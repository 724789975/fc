require "scripts/sys/class.lua"

local Resource = class.import("Client.Resource")

-- show console
console.Parent = gui

-- loading ui
local loading_frame = ptr_new "Gui.FlowLayout"
loading_frame.Dock = "kDockFill"
loading_frame.Align = "kAlignCenterBottom"
loading_frame.Parent = gui
loading_frame.BackgroundColor = ARGB(0, 0, 0, 0)

local progress_bar = ptr_new "Gui.Label"
progress_bar.BackgroundColor = ARGB(0, 0, 0, 0)
progress_bar.Parent = loading_frame
progress_bar.Size = Vector2(512, 20)
progress_bar.Margin = Vector4(0, 0, 0, 40)

local cache = {}

local function readfile(name)
	local file = io.open(name, "r")
	local result = ""
	local err = nil

	if file then
		result = file:read("*a")
		file:close()
	else
		err = "error open file"
	end

	return result
end

local func, err = loadin(cache, readfile("cache_effect.lua"))

if err then
	print(err)
	return
end

func()

local resource_count = 1
local resource_loaded = 1

-- get resource count
for _, t in pairs(cache) do
	if type(t) == "table" then
		resource_count = resource_count + #t
	end
end

local work_thread = coroutine.wrap(function()
	-- load resource
	for _, res in ipairs(cache.resource) do
		Resource.GC()
		Resource.Build(res, false)
		coroutine.yield()
	end

	-- load physx
	for _, res in ipairs(cache.physx) do
		Resource.GC()
		Resource.BuildByType(res, "physx", false)
		coroutine.yield()
	end

	-- copy scripts
	for _, file in ipairs(cache.copy) do
		if Resource.CopyFile(file) then
			print("copy file "..file)
		end
		coroutine.yield()
	end

	return true
end)

-- a per frame task
Task.Schedule(function()
	if work_thread() then
		game:Exit()
	else
		resource_loaded = resource_loaded + 1
		progress_bar.Text = string.format("building: %d / %d", resource_loaded, resource_count)
		Task.Schedule()
	end
end)
