module("L_GameBossBalance",package.seeall)

Level_data = nil

BoxScore = {-1,-1,-1,-1}
VipItemName = ""
openwitchbox = -1
BoxAndPrize = {-1,-1,-1,-1}
timefinish = false
finish_box = false
total_turn_chance = 0
BoxData = {}
Card = {}
BossPveCard = {}

turn_allcard = {}
allcard_num = 0
turn_card = {}
card_num = 0
isTurncard = true
local flag = {0,0,0,0,0,0}
PveCard_data = {}
PveAwards_data = {}
PveAwards_count = 0
PveAwards_page = 1
PveAwards_pages = 1

function SaveReplay(f)
	ptr_cast(game.CurrentState):ReplaySave(f)
end

-- function create_ui()

ui = Gui.Create()
{
	Gui.Control "ctrl_window_root"
	{
		Size = Vector2(1182, 883),
		--Location = Vector2(276, 22),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Dock = "kDockCenter",
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/GameBalance/summary_bg1.dds", Vector4(20, 20, 20, 20)),
		},
		
		Gui.TimeControl "PopCloseTimer"
		{
			-- Size = Vector2(0.5,0.5),
			-- BackgroundColor = ARGB(255, 255, 255, 255),
			
			-- EventFinish = function(Sender ,e)
				-- popup_card_window:Close()
			-- end
			Size = Vector2(5,5),
			Dock = "kDockCenter",
			BackgroundColor = ARGB(0, 255, 255, 255),
			EventTimeOut = function(sender, e)
				if popup_card_window then
					popup_card_window:Close()
				end
				if card_pve_window then
					card_pve_window:Close()
				end	
			end
		},
		
		Gui.Control "ctrl_window_BG"
		{
			Location = Vector2(15,15),
			Size = Vector2(1152, 780),
			BackgroundColor = ARGB(255, 255, 255, 255),
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/GameBalance/summary_bg2.dds", Vector4(20, 20, 20, 20)),
			},
			
			Gui.Control "ctrl_window_left"
			{
				Location = Vector2(10,10),
				Size = Vector2(300, 764),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_summary_boss_left01.dds", Vector4(0, 0, 0, 0)),
				},
				
				Gui.ScrollNumberButton "ctrl_window_left_middle"
				{
					Size = Vector2(400, 180),
					Location = Vector2(-133,138),
					BackgroundColor = ARGB(0, 255, 255, 255),
					ItemType = "numstyle3",
					ItemName = "#None",
					ScrollNumRange = "0,0",
					ScrollTime = 100.0,
					--ItemType = "numstyle2#numstyle1#numstyle1#levelstyle",
					--ItemName = lang:GetText("获得经验#获得能量#我的总能量#None"),
					--ScrollNumRange = "0,10000@2000,1000@100,1000",
					--ItemVSpace = "0,0,0",
					--Level = Vector2(0,10),
					--LevelRatio = Vector2(0,0.5),
				},
				
				Gui.ScrollNumberButton "ctrl_window_right_middle"
				{
					Size = Vector2(400, 180),
					Location = Vector2(-133,330),
					BackgroundColor = ARGB(0, 255, 255, 255),
					ItemType = "numstyle3",
					ItemName = "#None",
					ScrollNumRange = "0,0",
					ScrollTime = 100.0,
					--ItemType = "numstyle2#numstyle1#numstyle1#levelstyle",
					--ItemName = lang:GetText("获得经验#获得能量#我的总能量#None"),
					--ScrollNumRange = "0,10000@2000,1000@100,1000",
					--ItemVSpace = "0,0,0",
					--Level = Vector2(0,10),
					--LevelRatio = Vector2(0,0.5),
				},
			},
			
			Gui.Control "ctrl_window_right"
			{
				Location = Vector2(310,10),
				Size = Vector2(832, 198),
				BackgroundColor = ARGB(255, 255, 255, 255),
				
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_summary_boss_top01.dds", Vector4(10, 10, 10, 0)),
				},
				
				Gui.FlowLayout "buff_layout"
				{
					Location = Vector2(200,10),
					Size = Vector2(400,20),
					Direction = "kHorizontal",
					Align = "kAlignLeftMiddle",
					ControlAlign = "kAlignCenterMiddle",
					ControlSpace = 5,
				},
				
				Gui.Label "ctrl_vip"
				{
					Size = Vector2(40,28),
					Location = Vector2(200,32),
					BackgroundColor = ARGB(255,255,255,255),
				},
				
				Gui.Label "LVipSmall"
				{
					Size = Vector2(16,16),
					Location = Vector2(245,44),
					BackgroundColor = ARGB(255,255,255,255),
					
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/lb_icon_lv.dds", Vector4(0, 0, 0, 0)),
					},
				},
				
				Gui.Control "ctrl_level_background"
				{
					Size = Vector2(37, 33),
					Location = Vector2(261, 32),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/lv1-5.dds", Vector4(0, 0, 0, 0)),
					},
				},
				
				Gui.Label "ctrl_level_tens_m"
				{
					Size = Vector2(15, 33),
					Location = Vector2(265, 32),
					BackgroundColor = ARGB(255,255,255,255),
					Visible = true,
				},
				
				Gui.Label "ctrl_level_tens_m_front"
				{
					Size = Vector2(15, 33),
					Location = Vector2(265, 32),
					BackgroundColor = ARGB(255,255,255,255),
					Visible = true,
				},
				
				--等级个位
				Gui.Label "ctrl_level_unit_m"
				{
					Size = Vector2(15, 33),
					Location = Vector2(280, 32),
					BackgroundColor = ARGB(255,255,255,255),
					Visible = true,
				},
				
				Gui.Label "ctrl_level_unit_m_front"
				{
					Size = Vector2(15, 33),
					Location = Vector2(280, 32),
					BackgroundColor = ARGB(255,255,255,255),
					Visible = true,
				},

				--玩家姓名
				Gui.Label "lbl_user_name_top"
				{
					Size = Vector2(221, 45),
					TextColor = ARGB(255,226,217,208),
					TextAlign = "kAlignLeftMiddle",
					Text = lang:GetText("我的名字"),
					FontSize = 25,
					Location = Vector2(297, 22),
					--BackgroundColor = ARGB(255, 0, 0, 255),
				},
				Gui.ScrollNumberButton "ctrl_get_experience_sc"
				{
					NumberGroundImage = Gui.Image("InGameUI/lb_summary_number_l_bg3.dds"),
					Size = Vector2(600,160),
					Location = Vector2(150,-20),
					BackgroundColor = ARGB(0, 255, 255, 255),
					ItemType = "numstyle1",
					ItemName = lang:GetText("战队经验"),
					ScrollNumRange = "0,0",
					ScrollTime = 5.0,
					
					Gui.Label "IconVipExp"
					{
						Size = Vector2(40,24),
						Location = Vector2(170,100),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Visible = false,
					},
				},

				----------------获得能量滚动条-----------------------------
				Gui.ScrollNumberButton "ctrl_get_energy_sc"
				{
					NumberGroundImage = Gui.Image("InGameUI/lb_summary_number_l_bg3.dds"),
					Size = Vector2(600,160),
					Location = Vector2(150,30),
					BackgroundColor = ARGB(0, 255, 255, 255),
					ItemType = "numstyle2",
					ItemName = lang:GetText("战队贡献"),
					ScrollNumRange = "0,0",
					ScrollTime = 5.0,
					
					Gui.Label "IconVip"
					{
						Size = Vector2(40,24),
						Location = Vector2(170,100),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Visible = false,
					},
				},
				
				Gui.Label "lbl_Battle_Full"
				{
					Size = Vector2(600, 104),
					TextColor = ARGB(255,254,211,78),
					Text = lang:GetText("你今日获得的战队经验已达上限"),
					TextAlign = "kAlignCenterMiddle",
					FontSize = 18,
					Location = Vector2(200, 60),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("InGameUI/lb_summary_number_l_bg3.dds", Vector4(22, 22, 22, 22)),
					},
				},
				
				
			},
			
			
			
			Gui.ListTreeView "list_player_rank"
			{
				TreeVisible = false,
				AlwaysSelect = true,
				TreeVisible = false,
				AutoScroll = false,
				Size = Vector2(877, 547),
				Style = "Gui.ListTreeViewWith_VScroll",
				Location = Vector2(304, 173),
				TextColor = ARGB(255,226,217,208),
				HeaderHeight = 35,
				ItemHeight = 32,
				VScrollBarDisplay = "kHide",
				HeadFontSize = 18,
				HeadFontColor = ARGB(255, 215, 232, 227),
			},
			
			Gui.ListTreeView "list_BossPve_rank"
			{
				TreeVisible = false,
				AlwaysSelect = true,
				TreeVisible = false,
				AutoScroll = false,
				Size = Vector2(877, 547),
				Style = "Gui.ListTreeViewWith_VScroll",
				Location = Vector2(304, 173),
				TextColor = ARGB(255,226,217,208),
				HeaderHeight = 35,
				ItemHeight = 32,
				VScrollBarDisplay = "kHide",
				HeadFontSize = 18,
				HeadFontColor = ARGB(255, 215, 232, 227),
			},
		},
		
		--保存截图
		Gui.Button "btn_save_picture"
		{
			Size = Vector2(114, 52),
			Location = Vector2(742, 810),
			Text = lang:GetText("保存截图"),
			TextColor = ARGB(255, 0, 0, 0),
			FontSize = 18,
			PushDown = false,
			
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_battlecreate_button_create1_normal.dds", Vector4(20, 20, 20, 20)),
				HoverImage = Gui.Image("LobbyUI/GameBalance/lb_battlecreate_button_create1_hover.dds", Vector4(20, 20, 20, 20)),
				DownImage = Gui.Image("LobbyUI/GameBalance/lb_battlecreate_button_create1_down.dds", Vector4(20, 20, 20, 20)),
				DisabledImage = Gui.Image("LobbyUI/GameBalance/lb_battlecreate_button_create1_disabled.dds", Vector4(20, 20, 20, 20)),
			},
			
			EventClick = function()
				ptr_cast(game.CurrentState):AutoPhoto()
			end
		},
		
		--保存录像
		Gui.Button "btn_save_camera"
		{
			Size = Vector2(114, 52),
			Location = Vector2(867, 810),
			Text = lang:GetText("保存录像"),
			TextColor = ARGB(255, 0, 0, 0),
			FontSize = 18,
			PushDown = false,
			-- Visible = false,
			
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_battlecreate_button_create1_normal.dds", Vector4(20, 20, 20, 20)),
				HoverImage = Gui.Image("LobbyUI/GameBalance/lb_battlecreate_button_create1_hover.dds", Vector4(20, 20, 20, 20)),
				DownImage = Gui.Image("LobbyUI/GameBalance/lb_battlecreate_button_create1_down.dds", Vector4(20, 20, 20, 20)),
				DisabledImage = Gui.Image("LobbyUI/GameBalance/lb_battlecreate_button_create1_disabled.dds", Vector4(20, 20, 20, 20)),
			},
			
			EventClick = function()
				--ptr_cast(game.CurrentState):AutoPhoto()
				local level_id = ptr_cast(game.CurrentState):GetSelfRoomInfo().option.level_id
				local level_info = ptr_cast(game.CurrentState):GetLevelInfoById(level_id) or ""
				local single_mode = ptr_cast(game.CurrentState):GetSelfRoomInfo().option.character_id or ""
				print("level_info.type = "..level_info.type)
				local text = os.date("%Y-%m-%d-%H-%M_")..level_info.type.."_"..level_info.show_name.."_"..single_mode
				MessageBox.ShowWithTimer(3,lang:GetText("录像已保存"))
				SaveReplay(text)
				ui.btn_save_camera.Enable = false
			end
		},
		
		--确定
		Gui.Button "btn_confirm"
		{
			Size = Vector2(114, 52),
			Location = Vector2(992, 810),
			Text = lang:GetText("确定"),
			TextColor = ARGB(255, 0, 0, 0),
			FontSize = 18,
			PushDown = false,
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_battlecreate_button_create1_normal.dds", Vector4(20, 20, 20, 20)),
				HoverImage = Gui.Image("LobbyUI/GameBalance/lb_battlecreate_button_create1_hover.dds", Vector4(20, 20, 20, 20)),
				DownImage = Gui.Image("LobbyUI/GameBalance/lb_battlecreate_button_create1_down.dds", Vector4(20, 20, 20, 20)),
				DisabledImage = Gui.Image("LobbyUI/GameBalance/lb_battlecreate_button_create1_disabled.dds", Vector4(20, 20, 20, 20)),
			},
			
			EventClick = function()
				turn_allcard = {}
				allcard_num = 0
				turn_card = {}
				card_num = 0
				isTurncard = true
				local flag = {0,0,0,0,0,0}
				ptr_cast(game.CurrentState):Quit()
				L_LobbyMain.LobbyMainWin.invite_Timer:Show()
			end
		},
	},
}

-- ui.ctrl_window_root.Parent = gui

-- end

popup_card_window = nil

popup_card_window_ui =  Gui.Create()
{	
	Gui.Control "ctrl_popup_card_window"
	{
		Size = Vector2(1200,1000),
		Location = Vector2(0,0),
		BackgroundColor = ARGB(0, 255, 255, 255),
		
		Gui.Control "ctrl_popup_card_title"
		{
			Size = Vector2(1080,236),
			Location = Vector2(60,0),
			BackgroundColor = ARGB(0, 255, 255, 255),
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/WarZone/Present/lb_gift_biew_bg1.dds", Vector4(200,104,105,48)),
			},
		}
	}
}

function TurnCard(data)
	local index = data.index
	
	if index > 0 then
		local item_name = data.item.name
		local color = data.item.color
		
		if color > 1 then
			item_name = item_name.."_"..color
		end
		
		local cardback =  Gui.Image("LobbyUI/GameBalance/lb_summary_flop_card_back_1.dds", Vector4(0,0,0,0))
		local cardfront = Gui.Image("LobbyUI/GameBalance/lb_summary_flop_card_light.dds", Vector4(0,0,0,0))
		Card[index].card:DeleteFrameList("TurnCard")
		Card[index].card:AddFrame("TurnCard",cardback,Vector4(0, 0, 0, 0))
		Card[index].card:AddFrame("TurnCard",cardfront,Vector4(0, 0, 0, 0))
		Card[index].card:StartAnimation()
		
		print("item_name = "..item_name)
		local cardcontent = Gui.Image("LobbyUI/ibt_icon/"..item_name..".tga", Vector4(0,0,0,0))
		print("index = "..index)
		Card[index].card:AddFrame("TurnCard",cardcontent,Vector4(0, 0, 0, 0))	
		--Card[index]:StartAnimation()
		Card[index].card:TurnCard()
		Card[index].card.Enable = false
		if data.item.common.type == 4 and data.item.common.subtype == 7 or data.item.common.type == 5 then
			-- Card[index].card:OnDestroy()
			L_Characters.CreatPresentNumCtr(Card[index].card,data.item.item_num,132,159)
		end
		
		card_num = card_num + 1
		turn_card[card_num] = data.index
		
		if data.item.total_rare_level > 0 then
			--翻牌音效
			print(lang:GetText("播放翻牌音效"))
			gui:PlayAudio("kUIA_STAGE_TURNCARD")
		end
		gui:PlayAudio("kUIA_POKERCARD_TRUN")
		
		for i = 1, 6 do
			if flag[i] == 1 then
				flag[i] = 0
				if i == 1 then
					popup_card_window_ui.card_1.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("InGameUI/bottom_info/ig_common_fanpai_card_bg.dds", Vector4(0 , 0, 0, 0)),}
				elseif i == 2 then
					popup_card_window_ui.card_2.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("InGameUI/bottom_info/ig_common_fanpai_card_bg.dds", Vector4(0 , 0, 0, 0)),}
				elseif i == 3 then
					popup_card_window_ui.card_3.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("InGameUI/bottom_info/ig_common_fanpai_card_bg.dds", Vector4(0 , 0, 0, 0)),}
				elseif i == 4 then
					popup_card_window_ui.card_4.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("InGameUI/bottom_info/ig_common_fanpai_card_bg.dds", Vector4(0 , 0, 0, 0)),}
				elseif i == 5 then
					popup_card_window_ui.card_5.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("InGameUI/bottom_info/ig_common_fanpai_card_bg.dds", Vector4(0 , 0, 0, 0)),}
				elseif i == 6 then
					popup_card_window_ui.card_6.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("InGameUI/bottom_info/ig_common_fanpai_card_bg.dds", Vector4(0 , 0, 0, 0)),}
				end
				break
			end
		end
	else
		
	end
end

function SpawnNewCard(name,i)
	local row,col = 0,0
	local rownum,colnum = 3,3
	
	local CardIcon = Gui.Create(gui) {
					Gui.AnimControl "card"
					{
						Size = Vector2(144,172),
						BackgroundColor = ARGB(0, 255, 255, 255),
						PushDown = false,
						EventClick = function(Sender,e)
							if isTurncard then
								total_turn_chance = total_turn_chance - 1
								if total_turn_chance >= 0  and Sender.PushDown == false then
									Sender.PushDown = true
									local state = ptr_cast(game.CurrentState,"Client.StateBalance")
									local args = {pid = state:GetMyClientInfo().character_id,index = Sender.IntTag}
									rpc.safecall("stage_clear_open",args,TurnCard,function() MessageBox.CloseWaiter() end)
								end
								
								if total_turn_chance < 0 then
									total_turn_chance = 0
								end
								
								popup_card_window_ui.left_turncard_chance.Text = total_turn_chance
							end
						end,
						
						EventFinish  = function(Sender,e)
							for j=1,table.getn(turn_allcard) do
								if i == turn_allcard[j] then
									Card[i].get_card.Visible = true
								end
							end
							for j=1,table.getn(turn_card) do
								if i == turn_card[j] then
									Card[i].get_card.Visible = true
								end
							end
						end,
						
						Gui.Control "get_card"
						{	
							Size = Vector2(45,45),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Visible = false,
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_summary_flop_card_ico_01.dds", Vector4(0,0,0,0)),
							},
						}
					}
				}
	col = i / colnum
	col = math.floor(col)
	if i % colnum == 0 then
		col = col - 1
	end
	
	row = i - col * colnum
		
	CardIcon.card.Location = Vector2((row-1)*160+15,col*160 +5)
	CardIcon.get_card.Location = Vector2(12,13)
	CardIcon.card:AddAnim("TurnCard",0.5,5)
	
	local cardback =  Gui.Image("LobbyUI/GameBalance/lb_summary_flop_card_back_1.dds", Vector4(0,0,0,0))
	local cardfront = Gui.Image("LobbyUI/GameBalance/lb_summary_flop_card_front.dds", Vector4(0,0,0,0))
	
	CardIcon.card:AddFrame("TurnCard",cardback,Vector4(0, 0, 0, 0))
	CardIcon.card:AddFrame("TurnCard",cardfront,Vector4(0, 0, 0, 0))
	CardIcon.card:StartAnimation()
	CardIcon.card.IntTag = i
	
	return CardIcon
end

function TurnAllCard(data)
	turn_card = {}
	local items = data.items
	local turn_num = Split(data.indexs,",")
	local cardback =  Gui.Image("LobbyUI/GameBalance/lb_summary_flop_card_back_1.dds", Vector4(0,0,0,0))
	local cardfront = Gui.Image("LobbyUI/GameBalance/lb_summary_flop_card_light.dds", Vector4(0,0,0,0))
	popup_card_window_ui.left_turncard_chance.Text = "0"
	if items then
		for j = 1,table.getn(turn_num) do
			allcard_num = allcard_num+1
			turn_allcard[allcard_num] = tonumber(turn_num[j])
			if turn_allcard[allcard_num] then
				Card[turn_allcard[allcard_num]].card:DeleteFrameList("TurnCard")
				Card[turn_allcard[allcard_num]].card:AddFrame("TurnCard",cardback,Vector4(0, 0, 0, 0))
				Card[turn_allcard[allcard_num]].card:AddFrame("TurnCard",cardfront,Vector4(0, 0, 0, 0))
				Card[turn_allcard[allcard_num]].card:StartAnimation()
			end

			if data.indexs ~= "" and items[turn_allcard[allcard_num]].total_rare_level > 0 then
				--翻牌音效
				print(lang:GetText("播放翻牌音效"))
				gui:PlayAudio("kUIA_STAGE_TURNCARD")
			end
		end
	
		for i,v in ipairs(items) do		
			if i <= 9 and Card[i] and Card[i].card.Enable then
				local item_name = v.name
				local color = v.color
				
				if color > 1 then
					item_name = item_name.."_"..color
				end

				local cardcontent = Gui.Image("LobbyUI/ibt_icon/"..item_name..".tga", Vector4(0,0,0,0))
				Card[i].card:AddFrame("TurnCard",cardcontent,Vector4(0, 0, 0, 0))	
				Card[i].card:TurnCard()
				Card[i].card.Enable = false
				
				if v.common.type == 4 and v.common.subtype == 7 or v.common.type == 5 then
					-- Card[i].card:OnDestroy()
					L_Characters.CreatPresentNumCtr(Card[i].card,v.item_num,132,159)
				end
			end
		end
		for j = 1,table.getn(turn_num) do
			allcard_num = allcard_num+1
			turn_allcard[allcard_num] = tonumber(turn_num[j])
			if data.indexs ~= "" and items[turn_allcard[allcard_num]].total_rare_level > 0 then
				--翻牌音效
				print(lang:GetText("播放翻牌音效"))
				gui:PlayAudio("kUIA_STAGE_TURNCARD")
			end
		end
		gui:PlayAudio("kUIA_POKERCARD_TRUN")
		for i = 1, 6 do
			if flag[i] == 1 then
				flag[i] = 0
				if i == 1 then
					popup_card_window_ui.card_1.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("InGameUI/bottom_info/ig_common_fanpai_card_bg.dds", Vector4(0 , 0, 0, 0)),}
				elseif i == 2 then
					popup_card_window_ui.card_2.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("InGameUI/bottom_info/ig_common_fanpai_card_bg.dds", Vector4(0 , 0, 0, 0)),}
				elseif i == 3 then
					popup_card_window_ui.card_3.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("InGameUI/bottom_info/ig_common_fanpai_card_bg.dds", Vector4(0 , 0, 0, 0)),}
				elseif i == 4 then
					popup_card_window_ui.card_4.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("InGameUI/bottom_info/ig_common_fanpai_card_bg.dds", Vector4(0 , 0, 0, 0)),}
				elseif i == 5 then
					popup_card_window_ui.card_5.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("InGameUI/bottom_info/ig_common_fanpai_card_bg.dds", Vector4(0 , 0, 0, 0)),}
				elseif i == 6 then
					popup_card_window_ui.card_6.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("InGameUI/bottom_info/ig_common_fanpai_card_bg.dds", Vector4(0 , 0, 0, 0)),}
				end
			end
		end
	end
	gui:PlayAudio("kUIA_CONGRA_POP")
	-- ui.PopCloseTimer:AddAnim("CloseCardTimer",3,4)
	-- ui.PopCloseTimer:StartAnimation()
	ui.PopCloseTimer:CleanAll()
	ui.PopCloseTimer:AddTime(3)
end

popup_card_window = nil

popup_card_window_ui =  Gui.Create()
{	
	Gui.Control "ctrl_popup_card_window"
	{
		Size = Vector2(1200,1200),
		Location = Vector2(0,0),
		BackgroundColor = ARGB(0, 255, 255, 255),
		
		Gui.Control "ctrl_popup_card_content"
		{
			Size = Vector2(1080,760),
			Location = Vector2(60,274),
			BackgroundColor = ARGB(255, 255, 255, 255),
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/WarZone/Present/lb_gift_biew_bg1.dds", Vector4(200,104,105,48)),
			},
			
			Gui.Control "ctrl_popup_card_Score"
			{
				Size = Vector2(513,625),
				Location = Vector2(22,79),
				BackgroundColor = ARGB(255, 255, 255, 255),
				
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_summary_flop_bg_04.dds", Vector4(30 , 30, 30, 30)),
				},
				
				Gui.Control "ct_get_score"
				{
					Size = Vector2(471,47),
					Location = Vector2(19,67),
					BackgroundColor = ARGB(255, 255, 255, 255),
					
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_summary_flop_bg_02.dds", Vector4(20 , 20, 20, 20)),
					},
					
					Gui.Label ""
					{
						Size = Vector2(400, 46),
						Text = lang:GetText("获得积分"),
						FontSize = 20,
						TextColor = ARGB(255, 255, 181, 2),
						Location = Vector2(15, 1),
						TextAlign = "kAlignLeftMiddle",
					},
					Gui.AnimControl "ScrollScore"
					{
						Size = Vector2(330,44),
						Location  = Vector2(88,1),
						BackgroundColor = ARGB(0, 255, 255, 255),
					},
					
					Gui.Label "Unit"
					{
						Size = Vector2(100,46),
						Location  = Vector2(392,1),
						Text = lang:GetText("积分"),
						FontSize = 20,
						TextColor = ARGB(255, 255, 181, 2),
					},
				},
				
				Gui.Control "ct_get_exp"
				{
					Size = Vector2(471,135),
					Location = Vector2(19,139),
					BackgroundColor = ARGB(255, 255, 255, 255),
					
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_summary_flop_bg_03.dds", Vector4(30 , 30, 30, 30)),
					},
					
					Gui.Label ""
					{
						Size = Vector2(200, 46),
						Text = lang:GetText("获得经验:"),
						FontSize = 20,
						TextColor = ARGB(255, 255, 181, 2),
						Location = Vector2(15, 1),
						TextAlign = "kAlignLeftMiddle",
					},
					Gui.AnimControl "Scrollexp"
					{
						Size = Vector2(198,44),
						Location  = Vector2(220,4),
						BackgroundColor = ARGB(0, 255, 255, 255),
					},
					
					Gui.Label "Unit"
					{
						Size = Vector2(100,46),
						Location  = Vector2(392,1),
						Text = lang:GetText("经验"),
						FontSize = 20,
						TextColor = ARGB(255, 255, 181, 2),
					},
					
					Gui.Label ""
					{
						Size = Vector2(180,44),
						Location  = Vector2(5,45),
						Text = lang:GetText("基础获得"),
						FontSize = 16,
						TextColor = ARGB(255, 255, 181, 2),
						TextAlign = "kAlignLeftMiddle",
					},
					
					Gui.Label "scrollexp_base_get"
					{
						Size = Vector2(125,44),
						Location  = Vector2(190,45),
						Text = "10%",
						FontSize = 16,
						TextColor = ARGB(255, 219, 138, 56),
					},
					
					Gui.Label ""
					{
						Size = Vector2(180,44),
						Location  = Vector2(250,45),
						Text = "VIP",
						FontSize = 16,
						TextColor = ARGB(255, 255, 181, 2),
						TextAlign = "kAlignLeftMiddle",
					},
					
					Gui.Label "scrollexp_vip"
					{
						Size = Vector2(125,44),
						Location  = Vector2(435,45),
						Text = "10%",
						FontSize = 16,
						TextColor = ARGB(255, 219, 138, 56),
					},
					
					Gui.Label ""
					{
						Size = Vector2(180,44),
						Location  = Vector2(5,66),
						Text = lang:GetText("战队"),
						FontSize = 16,
						TextColor = ARGB(255, 255, 181, 2),
						TextAlign = "kAlignLeftMiddle",
					},
					
					Gui.Label "scrollexp_battle"
					{
						Size = Vector2(125,44),
						Location  = Vector2(190,66),
						Text = "10%",
						FontSize = 16,
						TextColor = ARGB(255, 219, 138, 56),
					},
					
					Gui.Label ""
					{
						Size = Vector2(180,44),
						Location  = Vector2(250,66),
						Text = lang:GetText("网吧"),
						FontSize = 16,
						TextColor = ARGB(255, 255, 181, 2),
						TextAlign = "kAlignLeftMiddle",
					},
					
					Gui.Label "scrollexp_cab"
					{
						Size = Vector2(125,44),
						Location  = Vector2(435,66),
						Text = "10%",
						FontSize = 16,
						TextColor = ARGB(255, 219, 138, 56),
					},
					
					Gui.Label ""
					{
						Size = Vector2(180,44),
						Location  = Vector2(5,87),
						Text = lang:GetText("活动"),
						FontSize = 16,
						TextColor = ARGB(255, 255, 181, 2),
						TextAlign = "kAlignLeftMiddle",
					},
					
					Gui.Label "scrollexp_activity"
					{
						Size = Vector2(125,44),
						Location  = Vector2(190,87),
						Text = "0%",
						FontSize = 16,
						TextColor = ARGB(255, 219, 138, 56),
					},
					Gui.Label ""
					{
						Size = Vector2(180,44),
						Location  = Vector2(250,87),
						Text = lang:GetText("道具"),
						FontSize = 16,
						TextColor = ARGB(255, 255, 181, 2),
						TextAlign = "kAlignLeftMiddle",
					},
					
					Gui.Label "scrollexp_daoju"
					{
						Size = Vector2(125,44),
						Location  = Vector2(435,87),
						Text = "10%",
						FontSize = 16,
						TextColor = ARGB(255, 219, 138, 56),
					},
					
				},
				
				Gui.Control "ct_get_eng"
				{
					Size = Vector2(471,135),
					Location = Vector2(19,299),
					BackgroundColor = ARGB(255, 255, 255, 255),
					
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_summary_flop_bg_03.dds", Vector4(30 , 30, 30, 30)),
					},
					
					Gui.Label ""
					{
						Size = Vector2(200, 46),
						Text = lang:GetText("获得C币:"),
						FontSize = 20,
						TextColor = ARGB(255, 255, 181, 2),
						Location = Vector2(15, 1),
					},
					
					Gui.AnimControl "Scrolleng"
					{
						Size = Vector2(198,44),
						Location  = Vector2(220,4),
						BackgroundColor = ARGB(0, 255, 255, 255),
					},
										
					Gui.Label "Unit"
					{
						Size = Vector2(100,46),
						Location  = Vector2(392,1),
						Text = lang:GetText("C币"),
						FontSize = 20,
						TextColor = ARGB(255, 255, 181, 2),
					},
					Gui.Label ""
					{
						Size = Vector2(180,44),
						Location  = Vector2(5,45),
						Text = lang:GetText("基础获得"),
						FontSize = 16,
						TextColor = ARGB(255, 255, 181, 2),
						TextAlign = "kAlignLeftMiddle",
					},

					Gui.Label "scrolleng_base_get"
					{
						Size = Vector2(125,44),
						Location  = Vector2(190,45),
						Text = "10%",
						FontSize = 16,
						TextColor = ARGB(255, 219, 138, 56),
					},
					
					Gui.Label ""
					{
						Size = Vector2(180,44),
						Location  = Vector2(250,45),
						Text = "VIP",
						FontSize = 16,
						TextColor = ARGB(255, 255, 181, 2),
						TextAlign = "kAlignLeftMiddle",
					},
					
					Gui.Label "scrolleng_vip"
					{
						Size = Vector2(125,44),
						Location  = Vector2(435,45),
						Text = "10%",
						FontSize = 16,
						TextColor = ARGB(255, 219, 138, 56),
					},
					
					Gui.Label ""
					{
						Size = Vector2(180,44),
						Location  = Vector2(5,66),
						Text = lang:GetText("战队"),
						FontSize = 16,
						TextColor = ARGB(255, 255, 181, 2),
						TextAlign = "kAlignLeftMiddle",
					},
					
					Gui.Label "scrolleng_battle"
					{
						Size = Vector2(125,44),
						Location  = Vector2(190,66),
						Text = "10%",
						FontSize = 16,
						TextColor = ARGB(255, 219, 138, 56),
					},
					
					Gui.Label ""
					{
						Size = Vector2(180,44),
						Location  = Vector2(250,66),
						Text = lang:GetText("网吧"),
						FontSize = 16,
						TextColor = ARGB(255, 255, 181, 2),
						TextAlign = "kAlignLeftMiddle",
					},
					
					Gui.Label "scrolleng_cab"
					{
						Size = Vector2(125,44),
						Location  = Vector2(435,66),
						Text = "10%",
						FontSize = 16,
						TextColor = ARGB(255, 219, 138, 56),
					},
					
					Gui.Label ""
					{
						Size = Vector2(180,44),
						Location  = Vector2(5,87),
						Text = lang:GetText("活动"),
						FontSize = 16,
						TextColor = ARGB(255, 255, 181, 2),
						TextAlign = "kAlignLeftMiddle",
					},
					
					Gui.Label "scrolleng_activity"
					{
						Size = Vector2(125,44),
						Location  = Vector2(190,87),
						Text = "0%",
						FontSize = 16,
						TextColor = ARGB(255, 219, 138, 56),
					},
					Gui.Label ""
					{
						Size = Vector2(180,44),
						Location  = Vector2(250,87),
						Text = lang:GetText("道具"),
						FontSize = 16,
						TextColor = ARGB(255, 255, 181, 2),
						TextAlign = "kAlignLeftMiddle",
					},
					
					Gui.Label "scrolleng_daoju"
					{
						Size = Vector2(125,44),
						Location  = Vector2(435,87),
						Text = "10%",
						FontSize = 16,
						TextColor = ARGB(255, 219, 138, 56),
					},
				},
				
				Gui.Control "ct_get_chance"
				{
					Size = Vector2(471,135),
					Location = Vector2(19,459),
					BackgroundColor = ARGB(255, 255, 255, 255),
					
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_summary_flop_bg_03.dds", Vector4(30 , 30, 30, 30)),
					},
					
					Gui.Label "chance_times"
					{
						Size = Vector2(300, 46),
						Text = lang:GetText("你总共获得了  次翻牌机会"),
						FontSize = 20,
						TextColor = ARGB(255, 255, 181, 2),
						Location = Vector2(15, 1),
					},
					
					-- Gui.Label "chance_times"
					-- {
						-- Size = Vector2(50, 60),
						-- Text = "3",
						-- FontSize = 32,
						-- TextColor = ARGB(255, 219, 138, 56),
						-- Location = Vector2(137, -8),
					-- },
					
					Gui.Label ""
					{
						Size = Vector2(180,44),
						Location  = Vector2(5,45),
						Text = lang:GetText("基础获得"),
						FontSize = 16,
						TextColor = ARGB(255, 255, 181, 2),
						TextAlign = "kAlignLeftMiddle",
					},
					
					Gui.Label "scrollchance_base_get"
					{
						Size = Vector2(125,44),
						Location  = Vector2(190,45),
						Text = "10%",
						FontSize = 16,
						TextColor = ARGB(255, 219, 138, 56),
					},
					
					Gui.Label ""
					{
						Size = Vector2(180,44),
						Location  = Vector2(250,45),
						Text = "VIP",
						FontSize = 16,
						TextColor = ARGB(255, 255, 181, 2),
						TextAlign = "kAlignLeftMiddle",
					},
					
					Gui.Label "scrollchance_vip"
					{
						Size = Vector2(125,44),
						Location  = Vector2(435,45),
						Text = "10%",
						FontSize = 16,
						TextColor = ARGB(255, 219, 138, 56),
					},
					
					Gui.Label ""
					{
						Size = Vector2(180,44),
						Location  = Vector2(5,66),
						Text = lang:GetText("网吧"),
						FontSize = 16,
						TextColor = ARGB(255, 255, 181, 2),
						TextAlign = "kAlignLeftMiddle",
					},
					
					Gui.Label "scrollchance_cab"
					{
						Size = Vector2(125,44),
						Location  = Vector2(190,66),
						Text = "10%",
						FontSize = 16,
						TextColor = ARGB(255, 219, 138, 56),
					},
					
					Gui.Label ""
					{
						Size = Vector2(100,44),
						Location  = Vector2(250,66),
						Text = lang:GetText("活动"),
						FontSize = 16,
						TextColor = ARGB(255, 255, 181, 2),
					},
					
					Gui.Label "scrollchance_activity"
					{
						Size = Vector2(125,44),
						Location  = Vector2(435,66),
						Text = "0%",
						FontSize = 16,
						TextColor = ARGB(255, 219, 138, 56),
					},
				},
			},
			
			Gui.Control "ctrl_popup_card_animation"
			{
				Size = Vector2(513,625),
				Location = Vector2(545,79),
				BackgroundColor = ARGB(255, 255, 255, 255),
				
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_summary_flop_bg_04.dds", Vector4(30 , 30, 30, 30)),
				},
				
				Gui.Label ""
				{
					Size = Vector2(200, 46),
					Text = lang:GetText("剩余时间:"),
					FontSize = 20,
					TextColor = ARGB(255, 255, 181, 2),
					Location = Vector2(330, 10),
				},
				
				Gui.AnimControl "card_timer"
				{
					Size = Vector2(40,46),
					Location  = Vector2(440,10),
					BackgroundColor = ARGB(0, 255, 255, 255),
					
					EventFinish = function(Sender,e)
						isTurncard = false
						local state = ptr_cast(game.CurrentState,"Client.StateBalance")
						local args = {pid = state:GetMyClientInfo().character_id}
						rpc.safecall("stage_clear_open_timeout",args,TurnAllCard,function() MessageBox.CloseWaiter() end)
					end
				},
				
				Gui.Control "ctrl_popup_card_timer"
				{
					Size = Vector2(471, 47),
					Location = Vector2(22,69),
					BackgroundColor = ARGB(255, 255, 255, 255),
					
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_summary_flop_bg_02.dds", Vector4(20 , 20, 20, 20)),
					},
					
					Gui.Label ""
					{
						Size = Vector2(200, 46),
						Text = lang:GetText("剩余次数:"),
						FontSize = 20,
						TextColor = ARGB(255, 255, 181, 2),
						Location = Vector2(15, 1),
					},
					
					Gui.Label "left_turncard_chance"
					{
						Size = Vector2(100, 46),
						Text = "3",
						FontSize = 24,
						TextColor = ARGB(255, 219, 138, 56),
						Location = Vector2(135, 1),
					},
					
					Gui.Control
					{
						Size = Vector2(36, 50),
						Location = Vector2(230, 1),
						BackgroundColor = ARGB(0, 255, 255, 255),
						
						Gui.Label
						{
							Size = Vector2(36, 15),
							Text = lang:GetText("分数"),
							FontSize = 10,
							Font = "simhei",
							TextColor = ARGB(255, 127, 118, 114),
							Location = Vector2(4, 5),
						},
						
						Gui.Control "card_1" 
						{
							Size = Vector2(36, 40),
							Location = Vector2(0, 5),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("InGameUI/bottom_info/ig_common_fanpai_card_bg.dds", Vector4(0 , 0, 0, 0)),
							},
						},
					},
					
					Gui.Control
					{
						Size = Vector2(36, 50),
						Location = Vector2(270, 1),
						BackgroundColor = ARGB(0, 255, 255, 255),
						
						Gui.Label
						{
							Size = Vector2(36, 15),
							Text = lang:GetText("分数"),
							FontSize = 10,
							Font = "simhei",
							TextColor = ARGB(255, 127, 118, 114),
							Location = Vector2(4, 5),
						},
						
						Gui.Control "card_2"
						{
							Size = Vector2(36, 40),
							Location = Vector2(0, 5),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("InGameUI/bottom_info/ig_common_fanpai_card_bg.dds", Vector4(0 , 0, 0, 0)),
							},
						},
					},

					Gui.Control
					{
						Size = Vector2(36, 50),
						Location = Vector2(310, 1),
						BackgroundColor = ARGB(0, 255, 255, 255),
						
						Gui.Label
						{
							Size = Vector2(36, 15),
							Text = lang:GetText("分数"),
							FontSize = 10,
							Font = "simhei",
							TextColor = ARGB(255, 127, 118, 114),
							Location = Vector2(4, 5),
						},
						
						Gui.Control "card_3"
						{
							Size = Vector2(36, 40),
							Location = Vector2(0, 5),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("InGameUI/bottom_info/ig_common_fanpai_card_bg.dds", Vector4(0 , 0, 0, 0)),
							},
						},
					},

					Gui.Control
					{
						Size = Vector2(36, 50),
						Location = Vector2(350, 1),
						BackgroundColor = ARGB(0, 255, 255, 255),

						Gui.Label
						{
							Size = Vector2(36, 15),
							Text = "VIP",
							FontSize = 10,
							Font = "simhei",
							TextColor = ARGB(255, 127, 118, 114),
							Location = Vector2(4, 5),
						},
						
						Gui.Control "card_4"
						{
							Size = Vector2(36, 40),
							Location = Vector2(0, 5),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("InGameUI/bottom_info/ig_common_fanpai_card_bg.dds", Vector4(0 , 0, 0, 0)),
							},
						},
					},

					Gui.Control
					{
						Size = Vector2(36, 50),
						Location = Vector2(390, 1),
						BackgroundColor = ARGB(0, 255, 255, 255),
						
						Gui.Label
						{
							Size = Vector2(36, 15),
							Text = lang:GetText("网吧"),
							FontSize = 10,
							Font = "simhei",
							TextColor = ARGB(255, 127, 118, 114),
							Location = Vector2(4, 5),
						},
						
						Gui.Control "card_5"
						{
							Size = Vector2(36, 40),
							Location = Vector2(0, 5),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("InGameUI/bottom_info/ig_common_fanpai_card_bg.dds", Vector4(0 , 0, 0, 0)),
							},
						},
					},

					Gui.Control
					{
						Size = Vector2(36, 50),
						Location = Vector2(430, 1),
						BackgroundColor = ARGB(0, 255, 255, 255),
						
						Gui.Label
						{
							Size = Vector2(36, 15),
							Text = lang:GetText("活动"),
							FontSize = 10,
							Font = "simhei",
							TextColor = ARGB(255, 127, 118, 114),
							Location = Vector2(4, 5),
						},						

						Gui.Control "card_6"
						{
							Size = Vector2(36, 40),
							Location = Vector2(0, 5),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("InGameUI/bottom_info/ig_common_fanpai_card_bg.dds", Vector4(0 , 0, 0, 0)),
							},
						},
					},
					-- Gui.Label ""
					-- {
						-- Size = Vector2(200, 46),
						-- Text = lang:GetText("剩余时间:"),
						-- FontSize = 20,
						-- TextColor = ARGB(255, 255, 181, 2),
						-- Location = Vector2(230, 1),
					-- },
					
					-- Gui.AnimControl "card_timer"
					-- {
						-- Size = Vector2(40,46),
						-- Location  = Vector2(340,1),
						-- BackgroundColor = ARGB(0, 255, 255, 255),
						
						-- EventFinish = function(Sender,e)	
							-- isTurncard = false
							-- local state = ptr_cast(game.CurrentState,"Client.StateBalance")
							-- local args = {pid = state:GetMyClientInfo().character_id}
							-- rpc.safecall("stage_clear_open_timeout",args,TurnAllCard,function() MessageBox.CloseWaiter() end)
						-- end
					-- },
				},
				
				Gui.Control "ctrl_popup_card_container"
				{
					Size = Vector2(491,491),
					Location = Vector2(11,126),
					BackgroundColor = ARGB(255, 255, 255, 255),
					
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_summary_flop_bg_04.dds", Vector4(30 , 30, 30, 30)),
					},
					
				},
			},
		},
		
		Gui.Control "ctrl_popup_card_title"
		{
			Size = Vector2(1072,260),
			Location = Vector2(64,155),
			BackgroundColor = ARGB(255, 255, 255, 255),
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_summary_flop_title_bg.dds", Vector4(0,0,0,0)),
			},
			
			Gui.Control "ctrl_popup_card_bg"
			{
				Size = Vector2(200,200),
				Location = Vector2(436, 5),
				BackgroundColor = ARGB(255, 255, 255, 255),
				
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_exp_ico_75_80.dds", Vector4(0,0,0,0)),
				},
			},
			
			Gui.Control
			{
				Size = Vector2(60, 105),
				Location = Vector2(529, 46),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Gui.Control "big_bg_one"
				{
					Size = Vector2(60, 105),
					Location = Vector2(0, 0),
					BackgroundColor = ARGB(255, 255, 255, 255),
				},
				Gui.Control "big_one"
				{
					Size = Vector2(60, 105 * (4+97)/105),
					Location = Vector2(0, 105 * (1 - (4+97)/105)),
					BackgroundColor = ARGB(255, 255, 255, 255),
				},
			},
			Gui.Control
			{
				Size = Vector2(60, 105),
				Location = Vector2(483, 46),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Gui.Control "big_bg_ten"
				{
					Size = Vector2(60, 105),
					Location = Vector2(0, 0),
					BackgroundColor = ARGB(255, 255, 255, 255),
				},
				Gui.Control "big_ten"
				{
					Size = Vector2(60, 105 * (4+97)/105),
					Location = Vector2(0, 105 * (1 - (4+97)/105)),
					BackgroundColor = ARGB(255, 255, 255, 255),
				},
			},
		},
	}
}

function ShowPopCard()
	popup_card_window_ui.ctrl_popup_card_container:OnDestroy()
	
	for i = 1, 9 do
		local newcard = SpawnNewCard("",i)
		Card[i] = newcard
		newcard.card.Parent = popup_card_window_ui.ctrl_popup_card_container
	end
	
	popup_card_window = ModalWindow.GetNew()
	popup_card_window.root.Size = Vector2(1200,1200)
	popup_card_window.screen.AllowEscToExit = false
	
	popup_card_window_ui.ctrl_popup_card_window.Parent = popup_card_window.root
end

function TurnBossPveCard(index)
	if index > 0 then
		local item_name = PveCard_data[index].name
		local color = PveCard_data[index].color
		
		if color > 1 then
			item_name = item_name.."_"..color
		end
		
		local cardback =  Gui.Image("LobbyUI/GameBalance/lb_summary_flop_card_back_"..index..".dds", Vector4(0,0,0,0))
		local cardfront = Gui.Image("LobbyUI/GameBalance/lb_summary_flop_card_light.dds", Vector4(0,0,0,0))
		BossPveCard[index].card:DeleteFrameList("TurnCard")
		BossPveCard[index].card:AddFrame("TurnCard",cardback,Vector4(0, 0, 0, 0))
		BossPveCard[index].card:AddFrame("TurnCard",cardfront,Vector4(0, 0, 0, 0))
		BossPveCard[index].card:StartAnimation()
		
		print("item_name = "..item_name)
		local cardcontent = Gui.Image("LobbyUI/ibt_icon/"..item_name..".tga", Vector4(0,0,0,0))
		print("index = "..index)
		BossPveCard[index].card:AddFrame("TurnCard",cardcontent,Vector4(0, 0, 0, 0))	
		BossPveCard[index].card:TurnCard()
		BossPveCard[index].card.Enable = false
		print("PveCard_data[index].common.type:"..PveCard_data[index].common.type)
		print("PveCard_data[index].common.subtype:"..PveCard_data[index].common.subtype)
		print("PveCard_data[index].item_num:"..PveCard_data[index].item_num)
		if PveCard_data[index].common.type == 4 and PveCard_data[index].common.subtype == 7 or PveCard_data[index].common.type == 5 then
			-- Card[index].card:OnDestroy()
			L_Characters.CreatPresentNumCtr(BossPveCard[index].card,PveCard_data[index].item_num,112,136)
		end
		if PveCard_data[index].total_rare_level > 0 then
			--翻牌音效
			print(lang:GetText("播放翻牌音效"))
			gui:PlayAudio("kUIA_STAGE_TURNCARD")
		end
		gui:PlayAudio("kUIA_POKERCARD_TRUN")
	end
end

function SpawnBossPveCard(name,i)
	local CardIcon = Gui.Create(gui) {
					Gui.AnimControl "card"
					{
						Size = Vector2(112,136),
						BackgroundColor = ARGB(0, 255, 255, 255),
						PushDown = false,
						EventClick = function(Sender,e)
							if isTurncard then
								total_turn_chance = total_turn_chance - 1
								if total_turn_chance >= 0  and Sender.PushDown == false then
									Sender.PushDown = true
									TurnBossPveCard(i)
								end
								if total_turn_chance < 0 then
									total_turn_chance = 0
								end
								card_pve_window_ui.left_turncard_chance.Text = total_turn_chance
							end
						end,
						
						EventFinish  = function(Sender,e)
							-- BossPveCard[i].get_card.Visible = true
						end,
						
						Gui.Control "get_card"
						{	
							Size = Vector2(36,36),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Visible = false,
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_summary_flop_card_ico_01.dds", Vector4(0,0,0,0)),
							},
						}
					}
				}	
	CardIcon.card.Location = Vector2((i-1)*128+10,17)
	CardIcon.get_card.Location = Vector2(8,10)
	CardIcon.card:AddAnim("TurnCard",0.5,5)
	
	local cardback =  Gui.Image("LobbyUI/GameBalance/lb_summary_flop_card_back_"..i..".dds", Vector4(0,0,0,0))
	local cardfront = Gui.Image("LobbyUI/GameBalance/lb_summary_flop_card_front.dds", Vector4(0,0,0,0))
	
	CardIcon.card:AddFrame("TurnCard",cardback,Vector4(0, 0, 0, 0))
	CardIcon.card:AddFrame("TurnCard",cardfront,Vector4(0, 0, 0, 0))
	CardIcon.card:StartAnimation()
	CardIcon.card.IntTag = i
	return CardIcon
end

function TurnAllBossPveCard()
	turn_card = {}
	local cardback =  Gui.Image("LobbyUI/GameBalance/lb_summary_flop_card_back_1.dds", Vector4(0,0,0,0))
	local cardfront = Gui.Image("LobbyUI/GameBalance/lb_summary_flop_card_light.dds", Vector4(0,0,0,0))
	card_pve_window_ui.left_turncard_chance.Text = "0"
	if PveCard_data then
		for i,v in ipairs(PveCard_data) do		
			if i <= 4 and BossPveCard[i] and BossPveCard[i].card.Enable then
				if PveCard_data[i] then
					BossPveCard[i].card:DeleteFrameList("TurnCard")
					cardback =  Gui.Image("LobbyUI/GameBalance/lb_summary_flop_card_back_"..i..".dds", Vector4(0,0,0,0))
					BossPveCard[i].card:AddFrame("TurnCard",cardback,Vector4(0, 0, 0, 0))
					BossPveCard[i].card:AddFrame("TurnCard",cardfront,Vector4(0, 0, 0, 0))
					BossPveCard[i].card:StartAnimation()
				end
				local item_name = v.name
				local color = v.color
				
				if color > 1 then
					item_name = item_name.."_"..color
				end

				local cardcontent = Gui.Image("LobbyUI/ibt_icon/"..item_name..".tga", Vector4(0,0,0,0))
				BossPveCard[i].card:AddFrame("TurnCard",cardcontent,Vector4(0, 0, 0, 0))	
				BossPveCard[i].card:TurnCard()
				BossPveCard[i].card.Enable = false
				
				if v.common.type == 4 and v.common.subtype == 7 or v.common.type == 5 then
					-- Card[i].card:OnDestroy()
					L_Characters.CreatPresentNumCtr(BossPveCard[i].card,v.item_num,112,136)
				end
				
				if v.total_rare_level > 0 then
					--翻牌音效
					print(lang:GetText("播放翻牌音效"))
					gui:PlayAudio("kUIA_STAGE_TURNCARD")
				end
			end
		end
		gui:PlayAudio("kUIA_POKERCARD_TRUN")
	end
	gui:PlayAudio("kUIA_CONGRA_POP")
	ui.PopCloseTimer:CleanAll()
	ui.PopCloseTimer:AddTime(3)
end

card_pve_window = nil

function CreateBossAwards(index,x,y)
	return Gui.ItemBoxBtn
			{
				Style = "Gui.ItemBoxBtn_ib",
				Size = Vector2(111, 111),
				Location = Vector2(x, y),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ItemBoxBtnSkin
				{
					NeutralNormalImage =  Gui.Image("LobbyUI/team/NewFight/lb_synthesis_common_slot.dds", Vector4(0, 0, 0, 0)),
					NeutralSelectedImage =  Gui.Image("LobbyUI/team/NewFight/lb_synthesis_common_slot.dds", Vector4(0, 0, 0, 0)),
					NeutralDisabledImage =  Gui.Image("LobbyUI/team/NewFight/lb_synthesis_common_slot.dds", Vector4(0, 0, 0, 0)),
				},
				EventMouseEnter = function(sender, e)
					L_ToolTips.FillToolTipsVIPPresent(index, card_pve_window.root, PveAwards_data)
				end,
				EventToolTipsShow = function(sender, e)
					if PveAwards_data[index] then
						local loc = sender.Location + sender.Parent.Location + sender.Parent.Parent.Location + sender.Parent.Parent.Parent.Location
						L_ToolTips.ShowToolTipsShowWindow(sender,Vector2(1200,1200), loc)
					end
				end,
				EventMouseLeave = function(sender, e)
					L_ToolTips.HideToolTipsWindow()
				end,
			}
end

card_pve_window_ui =  Gui.Create()
{	
	Gui.Control "ctrl_popup_card_window"
	{
		Size = Vector2(1200,1200),
		Location = Vector2(0,0),
		BackgroundColor = ARGB(0, 255, 255, 255),
		
		Gui.Control "ctrl_popup_card_content"
		{
			Size = Vector2(1080,760),
			Location = Vector2(60,274),
			BackgroundColor = ARGB(255, 255, 255, 255),
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/WarZone/Present/lb_gift_biew_bg1.dds", Vector4(200,104,105,48)),
			},
			
			Gui.Control "ctrl_popup_card_Score"
			{
				Size = Vector2(513,625),
				Location = Vector2(22,79),
				BackgroundColor = ARGB(255, 255, 255, 255),
				
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_summary_flop_bg_04.dds", Vector4(30 , 30, 30, 30)),
				},
				
				Gui.Control "ct_get_score"
				{
					Size = Vector2(471,47),
					Location = Vector2(19,67),
					BackgroundColor = ARGB(255, 255, 255, 255),
					
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_summary_flop_bg_02.dds", Vector4(20 , 20, 20, 20)),
					},
					
					Gui.Label ""
					{
						Size = Vector2(400, 46),
						Text = lang:GetText("获得积分"),
						FontSize = 20,
						TextColor = ARGB(255, 255, 181, 2),
						Location = Vector2(15, 1),
						TextAlign = "kAlignLeftMiddle",
					},
					Gui.AnimControl "ScrollScore"
					{
						Size = Vector2(330,44),
						Location  = Vector2(108,1),
						BackgroundColor = ARGB(0, 255, 255, 255),
					},
					
					Gui.Label "Unit"
					{
						Size = Vector2(100,46),
						Location  = Vector2(412,1),
						Text = lang:GetText("积分"),
						FontSize = 20,
						TextColor = ARGB(255, 255, 181, 2),
					},
				},
				
				Gui.Control "ct_get_exp"
				{
					Size = Vector2(471,135),
					Location = Vector2(19,139),
					BackgroundColor = ARGB(255, 255, 255, 255),
					
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_summary_flop_bg_03.dds", Vector4(30 , 30, 30, 30)),
					},
					
					Gui.Label ""
					{
						Size = Vector2(200, 46),
						Text = lang:GetText("获得经验:"),
						FontSize = 20,
						TextColor = ARGB(255, 255, 181, 2),
						Location = Vector2(15, 1),
						TextAlign = "kAlignLeftMiddle",
					},
					Gui.AnimControl "Scrollexp"
					{
						Size = Vector2(198,44),
						Location  = Vector2(240,4),
						BackgroundColor = ARGB(0, 255, 255, 255),
					},
					
					Gui.Label "Unit"
					{
						Size = Vector2(100,46),
						Location  = Vector2(412,1),
						Text = lang:GetText("经验"),
						FontSize = 20,
						TextColor = ARGB(255, 255, 181, 2),
					},
					
					Gui.Label ""
					{
						Size = Vector2(180,44),
						Location  = Vector2(5,45),
						Text = lang:GetText("基础获得"),
						FontSize = 16,
						TextColor = ARGB(255, 255, 181, 2),
						TextAlign = "kAlignLeftMiddle",
					},
					
					Gui.Label "scrollexp_base_get"
					{
						Size = Vector2(125,44),
						Location  = Vector2(190,45),
						Text = "10%",
						FontSize = 16,
						TextColor = ARGB(255, 219, 138, 56),
					},
					
					Gui.Label ""
					{
						Size = Vector2(180,44),
						Location  = Vector2(250,45),
						Text = "VIP",
						FontSize = 16,
						TextColor = ARGB(255, 255, 181, 2),
						TextAlign = "kAlignLeftMiddle",
					},
					
					Gui.Label "scrollexp_vip"
					{
						Size = Vector2(125,44),
						Location  = Vector2(435,45),
						Text = "10%",
						FontSize = 16,
						TextColor = ARGB(255, 219, 138, 56),
					},
					
					Gui.Label ""
					{
						Size = Vector2(180,44),
						Location  = Vector2(5,66),
						Text = lang:GetText("战队"),
						FontSize = 16,
						TextColor = ARGB(255, 255, 181, 2),
						TextAlign = "kAlignLeftMiddle",
					},
					
					Gui.Label "scrollexp_battle"
					{
						Size = Vector2(125,44),
						Location  = Vector2(190,66),
						Text = "10%",
						FontSize = 16,
						TextColor = ARGB(255, 219, 138, 56),
					},
					
					Gui.Label ""
					{
						Size = Vector2(180,44),
						Location  = Vector2(250,66),
						Text = lang:GetText("网吧"),
						FontSize = 16,
						TextColor = ARGB(255, 255, 181, 2),
						TextAlign = "kAlignLeftMiddle",
					},
					
					Gui.Label "scrollexp_cab"
					{
						Size = Vector2(125,44),
						Location  = Vector2(435,66),
						Text = "10%",
						FontSize = 16,
						TextColor = ARGB(255, 219, 138, 56),
					},
					
					Gui.Label ""
					{
						Size = Vector2(180,44),
						Location  = Vector2(5,87),
						Text = lang:GetText("活动"),
						FontSize = 16,
						TextColor = ARGB(255, 255, 181, 2),
						TextAlign = "kAlignLeftMiddle",
					},
					
					Gui.Label "scrollexp_activity"
					{
						Size = Vector2(125,44),
						Location  = Vector2(190,87),
						Text = "0%",
						FontSize = 16,
						TextColor = ARGB(255, 219, 138, 56),
					},
					Gui.Label ""
					{
						Size = Vector2(180,44),
						Location  = Vector2(250,87),
						Text = lang:GetText("道具"),
						FontSize = 16,
						TextColor = ARGB(255, 255, 181, 2),
						TextAlign = "kAlignLeftMiddle",
					},
					
					Gui.Label "scrollexp_daoju"
					{
						Size = Vector2(125,44),
						Location  = Vector2(435,87),
						Text = "10%",
						FontSize = 16,
						TextColor = ARGB(255, 219, 138, 56),
					},
					
				},
				
				Gui.Control "ct_get_eng"
				{
					Size = Vector2(471,135),
					Location = Vector2(19,299),
					BackgroundColor = ARGB(255, 255, 255, 255),
					
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_summary_flop_bg_03.dds", Vector4(30 , 30, 30, 30)),
					},
					
					Gui.Label ""
					{
						Size = Vector2(200, 46),
						Text = lang:GetText("获得C币:"),
						FontSize = 20,
						TextColor = ARGB(255, 255, 181, 2),
						Location = Vector2(15, 1),
					},
					
					Gui.AnimControl "Scrolleng"
					{
						Size = Vector2(198,44),
						Location  = Vector2(220,4),
						BackgroundColor = ARGB(0, 255, 255, 255),
					},
										
					Gui.Label "Unit"
					{
						Size = Vector2(100,46),
						Location  = Vector2(392,1),
						Text = lang:GetText("C币"),
						FontSize = 20,
						TextColor = ARGB(255, 255, 181, 2),
					},
					Gui.Label ""
					{
						Size = Vector2(180,44),
						Location  = Vector2(5,45),
						Text = lang:GetText("基础获得"),
						FontSize = 16,
						TextColor = ARGB(255, 255, 181, 2),
						TextAlign = "kAlignLeftMiddle",
					},

					Gui.Label "scrolleng_base_get"
					{
						Size = Vector2(125,44),
						Location  = Vector2(190,45),
						Text = "10%",
						FontSize = 16,
						TextColor = ARGB(255, 219, 138, 56),
					},
					
					Gui.Label ""
					{
						Size = Vector2(180,44),
						Location  = Vector2(250,45),
						Text = "VIP",
						FontSize = 16,
						TextColor = ARGB(255, 255, 181, 2),
						TextAlign = "kAlignLeftMiddle",
					},
					
					Gui.Label "scrolleng_vip"
					{
						Size = Vector2(125,44),
						Location  = Vector2(435,45),
						Text = "10%",
						FontSize = 16,
						TextColor = ARGB(255, 219, 138, 56),
					},
					
					Gui.Label ""
					{
						Size = Vector2(180,44),
						Location  = Vector2(5,66),
						Text = lang:GetText("战队"),
						FontSize = 16,
						TextColor = ARGB(255, 255, 181, 2),
						TextAlign = "kAlignLeftMiddle",
					},
					
					Gui.Label "scrolleng_battle"
					{
						Size = Vector2(125,44),
						Location  = Vector2(190,66),
						Text = "10%",
						FontSize = 16,
						TextColor = ARGB(255, 219, 138, 56),
					},
					
					Gui.Label ""
					{
						Size = Vector2(180,44),
						Location  = Vector2(250,66),
						Text = lang:GetText("网吧"),
						FontSize = 16,
						TextColor = ARGB(255, 255, 181, 2),
						TextAlign = "kAlignLeftMiddle",
					},
					
					Gui.Label "scrolleng_cab"
					{
						Size = Vector2(125,44),
						Location  = Vector2(435,66),
						Text = "10%",
						FontSize = 16,
						TextColor = ARGB(255, 219, 138, 56),
					},
					
					Gui.Label ""
					{
						Size = Vector2(180,44),
						Location  = Vector2(5,87),
						Text = lang:GetText("活动"),
						FontSize = 16,
						TextColor = ARGB(255, 255, 181, 2),
						TextAlign = "kAlignLeftMiddle",
					},
					
					Gui.Label "scrolleng_activity"
					{
						Size = Vector2(125,44),
						Location  = Vector2(190,87),
						Text = "0%",
						FontSize = 16,
						TextColor = ARGB(255, 219, 138, 56),
					},
					Gui.Label ""
					{
						Size = Vector2(180,44),
						Location  = Vector2(250,87),
						Text = lang:GetText("道具"),
						FontSize = 16,
						TextColor = ARGB(255, 255, 181, 2),
						TextAlign = "kAlignLeftMiddle",
					},
					
					Gui.Label "scrolleng_daoju"
					{
						Size = Vector2(125,44),
						Location  = Vector2(435,87),
						Text = "10%",
						FontSize = 16,
						TextColor = ARGB(255, 219, 138, 56),
					},
				},
				
				Gui.Control "ct_get_chance"
				{
					Size = Vector2(471,135),
					Location = Vector2(19,459),
					BackgroundColor = ARGB(255, 255, 255, 255),
					
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_summary_flop_bg_03.dds", Vector4(30 , 30, 30, 30)),
					},
					
					Gui.Label "chance_times"
					{
						Size = Vector2(300, 46),
						Text = lang:GetText("你总共获得了  次翻牌机会"),
						FontSize = 20,
						TextColor = ARGB(255, 255, 181, 2),
						Location = Vector2(15, 1),
					},
					
					-- Gui.Label "chance_times"
					-- {
						-- Size = Vector2(50, 60),
						-- Text = "3",
						-- FontSize = 32,
						-- TextColor = ARGB(255, 219, 138, 56),
						-- Location = Vector2(137, -8),
					-- },
					
					Gui.Label ""
					{
						Size = Vector2(180,44),
						Location  = Vector2(5,45),
						Text = lang:GetText("基础获得"),
						FontSize = 16,
						TextColor = ARGB(255, 255, 181, 2),
						TextAlign = "kAlignLeftMiddle",
					},
					
					Gui.Label "scrollchance_base_get"
					{
						Size = Vector2(125,44),
						Location  = Vector2(190,45),
						Text = "10%",
						FontSize = 16,
						TextColor = ARGB(255, 219, 138, 56),
					},
					
					Gui.Label ""
					{
						Size = Vector2(180,44),
						Location  = Vector2(250,45),
						Text = "VIP",
						FontSize = 16,
						TextColor = ARGB(255, 255, 181, 2),
						TextAlign = "kAlignLeftMiddle",
					},
					
					Gui.Label "scrollchance_vip"
					{
						Size = Vector2(125,44),
						Location  = Vector2(435,45),
						Text = "10%",
						FontSize = 16,
						TextColor = ARGB(255, 219, 138, 56),
					},
					
					Gui.Label ""
					{
						Size = Vector2(180,44),
						Location  = Vector2(5,66),
						Text = lang:GetText("网吧"),
						FontSize = 16,
						TextColor = ARGB(255, 255, 181, 2),
						TextAlign = "kAlignLeftMiddle",
					},
					
					Gui.Label "scrollchance_cab"
					{
						Size = Vector2(125,44),
						Location  = Vector2(190,66),
						Text = "10%",
						FontSize = 16,
						TextColor = ARGB(255, 219, 138, 56),
					},
					
					Gui.Label ""
					{
						Size = Vector2(100,44),
						Location  = Vector2(250,66),
						Text = lang:GetText("活动"),
						FontSize = 16,
						TextColor = ARGB(255, 255, 181, 2),
					},
					
					Gui.Label "scrollchance_activity"
					{
						Size = Vector2(125,44),
						Location  = Vector2(435,66),
						Text = "0%",
						FontSize = 16,
						TextColor = ARGB(255, 219, 138, 56),
					},
				},
			},
			
			Gui.Control "ctrl_popup_card_animation"
			{
				Size = Vector2(513,320),
				Location = Vector2(545,79),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_summary_flop_bg_04.dds", Vector4(30 , 30, 30, 30)),
				},
				
				Gui.Label
				{
					Size = Vector2(513,40),
					Location = Vector2(0,11),
					BackgroundColor = ARGB(255, 255, 255, 255),
					TextAlign = "kAlignCenterMiddle",
					Text = lang:GetText("胜利翻牌奖励"),
					TextColor = ARGB(255, 255, 133, 0),
					FontSize = 30,
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/GameBalance/ig_bo2_reward_title_02.dds", Vector4(0 , 0, 0, 0)),
					},
				},
				Gui.Control
				{
					Size = Vector2(486,47),
					Location = Vector2(13,55),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_summary_flop_bg_02.dds", Vector4(20, 20, 20, 20)),
					},
					Gui.Label ""
					{
						Size = Vector2(200, 46),
						Text = lang:GetText("剩余次数:"),
						FontSize = 20,
						TextColor = ARGB(255, 255, 181, 2),
						Location = Vector2(22, 0),
						Visible = false,
					},
					
					Gui.Label "left_turncard_chance"
					{
						Size = Vector2(100, 46),
						Text = "3",
						FontSize = 24,
						TextColor = ARGB(255, 219, 138, 56),
						Location = Vector2(139, 0),
						Visible = false,
					},
					
					Gui.Label ""
					{
						Size = Vector2(200, 46),
						Text = lang:GetText("剩余时间:"),
						FontSize = 20,
						TextColor = ARGB(255, 255, 181, 2),
						Location = Vector2(160, 0),
					},
					
					Gui.AnimControl "card_timer"
					{
						Size = Vector2(40,46),
						Location  = Vector2(272,0),
						BackgroundColor = ARGB(0, 255, 255, 255),
						
						EventFinish = function(Sender,e)
							isTurncard = false
							TurnAllBossPveCard()
						end
					},
				},
				
				Gui.Control "ctrl_popup_card_container"
				{
					Size = Vector2(492,167),
					Location = Vector2(11,126),
					BackgroundColor = ARGB(255, 255, 255, 255),
					
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_summary_flop_bg_02.dds", Vector4(20 , 20, 20, 20)),
					},
				},
			},
			
			Gui.Control "ctrl_get_boss_item"
			{
				Size = Vector2(513,296),
				Location = Vector2(545,407),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_summary_flop_bg_04.dds", Vector4(30 , 30, 30, 30)),
				},
				
				Gui.Label
				{
					Size = Vector2(513,40),
					Location = Vector2(0,11),
					BackgroundColor = ARGB(255, 255, 255, 255),
					TextAlign = "kAlignCenterMiddle",
					Text = lang:GetText("拾取到的BOSS掉落奖励"),
					TextColor = ARGB(255, 255, 133, 0),
					FontSize = 30,
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/GameBalance/ig_bo2_reward_title_02.dds", Vector4(0 , 0, 0, 0)),
					},
				},
				Gui.Control "ctrl_boss_get_container"
				{
					Size = Vector2(484,183),
					Location = Vector2(14,74),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_summary_flop_bg_02.dds", Vector4(20, 20, 20, 20)),
					},
					CreateBossAwards(1,13,19),
					CreateBossAwards(2,128,19),
					CreateBossAwards(3,243,19),
					CreateBossAwards(4,358,19),
					
					Gui.Button "m_Left"
					{	
						Size = Vector2(44, 32),
						Visible = true,
						Location = Vector2(153,130),
						TextColor = ARGB(255, 209, 227, 221),
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ib_common_nextpage_button_normal.dds", Vector4(5, 5, 10, 5)),
							HoverImage = Gui.Image("LobbyUI/ib_common_nextpage_button_hover.dds", Vector4(5, 5, 10, 5)),
							DownImage = Gui.Image("LobbyUI/ib_common_nextpage_button_down.dds", Vector4(5, 5, 10, 5)),
							DisabledImage = Gui.Image("LobbyUI/ib_common_nextpage_button_normal.dds", Vector4(5, 5, 10, 5)),
						},
						EventClick = function()
							if PveAwards_page ~= 1 then
								PveAwards_page = PveAwards_page - 1
								FillBossGet()
							end
						end	
					},
					Gui.Button "m_Right"
					{
						Size = Vector2(44, 32),
						Visible = true,
						Location = Vector2(299,130),
						TextColor = ARGB(255, 209, 227, 221),
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ib_common_nextpage_button02_normal.dds", Vector4(5, 5, 10, 5)),
							HoverImage = Gui.Image("LobbyUI/ib_common_nextpage_button02_hover.dds", Vector4(5, 5, 10, 5)),
							DownImage = Gui.Image("LobbyUI/ib_common_nextpage_button02_down.dds", Vector4(5, 5, 10, 5)),
							DisabledImage = Gui.Image("LobbyUI/ib_common_nextpage_button02_normal.dds", Vector4(5, 5, 10, 5)),
						},
						EventClick = function()
							if PveAwards_page ~= PveAwards_pages then
								PveAwards_page = PveAwards_page + 1
								FillBossGet()
							end
						end	
					},
					
					Gui.Button "m_PageDisplay"
					{
						Size = Vector2(82,33),
						FontSize = 24,
						Visible = true,
						Location = Vector2(207,130),
						TextColor = ARGB(255, 37, 37, 37),
						HighlightTextColor = ARGB(255, 37, 37, 37),
						TextAlign = "kAlignCenterMiddle",
						Text = "1/1",
						BackgroundColor = ARGB(255, 255, 255, 255),
						
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/team/lb_common_fanye_down.tga", Vector4(5, 5, 10, 5)),
							--HoverImage = Gui.Image("LobbyUI/team/lb_common_fanye_down.tga", Vector4(5, 5, 10, 5)),
							--DownImage = Gui.Image("LobbyUI/team/lb_common_fanye_down.tga", Vector4(5, 5, 10, 5)),
							DisabledImage = Gui.Image("LobbyUI/team/lb_common_fanye_down.tga", Vector4(5, 5, 10, 5)),
						},
					},
				},
			},	
		},
		
		Gui.Control "ctrl_popup_card_title"
		{
			Size = Vector2(1072,260),
			Location = Vector2(64,155),
			BackgroundColor = ARGB(255, 255, 255, 255),
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_summary_flop_title_bg.dds", Vector4(0,0,0,0)),
			},
			
			Gui.Control "ctrl_popup_card_bg"
			{
				Size = Vector2(200,200),
				Location = Vector2(436, 5),
				BackgroundColor = ARGB(255, 255, 255, 255),
				
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_exp_ico_75_80.dds", Vector4(0,0,0,0)),
				},
			},
			
			Gui.Control
			{
				Size = Vector2(60, 105),
				Location = Vector2(529, 46),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Gui.Control "big_bg_one"
				{
					Size = Vector2(60, 105),
					Location = Vector2(0, 0),
					BackgroundColor = ARGB(255, 255, 255, 255),
				},
				Gui.Control "big_one"
				{
					Size = Vector2(60, 105 * (4+97)/105),
					Location = Vector2(0, 105 * (1 - (4+97)/105)),
					BackgroundColor = ARGB(255, 255, 255, 255),
				},
			},
			Gui.Control
			{
				Size = Vector2(60, 105),
				Location = Vector2(483, 46),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Gui.Control "big_bg_ten"
				{
					Size = Vector2(60, 105),
					Location = Vector2(0, 0),
					BackgroundColor = ARGB(255, 255, 255, 255),
				},
				Gui.Control "big_ten"
				{
					Size = Vector2(60, 105 * (4+97)/105),
					Location = Vector2(0, 105 * (1 - (4+97)/105)),
					BackgroundColor = ARGB(255, 255, 255, 255),
				},
			},
		},
	}
}

function ShowPveCard(num)
	card_pve_window_ui.ctrl_popup_card_container:OnDestroy()
	for i = 1, num do
		local newcard = SpawnBossPveCard("",i)
		BossPveCard[i] = newcard
		newcard.card.Parent = card_pve_window_ui.ctrl_popup_card_container
	end
	
	card_pve_window = ModalWindow.GetNew()
	card_pve_window.root.Size = Vector2(1200,1200)
	card_pve_window.screen.AllowEscToExit = false
	
	card_pve_window_ui.ctrl_popup_card_window.Parent = card_pve_window.root
	FillBossGet()
end

function FillBossGet()
	if PveAwards_page > 0 then
		for i = 1 + ( PveAwards_page - 1 ) * 4 , 4 + ( PveAwards_page - 1 ) * 4 do
			local New = ptr_cast(card_pve_window_ui.ctrl_boss_get_container:GetChildByIndex((i-1)%4))
			New:OnDestroy()
			if New and PveAwards_data[i] then
				New.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..PveAwards_data[i].name..".tga")
				L_Characters.CreatPresentNumCtr(New,PveAwards_data[i].item_num,111,111)
			else
				New.ItemIcon = nil
			end
		end
	end	
end

function InitHead(ltv)
    ltv:DeleteAll()
    ltv:AddColumn("",37)
    ltv:AddColumn("",40)
    ltv:AddColumn(lang:GetText("排名"),72)
    ltv:AddColumn("",53)
    ltv:AddColumn("",14)
    ltv:AddColumn("",14)
    ltv:AddColumn(lang:GetText("玩家"),152)
    ltv:AddColumn(lang:GetText("积分"),95)
    ltv:AddColumn(lang:GetText("击杀/死亡"),130)
    ltv:AddColumn(lang:GetText("助攻"),84)
	ltv:AddColumn("",18)
    ltv:AddColumn("",18)
    ltv:AddColumn("",18)
    ltv:AddColumn("",18)
    ltv:AddColumn("",18)
    ltv:AddColumn("",18)
    ltv:AddColumn("",46)
    ltv:AddColumn("",20)
    local header = ltv.Columns
    header:SetAlign(0,"kAlignCenterMiddle")
    header:SetAlign(1,"kAlignCenterMiddle")
    header:SetAlign(2,"kAlignCenterMiddle")
    header:SetAlign(3,"kAlignLeftMiddle")
    header:SetAlign(4,"kAlignCenterMiddle")
    header:SetAlign(5,"kAlignCenterMiddle")
    header:SetAlign(6,"kAlignCenterMiddle")
    header:SetAlign(7,"kAlignCenterMiddle")
    header:SetAlign(8,"kAlignCenterMiddle")
    header:SetAlign(9,"kAlignCenterMiddle")
	header:SetAlign(10,"kAlignCenterMiddle")
    header:SetAlign(11,"kAlignCenterMiddle")
    header:SetAlign(12,"kAlignCenterMiddle")
    header:SetAlign(13,"kAlignCenterMiddle")
    header:SetAlign(14,"kAlignCenterMiddle")
    header:SetAlign(15,"kAlignCenterMiddle")
    header:SetAlign(16,"kAlignCenterMiddle")
    header:SetAlign(17,"kAlignCenterMiddle")
end

function InitBossPveHead(ltv)
    ltv:DeleteAll()
    ltv:AddColumn("",37)
    ltv:AddColumn("",40)
    ltv:AddColumn(lang:GetText("排名"),72)
    ltv:AddColumn("",53)
    ltv:AddColumn("",14)
    ltv:AddColumn("",14)
    ltv:AddColumn(lang:GetText("玩家"),152)
    ltv:AddColumn(lang:GetText("积分"),95)
    ltv:AddColumn(lang:GetText("造成的伤害"),100)
    ltv:AddColumn(lang:GetText("复活币"),104)
	ltv:AddColumn("",18)
    ltv:AddColumn("",18)
    ltv:AddColumn("",18)
    ltv:AddColumn("",18)
    ltv:AddColumn("",18)
    ltv:AddColumn("",18)
    ltv:AddColumn("",20)
    ltv:AddColumn("",119)
    local header = ltv.Columns
    header:SetAlign(0,"kAlignCenterMiddle")
    header:SetAlign(1,"kAlignCenterMiddle")
    header:SetAlign(2,"kAlignCenterMiddle")
    header:SetAlign(3,"kAlignLeftMiddle")
    header:SetAlign(4,"kAlignCenterMiddle")
    header:SetAlign(5,"kAlignCenterMiddle")
    header:SetAlign(6,"kAlignCenterMiddle")
    header:SetAlign(7,"kAlignCenterMiddle")
    header:SetAlign(8,"kAlignCenterMiddle")
    header:SetAlign(9,"kAlignCenterMiddle")
	header:SetAlign(10,"kAlignCenterMiddle")
    header:SetAlign(11,"kAlignCenterMiddle")
    header:SetAlign(12,"kAlignCenterMiddle")
    header:SetAlign(13,"kAlignCenterMiddle")
    header:SetAlign(14,"kAlignCenterMiddle")
    header:SetAlign(15,"kAlignCenterMiddle")
    header:SetAlign(16,"kAlignCenterMiddle")
    header:SetAlign(17,"kAlignCenterMiddle")
end

---------------创建新buff---------------
function SpawnNewBuff(data)
	local BuffCon = Gui.Create(gui)
				{
					Gui.Label "LBuff"
					{
						Size = Vector2(16,16),
						BackgroundColor = ARGB(255,255,255,255),
				
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/persionalInfo/buff/buff_ammo_up_60.dds", Vector4(0, 0, 0, 0)),
						},

					},	
				}
	
	BuffCon.LBuff.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/persionalInfo/buff/buff_"..data[1]..".dds", Vector4(0, 0, 0, 0)),}
	return BuffCon
end

function AddItemTest(ltv)
	for i = 1, 20 do
		local sub_item = ltv:AddItem(ltv.RootItem)
		if i % 2 == 0 then
          	sub_item.BGSkin = Skin.ListItemSkin_Double
          else
          	sub_item.BGSkin = Skin.ListItemSkin_Single
          end
          
          sub_item:AddSubItem("")
		sub_item:AddSubItem("")
		sub_item:AddSubItem("")
	end
end

function AddRemainItem(counter,AllNum,list_tree)	
	local RemainItem = AllNum-counter
	local list = list_tree
    
	if RemainItem > 0 then
		for j=counter,AllNum do
			local root = list.RootItem
			local item = list:AddItem(root)
       	
			item.CanSelect = false
			if j %2 == 0 then
				item.BGSkin = Skin.ListItemSkin_Single
			else
				item.BGSkin = Skin.ListItemSkin_Double
			end
		end
	end
end

function Calulatebits(number)
	local bit = 0
	while number > 0 do
		number = number / 10
		number = math.floor(number)
		bit = bit + 1
	end
	
	if bit == 0 then
		bit = 1
	end
	
	return bit
end

function DrawBossOrZombieLevel()
	local level1 = L_LobbyMain.PersonalInfo_data.level % 10 --等级个位
	local level2 = (L_LobbyMain.PersonalInfo_data.level - level1) / 10 --等级十位
	local preson_level = math.floor((L_LobbyMain.PersonalInfo_data.level-1)/5)
	local percent
	if L_LobbyMain.PersonalInfo_data.level == 80 then
		percent = 1
	else
		percent = (L_LobbyMain.PersonalInfo_data.exp - L_LobbyMain.LevelInfo_rpc_data[L_LobbyMain.PersonalInfo_data.level][2]) / (L_LobbyMain.LevelInfo_rpc_data[L_LobbyMain.PersonalInfo_data.level + 1][2] - L_LobbyMain.LevelInfo_rpc_data[L_LobbyMain.PersonalInfo_data.level][2]) 
		percent = string.format("%.2f", percent)
	end
	popup_card_window_ui.ctrl_popup_card_bg.Skin = Gui.ControlSkin
	{
		BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_exp_ico_" ..preson_level..".dds",Vector4(0, 0, 0, 0)),
	}
	
	popup_card_window_ui.big_bg_one.Skin = Gui.ControlSkin
	{
		BackgroundImage = Gui.Image("InGameUI/lb_summary_number_6.dds",Vector4(0, 0, 0, 0),Vector4(level1 / 10, 0, (level1 + 1) / 10, 1)),
	}
	popup_card_window_ui.big_one.Skin = Gui.ControlSkin
	{
		BackgroundImage = Gui.Icon("LobbyUI/WarZone/lb_summary_number_7.dds",Vector4(0, 0, 0, 0),Vector4(level1 / 10, 1 - (4 + percent * 112) / 120, (level1 + 1) / 10, 1.0)),
	}
	popup_card_window_ui.big_one.Size = Vector2(60, 105 * ( 4 + percent * 97) / 105)
	popup_card_window_ui.big_one.Location = Vector2(0, 105 * (1 - ( 4 + percent * 97) / 105))
	popup_card_window_ui.big_bg_ten.Skin = Gui.ControlSkin
	{
		BackgroundImage = Gui.Image("InGameUI/lb_summary_number_6.dds",Vector4(0, 0, 0, 0),Vector4(level2 / 10, 0, (level2 + 1) / 10, 1)),
	}
	popup_card_window_ui.big_ten.Skin = Gui.ControlSkin
	{
		BackgroundImage = Gui.Icon("LobbyUI/WarZone/lb_summary_number_7.dds",Vector4(0, 0, 0, 0),Vector4(level2 / 10, 1 - ( 4 + percent * 112) / 120, (level2 + 1) / 10, 1.0)),
	}
	popup_card_window_ui.big_ten.Size = Vector2(60, 105 * ( 4 + percent * 97) / 105)
	popup_card_window_ui.big_ten.Location = Vector2(0, 105 * (1 - ( 4 + percent * 97) / 105))
end

function DrawBossPveLevel()
	local level1 = L_LobbyMain.PersonalInfo_data.level % 10 --等级个位
	local level2 = (L_LobbyMain.PersonalInfo_data.level - level1) / 10 --等级十位
	local preson_level = math.floor((L_LobbyMain.PersonalInfo_data.level-1)/5)
	local percent
	if L_LobbyMain.PersonalInfo_data.level == 80 then
		percent = 1
	else
		percent = (L_LobbyMain.PersonalInfo_data.exp - L_LobbyMain.LevelInfo_rpc_data[L_LobbyMain.PersonalInfo_data.level][2]) / (L_LobbyMain.LevelInfo_rpc_data[L_LobbyMain.PersonalInfo_data.level + 1][2] - L_LobbyMain.LevelInfo_rpc_data[L_LobbyMain.PersonalInfo_data.level][2]) 
		percent = string.format("%.2f", percent)
	end
	card_pve_window_ui.ctrl_popup_card_bg.Skin = Gui.ControlSkin
	{
		BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_exp_ico_" ..preson_level..".dds",Vector4(0, 0, 0, 0)),
	}
	
	card_pve_window_ui.big_bg_one.Skin = Gui.ControlSkin
	{
		BackgroundImage = Gui.Image("InGameUI/lb_summary_number_6.dds",Vector4(0, 0, 0, 0),Vector4(level1 / 10, 0, (level1 + 1) / 10, 1)),
	}
	card_pve_window_ui.big_one.Skin = Gui.ControlSkin
	{
		BackgroundImage = Gui.Icon("LobbyUI/WarZone/lb_summary_number_7.dds",Vector4(0, 0, 0, 0),Vector4(level1 / 10, 1 - (4 + percent * 112) / 120, (level1 + 1) / 10, 1.0)),
	}
	card_pve_window_ui.big_one.Size = Vector2(60, 105 * ( 4 + percent * 97) / 105)
	card_pve_window_ui.big_one.Location = Vector2(0, 105 * (1 - ( 4 + percent * 97) / 105))
	card_pve_window_ui.big_bg_ten.Skin = Gui.ControlSkin
	{
		BackgroundImage = Gui.Image("InGameUI/lb_summary_number_6.dds",Vector4(0, 0, 0, 0),Vector4(level2 / 10, 0, (level2 + 1) / 10, 1)),
	}
	card_pve_window_ui.big_ten.Skin = Gui.ControlSkin
	{
		BackgroundImage = Gui.Icon("LobbyUI/WarZone/lb_summary_number_7.dds",Vector4(0, 0, 0, 0),Vector4(level2 / 10, 1 - ( 4 + percent * 112) / 120, (level2 + 1) / 10, 1.0)),
	}
	card_pve_window_ui.big_ten.Size = Vector2(60, 105 * ( 4 + percent * 97) / 105)
	card_pve_window_ui.big_ten.Location = Vector2(0, 105 * (1 - ( 4 + percent * 97) / 105))
end

function DrawBossOrZombieInfo(self)
	local curr_gp = self[6]
	local add_eng = self[9]
	local add_exp = self[8]
	local EngAll = curr_gp+add_eng
	
	local ScrollAdd_exp = "0,"..add_exp
	local ScrollAdd_eng = "0,"..add_eng
	local ScrollAll_eng = curr_gp..","..EngAll
	
	
	total_turn_chance = self.get_chances.totalGet
	popup_card_window_ui.left_turncard_chance.Text = total_turn_chance
	popup_card_window_ui.chance_times.Text = lang:GetText("你总共获得了")..self.get_chances.totalGet..lang:GetText("次翻牌机会")
	popup_card_window_ui.scrollchance_base_get.Text = self.get_chances.gameGet
	popup_card_window_ui.scrollchance_vip.Text =  self.get_chances.vipGet
	popup_card_window_ui.scrollchance_cab.Text = self.get_chances.netBarGet
	popup_card_window_ui.scrollchance_activity.Text = self.get_chances.activityGet
	
	if self.get_chances.gameGet == 1 then
		popup_card_window_ui.card_1.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("InGameUI/bottom_info/ig_common_fanpai_card_1.dds", Vector4(0 , 0, 0, 0)),}
		flag[1] = 1
	elseif self.get_chances.gameGet == 2 then
		popup_card_window_ui.card_1.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("InGameUI/bottom_info/ig_common_fanpai_card_1.dds", Vector4(0 , 0, 0, 0)),}
		popup_card_window_ui.card_2.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("InGameUI/bottom_info/ig_common_fanpai_card_1.dds", Vector4(0 , 0, 0, 0)),}
		flag[1] = 1
		flag[2] = 1
	elseif self.get_chances.gameGet == 3 then
		popup_card_window_ui.card_1.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("InGameUI/bottom_info/ig_common_fanpai_card_1.dds", Vector4(0 , 0, 0, 0)),}
		popup_card_window_ui.card_2.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("InGameUI/bottom_info/ig_common_fanpai_card_1.dds", Vector4(0 , 0, 0, 0)),}
		popup_card_window_ui.card_3.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("InGameUI/bottom_info/ig_common_fanpai_card_1.dds", Vector4(0 , 0, 0, 0)),}
		flag[1] = 1
		flag[2] = 1
		flag[3] = 1
	end
	
	if self.get_chances.vipGet == 1 then
		popup_card_window_ui.card_4.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("InGameUI/bottom_info/ig_common_fanpai_card_1.dds", Vector4(0 , 0, 0, 0)),}
		flag[4] = 1
	end
	if self.get_chances.netBarGet == 1 then
		popup_card_window_ui.card_5.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("InGameUI/bottom_info/ig_common_fanpai_card_1.dds", Vector4(0 , 0, 0, 0)),}
		flag[5] = 1
	end
	if self.get_chances.activityGet == 1 then
		popup_card_window_ui.card_6.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("InGameUI/bottom_info/ig_common_fanpai_card_1.dds", Vector4(0 , 0, 0, 0)),}
		flag[6] = 1
	end
	
	popup_card_window_ui.ScrollScore:ClearAll()
	popup_card_window_ui.Scrollexp:ClearAll()
	popup_card_window_ui.Scrolleng:ClearAll()
	popup_card_window_ui.card_timer:ClearAll()
	
	popup_card_window_ui.ScrollScore:AddAnim("ScrollScore",0.5,8)
	popup_card_window_ui.Scrollexp:AddAnim("ScrollScore",0.5,8)
	popup_card_window_ui.Scrolleng:AddAnim("ScrollScore",0.5,8)
	popup_card_window_ui.card_timer:AddAnim("timer",1,3)
	
	bit = Calulatebits(self[10])
	
	popup_card_window_ui.scrollexp_base_get.Text = self.get_exps.gameGet
	popup_card_window_ui.scrollexp_vip.Text = self.get_exps.vipGet.."%"
	popup_card_window_ui.scrollexp_cab.Text = self.get_exps.netBarGet.."%"
	popup_card_window_ui.scrollexp_activity.Text = self.get_exps.activityGet.."%"
	popup_card_window_ui.scrollexp_battle.Text = self.get_exps.teamAdd.."%"
	popup_card_window_ui.scrollexp_daoju.Text = self.get_exps.itemAdd.."%"
	
	
	popup_card_window_ui.scrolleng_base_get.Text = self.get_gps.gameGet
	popup_card_window_ui.scrolleng_vip.Text = self.get_gps.vipGet.."%"
	popup_card_window_ui.scrolleng_cab.Text = self.get_gps.netBarGet.."%"
	popup_card_window_ui.scrolleng_activity.Text = self.get_gps.activityGet.."%"
	popup_card_window_ui.scrolleng_battle.Text = self.get_gps.teamAdd.."%"
	popup_card_window_ui.scrolleng_daoju.Text = self.get_gps.itemAdd.."%"
	
	
	local cardback =  Gui.Image("InGameUI/lb_summary_number_l_1.dds", Vector4(0,0,0,0))
	local cardfront = Gui.Image("LobbyUI/summary_number_l_bg.dds")
	popup_card_window_ui.ScrollScore:AddFrame("ScrollScore",cardback,Vector4(0, 0, 0, 0))
	popup_card_window_ui.ScrollScore:AddFrame("ScrollScore",cardfront,Vector4(0, 0, 0, 0))
	popup_card_window_ui.ScrollScore:SetScrollParam("ScrollScore",self[10],bit + 1)
	popup_card_window_ui.ScrollScore.Size = Vector2((bit + 1) * 33,44)
	popup_card_window_ui.ScrollScore.Location = Vector2(471 - 33 * (bit + 2) -17 - 30,popup_card_window_ui.ScrollScore.Location.y)
	
	bit = Calulatebits(add_exp)
	popup_card_window_ui.Scrollexp:AddFrame("ScrollScore",cardback,Vector4(0, 0, 0, 0))
	popup_card_window_ui.Scrollexp:AddFrame("ScrollScore",cardfront,Vector4(0, 0, 0, 0))
	popup_card_window_ui.Scrollexp:SetScrollParam("ScrollScore",add_exp,bit + 1)
	popup_card_window_ui.Scrollexp.Size = Vector2((bit + 1) * 33,44)
	popup_card_window_ui.Scrollexp.Location = Vector2(471 - 33 * (bit + 2) -17 - 30,popup_card_window_ui.Scrollexp.Location.y)
	
	bit = Calulatebits(add_eng)
	popup_card_window_ui.Scrolleng:AddFrame("ScrollScore",cardback,Vector4(0, 0, 0, 0))
	popup_card_window_ui.Scrolleng:AddFrame("ScrollScore",cardfront,Vector4(0, 0, 0, 0))
	popup_card_window_ui.Scrolleng:SetScrollParam("ScrollScore",add_eng,bit + 1)
	popup_card_window_ui.Scrolleng.Size = Vector2((bit + 1) * 33,44)
	popup_card_window_ui.Scrolleng.Location = Vector2(471 - 33 * (bit + 2) -17 - 30,popup_card_window_ui.Scrolleng.Location.y)
	
	local i = 7
	while i >= 0 do
		num = Gui.Image("InGameUI/lb_summary_number_7.dds", Vector4(0,0,0,0),Vector4((i)/10.0 , 0, (i + 1)/10.0,1 ))
		popup_card_window_ui.card_timer:AddFrame("timer",num,Vector4(0, 0, 0, 0))
		i = i -1
	end
	
	popup_card_window_ui.card_timer:StartAnimation()
	popup_card_window_ui.Scrollexp:StartAnimation()
	popup_card_window_ui.ScrollScore:StartAnimation()
	popup_card_window_ui.Scrolleng:StartAnimation()
end

function DrawBossPveInfo(self)
	local curr_gp = self[6]
	local add_eng = self[9]
	local add_exp = self[8]
	local EngAll = curr_gp+add_eng
	
	local ScrollAdd_exp = "0,"..add_exp
	local ScrollAdd_eng = "0,"..add_eng
	local ScrollAll_eng = curr_gp..","..EngAll
	
	
	total_turn_chance = self.get_chances.totalGet
	card_pve_window_ui.left_turncard_chance.Text = total_turn_chance
	card_pve_window_ui.chance_times.Text = lang:GetText("你总共获得了")..self.get_chances.totalGet..lang:GetText("次翻牌机会")
	card_pve_window_ui.scrollchance_base_get.Text = self.get_chances.gameGet
	card_pve_window_ui.scrollchance_vip.Text =  self.get_chances.vipGet
	card_pve_window_ui.scrollchance_cab.Text = self.get_chances.netBarGet
	card_pve_window_ui.scrollchance_activity.Text = self.get_chances.activityGet
	
	card_pve_window_ui.ScrollScore:ClearAll()
	card_pve_window_ui.Scrollexp:ClearAll()
	card_pve_window_ui.Scrolleng:ClearAll()
	card_pve_window_ui.card_timer:ClearAll()
	
	card_pve_window_ui.ScrollScore:AddAnim("ScrollScore",0.5,8)
	card_pve_window_ui.Scrollexp:AddAnim("ScrollScore",0.5,8)
	card_pve_window_ui.Scrolleng:AddAnim("ScrollScore",0.5,8)
	card_pve_window_ui.card_timer:AddAnim("timer",1,3)
	
	bit = Calulatebits(self[10])
	
	card_pve_window_ui.scrollexp_base_get.Text = self.get_exps.gameGet
	card_pve_window_ui.scrollexp_vip.Text = self.get_exps.vipGet.."%"
	card_pve_window_ui.scrollexp_cab.Text = self.get_exps.netBarGet.."%"
	card_pve_window_ui.scrollexp_activity.Text = self.get_exps.activityGet.."%"
	card_pve_window_ui.scrollexp_battle.Text = self.get_exps.teamAdd.."%"
	card_pve_window_ui.scrollexp_daoju.Text = self.get_exps.itemAdd.."%"
	
	card_pve_window_ui.scrolleng_base_get.Text = self.get_gps.gameGet
	card_pve_window_ui.scrolleng_vip.Text = self.get_gps.vipGet.."%"
	card_pve_window_ui.scrolleng_cab.Text = self.get_gps.netBarGet.."%"
	card_pve_window_ui.scrolleng_activity.Text = self.get_gps.activityGet.."%"
	card_pve_window_ui.scrolleng_battle.Text = self.get_gps.teamAdd.."%"
	card_pve_window_ui.scrolleng_daoju.Text = self.get_gps.itemAdd.."%"
	
	
	local cardback =  Gui.Image("InGameUI/lb_summary_number_l_1.dds", Vector4(0,0,0,0))
	local cardfront = Gui.Image("LobbyUI/summary_number_l_bg.dds")
	card_pve_window_ui.ScrollScore:AddFrame("ScrollScore",cardback,Vector4(0, 0, 0, 0))
	card_pve_window_ui.ScrollScore:AddFrame("ScrollScore",cardfront,Vector4(0, 0, 0, 0))
	card_pve_window_ui.ScrollScore:SetScrollParam("ScrollScore",self[10],bit + 1)
	card_pve_window_ui.ScrollScore.Size = Vector2((bit + 1) * 33,44)
	card_pve_window_ui.ScrollScore.Location = Vector2(471 - 33 * (bit + 2) -17 - 30,card_pve_window_ui.ScrollScore.Location.y)
	
	bit = Calulatebits(add_exp)
	card_pve_window_ui.Scrollexp:AddFrame("ScrollScore",cardback,Vector4(0, 0, 0, 0))
	card_pve_window_ui.Scrollexp:AddFrame("ScrollScore",cardfront,Vector4(0, 0, 0, 0))
	card_pve_window_ui.Scrollexp:SetScrollParam("ScrollScore",add_exp,bit + 1)
	card_pve_window_ui.Scrollexp.Size = Vector2((bit + 1) * 33,44)
	card_pve_window_ui.Scrollexp.Location = Vector2(471 - 33 * (bit + 2) -17 - 30,card_pve_window_ui.Scrollexp.Location.y)
	
	bit = Calulatebits(add_eng)
	card_pve_window_ui.Scrolleng:AddFrame("ScrollScore",cardback,Vector4(0, 0, 0, 0))
	card_pve_window_ui.Scrolleng:AddFrame("ScrollScore",cardfront,Vector4(0, 0, 0, 0))
	card_pve_window_ui.Scrolleng:SetScrollParam("ScrollScore",add_eng,bit + 1)
	card_pve_window_ui.Scrolleng.Size = Vector2((bit + 1) * 33,44)
	card_pve_window_ui.Scrolleng.Location = Vector2(471 - 33 * (bit + 2) -17 - 30,card_pve_window_ui.Scrolleng.Location.y)
	
	local i = 7
	while i >= 0 do
		num = Gui.Image("InGameUI/lb_summary_number_7.dds", Vector4(0,0,0,0),Vector4((i)/10.0 , 0, (i + 1)/10.0,1 ))
		card_pve_window_ui.card_timer:AddFrame("timer",num,Vector4(0, 0, 0, 0))
		i = i -1
	end
	
	card_pve_window_ui.card_timer:StartAnimation()
	card_pve_window_ui.Scrollexp:StartAnimation()
	card_pve_window_ui.ScrollScore:StartAnimation()
	card_pve_window_ui.Scrolleng:StartAnimation()
end

function SetBalance(data)	
	print("in SetBalance")
	MessageBox.CloseWaiter()
	if data.warning then
		MessageBox.ShowWithTimer(1,data.warning)
		ptr_cast(game.CurrentState):Quit()
		return
	end
	
	----------成就列表---------------------------------
	local achievementlist = nil
	----------获得游戏类型，红方和蓝方数据--------------
	local game_type = data.type
	local team0 = data.team0
	local box,isVip
	----------获得本玩家和MVP信息-----------------------
	local self = nil	--本玩家信息
	local percentage = 0 
	local mvp_side = 0	--MVP信息
	local selfindex = 0
	local bufflist = nil
	local activity = data.activity
	local internetCafe,vipicon
	
	for _,v in ipairs(team0) do
		if v[2] == ptr_cast(game.CurrentState):GetMyClientInfo().name then
			self = v 
		end
		
		if v[2] == data.mvp[3] then
			mvp_side = v[3]
		end
	end
	
	-- if activity and activity > 1 then
		-- ui.DouExp.Visible = true
		-- ui.DouEng.Visible = true
	-- end
	
	if not self then
		MessageBox.ShowWithTimer(1,lang:GetText("本房间游戏已结束"))
		ptr_cast(game.CurrentState):Quit()
		return
	end
	

	if data.type ~= 10 then
		ui.list_player_rank.Visible = true
		ui.list_BossPve_rank.Visible = false
		ShowPopCard()
		DrawBossOrZombieLevel()
	else
		ui.list_player_rank.Visible = false
		ui.list_BossPve_rank.Visible = true
		PveCard_data = self.brands_list
		PveAwards_data = self.awards_list
		PveAwards_count  = self.awards_count
		PveAwards_pages = math.ceil(PveAwards_count/4)
		ShowPveCard(self.get_chances.totalGet)
		DrawBossPveLevel()
	end	

	local ltv
	local redteam = 0
	local blueteam = 0
	local counter = 0
	box = self.box
	isVip = self.isvip
	
	internetCafe = self.internetCafe
	print("isVip = ",isVip)
	print("internetCafe = ",internetCafe)

	ui.IconVipExp.Skin = Gui.ControlSkin{ BackgroundImage = Gui.Image("LobbyUI/vip/lb_"..isVip.."_ico_"..internetCafe..".dds", Vector4(0, 0, 0, 0)),}
	ui.IconVip.Skin = Gui.ControlSkin{ BackgroundImage = Gui.Image("LobbyUI/vip/lb_"..isVip.."_ico_"..internetCafe..".dds", Vector4(0, 0, 0, 0)),}
--	ui.IconVip1.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/vip/lb_"..isVip.."_ico_"..internetCafe..".dds", Vector4(0, 0, 0, 0)),}
--	ui.IconVip2.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/vip/lb_"..isVip.."_ico_"..internetCafe..".dds", Vector4(0, 0, 0, 0)),}
	ui.ctrl_vip.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/vip/lb_"..isVip.."_ico_"..internetCafe.."_big.dds", Vector4(0, 0, 0, 0)),}
	if isVip > 0 then
		ui.IconVipExp.Skin = Gui.ControlSkin{ BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_button_0"..isVip.."_normal.dds", Vector4(0, 0, 0, 0)),}
		ui.IconVip.Skin = Gui.ControlSkin{ BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_button_0"..isVip.."_normal.dds", Vector4(0, 0, 0, 0)),}
		-- ui.IconVip1.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_button_0"..isVip.."_normal.dds", Vector4(0, 0, 0, 0)),}
		-- ui.IconVip2.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_button_0"..isVip.."_normal.dds", Vector4(0, 0, 0, 0)),}
		ui.ctrl_vip.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_button_0"..isVip.."_normal.dds", Vector4(0, 0, 0, 0)),}
		ui.IconVipExp.Visible = true
		ui.IconVip.Visible = true
		-- ui.IconVip1.Visible = true
		-- ui.IconVip2.Visible = true
		ui.ctrl_vip.Visible = true
	else
		ui.IconVipExp.Visible = false
		ui.IconVip.Visible = false
		-- ui.IconVip1.Visible = false
		-- ui.IconVip2.Visible = false
		ui.ctrl_vip.Visible = false
	end

	bufflist = self.buff_list
	
	-- if bufflist then
		-- for i,v in ipairs(bufflist) do
			-- local buffInfo = SpawnNewBuff(v)
			-- buffInfo.LBuff.Parent = ui.buff_layout
		-- end
	-- end
	
	for i,v in ipairs(team0) do
		print("in team0")
		local sub_item,percentage
		local rank,rankunit,rankdel,exp,icon1,icon2,headIcon
		local internetCafe
		local isvip,vipicon
		if data.type == 10 then
			ltv = ui.list_BossPve_rank
		else	
			ltv = ui.list_player_rank
		end
		sub_item = ltv:AddItem(ltv.RootItem)
			
		if self == v then
			sub_item.IsSelfItem = true
		end
		
		isvip = v.isvip
		print("isvip = ",isvip)
		if i % 2 == 0 then
          	sub_item.BGSkin = Skin.ListItemSkin_Double_balance
          	
          	if isvip ~= 0 then
          		sub_item.BGSkin = Skin.ListItemSkin_Double_Vip_Balance
          	end 
          else
          	sub_item.BGSkin = Skin.ListItemSkin_Single_balance
          	
          	if isvip ~= 0 then
          		sub_item.BGSkin = Skin.ListItemSkin_Single_Vip_Balance
          	end
          end
       	
       	local killandDead = v[11].."/" .. v[12]
		sub_item:SetText(2,i)
		sub_item:SetText(6,v[2])
		if data.type ~= 10 then
			sub_item:SetText(7,v[10])
			sub_item:SetText(8,killandDead)
			sub_item:SetText(9,v[15])
		else
			sub_item:SetText(7,v[10])
			sub_item:SetText(8,v[21])
			sub_item:SetText(9,v[27])
		end
		
		
		local bufflist = v.buff_list
		local buff_num = 0
		if bufflist then
			buff_num = table.getn(bufflist)
			for j,b in ipairs(bufflist) do
				if b and j <= 6 then
					local buffername = b[1]
					iconbuffer =  Gui.Icon("LobbyUI/persionalInfo/buff/buff_"..buffername..".dds", Vector4(0, 0, 0, 0))
					sub_item:SetIcon(9+j,iconbuffer)
				end
			end
		end
		if buff_num > 6 then
			sub_item:SetText(16,"......")
		end	
		
		rankunit = v[7]%10 + 1
		rankdel = (v[7] - rankunit + 1)/10
		
		exp = v[5] + v[8]
		rank = v[7]
		
		rankdel = rankdel +1
		
		if Level_data then
			percentage = (exp - Level_data[rank][2])/(Level_data[rank+1][2]-Level_data[rank][2])
		end
		
		
		icon2 =  Gui.Icon("LobbyUI/WarZone/lb_summary_number_7e.dds", Vector4(0, 0, 0, 0),Vector4((rankunit-1)/10.0,(1 - ((7 + percentage * 19) / 33)),(rankunit)/10,1.0))
		icon1 =  Gui.Icon("LobbyUI/WarZone/lb_summary_number_6e.dds", Vector4(0, 0, 0, 0),Vector4((rankunit-1)/10,0,(rankunit)/10,1))
		sub_item:SetIcon(5,icon1,icon2)
		
		icon2 = Gui.Icon("LobbyUI/WarZone/lb_summary_number_7e.dds", Vector4(0, 0, 0, 0),Vector4((rankdel-1)/10.0,(1 - ((7 + percentage * 19) / 33)),(rankdel)/10,1.0))
		icon1 =Gui.Icon("LobbyUI/WarZone/lb_summary_number_6e.dds", Vector4(0, 0, 0, 0),Vector4((rankdel-1)/10,0,(rankdel)/10,1))
		sub_item:SetIcon(4,icon1,icon2)
		local num = 5
		sub_item.LV_BackgroundImage = Gui.Image("LobbyUI/lv"..(math.floor((rank - 1)/num)*num+1).."-"..(math.ceil(rank/num)*num)..".dds", Vector4(0, 0, 0, 0), Vector4(0, 0, 1, 1))
		sub_item.LV_localtion = Vector2(198,0)
		sub_item.LV_Size = Vector2(33,30)

		if v.icon ~= "null" then
			headIcon = Gui.Icon("LobbyUI/persionalInfo/HeadPic/lb_battlefield_icon"..v.icon..".dds")
		end
		
		internetCafe = v.internetCafe
		if isvip > 0 then
			vipicon = Gui.Icon("LobbyUI/vip/vip/VIP_button_0"..isvip.."_normal.dds", Vector4(0, 0, 0, 0))
		else
			vipicon = nil
		end
		sub_item:SetIcon(1,vipicon)
		
		sub_item:SetIcon(3,headIcon)
		
		sub_item.CanSelect = false
		sub_item.ColCantSelect = true
		
		counter = i
	end
	
	if data.type == 10 then
		AddRemainItem(counter,16,ui.list_BossPve_rank)
		ui.ctrl_window_left_middle.Visible = false
		ui.ctrl_window_right_middle.Visible = false
	else	
		AddRemainItem(counter,16,ui.list_player_rank)
		ui.ctrl_window_left_middle.Visible = true
		ui.ctrl_window_right_middle.Visible = true
	end
	
	
	ui.ctrl_window_left_middle.ScrollNumRange = "0,"..data.police_score
	ui.ctrl_window_right_middle.ScrollNumRange = "0,"..data.terrorist_score
	
	ui.ctrl_window_left_middle:Reset()
	ui.ctrl_window_right_middle:Reset()
	
	-------------经验，能量----------------
	local exp,eng
	add_exp = self.playerTeamExp * (self.isTeamAdd + 1)
	cur_exp = self[5]
	add_eng = self.playerContribution * (self.isTeamAdd + 1)
	exp = self[8]+cur_exp
	
	if add_exp == -1 then
		ui.lbl_Battle_Full.Visible = true
	else
		ui.ctrl_get_experience_sc.ScrollNumRange = "0,"..add_exp
		ui.ctrl_get_energy_sc.ScrollNumRange = "0,"..add_eng	
		ui.ctrl_get_experience_sc:Reset()
		ui.ctrl_get_energy_sc:Reset()
		ui.lbl_Battle_Full.Visible = false
	end
	-- local exp,eng
	-- add_exp = self[8]
	-- cur_exp = self[5]
	-- add_eng = self[9]
	-- exp = add_exp+cur_exp
	
	-- ui.ctrl_get_experience_sc.ScrollNumRange = "0,0" --add_exp
	-- ui.ctrl_get_energy_sc.ScrollNumRange = "0,0" --..add_eng
	gui:PlayAudio("kUIA_GAME_WIN")
	
	----------------弹出窗口:个人经验-----------------------------
	local curr_rank = self[4]
	local rank = self[7]
	local AddedRank = rank - curr_rank
	local rankUnit = rank%10 + 1
	local rankDel = (rank - rankUnit + 1)/10
	rankDel = rankDel +1
	
	print("curr_rank=",curr_rank)
	print("rank=",rank)
	print("AddedRank=",AddedRank)
	
	local height = 37
	local YL = ui.ctrl_level_unit_m.Location.y+ui.ctrl_level_unit_m.Size.y
	
	local num = 5
	ui.ctrl_level_background.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/lv"..(math.floor((rank - 1)/num)*num+1).."-"..(math.ceil(rank/num)*num)..".dds", Vector4(0, 0, 0, 0), Vector4(0, 0, 1, 1)),}
	
	ui.ctrl_level_unit_m.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_summary_number_6e.dds", Vector4(0, 0, 0, 0),Vector4((rankUnit-1)/10,0,(rankUnit)/10,1)),}
	ui.ctrl_level_tens_m.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_summary_number_6e.dds", Vector4(0, 0, 0, 0),Vector4((rankDel-1)/10,0,(rankDel)/10,1)),}
	
	if Level_data then
		if rank == 80 then
			percentage = 1.0
		else
			percentage = (exp - Level_data[rank][2])/(Level_data[rank+1][2]-Level_data[rank][2])
		end
	end
	
	--ui.ctrl_get_All_popup.LevelRatio = Vector2(0,percentage)
	
	height = height*percentage
	YL = YL - height
	ui.ctrl_level_unit_m_front.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_summary_number_7e.dds", Vector4(0, 0, 0, 0),Vector4((rankUnit-1)/10.0,(1 - ((7 + percentage * 19) / 33)),(rankUnit)/10,1.0)),}
	ui.ctrl_level_tens_m_front.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_summary_number_7e.dds", Vector4(0, 0, 0, 0),Vector4((rankDel-1)/10.0,(1 - ((7 + percentage * 19) / 33)),(rankDel)/10,1.0)),}
	
	ui.ctrl_level_unit_m_front.Size = Vector2(15,(7 + percentage * 19))
	ui.ctrl_level_tens_m_front.Size = Vector2(15,(7 + percentage * 19))
	ui.ctrl_level_unit_m_front.Location = Vector2(280,(58 - percentage * 19))
	ui.ctrl_level_tens_m_front.Location = Vector2(265,(58 - percentage * 19))
	
	ui.lbl_user_name_top.Text = self[2]
	
	--ui.realScore.Text = self[10]
	
	----------------弹出窗口:能量-----------------------------
	if data.type ~= 10 then
		DrawBossOrZombieInfo(self)
	else
		DrawBossPveInfo(self)
	end	
	gui:PlayAudio("kUIA_CLOSE_TIME")
	
	if rank - curr_rank >= 1 and gui then
		 gui:PlayAudio("kUIA_LEVEL_UP")
	end
end

function AlignUI()
	if ui then
		Gui.Align(ui.ctrl_window_root, 0.5, 0.5)
	end
end

function InitParam()
	VipItemName = ""
	openwitchbox = -1
	BoxAndPrize = {-1,-1,-1,-1}
	timefinish = false
end

function Show()
	-- create_ui()
	InitParam()
	InitHead(ui.list_player_rank)
	InitBossPveHead(ui.list_BossPve_rank)
	--AddItemTest(ui.list_player_rank)
	AlignUI()
	
	Level_data = L_LobbyMain.LevelInfo_rpc_data
end

function Hide()

	if ui then
		ui.ctrl_window_root.Parent = nil
	end
end

-- 字符串分割
function Split(szFullString, szSeparator)
	local nFindStartIndex = 1
	local nSplitIndex = 1
	local nSplitArray = {}
	while true do
	   local nFindLastIndex = string.find(szFullString, szSeparator,nFindStartIndex)
	   if not nFindLastIndex then
		nSplitArray[nSplitIndex] = string.sub(szFullString, nFindStartIndex, string.len(szFullString))
		break
	   end
	   nSplitArray[nSplitIndex] = string.sub(szFullString, nFindStartIndex, nFindLastIndex - 1)
	   nFindStartIndex = nFindLastIndex + string.len(szSeparator)
	   nSplitIndex = nSplitIndex + 1
	end
	return nSplitArray
end