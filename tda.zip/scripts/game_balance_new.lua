module("L_GameBalance",package.seeall)

BoxScore = {-1,-1,-1,-1}
----------------------加载ICON----------------------------------------------------------

iconWin = Gui.Icon("LobbyUI/GameBalance/summary_win_ico.dds",Vector4(0, 0, 0, 0))

iconHeadButcher  = Icons.PlayerStatusIcons["Head"]
VipItemName  = ""
openwitchbox =  -1
BoxAndPrize  = {-1, -1,-1,-1}
BoxData = {}
timefinish = false
finish_box = false
total_turn_chance = 0
Card = {}
local itemID = {}
local itemName = {}
turn_allcard  =  {}
allcard_num = 0
turn_card = {}
card_num = 0
isTurncard = true
local flag = {0,0,0,0,0,0}
local vipCardTime = 0
local  game_type
local  game_map
local game_type_key =
{
	"kTeam",
	"kHoldPoint",
	"kPushVehicle",
	"kTeamDeathMatch",
	"kBoss",
	"kKnife",
	"kBomb",
	"kStreetBoy",
	"kZombie",
}
----------------------加载ICON end----------------------------------------------------------
local clock = os.clock

Level_data =  nil

function SaveReplay(f)
	ptr_cast(game.CurrentState):ReplaySave(f)
end

-- function create_ui()

ui = Gui.Create()
{
	Gui.Control "ctrl_window_root"
	{
		Size = Vector2(1182, 883),
		--Location = Vector2(276, 22),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Dock = "kDockCenter",
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/GameBalance/summary_bg1.dds", Vector4(20, 20, 20, 20)),
		},
		
		Gui.TimeControl "PopCloseTimer"
		{
			
			Size = Vector2(5,5),
			Dock = "kDockCenter",
			BackgroundColor = ARGB(0, 255, 255, 255),
			EventTimeOut = function(sender, e)
				if game_type ==18 or L_WarZone.IsMatchServer()  then
					print("game_type000000",game_type)
					card_pve_window:Close()
				elseif	game_type ==12 and game_map == 10 then
					card_pve_window:Close()
				else
					print("game_type111111",game_type)
					popup_card_window:Close()
					
				end
				
			end
		},
		Gui.Control "ctrl_window_left"
		{
			Size = Vector2(547, 789),
			Location = Vector2(15, 16),
			BackgroundColor = ARGB(0, 255, 255, 255),

			Gui.Control "ctrl_window_left_top"
			{
				Size = Vector2(546, 555),
				Location = Vector2(0, 0),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/GameBalance/summary_bg2.dds", Vector4(20, 20, 20, 20)),
				},
			
				--VIP标志
				Gui.Label "ctrl_vip"
				{
					Size = Vector2(40, 28),
					Location = Vector2(8, 23),
					BackgroundColor = ARGB(255,255,255,255),
				},
				
				Gui.Control "ctrl_level_background"
				{
					Size = Vector2(37, 33),
					Location = Vector2(50, 18),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/lv1-5.dds", Vector4(0, 0, 0, 0)),
					},
				},
				
				--等级十位
				Gui.Label "ctrl_level_tens_m"
				{
					Size = Vector2(15, 33),
					Location = Vector2(54, 18),
					BackgroundColor = ARGB(255,255,255,255),
					Visible = true,
				},
				
				Gui.Label "ctrl_level_tens_m_front"
				{
					Size = Vector2(15, 33),
					Location = Vector2(54, 18),
					BackgroundColor = ARGB(255,255,255,255),
					Visible = true,
				},
				
				--等级个位
				Gui.Label "ctrl_level_unit_m"
				{
					Size = Vector2(15, 33),
					Location = Vector2(70, 18),
					BackgroundColor = ARGB(255,255,255,255),
					Visible = true,
				},
				
				Gui.Label "ctrl_level_unit_m_front"
				{
					Size = Vector2(15, 33),
					Location = Vector2(70, 18),
					BackgroundColor = ARGB(255,255,255,255),
					Visible = true,
				},

				--玩家姓名
				Gui.Label "lbl_user_name_top"
				{
					Size = Vector2(261, 45),
					TextColor = ARGB(255,226,217,208),
					TextAlign = "kAlignLeftMiddle",
					Text = lang:GetText("我的名字"),
					FontSize = 20,
					Location = Vector2(100, 10),
					--BackgroundColor = ARGB(255, 0, 0, 255),
				},
				
				Gui.FlowLayout "buff_layout"
				{
					Location = Vector2(100,6),
					Size = Vector2(400,20),
					Direction = "kHorizontal",
					Align = "kAlignLeftMiddle",
					ControlAlign = "kAlignCenterMiddle",
					ControlSpace = 5,
				},
				
				--恭喜你
				Gui.Label "lbl_congratulate"
				{
					Size = Vector2(330, 22),
					TextColor = ARGB(255,254,211,78),
					Text = lang:GetText("恭喜你，获得了以下奖励！！！"),
					FontSize = 18,
					Location = Vector2(46, 51),
					--BackgroundColor = ARGB(255, 0, 0, 255),
				},
				
				----------------获得经验滚动条-----------------------------
				Gui.ScrollNumberButton "ctrl_get_experience_sc"
				{
					NumberGroundImage = Gui.Image("InGameUI/lb_summary_number_l_bg3.dds"),
					Size = Vector2(400,160),
					Location = Vector2(-10,0),
					BackgroundColor = ARGB(0, 255, 255, 255),
					ItemType = "numstyle1",
					ItemName = lang:GetText("战队经验"),
					ScrollNumRange = "0,0",
					ScrollTime = 5.0,
					--ItemType = "numstyle2#numstyle1#numstyle1#levelstyle",
					--ItemName = lang:GetText("获得经验#获得能量#我的总能量#None"),
					--ScrollNumRange = "0,10000@2000,1000@100,1000",
					--ItemVSpace = "0,0,0",
					--Level = Vector2(0,10),
					--LevelRatio = Vector2(0,0.5),
					
					Gui.Label "IconVipExp"
					{
						Size = Vector2(40,24),
						Location = Vector2(170,100),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Visible = false,
					},
					
					OnComplete = function()
						--ui.ctrl_get_experience_popup.Visible = true
						--ui.ctrl_get_experience_popup:Reset()
					end
				},

				----------------获得能量滚动条-----------------------------
				Gui.ScrollNumberButton "ctrl_get_energy_sc"
				{
					NumberGroundImage = Gui.Image("InGameUI/lb_summary_number_l_bg3.dds"),
					Size = Vector2(400,160),
					Location = Vector2(-10,50),
					BackgroundColor = ARGB(0, 255, 255, 255),
					ItemType = "numstyle2",
					ItemName = lang:GetText("战队贡献"),
					ScrollNumRange = "0,0",
					ScrollTime = 5.0,
					
					Gui.Label "IconVip"
					{
						Size = Vector2(40,24),
						Location = Vector2(170,100),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Visible = false,
					},
				},
				
				Gui.Label "lbl_Battle_Full"
				{
					Size = Vector2(305, 102),
					TextColor = ARGB(255,254,211,78),
					Text = lang:GetText("你今日获得的战队经验已达上限"),
					TextAlign = "kAlignCenterMiddle",
					FontSize = 18,
					Location = Vector2(35, 80),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("InGameUI/lb_summary_number_l_bg3.dds", Vector4(22, 22, 22, 22)),
					},
				},
				
				--胜败图标
				Gui.Control "ctrl_result"
				{
					Size = Vector2(208, 180),
					Location = Vector2(341, 11),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/GameBalance/summary_win_logo.dds", Vector4(0, 0, 0, 0)),
					},
				},
			
				--成就展示
				Gui.Control "ctrl_accomplishment_show"
				{
					Size = Vector2(521, 250),
					Location = Vector2(13, 186),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/GameBalance/summary_l_bg4.dds", Vector4(2, 2, 2, 2)),
					},
				},
				
				Gui.ListTreeView "list_accomplishment_show"
				{
					Location = Vector2(13, 186),
					Size = Vector2(565, 250),
					Style = "Gui.ListTreeViewWith_Nothing",
					ItemHeight = 50,
					FontSize = 18,
					TextColor = ARGB(255,216,217,208),
					UseFistColumn = true,
					UseColumnNum = 0,
					UseColFontSize = 18,
					UseColFontCol = ARGB(255, 215, 232, 227),
					--HeaderHeight = 50,
					--Margin = Vector4(10, 9, 10, 9),
					--TreeVisible = false,
					--AlwaysSelect = true,
					--HeaderHeight = 40,
					--VScrollBarDisplay = "kHide",
					--HeaderVisible = false,
				},
					
				--控制数
				Gui.Control "ctrl_help_show"
				{
					Size = Vector2(257, 100),
					Location = Vector2(13, 442),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/GameBalance/summary_l_bg5.dds", Vector4(0, 0, 0, 0)),
					},
				},
				
				Gui.ListTreeView "list_help_show"
				{
					Location = Vector2(10, 442),
					Size = Vector2(305, 100),
					Style = "Gui.ListTreeViewWith_Nothing",
					--Dock = "kDockFill",
					ItemHeight = 50,
					FontSize = 18,
					TextColor = ARGB(255,216,217,208),
					UseFistColumn = true,
					UseColumnNum = 0,
					UseColFontSize = 18,
					UseColFontCol = ARGB(255, 215, 232, 227),
					--Margin = Vector4(10, 9, 10, 9),
					--HeaderHeight = 50,
					--TreeVisible = false,
					--AlwaysSelect = true,
					--HeaderHeight = 40,
					--VScrollBarDisplay = "kHide",
					--HeaderVisible = false,
				},

				--助攻数
				Gui.Control "ctrl_kill_show"
				{
					Size = Vector2(257, 100),
					Location = Vector2(276, 442),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/GameBalance/summary_l_bg5.dds", Vector4(0, 0, 0, 0)),
					},
				},
				
				Gui.ListTreeView "list_kill_show"
				{
					Location = Vector2(274, 442),
					Size = Vector2(305, 100),
					Style = "Gui.ListTreeViewWith_VScroll",
					ItemHeight = 50,
					--Margin = Vector4(10, 9, 10, 9),
					--HeaderHeight = 50,
					--TreeVisible = false,
					--AlwaysSelect = true,
					--HeaderHeight = 40,
				     VScrollBarDisplay = "kHide",
					HeaderVisible = false,
					FontSize = 18,
					TextColor = ARGB(255,216,217,208),
					UseFistColumn = true,
					UseColumnNum = 0,
					UseColFontSize = 18,
					UseColFontCol = ARGB(255, 215, 232, 227),
				},
				
			},

			Gui.ShaderControl "ctrl_window_left_bottom"
			{
				Size = Vector2(547, 224),
				Location = Vector2(0, 561),
				BackgroundColor = ARGB(255, 255, 255, 255),
				ShaderPS = "control_anim",
				Skin = Gui.ShaderSkin
				{
					ResImage1 = Gui.Image("LobbyUI/effect/color.tga", Vector4(15, 15, 15, 15)),
					ResImage2 = Gui.Image("LobbyUI/effect/mask.dds", Vector4(15, 15, 15, 15)),
					ResImage3 = Gui.Image("LobbyUI/effect/strip.dds", Vector4(15, 15, 15, 15)),
				},
				
				--等级十位
				Gui.Control "ctrl_level_tens"
				{
					Size = Vector2(15, 33),
					Location = Vector2(165, 27),
					Visible = true,
					BackgroundColor = ARGB(255,255,255,255),
				},
				
				Gui.Control "ctrl_level_tens_front"
				{
					Size = Vector2(15, 33),
					Location = Vector2(165, 27),
					Visible = true,
					BackgroundColor = ARGB(255,255,255,255),
				},
				
				--等级个位
				Gui.Control "ctrl_level_unit"
				{
					Size = Vector2(15, 33),
					Location = Vector2(181, 27),
					Visible = true,
					BackgroundColor = ARGB(255,255,255,255),
				},
				
				Gui.Control "ctrl_level_unit_front"
				{
					Size = Vector2(15, 33),
					Location = Vector2(181, 27),
					Visible = true,
					BackgroundColor = ARGB(255,255,255,255),
				},

				--玩家姓名
				Gui.Label "lbl_user_name"
				{
					Size = Vector2(223, 25),
					Text = lang:GetText("我的名字"),
					FontSize = 16,
					Location = Vector2(203, 34),
					TextColor = ARGB(255,255,255,167),
					--BackgroundColor = ARGB(255, 0, 0, 255),
				},

				--玩家头像
				Gui.Control "ctrl_head_icon"
				{
					Size = Vector2(89, 103),
					Location = Vector2(436, 23),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/lb_info_image01.dds", Vector4(0, 0, 0, 0)),
					},
				},

				--武器图像
				Gui.Control "ctrl_weapon_icon"
				{
					Size = Vector2(174, 101),
					Location = Vector2(193, 75),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ibt_icon/rocketlauncher.tga", Vector4(0, 0, 0, 0)),
					},
				},

				--他最有爱的武器
				Gui.Label "lbl_user_weapon_info"
				{
					Size = Vector2(302, 25),
					Text = lang:GetText("他最有爱的武器"),
					TextAlign = "kAlignCenterMiddle",
					TextColor = ARGB(255,255,255,167),
					FontSize = 20,
					Location = Vector2(120, 170),
					--BackgroundColor = ARGB(255, 0, 0, 255),
				},

				--超级给力火箭筒
				Gui.Label "lbl_user_weapon_name"
				{
					Size = Vector2(302, 25),
					Text = lang:GetText("超级给力火箭筒 MK-11"),
					TextAlign = "kAlignCenterMiddle",
					TextColor = ARGB(255,255,255,167),
					FontSize = 20,
					Location = Vector2(120, 191),
					--BackgroundColor = ARGB(255, 0, 0, 255),
				},
				
				Gui.Control "c_user_weapon_level"
				{
					Size = Vector2(80, 80),
					Location = Vector2(70, 75),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = nil,
					},
				},
			},
		},

		Gui.Control "ctrl_window_right"
		{
			Size = Vector2(601, 785),
			Location = Vector2(566, 16),
			BackgroundColor = ARGB(0, 255, 255, 255),

			Gui.Control "ctrl_window_right"
			{
				Size = Vector2(640, 169),
				Location = Vector2(-19, 309),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/GameBalance/summary_bg3_m.dds", Vector4(38, 23, 38, 23)),
				},
				
				-----------------------分数滚动条-------------------------
 				Gui.ScrollNumberButton "ctrl_window_right_middle"
				{
					Size = Vector2(400, 180),
					Location = Vector2(185,-35),
					BackgroundColor = ARGB(0, 255, 255, 255),
					ItemType = "numstyle3",
					ItemName = "#None",
					ScrollNumRange = "0,0",
					ScrollTime = 100.0,
					--ItemType = "numstyle2#numstyle1#numstyle1#levelstyle",
					--ItemName = lang:GetText("获得经验#获得能量#我的总能量#None"),
					--ScrollNumRange = "0,10000@2000,1000@100,1000",
					--ItemVSpace = "0,0,0",
					--Level = Vector2(0,10),
					--LevelRatio = Vector2(0,0.5),
				},
				
				Gui.ScrollNumberButton "ctrl_window_left_middle"
				{
					Size = Vector2(400, 180),
					Location = Vector2(-105,-35),
					BackgroundColor = ARGB(0, 255, 255, 255),
					ItemType = "numstyle3",
					ItemName = "#None",
					ScrollNumRange = "0,0",
					ScrollTime = 100.0,
					--ItemType = "numstyle2#numstyle1#numstyle1#levelstyle",
					--ItemName = lang:GetText("获得经验#获得能量#我的总能量#None"),
					--ScrollNumRange = "0,10000@2000,1000@100,1000",
					--ItemVSpace = "0,0,0",
					--Level = Vector2(0,10),
					--LevelRatio = Vector2(0,0.5),
				},
				
				-----------------------分数滚动条 结束-------------------------
			},

			Gui.Control "ctrl_window_right_top"
			{
				Size = Vector2(601, 312),
				Location = Vector2(0, 0),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/GameBalance/summary_bg3_u.dds", Vector4(18, 18, 18, 18)),
				},

				Gui.Control "ctrl_window_right_top_bg"
				{
					Size = Vector2(570, 297),
					Location = Vector2(13, 13),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/GameBalance/summary_r_bg7.dds", Vector4(3, 3, 3, 3)),
					},
				},
				
				---------------红方玩家信息------------------------------
				Gui.ListTreeView "list_red_team_show"
				{
					Location = Vector2(9, 12),
					Size = Vector2(612, 299),
					Style = "Gui.ListTreeViewWith_VScroll",
					HeaderHeight = 35,
					ItemHeight = 33,
					VScrollBarDisplay = "kHide",
					TextColor = ARGB(255,226,217,208),
					TreeVisible = false,
					AlwaysSelect = true,
					HeadFontSize = 16,
					HeadFontColor = ARGB(255, 215, 232, 227),
					--Margin = Vector4(10, 9, 10, 9),
					--TreeVisible = false,
					--AlwaysSelect = true,
					--HeaderVisible = false,
				},
			},	
			
			Gui.Control "ctrl_window_right_bottom"
			{
				Size = Vector2(601, 310),
				Location = Vector2(0, 476),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/GameBalance/summary_bg3_d.dds", Vector4(18, 18, 18, 18)),
				},
				Gui.Control "ctrl_window_right_bottom_bg"
				{
					Size = Vector2(570, 297),
					Location = Vector2(13, 0),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/GameBalance/summary_r_bg7.dds", Vector4(3, 3, 3, 3)),
					},
				},
				
				---------------蓝方玩家信息------------------------------
				Gui.ListTreeView "list_blue_team_show"
				{
					Size = Vector2(612, 299),
					Style = "Gui.ListTreeViewWith_VScroll",
					Location = Vector2(9, -1),
					TextColor = ARGB(255,226,217,208),
					HeaderHeight = 35,
					ItemHeight = 33,
					TreeVisible = false,
					VScrollBarDisplay = "kHide",
					HeadFontSize = 16,
					HeadFontColor = ARGB(255, 215, 232, 227),
					--Margin = Vector4(10, 9, 10, 9),
					--TreeVisible = false,
					--AlwaysSelect = true,
					--HeaderHeight = 40,
					--HeaderVisible = false,
				},
			},
		},
		
		--保存截图
		Gui.Button "btn_save_picture"
		{
			Size = Vector2(114, 52),
			Location = Vector2(742, 810),
			Text = lang:GetText("保存截图"),
			TextColor = ARGB(255, 0, 0, 0),
			FontSize = 18,
			PushDown = false,
			
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_battlecreate_button_create1_normal.dds", Vector4(20, 20, 20, 20)),
				HoverImage = Gui.Image("LobbyUI/GameBalance/lb_battlecreate_button_create1_hover.dds", Vector4(20, 20, 20, 20)),
				DownImage = Gui.Image("LobbyUI/GameBalance/lb_battlecreate_button_create1_down.dds", Vector4(20, 20, 20, 20)),
				DisabledImage = Gui.Image("LobbyUI/GameBalance/lb_battlecreate_button_create1_disabled.dds", Vector4(20, 20, 20, 20)),
			},
			
			EventClick = function()
				ptr_cast(game.CurrentState):AutoPhoto()
			end
		},
		
		--保存录像
		Gui.Button "btn_save_camera"
		{
			Size = Vector2(114, 52),
			Location = Vector2(867, 810),
			Text = lang:GetText("保存录像"),
			TextColor = ARGB(255, 0, 0, 0),
			FontSize = 18,
			PushDown = false,
			-- Visible = false,
			
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_battlecreate_button_create1_normal.dds", Vector4(20, 20, 20, 20)),
				HoverImage = Gui.Image("LobbyUI/GameBalance/lb_battlecreate_button_create1_hover.dds", Vector4(20, 20, 20, 20)),
				DownImage = Gui.Image("LobbyUI/GameBalance/lb_battlecreate_button_create1_down.dds", Vector4(20, 20, 20, 20)),
				DisabledImage = Gui.Image("LobbyUI/GameBalance/lb_battlecreate_button_create1_disabled.dds", Vector4(20, 20, 20, 20)),
			},
			
			EventClick = function()
				--ptr_cast(game.CurrentState):AutoPhoto()
				local level_id = ptr_cast(game.CurrentState):GetSelfRoomInfo().option.level_id
				local level_info = ptr_cast(game.CurrentState):GetLevelInfoById(level_id) or ""
				local single_mode = ptr_cast(game.CurrentState):GetSelfRoomInfo().option.character_id or ""
				print("level_info.type = "..level_info.type)
				local text = os.date("%Y-%m-%d-%H-%M_")..level_info.type.."_"..level_info.show_name.."_"..single_mode
				MessageBox.ShowWithTimer(3,lang:GetText("录像已保存"))
				SaveReplay(text)
				ui.btn_save_camera.Enable = false
			end
		},

		--确定
		Gui.Button "btn_confirm"
		{
			Size = Vector2(114, 52),
			Location = Vector2(992, 810),
			Text = lang:GetText("确定"),
			TextColor = ARGB(255, 0, 0, 0),
			FontSize = 18,
			PushDown = false,
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_battlecreate_button_create1_normal.dds", Vector4(20, 20, 20, 20)),
				HoverImage = Gui.Image("LobbyUI/GameBalance/lb_battlecreate_button_create1_hover.dds", Vector4(20, 20, 20, 20)),
				DownImage = Gui.Image("LobbyUI/GameBalance/lb_battlecreate_button_create1_down.dds", Vector4(20, 20, 20, 20)),
				DisabledImage = Gui.Image("LobbyUI/GameBalance/lb_battlecreate_button_create1_disabled.dds", Vector4(20, 20, 20, 20)),
			},
			
			EventClick = function()
				turn_allcard = {}
				allcard_num = 0
				turn_card = {}
				card_num = 0
				isTurncard = true
				local flag = {0,0,0,0,0,0}
				ptr_cast(game.CurrentState):Quit()
				L_LobbyMain.LobbyMainWin.invite_Timer:Show()
			end
		},
		
		--------------------弹出窗口 获得经验滚动条-------------------------------
		Gui.ScrollNumberButton "ctrl_get_experience_popup"
		{
			NumberGroundImage = Gui.Image("InGameUI/lb_summary_number_l_bg3.dds"),
			BackGroundImage = Gui.Image("InGameUI/lb_summary_popup_bg01.dds"),
			Size = Vector2(600,450),
			Location = Vector2(280,150),
			BackgroundColor = ARGB(0, 255, 255, 255),
			ItemType = "numstyle1#levelstyle",
			ItemName = lang:GetText("获得经验#None"),
			ScrollNumRange = "0,0",
			ScrollTime = 200.0,
			ItemVSpace = "3",
			Visible = false,
			Level = Vector2(0,0),
			--ItemType = "numstyle1#numstyle2#numstyle2#levelstyle",
			--ItemName = lang:GetText("获得经验#获得能量#我的总能量#None"),
			--ScrollNumRange = "0,10000@2000,1000@100,1000",
			--ItemVSpace = "0,0,0",
			--Level = Vector2(0,10),
			--LevelRatio = Vector2(0,0.5),
			
			-----获得经验完成-----------
			OnComplete = function()
				
				--ui.ctrl_get_experience_popup.Visible = false
				--ui.ctrl_get_energy_popup.Visible = true
				--ui.ctrl_get_energy_popup:Reset()				
				--sleep(2)
			end
		},
		
		--------------------弹出窗口 获得能量滚动条-------------------------------
		Gui.ScrollNumberButton "ctrl_get_energy_popup"
		{
			NumberGroundImage = Gui.Image("InGameUI/lb_summary_number_l_bg3.dds"),
			BackGroundImage = Gui.Image("InGameUI/lb_summary_popup_bg01.dds"),
			Size = Vector2(600,450),
			Location = Vector2(280,150),
			BackgroundColor = ARGB(0, 255, 255, 255),
			ItemType = "numstyle2#numstyle2",
			ItemName = lang:GetText("获得能量#我的总能量#None"),
			ScrollNumRange = "0,0@0,0",
			ScrollTime = 200.0,
			ItemVSpace = "3,3,3",
			Visible = false,
			Gui.Button "ctrl_energy_popup_ok"
			{
				Size = Vector2(160, 60),
				Location = Vector2(220, 300),
				Text = lang:GetText("确定"),
				TextColor = ARGB(255,54,53,49),
				FontSize = 18,
				
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_b_hover.dds", Vector4(20, 20, 20, 20)),
					HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_b_hover.dds", Vector4(20, 20, 20, 20)),
					DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_b_down.dds", Vector4(20, 20, 20, 20)),
					DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_normal.dds", Vector4(20, 20, 20, 20)),
				},
				
				EventClick = function()
				
					--ui.ctrl_get_energy_popup.Visible = false
				end,
			}
		},
		
		Gui.AnimControl "CloseTimer"
		{
			Size = Vector2(50,16),
			Location = Vector2(325,15),
			BackgroundColor = ARGB(0, 255, 255, 255),
			TextColor = ARGB(127, 254, 251, 245),
			FontSize = 16,
			Visible = false,
			
			EventFinish = function()
				print("in AnimControl CloseTimer")
				ptr_cast(game.CurrentState):Quit()
			end
		},
		
		--------------------弹出窗口 所有滚动条-------------------------------
		Gui.ScrollNumberButton "ctrl_get_All_popup"
		{
			NumberGroundImage = Gui.Image("InGameUI/lb_summary_number_l_bg3.dds"),
			BackGroundImage = Gui.Image("InGameUI/lb_summary_popup_bg01.dds"),
			Size = Vector2(600,850),
			Location = Vector2(280,50),
			BackgroundColor = ARGB(0, 255, 255, 255),
			ItemType = "numstyle1#levelstyle#numstyle2#numstyle2",
			ItemName = lang:GetText("获得经验#None#获得能量#我的总能量"),
			ScrollTime = 200.0,
			ItemSpace = 40,
			ItemVSpace = "0,80,3",
			Visible = false,
			
			Gui.Label "IconVip1"
			{
				Size = Vector2(40,28),
				Location = Vector2(140,60),
				BackgroundColor = ARGB(255, 255, 255, 255),
			},
			
			Gui.Label "DouExp"
			{
				Size = Vector2(88, 36),
				Location = Vector2(170, 45),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Visible = false,
			},
					
			Gui.Label "IconVip2"
			{
				Size = Vector2(40,28),
				Location = Vector2(140,340),
				BackgroundColor = ARGB(255, 255, 255, 255),
			},
			
			Gui.Label "DouEng"
			{
				Size = Vector2(88, 36),
				Location = Vector2(170, 325),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Visible = false,
			},
			
			Gui.Control "Score"
			{
				Location = Vector2(50,430),
				Size = Vector2(500,370),
				BackgroundColor = ARGB(255, 255, 255, 255),
				
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("InGameUI/lb_summary_number_l_bg3.dds", Vector4(22, 22, 22, 22)),
				},
				
				Gui.Label "ScoreName"
				{
					Location = Vector2(10,25),
					Size = Vector2(100,50),
					BackgroundColor = ARGB(0, 255, 255, 255),
					TextAlign = "kAlignCenterMiddle",
					TextColor = ARGB(255,253,211,77),
					FontSize = 24,
					Text = lang:GetText("获得分数"),
				},
				
				Gui.Label "realScore"
				{
					Location = Vector2(330,25),
					Size = Vector2(90,50),
					BackgroundColor = ARGB(0, 255, 255, 255),
					TextAlign = "kAlignRightMiddle",
					TextColor = ARGB(255,253,211,77),
					FontSize = 30,
				},
				
				Gui.Label "Unit"
				{
					Location = Vector2(410,30),
					Size = Vector2(100,50),
					BackgroundColor = ARGB(0, 255, 255, 255),
					TextAlign = "kAlignCenterMiddle",
					TextColor = ARGB(255,253,211,77),
					FontSize = 20,
					Text = "PTS",
				},
				
				Gui.Label "line"
				{
					Location = Vector2(10,70),
					Size = Vector2(470,5),
					BackgroundColor = ARGB(255, 255, 255, 255),
					
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_line01.dds", Vector4(14, 14, 14, 14)),
					},
				},
				
				Gui.Label "Gethortation"
				{
					Location = Vector2(10,80),
					Size = Vector2(100,50),
					BackgroundColor = ARGB(0, 255, 255, 255),
					TextAlign = "kAlignCenterMiddle",
					TextColor = ARGB(255,253,211,77),
					FontSize = 24,
					Text = lang:GetText("获得奖励"),
				},	
				
				Gui.AnimControl "Box1"
				{
					Location = Vector2(10,130),
					Size = Vector2(112,94),
					BackgroundColor = ARGB(255, 255, 255, 255),
					
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_summary_treasure_bg_normal.dds", Vector4(0, 0, 0, 0)),
						HoverImage = Gui.Image("LobbyUI/GameBalance/lb_summary_treasure_bg_hover.dds", Vector4(0, 0, 0, 0)),
						DownImage = Gui.Image("LobbyUI/GameBalance/lb_summary_treasure_bg_down.dds", Vector4(0, 0, 0, 0)),
					},
					
					EventClick = function(Sender,e)
						--[[
						print("in box1 EventClick")
						print("BoxAndPrize[1]",BoxAndPrize[1])					
						if openwitchbox < 0 then
							for i = 1,4 do
								if BoxAndPrize[i] > 0 and BoxAndPrize[i] <= 4 then
									timefinish = true
									ui.ATimer.Visible = false
									ui.TimerText.TextColor = ARGB(255,216,217,208)
									ui.TimerText.Text = lang:GetText("你可前往仓库查收")
									ui.OK.Visible = true
									
									openwitchbox = i
									OpenBox(BoxData[i])
								end	
							end
						end
						]]
					end
							
				},
				
				Gui.AnimControl "Box2"
				{
					Location = Vector2(132,130),
					Size = Vector2(112,94),
					BackgroundColor = ARGB(255, 255, 255, 255),
					
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_summary_treasure_bg_normal.dds", Vector4(0, 0, 0, 0)),
						HoverImage = Gui.Image("LobbyUI/GameBalance/lb_summary_treasure_bg_hover.dds", Vector4(0, 0, 0, 0)),
						DownImage = Gui.Image("LobbyUI/GameBalance/lb_summary_treasure_bg_down.dds", Vector4(0, 0, 0, 0)),
					},
					
					EventClick = function(Sender,e)
					--[[
						print("in box2 EventClick")
						print("BoxAndPrize[2]",BoxAndPrize[2])
						if openwitchbox < 0 then
							for i = 1,4 do
								if BoxAndPrize[i] > 0 and BoxAndPrize[i] <= 4 then
									timefinish = true
									ui.ATimer.Visible = false
									ui.TimerText.TextColor = ARGB(255,216,217,208)
									ui.TimerText.Text = lang:GetText("你可前往角色管理界面查收")
									ui.OK.Visible = true
									
									openwitchbox = i
									OpenBox(BoxData[i])
								end	
							end
						end
					]]
					end
				},
				
				Gui.AnimControl "Box3"
				{
					Location = Vector2(254,130),
					Size = Vector2(112,94),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_summary_treasure_bg_normal.dds", Vector4(0, 0, 0, 0)),
						HoverImage = Gui.Image("LobbyUI/GameBalance/lb_summary_treasure_bg_hover.dds", Vector4(0, 0, 0, 0)),
						DownImage = Gui.Image("LobbyUI/GameBalance/lb_summary_treasure_bg_down.dds", Vector4(0, 0, 0, 0)),
					},
					
					EventClick = function(Sender,e)
					--[[
						print("in box3 EventClick")
						print("BoxAndPrize[3]",BoxAndPrize[3])
						if openwitchbox < 0 then
							for i = 1,4 do
								if BoxAndPrize[i] > 0 and BoxAndPrize[i] <= 4 then
									timefinish = true
									ui.ATimer.Visible = false
									ui.TimerText.TextColor = ARGB(255,216,217,208)
									ui.TimerText.Text = lang:GetText("你可前往角色管理界面查收")
									ui.OK.Visible = true
									
									openwitchbox = i
									OpenBox(BoxData[i])
								end	
							end
						end
					]]
					end
				},
				
				Gui.AnimControl "Box4"
				{
					Location = Vector2(376,130),
					Size = Vector2(112,94),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_summary_treasure_bg_normal.dds", Vector4(0, 0, 0, 0)),
						HoverImage = Gui.Image("LobbyUI/GameBalance/lb_summary_treasure_bg_hover.dds", Vector4(0, 0, 0, 0)),
						DownImage = Gui.Image("LobbyUI/GameBalance/lb_summary_treasure_bg_down.dds", Vector4(0, 0, 0, 0)),
					},
				
					EventClick = function(Sender,e)
					--[[
						print("in box4 EventClick")
						print("BoxAndPrize[4]",BoxAndPrize[4])
						if openwitchbox < 0 then
							for i = 1,4 do
								if BoxAndPrize[i] > 0 and BoxAndPrize[i] <= 4 then
									timefinish = true
									ui.ATimer.Visible = false
									ui.TimerText.TextColor = ARGB(255,216,217,208)
									ui.TimerText.Text = lang:GetText("你可前往角色管理界面查收")
									ui.OK.Visible = true
									
									openwitchbox = i
									OpenBox(BoxData[i])
								end	
							end
						end
					]]--
					end
				},
				
				Gui.Control "cTimer"
				{
					Size = Vector2(480,135),
					Location = Vector2(10,230),
					BackgroundColor = ARGB(255, 255, 255, 255),
					
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_summary_treasure_bg02.dds", Vector4(8, 0, 8, 0)),
					},
					
					Gui.Label "TimerText"
					{
						Size = Vector2(432,40),
						Location = Vector2(0,0),
						TextAlign = "kAlignCenterMiddle",
						TextColor = ARGB(255,255,211,78),
						FontSize = 24,
						Text = lang:GetText("请在   秒内选择宝箱"),
						Visible = false,
					},
										
					Gui.AnimControl "ATimer"
					{
						Size = Vector2(33,50),
						Location = Vector2(148,-5),
						BackgroundColor = ARGB(0, 255, 255, 255),
						Visible = false,
						
						EventFinish = function(Sender,e)
						--[[
							print("in EventFinish")
							local boxopen = false
							local vidindex = -1
							local vipbox
							timefinish = true
							ui.OK.Visible = true
							local usebox
							if openwitchbox < 0 then
								
								for i = 1,4 do
									if BoxAndPrize[i] > 0 and BoxAndPrize[i] <= 4 then
										timefinish = true
										ui.ATimer.Visible = false
										ui.TimerText.TextColor = ARGB(255,216,217,208)
										ui.TimerText.Text = lang:GetText("你可前往角色管理界面查收")
										ui.OK.Visible = true
										
										openwitchbox = i
										OpenBox(BoxData[i])
									end	
								end
								
								ui.OK.Visible = true
								ui.ATimer.Visible = false
								ui.TimerText.TextColor = ARGB(255,216,217,208)
								ui.TimerText.Text = lang:GetText("你可前往角色管理界面查收")
							end
							]]
						end
						
					},
				},
				
			},
				
			Gui.Button "OK"
			{
				Size = Vector2(120,50),
				Location = Vector2(240,720),
				Text = lang:GetText("确定"),
				TextColor = ARGB(255,54,53,49),
				FontSize = 18,
				
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_b_hover.dds", Vector4(20, 20, 20, 20)),
					HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_b_hover.dds", Vector4(20, 20, 20, 20)),
					DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_b_down.dds", Vector4(20, 20, 20, 20)),
					DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_normal.dds", Vector4(20, 20, 20, 20)),
				},
				
				EventClick = function()
					finish_box = true
					ui.ctrl_get_All_popup.Visible = false
				end
			},
			
			OnComplete = function()
				
			end
		},
	},
}

function create_xiaohao_item(index)
	return 	Gui.Control ("xiaohao"..index)
	{
		Size = Vector2(111, 78),
		BackgroundColor = ARGB(0, 255, 255, 255),
		
		Gui.ItemBoxBtn ("pic"..index)
		{
			Size = Vector2(81, 78),
			Location = Vector2(0,0),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Empty = false,
			LoadingImage = Gui.AnimatedImage("LobbyUI/loading_ring.tga", 4, 2, 8),
			Type = 1,
			Skin = Gui.ItemBoxBtnSkin
			{
				NeutralNormalImage = Gui.Image("LobbyUI/GameBalance/TD/ig_js_bg_gouwuche2_normal.dds", Vector4(10, 10, 10, 10)),
				NeutralHoverImage = Gui.Image("LobbyUI/GameBalance/TD/ig_js_bg_gouwuche2_hover.dds", Vector4(10, 10, 10, 10)),
				NeutralSelectedImage = Gui.Image("LobbyUI/GameBalance/TD/ig_js_bg_gouwuche2_down.dds", Vector4(10, 10, 10, 10)),
				NeutralDisabledImage = Gui.Image("LobbyUI/GameBalance/TD/ig_js_bg_gouwuche2_normal.dds", Vector4(10, 10, 10, 10)),
			},
			
			EventSelected = function(sender, e)
				if index < 16 then
					for i = 1,15 do
						if TD_ui["pic"..i] then
							if i == index then
								TD_ui["pic"..i].Selected = true
							else
								TD_ui["pic"..i].Selected = false
							end
						end
					end
				else
					for i = 16,30 do
						if TD_ui["pic"..i] then
							if i == index then
								TD_ui["pic"..i].Selected = true
							else
								TD_ui["pic"..i].Selected = false
							end
						end
					end
				end
			end,
			EventMouseEnter = function(sender, e)

			end,
			EventToolTipsShow = function(sender, e)

			end,
			EventMouseLeave = function(sender, e)

			end,
		},
		Gui.Label ("l_num"..index)
		{
			Size = Vector2(30, 25),
			Location = Vector2(84, 38),
			Text = "",
			BackgroundColor = ARGB(0, 255, 255, 255),
			TextAlign = "kAlignCenterMiddle",
			FontSize = 20,
			TextColor = ARGB(255, 226, 217, 208),
		},
	}
end

TD_ui = Gui.Create()
{
	Gui.Control "ctrl_window_root"
	{
		Size = Vector2(1065, 890),
		--Location = Vector2(276, 22),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Dock = "kDockCenter",
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/GameBalance/summary_bg1.dds", Vector4(20, 20, 20, 20)),
		},
		Gui.Control "red"
		{
			Size = Vector2(1021, 364),
			Location = Vector2(23, 17),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/GameBalance/TD/ig_js_bg3.dds", Vector4(20, 20, 20, 20)),
			},
			Gui.Control
			{
				Size = Vector2(48, 29),
				Location = Vector2(19, 15),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/GameBalance/TD/ig_js_red.dds", Vector4(0, 0, 0, 0)),
				},
			},
			Gui.Label "red_get"
			{
				Size = Vector2(500, 30),
				Text = lang:GetText("进攻方获得：    88888888"),
				FontSize = 30,
				TextColor = ARGB(255, 255, 211, 78),
				Location = Vector2(411, 20),
				TextAlign = "kAlignLeftMiddle",
			},
			Gui.Control "res_icon_red"
			{
				Size = Vector2(30, 30),
				Location = Vector2(350, 18),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/lb_icon_res_02.dds", Vector4(0, 0, 0, 0)),
				},
			},
			Gui.Control
			{
				Size = Vector2(997, 33),
				Location = Vector2(13, 51),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/GameBalance/TD/ig_js_bg5.dds", Vector4(0, 0, 0, 0)),
				},
				Gui.Label
				{
					Size = Vector2(200, 33),
					Text = lang:GetText("玩家昵称"),
					FontSize = 18,
					TextColor = ARGB(255, 215, 232, 227),
					Location = Vector2(105, 0),
					TextAlign = "kAlignCenterMiddle",
				},
				Gui.Label
				{
					Size = Vector2(220, 33),
					Text = lang:GetText("进攻方消耗"),
					FontSize = 18,
					TextColor = ARGB(255, 215, 232, 227),
					Location = Vector2(572, 0),
					TextAlign = "kAlignCenterMiddle",
				},
			},
			Gui.ListTreeView "list_red_team_show"
			{
				Location = Vector2(13, 84),
				Size = Vector2(424, 264),
				Style = "Gui.ListTreeViewWith_VScroll",
				ItemHeight = 33,
				VScrollBarDisplay = "kHide",
				HeaderVisible = false,
				TextColor = ARGB(255,226,217,208),
				TreeVisible = false,
				AlwaysSelect = true,
			},
			Gui.Control
			{
				Size = Vector2(596, 86),
				Location = Vector2(407, 86),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/GameBalance/TD/ig_js_bg6.dds", Vector4(20, 20, 20, 20)),
				},
				Gui.FlowLayout
				{
					Size = Vector2(596, 86),
					Location = Vector2(0, 0),
					Align = "kAlignCenterTop",
					ControlAlign = "kAlignCenterMiddle",
					Padding = Vector4(0, 5, 0, 0),
					-- LineSpace = 10,
					create_xiaohao_item(1),
					create_xiaohao_item(2),
					create_xiaohao_item(3),
					create_xiaohao_item(4),
					create_xiaohao_item(5),
				},
			},
			Gui.Control
			{
				Size = Vector2(596, 86),
				Location = Vector2(407, 174),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/GameBalance/TD/ig_js_bg6.dds", Vector4(20, 20, 20, 20)),
				},
				Gui.FlowLayout
				{
					Size = Vector2(596, 86),
					Location = Vector2(0, 0),
					Align = "kAlignCenterTop",
					ControlAlign = "kAlignCenterMiddle",
					Padding = Vector4(0, 5, 0, 0),
					LineSpace = 10,
					create_xiaohao_item(6),
					create_xiaohao_item(7),
					create_xiaohao_item(8),
					create_xiaohao_item(9),
					create_xiaohao_item(10),
				},
			},
			Gui.Control
			{
				Size = Vector2(596, 86),
				Location = Vector2(407, 262),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/GameBalance/TD/ig_js_bg6.dds", Vector4(20, 20, 20, 20)),
				},
				Gui.FlowLayout
				{
					Size = Vector2(596, 86),
					Location = Vector2(0, 0),
					Align = "kAlignCenterTop",
					ControlAlign = "kAlignCenterMiddle",
					Padding = Vector4(0, 5, 0, 0),
					LineSpace = 10,
					create_xiaohao_item(11),
					create_xiaohao_item(12),
					create_xiaohao_item(13),
					create_xiaohao_item(14),
					create_xiaohao_item(15),
				},
			},
		},
		Gui.Control "blue"
		{
			Size = Vector2(1021, 296),
			Location = Vector2(23, 385),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/GameBalance/TD/ig_js_bg2.dds", Vector4(20, 20, 20, 20)),
			},
			Gui.Control
			{
				Size = Vector2(48, 29),
				Location = Vector2(19, 15),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/GameBalance/TD/ig_js_blue.dds", Vector4(0, 0, 0, 0)),
				},
			},
			Gui.Label "blue_get"
			{
				Size = Vector2(500, 30),
				Text = lang:GetText("防守方剩余：    88888888"),
				FontSize = 30,
				TextColor = ARGB(255, 255, 211, 78),
				Location = Vector2(411, 20),
				TextAlign = "kAlignLeftMiddle",
			},
			Gui.Control "res_icon_blue"
			{
				Size = Vector2(30, 30),
				Location = Vector2(350, 18),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/lb_icon_res_02.dds", Vector4(0, 0, 0, 0)),
				},
			},
			Gui.Control
			{
				Size = Vector2(997, 33),
				Location = Vector2(13, 51),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/GameBalance/TD/ig_js_bg5.dds", Vector4(0, 0, 0, 0)),
				},
				Gui.Label
				{
					Size = Vector2(200, 33),
					Text = lang:GetText("玩家昵称"),
					FontSize = 18,
					TextColor = ARGB(255, 215, 232, 227),
					Location = Vector2(105, 0),
					TextAlign = "kAlignCenterMiddle",
				},
				Gui.Label
				{
					Size = Vector2(220, 33),
					Text = lang:GetText("防守方消耗"),
					FontSize = 18,
					TextColor = ARGB(255, 215, 232, 227),
					Location = Vector2(572, 0),
					TextAlign = "kAlignCenterMiddle",
				},
			},
			Gui.ListTreeView "list_blue_team_show"
			{
				Location = Vector2(13, 84),
				Size = Vector2(424, 198),
				Style = "Gui.ListTreeViewWith_VScroll",
				ItemHeight = 33,
				VScrollBarDisplay = "kHide",
				HeaderVisible = false,
				TextColor = ARGB(255,226,217,208),
				TreeVisible = false,
				AlwaysSelect = true,
			},
			Gui.Control
			{
				Size = Vector2(596, 86),
				Location = Vector2(407, 86),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/GameBalance/TD/ig_js_bg6.dds", Vector4(20, 20, 20, 20)),
				},
				Gui.FlowLayout
				{
					Size = Vector2(596, 86),
					Location = Vector2(0, 0),
					Align = "kAlignCenterTop",
					ControlAlign = "kAlignCenterMiddle",
					Padding = Vector4(0, 5, 0, 0),
					-- LineSpace = 10,
					create_xiaohao_item(16),
					create_xiaohao_item(17),
					create_xiaohao_item(18),
					create_xiaohao_item(19),
					create_xiaohao_item(20),
				},
			},
			Gui.Control
			{
				Size = Vector2(596, 86),
				Location = Vector2(407, 174),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/GameBalance/TD/ig_js_bg6.dds", Vector4(20, 20, 20, 20)),
				},
				Gui.FlowLayout
				{
					Size = Vector2(596, 86),
					Location = Vector2(0, 0),
					Align = "kAlignCenterTop",
					ControlAlign = "kAlignCenterMiddle",
					Padding = Vector4(0, 5, 0, 0),
					LineSpace = 10,
					create_xiaohao_item(21),
					create_xiaohao_item(22),
					create_xiaohao_item(23),
					create_xiaohao_item(24),
					create_xiaohao_item(25),
				},
			},
			-- Gui.Control
			-- {
				-- Size = Vector2(596, 86),
				-- Location = Vector2(407, 262),
				-- BackgroundColor = ARGB(255, 255, 255, 255),
				-- Skin = Gui.ControlSkin
				-- {
					-- BackgroundImage = Gui.Image("LobbyUI/GameBalance/TD/ig_js_bg6.dds", Vector4(20, 20, 20, 20)),
				-- },
				-- Gui.FlowLayout
				-- {
					-- Size = Vector2(596, 86),
					-- Location = Vector2(0, 0),
					-- Align = "kAlignCenterTop",
					-- ControlAlign = "kAlignCenterMiddle",
					-- Padding = Vector4(0, 5, 0, 0),
					-- LineSpace = 10,
					-- create_xiaohao_item(26),
					-- create_xiaohao_item(27),
					-- create_xiaohao_item(28),
					-- create_xiaohao_item(29),
					-- create_xiaohao_item(30),
				-- },
			-- },
		},	
		Gui.Control "gray"
		{
			Size = Vector2(1024, 150),
			Location = Vector2(23, 688),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/GameBalance/summary_bg2.dds", Vector4(20, 20, 20, 20)),
			},
			Gui.Control
			{
				Size = Vector2(490, 45),
				Location = Vector2(22, 27),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/GameBalance/TD/ig_js_bg6.dds", Vector4(20, 20, 20, 20)),
				},
				Gui.Label
				{
					Size = Vector2(140, 45),
					Text = lang:GetText("我的获得"),
					FontSize = 18,
					TextColor = ARGB(255, 255, 211, 78),
					Location = Vector2(6, 0),
					TextAlign = "kAlignLeftMiddle",
				},
				Gui.Control "res_icon_1"
				{
					Size = Vector2(30, 30),
					Location = Vector2(136, 10),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/lb_icon_res_02.dds", Vector4(0, 0, 0, 0)),
					},
				},
				Gui.FlowLayout "my_get"
				{
					Location = Vector2(0,0),
					Size = Vector2(485,45),
					Direction = "kHorizontal",
					Align = "kAlignRightMiddle",
					ControlAlign = "kAlignCenterMiddle",
					ControlSpace = 0,
				},
			},
			Gui.Control "leader"
			{
				Size = Vector2(490, 45),
				Location = Vector2(515, 27),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/GameBalance/TD/ig_js_bg6.dds", Vector4(20, 20, 20, 20)),
				},
				Gui.Label
				{
					Size = Vector2(140, 45),
					Text = lang:GetText("队长加成"),
					FontSize = 18,
					TextColor = ARGB(255, 255, 211, 78),
					Location = Vector2(5, 0),
					TextAlign = "kAlignLeftMiddle",
				},
				Gui.Control "res_icon_2"
				{
					Size = Vector2(30, 30),
					Location = Vector2(136, 10),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/lb_icon_res_02.dds", Vector4(0, 0, 0, 0)),
					},
				},
				Gui.FlowLayout "leader_per"
				{
					Location = Vector2(0,0),
					Size = Vector2(485,45),
					Direction = "kHorizontal",
					Align = "kAlignRightMiddle",
					ControlAlign = "kAlignCenterMiddle",
					ControlSpace = 0,
				},
			},
			
			Gui.Control
			{
				Size = Vector2(490, 45),
				Location = Vector2(22, 77),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/GameBalance/TD/ig_js_bg6.dds", Vector4(20, 20, 20, 20)),
				},
				Gui.Label
				{
					Size = Vector2(140, 45),
					Text = lang:GetText("战队贡献"),
					FontSize = 18,
					TextColor = ARGB(255, 255, 211, 78),
					Location = Vector2(6, 0),
					TextAlign = "kAlignLeftMiddle",
				},
				-- Gui.Control "res_icon_4"
				-- {
					-- Size = Vector2(30, 30),
					-- Location = Vector2(86, 10),
					-- BackgroundColor = ARGB(255, 255, 255, 255),
					-- Skin = Gui.ControlSkin
					-- {
						-- BackgroundImage = Gui.Image("LobbyUI/team/lb_icon_res_02.dds", Vector4(0, 0, 0, 0)),
					-- },
				-- },
				Gui.FlowLayout "gongxian_get"
				{
					Location = Vector2(0,0),
					Size = Vector2(485,45),
					Direction = "kHorizontal",
					Align = "kAlignRightMiddle",
					ControlAlign = "kAlignCenterMiddle",
					ControlSpace = 0,
				},
			},			
			Gui.Control
			{
				Size = Vector2(490, 45),
				Location = Vector2(515, 77),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/GameBalance/TD/ig_js_bg6.dds", Vector4(20, 20, 20, 20)),
				},
				Gui.Label
				{
					Size = Vector2(140, 45),
					Text = lang:GetText("总计"),
					FontSize = 18,
					TextColor = ARGB(255, 255, 211, 78),
					Location = Vector2(2, 0),
					TextAlign = "kAlignLeftMiddle",
				},
				Gui.Control "res_icon_3"
				{
					Size = Vector2(30, 30),
					Location = Vector2(136, 10),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/lb_icon_res_02.dds", Vector4(0, 0, 0, 0)),
					},
				},
				Gui.FlowLayout "all_num"
				{
					Location = Vector2(0,0),
					Size = Vector2(485,45),
					Direction = "kHorizontal",
					Align = "kAlignRightMiddle",
					ControlAlign = "kAlignCenterMiddle",
					ControlSpace = 0,
				},
			},	
		},	
		
		Gui.Control "ctrl_red_result"
		{
			Size = Vector2(126, 117),
			Location = Vector2(938, 0),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/GameBalance/summary_win_logo.dds", Vector4(0, 0, 0, 0)),
			},
		},
		Gui.Control "ctrl_blue_result"
		{
			Size = Vector2(126, 117),
			Location = Vector2(938, 386),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/GameBalance/summary_lose_logo.dds", Vector4(0, 0, 0, 0)),
			},
		},
		
		--保存截图
		Gui.Button "btn_save_picture"
		{
			Size = Vector2(104, 36),
			Location = Vector2(709, 840),
			Text = lang:GetText("保存截图"),
			TextColor = ARGB(255, 0, 0, 0),
			FontSize = 18,
			PushDown = false,
			
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/GameBalance/TD/ig_button_normal.dds", Vector4(0, 0, 0, 0)),
				HoverImage = Gui.Image("LobbyUI/GameBalance/TD/ig_button_hover.dds", Vector4(0, 0, 0, 0)),
				DownImage = Gui.Image("LobbyUI/GameBalance/TD/ig_button_down.dds", Vector4(0, 0, 0, 0)),
				DisabledImage = Gui.Image("LobbyUI/GameBalance/TD/ig_button_disabled.dds", Vector4(0, 0, 0, 0)),
			},
			
			EventClick = function()
				ptr_cast(game.CurrentState):AutoPhoto()
			end
		},
		
		--保存录像
		Gui.Button "btn_save_camera"
		{
			Size = Vector2(104, 36),
			Location = Vector2(825, 840),
			Text = lang:GetText("保存录像"),
			TextColor = ARGB(255, 0, 0, 0),
			FontSize = 18,
			PushDown = false,
			Visible = false,
			
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/GameBalance/TD/ig_button_normal.dds", Vector4(0, 0, 0, 0)),
				HoverImage = Gui.Image("LobbyUI/GameBalance/TD/ig_button_hover.dds", Vector4(0, 0, 0, 0)),
				DownImage = Gui.Image("LobbyUI/GameBalance/TD/ig_button_down.dds", Vector4(0, 0, 0, 0)),
				DisabledImage = Gui.Image("LobbyUI/GameBalance/TD/ig_button_disabled.dds", Vector4(0, 0, 0, 0)),
			},
			
			EventClick = function()
				--ptr_cast(game.CurrentState):AutoPhoto()
				local level_id = ptr_cast(game.CurrentState):GetSelfRoomInfo().option.level_id
				local level_info = ptr_cast(game.CurrentState):GetLevelInfoById(level_id) or ""
				local single_mode = ptr_cast(game.CurrentState):GetSelfRoomInfo().option.character_id or ""
				print("level_info.type = "..level_info.type)
				local text = os.date("%Y-%m-%d-%H-%M_")..level_info.type.."_"..level_info.show_name.."_"..single_mode
				MessageBox.ShowWithTimer(3,lang:GetText("录像已保存"))
				SaveReplay(text)
				ui.btn_save_camera.Enable = false
			end
		},

		--确定
		Gui.Button "btn_confirm"
		{
			Size = Vector2(104, 36),
			Location = Vector2(939, 840),
			Text = lang:GetText("确定"),
			TextColor = ARGB(255, 0, 0, 0),
			FontSize = 18,
			PushDown = false,
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/GameBalance/TD/ig_button_normal.dds", Vector4(0, 0, 0, 0)),
				HoverImage = Gui.Image("LobbyUI/GameBalance/TD/ig_button_hover.dds", Vector4(0, 0, 0, 0)),
				DownImage = Gui.Image("LobbyUI/GameBalance/TD/ig_button_down.dds", Vector4(0, 0, 0, 0)),
				DisabledImage = Gui.Image("LobbyUI/GameBalance/TD/ig_button_disabled.dds", Vector4(0, 0, 0, 0)),
			},
			EventClick = function( )
				ptr_cast(game.CurrentState):Quit()
				L_LobbyMain.LobbyMainWin.invite_Timer:Show()	
			end
		},
	},
}

-- end

popup_card_window = nil

popup_card_window_ui =  Gui.Create()
{	
	Gui.Control "ctrl_popup_card_window"
	{
		Size = Vector2(1200,1000),
		Location = Vector2(0,0),
		BackgroundColor = ARGB(0, 255, 255, 255),
		
		Gui.Control "ctrl_popup_card_title"
		{
			Size = Vector2(1080,236),
			Location = Vector2(60,0),
			BackgroundColor = ARGB(0, 255, 255, 255),
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/WarZone/Present/lb_gift_biew_bg1.dds", Vector4(200,104,105,48)),
			},
		}
	}
}

function ShowPopCard()
	popup_card_window = ModalWindow.GetNew()
	popup_card_window.root.Size = Vector2(1200,1000)
	popup_card_window.AllowEscToExit = true
	
	popup_card_window_ui.ctrl_popup_card_window.Parent = popup_card_window.root
	
end
function ShowsurvivalPopCard()
	popup_card_window = ModalWindow.GetNew()
	popup_card_window.root.Size = Vector2(1200,1000)
	popup_card_window.AllowEscToExit = true
	
	card_pve_window_ui1.ctrl_popup_card_window.Parent = popup_card_window.root
	
end

function ShowmatchPopCard()
	popup_card_window = ModalWindow.GetNew()
	popup_card_window.root.Size = Vector2(1200,1000)
	popup_card_window.AllowEscToExit = true
	
	card_pve_match_window_ui.ctrl_popup_card_window.Parent = popup_card_window.root
	
end



------------延时函数-------------------------

function sleep(n)  -- seconds
  local t0 = clock()
  while clock() - t0 <= n do end
end


--------------初始化玩家信息列表---------------
function InitLtvHeader(ltv)
    ltv:DeleteAll()
	ltv:DeleteColumns()
    ltv:AddColumn(lang:GetText("排名"),65)
    ltv:AddColumn("",40)
    ltv:AddColumn("",38)
    ltv:AddColumn("",22)
    ltv:AddColumn("",22)
    ltv:AddColumn(lang:GetText("玩家"),137)
    ltv:AddColumn(lang:GetText("积分"),50)
    ltv:AddColumn(lang:GetText("击杀"),40)
    ltv:AddColumn("",18)
    ltv:AddColumn("",18)
    ltv:AddColumn("",18)
    ltv:AddColumn("",18)
    -- ltv:AddColumn("",18)
    -- ltv:AddColumn("",18)
    ltv:AddColumn("",46)
    -- ltv:AddColumn("",18)
    ltv:AddColumn(lang:GetText(""),40)
    local header = ltv.Columns
    header:SetAlign(0,"kAlignCenterMiddle")
    header:SetAlign(1,"kAlignCenterMiddle")
    header:SetAlign(2,"kAlignCenterMiddle")
    header:SetAlign(3,"kAlignRightMiddle")
    header:SetAlign(4,"kAlignLeftMiddle")
    header:SetAlign(5,"kAlignCenterMiddle")
    header:SetAlign(6,"kAlignCenterMiddle")
    header:SetAlign(7,"kAlignCenterMiddle")
    header:SetAlign(8,"kAlignCenterMiddle")
    header:SetAlign(9,"kAlignCenterMiddle")
    header:SetAlign(10,"kAlignCenterMiddle")
    header:SetAlign(11,"kAlignCenterMiddle")
    header:SetAlign(12,"kAlignCenterMiddle")
    header:SetAlign(13,"kAlignCenterMiddle")
    header:SetAlign(14,"kAlignRightMiddle")
    header:SetAlign(15,"kAlignCenterMiddle")
    -- header:SetAlign(16,"kAlignCenterMiddle")
end
function InitLtvHeader1(ltv)
    ltv:DeleteAll()
	ltv:DeleteColumns()
    ltv:AddColumn(lang:GetText("排名"),65)
    ltv:AddColumn("",40)
    ltv:AddColumn("",38)
    ltv:AddColumn("",22)
    ltv:AddColumn("",22)
    ltv:AddColumn(lang:GetText("玩家"),137)
	ltv:AddColumn(lang:GetText("比赛积分"),100)
    ltv:AddColumn(lang:GetText("击杀"),40)
    ltv:AddColumn("",18)
    ltv:AddColumn("",18)
    ltv:AddColumn("",18)
    ltv:AddColumn("",18)
    -- ltv:AddColumn("",18)
    -- ltv:AddColumn("",18)
    ltv:AddColumn("",46)
    -- ltv:AddColumn("",18)
    ltv:AddColumn(lang:GetText(""),40)
    local header = ltv.Columns
    header:SetAlign(0,"kAlignCenterMiddle")
    header:SetAlign(1,"kAlignCenterMiddle")
    header:SetAlign(2,"kAlignCenterMiddle")
    header:SetAlign(3,"kAlignRightMiddle")
    header:SetAlign(4,"kAlignLeftMiddle")
    header:SetAlign(5,"kAlignCenterMiddle")
    header:SetAlign(6,"kAlignCenterMiddle")
    header:SetAlign(7,"kAlignCenterMiddle")
    header:SetAlign(8,"kAlignCenterMiddle")
    header:SetAlign(9,"kAlignCenterMiddle")
    header:SetAlign(10,"kAlignCenterMiddle")
    header:SetAlign(11,"kAlignCenterMiddle")
    header:SetAlign(12,"kAlignCenterMiddle")
    header:SetAlign(13,"kAlignCenterMiddle")
    header:SetAlign(14,"kAlignRightMiddle")
    header:SetAlign(15,"kAlignCenterMiddle")
    -- header:SetAlign(16,"kAlignCenterMiddle")
end

-----------------初始化其他列表-----------------
function InitOtherList()
    local ltv = ui.list_accomplishment_show
    ltv:DeleteAll()
    ltv:AddColumn("",169)
    ltv:AddColumn("",192)
    ltv:AddColumn("",150)
    
    local header = ltv.Columns
    header:SetAlign(0,"kAlignCenterMiddle")
    header:SetAlign(1,"kAlignCenterMiddle")
    header:SetAlign(2,"kAlignCenterMiddle")
    
    ltv = ui.list_help_show
    ltv:DeleteAll()
    ltv:AddColumn("",160)
    ltv:AddColumn("",97)
    header = ltv.Columns
    header:SetAlign(0,"kAlignCenterMiddle")
    header:SetAlign(1,"kAlignCenterMiddle")
    
    ltv = ui.list_kill_show
    ltv:DeleteAll()
    ltv:AddColumn("",160)
    ltv:AddColumn("",97)
    header = ltv.Columns
    header:SetAlign(0,"kAlignCenterMiddle")
    header:SetAlign(1,"kAlignCenterMiddle")
    
    ui.ctrl_window_right_middle.ScrollNumRange = "0,0"
    ui.ctrl_window_left_middle.ScrollNumRange = "0,0"
    
    ui.ctrl_get_experience_sc.ScrollNumRange = "0,0"
    ui.ctrl_get_energy_sc.ScrollNumRange = "0,0"
end

function SetColumns(ltv,c)
	local header =ltv.Columns
	for i = 1,6 do
		header:SetText(i - 1,c[i][1])
		header:SetWidth(i - 1,c[i][2])
	end
end

function TurnCard(data)
	local index = data.index
	
	if index > 0 then
		local item_name = data.item.name
		local color = data.item.color
		
		if color > 1 then
			item_name = item_name.."_"..color
		end
		
		local cardback =  Gui.Image("LobbyUI/GameBalance/lb_summary_flop_card_back_1.dds", Vector4(0,0,0,0))
		local cardfront = Gui.Image("LobbyUI/GameBalance/lb_summary_flop_card_light.dds", Vector4(0,0,0,0))
		Card[index].card:DeleteFrameList("TurnCard")
		Card[index].card:AddFrame("TurnCard",cardback,Vector4(0, 0, 0, 0))
		Card[index].card:AddFrame("TurnCard",cardfront,Vector4(0, 0, 0, 0))
		Card[index].card:StartAnimation()
		
		print("item_name = "..item_name)
		local cardcontent = Gui.Image("LobbyUI/ibt_icon/"..item_name..".tga", Vector4(0,0,0,0))
		print("index = "..index)
		Card[index].card:AddFrame("TurnCard",cardcontent,Vector4(0, 0, 0, 0))	
		Card[index].card:TurnCard()
		Card[index].card.Enable = false
		if data.item.common.type == 4 and data.item.common.subtype == 7 or data.item.common.type == 5 then
			-- Card[index].card:OnDestroy()
			L_Characters.CreatPresentNumCtr(Card[index].card,data.item.item_num,132,159)
		end
		
		card_num = card_num + 1
		turn_card[card_num] = data.index
		if data.item.total_rare_level > 0 then
			--翻牌音效
			print(lang:GetText("播放翻牌音效"))
			gui:PlayAudio("kUIA_STAGE_TURNCARD")
		end
		gui:PlayAudio("kUIA_POKERCARD_TRUN")
		
		for i = 1, 5+flag[4] do
			if i == 4 and flag[i] > 0 then
				flag[i] = flag[i] - 1
				if flag[i] == 0 then
					popup_card_window_ui.card_4.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("InGameUI/bottom_info/ig_common_fanpai_card_bg.dds", Vector4(0 , 0, 0, 0)),}
				end
				popup_card_window_ui.vip_title.Text = "VIP X"..flag[i]
				break
			else
				if flag[i] == 1 then
					flag[i] = 0
					if i == 1 then
						popup_card_window_ui.card_1.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("InGameUI/bottom_info/ig_common_fanpai_card_bg.dds", Vector4(0 , 0, 0, 0)),}
					elseif i == 2 then
						popup_card_window_ui.card_2.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("InGameUI/bottom_info/ig_common_fanpai_card_bg.dds", Vector4(0 , 0, 0, 0)),}						
					elseif i == 3 then
						popup_card_window_ui.card_3.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("InGameUI/bottom_info/ig_common_fanpai_card_bg.dds", Vector4(0 , 0, 0, 0)),}						
					elseif i == 4 then
						popup_card_window_ui.card_4.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("InGameUI/bottom_info/ig_common_fanpai_card_bg.dds", Vector4(0 , 0, 0, 0)),}
					elseif i == 5 then
						popup_card_window_ui.card_5.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("InGameUI/bottom_info/ig_common_fanpai_card_bg.dds", Vector4(0 , 0, 0, 0)),}
					elseif i == 6 then
						popup_card_window_ui.card_6.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("InGameUI/bottom_info/ig_common_fanpai_card_bg.dds", Vector4(0 , 0, 0, 0)),}
					end
					break
				end
			end
		end
	else
		
	end
end

function SpawnNewCard(name,i)
	local row,col = 0,0
	local rownum,colnum = 3,3
	
	local CardIcon = Gui.Create(gui) {
					Gui.AnimControl "card"
					{
						Size = Vector2(144,172),
						BackgroundColor = ARGB(0, 255, 255, 255),
						PushDown = false,
						EventClick = function(Sender,e)
							if isTurncard then
								total_turn_chance = total_turn_chance - 1
								if total_turn_chance >= 0 and Sender.PushDown == false then
									Sender.PushDown = true
									local state = ptr_cast(game.CurrentState,"Client.StateBalance")
									local args = {pid = state:GetMyClientInfo().character_id,index = Sender.IntTag}
									rpc.safecall("stage_clear_open",args,TurnCard,function() MessageBox.CloseWaiter() end)
								end
								
								if total_turn_chance < 0 then
									total_turn_chance = 0
								end
								
								popup_card_window_ui.left_turncard_chance.Text = total_turn_chance
							end
						end,
						
						EventFinish  = function(Sender,e)
							for j=1,table.getn(turn_allcard) do
								if i == turn_allcard[j] then
									Card[i].get_card.Visible = true
								end
							end
							for j=1,table.getn(turn_card) do
								if i == turn_card[j] then
									Card[i].get_card.Visible = true
								end
							end
						end,
						
						Gui.Control "get_card"
						{	
							Size = Vector2(45,45),
							-- Location = Vector2(0,0),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Visible = false,
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_summary_flop_card_ico_01.dds", Vector4(0,0,0,0)),
							},
						}
					}
				}
	col = i / colnum
	col = math.floor(col)
	if i % colnum == 0 then
		col = col - 1
	end
	
	row = i - col * colnum
		
	CardIcon.card.Location = Vector2((row-1)*160+15,col*160 +5)
	CardIcon.get_card.Location = Vector2(12,13)
	CardIcon.card:AddAnim("TurnCard",0.5,5)
	
	local cardback =  Gui.Image("LobbyUI/GameBalance/lb_summary_flop_card_back_1.dds", Vector4(0,0,0,0))
	local cardfront = Gui.Image("LobbyUI/GameBalance/lb_summary_flop_card_front.dds", Vector4(0,0,0,0))
	
	CardIcon.card:AddFrame("TurnCard",cardback,Vector4(0, 0, 0, 0))
	CardIcon.card:AddFrame("TurnCard",cardfront,Vector4(0, 0, 0, 0))
	CardIcon.card:StartAnimation()
	CardIcon.card.IntTag = i
	
	return CardIcon
end

function TurnAllCard(data)
	local items = data.items
	local turn_num = Split(data.indexs,",")
	local cardback =  Gui.Image("LobbyUI/GameBalance/lb_summary_flop_card_back_1.dds", Vector4(0,0,0,0))
	local cardfront = Gui.Image("LobbyUI/GameBalance/lb_summary_flop_card_light.dds", Vector4(0,0,0,0))
	popup_card_window_ui.left_turncard_chance.Text = "0"
	if items then
		for j = 1,table.getn(turn_num) do
			allcard_num = allcard_num+1
			turn_allcard[allcard_num] = tonumber(turn_num[j])
			if turn_allcard[allcard_num] then
				Card[turn_allcard[allcard_num]].card:DeleteFrameList("TurnCard")
				Card[turn_allcard[allcard_num]].card:AddFrame("TurnCard",cardback,Vector4(0, 0, 0, 0))
				Card[turn_allcard[allcard_num]].card:AddFrame("TurnCard",cardfront,Vector4(0, 0, 0, 0))
				Card[turn_allcard[allcard_num]].card:StartAnimation()
			end

			if data.indexs ~= "" and items[turn_allcard[allcard_num]].total_rare_level > 0 then
				--翻牌音效
				print(lang:GetText("播放翻牌音效"))
				gui:PlayAudio("kUIA_STAGE_TURNCARD")
			end
		end
		for i,v in ipairs(items) do		
			if i <= 9 and Card[i] and Card[i].card.Enable then
				local item_name = v.name
				local color = v.color
				
				if color > 1 then
					item_name = item_name.."_"..color
				end

				local cardcontent = Gui.Image("LobbyUI/ibt_icon/"..item_name..".tga", Vector4(0,0,0,0))
				Card[i].card:AddFrame("TurnCard",cardcontent,Vector4(0, 0, 0, 0))	
				Card[i].card:TurnCard()
				Card[i].card.Enable = false
				if v.common.type == 4 and v.common.subtype == 7 or v.common.type == 5 then
					-- Card[i].card:OnDestroy()
					L_Characters.CreatPresentNumCtr(Card[i].card,v.item_num,132,159)
				end
			end
		end
		-- for j = 1,table.getn(turn_num) do
			-- allcard_num = allcard_num+1
			-- turn_allcard[allcard_num] = tonumber(turn_num[j])
			-- local cardback =  Gui.Image("LobbyUI/GameBalance/lb_summary_flop_card_back_1.dds", Vector4(0,0,0,0))
			-- local cardfront = Gui.Image("LobbyUI/GameBalance/lb_summary_flop_card_light.dds", Vector4(0,0,0,0))
			-- Card[turn_allcard[allcard_num]].card:AddFrame("TurnCard",cardback,Vector4(0, 0, 0, 0))
			-- Card[turn_allcard[allcard_num]].card:AddFrame("TurnCard",cardfront,Vector4(0, 0, 0, 0))
			-- Card[turn_allcard[allcard_num]].card:StartAnimation()
			-- if data.indexs ~= "" and items[turn_allcard[allcard_num]].total_rare_level > 0 then
				-- -- 翻牌音效
				-- print(lang:GetText("播放翻牌音效"))
				-- gui:PlayAudio("kUIA_STAGE_TURNCARD")
			-- end
		-- end
		gui:PlayAudio("kUIA_POKERCARD_TRUN")
		for i = 1, 5+flag[4] do
			if i == 4 and flag[i] > 0 then
				flag[i] = 0
				popup_card_window_ui.card_4.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("InGameUI/bottom_info/ig_common_fanpai_card_bg.dds", Vector4(0 , 0, 0, 0)),}
				popup_card_window_ui.vip_title.Text = "VIP X0"

				break
			else
				if flag[i] == 1 then
					flag[i] = 0
					if i == 1 then
						popup_card_window_ui.card_1.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("InGameUI/bottom_info/ig_common_fanpai_card_bg.dds", Vector4(0 , 0, 0, 0)),}
					elseif i == 2 then
						popup_card_window_ui.card_2.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("InGameUI/bottom_info/ig_common_fanpai_card_bg.dds", Vector4(0 , 0, 0, 0)),}
					elseif i == 3 then
						popup_card_window_ui.card_3.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("InGameUI/bottom_info/ig_common_fanpai_card_bg.dds", Vector4(0 , 0, 0, 0)),}
					elseif i == 4 then
						popup_card_window_ui.card_4.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("InGameUI/bottom_info/ig_common_fanpai_card_bg.dds", Vector4(0 , 0, 0, 0)),}
					elseif i == 5 then
						popup_card_window_ui.card_5.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("InGameUI/bottom_info/ig_common_fanpai_card_bg.dds", Vector4(0 , 0, 0, 0)),}
					elseif i == 6 then
						popup_card_window_ui.card_6.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("InGameUI/bottom_info/ig_common_fanpai_card_bg.dds", Vector4(0 , 0, 0, 0)),}
					end
				end
			end	
		end
	end
	gui:PlayAudio("kUIA_CONGRA_POP")
	-- ui.PopCloseTimer:AddAnim("CloseCardTimer",3,4)
	-- ui.PopCloseTimer:StartAnimation()
	
	ui.PopCloseTimer:CleanAll()
	ui.PopCloseTimer:AddTime(3)
end

popup_card_window = nil

popup_card_window_ui =  Gui.Create()
{	
	Gui.Control "ctrl_popup_card_window"
	{
		Size = Vector2(1200,1200),
		Location = Vector2(0,0),
		BackgroundColor = ARGB(0, 255, 255, 255),
		
		Gui.Control "ctrl_popup_card_content"
		{
			Size = Vector2(1080,760),
			Location = Vector2(60,274),
			BackgroundColor = ARGB(255, 255, 255, 255),
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/WarZone/Present/lb_gift_biew_bg1.dds", Vector4(200,104,105,48)),
			},
			
			Gui.Control "ctrl_popup_card_Score"
			{
				Size = Vector2(513,625),
				Location = Vector2(22,79),
				BackgroundColor = ARGB(255, 255, 255, 255),
				
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_summary_flop_bg_04.dds", Vector4(30 , 30, 30, 30)),
				},
				
				Gui.Control "ct_get_score"
				{
					Size = Vector2(471,47),
					Location = Vector2(19,67),
					BackgroundColor = ARGB(255, 255, 255, 255),
					
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_summary_flop_bg_02.dds", Vector4(20 , 20, 20, 20)),
					},
					
					Gui.Label "jifen"
					{
						Size = Vector2(400, 46),
						Text = lang:GetText("获得积分"),
						FontSize = 20,
						TextColor = ARGB(255, 255, 181, 2),
						Location = Vector2(15, 1),
						TextAlign = "kAlignLeftMiddle",
					},
					Gui.Control "negative"
					{
						Size = Vector2(32,44),
						Location = Vector2(261,1),
						BackgroundColor = ARGB(255, 255, 255, 255),
						
						Skin = Gui.ControlSkin
						{
							-- BackgroundImage = Gui.Image("InGameUI/lb_summary_number_reduce.dds", Vector4(20 , 20, 20, 20)),
						},
					},
					Gui.AnimControl "ScrollScore"
					{
						Size = Vector2(33,44),
						Location  = Vector2(88,1),
						BackgroundColor = ARGB(0, 255, 255, 255),
					},
					
					Gui.Label "Unit"
					{
						Size = Vector2(100,46),
						Location  = Vector2(392,1),
						Text = lang:GetText("积分"),
						FontSize = 20,
						TextColor = ARGB(255, 255, 181, 2),
					},
				},
				
				Gui.Control "ct_get_vipscore"
				{
					Size = Vector2(471,47),
					Location = Vector2(19,121),
					BackgroundColor = ARGB(255, 255, 255, 255),
					
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_summary_flop_bg_02.dds", Vector4(20 , 20, 20, 20)),
					},
					
					Gui.Label ""
					{
						Size = Vector2(400, 46),
						Text = lang:GetText("获得VIP经验"),
						FontSize = 20,
						TextColor = ARGB(255, 255, 181, 2),
						Location = Vector2(15, 1),
						TextAlign = "kAlignLeftMiddle",
					},
					Gui.AnimControl "vipScrollScore"
					{
						Size = Vector2(330,44),
						Location  = Vector2(88,1),
						BackgroundColor = ARGB(0, 255, 255, 255),
					},
					
					Gui.Label "vipUnit"
					{
						Size = Vector2(100,46),
						Location  = Vector2(392,1),
						Text = lang:GetText("经验"),
						FontSize = 20,
						TextColor = ARGB(255, 255, 181, 2),
					},
				},
				
				Gui.Control "ct_get_exp"
				{
					Size = Vector2(471,135),
					Location = Vector2(19,175),
					BackgroundColor = ARGB(255, 255, 255, 255),
					
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_summary_flop_bg_03.dds", Vector4(30 , 30, 30, 30)),
					},
					
					Gui.Label ""
					{
						Size = Vector2(200, 46),
						Text = lang:GetText("获得经验:"),
						FontSize = 20,
						TextColor = ARGB(255, 255, 181, 2),
						Location = Vector2(15, 1),
						TextAlign = "kAlignLeftMiddle",
					},
					Gui.AnimControl "Scrollexp"
					{
						Size = Vector2(198,44),
						Location  = Vector2(220,4),
						BackgroundColor = ARGB(0, 255, 255, 255),
					},
					
					Gui.Label "Unit"
					{
						Size = Vector2(100,46),
						Location  = Vector2(392,1),
						Text = lang:GetText("经验"),
						FontSize = 20,
						TextColor = ARGB(255, 255, 181, 2),
					},
					
					Gui.Label ""
					{
						Size = Vector2(180,44),
						Location  = Vector2(5,45),
						Text = lang:GetText("基础获得"),
						FontSize = 16,
						TextColor = ARGB(255, 255, 181, 2),
						TextAlign = "kAlignLeftMiddle",
					},
					
					Gui.Label "scrollexp_base_get"
					{
						Size = Vector2(125,44),
						Location  = Vector2(190,45),
						Text = "10%",
						FontSize = 16,
						TextColor = ARGB(255, 219, 138, 56),
					},
					
					Gui.Label ""
					{
						Size = Vector2(180,44),
						Location  = Vector2(250,45),
						Text = "VIP",
						FontSize = 16,
						TextColor = ARGB(255, 255, 181, 2),
						TextAlign = "kAlignLeftMiddle",
					},
					
					Gui.Label "scrollexp_vip"
					{
						Size = Vector2(125,44),
						Location  = Vector2(435,45),
						Text = "10%",
						FontSize = 16,
						TextColor = ARGB(255, 219, 138, 56),
					},
					
					Gui.Label ""
					{
						Size = Vector2(180,44),
						Location  = Vector2(5,66),
						Text = lang:GetText("战队"),
						FontSize = 16,
						TextColor = ARGB(255, 255, 181, 2),
						TextAlign = "kAlignLeftMiddle",
					},
					
					Gui.Label "scrollexp_battle"
					{
						Size = Vector2(125,44),
						Location  = Vector2(190,66),
						Text = "10%",
						FontSize = 16,
						TextColor = ARGB(255, 219, 138, 56),
					},
					
					Gui.Label ""
					{
						Size = Vector2(180,44),
						Location  = Vector2(250,66),
						Text = lang:GetText("网吧"),
						FontSize = 16,
						TextColor = ARGB(255, 255, 181, 2),
						TextAlign = "kAlignLeftMiddle",
					},
					
					Gui.Label "scrollexp_cab"
					{
						Size = Vector2(125,44),
						Location  = Vector2(435,66),
						Text = "10%",
						FontSize = 16,
						TextColor = ARGB(255, 219, 138, 56),
					},
					
					Gui.Label ""
					{
						Size = Vector2(180,44),
						Location  = Vector2(5,87),
						Text = lang:GetText("活动"),
						FontSize = 16,
						TextColor = ARGB(255, 255, 181, 2),
						TextAlign = "kAlignLeftMiddle",
					},
					
					Gui.Label "scrollexp_activity"
					{
						Size = Vector2(125,44),
						Location  = Vector2(190,87),
						Text = "0%",
						FontSize = 16,
						TextColor = ARGB(255, 219, 138, 56),
					},
					Gui.Label ""
					{
						Size = Vector2(180,44),
						Location  = Vector2(250,87),
						Text = lang:GetText("道具"),
						FontSize = 16,
						TextColor = ARGB(255, 255, 181, 2),
						TextAlign = "kAlignLeftMiddle",
					},
					
					Gui.Label "scrollexp_daoju"
					{
						Size = Vector2(125,44),
						Location  = Vector2(435,87),
						Text = "10%",
						FontSize = 16,
						TextColor = ARGB(255, 219, 138, 56),
					},
					
				},
				
				Gui.Control "ct_get_eng"
				{
					Size = Vector2(471,135),
					Location = Vector2(19,317),
					BackgroundColor = ARGB(255, 255, 255, 255),
					
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_summary_flop_bg_03.dds", Vector4(30 , 30, 30, 30)),
					},
					
					Gui.Label ""
					{
						Size = Vector2(200, 46),
						Text = lang:GetText("获得C币:"),
						FontSize = 20,
						TextColor = ARGB(255, 255, 181, 2),
						Location = Vector2(15, 1),
					},
					
					Gui.AnimControl "Scrolleng"
					{
						Size = Vector2(198,44),
						Location  = Vector2(220,4),
						BackgroundColor = ARGB(0, 255, 255, 255),
					},
										
					Gui.Label "Unit"
					{
						Size = Vector2(100,46),
						Location  = Vector2(392,1),
						Text = lang:GetText("C币"),
						FontSize = 20,
						TextColor = ARGB(255, 255, 181, 2),
					},
					Gui.Label ""
					{
						Size = Vector2(180,44),
						Location  = Vector2(5,45),
						Text = lang:GetText("基础获得"),
						FontSize = 16,
						TextColor = ARGB(255, 255, 181, 2),
						TextAlign = "kAlignLeftMiddle",
					},

					Gui.Label "scrolleng_base_get"
					{
						Size = Vector2(125,44),
						Location  = Vector2(190,45),
						Text = "10%",
						FontSize = 16,
						TextColor = ARGB(255, 219, 138, 56),
					},
					
					Gui.Label ""
					{
						Size = Vector2(180,44),
						Location  = Vector2(250,45),
						Text = "VIP",
						FontSize = 16,
						TextColor = ARGB(255, 255, 181, 2),
						TextAlign = "kAlignLeftMiddle",
					},
					
					Gui.Label "scrolleng_vip"
					{
						Size = Vector2(125,44),
						Location  = Vector2(435,45),
						Text = "10%",
						FontSize = 16,
						TextColor = ARGB(255, 219, 138, 56),
					},
					
					Gui.Label ""
					{
						Size = Vector2(180,44),
						Location  = Vector2(5,66),
						Text = lang:GetText("战队"),
						FontSize = 16,
						TextColor = ARGB(255, 255, 181, 2),
						TextAlign = "kAlignLeftMiddle",
					},
					
					Gui.Label "scrolleng_battle"
					{
						Size = Vector2(125,44),
						Location  = Vector2(190,66),
						Text = "10%",
						FontSize = 16,
						TextColor = ARGB(255, 219, 138, 56),
					},
					
					Gui.Label ""
					{
						Size = Vector2(180,44),
						Location  = Vector2(250,66),
						Text = lang:GetText("网吧"),
						FontSize = 16,
						TextColor = ARGB(255, 255, 181, 2),
						TextAlign = "kAlignLeftMiddle",
					},
					
					Gui.Label "scrolleng_cab"
					{
						Size = Vector2(125,44),
						Location  = Vector2(435,66),
						Text = "10%",
						FontSize = 16,
						TextColor = ARGB(255, 219, 138, 56),
					},
					
					Gui.Label ""
					{
						Size = Vector2(180,44),
						Location  = Vector2(5,87),
						Text = lang:GetText("活动"),
						FontSize = 16,
						TextColor = ARGB(255, 255, 181, 2),
						TextAlign = "kAlignLeftMiddle",
					},
					
					Gui.Label "scrolleng_activity"
					{
						Size = Vector2(125,44),
						Location  = Vector2(190,87),
						Text = "0%",
						FontSize = 16,
						TextColor = ARGB(255, 219, 138, 56),
					},
					Gui.Label ""
					{
						Size = Vector2(180,44),
						Location  = Vector2(250,87),
						Text = lang:GetText("道具"),
						FontSize = 16,
						TextColor = ARGB(255, 255, 181, 2),
						TextAlign = "kAlignLeftMiddle",
					},
					
					Gui.Label "scrolleng_daoju"
					{
						Size = Vector2(125,44),
						Location  = Vector2(435,87),
						Text = "10%",
						FontSize = 16,
						TextColor = ARGB(255, 219, 138, 56),
					},
				},
				
				Gui.Control "ct_get_chance"
				{
					Size = Vector2(471,135),
					Location = Vector2(19,459),
					BackgroundColor = ARGB(255, 255, 255, 255),
					
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_summary_flop_bg_03.dds", Vector4(30 , 30, 30, 30)),
					},
					
					Gui.Label "chance_times"
					{
						Size = Vector2(300, 46),
						Text = lang:GetText("你总共获得了  次翻牌机会"),
						FontSize = 20,
						TextColor = ARGB(255, 255, 181, 2),
						Location = Vector2(15, 1),
					},
					
					-- Gui.Label "chance_times"
					-- {
						-- Size = Vector2(50, 60),
						-- Text = "3",
						-- FontSize = 32,
						-- TextColor = ARGB(255, 219, 138, 56),
						-- Location = Vector2(137, -8),
					-- },
					
					Gui.Label ""
					{
						Size = Vector2(180,44),
						Location  = Vector2(5,45),
						Text = lang:GetText("基础获得"),
						FontSize = 16,
						TextColor = ARGB(255, 255, 181, 2),
						TextAlign = "kAlignLeftMiddle",
					},
					
					Gui.Label "scrollchance_base_get"
					{
						Size = Vector2(125,44),
						Location  = Vector2(190,45),
						Text = "10%",
						FontSize = 16,
						TextColor = ARGB(255, 219, 138, 56),
					},
					
					Gui.Label ""
					{
						Size = Vector2(180,44),
						Location  = Vector2(250,45),
						Text = "VIP",
						FontSize = 16,
						TextColor = ARGB(255, 255, 181, 2),
						TextAlign = "kAlignLeftMiddle",
					},
					
					Gui.Label "scrollchance_vip"
					{
						Size = Vector2(125,44),
						Location  = Vector2(435,45),
						Text = "10%",
						FontSize = 16,
						TextColor = ARGB(255, 219, 138, 56),
					},
					
					Gui.Label ""
					{
						Size = Vector2(180,44),
						Location  = Vector2(5,66),
						Text = lang:GetText("网吧"),
						FontSize = 16,
						TextColor = ARGB(255, 255, 181, 2),
						TextAlign = "kAlignLeftMiddle",
					},
					
					Gui.Label "scrollchance_cab"
					{
						Size = Vector2(125,44),
						Location  = Vector2(190,66),
						Text = "10%",
						FontSize = 16,
						TextColor = ARGB(255, 219, 138, 56),
					},
					
					Gui.Label ""
					{
						Size = Vector2(100,44),
						Location  = Vector2(250,66),
						Text = lang:GetText("活动"),
						FontSize = 16,
						TextColor = ARGB(255, 255, 181, 2),
					},
					
					Gui.Label "scrollchance_activity"
					{
						Size = Vector2(125,44),
						Location  = Vector2(435,66),
						Text = "0%",
						FontSize = 16,
						TextColor = ARGB(255, 219, 138, 56),
					},
				},
			},
			
			Gui.Control "ctrl_popup_card_animation"
			{
				Size = Vector2(513,625),
				Location = Vector2(545,79),
				BackgroundColor = ARGB(255, 255, 255, 255),
				
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_summary_flop_bg_04.dds", Vector4(30 , 30, 30, 30)),
				},
				
				Gui.Label ""
				{
					Size = Vector2(200, 46),
					Text = lang:GetText("剩余时间:"),
					FontSize = 20,
					TextColor = ARGB(255, 255, 181, 2),
					Location = Vector2(330, 10),
				},
				
				Gui.AnimControl "card_timer"
				{
					Size = Vector2(40,46),
					Location  = Vector2(440,10),
					BackgroundColor = ARGB(0, 255, 255, 255),
					
					EventFinish = function(Sender,e)
						isTurncard = false
						local state = ptr_cast(game.CurrentState,"Client.StateBalance")
						local args = {pid = state:GetMyClientInfo().character_id}
						rpc.safecall("stage_clear_open_timeout",args,TurnAllCard,function() MessageBox.CloseWaiter() end)
					end
				},
				
				Gui.Control "ctrl_popup_card_timer"
				{
					Size = Vector2(471, 47),
					Location = Vector2(22,59),
					BackgroundColor = ARGB(255, 255, 255, 255),
					
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_summary_flop_bg_02.dds", Vector4(20 , 20, 20, 20)),
					},
					
					Gui.Label ""
					{
						Size = Vector2(200, 46),
						Text = lang:GetText("剩余次数:"),
						FontSize = 20,
						TextColor = ARGB(255, 255, 181, 2),
						Location = Vector2(15, 1),
					},
					
					Gui.Label "left_turncard_chance"
					{
						Size = Vector2(100, 46),
						Text = "3",
						FontSize = 24,
						TextColor = ARGB(255, 219, 138, 56),
						Location = Vector2(135, 1),
					},
					
					Gui.Control
					{
						Size = Vector2(36, 50),
						Location = Vector2(230, 1),
						BackgroundColor = ARGB(0, 255, 255, 255),
						
						Gui.Label
						{
							Size = Vector2(36, 15),
							Text = lang:GetText("分数"),
							FontSize = 10,
							Font = "simhei",
							TextColor = ARGB(255, 127, 118, 114),
							Location = Vector2(4, 5),
						},
						
						Gui.Control "card_1" 
						{
							Size = Vector2(36, 40),
							Location = Vector2(0, 5),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("InGameUI/bottom_info/ig_common_fanpai_card_bg.dds", Vector4(0 , 0, 0, 0)),
							},
						},
					},
					
					Gui.Control
					{
						Size = Vector2(36, 50),
						Location = Vector2(270, 1),
						BackgroundColor = ARGB(0, 255, 255, 255),
						
						Gui.Label
						{
							Size = Vector2(36, 15),
							Text = lang:GetText("分数"),
							FontSize = 10,
							Font = "simhei",
							TextColor = ARGB(255, 127, 118, 114),
							Location = Vector2(4, 5),
						},
						
						Gui.Control "card_2"
						{
							Size = Vector2(36, 40),
							Location = Vector2(0, 5),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("InGameUI/bottom_info/ig_common_fanpai_card_bg.dds", Vector4(0 , 0, 0, 0)),
							},
						},
					},

					Gui.Control
					{
						Size = Vector2(36, 50),
						Location = Vector2(310, 1),
						BackgroundColor = ARGB(0, 255, 255, 255),
						
						Gui.Label
						{
							Size = Vector2(36, 15),
							Text = lang:GetText("分数"),
							FontSize = 10,
							Font = "simhei",
							TextColor = ARGB(255, 127, 118, 114),
							Location = Vector2(4, 5),
						},
						
						Gui.Control "card_3"
						{
							Size = Vector2(36, 40),
							Location = Vector2(0, 5),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("InGameUI/bottom_info/ig_common_fanpai_card_bg.dds", Vector4(0 , 0, 0, 0)),
							},
						},
					},

					Gui.Control
					{
						Size = Vector2(36, 50),
						Location = Vector2(350, 1),
						BackgroundColor = ARGB(0, 255, 255, 255),

						Gui.Label "vip_title"
						{
							Size = Vector2(36, 15),
							Text = "VIP",
							FontSize = 10,
							Font = "simhei",
							TextColor = ARGB(255, 127, 118, 114),
							Location = Vector2(4, 5),
						},
						
						Gui.Control "card_4"
						{
							Size = Vector2(36, 40),
							Location = Vector2(0, 5),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("InGameUI/bottom_info/ig_common_fanpai_card_bg.dds", Vector4(0 , 0, 0, 0)),
							},
						},
					},

					Gui.Control
					{
						Size = Vector2(36, 50),
						Location = Vector2(390, 1),
						BackgroundColor = ARGB(0, 255, 255, 255),
						
						Gui.Label
						{
							Size = Vector2(36, 15),
							Text = lang:GetText("网吧"),
							FontSize = 10,
							Font = "simhei",
							TextColor = ARGB(255, 127, 118, 114),
							Location = Vector2(4, 5),
						},
						
						Gui.Control "card_5"
						{
							Size = Vector2(36, 40),
							Location = Vector2(0, 5),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("InGameUI/bottom_info/ig_common_fanpai_card_bg.dds", Vector4(0 , 0, 0, 0)),
							},
						},
					},

					Gui.Control
					{
						Size = Vector2(36, 50),
						Location = Vector2(430, 1),
						BackgroundColor = ARGB(0, 255, 255, 255),
						
						Gui.Label
						{
							Size = Vector2(36, 15),
							Text = lang:GetText("活动"),
							FontSize = 10,
							Font = "simhei",
							TextColor = ARGB(255, 127, 118, 114),
							Location = Vector2(4, 5),
						},						

						Gui.Control "card_6"
						{
							Size = Vector2(36, 40),
							Location = Vector2(0, 5),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("InGameUI/bottom_info/ig_common_fanpai_card_bg.dds", Vector4(0 , 0, 0, 0)),
							},
						},
					},					
					-- Gui.Label ""
					-- {
						-- Size = Vector2(200, 46),
						-- Text = lang:GetText("剩余时间:"),
						-- FontSize = 20,
						-- TextColor = ARGB(255, 255, 181, 2),
						-- Location = Vector2(230, 1),
					-- },
					
					-- Gui.AnimControl "card_timer"
					-- {
						-- Size = Vector2(40,46),
						-- Location  = Vector2(340,1),
						-- BackgroundColor = ARGB(0, 255, 255, 255),
						
						-- EventFinish = function(Sender,e)
							-- isTurncard = false
							-- local state = ptr_cast(game.CurrentState,"Client.StateBalance")
							-- local args = {pid = state:GetMyClientInfo().character_id}
							-- rpc.safecall("stage_clear_open_timeout",args,TurnAllCard,function() MessageBox.CloseWaiter() end)
						-- end
					-- },
				},
				
				Gui.Control "ctrl_popup_card_container"
				{
					Size = Vector2(491,491),
					Location = Vector2(11,126),
					BackgroundColor = ARGB(255, 255, 255, 255),
					
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_summary_flop_bg_04.dds", Vector4(30 , 30, 30, 30)),
					},
					
				},
			},
		},
		
		Gui.Control "ctrl_popup_card_title"
		{
			Size = Vector2(1072,260),
			Location = Vector2(64,155),
			BackgroundColor = ARGB(255, 255, 255, 255),
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_summary_flop_title_bg.dds", Vector4(0,0,0,0)),
			},
			
			Gui.Control "ctrl_popup_card_bg"
			{
				Size = Vector2(200,200),
				Location = Vector2(436, 5),
				BackgroundColor = ARGB(255, 255, 255, 255),
				
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_exp_ico_75_80.dds", Vector4(0,0,0,0)),
				},
			},
			
			Gui.Control
			{
				Size = Vector2(60, 105),
				Location = Vector2(529, 46),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Gui.Control "big_bg_one"
				{
					Size = Vector2(60, 105),
					Location = Vector2(0, 0),
					BackgroundColor = ARGB(255, 255, 255, 255),
				},
				Gui.Control "big_one"
				{
					Size = Vector2(60, 105 * (4+97)/105),
					Location = Vector2(0, 105 * (1 - (4+97)/105)),
					BackgroundColor = ARGB(255, 255, 255, 255),
				},
			},
			Gui.Control
			{
				Size = Vector2(60, 105),
				Location = Vector2(483, 46),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Gui.Control "big_bg_ten"
				{
					Size = Vector2(60, 105),
					Location = Vector2(0, 0),
					BackgroundColor = ARGB(255, 255, 255, 255),
				},
				Gui.Control "big_ten"
				{
					Size = Vector2(60, 105 * (4+97)/105),
					Location = Vector2(0, 105 * (1 - (4+97)/105)),
					BackgroundColor = ARGB(255, 255, 255, 255),
				},
			},
		},
	}
}
card_pve_window = nil
card_pve_window_ui1 =  Gui.Create()
{	
	Gui.Control "ctrl_popup_card_window"
	{
		Size = Vector2(1200,1200),
		Location = Vector2(0,0),
		BackgroundColor = ARGB(0, 255, 255, 255),
		
		Gui.Control "ctrl_popup_card_content"
		{
			Size = Vector2(1080,760),
			Location = Vector2(60,274),
			BackgroundColor = ARGB(255, 255, 255, 255),
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/WarZone/Present/lb_gift_biew_bg1.dds", Vector4(200,104,105,48)),
			},
			
			Gui.Control "ctrl_popup_card_Score"
			{
				Size = Vector2(513,625),
				Location = Vector2(22,79),
				BackgroundColor = ARGB(255, 255, 255, 255),
				
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_summary_flop_bg_04.dds", Vector4(30 , 30, 30, 30)),
				},
				
				Gui.Control "ct_get_score"
				{
					Size = Vector2(471,47),
					Location = Vector2(19,67),
					BackgroundColor = ARGB(255, 255, 255, 255),
					
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_summary_flop_bg_02.dds", Vector4(20 , 20, 20, 20)),
					},
					
					Gui.Label "jifen1"
					{
						Size = Vector2(400, 46),
						Text = lang:GetText(""),
						FontSize = 20,
						TextColor = ARGB(255, 255, 181, 2),
						Location = Vector2(15, 1),
						TextAlign = "kAlignLeftMiddle",
					},
					Gui.Control "negative1"
					{
						Size = Vector2(32,44),
						Location = Vector2(261,1),
						BackgroundColor = ARGB(255, 255, 255, 255),
						
						Skin = Gui.ControlSkin
						{
							-- BackgroundImage = Gui.Image("InGameUI/lb_summary_number_reduce.dds", Vector4(20 , 20, 20, 20)),
						},
					},
					Gui.AnimControl "ScrollScore"
					{
						Size = Vector2(330,44),
						Location  = Vector2(108,1),
						BackgroundColor = ARGB(0, 255, 255, 255),
					},
					
					Gui.Label "Unit"
					{
						Size = Vector2(100,46),
						Location  = Vector2(412,1),
						Text = lang:GetText("积分"),
						FontSize = 20,
						TextColor = ARGB(255, 255, 181, 2),
					},
				},
				Gui.Control "ct_get_vipscore"
				{
					Size = Vector2(471,47),
					Location = Vector2(19,121),
					BackgroundColor = ARGB(255, 255, 255, 255),
					
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_summary_flop_bg_02.dds", Vector4(20 , 20, 20, 20)),
					},
					
					Gui.Label ""
					{
						Size = Vector2(400, 46),
						Text = lang:GetText("获得VIP经验"),
						FontSize = 20,
						TextColor = ARGB(255, 255, 181, 2),
						Location = Vector2(15, 1),
						TextAlign = "kAlignLeftMiddle",
					},
					Gui.AnimControl "vipScrollScore"
					{
						Size = Vector2(330,44),
						Location  = Vector2(88,1),
						BackgroundColor = ARGB(0, 255, 255, 255),
					},
					
					Gui.Label "vipUnit"
					{
						Size = Vector2(100,46),
						Location  = Vector2(392,1),
						Text = lang:GetText("经验"),
						FontSize = 20,
						TextColor = ARGB(255, 255, 181, 2),
					},
				},
				
				
				Gui.Control "ct_get_exp"
				{
					Size = Vector2(471,135),
					Location = Vector2(19,170),
					BackgroundColor = ARGB(255, 255, 255, 255),
					
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_summary_flop_bg_03.dds", Vector4(30 , 30, 30, 30)),
					},
					
					Gui.Label ""
					{
						Size = Vector2(200, 46),
						Text = lang:GetText("获得经验:"),
						FontSize = 20,
						TextColor = ARGB(255, 255, 181, 2),
						Location = Vector2(15, 1),
						TextAlign = "kAlignLeftMiddle",
					},
					Gui.AnimControl "Scrollexp"
					{
						Size = Vector2(198,44),
						Location  = Vector2(240,4),
						BackgroundColor = ARGB(0, 255, 255, 255),
					},
					
					Gui.Label "Unit"
					{
						Size = Vector2(100,46),
						Location  = Vector2(412,1),
						Text = lang:GetText("经验"),
						FontSize = 20,
						TextColor = ARGB(255, 255, 181, 2),
					},
					
					Gui.Label ""
					{
						Size = Vector2(180,44),
						Location  = Vector2(5,45),
						Text = lang:GetText("基础获得"),
						FontSize = 16,
						TextColor = ARGB(255, 255, 181, 2),
						TextAlign = "kAlignLeftMiddle",
					},
					
					Gui.Label "scrollexp_base_get"
					{
						Size = Vector2(125,44),
						Location  = Vector2(190,45),
						Text = "10%",
						FontSize = 16,
						TextColor = ARGB(255, 219, 138, 56),
					},
					
					Gui.Label ""
					{
						Size = Vector2(180,44),
						Location  = Vector2(250,45),
						Text = "VIP",
						FontSize = 16,
						TextColor = ARGB(255, 255, 181, 2),
						TextAlign = "kAlignLeftMiddle",
					},
					
					Gui.Label "scrollexp_vip"
					{
						Size = Vector2(125,44),
						Location  = Vector2(435,45),
						Text = "10%",
						FontSize = 16,
						TextColor = ARGB(255, 219, 138, 56),
					},
					
					Gui.Label ""
					{
						Size = Vector2(180,44),
						Location  = Vector2(5,66),
						Text = lang:GetText("战队"),
						FontSize = 16,
						TextColor = ARGB(255, 255, 181, 2),
						TextAlign = "kAlignLeftMiddle",
					},
					
					Gui.Label "scrollexp_battle"
					{
						Size = Vector2(125,44),
						Location  = Vector2(190,66),
						Text = "10%",
						FontSize = 16,
						TextColor = ARGB(255, 219, 138, 56),
					},
					
					Gui.Label ""
					{
						Size = Vector2(180,44),
						Location  = Vector2(250,66),
						Text = lang:GetText("网吧"),
						FontSize = 16,
						TextColor = ARGB(255, 255, 181, 2),
						TextAlign = "kAlignLeftMiddle",
					},
					
					Gui.Label "scrollexp_cab"
					{
						Size = Vector2(125,44),
						Location  = Vector2(435,66),
						Text = "10%",
						FontSize = 16,
						TextColor = ARGB(255, 219, 138, 56),
					},
					
					Gui.Label ""
					{
						Size = Vector2(180,44),
						Location  = Vector2(5,87),
						Text = lang:GetText("活动"),
						FontSize = 16,
						TextColor = ARGB(255, 255, 181, 2),
						TextAlign = "kAlignLeftMiddle",
					},
					
					Gui.Label "scrollexp_activity"
					{
						Size = Vector2(125,44),
						Location  = Vector2(190,87),
						Text = "0%",
						FontSize = 16,
						TextColor = ARGB(255, 219, 138, 56),
					},
					Gui.Label ""
					{
						Size = Vector2(180,44),
						Location  = Vector2(250,87),
						Text = lang:GetText("道具"),
						FontSize = 16,
						TextColor = ARGB(255, 255, 181, 2),
						TextAlign = "kAlignLeftMiddle",
					},
					
					Gui.Label "scrollexp_daoju"
					{
						Size = Vector2(125,44),
						Location  = Vector2(435,87),
						Text = "10%",
						FontSize = 16,
						TextColor = ARGB(255, 219, 138, 56),
					},
					
				},
				
				Gui.Control "ct_get_eng"
				{
					Size = Vector2(471,135),
					Location = Vector2(19,327),
					BackgroundColor = ARGB(255, 255, 255, 255),
					
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_summary_flop_bg_03.dds", Vector4(30 , 30, 30, 30)),
					},
					
					Gui.Label ""
					{
						Size = Vector2(200, 46),
						Text = lang:GetText("获得C币:"),
						FontSize = 20,
						TextColor = ARGB(255, 255, 181, 2),
						Location = Vector2(15, 1),
					},
					
					Gui.AnimControl "Scrolleng"
					{
						Size = Vector2(198,44),
						Location  = Vector2(220,4),
						BackgroundColor = ARGB(0, 255, 255, 255),
					},
										
					Gui.Label "Unit"
					{
						Size = Vector2(100,46),
						Location  = Vector2(392,1),
						Text = lang:GetText("C币"),
						FontSize = 20,
						TextColor = ARGB(255, 255, 181, 2),
					},
					Gui.Label ""
					{
						Size = Vector2(180,44),
						Location  = Vector2(5,45),
						Text = lang:GetText("基础获得"),
						FontSize = 16,
						TextColor = ARGB(255, 255, 181, 2),
						TextAlign = "kAlignLeftMiddle",
					},

					Gui.Label "scrolleng_base_get"
					{
						Size = Vector2(125,44),
						Location  = Vector2(190,45),
						Text = "10%",
						FontSize = 16,
						TextColor = ARGB(255, 219, 138, 56),
					},
					
					Gui.Label ""
					{
						Size = Vector2(180,44),
						Location  = Vector2(250,45),
						Text = "VIP",
						FontSize = 16,
						TextColor = ARGB(255, 255, 181, 2),
						TextAlign = "kAlignLeftMiddle",
					},
					
					Gui.Label "scrolleng_vip"
					{
						Size = Vector2(125,44),
						Location  = Vector2(435,45),
						Text = "10%",
						FontSize = 16,
						TextColor = ARGB(255, 219, 138, 56),
					},
					
					Gui.Label ""
					{
						Size = Vector2(180,44),
						Location  = Vector2(5,66),
						Text = lang:GetText("战队"),
						FontSize = 16,
						TextColor = ARGB(255, 255, 181, 2),
						TextAlign = "kAlignLeftMiddle",
					},
					
					Gui.Label "scrolleng_battle"
					{
						Size = Vector2(125,44),
						Location  = Vector2(190,66),
						Text = "10%",
						FontSize = 16,
						TextColor = ARGB(255, 219, 138, 56),
					},
					
					Gui.Label ""
					{
						Size = Vector2(180,44),
						Location  = Vector2(250,66),
						Text = lang:GetText("网吧"),
						FontSize = 16,
						TextColor = ARGB(255, 255, 181, 2),
						TextAlign = "kAlignLeftMiddle",
					},
					
					Gui.Label "scrolleng_cab"
					{
						Size = Vector2(125,44),
						Location  = Vector2(435,66),
						Text = "10%",
						FontSize = 16,
						TextColor = ARGB(255, 219, 138, 56),
					},
					
					Gui.Label ""
					{
						Size = Vector2(180,44),
						Location  = Vector2(5,87),
						Text = lang:GetText("活动"),
						FontSize = 16,
						TextColor = ARGB(255, 255, 181, 2),
						TextAlign = "kAlignLeftMiddle",
					},
					
					Gui.Label "scrolleng_activity"
					{
						Size = Vector2(125,44),
						Location  = Vector2(190,87),
						Text = "0%",
						FontSize = 16,
						TextColor = ARGB(255, 219, 138, 56),
					},
					Gui.Label ""
					{
						Size = Vector2(180,44),
						Location  = Vector2(250,87),
						Text = lang:GetText("道具"),
						FontSize = 16,
						TextColor = ARGB(255, 255, 181, 2),
						TextAlign = "kAlignLeftMiddle",
					},
					
					Gui.Label "scrolleng_daoju"
					{
						Size = Vector2(125,44),
						Location  = Vector2(435,87),
						Text = "10%",
						FontSize = 16,
						TextColor = ARGB(255, 219, 138, 56),
					},
				},
				
				Gui.Control "ct_get_chance"
				{
					Size = Vector2(471,135),
					Location = Vector2(19,475),
					BackgroundColor = ARGB(255, 255, 255, 255),
					
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_summary_flop_bg_03.dds", Vector4(30 , 30, 30, 30)),
					},
					
					Gui.Label "chance_times"
					{
						Size = Vector2(300, 46),
						Text = lang:GetText("你总共获得了  次翻牌机会"),
						FontSize = 20,
						TextColor = ARGB(255, 255, 181, 2),
						Location = Vector2(15, 1),
					},
					Gui.Label ""
					{
						Size = Vector2(180,44),
						Location  = Vector2(5,45),
						Text = lang:GetText("基础获得"),
						FontSize = 16,
						TextColor = ARGB(255, 255, 181, 2),
						TextAlign = "kAlignLeftMiddle",
					},
					
					Gui.Label "scrollchance_base_get"
					{
						Size = Vector2(125,44),
						Location  = Vector2(190,45),
						Text = "10%",
						FontSize = 16,
						TextColor = ARGB(255, 219, 138, 56),
					},
					
					Gui.Label ""
					{
						Size = Vector2(180,44),
						Location  = Vector2(250,45),
						Text = "VIP",
						FontSize = 16,
						TextColor = ARGB(255, 255, 181, 2),
						TextAlign = "kAlignLeftMiddle",
					},
					
					Gui.Label "scrollchance_vip"
					{
						Size = Vector2(125,44),
						Location  = Vector2(435,45),
						Text = "10%",
						FontSize = 16,
						TextColor = ARGB(255, 219, 138, 56),
					},
					
					Gui.Label ""
					{
						Size = Vector2(180,44),
						Location  = Vector2(5,66),
						Text = lang:GetText("网吧"),
						FontSize = 16,
						TextColor = ARGB(255, 255, 181, 2),
						TextAlign = "kAlignLeftMiddle",
					},
					
					Gui.Label "scrollchance_cab"
					{
						Size = Vector2(125,44),
						Location  = Vector2(190,66),
						Text = "10%",
						FontSize = 16,
						TextColor = ARGB(255, 219, 138, 56),
					},
					
					Gui.Label ""
					{
						Size = Vector2(100,44),
						Location  = Vector2(250,66),
						Text = lang:GetText("活动"),
						FontSize = 16,
						TextColor = ARGB(255, 255, 181, 2),
					},
					
					Gui.Label "scrollchance_activity"
					{
						Size = Vector2(125,44),
						Location  = Vector2(435,66),
						Text = "0%",
						FontSize = 16,
						TextColor = ARGB(255, 219, 138, 56),
					},
				},
			},
			
			Gui.Control "ctrl_popup_card_animation"
			{
				Size = Vector2(513,320),
				Location = Vector2(545,79),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_summary_flop_bg_04.dds", Vector4(30 , 30, 30, 30)),
				},
				
				Gui.Label
				{
					Size = Vector2(513,40),
					Location = Vector2(0,11),
					BackgroundColor = ARGB(255, 255, 255, 255),
					TextAlign = "kAlignCenterMiddle",
					Text = lang:GetText("胜利翻牌奖励"),
					TextColor = ARGB(255, 255, 133, 0),
					FontSize = 30,
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/GameBalance/ig_bo2_reward_title_02.dds", Vector4(0 , 0, 0, 0)),
					},
				},
				Gui.Control
				{
					Size = Vector2(486,47),
					Location = Vector2(13,55),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_summary_flop_bg_02.dds", Vector4(20, 20, 20, 20)),
					},
					Gui.Label ""
					{
						Size = Vector2(200, 46),
						Text = lang:GetText("剩余次数:"),
						FontSize = 20,
						TextColor = ARGB(255, 255, 181, 2),
						Location = Vector2(22, 0),
						Visible = false,
					},
					
					Gui.Label "left_turncard_chance"
					{
						Size = Vector2(100, 46),
						Text = "3",
						FontSize = 24,
						TextColor = ARGB(255, 219, 138, 56),
						Location = Vector2(139, 0),
						Visible = false,
					},
					
					Gui.Label ""
					{
						Size = Vector2(200, 46),
						Text = lang:GetText("剩余时间:"),
						FontSize = 20,
						TextColor = ARGB(255, 255, 181, 2),
						Location = Vector2(160, 0),
					},
					
					Gui.AnimControl "card_timer"
					{
						Size = Vector2(40,46),
						Location  = Vector2(272,0),
						BackgroundColor = ARGB(0, 255, 255, 255),
						
						EventFinish = function(Sender,e)
						isTurncard = false
						local state = ptr_cast(game.CurrentState,"Client.StateBalance")
						local args = {pid = state:GetMyClientInfo().character_id}
						rpc.safecall("stage_clear_open_timeout",args,TurnAllCard,function() MessageBox.CloseWaiter() end)
					end
					},
				},
				
				Gui.Control "ctrl_popup_card_container"
				{
					Size = Vector2(492,167),
					Location = Vector2(11,126),
					BackgroundColor = ARGB(255, 255, 255, 255),
					
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_summary_flop_bg_02.dds", Vector4(20 , 20, 20, 20)),
					},
				},
			},
			
			Gui.Control "ctrl_get_boss_item"
			{
				Size = Vector2(513,296),
				Location = Vector2(545,407),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_summary_flop_bg_04.dds", Vector4(30 , 30, 30, 30)),
				},
				
				Gui.Label"reward"
				{
					Size = Vector2(513,40),
					Location = Vector2(0,11),
					BackgroundColor = ARGB(255, 255, 255, 255),
					TextAlign = "kAlignCenterMiddle",
					Text = lang:GetText("VIP额外宝箱奖励"),
					TextColor = ARGB(255, 255, 133, 0),
					FontSize = 30,
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/GameBalance/ig_bo2_reward_title_02.dds", Vector4(0 , 0, 0, 0)),
					},
				},
				Gui.Control "ctrl_boss_get_container"
				{
					Size = Vector2(484,183),
					Location = Vector2(14,74),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_summary_flop_bg_02.dds", Vector4(20, 20, 20, 20)),
					},
					Gui.Control
					{
						Size = Vector2(84,84),
						Location = Vector2(10,30),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_synthesis_common_slot.dds", Vector4(0, 0, 0, 0)),
						},		
						Gui.Control"shengcunvip_0"
						{
							Size = Vector2(75,75),
							Location = Vector2(2,2),
							BackgroundColor = ARGB(255, 255, 255, 255),						
							Skin = Gui.ControlSkin
							{
						
							},
						},	
										
					},
					Gui.Control
					{
						Size = Vector2(84,84),
						Location = Vector2(105,30),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_synthesis_common_slot.dds", Vector4(0, 0, 0, 0)),
						},
						Gui.Control"shengcunvip_1"
						{
							Size = Vector2(75,75),
							Location = Vector2(2,2),
							BackgroundColor = ARGB(255, 255, 255, 255),					
							Skin = Gui.ControlSkin
							{
							
							},
						},												
					},
					Gui.Control
					{
						Size = Vector2(84,84),
						Location = Vector2(200,30),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_synthesis_common_slot.dds", Vector4(0, 0, 0, 0)),
						},
						Gui.Control"shengcunvip_4"
						{
							Size = Vector2(75,75),
							Location = Vector2(2,2),
							BackgroundColor = ARGB(255, 255, 255, 255),					
							Skin = Gui.ControlSkin
							{
							
							},
						},						
					},
					Gui.Control"shengcunSvipyin_01"
					{
						Size = Vector2(84,84),
						Location = Vector2(295,30),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_synthesis_common_slot.dds", Vector4(0, 0, 0, 0)),
						},
						Gui.Control"shengcunSvipyin_0"
						{
							Size = Vector2(75,75),
							Location = Vector2(2,2),
							BackgroundColor = ARGB(255, 255, 255, 255),		
							Skin = Gui.ControlSkin
							{
							
							},							
						},
					},
					Gui.Control"shengcunSvipyin_11"
					{
						Size = Vector2(84,84),
						Location = Vector2(390,30),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_synthesis_common_slot.dds", Vector4(0, 0, 0, 0)),
						},
						Gui.Control"shengcunSvipyin_1"
						{
							Size = Vector2(75,75),
							Location = Vector2(2,2),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Skin = Gui.ControlSkin
							{
							
							},
						},
					},
					
					Gui.Label "VIP0"
					{
						Size = Vector2(100, 46),
						Text = lang:GetText("VIP0"),
						FontSize = 16,
						TextColor = ARGB(255, 255, 181, 2),
						Location = Vector2(35, 100),
					},
					Gui.Label "VIP1"
					{
						Size = Vector2(100, 46),
						Text = lang:GetText("VIP1解锁"),
						FontSize = 16,
						TextColor = ARGB(255, 255, 181, 2),
						Location = Vector2(115, 100),
					},
					Gui.Label "VIP4"
					{
						Size = Vector2(100, 46),
						Text = lang:GetText("VIP4解锁"),
						FontSize = 16,
						TextColor = ARGB(255, 255, 181, 2),
						Location = Vector2(210, 100),
					},
					Gui.Label "VIP7"
					{
						Size = Vector2(100, 46),
						Text = lang:GetText("银钻尊享"),
						FontSize = 16,
						TextColor = ARGB(255, 255, 181, 2),
						Location = Vector2(305, 100),
					},
					Gui.Label "VIP8"
					{
						Size = Vector2(100, 46),
						Text = lang:GetText("金钻尊享"),
						FontSize = 16,
						TextColor = ARGB(255, 255, 181, 2),
						Location = Vector2(395, 100),
					},
				},	
			},
		},
		
		Gui.Control "ctrl_popup_card_title"
		{
			Size = Vector2(1072,260),
			Location = Vector2(64,155),
			BackgroundColor = ARGB(255, 255, 255, 255),
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_summary_flop_title_bg.dds", Vector4(0,0,0,0)),
			},
			
			Gui.Control "ctrl_popup_card_bg"
			{
				Size = Vector2(200,200),
				Location = Vector2(436, 5),
				BackgroundColor = ARGB(255, 255, 255, 255),
				
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_exp_ico_75_80.dds", Vector4(0,0,0,0)),
				},
			},
			
			Gui.Control
			{
				Size = Vector2(60, 105),
				Location = Vector2(529, 46),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Gui.Control "big_bg_one"
				{
					Size = Vector2(60, 105),
					Location = Vector2(0, 0),
					BackgroundColor = ARGB(255, 255, 255, 255),
				},
				Gui.Control "big_one"
				{
					Size = Vector2(60, 105 * (4+97)/105),
					Location = Vector2(0, 105 * (1 - (4+97)/105)),
					BackgroundColor = ARGB(255, 255, 255, 255),
				},
			},
			Gui.Control
			{
				Size = Vector2(60, 105),
				Location = Vector2(483, 46),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Gui.Control "big_bg_ten"
				{
					Size = Vector2(60, 105),
					Location = Vector2(0, 0),
					BackgroundColor = ARGB(255, 255, 255, 255),
				},
				Gui.Control "big_ten"
				{
					Size = Vector2(60, 105 * (4+97)/105),
					Location = Vector2(0, 105 * (1 - (4+97)/105)),
					BackgroundColor = ARGB(255, 255, 255, 255),
				},
			},
		},
	}
}




card_pve_match_window = nil
card_pve_match_window_ui =  Gui.Create()
{	
	Gui.Control "ctrl_popup_card_window"
	{
		Size = Vector2(1200,1200),
		Location = Vector2(0,0),
		BackgroundColor = ARGB(0, 255, 255, 255),
		
		Gui.Control "ctrl_popup_card_content"
		{
			Size = Vector2(1080,760),
			Location = Vector2(60,274),
			BackgroundColor = ARGB(255, 255, 255, 255),
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/WarZone/Present/lb_gift_biew_bg1.dds", Vector4(200,104,105,48)),
			},
			
			Gui.Control "ctrl_popup_card_Score"
			{
				Size = Vector2(513,625),
				Location = Vector2(22,79),
				BackgroundColor = ARGB(255, 255, 255, 255),
				
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_summary_flop_bg_04.dds", Vector4(30 , 30, 30, 30)),
				},
				
				Gui.Control "ct_get_score"
				{
					Size = Vector2(471,47),
					Location = Vector2(19,67),
					BackgroundColor = ARGB(255, 255, 255, 255),
					
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_summary_flop_bg_02.dds", Vector4(20 , 20, 20, 20)),
					},
					
					Gui.Label ""
					{
						Size = Vector2(400, 46),
						Text = lang:GetText("获得积分"),
						FontSize = 20,
						TextColor = ARGB(255, 255, 181, 2),
						Location = Vector2(15, 1),
						TextAlign = "kAlignLeftMiddle",
					},
					Gui.AnimControl "ScrollScore"
					{
						Size = Vector2(330,44),
						Location  = Vector2(108,1),
						BackgroundColor = ARGB(0, 255, 255, 255),
					},
					
					Gui.Label "Unit"
					{
						Size = Vector2(100,46),
						Location  = Vector2(412,1),
						Text = lang:GetText("积分"),
						FontSize = 20,
						TextColor = ARGB(255, 255, 181, 2),
					},
				},
				Gui.Control "ct_get_vipscore"
				{
					Size = Vector2(471,47),
					Location = Vector2(19,121),
					BackgroundColor = ARGB(255, 255, 255, 255),
					
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_summary_flop_bg_02.dds", Vector4(20 , 20, 20, 20)),
					},
					
					Gui.Label ""
					{
						Size = Vector2(400, 46),
						Text = lang:GetText("获得VIP经验"),
						FontSize = 20,
						TextColor = ARGB(255, 255, 181, 2),
						Location = Vector2(15, 1),
						TextAlign = "kAlignLeftMiddle",
					},
					Gui.AnimControl "vipScrollScore"
					{
						Size = Vector2(330,44),
						Location  = Vector2(88,1),
						BackgroundColor = ARGB(0, 255, 255, 255),
					},
					
					Gui.Label "vipUnit"
					{
						Size = Vector2(100,46),
						Location  = Vector2(392,1),
						Text = lang:GetText("经验"),
						FontSize = 20,
						TextColor = ARGB(255, 255, 181, 2),
					},
				},
				
				
				Gui.Control "ct_get_exp"
				{
					Size = Vector2(471,135),
					Location = Vector2(19,170),
					BackgroundColor = ARGB(255, 255, 255, 255),
					
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_summary_flop_bg_03.dds", Vector4(30 , 30, 30, 30)),
					},
					
					Gui.Label ""
					{
						Size = Vector2(200, 46),
						Text = lang:GetText("获得经验:"),
						FontSize = 20,
						TextColor = ARGB(255, 255, 181, 2),
						Location = Vector2(15, 1),
						TextAlign = "kAlignLeftMiddle",
					},
					Gui.AnimControl "Scrollexp"
					{
						Size = Vector2(198,44),
						Location  = Vector2(240,4),
						BackgroundColor = ARGB(0, 255, 255, 255),
					},
					
					Gui.Label "Unit"
					{
						Size = Vector2(100,46),
						Location  = Vector2(412,1),
						Text = lang:GetText("经验"),
						FontSize = 20,
						TextColor = ARGB(255, 255, 181, 2),
					},
					
					Gui.Label ""
					{
						Size = Vector2(180,44),
						Location  = Vector2(5,45),
						Text = lang:GetText("基础获得"),
						FontSize = 16,
						TextColor = ARGB(255, 255, 181, 2),
						TextAlign = "kAlignLeftMiddle",
					},
					
					Gui.Label "scrollexp_base_get"
					{
						Size = Vector2(125,44),
						Location  = Vector2(190,45),
						Text = "10%",
						FontSize = 16,
						TextColor = ARGB(255, 219, 138, 56),
					},
					
					Gui.Label ""
					{
						Size = Vector2(180,44),
						Location  = Vector2(250,45),
						Text = "VIP",
						FontSize = 16,
						TextColor = ARGB(255, 255, 181, 2),
						TextAlign = "kAlignLeftMiddle",
					},
					
					Gui.Label "scrollexp_vip"
					{
						Size = Vector2(125,44),
						Location  = Vector2(435,45),
						Text = "10%",
						FontSize = 16,
						TextColor = ARGB(255, 219, 138, 56),
					},
					
					Gui.Label ""
					{
						Size = Vector2(180,44),
						Location  = Vector2(5,66),
						Text = lang:GetText("战队"),
						FontSize = 16,
						TextColor = ARGB(255, 255, 181, 2),
						TextAlign = "kAlignLeftMiddle",
					},
					
					Gui.Label "scrollexp_battle"
					{
						Size = Vector2(125,44),
						Location  = Vector2(190,66),
						Text = "10%",
						FontSize = 16,
						TextColor = ARGB(255, 219, 138, 56),
					},
					
					Gui.Label ""
					{
						Size = Vector2(180,44),
						Location  = Vector2(250,66),
						Text = lang:GetText("网吧"),
						FontSize = 16,
						TextColor = ARGB(255, 255, 181, 2),
						TextAlign = "kAlignLeftMiddle",
					},
					
					Gui.Label "scrollexp_cab"
					{
						Size = Vector2(125,44),
						Location  = Vector2(435,66),
						Text = "10%",
						FontSize = 16,
						TextColor = ARGB(255, 219, 138, 56),
					},
					
					Gui.Label ""
					{
						Size = Vector2(180,44),
						Location  = Vector2(5,87),
						Text = lang:GetText("活动"),
						FontSize = 16,
						TextColor = ARGB(255, 255, 181, 2),
						TextAlign = "kAlignLeftMiddle",
					},
					
					Gui.Label "scrollexp_activity"
					{
						Size = Vector2(125,44),
						Location  = Vector2(190,87),
						Text = "0%",
						FontSize = 16,
						TextColor = ARGB(255, 219, 138, 56),
					},
					Gui.Label ""
					{
						Size = Vector2(180,44),
						Location  = Vector2(250,87),
						Text = lang:GetText("道具"),
						FontSize = 16,
						TextColor = ARGB(255, 255, 181, 2),
						TextAlign = "kAlignLeftMiddle",
					},
					
					Gui.Label "scrollexp_daoju"
					{
						Size = Vector2(125,44),
						Location  = Vector2(435,87),
						Text = "10%",
						FontSize = 16,
						TextColor = ARGB(255, 219, 138, 56),
					},
					
				},
				
				Gui.Control "ct_get_eng"
				{
					Size = Vector2(471,135),
					Location = Vector2(19,327),
					BackgroundColor = ARGB(255, 255, 255, 255),
					
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_summary_flop_bg_03.dds", Vector4(30 , 30, 30, 30)),
					},
					
					Gui.Label ""
					{
						Size = Vector2(200, 46),
						Text = lang:GetText("获得C币:"),
						FontSize = 20,
						TextColor = ARGB(255, 255, 181, 2),
						Location = Vector2(15, 1),
					},
					
					Gui.AnimControl "Scrolleng"
					{
						Size = Vector2(198,44),
						Location  = Vector2(220,4),
						BackgroundColor = ARGB(0, 255, 255, 255),
					},
										
					Gui.Label "Unit"
					{
						Size = Vector2(100,46),
						Location  = Vector2(392,1),
						Text = lang:GetText("C币"),
						FontSize = 20,
						TextColor = ARGB(255, 255, 181, 2),
					},
					Gui.Label ""
					{
						Size = Vector2(180,44),
						Location  = Vector2(5,45),
						Text = lang:GetText("基础获得"),
						FontSize = 16,
						TextColor = ARGB(255, 255, 181, 2),
						TextAlign = "kAlignLeftMiddle",
					},

					Gui.Label "scrolleng_base_get"
					{
						Size = Vector2(125,44),
						Location  = Vector2(190,45),
						Text = "10%",
						FontSize = 16,
						TextColor = ARGB(255, 219, 138, 56),
					},
					
					Gui.Label ""
					{
						Size = Vector2(180,44),
						Location  = Vector2(250,45),
						Text = "VIP",
						FontSize = 16,
						TextColor = ARGB(255, 255, 181, 2),
						TextAlign = "kAlignLeftMiddle",
					},
					
					Gui.Label "scrolleng_vip"
					{
						Size = Vector2(125,44),
						Location  = Vector2(435,45),
						Text = "10%",
						FontSize = 16,
						TextColor = ARGB(255, 219, 138, 56),
					},
					
					Gui.Label ""
					{
						Size = Vector2(180,44),
						Location  = Vector2(5,66),
						Text = lang:GetText("战队"),
						FontSize = 16,
						TextColor = ARGB(255, 255, 181, 2),
						TextAlign = "kAlignLeftMiddle",
					},
					
					Gui.Label "scrolleng_battle"
					{
						Size = Vector2(125,44),
						Location  = Vector2(190,66),
						Text = "10%",
						FontSize = 16,
						TextColor = ARGB(255, 219, 138, 56),
					},
					
					Gui.Label ""
					{
						Size = Vector2(180,44),
						Location  = Vector2(250,66),
						Text = lang:GetText("网吧"),
						FontSize = 16,
						TextColor = ARGB(255, 255, 181, 2),
						TextAlign = "kAlignLeftMiddle",
					},
					
					Gui.Label "scrolleng_cab"
					{
						Size = Vector2(125,44),
						Location  = Vector2(435,66),
						Text = "10%",
						FontSize = 16,
						TextColor = ARGB(255, 219, 138, 56),
					},
					
					Gui.Label ""
					{
						Size = Vector2(180,44),
						Location  = Vector2(5,87),
						Text = lang:GetText("活动"),
						FontSize = 16,
						TextColor = ARGB(255, 255, 181, 2),
						TextAlign = "kAlignLeftMiddle",
					},
					
					Gui.Label "scrolleng_activity"
					{
						Size = Vector2(125,44),
						Location  = Vector2(190,87),
						Text = "0%",
						FontSize = 16,
						TextColor = ARGB(255, 219, 138, 56),
					},
					Gui.Label ""
					{
						Size = Vector2(180,44),
						Location  = Vector2(250,87),
						Text = lang:GetText("道具"),
						FontSize = 16,
						TextColor = ARGB(255, 255, 181, 2),
						TextAlign = "kAlignLeftMiddle",
					},
					
					Gui.Label "scrolleng_daoju"
					{
						Size = Vector2(125,44),
						Location  = Vector2(435,87),
						Text = "10%",
						FontSize = 16,
						TextColor = ARGB(255, 219, 138, 56),
					},
				},
				
				Gui.Control "ct_get_chance"
				{
					Size = Vector2(471,135),
					Location = Vector2(19,475),
					BackgroundColor = ARGB(255, 255, 255, 255),
					
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_summary_flop_bg_03.dds", Vector4(30 , 30, 30, 30)),
					},
					
					Gui.Label "chance_times"
					{
						Size = Vector2(300, 46),
						Text = lang:GetText("你总共获得了  次翻牌机会"),
						FontSize = 20,
						TextColor = ARGB(255, 255, 181, 2),
						Location = Vector2(15, 1),
					},
					Gui.Label ""
					{
						Size = Vector2(180,44),
						Location  = Vector2(5,45),
						Text = lang:GetText("基础获得"),
						FontSize = 16,
						TextColor = ARGB(255, 255, 181, 2),
						TextAlign = "kAlignLeftMiddle",
					},
					
					Gui.Label "scrollchance_base_get"
					{
						Size = Vector2(125,44),
						Location  = Vector2(190,45),
						Text = "10%",
						FontSize = 16,
						TextColor = ARGB(255, 219, 138, 56),
					},
					
					Gui.Label ""
					{
						Size = Vector2(180,44),
						Location  = Vector2(250,45),
						Text = "VIP",
						FontSize = 16,
						TextColor = ARGB(255, 255, 181, 2),
						TextAlign = "kAlignLeftMiddle",
					},
					
					Gui.Label "scrollchance_vip"
					{
						Size = Vector2(125,44),
						Location  = Vector2(435,45),
						Text = "10%",
						FontSize = 16,
						TextColor = ARGB(255, 219, 138, 56),
					},
					
					Gui.Label ""
					{
						Size = Vector2(180,44),
						Location  = Vector2(5,66),
						Text = lang:GetText("网吧"),
						FontSize = 16,
						TextColor = ARGB(255, 255, 181, 2),
						TextAlign = "kAlignLeftMiddle",
					},
					
					Gui.Label "scrollchance_cab"
					{
						Size = Vector2(125,44),
						Location  = Vector2(190,66),
						Text = "10%",
						FontSize = 16,
						TextColor = ARGB(255, 219, 138, 56),
					},
					
					Gui.Label ""
					{
						Size = Vector2(100,44),
						Location  = Vector2(250,66),
						Text = lang:GetText("活动"),
						FontSize = 16,
						TextColor = ARGB(255, 255, 181, 2),
					},
					
					Gui.Label "scrollchance_activity"
					{
						Size = Vector2(125,44),
						Location  = Vector2(435,66),
						Text = "0%",
						FontSize = 16,
						TextColor = ARGB(255, 219, 138, 56),
					},
				},
			},
			
			Gui.Control "ctrl_popup_card_animation"
			{
				Size = Vector2(513,320),
				Location = Vector2(545,79),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_summary_flop_bg_04.dds", Vector4(30 , 30, 30, 30)),
				},
				
				Gui.Label
				{
					Size = Vector2(513,40),
					Location = Vector2(0,11),
					BackgroundColor = ARGB(255, 255, 255, 255),
					TextAlign = "kAlignCenterMiddle",
					Text = lang:GetText("胜利翻牌奖励"),
					TextColor = ARGB(255, 255, 133, 0),
					FontSize = 30,
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/GameBalance/ig_bo2_reward_title_02.dds", Vector4(0 , 0, 0, 0)),
					},
				},
				Gui.Control
				{
					Size = Vector2(486,47),
					Location = Vector2(13,55),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_summary_flop_bg_02.dds", Vector4(20, 20, 20, 20)),
					},
					Gui.Label ""
					{
						Size = Vector2(200, 46),
						Text = lang:GetText("剩余次数:"),
						FontSize = 20,
						TextColor = ARGB(255, 255, 181, 2),
						Location = Vector2(22, 0),
						Visible = false,
					},
					
					Gui.Label "left_turncard_chance"
					{
						Size = Vector2(100, 46),
						Text = "3",
						FontSize = 24,
						TextColor = ARGB(255, 219, 138, 56),
						Location = Vector2(139, 0),
						Visible = false,
					},
					
					Gui.Label ""
					{
						Size = Vector2(200, 46),
						Text = lang:GetText("剩余时间:"),
						FontSize = 20,
						TextColor = ARGB(255, 255, 181, 2),
						Location = Vector2(160, 0),
					},
					
					Gui.AnimControl "card_timer"
					{
						Size = Vector2(40,46),
						Location  = Vector2(272,0),
						BackgroundColor = ARGB(0, 255, 255, 255),
						
						EventFinish = function(Sender,e)
						isTurncard = false
						local state = ptr_cast(game.CurrentState,"Client.StateBalance")
						local args = {pid = state:GetMyClientInfo().character_id}
						rpc.safecall("stage_clear_open_timeout",args,TurnAllCard,function() MessageBox.CloseWaiter() end)
					end
					},
				},
				
				Gui.Control "ctrl_popup_card_container"
				{
					Size = Vector2(492,167),
					Location = Vector2(11,126),
					BackgroundColor = ARGB(255, 255, 255, 255),
					
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_summary_flop_bg_02.dds", Vector4(20 , 20, 20, 20)),
					},
				},
			},
			
			Gui.Control "ctrl_get_boss_item"
			{
				Size = Vector2(513,296),
				Location = Vector2(545,407),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_summary_flop_bg_04.dds", Vector4(30 , 30, 30, 30)),
				},
				
				Gui.Label
				{
					Size = Vector2(513,40),
					Location = Vector2(0,11),
					BackgroundColor = ARGB(255, 255, 255, 255),
					TextAlign = "kAlignCenterMiddle",
					Text = lang:GetText("额外奖励"),
					TextColor = ARGB(255, 255, 133, 0),
					FontSize = 30,
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/GameBalance/ig_bo2_reward_title_02.dds", Vector4(0 , 0, 0, 0)),
					},
				},
				Gui.Control "ctrl_boss_get_container"
				{
					Size = Vector2(484,183),
					Location = Vector2(14,74),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_summary_flop_bg_02.dds", Vector4(20, 20, 20, 20)),
					},
					Gui.Control
					{
						Size = Vector2(84,84),
						Location = Vector2(10,40),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_synthesis_common_slot.dds", Vector4(0, 0, 0, 0)),
						},		
						Gui.Control"jianli_1"
						{
							Size = Vector2(75,75),
							Location = Vector2(2,2),
							BackgroundColor = ARGB(255, 255, 255, 255),						
							Skin = Gui.ControlSkin
							{
						
							},
						},	
										
					},
					Gui.Control
					{
						Size = Vector2(84,84),
						Location = Vector2(105,40),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_synthesis_common_slot.dds", Vector4(0, 0, 0, 0)),
						},
						Gui.Control"jianli_2"
						{
							Size = Vector2(75,75),
							Location = Vector2(2,2),
							BackgroundColor = ARGB(255, 255, 255, 255),					
							Skin = Gui.ControlSkin
							{
							
							},
						},												
					},
					Gui.Control
					{
						Size = Vector2(84,84),
						Location = Vector2(200,40),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_synthesis_common_slot.dds", Vector4(0, 0, 0, 0)),
						},
						Gui.Control"jianli_3"
						{
							Size = Vector2(75,75),
							Location = Vector2(2,2),
							BackgroundColor = ARGB(255, 255, 255, 255),					
							Skin = Gui.ControlSkin
							{
							
							},
						},						
					},
					Gui.Control
					{
						Size = Vector2(84,84),
						Location = Vector2(295,40),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_synthesis_common_slot.dds", Vector4(0, 0, 0, 0)),
						},
						Gui.Control"jianli_4"
						{
							Size = Vector2(75,75),
							Location = Vector2(2,2),
							BackgroundColor = ARGB(255, 255, 255, 255),		
							Skin = Gui.ControlSkin
							{
							
							},							
						},
					},
					Gui.Control
					{
						Size = Vector2(84,84),
						Location = Vector2(390,40),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_synthesis_common_slot.dds", Vector4(0, 0, 0, 0)),
						},
						Gui.Control""
						{
							Size = Vector2(75,75),
							Location = Vector2(2,2),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Skin = Gui.ControlSkin
							{
							
							},
						},
					},
					
					-- Gui.Label ""
					-- {
						-- Size = Vector2(100, 46),
						-- Text = lang:GetText("VIP0"),
						-- FontSize = 16,
						-- TextColor = ARGB(255, 255, 181, 2),
						-- Location = Vector2(35, 100),
					-- },
					-- Gui.Label ""
					-- {
						-- Size = Vector2(100, 46),
						-- Text = lang:GetText("VIP1解锁"),
						-- FontSize = 16,
						-- TextColor = ARGB(255, 255, 181, 2),
						-- Location = Vector2(115, 100),
					-- },
					-- Gui.Label ""
					-- {
						-- Size = Vector2(100, 46),
						-- Text = lang:GetText("VIP4解锁"),
						-- FontSize = 16,
						-- TextColor = ARGB(255, 255, 181, 2),
						-- Location = Vector2(210, 100),
					-- },
					-- Gui.Label ""
					-- {
						-- Size = Vector2(100, 46),
						-- Text = lang:GetText("银钻尊享"),
						-- FontSize = 16,
						-- TextColor = ARGB(255, 255, 181, 2),
						-- Location = Vector2(305, 100),
					-- },
					-- Gui.Label ""
					-- {
						-- Size = Vector2(100, 46),
						-- Text = lang:GetText("金钻尊享"),
						-- FontSize = 16,
						-- TextColor = ARGB(255, 255, 181, 2),
						-- Location = Vector2(395, 100),
					-- },
				},	
			},
		},
		
		Gui.Control "ctrl_popup_card_title"
		{
			Size = Vector2(1072,260),
			Location = Vector2(64,155),
			BackgroundColor = ARGB(255, 255, 255, 255),
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_summary_flop_title_bg.dds", Vector4(0,0,0,0)),
			},
			
			Gui.Control "ctrl_popup_card_bg"
			{
				Size = Vector2(200,200),
				Location = Vector2(436, 5),
				BackgroundColor = ARGB(255, 255, 255, 255),
				
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_exp_ico_75_80.dds", Vector4(0,0,0,0)),
				},
			},
			
			Gui.Control
			{
				Size = Vector2(60, 105),
				Location = Vector2(529, 46),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Gui.Control "big_bg_one"
				{
					Size = Vector2(60, 105),
					Location = Vector2(0, 0),
					BackgroundColor = ARGB(255, 255, 255, 255),
				},
				Gui.Control "big_one"
				{
					Size = Vector2(60, 105 * (4+97)/105),
					Location = Vector2(0, 105 * (1 - (4+97)/105)),
					BackgroundColor = ARGB(255, 255, 255, 255),
				},
			},
			Gui.Control
			{
				Size = Vector2(60, 105),
				Location = Vector2(483, 46),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Gui.Control "big_bg_ten"
				{
					Size = Vector2(60, 105),
					Location = Vector2(0, 0),
					BackgroundColor = ARGB(255, 255, 255, 255),
				},
				Gui.Control "big_ten"
				{
					Size = Vector2(60, 105 * (4+97)/105),
					Location = Vector2(0, 105 * (1 - (4+97)/105)),
					BackgroundColor = ARGB(255, 255, 255, 255),
				},
			},
		},
	}
}






function ShowPopCard()
	popup_card_window_ui.ctrl_popup_card_container:OnDestroy()
	for i = 1, 9 do
		local newcard = SpawnNewCard("",i)
		Card[i] = newcard
		newcard.card.Parent = popup_card_window_ui.ctrl_popup_card_container
	end
	
	popup_card_window = ModalWindow.GetNew()
	popup_card_window.root.Size = Vector2(1200,1200)
	popup_card_window.screen.AllowEscToExit = false

	popup_card_window_ui.ctrl_popup_card_window.Parent = popup_card_window.root
end

function ShowsurvivalPopCard()
	
	card_pve_window_ui1.ctrl_popup_card_container:OnDestroy()
	for i = 1, 9 do
		local newcard = SpawnNewCard("",i)
		Card[i] = newcard
		newcard.card.Parent = card_pve_window_ui1.ctrl_popup_card_container
	end
	card_pve_window = ModalWindow.GetNew()
	card_pve_window.root.Size = Vector2(1200,1200)
	card_pve_window.screen.AllowEscToExit = false
	card_pve_window_ui1.ctrl_popup_card_window.Parent = card_pve_window.root
end
function ShowmatchPopCard()
	
	card_pve_match_window_ui.ctrl_popup_card_container:OnDestroy()
	for i = 1, 9 do
		local newcard = SpawnNewCard("",i)
		Card[i] = newcard
		newcard.card.Parent = card_pve_match_window_ui.ctrl_popup_card_container
	end
	card_pve_match_window = ModalWindow.GetNew()
	card_pve_match_window.root.Size = Vector2(1200,1200)
	card_pve_match_window.screen.AllowEscToExit = false
	card_pve_match_window_ui.ctrl_popup_card_window.Parent = card_pve_match_window.root
end

function ShowWitchBalance(data)
	print("in ShowWitchBalance")
	MessageBox.CloseWaiter()
	if data.warning then
	print("data.warning:"..data.warning)
		MessageBox.ShowWithTimer(1,data.warning)
		ptr_cast(game.CurrentState):Quit()
		return
	end
	
	 game_type = data.type
	 game_map = data.lct
	print("game_type = ",game_type)
	ModalWindow.CloseAll()
	
	if game_type == 5 then
		L_GameBossBalance.Show()
		L_GameBossBalance.SetBalance(data)
		L_GameBossBalance.ui.ctrl_window_left.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_summary_boss_left01.dds", Vector4(0, 0, 0, 0)),}
		L_GameBossBalance.ui.ctrl_window_root.Parent = gui
	elseif game_type == 9 then
		L_GameBossBalance.Show()
		L_GameBossBalance.SetBalance(data)
		L_GameBossBalance.ui.ctrl_window_left.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_re_left01.dds", Vector4(0, 0, 0, 0)),}
		L_GameBossBalance.ui.btn_save_camera.Visible = false
		L_GameBossBalance.ui.ctrl_window_root.Parent = gui
	elseif	game_type == 10 then
		L_GameBossBalance.Show()
		L_GameBossBalance.SetBalance(data)
		L_GameBossBalance.ui.ctrl_window_left.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/GameBalance/ig_bo2_boss_left01.dds", Vector4(0, 0, 0, 0)),}
		L_GameBossBalance.ui.btn_save_camera.Visible = false
		L_GameBossBalance.ui.ctrl_window_root.Parent = gui
	elseif game_type == 11 then
		L_GameBossBalance.Show()
		L_GameBossBalance.SetBalance(data)
		L_GameBossBalance.ui.ctrl_window_left.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_zb2_left01.dds", Vector4(0, 0, 0, 0)),}
		L_GameBossBalance.ui.btn_save_camera.Visible = false
		L_GameBossBalance.ui.ctrl_window_root.Parent = gui
	elseif game_type == 12 and game_map == 10 then
		InitLtvHeader(ui.list_red_team_show)
		InitLtvHeader(ui.list_blue_team_show)
		InitOtherList()
		Level_data = L_LobbyMain.LevelInfo_rpc_data
		ui.ctrl_window_root.Parent = gui
		SetBalance2(data)
	elseif game_type == 15 then
		ShowTDBalance(data)
	elseif	game_type == 18  then
		InitLtvHeader(ui.list_red_team_show)
		InitLtvHeader(ui.list_blue_team_show)
		InitOtherList()
		Level_data = L_LobbyMain.LevelInfo_rpc_data
		ui.ctrl_window_root.Parent = gui
		SetBalance1(data)
	elseif	L_WarZone.IsMatchServer() then
		InitLtvHeader1(ui.list_red_team_show)
		InitLtvHeader1(ui.list_blue_team_show)
		InitOtherList()
		Level_data = L_LobbyMain.LevelInfo_rpc_data
		ui.ctrl_window_root.Parent = gui
		SetBalance1(data)
	else
		InitLtvHeader(ui.list_red_team_show)
		InitLtvHeader(ui.list_blue_team_show)
		InitOtherList()
		Level_data = L_LobbyMain.LevelInfo_rpc_data
		ui.ctrl_window_root.Parent = gui
		SetBalance(data)
	end
end

function ShowTDBalance(data)
	local list = TD_ui.list_red_team_show
	list:DeleteColumns()
	list:AddColumn("",30, "kAlignCenterMiddle")
	list:AddColumn("",70, "kAlignLeftMiddle")
	list:AddColumn("",70, "kAlignLeftMiddle")
	list:AddColumn("",174, "kAlignLeftMiddle")
	list = TD_ui.list_blue_team_show
	list:DeleteColumns()
	list:AddColumn("",30, "kAlignCenterMiddle")
	list:AddColumn("",70, "kAlignLeftMiddle")
	list:AddColumn("",70, "kAlignLeftMiddle")
	list:AddColumn("",174, "kAlignLeftMiddle")
	Level_data = L_LobbyMain.LevelInfo_rpc_data
	TD_ui.ctrl_window_root.Parent = gui
	SetTDBalance(data)
end

---------------创建新buff---------------
function SpawnNewBuff(data)
	local BuffCon = Gui.Create(gui)
				{
					Gui.Label "LBuff"
					{
						Size = Vector2(16,16),
						BackgroundColor = ARGB(255,255,255,255),
				
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/persionalInfo/buff/buff_ammo_up_60.dds", Vector4(0, 0, 0, 0)),
						},

					},	
				}
	
	BuffCon.LBuff.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/persionalInfo/buff/buff_"..data[1]..".dds", Vector4(0, 0, 0, 0)),}
	return BuffCon
end

function Calulatebits(number)
	local bit = 0
	while number > 0 do
		number = number / 10
		number = math.floor(number)
		bit = bit + 1
	end
	
	if bit == 0 then
		bit = 1
	end
	
	return bit
end

function SetTDBalance(data)
	TD_ui.red_get.Text = lang:GetText("进攻方获得：    ")..data.winnerRes
	TD_ui.blue_get.Text = lang:GetText("防守方剩余：    ")..data.loserRes

	local team0 = data.team0
	local team1 = data.team1
	----------获得本玩家和MVP信息-----------------------
	local self = nil	--本玩家信息
	for _,v in ipairs(team0) do
		if v[2] == ptr_cast(game.CurrentState):GetMyClientInfo().name then
			self = v 
		end
	end
	for _,v in ipairs(team1) do
		if v[2] == ptr_cast(game.CurrentState):GetMyClientInfo().name then
			self = v
		end
	end
	----------如果没有找到本玩家则退出---------------------
	if not self then
		MessageBox.ShowWithTimer(1,lang:GetText("本房间游戏已结束"))
		ptr_cast(game.CurrentState):Quit()
		return
	end
	if data.winner == 0 then
		TD_ui.ctrl_red_result.Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/GameBalance/summary_win_logo.dds", Vector4(0, 0, 0, 0)),
		}
		TD_ui.ctrl_blue_result.Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/GameBalance/summary_lose_logo.dds", Vector4(0, 0, 0, 0)),
		}
	else
		TD_ui.ctrl_red_result.Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/GameBalance/summary_lose_logo.dds", Vector4(0, 0, 0, 0)),
		}
		TD_ui.ctrl_blue_result.Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/GameBalance/summary_win_logo.dds", Vector4(0, 0, 0, 0)),
		}
	end
	if L_FightTeam.SourceFightType == 0 then
		TD_ui.leader.Visible = true
		L_LobbyMain.ShowFightnums(TD_ui.my_get,tonumber(self.baseRes - self.captainRes),"GameBalance/TD/ig_js_number_l_1.dds",33,42)
		L_LobbyMain.ShowFightnums(TD_ui.leader_per,tonumber(self.captainRes),"GameBalance/TD/ig_js_number_l_1.dds",33,42)
		L_LobbyMain.ShowFightnums(TD_ui.all_num,tonumber(self.baseRes),"GameBalance/TD/ig_js_number_l_1.dds",33,42)
		L_LobbyMain.ShowFightnums(TD_ui.gongxian_get,tonumber(self.playerContribution),"GameBalance/TD/ig_js_number_l_1.dds",33,42)
		TD_ui.res_icon_red.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/team/lb_icon_res_02.dds", Vector4(0, 0, 0, 0)),}
		TD_ui.res_icon_blue.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/team/lb_icon_res_02.dds", Vector4(0, 0, 0, 0)),}
		TD_ui.res_icon_1.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/team/lb_icon_res_02_1.dds", Vector4(0, 0, 0, 0)),}
		TD_ui.res_icon_2.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/team/lb_icon_res_02_1.dds", Vector4(0, 0, 0, 0)),}
		TD_ui.res_icon_3.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/team/lb_icon_res_02_1.dds", Vector4(0, 0, 0, 0)),}
	elseif L_FightTeam.SourceFightType == 1 then
		TD_ui.leader.Visible = false
		L_LobbyMain.ShowFightnums(TD_ui.my_get,tonumber(self.baseRes),"GameBalance/TD/ig_js_number_l_1.dds",33,42)
		L_LobbyMain.ShowFightnums(TD_ui.all_num,tonumber(self.baseRes),"GameBalance/TD/ig_js_number_l_1.dds",33,42)
		L_LobbyMain.ShowFightnums(TD_ui.gongxian_get,tonumber(self.playerContribution),"GameBalance/TD/ig_js_number_l_1.dds",33,42)
		TD_ui.res_icon_red.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/team/lb_icon_res_01.dds", Vector4(0, 0, 0, 0)),}
		TD_ui.res_icon_blue.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/team/lb_icon_res_01.dds", Vector4(0, 0, 0, 0)),}
		if self.captainRes ~= 0 then
			TD_ui.res_icon_1.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/team/lb_icon_res_03.dds", Vector4(0, 0, 0, 0)),}
			TD_ui.res_icon_2.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/team/lb_icon_res_03.dds", Vector4(0, 0, 0, 0)),}
			TD_ui.res_icon_3.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/team/lb_icon_res_03.dds", Vector4(0, 0, 0, 0)),}
		else
			TD_ui.res_icon_1.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/team/lb_icon_res_02_1.dds", Vector4(0, 0, 0, 0)),}
			TD_ui.res_icon_2.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/team/lb_icon_res_02_1.dds", Vector4(0, 0, 0, 0)),}
			TD_ui.res_icon_3.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/team/lb_icon_res_02_1.dds", Vector4(0, 0, 0, 0)),}		
		end
	end
	
	--------------设置team0玩家信息------------------------
	local counter = 0
	ltv = TD_ui.list_red_team_show
	ltv:DeleteAll()
	for i,v in ipairs(team0) do
		local sub_item
		local isvip,vipicon,headicon
		sub_item = ltv:AddItem(ltv.RootItem)	
		if self == v then
			sub_item.IsSelfItem = true
		end
		isvip = v.isvip
		if isvip > 0 then
			vipicon = Gui.Icon("LobbyUI/vip/vip/VIP_button_0"..isvip.."_normal.dds", Vector4(0, 0, 0, 0))
		else
			vipicon = nil
			vipicon = Gui.Icon("LobbyUI/vip/vip/VIP_button_06_normal.dds", Vector4(0, 0, 0, 0))
		end
		if i % 2 == 0 then
          	sub_item.BGSkin = Skin.ListItemSkin_Double_balance
          	if isvip ~= 0 then
          		sub_item.BGSkin = Skin.ListItemSkin_Double_Vip_Balance
          	end 
		else
			sub_item.BGSkin = Skin.ListItemSkin_Single_balance
			if isvip ~= 0 then
				sub_item.BGSkin = Skin.ListItemSkin_Single_Vip_Balance
			end
		end
		sub_item:SetIcon(1,vipicon)
		
		if v.icon ~= "null" then
			headIcon = Gui.Icon("LobbyUI/persionalInfo/HeadPic/lb_battlefield_icon"..v.icon..".dds")
		else
			headIcon = Gui.Icon("LobbyUI/persionalInfo/HeadPic/lb_battlefield_icon02_r.dds")
		end
		sub_item:SetIcon(2,headIcon)
		sub_item:SetText(3,v[2])
		sub_item.CanSelect = false
		sub_item.ColCantSelect = true
		counter = i
	end
	L_GameBossBalance.AddRemainItem(counter,9,TD_ui.list_red_team_show)
	
	--------------设置team1玩家信息------------------------
	local counter = 0
	ltv = TD_ui.list_blue_team_show
	ltv:DeleteAll()
	for i,v in ipairs(team1) do
		local sub_item
		local isvip,vipicon,headicon
		sub_item = ltv:AddItem(ltv.RootItem)	
		if self == v then
			sub_item.IsSelfItem = true
		end
		isvip = v.isvip
		if isvip > 0 then
			vipicon = Gui.Icon("LobbyUI/vip/vip/VIP_button_0"..isvip.."_normal.dds", Vector4(0, 0, 0, 0))
		else
			vipicon = nil
			vipicon = Gui.Icon("LobbyUI/vip/vip/VIP_button_06_normal.dds", Vector4(0, 0, 0, 0))
		end
		if i % 2 == 0 then
          	sub_item.BGSkin = Skin.ListItemSkin_Double_balance
          	if isvip ~= 0 then
          		sub_item.BGSkin = Skin.ListItemSkin_Double_Vip_Balance
          	end 
		else
			sub_item.BGSkin = Skin.ListItemSkin_Single_balance
			if isvip ~= 0 then
				sub_item.BGSkin = Skin.ListItemSkin_Single_Vip_Balance
			end
		end
		sub_item:SetIcon(1,vipicon)
		
		if v.icon ~= "null" then
			headIcon = Gui.Icon("LobbyUI/persionalInfo/HeadPic/lb_battlefield_icon"..v.icon..".dds")
		else
			headIcon = Gui.Icon("LobbyUI/persionalInfo/HeadPic/lb_battlefield_icon02_r.dds")
		end
		sub_item:SetIcon(2,headIcon)
		sub_item:SetText(3,v[2])
		sub_item.CanSelect = false
		sub_item.ColCantSelect = true
		counter = i
	end
	L_GameBossBalance.AddRemainItem(counter,7,TD_ui.list_blue_team_show)
	
	for i = 1 , 15 do
		TD_ui["pic"..i]:OnDestroy()
		if data.team0costItems[i] then
			TD_ui["pic"..i].ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..data.team0costItems[i].name..".tga")
			TD_ui["l_num"..i].Text = "X"..data.team0costItems[i].costNum
			TD_ui["pic"..i].Enable = true
		else
			TD_ui["pic"..i].ItemIcon = nil
			TD_ui["l_num"..i].Text = ""
			TD_ui["pic"..i].Enable = false
		end	
	end
	
	for i = 16 , 25 do
		TD_ui["pic"..i]:OnDestroy()
		if data.team1costItems[i-15] then
			TD_ui["pic"..i].ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..data.team1costItems[i-15].name..".tga")
			TD_ui["l_num"..i].Text = "X"..data.team1costItems[i-15].costNum
			TD_ui["pic"..i].Enable = true
		else
			TD_ui["pic"..i].ItemIcon = nil
			TD_ui["l_num"..i].Text = ""
			TD_ui["pic"..i].Enable = false
		end	
	end
	
end

function SetBalance(data)
	print("in SetBalance")
	ShowPopCard()
	
	local level1 = L_LobbyMain.PersonalInfo_data.level % 10 --等级个位
	local level2 =(L_LobbyMain.PersonalInfo_data.level - level1) / 10 --等级十位
	local preson_level = math.floor((L_LobbyMain.PersonalInfo_data.level-1)/5)
	local percent
	if L_LobbyMain.PersonalInfo_data.level == 80 then
		percent = 1
	else
		percent = (L_LobbyMain.PersonalInfo_data.exp - L_LobbyMain.LevelInfo_rpc_data[L_LobbyMain.PersonalInfo_data.level][2]) / (L_LobbyMain.LevelInfo_rpc_data[L_LobbyMain.PersonalInfo_data.level + 1][2] - L_LobbyMain.LevelInfo_rpc_data[L_LobbyMain.PersonalInfo_data.level][2]) 
		percent = string.format("%.2f", percent)
	end

	popup_card_window_ui.ctrl_popup_card_bg.Skin = Gui.ControlSkin
	{
		BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_exp_ico_" ..preson_level..".dds",Vector4(0, 0, 0, 0)),
	}
	
	popup_card_window_ui.big_bg_one.Skin = Gui.ControlSkin
	{
		BackgroundImage = Gui.Image("InGameUI/lb_summary_number_6.dds",Vector4(0, 0, 0, 0),Vector4(level1 / 10, 0, (level1 + 1) / 10, 1)),
	}
	popup_card_window_ui.big_one.Skin = Gui.ControlSkin
	{
		BackgroundImage = Gui.Icon("LobbyUI/WarZone/lb_summary_number_7.dds",Vector4(0, 0, 0, 0),Vector4(level1 / 10, 1 - (4 + percent * 112) / 120, (level1 + 1) / 10, 1.0)),
	}
	popup_card_window_ui.big_one.Size = Vector2(60, 105 * ( 4 + percent * 97) / 105)
	popup_card_window_ui.big_one.Location = Vector2(0, 105 * (1 - ( 4 + percent * 97) / 105))
	popup_card_window_ui.big_bg_ten.Skin = Gui.ControlSkin
	{
		BackgroundImage = Gui.Image("InGameUI/lb_summary_number_6.dds",Vector4(0, 0, 0, 0),Vector4(level2 / 10, 0, (level2 + 1) / 10, 1)),
	}
	popup_card_window_ui.big_ten.Skin = Gui.ControlSkin
	{
		BackgroundImage = Gui.Icon("LobbyUI/WarZone/lb_summary_number_7.dds",Vector4(0, 0, 0, 0),Vector4(level2 / 10, 1 - ( 4 + percent * 112) / 120, (level2 + 1) / 10, 1.0)),
	}
	popup_card_window_ui.big_ten.Size = Vector2(60, 105 * ( 4 + percent * 97) / 105)
	popup_card_window_ui.big_ten.Location = Vector2(0, 105 * (1 - ( 4 + percent * 97) / 105))
	
	MessageBox.CloseWaiter()
	if data.warning then
		MessageBox.ShowWithTimer(1,data.warning)
		ptr_cast(game.CurrentState):Quit()
		return
	end
	
	ui.CloseTimer:AddAnim("Timer",3,4)
	ui.CloseTimer:StartAnimation()
	
	----------成就列表---------------------------------
	local achievementlist = nil
	----------获得游戏类型，红方和蓝方数据--------------
	local game_type = data.type
	local team0 = data.team0
	local team1 = data.team1
	local box,isVip
	----------获得本玩家和MVP信息-----------------------
	local self = nil	--本玩家信息
	local percentage = 0 
	local mvp_side = 0	--MVP信息
	local selfindex = 0
	local bufflist = nil
	local activity = data.activity
	local internetCafe,vipicon
	
	if data.mvp[7] < 0 then
		ui.lbl_user_weapon_info.Visible = false
		ui.ctrl_level_tens.Visible = false
		ui.ctrl_level_tens_front.Visible = false
		ui.ctrl_level_unit.Visible = false
		ui.ctrl_level_unit_front.Visible = false
	end
	
	print("activity = ",activity)
	if activity and activity > 1 then
		ui.DouExp.Visible = true
		ui.DouEng.Visible = true
		
		ui.DouExp.Skin = Gui.ControlSkin{ BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_summary_"..activity.."xexp.dds", Vector4(0, 0, 0, 0)), }
		ui.DouEng.Skin = Gui.ControlSkin{ BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_summary_"..activity.."xgp.dds", Vector4(0, 0, 0, 0)), }
	end
	
	for _,v in ipairs(team0) do
		if v[2] == ptr_cast(game.CurrentState):GetMyClientInfo().name then
			self = v 
		end
		
		if v[2] == data.mvp[3] then
			mvp_side = v[3]
		end
	end
	
	
	for _,v in ipairs(team1) do
		if v[2] == ptr_cast(game.CurrentState):GetMyClientInfo().name then
			self = v
		end
		
		if v[2] == data.mvp[3] then
			mvp_side = v[3]
		end
	end
	
	ui.ctrl_head_icon.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/persionalInfo/HeadPic/lb_info_image"..data.mvp[3]..".dds", Vector4(14, 14, 14, 14)),}
	----------如果没有找到本玩家则退出---------------------
	if not self then
		MessageBox.ShowWithTimer(1,lang:GetText("本房间游戏已结束"))
		ptr_cast(game.CurrentState):Quit()
		return
	end
	
	
	local ltv
	local redteam = 0
	local blueteam = 0
	box = self.box
	isVip = self.isvip
	
	bufflist = self.buff_list
    internetCafe = self.internetCafe
    
	if isVip > 0 then
		ui.IconVipExp.Skin = Gui.ControlSkin{ BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_button_0"..isVip.."_normal.dds", Vector4(0, 0, 0, 0)),}
		ui.IconVip.Skin = Gui.ControlSkin{ BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_button_0"..isVip.."_normal.dds", Vector4(0, 0, 0, 0)),}
		ui.IconVip1.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_button_0"..isVip.."_normal.dds", Vector4(0, 0, 0, 0)),}
		ui.IconVip2.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_button_0"..isVip.."_normal.dds", Vector4(0, 0, 0, 0)),}
		ui.ctrl_vip.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_button_0"..isVip.."_normal.dds", Vector4(0, 0, 0, 0)),}
		ui.IconVipExp.Visible = true
		ui.IconVip.Visible = true
		ui.IconVip1.Visible = true
		ui.IconVip2.Visible = true
		ui.ctrl_vip.Visible = true
	else
		ui.IconVipExp.Visible = false
		ui.IconVip.Visible = false
		ui.IconVip1.Visible = false
		ui.IconVip2.Visible = false
		ui.ctrl_vip.Visible = false
	end
	
	ui.buff_layout:OnDestroy()
	
	-- if bufflist then
		-- for i,v in ipairs(bufflist) do
			-- local buffInfo = SpawnNewBuff(v)
			-- buffInfo.LBuff.Parent = ui.buff_layout
		-- end
	-- end

	ui.realScore.Text = self[10]
	
	--------------设置MVP信息-------------------
	ui.lbl_user_weapon_name.Text = data.mvp[5]
	ui.lbl_user_name.Text = data.mvp[1]
	local mvp_WeaponLevel = data.mvp[8]
	if 	mvp_WeaponLevel > 0 then
		ui.c_user_weapon_level.Visible = true
		ui.c_user_weapon_level.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ToolTips/badge_lv"..mvp_WeaponLevel..".dds", Vector4(0, 0, 0, 0)),}
	else
		ui.c_user_weapon_level.Visible = false
	end
	local imagePath= ""
	local color = ""

	color = data.mvp[7]
	
	if color then
		if color > 1 then
			color = "_"..color
		else
			color = ""
		end
		imagePath = "LobbyUI/ibt_icon/".. data.mvp[4]..color..".tga"
	end
	
	ui.ctrl_weapon_icon.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image(imagePath, Vector4(0, 0, 0, 0)),}
	
	local ImageSize = ui.ctrl_weapon_icon.Skin.BackgroundImage.Size
	ui.ctrl_weapon_icon.Size = Vector2(ImageSize.x,ImageSize.y)
	
	--------------MVP end-----------------------
	ui.lbl_user_name_top.Text = self[2]
	
	--------------设置team0玩家信息------------------------
	for i,v in ipairs(team0) do
		local sub_item,percentage
		local rank,rankunit,rankdel,exp,icon1,icon2,headIcon
		local internetCafe
		local isvip,vipicon
		
		if v[3] == 0 then
			ltv = ui.list_red_team_show
			redteam = redteam +1
			sub_item = ltv:AddItem(ltv.RootItem,redteam)
		else
			ltv = ui.list_blue_team_show
			blueteam = blueteam +1
			sub_item = ltv:AddItem(ltv.RootItem,blueteam)
		end
			
		if self == v then
			sub_item.IsSelfItem = true
		end
		
		internetCafe = v.internetCafe
		
		bufflist = v.buff_list
		local buff_num = 0
		if bufflist then
			buff_num = table.getn(bufflist)
			for j,b in ipairs(bufflist) do
				if b and j <= 4 then
					local buffername = b[1]
					iconbuffer =  Gui.Icon("LobbyUI/persionalInfo/buff/buff_"..buffername..".dds", Vector4(0, 0, 0, 0))
					sub_item:SetIcon(7+j,iconbuffer)
				end
			end
		end
		
		isvip = v.isvip
		
		if isvip > 0 then
			vipicon = Gui.Icon("LobbyUI/vip/vip/VIP_button_0"..isvip.."_normal.dds", Vector4(0, 0, 0, 0))
		else
			vipicon = nil
		end
			
		sub_item:SetIcon(1,vipicon)
		
		if i % 2 == 0 then
          	sub_item.BGSkin = Skin.ListItemSkin_DoubleWitchCheck
          	
          	if isvip ~= 0 then
          		sub_item.BGSkin = Skin.ListItemSkin_Double_Vip_Balance
          	end 
          else
          	sub_item.BGSkin = Skin.ListItemSkin_SingleWitchCheck
          	
          	if isvip ~= 0 then
          		sub_item.BGSkin = Skin.ListItemSkin_Single_Vip_Balance
          	end
          end
          
		sub_item:SetText(5,game:StrCut(v[2],5))
		sub_item:SetText(6,v[10])
		sub_item:SetText(7,v[11])
		if buff_num > 4 then
			sub_item:SetText(12,"......")
		end	
		
		rankunit = v[7]%10 + 1
		rankdel = (v[7] - rankunit + 1)/10
		
		exp = v[5] + v[8]
		rank = v[7]
		
		rankdel = rankdel +1
		
		if Level_data then
			percentage = (exp - Level_data[rank][2])/(Level_data[rank+1][2]-Level_data[rank][2])
		end
		
		
		icon2 =  Gui.Icon("LobbyUI/WarZone/lb_summary_number_7e.dds", Vector4(0, 0, 0, 0),Vector4((rankunit-1)/10.0,(1 - ((7 + percentage * 19) / 33)),(rankunit)/10,1.0))
		icon1 =  Gui.Icon("LobbyUI/WarZone/lb_summary_number_6e.dds", Vector4(0, 0, 0, 0),Vector4((rankunit-1)/10,0,(rankunit)/10,1))
		sub_item:SetIcon(4,icon1,icon2)
		
		icon2 = Gui.Icon("LobbyUI/WarZone/lb_summary_number_7e.dds", Vector4(0, 0, 0, 0),Vector4((rankdel-1)/10.0,(1 - ((7 + percentage * 19) / 33)),(rankdel)/10,1.0))
		icon1 =Gui.Icon("LobbyUI/WarZone/lb_summary_number_6e.dds", Vector4(0, 0, 0, 0),Vector4((rankdel-1)/10,0,(rankdel)/10,1))
		sub_item:SetIcon(3,icon1,icon2)
		local num = 5
		sub_item.LV_BackgroundImage = Gui.Image("LobbyUI/lv"..(math.floor((rank - 1)/num)*num+1).."-"..(math.ceil(rank/num)*num)..".dds", Vector4(0, 0, 0, 0), Vector4(0, 0, 1, 1))
		sub_item.LV_localtion = Vector2(147,0)
		sub_item.LV_Size = Vector2(33,30)
		
		if v.icon ~= "null" then
			headIcon = Gui.Icon("LobbyUI/persionalInfo/HeadPic/lb_battlefield_icon"..v.icon..".dds")
		end
		
		sub_item:SetIcon(2,headIcon)
		
		exp = v[8]
		
		if data.winner == v[3] then
			sub_item:SetIcon(15,iconWin)
		end
		sub_item.CanSelect = false
		sub_item.ColCantSelect = true
	end
	
	--------------设置team1玩家信息------------------------
	for i,v in ipairs(team1) do
		local sub_item,percentage
		local rank,rankunit,rankdel,exp,icon1,icon2,headIcon
		local internetCafe
		local isvip,vipicon
		
		if v[3] == 0 then
			ltv = ui.list_red_team_show
			redteam = redteam +1
			sub_item = ltv:AddItem(ltv.RootItem,redteam)
		else
			ltv = ui.list_blue_team_show
			blueteam = blueteam +1
			sub_item = ltv:AddItem(ltv.RootItem,blueteam)
		end
			
		if self == v then
			sub_item.IsSelfItem = true
		end
		
		internetCafe = v.internetCafe
		
		bufflist = v.buff_list
		buff_num = 0
		if bufflist then
			buff_num = table.getn(bufflist)
			for j,b in ipairs(bufflist) do
				if b and j <= 4 then
					local buffername = b[1]
					iconbuffer =  Gui.Icon("LobbyUI/persionalInfo/buff/buff_"..buffername..".dds", Vector4(0, 0, 0, 0))
					sub_item:SetIcon(7+j,iconbuffer)
				end
			end
		end
		
		isvip = v.isvip
		if isvip > 0 then
			vipicon = Gui.Icon("LobbyUI/vip/vip/VIP_button_0"..isvip.."_normal.dds", Vector4(0, 0, 0, 0))
		else
			vipicon = nil
		end		
		sub_item:SetIcon(1,vipicon)
		
		if i % 2 == 0 then
          	sub_item.BGSkin = Skin.ListItemSkin_DoubleWitchCheck
          	
          	if isvip ~= 0 then
          		sub_item.BGSkin = Skin.ListItemSkin_Double_Vip_Balance
          	end 
          else
          	sub_item.BGSkin = Skin.ListItemSkin_SingleWitchCheck
          	
          	if isvip ~= 0 then
          		sub_item.BGSkin = Skin.ListItemSkin_Single_Vip_Balance
          	end
          end
          
		sub_item:SetText(5,game:StrCut(v[2],5))
		sub_item:SetText(6,v[10])
		sub_item:SetText(7,v[11])
		if buff_num > 4 then
			sub_item:SetText(12,"......")
		end
		
		rankunit = v[7]%10 + 1
		rankdel = (v[7] - rankunit + 1)/10
		
		exp = v[5] + v[8]
		rank = v[7]
		
		rankdel = rankdel +1
		
		if Level_data then
			percentage = (exp - Level_data[rank][2])/(Level_data[rank+1][2]-Level_data[rank][2])
		end
		
		
		icon2 =  Gui.Icon("LobbyUI/WarZone/lb_summary_number_7e.dds", Vector4(0, 0, 0, 0),Vector4((rankunit-1)/10.0,(1 - ((7 + percentage * 19) / 33)),(rankunit)/10,1.0))
		icon1 =  Gui.Icon("LobbyUI/WarZone/lb_summary_number_6e.dds", Vector4(0, 0, 0, 0),Vector4((rankunit-1)/10,0,(rankunit)/10,1))
		sub_item:SetIcon(4,icon1,icon2)
		
		icon2 = Gui.Icon("LobbyUI/WarZone/lb_summary_number_7e.dds", Vector4(0, 0, 0, 0),Vector4((rankdel-1)/10.0,(1 - ((7 + percentage * 19) / 33)),(rankdel)/10,1.0))
		icon1 =Gui.Icon("LobbyUI/WarZone/lb_summary_number_6e.dds", Vector4(0, 0, 0, 0),Vector4((rankdel-1)/10,0,(rankdel)/10,1))
		sub_item:SetIcon(3,icon1,icon2)
		local num = 5
		sub_item.LV_BackgroundImage = Gui.Image("LobbyUI/lv"..(math.floor((rank - 1)/num)*num+1).."-"..(math.ceil(rank/num)*num)..".dds", Vector4(0, 0, 0, 0), Vector4(0, 0, 1, 1))
		sub_item.LV_localtion = Vector2(147,0)
		sub_item.LV_Size = Vector2(33,30)
		
		if v.icon ~= "null" then
			headIcon = Gui.Icon("LobbyUI/persionalInfo/HeadPic/lb_battlefield_icon"..v.icon..".dds")
		end
		
		sub_item:SetIcon(2,headIcon)
		
		exp = v[8]
		
		if data.winner == v[3] then
			sub_item:SetIcon(15,iconWin)
		end
		sub_item.CanSelect = false
		sub_item.ColCantSelect = true
	end
	
	
	---------------设置胜败图标-----------------------
	
	local WinerLoserTextColor = nil
	local iconPaoge,iconButcher,iconFireman,iconOL,iconShangxiao,iconNurse,icomEngineer
	
	if data.winner ~= self[3] then
		
		ui.ctrl_result.Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/GameBalance/summary_lose_logo.dds", Vector4(0, 0, 0, 0)),
					}
					
		iconPaoge = Gui.Icon("LobbyUI/GameBalance/summary_ico_fairman_lose.dds", Vector4(0, 0, 0, 0))
		iconButcher = Gui.Icon("LobbyUI/GameBalance/summary_ico_butcher_lose.dds",Vector4(0, 0, 0, 0))
		iconFireman = Gui.Icon("LobbyUI/GameBalance/summary_ico_penhuobing_lose.dds",Vector4(0, 0, 0, 0))
		iconOL = Gui.Icon("LobbyUI/GameBalance/summary_ico_ol_lose.dds",Vector4(0, 0, 0, 0))
		iconShangxiao = Gui.Icon("LobbyUI/GameBalance/summary_ico_teamleader_lose.dds",Vector4(0, 0, 0, 0))
		iconNurse = Gui.Icon("LobbyUI/GameBalance/summary_ico_nurse_lose.dds",Vector4(0, 0, 0, 0))
		icomEngineer = Gui.Icon("LobbyUI/GameBalance/summary_ico_engineer_lose.dds",Vector4(0, 0, 0, 0))
		WinerLoserTextColor = ARGB(255,165,165,165)
	else
		ui.ctrl_result.Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/GameBalance/summary_win_logo.dds", Vector4(0, 0, 0, 0)),
					}
		
		iconPaoge = Gui.Icon("LobbyUI/GameBalance/summary_ico_fairman_win.dds", Vector4(0, 0, 0, 0))
		iconButcher = Gui.Icon("LobbyUI/GameBalance/summary_ico_butcher_win.dds",Vector4(0, 0, 0, 0))
		iconFireman = Gui.Icon("LobbyUI/GameBalance/summary_ico_penhuobing_win.dds",Vector4(0, 0, 0, 0))
		iconOL = Gui.Icon("LobbyUI/GameBalance/summary_ico_ol_win.dds",Vector4(0, 0, 0, 0))
		iconShangxiao = Gui.Icon("LobbyUI/GameBalance/summary_ico_teamleader_win.dds",Vector4(0, 0, 0, 0))
		iconNurse = Gui.Icon("LobbyUI/GameBalance/summary_ico_nurse_win.dds",Vector4(0, 0, 0, 0))
		icomEngineer = Gui.Icon("LobbyUI/GameBalance/summary_ico_engineer_win.dds",Vector4(0, 0, 0, 0))
		WinerLoserTextColor = ARGB(255,252,213,76)
	end
	
	--------------得分设置-------------------
	print("data.police_score=",data.police_score)
	print("data.terrorist_score=",data.terrorist_score)
	ui.ctrl_window_left_middle.ScrollNumRange = "0,"..data.terrorist_score
	ui.ctrl_window_right_middle.ScrollNumRange = "0,"..data.police_score
	
	ui.ctrl_window_left_middle:Reset()
	ui.ctrl_window_right_middle:Reset()
	
	--------------得分设置结束---------------
	
	local aplist = ui.list_accomplishment_show
	
	for i = 1, 5 do
		local sub_item = aplist:AddItem(aplist.RootItem)
		
		local num
		local character = nil
		local CharacterName = nil
		local icon = nil
		if i == 1 then
			sub_item:SetText(0,lang:GetText("最大爆头数"))
			num = self[17]
			character = self[18]
		elseif i == 2 then
			sub_item:SetText(0,lang:GetText("最大连杀数"))
			num = self[19]
			character = self[20]
		elseif i == 3 then
			sub_item:SetText(0,lang:GetText("最大破坏力"))
			num = self[21]
			character = self[22]
		elseif i == 4 then
			sub_item:SetText(0,lang:GetText("最大治疗量"))
			num = self[23]
			character = self[24]
		elseif i == 5 then
			local sec,minute,i = 0,0,0
			sub_item:SetText(0,lang:GetText("最长存活时间"))
			num = self[25]
			
			print(lang:GetText("存活时间 num = "),num)
			i = 0
			while num~=0 do
				if i == 0 then
					sec = num%60
				elseif i ==1 then
					minute = num % 60
				end
				
				num = num /60
				i = i+1
			end
			minute=math.floor(minute)
			num = minute..lang:GetText("分")..sec..lang:GetText("秒")
			character = self[26]
		end		
	
		if character == 1 then
			CharacterName = lang:GetText("firemanico")
			icon = iconPaoge
		elseif character == 2 then
			CharacterName = lang:GetText("butcherico")
			icon = iconButcher
		elseif character == 3 then
			CharacterName = lang:GetText("officeladyico")
			icon = iconOL
		elseif character == 4 then
			CharacterName = lang:GetText("leaderico")
			icon = iconShangxiao
		elseif character == 5 then
			CharacterName = lang:GetText("firebatico")
			icon = iconFireman
		elseif character == 6 then
			CharacterName = lang:GetText("nurseico")
			icon = iconNurse
		elseif character == 7 then
			CharacterName = lang:GetText("engineerico")
			icon = icomEngineer
		end
		
		if i % 2 == 1 then
			sub_item.BGSkin = Skin.ListItemSkin_Single_Normal_balance
		else
			sub_item.BGSkin = Skin.ListItemSkin_Double_Normal_balance
		end
		
		sub_item:SetText(1,num)
		sub_item:SetSubItemColor(1, WinerLoserTextColor)
		if character ~= 0 and CharacterName then
			sub_item:SetIcon(2,Gui.Icon("LobbyUI/GameBalance/lb_summary_"..CharacterName..".dds",Vector4(0, 0, 0, 0)))
		else
			sub_item:SetText(2,lang:GetText("未达成"))
		end
		
		-- sub_item:SetIcon(2,icon)
		if num == 0 then
			sub_item:SetText(2,lang:GetText("未达成"))
			sub_item:SetIcon(2,nil)
		end
		
		sub_item:SetSubItemColor(3, WinerLoserTextColor)
		
		sub_item.CanSelect = false
		sub_item.ColCantSelect = true
	end
	
	
	local list = ui.list_help_show
	sub_item = list:AddItem(list.RootItem)
	sub_item:SetText(0,lang:GetText("赏金击杀"))
	sub_item:SetText(1,self[13])
	sub_item.CanSelect = false
	sub_item.ColCantSelect = true
	sub_item:SetSubItemColor(1, WinerLoserTextColor)
	sub_item.BGSkin = Skin.ListItemSkin_Normal_Single
	
	sub_item = list:AddItem(list.RootItem)
	sub_item:SetText(0,lang:GetText("复仇数"))
	sub_item:SetText(1,self[14])
	sub_item:SetSubItemColor(1, WinerLoserTextColor)
	sub_item.CanSelect = false
	sub_item.ColCantSelect = true
	sub_item.BGSkin = Skin.ListItemSkin_Normal_Double
	
	list = ui.list_kill_show
	sub_item = list:AddItem(list.RootItem)
	sub_item:SetText(0,lang:GetText("助攻数"))
	sub_item:SetText(1,self[15])
	sub_item:SetSubItemColor(1, WinerLoserTextColor)
	sub_item.CanSelect = false
	sub_item.ColCantSelect = true
	sub_item.BGSkin = Skin.ListItemSkin_Normal_Single
	
	sub_item = list:AddItem(list.RootItem)
	sub_item:SetText(0,lang:GetText("近身杀人数"))
	sub_item:SetText(1,self[16])
	sub_item:SetSubItemColor(1, WinerLoserTextColor)
	sub_item.CanSelect = false
	sub_item.ColCantSelect = true
	sub_item.BGSkin = Skin.ListItemSkin_Normal_Double
	
	local team0Socre = data.terrorist_score
	local team1Socre = data.police_score
	
	
	-------------经验，能量----------------
	local exp,eng
	add_exp = self.playerTeamExp * (self.isTeamAdd + 1)
	cur_exp = self[5]
	add_eng = self.playerContribution * (self.isTeamAdd + 1)
	exp = self[8]+cur_exp
	
	if add_exp == -1 then
		ui.lbl_Battle_Full.Visible = true
	else
		ui.ctrl_get_experience_sc.ScrollNumRange = "0,"..add_exp
		ui.ctrl_get_energy_sc.ScrollNumRange = "0,"..add_eng	
		ui.ctrl_get_experience_sc:Reset()
		ui.ctrl_get_energy_sc:Reset()
		ui.lbl_Battle_Full.Visible = false
	end
	

	
	----------------弹出窗口:个人经验-----------------------------
	local curr_rank = self[4]
	local rank = self[7]
	local AddedRank = rank - curr_rank
	local rankUnit = rank%10 + 1
	local rankDel = (rank - rankUnit + 1)/10
	rankDel = rankDel +1
	
	print("curr_rank=",curr_rank)
	print("rank=",rank)
	print("AddedRank=",AddedRank)
	
	local height = 37
	local YL = ui.ctrl_level_unit_m.Location.y+ui.ctrl_level_unit_m.Size.y
	
	local num = 5
	ui.ctrl_level_background.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/lv"..(math.floor((rank - 1)/num)*num+1).."-"..(math.ceil(rank/num)*num)..".dds", Vector4(0, 0, 0, 0), Vector4(0, 0, 1, 1)),}
	
	ui.ctrl_level_unit_m.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_summary_number_6e.dds", Vector4(0, 0, 0, 0),Vector4((rankUnit-1)/10,0,(rankUnit)/10,1)),}
	ui.ctrl_level_tens_m.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_summary_number_6e.dds", Vector4(0, 0, 0, 0),Vector4((rankDel-1)/10,0,(rankDel)/10,1)),}
	
	if Level_data then
		if rank == 80 then
			percentage = 1.0
		else
			percentage = (exp - Level_data[rank][2])/(Level_data[rank+1][2]-Level_data[rank][2])
		end
	end
	
	
	height = height*percentage
	YL = YL - height
	ui.ctrl_level_unit_m_front.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_summary_number_7e.dds", Vector4(0, 0, 0, 0),Vector4((rankUnit-1)/10.0,(1 - ((7 + percentage * 19) / 33)),(rankUnit)/10,1.0)),}
	ui.ctrl_level_tens_m_front.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_summary_number_7e.dds", Vector4(0, 0, 0, 0),Vector4((rankDel-1)/10.0,(1 - ((7 + percentage * 19) / 33)),(rankDel)/10,1.0)),}
	
	ui.ctrl_level_unit_m_front.Size = Vector2(15,(7 + percentage * 19))
	ui.ctrl_level_tens_m_front.Size = Vector2(15,(7 + percentage * 19))
	ui.ctrl_level_unit_m_front.Location = Vector2(70,(44 - percentage * 19))
	ui.ctrl_level_tens_m_front.Location = Vector2(54,(44 - percentage * 19))

	----------------MVP经验-----------------------------
	local MvpRank = data.mvp[2]
	height = 37
	YL = ui.ctrl_level_unit.Location.y+ui.ctrl_level_unit.Size.y
	exp = data.mvp[6]
	
	rankUnit = MvpRank%10 + 1
	rankDel = (MvpRank-rankUnit + 1)/10
	rankDel = rankDel + 1
	
	ui.ctrl_level_unit.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_summary_number_6e.dds", Vector4(0, 0, 0, 0),Vector4((rankUnit-1)/10,0,(rankUnit)/10,1)),}
	ui.ctrl_level_tens.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_summary_number_6e.dds", Vector4(0, 0, 0, 0),Vector4((rankDel-1)/10,0,(rankDel)/10,1)),}
		
	if Level_data then
		if MvpRank == 80 then
			percentage = 1.0
		else
			percentage =(exp - Level_data[MvpRank][2])/(Level_data[MvpRank+1][2]-Level_data[MvpRank][2])
		end
	end
	
	height = height*percentage
	YL = YL - height

	ui.ctrl_level_unit_front.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_summary_number_7e.dds", Vector4(0, 0, 0, 0),Vector4((rankUnit-1)/10.0,(1 - ((7 + percentage * 19) / 33)),(rankUnit)/10,1.0-0.07),1),}
	ui.ctrl_level_tens_front.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_summary_number_7e.dds", Vector4(0, 0, 0, 0),Vector4((rankDel-1)/10.0,(1 - ((7 + percentage * 19) / 33)),(rankDel)/10,1.0-0.07),1),}
	
	ui.ctrl_level_unit_front.Size = Vector2(15,(7 + percentage * 19))
	ui.ctrl_level_tens_front.Size = Vector2(15,(7 + percentage * 19))
	ui.ctrl_level_unit_front.Location = Vector2(181,(53 - percentage * 19))
	ui.ctrl_level_tens_front.Location = Vector2(165,(53 - percentage * 19))
	
 	-------------MVP经验 end-------------------------------------------------------------
	
	
	----------------弹出窗口:能量-----------------------------
	

	
	local curr_gp = self[6]
	local EngAll = curr_gp+self[9]
	
	local ScrollAdd_exp = "0,"..self[8]
	local ScrollAdd_eng = "0,"..self[9]
	local ScrollAll_eng = curr_gp..","..EngAll
	local temp, bit = 0,0
	
	print("add_exp = "..add_exp)
	print("add_eng = "..add_eng)
	print("EngAll = "..EngAll)
	total_turn_chance = self.get_chances.totalGet
	popup_card_window_ui.left_turncard_chance.Text = total_turn_chance
	popup_card_window_ui.chance_times.Text = lang:GetText("你总共获得了")..self.get_chances.totalGet..lang:GetText("次翻牌机会")
	popup_card_window_ui.scrollchance_base_get.Text = self.get_chances.gameGet
	popup_card_window_ui.scrollchance_vip.Text =  self.get_chances.vipGet
	popup_card_window_ui.scrollchance_cab.Text = self.get_chances.netBarGet
	popup_card_window_ui.scrollchance_activity.Text = self.get_chances.activityGet

	if self.get_chances.gameGet == 1 then
		popup_card_window_ui.card_1.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("InGameUI/bottom_info/ig_common_fanpai_card_1.dds", Vector4(0 , 0, 0, 0)),}
		flag[1] = 1
	elseif self.get_chances.gameGet == 2 then
		popup_card_window_ui.card_1.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("InGameUI/bottom_info/ig_common_fanpai_card_1.dds", Vector4(0 , 0, 0, 0)),}
		popup_card_window_ui.card_2.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("InGameUI/bottom_info/ig_common_fanpai_card_1.dds", Vector4(0 , 0, 0, 0)),}
		flag[1] = 1
		flag[2] = 1
	elseif self.get_chances.gameGet == 3 then
		popup_card_window_ui.card_1.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("InGameUI/bottom_info/ig_common_fanpai_card_1.dds", Vector4(0 , 0, 0, 0)),}
		popup_card_window_ui.card_2.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("InGameUI/bottom_info/ig_common_fanpai_card_1.dds", Vector4(0 , 0, 0, 0)),}
		popup_card_window_ui.card_3.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("InGameUI/bottom_info/ig_common_fanpai_card_1.dds", Vector4(0 , 0, 0, 0)),}
		flag[1] = 1
		flag[2] = 1
		flag[3] = 1
	end
	
	if self.get_chances.vipGet > 0 then
		popup_card_window_ui.card_4.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("InGameUI/bottom_info/ig_common_fanpai_card_1.dds", Vector4(0 , 0, 0, 0)),}
		flag[4] = self.get_chances.vipGet
		popup_card_window_ui.vip_title.Text = "VIP X"..flag[4]
	else
		popup_card_window_ui.vip_title.Text = "VIP X0"
	end
	if self.get_chances.netBarGet == 1 then
		popup_card_window_ui.card_5.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("InGameUI/bottom_info/ig_common_fanpai_card_1.dds", Vector4(0 , 0, 0, 0)),}
		flag[5] = 1
	end
	if self.get_chances.activityGet == 1 then
	
		popup_card_window_ui.card_6.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("InGameUI/bottom_info/ig_common_fanpai_card_1.dds", Vector4(0 , 0, 0, 0)),}
		flag[6] = 1
	end
	popup_card_window_ui.ScrollScore:ClearAll()
	popup_card_window_ui.Scrollexp:ClearAll()
	popup_card_window_ui.Scrolleng:ClearAll()
	popup_card_window_ui.card_timer:ClearAll()
	popup_card_window_ui.vipScrollScore:ClearAll()
	
	
	popup_card_window_ui.ScrollScore:AddAnim("ScrollScore",0.5,8)
	popup_card_window_ui.Scrollexp:AddAnim("ScrollScore",0.5,8)
	popup_card_window_ui.Scrolleng:AddAnim("ScrollScore",0.5,8)
	popup_card_window_ui.card_timer:AddAnim("timer",1,3)
	popup_card_window_ui.vipScrollScore:AddAnim("ScrollScore",0.5,8)
	
	popup_card_window_ui.scrollexp_base_get.Text = self.get_exps.gameGet
	popup_card_window_ui.scrollexp_vip.Text = self.get_exps.vipGet.."%"
	popup_card_window_ui.scrollexp_cab.Text = self.get_exps.netBarGet.."%"
	popup_card_window_ui.scrollexp_activity.Text = self.get_exps.activityGet.."%"
	popup_card_window_ui.scrollexp_battle.Text = self.get_exps.teamAdd.."%"
	popup_card_window_ui.scrollexp_daoju.Text = self.get_exps.itemAdd.."%"
	
	
	popup_card_window_ui.scrolleng_base_get.Text = self.get_gps.gameGet
	popup_card_window_ui.scrolleng_vip.Text = self.get_gps.vipGet.."%"
	popup_card_window_ui.scrolleng_cab.Text = self.get_gps.netBarGet.."%"
	popup_card_window_ui.scrolleng_activity.Text = self.get_gps.activityGet.."%"
	popup_card_window_ui.scrolleng_battle.Text = self.get_gps.teamAdd.."%"
	popup_card_window_ui.scrolleng_daoju.Text = self.get_gps.itemAdd.."%"
	
	local cardback =  Gui.Image("InGameUI/lb_summary_number_l_1.dds", Vector4(0,0,0,0))
	local cardfront = Gui.Image("LobbyUI/summary_number_l_bg.dds")
	popup_card_window_ui.ScrollScore:AddFrame("ScrollScore",cardback,Vector4(0, 0, 0, 0))
	popup_card_window_ui.ScrollScore:AddFrame("ScrollScore",cardfront,Vector4(0, 0, 0, 0))
	
	
	local a = self[10]
	if a < 0 then
		bit = Calulatebits(math.abs(self[10]))
		popup_card_window_ui.negative.Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("InGameUI/lb_summary_number_reduce.dds", Vector4(20 , 20, 20, 20)),
		}
		popup_card_window_ui.ScrollScore:SetScrollParam("ScrollScore",math.abs(self[10]),bit + 1)
		popup_card_window_ui.ScrollScore.Size = Vector2((bit + 1) * 33,44)
		popup_card_window_ui.ScrollScore.Location = Vector2(471 - 33 * (bit + 2) -17 - 30,popup_card_window_ui.ScrollScore.Location.y)
	else	
		bit = Calulatebits(self[10])
		popup_card_window_ui.negative.Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image(""),
		}
		popup_card_window_ui.ScrollScore:SetScrollParam("ScrollScore",self[10],bit + 1)
		popup_card_window_ui.ScrollScore.Size = Vector2((bit + 1) * 33,44)
		popup_card_window_ui.ScrollScore.Location = Vector2(471 - 33 * (bit + 2) -17 - 30,popup_card_window_ui.ScrollScore.Location.y)
	
	end
	
	bit = Calulatebits(self.addedVipExp)
	popup_card_window_ui.vipScrollScore:AddFrame("ScrollScore",cardback,Vector4(0, 0, 0, 0))
	popup_card_window_ui.vipScrollScore:AddFrame("ScrollScore",cardfront,Vector4(0, 0, 0, 0))
	popup_card_window_ui.vipScrollScore:SetScrollParam("ScrollScore",self.addedVipExp,bit + 1)
	popup_card_window_ui.vipScrollScore.Size = Vector2((bit + 1) * 33,44)
	popup_card_window_ui.vipScrollScore.Location = Vector2(471 - 33 * (bit + 2) -17 - 30,popup_card_window_ui.vipScrollScore.Location.y)
	bit = Calulatebits(self[8])
	
	popup_card_window_ui.Scrollexp:AddFrame("ScrollScore",cardback,Vector4(0, 0, 0, 0))
	popup_card_window_ui.Scrollexp:AddFrame("ScrollScore",cardfront,Vector4(0, 0, 0, 0))
	popup_card_window_ui.Scrollexp:SetScrollParam("ScrollScore",self[8],bit + 1)
	popup_card_window_ui.Scrollexp.Size = Vector2((bit + 1) * 33,44)
	popup_card_window_ui.Scrollexp.Location = Vector2(471 - 33 * (bit + 2) -17 - 30,popup_card_window_ui.Scrollexp.Location.y)
	bit = Calulatebits(self[9])
	
	popup_card_window_ui.Scrolleng:AddFrame("ScrollScore",cardback,Vector4(0, 0, 0, 0))
	popup_card_window_ui.Scrolleng:AddFrame("ScrollScore",cardfront,Vector4(0, 0, 0, 0))
	popup_card_window_ui.Scrolleng:SetScrollParam("ScrollScore",self[9],bit + 1)
	popup_card_window_ui.Scrolleng.Size = Vector2((bit + 1) * 33,44)
	popup_card_window_ui.Scrolleng.Location = Vector2(471 - 33 * (bit + 2) -17 - 30,popup_card_window_ui.Scrolleng.Location.y)
	
	local i = 7
	while i >= 0 do
		num = Gui.Image("InGameUI/lb_summary_number_7.dds", Vector4(0,0,0,0),Vector4((i)/10.0 , 0, (i + 1)/10.0,1 ))
		popup_card_window_ui.card_timer:AddFrame("timer",num,Vector4(0, 0, 0, 0))
		i = i -1
	end
	
	popup_card_window_ui.card_timer:ReStart()
	popup_card_window_ui.card_timer:StartAnimation()
	popup_card_window_ui.Scrollexp:StartAnimation()
	popup_card_window_ui.ScrollScore:StartAnimation()
	popup_card_window_ui.Scrolleng:StartAnimation()
	popup_card_window_ui.vipScrollScore:StartAnimation()
	gui:PlayAudio("kUIA_CLOSE_TIME")
	if rank - curr_rank >= 1 and gui then
		 gui:PlayAudio("kUIA_LEVEL_UP")
	end
end

function SetBalance1(data)
	print("in SetBalance")
	ShowsurvivalPopCard()
	 if L_WarZone.IsMatchServer() then
		card_pve_window_ui1.jifen1.Text = "比赛积分"
		card_pve_window_ui1.reward.Text = "拾取到碎片奖励"
	else
		card_pve_window_ui1.jifen1.Text = "获得积分"
	end
	local level1 = L_LobbyMain.PersonalInfo_data.level % 10 --等级个位
	local level2 =(L_LobbyMain.PersonalInfo_data.level - level1) / 10 --等级十位
	local preson_level = math.floor((L_LobbyMain.PersonalInfo_data.level-1)/5)
	local percent
	if L_LobbyMain.PersonalInfo_data.level == 80 then
		percent = 1
	else
		percent = (L_LobbyMain.PersonalInfo_data.exp - L_LobbyMain.LevelInfo_rpc_data[L_LobbyMain.PersonalInfo_data.level][2]) / (L_LobbyMain.LevelInfo_rpc_data[L_LobbyMain.PersonalInfo_data.level + 1][2] - L_LobbyMain.LevelInfo_rpc_data[L_LobbyMain.PersonalInfo_data.level][2]) 
		percent = string.format("%.2f", percent)
	end

	card_pve_window_ui1.ctrl_popup_card_bg.Skin = Gui.ControlSkin
	{
		BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_exp_ico_" ..preson_level..".dds",Vector4(0, 0, 0, 0)),
	}
	
	card_pve_window_ui1.big_bg_one.Skin = Gui.ControlSkin
	{
		BackgroundImage = Gui.Image("InGameUI/lb_summary_number_6.dds",Vector4(0, 0, 0, 0),Vector4(level1 / 10, 0, (level1 + 1) / 10, 1)),
	}
	card_pve_window_ui1.big_one.Skin = Gui.ControlSkin
	{
		BackgroundImage = Gui.Icon("LobbyUI/WarZone/lb_summary_number_7.dds",Vector4(0, 0, 0, 0),Vector4(level1 / 10, 1 - (4 + percent * 112) / 120, (level1 + 1) / 10, 1.0)),
	}
	card_pve_window_ui1.big_one.Size = Vector2(60, 105 * ( 4 + percent * 97) / 105)
	card_pve_window_ui1.big_one.Location = Vector2(0, 105 * (1 - ( 4 + percent * 97) / 105))
	card_pve_window_ui1.big_bg_ten.Skin = Gui.ControlSkin
	{
		BackgroundImage = Gui.Image("InGameUI/lb_summary_number_6.dds",Vector4(0, 0, 0, 0),Vector4(level2 / 10, 0, (level2 + 1) / 10, 1)),
	}
	card_pve_window_ui1.big_ten.Skin = Gui.ControlSkin
	{
		BackgroundImage = Gui.Icon("LobbyUI/WarZone/lb_summary_number_7.dds",Vector4(0, 0, 0, 0),Vector4(level2 / 10, 1 - ( 4 + percent * 112) / 120, (level2 + 1) / 10, 1.0)),
	}
	card_pve_window_ui1.big_ten.Size = Vector2(60, 105 * ( 4 + percent * 97) / 105)
	card_pve_window_ui1.big_ten.Location = Vector2(0, 105 * (1 - ( 4 + percent * 97) / 105))
	
	MessageBox.CloseWaiter()
	if data.warning then
		MessageBox.ShowWithTimer(1,data.warning)
		ptr_cast(game.CurrentState):Quit()
		return
	end
	
	ui.CloseTimer:AddAnim("Timer",3,4)
	ui.CloseTimer:StartAnimation()
	
	----------成就列表---------------------------------
	local achievementlist = nil
	----------获得游戏类型，红方和蓝方数据--------------
	localgame_type = data.type
	local team0 = data.team0
	local team1 = data.team1
	local box,isVip
	----------获得本玩家和MVP信息-----------------------
	local self = nil	--本玩家信息
	local percentage = 0 
	local mvp_side = 0	--MVP信息
	local selfindex = 0
	local bufflist = nil
	local activity = data.activity
	local internetCafe,vipicon
	
	if data.mvp[7] < 0 then
		ui.lbl_user_weapon_info.Visible = false
		ui.ctrl_level_tens.Visible = false
		ui.ctrl_level_tens_front.Visible = false
		ui.ctrl_level_unit.Visible = false
		ui.ctrl_level_unit_front.Visible = false
	end
	
	print("activity = ",activity)
	if activity and activity > 1 then
		ui.DouExp.Visible = true
		ui.DouEng.Visible = true
		
		ui.DouExp.Skin = Gui.ControlSkin{ BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_summary_"..activity.."xexp.dds", Vector4(0, 0, 0, 0)), }
		ui.DouEng.Skin = Gui.ControlSkin{ BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_summary_"..activity.."xgp.dds", Vector4(0, 0, 0, 0)), }
	end
	
	for _,v in ipairs(team0) do
		if v[2] == ptr_cast(game.CurrentState):GetMyClientInfo().name then
			self = v 
		end
		
		if v[2] == data.mvp[3] then
			mvp_side = v[3]
		end
	end
	
	
	for _,v in ipairs(team1) do
		if v[2] == ptr_cast(game.CurrentState):GetMyClientInfo().name then
			self = v
		end
		
		if v[2] == data.mvp[3] then
			mvp_side = v[3]
		end
	end
	
	ui.ctrl_head_icon.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/persionalInfo/HeadPic/lb_info_image"..data.mvp[3]..".dds", Vector4(14, 14, 14, 14)),}
	----------如果没有找到本玩家则退出---------------------
	if not self then
		MessageBox.ShowWithTimer(1,lang:GetText("本房间游戏已结束"))
		ptr_cast(game.CurrentState):Quit()
		return
	end
	
	
	local ltv
	local redteam = 0
	local blueteam = 0
	box = self.box
	isVip = self.isvip
	
	bufflist = self.buff_list
    internetCafe = self.internetCafe
    
	if isVip > 0 then
		ui.IconVipExp.Skin = Gui.ControlSkin{ BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_button_0"..isVip.."_normal.dds", Vector4(0, 0, 0, 0)),}
		ui.IconVip.Skin = Gui.ControlSkin{ BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_button_0"..isVip.."_normal.dds", Vector4(0, 0, 0, 0)),}
		ui.IconVip1.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_button_0"..isVip.."_normal.dds", Vector4(0, 0, 0, 0)),}
		ui.IconVip2.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_button_0"..isVip.."_normal.dds", Vector4(0, 0, 0, 0)),}
		ui.ctrl_vip.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_button_0"..isVip.."_normal.dds", Vector4(0, 0, 0, 0)),}
		ui.IconVipExp.Visible = true
		ui.IconVip.Visible = true
		ui.IconVip1.Visible = true
		ui.IconVip2.Visible = true
		ui.ctrl_vip.Visible = true
	else
		ui.IconVipExp.Visible = false
		ui.IconVip.Visible = false
		ui.IconVip1.Visible = false
		ui.IconVip2.Visible = false
		ui.ctrl_vip.Visible = false
	end
	
	ui.buff_layout:OnDestroy()
	
	-- if bufflist then
		-- for i,v in ipairs(bufflist) do
			-- local buffInfo = SpawnNewBuff(v)
			-- buffInfo.LBuff.Parent = ui.buff_layout
		-- end
	-- end

	ui.realScore.Text = self[10]
	
	--------------设置MVP信息-------------------
	ui.lbl_user_weapon_name.Text = data.mvp[5]
	ui.lbl_user_name.Text = data.mvp[1]
	local mvp_WeaponLevel = data.mvp[8]
	if 	mvp_WeaponLevel > 0 then
		ui.c_user_weapon_level.Visible = true
		ui.c_user_weapon_level.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ToolTips/badge_lv"..mvp_WeaponLevel..".dds", Vector4(0, 0, 0, 0)),}
	else
		ui.c_user_weapon_level.Visible = false
	end
	local imagePath= ""
	local color = ""

	color = data.mvp[7]
	
	if color then
		if color > 1 then
			color = "_"..color
		else
			color = ""
		end
		imagePath = "LobbyUI/ibt_icon/".. data.mvp[4]..color..".tga"
	end
	
	ui.ctrl_weapon_icon.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image(imagePath, Vector4(0, 0, 0, 0)),}
	
	local ImageSize = ui.ctrl_weapon_icon.Skin.BackgroundImage.Size
	ui.ctrl_weapon_icon.Size = Vector2(ImageSize.x,ImageSize.y)
	
	--------------MVP end-----------------------
	ui.lbl_user_name_top.Text = self[2]
	
	--------------设置team0玩家信息------------------------
	for i,v in ipairs(team0) do
		local sub_item,percentage
		local rank,rankunit,rankdel,exp,icon1,icon2,headIcon
		local internetCafe
		local isvip,vipicon
		
		if v[3] == 0 then
			ltv = ui.list_red_team_show
			redteam = redteam +1
			sub_item = ltv:AddItem(ltv.RootItem,redteam)
		else
			ltv = ui.list_blue_team_show
			blueteam = blueteam +1
			sub_item = ltv:AddItem(ltv.RootItem,blueteam)
		end
			
		if self == v then
			sub_item.IsSelfItem = true
		end
		
		internetCafe = v.internetCafe
		
		bufflist = v.buff_list
		local buff_num = 0
		if bufflist then
			buff_num = table.getn(bufflist)
			for j,b in ipairs(bufflist) do
				if b and j <= 4 then
					local buffername = b[1]
					iconbuffer =  Gui.Icon("LobbyUI/persionalInfo/buff/buff_"..buffername..".dds", Vector4(0, 0, 0, 0))
					sub_item:SetIcon(7+j,iconbuffer)
				end
			end
		end
		
		isvip = v.isvip
		
		if isvip > 0 then
			vipicon = Gui.Icon("LobbyUI/vip/vip/VIP_button_0"..isvip.."_normal.dds", Vector4(0, 0, 0, 0))
		else
			vipicon = nil
		end
			
		sub_item:SetIcon(1,vipicon)
		
		if i % 2 == 0 then
          	sub_item.BGSkin = Skin.ListItemSkin_DoubleWitchCheck
          	
          	if isvip ~= 0 then
          		sub_item.BGSkin = Skin.ListItemSkin_Double_Vip_Balance
          	end 
          else
          	sub_item.BGSkin = Skin.ListItemSkin_SingleWitchCheck
          	
          	if isvip ~= 0 then
          		sub_item.BGSkin = Skin.ListItemSkin_Single_Vip_Balance
          	end
          end
          
		sub_item:SetText(5,game:StrCut(v[2],5))
		sub_item:SetText(6,v[10])
		sub_item:SetText(7,v[11])
		if buff_num > 4 then
			sub_item:SetText(12,"......")
		end	
		
		rankunit = v[7]%10 + 1
		rankdel = (v[7] - rankunit + 1)/10
		
		exp = v[5] + v[8]
		rank = v[7]
		
		rankdel = rankdel +1
		
		if Level_data then
			percentage = (exp - Level_data[rank][2])/(Level_data[rank+1][2]-Level_data[rank][2])
		end
		
		
		icon2 =  Gui.Icon("LobbyUI/WarZone/lb_summary_number_7e.dds", Vector4(0, 0, 0, 0),Vector4((rankunit-1)/10.0,(1 - ((7 + percentage * 19) / 33)),(rankunit)/10,1.0))
		icon1 =  Gui.Icon("LobbyUI/WarZone/lb_summary_number_6e.dds", Vector4(0, 0, 0, 0),Vector4((rankunit-1)/10,0,(rankunit)/10,1))
		sub_item:SetIcon(4,icon1,icon2)
		
		icon2 = Gui.Icon("LobbyUI/WarZone/lb_summary_number_7e.dds", Vector4(0, 0, 0, 0),Vector4((rankdel-1)/10.0,(1 - ((7 + percentage * 19) / 33)),(rankdel)/10,1.0))
		icon1 =Gui.Icon("LobbyUI/WarZone/lb_summary_number_6e.dds", Vector4(0, 0, 0, 0),Vector4((rankdel-1)/10,0,(rankdel)/10,1))
		sub_item:SetIcon(3,icon1,icon2)
		local num = 5
		sub_item.LV_BackgroundImage = Gui.Image("LobbyUI/lv"..(math.floor((rank - 1)/num)*num+1).."-"..(math.ceil(rank/num)*num)..".dds", Vector4(0, 0, 0, 0), Vector4(0, 0, 1, 1))
		sub_item.LV_localtion = Vector2(147,0)
		sub_item.LV_Size = Vector2(33,30)
		
		if v.icon ~= "null" then
			headIcon = Gui.Icon("LobbyUI/persionalInfo/HeadPic/lb_battlefield_icon"..v.icon..".dds")
		end
		
		sub_item:SetIcon(2,headIcon)
		
		exp = v[8]
		
		if data.winner == v[3] then
			sub_item:SetIcon(15,iconWin)
		end
		sub_item.CanSelect = false
		sub_item.ColCantSelect = true
	end
	
	--------------设置team1玩家信息------------------------
	for i,v in ipairs(team1) do
		local sub_item,percentage
		local rank,rankunit,rankdel,exp,icon1,icon2,headIcon
		local internetCafe
		local isvip,vipicon
		
		if v[3] == 0 then
			ltv = ui.list_red_team_show
			redteam = redteam +1
			sub_item = ltv:AddItem(ltv.RootItem,redteam)
		else
			ltv = ui.list_blue_team_show
			blueteam = blueteam +1
			sub_item = ltv:AddItem(ltv.RootItem,blueteam)
		end
			
		if self == v then
			sub_item.IsSelfItem = true
		end
		
		internetCafe = v.internetCafe
		
		bufflist = v.buff_list
		buff_num = 0
		if bufflist then
			buff_num = table.getn(bufflist)
			for j,b in ipairs(bufflist) do
				if b and j <= 4 then
					local buffername = b[1]
					iconbuffer =  Gui.Icon("LobbyUI/persionalInfo/buff/buff_"..buffername..".dds", Vector4(0, 0, 0, 0))
					sub_item:SetIcon(7+j,iconbuffer)
				end
			end
		end
		
		isvip = v.isvip
		if isvip > 0 then
			vipicon = Gui.Icon("LobbyUI/vip/vip/VIP_button_0"..isvip.."_normal.dds", Vector4(0, 0, 0, 0))
		else
			vipicon = nil
		end		
		sub_item:SetIcon(1,vipicon)
		
		if i % 2 == 0 then
          	sub_item.BGSkin = Skin.ListItemSkin_DoubleWitchCheck
          	
          	if isvip ~= 0 then
          		sub_item.BGSkin = Skin.ListItemSkin_Double_Vip_Balance
          	end 
          else
          	sub_item.BGSkin = Skin.ListItemSkin_SingleWitchCheck
          	
          	if isvip ~= 0 then
          		sub_item.BGSkin = Skin.ListItemSkin_Single_Vip_Balance
          	end
          end
          
		sub_item:SetText(5,game:StrCut(v[2],5))
		sub_item:SetText(6,v[10])
		sub_item:SetText(7,v[11])
		if buff_num > 4 then
			sub_item:SetText(12,"......")
		end
		
		rankunit = v[7]%10 + 1
		rankdel = (v[7] - rankunit + 1)/10
		
		exp = v[5] + v[8]
		rank = v[7]
		
		rankdel = rankdel +1
		
		if Level_data then
			percentage = (exp - Level_data[rank][2])/(Level_data[rank+1][2]-Level_data[rank][2])
		end
		
		
		icon2 =  Gui.Icon("LobbyUI/WarZone/lb_summary_number_7e.dds", Vector4(0, 0, 0, 0),Vector4((rankunit-1)/10.0,(1 - ((7 + percentage * 19) / 33)),(rankunit)/10,1.0))
		icon1 =  Gui.Icon("LobbyUI/WarZone/lb_summary_number_6e.dds", Vector4(0, 0, 0, 0),Vector4((rankunit-1)/10,0,(rankunit)/10,1))
		sub_item:SetIcon(4,icon1,icon2)
		
		icon2 = Gui.Icon("LobbyUI/WarZone/lb_summary_number_7e.dds", Vector4(0, 0, 0, 0),Vector4((rankdel-1)/10.0,(1 - ((7 + percentage * 19) / 33)),(rankdel)/10,1.0))
		icon1 =Gui.Icon("LobbyUI/WarZone/lb_summary_number_6e.dds", Vector4(0, 0, 0, 0),Vector4((rankdel-1)/10,0,(rankdel)/10,1))
		sub_item:SetIcon(3,icon1,icon2)
		local num = 5
		sub_item.LV_BackgroundImage = Gui.Image("LobbyUI/lv"..(math.floor((rank - 1)/num)*num+1).."-"..(math.ceil(rank/num)*num)..".dds", Vector4(0, 0, 0, 0), Vector4(0, 0, 1, 1))
		sub_item.LV_localtion = Vector2(147,0)
		sub_item.LV_Size = Vector2(33,30)
		
		if v.icon ~= "null" then
			headIcon = Gui.Icon("LobbyUI/persionalInfo/HeadPic/lb_battlefield_icon"..v.icon..".dds")
		end
		
		sub_item:SetIcon(2,headIcon)
		
		exp = v[8]
		
		if data.winner == v[3] then
			sub_item:SetIcon(15,iconWin)
		end
		sub_item.CanSelect = false
		sub_item.ColCantSelect = true
	end
	
	
	---------------设置胜败图标-----------------------
	
	local WinerLoserTextColor = nil
	local iconPaoge,iconButcher,iconFireman,iconOL,iconShangxiao,iconNurse,icomEngineer
	
	if data.winner ~= self[3] then
		
		ui.ctrl_result.Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/GameBalance/summary_lose_logo.dds", Vector4(0, 0, 0, 0)),
					}
					
		iconPaoge = Gui.Icon("LobbyUI/GameBalance/summary_ico_fairman_lose.dds", Vector4(0, 0, 0, 0))
		iconButcher = Gui.Icon("LobbyUI/GameBalance/summary_ico_butcher_lose.dds",Vector4(0, 0, 0, 0))
		iconFireman = Gui.Icon("LobbyUI/GameBalance/summary_ico_penhuobing_lose.dds",Vector4(0, 0, 0, 0))
		iconOL = Gui.Icon("LobbyUI/GameBalance/summary_ico_ol_lose.dds",Vector4(0, 0, 0, 0))
		iconShangxiao = Gui.Icon("LobbyUI/GameBalance/summary_ico_teamleader_lose.dds",Vector4(0, 0, 0, 0))
		iconNurse = Gui.Icon("LobbyUI/GameBalance/summary_ico_nurse_lose.dds",Vector4(0, 0, 0, 0))
		icomEngineer = Gui.Icon("LobbyUI/GameBalance/summary_ico_engineer_lose.dds",Vector4(0, 0, 0, 0))
		WinerLoserTextColor = ARGB(255,165,165,165)
	else
		ui.ctrl_result.Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/GameBalance/summary_win_logo.dds", Vector4(0, 0, 0, 0)),
					}
		
		iconPaoge = Gui.Icon("LobbyUI/GameBalance/summary_ico_fairman_win.dds", Vector4(0, 0, 0, 0))
		iconButcher = Gui.Icon("LobbyUI/GameBalance/summary_ico_butcher_win.dds",Vector4(0, 0, 0, 0))
		iconFireman = Gui.Icon("LobbyUI/GameBalance/summary_ico_penhuobing_win.dds",Vector4(0, 0, 0, 0))
		iconOL = Gui.Icon("LobbyUI/GameBalance/summary_ico_ol_win.dds",Vector4(0, 0, 0, 0))
		iconShangxiao = Gui.Icon("LobbyUI/GameBalance/summary_ico_teamleader_win.dds",Vector4(0, 0, 0, 0))
		iconNurse = Gui.Icon("LobbyUI/GameBalance/summary_ico_nurse_win.dds",Vector4(0, 0, 0, 0))
		icomEngineer = Gui.Icon("LobbyUI/GameBalance/summary_ico_engineer_win.dds",Vector4(0, 0, 0, 0))
		WinerLoserTextColor = ARGB(255,252,213,76)
	end
	
	--------------得分设置-------------------
	print("data.police_score=",data.police_score)
	print("data.terrorist_score=",data.terrorist_score)
	ui.ctrl_window_left_middle.ScrollNumRange = "0,"..data.terrorist_score
	ui.ctrl_window_right_middle.ScrollNumRange = "0,"..data.police_score
	
	ui.ctrl_window_left_middle:Reset()
	ui.ctrl_window_right_middle:Reset()
	
	--------------得分设置结束---------------
	
	local aplist = ui.list_accomplishment_show
	
	for i = 1, 5 do
		local sub_item = aplist:AddItem(aplist.RootItem)
		
		local num
		local character = nil
		local CharacterName = nil
		local icon = nil
		if i == 1 then
			sub_item:SetText(0,lang:GetText("最大爆头数"))
			num = self[17]
			character = self[18]
		elseif i == 2 then
			sub_item:SetText(0,lang:GetText("最大连杀数"))
			num = self[19]
			character = self[20]
		elseif i == 3 then
			sub_item:SetText(0,lang:GetText("最大破坏力"))
			num = self[21]
			character = self[22]
		elseif i == 4 then
			sub_item:SetText(0,lang:GetText("最大治疗量"))
			num = self[23]
			character = self[24]
		elseif i == 5 then
			local sec,minute,i = 0,0,0
			sub_item:SetText(0,lang:GetText("最长存活时间"))
			num = self[25]
			
			print(lang:GetText("存活时间 num = "),num)
			i = 0
			while num~=0 do
				if i == 0 then
					sec = num%60
				elseif i ==1 then
					minute = num % 60
				end
				
				num = num /60
				i = i+1
			end
			minute=math.floor(minute)
			num = minute..lang:GetText("分")..sec..lang:GetText("秒")
			character = self[26]
		end		
	
		if character == 1 then
			CharacterName = lang:GetText("firemanico")
			icon = iconPaoge
		elseif character == 2 then
			CharacterName = lang:GetText("butcherico")
			icon = iconButcher
		elseif character == 3 then
			CharacterName = lang:GetText("officeladyico")
			icon = iconOL
		elseif character == 4 then
			CharacterName = lang:GetText("leaderico")
			icon = iconShangxiao
		elseif character == 5 then
			CharacterName = lang:GetText("firebatico")
			icon = iconFireman
		elseif character == 6 then
			CharacterName = lang:GetText("nurseico")
			icon = iconNurse
		elseif character == 7 then
			CharacterName = lang:GetText("engineerico")
			icon = icomEngineer
		end
		
		if i % 2 == 1 then
			sub_item.BGSkin = Skin.ListItemSkin_Single_Normal_balance
		else
			sub_item.BGSkin = Skin.ListItemSkin_Double_Normal_balance
		end
		
		sub_item:SetText(1,num)
		sub_item:SetSubItemColor(1, WinerLoserTextColor)
		if character ~= 0 and CharacterName then
			sub_item:SetIcon(2,Gui.Icon("LobbyUI/GameBalance/lb_summary_"..CharacterName..".dds",Vector4(0, 0, 0, 0)))
		else
			sub_item:SetText(2,lang:GetText("未达成"))
		end
		
		-- sub_item:SetIcon(2,icon)
		if num == 0 then
			sub_item:SetText(2,lang:GetText("未达成"))
			sub_item:SetIcon(2,nil)
		end
		
		sub_item:SetSubItemColor(3, WinerLoserTextColor)
		
		sub_item.CanSelect = false
		sub_item.ColCantSelect = true
	end
	
	
	local list = ui.list_help_show
	sub_item = list:AddItem(list.RootItem)
	sub_item:SetText(0,lang:GetText("赏金击杀"))
	sub_item:SetText(1,self[13])
	sub_item.CanSelect = false
	sub_item.ColCantSelect = true
	sub_item:SetSubItemColor(1, WinerLoserTextColor)
	sub_item.BGSkin = Skin.ListItemSkin_Normal_Single
	
	sub_item = list:AddItem(list.RootItem)
	sub_item:SetText(0,lang:GetText("复仇数"))
	sub_item:SetText(1,self[14])
	sub_item:SetSubItemColor(1, WinerLoserTextColor)
	sub_item.CanSelect = false
	sub_item.ColCantSelect = true
	sub_item.BGSkin = Skin.ListItemSkin_Normal_Double
	
	list = ui.list_kill_show
	sub_item = list:AddItem(list.RootItem)
	sub_item:SetText(0,lang:GetText("助攻数"))
	sub_item:SetText(1,self[15])
	sub_item:SetSubItemColor(1, WinerLoserTextColor)
	sub_item.CanSelect = false
	sub_item.ColCantSelect = true
	sub_item.BGSkin = Skin.ListItemSkin_Normal_Single
	
	sub_item = list:AddItem(list.RootItem)
	sub_item:SetText(0,lang:GetText("近身杀人数"))
	sub_item:SetText(1,self[16])
	sub_item:SetSubItemColor(1, WinerLoserTextColor)
	sub_item.CanSelect = false
	sub_item.ColCantSelect = true
	sub_item.BGSkin = Skin.ListItemSkin_Normal_Double
	
	local team0Socre = data.terrorist_score
	local team1Socre = data.police_score
	
	
	-------------经验，能量----------------
	local exp,eng
	add_exp = self.playerTeamExp * (self.isTeamAdd + 1)
	cur_exp = self[5]
	add_eng = self.playerContribution * (self.isTeamAdd + 1)
	exp = self[8]+cur_exp
	
	if add_exp == -1 then
		ui.lbl_Battle_Full.Visible = true
	else
		ui.ctrl_get_experience_sc.ScrollNumRange = "0,"..add_exp
		ui.ctrl_get_energy_sc.ScrollNumRange = "0,"..add_eng	
		ui.ctrl_get_experience_sc:Reset()
		ui.ctrl_get_energy_sc:Reset()
		ui.lbl_Battle_Full.Visible = false
	end
	

	
	----------------弹出窗口:个人经验-----------------------------
	local curr_rank = self[4]
	local rank = self[7]
	local AddedRank = rank - curr_rank
	local rankUnit = rank%10 + 1
	local rankDel = (rank - rankUnit + 1)/10
	rankDel = rankDel +1
	
	print("curr_rank=",curr_rank)
	print("rank=",rank)
	print("AddedRank=",AddedRank)
	
	local height = 37
	local YL = ui.ctrl_level_unit_m.Location.y+ui.ctrl_level_unit_m.Size.y
	
	local num = 5
	ui.ctrl_level_background.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/lv"..(math.floor((rank - 1)/num)*num+1).."-"..(math.ceil(rank/num)*num)..".dds", Vector4(0, 0, 0, 0), Vector4(0, 0, 1, 1)),}
	
	ui.ctrl_level_unit_m.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_summary_number_6e.dds", Vector4(0, 0, 0, 0),Vector4((rankUnit-1)/10,0,(rankUnit)/10,1)),}
	ui.ctrl_level_tens_m.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_summary_number_6e.dds", Vector4(0, 0, 0, 0),Vector4((rankDel-1)/10,0,(rankDel)/10,1)),}
	
	if Level_data then
		if rank == 80 then
			percentage = 1.0
		else
			percentage = (exp - Level_data[rank][2])/(Level_data[rank+1][2]-Level_data[rank][2])
		end
	end
	
	
	height = height*percentage
	YL = YL - height
	ui.ctrl_level_unit_m_front.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_summary_number_7e.dds", Vector4(0, 0, 0, 0),Vector4((rankUnit-1)/10.0,(1 - ((7 + percentage * 19) / 33)),(rankUnit)/10,1.0)),}
	ui.ctrl_level_tens_m_front.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_summary_number_7e.dds", Vector4(0, 0, 0, 0),Vector4((rankDel-1)/10.0,(1 - ((7 + percentage * 19) / 33)),(rankDel)/10,1.0)),}
	
	ui.ctrl_level_unit_m_front.Size = Vector2(15,(7 + percentage * 19))
	ui.ctrl_level_tens_m_front.Size = Vector2(15,(7 + percentage * 19))
	ui.ctrl_level_unit_m_front.Location = Vector2(70,(44 - percentage * 19))
	ui.ctrl_level_tens_m_front.Location = Vector2(54,(44 - percentage * 19))

	----------------MVP经验-----------------------------
	local MvpRank = data.mvp[2]
	height = 37
	YL = ui.ctrl_level_unit.Location.y+ui.ctrl_level_unit.Size.y
	exp = data.mvp[6]
	
	rankUnit = MvpRank%10 + 1
	rankDel = (MvpRank-rankUnit + 1)/10
	rankDel = rankDel + 1
	
	ui.ctrl_level_unit.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_summary_number_6e.dds", Vector4(0, 0, 0, 0),Vector4((rankUnit-1)/10,0,(rankUnit)/10,1)),}
	ui.ctrl_level_tens.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_summary_number_6e.dds", Vector4(0, 0, 0, 0),Vector4((rankDel-1)/10,0,(rankDel)/10,1)),}
		
	if Level_data then
		if MvpRank == 80 then
			percentage = 1.0
		else
			percentage =(exp - Level_data[MvpRank][2])/(Level_data[MvpRank+1][2]-Level_data[MvpRank][2])
		end
	end
	
	height = height*percentage
	YL = YL - height

	ui.ctrl_level_unit_front.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_summary_number_7e.dds", Vector4(0, 0, 0, 0),Vector4((rankUnit-1)/10.0,(1 - ((7 + percentage * 19) / 33)),(rankUnit)/10,1.0-0.07),1),}
	ui.ctrl_level_tens_front.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_summary_number_7e.dds", Vector4(0, 0, 0, 0),Vector4((rankDel-1)/10.0,(1 - ((7 + percentage * 19) / 33)),(rankDel)/10,1.0-0.07),1),}
	
	ui.ctrl_level_unit_front.Size = Vector2(15,(7 + percentage * 19))
	ui.ctrl_level_tens_front.Size = Vector2(15,(7 + percentage * 19))
	ui.ctrl_level_unit_front.Location = Vector2(181,(53 - percentage * 19))
	ui.ctrl_level_tens_front.Location = Vector2(165,(53 - percentage * 19))
	
 	-------------MVP经验 end-------------------------------------------------------------
	
	
	----------------弹出窗口:能量-----------------------------
	

	
	local curr_gp = self[6]
	local EngAll = curr_gp+self[9]
	
	local ScrollAdd_exp = "0,"..self[8]
	local ScrollAdd_eng = "0,"..self[9]
	local ScrollAll_eng = curr_gp..","..EngAll
	local temp, bit = 0,0
	
	print("add_exp = "..add_exp)
	print("add_eng = "..add_eng)
	print("EngAll = "..EngAll)
	total_turn_chance = self.get_chances.totalGet
	card_pve_window_ui1.left_turncard_chance.Text = total_turn_chance
	card_pve_window_ui1.chance_times.Text = lang:GetText("你总共获得了")..self.get_chances.totalGet..lang:GetText("次翻牌机会")
	card_pve_window_ui1.scrollchance_base_get.Text = self.get_chances.gameGet
	card_pve_window_ui1.scrollchance_vip.Text =  self.get_chances.vipGet
	card_pve_window_ui1.scrollchance_cab.Text = 0
	card_pve_window_ui1.scrollchance_activity.Text = 0
	
	local temp_vip = tonumber(self.get_chances.activityGet%10)
	local temp_vip1 = (self.get_chances.activityGet-temp_vip)/10
	print(" temp_vip =",temp_vip)
	print(" temp_vip1 =",temp_vip1)	
	if L_WarZone.IsMatchServer() then
		card_pve_window_ui1.shengcunvip_0.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/pipei/icon_a1.dds", Vector4(0, 0, 0, 0)),}
		card_pve_window_ui1.shengcunvip_1.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/pipei/icon_b1.dds", Vector4(0, 0, 0, 0)),}
		card_pve_window_ui1.shengcunvip_4.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/pipei/icon_c1.dds", Vector4(0, 0, 0, 0)),}
	
		card_pve_window_ui1.shengcunSvipyin_01.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image(""),}
		card_pve_window_ui1.shengcunSvipyin_11.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image(""),}
		card_pve_window_ui1.VIP0.Text = lang:GetText("")
		card_pve_window_ui1.VIP1.Text = lang:GetText("")
		card_pve_window_ui1.VIP4.Text = lang:GetText("")
		card_pve_window_ui1.VIP7.Text = lang:GetText("")
		card_pve_window_ui1.VIP8.Text = lang:GetText("")
		
		local temp1 = math.floor(self.get_chances.activityGet/100)%10
		local temp2 = math.floor(self.get_chances.activityGet/10)%10
		local temp3 = self.get_chances.activityGet%10
		L_Characters.CreatPresentNumCtr(card_pve_window_ui1.shengcunvip_0,temp1,75,75)
		L_Characters.CreatPresentNumCtr(card_pve_window_ui1.shengcunvip_1,temp2,75,75)
		L_Characters.CreatPresentNumCtr(card_pve_window_ui1.shengcunvip_4,temp3,75,75)
	else
	
		if temp_vip1  == 0 then
			card_pve_window_ui1.shengcunvip_0.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/shengcunlock.tga", Vector4(0, 0, 0, 0)),}
			card_pve_window_ui1.shengcunvip_1.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/shengcunlock.tga", Vector4(0, 0, 0, 0)),}
			card_pve_window_ui1.shengcunvip_4.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/shengcunlock.tga", Vector4(0, 0, 0, 0)),}
			card_pve_window_ui1.shengcunSvipyin_0.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/shengcunlock.tga", Vector4(0, 0, 0, 0)),}
			card_pve_window_ui1.shengcunSvipyin_1.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/shengcunlock.tga", Vector4(0, 0, 0, 0)),}	  
			
		elseif temp_vip == 1 and temp_vip1== 1 then
			card_pve_window_ui1.shengcunvip_0.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/shengcunvip_0.tga", Vector4(0, 0, 0, 0)),}
			
			card_pve_window_ui1.shengcunvip_1.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/shengcunlock.tga", Vector4(0, 0, 0, 0)),}
			card_pve_window_ui1.shengcunvip_4.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/shengcunlock.tga", Vector4(0, 0, 0, 0)),}
			card_pve_window_ui1.shengcunSvipyin_0.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/shengcunlock.tga", Vector4(0, 0, 0, 0)),}
			card_pve_window_ui1.shengcunSvipyin_1.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/shengcunlock.tga", Vector4(0, 0, 0, 0)),}	 
		elseif temp_vip == 2 and temp_vip1== 1 then
			card_pve_window_ui1.shengcunvip_0.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/shengcunvip_0.tga", Vector4(0, 0, 0, 0)),}
			card_pve_window_ui1.shengcunvip_1.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/shengcunvip_1.tga", Vector4(0, 0, 0, 0)),}
			
			card_pve_window_ui1.shengcunvip_4.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/shengcunlock.tga", Vector4(0, 0, 0, 0)),}
			card_pve_window_ui1.shengcunSvipyin_0.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/shengcunlock.tga", Vector4(0, 0, 0, 0)),}
			card_pve_window_ui1.shengcunSvipyin_1.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/shengcunlock.tga", Vector4(0, 0, 0, 0)),}	
		elseif temp_vip == 3 and temp_vip1== 1 then
			card_pve_window_ui1.shengcunvip_0.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/shengcunvip_0.tga", Vector4(0, 0, 0, 0)),}
			card_pve_window_ui1.shengcunvip_1.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/shengcunvip_1.tga", Vector4(0, 0, 0, 0)),}
			card_pve_window_ui1.shengcunvip_4.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/shengcunvip_4.tga", Vector4(0, 0, 0, 0)),}
			
			card_pve_window_ui1.shengcunSvipyin_0.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/shengcunlock.tga", Vector4(0, 0, 0, 0)),}
			card_pve_window_ui1.shengcunSvipyin_1.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/shengcunlock.tga", Vector4(0, 0, 0, 0)),}	
		elseif temp_vip == 4 and temp_vip1== 1 then
			card_pve_window_ui1.shengcunvip_0.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/shengcunvip_0.tga", Vector4(0, 0, 0, 0)),}
			card_pve_window_ui1.shengcunvip_1.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/shengcunvip_1.tga", Vector4(0, 0, 0, 0)),}
			card_pve_window_ui1.shengcunvip_4.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/shengcunvip_4.tga", Vector4(0, 0, 0, 0)),}
			card_pve_window_ui1.shengcunSvipyin_0.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/shengcunSvipyin_0.tga", Vector4(0, 0, 0, 0)),}
			
			card_pve_window_ui1.shengcunSvipyin_1.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/shengcunlock.tga", Vector4(0, 0, 0, 0)),}	
		elseif temp_vip == 5 and temp_vip1== 1 then
			card_pve_window_ui1.shengcunvip_0.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/shengcunvip_0.tga", Vector4(0, 0, 0, 0)),}
			card_pve_window_ui1.shengcunvip_1.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/shengcunvip_1.tga", Vector4(0, 0, 0, 0)),}
			card_pve_window_ui1.shengcunvip_4.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/shengcunvip_4.tga", Vector4(0, 0, 0, 0)),}
			card_pve_window_ui1.shengcunSvipyin_0.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/shengcunSvipyin_0.tga", Vector4(0, 0, 0, 0)),}
			card_pve_window_ui1.shengcunSvipyin_1.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/shengcunSvipyin_1.tga", Vector4(0, 0, 0, 0)),}
			
		elseif temp_vip == 1 and temp_vip1== 2 then	
			card_pve_window_ui1.shengcunvip_0.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/shengcunSvip_0.tga", Vector4(0, 0, 0, 0)),}
			
			card_pve_window_ui1.shengcunvip_1.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/shengcunlock.tga", Vector4(0, 0, 0, 0)),}
			card_pve_window_ui1.shengcunvip_4.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/shengcunlock.tga", Vector4(0, 0, 0, 0)),}
			card_pve_window_ui1.shengcunSvipyin_0.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/shengcunlock.tga", Vector4(0, 0, 0, 0)),}
			card_pve_window_ui1.shengcunSvipyin_1.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/shengcunlock.tga", Vector4(0, 0, 0, 0)),}	 
		elseif temp_vip == 2 and temp_vip1== 2 then
			card_pve_window_ui1.shengcunvip_0.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/shengcunSvip_0.tga", Vector4(0, 0, 0, 0)),}
			card_pve_window_ui1.shengcunvip_1.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/shengcunSvip_1.tga", Vector4(0, 0, 0, 0)),}
			
			card_pve_window_ui1.shengcunvip_4.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/shengcunlock.tga", Vector4(0, 0, 0, 0)),}
			card_pve_window_ui1.shengcunSvipyin_0.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/shengcunlock.tga", Vector4(0, 0, 0, 0)),}
			card_pve_window_ui1.shengcunSvipyin_1.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/shengcunlock.tga", Vector4(0, 0, 0, 0)),}	 
		elseif temp_vip == 3 and temp_vip1== 2 then
			card_pve_window_ui1.shengcunvip_0.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/shengcunSvip_0.tga", Vector4(0, 0, 0, 0)),}
			card_pve_window_ui1.shengcunvip_1.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/shengcunSvip_1.tga", Vector4(0, 0, 0, 0)),}
			card_pve_window_ui1.shengcunvip_4.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/shengcunSvip_4.tga", Vector4(0, 0, 0, 0)),}
			
			card_pve_window_ui1.shengcunSvipyin_0.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/shengcunlock.tga", Vector4(0, 0, 0, 0)),}
			card_pve_window_ui1.shengcunSvipyin_1.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/shengcunlock.tga", Vector4(0, 0, 0, 0)),}	 
		elseif temp_vip == 4 and temp_vip1== 2 then
			card_pve_window_ui1.shengcunvip_0.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/shengcunSvip_0.tga", Vector4(0, 0, 0, 0)),}
			card_pve_window_ui1.shengcunvip_1.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/shengcunSvip_1.tga", Vector4(0, 0, 0, 0)),}
			card_pve_window_ui1.shengcunvip_4.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/shengcunSvip_4.tga", Vector4(0, 0, 0, 0)),}
			card_pve_window_ui1.shengcunSvipyin_1.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/shengcunSvipjin_0.tga", Vector4(0, 0, 0, 0)),}
			
			card_pve_window_ui1.shengcunSvipyin_1.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/shengcunlock.tga", Vector4(0, 0, 0, 0)),}	 
		elseif temp_vip == 5 and temp_vip1== 2 then
			card_pve_window_ui1.shengcunvip_0.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/shengcunSvip_0.tga", Vector4(0, 0, 0, 0)),}
			card_pve_window_ui1.shengcunvip_1.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/shengcunSvip_1.tga", Vector4(0, 0, 0, 0)),}
			card_pve_window_ui1.shengcunvip_4.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/shengcunSvip_4.tga", Vector4(0, 0, 0, 0)),}
			card_pve_window_ui1.shengcunSvipyin_0.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/shengcunSvipjin_0.tga", Vector4(0, 0, 0, 0)),}
			card_pve_window_ui1.shengcunSvipyin_1.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/shengcunSvipjin_1.tga", Vector4(0, 0, 0, 0)),}
		end
	end	
	-- if self.get_chances.gameGet == 1 then
		-- card_pve_window_ui1.card_1.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("InGameUI/bottom_info/ig_common_fanpai_card_1.dds", Vector4(0 , 0, 0, 0)),}
		-- flag[1] = 1
	-- elseif self.get_chances.gameGet == 2 then
		-- card_pve_window_ui1.card_1.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("InGameUI/bottom_info/ig_common_fanpai_card_1.dds", Vector4(0 , 0, 0, 0)),}
		-- card_pve_window_ui1.card_2.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("InGameUI/bottom_info/ig_common_fanpai_card_1.dds", Vector4(0 , 0, 0, 0)),}
		-- flag[1] = 1
		-- flag[2] = 1
	-- elseif self.get_chances.gameGet == 3 then
		-- card_pve_window_ui1.card_1.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("InGameUI/bottom_info/ig_common_fanpai_card_1.dds", Vector4(0 , 0, 0, 0)),}
		-- card_pve_window_ui1.card_2.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("InGameUI/bottom_info/ig_common_fanpai_card_1.dds", Vector4(0 , 0, 0, 0)),}
		-- card_pve_window_ui1.card_3.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("InGameUI/bottom_info/ig_common_fanpai_card_1.dds", Vector4(0 , 0, 0, 0)),}
		-- flag[1] = 1
		-- flag[2] = 1
		-- flag[3] = 1
	-- end
	
	-- if self.get_chances.vipGet > 0 then
		-- card_pve_window_ui1.card_4.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("InGameUI/bottom_info/ig_common_fanpai_card_1.dds", Vector4(0 , 0, 0, 0)),}
		-- flag[4] = self.get_chances.vipGet
		-- card_pve_window_ui1.vip_title.Text = "VIP X"..flag[4]
	-- else
		-- card_pve_window_ui1.vip_title.Text = "VIP X0"
	-- end
	-- if self.get_chances.netBarGet == 1 then
		-- card_pve_window_ui1.card_5.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("InGameUI/bottom_info/ig_common_fanpai_card_1.dds", Vector4(0 , 0, 0, 0)),}
		-- flag[5] = 1
	-- end
	-- if self.get_chances.activityGet == 1 then
		-- card_pve_window_ui1.card_6.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("InGameUI/bottom_info/ig_common_fanpai_card_1.dds", Vector4(0 , 0, 0, 0)),}
		-- flag[6] = 1
	-- end
	card_pve_window_ui1.ScrollScore:ClearAll()
	card_pve_window_ui1.Scrollexp:ClearAll()
	card_pve_window_ui1.Scrolleng:ClearAll()
	card_pve_window_ui1.card_timer:ClearAll()
	card_pve_window_ui1.vipScrollScore:ClearAll()
	
	
	card_pve_window_ui1.ScrollScore:AddAnim("ScrollScore",0.5,8)
	card_pve_window_ui1.Scrollexp:AddAnim("ScrollScore",0.5,8)
	card_pve_window_ui1.Scrolleng:AddAnim("ScrollScore",0.5,8)
	card_pve_window_ui1.card_timer:AddAnim("timer",1,3)
	card_pve_window_ui1.vipScrollScore:AddAnim("ScrollScore",0.5,8)
	
	-- bit = Calulatebits(self[10])
	
	
	card_pve_window_ui1.scrollexp_base_get.Text = self.get_exps.gameGet
	card_pve_window_ui1.scrollexp_vip.Text = self.get_exps.vipGet.."%"
	card_pve_window_ui1.scrollexp_cab.Text = self.get_exps.netBarGet.."%"
	card_pve_window_ui1.scrollexp_activity.Text = self.get_exps.activityGet.."%"
	card_pve_window_ui1.scrollexp_battle.Text = self.get_exps.teamAdd.."%"
	card_pve_window_ui1.scrollexp_daoju.Text = self.get_exps.itemAdd.."%"
	
	
	card_pve_window_ui1.scrolleng_base_get.Text = self.get_gps.gameGet
	card_pve_window_ui1.scrolleng_vip.Text = self.get_gps.vipGet.."%"
	card_pve_window_ui1.scrolleng_cab.Text = self.get_gps.netBarGet.."%"
	card_pve_window_ui1.scrolleng_activity.Text = self.get_gps.activityGet.."%"
	card_pve_window_ui1.scrolleng_battle.Text = self.get_gps.teamAdd.."%"
	card_pve_window_ui1.scrolleng_daoju.Text = self.get_gps.itemAdd.."%"
	
	
	local cardback =  Gui.Image("InGameUI/lb_summary_number_l_1.dds", Vector4(0,0,0,0))
	local cardfront = Gui.Image("LobbyUI/summary_number_l_bg.dds")
	card_pve_window_ui1.ScrollScore:AddFrame("ScrollScore",cardback,Vector4(0, 0, 0, 0))
	card_pve_window_ui1.ScrollScore:AddFrame("ScrollScore",cardfront,Vector4(0, 0, 0, 0))
	
	-- card_pve_window_ui1.ScrollScore:SetScrollParam("ScrollScore",self[10],bit + 1)
	-- card_pve_window_ui1.ScrollScore.Size = Vector2((bit + 1) * 33,44)
	-- card_pve_window_ui1.ScrollScore.Location = Vector2(471 - 33 * (bit + 2) -17 - 30,card_pve_window_ui1.ScrollScore.Location.y)
	
	
	
	
	local a = self[10]
	if a < 0 then
		bit = Calulatebits(math.abs(self[10]))
		card_pve_window_ui1.negative1.Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("InGameUI/lb_summary_number_reduce.dds", Vector4(20 , 20, 20, 20)),
		}
		card_pve_window_ui1.ScrollScore:SetScrollParam("ScrollScore",math.abs(self[10]),bit + 1)
		card_pve_window_ui1.ScrollScore.Size = Vector2((bit + 1) * 33,44)
		card_pve_window_ui1.ScrollScore.Location = Vector2(471 - 33 * (bit + 2) -17 - 30,card_pve_window_ui1.ScrollScore.Location.y)
	else	
		bit = Calulatebits(self[10])
		card_pve_window_ui1.negative1.Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image(""),
		}
		card_pve_window_ui1.ScrollScore:SetScrollParam("ScrollScore",self[10],bit + 1)
		card_pve_window_ui1.ScrollScore.Size = Vector2((bit + 1) * 33,44)
		card_pve_window_ui1.ScrollScore.Location = Vector2(471 - 33 * (bit + 2) -17 - 30,card_pve_window_ui1.ScrollScore.Location.y)
	
	end
	print("self.addedVipExp:"..self.addedVipExp)
	bit = Calulatebits(self.addedVipExp)
	card_pve_window_ui1.vipScrollScore:AddFrame("ScrollScore",cardback,Vector4(0, 0, 0, 0))
	card_pve_window_ui1.vipScrollScore:AddFrame("ScrollScore",cardfront,Vector4(0, 0, 0, 0))
	card_pve_window_ui1.vipScrollScore:SetScrollParam("ScrollScore",self.addedVipExp,bit + 1)
	card_pve_window_ui1.vipScrollScore.Size = Vector2((bit + 1) * 33,44)
	card_pve_window_ui1.vipScrollScore.Location = Vector2(471 - 33 * (bit + 2) -17 - 30,card_pve_window_ui1.vipScrollScore.Location.y)
	
	bit = Calulatebits(self[8])
	card_pve_window_ui1.Scrollexp:AddFrame("ScrollScore",cardback,Vector4(0, 0, 0, 0))
	card_pve_window_ui1.Scrollexp:AddFrame("ScrollScore",cardfront,Vector4(0, 0, 0, 0))
	card_pve_window_ui1.Scrollexp:SetScrollParam("ScrollScore",self[8],bit + 1)
	card_pve_window_ui1.Scrollexp.Size = Vector2((bit + 1) * 33,44)
	card_pve_window_ui1.Scrollexp.Location = Vector2(471 - 33 * (bit + 2) -17 - 30,card_pve_window_ui1.Scrollexp.Location.y)
	
	bit = Calulatebits(self[9])
	card_pve_window_ui1.Scrolleng:AddFrame("ScrollScore",cardback,Vector4(0, 0, 0, 0))
	card_pve_window_ui1.Scrolleng:AddFrame("ScrollScore",cardfront,Vector4(0, 0, 0, 0))
	card_pve_window_ui1.Scrolleng:SetScrollParam("ScrollScore",self[9],bit + 1)
	card_pve_window_ui1.Scrolleng.Size = Vector2((bit + 1) * 33,44)
	card_pve_window_ui1.Scrolleng.Location = Vector2(471 - 33 * (bit + 2) -17 - 30,card_pve_window_ui1.Scrolleng.Location.y)
	
	local i = 7
	while i >= 0 do
		num = Gui.Image("InGameUI/lb_summary_number_7.dds", Vector4(0,0,0,0),Vector4((i)/10.0 , 0, (i + 1)/10.0,1 ))
		card_pve_window_ui1.card_timer:AddFrame("timer",num,Vector4(0, 0, 0, 0))
		i = i -1
	end
	
	card_pve_window_ui1.card_timer:ReStart()
	card_pve_window_ui1.card_timer:StartAnimation()
	card_pve_window_ui1.Scrollexp:StartAnimation()
	card_pve_window_ui1.ScrollScore:StartAnimation()
	card_pve_window_ui1.Scrolleng:StartAnimation()
	card_pve_window_ui1.vipScrollScore:StartAnimation()
	gui:PlayAudio("kUIA_CLOSE_TIME")
	if rank - curr_rank >= 1 and gui then
		 gui:PlayAudio("kUIA_LEVEL_UP")
	end
end




function SetBalancematch(data)
	print("in SetBalance")
	ShowmatchPopCard()
	local level1 = L_LobbyMain.PersonalInfo_data.level % 10 --等级个位
	local level2 =(L_LobbyMain.PersonalInfo_data.level - level1) / 10 --等级十位
	local preson_level = math.floor((L_LobbyMain.PersonalInfo_data.level-1)/5)
	local percent
	if L_LobbyMain.PersonalInfo_data.level == 80 then
		percent = 1
	else
		percent = (L_LobbyMain.PersonalInfo_data.exp - L_LobbyMain.LevelInfo_rpc_data[L_LobbyMain.PersonalInfo_data.level][2]) / (L_LobbyMain.LevelInfo_rpc_data[L_LobbyMain.PersonalInfo_data.level + 1][2] - L_LobbyMain.LevelInfo_rpc_data[L_LobbyMain.PersonalInfo_data.level][2]) 
		percent = string.format("%.2f", percent)
	end

	card_pve_match_window_ui.ctrl_popup_card_bg.Skin = Gui.ControlSkin
	{
		BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_exp_ico_" ..preson_level..".dds",Vector4(0, 0, 0, 0)),
	}
	
	card_pve_match_window_ui.big_bg_one.Skin = Gui.ControlSkin
	{
		BackgroundImage = Gui.Image("InGameUI/lb_summary_number_6.dds",Vector4(0, 0, 0, 0),Vector4(level1 / 10, 0, (level1 + 1) / 10, 1)),
	}
	card_pve_match_window_ui.big_one.Skin = Gui.ControlSkin
	{
		BackgroundImage = Gui.Icon("LobbyUI/WarZone/lb_summary_number_7.dds",Vector4(0, 0, 0, 0),Vector4(level1 / 10, 1 - (4 + percent * 112) / 120, (level1 + 1) / 10, 1.0)),
	}
	card_pve_match_window_ui.big_one.Size = Vector2(60, 105 * ( 4 + percent * 97) / 105)
	card_pve_match_window_ui.big_one.Location = Vector2(0, 105 * (1 - ( 4 + percent * 97) / 105))
	card_pve_match_window_ui.big_bg_ten.Skin = Gui.ControlSkin
	{
		BackgroundImage = Gui.Image("InGameUI/lb_summary_number_6.dds",Vector4(0, 0, 0, 0),Vector4(level2 / 10, 0, (level2 + 1) / 10, 1)),
	}
	card_pve_match_window_ui.big_ten.Skin = Gui.ControlSkin
	{
		BackgroundImage = Gui.Icon("LobbyUI/WarZone/lb_summary_number_7.dds",Vector4(0, 0, 0, 0),Vector4(level2 / 10, 1 - ( 4 + percent * 112) / 120, (level2 + 1) / 10, 1.0)),
	}
	card_pve_match_window_ui.big_ten.Size = Vector2(60, 105 * ( 4 + percent * 97) / 105)
	card_pve_match_window_ui.big_ten.Location = Vector2(0, 105 * (1 - ( 4 + percent * 97) / 105))
	
	MessageBox.CloseWaiter()
	if data.warning then
		MessageBox.ShowWithTimer(1,data.warning)
		ptr_cast(game.CurrentState):Quit()
		return
	end
	
	ui.CloseTimer:AddAnim("Timer",3,4)
	ui.CloseTimer:StartAnimation()
	
	----------成就列表---------------------------------
	local achievementlist = nil
	----------获得游戏类型，红方和蓝方数据--------------
	local game_type = data.type
	local team0 = data.team0
	local team1 = data.team1
	local box,isVip
	----------获得本玩家和MVP信息-----------------------
	local self = nil	--本玩家信息
	local percentage = 0 
	local mvp_side = 0	--MVP信息
	local selfindex = 0
	local bufflist = nil
	local activity = data.activity
	local internetCafe,vipicon
	
	if data.mvp[7] < 0 then
		ui.lbl_user_weapon_info.Visible = false
		ui.ctrl_level_tens.Visible = false
		ui.ctrl_level_tens_front.Visible = false
		ui.ctrl_level_unit.Visible = false
		ui.ctrl_level_unit_front.Visible = false
	end
	
	print("activity = ",activity)
	if activity and activity > 1 then
		ui.DouExp.Visible = true
		ui.DouEng.Visible = true
		
		ui.DouExp.Skin = Gui.ControlSkin{ BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_summary_"..activity.."xexp.dds", Vector4(0, 0, 0, 0)), }
		ui.DouEng.Skin = Gui.ControlSkin{ BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_summary_"..activity.."xgp.dds", Vector4(0, 0, 0, 0)), }
	end
	
	for _,v in ipairs(team0) do
		if v[2] == ptr_cast(game.CurrentState):GetMyClientInfo().name then
			self = v 
		end
		
		if v[2] == data.mvp[3] then
			mvp_side = v[3]
		end
	end
	
	
	for _,v in ipairs(team1) do
		if v[2] == ptr_cast(game.CurrentState):GetMyClientInfo().name then
			self = v
		end
		
		if v[2] == data.mvp[3] then
			mvp_side = v[3]
		end
	end
	
	ui.ctrl_head_icon.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/persionalInfo/HeadPic/lb_info_image"..data.mvp[3]..".dds", Vector4(14, 14, 14, 14)),}
	----------如果没有找到本玩家则退出---------------------
	if not self then
		MessageBox.ShowWithTimer(1,lang:GetText("本房间游戏已结束"))
		ptr_cast(game.CurrentState):Quit()
		return
	end
	
	
	local ltv
	local redteam = 0
	local blueteam = 0
	box = self.box
	isVip = self.isvip
	
	bufflist = self.buff_list
    internetCafe = self.internetCafe
    
	if isVip > 0 then
		ui.IconVipExp.Skin = Gui.ControlSkin{ BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_button_0"..isVip.."_normal.dds", Vector4(0, 0, 0, 0)),}
		ui.IconVip.Skin = Gui.ControlSkin{ BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_button_0"..isVip.."_normal.dds", Vector4(0, 0, 0, 0)),}
		ui.IconVip1.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_button_0"..isVip.."_normal.dds", Vector4(0, 0, 0, 0)),}
		ui.IconVip2.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_button_0"..isVip.."_normal.dds", Vector4(0, 0, 0, 0)),}
		ui.ctrl_vip.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_button_0"..isVip.."_normal.dds", Vector4(0, 0, 0, 0)),}
		ui.IconVipExp.Visible = true
		ui.IconVip.Visible = true
		ui.IconVip1.Visible = true
		ui.IconVip2.Visible = true
		ui.ctrl_vip.Visible = true
	else
		ui.IconVipExp.Visible = false
		ui.IconVip.Visible = false
		ui.IconVip1.Visible = false
		ui.IconVip2.Visible = false
		ui.ctrl_vip.Visible = false
	end
	
	ui.buff_layout:OnDestroy()
	
	-- if bufflist then
		-- for i,v in ipairs(bufflist) do
			-- local buffInfo = SpawnNewBuff(v)
			-- buffInfo.LBuff.Parent = ui.buff_layout
		-- end
	-- end

	ui.realScore.Text = self[10]
	
	--------------设置MVP信息-------------------
	ui.lbl_user_weapon_name.Text = data.mvp[5]
	ui.lbl_user_name.Text = data.mvp[1]
	local mvp_WeaponLevel = data.mvp[8]
	if 	mvp_WeaponLevel > 0 then
		ui.c_user_weapon_level.Visible = true
		ui.c_user_weapon_level.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ToolTips/badge_lv"..mvp_WeaponLevel..".dds", Vector4(0, 0, 0, 0)),}
	else
		ui.c_user_weapon_level.Visible = false
	end
	local imagePath= ""
	local color = ""

	color = data.mvp[7]
	
	if color then
		if color > 1 then
			color = "_"..color
		else
			color = ""
		end
		imagePath = "LobbyUI/ibt_icon/".. data.mvp[4]..color..".tga"
	end
	
	ui.ctrl_weapon_icon.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image(imagePath, Vector4(0, 0, 0, 0)),}
	
	local ImageSize = ui.ctrl_weapon_icon.Skin.BackgroundImage.Size
	ui.ctrl_weapon_icon.Size = Vector2(ImageSize.x,ImageSize.y)
	
	--------------MVP end-----------------------
	ui.lbl_user_name_top.Text = self[2]
	
	--------------设置team0玩家信息------------------------
	for i,v in ipairs(team0) do
		local sub_item,percentage
		local rank,rankunit,rankdel,exp,icon1,icon2,headIcon
		local internetCafe
		local isvip,vipicon
		
		if v[3] == 0 then
			ltv = ui.list_red_team_show
			redteam = redteam +1
			sub_item = ltv:AddItem(ltv.RootItem,redteam)
		else
			ltv = ui.list_blue_team_show
			blueteam = blueteam +1
			sub_item = ltv:AddItem(ltv.RootItem,blueteam)
		end
			
		if self == v then
			sub_item.IsSelfItem = true
		end
		
		internetCafe = v.internetCafe
		
		bufflist = v.buff_list
		local buff_num = 0
		if bufflist then
			buff_num = table.getn(bufflist)
			for j,b in ipairs(bufflist) do
				if b and j <= 4 then
					local buffername = b[1]
					iconbuffer =  Gui.Icon("LobbyUI/persionalInfo/buff/buff_"..buffername..".dds", Vector4(0, 0, 0, 0))
					sub_item:SetIcon(7+j,iconbuffer)
				end
			end
		end
		
		isvip = v.isvip
		
		if isvip > 0 then
			vipicon = Gui.Icon("LobbyUI/vip/vip/VIP_button_0"..isvip.."_normal.dds", Vector4(0, 0, 0, 0))
		else
			vipicon = nil
		end
			
		sub_item:SetIcon(1,vipicon)
		
		if i % 2 == 0 then
          	sub_item.BGSkin = Skin.ListItemSkin_DoubleWitchCheck
          	
          	if isvip ~= 0 then
          		sub_item.BGSkin = Skin.ListItemSkin_Double_Vip_Balance
          	end 
          else
          	sub_item.BGSkin = Skin.ListItemSkin_SingleWitchCheck
          	
          	if isvip ~= 0 then
          		sub_item.BGSkin = Skin.ListItemSkin_Single_Vip_Balance
          	end
          end
          
		sub_item:SetText(5,game:StrCut(v[2],5))
		sub_item:SetText(6,v[10])
		sub_item:SetText(7,v[11])
		if buff_num > 4 then
			sub_item:SetText(12,"......")
		end	
		
		rankunit = v[7]%10 + 1
		rankdel = (v[7] - rankunit + 1)/10
		
		exp = v[5] + v[8]
		rank = v[7]
		
		rankdel = rankdel +1
		
		if Level_data then
			percentage = (exp - Level_data[rank][2])/(Level_data[rank+1][2]-Level_data[rank][2])
		end
		
		
		icon2 =  Gui.Icon("LobbyUI/WarZone/lb_summary_number_7e.dds", Vector4(0, 0, 0, 0),Vector4((rankunit-1)/10.0,(1 - ((7 + percentage * 19) / 33)),(rankunit)/10,1.0))
		icon1 =  Gui.Icon("LobbyUI/WarZone/lb_summary_number_6e.dds", Vector4(0, 0, 0, 0),Vector4((rankunit-1)/10,0,(rankunit)/10,1))
		sub_item:SetIcon(4,icon1,icon2)
		
		icon2 = Gui.Icon("LobbyUI/WarZone/lb_summary_number_7e.dds", Vector4(0, 0, 0, 0),Vector4((rankdel-1)/10.0,(1 - ((7 + percentage * 19) / 33)),(rankdel)/10,1.0))
		icon1 =Gui.Icon("LobbyUI/WarZone/lb_summary_number_6e.dds", Vector4(0, 0, 0, 0),Vector4((rankdel-1)/10,0,(rankdel)/10,1))
		sub_item:SetIcon(3,icon1,icon2)
		local num = 5
		sub_item.LV_BackgroundImage = Gui.Image("LobbyUI/lv"..(math.floor((rank - 1)/num)*num+1).."-"..(math.ceil(rank/num)*num)..".dds", Vector4(0, 0, 0, 0), Vector4(0, 0, 1, 1))
		sub_item.LV_localtion = Vector2(147,0)
		sub_item.LV_Size = Vector2(33,30)
		
		if v.icon ~= "null" then
			headIcon = Gui.Icon("LobbyUI/persionalInfo/HeadPic/lb_battlefield_icon"..v.icon..".dds")
		end
		
		sub_item:SetIcon(2,headIcon)
		
		exp = v[8]
		
		if data.winner == v[3] then
			sub_item:SetIcon(15,iconWin)
		end
		sub_item.CanSelect = false
		sub_item.ColCantSelect = true
	end
	
	--------------设置team1玩家信息------------------------
	for i,v in ipairs(team1) do
		local sub_item,percentage
		local rank,rankunit,rankdel,exp,icon1,icon2,headIcon
		local internetCafe
		local isvip,vipicon
		
		if v[3] == 0 then
			ltv = ui.list_red_team_show
			redteam = redteam +1
			sub_item = ltv:AddItem(ltv.RootItem,redteam)
		else
			ltv = ui.list_blue_team_show
			blueteam = blueteam +1
			sub_item = ltv:AddItem(ltv.RootItem,blueteam)
		end
			
		if self == v then
			sub_item.IsSelfItem = true
		end
		
		internetCafe = v.internetCafe
		
		bufflist = v.buff_list
		buff_num = 0
		if bufflist then
			buff_num = table.getn(bufflist)
			for j,b in ipairs(bufflist) do
				if b and j <= 4 then
					local buffername = b[1]
					iconbuffer =  Gui.Icon("LobbyUI/persionalInfo/buff/buff_"..buffername..".dds", Vector4(0, 0, 0, 0))
					sub_item:SetIcon(7+j,iconbuffer)
				end
			end
		end
		
		isvip = v.isvip
		if isvip > 0 then
			vipicon = Gui.Icon("LobbyUI/vip/vip/VIP_button_0"..isvip.."_normal.dds", Vector4(0, 0, 0, 0))
		else
			vipicon = nil
		end		
		sub_item:SetIcon(1,vipicon)
		
		if i % 2 == 0 then
          	sub_item.BGSkin = Skin.ListItemSkin_DoubleWitchCheck
          	
          	if isvip ~= 0 then
          		sub_item.BGSkin = Skin.ListItemSkin_Double_Vip_Balance
          	end 
          else
          	sub_item.BGSkin = Skin.ListItemSkin_SingleWitchCheck
          	
          	if isvip ~= 0 then
          		sub_item.BGSkin = Skin.ListItemSkin_Single_Vip_Balance
          	end
          end
          
		sub_item:SetText(5,game:StrCut(v[2],5))
		sub_item:SetText(6,v[10])
		sub_item:SetText(7,v[11])
		if buff_num > 4 then
			sub_item:SetText(12,"......")
		end
		
		rankunit = v[7]%10 + 1
		rankdel = (v[7] - rankunit + 1)/10
		
		exp = v[5] + v[8]
		rank = v[7]
		
		rankdel = rankdel +1
		
		if Level_data then
			percentage = (exp - Level_data[rank][2])/(Level_data[rank+1][2]-Level_data[rank][2])
		end
		
		
		icon2 =  Gui.Icon("LobbyUI/WarZone/lb_summary_number_7e.dds", Vector4(0, 0, 0, 0),Vector4((rankunit-1)/10.0,(1 - ((7 + percentage * 19) / 33)),(rankunit)/10,1.0))
		icon1 =  Gui.Icon("LobbyUI/WarZone/lb_summary_number_6e.dds", Vector4(0, 0, 0, 0),Vector4((rankunit-1)/10,0,(rankunit)/10,1))
		sub_item:SetIcon(4,icon1,icon2)
		
		icon2 = Gui.Icon("LobbyUI/WarZone/lb_summary_number_7e.dds", Vector4(0, 0, 0, 0),Vector4((rankdel-1)/10.0,(1 - ((7 + percentage * 19) / 33)),(rankdel)/10,1.0))
		icon1 =Gui.Icon("LobbyUI/WarZone/lb_summary_number_6e.dds", Vector4(0, 0, 0, 0),Vector4((rankdel-1)/10,0,(rankdel)/10,1))
		sub_item:SetIcon(3,icon1,icon2)
		local num = 5
		sub_item.LV_BackgroundImage = Gui.Image("LobbyUI/lv"..(math.floor((rank - 1)/num)*num+1).."-"..(math.ceil(rank/num)*num)..".dds", Vector4(0, 0, 0, 0), Vector4(0, 0, 1, 1))
		sub_item.LV_localtion = Vector2(147,0)
		sub_item.LV_Size = Vector2(33,30)
		
		if v.icon ~= "null" then
			headIcon = Gui.Icon("LobbyUI/persionalInfo/HeadPic/lb_battlefield_icon"..v.icon..".dds")
		end
		
		sub_item:SetIcon(2,headIcon)
		
		exp = v[8]
		
		if data.winner == v[3] then
			sub_item:SetIcon(15,iconWin)
		end
		sub_item.CanSelect = false
		sub_item.ColCantSelect = true
	end
	
	
	---------------设置胜败图标-----------------------
	
	local WinerLoserTextColor = nil
	local iconPaoge,iconButcher,iconFireman,iconOL,iconShangxiao,iconNurse,icomEngineer
	
	if data.winner ~= self[3] then
		
		ui.ctrl_result.Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/GameBalance/summary_lose_logo.dds", Vector4(0, 0, 0, 0)),
					}
					
		iconPaoge = Gui.Icon("LobbyUI/GameBalance/summary_ico_fairman_lose.dds", Vector4(0, 0, 0, 0))
		iconButcher = Gui.Icon("LobbyUI/GameBalance/summary_ico_butcher_lose.dds",Vector4(0, 0, 0, 0))
		iconFireman = Gui.Icon("LobbyUI/GameBalance/summary_ico_penhuobing_lose.dds",Vector4(0, 0, 0, 0))
		iconOL = Gui.Icon("LobbyUI/GameBalance/summary_ico_ol_lose.dds",Vector4(0, 0, 0, 0))
		iconShangxiao = Gui.Icon("LobbyUI/GameBalance/summary_ico_teamleader_lose.dds",Vector4(0, 0, 0, 0))
		iconNurse = Gui.Icon("LobbyUI/GameBalance/summary_ico_nurse_lose.dds",Vector4(0, 0, 0, 0))
		icomEngineer = Gui.Icon("LobbyUI/GameBalance/summary_ico_engineer_lose.dds",Vector4(0, 0, 0, 0))
		WinerLoserTextColor = ARGB(255,165,165,165)
	else
		ui.ctrl_result.Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/GameBalance/summary_win_logo.dds", Vector4(0, 0, 0, 0)),
					}
		
		iconPaoge = Gui.Icon("LobbyUI/GameBalance/summary_ico_fairman_win.dds", Vector4(0, 0, 0, 0))
		iconButcher = Gui.Icon("LobbyUI/GameBalance/summary_ico_butcher_win.dds",Vector4(0, 0, 0, 0))
		iconFireman = Gui.Icon("LobbyUI/GameBalance/summary_ico_penhuobing_win.dds",Vector4(0, 0, 0, 0))
		iconOL = Gui.Icon("LobbyUI/GameBalance/summary_ico_ol_win.dds",Vector4(0, 0, 0, 0))
		iconShangxiao = Gui.Icon("LobbyUI/GameBalance/summary_ico_teamleader_win.dds",Vector4(0, 0, 0, 0))
		iconNurse = Gui.Icon("LobbyUI/GameBalance/summary_ico_nurse_win.dds",Vector4(0, 0, 0, 0))
		icomEngineer = Gui.Icon("LobbyUI/GameBalance/summary_ico_engineer_win.dds",Vector4(0, 0, 0, 0))
		WinerLoserTextColor = ARGB(255,252,213,76)
	end
	
	--------------得分设置-------------------
	print("data.police_score=",data.police_score)
	print("data.terrorist_score=",data.terrorist_score)
	ui.ctrl_window_left_middle.ScrollNumRange = "0,"..data.terrorist_score
	ui.ctrl_window_right_middle.ScrollNumRange = "0,"..data.police_score
	
	ui.ctrl_window_left_middle:Reset()
	ui.ctrl_window_right_middle:Reset()
	
	--------------得分设置结束---------------
	
	local aplist = ui.list_accomplishment_show
	
	for i = 1, 5 do
		local sub_item = aplist:AddItem(aplist.RootItem)
		
		local num
		local character = nil
		local CharacterName = nil
		local icon = nil
		if i == 1 then
			sub_item:SetText(0,lang:GetText("最大爆头数"))
			num = self[17]
			character = self[18]
		elseif i == 2 then
			sub_item:SetText(0,lang:GetText("最大连杀数"))
			num = self[19]
			character = self[20]
		elseif i == 3 then
			sub_item:SetText(0,lang:GetText("最大破坏力"))
			num = self[21]
			character = self[22]
		elseif i == 4 then
			sub_item:SetText(0,lang:GetText("最大治疗量"))
			num = self[23]
			character = self[24]
		elseif i == 5 then
			local sec,minute,i = 0,0,0
			sub_item:SetText(0,lang:GetText("最长存活时间"))
			num = self[25]
			
			print(lang:GetText("存活时间 num = "),num)
			i = 0
			while num~=0 do
				if i == 0 then
					sec = num%60
				elseif i ==1 then
					minute = num % 60
				end
				
				num = num /60
				i = i+1
			end
			minute=math.floor(minute)
			num = minute..lang:GetText("分")..sec..lang:GetText("秒")
			character = self[26]
		end		
	
		if character == 1 then
			CharacterName = lang:GetText("firemanico")
			icon = iconPaoge
		elseif character == 2 then
			CharacterName = lang:GetText("butcherico")
			icon = iconButcher
		elseif character == 3 then
			CharacterName = lang:GetText("officeladyico")
			icon = iconOL
		elseif character == 4 then
			CharacterName = lang:GetText("leaderico")
			icon = iconShangxiao
		elseif character == 5 then
			CharacterName = lang:GetText("firebatico")
			icon = iconFireman
		elseif character == 6 then
			CharacterName = lang:GetText("nurseico")
			icon = iconNurse
		elseif character == 7 then
			CharacterName = lang:GetText("engineerico")
			icon = icomEngineer
		end
		
		if i % 2 == 1 then
			sub_item.BGSkin = Skin.ListItemSkin_Single_Normal_balance
		else
			sub_item.BGSkin = Skin.ListItemSkin_Double_Normal_balance
		end
		
		sub_item:SetText(1,num)
		sub_item:SetSubItemColor(1, WinerLoserTextColor)
		if character ~= 0 and CharacterName then
			sub_item:SetIcon(2,Gui.Icon("LobbyUI/GameBalance/lb_summary_"..CharacterName..".dds",Vector4(0, 0, 0, 0)))
		else
			sub_item:SetText(2,lang:GetText("未达成"))
		end
		
		-- sub_item:SetIcon(2,icon)
		if num == 0 then
			sub_item:SetText(2,lang:GetText("未达成"))
			sub_item:SetIcon(2,nil)
		end
		
		sub_item:SetSubItemColor(3, WinerLoserTextColor)
		
		sub_item.CanSelect = false
		sub_item.ColCantSelect = true
	end
	
	
	local list = ui.list_help_show
	sub_item = list:AddItem(list.RootItem)
	sub_item:SetText(0,lang:GetText("赏金击杀"))
	sub_item:SetText(1,self[13])
	sub_item.CanSelect = false
	sub_item.ColCantSelect = true
	sub_item:SetSubItemColor(1, WinerLoserTextColor)
	sub_item.BGSkin = Skin.ListItemSkin_Normal_Single
	
	sub_item = list:AddItem(list.RootItem)
	sub_item:SetText(0,lang:GetText("复仇数"))
	sub_item:SetText(1,self[14])
	sub_item:SetSubItemColor(1, WinerLoserTextColor)
	sub_item.CanSelect = false
	sub_item.ColCantSelect = true
	sub_item.BGSkin = Skin.ListItemSkin_Normal_Double
	
	list = ui.list_kill_show
	sub_item = list:AddItem(list.RootItem)
	sub_item:SetText(0,lang:GetText("助攻数"))
	sub_item:SetText(1,self[15])
	sub_item:SetSubItemColor(1, WinerLoserTextColor)
	sub_item.CanSelect = false
	sub_item.ColCantSelect = true
	sub_item.BGSkin = Skin.ListItemSkin_Normal_Single
	
	sub_item = list:AddItem(list.RootItem)
	sub_item:SetText(0,lang:GetText("近身杀人数"))
	sub_item:SetText(1,self[16])
	sub_item:SetSubItemColor(1, WinerLoserTextColor)
	sub_item.CanSelect = false
	sub_item.ColCantSelect = true
	sub_item.BGSkin = Skin.ListItemSkin_Normal_Double
	
	local team0Socre = data.terrorist_score
	local team1Socre = data.police_score
	
	
	-------------经验，能量----------------
	local exp,eng
	add_exp = self.playerTeamExp * (self.isTeamAdd + 1)
	cur_exp = self[5]
	add_eng = self.playerContribution * (self.isTeamAdd + 1)
	exp = self[8]+cur_exp
	
	if add_exp == -1 then
		ui.lbl_Battle_Full.Visible = true
	else
		ui.ctrl_get_experience_sc.ScrollNumRange = "0,"..add_exp
		ui.ctrl_get_energy_sc.ScrollNumRange = "0,"..add_eng	
		ui.ctrl_get_experience_sc:Reset()
		ui.ctrl_get_energy_sc:Reset()
		ui.lbl_Battle_Full.Visible = false
	end
	

	
	----------------弹出窗口:个人经验-----------------------------
	local curr_rank = self[4]
	local rank = self[7]
	local AddedRank = rank - curr_rank
	local rankUnit = rank%10 + 1
	local rankDel = (rank - rankUnit + 1)/10
	rankDel = rankDel +1
	
	print("curr_rank=",curr_rank)
	print("rank=",rank)
	print("AddedRank=",AddedRank)
	
	local height = 37
	local YL = ui.ctrl_level_unit_m.Location.y+ui.ctrl_level_unit_m.Size.y
	
	local num = 5
	ui.ctrl_level_background.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/lv"..(math.floor((rank - 1)/num)*num+1).."-"..(math.ceil(rank/num)*num)..".dds", Vector4(0, 0, 0, 0), Vector4(0, 0, 1, 1)),}
	
	ui.ctrl_level_unit_m.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_summary_number_6e.dds", Vector4(0, 0, 0, 0),Vector4((rankUnit-1)/10,0,(rankUnit)/10,1)),}
	ui.ctrl_level_tens_m.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_summary_number_6e.dds", Vector4(0, 0, 0, 0),Vector4((rankDel-1)/10,0,(rankDel)/10,1)),}
	
	if Level_data then
		if rank == 80 then
			percentage = 1.0
		else
			percentage = (exp - Level_data[rank][2])/(Level_data[rank+1][2]-Level_data[rank][2])
		end
	end
	
	
	height = height*percentage
	YL = YL - height
	ui.ctrl_level_unit_m_front.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_summary_number_7e.dds", Vector4(0, 0, 0, 0),Vector4((rankUnit-1)/10.0,(1 - ((7 + percentage * 19) / 33)),(rankUnit)/10,1.0)),}
	ui.ctrl_level_tens_m_front.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_summary_number_7e.dds", Vector4(0, 0, 0, 0),Vector4((rankDel-1)/10.0,(1 - ((7 + percentage * 19) / 33)),(rankDel)/10,1.0)),}
	
	ui.ctrl_level_unit_m_front.Size = Vector2(15,(7 + percentage * 19))
	ui.ctrl_level_tens_m_front.Size = Vector2(15,(7 + percentage * 19))
	ui.ctrl_level_unit_m_front.Location = Vector2(70,(44 - percentage * 19))
	ui.ctrl_level_tens_m_front.Location = Vector2(54,(44 - percentage * 19))

	----------------MVP经验-----------------------------
	local MvpRank = data.mvp[2]
	height = 37
	YL = ui.ctrl_level_unit.Location.y+ui.ctrl_level_unit.Size.y
	exp = data.mvp[6]
	
	rankUnit = MvpRank%10 + 1
	rankDel = (MvpRank-rankUnit + 1)/10
	rankDel = rankDel + 1
	
	ui.ctrl_level_unit.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_summary_number_6e.dds", Vector4(0, 0, 0, 0),Vector4((rankUnit-1)/10,0,(rankUnit)/10,1)),}
	ui.ctrl_level_tens.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_summary_number_6e.dds", Vector4(0, 0, 0, 0),Vector4((rankDel-1)/10,0,(rankDel)/10,1)),}
		
	if Level_data then
		if MvpRank == 80 then
			percentage = 1.0
		else
			percentage =(exp - Level_data[MvpRank][2])/(Level_data[MvpRank+1][2]-Level_data[MvpRank][2])
		end
	end
	
	height = height*percentage
	YL = YL - height

	ui.ctrl_level_unit_front.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_summary_number_7e.dds", Vector4(0, 0, 0, 0),Vector4((rankUnit-1)/10.0,(1 - ((7 + percentage * 19) / 33)),(rankUnit)/10,1.0-0.07),1),}
	ui.ctrl_level_tens_front.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_summary_number_7e.dds", Vector4(0, 0, 0, 0),Vector4((rankDel-1)/10.0,(1 - ((7 + percentage * 19) / 33)),(rankDel)/10,1.0-0.07),1),}
	
	ui.ctrl_level_unit_front.Size = Vector2(15,(7 + percentage * 19))
	ui.ctrl_level_tens_front.Size = Vector2(15,(7 + percentage * 19))
	ui.ctrl_level_unit_front.Location = Vector2(181,(53 - percentage * 19))
	ui.ctrl_level_tens_front.Location = Vector2(165,(53 - percentage * 19))
	
 	-------------MVP经验 end-------------------------------------------------------------
	
	
	----------------弹出窗口:能量-----------------------------
	

	
	local curr_gp = self[6]
	local EngAll = curr_gp+self[9]
	
	local ScrollAdd_exp = "0,"..self[8]
	local ScrollAdd_eng = "0,"..self[9]
	local ScrollAll_eng = curr_gp..","..EngAll
	local temp, bit = 0,0
	
	print("add_exp = "..add_exp)
	print("add_eng = "..add_eng)
	print("EngAll = "..EngAll)
	total_turn_chance = self.get_chances.totalGet
	card_pve_match_window_ui.left_turncard_chance.Text = total_turn_chance
	card_pve_match_window_ui.chance_times.Text = lang:GetText("你总共获得了")..self.get_chances.totalGet..lang:GetText("次翻牌机会")
	card_pve_match_window_ui.scrollchance_base_get.Text = self.get_chances.gameGet
	card_pve_match_window_ui.scrollchance_vip.Text =  self.get_chances.vipGet
	card_pve_match_window_ui.scrollchance_cab.Text = 0
	card_pve_match_window_ui.scrollchance_activity.Text = 0
	
	
	local temp1 = data.items
	local temp = self.item_list
	
	for i = 1, 4 do
		card_pve_match_window_ui["jianli_"..i]:OnDestroy()
		card_pve_match_window_ui["jianli_"..i].Skin = Gui.ControlSkin
		{
			BackgroundImage = nil,
		}
	end
	
	for i,v in ipairs(temp) do
		for j,v1 in ipairs(temp1) do
			if v[1] == v1[1] then
				card_pve_match_window_ui["jianli_"..i].Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ibt_icon/"..v1[2]..".tga", Vector4(0, 0, 0, 0)),
				}
				L_Characters.CreatPresentNumCtr(card_pve_match_window_ui["jianli_"..i],v[2],75,75)
				break
			end
		end
	end
	card_pve_match_window_ui.ScrollScore:ClearAll()
	card_pve_match_window_ui.Scrollexp:ClearAll()
	card_pve_match_window_ui.Scrolleng:ClearAll()
	card_pve_match_window_ui.card_timer:ClearAll()
	card_pve_match_window_ui.vipScrollScore:ClearAll()
	
	
	card_pve_match_window_ui.ScrollScore:AddAnim("ScrollScore",0.5,8)
	card_pve_match_window_ui.Scrollexp:AddAnim("ScrollScore",0.5,8)
	card_pve_match_window_ui.Scrolleng:AddAnim("ScrollScore",0.5,8)
	card_pve_match_window_ui.card_timer:AddAnim("timer",1,3)
	card_pve_match_window_ui.vipScrollScore:AddAnim("ScrollScore",0.5,8)
	
	bit = Calulatebits(self[10])
	
	card_pve_match_window_ui.scrollexp_base_get.Text = self.get_exps.gameGet
		-- card_pve_match_window_ui.scrollexp_vip.Text = self.get_exps.vipGet.."%"
		-- card_pve_match_window_ui.scrollexp_cab.Text = self.get_exps.netBarGet.."%"
		-- card_pve_match_window_ui.scrollexp_activity.Text = self.get_exps.activityGet.."%"
	card_pve_match_window_ui.scrollexp_battle.Text = self.get_exps.teamAdd.."%"
	card_pve_match_window_ui.scrollexp_daoju.Text = self.get_exps.itemAdd.."%"
	
	
	card_pve_match_window_ui.scrolleng_base_get.Text = self.get_gps.gameGet
	-- card_pve_match_window_ui.scrolleng_vip.Text = self.get_gps.vipGet.."%"
	-- card_pve_match_window_ui.scrolleng_cab.Text = self.get_gps.netBarGet.."%"
	-- card_pve_match_window_ui.scrolleng_activity.Text = self.get_gps.activityGet.."%"
	card_pve_match_window_ui.scrolleng_battle.Text = self.get_gps.teamAdd.."%"
	card_pve_match_window_ui.scrolleng_daoju.Text = self.get_gps.itemAdd.."%"
	
	
	local cardback =  Gui.Image("InGameUI/lb_summary_number_l_1.dds", Vector4(0,0,0,0))
	local cardfront = Gui.Image("LobbyUI/summary_number_l_bg.dds")
	card_pve_match_window_ui.ScrollScore:AddFrame("ScrollScore",cardback,Vector4(0, 0, 0, 0))
	card_pve_match_window_ui.ScrollScore:AddFrame("ScrollScore",cardfront,Vector4(0, 0, 0, 0))
	card_pve_match_window_ui.ScrollScore:SetScrollParam("ScrollScore",self[10],bit + 1)
	card_pve_match_window_ui.ScrollScore.Size = Vector2((bit + 1) * 33,44)
	card_pve_match_window_ui.ScrollScore.Location = Vector2(471 - 33 * (bit + 2) -17 - 30,card_pve_match_window_ui.ScrollScore.Location.y)
	
	print("self.addedVipExp:"..self.addedVipExp)
	bit = Calulatebits(self.addedVipExp)
	card_pve_match_window_ui.vipScrollScore:AddFrame("ScrollScore",cardback,Vector4(0, 0, 0, 0))
	card_pve_match_window_ui.vipScrollScore:AddFrame("ScrollScore",cardfront,Vector4(0, 0, 0, 0))
	card_pve_match_window_ui.vipScrollScore:SetScrollParam("ScrollScore",self.addedVipExp,bit + 1)
	card_pve_match_window_ui.vipScrollScore.Size = Vector2((bit + 1) * 33,44)
	card_pve_match_window_ui.vipScrollScore.Location = Vector2(471 - 33 * (bit + 2) -17 - 30,card_pve_match_window_ui.vipScrollScore.Location.y)
	
	bit = Calulatebits(self[8])
	card_pve_match_window_ui.Scrollexp:AddFrame("ScrollScore",cardback,Vector4(0, 0, 0, 0))
	card_pve_match_window_ui.Scrollexp:AddFrame("ScrollScore",cardfront,Vector4(0, 0, 0, 0))
	card_pve_match_window_ui.Scrollexp:SetScrollParam("ScrollScore",self[8],bit + 1)
	card_pve_match_window_ui.Scrollexp.Size = Vector2((bit + 1) * 33,44)
	card_pve_match_window_ui.Scrollexp.Location = Vector2(471 - 33 * (bit + 2) -17 - 30,card_pve_match_window_ui.Scrollexp.Location.y)
	
	bit = Calulatebits(self[9])
	card_pve_match_window_ui.Scrolleng:AddFrame("ScrollScore",cardback,Vector4(0, 0, 0, 0))
	card_pve_match_window_ui.Scrolleng:AddFrame("ScrollScore",cardfront,Vector4(0, 0, 0, 0))
	card_pve_match_window_ui.Scrolleng:SetScrollParam("ScrollScore",self[9],bit + 1)
	card_pve_match_window_ui.Scrolleng.Size = Vector2((bit + 1) * 33,44)
	card_pve_match_window_ui.Scrolleng.Location = Vector2(471 - 33 * (bit + 2) -17 - 30,card_pve_match_window_ui.Scrolleng.Location.y)
	
	local i = 7
	while i >= 0 do
		num = Gui.Image("InGameUI/lb_summary_number_7.dds", Vector4(0,0,0,0),Vector4((i)/10.0 , 0, (i + 1)/10.0,1 ))
		card_pve_match_window_ui.card_timer:AddFrame("timer",num,Vector4(0, 0, 0, 0))
		i = i -1
	end
	
	card_pve_match_window_ui.card_timer:ReStart()
	card_pve_match_window_ui.card_timer:StartAnimation()
	card_pve_match_window_ui.Scrollexp:StartAnimation()
	card_pve_match_window_ui.ScrollScore:StartAnimation()
	card_pve_match_window_ui.Scrolleng:StartAnimation()
	card_pve_match_window_ui.vipScrollScore:StartAnimation()
	gui:PlayAudio("kUIA_CLOSE_TIME")
	if rank - curr_rank >= 1 and gui then
		 gui:PlayAudio("kUIA_LEVEL_UP")
	end
end




function AlignUI()
	Gui.Align(ui.ctrl_window_root, 0.5, 0.5)
end

function InitParam()
	VipItemName = ""
	openwitchbox = -1
	BoxAndPrize = {-1,-1,-1,-1}
	timefinish = false
end

function Show()
	-----------初始化各列表-----------------------------------
	-- create_ui()
	
	InitParam()
	local state = ptr_cast(game.CurrentState,"Client.StateBalance")
	if state then
		stage_clear = state.StageClear
		
		if stage_clear then
			print("stage_clear")
			MessageBox.ShowWaiter(lang:GetText("正在过关结算..."))
			game.FightQuit = false
			local sid = game.ClientAddress.server_id
			local cid = game.ClientAddress.channel_id
			local roomid = state:GetSelfRoomInfo().id
			local personid = state:GetMyClientInfo().character_id
			--local personid = ptr_cast(game.CurrentState):GetCharacterId()
			local args = {server_id = sid,channel_id = cid,rid = roomid,pid = personid }
			rpc.safecall("stage_clear",args,ShowWitchBalance,function() MessageBox.CloseWaiter() end)	
		else
			if state:GetMyClientInfo() ~= nil and state:GetSelfRoomInfo() ~= nil then
				print("stage_quit")
				game.FightQuit = true
				local args = {server_id = game.ClientAddress.server_id,channel_id = game.ClientAddress.channel_id,pid = state:GetMyClientInfo().character_id,rid = state:GetSelfRoomInfo().id}
				rpc.safecall("stage_quit",args,nil,function() MessageBox.CloseWaiter() end)
			else
				print("stage_null")
				game.FightQuit = true
				ptr_cast(game.CurrentState):Quit()
				return
			end
		end
	end
	L_LobbyMain.FillPersonalInfo()
	AlignUI()
end

function Hide()
	ui.ctrl_window_root.Parent = nil
	TD_ui.ctrl_window_root.Parent = nil
end

-- 字符串分割
function Split(szFullString, szSeparator)
	local nFindStartIndex = 1
	local nSplitIndex = 1
	local nSplitArray = {}
	while true do
	   local nFindLastIndex = string.find(szFullString, szSeparator,nFindStartIndex)
	   if not nFindLastIndex then
		nSplitArray[nSplitIndex] = string.sub(szFullString, nFindStartIndex, string.len(szFullString))
		break
	   end
	   nSplitArray[nSplitIndex] = string.sub(szFullString, nFindStartIndex, nFindLastIndex - 1)
	   nFindStartIndex = nFindLastIndex + string.len(szSeparator)
	   nSplitIndex = nSplitIndex + 1
	end
	return nSplitArray
end