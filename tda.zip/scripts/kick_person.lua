module("L_Kickperson",package.seeall)

ui = Gui.Create()
{
	Gui.Control "kick_select_person"
	{
		Size = Vector2(460,288),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Location = Vector2(0, 0),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("InGameUI/kick/ig_tr_bg.dds",Vector4(20, 46, 20, 20)),
		},
		
		Gui.Control "kick_reason"
		{
			Size = Vector2(256,140),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Location = Vector2(189, 44),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("InGameUI/kick/ig_tr_bg2.dds", Vector4(25, 25, 25, 25)),
			},
		},
		
		Gui.Control
		{
			Size = Vector2(256,44),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Location = Vector2(189, 187),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("InGameUI/kick/ig_tr_bg2.dds", Vector4(25, 25, 25, 25)),
			},
			
			Gui.Label
			{
				Size = Vector2(200, 24),
				Location = Vector2(10, 10),
				BackgroundColor = ARGB(0, 0, 0, 0),
				TextColor = ARGB(255, 0, 0, 0),
				FontSize = 20,
				Text = lang:GetText("剩余次数:")
			},
			Gui.Label "lab_num"
			{
				Size = Vector2(200, 24),
				Location = Vector2(124, 8),
				BackgroundColor = ARGB(0, 255, 255, 255),
				TextColor = ARGB(255, 255, 128, 64),
				FontSize = 24,
				Text = ""
			},
		},
		
		Gui.ListTreeView "ctrl_list_select"
		{
			Size = Vector2(170, 187),
			Location = Vector2(12, 44),
			Style = "Gui.ListTreeViewWith_VScroll_KickPerson",
			HeaderVisible = false,
			HeaderHeight = 26,
			ItemHeight = 26,
			FontSize = 18,
			TextColor = ARGB(255, 84, 82, 77),
			
			VScrollBarWidth = 7,
			VScrollBarButtonSize = 7,
			
			EventClick = function(sender, e)
				local item = sender.SelectedItem
				if item then
					local state = ptr_cast(game.CurrentState)
					state.KickName = item:GetText(0)
				end
			end
		},
		
		Gui.Label "ctrl_text"
		{	
			Text = lang:GetText("请选择角色和理由"),
			TextColor = ARGB(255, 0, 0, 0),
			FontSize = 16,
			Location = Vector2(60, 14),
			Size = Vector2(320, 18),
			TextAlign = "kAlignCenterMiddle",
		},
		
		Gui.Button "btn_kick_ok"
		{
			Size = Vector2(103, 35),
			Location = Vector2(110, 239),
			Text = lang:GetText("确 定"),
			TextColor = ARGB(255, 211, 211, 211),
			HighlightTextColor = ARGB(255, 211, 211, 211),
			FontSize = 18,
			PushDown = false,
			Padding = Vector4(0, 0, 0, 5),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("faq/lb_contact_button_normal.tga", Vector4(20, 16, 20, 16)),
				HoverImage = Gui.Image("faq/lb_contact_button_hover.tga", Vector4(20, 16, 20, 16)),
				DownImage = Gui.Image("faq/lb_contact_button_down.tga", Vector4(20, 16, 20, 16)),
				DisabledImage = Gui.Image("faq/lb_contact_button_normal.tga", Vector4(20, 16, 20, 16)),
			},
			EventClick = function()
				local state = ptr_cast(game.CurrentState)
				if state and state.KickName == "" then
					MessageBox.ShowWithConfirm(lang:GetText("没有选择任何玩家，请重新申请！"),
					function(sender,e)
						Hide()
					end)
					return
				end
				if ui.ctrl_list_select.ItemCount  >= 2 then
					Hide()
					ptr_cast(game.CurrentState):KickPerson()
				else
					MessageBox.ShowWithConfirm(lang:GetText("当前队伍游戏角色小于3人，申请失败！"),
					function(sender,e)
						Hide()
					end)
				end
			end
		},
		
		Gui.Button "btn_kick_cancel"
		{
			Size = Vector2(103, 35),
			Location = Vector2(250, 239),
			Text = lang:GetText("取 消"),
			TextColor = ARGB(255, 211, 211, 211),
			HighlightTextColor = ARGB(255, 211, 211, 211),
			FontSize = 18,
			PushDown = false,
			Padding = Vector4(0, 0, 0, 5),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("faq/lb_contact_button_normal.tga", Vector4(20, 16, 20, 16)),
				HoverImage = Gui.Image("faq/lb_contact_button_hover.tga", Vector4(20, 16, 20, 16)),
				DownImage = Gui.Image("faq/lb_contact_button_down.tga", Vector4(20, 16, 20, 16)),
				DisabledImage = Gui.Image("faq/lb_contact_button_normal.tga", Vector4(20, 16, 20, 16)),
			},
			EventClick = function()
				Hide()
			end
		},
		
		Gui.RadioGroup "kick_gp"
		{
			Size = Vector2(250, 100),
			Location = Vector2(200, 65),
			ControlSpace = 20,
			LineSpace = 5,
			Style = "Gui.RadioButton",
			Gui.RadioButton "bt1"
			{
				Size = Vector2(250, 20),
				Location = Vector2(0,0),
				FontSize = 18,
				Text = lang:GetText("恶意使用bug"),
				ID = 1,
				TextColor = ARGB(255, 0, 0, 0),
			},

			Gui.RadioButton "bt2"
			{
				Size = Vector2(250, 20),
				Location = Vector2(0,0),
				FontSize = 18,
				Text = lang:GetText("长时间挂机"),
				ID = 2,			
				TextColor = ARGB(255, 0, 0, 0),
			},

			Gui.RadioButton "bt3"
			{
				Size = Vector2(250, 20),
				Location = Vector2(0,0),
				FontSize = 18,
				Text = lang:GetText("无理的谩骂"),
				ID = 3,			
				TextColor = ARGB(255, 0, 0, 0),
			},
			
			Gui.RadioButton "bt4"
			{
				Size = Vector2(250, 20),
				Location = Vector2(0,0),
				FontSize = 18,
				Text = lang:GetText("外挂或非法软件"),
				ID = 4,	
				TextColor = ARGB(255, 0, 0, 0),
			},
			
			EventRadioChanged = function(sender, args)
				local state = ptr_cast(game.CurrentState)
				state.KickReason = sender.RadioCheckID
			end
		},
	}
}

local modal_win = nil

function Init()
	ui.ctrl_list_select:AddColumn("",160,"kAlignCenterMiddle")
end

function Show()
	modal_win = ModalWindow.GetNew("kick_person")
	modal_win.root.Size = Vector2(460,288)
	modal_win.AllowEscToExit = false
	
	ui.kick_select_person.Parent = modal_win.root
	modal_win.root.BackgroundColor = ARGB(0, 255, 255, 255)
	
	return modal_win
end

function AddPerson(state, e)
	local selectitem
	selectitem = ui.ctrl_list_select:AddItem(ui.ctrl_list_select.RootItem)
	selectitem.BGSkin = Skin.ListItemSkin_KickPerson
	selectitem:SetText(0,e.person_name)
end

function SetNum(num)
	ui.lab_num.Text = num
end

function ClearPerson()
	ui.ctrl_list_select:DeleteAll()
end

function Hide()
	if modal_win then
		modal_win.Close()
		modal_win = nil
	end
end

function AlignUI()

end