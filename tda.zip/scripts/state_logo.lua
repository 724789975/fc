require "sys/all.lua"
local state = ptr_cast(game.CurrentState)

LogoWindow = Gui.Create()
{
	Gui.Control "logo_window"
	{
		Size = Vector2(1280, 960),
		Dock = "kDockCenter",
		BackgroundColor = ARGB(0, 255, 255, 255),
		
		Gui.FlashControl
		{
			Text = config:GetLogo(),
			Size = Vector2(1280, 960),
			BackgroundColor = ARGB(255, 255, 255, 255),
			IsUrl = true,
		},
	},
}

state.EventInit = function()
	LogoWindow.logo_window.Parent = gui
end

state.EventLeave = function()
	LogoWindow.logo_window.Parent = nil
	LogoWindow = nil
end