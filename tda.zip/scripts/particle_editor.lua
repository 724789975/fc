module("ParticleEditor", package.seeall)

if Close then Close() end

input_window = nil
emitter_window = nil
particle_window = nil
spline_window = nil
close_window = nil

particle_view = nil
emitter_list = nil
input = nil
input_vars = {}

local LockCamera = false
local ParticleSystem = nil
local ParticleResource  = nil

local mainstate = ptr_cast(game.CurrentState, "Client.StateMainGame")

function Show()
	InitInputWindow()
	InitCloseWindow()
	InitSplineView()
	InitParticleView()
	InitEmitterList()
	emitter_list = emitter_window.EmitterList
	particle_view = particle_window.ParticleView
	emitter_list:AddColumn("", 278)
	
	mainstate.EditorOn = true

	function particle_view.PropertyGrid.EventSelectItemChange(sender, e)
		local item = nil
		local value = nil
		if e.Item then
			item = ptr_cast(e.Item)
			value = ptr_cast(item.Value)
		end
	end
	LockCamera = true
	cg.LockCamera = LockCamera
end

function Close()
	if input_window then input_window.root.Parent = nil end
	if emitter_window then emitter_window.root.Parent = nil end
	if particle_window then particle_window.root.Parent = nil end
	if spline_window then spline_window.root.Parent = nil end
	if close_window then close_window.root.Parent = nil end
	LockCamera = false
	cg.LockCamera = LockCamera
end

function HideWindow()
	input_window.root.Visible = false
	emitter_window.root.Visible = false
	particle_window.root.Visible = false
	spline_window.root.Visible = false
	close_window.root.Visible = true
end

function ShowWindow()
	input_window.root.Visible = false
	emitter_window.root.Visible = true
	particle_window.root.Visible = true
	spline_window.root.Visible = true
	close_window.root.Visible = false
	LockCamera = false
end


function InitCloseWindow()
	close_window = Gui.Create(gui)
	{
		Gui.WindowUI "root"
		{
			Size = Vector2(180, 60),
			WorldLocation = Vector3(10, 10),
			ShowCloseButton = true,
			Moveable = false,
			Visible = false,
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/lb_shop_button04_hover.dds", Vector4(5, 5, 5, 5)),
			},
			
			Gui.Button "showall"
			{
				Location = Vector2(20, 30),
				Size = Vector2(60, 20),
				Text = lang:GetText("显示"),
			},
	
			Gui.Button "closeall"
			{
				Location = Vector2(100, 30),
				Size = Vector2(60, 20),
				Text = lang:GetText("关闭"),
			},
		},		
	}

	function close_window.root.EventClose(sender, e)
		ShowWindow()
	end
	
	function close_window.showall.EventClick(sender, e)
		ShowWindow()
	end

	function close_window.closeall.EventClick(sender, e)
		Close()
		mainstate.EditorOn = false
		cg.LockCamera = false
	end
end

function InitInputWindow()
	input_window = Gui.Create(gui)
	{
		Gui.WindowUI "root"
		{
			Size = Vector2(200, 180),
			WorldLocation = Vector3(gui.Size.x / 2 - 100, gui.Size.y / 2 - 75 , 0),
			BackgroundColor = ARGB(192, 0, 0, 0),
			Moveable = true,
			Visible = false,
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/lb_shop_button04_hover.dds", Vector4(5, 5, 5, 5)),
			},
			
			Gui.FlowLayout
			{
				Dock = "kDockFill",
				Direction = "kVertical",
				Align = "kAlignCenterMiddle",
				ControlAlign = "kAlignCenterMiddle",
				ControlSpace = 3,
				BackgroundColor = ARGB(0, 0, 0, 0),
		
				Gui.Label "label"
				{
					Margin = Vector4(0, 0, 0, 16),
					Size = Vector2(190, 20),
					TextColor = ARGB(255, 255, 239, 206),
					Text = "",
				},
		
				Gui.Textbox "input"
				{
					BackgroundColor = ARGB(0, 255, 255, 255),
					TextColor = ARGB(255, 255, 239, 206),
					Margin = Vector4(0, 0, 0, 16),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/lb_common_textbox01_normal.dds", Vector4(5, 5, 5, 5)),
					},
					Text = "",
				},
		
				Gui.Button "OK"
				{
					TextColor = ARGB(255, 255, 239, 206),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("InGameUI/kick/ig_tr_bg3.dds", Vector4(8, 8, 8, 8)),
						HoverImage = Gui.Image("InGameUI/kick/ig_tr_bg_hover.dds", Vector4(8, 8, 8, 8)),
						DownImage = Gui.Image("InGameUI/kick/ig_tr_bg_down.dds", Vector4(8, 8, 8, 8)),
						DisabledImage = Gui.Image("InGameUI/kick/ig_tr_bg3.dds", Vector4(8, 8, 8, 8)),
					},
					Text = lang:GetText("确定"),
				},
			},	
		},
	}
	
	function input_window.root.EventClose()
		input_window.root.Visible = false
	end
end

function InitSplineView()
	spline_window = Gui.Create(gui)
	{
		Gui.WindowUI "root"
		{
			Size = Vector2(500, 200),
			WorldLocation = Vector3(gui.Size.x / 2 - 250, gui.Size.y - 200, 0),
			BackgroundColor = ARGB(192, 0, 0, 0),
			Moveable = true,
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/lb_shop_button04_hover.dds", Vector4(5, 5, 5, 5)),
			},
			
			Gui.SplineView "spline_view"
			{
				Size = Vector2(500, 180),
				Dock = "kDockBottom",
			},
		},	
	}

	function spline_window.root.EventClose()
		HideWindow()
	end
end

function InitParticleView()
	particle_window = Gui.Create(gui)
	{
		Gui.WindowUI "root"
		{
			Size = Vector2(gui.Size.x * 0.3, gui.Size.y),
			WorldLocation = Vector3(gui.Size.x * 0.7, 0, 0),
			BackgroundColor = ARGB(192, 0, 0, 0),
			Moveable = true,

			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/lb_shop_button04_hover.dds", Vector4(5, 5, 5, 5)),
			},
			
			Gui.Label "label"
			{
				Text = lang:GetText("发射器"),
				Size = Vector2(60, 18),
			},
	
			Gui.PropertyView "ParticleView"
			{
				Dock = "kDockBottom",
				Size = Vector2(gui.Size.x * 0.3, gui.Size.y - 20),
			},				
		},
	}
	
	function particle_window.root.EventClose(sender, e)
		HideWindow()
	end	
end

function InitEmitterList()
	emitter_window = Gui.Create(gui)
	{
		Gui.WindowUI "root"
		{
			Size = Vector2(280, gui.Size.y),
			WorldLocation = Vector3(0, 0, 0),
			BackgroundColor = ARGB(192, 0, 0, 0),
			Moveable = true,
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/lb_shop_button04_hover.dds", Vector4(5, 5, 5, 5)),
			},
			
			Gui.Label "label"
			{
				Text = lang:GetText("粒子编辑器"),
				Size = Vector2(100, 18),
			},
	
			Gui.ListTreeView "EmitterList"
			{
				Dock = "kDockBottom",
				Size = Vector2(278, gui.Size.y - 70),
			},
	
			Gui.Button "NewParticle"
			{
				Location = Vector2(2, 21),
				Size = Vector2(40, 20),
				Text = lang:GetText("新建"),
				TextColor = ARGB(255, 255, 239, 206),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("InGameUI/kick/ig_tr_bg3.dds", Vector4(8, 8, 8, 8)),
					HoverImage = Gui.Image("InGameUI/kick/ig_tr_bg_hover.dds", Vector4(8, 8, 8, 8)),
					DownImage = Gui.Image("InGameUI/kick/ig_tr_bg_down.dds", Vector4(8, 8, 8, 8)),
					DisabledImage = Gui.Image("InGameUI/kick/ig_tr_bg3.dds", Vector4(8, 8, 8, 8)),
				},
			},

			Gui.Button "OpenParticle"
			{
				Location = Vector2(44, 21),
				Size = Vector2(40, 20),
				Text = lang:GetText("打开"),
				TextColor = ARGB(255, 255, 239, 206),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("InGameUI/kick/ig_tr_bg3.dds", Vector4(8, 8, 8, 8)),
					HoverImage = Gui.Image("InGameUI/kick/ig_tr_bg_hover.dds", Vector4(8, 8, 8, 8)),
					DownImage = Gui.Image("InGameUI/kick/ig_tr_bg_down.dds", Vector4(8, 8, 8, 8)),
					DisabledImage = Gui.Image("InGameUI/kick/ig_tr_bg3.dds", Vector4(8, 8, 8, 8)),
				},
			},
	
			Gui.Button "ModifyParticle"
			{
				Location = Vector2(86, 21),
				Size = Vector2(40, 20),
				Text = lang:GetText("修改"),
				TextColor = ARGB(255, 255, 239, 206),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("InGameUI/kick/ig_tr_bg3.dds", Vector4(8, 8, 8, 8)),
					HoverImage = Gui.Image("InGameUI/kick/ig_tr_bg_hover.dds", Vector4(8, 8, 8, 8)),
					DownImage = Gui.Image("InGameUI/kick/ig_tr_bg_down.dds", Vector4(8, 8, 8, 8)),
					DisabledImage = Gui.Image("InGameUI/kick/ig_tr_bg3.dds", Vector4(8, 8, 8, 8)),
				},
			},
	
			Gui.Button "SaveParticle"
			{
				Location = Vector2(128, 21),
				Size = Vector2(40, 20),
				Text = lang:GetText("保存"),
				TextColor = ARGB(255, 255, 239, 206),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("InGameUI/kick/ig_tr_bg3.dds", Vector4(8, 8, 8, 8)),
					HoverImage = Gui.Image("InGameUI/kick/ig_tr_bg_hover.dds", Vector4(8, 8, 8, 8)),
					DownImage = Gui.Image("InGameUI/kick/ig_tr_bg_down.dds", Vector4(8, 8, 8, 8)),
					DisabledImage = Gui.Image("InGameUI/kick/ig_tr_bg3.dds", Vector4(8, 8, 8, 8)),
				},
			},
	
			Gui.Button "Reset"
			{
				Location = Vector2(180, 21),
				Size = Vector2(40, 20), 
				Text = lang:GetText("重置"),
				TextColor = ARGB(255, 255, 239, 206),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("InGameUI/kick/ig_tr_bg3.dds", Vector4(8, 8, 8, 8)),
					HoverImage = Gui.Image("InGameUI/kick/ig_tr_bg_hover.dds", Vector4(8, 8, 8, 8)),
					DownImage = Gui.Image("InGameUI/kick/ig_tr_bg_down.dds", Vector4(8, 8, 8, 8)),
					DisabledImage = Gui.Image("InGameUI/kick/ig_tr_bg3.dds", Vector4(8, 8, 8, 8)),
				},
			},
	
			Gui.Button "Position"
			{
				Location = Vector2(222, 21),
				Size = Vector2(40, 20),
				Text = lang:GetText("位置"),
				TextColor = ARGB(255, 255, 239, 206),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("InGameUI/kick/ig_tr_bg3.dds", Vector4(8, 8, 8, 8)),
					HoverImage = Gui.Image("InGameUI/kick/ig_tr_bg_hover.dds", Vector4(8, 8, 8, 8)),
					DownImage = Gui.Image("InGameUI/kick/ig_tr_bg_down.dds", Vector4(8, 8, 8, 8)),
					DisabledImage = Gui.Image("InGameUI/kick/ig_tr_bg3.dds", Vector4(8, 8, 8, 8)),
				},
			},	
	
			Gui.Button "NewEmitter"
			{
				Location = Vector2(2, 45),
				Size = Vector2(40, 20),
				Text = lang:GetText("添加"),
				TextColor = ARGB(255, 255, 239, 206),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("InGameUI/kick/ig_tr_bg3.dds", Vector4(8, 8, 8, 8)),
					HoverImage = Gui.Image("InGameUI/kick/ig_tr_bg_hover.dds", Vector4(8, 8, 8, 8)),
					DownImage = Gui.Image("InGameUI/kick/ig_tr_bg_down.dds", Vector4(8, 8, 8, 8)),
					DisabledImage = Gui.Image("InGameUI/kick/ig_tr_bg3.dds", Vector4(8, 8, 8, 8)),
				},
			},
	
			Gui.Button "DeleteEmitter"
			{
				Location = Vector2(44, 45),
				Size = Vector2(40, 20),
				Text = lang:GetText("删除"),
				TextColor = ARGB(255, 255, 239, 206),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("InGameUI/kick/ig_tr_bg3.dds", Vector4(8, 8, 8, 8)),
					HoverImage = Gui.Image("InGameUI/kick/ig_tr_bg_hover.dds", Vector4(8, 8, 8, 8)),
					DownImage = Gui.Image("InGameUI/kick/ig_tr_bg_down.dds", Vector4(8, 8, 8, 8)),
					DisabledImage = Gui.Image("InGameUI/kick/ig_tr_bg3.dds", Vector4(8, 8, 8, 8)),
				},
			},
	
			Gui.Button "MoveUp"
			{
				Location = Vector2(86, 45),
				Size = Vector2(40, 20),
				Text = lang:GetText("上移"),
				TextColor = ARGB(255, 255, 239, 206),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("InGameUI/kick/ig_tr_bg3.dds", Vector4(8, 8, 8, 8)),
					HoverImage = Gui.Image("InGameUI/kick/ig_tr_bg_hover.dds", Vector4(8, 8, 8, 8)),
					DownImage = Gui.Image("InGameUI/kick/ig_tr_bg_down.dds", Vector4(8, 8, 8, 8)),
					DisabledImage = Gui.Image("InGameUI/kick/ig_tr_bg3.dds", Vector4(8, 8, 8, 8)),
				},
			},
	
			Gui.Button "MoveDown"
			{
				Location = Vector2(128, 45),
				Size = Vector2(40, 20),
				Text = lang:GetText("下移"),
				TextColor = ARGB(255, 255, 239, 206),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("InGameUI/kick/ig_tr_bg3.dds", Vector4(8, 8, 8, 8)),
					HoverImage = Gui.Image("InGameUI/kick/ig_tr_bg_hover.dds", Vector4(8, 8, 8, 8)),
					DownImage = Gui.Image("InGameUI/kick/ig_tr_bg_down.dds", Vector4(8, 8, 8, 8)),
					DisabledImage = Gui.Image("InGameUI/kick/ig_tr_bg3.dds", Vector4(8, 8, 8, 8)),
				},
			},
		
			Gui.Button "Camera"
			{
				Location = Vector2(180, 45),
				Size = Vector2(40, 20),
				Text = lang:GetText("相机"),
				TextColor = ARGB(255, 255, 239, 206),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("InGameUI/kick/ig_tr_bg3.dds", Vector4(8, 8, 8, 8)),
					HoverImage = Gui.Image("InGameUI/kick/ig_tr_bg_hover.dds", Vector4(8, 8, 8, 8)),
					DownImage = Gui.Image("InGameUI/kick/ig_tr_bg_down.dds", Vector4(8, 8, 8, 8)),
					DisabledImage = Gui.Image("InGameUI/kick/ig_tr_bg3.dds", Vector4(8, 8, 8, 8)),
				},
			},
		},			
	}
	
	function emitter_window.root.EventClose(sender, e)
		HideWindow()
	end

	function _G.lock()
		cg.LockCamera = true
	end
	
	function _G.unlock()
		cg.LockCamera = false
	end

	function emitter_window.Camera.EventClick(sender, e)
		LockCamera = not LockCamera
		cg.LockCamera = LockCamera
	end

	local position
	function emitter_window.OpenParticle.EventClick(sender, e)
		input_window.label.Text = lang:GetText("输入粒子文件名称:")
		input_window.root.Visible = true
	
		function input_window.OK.EventClick(sender, e)
			if (input_window.input.Text ~= "") then
				Open(input_window.input.Text)
				input_window.input.Text = ""
				input_window.root.Visible = false
				cg:AddParticle(ParticleSystem)
				position = cg:GetParticlePosition()
				ParticleSystem:SetPosition(position)
				ParticleSystem:Reset()
			end
		end
	end
	
	function emitter_window.NewParticle.EventClick(sender, e)
		input_window.label.Text = lang:GetText("输入粒子名称:")
		input_window.root.Visible = true

		function input_window.OK.EventClick(sender, e)
			if (input_window.input.Text ~= "") then
				emitter_list:DeleteAll()
				emitter_list:ClearSelection()
				emitter_list.Columns:SetText(0, input_window.input.Text)
				if ParticleResource then
					ParticleResource:ClearEmitterData()
				end
				if not ParticleSystem then
					ParticleSystem = ptr_new "Client.ParticleSystem"
					cg:AddParticle(ParticleSystem)
				end
				
				if not ParticleResource then
					ParticleResource = ptr_new "Client.ParticleResource"
				end
				
				ParticleSystem:SetParticleResource(ParticleResource)
				ParticleSystem:Initialize()
				input_window.input.Text = ""
				input_window.root.Visible = false
			end
		end
	end
	
	function emitter_window.SaveParticle.EventClick(sender, e)
		input_window.label.Text = lang:GetText("输入粒子文件名称:")
		input_window.root.Visible = true
		
		function input_window.OK.EventClick(sender, e)
			Save(input_window.input.Text)
			input_window.root.Visible = false
		end
	end

	function emitter_window.Reset.EventClick(sender, e)
--		cg:AddParticle(ParticleSystem)
--		ParticleSystem:SetPosition(position)
		ParticleSystem:Reset()
	end

	function emitter_window.Position.EventClick(sender, e)
		position = cg:GetParticlePosition()
		ParticleSystem:SetPosition(cg:GetParticlePosition())
	end
	
	function emitter_window.NewEmitter.EventClick(sender, e)
		input_window.label.Text = lang:GetText("输入发射器名称:")
		input_window.root.Visible = true
		function input_window.OK.EventClick(sender, e)
			if (input_window.input.Text ~= "") then
				item = emitter_list:AddItem(emitter_list.RootItem, input_window.input.Text)
				item.Tag = ParticleResource:CreateEmitterData()
		--		ParticleResource:AddEmitter(item.Tag)
				ptr_cast(item.Tag).EmitName = input_window.input.Text
				ParticleSystem:Initialize()
				input_window.input.Text = ""
				input_window.root.Visible = false
			end
		end
	end	
	
	
	local CurrentEmit
	function emitter_window.DeleteEmitter.EventClick(sender, e)
		if (CurrentEmit) then
			ParticleResource:DeleteEmitter(ptr_cast(CurrentEmit.Tag))
			emitter_list:DeleteNode(emitter_list.SelectedItem)
			ParticleSystem:Initialize()
		end
	end

	function emitter_window.MoveUp.EventClick(sender, e)
		local current = emitter_list.SelectedItem
		if current.Next then
			print("Next")
		end

		if current.Prev then
			print("Prev")
		end
	end
	
	function emitter_window.ModifyParticle.EventClick(sender, e)

		input_window.label.Text = lang:GetText("输入粒子名称:")
		input_window.root.Visible = true
		function input_window.OK.EventClick(sender, e)
			if (ParticleSystem and input_window.input.Text ~= "") then
				emitter_list.Columns:SetText(0, input_window.input.Text)
			end
			input_window.input.Text = ""
			input_window.root.Visible = false	
		end


		if (ParticleSystem and input_window.input.Text ~= "") then
			emitter_list.SelectedItem.Tag:SetEmitName(input_window.input.Text)
			emitter_list.SelectedItem.Text = input_window.input.Text
		end
	end
	
	function emitter_window.EmitterList.EventSelectItemChange(sender, e)
		if (e.Item) then 
			particle_view.SelectedObject = e.Item.Tag
			CurrentEmit = e.Item
		end
	end
	
	function particle_window.ParticleView.PropertyGrid.EventDropDown(sender, e)
		if e.Item then
			local item = ptr_cast(e.Item)
			local spline_value = ptr_cast(item.Value)
			if spline_value then
				spline_window.spline_view.Spline = spline_value
				if item:GetText() == "TextureName" then 
				    cg:ReloadResource("/vfx/" .. ptr_cast(item.Value))
				    cg:LoadResourceByType("/vfx/" .. ptr_cast(item.Value), "dds")
				end
			end
		end
	end
	function particle_window.ParticleView.PropertyGrid.EventExpand(sender, e)
	end

end

function Open(path)
	emitter_list:DeleteAll()
	emitter_list:ClearSelection()
	if not _G.particle_system then
		_G.particle_system = ptr_new "Client.ParticleResource"
	end
	_G.particle_system:ClearEmitterData()
	--dofile(Path.GetPhysicalPath("/vfx/".."ReadParticle.lua", "kVirtualRead"))
	--dofile(Path.GetPhysicalPath("/vfx/"..path, "kVirtualRead"))
	dofile2("../vfx/ReadParticle.lua")
	dofile2("../vfx/"..path)

	if not ParticleSystem then
		ParticleSystem = ptr_new "Client.ParticleSystem"
	end
	ParticleSystem:SetParticleResource(_G.particle_system)
	ParticleSystem:Initialize()
	ParticleResource = _G.particle_system
	ParticleResource:AddEmitToList(emitter_list)
	emitter_list.Columns:SetText(0, ParticleResource.Name)
end

function Save(path)
	--io.output(Path.GetPhysicalPath("/vfx/"..path, "kVirtualRead"))
	io.output("../vfx/"..path)


	local pos = 0
	local function writeline(v, c)
		pos = pos + c
		for i = 1, pos do
			io.write("\t")
		end
		io.write(v)
		io.write("\n")
	end

	local function writelinef(f, ...)
		io.write("\t")
		io.write(string.format(f, ...))
		io.write("\n")
	end

	writeline("ParticleSystem", 0)
	writeline("{", 0)
	writeline("ParticleSystemName = " .. "\"" .. emitter_list.Columns:GetText(0) .. "\"", 1)
	writeline("}", -1)

	local property_writer =
	{
		["unsigned long"] = function(k, v) writelinef("%s = %s,", k, v) end,
		["long"] = function(k, v) writelinef("%s = %s,", k, v) end,
		["float"] = function(k, v) writelinef("%s = %s,", k, v) end,
		["bool"] = function(k, v) writelinef("%s = %s,", k, tostring(v)) end,
		["Core.Identifier"] = function(k, v) writelinef("%s = %q,", k, v) end,
		["Core.String"] = function(k, v) writelinef("%s = %q,", k, v) end,
		["Core.Vector3"] = function(k, v) writelinef("%s = Vector3(%g, %g, %g),", k, v.x, v.y, v.z) end,
		["Core.Vector2"] = function(k, v) writelinef("%s = Vector2(%g, %g),", k, v.x, v.y) end,
		["Core.Color3"] = function(k, v) writelinef("%s = Color3(%g, %g, %g),", k, v.g, v.g, v.b) end,
		["Core.Color3"] = function(k, v) writelinef("%s = Color3(%g, %g, %g),", k, v.g, v.g, v.b) end,
	}

	local iter = emitter_list.RootItem.FirstChild
	while(iter) do
		writeline("Emitter", 0)
		writeline("{", 0)
		pos = pos + 1

		local emmiter = ptr_cast(iter.Tag)

		if emmiter then
			local emmiter_type = ptr_typeof(emmiter)

			if emmiter_type then
				local member_count = emmiter_type:GetMemberCount()

				for i = 0, member_count - 1 do
					local member = emmiter_type:GetMemberById(i)
					if member and member:GetMemberKind() == "kProperty" then
						local property = ptr_cast(member)
						local name = property:GetName()
						local typename = property:GetPropertyType()
						local value = emmiter[name]

						local writer = property_writer[typename]
--						print(typename)

						if writer then
							writer(name, value)
						else
							local param = ptr_cast(value, "Client.Parameter")
							if param then
								writelinef("%s = %s", name, ptr_cast(param):SaveToStream(1))
							else
								writelinef("%s = %q,", name, tostring(value))
							end
--							print(value)
						end
					end
				end
			end
		end
		iter = iter.Next
		pos = pos - 1
		writeline("}", 0)
	end
	io.close()
	--print(path .. " saved at " .. Path.GetPhysicalPath("/vfx/"..path, "kVirtualRead"))
	print(path .. " saved at " .. "../vfx/"..path)
end

Show()
