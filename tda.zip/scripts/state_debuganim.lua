module("ModelViewer", package.seeall)

local state = ptr_cast(game.CurrentState)
checkeddrawjoint = false
checkeddrawcharacter  = false
checkedwireframe = false
checkedphyicalline = false
checkedcrouch = false
checkedmultireload = false
checkedmultishoot = false

--ModelViewer Window
ui_right = Gui.Create
{
	Gui.WindowUI "UI_WINDOWS_RIGHT"
	{
		Size = Vector2(220, 900),
		ShowCloseButton = false,
		--Load Charater`s Resource
		Gui.FlowLayout
		{
			Style = "Gui.Control_50",
			Dock = "kDockTop",
			ControlSpace = 6,
			Align = "kAlignCenter",
			Direction = "kVertical",
			ControlAlign = "kAlignCenterMiddle",
			Size = Vector2(205, 150),
			BackgroundColor = ARGB(255,255,255,255),
			Margin = Vector4(3,3,3,3),
			Gui.Label
			{
				FontSize = 12,
				AutoSize = true,
				Text = "Load Resource",
				Margin = Vector4(0,2,0,0),
				TextColor = ARGB(255, 255, 255, 255),
			},
			Gui.ComboBox "cbx_character_mode"
			{
				Size = Vector2(160, 25),
				Readonly = true,
			},
			Gui.ComboBox "cbx_character"
			{
				Size = Vector2(160, 25),
				Readonly = true,
				EventItemSelected = function()
					count = ui_right.cbx_character.SelectedIndex
					LoadCbxWeapon(count)
				end
			},
			Gui.ComboBox "cbx_weapon"
			{
				Size = Vector2(160, 25),
				Readonly = true,
			},
			Gui.Button
			{
				Style = "Gui.Buttonsimhei14",
				Text = "Load",
				Size = Vector2(60, 25),
				Margin = Vector4(-80,0,0,0),
				ReceiveKey = false,
				EventClick = function()
					count = ui_right.cbx_character.SelectedIndex
					strweapon = ui_right.cbx_weapon.Text
					if ui_right.cbx_character_mode.SelectedIndex == 0 then
						first = true
					else
						first = false
					end
					if ui_right.cbx_weapon.SelectedIndex == 2 then
						knife = true
					else
						knife = false
					end
					ptr_cast(game.CurrentState):SetCharacter(count, strweapon, knife, first)
				end
			},
			Gui.Button
			{
				Style = "Gui.Buttonsimhei14",
				Text = "Init",
				Size = Vector2(60, 25),
				Margin = Vector4(80,-31,0,0),
				ReceiveKey = false,
				EventClick = function()
					ptr_cast(game.CurrentState):InitModel()
				end
			},
			
		},
		--Load Render
		Gui.FlowLayout
		{
			Style = "Gui.Control_50",
			Dock = "kDockTop",
			ControlSpace = 6,
			Align = "kAlignCenter",
			Direction = "kVertical",
			ControlAlign = "kAlignCenterMiddle",
			Size = Vector2(205, 150),
			BackgroundColor = ARGB(255,255,255,255),
			Margin = Vector4(3,3,3,3),
			Gui.Label
			{
				FontSize = 12,
				AutoSize = true,
				Text = "Render",
				Margin = Vector4(0,2,0,0),
				TextColor = ARGB(255, 255, 255, 255),
			},
			Gui.CheckBox "Drawjoint"
			{	
				Text = "Draw Joints",
				Size = Vector2(150, 20),
				CheckPosition = "kCheckLeft",
				EventCheckChanged = function() 
					checkeddrawjoint = not checkeddrawjoint
					if(checkeddrawjoint) then
						ptr_cast(game.CurrentState):SetDrawJoint(true)
					else
						ptr_cast(game.CurrentState):SetDrawJoint(false)
					end
				end
			},
			Gui.CheckBox "Drawcharacter"
			{	
				Text = "Draw Character",
				Size = Vector2(150, 20),
				CheckPosition = "kCheckLeft",
				Check = true,
				EventCheckChanged = function() 
					checkeddrawcharacter = not checkeddrawcharacter
					if(checkeddrawcharacter) then
						ptr_cast(game.CurrentState):SetDrawCharacter(true)
					else
						ptr_cast(game.CurrentState):SetDrawCharacter(false)
					end
				end
			},
			Gui.CheckBox "Drawwireframe"
			{	
				Text = "Draw WireFrame",
				Size = Vector2(150, 20),
				CheckPosition = "kCheckLeft",
				EventCheckChanged = function() 
					checkedwireframe = not checkedwireframe
					if(checkedwireframe) then
						ptr_cast(game.CurrentState):SetWireFrame(true)
					else
						ptr_cast(game.CurrentState):SetWireFrame(false)
					end
				end
			},
			Gui.CheckBox "Drawphyicalline"
			{	
				Text = "Draw PhyicalLine",
				Size = Vector2(150, 20),
				CheckPosition = "kCheckLeft",
				EventCheckChanged = function() 
					checkedphyicalline = not checkedphyicalline
					if(checkedphyicalline) then
						ptr_cast(game.CurrentState):SetDrawPhyicalLine(true)
					else
						ptr_cast(game.CurrentState):SetDrawPhyicalLine(false)
					end
				end
			},
		},
		--state
		Gui.FlowLayout
		{
			Style = "Gui.Control_50",
			Dock = "kDockTop",
			ControlSpace = 6,
			Align = "kAlignCenter",
			Direction = "kVertical",
			ControlAlign = "kAlignCenterMiddle",
			Size = Vector2(205, 100),
			BackgroundColor = ARGB(255,255,255,255),
			Margin = Vector4(3,3,3,3),
			Gui.Label
			{
				FontSize = 12,
				AutoSize = true,
				Text = "state",
				Margin = Vector4(0,2,0,0),
				TextColor = ARGB(255, 255, 255, 255),
			},
			Gui.CheckBox "Crouch"
			{	
				Text = "Crouch",
				Size = Vector2(150, 20),
				CheckPosition = "kCheckLeft",
				EventCheckChanged = function() 
					checkedcrouch = not checkedcrouch
					if(checkedcrouch) then
						ptr_cast(game.CurrentState):SetCharacterCrouch(true)
					else
						ptr_cast(game.CurrentState):SetCharacterCrouch(false)
					end
				end
			},
			Gui.CheckBox "Walk"
			{	
				Text = lang:GetText("Walk ( 米总 )"),
				Size = Vector2(150, 20),
				CheckPosition = "kCheckLeft",
				EventCheckChanged = function() 
					checkedcrouch = not checkedcrouch
					if(checkedcrouch) then
						ptr_cast(game.CurrentState):SetCharacterCrouch(true)
					else
						ptr_cast(game.CurrentState):SetCharacterCrouch(false)
					end
				end
			},
		},
		--Animation
		Gui.FlowLayout
		{
			Style = "Gui.Control_50",
			Dock = "kDockTop",
			ControlSpace = 6,
			Align = "kAlignCenter",
			Direction = "kVertical",
			ControlAlign = "kAlignCenterMiddle",
			Size = Vector2(205, 350),
			BackgroundColor = ARGB(255,255,255,255),
			Margin = Vector4(3,3,3,3),
			Gui.Label
			{
				FontSize = 12,
				AutoSize = true,
				Text = "Animation",
				Margin = Vector4(0,2,0,0),
				TextColor = ARGB(255, 255, 255, 255),
			},
			Gui.Button
			{
				Style = "Gui.Buttonsimhei14",
				Text = "Shoot",
				Size = Vector2(55, 25),
				Margin = Vector4(-120,0,0,0),
				ReceiveKey = false,
				EventClick = function()
					ptr_cast(game.CurrentState):SetCharacterShoot(checkedmultishoot)
				end
			},
			Gui.CheckBox "MultiShoot"
			{	
				Text = "MultiShoot",
				Size = Vector2(120, 25),
				Margin = Vector4(70,-33,0,0),
				CheckPosition = "kCheckLeft",
				EventCheckChanged = function() 
					checkedmultishoot = not checkedmultishoot
				end
			},
			Gui.Button
			{
				Style = "Gui.Buttonsimhei14",
				Text = "Reload",
				Size = Vector2(55, 25),
				Margin = Vector4(-120,0,0,0),
				ReceiveKey = false,
				EventClick = function()
					ptr_cast(game.CurrentState):SetCharacterReload(checkedmultireload)
				end
			},
			Gui.CheckBox "MultiReload"
			{	
				Text = "MultiReload",
				Size = Vector2(120, 25),
				Margin = Vector4(70,-33,0,0),
				CheckPosition = "kCheckLeft",
				EventCheckChanged = function() 
					checkedmultireload = not checkedmultireload
				end
			},
			Gui.Label
			{
				FontSize = 12,
				AutoSize = true,
				Text = "Knife",
				Margin = Vector4(0,2,0,0),
				TextColor = ARGB(255, 255, 255, 255),
			},
			Gui.Button
			{
				Style = "Gui.Buttonsimhei14",
				Text = "Stab1",
				Size = Vector2(60, 25),
				Margin = Vector4(-65,0,0,0),
				ReceiveKey = false,
				EventClick = function()
					ptr_cast(game.CurrentState):SetCharacterStab()
				end
			},
			Gui.Button
			{
				Style = "Gui.Buttonsimhei14",
				Text = "Stab2",
				Size = Vector2(60, 25),
				Margin = Vector4(65,-30,0,0),
				ReceiveKey = false,
				EventClick = function()
					ptr_cast(game.CurrentState):SetCharacterLightStab()
				end
			},
			Gui.Button
			{
				Style = "Gui.Buttonsimhei14",
				Text = "StabHit1",
				Size = Vector2(80, 25),
				Margin = Vector4(-85,0,0,0),
				ReceiveKey = false,
				EventClick = function()
					ptr_cast(game.CurrentState):SetCharacterStabHit()
				end
			},
			Gui.Button
			{
				Style = "Gui.Buttonsimhei14",
				Text = "StabHit2",
				Size = Vector2(80, 25),
				Margin = Vector4(85,-30,0,0),
				ReceiveKey = false,
				EventClick = function()
					ptr_cast(game.CurrentState):SetCharacterLightStabHit()
				end
			},
			Gui.Label
			{
				FontSize = 12,
				AutoSize = true,
				Text = "MultiGroup",
				Margin = Vector4(0,2,0,0),
				TextColor = ARGB(255, 255, 255, 255),
			},
			Gui.Textbox "Group"
			{
				Text = "",
				Size = Vector2(150, 30),
				Margin = Vector4(0, 15, 0, 0),
				TextColor = ARGB(255, 255, 239, 206),
			},	
			Gui.Label
			{
				FontSize = 12,
				AutoSize = true,
				Text = "GroupAnimation",
				Margin = Vector4(0,2,0,0),
				TextColor = ARGB(255, 255, 255, 255),
			},
			Gui.Textbox "Animation"
			{
				Text = "",
				Size = Vector2(150, 30),
				Margin = Vector4(0, 15, 0, 0),
				TextColor = ARGB(255, 255, 239, 206),
			},	
			Gui.Button
			{
				Style = "Gui.Buttonsimhei14",
				Text = "LoadAnimation",
				Size = Vector2(140, 30),
				ReceiveKey = false,
				EventClick = function()
					ptr_cast(game.CurrentState):LoadAnimation(ui_right.Group.Text,ui_right.Animation.Text)
				end
			},
		}
	}
}

ui_right.UI_WINDOWS_RIGHT.Parent = gui
ui_right.UI_WINDOWS_RIGHT:SetScreenPos( 2, 1, 0 )

function state.EventLeave()
	Gui.Clear(ui_right)
	ui_right = nil
	state.EventLeave = nil
end

function state.EventLoadCbxCharater()
	ui_right.cbx_character:AddItem("fireman")
	ui_right.cbx_character:AddItem("butcher")
	ui_right.cbx_character:AddItem("nurse")
	ui_right.cbx_character:AddItem("officelady")
	ui_right.cbx_character:AddItem("leader")
	ui_right.cbx_character.Text = "fireman"
	
	ui_right.cbx_character_mode:AddItem("firstPerson")
	ui_right.cbx_character_mode:AddItem("thirdperson")
	ui_right.cbx_character_mode.Text = "thirdperson"
	
	ui_right.cbx_weapon:AddItem("rocketlauncher")
	ui_right.cbx_weapon:AddItem("shotgun")
	ui_right.cbx_weapon:AddItem("fireaxe")
	ui_right.cbx_weapon.Text = "rocketlauncher"
end

function LoadCbxWeapon(charaterindex)
	if count == 0 then
		ui_right.cbx_weapon:RemoveAll()
		ui_right.cbx_weapon:AddItem("rocketlauncher")
		ui_right.cbx_weapon:AddItem("shotgun")
		ui_right.cbx_weapon:AddItem("fireaxe")
		ui_right.cbx_weapon.Text = "rocketlauncher"
	end
	if count == 1 then
		ui_right.cbx_weapon:RemoveAll()
		ui_right.cbx_weapon:AddItem("minigun")
		ui_right.cbx_weapon:AddItem("scattergun")
		ui_right.cbx_weapon:AddItem("kukri")
		ui_right.cbx_weapon.Text = "minigun"
	end
	if count == 2 then
		ui_right.cbx_weapon:RemoveAll()
		ui_right.cbx_weapon:AddItem("Syringegun")
		ui_right.cbx_weapon:AddItem("Laser")
		ui_right.cbx_weapon:AddItem("bonesaw")
		ui_right.cbx_weapon.Text = "Syringegun"
	end
	if count == 3 then
		ui_right.cbx_weapon:RemoveAll()
		ui_right.cbx_weapon:AddItem("sniperrifle")
		ui_right.cbx_weapon:AddItem("pistol")
		ui_right.cbx_weapon:AddItem("taser")
		ui_right.cbx_weapon.Text = "sniperrifle"
	end
	if count == 4 then
		ui_right.cbx_weapon:RemoveAll()
		ui_right.cbx_weapon:AddItem("mk18")
		ui_right.cbx_weapon:AddItem("deserteagle")
		ui_right.cbx_weapon:AddItem("sword")
		ui_right.cbx_weapon.Text = "mk18"
	end
end