require "sys/all.lua"
require "text.lua"
require "login_new.lua"
require "settings.lua"
require "kick_person.lua"
require "release_profession.lua"
require "VersionChange.lua"

L_Settings.Init()
L_Kickperson.Init()

local state = ptr_cast(game.CurrentState)

function gui.EventSizeChanged()
	L_Login_new.AlignUI()
	L_Settings.AlignUI()
	L_Kickperson.AlignUI()
end

function state.EventLeave()
	L_Settings.Hide()
	L_Kickperson.Hide()
	L_Login_new.Hide()
	gui.EventSizeChanged = nil
end

L_Login_new.Show()
