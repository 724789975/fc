module("L_Text", package.seeall)

--1.仅带“确定”的弹出框,ESC/Enter可以取消
--2.1秒消失的弹出框,ESC/Enter可以取消
--3.带“确定”和“取消”的弹出框,ESC不可取消
--4.在对应控件周围显示
--5.全窗口信息提示,ESC不可取消
--6.聊天框系统消息,ESC不可取消

function StrTeam01() return lang:GetText("添加关注成功") 			end --2
function StrTeam02() return lang:GetText("XXX已在你的关注中") 		end --2  modified
function StrTeam03() return lang:GetText("确定删除此关注?") end --3  modified
-- 这种情况不会发生了 没有会导致此情况的按钮 function StrTeam04() return lang:GetText("不能申请。 \n请先退出当前战队。") end --1
function StrTeam05() return lang:GetText("申请已发送") 			end --1
function StrTeam06() return lang:GetText("不能申请。\n你没有达到加入战队的军衔等级。") end --1
function StrTeam07() return lang:GetText("你没有“创建战队”道具。\n请前往商城购买。")	end --1
function StrTeam08() return lang:GetText("创建战队将消耗1个“创建战队”道具")			end--3
function StrTeam09() return lang:GetText("请输入战队名称")		end--4
function StrTeam10() return lang:GetText("请输入战队宣言")		end--4
function StrTeam11() return lang:GetText("请输入战队公告")			end--4  modified
function StrTeam12() return lang:GetText("文字中含有非法字符")	end--4
function StrTeam13() return lang:GetText("此战队名称已经被使用")	end--4  modified
function StrTeam14() return lang:GetText("文字中含有非法字符")	end--4
function StrTeam15() return lang:GetText("文字中含有非法字符")	end--4
function StrTeam16() return lang:GetText("请输入战队宣言")			end--4  modified
function StrTeam17() return lang:GetText("请输入战队公告")			end--4  modified
function StrTeam18() return lang:GetText("你没有“扩充战队”道具。\n请前往商城购买。")	end--1
function StrTeam19() return lang:GetText("扩充成功。\n你的战队已可容纳XXX人。")		end--1 modified
function StrTeam20() return lang:GetText("确定解散战队吗？")			end--3  modified
function StrTeam21() return lang:GetText("确定退出当前战队吗？")		end--3  modified
function StrTeam22() return lang:GetText("不能退出。\n请先授权队长权限。")			end--1
function StrTeam23(name)
	if type(name)~="string" then
		name = "    "
	end
	return string.format(lang:GetText("把 %s 任命为队长？"), name)
end--3
function StrTeam24(name)
	if type(name)~="string" then
		name = "    "
	end
	return string.format(lang:GetText("把 %s 开除出战队？"), name)
end --3
function StrTeam25() return lang:GetText("批准失败。\n此玩家已申请加入其他战队。")	end--1
function StrTeam26() return lang:GetText("批准成功。\nXXX成为战队低级会员")	end--2  modified
function StrTeam27() return lang:GetText("你没有达到可以创建战队的军衔等级")			end--1
function StrTeam28() return lang:GetText("有玩家申请加入您的战队，请快去处理一下吧")  end
function StrTeam29(num)
	if type(num)=="number" then
		return string.format(lang:GetText("你有%d个未处理的战队申请，请赶快处理一下吧"), num)
	else
		return nil
	end
end

function StrFriends01() return lang:GetText("添加好友成功") 		end --2
function StrFriends02() return lang:GetText("XXX已在你的好友中") 	end --2  modified
function StrFriends03(name)
	if type(name)~="string" then
		name = "    "
	end
	return string.format(lang:GetText("确定把 %s 删除?"), name)
end--3,ok,deletefriend_step2           modified
function StrFriends04() return lang:GetText("已删除") 			end --2
function StrFriends05() return lang:GetText("添加黑名单成功") 	end --2
function StrFriends06() return lang:GetText("XXX已在你的黑名单中") 	end --2 modified

function StrSearch01() return lang:GetText("请输入搜索内容") 		end --1
function StrSearch02() return lang:GetText("没有找到任何内容") 	end --1

function StrPlay01() return lang:GetText("进入房间失败") 			end --1
function StrPlay02(name)
	if type(name)~="string" then
		name = "    "
	end
	return string.format(lang:GetText("%s 不在任何房间内"), name)
end --1


enterroom_offline = lang:GetText("XXX不在线")--1 新加的，当加入某人的房间时，不在线的反馈。上面的是在线但不在房间内的反馈。

function StrSquad01(name)
	if type(name)~="string" then
		name = "    "
	end
	return string.format(lang:GetText("“%s ”不在线"), name)
end --1 modified
function StrSquad02(name)
	if type(name)~="string" then
		name = "    "
	end
	return string.format(lang:GetText("你向 %s 发出了组队邀请"), name)
end --6
function StrSquad03() return lang:GetText("邀请已发送")			end --2
function StrSquad04(name)
if type(name)~="string" then
		name = "    "
	end
	return string.format(lang:GetText("%s 已经在别的队伍中"), name)
end --1
function StrSquad05(name)
	if type(name)~="string" then
		name = "    "
	end
	return string.format(lang:GetText("%s 已在你队伍中"), name)
end --1
function StrSquad06() return lang:GetText("你向XXX发出了召唤")	end--6
function StrSquad07() return lang:GetText("邀请已发送")			end--2
function StrSquad08() return lang:GetText("XXX同意了组队")		end--6
function StrSquad09() return lang:GetText("XXX离开了小队")		end--6
function StrSquad10() return lang:GetText("授权XXX为小队队长？")	end--3
function StrSquad11() return lang:GetText("把XXX驱逐出小队？")	end--3
function StrSquad12() return lang:GetText("XXX邀请你加入小队")		end--3
function StrSquad13() return lang:GetText("你加入了xxx的小队")	end--6
function StrSquad14() return lang:GetText("你现在成为队长")			end--2
function StrSquad15() return lang:GetText("你被xxx驱逐出了队伍")	end--6
function StrSquad16() return lang:GetText("你的队伍已解散")		end--6
function StrSquad17() return lang:GetText("邀请失败")				end--1
function StrSquad18() return lang:GetText("你的队伍已满，不能再发出邀请")				end--6 我刚加的我刚加的，当队伍满员时
function StrPlayGame01(name)
	if type(name)~="string" then
		name = "    "
	end
	return string.format(lang:GetText("“%s ”现在不在任何服务器内"), name)
end --1
function StrPlayGame02(name)
	if type(name)~="string" then
		name = "    "
	end
	return string.format(lang:GetText("“%s ”现在不在任何频道内"), name)
end --1
function StrPlayGame03(name)
	if type(name)~="string" then
		name = "    "
	end
	return string.format(lang:GetText("“%s ”现在不在任何房间内"), name)
end --1


function StrGeneral01() return lang:GetText("请选择一个对象")		end--2
function StrGeneral02() return lang:GetText("正在XXX…")			end--5
function StrGeneral03() return lang:GetText("正在连接服务器…")	end--5
function StrGeneral04() return lang:GetText("正在进入大厅…")		end--5
function StrGeneral05() return lang:GetText("无法连接服务器")		end--1
function StrGeneral06() return lang:GetText("与服务器已断开连接")	end--1
function StrGeneral07() return lang:GetText("您的帐号已经在其他的地方登录")	end--1
function StrGeneral08() return lang:GetText("服务器已关闭")		end--1
function StrGeneral09() return lang:GetText("登录失败，请重新登录。")	end--1
function StrGeneral11() return lang:GetText("现在退出游戏？")		end--3
function StrGeneral12() return lang:GetText("你的抵用券不足")		end--1
function StrGeneral13() return lang:GetText("你的G币不足")		end--1
function StrGeneral14() return lang:GetText("你的抵用券不足")		end--1
function StrGeneral15(name)
	if type(name)~="string" then
		name = "    "
	end
	return string.format(lang:GetText("你的 %s 使用时间已经不足2小时，请及时续费"), name)
end
function StrGeneral16(name)
	if type(name)~="string" then
		name = "    "
	end
	return string.format(lang:GetText("你的 %s 使用时间已经不足1小时，请及时续费"), name)
end
function StrGeneral17(name)
	if type(name)~="string" then
		name = "    "
	end
	return string.format(lang:GetText("你的 %s 使用时间已经不足30分钟，请及时续费"), name)
end
function StrGeneral18()	return lang:GetText("你选中的是自己") end --2

function StrCharacter01() return lang:GetText("正在获取角色信息…")	end--5
function StrCharacter02() return lang:GetText("正在创建角色…")	end--5
function StrCharacter03() return lang:GetText("正在删除角色…")	end--5
function StrCharacter04() return lang:GetText("正在进入大厅…")	end--5
function StrCharacter05() return lang:GetText("返回到角色选择界面？")	end--3 modified


function StrMail01() return lang:GetText("请填写收件人")			end--2
function StrMail02() return lang:GetText("请填写主题")			end--2
function StrMail03() return lang:GetText("请填写正文")			end--2
function StrMail04() return lang:GetText("发送失败。\n收件人不存在。")	end--1
function StrMail05() return lang:GetText("取消新邮件的内容？")	end--3
function StrMail06() return lang:GetText("邮件已发送")			end--2
function StrMail07() return lang:GetText("有新邮件到了 赶快看一下吧") end
function StrMail08(num)
	if type(num)=="number" then
		return string.format(lang:GetText("你有%d封未读的新邮件，赶快看一下吧"), num)
	else
		return nil
	end
end

StrLoadingTipGeneral = {
	--lang:GetText("利用“ENTER”键打开聊天输入框"),
	--lang:GetText("“/w”或“F4”键可切换到战队聊天"),
	--lang:GetText("“/p”或“F3”键可切换到组队聊天"),
	--lang:GetText("需要帮助，可随时使用“F1”键查看"),
	--lang:GetText("“F11”键同意踢人，“F12”键反对踢人"),
	--lang:GetText("在观察模式中，点击鼠标“左键”切换至下一个玩家，“右键”切换至上一个玩家，“空格键”切换不同视角"),
	--lang:GetText("大厅中，“右键”点击玩家昵称，可对其进行各种社交操作"),
	--lang:GetText("小队队长可以以小队单位进入一个游戏房间。或者在已有房间内召回小队成员"),
	--lang:GetText("玩家鲜花的数量决定了TA的人气度"),
	--lang:GetText("商城中的商品都可以方便的赠送给你的好友"),
	"",
}
StrLoadingTipTeam = {
	"",
	"",
}
StrLoadingTipTeamDead = {
	"",
}
StrLoadingTipExplode = {
	"",
	"",
}
StrLoadingTipPushVehicle = {
	lang:GetText("欢迎来到推车模式"),
	lang:GetText("推车到目标点"),
}
StrLoadingTipBanner = {
	"",
	"",
	"",
}
StrLoadingTipTreasure = {
	"",
	"",
}
StrLoadingTipZombie = {
	"",
	"",
	"",
	"",
	"",
	"",
	"",
}
StrLoadingTipsModes =
{
	kTeam = StrLoadingTipTeam,
	kHoldPoint = StrLoadingTipExplode,
	kPushVehicle = StrLoadingTipPushVehicle,
}

function StrLoadingTip(gameMode)
	local allTips = {}
	local ModeTips = {}
	if gameMode then
		ModeTips = StrLoadingTipsModes[gameMode]
	end
	if ModeTips then
		for i=1, #ModeTips do
			table.insert(allTips, ModeTips[i])
		end
	end
	for i=1, #StrLoadingTipGeneral do
		table.insert(allTips, StrLoadingTipGeneral[i])
	end
	return allTips[math.random(1, #allTips)]
end

-- playgame.lua用到的相应字符串
kTeam = lang:GetText("团队竞技")
kHoldPoint = lang:GetText("占点")
kPushVehicle = lang:GetText("推车")
kTeamDeathMatch = lang:GetText("歼灭")
kBoss = "BOSS"
kKinfe = lang:GetText("刀战")
kBomb = lang:GetText("爆破")
kStreetBoy = lang:GetText("英雄")
kZombie = lang:GetText("生化")
kBossPVE = lang:GetText("审判")
kItemMode = lang:GetText("道具战")
kCommonZombieMode = lang:GetText("生化感染")
kBossMode2 = lang:GetText("BOSS末日进化")
kEditMode = lang:GetText("编辑")
kTDMode = lang:GetText("TD")
kKillNum = lang:GetText("杀人数")
kPlayTime = lang:GetText("时间")
kPlayRound = lang:GetText("回合数")
kBannerNum = lang:GetText("夺取数")

kFirstView=lang:GetText("第一人称")
kThirdView=lang:GetText("第三人称")

kNormal=lang:GetText("普通赛")
kSniper=lang:GetText("狙击战")
kPistal=lang:GetText("手枪战")
kKnife=lang:GetText("刀战")
kMoonMode = lang:GetText("勇者攀登")
kAdvenceMode = lang:GetText("跳跳乐")
kSurvivalMode = lang:GetText("生存模式")
kMatchingMode = lang:GetText("匹配模式")
-- ranking.lua用到的相应字符串
kCommon=lang:GetText("常规")
kMode=lang:GetText("模式")
kJoy=lang:GetText("趣味")
kWeapon=lang:GetText("武器专精")

kCr=lang:GetText("消费抵用券")
kGp=lang:GetText("消费G币")
kGrenade=lang:GetText("单颗手雷杀人数")
kDrop=lang:GetText("玩家跌死次数")
kGun=lang:GetText("玩家拥有枪械数量")
kReequip=lang:GetText("玩家枪支改装次数")
kFlower=lang:GetText("收到的鲜花数")
kDead=lang:GetText("死亡数")

-- 服务器返回码相应反馈的文字信息
function CreatEnumTable(tbl, index)
    if type(tbl) == "table" then
        local enumtbl = {}
        local enumindex = index or 0
        for i, v in ipairs(tbl) do
            enumtbl[v] = enumindex + i - 1
        end
        return enumtbl
    end
end

ServerError =
{
	"kErrorNone",
};

ServerErrorProxy =
{
	"kErrorProxyStart",

	"kErrorProxyEnterServer",
	"kErrorProxyEnterServerLevelHight",
	"kErrorProxyEnterServerLevelLow",
	"kErrorProxyEnterServerClientCount",

	"kErrorProxyChannelConnect",
	"kErrorProxyChannelConnectLevel",
	"kErrorProxyChannelConnectClientCount",
	"kErrorProxyChannelConnectAlreadyIn",

	"kErrorProxyTeamInvite",
    "kErrorProxyTeamInviteSelf",
    "kErrorProxyTeamInviteAlreadyInOtherTeam",
	"kErrorProxyTeamInviteAlreadyInTeam",
	"kErrorProxyTeamInviteClientError",
	"kErrorProxyTeamInviteNotTeamLeader",
    "kErrorProxyTeamInviteTeamFull",

	"kErrorProxyTeamJoin",
	"kErrorProxyTeamJoinLeaderError",
	"kErrorProxyTeamJoinLeaderIdError",
	"kErrorProxyTeamJoinMemberError",
	"kErrorProxyTeamjoinTeamFull",

	"kErrorProxyTeamCall",
	"kErrorSamePlayerOnline",
	"kErrorBattlePower",
};

ServerErrorChannel =
{
	"kErrorChannelStart",

	"kErrorChannelRoomCreate",
	"kErrorChannelRoomCreateFullRoom",
	"kErrorChannelRoomCreateClientCount",

	"kErrorChannelOption",
	"kErrorChannelOptionRoomError",
    "kErrorChannelOptionLevelIdInvalid",
	"kErrorChannelOptionNotHost",
	"kErrorChannelOptionRuleValue",
	"kErrorChannelOptionVictoryRule",
	"kErrorChannelOptionGameType",
	"kErrorChannelOptionSpawnTime",
	"kErrorChannelOptionSpecialMode",
	"kErrorChannelOptionDeadViewMode",
	"kErrorChannelOptionNoGroup",

	"kErrorChannelRoomEnter",
	"kErrorChannelRoomEnterRoomError",
	"kErrorChannelRoomEnterJoinOnPlaying",
	"kErrorChannelRoomEnterMemberSize",
	"kErrorChannelRoomEnterEnoughSlots",
	"kErrorChannelRoomEnterPassword",
	"kErrorChannelRoomEnterKickClient",
	
	"kErrorChannelRoomChangeTeam",
	"kErrorChannelRoomChangeTeamTeamError",
	"kErrorChannelRoomChangeTeamSameTeam",
	"kErrorChannelRoomChangeTeamIdError",
	"kErrorChannelRoomChangeTeamIsReady",
	"kErrorChannelRoomChangeTeamBalance",

	"kErrorChannelChangeSlot",
	"kErrorChannelChangeSlotRoomError",
	"kErrorChannelChangeSlotNotExist",
	"kErrorChannelChangeSlotEqual",
	"kErrorChannelChangeSlotHasClient",
	"kErrorChannelChangeSlotPreserveForOther",
	"kErrorChannelChangeSlotClose",
	"kErrorChannelChangeSlotReady",
	"kErrorChannelChangeSlotBalance",

	"kErrorChannelChangeSlotStatus",
	"kErrorChannelChangeSlotStatusRoomError",
	"kErrorChannelChangeSlotStatusNotHost",
	"kErrorChannelChangeSlotStatusNotExist",
	"kErrorChannelChangeSlotStatusStateError",
	"kErrorChannelChangeSlotStatusEqual",
	"kErrorChannelChangeSlotStatusBalance",

	"kErrorChannelPreserveSlot",
	"kErrorChannelPreserveSlotCannot",
	"kErrorChannelPreserveSlotAlreadyPreserved",
	"kErrorChannelPreserveSlotAlreadyInRoom",

	"kErrorChannelClientReady",
	"kErrorChannelClientReadyAlready",
	"kErrorChannelClientReadyTeam",
	"kErrorChannelClientReadyHost",
	"kErrorChannelClientReadyBalance",

	"kErrorChannelGameStart",
	"kErrorChannelGameStartBalance",
	"kErrorChannelGameStartGroupMatchNoGroup",
	"kErrorChannelGameStartGroupMatchGroupError",
	"kErrorChannelGameStartGroupMatchGroupEqual",
	"kErrorChannelGameStartGameServerError",
	"kErrorChannelGameStartNoOne",

	"kErrorChannelGameEnter",
	"kErrorChannelGameEnterBalance",
	"kErrorChannelGameEnterJoinOnPlaying",
    "kErrorChannelGameEnterJoinPK",
	"kErrorChannelGameEnterRoomIdError",
	"kErrorChannelGameEnterLeaveWhenConnecting",
    "kErrorChannelGameEnterCharacterInfoError",
	"kErrorChannelGameEnterWeaponDurableError",
	
	"kErrorChannelKickClient",
	"kErrorChannelKickClientNotHost",
	"kErrorChannelKickClientIdError",
	"kErrorChannelDeathMatchPlayerNumberError",
	"kErrorChannelBossPlayerNumberError",
	"kErrorChannelBoss2PlayerNumberError",
	"kErrorChannelStreetBoyPlayerNumberError",
	"kErrorChannelZombiePlayerNumberError",
	"kErrorChannelBombPlayerNumberError",
	"kErrorChannelCommonZombiePlayerNumberError",
	
	"kErrorChannelRoomCreateByGmError",
	
	"kErrorChannelAdvPlayerNumberError",
	"kErrorChannelAdvServerError",
}

ServerError = CreatEnumTable(ServerError)
ServerErrorProxy = CreatEnumTable(ServerErrorProxy, 10000)
ServerErrorChannel = CreatEnumTable(ServerErrorChannel, 20000)

ErrorText = {
[ServerError.kErrorNone] = "kErrorNone",

[ServerErrorProxy.kErrorProxyStart] = "proxy error start",
[ServerErrorProxy.kErrorProxyEnterServer] = lang:GetText("进入服务器错误，请重新进入"),
[ServerErrorProxy.kErrorProxyEnterServerLevelHight] = lang:GetText("您已不再是新手了，去挑战更高级的玩家吧！"),
[ServerErrorProxy.kErrorBattlePower] = lang:GetText("您的战斗力不足，不能进入该服务器！"),
[ServerErrorProxy.kErrorProxyEnterServerLevelLow] = lang:GetText("您还需要更多的磨练才能进入，加油吧！"),
[ServerErrorProxy.kErrorProxyEnterServerClientCount] = lang:GetText("该服务器已满，无法进入"),

[ServerErrorProxy.kErrorProxyChannelConnect] = lang:GetText("进入频道错误，请重新进入"),
[ServerErrorProxy.kErrorProxyChannelConnectLevel] = lang:GetText("您已不再是新手了，去挑战更高级的玩家吧！"),
[ServerErrorProxy.kErrorProxyChannelConnectClientCount] = lang:GetText("该频道已满，无法进入"),
[ServerErrorProxy.kErrorProxyChannelConnectAlreadyIn] = lang:GetText("你已经在频道中，请不要重复点击"),

[ServerErrorProxy.kErrorProxyTeamInvite] = lang:GetText("你不能邀请他"),
[ServerErrorProxy.kErrorProxyTeamInviteSelf] = lang:GetText("你无法邀请自己"),
[ServerErrorProxy.kErrorProxyTeamInviteAlreadyInOtherTeam] = lang:GetText("该玩家已在别的组队中"),
[ServerErrorProxy.kErrorProxyTeamInviteAlreadyInTeam] = lang:GetText("该玩家已在你的组队中"),
[ServerErrorProxy.kErrorProxyTeamInviteClientError] = lang:GetText("你不能邀请他"),
[ServerErrorProxy.kErrorProxyTeamInviteNotTeamLeader] = lang:GetText("你不是队长"),
[ServerErrorProxy.kErrorProxyTeamInviteTeamFull] = lang:GetText("组队人数已达上限"),

[ServerErrorProxy.kErrorProxyTeamJoin] = lang:GetText("加入组队失败"),
[ServerErrorProxy.kErrorProxyTeamJoinLeaderError] = lang:GetText("该组队已不存在"),
[ServerErrorProxy.kErrorProxyTeamJoinLeaderIdError] = lang:GetText("该组队已不存在"),
[ServerErrorProxy.kErrorProxyTeamJoinMemberError] = lang:GetText("加入组队失败"),
[ServerErrorProxy.kErrorProxyTeamjoinTeamFull] = lang:GetText("该组队人数已达上限"),

[ServerErrorProxy.kErrorProxyTeamCall] = lang:GetText("召唤失败"),
[ServerErrorProxy.kErrorSamePlayerOnline] = lang:GetText("同账号已在线，请重新登陆"),

[ServerErrorChannel.kErrorChannelStart] = "channel error start",

[ServerErrorChannel.kErrorChannelRoomCreate] = lang:GetText("无法创建房间"),
[ServerErrorChannel.kErrorChannelRoomCreateFullRoom] = lang:GetText("频道的房间数已满"),
[ServerErrorChannel.kErrorChannelRoomCreateClientCount] = "room create client count error",

[ServerErrorChannel.kErrorChannelOption] = lang:GetText("你不能那么做"),
[ServerErrorChannel.kErrorChannelOptionRoomError] = lang:GetText("你不能那么做"),
[ServerErrorChannel.kErrorChannelOptionLevelIdInvalid] = "option change level id invalid",
[ServerErrorChannel.kErrorChannelOptionNotHost] = lang:GetText("你不是房主"),
[ServerErrorChannel.kErrorChannelOptionRuleValue] = lang:GetText("你不能那么做"),
[ServerErrorChannel.kErrorChannelOptionVictoryRule] = lang:GetText("胜利条件不能修改"),
[ServerErrorChannel.kErrorChannelOptionGameType] = lang:GetText("游戏模式不能修改"),
[ServerErrorChannel.kErrorChannelOptionSpawnTime] = lang:GetText("复活时间不能修改"),
[ServerErrorChannel.kErrorChannelOptionSpecialMode] = lang:GetText("特殊模式不能修改"),
[ServerErrorChannel.kErrorChannelOptionDeadViewMode] = lang:GetText("死亡视角不能修改"),
[ServerErrorChannel.kErrorChannelOptionNoGroup] = lang:GetText("不能选择战队战"),

[ServerErrorChannel.kErrorChannelRoomEnter] = lang:GetText("无法进入该房间"),
[ServerErrorChannel.kErrorChannelRoomEnterRoomError] = lang:GetText("该房间已不存在"),
[ServerErrorChannel.kErrorChannelRoomEnterJoinOnPlaying] = lang:GetText("该房间无法中途加入"),
[ServerErrorChannel.kErrorChannelRoomEnterMemberSize] = "room enter member size greater than 4",
[ServerErrorChannel.kErrorChannelRoomEnterEnoughSlots] = lang:GetText("该房间没有足够的空位"),
[ServerErrorChannel.kErrorChannelRoomEnterPassword] = lang:GetText("当前房间不可进或密码错误"),
[ServerErrorChannel.kErrorChannelRoomEnterKickClient] = lang:GetText("你已经被踢出房间，无法再次进入"),

[ServerErrorChannel.kErrorChannelRoomChangeTeam] = lang:GetText("无法切换阵营"),
[ServerErrorChannel.kErrorChannelRoomChangeTeamTeamError] = "room change team team error",
[ServerErrorChannel.kErrorChannelRoomChangeTeamSameTeam] = lang:GetText("你已在该阵营中"),
[ServerErrorChannel.kErrorChannelRoomChangeTeamIdError] = "room change team team client in room id error",
[ServerErrorChannel.kErrorChannelRoomChangeTeamIsReady] = lang:GetText("你在准备状态，无法切换阵营"),
[ServerErrorChannel.kErrorChannelRoomChangeTeamBalance] = lang:GetText("人数不平衡，无法切换阵营"),

[ServerErrorChannel.kErrorChannelChangeSlot] = lang:GetText("你不能切换到该槽位"),
[ServerErrorChannel.kErrorChannelChangeSlotRoomError] = lang:GetText("你不能那么做"),
[ServerErrorChannel.kErrorChannelChangeSlotNotExist] = lang:GetText("你不能切换到该槽位"),
[ServerErrorChannel.kErrorChannelChangeSlotEqual] = lang:GetText("你不能切换到该槽位"),
[ServerErrorChannel.kErrorChannelChangeSlotHasClient] = lang:GetText("你不能切换到该槽位"),
[ServerErrorChannel.kErrorChannelChangeSlotPreserveForOther] = lang:GetText("你不能切换到该槽位"),
[ServerErrorChannel.kErrorChannelChangeSlotClose] = lang:GetText("你不能切换到该槽位"),
[ServerErrorChannel.kErrorChannelChangeSlotReady] = lang:GetText("你不能切换到该槽位"),
[ServerErrorChannel.kErrorChannelChangeSlotBalance] = lang:GetText("你不能切换到该槽位"),

[ServerErrorChannel.kErrorChannelChangeSlotStatus] = lang:GetText("你不能修改该槽位"),
[ServerErrorChannel.kErrorChannelChangeSlotStatusRoomError] = lang:GetText("你不能修改该槽位"),
[ServerErrorChannel.kErrorChannelChangeSlotStatusNotHost] = lang:GetText("你不能修改该槽位"),
[ServerErrorChannel.kErrorChannelChangeSlotStatusNotExist] = lang:GetText("你不能修改该槽位"),
[ServerErrorChannel.kErrorChannelChangeSlotStatusStateError] = lang:GetText("你不能修改该槽位"),
[ServerErrorChannel.kErrorChannelChangeSlotStatusEqual] = lang:GetText("你不能修改该槽位"),
[ServerErrorChannel.kErrorChannelChangeSlotStatusBalance] = lang:GetText("你不能修改该槽位"),

[ServerErrorChannel.kErrorChannelPreserveSlot] = lang:GetText("你不能那么做"),
[ServerErrorChannel.kErrorChannelPreserveSlotCannot] = lang:GetText("没有足够的槽位"),
[ServerErrorChannel.kErrorChannelPreserveSlotAlreadyPreserved] = lang:GetText("该玩家已接受召唤"),
[ServerErrorChannel.kErrorChannelPreserveSlotAlreadyInRoom] = lang:GetText("该玩家已在房间中"),

[ServerErrorChannel.kErrorChannelClientReady] = lang:GetText("无法准备"),
[ServerErrorChannel.kErrorChannelClientReadyAlready] = lang:GetText("你已经准备了"),
[ServerErrorChannel.kErrorChannelClientReadyTeam] = "client ready team error",
[ServerErrorChannel.kErrorChannelClientReadyHost] = "client ready client is host",
[ServerErrorChannel.kErrorChannelClientReadyBalance] = lang:GetText("人数不平衡，无法准备"),

[ServerErrorChannel.kErrorChannelGameStart] = lang:GetText("错误的房间信息，无法开始游戏"),
[ServerErrorChannel.kErrorChannelGameStartBalance] = lang:GetText("战力不平衡，无法开始游戏"),
[ServerErrorChannel.kErrorChannelGameStartGroupMatchNoGroup] = lang:GetText("战力不平衡，无法开始游戏"),
[ServerErrorChannel.kErrorChannelGameStartGroupMatchGroupError] = lang:GetText("战力不平衡，无法开始游戏"),
[ServerErrorChannel.kErrorChannelGameStartGroupMatchGroupEqual] = lang:GetText("战力不平衡，无法开始游戏"),
[ServerErrorChannel.kErrorChannelGameStartGameServerError] = "game start game server start error",
[ServerErrorChannel.kErrorChannelGameStartNoOne] = lang:GetText("房间内只有观察者时无法开始游戏"),

[ServerErrorChannel.kErrorChannelGameEnter] = lang:GetText("无法进入游戏"),
[ServerErrorChannel.kErrorChannelGameEnterBalance] = lang:GetText("人数不平衡，游戏无法开始"),
[ServerErrorChannel.kErrorChannelGameEnterJoinOnPlaying] = lang:GetText("不能中途加入游戏"),
[ServerErrorChannel.kErrorChannelGameEnterJoinPK] = lang:GetText("不能中途加入游戏"),
[ServerErrorChannel.kErrorChannelGameEnterRoomIdError] = lang:GetText("该房间已不存在"),
[ServerErrorChannel.kErrorChannelGameEnterLeaveWhenConnecting] = lang:GetText("该场游戏已经结束"),
[ServerErrorChannel.kErrorChannelGameEnterCharacterInfoError] = lang:GetText("你的角色包含非法游戏信息"),

[ServerErrorChannel.kErrorChannelDeathMatchPlayerNumberError] = lang:GetText("歼灭战两边人数不足"),
[ServerErrorChannel.kErrorChannelBossPlayerNumberError] = lang:GetText("BOSS战人数不足,至少10人才能开始游戏"),
[ServerErrorChannel.kErrorChannelBoss2PlayerNumberError] = lang:GetText("人数不足,至少2人才能开始游戏"),
[ServerErrorChannel.kErrorChannelStreetBoyPlayerNumberError] = lang:GetText("人数不足,至少两边各需要1人才能开始游戏"),
[ServerErrorChannel.kErrorChannelBombPlayerNumberError] = lang:GetText("人数不足,至少两边各需要1人才能开始游戏"),
[ServerErrorChannel.kErrorChannelZombiePlayerNumberError] = lang:GetText("人数不足,至少4人才能开始游戏"), 
[ServerErrorChannel.kErrorChannelCommonZombiePlayerNumberError] = lang:GetText("人数不足,至少2人才能开始游戏"),
[ServerErrorChannel.kErrorChannelAdvPlayerNumberError] = lang:GetText("活动模式人数不足,10人才能开始游戏"),
[ServerErrorChannel.kErrorChannelAdvServerError] = lang:GetText("您所在的服务器不能开启此模式"),


[ServerErrorChannel.kErrorChannelGameEnterWeaponDurableError] = lang:GetText("武器已过期或耐久度为0"),

[ServerErrorChannel.kErrorChannelKickClient] = lang:GetText("你不能那么做"),
[ServerErrorChannel.kErrorChannelKickClientNotHost] = "kick client client is not host",
[ServerErrorChannel.kErrorChannelKickClientIdError] = lang:GetText("该玩家已不在房间内"), 
[ServerErrorChannel.kErrorChannelRoomCreateByGmError] = lang:GetText("该地图为GM地图，不能开启"), 
}


















