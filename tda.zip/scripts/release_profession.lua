module("L_ReleaseProfession",package.seeall)

ui = Gui.Create()
{
	Gui.Control "release_profession"
	{
		Size = Vector2(560,220),
		BackgroundColor = ARGB(0, 255, 255, 255),

		Gui.FlashControl "flashplayer"
		{
			Text = "",
			Size = Vector2(560,220),
			BackgroundColor = ARGB(255, 255, 255, 255),
			UseTime = true,
			DisplayTime = 3,
			EventTimer = function(sender, e)
				ui.btn_release_ok.Visible = true
				UseTime = false
			end
		},
		
		Gui.Button "btn_release_ok"
		{
			Visible = false,
			Size = Vector2(105, 38),
			Location = Vector2(272, 142),
			Text = lang:GetText("确定"),
			TextColor = ARGB(255, 131, 68, 5),
			FontSize = 18,
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/lb_chenjiu_button_normal.dds", Vector4(15,15,15,15)),
				HoverImage = Gui.Image("LobbyUI/lb_chenjiu_button_hover.dds", Vector4(15,15,15,15)),
				DownImage = Gui.Image("LobbyUI/lb_chenjiu_button_down.dds", Vector4(15,15,15,15)),
				DisabledImage = Gui.Image("LobbyUI/lb_chenjiu_button_normal.dds", Vector4(15,15,15,15)),
			},
			EventClick = function()
				ui.btn_release_ok.Visible = false
				ui.flashplayer:CleanData()
				Hide()
			end
		},
	}
}

local modal_win = nil

function Show(cid)
	modal_win = ModalWindow.GetNew("release_profession")
	modal_win.root.Size = Vector2(560,220)
	modal_win.AllowEscToExit = true
	
	ui.release_profession.Parent = modal_win.root
	ui.flashplayer.Text = "lb_releaselock_"..cid
	modal_win.root.BackgroundColor = ARGB(0, 255, 255, 255)
	
	return modal_win
end

function Hide()
	if modal_win then
		modal_win.Close()
		modal_win = nil
	end
end

function AlignUI()

end