module("L_VersionChange",package.seeall)

Version_number = 5 --版本号
local num = 1 --共几张图片
local now_page = 1 --当前页码

VersionChange = Gui.Create()
{
	Gui.Control "content"
	{
		Size = Vector2(1011, 674),
		Dock = "kDockCenter",
		BackgroundColor = ARGB(0, 0, 0, 0),
		
		Gui.Control
		{
			Size = Vector2(1011, 674),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Location = Vector2(0, 0),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/VersionChange/lb_introduction_bg.dds",Vector4(491, 137, 215, 163)),
			},
			
			Gui.Control "c_bg" 
			{
				Size = Vector2(725, 448),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Location = Vector2(145, 100),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/VersionChange/lb_introduction_1.dds",Vector4(0, 0, 0, 0)),
				},
			},
			
			Gui.Button "begin"
			{
				Size = Vector2(280, 80),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Location = Vector2(351, 471),
				Visible = false,
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/VersionChange/lb_introduction_button02_normal.dds", Vector4(0, 0, 0, 0)),
					HoverImage = Gui.Image("LobbyUI/VersionChange/lb_introduction_button02_hover.dds", Vector4(0, 0, 0, 0)),
					DownImage = Gui.Image("LobbyUI/VersionChange/lb_introduction_button02_down.dds", Vector4(0, 0, 0, 0)),
					DisabledImage = Gui.Image("LobbyUI/VersionChange/lb_introduction_button02_normal.dds", Vector4(0, 0, 0, 0)),							
				},
				EventClick = function()
					Hide()
				end
			},
			
			Gui.Button "left"
			{
				Size = Vector2(64, 116),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Location = Vector2(45, 268),
				Enable = false,
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/VersionChange/lb_introduction_button01_normal.dds", Vector4(0, 0, 0, 0),Vector4(1, 0, 0, 1)),
					HoverImage = Gui.Image("LobbyUI/VersionChange/lb_introduction_button01_hover.dds", Vector4(0, 0, 0, 0),Vector4(1, 0, 0, 1)),
					DownImage = Gui.Image("LobbyUI/VersionChange/lb_introduction_button01_down.dds", Vector4(0, 0, 0, 0),Vector4(1, 0, 0, 1)),
					DisabledImage = Gui.Image("LobbyUI/VersionChange/lb_introduction_button01_disabled.dds", Vector4(0, 0, 0, 0),Vector4(1, 0, 0, 1)),							
				},
				EventClick = function()
					VersionChange.right.Enable = true
					now_page = now_page-1
					if now_page < 1 then
						now_page = 1
						VersionChange.left.Enable = false
					end
					VersionChange.c_bg.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/VersionChange/lb_introduction_"..now_page..".dds",Vector4(0, 0, 0, 0)),}
					
					for i=1 , num do
						local ibbtn = ptr_cast(VersionChange.point:GetChildByIndex(i-1))
						if now_page == i then						
							ibbtn.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/VersionChange/lb_introduction_light_hover.dds",Vector4(0, 0, 0, 0)),}	
						else
							ibbtn.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/VersionChange/lb_introduction_light_normal.dds",Vector4(0, 0, 0, 0)),}	
						end
					end
					VersionChange.lb_page_number.Text = now_page.."/"..num
					VersionChange.begin.Visible = false
				end
			},
			
			Gui.Button "right"
			{
				Size = Vector2(64, 116),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Location = Vector2(902, 268),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/VersionChange/lb_introduction_button01_normal.dds", Vector4(0, 0, 0, 0)),
					HoverImage = Gui.Image("LobbyUI/VersionChange/lb_introduction_button01_hover.dds", Vector4(0, 0, 0, 0)),
					DownImage = Gui.Image("LobbyUI/VersionChange/lb_introduction_button01_down.dds", Vector4(0, 0, 0, 0)),
					DisabledImage = Gui.Image("LobbyUI/VersionChange/lb_introduction_button01_disabled.dds", Vector4(0, 0, 0, 0)),							
				},
				EventClick = function()
					VersionChange.left.Enable = true
					now_page = now_page+1
					if now_page > num - 1 then
						now_page = num
						VersionChange.right.Enable = false
						VersionChange.begin.Visible = true
					end
					VersionChange.c_bg.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/VersionChange/lb_introduction_"..now_page..".dds",Vector4(0, 0, 0, 0)),}
					for i=1 , num do
						local ibbtn = ptr_cast(VersionChange.point:GetChildByIndex(i-1))
						if now_page == i then						
							ibbtn.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/VersionChange/lb_introduction_light_hover.dds",Vector4(0, 0, 0, 0)),}	
						else
							ibbtn.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/VersionChange/lb_introduction_light_normal.dds",Vector4(0, 0, 0, 0)),}	
						end
					end
					VersionChange.lb_page_number.Text = now_page.."/"..num
				end
			},

			Gui.FlowLayout "point"
			{
				Location = Vector2(0,567),
				Size = Vector2(969,24),
				Align = "kAlignCenterMiddle",
				ControlAlign = "kAlignCenterMiddle",
				ControlSpace = 6,
			},
			
			Gui.Label "lb_page_number"
			{
				Location = Vector2(800, 567),
				Size = Vector2(53, 23),
				FontSize = 20,
				TextAlign = "kAlignCenterMiddle",
				TextColor = ARGB(255, 89, 85, 82),
				Text = "1/1",
				BackgroundColor = ARGB(0, 255, 255, 255),
			},
			
					--退出
			Gui.Button
			{
				Size = Vector2(48, 48),
				Location = Vector2(880, 32),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_normal.dds", Vector4(10, 10, 10, 10)),
					HoverImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_hover.dds", Vector4(10, 10, 10, 10)),
					DownImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_down.dds", Vector4(10, 10, 10, 10)),
					DisabledImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_disabled.dds", Vector4(0, 0, 0, 0)),	
				},
				EventClick = function()
					Hide()
				end,
			},
		},	
	},	
}

function create_point(index)
	local Point = Gui.Create()
	{
		Gui.Control "root"
		{
			Size = Vector2(16, 16),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/VersionChange/lb_introduction_light_normal.dds",Vector4(0, 0, 0, 0)),
			},
		},
	}

	return Point
end

function Show_VersionChange()
	Versionmodal = ModalWindow.GetNew()
	Versionmodal.root.Size = Vector2(1011, 674)
	Versionmodal.AllowEscToExit = false
	VersionChange.content.Parent = Versionmodal.root
	
	VersionChange.point:OnDestroy()
	for i = 1, num do
		local p = create_point(i)
		p.root.Parent = VersionChange.point
	end

	config.Version = Version_number
	config:SaveVersion()
	local ibbtn = ptr_cast(VersionChange.point:GetChildByIndex(0))
	ibbtn.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/VersionChange/lb_introduction_light_hover.dds",Vector4(0, 0, 0, 0)),}
	VersionChange.lb_page_number.Text = now_page.."/"..num
	if num == 1 then
		VersionChange.right.Enable = false
		VersionChange.begin.Visible = true
	end
end

 function Hide()
	if Versionmodal then
		Versionmodal.Close()
		Versionmodal = nil
	end
end