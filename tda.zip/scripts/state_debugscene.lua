module("SceneViewer", package.seeall)
-- function cache
local Vector3 = Vector3
local Vector2 = Vector2
-- current state
local state = ptr_cast(game.CurrentState)



-- loading progress
 local progress_image = Gui.ProportionIcon("skinC/skinC_loading_bar01.tga", "skinC/skinC_loading_bar02.tga", Vector4(6,6,6,6), Vector4(6,6,6,6))

 local IsShowPatticle = true
--SceneViewer Window
local ui = nil
ui = Gui.Create
{
	Gui.FlowLayout "loadingpanel"
	{
		Visible = true,
		Dock = "kDockFill",
		Align = "kAlignCenterBottom",
		Gui.Label "label"
		{
			Style = "Transparent",
			Size = Vector2(math.ceil(gui.Size.x/3), math.ceil(gui.Size.y/40)),
			Icon = progress_image,
			Margin = Vector4(0, 0, 0, 40),
		},

	},
	Gui.WindowUI "UI_SCENEVIEWER"
	{
		Size = Vector2(220, 900),
		ShowCloseButton = false,
		Text = "SceneView",
		Padding = Vector4(10, 56, 10, 0),
		FontSize = 20,
		Gui.FlowLayout "UI_SCENEVIEWERBODDY"
		{
			Style = "Gui.Control_20",
			Dock = "kDockTop",
			ControlSpace = 5,
			Size = Vector2(205, 830),
			BackgroundColor = ARGB(255, 255, 255, 255),

			Gui.FlowLayout "UI_LOADSCENE"
			{
				Style = "Gui.Control_50",
				Dock = "kDockTop",
				ControlSpace = 8,
				Align = "kAlignCenter",
				Direction = "kVertical",
				ControlAlign = "kAlignCenterMiddle",
				Size = Vector2(180, 100),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Margin = Vector4(3, 3, 3, 3),

				--加载场景
				Gui.Label
				{
					FontSize = 16,
					AutoSize = true,
					Margin = Vector4(0, 5, 0, 0),
					Text = lang:GetText("场景加载"),
					TextColor = ARGB(255, 255, 255, 255),
				},

				Gui.Textbox "Scene_Path_Text"
				{
					Text = "",
					Size = Vector2(150, 30),
					TextColor = ARGB(255, 255, 239, 206),
				},

				Gui.Button "Scene_Path_Button"
				{
					Style = "Gui.Buttonsimhei14",
					Text = lang:GetText("加载场景"),
					Size = Vector2(150, 30),

					EventClick = function()
						str = ui.Scene_Path_Text.Text;
						if str == "" then
							MessageBox.ShowError(lang:GetText("请输入需要添加的场景文件路径"))
						else
							ptr_cast(game.CurrentState):LoadScene(str)
						end
					end
				},
			},

			Gui.FlowLayout "UI_CHECKMAPINFO"
			{
				Style = "Gui.Control_50",
				Dock = "kDockTop",
				ControlSpace = 8,
				Align = "kAlignCenter",
				Direction = "kVertical",
				ControlAlign = "kAlignCenterMiddle",
				Size = Vector2(180, 130),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Margin = Vector4(3, 3, 3, 3),

				Gui.Label
				{
					FontSize = 16,
					AutoSize = true,
					Margin = Vector4(0, 5, 0, 0),
					Text = "",
					TextColor = ARGB(255, 255, 255, 255),
				},

				--粒子信息
				Gui.CheckBox "CheckShowPatticle"
				{
					Text = "ShowPatticle",
					Size = Vector2(150, 30),
					CheckPosition = "kCheckLeft",
					Check = false,
				},

				--地表信息
				Gui.CheckBox "CheckColorMap"
				{	
					Text = "ColorMap",
					Size = Vector2(150, 30),
					CheckPosition = "kCheckLeft",
					Check = true,
					--EventCheckChanged = function() 
						--if(ui.CheckColorMap.Check) then
						--	state.bDrawColorMap = true
						--else
						--	state.bDrawColorMap = false
						--end
					--end
				},

				Gui.CheckBox "CheckLightMap"
				{	
					Text = "LightMap",
					Size = Vector2(150, 30),
					CheckPosition = "kCheckLeft",
					Check = true,
					--EventCheckChanged = function() 
					--	if(ui.CheckLightMap.Check) then
					--		state.bDrawLightMap = true
					--	else
					--		state.bDrawLightMap = false
					--	end
					--end
				},
			},

			--雾化信息
			Gui.FlowLayout "UI_FOGINFO"
			{
				Style = "Gui.Control_50",
				Dock = "kDockTop",
				ControlSpace = 1,
				Align = "kAlignCenter",
				Direction = "kHorizontal",
				ControlAlign = "kAlignCenterMiddle",
				Size = Vector2(180, 130),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Margin = Vector4(3, 3, 3, 3),
				Gui.CheckBox "CheckFog"
				{	
					Text = "ShowFog",
					Size = Vector2(180, 30),
					Margin = Vector4(30, 5, 0, 0),
					--Dock = "kDockRightTop",
					CheckPosition = "kCheckLeft",
					Check = true,
				},
				Gui.Label
				{
					FontSize = 16,
					Size = Vector2(20, 30),
					Text = "i",
					TextColor = ARGB(255, 255, 255, 255),
				},
				Gui.Textbox "Scene_Fogi_Text"
				{
					Text = "0.8",
					Size = Vector2(30, 30),
					TextColor = ARGB(255, 255, 239, 206),
				},
				Gui.Label
				{
					FontSize = 16,
					Size = Vector2(34, 30),
					Text = "min",
					TextColor = ARGB(255, 255, 255, 255),
				},
				Gui.Textbox "Scene_Fogmind_Text"
				{
					Text = "0",
					Size = Vector2(30, 30),
					TextColor = ARGB(255, 255, 239, 206),
				},
				Gui.Label
				{
					FontSize = 16,
					Size = Vector2(34, 30),
					Text = "max",
					TextColor = ARGB(255, 255, 255, 255),
				},
				Gui.Textbox "Scene_Fogmaxd_Text"
				{
					Text = "250",
					Size = Vector2(30, 30),
					TextColor = ARGB(255, 255, 239, 206),
				},
				Gui.Label
				{
					FontSize = 16,
					Size = Vector2(20, 30),
					Text = "r",
					TextColor = ARGB(255, 255, 255, 255),
				},
				Gui.Textbox "Scene_Fogr_Text"
				{
					Text = "0.14",
					Size = Vector2(30, 30),
					TextColor = ARGB(255, 255, 239, 206),
				},
				Gui.Label
				{
					FontSize = 16,
					Size = Vector2(34, 30),
					Text = "  g",
					TextColor = ARGB(255, 255, 255, 255),
				},
				Gui.Textbox "Scene_Fogg_Text"
				{
					Text = "0.5",
					Size = Vector2(30, 30),
					TextColor = ARGB(255, 255, 239, 206),
				},
				Gui.Label
				{
					FontSize = 16,
					Size = Vector2(34, 30),
					Text = "  b",
					TextColor = ARGB(255, 255, 255, 255),
				},
				Gui.Textbox "Scene_Fogb_Text"
				{
					Text = "0.85",
					Size = Vector2(30, 30),
					TextColor = ARGB(255, 255, 239, 206),
				},
				Gui.Button "Fog_Button"
				{
					Style = "Gui.Buttonsimhei14",
					Text = lang:GetText("生 成 雾"),
					Size = Vector2(150, 30),
					EventClick = function()
						if(ui.CheckFog.Check) then
							local i, mind, maxd, r, g, b = tonumber(ui.Scene_Fogi_Text.Text),tonumber(ui.Scene_Fogmind_Text.Text),tonumber(ui.Scene_Fogmaxd_Text.Text),tonumber(ui.Scene_Fogr_Text.Text),tonumber(ui.Scene_Fogg_Text.Text),tonumber(ui.Scene_Fogb_Text.Text)
							state:SetFog(i,mind,maxd, r, g, b)
						end
					end
				}
			},

			--道具信息
			Gui.FlowLayout "UI_PROPINFO"
			{
				Style = "Gui.Control_50",
				Dock = "kDockTop",
				ControlSpace = 3,
				Align = "kAlignCenter",
				Direction = "kHorizontal",
				ControlAlign = "kAlignCenterMiddle",
				Size = Vector2(180, 210),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Margin = Vector4(3, 3, 3, 3),
				Gui.Label
				{
					FontSize = 16,
					AutoSize = true,
					Margin = Vector4(0, 5, 0, 0),
					Text = lang:GetText("道具路径:/mesh/prop/"),
					TextColor = ARGB(255, 255, 255, 255),
				},
				Gui.Textbox "Prop_Path"
				{
					Text = "medkit/Medkit.mesh",
					Size = Vector2(190, 30),
					TextColor = ARGB(255, 255, 239, 206),
				},
				Gui.Label
				{
					FontSize = 16,
					Size = Vector2(190, 30),
					Text = "Position:",
					TextColor = ARGB(255, 255, 255, 255),
				},
				Gui.Label
				{
					FontSize = 16,
					Size = Vector2(30, 30),
					Text = "X:",
					TextColor = ARGB(255, 255, 255, 255),
				},
				Gui.Textbox "Prop_PositionX"
				{
					Text = "0",
					Size = Vector2(30, 30),
					TextColor = ARGB(255, 255, 239, 206),
				},
				Gui.Label
				{
					FontSize = 16,
					Size = Vector2(29, 30),
					Text = "Y:",
					TextColor = ARGB(255, 255, 255, 255),
				},
				Gui.Textbox "Prop_PositionY"
				{
					Text = "1",
					Size = Vector2(30, 30),
					TextColor = ARGB(255, 255, 239, 206),
				},
				Gui.Label
				{
					FontSize = 16,
					Size = Vector2(29, 30),
					Text = "Z:",
					TextColor = ARGB(255, 255, 255, 255),
				},
				Gui.Textbox "Prop_PositionZ"
				{
					Text = "0",
					Size = Vector2(30, 30),
					TextColor = ARGB(255, 255, 239, 206),
				},
				Gui.Label
				{
					FontSize = 16,
					Size = Vector2(190, 30),
					Text = "Rotation:",
					TextColor = ARGB(255, 255, 255, 255),
				},
				Gui.Label
				{
					FontSize = 16,
					Size = Vector2(17, 30),
					Text = "X:",
					TextColor = ARGB(255, 255, 255, 255),
				},
				Gui.Textbox "Prop_RotationX"
				{
					Text = "0",
					Size = Vector2(15, 30),
					TextColor = ARGB(255, 255, 239, 206),
				},
				Gui.Label
				{
					FontSize = 16,
					Size = Vector2(17, 30),
					Text = "Y:",
					TextColor = ARGB(255, 255, 255, 255),
				},
				Gui.Textbox "Prop_RotationY"
				{
					Text = "0",
					Size = Vector2(15, 30),
					TextColor = ARGB(255, 255, 239, 206),
				},
				Gui.Label
				{
					FontSize = 16,
					Size = Vector2(17, 30),
					Text = "Z:",
					TextColor = ARGB(255, 255, 255, 255),
				},
				Gui.Textbox "Prop_RotationZ"
				{
					Text = "0",
					Size = Vector2(15, 30),
					TextColor = ARGB(255, 255, 239, 206),
				},
				Gui.Label
				{
					FontSize = 16,
					Size = Vector2(45, 30),
					Text = "Angle:",
					TextColor = ARGB(255, 255, 255, 255),
				},
				Gui.Textbox "Prop_RotationAngle"
				{
					Text = "0",
					Size = Vector2(15, 30),
					TextColor = ARGB(255, 255, 239, 206),
				},
				Gui.Button "Prop_Button"
				{
					Style = "Gui.Buttonsimhei14",
					Text = lang:GetText("加载道具"),
					Size = Vector2(150, 30),

					EventClick = function()
						local px, py, pz, rx, ry, rz, ra = tonumber(ui.Prop_PositionX.Text),tonumber(ui.Prop_PositionY.Text),tonumber(ui.Prop_PositionZ.Text),tonumber(ui.Prop_RotationX.Text),tonumber(ui.Prop_RotationY.Text),tonumber(ui.Prop_RotationZ.Text),tonumber(ui.Prop_RotationAngle.Text)
						state:AddStaticMesh(ui.Prop_Path.Text,Vector3(px, py, pz), Quaternion(Vector3(rx, ry, rz), ra))
					end
				},

			},

			--资源加载
			Gui.FlowLayout "UI_RESOURCELOAD"
			{
				Style = "Gui.Control_50",
				Dock = "kDockTop",
				ControlSpace = 3,
				Align = "kAlignCenter",
				Direction = "kHorizontal",
				ControlAlign = "kAlignCenterMiddle",
				Size = Vector2(180, 170),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Margin = Vector4(3, 3, 3, 3),
				Gui.Label
				{
					FontSize = 16,
					AutoSize = true,
					Text = lang:GetText("加载资源路径:Data/"),
					TextColor = ARGB(255, 255, 255, 255),
				},
				Gui.Textbox "Text_ReloadResource"
				{
					Text = "",
					Size = Vector2(180, 30),
					TextColor = ARGB(255, 255, 239, 206),
				},
				Gui.Button 
				{
					Style = "Gui.Buttonsimhei14",
					Text = lang:GetText("重新加载"),
					Size = Vector2(150, 30),
					EventClick = function()
						state:ReloadResource(ui.Text_ReloadResource.Text)
					end
				},
				Gui.CheckBox "OnlyShowZone"
				{	
					Text = "OnlyShowZone",
					Size = Vector2(180, 30),
					Margin = Vector4(30, 5, 0, 0),
					--Dock = "kDockRightTop",
					CheckPosition = "kCheckLeft",
					Check = false,
				},
				Gui.Textbox "Text_LightmapIntensity"
				{
					Text = "1.0",
					Size = Vector2(180, 30),
					TextColor = ARGB(255, 255, 239, 206),
				},
				Gui.Button 
				{
					Style = "Gui.Buttonsimhei14",
					Text = "LightmapIntensity",
					Size = Vector2(150, 30),
					EventClick = function()
						state:SetLightmapIntensity(ui.Text_LightmapIntensity.Text)
					end
				},
	
			},

			--相机旋转速度
			Gui.FlowLayout "UI_CAMERAROT"
			{
				Style = "Gui.Control_50",
				Dock = "kDockTop",
				ControlSpace = 3,
				Align = "kAlignCenter",
				Direction = "kHorizontal",
				ControlAlign = "kAlignCenterMiddle",
				Size = Vector2(180, 70),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Margin = Vector4(3, 3, 3, 3),
				Gui.Label
				{
					FontSize = 16,
					AutoSize = true,
					Text = lang:GetText("相机移动速度x"),
					TextColor = ARGB(255, 255, 255, 255),
				},
				Gui.Textbox "Text_Movespeed"
				{
					Text = "1",
					Size = Vector2(35, 30),
					TextColor = ARGB(255, 255, 239, 206),


				},
				Gui.Label
				{
					FontSize = 16,
					AutoSize = true,
					Text = lang:GetText("相机旋转速度x"),
					TextColor = ARGB(255, 255, 255, 255),
				},
				Gui.Textbox "Text_Rotspeed"
				{
					Text = "1",
					Size = Vector2(35, 30),
					TextColor = ARGB(255, 255, 239, 206),
				}

			},
			
		},
	},

	Gui.CheckBox "Show_WindowUI"
	{	
		Text = "",
		Size = Vector2(25, 25),
		CheckPosition = "kCheckLeft",
		Dock = "kDockRightTop",
		Check = true,
		Margin = Vector4(0,15, 15, 0),

	},
}

--控制UI的显示与隐藏
function ui.Show_WindowUI.EventCheckChanged()
	if(ui.Show_WindowUI.Check) then
		ui.UI_SCENEVIEWER:Show()
	else
		ui.UI_SCENEVIEWER:Hide()
	end	
end

--粒子信息
function ui.CheckShowPatticle.EventCheckChanged()
	if(ui.CheckShowPatticle.Check) then
		state:SetParticleVisable(true)
	else
		state:SetParticleVisable(false)
	end
end

--地表信息
function ui.CheckColorMap.EventCheckChanged()
	if(ui.CheckColorMap.Check) then
		state.bDrawColorMap = true
	else
		state.bDrawColorMap = flase
	end
end

function ui.CheckLightMap.EventCheckChanged()
	if(ui.CheckLightMap.Check) then
		state.bDrawLightMap = true
	else
		state.bDrawLightMap = flase
	end
end

--雾化信息
function ui.CheckFog.EventCheckChanged()
	if(ui.CheckFog.Check) then
		local i, mind, maxd, r, g, b = tonumber(ui.Scene_Fogi_Text.Text),tonumber(ui.Scene_Fogmind_Text.Text),tonumber(ui.Scene_Fogmaxd_Text.Text),tonumber(ui.Scene_Fogr_Text.Text),tonumber(ui.Scene_Fogg_Text.Text),tonumber(ui.Scene_Fogb_Text.Text)
		state:SetFog(i,mind,maxd, r, g, b)	
	else
		state:SetFog(0, 1, 0, 0, 0, 0)
	end
end

--资源加载
function ui.OnlyShowZone.EventCheckChanged()
	if(ui.OnlyShowZone.Check) then
		state:SetShowZoneOnly(true)	
	else
		state:SetShowZoneOnly(false)
	end
end

--ui.UI_SCENEVIEWER.Parent = gui
ui.UI_SCENEVIEWER:SetScreenPos(2, 1, 0)

function state.EventLeave()
	print("EventLeave")
	Gui.Clear(ui)
	ui = nil
	state.EventLeave = nil
end

function ui.Text_Movespeed.EventTextChanged()
	print("Text_Movespeed")
	local speed = tonumber(ui.Text_Movespeed.Text)
	state.MoveSpeed = speed
end

function ui.Text_Rotspeed.EventTextChanged()
	print("Text_Rotspeed")
	local speed = tonumber(ui.Text_Rotspeed.Text)
	state.RotSpeed = speed
end

function state.EventProgressMove()
	progress_image.Proportion = state.Progress
end

function state.EventLoadingFailed()
	MessageBox.Show(string.format(lang:GetText("加载场景失败，请输入正确的场景文件路径")), lang:GetText("确定"), function()
								MessageBox.Close()
							end)
end

function state.EventLoadingOk()
	ui.loadingpanel.Visible = false
end

function state.EventLoadingBeginLoad()
	ui.loadingpanel.Visible = true
end
