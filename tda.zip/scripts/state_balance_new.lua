require "game_balance_new.lua"
require "game_boss_balance.lua"
local state = ptr_cast(game.CurrentState)

function gui.EventSizeChanged()
	L_GameBalance.AlignUI()
	L_GameBossBalance.AlignUI()
end

function state.EventSavePhoto()
	MessageBox.ShowWithTimer(1,lang:GetText("截图成功保存在游戏目录的pictures文件夹"))
end

function state.EventLeave()
	state.EventLeave = nil
	L_GameBalance.Hide()
	L_GameBossBalance.Hide()
	L_LobbyMain.AlignUI()
	gui.EventSizeChanged = nil
	
	--Clear any unfinished modal window
	ModalWindow.CloseAll()
end

function state.EventIdleKicked()
	 MessageBox.ShowWithTimer(5, lang:GetText("非常遗憾, 由于闲置时间过长\n您被请出了房间!"))
end

function state.EventAutoStartLeaveBalance()
	local state = ptr_cast(game.CurrentState,"Client.StateBalance")
	local args = {pid = state:GetMyClientInfo().character_id}
	rpc.safecall("stage_clear_open_timeout",args, function() end)
end

L_GameBalance.Show()