module("L_Settings",package.seeall)

--skin
local SettingsComboboxSkin = Gui.ComboBoxSkin
{
	ButtonNormalImage= Gui.Image("LobbyUI/setting/lb_squad_combobox_button2_normal.dds", Vector4(0, 0, 0, 0)),
	ButtonHoverImage = Gui.Image("LobbyUI/setting/lb_squad_combobox_button2_hover.dds", Vector4(0, 0, 0, 0)),
	ButtonDownImage = Gui.Image("LobbyUI/setting/lb_squad_combobox_button2_down.dds", Vector4(0, 0, 0, 0)),
	ButtonDisabledImage = Gui.Image("LobbyUI/setting/lb_squad_combobox_button3_normal.dds", Vector4(0, 0, 0, 0)),
	
	TextNormalImage = Gui.Image("LobbyUI/setting/lb_squad_combobox2_text.dds", Vector4(6, 0, 0, 0)),
	TextHoverImage = Gui.Image("LobbyUI/setting/lb_squad_combobox2_text.dds", Vector4(6, 0, 0, 0)),
	TextDownImage = Gui.Image("LobbyUI/setting/lb_squad_combobox2_text.dds", Vector4(6, 0, 0, 0)),
	TextDisabledImage = Gui.Image("LobbyUI/setting/lb_squad_combobox3_text.dds", Vector4(6, 0, 0, 0)),
}

local color_white = ARGB(255,255,255,255)
local color_black = ARGB(255,0,0,0)
local color_red = ARGB(255,255,0,0)
local color_green = ARGB(255,0,255,0)
local color_blue = ARGB(255,0,0,255)

local language_list = {"zh_CN","en_PH"}
local language_list_name = {"简体中文","English_PH"}

local default_settings =
{
	invite = false,
	resolution = "1024x768",
	full_screen = false,
	refresh_rate = 60,
	aspect_ratio = "All",
	msaa = lang:GetText("无"),
	filter = lang:GetText("三线性（推荐）"),
	Fluency = 0,
	shadow = 0,
	shader_quality = 0,
	model_quality = 0,
	v_sync = false,
	soft_particle = true,

	audio_off = false,
	audio_value = 50,
	music_off = false,
	music_value = 50,
	sound_off = false,
	sound_value = 50,
	
	sensitivity = 4.5,
	sensitivity_sniper = 4.5,
	mzj_sensitivity = 3.0,

	inverse = false,
	seft_hand = false,

	forward = "W",
	backward = "S",
	left = "A",
	right = "D",
	jump = "SPACE",
	reload = "R",
	crouch = "LCONTROL",
	change_weapon = "Q",
	map = "M",
	change = "B",
}

local default_cp =
{
	invite_off = false,
	guide_off = false,
	leader_enter = false,
}

local skin_mouse =
Gui.ControlSkin
{
	BackgroundImage = Gui.Image("LobbyUI/setting/lb_setting_shubiao.dds",Vector4(0,0,0,0)),
}

local function ChangeAudioOff(c)
	ui.ckb_audio_music_off.Check = c
	ui.ckb_audio_sound_off.Check = c
	ui.ckb_audio_off.Check = c
end

local function ChangeAudioValue(v)
	ui.sld_audio_music.CurValue = v*config.ProportionMusic
	ui.sld_audio_sound.CurValue = v*config.ProportionSound
	ui.sld_audio.CurValue = v*config.ProportionRadio
end

local function CheckAudioValue(v)
	if ui.sld_audio.CurValue < v then
		ui.sld_audio.CurValue = v
	end
	config:UpdateAudioProportion()
end

local function BigTitle(text)
	return Gui.Label
	{
		Size = Vector2(0,32),
		Dock = "kDockTop",
		FontSize = 18,
		TextColor = ARGB(255, 52, 50, 50),
		Text = text,
		TextAlign = "kAlignCenterMiddle",
		--BackgroundColor = color_black,
	}
end

local function SmallTitle1(w,text,h)
	return Gui.Label
	{
		Size = Vector2(w,27),
		FontSize = 18,
		TextColor = ARGB(255, 52, 50, 50),
		Text = text,
		Location = Vector2(72, h),
		TextAlign = "kAlignRightMiddle",
	}
end

local function SmallTitle2(w,text)
	return Gui.Label
	{
		Size = Vector2(w,27),
		FontSize = 18,
		TextColor = ARGB(255, 52, 50, 50),
		Text = text,
		TextAlign = "kAlignRightMiddle",
		--BackgroundColor = color_red,
	}
end

local function SmallTitle3(w,text,h)
	return Gui.Label
	{
		Size = Vector2(w,28),
		FontSize = 20,
		TextColor = ARGB(255, 0, 102, 255),
		Text = text,
		Location = Vector2(36, h),
	}
end

local function SmallTitle4(w,text,h)
	return Gui.Label
	{
		Size = Vector2(w,27),
		FontSize = 16,
		TextColor = ARGB(255, 52, 50, 50),
		Text = text,
		Location = Vector2(72, h),
		TextAlign = "kAlignLeftMiddle",
	}
end

--[[local function SpinBox(sb,min,max,step,int)
return Gui.SpinBox(sb)
	{
		Size = Vector2(60,27),
		MaxLength = 4,
		MinValue = min,
		MaxValue = max,
		StepValue = step,
		IsInt = int,
		Precision = 1,
	}
end]]

local function Description(text)
	return Gui.Label
	{
		Size = Vector2(300,38),
		TextColor = ARGB(255, 52, 50, 50),
		Text = text,
		--BackgroundColor = color_green,
	}
end

local function ComboBox(cmb,event)
	return Gui.ComboBox(cmb)
	{
		Size = Vector2(334, 28),
		Skin = SettingsComboboxSkin,
		TextColor = ARGB(255, 52, 50, 50),
		ChildComboListStyle =  "Gui.teamComboList",
		
		EventValueChanged = function(sender, args)
			if event then
				event()
			end
		end,
	}
end

local function CheckBox(ckb,w,text)
	return Gui.CheckBox(ckb)
	{
		Size = Vector2(w+4,23),
		TextColor = ARGB(255, 52, 50, 50),
		Text = text,
		Padding = Vector4(0, 0, 0, 3),
		Skin = Gui.CheckBoxSkin
		{
			OnImage = Gui.Image("LobbyUI/mail/lb_contact_checkbox_down.dds", Vector4(0, 0, 0, 0)),
			OffImage = Gui.Image("LobbyUI/mail/lb_contact_checkbox_normal.dds", Vector4(5, 5, 5, 5)),
			OnDisabledImage = Gui.Image("LobbyUI/setting/lb_shop_checkbox_content.dds", Vector4(5, 5, 5, 5)),
			OffDisabledImage = Gui.Image("LobbyUI/setting/lb_shop_checkbox_bg.dds", Vector4(5, 5, 5, 5)),
		},
		--BackgroundColor = color_red,
	}
end

local function Slider(sld,w)
	return Gui.Slider(sld)
	{
		Size = Vector2(w,20),
		MinValue = 0,
		MaxValue = 100,
		Minimum = 0,
		Maximum = 100,
		
		Skin = Gui.SliderSkin
		{
			--Control
			BackgroundImage = Gui.Image("LobbyUI/setting/lb_setting_scrollbar_bg.dds", Vector4(5, 0, 5, 0)),
		
			--Slider
			ThumbNormalImage= Gui.Image("LobbyUI/setting/lb_setting_scrollbar_slider.dds", Vector4(0, 0, 0, 0)),
			ThumbHoverImage = Gui.Image("LobbyUI/setting/lb_setting_scrollbar_slider.dds", Vector4(0, 0, 0, 0)),
			ThumbDownImage = Gui.Image("LobbyUI/setting/lb_setting_scrollbar_slider.dds", Vector4(0, 0, 0, 0)),
		},
		ThumbSize = Vector2(20,20),
	}
end

local function BigKey(key_name)
	return Gui.Control
	{
		Size = Vector2(46,36),
		BackgroundColor = color_white,
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/setting/keys/setting_icon_"..key_name..".dds",Vector4(0,0,0,0)),
		},
	}
end

local function SmallKey(key_name)
	return Gui.Control
	{
		Size = Vector2(36,36),
		BackgroundColor = color_white,
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/setting/keys/setting_icon_"..key_name..".dds",Vector4(0,0,0,0)),
		},
	}
end

local control_kb_list
local function KeyBox(key_box,i)
	return Gui.KeyBox(key_box)
	{
		Size = Vector2(139,27*i),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/setting/lb_setting_lingmindu_bg.dds", Vector4(10, 10, 10, 10)),
		},
		EventKeyNameChanged =
		function(sender)
			for k,v in ipairs(control_kb_list) do
				if v ~= sender and v.KeyName == sender.KeyName then
					v:Empty()
				end
			end
		end,
		EventKeyConflict =
		function(sender)
			MessageBox.ShowWithConfirm(lang:GetText("该键位已被占用！"),
			function (sender,e)
				ui.ctrl_settings.Focused = true
			end)
		end,
		EventKeyForbidden =
		function()
			MessageBox.ShowWithConfirm(lang:GetText("无法使用该键位！"),
			function (sender,e)
				ui.ctrl_settings.Focused = true
			end)
		end
	}
end

ui = Gui.Create()
{
	Gui.Control "ctrl_settings"
	{
		Size = Vector2(968,687),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Dock = "kDockFill",
		Location = Vector2(0, 0),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/setting/lb_contact_bg1.dds",Vector4(40, 40, 40, 40)),
		},
		Gui.Label 
		{
			Size = Vector2(944,36),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Location = Vector2(11, 10),
			Text = lang:GetText("游戏设置"),
			FontSize = 22,
			TextColor = ARGB(255, 52, 52, 50),
			TextAlign = "kAlignCenterMiddle",
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/setting/lb_shop_buttonfukuan_down.dds",Vector4(5, 5, 5, 5)),
			},
		},
		Gui.Control 
		{
			Size = Vector2(922,515),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Location = Vector2(21, 80),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/setting/lb_contact_bg2.dds",Vector4(21, 25, 21, 46)),
			},
		},
		Gui.Label "j"
		{
			--Visible = false,
			Size = Vector2(908, 38),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Location = Vector2(27, 85),
			Text = lang:GetText("基本选项"),
			FontSize = 22,
			TextColor = ARGB(255, 52, 52, 50),
			TextAlign = "kAlignCenterMiddle",
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/setting/lb_shop_buttonfukuan_down.dds",Vector4(5, 5, 5, 5)),
			},
		},
-------------------------------------------------------------------------------------------------------------------	
		Gui.Button "settings_game"
		{
			Text = lang:GetText("游戏"),
			TextColor = ARGB(255, 52, 50, 50),
			Location = Vector2(47, 52),
			Size = Vector2(175, 28),
			BackgroundColor = ARGB(255, 255, 255, 255),
			FontSize = 18,
			PushDown = true,
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/setting/lb_contact_tab1_normal.dds", Vector4(0, 0, 0, 0)),
				HoverImage = Gui.Image("LobbyUI/setting/lb_contact_tab1_hover.dds", Vector4(0, 0, 0, 0)),
				DownImage = Gui.Image("LobbyUI/setting/lb_contact_tab1_down.dds", Vector4(0, 0, 0, 0)),
				DisabledImage = Gui.Image("LobbyUI/setting/lb_contact_tab1_normal.dds", Vector4(0, 0, 0, 0)),
			},
			EventClick = function()
				ui.settings_game.PushDown = true
				ui.setting_invite.Visible = true
				ui.settings_keys.PushDown = false
				ui.settings_sp.PushDown = false
				ui.setting_shipin.Visible = false
				ui.j.Visible = true
				ui.setting_l.Visible = false
				ui.setting_q.Visible = false
				ui.setting_s.Visible = false
				ui.setting_j.Visible = false
				ui.settings_mouse.PushDown = false
				ui.setting_effact.Visible = false
				ui.setting_all.Visible = false
				ui.settings_music.PushDown = false
				ui.setting_music.Visible = false
				ui.settings_keys_ui.Visible = false
			end
		},
		
		Gui.Control "setting_invite"
		{	
			Size = Vector2(586,467),
			Location = Vector2(168, 78),
			BackgroundColor = ARGB(0, 255, 255, 255),
			
			Gui.Label
			{
				Size = Vector2(200, 24),
				TextColor = ARGB(255, 52, 50, 50),
				TextAlign = "kAlignLeftMiddle",
				Text = lang:GetText("选择语言"),
				FontSize = 14,
				Location = Vector2(60, 60),
			},
			Gui.ComboBox "cmb_lang"
			{
				Size = Vector2(240, 28),
				Skin = SettingsComboboxSkin,
				TextColor = ARGB(255, 52, 50, 50),
				Location = Vector2(265, 62),
				ChildComboListStyle =  "Gui.teamComboList",
			},
			
			Gui.Label
			{
				Size = Vector2(200, 24),
				TextColor = ARGB(255, 52, 50, 50),
				TextAlign = "kAlignLeftMiddle",
				Text = lang:GetText("拒绝邀请"),
				FontSize = 14,
				Location = Vector2(60, 110),
			},
			Gui.CheckBox "ckb_invite"
			{
				Size = Vector2(20,20),
				TextColor = ARGB(255, 52, 50, 50),
				Text = "",
				Padding = Vector4(0, 0, 0, 0),
				Location = Vector2(265, 112),
				Skin = Gui.CheckBoxSkin
				{
					OnImage = Gui.Image("LobbyUI/mail/lb_contact_checkbox_down.dds", Vector4(0, 0, 0, 0)),
					OffImage = Gui.Image("LobbyUI/mail/lb_contact_checkbox_normal.dds", Vector4(5, 5, 5, 5)),
					OnDisabledImage = Gui.Image("LobbyUI/setting/lb_shop_checkbox_content.dds", Vector4(5, 5, 5, 5)),
					OffDisabledImage = Gui.Image("LobbyUI/setting/lb_shop_checkbox_bg.dds", Vector4(5, 5, 5, 5)),
				},
			}
		},
-----------------------------------------------------------------------		
		Gui.Button "settings_sp"
		{
			Text = lang:GetText("视频"),
			TextColor = ARGB(255, 52, 50, 50),
			Location = Vector2(225, 52),
			Size = Vector2(175, 28),
			BackgroundColor = ARGB(255, 255, 255, 255),
			FontSize = 18,
			PushDown = false,
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/setting/lb_contact_tab1_normal.dds", Vector4(0, 0, 0, 0)),
				HoverImage = Gui.Image("LobbyUI/setting/lb_contact_tab1_hover.dds", Vector4(0, 0, 0, 0)),
				DownImage = Gui.Image("LobbyUI/setting/lb_contact_tab1_down.dds", Vector4(0, 0, 0, 0)),
				DisabledImage = Gui.Image("LobbyUI/setting/lb_contact_tab1_normal.dds", Vector4(0, 0, 0, 0)),
			},
			EventClick = function()
				ui.settings_game.PushDown = false
				ui.setting_invite.Visible = false				
				ui.settings_keys.PushDown = false
				ui.settings_sp.PushDown = true
				ui.setting_shipin.Visible = true
				ui.j.Visible = true
				ui.setting_l.Visible = false
				ui.setting_q.Visible = false
				ui.setting_s.Visible = false
				ui.setting_j.Visible = false
				ui.settings_mouse.PushDown = false
				ui.setting_effact.Visible = false
				ui.setting_all.Visible = false
				ui.settings_music.PushDown = false
				ui.setting_music.Visible = false
				ui.settings_keys_ui.Visible = false
			end
		},
		Gui.Control "setting_shipin"
		{	
			Size = Vector2(743,467),
			Location = Vector2(75, 78),
			BackgroundColor = ARGB(0, 255, 255, 255),
			Visible = false,
			--BigTitle(lang:GetText("基本选项")),
			Gui.FlowLayout
			{
				Dock = "kDockFill",
				Padding = Vector4(45,62,30,0),
				LineSpace = 10,
				ControlSpace = 12,
				ControlAlign = "kAlignCenterMiddle",
				--BackgroundColor = color_blue,
				SmallTitle1(238,lang:GetText("分辨率"),140),
				ComboBox("cmb_graphic_resolution"),
				CheckBox("ckb_graphic_full_screen",68,lang:GetText("全	屏")),
				SmallTitle1(238,lang:GetText("画面表现"),197),
				ComboBox("cmb_graphic_fluency",function()																										
													if ui.cmb_graphic_fluency.SelectedIndex == 1 then
														ui.cmb_graphic_shadow.SelectedIndex = 1
														ui.cmb_graphic_model_quality.SelectedIndex = 1
														ui.cmb_graphic_shader_quality.SelectedIndex = 1
														ui.cmb_graphic_filter.SelectedIndex = 0
														ui.cmb_graphic_msaa.SelectedIndex = 0
														ui.ckb_graphic_v_sync.Check = false
														ui.ckb_graphic_soft_particle.Check = false
													elseif ui.cmb_graphic_fluency.SelectedIndex == 2 then
														ui.cmb_graphic_shadow.SelectedIndex = 0
														ui.cmb_graphic_model_quality.SelectedIndex = 0
														ui.cmb_graphic_shader_quality.SelectedIndex = 0
														ui.cmb_graphic_filter.SelectedIndex = 4
														ui.cmb_graphic_msaa.SelectedIndex = 3
														ui.ckb_graphic_v_sync.Check = true
														ui.ckb_graphic_soft_particle.Check = true
													elseif ui.cmb_graphic_fluency.SelectedIndex == 0 then
														ui.cmb_graphic_shadow.SelectedIndex = 1
														ui.cmb_graphic_model_quality.SelectedIndex = 1
														ui.cmb_graphic_shader_quality.SelectedIndex = 1
														ui.cmb_graphic_filter.SelectedIndex = 0
														ui.cmb_graphic_msaa.SelectedIndex = 0
														ui.ckb_graphic_v_sync.Check = false
														ui.ckb_graphic_soft_particle.Check = false
													end
													local is_enable = false
													if ui.cmb_graphic_fluency.SelectedIndex == 0 then
														is_enable = true
													end
													ui.cmb_graphic_shadow.Enable = is_enable
													ui.cmb_graphic_model_quality.Enable = is_enable
													ui.cmb_graphic_shader_quality.Enable = is_enable
													ui.cmb_graphic_filter.Enable = is_enable
													ui.cmb_graphic_msaa.Enable = is_enable
													ui.ckb_graphic_v_sync.Enable = is_enable
													ui.ckb_graphic_soft_particle.Enable = is_enable
												end),
				SmallTitle1(238,lang:GetText("屏幕比例"),254),
				ComboBox("cmb_graphic_aspect"),
				SmallTitle1(238,lang:GetText("刷新率(全屏)"),311),
				ComboBox("cmb_graphic_refresh_rate"),
				SmallTitle1(238,lang:GetText("贴图过滤"),368),
				ComboBox("cmb_graphic_filter"),
				SmallTitle1(238,lang:GetText("抗锯齿"),425),
				ComboBox("cmb_graphic_msaa"),
				SmallTitle1(238,lang:GetText("阴影品质"),482),
				ComboBox("cmb_graphic_shadow"),
				SmallTitle1(238,lang:GetText("模型品质"),539),
				ComboBox("cmb_graphic_model_quality"),
				SmallTitle1(238,lang:GetText("材质品质"),596),
				ComboBox("cmb_graphic_shader_quality"),
				CheckBox("ckb_graphic_v_sync",85+40,lang:GetText("垂直同步")),
				SmallTitle1(488,"",596),
				CheckBox("ckb_graphic_soft_particle",85+40,lang:GetText("软粒子")),
			},
		},	
		
		Gui.Button "settings_mouse"
		{
			Text = lang:GetText("鼠标"),
			TextColor = ARGB(255, 52, 50, 50),
			Location = Vector2(403, 52),
			Size = Vector2(175, 28),
			BackgroundColor = ARGB(255, 255, 255, 255),
			FontSize = 18,
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/setting/lb_contact_tab1_normal.dds", Vector4(0, 0, 0, 0)),
				HoverImage = Gui.Image("LobbyUI/setting/lb_contact_tab1_hover.dds", Vector4(0, 0, 0, 0)),
				DownImage = Gui.Image("LobbyUI/setting/lb_contact_tab1_down.dds", Vector4(0, 0, 0, 0)),
				DisabledImage = Gui.Image("LobbyUI/setting/lb_contact_tab1_normal.dds", Vector4(0, 0, 0, 0)),
			},
			EventClick = function()
				ui.settings_game.PushDown = false	
				ui.setting_invite.Visible = false	
				ui.settings_sp.PushDown = false
				ui.settings_keys.PushDown = false
				ui.j.Visible = false
				ui.settings_mouse.PushDown = true
				ui.settings_music.PushDown = false
				ui.setting_s.Visible = true
				ui.setting_q.Visible = true
				ui.setting_l.Visible = true
				ui.setting_j.Visible = true
				ui.setting_shipin.Visible = false
				ui.setting_effact.Visible = false
				ui.setting_all.Visible = false
				ui.setting_music.Visible = false
				ui.settings_keys_ui.Visible = false
			end
		},
		Gui.Control "setting_l"
		{
			Visible = false,
			Size = Vector2(926,94),
			Location = Vector2(20, 85),
			BackgroundColor = ARGB(0, 255, 255, 255),
			Gui.Label 
			{
				Size = Vector2(908, 38),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Location = Vector2(7, 0),
				Text = lang:GetText("灵敏度"),
				FontSize = 20,
				TextColor = ARGB(255, 52, 52, 50),
				TextAlign = "kAlignCenterMiddle",
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/setting/lb_shop_buttonfukuan_down.dds",Vector4(8, 8, 8, 8)),
				},
			},
			Gui.FlowLayout
			{	
				Dock = "kDockFill",
				Padding = Vector4(0, 38, 0, 0),
				ControlSpace = 15,
				Align = "kAlignCenterMiddle",
				ControlAlign = "kAlignCenterMiddle",
				SmallTitle1(28,"1"),
				Slider("sld_mouse_sensitivity",316),
				SmallTitle1(28,"20"),
				--SpinBox("sld_mouse_sensitivity",1,20,0.1,false),
				Gui.Textbox "txb_mouse_sensitivity"
				{
					Size = Vector2(50,27),
					MaxLength = 4,
					BackgroundColor = ARGB(255, 255, 255, 255),
					TextColor = ARGB(255,159,155,155),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/setting/lb_setting_lingmindu_bg.dds", Vector4(0, 0, 0, 0)),
					},
				},
			},
		},
		Gui.Control "setting_j"
		{
			Visible = false,
			Size = Vector2(926,84),
			Location = Vector2(20, 170),
			BackgroundColor = ARGB(0, 255, 255, 255),
			Gui.Label 
			{
				Size = Vector2(908, 38),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Location = Vector2(7, 0),
				Text = lang:GetText("开镜后灵敏度"),
				FontSize = 20,
				TextColor = ARGB(255, 52, 52, 50),
				TextAlign = "kAlignCenterMiddle",
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/setting/lb_shop_buttonfukuan_down.dds",Vector4(8, 8, 8, 8)),
				},
			},
			Gui.FlowLayout
			{	
				Dock = "kDockFill",
				ControlSpace = 15,
				Padding = Vector4(0, 42, 0, 0),
				Align = "kAlignCenterMiddle",
				ControlAlign = "kAlignCenterMiddle",
				SmallTitle1(28,"1"),
				Slider("sld_miaozhunjing_sensitivity",316),
				SmallTitle1(28,"20"),
				Gui.Textbox "txb_miaozhunjing_sensitivity"
				{
					Size = Vector2(50,27),
					MaxLength = 4,
					BackgroundColor = ARGB(255, 255, 255, 255),
					TextColor = ARGB(255,159,155,155),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/setting/lb_setting_lingmindu_bg.dds", Vector4(0, 0, 0, 0)),
					},
				},
			},
		},
		Gui.Control "setting_q"
		{
			Visible = false,
			Size = Vector2(926,68),
			Location = Vector2(20, 252),
			BackgroundColor = ARGB(0, 255, 255, 255),
			Gui.Label 
			{
				Size = Vector2(908, 38),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Location = Vector2(7, 0),
				Text = lang:GetText("其他选项"),
				FontSize = 20,
				TextColor = ARGB(255, 52, 52, 50),
				TextAlign = "kAlignCenterMiddle",
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/setting/lb_shop_buttonfukuan_down.dds",Vector4(8, 8, 8, 8)),
				},
			},
			Gui.FlowLayout
			{
				
				Dock = "kDockFill",
				Padding = Vector4(0, 47, 0, 0),
				Direction = "kVertical",
				ControlSpace = 15,
				Align = "kAlignCenterMiddle",
				--BackgroundColor = color_blue
				CheckBox("ckb_mouse_inverse",85+40,lang:GetText("鼠标反转")),
				CheckBox("ckb_mouse_left_hand",85+40,lang:GetText("左手持枪")),
			},
		},
		Gui.Control "setting_s"
		{
			Visible = false,
			Size = Vector2(926,250),
			Location = Vector2(20, 322),
			BackgroundColor = ARGB(0, 255, 255, 255),
			Padding = Vector4(0, 38, 0, 0),
			Gui.Label 
			{
				Size = Vector2(908, 38),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Location = Vector2(7, 0),
				Text = lang:GetText("鼠标常规操作说明"),
				FontSize = 20,
				TextColor = ARGB(255, 52, 52, 50),
				TextAlign = "kAlignCenterMiddle",
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/setting/lb_shop_buttonfukuan_down.dds",Vector4(8, 8, 8, 8)),
				},
			},
			Gui.Control
			{
				Size = Vector2(500,187),
				Margin = Vector4(0,16,0,0),
				Dock = "kDockTopCenter",
				--BackgroundColor = ARGB(255, 255, 0, 0),
				Gui.Label
				{
					Location = Vector2(55,17),
					Size = Vector2(167,20),
					TextColor = ARGB(255, 52, 52, 50),
					FontSize = 14,
					TextAlign = "kAlignRightMiddle",
					Text = lang:GetText("切换武器"),
					--BackgroundColor = ARGB(255, 255, 255, 255),
				},
				Gui.Label
				{
					Location = Vector2(320,0),
					Size = Vector2(167,30),
					TextColor = ARGB(255, 52, 52, 50),
					FontSize = 14,
					TextAlign = "kAlignLeftBottom",
					Text = lang:GetText("开镜瞄准"),
					--BackgroundColor = ARGB(255, 255, 255, 255),
				},
				Gui.Label
				{
					Location = Vector2(10,64),
					Size = Vector2(169,20),
					TextColor = ARGB(255, 52, 52, 50),
					FontSize = 14,
					TextAlign = "kAlignRightMiddle",
					Text = lang:GetText("射击"),
					--BackgroundColor = ARGB(255, 255, 255, 255),
				},
				Gui.Control
				{
					Location = Vector2(180,26),
					Size = Vector2(136,161),
					BackgroundColor = ARGB(255,159,155,155),
					Skin = skin_mouse,
				},
			},
		},
		Gui.Control
		{
			Size = Vector2(716,57),
			Location = Vector2(160,550),
			BackgroundColor = ARGB(0,255,255,255),
			Gui.Button "btn_reset"
			{
				Size = Vector2(176,36),
				Location = Vector2(13,10),
				--HighlightTextColor = ARGB(255, 217, 209, 201),高亮时的颜色
				Text = lang:GetText("恢复默认"),
				FontSize = 16,
				Padding = Vector4(0, 0, 0, 7),
				TextColor = ARGB(255, 211, 211, 211),
				HighlightTextColor = ARGB(255, 211, 211, 211),
				TextAlign = "kAlignCenterMiddle",
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/lb_contact_button_normal.tga", Vector4(5, 5, 5, 5)),
					HoverImage = Gui.Image("LobbyUI/team/lb_contact_button_hover.tga", Vector4(5, 5, 5, 5)),
					DownImage = Gui.Image("LobbyUI/team/lb_contact_button_down.tga", Vector4(5, 5, 5, 5)),
					DisabledImage = Gui.Image("LobbyUI/team/lb_contact_button_normal.tga", Vector4(5, 5, 5, 5)),			
				},
			},
			Gui.Button "btn_cancel"
			{
				Size = Vector2(176,36),
				Location = Vector2(450,10),				
				TextColor = ARGB(255, 42, 43, 42),
				--HighlightTextColor = ARGB(255, 217, 209, 201),高亮时的颜色
				Text = lang:GetText("取 消"),
				FontSize = 16,
				Padding = Vector4(0, 0, 0, 7),
				TextColor = ARGB(255, 211, 211, 211),
				HighlightTextColor = ARGB(255, 211, 211, 211),
				TextAlign = "kAlignCenterMiddle",
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/lb_contact_button_normal.tga", Vector4(5, 5, 5, 5)),
					HoverImage = Gui.Image("LobbyUI/team/lb_contact_button_hover.tga", Vector4(5, 5, 5, 5)),
					DownImage = Gui.Image("LobbyUI/team/lb_contact_button_down.tga", Vector4(5, 5, 5, 5)),
					DisabledImage = Gui.Image("LobbyUI/team/lb_contact_button_normal.tga", Vector4(5, 5, 5, 5)),			
				},
			},
			Gui.Button "btn_confirm"
			{
				Size = Vector2(176,36),				
				Location = Vector2(255,10),
				TextColor = ARGB(255, 42, 43, 42),
				--HighlightTextColor = ARGB(255, 217, 209, 201),高亮时的颜色
				FontSize = 16,
				Text = lang:GetText("确 定"),
				Padding = Vector4(0, 0, 0, 7),
				TextColor = ARGB(255, 211, 211, 211),
				HighlightTextColor = ARGB(255, 211, 211, 211),
				TextAlign = "kAlignCenterMiddle",
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/lb_contact_button_normal.tga", Vector4(5, 5, 5, 5)),
					HoverImage = Gui.Image("LobbyUI/team/lb_contact_button_hover.tga", Vector4(5, 5, 5, 5)),
					DownImage = Gui.Image("LobbyUI/team/lb_contact_button_down.tga", Vector4(5, 5, 5, 5)),
					DisabledImage = Gui.Image("LobbyUI/team/lb_contact_button_normal.tga", Vector4(5, 5, 5, 5)),			
				},
			},
		},
		
		Gui.Button "settings_music"
		{
			Text = lang:GetText("音频"),
			TextColor = ARGB(255, 52, 50, 50),
			Location = Vector2(580, 52),
			Size = Vector2(175, 28),
			BackgroundColor = ARGB(255, 255, 255, 255),
			FontSize = 18,
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/setting/lb_contact_tab1_normal.dds", Vector4(0, 0, 0, 0)),
				HoverImage = Gui.Image("LobbyUI/setting/lb_contact_tab1_hover.dds", Vector4(0, 0, 0, 0)),
				DownImage = Gui.Image("LobbyUI/setting/lb_contact_tab1_down.dds", Vector4(0, 0, 0, 0)),
				DisabledImage = Gui.Image("LobbyUI/setting/lb_contact_tab1_normal.dds", Vector4(0, 0, 0, 0)),
			},
			EventClick = function()
				ui.settings_game.PushDown = false	
				ui.setting_invite.Visible = false	
				ui.settings_keys.PushDown = false
				ui.settings_sp.PushDown = false
				ui.setting_shipin.Visible = false
				ui.settings_mouse.PushDown = false
				ui.settings_music.PushDown = true
				ui.j.Visible = false
				ui.setting_l.Visible = false
				ui.setting_q.Visible = false
				ui.setting_s.Visible = false
				ui.setting_j.Visible = false
				ui.setting_effact.Visible = true
				ui.setting_all.Visible = true
				ui.setting_music.Visible = true
				ui.settings_keys_ui.Visible = false
			end
		},

		Gui.Control "setting_all"
		{
			Visible = false,
			Size = Vector2(926,130),
			Location = Vector2(25, 85),
			Gui.Label
			{
				Size = Vector2(908, 38),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Location = Vector2(0, 5),
				Text = lang:GetText("游戏音量"),
				FontSize = 20,
				TextColor = ARGB(255, 52, 52, 50),
				TextAlign = "kAlignCenterMiddle",
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/setting/lb_shop_buttonfukuan_down.dds",Vector4(5, 5, 5, 5)),
				},
			},
			Gui.FlowLayout
			{
				Dock = "kDockFill",
				ControlSpace = 18,
				Padding = Vector4(0, 42, 0, 0),
				Align = "kAlignCenterMiddle",
				ControlAlign = "kAlignCenterMiddle",
				
				CheckBox("ckb_audio_off",50+40,lang:GetText("静音")),
				SmallTitle1(28,"0"),
				Slider("sld_audio",240),
				SmallTitle1(35,"100"),
				Gui.Textbox "sb_audio"
				{
					Readonly = true,
					Size = Vector2(40,28),
					MaxLength = 4,
					BackgroundColor = ARGB(255, 255, 255, 255),
					TextColor = ARGB(255,159,155,155),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/setting/lb_setting_lingmindu_bg.dds", Vector4(0, 0, 0, 0)),
					},
				},
			},
		},
		
		Gui.Control "setting_music"
		{
			Visible = false,
			Size = Vector2(926,130),
			Location = Vector2(25, 225),
			Gui.Label
			{
				Size = Vector2(908, 38),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Location = Vector2(0, 5),
				Text = lang:GetText("音乐音量"),
				FontSize = 20,
				TextColor = ARGB(255, 52, 52, 50),
				TextAlign = "kAlignCenterMiddle",
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/setting/lb_shop_buttonfukuan_down.dds",Vector4(5, 5, 5, 5)),
				},
			},
			Gui.FlowLayout
			{
				Dock = "kDockFill",
				ControlSpace = 18,
				Padding = Vector4(0, 42, 0, 0),
				Align = "kAlignCenterMiddle",
				ControlAlign = "kAlignCenterMiddle",
				
				CheckBox("ckb_audio_music_off",50+40,lang:GetText("静音")),
				SmallTitle1(28,"0"),
				Slider("sld_audio_music",240),
				SmallTitle1(35,"100"),
				Gui.Textbox "sb_audio_music"
				{
					Readonly = true,
					Size = Vector2(40,28),
					MaxLength = 4,
					BackgroundColor = ARGB(255, 255, 255, 255),
					TextColor = ARGB(255,159,155,155),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/setting/lb_setting_lingmindu_bg.dds", Vector4(0, 0, 0, 0)),
					},
				},
			},
		},
		
		Gui.Control "setting_effact"
		{
			Visible = false,
			Size = Vector2(926,130),
			Location = Vector2(25, 365),
			Gui.Label
			{
				Size = Vector2(908, 38),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Location = Vector2(0, 5),
				Text = lang:GetText("音效音量"),
				FontSize = 20,
				TextColor = ARGB(255, 52, 52, 50),
				TextAlign = "kAlignCenterMiddle",
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/setting/lb_shop_buttonfukuan_down.dds",Vector4(5, 5, 5, 5)),
				},
			},
			Gui.FlowLayout
			{
				Dock = "kDockFill",
				ControlSpace = 18,
				Padding = Vector4(0, 42, 0, 0),
				Align = "kAlignCenterMiddle",
				ControlAlign = "kAlignCenterMiddle",
				
				CheckBox("ckb_audio_sound_off",50+40,lang:GetText("静音")),
				SmallTitle1(28,"0"),
				Slider("sld_audio_sound",240),
				SmallTitle1(35,"100"),
				Gui.Textbox "sb_audio_sound"
				{
					Readonly = true,
					Size = Vector2(40,28),
					MaxLength = 4,
					BackgroundColor = ARGB(255, 255, 255, 255),
					TextColor = ARGB(255,159,155,155),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/setting/lb_setting_lingmindu_bg.dds", Vector4(0, 0, 0, 0)),
					},
				},
			},
		},
		
		Gui.Button "settings_keys"
		{
			Text = lang:GetText("快捷键"),
			TextColor = ARGB(255, 52, 50, 50),
			Location = Vector2(758, 52),
			Size = Vector2(175, 28),
			BackgroundColor = ARGB(255, 255, 255, 255),
			FontSize = 18,
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/setting/lb_contact_tab1_normal.dds", Vector4(0, 0, 0, 0)),
				HoverImage = Gui.Image("LobbyUI/setting/lb_contact_tab1_hover.dds", Vector4(0, 0, 0, 0)),
				DownImage = Gui.Image("LobbyUI/setting/lb_contact_tab1_down.dds", Vector4(0, 0, 0, 0)),
				DisabledImage = Gui.Image("LobbyUI/setting/lb_contact_tab1_normal.dds", Vector4(0, 0, 0, 0)),
			},
			EventClick = function()
				ui.settings_game.PushDown = false
				ui.setting_invite.Visible = false					
				ui.settings_keys.PushDown = true
				ui.settings_sp.PushDown = false
				ui.j.Visible = false
				ui.settings_mouse.PushDown = false
				ui.settings_music.PushDown = false
				ui.setting_s.Visible = false
				ui.setting_q.Visible = false
				ui.setting_l.Visible = false
				ui.setting_j.Visible = false
				ui.setting_shipin.Visible = false
				ui.setting_effact.Visible = false
				ui.setting_all.Visible = false
				ui.setting_music.Visible = false
				ui.settings_keys_ui.Visible = true
			end
		},
		
		Gui.Control "settings_keys_ui"
		{
			Visible = false,
			Size = Vector2(915,465),
			Location = Vector2(25, 85),
			--BackgroundColor = color_red,
			Gui.ScrollableControl
			{
				Dock = "kDockFill",
				Padding = Vector4(10,10,10,10),
				VScrollBarDisplay = "kVisible",
				VScrollBarButtonSize = 34,
				AutoScroll = true,
				AutoSize = true,
				Gui.FlowLayout
				{
					AutoSize = true,
					LineSpace = 5,
					Align = "kAlignCenter",
					Gui.Control
					{
						Size = Vector2(885,240),
						--BackgroundColor = color_white,
						Gui.Label
						{
							Size = Vector2(885, 38),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Location = Vector2(0, 0),
							Text = lang:GetText("快捷键设置"),
							FontSize = 20,
							TextColor = ARGB(255, 52, 52, 50),
							TextAlign = "kAlignCenterMiddle",
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/setting/lb_shop_buttonfukuan_down.dds",Vector4(5, 5, 5, 5)),
							},
						},
						Gui.FlowLayout
						{
							Dock = "kDockFill",
							Padding = Vector4(0,45,10,0),
							LineSpace = 5,
							ControlSpace = 5,
							Align = "kAlignLeftTop",
							SmallTitle2(191,lang:GetText("前 进")),
							KeyBox("kb_shortcutl_forward",1),
							SmallTitle2(271,lang:GetText("跳 跃")),
							KeyBox("kb_shortcutl_jump",1),
							SmallTitle2(191,lang:GetText("后 退")),
							KeyBox("kb_shortcutl_backward",1),
							SmallTitle2(271,lang:GetText("装 弹")),
							KeyBox("kb_shortcutl_reload",1),
							SmallTitle2(191,lang:GetText("左 移")),
							KeyBox("kb_shortcutl_left",1),
							SmallTitle2(271,lang:GetText("切换角色")),
							KeyBox("kb_shortcutl_change",1),
							SmallTitle2(191,lang:GetText("右 移")),
							KeyBox("kb_shortcutl_right",1),
							SmallTitle2(271,lang:GetText("切换武器")),
							KeyBox("kb_shortcutl_change_weapon",1),
							SmallTitle2(191,lang:GetText("下 蹲")),
							KeyBox("kb_shortcutl_crouch",1),
							SmallTitle2(271,lang:GetText("打开地图")),
							KeyBox("kb_shortcutl_map",1),
						},
					},
					Gui.Control
					{
						Size = Vector2(885,1150),
						--BackgroundColor = color_white,
						Gui.Label
						{
							Size = Vector2(885, 38),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Location = Vector2(0, 0),
							Text = lang:GetText("其他按键说明(不可设置)"),
							FontSize = 20,
							TextColor = ARGB(255, 52, 52, 50),
							TextAlign = "kAlignCenterMiddle",
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/setting/lb_shop_buttonfukuan_down.dds",Vector4(5, 5, 5, 5)),
							},
						},
						Gui.FlowLayout
						{
							Dock = "kDockFill",
							Padding = Vector4(65,45,10,0),
							LineSpace = 5,
							ControlSpace = 5,
							Align = "kAlignLeftTop",
							
							SmallTitle3(552,lang:GetText("游戏中基本快捷键")),
							SmallTitle4(552,lang:GetText("切换为主武器")),
							SmallKey("1"),
							SmallTitle4(552,lang:GetText("切换为副武器")),
							SmallKey("2"),
							SmallTitle4(552,lang:GetText("切换为近身武器")),
							SmallKey("3"),
							SmallTitle4(552,lang:GetText("切换为特殊武器")),
							SmallKey("4"),
							SmallTitle4(552,lang:GetText("切换炸药包（爆破模式）")),
							SmallKey("5"),
							SmallTitle4(552,lang:GetText("呼出玩家列表")),
							BigKey("tab"),
							SmallTitle4(552,lang:GetText("显示/关闭队友血条")),
							SmallKey("insert"),
							SmallTitle4(552,lang:GetText("游戏内喷灌")),
							SmallKey("t"),
							SmallTitle4(552,lang:GetText("游戏内截图")),
							SmallKey("f9"),
							SmallTitle4(552,lang:GetText("游戏内呼叫医疗兵")),
							SmallKey("f"),
							SmallTitle4(552,lang:GetText("埋雷（爆破模式）")),
							SmallKey("e"),
							SmallTitle4(552,lang:GetText("选人快捷键")),
							SmallKey("f1"),
							SmallKey("f2"),
							SmallKey("f3"),
							SmallKey("f4"),
							SmallKey("f5"),
							SmallTitle3(552,lang:GetText("基本功能快捷键")),
							SmallTitle4(552,lang:GetText("呼出菜单")),
							SmallKey("esc"),
							SmallTitle4(552,lang:GetText("赞成踢人")),
							SmallKey("f11"),
							SmallTitle4(552,lang:GetText("反对踢人")),
							SmallKey("f12"),
							SmallTitle4(552,lang:GetText("提高鼠标灵敏度一级")),
							SmallKey("pgup"),
							SmallTitle4(552,lang:GetText("降低鼠标灵敏度一级")),
							SmallKey("pgdown"),
							SmallTitle4(552,lang:GetText("游戏内输入聊天")),
							BigKey("enter"),
							SmallTitle4(552,lang:GetText("无线电菜单（z）")),
							SmallKey("z"),
							SmallTitle4(552,lang:GetText("无线电菜单（x）")),
							SmallKey("x"),
							SmallTitle4(552,lang:GetText("无线电菜单（c）")),
							SmallKey("c"),
							SmallTitle4(552,lang:GetText("战队基地内建造")),
							SmallKey("j"),
						},
					},
				},
			},
		},
	},
}

control_kb_list =
{
	ui.kb_shortcutl_forward,
	ui.kb_shortcutl_backward,
	ui.kb_shortcutl_left,
	ui.kb_shortcutl_right,
	ui.kb_shortcutl_jump,
	ui.kb_shortcutl_reload,
	ui.kb_shortcutl_change,
	ui.kb_shortcutl_crouch,
	ui.kb_shortcutl_change_weapon,
	ui.kb_shortcutl_map,
}

local function AddMSAA()
	ui.cmb_graphic_msaa:RemoveAll()
	ui.cmb_graphic_msaa:AddItem(lang:GetText("无"))

	if config:CheckMultiSamplerType(2) then
		ui.cmb_graphic_msaa:AddItem(lang:GetText("2x（推荐）"))
	end
	if config:CheckMultiSamplerType(4) then
		ui.cmb_graphic_msaa:AddItem("4x")
	end
	if config:CheckMultiSamplerType(8) then
		ui.cmb_graphic_msaa:AddItem("8x")
	end
	if config:CheckMultiSamplerType(16) then
		ui.cmb_graphic_msaa:AddItem("16x")
	end
end

local filter_list = {}
local function AddTextureFilter()
	ui.cmb_graphic_filter:RemoveAll()
	filter_list[ui.cmb_graphic_filter:AddItem(lang:GetText("三线性（推荐）"))] = 0
	local i = 2
	while i <= 16 do
		if config:CheckAnisotropy(i) then
			filter_list[i] = ui.cmb_graphic_filter:AddItem(lang:GetText("各向异性") .. i .. "X")
		end
		i = i * 2
	end
end

local function AddLanguage()
	ui.cmb_lang:RemoveAll()
	for i = 1, #language_list do
		if language_list[i] == config.UserLanguage then
			ui.cmb_lang:AddItem(language_list_name[i])
		end
	end
	ui.cmb_lang.SelectedIndex = 0
	for i = 1, #language_list do
		if language_list[i] ~= config.UserLanguage and config:CheckLanguages(language_list[i]) == true then
			ui.cmb_lang:AddItem(language_list_name[i])
		end
	end
end

local function AddRefreshRate(value)
	ui.cmb_graphic_refresh_rate:RemoveAll()
	local count = config:GetDisplayModeCount()
	for i = 0, count do
		local refresh_rate = config:FillRefreshRate(i)
		if refresh_rate > 0 and ui.cmb_graphic_refresh_rate:TextToIndex(refresh_rate) < 0 then
			ui.cmb_graphic_refresh_rate:AddItem(refresh_rate)
		end
	end
end


AddMSAA()
AddRefreshRate()
AddTextureFilter()
AddLanguage()

local fluency_list = {lang:GetText("自定义"),lang:GetText("性能优先"),lang:GetText("画质优先")}
for _,v in ipairs(fluency_list) do
	ui.cmb_graphic_fluency:AddItem(v)
end

local shadow_list = {lang:GetText("高"),lang:GetText("低"),lang:GetText("无"),}
for _,v in ipairs(shadow_list) do
	ui.cmb_graphic_shadow:AddItem(v)
end

local model_quality_list = {lang:GetText("高"),lang:GetText("低")}
for _,v in ipairs(model_quality_list) do
	ui.cmb_graphic_model_quality:AddItem(v)
end

local shader_quality_list = {lang:GetText("高"),lang:GetText("低"),}
for _,v in ipairs(shader_quality_list) do
	ui.cmb_graphic_shader_quality:AddItem(v)
end

ui.sld_mouse_sensitivity.MinValue = 1
ui.sld_mouse_sensitivity.MaxValue = 20
ui.sld_mouse_sensitivity.Minimum = 0
ui.sld_mouse_sensitivity.Maximum = 99

ui.sld_miaozhunjing_sensitivity.MinValue = 1
ui.sld_miaozhunjing_sensitivity.MaxValue = 20
ui.sld_miaozhunjing_sensitivity.Minimum = 0
ui.sld_miaozhunjing_sensitivity.Maximum = 95

local function SafeSetCBX(cbx, value)
	local old_index = cbx:TextToIndex(value)
	if old_index < 0 then
		old_index = 0
	end
	cbx.SelectedIndex = old_index
end

local aspect_list = {}

local function UpdateAspectRatio(value)
	ui.cmb_graphic_aspect:RemoveAll()
	ui.cmb_graphic_aspect:AddItem("All")
	aspect_list[0] = 0
	local count = config:GetDisplayModeCount()
	for i = 0, count do
		local resolution = config:FillDisplayMode(i)
		local aspect = resolution.y / resolution.x

		if resolution.z == tonumber(ui.cmb_graphic_refresh_rate.Text) then
			if aspect < 0.75 and ui.cmb_graphic_aspect:TextToIndex(lang:GetText("普通")) < 0 then
				aspect_list[ui.cmb_graphic_aspect:AddItem(lang:GetText("普通"))] = 0
			elseif aspect == 10 / 16 and ui.cmb_graphic_aspect:TextToIndex(lang:GetText("宽屏")) < 0 then
				aspect_list[ui.cmb_graphic_aspect:AddItem(lang:GetText("宽屏"))] = 1
			end
		end
		--[[
			if aspect == 3 / 4 and ui.cmb_graphic_aspect:TextToIndex(lang:GetText("普通(4:3)")) < 0 then
				aspect_list[ui.cmb_graphic_aspect:AddItem(lang:GetText("普通(4:3)"))] = 3 / 4
			elseif aspect == 9 / 16 and ui.cmb_graphic_aspect:TextToIndex(lang:GetText("宽屏(16:9)")) < 0 then
				aspect_list[ui.cmb_graphic_aspect:AddItem(lang:GetText("宽屏(16:9)"))] = 9 / 16
			elseif aspect == 10 / 16 and ui.cmb_graphic_aspect:TextToIndex(lang:GetText("宽屏(16:10)")) < 0 then
				aspect_list[ui.cmb_graphic_aspect:AddItem(lang:GetText("宽屏(16:10)"))] = 10 /16
			end
		--]]
	end
	SafeSetCBX(ui.cmb_graphic_aspect, value)
end

local function UpdateResolution(value)
	ui.cmb_graphic_resolution:RemoveAll()
	local aspect = aspect_list[ui.cmb_graphic_aspect.SelectedIndex]

	local count = config:GetDisplayModeCount()
	for i = 0, count do
		local resolution = config:FillDisplayMode(i)
		local ratio = resolution.y / resolution.x
		if ratio < 0.75 then 
			ratio = 1
		else
			ratio = 0
		end

		local refresh = true

		if ui.ckb_graphic_full_screen.Check then
			refresh = resolution.z == tonumber(ui.cmb_graphic_refresh_rate.Text)
		end

		if refresh and resolution.x > 0 and resolution.y > 0 then
			if ui.cmb_graphic_aspect.SelectedIndex == 0 or ratio == aspect then
				local res = resolution.x.."x"..resolution.y
				if ui.cmb_graphic_resolution:TextToIndex(res) < 0 then
					ui.cmb_graphic_resolution:AddItem(res)
				end
			end
		end
	end

	if not ui.ckb_graphic_full_screen.Check then
		if value ~= "" and ui.cmb_graphic_resolution:TextToIndex(value) < 0 and ui.cmb_graphic_aspect.SelectedIndex == 0 then
			ui.cmb_graphic_resolution:AddItem(value)
			ui.cmb_graphic_aspect.SelectedIndex = 0
		end
	end

	SafeSetCBX(ui.cmb_graphic_resolution, value)
end

function UpdateMSAA(value)
	if value == 2 then
		ui.cmb_graphic_msaa.SelectedIndex = ui.cmb_graphic_msaa:TextToIndex(lang:GetText("2x（推荐）"))
	elseif value == 4 then
		ui.cmb_graphic_msaa.SelectedIndex = ui.cmb_graphic_msaa:TextToIndex("4x")
	elseif value == 8 then
		ui.cmb_graphic_msaa.SelectedIndex = ui.cmb_graphic_msaa:TextToIndex("8x")
	elseif value == 16 then
		ui.cmb_graphic_msaa.SelectedIndex = ui.cmb_graphic_msaa:TextToIndex("16x")
	else
		ui.cmb_graphic_msaa.SelectedIndex = 0
	end
end

function UpdateFilter(v)
	if v == lang:GetText("三线性（推荐）") then
		return 1
	else
		local i = 2
		while i <= 16 do
			local value = lang:GetText("各向异性") .. i .. "X"
			if v == value then
				return i
			end
			i = i * 2
		end
	end
end

local function UpdateInvite(data)
	if data then
		ui.ckb_invite.Check = data.invite
	else
		ui.ckb_invite.Check = config.Invite
	end
end

local function UpdateGraphic(data)
	if data then
		ui.ckb_graphic_full_screen.Check = data.full_screen
		ui.cmb_graphic_refresh_rate.Enable = data.full_screen
		ui.cmb_graphic_refresh_rate.Text = data.refresh_rate

		UpdateMSAA(data.msaa)
		UpdateAspectRatio(value)
		UpdateResolution(data.resolution)
		ui.cmb_graphic_aspect.Text= data.aspect_ratio
		ui.cmb_graphic_filter.Text = data.filter

		ui.cmb_graphic_fluency.SelectedIndex = data.Fluency
		ui.cmb_graphic_shadow.SelectedIndex = data.shadow
		ui.cmb_graphic_model_quality.SelectedIndex = data.model_quality
		ui.cmb_graphic_shader_quality.SelectedIndex = data.shader_quality
		ui.ckb_graphic_v_sync.Check = data.v_sync
		ui.ckb_graphic_soft_particle.Check = data.soft_particle
	else
		ui.ckb_graphic_full_screen.Check = config.FullScreen
		ui.cmb_graphic_refresh_rate.Enable = config.FullScreen
		ui.cmb_graphic_refresh_rate.Text = config.RefreshRate

		UpdateMSAA(config.MSAA)
		UpdateAspectRatio(config.AspectRatio)
		UpdateResolution(config.UserResolution)
		ui.cmb_graphic_filter.SelectedIndex = filter_list[config.Anisotropy]
		ui.cmb_graphic_aspect.Text = config.AspectRatio
		ui.cmb_graphic_fluency.SelectedIndex = config.Fluency
		ui.cmb_graphic_shadow.SelectedIndex = config.Shadow
		ui.cmb_graphic_model_quality.SelectedIndex = config.ModelQuality
		ui.cmb_graphic_shader_quality.SelectedIndex = config.ShaderQuality
		ui.ckb_graphic_v_sync.Check = config.VSync
		ui.ckb_graphic_soft_particle.Check = config.SoftParticle
	end
end

local function UpdateAudio(data)
	if data then
		ui.ckb_audio_off.Check = data.audio_off
		ui.sld_audio.CurValue = data.audio_value
		ui.ckb_audio_music_off.Check = data.music_off
		ui.sld_audio_music.CurValue = data.music_value
		ui.ckb_audio_sound_off.Check = data.sound_off
		ui.sld_audio_sound.CurValue = data.sound_value
	else
		ui.ckb_audio_off.Check = config.AudioOff
		ui.sld_audio.CurValue = config.AudioValue
		ui.ckb_audio_sound_off.Check = game:CategoryGetMute("sound")
		ui.sld_audio_sound.CurValue = game:CategoryGetVolume("sound")
		ui.ckb_audio_music_off.Check = game:CategoryGetMute("music")
		ui.sld_audio_music.CurValue = game:CategoryGetVolume("music")
	end
end

local function UpdateMouse(data)
	if data then
		ui.sld_miaozhunjing_sensitivity.CurValue = data.sensitivity_sniper
		ui.sld_mouse_sensitivity.CurValue = data.sensitivity
		ui.ckb_mouse_inverse.Check = data.inverse
		ui.ckb_mouse_left_hand.Check = data.left_hand
	else
		ui.sld_miaozhunjing_sensitivity.CurValue = config.SensitivitySniper
		ui.sld_mouse_sensitivity.CurValue = config.Sensitivity
		ui.ckb_mouse_inverse.Check = config.InverseMouse
		ui.ckb_mouse_left_hand.Check = config.LeftHand
	end
end

local function UpdateShotcut(data)
	if data then
		ui.kb_shortcutl_forward.KeyName = data.forward
		ui.kb_shortcutl_backward.KeyName = data.backward
		ui.kb_shortcutl_left.KeyName = data.left
		ui.kb_shortcutl_right.KeyName = data.right
		ui.kb_shortcutl_jump.KeyName = data.jump
		ui.kb_shortcutl_reload.KeyName = data.reload
		ui.kb_shortcutl_change.KeyName =data.change
		ui.kb_shortcutl_crouch.KeyName = data.crouch
		ui.kb_shortcutl_change_weapon.KeyName = data.change_weapon
		ui.kb_shortcutl_map.KeyName = data.map
	else
		ui.kb_shortcutl_forward.KeyName = config:ActionToInput("kActionMoveForward")
		ui.kb_shortcutl_backward.KeyName = config:ActionToInput("kActionMoveBackward")
		ui.kb_shortcutl_left.KeyName = config:ActionToInput("kActionMoveLeft")
		ui.kb_shortcutl_right.KeyName = config:ActionToInput("kActionMoveRight")
		ui.kb_shortcutl_jump.KeyName = config:ActionToInput("kActionJump")
		ui.kb_shortcutl_reload.KeyName = config:ActionToInput("kActionReload")
		ui.kb_shortcutl_change.KeyName = config:ActionToInput("kActionUIPack")
		ui.kb_shortcutl_crouch.KeyName = config:ActionToInput("kActionCrouch")
		ui.kb_shortcutl_change_weapon.KeyName = config:ActionToInput("kActionChangeWeapon")
		ui.kb_shortcutl_map.KeyName = config:ActionToInput("kActionUIMap")
	end
end

local function UpdateCustom(data)
	if data then
		ui.ckb_custom_invite_off.Check = data.invite_off
		ui.ckb_custom_guide_off.Check = data.guide_off
		ui.ckb_custom_leader_enter.Check = data.leader_enter
	else
		local cp = game.CharacterProfile
		if cp then
			ui.ckb_custom_invite_off.Check = cp.InviteOff
			ui.ckb_custom_guide_off.Check = cp.GuideOff
			ui.ckb_custom_leader_enter.Check = cp.LeaderEnter
		end
	end
end

local function UpdateSettings()
	local data,load_err = rpc.load_result(config.SettingStream)
	if load_err then
		data = {}
	end
	local my_settings = data.list
	
	--table.foreach(my_settings, print)
	if type(my_settings) ~= "table" then
		my_settings = {}
	end
	setmetatable(my_settings,{__index = default_settings})
	--table.foreach(my_settings, print)
	
	UpdateInvite()
	UpdateGraphic()
	UpdateAudio()
	UpdateMouse()
	UpdateShotcut()
	
	--update language
	for i = 1, #language_list do
		if config.UserLanguage == language_list[i] then
			ui.cmb_lang.Text = language_list_name[i]
		end
	end
	local state = ptr_cast(game.CurrentState,"Client.StateLobby")
	if state == nil then
		ui.cmb_lang.Enable = false
	else
		ui.cmb_lang.Enable = true
	end
	--UpdateCustom()
end

local function ApplyMSAA()
	if ui.cmb_graphic_msaa.Text == lang:GetText("无") then
		config.MSAA = 0
	elseif ui.cmb_graphic_msaa.Text == lang:GetText("2x（推荐）") then
		config.MSAA = 2
	elseif ui.cmb_graphic_msaa.Text == "4x" then
		config.MSAA = 4
	elseif ui.cmb_graphic_msaa.Text == "8x" then
		config.MSAA = 8
	elseif ui.cmb_graphic_msaa.Text == "16x" then
		config.MSAA = 16
	end
end

local function ApplySettings(boolSave)
	config.Invite = ui.ckb_invite.Check
	config.FullScreen = ui.ckb_graphic_full_screen.Check
	config.UserResolution = ui.cmb_graphic_resolution.Text
	config.RefreshRate = tonumber(ui.cmb_graphic_refresh_rate.Text)
	config.Shadow = ui.cmb_graphic_shadow.SelectedIndex
	config.Fluency = ui.cmb_graphic_fluency.SelectedIndex
	config.ModelQuality = ui.cmb_graphic_model_quality.SelectedIndex
	config.ShaderQuality = ui.cmb_graphic_shader_quality.SelectedIndex
	config.VSync = ui.ckb_graphic_v_sync.Check
	ApplyMSAA()
	config.Anisotropy = UpdateFilter(ui.cmb_graphic_filter.Text)
	config.AspectRatio = ui.cmb_graphic_aspect.Text
	config.SoftParticle = ui.ckb_graphic_soft_particle.Check

	ui.ckb_audio_music_off.Tag = ui.ckb_audio_music_off.Check
	ui.sld_audio_music.Tag = ui.sld_audio_music.CurValue
	ui.ckb_audio_sound_off.Tag = ui.ckb_audio_sound_off.Check
	ui.sld_audio_sound.Tag = ui.sld_audio_sound.CurValue
	ui.ckb_audio_off.Tag = ui.ckb_audio_off.Check
	ui.sld_audio.Tag = ui.sld_audio.CurValue
	
	config.AudioOff = ui.ckb_audio_off.Check
	config.AudioValue = ui.sld_audio.CurValue
	game:CategorySetMute("music",ui.ckb_audio_music_off.Check)
	game:CategorySetVolume("music",ui.sld_audio_music.CurValue)
	game:CategorySetMute("sound",ui.ckb_audio_sound_off.Check)
	game:CategorySetVolume("sound",ui.sld_audio_sound.CurValue)
	
	config.Sensitivity = ui.sld_mouse_sensitivity.CurValue
	config.SensitivitySniper = ui.sld_miaozhunjing_sensitivity.CurValue
	config.InverseMouse = ui.ckb_mouse_inverse.Check
	config.LeftHand = ui.ckb_mouse_left_hand.Check
	ui.ckb_mouse_left_hand.Visible = false
	
	config:BindAction("kActionMoveForward",ui.kb_shortcutl_forward.KeyName)
	config:BindAction("kActionMoveBackward",ui.kb_shortcutl_backward.KeyName)
	config:BindAction("kActionMoveLeft",ui.kb_shortcutl_left.KeyName)
	config:BindAction("kActionMoveRight",ui.kb_shortcutl_right.KeyName)
	config:BindAction("kActionJump",ui.kb_shortcutl_jump.KeyName);
	config:BindAction("kActionReload",ui.kb_shortcutl_reload.KeyName);
	config:BindAction("kActionCrouch",ui.kb_shortcutl_crouch.KeyName);
	config:BindAction("kActionChangeWeapon",ui.kb_shortcutl_change_weapon.KeyName);
	config:BindAction("kActionUIMap",ui.kb_shortcutl_map.KeyName);
	config:BindAction("kActionUIPack",ui.kb_shortcutl_change.KeyName);

	local cp = game.CharacterProfile
	--[[if cp then
		cp.InviteOff = ui.ckb_custom_invite_off.Check
		cp.GuideOff = ui.ckb_custom_guide_off.Check
		cp.LeaderEnter = ui.ckb_custom_leader_enter.Check
	end--]]

	if boolSave then
		config:SaveGraphic()
		config:SaveMouse()
		config:SaveAudio()
		config:SaveKeys()
		config:SaveGameing()
		
		index = nil
		for i = 1, #language_list_name do
			if ui.cmb_lang.Text == language_list_name[i] then
				index = i
			end
		end
		
		if index ~= nil and config.UserLanguage ~= language_list[index] then
			MessageBox.ShowWithTwoButtons(lang:GetText("修改语言后需要关闭客户端，\n下次启动生效，请确认还要修改吗？"),lang:GetText("关闭"),lang:GetText("取消"),
			function()
				config.UserLanguage = language_list[index]
				Thread.Quit()
			end,
			nil)
		end
	end
end

function ui.ckb_graphic_full_screen.EventCheckChanged(sender,e)
	ui.cmb_graphic_refresh_rate.Enable = sender.Check
	UpdateResolution(ui.cmb_graphic_resolution.Text)
end

function ui.cmb_graphic_refresh_rate.EventValueChanged(sender,e)
	UpdateAspectRatio(ui.cmb_graphic_aspect.Text)
	UpdateResolution(ui.cmb_graphic_resolution.Text)
end

function ui.cmb_graphic_aspect.EventValueChanged(sender,e)
	UpdateResolution(ui.cmb_graphic_resolution.Text)
end

--[[
function ui.cmb_graphic_shader_quality.EventValueChanged(sender,e)
	local old_shadow = ui.cmb_graphic_shadow.Text
	if sender.Text == lang:GetText("低") then
		ui.ckb_graphic_soft_particle.Check = false
		ui.ckb_graphic_soft_particle.Enable = false
		ui.cmb_graphic_shadow:RemoveAll()
		for i = 1,2 do
			ui.cmb_graphic_shadow:AddItem(shadow_list[i])
		end
		ui.cmb_graphic_shadow.SelectedIndex = 1
	else
		ui.ckb_graphic_soft_particle.Enable = true
		ui.cmb_graphic_shadow:RemoveAll()
		for i = 1,3 do
			ui.cmb_graphic_shadow:AddItem(shadow_list[i])
		end
		ui.cmb_graphic_shadow.SelectedIndex = ui.cmb_graphic_shadow:TextToIndex(old_shadow)
	end
end
--]]
--------------------------------------------------------------------------------------------
function ui.ckb_audio_music_off.EventCheckChanged(sender,e)
	if not c and CommonUtility.IsEventTriggeredByUser(e) then
		local c = sender.Check
		if not c then
			ui.ckb_audio_off.Check = c
		end
	end
end

function ui.ckb_audio_sound_off.EventCheckChanged(sender,e)
	if not c and CommonUtility.IsEventTriggeredByUser(e) then
		local c = sender.Check
		if not c then
			ui.ckb_audio_off.Check = c
		end
	end
end

function ui.ckb_audio_off.EventCheckChanged(sender, e)
	if CommonUtility.IsEventTriggeredByUser(e) then
		local c = sender.Check
		if not c then
			config.AudioOff = c
		end
		ChangeAudioOff(c)
	end
end
--------------------------------------------------------------------------------------------
function ui.sld_audio_music.EventValueChange(sender,e)
	local v = sender.CurValue
	ui.sb_audio_music.Text = string.format("%.0f",v)
	game:CategorySetVolume("music", v)
	if CommonUtility.IsEventTriggeredByUser(e) then
		ui.ckb_audio_music_off.Check = false
		ui.ckb_audio_off.Check = false
		CheckAudioValue(v)
	end
end

function ui.sld_audio_sound.EventValueChange(sender,e)
	local v = sender.CurValue
	ui.sb_audio_sound.Text = string.format("%.0f",v)
	game:CategorySetVolume("sound", v)
	if CommonUtility.IsEventTriggeredByUser(e) then
		ui.ckb_audio_sound_off.Check = false
		ui.ckb_audio_off.Check = false
		CheckAudioValue(v)
	end
end

function ui.sld_audio.EventValueChange(sender, e)
	local v = sender.CurValue
	ui.sb_audio.Text = string.format("%.0f",v)
	config.AudioValue = v
	if CommonUtility.IsEventTriggeredByUser(e) then
		ChangeAudioValue(v)
		ui.ckb_audio_off.Check = false
		ChangeAudioOff(false)
	end
end
--------------------------------------------------------------------------------------------
-- function ui.sb_audio_music.EventValueEnter(sender,e)
	-- local v = sender.Text
	-- ui.sld_audio_music.CurValue = v
	-- CheckAudioValue(v)
-- end
function ui.sb_audio_music.EventLeave(sender,e)
	ui.sld_audio_music.CurValue = sender.Text
end

-- function ui.sb_audio_sound.EventValueEnter(sender,e)
	-- local v = sender.Text
	-- ui.sld_audio_sound.CurValue = v
	-- CheckAudioValue(v)
-- end
function ui.sb_audio_sound.EventLeave(sender,e)
	ui.sld_audio_sound.CurValue = sender.Text
end

-- function ui.sb_audio.EventValueEnter(sender,e)
	-- local v = sender.Text
	-- ui.sld_audio.CurValue = v
	-- ChangeAudioValue(v)
-- end
function ui.sb_audio.EventLeave(sender,e)
	ui.sld_audio.CurValue = sender.Text
end
--------------------------------------------------------------------------------------------
function ui.sld_mouse_sensitivity.EventValueChange(sender,e)
	ui.txb_mouse_sensitivity.Text = string.format("%.1f",sender.CurValue)
end

function ui.txb_mouse_sensitivity.EventValueEnter(sender,e)
	ui.sld_mouse_sensitivity.CurValue = sender.Text
end

function ui.txb_mouse_sensitivity.EventLeave(sender,e)
	ui.sld_mouse_sensitivity.CurValue = sender.Text
end

function ui.sld_miaozhunjing_sensitivity.EventValueChange(sender,e)
	ui.txb_miaozhunjing_sensitivity.Text = string.format("%.1f",sender.CurValue)
end

function ui.txb_miaozhunjing_sensitivity.EventValueEnter(sender,e)
	ui.sld_miaozhunjing_sensitivity.CurValue = sender.Text
end

function ui.txb_miaozhunjing_sensitivity.EventLeave(sender,e)
	ui.sld_miaozhunjing_sensitivity.CurValue = sender.Text
end

--[[function ui.sld_miaozhunjing_sensitivity.EventValueChange(sender,e)
	ui.txb_miaozhunjing_sensitivity.Text = string.format("%.1f",sender.CurValue)
end]]

function ui.btn_reset.EventClick(sender,e)
	MessageBox.ShowWithConfirmCancel(lang:GetText("您确定要恢复初始设置吗？"),
		function(sender,e)
			if ui.settings_game.PushDown == true then
				UpdateInvite(default_settings)
			elseif ui.settings_sp.PushDown == true then
				UpdateGraphic(default_settings)
			elseif ui.settings_mouse.PushDown == true then
				UpdateMouse(default_settings)
			elseif ui.settings_music.PushDown == true then
				UpdateAudio(default_settings)
				config.ProportionMusic = 1
				config.ProportionSound = 1
				config.ProportionRadio = 1
			elseif ui.settings_keys.PushDown == true then
				UpdateShotcut(default_settings)
			end
		end,
	nil)
end

function ui.btn_confirm.EventClick(sender,e)
	if ui.cmb_graphic_resolution.Text == "" then
		MessageBox.ShowWithConfirm(lang:GetText("设置有误,请重新设置！"),
		function(sender,e)
			ui.ctrl_settings.Focused = true
		end
		)
	else
		ApplySettings(true)
		Hide()
	end
end

function ui.btn_cancel.EventClick(sender,e)
	ui.ckb_audio_music_off.Check = ptr_cast(ui.ckb_audio_music_off.Tag)
	ui.sld_audio_music.CurValue = ptr_cast(ui.sld_audio_music.Tag)
	ui.ckb_audio_sound_off.Check = ptr_cast(ui.ckb_audio_sound_off.Tag)
	ui.sld_audio_sound.CurValue = ptr_cast(ui.sld_audio_sound.Tag)
	ui.ckb_audio_off.Check = ptr_cast(ui.ckb_audio_off.Tag)
	ui.sld_audio.CurValue = ptr_cast(ui.sld_audio.Tag)
	UpdateShotcut()
	Hide()
end

local modal_win = nil

function Show()
	UpdateSettings()
	modal_win = ModalWindow.GetNew("settings")
	modal_win.root.Size = Vector2(968,687)
	modal_win.AllowEscToExit = false
	--[[ui.tpd_settings:SelectFirstPage()
	if ptr_cast(game.CurrentState,"Client.StateLobby") or ptr_cast(game.CurrentState,"Client.StateBalance") or ptr_cast(game.CurrentState,"Client.StateMainGame") then
		ui.ctrl_custom.Parent = ui.tpd_settings
	else
		ui.ctrl_custom.Parent = nil
	end--]]
	ui.ctrl_settings.Parent = modal_win.root
	modal_win.root.BackgroundColor = ARGB(0, 255, 255, 255)
	return modal_win
end

function Hide()
	if modal_win then
		modal_win.Close()
		modal_win = nil
	end
end


function AlignUI()
--	if Visible then
--		Gui.Align(win.root, 0.5, 0.5)
--	end
end

ui.ckb_graphic_soft_particle.Check = false

function Init()
	config.EventLoadSettings = function(sender, e)
		print("Loading config settings")
		print(e.Details)
		if e.Details then
			UpdateSettings()
			ApplySettings(false)
		end
	end

	config.EventLoadProfile = function(sender, e)
		print("Character Profile Loaded As: ")
		print(e.Details)
		--test
		--e.Details = testProfileDesc

		local cProfile = game.CharacterProfile
		if e.Details and cProfile then
			local data,load_err = rpc.load_result(e.Details)
			if load_err then
				data = {}
			end
			local profileDesc = data.list
			if type(profileDesc) == "table" then
				cProfile.InviteOff 				= profileDesc.InviteOff
				cProfile.GuideOff				= profileDesc.GuideOff
				cProfile.LeaderEnter			= profileDesc.LeaderEnter
				cProfile.SearchRoomWaiting		= profileDesc.SearchRoomWaiting
				cProfile.SearchRoomPlaying		= profileDesc.SearchRoomPlaying
				cProfile.SearchChannelCurrent	= profileDesc.SearchChannelCurrent
				cProfile.SearchChannelVIP		= profileDesc.SearchChannelVIP
				cProfile.SearchGameTypeIndex	= profileDesc.SearchGameTypeIndex
				cProfile.SearchMapName			= profileDesc.SearchMapName
				cProfile.SearchPlayerNum		= profileDesc.SearchPlayerNum
				cProfile.SearchOptionAutoSave	= profileDesc.SearchOptionAutoSave
				cProfile.LeaderEnterAutoSave	= profileDesc.LeaderEnterAutoSave
			else
				print("Profile data corrupted!")
			end
		end
	end

	config.EventSaveProfile = function(sender, e)
		local profileTable = {}
		local cProfile = game.CharacterProfile
		if cProfile then
			profileTable.InviteOff 				 = cProfile.InviteOff
			profileTable.GuideOff				 = cProfile.GuideOff
			profileTable.LeaderEnter			 = cProfile.LeaderEnter
			profileTable.SearchRoomWaiting		 = cProfile.SearchRoomWaiting
			profileTable.SearchRoomPlaying		 = cProfile.SearchRoomPlaying
			profileTable.SearchChannelCurrent	 = cProfile.SearchChannelCurrent
			profileTable.SearchChannelVIP		 = cProfile.SearchChannelVIP
			profileTable.SearchGameTypeIndex	 = cProfile.SearchGameTypeIndex
			profileTable.SearchMapName			 = cProfile.SearchMapName
			profileTable.SearchPlayerNum		 = cProfile.SearchPlayerNum
			profileTable.SearchOptionAutoSave	 = cProfile.SearchOptionAutoSave
			profileTable.LeaderEnterAutoSave	 = cProfile.LeaderEnterAutoSave

			local str = "list = \n{\n"
			for k,v in pairs(profileTable) do
				local value = v
				if type(value) == "boolean" then
					value = value and "true" or "false"
				elseif type(value) == "string" then
					value = "\""..value.."\""
				end
				str = str.."\t"..k.." = "..value..",\n"
			end
			str = str.."}"
			config.ProfileStream = str

--			if testUpdate then
--				testProfileDesc = str
--			end
			print(str)
		else
			config.ProfileStream = ""
		end
	end
end

--testUpdate = true
--testProfileDesc = ""
