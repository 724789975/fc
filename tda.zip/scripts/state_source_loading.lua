-- function cache
local Vector3 = Vector3
local Vector2 = Vector2

-- current state
local state = ptr_cast(game.CurrentState)

-- loading progress
local progress_image = Gui.ProportionIcon("DefaultSkin/DefaultSkin_bar01_BG.dds", "DefaultSkin/DefaultSkin_bar01_content.dds", Vector4(16,0,16,0), Vector4(16,0,16,0))

-- login window
local ui = Gui.Create
{
	Gui.FlowLayout
	{
		Dock = "kDockFill",
		Align = "kAlignCenterBottom",

		Gui.Picture "background"
		{
			Style = "",
			BackgroundColor = ARGB(255,0,0,0),
			Dock = "kDockFill",
			ForeGroundImage = Gui.Image("LobbyUI/lb_bg_wallpaper03.dds"),
			--Expand = true,
			KeepAspect = true,	
			-- Gui.Picture "map"
			-- {
				-- Dock = "kDockFill",
				-- BackgroundColor = ARGB(255, 255, 255, 255),
				-- ForeGroundImage = Gui.Image("MapsAndBG/Loading/loadingmap_xunzhang.dds"),
				-- KeepAspect = true,
				-- Gui.Label
				-- {
					-- Dock = "kDockFill",
					-- FontSize = 26,
					-- Text = "战队名称：陈俊你妹\n战队领地等级：10\n战队资源战排名：10",
					-- TextColor = ARGB(255, 50, 50, 50),
					-- TextAlign = "kAlignLefTop",
					-- AutoWrap = true,
					-- BackgroundColor = ARGB(0, 255, 255, 255),
				-- },
			-- },
			Gui.Control "map_bg"
			{
				Size = Vector2(712, 557),
				Dock = "kDockCenter",
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/lb_shop_daoju_bg.tga", Vector4(22, 22, 22, 22)),
				},
			},
			
			-- Gui.Label "MAP_name_bg"
			-- {
				-- FontSize = 26,
				-- Text = "可掠夺资源：\n原油：5000点",
				-- TextColor = ARGB(255, 50, 50, 50),
				-- TextAlign = "kAlignCenterMiddle",
				-- AutoWrap = true,
				-- BackgroundColor = ARGB(0, 255, 255, 255),
			-- },
			
			-- Gui.Label "MAP_name"
			-- {
				-- FontSize = 26,
				-- Text = "可掠夺资源：\n原油：5000点",
				-- TextColor = ARGB(255, 250, 250, 250),
				-- TextAlign = "kAlignCenterMiddle",
				-- AutoWrap = true,
				-- BackgroundColor = ARGB(0, 255, 255, 255),
			-- },
			
			Gui.Control "bg"
			{
				Size = Vector2(288, 56),
				Location = Vector2(60, 300),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("DefaultSkin/DefaultSkin_bar01_BG.dds", Vector4(0, 0, 0, 0)),
				},
			},
			
			Gui.Control "content"
			{
				Size = Vector2(0, 0),
				Location = Vector2(60, 300),
				BackgroundColor = ARGB(255, 255, 255, 255),
			},
		},
	},
}

ui.background.EventSizeChanged = function()
	local Window_Aspect = ui.background.Size.x/ui.background.Size.y
	local Picture_Aspect = 1600/900
	if Picture_Aspect > Window_Aspect then
		-- ui.Hint.Location = Vector2(ui.background.Size.x*(92.0/1680),(ui.background.Size.x/Picture_Aspect)*(259.0/1052) +((ui.background.Size.y - ui.background.Size.x/Picture_Aspect)/2 + 0.5))
		-- ui.Hint.Size = Vector2(ui.background.Size.x*(347.0/1680),(ui.background.Size.x/Picture_Aspect)*(227.0/1052))
		-- ui.MAP_name.Location = Vector2(ui.background.Size.x*(565.0/1680),(ui.background.Size.x/Picture_Aspect)*(50.0/1052) +((ui.background.Size.y - ui.background.Size.x/Picture_Aspect)/2 + 0.5))
		-- ui.MAP_name.Size = Vector2(ui.background.Size.x*(558.0/1680),(ui.background.Size.x/Picture_Aspect)*(80.0/1052))
		ui.bg.Location = Vector2(ui.background.Size.x*(696.0/1680),(ui.background.Size.x/Picture_Aspect)*(677.0/1052) +((ui.background.Size.y - ui.background.Size.x/Picture_Aspect)/2 + 0.5))
		ui.bg.Size = Vector2(ui.background.Size.x*(288.0/1680),(ui.background.Size.x/Picture_Aspect)*(56.0/1052))
	elseif Picture_Aspect < Window_Aspect then
		-- ui.Hint.Location = Vector2(ui.background.Size.y*Picture_Aspect*(92.0/1680) + ((ui.background.Size.x - ui.background.Size.y*Picture_Aspect)/2 + 0.5),ui.background.Size.y*(259.0/1052))
		-- ui.Hint.Size = Vector2(ui.background.Size.y*Picture_Aspect*(347.0/1680),ui.background.Size.y*(227.0/1052))
		-- ui.MAP_name.Location = Vector2(ui.background.Size.y*Picture_Aspect*(565.0/1680) + ((ui.background.Size.x - ui.background.Size.y*Picture_Aspect)/2 + 0.5),ui.background.Size.y*(50.0/1052))
		-- ui.MAP_name.Size = Vector2(ui.background.Size.y*Picture_Aspect*(558.0/1680),ui.background.Size.y*(80.0/1052))
		ui.bg.Location = Vector2(ui.background.Size.y*Picture_Aspect*(696.0/1680) + ((ui.background.Size.x - ui.background.Size.y*Picture_Aspect)/2 + 0.5),ui.background.Size.y*(677.0/1052))
		ui.bg.Size = Vector2(ui.background.Size.y*Picture_Aspect*(288.0/1680),ui.background.Size.y*(56.0/1052))
	else
		-- ui.Hint.Location = Vector2(ui.background.Size.x*(92.0/1680),ui.background.Size.y*(259.0/1052))
		-- ui.Hint.Size = Vector2(ui.background.Size.x*(347.0/1680),ui.background.Size.y*(227.0/1052))
		-- ui.MAP_name.Location = Vector2(ui.background.Size.x*(565.0/1680),ui.background.Size.y*(50.0/1052))
		-- ui.MAP_name.Size = Vector2(ui.background.Size.x*(558.0/1680),ui.background.Size.y*(80.0/1052))
		ui.bg.Location = Vector2(ui.background.Size.x*(696.0/1680),ui.background.Size.y*(677.0/1052))
		ui.bg.Size = Vector2(ui.background.Size.x*(288.0/1680),ui.background.Size.y*(56.0/1052))
	end
	-- ui.MAP_name_bg.Location = Vector2(ui.MAP_name.Location.x + 2,ui.MAP_name.Location.y + 2)
	-- ui.MAP_name_bg.Size = ui.MAP_name.Size
	ui.content.Location = ui.bg.Location
	ui.content.Size = Vector2(ui.bg.Size.x*state.Progress,ui.bg.Size.y)
end

function state.EventLeave()
	Gui.Clear(ui)
	ui = nil
	state.EventLeave = nil
	state.EventProgressMove = nil
	state = nil
end

function state.EventProgressMove()
	ui.content.Size = Vector2(ui.bg.Size.x*state.Progress, ui.bg.Size.y)
	ui.content.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("DefaultSkin/DefaultSkin_bar01_content.dds", Vector4(0, 0, 0, 0),Vector4(0, 0, state.Progress, 1))}
end

function state.EventEnter()
	L_FightTeam.source_success_ui.map_bg.Parent = ui.map_bg
	
end
