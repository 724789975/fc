module("L_ShoppingMall", package.seeall)

root_ui = nil
flag = nil
index_tz = 1
main_character_window_ui = nil
main_props_window_ui = nil
avatart_main_ui = nil
packge_main_ui = nil
user_bag_ui = nil
user_bag_info_ui = nil
ib_weapon_ui = nil
ib_dress_ui = nil
ib_accessories_ui = nil
prop_window_ui = nil
buy_and_present_ui = nil
shoppingcar_window_ui = nil
tuozhuai_ui = nil
isFriend = false
isPartner = false
isZhandui = false
isChannel = false
myZhanduiIndex = -1
local selectedid = -1
--储存伙伴列表信息
list = nil

--放入购物车的物品数量
shoppingcar_window_count = 0

current_selected = 0
shoppingcart_string = ""

--当前选择的itemboxbtn的索引
current_selected_ibtn_index = -1
--当前道具栏目索引(4=道具、5=设计图、6=素材、7=大礼包)
current_selected_prop_index = 4
--当前选择的ibt类型 0购物车 1商城
current_selected_item_class = -1

--当前商城 选择角色ID
current_c_id = 1

--当前购买方式
current_goods_price_info = nil

--当前购物车结算方式
current_selected_price_way_cars = {1, 1, 1, 1, 1, 1, 1}

--当前购物车购买方式
current_selected_price_unit_cars = {1, 1, 1, 1, 1, 1, 1}

--选择的结算方式
current_selected_price_way = 2
price_way = {lang:GetText("FC点"), lang:GetText("C币"), lang:GetText("抵用券")}
price_unit = {lang:GetText("FC点"), lang:GetText("C币"), lang:GetText("抵用券")}
--结算方式
unittype_way = {lang:GetText("永久"), lang:GetText("个"), lang:GetText("天")}

--是否购买并装备
is_buy_and_equip = false

--当前选择的购买方式 1：3天 2：7天 3：三十天 4：永久
cost_mode = 1

--当前选择的好友index
current_select_firend_index = -1

--武器筛选类型
Fileter_Weapon_Type = {lang:GetText("全部"),lang:GetText("VIP(全部)"),lang:GetText("网吧(全部)"),lang:GetText("主武器"),lang:GetText("副武器"),lang:GetText("近身武器"),lang:GetText("特殊武器"),}

--服装筛选类型
Fileter_Dress_Type = {lang:GetText("全部"),lang:GetText("VIP(全部)"),lang:GetText("网吧(全部)"),}

--饰品筛选类型
Fileter_Accessories_Type = {lang:GetText("全部"),lang:GetText("VIP(全部)"),lang:GetText("网吧(全部)"),lang:GetText("帽子"),lang:GetText("饰品"),}

--道具筛选类型
Fileter_prop_Type = {lang:GetText("全部"),lang:GetText("VIP(全部)"),lang:GetText("网吧(全部)"),lang:GetText("加成类"),lang:GetText("名片"),lang:GetText("喷罐"),lang:GetText("功能类"),lang:GetText("消耗类")}

--素材筛选类型
Fileter_Material_Type = {lang:GetText("全部"),lang:GetText("VIP(全部)"),lang:GetText("网吧(全部)"),}

--蓝图筛选类型
Fileter_BluePrint_Type = {lang:GetText("全部"),lang:GetText("VIP(全部)"),lang:GetText("网吧(全部)"),}

--大礼包筛选类型
Fileter_BigGift_Type = {lang:GetText("全部"),lang:GetText("VIP(全部)"),lang:GetText("网吧(全部)"),}

--开奖箱筛选类型
Fileter_Box_Type = {lang:GetText("全部"),lang:GetText("VIP(全部)"),lang:GetText("网吧(全部)"),}

--武器筛选类型
Fileter_Weapon_Storage_Type = {lang:GetText("全部"),lang:GetText("主武器"),lang:GetText("副武器"),lang:GetText("近身武器"),lang:GetText("特殊武器"),}

--服装筛选类型
Fileter_Dress_Storage_Type = {lang:GetText("全部"),}

--饰品筛选类型
Fileter_Accessories_Storage_Type = {lang:GetText("全部"),lang:GetText("帽子"),lang:GetText("饰品"),}

--道具筛选类型
Fileter_prop_Storage_Type = {lang:GetText("全部"),lang:GetText("加成类"),lang:GetText("名片"),lang:GetText("喷罐"),lang:GetText("功能类"),lang:GetText("消耗类")}

--素材筛选类型
Fileter_Material_Storage_Type = {lang:GetText("全部"),}

--蓝图筛选类型
Fileter_BluePrint_Storage_Type = {lang:GetText("全部"),}

--大礼包筛选类型
Fileter_BigGift_Storage_Type = {lang:GetText("全部"),}

--开奖礼盒筛选类型
Fileter_Box_Storage_Type = {lang:GetText("全部"),}

--筛选货币类型
Fileter_Equip_MoneyType = 0
Fileter_Property_MoneyType = 0

--道具窗口创建控件
main_window_Creat = false

--取消购买并装备
--4改头换面 14创建战队 9扩充战队 16战队更名 13战队清零 12逃跑清零 11战绩清零 2和3大小喇叭 15VIP
--5战绩清零卡  28复活币  29密码卡 30钥匙 17 勋章和能量块 31靶场子弹 32偷看道具 38VIP能量块
operator_iid = {4, 9, 14, 16, 13, 12, 11, 2, 3, 15, 5, 28, 29, 30, 36, 17, 31, 32, 38}

tuozhuai = 
{
	--[[Gui.Control
	{
		Size = Vector2(176, 460),
		Location = Vector2(485, 330),
		BackgroundColor = ARGB(100, 255, 255, 255),
	},]]
	Gui.Control "root"
	{
		Visible = false,
		Location = Vector2(17, 0),
		Size = Vector2(1167, 900),
		BackgroundColor = ARGB(0, 255, 255, 255),
		Gui.Control "Image"
		{
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ibt_icon/ak47.tga", Vector4(0, 0, 0, 0)),
			},
			Gui.DragLabel "tttt"
			{
				Size = Vector2(168, 156),
				Location = Vector2(0, 0),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Iimit = Vector4(-10000,-10000,10000,10000),
			},
		},
		EventMouseRightUp = function(sender, e)
			local lobby_state = ptr_cast(game.CurrentState)
			local cursor_ScreenSize = lobby_state:GetScreenSize()
			local cursor_pos = lobby_state:GetCursorPos()
			local x = cursor_pos.x - ((cursor_ScreenSize.x - (cursor_ScreenSize.y / 3 * 4)) / 2)
			local y = cursor_pos.y 	
			if  x < 650 and x > 175 and y < 798 and y > 292 then
				FillCart(index_tz)
				current_selected_item_class = 0
				if L_LobbyMain.ShoppingMallIB_rpc_data.items[index_tz].common.type == 1 then
					if L_LobbyMain.ShoppingMallIB_rpc_data.items[index_tz].common.seq == 1 then
						current_selected_ibtn_index = 1
					elseif L_LobbyMain.ShoppingMallIB_rpc_data.items[index_tz].common.seq == 2 then
						current_selected_ibtn_index = 2
					elseif L_LobbyMain.ShoppingMallIB_rpc_data.items[index_tz].common.seq == 4 then
						current_selected_ibtn_index = 3
					else
						current_selected_ibtn_index = 4
					end
				elseif L_LobbyMain.ShoppingMallIB_rpc_data.items[index_tz].common.type == 2 then
					current_selected_ibtn_index = 5
				else
					if L_LobbyMain.ShoppingMallIB_rpc_data.items[index_tz].common.seq == 2 then
						current_selected_ibtn_index = 6
					else
						current_selected_ibtn_index = 7
					end
				end
				L_LobbyMain.ChangeAvatarPart()
			end
			Getshoppingcar_window_count()
			if shoppingcar_window_count > 0 then
				user_bag_ui.btn_buy_all.Enable = true
				user_bag_ui.btn_clear_all.Enable = true
			end
			reset()
		end,
	},
}

function reset()
	if ib_weapon_ui and index_tz < 9 then
		local ibbtn = ptr_cast(ib_weapon_ui.ctrl_ib_container:GetChildByIndex(index_tz-1))
		if ibbtn.ItemIcon then
			ibbtn.ItemIcon.alpha = 255
		end
	end
	if ib_dress_ui and index_tz < 9 then
		local ibbtn = ptr_cast(ib_dress_ui.ctrl_ib_container:GetChildByIndex(index_tz-1))
		if ibbtn.ItemIcon then
			ibbtn.ItemIcon.alpha = 255
		end
	end
	if ib_accessories_ui then
		local ibbtn = ptr_cast(ib_accessories_ui.ctrl_ib_container:GetChildByIndex(index_tz-1))
		if ibbtn.ItemIcon then
			ibbtn.ItemIcon.alpha = 255
		end
	end
	if tuozhuai_ui then
		tuozhuai_ui.root.Visible = false
	end
	for i = 1, 7 do
		local ibbtn = ptr_cast(user_bag_info_ui.ctrl_ib_container:GetChildByIndex(i-1))
		ibbtn.Highlight = false
	end
end

--购物车购买界面
local shoppingcar_window = 
{
	Gui.Control "root"
	{
		Size = Vector2(1200, 900),
		Location = Vector2(200, 0),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/lb_common_black_bg.dds",Vector4(0, 0, 0, 0)),
		},
		Gui.Control "ctrl_window_root"
		{
			Size = Vector2(520, 524),
			Location = Vector2(310, 220),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_bg1.dds", Vector4(28, 28, 28, 28)),
			},
						
			Gui.Button "buy_all_chongzhi"
			{
				Enable = true,
				Size = Vector2(150, 32),
				Location = Vector2(350, 12),
				Text = lang:GetText("充 值"),
				TextColor = ARGB(255, 37, 37, 37),
				HighlightTextColor = ARGB(255, 37, 37, 37),
				Padding = Vector4(0, 0, 0, 5),
				FontSize = 18,
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/lb_shop_button_charge_normal.dds", Vector4(12, 12, 12, 12)),
					HoverImage = Gui.Image("LobbyUI/lb_shop_button_charge_hover.dds", Vector4(12, 12, 12, 12)),
					DownImage = Gui.Image("LobbyUI/lb_shop_button_charge_down.dds", Vector4(12, 12, 12, 12)),
					DisabledImage = Gui.Image("LobbyUI/lb_shop_button_charge_normal.dds", Vector4(12, 12, 12, 12)),
				},
				EventClick = function()
					gui:ShowIE()
				end
			},
			
			Gui.Control "ctrl_window_main"
			{
				Size = Vector2(477, 462),
				Location = Vector2(21, 46),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_bg2.dds", Vector4(21, 25, 21, 46)),
				},
				
				Gui.Label "lbl_window_title"
				{
					Size = Vector2(471, 37),
					Location = Vector2(2, 4),
					Text = lang:GetText("结算清单"),
					TextColor = ARGB(255, 37, 37, 37),
					TextAlign = "kAlignCenterMiddle",
					FontSize = 20,
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tanchu_bg.dds", Vector4(7, 7, 7, 7)),
					},
				},
				
				Gui.ScrollableControl "scr_buy_all"
				{
					Size = Vector2(455, 275),
					Location = Vector2(15, 44),
					AutoScroll = true,
					AutoSize = true,
					BackgroundColor = ARGB(255, 255, 255, 255),
					VScrollBarDisplay = "kAuto",
					Default_Size = 0.1,
					Default_Width = 7,
					Skin = Gui.ScrollableControlSkin
					{
						UpButtonNormalImage = nil,
						UpButtonHoverImage = nil,
						UpButtonDownImage = nil,
						UpButtonDisabledImage = nil,
						
						DownButtonNormalImage = nil,
						DownButtonHoverImage = nil,
						DownButtonDownImage = nil,
						DownButtonDisabledImage = nil,

						VSliderNormalImage = Gui.Image("LobbyUI/lb_shop_scrollbar01_slidernormal.dds", Vector4(0, 4, 0, 4)),
						VSliderHoverImage = Gui.Image("LobbyUI/lb_shop_scrollbar01_sliderhover.dds", Vector4(0, 4, 0, 4)),
						VSliderDownImage = Gui.Image("LobbyUI/lb_shop_scrollbar01_sliderdown.dds", Vector4(0, 4, 0, 4)),
						VSliderDisabledImage = Gui.Image("LobbyUI/lb_shop_scrollbar01_slidernormal.dds", Vector4(0, 4, 0, 4)),

						VBarBackgroundImage = Gui.Image("LobbyUI/lb_shop_scrollbar01_bg.dds", Vector4(0, 4, 0, 4)),
						BarCornerImage = nil,
					},
								
					Gui.FlowLayout "buy_all"
					{
						AutoSize = true,
						Padding = Vector4(0, 0, 0, 0),
						Align = "kAlignCenterTop",
						ControlAlign = "kAlignMiddle",
						LineSpace = 5,
						BackgroundColor = color_white,
						
						Gui.Control "buy_all_1"
						{
							Size = Vector2(443, 135),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_box4_jiaoyi.dds", Vector4(20, 20, 20, 20)),
							},
							
							Gui.Button "buy_all_chongzhi"
							{
								--Enable = false,
								Size = Vector2(55, 24),
								Location = Vector2(381, 14),
								Text = lang:GetText("移除"),
								TextColor = ARGB(255, 242, 242, 242),
								HighlightTextColor = ARGB(255, 37, 37, 37),
								FontSize = 14,
								Skin = Gui.ButtonSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_button6_normal.dds", Vector4(12, 12, 12, 12)),
									HoverImage = Gui.Image("LobbyUI/team/lb_squad_button6_hover.dds", Vector4(12, 12, 12, 12)),
									DownImage = Gui.Image("LobbyUI/team/lb_squad_button6_down.dds", Vector4(12, 12, 12, 12)),
									DisabledImage = Gui.Image("LobbyUI/team/lb_squad_button6_normal.dds", Vector4(12, 12, 12, 12)),
								},
								EventClick = function()
									L_LobbyMain.RemoveShoppingCart(1)
									L_LobbyMain.FillShoppingCart()
									Fillshoppingcar_window()
									Getshoppingcar_window_count()
									if shoppingcar_window_count == 0 then
										user_bag_ui.btn_buy_all.Enable = false
										user_bag_ui.btn_clear_all.Enable = false
										CloseShoppingCarBuyWin()
									end
								end
							},
							
							--物品图片
							Gui.Control "image_buy_all"
							{
								Size = Vector2(101, 83),
								Location = Vector2(12, 5),
								BackgroundColor = ARGB(255, 255, 255, 255),
								Skin = Gui.ControlSkin
								{
									BackgroundImage = Gui.Image("weapon/hk45_02.dds", Vector4(0, 0, 0, 0)),
								},
							},

							--物品名称
							Gui.Label "all_goods_name_buy"
							{
								Size = Vector2(250, 22),
								Text = lang:GetText("物品名称"),
								Font = "simhei",								
								Location = Vector2(136, 15),
								FontSize = 18,
								TextColor = ARGB(255, 37, 37, 37),
							},
							
							Gui.Control "ctrl_balance_mode_bg"
							{
								Size = Vector2(320, 38),
								Location = Vector2(119, 60),
								BackgroundColor = ARGB(255, 255, 255, 255),
								Skin = Gui.ControlSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_line4.dds", Vector4(10, 10, 10, 10)),
								},
								
								--结算方式
								Gui.Label "lbl_balance_mode"
								{
									Size = Vector2(78, 24),
									Text = lang:GetText("结算方式"),
									Font = "simhei",									
									Location = Vector2(108, 6),
									FontSize = 18,
									TextColor = ARGB(255, 37, 37, 37),
									--BackgroundColor = ARGB(255, 0, 0, 255),
								},
								
								--上一种结算方式
								Gui.Button "buy_all_front_page"
								{
									Size = Vector2(20, 20),
									Location = Vector2(203, 8),
									--Text = "<",
									TextColor = ARGB(255, 191, 189, 184),
									FontSize = 16,
									Skin = Gui.ButtonSkin
									{
										BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button08_normal.dds", Vector4(0, 0, 0, 0)),
										HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button08_hover.dds", Vector4(0, 0, 0, 0)),
										DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button08_down.dds", Vector4(0, 0, 0, 0)),
										DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button08_normal.dds", Vector4(0, 0, 0, 0)),
									},
									EventClick = function()
										current_selected_price_way_cars[1] = current_selected_price_way_cars[1] - 1
										if current_selected_price_way_cars[1] == 0 then
											current_selected_price_way_cars[1] = 3
										end
										
										if current_selected_price_way_cars[1] == 3 then
											if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][1].voucherprices ~= nil and L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][1].voucherprices[1] ~= nil then
												Fillshoppingcar_window()
											else
												current_selected_price_way_cars[1] = current_selected_price_way_cars[1] - 1
												if current_selected_price_way_cars[1] == 2 then
													if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][1].crprices ~= nil and L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][1].crprices[1] ~= nil then
														Fillshoppingcar_window()
													else
														current_selected_price_way_cars[1] = current_selected_price_way_cars[1] - 1
														Fillshoppingcar_window()
													end
												end
											end
										elseif current_selected_price_way_cars[1] == 2 then
											if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][1].crprices ~= nil and L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][1].crprices[1] ~= nil then
												Fillshoppingcar_window()
											else
												current_selected_price_way_cars[1] = current_selected_price_way_cars[1] - 1
												if current_selected_price_way_cars[1] == 1 then
													if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][1].gpprices ~= nil and L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][1].gpprices[1] ~= nil then
														Fillshoppingcar_window()
													else
														current_selected_price_way_cars[1] = 3
														Fillshoppingcar_window()
													end
												end
											end
										else
											if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][1].gpprices ~= nil and L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][1].gpprices[1] ~= nil then
												Fillshoppingcar_window()
											else
												current_selected_price_way_cars[1] = 3
												if current_selected_price_way_cars[1] == 3 then
													if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][1].voucherprices ~= nil and L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][1].voucherprices[1] ~= nil then
														Fillshoppingcar_window()
													else
														current_selected_price_way_cars[1] = 2	
														Fillshoppingcar_window()
													end
												end
											end
										end
									end
								},
								
								Gui.Label "buy_all_mode"
								{
									Location = Vector2(230, 9),
									Size = Vector2(80, 20),
									Font = "simhei",
									TextAlign = "kAlignCenterMiddle",
									FontSize = 16,
									TextColor = ARGB(255, 37, 37, 37),
									Text = lang:GetText("C币"),
								},
								
								Gui.Button "buy_all_next_page"
								{
									Size = Vector2(20, 20),
									Location = Vector2(292, 8),
									TextColor = ARGB(255, 191, 189, 184),
									FontSize = 16,
									Skin = Gui.ButtonSkin
									{
										BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button09_normal.dds", Vector4(0, 0, 0, 0)),
										HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button09_hover.dds", Vector4(0, 0, 0, 0)),
										DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button09_down.dds", Vector4(0, 0, 0, 0)),
										DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button09_normal.dds", Vector4(0, 0, 0, 0)),
									},
									EventClick = function()
										current_selected_price_way_cars[1] = current_selected_price_way_cars[1] + 1
										if current_selected_price_way_cars[1] == 4 then
											current_selected_price_way_cars[1] = 1
										end
										if current_selected_price_way_cars[1] == 1 then
											if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][1].gpprices ~= nil and L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][1].gpprices[1] ~= nil then
												Fillshoppingcar_window()
											else
												current_selected_price_way_cars[1] = current_selected_price_way_cars[1] + 1
												if current_selected_price_way_cars[1] == 2 then
													if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][1].crprices ~= nil and L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][1].crprices[1] ~= nil then
														Fillshoppingcar_window()
													else
														current_selected_price_way_cars[1] = current_selected_price_way_cars[1] + 1
														Fillshoppingcar_window()
													end
												end
											end
										elseif current_selected_price_way_cars[1] == 2 then
											if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][1].crprices ~= nil and L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][1].crprices[1] ~= nil then
												Fillshoppingcar_window()
											else
												current_selected_price_way_cars[1] = current_selected_price_way_cars[1] + 1
												if current_selected_price_way_cars[1] == 3 then
													if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][1].voucherprices ~= nil and L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][1].voucherprices[1] ~= nil then
														Fillshoppingcar_window()
													else
														current_selected_price_way_cars[1] = 1
														Fillshoppingcar_window()
													end
												end
											end
										else 
											if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][1].voucherprices ~= nil and L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][1].voucherprices[1] ~= nil then
												Fillshoppingcar_window()
											else
												current_selected_price_way_cars[1] = 1
												if current_selected_price_way_cars[1] == 1 then
													if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][1].gpprices ~= nil and L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][1].gpprices[1] ~= nil then
														Fillshoppingcar_window()
													else
														current_selected_price_way_cars[1] = 2	
														Fillshoppingcar_window()
													end
												end
											end
										end
									end
								},
															
							},

							--三天
							Gui.Button "btn_three_days_buy1"
							{
								Size = Vector2(103, 26),
								Location = Vector2(9, 104),
								Text = lang:GetText("50/3天"),
								TextColor = ARGB(255, 242, 242, 242),
								HighlightTextColor = ARGB(255, 37, 37, 37),
								Font = "simhei",
								FontSize = 14,
								BackgroundColor = ARGB(255, 255, 255, 255),
								PushDown = true,
								Skin = Gui.ButtonSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_normal.dds", Vector4(10, 10, 10, 10)),
									HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_hover.dds", Vector4(10, 10, 10, 10)),
									DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_down.dds", Vector4(10, 10, 10, 10)),
									DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_normal.dds", Vector4(10, 10, 10, 10)),
								},
								EventClick = function()
									if  shoppingcar_window_ui then
										shoppingcar_window_ui.btn_three_days_buy1.PushDown = true
										shoppingcar_window_ui.btn_senven_days_buy1.PushDown = false
										shoppingcar_window_ui.btn_thirty_days_buy1.PushDown = false
										shoppingcar_window_ui.btn_forever_buy1.PushDown = false
										current_selected_price_unit_cars[1] = 1
									end		
									Fillshoppingcar_window()
								end
							},

							--七天
							Gui.Button "btn_senven_days_buy1"
							{
								Size = Vector2(103, 26),
								Location = Vector2(117, 104),
								Text = lang:GetText("100/7天"),
								TextColor = ARGB(255, 242, 242, 242),
								HighlightTextColor = ARGB(255, 37, 37, 37),
								Font = "simhei",
								FontSize = 14,
								BackgroundColor = ARGB(255, 255, 255, 255),
								Skin = Gui.ButtonSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_normal.dds", Vector4(10, 10, 10, 10)),
									HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_hover.dds", Vector4(10, 10, 10, 10)),
									DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_down.dds", Vector4(10, 10, 10, 10)),
									DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_normal.dds", Vector4(10, 10, 10, 10)),
								},
								EventClick = function()
									if shoppingcar_window_ui then
										shoppingcar_window_ui.btn_three_days_buy1.PushDown = false
										shoppingcar_window_ui.btn_senven_days_buy1.PushDown = true
										shoppingcar_window_ui.btn_thirty_days_buy1.PushDown = false
										shoppingcar_window_ui.btn_forever_buy1.PushDown = false
										current_selected_price_unit_cars[1] = 2
									end
									Fillshoppingcar_window()
								end,
							},
							--三十天
							Gui.Button "btn_thirty_days_buy1"
							{
								Size = Vector2(103, 26),
								Location = Vector2(225, 104),
								Text = lang:GetText("500/30天"),
								TextColor = ARGB(255, 242, 242, 242),
								HighlightTextColor = ARGB(255, 37, 37, 37),
								Font = "simhei",
								FontSize = 14,
								BackgroundColor = ARGB(255, 255, 255, 255),
								Skin = Gui.ButtonSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_normal.dds", Vector4(10, 10, 10, 10)),
									HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_hover.dds", Vector4(10, 10, 10, 10)),
									DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_down.dds", Vector4(10, 10, 10, 10)),
									DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_normal.dds", Vector4(10, 10, 10, 10)),
								},
								EventClick = function()
									if shoppingcar_window_ui then
										current_selected_price_unit_cars[1] = 3
										shoppingcar_window_ui.btn_three_days_buy1.PushDown = false
										shoppingcar_window_ui.btn_senven_days_buy1.PushDown = false
										shoppingcar_window_ui.btn_thirty_days_buy1.PushDown = true
										shoppingcar_window_ui.btn_forever_buy1.PushDown = false
									end	
									Fillshoppingcar_window()
								end,
							},

							--永久
							Gui.Button "btn_forever_buy1"
							{
								Size = Vector2(103, 26),
								Location = Vector2(333, 104),
								Text = lang:GetText("1000/永久"),
								TextColor = ARGB(255, 242, 242, 242),
								HighlightTextColor = ARGB(255, 37, 37, 37),
								Font = "simhei",
								FontSize = 14,
								BackgroundColor = ARGB(255, 255, 255, 255),
								Skin = Gui.ButtonSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_normal.dds", Vector4(10, 10, 10, 10)),
									HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_hover.dds", Vector4(10, 10, 10, 10)),
									DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_down.dds", Vector4(10, 10, 10, 10)),
									DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_normal.dds", Vector4(10, 10, 10, 10)),
								},
								EventClick = function()
									if shoppingcar_window_ui then
										current_selected_price_unit_cars[1] = 4
										shoppingcar_window_ui.btn_three_days_buy1.PushDown = false
										shoppingcar_window_ui.btn_senven_days_buy1.PushDown = false
										shoppingcar_window_ui.btn_thirty_days_buy1.PushDown = false
										shoppingcar_window_ui.btn_forever_buy1.PushDown = true
									end
									Fillshoppingcar_window()
								end,
							},
						},
						
						Gui.Control "buy_all_2"
						{
							Size = Vector2(443, 135),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_box4_jiaoyi.dds", Vector4(20, 20, 20, 20)),
							},
							
							Gui.Button "buy_all_chongzhi"
							{
								--Enable = false,
								Size = Vector2(55, 24),
								Location = Vector2(381, 14),
								Text = lang:GetText("移除"),
								TextColor = ARGB(255, 242, 242, 242),
								HighlightTextColor = ARGB(255, 37, 37, 37),
								FontSize = 14,
								Skin = Gui.ButtonSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_button6_normal.dds", Vector4(12, 12, 12, 12)),
									HoverImage = Gui.Image("LobbyUI/team/lb_squad_button6_hover.dds", Vector4(12, 12, 12, 12)),
									DownImage = Gui.Image("LobbyUI/team/lb_squad_button6_down.dds", Vector4(12, 12, 12, 12)),
									DisabledImage = Gui.Image("LobbyUI/team/lb_squad_button6_normal.dds", Vector4(12, 12, 12, 12)),
								},
								EventClick = function()
									L_LobbyMain.RemoveShoppingCart(2)
									L_LobbyMain.FillShoppingCart()
									Fillshoppingcar_window()
									Getshoppingcar_window_count()
									if shoppingcar_window_count == 0 then
										user_bag_ui.btn_buy_all.Enable = false
										user_bag_ui.btn_clear_all.Enable = false
										CloseShoppingCarBuyWin()
									end
								end
							},
							
							--物品图片
							Gui.Control "image_buy_all"
							{
								Size = Vector2(101, 83),
								Location = Vector2(12, 5),
								BackgroundColor = ARGB(255, 255, 255, 255),
								Skin = Gui.ControlSkin
								{
									BackgroundImage = Gui.Image("weapon/hk45_02.dds", Vector4(0, 0, 0, 0)),
								},
							},

							--物品名称
							Gui.Label "all_goods_name_buy"
							{
								Size = Vector2(250, 22),
								Text = lang:GetText("物品名称"),
								Font = "simhei",
								Location = Vector2(136, 15),
								FontSize = 18,
								TextColor = ARGB(255, 37, 37, 37),
							},
							
							Gui.Control "ctrl_balance_mode_bg"
							{
								Size = Vector2(320, 38),
								Location = Vector2(119, 60),
								BackgroundColor = ARGB(255, 255, 255, 255),
								Skin = Gui.ControlSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_line4.dds", Vector4(10, 10, 10, 10)),
								},
								
								--结算方式
								Gui.Label "lbl_balance_mode"
								{
									Size = Vector2(78, 24),
									Text = lang:GetText("结算方式"),
									Font = "simhei",
									Location = Vector2(108, 6),
									FontSize = 18,
									TextColor = ARGB(255, 37, 37, 37),
								},
								
								--上一种结算方式
								Gui.Button "buy_all_front_page"
								{
									Size = Vector2(20, 20),
									Location = Vector2(203, 8),
									--Text = "<",
									TextColor = ARGB(255, 191, 189, 184),
									FontSize = 16,
									Skin = Gui.ButtonSkin
									{
										BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button08_normal.dds", Vector4(0, 0, 0, 0)),
										HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button08_hover.dds", Vector4(0, 0, 0, 0)),
										DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button08_down.dds", Vector4(0, 0, 0, 0)),
										DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button08_normal.dds", Vector4(0, 0, 0, 0)),
									},
									EventClick = function()
										current_selected_price_way_cars[2] = current_selected_price_way_cars[2] - 1
										if current_selected_price_way_cars[2] == 0 then
											current_selected_price_way_cars[2] = 3
										end
										
										if current_selected_price_way_cars[2] == 3 then
											if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][2].voucherprices ~= nil and L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][2].voucherprices[1] ~= nil then
												Fillshoppingcar_window()
											else
												current_selected_price_way_cars[2] = current_selected_price_way_cars[2] - 1
												if current_selected_price_way_cars[2] == 2 then
													if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][1].crprices ~= nil and L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][2].crprices[1] ~= nil then
														Fillshoppingcar_window()
													else
														current_selected_price_way_cars[2] = current_selected_price_way_cars[2] - 1
														Fillshoppingcar_window()
													end
												end
											end
										elseif current_selected_price_way_cars[2] == 2 then
											if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][2].crprices ~= nil and L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][2].crprices[1] ~= nil then
												Fillshoppingcar_window()
											else
												current_selected_price_way_cars[2] = current_selected_price_way_cars[2] - 1
												if current_selected_price_way_cars[2] == 1 then
													if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][2].gpprices ~= nil and L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][2].gpprices[1] ~= nil then
														Fillshoppingcar_window()
													else
														current_selected_price_way_cars[2] = 3
														Fillshoppingcar_window()
													end
												end
											end
										else
											if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][2].gpprices ~= nil and L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][2].gpprices[1] ~= nil then
												Fillshoppingcar_window()
											else
												current_selected_price_way_cars[2] = 3
												if current_selected_price_way_cars[2] == 3 then
													if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][2].voucherprices ~= nil and L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][2].voucherprices[1] ~= nil then
														Fillshoppingcar_window()
													else
														current_selected_price_way_cars[2] = 2	
														Fillshoppingcar_window()
													end
												end
											end
										end
									end
								},
								
								Gui.Label "buy_all_mode"
								{
									Location = Vector2(230, 9),
									Size = Vector2(80, 20),
									Font = "simhei",
									TextAlign = "kAlignCenterMiddle",
									FontSize = 16,
									TextColor = ARGB(255, 37, 37, 37),
									Text = lang:GetText("C币"),
								},
								
								Gui.Button "buy_all_next_page"
								{
									Size = Vector2(20, 20),
									Location = Vector2(292, 8),
									TextColor = ARGB(255, 191, 189, 184),
									FontSize = 16,
									Skin = Gui.ButtonSkin
									{
										BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button09_normal.dds", Vector4(0, 0, 0, 0)),
										HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button09_hover.dds", Vector4(0, 0, 0, 0)),
										DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button09_down.dds", Vector4(0, 0, 0, 0)),
										DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button09_normal.dds", Vector4(0, 0, 0, 0)),
									},
									EventClick = function()
										current_selected_price_way_cars[2] = current_selected_price_way_cars[2] + 1
										if current_selected_price_way_cars[2] == 4 then
											current_selected_price_way_cars[2] = 1
										end
										if current_selected_price_way_cars[2] == 1 then
											if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][2].gpprices ~= nil and L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][2].gpprices[1] ~= nil then
												Fillshoppingcar_window()
											else
												current_selected_price_way_cars[2] = current_selected_price_way_cars[2] + 1
												if current_selected_price_way_cars[2] == 2 then
													if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][2].crprices ~= nil and L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][2].crprices[1] ~= nil then
														Fillshoppingcar_window()
													else
														current_selected_price_way_cars[2] = current_selected_price_way_cars[2] + 1
														Fillshoppingcar_window()
													end
												end
											end
										elseif current_selected_price_way_cars[2] == 2 then
											if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][2].crprices ~= nil and L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][2].crprices[1] ~= nil then
												Fillshoppingcar_window()
											else
												current_selected_price_way_cars[2] = current_selected_price_way_cars[2] + 1
												if current_selected_price_way_cars[2] == 3 then
													if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][2].voucherprices ~= nil and L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][2].voucherprices[1] ~= nil then
														Fillshoppingcar_window()
													else
														current_selected_price_way_cars[2] = 1
														Fillshoppingcar_window()
													end
												end
											end
										else 
											if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][2].voucherprices ~= nil and L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][2].voucherprices[1] ~= nil then
												Fillshoppingcar_window()
											else
												current_selected_price_way_cars[2] = 1
												if current_selected_price_way_cars[2] == 1 then
													if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][2].gpprices ~= nil and L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][2].gpprices[1] ~= nil then
														Fillshoppingcar_window()
													else
														current_selected_price_way_cars[2] = 2	
														Fillshoppingcar_window()
													end
												end
											end
										end
									end
								},
							},
							
							--三天
							Gui.Button "btn_three_days_buy2"
							{
								Size = Vector2(103, 26),
								Location = Vector2(9, 104),
								Text = lang:GetText("50/3天"),
								TextColor = ARGB(255, 242, 242, 242),
								HighlightTextColor = ARGB(255, 37, 37, 37),
								Font = "simhei",
								FontSize = 14,
								BackgroundColor = ARGB(255, 255, 255, 255),
								PushDown = true,
								Skin = Gui.ButtonSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_normal.dds", Vector4(10, 10, 10, 10)),
									HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_hover.dds", Vector4(10, 10, 10, 10)),
									DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_down.dds", Vector4(10, 10, 10, 10)),
									DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_normal.dds", Vector4(10, 10, 10, 10)),
								},
								EventClick = function()
									if  shoppingcar_window_ui then
										shoppingcar_window_ui.btn_three_days_buy2.PushDown = true
										shoppingcar_window_ui.btn_senven_days_buy2.PushDown = false
										shoppingcar_window_ui.btn_thirty_days_buy2.PushDown = false
										shoppingcar_window_ui.btn_forever_buy2.PushDown = false
										current_selected_price_unit_cars[2] = 1
									end			
									Fillshoppingcar_window()
								end
							},

							--七天
							Gui.Button "btn_senven_days_buy2"
							{
								Size = Vector2(103, 26),
								Location = Vector2(117, 104),
								Text = lang:GetText("100/7天"),
								TextColor = ARGB(255, 242, 242, 242),
								HighlightTextColor = ARGB(255, 37, 37, 37),
								Font = "simhei",
								FontSize = 14,
								BackgroundColor = ARGB(255, 255, 255, 255),
								Skin = Gui.ButtonSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_normal.dds", Vector4(10, 10, 10, 10)),
									HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_hover.dds", Vector4(10, 10, 10, 10)),
									DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_down.dds", Vector4(10, 10, 10, 10)),
									DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_normal.dds", Vector4(10, 10, 10, 10)),
								},
								EventClick = function()
									if shoppingcar_window_ui then
										shoppingcar_window_ui.btn_three_days_buy2.PushDown = false
										shoppingcar_window_ui.btn_senven_days_buy2.PushDown = true
										shoppingcar_window_ui.btn_thirty_days_buy2.PushDown = false
										shoppingcar_window_ui.btn_forever_buy2.PushDown = false
										current_selected_price_unit_cars[2] = 2
									end
									Fillshoppingcar_window()
								end,
							},
							
							--三十天
							Gui.Button "btn_thirty_days_buy2"
							{
								Size = Vector2(103, 26),
								Location = Vector2(225, 104),
								Text = lang:GetText("500/30天"),
								TextColor = ARGB(255, 242, 242, 242),
								HighlightTextColor = ARGB(255, 37, 37, 37),
								Font = "simhei",
								FontSize = 14,
								BackgroundColor = ARGB(255, 255, 255, 255),
								Skin = Gui.ButtonSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_normal.dds", Vector4(10, 10, 10, 10)),
									HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_hover.dds", Vector4(10, 10, 10, 10)),
									DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_down.dds", Vector4(10, 10, 10, 10)),
									DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_normal.dds", Vector4(10, 10, 10, 10)),
								},
								EventClick = function()
									if shoppingcar_window_ui then
										current_selected_price_unit_cars[2] = 3
										shoppingcar_window_ui.btn_three_days_buy2.PushDown = false
										shoppingcar_window_ui.btn_senven_days_buy2.PushDown = false
										shoppingcar_window_ui.btn_thirty_days_buy2.PushDown = true
										shoppingcar_window_ui.btn_forever_buy2.PushDown = false
									end	
									Fillshoppingcar_window()
								end,
							},

							--永久
							Gui.Button "btn_forever_buy2"
							{
								Size = Vector2(103, 26),
								Location = Vector2(333, 104),
								Text = lang:GetText("1000/永久"),
								TextColor = ARGB(255, 242, 242, 242),
								HighlightTextColor = ARGB(255, 37, 37, 37),
								Font = "simhei",
								FontSize = 14,
								BackgroundColor = ARGB(255, 255, 255, 255),
								Skin = Gui.ButtonSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_normal.dds", Vector4(10, 10, 10, 10)),
									HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_hover.dds", Vector4(10, 10, 10, 10)),
									DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_down.dds", Vector4(10, 10, 10, 10)),
									DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_normal.dds", Vector4(10, 10, 10, 10)),
								},
								EventClick = function()
									if shoppingcar_window_ui then
										current_selected_price_unit_cars[2] = 4
										shoppingcar_window_ui.btn_three_days_buy2.PushDown = false
										shoppingcar_window_ui.btn_senven_days_buy2.PushDown = false
										shoppingcar_window_ui.btn_thirty_days_buy2.PushDown = false
										shoppingcar_window_ui.btn_forever_buy2.PushDown = true
									end
									Fillshoppingcar_window()
								end,
							},
						},
						
						Gui.Control "buy_all_3"
						{
							Size = Vector2(443, 135),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_box4_jiaoyi.dds", Vector4(20, 20, 20, 20)),
							},
							
							Gui.Button "buy_all_chongzhi"
							{
								--Enable = false,
								Size = Vector2(55, 24),
								Location = Vector2(381, 14),
								Text = lang:GetText("移除"),
								TextColor = ARGB(255, 242, 242, 242),
								HighlightTextColor = ARGB(255, 37, 37, 37),
								FontSize = 14,
								Skin = Gui.ButtonSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_button6_normal.dds", Vector4(12, 12, 12, 12)),
									HoverImage = Gui.Image("LobbyUI/team/lb_squad_button6_hover.dds", Vector4(12, 12, 12, 12)),
									DownImage = Gui.Image("LobbyUI/team/lb_squad_button6_down.dds", Vector4(12, 12, 12, 12)),
									DisabledImage = Gui.Image("LobbyUI/team/lb_squad_button6_normal.dds", Vector4(12, 12, 12, 12)),
								},
								EventClick = function()
									L_LobbyMain.RemoveShoppingCart(3)
									L_LobbyMain.FillShoppingCart()
									Fillshoppingcar_window()
									Getshoppingcar_window_count()
									if shoppingcar_window_count == 0 then
										user_bag_ui.btn_buy_all.Enable = false
										user_bag_ui.btn_clear_all.Enable = false
										CloseShoppingCarBuyWin()
									end
								end
							},
							
							--物品图片
							Gui.Control "image_buy_all"
							{
								Size = Vector2(101, 83),
								Location = Vector2(12, 5),
								BackgroundColor = ARGB(255, 255, 255, 255),
								Skin = Gui.ControlSkin
								{
									BackgroundImage = Gui.Image("weapon/hk45_02.dds", Vector4(0, 0, 0, 0)),
								},
							},

							--物品名称
							Gui.Label "all_goods_name_buy"
							{
								Size = Vector2(250, 22),
								Text = lang:GetText("物品名称"),
								Font = "simhei",
								Location = Vector2(136, 15),
								FontSize = 18,
								TextColor = ARGB(255, 37, 37, 37),
							},
							
							Gui.Control "ctrl_balance_mode_bg"
							{
								Size = Vector2(320, 38),
								Location = Vector2(119, 60),
								BackgroundColor = ARGB(255, 255, 255, 255),
								Skin = Gui.ControlSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_line4.dds", Vector4(10, 10, 10, 10)),
								},
								
								--结算方式
								Gui.Label "lbl_balance_mode"
								{
									Size = Vector2(78, 24),
									Text = lang:GetText("结算方式"),
									Font = "simhei",
									Location = Vector2(108, 6),
									FontSize = 18,
									TextColor = ARGB(255, 37, 37, 37),
								},
								
								--上一种结算方式
								Gui.Button "buy_all_front_page"
								{
									Size = Vector2(20, 20),
									Location = Vector2(203, 8),
									--Text = "<",
									TextColor = ARGB(255, 191, 189, 184),
									FontSize = 16,
									Skin = Gui.ButtonSkin
									{
										BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button08_normal.dds", Vector4(0, 0, 0, 0)),
										HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button08_hover.dds", Vector4(0, 0, 0, 0)),
										DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button08_down.dds", Vector4(0, 0, 0, 0)),
										DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button08_normal.dds", Vector4(0, 0, 0, 0)),
									},
									EventClick = function()
										current_selected_price_way_cars[3] = current_selected_price_way_cars[3] - 1
										if current_selected_price_way_cars[3] == 0 then
											current_selected_price_way_cars[3] = 3
										end
										
										if current_selected_price_way_cars[3] == 3 then
											if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][3].voucherprices ~= nil and L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][3].voucherprices[1] ~= nil then
												Fillshoppingcar_window()
											else
												current_selected_price_way_cars[3] = current_selected_price_way_cars[3] - 1
												if current_selected_price_way_cars[3] == 2 then
													if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][3].crprices ~= nil and L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][3].crprices[1] ~= nil then
														Fillshoppingcar_window()
													else
														current_selected_price_way_cars[3] = current_selected_price_way_cars[3] - 1
														Fillshoppingcar_window()
													end
												end
											end
										elseif current_selected_price_way_cars[3] == 2 then
											if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][3].crprices ~= nil and L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][3].crprices[1] ~= nil then
												Fillshoppingcar_window()
											else
												current_selected_price_way_cars[3] = current_selected_price_way_cars[3] - 1
												if current_selected_price_way_cars[3] == 1 then
													if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][3].gpprices ~= nil and L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][3].gpprices[1] ~= nil then
														Fillshoppingcar_window()
													else
														current_selected_price_way_cars[3] = 3
														Fillshoppingcar_window()
													end
												end
											end
										else
											if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][3].gpprices ~= nil and L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][3].gpprices[1] ~= nil then
												Fillshoppingcar_window()
											else
												current_selected_price_way_cars[3] = 3
												if current_selected_price_way_cars[3] == 3 then
													if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][3].voucherprices ~= nil and L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][3].voucherprices[1] ~= nil then
														Fillshoppingcar_window()
													else
														current_selected_price_way_cars[3] = 2	
														Fillshoppingcar_window()
													end
												end
											end
										end
									end
								},
								
								Gui.Label "buy_all_mode"
								{
									Location = Vector2(230, 9),
									Size = Vector2(80, 20),
									Font = "simhei",
									TextAlign = "kAlignCenterMiddle",
									FontSize = 16,
									TextColor = ARGB(255, 37, 37, 37),
									Text = lang:GetText("C币"),
								},
								
								Gui.Button "buy_all_next_page"
								{
									Size = Vector2(20, 20),
									Location = Vector2(292, 8),
									TextColor = ARGB(255, 191, 189, 184),
									FontSize = 16,
									Skin = Gui.ButtonSkin
									{
										BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button09_normal.dds", Vector4(0, 0, 0, 0)),
										HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button09_hover.dds", Vector4(0, 0, 0, 0)),
										DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button09_down.dds", Vector4(0, 0, 0, 0)),
										DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button09_normal.dds", Vector4(0, 0, 0, 0)),
									},
									EventClick = function()
										
										current_selected_price_way_cars[3] = current_selected_price_way_cars[3] + 1
										if current_selected_price_way_cars[3] == 4 then
											current_selected_price_way_cars[3] = 1
										end
										if current_selected_price_way_cars[3] == 1 then
											if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][3].gpprices ~= nil and L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][3].gpprices[1] ~= nil then
												Fillshoppingcar_window()
											else
												current_selected_price_way_cars[3] = current_selected_price_way_cars[3] + 1
												if current_selected_price_way_cars[3] == 2 then
													if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][3].crprices ~= nil and L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][3].crprices[1] ~= nil then
														Fillshoppingcar_window()
													else
														current_selected_price_way_cars[3] = current_selected_price_way_cars[3] + 1
														Fillshoppingcar_window()
													end
												end
											end
										elseif current_selected_price_way_cars[3] == 2 then
											if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][3].crprices ~= nil and L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][3].crprices[1] ~= nil then
												Fillshoppingcar_window()
											else
												current_selected_price_way_cars[3] = current_selected_price_way_cars[3] + 1
												if current_selected_price_way_cars[3] == 3 then
													if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][3].voucherprices ~= nil and L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][3].voucherprices[1] ~= nil then
														Fillshoppingcar_window()
													else
														current_selected_price_way_cars[3] = 1
														Fillshoppingcar_window()
													end
												end
											end
										else 
											if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][3].voucherprices ~= nil and L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][3].voucherprices[1] ~= nil then
												Fillshoppingcar_window()
											else
												current_selected_price_way_cars[3] = 1
												if current_selected_price_way_cars[3] == 1 then
													if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][3].gpprices ~= nil and L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][3].gpprices[1] ~= nil then
														Fillshoppingcar_window()
													else
														current_selected_price_way_cars[3] = 2	
														Fillshoppingcar_window()
													end
												end
											end
										end
									end
								},
							},

							--三天
							Gui.Button "btn_three_days_buy3"
							{
								Size = Vector2(103, 26),
								Location = Vector2(9, 104),
								Text = lang:GetText("50/3天"),
								TextColor = ARGB(255, 242, 242, 242),
								HighlightTextColor = ARGB(255, 37, 37, 37),
								Font = "simhei",
								FontSize = 14,
								BackgroundColor = ARGB(255, 255, 255, 255),
								PushDown = true,
								Skin = Gui.ButtonSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_normal.dds", Vector4(10, 10, 10, 10)),
									HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_hover.dds", Vector4(10, 10, 10, 10)),
									DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_down.dds", Vector4(10, 10, 10, 10)),
									DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_normal.dds", Vector4(10, 10, 10, 10)),
								},
								EventClick = function()
									if  shoppingcar_window_ui then
										shoppingcar_window_ui.btn_three_days_buy3.PushDown = true
										shoppingcar_window_ui.btn_senven_days_buy3.PushDown = false
										shoppingcar_window_ui.btn_thirty_days_buy3.PushDown = false
										shoppingcar_window_ui.btn_forever_buy3.PushDown = false
										current_selected_price_unit_cars[3] = 1
									end	
									Fillshoppingcar_window()
								end
							},

							--七天
							Gui.Button "btn_senven_days_buy3"
							{
								Size = Vector2(103, 26),
								Location = Vector2(117, 104),
								Text = lang:GetText("100/7天"),
								TextColor = ARGB(255, 242, 242, 242),
								HighlightTextColor = ARGB(255, 37, 37, 37),
								Font = "simhei",
								FontSize = 14,
								BackgroundColor = ARGB(255, 255, 255, 255),
								Skin = Gui.ButtonSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_normal.dds", Vector4(10, 10, 10, 10)),
									HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_hover.dds", Vector4(10, 10, 10, 10)),
									DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_down.dds", Vector4(10, 10, 10, 10)),
									DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_normal.dds", Vector4(10, 10, 10, 10)),
								},
								EventClick = function()
									if shoppingcar_window_ui then
										shoppingcar_window_ui.btn_three_days_buy3.PushDown = false
										shoppingcar_window_ui.btn_senven_days_buy3.PushDown = true
										shoppingcar_window_ui.btn_thirty_days_buy3.PushDown = false
										shoppingcar_window_ui.btn_forever_buy3.PushDown = false
										current_selected_price_unit_cars[3] = 2
									end
									Fillshoppingcar_window()
								end,
							},
							
							--三十天
							Gui.Button "btn_thirty_days_buy3"
							{
								Size = Vector2(103, 26),
								Location = Vector2(225, 104),
								Text = lang:GetText("500/30天"),
								TextColor = ARGB(255, 242, 242, 242),
								HighlightTextColor = ARGB(255, 37, 37, 37),
								Font = "simhei",
								FontSize = 14,
								BackgroundColor = ARGB(255, 255, 255, 255),
								Skin = Gui.ButtonSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_normal.dds", Vector4(10, 10, 10, 10)),
									HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_hover.dds", Vector4(10, 10, 10, 10)),
									DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_down.dds", Vector4(10, 10, 10, 10)),
									DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_normal.dds", Vector4(10, 10, 10, 10)),
								},
								EventClick = function()
									if shoppingcar_window_ui then
										current_selected_price_unit_cars[3] = 3
										shoppingcar_window_ui.btn_three_days_buy3.PushDown = false
										shoppingcar_window_ui.btn_senven_days_buy3.PushDown = false
										shoppingcar_window_ui.btn_thirty_days_buy3.PushDown = true
										shoppingcar_window_ui.btn_forever_buy3.PushDown = false
									end
									Fillshoppingcar_window()
								end,
							},

							--永久
							Gui.Button "btn_forever_buy3"
							{
								Size = Vector2(103, 26),
								Location = Vector2(333, 104),
								Text = lang:GetText("1000/永久"),
								TextColor = ARGB(255, 242, 242, 242),
								HighlightTextColor = ARGB(255, 37, 37, 37),
								Font = "simhei",
								FontSize = 14,
								BackgroundColor = ARGB(255, 255, 255, 255),
								Skin = Gui.ButtonSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_normal.dds", Vector4(10, 10, 10, 10)),
									HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_hover.dds", Vector4(10, 10, 10, 10)),
									DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_down.dds", Vector4(10, 10, 10, 10)),
									DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_normal.dds", Vector4(10, 10, 10, 10)),
								},
								EventClick = function()
									if shoppingcar_window_ui then
										current_selected_price_unit_cars[3] = 4
										shoppingcar_window_ui.btn_three_days_buy3.PushDown = false
										shoppingcar_window_ui.btn_senven_days_buy3.PushDown = false
										shoppingcar_window_ui.btn_thirty_days_buy3.PushDown = false
										shoppingcar_window_ui.btn_forever_buy3.PushDown = true
									end
									Fillshoppingcar_window()
								end,
							},
						},
						
						Gui.Control "buy_all_4"
						{
							Size = Vector2(443, 135),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_box4_jiaoyi.dds", Vector4(20, 20, 20, 20)),
							},
							
							Gui.Button "buy_all_chongzhi"
							{
								--Enable = false,
								Size = Vector2(55, 24),
								Location = Vector2(381, 14),
								Text = lang:GetText("移除"),
								TextColor = ARGB(255, 242, 242, 242),
								HighlightTextColor = ARGB(255, 37, 37, 37),
								FontSize = 14,
								Skin = Gui.ButtonSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_button6_normal.dds", Vector4(12, 12, 12, 12)),
									HoverImage = Gui.Image("LobbyUI/team/lb_squad_button6_hover.dds", Vector4(12, 12, 12, 12)),
									DownImage = Gui.Image("LobbyUI/team/lb_squad_button6_down.dds", Vector4(12, 12, 12, 12)),
									DisabledImage = Gui.Image("LobbyUI/team/lb_squad_button6_normal.dds", Vector4(12, 12, 12, 12)),
								},
								EventClick = function()
									L_LobbyMain.RemoveShoppingCart(4)
									L_LobbyMain.FillShoppingCart()
									Fillshoppingcar_window()
									Getshoppingcar_window_count()
									if shoppingcar_window_count == 0 then
										user_bag_ui.btn_buy_all.Enable = false
										user_bag_ui.btn_clear_all.Enable = false
										CloseShoppingCarBuyWin()
									end
								end
							},
							
							--物品图片
							Gui.Control "image_buy_all"
							{
								Size = Vector2(101, 83),
								Location = Vector2(12, 5),
								BackgroundColor = ARGB(255, 255, 255, 255),
								Skin = Gui.ControlSkin
								{
									BackgroundImage = Gui.Image("weapon/hk45_02.dds", Vector4(0, 0, 0, 0)),
								},
							},

							--物品名称
							Gui.Label "all_goods_name_buy"
							{
								Size = Vector2(250, 22),
								Text = lang:GetText("物品名称"),
								Font = "simhei",
								Location = Vector2(136, 15),
								FontSize = 18,
								TextColor = ARGB(255, 37, 37, 37),
							},
							
							Gui.Control "ctrl_balance_mode_bg"
							{
								Size = Vector2(320, 38),
								Location = Vector2(119, 60),
								BackgroundColor = ARGB(255, 255, 255, 255),
								Skin = Gui.ControlSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_line4.dds", Vector4(10, 10, 10, 10)),
								},
								
								--结算方式
								Gui.Label "lbl_balance_mode"
								{
									Size = Vector2(78, 24),
									Text = lang:GetText("结算方式"),
									Font = "simhei",
									Location = Vector2(108, 6),
									FontSize = 18,
									TextColor = ARGB(255, 37, 37, 37),
								},
								
								--上一种结算方式
								Gui.Button "buy_all_front_page"
								{
									Size = Vector2(20, 20),
									Location = Vector2(203, 8),
									--Text = "<",
									TextColor = ARGB(255, 191, 189, 184),
									FontSize = 16,
									Skin = Gui.ButtonSkin
									{
										BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button08_normal.dds", Vector4(0, 0, 0, 0)),
										HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button08_hover.dds", Vector4(0, 0, 0, 0)),
										DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button08_down.dds", Vector4(0, 0, 0, 0)),
										DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button08_normal.dds", Vector4(0, 0, 0, 0)),
									},
									EventClick = function()
										current_selected_price_way_cars[4] = current_selected_price_way_cars[4] - 1
										if current_selected_price_way_cars[4] == 0 then
											current_selected_price_way_cars[4] = 3
										end
										
										if current_selected_price_way_cars[4] == 3 then
											if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][4].voucherprices ~= nil and L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][4].voucherprices[1] ~= nil then
												Fillshoppingcar_window()
											else
												current_selected_price_way_cars[4] = current_selected_price_way_cars[4] - 1
												if current_selected_price_way_cars[4] == 2 then
													if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][4].crprices ~= nil and L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][4].crprices[1] ~= nil then
														Fillshoppingcar_window()
													else
														current_selected_price_way_cars[4] = current_selected_price_way_cars[4] - 1
														Fillshoppingcar_window()
													end
												end
											end
										elseif current_selected_price_way_cars[4] == 2 then
											if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][4].crprices ~= nil and L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][4].crprices[1] ~= nil then
												Fillshoppingcar_window()
											else
												current_selected_price_way_cars[4] = current_selected_price_way_cars[4] - 1
												if current_selected_price_way_cars[4] == 1 then
													if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][4].gpprices ~= nil and L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][4].gpprices[1] ~= nil then
														Fillshoppingcar_window()
													else
														current_selected_price_way_cars[4] = 3
														Fillshoppingcar_window()
													end
												end
											end
										else
											if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][4].gpprices ~= nil and L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][4].gpprices[1] ~= nil then
												Fillshoppingcar_window()
											else
												current_selected_price_way_cars[4] = 3
												if current_selected_price_way_cars[4] == 3 then
													if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][4].voucherprices ~= nil and L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][4].voucherprices[1] ~= nil then
														Fillshoppingcar_window()
													else
														current_selected_price_way_cars[4] = 2	
														Fillshoppingcar_window()
													end
												end
											end
										end
									end
								},
								
								Gui.Label "buy_all_mode"
								{
									Location = Vector2(230, 9),
									Size = Vector2(80, 20),
									Font = "simhei",
									TextAlign = "kAlignCenterMiddle",
									FontSize = 16,
									TextColor = ARGB(255, 37, 37, 37),
									Text = lang:GetText("C币"),
								},
								
								Gui.Button "buy_all_next_page"
								{
									Size = Vector2(20, 20),
									Location = Vector2(292, 8),
									TextColor = ARGB(255, 191, 189, 184),
									FontSize = 16,
									Skin = Gui.ButtonSkin
									{
										BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button09_normal.dds", Vector4(0, 0, 0, 0)),
										HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button09_hover.dds", Vector4(0, 0, 0, 0)),
										DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button09_down.dds", Vector4(0, 0, 0, 0)),
										DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button09_normal.dds", Vector4(0, 0, 0, 0)),
									},
									EventClick = function()
										current_selected_price_way_cars[4] = current_selected_price_way_cars[4] + 1
										if current_selected_price_way_cars[4] == 4 then
											current_selected_price_way_cars[4] = 1
										end
										if current_selected_price_way_cars[4] == 1 then
											if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][4].gpprices ~= nil and L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][4].gpprices[1] ~= nil then
												Fillshoppingcar_window()
											else
												current_selected_price_way_cars[4] = current_selected_price_way_cars[4] + 1
												if current_selected_price_way_cars[4] == 2 then
													if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][4].crprices ~= nil and L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][4].crprices[1] ~= nil then
														Fillshoppingcar_window()
													else
														current_selected_price_way_cars[4] = current_selected_price_way_cars[4] + 1
														Fillshoppingcar_window()
													end
												end
											end
										elseif current_selected_price_way_cars[4] == 2 then
											if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][4].crprices ~= nil and L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][4].crprices[1] ~= nil then
												Fillshoppingcar_window()
											else
												current_selected_price_way_cars[4] = current_selected_price_way_cars[4] + 1
												if current_selected_price_way_cars[4] == 3 then
													if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][4].voucherprices ~= nil and L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][4].voucherprices[1] ~= nil then
														Fillshoppingcar_window()
													else
														current_selected_price_way_cars[4] = 1
														Fillshoppingcar_window()
													end
												end
											end
										else 
											if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][4].voucherprices ~= nil and L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][4].voucherprices[1] ~= nil then
												Fillshoppingcar_window()
											else
												current_selected_price_way_cars[4] = 1
												if current_selected_price_way_cars[4] == 1 then
													if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][4].gpprices ~= nil and L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][4].gpprices[1] ~= nil then
														Fillshoppingcar_window()
													else
														current_selected_price_way_cars[4] = 2	
														Fillshoppingcar_window()
													end
												end
											end
										end
									end
								},
							},
							
							--三天
							Gui.Button "btn_three_days_buy4"
							{
								Size = Vector2(103, 26),
								Location = Vector2(9, 104),
								Text = lang:GetText("50/3天"),
								TextColor = ARGB(255, 242, 242, 242),
								HighlightTextColor = ARGB(255, 37, 37, 37),
								Font = "simhei",
								FontSize = 14,
								BackgroundColor = ARGB(255, 255, 255, 255),
								PushDown = true,
								Skin = Gui.ButtonSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_normal.dds", Vector4(10, 10, 10, 10)),
									HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_hover.dds", Vector4(10, 10, 10, 10)),
									DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_down.dds", Vector4(10, 10, 10, 10)),
									DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_normal.dds", Vector4(10, 10, 10, 10)),
								},
								EventClick = function()
									if  shoppingcar_window_ui then
										shoppingcar_window_ui.btn_three_days_buy4.PushDown = true
										shoppingcar_window_ui.btn_senven_days_buy4.PushDown = false
										shoppingcar_window_ui.btn_thirty_days_buy4.PushDown = false
										shoppingcar_window_ui.btn_forever_buy4.PushDown = false
										current_selected_price_unit_cars[4] = 1
									end
									Fillshoppingcar_window()
								end
							},

							--七天
							Gui.Button "btn_senven_days_buy4"
							{
								Size = Vector2(103, 26),
								Location = Vector2(117, 104),
								Text = lang:GetText("100/7天"),
								TextColor = ARGB(255, 242, 242, 242),
								HighlightTextColor = ARGB(255, 37, 37, 37),
								Font = "simhei",
								FontSize = 14,
								BackgroundColor = ARGB(255, 255, 255, 255),
								Skin = Gui.ButtonSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_normal.dds", Vector4(10, 10, 10, 10)),
									HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_hover.dds", Vector4(10, 10, 10, 10)),
									DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_down.dds", Vector4(10, 10, 10, 10)),
									DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_normal.dds", Vector4(10, 10, 10, 10)),
								},
								EventClick = function()
									if shoppingcar_window_ui then
										shoppingcar_window_ui.btn_three_days_buy4.PushDown = false
										shoppingcar_window_ui.btn_senven_days_buy4.PushDown = true
										shoppingcar_window_ui.btn_thirty_days_buy4.PushDown = false
										shoppingcar_window_ui.btn_forever_buy4.PushDown = false
										current_selected_price_unit_cars[4] = 2
									end
									Fillshoppingcar_window()
								end,
							},
							
							--三十天
							Gui.Button "btn_thirty_days_buy4"
							{
								Size = Vector2(103, 26),
								Location = Vector2(225, 104),
								Text = lang:GetText("500/30天"),
								TextColor = ARGB(255, 242, 242, 242),
								HighlightTextColor = ARGB(255, 37, 37, 37),
								Font = "simhei",
								FontSize = 14,
								BackgroundColor = ARGB(255, 255, 255, 255),
								Skin = Gui.ButtonSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_normal.dds", Vector4(10, 10, 10, 10)),
									HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_hover.dds", Vector4(10, 10, 10, 10)),
									DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_down.dds", Vector4(10, 10, 10, 10)),
									DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_normal.dds", Vector4(10, 10, 10, 10)),
								},
								EventClick = function()
									if shoppingcar_window_ui then
										current_selected_price_unit_cars[4] = 3
										shoppingcar_window_ui.btn_three_days_buy4.PushDown = false
										shoppingcar_window_ui.btn_senven_days_buy4.PushDown = false
										shoppingcar_window_ui.btn_thirty_days_buy4.PushDown = true
										shoppingcar_window_ui.btn_forever_buy4.PushDown = false
									end
									Fillshoppingcar_window()
								end,
							},

							--永久
							Gui.Button "btn_forever_buy4"
							{
								Size = Vector2(103, 26),
								Location = Vector2(333, 104),
								Text = lang:GetText("1000/永久"),
								TextColor = ARGB(255, 242, 242, 242),
								HighlightTextColor = ARGB(255, 37, 37, 37),
								Font = "simhei",
								FontSize = 14,
								BackgroundColor = ARGB(255, 255, 255, 255),
								Skin = Gui.ButtonSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_normal.dds", Vector4(10, 10, 10, 10)),
									HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_hover.dds", Vector4(10, 10, 10, 10)),
									DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_down.dds", Vector4(10, 10, 10, 10)),
									DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_normal.dds", Vector4(10, 10, 10, 10)),
								},
								EventClick = function()
									if shoppingcar_window_ui then
										current_selected_price_unit_cars[4] = 4
										shoppingcar_window_ui.btn_three_days_buy4.PushDown = false
										shoppingcar_window_ui.btn_senven_days_buy4.PushDown = false
										shoppingcar_window_ui.btn_thirty_days_buy4.PushDown = false
										shoppingcar_window_ui.btn_forever_buy4.PushDown = true
									end
									Fillshoppingcar_window()
								end,
							},
						},
						
						Gui.Control "buy_all_5"
						{
							Size = Vector2(443, 135),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_box4_jiaoyi.dds", Vector4(20, 20, 20, 20)),
							},
							
							Gui.Button "buy_all_chongzhi"
							{
								--Enable = false,
								Size = Vector2(55, 24),
								Location = Vector2(381, 14),
								Text = lang:GetText("移除"),
								TextColor = ARGB(255, 242, 242, 242),
								HighlightTextColor = ARGB(255, 37, 37, 37),
								FontSize = 14,
								Skin = Gui.ButtonSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_button6_normal.dds", Vector4(12, 12, 12, 12)),
									HoverImage = Gui.Image("LobbyUI/team/lb_squad_button6_hover.dds", Vector4(12, 12, 12, 12)),
									DownImage = Gui.Image("LobbyUI/team/lb_squad_button6_down.dds", Vector4(12, 12, 12, 12)),
									DisabledImage = Gui.Image("LobbyUI/team/lb_squad_button6_normal.dds", Vector4(12, 12, 12, 12)),
								},
								EventClick = function()
									L_LobbyMain.RemoveShoppingCart(5)
									L_LobbyMain.FillShoppingCart()
									Fillshoppingcar_window()
									Getshoppingcar_window_count()
									if shoppingcar_window_count == 0 then
										user_bag_ui.btn_buy_all.Enable = false
										user_bag_ui.btn_clear_all.Enable = false
										CloseShoppingCarBuyWin()
									end
								end
							},
							
							--物品图片
							Gui.Control "image_buy_all"
							{
								Size = Vector2(101, 83),
								Location = Vector2(12, 5),
								BackgroundColor = ARGB(255, 255, 255, 255),
								Skin = Gui.ControlSkin
								{
									BackgroundImage = Gui.Image("weapon/hk45_02.dds", Vector4(0, 0, 0, 0)),
								},
							},

							--物品名称
							Gui.Label "all_goods_name_buy"
							{
								Size = Vector2(250, 22),
								Text = lang:GetText("物品名称"),
								Font = "simhei",
								Location = Vector2(136, 15),
								FontSize = 18,
								TextColor = ARGB(255, 37, 37, 37),
							},
							
							Gui.Control "ctrl_balance_mode_bg"
							{
								Size = Vector2(320, 38),
								Location = Vector2(119, 60),
								BackgroundColor = ARGB(255, 255, 255, 255),
								Skin = Gui.ControlSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_line4.dds", Vector4(10, 10, 10, 10)),
								},
								
								--结算方式
								Gui.Label "lbl_balance_mode"
								{
									Size = Vector2(78, 24),
									Text = lang:GetText("结算方式"),
									Font = "simhei",
									Location = Vector2(108, 6),
									FontSize = 18,
									TextColor = ARGB(255, 37, 37, 37),
								},
								
								--上一种结算方式
								Gui.Button "buy_all_front_page"
								{
									Size = Vector2(20, 20),
									Location = Vector2(203, 8),
									--Text = "<",
									TextColor = ARGB(255, 191, 189, 184),
									FontSize = 16,
									Skin = Gui.ButtonSkin
									{
										BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button08_normal.dds", Vector4(0, 0, 0, 0)),
										HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button08_hover.dds", Vector4(0, 0, 0, 0)),
										DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button08_down.dds", Vector4(0, 0, 0, 0)),
										DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button08_normal.dds", Vector4(0, 0, 0, 0)),
									},
									EventClick = function()
										current_selected_price_way_cars[5] = current_selected_price_way_cars[5] - 1
										if current_selected_price_way_cars[5] == 0 then
											current_selected_price_way_cars[5] = 3
										end
										
										if current_selected_price_way_cars[5] == 3 then
											if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][5].voucherprices ~= nil and L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][5].voucherprices[1] ~= nil then
												Fillshoppingcar_window()
											else
												current_selected_price_way_cars[5] = current_selected_price_way_cars[5] - 1
												if current_selected_price_way_cars[5] == 2 then
													if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][1].crprices ~= nil and L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][5].crprices[1] ~= nil then
														Fillshoppingcar_window()
													else
														current_selected_price_way_cars[5] = current_selected_price_way_cars[5] - 1
														Fillshoppingcar_window()
													end
												end
											end
										elseif current_selected_price_way_cars[5] == 2 then
											if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][5].crprices ~= nil and L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][5].crprices[1] ~= nil then
												Fillshoppingcar_window()
											else
												current_selected_price_way_cars[5] = current_selected_price_way_cars[5] - 1
												if current_selected_price_way_cars[5] == 1 then
													if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][5].gpprices ~= nil and L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][5].gpprices[1] ~= nil then
														Fillshoppingcar_window()
													else
														current_selected_price_way_cars[5] = 3
														Fillshoppingcar_window()
													end
												end
											end
										else
											if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][5].gpprices ~= nil and L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][5].gpprices[1] ~= nil then
												Fillshoppingcar_window()
											else
												current_selected_price_way_cars[5] = 3
												if current_selected_price_way_cars[5] == 3 then
													if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][5].voucherprices ~= nil and L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][5].voucherprices[1] ~= nil then
														Fillshoppingcar_window()
													else
														current_selected_price_way_cars[5] = 2	
														Fillshoppingcar_window()
													end
												end
											end
										end
									end
								},
								
								Gui.Label "buy_all_mode"
								{
									Location = Vector2(230, 9),
									Size = Vector2(80, 20),
									Font = "simhei",
									TextAlign = "kAlignCenterMiddle",
									FontSize = 16,
									TextColor = ARGB(255, 37, 37, 37),
									Text = lang:GetText("C币"),
								},
								
								Gui.Button "buy_all_next_page"
								{
									Size = Vector2(20, 20),
									Location = Vector2(292, 8),
									TextColor = ARGB(255, 191, 189, 184),
									FontSize = 16,
									Skin = Gui.ButtonSkin
									{
										BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button09_normal.dds", Vector4(0, 0, 0, 0)),
										HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button09_hover.dds", Vector4(0, 0, 0, 0)),
										DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button09_down.dds", Vector4(0, 0, 0, 0)),
										DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button09_normal.dds", Vector4(0, 0, 0, 0)),
									},
									EventClick = function()
										current_selected_price_way_cars[5] = current_selected_price_way_cars[5] + 1
										if current_selected_price_way_cars[5] == 4 then
											current_selected_price_way_cars[5] = 1
										end
										if current_selected_price_way_cars[5] == 1 then
											if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][5].gpprices ~= nil and L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][5].gpprices[1] ~= nil then
												Fillshoppingcar_window()
											else
												current_selected_price_way_cars[5] = current_selected_price_way_cars[5] + 1
												if current_selected_price_way_cars[5] == 2 then
													if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][5].crprices ~= nil and L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][5].crprices[1] ~= nil then
														Fillshoppingcar_window()
													else
														current_selected_price_way_cars[5] = current_selected_price_way_cars[5] + 1
														Fillshoppingcar_window()
													end
												end
											end
										elseif current_selected_price_way_cars[5] == 2 then
											if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][5].crprices ~= nil and L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][5].crprices[1] ~= nil then
												Fillshoppingcar_window()
											else
												current_selected_price_way_cars[5] = current_selected_price_way_cars[5] + 1
												if current_selected_price_way_cars[5] == 3 then
													if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][5].voucherprices ~= nil and L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][5].voucherprices[1] ~= nil then
														Fillshoppingcar_window()
													else
														current_selected_price_way_cars[5] = 1
														Fillshoppingcar_window()
													end
												end
											end
										else 
											if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][5].voucherprices ~= nil and L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][5].voucherprices[1] ~= nil then
												Fillshoppingcar_window()
											else
												current_selected_price_way_cars[5] = 1
												if current_selected_price_way_cars[5] == 1 then
													if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][5].gpprices ~= nil and L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][5].gpprices[1] ~= nil then
														Fillshoppingcar_window()
													else
														current_selected_price_way_cars[5] = 2	
														Fillshoppingcar_window()
													end
												end
											end
										end
									end
								},
							},

							--三天
							Gui.Button "btn_three_days_buy5"
							{
								Size = Vector2(103, 26),
								Location = Vector2(9, 104),
								Text = lang:GetText("50/3天"),
								TextColor = ARGB(255, 242, 242, 242),
								HighlightTextColor = ARGB(255, 37, 37, 37),
								Font = "simhei",
								FontSize = 14,
								BackgroundColor = ARGB(255, 255, 255, 255),
								PushDown = true,
								Skin = Gui.ButtonSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_normal.dds", Vector4(10, 10, 10, 10)),
									HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_hover.dds", Vector4(10, 10, 10, 10)),
									DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_down.dds", Vector4(10, 10, 10, 10)),
									DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_normal.dds", Vector4(10, 10, 10, 10)),
								},
								EventClick = function()
									if  shoppingcar_window_ui then
										shoppingcar_window_ui.btn_three_days_buy5.PushDown = true
										shoppingcar_window_ui.btn_senven_days_buy5.PushDown = false
										shoppingcar_window_ui.btn_thirty_days_buy5.PushDown = false
										shoppingcar_window_ui.btn_forever_buy5.PushDown = false
										current_selected_price_unit_cars[5] = 1
									end
									Fillshoppingcar_window()
								end
							},

							--七天
							Gui.Button "btn_senven_days_buy5"
							{
								Size = Vector2(103, 26),
								Location = Vector2(117, 104),
								Text = lang:GetText("100/7天"),
								TextColor = ARGB(255, 242, 242, 242),
								HighlightTextColor = ARGB(255, 37, 37, 37),
								Font = "simhei",
								FontSize = 14,
								BackgroundColor = ARGB(255, 255, 255, 255),
								Skin = Gui.ButtonSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_normal.dds", Vector4(10, 10, 10, 10)),
									HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_hover.dds", Vector4(10, 10, 10, 10)),
									DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_down.dds", Vector4(10, 10, 10, 10)),
									DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_normal.dds", Vector4(10, 10, 10, 10)),
								},
								EventClick = function()
									if shoppingcar_window_ui then
										shoppingcar_window_ui.btn_three_days_buy5.PushDown = false
										shoppingcar_window_ui.btn_senven_days_buy5.PushDown = true
										shoppingcar_window_ui.btn_thirty_days_buy5.PushDown = false
										shoppingcar_window_ui.btn_forever_buy5.PushDown = false
										current_selected_price_unit_cars[5] = 2
									end
									Fillshoppingcar_window()
								end,
							},
							
							--三十天
							Gui.Button "btn_thirty_days_buy5"
							{
								Size = Vector2(103, 26),
								Location = Vector2(225, 104),
								Text = lang:GetText("500/30天"),
								TextColor = ARGB(255, 242, 242, 242),
								HighlightTextColor = ARGB(255, 37, 37, 37),
								Font = "simhei",
								FontSize = 14,
								BackgroundColor = ARGB(255, 255, 255, 255),
								Skin = Gui.ButtonSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_normal.dds", Vector4(10, 10, 10, 10)),
									HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_hover.dds", Vector4(10, 10, 10, 10)),
									DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_down.dds", Vector4(10, 10, 10, 10)),
									DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_normal.dds", Vector4(10, 10, 10, 10)),
								},
								EventClick = function()
									if shoppingcar_window_ui then
										current_selected_price_unit_cars[5] = 3
										shoppingcar_window_ui.btn_three_days_buy5.PushDown = false
										shoppingcar_window_ui.btn_senven_days_buy5.PushDown = false
										shoppingcar_window_ui.btn_thirty_days_buy5.PushDown = true
										shoppingcar_window_ui.btn_forever_buy5.PushDown = false
									end
									Fillshoppingcar_window()
								end,
							},

							--永久
							Gui.Button "btn_forever_buy5"
							{
								Size = Vector2(103, 26),
								Location = Vector2(333, 104),
								Text = lang:GetText("1000/永久"),
								TextColor = ARGB(255, 242, 242, 242),
								HighlightTextColor = ARGB(255, 37, 37, 37),
								Font = "simhei",
								FontSize = 14,
								BackgroundColor = ARGB(255, 255, 255, 255),
								Skin = Gui.ButtonSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_normal.dds", Vector4(10, 10, 10, 10)),
									HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_hover.dds", Vector4(10, 10, 10, 10)),
									DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_down.dds", Vector4(10, 10, 10, 10)),
									DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_normal.dds", Vector4(10, 10, 10, 10)),
								},
								EventClick = function()
									if shoppingcar_window_ui then
										current_selected_price_unit_cars[5] = 4
										shoppingcar_window_ui.btn_three_days_buy5.PushDown = false
										shoppingcar_window_ui.btn_senven_days_buy5.PushDown = false
										shoppingcar_window_ui.btn_thirty_days_buy5.PushDown = false
										shoppingcar_window_ui.btn_forever_buy5.PushDown = true
									end
									Fillshoppingcar_window()
								end,
							},
						},
						
						Gui.Control "buy_all_6"
						{
							Size = Vector2(443, 135),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_box4_jiaoyi.dds", Vector4(20, 20, 20, 20)),
							},
							
							Gui.Button "buy_all_chongzhi"
							{
								--Enable = false,
								Size = Vector2(55, 24),
								Location = Vector2(381, 14),
								Text = lang:GetText("移除"),
								TextColor = ARGB(255, 242, 242, 242),
								HighlightTextColor = ARGB(255, 37, 37, 37),
								FontSize = 14,
								Skin = Gui.ButtonSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_button6_normal.dds", Vector4(12, 12, 12, 12)),
									HoverImage = Gui.Image("LobbyUI/team/lb_squad_button6_hover.dds", Vector4(12, 12, 12, 12)),
									DownImage = Gui.Image("LobbyUI/team/lb_squad_button6_down.dds", Vector4(12, 12, 12, 12)),
									DisabledImage = Gui.Image("LobbyUI/team/lb_squad_button6_normal.dds", Vector4(12, 12, 12, 12)),
								},
								EventClick = function()
									L_LobbyMain.RemoveShoppingCart(6)
									L_LobbyMain.FillShoppingCart()
									Fillshoppingcar_window()
									Getshoppingcar_window_count()
									if shoppingcar_window_count == 0 then
										user_bag_ui.btn_buy_all.Enable = false
										user_bag_ui.btn_clear_all.Enable = false
										CloseShoppingCarBuyWin()
									end
								end
							},
							
							--物品图片
							Gui.Control "image_buy_all"
							{
								Size = Vector2(101, 83),
								Location = Vector2(12, 5),
								BackgroundColor = ARGB(255, 255, 255, 255),
								Skin = Gui.ControlSkin
								{
									BackgroundImage = Gui.Image("weapon/hk45_02.dds", Vector4(0, 0, 0, 0)),
								},
							},

							--物品名称
							Gui.Label "all_goods_name_buy"
							{
								Size = Vector2(250, 22),
								Text = lang:GetText("物品名称"),
								Font = "simhei",
								Location = Vector2(136, 15),
								FontSize = 18,
								TextColor = ARGB(255, 37, 37, 37),
							},
							
							Gui.Control "ctrl_balance_mode_bg"
							{
								Size = Vector2(320, 38),
								Location = Vector2(119, 60),
								BackgroundColor = ARGB(255, 255, 255, 255),
								Skin = Gui.ControlSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_line4.dds", Vector4(10, 10, 10, 10)),
								},
								
								--结算方式
								Gui.Label "lbl_balance_mode"
								{
									Size = Vector2(78, 24),
									Text = lang:GetText("结算方式"),
									Font = "simhei",
									Location = Vector2(108, 6),
									FontSize = 18,
									TextColor = ARGB(255, 37, 37, 37),
								},
								
								--上一种结算方式
								Gui.Button "buy_all_front_page"
								{
									Size = Vector2(20, 20),
									Location = Vector2(203, 8),
									--Text = "<",
									TextColor = ARGB(255, 191, 189, 184),
									FontSize = 16,
									Skin = Gui.ButtonSkin
									{
										BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button08_normal.dds", Vector4(0, 0, 0, 0)),
										HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button08_hover.dds", Vector4(0, 0, 0, 0)),
										DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button08_down.dds", Vector4(0, 0, 0, 0)),
										DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button08_normal.dds", Vector4(0, 0, 0, 0)),
									},
									EventClick = function()
										current_selected_price_way_cars[6] = current_selected_price_way_cars[6] - 1
										if current_selected_price_way_cars[6] == 0 then
											current_selected_price_way_cars[6] = 3
										end
										
										if current_selected_price_way_cars[6] == 3 then
											if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][6].voucherprices ~= nil and L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][6].voucherprices[1] ~= nil then
												Fillshoppingcar_window()
											else
												current_selected_price_way_cars[6] = current_selected_price_way_cars[6] - 1
												if current_selected_price_way_cars[6] == 2 then
													if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][1].crprices ~= nil and L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][6].crprices[1] ~= nil then
														Fillshoppingcar_window()
													else
														current_selected_price_way_cars[6] = current_selected_price_way_cars[6] - 1
														Fillshoppingcar_window()
													end
												end
											end
										elseif current_selected_price_way_cars[6] == 2 then
											if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][6].crprices ~= nil and L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][6].crprices[1] ~= nil then
												Fillshoppingcar_window()
											else
												current_selected_price_way_cars[6] = current_selected_price_way_cars[6] - 1
												if current_selected_price_way_cars[6] == 1 then
													if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][6].gpprices ~= nil and L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][6].gpprices[1] ~= nil then
														Fillshoppingcar_window()
													else
														current_selected_price_way_cars[6] = 3
														Fillshoppingcar_window()
													end
												end
											end
										else 
											if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][6].gpprices ~= nil and L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][6].gpprices[1] ~= nil then
												Fillshoppingcar_window()
											else
												current_selected_price_way_cars[6] = 3
												if current_selected_price_way_cars[6] == 3 then
													if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][6].voucherprices ~= nil and L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][6].voucherprices[1] ~= nil then
														Fillshoppingcar_window()
													else
														current_selected_price_way_cars[6] = 2	
														Fillshoppingcar_window()
													end
												end
											end
										end
									end
								},
								
								Gui.Label "buy_all_mode"
								{
									Location = Vector2(230, 9),
									Size = Vector2(80, 20),
									Font = "simhei",
									TextAlign = "kAlignCenterMiddle",
									FontSize = 16,
									TextColor = ARGB(255, 37, 37, 37),
									Text = lang:GetText("C币"),
								},
								
								Gui.Button "buy_all_next_page"
								{
									Size = Vector2(20, 20),
									Location = Vector2(298, 8),
									TextColor = ARGB(255, 191, 189, 184),
									FontSize = 16,
									Skin = Gui.ButtonSkin
									{
										BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button09_normal.dds", Vector4(0, 0, 0, 0)),
										HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button09_hover.dds", Vector4(0, 0, 0, 0)),
										DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button09_down.dds", Vector4(0, 0, 0, 0)),
										DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button09_normal.dds", Vector4(0, 0, 0, 0)),
									},
									EventClick = function()
										current_selected_price_way_cars[6] = current_selected_price_way_cars[6] + 1
										if current_selected_price_way_cars[6] == 4 then
											current_selected_price_way_cars[6] = 1
										end
										if current_selected_price_way_cars[6] == 1 then
											if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][6].gpprices ~= nil and L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][6].gpprices[1] ~= nil then
												Fillshoppingcar_window()
											else
												current_selected_price_way_cars[6] = current_selected_price_way_cars[6] + 1
												if current_selected_price_way_cars[6] == 2 then
													if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][6].crprices ~= nil and L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][6].crprices[1] ~= nil then
														Fillshoppingcar_window()
													else
														current_selected_price_way_cars[6] = current_selected_price_way_cars[6] + 1
														Fillshoppingcar_window()
													end
												end
											end
										elseif current_selected_price_way_cars[6] == 2 then
											if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][6].crprices ~= nil and L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][6].crprices[1] ~= nil then
												Fillshoppingcar_window()
											else
												current_selected_price_way_cars[6] = current_selected_price_way_cars[6] + 1
												if current_selected_price_way_cars[6] == 3 then
													if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][6].voucherprices ~= nil and L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][6].voucherprices[1] ~= nil then
														Fillshoppingcar_window()
													else
														current_selected_price_way_cars[6] = 1
														Fillshoppingcar_window()
													end
												end
											end
										else 
											if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][6].voucherprices ~= nil and L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][6].voucherprices[1] ~= nil then
												Fillshoppingcar_window()
											else
												current_selected_price_way_cars[6] = 1
												if current_selected_price_way_cars[6] == 1 then
													if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][6].gpprices ~= nil and L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][6].gpprices[1] ~= nil then
														Fillshoppingcar_window()
													else
														current_selected_price_way_cars[6] = 2	
														Fillshoppingcar_window()
													end
												end
											end
										end
									end
								},
							},

							--三天
							Gui.Button "btn_three_days_buy6"
							{
								Size = Vector2(103, 26),
								Location = Vector2(9, 104),
								Text = lang:GetText("50/3天"),
								TextColor = ARGB(255, 242, 242, 242),
								HighlightTextColor = ARGB(255, 37, 37, 37),
								Font = "simhei",
								FontSize = 14,
								BackgroundColor = ARGB(255, 255, 255, 255),
								PushDown = true,
								Skin = Gui.ButtonSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_normal.dds", Vector4(10, 10, 10, 10)),
									HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_hover.dds", Vector4(10, 10, 10, 10)),
									DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_down.dds", Vector4(10, 10, 10, 10)),
									DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_normal.dds", Vector4(10, 10, 10, 10)),
								},
								EventClick = function()
									if  shoppingcar_window_ui then
										shoppingcar_window_ui.btn_three_days_buy6.PushDown = true
										shoppingcar_window_ui.btn_senven_days_buy6.PushDown = false
										shoppingcar_window_ui.btn_thirty_days_buy6.PushDown = false
										shoppingcar_window_ui.btn_forever_buy6.PushDown = false
										current_selected_price_unit_cars[6] = 1
									end		
									Fillshoppingcar_window()
								end				
							},

							--七天
							Gui.Button "btn_senven_days_buy6"
							{
								Size = Vector2(103, 26),
								Location = Vector2(117, 104),
								Text = lang:GetText("100/7天"),
								TextColor = ARGB(255, 242, 242, 242),
								HighlightTextColor = ARGB(255, 37, 37, 37),
								Font = "simhei",
								FontSize = 14,
								BackgroundColor = ARGB(255, 255, 255, 255),
								Skin = Gui.ButtonSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_normal.dds", Vector4(10, 10, 10, 10)),
									HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_hover.dds", Vector4(10, 10, 10, 10)),
									DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_down.dds", Vector4(10, 10, 10, 10)),
									DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_normal.dds", Vector4(10, 10, 10, 10)),
								},
								EventClick = function()
									if shoppingcar_window_ui then
										shoppingcar_window_ui.btn_three_days_buy6.PushDown = false
										shoppingcar_window_ui.btn_senven_days_buy6.PushDown = true
										shoppingcar_window_ui.btn_thirty_days_buy6.PushDown = false
										shoppingcar_window_ui.btn_forever_buy6.PushDown = false
										current_selected_price_unit_cars[6] = 2
									end
									Fillshoppingcar_window()
								end,
							},
							
							--三十天
							Gui.Button "btn_thirty_days_buy6"
							{
								Size = Vector2(103, 26),
								Location = Vector2(225, 104),
								Text = lang:GetText("500/30天"),
								TextColor = ARGB(255, 242, 242, 242),
								HighlightTextColor = ARGB(255, 37, 37, 37),
								Font = "simhei",
								FontSize = 14,
								BackgroundColor = ARGB(255, 255, 255, 255),
								Skin = Gui.ButtonSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_normal.dds", Vector4(10, 10, 10, 10)),
									HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_hover.dds", Vector4(10, 10, 10, 10)),
									DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_down.dds", Vector4(10, 10, 10, 10)),
									DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_normal.dds", Vector4(10, 10, 10, 10)),
								},
								EventClick = function()
									if shoppingcar_window_ui then
										current_selected_price_unit_cars[6] = 3
										shoppingcar_window_ui.btn_three_days_buy6.PushDown = false
										shoppingcar_window_ui.btn_senven_days_buy6.PushDown = false
										shoppingcar_window_ui.btn_thirty_days_buy6.PushDown = true
										shoppingcar_window_ui.btn_forever_buy6.PushDown = false
									end
									Fillshoppingcar_window()
								end,
							},

							--永久
							Gui.Button "btn_forever_buy6"
							{
								Size = Vector2(103, 26),
								Location = Vector2(333, 104),
								Text = lang:GetText("1000/永久"),
								TextColor = ARGB(255, 242, 242, 242),
								HighlightTextColor = ARGB(255, 37, 37, 37),
								Font = "simhei",
								FontSize = 14,
								BackgroundColor = ARGB(255, 255, 255, 255),
								Skin = Gui.ButtonSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_normal.dds", Vector4(10, 10, 10, 10)),
									HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_hover.dds", Vector4(10, 10, 10, 10)),
									DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_down.dds", Vector4(10, 10, 10, 10)),
									DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_normal.dds", Vector4(10, 10, 10, 10)),
								},
								EventClick = function()
									if shoppingcar_window_ui then
										current_selected_price_unit_cars[6] = 4
										shoppingcar_window_ui.btn_three_days_buy6.PushDown = false
										shoppingcar_window_ui.btn_senven_days_buy6.PushDown = false
										shoppingcar_window_ui.btn_thirty_days_buy6.PushDown = false
										shoppingcar_window_ui.btn_forever_buy6.PushDown = true
									end
									Fillshoppingcar_window()
								end,
							},
						},
						
						Gui.Control "buy_all_7"
						{
							Size = Vector2(443, 135),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_box4_jiaoyi.dds", Vector4(20, 20, 20, 20)),
							},
							
							Gui.Button "buy_all_chongzhi"
							{
								--Enable = false,
								Size = Vector2(55, 24),
								Location = Vector2(381, 14),
								Text = lang:GetText("移除"),
								TextColor = ARGB(255, 242, 242, 242),
								HighlightTextColor = ARGB(255, 37, 37, 37),
								FontSize = 14,
								Skin = Gui.ButtonSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_button6_normal.dds", Vector4(12, 12, 12, 12)),
									HoverImage = Gui.Image("LobbyUI/team/lb_squad_button6_hover.dds", Vector4(12, 12, 12, 12)),
									DownImage = Gui.Image("LobbyUI/team/lb_squad_button6_down.dds", Vector4(12, 12, 12, 12)),
									DisabledImage = Gui.Image("LobbyUI/team/lb_squad_button6_normal.dds", Vector4(12, 12, 12, 12)),
								},
								EventClick = function()
									L_LobbyMain.RemoveShoppingCart(7)
									L_LobbyMain.FillShoppingCart()
									Getshoppingcar_window_count()
									if shoppingcar_window_count == 0 then
										user_bag_ui.btn_buy_all.Enable = false
										user_bag_ui.btn_clear_all.Enable = false
										CloseShoppingCarBuyWin()
									end
									Fillshoppingcar_window()
								end
							},
							
							--物品图片
							Gui.Control "image_buy_all"
							{
								Size = Vector2(101, 83),
								Location = Vector2(12, 5),
								BackgroundColor = ARGB(255, 255, 255, 255),
								Skin = Gui.ControlSkin
								{
									BackgroundImage = Gui.Image("weapon/hk45_02.dds", Vector4(0, 0, 0, 0)),
								},
							},

							--物品名称
							Gui.Label "all_goods_name_buy"
							{
								Size = Vector2(250, 22),
								Text = lang:GetText("物品名称"),
								Font = "simhei",
								Location = Vector2(136, 15),
								FontSize = 18,
								TextColor = ARGB(255, 37, 37, 37),
							},
							
							Gui.Control "ctrl_balance_mode_bg"
							{
								Size = Vector2(320, 38),
								Location = Vector2(119, 60),
								BackgroundColor = ARGB(255, 255, 255, 255),
								Skin = Gui.ControlSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_line4.dds", Vector4(10, 10, 10, 10)),
								},
								
								--结算方式
								Gui.Label "lbl_balance_mode"
								{
									Size = Vector2(78, 24),
									Text = lang:GetText("结算方式"),
									Font = "simhei",
									Location = Vector2(108, 6),
									FontSize = 18,
									TextColor = ARGB(255, 37, 37, 37),
								},
								
								--上一种结算方式
								Gui.Button "buy_all_front_page"
								{
									Size = Vector2(20, 20),
									Location = Vector2(203, 8),
									--Text = "<",
									TextColor = ARGB(255, 191, 189, 184),
									FontSize = 16,
									Skin = Gui.ButtonSkin
									{
										BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button08_normal.dds", Vector4(0, 0, 0, 0)),
										HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button08_hover.dds", Vector4(0, 0, 0, 0)),
										DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button08_down.dds", Vector4(0, 0, 0, 0)),
										DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button08_normal.dds", Vector4(0, 0, 0, 0)),
									},
									EventClick = function()
										current_selected_price_way_cars[7] = current_selected_price_way_cars[7] - 1
										if current_selected_price_way_cars[7] == 0 then
											current_selected_price_way_cars[7] = 3
										end
										
										if current_selected_price_way_cars[7] == 3 then
											if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][7].voucherprices ~= nil and L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][7].voucherprices[1] ~= nil then
												Fillshoppingcar_window()
											else
												current_selected_price_way_cars[7] = current_selected_price_way_cars[7] - 1
												if current_selected_price_way_cars[7] == 2 then
													if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][1].crprices ~= nil and L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][7].crprices[1] ~= nil then
														Fillshoppingcar_window()
													else
														current_selected_price_way_cars[7] = current_selected_price_way_cars[7] - 1
														Fillshoppingcar_window()
													end
												end
											end
										elseif current_selected_price_way_cars[7] == 2 then
											if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][7].crprices ~= nil and L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][7].crprices[1] ~= nil then
												Fillshoppingcar_window()
											else
												current_selected_price_way_cars[7] = current_selected_price_way_cars[7] - 1
												if current_selected_price_way_cars[7] == 1 then
													if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][7].gpprices ~= nil and L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][7].gpprices[1] ~= nil then
														Fillshoppingcar_window()
													else
														current_selected_price_way_cars[7] = 3
														Fillshoppingcar_window()
													end
												end
											end
										else
											if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][7].gpprices ~= nil and L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][7].gpprices[1] ~= nil then
												Fillshoppingcar_window()
											else
												current_selected_price_way_cars[7] = 3
												if current_selected_price_way_cars[7] == 3 then
													if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][7].voucherprices ~= nil and L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][7].voucherprices[1] ~= nil then
														Fillshoppingcar_window()
													else
														current_selected_price_way_cars[7] = 2	
														Fillshoppingcar_window()
													end
												end
											end
										end
									end
								},
								
								Gui.Label "buy_all_mode"
								{
									Location = Vector2(230, 9),
									Size = Vector2(80, 20),
									Font = "simhei",
									TextAlign = "kAlignCenterMiddle",
									FontSize = 16,
									TextColor = ARGB(255, 37, 37, 37),
									Text = lang:GetText("C币"),
								},
								
								Gui.Button "buy_all_next_page"
								{
									Size = Vector2(20, 20),
									Location = Vector2(292, 8),
									TextColor = ARGB(255, 191, 189, 184),
									FontSize = 16,
									Skin = Gui.ButtonSkin
									{
										BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button09_normal.dds", Vector4(0, 0, 0, 0)),
										HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button09_hover.dds", Vector4(0, 0, 0, 0)),
										DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button09_down.dds", Vector4(0, 0, 0, 0)),
										DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button09_normal.dds", Vector4(0, 0, 0, 0)),
									},
									EventClick = function()
										current_selected_price_way_cars[7] = current_selected_price_way_cars[7] + 1
										if current_selected_price_way_cars[7] == 4 then
											current_selected_price_way_cars[7] = 1
										end
										if current_selected_price_way_cars[7] == 1 then
											if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][7].gpprices ~= nil and L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][7].gpprices[1] ~= nil then
												Fillshoppingcar_window()
											else
												current_selected_price_way_cars[7] = current_selected_price_way_cars[7] + 1
												if current_selected_price_way_cars[7] == 2 then
													if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][7].crprices ~= nil and L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][7].crprices[1] ~= nil then
														Fillshoppingcar_window()
													else
														current_selected_price_way_cars[7] = current_selected_price_way_cars[7] + 1
														Fillshoppingcar_window()
													end
												end
											end
										elseif current_selected_price_way_cars[7] == 2 then
											if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][7].crprices ~= nil and L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][7].crprices[1] ~= nil then
												Fillshoppingcar_window()
											else
												current_selected_price_way_cars[7] = current_selected_price_way_cars[7] + 1
												if current_selected_price_way_cars[7] == 3 then
													if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][7].voucherprices ~= nil and L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][7].voucherprices[1] ~= nil then
														Fillshoppingcar_window()
													else
														current_selected_price_way_cars[7] = 1
														Fillshoppingcar_window()
													end
												end
											end
										else 
											if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][7].voucherprices ~= nil and L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][7].voucherprices[1] ~= nil then
												Fillshoppingcar_window()
											else
												current_selected_price_way_cars[7] = 1
												if current_selected_price_way_cars[7] == 1 then
													if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][7].gpprices ~= nil and L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][7].gpprices[1] ~= nil then
														Fillshoppingcar_window()
													else
														current_selected_price_way_cars[7] = 2	
														Fillshoppingcar_window()
													end
												end
											end
										end
									end
								},
							},
							
							--三天
							Gui.Button "btn_three_days_buy7"
							{
								Size = Vector2(103, 26),
								Location = Vector2(9, 104),
								Text = lang:GetText("50/3天"),
								TextColor = ARGB(255, 242, 242, 242),
								HighlightTextColor = ARGB(255, 37, 37, 37),
								Font = "simhei",
								FontSize = 14,
								BackgroundColor = ARGB(255, 255, 255, 255),
								PushDown = true,
								Skin = Gui.ButtonSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_normal.dds", Vector4(10, 10, 10, 10)),
									HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_hover.dds", Vector4(10, 10, 10, 10)),
									DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_down.dds", Vector4(10, 10, 10, 10)),
									DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_normal.dds", Vector4(10, 10, 10, 10)),
								},
								EventClick = function()
									if  shoppingcar_window_ui then
										shoppingcar_window_ui.btn_three_days_buy7.PushDown = true
										shoppingcar_window_ui.btn_senven_days_buy7.PushDown = false
										shoppingcar_window_ui.btn_thirty_days_buy7.PushDown = false
										shoppingcar_window_ui.btn_forever_buy7.PushDown = false
										current_selected_price_unit_cars[7] = 1
									end
									Fillshoppingcar_window()
								end
							},

							--七天
							Gui.Button "btn_senven_days_buy7"
							{
								Size = Vector2(103, 26),
								Location = Vector2(117, 104),
								Text = lang:GetText("100/7天"),
								TextColor = ARGB(255, 242, 242, 242),
								HighlightTextColor = ARGB(255, 37, 37, 37),
								Font = "simhei",
								FontSize = 14,
								BackgroundColor = ARGB(255, 255, 255, 255),
								Skin = Gui.ButtonSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_normal.dds", Vector4(10, 10, 10, 10)),
									HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_hover.dds", Vector4(10, 10, 10, 10)),
									DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_down.dds", Vector4(10, 10, 10, 10)),
									DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_normal.dds", Vector4(10, 10, 10, 10)),
								},
								EventClick = function()
									if shoppingcar_window_ui then
										shoppingcar_window_ui.btn_three_days_buy7.PushDown = false
										shoppingcar_window_ui.btn_senven_days_buy7.PushDown = true
										shoppingcar_window_ui.btn_thirty_days_buy7.PushDown = false
										shoppingcar_window_ui.btn_forever_buy7.PushDown = false
										current_selected_price_unit_cars[7] = 2
									end
									Fillshoppingcar_window()
								end,
							},
							
							--三十天
							Gui.Button "btn_thirty_days_buy7"
							{
								Size = Vector2(103, 26),
								Location = Vector2(225, 104),
								Text = lang:GetText("500/30天"),
								TextColor = ARGB(255, 242, 242, 242),
								HighlightTextColor = ARGB(255, 37, 37, 37),
								Font = "simhei",
								FontSize = 14,
								BackgroundColor = ARGB(255, 255, 255, 255),
								Skin = Gui.ButtonSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_normal.dds", Vector4(10, 10, 10, 10)),
									HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_hover.dds", Vector4(10, 10, 10, 10)),
									DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_down.dds", Vector4(10, 10, 10, 10)),
									DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_normal.dds", Vector4(10, 10, 10, 10)),
								},
								EventClick = function()
									if shoppingcar_window_ui then
										current_selected_price_unit_cars[7] = 3
										shoppingcar_window_ui.btn_three_days_buy7.PushDown = false
										shoppingcar_window_ui.btn_senven_days_buy7.PushDown = false
										shoppingcar_window_ui.btn_thirty_days_buy7.PushDown = true
										shoppingcar_window_ui.btn_forever_buy7.PushDown = false
									end
									Fillshoppingcar_window()
								end,
							},

							--永久
							Gui.Button "btn_forever_buy7"
							{
								Size = Vector2(103, 26),
								Location = Vector2(333, 104),
								Text = lang:GetText("1000/永久"),
								TextColor = ARGB(255, 242, 242, 242),
								HighlightTextColor = ARGB(255, 37, 37, 37),
								Font = "simhei",
								FontSize = 14,
								BackgroundColor = ARGB(255, 255, 255, 255),
								Skin = Gui.ButtonSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_normal.dds", Vector4(10, 10, 10, 10)),
									HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_hover.dds", Vector4(10, 10, 10, 10)),
									DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_down.dds", Vector4(10, 10, 10, 10)),
									DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_normal.dds", Vector4(10, 10, 10, 10)),
								},
								EventClick = function()
									if shoppingcar_window_ui then
										current_selected_price_unit_cars[7] = 4
										shoppingcar_window_ui.btn_three_days_buy7.PushDown = false
										shoppingcar_window_ui.btn_senven_days_buy7.PushDown = false
										shoppingcar_window_ui.btn_thirty_days_buy7.PushDown = false
										shoppingcar_window_ui.btn_forever_buy7.PushDown = true
									end
									Fillshoppingcar_window()
								end,
							},
						},
					},
				},
				
				--余额
				Gui.Label "lbl_balance"
				{
					Size = Vector2(60, 19),
					Text = lang:GetText("余额"),
					Font = "simhei",
					FontSize = 15,
					Location = Vector2(10, 335),
					TextColor = ARGB(255, 37, 37, 37),
					--BackgroundColor = ARGB(255, 0, 0, 255),
				},
				--FC点
				Gui.Label "lbl_balance_point"
				{
					Size = Vector2(151, 21),
					--Text = lang:GetText("500FC点"),
					Font = "simhei",
					FontSize = 16,
					Location = Vector2(68, 334),
					BackgroundColor = ARGB(255, 255, 255, 255),
					TextColor = ARGB(255, 37, 37, 37),
					TextAlign = "kAlignRightMiddle",
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_box_huafei.dds", Vector4(10, 10, 10, 10)),
					},
				},
				--C币
				Gui.Label "lbl_balance_GP"
				{
					Size = Vector2(151, 21),
					Font = "simhei",
					FontSize = 16,
					Location = Vector2(68, 357),
					BackgroundColor = ARGB(255, 255, 255, 255),
					TextColor = ARGB(255, 37, 37, 37),
					TextAlign = "kAlignRightMiddle",
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_box_huafei.dds", Vector4(10, 10, 10, 10)),
					},
				},
				--抵用券
				Gui.Label "lbl_balance_ticket"
				{
					Visible = false,
					Size = Vector2(151, 21),
					--Text = lang:GetText("10抵用券"),
					Font = "simhei",
					FontSize = 16,
					Location = Vector2(68, 380),
					TextColor = ARGB(255, 37, 37, 37),
					BackgroundColor = ARGB(255, 255, 255, 255),
					TextAlign = "kAlignRightMiddle",
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_box_huafei.dds", Vector4(10, 10, 10, 10)),
					},
				},

				--花费
				Gui.Label "lbl_spend"
				{
					Size = Vector2(37, 19),
					Text = lang:GetText("花费"),
					Font = "simhei",
					FontSize = 16,
					Location = Vector2(252, 335),
					TextColor = ARGB(255, 37, 37, 37),
					--BackgroundColor = ARGB(255, 0, 0, 255),
				},
				--FC点
				Gui.Label "lbl_spend_point"
				{
					Size = Vector2(151, 21),
					--Text = lang:GetText("500FC点"),
					Font = "simhei",
					FontSize = 16,
					Location = Vector2(296, 334),
					BackgroundColor = ARGB(255, 255, 255, 255),
					TextColor = ARGB(255, 37, 37, 37),
					TextAlign = "kAlignRightMiddle",
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_box_huafei.dds", Vector4(10, 10, 10, 10)),
					},
				},
				--C币
				Gui.Label "lbl_spend_GP"
				{
					Size = Vector2(151, 21),
					Font = "simhei",
					FontSize = 16,
					Location = Vector2(296, 357),
					BackgroundColor = ARGB(255, 255, 255, 255),
					TextColor = ARGB(255, 37, 37, 37),
					TextAlign = "kAlignRightMiddle",
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_box_huafei.dds", Vector4(10, 10, 10, 10)),
					},
				},
				--抵用券
				Gui.Label "lbl_spend_ticket"
				{
					Visible = false,
					Size = Vector2(151, 21),
					--Text = lang:GetText("10抵用券"),
					Font = "simhei",
					FontSize = 16,
					Location = Vector2(296, 380),
					BackgroundColor = ARGB(255, 255, 255, 255),
					TextColor = ARGB(255, 37, 37, 37),
					TextAlign = "kAlignRightMiddle",
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_box_huafei.dds", Vector4(10, 10, 10, 10)),
					},
				},
				
				Gui.CheckBox "cbox_buy_and_equip"
				{
					Location = Vector2(32, 430),
					TextColor = ARGB(255, 207, 221, 230),
					Size = Vector2(24, 24),
					BackgroundColor = ARGB(255, 0, 0, 255),
					Check = is_buy_and_equip,
					Skin = Gui.CheckBoxSkin
					{
						OnImage = Gui.Image("LobbyUI/mail/lb_contact_checkbox_down.dds", Vector4(0, 0, 0, 0)),
						OffImage = Gui.Image("LobbyUI/mail/lb_contact_checkbox_normal.dds", Vector4(0, 0, 0, 0)),
					},
					EventCheckChanged = function()
						is_buy_and_equip = not is_buy_and_equip
					end
				},
				Gui.Label "lbl_buy_and_equip"
				{
					Size = Vector2(123, 21),
					Text = lang:GetText("购买完直接装备"),
					Font = "simhei",
					FontSize = 16,
					TextColor = ARGB(255, 37, 37, 37),
					Location = Vector2(62, 430),
				},

				--购买
				Gui.Button "btn_buy"
				{
					TextAlign = "kAlignCenterMiddle",
					Size = Vector2(104, 36),
					Location = Vector2(244, 424),
					Padding = Vector4(0, 0, 0, 6),
					Text = lang:GetText("购买"),
					TextColor = ARGB(255, 211, 211, 211),
					Font = "simhei",
					FontSize = 20,
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/lb_contact_button_normal.dds", Vector4(0, 0, 0, 0)),
						HoverImage = Gui.Image("LobbyUI/team/lb_contact_button_hover.dds", Vector4(0, 0, 0, 0)),
						DownImage = Gui.Image("LobbyUI/team/lb_contact_button_down.dds", Vector4(0, 0, 0, 0)),
						DisabledImage = Gui.Image("LobbyUI/team/lb_contact_button_normal.dds", Vector4(0, 0, 0, 0)),
					},
					EventClick = function()
						is_buy_and_equip = shoppingcar_window_ui.cbox_buy_and_equip.Check
						if shoppingcart_string ~= "" then
							if is_buy_and_equip == true then
								L_LobbyMain.Buy_Goods_Cart(ptr_cast(game.CurrentState):GetUserId(), ptr_cast(game.CurrentState):GetCharacterId(), L_LobbyMain.current_choose_class,1)
							else
								L_LobbyMain.Buy_Goods_Cart(ptr_cast(game.CurrentState):GetUserId(), ptr_cast(game.CurrentState):GetCharacterId(), L_LobbyMain.current_choose_class,0)
							end		
						end
						user_bag_ui.btn_buy_all.Enable = false
						user_bag_ui.btn_clear_all.Enable = false
						CloseShoppingCarBuyWin()
						if user_bag_info_ui then
							for i = 1, 7 do
								local ibbtn = ptr_cast(user_bag_info_ui.ctrl_ib_container:GetChildByIndex(i-1))						
								ibbtn.Selected = false
							end
						end
					end
				},
				--取消
				Gui.Button "btn_cancel"
				{
					Size = Vector2(106, 36),
					Location = Vector2(356, 424),
					Text = lang:GetText("取消"),
					TextAlign = "kAlignCenterMiddle",
					Padding = Vector4(0, 0, 0, 6),
					TextColor = ARGB(255, 211, 211, 211),
					FontSize = 20,
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/lb_contact_button_normal.dds", Vector4(0, 0, 0, 0)),
						HoverImage = Gui.Image("LobbyUI/team/lb_contact_button_hover.dds", Vector4(0, 0, 0, 0)),
						DownImage = Gui.Image("LobbyUI/team/lb_contact_button_down.dds", Vector4(0, 0, 0, 0)),
						DisabledImage = Gui.Image("LobbyUI/team/lb_contact_button_normal.dds", Vector4(0, 0, 0, 0)),
					},
					EventClick = function()
						CloseShoppingCarBuyWin()
					end
				},
			},
		},
	}
}

function CloseShoppingCarBuyWin()
	if shoppingcar_window_ui then
		shoppingcar_window_ui.root.Parent = nil
		shoppingcar_window_ui = nil
	end
	shoppingcart_string = ""
	current_selected_price_way_cars = {1, 1, 1, 1, 1, 1, 1}
	current_selected_price_unit_cars = {1, 1, 1, 1, 1, 1, 1}
	if user_bag_info_ui then
		for i = 1, 7 do
			local ibbtn = ptr_cast(user_bag_info_ui.ctrl_ib_container:GetChildByIndex(i-1))						
			ibbtn.Selected = false
		end
	end
end

--创建购物车购买界面
local function setup_shoppingcar_window(parent_window)
	--界面是否存在
	if shoppingcar_window_ui then
		shoppingcar_window_ui.root.Parent = parent_window
		Fillshoppingcar_window()
		return
	end
	--创建界面
	shoppingcar_window_ui = Gui.Create(parent_window)(shoppingcar_window)
	Fillshoppingcar_window()
end

--填充购物车购买界面
function Fillshoppingcar_window()
	if shoppingcar_window_ui then
		if L_LobbyMain.PersonalInfo_data then
			shoppingcar_window_ui.lbl_balance_point.Text = L_LobbyMain.PersonalInfo_data.newCR..lang:GetText(" FC点")
			shoppingcar_window_ui.lbl_balance_GP.Text = L_LobbyMain.PersonalInfo_data.newGP..lang:GetText(" C币")
			shoppingcar_window_ui.lbl_balance_ticket.Text = L_LobbyMain.PersonalInfo_data.newTicket..lang:GetText(" 抵用券")
		end
		shoppingcart_string = ""
		local sum1 = 0
		local sum2 = 0
		local sum3 = 0
		if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class] then	
			for i = 1,7 do
				local temp = ptr_cast(shoppingcar_window_ui.buy_all:GetChildByIndex(i-1))
				if next(L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][i]) then
					local temp1 = ptr_cast(temp:GetChildByIndex(2))
					temp1.Text = L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][i].display
					temp1 = ptr_cast(temp:GetChildByIndex(1))
					if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][i].common.type == 1 then
						temp1.Size = Vector2(99, 50)
						temp1.Location = Vector2(12, 20)
					elseif L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][i].common.type == 2 then
						temp1.Size = Vector2(42, 82)
						temp1.Location = Vector2(40, 4)
					else
						temp1.Size = Vector2(83, 78)
						temp1.Location = Vector2(20, 6)
					end
					local color = L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][i].color
					local name = L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][i].name
					if color >= 1 and color <= 8 then
						temp1.Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ibt_icon/"..name.."_"..color..".tga", Vector4(0, 0, 0, 0)),
						}
					else
						temp1.Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ibt_icon/"..name..".tga", Vector4(0, 0, 0, 0)),
						}
					end
					
					if current_selected_price_way_cars[i] == 1 then
						if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][i].gpprices == nil or L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][i].gpprices[1] == nil then
							current_selected_price_way_cars[i] = 2
						else
							shoppingcart_string = shoppingcart_string..L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][i].sid .. "," .. L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][i].common.type .. "," .. L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][i].gpprices[current_selected_price_unit_cars[i]].id .. ";"
						end
					end
					if current_selected_price_way_cars[i] == 2 then
						if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][i].crprices == nil or L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][i].crprices[1] == nil then
							current_selected_price_way_cars[i] = 3
						else
							shoppingcart_string = shoppingcart_string..L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][i].sid .. "," .. L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][i].common.type .. "," .. L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][i].crprices[current_selected_price_unit_cars[i]].id .. ";"
						end
					end	
					if current_selected_price_way_cars[i] == 3 then
						shoppingcart_string = shoppingcart_string..L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][i].sid .. "," .. L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][i].common.type .. "," .. L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][i].voucherprices[current_selected_price_unit_cars[i]].id .. ";"
					end
					if current_selected_price_way_cars[i] == 2 then
						if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][i].crprices ~= nil then
							if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][i].crprices[1] ~= nil then
								for j = 1,4 do
									temp1 = ptr_cast(temp:GetChildByIndex(j + 3))
									if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][i].crprices[j] ~= nil then
										if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][i].crprices[j].unittype + 1 == 1 then
											temp1.Text = L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][i].crprices[j].cost.."/"..unittype_way[L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][i].crprices[j].unittype + 1]
										else
											temp1.Text = L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][i].crprices[j].cost.."/"..L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][i].crprices[j].unit..unittype_way[L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][i].crprices[j].unittype + 1]
										end
										temp1.Visible = true
									else
										temp1.Visible = false
									end
								end
								local temp = ptr_cast(shoppingcar_window_ui.buy_all:GetChildByIndex(i-1))
								local temp1 = ptr_cast(temp:GetChildByIndex(3))
								local temp2 = ptr_cast(temp1:GetChildByIndex(2))
								temp2.Text = price_unit[1]
								sum1 = sum1 + L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][i].crprices[current_selected_price_unit_cars[i]].cost
							else
								current_selected_price_way_cars[i] = 1
							end
						else
							current_selected_price_way_cars[i] = 1
						end
					elseif current_selected_price_way_cars[i] == 1 then
						if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][i].gpprices ~= nil then
							if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][i].gpprices[1] ~= nil then
								for j = 1,4 do
									temp1 = ptr_cast(temp:GetChildByIndex(j + 3))
									if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][i].gpprices[j] ~= nil then
										if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][i].gpprices[j].unittype + 1 == 1 then
											temp1.Text = L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][i].gpprices[j].cost.."/"..unittype_way[L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][i].gpprices[j].unittype + 1]
										else
											temp1.Text = L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][i].gpprices[j].cost.."/"..L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][i].gpprices[j].unit..unittype_way[L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][i].gpprices[j].unittype + 1]
										end
										temp1.Visible = true
									else
										temp1.Visible = false
									end
								end
								local temp = ptr_cast(shoppingcar_window_ui.buy_all:GetChildByIndex(i-1))
								local temp1 = ptr_cast(temp:GetChildByIndex(3))
								local temp2 = ptr_cast(temp1:GetChildByIndex(2))
								temp2.Text = price_unit[2]
								sum2 = sum2 +L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][i].gpprices[current_selected_price_unit_cars[i]].cost
							end
						else
							current_selected_price_way_cars[i] = 3
						end
					else
						if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][i].voucherprices ~= nil then
							if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][i].voucherprices[1] ~= nil then
								for j = 1,4 do
									temp1 = ptr_cast(temp:GetChildByIndex(j + 3))
									if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][i].voucherprices[j] ~= nil then
										if L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][i].voucherprices[j].unittype + 1 == 1 then
											temp1.Text = L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][i].voucherprices[j].cost..lang:GetText("抵用券/")..unittype_way[L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][i].voucherprices[j].unittype + 1]
										else
											temp1.Text = L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][i].voucherprices[j].cost..lang:GetText("抵用券/")..L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][i].voucherprices[j].unit..unittype_way[L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][i].voucherprices[j].unittype + 1]
										end
										temp1.Visible = true
									else
										temp1.Visible = false
									end
								end
								local temp = ptr_cast(shoppingcar_window_ui.buy_all:GetChildByIndex(i-1))
								local temp1 = ptr_cast(temp:GetChildByIndex(3))
								local temp2 = ptr_cast(temp1:GetChildByIndex(2))
								temp2.Text = price_unit[3]
								sum3 = sum3 + L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][i].voucherprices[current_selected_price_unit_cars[i]].cost
							end
						else
							current_selected_price_way_cars[i] = 1
						end
					end
				else
					temp.Visible = false
				end
			end
		end
		shoppingcar_window_ui.lbl_spend_point.TextColor = ARGB(255, 37, 37, 37)
		shoppingcar_window_ui.lbl_spend_GP.TextColor = ARGB(255, 37, 37, 37)
		shoppingcar_window_ui.lbl_spend_ticket.TextColor = ARGB(255, 37, 37, 37)
		if sum1 > L_LobbyMain.PersonalInfo_data.newCR then
			shoppingcar_window_ui.lbl_spend_point.TextColor = ARGB(255, 255, 0, 0)
		end
		if sum2 > L_LobbyMain.PersonalInfo_data.newGP then
			shoppingcar_window_ui.lbl_spend_GP.TextColor = ARGB(255, 255, 0, 0)
		end
		if sum3 > L_LobbyMain.PersonalInfo_data.newTicket then
			shoppingcar_window_ui.lbl_spend_ticket.TextColor = ARGB(255, 255, 0, 0)
		end
		if L_LobbyMain.PersonalInfo_data then
			shoppingcar_window_ui.lbl_spend_point.Text = sum1..lang:GetText(" FC点")
			shoppingcar_window_ui.lbl_spend_GP.Text = sum2..lang:GetText(" C币")
			shoppingcar_window_ui.lbl_spend_ticket.Text = sum3..lang:GetText(" 抵用券")
		end
	end
end

--购买结算 送给好友 界面
local buy_and_present_window_page =
{
	Gui.Control "ctrl_bg"
	{
		Size = Vector2(1200, 900),
		Location = Vector2(200, 0),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/lb_common_black_bg.dds",Vector4(0, 0, 0, 0)),
		},
		Gui.Control "ctrl_window_root"
		{
			Size = Vector2(570, 534),
			Location = Vector2(310, 220),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_contact_bg1_01.dds", Vector4(163,163,53,53)),
			},

			Gui.Control "ctrl_window_main"
			{
				Size = Vector2(527, 462),
				Location = Vector2(21, 46),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_contact_bg2.dds", Vector4(21, 25, 21, 46)),
				},
					
				--物品图片
				Gui.Control "ctrl_goods_image_root"
				{
					Size = Vector2(169, 156),
					Location = Vector2(17, 35),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_trading_box_01.dds", Vector4(10, 10, 10, 10)),
					},
					Gui.Control "ctrl_goods_image"
					{
						Dock = "kDockCenter",
						BackgroundColor = ARGB(255, 255, 255, 255),
					},
				},

				--物品名称
				Gui.Label "lbl_goods_name"
				{
					Size = Vector2(302, 20),
					Text = lang:GetText("物品名称"),
					Font = "simhei",
					FontSize = 18,
					Location = Vector2(180, 50),
					TextAlign = "kAlignCenterMiddle",
					TextColor = ARGB(255, 37, 37, 37),
					--BackgroundColor = ARGB(255, 0, 0, 255),
				},

				--物品用途
				Gui.TextArea "lbl_goods_info"
				{
					Size = Vector2(302, 131),
					Text = lang:GetText("物品用途"),
					FontSize = 16,
					Location = Vector2(204, 76),
					TextColor = ARGB(255, 37, 37, 37),
					Readonly = true,
					Fold = true,
					HScrollBarDisplay = "kHide",
					VScrollBarDisplay = "kAuto",							
					Skin = Gui.TextAreaSkin
					{
						UpButtonNormalImage = nil,
						UpButtonHoverImage = nil,
						UpButtonDownImage = nil,
						UpButtonDisabledImage = nil,

						DownButtonNormalImage = nil,
						DownButtonHoverImage = nil,
						DownButtonDownImage = nil,
						DownButtonDisabledImage = nil,

						VSliderNormalImage = Gui.Image("LobbyUI/team/lb_squad_scrollbar_button_normal.dds", Vector4(5, 5, 5, 5)),
						VSliderHoverImage = Gui.Image("LobbyUI/team/lb_squad_scrollbar_button_hover.dds", Vector4(5, 5, 5, 5)),
						VSliderDownImage = Gui.Image("LobbyUI/team/lb_squad_scrollbar_button_down.dds", Vector4(5, 5, 5, 5)),
						VSliderDisabledImage = Gui.Image("DLobbyUI/team/lb_squad_scrollbar_button_normal.dds", Vector4(5, 5, 5, 5)),

						VBarBackgroundImage = Gui.Image("LobbyUI/lb_common_scrollbar02_bg.dds", Vector4(0, 0, 0, 0)),
						BarCornerImage = nil,
					},
				},

				--结算方式
				Gui.Control "ctrl_balance_mode"
				{
					Size = Vector2(493, 92),
					Location = Vector2(15, 233),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_box4_jiaoyi.dds", Vector4(10, 10, 10, 10)),
					},
					
					--结算方式
					Gui.Control "ctrl_balance_mode_bg"
					{
						Size = Vector2(484, 38),
						Location = Vector2(5, 6),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Visible = true,
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_line4.dds", Vector4(10, 10, 10, 10)),
						},
						
						--赠送给
						Gui.Label "lbl_present_to"
						{
							Size = Vector2(68, 23),
							Text = lang:GetText("赠送给"),
							Font = "simhei",
							FontSize = 16,
							Visible = false,
							Location = Vector2(3, 6),
							TextColor = ARGB(255, 37, 37, 37),
							--BackgroundColor = ARGB(255, 255, 255, 255),
						},
						
						-- 好友列表
						-- Gui.ComboBox "cbx_friends_present"
						-- {
							-- Size = Vector2(80, 28),
							-- Readonly = true,
							-- TextColor = ARGB(255, 37, 37, 37),
							-- Location = Vector2(63, 3),
							-- Text = lang:GetText("请选择一位好友"),
							-- Visible = false,
							-- Skin = Gui.ComboBoxSkin
							-- {
								-- ButtonNormalImage= Gui.Image("LobbyUI/mail/lb_squad_combobox_button2_normal.dds", Vector4(0, 0, 0, 0)),
								-- ButtonHoverImage = Gui.Image("LobbyUI/mail/lb_squad_combobox_button2_hover.dds", Vector4(0, 0, 0, 0)),
								-- ButtonDownImage = Gui.Image("LobbyUI/mail/lb_squad_combobox_button2_down.dds", Vector4(0, 0, 0, 0)),
								
								-- TextNormalImage= Gui.Image("LobbyUI/mail/lb_squad_combobox2_text.dds", Vector4(6, 0, 0, 0)),
								-- TextHoverImage = Gui.Image("LobbyUI/mail/lb_squad_combobox2_text.dds", Vector4(6, 0, 0, 0)),
								-- TextDownImage = Gui.Image("LobbyUI/mail/lb_squad_combobox2_text.dds", Vector4(6, 0, 0, 0)),								
							-- },
							-- ChildComboListStyle =  "Gui.teamComboList",
							
							-- EventItemSelected = function(sender, e)
								-- current_select_firend_index = sender.SelectedIndex
								-- Player_List.Friend.PushDown = true
								-- Player_List.Partner.PushDown = false
								-- Player_List.Zhandui.PushDown = false
								-- Player_List.Channel_Player.PushDown = false
								
								-- isFriend = true
								-- isPartner = false
								-- isZhandui = false
								-- isChannel = false
							-- end
						-- },
						
						Gui.Textbox "cbx_friends_present"
						{
							Text = "",
							TextColor = ARGB(255, 37, 37, 37),
							FontSize = 12,
							Readonly = true,
							Location = Vector2(73, 3),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Size = Vector2(150, 30),
							Visible = false,
							Skin = Gui.TextboxSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_squad_combobox3_text.dds", Vector4(6,6, 6, 6)),
							},
						},

						Gui.Button "play_list"
						{
							Size = Vector2(80, 26),
							Location = Vector2(230, 5),
							Text = lang:GetText("玩家列表"),
							TextColor = ARGB(255, 0, 0, 0),
							HighlightTextColor = ARGB(255, 0, 0, 0),
							FontSize = 12,
							TextAlign = "kAlignCenterMiddle",
							Visible = false,
							Skin = Gui.ButtonSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button04_normal.dds", Vector4(5, 5, 5, 5)),
								HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button04_hover.dds", Vector4(5, 5, 5, 5)),
								DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button04_down.dds", Vector4(5, 5, 5, 5)),
								DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button04_normal.tga", Vector4(5, 5, 5, 5)),			
							},
							EventClick = function()
								setup_player_list()
								FillFriendsList()
								Player_List.Friend.PushDown = true
								Player_List.Partner.PushDown = false
								Player_List.Zhandui.PushDown = false
								Player_List.Channel_Player.PushDown = false
								
								isFriend = true
								isPartner = false
								isZhandui = false
								isChannel = false
							end
						},
						
						--结算方式
						Gui.Label "lbl_balance_mode"
						{
							Size = Vector2(80, 24),
							Text = lang:GetText("结算方式"),
							FontSize = 16,
							Location = Vector2(208, 5),
							TextAlign = "kAlignCenterMiddle",
							TextColor = ARGB(255, 37, 37, 37),
						},

						--上一种结算方式
						Gui.Button "btn_front_page"
						{
							Visible = false,
							Size = Vector2(20, 20),
							Location = Vector2(213, 7),
							--Text = "<",
							TextColor = ARGB(255, 191, 189, 184),
							FontSize = 16,
							Skin = Gui.ButtonSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button08_normal.dds", Vector4(8, 8, 8, 8)),
								HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button08_hover.dds", Vector4(8, 8, 8, 8)),
								DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button08_down.dds", Vector4(8, 8, 8, 8)),
								DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button08_normal.dds", Vector4(8, 8, 8, 8)),
							},
							EventClick = function()
								buy_and_present_ui.lbl_spend_point.TextColor = ARGB(255, 37, 37, 37)
								buy_and_present_ui.lbl_spend_GP.TextColor = ARGB(255, 37, 37, 37)
								buy_and_present_ui.lbl_spend_ticket.TextColor = ARGB(255, 37, 37, 37)
								if buy_and_present_ui then
									if L_LobbyMain.ShoppingMallIB_rpc_data then
										local weapon_info = L_LobbyMain.ShoppingMallIB_rpc_data.items[current_selected_ibtn_index]
										if weapon_info then
											--付款方式
											local mode1 = weapon_info.crprices
											local mode2 = weapon_info.gpprices
											local mode3 = weapon_info.voucherprices
											local ncount = current_selected_price_way
											ncount = ncount - 1
											
											buy_and_present_ui.btn_three_days.PushDown = false
											buy_and_present_ui.btn_senven_days.PushDown = false
											buy_and_present_ui.btn_thirty_days.PushDown = false
											buy_and_present_ui.btn_forever.PushDown = false
											cost_mode = 1
											
											local flag = true
											while flag do
												if ncount == 0 then
													ncount = 3
												end												

												if ncount == 1 then
													if mode1[1] then
														if  L_LobbyMain.ShoppingMallIB_rpc_data.items[current_selected_ibtn_index].crprices[cost_mode].cost > L_LobbyMain.PersonalInfo_data.newCR then
															buy_and_present_ui.lbl_spend_point.TextColor = ARGB(255, 255, 0, 0)
														end
														buy_and_present_ui.lbl_spend_point.Text = L_LobbyMain.ShoppingMallIB_rpc_data.items[current_selected_ibtn_index].crprices[cost_mode].cost .. " " .. price_way[1]
														buy_and_present_ui.lbl_spend_GP.Text = "0 " .. price_way[2]
														buy_and_present_ui.lbl_spend_ticket.Text = "0 " .. price_way[3]
														current_selected_price_way = 1
														flag = false
														if mode1[1].unittype == 0 then
															buy_and_present_ui.btn_three_days.Text = unittype_way[mode1[1].unittype + 1]
														else
															buy_and_present_ui.btn_three_days.Text = mode1[1].unit..unittype_way[mode1[1].unittype + 1]
														end
														buy_and_present_ui.btn_three_days.Visible = true
														buy_and_present_ui.btn_three_days.PushDown = true
													else
														buy_and_present_ui.btn_three_days.Visible = false
														buy_and_present_ui.btn_three_days.PushDown = false
													end

													if mode1[2] then
														if mode1[2].unittype == 0 then
															buy_and_present_ui.btn_senven_days.Text = unittype_way[mode1[2].unittype + 1]
														else
															buy_and_present_ui.btn_senven_days.Text = mode1[2].unit..unittype_way[mode1[2].unittype + 1]
														end
														buy_and_present_ui.btn_senven_days.Visible = true
													else
														buy_and_present_ui.btn_senven_days.Visible = false
														buy_and_present_ui.btn_senven_days.PushDown = false
													end

													if mode1[3] then
														if mode1[2].unittype == 0 then
															buy_and_present_ui.btn_thirty_days.Text = unittype_way[mode1[3].unittype + 1]
														else
															buy_and_present_ui.btn_thirty_days.Text = mode1[3].unit..unittype_way[mode1[3].unittype + 1]
														end
														buy_and_present_ui.btn_thirty_days.Visible = true
													else
														buy_and_present_ui.btn_thirty_days.Visible = false
														buy_and_present_ui.btn_thirty_days.PushDown = false
													end

													if mode1[4] then
														if mode1[4].unittype == 0 then
															buy_and_present_ui.btn_forever.Text = unittype_way[mode1[4].unittype + 1]
														else
															buy_and_present_ui.btn_forever.Text = mode1[1].unit..unittype_way[mode1[4].unittype + 1]
														end
														buy_and_present_ui.btn_forever.Visible = true
													else
														buy_and_present_ui.btn_forever.Visible = false
														buy_and_present_ui.btn_forever.PushDown = false
													end
												
												end

												if ncount == 2 then
													if mode2[1] then
														buy_and_present_ui.lbl_spend_point.Text = "0 " .. price_way[1]
														if  L_LobbyMain.ShoppingMallIB_rpc_data.items[current_selected_ibtn_index].gpprices[cost_mode].cost > L_LobbyMain.PersonalInfo_data.newGP then
															buy_and_present_ui.lbl_spend_GP.TextColor = ARGB(255, 255, 0, 0)
														end
														buy_and_present_ui.lbl_spend_GP.Text = L_LobbyMain.ShoppingMallIB_rpc_data.items[current_selected_ibtn_index].gpprices[cost_mode].cost .. " " .. price_way[2]
														buy_and_present_ui.lbl_spend_ticket.Text = "0 " .. price_way[3]
														current_selected_price_way = 2
														flag = false
														if mode2[1].unittype == 0 then
															buy_and_present_ui.btn_three_days.Text = unittype_way[mode2[1].unittype + 1]
														else
															buy_and_present_ui.btn_three_days.Text = mode2[1].unit..unittype_way[mode2[1].unittype + 1]
														end
														buy_and_present_ui.btn_three_days.Visible = true
														buy_and_present_ui.btn_three_days.PushDown = true
													else
														buy_and_present_ui.btn_three_days.Visible = false
														buy_and_present_ui.btn_three_days.PushDown = false
													end

													if mode2[2] then
														if mode2[2].unittype == 0 then
															buy_and_present_ui.btn_senven_days.Text = unittype_way[mode2[2].unittype + 1]
														else
															buy_and_present_ui.btn_senven_days.Text = mode2[2].unit..unittype_way[mode2[2].unittype + 1]
														end
														buy_and_present_ui.btn_senven_days.Visible = true
													else
														buy_and_present_ui.btn_senven_days.Visible = false
														buy_and_present_ui.btn_senven_days.PushDown = false
													end

													if mode2[3] then
														if mode2[2].unittype == 0 then
															buy_and_present_ui.btn_thirty_days.Text = unittype_way[mode2[3].unittype + 1]
														else
															buy_and_present_ui.btn_thirty_days.Text = mode2[3].unit..unittype_way[mode2[3].unittype + 1]
														end
														buy_and_present_ui.btn_thirty_days.Visible = true
													else
														buy_and_present_ui.btn_thirty_days.Visible = false
														buy_and_present_ui.btn_thirty_days.PushDown = false
													end

													if mode2[4] then
														if mode2[4].unittype == 0 then
															buy_and_present_ui.btn_forever.Text = unittype_way[mode2[4].unittype + 1]
														else
															buy_and_present_ui.btn_forever.Text = mode2[4].unit..unittype_way[mode2[4].unittype + 1]
														end
														buy_and_present_ui.btn_forever.Visible = true
													else
														buy_and_present_ui.btn_forever.Visible = false
														buy_and_present_ui.btn_forever.PushDown = false
													end
													
												end

												if ncount ==3 then
													if mode3[1] then
														buy_and_present_ui.lbl_spend_point.Text = "0 " .. price_way[1]
														buy_and_present_ui.lbl_spend_GP.Text = "0 " .. price_way[2]
														if  L_LobbyMain.ShoppingMallIB_rpc_data.items[current_selected_ibtn_index].voucherprices[cost_mode].cost > L_LobbyMain.PersonalInfo_data.newTicket then
															buy_and_present_ui.lbl_spend_ticket.TextColor = ARGB(255, 255, 0, 0)
														end
														buy_and_present_ui.lbl_spend_ticket.Text = L_LobbyMain.ShoppingMallIB_rpc_data.items[current_selected_ibtn_index].voucherprices[cost_mode].cost .. " " .. price_way[3]
														current_selected_price_way = 3
														flag = false
														if mode3[1].unittype == 0 then
															buy_and_present_ui.btn_three_days.Text = unittype_way[mode3[1].unittype + 1]
														else
															buy_and_present_ui.btn_three_days.Text = mode3[1].unit..unittype_way[mode3[1].unittype + 1]
														end
														buy_and_present_ui.btn_three_days.Visible = true
														buy_and_present_ui.btn_three_days.PushDown = true
													else
														buy_and_present_ui.btn_three_days.Visible = false
														buy_and_present_ui.btn_three_days.PushDown = false
													end

													if mode3[2] then
														if mode3[2].unittype == 0 then
															buy_and_present_ui.btn_senven_days.Text = unittype_way[mode3[2].unittype + 1]
														else
															buy_and_present_ui.btn_senven_days.Text = mode3[2].unit..unittype_way[mode3[2].unittype + 1]
														end
														buy_and_present_ui.btn_senven_days.Visible = true
													else
														buy_and_present_ui.btn_senven_days.Visible = false
														buy_and_present_ui.btn_senven_days.PushDown = false
													end

													if mode3[3] then
														if mode3[2].unittype == 0 then
															buy_and_present_ui.btn_thirty_days.Text = unittype_way[mode3[3].unittype + 1]
														else
															buy_and_present_ui.btn_thirty_days.Text = mode3[3].unit..unittype_way[mode3[3].unittype + 1]
														end
														buy_and_present_ui.btn_thirty_days.Visible = true
													else
														buy_and_present_ui.btn_thirty_days.Visible = false
														buy_and_present_ui.btn_thirty_days.PushDown = false
													end

													if mode3[4] then
														if mode3[4].unittype == 0 then
															buy_and_present_ui.btn_forever.Text = unittype_way[mode3[4].unittype + 1]
														else
															buy_and_present_ui.btn_forever.Text = mode3[4].unit..unittype_way[mode3[4].unittype + 1]
														end
														buy_and_present_ui.btn_forever.Visible = true
													else
														buy_and_present_ui.btn_forever.Visible = false
														buy_and_present_ui.btn_forever.PushDown = false
													end
													
												end
												ncount = ncount - 1
											end
											buy_and_present_ui.lb_page_number.Text = price_way[current_selected_price_way]
										end
									end
								end
							end
						},

						--FC点结算
						Gui.Label "lb_page_number"
						{
							Location = Vector2(286, 8),
							Size = Vector2(58, 20),
							FontSize = 16,
							TextAlign = "kAlignCenterMiddle",
							TextColor = ARGB(255, 37, 37, 37),
							Text = lang:GetText("FC点"),
						},

						--下一种结算方式
						Gui.Button "btn_next_page"
						{
							Visible = false,
							Size = Vector2(20, 20),
							Location = Vector2(317, 7),
							TextColor = ARGB(255, 191, 189, 184),
							FontSize = 16,
							Skin = Gui.ButtonSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button09_normal.dds", Vector4(8, 8, 8, 8)),
								HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button09_hover.dds", Vector4(8, 8, 8, 8)),
								DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button09_down.dds", Vector4(8, 8, 8, 8)),
								DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button09_normal.dds", Vector4(8, 8, 8, 8)),
							},
							EventClick = function()
								buy_and_present_ui.lbl_spend_point.TextColor = ARGB(255, 37, 37, 37)
								buy_and_present_ui.lbl_spend_GP.TextColor = ARGB(255, 37, 37, 37)
								buy_and_present_ui.lbl_spend_ticket.TextColor = ARGB(255, 37, 37, 37)
								if buy_and_present_ui then
									if L_LobbyMain.ShoppingMallIB_rpc_data then
										local weapon_info = L_LobbyMain.ShoppingMallIB_rpc_data.items[current_selected_ibtn_index]
										if weapon_info then
											--付款方式
											local mode1 = weapon_info.crprices
											local mode2 = weapon_info.gpprices
											local mode3 = weapon_info.voucherprices
											local ncount = current_selected_price_way
											ncount = ncount + 1
											
											buy_and_present_ui.btn_three_days.PushDown = false
											buy_and_present_ui.btn_senven_days.PushDown = false
											buy_and_present_ui.btn_thirty_days.PushDown = false
											buy_and_present_ui.btn_forever.PushDown = false
											cost_mode = 1

											local flag = true
											while flag do
												if ncount == 4 then
													ncount = 1
												end

												if ncount == 1 then
													if mode1[1] then
														if  L_LobbyMain.ShoppingMallIB_rpc_data.items[current_selected_ibtn_index].crprices[cost_mode].cost > L_LobbyMain.PersonalInfo_data.newCR then
															buy_and_present_ui.lbl_spend_point.TextColor = ARGB(255, 255, 0, 0)
														end
														buy_and_present_ui.lbl_spend_point.Text = L_LobbyMain.ShoppingMallIB_rpc_data.items[current_selected_ibtn_index].crprices[cost_mode].cost .. " " .. price_way[1]
														buy_and_present_ui.lbl_spend_GP.Text = "0 " .. price_way[2]
														buy_and_present_ui.lbl_spend_ticket.Text = "0 " .. price_way[3]
														current_selected_price_way = 1
														flag = false
														if mode1[1].unittype == 0 then
															buy_and_present_ui.btn_three_days.Text = unittype_way[mode1[1].unittype + 1]
														else
															buy_and_present_ui.btn_three_days.Text = mode1[1].unit..unittype_way[mode1[1].unittype + 1]
														end
														buy_and_present_ui.btn_three_days.Visible = true
														buy_and_present_ui.btn_three_days.PushDown = true
													else
														buy_and_present_ui.btn_three_days.Visible = false
														buy_and_present_ui.btn_three_days.PushDown = false
													end

													if mode1[2] then
														if mode1[2].unittype == 0 then
															buy_and_present_ui.btn_senven_days.Text = unittype_way[mode1[2].unittype + 1]
														else
															buy_and_present_ui.btn_senven_days.Text = mode1[2].unit..unittype_way[mode1[2].unittype + 1]
														end
														buy_and_present_ui.btn_senven_days.Visible = true
													else
														buy_and_present_ui.btn_senven_days.Visible = false
														buy_and_present_ui.btn_senven_days.PushDown = false
													end

													if mode1[3] then
														if mode1[2].unittype == 0 then
															buy_and_present_ui.btn_thirty_days.Text = unittype_way[mode1[3].unittype + 1]
														else
															buy_and_present_ui.btn_thirty_days.Text = mode1[3].unit..unittype_way[mode1[3].unittype + 1]
														end
														buy_and_present_ui.btn_thirty_days.Visible = true
													else
														buy_and_present_ui.btn_thirty_days.Visible = false
														buy_and_present_ui.btn_thirty_days.PushDown = false
													end

													if mode1[4] then
														if mode1[4].unittype == 0 then
															buy_and_present_ui.btn_forever.Text = unittype_way[mode1[4].unittype + 1]
														else
															buy_and_present_ui.btn_forever.Text = mode1[1].unit..unittype_way[mode1[4].unittype + 1]
														end
														buy_and_present_ui.btn_forever.Visible = true
													else
														buy_and_present_ui.btn_forever.Visible = false
														buy_and_present_ui.btn_forever.PushDown = false
													end
													
												end

												if ncount == 2 then
													if mode2[1] then
														buy_and_present_ui.lbl_spend_point.Text = "0 " .. price_way[1]
														if  L_LobbyMain.ShoppingMallIB_rpc_data.items[current_selected_ibtn_index].gpprices[cost_mode].cost > L_LobbyMain.PersonalInfo_data.newGP then
															buy_and_present_ui.lbl_spend_GP.TextColor = ARGB(255, 255, 0, 0)
														end
														buy_and_present_ui.lbl_spend_GP.Text = L_LobbyMain.ShoppingMallIB_rpc_data.items[current_selected_ibtn_index].gpprices[cost_mode].cost .. " " .. price_way[2]
														buy_and_present_ui.lbl_spend_ticket.Text = "0 " .. price_way[3]
														current_selected_price_way = 2
														flag = false
														if mode2[1].unittype == 0 then
															buy_and_present_ui.btn_three_days.Text = unittype_way[mode2[1].unittype + 1]
														else
															buy_and_present_ui.btn_three_days.Text = mode2[1].unit..unittype_way[mode2[1].unittype + 1]
														end
														buy_and_present_ui.btn_three_days.Visible = true
														buy_and_present_ui.btn_three_days.PushDown = true
													else
														buy_and_present_ui.btn_three_days.Visible = false
														buy_and_present_ui.btn_three_days.PushDown = false
													end

													if mode2[2] then
														if mode2[2].unittype == 0 then
															buy_and_present_ui.btn_senven_days.Text = unittype_way[mode2[2].unittype + 1]
														else
															buy_and_present_ui.btn_senven_days.Text = mode2[2].unit..unittype_way[mode2[2].unittype + 1]
														end
														buy_and_present_ui.btn_senven_days.Visible = true
													else
														buy_and_present_ui.btn_senven_days.Visible = false
														buy_and_present_ui.btn_senven_days.PushDown = false
													end

													if mode2[3] then
														if mode2[2].unittype == 0 then
															buy_and_present_ui.btn_thirty_days.Text = unittype_way[mode2[3].unittype + 1]
														else
															buy_and_present_ui.btn_thirty_days.Text = mode2[3].unit..unittype_way[mode2[3].unittype + 1]
														end
														buy_and_present_ui.btn_thirty_days.Visible = true
													else
														buy_and_present_ui.btn_thirty_days.Visible = false
														buy_and_present_ui.btn_thirty_days.PushDown = false
													end

													if mode2[4] then
														if mode2[4].unittype == 0 then
															buy_and_present_ui.btn_forever.Text = unittype_way[mode2[4].unittype + 1]
														else
															buy_and_present_ui.btn_forever.Text = mode2[4].unit..unittype_way[mode2[4].unittype + 1]
														end
														buy_and_present_ui.btn_forever.Visible = true
													else
														buy_and_present_ui.btn_forever.Visible = false
														buy_and_present_ui.btn_forever.PushDown = false
													end
													
												end

												if ncount ==3 then
													if mode3[1] then
														buy_and_present_ui.lbl_spend_point.Text = "0 " .. price_way[1]
														buy_and_present_ui.lbl_spend_GP.Text = "0 " .. price_way[2]
														if  L_LobbyMain.ShoppingMallIB_rpc_data.items[current_selected_ibtn_index].voucherprices[cost_mode].cost > L_LobbyMain.PersonalInfo_data.newTicket then
															buy_and_present_ui.lbl_spend_ticket.TextColor = ARGB(255, 255, 0, 0)
														end
														buy_and_present_ui.lbl_spend_ticket.Text = L_LobbyMain.ShoppingMallIB_rpc_data.items[current_selected_ibtn_index].voucherprices[cost_mode].cost .. " " .. price_way[3]
														current_selected_price_way = 3
														flag = false
														if mode3[1].unittype == 0 then
															buy_and_present_ui.btn_three_days.Text = unittype_way[mode3[1].unittype + 1]
														else
															buy_and_present_ui.btn_three_days.Text = mode3[1].unit..unittype_way[mode3[1].unittype + 1]
														end
														buy_and_present_ui.btn_three_days.Visible = true
														buy_and_present_ui.btn_three_days.PushDown = true
													else
														buy_and_present_ui.btn_three_days.Visible = false
														buy_and_present_ui.btn_three_days.PushDown = false
													end

													if mode3[2] then
														if mode3[2].unittype == 0 then
															buy_and_present_ui.btn_senven_days.Text = unittype_way[mode3[2].unittype + 1]
														else
															buy_and_present_ui.btn_senven_days.Text = mode3[2].unit..unittype_way[mode3[2].unittype + 1]
														end
														buy_and_present_ui.btn_senven_days.Visible = true
													else
														buy_and_present_ui.btn_senven_days.Visible = false
														buy_and_present_ui.btn_senven_days.PushDown = false
													end

													if mode3[3] then
														if mode3[2].unittype == 0 then
															buy_and_present_ui.btn_thirty_days.Text = unittype_way[mode3[3].unittype + 1]
														else
															buy_and_present_ui.btn_thirty_days.Text = mode3[3].unit..unittype_way[mode3[3].unittype + 1]
														end
														buy_and_present_ui.btn_thirty_days.Visible = true
													else
														buy_and_present_ui.btn_thirty_days.Visible = false
														buy_and_present_ui.btn_thirty_days.PushDown = false
													end

													if mode3[4] then
														if mode3[4].unittype == 0 then
															buy_and_present_ui.btn_forever.Text = unittype_way[mode3[4].unittype + 1]
														else
															buy_and_present_ui.btn_forever.Text = mode3[4].unit..unittype_way[mode3[4].unittype + 1]
														end
														buy_and_present_ui.btn_forever.Visible = true
													else
														buy_and_present_ui.btn_forever.Visible = false
														buy_and_present_ui.btn_forever.PushDown = false
													end
													
												end
												ncount = ncount + 1
											end
											buy_and_present_ui.lb_page_number.Text = price_way[current_selected_price_way]
										end
									end
								end
							end
						},
					},
					
					--三天
					Gui.Button "btn_three_days"
					{
						Size = Vector2(112, 26),
						Location = Vector2(8, 54),
						Text = lang:GetText("50/3天"),
						TextColor = ARGB(255, 242, 242, 242),
						HighlightTextColor = ARGB(255, 37, 37, 37),
						Font = "simhei",
						FontSize = 16,
						BackgroundColor = ARGB(255, 255, 255, 255),
						PushDown = true,
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_normal.dds", Vector4(10, 10, 10, 10)),
							HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_hover.dds", Vector4(10, 10, 10, 10)),
							DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_down.dds", Vector4(10, 10, 10, 10)),
							DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_normal.dds", Vector4(10, 10, 10, 10)),
						},
						EventClick = function()
							buy_and_present_ui.lbl_spend_point.TextColor = ARGB(255, 37, 37, 37)
							buy_and_present_ui.lbl_spend_GP.TextColor = ARGB(255, 37, 37, 37)
							buy_and_present_ui.lbl_spend_ticket.TextColor = ARGB(255, 37, 37, 37)
							if  buy_and_present_ui then
								buy_and_present_ui.btn_three_days.PushDown = true
								buy_and_present_ui.btn_senven_days.PushDown = false
								buy_and_present_ui.btn_thirty_days.PushDown = false
								buy_and_present_ui.btn_forever.PushDown = false
								cost_mode = 1
								if current_selected_price_way == 1 then
									if  L_LobbyMain.ShoppingMallIB_rpc_data.items[current_selected_ibtn_index].crprices[cost_mode].cost > L_LobbyMain.PersonalInfo_data.newCR then
										buy_and_present_ui.lbl_spend_point.TextColor = ARGB(255, 255, 0, 0)
									end
									buy_and_present_ui.lbl_spend_point.Text = L_LobbyMain.ShoppingMallIB_rpc_data.items[current_selected_ibtn_index].crprices[cost_mode].cost .. " " .. price_way[1]
									buy_and_present_ui.lbl_spend_GP.Text = "0 " .. price_way[2]
									buy_and_present_ui.lbl_spend_ticket.Text = "0 " .. price_way[3]
								elseif current_selected_price_way == 2 then
									buy_and_present_ui.lbl_spend_point.Text = "0 " .. price_way[1]
									if  L_LobbyMain.ShoppingMallIB_rpc_data.items[current_selected_ibtn_index].gpprices[cost_mode].cost > L_LobbyMain.PersonalInfo_data.newGP then
										buy_and_present_ui.lbl_spend_GP.TextColor = ARGB(255, 255, 0, 0)
									end
									buy_and_present_ui.lbl_spend_GP.Text = L_LobbyMain.ShoppingMallIB_rpc_data.items[current_selected_ibtn_index].gpprices[cost_mode].cost .. " " .. price_way[2]
									buy_and_present_ui.lbl_spend_ticket.Text = "0 " .. price_way[3]
								elseif current_selected_price_way == 3 then
									buy_and_present_ui.lbl_spend_point.Text = "0 " .. price_way[1]
									buy_and_present_ui.lbl_spend_GP.Text = "0 " .. price_way[2]
									if  L_LobbyMain.ShoppingMallIB_rpc_data.items[current_selected_ibtn_index].voucherprices[cost_mode].cost > L_LobbyMain.PersonalInfo_data.newTicket then
										buy_and_present_ui.lbl_spend_ticket.TextColor = ARGB(255, 255, 0, 0)
									end
									buy_and_present_ui.lbl_spend_ticket.Text = L_LobbyMain.ShoppingMallIB_rpc_data.items[current_selected_ibtn_index].voucherprices[cost_mode].cost .. " " .. price_way[3]
								end
							end
						end,
					},

					--七天
					Gui.Button "btn_senven_days"
					{
						Size = Vector2(112, 26),
						Location = Vector2(128, 54),
						Text = lang:GetText("100/7天"),
						TextColor = ARGB(255, 242, 242, 242),
						HighlightTextColor = ARGB(255, 37, 37, 37),
						Font = "simhei",
						FontSize = 16,
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_normal.dds", Vector4(10, 10, 10, 10)),
							HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_hover.dds", Vector4(10, 10, 10, 10)),
							DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_down.dds", Vector4(10, 10, 10, 10)),
							DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_normal.dds", Vector4(10, 10, 10, 10)),
						},
						EventClick = function()
							buy_and_present_ui.lbl_spend_point.TextColor = ARGB(255, 37, 37, 37)
							buy_and_present_ui.lbl_spend_GP.TextColor = ARGB(255, 37, 37, 37)
							buy_and_present_ui.lbl_spend_ticket.TextColor = ARGB(255, 37, 37, 37)
							if buy_and_present_ui then
								buy_and_present_ui.btn_three_days.PushDown = false
								buy_and_present_ui.btn_senven_days.PushDown = true
								buy_and_present_ui.btn_thirty_days.PushDown = false
								buy_and_present_ui.btn_forever.PushDown = false
								cost_mode = 2
								if current_selected_price_way == 1 then
									if  L_LobbyMain.ShoppingMallIB_rpc_data.items[current_selected_ibtn_index].crprices[cost_mode].cost > L_LobbyMain.PersonalInfo_data.newCR then
										buy_and_present_ui.lbl_spend_point.TextColor = ARGB(255, 255, 0, 0)
									end
									buy_and_present_ui.lbl_spend_point.Text = L_LobbyMain.ShoppingMallIB_rpc_data.items[current_selected_ibtn_index].crprices[cost_mode].cost .. " " .. price_way[1]
									buy_and_present_ui.lbl_spend_GP.Text = "0 " .. price_way[2]
									buy_and_present_ui.lbl_spend_ticket.Text = "0 " .. price_way[3]
								elseif current_selected_price_way == 2 then
									buy_and_present_ui.lbl_spend_point.Text = "0 " .. price_way[1]
									if  L_LobbyMain.ShoppingMallIB_rpc_data.items[current_selected_ibtn_index].gpprices[cost_mode].cost > L_LobbyMain.PersonalInfo_data.newGP then
										buy_and_present_ui.lbl_spend_GP.TextColor = ARGB(255, 255, 0, 0)
									end
									buy_and_present_ui.lbl_spend_GP.Text = L_LobbyMain.ShoppingMallIB_rpc_data.items[current_selected_ibtn_index].gpprices[cost_mode].cost .. " " .. price_way[2]
									buy_and_present_ui.lbl_spend_ticket.Text = "0 " .. price_way[3]
								else
									buy_and_present_ui.lbl_spend_point.Text = "0 " .. price_way[1]
									buy_and_present_ui.lbl_spend_GP.Text = "0 " .. price_way[2]
									if  L_LobbyMain.ShoppingMallIB_rpc_data.items[current_selected_ibtn_index].voucherprices[cost_mode].cost > L_LobbyMain.PersonalInfo_data.newTicket then
										buy_and_present_ui.lbl_spend_ticket.TextColor = ARGB(255, 255, 0, 0)
									end
									buy_and_present_ui.lbl_spend_ticket.Text = L_LobbyMain.ShoppingMallIB_rpc_data.items[current_selected_ibtn_index].voucherprices[cost_mode].cost .. " " .. price_way[3]
								end
							end
						end,
					},

					--三十天
					Gui.Button "btn_thirty_days"
					{
						Size = Vector2(112, 26),
						Location = Vector2(248, 54),
						Text = lang:GetText("500/30天"),
						TextColor = ARGB(255, 242, 242, 242),
						HighlightTextColor = ARGB(255, 37, 37, 37),
						Font = "simhei",
						FontSize = 16,
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_normal.dds", Vector4(10, 10, 10, 10)),
							HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_hover.dds", Vector4(10, 10, 10, 10)),
							DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_down.dds", Vector4(10, 10, 10, 10)),
							DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_normal.dds", Vector4(10, 10, 10, 10)),
						},
						EventClick = function()
							buy_and_present_ui.lbl_spend_point.TextColor = ARGB(255, 37, 37, 37)
							buy_and_present_ui.lbl_spend_GP.TextColor = ARGB(255, 37, 37, 37)
							buy_and_present_ui.lbl_spend_ticket.TextColor = ARGB(255, 37, 37, 37)
							if buy_and_present_ui then
								cost_mode = 3
								buy_and_present_ui.btn_three_days.PushDown = false
								buy_and_present_ui.btn_senven_days.PushDown = false
								buy_and_present_ui.btn_thirty_days.PushDown = true
								buy_and_present_ui.btn_forever.PushDown = false
								if current_selected_price_way == 1 then
									if  L_LobbyMain.ShoppingMallIB_rpc_data.items[current_selected_ibtn_index].crprices[cost_mode].cost > L_LobbyMain.PersonalInfo_data.newCR then
										buy_and_present_ui.lbl_spend_point.TextColor = ARGB(255, 255, 0, 0)
									end
									buy_and_present_ui.lbl_spend_point.Text = L_LobbyMain.ShoppingMallIB_rpc_data.items[current_selected_ibtn_index].crprices[cost_mode].cost .. " " .. price_way[1]
									buy_and_present_ui.lbl_spend_GP.Text = "0 " .. price_way[2]
									buy_and_present_ui.lbl_spend_ticket.Text = "0 " .. price_way[3]
								elseif current_selected_price_way == 2 then
									buy_and_present_ui.lbl_spend_point.Text = "0 " .. price_way[1]
									if  L_LobbyMain.ShoppingMallIB_rpc_data.items[current_selected_ibtn_index].gpprices[cost_mode].cost > L_LobbyMain.PersonalInfo_data.newGP then
										buy_and_present_ui.lbl_spend_GP.TextColor = ARGB(255, 255, 0, 0)
									end
									buy_and_present_ui.lbl_spend_GP.Text = L_LobbyMain.ShoppingMallIB_rpc_data.items[current_selected_ibtn_index].gpprices[cost_mode].cost .. " " .. price_way[2]
									buy_and_present_ui.lbl_spend_ticket.Text = "0 " .. price_way[3]
								else
									buy_and_present_ui.lbl_spend_point.Text = "0 " .. price_way[1]
									buy_and_present_ui.lbl_spend_GP.Text = "0 " .. price_way[2]
									if  L_LobbyMain.ShoppingMallIB_rpc_data.items[current_selected_ibtn_index].voucherprices[cost_mode].cost > L_LobbyMain.PersonalInfo_data.newTicket then
										buy_and_present_ui.lbl_spend_ticket.TextColor = ARGB(255, 255, 0, 0)
									end
									buy_and_present_ui.lbl_spend_ticket.Text = L_LobbyMain.ShoppingMallIB_rpc_data.items[current_selected_ibtn_index].voucherprices[cost_mode].cost .. " " .. price_way[3]
								end
							end
						end,
					},

					--永久
					Gui.Button "btn_forever"
					{
						Size = Vector2(112, 26),
						Location = Vector2(368, 54),
						Text = lang:GetText("1000/永久"),
						TextColor = ARGB(255, 242, 242, 242),
						HighlightTextColor = ARGB(255, 37, 37, 37),
						Font = "simhei",
						FontSize = 16,
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_normal.dds", Vector4(10, 10, 10, 10)),
							HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_hover.dds", Vector4(10, 10, 10, 10)),
							DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_down.dds", Vector4(10, 10, 10, 10)),
							DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_normal.dds", Vector4(10, 10, 10, 10)),
						},
						EventClick = function()
							buy_and_present_ui.lbl_spend_point.TextColor = ARGB(255, 37, 37, 37)
							buy_and_present_ui.lbl_spend_GP.TextColor = ARGB(255, 37, 37, 37)
							buy_and_present_ui.lbl_spend_ticket.TextColor = ARGB(255, 37, 37, 37)
							if buy_and_present_ui then
								cost_mode = 4
								buy_and_present_ui.btn_three_days.PushDown = false
								buy_and_present_ui.btn_senven_days.PushDown = false
								buy_and_present_ui.btn_thirty_days.PushDown = false
								buy_and_present_ui.btn_forever.PushDown = true
								if current_selected_price_way == 1 then
									if  L_LobbyMain.ShoppingMallIB_rpc_data.items[current_selected_ibtn_index].crprices[cost_mode].cost > L_LobbyMain.PersonalInfo_data.newCR then
										buy_and_present_ui.lbl_spend_point.TextColor = ARGB(255, 255, 0, 0)
									end
									buy_and_present_ui.lbl_spend_point.Text = L_LobbyMain.ShoppingMallIB_rpc_data.items[current_selected_ibtn_index].crprices[cost_mode].cost .. " " .. price_way[1]
									buy_and_present_ui.lbl_spend_GP.Text = "0 " .. price_way[2]
									buy_and_present_ui.lbl_spend_ticket.Text = "0 " .. price_way[3]
								elseif current_selected_price_way == 2 then
									buy_and_present_ui.lbl_spend_point.Text = "0 " .. price_way[1]
									if  L_LobbyMain.ShoppingMallIB_rpc_data.items[current_selected_ibtn_index].gpprices[cost_mode].cost > L_LobbyMain.PersonalInfo_data.newGP then
										buy_and_present_ui.lbl_spend_GP.TextColor = ARGB(255, 255, 0, 0)
									end
									buy_and_present_ui.lbl_spend_GP.Text = L_LobbyMain.ShoppingMallIB_rpc_data.items[current_selected_ibtn_index].gpprices[cost_mode].cost .. " " .. price_way[2]
									buy_and_present_ui.lbl_spend_ticket.Text = "0 " .. price_way[3]
								else
									buy_and_present_ui.lbl_spend_point.Text = "0 " .. price_way[1]
									buy_and_present_ui.lbl_spend_GP.Text = "0 " .. price_way[2]
									if  L_LobbyMain.ShoppingMallIB_rpc_data.items[current_selected_ibtn_index].voucherprices[cost_mode].cost > L_LobbyMain.PersonalInfo_data.newTicket then
										buy_and_present_ui.lbl_spend_ticket.TextColor = ARGB(255, 255, 0, 0)
									end
									buy_and_present_ui.lbl_spend_ticket.Text = L_LobbyMain.ShoppingMallIB_rpc_data.items[current_selected_ibtn_index].voucherprices[cost_mode].cost .. " " .. price_way[3]
								end
							end
						end,
					},
				},

				--余额
				Gui.Label "lbl_balance"
				{
					Size = Vector2(60, 19),
					Text = lang:GetText("余额"),
					Font = "simhei",
					FontSize = 15,
					Location = Vector2(10, 335),
					TextColor = ARGB(255, 37, 37, 37),
					--BackgroundColor = ARGB(255, 0, 0, 255),
				},
				--FC点
				Gui.Label "lbl_balance_point"
				{
					Size = Vector2(145, 21),
					Font = "simhei",
					FontSize = 16,
					Location = Vector2(90, 334),
					BackgroundColor = ARGB(255, 255, 255, 255),
					TextColor = ARGB(255, 37, 37, 37),
					TextAlign = "kAlignRightMiddle",
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_box_huafei.dds", Vector4(10, 10, 10, 10)),
					},
				},
				--C币
				Gui.Label "lbl_balance_GP"
				{
					Size = Vector2(145, 21),
					Font = "simhei",
					FontSize = 16,
					Location = Vector2(90, 357),
					BackgroundColor = ARGB(255, 255, 255, 255),
					TextColor = ARGB(255, 37, 37, 37),
					TextAlign = "kAlignRightMiddle",
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_box_huafei.dds", Vector4(10, 10, 10, 10)),
					},
				},
				--抵用券
				Gui.Label "lbl_balance_ticket"
				{
					Visible = false,
					Size = Vector2(145, 21),
					Font = "simhei",
					FontSize = 16,
					Location = Vector2(90, 380),
					TextColor = ARGB(255, 37, 37, 37),
					BackgroundColor = ARGB(255, 255, 255, 255),
					TextAlign = "kAlignRightMiddle",
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_box_huafei.dds", Vector4(10, 10, 10, 10)),
					},
				},

				--花费
				Gui.Label "lbl_spend"
				{
					Size = Vector2(60, 19),
					Text = lang:GetText("花费"),
					Font = "simhei",
					FontSize = 16,
					Location = Vector2(270, 335),
					TextColor = ARGB(255, 37, 37, 37),
					--BackgroundColor = ARGB(255, 0, 0, 255),
				},
				--FC点
				Gui.Label "lbl_spend_point"
				{
					Size = Vector2(145, 21),
					Font = "simhei",
					FontSize = 16,
					Location = Vector2(330, 334),
					BackgroundColor = ARGB(255, 255, 255, 255),
					TextColor = ARGB(255, 37, 37, 37),
					TextAlign = "kAlignRightMiddle",
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_box_huafei.dds", Vector4(10, 10, 10, 10)),
					},
				},
				--C币
				Gui.Label "lbl_spend_GP"
				{
					Size = Vector2(145, 21),
					Font = "simhei",
					FontSize = 16,
					Location = Vector2(330, 357),
					BackgroundColor = ARGB(255, 255, 255, 255),
					TextColor = ARGB(255, 37, 37, 37),
					TextAlign = "kAlignRightMiddle",
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_box_huafei.dds", Vector4(10, 10, 10, 10)),
					},
				},
				--抵用券
				Gui.Label "lbl_spend_ticket"
				{
					Visible = false,
					Size = Vector2(145, 21),
					Font = "simhei",
					FontSize = 16,
					Location = Vector2(330, 380),
					BackgroundColor = ARGB(255, 255, 255, 255),
					TextColor = ARGB(255, 37, 37, 37),
					TextAlign = "kAlignRightMiddle",
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_box_huafei.dds", Vector4(10, 10, 10, 10)),
					},
				},

				Gui.CheckBox "cbox_buy_and_equip"
				{
					Location = Vector2(32, 430),
					TextColor = ARGB(255, 207, 221, 230),
					Size = Vector2(24, 24),
					BackgroundColor = ARGB(255, 0, 0, 255),
					Check = is_buy_and_equip,
					Skin = Gui.CheckBoxSkin
					{
						OnImage = Gui.Image("LobbyUI/mail/lb_contact_checkbox_down.dds", Vector4(0, 0, 0, 0)),
						OffImage = Gui.Image("LobbyUI/mail/lb_contact_checkbox_normal.dds", Vector4(0, 0, 0, 0)),
					},
					EventCheckChanged = function()
						is_buy_and_equip = not is_buy_and_equip
					end
				},
				Gui.Label "lbl_buy_and_equip"
				{
					Size = Vector2(140, 21),
					Text = lang:GetText("购买完直接装备"),
					Font = "simhei",
					FontSize = 16,
					TextColor = ARGB(255, 37, 37, 37),
					Location = Vector2(62, 430),
					--BackgroundColor = ARGB(255, 0, 0, 255),
				},

				--购买
				Gui.Button "btn_buy"
				{
					Size = Vector2(124, 36),
					Location = Vector2(244, 424),
					Text = lang:GetText("购买"),
					TextAlign = "kAlignCenterMiddle",
					Padding = Vector4(0, 0, 0, 6),
					TextColor = ARGB(255, 211, 211, 211),
					Font = "simhei",
					FontSize = 20,
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/lb_contact_button_normal.dds", Vector4(0, 0, 0, 0)),
						HoverImage = Gui.Image("LobbyUI/team/lb_contact_button_hover.dds", Vector4(0, 0, 0, 0)),
						DownImage = Gui.Image("LobbyUI/team/lb_contact_button_down.dds", Vector4(0, 0, 0, 0)),
						DisabledImage = Gui.Image("LobbyUI/team/lb_contact_button_normal.dds", Vector4(0, 0, 0, 0)),
					},
					EventClick = function()
						--购买
						if L_LobbyMain.ShoppingMallIB_rpc_data then
							local weapon_info = L_LobbyMain.ShoppingMallIB_rpc_data.items[current_selected_ibtn_index]							
							is_buy_and_equip = buy_and_present_ui.cbox_buy_and_equip.Check
							if weapon_info then
								if buy_and_present_ui.lbl_present_to.Visible ~= true then
									if is_buy_and_equip == true then
										if weapon_info.common.type == 1 then
										--武器
											L_LobbyMain.IsInit = 0
											L_LobbyMain.weapon_index = weapon_info.common.seq
											L_LobbyMain.ClassBagIndex_Characters[L_LobbyMain.current_choose_class] = weapon_info.common.seq
											L_LobbyMain.ClassWeaponIndex_Characters[L_LobbyMain.current_choose_class] = weapon_info.common.seq
										elseif weapon_info.common.type == 2 then
										--套装
											L_LobbyMain.ClassBagIndex_Characters[L_LobbyMain.current_choose_class] = 5
										elseif weapon_info.common.type == 3 then
										--配饰
											L_LobbyMain.ClassBagIndex_Characters[L_LobbyMain.current_choose_class] = weapon_info.common.seq + 4
										end
										RestAllShoppingMallItemBoxBtn()
										local costid = -1
										if current_selected_price_way == 1 then
											costid = weapon_info.crprices[cost_mode].id
										elseif current_selected_price_way == 2 then
											costid = weapon_info.gpprices[cost_mode].id
										elseif current_selected_price_way == 3 then
											costid = weapon_info.voucherprices[cost_mode].id
										end
										L_LobbyMain.Buy_Goods(ptr_cast(game.CurrentState):GetUserId(), ptr_cast(game.CurrentState):GetCharacterId(), weapon_info.sid, L_LobbyMain.current_shoppingmall_storage, L_LobbyMain.current_choose_class, costid, 1)
									else
										local costid = -1
										if current_selected_price_way == 1 then
											costid = weapon_info.crprices[cost_mode].id
										elseif current_selected_price_way == 2 then
											costid = weapon_info.gpprices[cost_mode].id
										elseif current_selected_price_way == 3 then
											costid = weapon_info.voucherprices[cost_mode].id
										end
										L_LobbyMain.Buy_Goods(ptr_cast(game.CurrentState):GetUserId(), ptr_cast(game.CurrentState):GetCharacterId(), weapon_info.sid, L_LobbyMain.current_shoppingmall_storage, L_LobbyMain.current_choose_class, costid, 0)
									end
								elseif buy_and_present_ui.lbl_present_to.Visible == true then
									if weapon_info.common.type == 1 then
									--武器
										L_LobbyMain.ClassBagIndex_Characters[L_LobbyMain.current_choose_class] = weapon_info.common.seq
										L_LobbyMain.ClassWeaponIndex_Characters[L_LobbyMain.current_choose_class] = weapon_info.common.seq
									elseif weapon_info.common.type == 2 then
									--套装
										L_LobbyMain.ClassBagIndex_Characters[L_LobbyMain.current_choose_class] = 5
									elseif weapon_info.common.type == 3 then
									--配饰
										L_LobbyMain.ClassBagIndex_Characters[L_LobbyMain.current_choose_class] = weapon_info.common.seq + 5
									end
									if buy_and_present_ui.cbx_friends_present.Text == "" then
										MessageBox.ShowWithConfirm(lang:GetText("请选择一个好友！"),
											function(sender,e)
											end,
										nil)
										return
									end
									if current_select_firend_index > -1 then
										local costid = -1
										if current_selected_price_way == 1 then
											costid = weapon_info.crprices[cost_mode].id
										elseif current_selected_price_way == 2 then
											costid = weapon_info.gpprices[cost_mode].id
										elseif current_selected_price_way == 3 then
											costid = weapon_info.voucherprices[cost_mode].id
										end
									
										if isFriend then
											L_LobbyMain.SendEmilGift(L_LobbyMain.Friends_rpc_data[current_select_firend_index + 1][1], weapon_info.sid, L_LobbyMain.current_shoppingmall_storage, costid)
										elseif isPartner then
											L_LobbyMain.SendEmilGift(list[current_select_firend_index + 1][1], weapon_info.sid, L_LobbyMain.current_shoppingmall_storage, costid)
										elseif isZhandui then
											if myZhanduiIndex ~= -1 then
												if current_select_firend_index > myZhanduiIndex - 1 then
													current_select_firend_index = current_select_firend_index + 1
												end
											end
											L_LobbyMain.SendEmilGift(selectedid, weapon_info.sid, L_LobbyMain.current_shoppingmall_storage, costid)
											-- L_Friends.Team_RPC_List[current_select_firend_index + 1][1]
										elseif isChannel then
											local l = L_Friends.Channel_list
											local flag = false
											while l do
												if l.name == buy_and_present_ui.cbx_friends_present.Text then
													L_LobbyMain.SendEmilGift(l.id, weapon_info.sid, L_LobbyMain.current_shoppingmall_storage, costid)
													flag = true
													break
												end
												l = l.next
											end
											if not flag then
												MessageBox.ShowWithConfirm(lang:GetText("该角色已经离开此频道!"))
											end
											-- L_LobbyMain.SendEmilGift(L_Friends.Channel_list[current_select_firend_index + 1][1], weapon_info.sid, L_LobbyMain.current_shoppingmall_storage, costid)
										end
										-- L_LobbyMain.SendEmilGift(L_LobbyMain.Friends_rpc_data[current_select_firend_index + 1][1], weapon_info.sid, L_LobbyMain.current_shoppingmall_storage, costid)
									end
								end
							end
						end	
						if buy_and_present_ui.lbl_present_to.Visible == true and current_select_firend_index == -1 then
							return
						end						
						CloseBuyWin()
					end
				},
				--取消
				Gui.Button "btn_cancel"
				{
					Size = Vector2(124, 36),
					Location = Vector2(376, 424),
					Text = lang:GetText("取消"),
					TextAlign = "kAlignCenterMiddle",
					Padding = Vector4(0, 0, 0, 6),
					TextColor = ARGB(255, 211, 211, 211),
					FontSize = 20,
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/lb_contact_button_normal.dds", Vector4(0, 0, 0, 0)),
						HoverImage = Gui.Image("LobbyUI/team/lb_contact_button_hover.dds", Vector4(0, 0, 0, 0)),
						DownImage = Gui.Image("LobbyUI/team/lb_contact_button_down.dds", Vector4(0, 0, 0, 0)),
						DisabledImage = Gui.Image("LobbyUI/team/lb_contact_button_normal.dds", Vector4(0, 0, 0, 0)),
					},
					EventClick = function()
						CloseBuyWin()
					end
				},
			},
			
			--购买结算
			Gui.Button "btn_buy_and_balance"
			{
				Size = Vector2(165, 34),
				Location = Vector2(35, 15.5),
				Text = lang:GetText("购买结算"),
				TextColor = ARGB(255, 0, 0, 0),
				HighlightTextColor = ARGB(255, 0, 0, 0),
				Font = "simhei",
				FontSize = 16,
				PushDown = true,
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_tab1_normal.dds", Vector4(10, 0, 10, 0)),
					HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_contact_tab1_hover.dds", Vector4(10, 0, 10, 0)),
					DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_contact_tab1_down.dds", Vector4(10, 0, 10, 0)),
					DisabledImage = Gui.Image("LobbyUI/Friends/lb_contact_tab1_normal.dds", Vector4(10, 0, 10, 0)),
				},
				EventClick = function()
					if buy_and_present_ui then
						--buy_and_present_ui.lbl_spend_point.Text = L_LobbyMain.ShoppingMallIB_rpc_data.items[current_selected_ibtn_index].gpprices[cost_mode].cost..lang:GetText("C币")
						buy_and_present_ui.btn_buy_and_balance.PushDown = true
						buy_and_present_ui.btn_buy_and_present.PushDown = false
						buy_and_present_ui.btn_buy.Text = lang:GetText("购买")
						buy_and_present_ui.lbl_present_to.Visible = false
						buy_and_present_ui.cbx_friends_present.Visible = false
						buy_and_present_ui.lbl_balance_mode.Location = Vector2(140, 5)
						buy_and_present_ui.btn_front_page.Location = Vector2(213, 7)
						buy_and_present_ui.lb_page_number.Location = Vector2(246, 8)
						buy_and_present_ui.btn_next_page.Location = Vector2(317, 7)
						local weapon_info = L_LobbyMain.ShoppingMallIB_rpc_data.items[current_selected_ibtn_index]
						if weapon_info.common.type < 4 then
							buy_and_present_ui.cbox_buy_and_equip.Visible = true
							buy_and_present_ui.lbl_buy_and_equip.Visible = true
						else
							buy_and_present_ui.cbox_buy_and_equip.Visible = false
							buy_and_present_ui.lbl_buy_and_equip.Visible = false
						end
					end
					buy_and_present_ui.btn_three_days.PushDown = true
					buy_and_present_ui.btn_senven_days.PushDown = false
					buy_and_present_ui.btn_thirty_days.PushDown = false
					buy_and_present_ui.btn_forever.PushDown = false
					buy_and_present_ui.play_list.Visible = false
					FillBuyAndPresentWindow()
				end
			},

			--送给好友
			Gui.Button "btn_buy_and_present"
			{
				Size = Vector2(165, 34),
				Location = Vector2(200, 15.5),
				Text = lang:GetText("送给好友"),
				TextColor = ARGB(255, 0, 0, 0),
				HighlightTextColor = ARGB(255, 0, 0, 0),
				Font = "simhei",
				FontSize = 16,
				PushDown = false,
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_tab1_normal.dds", Vector4(10, 0, 10, 0)),
					HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_contact_tab1_hover.dds", Vector4(10, 0, 10, 0)),
					DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_contact_tab1_down.dds", Vector4(10, 0, 10, 0)),
					DisabledImage = Gui.Image("LobbyUI/Friends/lb_contact_tab1_normal.dds", Vector4(10, 0, 10, 0)),
				},
				EventClick = function()
					if buy_and_present_ui then
						buy_and_present_ui.lbl_present_to.Visible = true
						buy_and_present_ui.cbx_friends_present.Visible = true
						buy_and_present_ui.lbl_balance_mode.Location = Vector2(306, 6)
						buy_and_present_ui.btn_front_page.Location = Vector2(323, 7)
						buy_and_present_ui.lb_page_number.Location = Vector2(386, 6)
						buy_and_present_ui.btn_next_page.Location = Vector2(408, 7)
						
						buy_and_present_ui.lbl_spend_point.Text = ""
						buy_and_present_ui.btn_buy_and_balance.PushDown = false
						buy_and_present_ui.btn_buy_and_present.PushDown = true
						buy_and_present_ui.cbox_buy_and_equip.Visible = false
						buy_and_present_ui.lbl_buy_and_equip.Visible = false
						buy_and_present_ui.btn_three_days.PushDown = true
						buy_and_present_ui.btn_senven_days.PushDown = false
						buy_and_present_ui.btn_thirty_days.PushDown = false
						buy_and_present_ui.btn_forever.PushDown = false
						buy_and_present_ui.btn_buy.Text = lang:GetText("赠送")
						buy_and_present_ui.play_list.Visible = true
						
						FillPresentWindow()
					end
				end
			},

			--充值
			Gui.Button "btn_add_value"
			{
				Enable = true,
				Size = Vector2(150, 32),
				Location = Vector2(380, 12),
				Text = lang:GetText("充 值"),
				TextColor = ARGB(255, 37, 37, 37),
				HighlightTextColor = ARGB(255, 37, 37, 37),
				Padding = Vector4(0, 0, 0, 3),
				FontSize = 18,
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Mission/lb_task_button01_normal.dds", Vector4(0, 0, 0, 0)),
					HoverImage = Gui.Image("LobbyUI/Mission/lb_task_button01_hover.dds", Vector4(0, 0, 0, 0)),
					DownImage = Gui.Image("LobbyUI/Mission/lb_task_button01_down.dds", Vector4(0, 0, 0, 0)),
					DisabledImage = Gui.Image("LobbyUI/Mission/lb_task_button01_disabled.dds", Vector4(0, 0, 0, 0)),
				},
				EventClick = function()
					gui:ShowIE()
				end
			},
		},
	},
}

function FillPresentWindow()
	if buy_and_present_ui then
		-- buy_and_present_ui.cbx_friends_present:RemoveAll()
		current_select_firend_index = -1
		-- for _,v in ipairs(L_LobbyMain.Friends_rpc_data) do
			-- if v[1]then
				-- buy_and_present_ui.cbx_friends_present:AddItem(v[3])
			-- end
		-- end
		buy_and_present_ui.cbx_friends_present.Text = ""
		if L_LobbyMain.ShoppingMallIB_rpc_data then
			if L_LobbyMain.PersonalInfo_data then
				--FC点
				buy_and_present_ui.lbl_balance_point.Text = L_LobbyMain.PersonalInfo_data.newCR .. " " .. price_way[1]
				--C币
				buy_and_present_ui.lbl_balance_GP.Text = L_LobbyMain.PersonalInfo_data.newGP .. " " .. price_way[2]
				--抵用券
				buy_and_present_ui.lbl_balance_ticket.Text = L_LobbyMain.PersonalInfo_data.newTicket .. " " .. price_way[3]				
			end			
			buy_and_present_ui.lbl_spend_point.Text = "0 " .. price_way[1]
			--buy_and_present_ui.lbl_spend_GP.Text = L_LobbyMain.ShoppingMallIB_rpc_data.items[current_selected_ibtn_index].gpprices[1].cost .. " " .. price_way[2]
			buy_and_present_ui.lbl_spend_GP.Text = "0 " .. price_way[2]
			buy_and_present_ui.lbl_spend_ticket.Text = "0 " .. price_way[3]
			cost_mode = 1
			
			local weapon_info = L_LobbyMain.ShoppingMallIB_rpc_data.items[current_selected_ibtn_index]			
			if weapon_info then
				if L_LobbyMain.current_shoppingmall_storage == 1 then
					buy_and_present_ui.ctrl_goods_image.Size = Vector2(128, 64)
					buy_and_present_ui.ctrl_goods_image_root.Size = Vector2(160, 156)
				elseif L_LobbyMain.current_shoppingmall_storage == 2 then
					buy_and_present_ui.ctrl_goods_image.Size = Vector2(100, 195)
					buy_and_present_ui.ctrl_goods_image_root.Size = Vector2(160, 195)
				elseif L_LobbyMain.current_shoppingmall_storage == 3 then
					buy_and_present_ui.ctrl_goods_image.Size = Vector2(100, 96)
					buy_and_present_ui.ctrl_goods_image_root.Size = Vector2(160, 156)
				else
					buy_and_present_ui.ctrl_goods_image.Size = Vector2(100, 96)
					buy_and_present_ui.ctrl_goods_image_root.Size = Vector2(160, 156)
				end
				
				local color = weapon_info.color
				local name = weapon_info.name
				if color >= 1 and color <= 8 then
					buy_and_present_ui.ctrl_goods_image.Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ibt_icon/"..name.."_"..color..".tga", Vector4(0, 0, 0, 0)),
					}
				else
					buy_and_present_ui.ctrl_goods_image.Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ibt_icon/"..name..".tga", Vector4(0, 0, 0, 0)),
					}
				end
				
				buy_and_present_ui.lbl_goods_name.Text = weapon_info.display
				buy_and_present_ui.lbl_goods_info.Text = weapon_info.description

				--付款方式
				local mode1 = weapon_info.crprices
				local mode2 = weapon_info.gpprices
				local mode3 = weapon_info.voucherprices

				--抵用券
				if mode3[1] then
					if mode3[1] then
						current_selected_price_way = 3						
						buy_and_present_ui.lbl_spend_point.Text = "0 " .. price_way[1]
						buy_and_present_ui.lbl_spend_GP.Text = "0 " .. price_way[2]
						buy_and_present_ui.lbl_spend_ticket.Text = L_LobbyMain.ShoppingMallIB_rpc_data.items[current_selected_ibtn_index].voucherprices[1].cost .. " " .. price_way[3]						
						if mode3[1].unittype == 0 then
							buy_and_present_ui.btn_three_days.Text = unittype_way[mode3[1].unittype + 1]
						else
							buy_and_present_ui.btn_three_days.Text = mode3[1].unit..unittype_way[mode3[1].unittype + 1]
						end
						buy_and_present_ui.btn_three_days.Visible = true
					else
						buy_and_present_ui.btn_three_days.Visible = false
					end

					if mode3[2] then
						if mode3[2].unittype == 0 then
							buy_and_present_ui.btn_senven_days.Text = unittype_way[mode3[2].unittype + 1]
						else
							buy_and_present_ui.btn_senven_days.Text = mode3[2].unit..unittype_way[mode3[2].unittype + 1]
						end
						buy_and_present_ui.btn_senven_days.Visible = true
					else
						buy_and_present_ui.btn_senven_days.Visible = false
					end

					if mode3[3] then
						if mode3[2].unittype == 0 then
							buy_and_present_ui.btn_thirty_days.Text = unittype_way[mode3[3].unittype + 1]
						else
							buy_and_present_ui.btn_thirty_days.Text = mode3[3].unit..unittype_way[mode3[3].unittype + 1]
						end
						buy_and_present_ui.btn_thirty_days.Visible = true
					else
						buy_and_present_ui.btn_thirty_days.Visible = false
					end

					if mode3[4] then
						if mode3[4].unittype == 0 then
							buy_and_present_ui.btn_forever.Text = unittype_way[mode3[4].unittype + 1]
						else
							buy_and_present_ui.btn_forever.Text = mode3[4].unit..unittype_way[mode3[4].unittype + 1]
						end
						buy_and_present_ui.btn_forever.Visible = true
					else
						buy_and_present_ui.btn_forever.Visible = false
					end
				end

				--C币
				if mode2[1] then
					if mode2[1] then
						current_selected_price_way = 2
						buy_and_present_ui.lbl_spend_point.Text = "0 " .. price_way[1]
						buy_and_present_ui.lbl_spend_GP.Text = L_LobbyMain.ShoppingMallIB_rpc_data.items[current_selected_ibtn_index].gpprices[1].cost .. " " .. price_way[2]
						buy_and_present_ui.lbl_spend_ticket.Text = "0 " .. price_way[3]
						if mode2[1].unittype == 0 then
							buy_and_present_ui.btn_three_days.Text = unittype_way[mode2[1].unittype + 1]
						else
							buy_and_present_ui.btn_three_days.Text = mode2[1].unit..unittype_way[mode2[1].unittype + 1]
						end
						buy_and_present_ui.btn_three_days.Visible = true
					else
						buy_and_present_ui.btn_three_days.Visible = false
					end

					if mode2[2] then
						if mode2[2].unittype == 0 then
							buy_and_present_ui.btn_senven_days.Text = unittype_way[mode2[2].unittype + 1]
						else
							buy_and_present_ui.btn_senven_days.Text = mode2[2].unit..unittype_way[mode2[2].unittype + 1]
						end
						buy_and_present_ui.btn_senven_days.Visible = true
					else
						buy_and_present_ui.btn_senven_days.Visible = false
					end

					if mode2[3] then
						if mode2[2].unittype == 0 then
							buy_and_present_ui.btn_thirty_days.Text = unittype_way[mode2[3].unittype + 1]
						else
							buy_and_present_ui.btn_thirty_days.Text = mode2[3].unit..unittype_way[mode2[3].unittype + 1]
						end
						buy_and_present_ui.btn_thirty_days.Visible = true
					else
						buy_and_present_ui.btn_thirty_days.Visible = false
					end

					if mode2[4] then
						if mode2[4].unittype == 0 then
							buy_and_present_ui.btn_forever.Text = unittype_way[mode2[4].unittype + 1]
						else
							buy_and_present_ui.btn_forever.Text = mode2[4].unit..unittype_way[mode2[4].unittype + 1]
						end
						buy_and_present_ui.btn_forever.Visible = true
					else
						buy_and_present_ui.btn_forever.Visible = false
					end
				end

				--FC点
				if mode1[1] then
					if mode1[1] then
						current_selected_price_way = 1
						buy_and_present_ui.lbl_spend_point.Text = L_LobbyMain.ShoppingMallIB_rpc_data.items[current_selected_ibtn_index].crprices[1].cost .. " " .. price_way[1]
						buy_and_present_ui.lbl_spend_GP.Text = "0 " .. price_way[2]
						buy_and_present_ui.lbl_spend_ticket.Text = "0 " .. price_way[3]
						if mode1[1].unittype == 0 then
							buy_and_present_ui.btn_three_days.Text = unittype_way[mode1[1].unittype + 1]
						else
							buy_and_present_ui.btn_three_days.Text = mode1[1].unit..unittype_way[mode1[1].unittype + 1]
						end
						buy_and_present_ui.btn_three_days.Visible = true
					else
						buy_and_present_ui.btn_three_days.Visible = false
					end

					if mode1[2] then
						if mode1[2].unittype == 0 then
							buy_and_present_ui.btn_senven_days.Text = unittype_way[mode1[2].unittype + 1]
						else
							buy_and_present_ui.btn_senven_days.Text = mode1[2].unit..unittype_way[mode1[2].unittype + 1]
						end
						buy_and_present_ui.btn_senven_days.Visible = true
					else
						buy_and_present_ui.btn_senven_days.Visible = false
					end

					if mode1[3] then
						if mode1[2].unittype == 0 then
							buy_and_present_ui.btn_thirty_days.Text = unittype_way[mode1[3].unittype + 1]
						else
							buy_and_present_ui.btn_thirty_days.Text = mode1[3].unit..unittype_way[mode1[3].unittype + 1]
						end
						buy_and_present_ui.btn_thirty_days.Visible = true
					else
						buy_and_present_ui.btn_thirty_days.Visible = false
					end

					if mode1[4] then
						if mode1[4].unittype == 0 then
							buy_and_present_ui.btn_forever.Text = unittype_way[mode1[4].unittype + 1]
						else
							buy_and_present_ui.btn_forever.Text = mode1[4].unit..unittype_way[mode1[4].unittype + 1]
						end
						buy_and_present_ui.btn_forever.Visible = true
					else
						buy_and_present_ui.btn_forever.Visible = false
					end
				end
			
				buy_and_present_ui.lb_page_number.Text = price_way[current_selected_price_way]
			end
		end
	end
end

function CloseBuyWin()
	if buy_and_present_ui then
		buy_and_present_ui.ctrl_bg.Parent = nil
		--current_selected_price_way_cars = {1, 1, 1, 1, 1, 1, 1}
		--current_selected_price_unit_cars = {1, 1, 1, 1, 1, 1, 1}
		--buy_and_present_ui = nil
	end
end

--填充好友界面
function FillBuyAndPresentWindow()
	if buy_and_present_ui then
		local num = nil
		local btn_group = nil
		num, btn_group = L_LobbyMain.GetShoppingMallBottonGroup()
		if num ~= nil and btn_group ~= nil then
			local ibbtn = ptr_cast(btn_group:GetChildByIndex(current_selected_ibtn_index-1))
			if ibbtn ~= nil then
				local b_denote = ptr_cast(ibbtn:GetChildByIndex(2))
				if b_denote ~= nil then
					buy_and_present_ui.btn_buy_and_present.Visible = b_denote.Visible
				end
			end
		end

		buy_and_present_ui.lbl_present_to.Visible = false
		buy_and_present_ui.cbx_friends_present.Visible = false
		buy_and_present_ui.lbl_balance_mode.Location = Vector2(140, 6)
		buy_and_present_ui.btn_front_page.Location = Vector2(666, 458)
		buy_and_present_ui.lb_page_number.Location = Vector2(310, 9)
		buy_and_present_ui.btn_next_page.Location = Vector2(400, 9)
		
		buy_and_present_ui.lbl_spend_point.Text = ""
		buy_and_present_ui.btn_buy_and_balance.PushDown = true
		buy_and_present_ui.btn_buy_and_present.PushDown = false
		buy_and_present_ui.cbox_buy_and_equip.Visible = true
		buy_and_present_ui.lbl_buy_and_equip.Visible = true
		buy_and_present_ui.btn_buy.Text = lang:GetText("购买")
		if L_LobbyMain.ShoppingMallIB_rpc_data then
			if L_LobbyMain.PersonalInfo_data then
				--FC点
				buy_and_present_ui.lbl_balance_point.Text = L_LobbyMain.PersonalInfo_data.newCR .. " " .. price_way[1]
				--C币
				buy_and_present_ui.lbl_balance_GP.Text = L_LobbyMain.PersonalInfo_data.newGP .. " " .. price_way[2]
				--抵用券
				buy_and_present_ui.lbl_balance_ticket.Text = L_LobbyMain.PersonalInfo_data.newTicket .. " " .. price_way[3]				
			end		
			buy_and_present_ui.lbl_spend_point.TextColor = ARGB(255, 37, 37, 37)
			buy_and_present_ui.lbl_spend_GP.TextColor = ARGB(255, 37, 37, 37)
			buy_and_present_ui.lbl_spend_ticket.TextColor = ARGB(255, 37, 37, 37)
			buy_and_present_ui.lbl_spend_point.Text = "0 " .. price_way[1]
			--buy_and_present_ui.lbl_spend_GP.Text = L_LobbyMain.ShoppingMallIB_rpc_data.items[current_selected_ibtn_index].gpprices[1].cost .. " " .. price_way[2]
			buy_and_present_ui.lbl_spend_GP.Text = "0 " .. price_way[2]
			buy_and_present_ui.lbl_spend_ticket.Text = "0 " .. price_way[3]
			cost_mode = 1
			
			local weapon_info = L_LobbyMain.ShoppingMallIB_rpc_data.items[current_selected_ibtn_index]			
			if weapon_info then
				if L_LobbyMain.current_shoppingmall_storage == 1 then
					buy_and_present_ui.ctrl_goods_image.Size = Vector2(128, 64)
					buy_and_present_ui.ctrl_goods_image_root.Size = Vector2(160, 156)
				elseif L_LobbyMain.current_shoppingmall_storage == 2 then
					buy_and_present_ui.ctrl_goods_image.Size = Vector2(100, 195)
					buy_and_present_ui.ctrl_goods_image_root.Size = Vector2(160, 195)
				elseif L_LobbyMain.current_shoppingmall_storage == 3 then
					buy_and_present_ui.ctrl_goods_image.Size = Vector2(100, 96)
					buy_and_present_ui.ctrl_goods_image_root.Size = Vector2(160, 156)
				else
					buy_and_present_ui.ctrl_goods_image.Size = Vector2(100, 96)
					buy_and_present_ui.ctrl_goods_image_root.Size = Vector2(160, 156)
				end
				
				--取消购买并装备
				if 	weapon_info.common.type > 3 then
					if weapon_info.common.type == 4 then
						local pass = true
						for i = 1, #operator_iid do
							if weapon_info.iid == operator_iid[i] then
								pass = false
							end
						end
						if weapon_info.sid == 5650 then
							pass = false
						end
						if pass == true then
							buy_and_present_ui.lbl_buy_and_equip.Visible = true
							buy_and_present_ui.cbox_buy_and_equip.Visible = true
							buy_and_present_ui.cbox_buy_and_equip.Check = false
							buy_and_present_ui.lbl_buy_and_equip.Text = lang:GetText("购买完直接使用")
						else
							buy_and_present_ui.lbl_buy_and_equip.Visible = false
							buy_and_present_ui.cbox_buy_and_equip.Visible = false
							buy_and_present_ui.cbox_buy_and_equip.Check = false
						end
					else
						buy_and_present_ui.lbl_buy_and_equip.Visible = false
						buy_and_present_ui.cbox_buy_and_equip.Visible = false
						buy_and_present_ui.cbox_buy_and_equip.Check = false
					end
				else
					buy_and_present_ui.lbl_buy_and_equip.Visible = true
					buy_and_present_ui.cbox_buy_and_equip.Visible = true
					buy_and_present_ui.cbox_buy_and_equip.Check = false
					buy_and_present_ui.lbl_buy_and_equip.Text = lang:GetText("购买完直接装备")
				end
				local color = weapon_info.color
				local name = weapon_info.name
				if color >= 1 and color <= 8 then
					buy_and_present_ui.ctrl_goods_image.Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ibt_icon/"..name.."_"..color..".tga", Vector4(0, 0, 0, 0)),
					}
				else
					buy_and_present_ui.ctrl_goods_image.Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ibt_icon/"..name..".tga", Vector4(0, 0, 0, 0)),
					}
				end
				buy_and_present_ui.lbl_goods_name.Text = weapon_info.display
				buy_and_present_ui.lbl_goods_info.Text = weapon_info.description

				--付款方式
				local mode1 = weapon_info.crprices
				local mode2 = weapon_info.gpprices
				local mode3 = weapon_info.voucherprices

				--抵用券
				if mode3[1] then
					if mode3[1] then
						current_selected_price_way = 3						
						buy_and_present_ui.lbl_spend_point.Text = "0 " .. price_way[1]
						buy_and_present_ui.lbl_spend_GP.Text = "0 " .. price_way[2]
						if  L_LobbyMain.ShoppingMallIB_rpc_data.items[current_selected_ibtn_index].voucherprices[1].cost > L_LobbyMain.PersonalInfo_data.newTicket then
							buy_and_present_ui.lbl_spend_ticket.TextColor = ARGB(255, 255, 0, 0)
						end
						buy_and_present_ui.lbl_spend_ticket.Text = L_LobbyMain.ShoppingMallIB_rpc_data.items[current_selected_ibtn_index].voucherprices[1].cost .. " " .. price_way[3]						
						if mode3[1].unittype == 0 then
							buy_and_present_ui.btn_three_days.Text = unittype_way[mode3[1].unittype + 1]
						else
							buy_and_present_ui.btn_three_days.Text = mode3[1].unit..unittype_way[mode3[1].unittype + 1]
						end
						buy_and_present_ui.btn_three_days.Visible = true
					else
						buy_and_present_ui.btn_three_days.Visible = false
					end

					if mode3[2] then
						if mode3[2].unittype == 0 then
							buy_and_present_ui.btn_senven_days.Text = unittype_way[mode3[2].unittype + 1]
						else
							buy_and_present_ui.btn_senven_days.Text = mode3[2].unit..unittype_way[mode3[2].unittype + 1]
						end
						buy_and_present_ui.btn_senven_days.Visible = true
					else
						buy_and_present_ui.btn_senven_days.Visible = false
					end

					if mode3[3] then
						if mode3[2].unittype == 0 then
							buy_and_present_ui.btn_thirty_days.Text = unittype_way[mode3[3].unittype + 1]
						else
							buy_and_present_ui.btn_thirty_days.Text = mode3[3].unit..unittype_way[mode3[3].unittype + 1]
						end
						buy_and_present_ui.btn_thirty_days.Visible = true
					else
						buy_and_present_ui.btn_thirty_days.Visible = false
					end

					if mode3[4] then
						if mode3[4].unittype == 0 then
							buy_and_present_ui.btn_forever.Text = unittype_way[mode3[4].unittype + 1]
						else
							buy_and_present_ui.btn_forever.Text = mode3[4].unit..unittype_way[mode3[4].unittype + 1]
						end
						buy_and_present_ui.btn_forever.Visible = true
					else
						buy_and_present_ui.btn_forever.Visible = false
					end
				end

				--C币
				if mode2[1] then
					if mode2[1] then
						current_selected_price_way = 2
						buy_and_present_ui.lbl_spend_point.Text = "0 " .. price_way[1]
						if  L_LobbyMain.ShoppingMallIB_rpc_data.items[current_selected_ibtn_index].gpprices[1].cost > L_LobbyMain.PersonalInfo_data.newGP then
							buy_and_present_ui.lbl_spend_GP.TextColor = ARGB(255, 255, 0, 0)
						end
						buy_and_present_ui.lbl_spend_GP.Text = L_LobbyMain.ShoppingMallIB_rpc_data.items[current_selected_ibtn_index].gpprices[1].cost .. " " .. price_way[2]
						buy_and_present_ui.lbl_spend_ticket.Text = "0 " .. price_way[3]
						if mode2[1].unittype == 0 then
							buy_and_present_ui.btn_three_days.Text = unittype_way[mode2[1].unittype + 1]
						else
							buy_and_present_ui.btn_three_days.Text = mode2[1].unit..unittype_way[mode2[1].unittype + 1]
						end
						buy_and_present_ui.btn_three_days.Visible = true
					else
						buy_and_present_ui.btn_three_days.Visible = false
					end

					if mode2[2] then
						if mode2[2].unittype == 0 then
							buy_and_present_ui.btn_senven_days.Text = unittype_way[mode2[2].unittype + 1]
						else
							buy_and_present_ui.btn_senven_days.Text = mode2[2].unit..unittype_way[mode2[2].unittype + 1]
						end
						buy_and_present_ui.btn_senven_days.Visible = true
					else
						buy_and_present_ui.btn_senven_days.Visible = false
					end

					if mode2[3] then
						if mode2[2].unittype == 0 then
							buy_and_present_ui.btn_thirty_days.Text = unittype_way[mode2[3].unittype + 1]
						else
							buy_and_present_ui.btn_thirty_days.Text = mode2[3].unit..unittype_way[mode2[3].unittype + 1]
						end
						buy_and_present_ui.btn_thirty_days.Visible = true
					else
						buy_and_present_ui.btn_thirty_days.Visible = false
					end

					if mode2[4] then
						if mode2[4].unittype == 0 then
							buy_and_present_ui.btn_forever.Text = unittype_way[mode2[4].unittype + 1]
						else
							buy_and_present_ui.btn_forever.Text = mode2[4].unit..unittype_way[mode2[4].unittype + 1]
						end
						buy_and_present_ui.btn_forever.Visible = true
					else
						buy_and_present_ui.btn_forever.Visible = false
					end
				end

				--FC点
				if mode1[1] then
					if mode1[1] then
						current_selected_price_way = 1
						if  L_LobbyMain.ShoppingMallIB_rpc_data.items[current_selected_ibtn_index].crprices[1].cost > L_LobbyMain.PersonalInfo_data.newCR then
							buy_and_present_ui.lbl_spend_point.TextColor = ARGB(255, 255, 0, 0)
						end
						buy_and_present_ui.lbl_spend_point.Text = L_LobbyMain.ShoppingMallIB_rpc_data.items[current_selected_ibtn_index].crprices[1].cost .. " " .. price_way[1]
						buy_and_present_ui.lbl_spend_GP.Text = "0 " .. price_way[2]
						buy_and_present_ui.lbl_spend_ticket.Text = "0 " .. price_way[3]
						if mode1[1].unittype == 0 then
							buy_and_present_ui.btn_three_days.Text = unittype_way[mode1[1].unittype + 1]
						else
							buy_and_present_ui.btn_three_days.Text = mode1[1].unit..unittype_way[mode1[1].unittype + 1]
						end
						buy_and_present_ui.btn_three_days.Visible = true
					else
						buy_and_present_ui.btn_three_days.Visible = false
					end

					if mode1[2] then
						if mode1[2].unittype == 0 then
							buy_and_present_ui.btn_senven_days.Text = unittype_way[mode1[2].unittype + 1]
						else
							buy_and_present_ui.btn_senven_days.Text = mode1[2].unit..unittype_way[mode1[2].unittype + 1]
						end
						buy_and_present_ui.btn_senven_days.Visible = true
					else
						buy_and_present_ui.btn_senven_days.Visible = false
					end

					if mode1[3] then
						if mode1[2].unittype == 0 then
							buy_and_present_ui.btn_thirty_days.Text = unittype_way[mode1[3].unittype + 1]
						else
							buy_and_present_ui.btn_thirty_days.Text = mode1[3].unit..unittype_way[mode1[3].unittype + 1]
						end
						buy_and_present_ui.btn_thirty_days.Visible = true
					else
						buy_and_present_ui.btn_thirty_days.Visible = false
					end

					if mode1[4] then
						if mode1[4].unittype == 0 then
							buy_and_present_ui.btn_forever.Text = unittype_way[mode1[4].unittype + 1]
						else
							buy_and_present_ui.btn_forever.Text = mode1[4].unit..unittype_way[mode1[4].unittype + 1]
						end
						buy_and_present_ui.btn_forever.Visible = true
					else
						buy_and_present_ui.btn_forever.Visible = false
					end
				end
			
				buy_and_present_ui.lb_page_number.Text = price_way[current_selected_price_way]
			end
		end
	end
end

--购买 赠送好友界面
local function setup_buy_and_present_window(parent_window)
	--界面是否存在
	if buy_and_present_ui then
		buy_and_present_ui.ctrl_bg.Parent = parent_window
		buy_and_present_ui.btn_three_days.PushDown = true
		buy_and_present_ui.btn_senven_days.PushDown = false
		buy_and_present_ui.btn_thirty_days.PushDown = false
		buy_and_present_ui.btn_forever.PushDown = false
		FillBuyAndPresentWindow()
		return
	end
	--创建界面
	buy_and_present_ui = Gui.Create(parent_window)(buy_and_present_window_page)
	buy_and_present_ui.lbl_goods_info.VScrollBarWidth = 5
	buy_and_present_ui.lbl_goods_info.VScrollBarButtonSize = 0.1
	FillBuyAndPresentWindow()
	
	local Playerlist = Player_List.ltv_box
	Playerlist:DeleteColumns()
	Playerlist:AddColumn("",346, "kAlignCenterMiddle")
end

-------------------------------------------------------------------------------------------
--道具界面 
local function create_prop_page(index, line, list)
	return Gui.ItemBoxBtn
	{
		Style = "Gui.ItemBoxBtn_ib2",
		Size = Vector2(104, 100),
		Location = Vector2(117*line, 100*list),
		BtnLocation = Vector2(45, 72),
		BtnText = lang:GetText("购买"),
		ItemBtnSkin = Skin.ButtonSkin_ItemBoxBtn_buy,
		
		EventSelected = function(sender, e)
			if prop_window_ui and sender.Loading == false then
				for i = 1, 28 do
					local ibbtn = ptr_cast(prop_window_ui.ctrl_ib_container:GetChildByIndex(i-1))
					if ibbtn then
						if i == index then
							ibbtn.Selected = true
						else
							ibbtn.Selected = false
						end
					else
						print("ShoppingMall.lua create_prop_page error -- ibbtn is nil")
					end
				end
				FillPropInfo(index)
			end
		end,
		
		--购买行为
		EventDoubleClick = function(sender, e)
			if L_LobbyMain.LobbyMainWin.LobbyMain_Root_Parent then
				current_selected_ibtn_index = index
				setup_buy_and_present_window(L_LobbyMain.LobbyMainWin.LobbyMain_Root_Parent)
			end
		end,
		
		EventBtnClick = function()
			if L_LobbyMain.LobbyMainWin.LobbyMain_Root_Parent then
				current_selected_ibtn_index = index
				setup_buy_and_present_window(L_LobbyMain.LobbyMainWin.LobbyMain_Root_Parent)
				buy_and_present_ui.play_list.Visible = false
			end
		end,
		
		--ToolTips 行为
		EventMouseEnter = function(sender, e)
			--part = 2 表示商城
			if sender.Loading == false then
				L_ToolTips.FillToolTipsWindow(2, index, sender)
			end
		end,
		EventToolTipsShow = function(sender, e)
			L_ToolTips.ShowToolTipsShowWindow(sender)
		end,
		EventMouseLeave = function(sender, e)
			L_ToolTips.HideToolTipsWindow()
		end,
	}
end

function SpawnNewpropButton()
	local newbutton = Gui.Create(gui)
    {
		--赠送
		Gui.Button "ib_donate"
		{	
			Visible = false,
			Location = Vector2(104 - 100,100 - 28),
			Size = Vector2(47,25),
			Skin = Skin.ButtonSkin_ItemBoxBtn_gift,
			
			EventClick = function(Sender ,e)
				local ibbtn = nil
				local index = 0
				for i = 1, 28 do
					ibbtn = ptr_cast(prop_window_ui.ctrl_ib_container:GetChildByIndex(i-1))
					if Sender.Parent == ibbtn then
						index = i
						break
					end						
				end
				
				if L_LobbyMain.LobbyMainWin.LobbyMain_Root_Parent then
					current_selected_ibtn_index = index
					setup_buy_and_present_window(L_LobbyMain.LobbyMainWin.LobbyMain_Root_Parent)
				end
				
				if buy_and_present_ui then
					buy_and_present_ui.lbl_present_to.Visible = true
					buy_and_present_ui.cbx_friends_present.Visible = true
					buy_and_present_ui.lbl_balance_mode.Location = Vector2(306, 6)
					buy_and_present_ui.btn_front_page.Location = Vector2(323, 7)
					buy_and_present_ui.lb_page_number.Location = Vector2(386, 6)
					buy_and_present_ui.btn_next_page.Location = Vector2(408, 7)
					
					buy_and_present_ui.lbl_spend_point.Text = ""
					buy_and_present_ui.btn_buy_and_balance.PushDown = false
					buy_and_present_ui.btn_buy_and_present.PushDown = true
					buy_and_present_ui.cbox_buy_and_equip.Visible = false
					buy_and_present_ui.lbl_buy_and_equip.Visible = false
					buy_and_present_ui.btn_three_days.PushDown = true
					buy_and_present_ui.btn_senven_days.PushDown = false
					buy_and_present_ui.btn_thirty_days.PushDown = false
					buy_and_present_ui.btn_forever.PushDown = false
					buy_and_present_ui.play_list.Visible = true
					buy_and_present_ui.btn_buy.Text = lang:GetText("赠送")
					buy_and_present_ui.cbx_friends_present.Text = ""
					FillPresentWindow()
				end
			end
		},
    }
	return newbutton
end

local prop_window_page = 
{
	Gui.Control "ctrl_ib_container"
	{							
		Size = Vector2(832, 400),
		Location = Vector2(10, 60),
		BackgroundColor = ARGB(0, 255, 255, 255),
	
		create_prop_page(1, 0, 0),
		create_prop_page(2, 1, 0),
		create_prop_page(3, 2, 0),
		create_prop_page(4, 3, 0),
		create_prop_page(5, 4, 0),
		create_prop_page(6, 5, 0),
		create_prop_page(7, 6, 0),
		
		create_prop_page(8, 0, 1),
		create_prop_page(9, 1, 1),
		create_prop_page(10, 2, 1),
		create_prop_page(11, 3, 1),
		create_prop_page(12, 4, 1),
		create_prop_page(13, 5, 1),
		create_prop_page(14, 6, 1),
		
		create_prop_page(15, 0, 2),
		create_prop_page(16, 1, 2),
		create_prop_page(17, 2, 2),
		create_prop_page(18, 3, 2),
		create_prop_page(19, 4, 2),
		create_prop_page(20, 5, 2),
		create_prop_page(21, 6, 2),
		
		create_prop_page(22, 0, 3),
		create_prop_page(23, 1, 3),
		create_prop_page(24, 2, 3),
		create_prop_page(25, 3, 3),
		create_prop_page(26, 4, 3),
		create_prop_page(27, 5, 3),
		create_prop_page(28, 6, 3),
	},
}

local function setup_ib_prop(parent_window)
	--界面是否存在
	if prop_window_ui then
		prop_window_ui.ctrl_ib_container.Parent = parent_window
		return
	end
	--创建界面
	prop_window_ui = Gui.Create(parent_window)(prop_window_page)
	
	for i = 1, 28 do
		local ibbtn = ptr_cast(prop_window_ui.ctrl_ib_container:GetChildByIndex(i-1))
		local newbutton = SpawnNewpropButton()
		ibbtn.ItemBtnSkin = Skin.ButtonSkin_ItemBoxBtn_buy
		ibbtn.BtnSize = Vector2(47,25)
		ibbtn.BtnLocation = Vector2(104-53,100-28)
		newbutton.ib_donate.Parent = ibbtn
	end	
end

--------------------------------------------------------------------------------------------
-- 配饰界面
local function create_accessories_page(index, line, list)
	return Gui.ItemBoxBtn
	{
		Style = "Gui.ItemBoxBtn_ib2",
		Size = Vector2(104, 100),
		Location = Vector2(104*line, 100*list),
		BtnLocation = Vector2(45, 72),
		BtnText = lang:GetText("购买"),
		ItemBtnSkin = Skin.ButtonSkin_ItemBoxBtn_buy,
		
		-- event function
		EventSelected = function(sender, e)
			if ib_accessories_ui and sender.Loading == false then
				for i = 1, 16 do
					local ibbtn = ptr_cast(ib_accessories_ui.ctrl_ib_container:GetChildByIndex(i-1))
					if i == index then
						ibbtn.Selected = true
					else
						ibbtn.Selected = false
					end
				end
				
				FillCart(index)
				Getshoppingcar_window_count()
				if shoppingcar_window_count > 0 then
					user_bag_ui.btn_buy_all.Enable = true
					user_bag_ui.btn_clear_all.Enable = true
				end
			end
			current_selected_item_class = 1
			current_selected_ibtn_index	= index
			L_LobbyMain.ChangeAvatarPart()
		end,
		
		-- 拖拽行为
		EventMouseRightDown = function(sender, e)
			if tuozhuai_ui == nil then
				tuozhuai_ui = Gui.Create(L_LobbyMain.LobbyMainWin.LobbyMain_Root)(tuozhuai)
			end
			index_tz = index
			tuozhuai_ui.root.Visible = true
			local lobby_state = ptr_cast(game.CurrentState)
			local cursor_ScreenSize = lobby_state:GetScreenSize()
			local cursor_pos = lobby_state:GetCursorPos()
			tuozhuai_ui.Image.Location = Vector2(cursor_pos.x-((cursor_ScreenSize.x - cursor_ScreenSize.y / 3 * 4) / 2) - 51, cursor_pos.y - 34)
			tuozhuai_ui.Image.Size = Vector2(72, 68)
			if L_LobbyMain.ShoppingMallIB_rpc_data.items[index].color >= 1 and L_LobbyMain.ShoppingMallIB_rpc_data.items[index].color <= 8 then
				tuozhuai_ui.Image.Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ibt_icon/"..L_LobbyMain.ShoppingMallIB_rpc_data.items[index].name.."_"..L_LobbyMain.ShoppingMallIB_rpc_data.items[index].color..".tga", Vector4(0, 0, 0, 0)),
				}
			else
				tuozhuai_ui.Image.Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ibt_icon/"..L_LobbyMain.ShoppingMallIB_rpc_data.items[index].name..".tga", Vector4(0, 0, 0, 0)),
				}
			end
			local ibbtn = ptr_cast(ib_accessories_ui.ctrl_ib_container:GetChildByIndex(index-1))
			ibbtn.ItemIcon.alpha = 80
			Highlight_accessories_tip(index)
		end,
		
		-- TOOLTIPS行为
		EventMouseEnter = function(sender, e)
			if sender.Loading == false then
				L_ToolTips.FillToolTipsWindow(2, index, sender)
			end
		end,
		EventToolTipsShow = function(sender, e)
			L_ToolTips.ShowToolTipsShowWindowContrast(sender)
		end,
		EventMouseLeave = function(sender, e)
			L_ToolTips.HideToolTipsWindow()
		end,

		EventBtnClick = function()
			if L_LobbyMain.LobbyMainWin.LobbyMain_Root_Parent then
				current_selected_ibtn_index = index
				setup_buy_and_present_window(L_LobbyMain.LobbyMainWin.LobbyMain_Root_Parent)
				buy_and_present_ui.play_list.Visible = false
			end
		end,
	}
end

function SpawnNewaccessoriesButton()
	local newbutton = Gui.Create(gui)
    {
		--赠送
		Gui.Button "ib_donate"
		{	
			Visible = false,
			Location = Vector2(104 - 100,100 - 28),
			Size = Vector2(47,25),
			Skin = Skin.ButtonSkin_ItemBoxBtn_gift,
			
			EventClick = function(Sender ,e)
				local ibbtn = nil
				local index = 0
				for i = 1, 16 do
					ibbtn = ptr_cast(ib_accessories_ui.ctrl_ib_container:GetChildByIndex(i-1))
					if Sender.Parent == ibbtn then
						index = i
						break
					end						
				end
				
				if L_LobbyMain.LobbyMainWin.LobbyMain_Root_Parent then
					current_selected_ibtn_index = index
					setup_buy_and_present_window(L_LobbyMain.LobbyMainWin.LobbyMain_Root_Parent)
				end
				
				if buy_and_present_ui then
					buy_and_present_ui.lbl_present_to.Visible = true
					buy_and_present_ui.cbx_friends_present.Visible = true
					buy_and_present_ui.lbl_balance_mode.Location = Vector2(306, 6)
					buy_and_present_ui.btn_front_page.Location = Vector2(323, 7)
					buy_and_present_ui.lb_page_number.Location = Vector2(386, 6)
					buy_and_present_ui.btn_next_page.Location = Vector2(408, 7)
					
					buy_and_present_ui.lbl_spend_point.Text = ""
					buy_and_present_ui.btn_buy_and_balance.PushDown = false
					buy_and_present_ui.btn_buy_and_present.PushDown = true
					buy_and_present_ui.cbox_buy_and_equip.Visible = false
					buy_and_present_ui.lbl_buy_and_equip.Visible = false
					buy_and_present_ui.btn_three_days.PushDown = true
					buy_and_present_ui.btn_senven_days.PushDown = false
					buy_and_present_ui.btn_thirty_days.PushDown = false
					buy_and_present_ui.btn_forever.PushDown = false
					buy_and_present_ui.play_list.Visible = true
					buy_and_present_ui.btn_buy.Text = lang:GetText("赠送")
					buy_and_present_ui.cbx_friends_present.Text = ""
					
					FillPresentWindow()
				end
			end
		},
    }
	return newbutton
end

function SpawnNewaccessoriesControl()
	local newcontrol = Gui.Create(gui)
	{
		Gui.Control "ib_Compose"
		{			
			Visible = false,
			Size = Vector2(54,30),
			Location = Vector2(64 - 19,100 - 55),
			BackgroundColor = ARGB(255, 255, 255, 255),
		},
	}
	return newcontrol
end

function SpawnNewStarControl()
	local newcontrol = Gui.Create(gui)
	{
		Gui.Control "ib_star"
		{			
			Visible = false,
			Size = Vector2(102,17),
			Location = Vector2(64 - 39,100 - 55),
			BackgroundColor = ARGB(255, 255, 255, 255),
		},
	}
	return newcontrol
end

local accessories_info_page =
{
	Gui.Control "ctrl_ib_container"
	{							
		Size = Vector2(415, 400),
		Location = Vector2(19, 55),
		BackgroundColor = ARGB(0, 255, 255, 255),

		create_accessories_page(1, 0, 0),
		create_accessories_page(2, 1, 0),
		create_accessories_page(3, 2, 0),
		create_accessories_page(4, 3, 0),
		
		create_accessories_page(5, 0, 1),
		create_accessories_page(6, 1, 1),
		create_accessories_page(7, 2, 1),
		create_accessories_page(8, 3, 1),

		create_accessories_page(9, 0, 2),
		create_accessories_page(10, 1, 2),
		create_accessories_page(11, 2, 2),
		create_accessories_page(12, 3, 2),
		
		create_accessories_page(13, 0, 3),
		create_accessories_page(14, 1, 3),
		create_accessories_page(15, 2, 3),
		create_accessories_page(16, 3, 3),
	},
}

local function setup_ib_accessories(parent_window)
	if ib_weapon_ui then
		ib_weapon_ui.Parent = nil
	end

	if ib_dress_ui then
		ib_dress_ui.Parent = nil
	end

	--界面是否存在
	if ib_accessories_ui then
		ib_accessories_ui.ctrl_ib_container.Parent = parent_window
		return
	end
	--创建界面
	ib_accessories_ui = Gui.Create(parent_window)(accessories_info_page)	
	
	for i = 1, 16 do
		local ibbtn = ptr_cast(ib_accessories_ui.ctrl_ib_container:GetChildByIndex(i-1))
		local newbutton = SpawnNewaccessoriesButton()
		local Control = SpawnNewaccessoriesControl()
		ibbtn.ItemBtnSkin = Skin.ButtonSkin_ItemBoxBtn_buy
		ibbtn.BtnSize = Vector2(47,25)
		ibbtn.BtnLocation = Vector2(104 - 53,100- 28)
		newbutton.ib_donate.Parent = ibbtn
		Control.ib_Compose.Parent = ibbtn
	end
end

--------------------------------------------------------------------------------------------
--服装界面
local function create_dress_page(index, line, list)
	return Gui.ItemBoxBtn
	{
		Style = "Gui.ItemBoxBtn_ib1",
		Size = Vector2(104, 200),
		Location = Vector2(104*line, 200*list),
		BtnLocation = Vector2(47, 172),
		BtnText = lang:GetText("购买"),
		BtnSize = Vector2(48,25),
		ItemBtnSkin = Skin.ButtonSkin_ItemBoxBtn_buy,
		
		--event function 
		EventSelected = function(sender, e)
			if ib_dress_ui and sender.Loading == false then
				for i = 1, 8 do
					local ibbtn = ptr_cast(ib_dress_ui.ctrl_ib_container:GetChildByIndex(i-1))

					if i == index then
						ibbtn.Selected = true
					else
						ibbtn.Selected = false
					end
				end
				
				FillCart(index)
				Getshoppingcar_window_count()
				if shoppingcar_window_count > 0 then
					user_bag_ui.btn_buy_all.Enable = true
					user_bag_ui.btn_clear_all.Enable = true
				end
			end
			current_selected_item_class = 1
			current_selected_ibtn_index	= index
			L_LobbyMain.ChangeAvatarPart()
		end,
		
		EventMouseRightDown = function(sender, e)
			if tuozhuai_ui == nil then
				tuozhuai_ui = Gui.Create(L_LobbyMain.LobbyMainWin.LobbyMain_Root)(tuozhuai)
			end
			index_tz = index
			tuozhuai_ui.root.Visible = true
			local lobby_state = ptr_cast(game.CurrentState)
			local cursor_ScreenSize = lobby_state:GetScreenSize()
			local cursor_pos = lobby_state:GetCursorPos()
			tuozhuai_ui.Image.Location = Vector2(cursor_pos.x-((cursor_ScreenSize.x - cursor_ScreenSize.y / 3 * 4) / 2) - 55, cursor_pos.y - 78)
			tuozhuai_ui.Image.Size = Vector2(80, 156)
			if L_LobbyMain.ShoppingMallIB_rpc_data.items[index].color >= 1 and L_LobbyMain.ShoppingMallIB_rpc_data.items[index].color <= 8 then
				tuozhuai_ui.Image.Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ibt_icon/"..L_LobbyMain.ShoppingMallIB_rpc_data.items[index].name.."_"..L_LobbyMain.ShoppingMallIB_rpc_data.items[index].color..".tga", Vector4(0, 0, 0, 0)),
				}
			else
				tuozhuai_ui.Image.Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ibt_icon/"..L_LobbyMain.ShoppingMallIB_rpc_data.items[index].name..".tga", Vector4(0, 0, 0, 0)),
				}
			end
			local ibbtn = ptr_cast(ib_dress_ui.ctrl_ib_container:GetChildByIndex(index-1))
			ibbtn.ItemIcon.alpha = 80
			user_bag_info_ui.ib_no_use.Highlight = true
		end,

		EventMouseEnter = function(sender, e)
			if sender.Loading == false then
				L_ToolTips.FillToolTipsWindow(2, index, sender)
			end
		end,
		EventToolTipsShow = function(sender, e)
			L_ToolTips.ShowToolTipsShowWindowContrast(sender)
		end,
		EventMouseLeave = function(sender, e)
			L_ToolTips.HideToolTipsWindow()
		end,

		EventBtnClick = function()
			if L_LobbyMain.LobbyMainWin.LobbyMain_Root_Parent then
				current_selected_ibtn_index = index
				setup_buy_and_present_window(L_LobbyMain.LobbyMainWin.LobbyMain_Root_Parent)
				buy_and_present_ui.play_list.Visible = false
			end
		end,
	}
end

local dress_info_page =
{
	Gui.Control "ctrl_ib_container"
	{							
		Size = Vector2(415, 400),
		Location = Vector2(19, 55),
		BackgroundColor = ARGB(0, 255, 255, 255),
		
		create_dress_page(1, 0, 0),
		create_dress_page(2, 1, 0),
		create_dress_page(3, 2, 0),
		create_dress_page(4, 3, 0),
		
		create_dress_page(5, 0, 1),
		create_dress_page(6, 1, 1),
		create_dress_page(7, 2, 1),
		create_dress_page(8, 3, 1),
	},
}

function SpawnNewdressButton()
	local newbutton = Gui.Create(gui)
	{
		--赠送
		Gui.Button "ib_donate"
		{	
			Visible = false,
			Location = Vector2(104 - 100,200 - 30),
			Size = Vector2(47,27),
			Skin = Skin.ButtonSkin_ItemBoxBtn_gift,
			
			EventClick = function(Sender ,e)
				local ibbtn = nil
				local index = 0
				for i = 1, 8 do
					ibbtn = ptr_cast(ib_dress_ui.ctrl_ib_container:GetChildByIndex(i-1))
					if Sender.Parent == ibbtn then
						index = i
						break
					end						
				end
				
				if L_LobbyMain.LobbyMainWin.LobbyMain_Root_Parent then
					current_selected_ibtn_index = index
					setup_buy_and_present_window(L_LobbyMain.LobbyMainWin.LobbyMain_Root_Parent)
				end
				
				if buy_and_present_ui then
					buy_and_present_ui.lbl_present_to.Visible = true
					buy_and_present_ui.cbx_friends_present.Visible = true
					buy_and_present_ui.lbl_balance_mode.Location = Vector2(306, 6)
					buy_and_present_ui.btn_front_page.Location = Vector2(323, 7)
					buy_and_present_ui.lb_page_number.Location = Vector2(386, 6)
					buy_and_present_ui.btn_next_page.Location = Vector2(408, 7)
					
					buy_and_present_ui.lbl_spend_point.Text = ""
					buy_and_present_ui.btn_buy_and_balance.PushDown = false
					buy_and_present_ui.btn_buy_and_present.PushDown = true
					buy_and_present_ui.cbox_buy_and_equip.Visible = false
					buy_and_present_ui.lbl_buy_and_equip.Visible = false
					buy_and_present_ui.btn_three_days.PushDown = true
					buy_and_present_ui.btn_senven_days.PushDown = false
					buy_and_present_ui.btn_thirty_days.PushDown = false
					buy_and_present_ui.btn_forever.PushDown = false
					buy_and_present_ui.play_list.Visible = true
					buy_and_present_ui.btn_buy.Text = lang:GetText("赠送")
					buy_and_present_ui.cbx_friends_present.Text = ""
					
					FillPresentWindow()
				end
			end	
		},
	}
	return newbutton
end

function SpawnNewdressControl()
	local newcontrol = Gui.Create(gui)
	{
		Gui.Control "ib_Compose"
		{			
			Visible = false,
			Size = Vector2(54,30),
			Location = Vector2(64 - 19,200 - 57),
			BackgroundColor = ARGB(255, 255, 255, 255),
		},
	}
	return newcontrol
end

local function setup_ib_dress(parent_window)
	if ib_weapon_ui then
		ib_weapon_ui.ctrl_ib_container.Parent = nil
	end

	if ib_accessories_ui then
		ib_accessories_ui.ctrl_ib_container.Parent = nil
	end

	--界面是否存在
	if ib_dress_ui then
		ib_dress_ui.ctrl_ib_container.Parent = parent_window
		return
	end
	--创建界面
	ib_dress_ui = Gui.Create(parent_window)(dress_info_page)
	
	for i = 1, 8 do
		local ibbtn = ptr_cast(ib_dress_ui.ctrl_ib_container:GetChildByIndex(i-1))
		local newbutton = SpawnNewdressButton()
		local Control = SpawnNewdressControl()
		ibbtn.ItemBtnSkin = Skin.ButtonSkin_ItemBoxBtn_buy
		ibbtn.BtnSize = Vector2(47,27)
		ibbtn.BtnLocation = Vector2(104-53,200-30)
		newbutton.ib_donate.Parent = ibbtn
		Control.ib_Compose.Parent = ibbtn
	end
end

--------------------------------------------------------------------------------------------
--武器界面
local function create_weapon_page(index, line, list)
	return Gui.ItemBoxBtn
	{
		Style = "Gui.ItemBoxBtn_ib",
		Size = Vector2(212, 100),
		Location = Vector2(212*line, 100*list),
		BtnText = lang:GetText("购买"),
		ItemBtnSkin = Skin.ButtonSkin_ItemBoxBtn_buy,
		
		--event function 
		EventSelected = function(sender, e)
			if ib_weapon_ui and sender.Loading == false then
				for i = 1, 8 do
					local ibbtn = ptr_cast(ib_weapon_ui.ctrl_ib_container:GetChildByIndex(i-1))
					if i == index then
						ibbtn.Selected = true
					else
						ibbtn.Selected = false
					end
				end
				FillCart(index)
				Getshoppingcar_window_count()
				if shoppingcar_window_count > 0 then
					user_bag_ui.btn_buy_all.Enable = true
					user_bag_ui.btn_clear_all.Enable = true
				end
			end
			current_selected_item_class = 1
			current_selected_ibtn_index	= index
			L_LobbyMain.ChangeAvatarPart()
		end,

		EventMouseRightDown = function(sender, e)
			if tuozhuai_ui == nil then
				tuozhuai_ui = Gui.Create(L_LobbyMain.LobbyMainWin.LobbyMain_Root)(tuozhuai)
			end
			index_tz = index
			tuozhuai_ui.root.Visible = true
			local lobby_state = ptr_cast(game.CurrentState)
			local cursor_ScreenSize = lobby_state:GetScreenSize()
			local cursor_pos = lobby_state:GetCursorPos()
			tuozhuai_ui.Image.Location = Vector2(cursor_pos.x-((cursor_ScreenSize.x - cursor_ScreenSize.y / 3 * 4) / 2) - 99, cursor_pos.y - 38)
			tuozhuai_ui.Image.Size = Vector2(168, 76)
			-- 颜色
			if L_LobbyMain.ShoppingMallIB_rpc_data.items[index].color >= 1 and L_LobbyMain.ShoppingMallIB_rpc_data.items[index].color <= 8 then
				tuozhuai_ui.Image.Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ibt_icon/"..L_LobbyMain.ShoppingMallIB_rpc_data.items[index].name.."_"..L_LobbyMain.ShoppingMallIB_rpc_data.items[index].color..".tga", Vector4(0, 0, 0, 0)),
				}
			else
				tuozhuai_ui.Image.Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ibt_icon/"..L_LobbyMain.ShoppingMallIB_rpc_data.items[index].name..".tga", Vector4(0, 0, 0, 0)),
				}
			end
			local ibbtn = ptr_cast(ib_weapon_ui.ctrl_ib_container:GetChildByIndex(index-1))
			ibbtn.ItemIcon.alpha = 80
			Highlight_weapon_tip(index)
			
		end,

		EventMouseEnter = function(sender, e)
			if sender.Loading == false then
				L_ToolTips.FillToolTipsWindow(2, index, sender)
			end
		end,
		EventToolTipsShow = function(sender, e)
			L_ToolTips.ShowToolTipsShowWindowContrast(sender)
		end,
		EventMouseLeave = function(sender, e)
			L_ToolTips.HideToolTipsWindow()
		end,

		EventBtnClick = function()
			if L_LobbyMain.LobbyMainWin.LobbyMain_Root_Parent then
				current_selected_ibtn_index = index
				if L_LobbyMain.ShoppingMallIB_rpc_data.items[index].common.is_vip == 1 and L_LobbyMain.PersonalInfo_data.isvip == 0 then
					MessageBox.ShowWithConfirm(lang:GetText("您不是VIP，无法购买"))
				else
					setup_buy_and_present_window(L_LobbyMain.LobbyMainWin.LobbyMain_Root_Parent)
				end
				if buy_and_present_ui then
					buy_and_present_ui.play_list.Visible = false
				end
			end
		end,
	}
end

local weapon_info_page =
{
	Gui.Control "ctrl_ib_container"
	{							
		Size = Vector2(424, 400),
		Location = Vector2(19, 55),
		BackgroundColor = ARGB(0, 255, 255, 255),
		
		create_weapon_page(1, 0, 0),
		create_weapon_page(2, 1, 0),
		
		create_weapon_page(3, 0, 1),
		create_weapon_page(4, 1, 1),
		
		create_weapon_page(5, 0, 2),
		create_weapon_page(6, 1, 2),
		
		create_weapon_page(7, 0, 3),
		create_weapon_page(8, 1, 3),
	},
}

function SpawnNewWeaponButton()
	local newbutton = Gui.Create(gui)
	{
		--赠送
		Gui.Button "ib_donate"
		{	
			Visible = false,
			Location = Vector2(212 - 85,100 - 28),
			Size = Vector2(40,25),
			Skin = Skin.ButtonSkin_ItemBoxBtn_gift,
				
			EventClick = function(Sender,e)
				local ibbtn = nil
				local index = 1
				for i = 1, 8 do
					ibbtn = ptr_cast(ib_weapon_ui.ctrl_ib_container:GetChildByIndex(i-1))
					if Sender.Parent == ibbtn then
						index = i
						break
					end						
				end
				
				if L_LobbyMain.LobbyMainWin.LobbyMain_Root_Parent then
					current_selected_ibtn_index = index
					setup_buy_and_present_window(L_LobbyMain.LobbyMainWin.LobbyMain_Root_Parent)
				end
				
				if buy_and_present_ui then
					buy_and_present_ui.lbl_present_to.Visible = true
					buy_and_present_ui.cbx_friends_present.Visible = true
					buy_and_present_ui.lbl_balance_mode.Location = Vector2(306, 6)
					buy_and_present_ui.btn_front_page.Location = Vector2(323, 7)
					buy_and_present_ui.lb_page_number.Location = Vector2(386, 6)
					buy_and_present_ui.btn_next_page.Location = Vector2(408, 7)
					
					buy_and_present_ui.lbl_spend_point.Text = ""
					buy_and_present_ui.btn_buy_and_balance.PushDown = false
					buy_and_present_ui.btn_buy_and_present.PushDown = true
					buy_and_present_ui.cbox_buy_and_equip.Visible = false
					buy_and_present_ui.lbl_buy_and_equip.Visible = false
					buy_and_present_ui.btn_three_days.PushDown = true
					buy_and_present_ui.btn_senven_days.PushDown = false
					buy_and_present_ui.btn_thirty_days.PushDown = false
					buy_and_present_ui.btn_forever.PushDown = false
					buy_and_present_ui.play_list.Visible = true
					buy_and_present_ui.btn_buy.Text = lang:GetText("赠送")
					buy_and_present_ui.cbx_friends_present.Text = ""
					
					FillPresentWindow()
				end
			end
		},
	}
	return newbutton
end

function SpawnNewWeaponControl()
	local newcontrol = Gui.Create(gui)
	{
		Gui.Control "ib_Compose"
		{		
			Visible = false,
			Size = Vector2(54,30),
			Location = Vector2(212 - 60,100 - 57),
			BackgroundColor = ARGB(255, 255, 255, 255),
		},
	}
	return newcontrol
end

--武器界面
local function setup_ib_weapon(parent_window)
	if ib_dress_ui then
		ib_dress_ui.ctrl_ib_container.Parent = nil
	end

	if ib_accessories_ui then
		ib_accessories_ui.ctrl_ib_container.Parent = nil
	end

	--界面是否存在
	if ib_weapon_ui then
		ib_weapon_ui.ctrl_ib_container.Parent = parent_window
		return
	end
	--创建界面
	ib_weapon_ui = Gui.Create(parent_window)(weapon_info_page)
	
	for i = 1, 8 do
		local ibbtn = ptr_cast(ib_weapon_ui.ctrl_ib_container:GetChildByIndex(i-1))
		local newbutton = SpawnNewWeaponButton()
		local Control = SpawnNewWeaponControl()
		local Star = SpawnNewStarControl()
		ibbtn.ItemBtnSkin = Skin.ButtonSkin_ItemBoxBtn_buy
		ibbtn.BtnSize = Vector2(40,25)
		ibbtn.BtnLocation = Vector2(212 - 45,100-28)
		newbutton.ib_donate.Parent = ibbtn
		Control.ib_Compose.Parent = ibbtn
		Star.ib_star.Parent = ibbtn
	end
end

--------------------------------------------------------------------------------------------
--购物车界面 
local user_bag_info_page =
{
	Gui.Control "ctrl_ib_container"
	{							
		Size = Vector2(180, 400),
		Location = Vector2(0, 45),
		BackgroundColor = ARGB(0, 255, 255, 255),
		
		--主武器
		Gui.ItemBoxBtn "ib_primary_weapon"
		{
			Style = "Gui.ItemBoxBtn_destory",
			Size = Vector2(175, 80),
			Location = Vector2(4, 0),
			BtnVisible = false,
			BtnLocation = Vector2(145, 50),
			Enable = false,
			Padding = Vector4(0, 0, 0, 4),
			
			Skin = Gui.ItemBoxBtnSkin
			{
				NeutralNormalImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche1_normal.dds", Vector4(10, 10, 10, 10)),
				NeutralHoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche1_hover.dds", Vector4(10, 10, 10, 10)),
				NeutralSelectedImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_wuqi_down.dds", Vector4(10, 10, 10, 10)),
				NeutralDisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_caowei_zhuwuqi.dds", Vector4(10, 10, 10, 10)),
				NeutralHighlightImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche1_hover.dds", Vector4(20, 20, 20, 20)),
			},
			
			--event function 
			EventSelected = function(sender, e)
				if user_bag_info_ui and sender.Loading == false then
					for i = 1, 7 do
						local ibbtn = ptr_cast(user_bag_info_ui.ctrl_ib_container:GetChildByIndex(i-1))

						if i == 1 then
							ibbtn.Selected = true
						else
							ibbtn.Selected = false
						end
					end
				end
				current_selected_item_class = 0
				current_selected_ibtn_index	= 1
				L_LobbyMain.ChangeAvatarPart()
			end,

			EventDoubleClick = function(sender, e)
				--doubleAction(sender)
			end,

			EventMouseEnter = function(sender, e)
				if sender.Loading == false then
					L_ToolTips.FillToolTipsWindow(4, 1, sender)
				end
			end,
			EventToolTipsShow = function(sender, e)
				L_ToolTips.ShowToolTipsShowWindow(sender)
			end,
			EventMouseLeave = function(sender, e)
				L_ToolTips.HideToolTipsWindow()
			end,

			EventBtnClick = function(sender, e)
				--L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class][1].common.rareLevel = 0
				L_LobbyMain.RemoveShoppingCart(1)
				L_LobbyMain.FillShoppingCart()
				sender.Selected = false
				Getshoppingcar_window_count()
				if shoppingcar_window_count == 0 then
					user_bag_ui.btn_buy_all.Enable = false
					user_bag_ui.btn_clear_all.Enable = false
					CloseShoppingCarBuyWin()
				end
				ItemLevel = nil
			end,
		},

		--副武器
		Gui.ItemBoxBtn "ib_secondary_weapon"
		{
			Style = "Gui.ItemBoxBtn_destory",
			Size = Vector2(175, 80),
			Location = Vector2(4, 80),
			BtnVisible = false,
			BtnLocation = Vector2(145, 50),
			Enable = false,
			Padding = Vector4(0, 0, 0, 4),

			--event function 
			EventSelected = function(sender, e)
				if user_bag_info_ui and sender.Loading == false then
					for i = 1, 7 do
						local ibbtn = ptr_cast(user_bag_info_ui.ctrl_ib_container:GetChildByIndex(i-1))

						if i == 2 then
							ibbtn.Selected = true
						else
							ibbtn.Selected = false
						end
					end
				end
				current_selected_item_class = 0
				current_selected_ibtn_index	= 2
				L_LobbyMain.ChangeAvatarPart()
			end,
			BtnVisible = true,
			Skin = Gui.ItemBoxBtnSkin
			{
				NeutralNormalImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche1_normal.dds", Vector4(10, 10, 10, 10)),
				NeutralHoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche1_hover.dds", Vector4(10, 10, 10, 10)),
				NeutralSelectedImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_wuqi_down.dds", Vector4(10, 10, 10, 10)),
				NeutralDisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_caowei_fuwuqi.dds", Vector4(10, 10, 10, 10)),
				NeutralHighlightImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche1_hover.dds", Vector4(20, 20, 20, 20)),
			},
			
			EventDoubleClick = function(sender, e)
				--doubleAction(sender)
			end,

			EventMouseEnter = function(sender, e)
				if sender.Loading == false then
					L_ToolTips.FillToolTipsWindow(4, 2, sender)
				end
			end,
			EventToolTipsShow = function(sender, e)
				L_ToolTips.ShowToolTipsShowWindow(sender)
			end,
			EventMouseLeave = function(sender, e)
				L_ToolTips.HideToolTipsWindow()
			end,

			EventBtnClick = function(sender, e)
				--L_LobbyMain.CharactersCartInfo[current_choose_class][2].common.rareLevel = 0
				sender.Selected = false
				L_LobbyMain.RemoveShoppingCart(2)
				L_LobbyMain.FillShoppingCart()
				Getshoppingcar_window_count()
				if shoppingcar_window_count == 0 then
					user_bag_ui.btn_buy_all.Enable = false
					user_bag_ui.btn_clear_all.Enable = false
					CloseShoppingCarBuyWin()
				end
				ItemLevel = nil
			end,
		},

		--手雷
		Gui.ItemBoxBtn "ib_grenade"
		{
			Style = "Gui.ItemBoxBtn_destory",
			BtnVisible = false,
			Size = Vector2(88, 80),
			Location = Vector2(4, 160),
			BtnLocation = Vector2(58, 54),
			Enable = false,
			
			Skin = Gui.ItemBoxBtnSkin
			{
				NeutralNormalImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche2_normal.dds", Vector4(10, 10, 10, 10)),
				NeutralHoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche2_hover.dds", Vector4(10, 10, 10, 10)),
				NeutralSelectedImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_wuqi_down.dds", Vector4(10, 10, 10, 10)),
				NeutralDisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_caowei_teshuwuqi.dds", Vector4(10, 10, 10, 10)),
				NeutralHighlightImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche2_hover.dds", Vector4(20, 20, 20, 20)),
			},
			
			--event function 
			EventSelected = function(sender, e)
				if user_bag_info_ui and sender.Loading == false then
					for i = 1, 7 do
						local ibbtn = ptr_cast(user_bag_info_ui.ctrl_ib_container:GetChildByIndex(i-1))

						if i == 3 then
							ibbtn.Selected = true
						else
							ibbtn.Selected = false
						end
					end
				end
				current_selected_item_class = 0
				current_selected_ibtn_index	= 3
				L_LobbyMain.ChangeAvatarPart()
			end,

			EventDoubleClick = function(sender, e)
				--doubleAction(sender)
			end,
		
			EventMouseEnter = function(sender, e)
				if sender.Loading == false then
					L_ToolTips.FillToolTipsWindow(4, 3, sender)
				end
			end,
			EventToolTipsShow = function(sender, e)
				L_ToolTips.ShowToolTipsShowWindow(sender)
			end,
			EventMouseLeave = function(sender, e)
				L_ToolTips.HideToolTipsWindow()
			end,

			EventBtnClick = function(sender, e)
				--L_LobbyMain.CharactersCartInfo[current_choose_class][4].common.rareLevel = 0
				sender.Selected = false
				L_LobbyMain.RemoveShoppingCart(3)
				L_LobbyMain.FillShoppingCart()
				Getshoppingcar_window_count()
				if shoppingcar_window_count == 0 then
					user_bag_ui.btn_buy_all.Enable = false
					user_bag_ui.btn_clear_all.Enable = false
					CloseShoppingCarBuyWin()
				end
				ItemLevel = nil
			end,
		},

		--近身武器
		Gui.ItemBoxBtn "ib_melee_weapons"
		{
			Style = "Gui.ItemBoxBtn_destory",
			BtnVisible = false,
			Size = Vector2(88, 80),
			Location = Vector2(92, 160),
			BtnLocation = Vector2(58, 54),
			Enable = false,

			Skin = Gui.ItemBoxBtnSkin
			{
				NeutralNormalImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche2_normal.dds", Vector4(10, 10, 10, 10)),
				NeutralHoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche2_hover.dds", Vector4(10, 10, 10, 10)),
				NeutralSelectedImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_wuqi_down.dds", Vector4(10, 10, 10, 10)),
				NeutralDisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_caowei_jinshenwuqi.dds", Vector4(10, 10, 10, 10)),
				NeutralHighlightImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche2_hover.dds", Vector4(20, 20, 20, 20)),
			},
			
			--event function 
			EventSelected = function(sender, e)
				if user_bag_info_ui and sender.Loading == false then
					for i = 1, 7 do
						local ibbtn = ptr_cast(user_bag_info_ui.ctrl_ib_container:GetChildByIndex(i-1))

						if i == 4 then
							ibbtn.Selected = true
						else
							ibbtn.Selected = false
						end
					end
				end
				current_selected_item_class = 0
				current_selected_ibtn_index	= 4
				L_LobbyMain.ChangeAvatarPart()
			end,

			EventDoubleClick = function(sender, e)
				--doubleAction(sender)
			end,

			EventMouseEnter = function(sender, e)
				if sender.Loading == false then
					L_ToolTips.FillToolTipsWindow(4, 4, sender)
				end
			end,
			EventToolTipsShow = function(sender, e)
				L_ToolTips.ShowToolTipsShowWindow(sender)
			end,
			EventMouseLeave = function(sender, e)
				L_ToolTips.HideToolTipsWindow()
			end,

			EventBtnClick = function(sender, e)
				--L_LobbyMain.CharactersCartInfo[current_choose_class][3].common.rareLevel = 0
				sender.Selected = false
				L_LobbyMain.RemoveShoppingCart(4)
				L_LobbyMain.FillShoppingCart()
				Getshoppingcar_window_count()
				if shoppingcar_window_count == 0 then
					user_bag_ui.btn_buy_all.Enable = false
					user_bag_ui.btn_clear_all.Enable = false
					CloseShoppingCarBuyWin()
				end
				ItemLevel = nil
			end,
		},

		--还未使用
		Gui.ItemBoxBtn "ib_no_use"
		{
			Style = "Gui.ItemBoxBtn_destory",
			BtnVisible = false,
			Size = Vector2(88, 160),
			Location = Vector2(4, 240),
			BtnLocation = Vector2(58, 134),
			Enable = false,

			Skin = Gui.ItemBoxBtnSkin
			{
				NeutralNormalImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche3_normal.dds", Vector4(10, 10, 10, 10)),
				NeutralHoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche3_hover.dds", Vector4(10, 10, 10, 10)),
				NeutralSelectedImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_wuqi_down.dds", Vector4(10, 10, 10, 10)),
				NeutralDisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_caowei_juese.dds", Vector4(10, 10, 10, 10)),
				NeutralHighlightImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche3_hover.dds", Vector4(20, 20, 20, 20)),
			},
			
			--event function 
			EventSelected = function(sender, e)
				if user_bag_info_ui and sender.Loading == false then
					for i = 1, 7 do
						local ibbtn = ptr_cast(user_bag_info_ui.ctrl_ib_container:GetChildByIndex(i-1))

						if i == 5 then
							ibbtn.Selected = true
						else
							ibbtn.Selected = false
						end
					end
				end
				current_selected_item_class = 0
				current_selected_ibtn_index	= 5
				L_LobbyMain.ChangeAvatarPart()
			end,

			EventDoubleClick = function(sender, e)
				--doubleAction(sender)
			end,

			EventMouseEnter = function(sender, e)
				if sender.Loading == false then
					L_ToolTips.FillToolTipsWindow(4, 5, sender)
				end
			end,
			EventToolTipsShow = function(sender, e)
				L_ToolTips.ShowToolTipsShowWindow(sender)
			end,
			EventMouseLeave = function(sender, e)
				L_ToolTips.HideToolTipsWindow()
			end,

			EventBtnClick = function(sender, e)
				--L_LobbyMain.CharactersCartInfo[current_choose_class][5].common.rareLevel = 0
				sender.Selected = false
				L_LobbyMain.RemoveShoppingCart(5)
				L_LobbyMain.FillShoppingCart()
				Getshoppingcar_window_count()
				if shoppingcar_window_count == 0 then
					user_bag_ui.btn_buy_all.Enable = false
					user_bag_ui.btn_clear_all.Enable = false
					CloseShoppingCarBuyWin()
				end
				ItemLevel = nil
			end,
		},

		--帽子
		Gui.ItemBoxBtn "ib_hat"
		{
			Style = "Gui.ItemBoxBtn_destory",
			Size = Vector2(88, 80),
			Location = Vector2(92, 240),
			BtnVisible = false,
			BtnLocation = Vector2(58, 54),
			Enable = false,

			--event function 
			EventSelected = function(sender, e)
				if user_bag_info_ui and sender.Loading == false then
					for i = 1, 7 do
						local ibbtn = ptr_cast(user_bag_info_ui.ctrl_ib_container:GetChildByIndex(i-1))

						if i == 6 then
							ibbtn.Selected = true
						else
							ibbtn.Selected = false
						end
					end
				end
				current_selected_item_class = 0
				current_selected_ibtn_index	= 6
				L_LobbyMain.ChangeAvatarPart()
			end,

			Skin = Gui.ItemBoxBtnSkin
			{
				NeutralNormalImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche2_normal.dds", Vector4(10, 10, 10, 10)),
				NeutralHoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche2_hover.dds", Vector4(10, 10, 10, 10)),
				NeutralSelectedImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_wuqi_down.dds", Vector4(10, 10, 10, 10)),
				NeutralDisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_caowei_maozi.dds", Vector4(10, 10, 10, 10)),
				NeutralHighlightImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche2_hover.dds", Vector4(20, 20, 20, 20)),
			},
			
			EventDoubleClick = function(sender, e)
				--doubleAction(sender)
			end,

			EventMouseEnter = function(sender, e)
				if sender.Loading == false then
					L_ToolTips.FillToolTipsWindow(4, 6, sender)
				end
			end,
			EventToolTipsShow = function(sender, e)
				L_ToolTips.ShowToolTipsShowWindow(sender)
			end,
			EventMouseLeave = function(sender, e)
				L_ToolTips.HideToolTipsWindow()
			end,

			EventBtnClick = function(sender, e)
				--L_LobbyMain.CharactersCartInfo[current_choose_class][6].common.rareLevel = 0
				sender.Selected = false
				L_LobbyMain.RemoveShoppingCart(6)
				L_LobbyMain.FillShoppingCart()
				Getshoppingcar_window_count()
				if shoppingcar_window_count == 0 then
					user_bag_ui.btn_buy_all.Enable = false
					user_bag_ui.btn_clear_all.Enable = false
					CloseShoppingCarBuyWin()
				end
				ItemLevel = nil
			end,
		},

		Gui.ItemBoxBtn "ib_last"
		{
			Style = "Gui.ItemBoxBtn_destory",
			BtnVisible = false,
			Size = Vector2(88, 80),
			Location = Vector2(92, 320),
			BtnLocation = Vector2(58, 54),
			Enable = false,

			--event function 
			EventSelected = function(sender, e)
				if user_bag_info_ui and sender.Loading == false then
					for i = 1, 7 do
						local ibbtn = ptr_cast(user_bag_info_ui.ctrl_ib_container:GetChildByIndex(i-1))

						if i == 7 then
							ibbtn.Selected = true
						else
							ibbtn.Selected = false
						end
					end
				end
				current_selected_item_class = 0
				current_selected_ibtn_index	= 7
				L_LobbyMain.ChangeAvatarPart()
			end,

			Skin = Gui.ItemBoxBtnSkin
			{
				NeutralNormalImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche2_normal.dds", Vector4(10, 10, 10, 10)),
				NeutralHoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche2_hover.dds", Vector4(10, 10, 10, 10)),
				NeutralSelectedImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_wuqi_down.dds", Vector4(10, 10, 10, 10)),
				NeutralDisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_caowei_huizhang.dds", Vector4(10, 10, 10, 10)),
				NeutralHighlightImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche2_hover.dds", Vector4(20, 20, 20, 20)),
			},
			
			EventDoubleClick = function(sender, e)
				--doubleAction(sender)
			end,

			EventMouseEnter = function(sender, e)
				if sender.Loading == false then
					L_ToolTips.FillToolTipsWindow(4, 7, sender)
				end
			end,
			EventToolTipsShow = function(sender, e)
				L_ToolTips.ShowToolTipsShowWindow(sender)
			end,
			EventMouseLeave = function(sender, e)
				L_ToolTips.HideToolTipsWindow()
			end,

			EventBtnClick = function(sender, e)
				--L_LobbyMain.CharactersCartInfo[current_choose_class][7].common.rareLevel = 0
				sender.Selected = false
				L_LobbyMain.RemoveShoppingCart(7)
				L_LobbyMain.FillShoppingCart()
				Getshoppingcar_window_count()
				if shoppingcar_window_count == 0 then
					user_bag_ui.btn_buy_all.Enable = false
					user_bag_ui.btn_clear_all.Enable = false
					CloseShoppingCarBuyWin()
				end
				ItemLevel = nil
			end,
		},
	},
}

local function setup_user_bag(parent_window)
	--界面是否存在
	if user_bag_info_ui then
		user_bag_info_ui.Parent = parent_window
		return
	end
	--创建界面
	user_bag_info_ui = Gui.Create(parent_window)(user_bag_info_page)
	InitAllCharacterBagItemBoxBtnEvent()
end

local user_bag_window =
{
	Gui.Control "ctrl_shopping_cart_Main"
	{							
		Size = Vector2(180, 507),
		Location = Vector2(0, 0),
		BackgroundColor = ARGB(0, 255, 255, 255),
		
		--购物车
		-- Gui.Control
		-- {
			-- Size = Vector2(48, 28),
			-- Location = Vector2(70, 7),
			-- BackgroundColor = ARGB(255, 255, 255, 255),
			-- Skin = Gui.ControlSkin
			-- {
				-- BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_taitou.dds"),
			-- },
		-- },

		Gui.Label
		{
			Size = Vector2(160, 30),
			Text = lang:GetText("购物车"),
			FontSize = 17,
			Location = Vector2(11, 8),
			TextColor = ARGB(255, 159, 155, 155),
			BackgroundColor = ARGB(0, 255, 255, 255),
			TextAlign = "kAlignCenterMiddle",
		},
		
		--清空
		Gui.Button "btn_clear_all"
		{
			Size = Vector2(48, 37),
			Location = Vector2(130, 445),
			Text = lang:GetText("清空"),
			TextAlign = "kAlignCenterMiddle",
			TextColor = ARGB(255, 0, 0, 0),
			FontSize = 16,
			Enable = false,
			Padding = Vector4(0, 0, 0, 3),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button04_normal.dds", Vector4(10, 10, 10, 10)),
				HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button04_hover.dds", Vector4(10, 10, 10, 10)),
				DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button04_down.dds", Vector4(10, 10, 10, 10)),
				DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button04_normal.dds", Vector4(10, 10, 10, 10)),
			},
			EventClick = function()
				for i = 1 ,7 do
					L_LobbyMain.RemoveShoppingCart(i)
				end
				L_LobbyMain.FillShoppingCart()
				user_bag_ui.btn_buy_all.Enable = false
				user_bag_ui.btn_clear_all.Enable = false
				shoppingcar_window_count = 0
				if user_bag_info_ui then
					for i = 1, 7 do
						local ibbtn = ptr_cast(user_bag_info_ui.ctrl_ib_container:GetChildByIndex(i-1))						
						ibbtn.Selected = false
					end
				end
			end
		},

		--全部购买
		Gui.Button "btn_buy_all"
		{
			Size = Vector2(122, 37),
			Location = Vector2(6, 445),
			Enable = false,
			TextAlign = "kAlignRightMiddle",
			Text = lang:GetText("全部购买"),
			Padding = Vector4(0,0,10,3),
			FontSize = 16,
			TextColor = ARGB(255, 0, 0, 0),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button_purchase_normal.dds", Vector4(10, 10, 10, 10)),
				HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button_purchase_hover.dds", Vector4(10, 10, 10, 10)),
				DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button_purchase_down.dds", Vector4(10, 10, 10, 10)),
				DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button_purchase_disable.dds", Vector4(10, 10, 10, 10)),
			},
			EventClick = function()
				if L_LobbyMain.LobbyMainWin.LobbyMain_Root_Parent then
					setup_shoppingcar_window(L_LobbyMain.LobbyMainWin.LobbyMain_Root_Parent)
				end
			end
		},
	},
}

function ShowUserBag(win_parent)
	--界面是否存在
	if user_bag_ui then
		user_bag_ui.ctrl_shopping_cart_Main.Parent = win_parent
		return
	end
	--创建界面
	user_bag_ui = Gui.Create(win_parent)(user_bag_window)
end

local packge_window =
{
	Gui.Control "ctrl_Packge_Main_1"
	{							
		Size = Vector2(459, 458),
		Location = Vector2(631, 115),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg3.dds", Vector4(22, 22, 22, 22)),
		},
	},
	Gui.Control "ctrl_Packge_Main"
	{							
		Size = Vector2(459, 500),
		Location = Vector2(631, 69),
		BackgroundColor = ARGB(0, 255, 255, 255),

		Gui.Control "ctrl_btn_container"
		{							
			Size = Vector2(417, 56),
			Location = Vector2(9, -2),
			BackgroundColor = ARGB(0, 255, 255, 255),

			--武器
			Gui.Button "btn_Weapon"
			{
				Size = Vector2(92, 56),
				Location = Vector2(24, 0),
				PushDown = true,
				Skin = Skin.ButtonSkin_Weapon,
				
				EventClick = function()
					if L_LobbyMain.current_shoppingmall_storage ~= 1 then
						FilterMonChange(packge_main_ui,0)
						L_LobbyMain.current_shoppingmall_storage = 1
						if packge_main_ui then
							packge_main_ui.btn_Weapon.PushDown = true
							packge_main_ui.btn_Dress.PushDown = false
							packge_main_ui.btn_Accessories.PushDown = false
						end
						if ib_dress_ui then
							ib_dress_ui.ctrl_ib_container.Parent = nil
						end
						if ib_accessories_ui then
							ib_accessories_ui.ctrl_ib_container.Parent = nil
						end
						if packge_main_ui then
							setup_ib_weapon(packge_main_ui.ctrl_Packge_Main)
						end
						fill_cbx_Weapon_Type(packge_main_ui.cbx_Filter_Type,Fileter_Weapon_Type)
						--L_LobbyMain.FillShoppingMallIB()
					end
				end,
			},

			--服装
			Gui.Button "btn_Dress"
			{
				Size = Vector2(92, 56),
				Location = Vector2(116, 0),
				Skin = Skin.ButtonSkin_Clothes,
				
				EventClick = function()
					if L_LobbyMain.current_shoppingmall_storage ~= 2 then
						FilterMonChange(packge_main_ui,0)
						L_LobbyMain.current_shoppingmall_storage = 2
						if packge_main_ui then
							packge_main_ui.btn_Weapon.PushDown = false
							packge_main_ui.btn_Dress.PushDown = true
							packge_main_ui.btn_Accessories.PushDown = false
						end
						if ib_weapon_ui then
							ib_weapon_ui.ctrl_ib_container.Parent = nil
						end
						if ib_accessories_ui then
							ib_accessories_ui.ctrl_ib_container.Parent = nil
						end
						if packge_main_ui then									
							setup_ib_dress(packge_main_ui.ctrl_Packge_Main)
						end
						fill_cbx_Weapon_Type(packge_main_ui.cbx_Filter_Type,Fileter_Dress_Type)
						--L_LobbyMain.FillShoppingMallIB()
					end
				end
			},

			--配饰
			Gui.Button "btn_Accessories"
			{
				Size = Vector2(92, 56),
				Location = Vector2(208, 0),
				Skin = Skin.ButtonSkin_Hat,
				
				EventClick = function()
					if L_LobbyMain.current_shoppingmall_storage ~= 3 then
						FilterMonChange(packge_main_ui,0)
						L_LobbyMain.current_shoppingmall_storage = 3
						if packge_main_ui then
							packge_main_ui.btn_Weapon.PushDown = false
							packge_main_ui.btn_Dress.PushDown = false
							packge_main_ui.btn_Accessories.PushDown = true
						end

						if ib_weapon_ui then
							ib_weapon_ui.ctrl_ib_container.Parent = nil
						end

						if ib_dress_ui then
							ib_dress_ui.ctrl_ib_container.Parent = nil
						end

						if packge_main_ui then
							setup_ib_accessories(packge_main_ui.ctrl_Packge_Main)
						end
						fill_cbx_Weapon_Type(packge_main_ui.cbx_Filter_Type,Fileter_Accessories_Type)
						--L_LobbyMain.FillShoppingMallIB()
					end
				end
			},
		},
		
		Gui.ComboBox "cbx_Filter_Type"
		{
			Size = Vector2(126, 28),
			FontSize = 14,
			Readonly = true,
			Location = Vector2(330, 18),
			TextColor = ARGB(255,37,37,37),
			TextAlign = "kAlignCenterMiddle",
			TextPadding = Vector4(6,4,2,6),
			LikeButton = true,
			Skin = Gui.ComboBoxSkin
			{
				ButtonNormalImage= Gui.Image("LobbyUI/ShoppingMall/lb_filter_combobox_button_normal.dds", Vector4(0, 0, 0, 0)),
				ButtonHoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_filter_combobox_button_hover.dds", Vector4(0, 0, 0, 0)),
				ButtonDownImage = Gui.Image("LobbyUI/ShoppingMall/lb_filter_combobox_button_down.dds", Vector4(0, 0, 0, 0)),
				
				TextNormalImage= Gui.Image("LobbyUI/ShoppingMall/lb_filter_combobox_bg_normal.dds", Vector4(6, 6, 0, 6)),
				TextHoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_filter_combobox_bg_hover.dds", Vector4(6, 6, 0, 6)),
				TextDownImage = Gui.Image("LobbyUI/ShoppingMall/lb_filter_combobox_bg_down.dds", Vector4(6, 6, 0, 6)),
			},
			ChildComboListStyle =  "Gui.teamComboList",
			
			EventValueChanged = function(sender, args)
				if main_window_Creat == true then
					main_window_Creat = false
					return
				end
				L_LobbyMain.CurrentShoppingMallPages[L_LobbyMain.current_choose_class][L_LobbyMain.current_shoppingmall_storage] = 1
				if main_props_window_ui and main_character_window_ui.btn_Property.PushDown == true then
					if main_props_window_ui.btn_tuijian.PushDown == true then
						L_LobbyMain.current_shoppingmall_storage = 10
						L_LobbyMain.FillShoppingMallIB(0)
					elseif main_props_window_ui.btn_gongneng.PushDown == true then	
						L_LobbyMain.current_shoppingmall_storage = 4
						L_LobbyMain.FillShoppingMallIB(4)
					elseif main_props_window_ui.btn_hecheng.PushDown == true then
						L_LobbyMain.current_shoppingmall_storage = 5
						L_LobbyMain.FillShoppingMallIB(1)
					elseif main_props_window_ui.btn_xiaohao.PushDown == true then
						L_LobbyMain.current_shoppingmall_storage = 4
						L_LobbyMain.FillShoppingMallIB(7)
					elseif main_props_window_ui.btn_jiacheng.PushDown == true then
						L_LobbyMain.current_shoppingmall_storage = 4
						L_LobbyMain.FillShoppingMallIB(1)
					elseif main_props_window_ui.btn_lantu.PushDown == true then
						L_LobbyMain.current_shoppingmall_storage = 5
						L_LobbyMain.FillShoppingMallIB(2)
					elseif main_props_window_ui.btn_mingpian.PushDown == true then
						L_LobbyMain.current_shoppingmall_storage = 4
						L_LobbyMain.FillShoppingMallIB(2)
					end
				else
					L_LobbyMain.FillShoppingMallIB()
				end	
			end,
		},
		
--[[		Gui.RadioGroup "Filter_rg"
		{
			Size = Vector2(300, 25),
			Location = Vector2(20, 460),
			ControlSpace = 5,
			LineSpace = 5,
			TextColor = ARGB(255, 37, 37, 37),
			Visible = false,
			
			Gui.RadioButton "bt1"
			{
				Size = Vector2(70, 24),
				FontSize = 16,
				TextColor = ARGB(255, 243, 224, 207),
				Text = lang:GetText("全部"),
				ID = 0,
				
				Skin = Gui.CheckBoxSkin
				{
					OnImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_radiobutton_down.dds", Vector4(0, 0, 0, 0)),
					OffImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_radiobutton_normal.dds", Vector4(0, 0, 0, 0)),
					OnDisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_radiobutton_down.dds", Vector4(0, 0, 0, 0)),
					OffDisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_radiobutton_normal.dds", Vector4(0, 0, 0, 0)),
				},
			},

			Gui.RadioButton "bt2"
			{
				Size = Vector2(100, 24),
				FontSize = 16,
				TextColor = ARGB(255, 243, 224, 207),
				Text = lang:GetText("    FC点"),
				ID = 1,	

				Skin = Gui.CheckBoxSkin
				{
					OnImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_radiobutton_down.dds", Vector4(0, 0, 0, 0)),
					OffImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_radiobutton_normal.dds", Vector4(0, 0, 0, 0)),
					OnDisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_radiobutton_down.dds", Vector4(0, 0, 0, 0)),
					OffDisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_radiobutton_normal.dds", Vector4(0, 0, 0, 0)),
				},
			},
			
			Gui.RadioButton "bt3"
			{
				Size = Vector2(100, 24),
				FontSize = 16,
				TextColor = ARGB(255, 243, 224, 207),
				Text = lang:GetText("    C币"),
				ID = 2,	
				
				Skin = Gui.CheckBoxSkin
				{
					OnImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_radiobutton_down.dds", Vector4(0, 0, 0, 0)),
					OffImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_radiobutton_normal.dds", Vector4(0, 0, 0, 0)),
					OnDisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_radiobutton_down.dds", Vector4(0, 0, 0, 0)),
					OffDisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_radiobutton_normal.dds", Vector4(0, 0, 0, 0)),
				},
			},

			EventRadioChanged = function(sender, args)
				L_LobbyMain.CurrentShoppingMallPages[L_LobbyMain.current_choose_class][L_LobbyMain.current_shoppingmall_storage] = 1
				L_LobbyMain.FillShoppingMallIB()
			end
		},
]]		
		Gui.Button "BTN_bt0"
		{
			Location = Vector2(20, 458),
			Size = Vector2(89, 36),
			BackgroundColor = ARGB(255,255,255,255),
			Text = "   "..lang:GetText("全部"),
			FontSize = 16,
			TextAlign = "kAlignCenterMiddle",
			TextColor = ARGB(255, 243, 224, 207),
			HighlightTextColor = ARGB(255, 37, 37, 37),
			Padding = Vector4(0 ,0 ,0 ,4),
			PushDown = true,
			
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_filter_button_normal.dds", Vector4(26, 5, 5, 5)),
				HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_filter_button_hover.dds", Vector4(26, 5, 5, 5)),
				DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_filter_button_down.dds", Vector4(26, 5, 5, 5)),
				DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_filter_button_normal.dds", Vector4(26, 5, 5, 5)),
			},
			EventClick = function()
				if packge_main_ui.BTN_bt0.PushDown == true then
					return
				end
				FilterMonChange(packge_main_ui,0)
				if main_props_window_ui and main_character_window_ui.btn_Property.PushDown == true then
					if main_props_window_ui.btn_tuijian.PushDown == true then
						L_LobbyMain.current_shoppingmall_storage = 10
						L_LobbyMain.FillShoppingMallIB(0)
					elseif main_props_window_ui.btn_gongneng.PushDown == true then	
						L_LobbyMain.current_shoppingmall_storage = 4
						L_LobbyMain.FillShoppingMallIB(4)
					elseif main_props_window_ui.btn_hecheng.PushDown == true then
						L_LobbyMain.current_shoppingmall_storage = 5
						L_LobbyMain.FillShoppingMallIB(1)
					elseif main_props_window_ui.btn_xiaohao.PushDown == true then
						L_LobbyMain.current_shoppingmall_storage = 4
						L_LobbyMain.FillShoppingMallIB(7)
					elseif main_props_window_ui.btn_jiacheng.PushDown == true then
						L_LobbyMain.current_shoppingmall_storage = 4
						L_LobbyMain.FillShoppingMallIB(1)
					elseif main_props_window_ui.btn_lantu.PushDown == true then
						L_LobbyMain.current_shoppingmall_storage = 5
						L_LobbyMain.FillShoppingMallIB(2)
					elseif main_props_window_ui.btn_mingpian.PushDown == true then
						L_LobbyMain.current_shoppingmall_storage = 4
						L_LobbyMain.FillShoppingMallIB(2)
					end
				else
					L_LobbyMain.FillShoppingMallIB()
				end	
			end,
		},
		
		Gui.Button "BTN_bt1"
		{
			Location = Vector2(112, 458),
			Size = Vector2(93, 36),
			BackgroundColor = ARGB(255,255,255,255),
			FontSize = 16,
			TextAlign = "kAlignCenterMiddle",
			TextColor = ARGB(255, 243, 224, 207),
			HighlightTextColor = ARGB(255, 37, 37, 37),
			Padding = Vector4(0 ,0 ,0 ,4),
			
			Gui.Control
			{
				Size = Vector2(28, 20),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Location = Vector2(26, 7),
				
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_ico_fc.dds", Vector4(0, 0, 0, 0)),
				},
			},
			
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_filter_button_normal.dds", Vector4(26, 5, 5, 5)),
				HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_filter_button_hover.dds", Vector4(26, 5, 5, 5)),
				DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_filter_button_down.dds", Vector4(26, 5, 5, 5)),
				DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_filter_button_normal.dds", Vector4(26, 5, 5, 5)),
			},
			EventClick = function()
				if packge_main_ui.BTN_bt1.PushDown == true then
					return
				end
				FilterMonChange(packge_main_ui,1)
				if main_props_window_ui and main_character_window_ui.btn_Property.PushDown == true then
					if main_props_window_ui.btn_tuijian.PushDown == true then
						L_LobbyMain.current_shoppingmall_storage = 10
						L_LobbyMain.FillShoppingMallIB(0)
					elseif main_props_window_ui.btn_gongneng.PushDown == true then	
						L_LobbyMain.current_shoppingmall_storage = 4
						L_LobbyMain.FillShoppingMallIB(4)
					elseif main_props_window_ui.btn_hecheng.PushDown == true then
						L_LobbyMain.current_shoppingmall_storage = 5
						L_LobbyMain.FillShoppingMallIB(1)
					elseif main_props_window_ui.btn_xiaohao.PushDown == true then
						L_LobbyMain.current_shoppingmall_storage = 4
						L_LobbyMain.FillShoppingMallIB(7)
					elseif main_props_window_ui.btn_jiacheng.PushDown == true then
						L_LobbyMain.current_shoppingmall_storage = 4
						L_LobbyMain.FillShoppingMallIB(1)
					elseif main_props_window_ui.btn_lantu.PushDown == true then
						L_LobbyMain.current_shoppingmall_storage = 5
						L_LobbyMain.FillShoppingMallIB(2)
					elseif main_props_window_ui.btn_mingpian.PushDown == true then
						L_LobbyMain.current_shoppingmall_storage = 4
						L_LobbyMain.FillShoppingMallIB(2)
					end
				else
					L_LobbyMain.FillShoppingMallIB()
				end	
			end,
		},
		
		Gui.Button "BTN_bt2"
		{
			Location = Vector2(208, 458),
			Size = Vector2(89, 36),
			BackgroundColor = ARGB(255,255,255,255),
			FontSize = 16,
			TextAlign = "kAlignCenterMiddle",
			TextColor = ARGB(255, 243, 224, 207),
			HighlightTextColor = ARGB(255, 37, 37, 37),
			Padding = Vector4(0 ,0 ,0 ,4),
			
			Gui.Control
			{
				Size = Vector2(28, 20),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Location = Vector2(30, 7),
				
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_ico_cb.dds", Vector4(0, 0, 0, 0)),
				},
			},
			
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_filter_button_normal.dds", Vector4(26, 5, 5, 5)),
				HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_filter_button_hover.dds", Vector4(26, 5, 5, 5)),
				DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_filter_button_down.dds", Vector4(26, 5, 5, 5)),
				DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_filter_button_normal.dds", Vector4(26, 5, 5, 5)),
			},
			EventClick = function()
				if packge_main_ui.BTN_bt2.PushDown == true then
					return
				end
				FilterMonChange(packge_main_ui,2)
				if main_props_window_ui and main_character_window_ui.btn_Property.PushDown == true then
					if main_props_window_ui.btn_tuijian.PushDown == true then
						L_LobbyMain.current_shoppingmall_storage = 10
						L_LobbyMain.FillShoppingMallIB(0)
					elseif main_props_window_ui.btn_gongneng.PushDown == true then	
						L_LobbyMain.current_shoppingmall_storage = 4
						L_LobbyMain.FillShoppingMallIB(4)
					elseif main_props_window_ui.btn_hecheng.PushDown == true then
						L_LobbyMain.current_shoppingmall_storage = 5
						L_LobbyMain.FillShoppingMallIB(1)
					elseif main_props_window_ui.btn_xiaohao.PushDown == true then
						L_LobbyMain.current_shoppingmall_storage = 4
						L_LobbyMain.FillShoppingMallIB(7)
					elseif main_props_window_ui.btn_jiacheng.PushDown == true then
						L_LobbyMain.current_shoppingmall_storage = 4
						L_LobbyMain.FillShoppingMallIB(1)
					elseif main_props_window_ui.btn_lantu.PushDown == true then
						L_LobbyMain.current_shoppingmall_storage = 5
						L_LobbyMain.FillShoppingMallIB(2)
					elseif main_props_window_ui.btn_mingpian.PushDown == true then
						L_LobbyMain.current_shoppingmall_storage = 4
						L_LobbyMain.FillShoppingMallIB(2)
					end
				else
					L_LobbyMain.FillShoppingMallIB()
				end	
			end,
		},
		
		Gui.Control "ctrl_bottom_container"
		{							
			Size = Vector2(135, 52),
			Location = Vector2(300, 450),
			BackgroundColor = ARGB(0, 255, 255, 255),

			--上一页
			Gui.Button "btn_front_page"
			{
				Size = Vector2(14, 31),
				Location = Vector2(1, 9),
				--Text = "<",
				TextColor = ARGB(255, 255, 246, 235),
				FontSize = 18,
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button05_normal.dds", Vector4(0, 0, 0, 0)),
					HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button05_hover.dds", Vector4(0, 0, 0, 0)),
					DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button05_down.dds", Vector4(0, 0, 0, 0)),
					DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button05_normal.dds", Vector4(0, 0, 0, 0)),
				},
				EventClick = function()
					if L_LobbyMain.CurrentShoppingMallPages[L_LobbyMain.current_choose_class][L_LobbyMain.current_shoppingmall_storage] then
						if L_LobbyMain.CurrentShoppingMallPages[L_LobbyMain.current_choose_class][L_LobbyMain.current_shoppingmall_storage] <= 1 then
							return
						end
						if L_LobbyMain.CurrentShoppingMallPages[L_LobbyMain.current_choose_class][L_LobbyMain.current_shoppingmall_storage] > 1 then
							L_LobbyMain.CurrentShoppingMallPages[L_LobbyMain.current_choose_class][L_LobbyMain.current_shoppingmall_storage] = L_LobbyMain.CurrentShoppingMallPages[L_LobbyMain.current_choose_class][L_LobbyMain.current_shoppingmall_storage] - 1
						else
							L_LobbyMain.CurrentShoppingMallPages[L_LobbyMain.current_choose_class][L_LobbyMain.current_shoppingmall_storage] = 1
						end
						L_LobbyMain.FillShoppingMallIB()						
					end	
					RestAllShoppingMallItemBoxBtn()	
				end
			},
			
			--页码
			Gui.Label "lb_page_number"
			{
				Location = Vector2(30, 9),
				Size = Vector2(75, 31),
				FontSize = 24,
				TextAlign = "kAlignCenterMiddle",
				TextColor = ARGB(255, 103, 102, 98),
				Text = "1/1",
				BackgroundColor = ARGB(255, 255, 255, 255),

				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button06_bg.dds", Vector4(14, 14, 14, 14)),
				},
			},

			--下一页
			Gui.Button "btn_next_page"
			{
				Size = Vector2(14, 31),
				Location = Vector2(120, 9),
				--Text = ">",
				TextColor = ARGB(255, 255, 246, 235),
				FontSize = 18,
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button06_normal.dds", Vector4(0, 0, 0, 0)),
					HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button06_hover.dds", Vector4(0, 0, 0, 0)),
					DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button06_down.dds", Vector4(0, 0, 0, 0)),
					DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button06_normal.dds", Vector4(0, 0, 0, 0)),
				},
				EventClick = function()
					if L_LobbyMain.CurrentShoppingMallPages[L_LobbyMain.current_choose_class][L_LobbyMain.current_shoppingmall_storage] then
						if L_LobbyMain.CurrentShoppingMallPages[L_LobbyMain.current_choose_class][L_LobbyMain.current_shoppingmall_storage] >= L_LobbyMain.ShoppingMallIB_rpc_data.pages then
							return
						end
						if L_LobbyMain.CurrentShoppingMallPages[L_LobbyMain.current_choose_class][L_LobbyMain.current_shoppingmall_storage] < L_LobbyMain.ShoppingMallIB_rpc_data.pages then
							L_LobbyMain.CurrentShoppingMallPages[L_LobbyMain.current_choose_class][L_LobbyMain.current_shoppingmall_storage] = L_LobbyMain.CurrentShoppingMallPages[L_LobbyMain.current_choose_class][L_LobbyMain.current_shoppingmall_storage] + 1
						else
							L_LobbyMain.CurrentShoppingMallPages[L_LobbyMain.current_choose_class][L_LobbyMain.current_shoppingmall_storage] = L_LobbyMain.ShoppingMallIB_rpc_data.pages
						end
						if main_props_window_ui and main_character_window_ui.btn_Property.PushDown == true then
							if main_props_window_ui.btn_tuijian.PushDown == true then
								L_LobbyMain.current_shoppingmall_storage = 10
								L_LobbyMain.FillShoppingMallIB(0)
							elseif main_props_window_ui.btn_gongneng.PushDown == true then	
								L_LobbyMain.current_shoppingmall_storage = 4
								L_LobbyMain.FillShoppingMallIB(4)
							elseif main_props_window_ui.btn_hecheng.PushDown == true then
								L_LobbyMain.current_shoppingmall_storage = 5
								L_LobbyMain.FillShoppingMallIB(1)
							elseif main_props_window_ui.btn_xiaohao.PushDown == true then
								L_LobbyMain.current_shoppingmall_storage = 4
								L_LobbyMain.FillShoppingMallIB(7)
							elseif main_props_window_ui.btn_jiacheng.PushDown == true then
								L_LobbyMain.current_shoppingmall_storage = 4
								L_LobbyMain.FillShoppingMallIB(1)
							elseif main_props_window_ui.btn_lantu.PushDown == true then
								L_LobbyMain.current_shoppingmall_storage = 5
								L_LobbyMain.FillShoppingMallIB(2)
							elseif main_props_window_ui.btn_mingpian.PushDown == true then
								L_LobbyMain.current_shoppingmall_storage = 4
								L_LobbyMain.FillShoppingMallIB(2)
							end
						else
							L_LobbyMain.FillShoppingMallIB()
						end	
					end
					RestAllShoppingMallItemBoxBtn()
				end
			},
		},
	},
}

function ShowPackgeInfo(win_parent)
	--界面是否存在
	if packge_main_ui then
		packge_main_ui.ctrl_Packge_Main.Parent = win_parent
		return
	end
	--创建界面
	packge_main_ui = Gui.Create(win_parent)(packge_window)
	main_window_Creat = true
	fill_cbx_Weapon_Type(packge_main_ui.cbx_Filter_Type,Fileter_Weapon_Type)
end

local avatar_window =
{
	Gui.Control "ctrl_Avatar_Main"
	{
		Size = Vector2(472, 501),
		Location = Vector2(155, 75),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg3.dds", Vector4(22, 22, 22, 22)),
		},
		
		--人物显示
		Gui.CharacterViewer "character_viewer"
		{
			Size = Vector2(290, 494),
			Location = Vector2(5, 1),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_1_guang.tga", Vector4(0, 0, 0, 0)),
			},
		},
		
		Gui.Control "ctrl_shopping_cart"
		{							
			Size = Vector2(181, 492),
			Location = Vector2(285, 2),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg4_guang.dds", Vector4(8, 28, 8, 8)),
			},
		},
		--旋转角色
		Gui.Button "btn_rotate_avatar"
		{
			Size = Vector2(68, 24),
			Location = Vector2(8, 470),
			Padding = Vector4(0, 0, 0, 4),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button10_normal.dds", Vector4(0, 0, 0, 0)),
				HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button10_hover.dds", Vector4(0, 0, 0, 0)),
				DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button10_down.dds", Vector4(0, 0, 0, 0)),
				DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button10_normal.dds", Vector4(0, 0, 0, 0)),
			},
			EventClick = function()
				lg:RotateCharacter()
				--MessageBox.ShowWithConfirmCancel(lang:GetText("还在制作中？"), nil)
			end
		},

		--切换阵营
		Gui.Button "btn_change_team"
		{
			Size = Vector2(88, 24),
			Location = Vector2(80, 470),
			Padding = Vector4(0, 0, 0, 4),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button11_normal.dds", Vector4(0, 0, 0, 0)),
				HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button11_hover.dds", Vector4(0, 0, 0, 0)),
				DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button11_down.dds", Vector4(0, 0, 0, 0)),
				DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button11_normal.dds", Vector4(0, 0, 0, 0)),
			},
			EventClick = function()
				L_LobbyMain.current_Avatar_Team = (L_LobbyMain.current_Avatar_Team + 1) % 2
				L_LobbyMain.ChangeAvatarPart()
				RestAllShoppingMallItemBoxBtn()
			end
		},
		
		Gui.Control "fight_num_BG"
		{							
			Size = Vector2(280, 52),
			Location = Vector2(5, 1),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_power_bg_01.dds", Vector4(0, 0, 0, 0)),
			},
			Gui.FlowLayout "fightnum"
			{
				Location = Vector2(110,13),
				Size = Vector2(111,24),
				Align = "kAlignCenterMiddle",
				ControlAlign = "kAlignCenterMiddle",
				ControlSpace = 0,
			},
		},
	},
}

function ShowClassInfo(win_parent)
	--界面是否存在
	if avatart_main_ui then
		avatart_main_ui.ctrl_Avatar_Main.Parent = win_parent
		return
	end
	--创建界面
	avatart_main_ui = Gui.Create(win_parent)(avatar_window)
end

local main_props_window = 
{
	Gui.Control "ctrl_props_main"
	{
		Size = Vector2(1116, 586),
		Location = Vector2(19, 25),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/lb_shop_bg2.dds", Vector4(14, 14, 14, 14)),
		},

		Gui.Control "boddy_info_BG"
		{
			--Visible = false,
			Size = Vector2(1101, 551),
			Location = Vector2(9, 35),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_daoju_bg.tga", Vector4(22, 22, 22, 22)),
			},

			Gui.Control "ctrl_info_win"
			{
				Size = Vector2(861, 460),
				Location = Vector2(229, 77),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg3.dds", Vector4(20, 20, 20, 20)),
				},
			},
			
			Gui.Control "ctrl_info_win"
			{
				Size = Vector2(208, 498),
				Location = Vector2(16, 41),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg3.dds", Vector4(20, 20, 20, 20)),
				},
				Gui.Control "ctrl_prop_info_icon"
				{
					Size = Vector2(98, 94),
					Location = Vector2(56, 54),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_daoju_bg_l.dds", Vector4(0, 0, 0, 0)),
					},
					
					Gui.Control "ctrl_prop_info_icon"
					{
						Size = Vector2(98, 94),
						Location = Vector2(0, 0),
						BackgroundColor = ARGB(0, 255, 255, 255),
					},
				},
				
				Gui.TextArea "lbl_prop_info_title"
				{
					Text = "",
					FontSize = 18,
					Size = Vector2(230, 80),
					Location = Vector2(5, 170),
					DisabledTextColor = ARGB(255, 255, 189, 24),
					Fold = true,
					Enable = false,
				},
				
				Gui.TextArea "txtA_prop_info_body"
				{
					Size = Vector2(205, 405),
					Location = Vector2(5, 245),
					Readonly = false,
					FontSize = 18,
					Fold = true,
					Readonly = true,
					HScrollBarDisplay = "kHide",
					VScrollBarDisplay = "kHide",
					Enable = false,
					BackgroundColor = ARGB(255, 255, 255, 255),
					DisabledTextColor = ARGB(255, 191, 189, 184),
				},
			},

			Gui.Control "ctrl_prop_win"
			{
				Size = Vector2(835, 490),
				Location = Vector2(249, 31),
				BackgroundColor = ARGB(0, 255, 255, 255),
				
				Gui.Button "btn_tuijian"
				{
					Size = Vector2(92, 56),
					Location = Vector2(0 , 0),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_classification_01_normal.dds", Vector4(5, 5, 5, 5)),
						HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_classification_01_hover.dds", Vector4(5, 5, 5, 5)),
						DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_classification_01_down.dds", Vector4(5, 5, 5, 5)),
						DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_classification_01_normal.dds", Vector4(5, 5, 5, 5)),
					},
					PushDown = true,
					EventClick = function()
						if main_props_window_ui.btn_tuijian.PushDown == false then
							L_LobbyMain.current_shoppingmall_storage = 10
							if main_props_window_ui then
								current_selected_prop_index = 10
								main_props_window_ui.btn_tuijian.PushDown = true
								main_props_window_ui.btn_gongneng.PushDown = false
								main_props_window_ui.btn_hecheng.PushDown = false
								main_props_window_ui.btn_xiaohao.PushDown = false
								main_props_window_ui.btn_jiacheng.PushDown = false
								main_props_window_ui.btn_lantu.PushDown = false
								main_props_window_ui.btn_mingpian.PushDown = false
							end
							FilterMonChange(main_props_window_ui,0)
							-- fill_Filter_prop_Type(main_props_window_ui.cbx_Filter_Type,L_LobbyMain.current_shoppingmall_storage)
							L_LobbyMain.FillShoppingMallIB(0)
							--FillPropInfo(-1)
						end
					end
				},
				
				Gui.Button "btn_gongneng"
				{
					Size = Vector2(92, 56),
					Location = Vector2(92 , 0),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_classification_03_normal.dds", Vector4(5, 5, 5, 5)),
						HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_classification_03_hover.dds", Vector4(5, 5, 5, 5)),
						DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_classification_03_down.dds", Vector4(5, 5, 5, 5)),
						DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_classification_03_normal.dds", Vector4(5, 5, 5, 5)),
					},
					PushDown = false,
					EventClick = function()
						if main_props_window_ui.btn_gongneng.PushDown == false then
							L_LobbyMain.current_shoppingmall_storage = 4
							if main_props_window_ui then
								current_selected_prop_index = 4
								main_props_window_ui.btn_tuijian.PushDown = false
								main_props_window_ui.btn_gongneng.PushDown = true
								main_props_window_ui.btn_hecheng.PushDown = false
								main_props_window_ui.btn_xiaohao.PushDown = false
								main_props_window_ui.btn_jiacheng.PushDown = false
								main_props_window_ui.btn_lantu.PushDown = false
								main_props_window_ui.btn_mingpian.PushDown = false
							end
							FilterMonChange(main_props_window_ui,0)
							-- fill_Filter_prop_Type(main_props_window_ui.cbx_Filter_Type,L_LobbyMain.current_shoppingmall_storage)
							L_LobbyMain.FillShoppingMallIB(4)
							--FillPropInfo(-1)
						end
					end
				},
				
				Gui.Button "btn_hecheng"
				{
					Size = Vector2(92, 56),
					Location = Vector2(184 , 0),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_classification_02_normal.dds", Vector4(5, 5, 5, 5)),
						HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_classification_02_hover.dds", Vector4(5, 5, 5, 5)),
						DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_classification_02_down.dds", Vector4(5, 5, 5, 5)),
						DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_classification_02_normal.dds", Vector4(5, 5, 5, 5)),
					},
					PushDown = false,
					EventClick = function()
						if main_props_window_ui.btn_hecheng.PushDown == false then
							L_LobbyMain.current_shoppingmall_storage = 5
							if main_props_window_ui then
								current_selected_prop_index = 5
								main_props_window_ui.btn_tuijian.PushDown = false
								main_props_window_ui.btn_gongneng.PushDown = false
								main_props_window_ui.btn_hecheng.PushDown = true
								main_props_window_ui.btn_xiaohao.PushDown = false
								main_props_window_ui.btn_jiacheng.PushDown = false
								main_props_window_ui.btn_lantu.PushDown = false
								main_props_window_ui.btn_mingpian.PushDown = false
							end
							FilterMonChange(main_props_window_ui,0)
							-- fill_Filter_prop_Type(main_props_window_ui.cbx_Filter_Type,L_LobbyMain.current_shoppingmall_storage)
							L_LobbyMain.FillShoppingMallIB(1)
							--FillPropInfo(-1)
						end
					end
				},
				
				Gui.Button "btn_xiaohao"
				{
					Size = Vector2(92, 56),
					Location = Vector2(276 , 0),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_classification_04_normal.dds", Vector4(5, 5, 5, 5)),
						HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_classification_04_hover.dds", Vector4(5, 5, 5, 5)),
						DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_classification_04_down.dds", Vector4(5, 5, 5, 5)),
						DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_classification_04_normal.dds", Vector4(5, 5, 5, 5)),
					},
					PushDown = false,
					EventClick = function()
						if main_props_window_ui.btn_xiaohao.PushDown == false then
							L_LobbyMain.current_shoppingmall_storage = 4
							if main_props_window_ui then
								current_selected_prop_index = 4
								main_props_window_ui.btn_tuijian.PushDown = false
								main_props_window_ui.btn_gongneng.PushDown = false
								main_props_window_ui.btn_hecheng.PushDown = false
								main_props_window_ui.btn_xiaohao.PushDown = true
								main_props_window_ui.btn_jiacheng.PushDown = false
								main_props_window_ui.btn_lantu.PushDown = false
								main_props_window_ui.btn_mingpian.PushDown = false
							end
							FilterMonChange(main_props_window_ui,0)
							-- fill_Filter_prop_Type(main_props_window_ui.cbx_Filter_Type,L_LobbyMain.current_shoppingmall_storage)
							L_LobbyMain.FillShoppingMallIB(7)
							--FillPropInfo(-1)
						end
					end
				},
				
				Gui.Button "btn_jiacheng"
				{
					Size = Vector2(92, 56),
					Location = Vector2(368 , 0),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_classification_05_normal.dds", Vector4(5, 5, 5, 5)),
						HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_classification_05_hover.dds", Vector4(5, 5, 5, 5)),
						DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_classification_05_down.dds", Vector4(5, 5, 5, 5)),
						DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_classification_05_normal.dds", Vector4(5, 5, 5, 5)),
					},
					PushDown = false,
					EventClick = function()
						if main_props_window_ui.btn_jiacheng.PushDown == false then
							L_LobbyMain.current_shoppingmall_storage = 4
							if main_props_window_ui then
								current_selected_prop_index = 4
								main_props_window_ui.btn_tuijian.PushDown = false
								main_props_window_ui.btn_gongneng.PushDown = false
								main_props_window_ui.btn_hecheng.PushDown = false
								main_props_window_ui.btn_xiaohao.PushDown = false
								main_props_window_ui.btn_jiacheng.PushDown = true
								main_props_window_ui.btn_lantu.PushDown = false
								main_props_window_ui.btn_mingpian.PushDown = false
							end
							FilterMonChange(main_props_window_ui,0)
							-- fill_Filter_prop_Type(main_props_window_ui.cbx_Filter_Type,L_LobbyMain.current_shoppingmall_storage)
							L_LobbyMain.FillShoppingMallIB(1)
							--FillPropInfo(-1)
						end
					end
				},
				
				Gui.Button "btn_lantu"
				{
					Size = Vector2(92, 56),
					Location = Vector2(460 , 0),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_classification_06_normal.dds", Vector4(5, 5, 5, 5)),
						HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_classification_06_hover.dds", Vector4(5, 5, 5, 5)),
						DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_classification_06_down.dds", Vector4(5, 5, 5, 5)),
						DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_classification_06_normal.dds", Vector4(5, 5, 5, 5)),
					},
					PushDown = false,
					EventClick = function()
						if main_props_window_ui.btn_lantu.PushDown == false then
							L_LobbyMain.current_shoppingmall_storage = 5
							if main_props_window_ui then
								current_selected_prop_index = 5
								main_props_window_ui.btn_tuijian.PushDown = false
								main_props_window_ui.btn_gongneng.PushDown = false
								main_props_window_ui.btn_hecheng.PushDown = false
								main_props_window_ui.btn_xiaohao.PushDown = false
								main_props_window_ui.btn_jiacheng.PushDown = false
								main_props_window_ui.btn_lantu.PushDown = true
								main_props_window_ui.btn_mingpian.PushDown = false
							end
							FilterMonChange(main_props_window_ui,0)
							-- fill_Filter_prop_Type(main_props_window_ui.cbx_Filter_Type,L_LobbyMain.current_shoppingmall_storage)
							L_LobbyMain.FillShoppingMallIB(2)
							--FillPropInfo(-1)
						end
					end
				},
				
				Gui.Button "btn_mingpian"
				{
					Size = Vector2(92, 56),
					Location = Vector2(552 , 0),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_classification_07_normal.dds", Vector4(5, 5, 5, 5)),
						HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_classification_07_hover.dds", Vector4(5, 5, 5, 5)),
						DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_classification_07_down.dds", Vector4(5, 5, 5, 5)),
						DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_classification_07_normal.dds", Vector4(5, 5, 5, 5)),
					},
					PushDown = false,
					EventClick = function()
						if main_props_window_ui.btn_mingpian.PushDown == false then
							L_LobbyMain.current_shoppingmall_storage = 4
							if main_props_window_ui then
								main_props_window_ui.btn_tuijian.PushDown = false
								main_props_window_ui.btn_gongneng.PushDown = false
								main_props_window_ui.btn_hecheng.PushDown = false
								main_props_window_ui.btn_xiaohao.PushDown = false
								main_props_window_ui.btn_jiacheng.PushDown = false
								main_props_window_ui.btn_lantu.PushDown = false
								main_props_window_ui.btn_mingpian.PushDown = true
							end
							FilterMonChange(main_props_window_ui,0)
							-- fill_Filter_prop_Type(main_props_window_ui.cbx_Filter_Type,L_LobbyMain.current_shoppingmall_storage)
							L_LobbyMain.FillShoppingMallIB(2)
							--FillPropInfo(-1)
						end
					end
				},
				
				
				
				-- --道具
				-- Gui.Button "btn_Prop"
				-- {
					-- Size = Vector2(92, 56),
					-- Location = Vector2(0 , 0),
					-- Skin = Skin.ButtonSkin_props,
					-- PushDown = true,
					-- EventClick = function()
						-- if L_LobbyMain.current_shoppingmall_storage ~= 4 then
							-- L_LobbyMain.current_shoppingmall_storage = 4
							-- if main_props_window_ui then
								-- current_selected_prop_index = 4
								-- main_props_window_ui.btn_Prop.PushDown = true
								-- main_props_window_ui.btn_Material.PushDown = false
								-- main_props_window_ui.btn_BluePrint.PushDown = false
								-- main_props_window_ui.btn_BigGift.PushDown = false
							-- end
							-- FilterMonChange(main_props_window_ui,0)
							-- fill_Filter_prop_Type(main_props_window_ui.cbx_Filter_Type,L_LobbyMain.current_shoppingmall_storage)
							-- --L_LobbyMain.FillShoppingMallIB()
							-- --FillPropInfo(-1)
						-- end
					-- end
				-- },

				-- --素材
				-- Gui.Button "btn_Material"
				-- {
					-- Size = Vector2(92, 56),
					-- Location = Vector2(92 , 0),
					-- Skin = Skin.ButtonSkin_material,
					-- PushDown = false,
					-- EventClick = function()
						-- if L_LobbyMain.current_shoppingmall_storage ~= 5 then
							-- L_LobbyMain.current_shoppingmall_storage = 5
							-- if main_props_window_ui then
								-- current_selected_prop_index = 5
								-- main_props_window_ui.btn_Prop.PushDown = false
								-- main_props_window_ui.btn_Material.PushDown = true
								-- main_props_window_ui.btn_BluePrint.PushDown = false
								-- main_props_window_ui.btn_BigGift.PushDown = false
							-- end
							-- FilterMonChange(main_props_window_ui,0)
							-- fill_Filter_prop_Type(main_props_window_ui.cbx_Filter_Type,L_LobbyMain.current_shoppingmall_storage)
							-- --L_LobbyMain.FillShoppingMallIB()
							-- --FillPropInfo(-1)
						-- end
					-- end
				-- },

				-- --设计图
				-- Gui.Button "btn_BluePrint"
				-- {
					-- Visible = false,
					-- Size = Vector2(92, 56),
					-- Location = Vector2(184 , 0),
					-- Skin = Skin.ButtonSkin_material,
					-- PushDown = false,
					-- EventClick = function()
						-- if L_LobbyMain.current_shoppingmall_storage ~= 6 then
							-- L_LobbyMain.current_shoppingmall_storage = 6
							-- if main_props_window_ui then
								-- current_selected_prop_index = 6
								-- main_props_window_ui.btn_Prop.PushDown = false
								-- main_props_window_ui.btn_Material.PushDown = false
								-- main_props_window_ui.btn_BluePrint.PushDown = true
								-- main_props_window_ui.btn_BigGift.PushDown = false
							-- end
							-- FilterMonChange(main_props_window_ui,0)
							-- fill_Filter_prop_Type(main_props_window_ui.cbx_Filter_Type,L_LobbyMain.current_shoppingmall_storage)
							-- --L_LobbyMain.FillShoppingMallIB()
							-- --FillPropInfo(-1)
						-- end
					-- end
				-- },

				-- --大礼包
				-- Gui.Button "btn_BigGift"
				-- {
					-- Size = Vector2(92, 56),
					-- Location = Vector2(184 , 0),
					-- Skin = Skin.ButtonSkin_spree,
					-- PushDown = false,
					-- EventClick = function()
						-- if L_LobbyMain.current_shoppingmall_storage ~= 7 then
							-- L_LobbyMain.current_shoppingmall_storage = 7
							-- if main_props_window_ui then
								-- current_selected_prop_index = 7
								-- main_props_window_ui.btn_Prop.PushDown = false
								-- main_props_window_ui.btn_Material.PushDown = false
								-- main_props_window_ui.btn_BluePrint.PushDown = false
								-- main_props_window_ui.btn_BigGift.PushDown = true
							-- end
							-- FilterMonChange(main_props_window_ui,0)
							-- fill_Filter_prop_Type(main_props_window_ui.cbx_Filter_Type,L_LobbyMain.current_shoppingmall_storage)
							-- --L_LobbyMain.FillShoppingMallIB()
							-- --FillPropInfo(-1)
						-- end
					-- end
				-- },
				
				Gui.ComboBox "cbx_Filter_Type"
				{
					Size = Vector2(126, 28),
					FontSize = 14,
					Readonly = true,
					Location = Vector2(703, 18),
					TextColor = ARGB(255,37,37,37),
					TextAlign = "kAlignCenterMiddle",
					TextPadding = Vector4(6,4,2,6),
					LikeButton = true,
					Visible = false,
					Skin = Gui.ComboBoxSkin
					{
						ButtonNormalImage= Gui.Image("LobbyUI/ShoppingMall/lb_filter_combobox_button_normal.dds", Vector4(0, 0, 0, 0)),
						ButtonHoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_filter_combobox_button_hover.dds", Vector4(0, 0, 0, 0)),
						ButtonDownImage = Gui.Image("LobbyUI/ShoppingMall/lb_filter_combobox_button_down.dds", Vector4(0, 0, 0, 0)),
						
						TextNormalImage= Gui.Image("LobbyUI/ShoppingMall/lb_filter_combobox_bg_normal.dds", Vector4(6, 6, 0, 6)),
						TextHoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_filter_combobox_bg_hover.dds", Vector4(6, 6, 0, 6)),
						TextDownImage = Gui.Image("LobbyUI/ShoppingMall/lb_filter_combobox_bg_down.dds", Vector4(6, 6, 0, 6)),
					},
					ChildComboListStyle =  "Gui.teamComboList",
					
					EventValueChanged = function(sender, args)
						-- if main_window_Creat == true then
							-- main_window_Creat = false
							-- return
						-- end
						-- L_LobbyMain.CurrentShoppingMallPages[L_LobbyMain.current_choose_class][L_LobbyMain.current_shoppingmall_storage] = 1
						-- L_LobbyMain.FillShoppingMallIB()
						-- FillPropInfo(-1)
					end,
				},

				--上一页
				Gui.Button "btn_front_page"
				{
					Size = Vector2(14, 31),
					Location = Vector2(660, 462),
					--Text = "<",
					TextColor = ARGB(255, 255, 246, 235),
					FontSize = 18,
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button05_normal.dds", Vector4(0, 0, 0, 0)),
						HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button05_hover.dds", Vector4(0, 0, 0, 0)),
						DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button05_down.dds", Vector4(0, 0, 0, 0)),
						DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button05_normal.dds", Vector4(0, 0, 0, 0)),
					},
					EventClick = function()
						if L_LobbyMain.CurrentShoppingMallPages[L_LobbyMain.current_choose_class][L_LobbyMain.current_shoppingmall_storage] then
							if L_LobbyMain.CurrentShoppingMallPages[L_LobbyMain.current_choose_class][L_LobbyMain.current_shoppingmall_storage] <= 1 then
								return
							end
							if L_LobbyMain.CurrentShoppingMallPages[L_LobbyMain.current_choose_class][L_LobbyMain.current_shoppingmall_storage] > 1 then
								L_LobbyMain.CurrentShoppingMallPages[L_LobbyMain.current_choose_class][L_LobbyMain.current_shoppingmall_storage] = L_LobbyMain.CurrentShoppingMallPages[L_LobbyMain.current_choose_class][L_LobbyMain.current_shoppingmall_storage] - 1
							else
								L_LobbyMain.CurrentShoppingMallPages[L_LobbyMain.current_choose_class][L_LobbyMain.current_shoppingmall_storage] = 1
							end
							if main_props_window_ui.btn_tuijian.PushDown == true then
								L_LobbyMain.current_shoppingmall_storage = 10
								L_LobbyMain.FillShoppingMallIB(0)
							elseif main_props_window_ui.btn_gongneng.PushDown == true then	
								L_LobbyMain.current_shoppingmall_storage = 4
								L_LobbyMain.FillShoppingMallIB(4)
							elseif main_props_window_ui.btn_hecheng.PushDown == true then
								L_LobbyMain.current_shoppingmall_storage = 5
								L_LobbyMain.FillShoppingMallIB(1)
							elseif main_props_window_ui.btn_xiaohao.PushDown == true then
								L_LobbyMain.current_shoppingmall_storage = 4
								L_LobbyMain.FillShoppingMallIB(7)
							elseif main_props_window_ui.btn_jiacheng.PushDown == true then
								L_LobbyMain.current_shoppingmall_storage = 4
								L_LobbyMain.FillShoppingMallIB(1)
							elseif main_props_window_ui.btn_lantu.PushDown == true then
								L_LobbyMain.current_shoppingmall_storage = 5
								L_LobbyMain.FillShoppingMallIB(2)
							elseif main_props_window_ui.btn_mingpian.PushDown == true then
								L_LobbyMain.current_shoppingmall_storage = 4
								L_LobbyMain.FillShoppingMallIB(2)
							end
							-- L_LobbyMain.FillShoppingMallIB()
						end
						FillPropInfo(-1)
						RestAllShoppingMallItemBoxBtn()
					end
				},
			
				--页码
				Gui.Label "lb_page_number"
				{
					Location = Vector2(689, 462),
					Size = Vector2(75, 31),
					FontSize = 24,
					TextAlign = "kAlignCenterMiddle",
					TextColor = ARGB(255, 103, 102, 98),
					Text = "1/1",
					BackgroundColor = ARGB(255, 255, 255, 255),

					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button06_bg.dds", Vector4(13, 13, 13, 13)),
					},
				},

				--下一页
				Gui.Button "btn_next_page"
				{
					Size = Vector2(14, 31),
					Location = Vector2(779, 462),
					--Text = ">",
					TextColor = ARGB(255, 255, 246, 235),
					FontSize = 18,
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button06_normal.dds", Vector4(0, 0, 0, 0)),
						HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button06_hover.dds", Vector4(0, 0, 0, 0)),
						DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button06_down.dds", Vector4(0, 0, 0, 0)),
						DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button06_normal.dds", Vector4(0, 0, 0, 0)),
					},
					EventClick = function()
						if L_LobbyMain.CurrentShoppingMallPages[L_LobbyMain.current_choose_class][L_LobbyMain.current_shoppingmall_storage] then
							if L_LobbyMain.CurrentShoppingMallPages[L_LobbyMain.current_choose_class][L_LobbyMain.current_shoppingmall_storage] >= L_LobbyMain.ShoppingMallIB_rpc_data.pages then
								return
							end
							if L_LobbyMain.CurrentShoppingMallPages[L_LobbyMain.current_choose_class][L_LobbyMain.current_shoppingmall_storage] < L_LobbyMain.ShoppingMallIB_rpc_data.pages then
								L_LobbyMain.CurrentShoppingMallPages[L_LobbyMain.current_choose_class][L_LobbyMain.current_shoppingmall_storage] = L_LobbyMain.CurrentShoppingMallPages[L_LobbyMain.current_choose_class][L_LobbyMain.current_shoppingmall_storage] + 1
							else
								L_LobbyMain.CurrentShoppingMallPages[L_LobbyMain.current_choose_class][L_LobbyMain.current_shoppingmall_storage] = L_LobbyMain.ShoppingMallIB_rpc_data.pages
							end
							if main_props_window_ui.btn_tuijian.PushDown == true then
								L_LobbyMain.current_shoppingmall_storage = 10
								L_LobbyMain.FillShoppingMallIB(0)
							elseif main_props_window_ui.btn_gongneng.PushDown == true then	
								L_LobbyMain.current_shoppingmall_storage = 4
								L_LobbyMain.FillShoppingMallIB(4)
							elseif main_props_window_ui.btn_hecheng.PushDown == true then
								L_LobbyMain.current_shoppingmall_storage = 5
								L_LobbyMain.FillShoppingMallIB(1)
							elseif main_props_window_ui.btn_xiaohao.PushDown == true then
								L_LobbyMain.current_shoppingmall_storage = 4
								L_LobbyMain.FillShoppingMallIB(7)
							elseif main_props_window_ui.btn_jiacheng.PushDown == true then
								L_LobbyMain.current_shoppingmall_storage = 4
								L_LobbyMain.FillShoppingMallIB(1)
							elseif main_props_window_ui.btn_lantu.PushDown == true then
								L_LobbyMain.current_shoppingmall_storage = 5
								L_LobbyMain.FillShoppingMallIB(2)
							elseif main_props_window_ui.btn_mingpian.PushDown == true then
								L_LobbyMain.current_shoppingmall_storage = 4
								L_LobbyMain.FillShoppingMallIB(2)
							end
							-- L_LobbyMain.FillShoppingMallIB()
						end
						FillPropInfo(-1)
						RestAllShoppingMallItemBoxBtn()
					end
				},
		
				Gui.Button "BTN_bt0"
				{
					Location = Vector2(0, 462),
					Size = Vector2(89, 36),
					BackgroundColor = ARGB(255,255,255,255),
					Text = "   "..lang:GetText("全部"),
					FontSize = 16,
					TextAlign = "kAlignCenterMiddle",
					TextColor = ARGB(255, 243, 224, 207),
					HighlightTextColor = ARGB(255, 37, 37, 37),
					Padding = Vector4(0 ,0 ,0 ,4),
					PushDown = true,
					
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_filter_button_normal.dds", Vector4(26, 5, 5, 5)),
					HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_filter_button_hover.dds", Vector4(26, 5, 5, 5)),
					DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_filter_button_down.dds", Vector4(26, 5, 5, 5)),
					DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_filter_button_normal.dds", Vector4(26, 5, 5, 5)),
					},
					EventClick = function()
						if main_props_window_ui.BTN_bt0.PushDown == true then
							return
						end
						FilterMonChange(main_props_window_ui,0)
						if main_props_window_ui and main_character_window_ui.btn_Property.PushDown == true then
							if main_props_window_ui.btn_tuijian.PushDown == true then
								L_LobbyMain.current_shoppingmall_storage = 10
								L_LobbyMain.FillShoppingMallIB(0)
							elseif main_props_window_ui.btn_gongneng.PushDown == true then	
								L_LobbyMain.current_shoppingmall_storage = 4
								L_LobbyMain.FillShoppingMallIB(4)
							elseif main_props_window_ui.btn_hecheng.PushDown == true then
								L_LobbyMain.current_shoppingmall_storage = 5
								L_LobbyMain.FillShoppingMallIB(1)
							elseif main_props_window_ui.btn_xiaohao.PushDown == true then
								L_LobbyMain.current_shoppingmall_storage = 4
								L_LobbyMain.FillShoppingMallIB(7)
							elseif main_props_window_ui.btn_jiacheng.PushDown == true then
								L_LobbyMain.current_shoppingmall_storage = 4
								L_LobbyMain.FillShoppingMallIB(1)
							elseif main_props_window_ui.btn_lantu.PushDown == true then
								L_LobbyMain.current_shoppingmall_storage = 5
								L_LobbyMain.FillShoppingMallIB(2)
							elseif main_props_window_ui.btn_mingpian.PushDown == true then
								L_LobbyMain.current_shoppingmall_storage = 4
								L_LobbyMain.FillShoppingMallIB(2)
							end
						else
							L_LobbyMain.FillShoppingMallIB()
						end	
						FillPropInfo(-1)
					end,
				},
				
				Gui.Button "BTN_bt1"
				{
					Location = Vector2(92, 462),
					Size = Vector2(93, 36),
					BackgroundColor = ARGB(255,255,255,255),
					FontSize = 16,
					TextAlign = "kAlignCenterMiddle",
					TextColor = ARGB(255, 243, 224, 207),
					HighlightTextColor = ARGB(255, 37, 37, 37),
					Padding = Vector4(0 ,0 ,0 ,4),
					
					Gui.Control
					{
						Size = Vector2(28, 20),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Location = Vector2(26, 7),
						
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_ico_fc.dds", Vector4(0, 0, 0, 0)),
						},
					},
					
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_filter_button_normal.dds", Vector4(26, 5, 5, 5)),
						HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_filter_button_hover.dds", Vector4(26, 5, 5, 5)),
						DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_filter_button_down.dds", Vector4(26, 5, 5, 5)),
						DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_filter_button_normal.dds", Vector4(26, 5, 5, 5)),
					},
					EventClick = function()
						if main_props_window_ui.BTN_bt1.PushDown == true then
							return
						end
						FilterMonChange(main_props_window_ui,1)
						if main_props_window_ui and main_character_window_ui.btn_Property.PushDown == true then
							if main_props_window_ui.btn_tuijian.PushDown == true then
								L_LobbyMain.current_shoppingmall_storage = 10
								L_LobbyMain.FillShoppingMallIB(0)
							elseif main_props_window_ui.btn_gongneng.PushDown == true then	
								L_LobbyMain.current_shoppingmall_storage = 4
								L_LobbyMain.FillShoppingMallIB(4)
							elseif main_props_window_ui.btn_hecheng.PushDown == true then
								L_LobbyMain.current_shoppingmall_storage = 5
								L_LobbyMain.FillShoppingMallIB(1)
							elseif main_props_window_ui.btn_xiaohao.PushDown == true then
								L_LobbyMain.current_shoppingmall_storage = 4
								L_LobbyMain.FillShoppingMallIB(7)
							elseif main_props_window_ui.btn_jiacheng.PushDown == true then
								L_LobbyMain.current_shoppingmall_storage = 4
								L_LobbyMain.FillShoppingMallIB(1)
							elseif main_props_window_ui.btn_lantu.PushDown == true then
								L_LobbyMain.current_shoppingmall_storage = 5
								L_LobbyMain.FillShoppingMallIB(2)
							elseif main_props_window_ui.btn_mingpian.PushDown == true then
								L_LobbyMain.current_shoppingmall_storage = 4
								L_LobbyMain.FillShoppingMallIB(2)
							end
						else
							L_LobbyMain.FillShoppingMallIB()
						end	
						FillPropInfo(-1)
					end,
				},
				
				Gui.Button "BTN_bt2"
				{
					Location = Vector2(188, 462),
					Size = Vector2(89, 36),
					BackgroundColor = ARGB(255,255,255,255),
					FontSize = 16,
					TextAlign = "kAlignCenterMiddle",
					TextColor = ARGB(255, 243, 224, 207),
					HighlightTextColor = ARGB(255, 37, 37, 37),
					Padding = Vector4(0 ,0 ,0 ,4),
					
					Gui.Control
					{
						Size = Vector2(28, 20),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Location = Vector2(30, 7),
						
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_ico_cb.dds", Vector4(0, 0, 0, 0)),
						},
					},
					
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_filter_button_normal.dds", Vector4(26, 5, 5, 5)),
						HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_filter_button_hover.dds", Vector4(26, 5, 5, 5)),
						DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_filter_button_down.dds", Vector4(26, 5, 5, 5)),
						DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_filter_button_normal.dds", Vector4(26, 5, 5, 5)),
					},
					EventClick = function()
						if main_props_window_ui.BTN_bt2.PushDown == true then
							return
						end
						FilterMonChange(main_props_window_ui,2)
						if main_props_window_ui and main_character_window_ui.btn_Property.PushDown == true then
							if main_props_window_ui.btn_tuijian.PushDown == true then
								L_LobbyMain.current_shoppingmall_storage = 10
								L_LobbyMain.FillShoppingMallIB(0)
							elseif main_props_window_ui.btn_gongneng.PushDown == true then	
								L_LobbyMain.current_shoppingmall_storage = 4
								L_LobbyMain.FillShoppingMallIB(4)
							elseif main_props_window_ui.btn_hecheng.PushDown == true then
								L_LobbyMain.current_shoppingmall_storage = 5
								L_LobbyMain.FillShoppingMallIB(1)
							elseif main_props_window_ui.btn_xiaohao.PushDown == true then
								L_LobbyMain.current_shoppingmall_storage = 4
								L_LobbyMain.FillShoppingMallIB(7)
							elseif main_props_window_ui.btn_jiacheng.PushDown == true then
								L_LobbyMain.current_shoppingmall_storage = 4
								L_LobbyMain.FillShoppingMallIB(1)
							elseif main_props_window_ui.btn_lantu.PushDown == true then
								L_LobbyMain.current_shoppingmall_storage = 5
								L_LobbyMain.FillShoppingMallIB(2)
							elseif main_props_window_ui.btn_mingpian.PushDown == true then
								L_LobbyMain.current_shoppingmall_storage = 4
								L_LobbyMain.FillShoppingMallIB(2)
							end
						else
							L_LobbyMain.FillShoppingMallIB()
						end	
						FillPropInfo(-1)
					end,
				},
			},
		},

		Gui.Control "ctrl_Button_BG"
		{
			Size = Vector2(606, 74),
			Location = Vector2(210, 0),
			BackgroundColor = ARGB(255, 255, 255, 255),

			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab01_bg.dds", Vector4(29, 32, 32, 19)),
			},

			--角色
			Gui.Button "btn_Characters"
			{
				Size = Vector2(272, 52),
				Location = Vector2(26 , 9),
				Text = lang:GetText("角色商城"),
				TextColor = ARGB(255, 37, 37, 37),
				HighlightTextColor = ARGB(255, 37, 37, 37),
				FontSize = 28,
				PushDown = true,
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_normal.dds", Vector4(10, 10, 10, 10)),
					HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_hover.dds", Vector4(10, 10, 10, 10)),
					DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_down.dds", Vector4(10, 10, 10, 10)),
					DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_normal.dds", Vector4(10, 10, 10, 10)),
				},
				EventClick = function()
					if current_selected ~= 0 then
						current_selected = 0
						
						ShowWhichWin(root_ui, current_selected)
						
						if main_character_window_ui then
							main_character_window_ui.btn_Characters.PushDown = true
							main_character_window_ui.btn_Property.PushDown = false
						end					

						if packge_main_ui then
							if packge_main_ui.btn_Weapon.PushDown == true and L_LobbyMain.current_shoppingmall_storage ~= 1 then
								L_LobbyMain.current_shoppingmall_storage = 1
							elseif packge_main_ui.btn_Dress.PushDown == true and L_LobbyMain.current_shoppingmall_storage ~= 2 then
								L_LobbyMain.current_shoppingmall_storage = 2
							elseif packge_main_ui.btn_Accessories.PushDown == true and L_LobbyMain.current_shoppingmall_storage ~= 3 then
								L_LobbyMain.current_shoppingmall_storage = 3
							end
						end

						if main_props_window_ui then
							main_props_window_ui.btn_Characters.PushDown = true
							main_props_window_ui.btn_Property.PushDown = false
							main_props_window_ui.ctrl_props_main.Parent = nil
						end
						if L_LobbyMain.current_shoppingmall_storage == 1 then
							setup_ib_weapon(packge_main_ui.ctrl_Packge_Main)
						elseif L_LobbyMain.current_shoppingmall_storage == 2 then
							setup_ib_dress(packge_main_ui.ctrl_Packge_Main)
						elseif L_LobbyMain.current_shoppingmall_storage == 3 then
							setup_ib_accessories(packge_main_ui.ctrl_Packge_Main)
						end
						main_window_Creat = false
						L_LobbyMain.FillShoppingMallIB()
						L_LobbyMain.FillShoppingCart()
					end
					InitQuickSell()
					gui:PlayAudio("kUIA_CLOSE_UI2")
				end
			},

			--道具
			Gui.Button "btn_Property"
			{
				Size = Vector2(272, 52),
				Location = Vector2(305, 9),
				Text = lang:GetText("道具商城"),
				TextColor = ARGB(255, 37, 37, 37),
				HighlightTextColor = ARGB(255, 37, 37, 37),
				FontSize = 28,
				PushDown = false,
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_normal.dds", Vector4(10, 10, 10, 10)),
					HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_hover.dds", Vector4(10, 10, 10, 10)),
					DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_down.dds", Vector4(10, 10, 10, 10)),
					DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_normal.dds", Vector4(10, 10, 10, 10)),
				},
				EventClick = function()
					gui:PlayAudio("kUIA_CLOSE_UI2")
					--[[
					if current_selected ~= 1 then
						current_selected = 1
						if main_character_window_ui then
							main_character_window_ui.btn_Characters.PushDown = false
							main_character_window_ui.btn_Property.PushDown = true
							main_character_window_ui.ctrl_character_main.Parent = nil
						end
						
						ShowWhichWin(root_ui, current_selected)

						if main_props_window_ui then
							main_props_window_ui.btn_Characters.PushDown = false
							main_props_window_ui.btn_Property.PushDown = true
						end
						if L_LobbyMain.current_shoppingmall_storage > 3 then
							setup_ib_prop(main_props_window_ui.ctrl_prop_win)
						end
						L_LobbyMain.FillShoppingMallIB()
						L_LobbyMain.FillShoppingCart()
						FillPropInfo(-1)
					end
					]]
				end
			},
		},

		--免费兑换按钮
		Gui.Button "freeChang_btn"
		{
			Size = Vector2(152, 37),
			Location = Vector2(814, 0),
			Text = lang:GetText("免费兑换"),
			FontSize = 16,
			PushDown = false,
			--blinkwheelTimer = 0.6,
			blink_shade = false,
			TextColor = ARGB(255,238,221,190),
			HighlightTextColor = ARGB(255, 50 ,50 ,50),
			Padding = Vector4(0 ,4 ,0 ,0),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/free_change/lb_shop_button_free_normal.dds", Vector4(53, 0, 35, 0)),
				HoverImage = Gui.Image("LobbyUI/ShoppingMall/free_change/lb_shop_button_free_hover.dds", Vector4(53, 0, 35, 0)),
				DownImage = Gui.Image("LobbyUI/ShoppingMall/free_change/lb_shop_button_free_down.dds", Vector4(53, 0, 35, 0)),
				DisabledImage = Gui.Image("LobbyUI/ShoppingMall/free_change/lb_shop_button_free_normal.dds", Vector4(53, 0, 35, 0)),
				TwinkleImage  = Gui.Image("LobbyUI/ShoppingMall/free_change/lb_shop_button_free_flash.dds", Vector4(53, 0, 35, 0)),
			},
			EventClick = function()
				if L_LobbyMain.GetNowModuleState(L_LobbyMain.module_state.FreeChange.state,11,lang:GetText("免费兑换专区"),lang:GetText("战斗试练")) == false then
					return
				end
				L_FreeChangeShop.show()	
				L_LobbyMain.RPCBTNDown(6,main_props_window_ui.freeChang_btn)
			end
		},
		
		Gui.Button "time_sell_btn"
		{
			Size = Vector2(152, 37),
			Location = Vector2(957, 0),
			Text = lang:GetText("限时抢购"),
			FontSize = 16,
			PushDown = false,
			blink = true,
			--blinkwheelTimer = 0.6,
			-- blink_shade = false,
			TextColor = ARGB(255,238,221,190),
			HighlightTextColor = ARGB(255, 50 ,50 ,50),
			Padding = Vector4(0 ,4 ,0 ,0),
			Visible = false,
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/time_sell/lb_shop_button_snapup_normal.dds", Vector4(53, 0, 35, 0)),
				HoverImage = Gui.Image("LobbyUI/ShoppingMall/time_sell/lb_shop_button_snapup_hover.dds", Vector4(53, 0, 35, 0)),
				DownImage = Gui.Image("LobbyUI/ShoppingMall/time_sell/lb_shop_button_snapup_down.dds", Vector4(53, 0, 35, 0)),
				DisabledImage = Gui.Image("LobbyUI/ShoppingMall/time_sell/lb_shop_button_snapup_normal.dds", Vector4(53, 0, 35, 0)),
				TwinkleImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab01_light.dds", Vector4(11, 11, 11, 11)),
			},
			
			EventClick = function(Sender,e)
				L_TimeSell.show()	
			end
		},
		
		-- Gui.Button
		-- {
			-- Size = Vector2(144, 31),
			-- Location = Vector2(965, 6),
			-- BackgroundColor = ARGB(255, 255, 255, 255),
			-- blink = true,
			-- Enable = false,
			-- Skin = Gui.ButtonSkin
			-- {
				-- TwinkleImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab01_light.dds", Vector4(11, 11, 11, 11)),
			-- },
		-- },
		--Close Button
		Gui.Button "btn_Close"
		{
			Size = Vector2(43, 39),
			Location = Vector2(1064, 39),
			PushDown = false,
			Hint = lang:GetText("关闭商城并返回至战区"),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button01_small_normal.dds", Vector4(0, 0, 0, 0)),
				HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button01_small_hover.dds", Vector4(0, 0, 0, 0)),
				DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button01_small_down.dds", Vector4(0, 0, 0, 0)),
				DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button01_small_normal.dds", Vector4(0, 0, 0, 0)),
			},

			EventClick = function()
--				L_LobbyMain.HideAll()
				L_WarZone.Show(L_LobbyMain.LobbyMainWin_Boddy.LobbyMainWin_Boddy_Root)
				L_LobbyMain.LobbyMainWin_Foot.btn_WarZone.PushDown = true
			end
		},
		
	},
}

local main_character_window =
{
	Gui.Control "ctrl_character_main"
	{
		Size = Vector2(1116, 586),
		Location = Vector2(19, 25),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/lb_shop_bg2.dds", Vector4(14, 14, 14, 14)),
		},	
		
		Gui.Control "boddy_info_BG"
		{
			Size = Vector2(1101, 551),
			Location = Vector2(9, 34),
			BackgroundColor = ARGB(255, 255, 255, 255),
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg.tga", Vector4(150, 22, 22, 22)),
			},
		},
		
		--职业列表
		L_Characters_tab.create_tab_characters_windows(Vector2(1,38)),
		
		Gui.Control "ctrl_Button_BG"
		{
			Size = Vector2(606, 74),
			Location = Vector2(210, 0),
			BackgroundColor = ARGB(255, 255, 255, 255),

			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab01_bg.dds", Vector4(29, 32, 32, 19)),
			},

			--角色
			Gui.Button "btn_Characters"
			{
				Size = Vector2(272, 52),
				Location = Vector2(26 , 9),
				Text = lang:GetText("角色商城"),
				TextColor = ARGB(255, 37, 37, 37),
				HighlightTextColor = ARGB(255, 37, 37, 37),
				FontSize = 28,
				PushDown = true,
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_normal.dds", Vector4(10, 10, 10, 10)),
					HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_hover.dds", Vector4(10, 10, 10, 10)),
					DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_down.dds", Vector4(10, 10, 10, 10)),
					DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_normal.dds", Vector4(10, 10, 10, 10)),
				},
				EventClick = function()
					gui:PlayAudio("kUIA_CLOSE_UI2")
					--[[
					if current_selected ~= 0 then
						current_selected = 0
						
						ShowWhichWin(root_ui, current_selected)
						
						if main_character_window_ui then
							main_character_window_ui.btn_Characters.PushDown = true
							main_character_window_ui.btn_Property.PushDown = false
						end			
						
						if main_props_window_ui then
							main_props_window_ui.btn_Characters.PushDown = true
							main_props_window_ui.btn_Property.PushDown = false
							main_props_window_ui.ctrl_props_main.Parent = nil
						end
						if L_LobbyMain.current_shoppingmall_storage == 1 then
							setup_ib_weapon(packge_main_ui.ctrl_Packge_Main)
						elseif L_LobbyMain.current_shoppingmall_storage == 2 then
							setup_ib_dress(packge_main_ui.ctrl_Packge_Main)
						elseif L_LobbyMain.current_shoppingmall_storage == 3 then
							setup_ib_accessories(packge_main_ui.ctrl_Packge_Main)
						end
						L_LobbyMain.FillShoppingMallIB()
						L_LobbyMain.FillShoppingCart()
					end
					]]
				end
			},

			--道具
			Gui.Button "btn_Property"
			{
				Size = Vector2(272, 52),
				Location = Vector2(305, 9),
				Text = lang:GetText("道具商城"),
				TextColor = ARGB(255, 37, 37, 37),
				HighlightTextColor = ARGB(255, 37, 37, 37),
				FontSize = 28,
				PushDown = false,
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_normal.dds", Vector4(10, 10, 10, 10)),
					HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_hover.dds", Vector4(10, 10, 10, 10)),
					DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_down.dds", Vector4(10, 10, 10, 10)),
					DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_normal.dds", Vector4(10, 10, 10, 10)),
				},
				EventClick = function()
					if current_selected ~= 1 then
						current_selected = 1
						if main_character_window_ui then
							main_character_window_ui.btn_Characters.PushDown = false
							main_character_window_ui.btn_Property.PushDown = true
							main_character_window_ui.ctrl_character_main.Parent = nil
						end
						ShowWhichWin(root_ui, current_selected)
						if main_props_window_ui then
							main_props_window_ui.btn_Characters.PushDown = false
							main_props_window_ui.btn_Property.PushDown = true

							-- if main_props_window_ui.btn_Prop.PushDown == true and L_LobbyMain.current_shoppingmall_storage ~= 4 then
								-- L_LobbyMain.current_shoppingmall_storage = 4
							-- elseif main_props_window_ui.btn_Material.PushDown == true and L_LobbyMain.current_shoppingmall_storage ~= 5 then
								-- L_LobbyMain.current_shoppingmall_storage = 5
							-- elseif main_props_window_ui.btn_BluePrint.PushDown == true and L_LobbyMain.current_shoppingmall_storage ~= 6 then
								-- L_LobbyMain.current_shoppingmall_storage = 6
							-- elseif main_props_window_ui.btn_BigGift.PushDown == true and L_LobbyMain.current_shoppingmall_storage ~= 7 then
								-- L_LobbyMain.current_shoppingmall_storage = 7
							-- end
							if main_props_window_ui.btn_tuijian.PushDown == true then
								L_LobbyMain.current_shoppingmall_storage = 10
								L_LobbyMain.FillShoppingMallIB(0)
							elseif main_props_window_ui.btn_gongneng.PushDown == true then	
								L_LobbyMain.current_shoppingmall_storage = 4
								L_LobbyMain.FillShoppingMallIB(4)
							elseif main_props_window_ui.btn_hecheng.PushDown == true then
								L_LobbyMain.current_shoppingmall_storage = 5
								L_LobbyMain.FillShoppingMallIB(1)
							elseif main_props_window_ui.btn_xiaohao.PushDown == true then
								L_LobbyMain.current_shoppingmall_storage = 4
								L_LobbyMain.FillShoppingMallIB(7)
							elseif main_props_window_ui.btn_jiacheng.PushDown == true then
								L_LobbyMain.current_shoppingmall_storage = 4
								L_LobbyMain.FillShoppingMallIB(1)
							elseif main_props_window_ui.btn_lantu.PushDown == true then
								L_LobbyMain.current_shoppingmall_storage = 5
								L_LobbyMain.FillShoppingMallIB(2)
							elseif main_props_window_ui.btn_mingpian.PushDown == true then
								L_LobbyMain.current_shoppingmall_storage = 4
								L_LobbyMain.FillShoppingMallIB(2)
							end
						end
						if L_LobbyMain.current_shoppingmall_storage > 3 then
							setup_ib_prop(main_props_window_ui.ctrl_prop_win)
						end
						-- L_LobbyMain.FillShoppingMallIB()
						L_LobbyMain.FillShoppingCart()
						FillPropInfo(-1)
					end
					InitQuickSell()
					gui:PlayAudio("kUIA_CLOSE_UI2")
				end
			},
		},

		--免费兑换按钮
		Gui.Button "freeChang_btn"
		{
			Size = Vector2(152, 37),
			Location = Vector2(814, 0),
			Text = lang:GetText("免费兑换"),
			FontSize = 16,
			PushDown = false,
			blink_shade = false,
			TextColor = ARGB(255,238,221,190),
			HighlightTextColor = ARGB(255, 50 ,50 ,50),
			Padding = Vector4(0 ,4 ,0 ,0),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/free_change/lb_shop_button_free_normal.dds", Vector4(53, 0, 35, 0)),
				HoverImage = Gui.Image("LobbyUI/ShoppingMall/free_change/lb_shop_button_free_hover.dds", Vector4(53, 0, 35, 0)),
				DownImage = Gui.Image("LobbyUI/ShoppingMall/free_change/lb_shop_button_free_down.dds", Vector4(53, 0, 35, 0)),
				DisabledImage = Gui.Image("LobbyUI/ShoppingMall/free_change/lb_shop_button_free_normal.dds", Vector4(53, 0, 35, 0)),
				TwinkleImage  = Gui.Image("LobbyUI/ShoppingMall/free_change/lb_shop_button_free_flash.dds", Vector4(53, 0, 35, 0)),
			},
			EventClick = function()
				if L_LobbyMain.GetNowModuleState(L_LobbyMain.module_state.FreeChange.state,11,lang:GetText("免费兑换专区"),lang:GetText("战斗试练")) == false then
					return
				end
				L_FreeChangeShop.show()
				L_LobbyMain.RPCBTNDown(6,main_character_window_ui.freeChang_btn)
			end
		},
		
		Gui.Button "time_sell_btn"
		{
			Size = Vector2(152, 37),
			Location = Vector2(957, 0),
			Text = lang:GetText("限时抢购"),
			FontSize = 16,
			PushDown = false,
			blink = true,
			--blinkwheelTimer = 0.6,
			-- blink_shade = false,
			TextColor = ARGB(255,238,221,190),
			HighlightTextColor = ARGB(255, 50 ,50 ,50),
			Padding = Vector4(0 ,4 ,0 ,0),
			Visible = false,
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/time_sell/lb_shop_button_snapup_normal.dds", Vector4(53, 0, 35, 0)),
				HoverImage = Gui.Image("LobbyUI/ShoppingMall/time_sell/lb_shop_button_snapup_hover.dds", Vector4(53, 0, 35, 0)),
				DownImage = Gui.Image("LobbyUI/ShoppingMall/time_sell/lb_shop_button_snapup_down.dds", Vector4(53, 0, 35, 0)),
				DisabledImage = Gui.Image("LobbyUI/ShoppingMall/time_sell/lb_shop_button_snapup_normal.dds", Vector4(53, 0, 35, 0)),
				TwinkleImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab01_light.dds", Vector4(11, 11, 11, 11)),
			},
			
			EventClick = function(Sender,e)
				L_TimeSell.show()	
			end
		},
		
		-- Gui.Button
		-- {
			-- Size = Vector2(144, 31),
			-- Location = Vector2(965, 6),
			-- BackgroundColor = ARGB(255, 255, 255, 255),
			-- blink = true,
			-- -- Enable = false,
			-- Skin = Gui.ButtonSkin
			-- {
				-- TwinkleImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab01_light.dds", Vector4(11, 11, 11, 11)),
			-- },
		-- },
		
		--Close Button
		Gui.Button "btn_Close"
		{
			Size = Vector2(43, 39),
			Location = Vector2(1064, 39),
			PushDown = false,
			Hint = lang:GetText("关闭商城并返回至战区"),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button01_small_normal.dds", Vector4(0, 0, 0, 0)),
				HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button01_small_hover.dds", Vector4(0, 0, 0, 0)),
				DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button01_small_down.dds", Vector4(0, 0, 0, 0)),
				DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button01_small_normal.dds", Vector4(0, 0, 0, 0)),
			},

			EventClick = function()
				L_WarZone.Show(L_LobbyMain.LobbyMainWin_Boddy.LobbyMainWin_Boddy_Root)
				L_LobbyMain.LobbyMainWin_Foot.btn_WarZone.PushDown = true
			end
		},
	},
}

--重置商城职业列表
function RestAllCharactersClassBtn()
	for i = 1, 10 do
		main_character_window_ui["tab_btn_"..i].PushDown = false
	end
end


--同步职业列表
function SynchronousClassButton()
	if main_character_window_ui then
		RestAllCharactersClassBtn()
		main_character_window_ui["tab_btn_"..L_LobbyMain.current_choose_class].PushDown = true
	end
end

--职业列表事件
local function characters_tab_event()
	if main_character_window_ui == nil then
		return
	end
	
	for i = 1, 10 do
		main_character_window_ui["tab_btn_"..i].EventClick = function()
			if L_LobbyMain.current_choose_class ~= i then
				if L_LobbyMain.character_classes[i].is_open == 1 then
					L_LobbyMain.current_choose_class = i
					L_LobbyMain.CurrentShoppingMallPages[L_LobbyMain.current_choose_class][L_LobbyMain.current_shoppingmall_storage] = 1
					RestAllCharactersClassBtn()
					main_character_window_ui["tab_btn_"..i].PushDown = true
					ShowClassInfo(main_character_window_ui.ctrl_character_main)
					ShowPackgeInfo(main_character_window_ui.ctrl_character_main)
					L_LobbyMain.FillShoppingMallIB()
					L_LobbyMain.FillShoppingCart()
					RestAllShoppingMallItemBoxBtn()
					Getshoppingcar_window_count()
					if shoppingcar_window_count == 0 then
						user_bag_ui.btn_buy_all.Enable = false
						user_bag_ui.btn_clear_all.Enable = false
						CloseShoppingCarBuyWin()
					else
						user_bag_ui.btn_buy_all.Enable = true
						user_bag_ui.btn_clear_all.Enable = true
					end
					RestAllCharacterBagItemBoxBtn()
					L_LobbyMain.FillClassBag(ptr_cast(game.CurrentState):GetCharacterId(), L_LobbyMain.current_choose_class)
				end
			end
		end
	end
end

--0角色管理，1道具管理
function ShowWhichWin(win_parent, which)
	if which == 0 then
		if main_character_window_ui then
			main_character_window_ui.ctrl_character_main.Parent = win_parent
			
			if main_props_window_ui then
				main_props_window_ui.ctrl_props_main.Parent = nil
			end
			if L_LobbyMain.module_state then
				L_LobbyMain.SetBTNstate(L_LobbyMain.module_state.FreeChange.state,L_ShoppingMall.main_character_window_ui.freeChang_btn)
			end
			return
		end
		--在FillCharacterClass中填充
		main_character_window_ui = Gui.Create(win_parent)(main_character_window)
		main_character_window_ui["tab_btn_1"].PushDown = true
		characters_tab_event()
		if L_LobbyMain.module_state then
			L_LobbyMain.SetBTNstate(L_LobbyMain.module_state.FreeChange.state,L_ShoppingMall.main_character_window_ui.freeChang_btn)
		end
	elseif which == 1 then
		if main_props_window_ui then
			main_props_window_ui.ctrl_props_main.Parent = win_parent
			
			if main_character_window_ui then
				main_character_window_ui.ctrl_character_main.Parent = nil
			end
			if L_LobbyMain.module_state then
				L_LobbyMain.SetBTNstate(L_LobbyMain.module_state.FreeChange.state,L_ShoppingMall.main_props_window_ui.freeChang_btn)
			end
			return
		end
		main_props_window_ui = Gui.Create(win_parent)(main_props_window)
		if L_LobbyMain.module_state then
			L_LobbyMain.SetBTNstate(L_LobbyMain.module_state.FreeChange.state,L_ShoppingMall.main_props_window_ui.freeChang_btn)
		end
		main_window_Creat = true
		fill_cbx_Weapon_Type(main_props_window_ui.cbx_Filter_Type, Fileter_prop_Type)

		if main_props_window_ui then
			setup_ib_prop(main_props_window_ui.ctrl_prop_win)
		end
	end
end

Player_List = Gui.Create()
{
	Gui.Control "root"
	{
		Size = Vector2(482, 522),
		Dock = "kDockCenter",
		BackgroundColor = ARGB(255, 255, 255, 255),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/mail/lb_contact_bg1.dds", Vector4(38, 38, 38, 38)),
		},
		Gui.Control
		{
			Size = Vector2(452, 496),
			Location = Vector2(15, 13),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/mail/lb_contact_bg2.dds", Vector4(16, 12, 16, 45)),
			},
			Gui.Button "Friend"
			{
				PushDown = true,
				Text = lang:GetText("好友"),
				Location = Vector2(10,13),
				Size = Vector2(105, 30),
				TextColor = ARGB(255, 217, 209, 201),
				HighlightTextColor = ARGB(255, 217, 209, 201),
				FontSize = 18,
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/lb_shop_tab03_normal.dds", Vector4(5, 5, 5, 5)),
					HoverImage = Gui.Image("LobbyUI/team/lb_shop_tab03_hover.dds", Vector4(5, 5, 5, 5)),
					DownImage = Gui.Image("LobbyUI/team/lb_shop_tab03_down.dds", Vector4(5, 5, 5, 5)),
					DisabledImage = Gui.Image("LobbyUI/team/lb_shop_tab03_normal.dds", Vector4(5, 5, 5, 5)),
				},
				EventClick = function()
					Player_List.Friend.PushDown = true
					Player_List.Partner.PushDown = false
					Player_List.Zhandui.PushDown = false
					Player_List.Channel_Player.PushDown = false
					
					isFriend = true
					isPartner = false
					isZhandui = false
					isChannel = false
					FillFriendsList()
				end
			},
			Gui.Button "Partner"
			{
				Text = lang:GetText("伙伴"),
				Location = Vector2(115,13),
				Size = Vector2(105, 30),
				TextColor = ARGB(255, 217, 209, 201),
				HighlightTextColor = ARGB(255, 217, 209, 201),
				FontSize = 18,
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/lb_shop_tab03_normal.dds", Vector4(5, 5, 5, 5)),
					HoverImage = Gui.Image("LobbyUI/team/lb_shop_tab03_hover.dds", Vector4(5, 5, 5, 5)),
					DownImage = Gui.Image("LobbyUI/team/lb_shop_tab03_down.dds", Vector4(5, 5, 5, 5)),
					DisabledImage = Gui.Image("LobbyUI/team/lb_shop_tab03_normal.dds", Vector4(5, 5, 5, 5)),
				},
				EventClick = function()
					Player_List.Friend.PushDown = false
					Player_List.Partner.PushDown = true
					Player_List.Zhandui.PushDown = false
					Player_List.Channel_Player.PushDown = false
					
					isFriend = false
					isPartner = true
					isZhandui = false
					isChannel = false
					FillPartnerList()
				end
			},
			Gui.Button "Zhandui"
			{
				Text = lang:GetText("战队"),
				Location = Vector2(220,13),
				Size = Vector2(105, 30),
				TextColor = ARGB(255, 217, 209, 201),
				HighlightTextColor = ARGB(255, 217, 209, 201),
				FontSize = 18,
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/lb_shop_tab03_normal.dds", Vector4(5, 5, 5, 5)),
					HoverImage = Gui.Image("LobbyUI/team/lb_shop_tab03_hover.dds", Vector4(5, 5, 5, 5)),
					DownImage = Gui.Image("LobbyUI/team/lb_shop_tab03_down.dds", Vector4(5, 5, 5, 5)),
					DisabledImage = Gui.Image("LobbyUI/team/lb_shop_tab03_normal.dds", Vector4(5, 5, 5, 5)),
				},
				EventClick = function()
					Player_List.Friend.PushDown = false
					Player_List.Partner.PushDown = false
					Player_List.Zhandui.PushDown = true
					Player_List.Channel_Player.PushDown = false
					
					isFriend = false
					isPartner = false
					isZhandui = true
					isChannel = false
					FillZhanduiList()
				end
			},
			Gui.Button "Channel_Player"
			{
				Text = lang:GetText("频道"),
				Location = Vector2(325,13),
				Size = Vector2(105, 30),
				TextColor = ARGB(255, 217, 209, 201),
				HighlightTextColor = ARGB(255, 217, 209, 201),
				FontSize = 18,
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/lb_shop_tab03_normal.dds", Vector4(5, 5, 5, 5)),
					HoverImage = Gui.Image("LobbyUI/team/lb_shop_tab03_hover.dds", Vector4(5, 5, 5, 5)),
					DownImage = Gui.Image("LobbyUI/team/lb_shop_tab03_down.dds", Vector4(5, 5, 5, 5)),
					DisabledImage = Gui.Image("LobbyUI/team/lb_shop_tab03_normal.dds", Vector4(5, 5, 5, 5)),
				},
				EventClick = function()
					Player_List.Friend.PushDown = false
					Player_List.Partner.PushDown = false
					Player_List.Zhandui.PushDown = false
					Player_List.Channel_Player.PushDown = true
					
					isFriend = false
					isPartner = false
					isZhandui = false
					isChannel = true
					FillChannelPlayerList()
				end
			},
			Gui.Control 
			{		
				Location = Vector2(8, 38),
				Size = Vector2(436, 409),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/mail/lb_mail_label_bg01.dds", Vector4(5, 5, 5, 5)),
				},
				Gui.ListTreeView "ltv_box"
				{
					Style = "Gui.ListTreeViewWith_VScroll",
					Size = Vector2(426, 399),
					Location = Vector2(10, 14),
					CanKeySelect = false,
					TreeVisible = false,
					AlwaysSelect = false,
					VScrollBarWidth = 32,
					VScrollBarButtonSize = 32,
					FontSize = 14,
					TextColor = ARGB(255,216,217,208),
					VScrollBarDisplay = "kVisible",
					ItemHeight = 38,
					HeaderVisible = false,
				},
			},
			Gui.Button
			{
				Size = Vector2(150, 36),
				Location = Vector2(30, 455),
				Text = lang:GetText("确定"),
				TextColor = ARGB(255, 211, 211, 211),
				HighlightTextColor = ARGB(255, 211, 211, 211),
				TextAlign = "kAlignCenterMiddle",
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/lb_contact_button_normal.tga", Vector4(5, 5, 5, 5)),
					HoverImage = Gui.Image("LobbyUI/team/lb_contact_button_hover.tga", Vector4(5, 5, 5, 5)),
					DownImage = Gui.Image("LobbyUI/team/lb_contact_button_down.tga", Vector4(5, 5, 5, 5)),
					DisabledImage = Gui.Image("LobbyUI/team/lb_contact_button_normal.tga", Vector4(5, 5, 5, 5)),			
				},
				EventClick = function()
					local ltv = Player_List.ltv_box
					if ltv.SelectedItem then
						buy_and_present_ui.cbx_friends_present.Text = ltv.SelectedItem:GetText()
						current_select_firend_index = ltv.SelectingIndex
						selectedid = ltv.SelectedItem.ID
					else
						current_select_firend_index = -1
						selectedid = -1
						buy_and_present_ui.cbx_friends_present.Text = ""
					end
					if Player_list_modal then
						Player_list_modal.Close()
						Player_list_modal = nil
					end
				end
				  
			},
			Gui.Button
			{
				Size = Vector2(150, 36),
				Location = Vector2(250, 455),
				Text = lang:GetText("取消"),
				TextColor = ARGB(255, 211, 211, 211),
				HighlightTextColor = ARGB(255, 211, 211, 211),
				TextAlign = "kAlignCenterMiddle",
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/lb_contact_button_normal.tga", Vector4(5, 5, 5, 5)),
					HoverImage = Gui.Image("LobbyUI/team/lb_contact_button_hover.tga", Vector4(5, 5, 5, 5)),
					DownImage = Gui.Image("LobbyUI/team/lb_contact_button_down.tga", Vector4(5, 5, 5, 5)),
					DisabledImage = Gui.Image("LobbyUI/team/lb_contact_button_normal.tga", Vector4(5, 5, 5, 5)),			
				},
				EventClick = function()
					if Player_list_modal then
						Player_list_modal.Close()
						Player_list_modal = nil
					end
				end
			},
		},
	},
}

function Initialize()
	current_selected_ibtn_index = -1
	current_selected_item_class = -1
	ShowWhichWin(root_ui, current_selected)

	--设置avatar窗口显示
	if main_character_window_ui then
		ShowClassInfo(main_character_window_ui.ctrl_character_main)
		ShowPackgeInfo(main_character_window_ui.ctrl_character_main)
		if avatart_main_ui then
			ShowUserBag(avatart_main_ui.ctrl_shopping_cart)
		end

		if user_bag_ui then
			setup_user_bag(user_bag_ui.ctrl_shopping_cart_Main)
		end

		if packge_main_ui then
			setup_ib_weapon(packge_main_ui.ctrl_Packge_Main)
		end		
	end
end

function Finalize()
	if root_ui then
		root_ui = nil
	end
	
	if main_character_window_ui then
		main_character_window_ui = nil
	end

	if main_character_window_ui then
		main_character_window_ui = nil
	end

	if main_props_window_ui then
		main_props_window_ui = nil
	end

	if avatart_main_ui then
		avatart_main_ui = nil
	end
	
	if packge_main_ui then
		packge_main_ui = nil
	end
	
	if user_bag_ui then
		user_bag_ui = nil
	end

	if user_bag_info_ui then
		user_bag_info_ui = nil
	end

	if user_bag_info_ui then
		user_bag_info_ui = nil
	end

	if ib_weapon_ui then
		ib_weapon_ui = nil
	end

	if ib_dress_ui then
		ib_dress_ui = nil
	end

	if ib_accessories_ui then
		ib_accessories_ui = nil
	end
	
	if prop_window_ui then
		prop_window_ui = nil
	end

	if buy_and_present_ui then
		buy_and_present_ui = nil
	end
	
	current_selected = 0

	--当前选择的itemboxbtn的索引
	current_selected_ibtn_index = -1
	--当前道具栏目索引(4=道具、5=设计图、6=素材、7=大礼包)
	current_selected_prop_index = 4

	--当前商城 选择角色ID
	current_c_id = 1

	--当前购买方式
	current_goods_price_info = nil
	--选择的结算方式
	current_selected_price_way = 2

	--是否购买并装备
	is_buy_and_equip = false

	--当前选择的购买方式 1：3天 2：7天 3：三十天 4：永久
	cost_mode = 1
end

--商城
function Show(parent_win)
	L_LobbyMain.HideAll()
	L_LobbyMain.LobbyMainWin_Foot.btn_ShoppingMall.PushDown = true
	root_ui = parent_win
	if current_selected == 0 then
		if main_props_window_ui then
			main_props_window_ui.btn_Characters.PushDown = true
			main_props_window_ui.btn_Property.PushDown = false
			main_props_window_ui.ctrl_props_main.Parent = nil
		end
		if main_character_window_ui then
			main_character_window_ui.ctrl_character_main.Parent = parent_win
			main_character_window_ui.btn_Characters.PushDown = true
			main_character_window_ui.btn_Property.PushDown = false
			if L_LobbyMain.current_shoppingmall_storage == 1 then
				setup_ib_weapon(packge_main_ui.ctrl_Packge_Main)
			elseif L_LobbyMain.current_shoppingmall_storage == 2 then
				setup_ib_dress(packge_main_ui.ctrl_Packge_Main)
			elseif L_LobbyMain.current_shoppingmall_storage == 3 then
				setup_ib_accessories(packge_main_ui.ctrl_Packge_Main)
			end
		end
	elseif current_selected == 1 then
		if main_character_window_ui then
			main_character_window_ui.btn_Characters.PushDown = false
			main_character_window_ui.btn_Property.PushDown = true
			main_character_window_ui.ctrl_character_main.Parent = nil
		end
		if main_props_window_ui then
			main_props_window_ui.ctrl_props_main.Parent = parent_win
			main_props_window_ui.btn_Characters.PushDown = false
			main_props_window_ui.btn_Property.PushDown = true
			if L_LobbyMain.current_shoppingmall_storage > 3 then
				setup_ib_prop(main_props_window_ui.ctrl_prop_win)
			end
		end
	end
	InitQuickSell()
end

function Hide()
	current_selected_ibtn_index = -1
	current_selected_item_class = -1
	
	if main_character_window_ui then		
		main_character_window_ui.ctrl_character_main.Parent = nil
	end

	if main_props_window_ui then
		main_props_window_ui.ctrl_props_main.Parent = nil
	end
	
	if buy_and_present_ui then
		buy_and_present_ui.ctrl_bg.Parent = nil
	end
	
	if shoppingcar_window_ui then
		shoppingcar_window_ui.root.Parent = nil
	end
	
	if ib_weapon_ui then
		ib_weapon_ui.ctrl_ib_container.Parent = nil
	end
	
	if tuozhuai_ui then
		tuozhuai_ui.root.Parent = nil
		tuozhuai_ui = nil
	end
end

function RestAllCharacterBagItemBoxBtn()
	if user_bag_info_ui then 
		user_bag_info_ui.ib_primary_weapon.Selected = false
		user_bag_info_ui.ib_secondary_weapon.Selected = false
		user_bag_info_ui.ib_grenade.Selected = false
		user_bag_info_ui.ib_melee_weapons.Selected = false
		user_bag_info_ui.ib_no_use.Selected = false
		user_bag_info_ui.ib_hat.Selected = false
		user_bag_info_ui.ib_last.Selected = false
	end
end

function InitAllCharacterBagItemBoxBtnEvent()
	RestAllCharacterBagItemBoxBtn()
end

--获得shoppingcar_window_count
function Getshoppingcar_window_count()
	shoppingcar_window_count = 0
	for i = 1,7 do
		local ibbtn = ptr_cast(user_bag_info_ui.ctrl_ib_container:GetChildByIndex(i-1))
		if ibbtn.BtnVisible == true then
			shoppingcar_window_count = shoppingcar_window_count + 1
		end
	end
end

function RestAllShoppingMallItemBoxBtn()
	--道具界面
	if prop_window_ui then
		for i = 1, 28 do
			local ibbtn = ptr_cast(prop_window_ui.ctrl_ib_container:GetChildByIndex(i-1))
			if ibbtn then
				ibbtn.Selected = false
			end
		end		
	end
	
	if ib_accessories_ui then
		for i = 1, 16 do
			local ibbtn = ptr_cast(ib_accessories_ui.ctrl_ib_container:GetChildByIndex(i-1))
			ibbtn.Selected = false		
		end
	end
	
	if ib_dress_ui then
		for i = 1, 8 do
			local ibbtn = ptr_cast(ib_dress_ui.ctrl_ib_container:GetChildByIndex(i-1))
			ibbtn.Selected = false
		end
	end
	
	if ib_weapon_ui then
		for i = 1, 8 do
			local ibbtn = ptr_cast(ib_weapon_ui.ctrl_ib_container:GetChildByIndex(i-1))
			ibbtn.Selected = false
		end
	end
end

function FillCart(idx)
	if L_LobbyMain.ShoppingMallIB_rpc_data then
		item = L_LobbyMain.ShoppingMallIB_rpc_data.items[idx]
		if item then
			local index = 1
			if item.common.type == 1 then
				--武器
				index = item.common.seq
			elseif item.common.type == 2 then
				index = 5
			elseif item.common.type == 3 then
				index = item.common.seq + 4
			end
					
			L_LobbyMain.AddInShoppingCart(index, item)
			L_LobbyMain.FillShoppingCart()											
		end
	end
end

function Highlight_weapon_tip(index)
	if L_LobbyMain.ShoppingMallIB_rpc_data.items[index].common.seq == 1 then
		user_bag_info_ui.ib_primary_weapon.Highlight = true
	elseif L_LobbyMain.ShoppingMallIB_rpc_data.items[index].common.seq == 2 then
		user_bag_info_ui.ib_secondary_weapon.Highlight = true
	elseif L_LobbyMain.ShoppingMallIB_rpc_data.items[index].common.seq == 3 then
		user_bag_info_ui.ib_melee_weapons.Highlight = true
	else
		user_bag_info_ui.ib_grenade.Highlight = true
	end
end

function Highlight_accessories_tip(index)
	if L_LobbyMain.ShoppingMallIB_rpc_data.items[index].common.seq == 2 then
		user_bag_info_ui.ib_hat.Highlight = true
	else
		user_bag_info_ui.ib_last.Highlight = true
	end
end

--填充左侧道具信息
function FillPropInfo(index)
	if index < 1 then
		if main_props_window_ui then
			main_props_window_ui.ctrl_prop_info_icon.BackgroundColor = ARGB(0, 255, 255, 255)
			main_props_window_ui.ctrl_prop_info_icon.Skin = nil			
			main_props_window_ui.lbl_prop_info_title.Text = ""
			main_props_window_ui.txtA_prop_info_body.Text = ""
		end
		return
	end
	
	if L_LobbyMain.ShoppingMallIB_rpc_data and main_props_window_ui then
		local items = L_LobbyMain.ShoppingMallIB_rpc_data.items
		if items then
			if items[index] then
				main_props_window_ui.ctrl_prop_info_icon.BackgroundColor = ARGB(255, 255, 255, 255)
				main_props_window_ui.ctrl_prop_info_icon.Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ibt_icon/"..items[index].name..".tga", Vector4(0, 0, 0, 0)),
				}
				main_props_window_ui.lbl_prop_info_title.Text = items[index].display
				main_props_window_ui.txtA_prop_info_body.Text = items[index].description
			end
		end
	end	
end
--[[
--筛选购买货币类型复位
function FilterMonType(parent_win)
	parent_win.Filter_rg.RadioCheckID = 0
end
]]
--筛选武器类型填充
function fill_cbx_Weapon_Type(cbx, gtk)
	cbx:RemoveAll()
	if gtk then
		for i=1, #gtk do
			cbx:AddItem(gtk[i])
		end
	end
	cbx.SelectedIndex = 0
end

--道具筛选类型填充
function fill_Filter_prop_Type(parent_win,which)
	if which == 4 then
		if L_LobbyMain.current_chosse_main_page == 6 then
			fill_cbx_Weapon_Type(parent_win, Fileter_prop_Storage_Type)
		elseif L_LobbyMain.current_chosse_main_page == 7 then
			fill_cbx_Weapon_Type(parent_win, Fileter_prop_Type)
		end
	elseif which == 5 then
		if L_LobbyMain.current_chosse_main_page == 6 then
			fill_cbx_Weapon_Type(parent_win, Fileter_Material_Storage_Type)
		elseif L_LobbyMain.current_chosse_main_page == 7 then
			fill_cbx_Weapon_Type(parent_win, Fileter_Material_Type)
		end
	elseif which == 6 then
		if L_LobbyMain.current_chosse_main_page == 6 then
			fill_cbx_Weapon_Type(parent_win, Fileter_BluePrint_Storage_Type)
		elseif L_LobbyMain.current_chosse_main_page == 7 then
			fill_cbx_Weapon_Type(parent_win, Fileter_BluePrint_Type)
		end
	elseif which == 7 then
		if L_LobbyMain.current_chosse_main_page == 6 then
			fill_cbx_Weapon_Type(parent_win, Fileter_BigGift_Storage_Type)
		elseif L_LobbyMain.current_chosse_main_page == 7 then
			fill_cbx_Weapon_Type(parent_win, Fileter_BigGift_Type)
		end
	elseif which == 8 then
		if L_LobbyMain.current_chosse_main_page == 6 then
			fill_cbx_Weapon_Type(parent_win, Fileter_Box_Storage_Type)
		elseif L_LobbyMain.current_chosse_main_page == 7 then
			fill_cbx_Weapon_Type(parent_win, Fileter_Box_Type)
		end
	end
end

--筛选货币变更
function FilterMonChange(parent_win,which)
	parent_win.BTN_bt0.PushDown = false
	parent_win.BTN_bt1.PushDown = false
	parent_win.BTN_bt2.PushDown = false
	
	if which == 0 then
		parent_win.BTN_bt0.PushDown = true
	elseif which == 1 then
		parent_win.BTN_bt1.PushDown = true
	elseif which == 2 then
		parent_win.BTN_bt2.PushDown = true
	end
	
	if parent_win == main_props_window_ui then
		Fileter_Property_MoneyType = which
	elseif parent_win == packge_main_ui then
		Fileter_Equip_MoneyType = which		
	end
	L_LobbyMain.CurrentShoppingMallPages[L_LobbyMain.current_choose_class][L_LobbyMain.current_shoppingmall_storage] = 1
end

function setup_player_list()
	Player_list_modal = ModalWindow.GetNew()
	Player_list_modal.root.Size = Vector2(482, 522)
	Player_list_modal.AllowEscToExit = false
	Player_List.root.Parent = Player_list_modal.root
end

function FillFriendsList()
	local list = L_LobbyMain.Friends_rpc_data
	local ltv = Player_List.ltv_box   
	ltv:DeleteAll()
	local i = 1
	if list then
		for k, v in ipairs(list) do 
			local sub_item = ltv:AddItem(ltv.RootItem,v[3])
			if i % 2 == 1 then
				sub_item.BGSkin = Skin.ListItemSkin_Single
			else
				sub_item.BGSkin = Skin.ListItemSkin_Double
			end
			i = i + 1
		end
	end

	if i < 11 then
		local j 
		for j = i ,10 do
			local sub_item = ltv:AddItem(ltv.RootItem)
			sub_item.CanSelect = false
			sub_item.ID = -1
			if j % 2 == 1 then
				sub_item.BGSkin = Skin.ListItemSkin_Single
			else
				sub_item.BGSkin = Skin.ListItemSkin_Double
			end
		end
	end		
end

function FillPartnerList()
	-- local list
	local args = {pid = ptr_cast(game.CurrentState):GetCharacterId(), displayOnline = 0}
	rpc.safecall("partners_list",args,
				function (data) 
					list = data.partnerslist
					local ltv = Player_List.ltv_box   
					ltv:DeleteAll()
					-- local list = L_LobbyMain.partners_rpc_data
					local i = 1
					if list then
						for k, v in ipairs(list) do 
							local sub_item = ltv:AddItem(ltv.RootItem,v[3])
							if i % 2 == 1 then
								sub_item.BGSkin = Skin.ListItemSkin_Single
							else
								sub_item.BGSkin = Skin.ListItemSkin_Double
							end
							i = i + 1
						end
					end

					if i < 11 then
						local j 
						for j = i ,10 do
							local sub_item = ltv:AddItem(ltv.RootItem)
							sub_item.CanSelect = false
							sub_item.ID = -1
							if j % 2 == 1 then
								sub_item.BGSkin = Skin.ListItemSkin_Single
							else
								sub_item.BGSkin = Skin.ListItemSkin_Double
							end
						end
					end		
				end)
end

function FillZhanduiList()
	local list = L_Friends.Team_RPC_List
	local ltv = Player_List.ltv_box   
	ltv:DeleteAll()
	local i = 1
	if list then
		for k, v in ipairs(list) do 
			if v[4] ~= L_LobbyMain.PersonalInfo_data.name then
				local sub_item = ltv:AddItem(ltv.RootItem,v[4])
				sub_item.ID = v[1]
				if i % 2 == 1 then
					sub_item.BGSkin = Skin.ListItemSkin_Single
				else
					sub_item.BGSkin = Skin.ListItemSkin_Double
				end
				i = i + 1
			else
				myZhanduiIndex = i-1
			end
		end
	end

	if i < 11 then
		local j 
		for j = i ,10 do
			local sub_item = ltv:AddItem(ltv.RootItem)
			sub_item.CanSelect = false
			sub_item.ID = -1
			if j % 2 == 1 then
				sub_item.BGSkin = Skin.ListItemSkin_Single
			else
				sub_item.BGSkin = Skin.ListItemSkin_Double
			end
		end
	end		
end

function FillChannelPlayerList()
	local list = L_Friends.Channel_list
	local ltv = Player_List.ltv_box   
	ltv:DeleteAll()
	local i = 1
	while list do
		if list.name ~= L_LobbyMain.PersonalInfo_data.name then
			local sub_item = ltv:AddItem(ltv.RootItem,list.name)
			if i % 2 == 1 then
				sub_item.BGSkin = Skin.ListItemSkin_Single
			else
				sub_item.BGSkin = Skin.ListItemSkin_Double
			end
			i = i + 1
		end
		list = list.next
	end

	if i < 11 then
		local j 
		for j = i ,10 do
			local sub_item = ltv:AddItem(ltv.RootItem)
			sub_item.CanSelect = false
			sub_item.ID = -1
			if j % 2 == 1 then
				sub_item.BGSkin = Skin.ListItemSkin_Single
			else
				sub_item.BGSkin = Skin.ListItemSkin_Double
			end
		end
	end	
end

function InitQuickSell()
	if config:GetUISystemFlag(1) == 0 then
		if main_character_window_ui then
			main_character_window_ui.time_sell_btn.Visible = false
		end	
		if main_props_window_ui then
			main_props_window_ui.time_sell_btn.Visible = false
		end
	else
		if main_character_window_ui then
			main_character_window_ui.time_sell_btn.Visible = true
			main_character_window_ui.time_sell_btn.blink = L_LobbyMain.Sell_flag 
		end
		if main_props_window_ui then
			main_props_window_ui.time_sell_btn.Visible = true
			main_props_window_ui.time_sell_btn.blink = L_LobbyMain.Sell_flag 
		end	
	end
end