module("L_Characters_manage", package.seeall)

local Table = nil
local Count = 0
local Size = nil
local Max_Size = nil
local Is_changed = nil
local tempData =  nil
Rapid_Shopping_Win_ui = nil
local pay_id = 1
local select_zob = 0
function create_poker_people(i)
	return 	Gui.Control ("Poker"..i)
	{
		Size = Vector2(119, 168),
		Location = Vector2(89+121*(i-1), 54),
		BackgroundColor = ARGB(0, 255, 255, 255),
		
		Gui.Control ("b_select"..i)
		{
			Size = Vector2(119, 168),
			Location = Vector2(0, 0),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/Manage/lb_manage_poker_normal.dds", Vector4(5, 5, 5, 5)),
			},
			Gui.Button ("poker_bg"..i)
			{
				Location = Vector2(0, 0),
				Size = Vector2(119, 168),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Manage/lb_manage_poker_sniper_disabled.dds", Vector4(0, 0, 0, 0)),
					HoverImage = Gui.Image("LobbyUI/Manage/lb_manage_poker_sniper_hover.dds", Vector4(0, 0, 0, 0)),
					DownImage = Gui.Image("LobbyUI/Manage/lb_manage_poker_sniper_hover.dds", Vector4(0, 0, 0, 0)),
					DisabledImage = Gui.Image("LobbyUI/Manage/lb_manage_poker_sniper_hover.dds", Vector4(0, 0, 0, 0)),
				},
				EventClick = function(Sender,e)
					Is_changed = true
					if Sender.PushDown then
						Sender.PushDown = false
						ui["poker_man"..i].Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("InGameUI/select_person/ig_common_xuanren_"..tempData.data[i].resource..".dds", Vector4(0, 0, 0, 0)),
						}
						ui["poker_man_select"..i].Visible = false
						local c_id = ui["c_id"..i]
						local c_resource = ui["c_resource"..i]
						Table[tonumber(c_id.Text)][1] = 0
						Count = Count - 1
						ui.l_leftpeople.Text = lang:GetText("X")..(Size - Count)
					elseif not Sender.PushDown and Count < Size then
						Sender.PushDown = true
						ui["poker_man"..i].Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("InGameUI/select_person/ig_common_xuanren_down_"..tempData.data[i].resource.."_red.dds", Vector4(0, 0, 0, 0)),
						}
						ui["poker_man_select"..i].Visible = true
						local c_id = ui["c_id"..i]
						local c_resource = ui["c_resource"..i]
						Table[tonumber(c_id.Text)][1] = 1
						Table[tonumber(c_id.Text)][2] = c_resource.Text
						Count = Count + 1
						ui.l_leftpeople.Text = lang:GetText("X")..(Size - Count)
					end
				end,
			},
			Gui.Control ("poker_man"..i)
			{
				Location = Vector2(10, 15),
				Size = Vector2(98, 138),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Enable = false,
				Skin = Gui.ControlSkin
				{
					BackgroundImage = nil,
				},
			},
			Gui.Control ("poker_man_select"..i)
			{
				Location = Vector2(0, 0),
				Size = Vector2(119, 168),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Visible = false,
				Enable = false,
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Manage/lb_squad_select_ico.dds",Vector4(0, 0, 0, 0)),
				},
			},
		},
		Gui.Label ("c_id"..i)
		{
			Visible = false,
		},
		Gui.Label ("c_resource"..i)
		{
			Visible = false,
		},
	}			
end

function create_poker_zob(i)
	return 	Gui.Control ("PokerZob"..i)
	{
		Size = Vector2(119, 208),
		Location = Vector2(71+124*(i-1), 60),
		BackgroundColor = ARGB(0, 255, 255, 255),
		Visible = false,
		Gui.Control ("b_selectZob"..i)
		{
			Size = Vector2(119, 168),
			Location = Vector2(0, 0),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/Manage/lb_manage_poker_normal.dds", Vector4(5, 5, 5, 5)),
			},
			Gui.Button ("pokerZob_bg"..i)
			{
				Location = Vector2(0, 0),
				Size = Vector2(119, 168),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Manage/lb_manage_poker_zombie_disabled.dds", Vector4(0, 0, 0, 0)),
					HoverImage = Gui.Image("LobbyUI/Manage/lb_manage_poker_zombie_hover.dds", Vector4(0, 0, 0, 0)),
					DownImage = Gui.Image("LobbyUI/Manage/lb_manage_poker_zombie_hover.dds", Vector4(0, 0, 0, 0)),
					DisabledImage = Gui.Image("LobbyUI/Manage/lb_manage_poker_zombie_hover.dds", Vector4(0, 0, 0, 0)),
				},
				EventClick = function(Sender,e)
					if ui["poker_zob_lock"..i].Visible == true then
						select_zob = i
						ShowRapidShoppingWin()
						FillRapidShoppingWin(i)
						return
					end
					Is_changed = true
					if Sender.PushDown then
						ui["poker_zob_select"..i].Visible = false
						ui["poker_zob"..i].Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("InGameUI/select_person/ig_common_xuanren_"..tempData.bioChardata[i].resourceName..".dds", Vector4(0, 0, 0, 0)),
						}
						for i = 1 , 3 do
							ui["pokerZob_bg"..i].PushDown = false
						end
						ui.l_leftzob.Text = lang:GetText("X1")
					else
						ui["poker_zob_select"..i].Visible = true
						for i = 1 , 3 do
							ui["pokerZob_bg"..i].PushDown = false
							ui["poker_zob"..i].Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("InGameUI/select_person/ig_common_xuanren_"..tempData.bioChardata[i].resourceName..".dds", Vector4(0, 0, 0, 0)),
							}
						end
						ui.l_leftzob.Text = lang:GetText("X0")
						Sender.PushDown = true
						ui["poker_zob"..i].Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("InGameUI/select_person/ig_common_xuanren_down_"..tempData.bioChardata[i].resourceName.."_red.dds", Vector4(0, 0, 0, 0)),
						}
					end
					for j = 1, 3 do
						if i ~= j then
						ui["poker_zob_select"..j].Visible = false
						end
					end
				end,
			},
			Gui.Control ("poker_zob"..i)
			{
				Location = Vector2(11, 5),
				Size = Vector2(98, 156),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Enable = false,
				Skin = Gui.ControlSkin
				{
					BackgroundImage = nil,
				},
			},
			Gui.Control ("poker_zob_select"..i)
			{
				Location = Vector2(0, 0),
				Size = Vector2(119, 168),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Visible = false,
				Enable = false,
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Manage/lb_squad_select_ico.dds",Vector4(0, 0, 0, 0)),
				},
			},
			Gui.Control ("poker_zob_lock"..i)
			{
				Location = Vector2(20, 44),
				Size = Vector2(80, 80),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Enable = false,
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Manage/lb_synthesis_weijiesuo.dds", Vector4(0, 0, 0, 0)),
				},
			},
		},
		Gui.Label ("poker_zob_time"..i)
		{
			Location = Vector2(0, 160),
			Size = Vector2(119, 20),
			BackgroundColor = ARGB(255, 255, 255, 255),
			TextColor = ARGB(255, 255, 96, 0),
			FontSize = 14,
			TextAlign = "kAlignCenterTop",
			Text = lang:GetText("剩余10天"),
			BackgroundColor = ARGB(0,255,255,255),
			Visible = false,
		},
		Gui.Label ("zob_id"..i)
		{
			Visible = false,
		},
		Gui.Label ("zob_resource"..i)
		{
			Visible = false,
		},
	}			
end

ui = Gui.Create()
{
	Gui.Control "root"
	{
		Size = Vector2(1116, 586),
		Location = Vector2(19, 25),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/lb_shop_bg2.dds", Vector4(14, 14, 14, 14)),
		}, 
		Gui.Control 
		{
			Size = Vector2(1101, 580),
			Location = Vector2(9, 3),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_daoju_bg.tga", Vector4(22, 22, 22, 22)),
			},
			Gui.Control "Pokers"
			{
				Size = Vector2(1014, 245),
				Location = Vector2(48, 28),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Manage/lb_manage_bg.dds", Vector4(180, 0, 72, 0)),
				},
				Gui.Label
				{
					Size = Vector2(200, 28),
					Location = Vector2(76, 18),
					TextColor = ARGB(255, 255, 96, 0),
					FontSize = 24,
					TextAlign = "kAlignLeftTop",
					Text = lang:GetText("普通模式"),
					BackgroundColor = ARGB(0,255,255,255),
				},
				Gui.Label
				{
					Size = Vector2(400, 28),
					Location = Vector2(650, 22),
					TextColor = ARGB(255, 235, 177, 0),
					FontSize = 20,
					TextAlign = "kAlignLeftTop",
					Text = lang:GetText("剩余参战人数："),
					BackgroundColor = ARGB(0,255,255,255),
				},
				Gui.Label "l_leftpeople"
				{
					Size = Vector2(50, 28),
					Location = Vector2(956, 22),
					TextColor = ARGB(255, 255, 96, 0),
					FontSize = 20,
					TextAlign = "kAlignLeftTop",
					Text = lang:GetText("X1"),
					BackgroundColor = ARGB(0,255,255,255),
				},
				create_poker_people(1),
				create_poker_people(2),
				create_poker_people(3),
				create_poker_people(4),
				create_poker_people(5),
				create_poker_people(6),
				create_poker_people(7),
				Gui.Button "btn_Left"
				{
					Size = Vector2(44, 56),
					Location = Vector2(54, 111),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Visible = false,
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/Compose/lb_fastsettlement_button03_normal.dds", Vector4(0, 0, 0, 0)),
						HoverImage = Gui.Image("LobbyUI/Compose/lb_fastsettlement_button03_hover.dds", Vector4(0, 0, 0, 0)),
						DownImage = Gui.Image("LobbyUI/Compose/lb_fastsettlement_button03_down.dds", Vector4(0, 0, 0, 0)),
						DisabledImage = Gui.Image("LobbyUI/Compose/lb_fastsettlement_button03_disabled.dds", Vector4(0, 0, 0, 0)),
					},
				},	
				Gui.Button "btn_Right"
				{
					Size = Vector2(44, 56),
					Location = Vector2(927, 111),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Visible = false,
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/Compose/lb_fastsettlement_button02_normal.dds", Vector4(0, 0, 0, 0)),
						HoverImage = Gui.Image("LobbyUI/Compose/lb_fastsettlement_button02_hover.dds", Vector4(0, 0, 0, 0)),
						DownImage = Gui.Image("LobbyUI/Compose/lb_fastsettlement_button02_down.dds", Vector4(0, 0, 0, 0)),
						DisabledImage = Gui.Image("LobbyUI/Compose/lb_fastsettlement_button02_disabled.dds", Vector4(0, 0, 0, 0)),
					},
				},	
			},
			Gui.Control 
			{
				Size = Vector2(515, 260),
				Location = Vector2(48, 276),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Manage/lb_manage_bg.dds", Vector4(180, 0, 72, 0)),
				},
				Gui.Label
				{
					Size = Vector2(200, 28),
					Location = Vector2(76, 18),
					TextColor = ARGB(255, 255, 96, 0),
					FontSize = 24,
					TextAlign = "kAlignLeftTop",
					Text = lang:GetText("生化感染模式"),
					BackgroundColor = ARGB(0,255,255,255),
				},
				Gui.Label
				{
					Size = Vector2(400, 28),
					Location = Vector2(20, 22),
					TextColor = ARGB(255, 235, 177, 0),
					FontSize = 20,
					TextAlign = "kAlignRightTop",
					Text = lang:GetText("剩余参战人数："),
					BackgroundColor = ARGB(0,255,255,255),
				},
				Gui.Label "l_leftzob"
				{
					Size = Vector2(50, 28),
					Location = Vector2(456, 22),
					TextColor = ARGB(255, 255, 96, 0),
					FontSize = 20,
					TextAlign = "kAlignLeftTop",
					Text = lang:GetText("X1"),
					BackgroundColor = ARGB(0,255,255,255),
				},
				create_poker_zob(1),
				create_poker_zob(2),
				create_poker_zob(3),
			},
			Gui.Control 
			{
				Size = Vector2(515, 260),
				Location = Vector2(548, 275),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Manage/lb_manage_bg.dds", Vector4(180, 0, 72, 0)),
				},
				Gui.Label
				{
					Size = Vector2(200, 28),
					Location = Vector2(70, 70),
					TextColor = ARGB(255, 255, 96, 0),
					FontSize = 22,
					TextAlign = "kAlignLeftCenter",
					Text = lang:GetText("规则:"),
					BackgroundColor = ARGB(0,255,255,255),
				},
				Gui.Label
				{
					Size = Vector2(400, 200),
					Location = Vector2(70, 110),
					TextColor = ARGB(255, 235, 177, 0),
					FontSize = 16,
					TextAlign = "kAlignLeftTop",
					Text = lang:GetText("点击卡牌选择(取消)带入游戏的角色\n\n各个模式的参战人数限制不同\n\n点击未解锁的生化体可快速购买"),
					BackgroundColor = ARGB(0,255,255,255),
				},
			},
			
			Gui.Button
			{
				Location = Vector2(445, 527),
				Size = Vector2(215, 40),
				TextColor = ARGB(255, 0, 0, 0),
				HighlightTextColor = ARGB(255, 0, 0, 0),
				FontSize = 22,
				Text = lang:GetText("确 定"),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/lb_common_up_button_normal.dds", Vector4(20, 20, 20, 20)),
					HoverImage = Gui.Image("LobbyUI/lb_common_up_button_hover.dds", Vector4(20, 20, 20, 20)),
					DownImage = Gui.Image("LobbyUI/lb_common_up_button_down.dds", Vector4(20, 20, 20, 20)),
					DisabledImage = Gui.Image("LobbyUI/lb_common_up_button_disabled.dds", Vector4(20, 20, 20, 20)),			
				},
				EventClick = function()
					local args = ""
					local count = 0
					local zob_id = 0
					for i,v in ipairs(Table) do
						if v[1] == 1 then
							if count == 0 then
								args = args..i
							else
								args = args..","..i
							end
							count = count + 1
						end
					end
					for i = 1, 3 do
						if ui["pokerZob_bg"..i].PushDown then
							zob_id = tonumber(ui["zob_id"..i].Text)
						end
					end
					print("zob_id:"..zob_id)
					--bid
					rpc.safecall("character_set",{pid = ptr_cast(game.CurrentState):GetCharacterId(),cids = args,bid = zob_id},
					function(data)
						if data.error == nil then
							L_LobbyMain.HideAll()
							if L_LobbyMain.LobbyMainWin_Boddy then
								L_WarZone.Show(L_LobbyMain.LobbyMainWin_Boddy.LobbyMainWin_Boddy_Root)
							end
							lg:SetLobbyModules(5)
							current_chosse_main_page = 5
							MessageBox.ShowWithTimer(1,lang:GetText("设置成功"))
						end
					end)
				end
			},
			Gui.Button "btn_Close"
			{
				Size = Vector2(80, 60),
				Location = Vector2(1019, 3),
				Hint = lang:GetText("关闭参战名单"),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Manage/lb_manage_button01_normal.dds", Vector4(5, 5, 5, 5)),
					HoverImage = Gui.Image("LobbyUI/Manage/lb_manage_button01_hover.dds", Vector4(5, 5, 5, 5)),
					DownImage = Gui.Image("LobbyUI/Manage/lb_manage_button01_down.dds", Vector4(5, 5, 5, 5)),
					DisabledImage = Gui.Image("LobbyUI/Manage/lb_manage_button01_normal.dds", Vector4(5, 5, 5, 5)),
				},
				EventClick = function()
					if Is_changed == true then
						MessageBox.ShowWithTwoButtons(lang:GetText("您已更改了参战名单，是否保存修改？"),lang:GetText("保存"),lang:GetText("退出"), 
						function()
							local args = ""
							local count = 0
							local zob_id = 0
							for i,v in ipairs(Table) do
								if v[1] == 1 then
									if count == 0 then
										args = args..i
									else
										args = args..","..i
									end
									count = count + 1
								end
							end
							for i = 1, 3 do
								if ui["pokerZob_bg"..i].PushDown then
									zob_id = tonumber(ui["zob_id"..i].Text)
								end
							end
							rpc.safecall("character_set",{pid = ptr_cast(game.CurrentState):GetCharacterId(),cids = args,bid = zob_id},
							function(data)
								if data.error == nil then
									L_LobbyMain.HideAll()
									if L_LobbyMain.LobbyMainWin_Boddy then
										L_WarZone.Show(L_LobbyMain.LobbyMainWin_Boddy.LobbyMainWin_Boddy_Root)
									end
									lg:SetLobbyModules(5)
									current_chosse_main_page = 5
									MessageBox.ShowWithTimer(1,lang:GetText("设置成功"))
								end
							end)
						end,
						function()
							L_LobbyMain.HideAll()
							if L_LobbyMain.LobbyMainWin_Boddy then
								L_WarZone.Show(L_LobbyMain.LobbyMainWin_Boddy.LobbyMainWin_Boddy_Root)
							end
							lg:SetLobbyModules(5)
							current_chosse_main_page = 5
						end
						)
					else
						L_LobbyMain.HideAll()
						if L_LobbyMain.LobbyMainWin_Boddy then
							L_WarZone.Show(L_LobbyMain.LobbyMainWin_Boddy.LobbyMainWin_Boddy_Root)
						end
						lg:SetLobbyModules(5)
						current_chosse_main_page = 5
					end
				end
			},
		},	
	},
}
function Fill()
	rpc.safecallload("character_list",{pid = ptr_cast(game.CurrentState):GetCharacterId()},
	function(data)
		Size = data.size
		Max_Size = tonumber(data.openSize)
		tempData = data
		local my_count = 1
		for i = 1, #L_LobbyMain.character_classes do
			if data.data[i].is_open == 1 then
				ui["c_id"..i].Text = data.data[i].cid
				ui["c_resource"..i].Text = data.data[i].resource
				ui["poker_bg"..i].Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Manage/lb_manage_poker_"..data.data[i].resourceName.."_disabled.dds", Vector4(0, 0, 0, 0)),
					HoverImage = Gui.Image("LobbyUI/Manage/lb_manage_poker_"..data.data[i].resourceName.."_hover.dds", Vector4(0, 0, 0, 0)),
					DownImage = Gui.Image("LobbyUI/Manage/lb_manage_poker_"..data.data[i].resourceName.."_hover.dds", Vector4(0, 0, 0, 0)),
					DisabledImage = Gui.Image("LobbyUI/Manage/lb_manage_poker_"..data.data[i].resourceName.."_hover.dds", Vector4(0, 0, 0, 0)),
				}
				my_count = my_count + 1
			end
		end
		Count = #data.select
		for i = 1, 7 do
			ui["poker_man_select"..i].Visible = false
			ui["poker_bg"..i].PushDown = false
		end
		for i = 1, Count do
			for j = 1, data.openSize do
				local c_id = ui["c_id"..j]
				if tonumber(ui["c_id"..j].Text) == data.select[i] then
					local button = ui["poker_bg"..j]
					local c_resource = ui["c_resource"..j]
					button.PushDown = true
					ui["poker_man_select"..j].Visible = true
					Table[tonumber(ui["c_id"..j].Text)][1] = 1
					Table[tonumber(ui["c_id"..j].Text)][2] = c_resource.Text
				end
			end
		end
		for i = 1,data.openSize do
			if ui["poker_bg"..i].PushDown then
				ui["poker_man"..i].Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("InGameUI/select_person/ig_common_xuanren_down_"..data.data[i].resource.."_red.dds", Vector4(0, 0, 0, 0)),
				}
			else
				ui["poker_man"..i].Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("InGameUI/select_person/ig_common_xuanren_"..data.data[i].resource..".dds", Vector4(0, 0, 0, 0)),
				}
			end			
		end	
		ui.l_leftpeople.Text = lang:GetText("X")..(Size - Count)
		
		--生化FILL
		FillZob(data)
	end)
end

function FillZob(data)
	for i = 1, #data.bioChardata do
		ui["PokerZob"..i].Visible = false
	end
	local temp = 1
	for i = 1, #data.bioChardata do
		ui["poker_zob_select"..i].Visible = false
		ui["PokerZob"..i].Visible = true
		ui["zob_id"..i].Text = data.bioItemdata[i].itemID
		ui["zob_resource"..i].Text = data.bioChardata[i].resourceName
		if data.bioChardata[i].state == 0 then
			ui["poker_zob_lock"..i].Visible = true
			ui["poker_zob_time"..i].Visible =false
			ui["pokerZob_bg"..i].PushDown = false
			ui["poker_zob"..i].Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("InGameUI/select_person/ig_common_xuanren_"..data.bioChardata[i].resourceName..".dds", Vector4(0, 0, 0, 0)),
			}
		elseif data.bioChardata[i].state == 1 then
			ui["poker_zob_lock"..i].Visible = false
			ui["poker_zob_time"..i].Visible = true
			ui["poker_zob_time"..i].Text = lang:GetText("剩余")..math.floor(data.bioChardata[i].leftSeconds/3600/24)..lang:GetText("天")
			if math.floor(data.bioChardata[i].leftSeconds/3600/24) == 0 then
				ui["poker_zob_time"..i].Text = lang:GetText("剩余")..math.floor(data.bioChardata[i].leftSeconds/3600)..lang:GetText("小时")
			end
			ui["poker_zob"..i].Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("InGameUI/select_person/ig_common_xuanren_"..data.bioChardata[i].resourceName..".dds", Vector4(0, 0, 0, 0)),
			}
			ui["pokerZob_bg"..i].PushDown = false
		elseif data.bioChardata[i].state == 2 then
			ui["poker_zob_lock"..i].Visible = false
			ui["poker_zob_time"..i].Visible = true
			ui["poker_zob_select"..i].Visible = true
			ui["poker_zob_time"..i].Text = lang:GetText("剩余")..math.floor(data.bioChardata[i].leftSeconds/3600/24)..lang:GetText("天")
			if math.floor(data.bioChardata[i].leftSeconds/3600/24) == 0 then
				ui["poker_zob_time"..i].Text = lang:GetText("剩余")..math.floor(data.bioChardata[i].leftSeconds/3600)..lang:GetText("小时")
			end
			ui["pokerZob_bg"..i].PushDown = true
			ui["poker_zob"..i].Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("InGameUI/select_person/ig_common_xuanren_down_"..data.bioChardata[i].resourceName.."_red.dds", Vector4(0, 0, 0, 0)),
			}
			temp = 0
		end
	end
	ui.l_leftzob.Text = lang:GetText("X")..temp
end

--快速购买界面
local Rapid_Shopping_Win = 
{
	Gui.Control "Rapid_Shopping_root"
	{	
		Size = Vector2(1200, 900),
		BackgroundColor = ARGB(0, 255, 255, 255),
		Location = Vector2(0, 0),
		
		Gui.Control
		{	
			Size = Vector2(377, 395),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Dock = "kDockCenter",
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/main_bar01.dds", Vector4(20, 20, 20, 20)),
			},

			Gui.Control
			{	
				Size = Vector2(355, 372),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Location = Vector2(11, 12),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/main_bar02.dds", Vector4(8, 8, 8, 8)),
				},
				
				Gui.Label
				{
					Size = Vector2(353, 35),
					Location = Vector2(0, 0),
					TextColor = ARGB(255, 255, 210, 0),
					FontSize = 18,
					TextAlign = "kAlignLeftMiddle",
					Text = lang:GetText("快速购买"),
					BackgroundColor = ARGB(255,255,255,255),
					TextPadding = Vector4(8,0,0,8),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_onlinetime_bg_5.dds", Vector4(8, 8, 8, 8)),
					},
				},
				
				Gui.Control
				{	
					Size = Vector2(325, 280),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Location = Vector2(16, 39),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_01.dds", Vector4(40, 40, 40, 40)),
					},
					
					Gui.Control
					{	
						Size = Vector2(274, 228),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Location = Vector2(24, 10),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_06.dds", Vector4(32, 28, 32, 50)),
						},
						
						Gui.Label "name"
						{
							Size = Vector2(274, 28),
							Location = Vector2(0, 0),
							TextColor = ARGB(255, 255, 210, 0),
							FontSize = 18,
							TextAlign = "kAlignCenterMiddle",
							Text = lang:GetText("密码卡"),
							BackgroundColor = ARGB(0,255,255,255),
							TextPadding = Vector4(0,0,0,3),
						},
						
						Gui.TextArea "des"
						{
							Size = Vector2(244, 50),
							Location = Vector2(27, 105),
							TextColor = ARGB(255, 255, 210, 0),
							FontSize = 12,
							Readonly = true,
							Fold = true,
							BackgroundColor = ARGB(255,255,255,255),
						},
						
						Gui.Button "b_fc_1"
						{
							Size = Vector2(111,28),
							Location = Vector2(23, 160),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Text = lang:GetText("100FC/1天"),
							FontSize = 12,
							TextColor = ARGB(255, 255, 174, 0),
							HighlightTextColor = ARGB(255, 255, 174, 0),
							TextAlign = "kAlignCenterMiddle",
							Padding = Vector4(0, 0, 0, 5),
							Visible = false,
							PushDown = true,
							Skin = Gui.ButtonSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/Compose/lb_fastsettlement_button01_normal.dds", Vector4(20, 28, 6, 8)),
								HoverImage = Gui.Image("LobbyUI/Compose/lb_fastsettlement_button01_hover.dds", Vector4(20, 28, 6, 8)),
								DownImage = Gui.Image("LobbyUI/Compose/lb_manage_button_down.dds", Vector4(20, 28, 6, 8)),
								DisabledImage = Gui.Image("LobbyUI/Compose/lb_fastsettlement_button01_disabled.dds", Vector4(20, 28, 6, 8)),
							},
							EventClick = function()
								pay_id = 1
								Rapid_Shopping_Win_ui.b_fc_1.PushDown = true
								Rapid_Shopping_Win_ui.b_fc_2.PushDown = false
								Rapid_Shopping_Win_ui.b_fc_3.PushDown = false
								Rapid_Shopping_Win_ui.b_fc_4.PushDown = false
								Rapid_Shopping_Win_ui.Total_money.Text = tempData.bioItemdata[select_zob].crprices[1].cost
							end
						},
						Gui.Button "b_fc_2"
						{
							Size = Vector2(111,28),
							Location = Vector2(142, 160),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Text = lang:GetText("100FC/1天"),
							FontSize = 12,
							TextAlign = "kAlignCenterMiddle",
							TextColor = ARGB(255, 255, 174, 0),
							HighlightTextColor = ARGB(255, 255, 174, 0),
							Padding = Vector4(0, 0, 0, 5),
							Visible = false,
							Skin = Gui.ButtonSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/Compose/lb_fastsettlement_button01_normal.dds", Vector4(20, 28, 6, 8)),
								HoverImage = Gui.Image("LobbyUI/Compose/lb_fastsettlement_button01_hover.dds", Vector4(20, 28, 6, 8)),
								DownImage = Gui.Image("LobbyUI/Compose/lb_manage_button_down.dds", Vector4(20, 28, 6, 8)),
								DisabledImage = Gui.Image("LobbyUI/Compose/lb_fastsettlement_button01_disabled.dds", Vector4(20, 28, 6, 8)),
							},
							EventClick = function()
								pay_id = 2
								Rapid_Shopping_Win_ui.b_fc_1.PushDown = false
								Rapid_Shopping_Win_ui.b_fc_2.PushDown = true
								Rapid_Shopping_Win_ui.b_fc_3.PushDown = false
								Rapid_Shopping_Win_ui.b_fc_4.PushDown = false
								Rapid_Shopping_Win_ui.Total_money.Text = tempData.bioItemdata[select_zob].crprices[2].cost
							end
						},
						Gui.Button "b_fc_3"
						{
							Size = Vector2(111,28),
							Location = Vector2(23, 190),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Text = lang:GetText("100FC/1天"),
							FontSize = 12,
							TextAlign = "kAlignCenterMiddle",
							TextColor = ARGB(255, 255, 174, 0),
							HighlightTextColor = ARGB(255, 255, 174, 0),
							Padding = Vector4(0, 0, 0, 5),
							Visible = false,
							Skin = Gui.ButtonSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/Compose/lb_fastsettlement_button01_normal.dds", Vector4(20, 28, 6, 8)),
								HoverImage = Gui.Image("LobbyUI/Compose/lb_fastsettlement_button01_hover.dds", Vector4(20, 28, 6, 8)),
								DownImage = Gui.Image("LobbyUI/Compose/lb_manage_button_down.dds", Vector4(20, 28, 6, 8)),
								DisabledImage = Gui.Image("LobbyUI/Compose/lb_fastsettlement_button01_disabled.dds", Vector4(20, 28, 6, 8)),
							},
							EventClick = function()
								pay_id = 3
								Rapid_Shopping_Win_ui.b_fc_1.PushDown = false
								Rapid_Shopping_Win_ui.b_fc_2.PushDown = false
								Rapid_Shopping_Win_ui.b_fc_3.PushDown = true
								Rapid_Shopping_Win_ui.b_fc_4.PushDown = false
								Rapid_Shopping_Win_ui.Total_money.Text = tempData.bioItemdata[select_zob].crprices[3].cost
							end
						},
						Gui.Button "b_fc_4"
						{
							Size = Vector2(111,28),
							Location = Vector2(142, 190),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Text = lang:GetText("100FC/1天"),
							FontSize = 12,
							TextAlign = "kAlignCenterMiddle",
							TextColor = ARGB(255, 255, 174, 0),
							HighlightTextColor = ARGB(255, 255, 174, 0),
							Padding = Vector4(0, 0, 0, 5),
							Visible = false,
							Skin = Gui.ButtonSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/Compose/lb_fastsettlement_button01_normal.dds", Vector4(20, 28, 6, 8)),
								HoverImage = Gui.Image("LobbyUI/Compose/lb_fastsettlement_button01_hover.dds", Vector4(20, 28, 6, 8)),
								DownImage = Gui.Image("LobbyUI/Compose/lb_manage_button_down.dds", Vector4(20, 28, 6, 8)),
								DisabledImage = Gui.Image("LobbyUI/Compose/lb_fastsettlement_button01_disabled.dds", Vector4(20, 28, 6, 8)),
							},
							EventClick = function()
								pay_id = 4
								Rapid_Shopping_Win_ui.b_fc_1.PushDown = false
								Rapid_Shopping_Win_ui.b_fc_2.PushDown = false
								Rapid_Shopping_Win_ui.b_fc_3.PushDown = false
								Rapid_Shopping_Win_ui.b_fc_4.PushDown = true
								Rapid_Shopping_Win_ui.Total_money.Text = tempData.bioItemdata[select_zob].crprices[4].cost
							end
						},						
					},
					
					Gui.Label
					{
						Size = Vector2(110, 28),
						Location = Vector2(25, 240),
						TextColor = ARGB(255, 255, 210, 0),
						FontSize = 18,
						TextAlign = "kAlignCenterMiddle",
						Text = lang:GetText("您总共要支付"),
						BackgroundColor = ARGB(0,255,255,255),
						TextPadding = Vector4(0,0,0,3),
					},
					
					Gui.Label "Total_money"
					{
						Size = Vector2(118, 28),
						Location = Vector2(137, 240),
						TextColor = ARGB(255, 255, 210, 0),
						FontSize = 18,
						TextAlign = "kAlignCenterMiddle",
						Text = "0",
						BackgroundColor = ARGB(255,255,255,255),
						TextPadding = Vector4(0,0,0,3),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_03.dds", Vector4(8, 8, 8, 8)),
						},
					},
					
					Gui.Label
					{
						Size = Vector2(80, 28),
						Location = Vector2(257, 240),
						TextColor = ARGB(255, 255, 210, 0),
						FontSize = 18,
						TextAlign = "kAlignLeftMiddle",
						Text = lang:GetText("FC点"),
						BackgroundColor = ARGB(0,255,255,255),
						TextPadding = Vector4(0,0,0,3),
					},
				},
				
				Gui.Button
				{
					Size = Vector2(124,44),
					Location = Vector2(113, 325),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Text = lang:GetText("购 买"),
					TextColor = ARGB(255, 229, 255, 252),
					TextAlign = "kAlignCenterMiddle",
					HighlightTextColor = ARGB(255, 229, 255, 252),
					Padding = Vector4(0, 0, 0, 5),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_onlinetime_button_2_normal.dds", Vector4(0, 0, 0, 0)),
						HoverImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_onlinetime_button_2_hover.dds", Vector4(0, 0, 0, 0)),
						DownImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_onlinetime_button_2_down.dds", Vector4(0, 0, 0, 0)),
						DisabledImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_onlinetime_button_2_disabled.dds", Vector4(0, 0, 0, 0)),
					},
					EventClick = function()
						L_LobbyMain.Buy_Goods(ptr_cast(game.CurrentState):GetUserId(), ptr_cast(game.CurrentState):GetCharacterId(), tempData.bioItemdata[select_zob].itemID, 4, 1, tempData.bioItemdata[select_zob].crprices[pay_id].id, 0 , true)
					end,
				},
			},
		},
		
		Gui.ItemBoxBtn "itembox_hummer"
		{
			Style = "Gui.ItemBoxBtn_ib",
			Size = Vector2(153,79),
			Location = Vector2(522,343),--38 10
			BackgroundColor = ARGB(255,255,255,255),
			Skin = Gui.ItemBoxBtnSkin
			{
				NeutralNormalImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_02.dds", Vector4(0, 0, 0, 0)),
				--NeutralHoverImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_02.dds", Vector4(0, 0, 0, 0)),
				NeutralSelectedImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_02.dds", Vector4(0, 0, 0, 0)),
				NeutralDisabledImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_02.dds", Vector4(0, 0, 0, 0)),
			},
		},
		--退出
		Gui.Button
		{
			Size = Vector2(48,48),
			Location = Vector2(743, 250),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_normal.dds", Vector4(10, 10, 10, 10)),
				HoverImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_hover.dds", Vector4(10, 10, 10, 10)),
				DownImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_down.dds", Vector4(10, 10, 10, 10)),
				DisabledImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_disabled.dds", Vector4(0, 0, 0, 0)),	
			},
			EventClick = function()
				HideRapidShoppingWin()
			end,
		},
	},
}

function ShowRapidShoppingWin()
	if Rapid_Shopping_Win_ui == nil then
		Rapid_Shopping_Win_ui = Gui.Create()(Rapid_Shopping_Win)
		--快速购买界面初始化
		RapidShopping_Window = ModalWindow.GetNew("Rapid_Shopping_Win_ui")
		RapidShopping_Window.screen.AllowEscToExit = false
		RapidShopping_Window.screen.Visible = false
		--RapidShopping_Window.screen.EventEscPressed = HideCharmBottleWin
		RapidShopping_Window.screen.EventEscPressed = nil
		RapidShopping_Window.root.Size = Vector2(1200, 900)
		Rapid_Shopping_Win_ui.Rapid_Shopping_root.Parent = RapidShopping_Window.root
	end
	if RapidShopping_Window and RapidShopping_Window.screen then
		RapidShopping_Window.screen.Visible = true
		--gui.EventEscPressed = HideCharmBottleWin
		gui.EventEscPressed = nil
	end
end

function HideRapidShoppingWin()
	if RapidShopping_Window and RapidShopping_Window.screen then
		RapidShopping_Window.screen.Visible = false
		Rapid_Shopping_Win_ui = nil
	end
end

function FillRapidShoppingWin(i)
	Rapid_Shopping_Win_ui.name.Text = tempData.bioItemdata[i].display
	Rapid_Shopping_Win_ui.des.Text = tempData.bioItemdata[i].description
	Rapid_Shopping_Win_ui.itembox_hummer.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..tempData.bioItemdata[i].name..".tga")
	for  j = 1, #tempData.bioItemdata[i].crprices do
		Rapid_Shopping_Win_ui["b_fc_"..j].Visible = true
		Rapid_Shopping_Win_ui["b_fc_"..j].Text = tempData.bioItemdata[i].crprices[j].cost.."FC/"..tempData.bioItemdata[i].crprices[j].unit..lang:GetText("天")
	end
	for  j = 1, #tempData.bioItemdata[i].crprices do
		Rapid_Shopping_Win_ui["b_fc_"..j].Visible = true
		Rapid_Shopping_Win_ui["b_fc_"..j].Text = tempData.bioItemdata[i].crprices[j].cost.."FC/"..tempData.bioItemdata[i].crprices[j].unit..lang:GetText("天")
		if Rapid_Shopping_Win_ui["b_fc_"..j].PushDown then
			Rapid_Shopping_Win_ui.Total_money.Text = tempData.bioItemdata[i].crprices[j].cost
		end
	end
end

function Show(parent_win)
	Is_changed = false
	Table = {{0, ""},{0, ""},{0, ""},{0, ""},{0, ""},{0, ""},{0, ""},{0, ""},{0, ""},{0, ""}}
	Fill()
	ui.root.Parent = parent_win
end

function Initialize()
end

function Finalize()
end

function Hide()
	ui.root.Parent = nil
end

-- ui = Gui.Create()
-- {
	-- Gui.Control "root"
	-- {
		-- Size = Vector2(1116, 586),
		-- Location = Vector2(19, 25),
		-- BackgroundColor = ARGB(255, 255, 255, 255),
		-- Skin = Gui.ControlSkin
		-- {
			-- BackgroundImage = Gui.Image("LobbyUI/lb_shop_bg2.dds", Vector4(14, 14, 14, 14)),
		-- },
		-- Gui.Control 
		-- {
			-- Size = Vector2(1101, 580),
			-- Location = Vector2(9, 3),
			-- BackgroundColor = ARGB(255, 255, 255, 255),
			-- Skin = Gui.ControlSkin
			-- {
				-- BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_daoju_bg.tga", Vector4(22, 22, 22, 22)),
			-- },
			-- Gui.Control "car1"
			-- {
				-- Size = Vector2(821, 51),
				-- Location = Vector2(148, 270),
				-- BackgroundColor = ARGB(255, 255, 255, 255),
				-- Skin = Gui.ControlSkin
				-- {
					-- BackgroundImage = Gui.Image("LobbyUI/Manage/lb_manage_van_btm.dds", Vector4(10, 0, 10, 10)),
				-- },
			-- },
			-- Gui.Control 
			-- {
				-- Size = Vector2(936, 104),
				-- Location = Vector2(45, 249),
				-- BackgroundColor = ARGB(255, 255, 255, 255),
				-- Skin = Gui.ControlSkin
				-- {
					-- BackgroundImage = Gui.Image("LobbyUI/Manage/lb_manage_van_mid.dds", Vector4(0, 0, 0, 0)),
				-- },
			-- },
			-- Gui.Control "place"
			-- {
				-- Size = Vector2(920, 320),
				-- Location = Vector2(76 , 0),
				-- BackgroundColor = ARGB(255, 255, 255, 255),
				-- Skin = Gui.ControlSkin
				-- {
					-- BackgroundImage = Gui.Image("LobbyUI/Manage/lb_manage_van_top.dds", Vector4(0, 0, 0, 0)),
				-- },
				
				-- Gui.Button "kuang"
				-- {
					-- Location = Vector2(118, 65),
					-- Size = Vector2(740, 205),
					-- BackgroundColor = ARGB(255, 255, 255, 255),
					-- blink = true,
					-- blinkwheelTimer = 1.5,
					-- Skin = Gui.ButtonSkin
					-- {
						-- --BackgroundImage = Gui.Image("LobbyUI/dailycheck/lb_tutorial_square01.dds", Vector4(10, 10, 10, 10)),
						-- TwinkleImage = Gui.Image("LobbyUI/dailycheck/lb_tutorial_square02.dds", Vector4(10, 10, 10, 10)),
					-- },
				-- },	
				
				-- Gui.Control
				-- {
					-- Size = Vector2(132, 180),
					-- Location = Vector2(129, 79),
					-- BackgroundColor = ARGB(0, 255, 255, 255),
					-- Gui.Label
					-- {
						-- Size = Vector2(132, 180),
						-- Location = Vector2(0, 0),
						-- Text = lang:GetText("在下方选择任意\n职业带入战斗"),
						-- TextAlign = "kAlignCenterMiddle",
						-- TextColor = ARGB(255, 247, 238, 222),
						-- TextPadding = Vector4(0, 0, 0, 8),
					-- },
					-- Gui.Control
					-- {
						-- Visible = false,
						-- Size = Vector2(116, 180),
						-- Location = Vector2(8, 0),
						-- BackgroundColor = ARGB(255, 255, 255, 255),
					-- },
					-- Gui.Control
					-- {
						-- Visible = false,
						-- Size = Vector2(82, 35),
						-- Location = Vector2(23, 135),
						-- BackgroundColor = ARGB(255, 255, 255, 255),
						-- Skin = Gui.ControlSkin
						-- {
							-- BackgroundImage = Gui.Image("LobbyUI/Manage/lb_manage_bag_locked_02.dds", Vector4(13, 13, 13, 13)),
						-- },
						-- Gui.Button
						-- {
							-- Size = Vector2(78, 30),
							-- Location = Vector2(2, 2),
							-- Text = lang:GetText("解 锁"),
							-- TextAlign = "kAlignCenterMiddle",
							-- Padding = Vector4(0, 0, 0, 1),
							-- Skin = Gui.ButtonSkin
							-- {
								-- BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button04_normal_b.dds", Vector4(10, 10, 10, 10)),
								-- HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button04_hover_b.dds", Vector4(10, 10, 10, 10)),
								-- DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button04_down_b.dds", Vector4(10, 10, 10, 10)),
								-- DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button04_normal_b.dds", Vector4(10, 10, 10, 10)),
							-- },
						-- },
					-- },
					-- Gui.Button
					-- {
						-- Size = Vector2(20, 20),
						-- Location = Vector2(108, 2),
						-- Skin = Gui.ButtonSkin
						-- {
							-- BackgroundImage = Gui.Image("LobbyUI/Manage/lb_manage_button04_normal.dds", Vector4(10, 10, 10, 10)),
							-- HoverImage = Gui.Image("LobbyUI/Manage/lb_manage_button04_hover.dds", Vector4(10, 10, 10, 10)),
							-- DownImage = Gui.Image("LobbyUI/Manage/lb_manage_button04_down.dds", Vector4(10, 10, 10, 10)),
							-- DisabledImage = Gui.Image("LobbyUI/Manage/lb_manage_button04_normal.dds", Vector4(10, 10, 10, 10)),
						-- },
						-- EventClick = function()
							-- cancel( 1 )
						-- end
					-- },
				-- },
				-- Gui.Control
				-- {
					-- Size = Vector2(132, 180),
					-- Location = Vector2(273, 79),
					-- BackgroundColor = ARGB(0, 255, 255, 255),
					-- Gui.Label
					-- {
						-- Size = Vector2(132, 180),
						-- Location = Vector2(0, 0),
						-- Text = lang:GetText("在下方选择任意\n职业带入战斗"),
						-- TextAlign = "kAlignCenterMiddle",
						-- TextColor = ARGB(255, 247, 238, 222),
						-- TextPadding = Vector4(0, 0, 0, 8),
					-- },
					-- Gui.Control
					-- {
						-- Visible = false,
						-- Size = Vector2(116, 180),
						-- Location = Vector2(8, 0),
						-- BackgroundColor = ARGB(255, 255, 255, 255),
					-- },
					-- Gui.Control
					-- {
						-- Visible = false,
						-- Size = Vector2(82, 35),
						-- Location = Vector2(23, 135),
						-- BackgroundColor = ARGB(255, 255, 255, 255),
						-- Skin = Gui.ControlSkin
						-- {
							-- BackgroundImage = Gui.Image("LobbyUI/Manage/lb_manage_bag_locked_02.dds", Vector4(13, 13, 13, 13)),
						-- },
						-- Gui.Button
						-- {
							-- Size = Vector2(78, 30),
							-- Location = Vector2(2, 2),
							-- Text = lang:GetText("解 锁"),
							-- TextAlign = "kAlignCenterMiddle",
							-- Padding = Vector4(0, 0, 0, 1),
							-- Skin = Gui.ButtonSkin
							-- {
								-- BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button04_normal_b.dds", Vector4(10, 10, 10, 10)),
								-- HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button04_hover_b.dds", Vector4(10, 10, 10, 10)),
								-- DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button04_down_b.dds", Vector4(10, 10, 10, 10)),
								-- DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button04_normal_b.dds", Vector4(10, 10, 10, 10)),
							-- },
						-- },
					-- },
					-- Gui.Button
					-- {
						-- Size = Vector2(20, 20),
						-- Location = Vector2(108, 2),
						-- Skin = Gui.ButtonSkin
						-- {
							-- BackgroundImage = Gui.Image("LobbyUI/Manage/lb_manage_button04_normal.dds", Vector4(10, 10, 10, 10)),
							-- HoverImage = Gui.Image("LobbyUI/Manage/lb_manage_button04_hover.dds", Vector4(10, 10, 10, 10)),
							-- DownImage = Gui.Image("LobbyUI/Manage/lb_manage_button04_down.dds", Vector4(10, 10, 10, 10)),
							-- DisabledImage = Gui.Image("LobbyUI/Manage/lb_manage_button04_normal.dds", Vector4(10, 10, 10, 10)),
						-- },
						-- EventClick = function()
							-- cancel( 2 )
						-- end
					-- },
				-- },
				-- Gui.Control
				-- {
					-- Size = Vector2(132, 180),
					-- Location = Vector2(417, 79),
					-- BackgroundColor = ARGB(0, 255, 255, 255),
					-- Gui.Label
					-- {
						-- Size = Vector2(132, 180),
						-- Location = Vector2(0, 0),
						-- Text = lang:GetText("在下方选择任意\n职业带入战斗"),
						-- TextAlign = "kAlignCenterMiddle",
						-- TextColor = ARGB(255, 247, 238, 222),
						-- TextPadding = Vector4(0, 0, 0, 8),
					-- },
					-- Gui.Control
					-- {
						-- Visible = false,
						-- Size = Vector2(116, 180),
						-- Location = Vector2(8, 0),
						-- BackgroundColor = ARGB(255, 255, 255, 255),
					-- },
					-- Gui.Control
					-- {
						-- Visible = false,
						-- Size = Vector2(82, 35),
						-- Location = Vector2(23, 135),
						-- BackgroundColor = ARGB(255, 255, 255, 255),
						-- Skin = Gui.ControlSkin
						-- {
							-- BackgroundImage = Gui.Image("LobbyUI/Manage/lb_manage_bag_locked_02.dds", Vector4(13, 13, 13, 13)),
						-- },
						-- Gui.Button
						-- {
							-- Size = Vector2(78, 30),
							-- Location = Vector2(2, 2),
							-- Text = lang:GetText("解 锁"),
							-- TextAlign = "kAlignCenterMiddle",
							-- Padding = Vector4(0, 0, 0, 1),
							-- Skin = Gui.ButtonSkin
							-- {
								-- BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button04_normal_b.dds", Vector4(10, 10, 10, 10)),
								-- HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button04_hover_b.dds", Vector4(10, 10, 10, 10)),
								-- DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button04_down_b.dds", Vector4(10, 10, 10, 10)),
								-- DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button04_normal_b.dds", Vector4(10, 10, 10, 10)),
							-- },
						-- },
					-- },
					-- Gui.Button
					-- {
						-- Size = Vector2(20, 20),
						-- Location = Vector2(108, 2),
						-- Skin = Gui.ButtonSkin
						-- {
							-- BackgroundImage = Gui.Image("LobbyUI/Manage/lb_manage_button04_normal.dds", Vector4(10, 10, 10, 10)),
							-- HoverImage = Gui.Image("LobbyUI/Manage/lb_manage_button04_hover.dds", Vector4(10, 10, 10, 10)),
							-- DownImage = Gui.Image("LobbyUI/Manage/lb_manage_button04_down.dds", Vector4(10, 10, 10, 10)),
							-- DisabledImage = Gui.Image("LobbyUI/Manage/lb_manage_button04_normal.dds", Vector4(10, 10, 10, 10)),
						-- },
						-- EventClick = function()
							-- cancel( 3 )
						-- end
					-- },
				-- },
				-- Gui.Control
				-- {
					-- Size = Vector2(132, 180),
					-- Location = Vector2(561, 79),
					-- BackgroundColor = ARGB(0, 255, 255, 255),
					-- Gui.Label
					-- {
						-- Size = Vector2(132, 180),
						-- Location = Vector2(0, 0),
						-- Text = lang:GetText("在下方选择任意\n职业带入战斗"),
						-- TextAlign = "kAlignCenterMiddle",
						-- TextColor = ARGB(255, 247, 238, 222),
						-- TextPadding = Vector4(0, 0, 0, 8),
					-- },
					-- Gui.Control
					-- {
						-- Visible = false,
						-- Size = Vector2(116, 180),
						-- Location = Vector2(8, 0),
						-- BackgroundColor = ARGB(255, 255, 255, 255),
					-- },
					-- Gui.Control
					-- {
						-- Visible = false,
						-- Size = Vector2(82, 35),
						-- Location = Vector2(23, 135),
						-- BackgroundColor = ARGB(255, 255, 255, 255),
						-- Skin = Gui.ControlSkin
						-- {
							-- BackgroundImage = Gui.Image("LobbyUI/Manage/lb_manage_bag_locked_02.dds", Vector4(13, 13, 13, 13)),
						-- },
						-- Gui.Button
						-- {
							-- Size = Vector2(78, 30),
							-- Location = Vector2(2, 2),
							-- Text = lang:GetText("解 锁"),
							-- TextAlign = "kAlignCenterMiddle",
							-- Padding = Vector4(0, 0, 0, 1),
							-- Skin = Gui.ButtonSkin
							-- {
								-- BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button04_normal_b.dds", Vector4(10, 10, 10, 10)),
								-- HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button04_hover_b.dds", Vector4(10, 10, 10, 10)),
								-- DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button04_down_b.dds", Vector4(10, 10, 10, 10)),
								-- DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button04_normal_b.dds", Vector4(10, 10, 10, 10)),
							-- },
							-- EventClick = function()
								-- rpc.safecall("character_size_release",{pid = ptr_cast(game.CurrentState):GetCharacterId()},
								-- function(data)
									-- if data.error == nil then
										-- Count = 0
										-- Table = {{0, ""},{0, ""},{0, ""},{0, ""},{0, ""},{0, ""},{0, ""},{0, ""},{0, ""},{0, ""}}
										-- Fill()
									-- end
								-- end)
							-- end
						-- },
					-- },
					-- Gui.Button
					-- {
						-- Size = Vector2(20, 20),
						-- Location = Vector2(108, 2),
						-- Skin = Gui.ButtonSkin
						-- {
							-- BackgroundImage = Gui.Image("LobbyUI/Manage/lb_manage_button04_normal.dds", Vector4(10, 10, 10, 10)),
							-- HoverImage = Gui.Image("LobbyUI/Manage/lb_manage_button04_hover.dds", Vector4(10, 10, 10, 10)),
							-- DownImage = Gui.Image("LobbyUI/Manage/lb_manage_button04_down.dds", Vector4(10, 10, 10, 10)),
							-- DisabledImage = Gui.Image("LobbyUI/Manage/lb_manage_button04_normal.dds", Vector4(10, 10, 10, 10)),
						-- },
						-- EventClick = function()
							-- cancel( 4 )
						-- end
					-- },
				-- },
				-- Gui.Control
				-- {
					-- Size = Vector2(132, 180),
					-- Location = Vector2(705, 79),
					-- BackgroundColor = ARGB(0, 255, 255, 255),
					-- Skin = Gui.ControlSkin
					-- {
						-- BackgroundImage = Gui.Image("LobbyUI/Manage/lb_manage_bag_locked.dds", Vector4(0, 0, 0, 0)),
					-- },
					-- Gui.Label
					-- {
						-- Size = Vector2(132, 180),
						-- Location = Vector2(0, 0),
						-- Text = lang:GetText("在下方选择任意\n职业带入战斗"),
						-- TextAlign = "kAlignCenterMiddle",
						-- TextColor = ARGB(255, 247, 238, 222),
						-- TextPadding = Vector4(0, 0, 0, 8),
					-- },
					-- Gui.Control
					-- {
						-- Visible = false,
						-- Size = Vector2(116, 180),
						-- Location = Vector2(8, 0),
						-- BackgroundColor = ARGB(255, 255, 255, 255),
					-- },
					-- Gui.Control
					-- {
						-- Visible = false,
						-- Size = Vector2(82, 35),
						-- Location = Vector2(23, 135),
						-- BackgroundColor = ARGB(255, 255, 255, 255),
						-- Skin = Gui.ControlSkin
						-- {
							-- BackgroundImage = Gui.Image("LobbyUI/Manage/lb_manage_bag_locked_02.dds", Vector4(13, 13, 13, 13)),
						-- },
						-- Gui.Button
						-- {
							-- Size = Vector2(78, 30),
							-- Location = Vector2(2, 2),
							-- Text = lang:GetText("解 锁"),
							-- TextAlign = "kAlignCenterMiddle",
							-- Padding = Vector4(0, 0, 0, 1),
							-- Skin = Gui.ButtonSkin
							-- {
								-- BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button04_normal_b.dds", Vector4(10, 10, 10, 10)),
								-- HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button04_hover_b.dds", Vector4(10, 10, 10, 10)),
								-- DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button04_down_b.dds", Vector4(10, 10, 10, 10)),
								-- DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button04_normal_b.dds", Vector4(10, 10, 10, 10)),
							-- },
							-- EventClick = function()
								-- rpc.safecall("character_size_release",{pid = ptr_cast(game.CurrentState):GetCharacterId()},
								-- function(data)
									-- if data.error == nil then
										-- Count = 0
										-- Table = {{0, ""},{0, ""},{0, ""},{0, ""},{0, ""},{0, ""},{0, ""},{0, ""},{0, ""},{0, ""}}
										-- Fill()
									-- end
								-- end)
							-- end
						-- },
					-- },
					-- Gui.Button
					-- {
						-- Size = Vector2(20, 20),
						-- Location = Vector2(108, 2),
						-- Skin = Gui.ButtonSkin
						-- {
							-- BackgroundImage = Gui.Image("LobbyUI/Manage/lb_manage_button04_normal.dds", Vector4(10, 10, 10, 10)),
							-- HoverImage = Gui.Image("LobbyUI/Manage/lb_manage_button04_hover.dds", Vector4(10, 10, 10, 10)),
							-- DownImage = Gui.Image("LobbyUI/Manage/lb_manage_button04_down.dds", Vector4(10, 10, 10, 10)),
							-- DisabledImage = Gui.Image("LobbyUI/Manage/lb_manage_button04_normal.dds", Vector4(10, 10, 10, 10)),
						-- },
						-- EventClick = function()
							-- cancel( 5 )
						-- end
					-- },
				-- },
				
				-- Gui.Button
				-- {
					-- Visible = false,
					-- Size = Vector2(94, 28),
					-- Location = Vector2(435, 271),
					-- Text = lang:GetText("确 定"),
					-- TextAlign = "kAlignCenterMiddle",
					-- Padding = Vector4(0, 0, 0, 1),
					-- Skin = Gui.ButtonSkin
					-- {
						-- BackgroundImage = Gui.Image("LobbyUI/Manage/lb_manage_button02_normal.dds", Vector4(10, 0, 10, 0)),
						-- HoverImage = Gui.Image("LobbyUI/Manage/lb_manage_button02_hover.dds", Vector4(10, 0, 10, 0)),
						-- DownImage = Gui.Image("LobbyUI/Manage/lb_manage_button02_down.dds", Vector4(10, 0, 10, 0)),
						-- DisabledImage = nil,
					-- },
					-- EventClick = function()
						-- local args = ""
						-- local count = 0
						-- for i,v in ipairs(Table) do
							-- if v[1] == 1 then
								-- if count == 0 then
									-- args = args..i
								-- else
									-- args = args..","..i
								-- end
								-- count = count + 1
							-- end
						-- end
						-- rpc.safecall("character_set",{pid = ptr_cast(game.CurrentState):GetCharacterId(),cids = args},
						-- function(data)
							-- if data.error == nil then
								-- L_LobbyMain.HideAll()
								-- if L_LobbyMain.LobbyMainWin_Boddy then
									-- L_WarZone.Show(L_LobbyMain.LobbyMainWin_Boddy.LobbyMainWin_Boddy_Root)
								-- end
								-- lg:SetLobbyModules(5)
								-- current_chosse_main_page = 5
								-- all_false()
								-- MessageBox.ShowWithTimer(1,lang:GetText("设置成功"))
							-- end
						-- end)
					-- end
				-- },
				
				-- Gui.Control "place_bar"
				-- {
					-- Size = Vector2(359, 40),
					-- Location = Vector2(300, 30),
					-- BackgroundColor = ARGB(255, 255, 255, 255),
					-- Skin = Gui.ControlSkin
					-- {
						-- BackgroundImage = Gui.Image("LobbyUI/Manage/lb_manage_van_top_01.dds", Vector4(15, 0, 18, 0)),
					-- },
				-- },
				
				-- Gui.Label "place_bar_text"
				-- {
					-- Size = Vector2(359, 40),
					-- Location = Vector2(300, 30),
					-- BackgroundColor = ARGB(0, 255, 255, 255),
					-- Text = lang:GetText("参战名单"),
					-- FontSize = 18,
					-- TextAlign = "kAlignCenterMiddle",
				-- },
			-- },

			-- Gui.Button "kuang2"
			-- {
				-- Location = Vector2(48, 347),
				-- Size = Vector2(590, 232),
				-- BackgroundColor = ARGB(255, 255, 255, 255),
				-- blink = true,
				-- blinkwheelTimer = 1.5,
				-- Skin = Gui.ButtonSkin
				-- {
					-- TwinkleImage = Gui.Image("LobbyUI/dailycheck/lb_tutorial_square02.dds", Vector4(10, 10, 10, 10)),
				-- },
				-- EventClick = function()
				
				-- end
			-- },
			
			-- Gui.Control "Pokers"
			-- {
				-- Size = Vector2(806, 226),
				-- BackgroundColor = ARGB(0, 255, 255, 255),
			-- },

			-- Gui.Label "jieshi"
			-- {
				-- Size = Vector2(480, 190),
				-- Location = Vector2(620, 310),
				-- BackgroundColor = ARGB(255, 255, 255, 255),
				-- Text = lang:GetText("1,点击人物右上角的“x”	\n	或下方的扑克牌卸下职业\n2,点击下方的扑克牌更换职业\n3,点击确定保存配置			 "), 
				-- FontSize = 18,
				-- TextAlign = "kAlignLeftMiddle",
				-- TextPadding = Vector4(50,5,0,5),
				-- TextColor = ARGB(255, 0, 0, 0),
				-- Skin = Gui.ControlSkin
				-- {
					-- BackgroundImage = Gui.Image("LobbyUI/Manage/lb_tutorial_bg01.dds", Vector4(14, 14, 14, 14)),
				-- },
			-- },
			
			-- Gui.Label "up_qiantou"
			-- {
				-- Location = Vector2(820, 282),
				-- NormLocation = Vector2(820, 282),
				-- Size = Vector2(48, 48),
				-- BackgroundColor = ARGB(255, 255, 255, 255),				
				-- MoveLocation = Vector2(0,15),
				-- MoveWheelTime = 1.0,
				-- Skin = Gui.ControlSkin
				-- {
					-- BackgroundImage = Gui.Image("LobbyUI/Manage/lb_tutorial_arrow01.dds", Vector4(10, 10, 10, 10)),
				-- },
			-- },
			-- Gui.Label "left_qiantou"
			-- {
				-- Location = Vector2(640, 480),
				-- NormLocation = Vector2(640, 480),
				-- Size = Vector2(48, 48),
				-- BackgroundColor = ARGB(255, 255, 255, 255),
				-- MoveLocation = Vector2(20,0),
				-- MoveWheelTime = 1.0,
				-- Skin = Gui.ControlSkin
				-- {
					-- BackgroundImage = Gui.Image("LobbyUI/Manage/lb_tutorial_arrow02.dds", Vector4(10, 10, 10, 10)),
				-- },
			-- },
		-- },
		-- Gui.Label
		-- {
			-- Size = Vector2(170, 80),
			-- Location = Vector2(924, 484),
			-- BackgroundColor = ARGB(255, 255, 255, 255),
			-- Skin = Gui.ControlSkin
			-- {
				-- BackgroundImage = Gui.Image("LobbyUI/mail/lb_common_button_bg01.dds", Vector4(14, 14, 14, 14)),
			-- },
			-- Gui.Button 
			-- {
				-- Location = Vector2(9, 4),
				-- Size = Vector2(152, 72),
				-- BackgroundColor = ARGB(255,255,255,255),
				-- Skin = Gui.ButtonSkin
				-- {
					-- BackgroundImage = Gui.Image("LobbyUI/Manage/lb_manage_button_confirm_normal.dds", Vector4(5, 5, 5, 5)),
					-- HoverImage = Gui.Image("LobbyUI/Manage/lb_manage_button_confirm_hover.dds", Vector4(5, 5, 5, 5)),
					-- DownImage = Gui.Image("LobbyUI/Manage/lb_manage_button_confirm_down.dds", Vector4(5, 5, 5, 5)),
					-- DisabledImage = nil,			
				-- },
				-- EventClick = function()
					-- local args = ""
					-- local count = 0
					-- for i,v in ipairs(Table) do
						-- if v[1] == 1 then
							-- if count == 0 then
								-- args = args..i
							-- else
								-- args = args..","..i
							-- end
							-- count = count + 1
						-- end
					-- end
					-- rpc.safecall("character_set",{pid = ptr_cast(game.CurrentState):GetCharacterId(),cids = args},
					-- function(data)
						-- if data.error == nil then
							-- L_LobbyMain.HideAll()
							-- if L_LobbyMain.LobbyMainWin_Boddy then
								-- L_WarZone.Show(L_LobbyMain.LobbyMainWin_Boddy.LobbyMainWin_Boddy_Root)
							-- end
							-- lg:SetLobbyModules(5)
							-- current_chosse_main_page = 5
							-- all_false()
							-- MessageBox.ShowWithTimer(1,lang:GetText("设置成功"))
						-- end
					-- end)
				-- end
			-- },
		-- },
		-- Gui.Button "btn_Close"
		-- {
			-- Size = Vector2(80, 60),
			-- Location = Vector2(1028, 3),
			-- Hint = lang:GetText("关闭参战名单"),
			-- Skin = Gui.ButtonSkin
			-- {
				-- BackgroundImage = Gui.Image("LobbyUI/Manage/lb_manage_button01_normal.dds", Vector4(5, 5, 5, 5)),
				-- HoverImage = Gui.Image("LobbyUI/Manage/lb_manage_button01_hover.dds", Vector4(5, 5, 5, 5)),
				-- DownImage = Gui.Image("LobbyUI/Manage/lb_manage_button01_down.dds", Vector4(5, 5, 5, 5)),
				-- DisabledImage = Gui.Image("LobbyUI/Manage/lb_manage_button01_normal.dds", Vector4(5, 5, 5, 5)),
			-- },
			-- EventClick = function()
				-- if Is_changed == true then
					-- MessageBox.ShowWithTwoButtons(lang:GetText("您已更改了参战名单，是否保存修改？"),lang:GetText("保存"),lang:GetText("退出"), 
					-- function()
						-- local args = ""
						-- local count = 0
						-- for i,v in ipairs(Table) do
							-- if v[1] == 1 then
								-- if count == 0 then
									-- args = args..i
								-- else
									-- args = args..","..i
								-- end
								-- count = count + 1
							-- end
						-- end
						-- rpc.safecall("character_set",{pid = ptr_cast(game.CurrentState):GetCharacterId(),cids = args},
						-- function(data)
							-- if data.error == nil then
								-- L_LobbyMain.HideAll()
								-- if L_LobbyMain.LobbyMainWin_Boddy then
									-- L_WarZone.Show(L_LobbyMain.LobbyMainWin_Boddy.LobbyMainWin_Boddy_Root)
								-- end
								-- lg:SetLobbyModules(5)
								-- current_chosse_main_page = 5
								-- all_false()
								-- MessageBox.ShowWithTimer(1,lang:GetText("设置成功"))
							-- end
						-- end)
					-- end,
					-- function()
						-- L_LobbyMain.HideAll()
						-- if L_LobbyMain.LobbyMainWin_Boddy then
							-- L_WarZone.Show(L_LobbyMain.LobbyMainWin_Boddy.LobbyMainWin_Boddy_Root)
						-- end
						-- lg:SetLobbyModules(5)
						-- current_chosse_main_page = 5
					-- end
					-- )
				-- else
					-- L_LobbyMain.HideAll()
					-- if L_LobbyMain.LobbyMainWin_Boddy then
						-- L_WarZone.Show(L_LobbyMain.LobbyMainWin_Boddy.LobbyMainWin_Boddy_Root)
					-- end
					-- lg:SetLobbyModules(5)
					-- current_chosse_main_page = 5
				-- end
			-- end
		-- },
	-- },
-- }

-- function Fill()
	-- rpc.safecallload("character_list",{pid = ptr_cast(game.CurrentState):GetCharacterId()},
	-- function(data)
		-- Size = data.size
		-- Max_Size = tonumber(data.openSize)
		-- -- 填充已开槽位
		-- for i = 1,data.size do
			-- local Control = ptr_cast(ui.place:GetChildByIndex(i))
			-- local Control1 = ptr_cast(Control:GetChildByIndex(0))
			-- local Control2 = ptr_cast(Control:GetChildByIndex(1))
			-- local Control3 = ptr_cast(Control:GetChildByIndex(2))
			-- Control1.Text = lang:GetText("在下方选择任意\n职业带入战斗")
			-- Control1.Visible = true
			-- Control2.Visible = false
			-- Control3.Visible = false
			-- Control.BackgroundColor = ARGB(0, 255, 255, 255)
		-- end
		-- -- 填充未开槽位
		-- for i = data.size + 1, 5 do
			-- local Control = ptr_cast(ui.place:GetChildByIndex(i))
			-- local Control1 = ptr_cast(Control:GetChildByIndex(0))
			-- local Control2 = ptr_cast(Control:GetChildByIndex(1))
			-- local Control3 = ptr_cast(Control:GetChildByIndex(2))
			-- if i == data.size + 1 then
				-- Control3.Visible = false
			-- else
				-- Control3.Visible = false
			-- end
			-- Control.BackgroundColor = ARGB(255, 255, 255, 255)
			-- Control.Skin = Gui.ControlSkin
			-- {
				-- BackgroundImage = Gui.Image("LobbyUI/Manage/lb_manage_bag_locked.dds", Vector4(0, 0, 0, 0)),
			-- }
			-- Control2.Visible = false
			-- Control1.Visible = true
			-- Control1.Text = lang:GetText("请前往商城购买\n“角色扩展包”\n添加额外参战名额")
		-- end
		-- ui.Pokers:OnDestroy()
		-- ui.Pokers.Size = Vector2(74 * (data.openSize - 1) + 140, 226)
		-- local my_count = 1
		-- for i = 1, #L_LobbyMain.character_classes do
			-- if data.data[#L_LobbyMain.character_classes - i + 1].is_open == 1 then
				-- local Poker = Gui.Create()
				-- {
					-- Gui.Control "root"
					-- {
						-- Size = Vector2(140, 200),
						-- Location = Vector2(0, 0),
						-- BackgroundColor = ARGB(0, 255, 255, 255),
						-- Gui.Control "Image"
						-- {
							-- Location = Vector2(0, 0),
							-- Size = Vector2(140, 200),
							-- BackgroundColor = ARGB(255, 255, 255, 255),
							-- Skin = Gui.ControlSkin
							-- {
								-- BackgroundImage = Gui.Image("LobbyUI/Manage/lb_manage_poker_sniper_hover.dds", Vector4(0, 0, 0, 0)),
							-- },
						-- },
						-- Gui.Control "Image1"
						-- {
							
							-- Location = Vector2(10, 15),
							-- Size = Vector2(119, 170),
							-- BackgroundColor = ARGB(255, 255, 255, 255),
							-- Skin = Gui.ControlSkin
							-- {
								-- BackgroundImage = Gui.Image("LobbyUI/Manage/ig_common_xuanren_down_olred.dds", Vector4(0, 0, 0, 0)),
							-- },
						-- },
						-- Gui.Button
						-- {
							-- Size = Vector2(140, 200),
							-- Location = Vector2(0, 0),
							-- BackgroundColor = ARGB(255, 255, 255, 255),
							-- Skin = Gui.ButtonSkin
							-- {
								-- BackgroundImage = Gui.Image("LobbyUI/Manage/lb_manage_poker_normal.dds", Vector4(5, 5, 5, 5)),
								-- HoverImage = nil,
								-- DownImage = nil,
								-- DisabledImage = nil,
							-- },
							-- EventClick = function(Sender,e)
								-- Is_changed = true
								-- if Sender.Parent.Location.y == 0 then
									-- Sender.Parent.Location = Vector2(Sender.Parent.Location.x, 26)
									-- local c_id = ptr_cast(Sender.Parent:GetChildByIndex(3))
									-- local c_resource = ptr_cast(Sender.Parent:GetChildByIndex(4))
									-- Table[tonumber(c_id.Text)][1] = 0
									-- Count = Count - 1
								-- elseif Sender.Parent.Location.y == 26 and Count < data.size then
									-- Sender.Parent.Location = Vector2(Sender.Parent.Location.x, 0)
									-- local c_id = ptr_cast(Sender.Parent:GetChildByIndex(3))
									-- local c_resource = ptr_cast(Sender.Parent:GetChildByIndex(4))
									-- Table[tonumber(c_id.Text)][1] = 1
									-- Table[tonumber(c_id.Text)][2] = c_resource.Text
									-- Count = Count + 1
								-- end
								-- Fill_Car()
							-- end,
							
							-- EventMouseEnter = function(Sender,e)
								-- Sender.BackgroundColor = ARGB(0, 255, 255, 255)
							-- end,
							
							-- EventMouseLeave = function(Sender,e)
								-- if Sender.Parent.Location.y == 26 then
									-- Sender.BackgroundColor = ARGB(255, 255, 255, 255)
								-- end
							-- end,
						-- },
						-- Gui.Label "c_id"
						-- {
							-- Visible = false,
						-- },
						-- Gui.Label "c_resource"
						-- {
							-- Visible = false,
						-- },
					-- },
				-- }
				-- Poker.root.Location = Vector2((74 * (data.openSize - 1) + 74 - (my_count * 74)), 26)
				-- Poker.root.Parent = ui.Pokers
				-- Poker.c_id.Text = data.data[#L_LobbyMain.character_classes - i + 1].cid
				-- Poker.c_resource.Text = data.data[#L_LobbyMain.character_classes - i + 1].resource
				-- Poker.Image.Skin = Gui.ControlSkin
				-- {
					-- BackgroundImage = Gui.Image("LobbyUI/Manage/lb_manage_poker_"..data.data[#L_LobbyMain.character_classes - i + 1].resourceName.."_hover.dds", Vector4(0, 0, 0, 0)),
				-- }
				-- Poker.Image1.Skin = Gui.ControlSkin
				-- {
					-- BackgroundImage = Gui.Image("InGameUI/select_person/ig_common_xuanren_down_"..data.data[#L_LobbyMain.character_classes - i + 1].resource.."_red.dds", Vector4(0, 0, 0, 0)),
				-- }
				-- my_count = my_count + 1
			-- end
		-- end
		-- Count = #data.select
		-- for i = 1, Count do
			-- for j = 1, data.openSize do
				-- local Poker = ptr_cast(ui.Pokers:GetChildByIndex(j - 1))
				-- local c_id = ptr_cast(Poker:GetChildByIndex(3))
				-- if tonumber(c_id.Text) == data.select[i] then
					-- Poker.Location = Vector2(Poker.Location.x, 0)
					-- local button = ptr_cast(Poker:GetChildByIndex(2))
					-- local c_resource = ptr_cast(Poker:GetChildByIndex(4))
					-- button.BackgroundColor = ARGB(0, 255, 255, 255)
					-- Table[tonumber(c_id.Text)][1] = 1
					-- Table[tonumber(c_id.Text)][2] = c_resource.Text
				-- end
			-- end
		-- end
		-- Fill_Car()
		-- Gui.Align(ui.Pokers, 0.1, 1.0)
	-- end)
-- end

-- function Fill_Car()
	-- local num = 1
	-- for i,v in ipairs(Table) do
		-- if v[1] == 1 then
			-- local Image = ptr_cast(ui.place:GetChildByIndex(num))
			-- local Image0 = ptr_cast(Image:GetChildByIndex(0))
			-- local Image1 = ptr_cast(Image:GetChildByIndex(1))
			-- local Image2 = ptr_cast(Image:GetChildByIndex(3))
			-- Image0.Visible = false
			-- Image1.Visible = true
			-- Image1.Skin = Gui.ControlSkin
			-- {
				-- BackgroundImage = Gui.Image("InGameUI/select_person/ig_common_xuanren_down_"..v[2].."_red.dds", Vector4(0, 0, 0, 0)),
			-- }
			-- Image2.Visible = true
			-- num = num + 1
		-- end
	-- end
	-- for i = num, Size do
		-- local Image = ptr_cast(ui.place:GetChildByIndex(i))
		-- local Image0 = ptr_cast(Image:GetChildByIndex(0))
		-- local Image1 = ptr_cast(Image:GetChildByIndex(1))
		-- local Image2 = ptr_cast(Image:GetChildByIndex(3))
		-- Image0.Visible = true
		-- Image1.Visible = false
		-- Image2.Visible = false
	-- end
	-- ui.car1.Location = Vector2(148, 270 + 3 * Count)
	-- ui.place.Location = Vector2(76, 3 * Count)
-- end

-- function cancel( index )
	-- local count = 0
	-- Is_changed = true
	-- for i = 1, Max_Size do
		-- local control1 = ptr_cast(ui.Pokers:GetChildByIndex(Max_Size - i))
		-- if control1.Location.y == 0 then
			-- count = count + 1
		-- end
		-- if count == index then
			-- control1.Location = Vector2(control1.Location.x, 26)
			-- local c_id = ptr_cast(control1:GetChildByIndex(3))
			-- local c_resource = ptr_cast(control1:GetChildByIndex(4))
			-- Table[tonumber(c_id.Text)][1] = 0
			-- local control2 = ptr_cast(control1:GetChildByIndex(2))
			-- control2.BackgroundColor = ARGB(255, 255, 255, 255)
			-- Count = Count - 1
			-- Fill_Car()
			-- break
		-- end
	-- end
-- end

-- function Show(parent_win)
	-- ui.root.Parent = parent_win
	-- Is_changed = false
	-- Table = {{0, ""},{0, ""},{0, ""},{0, ""},{0, ""},{0, ""},{0, ""},{0, ""},{0, ""},{0, ""}}
	-- Fill()
-- end

-- function Initialize()
-- end

-- function Finalize()
-- end

-- function Hide()
	-- ui.root.Parent = nil
-- end

-- function all_false()
	-- ui.kuang.Visible = false
	-- ui.kuang2.Visible = false
	-- ui.jieshi.Visible = false
	-- ui.up_qiantou.Visible = false 
	-- ui.left_qiantou.Visible = false 	
-- end

--参战名单新手引导触发条件框（留着备用 timmy）
-- function all_true()
	-- ui.kuang.Visible = true
	-- ui.kuang2.Visible = true
	-- ui.jieshi.Visible = true
	-- ui.up_qiantou.Visible = true 
	-- ui.left_qiantou.Visible = true 	
-- end

-- new_Characters = Gui.Create()
-- {
	-- Gui.Button "main_kuang"
	-- {
		-- Location = Vector2(118, 65),
		-- Size = Vector2(140, 82),
		-- BackgroundColor = ARGB(255, 255, 255, 255),
		-- Skin = Gui.ButtonSkin
		-- {
			-- BackgroundImage = Gui.Image("LobbyUI/Manage/lb_tutorial_square01.dds", Vector4(10, 10, 10, 10)),
		-- },
		-- EventClick = function()
			-- all_true()
		-- end
	-- },	
	-- Gui.Label "abc"
	-- {
		-- Size = Vector2(144, 76),
		-- Location = Vector2(800, 360),
		-- BackgroundColor = ARGB(255, 255, 255, 255),
		-- Text = "abc！",
		-- FontSize = 20,
		-- TextAlign = "kAlignCenterMiddle",
		-- TextColor = ARGB(255, 0, 0, 0),
		-- Visible = false,
		-- Skin = Gui.ControlSkin
		-- {
			-- BackgroundImage = Gui.Image("LobbyUI/Manage/lb_tutorial_bg02.dds", Vector4(14, 14, 14, 14)),
		-- },
	-- },
	-- Gui.Label "up"
	-- {
		-- Location = Vector2(820, 292),
		-- NormLocation = Vector2(820, 292),
		-- Size = Vector2(40, 48),
		-- BackgroundColor = ARGB(255, 255, 255, 255),				
		-- MoveLocation = Vector2(0,15),
		-- MoveWheelTime = 1.0,
		-- Skin = Gui.ControlSkin
		-- {
			-- BackgroundImage = Gui.Image("LobbyUI/Manage/lb_tutorial_arrow01.dds", Vector4(10, 10, 10, 10)),
		-- },
	-- },
-- }