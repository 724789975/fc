module("L_TopList", package.seeall)
local name = nil
local id = nil
local vip = nil
local current_cid = 0
local sub_type = 1
local other_pid = nil
local top_num = nil

rpc_bag_data = nil

--当前排行的模式: 1 个人排名；2 每周排名；3 战队排名；4 趣味排名
local rank_mode = 1

local rank_mode_key =
{
	"kFightNum",
	"kWeek",
	"",
	"kJoy",
}

local fun_mode =
{
	lang:GetText("赏金击杀数"),
	lang:GetText("复仇次数"),
	--lang:GetText("助攻数"),
	lang:GetText("近身杀人数"),
}

local single_mode = 
{
	lang:GetText("综合"),
	lang:GetText("火箭兵"),
	lang:GetText("重机枪手"),
	lang:GetText("狙击手"),
	lang:GetText("突击手"),
	lang:GetText("火焰兵"),
	lang:GetText("医疗兵"),
	lang:GetText("工程兵"),
}

local sub_mode = 
{
	"kFightNum",
	"kScore",
	"kKillDead",
	"kAssist",
	"kWinRate",
}

local fun_type_key = 
{
    "kControl",
	"kRevenge",
	--"kAssist",
	"kKnife",
}

local text_color_list = 
{
	gold = ARGB(255, 255, 240, 0),
	silvery =  ARGB(255, 222, 222, 222),
	copper =  ARGB(255, 255, 138, 0),
}

local text_color = nil

--当前选着的页数
local rank_select_page = 1

--我的页数
local my_rank_page = -1

--最大页数
local max_page = -1

--定位到我 -- myself:0,N;1,Y	
local myself = 0 

local function Create_tab_button(index, name, displayname)
	return Gui.Button ("tab_button_"..index)
	{
		Size = Vector2(140, 48),
		Location = Vector2(1, 10 + (index - 1) * 54),
		Text = "     "..name,
		TextColor = ARGB(255, 217, 209, 201),
		HighlightTextColor = ARGB(255, 5, 7, 8),
		FontSize = 20,
		TextAlign = "kAlignLeftMiddle",
		Skin = Gui.ButtonSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab02_"..displayname.."normal.dds", Vector4(0, 0, 0, 0)),
			HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab02_"..displayname.."down.dds", Vector4(0, 0, 0, 0)),
			DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab02_"..displayname.."down.dds", Vector4(0, 0, 0, 0)),
			--DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab02_fairmannormal.dds", Vector4(0, 0, 0, 0)),
		},
		EventClick = function()
			current_cid = index - 1
			--FillTabButton()
			rank_select_page = 1
			if sub_type == 1 then
				Filltreeview()
			else
				FillCharacter(other_pid)
			end
		end
	}
end

local function Create_list_label_1(index)
	return Gui.Label ("list1_label_"..index)
	{
		Size = Vector2(384, 28),
		TextAlign = "kAlignLeftMiddle",
		FontSize = 16,
		TextColor = ARGB(255, 200, 255, 254),
	}
end

local function Create_list_label_2(index, text)
	return Gui.Label ("list2_label_"..index)
	{
		Size = Vector2(234, 28),
		Text = text,
		FontSize = 16,
		TextAlign = "kAlignLeftMiddle",
		TextColor = ARGB(255, 255, 255, 255),
	}
end

local function SpawnControl_1(index)
	return Gui.Control ("con_strength_image"..index)
	{
		Size = Vector2(54,30),
		Location = Vector2(175 - 60,80 - 40),
		BackgroundColor = ARGB(255, 255, 255, 255),
	}
end

function SpawnNewStarControl(index)
	return Gui.Control ("ib_star"..index)
	{	
		Visible = false,
		Size = Vector2(68,12),
		Location = Vector2(175 - 110,10),
		BackgroundColor = ARGB(255, 255, 255, 255),
	}
end

local function SpawnControl_2(index)
	return Gui.Control ("con_strength_image"..index)
	{
		Size = Vector2(54,30),
		Location = Vector2(88 - 60,160 - 40),
		BackgroundColor = ARGB(255, 255, 255, 255),
	}
end

local function SpawnControl_3(index)
	return Gui.Control ("con_strength_image"..index)
	{
		Size = Vector2(54,30),
		Location = Vector2(88 - 60,80 - 40),
		BackgroundColor = ARGB(255, 255, 255, 255),
	}
end

--排行榜界面
rank_ui = Gui.Create()
{
	Gui.Control "root"
	{
		Size = Vector2(1116, 586),
		Location = Vector2(19, 25),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/lb_shop_bg2.dds", Vector4(14, 14, 14, 14)),
		},

		Gui.Control "con_1"
		{
			Size = Vector2(1116, 586),
			Location = Vector2(0, 0),
			Gui.Control "con_1_bg"
			{
				Size = Vector2(1101, 551),
				Location = Vector2(9, 34),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_daoju_bg.tga", Vector4(22, 22, 22, 22)),
				},
				Gui.Control
				{
					Size = Vector2(282, 534),
					Location = Vector2(9, 6),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/TopList/lb_rank_bg_01.dds", Vector4(10, 10, 10, 10)),
					},
					Gui.Control "con_lvl"
					{
						Size = Vector2(40, 36),
						Location = Vector2(5, 30),
						BackgroundColor = ARGB(0, 255, 255, 255),
						
						--LV
						Gui.Control "lb_UserLevel"
						{
							Location = Vector2(0, 0),
							Size = Vector2(40, 36),
							BackgroundColor = ARGB(255,255,255,255),
							Skin = Gui.ControlSkin
							{
								BackgroundImage = nil,
							},
						},
						
						--十位
						Gui.Label "lb_UserLevel_Ten"
						{
							Size = Vector2(13,24),
							Location = Vector2(9, 2),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_summary_number_6b.dds", Vector4(0, 0, 0, 0),Vector4(0, 0, 0.1, 1)),
							},
						},
						
						--十位百分比
						Gui.Label "lb_UserLevel_TenState"
						{
							Size = Vector2(13,0),
							Location = Vector2(9, 26),
							BackgroundColor = ARGB(255, 255, 255, 255),			
						},
						
						--个位
						Gui.Label "lb_UserLevel_Anold"
						{
							Size = Vector2(13,24),
							Location = Vector2(19, 2),
							BackgroundColor = ARGB(255,255,255,255),
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_summary_number_6b.dds", Vector4(0, 0, 0, 0),Vector4(0, 0, 0.1, 1)),
							},
						},
						
						--个位百分比
						Gui.Label "lb_UserLevel_AnoldState"
						{
							Size = Vector2(13,0),
							Location = Vector2(19, 26),
							BackgroundColor = ARGB(255,255,255,255),
						},

					},
					Gui.Control "ctrl_Avatar_Main"
					{
						Size = Vector2(282, 452),
						Location = Vector2(0, 84),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg3.dds", Vector4(22, 22, 22, 22)),
						},
					},
					Gui.Control "con_vip"
					{
						Size = Vector2(30, 21),
						Location = Vector2(45, 36),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/vip/lb_1_ico_0_big.dds", Vector4(0, 0, 0, 0)),
						},
					},
					Gui.Label "lab_name"
					{
						Size = Vector2(210, 28),
						Location = Vector2(73, 33),
						TextColor = ARGB(255, 234, 255, 0),
						FontSize = 16,
						BackgroundColor = ARGB(0, 255, 255, 255),
						TextAlign = "kAlignCenterMiddle",
					},
					
					Gui.Label "team_name"
					{
						Size = Vector2(210, 20),
						Location = Vector2(73, 64),
						FontSize = 16,
						TextAlign = "kAlignCenterMiddle",
						TextColor = ARGB(255, 200, 255, 253),
					},
					Gui.Label
					{
						Size = Vector2(120, 20),
						Location = Vector2(5, 64),
						Text = lang:GetText("所属战队"),
						FontSize = 18,
						TextColor = ARGB(255, 25, 237, 222),
					},
					
					Gui.Control "ctrl_Avatar_Main"
					{
						Size = Vector2(280, 450),
						Location = Vector2(1, 84),
						
						--人物显示
						Gui.CharacterViewer "character_viewer"
						{
							Size = Vector2(280, 449),
							Location = Vector2(5, 1),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg3_guang.tga", Vector4(0, 0, 0, 0)),
							},
						},

						--旋转角色
						Gui.Button "btn_rotate_avatar"
						{
							Size = Vector2(68, 24),
							Location = Vector2(12, 420),
							Padding = Vector4(0, 0, 0, 4),
							Skin = Gui.ButtonSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button10_normal.dds", Vector4(0, 0, 0, 0)),
								HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button10_hover.dds", Vector4(0, 0, 0, 0)),
								DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button10_down.dds", Vector4(0, 0, 0, 0)),
								DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button10_normal.dds", Vector4(0, 0, 0, 0)),
							},
							EventClick = function()
								lg:RotateCharacter()
							end
						},

						--切换阵营
						Gui.Button "btn_change_team"
						{
							Size = Vector2(88, 24),
							Location = Vector2(82, 420),
							Padding = Vector4(0, 0, 0, 4),
							Skin = Gui.ButtonSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button11_normal.dds", Vector4(0, 0, 0, 0)),
								HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button11_hover.dds", Vector4(0, 0, 0, 0)),
								DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button11_down.dds", Vector4(0, 0, 0, 0)),
								DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button11_normal.dds", Vector4(0, 0, 0, 0)),
							},
							EventClick = function()
								L_LobbyMain.current_Avatar_Team = (L_LobbyMain.current_Avatar_Team + 1) % 2
								L_LobbyMain.ChangeAvatarPart()
							end
						},
						Gui.Button 
						{
							Size = Vector2(80, 24),
							Location = Vector2(170, 420),
							Padding = Vector4(0, 0, 0, 4),
							Skin = Gui.ButtonSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/TopList/lb_rank_button02_normal.dds", Vector4(10, 10, 10, 10)),
								HoverImage = Gui.Image("LobbyUI/TopList/lb_rank_button02_hover.dds", Vector4(10, 10, 10, 10)),
								DownImage = Gui.Image("LobbyUI/TopList/lb_rank_button02_down.dds", Vector4(10, 10, 10, 10)),
								DisabledImage = nil,
							},
							EventClick = function()
								character_bag.rank_num_text.Visible = true
								character_bag.rank_num.Visible = true
								character_bag.root.Visible = not character_bag.root.Visible
							end
						},
						Gui.Control "fight_num_BG"
						{							
							Size = Vector2(270, 52),
							Location = Vector2(5, 1),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_power_bg_1.dds", Vector4(0, 0, 0, 0)),
							},
							Gui.FlowLayout "fightnum"
							{
								Location = Vector2(110,13),
								Size = Vector2(111,24),
								Align = "kAlignCenterMiddle",
								ControlAlign = "kAlignCenterMiddle",
								ControlSpace = 0,
							},
							Gui.Button "des_button"
							{
								Size = Vector2(50, 32),
								Location = Vector2(213, 8),
								Skin = Gui.ButtonSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_power_button_1_1_normal.dds", Vector4(0, 0, 0, 0)),
									HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_power_button_1_1_hover.dds", Vector4(0, 0, 0, 0)),
									DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_power_button_1_1_down.dds", Vector4(0, 0, 0, 0)),
									DisabledImage = nil,
								},
								EventClick = function(sender, e)
									if not L_LobbyMain.ui_des_bag.root.Parent then
										L_LobbyMain.ui_des_bag.root.Location = Vector2(265, 387)
										L_LobbyMain.ui_des_bag.root.Parent = L_LobbyMain.LobbyMainWin.LobbyMain_Root_Parent
									end
									sender.Visible = false
									rank_ui.des_button_close.Visible = true
								end,
							},
							Gui.Button "des_button_close"
							{
								Size = Vector2(50, 32),
								Location = Vector2(213, 8),
								EventClick = function(sender, e)
									if L_LobbyMain.ui_des_bag.root.Parent then
										L_LobbyMain.ui_des_bag.root.Parent = nil
									end
									sender.Visible = false
									rank_ui.des_button.Visible = true
								end,
							},
						},
					},
				},
				
				Gui.Label
				{
					Size = Vector2(279, 27),
					Location = Vector2(591, 62),
					Text = lang:GetText("我的排名"),
					TextColor = ARGB(255, 0, 0, 0),
					TextAlign = "kAlignRightMiddle",
					FontSize = 18,
				},
				
				Gui.Label
				{
					Size = Vector2(279, 27),
					Location = Vector2(590, 61),
					Text = lang:GetText("我的排名"),
					TextColor = ARGB(255, 196, 134, 53),
					TextAlign = "kAlignRightMiddle",
					FontSize = 18,
				},
				
				Gui.Control
				{
					Size = Vector2(215, 85),
					Location = Vector2(877, 38),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/TopList/lb_rank_roller01.dds", Vector4(40, 20, 40, 20)),
					},
					
					Gui.Label "ranknum"
					{
						Size = Vector2(124, 52),
						Location = Vector2(20, 15),
						BackgroundColor = ARGB(255, 255, 255, 255),
						TextAlign = "kAlignCenterMiddle",
						TextPadding = Vector4(0, 0, 0, 0),
						FontSize = 24,
						TextColor = ARGB(255, 0, 0, 0),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/TopList/lb_rank_roller02.dds", Vector4(20, 26, 20, 26)),
						},
					},
					
					Gui.Button
					{
						Size = Vector2(52, 52),
						Location = Vector2(145, 16),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/TopList/lb_rank_button01_normal.dds", Vector4(0, 0, 0, 0)),
							HoverImage = Gui.Image("LobbyUI/TopList/lb_rank_button01_hover.dds", Vector4(0, 0, 0, 0)),
							DownImage = Gui.Image("LobbyUI/TopList/lb_rank_button01_down.dds", Vector4(0, 0, 0, 0)),
							DisabledImage = nil,
						},
						EventClick = function(Sender,e)
							if rank_mode == 1 and tonumber(rank_ui.ranknum.Text) > 10000 then
								MessageBox.ShowWithConfirm(lang:GetText("您未进入前10000名\n请继续努力"))
								return 
							end
							if rank_mode == 2 and top_num > 400 and (rank_ui.ranknum.Text ~= lang:GetText("未进入排名") or tonumber(rank_ui.ranknum.Text) > 400)  then
								MessageBox.ShowWithConfirm(lang:GetText("您未进入前400名\n请继续努力"))
								return 
							end
							myself = 1
							Filltreeview()
						end
					},
				},
				
				Gui.Control 
				{							
					Location = Vector2(290, 120),
					Size = Vector2(803, 421),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg3.dds", Vector4(22, 22, 22, 22)),
					},
					
					Gui.Control "con1_ltv_bg"
					{
						Location = Vector2(10, 10),
						Size = Vector2(783, 368),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/lb_battlefield_serverlist_bg01b.tga", Vector4(7, 42, 7, 8)),
						},
						Gui.ListTreeView "con1_ltv"
						{
							ItemHeight = 33,
							Location = Vector2(0, 8),
							Size = Vector2(817, 369),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Style = "Gui.ListTreeViewWith_VScroll",
							HScrollBarDisplay = "kHide",
							VScrollBarDisplay = "kHide",
							TreeVisible = false,
							AlwaysSelect = true,
							HeaderHeight = 30,
						},
					},
					Gui.Label
					{
						Size = Vector2(200, 20),
						Location = Vector2(10, 387),
						Text = lang:GetText("跳转至第"),
						TextAlign = "kAlignRightMiddle",
						FontSize = 18,
						TextColor = ARGB(255, 217, 209, 201),
					},
					Gui.Textbox "tbx_page"
					{
						Size = Vector2(73, 31),
						Location = Vector2(215, 382),
						Text = "",
						TextPadding = Vector4(30, 0, 0, 0),
						FontSize = 18,
						TextColor = ARGB(255, 210, 209, 193),
						InputNumberOnly = true,
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/TopList/lb_rank_bg_01.dds", Vector4(0, 0, 0, 0)),
						},
						EventTextChanged = function(Sender,e)
							if Sender.Text ~= "" and tonumber(Sender.Text) > max_page then
								Sender.Text = max_page
							end
							if Sender.Text ~= "" and tonumber(Sender.Text) < 1 then
								Sender.Text = 1
							end
							Sender.TextPadding = Vector4(35 - 5*string.len(Sender.Text),0,0,0)
						end
					},
					Gui.Button
					{
						Size = Vector2(63, 31),
						Location = Vector2(305, 382),
						Padding = Vector4(0, 0, 0, 4),
						Text = "OK",
						TextAlign = "kAlignCenterMiddle",
						TextColor = ARGB(255, 0, 0, 0),
						FontSize = 18,
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button04_normal.dds", Vector4(10, 10, 10, 10)),
							HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button04_hover.dds", Vector4(10, 10, 10, 10)),
							DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button04_down.dds", Vector4(10, 10, 10, 10)),
							DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button04_normal.dds", Vector4(10, 10, 10, 10)),
						},
						EventClick = function(Sender,e)
							if tonumber(rank_ui.tbx_page.Text) then
								if tonumber(rank_ui.tbx_page.Text) < 1 then
									rank_select_page = 1
								elseif tonumber(rank_ui.tbx_page.Text) > max_page then
									rank_select_page = max_page
								else
									rank_select_page =  tonumber(rank_ui.tbx_page.Text)
								end
								Filltreeview()
							end
						end
					},
					--上一页
					Gui.Button "btn_front_page"
					{
						Size = Vector2(14, 31),
						Location = Vector2(570, 382),
						TextColor = ARGB(255, 255, 246, 235),
						FontSize = 18,
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/lb_shop_button05_normal.dds", Vector4(0, 0, 0, 0)),
							HoverImage = Gui.Image("LobbyUI/lb_shop_button05_hover.dds", Vector4(0, 0, 0, 0)),
							DownImage = Gui.Image("LobbyUI/lb_shop_button05_down.dds", Vector4(0, 0, 0, 0)),
							DisabledImage = Gui.Image("LobbyUI/lb_shop_button05_normal.dds", Vector4(0, 0, 0, 0)),
						},
						EventClick = function()
							if rank_select_page > 1 then
								rank_select_page = rank_select_page - 1
								Filltreeview()
							end
						end
					},
				
					--页码
					Gui.Label "lb_page_number"
					{
						Location = Vector2(590, 379),
						Size = Vector2(175, 37),
						FontSize = 24,
						TextAlign = "kAlignCenterMiddle",
						TextColor = ARGB(255, 103, 102, 98),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button06_bg.dds", Vector4(14, 14, 14, 14)),
						},
					},

					--下一页
					Gui.Button "btn_next_page"
					{
						Size = Vector2(14, 31),
						Location = Vector2(769, 382),
						TextColor = ARGB(255, 255, 246, 235),
						FontSize = 18,
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/lb_shop_button06_normal.dds", Vector4(0, 0, 0, 0)),
							HoverImage = Gui.Image("LobbyUI/lb_shop_button06_hover.dds", Vector4(0, 0, 0, 0)),
							DownImage = Gui.Image("LobbyUI/lb_shop_button06_down.dds", Vector4(0, 0, 0, 0)),
							DisabledImage = Gui.Image("LobbyUI/lb_shop_button06_normal.dds", Vector4(0, 0, 0, 0)),
						},
						EventClick = function()
							if rank_select_page < max_page then
								rank_select_page = rank_select_page + 1
								Filltreeview()
							end
						end
					},
				},
				
				
				
				Gui.ComboBox "cbx_Type"
				{
					Size = Vector2(350, 36),
					Location = Vector2(300, 59),
					FontSize = 18,
					Text = lang:GetText("综合战斗力"),
					TextPadding = Vector4(0, 0, 0, 0),
					TextColor = ARGB(255, 217, 209, 201),
					HighlightTextColor = ARGB(255, 217, 209, 201),
					TextAlign = "kAlignCenterMiddle",
					ChildComboListStyle =  "Gui.ChangeJobComboList",
					
					Skin = Gui.ComboBoxSkin
					{
						ButtonNormalImage= Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_button_normal.dds", Vector4(0, 0, 0, 0)),
						ButtonHoverImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_button_hover.dds", Vector4(0, 0, 0, 0)),
						ButtonDownImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_button_down.dds", Vector4(0, 0, 0, 0)),
						
						TextNormalImage= Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_text.dds", Vector4(6, 0, 0, 0)),
						TextHoverImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_text.dds", Vector4(6, 0, 0, 0)),
						TextDownImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_text.dds", Vector4(6, 0, 0, 0)),	
					},
					
					EventItemSelected = function()
						if rank_ui.cbx_Type.SelectedIndex < #single_mode then
							current_cid = rank_ui.cbx_Type.SelectedIndex
							sub_type = 1
						else
							current_cid = 0
							sub_type = rank_ui.cbx_Type.SelectedIndex - (#single_mode - 2)
						end
						rank_select_page = 1
						Filltreeview()
					end,
				},
			},
		},
		
		Gui.Control "con_2"
		{
			Size = Vector2(1101, 551),
			Location = Vector2(9, 35),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Visible = false,
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_daoju_bg.tga", Vector4(22, 22, 22, 22)),
			},
			Gui.ComboBox "mode"
			{
				Visible = false,
				Size = Vector2(327, 36),
				Location = Vector2(46, 62),		
				Readonly = true,
				Skin = Gui.ComboBoxSkin
				{
					ButtonNormalImage= Gui.Image("LobbyUI/team/lb_squad_combobox_button_normal.dds", Vector4(0, 0, 0, 0)),
					ButtonHoverImage = Gui.Image("LobbyUI/team/lb_squad_combobox_button_hover.dds", Vector4(0, 0, 0, 0)),
					ButtonDownImage = Gui.Image("LobbyUI/team/lb_squad_combobox_button_down.dds", Vector4(0, 0, 0, 0)),
					
					TextNormalImage= Gui.Image("LobbyUI/team/lb_squad_combobox_text.dds", Vector4(6, 6, 0, 6)),
					TextHoverImage = Gui.Image("LobbyUI/team/lb_squad_combobox_text.dds", Vector4(6, 6, 0, 6)),
					TextDownImage = Gui.Image("LobbyUI/team/lb_squad_combobox_text.dds", Vector4(6, 6, 0, 6)),
				},
				ChildComboListStyle = "Gui.ChangeJobComboList",
			},
			
			Gui.Label "jiezhi_1"
			{
				Size = Vector2(179, 24),
				Location = Vector2(118, 69),
				Text = lang:GetText("排名截止"),
				FontSize = 16,
				TextColor = ARGB(255, 0, 0, 0),
				TextAlign = "kAlignRightMiddle",
			},
			
			Gui.Label "jiezhi_2"
			{
				Size = Vector2(179, 24),
				Location = Vector2(117, 68),
				Text = lang:GetText("排名截止"),
				FontSize = 16,
				TextColor = ARGB(255, 196, 134, 53),
				TextAlign = "kAlignRightMiddle",
			},
			
			Gui.Control "jiezhi"
			{
				Visible = false,
				Size = Vector2(225, 76),
				Location = Vector2(297, 44),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/TopList/lb_rank_roller01.dds", Vector4(20, 20, 20, 20)),
				},
				
				Gui.Label "pmjz"
				{
					Size = Vector2(196, 52),
					Location = Vector2(15, 9),
					Text = lang:GetText("0天0小时0分钟"),
					FontSize = 18,
					TextAlign = "kAlignCenterMiddle",
					BackgroundColor = ARGB(255, 255, 255, 255),
					TextColor = ARGB(255, 0, 0, 0),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/TopList/lb_rank_roller02.dds", Vector4(25, 25, 25, 25)),
					},
				},
			},
			Gui.Control "TopImage"
			{
				Visible = false,
				Size = Vector2(124, 392),
				Location = Vector2(14, 129),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/TopList/lb_rank_image01.dds", Vector4(0, 0, 0, 0)),
				},
				Gui.Control "baiwei"
				{
					--Visible = false,
					Size = Vector2(28, 52),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/TopList/lb_rank_number01.dds", Vector4(0, 0, 0, 0),Vector4(0.8, 0, 0.9, 1)),
					},
				},
				Gui.Control "shiwei"
				{
					--Visible = false,
					Size = Vector2(28, 52),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/TopList/lb_rank_number01.dds", Vector4(0, 0, 0, 0),Vector4(0.8, 0, 0.9, 1)),
					},
				},
				Gui.Control "gewei"
				{
					Size = Vector2(28, 52),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/TopList/lb_rank_number01.dds", Vector4(0, 0, 0, 0),Vector4(0, 0, 0.1, 1)),
					},
				},
			},
			
			Gui.Label
			{
				Size = Vector2(179, 27),
				Location = Vector2(627, 68),
				Text = lang:GetText("我的排名"),
				TextColor = ARGB(255, 0, 0, 0),
				TextAlign = "kAlignRightMiddle",
				FontSize = 16,
			},
			
			Gui.Label
			{
				Size = Vector2(179, 27),
				Location = Vector2(626, 67),
				Text = lang:GetText("我的排名"),
				TextColor = ARGB(255, 196, 134, 53),
				TextAlign = "kAlignRightMiddle",
				FontSize = 16,
			},
			
			Gui.Control
			{
				Size = Vector2(215, 76),
				Location = Vector2(811, 44),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/TopList/lb_rank_roller01.dds", Vector4(20, 20, 20, 20)),
				},
				
				Gui.Label "rank"
				{
					Size = Vector2(124, 52),
					Location = Vector2(20, 9),
					Text = lang:GetText("未进入"),
					FontSize = 20,
					TextAlign = "kAlignCenterMiddle",
					BackgroundColor = ARGB(255, 255, 255, 255),
					TextColor = ARGB(255, 0, 0, 0),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/TopList/lb_rank_roller02.dds", Vector4(25, 25, 25, 25)),
					},
				},
				Gui.Button
				{
					Size = Vector2(52, 52),
					Location = Vector2(148, 10),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/TopList/lb_rank_button01_normal.dds", Vector4(0, 0, 0, 0)),
						HoverImage = Gui.Image("LobbyUI/TopList/lb_rank_button01_hover.dds", Vector4(0, 0, 0, 0)),
						DownImage = Gui.Image("LobbyUI/TopList/lb_rank_button01_down.dds", Vector4(0, 0, 0, 0)),
						DisabledImage = nil,
					},
					EventClick = function(Sender,e)
						if rank_mode == 1 and tonumber(rank_ui.ranknum.Text) > 10000 then
							MessageBox.ShowWithConfirm(lang:GetText("您未进入前10000名\n请继续努力"))
							return 
						end
						if rank_mode == 2 and top_num > 400 and (rank_ui.ranknum.Text ~= lang:GetText("未进入排名") or tonumber(rank_ui.ranknum.Text) > 400)  then
							MessageBox.ShowWithConfirm(lang:GetText("您未进入前400名\n请继续努力"))
							return 
						end
						myself = 1
						Filltreeview()
					end
				},
			},
			Gui.Control "ltv_box_Background1"
			{
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg3.dds", Vector4(22, 22, 22, 22)),
				},
			},
			Gui.Control "ltv_box_Background"
			{
				Location = Vector2(48, 123),
				Size = Vector2(1003, 370),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/lb_battlefield_serverlist_bg01b.tga", Vector4(7, 42, 7, 8)),
				},
				Gui.ListTreeView "ltv_box"
				{
					ItemHeight = 33,
					Location = Vector2(0, 8),
					Size = Vector2(1037, 369),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Style = "Gui.ListTreeViewWith_VScroll",
					HScrollBarDisplay = "kHide",
					VScrollBarDisplay = "kHide",
					TreeVisible = false,
					AlwaysSelect = true,
					HeaderHeight = 30,
				},
			},
			Gui.Control
			{
				Location = Vector2(60, 500),
				Size = Vector2(1124, 45),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Gui.Label "LJumpText"
				{
					Size = Vector2(200,32),
					Location = Vector2(90,0),
					FontSize = 18,
					TextColor = ARGB(255, 215, 232, 227),
					TextAlign = "kAlignRightMiddle",
					Text = lang:GetText("跳转至第"),
				},
				
				Gui.Textbox "page"
				{
					Size =  Vector2(80,32),
					FontSize = 20,
					Location = Vector2(291, 0),
					TextColor = ARGB(255,195,189,176),
					MaxLength = 6,
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/lb_common_textbox01_normal.dds", Vector4(5, 5, 5, 5)),
					},
				},
				
				Gui.Button "BJump"
				{
					Size =  Vector2(75,40),
					Location = Vector2(381, -5),
					FontSize = 20,
					Text = "OK",
					TextColor = ARGB(255, 0, 0, 0),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_b_hover.dds", Vector4(20, 20, 20, 20)),
						HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_b_hover.dds", Vector4(20, 20, 20, 20)),
						DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_b_down.dds", Vector4(20, 20, 20, 20)),
						DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_normal.dds", Vector4(20, 20, 20, 20)),
					},
					EventClick = function()
						if tonumber(rank_ui.page.Text) ~= nil then
							page = math.floor(tonumber(rank_ui.page.Text))
							rank_ui.page.Text = page
							if page > max_page then
								rank_ui.page.Text = max_page
							end
							if page < 1 then
								rank_ui.page.Text = 1
							end
							rank_select_page = rank_ui.page.Text
							Filltreeview()
						end
					end
				},
				
				Gui.Button "m_AcheInfoLeft"
				{	
					Size = Vector2(20,35),
					Visible = true,
					Location = Vector2(769,0),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button05_normal.dds", Vector4(0, 0, 0, 0)),
						HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button05_hover.dds", Vector4(0, 0, 0, 0)),
						DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button05_down.dds", Vector4(0, 0, 0, 0)),
						DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button05_normal.dds", Vector4(0, 0, 0, 0)),
					},
					EventClick = function()
						if rank_select_page > 1 then
							rank_select_page = rank_select_page - 1
							Filltreeview()
						end
					end
				},
				
				Gui.Label "m_AcheInfoPageDisplay"
				{
					Size = Vector2(160,35),
					FontSize = 24,
					Visible = true,
					Location = Vector2(799,0),
					TextColor = ARGB(255, 128, 128, 128),
					TextAlign = "kAlignCenterMiddle",
					Text = "1/1",
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button06_bg.dds", Vector4(14, 14, 14, 14)),
					},
				},
				
				Gui.Button "m_AcheInfoRight"
				{
					Size = Vector2(20,35),
					Visible = true,
					Location = Vector2(969,0),
					
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button06_normal.dds", Vector4(0, 0, 0, 0)),
						HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button06_hover.dds", Vector4(0, 0, 0, 0)),
						DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button06_down.dds", Vector4(0, 0, 0, 0)),
						DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button06_normal.dds", Vector4(0, 0, 0, 0)),
					},
					EventClick = function()
						if rank_select_page < max_page then
							rank_select_page = rank_select_page + 1
							Filltreeview()
						end
					end
				},
			},
		},
		
		Gui.Control "con_3"
		{
			Size = Vector2(1101, 551),
			Location = Vector2(9, 35),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Visible = false,
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_daoju_bg.tga", Vector4(22, 22, 22, 22)),
			},
		},
		Gui.Button "btn_Close"
		{
			Size = Vector2(64, 54),
			Location = Vector2(1049, 3),
			PushDown = false,
			Hint = lang:GetText("关闭排行榜并返回至战区"),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button01_normal.dds", Vector4(0, 0, 0, 0)),
				HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button01_hover.dds", Vector4(0, 0, 0, 0)),
				DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button01_down.dds", Vector4(0, 0, 0, 0)),
				DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button01_normal.dds", Vector4(0, 0, 0, 0)),
			},

			EventClick = function()
--				L_LobbyMain.HideAll()
				L_WarZone.Show(L_LobbyMain.LobbyMainWin_Boddy.LobbyMainWin_Boddy_Root)
			end
		},
	
		Gui.Control 
		{
			Size = Vector2(1022, 70),
			Location = Vector2(23, 2),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab01_bg.dds", Vector4(29, 32, 32, 19)),
			},
			Gui.FlowLayout 
			{
				Dock = "kDockFill",
				BackgroundColor = ARGB(0, 255, 255, 255),
				Margin = Vector4(27, 6, 0, 0),
				ControlSpace = 0,
				Gui.Button "personalTop"
				{
					Size = Vector2(242, 52),
					Text = lang:GetText("个人排名"),
					BackgroundColor = ARGB(255,255,255,255),
					PushDown = true,
					TextColor = ARGB(255, 37, 37, 37),
					HighlightTextColor = ARGB(255, 37, 37, 37),
					FontSize = 20,
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_normal.dds", Vector4(10, 10, 10, 10)),
						HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_hover.dds", Vector4(10, 10, 10, 10)),
						DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_down.dds", Vector4(10, 10, 10, 10)),
						DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_normal.dds", Vector4(10, 10, 10, 10)),
					},
					EventClick = function()
						rank_mode = 1
						rank_select_page = 1
						Filltreeview()
						rank_ui.personalTop.PushDown = true
						rank_ui.WeekTop.PushDown = false
						rank_ui.TeamTop.PushDown = false
						rank_ui.Funtop.PushDown = false
						rank_ui.jiezhi.Visible = false
						rank_ui.jiezhi_1.Visible = false
						rank_ui.jiezhi_2.Visible = false
						rank_ui.TopImage.Visible = false
						rank_ui.mode.Visible = true
						rank_ui.ltv_box.Location = Vector2(0, 8)
						rank_ui.ltv_box.Size = Vector2(1037, 369)
						rank_ui.ltv_box_Background1.Size = Vector2(1013, 425)
						rank_ui.ltv_box_Background1.Location = Vector2(43,118)
						rank_ui.ltv_box_Background.Location = Vector2(48, 123)
						rank_ui.ltv_box_Background.Size = Vector2(1003, 370)
					end
				},
				Gui.Button "WeekTop"
				{
					Size = Vector2(242, 52),
					Text = lang:GetText("每周排名"),
					TextColor = ARGB(255, 37, 37, 37),
					HighlightTextColor = ARGB(255, 37, 37, 37),
					FontSize = 20,
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_normal.dds", Vector4(10, 10, 10, 10)),
						HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_hover.dds", Vector4(10, 10, 10, 10)),
						DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_down.dds", Vector4(10, 10, 10, 10)),
						DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_normal.dds", Vector4(10, 10, 10, 10)),
					},
					EventClick = function()
						rank_mode = 2
						rank_select_page = 1
						Filltreeview()
						rank_ui.personalTop.PushDown = false
						rank_ui.WeekTop.PushDown = true
						rank_ui.TeamTop.PushDown = false
						rank_ui.Funtop.PushDown = false
						rank_ui.jiezhi.Visible = true
						rank_ui.jiezhi_1.Visible = true
						rank_ui.jiezhi_2.Visible = true
						if rank_select_page <= 9 then
							rank_ui.TopImage.Visible = true
						end
						rank_ui.mode.Visible = false
						rank_ui.ltv_box.Location = Vector2(0, 8)
						rank_ui.ltv_box.Size = Vector2(939, 369)
						rank_ui.ltv_box_Background.Location = Vector2(146, 123)
						rank_ui.ltv_box_Background.Size = Vector2(905, 375)
						rank_ui.ltv_box_Background1.Size = Vector2(917, 425)
						rank_ui.ltv_box_Background1.Location = Vector2(139,118)
					end
				},
				Gui.Button "TeamTop"
				{
					Size = Vector2(242, 52),
					Text = lang:GetText("战队排名"),
					TextColor = ARGB(255, 37, 37, 37),
					HighlightTextColor = ARGB(255, 37, 37, 37),
					FontSize = 20,
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_normal.dds", Vector4(10, 10, 10, 10)),
						HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_hover.dds", Vector4(10, 10, 10, 10)),
						DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_down.dds", Vector4(10, 10, 10, 10)),
						DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_normal.dds", Vector4(10, 10, 10, 10)),
					},
					EventClick = function()
						rank_mode = 3
						rank_select_page = 1
						L_FightTeam.mode = 2
						L_FightTeam.rank_select_page = 1
						L_FightTeam.team_list_type = 1
						L_FightTeam.Set_type_btn()
						L_FightTeam.default_mode = 1
						L_FightTeam.team_ui.btn_list.PushDown = true
						L_FightTeam.team_ui.btn_my.PushDown = false
						L_FightTeam.team_list_ui.root.Visible = true
						L_FightTeam.team_ui.my_team.Visible = false
						mode = 2
						Filltreeview()
						rank_ui.personalTop.PushDown = false
						rank_ui.WeekTop.PushDown = false
						rank_ui.TeamTop.PushDown = true
						rank_ui.Funtop.PushDown = false
						rank_ui.jiezhi.Visible = false
						rank_ui.jiezhi_1.Visible = false
						rank_ui.jiezhi_2.Visible = false
						rank_ui.mode.Visible = false
						rank_ui.ltv_box.Location = Vector2(0, 8)
						rank_ui.ltv_box.Size = Vector2(1037, 369)
						rank_ui.ltv_box_Background1.Size = Vector2(1013, 425)
						rank_ui.ltv_box_Background1.Location = Vector2(43,118)
						rank_ui.ltv_box_Background.Location = Vector2(48, 123)
						rank_ui.ltv_box_Background.Size = Vector2(1003, 370)
					end
				},
				Gui.Button "Funtop"
				{
					Size = Vector2(242, 52),
					Text = lang:GetText("趣味排名"),
					TextColor = ARGB(255, 37, 37, 37),
					HighlightTextColor = ARGB(255, 37, 37, 37),
					FontSize = 20,
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_normal.dds", Vector4(10, 10, 10, 10)),
						HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_hover.dds", Vector4(10, 10, 10, 10)),
						DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_down.dds", Vector4(10, 10, 10, 10)),
						DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_normal.dds", Vector4(10, 10, 10, 10)),
					},
					EventClick = function()
						rank_mode = 4
						rank_select_page = 1
						local cbx = rank_ui.mode
						cbx:RemoveAll()
						for k, v in ipairs(fun_mode) do 
							cbx:AddItem(v)
						end
						cbx.SelectedIndex = 0
						Filltreeview()
						rank_ui.personalTop.PushDown = false
						rank_ui.WeekTop.PushDown = false
						rank_ui.TeamTop.PushDown = false
						rank_ui.Funtop.PushDown = true
						rank_ui.jiezhi.Visible = false
						rank_ui.jiezhi_1.Visible = false
						rank_ui.jiezhi_2.Visible = false
						rank_ui.TopImage.Visible = false
						rank_ui.mode.Visible = true
						rank_ui.ltv_box.Location = Vector2(0, 8)
						rank_ui.ltv_box.Size = Vector2(1037, 369)
						rank_ui.ltv_box_Background1.Size = Vector2(1013, 425)
						rank_ui.ltv_box_Background1.Location = Vector2(43,118)
						rank_ui.ltv_box_Background.Location = Vector2(48, 123)
						rank_ui.ltv_box_Background.Size = Vector2(1003, 370)
					end
				},
			},
		},
	
	},
}

character_bag = Gui.Create()
{
	Gui.Control "root"
	{
		--Visible = false,
		BackgroundColor = ARGB(255, 255, 255, 255),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/TopList/lb_rank_bg_01.dds", Vector4(10, 10, 10, 10)),
		},
		Gui.Label "name_txt"
		{
			Size = Vector2(0, 0),
			BackgroundColor = ARGB(0, 255, 255, 255),
		},
		Gui.Control
		{
			Size = Vector2(190, 460),
			Location = Vector2(5, 35),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/TopList/lb_rank_bg_02.dds", Vector4(10, 10, 10, 10)),
			},
			Gui.Label "rank_num_text"
			{
				Size = Vector2(200, 20),
				Location = Vector2(15, 5),
				Text = lang:GetText("排名"),
				FontSize = 18,
				TextColor = ARGB(255, 255, 130, 1),
			},
			
			Gui.Label "rank_num"
			{
				Size = Vector2(100, 20),
				Location = Vector2(81, 6),
				Text = "1000",
				FontSize = 18,
				TextColor = ARGB(255, 200, 255, 254),
				TextAlign = "kAlignRightMiddle",
			},
			
			Gui.Control "ctrl_ib_container"
			{							
				Size = Vector2(180, 457),
				Location = Vector2(1, -5),
				BackgroundColor = ARGB(0, 255, 255, 255),
				
				--主武器
				Gui.ItemBoxBtn "ib_weapon_1"
				{
					Style = "Gui.ItemBoxBtn_ib",
					Size = Vector2(175, 80),
					Location = Vector2(3, 46),
					Padding = Vector4(0, 0, 0, 4),
					CanSelect = false,
					Skin = Gui.ItemBoxBtnSkin
					{
						NeutralNormalImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche1_normal.dds", Vector4(10, 10, 10, 10)),
						NeutralHoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche1_hover.dds", Vector4(10, 10, 10, 10)),
						NeutralSelectedImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_wuqi_down.dds", Vector4(10, 10, 10, 10)),
						NeutralDisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_caowei_zhuwuqi.dds", Vector4(10, 10, 10, 10)),
						NeutralHighlightImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche1_hover.dds", Vector4(20, 20, 20, 20)),
					},
					
					EventMouseUp = function(sender, e)
						ChangeAvatar(1)
					end,

					EventMouseEnter = function(sender, e)
						L_ToolTips.FillToolTipsWindow(3, 1, sender)
					end,
					EventToolTipsShow = function(sender, e)
						L_ToolTips.ShowToolTipsShowWindow(sender)
					end,
					EventMouseLeave = function(sender, e)
						L_ToolTips.HideToolTipsWindow()
					end,
					
					SpawnControl_1(1),
					SpawnNewStarControl(1)
				},

				--副武器
				Gui.ItemBoxBtn "ib_weapon_2"
				{
					Style = "Gui.ItemBoxBtn_ib",
					Size = Vector2(175, 80),
					Location = Vector2(3, 126),
					Padding = Vector4(0, 0, 0, 4),
					CanSelect = false,
					Skin = Gui.ItemBoxBtnSkin
					{
						NeutralNormalImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche1_normal.dds", Vector4(10, 10, 10, 10)),
						NeutralHoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche1_hover.dds", Vector4(10, 10, 10, 10)),
						NeutralSelectedImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_wuqi_down.dds", Vector4(10, 10, 10, 10)),
						NeutralDisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_caowei_fuwuqi.dds", Vector4(10, 10, 10, 10)),
						NeutralHighlightImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche1_hover.dds", Vector4(20, 20, 20, 20)),
					},
					
					EventMouseUp = function(sender, e)
						ChangeAvatar(2)
					end,

					EventMouseEnter = function(sender, e)
						if sender.Loading == false then
							L_ToolTips.FillToolTipsWindow(3, 2, sender)
						end
					end,
					EventToolTipsShow = function(sender, e)
						L_ToolTips.ShowToolTipsShowWindow(sender)
					end,
					EventMouseLeave = function(sender, e)
						L_ToolTips.HideToolTipsWindow()
					end,
					
					SpawnControl_1(2),
					SpawnNewStarControl(2)
				},

				--手雷
				Gui.ItemBoxBtn "ib_weapon_4"
				{
					Style = "Gui.ItemBoxBtn_ib2",
					Size = Vector2(88, 80),
					Location = Vector2(3, 206),
					CanSelect = false,
					Skin = Gui.ItemBoxBtnSkin
					{
						NeutralNormalImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche2_normal.dds", Vector4(10, 10, 10, 10)),
						NeutralHoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche2_hover.dds", Vector4(10, 10, 10, 10)),
						NeutralSelectedImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_wuqi_down.dds", Vector4(10, 10, 10, 10)),
						NeutralDisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_caowei_teshuwuqi.dds", Vector4(10, 10, 10, 10)),
						NeutralHighlightImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche2_hover.dds", Vector4(20, 20, 20, 20)),
					},
					
					EventMouseUp = function(sender, e)
						ChangeAvatar(4)
					end,
			
					EventMouseEnter = function(sender, e)
						if sender.Loading == false then
							L_ToolTips.FillToolTipsWindow(3, 4, sender)
						end
					end,
					EventToolTipsShow = function(sender, e)
						L_ToolTips.ShowToolTipsShowWindow(sender)
					end,
					EventMouseLeave = function(sender, e)
						L_ToolTips.HideToolTipsWindow()
					end,
					
					SpawnControl_3(4),
					SpawnNewStarControl(4)
				},

				--近身武器
				Gui.ItemBoxBtn "ib_weapon_3"
				{
					Style = "Gui.ItemBoxBtn_ib2",
					Size = Vector2(88, 80),
					Location = Vector2(91, 206),
					CanSelect = false,
					Skin = Gui.ItemBoxBtnSkin
					{
						NeutralNormalImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche2_normal.dds", Vector4(10, 10, 10, 10)),
						NeutralHoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche2_hover.dds", Vector4(10, 10, 10, 10)),
						NeutralSelectedImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_wuqi_down.dds", Vector4(10, 10, 10, 10)),
						NeutralDisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_caowei_jinshenwuqi.dds", Vector4(10, 10, 10, 10)),
						NeutralHighlightImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche2_hover.dds", Vector4(20, 20, 20, 20)),
					},
					
					EventMouseUp = function(sender, e)
						ChangeAvatar(3)
					end,

					EventMouseEnter = function(sender, e)
						if sender.Loading == false then
							L_ToolTips.FillToolTipsWindow(3, 3, sender)
						end
					end,
					EventToolTipsShow = function(sender, e)
						L_ToolTips.ShowToolTipsShowWindow(sender)
					end,
					EventMouseLeave = function(sender, e)
						L_ToolTips.HideToolTipsWindow()
					end,
					
					SpawnControl_3(3),
					SpawnNewStarControl(3)
				},

				--套装
				Gui.ItemBoxBtn "ib_costume_1"
				{
					Style = "Gui.ItemBoxBtn_ib1",
					Size = Vector2(88, 160),
					Location = Vector2(3, 286),
					CanSelect = false,
					Skin = Gui.ItemBoxBtnSkin
					{
						NeutralNormalImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche3_normal.dds", Vector4(10, 10, 10, 10)),
						NeutralHoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche3_hover.dds", Vector4(10, 10, 10, 10)),
						NeutralSelectedImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_wuqi_down.dds", Vector4(10, 10, 10, 10)),
						NeutralDisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_caowei_juese.dds", Vector4(10, 10, 10, 10)),
						NeutralHighlightImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche3_hover.dds", Vector4(20, 20, 20, 20)),
					},
					
					EventSelected = function(sender, e)
						
					end,

					EventMouseEnter = function(sender, e)
						if sender.Loading == false then
							L_ToolTips.FillToolTipsWindow(3, 5, sender)
						end
					end,
					EventToolTipsShow = function(sender, e)
						L_ToolTips.ShowToolTipsShowWindow(sender)
					end,
					EventMouseLeave = function(sender, e)
						L_ToolTips.HideToolTipsWindow()
					end,
					
					SpawnControl_2(5),
					SpawnNewStarControl(5)
				},

				--帽子
				Gui.ItemBoxBtn "ib_costume_2"
				{
					Style = "Gui.ItemBoxBtn_ib2",
					Size = Vector2(88, 80),
					Location = Vector2(91, 286),
					CanSelect = false,
					Skin = Gui.ItemBoxBtnSkin
					{
						NeutralNormalImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche2_normal.dds", Vector4(10, 10, 10, 10)),
						NeutralHoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche2_hover.dds", Vector4(10, 10, 10, 10)),
						NeutralSelectedImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_wuqi_down.dds", Vector4(10, 10, 10, 10)),
						NeutralDisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_caowei_maozi.dds", Vector4(10, 10, 10, 10)),
						NeutralHighlightImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche2_hover.dds", Vector4(20, 20, 20, 20)),
					},
					EventSelected = function(sender, e)
						
					end,

					EventMouseEnter = function(sender, e)
						if sender.Loading == false then
							L_ToolTips.FillToolTipsWindow(3, 6, sender)
						end
					end,
					EventToolTipsShow = function(sender, e)
						L_ToolTips.ShowToolTipsShowWindow(sender)
					end,
					EventMouseLeave = function(sender, e)
						L_ToolTips.HideToolTipsWindow()
					end,
					
					SpawnControl_3(6),
					SpawnNewStarControl(6)
				},

				--徽章
				Gui.ItemBoxBtn "ib_costume_3"
				{
					Style = "Gui.ItemBoxBtn_ib2",
					Size = Vector2(88, 80),
					Location = Vector2(91, 366),
					CanSelect = false,
					Skin = Gui.ItemBoxBtnSkin
					{
						NeutralNormalImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche2_normal.dds", Vector4(10, 10, 10, 10)),
						NeutralHoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche2_hover.dds", Vector4(10, 10, 10, 10)),
						NeutralSelectedImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_wuqi_down.dds", Vector4(10, 10, 10, 10)),
						NeutralDisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_caowei_huizhang.dds", Vector4(10, 10, 10, 10)),
						NeutralHighlightImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche2_hover.dds", Vector4(20, 20, 20, 20)),
					},
					EventSelected = function(sender, e)
						
					end,
					EventMouseEnter = function(sender, e)
						if sender.Loading == false then
							L_ToolTips.FillToolTipsWindow(3, 7, sender)
						end
					end,
					EventToolTipsShow = function(sender, e)
						L_ToolTips.ShowToolTipsShowWindow(sender)
					end,
					EventMouseLeave = function(sender, e)
						L_ToolTips.HideToolTipsWindow()
					end,
					
					SpawnControl_3(7),
					SpawnNewStarControl(7),
				},
			},
		},
		
		Gui.Button
		{
			Size = Vector2(208, 32),
			Location = Vector2(200, 35),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Text = lang:GetText("加为好友"),
			FontSize = 18,
			TextColor = ARGB(255, 0, 0, 0),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/Mission/lb_task_button01_normal.dds", Vector4(10, 10, 10, 10)),
				HoverImage = Gui.Image("LobbyUI/Mission/lb_task_button01_hover.dds", Vector4(10, 10, 10, 10)),
				DownImage = Gui.Image("LobbyUI/Mission/lb_task_button01_down.dds", Vector4(10, 10, 10, 10)),
				DisabledImage = Gui.Image("LobbyUI/Mission/lb_task_button01_disabled.dds", Vector4(10, 10, 10, 10)),
			},
			EventClick = function()
				 L_Friends.FriendsAdd(nil,character_bag.name_txt.Text)
			end
		},
		
		Gui.Control 
		{							
			Size = Vector2(381, 174),
			Location = Vector2(200, 83),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/TopList/lb_rank_bg_02.dds", Vector4(10, 10, 10, 10)),
			},
			Gui.Label 
			{
				Size = Vector2(252, 22),
				Location = Vector2(7, 7),
				Text = lang:GetText("抗性加成")..":",
				TextColor = ARGB(255, 196, 134, 54),
				FontSize = 16,
			},
			Gui.ScrollableControl
			{
				Size = Vector2(404, 140),
				Location = Vector2(5, 32),
				AutoScroll = true,
				AutoSize = true,
				BackgroundColor = ARGB(255, 255, 255, 255),
				Gui.FlowLayout "list1"
				{
					Dock = "kDockFill",
					AutoSize = true,
					LineSpace = 0,
					Create_list_label_1(1),
					Create_list_label_1(2),
					Create_list_label_1(3),
					Create_list_label_1(4),
					Create_list_label_1(5),
				},
			},
		},
		
		Gui.Control 
		{							
			Size = Vector2(381, 234),
			Location = Vector2(200, 261),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/TopList/lb_rank_bg_02.dds", Vector4(10, 10, 10, 10)),
			},
			Gui.Label 
			{
				Size = Vector2(252, 22),
				Location = Vector2(7, 7),
				Text = lang:GetText("技能属性")..":",
				TextColor = ARGB(255, 196, 134, 54),
				FontSize = 16,
			},
			Gui.ScrollableControl "scroll"
			{
				Style = "Gui.Toplist",
				Size = Vector2(372, 200),
				Location = Vector2(5, 32),
				BackgroundColor = ARGB(255, 255, 255, 255),
				AutoScroll = true,
				Default_Width = 16,
				Default_Size = 16,
				Gui.FlowLayout "list2"
				{
					AutoSize = true,
					LineSpace = 0,
				},
			},
		},
		
		Gui.Button
		{
			Size = Vector2(32, 32),
			Location = Vector2(548, 4),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/TopList/lb_rank_button03_normal.dds", Vector4(0, 0, 0, 0)),
				HoverImage = Gui.Image("LobbyUI/TopList/lb_rank_button03_hover.dds", Vector4(0, 0, 0, 0)),
				DownImage = Gui.Image("LobbyUI/TopList/lb_rank_button03_down.dds", Vector4(0, 0, 0, 0)),
				DisabledImage = nil,
			},
			EventClick = function(sender, e)
				sender.Parent.Visible = false
			end
		},
	},
}

function Filltreeview()
	local list = rank_ui.ltv_box
	local i = 0
	local st_key = ""
	text_color = nil
	if rank_mode == 4 then
		st_key = fun_type_key[rank_ui.mode.SelectedIndex + 1]
	end
	--关闭个人详情界面
	if L_LobbyMain.ui_des_bag.root then
		L_LobbyMain.ui_des_bag.root.Parent = nil
	end
	if rank_mode == 1 then
		rank_ui.con_1.Visible = true
		rank_ui.con_2.Visible = false
		rank_ui.con_3.Visible = false
		local args = {cid = current_cid, t = sub_mode[sub_type] , pid = ptr_cast(game.CurrentState):GetCharacterId(), page = rank_select_page,self = myself}
		rpc.safecallload("common_top",args,
		function(data)
			if data.warning == lang:GetText("您还未被排名") then
				myself = 0
				MessageBox.ShowWithConfirm(lang:GetText("未进入排名，请继续努力！"))
			else
				if data.data[1] == nil then
					FillCharacter(ptr_cast(game.CurrentState):GetCharacterId())
				end
				rank_ui.ranknum.Text = data.top_num
				top_num = data.top_num
				local list = rank_ui.con1_ltv
				list:DeleteAll()
				list:DeleteColumns()
				list:AddColumn("",50, "kAlignLeftMiddle")	
				list:AddColumn(lang:GetText("排名"),80, "kAlignLeftMiddle")	
				if sub_mode[sub_type] ~= "kWinRate" then
					list:AddColumn(lang:GetText("段位"),150, "kAlignCenterMiddle")
				end
					
				list:AddColumn("",70, "kAlignRightMiddle")	
				list:AddColumn("",25, "kAlignRightMiddle")	
				list:AddColumn("",25, "kAlignLeftMiddle")
				list:AddColumn(lang:GetText("玩家"),231, "kAlignLeftMiddle")
				if sub_mode[sub_type] == "kFightNum" then
					list:AddColumn(lang:GetText("战斗力"),145, "kAlignLeftMiddle")
				elseif sub_mode[sub_type] == "kWinRate" then
					list:AddColumn(lang:GetText("胜场数"),60, "kAlignCenterMiddle")
					list:AddColumn("",100, "kAlignCenterMiddle")
					list:AddColumn(lang:GetText("胜率"),60, "kAlignCenterMiddle")
				else
					list:AddColumn(rank_ui.cbx_Type.Text, 145, "kAlignCenterMiddle")
				end
				for i,v in ipairs(data.data) do
					local sub_item = list:AddItem(list.RootItem)
					sub_item.ID = v[7]
					sub_item.NAME = v[2]
					sub_item.VIP = v[5]
					sub_item:AddSubItem(" "..v[1])
					if v[9]== -1 then
						sub_item:SetIcon(2, Gui.Icon("LobbyUI/pipei/icon_rank00.dds"),Vector4(0, 0, 0, 0))
					elseif	v[9]== 0 then
						sub_item:SetIcon(2, Gui.Icon("LobbyUI/pipei/icon_rank01_1X.dds"),Vector4(0, 0, 0, 0))
					elseif	v[9]== 1 then
						sub_item:SetIcon(2, Gui.Icon("LobbyUI/pipei/icon_rank01_2X.dds"),Vector4(0, 0, 0, 0))
					elseif	v[9]== 2 then
						sub_item:SetIcon(2, Gui.Icon("LobbyUI/pipei/icon_rank01_3X.dds"),Vector4(0, 0, 0, 0))
					elseif	v[9]== 3 then
						sub_item:SetIcon(2, Gui.Icon("LobbyUI/pipei/icon_rank02_1X.dds"),Vector4(0, 0, 0, 0))
					elseif	v[9]== 4 then
						sub_item:SetIcon(2, Gui.Icon("LobbyUI/pipei/icon_rank02_2X.dds"),Vector4(0, 0, 0, 0))
					elseif	v[9]== 5 then
						sub_item:SetIcon(2, Gui.Icon("LobbyUI/pipei/icon_rank02_3X.dds"),Vector4(0, 0, 0, 0))
					elseif	v[9]== 6 then
						sub_item:SetIcon(2, Gui.Icon("LobbyUI/pipei/icon_rank03_1X.dds"),Vector4(0, 0, 0, 0))
					elseif	v[9]== 7 then
						sub_item:SetIcon(2, Gui.Icon("LobbyUI/pipei/icon_rank03_2X.dds"),Vector4(0, 0, 0, 0))
					elseif	v[9]== 8 then
						sub_item:SetIcon(2, Gui.Icon("LobbyUI/pipei/icon_rank03_3X.dds"),Vector4(0, 0, 0, 0))
					elseif	v[9]== 9 then
						sub_item:SetIcon(2, Gui.Icon("LobbyUI/pipei/icon_rank04_1X.dds"),Vector4(0, 0, 0, 0))
					elseif	v[9]== 10 then
						sub_item:SetIcon(2, Gui.Icon("LobbyUI/pipei/icon_rank04_2X.dds"),Vector4(0, 0, 0, 0))
					elseif	v[9]== 11 then
						sub_item:SetIcon(2, Gui.Icon("LobbyUI/pipei/icon_rank04_3X.dds"),Vector4(0, 0, 0, 0))
					elseif	v[9]== 12 then
						sub_item:SetIcon(2, Gui.Icon("LobbyUI/pipei/icon_rank05_3X.dds"),Vector4(0, 0, 0, 0))
					end
					sub_item:AddSubItem(nil)
					
					sub_item:AddSubItem(nil)
					sub_item:AddSubItem(nil)
					sub_item:AddSubItem(v[2])
					
					if sub_mode[sub_type] == "kWinRate" then
						sub_item:AddSubItem(v[8])
						sub_item:AddSubItem(nil)
						sub_item:AddSubItem(v[9])
					else
						sub_item:AddSubItem(v[8])
					end
					if sub_mode[sub_type] == "kWinRate" then
						if v[3] > 0 then
							sub_item:SetIcon(2, Gui.Icon("LobbyUI/vip/vip/VIP_button_0"..v[3].."_normal.dds"),Vector4(0, 0, 0, 0))
						end 
					else
						if v[3] > 0 then
							sub_item:SetIcon(3, Gui.Icon("LobbyUI/vip/vip/VIP_button_0"..v[3].."_normal.dds"),Vector4(0, 0, 0, 0))
						end 
					end
					-- if v[3] > 0 then
						-- sub_item:SetIcon(3, Gui.Icon("LobbyUI/vip/vip/VIP_button_0"..v[3].."_normal.dds"),Vector4(0, 0, 0, 0))
					-- end 
					if i % 2 == 1 then
						sub_item.BGSkin = Skin.ListItemSkin_TopList_Double
					else
						sub_item.BGSkin = Skin.ListItemSkin_TopList_Single
					end
					local percent
					local RANK = (v[4] - (v[4] % 10)) / 100
					icon2 =  Gui.Icon("LobbyUI/WarZone/lb_summary_number_6c.dds", Vector4(0, 0, 0, 0),Vector4(RANK, 0, RANK + 0.1, 1))
					if v[4] == 80 then
						percent = 1
					else
						percent = (v[5] - L_LobbyMain.LevelInfo_rpc_data[v[4]][2]) / (L_LobbyMain.LevelInfo_rpc_data[v[4] + 1][2] - L_LobbyMain.LevelInfo_rpc_data[v[4]][2]) 
						percent = string.format("%.2f", percent)
					end
					icon1 =  Gui.Icon("LobbyUI/WarZone/lb_summary_number_7c.dds", Vector4(0, 0, 0, 0),Vector4(RANK, 1 - percent, RANK + 0.1, 1))
					if sub_mode[sub_type] == "kWinRate" then
						sub_item:SetIcon(3,icon2,icon1)
					else
						sub_item:SetIcon(4,icon2,icon1)
					end
					RANK = v[4] % 10 /10
					icon2 =  Gui.Icon("LobbyUI/WarZone/lb_summary_number_6c.dds", Vector4(0, 0, 0, 0),Vector4(RANK, 0, RANK + 0.1, 1))
					icon1 =  Gui.Icon("LobbyUI/WarZone/lb_summary_number_7c.dds", Vector4(0, 0, 0, 0),Vector4(RANK, 1 - percent, RANK + 0.1, 1))
					if sub_mode[sub_type] == "kWinRate" then
						sub_item:SetIcon(4,icon2,icon1)
					else
						sub_item:SetIcon(5,icon2,icon1)
					end
					if myself == 0 and i == 1 then
						list.SelectedItem = sub_item
						other_pid = v[7]
					end
					if myself == 1 and i == data.row_num then	
						list.SelectedItem = sub_item
						myself = 0
						other_pid = v[7]
					end
				end
				if #data.data < 10 then
					local j 
					for j = #data.data ,10 do
						local sub_item = list:AddItem(list.RootItem)
						sub_item.CanSelect = false
						sub_item.CheckVisible = false
						if j % 2 == 1 then
							sub_item.BGSkin = Skin.ListItemSkin_Single
						else
							sub_item.BGSkin = Skin.ListItemSkin_Double
						end
					end
				end
				max_page = data.pages
				rank_select_page = data.page
				rank_ui.tbx_page.Text = data.page
				rank_ui.lb_page_number.Text = data.page.."/"..data.pages
			end
		end)
	elseif rank_mode == 3 then
		rank_ui.con_1.Visible = false
		rank_ui.con_2.Visible = false
		rank_ui.con_3.Visible = true
		if L_FightTeam.team_list_ui.root then
			L_FightTeam.team_list_ui.root.Parent = rank_ui.con_3
			L_FightTeam.team_list_ui.root.Visible = true
			L_FightTeam.team_list_ui.root.Location = Vector2(-10, -30)
			L_FightTeam.team_list_type = 1
			L_FightTeam.FillTeamList()
		end
	else
		rank_ui.con_1.Visible = false
		rank_ui.con_2.Visible = true
		rank_ui.con_3.Visible = false
		local cbx = rank_ui.mode
		if cbx.SelectedIndex == -1 then
			cbx:RemoveAll()
			for k, v in ipairs(fun_mode) do 
				cbx:AddItem(v)
			end
			cbx.SelectedIndex = 0
		end
		local args = {st = st_key, t = rank_mode_key[rank_mode], pid = ptr_cast(game.CurrentState):GetCharacterId(), page = rank_select_page,self = myself}
		rpc.safecallload("personal_top",args,
		function(data)
			if data.warning == lang:GetText("您还未被排名") then
				myself = 0
				MessageBox.ShowWithConfirm(lang:GetText("未进入排名，请继续努力！"))
			else
				if rank_mode == 4 then
					if data.page < 11 then
						text_color = ARGB(255, 255, 240, 0)
					elseif data.page >= 11 and data.page < 21 then
						text_color = ARGB(255, 222, 222, 222)
					elseif data.page >= 21 and data.page < 31 then
						text_color = ARGB(255, 255, 138, 0)
					end
				end
				if rank_mode == 2 then
					if data.page > 40 then
						rank_ui.TopImage.Visible = false
					else
						rank_ui.TopImage.Visible = true
						if data.page < 6 then
							rank_ui.TopImage.Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/TopList/lb_rank_image01.dds", Vector4(0, 0, 0, 0)),
							}
							rank_ui.baiwei.Visible = false
							rank_ui.shiwei.Location = Vector2(34, 75)
							rank_ui.gewei.Location = Vector2(62, 75)
							rank_ui.shiwei.Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/TopList/lb_rank_number01.dds", Vector4(0, 0, 0, 0), Vector4((data.page / 10), 0, (data.page / 10 + 0.1), 1)),
							}
							rank_ui.gewei.Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/TopList/lb_rank_number01.dds", Vector4(0, 0, 0, 0),Vector4(0, 0, 0.1, 1)),
							}
							text_color = ARGB(255, 255, 240, 0)
						elseif data.page >= 6 and data.page < 21 then
							rank_ui.TopImage.Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/TopList/lb_rank_image02.dds", Vector4(0, 0, 0, 0)),
							}
							if data.page < 10 then
								rank_ui.baiwei.Visible = false
								rank_ui.shiwei.Location = Vector2(34, 75)
								rank_ui.gewei.Location = Vector2(62, 75)
								rank_ui.shiwei.Skin = Gui.ControlSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/TopList/lb_rank_number02.dds", Vector4(0, 0, 0, 0), Vector4((data.page / 10), 0, (data.page / 10 + 0.1), 1)),
								}
								rank_ui.gewei.Skin = Gui.ControlSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/TopList/lb_rank_number02.dds", Vector4(0, 0, 0, 0),Vector4(0, 0, 0.1, 1)),
								}
							else
								rank_ui.baiwei.Visible = true
								rank_ui.baiwei.Location = Vector2(20, 75)
								rank_ui.shiwei.Location = Vector2(48, 75)
								rank_ui.gewei.Location = Vector2(76, 75)
								local num = (data.page - data.page % 10) / 10
								rank_ui.baiwei.Skin = Gui.ControlSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/TopList/lb_rank_number02.dds", Vector4(0, 0, 0, 0), Vector4((num / 10), 0, (num / 10 + 0.1), 1)),
								}
								rank_ui.shiwei.Skin = Gui.ControlSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/TopList/lb_rank_number02.dds", Vector4(0, 0, 0, 0), Vector4(((data.page - (10 * num)) / 10), 0, ((data.page - (10 * num)) / 10 + 0.1), 1)),
								}
								rank_ui.gewei.Skin = Gui.ControlSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/TopList/lb_rank_number02.dds", Vector4(0, 0, 0, 0),Vector4(0, 0, 0.1, 1)),
								}
							end
							text_color = ARGB(255, 222, 222, 222)
						else
							rank_ui.TopImage.Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/TopList/lb_rank_image03.dds", Vector4(0, 0, 0, 0)),
							}
							rank_ui.baiwei.Visible = true
							rank_ui.baiwei.Location = Vector2(20, 75)
							rank_ui.shiwei.Location = Vector2(48, 75)
							rank_ui.gewei.Location = Vector2(76, 75)
							local num = (data.page - data.page % 10) / 10
							rank_ui.baiwei.Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/TopList/lb_rank_number03.dds", Vector4(0, 0, 0, 0), Vector4((num / 10), 0, (num / 10 + 0.1), 1)),
							}
							rank_ui.shiwei.Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/TopList/lb_rank_number03.dds", Vector4(0, 0, 0, 0), Vector4(((data.page - (10 * num)) / 10), 0, ((data.page - (10 * num)) / 10 + 0.1), 1)),
							}
							rank_ui.gewei.Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/TopList/lb_rank_number03.dds", Vector4(0, 0, 0, 0),Vector4(0, 0, 0.1, 1)),
							}
							text_color = ARGB(255, 255, 138, 0)
						end
					end
				end
				list:DeleteColumns()
				max_page = data.pages
				rank_select_page = data.page
				my_rank_page = data.page	
				rank_ui.m_AcheInfoPageDisplay.Text = data.page.."/"..data.pages
				if data.top_num == 0 then
					rank_ui.rank.Text = lang:GetText("未进入")
				else
					rank_ui.rank.Text = data.top_num
				end
				local time1 = data.left_time
				local t = (time1 - time1%1440) / 1440
				local s = ((time1 - t * 1440) - ((time1 - t * 1440) % 60)) / 60
				local m = time1 % 60
				rank_ui.pmjz.Text = t..lang:GetText("天")..s..lang:GetText("小时")..m..lang:GetText("分钟")
				local data1 = data.data
				list:DeleteAll()
				list:AddColumn("",1, "kAlignCenterLeft")
				for _,v in ipairs(data1) do
					if i == 0 then
						local j = 1
						for _,v in ipairs(data1[1]) do	
							if j == 1 then
								list:AddColumn(lang:GetText(v),64, "kAlignCenterMiddle")	
								list:AddColumn("",50, "kAlignRightMiddle")
								list:AddColumn("",50, "kAlignLeftMiddle")
								list:AddColumn("",15, "kAlignRightMiddle")
								list:AddColumn("",15, "kAlignLeftMiddle")
							elseif j == 2 then
									list:AddColumn(lang:GetText(v),180, "kAlignCenterMiddle")
							else
								if rank_mode == 1 then
									list:AddColumn(lang:GetText(v),150, "kAlignCenterMiddle")
								else 
									list:AddColumn(lang:GetText(v),127, "kAlignCenterMiddle")
								end
							end
							j = j + 1
						end
					else
						local sub_item = list:AddItem(list.RootItem,nil)
						if i == 1 then
							list.SelectedItem = sub_item
						end
						if myself == 1 and i == data.row_num then	
							list.SelectedItem = sub_item
							myself = 0
						end
						sub_item.NAME = v[2]
						sub_item.VIP = v[4]
						sub_item:AddSubItem(v[1])
						sub_item:AddSubItem(nil)
						sub_item:AddSubItem(nil)
						sub_item:AddSubItem(nil)
						if v[4] > 0 then
							sub_item:SetIcon(2, Gui.Icon("LobbyUI/vip/vip/VIP_button_0"..v[4].."_normal.dds"),Vector4(0, 0, 0, 0))
						end 
						if st_key ~= "" then
							sub_item:SetIcon(3, Gui.Icon("LobbyUI/persionalInfo/HeadPic/lb_battlefield_icon"..v[8]..".dds", Vector4(0, 0, 0, 0)))
							local percent
							local RANK = (v[5] - (v[5] % 10)) / 100
							icon2 =  Gui.Icon("LobbyUI/WarZone/lb_summary_number_6c.dds", Vector4(0, 0, 0, 0),Vector4(RANK, 0, RANK + 0.1, 1))
							if v[5] == 50 then
								percent = 1
							else
								percent = (v[6] - L_LobbyMain.LevelInfo_rpc_data[v[5]][2]) / (L_LobbyMain.LevelInfo_rpc_data[v[5] + 1][2] - L_LobbyMain.LevelInfo_rpc_data[v[5]][2]) 
								percent = string.format("%.2f", percent)
							end
							icon1 =  Gui.Icon("LobbyUI/WarZone/lb_summary_number_7c.dds", Vector4(0, 0, 0, 0),Vector4(RANK, 1 - percent, RANK + 0.1, 1))
							sub_item:SetIcon(4,icon2,icon1)
							RANK = v[5] % 10 /10
							icon2 =  Gui.Icon("LobbyUI/WarZone/lb_summary_number_6c.dds", Vector4(0, 0, 0, 0),Vector4(RANK, 0, RANK + 0.1, 1))
							icon1 =  Gui.Icon("LobbyUI/WarZone/lb_summary_number_7c.dds", Vector4(0, 0, 0, 0),Vector4(RANK, 1 - percent, RANK + 0.1, 1))
							sub_item:SetIcon(5,icon2,icon1)
							sub_item:AddSubItem(v[2])
							sub_item:AddSubItem(v[3])
							sub_item.ID = v[7]
						else
							local percent
							local RANK = (v[5] - (v[5] % 10)) / 100
							if v[13] == NULL then
								sub_item:SetIcon(3, Gui.Icon("LobbyUI/persionalInfo/HeadPic/lb_battlefield_icon01_r.dds", Vector4(0, 0, 0, 0)))
							else
								sub_item:SetIcon(3, Gui.Icon("LobbyUI/persionalInfo/HeadPic/lb_battlefield_icon"..v[13]..".dds", Vector4(0, 0, 0, 0)))
							end
							icon2 =  Gui.Icon("LobbyUI/WarZone/lb_summary_number_6c.dds", Vector4(0, 0, 0, 0),Vector4(RANK, 0, RANK + 0.1, 1))
							if v[5] == 50 then
								percent = 1
							else
								percent = (v[11] - L_LobbyMain.LevelInfo_rpc_data[v[5]][2]) / (L_LobbyMain.LevelInfo_rpc_data[v[5] + 1][2] - L_LobbyMain.LevelInfo_rpc_data[v[5]][2]) 
								percent = string.format("%.2f", percent)
							end
							percent = (19*percent + 7)/33
							icon1 =  Gui.Icon("LobbyUI/WarZone/lb_summary_number_7c.dds", Vector4(0, 0, 0, 0),Vector4(RANK, 1 - percent, RANK + 0.1, 1))
							sub_item:SetIcon(4,icon2,icon1)
							RANK = v[5] % 10 /10
							icon2 =  Gui.Icon("LobbyUI/WarZone/lb_summary_number_6c.dds", Vector4(0, 0, 0, 0),Vector4(RANK, 0, RANK + 0.1, 1))
							icon1 =  Gui.Icon("LobbyUI/WarZone/lb_summary_number_7c.dds", Vector4(0, 0, 0, 0),Vector4(RANK, 1 - percent, RANK + 0.1, 1))
							sub_item:SetIcon(5,icon2,icon1)
							sub_item:AddSubItem(v[2])
							sub_item:AddSubItem(v[3])
							sub_item.ID = v[12]
							local char
							char = v[6].."/"..v[7]
							sub_item:AddSubItem(char)
							sub_item:AddSubItem(v[8])
							local shenglv
							if v[10] + v[9] == 0 then
								sub_item:AddSubItem("0.0%")
							else
								shenglv =  v[9] / (v[10] + v[9]) * 100
								sub_item:AddSubItem(string.format("%.1f", shenglv).."%")
							end
						end
						if i % 2 == 1 then
							sub_item.BGSkin = Skin.ListItemSkin_Double
						else
							sub_item.BGSkin = Skin.ListItemSkin_Single
						end
						if text_color ~= nil and (rank_mode == 4 or rank_mode == 2 or rank_mode == 1) then
							Set_TextColor(sub_item)
							sub_item.TextColor = text_color
						end
					end
					i = i + 1
				end
				if i < 11 then
					local j 
					for j = i ,10 do
						local sub_item = list:AddItem(list.RootItem)
						sub_item.CanSelect = false
						sub_item.CheckVisible = false
						if j % 2 == 0 then
							sub_item.BGSkin = Skin.ListItemSkin_Single
						else
							sub_item.BGSkin = Skin.ListItemSkin_Double
						end
					end
				end
			end
		end)
	end
end

function FillCharacter(p_id)
	local args = {cid = current_cid, pid = p_id, t = sub_mode[sub_type]}
	rpc.safecallload("character_team_info",args,
	function(data)
		L_LobbyMain.CharactersInfo_rpc_data = data
		L_LobbyMain.InitAvatarPreviewInfo(ptr_cast(game.CurrentState):GetCharacterId(), current_cid)
		rank_ui.lb_UserLevel_AnoldState.Location = Vector2(19, 26)
		rank_ui.lb_UserLevel_TenState.Location = Vector2(9, 26)
		L_LobbyMain.FillLevel(data.player.rank,rank_ui,data.player.exp)
		if data.player.isvip > 0 then
			rank_ui.con_vip.Visible = true
			rank_ui.con_vip.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_button_0"..data.player.isvip.."_normal.dds", Vector4(0, 0, 0, 0)),}
		else
			rank_ui.con_vip.Visible = false
		end
		rank_ui.lab_name.Text = data.player.name
		rank_ui.team_name.Text = data.team.name or lang:GetText("无")
		L_LobbyMain.ChangeBG(rank_ui,data.items.fightnum, true)
		character_bag.rank_num.Text = data.player.rankintop
		rpc_bag_data = data
		L_LobbyMain.Characters_BagInfo_rpc_data = data
		L_LobbyMain.Fill_ui_des_bag(data)
		FillBag()
	end)
end

function Set_TextColor(sub_item)
	for i = 1, 11 do
		sub_item:SetSubItemColor(i - 1, text_color)
	end
end

function Show(parent_win)
	L_LobbyMain.HideAll()
	L_LobbyMain.LobbyMainWin_Foot.btn_TopList.PushDown = true
	character_bag.root.Size = Vector2(588, 507)
	character_bag.root.Location = Vector2(291, 33)
	character_bag.root.Visible = false
	character_bag.root.Parent = rank_ui.con_1_bg
	rank_mode = 1
	current_cid = 0
	sub_type = 1
	ltv_fun(rank_ui.ltv_box)
	ltv_fun(rank_ui.con1_ltv)
	rank_ui.personalTop.PushDown = true
	rank_ui.WeekTop.PushDown = false
	rank_ui.TeamTop.PushDown = false
	rank_ui.Funtop.PushDown = false
	local cbx = rank_ui.cbx_Type
	cbx:RemoveAll()
	if single_mode then
		for i=1, #single_mode do
			cbx:AddItem(single_mode[i]..lang:GetText("战斗力"))
		end
	end
	cbx:AddItem(lang:GetText("积分"))
	cbx:AddItem(lang:GetText("击杀/死亡"))
	cbx:AddItem(lang:GetText("助攻"))
	cbx:AddItem(lang:GetText("战绩"))
	cbx.SelectedIndex = 0
	cbx = rank_ui.mode
	cbx:RemoveAll()
	for k, v in ipairs(single_mode) do 
		cbx:AddItem(v)
	end
	cbx.SelectedIndex = 0
	cbx.Visible = true
	cbx.SelectedIndex = 0
	cbx.EventItemSelected = function(sender, e) 
		rank_select_page = 1
		Filltreeview()
	end
	rank_ui.root.Parent = parent_win
	Filltreeview()
	
end

function FillBag()
	local count1 = 0
	local count2 = 0
	local count3 = 0
	local count4 = 0
	local count5 = 0
	local count6 = 0
	local count7 = 0
	local count8 = 0
	local count9 = 0
	local count10 = 0
	local temp = 1
	if rpc_bag_data then
		character_bag.list2:OnDestroy()
		character_bag.scroll.AutoScrollMinSize = Vector2(0, 0)
		character_bag.name_txt.Text = rpc_bag_data.player.name
		for i,v in ipairs(rpc_bag_data.items.weapons) do
			if i > 4 then
				break
			end
			if v.color > 0 and v.color < 9 then
				if i == 3 or i == 4 then
					character_bag["ib_weapon_"..i].ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..v.name.."_Small_"..v.color..".tga")
				else
					character_bag["ib_weapon_"..i].ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..v.name.."_"..v.color..".tga")
				end
			else
				if i == 3 or i == 4 then
					character_bag["ib_weapon_"..i].ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..v.name.."_Small"..".tga")
				else
					character_bag["ib_weapon_"..i].ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..v.name..".tga")
				end
			end
			if v.isDefault == 0 then
				if i == 4 then
					if v.display == "temp" then
						character_bag["ib_weapon_"..i].Enable = false
					else
						character_bag["ib_weapon_"..i].Enable = true
					end
				end
			else
				character_bag["ib_weapon_"..i].Enable = true
			end
			
			if v.common.rareLevel then
				character_bag["ib_weapon_"..i].ItemLevel = Skin.rarelevel[math.ceil(v.common.rareLevel/25)]
			end
			
			
			if v.common.strength > 0 then
				character_bag["con_strength_image"..i].Visible = true
				character_bag["con_strength_image"..i].Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/badge_lv"..v.common.strength.."_small.dds", Vector4(0, 0, 0, 0)),
				}
			else
				character_bag["con_strength_image"..i].Visible = false
			end
			
			if v.gstLevel and v.gstLevel > 0 then
				character_bag["ib_star"..i].Visible = true
				character_bag["ib_star"..i].Size = Vector2(68,12)
				character_bag["ib_star"..i].Location = Vector2(175 - 110,10)
				character_bag["ib_star"..i].Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Compose/shengxing/lb_synthesis_conversion_star_0"..v.gstLevel..".dds", Vector4(0, 0, 0, 0)),
				}
			else
				character_bag["ib_star"..i].Visible = false
			end
			
			for _,w in ipairs(v.gunproperty) do
				if w[2] ~= "" and v.display ~= "temp" then
					local des = Gui.Create()
					{
						Gui.TextArea "t"
						{
							Size = Vector2(342, 45),
							FontSize = 16,
							Text = w[2],
							TextColor = ARGB(255, 200, 255, 254),
							Readonly = true,
							Fold = true,
						},
					}
					des.t.Parent = character_bag.list2
					temp = temp + 1
					character_bag.scroll.AutoScrollMinSize = Vector2(0,character_bag.scroll.AutoScrollMinSize.y + 45)
				end
			end
		end
		
		for i,v in ipairs(rpc_bag_data.items.costume) do
			count1 = count1 + v.common.cResistanceFire
			count2 = count2 + v.common.cResistanceFire_add
			count3 = count3 + v.common.cResistanceBlast
			count4 = count4 + v.common.cResistanceBlast_add
			count5 = count5 + v.common.cResistanceBullet
			count6 = count6 + v.common.cResistanceBullet_add
			count7 = count7 + v.common.cResistanceKnife
			count8 = count8 + v.common.cResistanceKnife_add
			count9 = count9 + v.common.cBloodAdd
			count10 = count10 + v.common.cBloodAdd_add
			if v.color > 0 and v.color < 9 then
				character_bag["ib_costume_"..i].ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..v.name.."_"..v.color..".tga")
			else
				character_bag["ib_costume_"..i].ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..v.name..".tga")
			end
			if v.isDefault == 0 then
				if i ~= 1 then
					character_bag["ib_costume_"..i].ItemIcon = nil
					character_bag["ib_costume_"..i].Enable = false
				end
			else
				character_bag["ib_costume_"..i].Enable = true
			end
			
			if v.common.rareLevel then
				character_bag["ib_costume_"..i].ItemLevel = Skin.rarelevel[math.ceil(v.common.rareLevel/25)]
			end
			
			if v.common.strength > 0 then
				character_bag["con_strength_image"..(i + 4)].Visible = true
				character_bag["con_strength_image"..(i + 4)].Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/badge_lv"..v.common.strength.."_small.dds", Vector4(0, 0, 0, 0)),
				}
			else
				character_bag["con_strength_image"..(i + 4)].Visible = false
			end
			
			if v.gstLevel and v.gstLevel > 0 then
				character_bag["ib_star"..(i + 4)].Visible = true
				character_bag["ib_star"..(i + 4)].Size = Vector2(46,12)
				character_bag["ib_star"..(i + 4)].Location = Vector2(10,10)
				character_bag["ib_star"..(i + 4)].Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Compose/shengxing/lb_synthesis_conversion_star_0"..v.gstLevel..".dds", Vector4(0, 0, 0, 0)),
				}
			else
				character_bag["ib_star"..(i + 4)].Visible = false
			end
			
			for _,w in ipairs(v.gunproperty) do
				if w[2] ~= "" and v.display ~= "temp" then
					local des = Gui.Create()
					{
						Gui.TextArea "t"
						{
							Size = Vector2(342, 45),
							FontSize = 16,
							Text = w[2],
							TextColor = ARGB(255, 200, 255, 254),
							Fold = true
						},
					}
					des.t.Parent = character_bag.list2
					temp = temp + 1
					character_bag.scroll.AutoScrollMinSize = Vector2(0,character_bag.scroll.AutoScrollMinSize.y + 45)
				end
			end
			
		end
		if L_Compose.precision(count1) < 10 then
			character_bag["list1_label_1"].Text = lang:GetText("火焰抗性").." "..L_Compose.precision(count1).."% (+"..L_Compose.precision(count2).."%)"
		else
			character_bag["list1_label_1"].Text = lang:GetText("火焰抗性").." "..L_Compose.precision(count1).."% (+"..L_Compose.precision(count2).."%)"
		end
		if L_Compose.precision(count3) < 10 then
			character_bag["list1_label_2"].Text = lang:GetText("爆炸抗性").." "..L_Compose.precision(count3).."% (+"..L_Compose.precision(count4).."%)"
		else
			character_bag["list1_label_2"].Text = lang:GetText("爆炸抗性").." "..L_Compose.precision(count3).."% (+"..L_Compose.precision(count4).."%)"
		end
		if L_Compose.precision(count5) < 10 then
			character_bag["list1_label_3"].Text = lang:GetText("子弹抗性").." "..L_Compose.precision(count5).."% (+"..L_Compose.precision(count6).."%)"
		else
			character_bag["list1_label_3"].Text = lang:GetText("子弹抗性").." "..L_Compose.precision(count5).."% (+"..L_Compose.precision(count6).."%)"
		end
		if L_Compose.precision(count7) < 10 then
			character_bag["list1_label_4"].Text = lang:GetText("近身抗性").." "..L_Compose.precision(count7).."% (+"..L_Compose.precision(count8).."%)"
		else
			character_bag["list1_label_4"].Text = lang:GetText("近身抗性").." "..L_Compose.precision(count7).."% (+"..L_Compose.precision(count8).."%)"
		end
		if L_Compose.precision(count9) < 10 then
			character_bag["list1_label_5"].Text = lang:GetText("增加血量").." "..L_Compose.precision(count9).."% (+"..L_Compose.precision(count10).."%)"
		else
			character_bag["list1_label_5"].Text = lang:GetText("增加血量").." "..L_Compose.precision(count9).."% (+"..L_Compose.precision(count10).."%)"
		end
	end
end

function ChangeAvatar(index)
	local weapon = rpc_bag_data.items.weapons[index]
	if weapon then		
		if weapon.resource then			
			L_LobbyMain.ChangeWeapon(current_Avatar_Team, weapon.resource.type)
			local n = #weapon.resource
			L_LobbyMain.SetWeaponColor(current_Avatar_Team,weapon.color)
			for i = 1, n do			
				if i > 0 then
					L_LobbyMain.AddWeaponPart(current_Avatar_Team, weapon.resource[i])
				end
			end
		end
	end
end

function ltv_fun(list)
	list.PopupMenu:RemoveAll()
	list.PopupMenu:AddItem(lang:GetText("私聊"))
	list.PopupMenu:AddItem(lang:GetText("加为好友"))
	list.PopupMenu:AddItem(lang:GetText("查看信息"))
	list.PopupMenu.Style = "Gui.MenuNew"
	list.EventRightClick = function(sender, e)
		if sender.PopupMenu and sender.PointedItem and sender.PointedItem.CanSelect then
			sender.PopupMenu:Open()
		end
	end      
	list.PopupMenu.EventClick = function(sender, e)
		local item = ptr_cast(sender.Tag)
		if sender.SelectedIndex == 0 then
			L_LobbyMain.ChatPrivate(item.NAME, item.VIP, item.ID)
		elseif sender.SelectedIndex == 1 then
			 L_Friends.FriendsAdd(nil,item.NAME)
		elseif sender.SelectedIndex == 2 then
			if item.ID == ptr_cast(game.CurrentState):GetCharacterId() then
				L_PersonalInfo.Show(L_LobbyMain.LobbyMainWin_Boddy.LobbyMainWin_Boddy_Root)
				L_LobbyMain.InitPersonalInfoRPCInfo()
				lg:SetLobbyModules(12)
				L_LobbyMain.current_chosse_main_page = 12
				L_PersonalInfo.SynchronousClassButton()
				L_LobbyMain.FillClassBag(ptr_cast(game.CurrentState):GetCharacterId(), L_LobbyMain.current_choose_class)
			else
				L_PersonalInfo.ShowPerson(L_LobbyMain.LobbyMainWin_Boddy.LobbyMainWin_Boddy_Root, item.ID, "")
			end
			Hide()
		end
	end
	list.EventSelectItemChange = function(sender, e)
		if rank_mode == 1 then
			if sender.SelectedItem then
				FillCharacter(sender.SelectedItem.ID)
			end
		end
	end
end

function Hide()	
	if rank_ui then		
		rank_ui.root.Parent = nil
	end
	
	if L_LobbyMain.ui_des_bag.root then
		L_LobbyMain.ui_des_bag.root.Parent = nil
	end
end

function Initialize()
	
end

function Reset()
end

function Finalize()
end