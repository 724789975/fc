module("L_Mission", package.seeall)

local mode_type = nil --0：每日 1：每周 2：活动 3：新手
local rpc_data = nil
local completed_mission_count = 1
local completed_mission_rpc_data = nil
local page = nil
local max_page = nil
local myTemp
local rpc_back = {}
local rpc_back_1 = nil
local Mission_id = nil
local flag = 0
local vipexp = {}

function create_btn(index, x, y)
	return Gui.ItemBoxBtn
	{
		Style = "Gui.ItemBoxBtn_ib",
		Empty = false,
		Type = 1,
		Size = Vector2(100, 100),
		Location = Vector2(x, y),
		CanSelect = false,
		Skin = Gui.ItemBoxBtnSkin
		{
			NeutralNormalImage = Gui.Image("LobbyUI/ShoppingMall/open_box/lb_gift_biew_bg2.dds", Vector4(0, 0, 0, 0)),
			NeutralDisabledImage = Gui.Image("LobbyUI/ShoppingMall/open_box/lb_gift_biew_bg2.dds", Vector4(0, 0, 0, 0)),
		},
		
		EventMouseEnter = function(sender, e)
			L_ToolTips.FillToolTipsVIPPresent(index, Award_ui.root, rpc_back_1.items)
		end,
		
		EventToolTipsShow = function(sender, e)
			local pos = sender:ClientToGlobalScreen(sender.Location)
			
			if index > 5 then
				pos.y = pos.y - 104
				pos.x = pos.x - ( ( index - 6 ) * 104 ) - 5
			else
				pos.x = pos.x - ( ( index - 1 ) * 104 ) - 5
			end
			L_ToolTips.ShowToolTipsShowWindow(sender, nil, pos)
		end,
		
		EventMouseLeave = function(sender, e)
			L_ToolTips.HideToolTipsWindow()
		end,
		
		Gui.Control 
		{
			Size = Vector2(70, 16),
			Location = Vector2(29, 78),
			BackgroundColor = ARGB(0, 255, 255, 255),
			Gui.Control "c1"
			{
				Size = Vector2(20, 16),
				Location = Vector2(5, 0),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Visible = false,
			},
			Gui.Control "c2"
			{
				Size = Vector2(20, 16),
				Location = Vector2(20, 0),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Visible = false,
			},
			Gui.Control "c3"
			{
				Size = Vector2(20, 16),
				Location = Vector2(35, 0),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Visible = false,
			},
			Gui.Control "c4"
			{
				Size = Vector2(20, 16),
				Location = Vector2(50, 0),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Visible = false,
			},
		}
	}
end

function create_type_button(index, text, x)
	return Gui.Button ("type_button_"..index)
	{
		Style = "Gui.Button_type",
		Size = Vector2(200, 45),
		Location = Vector2(x, 40),
		Text = text,
		FontSize = 16,
		HighlightTextColor = ARGB(255, 255, 211, 78),
		EventClick = function(Sender,e)
			mode_type = index 
			for i = 1, 4 do
				if mode_type == (i - 1) then
					Mission["type_button_"..(i - 1)].PushDown = true
				else
					Mission["type_button_"..(i - 1)].PushDown = false
				end
			end
			Fill()
		end
	}
end

function create_Label(index, x)
	return Gui.Label ("new"..index)
	{
		Visible = false,
		Enable = false,
		Size = Vector2(23, 32),
		Location = Vector2(x - 3, 45),
		NormLocation = Vector2(x - 3, 45),
		BackgroundColor = ARGB(255, 255, 255, 255),
		MoveLocation = Vector2(0,8),
		MoveWheelTime = 0.8,
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/Mission/lb_tutorial_renwu_ico.dds", Vector4(0, 0, 0, 0)),
		},
	}
end

function create_con(index)
	return Gui.Control ("con_"..index)
	{
		Visible = false,
		Size = Vector2(80, 56),
		Location = Vector2(0, 60 * (index - 1)),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Enable = false,
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/Mission/lb_task_ico_wancheng_01.dds", Vector4(0, 0, 0, 0)),
		},
	}
end

Award_ui = Gui.Create()
{
	Gui.Control "root"
	{
		Size = Vector2(1200, 900),
		Dock = "kDockCenter",
		BackgroundColor = ARGB(0, 255, 255, 255),
		Gui.Control "r"
		{
			Size = Vector2(570, 580),
			Dock = "kDockCenter",
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/open_box/main_bar01.dds", Vector4(20, 20, 20, 20)),
			},
			Gui.Control 
			{
				Size = Vector2(542, 552),
				Location = Vector2(14, 14),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/open_box/main_bar02.dds", Vector4(20, 20, 20, 20)),
				},
				Gui.Control 
				{
					Size = Vector2(531, 156),
					Location = Vector2(6, 34),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_summary_flop_bg_03.dds", Vector4(20, 60, 20, 20)),
					},
					Gui.Label
					{
						Size = Vector2(440, 32),
						Location = Vector2(35, 6),
						BackgroundColor = ARGB(255, 255, 255, 255),
						FontSize = 14,
						TextColor = ARGB(255, 255, 251, 240),
						TextPadding = Vector4(130, 0, 0, 0),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/Mission/lb_task_title_03.dds", Vector4(0, 0, 0, 0)),
						},
						Text = lang:GetText("获得经验"),
					},
					Gui.Label
					{
						Size = Vector2(440, 32),
						Location = Vector2(405, 6),
						BackgroundColor = ARGB(0, 255, 255, 255),
						FontSize = 14,
						TextColor = ARGB(255, 255, 251, 240),
						TextPadding = Vector4(0, 0, 0, 0),
						Text = lang:GetText("获得C币"),
					},
					Gui.Label 
					{
						Size = Vector2(180, 28),
						Location = Vector2(10, 60),
						FontSize = 18,
						TextAlign = "kAlignLeftMiddle",
						TextColor = ARGB(255, 255, 187, 0),
						Text = lang:GetText("基本获得"),
					},
					Gui.Label "t1"
					{
						Size = Vector2(120, 34),
						Location = Vector2(130, 60),
						TextColor = ARGB(255, 255, 110, 0),
						TextAlign = "kAlignCenterMiddle",
						FontSize = 18,
						BackgroundColor = ARGB(255 * 0.6, 255, 255, 255),
						TextPadding = Vector4(0, 0, 0, 7),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/vip_chest/lb_vipgifts_numberbar01.dds", Vector4(10, 10, 10, 10)),
						},
					},
					Gui.Label "t2"
					{
						Size = Vector2(120, 34),
						Location = Vector2(380, 60),
						TextColor = ARGB(255, 255, 110, 0),
						TextAlign = "kAlignCenterMiddle",
						FontSize = 18,
						BackgroundColor = ARGB(255 * 0.6, 255, 255, 255),
						TextPadding = Vector4(0, 0, 0, 7),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/vip_chest/lb_vipgifts_numberbar01.dds", Vector4(10, 10, 10, 10)),
						},
					},
					Gui.Label
					{
						Size = Vector2(180, 28),
						Location = Vector2(10, 110),
						FontSize = 18,
						TextAlign = "kAlignLeftMiddle",
						TextColor = ARGB(255, 255, 187, 0),
						Text = "VIP",
					},
					Gui.Label "t3"
					{
						Size = Vector2(120, 34),
						Location = Vector2(130, 110),
						TextColor = ARGB(255, 255, 110, 0),
						TextAlign = "kAlignCenterMiddle",
						FontSize = 18,
						BackgroundColor = ARGB(255 * 0.6, 255, 255, 255),
						TextPadding = Vector4(0, 0, 0, 7),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/vip_chest/lb_vipgifts_numberbar01.dds", Vector4(10, 10, 10, 10)),
						},
					},
					Gui.Label "t4"
					{
						Size = Vector2(120, 34),
						Location = Vector2(380, 110),
						TextColor = ARGB(255, 255, 110, 0),
						TextAlign = "kAlignCenterMiddle",
						FontSize = 18,
						TextPadding = Vector4(0, 0, 0, 7),
						BackgroundColor = ARGB(255 * 0.6, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/vip_chest/lb_vipgifts_numberbar01.dds", Vector4(10, 10, 10, 10)),
						},
					},
				},
				
				Gui.Control
				{
					Size = Vector2(531, 80),
					Location = Vector2(6, 193),
					BackgroundColor = ARGB(0, 0, 0, 0),
					Gui.Control "ctr_VIP_1"
					{
						Location = Vector2(10, 2),
						Size = Vector2(142, 77),
						BackgroundColor = ARGB(255,255,255,255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_bg_06.dds", Vector4(0, 0, 0, 0)),
						},
						Gui.Control "ctr_VIP_num1"
						{
							Location = Vector2(44, 30),
							Size = Vector2(50, 29),
							BackgroundColor = ARGB(255,255,255,255),
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_button_06_normal.dds", Vector4(0, 0, 0, 0)),
							},
						},
					},
					Gui.Control "ctr_VIP_2"
					{
						Location = Vector2(380, 2),
						Size = Vector2(142, 77),
						BackgroundColor = ARGB(255,255,255,255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_bg_06.dds", Vector4(0, 0, 0, 0)),
						},
						Gui.Control "ctr_VIP_num2"
						{
							Location = Vector2(44, 30),
							Size = Vector2(50, 29),
							BackgroundColor = ARGB(255,255,255,255),
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_button_06_normal.dds", Vector4(0, 0, 0, 0)),
							},
						},
					},
					
					Gui.Control
					{
						Size = Vector2(250,25),
						Location = Vector2(144, 50),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/vip/vip/lb_VIP_scrollbar_slider.dds", Vector4(10, 10, 20, 10)),
						},
						Gui.Control "exp_bar"
						{
							Size = Vector2(0,25),
							Location = Vector2(0, 0),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/vip/vip/lb_VIP_scrollbar_bg.dds", Vector4(10, 10, 20, 10)),
							},
						},
					},
					
					Gui.Label "vip_exp_text"
					{
						Size = Vector2(250,25),
						Location = Vector2(144, 25),
						BackgroundColor = ARGB(0, 255, 255, 255),
						TextAlign = "kAlignCenterMiddle",
					}
				},
				
				Gui.Control "icon1"
				{
					Size = Vector2(531, 221),
					Location = Vector2(6, 276),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/open_box/main_bar03.dds", Vector4(20, 20, 20, 20)),
					},
					create_btn(1, 7, 10),
					create_btn(2, 111, 10),
					create_btn(3, 215, 10),
					create_btn(4, 319, 10),
					create_btn(5, 423, 10),
					create_btn(6, 7, 114),
					create_btn(7, 111, 114),
					create_btn(8, 215, 114),
					create_btn(9, 319, 114),
					create_btn(10, 423, 114),
				},
				Gui.Control "icon2"
				{
					Size = Vector2(531, 221),
					Location = Vector2(6, 276),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ToolTips/lb_tooltips_bg_2.dds", Vector4(10, 10, 10, 10)),
					},
				},
				Gui.Button
				{
					Size = Vector2(124, 44),
					Location = Vector2(209, 505),
					TextColor = ARGB(255, 211, 211, 211),
					HighlightTextColor = ARGB(255, 211, 211, 211),
					Padding = Vector4(0, 0, 0, 7),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/lb_onlinetime_button_2_normal.dds", Vector4(63, 0, 57, 0)),
						HoverImage = Gui.Image("LobbyUI/lb_onlinetime_button_2_hover.dds", Vector4(63, 0, 57, 0)),
						DownImage = Gui.Image("LobbyUI/lb_onlinetime_button_2_down.dds", Vector4(63, 0, 57, 0)),
						DisabledImage = Gui.Image("LobbyUI/lb_onlinetime_button_2_disabled.dds", Vector4(63, 0, 57, 0)),
					},
					Text = lang:GetText("确 定"),
					EventClick = function()
						if Awardmodal then
							Awardmodal.Close()
							Awardmodal = nil
							gui:PlayAudio("kUIA_CONGRA_POP")
						end
					end
				},
			},
			Gui.Control 
			{
				Size = Vector2(568, 56),
				Location = Vector2(1, 0),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/open_box/lb_task_title.dds", Vector4(0, 0, 0, 0)),
				},
			},
		},
		Gui.ChangeControl "Change"
		{
			Visible = false,
			Size = Vector2(1055, 523),
			Normsize = Vector2(1055, 523),
			Location = Vector2(252, 69),
			NormLocation = Vector2(252, 69),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/Mission/levelup_mark.dds", Vector4(0, 0, 0, 0)),
			},
		},
	},
}

main_popup_window = Gui.Create()
{	
	Gui.Control "root"
	{
		Size = Vector2(1200, 900),
		Location = Vector2(0, 0),
		BackgroundColor = ARGB(0, 255, 255, 255),
		Gui.Control "r"
		{
			Size = Vector2(411, 357),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/team/lb_contact_bg1.dds", Vector4(38, 38, 38, 38)),
			},
			Gui.Control
			{
				Size = Vector2(385, 328),
				Location = Vector2(12, 13),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/lb_contact_bg2.dds", Vector4(16, 12, 16, 45)),
				},
				Gui.Label "T"
				{
					Size = Vector2(300, 60),
					Location = Vector2(44, 11),
					TextColor = ARGB(255, 52, 50, 50),
					FontSize = 20,
					TextAlign = "kAlignCenterMiddle",
					Text = lang:GetText("恭喜你完成了每日任务\n  快去领取奖励吧！")
				},
				Gui.Control
				{
					Size = Vector2(308, 205),
					Location = Vector2(57, 60),
					BackgroundColor = ARGB(0, 255, 255, 255),
					Gui.Control "Image"
					{
						Size = Vector2(196, 132),
						Location = Vector2(36, 11),
						BackgroundColor = ARGB(255, 255, 255, 255),
					},
					Gui.TextArea "description"
					{
						TextColor = ARGB(255, 52, 50, 50),
						Size = Vector2(270, 60),
						Location = Vector2(10, 150),
						Readonly = true,
						Fold = true,
						FontSize = 14,
					},
				},
				Gui.Button "next"
				{
					Style = "Gui.Mission_button",
					Location = Vector2(61, 287),
					Text = lang:GetText("下一页"),
					EventClick = function()
						completed_mission_count = completed_mission_count + 1
						Show_popup_window(completed_mission_count)
					end
				},
				Gui.Button "close"
				{
					Style = "Gui.Mission_button",
					Location = Vector2(61, 287),
					Text = lang:GetText("确定"),
					EventClick = function()
						completed_mission_count = 1
						table.remove(L_PushCmd.Queue,1)
						if L_PushCmd.Queue[1] ~= nil then
							Show_popup_window(1)
						else
							L_Mission.main_popup_window.root.Parent = nil
						end
					end
				},
				Gui.Button "button"
				{
					Style = "Gui.Mission_button",
					Location = Vector2(216, 287),
					Text = lang:GetText("前去领奖"),
					EventClick = function()
						completed_mission_count = 1
						L_Mission.main_popup_window.root.Parent = nil
						while true do
							if L_PushCmd.Queue[1] == nil then
								break
							else
								table.remove(L_PushCmd.Queue,1)
							end
						end
						L_LobbyMain.HideAll()
						L_LobbyMain.LobbyMainWin_Foot.btn_Mission.PushDown = true
						lg:SetLobbyModules(8)
						L_LobbyMain.current_chosse_main_page = 8
						L_Mission.Show(L_LobbyMain.LobbyMainWin_Boddy.LobbyMainWin_Boddy_Root)
						--Resetbutton()
					end
				},
			},
		},
	}, 
}

function Show_popup_window(data)
	if main_popup_window then
		if L_PushCmd.Queue[1] ~= nil then
			completed_mission_rpc_data = L_PushCmd.Queue[1]
		end
		main_popup_window.Image.Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("MapsAndBG/MapsIcon/"..completed_mission_rpc_data.mission[data][2]..".dds", Vector4(14, 14, 14, 14)),
		}
		if completed_mission_rpc_data.mission[data][9] == 0 then
			main_popup_window.T.Text = lang:GetText("恭喜你完成了每日任务\n  快去领取奖励吧！")
		elseif completed_mission_rpc_data.mission[data][9] == 1 then
			main_popup_window.T.Text = lang:GetText("恭喜你完成了每周任务\n  快去领取奖励吧！")
		else
			main_popup_window.T.Text = lang:GetText("恭喜你完成了活动\n  快去领取奖励吧！")
		end
		L_Mission.mode_type = completed_mission_rpc_data.mission[data][9]
		if completed_mission_rpc_data.mission[data][10] == 0 then
			main_popup_window.button.Visible = false
			main_popup_window.close.Location = Vector2(141, 287)
			main_popup_window.next.Location = Vector2(141, 287)
			main_popup_window.T.Text = lang:GetText("恭喜你完成了活动")
		else
			main_popup_window.button.Visible = true
			main_popup_window.next.Location = Vector2(61, 287)
			main_popup_window.close.Location = Vector2(61, 287)
		end
		main_popup_window.description.Text = completed_mission_rpc_data.mission[data][4]
		if data ~= completed_mission_rpc_data.num then
			main_popup_window.next.Visible = true
			main_popup_window.close.Visible = false
		else
			main_popup_window.next.Visible = false
			main_popup_window.close.Visible = true
		end
		Gui.Align(main_popup_window.r, 0.5, 0.5)
		main_popup_window.root.Parent = L_LobbyMain.LobbyMainWin.LobbyMain_Root
	end
end

Mission = Gui.Create()
{
	Gui.Control "root"
	{
		Size = Vector2(1116, 586),
		Location = Vector2(19, 25),
		BackgroundColor = ARGB(0, 255, 255, 255),
		
		Gui.Control 
		{
			Size = Vector2(1101, 551),
			Location = Vector2(9, 35),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_daoju_bg.tga", Vector4(22, 22, 22, 22)),
			},
		},
		
		Gui.Control 
		{
			Size = Vector2(1060, 502),
			Location = Vector2(28,76),
			BackgroundColor = ARGB(0, 255, 255, 255),
			
			Gui.Control 
			{
				Size = Vector2(1060, 502),
				Location = Vector2(0,0),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg3.dds", Vector4(22, 22, 22, 22)),
				},
			},
			
			Gui.Control 
			{
				Size = Vector2(670-60, 483),
				Location = Vector2(374+60, 10),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Mission/lb_task_bg_5.dds", Vector4(384, 162, 44, 49)),
				},
				
				Gui.Control 
				{
					Size = Vector2(688-60, 260),
					Location = Vector2(6, 6),
					BackgroundColor = ARGB(0, 255, 255, 255),
					Gui.Label
					{
						Size = Vector2(500, 24),
						Location = Vector2(10, 4),
						TextColor = ARGB(255, 255, 149, 3),
						FontSize = 20,
						Text = lang:GetText("任务目标")..":",
					},
					Gui.Control "icon"
					{
						Size = Vector2(196, 133),
						Location = Vector2(23, 46),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("MapsAndBG/MapsIcon/battlefield_map_lv2.dds", Vector4(0, 0, 0, 0)),
						},
						Gui.Control "complete"
						{
							Size = Vector2(87, 87),
							Location = Vector2(109, 0),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/Mission/lb_task_ico_wancheng.dds", Vector4(0, 0, 0, 0)),
							},
						},
					},
					
					Gui.Label 
					{
						Size = Vector2(200, 25),
						Location = Vector2(25, 180),
						Text = lang:GetText("任务进度："),
						FontSize = 18,
						TextColor = ARGB(255, 165, 195, 83),
					},
					
					Gui.Label "lab_1"
					{
						Size = Vector2(200, 25),
						Location = Vector2(25, 200),
						TextAlign = "kAlignLeftMiddle",
						FontSize = 18,
						TextColor = ARGB(255, 165, 195, 83),
					},
					
					Gui.Control "expBG"
					{
						Size = Vector2(195, 20),
						Location = Vector2(25, 230),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/Mission/lb_common_expbar01_bg.dds", Vector4(14, 0, 14, 0)),
						},
						Gui.Control "exp"
						{
							Size = Vector2(195, 20),
							Location = Vector2(0, 0),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/Mission/lb_info_bar01_content.dds", Vector4(0, 0, 0, 0)),
							},
						},
					},
					
					Gui.Control 
					{
						Size = Vector2(424-60, 202),
						Location = Vector2(230, 44),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/Mission/lb_task_bg_6.dds", Vector4(7, 7, 39, 39)),
						},
					},
					Gui.TextArea "des1"
					{
						Size = Vector2(440-60, 190),
						Location = Vector2(232, 60),
						TextColor = ARGB(255, 0, 0, 0),
						FontSize = 20,
						Readonly = true,
						Fold = true,
					},
					Gui.TextArea "des"
					{
						Size = Vector2(440-60, 190),
						Location = Vector2(231, 59),
						TextColor = ARGB(255, 255, 210, 0),
						BackgroundColor = ARGB(255, 255, 255, 255),
						FontSize = 20,
						Readonly = true,
						Fold = true,
					},
				},
				Gui.Control 
				{
					Size = Vector2(678-60, 232),
					Location = Vector2(6, 270),
					BackgroundColor = ARGB(0, 255, 255, 255),
					
					Gui.Control "award_e_g"
					{
						Size =  Vector2(678-60, 56),
						Location = Vector2(15, 0),
						Gui.Label "image0"
						{
							Size = Vector2(170, 20),
							Location = Vector2(0, 0),
							FontSize = 18,
							TextColor = ARGB(255, 195, 132, 53),
							Text = lang:GetText("任务奖励")..":",
						},
						Gui.FlowLayout "experience"
						{
							Size =  Vector2(520, 18),
							Location = Vector2(190, 2),
						},
						Gui.FlowLayout "gold"
						{
							Size =  Vector2(520, 18),
							Location = Vector2(310, 2),
						},
						Gui.Label "image1"
						{
							Size = Vector2(170, 20),
							Location = Vector2(0, 28),
							FontSize = 18,
							TextColor = ARGB(255, 195, 132, 53),
							Text = lang:GetText("VIP额外获得")..":",
						},
						Gui.FlowLayout "vip_experience"
						{
							Size =  Vector2(520, 18),
							Location = Vector2(190, 30),
						},
						Gui.FlowLayout "vip_gold"
						{
							Size =  Vector2(520, 18),
							Location = Vector2(310, 30),
						},
					},
					Gui.Control "award"
					{
						Size = Vector2(678, 97),
						Location = Vector2(0, 52),
					},
					Gui.Button "btn_award"
					{
						Size = Vector2(188, 56),
						Location = Vector2(440-60, 150),
						TextColor = ARGB(255, 54, 54, 52),
						HighlightTextColor = ARGB(255, 54, 54, 52),
						FontSize = 25,
						Text = lang:GetText("领取奖励"),
						blink = false,
						blink_shade = false,
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/Mission/lb_task_button_receive_normal.dds", Vector4(10, 10, 10, 10)),
							HoverImage = Gui.Image("LobbyUI/Mission/lb_task_button_receive_hover.dds", Vector4(10, 10, 10, 10)),
							DownImage = Gui.Image("LobbyUI/Mission/lb_task_button_receive_down.dds", Vector4(10, 10, 10, 10)),
							DisabledImage = Gui.Image("LobbyUI/Mission/lb_task_button_receive_disabled.dds", Vector4(10, 10, 10, 10)),
							TwinkleImage  = Gui.Image("LobbyUI/Mission/lb_task_button_receive_hover.dds", Vector4(0, 0, 0, 0)),
						},

						EventClick = function(Sender,e)
							local state = ptr_cast(game.CurrentState)
							local fcm_time = state.fcm_online_time
							if state.fcm_flag == 0 then
								fcm_time = 0
							end
							if mode_type == 3 then
								local args = {pid = ptr_cast(game.CurrentState):GetCharacterId(), mid = Mission_id}
								rpc.safecallload("get_growth_gift", args, FillAwaedUi)
							else
								local args = {pid = ptr_cast(game.CurrentState):GetCharacterId(), type = 1, mission_id = Mission_id, mission_type = mode_type}
								rpc.safecallload("mission", args, FillAwaedUi)
							end
							
							Sender.Enable = false
							Sender.Text = lang:GetText("已领取")
							gui:PlayAudio("kUIA_MISSION_REWARD")
							
							--更新在线时长模块
							L_LobbyMain.my_flag = 0
							
							L_LobbyMain.FillPersonalInfo()
						end
					},
				},
				Gui.Label "is_open"
				{
					Size = Vector2(670-60, 483),
					Location = Vector2(0, 0),
					BackgroundColor = ARGB(255, 255, 255, 255),
					TextColor = ARGB(255, 169, 163, 143),
					--Text = lang:GetText("等级到达13级并完成相应成长任务后开放"),
					TextAlign = "kAlignCenterMiddle",
					FontSize = 24,
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/Mission/lb_task_bg4.dds", Vector4(257, 0, 124, 0)),
					},
					
					Gui.RichEdit "re_msg"
					{
						Size = Vector2(500, 200),
						Location = Vector2(140, 200),
						FontSize = 24,
						BackgroundColor = ARGB(255, 255, 255, 255),
						Line_Space = 5,
						Text_Shadow = true,
						
						VScrollBarWidth = 16,
						VScrollBarButtonSize = 1,
						Style = "Gui.MessagePanel",
						AutoScroll = true,
						AutoScrollMinSize = Vector2(464, 140),
						HScrollBarDisplay = "kHide",
						VScrollBarDisplay = "kAuto",
						
					},
				},
			},
			
			Gui.Control
			{
				Size = Vector2(353+60, 483),
				Location = Vector2(10, 10),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Mission/lb_task_bg_6.dds", Vector4(7, 7, 39, 39)),
				},
				Gui.Control 
				{
					Location = Vector2(12, 12),
					Size = Vector2(329+60, 393),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/lb_battlefield_serverlist_bg01b.tga", Vector4(7, 42, 7, 8)),
					},
				},
			},
			
			Gui.ListTreeView "con1_ltv"
			{
				ItemHeight = 55,
				Location = Vector2(25, 25),
				Size = Vector2(362+60, 385),
				BackgroundColor = ARGB(255, 255, 255, 255),
				HScrollBarDisplay = "kHide",
				VScrollBarDisplay = "kHide",
				AlwaysSelect = true,
				HeaderVisible = false,
				EventSelectItemChange = function()
					FillMission()
				end
			},
			
			Gui.Control 
			{
				Visible = false,
				Enable = false,
				Size = Vector2(80, 60 * 10),
				Location = Vector2(258,18),
				BackgroundColor = ARGB(0, 0, 0, 0),
				create_con(1),
				create_con(2),
				create_con(3),
				create_con(4),
				create_con(5),
				create_con(6),
				create_con(7),
				create_con(8),
				create_con(9),
				create_con(10),
			},
			Gui.Button "m_Left"
			{	Size = Vector2(44, 32),
				Visible = true,
				Location = Vector2(98+30,438),
				TextColor = ARGB(255, 209, 227, 221),
				
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ib_common_nextpage_button_normal.dds", Vector4(5, 5, 10, 5)),
					HoverImage = Gui.Image("LobbyUI/ib_common_nextpage_button_hover.dds", Vector4(5, 5, 10, 5)),
					DownImage = Gui.Image("LobbyUI/ib_common_nextpage_button_down.dds", Vector4(5, 5, 10, 5)),
				},
				EventClick = function(Sender,e)
					if page > 1 then
						page = page - 1
						Fill()
					end
				end
			},
			
			Gui.Label "lab_2"
			{	
				Size = Vector2(72, 34),
				Location = Vector2(142+30,436),
				TextColor = ARGB(255, 209, 227, 221),
				Text = "1/1",
				FontSize = 16,
				TextAlign = "kAlignCenterMiddle",
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_page_hover.dds", Vector4(5, 5, 10, 5)),
				},
			},
			
			Gui.Button "m_Right"
			{
				Size = Vector2(44, 32),
				Visible = true,
				Location = Vector2(214+30,438),
				TextColor = ARGB(255, 209, 227, 221),
				
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ib_common_nextpage_button02_normal.dds", Vector4(5, 5, 10, 5)),
					HoverImage = Gui.Image("LobbyUI/ib_common_nextpage_button02_hover.dds", Vector4(5, 5, 10, 5)),
					DownImage = Gui.Image("LobbyUI/ib_common_nextpage_button02_down.dds", Vector4(5, 5, 10, 5)),
				},
				EventClick = function(Sender,e)
					if page < max_page then
						page = page + 1
						Fill()
					end
				end
			},
		},
		
		create_type_button(3, lang:GetText("新手任务"), 38),
		create_type_button(0, lang:GetText("每日任务"), 234),
		create_type_button(1, lang:GetText("每周任务"), 430),
		create_type_button(2, lang:GetText("活动"), 626),
		create_Label(1, 38),
		create_Label(2, 234),
		create_Label(3, 430),
		create_Label(4, 626),
		
		Gui.Button "btn_Close"
		{
			Size = Vector2(64, 52),
			Location = Vector2(1049, 3),
			PushDown = false,
			Hint = lang:GetText("关闭任务界面并返回至战区"),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button01_normal.dds", Vector4(0, 0, 0, 0)),
				HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button01_hover.dds", Vector4(0, 0, 0, 0)),
				DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button01_down.dds", Vector4(0, 0, 0, 0)),
				DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button01_normal.dds", Vector4(0, 0, 0, 0)),
			},

			EventClick = function()
				L_LobbyMain.HideAll()
				L_WarZone.Show(L_LobbyMain.LobbyMainWin_Boddy.LobbyMainWin_Boddy_Root)
			end
		},
	},
}

function FillHead()
	if myTemp > 7 then
		Mission.new1.Visible = true
		myTemp = myTemp - 8
	end
	if myTemp > 3 then
		Mission.new4.Visible = true
		myTemp = myTemp - 4
	end
	if myTemp > 1 then
		Mission.new3.Visible = true
		myTemp = myTemp - 2
	end
	if myTemp > 0 then
		Mission.new2.Visible = true
	end
	if mode_type == 3 then
		Mission.new1.Visible = false
	elseif mode_type == 2 then
		Mission.new4.Visible = false
	elseif mode_type == 1 then
		Mission.new3.Visible = false
	else
		Mission.new2.Visible = false
	end
end

function Fill()
	if mode_type ~= 3 then
		local args = {pid = ptr_cast(game.CurrentState):GetCharacterId(), type = 0, mission_type = mode_type, pageNo = page}
		rpc.safecallload("mission", args, FillList)
	else
		rpc.safecallload("get_growth_list", {pid = ptr_cast(game.CurrentState):GetCharacterId(), pageNo = page}, FillList)
	end
end

function FillList(data)
	myTemp = data.awoke
	FillHead()
	max_page = data.pages
	page = data.page
	Mission.lab_2.Text = page.."/"..max_page
	local ltv = Mission.con1_ltv
	ltv:DeleteAll()
	flag = 0
	i = 1
	for _,v in ipairs(data.mission) do
		flag = 1
		local sub_item = ltv:AddItem(ltv.RootItem)
		rpc_back[i] = v
		sub_item:AddSubItem(v[3])
		sub_item.FontSize = 20
		vipexp[i] = v.vipExp
		if v[7] ~= 1 then
			if mode_type == 3 and v[16] == 1 then
				sub_item.TextColor = ARGB(255, 255, 85, 1)
				sub_item.HighlightTextColor = ARGB(255, 255, 85, 1)
			else
				sub_item.TextColor = ARGB(255, 255, 211, 78)
				sub_item.HighlightTextColor = ARGB(255, 255, 211, 78)
			end
			Mission["con_"..i].Visible = false
		else
			if v[8] ~= 1 then
				sub_item.TextColor = ARGB(255, 175, 197, 196)
				sub_item.HighlightTextColor = ARGB(255, 175, 197, 196)
			else
				sub_item.TextColor = ARGB(255, 1, 255, 169)
				sub_item.HighlightTextColor = ARGB(255, 1, 255, 169)
			end
			Mission["con_"..i].Visible = true
		end
		if v[7] == 1 and v[8] ~= 1 then
			sub_item.LV_BackgroundImage = Gui.Image("LobbyUI/Mission/lb_task_complete.dds", Vector4(0, 0, 0, 0))
		elseif v[8] == 1 then
			sub_item.LV_BackgroundImage = Gui.Image("LobbyUI/Mission/lb_task_theend.dds", Vector4(0, 0, 0, 0))
		else
			if mode_type == 3 and v[16] == 1 then
				sub_item.LV_BackgroundImage = Gui.Image("LobbyUI/Mission/lb_task_didnotcomplete_1.dds", Vector4(0, 0, 0, 0))
			else
				sub_item.LV_BackgroundImage = Gui.Image("LobbyUI/Mission/lb_task_didnotcomplete.dds", Vector4(0, 0, 0, 0))
			end
		end
		sub_item.LV_localtion = Vector2(0, 2)
		sub_item.LV_Size = Vector2(212, 56)
		if i % 2 == 1 then
			sub_item.BGSkin = Skin.ListItemSkin_MissionSingle
		else
			sub_item.BGSkin = Skin.ListItemSkin_MissionDouble
		end
		if i == 1 then
			ltv.SelectedItem = sub_item
		end
		i = i + 1
	end
	if i == 1 then
		FillMission()
	end
	
	if i < 8 then
		local j 
		for j = i ,7 do
			local sub_item = ltv:AddItem(ltv.RootItem)
			sub_item.CanSelect = false
			if j % 2 == 1 then
				sub_item.BGSkin = Skin.ListItemSkin_MissionSingle
			else
				sub_item.BGSkin = Skin.ListItemSkin_MissionDouble
			end
			Mission["con_"..j].Visible = false
		end
	end
end

function FillAward(data, index, index1)
	local Award = Gui.Create()
	{
		Gui.ItemBoxBtn "Image"
		{
			Style = "Gui.ItemBoxBtn_ib",
			Size = Vector2(115, 92),
			Location = Vector2(120 * (index - 1), 0),
			BackgroundColor = ARGB(255, 255, 255, 255),
			CanSelect = false,
			
			Skin = Gui.ItemBoxBtnSkin
			{
				NeutralNormalImage = Gui.Image("LobbyUI/Mission/lb_task_bg2.dds", Vector4(0, 0, 0, 0)),
				NeutralSelectedImage = Gui.Image("LobbyUI/Mission/lb_task_bg2.dds", Vector4(0, 0, 0, 0)),
				NeutralDisabledImage = Gui.Image("LobbyUI/Mission/lb_task_bg2_disabled.dds", Vector4(0, 0, 0, 0)),
			},
			
			EventMouseEnter = function(sender, e)
				--index1 为任务的索引 index为某个任务奖励的索引
				L_ToolTips.FillToolTipsVIPPresent(index, gui, rpc_back[index1].items)
			end,
			
			EventToolTipsShow = function(sender, e)
				--ToolTips 坐标偏移
				local pos = sender:ClientToGlobalScreen(sender.Location)
				pos.x = pos.x - ( ( index - 1 ) * 120 )
				L_ToolTips.ShowToolTipsShowWindow(sender, nil, pos)
			end,
			
			EventMouseLeave = function(sender, e)
				L_ToolTips.HideToolTipsWindow()
			end,
			
		},
	}
	if data then
		if data[5] == 11 and data[7] == 0 then
		else
			if data.isVip == 1 then
				Award.Image.ItemIconNew = Gui.Icon("LobbyUI/ShoppingMall/lb_vip_ico2.dds")
			else
				Award.Image.ItemIconNew = nil
			end
			if data.color > 0 and data.color < 9 then
				Award.Image.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..data.name.."_"..data.color..".tga", Vector4(0, 0, 0, 0))
			else
				Award.Image.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..data.name..".tga", Vector4(0, 0, 0, 0))
			end
			if data.common.type >= 4 then
				L_Characters.CreatPresentNumCtr(Award.Image, data.common.quantity, 115, 92)
			end
			Award.Image.Enable = true
			return Award
		end
	else
		Award.Image.Enable = false
		Award.Image.ItemIcon = nil
		return Award
	end
end

function Initialize()
end

function Finalize()
end

function FillMission()
	local ltv = Mission.con1_ltv
	if flag == 0 then
		Mission.is_open.Visible = true
		Mission.re_msg:CleanAll()
		if mode_type ~= 2 and mode_type ~= 3 then
			Mission.re_msg:AddMsg(lang:GetText("达成以下条件开启"),ARGB(255, 169, 163, 143),true,false)
			Mission.re_msg:AddMsg(lang:GetText("“每日任务、每周任务”"),ARGB(255,181, 51, 0),false,false)
			Mission.re_msg:AddMsg(lang:GetText("："),ARGB(255, 169, 163, 143),false,false)
			Mission.re_msg:AddMsg(lang:GetText("1．等级达到"),ARGB(255, 169, 163, 143),true,false)
			Mission.re_msg:AddMsg(13,ARGB(255,181, 51, 0),false,false)
			Mission.re_msg:AddMsg(lang:GetText("级  "),ARGB(255, 169, 163, 143),false,false)
			Mission.re_msg:AddMsg(lang:GetText("2．完成主线任务"),ARGB(255, 169, 163, 143),true,false)
			Mission.re_msg:AddMsg(lang:GetText("“最终试炼”"),ARGB(255,181, 51, 0),false,false)
		end
	else
		Mission.is_open.Visible = false
		Mission_id = rpc_back[ltv.SelectingIndex + 1][1]
		Mission.icon.Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("MapsAndBG/MapsIcon/"..rpc_back[ltv.SelectingIndex + 1][2]..".dds", Vector4(0, 0, 0, 0)),
		}
		Mission.des.Text = rpc_back[ltv.SelectingIndex + 1][4]
		Mission.des1.Text = rpc_back[ltv.SelectingIndex + 1][4]
		if rpc_back[ltv.SelectingIndex + 1][6] > rpc_back[ltv.SelectingIndex + 1][5] then
			Mission.lab_1.Text = rpc_back[ltv.SelectingIndex + 1][5].."/"..rpc_back[ltv.SelectingIndex + 1][5]
			Mission.exp.Size = Vector2(195, 20)
		else
			Mission.lab_1.Text = rpc_back[ltv.SelectingIndex + 1][6].."/"..rpc_back[ltv.SelectingIndex + 1][5]
			Mission.exp.Size = Vector2(195 * rpc_back[ltv.SelectingIndex + 1][6] / rpc_back[ltv.SelectingIndex + 1][5], 20)
		end
		Mission.experience:OnDestroy()
		Mission.gold:OnDestroy()
		Mission.vip_experience:OnDestroy()
		Mission.vip_gold:OnDestroy()
		if rpc_back[ltv.SelectingIndex + 1][12] == 0 and rpc_back[ltv.SelectingIndex + 1][13] == 0 then
			Mission.experience.Visible = false
			Mission.gold.Visible = false
		else
			Mission.experience.Visible = true
			Mission.gold.Visible = true
			CreatNumCtr(Mission.experience, rpc_back[ltv.SelectingIndex + 1][13], 0)
			CreatNumCtr(Mission.gold, rpc_back[ltv.SelectingIndex + 1][12], 1)
		end
		if rpc_back[ltv.SelectingIndex + 1][14] == 0 and rpc_back[ltv.SelectingIndex + 1][15] == 0 then
			Mission.vip_experience.Visible = false
			Mission.vip_gold.Visible = false
			Mission.image1.Visible = false
		else
			Mission.vip_experience.Visible = true
			Mission.vip_gold.Visible = true
			Mission.image1.Visible = true
			CreatNumCtr(Mission.vip_experience, rpc_back[ltv.SelectingIndex + 1][15], 0)
			CreatNumCtr(Mission.vip_gold, rpc_back[ltv.SelectingIndex + 1][14], 1)
		end
		Mission.award:OnDestroy()
		for i = 1, 5 do
			local GUI = FillAward(rpc_back[ltv.SelectingIndex + 1].items[i], i, ltv.SelectingIndex + 1)
			GUI.Image.Parent = Mission.award
		end
		if rpc_back[ltv.SelectingIndex + 1][10] == 0 and mode_type == 2 then
			Mission.btn_award.Visible = false
			Mission.lab_1.Visible = false
			Mission.expBG.Visible = false
		else
			Mission.btn_award.Visible = true
			Mission.expBG.Visible = true
			Mission.lab_1.Visible = true
			if rpc_back[ltv.SelectingIndex + 1][8] == 0 and rpc_back[ltv.SelectingIndex + 1][7] == 1 then
				Mission.btn_award.Enable = true
				Mission.btn_award.blink = true
			else
				Mission.btn_award.Enable = false
				Mission.btn_award.blink = false
			end
			if rpc_back[ltv.SelectingIndex + 1][8] == 0 then
				Mission.btn_award.Text = lang:GetText("领取奖励")
			else
				Mission.btn_award.Text = lang:GetText("已领取")
			end
		end
		if rpc_back[ltv.SelectingIndex + 1][7] == 1 then
			Mission.complete.Visible = true
		else
			Mission.complete.Visible = false
		end
		
		local state = ptr_cast(game.CurrentState)
		if state.fcm_online_time >= 300 and state.fcm_flag ~= 0 then
			Mission.btn_award.Enable = false
		end
		
	end
end

function Show(parent_win)
	page = 1
	mode_type = 3 
	Mission.type_button_0.PushDown = false
	Mission.type_button_1.PushDown = false
	Mission.type_button_2.PushDown = false
	Mission.type_button_3.PushDown = true
	local list = Mission.con1_ltv
	list:DeleteColumns()
	list:AddColumn("",60, "kAlignCenterMiddle")
	list:AddColumn("",428, "kAlignLeftMiddle")
	Fill()
	Mission.root.Parent = parent_win
end

function Hide()
	Mission.root.Parent = nil
end

function FillAwaedUi(data)
	Awardmodal = ModalWindow.GetNew()
	Awardmodal.root.Size = Vector2(1600,900)
	Award_ui.root.Parent = Awardmodal.root
	Award_ui.t1.Text = data.info[2]
	Award_ui.t2.Text = data.info[1]
	Award_ui.t3.Text = data.info[4]
	Award_ui.t4.Text = data.info[3]
	local ltv = Mission.con1_ltv
	rpc_back_1 = data
	for i,v in ipairs(data.items) do
		local btn = ptr_cast(Award_ui.icon1:GetChildByIndex(i - 1))
		btn:OnDestroy()
		btn.Enable = true
		if v.color > 0 and v.color < 8 then
			btn.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..v.name.."_"..v.color..".tga")
		else
			btn.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..v.name..".tga")
		end
		if v.isVip == 1 then
			btn.ItemIconNew = Gui.Icon("LobbyUI/ShoppingMall/lb_vip_ico2.dds")
		else
			btn.ItemIconNew = nil
		end
		if v.common.type >= 4 then
			L_Characters.CreatPresentNumCtr(btn, v.common.quantity, 100, 100)
		end
		i = i + 1
	end
	
	if #data.items == 0 then
		Award_ui.icon2.Visible = true
	else
		Award_ui.icon2.Visible = false
	end
	
	if L_Vip.Viplevel == L_Vip.VipMaxlevel then
		Award_ui.vip_exp_text.Visible = true
		
		Award_ui.vip_exp_text.Text = "Max"
		
		Award_ui.ctr_VIP_1.Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_bg_0"..(L_Vip.VipMaxlevel - 1)..".dds", Vector4(0, 0, 0, 0)),
		}
		
		Award_ui.ctr_VIP_num1.Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_button_0"..(L_Vip.VipMaxlevel - 1).."_normal.dds", Vector4(0, 0, 0, 0)),
		}
		
		Award_ui.ctr_VIP_2.Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_bg_0"..L_Vip.VipMaxlevel..".dds", Vector4(0, 0, 0, 0)),
		}
		
		Award_ui.ctr_VIP_num2.Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_button_0"..L_Vip.VipMaxlevel.."_normal.dds", Vector4(0, 0, 0, 0)),
		}
		
		Award_ui.exp_bar.Size = Vector2(250, 25)
	else
		if mode_type > 0 then
			Award_ui.vip_exp_text.Visible = false
		else
			Award_ui.vip_exp_text.Visible = true
			if L_Vip.Viplevel == L_Vip.VipMaxlevel - 1 then
				if L_Vip.now_box == 1 then
					Award_ui.vip_exp_text.Text = (L_Vip.Vipexp - vipexp[ltv.SelectingIndex + 1]).."+("..vipexp[ltv.SelectingIndex + 1]..")/"..L_Vip.vip_exp[8]
				else
					Award_ui.vip_exp_text.Text = (L_Vip.Vipexp - vipexp[ltv.SelectingIndex + 1]).."+("..vipexp[ltv.SelectingIndex + 1]..")/"..L_Vip.vip_box_exp[L_Vip.now_box - 1]
				end
			else
				Award_ui.vip_exp_text.Text = (L_Vip.Vipexp - vipexp[ltv.SelectingIndex + 1]).."+("..vipexp[ltv.SelectingIndex + 1]..")/"..L_Vip.vip_exp[L_Vip.Viplevel + 1]
			end
		end
	
		Award_ui.ctr_VIP_1.Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_bg_0"..L_Vip.Viplevel..".dds", Vector4(0, 0, 0, 0)),
		}
		
		Award_ui.ctr_VIP_2.Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_bg_0"..(L_Vip.Viplevel + 1)..".dds", Vector4(0, 0, 0, 0)),
		}
		
		Award_ui.ctr_VIP_num1.Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_button_0"..L_Vip.Viplevel.."_normal.dds", Vector4(0, 0, 0, 0)),
		}
		
		Award_ui.ctr_VIP_num2.Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_button_0"..(L_Vip.Viplevel + 1).."_normal.dds", Vector4(0, 0, 0, 0)),
		}
		
		if L_Vip.Viplevel == 0 then
			Award_ui.exp_bar.Size = Vector2(0, 25)
		else
			if L_Vip.now_box == 15 then
				Award_ui.exp_bar.Size = Vector2(250,25)
			else
				if L_Vip.Viplevel == L_Vip.VipMaxlevel - 1 then
					if (L_Vip.vip_box_exp[L_Vip.now_box]-L_Vip.Vipexp) <= 0 then
						Award_ui.exp_bar.Size = Vector2(250,25)
					else
						if L_Vip.now_box == 1 then
							Award_ui.exp_bar.Size = Vector2((1 - ((L_Vip.vip_box_exp[L_Vip.now_box]-L_Vip.Vipexp) / (L_Vip.vip_box_exp[L_Vip.now_box] - L_Vip.vip_exp[8])))*250,25)
						else
							Award_ui.exp_bar.Size = Vector2((1 - ((L_Vip.vip_box_exp[L_Vip.now_box]-L_Vip.Vipexp) / (L_Vip.vip_box_exp[L_Vip.now_box] - L_Vip.vip_box_exp[L_Vip.now_box - 1])))*250,25)
						end
					end
				else
					Award_ui.exp_bar.Size = Vector2((1 - ((L_Vip.vip_exp[L_Vip.Viplevel+1]-L_Vip.Vipexp) / (L_Vip.vip_exp[L_Vip.Viplevel+1] - L_Vip.vip_exp[L_Vip.Viplevel])))*250,25)
				end
			end
		end
	end
	
	for i = #data.items + 1, 10 do
		local btn = ptr_cast(Award_ui.icon1:GetChildByIndex(i - 1))
		btn:OnDestroy()
		btn.Enable = false
		btn.ItemIcon = nil
		btn.ItemIconNew = nil
	end
	if data.info[5] == 1 then
		Award_ui.Change.Visible = true
		Award_ui.Change:Clear()
		Award_ui.Change:InsertMovePoint(Vector2(777,231), 0.1, Vector2(404,200), ARGB(255, 255, 255, 255))
	else
		Award_ui.Change.Visible = false
	end
	Fill()
end

function CreatNumCtr(m_parent, num, m_type)
	local n = 0
	local Tep_unm = num
	while Tep_unm > 0 do
		Tep_unm = math.floor(Tep_unm/10)
		n = n + 1
	end
	local ctr_num = Gui.Create()
	{
		Gui.Control "ctr_num_local"
		{
			Size = Vector2(37 + n*12, 21),
			BackgroundColor = ARGB(0, 255, 255, 255),
			Location = Vector2(0, 0),
			
			Gui.Control "image"
			{
				Size = Vector2(32, 21),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Location = Vector2(n * 12 + 5, -3),
			},
		},
	}
	if m_type == 1 then
		ctr_num.image.Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/ibt_icon/caladd_cb.tga", Vector4(0, 0, 0, 0)),
		}
	else
		ctr_num.image.Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/ibt_icon/caladd_exp.tga", Vector4(0, 0, 0, 0)),
		}
	end
	while num > 0 do
		Tep_unm = num % 10
		local ctr = Gui.Create()
		{
			Gui.Control "ctr_n"
			{
				Size = Vector2(15, 18),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Location = Vector2((n - 1) * 12, 0),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ibt_icon/caladd_number.tga", Vector4(0, 0, 0, 0),Vector4(Tep_unm/10.0 , 0, (Tep_unm + 1)/10.0, 1)),
				}
			},
		}
		ctr.ctr_n.Parent = ctr_num.ctr_num_local
		num = math.floor(num/10)
		n = n - 1
	end
	ctr_num.ctr_num_local.Parent = m_parent
end