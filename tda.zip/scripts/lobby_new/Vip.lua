module("L_Vip", package.seeall)

VipMaxlevel = 9
vip_des = {lang:GetText("\n\n\n\n\n\n               激活VIP可享受豪华VIP特权"),
				lang:GetText("1.完成每日、每周任务可额外获得50%奖励（下一级60%）\n2.过关结算可获得额外50%经验、C币加成（下一级70%）\n3.额外的强化成功率+5%\n4.免费兑换加入更多精彩道具 \n5.开启VIP箱权利\n6.过关结算时可以多1次翻牌的机会\n7.中途退出游戏可保留正常游戏的收益\n8.离开战队会保留30%的贡献值\n9.每日战队战贡献上限增加100\n10.为战队充能战队会多获得50%的战队经验（下一级60%）\n11.为战队充能会多获得50%的贡献值（下一级60%）\n12.在线奖励时间周期缩短一半\n13.增加改装成功率\n14.可获得免费补签和提前签到机会共3次\n15.增加游戏内每日踢人次数1次\n16.每天可猜数字3个\n17.游戏中TAB，游戏房间内、排行榜的VIP等级缎带更加绚丽\n23.VIP专属名片\n20.VIP专属头像(根据VIP等级变换)\n21.VIP标示"),
				lang:GetText("1.完成每日、每周任务可额外获得60%奖励（下一级70%）\n2.过关结算可获得额外70%经验、C币加成（下一级90%）\n3.额外的强化成功率+5%（下一级10%）\n4.VIP商城加入更多精彩道具 \n5.免费兑换加入更多精彩道具 \n6.开启VIP箱权利\n7.过关结算时可以多1次翻牌的机会（下一级2次）\n8.中途退出游戏可保留正常游戏的收益\n9.离开战队会保留30%的贡献值（下一级40%）\n10.每日战队战贡献上限增加100（下一级200）\n11.为战队充能战队会多获得60%的战队经验（下一级70%）\n12.为战队充能会多获得60%的贡献值（下一级70%）\n13.在线奖励时间周期缩短一半\n14.增加改装成功率\n15.可获得免费补签和提前签到机会共3次（下一级4次）\n16.增加游戏内每日踢人次数1次\n17.每天可猜数字3个\n18.游戏中TAB，游戏房间内、排行榜的VIP等级缎带更加绚丽\n23.VIP专属名片\n21.VIP专属头像(根据VIP等级变换)\n22.VIP标示"),
				lang:GetText("1.完成每日、每周任务可额外获得70%奖励（下一级80%）\n2.过关结算可获得额外90%经验、C币加成（下一级110%）\n3.额外的强化成功率+10%\n4.拼图开始时直接点亮3张\n5.VIP商城加入更多精彩道具 \n6.免费兑换加入更多精彩道具 \n7.开启VIP箱权利\n8.过关结算时可以多2次翻牌的机会\n9.中途退出游戏可保留正常游戏的收益\n10.离开战队会保留40%的贡献值\n11.每日战队战贡献上限增加200\n12.为战队充能战队会多获得70%的战队经验（下一级80%）\n13.为战队充能会多获得70%的贡献值（下一级80%）\n14.在线奖励时间周期缩短一半\n15.增加改装成功率\n16.可获得免费补签和提前签到机会共4次\n17.增加游戏内每日踢人次数1次\n18.每天可猜数字3个\n19.游戏中TAB，游戏房间内、排行榜的VIP等级缎带更加绚丽\n23.VIP专属名片\n22.VIP专属头像(根据VIP等级变换)\n23.VIP标示"),
				lang:GetText("1.完成每日、每周任务可额外获得80%奖励（下一级90%）\n2.过关结算可获得额外110%经验、C币加成（下一级130%）\n3.额外的强化成功率+10%（下一级15%）\n4.拼图开始时直接点亮3张（下一级4张）\n5.VIP商城加入更多精彩道具 \n6.免费兑换加入更多精彩道具 \n7.开启VIP箱权利\n8.过关结算时可以多2次翻牌的机会（下一级3次）\n9.中途退出游戏可保留正常游戏的收益\n10.离开战队会保留40%的贡献值（下一级50%）\n11.每日战队战贡献上限增加200（下一级400）\n12.为战队充能战队会多获得80%的战队经验（下一级90%）\n13.为战队充能会多获得80%的贡献值（下一级90%）\n14.在线奖励时间周期缩短一半\n15.大幅增加改装成功率\n16.可获得免费补签和提前签到机会共4次（下一级5次）\n17.熔能无限制\n18.增加游戏内每日踢人次数1次\n19.每天可猜数字3个\n20.游戏中TAB，游戏房间内、排行榜的VIP等级缎带更加绚丽\n23.VIP专属名片\n23.VIP专属头像(根据VIP等级变换)\n24.VIP标示"),
				lang:GetText("1.完成每日、每周任务可额外获得90%奖励（下一级100%）\n2.过关结算可获得额外130%经验、C币加成（下一级150%）\n3.额外的强化成功率+15%\n4.解锁强化等级至13\n5.拼图开始时直接点亮4张\n6.VIP商城加入更多精彩道具 \n7.免费兑换加入更多精彩道具 \n8.开启VIP箱权利\n9.过关结算时可以多3次翻牌的机会\n10.中途退出游戏可保留正常游戏的收益\n11.离开战队会保留50%的贡献值\n12.每日战队战贡献上限增加400\n13.为战队充能战队会多获得90%的战队经验（下一级100%）\n14.为战队充能会多获得90%的贡献值（下一级100%）\n15.在线奖励时间周期缩短一半\n16.大幅增加改装成功率\n17.可获得免费补签和提前签到机会（共5次）\n18.熔能无限制\n19.增加游戏内每日踢人次数1次\n20.每天可猜数字3个\n21.游戏中TAB，游戏房间内、排行榜的VIP等级缎带更加绚丽\n23.VIP专属名片\n24.VIP专属头像(根据VIP等级变换)\n25.VIP标示"),
				lang:GetText("1.完成每日、每周任务可额外获得100%奖励（下一级110%）\n2.过关结算可获得额外150%经验、C币加成（下一级160%）\n3.额外的强化成功率+15%（下一级+20%）\n4.解锁强化等级至14（下一级15）\n5.拼图开始时直接点亮4张（下一级5张）\n6.VIP商城加入更多精彩道具 \n7.免费兑换加入更多精彩道具 \n8.开启VIP箱权利\n9.过关结算时可以多3次翻牌的机会（下一级4次）\n10.中途退出游戏可保留正常游戏的收益\n11.离开战队会保留50%的贡献值（下一级60%）\n12.每日战队战贡献上限增加400\n13.为战队充能战队会多获得100%的战队经验（下一级110%）\n14.为战队充能会多获得100%的贡献值（下一级110%）\n15.在线奖励时间周期缩短一半\n16.大幅增加改装成功率\n17.可获得免费补签和提前签到机会（共5次，下一级6次）\n18.熔能无限制\n19.增加游戏内每日踢人次数1次\n20.每天可猜数字3个\n21.游戏中TAB，游戏房间内、排行榜的VIP等级缎带更加绚丽\n23.VIP专属名片\n24.VIP专属头像(根据VIP等级变换)\n25.VIP标示"),
				lang:GetText("1.完成每日、每周任务可额外获得110%奖励（下一级120%）\n2.过关结算可获得额外160%经验、C币加成（下一级180%）\n3.额外的强化成功率+20% \n4.解锁强化等级至15（下一级16）\n5.拼图开始时直接点亮5张 \n6.VIP商城加入更多精彩道具 \n7.免费兑换加入更多精彩道具 \n8.开启VIP箱权利\n9.过关结算时可以多4次翻牌的机会 \n10.中途退出游戏可保留正常游戏的收益\n11.离开战队会保留60%的贡献值 \n12.每日战队战贡献上限增加400\n13.为战队充能战队会多获得110%的战队经验（下一级120%）\n14.为战队充能会多获得110%的贡献值（下一级120%）\n15.在线奖励时间周期缩短一半\n16.大幅增加改装成功率\n17.可获得免费补签和提前签到机会（共6次）\n18.熔能无限制\n19.增加游戏内每日踢人次数1次\n20.每天可猜数字3个\n21.游戏中TAB，游戏房间内、排行榜的VIP等级缎带更加绚丽\n23.VIP专属名片\n24.VIP专属头像(根据VIP等级变换)\n25.银钻VIP尊贵皇冠标示 "),
				lang:GetText("1.完成每日、每周任务可额外获得120%奖励 \n2.过关结算可获得额外180%经验、C币加成 \n3.额外的强化成功率+20% \n4.解锁强化等级至16 \n5.拼图开始时直接点亮5张 \n6.VIP商城加入更多精彩道具 \n7.免费兑换加入更多精彩道具 \n8.开启VIP箱权利\n9.过关结算时可以多4次翻牌的机会 \n10.中途退出游戏可保留正常游戏的收益\n11.离开战队会保留60%的贡献值 \n12.每日战队战贡献上限增加400\n14.为战队充能战多获得120%的战队经验 \n14.为战队充能会多获得120%的贡献值 \n15.在线奖励时间周期缩短一半\n16.大幅增加改装成功率\n17.可获得免费补签和提前签到机会（共6次）\n18.熔能无限制\n19.增加游戏内每日踢人次数1次\n20.每天可猜数字3个\n21.游戏中TAB，游戏房间内、排行榜的VIP等级缎带更加绚丽\n23.VIP专属名片\n24.VIP专属头像(根据VIP等级变换)\n25.金钻VIP尊贵皇冠标示\n26.指定VIP经验可领取金钻尊享武器、服饰箱"),
				}
vip_next = {
				lang:GetText("1.完成每日、每周任务可额外获得50%奖励（下一级60%）\n2.过关结算可获得额外50%经验、C币加成（下一级70%）\n3.额外的强化成功率+5%\n4.免费兑换加入更多精彩道具 \n5.开启VIP箱权利\n6.过关结算时可以多1次翻牌的机会\n7.中途退出游戏可保留正常游戏的收益\n8.离开战队会保留30%的贡献值\n9.每日战队战贡献上限增加100\n10.为战队充能战队会多获得50%的战队经验（下一级60%）\n11.为战队充能会多获得50%的贡献值（下一级60%）\n12.在线奖励时间周期缩短一半\n13.增加改装成功率\n14.可获得免费补签和提前签到机会共3次\n15.增加游戏内每日踢人次数1次\n16.每天可猜数字3个\n17.游戏中TAB，游戏房间内、排行榜的VIP等级缎带更加绚丽\n23.VIP专属名片\n20.VIP专属头像(根据VIP等级变换)\n21.VIP标示"),
				lang:GetText("\n1.VIP商城加入更多精彩道具 "),
				lang:GetText("\n1.拼图开始时直接点亮3张"),
				lang:GetText("\n1.熔能无限制"),
				lang:GetText("\n1.解锁强化等级至13"),
				lang:GetText("\n1.解锁强化等级至14"),
				lang:GetText("\n1.银钻vip尊贵皇冠标帜\n2.解锁强化等级至15"),
				lang:GetText("\n1.金钻vip尊贵皇冠标帜\n2.指定经验点可领取金钻尊享武器或服装\n3.解锁强化等级至16"),
				"",
				}
local vip_level = 0
local pay_id = 1
tempData = nil
vip_exp = {0,18240,52800,115840,216000,361920,562240,825600,24420600}
vip_box_exp = {1475600,2125600,2883933,3642266,4552266,5462266,6599766,7737266,9253933,10770600,13045600,15320600,19870600,24420600}

preVipLevel = 0
preVipExp = 0
Viplevel = 0
Vipexp = 0
VipDay = 0
-- num = vip_exp[5]
now_box = 1
VipShow = Gui.Create()
{
	Gui.Control "root"
	{
		Size = Vector2(1000, 827),
		Dock = "kDockCenter",
		BackgroundColor = ARGB(0, 255, 255, 255),
		Gui.Control
		{
			Size = Vector2(900, 727),
			Dock = "kDockCenter",
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_contact_bg1_01.dds", Vector4(163,163,53,53)),
			},
			Gui.Control
			{							
				Size = Vector2(858, 674),
				Location = Vector2(19, 26),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg3.dds", Vector4(22, 22, 22, 22)),
				},
				Gui.Label
				{
					Size = Vector2(300, 30),
					Location = Vector2(10, 10),
					BackgroundColor = ARGB(0, 255, 255, 255),
					Text = lang:GetText("您现在的VIP等级："),
					FontSize = 22,
					TextAlign = "kAlignLeftMiddle",
					TextColor = ARGB(255, 255, 205, 69),
				},
				Gui.Label "next_exp"
				{
					Size = Vector2(300, 30),
					Location = Vector2(548, 10),
					BackgroundColor = ARGB(0, 255, 255, 255),
					Text = lang:GetText("距离下一级：30000"),
					FontSize = 22,
					TextAlign = "kAlignRightMiddle",
					TextColor = ARGB(255, 255, 205, 69),
				},
				Gui.Control
				{
					Size = Vector2(835,195),
					Location = Vector2(11, 46),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_task_bg_6.dds", Vector4(50, 50, 50, 50)),
					},
					Gui.Control
					{
						Size = Vector2(390,163),
						Location = Vector2(14, 17),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_contact_bg_normal.dds", Vector4(20, 20, 20, 20)),
						},
						Gui.Control
						{
							Size = Vector2(382,27),
							Location = Vector2(4, 4),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/vip/vip/lb_VIP_interface_bg01.dds", Vector4(57, 0, 148, 0)),
							},
							Gui.Label "now_exp"
							{
								Size = Vector2(300, 27),
								Location = Vector2(20, 0),
								BackgroundColor = ARGB(0, 255, 255, 255),
								Text = lang:GetText("VIP经验：800"),
								FontSize = 22,
								TextAlign = "kAlignLeftMiddle",
								TextColor = ARGB(255, 0, 0, 0),
							},
						},
						
						Gui.Control "Vip0_exp" 
						{
							Size = Vector2(382,125),
							Location = Vector2(4, 34),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Visible = true,
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/vip/vip/lb_VIP_interface_bg03.dds", Vector4(0, 0, 0, 0)),
							},
							Gui.Label
							{
								Size = Vector2(382, 125),
								Location = Vector2(0, 0),
								BackgroundColor = ARGB(0, 255, 255, 255),
								Text = lang:GetText("购买并使用VIP道具立即成为VIP1，\n享受豪华VIP特权"),
								FontSize = 22,
								TextAlign = "kAlignCenterMiddle",
								TextColor = ARGB(255, 255, 205, 69),
							},
						},
						
						Gui.Control "VipOther_exp" 
						{
							Size = Vector2(382,125),
							Location = Vector2(4, 34),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Visible = false,
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/vip/vip/lb_VIP_interface_bg03.dds", Vector4(0, 0, 0, 0)),
							},
							
							-- Gui.Label "lv0_des"
							-- {
								-- Size = Vector2(300, 20),
								-- Location = Vector2(41, 37),
								-- BackgroundColor = ARGB(0, 255, 255, 255),
								-- Text = lang:GetText("请先购买VIP"),
								-- FontSize = 16,
								-- TextAlign = "kAlignCenterMiddle",
								-- TextColor = ARGB(255, 255, 205, 69),
								-- Visible = false,
							-- },

							Gui.Control
							{
								Size = Vector2(300,25),
								Location = Vector2(41, 57),
								BackgroundColor = ARGB(255, 255, 255, 255),
								Skin = Gui.ControlSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/vip/vip/lb_VIP_scrollbar_slider.dds", Vector4(10, 10, 20, 10)),
								},
								Gui.Control "exp_bar"
								{
									Size = Vector2(0,25),
									Location = Vector2(0, 0),
									BackgroundColor = ARGB(255, 255, 255, 255),
									Skin = Gui.ControlSkin
									{
										BackgroundImage = Gui.Image("LobbyUI/vip/vip/lb_VIP_scrollbar_bg.dds", Vector4(10, 10, 20, 10)),
									},
								},
							},

							Gui.Control "plan_now"
							{
								Location = Vector2(41-9, 40),
								Size = Vector2(17,10),
								BackgroundColor = ARGB(255,255,255,255),
								Skin = Gui.ControlSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/vip/vip/lb_VIP_icon_plan.dds", Vector4(0, 0, 0, 0)),
								},
							},
							Gui.Label "c_VIP_now_exp"
							{
								Size = Vector2(90, 27),
								Location = Vector2(38-30-10, 10),
								BackgroundColor = ARGB(0, 255, 255, 255),
								Text = lang:GetText("114000"),
								FontSize = 22,
								TextAlign = "kAlignCenterMiddle",
								TextColor = ARGB(255, 255, 205, 69),
							},
							Gui.Control "c_VIP_now"
							{
								Location = Vector2(0, 72),
								Size = Vector2(76,42),
								BackgroundColor = ARGB(255,255,255,255),
								Skin = Gui.ControlSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_bg_02.dds", Vector4(0, 0, 0, 0)),
								},
								Gui.Control "c_VIP_now_num"
								{
									Location = Vector2(24, 17),
									Size = Vector2(27, 16),
									BackgroundColor = ARGB(255,255,255,255),
									Skin = Gui.ControlSkin
									{
										BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_button_02_normal.dds", Vector4(0, 0, 0, 0)),
									},
								},
							},
							Gui.Control "plan_next"
							{
								Location = Vector2(341-15, 40),
								Size = Vector2(17,10),
								BackgroundColor = ARGB(255,255,255,255),
								Skin = Gui.ControlSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/vip/vip/lb_VIP_icon_plan.dds", Vector4(0, 0, 0, 0)),
								},
							},
							-- Gui.Control "plan_box"
							-- {
								-- Location = Vector2(341-15, 40),
								-- Size = Vector2(17,10),
								-- BackgroundColor = ARGB(255,255,255,255),
								-- Skin = Gui.ControlSkin
								-- {
									-- BackgroundImage = Gui.Image("LobbyUI/vip/vip/lb_VIP_icon_plan.dds", Vector4(0, 0, 0, 0)),
								-- },
							-- },
							Gui.Label "l_get_exp"
							{
								Size = Vector2(300, 27),
								Location = Vector2(180, 10),
								BackgroundColor = ARGB(0, 255, 255, 255),
								Text = lang:GetText("领取经验："),
								FontSize = 20,
								TextAlign = "kAlignLeftMiddle",
								TextColor = ARGB(255, 255, 205, 69),
							},
							Gui.Label "c_VIP_next_exp"
							{
								Size = Vector2(90, 27),
								Location = Vector2(341-45-10, 10),
								BackgroundColor = ARGB(0, 255, 255, 255),
								Text = lang:GetText("91200"),
								FontSize = 22,
								TextAlign = "kAlignCenterMiddle",
								TextColor = ARGB(255, 255, 205, 69),
							},
							Gui.Control "c_VIP_next"
							{
								Location = Vector2(341-45, 72),
								Size = Vector2(76,42),
								BackgroundColor = ARGB(255,255,255,255),
								Skin = Gui.ControlSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_bg_03.dds", Vector4(0, 0, 0, 0)),
								},
								Gui.Control "c_VIP_next_num"
								{
									Location = Vector2(24, 17),
									Size = Vector2(27, 16),
									BackgroundColor = ARGB(255,255,255,255),
									Skin = Gui.ControlSkin
									{
										BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_button_03_normal.dds", Vector4(0, 0, 0, 0)),
									},
								},
							},
							Gui.Label "l_get_box"
							{
								Size = Vector2(300, 27),
								Location = Vector2(160, 82),
								BackgroundColor = ARGB(0, 255, 255, 255),
								Text = lang:GetText("金钻专享武器"),
								FontSize = 20,
								TextAlign = "kAlignLeftMiddle",
								TextColor = ARGB(255, 255, 205, 69),
							},
						},
					},
					Gui.Control
					{
						Size = Vector2(400,120),
						Location = Vector2(417, 17),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_contact_bg_normal.dds", Vector4(20, 20, 20, 20)),
						},
						Gui.Control
						{
							Size = Vector2(392,27),
							Location = Vector2(4, 4),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/vip/vip/lb_VIP_interface_bg01.dds", Vector4(57, 0, 148, 0)),
							},
							Gui.Label
							{
								Size = Vector2(300, 27),
								Location = Vector2(20, 0),
								BackgroundColor = ARGB(0, 255, 255, 255),
								Text = lang:GetText("VIP等级说明："),
								FontSize = 22,
								TextAlign = "kAlignLeftMiddle",
								TextColor = ARGB(255, 0, 0, 0),
							},
						},
						Gui.Control
						{
							Size = Vector2(392,82),
							Location = Vector2(4, 34),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/vip/vip/lb_VIP_interface_bg02.dds", Vector4(20, 20, 20, 20)),
							},

							Gui.TextArea "shuoming"
							{
								Readonly = true,
								Size = Vector2(392, 82),
								Location = Vector2(0, 0),
								Text = lang:GetText("1.玩家每升一级VIP等级都会新增更多的收益和权限\n2.未激活VIP或VIP期限到期将无法通过游戏手段获得VIP经验\n3.玩家每天领取签到奖励、在线时长奖励；完成每日任务；\n充值FC点；购买VIP经验道具都可获得VIP经验（VIP0时充值FC点仍可以积累VIP经验）"),
								FontSize = 18,
								Fold = true,
								TextColor = ARGB(255, 255, 255, 255),
								VScrollBarWidth = 10,
								VScrollBarButtonSize = 0,
								Skin = Gui.ScrollableControlSkin
								{
									VSliderNormalImage = Gui.Image("LobbyUI/team/NewFight/lb_common_scrollbar_02_slider.dds", Vector4(5, 5, 5, 5)),
									VSliderHoverImage = Gui.Image("LobbyUI/team/NewFight/lb_common_scrollbar_02_slider.dds", Vector4(5, 5, 5, 5)),
									VSliderDownImage = Gui.Image("LobbyUI/team/NewFight/lb_common_scrollbar_02_slider.dds", Vector4(5, 5, 5, 5)),
									VSliderDisabledImage = nil,
									
									VBarBackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_common_scrollbar_02_bg.dds", Vector4(5, 5, 5, 5)),
									VBarDisabledBackgroundImage = nil,
									BarCornerImage = nil,
								},
							},
							
						},
					},
					Gui.Control
					{
						Size = Vector2(265,35),
						Location = Vector2(417, 145),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/vip/vip/lb_VIP_text_bg.dds", Vector4(10, 10, 10, 10)),
						},
						Gui.Label "vip_state"
						{
							Size = Vector2(300, 35),
							Location = Vector2(10, 0),
							BackgroundColor = ARGB(0, 255, 255, 255),
							Text = lang:GetText("您还未激活高级VIP状态"),
							FontSize = 22,
							TextAlign = "kAlignLeftMiddle",
							TextColor = ARGB(255, 255, 187, 0),
						},
					},
					Gui.Button "quick_buy"
					{
						Location = Vector2(681, 141),
						Size = Vector2(128, 40),
						BackgroundColor = ARGB(255,255,255,255),
						Text = lang:GetText("快速激活"),
						TextAlign = "kAlignCenterMiddle",
						TextColor = ARGB(255,50,50,50),
						HighlightTextColor = ARGB(255, 50 ,50 ,50),
						Padding = Vector4(0, 0, 0, 5),
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/lb_common_up_button_normal.dds", Vector4(20, 20, 20, 20)),
							HoverImage = Gui.Image("LobbyUI/lb_common_up_button_hover.dds", Vector4(20, 20, 20, 20)),
							DownImage = Gui.Image("LobbyUI/lb_common_up_button_down.dds", Vector4(20, 20, 20, 20)),
							DisabledImage = Gui.Image("LobbyUI/lb_common_up_button_disabled.dds", Vector4(20, 20, 20, 20)),			
						},
						EventClick = function()
							ShowRapidShoppingWin()
							FillRapidShoppingWin()
						end
					},
				},
				Gui.Control
				{
					Size = Vector2(834,421),
					Location = Vector2(11, 242),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_task_bg_6.dds", Vector4(50, 50, 50, 50)),
					},
					Gui.Control
					{
						Size = Vector2(546,353),
						Location = Vector2(14, 8),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_contact_bg_normal.dds", Vector4(20, 20, 20, 20)),
						},
						Gui.Control "vip_card"
						{
							Size = Vector2(342,40),
							Location = Vector2(8, 18),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/vip/vip/vip1.dds", Vector4(20, 20, 20, 20)),
							},
						},
						
						Gui.Control "ctr_VIP_2"
						{
							Location = Vector2(8, -5),
							Size = Vector2(142,77),
							BackgroundColor = ARGB(255,255,255,255),
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_bg_01.dds", Vector4(0, 0, 0, 0)),
							},
							Gui.Control "ctr_VIP_num2"
							{
								Location = Vector2(44, 30),
								Size = Vector2(50, 29),
								BackgroundColor = ARGB(255,255,255,255),
								Skin = Gui.ControlSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_button_01_normal.dds", Vector4(0, 0, 0, 0)),
								},
							},
						},
						
						Gui.Control
						{
							Size = Vector2(534, 273),
							Location = Vector2(7, 67),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_contact_bg_normal.dds", Vector4(20, 20, 20, 20)),
							},
							Gui.Control
							{
								Size = Vector2(534, 273),
								Location = Vector2(0, 0),
								BackgroundColor = ARGB(255, 255, 255, 255),
								Skin = Gui.ControlSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/Compose/lb_melting_bg_cwlb.dds", Vector4(0,0,0,0)),
								},
								Gui.TextArea "jieshao"
								{
									Readonly = true,
									Size = Vector2(534, 273),
									Location = Vector2(0, 0),
									Text = vip_des[1],
									FontSize = 16,
									Fold = true,
									TextColor = ARGB(255, 255, 255, 255),
									VScrollBarWidth = 10,
									VScrollBarButtonSize = 0,
									Skin = Gui.ScrollableControlSkin
									{
										VSliderNormalImage = Gui.Image("LobbyUI/team/NewFight/lb_common_scrollbar_02_slider.dds", Vector4(5, 5, 5, 5)),
										VSliderHoverImage = Gui.Image("LobbyUI/team/NewFight/lb_common_scrollbar_02_slider.dds", Vector4(5, 5, 5, 5)),
										VSliderDownImage = Gui.Image("LobbyUI/team/NewFight/lb_common_scrollbar_02_slider.dds", Vector4(5, 5, 5, 5)),
										VSliderDisabledImage = nil,
										
										VBarBackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_common_scrollbar_02_bg.dds", Vector4(5, 5, 5, 5)),
										VBarDisabledBackgroundImage = nil,
										BarCornerImage = nil,
									},
								},
							},
						},
					},
					Gui.Control
					{
						Size = Vector2(259,314),
						Location = Vector2(563, 8),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_contact_bg_normal.dds", Vector4(20, 20, 20, 20)),
						},
						Gui.Control
						{
							Size = Vector2(251,27),
							Location = Vector2(4, 4),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/vip/vip/lb_VIP_interface_bg01.dds", Vector4(57, 0, 148, 0)),
							},
							Gui.Label "lb_vip_next"
							{
								Size = Vector2(300, 27),
								Location = Vector2(20, 0),
								BackgroundColor = ARGB(0, 255, 255, 255),
								Text = lang:GetText("下一级"),
								FontSize = 22,
								TextAlign = "kAlignLeftMiddle",
								TextColor = ARGB(255, 0, 0, 0),
							},
						},
						Gui.Control
						{
							Size = Vector2(245, 267),
							Location = Vector2(7, 35),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_contact_bg_normal.dds", Vector4(20, 20, 20, 20)),
							},
							-- Gui.Control "vip0_shuoming"
							-- {
								-- Size = Vector2(245, 267),
								-- Location = Vector2(0, 0),
								-- BackgroundColor = ARGB(255, 255, 255, 255),
								-- Visible = true,
								-- Skin = Gui.ControlSkin
								-- {
									-- BackgroundImage = Gui.Image("LobbyUI/Compose/lb_melting_bg_cwlb.dds", Vector4(0,0,0,0)),
								-- },
								
								-- Gui.Control
								-- {
									-- Location = Vector2(15, 9),
									-- Size = Vector2(100, 55),
									-- BackgroundColor = ARGB(255,255,255,255),
									-- Skin = Gui.ControlSkin
									-- {
										-- BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_bg_01.dds", Vector4(0, 0, 0, 0)),
									-- },
									-- Gui.Control
									-- {
										-- Location = Vector2(34, 23),
										-- Size = Vector2(29, 18),
										-- BackgroundColor = ARGB(255,255,255,255),
										-- Skin = Gui.ControlSkin
										-- {
											-- BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_button_01_normal.dds", Vector4(0, 0, 0, 0)),
										-- },
									-- },
								-- },
								
								-- Gui.Control
								-- {
									-- Location = Vector2(130, 9),
									-- Size = Vector2(100, 55),
									-- BackgroundColor = ARGB(255,255,255,255),
									-- Skin = Gui.ControlSkin
									-- {
										-- BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_bg_02.dds", Vector4(0, 0, 0, 0)),
									-- },
									-- Gui.Control
									-- {
										-- Location = Vector2(34, 23),
										-- Size = Vector2(29, 18),
										-- BackgroundColor = ARGB(255,255,255,255),
										-- Skin = Gui.ControlSkin
										-- {
											-- BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_button_02_normal.dds", Vector4(0, 0, 0, 0)),
										-- },
									-- },
								-- },
								
								-- Gui.Control
								-- {
									-- Location = Vector2(15, 73),
									-- Size = Vector2(100, 55),
									-- BackgroundColor = ARGB(255,255,255,255),
									-- Skin = Gui.ControlSkin
									-- {
										-- BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_bg_03.dds", Vector4(0, 0, 0, 0)),
									-- },
									-- Gui.Control
									-- {
										-- Location = Vector2(34, 23),
										-- Size = Vector2(29, 18),
										-- BackgroundColor = ARGB(255,255,255,255),
										-- Skin = Gui.ControlSkin
										-- {
											-- BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_button_03_normal.dds", Vector4(0, 0, 0, 0)),
										-- },
									-- },
								-- },
								-- Gui.Control
								-- {
									-- Location = Vector2(130, 73),
									-- Size = Vector2(100, 55),
									-- BackgroundColor = ARGB(255,255,255,255),
									-- Skin = Gui.ControlSkin
									-- {
										-- BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_bg_04.dds", Vector4(0, 0, 0, 0)),
									-- },
									-- Gui.Control
									-- {
										-- Location = Vector2(34, 23),
										-- Size = Vector2(29, 18),
										-- BackgroundColor = ARGB(255,255,255,255),
										-- Skin = Gui.ControlSkin
										-- {
											-- BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_button_04_normal.dds", Vector4(0, 0, 0, 0)),
										-- },
									-- },
								-- },
								-- Gui.Control
								-- {
									-- Location = Vector2(15, 137),
									-- Size = Vector2(100, 55),
									-- BackgroundColor = ARGB(255,255,255,255),
									-- Skin = Gui.ControlSkin
									-- {
										-- BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_bg_05.dds", Vector4(0, 0, 0, 0)),
									-- },
									-- Gui.Control
									-- {
										-- Location = Vector2(34, 23),
										-- Size = Vector2(29, 18),
										-- BackgroundColor = ARGB(255,255,255,255),
										-- Skin = Gui.ControlSkin
										-- {
											-- BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_button_05_normal.dds", Vector4(0, 0, 0, 0)),
										-- },
									-- },
								-- },
								-- Gui.Control
								-- {
									-- Location = Vector2(130, 137),
									-- Size = Vector2(100, 55),
									-- BackgroundColor = ARGB(255,255,255,255),
									-- Skin = Gui.ControlSkin
									-- {
										-- BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_bg_06.dds", Vector4(0, 0, 0, 0)),
									-- },
									-- Gui.Control
									-- {
										-- Location = Vector2(34, 23),
										-- Size = Vector2(29, 18),
										-- BackgroundColor = ARGB(255,255,255,255),
										-- Skin = Gui.ControlSkin
										-- {
											-- BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_button_06_normal.dds", Vector4(0, 0, 0, 0)),
										-- },
									-- },
								-- },
								-- Gui.Control
								-- {
									-- Location = Vector2(15, 201),
									-- Size = Vector2(100, 55),
									-- BackgroundColor = ARGB(255,255,255,255),
									-- Skin = Gui.ControlSkin
									-- {
										-- BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_bg_07.dds", Vector4(0, 0, 0, 0)),
									-- },
									-- Gui.Control
									-- {
										-- Location = Vector2(34, 23),
										-- Size = Vector2(29, 18),
										-- BackgroundColor = ARGB(255,255,255,255),
										-- Skin = Gui.ControlSkin
										-- {
											-- BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_button_07_normal.dds", Vector4(0, 0, 0, 0)),
										-- },
									-- },
								-- },
								-- Gui.Control
								-- {
									-- Location = Vector2(130, 201),
									-- Size = Vector2(100, 55),
									-- BackgroundColor = ARGB(255,255,255,255),
									-- Skin = Gui.ControlSkin
									-- {
										-- BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_bg_08.dds", Vector4(0, 0, 0, 0)),
									-- },
									-- Gui.Control
									-- {
										-- Location = Vector2(34, 23),
										-- Size = Vector2(29, 18),
										-- BackgroundColor = ARGB(255,255,255,255),
										-- Skin = Gui.ControlSkin
										-- {
											-- BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_button_08_normal.dds", Vector4(0, 0, 0, 0)),
										-- },
									-- },
								-- },
							-- },
							Gui.Control "vipOther_shuoming"
							{
								Size = Vector2(245, 267),
								Location = Vector2(0, 0),
								BackgroundColor = ARGB(255, 255, 255, 255),
								Visible = false,
								Skin = Gui.ControlSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/Compose/lb_melting_bg_cwlb.dds", Vector4(0,0,0,0)),
								},
								Gui.Control "ctr_VIP_next"
								{
									Location = Vector2(51, 20),
									Size = Vector2(142, 77),
									BackgroundColor = ARGB(255,255,255,255),
									Skin = Gui.ControlSkin
									{
										BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_bg_06.dds", Vector4(0, 0, 0, 0)),
									},
									Gui.Control "ctr_VIP_num_next"
									{
										Location = Vector2(44, 30),
										Size = Vector2(50, 29),
										BackgroundColor = ARGB(255,255,255,255),
										Skin = Gui.ControlSkin
										{
											BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_button_06_normal.dds", Vector4(0, 0, 0, 0)),
										},
									},
								},
								Gui.TextArea "next_jieshao"
								{
									Readonly = true,
									Size = Vector2(245, 167),
									Location = Vector2(0, 90),
									Text = vip_next[1],
									FontSize = 16,
									Fold = true,
									TextColor = ARGB(255, 255, 255, 255),
									VScrollBarWidth = 10,
									VScrollBarButtonSize = 0,
									Skin = Gui.ScrollableControlSkin
									{
										VSliderNormalImage = Gui.Image("LobbyUI/team/NewFight/lb_common_scrollbar_02_slider.dds", Vector4(5, 5, 5, 5)),
										VSliderHoverImage = Gui.Image("LobbyUI/team/NewFight/lb_common_scrollbar_02_slider.dds", Vector4(5, 5, 5, 5)),
										VSliderDownImage = Gui.Image("LobbyUI/team/NewFight/lb_common_scrollbar_02_slider.dds", Vector4(5, 5, 5, 5)),
										VSliderDisabledImage = nil,
										
										VBarBackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_common_scrollbar_02_bg.dds", Vector4(5, 5, 5, 5)),
										VBarDisabledBackgroundImage = nil,
										BarCornerImage = nil,
									},
								},
							},
						},
					},

					Gui.Control
					{
						Size = Vector2(265,35),
						Location = Vector2(563, 331),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/vip/vip/lb_VIP_text_bg.dds", Vector4(10, 10, 10, 10)),
						},
						Gui.Label "left_day"
						{
							Size = Vector2(259, 35),
							Location = Vector2(20, 0),
							BackgroundColor = ARGB(0, 255, 255, 255),
							Text = lang:GetText("剩余天数0天"),
							FontSize = 18,
							TextAlign = "kAlignLeftMiddle",
							TextColor = ARGB(255, 255, 187, 0),
						},
					},
					
					Gui.Control "ctrl_bottom_container"
					{							
						Size = Vector2(135, 52),
						Location = Vector2(350, 360),
						BackgroundColor = ARGB(0, 255, 255, 255),

						--上一页
						Gui.Button "btn_front_page"
						{
							Size = Vector2(14, 31),
							Location = Vector2(1, 9),
							--Text = "<",
							TextColor = ARGB(255, 255, 246, 235),
							FontSize = 18,
							Skin = Gui.ButtonSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/vip/vip/lb_shop_button05_normal.dds", Vector4(0, 0, 0, 0)),
								HoverImage = Gui.Image("LobbyUI/vip/vip/lb_shop_button05_hover.dds", Vector4(0, 0, 0, 0)),
								DownImage = Gui.Image("LobbyUI/vip/vip/lb_shop_button05_down.dds", Vector4(0, 0, 0, 0)),
								DisabledImage = Gui.Image("LobbyUI/vip/vip/lb_shop_button05_normal.dds", Vector4(0, 0, 0, 0)),
							},
							EventClick = function()
								if vip_level > 0 then
									vip_level = vip_level-1
									VipShow.jieshao.Text = vip_des[vip_level+1]
									VipShow.next_jieshao.Text = vip_next[vip_level+1]
									VipShow.lb_page_number.Text = (vip_level+1).."/"..(VipMaxlevel)
									VipShow.ctr_VIP_next.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_bg_0"..(vip_level+1)..".dds", Vector4(0, 0, 0, 0)),}
									VipShow.ctr_VIP_num_next.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_button_0"..(vip_level+1).."_normal.dds", Vector4(0, 0, 0, 0)),}
									VipShow.ctr_VIP_2.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_bg_0"..vip_level..".dds", Vector4(0, 0, 0, 0)),}
									VipShow.ctr_VIP_num2.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_button_0"..vip_level.."_normal.dds", Vector4(0, 0, 0, 0)),}
									VipShow.vip_card.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/vip/vip/vip"..vip_level..".dds", Vector4(20, 20, 20, 20)),}
								end
							end
						},
						
						--页码
						Gui.Label "lb_page_number"
						{
							Location = Vector2(30, 9),
							Size = Vector2(75, 31),
							FontSize = 24,
							TextAlign = "kAlignCenterMiddle",
							TextColor = ARGB(255, 103, 102, 98),
							Text = "1/"..(VipMaxlevel),
							BackgroundColor = ARGB(255, 255, 255, 255),

							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button06_bg.dds", Vector4(14, 14, 14, 14)),
							},
						},

						--下一页
						Gui.Button "btn_next_page"
						{
							Size = Vector2(14, 31),
							Location = Vector2(120, 9),
							--Text = ">",
							TextColor = ARGB(255, 255, 246, 235),
							FontSize = 18,
							Skin = Gui.ButtonSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/vip/vip/lb_shop_button06_normal.dds", Vector4(0, 0, 0, 0)),
								HoverImage = Gui.Image("LobbyUI/vip/vip/lb_shop_button06_hover.dds", Vector4(0, 0, 0, 0)),
								DownImage = Gui.Image("LobbyUI/vip/vip/lb_shop_button06_down.dds", Vector4(0, 0, 0, 0)),
								DisabledImage = Gui.Image("LobbyUI/vip/vip/lb_shop_button06_normal.dds", Vector4(0, 0, 0, 0)),
							},
							EventClick = function()
								if vip_level < VipMaxlevel-1  then
									vip_level = vip_level+1
									VipShow.jieshao.Text = vip_des[vip_level+1]
									VipShow.next_jieshao.Text = vip_next[vip_level+1]
									VipShow.lb_page_number.Text = (vip_level+1).."/"..(VipMaxlevel)
									if vip_level < (VipMaxlevel-1) then
										VipShow.ctr_VIP_next.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_bg_0"..(vip_level+1)..".dds", Vector4(0, 0, 0, 0)),}
										VipShow.ctr_VIP_num_next.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_button_0"..(vip_level+1).."_normal.dds", Vector4(0, 0, 0, 0)),}
									else
										VipShow.ctr_VIP_next.Skin = Gui.ControlSkin{BackgroundImage = nil,}
										VipShow.ctr_VIP_num_next.Skin = Gui.ControlSkin{BackgroundImage = nil,}
									end
									VipShow.ctr_VIP_2.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_bg_0"..vip_level..".dds", Vector4(0, 0, 0, 0)),}
									VipShow.ctr_VIP_num2.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_button_0"..vip_level.."_normal.dds", Vector4(0, 0, 0, 0)),}
									VipShow.vip_card.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/vip/vip/vip"..vip_level..".dds", Vector4(20, 20, 20, 20)),}
								end
							end
						},
					},
					Gui.Button "get_box"
					{
						Location = Vector2(563, 370),
						Size = Vector2(128, 40),
						BackgroundColor = ARGB(255,255,255,255),
						Text = lang:GetText("领取奖励"),
						TextAlign = "kAlignCenterMiddle",
						TextColor = ARGB(255,50,50,50),
						HighlightTextColor = ARGB(255, 50 ,50 ,50),
						Padding = Vector4(0, 0, 0, 5),
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/lb_common_up_button_normal.dds", Vector4(20, 20, 20, 20)),
							HoverImage = Gui.Image("LobbyUI/lb_common_up_button_hover.dds", Vector4(20, 20, 20, 20)),
							DownImage = Gui.Image("LobbyUI/lb_common_up_button_down.dds", Vector4(20, 20, 20, 20)),
							DisabledImage = Gui.Image("LobbyUI/lb_common_up_button_disabled.dds", Vector4(20, 20, 20, 20)),			
						},
						EventClick = function()
							rpc.safecallload("shop_vipexp_ex_buy", {pid = ptr_cast(game.CurrentState):GetCharacterId()},
							function (data)
								if data.errorMsg == nil then
									if now_box % 2 == 1 then
										MessageBox.ShowWithConfirm(lang:GetText("成功领取“金钻尊享武器多选一礼盒”"))
									else
										MessageBox.ShowWithConfirm(lang:GetText("成功领取“金钻尊享时装多选一礼盒”"))
									end
									Show_VipShow()
									L_LobbyMain.FillPersonalInfo()
								else
									MessageBox.ShowWithConfirm(data.errorMsg)
								end
							end)
						end
					},
				},
			},
			Gui.Control "ctr_VIP_1"
			{
				Location = Vector2(200, 10),
				Size = Vector2(142, 77),
				BackgroundColor = ARGB(255,255,255,255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_bg_06.dds", Vector4(0, 0, 0, 0)),
				},
				Gui.Control "ctr_VIP_num1"
				{
					Location = Vector2(44, 30),
					Size = Vector2(50, 29),
					BackgroundColor = ARGB(255,255,255,255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_button_06_normal.dds", Vector4(0, 0, 0, 0)),
					},
				},
			},
		},
		
		Gui.Button
		{
			Size = Vector2(48,48),
			Location = Vector2(916, 36),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_normal.dds", Vector4(10, 10, 10, 10)),
				HoverImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_hover.dds", Vector4(10, 10, 10, 10)),
				DownImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_down.dds", Vector4(10, 10, 10, 10)),
				DisabledImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_disabled.dds", Vector4(0, 0, 0, 0)),	
			},
			EventClick = function()
				Hide_VipShow()
			end,
		},
	},
}

--快速购买界面
local Rapid_Shopping_Win = 
{
	Gui.Control "Rapid_Shopping_root"
	{	
		Size = Vector2(1200, 900),
		BackgroundColor = ARGB(0, 255, 255, 255),
		Location = Vector2(0, 0),
		
		Gui.Control
		{	
			Size = Vector2(377, 395),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Dock = "kDockCenter",
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/main_bar01.dds", Vector4(20, 20, 20, 20)),
			},

			Gui.Control
			{	
				Size = Vector2(355, 372),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Location = Vector2(11, 12),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/main_bar02.dds", Vector4(8, 8, 8, 8)),
				},
				
				Gui.Label
				{
					Size = Vector2(353, 35),
					Location = Vector2(0, 0),
					TextColor = ARGB(255, 255, 210, 0),
					FontSize = 18,
					TextAlign = "kAlignLeftMiddle",
					Text = lang:GetText("快速购买"),
					BackgroundColor = ARGB(255,255,255,255),
					TextPadding = Vector4(8,0,0,8),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_onlinetime_bg_5.dds", Vector4(8, 8, 8, 8)),
					},
				},
				
				Gui.Control
				{	
					Size = Vector2(325, 280),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Location = Vector2(16, 39),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_01.dds", Vector4(40, 40, 40, 40)),
					},
					
					Gui.Control
					{	
						Size = Vector2(274, 228),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Location = Vector2(24, 10),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_06.dds", Vector4(32, 28, 32, 50)),
						},
						
						Gui.Label "name"
						{
							Size = Vector2(274, 28),
							Location = Vector2(0, 0),
							TextColor = ARGB(255, 255, 210, 0),
							FontSize = 18,
							TextAlign = "kAlignCenterMiddle",
							Text = lang:GetText("密码卡"),
							BackgroundColor = ARGB(0,255,255,255),
							TextPadding = Vector4(0,0,0,3),
						},
						
						Gui.TextArea "des"
						{
							Size = Vector2(244, 50),
							Location = Vector2(27, 105),
							TextColor = ARGB(255, 255, 210, 0),
							FontSize = 12,
							Readonly = true,
							Fold = true,
							BackgroundColor = ARGB(255,255,255,255),
						},
						
						Gui.Button "b_fc_1"
						{
							Size = Vector2(111,28),
							Location = Vector2(23, 160),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Text = lang:GetText("100FC/1天"),
							FontSize = 12,
							TextColor = ARGB(255, 255, 174, 0),
							HighlightTextColor = ARGB(255, 255, 174, 0),
							TextAlign = "kAlignCenterMiddle",
							Padding = Vector4(0, 0, 0, 5),
							Visible = false,
							PushDown = true,
							Skin = Gui.ButtonSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/Compose/lb_fastsettlement_button01_normal.dds", Vector4(20, 28, 6, 8)),
								HoverImage = Gui.Image("LobbyUI/Compose/lb_fastsettlement_button01_hover.dds", Vector4(20, 28, 6, 8)),
								DownImage = Gui.Image("LobbyUI/Compose/lb_manage_button_down.dds", Vector4(20, 28, 6, 8)),
								DisabledImage = Gui.Image("LobbyUI/Compose/lb_fastsettlement_button01_disabled.dds", Vector4(20, 28, 6, 8)),
							},
							EventClick = function()
								pay_id = 1
								Rapid_Shopping_Win_ui.b_fc_1.PushDown = true
								Rapid_Shopping_Win_ui.b_fc_2.PushDown = false
								Rapid_Shopping_Win_ui.b_fc_3.PushDown = false
								Rapid_Shopping_Win_ui.b_fc_4.PushDown = false
								Rapid_Shopping_Win_ui.Total_money.Text = tempData.crprices[1].cost
							end
						},
						Gui.Button "b_fc_2"
						{
							Size = Vector2(111,28),
							Location = Vector2(142, 160),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Text = lang:GetText("100FC/1天"),
							FontSize = 12,
							TextAlign = "kAlignCenterMiddle",
							TextColor = ARGB(255, 255, 174, 0),
							HighlightTextColor = ARGB(255, 255, 174, 0),
							Padding = Vector4(0, 0, 0, 5),
							Visible = false,
							Skin = Gui.ButtonSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/Compose/lb_fastsettlement_button01_normal.dds", Vector4(20, 28, 6, 8)),
								HoverImage = Gui.Image("LobbyUI/Compose/lb_fastsettlement_button01_hover.dds", Vector4(20, 28, 6, 8)),
								DownImage = Gui.Image("LobbyUI/Compose/lb_manage_button_down.dds", Vector4(20, 28, 6, 8)),
								DisabledImage = Gui.Image("LobbyUI/Compose/lb_fastsettlement_button01_disabled.dds", Vector4(20, 28, 6, 8)),
							},
							EventClick = function()
								pay_id = 2
								Rapid_Shopping_Win_ui.b_fc_1.PushDown = false
								Rapid_Shopping_Win_ui.b_fc_2.PushDown = true
								Rapid_Shopping_Win_ui.b_fc_3.PushDown = false
								Rapid_Shopping_Win_ui.b_fc_4.PushDown = false
								Rapid_Shopping_Win_ui.Total_money.Text = tempData.crprices[2].cost
							end
						},
						Gui.Button "b_fc_3"
						{
							Size = Vector2(111,28),
							Location = Vector2(23, 190),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Text = lang:GetText("100FC/1天"),
							FontSize = 12,
							TextAlign = "kAlignCenterMiddle",
							TextColor = ARGB(255, 255, 174, 0),
							HighlightTextColor = ARGB(255, 255, 174, 0),
							Padding = Vector4(0, 0, 0, 5),
							Visible = false,
							Skin = Gui.ButtonSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/Compose/lb_fastsettlement_button01_normal.dds", Vector4(20, 28, 6, 8)),
								HoverImage = Gui.Image("LobbyUI/Compose/lb_fastsettlement_button01_hover.dds", Vector4(20, 28, 6, 8)),
								DownImage = Gui.Image("LobbyUI/Compose/lb_manage_button_down.dds", Vector4(20, 28, 6, 8)),
								DisabledImage = Gui.Image("LobbyUI/Compose/lb_fastsettlement_button01_disabled.dds", Vector4(20, 28, 6, 8)),
							},
							EventClick = function()
								pay_id = 3
								Rapid_Shopping_Win_ui.b_fc_1.PushDown = false
								Rapid_Shopping_Win_ui.b_fc_2.PushDown = false
								Rapid_Shopping_Win_ui.b_fc_3.PushDown = true
								Rapid_Shopping_Win_ui.b_fc_4.PushDown = false
								Rapid_Shopping_Win_ui.Total_money.Text = tempData.crprices[3].cost
							end
						},
						Gui.Button "b_fc_4"
						{
							Size = Vector2(111,28),
							Location = Vector2(142, 190),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Text = lang:GetText("100FC/1天"),
							FontSize = 12,
							TextAlign = "kAlignCenterMiddle",
							TextColor = ARGB(255, 255, 174, 0),
							HighlightTextColor = ARGB(255, 255, 174, 0),
							Padding = Vector4(0, 0, 0, 5),
							Visible = false,
							Skin = Gui.ButtonSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/Compose/lb_fastsettlement_button01_normal.dds", Vector4(20, 28, 6, 8)),
								HoverImage = Gui.Image("LobbyUI/Compose/lb_fastsettlement_button01_hover.dds", Vector4(20, 28, 6, 8)),
								DownImage = Gui.Image("LobbyUI/Compose/lb_manage_button_down.dds", Vector4(20, 28, 6, 8)),
								DisabledImage = Gui.Image("LobbyUI/Compose/lb_fastsettlement_button01_disabled.dds", Vector4(20, 28, 6, 8)),
							},
							EventClick = function()
								pay_id = 4
								Rapid_Shopping_Win_ui.b_fc_1.PushDown = false
								Rapid_Shopping_Win_ui.b_fc_2.PushDown = false
								Rapid_Shopping_Win_ui.b_fc_3.PushDown = false
								Rapid_Shopping_Win_ui.b_fc_4.PushDown = true
								Rapid_Shopping_Win_ui.Total_money.Text = tempData.crprices[4].cost
							end
						},						
					},
					
					Gui.Label
					{
						Size = Vector2(110, 28),
						Location = Vector2(25, 240),
						TextColor = ARGB(255, 255, 210, 0),
						FontSize = 18,
						TextAlign = "kAlignCenterMiddle",
						Text = lang:GetText("您总共要支付"),
						BackgroundColor = ARGB(0,255,255,255),
						TextPadding = Vector4(0,0,0,3),
					},
					
					Gui.Label "Total_money"
					{
						Size = Vector2(118, 28),
						Location = Vector2(137, 240),
						TextColor = ARGB(255, 255, 210, 0),
						FontSize = 18,
						TextAlign = "kAlignCenterMiddle",
						Text = "0",
						BackgroundColor = ARGB(255,255,255,255),
						TextPadding = Vector4(0,0,0,3),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_03.dds", Vector4(8, 8, 8, 8)),
						},
					},
					
					Gui.Label
					{
						Size = Vector2(80, 28),
						Location = Vector2(257, 240),
						TextColor = ARGB(255, 255, 210, 0),
						FontSize = 18,
						TextAlign = "kAlignLeftMiddle",
						Text = lang:GetText("FC点"),
						BackgroundColor = ARGB(0,255,255,255),
						TextPadding = Vector4(0,0,0,3),
					},
				},
				
				Gui.Button "b_buy" 
				{
					Size = Vector2(124,44),
					Location = Vector2(113, 325),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Text = lang:GetText("购 买"),
					TextColor = ARGB(255, 229, 255, 252),
					TextAlign = "kAlignCenterMiddle",
					HighlightTextColor = ARGB(255, 229, 255, 252),
					Padding = Vector4(0, 0, 0, 5),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_onlinetime_button_2_normal.dds", Vector4(0, 0, 0, 0)),
						HoverImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_onlinetime_button_2_hover.dds", Vector4(0, 0, 0, 0)),
						DownImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_onlinetime_button_2_down.dds", Vector4(0, 0, 0, 0)),
						DisabledImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_onlinetime_button_2_disabled.dds", Vector4(0, 0, 0, 0)),
					},
					EventClick = function()
						L_LobbyMain.Buy_Goods(ptr_cast(game.CurrentState):GetUserId(), ptr_cast(game.CurrentState):GetCharacterId(), tempData.sid, 4, 1, tempData.crprices[pay_id].id, 1 , false)
						HideRapidShoppingWin()
					end,
				},
			},
		},
		
		Gui.ItemBoxBtn "itembox_hummer"
		{
			Style = "Gui.ItemBoxBtn_ib",
			Size = Vector2(153,79),
			Location = Vector2(522,343),--38 10
			BackgroundColor = ARGB(255,255,255,255),
			Skin = Gui.ItemBoxBtnSkin
			{
				NeutralNormalImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_02.dds", Vector4(0, 0, 0, 0)),
				--NeutralHoverImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_02.dds", Vector4(0, 0, 0, 0)),
				NeutralSelectedImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_02.dds", Vector4(0, 0, 0, 0)),
				NeutralDisabledImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_02.dds", Vector4(0, 0, 0, 0)),
			},
		},
		--退出
		Gui.Button
		{
			Size = Vector2(48,48),
			Location = Vector2(743, 250),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_normal.dds", Vector4(10, 10, 10, 10)),
				HoverImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_hover.dds", Vector4(10, 10, 10, 10)),
				DownImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_down.dds", Vector4(10, 10, 10, 10)),
				DisabledImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_disabled.dds", Vector4(0, 0, 0, 0)),	
			},
			EventClick = function()
				HideRapidShoppingWin()
			end,
		},
	},
}

function ShowRapidShoppingWin()
	if Rapid_Shopping_Win_ui == nil then
		Rapid_Shopping_Win_ui = Gui.Create()(Rapid_Shopping_Win)
		--快速购买界面初始化
		RapidShopping_Window = ModalWindow.GetNew("Rapid_Shopping_Win_ui")
		RapidShopping_Window.screen.AllowEscToExit = false
		RapidShopping_Window.screen.Visible = false
		--RapidShopping_Window.screen.EventEscPressed = HideCharmBottleWin
		RapidShopping_Window.screen.EventEscPressed = nil
		RapidShopping_Window.root.Size = Vector2(1200, 900)
		Rapid_Shopping_Win_ui.Rapid_Shopping_root.Parent = RapidShopping_Window.root
	end
	if RapidShopping_Window and RapidShopping_Window.screen then
		RapidShopping_Window.screen.Visible = true
		--gui.EventEscPressed = HideCharmBottleWin
		gui.EventEscPressed = nil
	end
end

function HideRapidShoppingWin()
	if RapidShopping_Window and RapidShopping_Window.screen then
		RapidShopping_Window.screen.Visible = false
		Rapid_Shopping_Win_ui = nil
	end
end

function FillRapidShoppingWin()
	Rapid_Shopping_Win_ui.name.Text = tempData.display
	Rapid_Shopping_Win_ui.des.Text = tempData.modified_desc
	Rapid_Shopping_Win_ui.itembox_hummer.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..tempData.name..".tga")
	for  j = 1, #tempData.crprices do
		Rapid_Shopping_Win_ui["b_fc_"..j].Visible = true
		Rapid_Shopping_Win_ui["b_fc_"..j].Text = tempData.crprices[j].cost.."FC/"..tempData.crprices[j].unit..lang:GetText("天")
		if Rapid_Shopping_Win_ui["b_fc_"..j].PushDown then
			Rapid_Shopping_Win_ui.Total_money.Text = tempData.crprices[j].cost
		end
	end
end

function Show_VipShow()
	if not VipShowmodel then
		VipShowmodel = ModalWindow.GetNew()
		VipShowmodel.root.Size = Vector2(1000,827)
		VipShowmodel.AllowEscToExit = false
		VipShow.root.Parent = VipShowmodel.root
	end
	rpc.safecallload("vip_info", {pid = ptr_cast(game.CurrentState):GetCharacterId()},
	function (data)
		tempData = data
		Vipexp = data.vipExp
		Viplevel = data.vipLevel
		now_box = data.currentyEXPItem + 1
		if Viplevel == 0 then
			vip_level = Viplevel
		else
			vip_level = Viplevel
		end
		
		if data.nextLevelExp ~= -1 and vip_level ~= 8 then
			VipShow.next_exp.Text = lang:GetText("距离下一级：")..(data.nextLevelExp-data.vipExp)
		elseif now_box == 15 then
			VipShow.next_exp.Text = lang:GetText("已达到最高级")
		elseif vip_level == 8 then
			local s = vip_box_exp[now_box] - Vipexp
			if s <= 0 then
				VipShow.next_exp.Text = lang:GetText("下一个宝箱需要经验：").."0"
			else
				VipShow.next_exp.Text = lang:GetText("下一个宝箱需要经验：")..s
			end
		else
			VipShow.next_exp.Text = lang:GetText("已达到最高级")
		end
		if Viplevel == 9 then
			Viplevel = 8
		end
		if vip_level == 9 then
			vip_level = 8
		end
		if Viplevel > 0 then
			VipShow.vip_state.Text = lang:GetText("您已经激活VIP状态")
			VipShow.vip_state.TextColor = ARGB(255, 255, 187, 0)
			if data.leftMins >= 0 then
				VipDay = math.floor(data.leftMins/60/24)
				VipShow.left_day.Text = lang:GetText("剩余天数")..VipDay..lang:GetText("天")
			else
				VipShow.left_day.Text = lang:GetText("已过期")
				VipShow.vip_state.Text = lang:GetText("您的VIP状态已过期")
				VipShow.vip_state.TextColor = ARGB(255, 255, 85, 45)
			end
		else
			VipShow.vip_state.Text = lang:GetText("您还未激活高级VIP状态")
			VipShow.vip_state.TextColor = ARGB(255, 255, 85, 45)
			VipShow.left_day.Text = lang:GetText("未激活")
		end
		
		VipShow.now_exp.Text = lang:GetText("VIP经验：")..data.vipExp
		print("vip_level:"..vip_level)
		VipShow.jieshao.Text = vip_des[vip_level+1]
		VipShow.next_jieshao.Text = vip_next[Viplevel+1]
		VipShow.lb_page_number.Text = (vip_level+1).."/"..(VipMaxlevel)
		if vip_level== 0 then
			VipShow.ctr_VIP_next.Skin = Gui.ControlSkin{BackgroundImage = nil,}
			VipShow.ctr_VIP_num_next.Skin = Gui.ControlSkin{BackgroundImage = nil,}
		else
			VipShow.ctr_VIP_next.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_bg_0"..(Viplevel+1)..".dds", Vector4(0, 0, 0, 0)),}
			VipShow.ctr_VIP_num_next.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_button_0"..(Viplevel+1).."_normal.dds", Vector4(0, 0, 0, 0)),}
		end	
		VipShow.ctr_VIP_2.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_bg_0"..vip_level..".dds", Vector4(0, 0, 0, 0)),}
		VipShow.ctr_VIP_num2.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_button_0"..vip_level.."_normal.dds", Vector4(0, 0, 0, 0)),}
		VipShow.vip_card.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/vip/vip/vip"..vip_level..".dds", Vector4(20, 20, 20, 20)),}
		VipShow.ctr_VIP_1.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_bg_0"..Viplevel..".dds", Vector4(0, 0, 0, 0)),}
		VipShow.ctr_VIP_num1.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_button_0"..Viplevel.."_normal.dds", Vector4(0, 0, 0, 0)),}
		if Viplevel == VipMaxlevel then
			VipShow.ctr_VIP_next.Skin = Gui.ControlSkin{BackgroundImage = nil,}
			VipShow.ctr_VIP_num_next.Skin = Gui.ControlSkin{BackgroundImage = nil,}
		end

		VipShow.plan_next.Visible = true
		VipShow.plan_now.Visible = true
		VipShow.c_VIP_now_exp.Visible = true
		VipShow.c_VIP_next_exp.Visible = true
		VipShow.next_exp.Visible = true
		-- VipShow.lv0_des.Visible = false
		if Viplevel == VipMaxlevel then
			VipShow.exp_bar.Size = Vector2(300,25)
			VipShow.c_VIP_now_exp.Text = vip_exp[8]
			VipShow.c_VIP_now.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_bg_07.dds", Vector4(0, 0, 0, 0)),}
			VipShow.c_VIP_now_num.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_button_07_normal.dds", Vector4(0, 0, 0, 0)),}
			VipShow.c_VIP_next_exp.Text = vip_exp[9]
			VipShow.c_VIP_next.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_bg_08.dds", Vector4(0, 0, 0, 0)),}
			VipShow.c_VIP_next_num.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_button_08_normal.dds", Vector4(0, 0, 0, 0)),}
			VipShow.VipOther_exp.Visible = true
			VipShow.Vip0_exp.Visible = false
			-- VipShow.vip0_shuoming.Visible = false
			VipShow.vipOther_shuoming.Visible = true
		elseif Viplevel == 0 then
			VipShow.exp_bar.Size = Vector2(0,25)
			VipShow.ctr_VIP_next.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_bg_0"..(Viplevel+1)..".dds", Vector4(0, 0, 0, 0)),}
			VipShow.ctr_VIP_num_next.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_button_0"..(Viplevel+1).."_normal.dds", Vector4(0, 0, 0, 0)),}
			VipShow.c_VIP_now.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_bg_0"..Viplevel..".dds", Vector4(0, 0, 0, 0)),}
			VipShow.c_VIP_now_num.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_button_0"..Viplevel.."_normal.dds", Vector4(0, 0, 0, 0)),}
			VipShow.c_VIP_next.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_bg_0"..(Viplevel+1)..".dds", Vector4(0, 0, 0, 0)),}
			VipShow.c_VIP_next_num.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_button_0"..(Viplevel+1).."_normal.dds", Vector4(0, 0, 0, 0)),}
			VipShow.plan_next.Visible = false
			VipShow.plan_now.Visible = false
			VipShow.c_VIP_now_exp.Visible = false
			VipShow.c_VIP_next_exp.Visible = false
			VipShow.next_exp.Visible = false
			VipShow.VipOther_exp.Visible = false
			VipShow.Vip0_exp.Visible = true
			-- VipShow.vip0_shuoming.Visible = false
			-- VipShow.ctr_VIP_next.Skin = Gui.ControlSkin{BackgroundImage = nil,}
			-- VipShow.ctr_VIP_num_next.Skin = Gui.ControlSkin{BackgroundImage = nil,}
			VipShow.vipOther_shuoming.Visible = true
			-- VipShow.lv0_des.Visible = true
		elseif Viplevel == 8 then
			VipShow.VipOther_exp.Visible = true
			VipShow.Vip0_exp.Visible = false
			-- VipShow.vip0_shuoming.Visible = false
			VipShow.vipOther_shuoming.Visible = true
		else	
			VipShow.exp_bar.Size = Vector2(((data.vipExp- vip_exp[Viplevel]) / (vip_exp[Viplevel+1] - vip_exp[Viplevel]))*300,25)
			VipShow.c_VIP_now_exp.Text = vip_exp[Viplevel]
			VipShow.c_VIP_now.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_bg_0"..Viplevel..".dds", Vector4(0, 0, 0, 0)),}
			VipShow.c_VIP_now_num.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_button_0"..Viplevel.."_normal.dds", Vector4(0, 0, 0, 0)),}
			VipShow.c_VIP_next_exp.Text = vip_exp[Viplevel+1]
			VipShow.c_VIP_next.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_bg_0"..(Viplevel+1)..".dds", Vector4(0, 0, 0, 0)),}
			VipShow.c_VIP_next_num.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_button_0"..(Viplevel+1).."_normal.dds", Vector4(0, 0, 0, 0)),}
			VipShow.VipOther_exp.Visible = true
			VipShow.Vip0_exp.Visible = false
			-- VipShow.vip0_shuoming.Visible = false
			VipShow.vipOther_shuoming.Visible = true
		end
		VipShow.get_box.Visible = false
		VipShow.l_get_box.Visible = false
		VipShow.l_get_exp.Visible = false 
		if Viplevel == 8 then
			VipShow.plan_next.Visible = true
			VipShow.c_VIP_next_exp.Visible = true
			VipShow.l_get_box.Visible = true
			VipShow.l_get_exp.Visible = true 
			VipShow.get_box.Visible = true
			VipShow.get_box.Enable = false
			local tempbar = 0
			if now_box % 2 == 1 then
				VipShow.l_get_box.Text = lang:GetText("金钻尊享武器")
			else
				VipShow.l_get_box.Text = lang:GetText("金钻尊享时装")
			end
							
			VipShow.c_VIP_now.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_bg_0"..Viplevel..".dds", Vector4(0, 0, 0, 0)),}
			VipShow.c_VIP_now_num.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_button_0"..Viplevel.."_normal.dds", Vector4(0, 0, 0, 0)),}
			VipShow.c_VIP_next.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/vip/vip/vip_exp_box.dds", Vector4(0, 0, 0, 0)),}
			VipShow.c_VIP_next_num.Skin = Gui.ControlSkin{BackgroundImage = nil,}
			if now_box == 1 then
				VipShow.c_VIP_now_exp.Text = vip_exp[Viplevel]
				VipShow.c_VIP_next_exp.Text = vip_box_exp[now_box]
				if (data.vipExp - vip_exp[Viplevel]) / (vip_box_exp[now_box] - vip_exp[Viplevel]) > 1 then
					tempbar = 1
				else
					tempbar = (data.vipExp - vip_exp[Viplevel]) / (vip_box_exp[now_box] - vip_exp[Viplevel])
				end
				VipShow.exp_bar.Size = Vector2(tempbar*300,25)
			elseif now_box == 15 then
				VipShow.c_VIP_now_exp.Text = vip_box_exp[13]
				VipShow.c_VIP_next_exp.Text = vip_box_exp[14]
				VipShow.exp_bar.Size = Vector2(300,25)
			else
				VipShow.c_VIP_now_exp.Text = vip_box_exp[now_box-1]
				VipShow.c_VIP_next_exp.Text = vip_box_exp[now_box]
				
				if (data.vipExp - vip_box_exp[now_box-1]) / (vip_box_exp[now_box] - vip_box_exp[now_box-1]) > 1 then
					tempbar = 1
				else
					tempbar = (data.vipExp - vip_box_exp[now_box-1]) / (vip_box_exp[now_box] - vip_box_exp[now_box-1])
				end
				VipShow.exp_bar.Size = Vector2(tempbar*300,25)
			end
			
			if now_box <= 14 and Vipexp >= vip_box_exp[now_box] then
				VipShow.get_box.Enable = true
			end
			if now_box >14 then
				VipShow.get_box.Enable = false
			end
			-- VipShow.plan_box.Location = Vector2(41+(vip_box_exp[now_box] - vip_exp[data.vipLevel])/(vip_exp[data.vipLevel+1] - vip_exp[data.vipLevel])*300-9, 40)
			-- print("aaaaaaaaaaaaaaaaaa:",(vip_box_exp[now_box] - vip_exp[data.vipLevel])/(vip_exp[data.vipLevel+1] - vip_exp[data.vipLevel])*300)
			-- now_box = now_box + 1
			-- if now_box == 15 then
				-- now_box = 1
			-- end
		end
		
		
	end)
end

function Hide_VipShow()
	if VipShowmodel then
		VipShowmodel.Close()
		VipShowmodel = nil
	end
end
