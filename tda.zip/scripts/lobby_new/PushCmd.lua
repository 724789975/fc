module("L_PushCmd",package.seeall)

local state = ptr_cast(game.CurrentState)
New_jiaose = nil
New_daoju = nil
New_daoju_dj = nil
New_daoju_sc = nil
New_daoju_kjx = nil
New_daoju_jiacheng = nil
New_daoju_lantu = nil
New_daoju_mingpian = nil
New_daoju_libao = nil

Queue = {}
Queue1 = {}

toPlayer_Res_ratio_status1 = 0

local  params1 = nil
local ModuleState_resource_ui = nil
local ModuleState_Window1 = nil
local ModuleState_Win1 = 
{
	Gui.Control "ctr_ModuleState_Window"
	{
		Size = Vector2(526, 272),
		Dock = "kDockCenter",
		BackgroundColor = ARGB(255, 255, 255, 255),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/lb_common_up_bg_01.dds", Vector4(200, 20, 100, 0)),
		},
		Gui.RichEdit "re_msg1"
		{
			Size = Vector2(380, 200),
			Location = Vector2(95, 90),
			--Dock = "kDockCenter",
			FontSize = 20,
			BackgroundColor = ARGB(255, 255, 255, 255),
			Line_Space = 5,
			Text_Shadow = true,
			
			VScrollBarWidth = 20,
			VScrollBarButtonSize = 1,
			Style = "Gui.MessagePanel",
			AutoScroll = true,
			AutoScrollMinSize = Vector2(464, 140),
			HScrollBarDisplay = "kHide",
			VScrollBarDisplay = "kAuto",
		},
		Gui.Button
		{
			Location = Vector2(300, 222),
			Size = Vector2(128, 40),
			BackgroundColor = ARGB(255,255,255,255),
			Text = lang:GetText("取消"),
			TextAlign = "kAlignCenterMiddle",
			TextColor = ARGB(255,50,50,50),
			HighlightTextColor = ARGB(255, 50 ,50 ,50),
			Padding = Vector4(0, 0, 0, 5),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/lb_common_up_button_normal.dds", Vector4(20, 20, 20, 20)),
				HoverImage = Gui.Image("LobbyUI/lb_common_up_button_hover.dds", Vector4(20, 20, 20, 20)),
				DownImage = Gui.Image("LobbyUI/lb_common_up_button_down.dds", Vector4(20, 20, 20, 20)),
				DisabledImage = Gui.Image("LobbyUI/lb_common_up_button_disabled.dds", Vector4(20, 20, 20, 20)),			
			},
			EventClick = function()
				HideModuleWin1()
				L_WarZone.battle_invite = false
			end
		},
		Gui.Button
		{
			Location = Vector2(100, 222),
			Size = Vector2(128, 40),
			BackgroundColor = ARGB(255,255,255,255),
			Text = lang:GetText("加入"),
			TextAlign = "kAlignCenterMiddle",
			TextColor = ARGB(255,50,50,50),
			HighlightTextColor = ARGB(255, 50 ,50 ,50),
			Padding = Vector4(0, 0, 0, 5),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/lb_common_up_button_normal.dds", Vector4(20, 20, 20, 20)),
				HoverImage = Gui.Image("LobbyUI/lb_common_up_button_hover.dds", Vector4(20, 20, 20, 20)),
				DownImage = Gui.Image("LobbyUI/lb_common_up_button_down.dds", Vector4(20, 20, 20, 20)),
				DisabledImage = Gui.Image("LobbyUI/lb_common_up_button_disabled.dds", Vector4(20, 20, 20, 20)),			
			},
			EventClick = function()
				L_WarZone.create_source_room_option = nil
				state.source_is_create = true
				L_FightTeam.is_in_invite = true
				state.is_fight_team_server = true
				HideModuleWin1()
				L_WarZone.FightGetBack(L_WarZone.current_state)
				L_WarZone.battle_invite = false
				state:AutoChangeRoomWithPassword(params1.serverid,params1.channelid,params1.roomid,params1.roompwd)
				
			end
		},
		
	},
}
function ShowModuleState_resource(name)
	if ModuleState_resource_ui == nil then
		ModuleState_resource_ui = Gui.Create()(ModuleState_Win1)
	end	
	if L_FightTeam.Res_ratio_status1 == "1" and toPlayer_Res_ratio_status1 == "1" then
		ModuleState_resource_ui.re_msg1:AddMsg("  “"..name.."”",ARGB(255,181, 51, 0),true,false)
		ModuleState_resource_ui.re_msg1:AddMsg(lang:GetText("邀请你加入资源争夺战"),ARGB(255,52, 50, 50),false,false)
	elseif L_FightTeam.Res_ratio_status1 == "1" and toPlayer_Res_ratio_status1 == "2"then
		ModuleState_resource_ui.re_msg1:AddMsg("  “"..name.."”",ARGB(255,181, 51, 0),true,false)
		ModuleState_resource_ui.re_msg1:AddMsg(lang:GetText("邀请你加入资源争夺战"),ARGB(255,52, 50, 50),false,false)
		ModuleState_resource_ui.re_msg1:AddMsg(lang:GetText("您今日原石收入已到上限,收益降为1/2"),ARGB(255,181, 51, 0),true,false)
	elseif L_FightTeam.Res_ratio_status1 == "1"and toPlayer_Res_ratio_status1 == "3" then
		ModuleState_resource_ui.re_msg1:AddMsg("  “"..name.."”",ARGB(255,181, 51, 0),true,false)
		ModuleState_resource_ui.re_msg1:AddMsg(lang:GetText("邀请你加入资源争夺战"),ARGB(255,52, 50, 50),false,false)
		ModuleState_resource_ui.re_msg1:AddMsg(lang:GetText("您今日原石收入已满额,收益降为0"),ARGB(255,181, 51, 0),true,false)
	elseif L_FightTeam.Res_ratio_status1 == "2" and toPlayer_Res_ratio_status1 == "1" then
		ModuleState_resource_ui.re_msg1:AddMsg("  “"..name.."”",ARGB(255,181, 51, 0),true,false)
		ModuleState_resource_ui.re_msg1:AddMsg(lang:GetText("邀请你加入资源争夺战"),ARGB(255,52, 50, 50),false,false)
		ModuleState_resource_ui.re_msg1:AddMsg(lang:GetText("战队今日原石收入已到上限,收益降为1/2"),ARGB(255,181, 51, 0),true,false)
	elseif L_FightTeam.Res_ratio_status1 == "2" and toPlayer_Res_ratio_status1 == "2" then
		ModuleState_resource_ui.re_msg1:AddMsg("  “"..name.."”",ARGB(255,181, 51, 0),true,false)
		ModuleState_resource_ui.re_msg1:AddMsg(lang:GetText("邀请你加入资源争夺战"),ARGB(255,52, 50, 50),false,false)
		ModuleState_resource_ui.re_msg1:AddMsg(lang:GetText("战队今日原石收入已到上限,收益降为1/2"),ARGB(255,181, 51, 0),true,false)
		ModuleState_resource_ui.re_msg1:AddMsg(lang:GetText("您今日原石收入已到上限,收益降为1/2"),ARGB(255,181, 51, 0),true,false)
	elseif L_FightTeam.Res_ratio_status1 == "2" and toPlayer_Res_ratio_status1 == "3" then
		ModuleState_resource_ui.re_msg1:AddMsg("  “"..name.."”",ARGB(255,181, 51, 0),true,false)
		ModuleState_resource_ui.re_msg1:AddMsg(lang:GetText("邀请你加入资源争夺战"),ARGB(255,52, 50, 50),false,false)
		ModuleState_resource_ui.re_msg1:AddMsg(lang:GetText("战队今日原石收入已到上限,收益降为1/2"),ARGB(255,181, 51, 0),true,false)
		ModuleState_resource_ui.re_msg1:AddMsg(lang:GetText("您今日原石收入已满额,收益降为0"),ARGB(255,181, 51, 0),true,false)
	elseif L_FightTeam.Res_ratio_status1 == "3" and toPlayer_Res_ratio_status1 == "1" then
		ModuleState_resource_ui.re_msg1:AddMsg("  “"..name.."”",ARGB(255,181, 51, 0),true,false)
		ModuleState_resource_ui.re_msg1:AddMsg(lang:GetText("邀请你加入资源争夺战"),ARGB(255,52, 50, 50),false,false)
		ModuleState_resource_ui.re_msg1:AddMsg(lang:GetText("战队今日原石收入已满额,收益降为0"),ARGB(255,181, 51, 0),true,false)
	elseif L_FightTeam.Res_ratio_status1 == "3" and toPlayer_Res_ratio_status1 == "2" then
		ModuleState_resource_ui.re_msg1:AddMsg("  “"..name.."”",ARGB(255,181, 51, 0),true,false)
		ModuleState_resource_ui.re_msg1:AddMsg(lang:GetText("邀请你加入资源争夺战"),ARGB(255,52, 50, 50),false,false)
		ModuleState_resource_ui.re_msg1:AddMsg(lang:GetText("战队今日原石收入已满额,收益降为0"),ARGB(255,181, 51, 0),true,false)
		ModuleState_resource_ui.re_msg1:AddMsg(lang:GetText("您今日原石收入已到上限,收益降为1/2"),ARGB(255,181, 51, 0),true,false)
	elseif L_FightTeam.Res_ratio_status1 == "3" and toPlayer_Res_ratio_status1 == "3" then
		ModuleState_resource_ui.re_msg1:AddMsg("  “"..name.."”",ARGB(255,181, 51, 0),true,false)
		ModuleState_resource_ui.re_msg1:AddMsg(lang:GetText("邀请你加入资源争夺战"),ARGB(255,52, 50, 50),false,false)
		ModuleState_resource_ui.re_msg1:AddMsg(lang:GetText("战队今日原石收入已满额,收益降为0"),ARGB(255,181, 51, 0),true,false)
		ModuleState_resource_ui.re_msg1:AddMsg(lang:GetText("您今日原石收入已满额,收益降为0"),ARGB(255,181, 51, 0),true,false)
	end	
	ModuleState_Window1 = ModalWindow.GetNew("ModuleState_resource_ui")
	ModuleState_Window1.screen.AllowEscToExit = false
	ModuleState_Window1.screen.Visible = false
	ModuleState_Window1.root.Size = Vector2(1200,900)
	ModuleState_Window1.screen.EventEscPressed = HideModuleWin1
	ModuleState_resource_ui.ctr_ModuleState_Window.Parent = ModuleState_Window1.root
	if ModuleState_Window1 and ModuleState_Window1.screen then
		ModuleState_Window1.screen.Visible = true
		gui.EventEscPressed = HideModuleWin1
	end
end
function HideModuleWin1()
	if ModuleState_Window1 and ModuleState_Window1.screen then
		ModuleState_Window1.screen.Visible = false
		ModuleState_Window1 = nil
		ModuleState_resource_ui = nil
	end
end
cmdTable = {
	mail = function(params)
				 if params then
					if gui then
						gui:PlayAudio("kUIA_NEW_MAIL")
					end
					L_LobbyMain.LobbyMainWin.tips.Text = lang:GetText("你有")..params.num..lang:GetText("封新邮件")
					L_LobbyMain.LobbyMainWin.tips.Location = Vector2(200, 758)
					L_LobbyMain.LobbyMainWin.tips.Size = Vector2(184,67)
					L_LobbyMain.LobbyMainWin.tips:Show()
					if L_Mail.Mail_root_ui then
						L_Mail.Mail_root_ui.In_Box.Text = lang:GetText("收件箱 (")..params.num..")"
					end
					if params.num == 0 then
						L_LobbyMain.LobbyMainWin.youjian.Skin = Gui.ControlSkin{BackgroundImage = nil,}
						L_LobbyMain.LobbyMainWin.youjian_mun.Text = ""
						L_LobbyMain.LobbyMainWin_Foot.btn_Mail.Text = ""
						L_LobbyMain.LobbyMainWin_Foot.btn_Mail.blink = false
						L_Mail.FillMail()
						
					else
					
						L_LobbyMain.LobbyMainWin.youjian.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/xin/lb_menu_tip.dds", Vector4(0 , 0, 0, 0)),}
						L_LobbyMain.LobbyMainWin.youjian_mun.Text = params.num
						L_LobbyMain.LobbyMainWin_Foot.btn_Mail.Text = ""
						L_LobbyMain.LobbyMainWin_Foot.btn_Mail.blink = true
						L_Mail.FillMail()
					end
				end
			end,

	highlight_storage = function(params)
				if params then
					if L_LobbyMain.LobbyMainWin_Foot.btn_Characters.PushDown == true and L_Characters.main_props_window_ui then
						L_LobbyMain.LobbyMainWin.new1:Show()
						L_LobbyMain.LobbyMainWin.new1.Location = Vector2(862-30, 810)
						L_LobbyMain.LobbyMainWin.new1.NormLocation = Vector2(862-30, 810)
						L_LobbyMain.LobbyMainWin.new1.UseTimer = true
						L_LobbyMain.LobbyMainWin.new1.DisplayTime = 1.5
						if params.type == 1 or params.type == 2 or params.type == 3 then
							if L_Characters.main_props_window_ui.btn_Characters.PushDown == false then
								L_LobbyMain.LobbyMainWin.new_jiaose.Location = Vector2(800, 220)
								L_LobbyMain.LobbyMainWin.new_jiaose.NormLocation = Vector2(800, 220)
								L_LobbyMain.LobbyMainWin.new_jiaose.UseTimer = false
								L_LobbyMain.LobbyMainWin.new_jiaose.Visible = true	
							end							
						end
						if params.type == 4 or params.type == 5 or params.type == 6 or params.type == 7 or params.type == 8 then
							if L_Characters.main_props_window_ui and L_Characters.main_props_window_ui.btn_Property.PushDown == true  then
								if L_LobbyMain.LobbyMainWin.new_daoju.Visible == true then
									L_LobbyMain.LobbyMainWin.new_daoju:Show()
									L_LobbyMain.LobbyMainWin.new_daoju.Location = Vector2(1000, 220)
									L_LobbyMain.LobbyMainWin.new_daoju.NormLocation = Vector2(1000, 220)
									L_LobbyMain.LobbyMainWin.new_daoju.UseTimer = true
									L_LobbyMain.LobbyMainWin.new_daoju.DisplayTime = 1.5
								end

								if params.type == 4 and params.subtype == 4 then
									L_LobbyMain.LobbyMainWin.new_daoju_sc.Location = Vector2(570, 290)
									L_LobbyMain.LobbyMainWin.new_daoju_sc.NormLocation = Vector2(570, 290)
									L_LobbyMain.LobbyMainWin.new_daoju_sc.UseTimer = false
									L_LobbyMain.LobbyMainWin.new_daoju_sc.Visible = true
									if L_Characters.main_props_window_ui and L_Characters.main_props_window_ui.btn_gongneng.PushDown == true then
										if L_LobbyMain.LobbyMainWin.new_daoju_sc.Visible == true then
											L_LobbyMain.LobbyMainWin.new_daoju_sc:Show()
											L_LobbyMain.LobbyMainWin.new_daoju_sc.UseTimer = true
											L_LobbyMain.LobbyMainWin.new_daoju_sc.DisplayTime = 0.5
											New_daoju_sc = 0
										end	
									end	
								end
								if params.type == 5 and params.subtype == 1 then
									L_LobbyMain.LobbyMainWin.new_daoju_kjx.Location = Vector2(660, 290)
									L_LobbyMain.LobbyMainWin.new_daoju_kjx.NormLocation = Vector2(660, 290)
									L_LobbyMain.LobbyMainWin.new_daoju_kjx.UseTimer = false
									L_LobbyMain.LobbyMainWin.new_daoju_kjx.Visible = true
									if L_Characters.main_props_window_ui and L_Characters.main_props_window_ui.btn_hecheng.PushDown == true then
										if L_LobbyMain.LobbyMainWin.new_daoju_kjx.Visible == true then
											L_LobbyMain.LobbyMainWin.new_daoju_kjx:Show()
											L_LobbyMain.LobbyMainWin.new_daoju_kjx.UseTimer = true
											L_LobbyMain.LobbyMainWin.new_daoju_kjx.DisplayTime = 0.5
											New_daoju_kjx = 0
										end	
									end	
								end
								if params.type == 4 and params.subtype == 7 then
									L_LobbyMain.LobbyMainWin.new_daoju_dj.Location = Vector2(750, 290)
									L_LobbyMain.LobbyMainWin.new_daoju_dj.NormLocation = Vector2(750, 290)
									L_LobbyMain.LobbyMainWin.new_daoju_dj.UseTimer = false
									L_LobbyMain.LobbyMainWin.new_daoju_dj.Visible = true
									if L_Characters.main_props_window_ui and L_Characters.main_props_window_ui.btn_xiaohao.PushDown == true then
										if L_LobbyMain.LobbyMainWin.new_daoju_dj.Visible == true then
											L_LobbyMain.LobbyMainWin.new_daoju_dj:Show()
											L_LobbyMain.LobbyMainWin.new_daoju_dj.UseTimer = true
											L_LobbyMain.LobbyMainWin.new_daoju_dj.DisplayTime = 0.5
											New_daoju_dj = 0
										end	
									end	
								end
								if params.type == 4 and params.subtype == 1 then
									L_LobbyMain.LobbyMainWin.new_daoju_jiacheng.Location = Vector2(840, 290)
									L_LobbyMain.LobbyMainWin.new_daoju_jiacheng.NormLocation = Vector2(840, 290)
									L_LobbyMain.LobbyMainWin.new_daoju_jiacheng.UseTimer = false
									L_LobbyMain.LobbyMainWin.new_daoju_jiacheng.Visible = true
									if L_Characters.main_props_window_ui and L_Characters.main_props_window_ui.btn_jiacheng.PushDown == true then
										if L_LobbyMain.LobbyMainWin.new_daoju_jiacheng.Visible == true then
											L_LobbyMain.LobbyMainWin.new_daoju_jiacheng:Show()
											L_LobbyMain.LobbyMainWin.new_daoju_jiacheng.UseTimer = true
											L_LobbyMain.LobbyMainWin.new_daoju_jiacheng.DisplayTime = 0.5
											New_daoju_jiacheng = 0
										end	
									end	
								end	
								if params.type == 5 and params.subtype == 2 then
									L_LobbyMain.LobbyMainWin.new_daoju_lantu.Location = Vector2(930, 290)
									L_LobbyMain.LobbyMainWin.new_daoju_lantu.NormLocation = Vector2(930, 290)
									L_LobbyMain.LobbyMainWin.new_daoju_lantu.UseTimer = false
									L_LobbyMain.LobbyMainWin.new_daoju_lantu.Visible = true
									if L_Characters.main_props_window_ui and L_Characters.main_props_window_ui.btn_lantu.PushDown == true then
										if L_LobbyMain.LobbyMainWin.new_daoju_lantu.Visible == true then
											L_LobbyMain.LobbyMainWin.new_daoju_lantu:Show()
											L_LobbyMain.LobbyMainWin.new_daoju_lantu.UseTimer = true
											L_LobbyMain.LobbyMainWin.new_daoju_lantu.DisplayTime = 0.5
											New_daoju_lantu = 0
										end	
									end	
								end	
								if params.type == 4 and params.subtype == 2 then
									L_LobbyMain.LobbyMainWin.new_daoju_mingpian.Location = Vector2(1020, 290)
									L_LobbyMain.LobbyMainWin.new_daoju_mingpian.NormLocation = Vector2(1020, 290)
									L_LobbyMain.LobbyMainWin.new_daoju_mingpian.UseTimer = false
									L_LobbyMain.LobbyMainWin.new_daoju_mingpian.Visible = true
									if L_Characters.main_props_window_ui and L_Characters.main_props_window_ui.btn_mingpian.PushDown == true then
										if L_LobbyMain.LobbyMainWin.new_daoju_mingpian.Visible == true then
											L_LobbyMain.LobbyMainWin.new_daoju_mingpian:Show()
											L_LobbyMain.LobbyMainWin.new_daoju_mingpian.UseTimer = true
											L_LobbyMain.LobbyMainWin.new_daoju_mingpian.DisplayTime = 0.5
											New_daoju_mingpian = 0
										end	
									end	
								end	
								if params.type == 8 and params.subtype == 1 then
									L_LobbyMain.LobbyMainWin.new_daoju_libao.Location = Vector2(1110, 290)
									L_LobbyMain.LobbyMainWin.new_daoju_libao.NormLocation = Vector2(1110, 290)
									L_LobbyMain.LobbyMainWin.new_daoju_libao.UseTimer = false
									L_LobbyMain.LobbyMainWin.new_daoju_libao.Visible = true
									if L_Characters.main_props_window_ui and L_Characters.main_props_window_ui.btn_libao.PushDown == true then
										if L_LobbyMain.LobbyMainWin.new_daoju_libao.Visible == true then
											L_LobbyMain.LobbyMainWin.new_daoju_libao:Show()
											L_LobbyMain.LobbyMainWin.new_daoju_libao.UseTimer = true
											L_LobbyMain.LobbyMainWin.new_daoju_libao.DisplayTime = 0.5
											New_daoju_libao = 0
										end	
									end	
								end									
							end	
						end							
					else
						L_LobbyMain.LobbyMainWin.new1.Location = Vector2(862-30, 810)
						L_LobbyMain.LobbyMainWin.new1.NormLocation = Vector2(862-30, 810)
						L_LobbyMain.LobbyMainWin.new1.UseTimer = false
						L_LobbyMain.LobbyMainWin.new1.Visible = true
						if params.type == 1 or params.type == 2 or params.type == 3 then
							New_jiaose = 1
						end
						if params.type == 4 or params.type == 5 or params.type == 6 or params.type == 7 or params.type == 8 then
							New_daoju = 1
							if params.type == 4 and params.subtype == 7 then
								New_daoju_dj = 1
							end
							if params.type == 4 and params.subtype == 4 then
								New_daoju_sc = 1
							end
							if params.type == 5 and params.subtype == 1 then
								New_daoju_kjx = 1
							end
							if params.type == 4 and params.subtype == 1 then
								New_daoju_jiacheng = 1
							end
							if params.type == 5 and params.subtype == 2 then
								New_daoju_lantu = 1
							end
							if params.type == 4 and params.subtype == 2 then
								New_daoju_mingpian = 1
							end
							if params.type == 8 and params.subtype == 1 then
								New_daoju_libao = 1
							end
						end							
					end							
				end 
			end,		
	team_application = function(params)
				if params then
					L_LobbyMain.LobbyMainWin.tips.Text = lang:GetText("你有")..params.num..lang:GetText("个待处理请求")
					L_LobbyMain.LobbyMainWin.tips.Location = Vector2(315, 758)
					L_LobbyMain.LobbyMainWin.tips.Size = Vector2(184,67)
					L_LobbyMain.LobbyMainWin.tips:Show()
					L_FightTeam.FillTeam()
				end
			end,
	team_approve_failed = function(params)
		if params then 
			local t_name = Split(params.list,"|")
			for i = 1 ,params.num do
				-- MessageBox.ShowWithConfirm(t_name[i]..lang:GetText("已经加入别的战队"))
				MessageBox.ShowWithConfirm(lang:GetText("该玩家已申请加入其他战队"))
			end
		end
	end,
	
	team_approve_failed2 = function(params)
		if params then 
			local t_name = Split(params.list,"|")
			for i = 1 ,params.num do
				MessageBox.ShowWithConfirm(t_name[i]..lang:GetText("已经加入你的战队"))
			end
		end
	end,

	
	team_number_change = function(params)
		print("-----------------------team_number_change---------------------------")
		if params then 
			--L_Friends.GetTeamInfo()
			L_FightTeam.FillTeam()
		end
	end,
	
	team_number_change_chat = function(params)
		print("-----------------------team_number_change---------------------------")
		if params then
			L_Friends.GetTeamInfo()
		end
	end,
	
	refreshBuffList = function(params)
		if params then
			L_LobbyMain.FillPersonalInfo()
		end
	end,
	
	refresh_friend = function(params)
		print ("--------------------------refresh_friend----------------------------")
		--if params then
			L_LobbyMain.GetFriendsList()
			L_LobbyMain.GerGroupList()
			L_Friends.GetTeamInfo()
			if L_Friends.Create_Friend_ui and L_Friends.Create_Friend_ui.Parent then
				L_LobbyMain.GetPartnerList()
			end
	--	end
	end,

	shop = function(params)
			end,
			
	money = function(params)
				if params then
					L_LobbyMain.UpdateMoney(params.cr, params.gp, params.v)
				end
			end,
	vip = function(params)
				if params then
					L_LobbyMain.FillPersonalInfo()
				end
			end,
	exp = function(params)
			if params then
				L_LobbyMain.UpdateLevelAndExp(params.rank, params.exp)
				L_LobbyMain.FillPersonalInfo()
			end
		  end,
	
	friendnew = function(params)
			end,
			
	top = function(params)
			end,

	switchMenu = function(params)
					if params then
					end
				end,
	black = function(params)
			end,
			
	acceptFriend = function(params)
			if params then
				print("--------------------acceptFriend----------------------------------")
				L_LobbyMain.FriendsInvited(params.pid,params.pname)
			end
		end,
		
	acceptGroup = function(params)
			if params then
				print("-------------------acceptGroup--------------------")
				L_LobbyMain.GroupInvitedAdd(params.pid,params.pname)
			end
		end,
		
	leavegroup = function(params)
			if params then
				print("-------------------leavegroup--------------------")
				L_Friends.ShowLeaveOwnGroupCreateWin(gui,lang:GetText("你已退出").."“"..params.gname.."”"..lang:GetText("聊天群"))
			end
		end,
		
	refreshFriendList = function(params)
				if params then
					print("-------------------refreshFriendList--------------------")
					L_LobbyMain.GetFriendsList()
				end
			end,
	refreshGroupList = function(params)
			if params then
				print("-------------------refreshGroupList--------------------")
				L_LobbyMain.GerGroupList()
			end
		end,
	achievement_completed = function(params)
			if params then
				print("-------------------achievement_completed--------------------")
				L_PersonalInfo.PopupAchievement(params)
				-- if config:IsInAchievementList(params.list[1][1]) then
					-- L_PersonalInfo.FaceBook(params)
				-- end
			end
	end,
	new_mission = function(params)
		if params then
			print("-----------------------------------------------------------------------")
			if params.mission ~= nil then
				for i,v in ipairs(params.mission) do
					local GUI = Gui.Create
					{
						Gui.Control "root"
						{
							Size = Vector2(196, 180),
							BackgroundColor = ARGB(0, 255, 255, 255),
							Gui.Control "Image"
							{
								Size = Vector2(196, 132),
								Location = Vector2(0, 0),
								BackgroundColor = ARGB(255, 255, 255, 255),
							},
							Gui.TextArea "description"
							{
								Size = Vector2(196, 80),
								Location = Vector2(0, 142),
								TextColor = ARGB(255, 37, 37, 37),
								FontSize = 14,
								Readonly = true,
								Fold = true,
							},
						},
					}
					GUI.Image.Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("MapsAndBG/MapsIcon/"..v[2]..".dds", Vector4(14, 14, 14, 14)),
					}
					GUI.description.Text = v[4]
					GUI.root.Parent = L_LobbyMain.Mission.scrollLayout
				end
				L_LobbyMain.Mission.root.Parent = L_LobbyMain.LobbyMainWin.LobbyMain_Root
				Gui.Align(L_LobbyMain.Mission.r, 0.5,0.5)
			end
		end
	end,
	completed_mission = function(params)
		if params then
			print("-------------------completed_mission--------------------")
			L_Mission.completed_mission_rpc_data = params
			L_Mission.Show_popup_window(1)
		end
	end,
	
	completed_activity = function(params)
		if params then
			print("-------------------completed_mission--------------------")
			print("==============================////")
			print(Queue[1])
			table.insert(Queue,params)
			L_Mission.Show_popup_window(1)
		end
	end,
	
	xunlei_gift = function(params)
		if params then
			table.remove(Queue1,1)
			table.insert(Queue1,params)
			L_LobbyMain.Fill_Gift_ui(1)
			L_LobbyMain.Gift_ui.root.Parent = L_LobbyMain.LobbyMainWin.LobbyMain_Root
			Gui.Align(L_LobbyMain.Gift_ui.r, 0.5,0.5)
		end
	end,
	
	releaseCharacter = function(params)
		if L_ReleaseProfession and params.cid then
			L_ReleaseProfession.Show(params.cid)
			rpc.safecall("character_list", {pid = ptr_cast(game.CurrentState):GetCharacterId()}, L_LobbyMain.FillCharacterClass)
		end
	end,
	
	expireBubble = function(params)
		L_LobbyMain.LobbyMainWin.tips.Text = lang:GetText("你有物品已过期或耐久为零")
		L_LobbyMain.LobbyMainWin.tips.Location = Vector2(705, 758)
		L_LobbyMain.LobbyMainWin.tips.Size = Vector2(239,67)
		L_LobbyMain.LobbyMainWin.tips:Show()
	end,
	
	warnMsg = function(params)
		if params then
			MessageBox.ShowWithConfirm(params.msg,nil)
		end
	end,
	
	--功能块状态更新
	module_status_change = function(params)
		print("module_status_change---------------------")
		if params then
			L_LobbyMain.module_status_change(params.list)
			if params.num and params.num ~= 0 then
				L_LobbyMain.ShowModuleNewOpen_Win(params.num)
			end
		end
	end,
	
	--个人总战斗力
	fightnum = function(params)
		if params then
			if L_LobbyMain.PersonalInfo_data then
				local n = math.floor(params.num)
				L_LobbyMain.ShowFightnums(L_LobbyMain.LobbyMainWin_Header.UserNickName_layout,n)
				L_LobbyMain.PersonalInfo_data.maxFightNum = n
			end
		end
	end,
	
	team_need_update = function(params)
		if params then
		print("params.num:"..params.num)
			if params.num == 3 then
				L_FightTeam.team_ui.new1:Show()
				L_FightTeam.team_ui.new1.NormLocation = Vector2(0, 10)
				L_FightTeam.team_ui.new1.UseTimer = true
				L_FightTeam.team_ui.new1.Visible = true
			elseif params.num == 2 then
				L_FightTeam.team_ui.new2:Show()
				L_FightTeam.team_ui.new2.NormLocation = Vector2(170, 10)
				L_FightTeam.team_ui.new2.UseTimer = true
				L_FightTeam.team_ui.new2.Visible = true	
			elseif params.num == 1 then
				if L_FightTeam.my_mode == 1 and L_FightTeam.team_ui.gonggao_btn.PushDown == true then
					L_FightTeam.team_ui.t_gonggao.Text = ""
					L_FightTeam.FillGongGao()
				end
				L_FightTeam.team_ui.new3:Show()
				L_FightTeam.team_ui.new3.NormLocation = Vector2(340, 10)
				L_FightTeam.team_ui.new3.UseTimer = true
				L_FightTeam.team_ui.new3.Visible = true
			elseif params.num == 4 then
				if L_FightTeam.my_mode == 1 and L_FightTeam.team_ui.gonggao_btn.PushDown == true then
					L_FightTeam.team_ui.t_gonggao.Text = ""
					L_FightTeam.FillGongGao()
				end
			end	
		end
	end,
	
	strenghtLevel = function(params)
		if params and L_LobbyMain.PersonalInfo_data then
			L_LobbyMain.PersonalInfo_data.maxLevel = params.level
		end
	end,
	
	vip_level_exp = function(params)
		if params then
			-- L_Vip.preVipLevel = params.preLevel
			-- L_Vip.preVipExp = params.preExp
			L_Vip.Viplevel = tonumber(params.level)
			L_Vip.Vipexp = tonumber(params.exp)
			if L_Vip.now_box == 15 then
				L_LobbyMain.LobbyMainWin.lb_vip_text.Text = lang:GetText("已达到最高级")
				L_LobbyMain.LobbyMainWin.exp_bar.Size = Vector2(286,25)
			elseif L_Vip.Viplevel == 8 then
				if L_Vip.now_box == 1 then
					temp = L_Vip.vip_box_exp[L_Vip.now_box] - L_Vip.Vipexp
					if (L_Vip.vip_box_exp[L_Vip.now_box] - L_Vip.Vipexp) <= 0 then
						temp = 0
					end
					L_LobbyMain.LobbyMainWin.lb_vip_text.Text = lang:GetText("下一个宝箱需要经验：")..temp	
				
					if (L_Vip.Vipexp - L_Vip.vip_exp[L_Vip.Viplevel]) / (L_Vip.vip_box_exp[L_Vip.now_box] - L_Vip.vip_exp[L_Vip.Viplevel]) > 1 then
						tempbar = 1
					else
						tempbar = (L_Vip.Vipexp - L_Vip.vip_exp[L_Vip.Viplevel]) / (L_Vip.vip_box_exp[L_Vip.now_box] - L_Vip.vip_exp[L_Vip.Viplevel])
					end
					L_LobbyMain.LobbyMainWin.exp_bar.Size = Vector2(tempbar*286,25)
				elseif L_Vip.now_box == 15 then
					L_LobbyMain.LobbyMainWin.lb_vip_text.Text = lang:GetText("下一级需要经验：0")
					L_LobbyMain.LobbyMainWin.exp_bar.Size = Vector2(286,25)
				else
					temp = L_Vip.vip_box_exp[L_Vip.now_box] - L_Vip.Vipexp
					if (L_Vip.vip_box_exp[L_Vip.now_box] - L_Vip.Vipexp) < 0 then
						temp = 0
					end
					
					L_LobbyMain.LobbyMainWin.lb_vip_text.Text = lang:GetText("下一个宝箱需要经验：")..temp	
				
					if (L_Vip.Vipexp - L_Vip.vip_box_exp[L_Vip.now_box-1]) / (L_Vip.vip_box_exp[L_Vip.now_box] - L_Vip.vip_box_exp[L_Vip.now_box-1]) > 1 then
						tempbar = 1
					else
						tempbar = (L_Vip.Vipexp - L_Vip.vip_box_exp[L_Vip.now_box-1]) / (L_Vip.vip_box_exp[L_Vip.now_box] - L_Vip.vip_box_exp[L_Vip.now_box-1])
					end
					L_LobbyMain.LobbyMainWin.exp_bar.Size = Vector2(tempbar*286,25)
				end
				-- LobbyMainWin.exp_bar.Size = Vector2((1 - ((L_Vip.vip_exp[L_Vip.Viplevel+1]-L_Vip.Vipexp) / (L_Vip.vip_exp[L_Vip.Viplevel+1] - L_Vip.vip_exp[L_Vip.Viplevel])))*286,25)
			elseif L_Vip.Viplevel == 0 then
				L_LobbyMain.LobbyMainWin.lb_vip_text.Text = lang:GetText("下一级需要经验：")
				L_LobbyMain.LobbyMainWin.exp_bar.Size = Vector2(0,25)
			else
				if L_Vip.now_box == 15 then
					L_LobbyMain.LobbyMainWin.lb_vip_text.Text = lang:GetText("下一级需要经验：").."0"	
					L_LobbyMain.LobbyMainWin.exp_bar.Size = Vector2(286, 25)
				else
					local temp = (L_Vip.vip_exp[L_Vip.Viplevel+1] - L_Vip.Vipexp) 
					if (L_Vip.vip_exp[L_Vip.Viplevel+1] - L_Vip.Vipexp) < 0 then
						temp = 0
					end
					L_LobbyMain.LobbyMainWin.lb_vip_text.Text = lang:GetText("下一级需要经验：")..temp	
					L_LobbyMain.LobbyMainWin.exp_bar.Size = Vector2((1 - ((L_Vip.vip_exp[L_Vip.Viplevel+1]-L_Vip.Vipexp) / (L_Vip.vip_exp[L_Vip.Viplevel+1] - L_Vip.vip_exp[L_Vip.Viplevel])))*286,25)
				end
			end
		end
	end,
	
	battlefield_invitation = function(params)
		params1 = params
		if params then
			local name = params.inviter_name
			
			toPlayer_Res_ratio_status1 = params.toPlayer_Res_ratio_status
			print("............",toPlayer_Res_ratio_status1)
			
			if L_WarZone.is_novice == true then
				return
			end
			if L_WarZone.host_character_info and L_WarZone.host_character_info.is_host == false and L_WarZone.host_character_info.ready then
				return
			end
			if L_LobbyMain.On_Invite_State == false then
				return
			end
			-- if L_FightTeam.team_data == nil then
				-- return
			-- end
			if L_WarZone.current_state ~= 0 then
				return
			end
			if not state.is_fight_team_server then
				if L_WarZone.battle_invite == false then
					L_WarZone.battle_invite = true
					
					ShowModuleState_resource(name)
				
					-- MessageBox.ShowWithTwoButtons(name..lang:GetText("邀请你加入资源争夺战"),lang:GetText("加入"),lang:GetText("取消"),
					-- function()
						-- L_WarZone.create_source_room_option = nil
						-- state.source_is_create = true
						-- L_FightTeam.is_in_invite = true
						-- state.is_fight_team_server = true
						-- L_WarZone.FightGetBack(L_WarZone.current_state)
						-- L_WarZone.battle_invite = false
						-- state:AutoChangeRoomWithPassword(params.serverid,params.channelid,params.roomid,params.roompwd)
					-- end,
					-- function()
						-- L_WarZone.battle_invite = false
					-- end
					-- )
				end
			end
		end
	end,
	battlefield_defense_invitation = function(params)
		if params then
			local flag = true
			for i = 1,10 do
				if L_FightTeam.attack_team_info[i][1] == nil then
					L_FightTeam.attack_team_info[i][1] = params.serverid
					L_FightTeam.attack_team_info[i][2] = params.channelid
					L_FightTeam.attack_team_info[i][3] = params.roomid
					L_FightTeam.attack_team_info[i][4] = params.roompwd
					L_FightTeam.attack_team_info[i][5] = params.attackTeam_name
					L_FightTeam.attack_team_info[i][6] = params.attackTeam_pid
					L_FightTeam.attack_team_info[i][7] = params.restype
					L_FightTeam.attack_team_info[i][8] = params.config
					L_FightTeam.attack_team_info[i][9] = params.canRobRes
					L_FightTeam.attack_team_info[i][10] = params.attackTeam_teamSpaceLevel
					L_FightTeam.attack_team_info[i][11] = params.atknum
					flag = false
					break
				end
			end
			
			if flag then
				for i = 1,10 do
					if i < 10 then
						L_FightTeam.attack_team_info[i][1] = L_FightTeam.attack_team_info[i+1][1]
						L_FightTeam.attack_team_info[i][2] = L_FightTeam.attack_team_info[i+1][2]
						L_FightTeam.attack_team_info[i][3] = L_FightTeam.attack_team_info[i+1][3]
						L_FightTeam.attack_team_info[i][4] = L_FightTeam.attack_team_info[i+1][4]
						L_FightTeam.attack_team_info[i][5] = L_FightTeam.attack_team_info[i+1][5]
						L_FightTeam.attack_team_info[i][6] = L_FightTeam.attack_team_info[i+1][6]
						L_FightTeam.attack_team_info[i][7] = L_FightTeam.attack_team_info[i+1][7]
						L_FightTeam.attack_team_info[i][8] = L_FightTeam.attack_team_info[i+1][8]
						L_FightTeam.attack_team_info[i][9] = L_FightTeam.attack_team_info[i+1][9]
						L_FightTeam.attack_team_info[i][10] = L_FightTeam.attack_team_info[i+1][10]
						L_FightTeam.attack_team_info[i][11] = L_FightTeam.attack_team_info[i+1][11]
					else
						L_FightTeam.attack_team_info[i][1] = params.serverid
						L_FightTeam.attack_team_info[i][2] = params.channelid
						L_FightTeam.attack_team_info[i][3] = params.roomid
						L_FightTeam.attack_team_info[i][4] = params.roompwd
						L_FightTeam.attack_team_info[i][5] = params.attackTeam_name
						L_FightTeam.attack_team_info[i][6] = params.attackTeam_pid
						L_FightTeam.attack_team_info[i][7] = params.restype
						L_FightTeam.attack_team_info[i][8] = params.config
						L_FightTeam.attack_team_info[i][9] = params.canRobRes
						L_FightTeam.attack_team_info[i][10] = params.attackTeam_teamSpaceLevel
						L_FightTeam.attack_team_info[i][11] = params.atknum
					end
				end
			end
			L_FightTeam.Fill_Defance_num()
		
			local name = params.attackTeam_name
			if L_WarZone.is_novice == true then
				return
			end
			if L_WarZone.host_character_info and L_WarZone.host_character_info.is_host == false and L_WarZone.host_character_info.ready then
				return
			end
			if L_LobbyMain.On_Invite_State == false then
				return
			end
			if not state.is_fight_team_server then
				if L_WarZone.battle_invite == false then
					L_WarZone.battle_invite = true
					MessageBox.ShowWithTwoButtons(name..lang:GetText("\n正在攻打战队领地是否加入"),lang:GetText("加入"),lang:GetText("取消"),
					function()
						state.source_is_create = true
						L_FightTeam.defense_success = true
						L_FightTeam.is_in_invite = true
						state.is_fight_team_server = true
						L_WarZone.FightGetBack(L_WarZone.current_state)
						L_WarZone.battle_invite = false
						L_FightTeam.source_pipei_success = true
						L_FightTeam.SourceFightType = params.restype
						state:AutoChangeRoomWithPassword(params.serverid,params.channelid,params.roomid,params.roompwd)
						L_FightTeam.FillMap(params.config,params.restype,params.canRobRes,params.attackTeam_teamSpaceLevel,name)
						state:EnterGame()
					end,
					function()
						L_WarZone.battle_invite = false
					end
					)
				end
			end
		end
	end,
	battlefield_infopush = function(params)
		if params then
			L_FightTeam.ShowSource_Success()
			L_FightTeam.SourceFightType = params.restype
			L_FightTeam.FillMap(params.dtconfig,params.restype,params.canRobRes,params.dtsplevel,params.dtname)
			L_FightTeam.source_time_ui.l_text.Text = lang:GetText("正在开始游戏......")
			L_FightTeam.source_time_ui.b_exit.Visible = false
			L_FightTeam.ShowSource_Time()
			L_FightTeam.source_success_ui.c_cost_source_bg.Visible = false
			L_FightTeam.source_success_ui.c_res_icon.Visible = false
			L_FightTeam.source_success_ui.c_cost_source_left_bg.Visible = false
			L_FightTeam.source_success_ui.c_res_icon_left.Visible = false
		end	
	end,
}

function OnServerCmd(sender, args)
	print(args.Details)
	local data, load_err = rpc.load_result("command = "..args.Details)
	if data then
		if data.command.cmd then
			if cmdTable[data.command.cmd] then
				cmdTable[data.command.cmd](data.command)
			end
			print(data.command.cmd)
			print(data.command.num)
		end
	else
		print(load_err)
	end
end

-- 字符串分割
function Split(szFullString, szSeparator)
	if szFullString == nil then
		return szFullString
	end
	local nFindStartIndex = 1
	local nSplitIndex = 1
	local nSplitArray = {}
	while true do
	   local nFindLastIndex = string.find(szFullString, szSeparator,nFindStartIndex)
	   if not nFindLastIndex then
		nSplitArray[nSplitIndex] = string.sub(szFullString, nFindStartIndex, string.len(szFullString))
		break
	   end
	   nSplitArray[nSplitIndex] = string.sub(szFullString, nFindStartIndex, nFindLastIndex - 1)
	   nFindStartIndex = nFindLastIndex + string.len(szSeparator)
	   nSplitIndex = nSplitIndex + 1
	end
	return nSplitArray
end
