module("L_Chat", package.seeall)

function Initialize()
	print("=================L_Chat Initialize()")
end

function Finalize()
	print("=================L_Chat Finalize()")
end

function Show(parent_win)
	print("=================L_Chat Show()")
end

function Hide()
	print("=================L_Chat Hide()")
end