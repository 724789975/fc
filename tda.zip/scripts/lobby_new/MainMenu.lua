module("L_MainMenu", package.seeall)

MenuLookupTable =
{
	--左侧
	Mail = L_Mail,--邮件
	FightTeam = L_FightTeam,--战队
	Friends = L_Friends,--好友
	Chat = L_Chat,--聊天
	--中间
	WarZone = L_WarZone,--战区
	Characters = L_Characters,--角色管理
	--右侧
	ShoppingMall = L_ShoppingMall,--商城
	BlackMarket = L_BlackMarket,--黑市
	Compose = L_Compose,--合成
	TopList = L_TopList,--排行榜
	Options = L_Options,--设置
	Present = L_Present,
	Shooting = L_Shooting, -- 打靶
}