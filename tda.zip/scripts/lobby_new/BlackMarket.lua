module("L_BlackMarket", package.seeall)

function Initialize()
	print("=================L_BlackMarket Initialize()")
end

function Finalize()
	print("=================L_BlackMarket Finalize()")
end

function Show(parent_win)
	print("=================L_BlackMarket Show()")
end

function Hide()
	print("=================L_BlackMarket Hide()")
end