module("L_ToolTips", package.seeall)

ci_bg_path = "LobbyUI/ToolTips/skin_bar02_BG.tga"
ci_fg_path = "LobbyUI/ToolTips/skin_bar02_content.tga"
ci_fg_path4 = "LobbyUI/ToolTips/skin_bar02_content_4.tga"
ci_fg_path7 = "LobbyUI/ToolTips/skin_bar02_content_7.tga"
ci_fg_path10 = "LobbyUI/ToolTips/skin_bar02_content_10.tga"
ci_fg_path12 = "LobbyUI/ToolTips/skin_bar02_content_12.tga"
ci_fg_path14 = "LobbyUI/ToolTips/skin_bar02_content_14.tga"
ci_fg_path15 = "LobbyUI/ToolTips/skin_bar02_content_15.tga"

ci_fg_plus_path = "LobbyUI/ToolTips/skin_bar02_increase.tga"
ci_fg_minus_path = "LobbyUI/ToolTips/skin_bar02_decrease.tga"

ci_bg_border = Vector4(5,5,5,5)
ci_fg_border = Vector4(5,5,5,5)

ShowContrast = true

font_color = {
				ARGB(255,205,43,55), 	ARGB(255,181,58,212), 	ARGB(255,101,179,239),	ARGB(255,128,239,147),
				ARGB(255,255,96,0), 	ARGB(255,255,96,0), 	ARGB(255,255,255,78), 	ARGB(255,128,239,147),
			}

local compareStrengthenIcon = 
					{ 
						Gui.CompareIcon(ci_bg_path, ci_fg_path, ci_fg_path, ci_fg_minus_path, ci_bg_border, ci_fg_border),
						Gui.CompareIcon(ci_bg_path, ci_fg_path4, ci_fg_path4, ci_fg_minus_path, ci_bg_border, ci_fg_border),
						Gui.CompareIcon(ci_bg_path, ci_fg_path7, ci_fg_path7, ci_fg_minus_path, ci_bg_border, ci_fg_border),
						Gui.CompareIcon(ci_bg_path, ci_fg_path10, ci_fg_path10, ci_fg_minus_path, ci_bg_border, ci_fg_border),
						Gui.CompareIcon(ci_bg_path, ci_fg_path12, ci_fg_path12, ci_fg_minus_path, ci_bg_border, ci_fg_border),
						Gui.CompareIcon(ci_bg_path, ci_fg_path14, ci_fg_path14, ci_fg_minus_path, ci_bg_border, ci_fg_border),
						Gui.CompareIcon(ci_bg_path, ci_fg_path15, ci_fg_path15, ci_fg_minus_path, ci_bg_border, ci_fg_border),
			
						Gui.CompareIcon(ci_bg_path, ci_fg_path, ci_fg_path, ci_fg_minus_path, ci_bg_border, ci_fg_border),
						Gui.CompareIcon(ci_bg_path, ci_fg_path4, ci_fg_path4, ci_fg_minus_path, ci_bg_border, ci_fg_border),
						Gui.CompareIcon(ci_bg_path, ci_fg_path7, ci_fg_path7, ci_fg_minus_path, ci_bg_border, ci_fg_border),
						Gui.CompareIcon(ci_bg_path, ci_fg_path10, ci_fg_path10, ci_fg_minus_path, ci_bg_border, ci_fg_border),
						Gui.CompareIcon(ci_bg_path, ci_fg_path12, ci_fg_path12, ci_fg_minus_path, ci_bg_border, ci_fg_border),
						Gui.CompareIcon(ci_bg_path, ci_fg_path14, ci_fg_path14, ci_fg_minus_path, ci_bg_border, ci_fg_border),
						Gui.CompareIcon(ci_bg_path, ci_fg_path15, ci_fg_path15, ci_fg_minus_path, ci_bg_border, ci_fg_border),
			
						Gui.CompareIcon(ci_bg_path, ci_fg_path, ci_fg_path, ci_fg_minus_path, ci_bg_border, ci_fg_border),
						Gui.CompareIcon(ci_bg_path, ci_fg_path4, ci_fg_path4, ci_fg_minus_path, ci_bg_border, ci_fg_border),
						Gui.CompareIcon(ci_bg_path, ci_fg_path7, ci_fg_path7, ci_fg_minus_path, ci_bg_border, ci_fg_border),
						Gui.CompareIcon(ci_bg_path, ci_fg_path10, ci_fg_path10, ci_fg_minus_path, ci_bg_border, ci_fg_border),
						Gui.CompareIcon(ci_bg_path, ci_fg_path12, ci_fg_path12, ci_fg_minus_path, ci_bg_border, ci_fg_border),
						Gui.CompareIcon(ci_bg_path, ci_fg_path14, ci_fg_path14, ci_fg_minus_path, ci_bg_border, ci_fg_border),
						Gui.CompareIcon(ci_bg_path, ci_fg_path15, ci_fg_path15, ci_fg_minus_path, ci_bg_border, ci_fg_border),
			
						Gui.CompareIcon(ci_bg_path, ci_fg_path, ci_fg_path, ci_fg_minus_path, ci_bg_border, ci_fg_border),
						Gui.CompareIcon(ci_bg_path, ci_fg_path4, ci_fg_path4, ci_fg_minus_path, ci_bg_border, ci_fg_border),
						Gui.CompareIcon(ci_bg_path, ci_fg_path7, ci_fg_path7, ci_fg_minus_path, ci_bg_border, ci_fg_border),
						Gui.CompareIcon(ci_bg_path, ci_fg_path10, ci_fg_path10, ci_fg_minus_path, ci_bg_border, ci_fg_border),
						Gui.CompareIcon(ci_bg_path, ci_fg_path12, ci_fg_path12, ci_fg_minus_path, ci_bg_border, ci_fg_border),
						Gui.CompareIcon(ci_bg_path, ci_fg_path14, ci_fg_path14, ci_fg_minus_path, ci_bg_border, ci_fg_border),
						Gui.CompareIcon(ci_bg_path, ci_fg_path15, ci_fg_path15, ci_fg_minus_path, ci_bg_border, ci_fg_border),
					}
					
local tooltip_window_ui = nil
local tooltip_window_ui_contrast = nil
--选择的结算方式
price_unit = {lang:GetText("FC点"), lang:GetText("C币"), lang:GetText("抵用券")}
--结算方式
unittype_way = {lang:GetText("永久"), lang:GetText("个"), lang:GetText("天")}
--服装加成信息
cloth_attribute = {lang:GetText("火焰抗性"), lang:GetText("爆炸抗性"), lang:GetText("子弹抗性"), lang:GetText("近身抗性"), lang:GetText("增加血量")}

local contrast_damage = nil
local contrast_speed = nil
local initial_damage = nil
local initial_speed = nil
local contrast_strengthen_damage = nil
local contrast_strengthen_speed = nil
local initial_strengthen_damage = nil
local initial_strengthen_speed = nil

local isNow = false
local isShowPrice = false
local isShowTimeIcon = false
local isShowDurableIcon = false
local isShowPerformance = false
local isToolAbout = false
local isBinding = false
local isBindingEx = false
local isFight = false
local isStrengthen = false
local isClothAttribute = false
local isTime = false

local contrast_isNow = false
local contrast_isShowPrice = false
local contrast_isShowTimeIcon = false
local contrast_isShowDurableIcon = false
local contrast_isShowPerformance = false
local contrast_isToolAbout = false
local contrast_isBinding = false
local contrast_isFight = false
local contrast_isStrengthen = false
local contrast_isClothAttribute = false
local contrast_isTime = false

local isCanShowContrast = false

local function create_skill_lable(location_y)
	return Gui.Control
	{
		Size = Vector2(300, 32),
		Location = Vector2(3, location_y + 3),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Gui.Control
		{
			Size = Vector2(45, 45),
			Location = Vector2(-5, -5),
			BackgroundColor = ARGB(255, 255, 255, 255),
		},
		Gui.TextArea
		{
			Size = Vector2(240, 40),
			Location = Vector2(40, -5),
			Fold = true,
			FontSize = 13,
		},
	}
end

local function create_skill_lable1(location_y)
	return Gui.TextArea
	{
		Size = Vector2(302, 40),
		Location = Vector2(0, location_y),
		TextColor = ARGB(255, 115, 175, 127),
		--BackgroundColor = ARGB(255, 255, 255, 255),
		FontSize = 12,
		Fold = true,
		--TextAlign = "kAlignCenterMiddle",
		Text = "",
	}
end

local function create_star_lable(index)
	return Gui.Label
	{
		Size = Vector2(20, 20),
		Location = Vector2(20*(index-1), 0),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/ToolTips/little_star.dds",Vector4(0, 0, 0, 0)),
		}, 
	}
end

--ToolTips窗口
local tooltip_window =
{
	Gui.Control "ctrl_root"
	{					
		Size = Vector2(320, 509),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Visible = false,
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/ToolTips/lb_tooltips_bg.dds",Vector4(10, 10, 10, 10)),
		},
		
		--物品名称
		Gui.Control "ctrl_title"
		{							
			Size = Vector2(302, 35),
			Location = Vector2(9, 11),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ToolTips/lb_tooltips_bg_wqmc.dds",Vector4(10, 10, 10, 10)),
			},
			Gui.Label "lbl_now"
			{
				Size = Vector2(287, 22),
				Location = Vector2(7, 4),
				TextColor = ARGB(255, 255, 180, 104),
				FontSize = 20,
				TextAlign = "kAlignCenterMiddle",
				Text = lang:GetText("当前装备"),
			},
			Gui.Label "lbl_title"
			{
				Size = Vector2(287, 22),
				Location = Vector2(7, 9),
				TextColor = ARGB(255, 215, 232, 227),
				FontSize = 18,
				TextAlign = "kAlignCenterMiddle",
				Text = lang:GetText("物品名称"),
			},
		},
		
		--货币价格
		Gui.Control "ctrl_price"
		{							
			Size = Vector2(302, 90),
			Location = Vector2(9, 49),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ToolTips/lb_tooltips_bg_2.dds",Vector4(8, 8, 8, 8)),
			},
			
			--C币
			Gui.Control "ctrl_gp"
			{
				Size = Vector2(28, 24),
				Location = Vector2(22, 4),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_ico_cb.dds",Vector4(0, 0, 0, 0)),
				},
			},
			Gui.Label "lbl_gp"
			{
				Size = Vector2(237, 24),
				Location = Vector2(58, 4),
				TextColor = ARGB(255, 252, 192, 0),
				--BackgroundColor = ARGB(255, 255, 0, 0),
				FontSize = 22,
				TextAlign = "kAlignCenterMiddle",
				Text = "",
			},
			
			--FC点
			Gui.Control "ctrl_ld"
			{
				Size = Vector2(28, 24),
				Location = Vector2(22, 34),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_ico_fc.dds",Vector4(0, 0, 0, 0)),
				},
			},
			Gui.Label "lbl_ld"
			{
				Size = Vector2(237, 24),
				Location = Vector2(58, 34),
				TextColor = ARGB(255, 252, 192, 0),
				--BackgroundColor = ARGB(255, 0, 255, 0),
				FontSize = 22,
				TextAlign = "kAlignCenterMiddle",
				Text = "",
			},
			
			Gui.Label "lbl_lq"
			{
				Size = Vector2(237, 24),
				Location = Vector2(58, 64),
				TextColor = ARGB(255, 252, 192, 0),
				--BackgroundColor = ARGB(255, 0, 0, 255),
				FontSize = 22,
				TextAlign = "kAlignCenterMiddle",
				Text = "",
			},
		},
		
		--是否绑定单独出现 道具才使用
		Gui.Control "ctrl_binding_ex"
		{							
			Size = Vector2(302, 24),
			Location = Vector2(9, 49),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ToolTips/lb_tooltips_bg_2.dds",Vector4(8, 8, 8, 8)),
			},
			
			Gui.Label "lbl_binding_ex"
			{
				Size = Vector2(287, 20),
				Location = Vector2(8, 2),
				TextColor = ARGB(255,190, 189, 185),
				FontSize = 16,
				TextAlign = "kAlignLeftMiddle",
				Text = "",
			},
		},
		
		--是否绑定
		Gui.Control "ctrl_binding"
		{							
			Size = Vector2(302, 82),
			Location = Vector2(9, 49),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ToolTips/lb_tooltips_bg_2.dds",Vector4(8, 8, 8, 8)),
			},
			
			Gui.Label "lbl_binding"
			{
				Size = Vector2(200, 20),
				Location = Vector2(8, 2),
				TextColor = ARGB(255,190, 189, 185),
				FontSize = 16,
				TextAlign = "kAlignLeftMiddle",
				Text = "",
			},
						
			--等级图标
			Gui.Control "ctrl_level_icon"
			{
				Size = Vector2(80, 80),
				Location = Vector2(214, 1),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Visible = false,
				Skin = Gui.ControlSkin
				{
					BackgroundImage = nil,
				},
			},
		},
			
		--战斗力
		Gui.Control "ctrl_fight"
		{							
			Size = Vector2(302, 24),
			Location = Vector2(9, 49),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = nil,
			},
			
			Gui.Label "lbl_fight"
			{
				Size = Vector2(200, 20),
				Location = Vector2(8, 2),
				TextColor = ARGB(255,190, 189, 185),
				FontSize = 16,
				TextAlign = "kAlignLeftMiddle",
				Text = "",
			},
		},
		
		--强化等级
		Gui.Control "ctrl_strengthen"
		{							
			Size = Vector2(302, 24),
			Location = Vector2(9, 49),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = nil,
			},
			
			Gui.Label "lbl_strengthen"
			{
				Size = Vector2(200, 20),
				Location = Vector2(8, 2),
				TextColor = ARGB(255, 190, 189, 185),
				FontSize = 16,
				TextAlign = "kAlignLeftMiddle",
				Text = "",
			},
		},
		
		--时间和耐久
		Gui.Control "ctrl_icons"
		{							
			Size = Vector2(302, 90),
			Location = Vector2(9, 122),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ToolTips/lb_tooltips_bg_2.dds",Vector4(8, 8, 8, 8)),
			},

			--剩余时间
			Gui.Control "ctrl_icon_bg3"
			{							
				Size = Vector2(264, 29),
				Location = Vector2(22, 12),
				BackgroundColor = ARGB(0, 255, 255, 255),
				
				Gui.Control "ctrl_icon3"
				{				
					--背景
					Size = Vector2(32, 29),
					Location = Vector2(0, 0),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ToolTips/lb_tooltips_bg_3.dds",Vector4(7, 7, 7, 7)),
					},
					--作用
					Gui.Control "ctrl_icon3_1"
					{							
						Size = Vector2(16, 20),
						Location = Vector2(8, 5),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ToolTips/lb_tooltips_bg_3.dds",Vector4(7, 7, 7, 7)),
						},
					},
				},
				
				Gui.Label "lbl_icon3_ds1"
				{
					Size = Vector2(214, 29),
					Location = Vector2(45, 0),
					TextColor = ARGB(255,215, 232, 227),
					FontSize = 18,
					TextAlign = "kAlignLeftMiddle",
					Text = "",
				},
			},
			
			--耐久度
			Gui.Control "ctrl_icon_bg4"
			{							
				Size = Vector2(264, 29),
				Location = Vector2(22, 48),
				BackgroundColor = ARGB(0, 255, 255, 255),
				
				Gui.Control "ctrl_icon4"
				{							
					Size = Vector2(32, 29),
					Location = Vector2(0, 0),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ToolTips/lb_tooltips_bg_3.dds",Vector4(7, 7, 7, 7)),
					},
					Gui.Control "ctrl_icon4_1"
					{							
						Size = Vector2(8, 20),
						Location = Vector2(6, 5),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ToolTips/lb_tooltips_powerico.dds", Vector4(0, 0, 0, 0)),
						},
					},
					Gui.Control "ctrl_icon4_2"
					{							
						Size = Vector2(12, 20),
						Location = Vector2(15, 5),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ToolTips/lb_tooltips_powerbg.dds", Vector4(0, 0, 0, 0)),
						},
					},
					Gui.Control "ctrl_icon4_3"
					{							
						Size = Vector2(12, 20),
						Location = Vector2(15, 5),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ToolTips/lb_tooltips_powercontent.dds", Vector4(0, 0, 0, 0)),
						},
					},
				},
				
				Gui.Label "lbl_icon4_ds1"
				{
					Size = Vector2(214, 29),
					Location = Vector2(45, 0),
					TextColor = ARGB(255,215, 232, 227),
					FontSize = 18,
					TextAlign = "kAlignLeftMiddle",
					Text = "",
				},
			},
			--星级
			Gui.Control "ctrl_icon_bg5"
			{							
				Size = Vector2(80, 80),
				Location = Vector2(210, 5),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Compose/shengxing/lb_synthesis_conversion_shengxin_01.dds", Vector4(0, 0, 0, 0)),
				},
			},
		},
		
		--时间FOR BUFF
		Gui.Control "ctrl_time"
		{							
			Size = Vector2(302, 45),
			Location = Vector2(9, 122),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ToolTips/lb_tooltips_bg_2.dds",Vector4(8, 8, 8, 8)),
			},

			--剩余时间
			Gui.Control "ctrl_icon_timebg3"
			{							
				Size = Vector2(264, 29),
				Location = Vector2(22, 12),
				BackgroundColor = ARGB(0, 255, 255, 255),
	
				Gui.Label "lbl_icon3_timeds1"
				{
					Size = Vector2(264, 29),
					Location = Vector2(0, 0),
					TextColor = ARGB(255,215, 232, 227),
					FontSize = 18,
					TextAlign = "kAlignCenterMiddle",
					Text = "",
				},
			},
		},
		
		--物品性能
		Gui.Control "ctrl_performance"
		{							
			Size = Vector2(302, 126),
			Location = Vector2(9, 215),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ToolTips/lb_tooltips_bg_2.dds",Vector4(8, 8, 8, 8)),
			},
			
			--伤害力
			Gui.Label "lbl_demage"
			{
				Size = Vector2(95, 16),
				Location = Vector2(10, 12),
				TextColor = ARGB(255, 215, 232, 227),
				FontSize = 14,
				TextAlign = "kAlignLeftMiddle",
				Text = lang:GetText("攻击威力"),
			},
			Gui.CompareBar "compare_demage"
            {
                Size = Vector2(124, 16),
				Location = Vector2(115, 14),
                Icon = nil,
            },
			Gui.Label "lbl_star_demage"
			{
				Size = Vector2(124, 20),
				Location = Vector2(115, 28),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = nil,
				},
				create_star_lable(2),
				Gui.Label "lbl_star_demage_num"
				{
					Size = Vector2(140, 20),
					Location = Vector2(40, 0),
					TextColor = ARGB(255, 0, 0, 0),
					FontSize = 16,
					TextAlign = "kAlignLeftMiddle",
				},
			},
			Gui.Label "ctrl_demage"
			{							
				Size = Vector2(16, 24),
				Location = Vector2(260, 7),
				NormLocation = Vector2(260, 7),
				BackgroundColor = ARGB(255, 255, 255, 255),
				MoveLocation = Vector2(0,4),
				MoveWheelTime = 0.8,
				Skin = Gui.ControlSkin
				{
					BackgroundImage = nil,
				},
			},
			
			--攻击速度
			Gui.Label "lbl_speed"
			{
				Size = Vector2(95, 16),
				Location = Vector2(10, 54),
				TextColor = ARGB(255,215, 232, 227),
				FontSize = 14,
				TextAlign = "kAlignLeftMiddle",
				Text = lang:GetText("攻击速度"),
			},
			Gui.CompareBar "compare_speed"
            {
                Size = Vector2(124, 16),
				Location = Vector2(115, 55),
                Icon = nil,
            },
			Gui.Label "lbl_star_speed"
			{
				Size = Vector2(124, 20),
				Location = Vector2(115, 69),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = nil,
				},
				create_star_lable(2),
				Gui.Label "lbl_star_speed_num"
				{
					Size = Vector2(140, 20),
					Location = Vector2(40, 0),
					TextColor = ARGB(255, 0, 0, 0),
					FontSize = 16,
					TextAlign = "kAlignLeftMiddle",
				},
			},
			Gui.Label "ctrl_speed"
			{							
				Size = Vector2(16, 24),
				Location = Vector2(260, 52),
				NormLocation = Vector2(260, 52),
				BackgroundColor = ARGB(255, 255, 255, 255),
				MoveLocation = Vector2(0,4),
				MoveWheelTime = 0.8,
				Skin = Gui.ControlSkin
				{
					BackgroundImage = nil,
				},
			},
			
			--装弹量：
			Gui.Label "lbl_number1"
			{
				Size = Vector2(200, 16),
				Location = Vector2(10, 92),
				TextColor = ARGB(255,215, 232, 227),
				FontSize = 14,
				TextAlign = "kAlignLeftMiddle",
				Text = "",
			},
		},
		
		--服装属性
		Gui.Control "ctrl_clothattribute"
		{							
			Size = Vector2(302, 170),
			Location = Vector2(9, 304),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ToolTips/lb_tooltips_bg_2.dds",Vector4(8, 8, 8, 8)),
			},
			create_skill_lable1(5),
			create_skill_lable1(45),
			create_skill_lable1(85),
			create_skill_lable1(125),
			create_skill_lable1(165),
			Gui.Control "shengxingHP"
			{							
				Size = Vector2(102, 17),
				Location = Vector2(155, 89),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					--BackgroundImage = Gui.Image("LobbyUI/Compose/shengxing/lb_synthesis_conversion_hp_05.dds",Vector4(0, 0, 0, 0)),
				},
			}
		},
		
		--物品介绍（武器技能1-12）
		Gui.Control "ctrl_skill"
		{							
			Size = Vector2(302, 228),
			Location = Vector2(9, 304),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ToolTips/lb_tooltips_bg_2.dds",Vector4(8, 8, 8, 8)),
			},
			create_skill_lable(3),
			create_skill_lable(43),
			create_skill_lable(83),
			create_skill_lable(123),
			create_skill_lable(163),
			create_skill_lable(203),
			create_skill_lable(243),
			create_skill_lable(283),
			create_skill_lable(323),
			create_skill_lable(363),
			create_skill_lable(403),
			create_skill_lable(443),
			create_skill_lable(483),
			create_skill_lable(523),
			create_skill_lable(563),
			create_skill_lable(603),
			create_skill_lable(643),
			create_skill_lable(683),
		},
		
		Gui.Control "taozhuang"
		{							
			Size = Vector2(302, 114),
			Location = Vector2(9, 625),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ToolTips/lb_tooltips_bg_2.dds",Vector4(8, 8, 8, 8)),
			},
			Gui.Label "taozhuang_name"
			{
				Size = Vector2(290, 20),
				Location = Vector2(6, 6),
				TextColor = ARGB(255, 255, 255, 255),
				FontSize = 14,
				TextAlign = "kAlignLeftMiddle",
				Text = lang:GetText("XX套装:"),
			},
			Gui.Label "taozhuang_des4"
			{
				Size = Vector2(290, 57),
				Location = Vector2(6, 20),
				TextColor = ARGB(255, 255, 255, 255),
				FontSize = 14,
				TextAlign = "kAlignLeftMiddle",
				Text = lang:GetText("4件套\nXXX:10%    XXX:10%\n6件套\nXXX:10%    XXX:10%"),
			},
			Gui.Label "taozhuang_des6"
			{
				Size = Vector2(290, 57),
				Location = Vector2(6, 72),
				TextColor = ARGB(255, 255, 255, 255),
				FontSize = 14,
				TextAlign = "kAlignLeftTop",
				Text = lang:GetText("4件套\nXXX:10%    XXX:10%\n6件套\nXXX:10%    XXX:10%"),
			},
		},
		
		--道具说明
		Gui.Control "ctrl_prop"
		{							
			Size = Vector2(302, 170),
			Location = Vector2(9, 562),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ToolTips/lb_tooltips_bg_2.dds",Vector4(8, 8, 8, 8)),
			},
			
			Gui.TextArea "txta_prop_info"
			{
				Size = Vector2(320, 155),
				Text = lang:GetText("物品用途"),
				FontSize = 16,
				Location = Vector2(4, 2),
				TextColor = ARGB(255, 234, 224, 207),
				Readonly = true,
				Fold = true,
				VScrollBarDisplay = "kHide",
				Gui.Label "ctrl_activate"
				{
					--Visible = false,
					Size = Vector2(320, 40),
					Location = Vector2(0, 115),
					TextColor = ARGB(255, 255, 0, 0),
					FontSize = 16,
				},
			},
				
			Gui.Control"sign_1"
			{
				Size = Vector2(70, 70),
				Location = Vector2(8, 45),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					-- BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_bg_1.dds",Vector4(8, 8, 8, 8)),
				},
				Gui.Control"goods_1"
				{	Size = Vector2(68, 68),
					Location = Vector2(1, 1),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						-- BackgroundImage = Gui.Image("LobbyUI/ibt_icon/upgardmod.tga",Vector4(8, 8, 8, 8)),
					},	
				},
				Gui.Label "num_1"
				{
					Size = Vector2(60, 20),
					Location = Vector2(30, 45),
					TextColor = ARGB(255, 255, 255, 255),
					FontSize = 16,
					TextAlign = "kAlignLeftMiddle",
					Text = lang:GetText(""),
				},
			},
			Gui.Label "num_11"
			{
				Size = Vector2(70, 40),
				Location = Vector2(8, 120),
				TextColor = ARGB(255, 255, 255, 255),
				FontSize = 16,
				TextAlign = "kAlignLeftMiddle",
				Text = lang:GetText(""),
			},
			Gui.Control"sign_2"
			{
				Size = Vector2(70, 70),
				Location = Vector2(81, 46),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					-- BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_bg_1.dds",Vector4(8, 8, 8, 8)),
				},
				Gui.Control"goods_2"
				{	Size = Vector2(68, 68),
					Location = Vector2(1, 1),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						-- BackgroundImage = Gui.Image("LobbyUI/ibt_icon/upgardmod.tga",Vector4(8, 8, 8, 8)),
					},	
				},
				Gui.Label "num_2"
				{
					Size = Vector2(60, 20),
					Location = Vector2(35, 45),
					TextColor = ARGB(255, 255, 255, 255),
					FontSize = 16,
					TextAlign = "kAlignLeftMiddle",
					Text = lang:GetText(""),
				},
			},
			Gui.Label "num_12"
			{
				Size = Vector2(70, 50),
				Location = Vector2(81, 115),
				TextColor = ARGB(255, 255, 255, 255),
				FontSize = 16,
				TextAlign = "kAlignLeftMiddle",
				Text = lang:GetText(""),
			},
			Gui.Control"sign_3"
			{
			
				Size = Vector2(70, 70),
				Location = Vector2(154, 46),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					-- BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_bg_1.dds",Vector4(8, 8, 8, 8)),
				},
				Gui.Control"goods_3"
				{	Size = Vector2(68, 68),
					Location = Vector2(1, 1),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						-- BackgroundImage = Gui.Image("LobbyUI/ibt_icon/upgardmod.tga",Vector4(8, 8, 8, 8)),
					},	
				},
				Gui.Label "num_3"
				{
					Size = Vector2(60, 20),
					Location = Vector2(35, 45),
					TextColor = ARGB(255, 255, 255, 255),
					FontSize = 16,
					TextAlign = "kAlignLeftMiddle",
					Text = lang:GetText(""),
				},
			},
			Gui.Label "num_13"
			{
				Size = Vector2(70, 50),
				Location = Vector2(154, 115),
				TextColor = ARGB(255, 255, 255, 255),
				FontSize = 16,
				TextAlign = "kAlignLeftMiddle",
				Text = lang:GetText(""),
			},
			Gui.Control"sign_4"
			{
				Size = Vector2(70, 70),
				Location = Vector2(227, 46),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					-- BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_bg_1.dds",Vector4(8, 8, 8, 8)),
				},
				Gui.Control"goods_4"
				{	Size = Vector2(68, 68),
					Location = Vector2(1, 1),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						-- BackgroundImage = Gui.Image("LobbyUI/ibt_icon/upgardmod.tga",Vector4(8, 8, 8, 8)),
					},	
				},
				Gui.Label "num_4"
				{
					Size = Vector2(60, 20),
					Location = Vector2(35, 45),
					TextColor = ARGB(255, 255, 255, 255),
					FontSize = 16,
					TextAlign = "kAlignLeftMiddle",
					Text = lang:GetText(""),
				},
			},
			Gui.Label "num_14"
			{
				Size = Vector2(70, 50),
				Location = Vector2(227, 115),
				TextColor = ARGB(255, 255, 255, 255),
				FontSize = 16,
				TextAlign = "kAlignLeftMiddle",
				Text = lang:GetText(""),
			},
		},
		
		--时间说明
		Gui.Control "ctrl_time_tips"
		{							
			Size = Vector2(302, 30),
			Location = Vector2(9, 562),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ToolTips/lb_tooltips_bg_2.dds",Vector4(8, 8, 8, 8)),
			},
			
			Gui.TextArea "txta_time_info"
			{
				Size = Vector2(294, 30),
				Text = lang:GetText("剩余时间"),
				FontSize = 18,
				Location = Vector2(4, 0),
				TextColor = ARGB(255, 255, 192, 0),
				Readonly = true,
				Fold = true,
				VScrollBarDisplay = "kHide",
			},
		},
	},
}

function HideToolTipsWindow()
	if tooltip_window_ui then
		tooltip_window_ui.ctrl_activate.Visible = false
		tooltip_window_ui.ctrl_root.Parent = nil
	end
	if tooltip_window_ui_contrast then
		tooltip_window_ui_contrast.ctrl_root.Parent = nil
	end	
end

local function setup_tooltips_window(parent_window)
	if tooltip_window_ui then
		tooltip_window_ui.ctrl_root.Parent = parent_window
		return
	end
	tooltip_window_ui = Gui.Create(parent_window)(tooltip_window)
end
local function setup_tooltips_window_contrast(parent_window)
	if tooltip_window_ui_contrast then
		tooltip_window_ui_contrast.ctrl_root.Parent = parent_window
		return
	end
	tooltip_window_ui_contrast = Gui.Create(parent_window)(tooltip_window)
end

local function ResetToolTipsWindow()
	local lobby_state = ptr_cast(game.CurrentState)
	if tooltip_window_ui then
		tooltip_window_ui.ctrl_title.Size = Vector2(302, 35)
		tooltip_window_ui.lbl_now.Visible = false
		tooltip_window_ui.ctrl_price.Visible = false
		tooltip_window_ui.ctrl_icons.Visible = false
		tooltip_window_ui.ctrl_time.Visible = false
		tooltip_window_ui.ctrl_performance.Visible = false
		tooltip_window_ui.ctrl_demage.Visible = false
		tooltip_window_ui.ctrl_speed.Visible = false
		tooltip_window_ui.ctrl_skill.Visible = false
		tooltip_window_ui.ctrl_icon_bg3.Visible = false
		tooltip_window_ui.ctrl_icon_bg4.Visible = false
		tooltip_window_ui.ctrl_prop.Visible = false
		tooltip_window_ui.ctrl_binding.Visible = false
		tooltip_window_ui.ctrl_binding_ex.Visible = false
		tooltip_window_ui.ctrl_level_icon.Visible = false
		tooltip_window_ui.ctrl_fight.Visible = false
		tooltip_window_ui.ctrl_strengthen.Visible = false
		tooltip_window_ui.ctrl_clothattribute.Visible = false
		tooltip_window_ui.ctrl_time_tips.Visible = false
	end
	
	isNow = false
	isShowPrice = false
	isShowTimeIcon = false
	isShowDurableIcon = false
	isShowPerformance = false
	isToolAbout = false
	isBinding = false
	isBindingEx = false
	isFight = false
	isStrengthen = false
	isClothAttribute = false
	isTime = false
	
	contrast_damage = nil
	contrast_speed = nil
	initial_damage = nil
	initial_speed = nil
	
	contrast_strengthen_damage = nil
	contrast_strengthen_speed = nil
	initial_strengthen_damage = nil
	initial_strengthen_speed = nil
end
local function ResetToolTipsWindowContrast()
	local lobby_state = ptr_cast(game.CurrentState)
	if tooltip_window_ui_contrast then
		tooltip_window_ui_contrast.ctrl_title.Size = Vector2(302, 35)
		tooltip_window_ui_contrast.lbl_now.Visible = false
		tooltip_window_ui_contrast.ctrl_price.Visible = false
		tooltip_window_ui_contrast.ctrl_icons.Visible = false
		tooltip_window_ui_contrast.ctrl_time.Visible = false
		tooltip_window_ui_contrast.ctrl_performance.Visible = false
		tooltip_window_ui_contrast.ctrl_demage.Visible = false
		tooltip_window_ui_contrast.ctrl_speed.Visible = false
		tooltip_window_ui_contrast.ctrl_skill.Visible = false
		tooltip_window_ui_contrast.ctrl_icon_bg3.Visible = false
		tooltip_window_ui_contrast.ctrl_icon_bg4.Visible = false
		tooltip_window_ui_contrast.ctrl_prop.Visible = false
		tooltip_window_ui_contrast.ctrl_binding.Visible = false
		tooltip_window_ui_contrast.ctrl_binding_ex.Visible = false
		tooltip_window_ui_contrast.ctrl_level_icon.Visible = false
		tooltip_window_ui_contrast.ctrl_fight.Visible = false
		tooltip_window_ui_contrast.ctrl_strengthen.Visible = false
		tooltip_window_ui_contrast.ctrl_clothattribute.Visible = false
		tooltip_window_ui_contrast.ctrl_time_tips.Visible = false
	end
	ShowContrast = true
	contrast_isNow = false
	contrast_isShowPrice = false
	contrast_isShowTimeIcon = false
	contrast_isShowDurableIcon = false
	contrast_isShowPerformance = false
	contrast_isToolAbout = false
	contrast_isBinding = false
	contrast_isFight = false
	contrast_isStrengthen = false
	contrast_isClothAttribute = false
	contrast_isTime = false
end

-- parent_window 表示依附的itemboxbtn
-- UIWindowSize 表示itemboxbtn所在窗体的大小
-- parent_location 表示itemboxbtn所在窗体的location
function ShowToolTipsShowWindow(parent_window, UIWindowSize, parent_location)
	if tooltip_window_ui then
		UpdateToolTipsWindow(parent_window, UIWindowSize, parent_location)
		tooltip_window_ui.ctrl_root.Visible = true
	end
end
function ShowToolTipsShowWindowContrast(parent_window, UIWindowSize, parent_location)
	if tooltip_window_ui_contrast and tooltip_window_ui then
		UpdateToolTipsWindowContrast(parent_window, UIWindowSize, parent_location)
		if isCanShowContrast and ShowContrast then
			tooltip_window_ui_contrast.ctrl_root.Visible = true
		end
		tooltip_window_ui.ctrl_root.Visible = true
	end
end

function UpdateToolTipsWindow(parent_window, UIWindowSize, parent_location)
	local lobby_state = ptr_cast(game.CurrentState)
	if lobby_state then
		local window_size 
		if UIWindowSize ~= nil then
			window_size = UIWindowSize
		else
			window_size = lobby_state:GetUIWindowSize()
		end
		if parent_location == nil then
			parent_location = parent_window.ClientLocation
		end
		local pos = Vector2(parent_location.x + parent_window.Size.x, parent_location.y - tooltip_window_ui.ctrl_root.Size.y / 3)
		if pos.x + 320 > window_size.x then
			pos = Vector2(parent_location.x - 321, parent_location.y - tooltip_window_ui.ctrl_root.Size.y / 3)
		end
		if pos.y >= 0 then
			if pos.y + tooltip_window_ui.ctrl_root.Size.y > window_size.y then
				pos = Vector2(pos.x, window_size.y-tooltip_window_ui.ctrl_root.Size.y-1)
			end
		else
			pos.y = 0
		end
		
		if tooltip_window_ui then
			tooltip_window_ui.ctrl_root.Location = pos
		end
	end
end
function UpdateToolTipsWindowContrast(parent_window, UIWindowSize, parent_location)
	local lobby_state = ptr_cast(game.CurrentState)
	if lobby_state then
		local window_size 
		if UIWindowSize ~= nil then
			window_size = UIWindowSize
		else
			window_size = lobby_state:GetUIWindowSize()
		end
		if parent_location == nil then
			parent_location = parent_window.ClientLocation
		end
		
		--对比两个窗口的高度
		local new_size_y = tooltip_window_ui_contrast.ctrl_root.Size.y
		if new_size_y < tooltip_window_ui.ctrl_root.Size.y then
			new_size_y = tooltip_window_ui.ctrl_root.Size.y
		end
		
		--计算新的POS
		local pos = Vector2(parent_location.x + parent_window.Size.x, parent_location.y - new_size_y / 3)
		if pos.x + 320 + 321 > window_size.x then
			pos = Vector2(parent_location.x - 321 - 320, parent_location.y - new_size_y / 3)
		end
		if pos.y + new_size_y > window_size.y then
			pos = Vector2(pos.x, window_size.y-new_size_y-1)
		end
		
		-- 更新两个窗口的位置
		if tooltip_window_ui_contrast then
			tooltip_window_ui_contrast.ctrl_root.Location = pos
		end
		if tooltip_window_ui then
			pos.x = pos.x + 321
			tooltip_window_ui.ctrl_root.Location = pos
		end
	end
end

----------------------------------------------------------------------------------
--绘制TOOLTIPS相关数据
function FillAllFromIndex(item , is_ib)--是否是仓库
	if item and tooltip_window_ui then
		local location_pos = Vector2(9, 49)
		
		if isNow then
			location_pos = Vector2(9, 69)
			--物品名称			
			tooltip_window_ui.ctrl_title.Size = Vector2(302, 55)
			tooltip_window_ui.lbl_now.Visible = false
			tooltip_window_ui.lbl_title.Location = Vector2(7, 19)
			tooltip_window_ui.taozhuang.Location = Vector2(9, 625)
		else
			--填充物品名称
			tooltip_window_ui.lbl_now.Visible = false
			tooltip_window_ui.lbl_title.Location = Vector2(7, 9)
			tooltip_window_ui.taozhuang.Location = Vector2(9, 605)
		end
		
		tooltip_window_ui.lbl_title.Text = item.display
		if item.color ~= nil and item.color >= 1 and item.color <= 7 then
			tooltip_window_ui.lbl_title.TextColor = font_color[item.color]
		else
			tooltip_window_ui.lbl_title.TextColor = ARGB(255, 255, 255, 255)
		end
			
		--货币价格
		if isShowPrice then
			tooltip_window_ui.ctrl_gp.Visible = false
			tooltip_window_ui.lbl_gp.Text = ""
			tooltip_window_ui.ctrl_gp.Location = Vector2(22, 38)
			tooltip_window_ui.lbl_gp.Location = Vector2(58, 36)  -- 4
			
			tooltip_window_ui.ctrl_ld.Visible = false
			tooltip_window_ui.lbl_ld.Text = ""
			tooltip_window_ui.ctrl_ld.Location = Vector2(22, 38)
			tooltip_window_ui.lbl_ld.Location = Vector2(58, 36)  -- 34
			
			tooltip_window_ui.lbl_lq.Text = ""
			tooltip_window_ui.lbl_lq.Location = Vector2(58, 36)  -- 64
			
			local price_count = 0		
			if item.gpprices and item.gpprices[1] then
				tooltip_window_ui.ctrl_gp.Visible = true
				price_count = price_count + 1
				if item.gpprices[1].unittype == 0 then
					tooltip_window_ui.lbl_gp.Text = item.gpprices[1].cost .. price_unit[2] .. "/" .. unittype_way[item.gpprices[1].unittype + 1]
				else
					tooltip_window_ui.lbl_gp.Text = item.gpprices[1].cost .. price_unit[2] .. "/" .. item.gpprices[1].unit .. unittype_way[item.gpprices[1].unittype + 1]
				end
			end
			if item.crprices and item.crprices[1] then
				tooltip_window_ui.ctrl_ld.Visible = true
				price_count = price_count + 1
				if item.crprices[1].unittype == 0 then
					tooltip_window_ui.lbl_ld.Text = item.crprices[1].cost .. price_unit[1] .. "/" .. unittype_way[item.crprices[1].unittype + 1]
				else
					tooltip_window_ui.lbl_ld.Text = item.crprices[1].cost .. price_unit[1] .. "/" .. item.crprices[1].unit .. unittype_way[item.crprices[1].unittype + 1]
				end
			end
			if item.voucherprices and item.voucherprices[1] then
				price_count = price_count + 1
				if item.voucherprices[1].unittype == 0 then
					tooltip_window_ui.lbl_lq.Text = item.voucherprices[1].cost .. price_unit[3] .. "/" .. unittype_way[item.voucherprices[1].unittype + 1]
				else
					tooltip_window_ui.lbl_lq.Text = item.voucherprices[1].cost .. price_unit[3] .. "/" .. item.voucherprices[1].unit .. unittype_way[item.voucherprices[1].unittype + 1]
				end
			end
			--设置价格窗口大小
			if price_count == 0 then
				tooltip_window_ui.ctrl_price.Visible = false
			else
				tooltip_window_ui.ctrl_price.Visible = true
				tooltip_window_ui.ctrl_price.Size = Vector2(302, 90)
				tooltip_window_ui.ctrl_price.Location = location_pos
				location_pos = Vector2(location_pos.x, location_pos.y + 93)
			end
		end

		if item.gstLevel and item.gstLevel > 0 then
			tooltip_window_ui.ctrl_icon_bg5.Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/Compose/shengxing/lb_synthesis_conversion_shengxin_0"..item.gstLevel..".dds", Vector4(0, 0, 0, 0)),
			}
		else
			tooltip_window_ui.ctrl_icon_bg5.Skin = Gui.ControlSkin
			{
				BackgroundImage = nil,
			}
		end
		
		--剩余时间
		if isShowTimeIcon then
			--物品图标
			tooltip_window_ui.ctrl_icons.Visible = true
			tooltip_window_ui.ctrl_icons.Location = location_pos
			location_pos = Vector2(location_pos.x, location_pos.y + 93)
			
			--剩余时间
			tooltip_window_ui.ctrl_icon3_1.Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ToolTips/lb_tooltips_sysj.dds",Vector4(0, 0, 0, 0)),
			}
			if item.unit_type == 0 then
				tooltip_window_ui.lbl_icon3_ds1.Text = lang:GetText("永久使用")
			elseif item.unit_type == 1 then
				tooltip_window_ui.lbl_icon3_ds1.Text = lang:GetText("剩余") .. item.common.quantity .. lang:GetText("个")
			elseif item.unit_type == 2 then
				local time_hour = (item.common.minutes_left - item.common.minutes_left % 60) / 60
				local provisional_item_day = item.provisional_item_day
				local Unit
				if item.crprices[1] then
					Unit = item.crprices[1].unit
				else
					Unit = item.gpprices[1].unit
				end
				if time_hour > 24 then
					local time_day = (time_hour - time_hour % 24) / 24
					local hour = time_hour % 24
					
					if hour ~= 0  then
						tooltip_window_ui.lbl_icon3_ds1.Text = lang:GetText("剩余") .. time_day .. lang:GetText("天") .. hour .. lang:GetText("小时")
						L_Characters.Renewals_window_ui.btn_buy.Enable =  true
					else
						tooltip_window_ui.lbl_icon3_ds1.Text = lang:GetText("剩余") .. time_day .. lang:GetText("天")
						L_Characters.Renewals_window_ui.btn_buy.Enable =  true
					end
					
					if provisional_item_day ~= 60001 and provisional_item_day ~= 0  and Unit < provisional_item_day then
						 L_Characters.Renewals_window_ui.lbl_limited.Text = lang:GetText("总续费天数上限为30天") 
						 L_Characters.Renewals_window_ui.btn_buy.Enable =  true
					elseif  provisional_item_day == 60001  and Unit < provisional_item_day then 
						 L_Characters.Renewals_window_ui.lbl_limited.Text = lang:GetText(" ") 
						 L_Characters.Renewals_window_ui.btn_buy.Enable =  true
					elseif   Unit > provisional_item_day then
						L_Characters.Renewals_window_ui.lbl_limited.Text = lang:GetText("总续费天数上限为30天")
						L_Characters.Renewals_window_ui.btn_buy.Enable =  false
					end
				elseif time_hour > 0 then
					tooltip_window_ui.lbl_icon3_ds1.Text = lang:GetText("剩余") .. time_hour .. lang:GetText("小时")
					L_Characters.Renewals_window_ui.btn_buy.Enable =  true
					
					if provisional_item_day ~= 60001 and provisional_item_day ~= 0 and Unit < provisional_item_day then
						 L_Characters.Renewals_window_ui.lbl_limited.Text = lang:GetText("总续费天数上限为30天")
						 L_Characters.Renewals_window_ui.btn_buy.Enable =  true
					elseif  provisional_item_day == 60001 and Unit < provisional_item_day then 
						 L_Characters.Renewals_window_ui.lbl_limited.Text = lang:GetText(" ") 
						 L_Characters.Renewals_window_ui.btn_buy.Enable =  true
					elseif   Unit > provisional_item_day then
						L_Characters.Renewals_window_ui.lbl_limited.Text = lang:GetText("总续费天数上限为30天") 
						L_Characters.Renewals_window_ui.btn_buy.Enable =  false
					end
					
				else
					tooltip_window_ui.lbl_icon3_ds1.Text = lang:GetText("剩余") .. item.common.minutes_left % 60 .. lang:GetText("分钟")
					L_Characters.Renewals_window_ui.btn_buy.Enable =  true
					
					if provisional_item_day ~= 60001 and provisional_item_day ~= 0 and Unit < provisional_item_day then
						 L_Characters.Renewals_window_ui.lbl_limited.Text = lang:GetText("总续费天数上限为30天")
						 L_Characters.Renewals_window_ui.btn_buy.Enable =  true
					elseif  provisional_item_day == 60001 and Unit < provisional_item_day then 
						 L_Characters.Renewals_window_ui.lbl_limited.Text = lang:GetText(" ")
						 L_Characters.Renewals_window_ui.btn_buy.Enable =  true
					elseif  Unit > provisional_item_day then
						L_Characters.Renewals_window_ui.lbl_limited.Text = lang:GetText("总续费天数上限为30天")
						L_Characters.Renewals_window_ui.btn_buy.Enable =  false
					end
					
					
				end
			end
			tooltip_window_ui.ctrl_icon_bg3.Visible = true
			if isShowDurableIcon then
				tooltip_window_ui.ctrl_icon_bg3.Location = Vector2(22, 12)
			else
				tooltip_window_ui.ctrl_icon_bg3.Location = Vector2(22, 24)
			end
		end
		
		--耐久			
		if isShowDurableIcon then
			local persent = item.common.durable / 100
			tooltip_window_ui.ctrl_icon4_3.Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ToolTips/lb_tooltips_powercontent.dds", Vector4(0, 0, 0, 0), Vector4(0, 1.0 - persent, 1.0, 1.0)),
			}
			if persent <= 0.2 then
				tooltip_window_ui.ctrl_icon4_3.BackgroundColor = ARGB(255, 255, 90, 9)
			else
				tooltip_window_ui.ctrl_icon4_3.BackgroundColor = ARGB(255, 255, 255, 255)
			end
			tooltip_window_ui.ctrl_icon4_3.Size = Vector2(12, 20 * persent)
			tooltip_window_ui.ctrl_icon4_3.Location = Vector2(15, 5 + 20 * (1.0 - persent))
			if item.isDefault == 1 then
				if item.unit_type ~= 2 then
					tooltip_window_ui.lbl_icon4_ds1.Text = lang:GetText("耐久") .." ".. math.ceil(item.common.durable) .. "/100"
				else
					tooltip_window_ui.lbl_icon4_ds1.Text = lang:GetText("耐久 --/--")
				end
			else
				tooltip_window_ui.lbl_icon4_ds1.Text = lang:GetText("耐久 --/--")
			end
			tooltip_window_ui.ctrl_icon_bg4.Visible = true
			tooltip_window_ui.ctrl_icon_bg4.Location = Vector2(22, 48)
		end
		
		--是否绑定
		if isBinding then
			tooltip_window_ui.ctrl_binding.Visible = true
			if item.isBind == "Y" then
				tooltip_window_ui.lbl_binding.Text = lang:GetText("已绑定")
				tooltip_window_ui.lbl_binding.TextColor = ARGB(255, 254, 0, 0)
			else
				tooltip_window_ui.lbl_binding.Text = lang:GetText("未绑定")
				tooltip_window_ui.lbl_binding.TextColor = ARGB(255, 0, 175, 80)
			end
			tooltip_window_ui.ctrl_binding.Location = location_pos
			location_pos = Vector2(location_pos.x, location_pos.y + 27)
		end
		
		--是否绑定单独版
		if isBindingEx then
			tooltip_window_ui.ctrl_binding_ex.Visible = true
			if item.isBind == "Y" then
				tooltip_window_ui.lbl_binding_ex.Text = lang:GetText("已绑定")
				tooltip_window_ui.lbl_binding_ex.TextColor = ARGB(255, 254, 0, 0)
			else
				tooltip_window_ui.lbl_binding_ex.Text = lang:GetText("未绑定")
				tooltip_window_ui.lbl_binding_ex.TextColor = ARGB(255, 0, 175, 80)
			end
			tooltip_window_ui.ctrl_binding_ex.Location = location_pos
			location_pos = Vector2(location_pos.x, location_pos.y + 27)
		end
		
		--战斗力
		if isFight then
			tooltip_window_ui.ctrl_fight.Visible = true
			tooltip_window_ui.lbl_fight.Text = lang:GetText("战斗力").." "..item.common.star
			tooltip_window_ui.ctrl_fight.Location = location_pos
			location_pos = Vector2(location_pos.x, location_pos.y + 27)
		end
				
		--强化
		if isStrengthen then
			tooltip_window_ui.ctrl_strengthen.Visible = true
			if item.isDefault == 0 then
				tooltip_window_ui.lbl_strengthen.Text = lang:GetText("无法强化")
				tooltip_window_ui.lbl_strengthen.TextColor = ARGB(255, 254, 0, 0)
				if item.common.strength == -1 or item.common.strength == 0 then
					tooltip_window_ui.ctrl_level_icon.Visible = false
				else
					tooltip_window_ui.ctrl_level_icon.Skin = Gui.ControlSkin
					{ BackgroundImage = Gui.Image("LobbyUI/ToolTips/badge_lv"..item.common.strength..".dds",Vector4(0, 0, 0, 0)), }
					tooltip_window_ui.ctrl_level_icon.Visible = true
				end
			else
				if item.common.strength == -1 or (item.unit_type ~= 0 and item.unit_type ~= nil) then
					tooltip_window_ui.lbl_strengthen.Text = lang:GetText("无法强化")
					tooltip_window_ui.lbl_strengthen.TextColor = ARGB(255, 254, 0, 0)
					tooltip_window_ui.ctrl_level_icon.Visible = false
				elseif item.common.strength >= 0 then
					tooltip_window_ui.lbl_strengthen.Text = lang:GetText("强化等级 LV.")..item.common.strength
					if item.common.strength < 4 then
						tooltip_window_ui.lbl_strengthen.TextColor = ARGB(255, 255, 255, 255)
					elseif item.common.strength >= 4 and item.common.strength < 7 then
						tooltip_window_ui.lbl_strengthen.TextColor = ARGB(255, 128, 239, 147)
					elseif item.common.strength < 10 then
						tooltip_window_ui.lbl_strengthen.TextColor = ARGB(255, 101, 179, 239)
					elseif item.common.strength < 13 then
						tooltip_window_ui.lbl_strengthen.TextColor = ARGB(255, 181, 58, 212)
					else
						tooltip_window_ui.lbl_strengthen.TextColor = ARGB(255, 255, 96, 0)
					end

					tooltip_window_ui.ctrl_level_icon.Skin = Gui.ControlSkin
					{ BackgroundImage = Gui.Image("LobbyUI/ToolTips/badge_lv"..item.common.strength..".dds",Vector4(0, 0, 0, 0)), }
					tooltip_window_ui.ctrl_level_icon.Visible = true
				end
			end
			tooltip_window_ui.ctrl_strengthen.Location = location_pos
			location_pos = Vector2(location_pos.x, location_pos.y + 31)
		end
		
		if item.isDefault == 0 then
			tooltip_window_ui.ctrl_fight.Visible = false
			tooltip_window_ui.ctrl_level_icon.Visible = false
		end
		
		--武器性能
		if isShowPerformance then
			tooltip_window_ui.ctrl_performance.Visible = true
			tooltip_window_ui.ctrl_performance.Location = location_pos
			if item.performance then
				--装弹量
				if item.performance.ammo_count ~= 0 then
					tooltip_window_ui.lbl_number1.Text = lang:GetText("装弹量：") .."  ".. item.performance.ammos .. " / " .. item.performance.ammo_count
				elseif item.performance.ammos ~= 0 then
					tooltip_window_ui.lbl_number1.Text = lang:GetText("装弹量：") .."  ".. item.performance.ammos
				else 
					tooltip_window_ui.lbl_number1.Text = ""
				end

				--伤害力进度条
				initial_damage = item.performance.damange
				initial_strengthen_damage = item.performance.damange_add
				if initial_damage == nil then
					initial_damage = 0
				end
				if initial_strengthen_damage == nil then
					initial_strengthen_damage = 0
				end		
				
				if item.wid == 4 then
					initial_damage = initial_damage * 3
					initial_strengthen_damage = initial_strengthen_damage * 3
				end
				
				-- print("--------------")
				-- print("initial_damage = "..initial_damage)
				-- print("initial_strengthen_damage = "..initial_strengthen_damage)
				-- if contrast_damage then
				-- print("contrast_damage = "..contrast_damage)
				-- end
				-- if contrast_strengthen_damage then
				-- print("contrast_strengthen_damage = "..contrast_strengthen_damage)
				-- end
				
				local star_num = math.floor((initial_damage + initial_strengthen_damage) / 50)
				local star_content = math.floor((initial_damage + initial_strengthen_damage) % 50)
				if star_content == 0 then
					star_num = star_num - 1
					star_content = 50
				end
				if star_num > 0 then
					local star = ptr_cast(tooltip_window_ui.lbl_star_demage:GetChildByIndex(0))
					star.Visible = true
					tooltip_window_ui.lbl_star_demage_num.Visible = true
					tooltip_window_ui.lbl_star_demage_num.Text = " X  "..star_num
					tooltip_window_ui.lbl_star_demage.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ToolTips/skin_bar02_BG_02.tga",Vector4(8, 8, 8, 8)),}
				else
					local star = ptr_cast(tooltip_window_ui.lbl_star_demage:GetChildByIndex(0))
					star.Visible = false
					tooltip_window_ui.lbl_star_demage_num.Visible = false
					tooltip_window_ui.lbl_star_demage.Skin = Gui.ControlSkin{BackgroundImage = nil,}
				end
				if star_num == 0 then
					tooltip_window_ui.compare_demage.Icon = compareStrengthenIcon[1]
				elseif star_num == 1 then
					tooltip_window_ui.compare_demage.Icon = compareStrengthenIcon[2]
				elseif star_num == 2 then
					tooltip_window_ui.compare_demage.Icon = compareStrengthenIcon[3]
				elseif star_num == 3 then
					tooltip_window_ui.compare_demage.Icon = compareStrengthenIcon[4]
				elseif star_num == 4 then
					tooltip_window_ui.compare_demage.Icon = compareStrengthenIcon[5]
				elseif star_num == 5 then
					tooltip_window_ui.compare_demage.Icon = compareStrengthenIcon[6]
				elseif star_num >= 6 then
					tooltip_window_ui.compare_demage.Icon = compareStrengthenIcon[7]
				end
				tooltip_window_ui.compare_demage:ResetBaseValue(star_content*2)

				local all_contrast = 0
				local all_initial = 0
				if contrast_damage ~= nil then
					all_contrast = all_contrast + math.floor(contrast_damage)
				end
				if contrast_strengthen_damage ~= nil then
					all_contrast = all_contrast + math.floor(contrast_strengthen_damage)
				end
				if initial_damage ~= nil then
					all_initial = all_initial + math.floor(initial_damage)
				end
				if initial_strengthen_damage ~= nil then
					all_initial = all_initial + math.floor(initial_strengthen_damage)
				end
				
				if contrast_damage ~= nil or contrast_strengthen_damage ~= nil then
					if all_contrast < all_initial then
						tooltip_window_ui.ctrl_demage.Visible = true
						tooltip_window_ui.ctrl_demage.Skin = Gui.ControlSkin
						{ BackgroundImage = Gui.Image("LobbyUI/ToolTips/lb_tooltips_jiantou_green.dds",Vector4(0, 0, 0, 0)), }
						tooltip_window_ui.ctrl_demage.MoveLocation = Vector2(0,-4)
					elseif all_contrast > all_initial then
						tooltip_window_ui.ctrl_demage.Visible = true
						tooltip_window_ui.ctrl_demage.Skin = Gui.ControlSkin
						{ BackgroundImage = Gui.Image("LobbyUI/ToolTips/lb_tooltips_jiantou_red.dds",Vector4(0, 0, 0, 0)), }
						tooltip_window_ui.ctrl_demage.MoveLocation = Vector2(0,4)
					else
						tooltip_window_ui.ctrl_demage.Visible = false
					end
				end
				
				--射击速度进度条
				initial_speed = item.performance.speed
				initial_strengthen_speed = item.performance.speed_add
				if initial_speed == nil then
					initial_speed = 0
				end
				if initial_strengthen_speed == nil then
					initial_strengthen_speed = 0
				end
				star_num = math.floor((initial_speed + initial_strengthen_speed) / 50)
				star_content = math.floor((initial_speed + initial_strengthen_speed) % 50)
				if star_content == 0 then
					star_num = star_num - 1
					star_content = 50
				end
				if star_num > 0 then
					local star = ptr_cast(tooltip_window_ui.lbl_star_speed:GetChildByIndex(0))
					star.Visible = true
					tooltip_window_ui.lbl_star_speed_num.Visible = true
					tooltip_window_ui.lbl_star_speed_num.Text = " X  "..star_num
					tooltip_window_ui.lbl_star_speed.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ToolTips/skin_bar02_BG_02.tga",Vector4(8, 8, 8, 8)),}
				else
					local star = ptr_cast(tooltip_window_ui.lbl_star_speed:GetChildByIndex(0))
					star.Visible = false
					tooltip_window_ui.lbl_star_speed_num.Visible = false
					tooltip_window_ui.lbl_star_speed.Skin = Gui.ControlSkin{BackgroundImage = nil,}
				end
				if star_num == 0 then
					tooltip_window_ui.compare_speed.Icon = compareStrengthenIcon[8]
				elseif star_num == 1 then
					tooltip_window_ui.compare_speed.Icon = compareStrengthenIcon[9]
				elseif star_num == 2 then
					tooltip_window_ui.compare_speed.Icon = compareStrengthenIcon[10]
				elseif star_num == 3 then
					tooltip_window_ui.compare_speed.Icon = compareStrengthenIcon[11]
				elseif star_num == 4 then
					tooltip_window_ui.compare_speed.Icon = compareStrengthenIcon[12]
				elseif star_num == 5 then
					tooltip_window_ui.compare_speed.Icon = compareStrengthenIcon[13]
				elseif star_num >= 6 then
					tooltip_window_ui.compare_speed.Icon = compareStrengthenIcon[14]
				end
				tooltip_window_ui.compare_speed:ResetBaseValue(star_content*2)
				
				local all_contrast_speed = 0
				local all_initial_speed = 0
				if contrast_speed ~= nil then
					all_contrast_speed = all_contrast_speed + math.floor(contrast_speed)
				end
				if contrast_strengthen_speed ~= nil then
					all_contrast_speed = all_contrast_speed + math.floor(contrast_strengthen_speed)
				end
				if initial_speed ~= nil then
					all_initial_speed = all_initial_speed + math.floor(initial_speed)
				end
				if initial_strengthen_speed ~= nil then
					all_initial_speed = all_initial_speed + math.floor(initial_strengthen_speed)
				end
				
				if contrast_speed ~= nil or contrast_strengthen_speed ~= nil then
					if all_contrast_speed < all_initial_speed then
						tooltip_window_ui.ctrl_speed.Visible = true
						tooltip_window_ui.ctrl_speed.Skin = Gui.ControlSkin
						{ BackgroundImage = Gui.Image("LobbyUI/ToolTips/lb_tooltips_jiantou_green.dds",Vector4(0, 0, 0, 0)), }
						tooltip_window_ui.ctrl_speed.MoveLocation = Vector2(0,-4)
					elseif all_contrast_speed > all_initial_speed then
						tooltip_window_ui.ctrl_speed.Visible = true
						tooltip_window_ui.ctrl_speed.Skin = Gui.ControlSkin
						{ BackgroundImage = Gui.Image("LobbyUI/ToolTips/lb_tooltips_jiantou_red.dds",Vector4(0, 0, 0, 0)), }
						tooltip_window_ui.ctrl_speed.MoveLocation = Vector2(0,4)
					else
						tooltip_window_ui.ctrl_speed.Visible = false
					end
				end
			end
			
			tooltip_window_ui.ctrl_performance.Size = Vector2(302, 126)
			location_pos = Vector2(location_pos.x, location_pos.y + 129)
		end
		
		--衣服属性
		if isClothAttribute and item.common.cResistanceFire_add ~= nil and item.common.cResistanceBlast_add ~= nil 
			and item.common.cResistanceBullet_add ~= nil and item.common.cResistanceKnife_add ~= nil 
			and item.common.cBloodAdd_add ~= nil and item.common.cResistanceFire ~= nil 
			and item.common.cResistanceBlast ~= nil and item.common.cResistanceBullet ~= nil
			and item.common.cResistanceKnife ~= nil and item.common.cBloodAdd then
			tooltip_window_ui.ctrl_clothattribute.Visible = true
			tooltip_window_ui.ctrl_clothattribute.Location = location_pos
			tooltip_window_ui.ctrl_clothattribute.Size = Vector2(302, 130)
			local text = ptr_cast(tooltip_window_ui.ctrl_clothattribute:GetChildByIndex(0))
			if text then
				text.FontSize = 15
				--text.TextAlign = "kAlignLeftMiddle"
				text.Location = Vector2(10, 5)
				if item.color ~= nil and item.color >= 1 and item.color <= 7 then
					text.TextColor = font_color[item.color]
				else
					text.TextColor = ARGB(255, 255, 255, 255)
				end
				text.Text = cloth_attribute[1].." "..math.floor(item.common.cResistanceFire + 0.5).."% (+"..math.floor(item.common.cResistanceFire_add + 0.5).."%)"
			end
			text = ptr_cast(tooltip_window_ui.ctrl_clothattribute:GetChildByIndex(1))
			if text then
				text.FontSize = 15
				--text.TextAlign = "kAlignLeftMiddle"
				text.Location = Vector2(10, 25)
				if item.color ~= nil and item.color >= 1 and item.color <= 7 then
					text.TextColor = font_color[item.color]
				else
					text.TextColor = ARGB(255, 255, 255, 255)
				end
				text.Text = cloth_attribute[2].." "..math.floor(item.common.cResistanceBlast + 0.5).."% (+"..math.floor(item.common.cResistanceBlast_add + 0.5).."%)"
			end
			text = ptr_cast(tooltip_window_ui.ctrl_clothattribute:GetChildByIndex(2))
			if text then
				text.FontSize = 15
				--text.TextAlign = "kAlignLeftMiddle"
				text.Location = Vector2(10, 45)
				if item.color ~= nil and item.color >= 1 and item.color <= 7 then
					text.TextColor = font_color[item.color]
				else
					text.TextColor = ARGB(255, 255, 255, 255)
				end
				text.Text = cloth_attribute[3].." "..math.floor(item.common.cResistanceBullet + 0.5).."% (+"..math.floor(item.common.cResistanceBullet_add + 0.5).."%)"
			end
			text = ptr_cast(tooltip_window_ui.ctrl_clothattribute:GetChildByIndex(3))
			if text then
				text.FontSize = 15
				--text.TextAlign = "kAlignLeftMiddle"
				text.Location = Vector2(10, 65)
				if item.color ~= nil and item.color >= 1 and item.color <= 7 then
					text.TextColor = font_color[item.color]
				else
					text.TextColor = ARGB(255, 255, 255, 255)
				end
				text.Text = cloth_attribute[4].." "..math.floor(item.common.cResistanceKnife + 0.5).."% (+"..math.floor(item.common.cResistanceKnife_add + 0.5).."%)"
			end
			text = ptr_cast(tooltip_window_ui.ctrl_clothattribute:GetChildByIndex(4))
			if text then
				text.FontSize = 15
				--text.TextAlign = "kAlignLeftMiddle"
				text.Location = Vector2(10, 85)
				if item.color ~= nil and item.color >= 1 and item.color <= 7 then
					text.TextColor = font_color[item.color]
				else
					text.TextColor = ARGB(255, 255, 255, 255)
				end
				text.Text = cloth_attribute[5].." "..math.floor(item.common.cBloodAdd + 0.5).."% (+"..math.floor(item.common.cBloodAdd_add + 0.5).."%)"
			end
			
			if L_LobbyMain.current_chosse_main_page == 22 then
				item.gstLevel = 0
			end
			
			if item.gstLevel then
				tooltip_window_ui.shengxingHP.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/Compose/shengxing/lb_synthesis_conversion_hp_0"..item.gstLevel..".dds",Vector4(0, 0, 0, 0)),}
			end	
			location_pos = Vector2(location_pos.x, location_pos.y + 130)
		end
		
		--武器属性介绍宝石镶嵌
		
		local SkillWinCount = 0
		local n = 0
		if item.common.strength ~= -1 and item.common.subtype ~= 4 and not item.provisional_item_flag and ((item.common.type and item.common.type < 4) or (item.type and item.type < 4)) then
				
			local list = item.combineDetail
			if list then
				for i, v in ipairs(list) do
					local skill_win = ptr_cast(tooltip_window_ui.ctrl_skill:GetChildByIndex(i-1))
					skill_win.Visible = true
					
					local c = ptr_cast(skill_win:GetChildByIndex(0))
					
					c.Visible = true
					if skill_win and v ~= nil then
						FillSkill(skill_win, item, v)
						n = i
						SkillWinCount = SkillWinCount + 1
					else
						if item.common.isOpenQuality == 0 then
							skill_win.Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/ToolTips/wepskillmodlv_bar_engineer.dds",Vector4(20, 10, 10, 10)),
							}
						else
							skill_win.Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/ToolTips/wepskillmodlv_bar.dds",Vector4(20, 10, 10, 10)),
							}
						end
					end
				end
			end
		elseif ((item.common.type and item.common.type < 4) or (item.type and item.type < 4)) then
			local gunproperty = #item.gunproperty
			local num = n + gunproperty	
			for i = 1, gunproperty do		
				if item.gunproperty[i] then
					local skill_win = ptr_cast(tooltip_window_ui.ctrl_skill:GetChildByIndex(i-1+n))
					if skill_win then
						skill_win.BackgroundColor = ARGB(0, 0, 0, 0)
						
						local c = ptr_cast(skill_win:GetChildByIndex(0))
						
						local l = ptr_cast(skill_win:GetChildByIndex(1))
						
						l.Size = Vector2(300, 32)
						l.Location = Vector2(0, 0)
						-- l.TextAlign = "kAlignCenterMiddle"
						
						c.Visible = not (item.common.subtype == 4 or item.provisional_item_flag)
						
						skill_win.Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ToolTips/wepskillmodlv_bar_engineer_down.dds",Vector4(20, 10, 10, 10)),
						}
						
						l.TextColor = ARGB(255, 91, 171, 42)
							
						l.Text = item.gunproperty[i][2]
					end
					SkillWinCount = SkillWinCount + 1
				end
			end
		end

		if SkillWinCount > 0 then
			tooltip_window_ui.ctrl_skill.Visible = true
			tooltip_window_ui.ctrl_skill.Location = location_pos
			tooltip_window_ui.ctrl_skill.Size = Vector2(302, SkillWinCount * 40 + 3)
			location_pos = Vector2(location_pos.x, location_pos.y + SkillWinCount * 40 + 3)
		end
		
		
		--道具说明
		if isToolAbout then
			tooltip_window_ui.ctrl_prop.Visible = true
		tooltip_window_ui.sign_1.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image(""),}
		tooltip_window_ui.sign_2.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image(""),}
		tooltip_window_ui.sign_3.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image(""),}
		tooltip_window_ui.sign_4.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image(""),}
		
		tooltip_window_ui.goods_1.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image(""),}
		tooltip_window_ui.goods_2.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image(""),}
		tooltip_window_ui.goods_3.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image(""),}
		tooltip_window_ui.goods_4.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image(""),}
		
		tooltip_window_ui.num_1.Text = lang:GetText("")
		tooltip_window_ui.num_2.Text = lang:GetText("")
		tooltip_window_ui.num_3.Text = lang:GetText("")
		tooltip_window_ui.num_4.Text = lang:GetText("")
		
		tooltip_window_ui.num_11.Text = lang:GetText("")
		tooltip_window_ui.num_12.Text = lang:GetText("")
		tooltip_window_ui.num_13.Text = lang:GetText("")
		tooltip_window_ui.num_14.Text = lang:GetText("")
			tooltip_window_ui.ctrl_prop.Location = location_pos
			tooltip_window_ui.txta_prop_info.Text = item.description
			location_pos = Vector2(location_pos.x, location_pos.y + 170 + 3)
		end
		
		--时间说明
		if isTime and item.timelimit then
			tooltip_window_ui.ctrl_time_tips.Visible = true
			tooltip_window_ui.ctrl_time_tips.Location = location_pos
			tooltip_window_ui.txta_time_info.Text = item.timelimit
			location_pos = Vector2(location_pos.x, location_pos.y + 30 + 3)
		end
		
		if item.suitId and item.suitId > 100 then
			location_pos = Vector2(location_pos.x, location_pos.y + 114 + 3)
			tooltip_window_ui.taozhuang.Visible = true
			if item.suitId == 101 then
				tooltip_window_ui.taozhuang_name.Text = lang:GetText("天神套装：")
			elseif item.suitId == 102 then
				tooltip_window_ui.taozhuang_name.Text = lang:GetText("银河套装：")
			elseif item.suitId == 103 then
				tooltip_window_ui.taozhuang_name.Text = lang:GetText("鸿运套装：")
			elseif item.suitId == 104 then
				tooltip_window_ui.taozhuang_name.Text = lang:GetText("朋克套装：")
			elseif item.suitId == 105 then
				tooltip_window_ui.taozhuang_name.Text = lang:GetText("巴洛克套装：")
			elseif item.suitId == 106 then
				tooltip_window_ui.taozhuang_name.Text = lang:GetText("新年套装：")	
			elseif item.suitId == 107 then
				tooltip_window_ui.taozhuang_name.Text = lang:GetText("生化套装：")				
			end
			tooltip_window_ui.taozhuang_des4.Text = lang:GetText("4件套:")..item.suitDetail.des4[1].."\n"..lang:GetText("4件套:")..item.suitDetail.des4[2]
			if item.suitId == 106 then
				tooltip_window_ui.taozhuang_des6.Text = lang:GetText(" ")
			else
				tooltip_window_ui.taozhuang_des6.Text = lang:GetText("6件套:")..item.suitDetail.des6[1].."\n"..lang:GetText("6件套:")..item.suitDetail.des6[2]
			end
			
			
			
			if L_LobbyMain.current_chosse_main_page == 22 then
				tooltip_window_ui.taozhuang_des4.TextColor = ARGB(255, 255, 255, 255)
				tooltip_window_ui.taozhuang_des6.TextColor = ARGB(255, 255, 255, 255)
			else
				if L_LobbyMain.CharactersInfo_rpc_data.items.putSuitId == item.suitId and L_LobbyMain.CharactersInfo_rpc_data.items.suitCount == 3 then
					tooltip_window_ui.taozhuang_des4.TextColor = ARGB(255, 255, 180, 104)
					tooltip_window_ui.taozhuang_des6.TextColor = ARGB(255, 255, 180, 104)
				else
					if L_LobbyMain.CharactersInfo_rpc_data.items.putSuitId == item.suitId and (L_LobbyMain.CharactersInfo_rpc_data.items.suitCount == 1 or L_LobbyMain.CharactersInfo_rpc_data.items.suitCount == 2) then
						tooltip_window_ui.taozhuang_des4.TextColor = ARGB(255, 255, 180, 104)
					else
						tooltip_window_ui.taozhuang_des4.TextColor = ARGB(255, 255, 255, 255)
						tooltip_window_ui.taozhuang_des6.TextColor = ARGB(255, 255, 255, 255)
					end
				end
			end
			
			
			tooltip_window_ui.taozhuang.Location = Vector2(9, location_pos.y + 10 - 125)
		else
			-- location_pos = Vector2(location_pos.x, location_pos.y + 114 + 3)
			tooltip_window_ui.taozhuang.Visible = false
		end
		if is_ib then
			tooltip_window_ui.taozhuang_des4.TextColor = ARGB(255, 255, 255, 255)
			tooltip_window_ui.taozhuang_des6.TextColor = ARGB(255, 255, 255, 255)
		end
		
		--设置整个窗口大小
		tooltip_window_ui.ctrl_root.Size = Vector2(320, location_pos.y + 10)
	end
end

--绘制TOOLTIPS相关数据Contrast
function FillAllFromIndexContrast(item)
	if item and tooltip_window_ui_contrast then
		local  location_pos = Vector2(9, 49)
		
		if item.display == "temp" then
			ShowContrast = false
		else
			ShowContrast = true
		end
		
		if contrast_isNow then
			location_pos = Vector2(9, 69)
			--物品名称			
			tooltip_window_ui_contrast.ctrl_title.Size = Vector2(302, 55)
			tooltip_window_ui_contrast.lbl_now.Visible = true
			tooltip_window_ui_contrast.lbl_title.Location = Vector2(7, 29)
			tooltip_window_ui_contrast.taozhuang.Location = Vector2(9, 625)
		else
			--填充物品名称
			tooltip_window_ui_contrast.lbl_now.Visible = false
			tooltip_window_ui_contrast.lbl_title.Location = Vector2(7, 9)
			tooltip_window_ui_contrast.taozhuang.Location = Vector2(9, 605)
		end
		
		tooltip_window_ui_contrast.lbl_title.Text = item.display
		if item.color ~= nil and item.color >= 1 and item.color <= 7 then
			tooltip_window_ui_contrast.lbl_title.TextColor = font_color[item.color]
		else
			tooltip_window_ui_contrast.lbl_title.TextColor = ARGB(255, 255, 255, 255)
		end
		
		--货币价格
		if contrast_isShowPrice then
			tooltip_window_ui_contrast.ctrl_gp.Visible = false
			tooltip_window_ui_contrast.ctrl_ld.Visible = false
			tooltip_window_ui_contrast.lbl_gp.Text = ""
			tooltip_window_ui_contrast.lbl_ld.Text = ""
			tooltip_window_ui_contrast.lbl_lq.Text = ""
			tooltip_window_ui_contrast.ctrl_gp.Location = Vector2(22, 38) --4
			tooltip_window_ui_contrast.lbl_gp.Location = Vector2(58, 36)
			tooltip_window_ui_contrast.ctrl_ld.Location = Vector2(22, 38) --34
			tooltip_window_ui_contrast.lbl_ld.Location = Vector2(58, 36)
			tooltip_window_ui_contrast.lbl_lq.Location = Vector2(58, 36)  --64
			local price_count = 0			
			if item.gpprices and item.gpprices[1] then
				tooltip_window_ui_contrast.ctrl_gp.Visible = true
				price_count = price_count + 1
				if item.gpprices[1].unittype == 0 then
					tooltip_window_ui_contrast.lbl_gp.Text = item.gpprices[1].cost .. price_unit[2] .. "/" .. unittype_way[item.gpprices[1].unittype + 1]
				else
					tooltip_window_ui_contrast.lbl_gp.Text = item.gpprices[1].cost .. price_unit[2] .. "/" .. item.gpprices[1].unit .. unittype_way[item.gpprices[1].unittype + 1]
				end
			end
			if item.crprices and item.crprices[1] then
				tooltip_window_ui_contrast.ctrl_ld.Visible = true
				price_count = price_count + 1
				if item.crprices[1].unittype == 0 then
					tooltip_window_ui_contrast.lbl_ld.Text = item.crprices[1].cost .. price_unit[1] .. "/" .. unittype_way[item.crprices[1].unittype + 1]
				else
					tooltip_window_ui_contrast.lbl_ld.Text = item.crprices[1].cost .. price_unit[1] .. "/" .. item.crprices[1].unit .. unittype_way[item.crprices[1].unittype + 1]
				end
			end
			if item.voucherprices and item.voucherprices[1] then
				price_count = price_count + 1
				if item.voucherprices[1].unittype == 0 then
					tooltip_window_ui_contrast.lbl_lq.Text = item.voucherprices[1].cost .. price_unit[3] .. "/" .. unittype_way[item.voucherprices[1].unittype + 1]
				else
					tooltip_window_ui_contrast.lbl_lq.Text = item.voucherprices[1].cost .. price_unit[3] .. "/" .. item.voucherprices[1].unit .. unittype_way[item.voucherprices[1].unittype + 1]
				end
			end
			--直接设置高度
			if price_count == 0 then
				tooltip_window_ui_contrast.ctrl_price.Visible = false
			else
				tooltip_window_ui_contrast.ctrl_price.Visible = true
				tooltip_window_ui_contrast.ctrl_price.Size = Vector2(302, 90)
				tooltip_window_ui_contrast.ctrl_price.Location = location_pos
				location_pos = Vector2(location_pos.x, location_pos.y + 93)
			end
		end
		
		if item.gstLevel and item.gstLevel > 0 then
			tooltip_window_ui_contrast.ctrl_icon_bg5.Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/Compose/shengxing/lb_synthesis_conversion_shengxin_0"..item.gstLevel..".dds", Vector4(0, 0, 0, 0)),
			}
		else
			tooltip_window_ui_contrast.ctrl_icon_bg5.Skin = Gui.ControlSkin
			{
				BackgroundImage = nil,
			}
		end
		
		--剩余时间
		if contrast_isShowTimeIcon then
			--物品图标
			tooltip_window_ui_contrast.ctrl_icons.Visible = true
			tooltip_window_ui_contrast.ctrl_icons.Location = location_pos
			location_pos = Vector2(location_pos.x, location_pos.y + 93)
			
			--剩余时间
			tooltip_window_ui_contrast.ctrl_icon3_1.Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ToolTips/lb_tooltips_sysj.dds",Vector4(0, 0, 0, 0)),
			}
			if item.unit_type == 0 then
				tooltip_window_ui_contrast.lbl_icon3_ds1.Text = lang:GetText("永久使用")
			elseif item.unit_type == 1 then
				tooltip_window_ui_contrast.lbl_icon3_ds1.Text = lang:GetText("剩余") .. item.common.quantity .. lang:GetText("个")
			elseif item.unit_type == 2 then
				local time_hour = (item.common.minutes_left - item.common.minutes_left % 60) / 60
				if time_hour > 24 then
					local time_day = (time_hour - time_hour % 24) / 24
					local hour = time_hour % 24
					if hour ~= 0 then
						tooltip_window_ui_contrast.lbl_icon3_ds1.Text = lang:GetText("剩余") .. time_day .. lang:GetText("天") .. hour .. lang:GetText("小时")
					else
						tooltip_window_ui_contrast.lbl_icon3_ds1.Text = lang:GetText("剩余") .. time_day .. lang:GetText("天")
					end
				elseif time_hour > 0 then
					tooltip_window_ui_contrast.lbl_icon3_ds1.Text = lang:GetText("剩余") .. time_hour .. lang:GetText("小时")
				else
					tooltip_window_ui_contrast.lbl_icon3_ds1.Text = lang:GetText("剩余") .. item.common.minutes_left % 60 .. lang:GetText("分钟")
				end
			end
			tooltip_window_ui_contrast.ctrl_icon_bg3.Visible = true
			if isShowDurableIcon then
				tooltip_window_ui_contrast.ctrl_icon_bg3.Location = Vector2(22, 12)
			else
				tooltip_window_ui_contrast.ctrl_icon_bg3.Location = Vector2(22, 24)
			end
		end
		
		--耐久			
		if contrast_isShowDurableIcon then
			local persent = item.common.durable / 100
			tooltip_window_ui_contrast.ctrl_icon4_3.Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ToolTips/lb_tooltips_powercontent.dds", Vector4(0, 0, 0, 0), Vector4(0, 1.0 - persent, 1.0, 1.0)),
			}
			if persent <= 0.2 then
				tooltip_window_ui_contrast.ctrl_icon4_3.BackgroundColor = ARGB(255, 255, 90, 9)
			else
				tooltip_window_ui_contrast.ctrl_icon4_3.BackgroundColor = ARGB(255, 255, 255, 255)
			end
			tooltip_window_ui_contrast.ctrl_icon4_3.Size = Vector2(12, 20 * persent)
			tooltip_window_ui_contrast.ctrl_icon4_3.Location = Vector2(15, 5 + 20 * (1.0 - persent))
			if item.isDefault == 1 then
				if item.unit_type ~= 2 then
					tooltip_window_ui_contrast.lbl_icon4_ds1.Text = lang:GetText("耐久") .." ".. math.ceil(item.common.durable) .. "/100"
				else
					tooltip_window_ui_contrast.lbl_icon4_ds1.Text = lang:GetText("耐久 --/--")
				end
			else
				tooltip_window_ui_contrast.lbl_icon4_ds1.Text = lang:GetText("耐久 --/--")
			end
			tooltip_window_ui_contrast.ctrl_icon_bg4.Visible = true
			tooltip_window_ui_contrast.ctrl_icon_bg4.Location = Vector2(22, 48)
		end
		
		--是否绑定
		if contrast_isBinding then
			tooltip_window_ui_contrast.ctrl_binding.Visible = true
			if item.isBind == "Y" then
				tooltip_window_ui_contrast.lbl_binding.Text = lang:GetText("已绑定")
				tooltip_window_ui_contrast.lbl_binding.TextColor = ARGB(255, 254, 0, 0)
			else
				tooltip_window_ui_contrast.lbl_binding.Text = lang:GetText("未绑定")
				tooltip_window_ui_contrast.lbl_binding.TextColor = ARGB(255, 0, 175, 80)
			end
			tooltip_window_ui_contrast.ctrl_binding.Location = location_pos
			location_pos = Vector2(location_pos.x, location_pos.y + 27)
		end
		
		--战斗力
		if contrast_isFight then
			tooltip_window_ui_contrast.ctrl_fight.Visible = true
			tooltip_window_ui_contrast.lbl_fight.Text = lang:GetText("战斗力").." "..item.common.star
			tooltip_window_ui_contrast.ctrl_fight.Location = location_pos
			location_pos = Vector2(location_pos.x, location_pos.y + 27)
		end
				
		--强化
		if contrast_isStrengthen then
			tooltip_window_ui_contrast.ctrl_strengthen.Visible = true
			if item.isDefault == 0 then
				tooltip_window_ui_contrast.lbl_strengthen.Text = lang:GetText("无法强化")
				tooltip_window_ui_contrast.lbl_strengthen.TextColor = ARGB(255, 254, 0, 0)
				if item.common.strength == -1 or item.common.strength == 0 then
					tooltip_window_ui_contrast.ctrl_level_icon.Visible = false
				else
					tooltip_window_ui_contrast.ctrl_level_icon.Skin = Gui.ControlSkin
					{ BackgroundImage = Gui.Image("LobbyUI/ToolTips/badge_lv"..item.common.strength..".dds",Vector4(0, 0, 0, 0)) }
					tooltip_window_ui_contrast.ctrl_level_icon.Visible = true
				end
			else
				if item.common.strength == -1 or (item.unit_type ~= 0 and item.unit_type ~= nil) then
					tooltip_window_ui_contrast.lbl_strengthen.Text = lang:GetText("无法强化")
					tooltip_window_ui_contrast.lbl_strengthen.TextColor = ARGB(255, 254, 0, 0)
					tooltip_window_ui_contrast.ctrl_level_icon.Visible = false
				elseif item.common.strength >= 0 then
					tooltip_window_ui_contrast.lbl_strengthen.Text = lang:GetText("强化等级 LV.")..item.common.strength
					
					if item.common.strength < 4 then
						tooltip_window_ui_contrast.lbl_strengthen.TextColor  = ARGB(255, 255, 255, 255)
					elseif item.common.strength >= 4 and item.common.strength < 7 then
						tooltip_window_ui_contrast.lbl_strengthen.TextColor  = ARGB(255, 128, 239, 147)
					elseif item.common.strength < 10 then
						tooltip_window_ui_contrast.lbl_strengthen.TextColor  = ARGB(255, 101, 179, 239)
					elseif item.common.strength < 13 then
						tooltip_window_ui_contrast.lbl_strengthen.TextColor  = ARGB(255, 181, 58, 212)
					else
						tooltip_window_ui_contrast.lbl_strengthen.TextColor  = ARGB(255, 255, 96, 0)
					end
					
					tooltip_window_ui_contrast.ctrl_level_icon.Skin = Gui.ControlSkin
					{ BackgroundImage = Gui.Image("LobbyUI/ToolTips/badge_lv"..item.common.strength..".dds",Vector4(0, 0, 0, 0)) }
					tooltip_window_ui_contrast.ctrl_level_icon.Visible = true
				end
			end
			tooltip_window_ui_contrast.ctrl_strengthen.Location = location_pos
			location_pos = Vector2(location_pos.x, location_pos.y + 31)
		end
		
		if item.isDefault == 0 then
			tooltip_window_ui_contrast.ctrl_fight.Visible = false
			tooltip_window_ui_contrast.ctrl_level_icon.Visible = false
		end
		
		--武器性能
		if contrast_isShowPerformance then
			tooltip_window_ui_contrast.ctrl_performance.Visible = true
			tooltip_window_ui_contrast.ctrl_performance.Location = location_pos
			if item.performance then
				--装弹量
				if item.performance.ammo_count ~= 0 then
					tooltip_window_ui_contrast.lbl_number1.Text = lang:GetText("装弹量：") .."  ".. item.performance.ammos .. " / " .. item.performance.ammo_count
				elseif item.performance.ammos ~= 0 then
					tooltip_window_ui_contrast.lbl_number1.Text = lang:GetText("装弹量：") .."  ".. item.performance.ammos
				else 
					tooltip_window_ui_contrast.lbl_number1.Text = ""
				end
				
				--伤害力进度条
				local ini_damage = item.performance.damange
				local ini_strengthen_damage = item.performance.damange_add
				if ini_damage == nil then
					ini_damage = 0
				end
				if ini_strengthen_damage == nil then
					ini_strengthen_damage = 0
				end
				
				if item.wid == 4 then
					ini_damage = ini_damage * 3
					ini_strengthen_damage = ini_strengthen_damage * 3
				end	
				local star_num = math.floor((ini_damage + ini_strengthen_damage) / 50)
				local star_content = math.floor((ini_damage + ini_strengthen_damage) % 50)
				if star_content == 0 then
					star_num = star_num - 1
					star_content = 50
				end
				if star_num > 0 then
					local star = ptr_cast(tooltip_window_ui_contrast.lbl_star_demage:GetChildByIndex(0))
					star.Visible = true
					tooltip_window_ui_contrast.lbl_star_demage_num.Visible = true
					tooltip_window_ui_contrast.lbl_star_demage_num.Text = " X  "..star_num
					tooltip_window_ui_contrast.lbl_star_demage.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ToolTips/skin_bar02_BG_02.tga",Vector4(8, 8, 8, 8)),}
				else
					local star = ptr_cast(tooltip_window_ui_contrast.lbl_star_demage:GetChildByIndex(0))
					star.Visible = false
					tooltip_window_ui_contrast.lbl_star_demage_num.Visible = false
					tooltip_window_ui_contrast.lbl_star_demage.Skin = Gui.ControlSkin{BackgroundImage = nil,}
				end
				if star_num == 0 then
					tooltip_window_ui_contrast.compare_demage.Icon = compareStrengthenIcon[15]
				elseif star_num == 1 then
					tooltip_window_ui_contrast.compare_demage.Icon = compareStrengthenIcon[16]
				elseif star_num == 2 then
					tooltip_window_ui_contrast.compare_demage.Icon = compareStrengthenIcon[17]
				elseif star_num == 3 then
					tooltip_window_ui_contrast.compare_demage.Icon = compareStrengthenIcon[18]
				elseif star_num == 4 then
					tooltip_window_ui_contrast.compare_demage.Icon = compareStrengthenIcon[19]
				elseif star_num == 5 then
					tooltip_window_ui_contrast.compare_demage.Icon = compareStrengthenIcon[20]
				elseif star_num >= 6 then
					tooltip_window_ui_contrast.compare_demage.Icon = compareStrengthenIcon[21]
				end
				tooltip_window_ui_contrast.compare_demage:ResetBaseValue(star_content*2)
				
				--射击速度进度条
				local ini_speed= item.performance.speed
				local ini_strengthen_speed = item.performance.speed_add
				if ini_speed == nil then
					ini_speed = 0
				end
				if ini_strengthen_speed == nil then
					ini_strengthen_speed = 0
				end
				star_num = math.floor((ini_speed + ini_strengthen_speed) / 50)
				star_content = math.floor((ini_speed + ini_strengthen_speed) % 50)
				if star_content == 0 then
					star_num = star_num - 1
					star_content = 50
				end
				if star_num > 0 then
					local star = ptr_cast(tooltip_window_ui_contrast.lbl_star_speed:GetChildByIndex(0))
					star.Visible = true
					tooltip_window_ui_contrast.lbl_star_speed_num.Visible = true
					tooltip_window_ui_contrast.lbl_star_speed_num.Text = " X  "..star_num
					tooltip_window_ui_contrast.lbl_star_speed.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ToolTips/skin_bar02_BG_02.tga",Vector4(8, 8, 8, 8)),}
				else
					local star = ptr_cast(tooltip_window_ui_contrast.lbl_star_speed:GetChildByIndex(0))
					star.Visible = false
					tooltip_window_ui_contrast.lbl_star_speed_num.Visible = false
					tooltip_window_ui_contrast.lbl_star_speed.Skin = Gui.ControlSkin{BackgroundImage = nil,}
				end
				-- for i = 1, 8 do
					-- local star = ptr_cast(tooltip_window_ui_contrast.lbl_star_speed:GetChildByIndex(i-1))
					-- if star then
						-- if i <= star_num then
							-- star.Visible = true
						-- else 
							-- star.Visible = false
						-- end
					-- end
				-- end
				if star_num == 0 then
					tooltip_window_ui_contrast.compare_speed.Icon = compareStrengthenIcon[22]
				elseif star_num == 1 then
					tooltip_window_ui_contrast.compare_speed.Icon = compareStrengthenIcon[23]
				elseif star_num == 2 then
					tooltip_window_ui_contrast.compare_speed.Icon = compareStrengthenIcon[24]
				elseif star_num == 3 then
					tooltip_window_ui_contrast.compare_speed.Icon = compareStrengthenIcon[25]
				elseif star_num == 4 then
					tooltip_window_ui_contrast.compare_speed.Icon = compareStrengthenIcon[26]
				elseif star_num == 5 then
					tooltip_window_ui_contrast.compare_speed.Icon = compareStrengthenIcon[27]
				elseif star_num >= 6 then
					tooltip_window_ui_contrast.compare_speed.Icon = compareStrengthenIcon[28]
				end
				tooltip_window_ui_contrast.compare_speed:ResetBaseValue(star_content*2)
				
				contrast_damage = item.performance.damange
				contrast_strengthen_damage = item.performance.damange_add
				if item.wid == 4 then
					contrast_damage = contrast_damage * 3
					contrast_strengthen_damage = contrast_strengthen_damage * 3
				end
				contrast_speed = item.performance.speed
				contrast_strengthen_speed = item.performance.speed_add
			end
			tooltip_window_ui_contrast.ctrl_performance.Size = Vector2(302, 126)
			location_pos = Vector2(location_pos.x, location_pos.y + 129)
		end
		
		--衣服属性
		if contrast_isClothAttribute and item.common.cResistanceFire_add ~= nil and item.common.cResistanceBlast_add ~= nil 
			and item.common.cResistanceBullet_add ~= nil and item.common.cResistanceKnife_add ~= nil 
			and item.common.cBloodAdd_add ~= nil and item.common.cResistanceFire ~= nil 
			and item.common.cResistanceBlast ~= nil and item.common.cResistanceBullet ~= nil
			and item.common.cResistanceKnife ~= nil and item.common.cBloodAdd then
			tooltip_window_ui_contrast.ctrl_clothattribute.Visible = true
			tooltip_window_ui_contrast.ctrl_clothattribute.Location = location_pos
			tooltip_window_ui_contrast.ctrl_clothattribute.Size = Vector2(302, 130)
			local text = ptr_cast(tooltip_window_ui_contrast.ctrl_clothattribute:GetChildByIndex(0))
			if text then
				text.FontSize = 15
				-- text.TextAlign = "kAlignLeftMiddle"
				text.Location = Vector2(10, 5)
				if item.color ~= nil and item.color >= 1 and item.color <= 7 then
					text.TextColor = font_color[item.color]
				else
					text.TextColor = ARGB(255, 255, 255, 255)
				end
				text.Text = cloth_attribute[1].." "..math.floor(item.common.cResistanceFire + 0.5).."% (+"..math.floor(item.common.cResistanceFire_add + 0.5).."%)"
			end
			text = ptr_cast(tooltip_window_ui_contrast.ctrl_clothattribute:GetChildByIndex(1))
			if text then
				text.FontSize = 15
				-- text.TextAlign = "kAlignLeftMiddle"
				text.Location = Vector2(10, 25)
				if item.color ~= nil and item.color >= 1 and item.color <= 7 then
					text.TextColor = font_color[item.color]
				else
					text.TextColor = ARGB(255, 255, 255, 255)
				end
				text.Text = cloth_attribute[2].." "..math.floor(item.common.cResistanceBlast + 0.5).."% (+"..math.floor(item.common.cResistanceBlast_add + 0.5).."%)"
			end
			text = ptr_cast(tooltip_window_ui_contrast.ctrl_clothattribute:GetChildByIndex(2))
			if text then
				text.FontSize = 15
				-- text.TextAlign = "kAlignLeftMiddle"
				text.Location = Vector2(10, 45)
				if item.color ~= nil and item.color >= 1 and item.color <= 7 then
					text.TextColor = font_color[item.color]
				else
					text.TextColor = ARGB(255, 255, 255, 255)
				end
				text.Text = cloth_attribute[3].." "..math.floor(item.common.cResistanceBullet + 0.5).."% (+"..math.floor(item.common.cResistanceBullet_add + 0.5).."%)"
			end
			text = ptr_cast(tooltip_window_ui_contrast.ctrl_clothattribute:GetChildByIndex(3))
			if text then
				text.FontSize = 15
				-- text.TextAlign = "kAlignLeftMiddle"
				text.Location = Vector2(10, 65)
				if item.color ~= nil and item.color >= 1 and item.color <= 7 then
					text.TextColor = font_color[item.color]
				else
					text.TextColor = ARGB(255, 255, 255, 255)
				end
				text.Text = cloth_attribute[4].." "..math.floor(item.common.cResistanceKnife + 0.5).."% (+"..math.floor(item.common.cResistanceKnife_add + 0.5).."%)"
			end
			text = ptr_cast(tooltip_window_ui_contrast.ctrl_clothattribute:GetChildByIndex(4))
			if text then
				text.FontSize = 15
				-- text.TextAlign = "kAlignLeftMiddle"
				text.Location = Vector2(10, 85)
				if item.color ~= nil and item.color >= 1 and item.color <= 7 then
					text.TextColor = font_color[item.color]
				else
					text.TextColor = ARGB(255, 255, 255, 255)
				end
				text.Text = cloth_attribute[5].." "..math.floor(item.common.cBloodAdd + 0.5).."% (+"..math.floor(item.common.cBloodAdd_add + 0.5).."%)"
			end
			if item.gstLevel then
				tooltip_window_ui_contrast.shengxingHP.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/Compose/shengxing/lb_synthesis_conversion_hp_0"..item.gstLevel..".dds",Vector4(0, 0, 0, 0)),}
			end	
			location_pos = Vector2(location_pos.x, location_pos.y + 130)
		end
		
		--武器属性介绍宝石镶嵌
		
		local SkillWinCount = 0
		local n = 0
		if item.common.strength ~= -1 and item.common.subtype ~= 4 and not item.provisional_item_flag and ((item.common.type and item.common.type < 4) or (item.type and item.type < 4)) then
			local list = item.combineDetail
			if list then
				for i, v in ipairs(list) do
					local skill_win = ptr_cast(tooltip_window_ui_contrast.ctrl_skill:GetChildByIndex(i-1))
					skill_win.Visible = true
					local c = ptr_cast(skill_win:GetChildByIndex(0))
					c.Visible = true
					if skill_win and v ~= nil then
						FillSkill(skill_win, item, v)
						n = i
						SkillWinCount = SkillWinCount + 1
					else
						if item.common.isOpenQuality == 0 then
							skill_win.Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/ToolTips/wepskillmodlv_bar_engineer.dds",Vector4(20, 10, 10, 10)),
							}
						else
							skill_win.Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/ToolTips/wepskillmodlv_bar.dds",Vector4(20, 10, 10, 10)),
							}
						end
					end
				end
			end
		elseif ((item.common.type and item.common.type < 4) or (item.type and item.type < 4)) then
			local gunproperty = #item.gunproperty
			local num = n + gunproperty
			for i = 1, gunproperty do		
				if item.gunproperty[i] then
					local skill_win = ptr_cast(tooltip_window_ui_contrast.ctrl_skill:GetChildByIndex(i-1+n))
					if skill_win then
						skill_win.BackgroundColor = ARGB(0, 0, 0, 0)
						local c = ptr_cast(skill_win:GetChildByIndex(0))
						
						local l = ptr_cast(skill_win:GetChildByIndex(1))
						
						c.Visible = not (item.common.subtype == 4 or item.provisional_item_flag)
						
						skill_win.Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ToolTips/wepskillmodlv_bar_engineer_down.dds",Vector4(20, 10, 10, 10)),
						}
						
						l.Size = Vector2(300, 32)
						l.Location = Vector2(0, 0)
						-- l.TextAlign = "kAlignCenterMiddle"
						
						l.TextColor = ARGB(255, 91, 171, 42)
							
						l.Text = item.gunproperty[i][2]
					end
					SkillWinCount = SkillWinCount + 1
				end
			end
		end

		if SkillWinCount > 0 then
			tooltip_window_ui_contrast.ctrl_skill.Visible = true
			tooltip_window_ui_contrast.ctrl_skill.Location = location_pos
			tooltip_window_ui_contrast.ctrl_skill.Size = Vector2(302, SkillWinCount * 40 + 3)
			location_pos = Vector2(location_pos.x, location_pos.y + SkillWinCount * 40 + 3)
		end
		
		
		--道具说明
		if contrast_isToolAbout then
			tooltip_window_ui_contrast.ctrl_prop.Visible = true
			tooltip_window_ui.sign_1.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image(""),}
		tooltip_window_ui.sign_2.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image(""),}
		tooltip_window_ui.sign_3.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image(""),}
		tooltip_window_ui.sign_4.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image(""),}
		
		tooltip_window_ui.goods_1.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image(""),}
		tooltip_window_ui.goods_2.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image(""),}
		tooltip_window_ui.goods_3.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image(""),}
		tooltip_window_ui.goods_4.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image(""),}
		
		tooltip_window_ui.num_1.Text = lang:GetText("")
		tooltip_window_ui.num_2.Text = lang:GetText("")
		tooltip_window_ui.num_3.Text = lang:GetText("")
		tooltip_window_ui.num_4.Text = lang:GetText("")
		
		tooltip_window_ui.num_11.Text = lang:GetText("")
		tooltip_window_ui.num_12.Text = lang:GetText("")
		tooltip_window_ui.num_13.Text = lang:GetText("")
		tooltip_window_ui.num_14.Text = lang:GetText("")
			tooltip_window_ui_contrast.ctrl_prop.Location = location_pos
			tooltip_window_ui_contrast.txta_prop_info.Text = item.description
			location_pos = Vector2(location_pos.x, location_pos.y + 170 + 3)
		end
		
		--时间说明
		if isTime and item.timelimit then
			tooltip_window_ui_contrast.ctrl_time_tips.Visible = true
			tooltip_window_ui_contrast.ctrl_time_tips.Location = location_pos
			tooltip_window_ui_contrast.txta_time_info.Text = item.timelimit
			location_pos = Vector2(location_pos.x, location_pos.y + 30 + 3)
		end
		if item.suitId and item.suitId > 100 then
			location_pos = Vector2(location_pos.x, location_pos.y + 114 + 3)
			tooltip_window_ui_contrast.taozhuang.Visible = true
			if item.suitId == 101 then
				tooltip_window_ui_contrast.taozhuang_name.Text = lang:GetText("天神套装：")
			elseif item.suitId == 102 then
				tooltip_window_ui_contrast.taozhuang_name.Text = lang:GetText("银河套装：")
			elseif item.suitId == 103 then
				tooltip_window_ui_contrast.taozhuang_name.Text = lang:GetText("鸿运套装：")
			elseif item.suitId == 104 then
				tooltip_window_ui_contrast.taozhuang_name.Text = lang:GetText("朋克套装：")
			elseif item.suitId == 105 then
				tooltip_window_ui_contrast.taozhuang_name.Text = lang:GetText("巴洛克套装：")
			elseif item.suitId == 106 then
				tooltip_window_ui_contrast.taozhuang_name.Text = lang:GetText("新年套装：")
			elseif item.suitId == 107 then
				tooltip_window_ui_contrast.taozhuang_name.Text = lang:GetText("生化套装：")
			end
			tooltip_window_ui_contrast.taozhuang_des4.Text = lang:GetText("4件套:")..item.suitDetail.des4[1].."\n"..lang:GetText("4件套:")..item.suitDetail.des4[2]
			if item.suitId == 106 then
				tooltip_window_ui_contrast.taozhuang_des6.Text = lang:GetText(" ")
			else
				tooltip_window_ui_contrast.taozhuang_des6.Text = lang:GetText("6件套:")..item.suitDetail.des6[1].."\n"..lang:GetText("6件套:")..item.suitDetail.des6[2]
			end
			if L_LobbyMain.CharactersInfo_rpc_data.items.putSuitId == item.suitId and L_LobbyMain.CharactersInfo_rpc_data.items.suitCount == 3 then
				tooltip_window_ui_contrast.taozhuang_des4.TextColor = ARGB(255, 255, 180, 104)
				tooltip_window_ui_contrast.taozhuang_des6.TextColor = ARGB(255, 255, 180, 104)
			else
				if L_LobbyMain.CharactersInfo_rpc_data.items.putSuitId == item.suitId and (L_LobbyMain.CharactersInfo_rpc_data.items.suitCount == 1 or L_LobbyMain.CharactersInfo_rpc_data.items.suitCount == 2) then
					tooltip_window_ui_contrast.taozhuang_des4.TextColor = ARGB(255, 255, 180, 104)
				else
					tooltip_window_ui_contrast.taozhuang_des4.TextColor = ARGB(255, 255, 255, 255)
					tooltip_window_ui_contrast.taozhuang_des6.TextColor = ARGB(255, 255, 255, 255)
				end
			end
			tooltip_window_ui_contrast.taozhuang.Location = Vector2(9, location_pos.y + 10 - 125)
		else
			-- location_pos = Vector2(location_pos.x, location_pos.y + 114 + 3)
			tooltip_window_ui_contrast.taozhuang.Visible = false
		end
		
		--设置整个窗口大小
		tooltip_window_ui_contrast.ctrl_root.Size = Vector2(320, location_pos.y + 10)
	end
end

--绘制属性数据
function FillSkill(control, item, v)
	local c = ptr_cast(control:GetChildByIndex(0))
	local l = ptr_cast(control:GetChildByIndex(1))
	
	control.BackgroundColor = ARGB(255, 255, 255, 255)
	
	l.Size = Vector2(240, 40)
	l.Location = Vector2(40, -5)
	
	if v and item then
		if v.state == 0 then
			control.Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ToolTips/wepskillmodlv_engineer_disabled.dds",Vector4(20, 10, 10, 10)),
			}
		else
			if v.level ~= 0 then
				if item.common.isOpenQuality == 0 then
					control.Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ToolTips/wepskillmodlv_bar_engineer_down.dds",Vector4(20, 10, 10, 10)),
					}
				else
					control.Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ToolTips/wepskillmodlv_bar_down.dds",Vector4(20, 10, 10, 10)),
					}
				end
			else
				if item.common.isOpenQuality == 0 then
					control.Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ToolTips/wepskillmodlv_bar_engineer.dds",Vector4(20, 10, 10, 10)),
					}
				else
					control.Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ToolTips/wepskillmodlv_bar.dds",Vector4(20, 10, 10, 10)),
					}
				end
			end
		end
	
		local name
		if item.common.type == 1 then
			name = "wepskillmodlv"..v.level..".tga"
		else
			name = "avatarskillmod"..v.level..".tga"
		end
		c.Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/ibt_icon/"..name,Vector4(10, 10, 10, 10)),
		}
		
		if v.level == 1 then
			l.TextColor = ARGB(255, 91, 171, 42)
		elseif v.level == 2 then
			l.TextColor = ARGB(255, 0, 173, 255)
		elseif v.level == 3 then
			l.TextColor = ARGB(255, 158, 48, 255)
		else
			l.TextColor = ARGB(255, 91, 171, 42)
		end
		
		l.Text = v.desc
	end
end
-----------------------------------------------------------------------------------
--For DailyCheck
function FillToolTipsDailyCheckWindow(index)
	setup_tooltips_window(L_DailyCheck.DailyCheck.content)
	tooltip_window_ui.ctrl_root.Visible = false
	ResetToolTipsWindow()

	local location_pos = Vector2(9, 49)
	tooltip_window_ui.lbl_title.Visible = true
	tooltip_window_ui.lbl_title.Location = Vector2(7, 9)
	if index == 3 then
		tooltip_window_ui.lbl_title.Text = lang:GetText("初级签到礼盒")
		tooltip_window_ui.lbl_title.TextColor = ARGB(255, 128, 239, 147)
	elseif index == 7 then
		tooltip_window_ui.lbl_title.Text = lang:GetText("中级签到礼盒")
		tooltip_window_ui.lbl_title.TextColor = ARGB(255, 101, 179, 239)
	elseif index == 14 then
		tooltip_window_ui.lbl_title.Text = lang:GetText("高级签到礼盒")
		tooltip_window_ui.lbl_title.TextColor = ARGB(255, 181, 58, 212)
	elseif index == 21 then
		tooltip_window_ui.lbl_title.Text = lang:GetText("特级签到礼盒")
		tooltip_window_ui.lbl_title.TextColor = ARGB(255, 205, 43, 55)
	elseif index == 100 then
		tooltip_window_ui.lbl_title.Text = lang:GetText("持续增幅能源")
		tooltip_window_ui.lbl_title.TextColor = ARGB(255, 205, 43, 55)
	else
		tooltip_window_ui.lbl_title.Text = lang:GetText("豪华签到礼盒")
		tooltip_window_ui.lbl_title.TextColor = ARGB(255, 205, 43, 55)
	end
	--道具说明
	tooltip_window_ui.ctrl_prop.Visible = true
	tooltip_window_ui.ctrl_prop.Location = location_pos
	if index == 3 then
		tooltip_window_ui.txta_prop_info.Text = lang:GetText("累计签到3天获得的礼盒。")
		tooltip_window_ui.sign_1.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_bg_1.dds", Vector4(8 , 8, 8, 8)),}
		tooltip_window_ui.sign_2.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image(""),}
		tooltip_window_ui.sign_3.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image(""),}
		tooltip_window_ui.sign_4.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image(""),}
		
		tooltip_window_ui.goods_1.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/medal.tga", Vector4(8 , 8, 8, 8)),}
		tooltip_window_ui.goods_2.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image(""),}
		tooltip_window_ui.goods_3.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image(""),}
		tooltip_window_ui.goods_4.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image(""),}
		
		tooltip_window_ui.num_1.Text = lang:GetText("×6")
		tooltip_window_ui.num_2.Text = lang:GetText("")
		tooltip_window_ui.num_3.Text = lang:GetText("")
		tooltip_window_ui.num_4.Text = lang:GetText("")
		
		tooltip_window_ui.num_11.Text = lang:GetText("  勋章")
		tooltip_window_ui.num_12.Text = lang:GetText("")
		tooltip_window_ui.num_13.Text = lang:GetText("")
		tooltip_window_ui.num_14.Text = lang:GetText("")
	elseif index == 7 then
		tooltip_window_ui.txta_prop_info.Text = lang:GetText("累计签到7天获得的礼盒。")
		
		tooltip_window_ui.sign_1.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_bg_1.dds", Vector4(8 , 8, 8, 8)),}
		tooltip_window_ui.sign_2.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image(""),}
		tooltip_window_ui.sign_3.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image(""),}
		tooltip_window_ui.sign_4.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image(""),}
		
		tooltip_window_ui.goods_1.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/upgardmod.tga", Vector4(8 , 8, 8, 8)),}
		tooltip_window_ui.goods_2.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image(""),}
		tooltip_window_ui.goods_3.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image(""),}
		tooltip_window_ui.goods_4.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image(""),}
		
		tooltip_window_ui.num_1.Text = lang:GetText("×4")
		tooltip_window_ui.num_2.Text = lang:GetText("")
		tooltip_window_ui.num_3.Text = lang:GetText("")
		tooltip_window_ui.num_4.Text = lang:GetText("")
		
		tooltip_window_ui.num_11.Text = lang:GetText("强化部件")
		tooltip_window_ui.num_12.Text = lang:GetText("")
		tooltip_window_ui.num_13.Text = lang:GetText("")
		tooltip_window_ui.num_14.Text = lang:GetText("")
	elseif index == 14 then
		tooltip_window_ui.txta_prop_info.Text = lang:GetText("累计签到14天获得的礼盒。打开后可随机获得以下物品中的一件：")
		
		tooltip_window_ui.sign_1.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_bg_1.dds", Vector4(8 , 8, 8, 8)),}
		tooltip_window_ui.sign_2.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_bg_1.dds", Vector4(8 , 8, 8, 8)),}
		tooltip_window_ui.sign_3.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_bg_1.dds", Vector4(8 , 8, 8, 8)),}
		tooltip_window_ui.sign_4.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image(""),}
		
		tooltip_window_ui.goods_1.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/failnoback.tga", Vector4(8 , 8, 8, 8)),}
		tooltip_window_ui.goods_2.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/wepskillmodlv3.tga", Vector4(8 , 8, 8, 8)),}
		tooltip_window_ui.goods_3.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/avatarskillmod3.tga", Vector4(8 , 8, 8, 8)),}
		tooltip_window_ui.goods_4.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image(""),}
		
		tooltip_window_ui.num_1.Text = lang:GetText("×5")
		tooltip_window_ui.num_2.Text = lang:GetText("x1")
		tooltip_window_ui.num_3.Text = lang:GetText("x1")
		tooltip_window_ui.num_4.Text = lang:GetText("")
		
		tooltip_window_ui.num_11.Text = lang:GetText("安定芯片")
		tooltip_window_ui.num_12.Text = lang:GetText("武器属性\n部件LV3")
		tooltip_window_ui.num_13.Text = lang:GetText("服饰属性\n部件LV3")
		tooltip_window_ui.num_14.Text = lang:GetText("")
		
	elseif index == 21 then
		tooltip_window_ui.txta_prop_info.Text = lang:GetText("累计签到21天获得的礼盒。")
		
		tooltip_window_ui.sign_1.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_bg_1.dds", Vector4(8 , 8, 8, 8)),}
		tooltip_window_ui.sign_2.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_bg_1.dds", Vector4(8 , 8, 8, 8)),}
		tooltip_window_ui.sign_3.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_bg_1.dds", Vector4(8 , 8, 8, 8)),}
		tooltip_window_ui.sign_4.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image(""),}
		
		tooltip_window_ui.goods_1.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/medal.tga", Vector4(8 , 8, 8, 8)),}
		tooltip_window_ui.goods_2.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/upgardmod.tga", Vector4(8 , 8, 8, 8)),}
		tooltip_window_ui.goods_3.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/addsucess.tga", Vector4(8 , 8, 8, 8)),}
		tooltip_window_ui.goods_4.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image(""),}
		
		tooltip_window_ui.num_1.Text = lang:GetText("×60")
		tooltip_window_ui.num_2.Text = lang:GetText("x30")
		tooltip_window_ui.num_3.Text = lang:GetText("x10")
		tooltip_window_ui.num_4.Text = lang:GetText("")
		
		tooltip_window_ui.num_11.Text = lang:GetText("  勋章")
		tooltip_window_ui.num_12.Text = lang:GetText("强化部件")
		tooltip_window_ui.num_13.Text = lang:GetText("增幅能源")
		tooltip_window_ui.num_14.Text = lang:GetText("")
	elseif index == 100 then
		tooltip_window_ui.txta_prop_info.Text = lang:GetText("使用后24小时内增加强化成功率10%，与增幅能源一起使用时，效果叠加。")
		tooltip_window_ui.sign_1.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image(""),}
		tooltip_window_ui.sign_2.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image(""),}
		tooltip_window_ui.sign_3.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image(""),}
		tooltip_window_ui.sign_4.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image(""),}
		
		tooltip_window_ui.goods_1.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image(""),}
		tooltip_window_ui.goods_2.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image(""),}
		tooltip_window_ui.goods_3.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image(""),}
		tooltip_window_ui.goods_4.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image(""),}
		
		tooltip_window_ui.num_1.Text = lang:GetText("")
		tooltip_window_ui.num_2.Text = lang:GetText("")
		tooltip_window_ui.num_3.Text = lang:GetText("")
		tooltip_window_ui.num_4.Text = lang:GetText("")
		
		tooltip_window_ui.num_11.Text = lang:GetText("")
		tooltip_window_ui.num_12.Text = lang:GetText("")
		tooltip_window_ui.num_13.Text = lang:GetText("")
		tooltip_window_ui.num_14.Text = lang:GetText("")
	else
		tooltip_window_ui.txta_prop_info.Text = lang:GetText("当月签到全勤获得的礼盒。")
		
		tooltip_window_ui.sign_1.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_bg_1.dds", Vector4(8 , 8, 8, 8)),}
		tooltip_window_ui.sign_2.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_bg_1.dds", Vector4(8 , 8, 8, 8)),}
		tooltip_window_ui.sign_3.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_bg_1.dds", Vector4(8 , 8, 8, 8)),}
		tooltip_window_ui.sign_4.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_bg_1.dds", Vector4(8 , 8, 8, 8)),}
		
		tooltip_window_ui.goods_1.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/exsuccess_01.tga", Vector4(8 , 8, 8, 8)),}
		tooltip_window_ui.goods_2.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/exsuccess_01.tga", Vector4(8 , 8, 8, 8)),}
		tooltip_window_ui.goods_3.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/exsuccess_01.tga", Vector4(8 , 8, 8, 8)),}
		tooltip_window_ui.goods_4.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/exsuccess_01.tga", Vector4(8 , 8, 8, 8)),}
		
		tooltip_window_ui.num_1.Text = lang:GetText("x1")
		tooltip_window_ui.num_2.Text = lang:GetText("x1")
		tooltip_window_ui.num_3.Text = lang:GetText("x1")
		tooltip_window_ui.num_4.Text = lang:GetText("x1")
		
		tooltip_window_ui.num_11.Text = lang:GetText("增幅能源\n  LV6")
		tooltip_window_ui.num_12.Text = lang:GetText("增幅能源\n  LV7")
		tooltip_window_ui.num_13.Text = lang:GetText("增幅能源\n  LV8")
		tooltip_window_ui.num_14.Text = lang:GetText("增幅能源\n  LV9")
	end	
	location_pos = Vector2(location_pos.x, location_pos.y + 170)
	tooltip_window_ui.ctrl_root.Size = Vector2(320, location_pos.y + 10)
end

--FOR BUFF INFO
function FillToolTipsBuffInfoWindow(data, index, name, des, text)
	setup_tooltips_window(gui)
	tooltip_window_ui.ctrl_root.Visible = false
	ResetToolTipsWindow()
	
	if data then
		isShowTimeIcon = true
		isToolAbout = true
		tooltip_window_ui.ctrl_activate.Visible = false
		
		local location_pos = Vector2(9, 49)
		tooltip_window_ui.lbl_title.Location = Vector2(7, 9)
		tooltip_window_ui.lbl_title.TextColor = ARGB(255, 255, 255, 255)
		
		tooltip_window_ui.lbl_title.Text = data[2]
		
		
		if isShowTimeIcon and data[4] ~= nil and data[5] ~= nil then
			if data[5] == 2 then
				tooltip_window_ui.ctrl_time.Visible = true
				tooltip_window_ui.ctrl_time.Location = location_pos
				location_pos = Vector2(location_pos.x, location_pos.y + 48)
				local time_hour = (data[4] - data[4] % 60) / 60
				if time_hour > 24 then
					local time_day = (time_hour - time_hour % 24) / 24
					local hour = time_hour % 24
					if hour ~= 0 then
						tooltip_window_ui.lbl_icon3_timeds1.Text = lang:GetText("剩余") .. time_day .. lang:GetText("天") .. hour .. lang:GetText("小时")
					else
						tooltip_window_ui.lbl_icon3_timeds1.Text = lang:GetText("剩余") .. time_day .. lang:GetText("天")
					end
				elseif time_hour > 0 then
					tooltip_window_ui.lbl_icon3_timeds1.Text = lang:GetText("剩余") .. time_hour .. lang:GetText("小时")
				else
					tooltip_window_ui.lbl_icon3_timeds1.Text = lang:GetText("剩余") .. data[4] % 60 .. lang:GetText("分钟")
				end
			elseif data[5] == 0 then
				tooltip_window_ui.lbl_icon3_timeds1.Text = lang:GetText("永久使用")
			end
			tooltip_window_ui.ctrl_icon_timebg3.Visible = true
		end
		if isToolAbout and data[3] ~= nil then
			tooltip_window_ui.ctrl_prop.Visible = true
			tooltip_window_ui.sign_1.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image(""),}
		tooltip_window_ui.sign_2.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image(""),}
		tooltip_window_ui.sign_3.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image(""),}
		tooltip_window_ui.sign_4.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image(""),}
		
		tooltip_window_ui.goods_1.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image(""),}
		tooltip_window_ui.goods_2.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image(""),}
		tooltip_window_ui.goods_3.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image(""),}
		tooltip_window_ui.goods_4.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image(""),}
		
		tooltip_window_ui.num_1.Text = lang:GetText("")
		tooltip_window_ui.num_2.Text = lang:GetText("")
		tooltip_window_ui.num_3.Text = lang:GetText("")
		tooltip_window_ui.num_4.Text = lang:GetText("")
		
		tooltip_window_ui.num_11.Text = lang:GetText("")
		tooltip_window_ui.num_12.Text = lang:GetText("")
		tooltip_window_ui.num_13.Text = lang:GetText("")
		tooltip_window_ui.num_14.Text = lang:GetText("")
			tooltip_window_ui.ctrl_prop.Location = location_pos
			
			tooltip_window_ui.txta_prop_info.Text = data[3]
		
			location_pos = Vector2(location_pos.x, location_pos.y + 170)
		end
		--设置整个窗口大小
		tooltip_window_ui.ctrl_root.Size = Vector2(320, location_pos.y + 10)
	else
		isShowTimeIcon = true
		isToolAbout = true
		tooltip_window_ui.ctrl_activate.Visible = true
		tooltip_window_ui.ctrl_activate.Text = lang:GetText("（未激活，无法使用）").."\n"..text
		
		local location_pos = Vector2(9, 49)
		tooltip_window_ui.lbl_title.Location = Vector2(7, 9)
		tooltip_window_ui.lbl_title.TextColor = ARGB(255, 255, 255, 255)
		tooltip_window_ui.lbl_title.Text = name
		
		tooltip_window_ui.ctrl_prop.Visible = true
		tooltip_window_ui.sign_1.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image(""),}
		tooltip_window_ui.sign_2.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image(""),}
		tooltip_window_ui.sign_3.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image(""),}
		tooltip_window_ui.sign_4.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image(""),}
		
		tooltip_window_ui.goods_1.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image(""),}
		tooltip_window_ui.goods_2.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image(""),}
		tooltip_window_ui.goods_3.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image(""),}
		tooltip_window_ui.goods_4.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image(""),}
		
		tooltip_window_ui.num_1.Text = lang:GetText("")
		tooltip_window_ui.num_2.Text = lang:GetText("")
		tooltip_window_ui.num_3.Text = lang:GetText("")
		tooltip_window_ui.num_4.Text = lang:GetText("")
		
		tooltip_window_ui.num_11.Text = lang:GetText("")
		tooltip_window_ui.num_12.Text = lang:GetText("")
		tooltip_window_ui.num_13.Text = lang:GetText("")
		tooltip_window_ui.num_14.Text = lang:GetText("")
		tooltip_window_ui.ctrl_prop.Location = location_pos
		tooltip_window_ui.txta_prop_info.Text = des
		location_pos = Vector2(location_pos.x, location_pos.y + 170)
		
		--设置整个窗口大小
		tooltip_window_ui.ctrl_root.Size = Vector2(320, location_pos.y + 10)
	end
end

--VIP礼包和魔罐 characters.lua
function FillToolTipsVIPPresent(index, parent_window, item_list)
	setup_tooltips_window(parent_window)
	tooltip_window_ui.ctrl_root.Visible = false
	ResetToolTipsWindow()
	if item_list and tooltip_window_ui then
		local items = item_list
		if items and items[index] then
			--武器
			if items[index].common.type == 1 then
				--1主武器 2副武器 3近战武器
				if items[index].common.seq == 1 or items[index].common.seq == 2 or items[index].common.seq == 3 then
					isShowPerformance = true
					isFight = true
					isBinding = true
					isStrengthen = true
				--投掷武器
				elseif items[index].common.seq == 4 then
					isFight = true
					isBinding = true
					isStrengthen = true
				end
			--套装 配饰
			elseif items[index].common.type == 2 or items[index].common.type == 3 then
				isFight = true
				isBinding = true
				isClothAttribute = true
				isStrengthen = true
			--道具
			elseif items[index].common.type > 3 then
				isToolAbout = true
			end
			isTime = true
			FillAllFromIndex(items[index],false)
		end
	end
end

--传入item
function FillToolTipsVIPPresent_item(parent_window, item)
	setup_tooltips_window(parent_window)
	tooltip_window_ui.ctrl_root.Visible = false
	ResetToolTipsWindow()
	if item and tooltip_window_ui then
		--武器
		if item.common.type == 1 then
			--1主武器 2副武器 3近战武器
			if item.common.seq == 1 or item.common.seq == 2 or item.common.seq == 3 then
				isShowPerformance = true
				isFight = true
				isBinding = true
				isStrengthen = true
			--投掷武器
			elseif item.common.seq == 4 then
				isFight = true
				isBinding = true
				isStrengthen = true
			end
		--套装 配饰
		elseif item.common.type == 2 or item.common.type == 3 then
			isFight = true
			isBinding = true
			isClothAttribute = true
			isStrengthen = true
		--道具
		elseif item.common.type > 3 then
			isToolAbout = true
		end
		isTime = true
		FillAllFromIndex(item,false)
	end
end

--个人信息的经验 PersonalInfo.lua 和 LobbyMain.lua
function FillToolUserLevelWindow(value1, value2)
	setup_tooltips_window(gui)
	tooltip_window_ui.ctrl_root.Visible = false
	ResetToolTipsWindow()
	
	if value1 and value2 then
		local location_pos = Vector2(9, 49)
		tooltip_window_ui.lbl_title.Location = Vector2(7, 9)
		tooltip_window_ui.lbl_title.TextColor = ARGB(255, 255, 255, 255)
		tooltip_window_ui.lbl_title.Text = lang:GetText("经验:")..value1.." / "..value2

		--设置整个窗口大小
		tooltip_window_ui.ctrl_root.Size = Vector2(320, location_pos.y + 10)
	elseif value1 and value2 == nil then
		local location_pos = Vector2(9, 49)
		tooltip_window_ui.lbl_title.Location = Vector2(7, 9)
		tooltip_window_ui.lbl_title.TextColor = ARGB(255, 255, 255, 255)
		if value1 == -1 then
			tooltip_window_ui.lbl_title.Text = lang:GetText("剩余时间: 永久")
		elseif value1 < 60 then
			tooltip_window_ui.lbl_title.Text = lang:GetText("剩余时间: ")..value1..lang:GetText("分钟")
		elseif value1 < 1440 then
			tooltip_window_ui.lbl_title.Text = lang:GetText("剩余时间: ")..(math.ceil(value1/60))..lang:GetText("小时")
		else
			tooltip_window_ui.lbl_title.Text = lang:GetText("剩余时间: ")..(math.ceil(value1/1440))..lang:GetText("天")
		end

		--设置整个窗口大小
		tooltip_window_ui.ctrl_root.Size = Vector2(320, location_pos.y + 10)
	end
end

--在线奖励 state_lobby_new.lua
function FillToolTipsPresentWindow(index)
	setup_tooltips_window(Present.content)
	tooltip_window_ui.ctrl_root.Visible = false
	ResetToolTipsWindow()
	if L_LobbyMain.OL_Award_List and tooltip_window_ui then
		local items = L_LobbyMain.OL_Award_List
		if items and items[index] then
			isToolAbout = true
			isTime = true
			FillAllFromIndex(items[index],false)
		end
	end
end

--equip_type 装备类型
local function FillContrasEquip(equip_type)
	if equip_type > 0 and equip_type < 8 then
		if L_LobbyMain.Characters_BagInfo_rpc_data and tooltip_window_ui_contrast then
			local items = L_LobbyMain.Characters_BagInfo_rpc_data.items.weapons
			if equip_type > 4 then
				items = L_LobbyMain.Characters_BagInfo_rpc_data.items.costume
			end
			if items then
				--武器
				if equip_type > 0 and equip_type < 4 then
					if items[equip_type].common then
						contrast_isShowTimeIcon = true
						contrast_isShowDurableIcon = true
						contrast_isShowPerformance = true
						contrast_isBinding = true
						contrast_isFight = true
						contrast_isStrengthen = true
						isCanShowContrast = true
						FillAllFromIndexContrast(items[equip_type])
					else
						isCanShowContrast = false
					end
				elseif equip_type == 4 then
					if items[equip_type].common then
						contrast_isShowTimeIcon = true
						contrast_isShowDurableIcon = true
						contrast_isBinding = true
						contrast_isFight = true
						contrast_isStrengthen = true
						isCanShowContrast = true
						FillAllFromIndexContrast(items[equip_type])
					else
						isCanShowContrast = false
					end
				--套装 配饰	
				elseif equip_type == 5 or equip_type == 6 or equip_type == 7 then
					contrast_isShowTimeIcon = true
					contrast_isBinding = true
					contrast_isFight = true
					contrast_isStrengthen = true
					contrast_isClothAttribute = true
					isCanShowContrast = true
					FillAllFromIndexContrast(items[equip_type-4])
					if equip_type == 6 or equip_type == 7 then
						if items[equip_type-4].isDefault == 0 then
							ShowContrast = false
						else
							ShowContrast = true
						end
					end
				end
			end
		end
	end
end

--大礼包奖励 Present.lua 幸运礼盒
function FillToolBigPresentWindow(index, parent_window, item_list)
	setup_tooltips_window(parent_window)
	tooltip_window_ui.ctrl_root.Visible = false
	ResetToolTipsWindow()
	if item_list and tooltip_window_ui then
		local items = item_list
		if items and items[index] then
			isShowPrice = true
			--武器
			if items[index].type == 1 then
				--1主武器 2副武器 3近战武器
				if items[index].common.seq == 1 or items[index].common.seq == 2 or items[index].common.seq == 3 then
					isShowPerformance = true
					isFight = true
					isStrengthen = true
					isBinding = true
					isNow = true
				--投掷武器
				elseif items[index].common.seq == 4 then
					isFight = true
					isStrengthen = true
					isBinding = true
					isNow = true
				end
			--套装 配饰
			elseif items[index].type == 2 or items[index].type == 3 then
				isFight = true
				isClothAttribute = true
				isStrengthen = true
				isBinding = true
				isNow = true
			--道具
			elseif items[index].type > 3 then
				isToolAbout = true
			end
			isTime = true
			FillAllFromIndex(items[index],false)
		end
	end
end

--邮件
function FillMailWindow(index, parent_window)
	setup_tooltips_window(parent_window)
	tooltip_window_ui.ctrl_root.Visible = false
	ResetToolTipsWindow()
	
	if L_Mail.rpc_date and tooltip_window_ui then
		local items = L_Mail.rpc_date
		if items and items[index] then
			--武器
			if items[index].common.type == 1 then
				--1主武器 2副武器 3近战武器
				if items[index].common.seq == 1 or items[index].common.seq == 2 or items[index].common.seq == 3 then
					isShowTimeIcon = true
					isShowDurableIcon = true
					isShowPerformance = true
					isBinding = true
					isFight = true
					isStrengthen = true
					isNow = true
				--投掷武器
				elseif items[index].common.seq == 4 then
					isShowTimeIcon = true
					isShowDurableIcon = true
					isBinding = true
					isFight = true
					isStrengthen = true
					isNow = true
				end
			--套装
			elseif items[index].common.type == 2 then
				isShowTimeIcon = true
				isBinding = true
				isFight = true
				isStrengthen = true
				isClothAttribute = true
				isNow = true
			--配饰
			elseif items[index].common.type == 3 then
				isShowTimeIcon = true
				isBinding = true
				isFight = true
				isStrengthen = true
				isClothAttribute = true
				isNow = true
			--道具
			elseif items[index].common.type > 3 then
				isShowTimeIcon = true
				isToolAbout = true
				isBindingEx = true
			end
			FillAllFromIndex(items[index],false)
		end
	end
end

--part 1:仓库 2:商城
--index 索引
function FillToolTipsWindow(part, index, parent_window)
	setup_tooltips_window(gui)
	setup_tooltips_window_contrast(gui)
	--刚开始隐藏
	tooltip_window_ui.ctrl_root.Visible = false
	tooltip_window_ui_contrast.ctrl_root.Visible = false
	
	ResetToolTipsWindow()
	ResetToolTipsWindowContrast()

	--仓库tooltips内容显示
	if part == 1 then
		if L_LobbyMain.CharactersIB_rpc_data and tooltip_window_ui then
			local items = L_LobbyMain.CharactersIB_rpc_data.items
			if items and items[index] then
				--武器
				if items[index].common.type == 1 then					
					--1主武器 2副武器 3近战武器
					if items[index].common.seq == 1 or items[index].common.seq == 2 or items[index].common.seq == 3 then
						isShowTimeIcon = true
						isShowDurableIcon = true
						isShowPerformance = true
						isBinding = true
						isFight = true
						isStrengthen = true
						isNow = true
						contrast_isNow = true
						FillContrasEquip(items[index].common.seq)
					--投掷武器
					elseif items[index].common.seq == 4 then
						isShowTimeIcon = true
						isShowDurableIcon = true
						isBinding = true
						isFight = true
						isStrengthen = true
						isNow = true
						contrast_isNow = true
						FillContrasEquip(4)
					end
				--套装
				elseif items[index].common.type == 2 then
					isShowTimeIcon = true
					isBinding = true
					isFight = true
					isStrengthen = true
					isClothAttribute = true
					isNow = true
					contrast_isNow = true
					FillContrasEquip(5)
				--配饰
				elseif items[index].common.type == 3 then
					isShowTimeIcon = true
					isBinding = true
					isFight = true
					isStrengthen = true
					isClothAttribute = true
					isNow = true
					contrast_isNow = true
					if items[index].common.seq == 2 then
						FillContrasEquip(6)
					elseif items[index].common.seq == 3 then
						FillContrasEquip(7)
					end
				--道具
				elseif items[index].common.type > 3 then
					isBindingEx = true
					isShowTimeIcon = true
					isToolAbout = true
				end
				FillAllFromIndex(items[index],true)
			end
		end
	--商城tooltips内容显示
	elseif part == 2 then
		if L_LobbyMain.ShoppingMallIB_rpc_data and tooltip_window_ui then
			local items = L_LobbyMain.ShoppingMallIB_rpc_data.items
			if items and items[index] then
				isShowPrice = true
				--武器
				if items[index].common.type == 1 then
					--1主武器 2副武器 3近战武器
					if items[index].common.seq == 1 or items[index].common.seq == 2 or items[index].common.seq == 3 then
						isShowPerformance = true
						isFight = true
						isStrengthen = true
						isBinding = true
						isNow = true
						contrast_isNow = true
						FillContrasEquip(items[index].common.seq)
					--投掷武器
					elseif items[index].common.seq == 4 then
						isFight = true
						isStrengthen = true
						isBinding = true
						isNow = true
						contrast_isNow = true
						FillContrasEquip(4)
					end
				--套装 配饰
				elseif items[index].common.type == 2 or items[index].common.type == 3 then
					isFight = true
					isClothAttribute = true
					isStrengthen = true
					isBinding = true
					isNow = true
					contrast_isNow = true
					if items[index].common.seq == 1 then
						FillContrasEquip(5)
					elseif items[index].common.seq == 2 then
						FillContrasEquip(6)
					elseif items[index].common.seq == 3 then
						FillContrasEquip(7)
					end
				--道具
				elseif items[index].common.type > 3 then
					isToolAbout = true
				end
				FillAllFromIndex(items[index],false)
			end
		end
	--仓库背包Tooltips内容显示
	elseif part == 3 then
		if L_LobbyMain.Characters_BagInfo_rpc_data and tooltip_window_ui then
			local items = L_LobbyMain.Characters_BagInfo_rpc_data.items.weapons
			if index > 4 then
				items = L_LobbyMain.Characters_BagInfo_rpc_data.items.costume
			end
			if items then
				--武器
				if index > 0 and index < 4 then
					isShowTimeIcon = true
					isShowDurableIcon = true
					isShowPerformance = true
					isBinding = true
					isFight = true
					isStrengthen = true
					FillAllFromIndex(items[index],false)
				elseif index == 4 then
					isShowTimeIcon = true
					isShowDurableIcon = true
					isBinding = true
					isFight = true
					isStrengthen = true
					FillAllFromIndex(items[index],false)
				--套装 配饰	
				elseif index == 5 or index == 6 or index == 7 then
					isShowTimeIcon = true
					isBinding = true
					isFight = true
					isStrengthen = true
					isClothAttribute = true
					FillAllFromIndex(items[index-4],false)
				end
			end
		end
	--商店背包Tooltips内容显示
	elseif part == 4 then
		if L_LobbyMain.ShoppingMallIB_rpc_data and tooltip_window_ui then
			local items = L_LobbyMain.CharactersCartInfo[L_LobbyMain.current_choose_class]
			if items and items[index] then
				isShowPrice = true
				--武器
				if items[index].common.type == 1 then
					--主武器 副武器 近战
					if items[index].common.seq == 1 or items[index].common.seq == 2 or items[index].common.seq == 3 then
						isShowPerformance = true
						isFight = true
						isStrengthen = true
						isBinding = true
					--投掷武器
					elseif items[index].common.seq == 4 then
						isFight = true
						isStrengthen = true
						isBinding = true
					end
				--套装 配饰 道具
				elseif items[index].common.type == 2 or items[index].common.type == 3 or items[index].common.type == 4 then
					isFight = true
					isClothAttribute = true
					isStrengthen = true
					isBinding = true
				end
				FillAllFromIndex(items[index],false)
			end
		end
	--合成系统
	elseif part == 5 then	
		if L_Compose.rpc_date and tooltip_window_ui then
			local items = L_Compose.rpc_date
			if items and items[index] then
				--武器
				if items[index].common.type == 1 then					
					--1主武器 2副武器 3近战武器
					if items[index].common.seq == 1 or items[index].common.seq == 2 or items[index].common.seq == 3 then
						isShowTimeIcon = true
						isShowDurableIcon = true
						isShowPerformance = true
						isBinding = true
						isFight = true
						isStrengthen = true
					--投掷武器
					elseif items[index].common.seq == 4 then
						isShowTimeIcon = true
						isShowDurableIcon = true
						isBinding = true
						isFight = true
						isStrengthen = true
					end
				--套装
				elseif items[index].common.type == 2 then
					isShowTimeIcon = true
					isBinding = true
					isFight = true
					isStrengthen = true
					isClothAttribute = true
				--配饰
				elseif items[index].common.type == 3 then
					isShowTimeIcon = true
					isBinding = true
					isFight = true
					isStrengthen = true
					isClothAttribute = true
				--道具
				elseif items[index].common.type > 3 then
					isShowTimeIcon = true
					isToolAbout = true
				end
				FillAllFromIndex(items[index],false)
			end
		end
	end
end
-----------------------------------------------------------------------------------