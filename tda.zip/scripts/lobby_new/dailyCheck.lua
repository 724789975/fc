module("L_DailyCheck",package.seeall)

local Meirimodal = nil
local Getgiftmodel = nil
Check_List = nil
Tomorrow_Num = -1
NowDay = nil
myNum = {"0","1","2","3","4","5","6","7","8","9"}
times = 0
local my_num = {-1,-1,-1}
local freeCheck = {0,3,3,4,4,5,5}
local freeCheckTimes = 0
local MonthCheckTimes = 0
local month_days = 0
DailyCheck = Gui.Create()
{
	Gui.Control "content"
	{
		Size = Vector2(832, 604),
		Dock = "kDockCenter",
		BackgroundColor = ARGB(0, 0, 0, 0),
		
		Gui.Control
		{
			Size = Vector2(816, 593),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Location = Vector2(0, 13),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/dailycheck/main_bar01.dds",Vector4(20, 32, 36, 20)),
			},

			Gui.Control
			{
				Size = Vector2(256, 476),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Location = Vector2(15, 100),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/dailycheck/lb_lucky_bar.dds",Vector4(64,0,64,0)),
				},
				Gui.Label "today_num"
				{
					Size = Vector2(212, 112),
					Location = Vector2(22, 0),
					BackgroundColor = ARGB(255, 255, 0, 0),
					Text = "",
					FontSize = 80,
					TextAlign = "kAlignCenterMiddle",
					TextColor = ARGB(255, 255, 162,0),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = nil,
					},
				},
				Gui.Label "my_num"
				{
					Size = Vector2(233, 46),
					Location = Vector2(11, 154),
					BackgroundColor = ARGB(255, 255, 0, 0),
					Text = "",
					FontSize = 30,
					TextAlign = "kAlignCenterMiddle",
					TextColor = ARGB(255, 213, 185,183),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = nil,
					},
					Gui.ChangeControl "MY_NUMS1"
					{
						Size = Vector2(20, 24),
						Normsize = Vector2(20, 24),
						Location = Vector2(30, 15),
						NormLocation = Vector2(30, 15),
						BackgroundColor = ARGB(255, 255, 255, 255),
					},
					Gui.ChangeControl "MY_NUMS2"
					{
						Size = Vector2(20, 24),
						Normsize = Vector2(20, 24),
						Location = Vector2(110, 15),
						NormLocation = Vector2(110, 15),
						BackgroundColor = ARGB(255, 255, 255, 255),
					},
					Gui.ChangeControl "MY_NUMS3"
					{
						Size = Vector2(20, 24),
						Normsize = Vector2(20, 24),
						Location = Vector2(190, 15),
						NormLocation = Vector2(190, 15),
						BackgroundColor = ARGB(255, 255, 255, 255),
					},
				},
				Gui.ComboBox "yuceshuzi"
				{
					Size = Vector2(180, 36),
					FontSize = 24,
					Readonly = true,
					Location = Vector2(11, 238),
					TextColor = ARGB(255, 255, 186, 0),
					TextAlign = "kAlignCenterMiddle",
					TextPadding = Vector4(0,0,0,0),
					LikeButton = true,
					ChildComboListStyle =  "Gui.New_teamComboList",
					Visible = false,
					Skin = Gui.ComboBoxSkin
					{
						ButtonNormalImage= Gui.Image("LobbyUI/dailycheck/lb_combobox_button01_normal.dds", Vector4(0, 0, 0, 0)),
						ButtonHoverImage = Gui.Image("LobbyUI/dailycheck/lb_combobox_button01_hover.dds", Vector4(0, 0, 0, 0)),
						ButtonDownImage = Gui.Image("LobbyUI/dailycheck/lb_combobox_button01_down.dds", Vector4(0, 0, 0, 0)),
					},
					EventValueChanged = function(sender, args)
						if DailyCheck.yuceshuzi.SelectedIndex >= 0 and DailyCheck.yuceshuzi.SelectedIndex < 10 then
							DailyCheck.num_enter.Enable = true
						else
							DailyCheck.num_enter.Enable = false
						end
					end,
				},
				
				Gui.Button "num_0"
				{
					Size = Vector2(24, 24),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Location = Vector2(12, 245),
					Text = "0",
					TextColor = ARGB(255,255,190,0),
					HighlightTextColor = ARGB(255,53,29,29),
					Padding = Vector4(0,0,2,6),
					Enable = true,
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/dailycheck/daily_number_normal.dds", Vector4(0, 0, 0, 0)),
						HoverImage = Gui.Image("LobbyUI/dailycheck/daily_number_hover.dds", Vector4(0, 0, 0, 0)),
						DownImage = Gui.Image("LobbyUI/dailycheck/daily_number_down.dds", Vector4(0, 0, 0, 0)),
						DisabledImage = Gui.Image("LobbyUI/dailycheck/daily_number_normal.dds", Vector4(0, 0, 0, 0)),							
					},
					EventClick = function(Sender,e)
						if times > 0 then
							if not Sender.PushDown then
								Sender.PushDown = true
								times = times - 1
								DailyCheck.num_times.Text = lang:GetText("剩余")..times..lang:GetText("次")
								for i=1,3 do
									if my_num[i] == -1 then
										my_num[i] = 0
										if times == 0 then
											DailyCheck.num_enter.Enable = true
										end
										return
									end
								end
							end
						else
							DailyCheck.num_enter.Enable = true
						end	
						if Sender.PushDown then
							Sender.PushDown = false
							times = times + 1
							DailyCheck.num_times.Text = lang:GetText("剩余")..times..lang:GetText("次")
							for i=1,3 do
								if my_num[i] == 0 then
									my_num[i] = -1
									break
								end
							end
							DailyCheck.num_enter.Enable = false
						end
					end
				},
				
				Gui.Button "num_1"
				{
					Size = Vector2(24, 24),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Location = Vector2(35, 245),
					Text = "1",
					TextColor = ARGB(255,255,190,0),
					HighlightTextColor = ARGB(255,53,29,29),
					Padding = Vector4(0,0,2,6),
					Enable = true,
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/dailycheck/daily_number_normal.dds", Vector4(0, 0, 0, 0)),
						HoverImage = Gui.Image("LobbyUI/dailycheck/daily_number_hover.dds", Vector4(0, 0, 0, 0)),
						DownImage = Gui.Image("LobbyUI/dailycheck/daily_number_down.dds", Vector4(0, 0, 0, 0)),
						DisabledImage = Gui.Image("LobbyUI/dailycheck/daily_number_normal.dds", Vector4(0, 0, 0, 0)),							
					},
					EventClick = function(Sender,e)
						if times > 0 then
							if not Sender.PushDown then
								Sender.PushDown = true
								times = times - 1
								DailyCheck.num_times.Text = lang:GetText("剩余")..times..lang:GetText("次")
								for i=1,3 do
									if my_num[i] == -1 then
										my_num[i] = 1
										if times == 0 then
											DailyCheck.num_enter.Enable = true
										end
										return
									end
								end
							end
						else
							DailyCheck.num_enter.Enable = true
						end	
						if Sender.PushDown then
							Sender.PushDown = false
							times = times + 1
							DailyCheck.num_times.Text = lang:GetText("剩余")..times..lang:GetText("次")
							for i=1,3 do
								if my_num[i] == 1 then
									my_num[i] = -1
									break
								end
							end
							DailyCheck.num_enter.Enable = false
						end
					end
				},
				
				Gui.Button "num_2"
				{
					Size = Vector2(24, 24),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Location = Vector2(58, 245),
					Text = "2",
					TextColor = ARGB(255,255,190,0),
					HighlightTextColor = ARGB(255,53,29,29),
					Padding = Vector4(0,0,2,6),
					Enable = true,
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/dailycheck/daily_number_normal.dds", Vector4(0, 0, 0, 0)),
						HoverImage = Gui.Image("LobbyUI/dailycheck/daily_number_hover.dds", Vector4(0, 0, 0, 0)),
						DownImage = Gui.Image("LobbyUI/dailycheck/daily_number_down.dds", Vector4(0, 0, 0, 0)),
						DisabledImage = Gui.Image("LobbyUI/dailycheck/daily_number_normal.dds", Vector4(0, 0, 0, 0)),							
					},
					EventClick = function(Sender,e)
						if times > 0 then
							if not Sender.PushDown then
								Sender.PushDown = true
								times = times - 1
								DailyCheck.num_times.Text = lang:GetText("剩余")..times..lang:GetText("次")
								for i=1,3 do
									if my_num[i] == -1 then
										my_num[i] = 2
										if times == 0 then
											DailyCheck.num_enter.Enable = true
										end
										return
									end
								end
							end
						else
							DailyCheck.num_enter.Enable = true
						end	
						if Sender.PushDown then
							Sender.PushDown = false
							times = times + 1
							DailyCheck.num_times.Text = lang:GetText("剩余")..times..lang:GetText("次")
							for i=1,3 do
								if my_num[i] == 2 then
									my_num[i] = -1
									break
								end
							end
							DailyCheck.num_enter.Enable = false
						end
					end
				},
				
				Gui.Button "num_3"
				{
					Size = Vector2(24, 24),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Location = Vector2(81, 245),
					Text = "3",
					TextColor = ARGB(255,255,190,0),
					HighlightTextColor = ARGB(255,53,29,29),
					Padding = Vector4(0,0,2,6),
					Enable = true,
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/dailycheck/daily_number_normal.dds", Vector4(0, 0, 0, 0)),
						HoverImage = Gui.Image("LobbyUI/dailycheck/daily_number_hover.dds", Vector4(0, 0, 0, 0)),
						DownImage = Gui.Image("LobbyUI/dailycheck/daily_number_down.dds", Vector4(0, 0, 0, 0)),
						DisabledImage = Gui.Image("LobbyUI/dailycheck/daily_number_normal.dds", Vector4(0, 0, 0, 0)),							
					},
					EventClick = function(Sender,e)
						if times > 0 then
							if not Sender.PushDown then
								Sender.PushDown = true
								times = times - 1
								DailyCheck.num_times.Text = lang:GetText("剩余")..times..lang:GetText("次")
								for i=1,3 do
									if my_num[i] == -1 then
										my_num[i] = 3
										if times == 0 then
											DailyCheck.num_enter.Enable = true
										end
										return
									end
								end
							end
						else
							DailyCheck.num_enter.Enable = true
						end	
						if Sender.PushDown then
							Sender.PushDown = false
							times = times + 1
							DailyCheck.num_times.Text = lang:GetText("剩余")..times..lang:GetText("次")
							for i=1,3 do
								if my_num[i] == 3 then
									my_num[i] = -1
									break
								end
							end
							DailyCheck.num_enter.Enable = false
						end
					end
				},
				
				Gui.Button "num_4"
				{
					Size = Vector2(24, 24),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Location = Vector2(104, 245),
					Text = "4",
					TextColor = ARGB(255,255,190,0),
					HighlightTextColor = ARGB(255,53,29,29),
					Padding = Vector4(0,0,2,6),
					Enable = true,
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/dailycheck/daily_number_normal.dds", Vector4(0, 0, 0, 0)),
						HoverImage = Gui.Image("LobbyUI/dailycheck/daily_number_hover.dds", Vector4(0, 0, 0, 0)),
						DownImage = Gui.Image("LobbyUI/dailycheck/daily_number_down.dds", Vector4(0, 0, 0, 0)),
						DisabledImage = Gui.Image("LobbyUI/dailycheck/daily_number_normal.dds", Vector4(0, 0, 0, 0)),							
					},
					EventClick = function(Sender,e)
						if times > 0 then
							if not Sender.PushDown then
								Sender.PushDown = true
								times = times - 1
								DailyCheck.num_times.Text = lang:GetText("剩余")..times..lang:GetText("次")
								for i=1,3 do
									if my_num[i] == -1 then
										my_num[i] = 4
										if times == 0 then
											DailyCheck.num_enter.Enable = true
										end
										return
									end
								end
							end
						else
							DailyCheck.num_enter.Enable = true
						end	
						if Sender.PushDown then
							Sender.PushDown = false
							times = times + 1
							DailyCheck.num_times.Text = lang:GetText("剩余")..times..lang:GetText("次")
							for i=1,3 do
								if my_num[i] == 4 then
									my_num[i] = -1
									break
								end
							end
							DailyCheck.num_enter.Enable = false
						end
					end
				},
				
				Gui.Button "num_5"
				{
					Size = Vector2(24, 24),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Location = Vector2(127, 245),
					Text = "5",
					TextColor = ARGB(255,255,190,0),
					HighlightTextColor = ARGB(255,53,29,29),
					Padding = Vector4(0,0,2,6),
					Enable = true,
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/dailycheck/daily_number_normal.dds", Vector4(0, 0, 0, 0)),
						HoverImage = Gui.Image("LobbyUI/dailycheck/daily_number_hover.dds", Vector4(0, 0, 0, 0)),
						DownImage = Gui.Image("LobbyUI/dailycheck/daily_number_down.dds", Vector4(0, 0, 0, 0)),
						DisabledImage = Gui.Image("LobbyUI/dailycheck/daily_number_normal.dds", Vector4(0, 0, 0, 0)),							
					},
					EventClick = function(Sender,e)
						if times > 0 then
							if not Sender.PushDown then
								Sender.PushDown = true
								times = times - 1
								DailyCheck.num_times.Text = lang:GetText("剩余")..times..lang:GetText("次")
								for i=1,3 do
									if my_num[i] == -1 then
										my_num[i] = 5
										if times == 0 then
											DailyCheck.num_enter.Enable = true
										end
										return
									end
								end
							end
						else
							DailyCheck.num_enter.Enable = true
						end	
						if Sender.PushDown then
							Sender.PushDown = false
							times = times + 1
							DailyCheck.num_times.Text = lang:GetText("剩余")..times..lang:GetText("次")
							for i=1,3 do
								if my_num[i] == 5 then
									my_num[i] = -1
									break
								end
							end
							DailyCheck.num_enter.Enable = false
						end
					end
				},
				
				Gui.Button "num_6"
				{
					Size = Vector2(24, 24),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Location = Vector2(151, 245),
					Text = "6",
					TextColor = ARGB(255,255,190,0),
					HighlightTextColor = ARGB(255,53,29,29),
					Padding = Vector4(0,0,2,6),
					Enable = true,
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/dailycheck/daily_number_normal.dds", Vector4(0, 0, 0, 0)),
						HoverImage = Gui.Image("LobbyUI/dailycheck/daily_number_hover.dds", Vector4(0, 0, 0, 0)),
						DownImage = Gui.Image("LobbyUI/dailycheck/daily_number_down.dds", Vector4(0, 0, 0, 0)),
						DisabledImage = Gui.Image("LobbyUI/dailycheck/daily_number_normal.dds", Vector4(0, 0, 0, 0)),							
					},
					EventClick = function(Sender,e)
						if times > 0 then
							if not Sender.PushDown then
								Sender.PushDown = true
								times = times - 1
								DailyCheck.num_times.Text = lang:GetText("剩余")..times..lang:GetText("次")
								for i=1,3 do
									if my_num[i] == -1 then
										my_num[i] = 6
										if times == 0 then
											DailyCheck.num_enter.Enable = true
										end
										return
									end
								end
							end
						else
							DailyCheck.num_enter.Enable = true
						end	
						if Sender.PushDown then
							Sender.PushDown = false
							times = times + 1
							DailyCheck.num_times.Text = lang:GetText("剩余")..times..lang:GetText("次")
							for i=1,3 do
								if my_num[i] == 6 then
									my_num[i] = -1
									break
								end
							end
							DailyCheck.num_enter.Enable = false
						end
					end
				},
				
				Gui.Button "num_7"
				{
					Size = Vector2(24, 24),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Location = Vector2(174, 245),
					Text = "7",
					TextColor = ARGB(255,255,190,0),
					HighlightTextColor = ARGB(255,53,29,29),
					Padding = Vector4(0,0,2,6),
					Enable = true,
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/dailycheck/daily_number_normal.dds", Vector4(0, 0, 0, 0)),
						HoverImage = Gui.Image("LobbyUI/dailycheck/daily_number_hover.dds", Vector4(0, 0, 0, 0)),
						DownImage = Gui.Image("LobbyUI/dailycheck/daily_number_down.dds", Vector4(0, 0, 0, 0)),
						DisabledImage = Gui.Image("LobbyUI/dailycheck/daily_number_normal.dds", Vector4(0, 0, 0, 0)),							
					},
					EventClick = function(Sender,e)
						if times > 0 then
							if not Sender.PushDown then
								Sender.PushDown = true
								times = times - 1
								DailyCheck.num_times.Text = lang:GetText("剩余")..times..lang:GetText("次")
								for i=1,3 do
									if my_num[i] == -1 then
										my_num[i] = 7
										if times == 0 then
											DailyCheck.num_enter.Enable = true
										end
										return
									end
								end
							end
						else
							DailyCheck.num_enter.Enable = true
						end	
						if Sender.PushDown then
							Sender.PushDown = false
							times = times + 1
							DailyCheck.num_times.Text = lang:GetText("剩余")..times..lang:GetText("次")
							for i=1,3 do
								if my_num[i] == 7 then
									my_num[i] = -1
									break
								end
							end
							DailyCheck.num_enter.Enable = false
						end
					end
				},
				
				Gui.Button "num_8"
				{
					Size = Vector2(24, 24),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Location = Vector2(198, 245),
					Text = "8",
					TextColor = ARGB(255,255,190,0),
					HighlightTextColor = ARGB(255,53,29,29),
					Padding = Vector4(0,0,2,6),
					Enable = true,
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/dailycheck/daily_number_normal.dds", Vector4(0, 0, 0, 0)),
						HoverImage = Gui.Image("LobbyUI/dailycheck/daily_number_hover.dds", Vector4(0, 0, 0, 0)),
						DownImage = Gui.Image("LobbyUI/dailycheck/daily_number_down.dds", Vector4(0, 0, 0, 0)),
						DisabledImage = Gui.Image("LobbyUI/dailycheck/daily_number_normal.dds", Vector4(0, 0, 0, 0)),							
					},
					EventClick = function(Sender,e)
						if times > 0 then
							if not Sender.PushDown then
								Sender.PushDown = true
								times = times - 1
								DailyCheck.num_times.Text = lang:GetText("剩余")..times..lang:GetText("次")
								for i=1,3 do
									if my_num[i] == -1 then
										my_num[i] = 8
										if times == 0 then
											DailyCheck.num_enter.Enable = true
										end
										return
									end
								end
							end
						else
							DailyCheck.num_enter.Enable = true
						end	
						if Sender.PushDown then
							Sender.PushDown = false
							times = times + 1
							DailyCheck.num_times.Text = lang:GetText("剩余")..times..lang:GetText("次")
							for i=1,3 do
								if my_num[i] == 8 then
									my_num[i] = -1
									break
								end
							end
							DailyCheck.num_enter.Enable = false
						end
					end
				},
				Gui.Button "num_9"
				{
					Size = Vector2(24, 24),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Location = Vector2(222, 245),
					Text = "9",
					TextColor = ARGB(255,255,190,0),
					HighlightTextColor = ARGB(255,53,29,29),
					Padding = Vector4(0,0,2,6),
					Enable = true,
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/dailycheck/daily_number_normal.dds", Vector4(0, 0, 0, 0)),
						HoverImage = Gui.Image("LobbyUI/dailycheck/daily_number_hover.dds", Vector4(0, 0, 0, 0)),
						DownImage = Gui.Image("LobbyUI/dailycheck/daily_number_down.dds", Vector4(0, 0, 0, 0)),
						DisabledImage = Gui.Image("LobbyUI/dailycheck/daily_number_normal.dds", Vector4(0, 0, 0, 0)),							
					},
					EventClick = function(Sender,e)
						if times > 0 then
							if not Sender.PushDown then
								Sender.PushDown = true
								times = times - 1
								DailyCheck.num_times.Text = lang:GetText("剩余")..times..lang:GetText("次")
								for i=1,3 do
									if my_num[i] == -1 then
										my_num[i] = 9
										if times == 0 then
											DailyCheck.num_enter.Enable = true
										end
										return
									end
								end
							end
						else
							DailyCheck.num_enter.Enable = true
						end	
						if Sender.PushDown then
							Sender.PushDown = false
							times = times + 1
							DailyCheck.num_times.Text = lang:GetText("剩余")..times..lang:GetText("次")
							for i=1,3 do
								if my_num[i] == 9 then
									my_num[i] = -1
									break
								end
							end
							DailyCheck.num_enter.Enable = false
						end
					end
				},
				
				Gui.Control "ctr_VIP_num"
				{
					Location = Vector2(22, 285),
					Size = Vector2(50, 29),
					BackgroundColor = ARGB(255,255,255,255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_button_01_normal.dds", Vector4(0, 0, 0, 0)),
					},
				},
				
				Gui.Label "num_times"
				{
					Size = Vector2(100, 30),
					Location = Vector2(80, 280),
					BackgroundColor = ARGB(0, 255, 0, 0),
					Text = lang:GetText("剩余0次"),
					FontSize = 18,
					TextAlign = "kAlignCenterMiddle",
					TextColor = ARGB(255, 255, 255,255),
				},
				
				Gui.Button "num_enter"
				{
					Size = Vector2(55, 36),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Location = Vector2(191, 278),
					Enable = false,
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/dailycheck/lb_submit_button01_normal.dds", Vector4(0, 0, 0, 0)),
						HoverImage = Gui.Image("LobbyUI/dailycheck/lb_submit_button01_hover.dds", Vector4(0, 0, 0, 0)),
						DownImage = Gui.Image("LobbyUI/dailycheck/llb_submit_button01_down.dds", Vector4(0, 0, 0, 0)),
						DisabledImage = Gui.Image("LobbyUI/dailycheck/lb_submit_button01_normal.dds", Vector4(0, 0, 0, 0)),							
					},
					EventClick = function()
						Show_ChangeNumber()
					end
				},	
			},	
			Gui.Control	"lucky"
			{
				Size = Vector2(268, 136),
				Location = Vector2(10, 0),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/dailycheck/lb_luckytitle.dds",Vector4(0, 0, 0, 0)),
				},
			},
			Gui.Label
			{
				Size = Vector2(235, 30),
				Location = Vector2(25, 225),
				BackgroundColor = ARGB(0, 255, 0, 0),
				Text = lang:GetText("我的预测"),
				FontSize = 18,
				TextAlign = "kAlignCenterMiddle",
				TextColor = ARGB(255, 255, 255,255),
			},
			Gui.Label
			{
				Size = Vector2(235, 30),
				Location = Vector2(25, 305),
				BackgroundColor = ARGB(0, 255, 0, 0),
				Text = lang:GetText("预测明天"),
				FontSize = 18,
				TextAlign = "kAlignCenterMiddle",
				TextColor = ARGB(255, 255, 255,255),
			},
			Gui.Label
			{
				Size = Vector2(235, 30),
				Location = Vector2(25, 414),
				BackgroundColor = ARGB(0, 255, 0, 0),
				Text = lang:GetText("预测奖励"),
				FontSize = 18,
				TextAlign = "kAlignCenterMiddle",
				TextColor = ARGB(255, 0, 0,0),
			},
			Gui.ItemBoxBtn
			{
				Size = Vector2(192, 104),
				BackgroundColor = ARGB(255, 255, 0, 0),
				Location = Vector2(48, 446),
				Empty = false,
				Selected = true,
				LoadingImage = Gui.AnimatedImage("LobbyUI/loading_ring.tga", 4, 2, 8),
				Type = 1,
				Skin = Gui.ItemBoxBtnSkin
				{							
				},
				ItemIcon = Gui.Icon("LobbyUI/ibt_icon/timeaddsucess.tga"),
				EventMouseEnter = function(sender, e)
					if sender.Loading == false then
						L_ToolTips.FillToolTipsDailyCheckWindow(100)
					end
				end,
				EventToolTipsShow = function(sender, e)
					L_ToolTips.ShowToolTipsShowWindow(sender, Vector2(832, 604),Vector2(45, 450))
				end,
				EventMouseLeave = function(sender, e)
					L_ToolTips.HideToolTipsWindow()
				end,								
			},
			
			Gui.Control "checkDate"
			{
				Size = Vector2(524, 559),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Location = Vector2(276,17),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/dailycheck/main_bar02.dds",Vector4(10, 10, 10, 10)),
				},				
				Gui.Control "main_bar_03"
				{
					Size = Vector2(502, 350),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Location = Vector2(11, 6),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/dailycheck/main_bar03.dds",Vector4(10, 10, 10, 10)),
					},
					Gui.Control 
					{
						Size = Vector2(239, 38),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Location = Vector2(8, 8),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/dailycheck/title_bar.dds",Vector4(10, 10, 10, 10)),
						},
						Gui.Label "now_Date"
						{		
							Size = Vector2(239, 36),
							Location = Vector2(0, 0),
							BackgroundColor = ARGB(0, 255, 255, 255),
							Text = "",
							FontSize = 12,					
							TextColor = ARGB(255, 215, 232, 227),
							TextAlign = "kAlignCenterMiddle",
						},
					},
					--免费\n每日领取
					Gui.Button "free_btn"
					{
						Size = Vector2(245, 36),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Location = Vector2(250, 8),
						Enable = false,
						blink = false,
						
						Text = lang:GetText("免费每日领取").."  ",
						FontSize = 14,
						TextAlign = "kAlignRightMiddle",
						TextColor = ARGB(255, 255, 175,20),
						
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/dailycheck/lb_receive_button01_normal.dds", Vector4(30, 0, 0, 0)),
							HoverImage = Gui.Image("LobbyUI/dailycheck/lb_receive_button01_hover.dds", Vector4(30, 0, 0, 0)),
							DownImage = Gui.Image("LobbyUI/dailycheck/lb_receive_button01_down.dds", Vector4(30, 0, 0, 0)),
							DisabledImage = Gui.Image("LobbyUI/dailycheck/lb_receive_button01_disabled.dds", Vector4(30, 0, 0, 0)),	
							TwinkleImage  = Gui.Image("LobbyUI/dailycheck/lb_tutorial_square02.dds", Vector4(14, 14, 14, 14)),
						},
						EventClick = function()
							Show_GetGift()
						end,
					},
					Gui.Control 
					{
						Size = Vector2(488, 303),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Location = Vector2(8, 41),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/dailycheck/lb_calendar_bar.dds",Vector4(50, 69, 50, 36)),
						},
					},
				},
				
				Gui.Control 
				{
					Size = Vector2(502, 193),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Location = Vector2(11, 359),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/dailycheck/main_bar03.dds",Vector4(10, 10, 10, 10)),
					},
					Gui.Label
					{		
						Size = Vector2(492, 36),
						Location = Vector2(6, 6),
						BackgroundColor = ARGB(255, 255, 255, 255),																											
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/dailycheck/title_bar.dds",Vector4(10, 10, 10, 10)),
						},
						-- Gui.Label "get_Gift"
						-- {		
							-- Size = Vector2(492, 36),
							-- Location = Vector2(20, 0),
							-- BackgroundColor = ARGB(0, 255, 255, 255),
							-- Text = "",
							-- FontSize = 14,					
							-- TextColor = ARGB(255, 215, 232, 227),
							-- TextAlign = "kAlignLeftMiddle",
						-- },
						Gui.RichEdit "get_Gift"
						{
							Size = Vector2(472, 36),
							Location = Vector2(12, 0),
							BackgroundColor = ARGB(0, 255, 255, 255),
							FontSize = 14,
						},
					},
					Gui.Control "checkList"
					{
						Size = Vector2(485, 111),
						BackgroundColor = ARGB(0, 250, 200, 0),
						Location = Vector2(11, 45),
						Gui.Control 
						{
							Size = Vector2(89, 111),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Location = Vector2(0, 0),
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/dailycheck/gift_bar.dds",Vector4(10, 10, 10, 10)),
							},
							Gui.Label
							{		
								Size = Vector2(89, 25),
								Location = Vector2(0, 0),
								BackgroundColor = ARGB(0, 0, 255, 0),
								Text = lang:GetText("签到3天"),
								FontSize = 20,					
								TextColor = ARGB(255, 0, 0, 0),
								TextAlign = "kAlignCenterMiddle",
							},	
							Gui.ItemBoxBtn "days_3"
							{
								Size = Vector2(80, 64),
								BackgroundColor = ARGB(0, 255, 255, 255),
								Location = Vector2(0, 37),
								Empty = false,
								Selected = true,
								LoadingImage = Gui.AnimatedImage("LobbyUI/loading_ring.tga", 4, 2, 8),
								Type = 1,
								Skin = Gui.ItemBoxBtnSkin
								{					
									NeutralNormalImage = Gui.Image("LobbyUI/dailycheck/gift_3day.dds", Vector4(0, 0, 0, 0)),
									NeutralHoverImage = Gui.Image("LobbyUI/dailycheck/gift_3day.dds", Vector4(0, 0, 0, 0)),
									NeutralSelectedImage = Gui.Image("LobbyUI/dailycheck/gift_3day.dds", Vector4(0, 0, 0, 0)),
									NeutralDisabledImage = Gui.Image("LobbyUI/dailycheck/gift_3day.dds", Vector4(0, 0, 0, 0)),	
									NeutralHighlightImage = Gui.Image("LobbyUI/dailycheck/gift_3day.dds", Vector4(0, 0, 0, 0)),									
								},
								EventMouseEnter = function(sender, e)
									if sender.Loading == false then
										L_ToolTips.FillToolTipsDailyCheckWindow(3)
									end
								end,
								EventToolTipsShow = function(sender, e)
									L_ToolTips.ShowToolTipsShowWindow(sender,Vector2(832, 604),Vector2(310, 450))
								end,
								EventMouseLeave = function(sender, e)
									L_ToolTips.HideToolTipsWindow()
								end,
							},
						},
						Gui.Control 
						{
							Size = Vector2(89, 111),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Location = Vector2(97, 0),
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/dailycheck/gift_bar.dds",Vector4(10, 10, 10, 10)),
							},
							Gui.Label
							{		
								Size = Vector2(89, 25),
								Location = Vector2(0, 0),
								BackgroundColor = ARGB(0, 0, 255, 0),
								Text = lang:GetText("签到7天"),
								FontSize = 20,					
								TextColor = ARGB(255, 0, 0, 0),
								TextAlign = "kAlignCenterMiddle",
							},				
							Gui.ItemBoxBtn "days_7"
							{
								Size = Vector2(80, 64),
								BackgroundColor = ARGB(255, 255, 255, 255),
								Location = Vector2(0, 37),
								Empty = false,
								LoadingImage = Gui.AnimatedImage("LobbyUI/loading_ring.tga", 4, 2, 8),
								Type = 1,
								Selected = true,
								Skin = Gui.ItemBoxBtnSkin
								{					
									NeutralNormalImage = Gui.Image("LobbyUI/dailycheck/gift_7day.dds", Vector4(0, 0, 0, 0)),
									NeutralHoverImage = Gui.Image("LobbyUI/dailycheck/gift_7day.dds", Vector4(0, 0, 0, 0)),
									NeutralSelectedImage = Gui.Image("LobbyUI/dailycheck/gift_7day.dds", Vector4(0, 0, 0, 0)),
									NeutralDisabledImage = Gui.Image("LobbyUI/dailycheck/gift_7day.dds", Vector4(0, 0, 0, 0)),	
									NeutralHighlightImage = Gui.Image("LobbyUI/dailycheck/gift_7day.dds", Vector4(0, 0, 0, 0)),									
								},		
								EventMouseEnter = function(sender, e)
									if sender.Loading == false then
										L_ToolTips.FillToolTipsDailyCheckWindow(7)
									end
								end,
								EventToolTipsShow = function(sender, e)
									L_ToolTips.ShowToolTipsShowWindow(sender,Vector2(832, 604),Vector2(424, 450))
								end,
								EventMouseLeave = function(sender, e)
									L_ToolTips.HideToolTipsWindow()
								end,
							},
						},
						
						Gui.Control 
						{
							Size = Vector2(89, 111),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Location = Vector2(194, 0),
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/dailycheck/gift_bar.dds",Vector4(10, 10, 10, 10)),
							},
							Gui.Label
							{		
								Size = Vector2(89, 25),
								Location = Vector2(0, 0),
								BackgroundColor = ARGB(0, 0, 255, 0),
								Text = lang:GetText("签到14天"),
								FontSize = 20,					
								TextColor = ARGB(255, 0, 0, 0),
								TextAlign = "kAlignCenterMiddle",
							},				
							Gui.ItemBoxBtn "days_14"
							{
								Size = Vector2(80, 64),
								BackgroundColor = ARGB(255, 255, 255, 255),
								Location = Vector2(0, 37),
								Empty = false,
								Selected = true,
								LoadingImage = Gui.AnimatedImage("LobbyUI/loading_ring.tga", 4, 2, 8),
								Type = 1,
								Skin = Gui.ItemBoxBtnSkin
								{								
									NeutralNormalImage = Gui.Image("LobbyUI/dailycheck/gift_14day.dds", Vector4(0, 0, 0, 0)),
									NeutralHoverImage = Gui.Image("LobbyUI/dailycheck/gift_14day.dds", Vector4(0, 0, 0, 0)),
									NeutralSelectedImage = Gui.Image("LobbyUI/dailycheck/gift_14day.dds", Vector4(0, 0, 0, 0)),
									NeutralDisabledImage = Gui.Image("LobbyUI/dailycheck/gift_14day.dds", Vector4(0, 0, 0, 0)),	
									NeutralHighlightImage = Gui.Image("LobbyUI/dailycheck/gift_14day.dds", Vector4(0, 0, 0, 0)),								
								},	
								EventMouseEnter = function(sender, e)
									if sender.Loading == false then
										L_ToolTips.FillToolTipsDailyCheckWindow(14)
									end
								end,
								EventToolTipsShow = function(sender, e)
									L_ToolTips.ShowToolTipsShowWindow(sender,Vector2(832, 604),Vector2(548, 450))
								end,
								EventMouseLeave = function(sender, e)
									L_ToolTips.HideToolTipsWindow()
								end,
							},
						},
						Gui.Control 
						{
							Size = Vector2(89, 111),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Location = Vector2(291, 0),
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/dailycheck/gift_bar.dds",Vector4(10, 10, 10, 10)),
							},
							Gui.Label
							{		
								Size = Vector2(89, 25),
								Location = Vector2(0, 0),
								BackgroundColor = ARGB(0, 0, 255, 0),
								Text = lang:GetText("签到21天"),
								FontSize = 20,					
								TextColor = ARGB(255, 0, 0, 0),
								TextAlign = "kAlignCenterMiddle",
							},				
							Gui.ItemBoxBtn "days_27"
							{
								Size = Vector2(80, 64),
								BackgroundColor = ARGB(255, 255, 255, 255),
								Location = Vector2(0, 37),
								Empty = false,
								Selected = true,
								LoadingImage = Gui.AnimatedImage("LobbyUI/loading_ring.tga", 4, 2, 8),
								Type = 1,
								Skin = Gui.ItemBoxBtnSkin
								{								
									NeutralNormalImage = Gui.Image("LobbyUI/dailycheck/gift_27day.dds", Vector4(0, 0, 0, 0)),
									NeutralHoverImage = Gui.Image("LobbyUI/dailycheck/gift_27day.dds", Vector4(0, 0, 0, 0)),
									NeutralSelectedImage = Gui.Image("LobbyUI/dailycheck/gift_27day.dds", Vector4(0, 0, 0, 0)),
									NeutralDisabledImage = Gui.Image("LobbyUI/dailycheck/gift_27day.dds", Vector4(0, 0, 0, 0)),	
									NeutralHighlightImage = Gui.Image("LobbyUI/dailycheck/gift_27day.dds", Vector4(0, 0, 0, 0)),								
								},		
								EventMouseEnter = function(sender, e)
									if sender.Loading == false then
										L_ToolTips.FillToolTipsDailyCheckWindow(21)
									end
								end,
								EventToolTipsShow = function(sender, e)
									L_ToolTips.ShowToolTipsShowWindow(sender, Vector2(832, 604),Vector2(672, 450))
								end,
								EventMouseLeave = function(sender, e)
									L_ToolTips.HideToolTipsWindow()
								end,								
							},
						},
						Gui.Control 
						{
							Size = Vector2(89, 111),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Location = Vector2(388, 0),
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/dailycheck/gift_bar.dds",Vector4(10, 10, 10, 10)),
							},
							Gui.Label "month_allday"
							{		
								Size = Vector2(89, 25),
								Location = Vector2(0, 0),
								BackgroundColor = ARGB(0, 0, 255, 0),
								Text = lang:GetText("签到30天"),
								FontSize = 20,					
								TextColor = ARGB(255, 0, 0, 0),
								TextAlign = "kAlignCenterMiddle",
							},				
							Gui.ItemBoxBtn "days_30"
							{
								Size = Vector2(80, 64),
								BackgroundColor = ARGB(255, 255, 255, 255),
								Location = Vector2(0, 37),
								Empty = false,
								Selected = true,
								LoadingImage = Gui.AnimatedImage("LobbyUI/loading_ring.tga", 4, 2, 8),
								Type = 1,
								Skin = Gui.ItemBoxBtnSkin
								{								
									NeutralNormalImage = Gui.Image("LobbyUI/dailycheck/gift_30day.dds", Vector4(0, 0, 0, 0)),
									NeutralHoverImage = Gui.Image("LobbyUI/dailycheck/gift_30day.dds", Vector4(0, 0, 0, 0)),
									NeutralSelectedImage = Gui.Image("LobbyUI/dailycheck/gift_30day.dds", Vector4(0, 0, 0, 0)),
									NeutralDisabledImage = Gui.Image("LobbyUI/dailycheck/gift_30day.dds", Vector4(0, 0, 0, 0)),	
									NeutralHighlightImage = Gui.Image("LobbyUI/dailycheck/gift_30day.dds", Vector4(0, 0, 0, 0)),								
								},		
								EventMouseEnter = function(sender, e)
									if sender.Loading == false then
										L_ToolTips.FillToolTipsDailyCheckWindow(month_days)
									end
								end,
								EventToolTipsShow = function(sender, e)
									L_ToolTips.ShowToolTipsShowWindow(sender, Vector2(832, 604),Vector2(672, 450))
								end,
								EventMouseLeave = function(sender, e)
									L_ToolTips.HideToolTipsWindow()
								end,								
							},
						},
					},
					Gui.Label "check_days"
					{		
						Size = Vector2(401, 24),
						Location = Vector2(50, 160),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Text = "",
						FontSize = 14,					
						TextColor = ARGB(255, 255, 255, 255),
						TextAlign = "kAlignCenterMiddle",
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/dailycheck/info_box.dds",Vector4(10, 10, 10, 10)),
						},
					},					
				},
			},
		},
		Gui.Button "daily_close"
		{
			Size = Vector2(48, 48),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Location = Vector2(782, 0),
			Hint = lang:GetText("关闭每日签到"),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_normal.dds", Vector4(10, 10, 10, 10)),
				HoverImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_hover.dds", Vector4(10, 10, 10, 10)),
				DownImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_down.dds", Vector4(10, 10, 10, 10)),
				DisabledImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_disabled.dds", Vector4(0, 0, 0, 0)),					
			},
			EventClick = function()
				if Meirimodal then
					Meirimodal.Close()
					Meirimodal = nil
				end
			end
		},
	},	
}

 ChangeNumber = Gui.Create()
{
	Gui.Control "num_price"
	{
		Size = Vector2(305,166),
		Dock = "kDockCenter",
		BackgroundColor = ARGB(0, 255, 255, 255),
		Gui.Control 
		{
			Size = Vector2(290,151),
			Location = Vector2(0, 15),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/dailycheck/lb_onlinetime_bg_4.dds",Vector4(23, 23, 23, 23)),
			},
			Gui.Label "lucknum_msg"
			{
				Size = Vector2(262, 76),
				Location = Vector2(16, 34),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Text = "",
				FontSize = 18,
				TextAlign = "kAlignCenterMiddle",
				TextColor = ARGB(255, 212, 203, 201),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/dailycheck/lb_onlinetime_bg_1.dds",Vector4(10, 10, 10, 10)),
				},
			},
			Gui.Button
			{
				Size = Vector2(79,28),
				Location = Vector2(56, 110),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Enable = true,
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/dailycheck/lb_onlinetime_button_2_normal.dds", Vector4(0, 0, 0, 0)),
					HoverImage = Gui.Image("LobbyUI/dailycheck/lb_onlinetime_button_2_hover.dds", Vector4(0, 0, 0, 0)),
					DownImage = Gui.Image("LobbyUI/dailycheck/lb_onlinetime_button_2_down.dds", Vector4(0, 0, 0, 0)),
					DisabledImage = Gui.Image("LobbyUI/dailycheck/lb_onlinetime_button_2_disabled.dds", Vector4(0, 0, 0, 0)),
				},
				Text = lang:GetText("确定"),
				TextColor = ARGB(255, 229, 255, 252),
				TextAlign = "kAlignCenterMiddle",
				HighlightTextColor = ARGB(255, 230, 254, 253),
				EventClick = function()
					if ChangeNumbermodal then
						local t_myNum
						local max1,max2,max3
						if L_Vip.Viplevel > 0 then
							max1 = math.max(my_num[1],math.max(my_num[2],my_num[3]))
							max3 = math.min(my_num[1],math.min(my_num[2],my_num[3]))
							for i = 1, 3 do
								if my_num[i] ~= max1 and my_num[i] ~= max3 then
									max2 = my_num[i]
								end
							end
							t_myNum = max3..","..max2..","..max1
						else
							t_myNum = ""..my_num[1]
						end
						SendDailyNum(t_myNum)
						ChangeNumbermodal.Close()
						ChangeNumbermodal = nil
					end									
				end
			},
			Gui.Button
			{
				Size = Vector2(79,28),
				Location = Vector2(180, 110),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Enable = true,
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/dailycheck/lb_onlinetime_button_2_normal.dds", Vector4(0, 0, 0, 0)),
					HoverImage = Gui.Image("LobbyUI/dailycheck/lb_onlinetime_button_2_hover.dds", Vector4(0, 0, 0, 0)),
					DownImage = Gui.Image("LobbyUI/dailycheck/lb_onlinetime_button_2_down.dds", Vector4(0, 0, 0, 0)),
					DisabledImage = Gui.Image("LobbyUI/dailycheck/lb_onlinetime_button_2_disabled.dds", Vector4(0, 0, 0, 0)),
				},
				Text = lang:GetText("取消"),
				TextColor = ARGB(255, 229, 255, 252),
				TextAlign = "kAlignCenterMiddle",
				HighlightTextColor = ARGB(255, 230, 254, 253),
				EventClick = function()				
					if ChangeNumbermodal then
						ChangeNumbermodal.Close()
						ChangeNumbermodal = nil
					end
				end
			},
		},
		Gui.Button 
		{
			Size = Vector2(48, 48),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Location = Vector2(257, 0),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_normal.dds", Vector4(10, 10, 10, 10)),
				HoverImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_hover.dds", Vector4(10, 10, 10, 10)),
				DownImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_down.dds", Vector4(10, 10, 10, 10)),
				DisabledImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_disabled.dds", Vector4(0, 0, 0, 0)),					
			},
			EventClick = function()
				if ChangeNumbermodal then
					ChangeNumbermodal.Close()
					ChangeNumbermodal = nil
					
				end
			end
		},
	},
}

function Show_DailyCheck()
	Meirimodal = ModalWindow.GetNew()
	Meirimodal.root.Size = Vector2(832,604)
	Meirimodal.AllowEscToExit = false
	DailyCheck.content.Parent = Meirimodal.root	
	L_LobbyMain.LobbyMainCalendar.calendar.Parent = Meirimodal.root
	L_LobbyMain.LobbyMainCalendar.weekday.Parent = Meirimodal.root
	L_LobbyMain.LobbyMainCalendar.weekday.Visible = true
	L_LobbyMain.LobbyMainCalendar.calendar.Visible = true
	if L_Vip.Viplevel > 0 then
		times = 3
	else
		times = 1
	end
	DailyCheck.num_times.Text = lang:GetText("剩余")..times..lang:GetText("次")
	DailyCheck.ctr_VIP_num.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_button_0"..L_Vip.Viplevel.."_normal.dds", Vector4(0, 0, 0, 0)),}
	for i = 0 , 9 do
		DailyCheck["num_"..i].PushDown = false
	end
	my_num = {-1,-1,-1}
	-- DailyCheck.get_Gift.Text = lang:GetText("您现在是VIP")..L_Vip.Viplevel..lang:GetText("级，可获得免费补签和提前签到机会（共")..freeCheck[L_Vip.Viplevel+1]..lang:GetText("次")
	ShowDailyCheckList()
end

 function Hide()
	if Meirimodal then
		L_LobbyMain.LobbyMainCalendar.calendar.Parent = LobbyMainWin.LobbyMain_Root
		L_LobbyMain.LobbyMainCalendar.weekday.Parent = LobbyMainWin.LobbyMain_Root
		L_LobbyMain.LobbyMainCalendar.weekday.Visible = false
		L_LobbyMain.LobbyMainCalendar.calendar.Visible = false
		Meirimodal.Close()
		Meirimodal = nil
	end
end

-- 参数
-- pid=123	//玩家ID
-- 返回值
-- msg=""	//msg=nil "dddddddd"
-- sid = 1,							--物品id，唯一
-- display = lang:GetText("黑水头套")						--物品名称
-- name = "head01",						--物品贴图资源名	
-- color=1,  --名字颜色 1红 2紫 3蓝 4绿  5默认值
--每日领取奖励
function SendDailyGift()
	local p_id = ptr_cast(game.CurrentState):GetCharacterId()
	rpc.safecall("daily_gift", {pid = p_id},
	function (data)
		if config:GetUISystemFlag(3) == 0 then
			GetGift.gift_name.Text = lang:GetText("你获得了 “")..data.check_gift[1].display.."”"
			GetGift.gift_btn:OnDestroy()
			L_Characters.CreatPresentNumCtr(GetGift.gift_btn,data.check_gift[1].item_num,158, 73)
			GetGift.mysource_num.Visible = false
			GetGift.c_res.Visible = false
		elseif config:GetUISystemFlag(3) == 1 then
			GetGift.gift_name.Text = lang:GetText("你获得了 “")..data.check_gift[1].display..lang:GetText("” “个人原石”")
			GetGift.gift_btn:OnDestroy()
			L_Characters.CreatPresentNumCtr(GetGift.gift_btn,data.check_gift[1].item_num,158, 73)
			GetGift.mysource_num:OnDestroy()
			L_Characters.CreatPresentNumCtr(GetGift.mysource_num,data.quietBounds.disResBounds,158, 73)
		end
		
		local color = data.check_gift[1].color
		if color >= 2 and color <= 4 then
			color = "_"..color
		else
			color = ""
		end
		GetGift.gift_btn.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..data.check_gift[1].name..color..".tga"),
		L_MessageBox.CloseWaiter()
	end)
end

-- 参数
-- pid=123	//玩家ID
-- num=1
--预测数字
function SendDailyNum(_num)
	local p_id = ptr_cast(game.CurrentState):GetCharacterId()
	rpc.safecall("daily_num", {pid = p_id,num = _num},
	function (data)
		if data.error == nil then
			if L_Vip.Viplevel > 0 then
				DailyCheck.MY_NUMS1.Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/countdown_number.dds", Vector4(0, 0, 0, 0),Vector4(0.1*my_num[1], 0, 0.1*(my_num[1] + 1), 1)),
				}
				DailyCheck.MY_NUMS1:Clear()
				DailyCheck.MY_NUMS1:InsertMovePoint(Vector2(25,5),0.4,Vector2(30,44),ARGB(255,255,255,255))
				DailyCheck.MY_NUMS1:InsertMovePoint(Vector2(30,15),1.0,Vector2(20,24),ARGB(255,255,255,255))
				DailyCheck.MY_NUMS1:ReState()

				DailyCheck.MY_NUMS2.Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/countdown_number.dds", Vector4(0, 0, 0, 0),Vector4(0.1*my_num[2], 0, 0.1*(my_num[2] + 1), 1)),
				}
				DailyCheck.MY_NUMS2:Clear()
				DailyCheck.MY_NUMS2:InsertMovePoint(Vector2(105,5),0.4,Vector2(30,44),ARGB(255,255,255,255))
				DailyCheck.MY_NUMS2:InsertMovePoint(Vector2(110,15),1.0,Vector2(20,24),ARGB(255,255,255,255))
				DailyCheck.MY_NUMS2:ReState()			

				DailyCheck.MY_NUMS3.Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/countdown_number.dds", Vector4(0, 0, 0, 0),Vector4(0.1*my_num[3], 0, 0.1*(my_num[3] + 1), 1)),
				}
				DailyCheck.MY_NUMS3:Clear()
				DailyCheck.MY_NUMS3:InsertMovePoint(Vector2(185,5),0.4,Vector2(30,44),ARGB(255,255,255,255))
				DailyCheck.MY_NUMS3:InsertMovePoint(Vector2(190,15),1.0,Vector2(20,24),ARGB(255,255,255,255))
				DailyCheck.MY_NUMS3:ReState()
			else
				DailyCheck.MY_NUMS2.Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/countdown_number.dds", Vector4(0, 0, 0, 0),Vector4(0.1*my_num[1], 0, 0.1*(my_num[1] + 1), 1)),
				}
				DailyCheck.MY_NUMS2:Clear()
				DailyCheck.MY_NUMS2:InsertMovePoint(Vector2(105,5),0.4,Vector2(30,44),ARGB(255,255,255,255))
				DailyCheck.MY_NUMS2:InsertMovePoint(Vector2(110,15),1.0,Vector2(20,24),ARGB(255,255,255,255))
				DailyCheck.MY_NUMS2:ReState()
			end
		else
			ChangeNumbermodal.Close()
			ChangeNumbermodal = nil	
		end
		L_MessageBox.CloseWaiter()
	end)
end

-- 参数
-- pid=123	//玩家ID
-- 返回值
-- day="2012-02-16"	//年月日
-- week=1	//星期几
-- check_days={
	-- "2012-02-16","2012-02-16","2012-02-16"
-- }
--日历签到
function SendDailyCheckList(d)
	local t = nil
	
	if tonumber(d) < tonumber(NowDay) then
		t = 1
		if freeCheckTimes == 0 then
		local money = 5*MonthCheckTimes*(MonthCheckTimes + 1) + 150
		MessageBox.ShowWithTwoButtons(lang:GetText("补充签到当前将扣除")..money..lang:GetText("FC点，确认继续？"),lang:GetText("确定"),lang:GetText("取消"),
								function()
									DailyCkeckRpc(d,t)
									MonthCheckTimes = MonthCheckTimes+1
								end,
								nil
								)
		else
			freeCheckTimes = freeCheckTimes - 1
			DailyCkeckRpc(d,t)
			MonthCheckTimes = MonthCheckTimes+1
		end		
	elseif tonumber(d) > tonumber(NowDay) then
		t = 3
		if freeCheckTimes == 0 then
		MessageBox.ShowWithTwoButtons(lang:GetText("提前签到将扣除30FC点，确认继续？"),lang:GetText("确定"),lang:GetText("取消"),
								function()
									DailyCkeckRpc(d,t)
									MonthCheckTimes = MonthCheckTimes+1
								end,
								nil
								)
		else
			DailyCkeckRpc(d,t)
			freeCheckTimes = freeCheckTimes - 1
			MonthCheckTimes = MonthCheckTimes+1
		end		
	else
		t = 2
		DailyCkeckRpc(d,t)
	end
	DailyCheck.get_Gift:CleanAll()
	DailyCheck.get_Gift:AddMsg(lang:GetText("您现在是VIP")..L_Vip.Viplevel..lang:GetText("级，可获得免费补签和提前签到机会（还有"),ARGB(255, 215, 232, 227),true,false)
	DailyCheck.get_Gift:AddMsg(freeCheckTimes,ARGB(255, 255, 205, 69),false,false)
	DailyCheck.get_Gift:AddMsg(lang:GetText("次）"),ARGB(255, 215, 232, 227),false,false)
end

function DailyCkeckRpc(d,t)
	local p_id = ptr_cast(game.CurrentState):GetCharacterId()
	rpc.safecall("daily_check", {pid = p_id, day = tonumber(d), checktype = t},
		function (data)
			if data.warning then
				MessageBox.ShowWithTimer(1,data.warning)
				return
			end
			if data.result == 0 then
				MessageBox.ShowWithTwoButtons(lang:GetText("你的FC点不足，请充值"),lang:GetText("充值"),lang:GetText("取消"),
									function()
										gui:ShowIE()
									end,
									nil
									)
			elseif data.result == 1 then
				MessageBox.ShowWithTimer(1,lang:GetText("你已经不能再补签了！"))
			elseif data.result == 2 then
				MessageBox.ShowWithTimer(1,lang:GetText("你已经不能再预签了！"))
			elseif data.result == 4 then
				MessageBox.ShowWithTimer(1,lang:GetText("错误的签到信息，请稍后再签到！"))
			else
				print("table.getn(data.check_days):"..table.getn(data.check_days))
				local day = Split(data.check_days[table.getn(data.check_days)],"-")
				L_LobbyMain.LobbyMainCalendar.calendar:SetDayActivate(day[3])
				DailyCheck.check_days.Text = lang:GetText("这个月你已经累计签到")..table.getn(data.check_days)..lang:GetText("天")
				Getgift_msg(table.getn(data.check_days))
				L_MessageBox.CloseWaiter()
			end
		end)
end

function HowManyDay(year , month)
	local feb = 0
	if year % 4 == 0 then
		feb = 1
	end
	local day = {31,28+feb,31,30,31,30,31,31,30,31,30,31}
	return day[tonumber(month)]
end

-- 参数
-- pid=123	//玩家ID
--累计签到奖励
function ShowDailyCheckList()
	local p_id = ptr_cast(game.CurrentState):GetCharacterId()
	rpc.safecall("daily_check_list",{pid = p_id},
	function (data)
		freeCheckTimes = data.freeCheckTimes
		MonthCheckTimes = data.checkNum
		DailyCheck.get_Gift:CleanAll()
		DailyCheck.get_Gift:AddMsg(lang:GetText("您现在是VIP")..L_Vip.Viplevel..lang:GetText("级，可获得免费补签和提前签到机会（还有"),ARGB(255, 215, 232, 227),true,false)
		DailyCheck.get_Gift:AddMsg(freeCheckTimes,ARGB(255, 255, 205, 69),false,false)
		DailyCheck.get_Gift:AddMsg(lang:GetText("次）"),ARGB(255, 215, 232, 227),false,false)
		Tomorrow_Num = data.tomorrow_num
		DailyCheck.today_num.Text = data.today_num
		if data.my_num == "-1" or Tomorrow_Num == "-1" then
			DailyCheck.MY_NUMS1.Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/lb_calendar_bg_xiala.dds", Vector4(0, 0, 0, 0)),
			}
			DailyCheck.MY_NUMS2.Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/lb_calendar_bg_xiala.dds", Vector4(0, 0, 0, 0)),
			}
			DailyCheck.MY_NUMS3.Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/lb_calendar_bg_xiala.dds", Vector4(0, 0, 0, 0)),
			}
			DailyCheck.num_enter.Enable = false
		else
			local allnum = Split(data.my_num,",")
			if #allnum == 3 then
				DailyCheck.MY_NUMS1.Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/countdown_number.dds", Vector4(0, 0, 0, 0),Vector4(0.1*allnum[1], 0, 0.1*(allnum[1] + 1), 1)),
				}
				DailyCheck.MY_NUMS2.Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/countdown_number.dds", Vector4(0, 0, 0, 0),Vector4(0.1*allnum[2], 0, 0.1*(allnum[2] + 1), 1)),
				}
				DailyCheck.MY_NUMS3.Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/countdown_number.dds", Vector4(0, 0, 0, 0),Vector4(0.1*allnum[3], 0, 0.1*(allnum[3] + 1), 1)),
				}
			elseif #allnum == 1 then
				DailyCheck.MY_NUMS1.Skin = Gui.ControlSkin
				{
					BackgroundImage = nil,
				}
				DailyCheck.MY_NUMS2.Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/countdown_number.dds", Vector4(0, 0, 0, 0),Vector4(0.1*allnum[1], 0, 0.1*(allnum[1] + 1), 1)),
				}
				DailyCheck.MY_NUMS3.Skin = Gui.ControlSkin
				{
					BackgroundImage = nil,
				}
			end			
		end
		 
		local allDay = Split(data.day,"-")
		local m_year = allDay[1]
		local m_month = allDay[2]
		local m_day = allDay[3]
		local m_week = data.week
		local china_date = {lang:GetText("日"),lang:GetText("一"),lang:GetText("二"),lang:GetText("三"),lang:GetText("四"),lang:GetText("五"),lang:GetText("六")} 
		local i = tonumber(m_week)
		DailyCheck.now_Date.Text = m_year..lang:GetText("年").. m_month..lang:GetText("月")..m_day..lang:GetText("日 周")..china_date[i+1]
		L_LobbyMain.LobbyMainCalendar.calendar:SetTime(m_year,m_month,m_day,m_week)
		NowDay = m_day
		DailyCheck.check_days.Text = lang:GetText("这个月你已经累计签到")..table.getn(data.check_days)..lang:GetText("天")
		
		for i=1,table.getn(data.check_days) do
			local day = Split(data.check_days[i],"-")
			L_LobbyMain.LobbyMainCalendar.calendar:SetDayActivate(day[3])			
		end
		month_days = HowManyDay(m_year,m_month)
		print("m_year:"..m_year)
		print("m_month:"..m_month)
		print("month_days:"..month_days)
		DailyCheck.month_allday.Text = lang:GetText("签到")..month_days..lang:GetText("天")
		FillCheckList(table.getn(data.check_days))
		if data.is_gift ~= 0 then
			DailyCheck.free_btn.Enable = false
			DailyCheck.free_btn.blink = false
		else
			DailyCheck.free_btn.Enable = true
			DailyCheck.free_btn.blink = true
		end
		
		local temp_mynum = nil
		if data.my_num ~= "-1" then
			temp_mynum = Split(data.my_num,",")
		end
		if temp_mynum and data.is_show_award == 0 then
			for i,v in ipairs(temp_mynum) do		
				if data.today_num == tonumber(temp_mynum[i]) then 
					MessageBox.ShowWithConfirm(lang:GetText("你的运气不错！猜对了幸运数字！\n获得了预测奖励，请去仓库查看！"))
					break
				end
			end
		end		
		DailyCheck.yuceshuzi:RemoveAll()
		if myNum then
			for i=1, #myNum do
				DailyCheck.yuceshuzi:AddItem(myNum[i])
			end
		end
		DailyCheck.yuceshuzi.Text = "--"
		if Tomorrow_Num ~= "-1" then
			local allnum = Split(Tomorrow_Num,",")
			if #allnum == 3 then
				DailyCheck.MY_NUMS1.Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/countdown_number.dds", Vector4(0, 0, 0, 0),Vector4(0.1*allnum[1], 0, 0.1*(allnum[1] + 1), 1)),
				}
				DailyCheck.MY_NUMS2.Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/countdown_number.dds", Vector4(0, 0, 0, 0),Vector4(0.1*allnum[2], 0, 0.1*(allnum[2] + 1), 1)),
				}
				DailyCheck.MY_NUMS3.Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/countdown_number.dds", Vector4(0, 0, 0, 0),Vector4(0.1*allnum[3], 0, 0.1*(allnum[3] + 1), 1)),
				}
			elseif #allnum == 1 then
				DailyCheck.MY_NUMS1.Skin = Gui.ControlSkin
				{
					BackgroundImage = nil,
				}
				DailyCheck.MY_NUMS2.Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/countdown_number.dds", Vector4(0, 0, 0, 0),Vector4(0.1*allnum[1], 0, 0.1*(allnum[1] + 1), 1)),
				}
				DailyCheck.MY_NUMS3.Skin = Gui.ControlSkin
				{
					BackgroundImage = nil,
				}

			end
		else
			DailyCheck.yuceshuzi.Text = "--"
		end
		L_MessageBox.CloseWaiter()
	end)	
end

function FillCheckList(days)
		local count = days
		if count > 2 then
			DailyCheck.days_3.ItemIcon = Gui.Icon("LobbyUI/dailycheck/lb_received.dds")
		end
		if count > 6 then
			DailyCheck.days_7.ItemIcon = Gui.Icon("LobbyUI/dailycheck/lb_received.dds")
		end
		if count > 13 then
			DailyCheck.days_14.ItemIcon = Gui.Icon("LobbyUI/dailycheck/lb_received.dds")
		end
		if count > 20 then
			DailyCheck.days_27.ItemIcon = Gui.Icon("LobbyUI/dailycheck/lb_received.dds")
		end
		if count > month_days - 1 then
			DailyCheck.days_30.ItemIcon = Gui.Icon("LobbyUI/dailycheck/lb_received.dds")
		end
end
function Getgift_msg(days)
	local count = days
	if count == 3 then
		DailyCheck.days_3.ItemIcon = Gui.Icon("LobbyUI/dailycheck/lb_received.dds")
		MessageBox.ShowWithConfirm(lang:GetText("你已经累计上线3天了！\n获得了系统送出的奖励，请去仓库查看"))
	end
	if count == 7 then
		DailyCheck.days_7.ItemIcon = Gui.Icon("LobbyUI/dailycheck/lb_received.dds")
		MessageBox.ShowWithConfirm(lang:GetText("你已经累计上线7天了！\n获得了系统送出的奖励，请去仓库查看"))
	end
	if count == 14 then
		DailyCheck.days_14.ItemIcon = Gui.Icon("LobbyUI/dailycheck/lb_received.dds")
		MessageBox.ShowWithConfirm(lang:GetText("你已经累计上线14天了！\n获得了系统送出的奖励，请去仓库查看"))
	end
	if count == 21 then
		DailyCheck.days_27.ItemIcon = Gui.Icon("LobbyUI/dailycheck/lb_received.dds")
		MessageBox.ShowWithConfirm(lang:GetText("你已经累计上线21天了！\n获得了系统送出的奖励，请去仓库查看"))
	end
	if count == month_days then
		DailyCheck.days_30.ItemIcon = Gui.Icon("LobbyUI/dailycheck/lb_received.dds")
		MessageBox.ShowWithConfirm(lang:GetText("你已经累计上线")..month_days..lang:GetText("天了！\n获得了系统送出的奖励，请去仓库查看"))
	end
end

GetGift = Gui.Create()
{
	Gui.Control "main_gift"
	{
		Size = Vector2(538,417),
		Dock = "kDockCenter",
		BackgroundColor = ARGB(255, 255, 255, 255),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_contact_bg1_01.dds", Vector4(163,163,53,53)),
		},
		Gui.Control 
		{
			Size = Vector2(507,305),
			Location = Vector2(15, 30),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/team/lb_shop_bg3_1.dds", Vector4(10, 10, 10, 10)),
			},
			Gui.Label "gift_name"
			{
				Size = Vector2(497, 32),
				Location = Vector2(0, 23),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Text = "",
				FontSize = 16,
				TextAlign = "kAlignCenterMiddle",
				TextColor = ARGB(255, 215, 232, 227),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/dailycheck/text_bar.dds",Vector4(70, 6, 70, 6)),
				},
			},
			Gui.ItemBoxBtn "gift_btn"
			{
				Size = Vector2(168, 80),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Location = Vector2(57, 83),
				Empty = false,
				LoadingImage = Gui.AnimatedImage("LobbyUI/loading_ring.tga", 4, 2, 8),
				Type = 1,
				Enable = false,
				Skin = Gui.ItemBoxBtnSkin
				{
					NeutralDisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche1_normal.dds", Vector4(0, 0, 0, 0)),								
				},		
			},
			Gui.Control "mysource_num"
			{
				Location = Vector2(282, 83),
				Size = Vector2(168, 80),
				BackgroundColor = ARGB(255,255,255,255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche1_normal.dds", Vector4(0, 0, 0, 0)),
				},
			},
			Gui.Control "c_res"
			{
				Location = Vector2(328, 109),
				Size = Vector2(30, 30),
				BackgroundColor = ARGB(255,255,255,255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/lb_icon_res_02_1.dds", Vector4(0, 0, 0, 0)),
				},
			},
			
			Gui.Control "ctr_VIP_1"
			{
				Location = Vector2(15, 185),
				Size = Vector2(142, 77),
				BackgroundColor = ARGB(255,255,255,255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_bg_06.dds", Vector4(0, 0, 0, 0)),
				},
				Gui.Control "ctr_VIP_num1"
				{
					Location = Vector2(44, 30),
					Size = Vector2(50, 29),
					BackgroundColor = ARGB(255,255,255,255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_button_06_normal.dds", Vector4(0, 0, 0, 0)),
					},
				},
			},
			
			Gui.Label "vip_exp"
			{
				Size = Vector2(300, 32),
				Location = Vector2(105, 235),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Text = "800(+100)/1000",
				FontSize = 16,
				TextAlign = "kAlignCenterMiddle",
				TextColor = ARGB(255, 215, 232, 227),
			},
			
			Gui.Control "exp_back"
			{
				Size = Vector2(300,25),
				Location = Vector2(105, 265),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/vip/vip/lb_VIP_scrollbar_slider.dds", Vector4(10, 10, 20, 10)),
				},
				Gui.Control "exp_bar"
				{
					Size = Vector2(0,25),
					Location = Vector2(0, 0),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/vip/vip/lb_VIP_scrollbar_bg.dds", Vector4(10, 10, 20, 10)),
					},
				},
			},
			
			Gui.Control "ctr_VIP_2"
			{
				Location = Vector2(350, 185),
				Size = Vector2(142, 77),
				BackgroundColor = ARGB(255,255,255,255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_bg_06.dds", Vector4(0, 0, 0, 0)),
				},
				Gui.Control "ctr_VIP_num2"
				{
					Location = Vector2(44, 30),
					Size = Vector2(50, 29),
					BackgroundColor = ARGB(255,255,255,255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_button_06_normal.dds", Vector4(0, 0, 0, 0)),
					},
				},
			},
		},
		Gui.Button
		{
			Size = Vector2(124,44),
			Location = Vector2(207, 347),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Enable = true,
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_normal.dds", Vector4(0, 0, 0, 0)),
				HoverImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_hover.dds", Vector4(0, 0, 0, 0)),
				DownImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_down.dds", Vector4(0, 0, 0, 0)),
				DisabledImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_disabled.dds", Vector4(0, 0, 0, 0)),
			},
			Text = lang:GetText("确定"),
			TextColor = ARGB(255, 229, 255, 252),
			TextAlign = "kAlignCenterMiddle",
			HighlightTextColor = ARGB(255, 229, 255, 252),
			EventClick = function()
				Hide()
			end
		},
	},
}

function Show_GetGift()
	Getgiftmodel = ModalWindow.GetNew()
	Getgiftmodel.root.Size = Vector2(538,417)
	Getgiftmodel.AllowEscToExit = false
	GetGift.main_gift.Parent = Getgiftmodel.root
	DailyCheck.free_btn.Enable = true
	
	GetGift.ctr_VIP_2.Visible = true
	GetGift.ctr_VIP_num2.Visible = true
	GetGift.exp_back.Visible = true
	GetGift.vip_exp.Visible = true
	GetGift.ctr_VIP_1.Visible = true
	GetGift.ctr_VIP_num1.Visible = true
	if L_Vip.Viplevel == L_Vip.VipMaxlevel then
		GetGift.ctr_VIP_1.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_bg_05.dds", Vector4(0, 0, 0, 0)),}
		GetGift.ctr_VIP_num1.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_button_05_normal.dds", Vector4(0, 0, 0, 0)),}
		GetGift.ctr_VIP_2.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_bg_06.dds", Vector4(0, 0, 0, 0)),}
		GetGift.ctr_VIP_num2.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_button_06_normal.dds", Vector4(0, 0, 0, 0)),}
		GetGift.exp_bar.Size = Vector2(300,25)
		GetGift.vip_exp.Text = "Max"
	elseif L_Vip.Viplevel == 0 then
		GetGift.exp_back.Visible = false
		GetGift.vip_exp.Visible = false
		GetGift.ctr_VIP_2.Visible = false
		GetGift.ctr_VIP_num2.Visible = false
		GetGift.ctr_VIP_1.Visible = false
		GetGift.ctr_VIP_num1.Visible = false
	else
		GetGift.ctr_VIP_1.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_bg_0"..L_Vip.Viplevel..".dds", Vector4(0, 0, 0, 0)),}
		GetGift.ctr_VIP_num1.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_button_0"..L_Vip.Viplevel.."_normal.dds", Vector4(0, 0, 0, 0)),}
		GetGift.ctr_VIP_2.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_bg_0"..(L_Vip.Viplevel+1)..".dds", Vector4(0, 0, 0, 0)),}
		GetGift.ctr_VIP_num2.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_button_0"..(L_Vip.Viplevel+1).."_normal.dds", Vector4(0, 0, 0, 0)),}
		if L_Vip.now_box == 15 then
			GetGift.exp_bar.Size = Vector2(300, 25)
			GetGift.vip_exp.Text = L_Vip.Vipexp.."(+400)/"..L_Vip.vip_box_exp[L_Vip.now_box - 1]
		elseif (L_Vip.vip_box_exp[L_Vip.now_box]-L_Vip.Vipexp) <= 0 then
			GetGift.exp_bar.Size = Vector2(300, 25)
			GetGift.vip_exp.Text = L_Vip.Vipexp.."(+400)/"..L_Vip.vip_box_exp[L_Vip.now_box]
		elseif L_Vip.Viplevel == L_Vip.VipMaxlevel - 1 then
			if L_Vip.now_box == 1 then
				GetGift.exp_bar.Size = Vector2((1 - ((L_Vip.vip_box_exp[L_Vip.now_box]-L_Vip.Vipexp) / (L_Vip.vip_box_exp[L_Vip.now_box] - L_Vip.vip_exp[8])))*300,25)
			else
				GetGift.exp_bar.Size = Vector2((1 - ((L_Vip.vip_box_exp[L_Vip.now_box]-L_Vip.Vipexp) / (L_Vip.vip_box_exp[L_Vip.now_box] - L_Vip.vip_box_exp[L_Vip.now_box - 1])))*300,25)
			end
			GetGift.vip_exp.Text = L_Vip.Vipexp.."(+400)/"..(L_Vip.vip_box_exp[L_Vip.now_box])
		else
			GetGift.exp_bar.Size = Vector2((1 - ((L_Vip.vip_exp[L_Vip.Viplevel+1]-L_Vip.Vipexp) / (L_Vip.vip_exp[L_Vip.Viplevel+1] - L_Vip.vip_exp[L_Vip.Viplevel])))*300,25)
			GetGift.vip_exp.Text = L_Vip.Vipexp.."(+400)/"..L_Vip.vip_exp[L_Vip.Viplevel+1]
		end
	end
	SendDailyGift()
end

function Hide()
	if Getgiftmodel then
		DailyCheck.free_btn.Enable = false
		DailyCheck.free_btn.blink = false
		Getgiftmodel.Close()
		Getgiftmodel = nil
	end
end

-- 字符串分割
function Split(szFullString, szSeparator)
	local nFindStartIndex = 1
	local nSplitIndex = 1
	local nSplitArray = {}
	while true do
	   local nFindLastIndex = string.find(szFullString, szSeparator,nFindStartIndex)
	   if not nFindLastIndex then
		nSplitArray[nSplitIndex] = string.sub(szFullString, nFindStartIndex, string.len(szFullString))
		break
	   end
	   nSplitArray[nSplitIndex] = string.sub(szFullString, nFindStartIndex, nFindLastIndex - 1)
	   nFindStartIndex = nFindLastIndex + string.len(szSeparator)
	   nSplitIndex = nSplitIndex + 1
	end
	return nSplitArray
end

function Show_ChangeNumber()
	ChangeNumbermodal = ModalWindow.GetNew()
	ChangeNumbermodal.root.Size = Vector2(427,372)
	ChangeNumbermodal.AllowEscToExit = false
	ChangeNumber.num_price.Parent = ChangeNumbermodal.root
	if L_Vip.Viplevel > 0 then
		ChangeNumber.lucknum_msg.Text = lang:GetText("你预测的幸运数字是：")..my_num[1]..","..my_num[2]..","..my_num[3]..lang:GetText("\n 激活将扣除1000 C币,是否继续？")
	else
		ChangeNumber.lucknum_msg.Text = lang:GetText("你预测的幸运数字是：")..my_num[1]..lang:GetText("\n 激活将扣除1000 C币,是否继续？")
	end
	gui:PlayAudio("kUIA_CONFIRM_MESSAGE")
end