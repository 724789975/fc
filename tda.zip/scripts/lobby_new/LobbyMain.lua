module("L_LobbyMain", package.seeall)
--当前选择的分页
current_chosse_main_page = 5
--当前选择职业(1:炮哥)
current_choose_class = 1
--当前角色管理 仓库选项（1武器2服装3配饰4道具5678）
current_character_storage = 1
--当前商城 仓库选项（1武器2服装3配饰）
current_shoppingmall_storage = 1
--当前预览武器类型默认是主武器
current_preview_weapon_index = 1
--职业列表
character_classes = nil
character_bag = nil
local lev = 1
local pid = nil
weapon_index = nil
IsInit = 1
local freshNew = true
local resetLobby = false
local character_management_ui = nil
local boddy_info_ui = nil
my_flag = nil
dlb_window_ui = nil
exppropmodal = nil
openbox_modal = nil

local now_exp = nil
local now_level = nil
local now_openbox_page = nil
local now_openbox_data = nil

bufflist = {}

OLTime = -2
Sell_Time = 0
Sell_flag = false
Sell_Type = 0

jiangli_ui = nil
jiangli_window = nil
selected_ibtn_index = 1

--未解锁职业描述
Characters_describe = 
{
	"",
	lang:GetText("血量最高的重型火力压制职业"),
	"",
	"",
	lang:GetText("在炽焰中移动的近距离突击职业"),
	"",
	"",
	"",
	"",
	""
}

--新手训练关
local create_training_ui = nil
local create_shimingzhi_ui = nil

current_Storageitem = nil
--当前Avatar显示阵营
current_Avatar_Team = 0

--当前商城玩家选择的武器类型
current_SelectedWeaponType_ShoppingMall = 1

local state = ptr_cast(game.CurrentState)

--rpc返回值 保存
LevelInfo_rpc_data = nil
CharactersInfo_rpc_data = nil
OtherCharactersInfo_rpc_data = nil
CharactersIB_rpc_data = nil
ShoppingMallIB_rpc_data = nil
PersonalInfo_data = nil
Characters_BagInfo_rpc_data = nil
Character_list_rpc_data = nil

--新模块打开状态
module_state = nil
--临时变量
module_state_Onuse = false

local prop_index = -1

--好友列表保存
Friends_rpc_data = nil
Black_rpc_data = nil
partners_rpc_data = nil
--玩家搜索 rpc
Search_rpc_data = nil

--玩家群组 rpc 保存
MyGroup_rpc_data = nil
AddGroup_rpc_data = nil

--系统喇叭控件
local Server_Horn = false

--进入频道Bool控件
Channl_Enter = false

OL_Award_List = nil

--邀请屏蔽bool控件
On_Invite_State = true

--私聊查看个人信息（name，id）
local Look_play_Info = {}
local Look_Indx = 0

--自动开始控件（临时）
Timer_control =
{
	Gui.AnimControl "Timer"
	{
		Size = Vector2(50,16),
		Location = Vector2(325,15),
		BackgroundColor = ARGB(0, 255, 255, 255),
		TextColor = ARGB(127, 254, 251, 245),
		FontSize = 16,
	},
}
--销毁物品
-- 参数列表
-- uid=帐号id
-- pid=帐号id
-- t	(该物品的type)
-- piid=物品的id(playerItemId)
function DestroyItem(index)
	if current_Storageitem[index] then
		local strInfo = lang:GetText("您确定要销毁“") .. current_Storageitem[index].display ..lang:GetText("”吗？\n【注：一经销毁不可恢复】")
		MessageBox.ShowWithConfirmCancel(strInfo,
			function(sender,e)
				--L_MessageBox.ShowWaiter(lang:GetText("正在销毁您的物品：") .. "“" .. current_Storageitem[index].display .. "”")			
				rpc.safecall("storage_destroy", {uid = state:GetUserId(), pid = state:GetCharacterId(), t = current_character_storage, piid = current_Storageitem[index].playeritemid},
					function (data)
					if data then
						print(lang:GetText("删除物品"))
					end
					if current_character_storage == 1 then
						local num = 0
						for i = 1, 8 do
							local ibbtn = ptr_cast(L_Characters.ib_weapon_ui.ctrl_ib_container:GetChildByIndex(i-1))
							if ibbtn and ibbtn.BtnVisible == true then
								num = num + 1
							end
						end
						if num == 1 then
							CurrentCharacterPages[L_LobbyMain.current_choose_class][L_LobbyMain.current_character_storage] = 1
						end
					elseif current_character_storage == 2 then
						local num = 0
						for i = 1, 8 do
							local ibbtn = ptr_cast(L_Characters.ib_dress_ui.ctrl_ib_container:GetChildByIndex(i-1))
							if ibbtn and ibbtn.BtnVisible == true then
								num = num + 1
							end
						end
						if num == 1 then
							CurrentCharacterPages[L_LobbyMain.current_choose_class][L_LobbyMain.current_character_storage] = 1
						end
					elseif current_character_storage == 3 then
						local num = 0
						for i = 1, 16 do
							local ibbtn = ptr_cast(L_Characters.ib_accessories_ui.ctrl_ib_container:GetChildByIndex(i-1))
							if ibbtn and ibbtn.BtnVisible == true then
								num = num + 1
							end
						end
						if num == 1 then
							CurrentCharacterPages[L_LobbyMain.current_choose_class][L_LobbyMain.current_character_storage] = 1
						end
					elseif current_character_storage > 3 and current_character_storage < 9 then
						local num = 0
						for i = 1, 28 do
							local ibbtn = ptr_cast(L_Characters.prop_window_ui.ctrl_ib_container:GetChildByIndex(i-1))
							if ibbtn and ibbtn.BtnVisible == true then
								num = num + 1
							end
						end
						if num == 1 then
							CurrentCharacterPages[L_LobbyMain.current_choose_class][L_LobbyMain.current_character_storage] = 1
						end
					end
					FillClassBag(ptr_cast(game.CurrentState):GetCharacterId(), current_choose_class)
					if L_LobbyMain.current_character_storage > 3 then
						L_LobbyMain.current_character_storage = L_Characters.current_selected_type[L_Characters.current_selected_type_index][1]
						L_LobbyMain.FillClassStorage(L_Characters.current_selected_type[L_Characters.current_selected_type_index][2])
					else
						L_LobbyMain.FillClassStorage()
					end
					L_MessageBox.CloseWaiter()
				end)			
			end,
		nil)
	end
end
--职业名称
ClassName =
{
	lang:GetText("火箭兵 "),
	lang:GetText("重机枪手 "),
	lang:GetText("狙击手 "),
	lang:GetText("突击手 "),
	lang:GetText("火焰兵 "),
	lang:GetText("罗护士 "),
	lang:GetText("工程兵 "),
	lang:GetText("间  谍 "),
	lang:GetText("冰球手 "),
	lang:GetText("机枪兵 "),
}

--角色管理当前职业Avatar背包索引
ClassBagIndex_Characters = 
{
	1,
	1, 
	1,
	1,
	1,
	1,
	1,
	1,
	1,
	1,
}

--角色管理当前职业Avatar武器
ClassWeaponIndex_Characters = 
{
	1,
	1, 
	1,
	1,
	1,
	1,
	1,
	1,
	1,
	1,
}

--商城当前职业Avatar武器
ClassWeaponIndex_ShoppingMall = 
{
	1,
	1, 
	1,
	1,
	1,
	1,
	1,
	1,
	1,
	1,
}

--当前角色管理页面索引
CurrentCharacterPages = 
{
	{1,1,1,1,1,1,1,1,1,1},
	{1,1,1,1,1,1,1,1,1,1},
	{1,1,1,1,1,1,1,1,1,1},
	{1,1,1,1,1,1,1,1,1,1},
	{1,1,1,1,1,1,1,1,1,1},
	{1,1,1,1,1,1,1,1,1,1},
	{1,1,1,1,1,1,1,1,1,1},
	{1,1,1,1,1,1,1,1,1,1},
	{1,1,1,1,1,1,1,1,1,1},
	{1,1,1,1,1,1,1,1,1,1},
}

--当前商城页面索引
CurrentShoppingMallPages = 
{
	{1,1,1,1,1,1,1,1,1,1},
	{1,1,1,1,1,1,1,1,1,1},
	{1,1,1,1,1,1,1,1,1,1},
	{1,1,1,1,1,1,1,1,1,1},
	{1,1,1,1,1,1,1,1,1,1},
	{1,1,1,1,1,1,1,1,1,1},
	{1,1,1,1,1,1,1,1,1,1},
	{1,1,1,1,1,1,1,1,1,1},
	{1,1,1,1,1,1,1,1,1,1},
	{1,1,1,1,1,1,1,1,1,1},
}
--购物车信息
CharactersCartInfo =
{
	{
		{},
		{},
		{},
		{},
		{},
		{},
		{},
	},
	{
		{},
		{},
		{},
		{},
		{},
		{},
		{},
	},
	{
		{},
		{},
		{},
		{},
		{},
		{},
		{},
	},
	{
		{},
		{},
		{},
		{},
		{},
		{},
		{},
	},
	{
		{},
		{},
		{},
		{},
		{},
		{},
		{},
	},
	{
		{},
		{},
		{},
		{},
		{},
		{},
		{},
	},
	{
		{},
		{},
		{},
		{},
		{},
		{},
		{},
	},
	{
		{},
		{},
		{},
		{},
		{},
		{},
		{},
	},
	{
		{},
		{},
		{},
		{},
		{},
		{},
		{},
	},
	{
		{},
		{},
		{},
		{},
		{},
		{},
		{},
	},
}
--Avatar预览信息
AvatarPreviewInfo =
{
	{
		{},
		{},
		{},
		{},
		{},
		{},
		{},
	},
	{
		{},
		{},
		{},
		{},
		{},
		{},
		{},
	},
	{
		{},
		{},
		{},
		{},
		{},
		{},
		{},
	},
	{
		{},
		{},
		{},
		{},
		{},
		{},
		{},
	},
	{
		{},
		{},
		{},
		{},
		{},
		{},
		{},
	},
	{
		{},
		{},
		{},
		{},
		{},
		{},
		{},
	},
	{
		{},
		{},
		{},
		{},
		{},
		{},
		{},
	},
	{
		{},
		{},
		{},
		{},
		{},
		{},
		{},
	},
	{
		{},
		{},
		{},
		{},
		{},
		{},
		{},
	},
	{
		{},
		{},
		{},
		{},
		{},
		{},
		{},
	},
}
--初始化大厅信息
function InitAllInfo()
	--初始化RPC数据
	LevelInfo_rpc_data = nil
	CharactersInfo_rpc_data = nil
	CharactersIB_rpc_data = nil
	ShoppingMallIB_rpc_data = nil
	PersonalInfo_data = nil
	Characters_BagInfo_rpc_data = nil
	
	--当前选择的分页
	current_chosse_main_page = 5
	--当前选择职业
	current_choose_class = 1
	--当前角色管理 仓库选项（1武器2服装3配饰4道具567）
	current_character_storage = 1
	--当前商城 仓库选项（1武器2服装3配饰）
	current_shoppingmall_storage = 1
	--职业列表
	character_classes = nil
	character_bag = nil
	pid = nil

	freshNew = true
	resetLobby = false
	character_management_ui = nil
	boddy_info_ui = nil
	current_Storageitem = nil
	--当前Avatar显示阵营
	current_Avatar_Team = 0

	--当前商城玩家选择的武器类型
	current_SelectedWeaponType_ShoppingMall = 1
	
	if create_shimingzhi_ui then
		create_shimingzhi_ui.Close()
		create_shimingzhi_ui = nil
	end
	
	--LobbyMainWin = nil
	--LobbyMainWin_Header = nil
	--LobbyMainWin_Boddy = nil
	--LobbyMainWin_Foot = nil
	
end
function HideAll()
print("aaaaaaaaaaaa")
	--为了挂自动开始控件（临时）
	if Timer_control_ui then
		if L_WarZone.room_ui and LobbyMainWin then
			--Timer_control_ui.Timer.Visible = false
			Timer_control_ui.Timer.Parent = LobbyMainWin.Timer_Root
		end
	else
		Timer_control_ui = Gui.Create(LobbyMainWin.Timer_Root)(Timer_control)
	end
	--左侧
	L_LobbyMain.LobbyMainWin_Foot.btn_Mail.Padding = Vector4(20, 0, 0, 60)
	L_Mail.Hide()--邮件
	if not state.is_fight_team_server then
		L_FightTeam.Hide()--战队
		if (L_WarZone.IsMatchServer1() or L_WarZone.IsMatchServer()) and L_WarZone.leaveGame == true then
			L_WarZone.leaveGame = false
			state:LeaveChannel()
		end
	else
		state.battle_is_create = false
		L_FightTeam.battle_ready = false
		state:LeaveChannel()
		
		if L_FightTeam.my_battle_info then
			state:BattleGroupLeave(L_FightTeam.my_battle_info.battlegroup_id)
		end
		L_FightTeam.fightteam_fight_ui.b_pipei.Enable = true
		L_FightTeam.HideFightTeam()
	end
--	L_Friends.Hide()--好友
--	L_Friends.HideChat()--聊天窗口
	L_Chat.Hide()--聊天
	
	--中间
	L_WarZone.Hide()--战区
	L_Characters.Hide()--角色管理
	L_Present.Hide()
	--右侧
	L_ShoppingMall.Hide()--商城
	L_Mission.Hide()--任务
	L_Compose.Hide()--合成
	L_TopList.Hide()--排行榜
	L_Options.Hide()--设置
	L_Characters_manage.Hide()--职业槽
	L_PersonalInfo.Hide() --个人信息
	L_PersonalInfo.HideToolTipsWindow() 
	-- L_WarZone.HideToolTipsWindow() 
	
	if create_shimingzhi_ui then
		create_shimingzhi_ui.Close()
		create_shimingzhi_ui = nil
	end
	
	if L_FightTeam.fightteam_fight_window then
		L_FightTeam.fightteam_fight_window:Close()
		L_FightTeam.fightteam_fight_window = nil
	end
	
	LobbyMainWinFootBTN()	
	L_LobbyMain.On_Invite_State = true
	
	
end

local Gift_ui_count = 1
Gift_ui = Gui.Create()
{	
	Gui.Control "root"
	{
		Size = Vector2(1200, 900),
		Location = Vector2(0, 0),
		BackgroundColor = ARGB(0, 255, 255, 255),
		Gui.Control "r"
		{
			Size = Vector2(411, 357),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/team/lb_contact_bg1.dds", Vector4(38, 38, 38, 38)),
			},
			Gui.Control
			{
				Size = Vector2(385, 328),
				Location = Vector2(12, 13),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/lb_contact_bg2.dds", Vector4(16, 12, 16, 45)),
				},
				Gui.Label "T"
				{
					Size = Vector2(300, 60),
					Location = Vector2(44, 11),
					TextColor = ARGB(255, 52, 50, 50),
					FontSize = 20,
					TextAlign = "kAlignCenterMiddle",
					Text = lang:GetText("GM送您礼物了！！！")
				},
				Gui.Control
				{
					Size = Vector2(268, 205),
					Location = Vector2(57, 60),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/ib_achieve_box1.dds", Vector4(14, 14, 14, 14)),
					},
					Gui.Control "Image1"
					{
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/mail/lb_mail_item_bg.dds", Vector4(14, 14, 14, 14)),
						},
						BackgroundColor = ARGB(255, 255, 255, 255),
					},
					Gui.Control "Image"
					{
						BackgroundColor = ARGB(255, 255, 255, 255),
					},
					Gui.Label "description"
					{
						TextColor = ARGB(255, 52, 50, 50),
						Size = Vector2(196, 60),
						Location = Vector2(36, 150),
						TextAlign = "kAlignCenterMiddle",
						FontSize = 14,
					},
				},
				Gui.Button "next"
				{
					Style = "Gui.Mission_button",
					Location = Vector2(140, 287),
					Text = lang:GetText("下一个"),
					EventClick = function()
						Gift_ui_count = Gift_ui_count + 1
						Fill_Gift_ui(Gift_ui_count)
					end
				},
				Gui.Button "close"
				{
					Style = "Gui.Mission_button",
					Location = Vector2(140, 287),
					Text = lang:GetText("确定"),
					EventClick = function()
						Gift_ui_count = 1
						table.remove(L_PushCmd.Queue1,1)
						if L_PushCmd.Queue[1] ~= nil then
							Fill_Gift_ui(1)
						else
							L_LobbyMain.Gift_ui.root.Parent = nil
						end
					end
				},
			},
		},
	}, 
}

function Fill_Gift_ui(index)
	if Gift_ui then
		if L_PushCmd.Queue1[1] ~= nil then
			if L_PushCmd.Queue1[1].items[index][6] == 1 or L_PushCmd.Queue1[1].items[index][6] == 2 or L_PushCmd.Queue1[1].items[index][6] == 3 or L_PushCmd.Queue1[1].items[index][6] == 4 then
				Gift_ui.Image.Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ibt_icon/"..L_PushCmd.Queue1[1].items[index][2].."_"..L_PushCmd.Queue1[1].items[index][6]..".tga"),
				}
			else
				Gift_ui.Image.Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ibt_icon/"..L_PushCmd.Queue1[1].items[index][2]..".tga"),
				}
			end
			if L_PushCmd.Queue1[1].items[index][5] == 1 then
				Gift_ui.Image.Size = Vector2(172, 78)
				Gift_ui.Image.Location = Vector2(48, 50)
				Gift_ui.Image1.Size = Vector2(172, 78)
				Gift_ui.Image1.Location = Vector2(48, 50)
			elseif L_PushCmd.Queue1[1].items[index][5] == 2 then
				Gift_ui.Image1.Size = Vector2(84, 156)
				Gift_ui.Image1.Location = Vector2(92, 11)
				Gift_ui.Image.Size = Vector2(84, 156)
				Gift_ui.Image.Location = Vector2(92, 11)
			else
				Gift_ui.Image1.Size = Vector2(84, 78)
				Gift_ui.Image1.Location = Vector2(92, 50)
				Gift_ui.Image.Size = Vector2(84, 78)
				Gift_ui.Image.Location = Vector2(92, 50)
			end
			Gift_ui.description.Text = L_PushCmd.Queue1[1].items[index][3]
			if L_PushCmd.Queue1[1].num == index then
				Gift_ui.next.Visible = false
				Gift_ui.close.Visible = true
			else
				Gift_ui.next.Visible = true
				Gift_ui.close.Visible = false
			end
		end
		Gift_ui_count = index
	end
end

--第一次登入游戏领取任务
Mission = Gui.Create()
{
	Gui.Control "root"
	{
		Size = Vector2(1200, 900),
		Location = Vector2(0, 0),
		BackgroundColor = ARGB(0, 255, 255, 255),
		Gui.Control "r"
		{
			Size = Vector2(729, 337),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/team/lb_contact_bg1.dds", Vector4(38, 38, 38, 38)),
			},
			Gui.Control
			{
				Size = Vector2(697, 305),
				Location = Vector2(16, 16),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/lb_contact_bg2.dds", Vector4(16, 12, 16, 45)),
				},
				Gui.Label
				{
					Size = Vector2(200, 30),
					Location = Vector2(300, 10),
					Text = lang:GetText("每日任务"),
					FontSize = 20,
					TextColor = ARGB(255, 52, 50, 50),
				},
				Gui.Control
				{
					Size = Vector2(679, 213),
					Location = Vector2(9, 40),
					BackgroundColor = ARGB(0, 255, 255, 255),
					Gui.FlowLayout "scrollLayout"
					{
						Dock = "kDockFill",
						ControlSpace = 31,
						LineSpace = 50,
						Padding = Vector4(15, 23, 0, 0),
					},
				},
				Gui.Button "close"
				{
					Style = "Gui.Mission_button",
					Location = Vector2(293, 266),
					Text = lang:GetText("确定"),
					EventClick = function()
						L_LobbyMain.Mission.root.Parent = nil
					end
				},
			},
		},
	},
}

--line 	行
--list 	列
--w 	宽
--h 	高
--index 序号
local function Creat_ItemBoxBtn(line,list,w,h,index)
	return Gui.ItemBoxBtn
	{
		Style = "Gui.ItemBoxBtn_ib",
		Size = Vector2(100, 100),
		Location = Vector2(103*(line-1),103*(list-1)),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Skin = Gui.ItemBoxBtnSkin
		{
			NeutralNormalImage = Gui.Image("LobbyUI/ShoppingMall/vip_chest/lb_vipgifts_slot_01_normal.dds", Vector4(0, 0, 0, 0)),
			NeutralSelectedImage = Gui.Image("LobbyUI/ShoppingMall/vip_chest/lb_vipgifts_slot_01_normal.dds", Vector4(0, 0, 0, 0)),
			NeutralDisabledImage = Gui.Image("LobbyUI/ShoppingMall/vip_chest/lb_vipgifts_slot_01_normal.dds", Vector4(0, 0, 0, 0)),
		},
		
		Padding = Vector4(5,5,5,5),

		--ToolTips 行为
		EventMouseEnter = function(sender, e)
			if now_openbox_data then
				local n = (now_openbox_page-1)*9
				local data = {}
				for i = 1,9 do
					data[i] = now_openbox_data.items[n+i]
				end
				L_ToolTips.FillToolTipsVIPPresent(index, openbox_modal.root, data)
			end
		end,
		EventToolTipsShow = function(sender, e)
			if now_openbox_data then
				local loc = sender.Location + sender.Parent.Location + sender.Parent.Parent.Location + sender.Parent.Parent.Parent.Location + sender.Parent.Parent.Parent.Parent.Location
				L_ToolTips.ShowToolTipsShowWindow(sender,Vector2(1200, 900),loc)
			end
		end,
		EventMouseLeave = function(sender, e)
			L_ToolTips.HideToolTipsWindow()
		end,
	}
end

--开箱子
use_open_box = Gui.Create()
{
	Gui.Control "content"
	{
		Size = Vector2(1200,900),
		Dock = "kDockCenter",
		BackgroundColor = ARGB(0, 0, 0, 0),
		
		Gui.Control "bg"
		{
			Size = Vector2(384,528),
			Dock = "kDockCenter",
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/open_box/main_bar01.dds",Vector4(20, 20, 20, 20)),
			},
			Gui.Control
			{
				Size = Vector2(354,498),
				Dock = "kDockCenter",
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/open_box/main_bar02.dds",Vector4(8, 8, 8, 8)),
				},
				
				Gui.Control "get_gold"
				{
					Size = Vector2(336,40),
					Location = Vector2(10,32),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/open_box/main_bar03.dds",Vector4(8, 8, 8, 8)),
					},
					Gui.Label
					{
						Size = Vector2(100, 38),
						Location = Vector2(8, 1),
						TextColor = ARGB(255, 255, 180, 0),
						FontSize = 22,
						TextAlign = "kAlignCenterMiddle",
						Text = lang:GetText("获得"),
					},
					Gui.Label "gold"
					{
						Size = Vector2(200, 38),
						Location = Vector2(100, 1),
						TextColor = ARGB(255, 255, 110, 0),
						FontSize = 16,
						TextAlign = "kAlignLeftMiddle",
						Text = "",
					},
				},

				Gui.Control
				{
					Size = Vector2(336,368),
					Location = Vector2(10,77),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/open_box/main_bar03.dds",Vector4(8, 8, 8, 8)),
					},
					Gui.Control "itemboxbtn_groups"
					{
						Size = Vector2(310,310),
						Location = Vector2(14,12),
						BackgroundColor = ARGB(0, 255, 255, 255),
						
						Creat_ItemBoxBtn(1,1,100,100,1),
						Creat_ItemBoxBtn(2,1,100,100,2),
						Creat_ItemBoxBtn(3,1,100,100,3),
						Creat_ItemBoxBtn(1,2,100,100,4),
						Creat_ItemBoxBtn(2,2,100,100,5),
						Creat_ItemBoxBtn(3,2,100,100,6),
						Creat_ItemBoxBtn(1,3,100,100,7),
						Creat_ItemBoxBtn(2,3,100,100,8),
						Creat_ItemBoxBtn(3,3,100,100,9),
					},
				},
				
				Gui.Control "ctrl_bottom_container"
				{							
					Size = Vector2(136, 32),
					Location = Vector2(110, 407),
					BackgroundColor = ARGB(0, 255, 255, 255),

					--上一页
					Gui.Button "btn_front_page"
					{
						Size = Vector2(14, 30),
						Location = Vector2(0, 1),
						TextColor = ARGB(255, 255, 246, 235),
						FontSize = 18,
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button05_normal.dds", Vector4(0, 0, 0, 0)),
							HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button05_hover.dds", Vector4(0, 0, 0, 0)),
							DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button05_down.dds", Vector4(0, 0, 0, 0)),
							DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button05_normal.dds", Vector4(0, 0, 0, 0)),
						},
						EventClick = function()
							local length_page = math.ceil(#now_openbox_data.items/9)
							if now_openbox_page > 1 then
								now_openbox_page = now_openbox_page - 1
								FillOpenBox(now_openbox_data)
								use_open_box.lb_page_number.Text = now_openbox_page.."/"..length_page
							end
						end
					},
					
					--页码
					Gui.Label "lb_page_number"
					{
						Location = Vector2(18, 1),
						Size = Vector2(100, 30),
						FontSize = 24,
						TextAlign = "kAlignCenterMiddle",
						TextColor = ARGB(255, 103, 102, 98),
						Text = "1/1",
						BackgroundColor = ARGB(255, 255, 255, 255),

						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button06_bg.dds", Vector4(14, 14, 14, 14)),
						},
					},

					--下一页
					Gui.Button "btn_next_page"
					{
						Size = Vector2(14, 30),
						Location = Vector2(122, 1),
						TextColor = ARGB(255, 255, 246, 235),
						FontSize = 18,
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button06_normal.dds", Vector4(0, 0, 0, 0)),
							HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button06_hover.dds", Vector4(0, 0, 0, 0)),
							DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button06_down.dds", Vector4(0, 0, 0, 0)),
							DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button06_normal.dds", Vector4(0, 0, 0, 0)),
						},
						EventClick = function()
							local length_page = math.ceil(#now_openbox_data.items/9)
							if now_openbox_page < length_page then
								now_openbox_page = now_openbox_page + 1
								FillOpenBox(now_openbox_data)
								use_open_box.lb_page_number.Text = now_openbox_page.."/"..length_page
							end
						end
					},
				},
				
				Gui.Button "bt_ok"
				{
					Size = Vector2(200,44),
					Location = Vector2(76, 450),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_normal.dds", Vector4(0, 0, 0, 0)),
						HoverImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_hover.dds", Vector4(0, 0, 0, 0)),
						DownImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_down.dds", Vector4(0, 0, 0, 0)),
						DisabledImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_disabled.dds", Vector4(0, 0, 0, 0)),
					},
					Text = lang:GetText("确定"),
					TextColor = ARGB(255, 229, 255, 252),
					TextAlign = "kAlignCenterMiddle",
					HighlightTextColor = ARGB(255, 255, 246, 235),
					EventClick = function()
						if openbox_modal then
							ModalWindow.CloseAll()
							openbox_modal = nil
							if L_LobbyMain.current_character_storage > 3 then
								L_LobbyMain.current_character_storage = L_Characters.current_selected_type[L_Characters.current_selected_type_index][1]
								L_LobbyMain.FillClassStorage(L_Characters.current_selected_type[L_Characters.current_selected_type_index][2])
							else
								L_LobbyMain.FillClassStorage()
							end
							-- FillClassStorage()
							MessageBox.ShowWithTimer(1,lang:GetText("奖励物品已放入仓库中！"))
							gui:PlayAudio("kUIA_GETITEM")
						--	L_LobbyMain.On_Invite_State = true
						end
					end
				},
			},
			--title
			Gui.Control
			{
				Size = Vector2(360,52),
				Location = Vector2(14,2),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/open_box/title.dds",Vector4(0, 0, 0, 0)),
				},
			},
		},
	},
}

function FillOpenBox(data)
	if data then
		if data.gp ~= nil then
			use_open_box.gold.Text = data.gp..lang:GetText(" C币")
		else
			use_open_box.gold.Text = lang:GetText("0 C币")
		end
		local length = #data.items
		local page = math.ceil(length / 9)
		use_open_box.lb_page_number.Text = now_openbox_page.."/"..page
		for i = 1,9 do
			local ibbtn = ptr_cast(use_open_box.itemboxbtn_groups:GetChildByIndex(i - 1))
			ibbtn.ItemLevel = nil
			ibbtn:OnDestroy()
			local j = ((now_openbox_page-1)*9+i)
			if data.items[j] ~= nil then
				ibbtn.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..data.items[j].name..".tga")
				if data.items[j].common and data.items[j].common.rareLevel then
					ibbtn.ItemLevel = Skin.rarelevel[math.ceil(data.items[j].common.rareLevel/25)]
				end
				ibbtn.Enable = true
				if data.items[j].common.type == 4 and data.items[j].common.subtype == 7 or data.items[j].common.type == 5 then
					L_Characters.CreatPresentNumCtr(ibbtn, data.items[j].common.quantity, 100, 100)
				end
			else
				ibbtn.Enable = false
				ibbtn.ItemIcon = nil
				ibbtn.ItemLevel = nil
			end
		end
	end
end

function Show_Open_box()
	if openbox_modal == nil then
		openbox_modal = ModalWindow.GetNew()
		openbox_modal.root.Size = Vector2(1200,900)
		openbox_modal.screen.AllowEscToExit = false
		use_open_box.content.Parent = openbox_modal.root
		now_openbox_page = 1
	end
end

local function create_lable(w,h,x,y,path)
	return Gui.Label
	{
		Size = Vector2(w, h),
		Location = Vector2(x, y),
		NormLocation = Vector2(x, y),
		BackgroundColor = ARGB(255, 255, 255, 255),
		MoveLocation = Vector2(0,10),
		MoveWheelTime = 0.7,
		Visible = false,
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image(path, Vector4(0, 0, 0, 0),Vector4(0, 0, 0.1, 1)),
		},
	}
end

--仓库使用经验药水
use_exp_prop = Gui.Create()
{
	Gui.Control "content"
	{
		Size = Vector2(1200,900),
		Dock = "kDockCenter",
		BackgroundColor = ARGB(0, 0, 0, 0),
		
		Gui.AnimControl "light"
		{
			Size = Vector2(440,440),
			BackgroundColor = ARGB(0, 255, 255, 255),			
			Dock = "kDockCenter",
		},
		
		Gui.TimeControl "time"
		{
			Size = Vector2(5,5),
			Dock = "kDockCenter",
			BackgroundColor = ARGB(0, 255, 255, 255),
			EventTimeOut = function(sender, e)
				if exppropmodal then
					exppropmodal.Close()
					exppropmodal = nil
				end
			end
		},
		
		Gui.Control "bg"
		{
			Size = Vector2(1200,900),
			Dock = "kDockCenter",
			BackgroundColor = ARGB(0, 255, 255, 255),
			create_lable(56,76,620-56*4,521,"LobbyUI/number.dds"),
			create_lable(56,76,620-56*3,521,"LobbyUI/number.dds"),
			create_lable(56,76,620-56*2,521,"LobbyUI/number.dds"),
			create_lable(56,76,620-56*1,521,"LobbyUI/number.dds"),
			create_lable(56,76,620-56*0,521,"LobbyUI/number.dds"),
			Gui.Control
			{
				Size = Vector2(104,160),
				Dock = "kDockCenter",
				BackgroundColor = ARGB(0, 255, 255, 255),
				Gui.Label "lab_up"
				{							
					Size = Vector2(104, 140),
					Location = Vector2(0, 10),
					NormLocation = Vector2(0, 10),
					BackgroundColor = ARGB(255, 255, 255, 255),
					MoveLocation = Vector2(0,10),
					MoveWheelTime = 0.7,
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/up.dds", Vector4(0, 0, 0, 0)),
					},
				},
			},
			Gui.Label "lab_addexp"
			{							
				Size = Vector2(312, 48),
				Location = Vector2(500, 535),
				NormLocation = Vector2(500, 535),
				BackgroundColor = ARGB(255, 255, 255, 255),
				MoveLocation = Vector2(0,10),
				MoveWheelTime = 0.7,
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/+exp.dds", Vector4(0, 0, 0, 0)),
				},
			},
			Gui.ChangeControl "Change"
			{
				Size = Vector2(1153, 572),
				Normsize = Vector2(1153, 572),
				Location = Vector2(0, 0),
				NormLocation = Vector2(0, 0),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/levelup_mark.dds", Vector4(0, 0, 0, 0)),
				},
			},
		},
	},
}

function Show_Exp_prop(p_iid)
	rpc.safecallload("storage_expitem_use", {uid = ptr_cast(game.CurrentState):GetUserId(), pid = ptr_cast(game.CurrentState):GetCharacterId(), piid = p_iid},
	function (data)
		if data then
			use_exp_prop.light:AddAnim("rotation",0.5,6)
			local sun = Gui.Icon("LobbyUI/light.dds", Vector4(0, 0, 0, 0))
			use_exp_prop.light:AddFrame("rotation",sun)
			use_exp_prop.light:StartAnimation()
			use_exp_prop.time:AddTime(3)
			
			local temp = {0, 0, 0, 0, 0}
			temp[1] = math.floor(data.expnum / 10000)*0.1
			temp[2] = math.floor(data.expnum % 10000 / 1000)*0.1
			temp[3] = math.floor(data.expnum % 1000 / 100)*0.1
			temp[4] = math.floor(data.expnum % 100 / 10)*0.1
			temp[5] = math.floor(data.expnum % 10)*0.1
			local pass = true
			for i = 1 , 5 do
				if temp[i] ~= 0 and pass == true then
					pass = false
				end
				if pass == false then
					local ibbtn = ptr_cast(use_exp_prop.bg:GetChildByIndex(i - 1))
					ibbtn.Visible = true
					ibbtn.Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/number.dds", Vector4(0, 0, 0, 0),Vector4(temp[i], 0, temp[i]+0.1, 1)),
					}
				else
					local ibbtn = ptr_cast(use_exp_prop.bg:GetChildByIndex(i - 1))
					ibbtn.Visible = false
				end
			end
			gui:PlayAudio("kUIA_USE_EXP")
			FillPersonalInfo()
			
			if now_level and now_level < data.level then 
				use_exp_prop.Change:InsertMovePoint(Vector2(0,0),1,Vector2(1153,572),ARGB(0,255,255,255))
				use_exp_prop.Change:InsertMovePoint(Vector2(405,316),1.208,Vector2(404,200),ARGB(255,255,255,255))
				use_exp_prop.Change:InsertMovePoint(Vector2(387,307),1.332,Vector2(440,218),ARGB(255,255,255,255))
				use_exp_prop.Change:InsertMovePoint(Vector2(405,316),1.540,Vector2(404,200),ARGB(255,255,255,255))
				gui:PlayAudio("kUIA_USE_EXP_LEVELUP")
			end
		end
	end)
end

--新手训练关
local create_training_window =
{
	Gui.Control "training_window"
	{
		Size = Vector2(1680, 1050),
		Location = Vector2(0, 0),
		BackgroundColor = ARGB(0, 255, 255, 255),
		
		Gui.Control "ctrl_training"
		{
			Size = Vector2(604, 304),
			BackgroundColor = ARGB(255,255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("Login/lb_popup_bg02.dds", Vector4(36, 36, 38, 38)),
			},

			--介绍
			Gui.Label "lbl_training_tip"
			{
				Size = Vector2(500,200),
				Location = Vector2(60,0),
				Margin = Vector4(5,5,5,5),
				TextColor = ARGB(255, 52, 50, 50),
				BackgroundColor = ARGB(0,255, 255, 255),
				FontSize = 24,
				AutoWrap = true,
				Text = lang:GetText("欢迎来到大冲锋。接下来将进入新手关开启新手引导。完成新手关你可以获得奖品。而新手引导可以帮助你更快更好的了解大冲锋的操作。"),
			},
		
			--确定按钮
			Gui.Button "btn_ok"
			{
				Enable = false,
				Size = Vector2(140, 50),
				Location = Vector2(150 , 233),
				Text = lang:GetText("确 定"),
				Padding = Vector4(0, 0, 0, 7),
				TextColor = ARGB(255, 211, 211, 211),
				HighlightTextColor = ARGB(255, 211, 211, 211),
				TextAlign = "kAlignCenterMiddle",
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/lb_contact_button_normal.tga", Vector4(5, 5, 5, 5)),
					HoverImage = Gui.Image("LobbyUI/team/lb_contact_button_hover.tga", Vector4(5, 5, 5, 5)),
					DownImage = Gui.Image("LobbyUI/team/lb_contact_button_down.tga", Vector4(5, 5, 5, 5)),
					DisabledImage = Gui.Image("LobbyUI/team/lb_contact_button_normal.tga", Vector4(5, 5, 5, 5)),			
				},
				FontSize = 30,
				EventClick = function()
					if create_training_ui then
						create_training_ui.training_window.Visible = false
						create_training_ui.ctrl_training.Parent = nil
						create_training_ui.ctrl_training.Visible = false
					end
					
					if L_WarZone then
						L_WarZone.novice_need_in = true
						L_WarZone.EnterNoviceServer()
					end
				end,
			},
			Gui.Button "btn_cancel"
			{
				Enable = false,
				Size = Vector2(140, 50),
				Location = Vector2(300 , 233),
				Text = lang:GetText("取 消"),
				Padding = Vector4(0, 0, 0, 7),
				TextColor = ARGB(255, 211, 211, 211),
				HighlightTextColor = ARGB(255, 211, 211, 211),
				TextAlign = "kAlignCenterMiddle",
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/lb_contact_button_normal.tga", Vector4(5, 5, 5, 5)),
					HoverImage = Gui.Image("LobbyUI/team/lb_contact_button_hover.tga", Vector4(5, 5, 5, 5)),
					DownImage = Gui.Image("LobbyUI/team/lb_contact_button_down.tga", Vector4(5, 5, 5, 5)),
					DisabledImage = Gui.Image("LobbyUI/team/lb_contact_button_normal.tga", Vector4(5, 5, 5, 5)),			
				},
				FontSize = 30,
				EventClick = function()
					if create_training_ui then
						create_training_ui.training_window.Visible = false
						create_training_ui.ctrl_training.Parent = nil
						create_training_ui.ctrl_training.Visible = false
						
						local args = {pid = state:GetCharacterId()}
						rpc.safecall("end_new", args, EndNew)
					end
					if L_WarZone then
						L_WarZone.novice_need_in = false
					end
				end,
			},
		},
	},	
}

function EndNew(data)
	
end

local function SetVipTime(isvip,leftMinites)
	if isvip == 1 then
		if leftMinites > 0 then
			LobbyMainWin.lab_Viptimer_dlb:Show()
		end
	end
end

--大厅主窗口
LobbyMainWin = Gui.Create(gui)
{
	Gui.Control "LobbyMain_Root_Parent"
	{
		Size = Vector2(1600, 900),
		BackgroundColor = ARGB(0, 255, 255, 255),
		Location = Vector2(0, 0),
		
		--为了挂自动开始控件（临时）
		Gui.Control "Timer_Root"
		{
			Size = Vector2(1200, 900),
			BackgroundColor = ARGB(0, 255, 255, 255),
			Location = Vector2(200, 0),
		},
		
		--大喇叭 发送时间限制控件
		Gui.Label "lab_timer_dlb"
		{
			Size = Vector2(1200,900),
			Location = Vector2(0, 0),
			BackgroundColor = ARGB(0, 255, 255, 255),
			Visible = false,
			UseTimer = true,
			DisplayTime = 3,
			
			EventClose = function()
				print(lang:GetText("关闭"))
			end,
		},
		
		--VIP tips 时间更新控件
		Gui.Label "lab_Viptimer_dlb"
		{
			Size = Vector2(1200,900),
			Location = Vector2(0, 0),
			BackgroundColor = ARGB(0, 255, 255, 255),
			Visible = false,
			UseTimer = true,
			DisplayTime = 60,
			
			EventClose = function()
				if PersonalInfo_data then
					PersonalInfo_data.leftMinites = PersonalInfo_data.leftMinites - 1
					SetVipTime(PersonalInfo_data.isvip,PersonalInfo_data.leftMinites)
				end
			end,
		},
		
		Gui.Label "invite_Timer"
		{
			Size = Vector2(1200,900),
			Location = Vector2(0, 0),
			BackgroundColor = ARGB(0, 255, 255, 255),
			Visible = true,
			UseTimer = true,
			DisplayTime = 180,
			
			EventClose = function()
				LobbyMainWin.invite_Timer:Show()
				if config.Invite == true then
					return
				end
				if L_WarZone.is_novice == true then
					return
				end
				if L_WarZone.host_character_info and L_WarZone.host_character_info.is_host == false and L_WarZone.host_character_info.ready then
					return
				end
				if L_LobbyMain.On_Invite_State == false then
					return
				end
				if L_WarZone.match_window_ui then
					return
				end
				if L_WarZone.automatic_match_ui then
					return
				end
				local room_info = state:GetSelfRoomInfo()
				if L_WarZone.channel_name ~= "" and room_info.id > 0 then
					return
				end
				local room_count = state:GetRoomCount()
				local small_num = 1000
				local playername = nil
				local num1 = 0
				local num2 = 0
				if room_count <= 0 then
					return
				end
				for i = 0, room_count - 1 do
					room_info = state:GetRoomInfo(i)
					if (room_info.option.use_password ~= true) and (room_info.option.client_count > room_info.client_count) and room_info.option.can_join_on_playing and room_info.state == 2 then
						num1 = L_LobbyMain.PersonalInfo_data.level - room_info.character_level
						num2 = L_LobbyMain.PersonalInfo_data.level - small_num
						if num1 < 0 then
							num1 = num1*(-1)
						end
						if num2 < 0 then
							num2 = num2*(-1)
						end
						if num1<num2 then
							small_num = room_info.character_level
							playername = room_info.host_name
							break
						end
					end
				end
				if playername == nil then
					return
				end
				if state.is_fight_team_server then
					return
				end
				MessageBox.ShowWithTimers(5,lang:GetText("房主为")..playername..lang:GetText("的房间\n邀请你进入") ,lang:GetText("接 受") ,lang:GetText("拒 绝") ,
													function()
														L_LobbyMain.GotoPlayerRoom(playername,false)
													end,
													function() 
														return
													end)
			end,
		},
		
		Gui.Control 
		{
			Size = Vector2(1200, 900),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Location = Vector2(200, 0),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/lb_bg_win01_4.dds", Vector4(0, 0, 0, 0)),
			},
			
			Gui.Control
			{
				Location = Vector2(37, 40),
				Size = Vector2(130, 70),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/logo_1.dds", Vector4(0, 0, 0, 0)),
				},
			},
			
			Gui.FlashControl
			{
				Text = "lb_logo",
				Location = Vector2(37, 40),
				Size = Vector2(130, 70),
				BackgroundColor = ARGB(255, 255, 255, 255),
			},
		},
		
		Gui.Control "LobbyMain_Root"
		{
			Size = Vector2(1200, 900),
			BackgroundColor = ARGB(0, 255, 255, 255),
			Location = Vector2(200, 0),
		},
			
		Gui.Button "Manage_list"
		{
			Size = Vector2(120, 96),
			Location = Vector2(229, 142),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/Manage/lb_manage_button03_normal.dds", Vector4(0, 0, 0, 0)),
				HoverImage = Gui.Image("LobbyUI/Manage/lb_manage_button03_hover.dds", Vector4(0, 0, 0, 0)),
				DownImage = Gui.Image("LobbyUI/Manage/lb_manage_button03_down.dds", Vector4(0, 0, 0, 0)),
				DisabledImage = Gui.Image("LobbyUI/Manage/lb_manage_button03_disable.dds", Vector4(0, 0, 0, 0)),
				TwinkleImage  = Gui.Image("LobbyUI/Manage/lb_manage_button03_flash.dds", Vector4(0, 0, 0, 0)),
			},
			EventClick = function()
				if current_chosse_main_page ~= 13 then
					L_LobbyMain.HideAll()
					L_Characters_manage.Show(L_LobbyMain.LobbyMainWin_Boddy.LobbyMainWin_Boddy_Root)					
					lg:SetLobbyModules(13)
					current_chosse_main_page = 13
					gui:PlayAudio("kUIA_CLOSE_UI2")
				end
			end
		},
		
		Gui.Button "video_button"
		{
			Size = Vector2(120, 96),
			Location = Vector2(346, 142),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/Manage/lb_video_button_01_normal.dds", Vector4(0, 0, 0, 0)),
				HoverImage = Gui.Image("LobbyUI/Manage/lb_video_button_01_hover.dds", Vector4(0, 0, 0, 0)),
				DownImage = Gui.Image("LobbyUI/Manage/lb_video_button_01_down.dds", Vector4(0, 0, 0, 0)),
				DisabledImage = Gui.Image("LobbyUI/Manage/lb_video_button_01_disable.dds", Vector4(0, 0, 0, 0)),
			},
			EventClick = function()
				L_WarZone.ShowVideo()
			end
		},
		
		-- "Manage_list" BUT 覆盖层
		Gui.Control
		{
			Size = Vector2(240, 60),
			Location = Vector2(234, 115),
			BackgroundColor = ARGB(0, 255, 255, 255),
		},
			
		--聊天父窗口
		Gui.Control"ctr_ChatWin"
		{
			Size = Vector2(860, 32),
			BackgroundColor = ARGB(0, 255, 255, 255),
			Location = Vector2(530, 789),
		},
		
		Gui.Control "ctr_Create_Chat_Private"
		{
			Size = Vector2(244, 260),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Location = Vector2(200, 0),
			Visible = false,
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_bg1.dds", Vector4(28, 28, 28, 28)),
			},

			Gui.Label "lb_Name"
			{
				Location = Vector2(10, 12),
				Size = Vector2(170, 19),
				FontSize = 14,
				TextAlign = "kAlignLeftMiddle",
				TextColor = ARGB(255, 37, 37, 37),
				HighlightTextColor = ARGB(255, 37, 37, 37),
				Text = ""
			},
			
			Gui.Button "btn_play_info"
			{
				Size = Vector2(20,20),
				Location = Vector2(175, 11),
				BackgroundColor = ARGB(255, 255, 255, 255),
				TextColor = ARGB(255, 229, 255, 252),
				TextAlign = "kAlignCenterMiddle",
				HighlightTextColor = ARGB(255, 229, 255, 252),
				Padding = Vector4(0, 0, 0, 5),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_button_chakan_normal.dds", Vector4(0, 0, 0, 0)),
					HoverImage = Gui.Image("LobbyUI/Friends/lb_contact_button_chakan_hover.dds", Vector4(0, 0, 0, 0)),
					DownImage = Gui.Image("LobbyUI/Friends/lb_contact_button_chakan_down.dds", Vector4(0, 0, 0, 0)),
					DisabledImage = Gui.Image("LobbyUI/Friends/lb_contact_button_chakan_normal.dds", Vector4(0, 0, 0, 0)),
				},
				EventClick = function()
					for i = 1 , 10 do
						if L_Friends.ChatBTNSign == L_Friends.ChatInfo[i][1] and L_Friends.ChatInfo[i][8] > 0 then
							L_PersonalInfo.ShowPerson(L_LobbyMain.LobbyMainWin_Boddy.LobbyMainWin_Boddy_Root,L_Friends.ChatInfo[i][8],L_Friends.ChatInfo[i][3])
						end
					end
				end,
			},
			
			Gui.Control 
			{
				Size = Vector2(226, 184),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Location = Vector2(9, 33),
				
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Friends/lb_chat_bg2.dds", Vector4(23, 23, 23, 23)),
				},
					
				Gui.TextArea "tarea_Private"
				{
					Style = "Gui.TextAreaWithVBar",
					Size = Vector2(220, 174),
					FontSize = 14,
					Location = Vector2(0, 5),
					TextColor = ARGB(255, 0, 0, 0),
					HighlightTextColor = ARGB(255, 0, 0, 0),
					Readonly = true,
					Fold = true,
					VScrollBarWidth = 8,
					VScrollBarButtonSize = 1,
					VScrollBarPos = Vector2(0, 0),
					Padding = Vector4(5, 5, 5, 5),
				
					EventTextChanged = function()
						L_LobbyMain.LobbyMainWin.tarea_Private:ScrollToEnd()
					end
				},
			},

			Gui.Control"ctr_Private_write"
			{
				Size = Vector2(217, 27),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Location = Vector2(13, 220),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_bg3_normal.dds", Vector4(8, 8, 8, 8)),
				},
			},
			
			--最小化
			Gui.Button
			{
				Size = Vector2(20,20),
				Location = Vector2(196, 11),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Friends/lb_chat_button1_normal.dds", Vector4(0, 0, 0, 0)),
					HoverImage = Gui.Image("LobbyUI/Friends/lb_chat_button1_hover.dds", Vector4(0, 0, 0, 0)),
					DownImage = Gui.Image("LobbyUI/Friends/lb_chat_button1_down.dds", Vector4(0, 0, 0, 0)),
					DisabledImage = Gui.Image("LobbyUI/Friends/lb_chat_button1_normal.dds", Vector4(0, 0, 0, 0)),
				},
				EventClick = function()
					L_Friends.ChatPrivateWinMin()
				end
			},
			
			--退出
			Gui.Button
			{
				Size = Vector2(20,20),
				Location = Vector2(217, 11),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_buttonX_normal.dds", Vector4(0, 0, 0, 0)),
					HoverImage = Gui.Image("LobbyUI/Friends/lb_contact_buttonX_hover.dds", Vector4(0, 0, 0, 0)),
					DownImage = Gui.Image("LobbyUI/Friends/lb_contact_buttonX_down.dds", Vector4(0, 0, 0, 0)),
					DisabledImage = Gui.Image("LobbyUI/Friends/lb_contact_buttonX_normal.dds", Vector4(0, 0, 0, 0)),
				},
				EventClick = function()
					L_Friends.HideChatPrivateWin()
				end
			},

		},
		
		Gui.Control "ctr_Group_Chat_Win"
		{
			Size = Vector2(408, 260),--329 260
			BackgroundColor = ARGB(255, 255, 255, 255),
			Location = Vector2(200, 0),
			Visible = false,
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_bg1.dds", Vector4(28, 28, 28, 28)),
			},
			
			Gui.Label "lb_Group_Name"
			{
				Location = Vector2(18, 12),
				Size = Vector2(240, 19),
				FontSize = 14,
				TextAlign = "kAlignLeftMiddle",
				TextColor = ARGB(255, 37, 37, 37),
				HighlightTextColor = ARGB(255, 37, 37, 37),
				Text = ""
			},
			
			--最小化
			Gui.Button
			{
				Size = Vector2(20,20),
				Location = Vector2(358, 11),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Friends/lb_chat_button1_normal.dds", Vector4(0, 0, 0, 0)),
					HoverImage = Gui.Image("LobbyUI/Friends/lb_chat_button1_hover.dds", Vector4(0, 0, 0, 0)),
					DownImage = Gui.Image("LobbyUI/Friends/lb_chat_button1_down.dds", Vector4(0, 0, 0, 0)),
					DisabledImage = Gui.Image("LobbyUI/Friends/lb_chat_button1_normal.dds", Vector4(0, 0, 0, 0)),
				},
				EventClick = function()
					L_Friends.ChatGroupWinWin()
				end
			},
			
			--退出
			Gui.Button
			{
				Size = Vector2(20,20),
				Location = Vector2(379, 11),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_buttonX_normal.dds", Vector4(0, 0, 0, 0)),
					HoverImage = Gui.Image("LobbyUI/Friends/lb_contact_buttonX_hover.dds", Vector4(0, 0, 0, 0)),
					DownImage = Gui.Image("LobbyUI/Friends/lb_contact_buttonX_down.dds", Vector4(0, 0, 0, 0)),
					DisabledImage = Gui.Image("LobbyUI/Friends/lb_contact_buttonX_normal.dds", Vector4(0, 0, 0, 0)),
				},
				EventClick = function()
					L_Friends.HideChatPrivateWin()
				end
			},
			
			Gui.Control
			{
				Size = Vector2(387, 184),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Location = Vector2(9, 33),
				
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Friends/lb_chat_bg2.dds", Vector4(23, 23, 23, 23)),
				},

				Gui.Control
				{
					Size = Vector2(200, 174),--107  174
					BackgroundColor = ARGB(255, 255, 255, 255),
					Location = Vector2(4, 5),
					
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/Friends/lb_chat_bg3.dds", Vector4(13, 13, 13, 13)),
					},
					
					Gui.Label"lb_List_Name"
					{
						Size = Vector2(194, 28),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Location = Vector2(3, 2),
						FontSize = 14,
						Text = "",
						TextAlign = "kAlignCenterMiddle",
						TextColor = ARGB(255, 37, 37, 37),
						TextPadding = Vector4(0, 0, 0, 5),
						
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/Friends/lb_chat_bg5.dds", Vector4(3, 3, 3, 8)),
						},
						
						Gui.Control "ctr_list_type"
						{	
							Size = Vector2(34, 22),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Location = Vector2(8, 2),							
						},
						
						Gui.Button "btn_Group_Add"
						{
							Location = Vector2(170, 2),
							Size = Vector2(20, 20),
							BackgroundColor = ARGB(255,255,255,255),
							--Text = lang:GetText("添加组员"),							
							Skin = Gui.ButtonSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_button_add_normal.dds", Vector4(0, 0, 0, 0)),
								HoverImage = Gui.Image("LobbyUI/Friends/lb_contact_button_add_hover.dds", Vector4(0, 0, 0, 0)),
								DownImage = Gui.Image("LobbyUI/Friends/lb_contact_button_add_down.dds", Vector4(0, 0, 0, 0)),
								DisabledImage = Gui.Image("LobbyUI/Friends/lb_contact_button_add_normal.dds", Vector4(0, 0, 0, 0)),
							},
							EventClick = function()
								--MessageBox.ShowWithConfirmCancel(lang:GetText("还在制作中？"), nil)
								L_Friends.ShowGroupAddWin(gui)
								L_Friends.TebGroupAddList(1)
								GetPartnerList(1)
							end
						},
						
						Gui.Button "btn_TepGroup_Add"
						{
							Location = Vector2(170, 2),
							Size = Vector2(20, 20),
							BackgroundColor = ARGB(255,255,255,255),
							--Text = lang:GetText("添加好友"),							
							Skin = Gui.ButtonSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_button_add_normal.dds", Vector4(0, 0, 0, 0)),
								HoverImage = Gui.Image("LobbyUI/Friends/lb_contact_button_add_hover.dds", Vector4(0, 0, 0, 0)),
								DownImage = Gui.Image("LobbyUI/Friends/lb_contact_button_add_down.dds", Vector4(0, 0, 0, 0)),
								DisabledImage = Gui.Image("LobbyUI/Friends/lb_contact_button_add_normal.dds", Vector4(0, 0, 0, 0)),
							},
							EventClick = function()
								--MessageBox.ShowWithConfirmCancel(lang:GetText("还在制作中？"), nil)
								L_Friends.ShowFriendsChooseWin(gui)
								L_Friends.TepGroupListFill(L_LobbyMain.Friends_rpc_data , L_Friends.Create_Friends_Choose_ui.list_Friends_Choose_room)
							end
						},
						
						Gui.Button "btn_Group_From"
						{
							Location = Vector2(170, 2),
							Size = Vector2(20, 20),
							BackgroundColor = ARGB(255,255,255,255),
							--Text = lang:GetText("退出群组"),							
							Skin = Gui.ButtonSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_button_quit_normal.dds", Vector4(0, 0, 0, 0)),
								HoverImage = Gui.Image("LobbyUI/Friends/lb_contact_button_quit_hover.dds", Vector4(0, 0, 0, 0)),
								DownImage = Gui.Image("LobbyUI/Friends/lb_contact_button_quit_down.dds", Vector4(0, 0, 0, 0)),
								DisabledImage = Gui.Image("LobbyUI/Friends/lb_contact_button_quit_normal.dds", Vector4(0, 0, 0, 0)),
							},
							EventClick = function()
								--MessageBox.ShowWithConfirmCancel(lang:GetText("还在制作中？"), nil)
								local LeaveGroupName = nil
								for i = 1 , L_Friends.ChatBtn_WinNumber do
									if L_Friends.ChatBTNSign == L_Friends.ChatBTNTrait[i][1] then
										LeaveGroupName = L_Friends.ChatBTNTrait[i][3]
										break
									end
								end
								L_Friends.LeaveGroupfont(LeaveGroupName)
								L_Friends.ShowLeaveGroupCreateWin(gui,LeaveGroupName)
							end
						},
					},
					
					--频道列表
					Gui.ListTreeView "Chat_Channl_List"
					{
						Size = Vector2(195, 137),
						Location = Vector2(2,30),
						Style = "Gui.ListTreeViewWith_VScroll_Channl",
						HeaderVisible = false,
						
						ItemHeight = 19,
						FontSize = 14,
						TextColor = ARGB(255, 216, 217, 208),
						VScrollBarWidth = 8,
						VScrollBarButtonSize = 1,
						HScrollBarWidth = 8,
						VScrollBarPos = Vector2(0, 0),
						
						EventDoubleClick = function(sender, e)
							local item = sender.SelectedItem
							local itemName = item:GetText(1)
							if itemName ~= "" then
								if itemName == L_LobbyMain.PersonalInfo_data.name then
									L_Friends.ShowLeaveOwnGroupCreateWin(gui,lang:GetText("您不能和自己私聊！"))
									return
								end
								for i = 1 , L_Friends.ChatBtn_WinNumber do
									if L_Friends.ChatBTNSign == L_Friends.ChatBTNTrait[i][1] then
										if L_Friends.ChatBTNTrait[i][2] == 6 then
											for _,v in ipairs(L_Friends.Team_RPC_List) do
												if itemName == v[4] then
													L_Friends.Name_Id = v[1]
													break
												end
											end
										end
									end
								end
								L_Friends.CreatePrivateChat(itemName,1)
							end
						end,
						
						--右击
						EventRightClick = function(sender, e)
							LobbyMainWin.Chat_Channl_List.PopupMenu:RemoveAll()
							LobbyMainWin.Chat_Channl_List.PopupMenu:AddItem(lang:GetText("私聊"))
							LobbyMainWin.Chat_Channl_List.PopupMenu:AddItem(lang:GetText("和TA一起玩"))
							LobbyMainWin.Chat_Channl_List.PopupMenu:AddItem(lang:GetText("加为好友"))
							LobbyMainWin.Chat_Channl_List.PopupMenu:AddItem(lang:GetText("加入黑名单"))
							LobbyMainWin.Chat_Channl_List.PopupMenu:AddItem(lang:GetText("查看信息"))
							LobbyMainWin.Chat_Channl_List.PopupMenu:AddItem(lang:GetText("我要举报"))
							LobbyMainWin.Chat_Channl_List.PopupMenu.Style = "Gui.MenuNew"
							
							LobbyMainWin.Chat_Channl_List.PopupMenu.EventClick = function(sender, e)
								local item = ptr_cast(sender.Tag)	
								local itemName = item:GetText(1)
								if sender.SelectedIndex == 0 then
									if itemName ~= "" then
										if itemName == L_LobbyMain.PersonalInfo_data.name then
											L_Friends.ShowLeaveOwnGroupCreateWin(gui,lang:GetText("您不能和自己私聊！"))
											return
										end
										for i = 1 , L_Friends.ChatBtn_WinNumber do
											if L_Friends.ChatBTNSign == L_Friends.ChatBTNTrait[i][1] then
												if L_Friends.ChatBTNTrait[i][2] == 6 then
													for _,v in ipairs(L_Friends.Team_RPC_List) do
														if itemName == v[4] then
															L_Friends.Name_Id = v[1]
															break
														end
													end
												end
											end
										end
										L_Friends.CreatePrivateChat(itemName,1)
										local l = L_Friends.Channel_list
										while l do
											if l.name == itemName then
												L_Friends.Vip = l.vip
												break
											end
											l = l.next
										end
									end
								elseif sender.SelectedIndex == 1 then
									if itemName ~= "" then
										L_LobbyMain.GotoPlayerRoom(itemName,false)
									end
								elseif sender.SelectedIndex == 2 then
									if itemName ~= "" then
										L_Friends.FriendsAdd(nil,itemName)	
									end
								elseif sender.SelectedIndex == 3 then
									if itemName ~= "" then
										L_Friends.BlackAdd(itemName)
									end
								elseif sender.SelectedIndex == 4 then
									if itemName ~= "" then
										if itemName == L_LobbyMain.PersonalInfo_data.name then
											if L_LobbyMain.LobbyMainWin_Boddy then
												L_PersonalInfo.Show(L_LobbyMain.LobbyMainWin_Boddy.LobbyMainWin_Boddy_Root)
											end
											L_LobbyMain.InitPersonalInfoRPCInfo()
											lg:SetLobbyModules(12)
											L_LobbyMain.current_chosse_main_page = 12
											L_PersonalInfo.SynchronousClassButton()
											L_LobbyMain.FillClassBag(ptr_cast(game.CurrentState):GetCharacterId(), L_LobbyMain.current_choose_class)
											return
										end
										for i = 1 , 10 do
											if L_Friends.ChatBTNSign == L_Friends.ChatInfo[i][1] then
												if L_Friends.ChatInfo[i][2] == 6 then
													for _,v in ipairs(L_Friends.Team_RPC_List) do
														if itemName == v[4] then
															L_PersonalInfo.ShowPerson(L_LobbyMain.LobbyMainWin_Boddy.LobbyMainWin_Boddy_Root,v[1],v[4])
															break
														end
													end	
													break
												elseif L_Friends.ChatInfo[i][2] == 4 then
													local l = L_Friends.Channel_list
													while l do
														if l.name == itemName then
															L_PersonalInfo.ShowPerson(L_LobbyMain.LobbyMainWin_Boddy.LobbyMainWin_Boddy_Root,l.id,l.name)
															break
														end
														l = l.next
													end	
													break
												end
											end
										end	
									end
								elseif sender.SelectedIndex == 5 then
									if itemName ~= "" then
										ShowReportWin(itemName,1)
									end
								end
							end
							local item = sender.MouseSelectedItem
							if item then
								if item:GetText(1) ~= "" and item:GetText(1) ~= L_LobbyMain.PersonalInfo_data.name then
									sender.PopupMenu:Open()
								end
							end
						end,
					},
					
					--房间列表
					Gui.ListTreeView "Chat_Room_List"
					{
						Size = Vector2(195, 137),
						Location = Vector2(2,30),
						Style = "Gui.ListTreeViewWith_VScroll_Channl",
						HeaderVisible = false,

						ItemHeight = 19,
						FontSize = 14,
						TextColor = ARGB(255, 216, 217, 208),
						VScrollBarWidth = 8,
						VScrollBarButtonSize = 1,
						HScrollBarWidth = 8,
						VScrollBarPos = Vector2(0, 0),
						
						EventDoubleClick = function(sender, e)
							local item = sender.SelectedItem
							local itemName = item:GetText(1)
							if itemName ~= "" then
								if itemName == L_LobbyMain.PersonalInfo_data.name then
									L_Friends.ShowLeaveOwnGroupCreateWin(gui,lang:GetText("您不能和自己私聊！"))
									return
								end
								L_Friends.Name_Id = 0 
								L_Friends.CreatePrivateChat(itemName,1)
							end
						end,
						
						--右击
						EventRightClick = function(sender, e)
							L_LobbyMain.LobbyMainWin.Chat_Room_List.PopupMenu:RemoveAll()
							L_LobbyMain.LobbyMainWin.Chat_Room_List.PopupMenu:AddItem(lang:GetText("私聊"))
							L_LobbyMain.LobbyMainWin.Chat_Room_List.PopupMenu:AddItem(lang:GetText("加为好友"))
							L_LobbyMain.LobbyMainWin.Chat_Room_List.PopupMenu:AddItem(lang:GetText("加入黑名单"))
							L_LobbyMain.LobbyMainWin.Chat_Room_List.PopupMenu:AddItem(lang:GetText("查看信息"))
							L_LobbyMain.LobbyMainWin.Chat_Room_List.PopupMenu:AddItem(lang:GetText("我要举报"))
							L_LobbyMain.LobbyMainWin.Chat_Room_List.PopupMenu.Style = "Gui.MenuNew"
							  
							L_LobbyMain.LobbyMainWin.Chat_Room_List.PopupMenu.EventClick = function(sender, e)
								local item = ptr_cast(sender.Tag)
								local itemName = item:GetText(1)
								if sender.SelectedIndex == 0 then
									if itemName ~= "" then
										if itemName == L_LobbyMain.PersonalInfo_data.name then
											L_Friends.ShowLeaveOwnGroupCreateWin(gui,lang:GetText("您不能和自己私聊！"))
											return
										end
										L_Friends.Name_Id = 0 
										L_Friends.CreatePrivateChat(itemName,1)
										local l = L_Friends.room_list
										while l do
											if l.name == itemName then
												L_Friends.Vip = l.vip
												break
											end
											l = l.next
										end
									end
								elseif sender.SelectedIndex == 1 then
									if itemName ~= "" then
										L_Friends.FriendsAdd(nil,itemName)	
									end
								elseif sender.SelectedIndex == 2 then
									if itemName ~= "" then
										L_Friends.BlackAdd(itemName)
									end
								elseif sender.SelectedIndex == 3 then
									if itemName ~= "" then
										if itemName == L_LobbyMain.PersonalInfo_data.name then
						--					L_LobbyMain.HideAll()
											if L_LobbyMain.LobbyMainWin_Boddy then
												L_PersonalInfo.Show(L_LobbyMain.LobbyMainWin_Boddy.LobbyMainWin_Boddy_Root)
											end
											L_LobbyMain.InitPersonalInfoRPCInfo()
											lg:SetLobbyModules(12)
											L_LobbyMain.current_chosse_main_page = 12
											L_PersonalInfo.SynchronousClassButton()
											L_LobbyMain.FillClassBag(ptr_cast(game.CurrentState):GetCharacterId(), L_LobbyMain.current_choose_class)
											return
										end
										local l = L_Friends.room_list
										while l do
											if l.name == itemName then
												L_PersonalInfo.ShowPerson(L_LobbyMain.LobbyMainWin_Boddy.LobbyMainWin_Boddy_Root,l.id,l.name)
												break
											end
											l = l.next
										end			
									end
								elseif  sender.SelectedIndex == 4 then
									if itemName ~= "" then
										ShowReportWin(itemName,1)
									end
								end
							end
							local item = sender.MouseSelectedItem
							if item then
								if item:GetText(1) ~= "" and item:GetText(1) ~= L_LobbyMain.PersonalInfo_data.name then
									sender.PopupMenu:Open()
								end
							end
						end,
					},
					
					--群组列表
					Gui.ListTreeView "Chat_Group_List"
					{
						Size = Vector2(195, 137),
						Location = Vector2(2,30),
						Style = "Gui.ListTreeViewWith_VScroll_Channl",
						HeaderVisible = false,

						ItemHeight = 19,
						FontSize = 14,
						TextColor = ARGB(255, 216, 217, 208),
						VScrollBarWidth = 8,
						VScrollBarButtonSize = 1,
						HScrollBarWidth = 8,
						VScrollBarPos = Vector2(0, 0),
						
						EventDoubleClick = function(sender, e)
							local item = sender.SelectedItem
							local itemName = item:GetText(1)
							if itemName ~= "" then
								if itemName == L_LobbyMain.PersonalInfo_data.name then
									L_Friends.ShowLeaveOwnGroupCreateWin(gui,lang:GetText("您不能和自己私聊！"))
									return
								end
								for i = 1 , L_Friends.ChatBtn_WinNumber do
									if L_Friends.ChatBTNSign == L_Friends.ChatBTNTrait[i][1] then
										if L_Friends.ChatBTNTrait[i][2] == 3 then
											if L_LobbyMain.MyGroup_rpc_data and L_LobbyMain.MyGroup_rpc_data[1] and L_Friends.ChatBTNTrait[i][3] == L_LobbyMain.MyGroup_rpc_data[1][5] then
												for _,v in ipairs(L_LobbyMain.MyGroup_rpc_data) do
													if v[3] == itemName then													
														L_Friends.Name_Id = v[1]
														break
													end
												end
											else
												for _,v in ipairs(L_LobbyMain.AddGroup_rpc_data) do
													if v[1][5] == L_Friends.ChatBTNTrait[i][3] then
														for _,y in ipairs(v) do
															if y[3] == itemName then													
																L_Friends.Name_Id = y[1]
																break
															end
														end
													end
												end
											end
										elseif L_Friends.ChatBTNTrait[i][2] == 2 then
											local l = L_Friends.TepGroup_Member
											while l do
												if l.group_id == L_Friends.ChatInfo[i][7] then
													for j = 1 , 5 do
														if l.member[j] == itemName then
															L_Friends.Name_Id = l.member_id[j]
															break
														end
													end
												end
												l = l.next
											end
										end
										break
									end
								end
								L_Friends.CreatePrivateChat(itemName,1)
							end
						end,
						
						--右击
						EventRightClick = function(sender, e)
							local Tepnum = 0
							for i = 1 , L_Friends.ChatBtn_WinNumber do
								if L_Friends.ChatBTNSign == L_Friends.ChatBTNTrait[i][1] then
									Tepnum = i
									break
								end
							end
							if Tepnum == 0 then
								return
							end
							L_LobbyMain.LobbyMainWin.Chat_Group_List.PopupMenu:RemoveAll()
							L_LobbyMain.LobbyMainWin.Chat_Group_List.PopupMenu:AddItem(lang:GetText("私聊"))
							L_LobbyMain.LobbyMainWin.Chat_Group_List.PopupMenu:AddItem(lang:GetText("和TA一起玩"))
							L_LobbyMain.LobbyMainWin.Chat_Group_List.PopupMenu:AddItem(lang:GetText("加为好友"))
							L_LobbyMain.LobbyMainWin.Chat_Group_List.PopupMenu:AddItem(lang:GetText("加入黑名单"))
							L_LobbyMain.LobbyMainWin.Chat_Group_List.PopupMenu:AddItem(lang:GetText("查看信息"))
							if L_Friends.ChatBTNTrait[Tepnum][2] == 3 and L_LobbyMain.MyGroup_rpc_data and L_LobbyMain.MyGroup_rpc_data[1] and L_Friends.ChatBTNTrait[Tepnum][3] == L_LobbyMain.MyGroup_rpc_data[1][5] then
								L_LobbyMain.LobbyMainWin.Chat_Group_List.PopupMenu:AddItem(lang:GetText("踢出群组"))
							end
							L_LobbyMain.LobbyMainWin.Chat_Group_List.PopupMenu:AddItem(lang:GetText("我要举报"))
							L_LobbyMain.LobbyMainWin.Chat_Group_List.PopupMenu.Style = "Gui.MenuNew"
							  
							L_LobbyMain.LobbyMainWin.Chat_Group_List.PopupMenu.EventClick = function(sender, e)
								local item = ptr_cast(sender.Tag)	
								local itemName = item:GetText(1)
								if sender.SelectedIndex == 0 then
									if itemName ~= "" then
										if itemName == L_LobbyMain.PersonalInfo_data.name then
											L_Friends.ShowLeaveOwnGroupCreateWin(gui,lang:GetText("您不能和自己私聊！"))
											return
										end
										for i = 1 , L_Friends.ChatBtn_WinNumber do
											if L_Friends.ChatBTNSign == L_Friends.ChatBTNTrait[i][1] then
												if L_Friends.ChatBTNTrait[i][2] == 3 then
													if L_LobbyMain.MyGroup_rpc_data and L_LobbyMain.MyGroup_rpc_data[1] and L_Friends.ChatBTNTrait[i][3] == L_LobbyMain.MyGroup_rpc_data[1][5] then
														for _,v in ipairs(L_LobbyMain.MyGroup_rpc_data) do
															if v[3] == itemName then													
																L_Friends.Name_Id = v[1]
																break
															end
														end
													else
														for _,v in ipairs(L_LobbyMain.AddGroup_rpc_data) do
															if v[1][5] == L_Friends.ChatBTNTrait[i][3] then
																for _,y in ipairs(v) do
																	if y[3] == itemName then													
																		L_Friends.Name_Id = y[1]
																		break
																	end
																end
															end
														end
													end
												elseif L_Friends.ChatBTNTrait[i][2] == 2 then
													local l = L_Friends.TepGroup_Member
													while l do
														if l.group_id == L_Friends.ChatInfo[i][7] then
															for j = 1 , 5 do
																if l.member[j] == itemName then
																	L_Friends.Name_Id = l.member_id[j]
																	break
																end
															end
														end
														l = l.next
													end
												end
												break
											end
										end
										L_Friends.CreatePrivateChat(itemName,1)
									end
								elseif sender.SelectedIndex == 1 then
									if itemName ~= "" then
										L_LobbyMain.GotoPlayerRoom(itemName,false)
									end
								elseif sender.SelectedIndex == 2 then
									if itemName ~= "" then
										L_Friends.FriendsAdd(nil,itemName)	
									end
								elseif sender.SelectedIndex == 3 then
									if itemName ~= "" then
										L_Friends.BlackAdd(itemName)
									end
								elseif sender.SelectedIndex == 4 then
									if itemName ~= "" then
										if itemName == L_LobbyMain.PersonalInfo_data.name then
											if L_LobbyMain.LobbyMainWin_Boddy then
												L_PersonalInfo.Show(L_LobbyMain.LobbyMainWin_Boddy.LobbyMainWin_Boddy_Root)
											end
											L_LobbyMain.InitPersonalInfoRPCInfo()
											lg:SetLobbyModules(12)
											L_LobbyMain.current_chosse_main_page = 12
											L_PersonalInfo.SynchronousClassButton()
											L_LobbyMain.FillClassBag(ptr_cast(game.CurrentState):GetCharacterId(), L_LobbyMain.current_choose_class)
											return
										end
										for i = 1 , 10 do
											if L_Friends.ChatBTNSign == L_Friends.ChatInfo[i][1] then
												if L_Friends.ChatInfo[i][2] == 2 then
													local l = L_Friends.TepGroup_Member
													while l do
														if l.group_id == L_Friends.ChatInfo[i][7] then
															for j = 1 , 5 do
																if l.member[j] == itemName then
																	L_PersonalInfo.ShowPerson(L_LobbyMain.LobbyMainWin_Boddy.LobbyMainWin_Boddy_Root,l.member_id[j],l.member[j])
																	return
																end
															end
														end
														l = l.next
													end
												elseif L_Friends.ChatInfo[i][2] == 3 then
													if L_LobbyMain.MyGroup_rpc_data[1] and L_LobbyMain.MyGroup_rpc_data[1][5] == L_Friends.ChatInfo[i][3] then
														L_Friends.ShowPerson(L_LobbyMain.MyGroup_rpc_data,itemName)	
														return
													end
													for _,v in ipairs(L_LobbyMain.AddGroup_rpc_data) do 
														if v[1][5] == L_Friends.ChatInfo[i][3] then
															L_Friends.ShowPerson(v,itemName)	
															return
														end
													end
												end
												break
											end
										end	
									end
								else
									if L_Friends.ChatBTNTrait[Tepnum][2] == 3 and L_LobbyMain.MyGroup_rpc_data and L_LobbyMain.MyGroup_rpc_data[1] and L_Friends.ChatBTNTrait[Tepnum][3] == L_LobbyMain.MyGroup_rpc_data[1][5] then
										if sender.SelectedIndex == 5 then
											if itemName ~= "" then
												KickingGroupMemberName = itemName			
												if KickingGroupMemberName == PersonalInfo_data.name then
													L_Friends.ShowLeaveOwnGroupCreateWin(gui,lang:GetText("您不能把自己踢出自己的群！"))
												elseif KickingGroupMemberName ~= nil then
													L_Friends.ShowKickingGroupCreateWin(gui)
												end
											end
										elseif  sender.SelectedIndex == 6 then
											if itemName ~= "" then
												ShowReportWin(itemName,1)
											end
										end
									else
										if  sender.SelectedIndex == 5 then
											if itemName ~= "" then
												ShowReportWin(itemName,1)
											end
										end
									end
								end
							end
							local item = sender.MouseSelectedItem
							if item then
								if item:GetText(1) ~= "" and item:GetText(1) ~= L_LobbyMain.PersonalInfo_data.name then
									sender.PopupMenu:Open()
								end
							end
						end,
					},										
				},
					
				Gui.TextArea "tarea_Chat_Group"
				{
					Style = "Gui.TextAreaWithVBar",
					Size = Vector2(183, 174),
					FontSize = 14,
					Location = Vector2(197, 5),
					TextColor = ARGB(255, 0, 0, 0),
					HighlightTextColor = ARGB(255, 0, 0, 0),
					Readonly = true,
					Fold = true,
					VScrollBarWidth = 8,
					VScrollBarButtonSize = 1,
					VScrollBarPos = Vector2(0, 0),
					Padding = Vector4(5, 5, 5, 5),
				
					EventTextChanged = function()
						L_LobbyMain.LobbyMainWin.tarea_Chat_Group:ScrollToEnd()
					end
				},
			},
			
			Gui.Control"ctr_Group_write"
			{
				Size = Vector2(381, 27),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Location = Vector2(12, 220),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_bg3_normal.dds", Vector4(8, 8, 8, 8)),
				},
			},
		},

		Gui.Control "ctr_Group_Team_Win"
		{
			-- Size = Vector2(408, 260),--329 260
			Size = Vector2(373, 272),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Location = Vector2(200, 0),
			Visible = false,
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_bg1.dds", Vector4(28, 28, 28, 28)),
			},
			
			Gui.Label "lb_Team_Name"
			{
				Location = Vector2(18, 12),
				Size = Vector2(240, 19),
				FontSize = 14,
				TextAlign = "kAlignLeftMiddle",
				TextColor = ARGB(255, 37, 37, 37),
				HighlightTextColor = ARGB(255, 37, 37, 37),
				Text = ""
			},
			
			--退出
			Gui.Button "b_close"
			{
				Size = Vector2(20,20),
				Location = Vector2(344, 11),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_buttonX_normal.dds", Vector4(0, 0, 0, 0)),
					HoverImage = Gui.Image("LobbyUI/Friends/lb_contact_buttonX_hover.dds", Vector4(0, 0, 0, 0)),
					DownImage = Gui.Image("LobbyUI/Friends/lb_contact_buttonX_down.dds", Vector4(0, 0, 0, 0)),
					DisabledImage = Gui.Image("LobbyUI/Friends/lb_contact_buttonX_normal.dds", Vector4(0, 0, 0, 0)),
				},
				EventClick = function()
					L_LobbyMain.LobbyMainWin.ctr_Group_Team_Win.Visible = false
				end
			},
			
			Gui.Control
			{
				Size = Vector2(352, 184),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Location = Vector2(9, 33),
				
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Friends/lb_chat_bg2.dds", Vector4(23, 23, 23, 23)),
				},

				-- Gui.Control
				-- {
					-- Size = Vector2(200, 174),--107  174
					-- BackgroundColor = ARGB(255, 255, 255, 255),
					-- Location = Vector2(4, 5),
					
					-- Skin = Gui.ControlSkin
					-- {
						-- BackgroundImage = Gui.Image("LobbyUI/Friends/lb_chat_bg3.dds", Vector4(13, 13, 13, 13)),
					-- },
					
					-- Gui.Label"lb_List_Team_Name"
					-- {
						-- Size = Vector2(194, 28),
						-- BackgroundColor = ARGB(255, 255, 255, 255),
						-- Location = Vector2(3, 2),
						-- FontSize = 14,
						-- Text = "",
						-- TextAlign = "kAlignCenterMiddle",
						-- TextColor = ARGB(255, 37, 37, 37),
						-- TextPadding = Vector4(0, 0, 0, 5),
						
						-- Skin = Gui.ControlSkin
						-- {
							-- BackgroundImage = Gui.Image("LobbyUI/Friends/lb_chat_bg5.dds", Vector4(3, 3, 3, 8)),
						-- },
						
						-- Gui.Control "ctr_list_Team_type"
						-- {	
							-- Size = Vector2(34, 22),
							-- BackgroundColor = ARGB(255, 255, 255, 255),
							-- Location = Vector2(8, 2),							
						-- },
					-- },
					
					-- -- 群组列表
					-- Gui.ListTreeView "Chat_Team_List"
					-- {
						-- Size = Vector2(195, 137),
						-- Location = Vector2(2,30),
						-- Style = "Gui.ListTreeViewWith_VScroll_Channl",
						-- HeaderVisible = false,

						-- ItemHeight = 19,
						-- FontSize = 14,
						-- TextColor = ARGB(255, 216, 217, 208),
						-- VScrollBarWidth = 8,
						-- VScrollBarButtonSize = 1,
						-- HScrollBarWidth = 8,
						-- VScrollBarPos = Vector2(0, 0),
					-- },										
				-- },
					
				Gui.TextArea "tarea_Chat_Team"
				{
					Style = "Gui.TextAreaWithVBar",
					Size = Vector2(345, 174),
					FontSize = 14,
					Location = Vector2(0, 5),
					TextColor = ARGB(255, 0, 0, 0),
					HighlightTextColor = ARGB(255, 0, 0, 0),
					Readonly = true,
					Fold = true,
					VScrollBarWidth = 8,
					VScrollBarButtonSize = 1,
					VScrollBarPos = Vector2(0, 0),
					Padding = Vector4(5, 5, 5, 5),
				
					EventTextChanged = function()
						L_LobbyMain.LobbyMainWin.tarea_Chat_Team:ScrollToEnd()
					end
				},
			},
			
			Gui.Control"ctr_Team_write"
			{
				Size = Vector2(346, 27),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Location = Vector2(12, 220),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_bg3_normal.dds", Vector4(8, 8, 8, 8)),
				},
			},
		},
		
		--好友父窗口
		Gui.Control "ctr_FriendsWin_root_Parent"
		{
			Size = Vector2(297, 357), --226   357
			BackgroundColor = ARGB(255, 255, 255, 255),
			Location = Vector2(228, 465),
			Visible = false,
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_bg1.dds", Vector4(28, 28, 28, 28)),
			},
			
			Gui.DragLabel
			{
				Size = Vector2(297, 357),
				Text = "",
				BackgroundColor = ARGB(0, 255, 255, 255),
				Iimit = Vector4(30,0,1345,465),
			},
			
			Gui.Control "ctr_ctr_FriendsWin_root"
			{
				Size = Vector2(285, 311),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Location = Vector2(7, 37),				
			},
				
			--通讯录
			Gui.Button "btn_Friend"
			{
				Size = Vector2(84, 28),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Location = Vector2(19, 13),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_tab1_ico02_normal.dds", Vector4(10, 0, 10, 0)),
					HoverImage = Gui.Image("LobbyUI/Friends/lb_contact_tab1_ico02_hover.dds", Vector4(10, 0, 10, 0)),
					DownImage = Gui.Image("LobbyUI/Friends/lb_contact_tab1_ico02_down.dds", Vector4(10, 0, 10, 0)),
					DisabledImage = Gui.Image("LobbyUI/Friends/lb_contact_tab1_ico02_normal.dds", Vector4(10, 0, 10, 0)),
				},

				EventClick = function()
					L_Friends.current_selected = 0
					L_Friends.ShowCreateFriends(L_LobbyMain.LobbyMainWin.ctr_ctr_FriendsWin_root,L_Friends.current_selected)
					L_LobbyMain.FriendsUpdate()
				end,
			},
			
			--群组
			Gui.Button "btn_Friends"
			{
				Size = Vector2(84, 28),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Location = Vector2(104, 13),				
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_tab1_ico01_normal.dds", Vector4(10, 0, 10, 0)),
					HoverImage = Gui.Image("LobbyUI/Friends/lb_contact_tab1_ico01_hover.dds", Vector4(10, 0, 10, 0)),
					DownImage = Gui.Image("LobbyUI/Friends/lb_contact_tab1_ico01_down.dds", Vector4(10, 0, 10, 0)),
					DisabledImage = Gui.Image("LobbyUI/Friends/lb_contact_tab1_ico01_normal.dds", Vector4(10, 0, 10, 0)),
				},

				EventClick = function()
					L_Friends.current_selected = 1
					L_Friends.ShowCreateFriends(L_LobbyMain.LobbyMainWin.ctr_ctr_FriendsWin_root,L_Friends.current_selected)
				end,								
			},
				
			
			--退出
			Gui.Button "btn_FriendsExit"
			{
				Size = Vector2(20,20),
				Location = Vector2(265, 9),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_buttonX_normal.dds", Vector4(0, 0, 0, 0)),
					HoverImage = Gui.Image("LobbyUI/Friends/lb_contact_buttonX_hover.dds", Vector4(0, 0, 0, 0)),
					DownImage = Gui.Image("LobbyUI/Friends/lb_contact_buttonX_down.dds", Vector4(0, 0, 0, 0)),
					DisabledImage = Gui.Image("LobbyUI/Friends/lb_contact_buttonX_normal.dds", Vector4(0, 0, 0, 0)),
				},
				EventClick = function()
					L_Friends.Hide()
				end,
			},
		},
		
		Gui.Control "youjian"
		{
			Location = Vector2(349, 817),
			Size = Vector2(28, 28),
			BackgroundColor = ARGB(255,255,255,255),
			-- Visible = false,
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/xin/lb_menu_tip.dds", Vector4(0, 0, 0, 0)),
			},
			Gui.Label"youjian_mun"
			{
				Location = Vector2(2, 0),
				Size = Vector2(24, 24),
				FontSize = 18,
				TextAlign = "kAlignCenterMiddle",
				TextColor = ARGB(255, 255, 255, 255),
				Text = "",
				BackgroundColor = ARGB(0, 255, 255, 255),
			},
		},
	
		Gui.Label "tips"
		{
			
			Size = Vector2(184,67),
			Location = Vector2(200, 758),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Visible = false,
			TextAlign = "kAlignCenterMiddle",
			UseTimer = true,
			Enable = false,
			FontSize = 16,
			MoveLocation = Vector2(0,5),
			MoveWheelTime = 0.6,
			TextColor = ARGB(255, 37, 37, 37),
			TextPadding = Vector4(0, 0, 0, 0),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/mail/lb_mail_newmail_bg.dds", Vector4(0, 0, 0, 0)),
			},
		},
		Gui.Label "new"
		{			
			Size = Vector2(44,40),
			--Location = Vector2(200, 758),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Visible = false,
			UseTimer = false,
			Enable = false,
			MoveLocation = Vector2(0,5),
			MoveWheelTime = 0.6,
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_shop_new_flash.dds", Vector4(0, 0, 0, 0)),
			},
			EventClose = function()
				L_LobbyMain.LobbyMainWin.new.UseTimer = false
			end,
		},
	
		Gui.Label "new1"
		{			
			Size = Vector2(44,40),
			--Location = Vector2(200, 758),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Visible = false,
			UseTimer = false,
			Enable = false,
			MoveLocation = Vector2(0,5),
			MoveWheelTime = 0.6,
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_shop_new_flash.dds", Vector4(0, 0, 0, 0)),
			},
			EventClose = function()
				L_LobbyMain.LobbyMainWin.new1.UseTimer = false
			end,
		},

		Gui.Label "new_jiaose"
		{			
			Size = Vector2(44,40),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Visible = false,
			UseTimer = false,
			Enable = false,
			MoveLocation = Vector2(0,5),
			MoveWheelTime = 0.6,
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_shop_new_flash.dds", Vector4(0, 0, 0, 0)),
			},
			EventClose = function()
				L_LobbyMain.LobbyMainWin.new_jiaose.UseTimer = false
			end,
		},
	
		Gui.Label "new_daoju"
		{			
			Size = Vector2(44,40),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Visible = false,
			UseTimer = false,
			Enable = false,
			MoveLocation = Vector2(0,5),
			MoveWheelTime = 0.6,
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_shop_new_flash.dds", Vector4(0, 0, 0, 0)),
			},
			EventClose = function()
				L_LobbyMain.LobbyMainWin.new_daoju.UseTimer = false
			end,
		},
		
		Gui.Label "new_daoju_dj"
		{			
			Size = Vector2(35,32),
			--Location = Vector2(200, 758),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Visible = false,
			UseTimer = false,
			Enable = false,
			MoveLocation = Vector2(0,5),
			MoveWheelTime = 0.6,
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_shop_new_flash.dds", Vector4(0, 0, 0, 0)),
			},
			EventClose = function()
				L_LobbyMain.LobbyMainWin.new_daoju.UseTimer = false
			end,
		},
		
		Gui.Label "new_daoju_sc"
		{			
			Size = Vector2(35,32),
			--Location = Vector2(200, 758),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Visible = false,
			UseTimer = false,
			Enable = false,
			MoveLocation = Vector2(0,5),
			MoveWheelTime = 0.6,
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_shop_new_flash.dds", Vector4(0, 0, 0, 0)),
			},
			EventClose = function()
				L_LobbyMain.LobbyMainWin.new_daoju.UseTimer = false
			end,
		},
		
		Gui.Label "new_daoju_kjx"
		{			
			Size = Vector2(35,32),
			--Location = Vector2(200, 758),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Visible = false,
			UseTimer = false,
			Enable = false,
			MoveLocation = Vector2(0,5),
			MoveWheelTime = 0.6,
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_shop_new_flash.dds", Vector4(0, 0, 0, 0)),
			},
			EventClose = function()
				L_LobbyMain.LobbyMainWin.new_daoju.UseTimer = false
			end,
		},
		
		Gui.Label "new_daoju_jiacheng"
		{			
			Size = Vector2(35,32),
			--Location = Vector2(200, 758),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Visible = false,
			UseTimer = false,
			Enable = false,
			MoveLocation = Vector2(0,5),
			MoveWheelTime = 0.6,
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_shop_new_flash.dds", Vector4(0, 0, 0, 0)),
			},
			EventClose = function()
				L_LobbyMain.LobbyMainWin.new_daoju.UseTimer = false
			end,
		},
		
		Gui.Label "new_daoju_lantu"
		{			
			Size = Vector2(35,32),
			--Location = Vector2(200, 758),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Visible = false,
			UseTimer = false,
			Enable = false,
			MoveLocation = Vector2(0,5),
			MoveWheelTime = 0.6,
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_shop_new_flash.dds", Vector4(0, 0, 0, 0)),
			},
			EventClose = function()
				L_LobbyMain.LobbyMainWin.new_daoju.UseTimer = false
			end,
		},
		
		Gui.Label "new_daoju_mingpian"
		{			
			Size = Vector2(35,32),
			--Location = Vector2(200, 758),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Visible = false,
			UseTimer = false,
			Enable = false,
			MoveLocation = Vector2(0,5),
			MoveWheelTime = 0.6,
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_shop_new_flash.dds", Vector4(0, 0, 0, 0)),
			},
			EventClose = function()
				L_LobbyMain.LobbyMainWin.new_daoju.UseTimer = false
			end,
		},
		
		Gui.Label "new_daoju_libao"
		{			
			Size = Vector2(35,32),
			--Location = Vector2(200, 758),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Visible = false,
			UseTimer = false,
			Enable = false,
			MoveLocation = Vector2(0,5),
			MoveWheelTime = 0.6,
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_shop_new_flash.dds", Vector4(0, 0, 0, 0)),
			},
			EventClose = function()
				L_LobbyMain.LobbyMainWin.new_daoju.UseTimer = false
			end,
		},
		
		--VIP
		Gui.Control "ctr_VIP"
		{
			Location = Vector2(401, 102),
			Size = Vector2(142, 77),
			BackgroundColor = ARGB(255,255,255,255),
			Visible = false,
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_bg_01.dds", Vector4(0, 0, 0, 0)),
			},
		},
		
		Gui.Button "ctr_VIP_num"
		{
			Location = Vector2(445, 132),
			Size = Vector2(50, 29),
			BackgroundColor = ARGB(255,255,255,255),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_button_01_normal.dds", Vector4(0, 0, 0, 0)),
				HoverImage = Gui.Image("LobbyUI/vip/vip/VIP_button_01_hover.dds", Vector4(0, 0, 0, 0)),
				DownImage = Gui.Image("LobbyUI/vip/vip/VIP_button_01_down.dds", Vector4(0, 0, 0, 0)),
				DisabledImage = Gui.Image("LobbyUI/vip/vip/VIP_button_01_disabled.dds", Vector4(0, 0, 0, 0)),
			},
			EventClick = function()
				L_Vip.Show_VipShow()
			end,
			EventMouseEnter = function()
				LobbyMainWin.ctr_VIP.Visible = true
				LobbyMainWin.vip_tips.Visible = true
			end,
			EventMouseLeave = function()
				LobbyMainWin.ctr_VIP.Visible = false
				LobbyMainWin.vip_tips.Visible = false
			end,
		},
	
		Gui.Control "LobbyMainWin_Header_Team"
		{
			Size = Vector2(1200, 258),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Location = Vector2(200, 0),
			Visible = false,
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_bg_01.dds",Vector4(0, 0, 0, 0)),
			},
			Gui.Control
			{
				Size = Vector2(1093, 180),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Location = Vector2(57, 31),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_bg.dds",Vector4(282, 156, 41, 6)),
				},
				Gui.Control "con_3"
				{
					Size = Vector2(858, 25),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Location = Vector2(17, 7),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/lb_com_bg.dds",Vector4(45,0,20,0)),
					},
				},
				
				Gui.Control
				{
					Size = Vector2(134, 93),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Location = Vector2(18, 40),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_bg_02.dds",Vector4(10, 10, 2, 2)),
					},
					Gui.Control "c_touxiang"
					{
						Size = Vector2(84, 84),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Location = Vector2(6, 5),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/team/FightHead/lb_squad_touxiang_1.dds",Vector4(0, 0, 0, 0)),
						},
					},
					Gui.Button "change_teaminfo"
					{
						Location = Vector2(99, 7),
						Size = Vector2(28, 80),
						BackgroundColor = ARGB(255,255,255,255),
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_button10_normal.dds", Vector4(0, 0, 0, 0)),
							HoverImage = Gui.Image("LobbyUI/team/lb_squad_button10_hover.dds", Vector4(0, 0, 0, 0)),
							DownImage = Gui.Image("LobbyUI/team/lb_squad_button10_down.dds", Vector4(0, 0, 0, 0)),
							DisabledImage = Gui.Image("LobbyUI/team/lb_squad_button10_disabled.dds", Vector4(0, 0, 0, 0)),
						},
						EventClick = function(sender, e)
							if L_FightTeam.p_job ~= 4 then
								MessageBox.ShowWithConfirm(lang:GetText("只有队长有权限修改战队信息"), nil)
								return
							end
							L_FightTeam.register_team_ui = ModalWindow.GetNew()
							L_FightTeam.register_team_ui.root.Size = Vector2(605, 676)
							L_FightTeam.register_team_ui.AllowEscToExit = false
							L_FightTeam.register_team.root.Parent = L_FightTeam.register_team_ui.root
							L_FightTeam.register_team.team_name.Text = ""
							L_FightTeam.register_team.description.Text = ""
							L_FightTeam.register_team.b_create.Text = lang:GetText("完成")
							L_FightTeam.team_create_data.playerItemId = 0
							if L_FightTeam.team_data then
								L_FightTeam.selsect_image_id = L_FightTeam.team_data[3]
								L_FightTeam.image_id = L_FightTeam.team_data[3]
								local col
								if L_FightTeam.selsect_image_id % 4 == 0 then
									col = 4
								else
									col = L_FightTeam.selsect_image_id % 4
								end
								local row = (L_FightTeam.selsect_image_id - col) / 4 + 1
								local pic = L_FightTeam.Image_team.ib_image:GetDisplayPicture(row, col)
								pic.Highlighted = true
								L_FightTeam.register_team.zhandui_touxiang.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/team/FightHead/lb_squad_touxiang_"..L_FightTeam.team_data[3]..".dds",Vector4(0,0,0,0)),}
							end
							local cbx = L_FightTeam.register_team.rank
							cbx:RemoveAll()
							for i = 1, 50  do 
								cbx:AddItem( i )
							end
							L_FightTeam.register_team.team_name.Enable = false
							L_FightTeam.register_team.team_name.Skin = Gui.TextboxSkin{BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_contact_bg_disabled.dds", Vector4(10, 10, 10, 10)),}
							L_FightTeam.register_team.province.Enable = false
							L_FightTeam.register_team.city.Enable = false
							L_FightTeam.register_team.abcd.Visible = false
							-- register_team.geshu.Visible = false
							L_FightTeam.register_team.province.Text = L_FightTeam.team_data[15]--L_FightTeam.my_battle_province
							L_FightTeam.register_team.city.Text = L_FightTeam.team_data[16]--L_FightTeam.my_battle_city
							L_FightTeam.register_team.team_name.Text = L_FightTeam.team_data[2]--L_FightTeam.my_battle_name
							L_FightTeam.register_team.description.Text = L_FightTeam.team_data[4]--L_FightTeam.team_description
							L_FightTeam.register_team.rank.Text = L_FightTeam.team_data[17]--L_FightTeam.t_rank
							-- register_team.rank.Text = 1
							Gui.Align(L_FightTeam.register_team.register, 0.5, 0.5)
						end,
					},
				},
				
				Gui.Control
				{
					Size = Vector2(68,18),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Location = Vector2(21, 140),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_icon_lv.dds",Vector4(0, 0, 0, 0)),
					},
				},
				Gui.FlowLayout "TeamLv_layout"
				{
					Location = Vector2(99,140),
					Size = Vector2(32,19),
					Direction = "kHorizontal",
					Align = "kAlignRightMiddle",
					ControlAlign = "kAlignCenterMiddle",
					ControlSpace = 0,
				},
				Gui.Control
				{
					Size = Vector2(317, 17),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Location = Vector2(172, 44),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_bg_03.dds",Vector4(95, 0, 10, 0)),
					},
				},		
				Gui.Control
				{
					Size = Vector2(317, 17),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Location = Vector2(172, 69),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_bg_03.dds",Vector4(95, 0, 10, 0)),
					},
				},
				Gui.Control
				{
					Size = Vector2(317, 17),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Location = Vector2(172, 94),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_bg_03.dds",Vector4(95, 0, 10, 0)),
					},
				},
				Gui.Control
				{
					Size = Vector2(317, 17),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Location = Vector2(172, 119),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_bg_03.dds",Vector4(95, 0, 10, 0)),
					},
				},
				Gui.Control "con_4"
				{
					Size = Vector2(317, 17),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Location = Vector2(172, 144),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_bg_03.dds",Vector4(95, 0, 10, 0)),
					},
				},
				
				Gui.Control
				{
					Size = Vector2(72, 24),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Location = Vector2(186, 42),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_zdl.dds",Vector4(0, 0, 0, 0)),
					},
				},
				Gui.Control
				{
					Size = Vector2(72, 24),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Location = Vector2(186, 67),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_zdm.dds",Vector4(0, 0, 0, 0)),
					},
				},
				Gui.Control
				{
					Size = Vector2(72, 24),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Location = Vector2(186, 92),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_duizhang.dds",Vector4(0, 0, 0, 0)),
					},
				},
				Gui.Control
				{
					Size = Vector2(72, 24),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Location = Vector2(186, 117),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_zdzpm.dds",Vector4(0, 0, 0, 0)),
					},
				},
				Gui.Control "con_1"
				{
					Size = Vector2(72, 24),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Location = Vector2(186, 142),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_zypm.dds",Vector4(0, 0, 0, 0)),
					},
				},
				Gui.Label
				{
					Location = Vector2(216, 42),
					Size = Vector2(76, 16),
					FontSize = 14,
					TextAlign = "kAlignLeftTop",
					TextColor = ARGB(255, 255, 210, 0),
					Text = lang:GetText("战队战斗力"),
					BackgroundColor = ARGB(0, 255, 255, 255),
				},
				Gui.Label
				{
					Location = Vector2(216, 67),
					Size = Vector2(76, 16),
					FontSize = 14,
					TextAlign = "kAlignLeftTop",
					TextColor = ARGB(255, 255, 210, 0),
					Text = lang:GetText("战队"),
					BackgroundColor = ARGB(0, 255, 255, 255),
				},
				Gui.Label
				{
					Location = Vector2(216, 92),
					Size = Vector2(76, 16),
					FontSize = 14,
					TextAlign = "kAlignLeftTop",
					TextColor = ARGB(255, 255, 210, 0),
					Text = lang:GetText("队长"),
					BackgroundColor = ARGB(0, 255, 255, 255),
				},
				Gui.Label
				{
					Location = Vector2(216, 117),
					Size = Vector2(76, 16),
					FontSize = 14,
					TextAlign = "kAlignLeftTop",
					TextColor = ARGB(255, 255, 210, 0),
					Text = lang:GetText("战队排名"),
					BackgroundColor = ARGB(0, 255, 255, 255),
				},
				Gui.Label "con_2"
				{
					Location = Vector2(216, 142),
					Size = Vector2(76, 16),
					FontSize = 14,
					TextAlign = "kAlignLeftTop",
					TextColor = ARGB(255, 255, 210, 0),
					Text = lang:GetText("资源战排名"),
					BackgroundColor = ARGB(0, 255, 255, 255),
				},
				Gui.FlowLayout "FightNum_layout"
				{
					Location = Vector2(310,39),
					Size = Vector2(180,15),
					Direction = "kHorizontal",
					Align = "kAlignRightMiddle",
					ControlAlign = "kAlignCenterMiddle",
					ControlSpace = 0,
				},
				Gui.Label "team_name"
				{
					Location = Vector2(172, 62),
					Size = Vector2(317, 20),
					FontSize = 16,
					TextAlign = "kAlignRightTop",
					TextColor = ARGB(255, 255, 255, 255),
				},
				Gui.Label "team_lead"
				{
					Location = Vector2(172, 84),
					Size = Vector2(317, 20),
					FontSize = 16,
					TextAlign = "kAlignRightTop",
					TextColor = ARGB(255, 255, 255, 255),
				},
				Gui.FlowLayout "FightTop_layout"
				{
					Location = Vector2(310,112),
					Size = Vector2(180,15),
					Direction = "kHorizontal",
					Align = "kAlignRightMiddle",
					ControlAlign = "kAlignCenterMiddle",
					ControlSpace = 0,
				},	
				Gui.FlowLayout "SourceTop_layout"
				{
					Location = Vector2(310,138),
					Size = Vector2(180,15),
					Direction = "kHorizontal",
					Align = "kAlignRightMiddle",
					ControlAlign = "kAlignCenterMiddle",
					ControlSpace = 0,
				},	

				
				Gui.Control "zhandui_source"
				{
					Size = Vector2(544, 125),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Location = Vector2(527, 37),
					Visible = true,
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_bg_02.dds",Vector4(10, 10, 2, 2)),
					},
					Gui.Control
					{
						Size = Vector2(269, 29),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Location = Vector2(5, 6),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/team/lb_yaoqing_bg.dds",Vector4(0, 0, 0, 0)),
						},
						Gui.Control
						{
							Size = Vector2(68, 17),
							Location = Vector2(12, 7),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Skin = Skin.priceLevelIcon,
						},
						Gui.FlowLayout "Zhandui_SourceLv_layout"
						{
							Location = Vector2(110,5),
							Size = Vector2(60,20),
							Direction = "kHorizontal",
							Align = "kAlignLeftMiddle",
							ControlAlign = "kAlignCenterMiddle",
							ControlSpace = 0,
						},
					},
					Gui.Button "upGread"
					{
						Size = Vector2(162, 27),
						Location = Vector2(160,6),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Text = lang:GetText("空间升级"),
						Skin = Skin.LevelUpBtnSkin,
						EventClick = function()
							L_PlaceLevelUp.Show_PlaceLevelUp(L_FightTeam.t_id)
						end
					},
					Gui.Button "Zhandui_Quick"
					{
						Location = Vector2(420, 30),
						Size = Vector2(112, 27),
						BackgroundColor = ARGB(255,255,255,255),
						Text = lang:GetText("快速获取"),
						Skin = Skin.LevelUpBtnSkin,
						EventClick = function()
							L_FightTeam.Show_TeamAddPower()
						end,
					},
					Gui.Label "zhandui_fightsource_rate"
					{
						Location = Vector2(0, 36),
						Size = Vector2(420, 20),
						FontSize = 16,
						TextAlign = "kAlignRightTop",
						TextColor = ARGB(255, 255, 255, 255),
						Text = lang:GetText("战队原石每小时转换：1000黑铁(自动转换)"),
						BackgroundColor = ARGB(0, 255, 255, 255),
					},
					Gui.Control
					{
						Size = Vector2(30, 30),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Location = Vector2(35, 56),
						Hint = lang:GetText("战队原石"),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/team/lb_icon_res_02.dds",Vector4(10, 10, 10, 10)),
						},
					},
					Gui.Control
					{
						Size = Vector2(432, 25),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Location = Vector2(99, 59),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/lb_com_bg.dds",Vector4(45,0,20,0)),
						},
						Gui.Control "zhandui_cannot_use_oil"
						{
							Size = Vector2(422, 17),
							Size = Vector2(422, 17),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Location = Vector2(5, 4),
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/team/lb_res_bg_02.dds",Vector4(0, 0, 0, 0)),
							},
						},
						-- Gui.Control
						-- {
							-- Size = Vector2(39, 25),
							-- BackgroundColor = ARGB(255, 255, 255, 255),
							-- Location = Vector2(0, 0),
							-- Skin = Gui.ControlSkin
							-- {
								-- BackgroundImage = Gui.Image("LobbyUI/lb_com_bg_01.dds",Vector4(69,0,112,0)),
							-- },
						-- },
						Gui.Label "zhandui_cannot_use_rate"
						{
							Location = Vector2(0, 3),
							Size = Vector2(422, 17),
							FontSize = 16,
							TextAlign = "kAlignRightMiddle",
							TextColor = ARGB(255, 255, 255, 255),
							Text = "1/1",
							BackgroundColor = ARGB(0, 255, 255, 255),
						},
					},
					Gui.Control
					{
						Size = Vector2(30, 30),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Location = Vector2(35,86),
						Hint = lang:GetText("战队黑铁"),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/team/lb_icon_res_01.dds",Vector4(10, 10, 10, 10)),
						},
					},
					Gui.Control
					{
						Size = Vector2(432, 25),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Location = Vector2(99, 89),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/lb_com_bg.dds",Vector4(45,0,20,0)),
						},
						Gui.Control "zhandui_can_use_oil"
						{
							Size = Vector2(422, 17),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Location = Vector2(5, 4),
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/team/lb_res_bg_01.dds",Vector4(0, 0, 0, 0)),
							},
						},
						-- Gui.Control
						-- {
							-- Size = Vector2(39, 25),
							-- BackgroundColor = ARGB(255, 255, 255, 255),
							-- Location = Vector2(0, 0),
							-- Skin = Gui.ControlSkin
							-- {
								-- BackgroundImage = Gui.Image("LobbyUI/lb_com_bg_01.dds",Vector4(69,0,112,0)),
							-- },
						-- },
						Gui.Label "zhandui_can_use_rate"
						{
							Location = Vector2(0, 3),
							Size = Vector2(422, 17),
							FontSize = 16,
							TextAlign = "kAlignRightMiddle",
							TextColor = ARGB(255, 255, 255, 255),
							Text = "1/1",
							BackgroundColor = ARGB(0, 255, 255, 255),
						},
					},
				},
				Gui.Control "my_source"
				{
					Size = Vector2(544, 125),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Location = Vector2(527, 37),
					Visible = false,
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_bg_02.dds",Vector4(10, 10, 2, 2)),
					},
					Gui.Control
					{
						Size = Vector2(269, 29),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Location = Vector2(5, 6),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/team/lb_yaoqing_bg.dds",Vector4(0, 0, 0, 0)),
						},
						Gui.Control
						{
							Size = Vector2(68,17),
							Location = Vector2(12, 7),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_zhanduikongjian.dds", Vector4(0, 0, 0, 0)),
							},
						},
						-- Gui.Label
						-- {
							-- Location = Vector2(12, 0),
							-- Size = Vector2(230, 20),
							-- FontSize = 20,
							-- TextAlign = "kAlignLeftMiddle",
							-- TextColor = ARGB(255, 255, 210, 0),
							-- Text = lang:GetText("领地等级"),
							-- BackgroundColor = ARGB(0, 255, 255, 255),
						-- },
						Gui.FlowLayout "My_SourceLv_layout"
						{
							Location = Vector2(110,5),
							Size = Vector2(60,20),
							Direction = "kHorizontal",
							Align = "kAlignLeftMiddle",
							ControlAlign = "kAlignCenterMiddle",
							ControlSpace = 0,
						},
					},
					Gui.Button "My_Quick"
					{
						Location = Vector2(420, 30),
						Size = Vector2(112, 27),
						BackgroundColor = ARGB(255,255,255,255),
						Text = lang:GetText("快速获取"),
						Skin = Skin.LevelUpBtnSkin,
						EventClick = function()
							L_FightTeam.Show_MyAddPower()
						end,
					},
					Gui.Label "my_fightsource_rate"
					{
						Location = Vector2(0, 36),
						Size = Vector2(420, 20),
						FontSize = 16,
						TextAlign = "kAlignRightTop",
						TextColor = ARGB(255, 255, 255, 255),
						Text = lang:GetText("个人原石每小时转换：1000黑晶石(自动转换)"),
						BackgroundColor = ARGB(0, 255, 255, 255),
					},
					Gui.Control
					{
						Size = Vector2(30, 30),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Location = Vector2(35, 56),
						Hint = lang:GetText("个人原石"),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/team/lb_icon_res_02_1.dds",Vector4(10, 10, 10, 10)),
						},
					},
					Gui.Control
					{
						Size = Vector2(432, 25),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Location = Vector2(99, 59),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/lb_com_bg.dds",Vector4(45,0,20,0)),
						},
						Gui.Control "my_cannot_use_oil"
						{
							Size = Vector2(422, 17),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Location = Vector2(5, 4),
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/team/lb_res_bg_02_3.dds",Vector4(0, 0, 0, 0)),
							},
						},
						-- Gui.Control
						-- {
							-- Size = Vector2(39, 25),
							-- BackgroundColor = ARGB(255, 255, 255, 255),
							-- Location = Vector2(0, 0),
							-- Skin = Gui.ControlSkin
							-- {
								-- BackgroundImage = Gui.Image("LobbyUI/lb_com_bg_01.dds",Vector4(69,0,112,0)),
							-- },
						-- },
						Gui.Label "my_cannot_use_rate"
						{
							Location = Vector2(0, 3),
							Size = Vector2(422, 17),
							FontSize = 16,
							TextAlign = "kAlignRightMiddle",
							TextColor = ARGB(255, 255, 255, 255),
							Text = "1/1",
							BackgroundColor = ARGB(0, 255, 255, 255),
						},
					},
					Gui.Control
					{
						Size = Vector2(30, 30),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Location = Vector2(35,86),
						Hint = lang:GetText("个人黑晶石"),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/team/lb_icon_res_03.dds",Vector4(10, 10, 10, 10)),
						},
					},
					Gui.Control
					{
						Size = Vector2(432, 25),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Location = Vector2(99, 89),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/lb_com_bg.dds",Vector4(45,0,20,0)),
						},
						Gui.Control "my_can_use_oil"
						{
							Size = Vector2(422, 17),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Location = Vector2(5, 4),
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/team/lb_res_bg_03.dds",Vector4(0, 0, 0, 0)),
							},
						},
						-- Gui.Control
						-- {
							-- Size = Vector2(39, 25),
							-- BackgroundColor = ARGB(255, 255, 255, 255),
							-- Location = Vector2(0, 0),
							-- Skin = Gui.ControlSkin
							-- {
								-- BackgroundImage = Gui.Image("LobbyUI/lb_com_bg_01.dds",Vector4(69,0,112,0)),
							-- },
						-- },
						Gui.Label "my_can_use_rate"
						{
							Location = Vector2(0, 3),
							Size = Vector2(422, 17),
							FontSize = 16,
							TextAlign = "kAlignRightMiddle",
							TextColor = ARGB(255, 255, 255, 255),
							Text = "1/1",
							BackgroundColor = ARGB(0, 255, 255, 255),
						},
					},
				},
				Gui.Button "b_zhandui"
				{
					Location = Vector2(882, 14),
					Size = Vector2(93, 24),
					BackgroundColor = ARGB(255,255,255,255),
					Text = lang:GetText("战队"),
					PushDown = true,
					TextColor = ARGB(255,0,0,0),
					HighlightTextColor = ARGB(255,255,255,255),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_button11_normal.dds", Vector4(0, 0, 0, 0)),
						HoverImage = Gui.Image("LobbyUI/team/lb_squad_button11_hover.dds", Vector4(0, 0, 0, 0)),
						DownImage = Gui.Image("LobbyUI/team/lb_squad_button11_down.dds", Vector4(0, 0, 0, 0)),
						DisabledImage = Gui.Image("LobbyUI/team/lb_squad_button11_disabled.dds", Vector4(0, 0, 0, 0)),
					},
					EventClick = function()
						LobbyMainWin.zhandui_source.Visible = true
						LobbyMainWin.my_source.Visible = false
						LobbyMainWin.b_zhandui.PushDown = true
						LobbyMainWin.b_geren.PushDown = false
					end,
				},
				Gui.Button "b_geren"
				{
					Location = Vector2(978, 14),
					Size = Vector2(93, 24),
					BackgroundColor = ARGB(255,255,255,255),
					Text = lang:GetText("个人"),
					TextColor = ARGB(255,0,0,0),
					HighlightTextColor = ARGB(255,255,255,255),
					PushDown = false,
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_button11_normal.dds", Vector4(0, 0, 0, 0)),
						HoverImage = Gui.Image("LobbyUI/team/lb_squad_button11_hover.dds", Vector4(0, 0, 0, 0)),
						DownImage = Gui.Image("LobbyUI/team/lb_squad_button11_down.dds", Vector4(0, 0, 0, 0)),
						DisabledImage = Gui.Image("LobbyUI/team/lb_squad_button11_disabled.dds", Vector4(0, 0, 0, 0)),
					},
					EventClick = function()
						LobbyMainWin.zhandui_source.Visible = false
						LobbyMainWin.my_source.Visible = true
						LobbyMainWin.b_zhandui.PushDown = false
						LobbyMainWin.b_geren.PushDown = true
					end,
				},
				Gui.FlashControl "f_billbord"
				{
					Text = config:GetBillBoardH(),
					Location = Vector2(527, 14),
					-- Size = Vector2(484, 140),
					Size = Vector2(544, 125),
					BackgroundColor = ARGB(255, 255, 255, 255),
					IsUrl = true,
				},
			},
			Gui.Button "btn_sourcefight"
			{
				Location = Vector2(332, 214),
				Size = Vector2(269, 44),
				BackgroundColor = ARGB(255,255,255,255),
				Text = lang:GetText("资源争夺战"),
				TextColor = ARGB(255,200,200,200),
				FontSize = 16,
				HighlightTextColor = ARGB(255,255, 255, 255),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/lb_shop_button12_normal.dds", Vector4(0, 0, 0, 0)),
					HoverImage = Gui.Image("LobbyUI/team/lb_shop_button12_hover.dds", Vector4(0, 0, 0, 0)),
					DownImage = Gui.Image("LobbyUI/team/lb_shop_button12_down.dds", Vector4(0, 0, 0, 0)),
					DisabledImage = Gui.Image("LobbyUI/team/lb_shop_button12_disabled.dds", Vector4(0, 0, 0, 0)),
				},
				EventClick = function(sender, e)
			
					SetSourceBtn(sender, 1)
					L_FightTeam.mode = 3
					
					
				
					L_FightTeam.allteam_source_ui.team_prompting.Location = Vector2(430, 0)
					if L_FightTeam.Res_ratio_status1 == "1" then
						L_FightTeam.allteam_source_ui.team_prompting.Text = lang:GetText("")
					elseif L_FightTeam.Res_ratio_status1 == "2" then
						L_FightTeam.allteam_source_ui.team_prompting.Text= lang:GetText("战队今日原石收入已到上限，收益降为1/2 ")	
					elseif L_FightTeam.Res_ratio_status1 == "3" then
						L_FightTeam.allteam_source_ui.team_prompting.Text= lang:GetText("战队今日原石收入已满额，收益降为0 ")	
					end
					L_FightTeam.allteam_source_ui.team_prompting1.Location = Vector2(430, 25)
					if L_FightTeam.player_Res_ratio_status1 == "1" then
						L_FightTeam.allteam_source_ui.team_prompting1.Text = lang:GetText("")
					elseif L_FightTeam.player_Res_ratio_status1 == "2" then
						L_FightTeam.allteam_source_ui.team_prompting1.Text= lang:GetText("您今日原石收入已到上限，收益降为1/2")	
					elseif L_FightTeam.player_Res_ratio_status1 == "3" then
						L_FightTeam.allteam_source_ui.team_prompting1.Text= lang:GetText("您今日原石收入已满额，收益降为0")	
					end
				end,
			},
			Gui.Button "btn_my"
			{
				Location = Vector2(57, 214),
				Size = Vector2(269, 44),
				BackgroundColor = ARGB(255,255,255,255),
				Text = lang:GetText("战队战"),
				FontSize = 16,
				TextColor = ARGB(255,200,200,200),
				HighlightTextColor = ARGB(255,255, 255, 255),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/lb_shop_button12_normal.dds", Vector4(0, 0, 0, 0)),
					HoverImage = Gui.Image("LobbyUI/team/lb_shop_button12_hover.dds", Vector4(0, 0, 0, 0)),
					DownImage = Gui.Image("LobbyUI/team/lb_shop_button12_down.dds", Vector4(0, 0, 0, 0)),
					DisabledImage = Gui.Image("LobbyUI/team/lb_shop_button12_disabled.dds", Vector4(0, 0, 0, 0)),
				},
				EventClick = function(sender, e)
					SetSourceBtn(sender, 2)
					L_FightTeam.mode = 1
					L_FightTeam.FillTeam()
					L_FightTeam.team_ui.btn_my.PushDown = true
					L_FightTeam.team_ui.btn_list.PushDown = false
					L_FightTeam.team_list_ui.root.Visible = false
					L_FightTeam.team_ui.my_team.Visible = true
				end,
			},
			Gui.Button "btn_list"
			{
				Location = Vector2(607, 214),
				Size = Vector2(269, 44),
				BackgroundColor = ARGB(255,255,255,255),
				Text = lang:GetText("战队列表"),
				FontSize = 16,
				TextColor = ARGB(255,200,200,200),
				HighlightTextColor = ARGB(255,255, 255, 255),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/lb_shop_button12_normal.dds", Vector4(0, 0, 0, 0)),
					HoverImage = Gui.Image("LobbyUI/team/lb_shop_button12_hover.dds", Vector4(0, 0, 0, 0)),
					DownImage = Gui.Image("LobbyUI/team/lb_shop_button12_down.dds", Vector4(0, 0, 0, 0)),
					DisabledImage = Gui.Image("LobbyUI/team/lb_shop_button12_disabled.dds", Vector4(0, 0, 0, 0)),
				},
				EventClick = function(sender, e)
					SetSourceBtn(sender, 3)
					L_FightTeam.default_mode = 1
					L_FightTeam.mode = 2
					L_FightTeam.rank_select_page = 1
					L_FightTeam.team_list_type = 1
					L_FightTeam.Set_type_btn()
					-- L_FightTeam.FillTeam()
					local cbx = L_FightTeam.team_list_ui.province
					cbx:RemoveAll()
					cbx:AddItem( lang:GetText("全部") )
					for _,v in ipairs(L_FightTeam.province) do
						cbx:AddItem( v )
					end
					L_FightTeam.team_list_ui.province.Text = lang:GetText("全部")
					L_FightTeam.team_list_ui.city.Text = lang:GetText("全部")
				end,
			},
		},
			
		--公告
		Gui.Control "lb_Announcement"
		{
			Size = Vector2(390, 35),
			Location = Vector2(483, 180),
			BackgroundColor = ARGB(0, 255, 255, 255),
		},
		
		Gui.Control "buff_list_con"
		{
			Visible = false,
			Size = Vector2(180,180),
			Location = Vector2(514,29),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/lb_bg_win01_4_buff_bg.dds",Vector4(11, 14, 11, 14)),
			},
			
			Gui.FlowLayout "buff_layout_1"
			{
				Location = Vector2(13,15),
				Size = Vector2(140,160),
				Direction = "kHorizontal",
				ControlSpace = 1,
				LineSpace = 7,
			},
			
			Gui.Button
			{
				Size = Vector2(20,24),
				Location = Vector2(150,10),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/lb_bg_win01_4_button_01_normal.dds", Vector4(10, 10, 10, 10)),
					HoverImage = Gui.Image("LobbyUI/lb_bg_win01_4_button_01_hover.dds", Vector4(10, 10, 10, 10)),
					DownImage = Gui.Image("LobbyUI/lb_bg_win01_4_button_01_down.dds", Vector4(10, 10, 10, 10)),
					DisabledImage = Gui.Image("LobbyUI/lb_info_button02_normal.dds", Vector4(10, 10, 10, 10)),
				},
				EventClick = function(sender, e)
					sender.Parent.Visible = false
				end
			},
		},
		
		Gui.Control "vip_tips" 
		{
			Size = Vector2(335, 307),
			Location = Vector2(543,97),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Visible = false,
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ToolTips/lb_tooltips_bg.dds",Vector4(10, 10, 10, 10)),
			},
			
			Gui.Control
			{							
				Size = Vector2(317, 66),
				Location = Vector2(9, 8),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ToolTips/lb_tooltips_bg_wqmc.dds",Vector4(10, 10, 10, 10)),
				},
				Gui.Label
				{
					Size = Vector2(317, 22),
					Location = Vector2(0, 5),
					TextColor = ARGB(255,255,190,0),
					FontSize = 20,
					TextAlign = "kAlignCenterMiddle",
					Text = lang:GetText("点击可查询所有VIP特权"),
				},
				Gui.Label "l_viplevel"
				{
					Size = Vector2(317, 22),
					Location = Vector2(0, 30),
					TextColor = ARGB(255, 215, 232, 227),
					FontSize = 18,
					TextAlign = "kAlignCenterMiddle",
					Text = lang:GetText("当前等级VIP6"),
				},
			},
			Gui.Control
			{							
				Size = Vector2(317, 110),
				Location = Vector2(9, 79),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ToolTips/lb_tooltips_bg_2.dds",Vector4(8, 8, 8, 8)),
				},
				Gui.Control "ctr_VIP_Tips"
				{
					Location = Vector2(88, 4),
					Size = Vector2(142, 77),
					BackgroundColor = ARGB(255,255,255,255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_bg_01.dds", Vector4(0, 0, 0, 0)),
					},
					Gui.Button "ctr_VIP_num_Tips"
					{
						Location = Vector2(44, 30),
						Size = Vector2(50, 29),
						BackgroundColor = ARGB(255,255,255,255),
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_button_01_normal.dds", Vector4(0, 0, 0, 0)),
							HoverImage = Gui.Image("LobbyUI/vip/vip/VIP_button_01_hover.dds", Vector4(0, 0, 0, 0)),
							DownImage = Gui.Image("LobbyUI/vip/vip/VIP_button_01_down.dds", Vector4(0, 0, 0, 0)),
							DisabledImage = Gui.Image("LobbyUI/vip/vip/VIP_button_01_disabled.dds", Vector4(0, 0, 0, 0)),
						},
					},
				},
				Gui.Label
				{
					Size = Vector2(150, 19),
					Location = Vector2(0, 70),
					TextColor = ARGB(255,255,190,0),
					FontSize = 18,
					TextAlign = "kAlignCenterMiddle",
					Text = lang:GetText("高级VIP状态："),
				},
				Gui.Label "lbl_left_day"
				{
					Size = Vector2(200, 25),
					Location = Vector2(130, 70),
					TextColor = ARGB(255, 255, 96, 0),
					FontSize = 18,
					TextAlign = "kAlignLeftMiddle",
					Text = lang:GetText("剩余30天"),
				},
			},
			Gui.Control
			{							
				Size = Vector2(317, 100),
				Location = Vector2(9, 197),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ToolTips/lb_tooltips_bg_2.dds",Vector4(8, 8, 8, 8)),
				},
				Gui.Label "lb_vip_text"
				{
					Size = Vector2(250, 19),
					Location = Vector2(0, 10),
					TextColor = ARGB(255,255,190,0),
					FontSize = 18,
					TextAlign = "kAlignCenterMiddle",
					Text = lang:GetText("下一级需要经验：8000"),
				},
				Gui.Control
				{
					Size = Vector2(286,25),
					Location = Vector2(15, 38),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/vip/vip/lb_VIP_scrollbar_slider.dds", Vector4(10, 10, 20, 10)),
					},
					Gui.Control "exp_bar"
					{
						Size = Vector2(0,25),
						Location = Vector2(0, 0),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/vip/vip/lb_VIP_scrollbar_bg.dds", Vector4(10, 10, 20, 10)),
						},
					},
				},
			},
		},
	},
}

--大厅主界面 中部
LobbyMainWin_Boddy = Gui.Create(LobbyMainWin.LobbyMain_Root)
{
	Gui.Control "LobbyMainWin_Boddy_Root"
	{
		Size = Vector2(1150, 630),
		BackgroundColor = ARGB(0, 255, 255, 255),
		Location = Vector2(0, 0),
	},
}

LobbyMainCalendar = Gui.Create(LobbyMainWin.LobbyMain_Root)
{
	Gui.Control "weekday"
	{
		Visible = false,
		Location = Vector2(312, 88),
		Size = Vector2(455, 36),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/dailycheck/lb_calendar_weektable.dds", Vector4(0, 0, 0, 0)),
		},
	},
	Gui.Calendar "calendar"
	{
		Visible = false,
		ButtonSpace = Vector2(1,1),
		Location = Vector2(314, 132),
		Size = Vector2(449, 226),
		FontSize = 24,
		TextColor = ARGB(255,0,0,0),
		CanSupplyNum = 30,
		CanPrepareNum = 3,
		BtnSkin = Gui.ButtonSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/dailycheck/calendar_table04_today.dds", Vector4(20, 20, 20, 20)),
			TwinkleImage = Gui.Image("LobbyUI/dailycheck/calendar_table04_today_flash.dds", Vector4(0, 0, 0, 0)),
			HoverImage = Gui.Image("LobbyUI/dailycheck/lb_calendar_table04_hover.dds", Vector4(20, 20, 20, 20)),
			DownImage = Gui.Image("LobbyUI/dailycheck/lb_calendar_table04_down.dds", Vector4(20, 20, 20, 20)),
			DisabledImage = Gui.Image("LobbyUI/dailycheck/lb_calendar_table04_normal.dds", Vector4(20, 20, 20, 20)),
		},
		BtnSkinSupply = Gui.ButtonSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/dailycheck/calendar_table04_buqian.dds", Vector4(20, 20, 20, 20)),
			TwinkleImage = Gui.Image("LobbyUI/dailycheck/calendar_table04_buqian_flash.dds", Vector4(0, 0, 0, 0)),
			HoverImage = Gui.Image("LobbyUI/dailycheck/lb_calendar_table04_hover.dds", Vector4(20, 20, 20, 20)),
			DownImage = Gui.Image("LobbyUI/dailycheck/lb_calendar_table04_down.dds", Vector4(20, 20, 20, 20)),
			DisabledImage = Gui.Image("LobbyUI/dailycheck/lb_calendar_table04_normal.dds", Vector4(20, 20, 20, 20)),
		},
		BtnSkinPrepare = Gui.ButtonSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/dailycheck/calendar_table04_buqian.dds", Vector4(20, 20, 20, 20)),
			TwinkleImage = Gui.Image("LobbyUI/dailycheck/calendar_table04_buqian_flash.dds", Vector4(0, 0, 0, 0)),
			HoverImage = Gui.Image("LobbyUI/dailycheck/lb_calendar_table04_hover.dds", Vector4(20, 20, 20, 20)),
			DownImage = Gui.Image("LobbyUI/dailycheck/lb_calendar_table04_down.dds", Vector4(20, 20, 20, 20)),
			DisabledImage = Gui.Image("LobbyUI/dailycheck/lb_calendar_table04_normal.dds", Vector4(20, 20, 20, 20)),
		},
		Skin = Gui.CalendarSkin
		{
			DisabledImage = Gui.Image("LobbyUI/dailycheck/calendar_table01_normal.dds", Vector4(0, 0, 0, 0)),
			ActivateImage = Gui.Image("LobbyUI/dailycheck/calendar_table03_sign.dds", Vector4(0, 0, 0, 0)),
			InActivateImage = Gui.Image("LobbyUI/dailycheck/calendar_table02_pass.dds", Vector4(0, 0, 0, 0)),
		},
		EventButtonClick = function(sender, e)
			L_DailyCheck.SendDailyCheckList(sender.CheckValue)	
		end
	},
}

LobbyMainWin_Header = Gui.Create(LobbyMainWin.LobbyMain_Root)
{
	Gui.Control "LobbyMainWin_Header_Root"
	{
		Size = Vector2(1170, 210),
		BackgroundColor = ARGB(0, 255, 255, 255),
		Location = Vector2(0, 0),
		
		Gui.Control "img_UserHeadIcon"
		{
			Size = Vector2(77, 87),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Location = Vector2(218, 38),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/lb_info_image01.dds", Vector4(0, 0, 0, 0)),
			},
		},
		
		--LV
		Gui.Control "lb_UserLevel"
		{
			Location = Vector2(177, 10),
			Size = Vector2(40, 36),
			BackgroundColor = ARGB(255,255,255,255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = nil,
			},
		},

		--等级十位
		Gui.Control "lb_UserLevel_Ten"
		{
			Location = Vector2(184, 12),
			Size = Vector2(13, 24),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_summary_number_6b.dds",Vector4(0, 0, 0, 0), Vector4(0, 0, 0.1, 1)),
			},
			
		},
	
		--等级十位百分比
		Gui.Control "lb_UserLevel_TenState"
		{
			Location = Vector2(184, 36),
			Size = Vector2(13, 0),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_summary_number_7b.dds",Vector4(0, 0, 0, 0), Vector4(0, 0, 0.1, 0)),
			},
			
		},
		
		--等级个位
		Gui.Control "lb_UserLevel_Anold"
		{
			Location = Vector2(198, 12),
			Size = Vector2(13, 24),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_summary_number_6b.dds", Vector4(0, 0, 0, 0),Vector4(0, 0, 0.1, 1)),
			},
			
		},
		
		--等级个位百分比
		Gui.Control "lb_UserLevel_AnoldState"
		{
			Location = Vector2(198, 36),
			Size = Vector2(13, 0),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_summary_number_7b.dds", Vector4(0, 0, 0, 0),Vector4(0, 0, 0.1, 0)),
			},
			
		},
		
		Gui.ItemBoxBtn
		{
			Style = "Gui.ItemBoxBtn_ib",
			Size = Vector2(44,44),
			Location = Vector2(175, 2),
			BackgroundColor = ARGB(255, 255, 255, 255),
			
			Skin = Gui.ItemBoxBtnSkin
			{
				NeutralNormalImage = nil,
				NeutralHoverImage = nil,
				NeutralSelectedImage = nil,
				NeutralDisabledImage = nil,
			},
			
			EventMouseEnter = function(sender, e)
				local info = PersonalInfo_data
				if info then
					L_ToolTips.FillToolUserLevelWindow(info.exp - LevelInfo_rpc_data[info.level][2],LevelInfo_rpc_data[info.level + 1][2] - LevelInfo_rpc_data[info.level][2])
				end
			end,
			EventToolTipsShow = function(sender, e)
				if PersonalInfo_data then
					L_ToolTips.ShowToolTipsShowWindow(sender)
				end
			end,
			EventMouseLeave = function(sender, e)
				L_ToolTips.HideToolTipsWindow()
			end,
		},
		--角色名字
		Gui.Label "lb_UserName"
		{
			Location = Vector2(212, 6),
			Size = Vector2(196, 30),
			FontSize = 16,
			TextAlign = "kAlignLeftMiddle",
			TextColor = ARGB(255, 234, 255, 0),
			Text = lang:GetText("加载中..."),
			BackgroundColor = ARGB(0, 255, 255, 255),
		},
		
		Gui.Button "b_SecondCode"
		{
			Size = Vector2(28,29),
			Location = Vector2(185,50),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/lb_SecondCode_button01_normal.dds", Vector4(0, 0, 0, 0)),
				HoverImage = Gui.Image("LobbyUI/lb_SecondCode_button01_hover.dds", Vector4(0, 0, 0, 0)),
				DownImage = Gui.Image("LobbyUI/lb_SecondCode_button01_down.dds", Vector4(0, 0, 0, 0)),
				DisabledImage = Gui.Image("LobbyUI/lb_SecondCode_button01_disabled.dds", Vector4(0, 0, 0, 0)),
			},
			EventClick = function()
				L_SecondCode.SecondCode.delete_password.Visible = false
				L_SecondCode.SecondCode.forget_password.Visible = true
				rpc.safecallload("get_second_password_status", {pid = state:GetCharacterId()},
				function (data)
					if data then
						if data.status == 0 then
							L_SecondCode.SecondCode.first_secondcode.Visible = true
							L_SecondCode.SecondCode.second_secondcode.Visible = false
							L_SecondCode.Show_SecondCode()
						elseif data.status == 1 then
							L_SecondCode.SecondCode.first_secondcode.Visible = false
							L_SecondCode.SecondCode.second_secondcode.Visible = true
							L_SecondCode.Show_SecondCode()
						elseif data.status == 2 then
							local day = math.floor(data.time/(24*3600))
							L_SecondCode.SecondCode.first_secondcode.Visible = false
							L_SecondCode.SecondCode.second_secondcode.Visible = true
							L_SecondCode.SecondCode.delete_password.Visible = true
							L_SecondCode.SecondCode.delete_password.Text = lang:GetText("你已经使用忘记密码功能，密码将在")..day..lang:GetText("天后被清除，\n在此期间验证密码将会退出清除状态")
							L_SecondCode.SecondCode.forget_password.Visible = false
							L_SecondCode.Show_SecondCodeConfirm()
						end	
					end	
				end)
			end
		},

		Gui.FlowLayout "UserNickName_layout"
		{
			Location = Vector2(392,50),
			Size = Vector2(100,20),
			Direction = "kHorizontal",
			Align = "kAlignLeftMiddle",
			ControlAlign = "kAlignCenterMiddle",
			ControlSpace = 0,
		},
	
		Gui.FlowLayout "buff_layout"
		{
			Location = Vector2(362,27),
			Size = Vector2(216,16),
			Direction = "kHorizontal",
			Align = "kAlignLeftMiddle",
			--ControlAlign = "kAlignCenterMiddle",
			ControlSpace = 1,
		},
		
		Gui.Button
		{
			Size = Vector2(20,24),
			Location = Vector2(450,20),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/lb_bg_win01_4_button_normal.dds", Vector4(10, 10, 10, 10)),
				HoverImage = Gui.Image("LobbyUI/lb_bg_win01_4_button_hover.dds", Vector4(10, 10, 10, 10)),
				DownImage = Gui.Image("LobbyUI/lb_bg_win01_4_button_down.dds", Vector4(10, 10, 10, 10)),
				DisabledImage = Gui.Image("LobbyUI/lb_info_button02_normal.dds", Vector4(10, 10, 10, 10)),
			},
			EventClick = function()
				LobbyMainWin.buff_list_con.Visible = true
			end
		},
		
		--GP
		Gui.Label "lb_GP"
		{
			Location = Vector2(332, 100),
			Size = Vector2(118, 30),
			FontSize = 20,
			TextAlign = "kAlignRightMiddle",
			TextColor = ARGB(255, 255, 234, 86),
			Text = "0",
		},
		
		--cal
		Gui.Label
		{
			Location = Vector2(455, 102),
			Size = Vector2(80, 30),
			FontSize = 16,
			TextAlign = "kAlignRightMiddle",
			TextColor = ARGB(255, 255, 204, 86),
			Text = lang:GetText("C币"),
		},
		
		--FC点
		Gui.Label "lb_LeiPoint"
		{
			Location = Vector2(332, 72),
			Size = Vector2(118, 30),
			FontSize = 20,
			TextAlign = "kAlignRightMiddle",
			TextColor = ARGB(255, 255, 234, 86),
			Text = "0",
		},
		
		
		Gui.Label
		{
			Location = Vector2(455, 72),
			Size = Vector2(80, 30),
			FontSize = 16,
			TextAlign = "kAlignRightMiddle",
			TextColor = ARGB(255, 255, 204, 86),
			Text = lang:GetText("FC点"),
		},
	
		--查看详情
		Gui.Button "btn_ShowMoreInfo"
		{
			Size = Vector2(56,56),
			Location = Vector2(479, 16),
			Text = "",
			TextColor = ARGB(255, 52, 51, 49),
			FontSize = 16,
			Enable = true,
			Visible = true,
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/lb_info_button02_normal.dds", Vector4(10, 10, 10, 10)),
				HoverImage = Gui.Image("LobbyUI/lb_info_button02_hover.dds", Vector4(10, 10, 10, 10)),
				DownImage = Gui.Image("LobbyUI/lb_info_button02_down.dds", Vector4(10, 10, 10, 10)),
				DisabledImage = Gui.Image("LobbyUI/lb_info_button02_normal.dds", Vector4(10, 10, 10, 10)),
			},
			EventClick = function()
				if LobbyMainWin_Boddy then
					L_PersonalInfo.Show(LobbyMainWin_Boddy.LobbyMainWin_Boddy_Root)
				end
				InitPersonalInfoRPCInfo()
				lg:SetLobbyModules(12)
				current_chosse_main_page = 12
				L_PersonalInfo.SynchronousClassButton()
				L_LobbyMain.FillClassBag(ptr_cast(game.CurrentState):GetCharacterId(), L_LobbyMain.current_choose_class)
			end
		},
			
		Gui.FlashControl
		{
			Text = config:GetBillBoardH(),
			Location = Vector2(577, 3),
			Size = Vector2(484, 140),
			BackgroundColor = ARGB(255, 255, 255, 255),
			IsUrl = true,
		},
			
		Gui.TimeControl "time_msg"
		{
			Size = Vector2(5,5),
			Dock = "kDockCenter",
			BackgroundColor = ARGB(0, 255, 255, 255),
			EventTimeOut = function(sender, e)
				L_LobbyMain.LobbyMainWin_Header.lb_horn.Visible = false
			end
		},
		
		--大喇叭
		Gui.Control "lb_horn"
		{
			Size = Vector2(484,140),
			Location = Vector2(577, 3),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Visible = false,
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/lb_top_ad_black.dds", Vector4(14, 14, 14, 14)),
			},
		
			Gui.RichEdit "re_msg"
			{
				Size = Vector2(464, 140),
				Location = Vector2(10, 0),
				FontSize = 16,
				BackgroundColor = ARGB(0, 255, 255, 255),
				
				VScrollBarWidth = 16,
				VScrollBarButtonSize = 1,
				Style = "Gui.MessagePanel",
				AutoScroll = true,
				AutoScrollMinSize = Vector2(464, 140),
				HScrollBarDisplay = "kHide",
				VScrollBarDisplay = "kAuto",
				
				EventClick_Name = function()
					local Tep_i = 1
					while Look_play_Info[Tep_i] do
						if LobbyMainWin_Header.re_msg.Click_Name == Look_play_Info[Tep_i][1] then
							L_LobbyMain.ChatPrivate(Look_play_Info[Tep_i][1],nil,Look_play_Info[Tep_i][2])
							return
						end
						Tep_i = Tep_i + 1
					end
					L_LobbyMain.ChatPrivate(LobbyMainWin_Header.re_msg.Click_Name)
				end,
			},
		},
			
		--退出
		Gui.Button "btn_FromExit"
		{
			Size = Vector2(84,44),
			Location = Vector2(1070, 4),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/lb_button02_exit_normal.dds", Vector4(0, 0, 0, 0)),
				HoverImage = Gui.Image("LobbyUI/lb_button02_exit_hover.dds", Vector4(0, 0, 0, 0)),
				DownImage = Gui.Image("LobbyUI/lb_button02_exit_down.dds", Vector4(0, 0, 0, 0)),
				DisabledImage = Gui.Image("LobbyUI/lb_button02_exit_normal.dds", Vector4(0, 0, 0, 0)),
			},
			EventClick = function()
				Show_QuitWin()
			end
		},
		
		--设置
		Gui.Button
		{
			Size = Vector2(84,44),
			Location = Vector2(1070, 51),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/lb_button02_setting_normal.dds", Vector4(0, 0, 0, 0)),
				HoverImage = Gui.Image("LobbyUI/lb_button02_setting_hover.dds", Vector4(0, 0, 0, 0)),
				DownImage = Gui.Image("LobbyUI/lb_button02_setting_down.dds", Vector4(0, 0, 0, 0)),
				DisabledImage = Gui.Image("LobbyUI/lb_button02_setting_normal.dds", Vector4(0, 0, 0, 0)),
			},
			EventClick = function()
				L_Settings.Show()
			end
		},
		
		--充值
		Gui.Button
		{
			Size = Vector2(84,44),
			Location = Vector2(1070, 98),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Enable = true,
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/lb_button02_recharge_normal.dds", Vector4(0, 0, 0, 0)),
				HoverImage = Gui.Image("LobbyUI/lb_button02_recharge_hover.dds", Vector4(0, 0, 0, 0)),
				DownImage = Gui.Image("LobbyUI/lb_button02_recharge_down.dds", Vector4(0, 0, 0, 0)),
				DisabledImage = Gui.Image("LobbyUI/lb_button02_recharge_normal.dds", Vector4(0, 0, 0, 0)),
			},
			EventClick = function()
				gui:ShowIE()
			end
		},
		
		--版本
		Gui.Control "ctr_Version"
		{
			Location = Vector2(19, 114),
			Size = Vector2(140, 22),
			BackgroundColor = ARGB(0,255,255,255),

			Gui.Label "lb_Version"
			{
				Location = Vector2(-8, -2),
				Size = Vector2(140, 22),
				FontSize = 14,
				TextAlign = "kAlignCenterMiddle",
				TextColor = ARGB(255, 255, 234, 86),
				Text = "0.0.0.0.0.0",	
			},
		},
		
		Gui.ShaderButton "shooting"
		{
			Size = Vector2(180, 64),
			Location = Vector2(665, 147),
			ShaderPS = "control_flow",
			BackgroundColor = ARGB(255, 255, 255, 255),
			--Visible = false,
			Skin = Gui.ShaderButtonSkin
			{
			    ResImage1 = Gui.Image("LobbyUI/effect/lb_onlinetime_flash.dds", Vector4(0, 0, 0, 0)),
                ResImage2 = Gui.Image("LobbyUI/effect/renderuvmapping.tga", Vector4(0, 0, 0, 0)),
                ResImage3 = nil,
				BackgroundImage = Gui.Image("LobbyUI/Shooting/lb_range_button_getinto_normal.dds", Vector4(0, 0, 0, 0)),
				HoverImage = Gui.Image("LobbyUI/Shooting/lb_range_button_getinto_hover.dds", Vector4(0, 0, 0, 0)),
				DownImage = Gui.Image("LobbyUI/Shooting/lb_range_button_getinto_down.dds", Vector4(0, 0, 0, 0)),
				DisabledImage = nil,			
			},
			EventClick = function()
				local room_info = state:GetSelfRoomInfo()
				local room_id = 0
				if room_info then
					room_id = room_info.id
				end
				if room_id == 0 then
					RPCBTNDown(7,LobbyMainWin_Header.shooting)
					LobbyMainWin_Header.shooting.IsShowTime = false
					L_WarZone.is_novice = true
					rpc.safecall("shooting_ammo", {pid = ptr_cast(game.CurrentState):GetCharacterId()},L_Shooting.ShowShootingJionWin)
				else
					MessageBox.ShowWithConfirm(lang:GetText("请先退出房间！"), nil)
				end
				gui:PlayAudio("kUIA_CLOSE_UI2")
			end
		},
		
		Gui.Control "time"
		{
			Visible = false,
			Location = Vector2(988, 146),
			Size = Vector2(180, 68),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_normal.dds", Vector4(0, 0, 0, 0)),
			},
			Gui.Control 
			{
				Location = Vector2(29, 23),
				Size = Vector2(28, 28),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_number_bg.dds", Vector4(0, 0, 0, 0)),
				},
			},
			Gui.Control 
			{
				Location = Vector2(49, 23),
				Size = Vector2(28, 28),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_number_bg.dds", Vector4(0, 0, 0, 0)),
				},
			},
			Gui.Control 
			{
				Location = Vector2(95, 23),
				Size = Vector2(28, 28),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_number_bg.dds", Vector4(0, 0, 0, 0)),
				},
			},
			Gui.Control 
			{
				Location = Vector2(115, 23),
				Size = Vector2(28, 28),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_number_bg.dds", Vector4(0, 0, 0, 0)),
				},
			},
			
			Gui.Label
			{
				Size = Vector2(180, 15),
				Location = Vector2(5, 8),
				Text = lang:GetText("离领取奖励还有"),
				TextColor = ARGB(255, 255, 213, 23),
				TextAlign = "kAlignCenterMiddle",
			},
			
			Gui.TimeControl "Event"
			{
				Size = Vector2(5, 5),
				BackgroundColor = ARGB(0, 255, 255, 255),
				EventTimeOut = function(sender, e)
					OLTime = OLTime - 1
					if OLTime >= 0 then
						LobbyMainWin_Header.Event:CleanAll()
						LobbyMainWin_Header.Event:AddTime(1)
						OnUpdateTime()
					end
				end
			},
			
			Gui.TimeControl "Event_Sell"
			{
				Size = Vector2(5, 5),
				BackgroundColor = ARGB(0, 255, 255, 255),
				EventTimeOut = function(sender, e)
					Sell_Time = Sell_Time - 1
					if Sell_Type == 1 then
						if Sell_Time > 0 then
							LobbyMainWin_Header.Event_Sell:CleanAll()
							LobbyMainWin_Header.Event_Sell:AddTime(1)
						else
							Sell_flag = true
							if L_ShoppingMall.main_character_window_ui then
								L_ShoppingMall.main_character_window_ui.time_sell_btn.blink = Sell_flag 
							end
							if L_ShoppingMall.main_props_window_ui then
								L_ShoppingMall.main_props_window_ui.time_sell_btn.blink = Sell_flag 
							end
							if L_Present.main_present_window_ui then
								L_Present.main_present_window_ui.time_sell_btn.blink = Sell_flag
							end
							rpc.safecall("get_compete_buy_time", {pid = ptr_cast(game.CurrentState):GetCharacterId()},
							function(data)
								if data.type == 0 then
									Sell_flag = false
									Sell_Type = 0
								elseif data.type == 1 then
									Sell_flag = false
									if data.time > 0 then
										Sell_Time = data.time
										LobbyMainWin_Header.Event_Sell:CleanAll()
										LobbyMainWin_Header.Event_Sell:AddTime(1)
										Sell_Type = 1
									end	
								elseif data.type == 2 then
									Sell_flag = true
									if data.time > 0 then
										Sell_Time = data.time
										LobbyMainWin_Header.Event_Sell:CleanAll()
										LobbyMainWin_Header.Event_Sell:AddTime(1)
										Sell_Type = 2
									end	
								end
							end)
						end
					elseif Sell_Type == 2 then
						Sell_flag = true
						if Sell_Time > 0 then
							LobbyMainWin_Header.Event_Sell:CleanAll()
							LobbyMainWin_Header.Event_Sell:AddTime(1)
						else
							Sell_flag = false
							if L_ShoppingMall.main_character_window_ui then
								L_ShoppingMall.main_character_window_ui.time_sell_btn.blink = Sell_flag 
							end
							if L_ShoppingMall.main_props_window_ui then
								L_ShoppingMall.main_props_window_ui.time_sell_btn.blink = Sell_flag 
							end
							if L_Present.main_present_window_ui then
								L_Present.main_present_window_ui.time_sell_btn.blink = Sell_flag
							end
						end
					end
				end
			},
		},
		
		Gui.Button "OL"
		{
			Size = Vector2(180, 68),
			Location = Vector2(988, 146),
			BackgroundColor = ARGB(255, 255, 255, 255),
			--Visible = false,
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = nil,
				HoverImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_hover.dds", Vector4(0, 0, 0, 0)),
				DownImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_hover.dds", Vector4(0, 0, 0, 0)),
				DisabledImage = nil,
				TwinkleImage  = Gui.Image("LobbyUI/OL_award/lb_onlinetime_lingqujiangli.dds", Vector4(0, 0, 180, 0)),
			},
			EventClick = function()
				Show_Present()
				RPCBTNDown(3,LobbyMainWin_Header.OL)
				gui:PlayAudio("kUIA_CLOSE_UI2")
			end
		},
		
		Gui.ShaderButton "daily"
		{
			Size = Vector2(180, 64),
			Location = Vector2(825, 147),
			BackgroundColor = ARGB(255, 255, 255, 255),
			ShaderPS = "control_flow",
			--Enable = false,
			Skin = Gui.ShaderButtonSkin
			{
			    ResImage1 = Gui.Image("LobbyUI/effect/lb_onlinetime_flash.dds", Vector4(0, 0, 0, 0)),
                ResImage2 = Gui.Image("LobbyUI/effect/renderuvmapping.tga", Vector4(0, 0, 0, 0)),
                ResImage3 = nil,
				BackgroundImage = Gui.Image("LobbyUI/dailycheck/lb_sign_button01_normal.dds", Vector4(0, 0, 0, 0)),
				HoverImage = Gui.Image("LobbyUI/dailycheck/lb_sign_button01_hover.dds", Vector4(0, 0, 0, 0)),
				DownImage = Gui.Image("LobbyUI/dailycheck/lb_sign_button01_down.dds", Vector4(0, 0, 0, 0)),
				DisabledImage = nil,			
			},
			EventClick = function()
				state.Today_Check = false
				LobbyMainWin_Header.daily.IsShowTime = false
				L_DailyCheck.Show_DailyCheck()
				RPCBTNDown(5,LobbyMainWin_Header.daily)
				gui:PlayAudio("kUIA_CLOSE_UI2")
			end
		},
	},
}

LobbyMainWin_Foot = Gui.Create(LobbyMainWin.LobbyMain_Root)
{
	Gui.Control "LobbyMainWin_Foot_Root"
	{
		Size = Vector2(1150, 75),
		BackgroundColor = ARGB(0, 255, 255, 255),
		Location = Vector2(0, 0),
		--排行榜
		Gui.Button "btn_TopList"
		{
			Size = Vector2(68, 64),
			Location = Vector2(10+1, 15),
			Hint = lang:GetText("排行榜"),
			TextColor = ARGB(255, 42, 42, 42),
			FontSize = 18,
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/xin/lb_menu_rank_normal.tga", Vector4(0, 0, 0, 0)),
				HoverImage = Gui.Image("LobbyUI/xin/lb_menu_rank_hover.tga", Vector4(0, 0, 0, 0)),
				DownImage = Gui.Image("LobbyUI/xin/lb_menu_rank_down.tga", Vector4(0, 0, 0, 0)),
				DisabledImage = Gui.Image("LobbyUI/xin/lb_menu_rank_disabled.tga", Vector4(0, 0, 0, 0)),
			},
			EventClick = function()
				if current_chosse_main_page ~= 10 then
					if LobbyMainWin_Boddy then
						L_TopList.Show(LobbyMainWin_Boddy.LobbyMainWin_Boddy_Root)
					end
					lg:SetLobbyModules(10)
					current_chosse_main_page = 10
					L_TopList.rank_select_page = 1
					gui:PlayAudio("kUIA_CLOSE_UI")
				end
			end
		},		
		--邮件
		Gui.Button "btn_Mail"
		{
			Hint = lang:GetText("邮件"),
			Size = Vector2(68, 64),
			Location = Vector2(79+1, 15),
			--Text = lang:GetText("邮件"),
			TextAlign = "kAlignRightMiddle",
			Padding = Vector4(0, 0, 5, 16),
			TextColor = ARGB(255, 255, 255, 255),
			HighlightTextColor = ARGB(255, 255, 255, 255),
			FontSize = 20,
			blink_shade = false,
			--Enable = false,
			--blink = true,
			--Visible = false,
			--blinkwheelTimer = 1.0,
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/xin/lb_menu_mail_normal.tga", Vector4(0, 0, 0, 0)),
				HoverImage = Gui.Image("LobbyUI/xin/lb_menu_mail_hover.tga", Vector4(0, 0, 0, 0)),
				DownImage = Gui.Image("LobbyUI/xin/lb_menu_mail_down.tga", Vector4(0, 0, 0, 0)),
				DisabledImage = Gui.Image("LobbyUI/xin/lb_menu_mail_disabled.tga", Vector4(0, 0, 0, 0)),
				TwinkleImage  = Gui.Image("LobbyUI/xin/lb_menu_mail_pop.tga", Vector4(0, 0, 0, 0)),
			},
			EventClick = function()
--				HideAll()
				if current_chosse_main_page ~= 1 then
					L_Mail.Type = 0
					if L_Mail.Mail_root_ui then
						L_Mail.Mail_root_ui.In_Box.PushDown = true
						L_Mail.Mail_root_ui.Out_Box.PushDown = false
					end
					if LobbyMainWin_Boddy then
						L_Mail.Show(LobbyMainWin_Boddy.LobbyMainWin_Boddy_Root)
					end
					L_LobbyMain.LobbyMainWin_Foot.btn_Mail.Padding = Vector4(20, 0, 0, 60)
					lg:SetLobbyModules(1)
					current_chosse_main_page = 1
					LobbyMainWin.tips.Visible = false
					L_LobbyMain.LobbyMainWin_Foot.btn_Mail.blink = false
					
					gui:PlayAudio("kUIA_CLOSE_UI")
				end
			end
		},

		--战队
		Gui.Button "btn_FightTeam"
		{
			Size = Vector2(68, 64),
			Location = Vector2(148+1, 15),
			--Text = lang:GetText("战队"),
			TextColor = ARGB(255, 42, 42, 42),
			FontSize = 18,
			Hint = lang:GetText("战队"),
			--Enable = false,
			--Visible = false,
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/xin/lb_menu_squad_normal.tga", Vector4(0, 0, 0, 0)),
				HoverImage = Gui.Image("LobbyUI/xin/lb_menu_squad_hover.tga", Vector4(0, 0, 0, 0)),
				DownImage = Gui.Image("LobbyUI/xin/lb_menu_squad_down.tga", Vector4(0, 0, 0, 0)),
				DisabledImage = Gui.Image("LobbyUI/xin/lb_menu_squad_disabled.tga", Vector4(0, 0, 0, 0)),
			},
			EventClick = function()
--				HideAll()
				if current_chosse_main_page ~= 2 then
					-- if LobbyMainWin_Boddy then
						-- L_FightTeam.Show(LobbyMainWin_Boddy.LobbyMainWin_Boddy_Root)
					-- end
					-- current_chosse_main_page = 2
					-- lg:SetLobbyModules(2)
					-- gui:PlayAudio("kUIA_CLOSE_UI")
					L_FightTeam.is_in_fight_ui = true
					L_WarZone.FightGetBack(L_WarZone.current_state)
				end
			end
		},
		
		--好友
		Gui.Button "btn_Friends"
		{
			Size = Vector2(68, 64),
			Location = Vector2(217, 15),
			--Text = "0   ",
			TextAlign = "kAlignCenterMiddle",
			TextColor = ARGB(255, 255, 255, 255),
			DisabledTextColor = ARGB(255, 255, 255, 255),
			HighlightTextColor = ARGB(255, 255, 255, 255),
			FontSize = 20,
			Enable = true,
			Visible = true,
			blink = false,
			blink_shade = false,
			Hint = lang:GetText("好友"),
			Padding = Vector4(40, 0, 0, 40),
			--blinkwheelTimer = 0.6,
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/xin/lb_menu_contact_normal.tga", Vector4(0, 0, 0, 0)),
				HoverImage = Gui.Image("LobbyUI/xin/lb_menu_contact_hover.tga", Vector4(0, 0, 0, 0)),
				DownImage = Gui.Image("LobbyUI/xin/lb_menu_contact_down.tga", Vector4(0, 0, 0, 0)),
				DisabledImage = Gui.Image("LobbyUI/xin/lb_menu_contact_disabled.tga", Vector4(0, 0, 0, 0)),
				TwinkleImage  = Gui.Image("LobbyUI/xin/lb_menu_contact_pop.tga", Vector4(0, 0, 0, 0)),
			},
			EventClick = function()
				--HideAll()
				--MessageBox.ShowWithConfirmCancel(lang:GetText("还在制作中？"), nil)
				--lg:SetLobbyModules(3)
				LobbyMainWin.tips.Visible = false
				if FriendAdd then
					FriendName = FriendAdd.name
					FriendId = FriendAdd.id
					--FriendAdd = FriendAdd.next
					L_Friends.ShowInvitedCreateWin(gui)
				elseif GroupAdd then
					GroupAddName = GroupAdd.name
					GroupAddId = GroupAdd.id
					--GroupAdd = GroupAdd.next
					L_Friends.ShowGroupInvitedCreateWin(gui)
				elseif TepGroupAdd then
					TepGroupAddName = TepGroupAdd.groupname
					TepAddName = TepGroupAdd.name
					TepGroupAddId = TepGroupAdd.group_id
					--TepGroupAdd = TepGroupAdd.next
					L_Friends.ShowTepGroupInvitedCreateWin(gui)
				elseif 1 then
					if L_LobbyMain.LobbyMainWin.ctr_FriendsWin_root_Parent.Visible == false then
						L_Friends.Show()
						L_LobbyMain.LobbyMainWin_Foot.btn_Friends.Enable = false
						L_LobbyMain.GetPartnerList()
					else	
						L_Friends.Hide()
					end
				end
			end,
		},

		--战区
		Gui.Button "btn_WarZone"
		{
			Size = Vector2(172, 76),
			Location = Vector2(304, 0),
--			Text = lang:GetText("战区"),
			TextColor = ARGB(255, 42, 42, 42),
			FontSize = 24,
			Margin = Vector4(10, 10, 10, 10),
			--Hint = lang:GetText("战区"),
			PushDown = true,
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/lb_menu_battlefield_normal.tga", Vector4(20, 20, 20, 20)),
				HoverImage = Gui.Image("LobbyUI/lb_menu_battlefield_hover.tga", Vector4(20, 20, 20, 20)),
				DownImage = Gui.Image("LobbyUI/lb_menu_battlefield_down.tga", Vector4(20, 20, 20, 20)),
				DisabledImage = Gui.Image("LobbyUI/lb_menu_battlefield_disabled.tga", Vector4(20, 20, 20, 20)),
			},
			EventClick = function()
				if current_chosse_main_page ~= 5 then
					--HideAll()
					if LobbyMainWin_Boddy then
						L_WarZone.Show(LobbyMainWin_Boddy.LobbyMainWin_Boddy_Root)
					end
					lg:SetLobbyModules(5)
					current_chosse_main_page = 5
					-- if L_LobbyMain.LobbyMainWin.new_daoju.Visible == true then
						-- L_LobbyMain.LobbyMainWin.new_daoju.Visible = false
						-- L_PushCmd.New_daoju = 0
					-- end	
					-- if L_LobbyMain.LobbyMainWin.new_jiaose.Visible == true then
						-- L_LobbyMain.LobbyMainWin.new_jiaose.Visible = false
						-- L_PushCmd.New_jiaose = 0
					-- end
					gui:PlayAudio("kUIA_CLOSE_UI")
				end
			end
		},

		--仓库
		Gui.Button "btn_Characters"
		{
			Size = Vector2(164, 76),
			Location = Vector2(476, 0),
--			Text = lang:GetText("角色管理"),
			TextColor = ARGB(255, 42, 42, 42),
			FontSize = 24,
			--Hint = lang:GetText("角色管理"),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/lb_menu_manage_normal.tga", Vector4(0, 0, 0, 0)),
				HoverImage = Gui.Image("LobbyUI/lb_menu_manage_hover.tga", Vector4(0, 0, 0, 0)),
				DownImage = Gui.Image("LobbyUI/lb_menu_manage_down.tga", Vector4(0, 0, 0, 0)),
				DisabledImage = Gui.Image("LobbyUI/lb_menu_manage_disabled.tga", Vector4(0, 0, 0, 0)),
			},
			EventClick = function()
				if current_chosse_main_page ~= 6 then
					--HideAll()
					if LobbyMainWin_Boddy then
						L_Characters.Show(LobbyMainWin_Boddy.LobbyMainWin_Boddy_Root)
					end
					InitCharactersRPCInfo()
					lg:SetLobbyModules(6)
					current_chosse_main_page = 6
					L_Characters.SynchronousClassButton()
					L_Characters.RestAllCharacterBagItemBoxBtn()
					L_Characters.FillPropInfo(-1)
					L_LobbyMain.On_Invite_State = false
					if L_LobbyMain.LobbyMainWin.new1.Visible == true then
						L_LobbyMain.LobbyMainWin.new1:Show()
						L_LobbyMain.LobbyMainWin.new1.Location = Vector2(862-30, 810)
						L_LobbyMain.LobbyMainWin.new1.NormLocation = Vector2(862-30, 810)
						L_LobbyMain.LobbyMainWin.new1.UseTimer = true
						L_LobbyMain.LobbyMainWin.new1.DisplayTime = 0.5
					end	
					if L_PushCmd.New_jiaose == 1 then
						L_LobbyMain.LobbyMainWin.new_jiaose.Location = Vector2(480, 220)
						L_LobbyMain.LobbyMainWin.new_jiaose.NormLocation = Vector2(480, 220)
						L_LobbyMain.LobbyMainWin.new_jiaose.UseTimer = false
						L_LobbyMain.LobbyMainWin.new_jiaose.Visible = true
						if L_Characters.main_props_window_ui and L_Characters.main_props_window_ui.btn_Characters.PushDown == true then
							if L_LobbyMain.LobbyMainWin.new_jiaose.Visible == true then
								L_LobbyMain.LobbyMainWin.new_jiaose:Show()
								L_LobbyMain.LobbyMainWin.new_jiaose.UseTimer = true
								L_LobbyMain.LobbyMainWin.new_jiaose.DisplayTime = 0.5
								L_PushCmd.New_jiaose = 0
							end	
						end
					end	
					if L_PushCmd.New_daoju == 1 then
						L_LobbyMain.LobbyMainWin.new_daoju.Location = Vector2(760, 220)
						L_LobbyMain.LobbyMainWin.new_daoju.NormLocation = Vector2(760, 220)
						L_LobbyMain.LobbyMainWin.new_daoju.UseTimer = false
						L_LobbyMain.LobbyMainWin.new_daoju.Visible = true
						if L_Characters.main_props_window_ui and L_Characters.main_character_window_ui.btn_Property.PushDown == true then
							if L_LobbyMain.LobbyMainWin.new_daoju.Visible == true then
								L_LobbyMain.LobbyMainWin.new_daoju:Show()
								L_LobbyMain.LobbyMainWin.new_daoju.UseTimer = true
								L_LobbyMain.LobbyMainWin.new_daoju.DisplayTime = 0.5
								L_PushCmd.New_daoju = 0
							end	
						end						
					end	
					gui:PlayAudio("kUIA_CLOSE_UI")
				end
			end
		},

		--商城
		Gui.Button "btn_ShoppingMall"
		{
			Size = Vector2(172, 76),
			Location = Vector2(642, 0),
			--Text = lang:GetText("商城"),
			TextColor = ARGB(255, 42, 42, 42),
			--Hint = lang:GetText("商城"),
			FontSize = 18,
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/lb_menu_shop_normal.tga", Vector4(0, 0, 0, 0)),
				HoverImage = Gui.Image("LobbyUI/lb_menu_shop_hover.tga", Vector4(0, 0, 0, 0)),
				DownImage = Gui.Image("LobbyUI/lb_menu_shop_down.tga", Vector4(0, 0, 0, 0)),
				DisabledImage = Gui.Image("LobbyUI/lb_menu_shop_disabled.tga", Vector4(0, 0, 0, 0)),
			},
			EventClick = function()
				if current_chosse_main_page ~= 7 then
					if LobbyMainWin_Boddy then
						L_ShoppingMall.Show(LobbyMainWin_Boddy.LobbyMainWin_Boddy_Root)
					end
					InitShoppingMallRPCInfo()
					lg:SetLobbyModules(7)
					current_chosse_main_page = 7
					L_ShoppingMall.RestAllShoppingMallItemBoxBtn()
					L_ShoppingMall.SynchronousClassButton()
					FillShoppingCart()
					L_ShoppingMall.RestAllCharacterBagItemBoxBtn()
					FillClassBag(ptr_cast(game.CurrentState):GetCharacterId(), current_choose_class)
					L_ShoppingMall.FillPropInfo(-1)
					L_LobbyMain.On_Invite_State = false
					-- if L_LobbyMain.LobbyMainWin.new_daoju.Visible == true then
						-- L_LobbyMain.LobbyMainWin.new_daoju.Visible = false
						-- L_PushCmd.New_daoju = 0
					-- end	
					-- if L_LobbyMain.LobbyMainWin.new_jiaose.Visible == true then
						-- L_LobbyMain.LobbyMainWin.new_jiaose.Visible = false
						-- L_PushCmd.New_jiaose = 0
					-- end	
					gui:PlayAudio("kUIA_CLOSE_UI")
				end
			end
		},
		
		--幸运礼盒
		Gui.Button "btn_present"
		{
			Size = Vector2(104, 64),
			Location = Vector2(861-35, 15),
			--Text = lang:GetText("任务"),
			TextColor = ARGB(255, 42, 42, 42),
			FontSize = 18,
			Enable = true,
			Visible = true,
			--blinkwheelTimer = 0.6,
			blink = false,
			blink_shade = false,
			Hint = lang:GetText("彩盒"),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/xin/lb_menu_gift_normal.tga", Vector4(0, 0, 0, 0)),
				HoverImage = Gui.Image("LobbyUI/xin/lb_menu_gift_hover.tga", Vector4(0, 0, 0, 0)),
				DownImage = Gui.Image("LobbyUI/xin/lb_menu_gift_down.tga", Vector4(0, 0, 0, 0)),
				DisabledImage = Gui.Image("LobbyUI/xin/lb_menu_gift_disabled.tga", Vector4(0, 0, 0, 0)),
				TwinkleImage  = Gui.Image("LobbyUI/xin/lb_menu_gift_btn.tga", Vector4(0, 0, 0, 0)),
			},
			EventClick = function()
				if GetNowModuleState(module_state.Present.state,9,lang:GetText("彩盒"),lang:GetText("战斗中成长")) == false then
					return
				end
				L_Present.Show(L_LobbyMain.LobbyMainWin_Boddy.LobbyMainWin_Boddy_Root)
				RPCBTNDown(4,LobbyMainWin_Foot.btn_present)
				L_LobbyMain.On_Invite_State = false
				LobbyMainWin_Foot.btn_present.PushDown = true
				gui:PlayAudio("kUIA_CLOSE_UI")
			end
		},

		--任务
		Gui.Button "btn_Mission"
		{
			Size = Vector2(104, 64),
			Location = Vector2(966-35, 15),
			--Text = lang:GetText("任务"),
			TextColor = ARGB(255, 42, 42, 42),
			FontSize = 18,
			--blinkwheelTimer = 0.6,
			blink = false,
			--Enable = false,
			Visible = true,
			blink_shade = false,
			Hint = lang:GetText("任务"),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/xin/lb_menu_mission_normal.tga", Vector4(0, 0, 0, 0)),
				HoverImage = Gui.Image("LobbyUI/xin/lb_menu_mission_hover.tga", Vector4(0, 0, 0, 0)),
				DownImage = Gui.Image("LobbyUI/xin/lb_menu_mission_down.tga", Vector4(0, 0, 0, 0)),
				DisabledImage = Gui.Image("LobbyUI/xin/lb_menu_mission_disabled.tga", Vector4(0, 0, 0, 0)),
				TwinkleImage  = Gui.Image("LobbyUI/xin/lb_menu_mission_btn.tga", Vector4(0, 0, 0, 0)),
			},
			EventClick = function()
				if current_chosse_main_page ~= 8 then
					HideAll()
					LobbyMainWin_Foot.btn_Mission.PushDown = true
					lg:SetLobbyModules(8)
					current_chosse_main_page = 8
					L_Mission.mode_type = 3
					L_Mission.Show(LobbyMainWin_Boddy.LobbyMainWin_Boddy_Root)
					RPCBTNDown(0,LobbyMainWin_Foot.btn_Mission)
					--LobbyMainWin.new.Visible = false
					if L_LobbyMain.LobbyMainWin.new.Visible == true then
						L_LobbyMain.LobbyMainWin.new.UseTimer = true
						L_LobbyMain.LobbyMainWin.new.DisplayTime = 0.5
						L_LobbyMain.LobbyMainWin.new:Show()
					end
					gui:PlayAudio("kUIA_CLOSE_UI")
				end
			end
		},

		--合成
		Gui.Button "btn_Compose"
		{
			Size = Vector2(104, 64),
			Location = Vector2(1070-35, 15),
			TextColor = ARGB(255, 42, 42, 42),
			--blinkwheelTimer = 0.6,
			Hint = lang:GetText("合成"),
			blink = false,
			Enable = true,
			blink_shade = false,
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/xin/lb_menu_tune_normal.tga", Vector4(0, 0, 0, 0)),
				HoverImage = Gui.Image("LobbyUI/xin/lb_menu_tune_hover.tga", Vector4(0, 0, 0, 0)),
				DownImage = Gui.Image("LobbyUI/xin/lb_menu_tune_down.tga", Vector4(0, 0, 0, 0)),
				DisabledImage = Gui.Image("LobbyUI/xin/lb_menu_tune_disabled.tga", Vector4(0, 0, 0, 0)),
				TwinkleImage  = Gui.Image("LobbyUI/xin/lb_menu_rank_btn.tga", Vector4(0, 0, 0, 0)),
			},
			EventClick = function()
				if GetNowModuleState(module_state.Compose.state,4,lang:GetText("合成系统"),lang:GetText("新兵训练2")) == false then
					return
				end
				if current_chosse_main_page ~= 9 then
					HideAll()
					LobbyMainWin_Foot.btn_Compose.PushDown = true
					lg:SetLobbyModules(9)
					current_chosse_main_page = 9
					L_Compose.Show(LobbyMainWin_Boddy.LobbyMainWin_Boddy_Root)
					RPCBTNDown(2,LobbyMainWin_Foot.btn_Compose)
					L_LobbyMain.On_Invite_State = false
					gui:PlayAudio("kUIA_CLOSE_UI")
				end
			end
		},
	},
}

function ShowLobbyMainWindow()
	my_flag = 0
	local args = {pid = ptr_cast(game.CurrentState):GetCharacterId()}
	rpc.safecall("get_module_status", args, 
	function(data)
		if data.warning then
			MessageBox.ShowWithTimer(1,data.warning)
		else
			module_state = data.list
			SetmoduleState()
		end
	end)
	LobbyMainWin.LobbyMain_Root_Parent.Parent = gui
	LobbyMainWin.LobbyMain_Root.Visible = true
	
	LobbyMainWin_Header.daily.IsShowTime = state.Today_Check
	
	if state.Is_Need_Train == true then
		create_training_ui.training_window.Visible = true
		create_training_ui.ctrl_training.Parent = gui
		create_training_ui.ctrl_training.Visible = true
		--create_training_ui.bbb.Parent = gui
		--create_training_ui.bbb.Visible = true
		
		state.Is_Need_Train = false
	else
		create_training_ui.training_window.Visible = false
		create_training_ui.ctrl_training.Parent = nil
		create_training_ui.ctrl_training.Visible = false
		-- create_training_ui.bbb.Parent = nil
		-- create_training_ui.bbb.Visible = false
	end
	
	if PersonalInfo_data == nil then
		rpc.safecallload("personal_simple", {uid = ptr_cast(game.CurrentState):GetUserId(), pid = ptr_cast(game.CurrentState):GetCharacterId()},
		function (data)
			if data then
				PersonalInfo_data = data
				L_WarZone.Show(LobbyMainWin_Boddy.LobbyMainWin_Boddy_Root)
			end
		end)
	else
		L_WarZone.Show(LobbyMainWin_Boddy.LobbyMainWin_Boddy_Root)
	end
	
	L_LobbyMain.ReadlyState(true)
	if config:GetUISystemFlag(2) == 0 then
		LobbyMainWin_Header.b_SecondCode.Visible = false
	else
		LobbyMainWin_Header.b_SecondCode.Visible = true
	end
end

function HideLobbyMainWindow()
	LobbyMainWin.LobbyMain_Root_Parent.Parent = nil
	
	if create_training_ui then
		create_training_ui.training_window.Visible = false
		create_training_ui.ctrl_training.Parent = nil
		create_training_ui.ctrl_training.Visible = false
	end
	
	if create_shimingzhi_ui then
		create_shimingzhi_ui.Close()
		create_shimingzhi_ui = nil
	end
	
	HideDlbWindow()
	
	gmz_window.root.Parent = nil
	team_gmz_window.root.Parent = nil
	L_PersonalInfo.Hide()
	L_PersonalInfo.HidePopupWindow()
	L_ShoppingMall.CloseShoppingCarBuyWin()
	L_ShoppingMall.CloseBuyWin()
	L_Friends.HideAll()--好友聊天
	HideModuleNewOpenWin()
	if L_ReleaseProfession then
		if L_ReleaseProfession.btn_release_ok then
			L_ReleaseProfession.btn_release_ok.Visible = false
		end
		if L_ReleaseProfession.flashplayer then
			L_ReleaseProfession.flashplayer:CleanData()
		end
		L_ReleaseProfession.Hide()
	end
	L_FightTeam.FightTeamHideAll()
	L_ShoppingMall.Hide()
	L_Characters.Hide()
	lcSysMsgBar.Parent = nil
end

function AlignUI()
	if dlb_window_ui then
		Gui.Align(dlb_window_ui.root, 0.5, 0.5)
		Gui.Align(dlb_window_ui.bg_root, 0.5, 0.5)
	end
	Gui.Align(LobbyMainWin.LobbyMain_Root_Parent, 0.5, 0.5)
	Gui.Align(LobbyMainWin_Header.LobbyMainWin_Header_Root, 0.5, 2.0 / 75.0)
	Gui.Align(LobbyMainWin_Boddy.LobbyMainWin_Boddy_Root, 0.5, 23.0 / 31.0)
	Gui.Align(LobbyMainWin_Foot.LobbyMainWin_Foot_Root, 0.5, 257.0 / 260.0)
	if create_training_ui then
		Gui.Align(create_training_ui.ctrl_training, 0.5, 0.5)
	end
	L_Friends.AlignUI()
	if  L_FightTeam.request_list_ui then
		Gui.Align(L_FightTeam.request_list_ui.root, 0.5,0.5)
	end
	ModuleNewOpenWinAlignUI()
end

function CommonInitLobby()
	addressRequestCallbacks = {}
	addressRequestNames = {}
	addressRequestCounter = 0
	
	local state = ptr_cast(game.CurrentState)
	if state then		
		state.EventChannelLeave = ChannelLeave
		--state.EventChannelEnter = CreatChannllist
		state.EventChannelClientListChanged = RefreshChannelPlayerList
		state.EventAddressArrived = OnAddressArrived
		state.EventServerCmd = L_PushCmd.OnServerCmd
		state.EventQueryExpiredItem = QueryExpiredItem
		state.EventCreatGroup = CreatTepGroup
		state.EventInviteGroup = InviteGroup
		state.EventGetGroupMember = GetGroupMember
		state.EventForcelLeave = ForceLeave
		state.EventFocusLost = function(sender, e)
			if L_Characters.tuozhuai then
				L_Characters.reset()
			end
			if L_Compose.tuozhuai then
				L_Compose.reset(nil,true)
			end
			if L_ShoppingMall.tuozhuai then
				L_ShoppingMall.reset()
			end
		end
		state.EventNeedAutoPassword = function(sender, e)
			L_PassWordBox.Show(gui, state, nil, 2)
		end
		state.EventOnNeedFCMNotified = OnNeedFCMNotified
	else
		MessageBox.ShowError("Error: No lobby")
	end

	for index, md in ipairs(LobbyModules) do
		md.Initialize()
	end
	
	gui.EventAvatarSwitched = OnSwitchAvatar

	if create_training_ui then
		create_training_ui.training_window.Parent = gui
	end
	create_training_ui = Gui.Create(win_parent)(create_training_window)
	
	ShowLobbyMainWindow()
	CommonUtility.cumulate = true
end

function GetCharacterHeadImage(data)
	bufflist = data.buff_list
	local headIcon = data.head_image	
	if headIcon ~= nil then
		headSkin = Gui.ControlSkin{ BackgroundImage = Gui.Image("LobbyUI/persionalInfo/HeadPic/lb_info_image"..headIcon..".dds", Vector4(14, 14, 14, 14)),}
		LobbyMainWin_Header.img_UserHeadIcon.Skin = headSkin
	end
	
	if data.maxFightNum ~= "" then
		ShowFightnums(LobbyMainWin_Header.UserNickName_layout,data.maxFightNum)
	end

	LobbyMainWin_Header.buff_layout:OnDestroy()
	LobbyMainWin.buff_layout_1:OnDestroy()
	
	for i,v in ipairs(bufflist) do
		if i < 6 then
			local buffInfo = L_PersonalInfo.SpawnNewBuff(v,i)
			buffInfo.LBuff.Parent = LobbyMainWin_Header.buff_layout
		else
			break
		end
	end
	
	for i,v in ipairs(bufflist) do
		local buffInfo = L_PersonalInfo.SpawnNewBuff(v,i)
		buffInfo.LBuff.Parent = LobbyMainWin.buff_layout_1
	end
end

function GetHeadImage()			
	GetCharacterHeadImage(PersonalInfo_data)
end
	
--大厅UI入口
function OnEnterLobby()
	local state = ptr_cast(game.CurrentState)
	if state then
		pid = state:GetCharacterId()
	end
	module_state_Onuse = state:GetModuleState()

	CommonInitLobby()
	AlignUI()
	
	RequestLevelInfo()
	
	LobbyState = "lobby"
	WeaponEntrance = 0
	
	lcSysMsgBar = state.SysMsgBar
	lcSysMsgBar.Parent = LobbyMainWin.lb_Announcement
	lcSysMsgBar.Size = Vector2(390, 35)
	lcSysMsgBar.Dock = "kDockFill"
	lcSysMsgBar.EventHornMessage = ReceiveHorn
	lcSysMsgBar.EventSpeakerMessage = ReceiveSpraker
	lcSysMsgBar.EventSeverPresent = SeverPresent
	
	GetFriendsList()
	GerGroupList()
--	L_Friends.GetTeamInfo()
--	L_LobbyMain.LobbyMainWin_Header.ctr_AD:DeleteAllImage()
--	L_LobbyMain.LobbyMainWin_Header.ctr_AD:AddFrame(Gui.Image("LobbyUI/lb_top_ad09.dds",Vector4(0, 0, 0, 0)))
	rpc.safecall("expire_bubble",{pid = ptr_cast(game.CurrentState):GetCharacterId()},nil)
	InitCharactersRPCInfo()
	
	if Timer_control_ui then
		Timer_control_ui = Gui.Create(gui)(Timer_control)
	end
end

function OnRestoreLobby()
	if L_MainMenu.menuState == "" then
		OnEnterLobby()
	else
		local state = ptr_cast(game.CurrentState)
		CommonInitLobby()
	end
	
	lcSysMsgBar = state.SysMsgBar
	lcSysMsgBar.Parent = LobbyMainWin.lb_Announcement
	lcSysMsgBar.Size = Vector2(390, 35)
	lcSysMsgBar.Dock = "kDockFill"
	
	lcSysMsgBar.EventHornMessage = ReceiveHorn
	lcSysMsgBar.EventSpeakerMessage = ReceiveSpraker
	lcSysMsgBar.EventSeverPresent = SeverPresent
	
	if create_shimingzhi_ui then
		create_shimingzhi_ui.Close()
		create_shimingzhi_ui = nil
	end

	AlignUI()
end

function OnLogoutCharacter()
	for index, md in ipairs(LobbyModules) do
		md.Finalize()
	end
	InitAllInfo()
end

function OnLeaveLobby()
	--Close any unclosed modal window (in case of getting disconnected)
	rpc.clear()
	local state = ptr_cast(game.CurrentState, "Client.StateLobby")
	state.EventServerCmd = nil
	state.EventChannelClientListChanged = nil
	state.EventAddressArrived = nil
	state.EventQueryExpiredItem = nil
	state.EventNeedAutoPassword = nil
	state.AutoPassword = ""
	state:CancelAutoChange()
	state.EventOnNeedFCMNotified = nil

	gui.EventAvatarSwitched = nil
	HideLobbyMainWindow()
end

LobbyState = "lobby"

--请求等级数据
function RequestLevelInfo()
	rpc.safecall("rank_list", nil,
	function (data)
		if data then
			LevelInfo_rpc_data = data.rank
		end
		L_MessageBox.CloseWaiter()
		FillPersonalInfo()
	end)
end


--填充帐号信息
function FillPersonalInfo()
	--L_Loading.Show()
	rpc.safecallload("personal_simple", {uid = state:GetUserId(), pid = state:GetCharacterId()},
	function (data)
		if data then
			PersonalInfo_data = data
			LobbyMainWin_Header.lb_UserLevel_AnoldState.Location = Vector2(198, 36)
			LobbyMainWin_Header.lb_UserLevel_TenState.Location = Vector2(184, 36)
			FillLevel(data.level,LobbyMainWin_Header,data.exp)		
			LobbyMainWin_Header.lb_UserName.Text = data.name
			LobbyMainWin_Header.lb_Version.Text = string.format("%s", game.Version)
			LobbyMainWin_Header.lb_LeiPoint.Text = data.newCR
			LobbyMainWin_Header.lb_GP.Text = data.newGP
			L_Vip.Viplevel = data.isvip
			L_Vip.Vipexp = data.vipExp
			L_Vip.VipDay = math.floor(data.vipLeftMins/60/24)
			L_Vip.now_box = data.currentyEXPItem + 1
			local tempbar = 0
			local temp = 0
			if L_Vip.Viplevel == 9 then
				L_Vip.Viplevel = 8
			end
			LobbyMainWin.ctr_VIP.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_bg_0"..L_Vip.Viplevel..".dds", Vector4(0, 0, 0, 0)),}
			LobbyMainWin.ctr_VIP_num.Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_button_0"..L_Vip.Viplevel.."_normal.dds", Vector4(0, 0, 0, 0)),
				HoverImage = Gui.Image("LobbyUI/vip/vip/VIP_button_0"..L_Vip.Viplevel.."_hover.dds", Vector4(0, 0, 0, 0)),
				DownImage = Gui.Image("LobbyUI/vip/vip/VIP_button_0"..L_Vip.Viplevel.."_down.dds", Vector4(0, 0, 0, 0)),
				DisabledImage = Gui.Image("LobbyUI/vip/vip/VIP_button_0"..L_Vip.Viplevel.."_disabled.dds", Vector4(0, 0, 0, 0)),
			}
			LobbyMainWin.lbl_left_day.Text = lang:GetText("剩余")..L_Vip.VipDay..lang:GetText("天")
			
			if L_Vip.Viplevel == 7 then
				LobbyMainWin.l_viplevel.Text = lang:GetText("当前等级银钻")
			elseif L_Vip.Viplevel == 8 then
				LobbyMainWin.l_viplevel.Text = lang:GetText("当前等级金钻")
			else
				LobbyMainWin.l_viplevel.Text = lang:GetText("当前等级VIP")..L_Vip.Viplevel
			end
			LobbyMainWin.ctr_VIP_num_Tips.Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_button_0"..L_Vip.Viplevel.."_normal.dds", Vector4(0, 0, 0, 0)),
				HoverImage = Gui.Image("LobbyUI/vip/vip/VIP_button_0"..L_Vip.Viplevel.."_hover.dds", Vector4(0, 0, 0, 0)),
				DownImage = Gui.Image("LobbyUI/vip/vip/VIP_button_0"..L_Vip.Viplevel.."_down.dds", Vector4(0, 0, 0, 0)),
				DisabledImage = Gui.Image("LobbyUI/vip/vip/VIP_button_0"..L_Vip.Viplevel.."_disabled.dds", Vector4(0, 0, 0, 0)),
			}
			LobbyMainWin.ctr_VIP_Tips.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_bg_0"..L_Vip.Viplevel..".dds", Vector4(0, 0, 0, 0)),}
			if L_Vip.now_box == 15 then
				LobbyMainWin.lb_vip_text.Text = lang:GetText("已达到最高级")
				LobbyMainWin.exp_bar.Size = Vector2(286,25)
			elseif L_Vip.Viplevel == 8 then
				if L_Vip.now_box == 1 then
					temp = L_Vip.vip_box_exp[L_Vip.now_box] - L_Vip.Vipexp
					if (L_Vip.vip_box_exp[L_Vip.now_box] - L_Vip.Vipexp) <= 0 then
						temp = 0
					end
					LobbyMainWin.lb_vip_text.Text = lang:GetText("下一个宝箱需要经验：")..temp	
				
					if (data.vipExp - L_Vip.vip_exp[L_Vip.Viplevel]) / (L_Vip.vip_box_exp[L_Vip.now_box] - L_Vip.vip_exp[L_Vip.Viplevel]) > 1 then
						tempbar = 1
					else
						tempbar = (data.vipExp - L_Vip.vip_exp[L_Vip.Viplevel]) / (L_Vip.vip_box_exp[L_Vip.now_box] - L_Vip.vip_exp[L_Vip.Viplevel])
					end
					LobbyMainWin.exp_bar.Size = Vector2(tempbar*286,25)
				elseif L_Vip.now_box == 15 then
					LobbyMainWin.lb_vip_text.Text = lang:GetText("下一级需要经验：0")
					LobbyMainWin.exp_bar.Size = Vector2(286,25)
				else
					temp = L_Vip.vip_box_exp[L_Vip.now_box] - L_Vip.Vipexp
					if (L_Vip.vip_box_exp[L_Vip.now_box] - L_Vip.Vipexp) < 0 then
						temp = 0
					end
					
					LobbyMainWin.lb_vip_text.Text = lang:GetText("下一个宝箱需要经验：")..temp	
				
					if (data.vipExp - L_Vip.vip_box_exp[L_Vip.now_box-1]) / (L_Vip.vip_box_exp[L_Vip.now_box] - L_Vip.vip_box_exp[L_Vip.now_box-1]) > 1 then
						tempbar = 1
					else
						tempbar = (data.vipExp - L_Vip.vip_box_exp[L_Vip.now_box-1]) / (L_Vip.vip_box_exp[L_Vip.now_box] - L_Vip.vip_box_exp[L_Vip.now_box-1])
					end
					LobbyMainWin.exp_bar.Size = Vector2(tempbar*286,25)
				end
				--LobbyMainWin.exp_bar.Size = Vector2((1 - ((L_Vip.vip_exp[L_Vip.Viplevel+1]-L_Vip.Vipexp) / (L_Vip.vip_exp[L_Vip.Viplevel+1] - L_Vip.vip_exp[L_Vip.Viplevel])))*286,25)
			elseif L_Vip.Viplevel == 0 then
				LobbyMainWin.lb_vip_text.Text = lang:GetText("下一级需要经验：")
				LobbyMainWin.exp_bar.Size = Vector2(0,25)
			else
				local temp = (L_Vip.vip_exp[L_Vip.Viplevel+1] - L_Vip.Vipexp) 
				if (L_Vip.vip_exp[L_Vip.Viplevel+1] - L_Vip.Vipexp) < 0 then
					temp = 0
				end
				LobbyMainWin.lb_vip_text.Text = lang:GetText("下一级需要经验：")..temp	
				LobbyMainWin.exp_bar.Size = Vector2((1 - ((L_Vip.vip_exp[L_Vip.Viplevel+1]-L_Vip.Vipexp) / (L_Vip.vip_exp[L_Vip.Viplevel+1] - L_Vip.vip_exp[L_Vip.Viplevel])))*286,25)
			end
		end
					
		if data and create_training_ui then
			create_training_ui.btn_ok.Enable = true
			create_training_ui.btn_cancel.Enable = true
		end
		GetHeadImage()
		--L_Loading.Hide()
		SetVipTime(L_Vip.Viplevel,data.leftMinites)
	end)
end

function FillClassBag(p_id, c_id)
	local user_bag_weaponinfo = {
								L_Characters.user_bag_info_ui.ib_primary_weapon,
								L_Characters.user_bag_info_ui.ib_secondary_weapon,
								L_Characters.user_bag_info_ui.ib_melee_weapons,
								L_Characters.user_bag_info_ui.ib_grenade,
								L_Characters.user_bag_info_ui.ib_no_use,
								L_Characters.user_bag_info_ui.ib_hat,
								L_Characters.user_bag_info_ui.ib_last,
							}
							
	for index in pairs(user_bag_weaponinfo) do
		local ibbtn = ptr_cast(L_Characters.user_bag_info_ui.ctrl_ib_container:GetChildByIndex(index-1))
		local b_denote = ptr_cast(ibbtn:GetChildByIndex(2))
		user_bag_weaponinfo[index].Loading = true
		user_bag_weaponinfo[index].ItemIconPastDue = nil
		b_denote.Visible = false
		user_bag_weaponinfo[index].PBVisible = false
		user_bag_weaponinfo[index].ItemLevel = nil
	end
	
	rpc.safecall("character_get", {pid = p_id, cid = c_id},
	
	function (data)
		if data.enable == 0 then
			Message.ShowError(lang:GetText("该角色还未解锁!"))
		end
		if current_chosse_main_page == 12 then
			L_TopList.rpc_bag_data = nil
			L_TopList.rpc_bag_data = data
			L_TopList.FillBag()
		end
		
		if p_id ~= ptr_cast(game.CurrentState):GetCharacterId() then
			OtherCharactersInfo_rpc_data = data
			L_MessageBox.CloseWaiter()
			InitAvatarPreviewInfo(p_id, c_id)
			ChangeBG(L_PersonalInfo.main_character_window_ui,data.fightnum, true)
			Characters_BagInfo_rpc_data = data
			CharactersInfo_rpc_data = data
			Fill_ui_des_bag(data)
			-- L_TopList.rpc_bag_data = data
			-- L_TopList.FillBag()
			return
		end
		ChangeBG(L_PersonalInfo.main_character_window_ui,data.fightnum, true)
		ChangeBG(L_Characters.avatart_main_ui,data.fightnum, true)
		ChangeBG(L_ShoppingMall.avatart_main_ui,data.fightnum, false)
		Characters_BagInfo_rpc_data = data
		CharactersInfo_rpc_data = data
		Fill_ui_des_bag(data)
		-- L_TopList.rpc_bag_data = data
		-- L_TopList.FillBag()
		local weapons = data.items.weapons			--武器
		local costumes = data.items.costume			--装备
		local v = nil
		for index in pairs(weapons) do
			v = index
		end
		for index in pairs(costumes) do
			weapons[index + v] = costumes[index]
		end
		if weapons then
			if L_Characters.user_bag_ui and L_Characters.user_bag_info_ui then
				for index in pairs(user_bag_weaponinfo) do
					if weapons[index] then
						if weapons[index].name then
							-- 颜色
							local ibbtn = nil
							local b_denote = nil
							local b_star = nil
							if index == 3 then
								ibbtn = ptr_cast(L_Characters.user_bag_info_ui.ctrl_ib_container:GetChildByIndex(3))
								b_denote = ptr_cast(ibbtn:GetChildByIndex(2))
							elseif index == 4 then
								ibbtn = ptr_cast(L_Characters.user_bag_info_ui.ctrl_ib_container:GetChildByIndex(2))
								b_denote = ptr_cast(ibbtn:GetChildByIndex(2))
							else
								ibbtn = ptr_cast(L_Characters.user_bag_info_ui.ctrl_ib_container:GetChildByIndex(index - 1))
								b_denote = ptr_cast(ibbtn:GetChildByIndex(2))
								b_star = ptr_cast(ibbtn:GetChildByIndex(3))
							end
							if weapons[index].color >= 1 and weapons[index].color <= 8 then
								if index == 3 or index == 4 then
									user_bag_weaponinfo[index].ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..weapons[index].name.."_Small_"..weapons[index].color..".tga")
								else
									user_bag_weaponinfo[index].ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..weapons[index].name.."_"..weapons[index].color..".tga")
								end
							else
								if index == 3 or index == 4 then
									user_bag_weaponinfo[index].ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..weapons[index].name.."_Small.tga")
								else
									user_bag_weaponinfo[index].ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..weapons[index].name..".tga")
								end
							end

							user_bag_weaponinfo[index].Enable = true
							
							-- vip && minutes
							if weapons[index].common.is_vip > 0 then
								user_bag_weaponinfo[index].ItemIconVIP = Gui.Icon("LobbyUI/ShoppingMall/vip"..weapons[index].common.is_vip..".dds")
							else
								user_bag_weaponinfo[index].ItemIconVIP = nil
							end
							
							--rarelevel
							if weapons[index].common.rareLevel then
								user_bag_weaponinfo[index].ItemLevel = Skin.rarelevel[math.ceil(weapons[index].common.rareLevel/25)]
							end
							
							if weapons[index].unit_type == 2 and weapons[index].common.minutes_left == 0 then
								if index == 1 or index == 2 then
									user_bag_weaponinfo[index].ItemIconPastDue = Gui.Icon("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche1_guoqi1.dds")
								elseif index == 3 or index == 4 or index == 6 or index == 7 then
									user_bag_weaponinfo[index].ItemIconPastDue = Gui.Icon("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche1_guoqi3.dds")
								elseif index == 5 then
									user_bag_weaponinfo[index].ItemIconPastDue = Gui.Icon("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche1_guoqi2.dds")
								else
									user_bag_weaponinfo[index].ItemIconPastDue = nil
								end
							else
								user_bag_weaponinfo[index].ItemIconPastDue = nil
							end
							
							if weapons[index].unit_type == 2 then
								b_denote.Text = lang:GetText("续费")
							else
								b_denote.Text = lang:GetText("维修")
							end
							
							if b_star then
								if weapons[index].gstLevel and weapons[index].gstLevel > 0  then
									b_star.Visible = true
									b_star.Skin = Gui.ControlSkin
									{
										BackgroundImage = Gui.Image("LobbyUI/Compose/shengxing/lb_synthesis_conversion_star_0"..weapons[index].gstLevel..".dds", Vector4(3, 0, 0, 0)),
									}
								else
									b_star.Visible = false
								end
								if index > 2 then
									b_star.Location = Vector2(10, 10)
								else
									b_star.Location = Vector2(212-142, 10)
								end
							end
							if index == 1 or index == 2 or index == 3 or index == 4 then
								if weapons[index].unit_type == 0 then
									user_bag_weaponinfo[index].PBVisible = true
									user_bag_weaponinfo[index].ComboVisible = false
									
									local percent = weapons[index].common.durable / 100.0
									local fPosY = 12.0 + 29.0 * (1.0 - percent)
									local fHeight = 29.0 * percent
									local topSkin
									user_bag_weaponinfo[index].PBTopLocation = Vector2(4, fPosY)
									user_bag_weaponinfo[index].PBTopSize = Vector2(16, fHeight)
									
									if percent <= 0.2 then
										topSkin = Gui.ControlSkin
										{
											BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_manage_power_content2.dds", Vector4(0, 0, 0, 0)),
										}		
									else
										topSkin = Gui.ControlSkin
										{
											BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_manage_power_content.dds", Vector4(0, 0, 0, 0)),
										}		
									end
									
									user_bag_weaponinfo[index].PBTopSkin = topSkin
									
									user_bag_weaponinfo[index].ItemCombo:RemoveAll()
									user_bag_weaponinfo[index].ItemCombo:AddItem(lang:GetText("充能"))
									user_bag_weaponinfo[index].ItemCombo:AddItem(lang:GetText("续费"))
								else
									user_bag_weaponinfo[index].PBVisible = false
									user_bag_weaponinfo[index].ComboVisible = false
								end
							end
							
							user_bag_weaponinfo[index].ComboVisible = false
							
							--如果是默认没有这些东西
							if weapons[index].isDefault == 0 then
								b_denote.Visible = false
								user_bag_weaponinfo[index].PBVisible = false
								--user_bag_weaponinfo[index].ItemLevel = nil
								user_bag_weaponinfo[index].BtnVisible = false
								if index == 6 or index == 7 then
									user_bag_weaponinfo[index].Enable = false
								else
									user_bag_weaponinfo[index].Enable = true
								end
								if index == 4 then
									if weapons[index].display == "temp" then
										user_bag_weaponinfo[index].Enable = false
										user_bag_weaponinfo[index].ItemLevel = nil
									else
										user_bag_weaponinfo[index].Enable = true
									end
								end
							else
								--卸下的操作判断
								if index == 4 then
									user_bag_weaponinfo[index].BtnVisible = true
								end
								if index == 6 or index == 7 then
									user_bag_weaponinfo[index].BtnVisible = true
								end
								b_denote.Visible = true
							end
							if weapons[index].common.isAsset == 1 then
								b_denote.Visible = false
							end
							if index < 1 or index > 4 and b_denote.Text == lang:GetText("维修") then
								b_denote.Visible = false
							end
						else
							-- 关掉相关信息
							user_bag_weaponinfo[index].ItemIcon = nil
							user_bag_weaponinfo[index].ItemIconVIP = nil
							user_bag_weaponinfo[index].ItemLevel = nil
							user_bag_weaponinfo[index].Enable = false
							user_bag_weaponinfo[index].PBVisible = false
							user_bag_weaponinfo[index].ComboVisible = false
						end
					end
				end
			end
		end

		if L_Characters.user_bag_info_ui then
			for index in pairs(user_bag_weaponinfo) do
				user_bag_weaponinfo[index].Loading = false
			end
		end
		L_MessageBox.CloseWaiter()
		InitAvatarPreviewInfo(p_id, c_id)
	end)
end

--人物装备
---参数列
-- pid=帐号id
-- cid=人物id(炮哥ID)
-- playeritemid (想从仓库装备到背包的物品id)
-- t		(该物品的type)
--function RpcEquipWeapon(u_id, p_id, _t, c_id,itemIndex)
function RpcEquipWeapon(itemIndex)
	local item_id
	
	if current_Storageitem[itemIndex] then
		item_id = current_Storageitem[itemIndex].playeritemid
	else
		return
	end
	
	args = {uid = ptr_cast(game.CurrentState):GetUserId(),pid = ptr_cast(game.CurrentState):GetCharacterId(),cid = current_choose_class,playeritemid = item_id, t = current_character_storage}
	rpc.safecall("storage_req_equipt", args,
	function(data)
		if data then
			if data.warning then
				MessageBox.ShowWithTimer(1,data.warning)
				ptr_cast(game.CurrentState):Quit()
				return
			end
			gui:PlayAudio("kUIA_EQUIPMENT")
			if current_Storageitem[itemIndex] then
				if current_Storageitem[itemIndex].common.type == 1 then
				--武器
					IsInit = 0
					weapon_index = current_Storageitem[itemIndex].common.seq
					ClassBagIndex_Characters[current_choose_class] = current_Storageitem[itemIndex].common.seq
					ClassWeaponIndex_Characters[current_choose_class] = current_Storageitem[itemIndex].common.seq
				elseif current_Storageitem[itemIndex].common.type == 2 then
				--套装
					ClassBagIndex_Characters[current_choose_class] = 5
				elseif current_Storageitem[itemIndex].common.type == 3 then
				--配饰
					ClassBagIndex_Characters[current_choose_class] = current_Storageitem[itemIndex].common.seq + 5
				end
			end

			FillClassBag(ptr_cast(game.CurrentState):GetCharacterId(), current_choose_class)
			FillClassStorage()
		end
		L_MessageBox.CloseWaiter()
		L_Characters.RestAllCharacterBagItemBoxBtn()
	end)
	
end


--装备移除
-- 参数列表
-- uid=帐号id
-- pid=帐号id
-- cid=人物id(炮哥ID)
-- t	(该物品的type)
-- seq=背包物品序列()

function RpcRemoveEquip(_t,itemIndex)
	args = {uid = ptr_cast(game.CurrentState):GetUserId(),pid = ptr_cast(game.CurrentState):GetCharacterId(),cid = L_LobbyMain.current_choose_class,t = _t,seq = itemIndex}
	rpc.safecall("storage_req_unpack",args,Equip,function() L_MessageBox.CloseWaiter() end)
end

function Equip(data)
	if data.warning then
		MessageBox.ShowWithTimer(1,data.warning)
		ptr_cast(game.CurrentState):Quit()
		return
	end
	FillClassBag(ptr_cast(game.CurrentState):GetCharacterId(), current_choose_class)
	FillClassStorage()
	L_Characters.RestAllCharacterBagItemBoxBtn()
end

--填充仓库
-- 参数列表
-- uid=帐号id
-- pid=人物id
-- t:请求的商城物品类型，1=武器、2=套装、3=配饰、4=道具、5=设计图、6=素材、7=大礼包
-- cid=角色id
-- p:请求该类型和该子类型的第几页
-- st:筛选装备类型
function FillClassStorage(tempst)
	if current_character_storage == 1 then
		if L_Characters.ib_weapon_ui == nil then
			return
		end
		for i = 1, 8 do
			local ibbtn = ptr_cast(L_Characters.ib_weapon_ui.ctrl_ib_container:GetChildByIndex(i-1))
			local b_denote = ptr_cast(ibbtn:GetChildByIndex(2))
			local b_destoty = ptr_cast(ibbtn:GetChildByIndex(3))
			local b_control = ptr_cast(ibbtn:GetChildByIndex(4))
			b_denote.Visible = false
			b_destoty.Visible = false
			b_control.Visible = false
			if ibbtn then
				ibbtn.BtnVisible = true
				ibbtn.Loading = true 	--fireball 修改这里可以打开或关闭LOADING开关
				ibbtn.PBVisible = false
				ibbtn.ItemLevel = nil
			end
		end
	elseif current_character_storage == 2 then
		if L_Characters.ib_dress_ui == nil then
			return
		end
		for i = 1, 8 do
			local ibbtn = ptr_cast(L_Characters.ib_dress_ui.ctrl_ib_container:GetChildByIndex(i-1))
			local b_denote = ptr_cast(ibbtn:GetChildByIndex(2))
			local b_destoty = ptr_cast(ibbtn:GetChildByIndex(3))
			local b_control = ptr_cast(ibbtn:GetChildByIndex(4))
			b_denote.Visible = false
			b_destoty.Visible = false
			b_control.Visible = false
			if ibbtn then
				ibbtn.BtnVisible = true
				ibbtn.Loading = true
				ibbtn.ItemLevel = nil
			end
		end
	elseif current_character_storage == 3 then
		if L_Characters.ib_accessories_ui == nil then
			return
		end
		for i = 1, 16 do
			local ibbtn = ptr_cast(L_Characters.ib_accessories_ui.ctrl_ib_container:GetChildByIndex(i-1))
			local b_denote = ptr_cast(ibbtn:GetChildByIndex(2))
			local b_destoty = ptr_cast(ibbtn:GetChildByIndex(3))
			local b_control = ptr_cast(ibbtn:GetChildByIndex(4))
			b_denote.Visible = false
			b_destoty.Visible = false
			b_control.Visible = false
			if ibbtn then
				ibbtn.BtnVisible = true
				ibbtn.Loading = true
				ibbtn.ItemLevel = nil
			end
		end
	elseif current_character_storage > 3 and current_character_storage < 9 then
		for i = 1, 28 do
			local ibbtn = ptr_cast(L_Characters.prop_window_ui.ctrl_ib_container:GetChildByIndex(i-1))
			local b_denote = ptr_cast(ibbtn:GetChildByIndex(2))
			local b_destoty = ptr_cast(ibbtn:GetChildByIndex(3))
			local c_control = ptr_cast(ibbtn:GetChildByIndex(4))
			b_denote.Visible = false
			b_destoty.Visible = false
			c_control.Visible = false
			if ibbtn then
				ibbtn.BtnVisible = true
				ibbtn.Loading = true
				ibbtn:IsShowTimer()
				ibbtn.ItemLevel = nil
			end
		end
	end
	local st = 0
	if current_character_storage > 3 then
		if tempst then
			st = tempst
		end
	else
		st = L_Characters.packge_main_ui.cbx_Filter_Type.SelectedIndex
	end
	
	local args = {uid = ptr_cast(game.CurrentState):GetUserId(), pid = ptr_cast(game.CurrentState):GetCharacterId(), t = current_character_storage, cid = current_choose_class, p = CurrentCharacterPages[current_choose_class][current_character_storage],st = st}
	rpc.safecallload("storage_list", args,
	function (data)
		CharactersIB_rpc_data = data
		local items = data.items
		current_Storageitem = data.items
		if items then	
			if current_character_storage == 1 then
				if L_Characters.ib_weapon_ui then
					for i = 1, 8 do
						local ibbtn = ptr_cast(L_Characters.ib_weapon_ui.ctrl_ib_container:GetChildByIndex(i-1))
						ibbtn.ItemIconPastDue = nil
						local b_denote = ptr_cast(ibbtn:GetChildByIndex(2))
						local b_destoty = ptr_cast(ibbtn:GetChildByIndex(3))
						local b_control = ptr_cast(ibbtn:GetChildByIndex(4))
						local b_star = ptr_cast(ibbtn:GetChildByIndex(5))
						ibbtn.ComboVisible = false
						if items[i] then
							ibbtn.BtnVisible = true
							ibbtn.Enable = true
							ibbtn.Selected = false
							b_control.Visible = true
							if items[i].common.is_vip > 0 then
								ibbtn.ItemIconVIP = Gui.Icon("LobbyUI/ShoppingMall/vip"..items[i].common.is_vip..".dds")
							else
								ibbtn.ItemIconVIP = nil
							end
							if items[i].common.minutes_left == 0 then
								ibbtn.ItemIconPastDue = Gui.Icon("LobbyUI/ShoppingMall/lb_shop_bg_wuqi_guoqi5.dds")
							end
							
							if items[i].unit_type == 2 then
								b_denote.Text = lang:GetText("续费")
								ibbtn.PBVisible = false
							else
								b_denote.Text = lang:GetText("维修")
								ibbtn.PBVisible = true
								ibbtn.ItemIconPastDue = nil
							end
							
							if items[i].common.rareLevel then
								ibbtn.ItemLevel = Skin.rarelevel[math.ceil(items[i].common.rareLevel/25)]
							end
							
							local percent = items[i].common.durable / 100.0
							local fPosY = 27.0 + 29 * (1.0 - percent)
							local fHeight = 29 * percent
							ibbtn.PBTopLocation = Vector2(4, fPosY)
							ibbtn.PBTopSize = Vector2(16, fHeight)
							local topSkin
							if percent <= 0.2 then
								topSkin = Gui.ControlSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_manage_power_content2.dds", Vector4(0, 3, 0, 3)),
								}		
							else
								topSkin = Gui.ControlSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_manage_power_content.dds", Vector4(0, 3, 0, 3)),
								}		
							end
							ibbtn.PBTopSkin = topSkin
							
							if items[i].isDefault == 0 then
								b_denote.Visible = false
								b_destoty.Visible = false
								ibbtn.PBVisible = false
							else
								b_denote.Visible = true
								b_destoty.Visible = true
							end							
							
							if items[i].common.isAsset == 1 then
								b_denote.Visible = false
							end
							
							-- 颜色
							if items[i].color >= 1 and items[i].color <= 8 then
								ibbtn.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..items[i].name.."_"..items[i].color..".tga")
							else
								ibbtn.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..items[i].name..".tga")
							end
							ibbtn.Padding = Vector4(0, 0, 0, 7)
							
							if items[i].common.strength == -1 then
								b_control.Skin = Gui.ControlSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_cantenhance_ico.dds", Vector4(0, 0, 0, 0)),
								}
							else
								if items[i].common.strength == 0 then
									if items[i].isDefault == 0 or unit_type ~= 0 then -- unit_type == 0 为永久物品 才有强化对可能
										b_control.Skin = Gui.ControlSkin
										{
											BackgroundImage = nil,
										}
									else
										b_control.Skin = Gui.ControlSkin
										{
											BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_canenhance_ico.dds", Vector4(0, 0, 0, 0)),
										}
									end
								elseif items[i].common.strength > 0 then
									b_control.Skin = Gui.ControlSkin
									{
										BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/badge_lv"..items[i].common.strength.."_small.dds", Vector4(0, 0, 0, 0)),
									}
								end
							end
							
							if items[i].gstLevel and items[i].gstLevel > 0  then
								b_star.Visible = true
								b_star.Skin = Gui.ControlSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/Compose/shengxing/lb_synthesis_conversion_star_0"..items[i].gstLevel..".dds", Vector4(0, 0, 0, 0)),
								}
							else
								b_star.Visible = false
							end
						else
							ibbtn.BtnVisible = false
							b_denote.Visible = false
							b_destoty.Visible = false
							b_control.Visible = false
							b_star.Visible = false
							ibbtn.ItemIcon = nil
							ibbtn.Enable = false
							ibbtn.Selected = false
							ibbtn.ComboVisible = false
							ibbtn.PBVisible = false
							ibbtn.ItemIconVIP = nil
							ibbtn.ItemLevel = nil
						end
					end
				end
			elseif current_character_storage == 2 then
				if L_Characters.ib_dress_ui then
					for i = 1, 8 do
						local ibbtn = ptr_cast(L_Characters.ib_dress_ui.ctrl_ib_container:GetChildByIndex(i-1))
						ibbtn.ItemIconPastDue = nil
						local b_denote = ptr_cast(ibbtn:GetChildByIndex(2))
						local b_destoty = ptr_cast(ibbtn:GetChildByIndex(3))
						local b_control = ptr_cast(ibbtn:GetChildByIndex(4))
						local b_star = ptr_cast(ibbtn:GetChildByIndex(5))
						if items[i] then
							b_control.Visible = true
							ibbtn.BtnVisible = true
							ibbtn.Enable = true
							ibbtn.Selected = false
							b_destoty.Visible = true
							b_denote.Visible = true
							
							if items[i].common.is_vip > 0 then
								ibbtn.ItemIconVIP = Gui.Icon("LobbyUI/ShoppingMall/vip"..items[i].common.is_vip..".dds")
							else
								ibbtn.ItemIconVIP = nil
							end
							
							if items[i].isDefault == 0 then
								b_destoty.Visible = false
								b_denote.Visible = false
							end
							
							if items[i].unit_type == 0 then
								b_denote.Visible = false
							end
							
							if items[i].common.isAsset == 1 then
								b_denote.Visible = false
							end
							
							if items[i].common.rareLevel then
								ibbtn.ItemLevel = Skin.rarelevel[math.ceil(items[i].common.rareLevel/25)]
							end
							
							if items[i].unit_type == 2 and items[i].common.minutes_left == 0 then
								ibbtn.ItemIconPastDue = Gui.Icon("LobbyUI/ShoppingMall/lb_shop_bg_fuzhuang_guoqi4.dds")
							else
								ibbtn.ItemIconPastDue = nil
							end
							
							if items[i].color >= 1 and items[i].color <= 8 then
								ibbtn.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..items[i].name.."_"..items[i].color..".tga")
							else
								ibbtn.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..items[i].name..".tga")
							end
							ibbtn.Padding = Vector4(0, 0, 0, 7)
							
							if items[i].common.strength == -1 then
								b_control.Skin = Gui.ControlSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_cantenhance_ico.dds", Vector4(0, 0, 0, 0)),
								}
							else
								if items[i].common.strength == 0 then
									if items[i].isDefault == 0 or unit_type ~= 0 then -- unit_type == 0 为永久物品 才有强化对可能
										b_control.Skin = Gui.ControlSkin
										{
											BackgroundImage = nil,
										}
									else
										b_control.Skin = Gui.ControlSkin
										{
											BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_canenhance_ico.dds", Vector4(0, 0, 0, 0)),
										}
									end
								elseif items[i].common.strength > 0 then
									b_control.Skin = Gui.ControlSkin
									{
										BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/badge_lv"..items[i].common.strength.."_small.dds", Vector4(0, 0, 0, 0)),
									}
								end
							end
							if items[i].gstLevel and items[i].gstLevel > 0  then
								b_star.Visible = true
								b_star.Skin = Gui.ControlSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/Compose/shengxing/lb_synthesis_conversion_star_0"..items[i].gstLevel..".dds", Vector4(0, 0, 0, 0)),
								}
							else
								b_star.Visible = false
							end
						else
							ibbtn.BtnVisible = false
							b_denote.Visible = false
							b_destoty.Visible = false
							b_control.Visible = false
							b_star.Visible = false
							ibbtn.ItemIcon = nil
							ibbtn.Enable = false
							ibbtn.Selected = false
							ibbtn.ComboVisible = false
							ibbtn.ItemIconVIP = nil
							ibbtn.ItemLevel = nil
						end
					end
				end
			elseif current_character_storage == 3 then
				if L_Characters.ib_accessories_ui then
					for i = 1, 16 do
						local ibbtn = ptr_cast(L_Characters.ib_accessories_ui.ctrl_ib_container:GetChildByIndex(i-1))
						local b_denote = ptr_cast(ibbtn:GetChildByIndex(2))
						local b_destoty = ptr_cast(ibbtn:GetChildByIndex(3))
						local b_control = ptr_cast(ibbtn:GetChildByIndex(4))
						local b_star = ptr_cast(ibbtn:GetChildByIndex(5))
						ibbtn.ItemIconPastDue = nil
						if items[i] then
							ibbtn.BtnVisible = true
							ibbtn.Enable = true
							ibbtn.Selected = false
							b_denote.Visible = true
							b_destoty.Visible = true
							b_control.Visible = true
							
							if items[i].common.is_vip > 0 then
								ibbtn.ItemIconVIP = Gui.Icon("LobbyUI/ShoppingMall/vip"..items[i].common.is_vip..".dds")
							else
								ibbtn.ItemIconVIP = nil
							end
							
							if items[i].unit_type == 2 and items[i].common.minutes_left == 0 then
								ibbtn.ItemIconPastDue = Gui.Icon("LobbyUI/ShoppingMall/lb_shop_bg_peishi_guoqi6.dds")
							else
								ibbtn.ItemIconPastDue = nil
							end
							
							if items[i].common.rareLevel then
								ibbtn.ItemLevel = Skin.rarelevel[math.ceil(items[i].common.rareLevel/25)]
							end
							
							if items[i].isDefault == 0 then
								b_destoty.Visible = false
								b_denote.Visible = false
							end
							
							if items[i].unit_type == 0 then
								b_denote.Visible = false
							end
							
							if items[i].common.isAsset == 1 then
								b_denote.Visible = false
							end
							
							if items[i].color >= 1 and items[i].color <= 8 then
								ibbtn.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..items[i].name.."_"..items[i].color..".tga")
							else
								ibbtn.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..items[i].name..".tga")
							end
							ibbtn.Padding = Vector4(0, 0, 0, 7)
					
							if items[i].common.strength == -1 then
								b_control.Skin = Gui.ControlSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_cantenhance_ico.dds", Vector4(0, 0, 0, 0)),
								}
							else
								if items[i].common.strength == 0 then
									if items[i].isDefault == 0 or unit_type ~= 0 then -- unit_type == 0 为永久物品 才有强化对可能
										b_control.Skin = Gui.ControlSkin
										{
											BackgroundImage = nil,
										}
									else
										b_control.Skin = Gui.ControlSkin
										{
											BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_canenhance_ico.dds", Vector4(0, 0, 0, 0)),
										}
									end
								elseif items[i].common.strength > 0 then
									b_control.Skin = Gui.ControlSkin
									{
										BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/badge_lv"..items[i].common.strength.."_small.dds", Vector4(0, 0, 0, 0)),
									}
								end
							end
							if items[i].gstLevel and items[i].gstLevel > 0  then
								b_star.Visible = true
								b_star.Skin = Gui.ControlSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/Compose/shengxing/lb_synthesis_conversion_star_0"..items[i].gstLevel..".dds", Vector4(0, 0, 0, 0)),
								}
							else
								b_star.Visible = false
							end
						else
							b_denote.Visible = false
							b_destoty.Visible = false
							b_control.Visible = false
							b_star.Visible = false
							ibbtn.BtnVisible = false
							ibbtn.ItemIcon = nil
							ibbtn.Enable = false
							ibbtn.Selected = false
							ibbtn.ComboVisible = false
							ibbtn.ItemIconVIP = nil
							ibbtn.ItemLevel = nil
						end
					end
				end
			elseif current_character_storage == 4 then
				if L_Characters.prop_window_ui then
					for i = 1, 28 do
						local ibbtn = ptr_cast(L_Characters.prop_window_ui.ctrl_ib_container:GetChildByIndex(i-1))
						local b_denote = ptr_cast(ibbtn:GetChildByIndex(2))
						local b_destoty = ptr_cast(ibbtn:GetChildByIndex(3))
						local c_control = ptr_cast(ibbtn:GetChildByIndex(4))
						
						if items[i] then
							ibbtn.BtnVisible = true
							ibbtn.Enable = true
							ibbtn.Selected = false
							b_denote.Visible = true
							b_destoty.Visible = true
							c_control.Visible = false
							-- if items[i].common.is_vip > 0 then
								-- ibbtn.ItemIconVIP = Gui.Icon("LobbyUI/ShoppingMall/vip"..items[i].common.is_vip..".dds")
							-- else
								ibbtn.ItemIconVIP = nil
							-- end
							
							if items[i].isDefault == 0 then
								b_destoty.Visible = false
								b_denote.Visible = true
							end
							
							if items[i].unit_type == 0 then
								b_denote.Visible = false
							end
							
							if items[i].color >= 1 and items[i].color <= 8 then
								ibbtn.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..items[i].name.."_"..items[i].color..".tga")
							else
								ibbtn.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..items[i].name..".tga")
							end
							ibbtn.Padding = Vector4(0, 0, 0, 5)
							
							--基于时间的道具
							if items[i].unit_type == 2 then
								if items[i].buff == nil then
									ibbtn.ItemIconPastDue = nil
								else
									if items[i].buff == 0 then
										ibbtn.BtnText = lang:GetText("使用")
										ibbtn.BtnVisible = true
										ibbtn.ItemIconPastDue = nil
									elseif items[i].buff > 0 then
										ibbtn.BtnVisible = false
										ibbtn.ItemIconPastDue = Gui.Icon("LobbyUI/ShoppingMall/lb_shop_ico_shiyongzhong.dds")
									end
								end
							else
								b_denote.Visible = false
								ibbtn.BtnText = lang:GetText("使用")
								ibbtn.BtnVisible = true
								ibbtn.ItemIconPastDue = nil
							end
							
							-- 隔天礼包
							if items[i].iid == 24 then
								ibbtn:SetTimer(items[i].createtime,data.currenttime,28800)
								if items[i].sid == 5815 then
									ibbtn:SetTimer(items[i].createtime,data.currenttime,15*60)
								elseif items[i].sid == 5816 then
									ibbtn:SetTimer(items[i].createtime,data.currenttime,30*60)
								elseif items[i].sid == 5817 then
									ibbtn:SetTimer(items[i].createtime,data.currenttime,60*60)
								elseif items[i].sid == 5818 then
									ibbtn:SetTimer(items[i].createtime,data.currenttime,120*60)
								elseif items[i].sid == 5819 then
									ibbtn:SetTimer(items[i].createtime,data.currenttime,12*3600)
								elseif items[i].sid == 5820 then
									ibbtn:SetTimer(items[i].createtime,data.currenttime,24*3600)
								elseif items[i].sid == 5821 then
									ibbtn:SetTimer(items[i].createtime,data.currenttime,48*3600)
								elseif items[i].sid == 5822 then
									ibbtn:SetTimer(items[i].createtime,data.currenttime,72*3600)
								end
							else
								ibbtn:IsShowTimer()
							end
							
							if items[i].common.isAsset == 1 then
								b_denote.Visible = false
							end
							
							if items[i].common.subtype == 7 then
								ibbtn.BtnVisible = false
								c_control.Visible = true
								c_control.Location = Vector2(29,73)
								FillNumber(items[i].common.quantity, c_control)
							end
						else
							ibbtn.BtnVisible = false
							b_denote.Visible = false
							b_destoty.Visible = false
							c_control.Visible = false
							ibbtn.ItemIcon = nil
							ibbtn.Enable = false
							ibbtn.Selected = false
							ibbtn.ComboVisible = false
							ibbtn.ItemIconVIP = nil
							ibbtn.ItemIconPastDue = nil
							ibbtn.ItemLevel = nil
						end
					end
				end
			elseif current_character_storage == 5 then
				if L_Characters.prop_window_ui then
					for i = 1, 28 do
						local ibbtn = ptr_cast(L_Characters.prop_window_ui.ctrl_ib_container:GetChildByIndex(i-1))
						local b_denote = ptr_cast(ibbtn:GetChildByIndex(2))
						local b_destoty = ptr_cast(ibbtn:GetChildByIndex(3))
						local c_control = ptr_cast(ibbtn:GetChildByIndex(4))
						if items[i] then
							ibbtn.BtnVisible = true
							ibbtn.Enable = true
							ibbtn.Selected = false
							c_control.Visible = true
							b_destoty.Visible = true
							ibbtn.ItemIconPastDue = nil
							ibbtn.BtnVisible = false
							
							c_control.Location = Vector2(29,73)
							FillNumber(items[i].common.quantity, c_control)
							
							-- if items[i].common.is_vip > 0 then
								-- ibbtn.ItemIconVIP = Gui.Icon("LobbyUI/ShoppingMall/vip"..items[i].common.is_vip..".dds")
							-- else
								ibbtn.ItemIconVIP = nil
							-- end
							
							if items[i].isDefault == 0 then
								b_destoty.Visible = false
							end
							
							if items[i].unit_type == 0 then
								b_denote.Visible = false
							end
							
							if items[i].common.rareLevel then
								ibbtn.ItemLevel = Skin.rarelevel[math.ceil(items[i].common.rareLevel/25)]
							end
							
							if items[i].color >= 1 and items[i].color <= 8 then
								ibbtn.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..items[i].name.."_"..items[i].color..".tga")
							else
								ibbtn.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..items[i].name..".tga")
							end
							ibbtn.Padding = Vector4(0, 0, 0, 5)
						else
							ibbtn.BtnVisible = false
							b_denote.Visible = false
							b_destoty.Visible = false
							c_control.Visible = false
							ibbtn.ItemIcon = nil
							ibbtn.Enable = false
							ibbtn.Selected = false
							ibbtn.ComboVisible = false
							ibbtn.ItemIconVIP = nil
							ibbtn.ItemIconPastDue = nil
							ibbtn.ItemLevel = nil
						end
					end
				end
			elseif current_character_storage == 6 then
				if L_Characters.prop_window_ui then
					for i = 1, 28 do
						local ibbtn = ptr_cast(L_Characters.prop_window_ui.ctrl_ib_container:GetChildByIndex(i-1))
						local b_denote = ptr_cast(ibbtn:GetChildByIndex(2))
						local b_destoty = ptr_cast(ibbtn:GetChildByIndex(3))
						
						if items[i] then
							ibbtn.BtnVisible = true
							ibbtn.Enable = true
							ibbtn.Selected = false
							b_denote.Visible = true
							b_destoty.Visible = true
							-- if items[i].common.is_vip > 0 then
								-- ibbtn.ItemIconVIP = Gui.Icon("LobbyUI/ShoppingMall/vip"..items[i].common.is_vip..".dds")
							-- else
								ibbtn.ItemIconVIP = nil
							-- end
							
							if items[i].isDefault == 0 then
								b_destoty.Visible = false
								b_denote.Visible = true
							end
							
							if items[i].unit_type == 0 then
								b_denote.Visible = false
							end
							
							if items[i].color >= 1 and items[i].color <= 8 then
								ibbtn.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..items[i].name.."_"..items[i].color..".tga")
							else
								ibbtn.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..items[i].name..".tga")
							end
							ibbtn.Padding = Vector4(0, 0, 0, 5)
						else
							ibbtn.BtnVisible = false
							b_denote.Visible = false
							b_destoty.Visible = false
							ibbtn.ItemIcon = nil
							ibbtn.Enable = false
							ibbtn.Selected = false
							ibbtn.ComboVisible = false
							ibbtn.ItemIconVIP = nil
							ibbtn.ItemIconPastDue = nil
						end
					end
				end
			elseif current_character_storage == 7 then
				if L_Characters.prop_window_ui then
					for i = 1, 28 do
						local ibbtn = ptr_cast(L_Characters.prop_window_ui.ctrl_ib_container:GetChildByIndex(i-1))
						local b_denote = ptr_cast(ibbtn:GetChildByIndex(2))
						local b_destoty = ptr_cast(ibbtn:GetChildByIndex(3))
						
						if items[i] then
							ibbtn.BtnVisible = true
							ibbtn.Enable = true
							ibbtn.Selected = false
							b_denote.Visible = true
							b_destoty.Visible = true
							-- if items[i].common.is_vip > 0 then
								-- ibbtn.ItemIconVIP = Gui.Icon("LobbyUI/ShoppingMall/vip"..items[i].common.is_vip..".dds")
							-- else
								ibbtn.ItemIconVIP = nil
							-- end
							
							if items[i].isDefault == 0 then
								b_destoty.Visible = false
								b_denote.Visible = true
							end
							
							if items[i].unit_type == 0 then
								b_denote.Visible = false
							end
							
							if items[i].color >= 1 and items[i].color <= 8 then
								ibbtn.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..items[i].name.."_"..items[i].color..".tga")
							else
								ibbtn.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..items[i].name..".tga")
							end
							ibbtn.Padding = Vector4(0, 0, 0, 5)
						else
							ibbtn.BtnVisible = false
							b_denote.Visible = false
							b_destoty.Visible = false
							ibbtn.ItemIcon = nil
							ibbtn.Enable = false
							ibbtn.Selected = false
							ibbtn.ComboVisible = false
							ibbtn.ItemIconVIP = nil
							ibbtn.ItemIconPastDue = nil
						end
					end
				end
			elseif current_character_storage == 8 then
				if L_Characters.prop_window_ui then
					for i = 1, 28 do
						local ibbtn = ptr_cast(L_Characters.prop_window_ui.ctrl_ib_container:GetChildByIndex(i-1))
						local b_denote = ptr_cast(ibbtn:GetChildByIndex(2))
						local b_destoty = ptr_cast(ibbtn:GetChildByIndex(3))
						local c_control = ptr_cast(ibbtn:GetChildByIndex(4))
						
						if items[i] then
							ibbtn.BtnVisible = true
							ibbtn.Enable = true
							ibbtn.Selected = false
							b_denote.Visible = true
							b_destoty.Visible = true
							c_control.Visible = true
							-- if items[i].common.is_vip > 0 then
								-- ibbtn.ItemIconVIP = Gui.Icon("LobbyUI/ShoppingMall/vip"..items[i].common.is_vip..".dds")
							-- else
								ibbtn.ItemIconVIP = nil
							-- end
							
							if items[i].isDefault == 0 then
								b_destoty.Visible = false
								b_denote.Visible = true
							end
							
							c_control.Location = Vector2(29,56)
							FillNumber(items[i].common.quantity, c_control)
							
							if items[i].common.rareLevel then
								ibbtn.ItemLevel = Skin.rarelevel[math.ceil(items[i].common.rareLevel/25)]
							end
							
							if items[i].unit_type == 0 then
								b_denote.Visible = false
							end
							
							if items[i].color >= 1 and items[i].color <= 8 then
								ibbtn.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..items[i].name.."_"..items[i].color..".tga")
							else
								ibbtn.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..items[i].name..".tga")
							end
							ibbtn.Padding = Vector4(0, 0, 0, 5)
							
							--基于时间的道具
							if items[i].unit_type == 2 then
								if items[i].buff == nil then
									ibbtn.ItemIconPastDue = nil
								else
									if items[i].buff == 0 then
										ibbtn.BtnText = lang:GetText("使用")
										ibbtn.BtnVisible = true
										ibbtn.ItemIconPastDue = nil
									elseif items[i].buff > 0 then
										ibbtn.BtnVisible = false
										ibbtn.ItemIconPastDue = Gui.Icon("LobbyUI/ShoppingMall/lb_shop_ico_shiyongzhong.dds")
									end
								end
							else
								b_denote.Visible = false
								ibbtn.BtnText = lang:GetText("使用")
								ibbtn.BtnVisible = true
								ibbtn.ItemIconPastDue = nil
							end
							
							-- 隔天礼包
							if items[i].iid == 24 then
								ibbtn:SetTimer(items[i].createtime,data.currenttime,28800)
								if items[i].sid == 5815 then
									ibbtn:SetTimer(items[i].createtime,data.currenttime,15*60)
								elseif items[i].sid == 5816 then
									ibbtn:SetTimer(items[i].createtime,data.currenttime,30*60)
								elseif items[i].sid == 5817 then
									ibbtn:SetTimer(items[i].createtime,data.currenttime,60*60)
								elseif items[i].sid == 5818 then
									ibbtn:SetTimer(items[i].createtime,data.currenttime,120*60)
								elseif items[i].sid == 5819 then
									ibbtn:SetTimer(items[i].createtime,data.currenttime,12*3600)
								elseif items[i].sid == 5820 then
									ibbtn:SetTimer(items[i].createtime,data.currenttime,24*3600)
								elseif items[i].sid == 5821 then
									ibbtn:SetTimer(items[i].createtime,data.currenttime,48*3600)
								elseif items[i].sid == 5822 then
									ibbtn:SetTimer(items[i].createtime,data.currenttime,72*3600)
								end
							else
								ibbtn:IsShowTimer()
							end
						else
							ibbtn.BtnVisible = false
							b_denote.Visible = false
							b_destoty.Visible = false
							c_control.Visible = false
							ibbtn.ItemIcon = nil
							ibbtn.Enable = false
							ibbtn.Selected = false
							ibbtn.ComboVisible = false
							ibbtn.ItemIconVIP = nil
							ibbtn.ItemIconPastDue = nil
							ibbtn.ItemLevel = nil
						end
					end
				end
			end
		end
		SetCharactersPage()

		if current_character_storage == 1 then
			if L_Characters.ib_weapon_ui then
				for i = 1, 8 do
					local ibbtn = ptr_cast(L_Characters.ib_weapon_ui.ctrl_ib_container:GetChildByIndex(i-1))
					if ibbtn then
						ibbtn.Loading = false
					end
				end
			end
		elseif current_character_storage == 2 then
			if L_Characters.ib_dress_ui then
				for i = 1, 8 do
					local ibbtn = ptr_cast(L_Characters.ib_dress_ui.ctrl_ib_container:GetChildByIndex(i-1))
					if ibbtn then
						ibbtn.Loading = false
					end
				end
			end
		elseif current_character_storage == 3 then
			if L_Characters.ib_accessories_ui then
				for i = 1, 16 do
					local ibbtn = ptr_cast(L_Characters.ib_accessories_ui.ctrl_ib_container:GetChildByIndex(i-1))
					if ibbtn then
						ibbtn.Loading = false
					end
				end
			end
		elseif current_character_storage > 3 and current_character_storage < 9 then
			if L_Characters.prop_window_ui then
				for i = 1, 28 do
					local ibbtn = ptr_cast(L_Characters.prop_window_ui.ctrl_ib_container:GetChildByIndex(i-1))
					if ibbtn then
						ibbtn.Loading = false
					end
				end
			end
		end
	end)
end

-- 得到按钮数量和按钮的组
function GetShoppingMallBottonGroup()
	if current_shoppingmall_storage == 1 and L_ShoppingMall.ib_weapon_ui then
		return 8, L_ShoppingMall.ib_weapon_ui.ctrl_ib_container
	elseif current_shoppingmall_storage == 2 and L_ShoppingMall.ib_dress_ui then
		return 8, L_ShoppingMall.ib_dress_ui.ctrl_ib_container
	elseif current_shoppingmall_storage == 3 and L_ShoppingMall.ib_accessories_ui then
		return 16, L_ShoppingMall.ib_accessories_ui.ctrl_ib_container
	elseif current_shoppingmall_storage > 3 and current_shoppingmall_storage < 11 and L_ShoppingMall.prop_window_ui then
		return 28, L_ShoppingMall.prop_window_ui.ctrl_ib_container
	end
end

local function InitShoppingMall()
	local num = nil
	local btn_group = nil
	num, btn_group = GetShoppingMallBottonGroup()
	if num ~= nil and btn_group ~= nil then
		for i = 1, num do
			local ibbtn = ptr_cast(btn_group:GetChildByIndex(i-1))
			local b_denote = ptr_cast(ibbtn:GetChildByIndex(2))
			local b_control = ptr_cast(ibbtn:GetChildByIndex(3))
			b_denote.Visible = false
			b_control.Visible = false
			if ibbtn then
				ibbtn.BtnVisible = false
				ibbtn.Loading = true
			end
		end	
	end
end
local function UpdateShoppingMall()
	L_ShoppingMall.RestAllShoppingMallItemBoxBtn()
	if ShoppingMallIB_rpc_data ~= nil then
		local items = ShoppingMallIB_rpc_data.items
		local num = nil
		local btn_group = nil
		num, btn_group = GetShoppingMallBottonGroup()
		if items and num ~= nil and btn_group ~= nil then
			for i = 1, num do
				local ibbtn = ptr_cast(btn_group:GetChildByIndex(i-1))
				local b_denote = ptr_cast(ibbtn:GetChildByIndex(2))
				local b_control = ptr_cast(ibbtn:GetChildByIndex(3))
				local b_star = ptr_cast(ibbtn:GetChildByIndex(4))
				ibbtn.ItemLevel = nil
				if items[i] then
					if current_character_storage > 0 and current_character_storage < 4 then
						b_control.Visible = true
						if items[i].common.strength == -1 then
							b_control.Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_cantenhance_ico.dds", Vector4(0, 0, 0, 0)),
							}
						else
							if items[i].common.strength == 0 then
								if items[i].isDefault == 0 or unit_type ~= 0 then -- unit_type == 0 为永久物品 才有强化对可能
									b_control.Skin = Gui.ControlSkin
									{
										BackgroundImage = nil,
									}
								else
									b_control.Skin = Gui.ControlSkin
									{
										BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_canenhance_ico.dds", Vector4(0, 0, 0, 0)),
									}
								end
							elseif items[i].common.strength > 0 then
								b_control.Skin = Gui.ControlSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/badge_lv"..items[i].common.strength.."_small.dds", Vector4(0, 0, 0, 0)),
								}
							end
						end
					else
						b_control.Visible = false
					end
					
					ibbtn.BtnVisible = true
					ibbtn.Enable = true
					ibbtn.Padding = Vector4(0, 0, 0, 7)
					ibbtn.GoodsID = items[i].sid
					if items[i].sendperson == 0 then
						b_denote.Visible = true
					else
						b_denote.Visible = false
					end
					
					if items[i].color >= 1 and items[i].color <= 8 then
						ibbtn.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..items[i].name.."_"..items[i].color..".tga")
					else
						ibbtn.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..items[i].name..".tga")
					end
					
					if items[i].common.rareLevel then
						ibbtn.ItemLevel = Skin.rarelevel[math.ceil(items[i].common.rareLevel/25)]
					end
							
					if items[i].common.is_vip > 0 then
						ibbtn.ItemIconNew = Gui.Icon("LobbyUI/ShoppingMall/vip"..items[i].common.is_vip..".dds")
					elseif items[i].common.is_new == 1 then
						ibbtn.ItemIconNew = Gui.Icon("LobbyUI/ShoppingMall/lb_vip_new.dds")
					elseif items[i].common.is_hot == 1 then
						ibbtn.ItemIconNew = Gui.Icon("LobbyUI/ShoppingMall/lb_vip_hot.dds")
					elseif items[i].common.is_web == 1 then
						ibbtn.ItemIconNew = Gui.Icon("LobbyUI/ShoppingMall/lb_wangba_ico.dds")
					else
						ibbtn.ItemIconNew =nil
					end
				else
					ibbtn.BtnVisible = false
					b_control.Visible = false
					b_denote.Visible = false
					ibbtn.ItemIcon = nil
					ibbtn.Enable = false
					ibbtn.GoodsID = -1
					ibbtn.ItemIconNew = nil
					ibbtn.ItemIconVIP = nil
					ibbtn.Selected = false
				end
			end
		end
		if num ~= nil and btn_group ~= nil then
			SetShoppingMallPage()
			L_MessageBox.CloseWaiter()
			for i = 1, num do
				local ibbtn = ptr_cast(btn_group:GetChildByIndex(i-1))
				if ibbtn then
					ibbtn.Loading = false
				end
			end		
		end
	else
		print("LobbyMain.UpdateShoppingMall error : ShoppingMallIB_rpc_data is nil")
	end
end
-- 参数列表
-- uid=帐号id
-- pid=人物id
-- t:请求的商城物品类型，1=武器、2=套装、3=配饰、4=道具、5=设计图、6=素材、7=大礼包
-- cid=角色id
-- p:请求该类型和该子类型的第几页
-- st:筛选装备类型
-- pt:筛选购买类型
function FillShoppingMallIB(tempst)
	InitShoppingMall()
	local st = 0
	local pt = 0
	if current_shoppingmall_storage >3 then
		st = L_ShoppingMall.main_props_window_ui.cbx_Filter_Type.SelectedIndex
		pt = L_ShoppingMall.Fileter_Property_MoneyType
	else
		st = L_ShoppingMall.packge_main_ui.cbx_Filter_Type.SelectedIndex
		pt = L_ShoppingMall.Fileter_Equip_MoneyType
	end
	if pt < 0 then
		pt = 0
	end
	if st>0 and st < 3 then
		st = st+7
	else
		st = st-2
	end
	if st == 5 then
		st = 7
	end
	if tempst then
		st = tempst
	end
	local args = {uid = ptr_cast(game.CurrentState):GetUserId(), pid = ptr_cast(game.CurrentState):GetCharacterId(), t = current_shoppingmall_storage, cid = current_choose_class, p = CurrentShoppingMallPages[current_choose_class][current_shoppingmall_storage],st = st,pt = pt}
	rpc.safecallload("shop_list",args,
	function (data)
		ShoppingMallIB_rpc_data = data
		UpdateShoppingMall()
	end)
end

-- 功能：商场购买商品并装备到背包
-- 参数列表
-- uid=帐号id
-- pid=帐号id
-- sid =准备要买的物品的id
-- t = 准备要买的物品的type 1=武器、2=套装、3=配饰、4=道具、5=设计图、6=素材、7=大礼包
-- cid = 角色id 4=道具、5=设计图、6=素材、7=大礼包 cid=0
-- costid = 1, 2, 3 付款方式的id
-- packid=1 装备到背包=1 购买不装备=0
function Buy_Goods(u_id, p_id, s_id, _t, c_id, cost_id, pack_id , is_zob)
	rpc.safecall("shop_req_buy", {uid = u_id, pid = p_id, sid = s_id, t = _t, cid = c_id, costid = cost_id, packid = pack_id},
	function (data)
		if L_ShoppingMall.is_buy_and_equip == true then
			--AvatarInShoppingMall()
		end
		
		if data.result == -2 or data.result == -3 then
			MessageBox.ShowWithTwoButtons(lang:GetText("你的FC点不足，请充值"),lang:GetText("充值"),lang:GetText("取消"),
									function()
										gui:ShowIE()
									end,
									nil
									)
		elseif data.result == -1 then
			MessageBox.ShowWithConfirm(lang:GetText("你的C币不足"))
		else
			MessageBox.ShowWithTimer(1, lang:GetText("购买成功"))
			if gui then
				gui:PlayAudio("kUIA_BUY_SUCCESS")
			end
			-- L_Vip.HideRapidShoppingWin()
			if L_Vip.VipShowmodel then
				L_Vip.Show_VipShow()
				return
			end
			if is_zob then
				L_Characters_manage.Fill()
				L_Characters_manage.HideRapidShoppingWin()
				return
			end
			
			if _t < 4 then
				FillClassBag(ptr_cast(game.CurrentState):GetCharacterId(), current_choose_class)
			end
			L_ShoppingMall.CloseBuyWin()
		end		
		L_MessageBox.CloseWaiter()
	end)
end

-- 参数列表
-- uid=帐号id
-- pid=帐号id
-- cid = 角色id
-- packid=1 装备到背包=1 购买不装备=0  
-- list="sid,t,costid;sid,t,costid;sid,t,costid;"
function Buy_Goods_Cart(u_id, p_id, c_id, pack_id)
	rpc.safecall("shop_req_buy_list", {uid = u_id, pid = p_id, cid = c_id, packid = pack_id, list = L_ShoppingMall.shoppingcart_string},
	function (data)
		if data.result == -2 or data.result == -3 then
			MessageBox.ShowWithTwoButtons(lang:GetText("你的FC点不足，请充值"),lang:GetText("充值"),lang:GetText("取消"),
									function()
										gui:ShowIE()
									end,
									nil
									)
		elseif data.result == -1 then
			MessageBox.ShowWithConfirm(lang:GetText("你的C币不足"))
		else
			MessageBox.ShowWithTimer(1, lang:GetText("购买成功"))
			if gui then
				gui:PlayAudio("kUIA_BUY_SUCCESS")
			end
		end
		L_MessageBox.CloseWaiter()
	end)
	for i = 1 ,7 do
		RemoveShoppingCart(i)
	end
	FillShoppingCart()
end

function LoadAvatar(pid)
	if pid == ptr_cast(game.CurrentState):GetCharacterId() then	
		ChangeAvatar(current_Avatar_Team, CharactersInfo_rpc_data.items.resourcename)
		--套装 帽子 配饰
		for index = 1, 3 do
			local item = AvatarPreviewInfo[current_choose_class][index + 4]
			if item.resource and item.name then
				local n = #item.resource
				for i = 1, n do			
					if i > 0 then
						AddAvatarPart(current_Avatar_Team, item.resource[i])
					end
				end
			else
				local avatars = CharactersInfo_rpc_data.items.avatar
				if avatars then
					local avatar = avatars[index]
					if avatar then
						if avatar ~= "" then
							AddAvatarPart(current_Avatar_Team, avatar)
						else
							print(lang:GetText("没有发现默认装备") .. index)
						end
					end
				end
			end
		end
		
		--武器
		
		local weapon = AvatarPreviewInfo[current_choose_class][current_preview_weapon_index]
		if weapon then		
			if weapon.resource then			
				ChangeWeapon(current_Avatar_Team, weapon.resource.type)
				local n = #weapon.resource
				SetWeaponColor(current_Avatar_Team,weapon.color)
				for i = 1, n do			
					if i > 0 then
						AddWeaponPart(current_Avatar_Team, weapon.resource[i])
					end
				end
			else
				local weapon = CharactersInfo_rpc_data.items.weapons[current_preview_weapon_index]
				if weapon.resource then
					ChangeWeapon(current_Avatar_Team, weapon.resource.type)
					local n = #weapon.resource
					SetWeaponColor(current_Avatar_Team,weapon.color)
					for i = 1, n do			
						if i > 0 then
							AddWeaponPart(current_Avatar_Team, weapon.resource[i])
						end
					end
				else
					weapon = CharactersInfo_rpc_data.items.weapons[1]
					if weapon.resource then
						ChangeWeapon(current_Avatar_Team, weapon.resource.type)
						local n = #weapon.resource
						SetWeaponColor(current_Avatar_Team,weapon.color)
						for i = 1, n do			
							if i > 0 then
								AddWeaponPart(current_Avatar_Team, weapon.resource[i])
							end
						end
					end
				end
			end
		end
	else
		if OtherCharactersInfo_rpc_data then
			ChangeAvatar(current_Avatar_Team, OtherCharactersInfo_rpc_data.items.resourcename)
			--套装 帽子 配饰
			for index = 1, 3 do
				local item = OtherCharactersInfo_rpc_data.items.costume[index]
				if item.resource then
					local n = #item.resource
					for i = 1, n do			
						if i > 0 then
							AddAvatarPart(current_Avatar_Team, item.resource[i])
						end
					end
				else
					local avatars = OtherCharactersInfo_rpc_data.items.avatar
					if avatars then
						local avatar = avatars[index]
						if avatar then
							if avatar ~= "" then			
								AddAvatarPart(current_Avatar_Team, avatar)
							else
								print(lang:GetText("没有发现默认装备") .. index)
							end
						end
					end
				end
			end
			
			--武器
			local weapon = OtherCharactersInfo_rpc_data.items.weapons[1]
			if weapon then		
				if weapon.resource then			
					ChangeWeapon(current_Avatar_Team, weapon.resource.type)
					local n = #weapon.resource
					SetWeaponColor(current_Avatar_Team,weapon.color)
					for i = 1, n do			
						if i > 0 then
							AddWeaponPart(current_Avatar_Team, weapon.resource[i])
						end
					end
				end
			end
		else
			print("ERROR!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
		end
	end
end
--切换职业
function ChangeAvatar(side, name)
	lg:AvatarShow(side, name)
end

--加载人物模型部件
function AddAvatarPart(side, part)
	lg:SetAvatarPart(side, part)
end

--切换武器
function ChangeWeapon(side, type)
	lg:SetWeaponType(side, type)
end

--加载武器模型部件
function AddWeaponPart(side, part)
	lg:AddWeaponPart(side, part)
end

function SetWeaponColor(side, color)
	lg:SetWeaponColor(side, color)
end

function ClearAvatar()
end

function InitCharactersRPCInfo()
	--职业列表填充
	rpc.safecall("character_list", {pid = pid}, FillCharacterClass)
	L_LobbyMain.FillClassBag(ptr_cast(game.CurrentState):GetCharacterId(), current_choose_class)
	if L_Characters.main_props_window_ui ~= nil and L_LobbyMain.current_character_storage > 3 then
		L_LobbyMain.current_character_storage = L_Characters.current_selected_type[L_Characters.current_selected_type_index][1]
		L_LobbyMain.FillClassStorage(L_Characters.current_selected_type[L_Characters.current_selected_type_index][2])
	else	
		L_LobbyMain.FillClassStorage()
	end
end

function InitShoppingMallRPCInfo()
	--职业列表填充
	--L_MessageBox.ShowWaiter(lang:GetText("正在加载职业列表..."))
	rpc.safecall("character_list", {pid = pid}, FillCharacterClass)
	
	--填充商城数据
	if L_ShoppingMall.main_props_window_ui and L_ShoppingMall.main_character_window_ui.btn_Property.PushDown == true then
		if L_ShoppingMall.main_props_window_ui.btn_tuijian.PushDown == true then
			L_LobbyMain.current_shoppingmall_storage = 10
			L_LobbyMain.FillShoppingMallIB(0)
		elseif L_ShoppingMall.main_props_window_ui.btn_gongneng.PushDown == true then	
			L_LobbyMain.current_shoppingmall_storage = 4
			L_LobbyMain.FillShoppingMallIB(4)
		elseif L_ShoppingMall.main_props_window_ui.btn_hecheng.PushDown == true then
			L_LobbyMain.current_shoppingmall_storage = 5
			L_LobbyMain.FillShoppingMallIB(1)
		elseif L_ShoppingMall.main_props_window_ui.btn_xiaohao.PushDown == true then
			L_LobbyMain.current_shoppingmall_storage = 4
			L_LobbyMain.FillShoppingMallIB(7)
		elseif L_ShoppingMall.main_props_window_ui.btn_jiacheng.PushDown == true then
			L_LobbyMain.current_shoppingmall_storage = 4
			L_LobbyMain.FillShoppingMallIB(1)
		elseif L_ShoppingMall.main_props_window_ui.btn_lantu.PushDown == true then
			L_LobbyMain.current_shoppingmall_storage = 5
			L_LobbyMain.FillShoppingMallIB(2)
		elseif L_ShoppingMall.main_props_window_ui.btn_mingpian.PushDown == true then
			L_LobbyMain.current_shoppingmall_storage = 4
			L_LobbyMain.FillShoppingMallIB(2)
		end
	else
		L_LobbyMain.FillShoppingMallIB()
	end	
end

function InitPersonalInfoRPCInfo()
	--职业列表填充
	rpc.safecall("character_list",{pid = pid}, FillCharacterClass)
end

--填充左侧职业列表
function FillCharacterClass(data)
	if data then
		L_LobbyMain.character_classes = data.data
		if L_Characters.main_character_window_ui then
			for i,v in ipairs(L_LobbyMain.character_classes) do
				local button = ptr_cast(L_Characters.main_character_window_ui["tab_btn_"..i])
				if v then
					--button.Text = v.name.." "
					if v.is_open == 1 then
						button.Enable = true
						button.Visible = true
						button.Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab02_"..v.resourceName.."normal.dds", Vector4(0, 0, 0, 0)),
							HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab02_"..v.resourceName.."down.dds", Vector4(0, 0, 0, 0)),
							DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab02_"..v.resourceName.."down.dds", Vector4(0, 0, 0, 0)),
							DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab02_"..v.resourceName.."normal.dds", Vector4(0, 0, 0, 0)),
						}
					end
				else
					button.Visible = false
				end
			end
		end

		if L_ShoppingMall.main_character_window_ui then
			for i,v in ipairs(L_LobbyMain.character_classes) do
				local button = ptr_cast(L_ShoppingMall.main_character_window_ui["tab_btn_"..i])
				if v then
					--button.Text = v.name.." "
					if v.is_open == 1 then
						button.Enable = true
						button.Visible = true
						button.Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab02_"..v.resourceName.."normal.dds", Vector4(0, 0, 0, 0)),
							HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab02_"..v.resourceName.."down.dds", Vector4(0, 0, 0, 0)),
							DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab02_"..v.resourceName.."down.dds", Vector4(0, 0, 0, 0)),
							DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab02_"..v.resourceName.."normal.dds", Vector4(0, 0, 0, 0)),
						}
					end
				else
					button.Visible = false
				end
			end
		end
		
		if L_PersonalInfo.main_character_window_ui then
			for i,v in ipairs(L_LobbyMain.character_classes) do
				local button = ptr_cast(L_PersonalInfo.main_character_window_ui["tab_btn_"..i])
				if v then
					--button.Text = v.name.." "
					if v.is_open == 1 then
						button.Enable = true
						button.Visible = true
						button.Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab02_"..v.resourceName.."normal.dds", Vector4(0, 0, 0, 0)),
							HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab02_"..v.resourceName.."down.dds", Vector4(0, 0, 0, 0)),
							DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab02_"..v.resourceName.."down.dds", Vector4(0, 0, 0, 0)),
							DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab02_"..v.resourceName.."normal.dds", Vector4(0, 0, 0, 0)),
						}
					end
				else
					button.Visible = false
				end
			end
		end
		
		if L_PersonalInfo.main_character_achievement_window_ui then
			for i,v in ipairs(L_LobbyMain.character_classes) do
				local button = ptr_cast(L_PersonalInfo.main_character_achievement_window_ui["tab_btn_"..i])
				if v then
					--button.Text = v.name.." "
					if v.is_open == 1 then
						button.Enable = true
						button.Visible = true
						button.Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab02_"..v.resourceName.."normal.dds", Vector4(0, 0, 0, 0)),
							HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab02_"..v.resourceName.."down.dds", Vector4(0, 0, 0, 0)),
							DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab02_"..v.resourceName.."down.dds", Vector4(0, 0, 0, 0)),
							DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab02_"..v.resourceName.."normal.dds", Vector4(0, 0, 0, 0)),
						}
					end
				else
					button.Visible = false
				end
			end
		end
		
		if L_Compose.ui then
			for i,v in ipairs(L_LobbyMain.character_classes) do
				local button = ptr_cast(L_Compose.ui["tab_btn_"..i])
				if v then
					--button.Text = v.name.." "
					if v.is_open == 1 then
						button.Enable = true
						button.Visible = true
						button.Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab02_"..v.resourceName.."normal.dds", Vector4(0, 0, 0, 0)),
							HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab02_"..v.resourceName.."down.dds", Vector4(0, 0, 0, 0)),
							DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab02_"..v.resourceName.."down.dds", Vector4(0, 0, 0, 0)),
							DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab02_"..v.resourceName.."normal.dds", Vector4(0, 0, 0, 0)),
						}
					end
				else
					button.Visible = false
				end
			end
		end
		
		if L_Mail.Player_storage then
			for i,v in ipairs(L_LobbyMain.character_classes) do
				local button = ptr_cast(L_Mail.Player_storage["tab_btn_"..i])
				if v then
					--button.Text = v.name.." "
					if v.is_open == 1 then
						button.Enable = true
						button.Visible = true
						button.Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab02_"..v.resourceName.."normal.dds", Vector4(0, 0, 0, 0)),
							HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab02_"..v.resourceName.."down.dds", Vector4(0, 0, 0, 0)),
							DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab02_"..v.resourceName.."down.dds", Vector4(0, 0, 0, 0)),
							DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab02_"..v.resourceName.."normal.dds", Vector4(0, 0, 0, 0)),
						}
					end
				else
					button.Visible = false
				end
			end
		end
	else
		character_classes = nil
	end
	L_MessageBox.CloseWaiter()
end

--填充角色管理界面 页码
function SetCharactersPage()
	if L_Characters.packge_main_ui then
		if CharactersIB_rpc_data.pages == 0 then
			L_Characters.packge_main_ui.lb_page_number.Text = CharactersIB_rpc_data.page.."/"..CharactersIB_rpc_data.pages + 1
		else
			L_Characters.packge_main_ui.lb_page_number.Text = CharactersIB_rpc_data.page.."/"..CharactersIB_rpc_data.pages
		end
	end

	if L_Characters.main_props_window_ui then
		if CharactersIB_rpc_data.pages == 0 then
			L_Characters.main_props_window_ui.lb_page_number.Text = CharactersIB_rpc_data.page.."/"..CharactersIB_rpc_data.pages + 1
		else
			L_Characters.main_props_window_ui.lb_page_number.Text = CharactersIB_rpc_data.page.."/"..CharactersIB_rpc_data.pages
		end
	end
end

--填充商城界面 页码
function SetShoppingMallPage()
	if L_ShoppingMall.packge_main_ui then
		if ShoppingMallIB_rpc_data.pages == 0 then
			L_ShoppingMall.packge_main_ui.lb_page_number.Text = ShoppingMallIB_rpc_data.page.."/"..ShoppingMallIB_rpc_data.pages + 1
		else
			L_ShoppingMall.packge_main_ui.lb_page_number.Text = ShoppingMallIB_rpc_data.page.."/"..ShoppingMallIB_rpc_data.pages
		end
	end

	if L_ShoppingMall.main_props_window_ui then
		if ShoppingMallIB_rpc_data.pages == 0 then
			L_ShoppingMall.main_props_window_ui.lb_page_number.Text = ShoppingMallIB_rpc_data.page.."/"..ShoppingMallIB_rpc_data.pages + 1
		else
			L_ShoppingMall.main_props_window_ui.lb_page_number.Text = ShoppingMallIB_rpc_data.page.."/"..ShoppingMallIB_rpc_data.pages
		end
	end
end

--添加物品至购物车
--index: 购物车槽位
--item: 放入购物车物品的信息
function AddInShoppingCart(index, item)
	if index == 3 then
		index = 4
	elseif index == 4 then
		index = 3
	end
	CharactersCartInfo[current_choose_class][index] = item
end

--移除购物车物品
--index: 购物车槽位
function RemoveShoppingCart(index)
	CharactersCartInfo[current_choose_class][index] = {}
	L_ShoppingMall.RestAllShoppingMallItemBoxBtn()
end

--填充购物车界面
function FillShoppingCart()
	local fight_num = {0, 0, 0, 0, 0, 0, 0}
	if L_ShoppingMall.user_bag_info_ui then
		for i = 1, 7 do
			local ibbtn = ptr_cast(L_ShoppingMall.user_bag_info_ui.ctrl_ib_container:GetChildByIndex(i-1))
			if ibbtn then
				ibbtn.ItemLevel = nil
				if next(CharactersCartInfo[current_choose_class][i]) then
					if i == 3 then
						fight_num[4] = CharactersCartInfo[current_choose_class][i].common.star
					elseif i == 4 then
						fight_num[3] = CharactersCartInfo[current_choose_class][i].common.star
					else
						fight_num[i] = CharactersCartInfo[current_choose_class][i].common.star
					end
					local color = CharactersCartInfo[current_choose_class][i].color
					local name = CharactersCartInfo[current_choose_class][i].name
					if i == 3 or i == 4 then
						if color >= 1 and color <= 8 then
							ibbtn.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..name.."_Small_"..color..".tga")
						else
							ibbtn.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..name.."_Small.tga")
						end
					else
						if color >= 1 and color <= 8 then
							ibbtn.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..name.."_"..color..".tga")
						else
							ibbtn.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..name..".tga")
						end
					end	
				
					--rarelevel
					if CharactersCartInfo[current_choose_class][i].common.rareLevel then
						ibbtn.ItemLevel = Skin.rarelevel[math.ceil(CharactersCartInfo[current_choose_class][i].common.rareLevel/25)]
					end
				
					ibbtn.BtnVisible = true
					ibbtn.Enable = true
				else
					if i < 5 then
						if i == 3 then
							fight_num[4] = CharactersInfo_rpc_data.items.weapons[i + 1].common.star
						elseif i == 4 then
							fight_num[3] = CharactersInfo_rpc_data.items.weapons[i - 1].common.star
						else
							fight_num[i] = CharactersInfo_rpc_data.items.weapons[i].common.star
						end
					else
						fight_num[i] = CharactersInfo_rpc_data.items.costume[i - 4].common.star
					end
					ibbtn.ItemIcon = nil
					ibbtn.BtnVisible = false
					ibbtn.Enable = false
				end
			end
		end
		--购物车状态改变 修改战斗力
		for i = 1, 7 do
			print("fight_num:"..fight_num[i])
		end
		local total_num = 0
		total_num = ((0.85 * fight_num[1]) + (0.05 * fight_num[2]) + (0.1 * fight_num[3])) * 
					(1 + fight_num[4] / 5000) * (1 + fight_num[5] / 1000) * (1 + fight_num[6] / 1000) *
					(1 + fight_num[7] / 1000)
		ChangeBG(L_ShoppingMall.avatart_main_ui, math.floor(total_num), false)
	end	
end

--更新等级经验
--level 等级
--exp 经验
function UpdateLevelAndExp(level, exp)
	LobbyMainWin_Header.lb_UserLevel_AnoldState.Location = Vector2(198, 36)
	LobbyMainWin_Header.lb_UserLevel_TenState.Location = Vector2(184, 36)
	FillLevel(level,LobbyMainWin_Header,exp)
end

--更新FC点GP抵用券
--point FC点
--gp GP
--cr CR
function UpdateMoney(cr, gp, point)
	if PersonalInfo_data then
		PersonalInfo_data.newGP = gp
		PersonalInfo_data.newCR = cr
		PersonalInfo_data.newTicket = point
	end
	LobbyMainWin_Header.lb_LeiPoint.Text = cr
	LobbyMainWin_Header.lb_GP.Text = gp
	L_FightTeam.add_team_power_ui.FC_left.Text = cr..lang:GetText("  FC点")
	L_FightTeam.add_my_power_ui.FC_left.Text = cr..lang:GetText("  FC点")
	--LobbyMainWin_Header.lb_Point.Text = point

end

function UpdateName(name)
	if PersonalInfo_data then
		PersonalInfo_data.name = name
	end
	LobbyMainWin_Header.lb_UserName.Text = name
end

function ShowAddPowerWindow(_where, _index)
	if _where == 0 then
		if Characters_BagInfo_rpc_data then
			local weapons = Characters_BagInfo_rpc_data.items.weapons
			if weapons and weapons[_index] then
				local strShow = lang:GetText("当前武器维修\n需要消耗") .. weapons[_index].repair_cost .. lang:GetText("C币")
				MessageBox.ShowWithConfirmCancel(strShow,
					function(sender,e)
						AddPower(_where, _index)
					end,
				nil)
			end
		end
	elseif _where == 1 then
		if CharactersIB_rpc_data then
			local items = CharactersIB_rpc_data.items
			if items and items[_index] then
				local strShow = lang:GetText("当前武器维修需要消耗") .. items[_index].repair_cost .. lang:GetText("C币")
				MessageBox.ShowWithConfirmCancel(strShow,
					function(sender,e)
						AddPower(_where, _index)
					end,
				nil)
			end
		end
	end
end

--充能
-- uid=帐号id
-- pid=帐号id
-- t	(该物品的type)
-- piid=物品的id(playerItemId)
function AddPower(where, index)
	if where == 0 then
		if Characters_BagInfo_rpc_data then
			local weapons = Characters_BagInfo_rpc_data.items.weapons
			if weapons and weapons[index] then
				rpc.safecall("storage_fix", {uid = state:GetUserId(), pid = state:GetCharacterId(), t = weapons[index].common.type, piid = weapons[index].playeritemid},
				function (data)	
					local Error = data.error
					if Error then
						MessageBox.ShowWithTimer(1, Error)
					else
						MessageBox.ShowWithTimer(1, lang:GetText("维修成功"))
					end		
					L_MessageBox.CloseWaiter()
					FillClassBag(ptr_cast(game.CurrentState):GetCharacterId(), current_choose_class)
				end)
			end
		end
	elseif where == 1 then	
		if CharactersIB_rpc_data then
			local items = CharactersIB_rpc_data.items
			if items and items[index] then
				rpc.safecall("storage_fix", {uid = state:GetUserId(), pid = state:GetCharacterId(), t = items[index].common.type, piid = items[index].playeritemid},
				function (data)	
					local Error = data.error
					if Error then
						MessageBox.ShowWithTimer(1, Error)
					else
						MessageBox.ShowWithTimer(1, lang:GetText("维修成功"))
					end		
					L_MessageBox.CloseWaiter()
					FillClassStorage()
				end)
			end
		end
	end
end

--续费
-- uid=帐号id
-- pid=帐号id
-- piid=物品的id(playerItemId)
-- t(该物品的type)
-- costid=付款id
function Renewals(_piid, _t, _costid)
	rpc.safecall("storage_req_renew", {uid = state:GetUserId(), pid = state:GetCharacterId(), piid = _piid, t = _t, costid = _costid},
		function (data)	
			local Error = data.error
			if Error then
				MessageBox.ShowWithTimer(1, Error)
			else
				MessageBox.ShowWithTimer(1, lang:GetText("续费成功"))
			end		
		L_MessageBox.CloseWaiter()
		if L_Characters.current_selected_item_class == 0 then
			FillClassBag(ptr_cast(game.CurrentState):GetCharacterId(), current_choose_class)
		elseif L_Characters.current_selected_item_class == 1 then
			if L_LobbyMain.current_character_storage > 3 then
				L_LobbyMain.current_character_storage = L_Characters.current_selected_type[L_Characters.current_selected_type_index][1]
				L_LobbyMain.FillClassStorage(L_Characters.current_selected_type[L_Characters.current_selected_type_index][2])
			else
				L_LobbyMain.FillClassStorage()
			end
		end
	end)
end

function OnNeedFCMNotified()
	setup_shimingzhi_window(gui)
	
	--未认证
	if state.fcm_flag == 2 then
		create_shimingzhi_window.lbl_info.Text = lang:GetText("你的账号因未填写实名制信息,将会被防沉迷系统限制您的收益.请去官方网站填写身份信息")
		create_shimingzhi_window.chaolianjie.Visible = true
		create_shimingzhi_window.underline.Visible = true
	--未成年
	elseif state.fcm_flag == 1 then
		create_shimingzhi_window.lbl_info.Text = lang:GetText("你的账号为未成年用户，将会被防沉迷系统限制您的收益")
	
	end
end

--实名反沉迷
create_shimingzhi_window = Gui.Create()
{
	Gui.Control "root"
	{
		Size = Vector2(684, 304),
		BackgroundColor = ARGB(0, 255, 200, 255),
		Dock = "kDockCenter",
		Gui.Control "shimingzhi"
		{
			Size = Vector2(684, 304),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/setting/ig_esc_bg2.dds",Vector4(10, 10, 10, 10)),
			},
			
			Gui.Label 
			{
				Size = Vector2(661,36),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Location = Vector2(11, 10),
				Text = lang:GetText("防沉迷提示"),
				FontSize = 20,
				TextColor = ARGB(255, 52, 52, 50),
				TextAlign = "kAlignCenterMiddle",
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/setting/lb_shop_buttonfukuan_down.dds",Vector4(5, 5, 5, 5)),
				},
			},

			Gui.Label "lbl_info"
			{
				Size = Vector2(580,200),
				Location = Vector2(50,0),
				TextColor = ARGB(255, 218, 0, 6),
				FontSize = 24,
				AutoWrap = true,
				Text = "",
			},
			
			Gui.Label "underline"
			{
				Size = Vector2(360,25),
				Location = Vector2(50,135),
				Text = "────────────────────────────",
				TextColor = ARGB(255, 0, 99, 210),
				FontSize = 24,
				Visible = false,
			},
			
			Gui.Button "chaolianjie"
			{
				Size = Vector2(360,30),
				Location = Vector2(50,120),
				Text = "http://youxi.xunlei.com/fcm/",
				TextColor = ARGB(255, 0, 99, 210),
				HighlightTextColor = ARGB(255,156, 227, 247),
				FontSize = 24,
				Visible = false,
				EventClick = function()
					gui:ShowFCM()
				end,
				EventMouseEnter = function()
					create_shimingzhi_window.underline.TextColor = ARGB(255,156, 227, 247)
				end,
				EventMouseLeave = function()
					create_shimingzhi_window.underline.TextColor = ARGB(255, 0, 99, 210)
				end,
			},
		
			--确定按钮
			Gui.Button "btn_ok"
			{
				Size = Vector2(140, 50),
				Location = Vector2(262 , 233),
				Text = lang:GetText("确 定"),
				TextColor = ARGB(255,255, 239, 206),
				HighlightTextColor = ARGB(255,255, 239, 206),
				FontSize = 30,
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/lb_contact_button_normal.tga", Vector4(5, 5, 5, 5)),
					HoverImage = Gui.Image("LobbyUI/team/lb_contact_button_hover.tga", Vector4(5, 5, 5, 5)),
					DownImage = Gui.Image("LobbyUI/team/lb_contact_button_down.tga", Vector4(5, 5, 5, 5)),
					DisabledImage = Gui.Image("LobbyUI/team/lb_contact_button_normal.tga", Vector4(5, 5, 5, 5)),		
				},
				EventClick = function()
					if create_shimingzhi_ui then
						create_shimingzhi_ui.Close()
						create_shimingzhi_ui = nil
					end
				end,
			},
		},
	},
}

--创建防沉迷界面
function setup_shimingzhi_window(parent_window)
	--界面是否存在
	if create_shimingzhi_ui then
		return
	end
	
	create_shimingzhi_ui = ModalWindow.GetNew("create_shimingzhi")
	create_shimingzhi_ui.root.Size = Vector2(684, 304)
	create_shimingzhi_ui.AllowEscToExit = true
	
	create_shimingzhi_window.root.Parent = create_shimingzhi_ui.root
	create_shimingzhi_ui.root.BackgroundColor = ARGB(0, 255, 255, 255)
end

--获得好友列表
-- pid=昵称id
-- displayOnline = 1只显示在线好友0全部显示
function GetFriendsList()
	local args = {pid = ptr_cast(game.CurrentState):GetCharacterId(), displayOnline = 0}
	rpc.safecall("friends_list",args,
				function (data) 
					Friends_rpc_data = nil
					Black_rpc_data = nil
					Friends_rpc_data = data.friendlist
					Black_rpc_data = data.blacklist
					state:BlacklistClear()
					local i = 1
					while Black_rpc_data[i] do
						state:BlacklistAdd(Black_rpc_data[i][1],Black_rpc_data[i][3])
						i = i + 1
					end
					GetOnlineFriends()
					if L_Friends.Create_Friend_ui then
						L_Friends.ChangesList(L_Friends.changes_List)
					end
				end)
end

--获得陌生人列表
-- pid=昵称id
-- displayOnline = 1只显示在线好友0全部显示
function GetPartnerList(which)
	local args = {pid = ptr_cast(game.CurrentState):GetCharacterId(), displayOnline = 0}
	rpc.safecall("partners_list",args,
				function (data) 
					partners_rpc_data = nil
					partners_rpc_data = data.partnerslist
					GetOnlineFriends()
					if L_Friends.Create_Friend_ui and L_Friends.changes_List == 2 then
						L_Friends.ChangesList(L_Friends.changes_List)
					end
					L_LobbyMain.LobbyMainWin_Foot.btn_Friends.Enable = true
					if which and which == 1 then
						L_Friends.GroupListFill(L_LobbyMain.Friends_rpc_data , L_Friends.Create_Group_AddMembers_ui.list_Group_AddMembers_info_Friend)
						L_Friends.GroupListFill(L_LobbyMain.partners_rpc_data , L_Friends.Create_Group_AddMembers_ui.list_Group_AddMembers_info_stranger)
					elseif which and which == 2 then
						--L_Friends.FillInviteFriendsList(L_LobbyMain.Friends_rpc_data ,L_Friends.Create_InviteGame_Win_ui.list_Friends_Invite)
						--L_Friends.FillInviteFriendsList(L_LobbyMain.partners_rpc_data ,L_Friends.Create_InviteGame_Win_ui.list_Stranger_Invite)
					end
				end)
end

--获得群组列表
-- pid=昵称id
function GerGroupList()
	local args = {pid = ptr_cast(game.CurrentState):GetCharacterId(), displayOnline = 0}
	rpc.safecall("friend_group_list",args,
				function (data) 
					MyGroup_rpc_data = nil
					AddGroup_rpc_data = nil
					MyGroup_rpc_data = data.myGroup
					AddGroup_rpc_data = data.addGroups
					if L_Friends.Create_Friend_ui then
						L_Friends.FileGroupList(MyGroup_rpc_data,AddGroup_rpc_data)
					end
					for i = 1 , 10 do
						if L_Friends.ChatInfo[i][2] == 3 then
							GroupListSearch(L_Friends.ChatInfo[i][3],L_Friends.ChatInfo[i][1])
						end
					end
					
					if L_Friends.ChatBTNSign ~= 0 then
						for i = 1 , L_Friends.ChatBtn_WinNumber do
							if L_Friends.ChatBTNSign == L_Friends.ChatBTNTrait[i][1] and L_Friends.ChatBTNTrait[i][2] == 3 then
								L_Friends.FileGroupListMember(L_Friends.ChatBTNTrait[i][3])
								L_Friends.GroupSpeak(L_Friends.ChatBTNTrait[i][3])
								break
							end
						end
					end
					
					LeaverGroupControl()
				end,
		function () L_MessageBox.CloseWaiter() 
		end)
end

--群组列表搜索
function GroupListSearch(Name,which)
	if MyGroup_rpc_data[1] and Name == MyGroup_rpc_data[1][5] then
		return
	end
	for _,v in ipairs(AddGroup_rpc_data) do
		if Name ==  v[1][5] then
			return
		end
	end
	for j = 1 , L_Friends.ChatBtn_WinNumber do
		if L_Friends.ChatBTNTrait[j][1] == which then
			L_Friends.HideChatBTN(which,j)
			return
		end
	end
	L_Friends.HideChatBTN(which,0)
end

--群组退出确定框状态控制
function LeaverGroupControl()
	if L_Friends.LeaveGroupName then
		if MyGroup_rpc_data[1] and L_Friends.LeaveGroupName == MyGroup_rpc_data[1][5] then
			return
		end
		for _,v in ipairs(AddGroup_rpc_data) do
			if Name ==  v[1][5] then
				return
			end
		end
		L_Friends.HIdeLeaveGroupCreateWin()
	end
end

--获得好友在线人数
FriendNumbers = 0
FriendOnlineNumbers = 0
BlackNumbers = 0
BlackOnlineNumbers = 0
PartnerNumbers = 0
PartnerOnlineNumbers = 0

function GetOnlineFriends()
	FriendNumbers = 0
	FriendOnlineNumbers = 0
	if Friends_rpc_data then
		for _,v in ipairs(Friends_rpc_data) do
			FriendNumbers = FriendNumbers + 1
			if v[5] == 1 then
				FriendOnlineNumbers = FriendOnlineNumbers + 1
			end
		end
	end
	BlackNumbers = 0
	BlackOnlineNumbers = 0
	if Black_rpc_data then
		for _,v in ipairs(Black_rpc_data) do
			BlackNumbers = BlackNumbers + 1
			if v[5] == 1 then
				BlackOnlineNumbers = BlackOnlineNumbers + 1
			end
		end
	end
	PartnerNumbers = 0
	PartnerOnlineNumbers = 0
	if partners_rpc_data then
		for _,v in ipairs(partners_rpc_data) do
			PartnerNumbers = PartnerNumbers + 1
			if v[5] == 1 then
				PartnerOnlineNumbers = PartnerOnlineNumbers + 1
			end
		end
	end
	LobbyMainWin_Foot.btn_Friends.Text = FriendOnlineNumbers
--	LobbyMainWin_Foot.btn_Friends_Invited.Text = FriendOnlineNumbers
--	LobbyMainWin_Foot.btn_Grounp_Invited.Text = FriendOnlineNumbers	
	FriendsUpdate()
end

--好友人数显示刷新
function FriendsUpdate()
	if L_Friends.Create_Friend_ui then
		L_Friends.Create_Friend_ui.lb_Friend_Friend.Text = "("..FriendOnlineNumbers.."/"..FriendNumbers..")"
		L_Friends.Create_Friend_ui.lb_Friend_Blacklist.Text = "("..BlackOnlineNumbers.."/"..BlackNumbers..")"
		L_Friends.Create_Friend_ui.lb_Friend_Stranger.Text = "("..PartnerOnlineNumbers.."/"..PartnerNumbers..")"
	end
end
--[[
--群组添加框
function GroupUpdata()
	if L_Friends.Create_Group_AddMembers_ui then
		L_Friends.Create_Group_AddMembers_ui.lb_Group_AddMembers_Friend.Text = "("..FriendOnlineNumbers.."/"..FriendNumbers..")"
		L_Friends.Create_Group_AddMembers_ui.lb_Group_AddMembers_Stranger.Text = "("..PartnerOnlineNumbers.."/"..PartnerNumbers..")"
	end
end
	]]
--玩家搜索接口
-- name = 搜索关键字
-- page_id = 当前请求的页数
function FriendsSearch()
	local args = { name = L_Friends.Create_Friend_ui.tbox_Friend_search.Text , page_id = 1}
	rpc.safecall("friends_search_list",args,L_Friends.FilFriendSearchList,function () L_MessageBox.CloseWaiter() end)
end

--好友邀请
FriendAdd = nil

function FriendsInvited(Id,FdName)
	if Id == FriendId then
		return
	end
	for _,v in ipairs(L_LobbyMain.Black_rpc_data) do
		if Id == v[1] then
			return
		end
	end
	L_LobbyMain.LobbyMainWin.tips.Text = lang:GetText("您有一个好友邀请！")
	L_LobbyMain.LobbyMainWin.tips.Location = Vector2(420, 758)
	L_LobbyMain.LobbyMainWin.tips.Size = Vector2(184,67)
	L_LobbyMain.LobbyMainWin.tips:Show()
	local l = FriendAdd
	while l do
		if l.id == Id then
			return
		end
		l = l.next
	end
	FriendAdd = {next = FriendAdd , id = Id , name = FdName}
	LobbyMainWin_Foot.btn_Friends.blink = true
	gui:PlayAudio("kUIA_NEW_MAIL")
--	LobbyMainWin_Foot.btn_Friends_Invited.Visible = true
end

--群组加入邀请
GroupAdd = nil

function GroupInvitedAdd(Id,FdName)
	if GroupAddId == Id then
		return
	end
	for _,v in ipairs(L_LobbyMain.Black_rpc_data) do
		if Id == v[1] then
			return
		end
	end
	L_LobbyMain.LobbyMainWin.tips.Text = lang:GetText("您有一个群组邀请！")
	L_LobbyMain.LobbyMainWin.tips.Location = Vector2(420, 758)
	L_LobbyMain.LobbyMainWin.tips.Size = Vector2(184,67)
	L_LobbyMain.LobbyMainWin.tips:Show()
	local l = GroupAdd
	while l do
		if l.id == Id then
			return
		end
		l = l.next
	end
	GroupAdd = {next = GroupAdd , id = Id , name = FdName}
	LobbyMainWin_Foot.btn_Friends.blink = true
	gui:PlayAudio("kUIA_NEW_MAIL")
--	LobbyMainWin_Foot.btn_Grounp_Invited.Visible = true
end

-- 临时群组创建
function CreatTepGroup(sender, args)
	L_Friends.TepGroup_Id = args.Group_id
	L_Friends.TepGroup_Member = {next = L_Friends.TepGroup_Member , group_id = args.Group_id , member = {PersonalInfo_data.name ,nil ,nil ,nil ,nil} ,member_id = {PersonalInfo_data.id ,0 ,0 ,0 ,0},is_vip = {PersonalInfo_data.isvip ,0 ,0 ,0 ,0},business_card = {PersonalInfo_data.card,0,0,0,0},net_bar_level = {PersonalInfo_data.internetCafe,0,0,0,0}}
	L_Friends.CreatePrivateChat(args.name , 2 , args.Group_id)
	L_Friends.ShowFriendsChooseWin(gui)
	L_Friends.TepGroupListFill(L_LobbyMain.Friends_rpc_data , L_Friends.Create_Friends_Choose_ui.list_Friends_Choose_room)	
end

TepGroupAdd = nil

-- 临时群组邀请
function InviteGroup(sender, args)
	if L_LobbyMain.TepGroupAddId == args.Group_id then
		return
	end
	for _,v in ipairs(L_LobbyMain.Black_rpc_data) do
		if args.name == v[3] then
			return
		end
	end 
	for i = 1 , 10 do
		if L_Friends.ChatInfo[i][2] == 2 and L_Friends.ChatInfo[i][7] == args.Group_id then
			return
		end
	end
	L_LobbyMain.LobbyMainWin.tips.Text = lang:GetText("您有一个临时群邀请！")
	L_LobbyMain.LobbyMainWin.tips.Location = Vector2(420, 758)
	L_LobbyMain.LobbyMainWin.tips.Size = Vector2(184,67)
	L_LobbyMain.LobbyMainWin.tips:Show()
	local l = TepGroupAdd
	while l do
		if l.group_id == args.Group_id then
			return
		end
		l = l.next
	end
	TepGroupAdd = {next = TepGroupAdd , name = args.name , groupname = args.Groupname , group_id = args.Group_id}
	LobbyMainWin_Foot.btn_Friends.blink = true
	gui:PlayAudio("kUIA_NEW_MAIL")
end

function GetGroupMember(sender, args)
	if args.Group_id == 0 then
		L_Friends.ShowLeaveOwnGroupCreateWin(gui,lang:GetText("加入失败！"))
		for i = 1 , 10 do
			if L_Friends.ChatInfo[i][2] == 2 then
				HideTepGroup(i)
			end
		end
		return
	end
	local l = L_Friends.TepGroup_Member
	while l do
		if l.group_id == args.Group_id then
			l.member[args.num_which] = args.MemberName
			l.member_id[args.num_which] = args.MemberName_id
			l.is_vip[args.num_which] = args.MemberName_vip
			l.business_card[args.num_which] = args.MemberName_business_card
			l.net_bar_level[args.num_which] = args.MemberName_net_bar_level
			if args.num_which == 5 and L_Friends.ChatBTNSign ~= 0 then	
				for i = 1 , 10 do
					if L_Friends.ChatBTNSign == L_Friends.ChatInfo[i][1] then
						if L_Friends.ChatInfo[i][2] == 2 and L_Friends.ChatInfo[i][7] == args.Group_id then
							L_Friends.FileTepGroupListMember(L_Friends.ChatBTNSign)
						end
						return
					end
				end
			end
			return
		end
		l = l.next
	end
	L_Friends.TepGroup_Member = {
								next = L_Friends.TepGroup_Member ,
								group_id = args.Group_id , 
								member = {args.MemberName ,nil , nil , nil , nil} ,
								member_id = {args.MemberName_id ,0 ,0 ,0 ,0} ,
								is_vip = {args.MemberName_vip ,0 ,0 ,0 ,0} ,
								business_card = {args.MemberName_business_card ,0 ,0 ,0 ,0},
								net_bar_level = {args.MemberName_net_bar_level ,0 ,0 ,0 ,0}
								}
end

function HideTepGroup(num)
	local l = L_Friends.TepGroup_Member
	while l do
		if l.group_id == L_Friends.ChatInfo[num][7] then
			return
		end
		l = l.next
	end
	L_Friends.HideChatInfo(nil,2,L_Friends.ChatInfo[num][7])
end

-- 参数列表
-- uid=帐号id
-- pid=人物
-- rid: int = 收件人的ID
-- sid: int = 商城里物品的ID
-- t = 准备要买的物品的type 1=武器、2=套装、3=配饰、4=道具、5=蓝图、6=素材、7=大礼包
-- costid = 1, 2, 3 付款方式的id
function SendEmilGift(r_id, s_id, _t, cost_id)
	local p_id = ptr_cast(game.CurrentState):GetCharacterId()
	rpc.safecall("email_gift", {pid = p_id, rid = r_id, sid = s_id, t = _t, costid = cost_id},
	function (data)
		if data.result == -2 or data.result == -3 then
			MessageBox.ShowWithTwoButtons(lang:GetText("你的FC点不足，请充值"),lang:GetText("充值"),lang:GetText("取消"),
									function()
										gui:ShowIE()
									end,
									nil
									)
		elseif data.Error then
			Message.ShowError(lang:GetText("赠送好友失败!"))
		else
			MessageBox.ShowWithTimer(1, lang:GetText("购买成功"))
			if gui then
				gui:PlayAudio("kUIA_BUY_SUCCESS")
			end
		end
		L_MessageBox.CloseWaiter()
	end)
end

--进入频道列表填充
function RefreshChannelPlayerList()
--[[	if L_Friends.ChatBTNSign ~= 0 then
		for i = 1 , L_Friends.ChatBtn_WinNumber do
			if L_Friends.ChatBTNSign == L_Friends.ChatBTNTrait[i][1] and L_Friends.ChatBTNTrait[i][2] == 4 then
				L_Friends.FileChannelList(L_LobbyMain.LobbyMainWin.Chat_Channl_List,14)
				return
			end
		end
	end
]]	

	if not state.is_fight_team_server then
		L_WarZone.FillPlayList()
	end
	
end

-- 参数列表 
--uid=1
--pid=1
--playeritemid = 23	-- 物品的PLAYER_ITEM_ID
--msg = ""
--server_id
--channel_id
function UseProp(index)
	if CharactersIB_rpc_data and CharactersIB_rpc_data.items[index] then
		prop_index = index
		--大喇叭
		if CharactersIB_rpc_data.items[index].iid < 1 then
			gui:PlayAudio("kUIA_USE_ITEM")
			return
		elseif CharactersIB_rpc_data.items[index].iid == 3 or CharactersIB_rpc_data.items[index].iid == 2 then
			ShowDlbWindow(CharactersIB_rpc_data.items[index].iid)
			gui:PlayAudio("kUIA_USE_ITEM")
			return
		elseif CharactersIB_rpc_data.items[index].iid == 4 then
			gmz_window.root.Parent = gui
			gmz_window.name.Text = ""
			Gui.Align(gmz_window.root, 0.5, 0.5)
			Gui.Align(gmz_window.bg_root, 0.5, 0.5)
			gui:PlayAudio("kUIA_USE_ITEM")
			return
		elseif  CharactersIB_rpc_data.items[index].iid == 8 then
			gui:PlayAudio("kUIA_USE_MONEY")
		elseif CharactersIB_rpc_data.items[index].iid == 14 then
			L_FightTeam.team_create_data.playerItemId = CharactersIB_rpc_data.items[index].playeritemid
			L_FightTeam.register_team_ui = ModalWindow.GetNew()
			L_FightTeam.register_team_ui.root.Size = Vector2(605, 676)
			L_FightTeam.register_team_ui.AllowEscToExit = false
			L_FightTeam.register_team.root.Parent = L_FightTeam.register_team_ui.root
			L_FightTeam.register_team.team_name.Enable = true
			L_FightTeam.register_team.team_name.Skin = Gui.TextboxSkin{BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_contact_bg_normal.dds", Vector4(10, 10, 10, 10)),}
			L_FightTeam.register_team.province.Enable = true
			L_FightTeam.register_team.city.Enable = true
			L_FightTeam.register_team.abcd.Visible = true
			-- L_FightTeam.register_team.geshu.Visible = true
			L_FightTeam.register_team.team_name.Text = ""
			L_FightTeam.register_team.description.Text = ""
			L_FightTeam.register_team.b_create.Text = lang:GetText("创建")
			local cbx = L_FightTeam.register_team.rank
			cbx:RemoveAll()
			for i = 1, 50  do 
				cbx:AddItem( i )
			end
			cbx = L_FightTeam.register_team.province
			cbx:RemoveAll()
			for _,v in ipairs(L_FightTeam.province) do
				cbx:AddItem( v )
			end
			cbx.SelectedIndex = 0
			L_FightTeam.register_team.rank.Text = 1
			Gui.Align(L_FightTeam.register_team.register, 0.5, 0.5)
			L_FightTeam.selsect_image_id = 1
			L_FightTeam.image_id = 1
			L_FightTeam.Image_team.ib_image:AllPictureHL(false)
			L_FightTeam.register_team.zhandui_touxiang.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/team/FightHead/lb_squad_touxiang_1.dds",Vector4(0,0,0,0)),}
			gui:PlayAudio("kUIA_USE_ITEM")
			return
		elseif CharactersIB_rpc_data.items[index].iid == 16 then
			team_gmz_window.root.Parent = gui
			team_gmz_window.name.Text = ""
			Gui.Align(team_gmz_window.root, 0.5, 0.5)
			Gui.Align(team_gmz_window.bg_root, 0.5, 0.5)
			gui:PlayAudio("kUIA_USE_ITEM")
			return
--勋章 17 		锦囊 18		
--签到礼盒 19 	经验类道具 21		
--VIP保险柜 20	魔罐 22		
--等级礼盒 23   隔天礼盒 24		
--进阶礼盒 25	多选一礼盒 26	好友礼盒 27	
		elseif CharactersIB_rpc_data.items[index].iid == 19 or CharactersIB_rpc_data.items[index].iid == 18 or
				CharactersIB_rpc_data.items[index].iid == 23 or CharactersIB_rpc_data.items[index].iid == 24 or
				CharactersIB_rpc_data.items[index].iid == 25 or CharactersIB_rpc_data.items[index].iid == 27 or
				CharactersIB_rpc_data.items[index].iid == 36 or CharactersIB_rpc_data.items[index].iid == 58 or
				CharactersIB_rpc_data.items[index].iid == 59 or CharactersIB_rpc_data.items[index].iid == 60 or
				CharactersIB_rpc_data.items[index].iid == 62 then
			--签到礼包和精囊音效
			if CharactersIB_rpc_data.items[index].iid == 19 or CharactersIB_rpc_data.items[index].iid == 18 then
				--gui:PlayAudio("kUIA_OPEN_SUCCEED")
			end
			if openbox_modal == nil then
				L_MessageBox.ShowWaiter(lang:GetText("正在请求数据..."))
				rpc.safecall("storage_item_use", {uid = ptr_cast(game.CurrentState):GetUserId(), pid = ptr_cast(game.CurrentState):GetCharacterId(), playeritemid = CharactersIB_rpc_data.items[index].playeritemid, type = CharactersIB_rpc_data.items[index].common.type},
				function (data)
					if data.error then
						Message.ShowError(lang:GetText("使用道具失败!"))
						gui:PlayAudio("kUIA_CONFIRM_MESSAGE")
					else
						now_openbox_data = data
						Show_Open_box()
						FillOpenBox(now_openbox_data)
						gui:PlayAudio("kUIA_LOTTERY")
					end
					L_MessageBox.CloseWaiter()
				end)
			end
			return
		elseif CharactersIB_rpc_data.items[index].iid == 21 then
			if exppropmodal == nil then
				exppropmodal = ModalWindow.GetNew()
				exppropmodal.root.Size = Vector2(1200,900)
				exppropmodal.AllowEscToExit = false
				use_exp_prop.content.Parent = exppropmodal.root
				
				use_exp_prop.Change:Clear()
				use_exp_prop.Change.BackgroundColor = ARGB(0, 255, 255, 255),
				rpc.safecall("storage_item_use", {uid = ptr_cast(game.CurrentState):GetUserId(), pid = ptr_cast(game.CurrentState):GetCharacterId(), playeritemid = CharactersIB_rpc_data.items[index].playeritemid, type = CharactersIB_rpc_data.items[index].common.type},
					function (data)
						if data.error then
							Message.ShowError(lang:GetText("使用道具失败!"))
							gui:PlayAudio("kUIA_CONFIRM_MESSAGE")
						else
							L_MessageBox.CloseWaiter()
							now_exp = PersonalInfo_data.exp
							now_level = PersonalInfo_data.level
							Show_Exp_prop(CharactersIB_rpc_data.items[index].playeritemid)
							if L_LobbyMain.current_character_storage > 3 then
								L_LobbyMain.current_character_storage = L_Characters.current_selected_type[L_Characters.current_selected_type_index][1]
								L_LobbyMain.FillClassStorage(L_Characters.current_selected_type[L_Characters.current_selected_type_index][2])
							else
								L_LobbyMain.FillClassStorage()
							end
							gui:PlayAudio("kUIA_LOTTERY")
						end
					end)
			end
		return
		elseif CharactersIB_rpc_data.items[index].iid == 20 then
			--VIP 宝箱
			if L_Characters.Vip_Chest_Win_ui then
				return
			end
			L_Characters.CreateVipChestWin()
			local args = {pid = ptr_cast(game.CurrentState):GetCharacterId(),playeritemid = CharactersIB_rpc_data.items[index].playeritemid}
			rpc.safecall("vip_random_list", args, 
											function(data)
												if data.warning then
													MessageBox.ShowWithTimer(1,data.warning)
													gui:PlayAudio("kUIA_CONFIRM_MESSAGE")
													L_Characters.HideVipChestWin()
												else
													L_Characters.ShowVipChestWin(data,CharactersIB_rpc_data.items[index].playeritemid)
													--打开vip宝箱音效
													gui:PlayAudio("kUIA_LOTTERY")
												end
											end,
											function()
												L_Characters.HideVipChestWin()
											end)
			return		
		elseif CharactersIB_rpc_data.items[index].iid == 22 then
			if L_Characters.Charm_Bottle_Win_ui then
				return
			end
			L_Characters.CreateCharmBottleWin()
			local args = {pid = ptr_cast(game.CurrentState):GetCharacterId(),playeritemid = CharactersIB_rpc_data.items[index].playeritemid}
			rpc.safecall("magic_box_list", args, 
											function(data)
												if data.warning then
													MessageBox.ShowWithTimer(1,data.warning)
													gui:PlayAudio("kUIA_CONFIRM_MESSAGE")
													L_Characters.HideCharmBottleWin()
												else
													L_Characters.ShowCharmBottleWin(data,CharactersIB_rpc_data.items[index].playeritemid)
													gui:PlayAudio("kUIA_LOTTERY")
												end
											end,
											function()
												L_Characters.HideCharmBottleWin()
											end)
			return
		elseif CharactersIB_rpc_data.items[index].iid == 26 or  CharactersIB_rpc_data.items[index].iid == 61 then
			local p = CharactersIB_rpc_data.items[index].playeritemid
			local t = CharactersIB_rpc_data.items[index].common.type
			show_jiangli(p,t)
			gui:PlayAudio("kUIA_USE_ITEM")
			return
		end
		rpc.safecall("storage_item_use", {uid = ptr_cast(game.CurrentState):GetUserId(), pid = ptr_cast(game.CurrentState):GetCharacterId(), playeritemid = CharactersIB_rpc_data.items[index].playeritemid, type = CharactersIB_rpc_data.items[index].common.type},
		function (data)
			if data.error then
				Message.ShowError(lang:GetText("使用道具失败!"))
				gui:PlayAudio("kUIA_CONFIRM_MESSAGE")
			else
				MessageBox.ShowWithTimer(1, lang:GetText("使用成功"))
				gui:PlayAudio("kUIA_USE_ITEM")
			end
			L_MessageBox.CloseWaiter()
		end)
		if L_LobbyMain.current_character_storage > 3 then
			L_LobbyMain.current_character_storage = L_Characters.current_selected_type[L_Characters.current_selected_type_index][1]
			L_LobbyMain.FillClassStorage(L_Characters.current_selected_type[L_Characters.current_selected_type_index][2])
		else
			L_LobbyMain.FillClassStorage()
		end
	end
end


--改名字窗口
gmz_window = Gui.Create()
{
	Gui.Control "root"
	{
		Size = Vector2(1680, 1050),
		Location = Vector2(0, 0),
		BackgroundColor = ARGB(0, 255, 255, 255),
		Gui.Control "bg_root"
		{
			Size = Vector2(578, 266),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/lb_manage_props_popup_bg01.dds", Vector4(25, 50, 25, 50)),
			},
			
			Gui.Label "lbl_window_title"
			{
				Size = Vector2(568, 39),
				Location = Vector2(15, 10),
				Text = lang:GetText("改头换面"),
				TextColor = ARGB(255, 37, 37, 37),
				TextAlign = "kAlignCenterMiddle",
				FontSize = 24,
			},
			Gui.Textbox "name"
			{
				Size = Vector2(396, 41),
				Location = Vector2(97, 89),
				TextColor = ARGB(255, 0, 0, 0),
				FontSize = 24,
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/mail/lb_contact_bg3_normal.dds", Vector4(14, 14, 14, 14)),
				},
			},
			Gui.Label
			{
				Size = Vector2(500,54),
				Location = Vector2(39, 129),
				BackgroundColor = ARGB(255, 255, 255, 255),
				TextAlign = "kAlignCenterMiddle",
				Text = lang:GetText("修改完毕后需要重启客户端生效！"),
				FontSize = 14,
				TextColor = ARGB(255, 81, 79, 79),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/mail/lb_mail_newmail_ts_bg.dds", Vector4(14, 14, 14, 14)),
				},
			},
			Gui.Button 
			{
				Size = Vector2(100,35),
				Location = Vector2(175, 196),
				Text = lang:GetText("确 定"),
				TextColor = ARGB(255, 211, 211, 211),
				HighlightTextColor = ARGB(255, 211, 211, 211),
				FontSize = 20,
				Padding = Vector4(0, 0, 0 ,7),
				BackgroundColor = ARGB(255,255,255,255),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/lb_contact_button_normal.tga", Vector4(5, 5, 5, 5)),
					HoverImage = Gui.Image("LobbyUI/team/lb_contact_button_hover.tga", Vector4(5, 5, 5, 5)),
					DownImage = Gui.Image("LobbyUI/team/lb_contact_button_down.tga", Vector4(5, 5, 5, 5)),
					DisabledImage = Gui.Image("LobbyUI/team/lb_contact_button_normal.tga", Vector4(5, 5, 5, 5)),			
				},
				EventClick = function()
					local namelen = game:TextLenght(gmz_window.name.Text)
					if namelen < config:GetNickNameLengthMin() then
						MessageBox.ShowError(lang:GetText("角色名称过短！"))
						return
					elseif namelen > config:GetNickNameLengthMax() then
						MessageBox.ShowError(lang:GetText("角色名称过长！"))
						return
					end
					rpc.safecall("change_name_per",{pid = pid, newname = gmz_window.name.Text},
					function(data)
						if data.error == nil then
							MessageBox.ShowWithConfirmCancel(lang:GetText("确定修改昵称吗？\n修改完毕将关闭客户端"),
							function(sender,e)
								rpc.safecall("storage_item_use", {pid = pid, playeritemid = CharactersIB_rpc_data.items[prop_index].playeritemid, type = CharactersIB_rpc_data.items[prop_index].common.type, msg = gmz_window.name.Text},
								function(data)
									if data.error == nil then
										Thread.Quit()
									end
								end)
							end)
						end
					end)
				end
			},
			Gui.Button 
			{
				Size = Vector2(100,35),
				Location = Vector2(315, 196),
				Text = lang:GetText("取 消"),
				TextColor = ARGB(255, 211, 211, 211),
				HighlightTextColor = ARGB(255, 211, 211, 211),
				FontSize = 20,
				Padding = Vector4(0, 0, 0 ,7),
				BackgroundColor = ARGB(255,255,255,255),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/lb_contact_button_normal.tga", Vector4(5, 5, 5, 5)),
					HoverImage = Gui.Image("LobbyUI/team/lb_contact_button_hover.tga", Vector4(5, 5, 5, 5)),
					DownImage = Gui.Image("LobbyUI/team/lb_contact_button_down.tga", Vector4(5, 5, 5, 5)),
					DisabledImage = Gui.Image("LobbyUI/team/lb_contact_button_normal.tga", Vector4(5, 5, 5, 5)),			
				},
				EventClick = function()
					gmz_window.root.Parent = nil
				end
			},
		},
	},
}

--大喇叭窗口
local dlb_window =
{
	Gui.Control "root"
	{
		Size = Vector2(1680, 1050),
		Location = Vector2(0, 0),
		BackgroundColor = ARGB(0, 255, 255, 255),
		Gui.Control "bg_root"
		{
			Size = Vector2(597, 450),
			Location = Vector2(254, 43),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/lb_manage_props_popup_bg01.dds", Vector4(25, 50, 25, 50)),
			},
			Gui.Label "lbl_window_title"
			{
				Size = Vector2(577, 37),
				Location = Vector2(2, 10),
				Text = lang:GetText("大喇叭"),
				TextColor = ARGB(255, 37, 37, 37),
				TextAlign = "kAlignCenterMiddle",
				FontSize = 20,
			},
			Gui.Control
			{
				Size = Vector2(509,265),
				Location = Vector2(44, 105),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/mail/lb_mail_newmail_text_down.dds", Vector4(14, 14, 14, 14)),
				},
			},
			Gui.TextArea "neirong_text"
			{
				Size = Vector2(509,265),
				Location = Vector2(44, 105),
				TextColor = ARGB(255, 211, 211, 211),
				Fold = true,
				--HScrollBarDisplay = "kHide",
				FontSize = 20,
				Readonly = false,
				TabFocus = true,
				MaxLength = 160,
				EventTextChanged = function()
					if string.len(dlb_window_ui.neirong_text.Text) > 60 then
						flag = 0						
						dlb_window_ui.abcd.TextColor = ARGB(255, 174, 9, 9)
						if (string.len(dlb_window_ui.neirong_text.Text) - 60) % 2 == 1 then
							dlb_window_ui.abcd.Text = lang:GetText("已超出")..((string.len(dlb_window_ui.neirong_text.Text) - 60) / 2 + 0.5)..lang:GetText("字")
						else
							dlb_window_ui.abcd.Text = lang:GetText("已超出")..((string.len(dlb_window_ui.neirong_text.Text) - 60) / 2)..lang:GetText("字")
						end
					else
						flag = 1
						dlb_window_ui.abcd.TextColor = ARGB(255, 81, 79, 79)
						if (string.len(dlb_window_ui.neirong_text.Text) - 60) % 2 == 1 then
							dlb_window_ui.abcd.Text = lang:GetText("你还能输入")..((60 - string.len(dlb_window_ui.neirong_text.Text)) / 2 + 0.5)..lang:GetText("个字")
						else
							dlb_window_ui.abcd.Text = lang:GetText("你还能输入")..((60 - string.len(dlb_window_ui.neirong_text.Text)) / 2)..lang:GetText("个字")
						end
					end
				end
			},
			Gui.Label "abcd"
			{
				Size = Vector2(200,34),
				Location = Vector2(74, 370),
				BackgroundColor = ARGB(255, 255, 255, 255),
				TextAlign = "kAlignCenterMiddle",
				Text = lang:GetText("你还能输入").."30"..lang:GetText("个字"),
				FontSize = 14,
				TextColor = ARGB(255, 81, 79, 79),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/mail/lb_mail_newmail_ts_bg.dds", Vector4(14, 14, 14, 14)),
				},
			},
			Gui.Button 
			{
				Size = Vector2(101,33),
				Location = Vector2(332, 393),
				Text = lang:GetText("发 送"),
				TextColor = ARGB(255, 211, 211, 211),
				HighlightTextColor = ARGB(255, 211, 211, 211),
				FontSize = 20,
				BackgroundColor = ARGB(255,255,255,255),
				Padding = Vector4(0, 0, 0 ,7),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/lb_contact_button_normal.tga", Vector4(5, 5, 5, 5)),
					HoverImage = Gui.Image("LobbyUI/team/lb_contact_button_hover.tga", Vector4(5, 5, 5, 5)),
					DownImage = Gui.Image("LobbyUI/team/lb_contact_button_down.tga", Vector4(5, 5, 5, 5)),
					DisabledImage = Gui.Image("LobbyUI/team/lb_contact_button_normal.tga", Vector4(5, 5, 5, 5)),			
				},
				EventClick = function()
					if LobbyMainWin.lab_timer_dlb.Visible then
						MessageBox.ShowWithTimer(1, lang:GetText("喇叭功能使用太频繁，请稍候使用！"))
						return
					end
					if flag == 0 then
						MessageBox.ShowWithTimer(1, lang:GetText("字数超出限制！"))
					else
						if game.ClientAddress.channel_id > 0 then
							if game.ClientAddress.server_id > 0 and string.len(dlb_window_ui.neirong_text.Text) > 0 and prop_index > 0 then
								local message = dlb_window_ui.neirong_text.Text
								rpc.safecall("storage_item_use", {uid = ptr_cast(game.CurrentState):GetUserId(), pid = ptr_cast(game.CurrentState):GetCharacterId(), playeritemid = CharactersIB_rpc_data.items[prop_index].playeritemid, type = CharactersIB_rpc_data.items[prop_index].common.type,
								msg = Delete_Enter(message), server_id = game.ClientAddress.server_id, channel_id = game.ClientAddress.channel_id},
								function (data)
									if data.error then
										MessageBox.ShowWithConfirm(lang:GetText("使用道具失败"))
									end
									L_MessageBox.CloseWaiter()
								end)
								if L_LobbyMain.current_character_storage > 3 then
									L_LobbyMain.current_character_storage = L_Characters.current_selected_type[L_Characters.current_selected_type_index][1]
									L_LobbyMain.FillClassStorage(L_Characters.current_selected_type[L_Characters.current_selected_type_index][2])
								else
									L_LobbyMain.FillClassStorage()
								end
								HideDlbWindow()
								LobbyMainWin.lab_timer_dlb:Show()
							else
								MessageBox.ShowWithConfirm(lang:GetText("请输入您广播的内容！"))
							end
						else
							if CharactersIB_rpc_data.items[prop_index].iid == 3 then
								MessageBox.ShowWithTimer(1,lang:GetText("你发送的消息全服可见，请先进入频道!"))
							elseif CharactersIB_rpc_data.items[prop_index].iid == 2 then
								MessageBox.ShowWithTimer(1,lang:GetText("你发送的消息全频道可见，请先进入频道!"))
							end
						end
					end				
				end
			},
			Gui.Button 
			{
				Size = Vector2(101, 33),
				Location = Vector2(450, 393),
				Text = lang:GetText("取 消"),
				TextColor = ARGB(255, 211, 211, 211),
				HighlightTextColor = ARGB(255, 211, 211, 211),
				FontSize = 20,
				BackgroundColor = ARGB(255,255,255,255),
				Padding = Vector4(0, 0, 0 ,7),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/lb_contact_button_normal.tga", Vector4(5, 5, 5, 5)),
					HoverImage = Gui.Image("LobbyUI/team/lb_contact_button_hover.tga", Vector4(5, 5, 5, 5)),
					DownImage = Gui.Image("LobbyUI/team/lb_contact_button_down.tga", Vector4(5, 5, 5, 5)),
					DisabledImage = Gui.Image("LobbyUI/team/lb_contact_button_normal.tga", Vector4(5, 5, 5, 5)),			
				},
				EventClick = function()
					HideDlbWindow()
				end
			},
		},
	},
}
--大喇叭内容去回车
function Delete_Enter(szFullString)
	local nFindStartIndex = 1
	local nSplitIndex = 1
	local nSplitArray = ""
	while true do
	   local nFindLastIndex = string.find(szFullString, '\n',nFindStartIndex)
	   if not nFindLastIndex then
			nSplitArray = nSplitArray..string.sub(szFullString, nFindStartIndex, string.len(szFullString))
			break
	   end
	   nSplitArray = nSplitArray..string.sub(szFullString, nFindStartIndex, nFindLastIndex - 1)
	   nFindStartIndex = nFindLastIndex + 1
	   nSplitIndex = nSplitIndex + 1
	end
	return nSplitArray
end

function ShowDlbWindow(index)
	--界面是否存在
	if dlb_window_ui then
		dlb_window_ui.root.Parent = gui
		if dlb_window_ui then
			Gui.Align(dlb_window_ui.root, 0.5, 0.5)
			Gui.Align(dlb_window_ui.bg_root, 0.5, 0.5)
			if index == 3 then
				dlb_window_ui.lbl_window_title.Text = lang:GetText("大喇叭")
			else
				dlb_window_ui.lbl_window_title.Text = lang:GetText("小喇叭")
			end
		end
		return
	end
	--创建界面
	dlb_window_ui = Gui.Create(gui)(dlb_window)
	if dlb_window_ui then
		Gui.Align(dlb_window_ui.root, 0.5, 0.5)
		Gui.Align(dlb_window_ui.bg_root, 0.5, 0.5)
		if index == 3 then
			dlb_window_ui.lbl_window_title.Text = lang:GetText("大喇叭")
		else
			dlb_window_ui.lbl_window_title.Text = lang:GetText("小喇叭")
		end
	end
end

function HideDlbWindow()
	if dlb_window_ui then
		dlb_window_ui.root.Parent = nil
		dlb_window_ui = nil
	end
end
-- 战队改名
team_gmz_window = Gui.Create()
{
	Gui.Control "root"
	{
		Size = Vector2(1680, 1050),
		Location = Vector2(0, 0),
		BackgroundColor = ARGB(0, 255, 255, 255),
		Gui.Control "bg_root"
		{
			Size = Vector2(578, 266),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/lb_manage_props_popup_bg01.dds", Vector4(25, 50, 25, 50)),
			},
			
			Gui.Label "lbl_window_title"
			{
				Size = Vector2(568, 39),
				Location = Vector2(15, 10),
				Text = lang:GetText("战队改名"),
				TextColor = ARGB(255, 37, 37, 37),
				TextAlign = "kAlignCenterMiddle",
				FontSize = 24,
			},
			Gui.Textbox "name"
			{
				Size = Vector2(396, 41),
				Location = Vector2(97, 89),
				TextColor = ARGB(255, 0, 0, 0),
				FontSize = 24,
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/mail/lb_contact_bg3_normal.dds", Vector4(14, 14, 14, 14)),
				},
			},
			Gui.Label
			{
				Size = Vector2(308,54),
				Location = Vector2(139, 129),
				BackgroundColor = ARGB(255, 255, 255, 255),
				TextAlign = "kAlignCenterMiddle",
				Text = lang:GetText("最多可输入")..config:GetBattleGroupNameLengthMax()..lang:GetText("个字"),
				FontSize = 14,
				TextColor = ARGB(255, 81, 79, 79),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/mail/lb_mail_newmail_ts_bg.dds", Vector4(14, 14, 14, 14)),
				},
			},
			Gui.Button 
			{
				Size = Vector2(100,35),
				Location = Vector2(175, 196),
				Text = lang:GetText("确 定"),
				TextColor = ARGB(255, 211, 211, 211),
				HighlightTextColor = ARGB(255, 211, 211, 211),
				FontSize = 20,
				Padding = Vector4(0, 0, 0 ,7),
				BackgroundColor = ARGB(255,255,255,255),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/lb_contact_button_normal.tga", Vector4(5, 5, 5, 5)),
					HoverImage = Gui.Image("LobbyUI/team/lb_contact_button_hover.tga", Vector4(5, 5, 5, 5)),
					DownImage = Gui.Image("LobbyUI/team/lb_contact_button_down.tga", Vector4(5, 5, 5, 5)),
					DisabledImage = Gui.Image("LobbyUI/team/lb_contact_button_normal.tga", Vector4(5, 5, 5, 5)),			
				},
				EventClick = function()
					local Tepnum = string.find(team_gmz_window.name.Text,"　")
					local namelen = game:TextLenght(team_gmz_window.name.Text)
					if Tepnum then
						MessageBox.ShowWithTimer(2,lang:GetText("战队名不能包含空格"))
						return
					end
					-- if game:TextLenght(team_gmz_window.name.Text) > 10 then
						-- MessageBox.ShowWithTimer(2,lang:GetText("字数超出限制！"))
						-- return
					-- end
					if namelen < config:GetBattleGroupNameLengthMin() then
						MessageBox.ShowWithTimer(2,lang:GetText("战队名称过短！"))
						return
					elseif namelen > config:GetBattleGroupNameLengthMax() then
						MessageBox.ShowWithTimer(2,lang:GetText("战队名称过长！"))
						return
					end
					rpc.safecall("storage_item_use",{pid = pid, type = 4, playeritemid = CharactersIB_rpc_data.items[prop_index].playeritemid, msg = team_gmz_window.name.Text},
					function(data)
						if data.error == nil then
							MessageBox.ShowWithTimer(1,lang:GetText("修改成功"),nil)
							team_gmz_window.root.Parent = nil
							if L_LobbyMain.current_character_storage > 3 then
								L_LobbyMain.current_character_storage = L_Characters.current_selected_type[L_Characters.current_selected_type_index][1]
								L_LobbyMain.FillClassStorage(L_Characters.current_selected_type[L_Characters.current_selected_type_index][2])
							else
								L_LobbyMain.FillClassStorage()
							end
						end
					end)
				end
			},
			Gui.Button 
			{
				Size = Vector2(100,35),
				Location = Vector2(315, 196),
				Text = lang:GetText("取 消"),
				TextColor = ARGB(255, 211, 211, 211),
				HighlightTextColor = ARGB(255, 211, 211, 211),
				FontSize = 20,
				Padding = Vector4(0, 0, 0 ,7),
				BackgroundColor = ARGB(255,255,255,255),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/lb_contact_button_normal.tga", Vector4(5, 5, 5, 5)),
					HoverImage = Gui.Image("LobbyUI/team/lb_contact_button_hover.tga", Vector4(5, 5, 5, 5)),
					DownImage = Gui.Image("LobbyUI/team/lb_contact_button_down.tga", Vector4(5, 5, 5, 5)),
					DisabledImage = Gui.Image("LobbyUI/team/lb_contact_button_normal.tga", Vector4(5, 5, 5, 5)),			
				},
				EventClick = function()
					team_gmz_window.root.Parent = nil
				end
			},
		},
	},
}

local Text_table = 
{
	lang:GetText("主武器"),
	lang:GetText("副武器"),
	lang:GetText("近身武器"),
	lang:GetText("特殊武器"),
	lang:GetText("服装"),
	lang:GetText("帽子"),
	lang:GetText("饰品"),
}

function create_des_bag_item(index)
	return Gui.Control ("con_"..index)
	{
		Size = Vector2(340, 123),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_power_bg.dds", Vector4(5, 5, 5, 5)),
		},
		Gui.Label
		{
			Size = Vector2(330, 20),
			Location = Vector2(5, 5),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("InGameUI/kick/ig_tr_bg_down.dds", Vector4(8, 8, 8, 8)),
			},	
			TextPadding = Vector4(10, 0, 0, 4),
			Text = Text_table[index]..lang:GetText("战斗力"),
			FontSize = 14,
		},
		Gui.Label
		{
			Size = Vector2(330, 20),
			Location = Vector2(5, 27),
			BackgroundColor = ARGB(0, 255, 255, 255),
			Text = lang:GetText("+基本："),
			TextColor = ARGB(255, 0, 0, 0),
			FontSize = 14,
		},
		Gui.Label ("fightnum_1_"..index)
		{
			Size = Vector2(330,20),
			Location = Vector2(0, 27),
			TextAlign = "kAlignRightMiddle",
			FontSize = 16,
			TextColor = ARGB(255, 0, 0, 0),
		},
		Gui.Label
		{
			Size = Vector2(330, 20),
			Location = Vector2(5, 49),
			BackgroundColor = ARGB(0, 255, 255, 255),
			Text = lang:GetText("+强化："),
			TextColor = ARGB(255, 0, 0, 0),
			FontSize = 14,
		},
		Gui.Label ("fightnum_2_"..index)
		{
			Size = Vector2(330,20),
			Location = Vector2(0, 49),
			TextAlign = "kAlignRightMiddle",
			FontSize = 16,
			TextColor = ARGB(255, 0, 0, 0),
		},
		Gui.Label
		{
			Size = Vector2(330, 20),
			Location = Vector2(5, 71),
			BackgroundColor = ARGB(0, 255, 255, 255),
			Text = lang:GetText("+属性部件："),
			TextColor = ARGB(255, 0, 0, 0),
			FontSize = 14,
		},
		Gui.FlowLayout ("fightnum_3_"..index)
		{
			Size = Vector2(330,28),
			Location = Vector2(0, 70),
			Align = "kAlignRightMiddle",
			ControlSpace = -5,
		},
		Gui.Control
		{
			Size = Vector2(330, 2),
			Location = Vector2(5, 97),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("InGameUI/kick/ig_tr_bg_down.dds", Vector4(0, 0, 0, 0)),
			},	
		},
		Gui.FlowLayout
		{
			Size = Vector2(139, 25),
			Location = Vector2(103, 97),
			Padding = Vector4(20, 5, 5, 0),
			Align = "kAlignRightMiddle",
			Gui.Label
			{
				Size = Vector2(20, 20),
				Text = "=",
				FontSize = 30,
				TextColor = ARGB(255, 0, 0, 0),
				TextPadding = Vector4(0, 0, 0, 5),
			},
			Gui.FlowLayout ("fightnum_4_"..index)
			{
				Size = Vector2(70,20),
				Align = "kAlignRightMiddle",
			},
		},
		Gui.Control ("con_01_"..index)
		{
			Size = Vector2(80, 16),
			Location = Vector2(242, 103),
			BackgroundColor = ARGB(255, 255, 255, 255),	
		},
	}
end

-- 背包详情
ui_des_bag = Gui.Create()
{
	Gui.FlowLayout "root"
	{
		Size = Vector2(700, 514),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/mail/lb_mail_xiala_bg.dds", Vector4(10, 10, 10, 10)),
		},
		LineSpace = 3,
		ControlSpace = 3,
		Padding = Vector4(8, 5, 0, 0),
		create_des_bag_item(1),
		create_des_bag_item(2),
		create_des_bag_item(3),
		create_des_bag_item(4),
		create_des_bag_item(5),
		create_des_bag_item(6),
		create_des_bag_item(7),
	},
}

function Fill_ui_des_bag(data)
	for i = 1, 4 do
		ui_des_bag["fightnum_1_"..i].Text = data.items.weapons[i].baseItemFightNum
		ui_des_bag["fightnum_2_"..i].Text = data.items.weapons[i].strengthenItemFightNum
		CreatCtr(ui_des_bag["fightnum_3_"..i],data.items.weapons[i].combineDetail,1)
		ShowFightnums(ui_des_bag["fightnum_4_"..i], data.items.weapons[i].common.star, "lb_bg_win01_4_number_02.dds", 13.1, 17)
		ui_des_bag["con_01_"..i].Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/lb_power_equal_01.dds", Vector4(0, 0, 0, 0)),
		}
	end
	for i = 1, 3 do
		ui_des_bag["fightnum_1_"..i + 4].Text = data.items.costume[i].baseItemFightNum
		ui_des_bag["fightnum_2_"..i + 4].Text = data.items.costume[i].strengthenItemFightNum
		CreatCtr(ui_des_bag["fightnum_3_"..i + 4],data.items.costume[i].combineDetail,2)
		ShowFightnums(ui_des_bag["fightnum_4_"..i + 4], data.items.costume[i].common.star, "lb_bg_win01_4_number_02.dds", 13.1, 15)
		ui_des_bag["con_01_"..i + 4].Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/lb_power_equal_02.dds", Vector4(0, 0, 0, 0)),
		}
	end
end

function CreatCtr(Parent_layout, data, type)
	Parent_layout:OnDestroy()
	for i,v in ipairs(data) do	
		if v.level ~= 0 then
			local text = ""
			if type == 1 then
				text = "wepskillmodlv"..v.level
			else
				text = "avatarskillmod"..v.level
			end
			local control = Gui.Create()
			{
				Gui.Control "image"
				{
					Size = Vector2(28, 28),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ibt_icon/"..text..".tga", Vector4(0, 0, 0, 0)),
					},	
				},
			}
			control.image.Parent = Parent_layout
		end
	end
end

--私聊或联系队长聊天接口
function ChatPrivate(Name,vip,id)
	if Name == PersonalInfo_data.name then
		L_Friends.ShowLeaveOwnGroupCreateWin(gui,lang:GetText("您不能和自己私聊！"))
		return
	end
	if id == nil then
		id = 0
	end
	L_Friends.Name_Id = id
	L_Friends.CreatePrivateChat(Name,1)
end

--和TA一起玩接口
function GotoPlayerRoom(name,flag)
	if L_WarZone.Is_Auto_Start == true then
		return 
	end
	local myname = ""
	local state = ptr_cast(game.CurrentState, "Client.StateLobby")
	if state then
		myname = state:GetCharacterName()
	end
	-- if state and state.is_fight_team_server then
		-- 
		-- return
	-- end
	if name==myname then
		L_Friends.ShowLeaveOwnGroupCreateWin(gui,lang:GetText("您选中的是自己！"))
		return
	end
	if L_WarZone.host_character_info and L_WarZone.host_character_info.is_host == false and L_WarZone.host_character_info.ready then
		MessageBox.ShowWithTimer(1,lang:GetText("请先取消准备状态！"))
		return
	end
	RequestCharacterAddress(name,
	function(data)
		if data.online == 1 and data.address then
			for i = 0, state:GetServerCount() - 1 do
				local info = state:GetServerInfo(i,true)
				if info.id == data.address.server_id and info.isnovice == 2 then
					MessageBox.ShowWithTimer(2,lang:GetText("该名玩家正在战队战中..."))
					return
				end
				if info.id == data.address.server_id and info.isnovice == 3 then
					MessageBox.ShowWithTimer(2,lang:GetText("该名玩家正在资源争夺战中..."))
					return
				end
				if flag == false and L_WarZone.IsMatchServerById(data.address.server_id) then
					MessageBox.ShowWithTimer(2,lang:GetText("该名玩家正在匹配队伍中..."))
					return
				end
			end
			if data.address.server_id<=0 and L_WarZone.match_window_ui == nil then
				L_Friends.ShowLeaveOwnGroupCreateWin(gui,lang:GetText("玩家").."“"..name.."”"..lang:GetText("不在任何服务器内！"))
			elseif data.address.channel_id<=0 then
				L_Friends.ShowLeaveOwnGroupCreateWin(gui,lang:GetText("玩家").."“"..name.."”"..lang:GetText("不在任何频道内！"))
			elseif data.address.room_id<=0 then
				L_Friends.ShowLeaveOwnGroupCreateWin(gui,lang:GetText("玩家").."“"..name.."”"..lang:GetText("不在任何房间内！"))
			elseif not L_WarZone.IsMatchServerById(data.address.server_id) and L_WarZone.match_window_ui ~= nil then
				L_Friends.ShowLeaveOwnGroupCreateWin(gui,lang:GetText("玩家").."“"..name.."”"..lang:GetText("不在匹配服中！"))
			else
			print("data.address.server_id:",data.address.server_id)
			print("data.address.channel_id:",data.address.channel_id)
			print("data.address.room_id:",data.address.room_id)
				ptr_cast(game.CurrentState):AutoChangeRoom(data.address.server_id,data.address.channel_id,data.address.room_id)
				L_Friends.channel_id = data.address.channel_id
			end
		else
			L_Friends.ShowLeaveOwnGroupCreateWin(gui,lang:GetText("玩家").."“"..name.."”"..lang:GetText("不在线！"))
		end
	end)
end

local addressRequestCallbacks = {}
local addressRequestNames = {} --only for double check
local addressRequestCounter = 0
function RequestCharacterAddress(name, callback)
	local state = ptr_cast(game.CurrentState)
	if state then
		addressRequestCallbacks[addressRequestCounter] = callback
		addressRequestNames[addressRequestCounter] = name
		state:RequestCharacterAddress(name, addressRequestCounter)
		addressRequestCounter = addressRequestCounter+1
	end
end

function OnAddressArrived(sender, args)
	local uid = args.userdata
	if uid and uid>=0 then
		local cName = addressRequestNames[uid]
		if cName == args.name then
			local func = addressRequestCallbacks[uid]
			if func then
				local data = {}
				data.online = args.online
				data.address = args.address
				func(data)
			end
		else
			MessageBox.ShowError("Address Request names do not match")
		end
		addressRequestNames[uid] = nil
		addressRequestCallbacks[uid] = nil
	end
end

function CreatChannllist()
	local info = state:GetChannelInfo(L_Friends.channel_id - 1)
	Channl_Enter = true
--	L_Friends.CreateChatRoom(nil)
--	L_Friends.Channel_name = info.name.." "
	L_WarZone.channel_name = info.name	
	L_WarZone.channel_id = info.id
	L_WarZone.current_select_channel_info = info
	L_WarZone.SelectedChannelID = info.id
--[[	if L_Friends.Channl_Text then
		L_Friends.ChatInfoFill(L_Friends.Channel_name,L_Friends.Channl_Text,4)
	else
		L_Friends.ChatInfoFill(L_Friends.Channel_name,"",4)
	end
	if L_Friends.Create_Friend_ui then
		L_Friends.FileGroupList(MyGroup_rpc_data, AddGroup_rpc_data)
	end
]]	
	--频道聊天列表初始化
	-- L_WarZone.main_room_list_ui.Channl_List:DeleteColumns()
	-- L_WarZone.main_room_list_ui.Channl_List:AddColumn("", 15, "kAlignCenterMiddle")
	-- L_WarZone.main_room_list_ui.Channl_List:AddColumn("", 80, "kAlignLeftMiddle")
end

function ChannlListInivate()
	--战队、频道聊天列表初始化	
	LobbyMainWin.Chat_Channl_List:DeleteColumns()
	LobbyMainWin.Chat_Channl_List:AddColumn("", 15, "kAlignCenterMiddle")
	LobbyMainWin.Chat_Channl_List:AddColumn("", 170, "kAlignLeftMiddle")
end
function ChannelLeave()
	Channl_Enter = false
	L_Friends.Channel_name = nil
--[[	for i = 1 , 10 do
		if L_Friends.ChatInfo[i][2] == 4 then
			for j = 1 , L_Friends.ChatBtn_WinNumber do
				if L_Friends.ChatBTNTrait[j][2] == 4 then
					L_Friends.HideChatBTN(L_Friends.ChatInfo[i][1],j)
					break
				end
			end
			if L_Friends.ChatInfo[i][2] == 4 then
				L_Friends.HideChatBTN(L_Friends.ChatInfo[i][1],0)
			end
		end
	end
	if L_Friends.Create_Friend_ui then
		L_Friends.FileGroupList(L_LobbyMain.MyGroup_rpc_data,L_LobbyMain.AddGroup_rpc_data)
	end]]
	L_LobbyMain.EnterRoomState(true)
	print("ChannelLeaveChannelLeaveChannelLeaveChannelLeaveChannelLeaveChannelLeaveChannelLeave")
	if state.is_fight_team_server or L_FightTeam.is_in_fight_ui or L_FightTeam.is_in_invite or L_WarZone.IsMatchServer()or L_WarZone.IsMatchServer1() then
	print("213122131231231")
		L_WarZone.GetBack(1)
	end
	-- if game.ClientAddress.server_id == 19 then
		-- L_WarZone.GetBack(1)
	-- end
end
--初始化预览背包
--pid 用户Id cid角色ID
function InitAvatarPreviewInfo(pid, cid)	
	if pid == ptr_cast(game.CurrentState):GetCharacterId() then
		--预览自己
		AvatarPreviewInfo[current_choose_class][1] = CharactersInfo_rpc_data.items.weapons[1]
		AvatarPreviewInfo[current_choose_class][2] = CharactersInfo_rpc_data.items.weapons[2]
		AvatarPreviewInfo[current_choose_class][3] = CharactersInfo_rpc_data.items.weapons[3]
		AvatarPreviewInfo[current_choose_class][4] = CharactersInfo_rpc_data.items.weapons[4]
		
		AvatarPreviewInfo[current_choose_class][5] = CharactersInfo_rpc_data.items.costume[1]
		AvatarPreviewInfo[current_choose_class][6] = CharactersInfo_rpc_data.items.costume[2]
		AvatarPreviewInfo[current_choose_class][7] = CharactersInfo_rpc_data.items.costume[3]
	else
		--预览他人
		AvatarPreviewInfo[current_choose_class][1] = OtherCharactersInfo_rpc_data.items.weapons[1]
		AvatarPreviewInfo[current_choose_class][2] = OtherCharactersInfo_rpc_data.items.weapons[2]
		AvatarPreviewInfo[current_choose_class][3] = OtherCharactersInfo_rpc_data.items.weapons[3]
		AvatarPreviewInfo[current_choose_class][4] = OtherCharactersInfo_rpc_data.items.weapons[4]
		
		AvatarPreviewInfo[current_choose_class][5] = OtherCharactersInfo_rpc_data.items.costume[1]
		AvatarPreviewInfo[current_choose_class][6] = OtherCharactersInfo_rpc_data.items.costume[2]
		AvatarPreviewInfo[current_choose_class][7] = OtherCharactersInfo_rpc_data.items.costume[3]
	end
	if IsInit == 1 then
		current_preview_weapon_index = 1
	else
		current_preview_weapon_index = weapon_index
		IsInit = 1
	end
	LoadAvatar(pid)
end

--角色管理(背包\仓库)、商城(购物车\商城)预览
function ChangeAvatarPart(index)
	if current_chosse_main_page == 6 then
		--角色管理界面
		if L_Characters.current_selected_item_class == 0 then
			--背包
			if CharactersInfo_rpc_data then
				if L_Characters.current_selected_ibtn_index < 5 then
					current_preview_weapon_index = L_Characters.current_selected_ibtn_index
					AvatarPreviewInfo[current_choose_class][L_Characters.current_selected_ibtn_index] = CharactersInfo_rpc_data.items.weapons[L_Characters.current_selected_ibtn_index]
				else
					AvatarPreviewInfo[current_choose_class][L_Characters.current_selected_ibtn_index] = CharactersInfo_rpc_data.items.costume[L_Characters.current_selected_ibtn_index - 4]
				end
			else
				print("ChangeAvatarPart ERROR")
			end
		elseif L_Characters.current_selected_item_class == 1 then
			--仓库
			if CharactersIB_rpc_data then
				local item = CharactersIB_rpc_data.items[L_Characters.current_selected_ibtn_index]
				if item then
					if item.common.type == 1 then
						--武器
						current_preview_weapon_index = item.common.seq
						AvatarPreviewInfo[current_choose_class][item.common.seq] = item						
					elseif item.common.type == 2 then
						--套装
						AvatarPreviewInfo[current_choose_class][item.common.seq + 4] = item
					elseif item.common.type == 3 then
						--配饰：帽子 徽章
						AvatarPreviewInfo[current_choose_class][item.common.seq + 4] = item
					end
				else
					print("ChangeAvatarPart ERROR")
				end
			else
				print("ChangeAvatarPart ERROR")
			end
		end
	elseif current_chosse_main_page == 7 then
		--商城界面
		if L_ShoppingMall.current_selected_item_class == 0 then
			--购物车
			if L_ShoppingMall.current_selected_ibtn_index < 5 then
				current_preview_weapon_index = L_ShoppingMall.current_selected_ibtn_index
			end
			AvatarPreviewInfo[current_choose_class][L_ShoppingMall.current_selected_ibtn_index] = CharactersCartInfo[current_choose_class][L_ShoppingMall.current_selected_ibtn_index]
		elseif L_ShoppingMall.current_selected_item_class == 1 then
			--商城
			if ShoppingMallIB_rpc_data then
				local item = ShoppingMallIB_rpc_data.items[L_ShoppingMall.current_selected_ibtn_index]
				if item then
					if item.common.type == 1 then
						--武器
						current_preview_weapon_index = item.common.seq
						AvatarPreviewInfo[current_choose_class][item.common.seq] = item						
					elseif item.common.type == 2 then
						--套装
						AvatarPreviewInfo[current_choose_class][item.common.seq + 4] = item
					elseif item.common.type == 3 then
						--配饰：帽子 徽章
						AvatarPreviewInfo[current_choose_class][item.common.seq + 4] = item
					end
				else
					print("ChangeAvatarPart ERROR")
				end
			else
				print("ChangeAvatarPart ERROR")
			end
		end
	elseif current_chosse_main_page == 12 then
		--他人信息
		if L_PersonalInfo.OtherPid > 0 then
			LoadAvatar(L_PersonalInfo.OtherPid)
		else
			LoadAvatar(state:GetCharacterId())
		end
		return
	end
	
	LoadAvatar(ptr_cast(game.CurrentState):GetCharacterId())
end

--[[
function ChangeAvatarPartBuyAndEquip(index)
	if CharactersInfo_rpc_data then
		if index > 0 and index < 5 then
			current_preview_weapon_index = L_Characters.current_selected_ibtn_index
			AvatarPreviewInfo[current_choose_class][L_Characters.current_selected_ibtn_index] = CharactersInfo_rpc_data.items.weapons[L_Characters.current_selected_ibtn_index]
		elseif index > 4 then
			AvatarPreviewInfo[current_choose_class][L_Characters.current_selected_ibtn_index] = CharactersInfo_rpc_data.items.costume[L_Characters.current_selected_ibtn_index - 4]
		end
	else
		print("ERROR!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
	end
	LoadAvatar(ptr_cast(game.CurrentState):GetCharacterId())
end
]]--

--大厅底排按钮状态取消
function LobbyMainWinFootBTN()
	LobbyMainWin_Foot.btn_Mail.PushDown = false
	LobbyMainWin_Foot.btn_FightTeam.PushDown = false
	LobbyMainWin_Foot.btn_WarZone.PushDown = false
	LobbyMainWin_Foot.btn_Characters.PushDown = false
	LobbyMainWin_Foot.btn_ShoppingMall.PushDown = false
	LobbyMainWin_Foot.btn_present.PushDown = false
	LobbyMainWin_Foot.btn_Mission.PushDown = false
	LobbyMainWin_Foot.btn_Compose.PushDown = false
	LobbyMainWin_Foot.btn_TopList.PushDown = false
	--L_LobbyMain.LobbyMainWin.new.Visible = false
	--L_LobbyMain.LobbyMainWin.new1.Visible = false
	L_LobbyMain.LobbyMainWin.new_jiaose.Visible = false
	L_LobbyMain.LobbyMainWin.new_daoju.Visible = false
	L_LobbyMain.LobbyMainWin.new_daoju_dj.Visible = false
	L_LobbyMain.LobbyMainWin.new_daoju_sc.Visible = false
	L_LobbyMain.LobbyMainWin.new_daoju_kjx.Visible = false
	L_LobbyMain.LobbyMainWin.new_daoju_jiacheng.Visible = false
	L_LobbyMain.LobbyMainWin.new_daoju_lantu.Visible = false
	L_LobbyMain.LobbyMainWin.new_daoju_mingpian.Visible = false
	L_LobbyMain.LobbyMainWin.new_daoju_libao.Visible = false
end

--大喇叭
function ReceiveHorn()
	local Name = lcSysMsgBar.SenderName
	local TepSenderMSG = lcSysMsgBar.SenderMessage
	L_LobbyMain.LobbyMainWin_Header.lb_horn.Visible = true
	if Name == lang:GetText("系统公告") then
		SetHornVisible(3,Name,TepSenderMSG)
		return
	end
	SetHornVisible(1,Name,TepSenderMSG)
end

--小喇叭
function ReceiveSpraker()
	local Name = lcSysMsgBar.SenderName
	local TepSenderMSG = lcSysMsgBar.SenderMessage
	L_LobbyMain.LobbyMainWin_Header.lb_horn.Visible = true
	SetHornVisible(2,Name,TepSenderMSG)
end

--合成炫耀
function SeverPresent()
	local Name = lang:GetText("系统")
	local TepSenderMSG = lcSysMsgBar.SenderMessage
	L_LobbyMain.LobbyMainWin_Header.lb_horn.Visible = true
	SetHornVisible(4,Name,TepSenderMSG)
end

function SetHornVisible(which,Name,msg)
	L_LobbyMain.LobbyMainWin_Header.time_msg:CleanAll()
	L_LobbyMain.LobbyMainWin_Header.time_msg:AddTime(60)
	--大喇叭
	if which == 1 then
		local color = ARGB(255, 255, 255, 0)
		L_LobbyMain.LobbyMainWin_Header.re_msg:AddMsg(lang:GetText("[大喇叭]["),color,true,false)
		L_LobbyMain.LobbyMainWin_Header.re_msg:AddMsg(Name,color,false,true)
		L_LobbyMain.LobbyMainWin_Header.re_msg:AddMsg("]:",color,false,false)
		L_LobbyMain.LobbyMainWin_Header.re_msg:AddMsg(msg,color,true,false)
	--小喇叭
	elseif which == 2 then
		local color = ARGB(255, 255, 132, 0)
		L_LobbyMain.LobbyMainWin_Header.re_msg:AddMsg(lang:GetText("[小喇叭]["),color,true,false)
		L_LobbyMain.LobbyMainWin_Header.re_msg:AddMsg(Name,color,false,true)
		L_LobbyMain.LobbyMainWin_Header.re_msg:AddMsg("]:",color,false,false)
		L_LobbyMain.LobbyMainWin_Header.re_msg:AddMsg(msg,color,true,false)
	--系统公告
	elseif which == 3 then
		local color = ARGB(255, 218, 0, 6)
		L_LobbyMain.LobbyMainWin_Header.re_msg:AddMsg("["..Name.."]:",color,true,false)
		L_LobbyMain.LobbyMainWin_Header.re_msg:AddMsg(msg,color,true,false)
	--合成炫耀
	elseif which == 4 then
		local color = ARGB(255, 255, 0, 0)
		L_LobbyMain.LobbyMainWin_Header.re_msg:AddMsg("["..Name.."]:",color,true,false)
		
		--print("msg = "..msg)
		--msg = lang:GetText("@!0@!恭喜玩家@!3@!ttttt@!0@!在强化装备时，运气不错！将“@!3@!古斯塔夫火箭炮@!0@!”强化到了@!3@!10@!0@!级！战斗力大增！")
		msg_table = L_PushCmd.Split(msg,"@!")
		if PersonalInfo_data and msg_table[5] == PersonalInfo_data.name then
			gui:PlayAudio("kUIA_GET_GOOD_REWARD")
		end
		local new = true
		for i=2, #msg_table do
			--颜色
			if i % 2 == 0 then
				if tonumber(msg_table[i]) > 0 and tonumber(msg_table[i]) < 8 then
					color = L_ToolTips.font_color[tonumber(msg_table[i])]
				else
					color = ARGB(255, 255, 255, 255)
				end
			--内容
			else
				if i == 5 then
					L_LobbyMain.LobbyMainWin_Header.re_msg:AddMsg(msg_table[i],color,new,true)
				elseif i == 7 then
					if confirmLook_play_Info(tonumber(msg_table[i])) then
						Look_Indx = Look_Indx + 1
						if Look_Indx > 20 then
							Look_Indx = 1
						end
						Look_play_Info[Look_Indx] = {msg_table[i - 2],tonumber(msg_table[i])}
					end
				else
					L_LobbyMain.LobbyMainWin_Header.re_msg:AddMsg(msg_table[i],color,new,false)
				end
				new = false
			end
		end
	end
	
	L_LobbyMain.LobbyMainWin_Header.re_msg.AutoScrollPosition = Vector2(0,L_LobbyMain.LobbyMainWin_Header.re_msg.AutoScrollMinSize.y)
end

function confirmLook_play_Info(play_id)
	local Tep_i = 1
	while Look_play_Info[Tep_i] do
		if Look_play_Info[Tep_i][2] == play_id then
			return false
		end
		Tep_i = Tep_i + 1
	end
	return true
end

function CopyHorn()
	L_LobbyMain.LobbyMainWin_Header.ctr_First_born.Skin = L_LobbyMain.LobbyMainWin_Header.ctr_Second_born.Skin
	L_LobbyMain.LobbyMainWin_Header.ctr_First_born.Visible = true
	L_LobbyMain.LobbyMainWin_Header.lb_First_PlayerName.Text = L_LobbyMain.LobbyMainWin_Header.lb_Second_PlayerName.Text
	L_LobbyMain.LobbyMainWin_Header.tarea_First_Text.Text = L_LobbyMain.LobbyMainWin_Header.tarea_Second_Text.Text
	L_LobbyMain.LobbyMainWin_Header.lb_horn_First.DisplayTime = L_LobbyMain.LobbyMainWin_Header.lb_horn_Second.DisplayTime
	L_LobbyMain.LobbyMainWin_Header.lb_horn_First:Show()
	L_LobbyMain.LobbyMainWin_Header.ctr_Second_born.Visible = false				
	L_LobbyMain.LobbyMainWin_Header.lb_Second_PlayerName.Text = ""
	L_LobbyMain.LobbyMainWin_Header.tarea_Second_Text.Text = ""
	L_LobbyMain.LobbyMainWin_Header.lb_horn_Second.Visible = false	
end
function ForceLeave(sender, args)
	if L_WarZone then
		L_WarZone.GetBack(args.exit_id)
	end
end

function ReadlyState(sta)
	if L_WarZone.room_ui then
		L_WarZone.room_ui.btn_exitroom.Enable = sta
	end
end

function EnterRoomState(sta)
	L_LobbyMain.LobbyMainWin_Foot.btn_Characters.Enable = sta
	L_LobbyMain.LobbyMainWin_Foot.btn_ShoppingMall.Enable = sta
	L_LobbyMain.LobbyMainWin_Foot.btn_Mail.Enable = sta
	L_LobbyMain.LobbyMainWin_Foot.btn_FightTeam.Enable = sta
	L_LobbyMain.LobbyMainWin_Foot.btn_Mission.Enable = sta
	L_LobbyMain.LobbyMainWin_Foot.btn_Compose.Enable = sta
	L_LobbyMain.LobbyMainWin_Foot.btn_present.Enable = sta
	L_LobbyMain.LobbyMainWin_Foot.btn_TopList.Enable = sta
	LobbyMainWin_Header.daily.Enable = sta
	if OLTime ~= -2 then
		LobbyMainWin_Header.OL.Enable = sta
	end
	L_LobbyMain.LobbyMainWin.Manage_list.Enable = sta
	--L_LobbyMain.LobbyMainWin.Manage_list_back.Visible = sta
	if sta == true then
		SetmoduleState()
	end
end

function SetmoduleState()
	SetBTNstate(module_state.Mission.state,L_LobbyMain.LobbyMainWin_Foot.btn_Mission)
	SetBTNstate(module_state.Compose.state,L_LobbyMain.LobbyMainWin_Foot.btn_Compose)
	SetBTNstate(module_state.Present.state,L_LobbyMain.LobbyMainWin_Foot.btn_present)
	SetBTNstate(module_state.Shot.state,L_LobbyMain.LobbyMainWin_Header.shooting)
	
	SetBTNstate(module_state.DailyCheck.state,LobbyMainWin_Header.daily)
	if my_flag == 0 and OLTime ~= -2 then
		SetBTNstate(module_state.Online.state,LobbyMainWin_Header.OL)
	end
	if module_state.DailyCheck.state == 0 then
		LobbyMainWin_Header.daily.Visible = false
	else
		LobbyMainWin_Header.daily.Visible = true
	end
	if module_state.Shot.state == 0 then
		LobbyMainWin_Header.shooting.Visible = false
	else
		LobbyMainWin_Header.shooting.Visible = true
	end
	if module_state.Shot.state == 1 then
		L_LobbyMain.LobbyMainWin_Header.shooting.IsShowTime = true
	end
	if module_state.Mission.state == 1 then
		ShowTipsNewMission()
	end
	if module_state and module_state.Online.state ~= 0 then
		if my_flag == 0 then
			LobbyMainWin_Header.time.Visible = true
			rpc.safecall("online_award",{pid = ptr_cast(game.CurrentState):GetCharacterId()},
			function(data)
				if data.time >= 0 then
					LobbyMainWin_Header.Event:CleanAll()
					LobbyMainWin_Header.Event:AddTime(1)
					OLTime = data.time
				elseif data.time > -2 then
					OLTime = 0
				else
					OLTime = -2
				end
				OL_Award_List = data.items
				FillPresent(data.award_time)
				Present.ol_exp.Text = lang:GetText("经验奖励：")..data.currentExp
				OnUpdateTime()
			end)
			my_flag = 1
		end
	end
	
	rpc.safecall("get_compete_buy_time", {pid = ptr_cast(game.CurrentState):GetCharacterId()},
	function(data)
		if data.type == 0 then
			Sell_flag = false
			Sell_Type = 0
		elseif data.type == 1 then
			Sell_flag = false
			if data.time > 0 then
				Sell_Time = data.time
				LobbyMainWin_Header.Event_Sell:CleanAll()
				LobbyMainWin_Header.Event_Sell:AddTime(1)
				Sell_Type = 1
			end	
		elseif data.type == 2 then
			Sell_flag = true
			if data.time > 0 then
				Sell_Time = data.time
				LobbyMainWin_Header.Event_Sell:CleanAll()
				LobbyMainWin_Header.Event_Sell:AddTime(1)
				Sell_Type = 2
			end	
		end
	
	
	
	
		-- if data.time == -1 then
			-- Sell_flag = true
		-- elseif data.time > 0 then
			-- LobbyMainWin_Header.Event:CleanAll()
			-- LobbyMainWin_Header.Event:AddTime(1)
			-- Sell_Time = data.time
		-- end	
	end)
	
	if L_ShoppingMall.main_props_window_ui then
		SetBTNstate(module_state.FreeChange.state,L_ShoppingMall.main_props_window_ui.freeChang_btn)
	end
	if L_ShoppingMall.main_character_window_ui then
		SetBTNstate(module_state.FreeChange.state,L_ShoppingMall.main_character_window_ui.freeChang_btn)
	end
	if module_state.Online.state == 0 then
		LobbyMainWin_Header.OL.Visible = false
	else
		LobbyMainWin_Header.OL.Visible = true
	end
end

function SetBTNstate(state,BTN)
	if module_state_Onuse then
		BTN.Enable = true
		return
	end
	if state == 2 then
		BTN.Enable = true
	elseif state == 1 then
		BTN.Enable = true
		BTN.blink = true
	else
		--BTN.Enable = false
		BTN.blink = false
	end
end

-- num = 0任务 1每日任务 2合成 3在线时长 4博彩 5每日签到 6免费兑换
function RPCBTNDown(num,btn)
	if num == 0 then
		if module_state.Mission.state ~= 1 then
			return
		end
		module_state.Mission.state = 2
	elseif num == 1 then
		if module_state.DailyMission.state ~= 1 then
			return
		end
		module_state.DailyMission.state = 2
	elseif num == 2 then
		if module_state.Compose.state ~= 1 then
			return
		end
		module_state.Compose.state = 2
	elseif num == 3 then
		if module_state.Online.state ~= 1 then
			return
		end
		module_state.Online.state = 2
	elseif num == 4 then
		if module_state.Present.state ~= 1 then
			return
		end
		module_state.Present.state = 2
	elseif num == 5 then
		if module_state.DailyCheck.state ~= 1 then
			return
		end
		module_state.DailyCheck.state = 2
	elseif num == 6 then
		if module_state.FreeChange.state ~= 1 then
			return
		end
		module_state.FreeChange.state = 2
	elseif num == 7 then
		if module_state.Shot.state ~= 1 then
			return
		end
		module_state.Shot.state = 2
	end
	if btn then
		btn.blink = false
	end
	local args = {pid = ptr_cast(game.CurrentState):GetCharacterId(),num = num}
	rpc.safecall("module_response", args, nil)
end

function module_status_change(list)
	module_state = list
	if current_chosse_main_page == 8 then
		RPCBTNDown(0,LobbyMainWin_Foot.btn_Mission)
		L_Mission.Fill()
	end
	SetmoduleState()
end

function ShowTipsNewMission()
	L_LobbyMain.LobbyMainWin.new.Location = Vector2(1194, 810)
	L_LobbyMain.LobbyMainWin.new.NormLocation = Vector2(1194, 810)
	L_LobbyMain.LobbyMainWin.new.Visible = true
end

function FillNumber(number, control)
	local count = 1
	while number and number >= 0 do
		local temp = number % 10
		c_temp = ptr_cast(control:GetChildByIndex(4 - count))
		if c_temp then
			c_temp.Visible = true
			c_temp.Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_number.dds",Vector4(0, 0, 0, 0),Vector4((temp / 10), 0, (temp / 10 + 0.1), 1)),
			}
			if number < 10 then
				count = count + 1
				c_temp = ptr_cast(control:GetChildByIndex(4 - count))
				c_temp.Visible = true
				c_temp.Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_number_X.dds",Vector4(0, 0, 0, 0)),
				}
				count = count + 1
				while count <= 4 do
					c_temp = ptr_cast(control:GetChildByIndex(4 - count))
					c_temp.Visible = false
					count = count + 1
				end
				break
			else
				number = (number - (number % 10)) / 10
				count = count + 1
			end
		else
			return
		end
	end
end

function OnUpdateTime()	
	if module_state == nil or module_state.Online.state == 0 then
		return
	end	
	OLtime = math.floor(OLTime)
	if OLtime <= -2 then
		LobbyMainWin_Header.OL.blink = false
		LobbyMainWin_Header.OL.Enable = false
		LobbyMainWin_Header.OL.Skin = Gui.ButtonSkin
		{
			BackgroundImage = nil,
			HoverImage = nil,
			DownImage = nil,
			DisabledImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_wancheng.dds", Vector4(0, 0, 0, 0)),
			TwinkleImage  = nil
		}
		return
	elseif OLtime <= 0 then
		LobbyMainWin_Header.OL.blink = true
		--LobbyMainWin_Header.OL.Enable = true
		LobbyMainWin_Header.OL.Skin = Gui.ButtonSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_lingqujiangli.dds", Vector4(180, 0, 0, 0)),
			HoverImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_hover.dds", Vector4(0, 0, 0, 0)),
			DownImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_hover.dds", Vector4(0, 0, 0, 0)),
			DisabledImage = nil,
			TwinkleImage  = Gui.Image("LobbyUI/OL_award/lb_onlinetime_lingqujiangli.dds", Vector4(0, 0, 180, 0)),
		}
		return
	else
		--LobbyMainWin_Header.OL.Enable = true
		LobbyMainWin_Header.OL.blink = false
		LobbyMainWin_Header.OL.Skin = Gui.ButtonSkin
		{
			BackgroundImage = nil,
			HoverImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_hover.dds", Vector4(0, 0, 0, 0)),
			DownImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_hover.dds", Vector4(0, 0, 0, 0)),
			DisabledImage = nil,
			TwinkleImage  = Gui.Image("LobbyUI/OL_award/lb_onlinetime_lingqujiangli.dds", Vector4(0, 0, 180, 0)),
		}
	end
	local temp_time = nil
	local Control = ptr_cast(LobbyMainWin_Header.time:GetChildByIndex(3))
	temp_time = OLtime % 10
	Control.Skin = Gui.ControlSkin
	{
		BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_numbe.dds", Vector4(0, 0, 0, 0), Vector4((temp_time / 10), 0, (temp_time / 10) + 0.1, 1)),
	}
	local Control = ptr_cast(LobbyMainWin_Header.time:GetChildByIndex(2))
	temp_time = OLtime % 60
	temp_time = (temp_time - temp_time % 10) / 10
	Control.Skin = Gui.ControlSkin
	{
		BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_numbe.dds", Vector4(0, 0, 0, 0), Vector4((temp_time / 10), 0, (temp_time / 10) + 0.1, 1)),
	}
	local Control = ptr_cast(LobbyMainWin_Header.time:GetChildByIndex(1))
	temp_time = (OLtime - (OLtime % 60)) / 60
	temp_time = temp_time % 10
	Control.Skin = Gui.ControlSkin
	{
		BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_numbe.dds", Vector4(0, 0, 0, 0), Vector4((temp_time / 10), 0, (temp_time / 10) + 0.1, 1)),
	}
	local Control = ptr_cast(LobbyMainWin_Header.time:GetChildByIndex(0))
	temp_time = (OLtime - (OLtime % 60)) / 60
	temp_time = (temp_time - temp_time % 10) / 10 % 10
	Control.Skin = Gui.ControlSkin
	{
		BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_numbe.dds", Vector4(0, 0, 0, 0), Vector4((temp_time / 10), 0, (temp_time / 10) + 0.1, 1)),
	}
end

function PresentNumControl()
	local newControl = Gui.Create(gui)
	{
		Gui.Control "ib_donate"
		{
			Size = Vector2(70, 16),
			Location = Vector2(17, 66),
			BackgroundColor = ARGB(0, 255, 255, 255),
			Gui.Control "c1"
			{
				Size = Vector2(20, 16),
				Location = Vector2(5, 0),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Visible = false,
			},
			Gui.Control "c2"
			{
				Size = Vector2(20, 16),
				Location = Vector2(20, 0),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Visible = false,
			},
			Gui.Control "c3"
			{
				Size = Vector2(20, 16),
				Location = Vector2(35, 0),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Visible = false,
			},
			Gui.Control "c4"
			{
				Size = Vector2(20, 16),
				Location = Vector2(50, 0),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Visible = false,
			},
		},
	}
	return newControl
end

function FillPresent(time_t)
	Present.text.Text = lang:GetText("请保持在线至")..time_t..lang:GetText("，你将获得以下奖励")
	local count = 1
	for _,v in ipairs(OL_Award_List) do
		local newControl = PresentNumControl()
		btn = ptr_cast(Present.list:GetChildByIndex(count - 1))
		btn:OnDestroy()
		btn.ItemLevel = nil
		btn.Enable = true
		if v.common.type == 4 and v.common.subtype == 7 or v.common.type == 5 then
			newControl.ib_donate.Parent = btn
			L_Characters.CreatPresentNumCtr(btn, v.common.quantity, btn.Size.x, btn.Size.y)
		end
		if v.color > 0 and v.color < 8 then
			btn.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..v.name.."_"..v.color..".tga")
		else
			btn.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..v.name..".tga")
		end
		if v.common and v.common.rareLevel then
			btn.ItemLevel = Skin.rarelevel[math.ceil(v.common.rareLevel/25)]
		end
		count = count + 1
	end
	for i = count, 6 do
		btn = ptr_cast(Present.list:GetChildByIndex(i - 1))
		btn.ItemIcon = nil
		btn.Enable = false
	end
end

function CreateJiangliBTN(list,line,index)
	return Gui.ItemBoxBtn
	{
		Style = "Gui.ItemBoxBtn_ib",
		Size = Vector2(100,100),
		Location = Vector2(106*list,106*line),
		BackgroundColor = ARGB(255, 255, 255, 255),
		--BtnLocation = Vector2(45, 72),
		--BtnText = lang:GetText("购买"),
		--Enable = false,
		
		Skin = Gui.ItemBoxBtnSkin
		{
			NeutralNormalImage = Gui.Image("LobbyUI/ShoppingMall/open_box/lb_gift_biew_bg2.dds", Vector4(0, 0, 0, 0)),
			NeutralHoverImage = Gui.Image("LobbyUI/ShoppingMall/vip_chest/lb_vipgifts_slot_flash.dds", Vector4(0, 0, 0, 0)),
			NeutralSelectedImage = Gui.Image("LobbyUI/ShoppingMall/open_box/lb_gift_select_bg2.dds", Vector4(0, 0, 0, 0)),
			NeutralDisabledImage = Gui.Image("LobbyUI/ShoppingMall/vip_chest/lb_vipgifts_slot_01_disabled.dds", Vector4(0, 0, 0, 0)),
		},
		
		--ItemIcon = Gui.Icon("LobbyUI/ibt_icon/magic_4.tga"),
		Padding = Vector4(5,5,5,5),
		
		EventSelected = function(sender, e)
			if jiangli_ui and sender.Loading == false then
				for i = 1, 9 do
					local ibbtn = ptr_cast(jiangli_ui.ctr_persent:GetChildByIndex(i - 1))
					if i == index then
						ibbtn.Selected = true
						jiangli_ui.lihe_btn.Enable = true
					else
						ibbtn.Selected = false
					end
				end
			end		
			selected_ibtn_index = index
		end,
		
		EventMouseEnter = function(sender, e)
			L_ToolTips.FillToolTipsVIPPresent(index, jiangli_window.root, jiangli_list)
		end,
		EventToolTipsShow = function(sender, e)
			if jiangli_list[index] then
				local loc = sender.Location + sender.Parent.Location + sender.Parent.Parent.Location + sender.Parent.Parent.Parent.Location + sender.Parent.Parent.Parent.Parent.Location
				L_ToolTips.ShowToolTipsShowWindow(sender,Vector2(1200, 900), loc)
			end
		end,
		EventMouseLeave = function(sender, e)
			L_ToolTips.HideToolTipsWindow()
		end,
	}
end

jiangli =
{	
	Gui.Control "ctrl_view_jiangli_window"
	{
		Size = Vector2(1200,900),
		BackgroundColor = ARGB(0, 255, 255, 255),
		 Dock = "kDockCenter",
		
		Gui.Control
		{	
			--Size = Vector2(379, 480),
			Size = Vector2(384,480),
			Dock = "kDockCenter",
			BackgroundColor = ARGB(255, 255, 255, 255),
			Location = Vector2(0, 0),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/open_box/main_bar01.dds", Vector4(20, 20, 20, 20)),
			},
			Gui.Control
			{
				Size = Vector2(354,461),
				--Location = Vector2(12,9),
				Dock = "kDockCenter",
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/open_box/main_bar02.dds", Vector4(20,20,20,20)),
				},					
				Gui.Label 
				{
					Size = Vector2(354, 32),
					Location = Vector2(0, 40),
					BackgroundColor = ARGB(0, 255, 255, 255),
					Text = lang:GetText("请选择你将获得奖励"),
					FontSize = 18,
					Font = "simhei",
					TextAlign = "kAlignCenterMiddle",
					TextColor = ARGB(255, 127, 127, 127),
				},
				Gui.Control
				{
					Size = Vector2(335,330),
					Location = Vector2(9, 67),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/open_box/main_bar03.dds", Vector4(20,20,20,20)),
					},
					Gui.Control "ctr_persent"
					{
						Size = Vector2(848,424),
						Location = Vector2(11,10),
						BackgroundColor = ARGB(0, 255, 255, 255),
						
						CreateJiangliBTN(0,0,1),
						CreateJiangliBTN(1,0,2),
						CreateJiangliBTN(2,0,3),
						
						CreateJiangliBTN(0,1,4),
						CreateJiangliBTN(1,1,5),
						CreateJiangliBTN(2,1,6),
						
						CreateJiangliBTN(0,2,7),
						CreateJiangliBTN(1,2,8),
						CreateJiangliBTN(2,2,9),
					},
				},
				--确定
				Gui.Button "lihe_btn"
				{
					Size = Vector2(200,44),
					Location = Vector2(77, 407),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Text = lang:GetText("确定"),
					TextColor = ARGB(255, 229, 255, 252),
					TextAlign = "kAlignCenterMiddle",
					HighlightTextColor = ARGB(255, 229, 255, 252),
					Enable = false,

					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_normal.dds", Vector4(0, 0, 0, 0)),
						HoverImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_hover.dds", Vector4(0, 0, 0, 0)),
						DownImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_down.dds", Vector4(0, 0, 0, 0)),
						DisabledImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_disabled.dds", Vector4(0, 0, 0, 0)),
					},				
					EventClick = function(Sender ,e)
						local args = {pid = ptr_cast(game.CurrentState):GetCharacterId(), sid = jiangli_list[selected_ibtn_index].sid, piid = piid}
						rpc.safecall("storage_item_choice", args,
						function (data)
							if data.error then
								Message.ShowError(lang:GetText("领取道具失败!"))
							else
								ModalWindow.CloseAll()
								MessageBox.ShowWithTimer(1,lang:GetText("物品已放入仓库中！"))
								if L_LobbyMain.current_character_storage > 3 then
									L_LobbyMain.current_character_storage = L_Characters.current_selected_type[L_Characters.current_selected_type_index][1]
									L_LobbyMain.FillClassStorage(L_Characters.current_selected_type[L_Characters.current_selected_type_index][2])
								else
									L_LobbyMain.FillClassStorage()
								end
								gui:PlayAudio("kUIA_GETITEM")
							end
							L_MessageBox.CloseWaiter()
						end)
						if jiangli_window then	
							ModalWindow.CloseAll()
							jiangli_window = nil	
						--	L_LobbyMain.On_Invite_State = true
						end
					end
				},
			},
			--logo头图片
			Gui.Control
			{
				Size = Vector2(356,52),
				Location = Vector2(13, 0),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/open_box/title.dds", Vector4(0,0,0,0)),
				},
			},
			Gui.Button 
			{
				Size = Vector2(48, 48),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Location = Vector2(332, 0),
				Hint = lang:GetText("关闭多选一礼盒"),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_normal.dds", Vector4(10, 10, 10, 10)),
					HoverImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_hover.dds", Vector4(10, 10, 10, 10)),
					DownImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_down.dds", Vector4(10, 10, 10, 10)),
					DisabledImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_disabled.dds", Vector4(0, 0, 0, 0)),					
				},
				EventClick = function()
					if jiangli_window then	
						ModalWindow.CloseAll()
						jiangli_window = nil	
				--		L_LobbyMain.On_Invite_State = true
					end
				end
			},
		},
	},
}

function show_jiangli(p,t)
	local args = {uid = ptr_cast(game.CurrentState):GetUserId(), pid = ptr_cast(game.CurrentState):GetCharacterId(), playeritemid = p, type = t}
	rpc.safecall("storage_item_use", args, 
	function (data)
		if data.error then
			Message.ShowError(lang:GetText("使用道具失败!"))
		else
			piid = p
			jiangli_list = data.items
			ShowViewJiangliWindow()
		--	L_LobbyMain.On_Invite_State = false
		end
		L_MessageBox.CloseWaiter()
	end)	
end
function ShowViewJiangliWindow()
	if jiangli_ui == nil then
		jiangli_ui = Gui.Create()(jiangli)
	end
	if jiangli_window == nil then
		--多选一礼盒
		jiangli_window = ModalWindow.GetNew("jiangli_ui")
		jiangli_window.screen.AllowEscToExit = false
		jiangli_window.screen.Visible = false
		jiangli_window.root.Size = Vector2(1200,900)
		jiangli_window.screen.EventEscPressed = HideCharmBottleWin
		jiangli_ui.ctrl_view_jiangli_window.Parent = jiangli_window.root
		
		if jiangli_window and jiangli_window.screen then
			jiangli_window.screen.Visible = true
			gui.EventEscPressed = HideCharmBottleWin
		end
	end
	
	FillViewJiangli()
end

function FillViewJiangli()

	if jiangli_ui == nil then
		return
	end		
	jiangli_ui.lihe_btn.Enable = false
	for i = 1 , 9 do
		local ibbtn = ptr_cast(jiangli_ui.ctr_persent:GetChildByIndex(i - 1))
		ibbtn.ItemLevel = nil
		--ibbtn:OnDestroy()	
		if jiangli_list[i] then
			if jiangli_list[i].color >= 1 and jiangli_list[i].color <= 8 then
				ibbtn.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..jiangli_list[i].name.."_"..jiangli_list[i].color..".tga")
			else
				ibbtn.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..jiangli_list[i].name..".tga")
			end
			if jiangli_list[i].common and jiangli_list[i].common.rareLevel then
				ibbtn.ItemLevel = Skin.rarelevel[math.ceil(jiangli_list[i].common.rareLevel/25)]
			end
			ibbtn.Selected = false
			ibbtn.Enable = true
		else
			ibbtn.ItemIcon = nil
			ibbtn.Enable = false
			ibbtn.ItemLevel = nil
		end
	end
end

--战斗力数值显示
function ShowFightnums(Parent_layout,num,res,width,high)
	Parent_layout:OnDestroy()
	local maxFightNum = num
	local n = string.len(num)
	local Tep_which = 1
	while Tep_which <= n do
		local num = string.sub(maxFightNum,Tep_which,Tep_which)
		local Ctr_Num = CreatCtr_Num(tonumber(num),res,width,high)
		Ctr_Num.ctr_num.Parent = Parent_layout
		Tep_which = Tep_which + 1
	end
end

--总战斗力数值Ctr 生成
function CreatCtr_Num(num,res,width,high)
	local ctr = Gui.Create()
	{
		Gui.Control "ctr_num"
		{	
			Size = Vector2(12, 18),
			BackgroundColor = ARGB(255, 255, 255, 255),
		},
	}
	if res then
		ctr.ctr_num.Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/"..res, Vector4(0, 0, 0, 0), Vector4(num*0.1 , 0, (num + 1)*0.1, 1)),
		}
	else
		ctr.ctr_num.Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/lb_bg_win01_4_number.dds", Vector4(0, 0, 0, 0), Vector4(num*0.1 , 0, (num + 1)*0.1, 1)),
		}
	end
	if width and high then
		ctr.ctr_num.Size = Vector2(width, high)
	end
	return ctr
end

--战斗力填充
function ChangeBG(avatart_main_ui,fightnum,flag)
	if avatart_main_ui then
		if fightnum < 3000 then
			avatart_main_ui.character_viewer.Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_1_guang.tga", Vector4(0, 0, 0, 0)),
			}
			if flag then
				avatart_main_ui.des_button.Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_power_button_1_1_normal.dds", Vector4(0, 0, 0, 0)),
					HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_power_button_1_1_hover.dds", Vector4(0, 0, 0, 0)),
					DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_power_button_1_1_down.dds", Vector4(0, 0, 0, 0)),
					DisabledImage = nil,
				}
				avatart_main_ui.des_button_close.Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_power_button_1_2_normal.dds", Vector4(0, 0, 0, 0)),
					HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_power_button_1_2_hover.dds", Vector4(0, 0, 0, 0)),
					DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_power_button_1_2_down.dds", Vector4(0, 0, 0, 0)),
					DisabledImage = nil,
				}
				avatart_main_ui.fight_num_BG.Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_power_bg_1.dds", Vector4(0, 0, 0, 0)),
				}
			else
				avatart_main_ui.fight_num_BG.Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_power_bg_6.dds", Vector4(0, 0, 0, 0)),
				}
			end
		elseif fightnum < 6000 then
			avatart_main_ui.character_viewer.Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_2_guang.tga", Vector4(0, 0, 0, 0)),
			}
			if flag then
				avatart_main_ui.des_button.Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_power_button_2_1_normal.dds", Vector4(0, 0, 0, 0)),
					HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_power_button_2_1_hover.dds", Vector4(0, 0, 0, 0)),
					DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_power_button_2_1_down.dds", Vector4(0, 0, 0, 0)),
					DisabledImage = nil,
				}
				avatart_main_ui.des_button_close.Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_power_button_2_2_normal.dds", Vector4(0, 0, 0, 0)),
					HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_power_button_2_2_hover.dds", Vector4(0, 0, 0, 0)),
					DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_power_button_2_2_down.dds", Vector4(0, 0, 0, 0)),
					DisabledImage = nil,
				}
				avatart_main_ui.fight_num_BG.Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_power_bg_2.dds", Vector4(0, 0, 0, 0)),
				}
			else
				avatart_main_ui.fight_num_BG.Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_power_bg_7.dds", Vector4(0, 0, 0, 0)),
				}
			end
		elseif fightnum < 10000 then
			avatart_main_ui.character_viewer.Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_3_guang.tga", Vector4(0, 0, 0, 0)),
			}
			if flag then
				avatart_main_ui.des_button.Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_power_button_3_1_normal.dds", Vector4(0, 0, 0, 0)),
					HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_power_button_3_1_hover.dds", Vector4(0, 0, 0, 0)),
					DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_power_button_3_1_down.dds", Vector4(0, 0, 0, 0)),
					DisabledImage = nil,
				}
				avatart_main_ui.des_button_close.Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_power_button_3_2_normal.dds", Vector4(0, 0, 0, 0)),
					HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_power_button_3_2_hover.dds", Vector4(0, 0, 0, 0)),
					DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_power_button_3_2_down.dds", Vector4(0, 0, 0, 0)),
					DisabledImage = nil,
				}
				avatart_main_ui.fight_num_BG.Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_power_bg_3.dds", Vector4(0, 0, 0, 0)),
				}
			else
				avatart_main_ui.fight_num_BG.Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_power_bg_8.dds", Vector4(0, 0, 0, 0)),
				}
			end
		else
			avatart_main_ui.character_viewer.Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_4_guang.tga", Vector4(0, 0, 0, 0)),
			}
			if flag then
				avatart_main_ui.des_button.Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_power_button_4_1_normal.dds", Vector4(0, 0, 0, 0)),
					HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_power_button_4_1_hover.dds", Vector4(0, 0, 0, 0)),
					DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_power_button_4_1_down.dds", Vector4(0, 0, 0, 0)),
					DisabledImage = nil,
				}
				avatart_main_ui.des_button_close.Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_power_button_4_2_normal.dds", Vector4(0, 0, 0, 0)),
					HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_power_button_4_2_hover.dds", Vector4(0, 0, 0, 0)),
					DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_power_button_4_2_down.dds", Vector4(0, 0, 0, 0)),
					DisabledImage = nil,
				}
				avatart_main_ui.fight_num_BG.Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_power_bg_4.dds", Vector4(0, 0, 0, 0)),
				}
			else
				avatart_main_ui.fight_num_BG.Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_power_bg_9.dds", Vector4(0, 0, 0, 0)),
				}
			end
		end
		if ui_des_bag.root then
			ui_des_bag.root.Parent = nil
		end
		if avatart_main_ui.des_button then
			avatart_main_ui.des_button.Visible = true
			avatart_main_ui.des_button_close.Visible = false
		end
		ShowFightnums(avatart_main_ui.fightnum,fightnum)
	end
end

--功能块未开放提示窗口
local ModuleState_Win_ui = nil
local ModuleState_Window = nil
local ModuleState_Win = 
{
	Gui.Control "ctr_ModuleState_Win"
	{
		Size = Vector2(526, 272),
		Dock = "kDockCenter",
		BackgroundColor = ARGB(255, 255, 255, 255),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/lb_common_up_bg_01.dds", Vector4(200, 20, 100, 0)),
		},
			
		Gui.Control
		{
			Size = Vector2(80, 68),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Location = Vector2(40, 85),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/mokuai_title02.dds", Vector4(0, 0, 0, 0)),
			},
		},
		
		Gui.RichEdit "re_msg"
		{
			Size = Vector2(380, 200),
			Location = Vector2(145, 45),
			--Dock = "kDockCenter",
			FontSize = 18,
			BackgroundColor = ARGB(255, 255, 255, 255),
			Line_Space = 5,
			Text_Shadow = true,
			
			VScrollBarWidth = 16,
			VScrollBarButtonSize = 1,
			Style = "Gui.MessagePanel",
			AutoScroll = true,
			AutoScrollMinSize = Vector2(464, 140),
			HScrollBarDisplay = "kHide",
			VScrollBarDisplay = "kAuto",
			
		},
	
		--确定
		Gui.Button
		{
			Location = Vector2(200, 222),
			Size = Vector2(128, 40),
			BackgroundColor = ARGB(255,255,255,255),
			Text = lang:GetText("确 定"),
			TextAlign = "kAlignCenterMiddle",
			TextColor = ARGB(255,50,50,50),
			HighlightTextColor = ARGB(255, 50 ,50 ,50),
			Padding = Vector4(0, 0, 0, 5),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/lb_common_up_button_normal.dds", Vector4(20, 20, 20, 20)),
				HoverImage = Gui.Image("LobbyUI/lb_common_up_button_hover.dds", Vector4(20, 20, 20, 20)),
				DownImage = Gui.Image("LobbyUI/lb_common_up_button_down.dds", Vector4(20, 20, 20, 20)),
				DisabledImage = Gui.Image("LobbyUI/lb_common_up_button_disabled.dds", Vector4(20, 20, 20, 20)),			
			},
			
			EventClick = function()
				--MessageBox.ShowWithConfirmCancel(lang:GetText("还在制作中？"), nil)
				HideModuleWin()
			end
		},
	},
}

function ShowModuleState_Win(level,text,text_task)
	if ModuleState_Win_ui == nil then
		ModuleState_Win_ui = Gui.Create()(ModuleState_Win)
	end
	
	ModuleState_Win_ui.re_msg:CleanAll()
	ModuleState_Win_ui.re_msg:AddMsg(lang:GetText("达成以下条件开启"),ARGB(255,52, 50, 50),true,false)
	ModuleState_Win_ui.re_msg:AddMsg("“"..text.."”",ARGB(255,181, 51, 0),false,false)
	ModuleState_Win_ui.re_msg:AddMsg(": ",ARGB(255,52, 50, 50),false,false)
	ModuleState_Win_ui.re_msg:AddMsg(lang:GetText("1．等级达到"),ARGB(255,52, 50, 50),true,false)
	ModuleState_Win_ui.re_msg:AddMsg(level,ARGB(255,181, 51, 0),false,false)
	ModuleState_Win_ui.re_msg:AddMsg(lang:GetText("级  "),ARGB(255,52, 50, 50),false,false)
	ModuleState_Win_ui.re_msg:AddMsg(lang:GetText("2．完成主线任务"),ARGB(255,52, 50, 50),true,false)
	ModuleState_Win_ui.re_msg:AddMsg("“"..text_task.."”",ARGB(255,181, 51, 0),false,false)
	
	ModuleState_Window = ModalWindow.GetNew("ModuleState_Win_ui")
	ModuleState_Window.screen.AllowEscToExit = false
	ModuleState_Window.screen.Visible = false
	ModuleState_Window.root.Size = Vector2(1200,900)
	ModuleState_Window.screen.EventEscPressed = HideModuleWin
	ModuleState_Win_ui.ctr_ModuleState_Win.Parent = ModuleState_Window.root
	
	if ModuleState_Window and ModuleState_Window.screen then
		ModuleState_Window.screen.Visible = true
		gui.EventEscPressed = HideModuleWin
	end
end

function HideModuleWin()
	if ModuleState_Window and ModuleState_Window.screen then
		ModuleState_Window.screen.Visible = false
		ModuleState_Window = nil
		ModuleState_Win_ui = nil
	end
end

function GetNowModuleState(state,level,text,text_task)
	if module_state_Onuse then
		return true
	end
	if state == 0 then
		ShowModuleState_Win(level,text,text_task)
		return false
	end
	return true
end

--模块打开提示窗口
local ModuleNewOpen_Win_ui = nil
--local ModuleNewOpen_Window = nil
local ModuleName = {lang:GetText("每日任务，每周任务和活动！"),lang:GetText("合成系统！"),lang:GetText("在线时长系统！"),lang:GetText("彩盒！"),lang:GetText("每日签到系统！"),lang:GetText("免费兑换专区！"),lang:GetText("靶场系统")}
local ModuleNewOpen_Win = 
{
	Gui.Control "ctr_ModuleNewOpen_Win"
	{
		Size = Vector2(1600, 900),
		BackgroundColor = ARGB(0, 255, 255, 255),
			
		Gui.Control
		{
			Size = Vector2(800, 800),
			BackgroundColor = ARGB(0, 255, 255, 255),
			Dock = "kDockCenter",
			
			Gui.FlashControl
			{
				Text = "kaifang",
				Location = Vector2(0, 0),
				Size = Vector2(800, 800),
				BackgroundColor = ARGB(255, 255, 255, 255),
			},
			
			Gui.AnimControl "ctrl_sunshine_window"
			{
				Size = Vector2(600,600),
				Location = Vector2(100,100),
				BackgroundColor = ARGB(0, 255, 255, 255),
			},
			Gui.Control
			{
				Size = Vector2(563, 365),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Dock = "kDockCenter",
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_bg1.dds", Vector4(28, 28, 28, 28)),
				},
				
				Gui.Control
				{
					Size = Vector2(580, 50),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Location = Vector2(-10, 5),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/mokuai_title01.dds", Vector4(0, 0, 0, 0)),
					},
				},
				
				Gui.Control "ctr_back"
				{
					Size = Vector2(560, 240),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Location = Vector2(0, 55),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/dikuang.dds", Vector4(0, 0, 0, 0)),
					},
				},
				
				Gui.Label "lab_Text"
				{
					Size = Vector2(520, 35),
					Location = Vector2(20, 135),
					BackgroundColor = ARGB(0, 255, 255, 255),
					TextColor = ARGB(255,52, 50, 50),
					FontSize = 30,
					TextAlign = "kAlignCenterMiddle",
					Text = "",
				},
				
				Gui.Label "lab_Text_Modle"
				{
					Size = Vector2(520, 40),
					Location = Vector2(20, 185),
					BackgroundColor = ARGB(0, 255, 255, 255),
					TextColor = ARGB(255,181, 51, 0),
					FontSize = 36,
					TextAlign = "kAlignCenterMiddle",
					Text = "",
				},
			},
			
			--确定
			Gui.Button
			{
				Size = Vector2(124,44),
				Location = Vector2(338, 517),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Text = lang:GetText("确 定"),
				TextColor = ARGB(255, 229, 255, 252),
				TextAlign = "kAlignCenterMiddle",
				HighlightTextColor = ARGB(255, 229, 255, 252),
				Padding = Vector4(0, 0, 0, 5),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_onlinetime_button_2_normal.dds", Vector4(0, 0, 0, 0)),
					HoverImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_onlinetime_button_2_hover.dds", Vector4(0, 0, 0, 0)),
					DownImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_onlinetime_button_2_down.dds", Vector4(0, 0, 0, 0)),
					DisabledImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_onlinetime_button_2_disabled.dds", Vector4(0, 0, 0, 0)),
				},
				
				EventClick = function()
					--MessageBox.ShowWithConfirmCancel(lang:GetText("还在制作中？"), nil)
					HideModuleNewOpenWin()
				end,
			},
		},
	},
}

function ShowModuleNewOpen_Win(num)
	if ModuleNewOpen_Win_ui == nil then
		ModuleNewOpen_Win_ui = Gui.Create(gui)(ModuleNewOpen_Win)
	end
	gui:PlayAudio("kUIA_UNLOCK_MODULE")
	ModuleNewOpen_Win_ui.lab_Text.Text = lang:GetText("恭喜你开启了\n")
	ModuleNewOpen_Win_ui.lab_Text_Modle.Text = "“"..ModuleName[num].."”"
	ModuleNewOpen_Win_ui.ctr_back.Skin = Gui.ControlSkin
	{
		BackgroundImage = Gui.Image("LobbyUI/dikuang_"..num..".dds", Vector4(0, 0, 0, 0)),
	}
	ModuleNewOpen_Win_ui.ctrl_sunshine_window:AddAnim("rotation",0.5,6)
	local sun =  Gui.Icon("LobbyUI/WarZone/Present/light.dds", Vector4(0, 0, 0, 0))
	ModuleNewOpen_Win_ui.ctrl_sunshine_window:AddFrame("rotation",sun)
	ModuleNewOpen_Win_ui.ctrl_sunshine_window:StartAnimation()
	ModuleNewOpenWinAlignUI()
--[[	ModuleNewOpen_Window = ModalWindow.GetNew("ModuleNewOpen_Win_ui")
	ModuleNewOpen_Window.screen.AllowEscToExit = false
	ModuleNewOpen_Window.screen.Visible = false
	ModuleNewOpen_Window.root.Size = Vector2(1200,900)
	ModuleNewOpen_Window.screen.EventEscPressed = HideModuleNewOpenWin
	ModuleNewOpen_Win_ui.ctr_ModuleNewOpen_Win.Parent = ModuleNewOpen_Window.root
	
	if ModuleNewOpen_Window and ModuleNewOpen_Window.screen then
		ModuleNewOpen_Window.screen.Visible = true
		gui.EventEscPressed = HideModuleNewOpenWin
	end
]]	
end

function HideModuleNewOpenWin()
	if ModuleNewOpen_Win_ui then
		ModuleNewOpen_Win_ui.ctr_ModuleNewOpen_Win.Parent = nil
		ModuleNewOpen_Win_ui = nil
	end
--[[	if ModuleNewOpen_Window and ModuleNewOpen_Window.screen then
		ModuleNewOpen_Window.screen.Visible = false
		ModuleNewOpen_Window = nil
		ModuleNewOpen_Win_ui = nil
	end
	]]
end

function ModuleNewOpenWinAlignUI()
	if ModuleNewOpen_Win_ui then
		Gui.Align(ModuleNewOpen_Win_ui.ctr_ModuleNewOpen_Win, 0.5, 0.5)
	end
end
function FillLevel(level,P_parent,Exp)
	local num = 5
	local user_bg = "LobbyUI/lv"..(math.floor((level - 1)/num)*num+1).."-"..(math.ceil(level/num)*num)..".dds"
	P_parent.lb_UserLevel.Skin = Gui.ControlSkin
	{
		BackgroundImage = Gui.Image(user_bg, Vector4(0, 0, 0, 0), Vector4(0, 0, 1, 1)),
	}
	
	local level_Percentage =  1.0 
	if level == 80 then
		level_Percentage =  1.0
	else
		level_Percentage = (Exp - LevelInfo_rpc_data[level][2]) / (LevelInfo_rpc_data[level + 1][2] - LevelInfo_rpc_data[level][2])
	end
	
	local Text_Begin = (level % 10) * 0.1
	local Text_End   = Text_Begin + 0.1
	P_parent.lb_UserLevel_Anold.Skin = Gui.ControlSkin
	{
		BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_summary_number_6b.dds",Vector4(0, 0, 0, 0), Vector4(Text_Begin, 0, Text_End, 1)),		
	}
	P_parent.lb_UserLevel_AnoldState.Location = P_parent.lb_UserLevel_AnoldState.Location - Vector2(0, level_Percentage * 24)
	P_parent.lb_UserLevel_AnoldState.Size = Vector2(13,(0 + level_Percentage * 24))
	P_parent.lb_UserLevel_AnoldState.Skin = Gui.ControlSkin
	{
		BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_summary_number_7b.dds",Vector4(0, 0, 0, 0), Vector4(Text_Begin,(1 - level_Percentage), Text_End, 1)),
	}
	
	Text_Begin   = ((level-Text_Begin * 10) / 10) * 0.1
	Text_End     = Text_Begin + 0.1
	P_parent.lb_UserLevel_Ten.Skin = Gui.ControlSkin
	{
		BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_summary_number_6b.dds",Vector4(0, 0, 0, 0), Vector4(Text_Begin, 0, Text_End, 1)),
	}
	P_parent.lb_UserLevel_TenState.Location = P_parent.lb_UserLevel_TenState.Location - Vector2(0, level_Percentage * 24)
	P_parent.lb_UserLevel_TenState.Size = Vector2(13, level_Percentage * 24)
	P_parent.lb_UserLevel_TenState.Skin = Gui.ControlSkin
	{
		BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_summary_number_7b.dds",Vector4(0, 0, 0, 0), Vector4(Text_Begin,(1 - level_Percentage), Text_End, 1)),
	}
end

function SetSourceBtn(sender, index)
	L_FightTeam.team_list_ui.root.Visible = false
	L_FightTeam.team_ui.my_team.Visible = false
	L_FightTeam.allteam_source_ui.root.Visible = false
	L_FightTeam.my_source_ui.root.Visible = false
	L_FightTeam.my_source_shop.root.Visible = false
	LobbyMainWin.btn_sourcefight.PushDown = false
	LobbyMainWin.btn_my.PushDown = false
	LobbyMainWin.btn_list.PushDown = false
	sender.PushDown = true
	if index == 1 then
		L_FightTeam.allteam_source_ui.root.Visible = true
		L_FightTeam.allteam_source_ui.allteam.Visible = true
		L_FightTeam.allteam_source_ui.buildteam.Visible = false
		L_FightTeam.allteam_source_ui.buildSingle.Visible = false
		L_FightTeam.allteam_source_ui.info_btn.PushDown = true
		L_FightTeam.allteam_source_ui.person_btn.PushDown = false
		L_FightTeam.allteam_source_ui.team_btn.PushDown = false
	elseif index == 2 then
		L_FightTeam.team_ui.my_team.Visible = true
	elseif index == 3 then
		L_FightTeam.team_list_ui.root.Visible = true
	end
end
