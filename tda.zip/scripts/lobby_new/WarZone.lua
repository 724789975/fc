module("L_WarZone", package.seeall)


match_des = {
				lang:GetText("定级赛:\n玩家首次参加群雄争霸赛,前10场为定\n级比赛,根据胜场数决定初始段位.\n\n计分:\n游戏中的普通击杀,连杀,助攻都可得分,\n胜场得高分,回合失败和中途退出将会扣除\n较高分数.\n每天10场比赛后获得积分开始衰减。\n\n沉默掉分:\n专家及以上级别的玩家一段时间不上线比赛\n将开始扣除分数.")
			}


automatic_match_ui = nil	
matchTime_window  = nil	
matching_id = 0			
			
local temp = 0
local temp1 = 0
local temp12 = 0
local temp13 = 0
local temp14 = 0
local temp15 = 0
root_ui = nil
main_server_list_ui = nil
main_channel_list_ui = nil
match_window_ui = nil
match_ank_ui = nil
match_ank_ui1 = nil
match_ank_ui2 = nil
match_all_player_info = {{},{},{},{},{},{}}
match_server = false

main_room_list_ui = nil
create_room_ui = nil
matchTime_window_ui = nil
is_choose_channel = false
room_ui = nil
chatWindow = nil
current_state = 0
-- server_id = 0
server_id = 0
local server_id_mod = -1
channel_id = 0
room_id = 0
is_fight_id = false
is_source_id = false
is_pipei_id = false
is_Channelcount_id = false
local is_inboss = false
local is_inzombie = false
local is_inbosspve = false
local is_incommonzombie = false
local now_Column = 0
local server_name
channel_name = ""
local room_name
matchingisinvite = false
local in_server_first = true
local in_channel_first = true
local in_room_first = true
novice_need_in = false
Is_Auto_Start = false
local SelectedServerID = nil
SelectedChannelID = nil
local SelectedroomID = nil
local novice_server_id = nil
local novice_channel_id = nil
local battle_channel_id = nil
local room_set_password = ""
tooltip_window_ui = nil
local video_list = {}
local is_Look = false
local is_specialjob = true
local specialjob_id = 0
local moshi_num = 0
local map_num = 0
local specialjob_num = 0
local room_num = 0
local roomstate_num = 0
local needShowMatch_Time = false
local needShowMatching_Time = false
local pipeiTimes = 1
local pipeiTimes1 = 1
local leaveRoom = false
local isKickByRoom = false
local isKickByRoom1 = false
leaveGame = false

local matchtimr = 0
battle_invite = false --判断战队邀请框只弹1次
--地图资源
local rank_select_page1 = 1
local rank_select_page2 = 1
local my_rank_page = -1
local my_rank_page1 = -1 
local max_page1 = nil
local max_page2 = nil
is_invite = false
is_invite1 = false
local Map_Icons = nil

current_select_server_info = nil
current_select_channel_info = nil
current_select_room_info = nil
host_character_info = nil

state = ptr_cast(game.CurrentState)

my_game_mode = lang:GetText("全部")

local level_count = 0

game_mode_info={}

map_show_name_of_key={}

map_desc_of_key={}

map_key_of_game_type={}

map_show_name = {}

map_id={}

map_isgm = {}

kill_num={50,100,150}
item_kill_num={50,70,100}
local game_time={5,8,10,12}
common_game_round={1,2,3}
bomb_and_hero_round={3,5,9}
kTeamDeathMatch_game_round={3,5,7}
local game_dq={3,5}
local zombie_game_round={3,5,9}
local bosspve_game_round={1}
local common_zombie_game_round = {5, 7, 9}

is_novice = false
-- matchtimr = GetTriggerUnit()
			-- TimerStart(CreateTimer(),0.1,true,
			-- function()
			-- SetUnitX(matchtimr,GetUnitX(matchtimr)+1)
			-- SetUnitY(matchtimr,GetUnitY(matchtimr)+1)
			-- end
			-- )

--频道列表总页数
local channl_list_page_total = 1
local channl_list_page = 1
local channl_input_num = -1
--频道列表搜索
local Search_rpc_data = nil
local Channl_Search_state = false


local match_Begin = false
local matching_Begin = false
-- 1 游戏中/关闭 2 等待中/打开 3 不可进入  4 可以进入 5 爆满 6 火爆 7 轻松 8 通畅 9 房主名称等
local lrv_colors = {ARGB(255,254,1,0), ARGB(255,0,196,235), ARGB(255,125,125,125), ARGB(255,230,236,218), ARGB(255,254,1,0), ARGB(255,255,95,35), ARGB(255,255,216,0), ARGB(255,35,186,67),ARGB(255,255,111,56)}
--------------------------game type-------------------------------
local game_type_info_order1 =
{
{lang:GetText("全部"),"kAll",-1},
{lang:GetText("团队竞技"),"kTeam",0},
{lang:GetText("歼灭"),"kTeamDeathMatch",4},
{lang:GetText("生化感染"),"kCommonZombieMode",11},
}

local game_type_info_order =
{
	{lang:GetText("团队竞技"),"kTeam",0},
	{lang:GetText("占点"),"kHoldPoint",1},
	{lang:GetText("推车"),"kPushVehicle",2},
	{lang:GetText("歼灭"),"kTeamDeathMatch",4},
	{"BOSS","kBoss",5},
	{lang:GetText("刀战"),"kKnife",6},
	{lang:GetText("爆破"),"kBomb",7},
	{lang:GetText("英雄"),"kStreetBoy",8},
	{lang:GetText("生化"),"kZombie",9},
	{lang:GetText("审判"),"kBossPVE",10},
	{lang:GetText("生化感染"),"kCommonZombieMode",11},
	{lang:GetText("BOSS末日进化"),"kBossMode2",12},
	{lang:GetText("道具战"),"kItemMode",13},
	{lang:GetText("编辑"),"kEditMode",14},
	{lang:GetText("TD"),"kTDMode",15},
	{lang:GetText("勇者攀登"),"kMoonMode",16},
	{lang:GetText("跳跳乐"),"kAdvenceMode",17},
	{lang:GetText("生存模式"),"kSurvivalMode",18},
	
}
local game_type_key=
{
	"kTeam",
	"kHoldPoint",
	"kPushVehicle",
	"kTeamDeathMatch",
	"kBoss",
	"kKnife",
	"kBomb",
	"kStreetBoy",
	"kZombie",
	"kBossPVE",
	"kCommonZombieMode",
	"kBossMode2",
	"kItemMode",
	"kEditMode",
	"kTDMode",
	"kMoonMode",
	"kAdvenceMode",
	"kSurvivalMode",
	"kMatchingMode",
}

local setting_moshi=
{
	-- lang:GetText("全部"),
	-- lang:GetText("团队竞技"),
	-- lang:GetText("占点"),
	-- lang:GetText("推车"),
	-- lang:GetText("歼灭"),
	-- "BOSS",
	-- lang:GetText("刀战"),
	-- lang:GetText("爆破"),
	-- lang:GetText("英雄"),
	-- lang:GetText("生化"),
	-- lang:GetText("审判"),
	--lang:GetText("普通生化"),
}
local setting_moshi1=
{}
local setting_mode1 =
{}
local setting_mode =
{
	-- mode					name					isnew(普通 0 ，new 1，推荐 2，new推荐 3) isskipp

	-- {"kAll",					lang:GetText("全部"),		0,	0},
	-- {"kTeam",					lang:GetText("团队竞技"),	0,	0},
	-- {"kBossPVE",				lang:GetText("审判"),		1,	1},
	-- {"kZombie",					lang:GetText("生化"),		0,	0},
	-- {"kStreetBoy",				lang:GetText("英雄"),		0,	0},
	-- {"kBomb",					lang:GetText("爆破"),		0,	0},
	-- {"kBoss",					"BOSS",						0,	0},
	-- {"kPushVehicle",			lang:GetText("推车"),		0,	0},
	-- {"kTeamDeathMatch",			lang:GetText("歼灭"),		0,	0},
	-- {"kKnife",					lang:GetText("刀战"),		0,	0},
	-- {"kHoldPoint",				lang:GetText("占点"),		0,	0},
	-- {"kCommonZombieMode",		lang:GetText("普通生化"),	0,	0},

	-- {"kAll",			lang:GetText("全部"),		0,	0},
	-- {"kTeam",			lang:GetText("团队竞技"),	0,	0},
	-- {"kBossPVE",		lang:GetText("审判"),		1,	1},
	-- {"kZombie",			lang:GetText("生化"),		0,	0},
	-- {"kStreetBoy",		lang:GetText("英雄"),		0,	0},
	-- {"kBomb",			lang:GetText("爆破"),		0,	0},
	-- {"kBoss",			"BOSS",						0,	0},
	-- {"kPushVehicle",	lang:GetText("推车"),		0,	0},
	-- {"kTeamDeathMatch",	lang:GetText("歼灭"),		0,	0},
	-- {"kKnife",			lang:GetText("刀战"),		0,	0},
	-- {"kHoldPoint",		lang:GetText("占点"),		0,	0},

}
local setting_map1=
{}

local setting_map=
{
	-- {lang:GetText("全部"),lang:GetText("风车小镇"),lang:GetText("乡间伐木场"),lang:GetText("夜晚小镇"),lang:GetText("盛夏农场"),lang:GetText("沙之吊桥"),lang:GetText("埃及古墓"),lang:GetText("红岩谷"),lang:GetText("宫廷回廊"),lang:GetText("风暴都城"),lang:GetText("战神竞技场"),lang:GetText("激战麦田"),lang:GetText("灵石谷"),lang:GetText("神秘山丘")},
	-- {lang:GetText("全部"),lang:GetText("风车小镇"),lang:GetText("金色农场"),lang:GetText("乡间伐木场"),lang:GetText("红岩谷")},
	-- {lang:GetText("全部"),lang:GetText("法老神殿"),lang:GetText("神庙遗迹"),lang:GetText("夜晚农场"),lang:GetText("宫廷回廊")},
	-- {lang:GetText("全部"),lang:GetText("神庙遗迹"),lang:GetText("盛夏农场"),lang:GetText("阿拉伯古城"),lang:GetText("沙之吊桥"),lang:GetText("埃及古墓"),lang:GetText("风暴都城"),lang:GetText("红岩谷"),lang:GetText("战神竞技场"),lang:GetText("灵石谷"),lang:GetText("神秘山丘")},
	-- {lang:GetText("全部"),lang:GetText("阴霾教堂"),lang:GetText("失落废墟")},
	-- {lang:GetText("全部"),lang:GetText("神殿广场"),lang:GetText("神庙遗迹"),lang:GetText("夜晚小镇"),lang:GetText("激战麦田"),lang:GetText("战神竞技场"),lang:GetText("灵石谷")},
	-- {lang:GetText("全部"),lang:GetText("阿拉伯古城"),lang:GetText("沙之吊桥"),lang:GetText("风暴都城"),lang:GetText("灵石谷")},
	-- {lang:GetText("全部"),lang:GetText("九龙街区"),lang:GetText("神庙遗迹"),lang:GetText("失落废墟"),lang:GetText("埃及古墓"),lang:GetText("战神竞技场")},
	-- {lang:GetText("全部"),lang:GetText("生化研究所")},
	-- {lang:GetText("全部"),lang:GetText("毁灭之都")},
	--{lang:GetText("全部"),lang:GetText("普通生化")},
}

local setting_specialjob=
{
	lang:GetText("全部"),
	lang:GetText("火箭兵"),
	lang:GetText("重机枪手"),
	lang:GetText("狙击手"),
	lang:GetText("突击手"),
	lang:GetText("火焰兵"),
	lang:GetText("医疗兵"),
	lang:GetText("工程兵"),
}

local setting_roomnum={lang:GetText("全部"),"1","2","3","4","5","6","7","8","9","10","11","12","13","14","15"}

local setting_roomstate = 
{
	lang:GetText("全部"),
	lang:GetText("等待中"),
	lang:GetText("游戏中")
}

local game_type_table=
{
	kTeam = L_Text.kTeam,
	kHoldPoint = L_Text.kHoldPoint,
	kPushVehicle = L_Text.kPushVehicle,
	kTeamDeathMatch = L_Text.kTeamDeathMatch,
	kBoss = L_Text.kBoss,
	kKnife = L_Text.kKnife,
	kBomb = L_Text.kBomb,
	kStreetBoy = L_Text.kStreetBoy,
	kZombie = L_Text.kZombie,
	kBossPVE = L_Text.kBossPVE,
	kCommonZombieMode = L_Text.kCommonZombieMode,
	kBossMode2 = L_Text.kBossMode2,
	kItemMode = L_Text.kItemMode,
	kEditMode = L_Text.kEditMode,
	kTDMode = L_Text.kTDMode,
	kMoonMode = L_Text.kMoonMode,
	kAdvenceMode = L_Text.kAdvenceMode,
	kSurvivalMode = L_Text.kSurvivalMode,
	kMatchingMode = L_Text.kMatchingMode
}

local function game_type_index(key)
	for k, v in ipairs(game_type_key) do
		if v == key then return k end
	end
end

local function game_type(key)
	return game_type_table[key]
end
--------------------------game type end-------------------------------

--------------------------rebirth ------------------------------------
rebirth_time={0, 3, 5, 10}
local function fill_cbx_rebirth_time(cbx)
	cbx:RemoveAll()
	for i=1, #rebirth_time do
		  cbx:AddItem(rebirth_time[i] .. lang:GetText("秒"))
	end
end
local function rebirth_time_index(v)
	for k, vv in ipairs(rebirth_time) do
		if vv == v then return k end
	end
end
--------------------------rebirth end------------------------------------


--------------------------victory rule---------------------------------
local victory_rule_key=
{
	"kKillNum",
	"kPlayTime",
	"kPlayRound",
	"kBannerNum",
}

local victory_rule_table=
{
	kKillNum=L_Text.kKillNum,
	kPlayTime=L_Text.kPlayTime,
	kPlayRound=L_Text.kPlayRound,
	kBannerNum=L_Text.kBannerNum,
}

local function victory_rule_index(key)
	for k, v in ipairs(victory_rule_key) do
		if v == key then return k end
	end
end

local function victory_rule(key)
	return victory_rule_table[key]
end

local function fill_cbx_victory_rule(cbx)
	cbx:RemoveAll()
	for i=1, #victory_rule_key do
		cbx:AddItem(victory_rule_table[victory_rule_key[i]])
	end
end
--------------------------victory rule end---------------------------------

-------------------------view mode-----------------------------------------
local view_key=
{
	"kFirstView",
	"kThirdView",
}

local view_table=
{
	kFirstView=L_Text.kFirstView,
	kThirdView=L_Text.kThirdView,
}

local function view_index(key)
	for k, v in ipairs(view_key) do
		if v == key then return k end
	end
end

local function fill_cbx_view_mode(cbx)
	cbx:RemoveAll()
	for i=1, #view_key do
		cbx:AddItem(view_table[view_key[i]])
	end
end
-------------------------view mode end-----------------------------------------


------------------------win goal-----------------------------------------------
local unit_type=
{
	kKillNum=lang:GetText("个"),
	kPlayTime=lang:GetText("分钟"),
	kPlayRound=lang:GetText("回合"),
	kBannerNum=lang:GetText("夺取数"),
}

single_character_id = 
{
	0,1,2,3,4,5,6,7,
}

local character = 
{
	lang:GetText("全部"),
	lang:GetText("火箭兵"),
	lang:GetText("重机枪手"),
	lang:GetText("狙击手"),
	lang:GetText("突击手"),
	lang:GetText("火焰兵"),
	lang:GetText("医疗兵"),
	lang:GetText("工程兵"),
}

local character_Icon = 
{
	lang:GetText("全部"),
	"rocketlauncher_01.dds",
	"minigun_01.dds",
	"Sniperrifle_01.dds",
	"mk18_01.dds",
	"flame_01.dds",
	"medic01005.dds",
	"engineer01001.dds",
}

local win_goal_table=
{
	kTeam=
	{
		kKillNum=kill_num,
		kPlayTime=game_time,
	},
	
	kHoldPoint=
	{
		kPlayRound=common_game_round,
	},
	
	kPushVehicle=
	{
		kPlayRound=common_game_round,
	},
	
	kTeamDeathMatch =
	{
		kPlayRound=kTeamDeathMatch_game_round,
	},
	
	kBoss = 
	{
		kPlayRound=common_game_round,
	},
	
	kKnife = 
	{
		kKillNum=kill_num,
		kPlayTime=game_time,
	},
	
	kMoonMode = 
	{
		kPlayRound=bosspve_game_round,
	},
	
	kAdvenceMode = 
	{
		kPlayRound = bosspve_game_round,
	},
	
	kSurvivalMode = 
	{
		kPlayRound = bosspve_game_round,
	},
	
	kBomb = 
	{
		kPlayRound=bomb_and_hero_round,
	},
	
	kStreetBoy = 
	{
		kPlayRound=bomb_and_hero_round,
	},
	
	kZombie = 
	{
		kPlayRound=zombie_game_round,
	},

	kBossPVE = 
	{
		kPlayRound=bosspve_game_round,
	},
	
	kCommonZombieMode = 
	{
		kPlayRound = common_zombie_game_round
	},
	
	kBossMode2 = 
	{
		kPlayRound = game_dq
	},
	
	kItemMode = 
	{
		kKillNum=item_kill_num,
		kPlayTime=game_time,
	},
	
	kEditMode=
	{
		kKillNum=kill_num,
		kPlayTime=game_time,
	},
	kTDMode=
	{
		kKillNum=kill_num,
		kPlayTime=game_time,
	},
}  
 function fill_cbx_win_goal(cbx, gtk, win_rule)
	cbx:RemoveAll()
	if gtk and win_rule then
		local a = win_goal_table[gtk]
		if a then
			local b = a[win_rule]
			if b then
				for i=1, #b do
					cbx:AddItem(b[i] .. unit_type[win_rule])
				end
			end
		end
	end
    
	if gtk == "kTeam" then   
		cbx.SelectedIndex = 0
		create_room_option.rule_value = kill_num[cbx.SelectedIndex+1]
	elseif gtk == "kBossPVE" or gtk == "kMoonMode" or gtk == "kAdvenceMode" or gtk == "kSurvivalMode"  then
		cbx.SelectedIndex = 0
		create_room_option.rule_value = bosspve_game_round[cbx.SelectedIndex+1]
	end
end
------------------------win goal end-------------------------------------------

-------------------------war mode----------------------------------------------
local war_mode_key=
{
	"kNormal",
	--"kKnife",
}
local war_mode_table=
{
	kNormal=L_Text.kNormal,
	--kKnife=L_Text.kKnife,
}

local war_mode_key_of_kTeamDead=
{
	"kNormal",
	"kSniper",
	"kKnife",
}

local function war_mode_index(key)
	for k, v in ipairs(war_mode_key) do
		if v == key then return k end
	end
end

local function fill_cbx_war_mode(cbx)
	cbx:RemoveAll()
	for i=1, #war_mode_key do
		cbx:AddItem(war_mode_table[war_mode_key[i]])
	end
end

local function fill_cbx_single(cbx)
	cbx:RemoveAll()
	for i = 1, #single_character_id do
		cbx:AddItem(character[single_character_id[i] + 1])
	end
end

local function war_mode_index_of_kTeamDead(key)
	for k, v in ipairs(war_mode_key_of_kTeamDead) do
		if v == key then return k end
	end
end
local function fill_cbx_war_mode_of_kTeamDead(cbx)
	cbx:RemoveAll()
	for i=1, #war_mode_key_of_kTeamDead do
		cbx:AddItem(war_mode_table[war_mode_key_of_kTeamDead[i]])
	end
end

-------------------------war mode end----------------------------------------------

------------------------max player-------------------------------------------------

local max_player={2,4,6,8,10,12,14,16}
local function fill_cbx_max_player(cbx)
	cbx:RemoveAll()
	for i=1, #max_player do
		cbx:AddItem(max_player[i] .. lang:GetText("人"))
	end
end

local max_boss_player={10,12,14,16}
local function fill_cbx_boss_max_player(cbx)
	cbx:RemoveAll()
	for i=1, #max_boss_player do
		cbx:AddItem(max_boss_player[i] .. lang:GetText("人"))
	end
end

local function fill_cbx_bosspve_max_player(cbx)
	cbx:RemoveAll()
	cbx:AddItem(lang:GetText("10人"))
end

local max_zombie_player={4,6,8,10,12,14,16}
local function fill_cbx_zombie_max_player(cbx)
	cbx:RemoveAll()
	for i=1, #max_zombie_player do
		cbx:AddItem(max_zombie_player[i] .. lang:GetText("人"))
	end
end

local function max_player_index(v)
	for k, vv in ipairs(max_player) do
		if vv == v then return k end
	end
end

local view_max_player={2,4,6,8,10,12,14,16}
local function fill_cbx_view_max_player(cbx)
	cbx:RemoveAll()
	for i=1, #view_max_player do
		cbx:AddItem(view_max_player[i] .. lang:GetText("人"))
	end
end

local function view_max_player_index(v)
	for k, vv in ipairs(view_max_player) do
		if vv == v then return k end
	end
end

------------------------max player end-----------------------------------------------

------------------------------imageBrowser two button logic-----------------------------------
--first row map key
map_key1 = {}
--second row map key
map_key2 = {}
local map_key1_length = 0
local map_key2_length = 0
function init_buf_map_match_key(ib,game_type)
	map_key1 = nil
	map_key2 = nil
	map_key1 = {}
	map_key2 = {}
	local map_key = map_key_of_game_type[game_type]

	local l = 0
	
	if map_key then
		l = table.getn(map_key)
	end
     
	if l < 1 then
	
		return
	end
	
	if l <= 6 then
		ib.DisplayRowAndCol = Vector2(2 ,3)
	else
		ib.DisplayRowAndCol = Vector2(2 ,match_window_ui.ib_map.NumSkip*math.ceil(l/(match_window_ui.ib_map.NumSkip*2)))
	end
	
	local bi = true
	for i=1, #map_key, match_window_ui.ib_map.NumSkip do
		if bi then
			for j = 0,match_window_ui.ib_map.NumSkip - 1 do
				table.insert(map_key1, map_key[j+i])
			end
			bi = false
		else
			for j = 0,match_window_ui.ib_map.NumSkip - 1 do
				table.insert(map_key2, map_key[j+i])
			end
			bi = true
		end
	end

	map_key1_length = table.getn(map_key1)
	map_key2_length = table.getn(map_key2)
end



function init_buf_map_key(ib,game_type)
	map_key1 = nil
	map_key2 = nil
	map_key1 = {}
	map_key2 = {}
	local map_key = map_key_of_game_type[game_type]

	local l = 0
	
	if map_key then
		l = table.getn(map_key)
	end
     
	if l < 1 then
		--print("function init_buf_map_key(ib,game_type) length error")
		return
	end
	
	if l <= 6 then
		ib.DisplayRowAndCol = Vector2(2 ,3)
	else
		ib.DisplayRowAndCol = Vector2(2 ,create_room_ui.ib_map.NumSkip*math.ceil(l/(create_room_ui.ib_map.NumSkip*2)))
	end
	
	local bi = true
	for i=1, #map_key, create_room_ui.ib_map.NumSkip do
		if bi then
			for j = 0,create_room_ui.ib_map.NumSkip - 1 do
				table.insert(map_key1, map_key[j+i])
			end
			bi = false
		else
			for j = 0,create_room_ui.ib_map.NumSkip - 1 do
				table.insert(map_key2, map_key[j+i])
			end
			bi = true
		end
	end

	map_key1_length = table.getn(map_key1)
	map_key2_length = table.getn(map_key2)
end

function RandomMapKey(gtk)
	local map_key = map_key_of_game_type and map_key_of_game_type[gtk] or nil
	--print(gtk, map_key_of_game_type, map_key)
	if map_key then
		local i = math.random(2, #map_key)
		return map_key[i]
	end
	return ""
end

------------------------------imageBrowser two button logic end-----------------------------------

-----------------------------win_rule---------------------------------------------------------------
local win_rule_table=
{
	kTeam={"kKillNum","kPlayTime"},
	kHoldPoint={"kPlayRound"},
	kPushVehicle={"kPlayRound"},
	kKnife={"kKillNum","kPlayTime"},
}
local function whichRuleSelect(gtk, index)
	local t = win_rule_table[gtk]
	local rule = nil
	rule = t[index]
	if rule then
		return rule
	end
	error "#######whichRuleSelect#######"
end
local function whichRuleSelect_index(gtk, v --[[victory_rule--]])
	local t = win_rule_table[gtk]
	if t then
		for k, vv in ipairs(t) do
			if vv == v then 
				return k 
			end
		end
	end
end

local function fill_cbx_win_rule(cbx, gtk)
	cbx:RemoveAll()
	if gtk then
		local t = win_rule_table[gtk]
		for i=1, #t do
			cbx:AddItem(victory_rule_table[t[i]])
		end
	end
	cbx.SelectedIndex = 0
end

-----------------------------win_rule end---------------------------------------------------------------

local replay_video_window

replay_video_window_ui = Gui.Create()
{
	Gui.Control "ctrl_replay_video_window"
	{
		Size = Vector2(495,495),
		Location = Vector2(18, 4),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_bg1.dds", Vector4(28, 28, 28, 28)),
		},
		
		Gui.Control 
		{
			Size = Vector2(475, 470),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Location = Vector2(10, 10),
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_bg2.dds", Vector4(21, 25, 21, 56)),
			},
			
			Gui.ListTreeView "list_video_info"
			{
				Size = Vector2(465, 360),
				Location = Vector2(5, 40),
				TextColor = ARGB(255, 255, 186, 0),
				FontSize = 16,
				CanKeySelect = false,
				ItemHeight = 60,
				HeaderVisible = false,
				Style = "Gui.ListTreeViewWith_VScroll_Video",
				VScrollBarWidth = 12,
				VScrollBarButtonSize = 1,
				VScrollBarPos = Vector2(0, 0),
			},
			
			Gui.Button "bt_replay"
			{
				Size = Vector2(124, 44),
				Location = Vector2(65 , 426),
				Text = lang:GetText("播放"),
				TextColor = ARGB(255, 229, 255, 252),
				TextAlign = "kAlignCenterMiddle",
				HighlightTextColor = ARGB(255, 229, 255, 252),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_normal.dds", Vector4(0, 0, 0, 0)),
					HoverImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_hover.dds", Vector4(0, 0, 0, 0)),
					DownImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_down.dds", Vector4(0, 0, 0, 0)),
					DisabledImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_disabled.dds", Vector4(0, 0, 0, 0)),
				},
				
				EventClick = function(Sender ,e)
					local index = replay_video_window_ui.list_video_info.SelectingIndex
					Play(index)
				end
			},
			
			Gui.Button "bt_replay_del"
			{
				Size = Vector2(124, 44),
				Location = Vector2(285 , 426),
				Text = lang:GetText("删除"),
				TextColor = ARGB(255, 229, 255, 252),
				TextAlign = "kAlignCenterMiddle",
				HighlightTextColor = ARGB(255, 229, 255, 252),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_normal.dds", Vector4(0, 0, 0, 0)),
					HoverImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_hover.dds", Vector4(0, 0, 0, 0)),
					DownImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_down.dds", Vector4(0, 0, 0, 0)),
					DisabledImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_disabled.dds", Vector4(0, 0, 0, 0)),
				},
				
				EventClick = function(Sender ,e)
					local index = replay_video_window_ui.list_video_info.SelectingIndex
					
					index = index + 1
	
					if replay_video_window_ui.list_video_info.SelectedItem == nil then
						return
					end
					
					if video_list[index]==nil or string.len(video_list[index]) == 0 then
						return
					end
					
					MessageBox.ShowWithTwoButtons(lang:GetText("确定要删除"),lang:GetText("确认"),lang:GetText("取消"),
								function() 
									local index = replay_video_window_ui.list_video_info.SelectingIndex
									index = index + 1
									DeleteVideo(index)
								end,
								function() 
									return
								end
							)
				end
			},
		},
	}
}


replay_video_cancel_window_ui = 	Gui.Create()
{
	Gui.Button "Cancel"
	{
		Size = Vector2(48, 48),
		Location = Vector2(451,0),
		Skin = Gui.ButtonSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/WarZone/Video/lb_onlinetime_button_3_normal.dds", Vector4(0, 0, 0, 0)),
			HoverImage = Gui.Image("LobbyUI/WarZone/Video/lb_onlinetime_button_3_hover.dds", Vector4(0, 0, 0, 0)),
			DownImage = Gui.Image("LobbyUI/WarZone/Video/lb_onlinetime_button_3_down.dds", Vector4(0, 0, 0, 0)),
			DisabledImage = Gui.Image("LobByUI/WarZone/Video/lb_onlinetime_button_3_down.dds", Vector4(0, 0, 0, 0)),
		},
		
		EventClick = function()
			replay_video_window:Close()
		end,
	},
}

--房间创建窗口
local create_room_window =
{
	Gui.Control "ctrl_Main_Window"
	{
		Size = Vector2(1123, 590),
		Location = Vector2(16, 25),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_daoju_bg.dds", Vector4(22, 22, 22, 22)),
		},

		Gui.Label "lbl_RoomName"
		{
			Size = Vector2(105, 38),
			Text = lang:GetText("房间名称"),
			FontSize = 18,
			TextColor = ARGB(255, 255, 128, 0),
			Location = Vector2(14, 36),
		},
		Gui.Textbox "tbox_RoomName"
		{
			Size = Vector2(284, 38),
			FontSize = 18,
			--MaxLength = 12,
			Location = Vector2(141, 36),
			Text = lang:GetText("大冲锋"),
			TextColor = ARGB(255,195,189,176),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_rank_bg_01.dds", Vector4(5, 5, 5, 5)),
			},
		},
		
		Gui.CheckBox "cbox_PassWord"
		{
			Location = Vector2(477, 43),
			TextColor = ARGB(255, 207, 221, 230),
			Size = Vector2(25,25),
		},

		Gui.Label "lbl_PassWord"
		{
			Size = Vector2(80, 38),
			Text = lang:GetText("密码"),
			FontSize = 18,
			TextColor = ARGB(255, 255, 128, 0),
			Location = Vector2(501, 36),
		},

		Gui.Textbox "tbox_PassWord"
		{
			Size = Vector2(233, 38),
			FontSize = 18,
			Location = Vector2(581, 36),
			TextColor = ARGB(255,195,189,176),
			TextPassword = true,
			InputNumberCharacterOnly = true,
			MaxLength = 6,
			Enable = false,
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_rank_bg_01.dds", Vector4(5, 5, 5, 5)),
			},
		},

		Gui.Label "lbl_GameType"
		{
			Size = Vector2(105, 36),
			Text = lang:GetText("游戏模式"),
			TextColor = ARGB(255, 255, 128, 0),
			FontSize = 18,
			Location = Vector2(14, 84),
		},

		Gui.ComboBox "cbx_Mode"
		{
			Style = "Gui.WarZoneCreateComboBox",
			Size = Vector2(284, 38),
			FontSize = 18,
			Readonly = true,
			Location = Vector2(141, 87),
			TextColor = ARGB(255,206,227,234),
			ChildComboListStyle =  "Gui.ChangeJobComboList",
			WithIconOffset = Vector2(240,0),
		},
				
		Gui.Label "lbl_map"
		{
			Size = Vector2(105, 36),
			Text = lang:GetText("地图"),
			FontSize = 18,
			TextColor = ARGB(255, 255, 128, 0),
			Location = Vector2(14, 132),
		},
		
		Gui.Control "image_map"
	    {
	    	Size = Vector2(670, 350),
			Location = Vector2(141, 133),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg3.dds", Vector4(16, 16, 16, 16)),
			},
			
			Gui.Control
			{
				Size = Vector2(645, 350),
				Location = Vector2(0, 10),
				BackgroundColor = ARGB(0, 255, 255, 255),
					
				Gui.ImageBrowser "ib_map"
				{
					Location = Vector2(10, 10),
					Dock = "kDockFill",
					DisplayRowAndCol = Vector2(2, 3),
					NumSkip = 3,
					PictureStyle = "Gui.PictureMapInBrowser",
					PWidth = 195,
					PHeight = 132,
				},
			}
		},
		
		Gui.Button "m_Left"
		{	Size = Vector2(44, 32),
			Visible = true,
			Location = Vector2(385,440),
			TextColor = ARGB(255, 209, 227, 221),
			
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ib_common_nextpage_button_normal.dds", Vector4(5, 5, 10, 5)),
				HoverImage = Gui.Image("LobbyUI/ib_common_nextpage_button_hover.dds", Vector4(5, 5, 10, 5)),
				DownImage = Gui.Image("LobbyUI/ib_common_nextpage_button_down.dds", Vector4(5, 5, 10, 5)),
				DisabledImage = Gui.Image("LobbyUI/ib_common_nextpage_button_normal.dds", Vector4(5, 5, 10, 5)),
			},
		},
		
		Gui.Button "m_Right"
		{
			Size = Vector2(44, 32),
			Visible = true,
			Location = Vector2(515,440),
			TextColor = ARGB(255, 209, 227, 221),
			
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ib_common_nextpage_button02_normal.dds", Vector4(5, 5, 10, 5)),
				HoverImage = Gui.Image("LobbyUI/ib_common_nextpage_button02_hover.dds", Vector4(5, 5, 10, 5)),
				DownImage = Gui.Image("LobbyUI/ib_common_nextpage_button02_down.dds", Vector4(5, 5, 10, 5)),
				DisabledImage = Gui.Image("LobbyUI/ib_common_nextpage_button02_normal.dds", Vector4(5, 5, 10, 5)),
			},

		},
		
		Gui.Button "m_PageDisplay"
		{
			Size = Vector2(75,31),
			FontSize = 24,
			Visible = true,
			Location = Vector2(435,440),
			TextColor = ARGB(255, 37, 37, 37),
			HighlightTextColor = ARGB(255, 37, 37, 37),
			TextAlign = "kAlignCenterMiddle",
			Text = "1/1",
			BackgroundColor = ARGB(255, 255, 255, 255),
			
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/team/lb_common_fanye_down.tga", Vector4(5, 5, 10, 5)),
				--HoverImage = Gui.Image("LobbyUI/team/lb_common_fanye_down.tga", Vector4(5, 5, 10, 5)),
				--DownImage = Gui.Image("LobbyUI/team/lb_common_fanye_down.tga", Vector4(5, 5, 10, 5)),
				DisabledImage = Gui.Image("LobbyUI/team/lb_common_fanye_down.tga", Vector4(5, 5, 10, 5)),
			},
		},


		Gui.Label "lbl_Special"
		{
			Visible = false,
			Size = Vector2(228, 29),
			Text = lang:GetText("特殊职业战"),
			FontSize = 20,
			TextColor = ARGB(255, 254, 174, 1),
			Location = Vector2(859, 36),
			TextAlign = "kAlignCenterMiddle",
		},
		Gui.ComboBox "cbx_Special"
		{
			Style = "Gui.WarZoneComboBox",
			Visible = false,
			Size = Vector2(228, 36),
			FontSize = 18,
			Readonly = true,
			Location = Vector2(859, 65),
			TextColor = ARGB(255,206,227,234),
			ChildComboListStyle =  "Gui.teamComboList",
		},
		
		Gui.Label "lbl_Single"
		{
			Size = Vector2(228, 29),
			Text = lang:GetText("特殊职业战"),
			FontSize = 20,
			TextColor = ARGB(255, 254, 174, 1),
			Location = Vector2(859, 56),
			TextAlign = "kAlignCenterMiddle",
		},
		Gui.ComboBox "cbx_Single"
		{
			Style = "Gui.WarZoneComboBox",
			Size = Vector2(228, 36),
			FontSize = 18,
			Readonly = true,
			Location = Vector2(859, 85),
			TextColor = ARGB(255,206,227,234),
			ChildComboListStyle =  "Gui.teamComboList",
		},

		Gui.Label "lbl_Condition"
		{
			Size = Vector2(228, 29),
			Text = lang:GetText("胜利条件"),
			FontSize = 20,
			TextColor = ARGB(255, 254, 174, 1),
			Location = Vector2(859, 131),
			TextAlign = "kAlignCenterMiddle",
		},
		Gui.ComboBox "cbx_Condition"
		{
			Style = "Gui.WarZoneComboBox",
			Size = Vector2(228, 36),
			FontSize = 18,
			Readonly = true,
			Location = Vector2(859, 160),
			TextColor = ARGB(255,206,227,234),
			ChildComboListStyle =  "Gui.teamComboList",
		},

		Gui.Label "lbl_Number"
		{
			Size = Vector2(228, 29),
			Text = lang:GetText("游戏人数"),
			FontSize = 20,
			TextColor = ARGB(255, 254, 174, 1),
			Location = Vector2(859, 206),
			TextAlign = "kAlignCenterMiddle",
		},
		Gui.ComboBox "cbx_Number"
		{
			Style = "Gui.WarZoneComboBox",
			Size = Vector2(228, 36),
			FontSize = 18,
			Readonly = true,
			Location = Vector2(859, 235),
			TextColor = ARGB(255,206,227,234),
			ChildComboListStyle = "Gui.teamComboList",
		},

		Gui.Label "lbl_Time"
		{
			Size = Vector2(228, 29),
			Text = lang:GetText("复活等待时间"),
			FontSize = 20,
			TextColor = ARGB(255, 254, 174, 1),
			Location = Vector2(859, 281),
			TextAlign = "kAlignCenterMiddle",
		},
		Gui.ComboBox "cbx_Time"
		{
			Style = "Gui.WarZoneComboBox",
			Size = Vector2(228, 36),
			FontSize = 18,
			Readonly = true,
			Location = Vector2(859, 310),
			TextColor = ARGB(255,206,227,234),
			ChildComboListStyle =  "Gui.teamComboList",
		},

		Gui.CheckBox "cbox_PlayJoin"
		{
			Location = Vector2(863, 371),
			TextColor = ARGB(255, 207, 221, 230),
			Size = Vector2(25, 25),
		},

		Gui.Label "lbl_PlayJoin"
		{
			Size = Vector2(150, 26),
			Text = lang:GetText("中途加入"),
			FontSize = 20,
			TextColor = ARGB(255, 215, 232, 227),
			Location = Vector2(887, 369),
		},

		Gui.CheckBox "cbox_Balance"
		{
			Location = Vector2(863, 412),
			TextColor = ARGB(255, 207, 221, 230),
			Size = Vector2(25, 25),
			Check = false,
			Visible = true,
		},

		Gui.Label "lbl_Balance"
		{
			Size = Vector2(150, 26),
			Text = lang:GetText("战力平衡"),
			FontSize = 20,
			TextColor = ARGB(255, 215, 232, 227),
			Location = Vector2(887, 410),
			Visible = true,
		},
		
		Gui.CheckBox "cbox_AutoStart"
		{
			Location = Vector2(863, 453),
			TextColor = ARGB(255, 207, 221, 230),
			Size = Vector2(25, 25),
			Visible = true,
			Check = false,
			Enable = false,
		},

		Gui.Label "lbl_AutoStart"
		{
			Size = Vector2(150, 26),
			Text = lang:GetText("自动开始"),
			FontSize = 20,
			TextColor = ARGB(255, 215, 232, 227),
			Location = Vector2(887, 451),
			Visible = true,
		},
		
		Gui.CheckBox "cbox_Kniefmode"
		{
			Location = Vector2(903, 494),
			TextColor = ARGB(255, 207, 221, 230),
			Size = Vector2(25, 25),
			Check = false,
			Enable = true,
			Visible = false,
		},

		Gui.Label "lbl_Kniefmode"
		{
			Size = Vector2(150, 26),
			Text = lang:GetText("刀战"),
			FontSize = 20,
			TextColor = ARGB(255, 215, 232, 227),
			Location = Vector2(927, 492),
			Visible = false,
		},


		--创建
		Gui.Button "btn_Create"
		{
			Size = Vector2(221, 52),
			Location = Vector2(302 , 497),
			Text = lang:GetText("创建"),
			TextColor = ARGB(255, 255, 255, 255),
			HighlightTextColor = ARGB(255, 255, 255, 255),
			FontSize = 24,
			Margin = Vector4(10, 10, 10, 10),
			PushDown = false,
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_battlecreate_button_create_normal.dds", Vector4(20, 20, 20, 20)),
				HoverImage = Gui.Image("LobbyUI/WarZone/lb_battlecreate_button_create_hover.dds", Vector4(20, 20, 20, 20)),
				DownImage = Gui.Image("LobbyUI/WarZone/lb_battlecreate_button_create_down.dds", Vector4(20, 20, 20, 20)),
				DisabledImage = Gui.Image("LobbyUI/WarZone/lb_battlecreate_button_create_disabled.dds", Vector4(20, 20, 20, 20)),
			},
		},

		--取消
		Gui.Button "btn_Cannel"
		{
			Size = Vector2(221, 52),
			Location = Vector2(550 , 497),
			Text = lang:GetText("取消"),
			TextColor = ARGB(255, 255, 255, 255),
			HighlightTextColor = ARGB(255, 255, 255, 255),
			FontSize = 24,
			Margin = Vector4(10, 10, 10, 10),
			PushDown = false,
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_battlecreate_button_create_normal.dds", Vector4(20, 20, 20, 20)),
				HoverImage = Gui.Image("LobbyUI/WarZone/lb_battlecreate_button_create_hover.dds", Vector4(20, 20, 20, 20)),
				DownImage = Gui.Image("LobbyUI/WarZone/lb_battlecreate_button_create_down.dds", Vector4(20, 20, 20, 20)),
				DisabledImage = Gui.Image("LobbyUI/WarZone/lb_battlecreate_button_create_disabled.dds", Vector4(20, 20, 20, 20)),
			},
			EventClick = function()
				if create_room_ui.btn_Cannel.Text == lang:GetText("返　回") then
					GetBack(5)
				else
					is_inboss = false
					is_inzombie = false
					is_inbosspve = false
					is_incommonzombie = false
					create_room_ui.ctrl_Main_Window.Parent = nil
					create_room_ui = nil
					GetBack(current_state)	
				end
			end,
		},
	},
}


--房间窗口
local room_window =
{
	Gui.Control "ctrl_Main_Window"
	{
		Size = Vector2(1150, 610),
		Location = Vector2(0, 10),
		BackgroundColor = ARGB(0, 255, 255, 255),

		Gui.Control "ctrl_AD_Window_BG"
		{
			Size = Vector2(347, 584),
			Location = Vector2(21, 16),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/lb_bg_win02.dds", Vector4(16, 16, 16, 16)),
			},
			
			Gui.Control "ctrl_AD_Window"
			{
				Size = Vector2(337, 574),
				Location = Vector2(6, 6),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_daoju_bg.dds", Vector4(22, 22, 22, 22)),
				},
				
				Gui.Control "list_info_BG"
				{
					Location = Vector2(12, 12),
					Size = Vector2(314,274),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_room_left_bg.dds", Vector4(12, 12, 12, 0)),
					},
				
					Gui.ItemPicture "ctrl_small_map"
					{
						Size = Vector2(240, 148),
						Location = Vector2(37, 5),
						BackgroundColor = ARGB(255, 255, 255, 255),
					},
					
					Gui.Button "Tips"
					{
						Size = Vector2(68, 68),
						Location = Vector2(28, -2),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Enable = true,
						--blinkwheelTimer = 0.6,
						blink = true,
						blink_shade = true,
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = nil,
							TwinkleImage = nil,
						},
						Visible = false,
					},
					
					Gui.Control "knife_tips"
					{
						Size = Vector2(40, 52),
						Location = Vector2(230, 6),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_knife_ico.dds", Vector4(0, 0, 0, 0)),
						},
						Visible = false,
					},
					
					--查看房间信息
					Gui.Button "look_up"
					{
						Size = Vector2(39, 33),
						Location = Vector2(276, 120),
						BackgroundColor = ARGB(255, 255, 255, 255),
						
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/Compose/lb_melting_button_06_normal.dds", Vector4(0, 0, 0, 0)),
							HoverImage = Gui.Image("LobbyUI/Compose/lb_melting_button_06_hover.dds", Vector4(0, 0, 0, 0)),
							DownImage = Gui.Image("LobbyUI/Compose/lb_melting_button_06_down.dds", Vector4(0, 0, 0, 0)),
							DisabledImage = Gui.Image("LobbyUI/Compose/lb_melting_button_06_disabled.dds", Vector4(0, 0, 0, 0)),
						},
						
						EventClick = function(sender,e)
							ShowRoomInfo(root_ui)
						end
					},
					
					Gui.ListTreeView "list_room_info"
					{
						Size = Vector2(512, 264),
						Location = Vector2(-5, 158),
						Style = "Gui.ListTreeViewWith_Nothing",
						CanKeySelect = false,
						ItemHeight = 23,
						FontSize = 14,
						TextColor = ARGB(255, 216, 217, 208),
						UseFistColumn = true,
						UseColumnNum = 0,
						UseColFontSize = 14,
						UseColFontCol = ARGB(255, 215, 232, 227),
					},
				},

--[[				Gui.Control "ctrl_btn_setroom"
				{
					Size = Vector2(162, 80),
					Location = Vector2(80, 475),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Visible = false,
					
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/lb_common_button_bg01.dds", Vector4(20, 20, 20, 20)),
					},
					
						--房间设置
					Gui.Button "btn_room_option"
					{
						Size = Vector2(150, 72),
						Location = Vector2(5 , 5),
						TextColor = ARGB(255, 255, 246, 235),
						FontSize = 18,
						PushDown = flase,
						
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_setting_normal.dds", Vector4(5, 5, 5, 5)),
							HoverImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_setting_hover.dds", Vector4(5, 5, 5, 5)),
							DownImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_setting_down.dds", Vector4(5, 5, 5, 5)),
							DisabledImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_setting_disabled.dds", Vector4(5, 5, 5, 5)),
						},
					},
				},]]
				Gui.Control
				{
					Size = Vector2(323, 310),
					Location = Vector2(7, 260),
					BackgroundColor = ARGB(255, 255, 255, 255),
					
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/Friends/lb_battlefield_chat_bg_01.dds", Vector4(14, 14, 14, 14)),
					},
					
					Gui.MessagePanel "MesPanel_room"
					{
						Style = "Gui.MessagePanel",
						Size = Vector2(310, 270),
						Location = Vector2(3, 5),
						BackgroundColor = ARGB(0, 255, 255, 255),
						VisibleLine = 15,
						ScrollBarWidth = 16,
						
						ButtonHeight = 1,
						ButHeight = 17,
						MaxAllLine = 128,
						
						EventClick_Name = function()
							L_LobbyMain.ChatPrivate(room_ui.MesPanel_room.Click_Name)
						end
					},
					
					Gui.Control
					{
						Size = Vector2(323, 30),
						Location = Vector2(0, 274),
						BackgroundColor = ARGB(0, 255, 255, 255),
						
						Gui.Control "ctr_Tex_back"
						{
							Size = Vector2(307, 25),
							Location = Vector2(8, 2),
							BackgroundColor = ARGB(255, 255, 255, 255),
							
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/Friends/lb_battlefield_chat_bg_02_down.dds", Vector4(4, 4, 4, 4)),
							},
						},
						
						Gui.Textbox "Tex_room"
						{
							Size = Vector2(182, 25),
							Location = Vector2(78, 2),
							BackgroundColor = ARGB(0, 255, 255, 255),
							MaxLength = 120,
							TextPadding = Vector4(0, 0, 0, 0),
							
							EventValueEnter = function(sender, e)
								SpeakType(room_ui.BTN_Tex_sta,"/room",room_ui.Tex_room)
							end,
							
							EventEnter = function()
								room_ui.ctr_Tex_back.Skin = Gui.ControlSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/Friends/lb_battlefield_chat_bg_02_down.dds", Vector4(4, 4, 4, 4)),
								}
							end,
							
							EventLeave = function()
								room_ui.ctr_Tex_back.Skin = Gui.ControlSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/Friends/lb_battlefield_chat_bg_02_normal.dds", Vector4(4, 4, 4, 4)),
								}
							end,
						},
						
						Gui.Button "BTN_Tex_sta"
						{
							Size = Vector2(60,19),
							Location = Vector2(12, 5),
							TextAlign = "kAlignCenterMiddle",
							Text = lang:GetText("当前"),
							FontSize = 12,
							TextColor = ARGB(255, 214, 212, 207),
							HighlightTextColor = ARGB(255, 214, 212, 207),
							Skin = Gui.ButtonSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/Friends/lb_battlefield_button_01_normal.dds", Vector4(4, 4, 4, 4)),
								HoverImage = Gui.Image("LobbyUI/Friends/lb_battlefield_button_01_hover.dds", Vector4(4, 4, 4, 4)),
								DownImage = Gui.Image("LobbyUI/Friends/lb_battlefield_button_01_down.dds", Vector4(4, 4, 4, 4)),
								DisabledImage = Gui.Image("LobbyUI/Friends/lb_battlefield_button_01_normal.dds", Vector4(4, 4, 4, 4)),
							},
							EventClick = function()
								room_ui.ctr_BTN_Choose.Visible = true
								room_ui.lab_timer_ctr.UseTimer = true
								room_ui.lab_timer_ctr:Show()	
							end,
						},
						
						Gui.Button
						{
							Size = Vector2(32,19),
							Location = Vector2(265, 5),
							Skin = Gui.ButtonSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/Friends/lb_battlefield_button_02_normal.dds", Vector4(4, 4, 4, 4)),
								HoverImage = Gui.Image("LobbyUI/Friends/lb_battlefield_button_02_hover.dds", Vector4(4, 4, 4, 4)),
								DownImage = Gui.Image("LobbyUI/Friends/lb_battlefield_button_02_down.dds", Vector4(4, 4, 4, 4)),
								DisabledImage = Gui.Image("LobbyUI/Friends/lb_battlefield_button_02_normal.dds", Vector4(4, 4, 4, 4)),
							},
							EventClick = function()
								SpeakType(room_ui.BTN_Tex_sta,"/room",room_ui.Tex_room)
							end,
						},
						
						Gui.Button
						{
							Size = Vector2(16,19),
							Location = Vector2(295, 5),
							TextColor = ARGB(255, 37, 37, 37),
							HighlightTextColor = ARGB(255, 37, 37, 37),
							FontSize = 12,
							TextAlign = "kAlignCenterMiddle",
							Text = "C",
							Padding = Vector4(0, 0, 0, 0),
							Skin = Gui.ButtonSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/Friends/lb_battlefield_button_01_normal.dds", Vector4(4, 4, 4, 4)),
								HoverImage = Gui.Image("LobbyUI/Friends/lb_battlefield_button_01_hover.dds", Vector4(4, 4, 4, 4)),
								DownImage = Gui.Image("LobbyUI/Friends/lb_battlefield_button_01_down.dds", Vector4(4, 4, 4, 4)),
								DisabledImage = Gui.Image("LobbyUI/Friends/lb_battlefield_button_01_normal.dds", Vector4(4, 4, 4, 4)),
							},
							EventClick = function()
								room_ui.MesPanel_room:ClearLines()
							end,
						},
					},
					
					Gui.Control "ctr_BTN_Choose"
					{
						Size = Vector2(95, 70),
						Location = Vector2(8, 205),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Visible = false,
						
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_summary_flop_bg_04.dds", Vector4(30 , 30, 30, 30)),
						},
						
						EventMouseEnter = function()
							room_ui.lab_timer_ctr.UseTimer = false
							room_ui.lab_timer_ctr:Show()
						end,
						
						EventMouseLeave = function()
							room_ui.lab_timer_ctr.UseTimer = true
							room_ui.lab_timer_ctr:Show()
						end,
						
						Gui.Label "lab_timer_ctr"
						{
							Size = Vector2(10,10),
							Location = Vector2(0, 0),
							BackgroundColor = ARGB(0, 255, 255, 255),
							Visible = false,
							UseTimer = true,
							DisplayTime = 5,
							
							EventClose = function()
								room_ui.ctr_BTN_Choose.Visible = false
							end,
						},
						
						Gui.Button
						{
							Size = Vector2(91,20),
							Location = Vector2(0, 5),
							TextColor = ARGB(255, 214, 212, 207),
							HighlightTextColor = ARGB(255, 214, 212, 207),
							BackgroundColor = ARGB(0, 255, 255, 255),
							FontSize = 14,
							TextAlign = "kAlignLeftMiddle",
							Text = lang:GetText("/C 当前"),
							Padding = Vector4(10, 0, 0, 4),
							
							EventClick = function(sender, e)
								room_ui.ctr_BTN_Choose.Visible = false
								room_ui.BTN_Tex_sta.Text = lang:GetText("当前")
								room_ui.BTN_Tex_sta.TextColor = sender.TextColor
								room_ui.BTN_Tex_sta.HighlightTextColor = sender.HighlightTextColor
							end,
						},
						
						Gui.Button
						{
							Size = Vector2(91,20),
							Location = Vector2(0, 25),
							TextColor = ARGB(255, 242, 127, 3),
							HighlightTextColor = ARGB(255, 242, 127, 3),
							BackgroundColor = ARGB(0, 255, 255, 255),
							FontSize = 14,
							TextAlign = "kAlignLeftMiddle",
							Text = lang:GetText("/X 小喇叭"),
							Padding = Vector4(10, 0, 0, 4),
							
							EventClick = function(sender, e)
								room_ui.ctr_BTN_Choose.Visible = false
								room_ui.BTN_Tex_sta.Text = lang:GetText("小喇叭")
								room_ui.BTN_Tex_sta.TextColor = sender.TextColor
								room_ui.BTN_Tex_sta.HighlightTextColor = sender.HighlightTextColor
							end,
						},
						
						Gui.Button
						{
							Size = Vector2(91,20),
							Location = Vector2(0, 45),
							TextColor = ARGB(255, 255, 234, 0),
							HighlightTextColor = ARGB(255, 255, 234, 0),
							BackgroundColor = ARGB(0, 255, 255, 255),
							FontSize = 14,
							TextAlign = "kAlignLeftMiddle",
							Text = lang:GetText("/D 大喇叭"),
							Padding = Vector4(10, 0, 0, 4),
							
							EventClick = function(sender, e)
								room_ui.ctr_BTN_Choose.Visible = false
								room_ui.BTN_Tex_sta.Text = lang:GetText("大喇叭")
								room_ui.BTN_Tex_sta.TextColor = sender.TextColor
								room_ui.BTN_Tex_sta.HighlightTextColor = sender.HighlightTextColor
							end,
						},
					},
				},
			},
		},

		Gui.Control "ctrl_List_Window_BG"
		{
			Size = Vector2(763, 584),
			Location = Vector2(373, 16),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/lb_bg_win02.dds", Vector4(16, 16, 16, 16)),
			},
		
			Gui.Control "ctrl_List_Window"
			{
				Size = Vector2(753, 574),
				Location = Vector2(5, 5),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_daoju_bg.dds", Vector4(22, 22, 22, 22)),
				},

				Gui.Control "ctrl_room_title"
				{
					Size = Vector2(700, 116),
					Location = Vector2(25, 19),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_room_title01.dds", Vector4(0, 0, 0, 0)),
					},
							
--[[					Gui.AnimControl "Timer"
					{
						Size = Vector2(50,16),
						Location = Vector2(325,15),
						BackgroundColor = ARGB(0, 255, 255, 255),
						TextColor = ARGB(127, 254, 251, 245),
						FontSize = 16,
					},
]]				
					Gui.Label "lbl_red"
					{
						Size = Vector2(70, 92),
						Location = Vector2(256, 1),
						Text = "1",
						FontSize = 85,
						TextColor = ARGB(127, 254, 251, 245),
						TextAlign = "kAlignCenterMiddle",
					},

					Gui.Label "lbl_blue"
					{
						Size = Vector2(70, 92),
						Location = Vector2(371, 1),
						Text = "0",
						FontSize = 85,
						TextColor = ARGB(127, 254, 251, 245),
						TextAlign = "kAlignCenterMiddle",
					},
				},

				Gui.Control "ctrl_List_BG"
				{		
					Location = Vector2(27, 120),
					Size = Vector2(696, 340),
					BackgroundColor = ARGB(255, 255, 255, 255),
					-- BackgroundColor = ARGB(255/4, 0, 0, 0),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_room_title01_bg.dds", Vector4(0, 0, 0, 0)),
					},
					Gui.ListTreeViewSPA "list_red"
					{
						Location = Vector2(-2, 0),
						Size = Vector2(350, 336),
						Style = "Gui.ListTreeViewWith_VScroll",
						CanKeySelect = false,
						TreeVisible = false,
						AlwaysSelect = true,
						AutoScroll = false,
						HeaderVisible = false,
						TextColor = ARGB(255, 216, 217, 208),
						ItemHeight = 42,
						HeadFontSize = 18,
						FontSize = 18,
						HeadFontColor = ARGB(255, 215, 232, 227),
						VScrollBarDisplay = "kHide",
						ComboVisible = false,
					},
					
					Gui.ListTreeViewSPA "list_blue"
					{
						Location = Vector2(348, 0),
						Size = Vector2(350, 336),
						TextColor = ARGB(255, 216, 217, 208),
						Style = "Gui.ListTreeViewWith_VScroll",
						CanKeySelect = false,
						AutoScroll = false,
						TreeVisible = false,
						AlwaysSelect = true,
						HeaderVisible = false,
						FontSize = 18,
						ItemHeight = 42,
						HeadFontSize = 18,
						HeadFontColor = ARGB(255, 215, 232, 227),
						VScrollBarDisplay = "kHide",
						ComboVisible = false,
					},
				},

				Gui.Control "ctrl_btn"
				{
					Size = Vector2(245, 74),
					Location = Vector2(23, 475),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Visible = false,
					
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/lb_common_button_bg01.dds", Vector4(20, 20, 20, 20)),
					},
--[[
					--换边
					Gui.Button "btn_change_team"
					{
						Size = Vector2(117, 72),
						Location = Vector2(6 , 4),
						--Text = lang:GetText("换边"),
						TextColor = ARGB(255, 255, 246, 235),
						FontSize = 18,
						PushDown = false,
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_switchside_normal.dds", Vector4(0, 0, 0, 0)),
							HoverImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_switchside_hover.dds", Vector4(0, 0, 0, 0)),
							DownImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_switchside_down.dds", Vector4(0, 0, 0, 0)),
							DisabledImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_switchside_disabled.dds", Vector4(0, 0, 0, 0)),
						},
					},
]]					
						
						--房间设置
					Gui.Button "btn_room_option"
					{
						Size = Vector2(133, 64),
						Location = Vector2(7 , 6),
						TextColor = ARGB(255, 255, 246, 235),
						FontSize = 18,
						PushDown = flase,
						
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_setting_normal.dds", Vector4(5, 5, 5, 5)),
							HoverImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_setting_hover.dds", Vector4(5, 5, 5, 5)),
							DownImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_setting_down.dds", Vector4(5, 5, 5, 5)),
							DisabledImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_setting_disabled.dds", Vector4(5, 5, 5, 5)),
						},
					},

					--邀请
					Gui.Button "btn_invite"
					{
						Size = Vector2(104, 64),
						Location = Vector2(138 , 6),
						--Text = lang:GetText("邀请"),
						TextColor = ARGB(255, 255, 246, 235),
						FontSize = 18,
						PushDown = false,
						Enable = true,
						Visible = true,
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_invite_normal.dds", Vector4(0, 0, 0, 0)),
							HoverImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_invite_hover.dds", Vector4(0, 0, 0, 0)),
							DownImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_invite_down.dds", Vector4(0, 0, 0, 0)),
							DisabledImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_invite_disabled.dds", Vector4(0, 0, 0, 0)),
						},
						EventClick = function()
							--MessageBox.ShowWithConfirmCancel(lang:GetText("还在制作中？"), nil
							L_Friends.ShowInviteGameCreateWin(gui)
						end,
					},
				},
				
				Gui.Control "ctrl_enter"
				{
					Size = Vector2(164, 78),
					Location = Vector2(412, 474),
					BackgroundColor = ARGB(255, 255, 255, 255),

					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_common_button_bg02.dds", Vector4(15, 0, 44, 0)),
					},
					
					--退出房间
					Gui.Button "btn_exitroom"
					{
						Size = Vector2(148, 64),
						Location = Vector2(7 , 8),
					
						TextColor = ARGB(255, 255, 246, 235),
						FontSize = 18,
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_exitroom_normal.dds", Vector4(5, 5, 5, 5)),
							HoverImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_exitroom_hover.dds", Vector4(5, 5, 5, 5)),
							DownImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_exitroom_down.dds", Vector4(5, 5, 5, 5)),
							DisabledImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_exitroom_disabled.dds", Vector4(5, 5, 5, 5)),
						},
						
						EventClick = function()
							if Is_Auto_Start == false then
								create_room_ui = nil
								GetBack(current_state)
							end
						end,
					},
				},
				
				Gui.Control
				{
					Size = Vector2(168, 78),
					Location = Vector2(550, 474),
					BackgroundColor = ARGB(255, 255, 255, 255),

					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_common_button_bg03.dds", Vector4(51, 20, 22, 20)),
					},
					--开始游戏
					Gui.Button "btn_begin"
					{
						Size = Vector2(156, 64),
						Location = Vector2(6 , 7),
						TextColor = ARGB(255, 255, 246, 235),
						FontSize = 18,
						PushDown = false,
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/lb_shop_button02_normal.dds", Vector4(5, 5, 5, 5)),
							HoverImage = Gui.Image("LobbyUI/lb_shop_button02_hover.dds", Vector4(5, 5, 5, 5)),
							DownImage = Gui.Image("LobbyUI/lb_shop_button02_down.dds", Vector4(5, 5, 5, 5)),
							DisabledImage = Gui.Image("LobbyUI/lb_shop_button02_normal.dds", Vector4(5, 5, 5, 5)),
						},
					},
				},	
			},
			
			Gui.Label "roomid_name1"
			{
				Size = Vector2(343, 40),
				Text = lang:GetText("当前位置:"),
				FontSize = 14,
				TextColor = ARGB(255, 255, 231, 26),
				Location = Vector2(488, 10),
				TextAlign = "kAlignLeftMiddle",
			},
			
			Gui.Control
			{
				Size = Vector2(339,22),
				Location = Vector2(30, 17),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_fjmc_ico.dds", Vector4(20, 20, 20, 20)),
				},
				Gui.Label "roomid_name2"
				{
					Size = Vector2(339, 22),
					Text = "",
					FontSize = 16,
					TextColor = ARGB(255, 0, 210, 225),
					Location = Vector2(0, 0),
				},
			},
		},
	},
}

--房间信息窗口
main_room_info_ui = Gui.Create()
{
	Gui.Control "room_info"
	{
		Visible = false,
		Size = Vector2(320, 370),
		Location = Vector2(380, 100),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/ToolTips/lb_tooltips_bg.dds",Vector4(10, 10, 10, 10)),
		},
		
		Gui.ItemPicture "ctrl_small_map"
		{
			Size = Vector2(240, 148),
			Location = Vector2(37, 15),
			BackgroundColor = ARGB(255, 255, 255, 255),
		},
		Gui.Button "Tips"
		{
			Size = Vector2(68, 68),
			Location = Vector2(28, 8),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Enable = true,
			blink = true,
			blink_shade = true,
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = nil,
				TwinkleImage = nil,
			},
			Visible = false,
		},
		Gui.ListTreeView "list_room_info"
		{
			Size = Vector2(320, 360),
			Location = Vector2(10, 170),
			Style = "Gui.ListTreeViewWith_Nothing",
			CanKeySelect = false,
			ItemHeight = 23,
			FontSize = 14,
			TextColor = ARGB(255, 216, 217, 208),
			UseFistColumn = true,
			UseColumnNum = 0,
			UseColFontSize = 14,
			UseColFontCol = ARGB(255, 215, 232, 227),
		},
	},
}

--房间列表窗口
local room_list_window =
{
	Gui.Control "ctrl_Main_Window"
	{
		Size = Vector2(1150, 610),
		Location = Vector2(0, 10),
		BackgroundColor = ARGB(0, 255, 255, 255),

		Gui.Control "ctrl_AD_Window_BG"
		{
			Size = Vector2(347, 584),
			Location = Vector2(21, 16),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/lb_bg_win02.dds", Vector4(16, 16, 16, 16)),
			},
			
			Gui.Control "ctrl_AD_Window"
			{
				Size = Vector2(337, 574),
				Location = Vector2(6, 6),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_daoju_bg.dds", Vector4(22, 22, 22, 22)),
				},
				
				Gui.Control "list_info_BG"
				{
					Location = Vector2(12, 12),
					Size = Vector2(314,274),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_room_left_bg.dds", Vector4(12, 12, 12, 0)),
					},
					
					Gui.Control "map_bg"
					{
						Size = Vector2(240, 148),
						Location = Vector2(37, 5),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("MapsAndBG/MapsIcon/lb_battlefield_map_lv0_b.dds", Vector4(0, 0, 0, 0)),
						},
					},
				
					Gui.ItemPicture "ctrl_small_map"
					{
						Size = Vector2(240, 148),
						Location = Vector2(37, 5),
						BackgroundColor = ARGB(255, 255, 255, 255),
					},
					
					Gui.Button "Tips"
					{
						Size = Vector2(68, 68),
						Location = Vector2(28, -2),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Enable = true,
						blink = true,
						-- blinkwheelTimer = 0.6,
						blink_shade = true,
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = nil,
							TwinkleImage = nil,
						},
						Visible = false,
					},
					
					Gui.Control "knife_tips"
					{
						Size = Vector2(40, 52),
						Location = Vector2(230, 6),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_knife_ico.dds", Vector4(0, 0, 0, 0)),
						},
						Visible = false,
					},
							
					-- 查看房间信息
					Gui.Button "look_up"
					{
						Size = Vector2(39, 33),
						Location = Vector2(276, 120),
						BackgroundColor = ARGB(255, 255, 255, 255),
						
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/Compose/lb_melting_button_06_normal.dds", Vector4(0, 0, 0, 0)),
							HoverImage = Gui.Image("LobbyUI/Compose/lb_melting_button_06_hover.dds", Vector4(0, 0, 0, 0)),
							DownImage = Gui.Image("LobbyUI/Compose/lb_melting_button_06_down.dds", Vector4(0, 0, 0, 0)),
							DisabledImage = Gui.Image("LobbyUI/Compose/lb_melting_button_06_disabled.dds", Vector4(0, 0, 0, 0)),
						},
						
						EventClick = function(sender,e)
							ShowRoomInfo(root_ui)
						end
					},
					
					Gui.ListTreeView "list_room_info"
					{
						Size = Vector2(512, 264),
						Location = Vector2(-5, 158),
						Style = "Gui.ListTreeViewWith_Nothing",
						CanKeySelect = false,
						ItemHeight = 23,
						FontSize = 14,
						TextColor = ARGB(255, 216, 217, 208),
						UseFistColumn = true,
						UseColumnNum = 0,
						UseColFontSize = 14,
						UseColFontCol = ARGB(255, 215, 232, 227),
					},
				},
				Gui.Control
				{
					Size = Vector2(323, 315),
					Location = Vector2(7, 255),
					BackgroundColor = ARGB(0, 255, 255, 255),
					
					-- 频道列表刷新
					Gui.Label "lab_timer_Channl_list"
					{
						Size = Vector2(1200,900),
						Location = Vector2(0, 0),
						BackgroundColor = ARGB(0, 255, 255, 255),
						Visible = false,
						UseTimer = true,
						DisplayTime = 3600,
						
						EventClose = function()
							main_room_list_ui.lab_timer_Channl_list:Show()
							if Channl_Search_state == false then
								state:RefreshClientList((channl_list_page - 1)*10)
							end
						end,
					},
					
					Gui.Control
					{							
						Size = Vector2(323, 281),
						Location = Vector2(0, 30),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg3.dds", Vector4(22, 22, 22, 22)),
						},
					},
					
					Gui.Control "ctr_play_Chat"
					{
						Size = Vector2(323, 280),
						Location = Vector2(2, 34),
						BackgroundColor = ARGB(0, 255, 255, 255),
						Visible = false,
						
						 Gui.MessagePanel "MesPanel_channel"
						 {
							 Style = "Gui.MessagePanel",
							 Size = Vector2(310, 234),
							 Location = Vector2(3, 5),
							 BackgroundColor = ARGB(0, 255, 255, 255),
							 VisibleLine = 13,
							 ScrollBarWidth = 16,
							
							 ButtonHeight = 1,
							 ButHeight = 17,
							 MaxAllLine = 128,
							
							 EventClick_Name = function()
								L_LobbyMain.ChatPrivate(main_room_list_ui.MesPanel_channel.Click_Name)
							 end
						 },
						 
						 Gui.Control
						 {
							 Size = Vector2(323, 30),
							 Location = Vector2(-2, 245),
							 BackgroundColor = ARGB(0, 255, 255, 255),
					
							 Gui.Control "ctr_Tex_back"
							 {
								 Size = Vector2(307, 25),
								 Location = Vector2(8, 0),
								 BackgroundColor = ARGB(255, 255, 255, 255),
								
								 Skin = Gui.ControlSkin
								 {
									BackgroundImage = Gui.Image("LobbyUI/Friends/lb_battlefield_chat_bg_02_down.dds", Vector4(4, 4, 4, 4)),
								 },
							 },
						
							 Gui.Textbox "Tex_room"
							 {
								 Size = Vector2(182, 25),
								 Location = Vector2(78, 0),
								 BackgroundColor = ARGB(0, 255, 255, 255),
								 MaxLength = 120,
								 TextPadding = Vector4(0, 0, 0, 0),
								
								 EventValueEnter = function(sender, e)
									 SpeakType(main_room_list_ui.BTN_Tex_sta,"/Channel",main_room_list_ui.Tex_room)
								 end,
								
								 EventEnter = function()
									 main_room_list_ui.ctr_Tex_back.Skin = Gui.ControlSkin
									 {
										 BackgroundImage = Gui.Image("LobbyUI/Friends/lb_battlefield_chat_bg_02_down.dds", Vector4(4, 4, 4, 4)),
									 }
								 end,
								
								 EventLeave = function()
									 main_room_list_ui.ctr_Tex_back.Skin = Gui.ControlSkin
									 {
										 BackgroundImage = Gui.Image("LobbyUI/Friends/lb_battlefield_chat_bg_02_normal.dds", Vector4(4, 4, 4, 4)),
									 }
								 end,
							 },
						
							 Gui.Button "BTN_Tex_sta"
							 {
								 Size = Vector2(60,19),
								 Location = Vector2(12, 3),
								 TextAlign = "kAlignCenterMiddle",
								 Text = lang:GetText("当前"),
								 FontSize = 12,
								 TextColor = ARGB(255, 214, 212, 207),
								 HighlightTextColor = ARGB(255, 214, 212, 207),
								 Skin = Gui.ButtonSkin
								 {
									 BackgroundImage = Gui.Image("LobbyUI/Friends/lb_battlefield_button_01_normal.dds", Vector4(4, 4, 4, 4)),
									 HoverImage = Gui.Image("LobbyUI/Friends/lb_battlefield_button_01_hover.dds", Vector4(4, 4, 4, 4)),
									 DownImage = Gui.Image("LobbyUI/Friends/lb_battlefield_button_01_down.dds", Vector4(4, 4, 4, 4)),
									 DisabledImage = Gui.Image("LobbyUI/Friends/lb_battlefield_button_01_normal.dds", Vector4(4, 4, 4, 4)),
								 },
								 EventClick = function()
									 main_room_list_ui.ctr_BTN_Choose.Visible = true
									 main_room_list_ui.lab_timer_ctr.UseTimer = true
									 main_room_list_ui.lab_timer_ctr:Show()	
								 end,
							 },
						
							 Gui.Button
							 {
								 Size = Vector2(32,19),
								 Location = Vector2(265, 3),
								 Skin = Gui.ButtonSkin
								 {
									 BackgroundImage = Gui.Image("LobbyUI/Friends/lb_battlefield_button_02_normal.dds", Vector4(4, 4, 4, 4)),
									 HoverImage = Gui.Image("LobbyUI/Friends/lb_battlefield_button_02_hover.dds", Vector4(4, 4, 4, 4)),
									 DownImage = Gui.Image("LobbyUI/Friends/lb_battlefield_button_02_down.dds", Vector4(4, 4, 4, 4)),
									 DisabledImage = Gui.Image("LobbyUI/Friends/lb_battlefield_button_02_normal.dds", Vector4(4, 4, 4, 4)),
								 },
								 EventClick = function()
									SpeakType(main_room_list_ui.BTN_Tex_sta,"/Channel",main_room_list_ui.Tex_room)
								 end,
							 },
							
							 Gui.Button
							 {
								 Size = Vector2(16,19),
								 Location = Vector2(295, 3),
								 TextColor = ARGB(255, 37, 37, 37),
								 HighlightTextColor = ARGB(255, 37, 37, 37),
								 FontSize = 12,
								 TextAlign = "kAlignCenterMiddle",
								 Text = "C",
								 Padding = Vector4(0, 0, 0, 0),
								 Skin = Gui.ButtonSkin
								 {
									 BackgroundImage = Gui.Image("LobbyUI/Friends/lb_battlefield_button_01_normal.dds", Vector4(4, 4, 4, 4)),
									 HoverImage = Gui.Image("LobbyUI/Friends/lb_battlefield_button_01_hover.dds", Vector4(4, 4, 4, 4)),
									 DownImage = Gui.Image("LobbyUI/Friends/lb_battlefield_button_01_down.dds", Vector4(4, 4, 4, 4)),
									 DisabledImage = Gui.Image("LobbyUI/Friends/lb_battlefield_button_01_normal.dds", Vector4(4, 4, 4, 4)),
								 },
								 EventClick = function()
									main_room_list_ui.MesPanel_channel:ClearLines()
								 end,
							 },
						 },
					
						 Gui.Control "ctr_BTN_Choose"
						 {
							 Size = Vector2(95, 70),
							 Location = Vector2(8, 175),
							 BackgroundColor = ARGB(255, 255, 255, 255),
							 Visible = false,
							
							 Skin = Gui.ControlSkin
							 {
								BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_summary_flop_bg_04.dds", Vector4(30 , 30, 30, 30)),
							 },
							
							 EventMouseEnter = function()
								main_room_list_ui.lab_timer_ctr.UseTimer = false
								main_room_list_ui.lab_timer_ctr:Show()
							 end,
							
							 EventMouseLeave = function()
								 main_room_list_ui.lab_timer_ctr.UseTimer = true
								 main_room_list_ui.lab_timer_ctr:Show()
							 end,
							
							 Gui.Label "lab_timer_ctr"
							 {
								 Size = Vector2(10,10),
								 Location = Vector2(0, 0),
								 BackgroundColor = ARGB(0, 255, 255, 255),
								 Visible = false,
								 UseTimer = true,
								 DisplayTime = 5,
								
								 EventClose = function()
									main_room_list_ui.ctr_BTN_Choose.Visible = false
								 end,
							 },
							
							 Gui.Button
							 {
								 Size = Vector2(91,20),
								 Location = Vector2(0, 5),
								 TextColor = ARGB(255, 214, 212, 207),
								 HighlightTextColor = ARGB(255, 214, 212, 207),
								 BackgroundColor = ARGB(0, 255, 255, 255),
								 FontSize = 14,
								 TextAlign = "kAlignLeftMiddle",
								 Text = lang:GetText("/C 当前"),
								 Padding = Vector4(10, 0, 0, 4),
								
								 EventClick = function(sender, e)
									main_room_list_ui.ctr_BTN_Choose.Visible = false
									main_room_list_ui.BTN_Tex_sta.Text = lang:GetText("当前")
									main_room_list_ui.BTN_Tex_sta.TextColor = sender.TextColor
									main_room_list_ui.BTN_Tex_sta.HighlightTextColor = sender.HighlightTextColor
								 end,
							 },
							
							 Gui.Button
							 {
								 Size = Vector2(91,20),
								 Location = Vector2(0, 25),
								 TextColor = ARGB(255, 242, 127, 3),
								 HighlightTextColor = ARGB(255, 242, 127, 3),
								 BackgroundColor = ARGB(0, 255, 255, 255),
								 FontSize = 14,
								 TextAlign = "kAlignLeftMiddle",
								 Text = lang:GetText("/X 小喇叭"),
								 Padding = Vector4(10, 0, 0, 4),
								
								 EventClick = function(sender, e)
									main_room_list_ui.ctr_BTN_Choose.Visible = false
									main_room_list_ui.BTN_Tex_sta.Text = lang:GetText("小喇叭")
									main_room_list_ui.BTN_Tex_sta.TextColor = sender.TextColor
									main_room_list_ui.BTN_Tex_sta.HighlightTextColor = sender.HighlightTextColor
								 end,
							 },
							
							 Gui.Button
							 {
								 Size = Vector2(91,20),
								 Location = Vector2(0, 45),
								 TextColor = ARGB(255, 255, 234, 0),
								 HighlightTextColor = ARGB(255, 255, 234, 0),
								 BackgroundColor = ARGB(0, 255, 255, 255),
								 FontSize = 14,
								 TextAlign = "kAlignLeftMiddle",
								 Text = lang:GetText("/D 大喇叭"),
								 Padding = Vector4(10, 0, 0, 4),
								
								 EventClick = function(sender, e)
									main_room_list_ui.ctr_BTN_Choose.Visible = false
									main_room_list_ui.BTN_Tex_sta.Text = lang:GetText("大喇叭")
									main_room_list_ui.BTN_Tex_sta.TextColor = sender.TextColor
									main_room_list_ui.BTN_Tex_sta.HighlightTextColor = sender.HighlightTextColor
								end,
							 },
						},	
					},
					
					Gui.Control "ctr_play_list"
					{
						Size = Vector2(323, 280),
						Location = Vector2(8, 38),
						BackgroundColor = ARGB(0, 255, 255, 255),
						Visible = true,
						
						-- 玩家列表
						Gui.ListTreeView "Play_List"
						{
							Size = Vector2(305, 244),
							Location = Vector2(0,0),
							Style = "Gui.Toplist",
							HeaderVisible = false,
							TreeVisible = false,
							VScrollBarWidth = 16,
							VScrollBarButtonSize = 16,
							ItemHeight = 24,
							EventDoubleClick = function(sender, e)
								local item = sender.SelectedItem
								local itemName = item:GetText(4)
								if itemName ~= "" then
									if itemName == L_LobbyMain.PersonalInfo_data.name then
										L_Friends.ShowLeaveOwnGroupCreateWin(gui,lang:GetText("您不能和自己私聊！"))
										return
									end
									L_Friends.CreatePrivateChat(itemName,1)
								end
							end,
							
							-- 右击
							EventRightClick = function(sender, e)
								main_room_list_ui.Play_List.PopupMenu:RemoveAll()
								main_room_list_ui.Play_List.PopupMenu:AddItem(lang:GetText("私聊"))
								main_room_list_ui.Play_List.PopupMenu:AddItem(lang:GetText("和TA一起玩"))
								main_room_list_ui.Play_List.PopupMenu:AddItem(lang:GetText("加为好友"))
								main_room_list_ui.Play_List.PopupMenu:AddItem(lang:GetText("加入黑名单"))
								main_room_list_ui.Play_List.PopupMenu:AddItem(lang:GetText("查看信息"))
								main_room_list_ui.Play_List.PopupMenu:AddItem(lang:GetText("我要举报"))
								main_room_list_ui.Play_List.PopupMenu.Style = "Gui.MenuNew"
								
								main_room_list_ui.Play_List.PopupMenu.EventClick = function(sender, e)
									local item = ptr_cast(sender.Tag)	
									local itemName = item:GetText(4)
									local itemId = item.ID
									if sender.SelectedIndex == 0 then
										if itemName ~= "" then
											if itemName == L_LobbyMain.PersonalInfo_data.name then
												L_Friends.ShowLeaveOwnGroupCreateWin(gui,lang:GetText("您不能和自己私聊！"))
												return
											end
											L_Friends.CreatePrivateChat(itemName,1)
											local l = L_Friends.Channel_list
											while l do
												if l.name == itemName then
													L_Friends.Vip = l.vip
													break
												end
												l = l.next
											end
										end
									elseif sender.SelectedIndex == 1 then
										if itemName ~= "" then
											L_LobbyMain.GotoPlayerRoom(itemName,false)
										end
									elseif sender.SelectedIndex == 2 then
										if itemName ~= "" then
											L_Friends.FriendsAdd(nil,itemName)	
										end
									elseif sender.SelectedIndex == 3 then
										if itemName ~= "" then
											L_Friends.BlackAdd(itemName)
										end
									elseif sender.SelectedIndex == 4 then
										if itemName ~= "" then
											if itemName == L_LobbyMain.PersonalInfo_data.name then
												if L_LobbyMain.LobbyMainWin_Boddy then
													L_PersonalInfo.Show(L_LobbyMain.LobbyMainWin_Boddy.LobbyMainWin_Boddy_Root)
												end
												L_LobbyMain.InitPersonalInfoRPCInfo()
												lg:SetLobbyModules(12)
												L_LobbyMain.current_chosse_main_page = 12
												L_PersonalInfo.SynchronousClassButton()
												L_LobbyMain.FillClassBag(ptr_cast(game.CurrentState):GetCharacterId(), L_LobbyMain.current_choose_class)
												return
											end
											
											L_PersonalInfo.ShowPerson(L_LobbyMain.LobbyMainWin_Boddy.LobbyMainWin_Boddy_Root, itemId, itemName)
											
										end
									elseif  sender.SelectedIndex == 5 then
										if itemName ~= "" then
											ShowReportWin(itemName,1)
										end
									end
								end
								local item = sender.MouseSelectedItem
								if item then
									if item:GetText(4) ~= "" and item:GetText(4) ~= L_LobbyMain.PersonalInfo_data.name then
										sender.PopupMenu:Open()
									end
								end
							end,
						},
						
						Gui.Control
						{
							Size = Vector2(323, 30),
							Location = Vector2(0, 240),
							BackgroundColor = ARGB(0, 255, 255, 255),
							
							Gui.Textbox "tbox_search_text"
							{
								Location = Vector2(2, 2),
								Size = Vector2(115, 25),
								FontSize = 14,
								TextColor = ARGB(255, 167, 179, 176),
								Text = lang:GetText("搜索玩家..."),
								-- BackgroundColor = ARGB(255,255,255,255),
								Skin = Gui.TextboxSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_text_down.dds", Vector4(5, 5, 5, 5)),
									-- ActiveImage = Gui.Image("LobbyUI/Friends/lb_contact_bg3_down.dds", Vector4(6, 6, 6, 6)),
									-- DisabledImage = Gui.Image("LobbyUI/Friends/lb_contact_bg3_down.dds", Vector4(6, 6, 6, 6)),
								},
								EventEnter = function()
									if main_room_list_ui.tbox_search_text.Text == lang:GetText("搜索玩家...") then
										main_room_list_ui.tbox_search_text.Text = ""
										-- main_room_list_ui.tbox_search_text.TextColor = ARGB(255, 62, 64, 63)
									end
								end,
								
								EventLeave = function()
									if main_room_list_ui.tbox_search_text.Text == "" then
										main_room_list_ui.tbox_search_text.Text = lang:GetText("搜索玩家...")
										-- main_room_list_ui.tbox_search_text.TextColor = ARGB(255, 167, 179, 176)
									end
									
								end
							},
				
							-- 搜索
							Gui.Button "btn_search_channl"
							{
								Location = Vector2(120, 3),
								Size = Vector2(24, 24),
								BackgroundColor = ARGB(255,255,255,255),
								Skin = Gui.ButtonSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_button_ss_normal.dds", Vector4(0, 0, 0, 0)),
									HoverImage = Gui.Image("LobbyUI/Friends/lb_contact_button_ss_hover.dds", Vector4(0, 0, 0, 0)),
									DownImage = Gui.Image("LobbyUI/Friends/lb_contact_button_ss_down.dds", Vector4(0, 0, 0, 0)),
									DisabledImage = Gui.Image("LobbyUI/Friends/lb_contact_button_ss_normal.dds", Vector4(0, 0, 0, 0)),
								},
								EventClick = function()
									-- MessageBox.ShowWithConfirmCancel(lang:GetText("还在制作中？"), nil)
									if Channl_Search_state == false then
										if main_room_list_ui.tbox_search_text.Text == lang:GetText("搜索玩家...") or main_room_list_ui.tbox_search_text.Text == "" then
											MessageBox.ShowWithTimer(1,lang:GetText("请输入玩家名称"))
											return
										end
										local args = { name = main_room_list_ui.tbox_search_text.Text , page_id = 1}
										rpc.safecall("friends_search_list",args,FileSearchList,function () L_MessageBox.CloseWaiter() end)
										Set_Channl_Search_state(true)
									else
										Set_Channl_Search_state(false)
										state:RefreshClientList(0)
									end
								end
							},
							
							Gui.Button
							{
								Location = Vector2(166, 7),
								Size = Vector2(12, 18),
								BackgroundColor = ARGB(255,255,255,255),
								Skin = Gui.ButtonSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_fanye_button_normal_L.dds", Vector4(0, 0, 0, 0)),
									HoverImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_fanye_button_hover_L.dds", Vector4(0, 0, 0, 0)),
									DownImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_fanye_button_down_L.dds", Vector4(0, 0, 0, 0)),
									DisabledImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_fanye_button_disabled_L.dds", Vector4(0, 0, 0, 0)),
								},
							
								EventClick = function()
									-- MessageBox.ShowWithConfirmCancel(lang:GetText("还在制作中？"), nil)
									if Channl_Search_state then
										FillPlayList_search(channl_list_page - 1)
									else
										local num_Tep = channl_list_page - 2
										if num_Tep < 0 then
											num_Tep = 0
										end
										state:RefreshClientList(num_Tep*10)
									end
								end
							},
							
							Gui.Textbox "tbox_text_page"
							{
								Location = Vector2(185, 2),
								Size = Vector2(95, 25),
								FontSize = 16,
								TextColor = ARGB(255, 167, 179, 176),
								Text = "",
								-- BackgroundColor = ARGB(255,255,255,255),
								InputNumberOnly = false,
								TextPadding = Vector4(42,0,0,0),
								Skin = Gui.TextboxSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_text_down.dds", Vector4(5, 5, 5, 5)),
									-- ActiveImage = Gui.Image("LobbyUI/Friends/lb_contact_bg3_down.dds", Vector4(6, 6, 6, 6)),
									-- DisabledImage = Gui.Image("LobbyUI/Friends/lb_contact_bg3_down.dds", Vector4(6, 6, 6, 6)),
								},
								
								EventTextChanged = function()
									if main_room_list_ui.tbox_text_page.Text ~= "" and main_room_list_ui.tbox_text_page.InputNumberOnly then
										if math.ceil(tonumber(main_room_list_ui.tbox_text_page.Text)) > 50 then
											main_room_list_ui.tbox_text_page.Text = "50"
											return
										elseif math.ceil(tonumber(main_room_list_ui.tbox_text_page.Text)) < 1 then
											main_room_list_ui.tbox_text_page.Text = "1"
											return
										end
										if string.sub(main_room_list_ui.tbox_text_page.Text,1,1) == "0" then
											main_room_list_ui.tbox_text_page.Text = string.sub(main_room_list_ui.tbox_text_page.Text,2)
											return
										end
									end
									main_room_list_ui.tbox_text_page.TextPadding = Vector4(42 - 4*string.len(main_room_list_ui.tbox_text_page.Text),0,0,0)
								end,
								
								EventEnter = function()
									main_room_list_ui.tbox_text_page.Text = ""
									main_room_list_ui.tbox_text_page.InputNumberOnly = true
								end,
								
								EventLeave = function()
									if main_room_list_ui.tbox_text_page.Text ~= "" then
										channl_input_num = tonumber(main_room_list_ui.tbox_text_page.Text)
									end
									main_room_list_ui.tbox_text_page.InputNumberOnly = false
									fileChannlListPage()
								end,
							},				
													
							-- 页数跳转
							Gui.Button
							{
								Location = Vector2(260, 4),
								Size = Vector2(16, 20),
								BackgroundColor = ARGB(255,255,255,255),
								Skin = Gui.ButtonSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_chat_button_normal.dds", Vector4(0, 0, 0, 0)),
									HoverImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_chat_button_hover.dds", Vector4(0, 0, 0, 0)),
									DownImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_chat_button_down.dds", Vector4(0, 0, 0, 0)),
									DisabledImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_chat_button_normal.dds", Vector4(0, 0, 0, 0)),
								},
								EventClick = function()
									-- MessageBox.ShowWithConfirmCancel(lang:GetText("还在制作中？"), nil)
									if channl_input_num > 0 then
										if Channl_Search_state then
											FillPlayList_search(channl_input_num)
										else
											local num_Tep = (channl_input_num - 1)*10
											while num_Tep > state.channl_list_total_count - 1 do
												num_Tep = num_Tep - 10
											end
											state:RefreshClientList(num_Tep)
										end
										channl_input_num = -1
									end
								end,
							},		
							
							Gui.Button
							{
								Location = Vector2(287, 7),
								Size = Vector2(12, 18),
								BackgroundColor = ARGB(255,255,255,255),
								Skin = Gui.ButtonSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_fanye_button_normal_R.dds", Vector4(0, 0, 0, 0)),
									HoverImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_fanye_button_hover_R.dds", Vector4(0, 0, 0, 0)),
									DownImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_fanye_button_down_R.dds", Vector4(0, 0, 0, 0)),
									DisabledImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_fanye_button_disabled_R.dds", Vector4(0, 0, 0, 0)),
								},
								EventClick = function()
									-- MessageBox.ShowWithConfirmCancel(lang:GetText("还在制作中？"), nil)
									if Channl_Search_state then
										FillPlayList_search(channl_list_page + 1)
									else
										local num_Tep = channl_list_page*10
										while num_Tep > state.channl_list_total_count - 1 do
											num_Tep = num_Tep - 10
										end
										state:RefreshClientList(num_Tep)
									end
								end
							},
						},	
					},
					
					Gui.Button "BTN_Channl_List"
					{
						Location = Vector2(2, 5),
						Size = Vector2(160, 33),
						BackgroundColor = ARGB(255, 255, 255, 255),
						FontSize = 16,
						Text = lang:GetText("玩家列表"),
						TextAlign = "kAlignCenterMiddle",
						TextColor = ARGB(255, 217, 209, 201),
						HighlightTextColor = ARGB(255, 217, 209, 201),
						Padding = Vector4(0, 0, 0, 0),
						PushDown = true,
	
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/team/lb_shop_tab03_normal.dds", Vector4(5, 5, 5, 5)),
							HoverImage = Gui.Image("LobbyUI/team/lb_shop_tab03_hover.dds", Vector4(5, 5, 5, 5)),
							DownImage = Gui.Image("LobbyUI/team/lb_shop_tab03_down.dds", Vector4(5, 5, 5, 5)),
							DisabledImage = Gui.Image("LobbyUI/team/lb_shop_tab03_normal.dds", Vector4(5, 5, 5, 5)),
						},
						
						 EventClick = function()
							 SetChannnlListVisible(2)
						 end,
					},
					
					Gui.Button "BTN_Channl_Chat"
					{
						Location = Vector2(158, 5),
						Size = Vector2(160, 33),
						BackgroundColor = ARGB(255, 255, 255, 255),
						FontSize = 16,
						Text = lang:GetText("聊 天"),
						TextAlign = "kAlignCenterMiddle",
						TextColor = ARGB(255, 217, 209, 201),
						HighlightTextColor = ARGB(255, 217, 209, 201),
						Padding = Vector4(0, 0, 0, 0),
						
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/team/lb_shop_tab03_normal.dds", Vector4(5, 5, 5, 5)),
							HoverImage = Gui.Image("LobbyUI/team/lb_shop_tab03_hover.dds", Vector4(5, 5, 5, 5)),
							DownImage = Gui.Image("LobbyUI/team/lb_shop_tab03_down.dds", Vector4(5, 5, 5, 5)),
							DisabledImage = Gui.Image("LobbyUI/team/lb_shop_tab03_normal.dds", Vector4(5, 5, 5, 5)),
						},
						
						 EventClick = function()
							 SetChannnlListVisible(1)
						 end,
					},
				},
			},
		},
				
		Gui.Control "ctrl_List_Window_BG"
		{
			Size = Vector2(763, 584),
			Location = Vector2(373, 16),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/lb_bg_win02.dds", Vector4(16, 16, 16, 16)),
			},
			
			Gui.Control "ctrl_List_Window"
			{
				Size = Vector2(753, 574),
				Location = Vector2(5, 5),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_daoju_bg.dds", Vector4(22, 22, 22, 22)),
				},

				Gui.ComboBox "cbx_Mode"
				{
					Style = "Gui.WarZoneCreateComboBox",
					Size = Vector2(284, 38),
					FontSize = 18,
					Readonly = true,
					Location = Vector2(25,38),
					TextColor = ARGB(255,206,227,234),
					ChildComboListStyle =  "Gui.ChangeJobComboList",
					WithIconOffset = Vector2(240,0),
				},
				
				Gui.Control "ctrl_List_BG"
				{		
					Location = Vector2(25, 88),
					Size = Vector2(703, 375),
					BackgroundColor = ARGB(255, 255, 255, 255),
	
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/lb_battlefield_serverlist_bg01.tga", Vector4(8, 42, 50, 8)),
					},
					
					Gui.ListTreeView "list"
					{
						Style = "Gui.ListTreeViewWith_VScroll",
						Dock = "kDockFill",
						CanKeySelect = false,
						HeaderSkin = Gui.HeaderSkin
						{
							-- list item skin
							NormalImage = nil,
							HoverImage = nil,
							DownImage = nil,
							-- DisabledImage = nil,
							SortNormalImage = Gui.Image("DefaultSkin/DefaultSkin_list01_sort_normal.dds", Vector4(0,0,0,0)),
							SortReverseImage = Gui.Image("DefaultSkin/DefaultSkin_list01_sort_reverse.dds", Vector4(0,0,0,0)),
						},
						TreeVisible = false,
						AlwaysSelect = true,
						HeaderHeight = 40,
						VScrollBarWidth = 40,
						VScrollBarButtonSize = 36,
						FontSize = 14,
						TextColor = ARGB(255,216,217,208),
						HeadFontSize = 14,
						HeadFontColor = ARGB(255, 215, 232, 227),
					},
				},

				Gui.Control "setting_window"
				{
					Size = Vector2(500, 400),
					Location = Vector2(270, 192),
					BackgroundColor = ARGB(0, 255, 255, 255),
					Visible = false,
					Gui.Control
					{
						Size = Vector2(420, 290),
						Location = Vector2(0, 0),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_contact_bg1_01.dds", Vector4(163,163,53,53)),
						},
					},
					Gui.Control
					{
						Size = Vector2(388, 250),
						Location = Vector2(16, 16),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_contact_bg2.dds", Vector4(38, 41, 38, 66)),	
						},
					},
					Gui.Label
					{
						Size = Vector2(125,44),
						Location  = Vector2(41,20),
						Text = lang:GetText("模式"),
						FontSize = 20,
						TextColor = ARGB(255, 37, 37, 37),
					},
					Gui.Label
					{
						Size = Vector2(125,44),
						Location  = Vector2(41,60),
						Text = lang:GetText("地图"),
						FontSize = 20,
						TextColor = ARGB(255, 37, 37, 37),
					},
					Gui.Label
					{
						Size = Vector2(125,44),
						Location  = Vector2(41,100),
						Text = lang:GetText("特殊职业战"),
						FontSize = 20,
						TextColor = ARGB(255, 37, 37, 37),
					},
					Gui.Label
					{
						Size = Vector2(125,44),
						Location  = Vector2(41,140),
						Text = lang:GetText("人数"),
						FontSize = 20,
						TextColor = ARGB(255, 37, 37, 37),
					},
					Gui.Label
					{
						Size = Vector2(125,44),
						Location  = Vector2(41,180),
						Text = lang:GetText("状态"),
						FontSize = 20,
						TextColor = ARGB(255, 37, 37, 37),
					},
					
					
					Gui.ComboBox "c_moshi"
					{
						Skin = Gui.ComboBoxSkin
						{
							ButtonNormalImage= Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_button_normal.dds", Vector4(0, 0, 0, 0)),
							ButtonHoverImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_button_hover.dds", Vector4(0, 0, 0, 0)),
							ButtonDownImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_button_down.dds", Vector4(0, 0, 0, 0)),
							ButtonDisabledImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_button_disabled.dds", Vector4(0, 0, 0, 0)),	
							TextNormalImage= Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_text.dds", Vector4(6, 0, 0, 0)),
							TextHoverImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_text.dds", Vector4(6, 0, 0, 0)),
							TextDownImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_text.dds", Vector4(6, 0, 0, 0)),
							TextDisabledImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_text_disabled.dds", Vector4(6, 0, 0, 0)),
						},
						Size = Vector2(224,30),
						Location = Vector2(160, 28),
						Readonly = true,
						TextColor = ARGB(255, 243, 194, 10),
						-- MaxLength = 12,
						Text = lang:GetText("全部"),
						ChildComboListStyle =  "Gui.ChangeJobComboList",
						EventValueChanged = function(sender, args)
							if main_room_list_ui then
								if sender.SelectedIndex <= 0 then
									main_room_list_ui.c_map.Enable = false
									main_room_list_ui.c_map.Text = lang:GetText("全部")
									main_room_list_ui.c_roomstate.Enable = true
									main_room_list_ui.c_roomnum.Enable = true
								else
									main_room_list_ui.c_map.Enable = true
									main_room_list_ui.c_map:RemoveAll()
									main_room_list_ui.c_map.Text = lang:GetText("全部")
									-- print(sender.SelectedIndex)
									for i=1, #setting_map[sender.SelectedIndex] do
										main_room_list_ui.c_map:AddItem(setting_map[sender.SelectedIndex][i])
									end
									if setting_moshi[sender.SelectedIndex+1] == "审判" then
										main_room_list_ui.c_roomstate.Enable = false
										main_room_list_ui.c_roomstate.Text = lang:GetText("等待中")
										main_room_list_ui.c_roomstate.SelectedIndex = 1
										main_room_list_ui.c_roomnum.Enable = false
										main_room_list_ui.c_roomnum.Text = lang:GetText("全部")
										main_room_list_ui.c_roomnum.SelectedIndex = 0
									else
										main_room_list_ui.c_roomstate.Enable = true
										main_room_list_ui.c_roomnum.Enable = true
									end
								end
							end
						end,
					},
					
					Gui.ComboBox "c_map"
					{
						Skin = Gui.ComboBoxSkin
						{
							ButtonNormalImage= Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_button_normal.dds", Vector4(0, 0, 0, 0)),
							ButtonHoverImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_button_hover.dds", Vector4(0, 0, 0, 0)),
							ButtonDownImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_button_down.dds", Vector4(0, 0, 0, 0)),
							ButtonDisabledImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_button_disabled.dds", Vector4(0, 0, 0, 0)),	
							TextNormalImage= Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_text.dds", Vector4(6, 0, 0, 0)),
							TextHoverImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_text.dds", Vector4(6, 0, 0, 0)),
							TextDownImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_text.dds", Vector4(6, 0, 0, 0)),
							TextDisabledImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_text_disabled.dds", Vector4(6, 0, 0, 0)),
						},
						Size = Vector2(224,30),
						Location = Vector2(160, 68),
						Readonly = true,
						TextColor = ARGB(255, 243, 194, 10),
						-- MaxLength = 12,
						Text = lang:GetText("全部"),
						Enable = false,
						ChildComboListStyle =  "Gui.ChangeJobComboList",
					},
					
					Gui.ComboBox "c_specialjob"
					{
						Skin = Gui.ComboBoxSkin
						{
							ButtonNormalImage= Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_button_normal.dds", Vector4(0, 0, 0, 0)),
							ButtonHoverImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_button_hover.dds", Vector4(0, 0, 0, 0)),
							ButtonDownImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_button_down.dds", Vector4(0, 0, 0, 0)),
							ButtonDisabledImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_button_disabled.dds", Vector4(0, 0, 0, 0)),	
							TextNormalImage= Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_text.dds", Vector4(6, 0, 0, 0)),
							TextHoverImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_text.dds", Vector4(6, 0, 0, 0)),
							TextDownImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_text.dds", Vector4(6, 0, 0, 0)),
							TextDisabledImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_text_disabled.dds", Vector4(6, 0, 0, 0)),
						},
						Size = Vector2(224,30),
						Location = Vector2(160, 108),
						Readonly = true,
						TextColor = ARGB(255, 243, 194, 10),
						-- MaxLength = 12,
						Text = lang:GetText("全部"),
						ChildComboListStyle =  "Gui.ChangeJobComboList",
					},
					
					Gui.ComboBox "c_roomnum"
					{
						Skin = Gui.ComboBoxSkin
						{
							ButtonNormalImage= Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_button_normal.dds", Vector4(0, 0, 0, 0)),
							ButtonHoverImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_button_hover.dds", Vector4(0, 0, 0, 0)),
							ButtonDownImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_button_down.dds", Vector4(0, 0, 0, 0)),
							ButtonDisabledImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_button_disabled.dds", Vector4(0, 0, 0, 0)),	
							TextNormalImage= Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_text.dds", Vector4(6, 0, 0, 0)),
							TextHoverImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_text.dds", Vector4(6, 0, 0, 0)),
							TextDownImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_text.dds", Vector4(6, 0, 0, 0)),
							TextDisabledImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_text_disabled.dds", Vector4(6, 0, 0, 0)),
						},
						Size = Vector2(224,30),
						Location = Vector2(160, 148),
						Readonly = true,
						TextColor = ARGB(255, 243, 194, 10),
						-- MaxLength = 12,
						Text = lang:GetText("全部"),
						ChildComboListStyle =  "Gui.ChangeJobComboList",
					},
					
					Gui.ComboBox "c_roomstate"
					{
						Skin = Gui.ComboBoxSkin
						{
							ButtonNormalImage= Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_button_normal.dds", Vector4(0, 0, 0, 0)),
							ButtonHoverImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_button_hover.dds", Vector4(0, 0, 0, 0)),
							ButtonDownImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_button_down.dds", Vector4(0, 0, 0, 0)),
							ButtonDisabledImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_button_disabled.dds", Vector4(0, 0, 0, 0)),	
							TextNormalImage= Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_text.dds", Vector4(6, 0, 0, 0)),
							TextHoverImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_text.dds", Vector4(6, 0, 0, 0)),
							TextDownImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_text.dds", Vector4(6, 0, 0, 0)),
							TextDisabledImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_text_disabled.dds", Vector4(6, 0, 0, 0)),
						},

						Size = Vector2(224,30),
						Location = Vector2(160, 188),
						Readonly = true,
						TextColor = ARGB(255, 243, 194, 10),
						-- MaxLength = 12,
						Text = lang:GetText("全部"),
						ChildComboListStyle =  "Gui.ChangeJobComboList",						
					},
					
					Gui.Button "btn_save"
					{
						Size = Vector2(105, 35),
						Location = Vector2(77, 227),
						Text = lang:GetText("保存"),
						TextColor = ARGB(255, 211, 211, 211),
						HighlightTextColor = ARGB(255, 211, 211, 211),
						TextAlign = "kAlignCenterMiddle",
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/team/lb_contact_button_normal.dds", Vector4(5, 5, 5, 5)),
							HoverImage = Gui.Image("LobbyUI/team/lb_contact_button_hover.dds", Vector4(5, 5, 5, 5)),
							DownImage = Gui.Image("LobbyUI/team/lb_contact_button_down.dds", Vector4(5, 5, 5, 5)),
							DisabledImage = Gui.Image("LobbyUI/team/lb_contact_button_normal.dds", Vector4(5, 5, 5, 5)),			
						},
						EventClick = function()
							moshi_num = main_room_list_ui.c_moshi.SelectedIndex
							map_num = main_room_list_ui.c_map.SelectedIndex
							specialjob_num = main_room_list_ui.c_specialjob.SelectedIndex
							room_num = main_room_list_ui.c_roomnum.SelectedIndex
							roomstate_num = main_room_list_ui.c_roomstate.SelectedIndex
							
							config.Moshi = moshi_num
							config.Map = map_num
							config.Specialjob = specialjob_num
							config.Roomnum = room_num
							config.Roomstate = roomstate_num
							config:SaveQuickSetting()
							main_room_list_ui.setting_window.Visible = false
						end
					},
			
					Gui.Button "btn_cancel"
					{
						Size = Vector2(105, 35),
						Location = Vector2(230, 227),
						Text = lang:GetText("取消"),
						TextColor = ARGB(255, 211, 211, 211),
						HighlightTextColor = ARGB(255, 211, 211, 211),
						TextAlign = "kAlignCenterMiddle",
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/team/lb_contact_button_normal.dds", Vector4(5, 5, 5, 5)),
							HoverImage = Gui.Image("LobbyUI/team/lb_contact_button_hover.dds", Vector4(5, 5, 5, 5)),
							DownImage = Gui.Image("LobbyUI/team/lb_contact_button_down.dds", Vector4(5, 5, 5, 5)),
							DisabledImage = Gui.Image("LobbyUI/team/lb_contact_button_normal.dds", Vector4(5, 5, 5, 5)),			
						},
						EventClick = function()
							main_room_list_ui.c_moshi.Text = setting_moshi[moshi_num+1]
							main_room_list_ui.c_specialjob.Text = setting_specialjob[specialjob_num+1]
							main_room_list_ui.c_roomnum.Text = setting_roomnum[room_num+1]
							main_room_list_ui.c_roomstate.Text = setting_roomstate[roomstate_num+1]
							if moshi_num <= 0 then
								main_room_list_ui.c_map.Enable = false
								main_room_list_ui.c_map.Text = lang:GetText("全部")
							else
								main_room_list_ui.c_map.Enable = true
								main_room_list_ui.c_map.Text = setting_map[moshi_num][map_num+1]
							end
							main_room_list_ui.setting_window.Visible = false
						end
					},
				},
				
				Gui.Control "quick_start"
				{		
					Location = Vector2(25, 474),
					Size = Vector2(144, 74),
					BackgroundColor = ARGB(255, 255, 255, 255),

					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/lb_common_button_bg01.dds", Vector4(20, 20, 20, 20)),
					},
					
					-- 创建房间
					Gui.Button "btn_create_room"
					{
						Size = Vector2(130, 64),
						Location = Vector2(7 , 5),
						TextColor = ARGB(255, 255, 246, 235),
						FontSize = 18,
						PushDown = false,
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_create_normal.dds", Vector4(0, 0, 0, 0)),
							HoverImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_create_hover.dds", Vector4(0, 0, 0, 0)),
							DownImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_create_down.dds", Vector4(0, 0, 0, 0)),
							DisabledImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_create_disabled.dds", Vector4(0, 0, 0, 0)),
						},
					},
				},
		
				Gui.Control
				{		
					Location = Vector2(262, 474),
					Size = Vector2(157, 78),
					BackgroundColor = ARGB(255, 255, 255, 255),

					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_common_button_bg02.dds", Vector4(15, 0, 44, 0)),
					},
					-- 退出频道
					Gui.Button "btn_exitroomlist"
					{
						Size = Vector2(140, 64),
						Location = Vector2(7 , 8),
						TextColor = ARGB(255, 255, 246, 235),
						FontSize = 18,
						PushDown = flase,
						Visible = true,
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_exitchnl_normal.dds", Vector4(0, 0, 0, 0)),
							HoverImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_exitchnl_hover.dds", Vector4(0, 0, 0, 0)),
							DownImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_exitchnl_down.dds", Vector4(0, 0, 0, 0)),
							DisabledImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_exitchnl_disabled.dds", Vector4(0, 0, 0, 0)),
						},
						
						EventClick = function()
							GetBack(current_state)
						end,
					},
				},
					
				Gui.Control "ctrl_enter"
				{
					Size = Vector2(336, 78),
					Location = Vector2(392, 474),
					BackgroundColor = ARGB(255, 255, 255, 255),

					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_common_button_bg03.dds", Vector4(51, 20, 22, 20)),
					},
				
					-- 快速开始
					Gui.Button "btn_quick_start"
					{
						Size = Vector2(136, 64),
						Location = Vector2(6 , 7),
						-- Text = lang:GetText("快速开始"),
						TextColor = ARGB(255, 255, 246, 235),
						FontSize = 18,
						PushDown = false,
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_quick_normal.dds", Vector4(0, 0, 0, 0)),
							HoverImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_quick_hover.dds", Vector4(0, 0, 0, 0)),
							DownImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_quick_down.dds", Vector4(0, 0, 0, 0)),
							DisabledImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_quick_disabled.dds", Vector4(0, 0, 0, 0)),
						},
						EventClick = function()
							QuickStart(current_state)
						end,
					},
					
					-- 设置
					Gui.Button "btn_Setting"
					{
						Size = Vector2(52, 64),
						Location = Vector2(138 , 7),
						-- Text = lang:GetText("设置"),
						TextColor = ARGB(255, 255, 246, 235),
						FontSize = 18,
						PushDown = false,
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_install_normal.dds", Vector4(0, 0, 0, 0)),
							HoverImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_install_hover.dds", Vector4(0, 0, 0, 0)),
							DownImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_install_down.dds", Vector4(0, 0, 0, 0)),
							DisabledImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_install_disabled.dds", Vector4(0, 0, 0, 0)),
						},
						EventClick = function()
							main_room_list_ui.setting_window.Visible = true
						end,
					},

					-- 进入房间
					Gui.Button "btn_enter_room"
					{
						Size = Vector2(140, 64),
						Location = Vector2(190 , 7),
						-- Text = lang:GetText("进入房间"),
						TextColor = ARGB(255, 255, 246, 235),
						FontSize = 18,
						PushDown = false,
						Enable = false,
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_enter02_normal.dds", Vector4(0, 0, 0, 0)),
							HoverImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_enter02_hover.dds", Vector4(0, 0, 0, 0)),
							DownImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_enter02_down.dds", Vector4(0, 0, 0, 0)),
							DisabledImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_enter02_disabled.dds", Vector4(0, 0, 0, 0)),
						},
					},
				},
			},

			
			Gui.Control
			{
				Size = Vector2(239,22),
				Location = Vector2(30, 17),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_fjmc_ico.dds", Vector4(20, 20, 20, 20)),
				},
				Gui.Label "room_name2"
				{
					Size = Vector2(200, 22),
					Text = "",
					FontSize = 16,
					TextColor = ARGB(255, 0, 210, 225),
					Location = Vector2(100, 0),
				},
			},
		},
		Gui.Label "room_name1"
			{
				Size = Vector2(363, 40),
				Text = lang:GetText("当前位置:"),
				FontSize = 14,
				TextColor = ARGB(255, 255, 231, 26),
				-- BackgroundColor = ARGB(255, 255, 255, 255),
				Location = Vector2(700, 50),
				TextAlign = "kAlignLeftMiddle",
			},
	},
}

local match_window =
{
	Gui.Control "ctrl_Main_Window"
	{ 
		Size = Vector2(1123, 590),
		Location = Vector2(16, 25),
		BackgroundColor = ARGB(255, 255, 255, 255),
		-- Visible = false,
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_daoju_bg.dds", Vector4(22, 22, 22, 22)),
		},
		
		-- Gui.Label "lbl_GameType"
		-- {
			-- Size = Vector2(105, 36),
			-- Text = lang:GetText("游戏模式:"),
			-- TextColor = ARGB(255, 255, 0, 0),
			-- FontSize = 18,
			-- Location = Vector2(30, 20),
		-- },

		-- Gui.ComboBox "cbx_Mode"
		-- {
			-- Style = "Gui.WarZoneCreateComboBox",
			-- Size = Vector2(284, 38),
			-- FontSize = 18,
			-- Text = lang:GetText("团队竞技"),
			-- TextColor = ARGB(255, 255, 0, 0),
			-- Location = Vector2(30, 55),
			-- TextColor = ARGB(255,206,227,234),
			-- ChildComboListStyle =  "Gui.ChangeJobComboList",
			-- WithIconOffset = Vector2(240,0),
		-- },
		Gui.Control "image_map"
	    {
	    	Size = Vector2(676, 323),
			Location = Vector2(30, 30),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg3.dds", Vector4(16, 16, 16, 16)),
			},
			Gui.Control"lbl_badge"
			{	
				Size = Vector2(200, 250),
				Location = Vector2(38, 38),
				BackgroundColor = ARGB(255, 255, 255, 255),
				
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/pipei/rank00.dds", Vector4(14, 14, 14, 14)),
				},
			},
			Gui.Control"exp_jifen"
			{
				Size = Vector2(130,25),
				Location = Vector2(73, 267),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					-- BackgroundImage = Gui.Image("LobbyUI/vip/vip/lb_VIP_scrollbar_slider.dds", Vector4(10, 10, 20, 10)),
				},
				Gui.Control "exp_bar"
				{
					Size = Vector2(0,25),
					Location = Vector2(0, 0),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/vip/vip/lb_VIP_scrollbar_bg.dds", Vector4(10, 10, 20, 10)),
					},
				},
			},
			
			Gui.Control"rank_small"
			{	
				Size = Vector2(50, 50),
				Location = Vector2(20, 250),
				BackgroundColor = ARGB(255, 255, 255, 255),
				
				Skin = Gui.ControlSkin
				{
					-- BackgroundImage = Gui.Image("LobbyUI/pipei/rank00_small.dds", Vector4(14, 14, 14, 14)),
				},
			},
			
			Gui.Control"small"
			{	
				Size = Vector2(50, 50),
				Location = Vector2(200, 250),
				BackgroundColor = ARGB(255, 255, 255, 255),
				
				Skin = Gui.ControlSkin
				{
					-- BackgroundImage = Gui.Image("LobbyUI/pipei/rankXR01_small.dds", Vector4(14, 14, 14, 14)),
				},
			},
			
			Gui.Label "lbl_Paihang"
			{
				Size = Vector2(155, 38),
				Text = lang:GetText("比赛排位:"),
				TextColor = ARGB(255, 255, 247, 0),
				FontSize = 36,
				Location = Vector2(280, 30),
			},
			Gui.Label "lbl_paiwei"
			{
				Size = Vector2(180, 38),
				Text = lang:GetText(""),
				TextColor = ARGB(255, 255, 247, 0),
				FontSize = 36,
				Location = Vector2(440, 30),
			},
			Gui.Label "lbl_Pingji"
			{
				Size = Vector2(135, 38),
				Text = lang:GetText("评级K值:"),
				TextColor = ARGB(255, 255, 247, 0),
				FontSize = 24,
				Location = Vector2(280, 68),
			},
			Gui.Label "lbl_murder"
			{
				Size = Vector2(200, 38),
				Text = lang:GetText("杀人数:"),
				TextColor = ARGB(255, 200, 200,200),
				FontSize = 18,
				Location = Vector2(280, 100),
			},
			Gui.Label "lbl_die"
			{
				Size = Vector2(200, 38),
				Text = lang:GetText("死亡数:"),
				TextColor = ARGB(255, 200, 200,200),
				FontSize = 18,
				Location = Vector2(470, 100),
			},
			Gui.Label "lbl_win"
			{
				Size = Vector2(200, 38),
				Text = lang:GetText("胜利场次:"),
				TextColor = ARGB(255, 200, 200,200),
				FontSize = 18,
				Location = Vector2(280, 122),
			},
			Gui.Label "lbl_fail"
			{
				Size = Vector2(200, 38),
				Text = lang:GetText("失败场次:"),
				TextColor = ARGB(255, 200, 200,200),
				FontSize = 18,
				Location = Vector2(470, 122),
			},
			Gui.Label "lbl_assist"
			{
				Size = Vector2(200, 38),
				Text = lang:GetText("助攻数:"),
				TextColor = ARGB(255, 200, 200,200),
				FontSize = 18,
				Location = Vector2(280, 144),
			},
			Gui.Label "lbl_victory1"
			{
				Size = Vector2(200, 38),
				Text = lang:GetText("胜率:"),
				TextColor = ARGB(255, 200, 200,200),
				FontSize = 18,
				Location = Vector2(470, 144),
			},
			Gui.Label "lbl_victory"
			{
				Size = Vector2(200, 38),
				Text = lang:GetText("赛季杀敌数:"),
				TextColor = ARGB(255, 200, 200,200),
				FontSize = 18,
				Location = Vector2(280, 166),
			},
			
			Gui.Button "btn_zhanji"
			{
				Size = Vector2(120,50),
				Location = Vector2(280, 250),
				TextColor = ARGB(255, 255, 246, 235),
				FontSize = 18,
				PushDown = false,
				Enable = true,
				Visible = true,
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/pipei/match_result__normal.tga", Vector4(32, 0, 32, 0)),
					HoverImage = Gui.Image("LobbyUI/pipei/match_result_hover.tga", Vector4(32, 0, 32, 0)),
					DownImage = Gui.Image("LobbyUI/pipei/match_result_down.tga", Vector4(32, 0, 32, 0)),
					DisabledImage = Gui.Image("LobbyUI/pipei/match_result_disabled.tga", Vector4(32, 0, 32, 0)),
				},
				EventClick = function()
				
					ShoWmatch_zhanji_rank(root_ui)
				end,
			},
			Gui.Button "btn_chakan"
			{
				Size = Vector2(120,50),
				Location = Vector2(409, 250),
				TextColor = ARGB(255, 255, 246, 235),
				FontSize = 18,
				PushDown = false,
				Enable = true,
				Visible = true,
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/pipei/match_ranking_normal.tga", Vector4(32, 0, 32, 0)),
					HoverImage = Gui.Image("LobbyUI/pipei/match_ranking_hover.tga", Vector4(32, 0, 32, 0)),
					DownImage = Gui.Image("LobbyUI/pipei/match_ranking_down.tga", Vector4(32, 0, 32, 0)),
					DisabledImage = Gui.Image("LobbyUI/pipei/match_ranking_disabled.tga", Vector4(32, 0, 32, 0)),
				},
				EventClick = function()
					ShoWmatch_rank(root_ui)
				end,
			},	
			
			Gui.Button ""
			{
				Size = Vector2(120,50),
				Location = Vector2(540, 250),
				TextColor = ARGB(255, 255, 246, 235),
				FontSize = 18,
				PushDown = false,
				Enable = true,
				Visible = true,
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/pipei/match_rule_normal.tga", Vector4(32, 0, 32, 0)),
					HoverImage = Gui.Image("LobbyUI/pipei/match_rule_hover.tga", Vector4(32, 0, 32, 0)),
					DownImage = Gui.Image("LobbyUI/pipei/match_rule_down.tga", Vector4(32, 0, 32, 0)),
					DisabledImage = Gui.Image("LobbyUI/pipei/match_rule_disabled.tga", Vector4(32, 0, 32, 0)),
				},
				EventClick = function()
					ShoWmatch_rule_ui_rank(root_ui)
				end,
			},
		},
		Gui.Control
		{	Size = Vector2(680, 235),
			Location = Vector2(28, 350),
			BackgroundColor = ARGB(255, 255, 255, 255),
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/Friends/lb_battlefield_chat_bg_01.dds", Vector4(14, 14, 14, 14)),
			},
			
			Gui.MessagePanel "MesPanel_match"
			{
				Style = "Gui.MessagePanel",
				Size = Vector2(670, 200),
				Location = Vector2(0, 5),
				BackgroundColor = ARGB(0, 255, 255, 255),
				VisibleLine = 12,
				ScrollBarWidth = 16,
				
				ButtonHeight = 1,
				ButHeight = 17,
				MaxAllLine = 128,
				
				EventClick_Name = function()
					L_LobbyMain.ChatPrivate(match_window_ui.MesPanel_match.Click_Name)
				end
			},
			
			Gui.Control
			{
				Size = Vector2(680, 30),
				Location = Vector2(1,200),
				BackgroundColor = ARGB(0, 255, 255, 255),
				
				Gui.Control "ctr_Tex_back1"
				{
					Size = Vector2(664, 25),
					Location = Vector2(6, 2),
					BackgroundColor = ARGB(255, 255, 255, 255),
					
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/Friends/lb_battlefield_chat_bg_02_down.dds", Vector4(4, 4, 4, 4)),
					},
				},
				
				Gui.Textbox "Tex_room"
				{
					Size = Vector2(663, 25),
					Location = Vector2(78, 2),
					BackgroundColor = ARGB(0, 255, 255, 255),
					MaxLength = 120,
					TextPadding = Vector4(0, 0, 0, 0),
					
					EventValueEnter = function(sender, e)
						SpeakType(match_window_ui.BTN_Tex_sta,"/room",match_window_ui.Tex_room)
					end,
					
					EventEnter = function()
						match_window_ui.ctr_Tex_back1.Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/Friends/lb_battlefield_chat_bg_02_down.dds", Vector4(4, 4, 4, 4)),
						}
					end,
					
					EventLeave = function()
						match_window_ui.ctr_Tex_back1.Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/Friends/lb_battlefield_chat_bg_02_normal.dds", Vector4(4, 4, 4, 4)),
						}
					end,
				},
				
				Gui.Button "BTN_Tex_sta"
				{
					Size = Vector2(60,19),
					Location = Vector2(12, 5),
					TextAlign = "kAlignCenterMiddle",
					Text = lang:GetText("当前"),
					FontSize = 12,
					TextColor = ARGB(255, 214, 212, 207),
					HighlightTextColor = ARGB(255, 214, 212, 207),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/Friends/lb_battlefield_button_01_normal.dds", Vector4(4, 4, 4, 4)),
						HoverImage = Gui.Image("LobbyUI/Friends/lb_battlefield_button_01_hover.dds", Vector4(4, 4, 4, 4)),
						DownImage = Gui.Image("LobbyUI/Friends/lb_battlefield_button_01_down.dds", Vector4(4, 4, 4, 4)),
						DisabledImage = Gui.Image("LobbyUI/Friends/lb_battlefield_button_01_normal.dds", Vector4(4, 4, 4, 4)),
					},
					EventClick = function()
						match_window_ui.ctr_BTN_Choose.Visible = true
						match_window_ui.lab_timer_ctr.UseTimer = true
						match_window_ui.lab_timer_ctr:Show()	
					end,
				},
				
				Gui.Button
				{
					Size = Vector2(32,19),
					Location = Vector2(627, 5),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/Friends/lb_battlefield_button_02_normal.dds", Vector4(4, 4, 4, 4)),
						HoverImage = Gui.Image("LobbyUI/Friends/lb_battlefield_button_02_hover.dds", Vector4(4, 4, 4, 4)),
						DownImage = Gui.Image("LobbyUI/Friends/lb_battlefield_button_02_down.dds", Vector4(4, 4, 4, 4)),
						DisabledImage = Gui.Image("LobbyUI/Friends/lb_battlefield_button_02_normal.dds", Vector4(4, 4, 4, 4)),
					},
					EventClick = function()
						SpeakType(match_window_ui.BTN_Tex_sta,"/room",match_window_ui.Tex_room)
					end,
				},
				
				Gui.Button
				{
					Size = Vector2(16,19),
					Location = Vector2(652, 5),
					TextColor = ARGB(255, 37, 37, 37),
					HighlightTextColor = ARGB(255, 37, 37, 37),
					FontSize = 12,
					TextAlign = "kAlignCenterMiddle",
					Text = "C",
					Padding = Vector4(0, 0, 0, 0),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/Friends/lb_battlefield_button_01_normal.dds", Vector4(4, 4, 4, 4)),
						HoverImage = Gui.Image("LobbyUI/Friends/lb_battlefield_button_01_hover.dds", Vector4(4, 4, 4, 4)),
						DownImage = Gui.Image("LobbyUI/Friends/lb_battlefield_button_01_down.dds", Vector4(4, 4, 4, 4)),
						DisabledImage = Gui.Image("LobbyUI/Friends/lb_battlefield_button_01_normal.dds", Vector4(4, 4, 4, 4)),
					},
					EventClick = function()
						match_window_ui.MesPanel_match:ClearLines()
					end,
				},
			},
			
			Gui.Control "ctr_BTN_Choose"
			{
				 Size = Vector2(90, 70),
				 Location = Vector2(0, 50),
				 BackgroundColor = ARGB(255, 255, 255, 255),
				 Visible = false,
				
				 Skin = Gui.ControlSkin
				 {
					BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_summary_flop_bg_04.dds", Vector4(30 , 30, 30, 30)),
				 },
				
				 EventMouseEnter = function()
					match_window_ui.lab_timer_ctr.UseTimer = false
					match_window_ui.lab_timer_ctr:Show()
				 end,
				
				 EventMouseLeave = function()
					 match_window_ui.lab_timer_ctr.UseTimer = true
					 match_window_ui.lab_timer_ctr:Show()
				 end,
				
				Gui.Label "lab_timer_ctr"
				{
					 Size = Vector2(10,10),
					 Location = Vector2(0, 0),
					 BackgroundColor = ARGB(0, 255, 255, 255),
					 Visible = false,
					 UseTimer = true,
					 DisplayTime = 5,
					
					 EventClose = function()
						match_window_ui.ctr_BTN_Choose.Visible = false
					 end,
				},
				
				 Gui.Button
				 {
					 Size = Vector2(91,20),
					 Location = Vector2(0, 5),
					 TextColor = ARGB(255, 214, 212, 207),
					 HighlightTextColor = ARGB(255, 214, 212, 207),
					 BackgroundColor = ARGB(0, 255, 255, 255),
					 FontSize = 14,
					 TextAlign = "kAlignLeftMiddle",
					 Text = lang:GetText("/C 当前"),
					 Padding = Vector4(10, 0, 0, 4),
					
					 EventClick = function(sender, e)
						match_window_ui.ctr_BTN_Choose.Visible = false
						match_window_ui.BTN_Tex_sta.Text = lang:GetText("当前")
						match_window_ui.BTN_Tex_sta.TextColor = sender.TextColor
						match_window_ui.BTN_Tex_sta.HighlightTextColor = sender.HighlightTextColor
					 end,
				 },
				
				 Gui.Button
				 {
					 Size = Vector2(91,20),
					 Location = Vector2(0, 25),
					 TextColor = ARGB(255, 242, 127, 3),
					 HighlightTextColor = ARGB(255, 242, 127, 3),
					 BackgroundColor = ARGB(0, 255, 255, 255),
					 FontSize = 14,
					 TextAlign = "kAlignLeftMiddle",
					 Text = lang:GetText("/X 小喇叭"),
					 Padding = Vector4(10, 0, 0, 4),
					
					 EventClick = function(sender, e)
						match_window_ui.ctr_BTN_Choose.Visible = false
						match_window_ui.BTN_Tex_sta.Text = lang:GetText("小喇叭")
						match_window_ui.BTN_Tex_sta.TextColor = sender.TextColor
						match_window_ui.BTN_Tex_sta.HighlightTextColor = sender.HighlightTextColor
					 end,
				 },
				
				 Gui.Button
				 {
					 Size = Vector2(91,20),
					 Location = Vector2(0, 45),
					 TextColor = ARGB(255, 255, 234, 0),
					 HighlightTextColor = ARGB(255, 255, 234, 0),
					 BackgroundColor = ARGB(0, 255, 255, 255),
					 FontSize = 14,
					 TextAlign = "kAlignLeftMiddle",
					 Text = lang:GetText("/D 大喇叭"),
					 Padding = Vector4(10, 0, 0, 4),
					
					 EventClick = function(sender, e)
						match_window_ui.ctr_BTN_Choose.Visible = false
						match_window_ui.BTN_Tex_sta.Text = lang:GetText("大喇叭")
						match_window_ui.BTN_Tex_sta.TextColor = sender.TextColor
						match_window_ui.BTN_Tex_sta.HighlightTextColor = sender.HighlightTextColor
					end,
				 },
			},		
		},
		
		
		Gui.Control"ctr_play_list"
		{
			Size = Vector2(360, 390),
			Location = Vector2(735, 30),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Visible = true,
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_contact_bg2.dds", Vector4(38, 41, 38, 66)),	
			},
			
			Gui.Label
			{		
				Location = Vector2(5, 10),
				Size = Vector2(337, 30),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Text = lang:GetText("队伍列表"),
				FontSize = 24,
				TextColor = ARGB(255, 127, 127, 127),
				TextAlign = "kAlignCenterMiddle",
			},
			Gui.Label
			{		
				Location = Vector2(5, 7),
				Size = Vector2(337, 30),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Text = lang:GetText("队伍列表"),
				FontSize = 24,
				TextColor = ARGB(255, 255, 108, 0),
				TextAlign = "kAlignCenterMiddle",
			},
			Gui.Control 
			{		
				Location = Vector2(13, 38),
				Size = Vector2(330, 341),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_rank_bg_01.dds", Vector4(34, 34, 34, 34)),
				},																						
				Gui.ListTreeView "Fight_Team_Room_Player"
				{
					Style = "Gui.ListTreeViewWith_VScroll_FightTeam",
					Size = Vector2(329, 350),
					Location = Vector2(0,4),
					ItemHeight = 42,
					TreeVisible = false,
					-- MY_SPLIT_WIDTH = 28, --CHECKBOX 鼠标点击的偏移量
					AlwaysSelect = false,
					HeaderVisible = false,
					-- VScrollBarDisplay = "kVisible",
					-- VScrollBarWidth = 16,
					-- VScrollBarButtonSize = 16,
					CanKeySelect = false,
					VScrollBarWidth = 1,
					VScrollBarButtonSize = 1,
				},
			},
			Gui.Control ""
			{		
				Location = Vector2(120, 217),
				Size = Vector2(120, 24),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_room_closed_bg_hover.dds", Vector4(34, 34, 34, 34)),
				},	
				
			},
			Gui.Control ""
			{		
				Location = Vector2(120, 217+43),
				Size = Vector2(120, 24),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_room_closed_bg_hover.dds", Vector4(34, 34, 34, 34)),
				},	
				
			},
			Gui.Control ""
			{		
				Location = Vector2(120, 217+43+43),
				Size = Vector2(120, 24),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_room_closed_bg_hover.dds", Vector4(34, 34, 34, 34)),
				},	
				
			},
			Gui.Control ""
			{		
				Location = Vector2(120, 217+43+43+43),
				Size = Vector2(120, 24),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_room_closed_bg_hover.dds", Vector4(34, 34, 34, 34)),
				},	
				
			},
		},
		Gui.Control
		{
			Size = Vector2(168, 78),
			Location = Vector2(928, 420),
			BackgroundColor = ARGB(255, 255, 255, 255),

			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_common_button_bg03.dds", Vector4(51, 20, 22, 20)),
			},
			--进入
			Gui.Button "btn_invite"
			{
				Size = Vector2(156, 64),
				Location = Vector2(6 , 7),
				TextColor = ARGB(255, 255, 246, 235),
				FontSize = 18,
				PushDown = false,
				Enable = true,
				Visible = true,
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_invite1_normal.dds", Vector4(32, 0, 32, 0)),
					HoverImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_invite1_hover.dds", Vector4(32, 0, 32, 0)),
					DownImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_invite1_down.dds", Vector4(32, 0, 32, 0)),
					DisabledImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_invite1_disabled.dds.", Vector4(32, 0, 32, 0)),
				},
				EventClick = function()
					L_Friends.ShowInviteGameCreatematchWin(gui)
				end,
			},
		},
			--退出频道
			
		Gui.Control "ctrl_enter"
		{
			Size = Vector2(164, 78),
			Location = Vector2(737, 420),
			BackgroundColor = ARGB(255, 255, 255, 255),

			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_common_button_bg02.dds", Vector4(15, 0, 44, 0)),
			},
				
				--退出频道
			Gui.Button "btn_exit_channel"
			{
				Size = Vector2(148, 64),
				Location = Vector2(6 , 8),
				TextColor = ARGB(255, 255, 246, 235),
				FontSize = 18,
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_exitserver_normal.dds", Vector4(5, 5, 5, 5)),
					HoverImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_exitserver_hover.dds", Vector4(5, 5, 5, 5)),
					DownImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_exitserver_down.dds", Vector4(5, 5, 5, 5)),
					DisabledImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_exitserver_disabled.dds", Vector4(5, 5, 5, 5)),
				},
				EventClick = function()
					FightGetBack(current_state)
					if match_window_ui then
						match_window_ui.ctrl_Main_Window.Parent = nil
						match_window_ui = nil
					end
					-- match_window_ui.ctrl_Main_Window.Parent = nil
					
					-- match_time_ui = nil
					if host_character_info then
						host_character_info = NullPtr
						host_character_info = nil
					end
					if matchTime_window_ui then
						matchTime_window_ui = nil
					end
					state:LeaveRoom()
					state:LeaveChannel()
					ShowServerList(root_ui)
					match_Begin = false
					
					L_LobbyMain.EnterRoomState(true)
				end,
			},
		},
		Gui.Control "ctrl_match"
		{		
			Location = Vector2(832, 498),
			Size = Vector2(166, 82),
			BackgroundColor = ARGB(255, 255, 255, 255),

			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/lb_common_button_bg01.dds", Vector4(20, 20, 20, 20)),
			},
			
			--创建房间
			Gui.Button "btn_match"
			{
				Size = Vector2(152, 72),
				Location = Vector2(7 , 5),
				BackgroundColor = ARGB(255, 255, 255, 255),
				TextColor = ARGB(255, 226, 217, 208),
				TextAlign = "kAlignCenterMiddle",
				DisabledTextColor = ARGB(255, 37, 37, 37),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_find_normal.dds", Vector4(32, 0, 32, 0)),
					HoverImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_find_hover.dds", Vector4(32, 0, 32, 0)),
					DownImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_find_down.dds", Vector4(32, 0, 32, 0)),
					DisabledImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_find_disabled.dds", Vector4(32, 0, 32, 0)),
				},
				EventClick = function()
					needShowMatch_Time = true
					state:RoomChangeOption(L_FightTeam.create_source_room_option)
					state:RequestMatching()
				end,
			},
		},
	},
}

function FillMatchmain()
	local args = {pid = ptr_cast(game.CurrentState):GetCharacterId(),t = 0}
	rpc.safecall("get_qw_info", args, function(data)				
		local scoce = data.scoce
		local kill = data.kill
		local dead = data.dead
		local assist = data.assist
		local win = data.win
		local fail = data.fail
		local rank = data.rank
		local rankNum = data.rankNum
		local kValue = data.kValue
		local killSum = data.killSum
		local percent = win+fail
		local rate = data.rate

		if match_window_ui == nil then
			return
		end
		if rankNum == -1 then
			match_window_ui.lbl_paiwei.Text = lang:GetText("未定级")
		else
			match_window_ui.lbl_paiwei.Text = lang:GetText("第")..rankNum..lang:GetText("名")
		end
		
		if percent == 0 then
			match_window_ui.lbl_victory1.Text = lang:GetText("胜率: ")..percent.. lang:GetText(" %")
		else
			local percent1 =win/(win+fail)*100
			percent1 = math.floor(percent1)
			match_window_ui.lbl_victory1.Text = lang:GetText("胜率: ")..percent1.. lang:GetText(" %")
		end
		if scoce == 0 then 
			match_window_ui.lbl_Pingji.Text = lang:GetText("评级K值: ")..kValue	
		else
			match_window_ui.lbl_Pingji.Text = lang:GetText("积分: ")..scoce	
		end
		if scoce > 0 then
			match_window_ui.exp_jifen.Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/vip/vip/lb_VIP_scrollbar_slider.dds", Vector4(10, 10, 20, 10)),
			}
			if rate > 0 then
				match_window_ui.exp_bar.Size = Vector2((130/100*rate),25)
			else
				match_window_ui.exp_bar.Size = Vector2((0),25)
			end
		end
		
		
		
		if rank == 0 then
			match_window_ui.lbl_badge.Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/pipei/rank01_1X.dds", Vector4(0, 0, 0, 0)),
			}
		elseif rank == 1 then
			match_window_ui.lbl_badge.Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/pipei/rank01_2X.dds", Vector4(0, 0, 0, 0)),
			}
		elseif rank == 2 then
			match_window_ui.lbl_badge.Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/pipei/rank01_3X.dds", Vector4(0, 0, 0, 0)),
			}
		elseif rank == 3 then
			match_window_ui.lbl_badge.Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/pipei/rank02_1X.dds", Vector4(0, 0, 0, 0)),
			}
		elseif rank == 4 then
			match_window_ui.lbl_badge.Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/pipei/rank02_2X.dds", Vector4(0, 0, 0, 0)),
			}
		elseif rank == 5 then
			match_window_ui.lbl_badge.Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/pipei/rank02_3X.dds", Vector4(0, 0, 0, 0)),
			}
		elseif rank == 6 then
			match_window_ui.lbl_badge.Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/pipei/rank03_1X.dds", Vector4(0, 0, 0, 0)),
			}
			-- match_window_ui.lbl_badge.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/pipei/rankZJ01.dds", Vector4(0, 0, 0, 0))
		elseif rank == 7 then
			match_window_ui.lbl_badge.Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/pipei/rank03_2X.dds", Vector4(0, 0, 0, 0)),
			}
		elseif rank == 8 then
			match_window_ui.lbl_badge.Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/pipei/rank03_3X.dds", Vector4(0, 0, 0, 0)),
			}
		elseif rank == 9 then
			match_window_ui.lbl_badge.Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/pipei/rank04_1X.dds", Vector4(0, 0, 0, 0)),
			}
		elseif rank == 10 then
			match_window_ui.lbl_badge.Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/pipei/rank04_2X.dds", Vector4(0, 0, 0, 0)),
			}
		elseif rank == 11 then
			match_window_ui.lbl_badge.Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/pipei/rank04_3X.dds", Vector4(0, 0, 0, 0)),
			}
		elseif rank == 12 then
			match_window_ui.lbl_badge.Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/pipei/rank05_3X.dds", Vector4(0, 0, 0, 0)),
			}
		end
	
		
		if rank < 13 then
			if rank == 0 then
				match_window_ui.rank_small.Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/pipei/rank01_1X_small.dds", Vector4(0, 0, 0, 0)),
				}
			elseif rank == 1 then
				match_window_ui.rank_small.Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/pipei/rank01_2X_small.dds", Vector4(0, 0, 0, 0)),
				}
			elseif rank == 2 then
				match_window_ui.rank_small.Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/pipei/rank01_3X_small.dds", Vector4(0, 0, 0, 0)),
				}
			elseif rank == 3 then
				match_window_ui.rank_small.Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/pipei/rank02_1X_small.dds", Vector4(0, 0, 0, 0)),
				}
			elseif rank == 4 then
				match_window_ui.rank_small.Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/pipei/rank02_2X_small.dds", Vector4(0, 0, 0, 0)),
				}
			elseif rank == 5 then
				match_window_ui.rank_small.Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/pipei/rank02_3X_small.dds", Vector4(0, 0, 0, 0)),
				}
			elseif rank == 6 then
				match_window_ui.rank_small.Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/pipei/rank03_1X_small.dds", Vector4(0, 0, 0, 0)),
				}
			elseif rank == 7 then
				match_window_ui.rank_small.Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/pipei/rank03_2X_small.dds", Vector4(0, 0, 0, 0)),
				}
			elseif rank == 8 then
				match_window_ui.rank_small.Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/pipei/rank03_3X_small.dds", Vector4(0, 0, 0, 0)),
				}
			elseif rank == 9 then
				match_window_ui.rank_small.Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/pipei/rank04_1X_small.dds", Vector4(0, 0, 0, 0)),
				}
			elseif rank == 10 then
				match_window_ui.rank_small.Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/pipei/rank04_2X_small.dds", Vector4(0, 0, 0, 0)),
				}
			elseif rank == 11 then
				match_window_ui.rank_small.Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/pipei/rank04_3X_small.dds", Vector4(0, 0, 0, 0)),
				}
			elseif rank == 12 then
				match_window_ui.rank_small.Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/pipei/rank05_3X_small.dds", Vector4(0, 0, 0, 0)),
				}
			end
		end
		
		if rank < 13 then
			if rank == 0 then
				match_window_ui.small.Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/pipei/rank01_2X_small.dds", Vector4(0, 0, 0, 0)),
				}
			elseif rank == 1 then
				match_window_ui.small.Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/pipei/rank01_3X_small.dds", Vector4(0, 0, 0, 0)),
				}
			elseif rank == 2 then
				match_window_ui.small.Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/pipei/rank02_1X_small.dds", Vector4(0, 0, 0, 0)),
				}
			elseif rank == 3 then
				match_window_ui.small.Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/pipei/rank02_2X_small.dds", Vector4(0, 0, 0, 0)),
				}
			elseif rank == 4 then
				match_window_ui.small.Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/pipei/rank02_3X_small.dds", Vector4(0, 0, 0, 0)),
				}
			elseif rank == 5 then
				match_window_ui.small.Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/pipei/rank03_1X_small.dds", Vector4(0, 0, 0, 0)),
				}
			elseif rank == 6 then
				match_window_ui.small.Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/pipei/rank03_2X_small.dds", Vector4(0, 0, 0, 0)),
				}
			elseif rank == 7 then
				match_window_ui.small.Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/pipei/rank03_3X_small.dds", Vector4(0, 0, 0, 0)),
				}
			elseif rank == 8 then
				match_window_ui.small.Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/pipei/rank04_1X_small.dds", Vector4(0, 0, 0, 0)),
				}
			elseif rank == 9 then
				match_window_ui.small.Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/pipei/rank04_2X_small.dds", Vector4(0, 0, 0, 0)),
				}
			elseif rank == 10 then
				match_window_ui.small.Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/pipei/rank04_3X_small.dds", Vector4(0, 0, 0, 0)),
				}
			elseif rank == 11 or rank == 12 then
				match_window_ui.small.Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/pipei/rank05_3X_small.dds", Vector4(0, 0, 0, 0)),
				}
			end
		end
		
		
		match_window_ui.lbl_murder.Text = lang:GetText("杀人数:  ")..kill
		match_window_ui.lbl_die.Text = lang:GetText("死亡数:  ")..dead
		match_window_ui.lbl_win.Text = lang:GetText("胜利场次: ")..win
		match_window_ui.lbl_fail.Text = lang:GetText("失败场次: ")..fail
		match_window_ui.lbl_assist.Text = lang:GetText("助攻数: ")..assist
		match_window_ui.lbl_victory.Text = lang:GetText("赛季杀敌数: ")..killSum
		
	end)
end

--枪王排行榜
zhanji_ui = 
{
	Gui.Control "ctrl_Main_Window"
	{
		Size = Vector2(1116, 586),
		Location = Vector2(19, 25),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/lb_shop_bg2.dds", Vector4(14, 14, 14, 14)),
		},

		Gui.Control "con_1"
		{
			Size = Vector2(1116, 586),
			Location = Vector2(0, 0),
			Gui.Control "con_1_bg"
			{
				Size = Vector2(1101, 551),
				Location = Vector2(9, 34),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_daoju_bg.dds", Vector4(22, 22, 22, 22)),
				},
				Gui.Control 
				{							
					Location = Vector2(10, 10),
					Size = Vector2(1086, 536),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg3.dds", Vector4(22, 22, 22, 22)),
					},
					Gui.Control""
					{	
						Size = Vector2(369, 50),
						Location = Vector2(400, 10),
						BackgroundColor = ARGB(255, 255, 255, 255),
						
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/pipei/match_finally01.dds", Vector4(14, 14, 14, 14)),
						},
					},
					Gui.Control "con1_ltv_bg"
					{
						Location = Vector2(10, 60),
						Size = Vector2(1076, 423),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/lb_battlefield_serverlist_bg01b.tga", Vector4(7, 42, 7, 8)),
						},
						Gui.ListTreeView "con1_ltv"
						{
							ItemHeight = 32,
							Location = Vector2(0, 8),
							Size = Vector2(1116, 586),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Style = "Gui.ListTreeViewWith_match_VScroll",
							HScrollBarDisplay = "kHide",
							VScrollBarDisplay = "kHide",
							TreeVisible = false,
							AlwaysSelect = false,
							HeaderHeight = 30,
						},
					},
					-- 上一页
					Gui.Button "btn_front_page"
					{
						Size = Vector2(14, 31),
						Location = Vector2(650, 495),
						TextColor = ARGB(255, 255, 246, 235),
						FontSize = 18,
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/lb_shop_button05_normal.dds", Vector4(0, 0, 0, 0)),
							HoverImage = Gui.Image("LobbyUI/lb_shop_button05_hover.dds", Vector4(0, 0, 0, 0)),
							DownImage = Gui.Image("LobbyUI/lb_shop_button05_down.dds", Vector4(0, 0, 0, 0)),
							DisabledImage = Gui.Image("LobbyUI/lb_shop_button05_normal.dds", Vector4(0, 0, 0, 0)),
						},
						EventClick = function()
							if rank_select_page1 > 1 then
								rank_select_page1 = rank_select_page1 - 1
								FillMatchmain_zhanji()
							end
						end
					},
				
					--页码
					Gui.Label "lb_page_number"
					{
						Location = Vector2(670, 490),
						Size = Vector2(175, 37),
						FontSize = 24,
						TextAlign = "kAlignCenterMiddle",
						TextColor = ARGB(255, 103, 102, 98),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button06_bg.dds", Vector4(14, 14, 14, 14)),
						},
					},

					--下一页
					Gui.Button "btn_next_page"
					{
						Size = Vector2(14, 31),
						Location = Vector2(854, 495),
						TextColor = ARGB(255, 255, 246, 235),
						FontSize = 18,
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/lb_shop_button06_normal.dds", Vector4(0, 0, 0, 0)),
							HoverImage = Gui.Image("LobbyUI/lb_shop_button06_hover.dds", Vector4(0, 0, 0, 0)),
							DownImage = Gui.Image("LobbyUI/lb_shop_button06_down.dds", Vector4(0, 0, 0, 0)),
							DisabledImage = Gui.Image("LobbyUI/lb_shop_button06_normal.dds", Vector4(0, 0, 0, 0)),
						},
						EventClick = function()
							if rank_select_page1 < max_page1 then
								rank_select_page1 = rank_select_page1 + 1
								FillMatchmain_zhanji()
							end
						end
					},
				},
			},
			Gui.Button "btn_Close"
			{
				Size = Vector2(64, 54),
				Location = Vector2(1047, 1),
				PushDown = false,
				Hint = lang:GetText("关闭战绩表并返回至战区"),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button01_normal.dds", Vector4(0, 0, 0, 0)),
					HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button01_hover.dds", Vector4(0, 0, 0, 0)),
					DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button01_down.dds", Vector4(0, 0, 0, 0)),
					DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button01_normal.dds", Vector4(0, 0, 0, 0)),
				},
				EventClick = function()
					L_WarZone.Show(L_LobbyMain.LobbyMainWin_Boddy.LobbyMainWin_Boddy_Root)
				end
			},
		},
	},
}

rank_ui = 
{
	Gui.Control "ctrl_Main_Window"
	{
		Size = Vector2(1116, 586),
		Location = Vector2(19, 25),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/lb_shop_bg2.dds", Vector4(14, 14, 14, 14)),
		},

		Gui.Control "con_1"
		{
			Size = Vector2(1116, 586),
			Location = Vector2(0, 0),
			Gui.Control "con_1_bg"
			{
				Size = Vector2(1101, 551),
				Location = Vector2(9, 34),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_daoju_bg.dds", Vector4(22, 22, 22, 22)),
				},
				Gui.Control 
				{							
					Location = Vector2(10, 10),
					Size = Vector2(1086, 536),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg3.dds", Vector4(22, 22, 22, 22)),
					},
					Gui.Control""
					{	
						Size = Vector2(369, 50),
						Location = Vector2(400, 10),
						BackgroundColor = ARGB(255, 255, 255, 255),
						
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/pipei/match_finally02.dds", Vector4(14, 14, 14, 14)),
						},
					},
					Gui.Control "con1_ltv_bg"
					{
						Location = Vector2(10, 60),
						Size = Vector2(1076, 423),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/lb_battlefield_serverlist_bg01b.tga", Vector4(7, 42, 7, 8)),
						},
						Gui.ListTreeView "con1_ltv1"
						{
							ItemHeight = 33,
							Location = Vector2(0, 8),
							Size = Vector2(1116, 586),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Style = "Gui.ListTreeViewWith_match_VScroll",
							HScrollBarDisplay = "kHide",
							VScrollBarDisplay = "kHide",
							TreeVisible = false,
							AlwaysSelect = true,
							HeaderHeight = 30,
						},
					},
					--上一页
					Gui.Button "btn_front_page"
					{
						Size = Vector2(14, 31),
						Location = Vector2(650, 495),
						TextColor = ARGB(255, 255, 246, 235),
						FontSize = 18,
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/lb_shop_button05_normal.dds", Vector4(0, 0, 0, 0)),
							HoverImage = Gui.Image("LobbyUI/lb_shop_button05_hover.dds", Vector4(0, 0, 0, 0)),
							DownImage = Gui.Image("LobbyUI/lb_shop_button05_down.dds", Vector4(0, 0, 0, 0)),
							DisabledImage = Gui.Image("LobbyUI/lb_shop_button05_normal.dds", Vector4(0, 0, 0, 0)),
						},
						EventClick = function()
							if rank_select_page2 > 1 then
								rank_select_page2 = rank_select_page2 - 1
								FillMatchmain_rank()
							end
						end
					},
				
					--页码
					Gui.Label "lb_page_number"
					{
						Location = Vector2(670, 490),
						Size = Vector2(175, 37),
						FontSize = 24,
						Text = "1/1",
						TextAlign = "kAlignCenterMiddle",
						TextColor = ARGB(255, 103, 102, 98),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button06_bg.dds", Vector4(14, 14, 14, 14)),
						},
					},

					--下一页
					Gui.Button "btn_next_page"
					{
						Size = Vector2(14, 31),
						Location = Vector2(854, 495),
						TextColor = ARGB(255, 255, 246, 235),
						FontSize = 18,
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/lb_shop_button06_normal.dds", Vector4(0, 0, 0, 0)),
							HoverImage = Gui.Image("LobbyUI/lb_shop_button06_hover.dds", Vector4(0, 0, 0, 0)),
							DownImage = Gui.Image("LobbyUI/lb_shop_button06_down.dds", Vector4(0, 0, 0, 0)),
							DisabledImage = Gui.Image("LobbyUI/lb_shop_button06_normal.dds", Vector4(0, 0, 0, 0)),
						},
						EventClick = function()
							if rank_select_page2 < max_page2 then
								rank_select_page2 = rank_select_page2 + 1
								FillMatchmain_rank()
							end
						end
					},
				},
			},
			Gui.Button "btn_Close"
			{
				Size = Vector2(64, 54),
				Location = Vector2(1047, 1),
				PushDown = false,
				Hint = lang:GetText("关闭排行榜并返回至战区"),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button01_normal.dds", Vector4(0, 0, 0, 0)),
					HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button01_hover.dds", Vector4(0, 0, 0, 0)),
					DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button01_down.dds", Vector4(0, 0, 0, 0)),
					DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button01_normal.dds", Vector4(0, 0, 0, 0)),
				},
				EventClick = function()
					L_WarZone.Show(L_LobbyMain.LobbyMainWin_Boddy.LobbyMainWin_Boddy_Root)
				end
			},
		},
	},
}
rule_ui = 
{
	Gui.Control "ctrl_Main_Window"
	{
		Size = Vector2(1116, 586),
		Location = Vector2(19, 25),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/lb_shop_bg2.dds", Vector4(14, 14, 14, 14)),
		},
		Gui.Control "con_1"
		{
			Size = Vector2(1116, 586),
			Location = Vector2(0, 0),
			Gui.Control "con_1_bg"
			{
				Size = Vector2(1101, 551),
				Location = Vector2(9, 34),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_daoju_bg.dds", Vector4(22, 22, 22, 22)),
				},
				Gui.Control 
				{							
					Location = Vector2(10, 10),
					Size = Vector2(1086, 536),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg3.dds", Vector4(22, 22, 22, 22)),
					},
					Gui.Control 
					{							
						Location = Vector2(60, 5),
						Size = Vector2(130, 130),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/pipei/rank01.DDS", Vector4(22, 22, 22, 22)),
						},
					},
					Gui.Control 
					{							
						Location = Vector2(260, 5),
						Size = Vector2(130, 130),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/pipei/rank02.DDS", Vector4(22, 22, 22, 22)),
						},
					},
					
					Gui.Control 
					{							
						Location = Vector2(460, 5),
						Size = Vector2(130, 130),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/pipei/rank03.DDS", Vector4(22, 22, 22, 22)),
						},
					},
					
					Gui.Control 
					{							
						Location = Vector2(660, 5),
						Size = Vector2(130, 130),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/pipei/rank04.DDS", Vector4(22, 22, 22, 22)),
						},
					},
					Gui.Control 
					{							
						Location = Vector2(860, 5),
						Size = Vector2(130, 130),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/pipei/rank05.DDS", Vector4(22, 22, 22, 22)),
						},
					},
					
					Gui.Control ""
					{
						Size = Vector2(563, 400),
						Location = Vector2(0, 140),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/lb_shop_bg2.dds", Vector4(14, 14, 14, 14)),
						},
						Gui.Label ""
						{
							Size = Vector2(554,26),
							Location = Vector2(4,1),
							BackgroundColor = ARGB(40, 255, 255, 255),
							TextColor = ARGB(255, 200, 200, 1),
							TextAlign = "kAlignLeftMiddle",
							FontSize = 18,
							Text = lang:GetText("   等级       最低分       最高分        赛季奖励   "),
						},
						Gui.Label ""
						{
							Size = Vector2(554,26),
							Location = Vector2(4,29),
							BackgroundColor = ARGB(20, 255, 255, 255),
							TextColor = ARGB(255, 200, 200, 1),
							TextAlign = "kAlignLeftMiddle",
							FontSize = 18,
							Text = lang:GetText("  新秀1星      1　          420        新秀杀敌宝箱   "),
						},	
						Gui.Label ""
						{
							Size = Vector2(554,26),
							Location = Vector2(4,57),
							BackgroundColor = ARGB(10, 255, 255, 255),
							TextColor = ARGB(255, 200, 200, 1),
							TextAlign = "kAlignLeftMiddle",
							FontSize = 18,
							Text = lang:GetText("  新秀2星      421          923        新秀杀敌宝箱   "),
						},	
						Gui.Label ""
						{
							Size = Vector2(554,26),
							Location = Vector2(4,85),
							BackgroundColor = ARGB(20, 255, 255, 255),
							TextColor = ARGB(255, 200, 200, 1),
							TextAlign = "kAlignLeftMiddle",
							FontSize = 18,
							Text = lang:GetText("  新秀3星      924          1500       新秀杀敌宝箱   "),
						},	
						Gui.Label ""
						{
							Size = Vector2(554,26),
							Location = Vector2(4,113),
							BackgroundColor = ARGB(10, 255, 255, 255),
							TextColor = ARGB(255, 200, 200, 1),
							TextAlign = "kAlignLeftMiddle",
							FontSize = 18,
							Text = lang:GetText("  职业1星      1501         2760       职业杀敌宝箱   "),
						},	
						Gui.Label ""
						{
							Size = Vector2(554,26),
							Location = Vector2(4,141),
							BackgroundColor = ARGB(20, 255, 255, 255),
							TextColor = ARGB(255, 200, 200, 1),
							TextAlign = "kAlignLeftMiddle",
							FontSize = 18,
							Text = lang:GetText("  职业2星      2761         4267       职业杀敌宝箱   "),
						},	
						Gui.Label ""
						{
							Size = Vector2(554,26),
							Location = Vector2(4,169),
							BackgroundColor = ARGB(10, 255, 255, 255),
							TextColor = ARGB(255, 200, 200, 1),
							TextAlign = "kAlignLeftMiddle",
							FontSize = 18,
							Text = lang:GetText("  职业3星      4268         6000       职业杀敌宝箱   "),
						},	
						Gui.Label ""
						{
							Size = Vector2(558,26),
							Location = Vector2(2,197),
							BackgroundColor = ARGB(20, 255, 255, 255),
							TextColor = ARGB(255, 200, 200, 1),
							TextAlign = "kAlignLeftMiddle",
							FontSize = 18,
							Text = lang:GetText("  专家1星      6001         8520       专家杀敌宝箱   "),
						},	
						Gui.Label ""
						{
							Size = Vector2(554,26),
							Location = Vector2(4,225),
							BackgroundColor = ARGB(10, 255, 255, 255),
							TextColor = ARGB(255, 200, 200, 1),
							TextAlign = "kAlignLeftMiddle",
							FontSize = 18,
							Text = lang:GetText("  专家2星      8521         11535      专家杀敌宝箱   "),
						},	
						Gui.Label ""
						{
							Size = Vector2(554,26),
							Location = Vector2(4,253),
							BackgroundColor = ARGB(20, 255, 255, 255),
							TextColor = ARGB(255, 200, 200, 1),
							TextAlign = "kAlignLeftMiddle",
							FontSize = 18,
							Text = lang:GetText("  专家3星      11536        15000      专家杀敌宝箱   "),
						},	
						Gui.Label ""
						{
							Size = Vector2(554,26),
							Location = Vector2(4,281),
							BackgroundColor = ARGB(10, 255, 255, 255),
							TextColor = ARGB(255, 200, 200, 1),
							TextAlign = "kAlignLeftMiddle",
							FontSize = 18,
							Text = lang:GetText("  英雄1星      15001        19200      英雄杀敌宝箱   "),
						},	
						Gui.Label ""
						{
							Size = Vector2(554,26),
							Location = Vector2(4,309),
							BackgroundColor = ARGB(20, 255, 255, 255),
							TextColor = ARGB(255, 200, 200, 1),
							TextAlign = "kAlignLeftMiddle",
							FontSize = 18,
							Text = lang:GetText("  英雄2星      19201        24225      英雄杀敌宝箱   "),
						},
						
						Gui.Label ""
						{
							Size = Vector2(554,26),
							Location = Vector2(4,337),
							BackgroundColor = ARGB(10, 255, 255, 255),
							TextColor = ARGB(255, 200, 200, 1),
							TextAlign = "kAlignLeftMiddle",
							FontSize = 18,
							Text = lang:GetText("  英雄3星      24226        无限       英雄杀敌宝箱   "),
						},
						Gui.Label ""
						{
							Size = Vector2(554,26),
							Location = Vector2(4,365),
							BackgroundColor = ARGB(10, 255, 255, 255),
							TextColor = ARGB(255, 200, 200, 1),
							TextAlign = "kAlignLeftMiddle",
							FontSize = 18,
							Text = lang:GetText("   王者             前10名             王者杀敌宝箱   "),
						},
						-- Gui.Label ""
						-- {
							-- Size = Vector2(554,26),
							-- Location = Vector2(4,365),
							-- BackgroundColor = ARGB(20, 255, 255, 255),
							-- TextColor = ARGB(255, 200, 200, 1),
							-- TextAlign = "kAlignLeftMiddle",
							-- FontSize = 18,
							-- Text = lang:GetText("  王者"),
						-- },	
						-- Gui.Label ""
						-- {
							-- Size = Vector2(554,26),
							-- Location = Vector2(150,365),
							-- BackgroundColor = ARGB(20, 255, 255, 255),
							-- TextColor = ARGB(255, 200, 200, 1),
							-- TextAlign = "kAlignLeftMiddle",
							-- FontSize = 18,
							-- Text = lang:GetText(" 分数最高者10名"),
						-- },
						-- Gui.Label ""
						-- {
							-- Size = Vector2(554,26),
							-- Location = Vector2(364,365),
							-- BackgroundColor = ARGB(20, 255, 255, 255),
							-- TextColor = ARGB(255, 200, 200, 1),
							-- TextAlign = "kAlignLeftMiddle",
							-- FontSize = 17,
							-- Text = lang:GetText("王者杀敌宝箱"),
						-- },	
					},	
					Gui.Control ""
					{
						Size = Vector2(523, 400),
						Location = Vector2(570, 140),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/lb_shop_bg2.dds", Vector4(14, 14, 14, 14)),
						},
						Gui.Label
						{
							Size = Vector2(100, 50),
							Location = Vector2(8, 10),
							Text = lang:GetText("比赛规则"),
							TextAlign = "kAlignRightMiddle",
							FontSize = 24,
							TextColor = ARGB(255, 250, 250, 1),
						},
						Gui.Control
						{
							Size = Vector2(523, 536),
							Location = Vector2(0, 30),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/Compose/lb_melting_bg_cwlb.dds", Vector4(0,0,0,0)),
							},
							Gui.Control
							{
								Size = Vector2(523, 536),
								Location = Vector2(0, 30),
								BackgroundColor = ARGB(255, 255, 255, 255),
								Skin = Gui.ControlSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/Compose/lb_melting_bg_cwlb.dds", Vector4(0,0,0,0)),
								},
								Gui.TextArea ""
								{
									Readonly = true,
									Size = Vector2(523, 536),
									Location = Vector2(10, 0),
									Text = match_des[1],
									FontSize = 22,
									Fold = true,
									TextColor = ARGB(255, 255, 255, 255),
									VScrollBarWidth = 10,
									VScrollBarButtonSize = 0,
									Skin = Gui.ScrollableControlSkin
									{
										VSliderNormalImage = Gui.Image("LobbyUI/team/NewFight/lb_common_scrollbar_02_slider.dds", Vector4(5, 5, 5, 5)),
										VSliderHoverImage = Gui.Image("LobbyUI/team/NewFight/lb_common_scrollbar_02_slider.dds", Vector4(5, 5, 5, 5)),
										VSliderDownImage = Gui.Image("LobbyUI/team/NewFight/lb_common_scrollbar_02_slider.dds", Vector4(5, 5, 5, 5)),
										VSliderDisabledImage = nil,
										
										VBarBackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_common_scrollbar_02_bg.dds", Vector4(5, 5, 5, 5)),
										VBarDisabledBackgroundImage = nil,
										BarCornerImage = nil,
									},
								},
							},
						},
					},
				},
			},
			
			Gui.Button "btn_Close"
			{
				Size = Vector2(64, 54),
				Location = Vector2(1047, 1),
				PushDown = false,
				Hint = lang:GetText("关闭比赛规则并返回至战区"),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button01_normal.dds", Vector4(0, 0, 0, 0)),
					HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button01_hover.dds", Vector4(0, 0, 0, 0)),
					DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button01_down.dds", Vector4(0, 0, 0, 0)),
					DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button01_normal.dds", Vector4(0, 0, 0, 0)),
				},
				EventClick = function()
					L_WarZone.Show(L_LobbyMain.LobbyMainWin_Boddy.LobbyMainWin_Boddy_Root)
				end
			},
		},
	},
}

function ShoWmatch_rule_ui_rank(parent_win)
	
	L_LobbyMain.HideAll()
	--创建界面
	if not match_ank_ui2 then
		match_ank_ui2 = Gui.Create(parent_win)(rule_ui)
	end
	match_ank_ui2.ctrl_Main_Window.Parent = parent_win
end

function ShoWmatch_zhanji_rank(parent_win)
	
	L_LobbyMain.HideAll()
	--创建界面
	if not match_ank_ui then
		match_ank_ui = Gui.Create(parent_win)(zhanji_ui)
	end
	match_ank_ui.ctrl_Main_Window.Parent = parent_win
	FillMatchmain_zhanji()
end

function FillMatchmain_zhanji()
	local args = {pid = ptr_cast(game.CurrentState):GetCharacterId(),t = 1,page = rank_select_page1}
	rpc.safecall("get_qw_info", args, 
	function(data)
		max_page1 = data.pageNum
		rank_select_page1 = data.page
		my_rank_page = data.page	
		match_ank_ui.lb_page_number.Text = data.page.."/"..data.pageNum
		-- max_page1 = data.pageNum
		local items = data.items
		local list = match_ank_ui.con1_ltv
		list:DeleteAll()
		list:DeleteColumns()
		list:AddColumn("",30, "kAlignLeftMiddle")	
		list:AddColumn(lang:GetText("时间"),150, "kAlignLeftMiddle")	
		list:AddColumn(lang:GetText("段位"),100, "kAlignCenterMiddle")
		list:AddColumn(lang:GetText("积分"),100, "kAlignCenterMiddle")
		list:AddColumn(lang:GetText("杀敌"),100, "kAlignCenterMiddle")
		list:AddColumn(lang:GetText("死亡"),100, "kAlignCenterMiddle")
		list:AddColumn(lang:GetText("胜场"),100, "kAlignCenterMiddle")
		list:AddColumn(lang:GetText("失败"),100, "kAlignCenterMiddle")
		list:AddColumn(lang:GetText("胜率"),100, "kAlignCenterMiddle")
		list:AddColumn(lang:GetText("助攻"),100, "kAlignCenterMiddle")
		list:AddColumn(lang:GetText("总杀敌数"),100, "kAlignCenterMiddle")
		local i = 0
		for i,v in ipairs(items) do
			local sub_item = list:AddItem(list.RootItem)
		
			if i % 2 == 0 then
				sub_item.BGSkin = Skin.ListItemSkin_Single
			else	
				sub_item.BGSkin = Skin.ListItemSkin_Double
			end	
			sub_item:AddSubItem(v.t)
			if v.r == -1 then
				sub_item:SetIcon(2, Gui.Icon("LobbyUI/pipei/icon_rank00.dds"),Vector4(0, 0, 0, 0))
			elseif	v.r == 0 then
				sub_item:SetIcon(2, Gui.Icon("LobbyUI/pipei/icon_rank01_1X.dds"),Vector4(0, 0, 0, 0))
			elseif	v.r == 1 then
				sub_item:SetIcon(2, Gui.Icon("LobbyUI/pipei/icon_rank01_2X.dds"),Vector4(0, 0, 0, 0))
			elseif	v.r == 2 then
				sub_item:SetIcon(2, Gui.Icon("LobbyUI/pipei/icon_rank01_3X.dds"),Vector4(0, 0, 0, 0))
			elseif	v.r == 3 then
				sub_item:SetIcon(2, Gui.Icon("LobbyUI/pipei/icon_rank02_1X.dds"),Vector4(0, 0, 0, 0))
			elseif	v.r == 4 then
				sub_item:SetIcon(2, Gui.Icon("LobbyUI/pipei/icon_rank02_2X.dds"),Vector4(0, 0, 0, 0))
			elseif	v.r == 5 then
				sub_item:SetIcon(2, Gui.Icon("LobbyUI/pipei/icon_rank02_3X.dds"),Vector4(0, 0, 0, 0))
			elseif	v.r == 6 then
				sub_item:SetIcon(2, Gui.Icon("LobbyUI/pipei/icon_rank03_1X.dds"),Vector4(0, 0, 0, 0))
			elseif	v.r == 7 then
				sub_item:SetIcon(2, Gui.Icon("LobbyUI/pipei/icon_rank03_2X.dds"),Vector4(0, 0, 0, 0))
			elseif	v.r == 8 then
				sub_item:SetIcon(2, Gui.Icon("LobbyUI/pipei/icon_rank03_3X.dds"),Vector4(0, 0, 0, 0))
			elseif	v.r == 9 then
				sub_item:SetIcon(2, Gui.Icon("LobbyUI/pipei/icon_rank04_1X.dds"),Vector4(0, 0, 0, 0))
			elseif	v.r == 10 then
				sub_item:SetIcon(2, Gui.Icon("LobbyUI/pipei/icon_rank04_2X.dds"),Vector4(0, 0, 0, 0))
			elseif	v.r == 11 then
				sub_item:SetIcon(2, Gui.Icon("LobbyUI/pipei/icon_rank04_3X.dds"),Vector4(0, 0, 0, 0))
			elseif	v.r == 12 then
				sub_item:SetIcon(2, Gui.Icon("LobbyUI/pipei/icon_rank05_3X.dds"),Vector4(0, 0, 0, 0))
			end
			sub_item:AddSubItem(v.s)
			sub_item:AddSubItem(v.k)
			sub_item:AddSubItem(v.d)
			sub_item:AddSubItem(v.w)
			sub_item:AddSubItem(v.f)
			local temp = v.w
			local temp1 = v.f
			local temp2 = temp+temp1
			if temp2 == 0 then
				sub_item:AddSubItem(0)
			else
				local temp3 = 100*(temp/temp2)
				temp3 = math.floor(temp3).."%"
				sub_item:AddSubItem(temp3)
			end
			sub_item:AddSubItem(v.a)
			sub_item:AddSubItem(v.ks)
				
		end
	end)
end

function ShoWmatch_rank(parent_win)
	
	L_LobbyMain.HideAll()
	--创建界面
	if not match_ank_ui1 then
		match_ank_ui1 = Gui.Create(parent_win)(rank_ui)
	end
	match_ank_ui1.ctrl_Main_Window.Parent = parent_win
	 FillMatchmain_rank()
end
function FillMatchmain_rank()
	local args = {pid = ptr_cast(game.CurrentState):GetCharacterId(),t = 2,page = rank_select_page2}
	rpc.safecall("get_qw_info", args, 
	function(data)
	
		max_page2 = data.pageNum
		rank_select_page2 = data.page
		my_rank_page1 = data.page	
		match_ank_ui1.lb_page_number.Text = data.page.."/"..data.pageNum
		-- max_page2 = data.pageNum
		local items = data.items
		local list = match_ank_ui1.con1_ltv1
		list:DeleteAll()
		list:DeleteColumns()
		list:AddColumn("",10, "kAlignLeftMiddle")	
		list:AddColumn(lang:GetText("排名"),80, "kAlignCenterMiddle")	
		-- list:AddColumn(lang:GetText("VIP"),60, "kAlignCenterMiddle")
		list:AddColumn(lang:GetText("等级"),70, "kAlignCenterMiddle")
		list:AddColumn(lang:GetText("玩家"),170, "kAlignCenterMiddle")
		
		list:AddColumn(lang:GetText("段位"),110, "kAlignCenterMiddle")
		list:AddColumn(lang:GetText("积分"),110, "kAlignCenterMiddle")
		list:AddColumn(lang:GetText("杀敌"),110, "kAlignCenterMiddle")
		list:AddColumn(lang:GetText("死亡"),110, "kAlignCenterMiddle")
		list:AddColumn(lang:GetText("胜场"),110, "kAlignCenterMiddle")
		list:AddColumn(lang:GetText("失败"),110, "kAlignCenterMiddle")
		list:AddColumn(lang:GetText("胜率"),110, "kAlignCenterMiddle")
		local i = 0
		for i,v in ipairs(items) do
			local sub_item = list:AddItem(list.RootItem)
			if i % 2 == 0 then
				sub_item.BGSkin = Skin.ListItemSkin_Single
			else	
				sub_item.BGSkin = Skin.ListItemSkin_Double
			end	
			sub_item:AddSubItem(v.rN)
			-- if v.vR > 0 then
				-- sub_item:SetIcon(2, Gui.Icon("LobbyUI/vip/vip/VIP_button_0"..v.vR.."_normal.dds"),Vector4(0, 0, 0, 0))
			-- else
				-- sub_item:AddSubItem(nil)
			-- end
			sub_item:AddSubItem(v.pR)
			sub_item:AddSubItem(v.n)
			if v.r == -1 then
				sub_item:SetIcon(4, Gui.Icon("LobbyUI/pipei/icon_rank00.dds"),Vector4(0, 0, 0, 0))
			elseif	v.r == 0 then
				sub_item:SetIcon(4, Gui.Icon("LobbyUI/pipei/icon_rank01_1X.dds"),Vector4(0, 0, 0, 0))
			elseif	v.r == 1 then
				sub_item:SetIcon(4, Gui.Icon("LobbyUI/pipei/icon_rank01_2X.dds"),Vector4(0, 0, 0, 0))
			elseif	v.r == 2 then
				sub_item:SetIcon(4, Gui.Icon("LobbyUI/pipei/icon_rank01_3X.dds"),Vector4(0, 0, 0, 0))
			elseif	v.r == 3 then
				sub_item:SetIcon(4, Gui.Icon("LobbyUI/pipei/icon_rank02_1X.dds"),Vector4(0, 0, 0, 0))
			elseif	v.r == 4 then
				sub_item:SetIcon(4, Gui.Icon("LobbyUI/pipei/icon_rank02_2X.dds"),Vector4(0, 0, 0, 0))
			elseif	v.r == 5 then
				sub_item:SetIcon(4, Gui.Icon("LobbyUI/pipei/icon_rank02_3X.dds"),Vector4(0, 0, 0, 0))
			elseif	v.r == 6 then
				sub_item:SetIcon(4, Gui.Icon("LobbyUI/pipei/icon_rank03_1X.dds"),Vector4(0, 0, 0, 0))
			elseif	v.r == 7 then
				sub_item:SetIcon(4, Gui.Icon("LobbyUI/pipei/icon_rank03_2X.dds"),Vector4(0, 0, 0, 0))
			elseif	v.r == 8 then
				sub_item:SetIcon(4, Gui.Icon("LobbyUI/pipei/icon_rank03_3X.dds"),Vector4(0, 0, 0, 0))
			elseif	v.r == 9 then
				sub_item:SetIcon(4, Gui.Icon("LobbyUI/pipei/icon_rank04_1X.dds"),Vector4(0, 0, 0, 0))
			elseif	v.r == 10 then
				sub_item:SetIcon(4, Gui.Icon("LobbyUI/pipei/icon_rank04_2X.dds"),Vector4(0, 0, 0, 0))
			elseif	v.r == 11 then
				sub_item:SetIcon(4, Gui.Icon("LobbyUI/pipei/icon_rank04_3X.dds"),Vector4(0, 0, 0, 0))
			elseif	v.r == 12 then
				sub_item:SetIcon(4, Gui.Icon("LobbyUI/pipei/icon_rank05_3X.dds"),Vector4(0, 0, 0, 0))
			end
			sub_item:AddSubItem(v.s)
			sub_item:AddSubItem(v.k)
			sub_item:AddSubItem(v.d)
			sub_item:AddSubItem(v.w)
			sub_item:AddSubItem(v.f)
			local temp = v.w
			local temp1 = v.f
			local temp2 = temp+temp1
			if temp2 == 0 then
				sub_item:AddSubItem(0)
			else
				local temp3 = 100*(temp/temp2)
				temp3 = math.floor(temp3).."%"
						-- math.ceil()
				sub_item:AddSubItem(temp3)
			end
		end
		
	end)
end

function ShowMatch_Time()
	matchTime_window_ui = ModalWindow.GetNew()
	matchTime_window_ui.root.Size = Vector2(780, 294)
	matchTime_window_ui.screen.AllowEscToExit = false
	match_time_ui.root.Parent = matchTime_window_ui.root
	
	pipeiTimes = 1
	match_time_ui.t_Time.Text = pipeiTimes
	match_time_ui.t_Time.Text = lang:GetText("等待时间")..pipeiTimes..lang:GetText("秒")
	if pipeiTimes < 35 then
		match_time_ui.t_prompt.Text = lang:GetText("比赛中长时间不操作会被踢出哦.")
	elseif pipeiTimes > 35 and pipeiTimes < 70 then
		match_time_ui.t_prompt.Text = lang:GetText("专家以上级别长期不参赛会扣减分数.")
	elseif pipeiTimes > 70 then
		match_time_ui.t_prompt.Text = lang:GetText("回合失败和中途退出会扣分.")
	end
	match_time_ui.Timer:CleanAll()
	match_time_ui.Timer:AddTime(1)
end

function HideMatch_Time()
	if matchTime_window_ui then
		matchTime_window_ui:Close()
		matchTime_window_ui = nil
	end
end


match_time_ui = Gui.Create()
{
	Gui.Control "root"
	{
		Size = Vector2(580,294),
		Location = Vector2(100, 0),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/lb_common_up_bg_01.dds", Vector4(0, 24, 0, 24)),
		},
		Gui.Label "l_text"
		{
			Location = Vector2(0, 80),
			Size = Vector2(630, 30),
			BackgroundColor = ARGB(0, 255, 255, 255),
			Text = lang:GetText("正在匹配中......"),
			FontSize = 20,
			TextAlign = "kAlignCenterMiddle",
			TextColor = ARGB(255, 53, 53, 53),
		},
		Gui.Label "t_prompt"
		{
			Size = Vector2(530,80),
			Text = lang:GetText(""),
			FontSize = 20,
			TextColor = ARGB(255, 53, 53, 53),
			Location = Vector2(35, 100),
			TextAlign = "kAlignCenterMiddle",
		},
		Gui.Label "t_Time"
		{
			Size = Vector2(530,80),
			Text = lang:GetText("等待时间   秒"),
			FontSize = 20,
			TextColor = ARGB(255, 53, 53, 53),
			Location = Vector2(30, 140),
			TextAlign = "kAlignCenterMiddle",
		},
		Gui.TimeControl "Timer"
		{
			Size = Vector2(5,5),
			-- Location = Vector2(305, 200),
			Dock = "kDockCenter",
			BackgroundColor = ARGB(0, 53, 53, 53),
			EventTimeOut = function(sender, e)
				match_time_ui.t_Time.Text = pipeiTimes 
				pipeiTimes = pipeiTimes + 1
				match_time_ui.t_Time.Text = lang:GetText("等待时间")..pipeiTimes..lang:GetText("秒")
				if pipeiTimes < 35 then
					match_time_ui.t_prompt.Text = lang:GetText("比赛中长时间不操作会被踢出哦.")
				elseif pipeiTimes > 35 and pipeiTimes < 70 then
					match_time_ui.t_prompt.Text = lang:GetText("专家以上级别长期不参赛会扣减分数.")
				elseif pipeiTimes > 70 then
					match_time_ui.t_prompt.Text = lang:GetText("回合失败和中途退出会扣分.")
				end
				if true then
					match_time_ui.Timer:CleanAll()
					match_time_ui.Timer:AddTime(1)
				end
			end
		},
		Gui.Button "b_exit"
		{
			Size = Vector2(100,40),
			Location = Vector2(250, 240),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Text = lang:GetText("取消"),
			TextColor = ARGB(255, 226, 217, 208),
			TextAlign = "kAlignCenterMiddle",
			DisabledTextColor = ARGB(255, 37, 37, 37),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_button12_normal.dds", Vector4(0, 0, 0, 0)),
				HoverImage = Gui.Image("LobbyUI/team/lb_squad_button12_hover.dds", Vector4(0, 0, 0, 0)),
				DownImage = Gui.Image("LobbyUI/team/lb_squad_button12_down.dds", Vector4(0, 0, 0, 0)),
				DisabledImage = Gui.Image("LobbyUI/team/lb_squad_button12_disabled.dds", Vector4(0, 0, 0, 0)),
			},
			EventClick = function()
                state:RequestCancelMatching()
			end
		},
	}
}



--频道列表窗口
local channel_list_window =
{
	Gui.Control "ctrl_Main_Window"
	{
		Size = Vector2(1150, 610),
		Location = Vector2(0, 10),
		BackgroundColor = ARGB(0, 255, 255, 255),


		Gui.Control "ctrl_AD_Window_BG"
		{
			Size = Vector2(347, 584),
			Location = Vector2(21, 16),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/lb_bg_win02.dds", Vector4(16, 16, 16, 16)),
			},
			
			Gui.Control "ctrl_AD_Window"
			{
				Size = Vector2(337, 574),
				Location = Vector2(6, 6),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_daoju_bg.dds", Vector4(22, 22, 22, 22)),
				},
				-- Gui.Control ""
				-- {
				-- Size = Vector2(317, 555),
				-- Location = Vector2(10, 10),
				-- BackgroundColor = ARGB(255, 255, 255, 255),
				-- Skin = Gui.ControlSkin
				-- {
					-- BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/ib_achieve_box1.dds", Vector4(22, 22, 22, 22)),
				-- },
				-- },
				Gui.FlashControl
				{
					Text = config:GetBillBoardV(),
					Size = Vector2(317, 555),
					Location = Vector2(10, 10),
					BackgroundColor = ARGB(255, 255, 255, 255),
					IsUrl = true,
				},
			},
		},
		Gui.Button "btn_website"
		{
			Size = Vector2(347, 584),
			Location = Vector2(21, 16),
			BackgroundColor = ARGB(0, 0, 0, 0),
			EventClick = function()
			gui:ShowGW()
			end
		},

		Gui.Control "ctrl_List_Window_BG"
		{
			Size = Vector2(763, 584),
			Location = Vector2(373, 16),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/lb_bg_win02.dds", Vector4(16, 16, 16, 16)),
			},
		
			Gui.Control "ctrl_List_Window"
			{
				Size = Vector2(753, 574),
				Location = Vector2(5, 5),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_daoju_bg.dds", Vector4(22, 22, 22, 22)),
				},

				Gui.Control "ctrl_List_BG"
				{		
					Location = Vector2(25, 48),
					Size = Vector2(703, 415),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/lb_battlefield_serverlist_bg01.tga", Vector4(8, 42, 50, 8)),
					},
		
					Gui.ListTreeView "list"
					{
						Style = "Gui.ListTreeViewWith_VScroll",
						Dock = "kDockFill",
						CanKeySelect = false,
						TreeVisible = false,
						AlwaysSelect = true,
						HeaderHeight = 40,
						VScrollBarWidth = 40,
						VScrollBarButtonSize = 36,
						FontSize = 14,
						TextColor = ARGB(255,216,217,208),
						HeadFontSize = 18,
						HeadFontColor = ARGB(255, 215, 232, 227),
					},
				},

				Gui.Control "ctrl_enter"
				{
					Size = Vector2(164, 78),
					Location = Vector2(407, 474),
					BackgroundColor = ARGB(255, 255, 255, 255),

					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_common_button_bg02.dds", Vector4(15, 0, 44, 0)),
					},
					
					--退出频道
					Gui.Button "btn_exit_channel"
					{
						Size = Vector2(148, 64),
						Location = Vector2(6 , 8),
					
						TextColor = ARGB(255, 255, 246, 235),
						FontSize = 18,
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_exitsvr_normal.dds", Vector4(5, 5, 5, 5)),
							HoverImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_exitsvr_hover.dds", Vector4(5, 5, 5, 5)),
							DownImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_exitsvr_down.dds", Vector4(5, 5, 5, 5)),
							DisabledImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_exitsvr_disabled.dds", Vector4(5, 5, 5, 5)),
						},
						
						EventClick = function()
							GetBack(current_state)
						end,
					},
				},
				
				Gui.Control
				{
					Size = Vector2(168, 78),
					Location = Vector2(550, 474),
					BackgroundColor = ARGB(255, 255, 255, 255),

					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_common_button_bg03.dds", Vector4(51, 20, 22, 20)),
					},
					--进入
					Gui.Button "btn_enter"
					{
						Size = Vector2(156, 64),
						Location = Vector2(6 , 7),
						--Text = lang:GetText("进入"),
						TextColor = ARGB(255, 255, 246, 235),
						FontSize = 18,
						Enable = false,
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_enter01_normal.dds", Vector4(5, 5, 5, 5)),
							HoverImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_enter01_hover.dds", Vector4(5, 5, 5, 5)),
							DownImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_enter01_down.dds", Vector4(5, 5, 5, 5)),
							DisabledImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_enter01_disabled.dds", Vector4(5, 5, 5, 5)),
						},
					},
				},
				
				Gui.Label "server_name1"
				{
					Size = Vector2(243, 20),
					Text = lang:GetText("当前位置:"),
					FontSize = 14,
					TextColor = ARGB(255, 255, 231, 26),
					Location = Vector2(480, 12),
					TextAlign = "kAlignRightMiddle",
				},
			},
		},
	},
}

--服务器列表窗口
local server_list_window =
{
	Gui.Control "ctrl_Main_Window"
	{
		Size = Vector2(1150, 610),
		Location = Vector2(0, 10),
		BackgroundColor = ARGB(0, 255, 255, 255),

		Gui.Control "ctrl_AD_Window_BG"
		{
			Size = Vector2(347, 584),
			Location = Vector2(21, 16),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/lb_bg_win02.dds", Vector4(16, 16, 16, 16)),
			},
			Gui.Control "ctrl_AD_Window"
			{
				Size = Vector2(337, 574),
				Location = Vector2(6, 6),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_daoju_bg.dds", Vector4(22, 22, 22, 22)),
				},
				Gui.FlashControl
				{
					Text = config:GetBillBoardV(),
					Size = Vector2(317, 555),
					Location = Vector2(10, 10),
					BackgroundColor = ARGB(255, 255, 255, 255),
					IsUrl = true,
				},
			},
		},
		Gui.Button "btn_website"
		{
			Size = Vector2(347, 584),
			Location = Vector2(21, 16),
			BackgroundColor = ARGB(0, 0, 0, 0),
			EventClick = function()
			gui:ShowGW()
			
			end
		},
		
		Gui.Control "ctrl_List_Window_BG"
		{
			Size = Vector2(763, 584),
			Location = Vector2(373, 16),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/lb_bg_win02.dds", Vector4(16, 16, 16, 16)),
			},
			Gui.Control "ctrl_List_Window_BG"
			{
				Size = Vector2(753, 574),
				Location = Vector2(5, 5),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/dating/lb_shop_daoju_bg.dds", Vector4(22, 22, 22, 22)),
				},
				
				Gui.Control "ctrl_List_Window_BG1"
				{
					Size = Vector2(731, 554),
					Location = Vector2(11, 11),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_contact_bg_normal.dds", Vector4(16, 16, 16, 16)),
					},	
					Gui.ScrollableControl "server_list"
					{
						Gui.Control "List_Window_server"
						{
							Size = Vector2(740, 560),
							Location = Vector2(1, 1),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_contact_bg_normal.dds", Vector4(0, 0, 0, 0)),
							},	
						},
						Size = Vector2(730, 552),
						Location = Vector2(0, 0),
						AutoScroll = true,
						
						VScrollBarButtonSize = 16,
						VScrollBarWidth = 16,
						
						VScrollBarDisplay = true,
						--AutoScrollMinSize = Vector2(120,195),
						BackgroundColor = ARGB(255,255,255,255),
						Skin = Gui.ScrollableControlSkin
						{
							UpButtonNormalImage = Gui.Image("LobbyUI/team/NewFight/lb_battlefield_scrollbar_button_01_normal.dds", Vector4(0, 0, 0, 0)),
							UpButtonHoverImage = Gui.Image("LobbyUI/team/NewFight/lb_battlefield_scrollbar_button_01_hover.dds", Vector4(0, 0, 0, 0)),
							UpButtonDownImage = Gui.Image("LobbyUI/team/NewFight/lb_battlefield_scrollbar_button_01_down.dds", Vector4(0, 0, 0, 0)),
							UpButtonDisabledImage = Gui.Image("LobbyUI/team/NewFight/lb_battlefield_scrollbar_button_01_normal.dds", Vector4(0, 0, 0, 0)),

							DownButtonNormalImage = Gui.Image("LobbyUI/team/NewFight/lb_battlefield_scrollbar_button_02_normal.dds", Vector4(0, 0, 0, 0)),
							DownButtonHoverImage = Gui.Image("LobbyUI/team/NewFight/lb_battlefield_scrollbar_button_02_hover.dds", Vector4(0, 0, 0, 0)),
							DownButtonDownImage = Gui.Image("LobbyUI/team/NewFight/lb_battlefield_scrollbar_button_02_down.dds", Vector4(0, 0, 0, 0)),
							DownButtonDisabledImage = Gui.Image("LobbyUI/team/NewFight/lb_battlefield_scrollbar_button_02_normal.dds", Vector4(0, 0, 0, 0)),
							
							VSliderNormalImage = Gui.Image("LobbyUI/team/NewFight/lb_battlefield_scrollbar_button_03_normal.dds", Vector4(3, 4, 5, 5)),
							VSliderHoverImage = Gui.Image("LobbyUI/team/NewFight/lb_battlefield_scrollbar_button_03_hover.dds", Vector4(3, 4, 5, 5)),
							VSliderDownImage = Gui.Image("LobbyUI/team/NewFight/lb_battlefield_scrollbar_button_03_down.dds", Vector4(3, 4, 5, 5)),
							VSliderDisabledImage = Gui.Image("LobbyUI/team/NewFight/lb_battlefield_scrollbar_button_03_normal.dds", Vector4(3, 4, 5, 5)),

							VBarBackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_battlefield_scrollbar_bg.dds", Vector4(3, 4, 5, 5)),
							BarCornerImage = nil,
						},
					
						Gui.Button ""
						{
							Size = Vector2(359, 136),
							Location = Vector2(1, 1),
							FontSize = 18,
							PushDown = false,
							Skin = Gui.ButtonSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/pipei/1p.dds", Vector4(20, 20, 20, 20)),
								HoverImage = Gui.Image("LobbyUI/pipei/lb_battlefield_serverlist_8_disabled88888.dds", Vector4(20, 20, 20, 20)),
							},
							EventClick = function()
								for i = 0, state:GetServerCount() - 1 do
									local info = state:GetServerInfo(i,true)
									if info.isnovice == 7 then
										server_id = info.id
										server_name = info.name
										SelectedServerID = info.id
										is_pipei_id = false
										is_fight_id = false
										is_source_id = false
										is_Channelcount_id = false
										state:EnterServer(info.id)
									end
								end
							end,
							Gui.Label "server_name_1_1"
							{
								Location = Vector2(6,33),
								Size = Vector2(200, 40),
								BackgroundColor = ARGB(0, 255, 255, 255),
								Text = "",
								FontSize = 32,
								TextAlign = "kAlignLeftMiddle",
								TextColor = ARGB(255, 0, 0, 0),
							},
							Gui.Label "server_name_shadow_1_1"
							{
								Location = Vector2(5,32),
								Size = Vector2(200, 40),
								BackgroundColor = ARGB(0, 255, 255, 255),
								Text = "",
								FontSize = 32,
								TextAlign = "kAlignLeftMiddle",
								TextColor = ARGB(255, 255, 255, 255),
							},
						},
						Gui.Button ""
						{
							Size = Vector2(359, 136),
							Location = Vector2(360, 1),
							FontSize = 18,
							PushDown = false,
							Skin = Gui.ButtonSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/pipei/2p.dds", Vector4(20, 20, 20, 20)),
								HoverImage = Gui.Image("LobbyUI/pipei/lb_battlefield_serverlist_8_disabled88888.dds", Vector4(20, 20, 20, 20)),
							},
							EventClick = function()
								for i = 0, state:GetServerCount() - 1 do
									local info = state:GetServerInfo(i,true)	
									-- if L_LobbyMain.PersonalInfo_data.level >= info.nMinLevel and L_LobbyMain.PersonalInfo_data.level <= info.nMaxLevel  then
										server_id = info.id
										server_name = info.name
										SelectedServerID = info.id
										if info.isnovice == 2 then
											is_fight_id = true
										else	
											is_fight_id = false
										end
										if info.isnovice == 3 then
											is_source_id = true
										else	
											is_source_id = false
										end
										if info.Channelcount == 0 then
											is_Channelcount_id = true
										else
											is_Channelcount_id = false
										end
										is_pipei_id = false
										if info.isnovice < 2 then
											state:EnterServer(temp)
										end
									-- end
								end
							end,
							Gui.Label "server_name_2_1"
							{
								Location = Vector2(14,33),
								Size = Vector2(200, 40),
								BackgroundColor = ARGB(0, 255, 255, 255),
								Text = "房间模式",
								FontSize = 32,
								TextAlign = "kAlignLeftMiddle",
								TextColor = ARGB(255, 0, 0, 0),
							},
							Gui.Label "server_name_shadow_2_1"
							{
								Location = Vector2(13,32),
								Size = Vector2(200, 40),
								BackgroundColor = ARGB(0, 255, 255, 255),
								Text = "房间模式",
								FontSize = 32,
								TextAlign = "kAlignLeftMiddle",
								TextColor = ARGB(255, 255, 255, 255),
							},
						},
						Gui.Button "zhenbasai1"
						{
							Size = Vector2(359, 136),
							Location = Vector2(1, 133),
							FontSize = 18,
							PushDown = false,
							Skin = Gui.ButtonSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/pipei/3s.dds", Vector4(20, 20, 20, 20)),
								HoverImage = Gui.Image("LobbyUI/pipei/lb_battlefield_serverlist_8_disabled88888.dds", Vector4(20, 20, 20, 20)),
							},
							EventClick = function()
								match_server = true
								for i = 0, state:GetServerCount() - 1 do
									local info = state:GetServerInfo(i,true)
									if info.isnovice == 6 then
										if info.Channelcount ~= 0 then
											if L_LobbyMain.PersonalInfo_data.level >= 5 then
											server_id = info.id
											server_name = info.name
											SelectedServerID = info.id
											is_pipei_id = true
											is_fight_id = false
											is_source_id = false
											is_Channelcount_id = false
											state:EnterServer(info.id)
											else
												MessageBox.ShowWithConfirm(lang:GetText("你未满5级，不可匹配"))
											end
										else
											MessageBox.ShowWithConfirm(lang:GetText("匹配频道目前无法进入"))
										end
									end
								end
							end,
							Gui.Label "server_name_3_1"
							{
								Location = Vector2(6,36),
								Size = Vector2(200, 40),
								BackgroundColor = ARGB(0, 255, 255, 255),
								Text = "",
								FontSize = 32,
								TextAlign = "kAlignLeftMiddle",
								TextColor = ARGB(255, 0, 0, 0),
							},
							Gui.Label "server_name_shadow_3_1"
							{
								Location = Vector2(5,35),
								Size = Vector2(200, 40),
								BackgroundColor = ARGB(0, 255, 255, 255),
								Text = "",
								FontSize = 32,
								TextAlign = "kAlignLeftMiddle",
								TextColor = ARGB(255, 255, 255, 255),
							},
							Gui.Label "time_prompt1_1"
							{
								Location = Vector2(3,21),
								Size = Vector2(381, 173),
								BackgroundColor = ARGB(0, 255, 255, 255),
								Text = "",
								FontSize = 14,
								TextAlign = "kAlignLeftMiddle",
								TextColor = ARGB(255, 0, 0, 0),
							},
							Gui.Label "time_prompt_1"
							{
								Location = Vector2(2,20),
								Size = Vector2(381, 173),
								BackgroundColor = ARGB(0, 255, 255, 255),
								Text = "",
								FontSize = 14,
								TextAlign = "kAlignLeftMiddle",
								TextColor = ARGB(255, 255, 255, 255),
							},
						},
						Gui.Button "tiaotiaole1"
						{
							Size = Vector2(359, 136),
							Location = Vector2(360, 133),
							FontSize = 18,
							PushDown = false,
							Skin = Gui.ButtonSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/pipei/4s.dds", Vector4(20, 20, 20, 20)),
								HoverImage = Gui.Image("LobbyUI/pipei/lb_battlefield_serverlist_8_disabled88888.dds", Vector4(20, 20, 20, 20)),
							},
							EventClick = function()
								for i = 0, state:GetServerCount() - 1 do
									local info = state:GetServerInfo(i,true)
									if info.isnovice == 4 then
										server_id = info.id
										server_name = info.name
										SelectedServerID = info.id
										is_fight_id = false
										is_pipei_id = false
										is_source_id = false
										if info.Channelcount == 0 then
											is_Channelcount_id = true
										else
											is_Channelcount_id = false
										end
										state:EnterServer(info.id)
									end
								end
							end,
							Gui.Label "server_name_4_1"
							{
								Location = Vector2(14,36),
								Size = Vector2(200, 40),
								BackgroundColor = ARGB(0, 255, 255, 255),
								Text = "",
								FontSize = 32,
								TextAlign = "kAlignLeftMiddle",
								TextColor = ARGB(255, 0, 0, 0),
							},
							Gui.Label "server_name_shadow_4_1"
							{
								Location = Vector2(13,35),
								Size = Vector2(200, 40),
								BackgroundColor = ARGB(0, 255, 255, 255),
								Text = "",
								FontSize = 32,
								TextAlign = "kAlignLeftMiddle",
								TextColor = ARGB(255, 255, 255, 255),
							},
							Gui.Label "time_prompt3_1"
							{
								Location = Vector2(11,21),
								Size = Vector2(381, 173),
								BackgroundColor = ARGB(0, 255, 255, 255),
								Text = "",
								FontSize = 14,
								TextAlign = "kAlignLeftMiddle",
								TextColor = ARGB(255, 0, 0, 0),
							},
							Gui.Label "time_prompt2_1"
							{
								Location = Vector2(10,20),
								Size = Vector2(381, 173),
								BackgroundColor = ARGB(0, 255, 255, 255),
								Text = "",
								FontSize = 14,
								TextAlign = "kAlignLeftMiddle",
								TextColor = ARGB(255, 255, 255, 255),
							},
						},
						Gui.Button ""
						{
							Size = Vector2(359, 136),
							Location = Vector2(1, 272),
							FontSize = 18,
							PushDown = false,
							Skin = Gui.ButtonSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/pipei/5p.dds", Vector4(20, 20, 20, 20)),
								HoverImage = Gui.Image("LobbyUI/pipei/lb_battlefield_serverlist_8_disabled88888.dds", Vector4(20, 20, 20, 20)),
							},
							EventClick = function()
								if L_LobbyMain and L_LobbyMain.PersonalInfo_data and L_LobbyMain.PersonalInfo_data.level < 6 then
									print("111111=================L_Chat Initialize()")
									L_WarZone.is_novice = true
									MessageBox.ShowWithTwoButtons(lang:GetText("确定要进入新手训练关？"),lang:GetText("确认"),lang:GetText("取消"),
									
									function() 
										print("22222=================L_Chat Initialize()")
										L_WarZone.novice_need_in = true
										L_WarZone.EnterNoviceServer()
										L_WarZone.is_novice = false
									end,
									function() 
										L_WarZone.is_novice = false
									end
									)
								elseif L_LobbyMain.PersonalInfo_data and L_LobbyMain.PersonalInfo_data.level >= 6 then
									MessageBox.ShowWithConfirm(lang:GetText("您已不再是新手了，去挑战更高级的玩家吧！"))
								end
							end,
							Gui.Label "server_name_5_1"
							{
								Location = Vector2(6,40),
								Size = Vector2(200, 40),
								BackgroundColor = ARGB(0, 255, 255, 255),
								Text = "训练关",
								FontSize = 32,
								TextAlign = "kAlignLeftMiddle",
								TextColor = ARGB(255, 0, 0, 0),
							},
							Gui.Label "server_name_shadow_5_1"
							{
								Location = Vector2(5,39),
								Size = Vector2(200, 40),
								BackgroundColor = ARGB(0, 255, 255, 255),
								Text = "训练关",
								FontSize = 32,
								TextAlign = "kAlignLeftMiddle",
								TextColor = ARGB(255, 255, 255, 255),
							},
							Gui.Label "dengji_5_1"
							{
								Location = Vector2(10,100),
								Size = Vector2(200, 30),
								BackgroundColor = ARGB(0, 255, 255, 255),
								Text = "等级1-5",
								FontSize = 24,
								TextAlign = "kAlignLeftMiddle",
								TextColor = ARGB(255, 0, 0, 0),
							},
							Gui.Label "dengji_shadow_5_1"
							{
								Location = Vector2(9,99),
								Size = Vector2(200, 30),
								BackgroundColor = ARGB(0, 255, 255, 255),
								Text = "等级1-5",
								FontSize = 24,
								TextAlign = "kAlignLeftMiddle",
								TextColor = ARGB(255, 255, 255, 255),
							},
							
						},
						Gui.Button ""
						{
							Size = Vector2(359, 136),
							Location = Vector2(360, 272),
							FontSize = 18,
							PushDown = false,
							Skin = Gui.ButtonSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/pipei/6s.dds", Vector4(20, 20, 20, 20)),
								HoverImage = Gui.Image("LobbyUI/pipei/lb_battlefield_serverlist_8_disabled88888.dds", Vector4(20, 20, 20, 20)),
							},
							EventClick = function()
								MessageBox.ShowWithConfirm(lang:GetText("暂未开放，敬请期待！"))
							end,
							Gui.Label ""
							{
								Location = Vector2(14,40),
								Size = Vector2(200, 40),
								BackgroundColor = ARGB(0, 255, 255, 255),
								Text = "战队联赛",
								FontSize = 32,
								TextAlign = "kAlignLeftMiddle",
								TextColor = ARGB(255, 0, 0, 0),
							},
							Gui.Label ""
							{
								Location = Vector2(13,39),
								Size = Vector2(200, 40),
								BackgroundColor = ARGB(0, 255, 255, 255),
								Text = "战队联赛",
								FontSize = 32,
								TextAlign = "kAlignLeftMiddle",
								TextColor = ARGB(255, 255, 255, 255),
							},
						},
						Gui.Button ""
						{
							Size = Vector2(359, 136),
							Location = Vector2(1, 408),
							FontSize = 18,
							PushDown = false,
							Skin = Gui.ButtonSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/pipei/7s.dds", Vector4(20, 20, 20, 20)),
								HoverImage = Gui.Image("LobbyUI/pipei/lb_battlefield_serverlist_8_disabled88888.dds", Vector4(20, 20, 20, 20)),
							},
							EventClick = function()
								MessageBox.ShowWithConfirm(lang:GetText("暂未开放，敬请期待！"))
							end,
							Gui.Label ""
							{
								Location = Vector2(6,41),
								Size = Vector2(200, 40),
								BackgroundColor = ARGB(0, 255, 255, 255),
								Text = "测试区",
								FontSize = 32,
								TextAlign = "kAlignLeftMiddle",
								TextColor = ARGB(255, 0, 0, 0),
							},
							Gui.Label ""
							{
								Location = Vector2(5,40),
								Size = Vector2(200, 40),
								BackgroundColor = ARGB(0, 255, 255, 255),
								Text = "测试区",
								FontSize = 32,
								TextAlign = "kAlignLeftMiddle",
								TextColor = ARGB(255, 255, 255, 255),
							},
						},
						Gui.Button ""
						{
							Size = Vector2(359, 136),
							Location = Vector2(360, 408),
							FontSize = 18,
							PushDown = false,
							Skin = Gui.ButtonSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/pipei/8s.dds", Vector4(20, 20, 20, 20)),
								HoverImage = Gui.Image("LobbyUI/pipei/lb_battlefield_serverlist_8_disabled88888.dds", Vector4(20, 20, 20, 20)),
							},
							EventClick = function()
								MessageBox.ShowWithConfirm(lang:GetText("暂未开放，敬请期待！"))
							end,
							Gui.Label ""
							{
								Location = Vector2(14,41),
								Size = Vector2(200, 40),
								BackgroundColor = ARGB(0, 255, 255, 255),
								Text = "活动区",
								FontSize = 32,
								TextAlign = "kAlignLeftMiddle",
								TextColor = ARGB(255, 0, 0, 0),
							},
							Gui.Label ""
							{
								Location = Vector2(13,40),
								Size = Vector2(200, 40),
								BackgroundColor = ARGB(0, 255, 255, 255),
								Text = "活动区",
								FontSize = 32,
								TextAlign = "kAlignLeftMiddle",
								TextColor = ARGB(255, 255, 255, 255),
							},
						},
					},
				},	
			},
		},
		
	},
}
ChatWin = Gui.Create(gui)
{
	Gui.FadingWindowUI "root"
	{
		Moveable = false,
		ContentSize = Vector2(500,500),
		WorldLocation = Vector3(400,400,400),
		Margin = Vector4(10, 0, 0, 95),
		BackgroundColor = ARGB(0,128,128,128),
		ShowCloseButton = false,
		Visible = false,
	}
}

--ToolTips窗口
local tooltip_window =
{
	Gui.Control "ctrl_root"
	{							
		Size = Vector2(246, 143),
		Location = Vector2(1, 46),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/ToolTips/lb_tooltips_bg.dds",Vector4(10, 10, 10, 10)),
		},
	
		Gui.Control "ctrl_tips_bg"
		{							
			Size = Vector2(228,121),
			Location = Vector2(9, 11),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ToolTips/lb_tooltips_bg_2.dds",Vector4(8, 8, 8, 8)),
			},
			
			Gui.Label "p_fightnum"
			{
				Size = Vector2(225, 18),
				Location = Vector2(7, 9),
				TextColor = ARGB(255,216,217,208),
				FontSize = 14,
			},
			
			Gui.Label "p_win"
			{
				Size = Vector2(225, 18),
				Location = Vector2(7, 36),
				TextColor = ARGB(255,216,217,208),
				FontSize = 14,
			},
			
			Gui.Label "p_top"
			{
				Size = Vector2(225, 18),
				Location = Vector2(7, 63),
				TextColor = ARGB(255,216,217,208),
				FontSize = 14,
			},
			
			Gui.Label "p_group"
			{
				Size = Vector2(225, 23),
				Location = Vector2(7, 90),
				TextColor = ARGB(255,216,217,208),
				FontSize = 14,
			},
		},
	},
}

function SetRoomButtonEvent(gtk)
	if gtk == "kTeam" then --团队竞技模式
		if main_room_list_ui then
			is_inboss = false
			is_inzombie = false
			is_inbosspve = false
			is_incommonzombie = false
		end
    	SetCreateRoomInfo(game_type_key[1])
		create_room_ui.cbox_Balance.Visible = true
		create_room_ui.lbl_Balance.Visible = true
	elseif gtk == "kKnife" then  --刀战
		if main_room_list_ui then
			create_room_ui.cbox_Balance.Visible = true
			create_room_ui.lbl_Balance.Visible = true
			is_inboss = false
			is_inzombie = false
			is_inbosspve = false
			is_incommonzombie = false
		end
    		SetCreateRoomInfo(game_type_key[6])
	elseif gtk == "kMoonMode" then
		if main_room_list_ui then
			is_inboss = false
			is_inzombie = false
			is_inbosspve = false
			is_incommonzombie = false
		end
    	SetCreateRoomInfo(game_type_key[16])
    	create_room_ui.cbx_Time.Text = lang:GetText("5秒")
		create_room_ui.cbx_Time.Enable = false
		create_room_ui.cbox_Balance.Visible = false
		create_room_ui.lbl_Balance.Visible = false
	elseif gtk == "kHoldPoint" then --占点
		if main_room_list_ui then
			is_inboss = false
			is_inzombie = false
			is_inbosspve = false
			is_incommonzombie = false
		end
    	SetCreateRoomInfo(game_type_key[2])
    	create_room_ui.cbx_Time.Text = lang:GetText("5秒")
		create_room_ui.cbx_Time.Enable = false
		create_room_ui.cbox_Balance.Visible = true
		create_room_ui.lbl_Balance.Visible = true
		-- create_room_ui.cbox_Kniefmode.Visible = true
		-- create_room_ui.lbl_Kniefmode.Visible = true		
	elseif gtk == "kPushVehicle" then --推车
		if main_room_list_ui then
			is_inboss = false
			is_inzombie = false
			is_inbosspve = false
			is_incommonzombie = false
		end
    	SetCreateRoomInfo(game_type_key[3])
    	create_room_ui.cbx_Time.Text = lang:GetText("5秒")
		create_room_ui.cbx_Time.Enable = false
		create_room_ui.cbox_Balance.Visible = true
		create_room_ui.lbl_Balance.Visible = true
		-- create_room_ui.cbox_Kniefmode.Visible = true
		-- create_room_ui.lbl_Kniefmode.Visible = true		
	elseif gtk == "kTeamDeathMatch" then --歼灭
		if main_room_list_ui then
			is_inboss = false
			is_inzombie = false
			is_inbosspve = false
			is_incommonzombie = false
		end
    	SetCreateRoomInfo(game_type_key[4])
    	create_room_ui.cbx_Time.Enable = false
    	create_room_ui.cbx_Time.Text = lang:GetText("5秒")
		create_room_ui.cbox_Balance.Visible = true
		create_room_ui.lbl_Balance.Visible = true
		-- create_room_ui.cbox_Kniefmode.Visible = true
		-- create_room_ui.lbl_Kniefmode.Visible = true
	elseif gtk == "kBoss" then --Boss
		if main_room_list_ui then
			is_inboss = true
			is_inzombie = false
			is_inbosspve = false
			is_incommonzombie = false
		end
    	SetCreateRoomInfo(game_type_key[5])
		create_room_ui.cbx_Time.Enable = false
    	create_room_ui.cbx_Time.Text = lang:GetText("5秒")
		create_room_ui.cbox_Balance.Visible = false
		create_room_ui.lbl_Balance.Visible = false
		-- create_room_ui.cbox_Kniefmode.Visible = false
		-- create_room_ui.lbl_Kniefmode.Visible = false
	elseif gtk == "kBomb" then --爆破
		if main_room_list_ui then
			is_inboss = false
			is_inzombie = false
			is_inbosspve = false
			is_incommonzombie = false
		end
    	SetCreateRoomInfo(game_type_key[7])
    	create_room_ui.cbx_Time.Enable = false
    	create_room_ui.cbx_Time.Text = lang:GetText("5秒")
		create_room_ui.cbox_Balance.Visible = true
		create_room_ui.lbl_Balance.Visible = true
		-- create_room_ui.cbox_Kniefmode.Visible = false
		-- create_room_ui.lbl_Kniefmode.Visible = false
	elseif gtk == "kStreetBoy" then --英雄
		if main_room_list_ui then
			is_inboss = false
			is_inzombie = false
			is_inbosspve = false
			is_incommonzombie = false
		end
    	SetCreateRoomInfo(game_type_key[8])
    	create_room_ui.cbx_Time.Enable = false
    	create_room_ui.cbx_Time.Text = lang:GetText("5秒")
		create_room_ui.cbox_Balance.Visible = true
		create_room_ui.lbl_Balance.Visible = true
		-- create_room_ui.cbox_Kniefmode.Visible = false
		-- create_room_ui.lbl_Kniefmode.Visible = false		
	elseif gtk == "kZombie" then --生化
		if main_room_list_ui then
			is_inboss = false
			is_inzombie = true
			is_inbosspve = false
			is_incommonzombie = false
		end
		SetCreateRoomInfo(game_type_key[9])
		create_room_ui.cbx_Time.Enable = false
		create_room_ui.cbx_Time.Text = lang:GetText("5秒")
		create_room_ui.cbox_Balance.Visible = false
		create_room_ui.lbl_Balance.Visible = false
		create_room_ui.cbox_Kniefmode.Visible = false
		create_room_ui.lbl_Kniefmode.Visible = false
	elseif gtk == "kBossPVE" then --Boss
		if main_room_list_ui then
			is_inboss = false
			is_inzombie = false
			is_inbosspve = true
			is_incommonzombie = false
		end
    	SetCreateRoomInfo(game_type_key[10])
		create_room_ui.cbx_Time.Enable = false
    	create_room_ui.cbx_Time.Text = lang:GetText("5秒")
		create_room_ui.cbox_Balance.Visible = false
		create_room_ui.lbl_Balance.Visible = false
		-- create_room_ui.cbox_Kniefmode.Visible = false
		-- create_room_ui.lbl_Kniefmode.Visible = false		
	elseif gtk == "kCommonZombieMode" then
		if main_room_list_ui then
			is_inboss = false
			is_inzombie = false
			is_inbosspve = false
			is_incommonzombie = true
		end
		create_room_ui.cbx_Time.Enable = false
		create_room_ui.cbx_Time.Text = lang:GetText("5秒")
		create_room_ui.cbox_Balance.Visible = false
		create_room_ui.lbl_Balance.Visible = false
		create_room_ui.cbox_Kniefmode.Visible = false
		create_room_ui.lbl_Kniefmode.Visible = false
		SetCreateRoomInfo(game_type_key[11])
	elseif gtk == "kBossMode2" then
		if main_room_list_ui then
			is_inboss = false
			is_inzombie = false
			is_inbosspve = false
			is_incommonzombie = false
		end
		create_room_ui.cbx_Time.Enable = false
		create_room_ui.cbx_Time.Text = lang:GetText("5秒")
		create_room_ui.cbox_Balance.Visible = false
		create_room_ui.lbl_Balance.Visible = false
		create_room_ui.cbox_Kniefmode.Visible = false
		create_room_ui.lbl_Kniefmode.Visible = false
		SetCreateRoomInfo(game_type_key[12])
	elseif gtk == "kItemMode" then
		if main_room_list_ui then
			is_inboss = false
			is_inzombie = false
			is_inbosspve = false
			is_incommonzombie = false
		end
    	SetCreateRoomInfo(game_type_key[13])
		create_room_ui.cbox_Balance.Visible = true
		create_room_ui.lbl_Balance.Visible = true
	elseif gtk == "kEditMode" then
		if main_room_list_ui then
			is_inboss = false
			is_inzombie = false
			is_inbosspve = false
			is_incommonzombie = false
		end
    	SetCreateRoomInfo(game_type_key[14])
		create_room_ui.cbox_Balance.Visible = true
		create_room_ui.lbl_Balance.Visible = true
	elseif gtk == "kTDMode" then
		if main_room_list_ui then
			is_inboss = false
			is_inzombie = false
			is_inbosspve = false
			is_incommonzombie = false
		end
    	SetCreateRoomInfo(game_type_key[15])
		create_room_ui.cbox_Balance.Visible = true
		create_room_ui.lbl_Balance.Visible = true
	elseif gtk == "kAdvenceMode" then
		if main_room_list_ui then
			is_inboss = false
			is_inzombie = false
			is_inbosspve = false
			is_incommonzombie = false
		end
    	SetCreateRoomInfo(game_type_key[17])
    	create_room_ui.cbx_Time.Text = lang:GetText("5秒")
		create_room_ui.cbx_Time.Enable = false
		create_room_ui.cbox_Balance.Visible = false
		create_room_ui.lbl_Balance.Visible = false
	elseif gtk == "kSurvivalMode" then
		if main_room_list_ui then
			is_inboss = false
			is_inzombie = false
			is_inbosspve = false
			is_incommonzombie = false
		end
    	SetCreateRoomInfo(game_type_key[18])
    	create_room_ui.cbx_Time.Text = lang:GetText("5秒")
		create_room_ui.cbx_Time.Enable = false
		create_room_ui.cbox_Balance.Visible = false
		create_room_ui.lbl_Balance.Visible = false
	elseif gtk == "kMatchingMode" then
		if main_room_list_ui then
			is_inboss = false
			is_inzombie = false
			is_inbosspve = false
			is_incommonzombie = false
		end
    	SetCreateRoomInfo(game_type_key[19])
    	create_room_ui.cbx_Time.Text = lang:GetText("5秒")
		create_room_ui.cbx_Time.Enable = false
		create_room_ui.cbox_Balance.Visible = false
		create_room_ui.lbl_Balance.Visible = false	
	end
end

local option_room_name = 
{
   lang:GetText("全民大冲锋!"),
   lang:GetText("来!战个痛快!"),
   lang:GetText("FC!大革命!"),
   lang:GetText("GoGo!大冲锋!"),
   lang:GetText("FC勇往直前!"),
}

--创建房间
function ShowCreateRoom(win_parent)
	print("=================L_WarZone ShowCreateRoom()")
	--界面是否存在
	L_LobbyMain.HideAll()
	--创建界面	
	if not create_room_ui then 
		create_room_ui = Gui.Create(win_parent)(create_room_window)
		current_state = 4
		
		if not create_room_option then
			create_room_option = ptr_new ("Client.RoomOption")
		else
			create_room_info = state:GetSelfRoomInfo()
	        
			if create_room_info.id > 0 then
				create_room_option = ptr_cast(create_room_info.option)
			end
		end
	    
		---创建房间---
		function create_room_ui.btn_Create.EventClick()
			
			if string.len(create_room_ui.tbox_RoomName.Text) == 0 then
				MessageBox.ShowError(lang:GetText("房间名不能为空"))
				return
			end
			
			if string.find(create_room_ui.tbox_RoomName.Text," ") then
				MessageBox.ShowError(lang:GetText("房间名不能含有空格"))
				return 
			end
			
			if game:TextLenght(create_room_ui.tbox_RoomName.Text) > config:GetRoomNameLengthMax() then
				MessageBox.ShowError(lang:GetText("房间名过长！"))
				return
			elseif game:TextLenght(create_room_ui.tbox_RoomName.Text) < config:GetRoomNameLengthMin() then
				MessageBox.ShowError(lang:GetText("房间名过短！"))
				return
			end
			
			
			create_room_option.name = create_room_ui.tbox_RoomName.Text
	        
			create_room_option.use_password = false
			create_room_option.password = nil
		   	
		   	if string.len(create_room_ui.tbox_PassWord.Text) == 0 and create_room_ui.cbox_PassWord.Check == true then
		   		MessageBox.ShowError(lang:GetText("密码不能为空"))
				return
		   	end
		   	
			if string.len(create_room_ui.tbox_PassWord.Text) >= 0 and create_room_ui.cbox_PassWord.Check == true then	
				if(string.len(create_room_ui.tbox_PassWord.Text) > 6) then
					MessageBox.ShowError(lang:GetText("房间密码过长，最多输入6个字符"))
					return
				end
				
				create_room_option.use_password = true
				create_room_option.password = create_room_ui.tbox_PassWord.Text
				room_set_password = create_room_ui.tbox_PassWord.Text
			end
	        
			create_room_option.special_mode = war_mode_key[create_room_ui.cbx_Special.SelectedIndex+1]
			
			create_room_option.character_id = single_character_id[create_room_ui.cbx_Single.SelectedIndex + 1]
			if create_room_ui.cbox_Balance.Visible == false and create_room_option.game_type ~= "kMoonMode" then
				create_room_option.check_game_balance = false
			elseif create_room_ui.cbox_Balance.Visible == false and create_room_option.game_type == "kMoonMode" then
				create_room_option.check_game_balance = true
			end
			
			if create_room_ui.cbox_Kniefmode.Visible == false then
				create_room_option.is_knife = false
			end
			
			create_room_option.is_gm = map_isgm[create_room_option.level_id]
			
			--print("create_room_ui.cbx_Condition.Text",create_room_option.rule_value)
	          create_room_ui.ctrl_Main_Window.Parent = nil
			if host_character_info then
				if host_character_info.is_host == true then
					state:RoomChangeOption(create_room_option)
					MessageBox.ShowWaiter(lang:GetText("正在更改房间设置,请稍候..."))
				else
					state:CreateRoom(create_room_option)
					MessageBox.ShowWaiter(lang:GetText("正在创建房间,请稍候..."))
				end
			else
				state:CreateRoom(create_room_option)
				MessageBox.ShowWaiter(lang:GetText("正在创建房间,请稍候..."))
			end
		end
		
		setup_ui_game_mode(create_room_ui.cbx_Mode, false)
	    		
		create_room_ui.tbox_RoomName.Text = option_room_name[math.random(1, #option_room_name)]
			
	else
		create_room_ui.ctrl_Main_Window.Parent = win_parent
		current_state = 4
		return
	end
    
	SetCreateRoomInfo(setting_mode[2][1])
	-- create_room_ui.cbox_Balance.Visible = true
	-- create_room_ui.lbl_Balance.Visible = true
end
                                                                                                                                                                      
-- 最大人数ComboBox
function setup_ui_cbx_maxplayer(cbx, gtk)
	if gtk == "kBoss" then
		fill_cbx_boss_max_player(cbx)
	elseif gtk == "kZombie" then
		fill_cbx_zombie_max_player(cbx)
	elseif gtk == "kBossPVE" or gtk == "kAdvenceMode" then
		fill_cbx_bosspve_max_player(cbx)
	elseif gtk == "kCommonZombieMode" then
		fill_cbx_view_max_player(cbx)
	else
		fill_cbx_max_player(cbx)
	end
	
	cbx.SelectedIndex = cbx.ItemCount-1
	
	
	if gtk == "kBoss" then
		create_room_option.client_count = max_boss_player[cbx.SelectedIndex+1]
	elseif gtk == "kZombie" then
		create_room_option.client_count = max_zombie_player[cbx.SelectedIndex+1]
	elseif gtk == "kBossPVE" or gtk == "kAdvenceMode" then
		create_room_option.client_count = 10
	elseif gtk == "kCommonZombieMode" then
		create_room_option.client_count = view_max_player[cbx.SelectedIndex+1]
	else
		create_room_option.client_count = max_player[cbx.SelectedIndex+1]
	end
	
     
	function cbx:EventItemSelected(sender, e)
		local index = self.SelectedIndex
		if create_room_option then
			if is_inboss == true then
				create_room_option.client_count=max_boss_player[index+1]	
			elseif is_inzombie == true then
				create_room_option.client_count=max_zombie_player[index+1]
			elseif is_inbosspve == true then
				create_room_option.client_count = 10
			elseif is_incommonzombie == true then
				create_room_option.client_count = view_max_player[cbx.SelectedIndex+1]
			else
				create_room_option.client_count=max_player[index+1]
			end
		end
		print("in cbx:EventItemSelected\ncreate_room_option.client_count = "..create_room_option.client_count)
	end
end

function setup_ui_rebirth(cbx, gtk)
	--复活等待时间
	cbx.Enable = true
	fill_cbx_rebirth_time(cbx)
	cbx.SelectedIndex = 0

	if create_room_info.id > 0 and (create_room_option.game_type == gtk) then
		cbx.SelectedIndex = rebirth_time_index(create_room_option.round_rebirth_time_max) - 1
	else
		create_room_option.round_rebirth_time_max=rebirth_time[cbx.SelectedIndex+1]
	end
    
	function cbx:EventItemSelected(sender, e)
		local index = self.SelectedIndex
		if create_room_option then
			create_room_option.round_rebirth_time_max=rebirth_time[index+1]
		end
	end
end

---------------密码设定------------------

function setup_password_event(cx)
	function cx:EventCheckChanged(sender, e)
		if self.Check == true then
			create_room_ui.tbox_PassWord.Enable = true
		else 
			create_room_ui.tbox_PassWord.Enable = false
		end
	end
end

---------------允许观战control

function setup_ui_view_war(count)
	create_room_option.viewer_count=count
end

--------------- 中途加入CheckBox
local cx_break_join = nil
local cx_war_team = nil

function setup_ui_break_join(cx, gtk)
	cx_break_join = cx
	cx_break_join.MuteCheck = true
	
	if create_room_info.id > 0 and (create_room_option.game_type == gtk) then
		cx.MuteCheck = create_room_option.can_join_on_playing
		-- 如果开启战队战的话 中途加入 必须关掉
		if create_room_option.group_match then
			cx.MuteCheck = false
		end
	else
		-- new add
		-- 如果开启战队战的话 中途加入 必须关掉
		if create_room_option.group_match then
			cx.MuteCheck = false
		end
		create_room_option.can_join_on_playing = cx.Check
	end
    
	function cx:EventCheckChanged(sender, e)
		if cx_war_team and cx_war_team.Check then
			self.MuteCheck = false
			create_room_option.can_join_on_playing = false
			MessageBox.ShowError(lang:GetText("战队战状态下,不可以中途加入"))
			return
		end
		if create_room_option then
			create_room_option.can_join_on_playing = self.Check
		end
	end
end

--------设置战力平衡---------------
function setup_game_balance(cx)	
	create_room_option.check_game_balance = cx.Check
	
	function cx:EventCheckChanged(sender, e)
		create_room_option.check_game_balance = self.Check
	end
end

function setup_ui_is_knife(cx)

	if cx.Check then
		create_room_option.is_knife = 1
	else
		create_room_option.is_knife = 0
	end
	
	function cx:EventCheckChanged(sender, e)
		if self.Check then
			create_room_option.is_knife = 1
		else
			create_room_option.is_knife = 0
		end
	end
end

--------设置自动开始---------------
function setup_auto_start(cx)	
	create_room_option.auto_start = cx.Check
	
	function cx:EventCheckChanged(sender, e)
		create_room_option.auto_start = self.Check
	end
end

-- 特俗战ComboBox
function setup_ui_war_mode(cbx, gtk)
	--print("in setup_ui_war_mode")
	--print("gtk = ",gtk)
    
	cbx.Enable = true
	fill_cbx_war_mode(cbx)
	cbx.SelectedIndex = 0

	if create_room_info.id > 0 and (create_room_option.game_type == gtk) then
    		--print("in  create_room_info.id > 0 and")
		cbx.SelectedIndex = war_mode_index(create_room_option.special_mode) - 1
	else
		create_room_option.special_mode=war_mode_key[cbx.SelectedIndex+1]
	end

	function cbx:EventItemSelected(sender, e)
    		--print("in cbx:EventItemSelected")
		local index = self.SelectedIndex
		if create_room_option then
			create_room_option.special_mode=war_mode_key[index+1]
		end
	end
end

function setup_ui_game_mode(cbx, flag)
	cbx.Enable = true
	local room_info=state:GetSelfRoomInfo()
	local room_option = ptr_cast(room_info.option)
	local index = 0
	cbx:RemoveAll()
	for i=2, #setting_mode do
		if(setting_mode[i][3] == 0) then
			cbx:AddItem(setting_mode[i][2])
		else
			cbx:AddItemWithIcon(setting_mode[i][2],setting_mode[i][3] - 1)
		end
		
		if flag and (setting_mode[i][1] == "kBossPVE" or setting_mode[i][1] == "kAdvenceMode") then
			cbx:SetItemDisable(i-2, true)
		end
		
		if room_option.game_type == setting_mode[i][1] then
			index = i - 2
		end
	end
	
	if flag then
		cbx.SelectedIndex = index
	else
		cbx.SelectedIndex = 0
	end
	function cbx:EventItemSelected(sender, e)
		local index = self.SelectedIndex
		SetRoomButtonEvent(setting_mode[index + 2][1])
	end
end

--单职业战
function setup_ui_single_character(cbx, gtk, c_id)
	cbx.Enable = true
	fill_cbx_single(cbx)
	if c_id <= 0 then
		cbx.SelectedIndex = 0
	else
		cbx.SelectedIndex = c_id
	end
	create_room_option.character_id = single_character_id[cbx.SelectedIndex + 1]

	function cbx:EventItemSelected(sender, e)
		local index = self.SelectedIndex
		if create_room_option then
			if index > 0 then
				create_room_ui.tbox_RoomName.Text = character[single_character_id[index+1] + 1]--..lang:GetText("之战")
			else
				create_room_ui.tbox_RoomName.Text = option_room_name[math.random(1, #option_room_name)]
			end
			create_room_option.character_id = single_character_id[index+1]
		end
	end
end

--new function add two button logic
local ib_lindex=3
local ib_rindex=1
local function what_map_select(pic, gtk)
	if pic.Text == what_map_name_select then
		pic.Highlighted = true
		if create_room_option then
			create_room_option.map_name = pic.Text
			if pic.Text == "level_random" then
				if gtk then
					create_room_option.map_name = RandomMapKey(gtk)
					create_room_option.level_id = map_id[gtk][create_room_option.map_name]
				else
					create_room_option.map_name = RandomMapKey(create_room_option.game_type)
					create_room_option.level_id = map_id[create_room_option.game_type][create_room_option.map_name]
				end
			end
		end
	else
		pic.Highlighted = false
	end
end

function setup_ui_map_browser(ib, game_type)
	ib_lindex = ib.NumSkip
	ib_rindex = 1

	init_buf_map_key(ib, game_type)
	
	create_room_ui.m_PageDisplay.Text = ib_lindex/ib.NumSkip.."/"..math.ceil(map_key1_length/ib.NumSkip)
   
	local row = ib.DisplayRowAndCol.x
	local col = ib.DisplayRowAndCol.y
	
	what_map_name_select = map_key1[1]
	
	if game_type and what_map_name_select then
		create_room_option.map_name = map_key1[1]
	    create_room_option.level_id = map_id[game_type][what_map_name_select]
		-- print("create_room_option.level_id:"..create_room_option.level_id)
    end
	print("row:"..row)
	print("col:"..col)
	for r=1, row do
		for c=1, col do
    		local pic = ib:GetDisplayPicture(r,c)
    		pic.FrontImage = Gui.Image("MapsAndBG/MapsIcon/black_piece.dds", Vector4(0, 0, 0, 0))
			--pic.KeepAspect = true
            pic.BeStatic = true
            if r==1 then
				pic.Text = map_key1[c]
			
				pic.ForeGroundImage = FindMapIcon(pic.Text).Icon
				
           		if string.len(pic.Text) ~= 0 then
               		pic.BeStatic = false
           		end
			elseif r==2 then
				pic.Text = map_key2[c]
			
				pic.ForeGroundImage = FindMapIcon(pic.Text).Icon
				
				if string.len(pic.Text) ~= 0 then
					pic.BeStatic = false
				end
			end
			local temp_levelinfo_id = map_id[game_type][pic.Text]
			local temp_levelinfo = ptr_cast(game.CurrentState):GetLevelInfoById(temp_levelinfo_id)

			if temp_levelinfo then
				if temp_levelinfo.is_new ~= 0 then
					pic.IsNewImage = Gui.Image("MapsAndBG/MapsIcon/lb_battlefield_map_new.dds", Vector4(0, 0, 0, 0))
				else
					pic.IsNewImage = nil
				end
			end
			if pic.Text == "" then
				pic.ForeGroundImage = Gui.Image("MapsAndBG/MapsIcon/lb_battlefield_map_disabled.dds", Vector4(0, 0, 0, 0))
			end
			
			what_map_select(pic, game_type)
			
			pic.EventClick = function(sender, e)
     			what_map_name_select = pic.Text
     			if create_room_option then
          			create_room_option.map_name = pic.Text
          			create_room_option.level_id = map_id[create_room_option.game_type][create_room_option.map_name]
				end
                	
				ib:AllPictureHL(false)
				pic.Highlighted=true
			end			
		end
	end
    
	function create_room_ui.m_Left.EventClick()	
		for i=1, ib.NumSkip do
			if ib_rindex > 1 then
				ib_rindex = ib_rindex - 1

				ib_lindex = ib_lindex - 1

				--print("current left index:",ib_lindex)
				--print("current right index:",ib_rindex)

				ib:RightBtnClick()

				local key1 = map_key1[ib_rindex]
				local key2 = map_key2[ib_rindex]

				local pic = ib:GetDisplayPicture(1,1)
				pic.Text = key1
			
				if string.len(pic.Text) == 0 then
					pic.BeStatic = true
				else
					pic.BeStatic = false
				end
				pic.ForeGroundImage =  FindMapIcon(pic.Text).Icon
					
				what_map_select(pic)

				pic = ib:GetDisplayPicture(2, 1)
				pic.Text = key2

				if string.len(pic.Text) == 0 then
					pic.BeStatic = true
				else
					pic.BeStatic = false
				end
			
				pic.ForeGroundImage = FindMapIcon(pic.Text).Icon
				what_map_select(pic)
			end
		end
		create_room_ui.m_PageDisplay.Text = ib_lindex/ib.NumSkip.."/"..math.ceil(map_key1_length/ib.NumSkip)
	end
    
	function create_room_ui.m_Right.EventClick()
		--print("right btn click")
    		local TepNum = ib.NumSkip*math.ceil(map_key1_length/ib.NumSkip)
   		for i=1, ib.NumSkip do
			if ib_lindex < TepNum then				
				ib_lindex = ib_lindex + 1
				ib_rindex = ib_rindex + 1

				--print("current left index:",ib_lindex)
				--print("current right index:",ib_rindex)

				local key1 = map_key1[ib_lindex]
				local key2 = map_key2[ib_lindex]

				local pic = ib:GetDisplayPicture(1, col+1)
				pic.Text = key1
				
				if string.len(pic.Text) == 0 then
					pic.BeStatic = true
				end
				pic.ForeGroundImage = FindMapIcon(pic.Text).Icon
				
				what_map_select(pic)

				pic = ib:GetDisplayPicture(2, col+1)
				pic.Text = key2
				
				if string.len(pic.Text) == 0 then
					pic.BeStatic = true
				end
	               
				pic.ForeGroundImage = FindMapIcon(pic.Text).Icon

                	what_map_select(pic)
				ib:LeftBtnClick()
			end
		end
		create_room_ui.m_PageDisplay.Text = ib_lindex/ib.NumSkip.."/"..math.ceil(map_key1_length/ib.NumSkip)
	end    
	ib.LeftBtn.Visible=false
	ib.RightBtn.Visible=false
end

-- 根据不同的游戏模式设置创建房间界面
local win_rule_ctrl=nil
function SetCreateRoomInfo(gtk)
	--print("SetCreateRoomInfo("..gtk..")")
	create_room_info = state:GetSelfRoomInfo()
    
	if create_room_info.id > 0 then
		create_room_option = ptr_cast( create_room_info.option )
	else
		what_map_name_select = "level_random"
	end
    
	local room_option = create_room_option
 
	local ib_map = create_room_ui.ib_map
	local tb_room_name = create_room_ui.tbox_RoomName
	local tb_room_password = create_room_ui.tbox_PassWord
	local cbx_max_player = create_room_ui.cbx_Number    
	local cbx_rebirth_wait_time = create_room_ui.cbx_Time  
    cbx_rebirth_wait_time.Visible = true
    create_room_ui.lbl_Time.Visible = true
	--local cb_allow_view = create_room_ui.cbox_ViewMod   
	local cb_break_join = create_room_ui.cbox_PlayJoin

	local cb_game_balance = create_room_ui.cbox_Balance
	local cb_auto_start = create_room_ui.cbox_AutoStart
	local cb_is_knife = create_room_ui.cbox_Kniefmode
    local cb_password = create_room_ui.cbox_PassWord
	-- 胜利规则
	local cbx_win_rule = create_room_ui.cbx_Condition     --胜利规则
   
	--特俗战列表
	local cbx_special_war = create_room_ui.cbx_Special
    cb_game_balance.Check = false
	setup_ui_cbx_maxplayer(cbx_max_player, gtk)
	setup_ui_rebirth(cbx_rebirth_wait_time, gtk)
	setup_ui_view_war(0)
	setup_ui_break_join(cb_break_join, gtk)
	setup_ui_is_knife(cb_is_knife, gtk)	
	setup_password_event(cb_password)
	
	setup_game_balance(cb_game_balance)
	setup_auto_start(cb_auto_start)
	if (gtk == "kTeam") or (gtk == "kKnife") or (gtk =="kTDMode") or (gtk =="kEditMode") then --团队竞技模式 or 夺宝模式
		setup_ui_war_mode(cbx_special_war, gtk)
		if create_room_info and (create_room_option.game_type == gtk) then
    		fill_cbx_win_goal(cbx_win_rule, gtk,"kKillNum")	
    		cbx_win_rule.SelectedIndex=1
			create_room_option.rule_value = kill_num[cbx_win_rule.SelectedIndex+1]
    		-- 复活等待时间
			cbx_rebirth_wait_time.Enable = true
			cbx_rebirth_wait_time.SelectedIndex = 2
			create_room_option.round_rebirth_time_max = rebirth_time[cbx_rebirth_wait_time.SelectedIndex+1]
    	else 
			fill_cbx_win_goal(cbx_win_rule,gtk,"kKillNum")
			cbx_win_rule.SelectedIndex=1
			create_room_option.rule_value = kill_num[cbx_win_rule.SelectedIndex+1]
			--复活等待时间
			cbx_rebirth_wait_time.Enable=true
			cbx_rebirth_wait_time.SelectedIndex = 2
			create_room_option.round_rebirth_time_max = rebirth_time[cbx_rebirth_wait_time.SelectedIndex+1]
		end
		cb_break_join.Check = true
		cb_break_join.Enable = true
	elseif gtk == "kItemMode" then
		setup_ui_war_mode(cbx_special_war, gtk)
		if create_room_info and (create_room_option.game_type == gtk) then
    		fill_cbx_win_goal(cbx_win_rule, gtk,"kKillNum")	
    		cbx_win_rule.SelectedIndex=1
			create_room_option.rule_value = item_kill_num[cbx_win_rule.SelectedIndex+1]
    		-- 复活等待时间
			cbx_rebirth_wait_time.Enable = true
			cbx_rebirth_wait_time.SelectedIndex = 2
			create_room_option.round_rebirth_time_max = rebirth_time[cbx_rebirth_wait_time.SelectedIndex+1]
    	else 
			fill_cbx_win_goal(cbx_win_rule,gtk,"kKillNum")
			cbx_win_rule.SelectedIndex=1
			create_room_option.rule_value = item_kill_num[cbx_win_rule.SelectedIndex+1]
			--复活等待时间
			cbx_rebirth_wait_time.Enable=true
			cbx_rebirth_wait_time.SelectedIndex = 2
			create_room_option.round_rebirth_time_max = rebirth_time[cbx_rebirth_wait_time.SelectedIndex+1]
		end
		cb_break_join.Check = true
		cb_break_join.Enable = true
	elseif gtk == "kHoldPoint" then --占点
		--设置特俗站模式
		setup_ui_war_mode(cbx_special_war, gtk)
		if create_room_info and (create_room_option.game_type == gtk) then
			fill_cbx_win_goal(cbx_win_rule, gtk,"kPlayRound")
               
               cbx_win_rule.SelectedIndex=1
			create_room_option.rule_value = common_game_round[cbx_win_rule.SelectedIndex+1]
			
			-- 复活等待时间
			cbx_rebirth_wait_time.Enable = true
			cbx_rebirth_wait_time.SelectedIndex = 2
			create_room_option.round_rebirth_time_max = rebirth_time[cbx_rebirth_wait_time.SelectedIndex+1]
		else
			fill_cbx_win_goal(cbx_win_rule, gtk,"kPlayRound")

			cbx_win_rule.SelectedIndex=1
			--cbx_win_goal.SelectedIndex=2

			create_room_option.rule_value = common_game_round[cbx_win_rule.SelectedIndex+1]

			--复活等待时间
			cbx_rebirth_wait_time.Enable = true
			cbx_rebirth_wait_time.SelectedIndex = 2
			create_room_option.round_rebirth_time_max = rebirth_time[cbx_rebirth_wait_time.SelectedIndex+1]   
		end
		cb_break_join.Check = true
		cb_break_join.Enable = true		
	elseif gtk == "kPushVehicle" then --推车
		--设置特殊战模式
		setup_ui_war_mode(cbx_special_war, gtk)
            
		if create_room_info and (create_room_option.game_type == gtk) then
			fill_cbx_win_goal(cbx_win_rule, gtk,"kPlayRound")
			cbx_win_rule.SelectedIndex = 1
			create_room_option.rule_value = common_game_round[cbx_win_rule.SelectedIndex+1]
			
			-- 复活等待时间
			cbx_rebirth_wait_time.Enable = true
			cbx_rebirth_wait_time.SelectedIndex = 2
			create_room_option.round_rebirth_time_max = rebirth_time[cbx_rebirth_wait_time.SelectedIndex+1]
		else
			fill_cbx_win_goal(cbx_win_rule, gtk,"kPlayRound")

			cbx_win_rule.SelectedIndex = 1
			create_room_option.rule_value = common_game_round[cbx_win_rule.SelectedIndex+1]

			--复活等待时间
			cbx_rebirth_wait_time.Enable = true
			cbx_rebirth_wait_time.SelectedIndex = 2
			create_room_option.round_rebirth_time_max = rebirth_time[cbx_rebirth_wait_time.SelectedIndex+1]
		end
		cb_break_join.Check = true
		cb_break_join.Enable = true
	elseif gtk == "kMoonMode" then
		--设置特殊战模式
		create_room_ui.cbox_Balance.Visible = false
		create_room_ui.lbl_Balance.Visible = false
		setup_ui_war_mode(cbx_special_war, gtk)
		if create_room_info and (create_room_option.game_type == gtk) then
			fill_cbx_win_goal(cbx_win_rule, gtk,"kPlayRound")
			cbx_win_rule.SelectedIndex = 1
			create_room_option.rule_value = common_game_round[cbx_win_rule.SelectedIndex+1]
			
			-- 复活等待时间
			cbx_rebirth_wait_time.Enable = true
			cbx_rebirth_wait_time.SelectedIndex = 2
			create_room_option.round_rebirth_time_max = rebirth_time[cbx_rebirth_wait_time.SelectedIndex+1]
		else
			fill_cbx_win_goal(cbx_win_rule, gtk,"kPlayRound")

			cbx_win_rule.SelectedIndex = 1
			create_room_option.rule_value = common_game_round[cbx_win_rule.SelectedIndex+1]

			--复活等待时间
			cbx_rebirth_wait_time.Enable = true
			cbx_rebirth_wait_time.SelectedIndex = 2
			create_room_option.round_rebirth_time_max = rebirth_time[cbx_rebirth_wait_time.SelectedIndex+1]
		end
		cb_break_join.Check = false
		cb_break_join.Enable = false
	elseif gtk == "kTeamDeathMatch" then --歼灭
		setup_ui_war_mode(cbx_special_war, gtk)
		
		if create_room_info and (create_room_option.game_type == gtk) then
			fill_cbx_win_goal(cbx_win_rule, gtk,"kPlayRound")
			cbx_win_rule.SelectedIndex = 1
			create_room_option.rule_value = kTeamDeathMatch_game_round[cbx_win_rule.SelectedIndex+1]
			
			-- 复活等待时间
			cbx_rebirth_wait_time.Enable = true
			cbx_rebirth_wait_time.SelectedIndex = 1
			create_room_option.round_rebirth_time_max = rebirth_time[cbx_rebirth_wait_time.SelectedIndex+1]
		else
			fill_cbx_win_goal(cbx_win_rule, gtk,"kPlayRound")

			cbx_win_rule.SelectedIndex = 0
			create_room_option.rule_value = kTeamDeathMatch_game_round[cbx_win_rule.SelectedIndex+1]

			--复活等待时间
			cbx_rebirth_wait_time.Enable = true
			cbx_rebirth_wait_time.SelectedIndex = 0
			create_room_option.round_rebirth_time_max = rebirth_time[cbx_rebirth_wait_time.SelectedIndex+1]
		end
		
		cbx_rebirth_wait_time.Visible = false
    	create_room_ui.lbl_Time.Visible = false
		cb_break_join.Check = true
		cb_break_join.Enable = true		
	elseif gtk == "kBoss" then --Boss
		create_room_ui.cbox_Balance.Visible = false
		create_room_ui.lbl_Balance.Visible = false
		setup_ui_war_mode(cbx_special_war, gtk)	
		if create_room_info and (create_room_option.game_type == gtk) then
			fill_cbx_win_goal(cbx_win_rule, gtk,"kPlayRound")
			cbx_win_rule.SelectedIndex = 1
			create_room_option.rule_value = common_game_round[cbx_win_rule.SelectedIndex+1]
			
			-- 复活等待时间
			cbx_rebirth_wait_time.Enable = true
			cbx_rebirth_wait_time.SelectedIndex = 2
			create_room_option.round_rebirth_time_max = rebirth_time[cbx_rebirth_wait_time.SelectedIndex+1]
		else
			fill_cbx_win_goal(cbx_win_rule, gtk,"kPlayRound")

			cbx_win_rule.SelectedIndex = 1
			create_room_option.rule_value = common_game_round[cbx_win_rule.SelectedIndex+1]

			--复活等待时间
			cbx_rebirth_wait_time.Enable = true
			cbx_rebirth_wait_time.SelectedIndex = 2
			create_room_option.round_rebirth_time_max = rebirth_time[cbx_rebirth_wait_time.SelectedIndex+1]
		end
		cbx_rebirth_wait_time.Visible = false
    	create_room_ui.lbl_Time.Visible = false
		cb_break_join.Check = true
		cb_break_join.Enable = true		
	elseif gtk == "kBomb" then --爆破
		setup_ui_war_mode(cbx_special_war, gtk)	
		cb_game_balance.Check = true
		if create_room_info and (create_room_option.game_type == gtk) then
			fill_cbx_win_goal(cbx_win_rule, gtk,"kPlayRound")
			cbx_win_rule.SelectedIndex = 1
			create_room_option.rule_value = bomb_and_hero_round[cbx_win_rule.SelectedIndex+1]
			
			-- 复活等待时间
			cbx_rebirth_wait_time.Enable = true
			cbx_rebirth_wait_time.SelectedIndex = 2
			create_room_option.round_rebirth_time_max = rebirth_time[cbx_rebirth_wait_time.SelectedIndex+1]
		else
			fill_cbx_win_goal(cbx_win_rule, gtk,"kPlayRound")

			cbx_win_rule.SelectedIndex = 1
			create_room_option.rule_value = bomb_and_hero_round[cbx_win_rule.SelectedIndex+1]

			--复活等待时间
			cbx_rebirth_wait_time.Enable = true
			cbx_rebirth_wait_time.SelectedIndex = 2
			create_room_option.round_rebirth_time_max = rebirth_time[cbx_rebirth_wait_time.SelectedIndex+1]
		end
		cbx_rebirth_wait_time.Visible = false
    	create_room_ui.lbl_Time.Visible = false
		cb_break_join.Check = true
		cb_break_join.Enable = true		
	elseif gtk == "kStreetBoy" then --英雄
		cb_game_balance.Check = true
		setup_ui_war_mode(cbx_special_war, gtk)	
		if create_room_info and (create_room_option.game_type == gtk) then
			fill_cbx_win_goal(cbx_win_rule, gtk,"kPlayRound")
			cbx_win_rule.SelectedIndex = 1
			create_room_option.rule_value = bomb_and_hero_round[cbx_win_rule.SelectedIndex+1]
			
			-- 复活等待时间
			cbx_rebirth_wait_time.Enable = false
			cbx_rebirth_wait_time.SelectedIndex = 2
			create_room_option.round_rebirth_time_max = rebirth_time[cbx_rebirth_wait_time.SelectedIndex+1]
		else
			fill_cbx_win_goal(cbx_win_rule, gtk,"kPlayRound")

			cbx_win_rule.SelectedIndex = 1
			create_room_option.rule_value = bomb_and_hero_round[cbx_win_rule.SelectedIndex+1]

			--复活等待时间
			cbx_rebirth_wait_time.Enable = false
			cbx_rebirth_wait_time.SelectedIndex = 2
			create_room_option.round_rebirth_time_max = rebirth_time[cbx_rebirth_wait_time.SelectedIndex+1]
		end	
		cb_break_join.Check = true
		cb_break_join.Enable = true
	elseif gtk == "kZombie" then --生化
		cb_game_balance.Check = true
		setup_ui_war_mode(cbx_special_war, gtk)	
		if create_room_info and (create_room_option.game_type == gtk) then
			fill_cbx_win_goal(cbx_win_rule, gtk,"kPlayRound")
			cbx_win_rule.SelectedIndex = 1
			create_room_option.rule_value = zombie_game_round[cbx_win_rule.SelectedIndex+1]
			
			-- 复活等待时间
			cbx_rebirth_wait_time.Enable = false
			cbx_rebirth_wait_time.SelectedIndex = 2
			create_room_option.round_rebirth_time_max = rebirth_time[cbx_rebirth_wait_time.SelectedIndex+1]
		else
			fill_cbx_win_goal(cbx_win_rule, gtk,"kPlayRound")

			cbx_win_rule.SelectedIndex = 1
			create_room_option.rule_value = zombie_game_round[cbx_win_rule.SelectedIndex+1]

			--复活等待时间
			cbx_rebirth_wait_time.Enable = false
			cbx_rebirth_wait_time.SelectedIndex = 2
			create_room_option.round_rebirth_time_max = rebirth_time[cbx_rebirth_wait_time.SelectedIndex+1]
		end	
		cbx_rebirth_wait_time.Visible = false
    	create_room_ui.lbl_Time.Visible = false
		cb_break_join.Check = true
		cb_break_join.Enable = true
	elseif gtk == "kBossPVE" then
		--print("kBossPVEkBossPVEkBossPVEkBossPVE")
		create_room_ui.cbox_Balance.Visible = false
		create_room_ui.lbl_Balance.Visible = false
		setup_ui_war_mode(cbx_special_war, gtk)	
		if create_room_info and (create_room_option.game_type == gtk) then
			fill_cbx_win_goal(cbx_win_rule, gtk,"kPlayRound")
			cbx_win_rule.SelectedIndex = 1
			create_room_option.rule_value = 1
			
			-- 复活等待时间
			cbx_rebirth_wait_time.Enable = true
			cbx_rebirth_wait_time.SelectedIndex = 2
			create_room_option.round_rebirth_time_max = rebirth_time[cbx_rebirth_wait_time.SelectedIndex+1]
		else
			fill_cbx_win_goal(cbx_win_rule, gtk,"kPlayRound")

			cbx_win_rule.SelectedIndex = 1
			create_room_option.rule_value = 1

			--复活等待时间
			cbx_rebirth_wait_time.Enable = true
			cbx_rebirth_wait_time.SelectedIndex = 2
			create_room_option.round_rebirth_time_max = rebirth_time[cbx_rebirth_wait_time.SelectedIndex+1]
		end
		cbx_rebirth_wait_time.Visible = false
    	create_room_ui.lbl_Time.Visible = false
		cb_break_join.Check = false
		cb_break_join.Enable = false
	elseif gtk == "kCommonZombieMode" then
		-- cb_game_balance.Check = true
		create_room_ui.cbox_Balance.Visible = false
		create_room_ui.lbl_Balance.Visible = false
		setup_ui_war_mode(cbx_special_war, gtk)	
		if create_room_info and (create_room_option.game_type == gtk) then
			fill_cbx_win_goal(cbx_win_rule, gtk,"kPlayRound")
			cbx_win_rule.SelectedIndex = 1
			create_room_option.rule_value = common_zombie_game_round[cbx_win_rule.SelectedIndex+1]
			
			-- 复活等待时间
			cbx_rebirth_wait_time.Enable = false
			cbx_rebirth_wait_time.SelectedIndex = 2
			create_room_option.round_rebirth_time_max = rebirth_time[cbx_rebirth_wait_time.SelectedIndex+1]
		else
			fill_cbx_win_goal(cbx_win_rule, gtk,"kPlayRound")

			cbx_win_rule.SelectedIndex = 1
			create_room_option.rule_value = common_zombie_game_round[cbx_win_rule.SelectedIndex+1]

			--复活等待时间
			cbx_rebirth_wait_time.Enable = false
			cbx_rebirth_wait_time.SelectedIndex = 2
			create_room_option.round_rebirth_time_max = rebirth_time[cbx_rebirth_wait_time.SelectedIndex+1]
		end
		cbx_rebirth_wait_time.Visible = false
    	create_room_ui.lbl_Time.Visible = false
		cb_break_join.Check = true
		cb_break_join.Enable = true
	elseif gtk == "kBossMode2" then --Boss
		create_room_ui.cbox_Balance.Visible = false
		create_room_ui.lbl_Balance.Visible = false
		setup_ui_war_mode(cbx_special_war, gtk)	
		if create_room_info and (create_room_option.game_type == gtk) then
			fill_cbx_win_goal(cbx_win_rule, gtk,"kPlayRound")
			cbx_win_rule.SelectedIndex = 0
			create_room_option.rule_value = game_dq[cbx_win_rule.SelectedIndex+1]
			
			-- 复活等待时间
			cbx_rebirth_wait_time.Enable = true
			cbx_rebirth_wait_time.SelectedIndex = 2
			create_room_option.round_rebirth_time_max = rebirth_time[cbx_rebirth_wait_time.SelectedIndex+1]
		else
			fill_cbx_win_goal(cbx_win_rule, gtk,"kPlayRound")

			cbx_win_rule.SelectedIndex = 0
			create_room_option.rule_value = game_dq[cbx_win_rule.SelectedIndex+1]

			--复活等待时间
			cbx_rebirth_wait_time.Enable = true
			cbx_rebirth_wait_time.SelectedIndex = 2
			create_room_option.round_rebirth_time_max = rebirth_time[cbx_rebirth_wait_time.SelectedIndex+1]
		end
		cbx_rebirth_wait_time.Visible = false
    	create_room_ui.lbl_Time.Visible = false
		cb_break_join.Check = true
		cb_break_join.Enable = true	
	elseif gtk == "kAdvenceMode" then
		create_room_ui.cbox_Balance.Visible = false
		create_room_ui.lbl_Balance.Visible = false
		setup_ui_war_mode(cbx_special_war, gtk)
		if create_room_info and (create_room_option.game_type == gtk) then
			fill_cbx_win_goal(cbx_win_rule, gtk,"kPlayRound")
			cbx_win_rule.SelectedIndex = 1
			create_room_option.rule_value = common_game_round[cbx_win_rule.SelectedIndex+1]
			
			-- 复活等待时间
			cbx_rebirth_wait_time.Enable = false
			cbx_rebirth_wait_time.SelectedIndex = 2
			create_room_option.round_rebirth_time_max = rebirth_time[cbx_rebirth_wait_time.SelectedIndex+1]
		else
			fill_cbx_win_goal(cbx_win_rule, gtk,"kPlayRound")

			cbx_win_rule.SelectedIndex = 1
			create_room_option.rule_value = common_game_round[cbx_win_rule.SelectedIndex+1]

			--复活等待时间
			cbx_rebirth_wait_time.Enable = false
			cbx_rebirth_wait_time.SelectedIndex = 2
			create_room_option.round_rebirth_time_max = rebirth_time[cbx_rebirth_wait_time.SelectedIndex+1]
		end
		cb_break_join.Check = false
		cb_break_join.Enable = false
	elseif gtk == "kSurvivalMode" then
		create_room_ui.cbox_Balance.Visible = false
		create_room_ui.lbl_Balance.Visible = false
		setup_ui_war_mode(cbx_special_war, gtk)
		if create_room_info and (create_room_option.game_type == gtk) then
			fill_cbx_win_goal(cbx_win_rule, gtk,"kPlayRound")
			cbx_win_rule.SelectedIndex = 1
			create_room_option.rule_value = common_game_round[cbx_win_rule.SelectedIndex+1]
			
			-- 复活等待时间
			cbx_rebirth_wait_time.Enable = false
			cbx_rebirth_wait_time.SelectedIndex = 2
			create_room_option.round_rebirth_time_max = rebirth_time[cbx_rebirth_wait_time.SelectedIndex+1]
		else
			fill_cbx_win_goal(cbx_win_rule, gtk,"kPlayRound")

			cbx_win_rule.SelectedIndex = 1
			create_room_option.rule_value = common_game_round[cbx_win_rule.SelectedIndex+1]

			--复活等待时间
			cbx_rebirth_wait_time.Enable = false
			cbx_rebirth_wait_time.SelectedIndex = 2
			create_room_option.round_rebirth_time_max = rebirth_time[cbx_rebirth_wait_time.SelectedIndex+1]
		end
		cb_break_join.Check = false
		cb_break_join.Enable = falseSS
	elseif gtk == "kMatchingMode" then
		create_room_ui.cbox_Balance.Visible = false
		create_room_ui.lbl_Balance.Visible = false
		setup_ui_war_mode(cbx_special_war, gtk)
		if create_room_info and (create_room_option.game_type == gtk) then
			fill_cbx_win_goal(cbx_win_rule, gtk,"kPlayRound")
			cbx_win_rule.SelectedIndex = 1
			create_room_option.rule_value = common_game_round[cbx_win_rule.SelectedIndex+1]
			
			-- 复活等待时间
			cbx_rebirth_wait_time.Enable = false
			cbx_rebirth_wait_time.SelectedIndex = 2
			create_room_option.round_rebirth_time_max = rebirth_time[cbx_rebirth_wait_time.SelectedIndex+1]
		else
			fill_cbx_win_goal(cbx_win_rule, gtk,"kPlayRound")

			cbx_win_rule.SelectedIndex = 1
			create_room_option.rule_value = common_game_round[cbx_win_rule.SelectedIndex+1]

			--复活等待时间
			cbx_rebirth_wait_time.Enable = false
			cbx_rebirth_wait_time.SelectedIndex = 2
			create_room_option.round_rebirth_time_max = rebirth_time[cbx_rebirth_wait_time.SelectedIndex+1]
		end
		cb_break_join.Check = false
		cb_break_join.Enable = false
		
	end
	--单职业战
	setup_ui_single_character(create_room_ui.cbx_Single, gtk, create_room_ui.cbx_Single.SelectedIndex)
    
	if room_option then			
		if ib_map ~= nil then
			setup_ui_map_browser(ib_map, gtk)			
			--选取地图初始化设定
			local array = map_key_of_game_type[ gtk ] --game_type_key[index+1]]
			if array then
				create_room_ui.btn_Create.Enable = true
			else
				create_room_ui.btn_Create.Enable = false
			end
		end
	end

	create_room_option.game_type = gtk
   
	function cbx_win_rule:EventItemSelected(sender, e)
		--print("in cbx_win_rule:EventItemSelected")
		if room_option then
			local victory_rule = ""
        	  
			if (create_room_option.game_type == "kTeam") or (create_room_option.game_type == "kKnife") or (create_room_option.game_type == "kItemMode") then
            	victory_rule = "kKillNum"
			else 
            	victory_rule = "kPlayRound"
			end
            
			create_room_option.rule_value = win_goal_table[create_room_option.game_type][victory_rule][self.SelectedIndex+1]
			
			if  victory_rule == "kPlayTime" then
				create_room_option.rule_value = create_room_option.rule_value * 60
			end
		end
	end
end

function FillRoomInfo(my_room_info)
	local create_room_option_m = my_room_info.option
	
	create_room_ui.btn_Create.Text = lang:GetText("完　成")
	create_room_ui.btn_Cannel.Text = lang:GetText("返　回")
	---------------房间名称----------------
	create_room_ui.tbox_RoomName.Text = create_room_option_m.name
     
	---------------房间密码----------------
	create_room_ui.cbox_PassWord.Check = create_room_option_m.use_password
	create_room_ui.tbox_PassWord.Text = room_set_password
	
	local game_mode = create_room_option_m.game_type
	SetRoomButtonEvent(game_mode)
	
	-- create_room_ui.cbx_Special.Text = create_room_option_m.special_mode and war_mode_table[create_room_option_m.special_mode] or ""
	create_room_ui.cbx_Single.Text = create_room_option_m.character_id and character[create_room_option_m.character_id+1] or ""
	create_room_ui.cbox_PlayJoin.Check = create_room_option_m.can_join_on_playing
	create_room_ui.cbox_Balance.Check = create_room_option_m.check_game_balance
	create_room_ui.cbox_AutoStart.Check = create_room_option_m.auto_start
	if create_room_option_m.is_knife == 0 then
		create_room_ui.cbox_Kniefmode.Check = false
	elseif create_room_option_m.is_knife == 1 then
		create_room_ui.cbox_Kniefmode.Check = true
	end
	
	local rule_value=0
     
	if create_room_option_m.game_type == "kTeam" or create_room_option_m.game_type == "kKnife" or (create_room_option.game_type == "kItemMode") then
		rule_value = create_room_option_m.rule_value
		rule_value = rule_value .. lang:GetText("个")
	else
		rule_value = create_room_option_m.rule_value
		rule_value = rule_value .. lang:GetText("回合")
	end
     
	rule_value = rule_value or ""
	
	create_room_ui.cbx_Condition.Text = rule_value
	create_room_ui.cbx_Number.Text = create_room_option_m.client_count..lang:GetText("人")
	create_room_ui.cbx_Time.Text = create_room_option_m.round_rebirth_time_max .. lang:GetText("秒")
	
	local row = create_room_ui.ib_map.DisplayRowAndCol.x
	local col = create_room_ui.ib_map.DisplayRowAndCol.y
	
	for r=1, row do
    		for c=1, col do
    			local pic = create_room_ui.ib_map:GetDisplayPicture(r,c)
    			if pic.Text == create_room_option_m.map_name then
    				what_map_name_select = pic.Text
     			if create_room_option then
          			create_room_option.map_name = pic.Text
          			create_room_option.level_id = map_id[create_room_option.game_type][create_room_option.map_name]
				end
				
    				create_room_ui.ib_map:AllPictureHL(false)
				pic.Highlighted = true
    			end
    		end
    	end
    	
     create_room_option = create_room_option_m
end		

--创建Tooltipswindow
local function setup_tooltips_window(parent_window)
	--界面是否存在
	if tooltip_window_ui then
		tooltip_window_ui.ctrl_root.Parent = parent_window
		return
	end
	--创建界面
	tooltip_window_ui = Gui.Create(parent_window)(tooltip_window)
end

local function ShowToolTipsWindow(pos)
	local lobby_state = ptr_cast(game.CurrentState)
	if lobby_state and tooltip_window_ui and tooltip_window_ui.ctrl_root then
		local window_size = lobby_state:GetUIWindowSize()
		if pos.x + 246 > window_size.x then
			pos = Vector2(pos.x - 246 - 50, pos.y)
		end
		if pos.y + tooltip_window_ui.ctrl_root.Size.y > window_size.y then
			pos = Vector2(pos.x, pos.y-tooltip_window_ui.ctrl_root.Size.y-50)
		end
		if tooltip_window_ui then
			tooltip_window_ui.ctrl_root.Location = pos
		end
	end
end

function HideToolTipsWindow()
	if tooltip_window_ui then
		tooltip_window_ui.ctrl_root.Parent = nil
		tooltip_window_ui = nil
	end
end

function FillToolTipsWindow(data, first)
	setup_tooltips_window(gui)
	if tooltip_window_ui then
		if first == 1 then
			tooltip_window_ui.ctrl_root.Location = Vector2(-5000,-5000)
		end
		
		local winSize = state:GetScreenSize()
		local fightnum = lang:GetText("战斗力:")
		local win = lang:GetText("胜率:")
		local top = lang:GetText("排名:No.--")
		local group = lang:GetText("所属战队:")
		tooltip_window_ui.p_fightnum.Text = fightnum..data[1]
		tooltip_window_ui.p_win.Text = win..data[2].."%"
		tooltip_window_ui.p_top.Text = top
		-- ..data[3]
		tooltip_window_ui.p_group.Text = group..data[4]
		
		if tooltip_window_ui.ctrl_root.Location.y + tooltip_window_ui.ctrl_root.Size.y >= winSize.y then
			local newLocY =  winSize.y - tooltip_window_ui.ctrl_root.Size.y - 20
			local newLocX = tooltip_window_ui.ctrl_root.Location.x
			tooltip_window_ui.ctrl_root.Location = Vector2(newLocX,newLocY)
		end
	end
end

--显示进入房间
function ShowRoomWindow(win_parent)
	if state.is_fight_team_server then
		return
	end
	
	if L_FightTeam.is_in_fight_ui then
		return
	end
	if L_FightTeam.is_in_invite then
		return
	end
	L_LobbyMain.HideAll()
	L_LobbyMain.current_chosse_main_page = 5
	L_LobbyMain.LobbyMainWin_Foot.btn_WarZone.PushDown = true
	L_LobbyMain.LobbyMainWin.video_button.Enable = false
	local room_info=state:GetSelfRoomInfo()
	local room_option = ptr_cast(room_info.option)
	local half_count = room_option.client_count / 2
	local balance = room_option.check_game_balance
	UpdateRoomInfo(room_info,room_option)
	--创建界面
	if not room_ui then	
		room_ui = Gui.Create(win_parent)(room_window)
		room_ui.ctrl_Main_Window.Parent = win_parent
		current_state = 3
		L_LobbyMain.Timer_control_ui.Timer:AddAnim("Timer",10,4)
		L_LobbyMain.Timer_control_ui.Timer.EventFinish = function()
			if L_WarZone.host_character_info then
				if L_WarZone.host_character_info.is_host == true then
					MessageBox.ShowWaiter(lang:GetText("正在开始游戏,请稍候..."))						
					state:StartGame()
				end
			end
			L_LobbyMain.Timer_control_ui.Timer.Visible = false
		end
		local roomlist = room_ui.list_room_info
		roomlist:AddColumn("",140,"kAlignCenterMiddle")
		roomlist:AddColumn("",190,"kAlignCenterMiddle")
		client_items = {}
		
		for id, list in ipairs({room_ui.list_red,room_ui.list_blue}) do		
			list.EventItemClose = function(sender, e)
				local info = nil
				info = ptr_cast(e.Item.Tag)
				if info then
					if info.id ~= (host_character_info and host_character_info.id) then
	                    state:ChangeSlotStatus(e.Item.ID, 0)
	                else
	                    MessageBox.ShowError(lang:GetText("房主不可以关闭自己"))
					    return
	                end
				else 
					state:ChangeSlotStatus(e.Item.ID, 0)
				end
			end
	          
			list.EventItemOpen = function(sender, e)
				local info = nil
				info = ptr_cast(e.Item.Tag)
				if info then
					if info.id ~= (host_character_info and host_character_info.id) then
						state:ChangeSlotStatus(e.Item.ID, 1)
					end
				else
					state:ChangeSlotStatus(e.Item.ID, 1)
				end
			end
	     
			list.EventItemView = function(sender, e)
				local info = nil
           		info = ptr_cast(e.Item.Tag)
           		-- if info then
          			-- if info.id ~= (host_character_info and host_character_info.id) then
             				-- state:ChangeSlotStatus(e.Item.ID, 2)
             			-- else
             				-- MessageBox.ShowError(lang:GetText("房主不可以设自己观察"))
					    -- return
          			-- end
           		-- else
               		state:ChangeSlotStatus(e.Item.ID, 2)
           		-- end
			end
            ---------------------增加TIPS----------------------
			
			function list.UpdateMouseMove(sender,e)
				local lobby_state = ptr_cast(game.CurrentState)
				
				if lobby_state and tooltip_window_ui and tooltip_window_ui.ctrl_root and room_ui.list_red.PopupMenu.Focused == false and  room_ui.list_blue.PopupMenu.Focused == false then
					local cursor_pos = lobby_state:GetCursorPos()
					local pos = Vector2(cursor_pos.x+25,cursor_pos.y+25)
					ShowToolTipsWindow(pos)
				end
			end
		
			function list.EventNodeMouseEnter(sender,e)
				local item = sender.PointedItem
				local data = {}
				if item and room_ui.list_red.PopupMenu.Focused == false and  room_ui.list_blue.PopupMenu.Focused == false then
					local name = item:GetText(4)
					if name ~= "" then
						local client_count = state:GetClientCount()
						for i = 0, client_count - 1 do
							local client_info = state:GetClientInfo(i)
							if name == client_info.name then
								data[1] = client_info.fightnum
								data[2] = math.floor(client_info.win_rate*1000+0.5)/10
								-- --print("aaaaaaaaaaaaaaaaa:"..data[2])
								-- --print("bbbbbbbbbbbbbbbbb:"..client_info.group)
								data[3] = client_info.top
								if client_info.group == ""then
									data[4] = lang:GetText("无")
								else
									data[4] = client_info.group
								end
							end
						end
	
						FillToolTipsWindow(data,1)
					end
				end
			end
		
			function list.EventNodeMouseLeave(sender,e)
				HideToolTipsWindow()
			end
			
			-------------------增加右键菜单--------------------
			list.PopupMenu.Style = "Gui.MenuNew"
			list.EventRightClick = function(sender, e)
				list.PopupMenu:RemoveAll()
				local item = sender.MouseSelectedItem
				
				if not item then
					return
				end
				
				local name = item:GetText(4)
				local room_info=state:GetSelfRoomInfo()
				local room_option = ptr_cast(room_info.option)
				if host_character_info then
					if host_character_info.is_host == true then
						list.PopupMenu:AddItem(lang:GetText("打开"))
						list.PopupMenu:AddItem(lang:GetText("关闭"))
						if name ~= "" then
							list.PopupMenu:AddItem(lang:GetText("私聊"))
							list.PopupMenu:AddItem(lang:GetText("加为好友"))
							list.PopupMenu:AddItem(lang:GetText("查看信息"))
						end
						if host_character_info.is_vip ~= 0 and room_option.game_type ~= "kBossPVE" and room_option.game_type ~= "kAdvenceMode" then
							list.PopupMenu:AddItem(lang:GetText("观战"))
						end
						if name ~= "" then
							list.PopupMenu:AddItem(lang:GetText("我要举报"))
						end
					elseif host_character_info.is_host == false then
						list.PopupMenu:AddItem(lang:GetText("私聊"))
						list.PopupMenu:AddItem(lang:GetText("加为好友"))
						list.PopupMenu:AddItem(lang:GetText("查看信息"))
						list.PopupMenu:AddItem(lang:GetText("我要举报"))
						if name == "" then
							return
						end
					end
				end

				
				if sender.PopupMenu then
					sender.PopupMenu:Open()
					HideToolTipsWindow()
				end
			end
	          
			list.PopupMenu.EventClick = function(sender, e)
				local item = ptr_cast(sender.Tag)
				local name = item:GetText(4)
		      	local pid = GetPidByNameInRoom(name)
		      	--print("name = ",name)
				local room_info=state:GetSelfRoomInfo()
				local room_option = ptr_cast(room_info.option)
      			if host_character_info and host_character_info.is_host == true then
					if sender.SelectedIndex == 0 then	
						if Is_Auto_Start == false then
							if (room_option.game_type == "kBossPVE" or room_option.game_type == "kAdvenceMode") and room_option.client_count >= 10 then
								if room_option.game_type == "kBossPVE" then
									MessageBox.ShowWithTimer(2,lang:GetText("审判模式设定人数为10人\n不能再增加房间个数"))
								elseif room_option.game_type == "kAdvenceMode" then
									MessageBox.ShowWithTimer(2,lang:GetText(L_Text.kAdvenceMode.."模式设定人数为10人\n不能再增加人数"))
								end
							else
								state:ChangeSlotStatus(item.ID, 1)
							end
						end
					elseif  sender.SelectedIndex == 1 then
						if Is_Auto_Start == false then
							-- if room_option.game_type == "kAdvenceMode" and room_option.client_count <= 10 then
								-- MessageBox.ShowWithTimer(2,lang:GetText(L_Text.kAdvenceMode.."模式设定人数为10人\n不能再减少人数"))
							-- else
								list:CloseItem(item)
							-- end
						end
					elseif  sender.SelectedIndex == 2 and name ~= "" then
						if name == L_LobbyMain.PersonalInfo_data.name then
							L_Friends.ShowLeaveOwnGroupCreateWin(gui,lang:GetText("您不能和自己私聊！"))
							return
						end
						L_Friends.CreatePrivateChat(name,1)
					elseif  sender.SelectedIndex == 3 and name ~= "" then
						L_Friends.FriendsAdd(nil,name)
		      		elseif  sender.SelectedIndex == 4 and name ~= "" then
		      			Hide()
		      			if pid ~= ptr_cast(game.CurrentState):GetCharacterId() then
		      				L_PersonalInfo.ShowPerson(root_ui,pid,name)
		      				
		      			else
		      				L_PersonalInfo.Show(L_LobbyMain.LobbyMainWin_Boddy.LobbyMainWin_Boddy_Root)
		      				L_LobbyMain.InitPersonalInfoRPCInfo()
							lg:SetLobbyModules(12)
							L_LobbyMain.current_chosse_main_page = 12
							L_PersonalInfo.SynchronousClassButton()
							L_LobbyMain.FillClassBag(ptr_cast(game.CurrentState):GetCharacterId(), L_LobbyMain.current_choose_class)
		      			end
		      		-- elseif sender.SelectedIndex == 5 and name ~= "" and Is_Auto_Start == false then
		      			-- list:SetItemToView(item)
		      		elseif sender.SelectedIndex == 2 and name == "" then
		      			list:SetItemToView(item)
					elseif host_character_info.is_vip == 0 and sender.SelectedIndex == 5 and name ~= "" and Is_Auto_Start == false then
						ShowReportWin(name,1)
					elseif host_character_info.is_vip ~= 0 and sender.SelectedIndex == 6 and name ~= "" then
						ShowReportWin(name,1)
					elseif host_character_info.is_vip ~= 0 and sender.SelectedIndex == 5 and name ~= "" and Is_Auto_Start == false then
						list:SetItemToView(item)
	                end
	            else
					if sender.SelectedIndex == 0 and name ~= "" then
						if name == L_LobbyMain.PersonalInfo_data.name then
							L_Friends.ShowLeaveOwnGroupCreateWin(gui,lang:GetText("您不能和自己私聊！"))
							return
						end
						L_Friends.CreatePrivateChat(name,1)
					elseif sender.SelectedIndex == 1 and name ~= "" then
						L_Friends.FriendsAdd(nil,name)
					elseif  sender.SelectedIndex == 2 and name ~= "" then
					
						Hide()
						if pid ~= ptr_cast(game.CurrentState):GetCharacterId() then
							L_PersonalInfo.ShowPerson(root_ui,pid,name)
						else
							L_PersonalInfo.Show(L_LobbyMain.LobbyMainWin_Boddy.LobbyMainWin_Boddy_Root)
							L_LobbyMain.InitPersonalInfoRPCInfo()
							lg:SetLobbyModules(12)
							L_LobbyMain.current_chosse_main_page = 12
							L_PersonalInfo.SynchronousClassButton()
							L_LobbyMain.FillClassBag(ptr_cast(game.CurrentState):GetCharacterId(), L_LobbyMain.current_choose_class)
						end
					elseif  sender.SelectedIndex == 3 and name ~= "" then
						if name ~= "" then
							ShowReportWin(name,1)
						end
					end
			   end                               
			end
	          
	         
	    		
			function list.EventSelectItemChange(sender, e)
			     print("list.EventSelectItemChange()")
				local item = sender.SelectedItem
		        	 
				 if item then
				 	local room_slot = state:GetSlot(item.ID)  
		        	
			        	-- if room_slot and room_slot.status == 2 and host_character_info and host_character_info.is_host == true then
			        	 	-- return 
			        	-- end
		        	 
	                    if item.ID > 8 then
				            room_ui.list_red.SelectedItem = nil
	                    else
				            room_ui.list_blue.SelectedItem = nil
	                    end
	                    
	                    if not item.Tag and Is_Auto_Start == false then
	                        state:ChangeSlot(item.ID)
	                    end
	                end
	      	end
	      	
			list:DeleteColumns()
	     	if id == 1 then
				--list:AddColumn("",10, "kAlignCenterMiddle")
		     	list:AddColumn("",50, "kAlignCenterMiddle")
				list:AddColumn(lang:GetText("头像"), 40, "kAlignCenterMiddle")
				list:AddColumn(lang:GetText("等"), 27,"kAlignRightMiddle")
				list:AddColumn(lang:GetText("级"), 27,"kAlignLeftMiddle")
				list:AddColumn(lang:GetText("玩家昵称"),152,"kAlignLeftMiddle")
				list:AddColumn(lang:GetText("状态"),50,"kAlignCenterMiddle")
			elseif id == 2 then
				--list:AddColumn("",40, "kAlignCenterMiddle")
				list:AddColumn("",40, "kAlignCenterMiddle")
				list:AddColumn(lang:GetText("头像"), 40, "kAlignCenterMiddle")
				list:AddColumn(lang:GetText("等"), 27,"kAlignRightMiddle")
				list:AddColumn(lang:GetText("级"), 27,"kAlignLeftMiddle")
				list:AddColumn(lang:GetText("玩家昵称"),152,"kAlignLeftMiddle")
				list:AddColumn(lang:GetText("状态"),50,"kAlignCenterMiddle")
		    	end
		    	
			list.IsHost = false
			list.Columns.Clickable = false
			list.Columns.Movable = false 
			local root = list.RootItem
	
			list:DeleteAll()
			
			for i = 1, 8 do
				local item = list:AddItem(root, "",false)
				item.ID = i + (id - 1) * 8
				item:AddSubItem("")
				item:AddSubItem("")
				item:AddSubItem("")
				item:AddSubItem("")
				item:AddSubItem("")
				table.insert(client_items, item)
			end
		end
		
		
		function room_ui.btn_begin.EventClick()
			local room_info = state:GetSelfRoomInfo()
			local room_option = ptr_cast(room_info.option)
			if room_info.state == 2 then
				MessageBox.ShowWaiter(lang:GetText("正在开始游戏,请稍候..."))
				state:EnterGame()	
			else
				if host_character_info then
					local is_host = host_character_info.is_host
				 
					if host_character_info.is_host == true then
						local client_count = state:GetClientCount()
						local Ready_Count = 0
						for i = 0, client_count - 1 do
							client_info = state:GetClientInfo(i)
							if client_info.ready then
								Ready_Count = Ready_Count + 1
							end	
						end
						print("client_count:"..client_count)
						print("Ready_Count:"..Ready_Count)
						if Ready_Count < client_count and room_info.option.game_type == "kBossPVE" then
							MessageBox.ShowWithTwoButtons(lang:GetText("房间内有玩家未准备，是否开始游戏？"),lang:GetText("开始"),lang:GetText("取消"),
							function()
								MessageBox.ShowWaiter(lang:GetText("正在开始游戏,请稍候..."))						
								state:StartGame()
							end,
							nil
							)
							return
						else
							MessageBox.ShowWaiter(lang:GetText("正在开始游戏,请稍候..."))						
							state:StartGame()
						end
					else
						if Is_Auto_Start == false then
							MessageBox.ShowWaiter(lang:GetText("正在") .. (host_character_info.ready and lang:GetText("取消准备") or lang:GetText("准备")) .. lang:GetText("游戏,请稍候..."))
							state:Ready(not host_character_info.ready)
							--print("state:Ready()")
						end
					end
				end
			end
		end
		
		
		------------------开始游戏按钮----------------------------    
		function room_ui.btn_begin.EventClick()
			local room_info = state:GetSelfRoomInfo()
			local room_option = ptr_cast(room_info.option)
			
			if room_info.state == 2 then
				MessageBox.ShowWaiter(lang:GetText("正在开始游戏,请稍候..."))
				state:EnterGame()	
			else
				if host_character_info then
					local is_host = host_character_info.is_host
				 
					if host_character_info.is_host == true then
						local client_count = state:GetClientCount()
						local Ready_Count = 0
						for i = 0, client_count - 1 do
							client_info = state:GetClientInfo(i)
							if client_info.ready then
								Ready_Count = Ready_Count + 1
							end	
						end

						if Ready_Count < client_count and room_info.option.game_type == "kBossPVE" then
							MessageBox.ShowWithTwoButtons(lang:GetText("房间内有玩家未准备，是否开始游戏？"),lang:GetText("开始"),lang:GetText("取消"),
							function()
								MessageBox.ShowWaiter(lang:GetText("正在开始游戏,请稍候..."))						
								state:StartGame()
							end,
							nil
							)
							return
						else
							MessageBox.ShowWaiter(lang:GetText("正在开始游戏,请稍候..."))						
							state:StartGame()
						end
					else
						if Is_Auto_Start == false then
							MessageBox.ShowWaiter(lang:GetText("正在") .. (host_character_info.ready and lang:GetText("取消准备") or lang:GetText("准备")) .. lang:GetText("游戏,请稍候..."))
							state:Ready(not host_character_info.ready)
							--print("state:Ready()")
						end
					end
				end
			end
		end
		
		
		--------------------换边---------------------------------
--[[		function room_ui.btn_change_team.EventClick()
			if Is_Auto_Start == false then
				if host_character_info and host_character_info.team ~= 0 then
					state:ChangeTeam(0)
					if room_ui and room_ui.list_red then
						room_ui.list_red.SelectedItem = nil
					end                            
				elseif host_character_info and host_character_info.team ~= 1 then
					state:ChangeTeam(1)
					if in_room_ui and in_room_ui.list_blue then
						in_room_ui.list_blue.SelectedItem = nil
					end
				end
			end
		end
]]		
		
		------------------房间设置------------------------------	
		
			
		function room_ui.btn_room_option.EventClick()
			local room_info = state:GetSelfRoomInfo()
			if room_info.state == 2 then
				MessageBox.ShowError(lang:GetText("还有人正在游戏,无法再次设置该房间"))
				return
			end
		     
			if Is_Auto_Start == true then
				MessageBox.ShowError(lang:GetText("启动自动开始，不能更改房间设置"))
				return
			end

			if not create_room_ui then
				ShowCreateRoom(root_ui)
			end
		
			
		    create_room_ui.cbx_Number.Enable = false
			setup_ui_game_mode(create_room_ui.cbx_Mode ,true)

			HideAll()		     
			ShowCreateRoom(root_ui)
		    FillRoomInfo(room_info)
		end
		
		
	else
		room_ui.ctrl_Main_Window.Parent = win_parent
		current_state = 3
	end
	local room_info = state:GetSelfRoomInfo()
	room_ui.roomid_name1.Text = lang:GetText("当前位置:").."\n"..lang:GetText(server_name).."-"..lang:GetText(channel_name)..lang:GetText("-房间")..room_info.id
	room_ui.roomid_name2.Text = lang:GetText("房间名称")..lang:GetText(":")..lang:GetText(room_info.option.name)
	EventRoomClientListChangedCallBack()
	
	MessageBox.CloseWaiter()
	
end

function IsGameBalance(room_option_arg)
	local isBalance = true
	return isBalance
end

function LoadCard(item,left,coulmn,cardID)
	local index
	
	SingleOrDouble = ""
	HoverAndDown = ""
	CardType = ""
	
	if cardID > 0 then
		--print("in LoadCard")
		--print("left = ",left)
		--print("coulmn =",coulmn )
		--print("cardID = ",cardID)
		if left == 1 then
			if coulmn %2 == 0 then
				CardType = "r"
				HoverAndDown = "red"
				SingleOrDouble = "double"
				index = 2
			else
				index = 1
				
				CardType = "r"
				HoverAndDown = "red"
				SingleOrDouble = "single"
			end
		else
			if coulmn %2 == 0 then
				index = 3
				CardType = "b"
				HoverAndDown = "blue"
				SingleOrDouble = "double"
			else
				index = 4
				CardType = "b"
				HoverAndDown = "blue"
				SingleOrDouble = "single"
			end
		end
		
		
		item.BGSkin = Gui.ListItemSkin
						{
							--control skin
							BackgroundImage = Gui.Image("LobbyUI/WarZone/Card/namecard"..cardID.."_"..CardType.."_"..SingleOrDouble..".dds", Vector4(8, 3,10, 3)),
							SelfImage = Gui.Image("LobbyUI/WarZone/lb_room_list_"..HoverAndDown.."bg_me.dds", Vector4(10,10,10,10)),
							HoverImage = Gui.Image("LobbyUI/WarZone/lb_room_list_"..HoverAndDown.."bg_hover.dds", Vector4(8, 3, 10, 3)),
							SelectedImage = Gui.Image("LobbyUI/WarZone/Card/namecard"..cardID.."_down_"..CardType..".dds", Vector4(8, 3, 10, 3)),
						}
	end
end


function EventRoomSlotChangedCallBack()
	print("in EventRoomSlotChangedCallBack()")
	
	if room_ui and room_ui.list_blue and room_ui.list_red and host_character_info then
		--print("++++++++++in EventRoomSlotChangedCallBack()")
		for j, list in ipairs({room_ui.list_red,room_ui.list_blue}) do
			
			list.IsHost = host_character_info.is_host
			
			for i = 1, 8 do
				local item = list:DisplayIndexToItem(i-1)
				if item then
					item:SetHoverIcon(4,nil)
					item:SetIcon(4, nil)
					local room_slot = state:GetSlot(item.ID)              
					local iconN = nil
					local iconA = nil
					local client_info = nil		
					client_info = ptr_cast( item.Tag )
					local CardId = -1
					if client_info then	
						CardId = client_info.business_card
					end
							
		            if  i % 2 == 0 then
		               	if j == 1 then	               	
		               		item.BGSkin = Skin.ListItemSkin_Double_Red
		               	else
		               		item.BGSkin = Skin.ListItemSkin_Double_Blue
		               	end
		               	
		               	if client_info and client_info.is_vip ~= 0 then
		               		if j == 1 then
		               			item.BGSkin = Skin.ListItemSkin_Double_Vip_Red
		               		else
		               			item.BGSkin = Skin.ListItemSkin_Double_Vip_Blue
		               		end
		               	end 
		               	
		            else
		               	if j == 1 then
		               		item.BGSkin = Skin.ListItemSkin_Single_Red
		               	else
		               		item.BGSkin = Skin.ListItemSkin_Single_Blue
		               	end
		               	
		               	if client_info and client_info.is_vip ~= 0 then
		               		if j == 1 then
		               			item.BGSkin = Skin.ListItemSkin_Single_Vip_Red
		               		else
		               			item.BGSkin = Skin.ListItemSkin_Single_Vip_Blue
		               		end
		               	end 
		            end
		    		LoadCard(item,j,i,CardId)
					if client_info and (client_info.is_vip ~= 0 or client_info.net_bar_level ~= 0) then
						-- item:SetIcon(0, Gui.Icon("LobbyUI/vip/lb_"..client_info.is_vip.."_ico_"..client_info.net_bar_level..".dds"),Vector4(0, 0, 0, 0))
						if j == 1 then
							item:SetIcon(0, Gui.Icon("LobbyUI/vip/vip/VIP_button_0"..client_info.is_vip.."_normalred.dds"),Vector4(0, 0, 0, 0))
						else
							item:SetIcon(0, Gui.Icon("LobbyUI/vip/vip/VIP_button_0"..client_info.is_vip.."_normal.dds"),Vector4(0, 0, 0, 0))
						end
					end
					if client_info and client_info.is_gm == 1 then
						if j == 1 then
							item:SetIcon(0, Gui.Icon("LobbyUI/GM_red.dds"),Vector4(0, 0, 0, 0))
						else
							item:SetIcon(0, Gui.Icon("LobbyUI/GM.dds"),Vector4(0, 0, 0, 0))
						end
						
					end
					if room_slot.status == 0 then					
						if client then
							state:RoomKickClient(client.id)
						end
						iconN = Icons.PlayerStatusIcons["Close"]
						iconA = Icons.PlayerStatusIcons["CloseHover"]
						item:SetIcon(4,iconN)	
						item:SetHoverIcon(4,iconA)
					elseif room_slot.status == 1 then
						item:SetIcon(4, nil)
						list:OpenItem(item)					
					elseif room_slot.status == 2 then
						if item:GetText(4) == "" then
							item:SetIcon(4,nil)
							iconA = Icons.PlayerStatusIcons["WatchPlayingA"]
							iconN = Icons.PlayerStatusIcons["WatchPlayingHover"]
							item:SetIcon(4,iconA)
							item:SetHoverIcon(4,iconN)
						else
							item:SetIcon(5,nil)
							iconA = Icons.PlayerStatusIcons["WatchPlayingB"]
							iconN = Icons.PlayerStatusIcons["WatchPlayingB"]
							item:SetIcon(5,iconA)
							item:SetHoverIcon(5,iconN)
						end
					end
					if (i + (j - 1)*8) == host_character_info.id then
						if is_Look == false and room_slot.status == 2 then
							MessageBox.ShowWithTimer(2,lang:GetText("您现在为观察者状态"))
							is_Look = true
							is_specialjob = false
						elseif room_slot.status ~= 2 then
							is_Look = false
							
							local room_info=state:GetSelfRoomInfo()
							if room_info.option.character_id ~= 0 and specialjob_id ~= room_info.option.character_id then
								specialjob_id = room_info.option.character_id
								local special_war = character[room_info.option.character_id + 1]
								MessageBox.ShowWithTimer(2,lang:GetText("当前你所在的房间为“特殊职业战”房间\n特殊职业为“")..special_war.."”")
								-- is_specialjob = false
							end
						end
					end
            	end
			end
		end
	end
end

function GetPidByNameInRoom(name)
	local room_info=state:GetSelfRoomInfo()
	local room_option = ptr_cast(room_info.option)
	local client_count = state:GetClientCount()
	
	local pid = -1
	
	for i = 0, client_count - 1 do
		local client_info = state:GetClientInfo(i)
		
		if name == client_info.name then
			pid = client_info.character_id
		end
	end
	
	return pid
end

function EventRoomClientListChangedCallBack()
	print("in EventRoomClientListChangedCallBack()")
	local ll = 0
	local rr = 0
	local xx = 0
	--print(1)
	--print(room_ui.ctrl_Main_Window.Parent)
	local room_info=state:GetSelfRoomInfo()
	local room_option = ptr_cast(room_info.option)
	local half_count = room_option.client_count / 2
	--print("room_option.client_count=",room_option.client_count)
	local my_id = state:GetCharacterId()
     
	if IsMatchServer() then
		if my_id == room_info.host_id then
			match_window_ui.btn_match.Enable = true
			match_window_ui.btn_invite.Enable = true
		else
			match_window_ui.btn_match.Enable = false
			match_window_ui.btn_invite.Enable = false
		end	
	elseif IsMatchServer1() then
		if my_id == room_info.host_id then
			automatic_match_ui.start_match.Enable = true
			automatic_match_ui.btn_invite.Enable = true
		else
			automatic_match_ui.start_match.Enable = false
			automatic_match_ui.btn_invite.Enable = false
		end	
	end

	 
	for id, item in ipairs(client_items) do
		-- VIP
		item:SetIcon(0, nil)
		--头像
		item:SetIcon(1, nil)
		--等级	 
		item:SetIcon(2, nil)
		item:SetIcon(3, nil)
		-- 玩家昵称
		item:SetText(4, nil)
		-- 状态
		item:SetIcon(5, nil)
		
		item:SetHoverIcon(5, nil)
		item.IsSelfItem = false
		item.LV_BackgroundImage = nil
		item.Tag = nil
	end
	
--	L_Friends.CreateChatRoom(room_info.option.name)
	
	if not room_ui.ctrl_Main_Window.Parent then
		return
	end
	
	--print("in EventRoomClientListChangedCallBack()")
	
	local client_count = state:GetClientCount()
     
    print("client_count=",client_count)
	local Ready_Count = 0
	for i = 0, client_count - 1 do
		client_info = state:GetClientInfo(i)
		local item = nil
		
		item = client_items[client_info.id]
		
		
		if item then
			if client_info.id <= 8 then
				ll = ll + 1
				xx = 93
			elseif client_info.id >=9 then
				rr = rr + 1
				xx = 83
			end
			local status = ""
			local name = ""
			local iconVip = nil
			local iconN = nil
			local iconA = nil
			local iconH = nil
			local iconHead = nil
			local icon2,icon1 = nil,nil
			local isVip = client_info.is_vip
			--print("isVip = ",isVip)
			-- if isVip == 1 then
				-- iconVip = Icons.PlayerStatusIcons["Vip"]
			-- elseif isVip == 2 then
				-- iconVip = Icons.PlayerStatusIcons["XunLeiVip"]
			-- end
			
			if isVip > 0 then
				iconVip = Gui.Icon("LobbyUI/vip/vip/VIP_button_0"..isVip.."_normal")
			end
			--print("client_info.icon = ",client_info.icon)
			if client_info.icon ~= "null" then
				iconHead = Gui.Icon("LobbyUI/persionalInfo/HeadPic/lb_battlefield_icon"..client_info.icon..".dds")
			end
			
			if iconHead == nil then
				iconHead = Gui.Icon("LobbyUI/persionalInfo/HeadPic/lb_battlefield_icon01_b.dds")
			end
			
			--iconHead = Icons.PlayerStatusIcons["Head"]
			if client_info.in_game then
				
				iconN = Icons.PlayerStatusIcons["PlayingC"]
				iconA = Icons.PlayerStatusIcons["PlayingC"]
			elseif client_info.ready then
				Ready_Count = Ready_Count + 1
				iconN = Icons.PlayerStatusIcons["ReadyN"]
				iconA = Icons.PlayerStatusIcons["ReadyA"]
			end
                
			if client_info.is_host then
				client_info.ready = true
				iconN = Icons.PlayerStatusIcons["Host"]
				iconA = Icons.PlayerStatusIcons["Host"]
			end
			
			
			if (my_id == client_info.character_id) then
				host_character_info = client_info
				item.IsSelfItem = true
			 	name = client_info.name
			else
			 	name = client_info.name
			end
			-- name = game:StrCut(name,6)
			item:SetIcon(0, iconVip)
			item:SetIcon(1, iconHead)
			item:SetText(4, name)
			item:SetIcon(5, iconN)
			item:SetHoverIcon(5, iconA)
			FillLevel(client_info.level, client_info.exp, item)
			
			local num = 5
			item.LV_BackgroundImage = Gui.Image("LobbyUI/lv"..(math.floor((client_info.level - 1)/num)*num+1).."-"..(math.ceil(client_info.level/num)*num)..".dds", Vector4(0, 0, 0, 0), Vector4(0, 0, 1, 1))
			item.LV_localtion = Vector2(xx,0)
			item.LV_Size = Vector2(46,42)
		end
	end
  
  	if host_character_info then

		if host_character_info.is_host == true then
			room_ui.btn_begin.Skin = Skin.ButtonSkin_StartGame
--			room_ui.ctrl_btn_setroom.Visible = true
			
--			room_ui.ctrl_btn.Size = Vector2(273, 80)
			room_ui.ctrl_btn.Visible = true
--			room_ui.btn_invite.Visible = true
		else
			
	        if room_info.state == 2 then
			room_ui.btn_begin.Skin = host_character_info.ready and Skin.ButtonSkin_ReadyCancel or Skin.ButtonSkin_EnterGame			
	        else
			room_ui.btn_begin.Skin = host_character_info.ready and Skin.ButtonSkin_ReadyCancel or Skin.ButtonSkin_Ready
	        end
	       
--			room_ui.ctrl_btn_setroom.Visible = false
			room_ui.ctrl_btn.Visible = false
--			room_ui.ctrl_btn.Size = Vector2(129, 80)
--			room_ui.btn_invite.Visible = false
		end
		if host_character_info.is_host == true then
			L_LobbyMain.ReadlyState(true)
			L_LobbyMain.EnterRoomState(not room_option.auto_start)
		else
			L_LobbyMain.EnterRoomState(not host_character_info.ready)
			L_LobbyMain.ReadlyState(not host_character_info.ready)
		end
	end
 
	EventRoomSlotChangedCallBack()     
	DisplayRoomInfo()     
	if room_ui then
		room_ui.lbl_red.Text = ll
		room_ui.lbl_blue.Text = rr
	end
	
	if L_LobbyMain.Timer_control_ui.Timer and room_ui then
		L_LobbyMain.Timer_control_ui.Timer.Visible = Is_Auto_Start
		L_LobbyMain.Timer_control_ui.Timer.Parent = room_ui.ctrl_room_title
	end
	
end

function UpdateRoomInfo(room_info, room_option)
	local roomlist = main_room_info_ui.list_room_info
	roomlist:AddColumn("",20,"kAlignLeftMiddle")
	roomlist:AddColumn("",140,"kAlignLeftMiddle")
	roomlist:AddColumn("",170,"kAlignLeftMiddle")
	
	local root = roomlist.RootItem     
	roomlist:DeleteAll()

	local item = roomlist:AddItem(root,1)
	item.CanSelect = false
	item.ColCantSelect = true
	item.BGSkin = Skin.ListItemSkin_Single
	item:SetText(0,"")
	item:SetText(1,lang:GetText("房主名称:"))
	item:SetSubItemColor(1, lrv_colors[9])	
	local hostname = room_info.host_name
	if id == 0 then
		item:SetText(2,"")  
	else
		item:SetText(2,hostname)  
	end
	
	item = roomlist:AddItem(root,2)
	item.CanSelect = false
	item.BGSkin = Skin.ListItemSkin_Double
	item.ColCantSelect = true
	item:SetText(0,"")
	item:SetText(1,lang:GetText("游戏模式:"))
	item:SetSubItemColor(1, lrv_colors[9])	
	local game_mode = game_type(room_option.game_type) or ""
	if id == 0 then
		item:SetText(2,"")
	else
		item:SetText(2,game_mode)  
	end
     
	item = roomlist:AddItem(root,3)
	item.CanSelect = false
	item.BGSkin = Skin.ListItemSkin_Single
	item.ColCantSelect = true
	item:SetText(0,"")
	item:SetText(1,lang:GetText("胜利条件:"))
	item:SetSubItemColor(1, lrv_colors[9])	
	local rule_value=0
	if room_option.game_type == "kTeam" or room_option.game_type == "kKnife" or room_option.game_type == "kItemMode" then
		rule_value = room_option.rule_value
		rule_value = rule_value .. lang:GetText("人")
	else
		rule_value = room_option.rule_value
		rule_value = rule_value .. lang:GetText("回合")
	end
	rule_value = rule_value or ""
	if id == 0 then
		item:SetText(2,"")
	else
		item:SetText(2,rule_value)  
	end
	
	item = roomlist:AddItem(root,4)
	item.CanSelect = false
	item.BGSkin = Skin.ListItemSkin_Double
	item.ColCantSelect = true
	item:SetText(0,"")
	item:SetText(1,lang:GetText("自动开始:"))
	item:SetSubItemColor(1, lrv_colors[9])
	if id == 0 then
		item:SetText(2,"")
	else
		if room_option.auto_start == true then
			item:SetText(2,lang:GetText("开启"))
			item:SetSubItemColor(2, lrv_colors[2])
		else
			item:SetText(2,lang:GetText("关闭"))
			item:SetSubItemColor(2, lrv_colors[1])
		end
	end
	
	item = roomlist:AddItem(root,5)
	item.CanSelect = false
	item.BGSkin = Skin.ListItemSkin_Single
	item.ColCantSelect = true
	item:SetText(0,"")
	item:SetText(1,lang:GetText("特殊职业战:"))
	item:SetSubItemColor(1, lrv_colors[9])
	if id ~= 0 then
		local special_war = character[room_option.character_id + 1]
		item:SetText(2,special_war)
	else
		item:SetText(2,"")
	end
	
	item = roomlist:AddItem(root,6)
	item.CanSelect = false
	item.BGSkin = Skin.ListItemSkin_Double
	item.ColCantSelect = true
	item:SetText(0,"")
	item:SetText(1,lang:GetText("中途加入:"))
	item:SetSubItemColor(1, lrv_colors[9])
	if id ~= 0 then
		if room_option.can_join_on_playing == true then
			item:SetText(2,lang:GetText("允许"))
			item:SetSubItemColor(2, lrv_colors[2])
		else
			item:SetText(2,lang:GetText("不允许"))
			item:SetSubItemColor(2, lrv_colors[1])
		end
	else
		item:SetText(2,"")
	end
	
	item = roomlist:AddItem(root,7)
	item.CanSelect = false
	item.BGSkin = Skin.ListItemSkin_Single
	item.ColCantSelect = true
	item:SetText(0,"")
	item:SetText(1,lang:GetText("战力平衡:"))
	item:SetSubItemColor(1, lrv_colors[9])
	if id ~= 0 then
		if room_option.check_game_balance == true then
			item:SetText(2,lang:GetText("开启"))
			item:SetSubItemColor(2, lrv_colors[2])	
		else
			item:SetText(2,lang:GetText("关闭"))
			item:SetSubItemColor(2, lrv_colors[1])
		end
	else
		item:SetText(2,"")
	end
	
	item = roomlist:AddItem(root,8)
	item.CanSelect = false
	item.BGSkin = Skin.ListItemSkin_Double
	item.ColCantSelect = true
	item:SetText(0,"")
	item:SetText(1,lang:GetText("复活时间:"))
	item:SetSubItemColor(1, lrv_colors[9])
	if id ~= 0 then
		local round_rebirth_time_max = room_option.round_rebirth_time_max .. lang:GetText("秒")
		item:SetText(2,round_rebirth_time_max)
		if room_option.game_type ~= "kTeam" and room_option.game_type ~= "kKnife" and room_option.game_type ~= "kItemMode" then
			item:SetSubItemColor(2,ARGB(255,128,128,128))
			item:SetSubItemColor(2,ARGB(255,128,128,128))
		end
	else
		item:SetText(1,"")
	end
	if id ~= 0 then
		main_room_info_ui.ctrl_small_map.ForeGroundImage = FindMapIcon(room_option.map_name).Icon_out
		main_room_info_ui.Tips.Visible = true
		main_room_info_ui.Tips.Skin = Gui.ButtonSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_chat_special_"..room_option.character_id..".dds", Vector4(0, 0, 0, 0)),
			TwinkleImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_chat_special_"..room_option.character_id.."_flash.dds", Vector4(0, 0, 0, 0)),
		}
	else
		main_room_info_ui.ctrl_small_map.ForeGroundImage = Gui.Image("MapsAndBG/MapsIcon/lb_battlefield_map_lv0_b.dds",Vector4(0,0,0,0))
	end
end

function DisplayRoomInfo()
	local room_info = state:GetSelfRoomInfo()
	
	local room_option = ptr_cast(room_info.option)
     
	local roomlist = room_ui.list_room_info
	local root = roomlist.RootItem     
	roomlist:DeleteAll()
     --print("id = ",room_info.id)
     --print("host_id = ",room_info.host_id)
     --print("state = ",room_info.state)
     --print("host_name = ",room_info.host_name)
     
	local item = roomlist:AddItem(root,1)
	item.CanSelect = false
	item.ColCantSelect = true
	item.BGSkin = Skin.ListItemSkin_Single
	item:SetText(0,lang:GetText("房主名称:"))
	item:SetSubItemColor(0, lrv_colors[9])	
	local hostname = room_info.host_name
	item:SetText(1,hostname)  
     
	item = roomlist:AddItem(root,2)
	item.CanSelect = false
	item.BGSkin = Skin.ListItemSkin_Double
	item.ColCantSelect = true
	item:SetText(0,lang:GetText("游戏模式:"))
	item:SetSubItemColor(0, lrv_colors[9])	
	local game_mode = game_type(room_option.game_type) or ""
	item:SetText(1,game_mode)
	
	item = roomlist:AddItem(root,3)
	item.CanSelect = false
	item.BGSkin = Skin.ListItemSkin_Single
	item.ColCantSelect = true
	item:SetText(0,lang:GetText("胜利条件:"))
	item:SetSubItemColor(0, lrv_colors[9])	
	local rule_value=0
	if room_option.game_type == "kTeam" or room_option.game_type == "kKnife" or room_option.game_type == "kItemMode" then
		rule_value = room_option.rule_value
		rule_value = rule_value .. lang:GetText("人")
	else
		rule_value = room_option.rule_value
		rule_value = rule_value .. lang:GetText("回合")
	end
	rule_value = rule_value or ""
	if id == 0 then
		item:SetText(1,"")
	else
		item:SetText(1,rule_value)  
	end

	item = roomlist:AddItem(root,4)
	item.CanSelect = false
	item.BGSkin = Skin.ListItemSkin_Double
	item.ColCantSelect = true
	item:SetText(0,lang:GetText("复活时间:"))
	item:SetSubItemColor(0, lrv_colors[9])
	if id ~= 0 then
		local round_rebirth_time_max = room_option.round_rebirth_time_max .. lang:GetText("秒")
		item:SetText(1,round_rebirth_time_max)
		if room_option.game_type ~= "kTeam" and room_option.game_type ~= "kKnife" and room_option.game_type ~= "kItemMode" then
			item:SetSubItemColor(1,ARGB(255,128,128,128))
			item:SetSubItemColor(1,ARGB(255,128,128,128))
		end
	else
		item:SetText(1,"")
	end
     
	room_ui.ctrl_small_map.ForeGroundImage = FindMapIcon(room_option.map_name).Icon_out
	room_ui.Tips.Visible = true
	room_ui.Tips.Skin = Gui.ButtonSkin
	{
		BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_chat_special_"..room_option.character_id..".dds", Vector4(0, 0, 0, 0)),
		TwinkleImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_chat_special_"..room_option.character_id.."_flash.dds", Vector4(0, 0, 0, 0)),
	}

	if is_knife == 1 then
		room_ui.knife_tips.Visible = true
	else
		room_ui.knife_tips.Visible = false
	end

--	L_Friends.UpdateRoomInfo(room_name)
end

function SetModeState(AllMode_new_com,AllMode_new,AllMode_commend,AllMode)
	setting_mode = {}
	setting_moshi = {}
	setting_map = {}
	setting_mode[1] = {"kAll",lang:GetText("全部"),0,0}
	setting_moshi[1] = lang:GetText("全部")
	local i_tep = 2
	if AllMode_new_com then
		for i=1, #AllMode_new_com do
			for j=1, #game_type_info_order do
				if game_type_info_order[j][3] == tonumber(AllMode_new_com[i]) then				
					setting_mode[i_tep] = {game_type_info_order[j][2],game_type_info_order[j][1],3,0}
					setting_moshi[i_tep] = game_type_info_order[j][1]
					setting_map[i_tep-1] = map_show_name[game_type_info_order[j][2]]
					i_tep = i_tep + 1
					break
				end
			end
		end
	end
	if AllMode_new then
		for i=1, #AllMode_new do
			for j=1, #game_type_info_order do
				if game_type_info_order[j][3] == tonumber(AllMode_new[i]) then				
					setting_mode[i_tep] = {game_type_info_order[j][2],game_type_info_order[j][1],1,0}
					setting_moshi[i_tep] = game_type_info_order[j][1]
					setting_map[i_tep-1] = map_show_name[game_type_info_order[j][2]]
					i_tep = i_tep + 1
					break
				end
			end
		end
	end
	if AllMode_commend then
		for i=1, #AllMode_commend do
			for j=1, #game_type_info_order do
				if game_type_info_order[j][3] == tonumber(AllMode_commend[i]) then				
					setting_mode[i_tep] = {game_type_info_order[j][2],game_type_info_order[j][1],2,0}
					setting_moshi[i_tep] = game_type_info_order[j][1]
					setting_map[i_tep-1] = map_show_name[game_type_info_order[j][2]]
					i_tep = i_tep + 1
					break
				end
			end
		end
	end
	if AllMode then
		for i=1, #AllMode do
			for j=1, #game_type_info_order do
				if game_type_info_order[j][3] == tonumber(AllMode[i]) then				
					setting_mode[i_tep] = {game_type_info_order[j][2],game_type_info_order[j][1],0,0}
					setting_moshi[i_tep] = game_type_info_order[j][1]
					setting_map[i_tep-1] = map_show_name[game_type_info_order[j][2]]
					i_tep = i_tep + 1
					break
				end
			end
		end
	end
end

function setup_ui_room_list_mode(cbx)
	if game.ClientAddress.server_id == server_id_mod then
		return
	end
	server_id_mod = game.ClientAddress.server_id
	cbx.Enable = true
	cbx:RemoveAll()
	local info = state:GetServerInfo(game.ClientAddress.server_id - 1,false)
	local gametype_limit_old = L_PushCmd.Split(info.gametype_limit,";")	
	local gametype_limit = L_PushCmd.Split(gametype_limit_old[1],",")
	local gametype_commend = L_PushCmd.Split(gametype_limit_old[2],",")
	local gametype_new = L_PushCmd.Split(gametype_limit_old[3],",")
	local gametype_new_com = L_PushCmd.Split(gametype_limit_old[4],",")
	SetModeState(gametype_new_com,gametype_new,gametype_commend,gametype_limit)
	for i=1, #setting_mode do
		if(setting_mode[i][3] == 0) then
			cbx:AddItem(setting_mode[i][2])
		else
			cbx:AddItemWithIcon(setting_mode[i][2],setting_mode[i][3] - 1)
		end
	end
	
	cbx.SelectedIndex = 0
	
	my_game_mode = setting_mode[1][2]
	print("6075")
	ShowWitchList(my_game_mode)
	
	function cbx:EventItemSelected(sender, e)
	print("6079")
		local index = self.SelectedIndex
		my_game_mode = setting_mode[index + 1][2]
		ShowWitchList(my_game_mode)
	end
end

--显示房间信息
function ShowRoomInfo(win_parent)
	if main_room_info_ui.room_info.Visible == false then
		main_room_info_ui.room_info.Parent = win_parent
		main_room_info_ui.room_info.Visible = true
	else
		main_room_info_ui.room_info.Visible = false
		return
	end
end

--显示房间列表
function ShowRoomList(win_parent)
	if state.is_fight_team_server then
		return
	end
	if L_FightTeam.is_in_fight_ui then
		return
	end
	if L_FightTeam.is_in_invite then
		return
	end
	if match_window_ui then
		return
	end
	if automatic_match_ui then
		return
	end
	
	if IsMatchServer() then
		-- state.LeaveChannel()
		return
	end
	if IsMatchServer1() then
		return
	end
	print("=================L_WarZone ShowRoomList()")
	L_LobbyMain.HideAll()
	L_LobbyMain.current_chosse_main_page = 5
	L_LobbyMain.LobbyMainWin_Foot.btn_WarZone.PushDown = true
	
	local s = ptr_cast(game.CurrentState,"Client.StateLobby")
						
	if s then
		s:UpdateReplayList()
		count = s:GetReplayCount()
	end
	
	if count > 0 then
		L_LobbyMain.LobbyMainWin.video_button.Enable = true
	else
		L_LobbyMain.LobbyMainWin.video_button.Enable = false
	end
	--创建界面
	
	if not main_room_list_ui then
		main_room_list_ui = Gui.Create(win_parent)(room_list_window)
		current_state = 2
		local list = main_room_list_ui.list
		list:DeleteColumns()
	    list.Columns.Clickable = true
		list:AddColumn(lang:GetText("序号"),59,"kAlignCenterMiddle")
		list:AddColumn("",16, "kAlignCenterMiddle",true)
		list:AddColumn("",36, "kAlignCenterMiddle",true)
		list:AddColumn(lang:GetText("房间名称"),142,"kAlignCenterMiddle")
		list:AddColumn(lang:GetText("模式"),88,"kAlignCenterMiddle")		
		list:AddColumn(lang:GetText("职业战"),88, "kAlignCenterMiddle")
		list:AddColumn(lang:GetText(" 地图"),104,"kAlignLeftMiddle")
		list:AddColumn(lang:GetText("人数"),66,"kAlignCenterMiddle")
		list:AddColumn(lang:GetText("状态"),75,"kAlignCenterMiddle")
		list.Columns.SortID = 0
		list.Columns.SortReverse = true
		
		local roomlist = main_room_list_ui.list_room_info
		roomlist:AddColumn("",140,"kAlignCenterMiddle")
		roomlist:AddColumn("",190,"kAlignCenterMiddle")
		
		RoomInfoInit()
		
		function list.EventSelectItemChange(sender)
			local item = sender.SelectedItem
	
			if item then
				room_id = tonumber(item:GetText(0))
				room_name = item:GetText(3)
			else
				room_id = 0
				rodm_name = ""
			end
			
			if item and item.Tag then
				current_select_room_info = ptr_cast(item.Tag)
				local room_info = current_select_room_info
				local room_option = ptr_cast(room_info.option)				
				SelectedroomID = room_info.id
				RefreshRoomInfo(room_info,room_option)
			else
				main_room_list_ui.ctrl_small_map.ForeGroundImage = nil
				main_room_list_ui.room_name2.Text = ""
				RoomInfoInit()
			end
	
			main_room_list_ui.btn_enter_room.Enable = (room_id > 0)
		end
		
		function list.EventDoubleClick(sender, e)
			local item = sender.SelectedItem
			
			if item then
				e.Handled = true				
				if state.AmILeader then
					--L_EnterRoomTip.Show(tonumber(item:GetText(0)))
				else
					EnterRoom(tonumber(item:GetText(0)))
				end
			end
		end
		
		function list.Columns.EventItemClick(sender, e)
			if state then
				now_Column = e.Column
				list:SortColumnExt(e.Column, false, state:GetRoomListCompareFunc())
				ShowWitchList(my_game_mode)
			else
				--print("state not valid when sorting rooms")
			end
		end
		
		function main_room_list_ui.btn_create_room.EventClick()
			create_room_ui = nil
			ShowCreateRoom(root_ui)
			if host_character_info then
				host_character_info = NullPtr
				host_character_info = nil
			end
		end
				
		function main_room_list_ui.btn_enter_room.EventClick()
			local item = list.SelectedItem
			if item then
				if state.AmILeader then
					L_EnterRoomTip.Show(tonumber(item:GetText(0)))
				else
					EnterRoom(tonumber(item:GetText(0)))
				end
			end
		end
		
	else
		main_room_list_ui.ctrl_Main_Window.Parent = win_parent
		current_state = 2
	end
	if main_room_list_ui then
		main_room_list_ui.ctrl_small_map.ForeGroundImage = nil
		main_room_list_ui.room_name2.Text = ""
		RoomInfoInit()
	end
	
	setup_ui_room_list_mode(main_room_list_ui.cbx_Mode)
	
	main_room_list_ui.room_name1.Text = lang:GetText("当前位置:")..lang:GetText(server_name).."-"..lang:GetText(channel_name)
	print("6230")
	ShowWitchList(my_game_mode)
	
	moshi_num = config.Moshi
	map_num = config.Map
	if map_num < 0 then
		map_num = 0
	end
	specialjob_num = config.Specialjob
	room_num = config.Roomnum
	roomstate_num = config.Roomstate
	
	--print(moshi_num)
	--print(map_num)
	--print(specialjob_num)
	
	main_room_list_ui.c_moshi:RemoveAll()
	for i=1, #setting_moshi do
		main_room_list_ui.c_moshi:AddItem(setting_moshi[i])
	end
	main_room_list_ui.c_moshi.Text = setting_moshi[moshi_num+1]
	
	main_room_list_ui.c_specialjob:RemoveAll()
	for i=1, #setting_specialjob do
		main_room_list_ui.c_specialjob:AddItem(setting_specialjob[i])
	end
	main_room_list_ui.c_specialjob.Text = setting_specialjob[specialjob_num+1]
	
	main_room_list_ui.c_roomnum:RemoveAll()
	for i=1, #setting_roomnum do
		main_room_list_ui.c_roomnum:AddItem(setting_roomnum[i])
	end
	main_room_list_ui.c_roomnum.Text = setting_roomnum[room_num+1]
	
	main_room_list_ui.c_roomstate:RemoveAll()
	for i=1, #setting_roomstate do
		main_room_list_ui.c_roomstate:AddItem(setting_roomstate[i])
	end
	main_room_list_ui.c_roomstate.Text = setting_roomstate[roomstate_num+1]
	
	if moshi_num <= 0 then
		main_room_list_ui.c_map.Enable = false
		main_room_list_ui.c_map.Text = lang:GetText("全部")
	else
		main_room_list_ui.c_map.Enable = true
		main_room_list_ui.c_map:RemoveAll()
		for i=1, #setting_map[moshi_num] do
			main_room_list_ui.c_map:AddItem(setting_map[moshi_num][i])
		end
		-- --print("moshi_num:"..moshi_num)
		-- --print("map_num:"..map_num)
		-- --print("map_num:"..setting_specialjob[moshi_num][map_num+1])
		main_room_list_ui.c_map.Text = setting_map[moshi_num][map_num+1]
	end
	
	list = main_room_list_ui.Play_List
	list:DeleteColumns()
	list:AddColumn("",40,"kAlignRightMiddle")
	list:AddColumn("",1,"kAlignRightMiddle")
	list:AddColumn("",30, "kAlignRightMiddle")
	list:AddColumn("",30, "kAlignLeftMiddle")
	list:AddColumn("",160, "kAlignCenterMiddle")
	
	MessageBox.CloseWaiter()
end

function StartNoviceGame()
	if state.Is_Novice_Game and novice_need_in == true then
		ispass = state:StartNovice()
		if ispass == true then
			novice_need_in = false
			state.Is_Novice_Game = false
		end
	end
end

function RoomInfoInit()
	local roomlist = main_room_list_ui.list_room_info
	local root = roomlist.RootItem
	roomlist:DeleteAll()
	
	local item = roomlist:AddItem(root,1)
	item.CanSelect = false
	item.ColCantSelect = true
	item.BGSkin = Skin.ListItemSkin_Single
	item:SetText(0,lang:GetText("房主名称:"))
	item:SetSubItemColor(0, lrv_colors[9])	
	
	item = roomlist:AddItem(root,2)
	item.CanSelect = false
	item.BGSkin = Skin.ListItemSkin_Double
	item.ColCantSelect = true
	item:SetText(0,lang:GetText("游戏模式:"))
	item:SetSubItemColor(0, lrv_colors[9])
	
	item = roomlist:AddItem(root,3)
	item.CanSelect = false
	item.BGSkin = Skin.ListItemSkin_Single
	item.ColCantSelect = true
	item:SetText(0,lang:GetText("胜利条件:"))
	item:SetSubItemColor(0, lrv_colors[9])	
	
	item = roomlist:AddItem(root,4)
	item.CanSelect = false
	item.BGSkin = Skin.ListItemSkin_Double
	item.ColCantSelect = true
	item:SetText(0,lang:GetText("复活时间:"))
	item:SetSubItemColor(0, lrv_colors[9])
	
	local roomlist = main_room_info_ui.list_room_info
	roomlist:AddColumn("",20,"kAlignLeftMiddle")
	roomlist:AddColumn("",140,"kAlignLeftMiddle")
	roomlist:AddColumn("",170,"kAlignLeftMiddle")
	
	local root = roomlist.RootItem     
	roomlist:DeleteAll()

	local item = roomlist:AddItem(root,1)
	item.CanSelect = false
	item.ColCantSelect = true
	item.BGSkin = Skin.ListItemSkin_Single
	item:SetText(0,"")
	item:SetText(1,lang:GetText("房主名称:"))
	item:SetSubItemColor(1, lrv_colors[9])
	item:SetText(2,"")
	
	item = roomlist:AddItem(root,2)
	item.CanSelect = false
	item.BGSkin = Skin.ListItemSkin_Double
	item.ColCantSelect = true
	item:SetText(0,"")
	item:SetText(1,lang:GetText("游戏模式:"))
	item:SetSubItemColor(1, lrv_colors[9])	
	item:SetText(2,"")
     
	item = roomlist:AddItem(root,3)
	item.CanSelect = false
	item.BGSkin = Skin.ListItemSkin_Single
	item.ColCantSelect = true
	item:SetText(0,"")
	item:SetText(1,lang:GetText("胜利条件:"))
	item:SetSubItemColor(1, lrv_colors[9])	
	item:SetText(2,"")
	
	item = roomlist:AddItem(root,4)
	item.CanSelect = false
	item.BGSkin = Skin.ListItemSkin_Double
	item.ColCantSelect = true
	item:SetText(0,"")
	item:SetText(1,lang:GetText("自动开始:"))
	item:SetSubItemColor(1, lrv_colors[9])
	item:SetText(2,"")
	
	item = roomlist:AddItem(root,5)
	item.CanSelect = false
	item.BGSkin = Skin.ListItemSkin_Single
	item.ColCantSelect = true
	item:SetText(0,"")
	item:SetText(1,lang:GetText("特殊职业战:"))
	item:SetSubItemColor(1, lrv_colors[9])
	item:SetText(2,"")
	
	item = roomlist:AddItem(root,6)
	item.CanSelect = false
	item.BGSkin = Skin.ListItemSkin_Double
	item.ColCantSelect = true
	item:SetText(0,"")
	item:SetText(1,lang:GetText("中途加入:"))
	item:SetSubItemColor(1, lrv_colors[9])
	item:SetText(2,"")
	
	item = roomlist:AddItem(root,7)
	item.CanSelect = false
	item.BGSkin = Skin.ListItemSkin_Single
	item.ColCantSelect = true
	item:SetText(0,"")
	item:SetText(1,lang:GetText("战力平衡:"))
	item:SetSubItemColor(1, lrv_colors[9])
	item:SetText(2,"")
	
	item = roomlist:AddItem(root,8)
	item.CanSelect = false
	item.BGSkin = Skin.ListItemSkin_Double
	item.ColCantSelect = true
	item:SetText(0,"")
	item:SetText(1,lang:GetText("复活时间:"))
	item:SetSubItemColor(1, lrv_colors[9])
	item:SetText(2,"")

	main_room_info_ui.ctrl_small_map.ForeGroundImage = Gui.Image("MapsAndBG/MapsIcon/lb_battlefield_map_lv0_b.dds",Vector4(0,0,0,0))
	
end

function RefreshRoomInfo(room_info_arg, room_option_arg)
	local room_info  = room_info_arg
	local room_option = room_option_arg

	if room_info == nil then
		room_info = state:GetSelfRoomInfo()
	end
     
	if room_option == nil then
		room_option = ptr_cast(room_info.option)
	end
     
	local roomlist = main_room_list_ui.list_room_info
	local root = roomlist.RootItem
	roomlist:DeleteAll()

	local item = roomlist:AddItem(root,1)
	item.CanSelect = false
	item.ColCantSelect = true
	item.BGSkin = Skin.ListItemSkin_Single
	item:SetText(0,lang:GetText("房主名称:"))
	item:SetSubItemColor(0, lrv_colors[9])	
	local hostname = room_info.host_name
	item:SetText(1,hostname)  
	     
	item = roomlist:AddItem(root,2)
	item.CanSelect = false
	item.BGSkin = Skin.ListItemSkin_Double
	item.ColCantSelect = true
	item:SetText(0,lang:GetText("游戏模式:"))
	item:SetSubItemColor(0, lrv_colors[9])	
	local game_mode = game_type(room_option.game_type) or ""
	item:SetText(1,game_mode)	
	
	item = roomlist:AddItem(root,3)
	item.CanSelect = false
	item.BGSkin = Skin.ListItemSkin_Single
	item.ColCantSelect = true
	item:SetText(0,lang:GetText("胜利条件:"))
	item:SetSubItemColor(0, lrv_colors[9])	
	local rule_value=0
	if room_option.game_type == "kTeam" or room_option.game_type == "kKnife" or room_option.game_type == "kItemMode" then
		rule_value = room_option.rule_value
		rule_value = rule_value .. lang:GetText("人")
	else
		rule_value = room_option.rule_value
		rule_value = rule_value .. lang:GetText("回合")
	end
	rule_value = rule_value or ""
	if id == 0 then
		item:SetText(1,"")
	else
		item:SetText(1,rule_value)  
	end
     
	item = roomlist:AddItem(root,4)
	item.CanSelect = false
	item.BGSkin = Skin.ListItemSkin_Double
	item.ColCantSelect = true
	item:SetText(0,lang:GetText("复活时间:"))
	item:SetSubItemColor(0, lrv_colors[9])
	if id ~= 0 then
		local round_rebirth_time_max = room_option.round_rebirth_time_max .. lang:GetText("秒")
		item:SetText(1,round_rebirth_time_max)
		if room_option.game_type ~= "kTeam" and room_option.game_type ~= "kKnife" and room_option.game_type ~= "kItemMode" then
			item:SetSubItemColor(1,ARGB(255,128,128,128))
			item:SetSubItemColor(1,ARGB(255,128,128,128))
		end
	else
		item:SetText(1,"")
	end
     
	main_room_list_ui.ctrl_small_map.ForeGroundImage = FindMapIcon(room_option.map_name).Icon_out
	main_room_list_ui.Tips.Visible = true
	main_room_list_ui.Tips.Skin = Gui.ButtonSkin
	{
		BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_chat_special_"..room_option.character_id..".dds", Vector4(0, 0, 0, 0)),
		TwinkleImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_chat_special_"..room_option.character_id.."_flash.dds", Vector4(0, 0, 0, 0)),
	}

	if is_knife == 1 then
		main_room_list_ui.knife_tips.Visible = true
	else
		main_room_list_ui.knife_tips.Visible = false
	end
	
	UpdateRoomInfo(room_info,room_option)
end

function ShowWitchList(WhitchMode)
	print("in ShowWitchList()")
	local room_count
	local room_num = 0

	if main_room_list_ui and main_room_list_ui.list then
		main_room_list_ui.Tips.Visible = false
		main_room_list_ui.knife_tips.Visible = false
		local list = main_room_list_ui.list
		list:DeleteAll()		
		room_count = state:GetRoomCount()
		--print("============room_count=",room_count)
		for i = 0, room_count - 1 do
			local room_info = state:GetRoomInfo(i)
			local type = game_type(room_info.option.game_type)
		     
			if WhitchMode == lang:GetText("全部") then
				type = lang:GetText("全部")
			end
			
			if WhitchMode == type and  map_show_name_of_key[room_info.option.map_name] ~= lang:GetText("新手关") then
				local root = list.RootItem
				local item = list:AddItem(root)
				item:SetText(0,room_info.id)
				item.FontSize = 14
				item.TextColor = lrv_colors[4]
				list:AddSubItem(item, "")
				list:AddSubItem(item, "")
				list:AddSubItem(item, room_info.option.name)
				list:AddSubItem(item, game_type(room_info.option.game_type))
				
				list:AddSubItem(item, "")
				item:SetIcon(5, Gui.Icon("weapon/"..character_Icon[room_info.option.character_id + 1]),Vector4(0, 0, 0, 0))
				list:AddSubItem(item, map_show_name_of_key[room_info.option.map_name])
				list:AddSubItem(item, string.format("%g / %g", room_info.client_count, room_info.option.client_count))
				if room_info.state == 1 then
					list:AddSubItem(item, lang:GetText("等待中"))
					item:SetSubItemColor(6, lrv_colors[2])
					item:SetSubItemColor(7, lrv_colors[2])
				elseif room_info.state == 2 then
					list:AddSubItem(item, lang:GetText("游戏中"))
					if room_info.client_count<room_info.option.client_count then
						item.TextColor = lrv_colors[4]
						item:SetSubItemColor(6, lrv_colors[1])
						item:SetSubItemColor(7, lrv_colors[1])
					else
						item.TextColor = lrv_colors[3]
					end
				end
				item.Tag = room_info
				--vip
				
				if room_info and (room_info.is_vip ~= 0 or room_info.net_bar_level ~= 0) then
					-- item:SetIcon(2, Gui.Icon("LobbyUI/vip/lb_"..room_info.is_vip.."_ico_"..room_info.net_bar_level..".dds"),Vector4(0, 0, 0, 0))
					item:SetIcon(2, Gui.Icon("LobbyUI/vip/vip/VIP_button_0"..room_info.is_vip.."_normal.dds"),Vector4(0, 0, 0, 0))
				end	

				local count = state:GetChannelCount()
				for i = 1, count do
					clientInfo = state:GetChannelClientInfo(i)
					if room_info.host_id == clientInfo.character_id then
						if clientInfo.is_gm == 1 then
							item:SetIcon(2, Gui.Icon("LobbyUI/GM.dds"),Vector4(0, 0, 0, 0))
						end
						break
					end
				end
				
			
				
				if room_info.option.use_password then
					item:SetIcon(1, Icons.RoomStatusIcons["PasswordN"])
					item:SetHoverIcon(1, Icons.RoomStatusIcons["PasswordA"])
				end
				
				if room_num == 0 and not SelectedroomID then
					list.SelectedItem = item
					SelectedroomID = room_info.id
				elseif SelectedroomID and SelectedroomID == room_info.id then
					list.SelectedItem = item
				end
				
				if room_num %2 == 0 then
					if room_info.is_vip ~= 0 then
						item.UserData = 1 --Skin.ListItemSkin_Single_RoomVip
					else
						item.UserData = 0 --Skin.ListItemSkin_Single
					end
				else
					if room_info.is_vip ~= 0 then
						item.UserData = 1 --Skin.ListItemSkin_Double_RoomVip
					else
						item.UserData = 0 --Skin.ListItemSkin_Double
					end
				end
				room_num=room_num+1
			end			
		end
				
		if state and now_Column >= 0 and now_Column <= 8 then
			list:SortColumn(now_Column, false, state:GetRoomListCompareFunc())
		else
			--print("state not valid when sorting rooms")
		end
		
		for i = 0, room_num do
			local item = list:DisplayIndexToItem(i)
			if item then
				if item.UserData == 0 or item.UserData == -1 then
					if i % 2 == 0 then
						item.BGSkin = Skin.ListItemSkin_Single
					else
						item.BGSkin = Skin.ListItemSkin_Double
					end
				elseif item.UserData == 1 then
					if i % 2 == 0 then
						item.BGSkin = Skin.ListItemSkin_Single_RoomVip
					else
						item.BGSkin = Skin.ListItemSkin_Double_RoomVip
					end
				end
			end
		end
	end
	
	
	
	if main_room_list_ui then 
		local RemainItem = 10-room_num
		local list = main_room_list_ui.list
		if RemainItem > 0 then
			for j=room_num,10 do
				local root = list.RootItem
				local item = list:AddItem(root)
				item.CanSelect = false
				if j %2 == 0 then
					item.BGSkin = Skin.ListItemSkin_Single
				else
					item.BGSkin = Skin.ListItemSkin_Double
				end
			end
		end
	end
end

function RefreshRoomList()
	local room_count
     
	if not main_room_list_ui.ctrl_Main_Window.Parent then
		return
	end
     
	--print("in RefreshRoomList()")
	if main_room_list_ui and main_room_list_ui.list then
		local list = main_room_list_ui.list
		list:DeleteAll()
		room_count = state:GetRoomCount()
		
		--print("====================room num = ",room_count)
		for i = 0, room_count - 1 do
			local room_info = state:GetRoomInfo(i)
			local root = list.RootItem
			local item = list:AddItem(root, room_info.id)
			list:AddSubItem(item, "")
			list:AddSubItem(item, room_info.option.name)
			list:AddSubItem(item, game_type(room_info.option.game_type))
			list:AddSubItem(item, map_show_name_of_key[room_info.option.map_name])
			list:AddSubItem(item, string.format("%g / %g", room_info.client_count, room_info.option.client_count))
			item.Tag = room_info
			
			if room_info.state == 1 then
				item:SetIcon(1, Icons.RoomStatusIcons["WaitingN"])
				item:SetHoverIcon(1, Icons.RoomStatusIcons["WaitingA"])
			elseif room_info.state == 2 then
				item:SetIcon(1, Icons.RoomStatusIcons["PlayingN"])
				item:SetHoverIcon(1, Icons.RoomStatusIcons["PlayingA"])
			elseif room_info.state == 3 then
				item:SetIcon(1, Icons.RoomStatusIcons["FullN"])
				item:SetHoverIcon(1, Icons.RoomStatusIcons["FullA"])
			end
			
			if room_info.client_count>=room_info.option.client_count then
				item:SetIcon(1, Icons.RoomStatusIcons["FullN"])
				item:SetHoverIcon(1, Icons.RoomStatusIcons["FullA"])
			end
			
			if i==0 then			
				list.SelectedItem = item
				SelectedroomItem = item
			end
			
			if i%2 == 0 then
				item.BGSkin = Skin.ListItemSkin_Single
			else
				item.BGSkin = Skin.ListItemSkin_Double
			end
		end
		
		list:Ready()
	end
	
	local RemainItem = 10-room_count
	local list = main_room_list_ui.list
    
     local root = list.RootItem
	if RemainItem > 0 then
		for j=room_count,10 do
			local item = list:AddItem(root)
       	
			item.CanSelect = false
			if j%2 == 0 then
				item.BGSkin = Skin.ListItemSkin_Single
			else
				item.BGSkin = Skin.ListItemSkin_Double
			end
		end
	end
end

function EnterRoom(id, cmd)
	if cmd then
		local room_count = state:GetRoomCount()
		for i = 0, room_count - 1 do
			local room_info = state:GetRoomInfo(i)
			if id == room_info.id then
				doEnterRoomWithRoomInfo( id, room_info )
				break
			end
		end
		return
	end

	if current_select_room_info then
		doEnterRoomWithRoomInfo( id, current_select_room_info )
	else
		MessageBox.ShowWaiter(lang:GetText("正在进入房间"))
		state:EnterRoom(id)
	end
end

function doEnterRoomWithRoomInfo( id, room_info )
	local room_option = ptr_cast( room_info.option )
	if room_option and room_option.use_password then
		L_PassWordBox.Show(gui, state, room_info, 1,room_option.use_password)
	else
		MessageBox.ShowWaiter(lang:GetText("正在进入房间"))
		state:EnterRoom(id)
	end
end

function ShowMatchUI(win_parent)
	match_Begin = true
	L_LobbyMain.HideAll()
	L_LobbyMain.current_chosse_main_page = 5
	L_LobbyMain.LobbyMainWin_Foot.btn_WarZone.PushDown = true
	L_LobbyMain.LobbyMainWin.video_button.Enable = false
	current_state = 3
	
	--创建界面
	
	if not match_window_ui then
		match_window_ui = Gui.Create(win_parent)(match_window)
	end
	
	MatchUiInit()
	FillMatchmain()
	match_window_ui.ctrl_Main_Window.Parent = win_parent
	MessageBox.CloseWaiter()
	L_LobbyMain.EnterRoomState(false)
end

function MatchUiInit()
	-- local ib_map = match_window_ui.ib_map	
	-- if ib_map ~= nil then
		-- setup_match_window_ui(ib_map, game_type_key[1])			
		--选取地图初始化设定
	-- end
	local list = match_window_ui.Fight_Team_Room_Player
	list:DeleteColumns()
	list:AddColumn("",50, "kAlignCenterMiddle")
	list:AddColumn(lang:GetText("头像"), 35, "kAlignCenterMiddle")
	list:AddColumn(lang:GetText("等"), 22,"kAlignRightMiddle")
	list:AddColumn(lang:GetText("级"), 22,"kAlignLeftMiddle")
	list:AddColumn(lang:GetText("玩家昵称"),160,"kAlignCenterMiddle")
	list:AddColumn(lang:GetText("状态"),56,"kAlignCenterMiddle")
	
	L_FightTeam.create_source_room_option = ptr_new ("Client.RoomOption")
	L_FightTeam.create_source_room_option.name = lang:GetText("匹配房")
	L_FightTeam.create_source_room_option.client_count = 4
	L_FightTeam.create_source_room_option.use_password = false
	L_FightTeam.create_source_room_option.character_id = L_WarZone.single_character_id[1]
	L_FightTeam.create_source_room_option.check_game_balance = false
	L_FightTeam.create_source_room_option.round_rebirth_time_max = L_WarZone.rebirth_time[1]
	L_FightTeam.create_source_room_option.game_type = "kTeam"
	L_FightTeam.create_source_room_option.map_name = ""
	L_FightTeam.create_source_room_option.rule_value = 1
	L_FightTeam.create_source_room_option.level_id = -1
	L_FightTeam.create_source_room_option.is_matching = 1 --==1是匹配房
	
	---------------增加右键菜单--------------------
	list.PopupMenu.Style = "Gui.MenuNew"
	list.EventRightClick = function(sender, e)
		list.PopupMenu:RemoveAll()
		local item = sender.MouseSelectedItem
		
		if not item then
			return
		end
		
		local name = item:GetText(4)
		local room_info=state:GetSelfRoomInfo()
		local room_option = ptr_cast(room_info.option)
		if host_character_info then
			if host_character_info.is_host == true then
				list.PopupMenu:AddItem(lang:GetText("关闭"))

			elseif host_character_info.is_host == false then
				if name == "" then
					return
				end
			end
		end
		
		if sender.PopupMenu and name ~= "" and host_character_info.is_host == true then
			sender.PopupMenu:Open()
			HideToolTipsWindow()
		end
	end
	
	list.PopupMenu.EventClick = function(sender, e)
		local item = ptr_cast(sender.Tag)
		local name = item:GetText(4)
		local pid = GetPidByNameInRoom(name)
		local room_info=state:GetSelfRoomInfo()
		local room_option = ptr_cast(room_info.option)

		local my_id = state:GetCharacterId()
		if host_character_info and host_character_info.character_id == my_id and my_id == pid then
			MessageBox.ShowError(lang:GetText("房主不可以关闭自己"))
			return
		end
		if host_character_info and host_character_info.is_host == true then
			if  sender.SelectedIndex == 0 then
				if Is_Auto_Start == false then
					state:ChangeSlotStatus(item.ID,0)
					state:ChangeSlotStatus(item.ID,1)
				end
			end
		end
	end
end

function FillMatchUi()
	if L_WarZone.matchTime_window_ui then
		return
	end
	local ltv = match_window_ui.Fight_Team_Room_Player 
	local flag = true	
	ltv:DeleteAll()
	local i = 1
	local state = ptr_cast(game.CurrentState)
	if not state then
		return
	end
	local client_count = state:GetClientCount()
	print("client_count1111111:",client_count)
	for j = 0, client_count-1 do
		local client_info = state:GetClientInfo(j)
		local sub_item = ltv:AddItem(ltv.RootItem,"")
		if j % 2 == 1 then
			sub_item.BGSkin = Skin.ListItemSkin_Double_Black
		else
			sub_item.BGSkin = Skin.ListItemSkin_Single_Black
		end
		sub_item.ID = client_info.id
		local status = ""
		local name = ""
		local iconVip = nil
		local iconN = nil
		local iconA = nil
		local iconH = nil
		local iconHead = nil
		local headIcon = nil
		local icon2,icon1 = nil,nil
		local isVip = client_info.is_vip
		local CardId = -1
		if client_info then	
			CardId = client_info.business_card
		end
		LoadCard(sub_item,1,j,CardId)
		if isVip == 1 then
			iconVip = Icons.PlayerStatusIcons["Vip"]
		elseif isVip == 2 then
			iconVip = Icons.PlayerStatusIcons["XunLeiVip"]
		end
		
		if isVip > 0 then
			iconVip = Gui.Icon("LobbyUI/vip/vip/VIP_button_0"..isVip.."_normalred.dds")
		end
		
		if client_info.icon ~= "null" then
				iconHead = Gui.Icon("LobbyUI/persionalInfo/HeadPic/lb_battlefield_icon"..client_info.icon..".dds")
		end
		
		if iconHead == nil then
			iconHead = Gui.Icon("LobbyUI/persionalInfo/HeadPic/lb_battlefield_icon01_b.dds")
		end
		local my_id = state:GetCharacterId()
		if (my_id == client_info.character_id) then
			host_character_info = client_info
			sub_item.IsSelfItem = true
		end
		-- iconHead = Icons.PlayerStatusIcons["Head"]
		
		-- if client_info.is_ready == 2 then
			-- iconN = Icons.PlayerStatusIcons["PlayingC"]
			-- iconA = Icons.PlayerStatusIcons["PlayingC"]
		-- elseif client_info.is_ready == 1 then
			-- iconN = Icons.PlayerStatusIcons["ReadyN"]
			-- iconA = Icons.PlayerStatusIcons["ReadyA"]
		-- end
		-- if client_info.client_uid == state.b_player_info.ownerclient_uid then
			-- iconN = Icons.PlayerStatusIcons["Host"]
			-- iconA = Icons.PlayerStatusIcons["Host"]
		-- end
		name = client_info.name
		sub_item:SetIcon(0, iconVip)
		sub_item:SetIcon(1, iconHead)
	
		sub_item:SetText(4, name)
		sub_item:SetIcon(5, iconN)
		sub_item:SetHoverIcon(5, iconA)
		FillLevel(client_info.level, client_info.exp, sub_item)
		
		local num = 5
		sub_item.LV_BackgroundImage = Gui.Image("LobbyUI/lv"..(math.floor((client_info.level - 1)/num)*num+1).."-"..(math.ceil(client_info.level/num)*num)..".dds", Vector4(0, 0, 0, 0), Vector4(0, 0, 1, 1))
		sub_item.LV_localtion = Vector2(84,0)
		sub_item.LV_Size = Vector2(46,42)
		-- sub_item.CheckVisible = false
		i = i + 1
		
	end

	if i < 9 then
		local j 
		for j = i ,9 do
			local sub_item = ltv:AddItem(ltv.RootItem)
			sub_item.CanSelect = false
			sub_item.ID = -1
			if j % 2 == 1 then
				sub_item.BGSkin = Skin.ListItemSkin_Single_Black
			else
				sub_item.BGSkin = Skin.ListItemSkin_Double_Black
			end
		end
	end
end

function setup_match_window_ui(ib, game_type)
	
	
	ib_lindex = ib.NumSkip
	ib_rindex = 1

	init_buf_map_match_key(ib, game_type)
	
	match_window_ui.m_PageDisplay.Text = ib_lindex/ib.NumSkip.."/"..math.ceil(map_key1_length/ib.NumSkip)
   
	local row = ib.DisplayRowAndCol.x
	local col = ib.DisplayRowAndCol.y
	
	what_map_name_select = map_key1[1]
	
	if game_type and what_map_name_select then
		match_window_ui.map_name = map_key1[1]
	    match_window_ui.level_id = map_id[game_type][what_map_name_select]
    end
	
	for r=1, row do
		for c=1, col do
    		local pic = ib:GetDisplayPicture(r,c)
    		pic.FrontImage = Gui.Image("MapsAndBG/MapsIcon/black_piece.dds", Vector4(0, 0, 0, 0))
			--pic.KeepAspect = true
            pic.BeStatic = true
            if r==1 then
				pic.Text = map_key1[c]
				pic.ForeGroundImage = FindMapIcon(pic.Text).Icon
				
           		if string.len(pic.Text) ~= 0 then
               		pic.BeStatic = false
           		end
			elseif r==2 then
				pic.Text = map_key2[c]
				pic.ForeGroundImage = FindMapIcon(pic.Text).Icon
				
				if string.len(pic.Text) ~= 0 then
					pic.BeStatic = false
				end
			end
			local temp_levelinfo_id = map_id[game_type][pic.Text]
			local temp_levelinfo = ptr_cast(game.CurrentState):GetLevelInfoById(temp_levelinfo_id)

			if temp_levelinfo then
				if temp_levelinfo.is_new ~= 0 then
					pic.IsNewImage = Gui.Image("MapsAndBG/MapsIcon/lb_battlefield_map_new.dds", Vector4(0, 0, 0, 0))
				else
					pic.IsNewImage = nil
				end
			end
			if pic.Text == "" then
				pic.ForeGroundImage = Gui.Image("MapsAndBG/MapsIcon/lb_battlefield_map_disabled.dds", Vector4(0, 0, 0, 0))
			end
			
			pic.EventClick = function(sender, e)
			    what_map_name_select = pic.Text
     			if  L_FightTeam.create_source_room_option then
          			L_FightTeam.create_source_room_option.map_name = pic.Text
          			L_FightTeam.create_source_room_option.level_id = map_id[L_FightTeam.create_source_room_option.game_type][L_FightTeam.create_source_room_option.map_name]
				end
				ib:AllPictureHL(false)
				pic.Highlighted=true
				
			end			
		end
	end
	
	function match_window_ui.m_Left.EventClick()	
		for i=1, ib.NumSkip do
			if ib_rindex > 1 then
				ib_rindex = ib_rindex - 1

				ib_lindex = ib_lindex - 1

				-- print("current left index:",ib_lindex)
				-- print("current right index:",ib_rindex)

				ib:RightBtnClick()

				local key1 = map_key1[ib_rindex]
				local key2 = map_key2[ib_rindex]

				local pic = ib:GetDisplayPicture(1,1)
				pic.Text = key1
			
				if string.len(pic.Text) == 0 then
					pic.BeStatic = true
				else
					pic.BeStatic = false
				end
				pic.ForeGroundImage =  FindMapIcon(pic.Text).Icon
					
				what_map_select(pic)

				pic = ib:GetDisplayPicture(2, 1)
				pic.Text = key2

				if string.len(pic.Text) == 0 then
					pic.BeStatic = true
				else
					pic.BeStatic = false
				end
			
				pic.ForeGroundImage = FindMapIcon(pic.Text).Icon
				what_map_select(pic)
			end
		end
		match_window_ui.m_PageDisplay.Text = ib_lindex/ib.NumSkip.."/"..math.ceil(map_key1_length/ib.NumSkip)
	end
    
	function match_window_ui.m_Right.EventClick()
		--print("right btn click")
    	local TepNum = ib.NumSkip*math.ceil(map_key1_length/ib.NumSkip)
   		for i=1, ib.NumSkip do
			if ib_lindex < TepNum then				
				ib_lindex = ib_lindex + 1
				ib_rindex = ib_rindex + 1

				-- print("current left index:",ib_lindex)
				-- print("current right index:",ib_rindex)

				local key1 = map_key1[ib_lindex]
				local key2 = map_key2[ib_lindex]

				local pic = ib:GetDisplayPicture(1, col+1)
				pic.Text = key1
				
				if string.len(pic.Text) == 0 then
					pic.BeStatic = true
				end
				pic.ForeGroundImage = FindMapIcon(pic.Text).Icon
				
				what_map_select(pic)

				pic = ib:GetDisplayPicture(2, col+1)
				pic.Text = key2
				
				if string.len(pic.Text) == 0 then
					pic.BeStatic = true
				end
	               
				pic.ForeGroundImage = FindMapIcon(pic.Text).Icon

                what_map_select(pic)
				ib:LeftBtnClick()
			end
		end
		
		match_window_ui.m_PageDisplay.Text = ib_lindex/ib.NumSkip.."/"..math.ceil(map_key1_length/ib.NumSkip)
	end    
	ib.LeftBtn.Visible=false
	ib.RightBtn.Visible=false
end

--显示频道列表
function ShowChannelList(win_parent)
	if state.is_fight_team_server then
		return
	end
	if L_FightTeam.is_in_fight_ui then
		return
	end
	if L_FightTeam.is_in_invite then
		return
	end
	if IsMatchServer() then
		-- state.LeaveChannel()
		return
	end
	if IsMatchServer1() then
	-- state.LeaveChannel()
		return
	end
	print("=================L_WarZone ShowChannelList()")
	L_LobbyMain.HideAll()
	L_LobbyMain.current_chosse_main_page = 5
	L_LobbyMain.LobbyMainWin_Foot.btn_WarZone.PushDown = true
	L_LobbyMain.LobbyMainWin.video_button.Enable = false
	--创建界面
	
	if not main_channel_list_ui then
		main_channel_list_ui = Gui.Create(win_parent)(channel_list_window)
--		main_channel_list_ui.ctrl_AD_Window_child:DeleteAllImage()
--		main_channel_list_ui.ctrl_AD_Window_child:AddFrame(Gui.Image("LobbyUI/WarZone/lb_server_ad006.dds", Vector4(0, 0, 0, 0)))
		current_state = 1
		local list = main_channel_list_ui.list
		list:DeleteColumns()
		list:AddColumn(lang:GetText("序号"),64,"kAlignCenterMiddle")
		list:AddColumn(lang:GetText("频道名称"),232,"kAlignCenterMiddle")
		list:AddColumn(lang:GetText("连接人数"),292,"kAlignCenterMiddle")
		list:AddColumn(lang:GetText("状态"),69,"kAlignCenterMiddle")
		
		function list.EventSelectItemChange(sender)
			local item = sender.SelectedItem
			
			if item then
				local info = ptr_cast(item.Tag)
				current_select_channel_info = info
				channel_id = info.id
				channel_name = info.name
				SelectedChannelID = info.id
				L_Friends.channel_id = info.id
			else
				current_select_channel_info = nil
				channel_id = 0
				channel_name = ""
			end
	
			main_channel_list_ui.btn_enter.Enable = (channel_id > 0)
		end
		
		function list.EventDoubleClick(sender, e)
			local item = sender.SelectedItem
			local info = ptr_cast(item and item.Tag or nil)
	          
			if item and info then
				MessageBox.ShowWaiter(lang:GetText("正在进入频道"))
				e.Handled = true
				n = info.id
				--print(lang:GetText("进入频道:"), n)
				state.last_channel_id = n
				state:ConnectChannel(n)
			end
		end
		
		function main_channel_list_ui.btn_enter.EventClick()  
			if current_select_channel_info then    
				MessageBox.ShowWaiter(lang:GetText("正在进入频道"))
				channel_id = current_select_channel_info.id
				state:ConnectChannel(channel_id)
			end
		end
		
	else
		main_channel_list_ui.ctrl_Main_Window.Parent = win_parent
		current_state = 1
	end
	--print("server_name:"..server_name)
	main_channel_list_ui.server_name1.Text = lang:GetText("当前位置:")..lang:GetText(server_name)
	RefreshChannelList()
	MessageBox.CloseWaiter()
end

--更新频道列表
function RefreshChannelList()	
	if not main_channel_list_ui then
		return
	end
	
	if not main_channel_list_ui.ctrl_Main_Window.Parent then
		return
	end
	
	--print("in RefreshChannelList()")
	local list = main_channel_list_ui.list
	local root = list.RootItem
	local ChannelNum = 0
	list:DeleteAll()
	
    is_choose_channel = false
	
	for i = 0, state:GetChannelCount() - 1 do
    	local info = state:GetChannelInfo(i)
		local item = list:AddItem(root, info.id)
		if info.online_max == 0 then
			item.CanSelect = false
		end
        
		list:AddSubItem(item, lang:GetText(info.name))
		local channelProportionN = Gui.ProportionIcon("LobbyUI/WarZone/lb_common_expbar01_bg.dds", "LobbyUI/WarZone/lb_common_expbar01_content.dds", Vector4(8,8,8,8), Vector4(0,0,0,0))
		channelProportionN.Proportion = info.online_count/info.online_max
		channelProportionN.BarPadding = Vector4(5,8,5,9),
		item:SetIcon(2, channelProportionN)
		item.FontSize = 16
        item.TextColor = lrv_colors[4]
		if info.online_max == 0 then
			item:SetText(3, lang:GetText("关闭"))
			item.TextColor = lrv_colors[3]
			
			local serverProportionN = Gui.ProportionIcon("LobbyUI/WarZone/lb_common_expbar01_bg.dds", "LobbyUI/WarZone/lb_bar_content_04.dds", Vector4(8,8,8,8), Vector4(0,0,0,0))
			serverProportionN.Proportion = info.online_count/info.online_max
			serverProportionN.BarPadding = Vector4(5,6,5,6),
			item:SetIcon(2, serverProportionN)
        elseif info.online_count/info.online_max > 0.8 then
			item:SetText(3, lang:GetText("爆满"))
			item:SetSubItemColor(3, lrv_colors[5])
			
			local serverProportionN = Gui.ProportionIcon("LobbyUI/WarZone/lb_common_expbar01_bg.dds", "LobbyUI/WarZone/lb_bar_content_01.dds", Vector4(8,8,8,8), Vector4(0,0,0,0))
			serverProportionN.Proportion = info.online_count/info.online_max
			serverProportionN.BarPadding = Vector4(5,6,5,6),
			item:SetIcon(2, serverProportionN)
		elseif info.online_count/info.online_max > 0.6 then
			item:SetText(3, lang:GetText("火爆"))
			item:SetSubItemColor(3, lrv_colors[6])
			
			local serverProportionN = Gui.ProportionIcon("LobbyUI/WarZone/lb_common_expbar01_bg.dds", "LobbyUI/WarZone/lb_bar_content_02.dds", Vector4(8,8,8,8), Vector4(0,0,0,0))
			serverProportionN.Proportion = info.online_count/info.online_max
			serverProportionN.BarPadding = Vector4(5,6,5,6),
			item:SetIcon(2, serverProportionN)
		elseif info.online_count/info.online_max > 0.3 then
			item:SetText(3, lang:GetText("轻松"))
			item:SetSubItemColor(3, lrv_colors[7])
			
			local serverProportionN = Gui.ProportionIcon("LobbyUI/WarZone/lb_common_expbar01_bg.dds", "LobbyUI/WarZone/lb_bar_content_03.dds", Vector4(8,8,8,8), Vector4(0,0,0,0))
			serverProportionN.Proportion = info.online_count/info.online_max
			serverProportionN.BarPadding = Vector4(5,6,5,6),
			item:SetIcon(2, serverProportionN)
		else
            item:SetText(3, lang:GetText("通畅"))
			item:SetSubItemColor(3, lrv_colors[8])
			
			local serverProportionN = Gui.ProportionIcon("LobbyUI/WarZone/lb_common_expbar01_bg.dds", "LobbyUI/WarZone/lb_bar_content_04.dds", Vector4(8,8,8,8), Vector4(0,0,0,0))
			serverProportionN.Proportion = info.online_count/info.online_max
			serverProportionN.BarPadding = Vector4(5,6,5,6),
			item:SetIcon(2, serverProportionN)
		end
		
		item.Tag = info
        
		if i == 0 and not SelectedChannelID then
			list.SelectedItem = item
			SelectedChannelID = info.id
			--print("room_num == 0,SelectedroomID=",SelectedroomID)
		elseif SelectedChannelID and SelectedChannelID == info.id then
			list.SelectedItem = item
		end
	   
	    if is_choose_channel == false and info.online_max ~= 0 and info.online_count/info.online_max < 0.8 and novice_need_in == true then
			novice_channel_id = info.id
			is_choose_channel = true
        end
	   
		if i %2 == 0 then
			item.BGSkin = Skin.ListItemSkin_Single
		else
			item.BGSkin = Skin.ListItemSkin_Double
		end
	   
		ChannelNum = ChannelNum +1
	end
    
	local RemainItem = 11-ChannelNum
    	
	if RemainItem > 0 then
		for j=ChannelNum,11 do
			local item = list:AddItem(root)
			item.CanSelect = false
			if j %2 == 0 then
				item.BGSkin = Skin.ListItemSkin_Single
			else
				item.BGSkin = Skin.ListItemSkin_Double
			end
		end
	end
end

--显示服务器列表
function ShowServerList(win_parent)
	if state.is_fight_team_server then
		--print("11111111111111111111chenji")
		L_FightTeam.FillTeam() --战队战结束更新状态
		return
	end
	print("=================L_WarZone ShowServerList()")
	L_LobbyMain.HideAll()
	L_LobbyMain.current_chosse_main_page = 5
	L_LobbyMain.LobbyMainWin_Foot.btn_WarZone.PushDown = true
	L_LobbyMain.LobbyMainWin.video_button.Enable = false
	--创建界面
	if not main_server_list_ui then
		main_server_list_ui = Gui.Create(win_parent)(server_list_window)
		current_state = 0
		
		main_server_list_ui.server_list.AutoScrollMinSize = Vector2(0,564)
		showTime()
	 else 
		main_server_list_ui.ctrl_Main_Window.Parent = win_parent
		current_state = 0
	end
	
	RefreshServerList()
end

function showTime()
	local temp = {}
	local ID
	local args = {pid = ptr_cast(game.CurrentState):GetCharacterId(),t = 1,page = 1}
	rpc.safecall("server_remark",args,
	function(data)
		for i = 1,#data.servers do
			temp[i] = data.servers[i]
			ID = temp[i].id
			for j = 0, state:GetServerCount() - 1 do
				local info = state:GetServerInfo(j,true)
				if info.isnovice == 6 and info.id == ID then
					if  temp[i].remark == 0 then
						-- main_server_list_ui.time_prompt.Text =""
						-- main_server_list_ui.time_prompt1.Text =""
						main_server_list_ui.time_prompt_1.Text =""
						main_server_list_ui.time_prompt1_1.Text =""
					else
						-- main_server_list_ui.time_prompt.Text = temp[i].remark
						-- main_server_list_ui.time_prompt1.Text = temp[i].remark
						main_server_list_ui.time_prompt_1.Text = temp[i].remark
						main_server_list_ui.time_prompt1_1.Text = temp[i].remark
					end
				elseif info.isnovice == 4 and info.id == ID then
					if  temp[i].remark == 0 then
						-- main_server_list_ui.time_prompt2.Text =""
						-- main_server_list_ui.time_prompt3.Text =""
						main_server_list_ui.time_prompt2_1.Text =""
						main_server_list_ui.time_prompt3_1.Text =""
					else
						-- main_server_list_ui.time_prompt2.Text = temp[i].remark
						-- main_server_list_ui.time_prompt3.Text = temp[i].remark
						main_server_list_ui.time_prompt2_1.Text = temp[i].remark
						main_server_list_ui.time_prompt3_1.Text = temp[i].remark
					end
				end
			end
		end
	end)
end


function DeleteVideo(index)
	local s = ptr_cast(game.CurrentState,"Client.StateLobby")
	
	if s then
		s:ReplayDelete(video_list[index])
		video_list = {}
		UpdataVideoList()
	end
end

function Play(index)
	index = index + 1
	--print("index = "..index)
	-- --print("video_list[index]"..video_list[index])
	if replay_video_window_ui.list_video_info.SelectedItem == nil then
		return
	end
	
	if video_list[index]==nil or string.len(video_list[index]) == 0 then
		return
	end
	local s = ptr_cast(game.CurrentState,"Client.StateLobby")
	
	if s then
		local ret = s:ReplayOpen(video_list[index])
		print("ret ="..ret)
		if ret == 0 then
			s:ReplayPlay(video_list[index])
		else
			MessageBox.ShowWithTimer(3,lang:GetText("文件格式错误"))
		end
	end
end

function ShowVideo()
	replay_video_window = ModalWindow.GetNew()
	replay_video_window.root.Size = Vector2(520,520)
	replay_video_window.AllowEscToExit = true
	replay_video_window_ui.ctrl_replay_video_window.Parent = replay_video_window.root
	replay_video_cancel_window_ui.Cancel.Parent = replay_video_window.root
	local list = replay_video_window_ui.list_video_info
	
	list:AddColumn("",475,"kAlignLeftMiddle")
	
	UpdataVideoList()
end

function UpdataVideoList()
	local list = replay_video_window_ui.list_video_info
	local X = replay_video_window_ui.list_video_info.Size.x
	local FX = 9
	
	local root = list.RootItem
	local replay_info = nil
	list:DeleteAll()
	local replay_time,replay_mode,replay_map = "","",""
	local replay_single_mode = 1
	local s = ptr_cast(game.CurrentState,"Client.StateLobby")
						
	if s then
		s:UpdateReplayList()
		count = s:GetReplayCount()
	end
			
	if count < 7 then
		count = 7
	end	
	for i = 1, count do
		local replayname = ""
		local item = list:AddItem(root)
		local space_num
		local year,month,day,hour,minite = "","","","",""
		if i % 2 == 1 then
			item.BGSkin = Skin.ListItemSkin_Video_a
		else
			item.BGSkin = Skin.ListItemSkin_Video_b
		end
		replayname = s:GetReplayName(i - 1)
		video_list[i] = replayname
		replay_info = L_PersonalInfo.Split(replayname,"_")
		if replay_info then
			replay_time = replay_info[1]
			replay_mode = replay_info[2]
			replay_map = replay_info[3]
			if replay_info[4] then
				replay_single_mode = tonumber(replay_info[4]) + 1
			else
				replay_single_mode = 1
			end
		end
		
		if replay_time == nil or replay_mode == nil or replay_map == nil then
			item.CanSelect = false
		else
		
			if replay_time then
				replay_time = L_PersonalInfo.Split(replay_time,"-")
				year = replay_time[1]
				month = replay_time[2]
				day = replay_time[3]
				hour = replay_time[4]
				minite = replay_time[5]
			end
			replay_time = lang:GetText("时间:").." "..year..lang:GetText("年")..month..lang:GetText("月")..day..lang:GetText("日")..hour..lang:GetText("时")..minite..lang:GetText("分")
			replay_mode = lang:GetText("模式:").." "..game_type_table[replay_mode]
		
			space_num = (X - string.len(replay_time) * FX - string.len(replay_mode) * FX)/FX
			
			for i =1,	space_num do
				replay_time = replay_time.." "
			end
			replay_time = replay_time..replay_mode
			item:SetText(0,replay_time)
			local game_mode = lang:GetText("特殊职业战:")..character[replay_single_mode]
			replay_map = lang:GetText("地图:").." "..replay_map
			space_num = (X - string.len(replay_map) * FX - string.len(game_mode) * FX)/FX
			
			for i =1,	space_num do
				replay_map = replay_map.." "
			end
			replay_map = replay_map..game_mode
			item.SecLineTextColunm = 0
			item.SecLineText = replay_map
			item.SecLineFontSize = 16
			item.SecLineColor = ARGB(255,214,207,199)
		end
	end
	
	local rest = nil
	
	if count < 7 then
		rest = 7 - count
	
		for i = 1,rest do
			local replayname = nil
			local item = list:AddItem(root)
			
			if i % 2 == 1 then
				item.BGSkin = Skin.ListItemSkin_Video_a
			else
				item.BGSkin = Skin.ListItemSkin_Video_b
			end
		end
	
	end
end

--更新服务器列表
function RefreshServerList()	
	if not main_server_list_ui then
		--print("no main_server_list_ui")
		return
	end
	if not  main_server_list_ui.ctrl_Main_Window.Parent then
		return
	end
	state = ptr_cast(game.CurrentState)
	
		local num1 = 1
		local num2 = 3
	
		for i = 0, state:GetServerCount() - 1 do
			local info = state:GetServerInfo(i,true)
			if info.isnovice == 7 then
				server_id = info.id				
				main_server_list_ui.server_name_1_1.Text = info.name
				main_server_list_ui.server_name_shadow_1_1.Text = info.name				
			elseif info.isnovice == 4 then
				server_id = info.id
				main_server_list_ui.server_name_4_1.Text = info.name
				main_server_list_ui.server_name_shadow_4_1.Text = info.name
				if info.Channelcount ~= 0 then
				
					main_server_list_ui.tiaotiaole1.Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/pipei/4p.dds", Vector4(20, 20, 20, 20)),
						HoverImage = Gui.Image("LobbyUI/pipei/lb_battlefield_serverlist_8_disabled88888.dds", Vector4(20, 20, 20, 20)),
						
					}
				end
			elseif info.isnovice == 6 then
				server_id = info.id
				main_server_list_ui.server_name_3_1.Text = info.name
				main_server_list_ui.server_name_shadow_3_1.Text = info.name
				if info.Channelcount ~= 0 then
					main_server_list_ui.zhenbasai1.Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/pipei/3p.dds", Vector4(20, 20, 20, 20)),
						HoverImage = Gui.Image("LobbyUI/pipei/lb_battlefield_serverlist_8_disabled88888.dds", Vector4(20, 20, 20, 20)),
					}
				end
				
			elseif  info.isnovice < 2  then
				if L_LobbyMain.PersonalInfo_data.level >= info.nMinLevel and L_LobbyMain.PersonalInfo_data.level <= info.nMaxLevel  then			
					temp = info.id
				end
			end
		end
	
	
	
	
	for i = 0, state:GetServerCount() - 1 do
		local info = state:GetServerInfo(i,true)
		if info.isnovice ~= 6 then
			--item.Tag = info
			if info.isnovice == 1 and info.online_count/info.online_max < 0.8 and novice_server_id == nil then
				novice_server_id = info.id
			end	    
			
			-- list:AddSubItem(item, lang:GetText(info.name))
			
			-- item.TextColor = lrv_colors[4]
			-- if info.online_max == 0 then
				-- item:SetText(2, lang:GetText("关闭"))
				-- item.TextColor = lrv_colors[3]
		-- --[[		
				-- local serverProportionN = Gui.ProportionIcon("LobbyUI/WarZone/lb_common_expbar01_bg.dds", "LobbyUI/WarZone/lb_bar_content_04.dds", Vector4(8,8,8,8), Vector4(0,0,0,0))
				-- serverProportionN.Proportion = info.online_count/info.online_max
				-- serverProportionN.BarPadding = Vector4(5,6,5,6),
				-- item:SetIcon(2, serverProportionN)
				-- ]]
			-- elseif info.online_count/info.online_max > 0.8 then
				-- item:SetText(2, lang:GetText("爆满"))
				-- item:SetSubItemColor(2, lrv_colors[5])
			-- --[[
				-- local serverProportionN = Gui.ProportionIcon("LobbyUI/WarZone/lb_common_expbar01_bg.dds", "LobbyUI/WarZone/lb_bar_content_01.dds", Vector4(8,8,8,8), Vector4(0,0,0,0))
				-- serverProportionN.Proportion = info.online_count/info.online_max
				-- serverProportionN.BarPadding = Vector4(5,6,5,6),
				-- item:SetIcon(2, serverProportionN)
				-- ]]
			-- elseif info.online_count/info.online_max > 0.6 then
				-- item:SetText(2, lang:GetText("火爆"))
				-- item:SetSubItemColor(2, lrv_colors[6])
			-- --[[	
				-- local serverProportionN = Gui.ProportionIcon("LobbyUI/WarZone/lb_common_expbar01_bg.dds", "LobbyUI/WarZone/lb_bar_content_02.dds", Vector4(8,8,8,8), Vector4(0,0,0,0))
				-- serverProportionN.Proportion = info.online_count/info.online_max
				-- serverProportionN.BarPadding = Vector4(5,6,5,6),
				-- item:SetIcon(2, serverProportionN)
				-- ]]
			-- elseif info.online_count/info.online_max > 0.3 then
				-- item:SetText(2, lang:GetText("轻松"))
				-- item:SetSubItemColor(2, lrv_colors[7])
		-- --[[		
				-- local serverProportionN = Gui.ProportionIcon("LobbyUI/WarZone/lb_common_expbar01_bg.dds", "LobbyUI/WarZone/lb_bar_content_03.dds", Vector4(8,8,8,8), Vector4(0,0,0,0))
				-- serverProportionN.Proportion = info.online_count/info.online_max
				-- serverProportionN.BarPadding = Vector4(5,6,5,6),
				-- item:SetIcon(2, serverProportionN)
				-- ]]
			-- else
				-- item:SetText(2, lang:GetText("通畅"))
				-- item:SetSubItemColor(2, lrv_colors[8])
		-- --[[		
				-- local serverProportionN = Gui.ProportionIcon("LobbyUI/WarZone/lb_common_expbar01_bg.dds", "LobbyUI/WarZone/lb_bar_content_04.dds", Vector4(8,8,8,8), Vector4(0,0,0,0))
				-- serverProportionN.Proportion = info.online_count/info.online_max
				-- serverProportionN.BarPadding = Vector4(5,6,5,6),
				-- item:SetIcon(2, serverProportionN)
		-- ]]--
			-- end

			-- item.Tag = info
			-- if info.isnovice == 1 and info.online_count/info.online_max < 0.8 and novice_server_id == nil then
				-- novice_server_id = info.id
			-- end	    
			
			-- if i == 0 and not SelectedServerID then
				-- list.SelectedItem = item
				-- SelectedServerID = info.id
				-- --print("room_num == 0,SelectedroomID=",SelectedroomID)	
			-- elseif SelectedServerID and SelectedServerID == info.id then
				-- list.SelectedItem = item
			-- end
			
			-- if ServerNum %2 == 1 then
				-- item.BGSkin = Skin.ListItemSkin_Double
			-- else
				-- item.BGSkin = Skin.ListItemSkin_Single
			-- end
			
			-- ServerNum = ServerNum + 1
		-- -- end
		end
	end	
	
	--local RemainItem = 11 - ServerNum
    	
	-- if RemainItem > 0 then
		-- for j = ServerNum, 11 do
			-- local item = list:AddItem(root)
			-- item.CanSelect = false
			-- if j%2 == 1 then
				-- item.BGSkin = Skin.ListItemSkin_Double
			-- else
				-- item.BGSkin = Skin.ListItemSkin_Single
			-- end
		-- end
	-- end	
end


function EnterServer()
	if is_fight_id then
		MessageBox.ShowWithConfirm(lang:GetText("战队战频道无法直接进入\n你可以在战队界面进行战队战匹配\n参加战队战可获得战队贡献，享受战队技能"))
		return
	end
	if is_source_id then
		MessageBox.ShowWithConfirm(lang:GetText("资源争夺战频道无法直接进入"))
		return
	end
	if is_pipei_id and L_LobbyMain.PersonalInfo_data.level < 5 then
		MessageBox.ShowWithConfirm(lang:GetText("你未满5级，不可匹配"))
		return
	end
	if is_Channelcount_id and IsMatchServer() then
		MessageBox.ShowWithConfirm(lang:GetText("匹配频道目前无法进入"))
		return
	end
	if server_id > 0 then
	
		MessageBox.ShowWaiter(lang:GetText("正在进入服务器"))
		state:EnterServer(server_id)
	end
end

function EnterNoviceServer()
	-- novice_server_id=1
   
	if novice_server_id and novice_need_in == true then
		if state then
			MessageBox.ShowWaiter(lang:GetText("正在进入服务器"))
			state:EnterServer(novice_server_id)
		end
	end
end

function Match_player()
	state = ptr_cast(game.CurrentState)
	if state then	
		srate.EventMatchRoom = function()
			
		end
	end
end

function initStateCallBack()
	state = ptr_cast(game.CurrentState)
	if state then	
		state.EventLeaveRoom = function()
			if state.is_fight_team_server then
				if state.source_is_create then
					state.is_fight_team_server = false
					state.source_is_create = false
					L_FightTeam.HideSourceFight()
					L_FightTeam.HideSource_Success()
					print("1111111111111111111111111111111111")
					MessageBox.ShowWithTimer(3, lang:GetText("非常遗憾, 您被请出了房间!"))
					state:LeaveChannel()
					L_FightTeam.create_source_room_option = nil
					return
				end
			end
			if IsMatchServer() and matchTime_window_ui == nil then
				state:LeaveChannel()
				return
			elseif IsMatchServer1() and matchTime_window == nil then
				state:LeaveChannel()
				return
			end
			if host_character_info then
				host_character_info = NullPtr
				host_character_info = nil
			end
			if not state.is_fight_team_server then
				room_ui.list_red.SelectedItem = nil
				room_ui.list_blue.SelectedItem = nil
				room_ui.ctrl_btn.Visible = false
			end
			in_room_first = true
			if L_LobbyMain.current_chosse_main_page == 5 then
				ShowRoomList(root_ui)
			end
			
			L_LobbyMain.EnterRoomState(true)
			is_Look = false
			is_specialjob = true
			specialjob_id = 0
		end
		
		state.EventUpdateLevelList1 = function()
	     	UpdateLevelList ()
		end
	     
		function state.EventRoomOptionChanged()
			print("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$EventRoomOptionChanged......")
			--print("L_LobbyMain.current_chosse_main_page=",L_LobbyMain.current_chosse_main_page)
			if L_LobbyMain.current_chosse_main_page == 5 then
				--print("EventRoomOptionChanged......")
	     		MessageBox.CloseWaiter()
				if not IsMatchServer() and not IsMatchServer1() then
					ShowRoomWindow(root_ui)
				end
	     	else
				--print("￥￥￥￥￥￥￥￥￥￥")
				if not state.is_fight_team_server then
					EventRoomClientListChangedCallBack()
				end
	     	end    	
		end
		
	    state.EventRoomAutoStart = function(sender, e)
			--print("AUTO START")
			if host_character_info and (host_character_info.ready or host_character_info.is_host) and Is_Auto_Start == false then
				Is_Auto_Start = true
				L_LobbyMain.Timer_control_ui.Timer.Visible = true
				L_LobbyMain.Timer_control_ui.Timer:SetAnimationTimer("Timer",sender.autostarttime)
				L_LobbyMain.Timer_control_ui.Timer:ReStart()
				L_LobbyMain.Timer_control_ui.Timer:StartAnimation()
			end
		end
		 
		 
		state.EventCreateRoomFailed = function(sender, e)
		print("进入房间失败进入房间失败进入房间失败进入房间失败")
			MessageBox.CloseWaiter()
			MessageBox.ShowError(L_Text.ErrorText[e.Ret])
			Show(L_LobbyMain.LobbyMainWin_Boddy.LobbyMainWin_Boddy_Root)
		end

		state.EventEnterRoomFailed = function(sender, e)
			-- print(lang:GetText("进入房间失败"))
			if (state.is_fight_team_server and L_Text.ErrorText[e.Ret] == lang:GetText("当前房间不可进或密码错误")) or IsMatchServer() or IsMatchServer1() then
				MessageBox.ShowError(L_Text.ErrorText[e.Ret],
									function()
										CommonUtility.cumulate = true
									 end)
				state:LeaveChannel()
				match_time_ui.b_exit.Enable = true
				state.source_is_create = false
				L_FightTeam.defense_success = false
				L_FightTeam.is_in_invite = false
				state.is_fight_team_server = false
				L_FightTeam.source_pipei_success = false
				state.Is_in_invite = false
				state.Is_in_invite1 = false
				return
			end
			MessageBox.CloseWaiter()
			if CommonUtility.cumulate == false then
				return
			end
			CommonUtility.cumulate = false
			print("xxxxxxxxxxxxxxxx")
			MessageBox.ShowError(L_Text.ErrorText[e.Ret],function()
															CommonUtility.cumulate = true
														 end)
			if not state.is_fight_team_server then
				return
			end
			L_FightTeam.HideSourceFight()		
			local state = ptr_cast(game.CurrentState)
			if state then
				state.source_is_create = false
				for i = 2 , 16 do
					state:ChangeSlotStatus(i,0)
				end
				state:LeaveChannel()
				L_FightTeam.create_source_room_option = nil
			end
		end
        
		--服务器列表更新消息
		state.EventUpdateServerList = function(sender, e)
			RefreshServerList()
		end
		
		--频道列表更新消息
		state.EventUpdateChannelList = function(sender, e)
			RefreshChannelList()
		end
	     
		--新手关更新消息
		function state.EventUpdateNovice()
			StartNoviceGame()  	  
		end
	     
		--房间列更新消息
		function state.EventRoomListChanged()
		print("7458")
			if not state.is_fight_team_server then
			   if not IsMatchServer()  and not IsMatchServer1()then
					ShowWitchList(my_game_mode)  
				end
			end
		end
		 
		--房间内信息更新消息
		function state.EventRoomClientListChanged()
			if not state.is_fight_team_server then
				EventRoomClientListChangedCallBack()
				if IsMatchServer()  then
					FillMatchUi()
				elseif IsMatchServer1() then
					FillAutomaticMatchUi()
				end
			end
			if state.source_is_create then
				if L_FightTeam.is_in_invite then
					L_FightTeam.is_in_invite = false
					state:Ready(true)
				end
				local room_info = state:GetSelfRoomInfo()
				if room_info.state == 2 then
					return
				end
				if not L_FightTeam.defense_success then
					L_FightTeam.ShowSourceFight()
				end
				L_FightTeam.FillSourceZhanduiRoom()
				L_FightTeam.FillSourceZhanduiList()
				L_FightTeam.FillSource_Success_Room()
			end
		end
	    
		--进入服务器成功返回消息
		state.EventEnterServer = function(sender, e)
			--print("in EventEnterServer")
			if e.Ret == 0 then
			print("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx")
				Hide()
				local address = game.ClientAddress
				server_name = address.server_name
				
				server_id = address.server_id
				print("server_id2 = " , server_id)
				if not state.is_fight_team_server then
					if  IsMatchServer() then
						ShowMatchUI(root_ui)
					elseif IsMatchServer1() then
						ShowAutomaticMatchUI(root_ui)
					else
						ShowChannelList(root_ui)
					end
				else
					local t_level = nil
					local flag = false
					if L_FightTeam.team_data and L_FightTeam.team_data[18] then
						t_level = L_FightTeam.team_data[18]
					end
					if t_level then
						for i = 0, state:GetChannelCount() - 1 do
							local info = state:GetChannelInfo(i)
							if t_level <= info.max_level and t_level >= info.min_level then
								if info.online_count < 150 then
									battle_channel_id = info.id
									flag = true
									break
								end
							end
						end
						if not flag then
							for i = 0, state:GetChannelCount() - 1 do
								local info = state:GetChannelInfo(i)
								if info.max_level == 0 or info.min_level == 0 then
									if info.online_count < 150 then
										battle_channel_id = info.id
										flag = true
										break
									end
								end
							end
						end
						if not flag then
							for i = 0, state:GetChannelCount() - 1 do
								local info = state:GetChannelInfo(i)
								if t_level <= info.max_level and t_level >= info.min_level then
									if info.online_count < info.online_max then
										battle_channel_id = info.id
										flag = true
										break
									end
								end
							end
						end
						if not flag then
							for i = 0, state:GetChannelCount() - 1 do
								local info = state:GetChannelInfo(i)
								if info.max_level == 0 or info.min_level == 0 then
									if info.online_count < info.online_max then
										battle_channel_id = info.id
										flag = true
										break
									end
								end
							end
						end
						if flag and battle_channel_id then
							state:ConnectChannel(battle_channel_id)
						else
						print("battle_channel_idbattle_channel_idbattle_channel_id",battle_channel_id)
							MessageBox.ShowWithTimer(3,lang:GetText("资源争夺战频道已满"))
							state:LeaveServer()
							state.source_is_create = false
							create_source_room_option = nil		
							state.is_fight_team_server = false
							state.battle_is_create = false
							battle_ready = false
						end
					end
				end
				
				if novice_channel_id and novice_need_in == true then
					state.Is_Novice_Game = true
                    state:ConnectChannel(novice_channel_id)
                end
			else
				novice_need_in = false
				MessageBox.CloseWaiter()
				MessageBox.ShowError(L_Text.ErrorText[e.Ret])
			end
		end
		
		--断开连接返回频道列表
		state.EventCancelChannel = function(sender, e)
			if create_room_ui then
				create_room_ui.ctrl_Main_Window.Parent = nil
			end
			if not state.is_fight_team_server then
				GetBack(3)
				GetBack(2)
			end
		end
		
		--进入频道成功返回消息
		state.EventEnterChannel = function(sender, e)
			--chatWindow:Whisper("lvrui")
			if e.Ret == 0 then
				Hide()
				if not state.is_fight_team_server then
					if IsMatchServer() and not is_invite then
						ShowMatchUI(root_ui)
					elseif IsMatchServer1() and not is_invite1 then
						ShowAutomaticMatchUI(root_ui)			
				    else
						ShowRoomList(root_ui)
					end
				end	
				-- FillPlayList()
			else
				novice_need_in = false
				MessageBox.CloseWaiter()
				MessageBox.ShowError(L_Text.ErrorText[e.Ret])
			end			
		end
		
		state.EventChannelEnter= function(sender, e)
			print("EventChannelEnter1111111111111111111111111")
			Hide()		
			L_LobbyMain.CreatChannllist()
			if not state.is_fight_team_server  then
				if  IsMatchServer() and state.Is_in_invite ~= true and isKickByRoom ~= true then
					L_FightTeam.create_source_room_option = ptr_new ("Client.RoomOption")
					L_FightTeam.create_source_room_option.name = lang:GetText("匹配房")
					L_FightTeam.create_source_room_option.client_count = 4
					L_FightTeam.create_source_room_option.use_password = false
					L_FightTeam.create_source_room_option.character_id = L_WarZone.single_character_id[1]
					L_FightTeam.create_source_room_option.check_game_balance = false
					L_FightTeam.create_source_room_option.round_rebirth_time_max = L_WarZone.rebirth_time[1]
					L_FightTeam.create_source_room_option.game_type = "kTeam"
					L_FightTeam.create_source_room_option.map_name = ""
					L_FightTeam.create_source_room_option.rule_value = 1
					L_FightTeam.create_source_room_option.level_id = -1
					L_FightTeam.create_source_room_option.is_matching = 1 --==1是匹配房
					state:CreateRoom(L_FightTeam.create_source_room_option) 
					-- MessageBox.ShowWaiter(lang:GetText("正在创建房间,请稍候..."))
				elseif 	IsMatchServer1() and state.Is_in_invite1 ~= true and isKickByRoom1 ~= true then
					L_FightTeam.create_source_room_option = ptr_new ("Client.RoomOption")
					L_FightTeam.create_source_room_option.name = lang:GetText("个人匹配")
					L_FightTeam.create_source_room_option.client_count = 4
					L_FightTeam.create_source_room_option.use_password = false
					L_FightTeam.create_source_room_option.character_id = L_WarZone.single_character_id[1]
					L_FightTeam.create_source_room_option.check_game_balance = false
					L_FightTeam.create_source_room_option.round_rebirth_time_max = L_WarZone.rebirth_time[1]
					L_FightTeam.create_source_room_option.game_type = -1
					L_FightTeam.create_source_room_option.map_name = ""
					L_FightTeam.create_source_room_option.rule_value = 1
					L_FightTeam.create_source_room_option.level_id = -1
					L_FightTeam.create_source_room_option.is_matching = 1 --==1是匹配房
					state:CreateRoom(L_FightTeam.create_source_room_option) 
				else
					ShowRoomList(root_ui)
					if main_room_list_ui then
						main_room_list_ui.Tex_room.Text = "/c"
						SpeakType(main_room_list_ui.BTN_Tex_sta,"/Channel",main_room_list_ui.Tex_room)
					end
				end
				if isKickByRoom == true then
					state:LeaveChannel()
					if match_window_ui then
						match_window_ui.ctrl_Main_Window.Parent = nil
						match_window_ui = nil
					end
					ShowServerList(root_ui)
					isKickByRoom = false
				end	
				if isKickByRoom1 == true then
					state:LeaveChannel()
					if automatic_match_ui then
						automatic_match_ui.ctrl_Main_Window.Parent = nil
						automatic_match_ui = nil
					end
					ShowServerList(root_ui)
					isKickByRoom1 = false
				end	
			else
				if state.battle_is_create and not L_FightTeam.battle_pipei_success then
					state:CreateRoom(L_FightTeam.create_fightteam_room_option)
					MessageBox.ShowWaiter(lang:GetText("正在创建房间,请稍候..."))
				end
				if state.source_is_create and not L_FightTeam.is_in_invite then
				
					state:CreateRoom(L_FightTeam.create_source_room_option)
					MessageBox.ShowWaiter(lang:GetText("正在创建房间,请稍候..."))
				end
				if L_FightTeam.is_Edit_create_room then
					MessageBox.ShowWaiter(lang:GetText("正在创建房间,请稍候..."))
					state:CreateRoom(L_FightTeam.create_source_room_option)
				end
			end
		end
	     
		state.EventRoomSlotChanged = function()
			if not state.is_fight_team_server then
				EventRoomSlotChangedCallBack()
				DisplayRoomInfo()
			end
		end
		
		state.EventOnQuitInGame = function()
			if state.is_fight_team_server then
				return
			end
			if IsMatchServer() or server_id == 1 or IsMatchServer1() then
				if host_character_info then
					host_character_info = NullPtr
					host_character_info = nil
				end
				if matchTime_window_ui then
					matchTime_window_ui = nil
				end
				if matchTime_window then
					matchTime_window = nil
				end
				state:LeaveRoom()
				return
			end
			current_state = 3
             
            if state then
				if host_character_info then
					host_character_info = NullPtr
					host_character_info = nil
				end
				if matchTime_window_ui then
					matchTime_window_ui = nil
				end
				if matchTime_window then
					matchTime_window = nil
				end
				state:LeaveRoom()
			end
            GetBack(3)
		end
		
		state.EventKickedInRoom = function()
			if state.is_fight_team_server then
				return
			end
            MessageBox.ShowWithTimer(3, lang:GetText("非常遗憾, 您被请出了房间!"))
			if L_LobbyMain.current_chosse_main_page == 5 then
				GetBack(3)
			end
            current_state = 2
			if state then
				if host_character_info then
					host_character_info = NullPtr
					host_character_info = nil
				end
				if matchTime_window_ui then
					matchTime_window_ui = nil
				end
				if matchTime_window then
					matchTime_window = nil
				end
				state:LeaveRoom()
				if IsMatchServer() then
					isKickByRoom = true
				elseif IsMatchServer1() then
					isKickByRoom1 = true
				end
			end
		end
		
		
		state.EventIdleKicked = function()
			if state.is_fight_team_server then
				return
			end
			if match_Begin == true then
				MessageBox.ShowWithTimer(5, lang:GetText("非常遗憾, 由于闲置时间过长\n您被请出了房间!"))
				match_Begin = false
				return
			end
			if matching_Begin then
				MessageBox.ShowWithTimer(5, lang:GetText("非常遗憾, 由于闲置时间过长\n您被请出了房间!"))
				matching_Begin = false
				return
			end
            MessageBox.ShowWithTimer(5, lang:GetText("非常遗憾, 由于闲置时间过长\n您被请出了房间!"))
		
            if L_LobbyMain.current_chosse_main_page == 5 then
				GetBack(3)
			end 
            current_state = 2
            if state then
				if host_character_info then
					host_character_info = NullPtr
					host_character_info = nil
				end
				if matchTime_window_ui then
					matchTime_window_ui = nil
				end
				if matchTime_window then
					matchTime_window = nil
				end
				state:LeaveRoom()
			end
		end
		
		
		--进入房间成功返回消息
		state.EventEnterRoomSuccess = function()
			print("in EventEnterRoomSuccess")
			if not state.is_fight_team_server then

					ShowRoomWindow(root_ui)
					room_ui.MesPanel_room:ClearLines()
					room_ui.MesPanel_room:AddLineNew(lang:GetText("您可以在此与房间内玩家聊天"),0)
					room_ui.MesPanel_room:DirtyLines(true)
					room_ui.Tex_room.Text = "/c"
					SpeakType(room_ui.BTN_Tex_sta,"/room",room_ui.Tex_room)
				if IsMatchServer() then
					ShowMatchUI(root_ui)
					match_window_ui.Tex_room.Text = "/c"
					SpeakType(match_window_ui.BTN_Tex_sta,"/room",match_window_ui.Tex_room)
				elseif IsMatchServer1() then
					ShowAutomaticMatchUI(root_ui)
				end
				-- end

			else
				if state.battle_is_create then
					if not L_FightTeam.battle_pipei_success then	
						for i = 9 , 14 do
							state:ChangeSlotStatus(i,0)
						end
					end
				-- elseif state.source_is_create then
					-- for i = 9 , 16 do
						-- state:ChangeSlotStatus(i,0)
					-- end
				end				
			end
			local room_info = state:GetSelfRoomInfo()
			local room_option = ptr_cast(room_info.option)
			room_option.group_match = false
			if L_FightTeam.is_Edit_create_room then
				state:StartGame()
				return
			end
			if L_FightTeam.battle_pipei_success then
				if room_info.state == 2 then
					print(lang:GetText("1111111开始游戏"))
					state:EnterGame()
				else
					print(lang:GetText("1111111准备游戏"))
					state:Ready(true)
				end
				Is_Auto_Start = false
				return
			end
			if L_FightTeam.source_pipei_success then
				if room_info.state == 2 then
					state:EnterGame()
				else
					state:Ready(true)
				end
				Is_Auto_Start = false
				return
			end
			
			Is_Auto_Start = false
			MessageBox.CloseWaiter()
		end
	     
		---------游戏开始-------------
		state.EventGameBegin = function(sender, e)
			print("in EventGameBegin")
			L_WarZone.HideToolTipsWindow() 
			if e.Ret == 0 then
				MessageBox.CloseWaiter()
				ModalWindow.CloseAll()
			else
			print("---------游戏开始--------------")
				MessageBox.CloseWaiter()
				ModalWindow.CloseAll()
                MessageBox.ShowError(L_Text.ErrorText[e.Ret])
				print("e.Ret:"..e.Ret)
				print(L_Text.ErrorText[e.Ret])
			end
			L_FightTeam.VS.shenji_1:CleanAll()
			L_FightTeam.VS.shenji_2:CleanAll()
			L_FightTeam.battle_pipei_success = false
			L_FightTeam.source_pipei_success = false
			L_FightTeam.defense_success = false
			state.source_is_create = false
			L_FightTeam.HideSource_Success()
			L_FightTeam.HideSourceFight()
			L_FightTeam.create_source_room_option = nil
			if L_FightTeam.is_Edit_create_room then
				L_FightTeam.is_Edit_create_room = false
				-- state.is_fight_team_server = false
			end
			if matchTime_window_ui then
				matchTime_window_ui:Close()
				matchTime_window_ui = nil
				
			end
			if matchTime_window then
				matchTime_window:Close()
				matchTime_window = nil
				
			end
			if match_window_ui then
				match_window_ui.ctrl_Main_Window.Parent = nil
				match_window_ui = nil
			end
			if automatic_match_ui then
				automatic_match_ui.ctrl_Main_Window.Parent = nil
				automatic_match_ui = nil
			end
			leaveGame = true
		end
		
		---------游戏准备--------------
		state.EventGameReady = function(sender, e)
			--print("EventGameReady########", e.Ret)
			if e.Ret == 0 then
				-- if L_FightTeam.battle_pipei_success then
					
				-- else
					MessageBox.CloseWaiter()
				-- end
			else
			print("---------游戏准备--------------")
				MessageBox.CloseWaiter()
                MessageBox.ShowError(L_Text.ErrorText[e.Ret])
			end
			L_FightTeam.battle_pipei_success = false
			L_FightTeam.source_pipei_success = false
		end
		
		---------自动开始状态取消-------------
		state.EventRoomAutoStartCancel = function(sender, e)
			--print("in EventRoomAutoStartCancel")
			Is_Auto_Start = false
		end
		
		state.EventBattleRoomChange = function(sender, e)
			if L_FightTeam.fightteam_fight_window then
				L_FightTeam.FillZhanduiList()
				L_FightTeam.FillZhanduiRoom()
				L_LobbyMain.current_chosse_main_page = 2
				L_FightTeam.is_in_invite = false
			end	
		end
		
		state.EventSaveTiaoZhan = function(sender, e)
			L_FightTeam.tiaozhan_battle_info[state.zhihuisuo_num] = state.b_player_info
			state.zhihuisuo_num = state.zhihuisuo_num+1
		end
		
		state.EventFillTiaoZhan = function(sender, e)
			-- if e.Ret < 7 then
				-- L_FightTeam.zhihuisuo_ui.m_Right.Enable = false
			-- end
			L_FightTeam.FillTiaoZhan()
		end
		
		state.EventSaveZhihuisuo = function(sender, e)
			local Tep = state.b_player_info
			L_FightTeam.three_battle_info[state.zhihuisuo_num] = Tep
			L_FightTeam.three_battle_player_info[state.zhihuisuo_num] = {}
			for i = 1 , 6 do
				L_FightTeam.three_battle_player_info[state.zhihuisuo_num][i] = state:GetBattlePlayerInfo(i-1)
			end
			state.zhihuisuo_num = state.zhihuisuo_num+1
		end
		
		state.EventFillZhihuisuo = function(sender, e)
			if e.Ret < 3 then
				L_FightTeam.zhihuisuo_ui.m_Right.Enable = false
			else
				L_FightTeam.zhihuisuo_ui.m_Right.Enable = true
			end
			for i = 1,3 do
				if i <= e.Ret then
					L_FightTeam.zhihuisuo_ui["b_join"..i].Enable = true
					L_FightTeam.FillThreeZhanduiRoom(i,true)
				else
					L_FightTeam.zhihuisuo_ui["b_join"..i].Enable = false
					L_FightTeam.FillThreeZhanduiRoom(i,false)
				end	
			end
		end
		
		state.EventCancelMatch = function(sender, e)
			if IsMatchServer() then
				HideMatch_Time()
			elseif IsMatchServer1() then
				HideMatching_Time()
			end
		end
		state.EventMatch= function(sender, e)
			if  IsMatchServer() then
				if needShowMatch_Time then
					match_time_ui.b_exit.Enable = true
				else
					match_time_ui.b_exit.Enable = false
				end
				ShowMatch_Time()
				needShowMatch_Time = false
			elseif IsMatchServer1() then
				if needShowMatching_Time then
					match_time.b_exit.Enable = true
				else
					match_time.b_exit.Enable = false
				end
				ShowMatching_Time()
				needShowMatching_Time = false
			end	
		end
		state.EventBattleGroupSearching = function(sender, e)
			if e.Ret == 1 then
				L_FightTeam.time_num = 0
				for i = 9 , 14 do
					state:ChangeSlotStatus(i,1)
				end
				L_FightTeam.ShowBattleTime()
				L_FightTeam.battle_time_ui.change_time:CleanAll()
				L_FightTeam.battle_time_ui.ten_num.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("InGameUI/countdown_number.dds", Vector4(0, 0, 0, 0),Vector4(0, 0, 116/1160, 1))}
				L_FightTeam.battle_time_ui.one_num.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("InGameUI/countdown_number.dds", Vector4(0, 0, 0, 0),Vector4(0, 0, 116/1160, 1))}
				L_FightTeam.battle_time_ui.change_time:AddTime(1)
			elseif e.Ret == 0 then
				L_FightTeam.HideBattleTime()
				L_FightTeam.battle_time_ui.change_time:CleanAll()
			end
		end
		
		state.EventBattleGroupGameStart = function(sender, args)
			rpc.safecall("team_info_get_list", {tida = args.team1, tidb = args.team2},L_FightTeam.FillVS)
			if args.change_room == 0 then
				if L_FightTeam.fightteam_fight_ui and L_FightTeam.fightteam_fight_ui.b_pipei.Text == lang:GetText("匹配对手") then
					L_FightTeam.fightteam_fight_ui.StartGame:CleanAll()
					L_FightTeam.fightteam_fight_ui.StartGame:AddTime(3)
				end	
			elseif args.change_room == 1 then
				state:AutoChangeRoomWithPassword(args.server_id,args.channel_id,args.room_id,"sdfgde")
				L_FightTeam.battle_pipei_success = true
			end
		end
		
		state.NotifyBattleGroupInvite = function(sender, args)
			local temp = args.Group_id
			local name = args.name
			-- if config.Invite == true then
				-- chatWindow:RefuseInvite(Name)
				-- return
			-- end
			if L_WarZone.is_novice == true then
				return
			end
			if L_WarZone.host_character_info and L_WarZone.host_character_info.is_host == false and L_WarZone.host_character_info.ready then			
				return
			end
			if L_LobbyMain.On_Invite_State == false then
				return
			end
			-- if L_FightTeam.team_data == nil then
				-- print("00000000000000000000333333333")
				-- return
			-- end
			if not state.is_fight_team_server then
				if battle_invite == false then
					battle_invite = true
					MessageBox.ShowWithTwoButtons(name..lang:GetText("邀请你加入战队战"),lang:GetText("加入"),lang:GetText("取消"),
					function()
						L_FightTeam.is_in_invite = true
						state.is_fight_team_server = true
						L_FightTeam.invite_group = temp
						FightGetBack(current_state)
						battle_invite = false
					end,
					function()
						battle_invite = false
					end
					)
				end
			end
		end
		
		state.NotifyBattleGroupKick = function(sender, e)
			L_FightTeam.HideFightTeam()
			L_FightTeam.HideBattleTime()
			-- state.is_fight_team_server = false
			state.battle_is_create = false
			if L_FightTeam.battle_ready == true then
				state:Ready(false)
				state:BattleGroupReady()
				L_FightTeam.battle_ready = false
			end
			L_FightTeam.fightteam_fight_ui.b_exit.Enable = true
			state:LeaveChannel()
			-- state:BattleGroupLeave(my_battle_info.battlegroup_id)
			MessageBox.ShowWithConfirm(lang:GetText("队长解散了本小队"))
		end
		
		state.EventLeaveServer = function(sender, e)
			server_id = 0
			L_FightTeam.fightteam_fight_ui.b_exit.Enable = true
			if L_FightTeam.is_in_fight_ui then
				L_LobbyMain.current_chosse_main_page = 2
				lg:SetLobbyModules(2)
				gui:PlayAudio("kUIA_CLOSE_UI")
				-- L_FightTeam.is_in_fight_ui = false
				if L_LobbyMain.LobbyMainWin_Boddy then
					L_FightTeam.Show(L_LobbyMain.LobbyMainWin_Boddy.LobbyMainWin_Boddy_Root)
				end
			end
			
			if L_FightTeam.is_in_invite then
				L_LobbyMain.current_chosse_main_page = 2
				lg:SetLobbyModules(2)
				gui:PlayAudio("kUIA_CLOSE_UI")
				if L_LobbyMain.LobbyMainWin_Boddy then
					L_FightTeam.Show(L_LobbyMain.LobbyMainWin_Boddy.LobbyMainWin_Boddy_Root)
				end
				
				-- state.is_fight_team_server = true
				-- local state = ptr_cast(game.CurrentState)
				-- state:GetBattleGroupJoin(L_FightTeam.invite_group)
			end
		end
		
		state.EnterFightRoomError = function(sender, e)
			L_FightTeam.HideFightTeam()
			MessageBox.ShowWithTimer(2,lang:GetText("无法进入该房间,请稍后再试"))
			state.is_fight_team_server = false
			L_FightTeam.is_in_invite = false
		end
		
		state.EnterFightRoomSuccess = function(sender, e)
			L_FightTeam.ShowFightTeam()
		end
		
		state.EnterFightCreatrRoomSuccess = function(sender, e)
			L_FightTeam.ShowFightTeam()
		end
		
		state.EnterSourceRoomError = function(sender, e)
			state:LeaveChannel()
			state.source_is_create = false
			L_FightTeam.defense_success = false
			L_FightTeam.is_in_invite = false
			state.is_fight_team_server = false
			-- L_WarZone.FightGetBack(L_WarZone.current_state)
			L_FightTeam.source_pipei_success = false
		end
	end
end

function FillPlayList()
	if not IsMatchServer() and not IsMatchServer1() then
		main_room_list_ui.lab_timer_Channl_list:Show()
		Set_Channl_Search_state(false)
		local Add = 1
		local item = nil
		local ltv = main_room_list_ui.Play_List
		local root = ltv.RootItem
		ltv:DeleteAll()
		local state = ptr_cast(game.CurrentState)
		itemCount = state:GetChannelClientCount()
		channl_list_page_total = math.ceil(state.channl_list_total_count/10)
		if channl_list_page_total < 1 then
			channl_list_page_total = 1
		end
		channl_list_page = math.floor(state.channl_list_start/10) + 1
		for i=0, itemCount-1 do
			if i > 9 then
				break
			end
			local info = state:GetChannelClientInfo(i)
	--		if info.name ~= L_LobbyMain.PersonalInfo_data.name then
				item = ltv:AddItem(root,nil)
				item.ID = info.character_id
				item.CanSelect = true
				if Add % 2 == 0 then
					item.BGSkin = Skin.ListItemSkin_Single_02
				else
					item.BGSkin = Skin.ListItemSkin_Double_02
				end
				Add = Add + 1
				item.FontSize = 14
				item.TextColor = ARGB(255, 226, 215, 205)
				item.HighlightTextColor = ARGB(255, 226, 215, 205)
				if info.is_vip > 0 then
					item:SetIcon(0, Gui.Icon("LobbyUI/vip/vip/VIP_button_0"..info.is_vip.."_normal.dds"),Vector4(0, 0, 0, 0))
				end
				item:SetText(4,info.name)
				FillLevel(info.level, -1, item,"e")
				local num = 5
				item.LV_BackgroundImage = Gui.Image("LobbyUI/lv"..(math.floor((info.level - 1)/num)*num+1).."-"..(math.ceil(info.level/num)*num)..".dds", Vector4(0, 0, 0, 0), Vector4(0, 0, 1, 1))
				item.LV_localtion = Vector2(55,0)
				item.LV_Size = Vector2(30,24)
	--		end
		end
		
		if Add < 11 then
			for i = Add , 10 do
				item = ltv:AddItem(root,nil)
				item.CanSelect = false
				if Add % 2 == 0 then
					item.BGSkin = Skin.ListItemSkin_Single_02
				else
					item.BGSkin = Skin.ListItemSkin_Double_02
				end

				Add = Add + 1
			end
		end
		fileChannlListPage()
	end
end

function FileSearchList(data)
	if data then
		Search_rpc_data = nil
		Search_rpc_data = data
		if data.list then
			channl_list_page_total = math.ceil(table.getn(data.list)/10)
			if channl_list_page_total < 1 then
				channl_list_page_total = 1
			end
		end
		FillPlayList_search(1)
	end
end

function FillPlayList_search(page)
	if Search_rpc_data == nil then
		return
	end
	if page > channl_list_page_total then
		page = channl_list_page_total
	end
	if page < 1 then
		page = 1
	end
	channl_list_page = page
	local Add = 1
	local item = nil
	local ltv = main_room_list_ui.Play_List
	local root = ltv.RootItem
	ltv:DeleteAll()
	for i=1 + 10 * (page - 1), 10 * page do
		if i > table.getn(Search_rpc_data.list) then
			break
		end
		if Search_rpc_data.list[i][3] then
			item = ltv:AddItem(root,nil)
			item.ID = Search_rpc_data.list[i][1]
			item.CanSelect = true
			if Add % 2 == 0 then
				item.BGSkin = Skin.ListItemSkin_Single_02
			else
				item.BGSkin = Skin.ListItemSkin_Double_02
			end
			Add = Add + 1
			item.FontSize = 14
			L_Friends.SetVipIcon(item,Search_rpc_data.list[i][6],0,Search_rpc_data.list[i][9],nil,Search_rpc_data.list[i][8])
			item.TextColor = ARGB(255, 226, 215, 205)
			item.HighlightTextColor = ARGB(255, 226, 215, 205)
			item:SetText(4,Search_rpc_data.list[i][3])
			FillLevel(Search_rpc_data.list[i][2], -1, item,"e")
			local num = 5
			item.LV_BackgroundImage = Gui.Image("LobbyUI/lv"..(math.floor((Search_rpc_data.list[i][2] - 1)/num)*num+1).."-"..(math.ceil(Search_rpc_data.list[i][2]/num)*num)..".dds", Vector4(0, 0, 0, 0), Vector4(0, 0, 1, 1))
			item.LV_localtion = Vector2(55,0)
			item.LV_Size = Vector2(30,24)
		end
	end
	
	if Add < 11 then
		for i = Add , 10 do
			item = ltv:AddItem(root,nil)
			item.CanSelect = false
			if Add % 2 == 0 then
				item.BGSkin = Skin.ListItemSkin_Single_02
			else
				item.BGSkin = Skin.ListItemSkin_Double_02
			end

			Add = Add + 1
		end
	end
	fileChannlListPage()
end

function FillLevel(level, exp, item,res,item1,item2)
	local levelunit = level%10 + 1
	local leveldec = (level -levelunit + 1) /10
	local percent
	
	if level == 80 or exp == -1 then
		percent = 1
	else
		percent = (exp - L_LobbyMain.LevelInfo_rpc_data[level][2]) / (L_LobbyMain.LevelInfo_rpc_data[level + 1][2] - L_LobbyMain.LevelInfo_rpc_data[level][2]) 
		percent = string.format("%.2f", percent)
	end
	if res then
		if res == "b" then
			percent =(percent*21 + 2)/24
		elseif res == "c" then
			percent =(percent*21 + 6)/33
		elseif res == "d" then
			percent =(percent*21 + 10)/42
		elseif res == "e" then
			percent =(percent*21 + 6)/32
		end
	else
		percent =(percent*21 + 10)/42
	end
	levelunit = math.ceil(levelunit)
	if res then
		icon2 =  Gui.Icon("LobbyUI/WarZone/lb_summary_number_7"..res..".dds", Vector4(0, 0, 0, 0),Vector4((levelunit-1)/10,1-percent,(levelunit)/10,1))
		icon1 =  Gui.Icon("LobbyUI/WarZone/lb_summary_number_6"..res..".dds", Vector4(0, 0, 0, 0),Vector4((levelunit-1)/10,0,(levelunit)/10,1))
	else
		icon2 =  Gui.Icon("LobbyUI/WarZone/lb_summary_number_7d.dds", Vector4(0, 0, 0, 0),Vector4((levelunit-1)/10,1-percent,(levelunit)/10,1))
		icon1 =  Gui.Icon("LobbyUI/WarZone/lb_summary_number_6d.dds", Vector4(0, 0, 0, 0),Vector4((levelunit-1)/10,0,(levelunit)/10,1))
	end
	
	
	leveldec = leveldec + 1
	item.Tag = client_info
	if item1 == 2 then
		item:SetIcon(2, icon1,icon2)
	else
		item:SetIcon(3, icon1,icon2)
	end	
	if res then
		icon2 =  Gui.Icon("LobbyUI/WarZone/lb_summary_number_7"..res..".dds", Vector4(0, 0, 0, 0),Vector4((leveldec-1)/10,1-percent,(leveldec)/10,1))
		icon1 =  Gui.Icon("LobbyUI/WarZone/lb_summary_number_6"..res..".dds", Vector4(0, 0, 0, 0),Vector4((leveldec-1)/10,0,(leveldec)/10,1))
	else
		icon2 =  Gui.Icon("LobbyUI/WarZone/lb_summary_number_7d.dds", Vector4(0, 0, 0, 0),Vector4((leveldec-1)/10,1-percent,(leveldec)/10,1))
		icon1 =  Gui.Icon("LobbyUI/WarZone/lb_summary_number_6d.dds", Vector4(0, 0, 0, 0),Vector4((leveldec-1)/10,0,(leveldec)/10,1))
	end
	if item2 == 1 then
		item:SetIcon(1, icon1,icon2)
	else
		item:SetIcon(2, icon1,icon2)
	end	
end

--快速开始
function QuickStart()
	local room_count = state:GetRoomCount()
	local RoomId = nil
	local Flag = 0
	-- for i = 0, room_count - 1 do
		-- room_info = state:GetRoomInfo(i)
		-- if (room_info.state == 2) and (room_info.option.use_password ~= true) and (room_info.option.client_count > room_info.client_count) and (room_info.client_count >= 8) and room_info.option.can_join_on_playing then
			-- state:EnterRoom(room_info.id)
			-- Flag = 1
			-- break
		-- elseif (room_info.state == 2) and (room_info.option.use_password ~= true) and (room_info.option.client_count > room_info.client_count) and room_info.option.can_join_on_playing then
			-- RoomId = room_info.id
		-- end
	-- end
	-- if (Flag == 0) and (RoomId ~= nil) then
		-- state:EnterRoom(RoomId)
	-- elseif (Flag == 0) and (RoomId == nil) then
		-- MessageBox.ShowWithConfirm(lang:GetText("没有找到合适的房间"))
	-- end
	local all_RoomId = {}
	local RoomId_num = 1
	for i = 0, room_count - 1 do
		room_info = state:GetRoomInfo(i)
		--print("character_level:"..room_info.character_level)
		--print("L_LobbyMain.PersonalInfo_data.level"..L_LobbyMain.PersonalInfo_data.level)
		if (moshi_num <= 0 or (moshi_num > 0 and game_type(room_info.option.game_type) == setting_moshi[moshi_num+1])) and (map_num <= 0 or (map_num > 0 and map_show_name_of_key[room_info.option.map_name] == setting_map[moshi_num][map_num+1])) and (specialjob_num <= 0 or (specialjob_num > 0 and room_info.option.character_id == specialjob_num)) and (room_num <= 0 or (room_num > 0 and room_info.option.client_count - room_info.client_count == tonumber(setting_roomnum[room_num+1]))) and (roomstate_num <= 0 or (roomstate_num > 0 and room_info.state == roomstate_num)) then
			-- if (room_info.option.use_password ~= true) and (room_info.option.client_count > room_info.client_count) and room_info.option.can_join_on_playing  and (L_LobbyMain.PersonalInfo_data.level <= room_info.character_level+2 and L_LobbyMain.PersonalInfo_data.level >= room_info.character_level-2) then
				-- state:EnterRoom(room_info.id)
				-- Flag = 1
				-- break
			-- elseif (room_info.option.use_password ~= true) and (room_info.option.client_count > room_info.client_count) and room_info.option.can_join_on_playing then
				-- RoomId = room_info.id
			-- end
			if (room_info.option.use_password ~= true) and (room_info.option.client_count > room_info.client_count) and ((room_info.state == 1 and not room_info.option.can_join_on_playing) or room_info.option.can_join_on_playing) then
				all_RoomId[RoomId_num] = room_info.id
				RoomId_num = RoomId_num + 1
			end
		end
	end
	print("RoomId_num:"..RoomId_num)
	if RoomId_num ~= 1 then
		RoomId = math.random(1,RoomId_num-1)
	end	
	if RoomId_num ~= 1 and RoomId ~= nil then
		state:EnterRoom(all_RoomId[RoomId])
	else
		MessageBox.ShowWithConfirm(lang:GetText("没有找到合适的房间"))
	end
end

function GetBack(page)
print("88888888888888888888888888888888888")
	HideAll()
    local SelectedServerID = nil
	local SelectedChannelID = nil
	local SelectedroomID = nil
	
	if page == 0 then
		
	elseif page == 1 then
	
		if state then
			state:LeaveServer()
		end
		in_server_first = true
		if not state.is_fight_team_server and not L_FightTeam.is_in_fight_ui and not L_FightTeam.is_in_invite then
			ShowServerList(root_ui)
		end
	elseif page == 2 then
		if state then
			state:LeaveChannel()
		end
		in_channel_first = true
		if not state.is_fight_team_server and not IsMatchServer()  and not IsMatchServer1() then
			ShowChannelList(root_ui)
		end		
	elseif page == 3 then
	
		if state then
			if host_character_info then
				host_character_info = NullPtr
				host_character_info = nil
			end
			if matchTime_window_ui then
				matchTime_window_ui = nil
			end
			if matchTime_window then
				matchTime_window = nil
			end
			state:LeaveRoom()
			leaveRoom = true
		end
		
		if host_character_info then
			host_character_info = NullPtr
			host_character_info = nil
		end
		
		in_room_first = true
		if not state.is_fight_team_server and not IsMatchServer() and not IsMatchServer1() then
			ShowRoomList(root_ui)	
		end
	elseif page == 4 then
		in_room_first = true
		if not state.is_fight_team_server and not IsMatchServer()and not IsMatchServer1()  then
			ShowRoomList(root_ui)	
		end
	elseif page == 5 then
		if not state.is_fight_team_server and not IsMatchServer()and not IsMatchServer1()  then
			ShowRoomWindow(root_ui)	
		end
	end
end

function FightGetBack(page)
	HideAll()
    local SelectedServerID = nil
	local SelectedChannelID = nil
	local SelectedroomID = nil
	
	if page == 0 then
		if L_FightTeam.is_in_fight_ui then
			L_LobbyMain.current_chosse_main_page = 2
			lg:SetLobbyModules(2)
			gui:PlayAudio("kUIA_CLOSE_UI")
			--L_LobbyMain.LobbyMainWin_Foot.btn_FightTeam.PushDown = true
			--L_LobbyMain.LobbyMainWin_Foot.btn_WarZone.PushDown = false
			-- L_FightTeam.is_in_fight_ui = false
			if L_LobbyMain.LobbyMainWin_Boddy then
				L_FightTeam.Show(L_LobbyMain.LobbyMainWin_Boddy.LobbyMainWin_Boddy_Root)
			end
		end
		
		if L_FightTeam.is_in_invite then
			L_LobbyMain.current_chosse_main_page = 2
			lg:SetLobbyModules(2)
			gui:PlayAudio("kUIA_CLOSE_UI")
			if L_LobbyMain.LobbyMainWin_Boddy then
				L_FightTeam.Show(L_LobbyMain.LobbyMainWin_Boddy.LobbyMainWin_Boddy_Root)
			end
			
			-- state.is_fight_team_server = true
			
			-- local state = ptr_cast(game.CurrentState)
			-- state:GetBattleGroupJoin(L_FightTeam.invite_group)
		end
	elseif page == 1 then
		if state then
			state:LeaveServer()
		end
		in_server_first = true
	elseif page == 2 then
		if state then
			state:LeaveChannel()
		end
		in_channel_first = true	
	elseif page == 3 then
		if state then
			state:LeaveChannel()
		end
		if host_character_info then
			host_character_info = NullPtr
			host_character_info = nil
		end
		in_room_first = true
	elseif page == 4 then
		if state then
			state:LeaveChannel()
		end
	elseif page == 5 then
		if state then
			state:LeaveChannel()
		end
	end
	current_state = 0
end

function InitChatWin( Win )
	local state = ptr_cast(game.CurrentState)
	chatWindow = state.ChatWindow
	chatWindow.Parent = Win
	chatWindow.Size = Vector2(400,300)
	chatWindow.MessageDisplaySize = Vector2(300,200)
	chatWindow.MessageDisplayLoc = Vector2(100,0)
end


function ShowWitchWindow(parent_win)
	--print("in ShowWitchWindow")
	L_LobbyMain.HideAll()
	if state.is_fight_team_server then
		L_LobbyMain.LobbyMainWin_Foot.btn_FightTeam.PushDown = true
		current_state = 0
	else	
		L_LobbyMain.LobbyMainWin_Foot.btn_WarZone.PushDown = true
	end
	HideAll()
	print("current_state = "..current_state)
	if current_state == 0 then
		ShowServerList(parent_win)
	elseif current_state == 1 then
	    ShowChannelList(parent_win)
	elseif current_state == 2 then
		ShowRoomList(parent_win)
	elseif current_state == 3 then
	    if IsMatchServer() then
			ShowMatchUI(parent_win)
		elseif	IsMatchServer1() then
			ShowAutomaticMatchUI(parent_win)
		else	
			ShowRoomWindow(parent_win)
		end
	elseif current_state == 4 then		
		if create_room_ui.btn_Cannel.Text == lang:GetText("返　回") then
			GetBack(5)
		else
			create_room_ui.ctrl_Main_Window.Parent = nil			     
			create_room_ui = nil
			GetBack(current_state)	
		end	
	end
end


function HideAll()

	if main_server_list_ui then
		main_server_list_ui.ctrl_Main_Window.Parent = nil
	end
	
	if main_channel_list_ui then
		main_channel_list_ui.ctrl_Main_Window.Parent = nil
	end
	if match_window_ui then
		match_window_ui.ctrl_Main_Window.Parent = nil
	end
	if automatic_match_ui then
		automatic_match_ui.ctrl_Main_Window.Parent = nil
	end
	
	if match_ank_ui1 then
		match_ank_ui1.ctrl_Main_Window.Parent = nil
	end
		if match_ank_ui2 then
		match_ank_ui2.ctrl_Main_Window.Parent = nil
	end
	if match_ank_ui then
	   match_ank_ui.ctrl_Main_Window.Parent = nil
	end	
	if main_room_list_ui then
		main_room_list_ui.setting_window.Visible = false
		main_room_list_ui.ctrl_Main_Window.Parent = nil
	end
	
	if create_room_ui then
		create_room_ui.ctrl_Main_Window.Parent = nil
	end
	
	if room_ui then
		room_ui.ctrl_Main_Window.Parent = nil
		--room_ui.Timer.Visible = false
	end
end


function Logout()	
	--print("in Logout()")
	HideAll()
	current_state = 0
end
--------------------------------function end----------------------------------------

function Initialize()
	--print("=================L_WarZone Initialize()")
end

function Finalize()
	--print("=================L_WarZone Finalize()")
	HideAll()
	root_ui = nil
	main_server_list_ui = nil
	main_channel_list_ui = nil
	automatic_match_ui = nil
	match_window_ui = nil
	match_ank_ui = nil
	match_ank_ui1 = nil
	match_ank_ui2 = nil
	main_room_list_ui = nil
	create_room_ui = nil
	room_ui = nil

	current_state = 0

	server_id = 0
	channel_id = 0
	room_id = 0
	is_fight_id = false
	is_source_id = false
	is_pipei_id = false
	is_Channelcount_id = false
	server_name = nil
	channel_name = nil
	room_name = nil

	in_server_first = true
	in_channel_first = true
	in_room_first = true

	SelectedServerID = nil
	SelectedChannelID = nil
	SelectedroomID = nil

	current_select_server_info = nil
	current_select_channel_info = nil
	current_select_room_info = nil
	host_character_info = nil
end

function Show(parent_win)
	--print("=================L_WarZone Show()")
	if state.is_fight_team_server or L_FightTeam.is_in_invite then
		L_LobbyMain.current_chosse_main_page = 2
	else
		L_LobbyMain.current_chosse_main_page = 5
	end
	root_ui = parent_win


	initStateCallBack()
	UpdateLevelList ()
	ShowWitchWindow(parent_win)
end

function Hide()
	if main_server_list_ui then
		main_server_list_ui.ctrl_Main_Window.Parent = nil
	end
	if main_channel_list_ui then
		main_channel_list_ui.ctrl_Main_Window.Parent = nil
	end
	if automatic_match_ui then
		automatic_match_ui.ctrl_Main_Window.Parent = nil
	end
	if match_window_ui then
		match_window_ui.ctrl_Main_Window.Parent = nil
	end
	if match_ank_ui then
		match_ank_ui.ctrl_Main_Window.Parent = nil
	end
	if match_ank_ui1 then
		match_ank_ui1.ctrl_Main_Window.Parent = nil
	end
	if match_ank_ui2 then
		match_ank_ui2.ctrl_Main_Window.Parent = nil
	end
	if main_room_list_ui then
		main_room_list_ui.ctrl_Main_Window.Parent = nil
	end
	if create_room_ui then
		create_room_ui.ctrl_Main_Window.Parent = nil
	end

	if room_ui then
		room_ui.ctrl_Main_Window.Parent = nil
	end
	
	if replay_video_window then
		replay_video_window:Close()
	end
	    
	if main_room_info_ui ~= nil then
		main_room_info_ui.room_info.Visible = false
		main_room_info_ui.room_info.Parent = nil
	end
end

--地图资源加载
function FindMapIcon(Text)
	local l = Map_Icons
	while l do
		if l.text == Text then
			return l
		end
		l = l.next
	end
	local Tepnum = string.find(Text,"_")
	local num
	if Tepnum then
		num = string.sub(Text , 6 , Tepnum - 1)
	else
		num = ""
	end
	Map_Icons = { 
				next = Map_Icons , 
				text = Text ,
				Icon = Gui.Image("MapsAndBG/MapsIcon/battlefield_map_lv"..num..".dds",Vector4(0,0,0,0)),
				Icon_out = Gui.Image("MapsAndBG/MapsIcon/lb_battlefield_map_lv"..num.."_b.dds",Vector4(0,0,0,0))
				}
	local l = Map_Icons
	while l do
		if l.text == Text then
			return l
		end
		l = l.next
	end
end

function WinSizeChange()
	if L_WarZone.room_ui then
		L_WarZone.room_ui.MesPanel_room:EventSizeChanged()
	end
	if main_room_list_ui then
		main_room_list_ui.MesPanel_channel:EventSizeChanged()
	end
end

function SpeakType(Type_text_btn,Text_Position,ctr_text)
	if ctr_text.Text == "/C" or ctr_text.Text == "/c" then
		Type_text_btn.Text = lang:GetText("当前")
		Type_text_btn.TextColor = ARGB(255, 214, 212, 207)
		Type_text_btn.HighlightTextColor = ARGB(255, 214, 212, 207)
		ctr_text.Text = ""
	elseif ctr_text.Text == "/X" or ctr_text.Text == "/x" then
		Type_text_btn.Text = lang:GetText("小喇叭")
		Type_text_btn.TextColor = ARGB(255, 242, 127, 3)
		Type_text_btn.HighlightTextColor = ARGB(255, 242, 127, 3)
		ctr_text.Text = ""
	elseif ctr_text.Text == "/D" or ctr_text.Text == "/d" then
		Type_text_btn.Text = lang:GetText("大喇叭")
		Type_text_btn.TextColor = ARGB(255, 255, 234, 0)
		Type_text_btn.HighlightTextColor = ARGB(255, 255, 234, 0)
		ctr_text.Text = ""
	end
	if ctr_text.Text == "" then
		return
	end
	local args
	local Type
	if Type_text_btn.Text == lang:GetText("当前") then
		L_Friends.chatWindow:Chat(ctr_text.Text,Text_Position)
		ctr_text.Text = ""
		return
	elseif Type_text_btn.Text == lang:GetText("大喇叭") then
		args = {pid = ptr_cast(game.CurrentState):GetCharacterId(),server_id = server_id, channel_id = state.last_channel_id,type = 3, msg = ctr_text.Text}
		Type = 3
	elseif Type_text_btn.Text == lang:GetText("小喇叭")then
		args = {pid = ptr_cast(game.CurrentState):GetCharacterId(),server_id = server_id, channel_id = state.last_channel_id,type = 2, msg = ctr_text.Text}
		Type = 2
	end
	--L_MessageBox.ShowWaiter(lang:GetText("正在发送") .. "“"..Type_text_btn.Text.."”...")
	if L_LobbyMain.LobbyMainWin.lab_timer_dlb.Visible then
		MessageBox.ShowWithTimer(1, lang:GetText("喇叭功能使用太频繁，请稍候使用！"))
		return
	end
	local tex = ctr_text.Text
	rpc.safecall("speak", args, function(data)
									--L_MessageBox.CloseWaiter()
									if data.warning then
										MessageBox.ShowWithTwoButtons(lang:GetText("你的")..Type_text_btn.Text..lang:GetText("不足，请购买！"),lang:GetText("购买"),lang:GetText("取消"),
																					function()
																						rpc.safecall("get_speak",{type = Type},
																												function(data)
																													L_Characters.magice_hummer_Info[1] = data.list
																													L_Characters.ShowRapidShoppingWin()
																													L_Characters.Rapid_Shopping_Win_ui.des.Size = Vector2(250, 50)
																													L_Characters.Rapid_Shopping_Win_ui.des.Location = Vector2(25, 110)
																													L_Characters.Rapid_Shopping_Win_ui.des.FontSize = 14
																												end
																												)
																					end,
																					nil
																					)
										ctr_text.Text = tex
									end
								end)
	ctr_text.Text = ""
	L_LobbyMain.LobbyMainWin.lab_timer_dlb:Show()
end

function SetChannnlListVisible(num)
	if main_room_list_ui then
		if num == 1 then
			main_room_list_ui.ctr_play_Chat.Visible = true
			main_room_list_ui.ctr_play_list.Visible = false
			main_room_list_ui.BTN_Channl_List.PushDown = false
			main_room_list_ui.BTN_Channl_Chat.PushDown = true
		elseif num == 2 then
			main_room_list_ui.ctr_play_Chat.Visible = false
			main_room_list_ui.ctr_play_list.Visible = true
			main_room_list_ui.BTN_Channl_List.PushDown = true
			main_room_list_ui.BTN_Channl_Chat.PushDown = false
		end
	end
end

function fileChannlListPage()
	main_room_list_ui.tbox_text_page.Text = channl_list_page.."/"..channl_list_page_total..lang:GetText("页")
end

function Set_Channl_Search_state(sta)
	Channl_Search_state = sta
	if Channl_Search_state == true then
		main_room_list_ui.btn_search_channl.Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_contact_button_ss1_normal.dds", Vector4(0, 0, 0, 0)),
				HoverImage = Gui.Image("LobbyUI/WarZone/lb_contact_button_ss1_hover.dds", Vector4(0, 0, 0, 0)),
				DownImage = Gui.Image("LobbyUI/WarZone/lb_contact_button_ss1_down.dds", Vector4(0, 0, 0, 0)),
				DisabledImage = Gui.Image("LobbyUI/WarZone/lb_contact_button_ss1_normal.dds", Vector4(0, 0, 0, 0)),
			}
	else
	main_room_list_ui.btn_search_channl.Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_button_ss_normal.dds", Vector4(0, 0, 0, 0)),
				HoverImage = Gui.Image("LobbyUI/Friends/lb_contact_button_ss_hover.dds", Vector4(0, 0, 0, 0)),
				DownImage = Gui.Image("LobbyUI/Friends/lb_contact_button_ss_down.dds", Vector4(0, 0, 0, 0)),
				DisabledImage = Gui.Image("LobbyUI/Friends/lb_contact_button_ss_normal.dds", Vector4(0, 0, 0, 0)),
			}
	end
end

function IsMatchServer()
	for i = 0, state:GetServerCount() - 1 do
		local info = state:GetServerInfo(i,true)
		if info.id == server_id and info.isnovice == 6   then
			return true
		end
	end
	return false
end

function UpdateLevelList ()
	local cnt = state:GetLevelCount()
	
	if level_count ~= cnt then
		level_count = cnt
		map_show_name_of_key={}
		map_desc_of_key={}
		map_key_of_game_type={}
		map_id={}
		map_show_name = {}
		map_isgm = {}
		for i=1, level_count do
			local level_info = state:GetLevelInfo(i-1)
			if not map_key_of_game_type[level_info.type] then
				map_key_of_game_type[level_info.type] = {}
			end

			if not map_show_name[level_info.type] then
				map_show_name[level_info.type] = {lang:GetText("全部")}
			end
			table.insert(map_key_of_game_type[level_info.type], level_info.name)
			table.insert(map_show_name[level_info.type], level_info.show_name)
			-- show name fill
			map_show_name_of_key[level_info.name] = level_info.show_name

			-- map desc fill
			map_desc_of_key[level_info.name] = level_info.description

			if not map_id[level_info.type] then
				map_id[level_info.type] = {}
			end

			map_id[level_info.type][level_info.name] = level_info.id
			
			map_isgm[level_info.id] = level_info.is_gm
		end
		-- setting_map = 
		-- {
			-- map_show_name["kTeam"],
			-- {lang:GetText("全部"),lang:GetText("风车小镇"),lang:GetText("金色农场"),lang:GetText("乡间伐木场"),lang:GetText("红岩谷")},
			-- {lang:GetText("全部"),lang:GetText("法老神殿"),lang:GetText("神庙遗迹"),lang:GetText("夜晚农场"),lang:GetText("宫廷回廊")},
			-- {lang:GetText("全部"),lang:GetText("神庙遗迹"),lang:GetText("盛夏农场"),lang:GetText("阿拉伯古城"),lang:GetText("沙之吊桥"),lang:GetText("埃及古墓"),lang:GetText("风暴都城"),lang:GetText("红岩谷"),lang:GetText("战神竞技场"),lang:GetText("灵石谷"),lang:GetText("神秘山丘")},
			-- {lang:GetText("全部"),lang:GetText("阴霾教堂"),lang:GetText("失落废墟")},
			-- {lang:GetText("全部"),lang:GetText("神殿广场"),lang:GetText("神庙遗迹"),lang:GetText("夜晚小镇"),lang:GetText("激战麦田"),lang:GetText("战神竞技场"),lang:GetText("灵石谷")},
			-- {lang:GetText("全部"),lang:GetText("阿拉伯古城"),lang:GetText("沙之吊桥"),lang:GetText("风暴都城"),lang:GetText("灵石谷")},
			-- {lang:GetText("全部"),lang:GetText("九龙街区"),lang:GetText("神庙遗迹"),lang:GetText("失落废墟"),lang:GetText("埃及古墓"),lang:GetText("战神竞技场")},
			-- {lang:GetText("全部"),lang:GetText("生化研究所")},
			-- {lang:GetText("全部"),lang:GetText("毁灭之都")},
		-- }
		
	-- for _, v in ipairs(game_type_key) do
		-- if not map_key_of_game_type[v] then
			-- map_key_of_game_type[v] = {}
		-- end
					-- table.insert(map_key_of_game_type[v], 1, "level_random")
			-- end
		
			-- if not map_key_of_game_type["kRandom"] then
		-- map_key_of_game_type["kRandom"] = {}
	-- end
	   
	-- table.insert(map_key_of_game_type.kRandom, 1, "level_random")
	end
end

function IsMatchServerById(serverid)
	for i = 0, state:GetServerCount() - 1 do
		local info = state:GetServerInfo(i,true)
		if info.id == serverid and info.isnovice == 6 then
			return true
		end
	end
	return false
end


function IsMatchServer1()
	for i = 0, state:GetServerCount() - 1 do
		local info = state:GetServerInfo(i,true)
		if info.id == server_id and info.isnovice == 7   then
			return true
		end
	end
	return false
end

function IsMatchServerById1(serverid)
	for i = 0, state:GetServerCount() - 1 do
		local info = state:GetServerInfo(i,true)
		if info.id == serverid and info.isnovice == 7 then
			return true
		end
	end
	return false
end

local Automatic_match_window =
{
 
	Gui.Control "ctrl_Main_Window"
	{ 
		Size = Vector2(1123, 590),
		Location = Vector2(16, 25),
		BackgroundColor = ARGB(255, 255, 255, 255),
		-- Visible = false,
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/lb_bg_wallpaper04.dds", Vector4(22, 22, 22, 22)),
		},
		Gui.Label "lbl_GameType"
		{
			Size = Vector2(105, 36),
			Text = lang:GetText("游戏模式"),
			TextColor = ARGB(255, 255, 128, 0),
			FontSize = 18,
			Location = Vector2(30, 30),
		},
		Gui.Label ""
		{
			Size = Vector2(105, 36),
			Text = lang:GetText("地图"),
			TextColor = ARGB(255, 255, 128, 0),
			FontSize = 18,
			Location = Vector2(30, 120),
		},
		Gui.ComboBox "cbx_Mode1"
		{
			Style = "Gui.WarZoneCreateComboBox",
			Size = Vector2(284, 38),
			FontSize = 18,
			Readonly = true,
			Location = Vector2(30, 80),
			TextColor = ARGB(255,206,227,234),
			ChildComboListStyle =  "Gui.ChangeJobComboList",
			WithIconOffset = Vector2(240,0),
		},
		Gui.Control "1"
	    {
	    	Size = Vector2(676, 353),
			Location = Vector2(30, 150),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg3.dds", Vector4(16, 16, 16, 16)),
			},
			Gui.Control ""
			{
				Size = Vector2(675, 352),
				Location = Vector2(1, 1),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/pipei/battlefield_map_random.dds", Vector4(16, 16, 16, 16)),
				},
			},
		},
		
		
		Gui.Control "2"
	    {
	    	Size = Vector2(360+20, 390+87),
			Location = Vector2(735-18, 30),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg3.dds", Vector4(16, 16, 16, 16)),
			},
			Gui.Control"ctr_play_list"
			{
				Size = Vector2(360, 390),
				Location = Vector2(10, 10),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Visible = true,
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_contact_bg2.dds", Vector4(38, 41, 38, 66)),	
				},
				
				Gui.Label
				{		
					Location = Vector2(5, 10),
					Size = Vector2(337, 30),
					BackgroundColor = ARGB(0, 255, 255, 255),
					Text = lang:GetText("队伍列表"),
					FontSize = 24,
					TextColor = ARGB(255, 127, 127, 127),
					TextAlign = "kAlignCenterMiddle",
				},
				Gui.Label
				{		
					Location = Vector2(6, 9),
					Size = Vector2(337, 30),
					BackgroundColor = ARGB(0, 255, 255, 255),
					Text = lang:GetText("队伍列表"),
					FontSize = 24,
					TextColor = ARGB(255, 255, 108, 0),
					TextAlign = "kAlignCenterMiddle",
				},
				Gui.Control 
				{		
					Location = Vector2(13, 38),
					Size = Vector2(330, 341),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_rank_bg_01.dds", Vector4(34, 34, 34, 34)),
					},																						
					Gui.ListTreeView "Fight_Team_Room_Player"
					{
						Style = "Gui.ListTreeViewWith_VScroll_FightTeam",
						Size = Vector2(329, 350),
						Location = Vector2(0,4),
						ItemHeight = 42,
						TreeVisible = false,
						-- MY_SPLIT_WIDTH = 28, --CHECKBOX 鼠标点击的偏移量
						AlwaysSelect = false,
						HeaderVisible = false,
						-- VScrollBarDisplay = "kVisible",
						-- VScrollBarWidth = 16,
						-- VScrollBarButtonSize = 16,
						CanKeySelect = false,
						VScrollBarWidth = 1,
						VScrollBarButtonSize = 1,
					},
					Gui.Control ""
					{		
						Location = Vector2(120, 222-43),
						Size = Vector2(120, 24),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_room_closed_bg_hover.dds", Vector4(34, 34, 34, 34)),
						},	
						
					},
					Gui.Control ""
					{		
						Location = Vector2(120, 222),
						Size = Vector2(120, 24),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_room_closed_bg_hover.dds", Vector4(34, 34, 34, 34)),
						},	
						
					},
					Gui.Control ""
					{		
						Location = Vector2(120, 222+43),
						Size = Vector2(120, 24),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_room_closed_bg_hover.dds", Vector4(34, 34, 34, 34)),
						},	
						
					},
					Gui.Control ""
					{		
						Location = Vector2(120, 222+43+43),
						Size = Vector2(120, 24),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_room_closed_bg_hover.dds", Vector4(34, 34, 34, 34)),
						},	
						
					},
				},
			},
			
			
						--邀请
			Gui.Button "btn_invite"
			{
				Size = Vector2(116, 72),
				Location = Vector2(147, 401),
				TextColor = ARGB(255, 255, 246, 235),
				FontSize = 18,
				PushDown = false,
				Enable = true,
				Visible = true,
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/pipei/lb_battlefield_button_invite_normal.dds", Vector4(0, 0, 0, 0)),
					HoverImage = Gui.Image("LobbyUI/pipei/lb_battlefield_button_invite_hover.dds", Vector4(0, 0, 0, 0)),
					DownImage = Gui.Image("LobbyUI/pipei/lb_battlefield_button_invite_down.dds", Vector4(0, 0, 0, 0)),
					DisabledImage = Gui.Image("LobbyUI/pipei/lb_battlefield_button_invite_disabled.dds.", Vector4(0, 0, 0, 0)),
				},
				EventClick = function()
					L_Friends.ShowInviteGameCreatematchWinmatch(gui)
				end,
			},
			
		},

		--退出频道
		Gui.Button "btn_exit_channel"
		{
			Size = Vector2(163, 46),
			Location = Vector2(467, 515),
			Text = lang:GetText("取  消"),
			TextColor = ARGB(255, 255, 255, 255),
			FontSize = 18,
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/pipei/lb_squad_button7_normal.dds", Vector4(5, 5, 5, 5)),
				HoverImage = Gui.Image("LobbyUI/pipei/lb_squad_button7_hover.dds", Vector4(5, 5, 5, 5)),
				DownImage = Gui.Image("LobbyUI/pipei/lb_squad_button7_down.dds", Vector4(5, 5, 5, 5)),
				DisabledImage = Gui.Image("LobbyUI/pipei/lb_squad_button7_disabled.dds", Vector4(5, 5, 5, 5)),
			},
			EventClick = function()
				FightGetBack(current_state)
				if automatic_match_ui then
					automatic_match_ui.ctrl_Main_Window.Parent = nil
					automatic_match_ui = nil
				end
				if host_character_info then
					host_character_info = NullPtr
					host_character_info = nil
				end
				state:LeaveRoom()
				state:LeaveChannel()
				ShowServerList(root_ui)
				matching_Begin = false
				L_LobbyMain.EnterRoomState(true)
				
			end,
		},
		--开始匹配
		Gui.Button "start_match"
		{
			Size = Vector2(163, 46),
			Location = Vector2(167, 515),
			Text = lang:GetText("开始匹配"),
			TextColor = ARGB(255, 255, 255, 255),
			FontSize = 18,
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/pipei/lb_squad_button8_normal.dds", Vector4(5, 5, 5, 5)),
				HoverImage = Gui.Image("LobbyUI/pipei/lb_squad_button8_hover.dds", Vector4(5, 5, 5, 5)),
				DownImage = Gui.Image("LobbyUI/pipei/lb_squad_button8_down.dds", Vector4(5, 5, 5, 5)),
				DisabledImage = Gui.Image("LobbyUI/pipei/lb_squad_button8_disabled.dds", Vector4(5, 5, 5, 5)),
			},
			EventClick = function()
				needShowMatching_Time = true
				state:RoomChangeOption(L_FightTeam.create_source_room_option)
				state:RequestMatching()
			end,
		},
	},
}
function ShowAutomaticMatchUI(win_parent)
    print("1111111.....")
	matching_Begin = true
	L_LobbyMain.HideAll()
	L_LobbyMain.current_chosse_main_page = 5
	L_LobbyMain.LobbyMainWin_Foot.btn_WarZone.PushDown = true
	L_LobbyMain.LobbyMainWin.video_button.Enable = false
	current_state = 3
	
	--创建界面
	
	if not automatic_match_ui then
		automatic_match_ui = Gui.Create(win_parqent)(Automatic_match_window)
	end
	AutomaticMatchUiInit()
	
	setup_match_game_mode1(automatic_match_ui.cbx_Mode1 ,true)
	automatic_match_ui.ctrl_Main_Window.Parent = win_parent
	MessageBox.CloseWaiter()
	L_LobbyMain.EnterRoomState(false)
end

function FillAutomaticMatchUi()
	-- if L_WarZone.matchTime_window_ui then
		-- return
	-- end
	local ltv = automatic_match_ui.Fight_Team_Room_Player 
	local flag = true	
	ltv:DeleteAll()
	local i = 1
	local state = ptr_cast(game.CurrentState)
	if not state then
		return
	end
	local client_count = state:GetClientCount()
	print("client_count1111111:",client_count)
	for j = 0, client_count-1 do
		local client_info = state:GetClientInfo(j)
		local sub_item = ltv:AddItem(ltv.RootItem,"")
		if j % 2 == 1 then
			sub_item.BGSkin = Skin.ListItemSkin_Double_Black
		else
			sub_item.BGSkin = Skin.ListItemSkin_Single_Black
		end
		sub_item.ID = client_info.id
		local status = ""
		local name = ""
		local iconVip = nil
		local iconN = nil
		local iconA = nil
		local iconH = nil
		local iconHead = nil
		local headIcon = nil
		local icon2,icon1 = nil,nil
		local isVip = client_info.is_vip
		local CardId = -1
		if client_info then	
			CardId = client_info.business_card
		end
		LoadCard(sub_item,1,j,CardId)
		if isVip == 1 then
			iconVip = Icons.PlayerStatusIcons["Vip"]
		elseif isVip == 2 then
			iconVip = Icons.PlayerStatusIcons["XunLeiVip"]
		end
		
		if isVip > 0 then
			iconVip = Gui.Icon("LobbyUI/vip/vip/VIP_button_0"..isVip.."_normalred.dds")
		end
		
		if client_info.icon ~= "null" then
				iconHead = Gui.Icon("LobbyUI/persionalInfo/HeadPic/lb_battlefield_icon"..client_info.icon..".dds")
		end
		
		if iconHead == nil then
			iconHead = Gui.Icon("LobbyUI/persionalInfo/HeadPic/lb_battlefield_icon01_b.dds")
		end
		local my_id = state:GetCharacterId()
		if (my_id == client_info.character_id) then
			host_character_info = client_info
			sub_item.IsSelfItem = true
		end
		-- iconHead = Icons.PlayerStatusIcons["Head"]
		
		-- if client_info.is_ready == 2 then
			-- iconN = Icons.PlayerStatusIcons["PlayingC"]
			-- iconA = Icons.PlayerStatusIcons["PlayingC"]
		-- elseif client_info.is_ready == 1 then
			-- iconN = Icons.PlayerStatusIcons["ReadyN"]
			-- iconA = Icons.PlayerStatusIcons["ReadyA"]
		-- end
		-- if client_info.client_uid == state.b_player_info.ownerclient_uid then
			-- iconN = Icons.PlayerStatusIcons["Host"]
			-- iconA = Icons.PlayerStatusIcons["Host"]
		-- end
		name = client_info.name
		sub_item:SetIcon(0, iconVip)
		sub_item:SetIcon(1, iconHead)
	
		sub_item:SetText(4, name)
		sub_item:SetIcon(5, iconN)
		sub_item:SetHoverIcon(5, iconA)
		FillLevel(client_info.level, client_info.exp, sub_item)
		
		local num = 5
		sub_item.LV_BackgroundImage = Gui.Image("LobbyUI/lv"..(math.floor((client_info.level - 1)/num)*num+1).."-"..(math.ceil(client_info.level/num)*num)..".dds", Vector4(0, 0, 0, 0), Vector4(0, 0, 1, 1))
		sub_item.LV_localtion = Vector2(84,0)
		sub_item.LV_Size = Vector2(46,42)
		-- sub_item.CheckVisible = false
		i = i + 1
		
	end

	if i < 9 then
		local j 
		for j = i ,9 do
			local sub_item = ltv:AddItem(ltv.RootItem)
			sub_item.CanSelect = false
			sub_item.ID = -1
			if j % 2 == 1 then
				sub_item.BGSkin = Skin.ListItemSkin_Single_Black
			else
				sub_item.BGSkin = Skin.ListItemSkin_Double_Black
			end
		end
	end
end

function AutomaticMatchUiInit()
	-- local ib_map = match_window_ui.ib_map	
	-- if ib_map ~= nil then
		-- setup_match_window_ui(ib_map, game_type_key[1])			
		--选取地图初始化设定
	-- end
	local list = automatic_match_ui.Fight_Team_Room_Player
	list:DeleteColumns()
	list:AddColumn("",50, "kAlignCenterMiddle")
	list:AddColumn(lang:GetText("头像"), 35, "kAlignCenterMiddle")
	list:AddColumn(lang:GetText("等"), 22,"kAlignRightMiddle")
	list:AddColumn(lang:GetText("级"), 22,"kAlignLeftMiddle")
	list:AddColumn(lang:GetText("玩家昵称"),160,"kAlignCenterMiddle")
	list:AddColumn(lang:GetText("状态"),56,"kAlignCenterMiddle")
	
	L_FightTeam.create_source_room_option = ptr_new ("Client.RoomOption")
	L_FightTeam.create_source_room_option.name = lang:GetText("个人匹配")
	L_FightTeam.create_source_room_option.client_count = 4
	L_FightTeam.create_source_room_option.use_password = false
	L_FightTeam.create_source_room_option.character_id = L_WarZone.single_character_id[1]
	L_FightTeam.create_source_room_option.check_game_balance = false
	L_FightTeam.create_source_room_option.round_rebirth_time_max = L_WarZone.rebirth_time[1]
	L_FightTeam.create_source_room_option.game_type = -1
	L_FightTeam.create_source_room_option.map_name = ""
	L_FightTeam.create_source_room_option.rule_value = 1
	L_FightTeam.create_source_room_option.level_id = -1
	L_FightTeam.create_source_room_option.is_matching = 1 --==1是匹配房
	
	---------------增加右键菜单--------------------
	list.PopupMenu.Style = "Gui.MenuNew"
	list.EventRightClick = function(sender, e)
		list.PopupMenu:RemoveAll()
		local item = sender.MouseSelectedItem
		
		if not item then
			return
		end
		
		local name = item:GetText(4)
		local room_info=state:GetSelfRoomInfo()
		local room_option = ptr_cast(room_info.option)
		if host_character_info then
			if host_character_info.is_host == true then
				list.PopupMenu:AddItem(lang:GetText("关闭"))

			elseif host_character_info.is_host == false then
				if name == "" then
					return
				end
			end
		end
		
		if sender.PopupMenu and name ~= "" and host_character_info.is_host == true then
			sender.PopupMenu:Open()
			HideToolTipsWindow()
		end
	end
	
	list.PopupMenu.EventClick = function(sender, e)
		local item = ptr_cast(sender.Tag)
		local name = item:GetText(4)
		local pid = GetPidByNameInRoom(name)
		local room_info=state:GetSelfRoomInfo()
		local room_option = ptr_cast(room_info.option)

		local my_id = state:GetCharacterId()
		if host_character_info and host_character_info.character_id == my_id and my_id == pid then
			MessageBox.ShowError(lang:GetText("房主不可以关闭自己"))
			return
		end
		if host_character_info and host_character_info.is_host == true then
			if  sender.SelectedIndex == 0 then
				if Is_Auto_Start == false then
					state:ChangeSlotStatus(item.ID,0)
					state:ChangeSlotStatus(item.ID,1)
				end
			end
		end
	end
end

function setup_match_game_mode(cbx, flag)
	cbx.Enable = true
	local room_info=state:GetSelfRoomInfo()
	local room_option = ptr_cast(room_info.option)
	local index = 0
	local info = state:GetServerInfo(game.ClientAddress.server_id - 1,false)
	local gametype_limit_old = L_PushCmd.Split(info.gametype_limit,";")	
	local gametype_limit = L_PushCmd.Split(gametype_limit_old[1],",")
	local gametype_commend = L_PushCmd.Split(gametype_limit_old[2],",")
	local gametype_new = L_PushCmd.Split(gametype_limit_old[3],",")
	local gametype_new_com = L_PushCmd.Split(gametype_limit_old[4],",")
	SetModeState_match(gametype_new_com,gametype_new,gametype_commend,gametype_limit)
	cbx:RemoveAll()
	for i=1, #setting_mode do
		if(setting_mode[i][3] == 0) then
			cbx:AddItem(setting_mode[i][2])
		else
			cbx:AddItemWithIcon(setting_mode[i][2],setting_mode[i][3] - 1)
		end
		
		if flag and (setting_mode[i][1] == "kBossPVE" or setting_mode[i][1] == "kAdvenceMode") then
			cbx:SetItemDisable(i-2, true)
		end
		
		if room_option.game_type == setting_mode[i][1] then
			index = i - 2
		end
	end
	
	if flag then
		cbx.SelectedIndex = index
	else
		cbx.SelectedIndex = 0
	end
	function cbx:EventItemSelected(sender, e)
		local index = self.SelectedIndex
		SetRoomButtonEvent1(setting_mode1[index + 1][1])
	end
end

function SetModeState_match(AllMode_new_com,AllMode_new,AllMode_commend,AllMode)
	setting_mode1 = {}
	setting_moshi1 = {}
	setting_map1 = {}
	setting_mode1[1] = {"kAll",lang:GetText("随机"),0,0}
	setting_moshi1[1] = lang:GetText("随机")
	local i_tep = 2
	if AllMode_new_com then
		for i=1, #AllMode_new_com do
			for j=1, #game_type_info_order1 do
				if game_type_info_order1[j][3] == tonumber(AllMode_new_com[i]) then				
					setting_mode1[i_tep] = {game_type_info_order1[j][2],game_type_info_order1[j][1],3,0}
					setting_moshi1[i_tep] = game_type_info_order1[j][1]
					setting_map1[i_tep-1] = map_show_name[game_type_info_order1[j][2]]
					i_tep = i_tep + 1
					break
				end
			end
		end
	end
	if AllMode_new then
		for i=1, #AllMode_new do
			for j=1, #game_type_info_order1 do
				if game_type_info_order1[j][3] == tonumber(AllMode_new[i]) then				
					setting_mode1[i_tep] = {game_type_info_order1[j][2],game_type_info_order1[j][1],1,0}
					setting_moshi1[i_tep] = game_type_info_order1[j][1]
					setting_map1[i_tep-1] = map_show_name[game_type_info_order1[j][2]]
					i_tep = i_tep + 1
					break
				end
			end
		end
	end
	if AllMode_commend then
		for i=1, #AllMode_commend do
			for j=1, #game_type_info_order1 do
				if game_type_info_order1[j][3] == tonumber(AllMode_commend[i]) then				
					setting_mode1[i_tep] = {game_type_info_order1[j][2],game_type_info_order1[j][1],2,0}
					setting_moshi1[i_tep] = game_type_info_order1[j][1]
					setting_map1[i_tep-1] = map_show_name[game_type_info_order1[j][2]]
					i_tep = i_tep + 1
					break
				end
			end
		end
	end
	if AllMode then
		for i=1, #AllMode do
			for j=1, #game_type_info_order1 do
				if game_type_info_order1[j][3] == tonumber(AllMode[i]) then				
					setting_mode1[i_tep] = {game_type_info_order1[j][2],game_type_info_order1[j][1],0,0}
					setting_moshi1[i_tep] = game_type_info_order1[j][1]
					setting_map1[i_tep-1] = map_show_name[game_type_info_order1[j][2]]
					i_tep = i_tep + 1
					break
				end
			end
		end
	end
end
function SetRoomButtonEvent1(gtk)
	if gtk == "kTeam" then --团队竞技模式
    	L_FightTeam.create_source_room_option.game_type = "kTeam"
		state:RoomChangeOption(L_FightTeam.create_source_room_option)
		matching_id = 1
	elseif gtk == "kTeamDeathMatch" then --歼灭
    	L_FightTeam.create_source_room_option.game_type = "kTeamDeathMatch"
		state:RoomChangeOption(L_FightTeam.create_source_room_option)
		matching_id = 2
	elseif gtk == "kCommonZombieMode" then --生化
		L_FightTeam.create_source_room_option.game_type = "kCommonZombieMode"
		state:RoomChangeOption(L_FightTeam.create_source_room_option)
		matching_id = 3
	else
		L_FightTeam.create_source_room_option.game_type = -1
		state:RoomChangeOption(L_FightTeam.create_source_room_option)
		matching_id = 0
	end
end


match_time = Gui.Create()
{
	Gui.Control "root"
	{
		Size = Vector2(1124, 600),
		Location = Vector2(2, 140),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/pipei/loadingmap_level_train_auto.tga", Vector4(0, 0, 0, 0)),
		},
		Gui.Label "matching_mode"
		{
			Size = Vector2(200,40),
			Text = lang:GetText(" "),
			FontSize = 20,
			TextColor = ARGB(255, 255, 255, 255),
			Location = Vector2(458, -7),
			TextAlign = "kAlignCenterMiddle",
		},
		Gui.Label "t_Time"
		{
			Size = Vector2(530,80),
			Text = lang:GetText("等待时间   秒"),
			FontSize = 20,
			TextColor = ARGB(255, 255, 255, 255),
			Location = Vector2(302, 452),
			TextAlign = "kAlignCenterMiddle",
		},
		Gui.TimeControl "Timer"
		{
			Size = Vector2(5,5),
			Dock = "kDockCenter",
			BackgroundColor = ARGB(0, 255, 255, 255),
			EventTimeOut = function(sender, e)
				match_time.t_Time.Text = pipeiTimes1 
				pipeiTimes1 = pipeiTimes1 + 1
				match_time.t_Time.Text = lang:GetText("等待时间")..pipeiTimes1..lang:GetText("秒")
				if true then
					match_time.Timer:CleanAll()
					match_time.Timer:AddTime(1)
				end
			end
		},
		Gui.Button "b_exit"
		{
			Size = Vector2(140,64),
			Location = Vector2(488, 514),
			BackgroundColor = ARGB(255, 255, 255, 255),
			TextColor = ARGB(255, 226, 217, 208),
			TextAlign = "kAlignCenterMiddle",
			DisabledTextColor = ARGB(255, 37, 37, 37),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/pipei/lb_battlefield_button_auto_cancle_normal.dds", Vector4(0, 0, 0, 0)),
				HoverImage = Gui.Image("LobbyUI/pipei/lb_battlefield_button_auto_cancle_hover.dds", Vector4(0, 0, 0, 0)),
				DownImage = Gui.Image("LobbyUI/pipei/lb_battlefield_button_auto_cancle_down.dds", Vector4(0, 0, 0, 0)),
				DisabledImage = Gui.Image("LobbyUI/pipei/lb_battlefield_button_auto_cancle_disabled.dds", Vector4(0, 0, 0, 0)),
			},
			EventClick = function()
                state:RequestCancelMatching()
			end
		},
	}
}
function ShowMatching_Time()
	matchTime_window = ModalWindow.GetNew()
	matchTime_window.root.Size = Vector2(1126, 738)
	matchTime_window.screen.AllowEscToExit = false
	match_time.root.Parent = matchTime_window.root
	
	pipeiTimes1 = 1
	match_time.t_Time.Text = pipeiTimes1
	match_time.t_Time.Text = lang:GetText("等待时间")..pipeiTimes1..lang:GetText("秒")
	if matching_id == 0 then
		match_time.matching_mode.Text = lang:GetText("随机模式")
	elseif matching_id == 1 then
		match_time.matching_mode.Text = lang:GetText("团队模式")
	elseif matching_id == 2 then
		match_time.matching_mode.Text = lang:GetText("歼灭模式")
	elseif matching_id == 3 then
		match_time.matching_mode.Text = lang:GetText("生化模式")
	end
	match_time.Timer:CleanAll()
	match_time.Timer:AddTime(1)
end
function HideMatching_Time()
	if matchTime_window then
		matchTime_window:Close()
		matchTime_window = nil
	end
end
function setup_match_game_mode1(cbx, flag)
	cbx.Enable = true
	local room_info=state:GetSelfRoomInfo()
	local room_option = ptr_cast(room_info.option)
	local index = 0
	local info = state:GetServerInfo(game.ClientAddress.server_id - 1,false)
	local gametype_limit_old = L_PushCmd.Split(info.gametype_limit,";")	
	local gametype_limit = L_PushCmd.Split(gametype_limit_old[1],",")
	local gametype_commend = L_PushCmd.Split(gametype_limit_old[2],",")
	local gametype_new = L_PushCmd.Split(gametype_limit_old[3],",")
	local gametype_new_com = L_PushCmd.Split(gametype_limit_old[4],",")
	SetModeState_match(gametype_new_com,gametype_new,gametype_commend,gametype_limit)
	cbx:RemoveAll()
	for i=1, #setting_mode1 do
		if(setting_mode1[i][3] == 0) then
			cbx:AddItem(setting_mode1[i][2])
		else
			cbx:AddItemWithIcon(setting_mode1[i][2],setting_mode1[i][3] - 1)
		end
		
		if flag and (setting_mode1[i][1] == "kBossPVE" or setting_mode1[i][1] == "kAdvenceMode") then
			cbx:SetItemDisable(i-2, true)
		end
		
		if room_option.game_type == setting_mode1[i][1] then
			index = i - 2
		end
	end
	
	if flag then
		cbx.SelectedIndex = index
	else
		cbx.SelectedIndex = 0
	end
	function cbx:EventItemSelected(sender, e)
		local index = self.SelectedIndex
		SetRoomButtonEvent1(setting_mode1[index + 1][1])
	end
end