module("L_TimeSell", package.seeall)

local view_TimeSell_window_ui = nil
local TimeSell_Window =  nil

local SellBeginTime  = 0
local my_coin_num = {0,0,0} --我剩余的黄金卡，勋章数量
local my_now_nums = {0,0,0} --我的出价
local coin_data = {0,0,0} --出价单位
local add_time_decrease = {10,10,10}
local add_time_text = {nil,nil,nil}
function CreateSellAdd(x,y,index)
	local title = nil
	local money = nil
	if index == 1 then
		title = lang:GetText("稀有宝箱")
		-- money = lang:GetText("黄金卡")
	elseif index == 2 then
		title = lang:GetText("卓越宝箱")
		-- money = lang:GetText("黄金卡")
	elseif index == 3 then
		title = lang:GetText("精良宝箱")
		-- money = lang:GetText("勋章")
	end
	return Gui.Control	("sell_add_"..index)
		{
			Size = Vector2(520,187),
			Location = Vector2(x,y),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/WarZone/Present/ib_gift_blockbox_bg_04.dds", Vector4(114,72,129,33)),
			},
			Gui.Label
			{
				Size = Vector2(300, 22),
				Location = Vector2(15, 10),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Text = title,
				FontSize = 20,
				TextAlign = "kAlignLeftMiddle",
				TextColor = ARGB(255, 37, 37, 37),
			},
			
			Gui.Label
			{
				Size = Vector2(100, 20),
				Location = Vector2(330, 10),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Text = lang:GetText("我的出价："),
				FontSize = 18,
				TextAlign = "kAlignLeftMiddle",
				TextColor = ARGB(255, 255, 205, 69),
			},
			
			Gui.Label ("my_nums_black_"..index)
			{
				Size = Vector2(100, 20),
				Location = Vector2(432, 12),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Text = 1,
				FontSize = 18,
				TextAlign = "kAlignCenterMiddle",
				TextColor = ARGB(255, 0, 0, 0),
			},
			
			Gui.Label ("my_nums_"..index)
			{
				Size = Vector2(100, 20),
				Location = Vector2(430, 10),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Text = 1,
				FontSize = 18,
				TextAlign = "kAlignCenterMiddle",
				TextColor = ARGB(255, 254, 169, 85),
			},
			
			Gui.Control 
			{
				Location = Vector2(14, 50),
				Size = Vector2(100, 100),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_slot.dds", Vector4(0, 0, 0, 0)),
				},
				Gui.Control 
				{
					Location = Vector2(6, 6),
					Size = Vector2(88, 88),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/time_sell/buylimit_box_"..index..".tga", Vector4(0, 0, 0, 0)),
					},
				},
			},
			Gui.Label
			{
				Size = Vector2(200, 20),
				Location = Vector2(130, 55),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Text = lang:GetText("剩余数量"),
				FontSize = 16,
				TextAlign = "kAlignLeftMiddle",
				TextColor = ARGB(255, 255, 133, 0),
			},
			Gui.Label ("item_nums_"..index)
			{
				Size = Vector2(100, 20),
				Location = Vector2(240, 55),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Text = 0,
				FontSize = 16,
				TextAlign = "kAlignCenterMiddle",
				TextColor = ARGB(255, 255, 205, 69),
			},
			Gui.Label
			{
				Size = Vector2(200, 20),
				Location = Vector2(130, 85),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Text = lang:GetText("最低价"),
				FontSize = 16,
				TextAlign = "kAlignLeftMiddle",
				TextColor = ARGB(255, 255, 133, 0),
				Visible = false,
			},
			Gui.Label ("least_nums_"..index)
			{
				Size = Vector2(100, 20),
				Location = Vector2(240, 85),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Text = 500,
				FontSize = 16,
				TextAlign = "kAlignCenterMiddle",
				TextColor = ARGB(255, 255, 205, 69),
				Visible = false,
			},
			Gui.Label
			{
				Size = Vector2(200, 20),
				Location = Vector2(320, 85),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Text = money,
				FontSize = 16,
				TextAlign = "kAlignLeftMiddle",
				TextColor = ARGB(255, 255, 133, 0),
				Visible = false,
			},
			Gui.Label
			{
				Size = Vector2(200, 20),
				Location = Vector2(130, 115),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Text = lang:GetText("最低价"),
				FontSize = 16,
				TextAlign = "kAlignLeftMiddle",
				TextColor = ARGB(255, 255, 133, 0),
			},			
			Gui.Label ("valid_nums_"..index)
			{
				Size = Vector2(100, 20),
				Location = Vector2(240, 115),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Text = 700,
				FontSize = 16,
				TextAlign = "kAlignCenterMiddle",
				TextColor = ARGB(255, 255, 205, 69),
			},
			Gui.Label ("coin_low_data"..index)
			{
				Size = Vector2(200, 20),
				Location = Vector2(320, 115),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Text = lang:GetText("黄金卡"),
				FontSize = 16,
				TextAlign = "kAlignLeftMiddle",
				TextColor = ARGB(255, 255, 133, 0),
			},
			Gui.Label
			{
				Size = Vector2(200, 20),
				Location = Vector2(130, 145),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Text = lang:GetText("最高价"),
				FontSize = 16,
				TextAlign = "kAlignLeftMiddle",
				TextColor = ARGB(255, 255, 133, 0),
			},
			Gui.Label ("most_nums_"..index)
			{
				Size = Vector2(100, 20),
				Location = Vector2(240, 145),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Text = 1000,
				FontSize = 16,
				TextAlign = "kAlignCenterMiddle",
				TextColor = ARGB(255, 255, 205, 69),
			},
			Gui.Label ("coin_high_data"..index)
			{
				Size = Vector2(200, 20),
				Location = Vector2(320, 145),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Text = lang:GetText("黄金卡"),
				FontSize = 16,
				TextAlign = "kAlignLeftMiddle",
				TextColor = ARGB(255, 255, 133, 0),
			},
			
			Gui.Button 
			{
				Size = Vector2(98, 30),
				Location = Vector2(16, 147),
				BackgroundColor = ARGB(255, 255, 255, 255),
				TextColor = ARGB(255, 0, 0, 0),
				HighlightTextColor = ARGB(255, 0, 0, 0),
				-- Padding = Vector4(0, 0, 0, 5),
				FontSize = 16,
				TextAlign = "kAlignCenterMiddle",
				Text = lang:GetText("查看"),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_v2_01_normal.dds", Vector4(24, 20, 20, 12)),
					HoverImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_v2_01_hover.dds", Vector4(24, 20, 20, 12)),
					DownImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_v2_01_down.dds", Vector4(24, 20, 20, 12)),
					DisabledImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_v2_01_disabled.dds", Vector4(24, 20, 20, 12)),
				},									
				EventClick = function()
					show_jiangli(index)
				end,
			},
			
			Gui.TimeControl ("Event_"..index)
			{
				Size = Vector2(5, 5),
				BackgroundColor = ARGB(0, 255, 255, 255),
				EventTimeOut = function(sender, e)
					if add_time_text[index] == nil then
						add_time_text[index] = view_TimeSell_window_ui["bt_add_"..index].Text
					end
					add_time_decrease[index] = add_time_decrease[index] - 1
					view_TimeSell_window_ui["bt_add_"..index].Text = add_time_decrease[index]
					if add_time_decrease[index] == 0 then
						view_TimeSell_window_ui["bt_add_"..index].Text = lang:GetText("出价")
						view_TimeSell_window_ui["bt_add_"..index].Enable = true
						add_time_text[index] = nil
						add_time_decrease[index] = 10
					else
						view_TimeSell_window_ui["Event_"..index]:CleanAll()
						view_TimeSell_window_ui["Event_"..index]:AddTime(1)
					end
				end
			},
			
			Gui.Button ("bt_add_"..index)
			{
				Size = Vector2(104, 56),
				Location = Vector2(404, 118),
				BackgroundColor = ARGB(255, 255, 255, 255),
				TextColor = ARGB(255, 37, 37, 37),
				HighlightTextColor = ARGB(255, 37, 37, 37),
				FontSize = 20,
				TextAlign = "kAlignCenterMiddle",
				Text = lang:GetText("出价"),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/time_sell/lb_buylimit_button1_normal.dds", Vector4(0, 0, 0, 0)),
					HoverImage = Gui.Image("LobbyUI/ShoppingMall/time_sell/lb_buylimit_button1_hover.dds", Vector4(0, 0, 0, 0)),
					DownImage = Gui.Image("LobbyUI/ShoppingMall/time_sell/lb_buylimit_button1_down.dds", Vector4(0, 0, 0, 0)),
					DisabledImage = Gui.Image("LobbyUI/ShoppingMall/time_sell/lb_buylimit_button1_disabled.dds", Vector4(0, 0, 0, 0)),
				},									
				EventClick = function()
					ShowAddPay(index)
					my_index = index
				end,
			},
		}
end

view_TimeSell_window =
{	
	Gui.Control "ctrl_view_timesell_window"
	{
		Size = Vector2(900,727),
		BackgroundColor = ARGB(0, 255, 255, 255),
		Dock = "kDockCenter",
		
		Gui.Control
		{	
			Size = Vector2(900, 727),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Dock = "kDockCenter",
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_contact_bg1_01.dds", Vector4(163,163,53,53)),
			},
			Gui.Control
			{							
				Size = Vector2(860, 678),
				Location = Vector2(20, 26),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg3.dds", Vector4(22, 22, 22, 22)),
				},
				
				Gui.Label
				{
					Size = Vector2(200, 32),
					Location = Vector2(20, 20),
					BackgroundColor = ARGB(0, 255, 255, 255),
					Text = lang:GetText("限时抢购"),
					FontSize = 22,
					TextAlign = "kAlignLeftMiddle",
					TextColor = ARGB(255, 255, 205, 69),
				},
				
				Gui.Control
				{
					Size = Vector2(289,613),
					Location = Vector2(15, 52),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_task_bg_6.dds", Vector4(50, 50, 50, 50)),
					},
					Gui.Control
					{
						Size = Vector2(269,115),
						Location = Vector2(9, 10),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_contact_bg_normal.dds", Vector4(20, 20, 20, 20)),
						},
						Gui.Label "lb_time"
						{
							Size = Vector2(150, 60),
							Location = Vector2(0, 0),
							BackgroundColor = ARGB(0, 255, 255, 255),
							Text = lang:GetText("本次限时抢购\n剩余时间"),
							FontSize = 14,
							TextAlign = "kAlignCenterMiddle",
							TextColor = ARGB(255, 255, 133, 0),
						},
						
						Gui.Label "lb_time_day"
						{
							Size = Vector2(120, 60),
							Location = Vector2(150, 0),
							BackgroundColor = ARGB(0, 255, 255, 255),
							Text = lang:GetText("3天"),
							FontSize = 24,
							TextAlign = "kAlignCenterMiddle",
							TextColor = ARGB(255, 255, 133, 0),
						},
						
						Gui.Control "date"
						{
							Size = Vector2(269,48),
							Location = Vector2(0, 60),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Visible = false,
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/time_sell/lb_buylimit_bg1.dds", Vector4(20, 20, 20, 20)),
							},
							Gui.Control 
							{
								Location = Vector2(24, 10),
								Size = Vector2(28, 28),
								BackgroundColor = ARGB(255, 255, 255, 255),
								Skin = Gui.ControlSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_number_bg.dds", Vector4(0, 0, 0, 0)),
								},
							},
							Gui.Control 
							{
								Location = Vector2(44, 10),
								Size = Vector2(28, 28),
								BackgroundColor = ARGB(255, 255, 255, 255),
								Skin = Gui.ControlSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_number_bg.dds", Vector4(0, 0, 0, 0)),
								},
							},
							Gui.Control 
							{
								Location = Vector2(64, 10),
								Size = Vector2(28, 28),
								BackgroundColor = ARGB(255, 255, 255, 255),
								Skin = Gui.ControlSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_number_bg.dds", Vector4(0, 0, 0, 0)),
								},
							},
							Gui.Control 
							{
								Location = Vector2(84, 10),
								Size = Vector2(28, 28),
								BackgroundColor = ARGB(255, 255, 255, 255),
								Skin = Gui.ControlSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_number_bg.dds", Vector4(0, 0, 0, 0)),
								},
							},
							Gui.Control 
							{
								Location = Vector2(131, 10),
								Size = Vector2(28, 28),
								BackgroundColor = ARGB(255, 255, 255, 255),
								Skin = Gui.ControlSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_number_bg.dds", Vector4(0, 0, 0, 0)),
								},
							},
							Gui.Control 
							{
								Location = Vector2(151, 10),
								Size = Vector2(28, 28),
								BackgroundColor = ARGB(255, 255, 255, 255),
								Skin = Gui.ControlSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_number_bg.dds", Vector4(0, 0, 0, 0)),
								},
							},
							Gui.Control 
							{
								Location = Vector2(196, 10),
								Size = Vector2(28, 28),
								BackgroundColor = ARGB(255, 255, 255, 255),
								Skin = Gui.ControlSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_number_bg.dds", Vector4(0, 0, 0, 0)),
								},
							},
							Gui.Control 
							{
								Location = Vector2(216, 10),
								Size = Vector2(28, 28),
								BackgroundColor = ARGB(255, 255, 255, 255),
								Skin = Gui.ControlSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_number_bg.dds", Vector4(0, 0, 0, 0)),
								},
							},
							
							Gui.Control 
							{
								Location = Vector2(114, 15),
								Size = Vector2(17, 21),
								BackgroundColor = ARGB(255, 255, 255, 255),
								Skin = Gui.ControlSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/time_sell/lb_buylimit_colon.dds", Vector4(0, 0, 0, 0)),
								},
							},
							Gui.Control 
							{
								Location = Vector2(181, 15),
								Size = Vector2(17, 21),
								BackgroundColor = ARGB(255, 255, 255, 255),
								Skin = Gui.ControlSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/time_sell/lb_buylimit_colon.dds", Vector4(0, 0, 0, 0)),
								},
							},
						},	
						
						Gui.Control "time"
						{
							Size = Vector2(269,48),
							Location = Vector2(0, 60),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Visible = false,
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/time_sell/lb_buylimit_bg1.dds", Vector4(20, 20, 20, 20)),
							},
							Gui.Control 
							{
								Location = Vector2(34, 10),
								Size = Vector2(28, 28),
								BackgroundColor = ARGB(255, 255, 255, 255),
								Skin = Gui.ControlSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_number_bg.dds", Vector4(0, 0, 0, 0)),
								},
							},
							Gui.Control 
							{
								Location = Vector2(54, 10),
								Size = Vector2(28, 28),
								BackgroundColor = ARGB(255, 255, 255, 255),
								Skin = Gui.ControlSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_number_bg.dds", Vector4(0, 0, 0, 0)),
								},
							},
							
							Gui.Control 
							{
								Location = Vector2(74, 10),
								Size = Vector2(28, 28),
								BackgroundColor = ARGB(255, 255, 255, 255),
								Skin = Gui.ControlSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_number_bg.dds", Vector4(0, 0, 0, 0)),
								},
							},
							Gui.Control 
							{
								Location = Vector2(121, 10),
								Size = Vector2(28, 28),
								BackgroundColor = ARGB(255, 255, 255, 255),
								Skin = Gui.ControlSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_number_bg.dds", Vector4(0, 0, 0, 0)),
								},
							},
							Gui.Control 
							{
								Location = Vector2(141, 10),
								Size = Vector2(28, 28),
								BackgroundColor = ARGB(255, 255, 255, 255),
								Skin = Gui.ControlSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_number_bg.dds", Vector4(0, 0, 0, 0)),
								},
							},
							Gui.Control 
							{
								Location = Vector2(186, 10),
								Size = Vector2(28, 28),
								BackgroundColor = ARGB(255, 255, 255, 255),
								Skin = Gui.ControlSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_number_bg.dds", Vector4(0, 0, 0, 0)),
								},
							},
							Gui.Control 
							{
								Location = Vector2(206, 10),
								Size = Vector2(28, 28),
								BackgroundColor = ARGB(255, 255, 255, 255),
								Skin = Gui.ControlSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_number_bg.dds", Vector4(0, 0, 0, 0)),
								},
							},
							
							Gui.Control 
							{
								Location = Vector2(104, 15),
								Size = Vector2(17, 21),
								BackgroundColor = ARGB(255, 255, 255, 255),
								Skin = Gui.ControlSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/time_sell/lb_buylimit_colon.dds", Vector4(0, 0, 0, 0)),
								},
							},
							Gui.Control 
							{
								Location = Vector2(171, 15),
								Size = Vector2(17, 21),
								BackgroundColor = ARGB(255, 255, 255, 255),
								Skin = Gui.ControlSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/time_sell/lb_buylimit_colon.dds", Vector4(0, 0, 0, 0)),
								},
							},
							Gui.TimeControl "Event"
							{
								Size = Vector2(5, 5),
								BackgroundColor = ARGB(0, 255, 255, 255),
								EventTimeOut = function(sender, e)
									SellBeginTime = SellBeginTime - 1
									if view_TimeSell_window_ui and SellBeginTime >= 0 then
										OnUpdateTime()
									end
								end
							},
						},
					},
					Gui.Control
					{
						Size = Vector2(269,427),
						Location = Vector2(9, 137),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_contact_bg_normal.dds", Vector4(20, 20, 20, 20)),
						},
						Gui.Control
						{
							Size = Vector2(269,427),
							Location = Vector2(0, 0),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/Compose/lb_melting_bg_cwlb.dds", Vector4(0,0,0,0)),
							},
							Gui.Label
							{
								Size = Vector2(269, 20),
								Location = Vector2(0, 20),
								BackgroundColor = ARGB(0, 255, 255, 255),
								Text = lang:GetText("抢购规则"),
								FontSize = 18,
								TextAlign = "kAlignCenterMiddle",
								TextColor = ARGB(255, 255, 133, 0),
							},
							Gui.Label "time_sell_des"
							{
								Size = Vector2(265, 400),
								Location = Vector2(5, 50),
								BackgroundColor = ARGB(0, 255, 255, 255),
								Text = lang:GetText("■ 拍卖时间：周六的10：00至16：00\n\n■ 出价相同时，先出价者排名在前\n\n■ 每次成功出价扣除相应的物品个数\n\n■ 拍得物品在拍卖结束后的次日0点\n   发放给各位玩家\n\n■ 出价失败，返还的物品在拍卖结束后\n   的次日0点发放给各位玩家\n\n■ 点击刷新按钮可更新当前最新的报价"),
								FontSize = 14,
								TextAlign = "kAlignLeftTop",
								TextColor = ARGB(255, 255, 205, 69),
							},	
						},
					},
				},
				
				Gui.Control
				{
					Size = Vector2(538,613),
					Location = Vector2(308, 52),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_task_bg_6.dds", Vector4(50, 50, 50, 50)),
					},
					
					CreateSellAdd(8,8,1),
					CreateSellAdd(8,195,2),
					CreateSellAdd(8,385,3),
					
					Gui.TimeControl ("Event_fresh")
					{
						Size = Vector2(5, 5),
						BackgroundColor = ARGB(0, 255, 255, 255),
						EventTimeOut = function(sender, e)
							view_TimeSell_window_ui.b_fresh.Enable = true
						end
					},
					Gui.Button "b_fresh"
					{
						Size = Vector2(143, 35),
						Location = Vector2(358, 574),
						BackgroundColor = ARGB(255, 255, 255, 255),
						TextColor = ARGB(255, 0, 0, 0),
						HighlightTextColor = ARGB(255, 0, 0, 0),
						FontSize = 18,
						TextAlign = "kAlignCenterMiddle",
						Text = lang:GetText("刷新"),
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_v2_01_normal.dds", Vector4(24, 20, 20, 12)),
							HoverImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_v2_01_hover.dds", Vector4(24, 20, 20, 12)),
							DownImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_v2_01_down.dds", Vector4(24, 20, 20, 12)),
							DisabledImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_v2_01_disabled.dds", Vector4(24, 20, 20, 12)),
						},								
						EventClick = function()
							FillTimeSell(false)
							view_TimeSell_window_ui.b_fresh.Enable = false
							view_TimeSell_window_ui.Event_fresh:CleanAll()
							view_TimeSell_window_ui.Event_fresh:AddTime(5)
						end,
					},
				},
			},
		},
		--退出
		Gui.Button
		{
			Size = Vector2(48,48),
			Location = Vector2(840, 10),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_normal.dds", Vector4(10, 10, 10, 10)),
				HoverImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_hover.dds", Vector4(10, 10, 10, 10)),
				DownImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_down.dds", Vector4(10, 10, 10, 10)),
				DisabledImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_disabled.dds", Vector4(0, 0, 0, 0)),	
			},
			EventClick = function()
				HideTimeSellWindow()
			end,
		},
	},
}

add_pay_ui = Gui.Create()
{
	Gui.Control "root"
	{
		Size = Vector2(394,488),
		BackgroundColor = ARGB(0, 255, 255, 255),
		Dock = "kDockCenter",
		
		Gui.Control
		{	
			Size = Vector2(394, 488),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Dock = "kDockCenter",
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_contact_bg1_01.dds", Vector4(163,163,53,53)),
			},
			Gui.Control
			{							
				Size = Vector2(356, 441),
				Location = Vector2(19, 21),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/WarZone/Present/ib_gift_blockbox_bg_04.dds", Vector4(114,72,129,33)),
				},
				Gui.Label
				{
					Size = Vector2(341, 25),
					Location = Vector2(15, 10),
					BackgroundColor = ARGB(0, 255, 255, 255),
					Text = lang:GetText("出价"),
					FontSize = 20,
					TextAlign = "kAlignLeftMiddle",
					TextColor = ARGB(255, 34, 34, 34),
				},
				Gui.Control
				{							
					Size = Vector2(324, 328),
					Location = Vector2(15, 58),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_contact_bg_normal.dds", Vector4(20, 20, 20, 20)),
					},
					Gui.Control
					{							
						Size = Vector2(324, 348),
						Location = Vector2(0, 0),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/Compose/lb_melting_bg_cwlb.dds", Vector4(0,0,0,0)),
						},
						Gui.Control
						{							
							Size = Vector2(317, 227),
							Location = Vector2(4, 10),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_06.dds", Vector4(28, 26, 28, 20)),
							},

							Gui.Label "lb_name"
							{
								Size = Vector2(317, 20),
								Location = Vector2(0, 5),
								BackgroundColor = ARGB(0, 255, 255, 255),
								Text = lang:GetText("黄金卡"),
								FontSize = 16,
								TextAlign = "kAlignCenterMiddle",
								TextColor = ARGB(255, 240, 198, 0),
							},
							Gui.Control 
							{
								Location = Vector2(81, 22),
								Size = Vector2(156, 84),
								BackgroundColor = ARGB(255, 255, 255, 255),
								Skin = Gui.ControlSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_slot.dds", Vector4(42, 42, 20, 20)),
								},
								Gui.Control  "c_pic"
								{
									Location = Vector2(46, 10),
									Size = Vector2(64, 64),
									BackgroundColor = ARGB(255, 255, 255, 255),
									Skin = Gui.ControlSkin
									{
										BackgroundImage = Gui.Image("LobbyUI/ibt_icon/goldCard.tga", Vector4(0, 0, 0, 0)),
										-- medal
									},
								},
							},
							Gui.TextArea "lb_des"
							{
								Size = Vector2(267, 40),
								Location = Vector2(25, 98),
								BackgroundColor = ARGB(0, 255, 255, 255),
								Text = lang:GetText("用来开启黄金宝盒的特定密码卡。"),
								FontSize = 14,
								-- TextAlign = "kAlignCenterMiddle",
								TextColor = ARGB(255, 240, 198, 0),
								Fold = true,
							},
							
							Gui.Label
							{
								Size = Vector2(317, 20),
								Location = Vector2(0, 136),
								BackgroundColor = ARGB(0, 255, 255, 255),
								Text = lang:GetText("你的出价"),
								FontSize = 16,
								TextAlign = "kAlignCenterMiddle",
								TextColor = ARGB(255, 255, 102, 0),
							},
							
							Gui.Button "b_decrease"
							{
								Size = Vector2(28,28),
								Location = Vector2(50, 179),
								BackgroundColor = ARGB(255, 255, 255, 255),
								Text = "-",
								FontSize = 40,
								Padding = Vector4(0, 0, 0, 3),
								TextColor = ARGB(255, 255, 174, 0),
								HighlightTextColor = ARGB(255, 255, 174, 0),
								Skin = Gui.ButtonSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/Compose/lb_fastsettlement_button01_normal.dds", Vector4(0, 0, 0, 0)),
									HoverImage = Gui.Image("LobbyUI/Compose/lb_fastsettlement_button01_hover.dds", Vector4(0, 0, 0, 0)),
									DownImage = Gui.Image("LobbyUI/Compose/lb_fastsettlement_button01_down.dds", Vector4(0, 0, 0, 0)),
									DisabledImage = Gui.Image("LobbyUI/Compose/lb_fastsettlement_button01_disabled.dds", Vector4(0, 0, 0, 0)),
								},
								EventClick = function(Sender ,e)
									if tonumber(add_pay_ui.Tbox_Totle_num.Text) > 0 then
										if tonumber(add_pay_ui.Tbox_Totle_num.Text) > tonumber(view_TimeSell_window_ui["my_nums_"..my_index].Text) then
											add_pay_ui.Tbox_Totle_num.Text = tonumber(add_pay_ui.Tbox_Totle_num.Text) - 1
											if tonumber(add_pay_ui.Tbox_Totle_num.Text) <= tonumber(view_TimeSell_window_ui["my_nums_"..my_index].Text) then
												Sender.Visible = false
											end
										end
										-- add_pay_ui.all_pay.Text = my_now_nums[my_index] + tonumber(add_pay_ui.Tbox_Totle_num.Text)
										-- add_pay_ui.you_pay.Text = add_pay_ui.Tbox_Totle_num.Text
									end
								end,
							},

							Gui.Textbox "Tbox_Totle_num"
							{
								Size = Vector2(156, 35),
								Location = Vector2(80, 177),
								TextColor = ARGB(255, 255, 210, 0),
								FontSize = 24,
								Text = "0",
								MaxLength = 6,
								BackgroundColor = ARGB(255,255,255,255),
								TextPadding = Vector4(72,0,0,0),
								InputNumberOnly = true,
								Skin = Gui.TextboxSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_04.dds", Vector4(12, 0, 12, 0)),
									ActiveImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_04.dds", Vector4(12, 0, 12, 0)),
									DisabledImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_04.dds", Vector4(12, 0, 12, 0)),
								},
								EventTextChanged = function()
									-- if add_pay_ui.Tbox_Totle_num.Text ~= "" then
										-- if string.sub(add_pay_ui.Tbox_Totle_num.Text,1,1) == "0" and add_pay_ui.Tbox_Totle_num.Text ~= "0" then
											-- add_pay_ui.Tbox_Totle_num.Text = string.sub(add_pay_ui.Tbox_Totle_num.Text,2)
											-- return
										-- end
										-- if my_index and my_index ~= 0 then
											-- if tonumber(add_pay_ui.Tbox_Totle_num.Text) > my_coin_num[my_index] then
												-- add_pay_ui.Tbox_Totle_num.Text = my_coin_num[my_index]
												-- return
											-- elseif tonumber(add_pay_ui.Tbox_Totle_num.Text) < my_now_nums[my_index]then
												-- add_pay_ui.Tbox_Totle_num.Text = my_now_nums[my_index]
												-- return
											-- elseif tonumber(add_pay_ui.Tbox_Totle_num.Text) < 0 then
												-- add_pay_ui.Tbox_Totle_num.Text = 0
												-- return
											-- end
											-- -- add_pay_ui.Tbox_Totle_num.Text = tonumber(add_pay_ui.Tbox_Totle_num.Text)
											-- add_pay_ui.you_pay.Text = tonumber(add_pay_ui.Tbox_Totle_num.Text)
											-- add_pay_ui.all_pay.Text = tonumber(add_pay_ui.now_pay.Text) + tonumber(add_pay_ui.Tbox_Totle_num.Text)
											add_pay_ui.Tbox_Totle_num.TextPadding = Vector4(77 - 5*string.len(add_pay_ui.Tbox_Totle_num.Text),0,0,0)
										-- end
									-- else
										-- add_pay_ui.you_pay.Text = 0
										-- add_pay_ui.all_pay.Text = tonumber(add_pay_ui.now_pay.Text)
									-- end
								end,

								EventLeave = function()
									if add_pay_ui.Tbox_Totle_num.Text == "" then
										add_pay_ui.Tbox_Totle_num.Text = 0
										-- add_pay_ui.all_pay.Text = my_now_nums[my_index] + tonumber(add_pay_ui.Tbox_Totle_num.Text)
										-- add_pay_ui.you_pay.Text = add_pay_ui.Tbox_Totle_num.Text
									end
									if my_now_nums[my_index] > tonumber(view_TimeSell_window_ui["most_nums_"..my_index].Text) then
										tmax = my_now_nums[my_index]
									else
										tmax = tonumber(view_TimeSell_window_ui["most_nums_"..my_index].Text)
									end
									print("tmax:"..tmax)
									if tonumber(add_pay_ui.Tbox_Totle_num.Text) < tmax then
										add_pay_ui.Tbox_Totle_num.Text = tmax
										add_pay_ui.b_decrease.Visible = false
									end
								end,
							},

							Gui.Button "b_plus"
							{
								Size = Vector2(28,28),
								Location = Vector2(238, 179),
								BackgroundColor = ARGB(255, 255, 255, 255),
								Text = "+",
								FontSize = 28,
								TextColor = ARGB(255, 255, 174, 0),
								Padding = Vector4(0, 0, 0, 3),
								HighlightTextColor = ARGB(255, 255, 174, 0),
								Skin = Gui.ButtonSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/Compose/lb_fastsettlement_button01_normal.dds", Vector4(0, 0, 0, 0)),
									HoverImage = Gui.Image("LobbyUI/Compose/lb_fastsettlement_button01_hover.dds", Vector4(0, 0, 0, 0)),
									DownImage = Gui.Image("LobbyUI/Compose/lb_fastsettlement_button01_down.dds", Vector4(0, 0, 0, 0)),
									DisabledImage = Gui.Image("LobbyUI/Compose/lb_fastsettlement_button01_disabled.dds", Vector4(0, 0, 0, 0)),
								},
								EventClick = function(Sender,e)
									if tonumber(add_pay_ui.Tbox_Totle_num.Text) - tonumber(add_pay_ui.low_pay.Text)< my_coin_num[my_index] then
										add_pay_ui.Tbox_Totle_num.Text = tonumber(add_pay_ui.Tbox_Totle_num.Text) + 1
										add_pay_ui.b_decrease.Visible = true
										-- add_pay_ui.all_pay.Text = my_now_nums[my_index] + tonumber(add_pay_ui.Tbox_Totle_num.Text)
										-- add_pay_ui.you_pay.Text = add_pay_ui.Tbox_Totle_num.Text
									end
								end,
							},
						},
					
						Gui.Control
						{							
							Size = Vector2(313, 37),
							Location = Vector2(6, 240),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/ToolTips/lb_tooltips_bg_2.dds",Vector4(15, 13, 15, 13)),
							},
							Gui.Label
							{
								Size = Vector2(200, 20),
								Location = Vector2(20, 10),
								BackgroundColor = ARGB(0, 255, 255, 255),
								Text = lang:GetText("当前最低价"),
								FontSize = 20,
								TextAlign = "kAlignLeftMiddle",
								TextColor = ARGB(255, 255, 102, 0),
							},
							Gui.Label "low_pay"
							{
								Size = Vector2(100, 20),
								Location = Vector2(200, 10),
								BackgroundColor = ARGB(0, 255, 255, 255),
								Text = 100,
								FontSize = 20,
								TextAlign = "kAlignLeftMiddle",
								TextColor = ARGB(255, 240, 198, 0),
							},
							-- Gui.Label
							-- {
								-- Size = Vector2(100, 20),
								-- Location = Vector2(80, 10),
								-- BackgroundColor = ARGB(0, 255, 255, 255),
								-- Text = lang:GetText("上次出价"),
								-- FontSize = 16,
								-- TextAlign = "kAlignLeftMiddle",
								-- TextColor = ARGB(255, 255, 102, 0),
							-- },
							-- Gui.Label "now_pay"
							-- {
								-- Size = Vector2(100, 20),
								-- Location = Vector2(200, 10),
								-- BackgroundColor = ARGB(0, 255, 255, 255),
								-- Text = 100,
								-- FontSize = 16,
								-- TextAlign = "kAlignLeftMiddle",
								-- TextColor = ARGB(255, 240, 198, 0),
							-- },
							-- Gui.Label
							-- {
								-- Size = Vector2(100, 20),
								-- Location = Vector2(80, 30),
								-- BackgroundColor = ARGB(0, 255, 255, 255),
								-- Text = lang:GetText("你的出价"),
								-- FontSize = 16,
								-- TextAlign = "kAlignLeftMiddle",
								-- TextColor = ARGB(255, 255, 102, 0),
							-- },
							-- Gui.Label "you_pay"
							-- {
								-- Size = Vector2(100, 20),
								-- Location = Vector2(200, 30),
								-- BackgroundColor = ARGB(0, 255, 255, 255),
								-- Text = 1,
								-- FontSize = 16,
								-- TextAlign = "kAlignLeftMiddle",
								-- TextColor = ARGB(255, 240, 198, 0),
							-- },
							
							-- Gui.Control
							-- {							
								-- Size = Vector2(297, 31),
								-- Location = Vector2(8, 53),
								-- BackgroundColor = ARGB(255, 255, 255, 255),
								-- Skin = Gui.ControlSkin
								-- {
									-- BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/time_sell/lb_buylimit_bg2.dds",Vector4(0, 0, 0, 0)),
								-- },
								-- Gui.Label
								-- {
									-- Size = Vector2(100, 20),
									-- Location = Vector2(102, 5),
									-- BackgroundColor = ARGB(0, 255, 255, 255),
									-- Text = lang:GetText("结果"),
									-- FontSize = 18,
									-- TextAlign = "kAlignLeftMiddle",
									-- TextColor = ARGB(255, 244, 162, 81),
								-- },
								-- Gui.Label "all_pay"
								-- {
									-- Size = Vector2(100, 20),
									-- Location = Vector2(192, 5),
									-- BackgroundColor = ARGB(0, 255, 255, 255),
									-- Text = 150,
									-- FontSize = 18,
									-- TextAlign = "kAlignLeftMiddle",
									-- TextColor = ARGB(255, 255, 202, 87),
								-- },
							-- },
						},	
					
						Gui.Control
						{							
							Size = Vector2(313, 50),
							Location = Vector2(6, 272),
							BackgroundColor = ARGB(0, 255, 255, 255),
							
							Gui.Control
							{							
								Size = Vector2(313, 40),
								Location = Vector2(0, 10),
								BackgroundColor = ARGB(255, 255, 255, 255),
								Skin = Gui.ControlSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/ToolTips/lb_tooltips_bg_2.dds",Vector4(15, 13, 15, 13)),
								},
								Gui.Label
								{
									Size = Vector2(100, 40),
									Location = Vector2(60, 0),
									BackgroundColor = ARGB(0, 255, 255, 255),
									Text = lang:GetText("剩余"),
									FontSize = 16,
									TextAlign = "kAlignCenterMiddle",
									TextColor = ARGB(255, 255, 102, 0),
								},
								
								Gui.Label "left_money"
								{
									Size = Vector2(100, 40),
									Location = Vector2(120, 0),
									BackgroundColor = ARGB(0, 255, 255, 255),
									Text = 100,
									FontSize = 16,
									TextAlign = "kAlignCenterMiddle",
									TextColor = ARGB(255, 240, 198, 0),
								},
								
								Gui.Label "lb_type"
								{
									Size = Vector2(100, 40),
									Location = Vector2(200, 0),
									BackgroundColor = ARGB(0, 255, 255, 255),
									Text = lang:GetText("黄金卡"),
									FontSize = 16,
									TextAlign = "kAlignLeftMiddle",
									TextColor = ARGB(255, 255, 102, 0),
								},
							},	
							Gui.Control "c_type"
							{							
								Size = Vector2(39, 37),
								Location = Vector2(5, 5),
								BackgroundColor = ARGB(255, 255, 255, 255),
								Skin = Gui.ControlSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/time_sell/lb_buylimit_ico_goldcard.dds", Vector4(0,0,0,0)),
								},
							},
						},	
					},	
				},
			
				Gui.Button "b_quickby"
				{
					Size = Vector2(160, 35),
					Location = Vector2(17, 392),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Text = lang:GetText("快速购买"),
					TextColor = ARGB(255, 0, 0, 0),
					Padding = Vector4(0, 0, 0, 5),
					FontSize = 16,
					TextAlign = "kAlignCenterMiddle",
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_v2_01_normal.dds", Vector4(24, 20, 20, 14)),
						HoverImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_v2_01_hover.dds", Vector4(24, 20, 20, 14)),
						DownImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_v2_01_down.dds", Vector4(24, 20, 20, 14)),
						DisabledImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_v2_01_disabled.dds", Vector4(24, 20, 20, 14)),
					},									
					EventClick = function(Sender,e)
						ShowRapidShoppingWin()
					end
				},
				
				Gui.Button
				{
					Size = Vector2(160, 35),
					Location = Vector2(179, 392),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Text = lang:GetText("确定"),
					TextColor = ARGB(255, 0, 0, 0),
					Padding = Vector4(0, 0, 0, 5),
					FontSize = 16,
					TextAlign = "kAlignCenterMiddle",
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_v2_01_normal.dds", Vector4(24, 20, 20, 14)),
						HoverImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_v2_01_hover.dds", Vector4(24, 20, 20, 14)),
						DownImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_v2_01_down.dds", Vector4(24, 20, 20, 14)),
						DisabledImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_v2_01_disabled.dds", Vector4(24, 20, 20, 14)),
					},									
					EventClick = function(Sender,e)
						-- if tonumber(add_pay_ui.you_pay.Text) == 0 then
							-- return
						-- end
						local num = tonumber(add_pay_ui.Tbox_Totle_num.Text) - tonumber(view_TimeSell_window_ui["my_nums_"..my_index].Text)
						if num <= 0 then
							MessageBox.ShowWithConfirm(lang:GetText("你不能以相同的价格出价"))
							return
						end
						MessageBox.ShowWithTwoButtons(lang:GetText("确定要以这个价格出价吗？"),lang:GetText("确定"),lang:GetText("取消"),
										function()
											rpc.safecallload("compete_buy_item", {pid = ptr_cast(game.CurrentState):GetCharacterId(),index = my_index - 1 , amount = num , payMethod = tonumber(coin_data[my_index])},
											function(data)
												if data.result == 0 then
													view_TimeSell_window_ui["my_nums_"..my_index].Text = tonumber(view_TimeSell_window_ui["my_nums_"..my_index].Text) + num
													view_TimeSell_window_ui["my_nums_black_"..my_index].Text = tonumber(view_TimeSell_window_ui["my_nums_"..my_index].Text)
													-- if my_index == 1 or my_index == 2 then
														-- my_coin_num[1] = my_coin_num[1] - num
														-- my_coin_num[2] = my_coin_num[2] - num
													-- elseif my_index == 3 then
														-- my_coin_num[3] = my_coin_num[3] - num	
													-- end
													
													if tonumber(coin_data[my_index]) == 1 then
														for i = 1,3 do
															if tonumber(coin_data[i]) == 1 then
																my_coin_num[i] = my_coin_num[i] - num
															end
														end
													elseif tonumber(coin_data[my_index]) == 2 then
														for i = 1,3 do
															if tonumber(coin_data[i]) == 2 then
																my_coin_num[i] = my_coin_num[i] - num
															end
														end	
													end
													
													my_now_nums[my_index] = my_now_nums[my_index] + num
													view_TimeSell_window_ui["bt_add_"..my_index].Enable = false
													view_TimeSell_window_ui["Event_"..my_index]:CleanAll()
													view_TimeSell_window_ui["Event_"..my_index]:AddTime(1)
													HideAddPay()
												else
													MessageBox.ShowWithTimer(1,data.warning)
												end
											end)
										end,
										nil
										)
					end
				},
			},	
		},
		--退出
		Gui.Button
		{
			Size = Vector2(48,48),
			Location = Vector2(335, 10),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_normal.dds", Vector4(10, 10, 10, 10)),
				HoverImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_hover.dds", Vector4(10, 10, 10, 10)),
				DownImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_down.dds", Vector4(10, 10, 10, 10)),
				DisabledImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_disabled.dds", Vector4(0, 0, 0, 0)),	
			},
			EventClick = function()
				HideAddPay()
			end,
		},
	},
}

--快速购买界面
local Rapid_Shopping_Win = 
{
	Gui.Control "Rapid_Shopping_root"
	{	
		Size = Vector2(1200, 900),
		BackgroundColor = ARGB(0, 255, 255, 255),
		Location = Vector2(0, 0),
		
		Gui.Control
		{	
			Size = Vector2(377, 375),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Dock = "kDockCenter",
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/main_bar01.dds", Vector4(20, 20, 20, 20)),
			},

			Gui.Control
			{	
				Size = Vector2(355, 352),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Location = Vector2(11, 12),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/main_bar02.dds", Vector4(8, 8, 8, 8)),
				},
				
				Gui.Label
				{
					Size = Vector2(353, 35),
					Location = Vector2(0, 0),
					TextColor = ARGB(255, 255, 210, 0),
					FontSize = 18,
					TextAlign = "kAlignLeftMiddle",
					Text = lang:GetText("快速购买"),
					BackgroundColor = ARGB(255,255,255,255),
					TextPadding = Vector4(8,0,0,8),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_onlinetime_bg_5.dds", Vector4(8, 8, 8, 8)),
					},
				},
				
				Gui.Control
				{	
					Size = Vector2(325, 260),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Location = Vector2(16, 39),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_01.dds", Vector4(40, 40, 40, 40)),
					},
					
					Gui.Control
					{	
						Size = Vector2(274, 208),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Location = Vector2(24, 10),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_06.dds", Vector4(32, 28, 32, 50)),
						},
						
						Gui.Label "name"
						{
							Size = Vector2(274, 28),
							Location = Vector2(0, 0),
							TextColor = ARGB(255, 255, 210, 0),
							FontSize = 18,
							TextAlign = "kAlignCenterMiddle",
							Text = lang:GetText("密码卡"),
							BackgroundColor = ARGB(0,255,255,255),
							TextPadding = Vector4(0,0,0,3),
						},
						
						Gui.TextArea "des"
						{
							Size = Vector2(250, 50),
							Location = Vector2(30, 110),
							TextColor = ARGB(255, 255, 210, 0),
							FontSize = 16,
							Readonly = true,
							Fold = true,
							BackgroundColor = ARGB(255,255,255,255),
						},
						
						Gui.Button "btn_left"
						{
							Size = Vector2(20,32),
							Location = Vector2(32, 167),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Skin = Gui.ButtonSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_fanye_button_normal_L.dds", Vector4(0, 0, 0, 0)),
								HoverImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_fanye_button_hover_L.dds", Vector4(0, 0, 0, 0)),
								DownImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_fanye_button_down_L.dds", Vector4(0, 0, 0, 0)),
								DisabledImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_fanye_button_disabled_L.dds", Vector4(0, 0, 0, 0)),
							},
							EventClick = function()
								Rapid_Shopping_Win_ui.Tbox_Totle_num.Text = math.ceil(tonumber(Rapid_Shopping_Win_ui.Tbox_Totle_num.Text)) - 1
							end,
						},
						
						Gui.Textbox "Tbox_Totle_num"
						{
							Size = Vector2(154, 34),
							Location = Vector2(61, 166),
							TextColor = ARGB(255, 255, 210, 0),
							DisabledTextColor = ARGB(255, 255, 210, 0),
							FontSize = 24,
							Text = "1",
							BackgroundColor = ARGB(255,255,255,255),
							TextPadding = Vector4(71,0,0,0),
							InputNumberOnly = true,
							Skin = Gui.TextboxSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_04.dds", Vector4(12, 0, 12, 0)),
								ActiveImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_04.dds", Vector4(12, 0, 12, 0)),
								DisabledImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_04.dds", Vector4(12, 0, 12, 0)),
							},
							
							EventTextChanged = function(sender, e)
								if Rapid_Shopping_Win_ui.Tbox_Totle_num.Text ~= "" then
									if math.ceil(tonumber(Rapid_Shopping_Win_ui.Tbox_Totle_num.Text)) > 300 then
										Rapid_Shopping_Win_ui.Tbox_Totle_num.Text = "300"
										return
									elseif math.ceil(tonumber(Rapid_Shopping_Win_ui.Tbox_Totle_num.Text)) < 1 then
										Rapid_Shopping_Win_ui.Tbox_Totle_num.Text = "1"
										return
									end
									if string.sub(Rapid_Shopping_Win_ui.Tbox_Totle_num.Text,1,1) == "0" then
										Rapid_Shopping_Win_ui.Tbox_Totle_num.Text = string.sub(Rapid_Shopping_Win_ui.Tbox_Totle_num.Text,2)
										return
									end
									Rapid_Shopping_Win_ui.Tbox_Totle_num.TextPadding = Vector4(77 - 6*string.len(Rapid_Shopping_Win_ui.Tbox_Totle_num.Text),0,0,0)
								end
								SetHummerTotalMoney()
							end,
							
							EventLeave = function()
								if Rapid_Shopping_Win_ui.Tbox_Totle_num.Text == "" then
									Rapid_Shopping_Win_ui.Tbox_Totle_num.Text = 1
								end
							end,
							
							EventValueNoNumber = function()
								Rapid_Shopping_Win_ui.lab_timer_ctr:Show()
							end,
						},
						
						Gui.Button "btn_right"
						{
							Size = Vector2(20,32),
							Location = Vector2(223, 167),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Skin = Gui.ButtonSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_fanye_button_normal_R.dds", Vector4(0, 0, 0, 0)),
								HoverImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_fanye_button_hover_R.dds", Vector4(0, 0, 0, 0)),
								DownImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_fanye_button_down_R.dds", Vector4(0, 0, 0, 0)),
								DisabledImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_fanye_button_disabled_R.dds", Vector4(0, 0, 0, 0)),
							},
							EventClick = function()
								Rapid_Shopping_Win_ui.Tbox_Totle_num.Text = math.ceil(tonumber(Rapid_Shopping_Win_ui.Tbox_Totle_num.Text)) + 1
							end,
						},
					},
					
					Gui.Label
					{
						Size = Vector2(110, 28),
						Location = Vector2(25, 220),
						TextColor = ARGB(255, 255, 210, 0),
						FontSize = 18,
						TextAlign = "kAlignCenterMiddle",
						Text = lang:GetText("您总共要支付"),
						BackgroundColor = ARGB(0,255,255,255),
						TextPadding = Vector4(0,0,0,3),
					},
					
					Gui.Label "Total_money"
					{
						Size = Vector2(118, 28),
						Location = Vector2(137, 220),
						TextColor = ARGB(255, 255, 210, 0),
						FontSize = 18,
						TextAlign = "kAlignCenterMiddle",
						Text = "0",
						BackgroundColor = ARGB(255,255,255,255),
						TextPadding = Vector4(0,0,0,3),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_03.dds", Vector4(8, 8, 8, 8)),
						},
					},
					
					Gui.Label
					{
						Size = Vector2(80, 28),
						Location = Vector2(257, 220),
						TextColor = ARGB(255, 255, 210, 0),
						FontSize = 18,
						TextAlign = "kAlignLeftMiddle",
						Text = lang:GetText("FC点"),
						BackgroundColor = ARGB(0,255,255,255),
						TextPadding = Vector4(0,0,0,3),
					},
					
					Gui.Label "lab_timer_ctr"
					{
						Size = Vector2(116,35),
						Location = Vector2(100, 207),
						BackgroundColor = ARGB(255, 255, 255, 255),
						TextColor = ARGB(255, 0, 0, 0),
						Visible = false,
						UseTimer = true,
						DisplayTime = 1,
						FontSize = 12,
						TextAlign = "kAlignCenterMiddle",
						Text = lang:GetText("只能输入数字0～9"),
						TextPadding = Vector4(0,8,0,0),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_05.dds", Vector4(37, 18, 14, 12)),
						},
						
						EventClose = function()
							
						end
					},
				},
				
				Gui.Button
				{
					Size = Vector2(124,44),
					Location = Vector2(113, 305),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Text = lang:GetText("购 买"),
					TextColor = ARGB(255, 229, 255, 252),
					TextAlign = "kAlignCenterMiddle",
					HighlightTextColor = ARGB(255, 229, 255, 252),
					Padding = Vector4(0, 0, 0, 5),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_onlinetime_button_2_normal.dds", Vector4(0, 0, 0, 0)),
						HoverImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_onlinetime_button_2_hover.dds", Vector4(0, 0, 0, 0)),
						DownImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_onlinetime_button_2_down.dds", Vector4(0, 0, 0, 0)),
						DisabledImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_onlinetime_button_2_disabled.dds", Vector4(0, 0, 0, 0)),
					},
					EventClick = function()
						local args = {num = Rapid_Shopping_Win_ui.Tbox_Totle_num.Text, pid = ptr_cast(game.CurrentState):GetCharacterId(), sid = 4879}
						local keynum = tonumber(Rapid_Shopping_Win_ui.Tbox_Totle_num.Text)
						rpc.safecall("shop_fast_buy", args,
						function(data)
							if data.result == 0 then
								MessageBox.ShowWithTwoButtons(lang:GetText("你的FC点不足，请充值"),lang:GetText("充值"),lang:GetText("取消"),
														function()
															gui:ShowIE()
														end,
														nil
														)
							else
								MessageBox.ShowWithTimer(1,lang:GetText("购买成功"))
								HideRapidShoppingWin()
								my_coin_num[1] = my_coin_num[1] + keynum
								my_coin_num[2] = my_coin_num[2] + keynum
								add_pay_ui.left_money.Text = add_pay_ui.left_money.Text + keynum
								add_pay_ui.b_plus.Enable = true
								add_pay_ui.b_decrease.Enable = true
								add_pay_ui.Tbox_Totle_num.Enable = true
							end
						end)
					end,
				},
			},
		},
		
		Gui.ItemBoxBtn"itembox_hummer"
		{
			Style = "Gui.ItemBoxBtn_ib",
			Size = Vector2(153,79),
			Location = Vector2(522,353),--38 10
			--BtnLocation = Vector2(45, 72),
			--BtnText = lang:GetText("购买"),
			--Enable = false,
			BackgroundColor = ARGB(255,255,255,255),
			Skin = Gui.ItemBoxBtnSkin
			{
				NeutralNormalImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_02.dds", Vector4(0, 0, 0, 0)),
				--NeutralHoverImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_02.dds", Vector4(0, 0, 0, 0)),
				NeutralSelectedImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_02.dds", Vector4(0, 0, 0, 0)),
				NeutralDisabledImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_02.dds", Vector4(0, 0, 0, 0)),
			},
		},
		--退出
		Gui.Button
		{
			Size = Vector2(48,48),
			Location = Vector2(743, 270),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_normal.dds", Vector4(10, 10, 10, 10)),
				HoverImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_hover.dds", Vector4(10, 10, 10, 10)),
				DownImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_down.dds", Vector4(10, 10, 10, 10)),
				DisabledImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_disabled.dds", Vector4(0, 0, 0, 0)),	
			},
			EventClick = function()
				HideRapidShoppingWin()
			end,
		},
	},
}

function CreateJiangliBTN(list,line,index)
	return Gui.ItemBoxBtn
	{
		Style = "Gui.ItemBoxBtn_ib",
		Size = Vector2(100,100),
		Location = Vector2(106*list,106*line),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Skin = Gui.ItemBoxBtnSkin
		{
			NeutralNormalImage = Gui.Image("LobbyUI/ShoppingMall/open_box/lb_gift_biew_bg2.dds", Vector4(0, 0, 0, 0)),
			NeutralHoverImage = Gui.Image("LobbyUI/ShoppingMall/vip_chest/lb_vipgifts_slot_flash.dds", Vector4(0, 0, 0, 0)),
			NeutralSelectedImage = Gui.Image("LobbyUI/ShoppingMall/open_box/lb_gift_select_bg2.dds", Vector4(0, 0, 0, 0)),
			NeutralDisabledImage = Gui.Image("LobbyUI/ShoppingMall/vip_chest/lb_vipgifts_slot_01_disabled.dds", Vector4(0, 0, 0, 0)),
		},
		Padding = Vector4(-5,-5,-5,-5),
		EventSelected = function(sender, e)
			if jiangli_ui and sender.Loading == false then
				for i = 1, 9 do
					local ibbtn = ptr_cast(jiangli_ui.ctr_persent:GetChildByIndex(i - 1))
					if i == index then
						ibbtn.Selected = true
					else
						ibbtn.Selected = false
					end
				end
			end		
		end,
		EventMouseEnter = function(sender, e)
			L_ToolTips.FillToolTipsVIPPresent(index, jiangli_window.root, jiangli_list)
		end,
		EventToolTipsShow = function(sender, e)
			if jiangli_list[index] then
				local loc = sender.Location + sender.Parent.Location + sender.Parent.Parent.Location + sender.Parent.Parent.Parent.Location + sender.Parent.Parent.Parent.Parent.Location
				L_ToolTips.ShowToolTipsShowWindow(sender,Vector2(1200, 900), loc)
			end
		end,
		EventMouseLeave = function(sender, e)
			L_ToolTips.HideToolTipsWindow()
		end,
	}
end

jiangli =
{	
	Gui.Control "ctrl_view_jiangli_window"
	{
		Size = Vector2(1200,900),
		BackgroundColor = ARGB(0, 255, 255, 255),
		 Dock = "kDockCenter",
		
		Gui.Control
		{	
			--Size = Vector2(379, 480),
			Size = Vector2(384,480),
			Dock = "kDockCenter",
			BackgroundColor = ARGB(255, 255, 255, 255),
			Location = Vector2(0, 0),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/open_box/main_bar01.dds", Vector4(20, 20, 20, 20)),
			},
			Gui.Control
			{
				Size = Vector2(354,461),
				--Location = Vector2(12,9),
				Dock = "kDockCenter",
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/open_box/main_bar02.dds", Vector4(20,20,20,20)),
				},					
				Gui.Label 
				{
					Size = Vector2(354, 32),
					Location = Vector2(0, 40),
					BackgroundColor = ARGB(0, 255, 255, 255),
					Text = lang:GetText("请选择你将获得奖励"),
					FontSize = 18,
					Font = "simhei",
					TextAlign = "kAlignCenterMiddle",
					TextColor = ARGB(255, 127, 127, 127),
				},
				Gui.Control
				{
					Size = Vector2(335,330),
					Location = Vector2(9, 67),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/open_box/main_bar03.dds", Vector4(20,20,20,20)),
					},
					Gui.Control "ctr_persent"
					{
						Size = Vector2(848,424),
						Location = Vector2(11,10),
						BackgroundColor = ARGB(0, 255, 255, 255),
						
						CreateJiangliBTN(0,0,1),
						CreateJiangliBTN(1,0,2),
						CreateJiangliBTN(2,0,3),
						
						CreateJiangliBTN(0,1,4),
						CreateJiangliBTN(1,1,5),
						CreateJiangliBTN(2,1,6),
						
						CreateJiangliBTN(0,2,7),
						CreateJiangliBTN(1,2,8),
						CreateJiangliBTN(2,2,9),
					},
				},
				--关闭
				Gui.Button "lihe_btn"
				{
					Size = Vector2(200,44),
					Location = Vector2(77, 407),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Text = lang:GetText("关闭"),
					TextColor = ARGB(255, 229, 255, 252),
					TextAlign = "kAlignCenterMiddle",
					HighlightTextColor = ARGB(255, 229, 255, 252),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_normal.dds", Vector4(0, 0, 0, 0)),
						HoverImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_hover.dds", Vector4(0, 0, 0, 0)),
						DownImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_down.dds", Vector4(0, 0, 0, 0)),
						DisabledImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_disabled.dds", Vector4(0, 0, 0, 0)),
					},				
					EventClick = function(Sender ,e)
						HideViewJiangliWindow()
					end
				},
			},
			Gui.Control
			{
				Size = Vector2(356,52),
				Location = Vector2(13, 0),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/open_box/title.dds", Vector4(0,0,0,0)),
				},
			},
			Gui.Button 
			{
				Size = Vector2(48, 48),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Location = Vector2(332, 0),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_normal.dds", Vector4(10, 10, 10, 10)),
					HoverImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_hover.dds", Vector4(10, 10, 10, 10)),
					DownImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_down.dds", Vector4(10, 10, 10, 10)),
					DisabledImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_disabled.dds", Vector4(0, 0, 0, 0)),					
				},
				EventClick = function()
					HideViewJiangliWindow()
				end
			},
		},
	},
}


function show()
	ShowTimeSellWindow()
end

function ShowTimeSellWindow()
	if view_TimeSell_window_ui == nil then
		view_TimeSell_window_ui = Gui.Create()(view_TimeSell_window)
	end
	if TimeSell_Window and TimeSell_Window.screen then
		TimeSell_Window.screen.Visible = false
	end
	TimeSell_Window = ModalWindow.GetNew("view_TimeSell_window_ui")
	TimeSell_Window.screen.AllowEscToExit = false
	TimeSell_Window.screen.Visible = false
	TimeSell_Window.root.Size = Vector2(1200,900)
	TimeSell_Window.screen.EventEscPressed = HideTimeSellWindow
	view_TimeSell_window_ui.ctrl_view_timesell_window.Parent = TimeSell_Window.root
	
	if TimeSell_Window and TimeSell_Window.screen then
		TimeSell_Window.screen.Visible = true
		gui.EventEscPressed = HideTimeSellWindow
	end
	FillTimeSell(true)
end

function FillTimeSell(flag)
	local time_date = ChangeDate(config:GetTimeSellDate())
	time_date = " "..lang:GetText(time_date).." "
	local time_start = config:GetTimeSellStart()
	local time_start_date = ChangeDate(config:GetTimeSellStartDate())
	local time_end = config:GetTimeSellEnd()
	local time_end_date = ChangeDate(config:GetTimeSellEndDate())
	time_end_date = " "..lang:GetText(time_end_date).." "
	local time_gift_h = config:GetTimeSellGiftH()
	local time_gift_m = config:GetTimeSellGiftM()
	local t = ""
	coin_data = L_PushCmd.Split(config:GetQuickSellData(),",")
	if time_gift_m < 10 then
		time_gift_m = "0"..time_gift_m
	end
	t = time_gift_h..":"..time_gift_m
	view_TimeSell_window_ui.time_sell_des.Text = lang:GetText("■ 拍卖时间：")..time_start_date..lang:GetText("的")..time_start..":00"..lang:GetText("至\n   ")..time_end_date..lang:GetText("的")..time_end..":00"..lang:GetText("\n\n■ 出价相同时，先出价者排名在前\n\n■ 每次成功出价扣除相应的物品个数\n\n■ 拍得物品将在")..time_date..lang:GetText("的")..t..lang:GetText("\n   发放给各位玩家\n\n■ 出价失败，返还的物品将在")..time_date..lang:GetText("的\n   ")..t..lang:GetText("发放给各位玩家\n\n■ 点击刷新按钮可更新当前最新的报价")
	rpc.safecallload("get_compete_buy_items", {pid = ptr_cast(game.CurrentState):GetCharacterId()},
	function(data)
		for i = 1 , 3 do
			view_TimeSell_window_ui["my_nums_"..i].Text = data.myNums[i]
			view_TimeSell_window_ui["my_nums_black_"..i].Text = data.myNums[i]
			view_TimeSell_window_ui["item_nums_"..i].Text = data.itemNums[i]
			view_TimeSell_window_ui["least_nums_"..i].Text = data.leastNums[i]
			view_TimeSell_window_ui["valid_nums_"..i].Text = data.validNums[i]
			view_TimeSell_window_ui["most_nums_"..i].Text = data.mostNums[i]
			if tonumber(coin_data[i]) == 1 then
				view_TimeSell_window_ui["coin_low_data"..i].Text = lang:GetText("黄金卡")
				view_TimeSell_window_ui["coin_high_data"..i].Text = lang:GetText("黄金卡")
			elseif tonumber(coin_data[i]) == 2 then
				view_TimeSell_window_ui["coin_low_data"..i].Text = lang:GetText("勋章")
				view_TimeSell_window_ui["coin_high_data"..i].Text = lang:GetText("勋章")
			end
			my_coin_num[i] = data.leftNums[i]
			my_now_nums[i] = data.myNums[i]
			if flag and add_time_decrease[i] == 10 then
				view_TimeSell_window_ui["bt_add_"..i].Text = lang:GetText("出价")
			end
		end
	
		if data.type == 0 then
			view_TimeSell_window_ui.lb_time.Text = lang:GetText("下次限时抢购\n开始时间")
			view_TimeSell_window_ui.date.Visible = true
			view_TimeSell_window_ui.time.Visible = false
			view_TimeSell_window_ui.lb_time_day.Visible = false
			for i = 1 , 3 do
				view_TimeSell_window_ui["bt_add_"..i].Enable = false
			end
			view_TimeSell_window_ui.b_fresh.Enable = false
			SellBeginTime = data.time
			OnShowDate()
			ResertZero()
		elseif data.type == 1 then
			view_TimeSell_window_ui.lb_time.Text = lang:GetText("距离限时抢购\n开始还剩")
			view_TimeSell_window_ui.date.Visible = false
			view_TimeSell_window_ui.time.Visible = true
			view_TimeSell_window_ui.lb_time_day.Visible = false
			for i = 1 , 3 do
				view_TimeSell_window_ui["bt_add_"..i].Enable = false
			end
			view_TimeSell_window_ui.b_fresh.Enable = false			
			SellBeginTime = data.time
			OnUpdateTime()
			ResertZero()
		elseif data.type == 2 then
			view_TimeSell_window_ui.lb_time.Text = lang:GetText("限时抢购进行中\n剩余时间")
			view_TimeSell_window_ui.date.Visible = false
			view_TimeSell_window_ui.time.Visible = true
			view_TimeSell_window_ui.lb_time_day.Visible = true
			for i = 1 , 3 do
				if flag and add_time_decrease[i] == 10 then
					view_TimeSell_window_ui["bt_add_"..i].Enable = true
				end
			end	
			if view_TimeSell_window_ui.b_fresh.Enable then
				view_TimeSell_window_ui.b_fresh.Enable = true
			end
			SellBeginTime = data.time
			OnUpdateTime()
		end
	end)
end

function HideTimeSellWindow()
	if TimeSell_Window and TimeSell_Window.screen then
		TimeSell_Window.screen.Visible = false
		-- view_TimeSell_window_ui = nil
	end
end

function ShowAddPay(index)
	add_pay_window = ModalWindow.GetNew()
	add_pay_window.root.Size = Vector2(394, 488)
	add_pay_window.screen.AllowEscToExit = false
	add_pay_ui.root.Parent = add_pay_window.root
	FillAddPay(index)
end

function FillAddPay(index)
	add_pay_ui.low_pay.Text = view_TimeSell_window_ui["valid_nums_"..index].Text
	add_pay_ui.left_money.Text = my_coin_num[my_index]
	-- add_pay_ui.now_pay.Text = my_now_nums[index]
	-- add_pay_ui.you_pay.Text = add_pay_ui.Tbox_Totle_num.Text
	-- add_pay_ui.all_pay.Text = tonumber(add_pay_ui.now_pay.Text) + tonumber(add_pay_ui.you_pay.Text)
	-- my_now_nums[index] + tonumber(add_pay_ui.Tbox_Totle_num.Text)
	add_pay_ui.left_money.Text = my_coin_num[index]
	if my_now_nums[index] > tonumber(view_TimeSell_window_ui["valid_nums_"..index].Text) then
		add_pay_ui.Tbox_Totle_num.Text = my_now_nums[index]
	else
		add_pay_ui.Tbox_Totle_num.Text = view_TimeSell_window_ui["valid_nums_"..index].Text
	end
	add_pay_ui.b_decrease.Visible = false

	if tonumber(coin_data[index]) == 1 then
		add_pay_ui.lb_type.Text = lang:GetText("黄金卡")
		add_pay_ui.c_type.Size = Vector2(39, 37)
		add_pay_ui.c_type.Location = Vector2(5, 5)
		add_pay_ui.c_type.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/time_sell/lb_buylimit_ico_goldcard.dds", Vector4(0,0,0,0)),}
		add_pay_ui.b_quickby.Enable = true
		add_pay_ui.lb_name.Text = lang:GetText("黄金卡")
		add_pay_ui.c_pic.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/goldCard.tga", Vector4(0, 0, 0, 0)),}
		add_pay_ui.lb_des.Text = lang:GetText("用来开启黄金宝盒的特定密码卡。")
	elseif tonumber(coin_data[index]) then
		add_pay_ui.lb_type.Text = lang:GetText("勋章")
		add_pay_ui.c_type.Size = Vector2(28, 36)
		add_pay_ui.c_type.Location = Vector2(5, 15)
		add_pay_ui.c_type.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_xunzhang_ico.dds", Vector4(0, 0, 0, 0)),}
		add_pay_ui.b_quickby.Enable = false
		add_pay_ui.lb_name.Text = lang:GetText("勋章")
		add_pay_ui.c_pic.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/medal.tga", Vector4(0, 0, 0, 0)),}
		add_pay_ui.lb_des.Text = lang:GetText("可用于兑换道具商城。")
	end
	
	-- if index == 1 then
		-- add_pay_ui.lb_type.Text = lang:GetText("黄金卡")
		-- add_pay_ui.c_type.Size = Vector2(39, 37)
		-- add_pay_ui.c_type.Location = Vector2(5, 5)
		-- add_pay_ui.c_type.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/time_sell/lb_buylimit_ico_goldcard.dds", Vector4(0,0,0,0)),}
		-- add_pay_ui.b_quickby.Enable = true
		-- add_pay_ui.lb_name.Text = lang:GetText("黄金卡")
		-- add_pay_ui.c_pic.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/goldCard.tga", Vector4(0, 0, 0, 0)),}
		-- add_pay_ui.lb_des.Text = lang:GetText("用来开启黄金宝盒的特定密码卡。")
	-- elseif index == 2 then
		-- add_pay_ui.lb_type.Text = lang:GetText("黄金卡")
		-- add_pay_ui.c_type.Size = Vector2(39, 37)
		-- add_pay_ui.c_type.Location = Vector2(5, 5)
		-- add_pay_ui.c_type.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/time_sell/lb_buylimit_ico_goldcard.dds", Vector4(0,0,0,0)),}
		-- add_pay_ui.b_quickby.Enable = true
		-- add_pay_ui.lb_name.Text = lang:GetText("黄金卡")
		-- add_pay_ui.c_pic.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/goldCard.tga", Vector4(0, 0, 0, 0)),}
		-- add_pay_ui.lb_des.Text = lang:GetText("用来开启黄金宝盒的特定密码卡。")
	-- elseif index == 3 then
		-- add_pay_ui.lb_type.Text = lang:GetText("勋章")
		-- add_pay_ui.c_type.Size = Vector2(28, 36)
		-- add_pay_ui.c_type.Location = Vector2(5, 15)
		-- add_pay_ui.c_type.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_xunzhang_ico.dds", Vector4(0, 0, 0, 0)),}
		-- add_pay_ui.b_quickby.Enable = false
		-- add_pay_ui.lb_name.Text = lang:GetText("勋章")
		-- add_pay_ui.c_pic.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/medal.tga", Vector4(0, 0, 0, 0)),}
		-- add_pay_ui.lb_des.Text = lang:GetText("可用于兑换道具商城。")
	-- end
	if my_coin_num[index] == 0 then
		add_pay_ui.b_plus.Enable = false
		add_pay_ui.b_decrease.Enable = false
		add_pay_ui.Tbox_Totle_num.Enable = false		
	else
		add_pay_ui.b_plus.Enable = true
		add_pay_ui.b_decrease.Enable = true
		add_pay_ui.Tbox_Totle_num.Enable = true
	end
end

function HideAddPay()
	if add_pay_window then
		add_pay_window:Close()
		add_pay_window = nil
	end
end

function OnShowDate()	
	if not SellBeginTime or SellBeginTime <= 0 then
		return
	end
	local temp_day = nil
	local ten = 1
	local Control = nil
	for i = 1 , 8 do
		Control = ptr_cast(view_TimeSell_window_ui.date:GetChildByIndex(i-1))
		for j = 7-i , 0 , -1 do
			ten = ten * 10
		end
		temp_day = (SellBeginTime - SellBeginTime%ten)/ten%10
		Control.Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_numbe.dds", Vector4(0, 0, 0, 0), Vector4((temp_day / 10), 0, (temp_day / 10) + 0.1, 1)),
		}
		ten = 1
	end
end

function OnUpdateTime()	
	if SellBeginTime <= 0 then
		FillTimeSell(true)
		return
	end
	view_TimeSell_window_ui.Event:CleanAll()
	view_TimeSell_window_ui.Event:AddTime(1)
	local temp_time = nil
	local t_date = nil
	t_date = math.floor(SellBeginTime/3600/24)
	local t_SellBeginTime = SellBeginTime%(3600*24)
	view_TimeSell_window_ui.lb_time_day.Text = t_date..lang:GetText("天")
	temp_time = t_SellBeginTime % 10
	
	local Control = ptr_cast(view_TimeSell_window_ui.time:GetChildByIndex(6))
	Control.Skin = Gui.ControlSkin
	{
		BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_numbe.dds", Vector4(0, 0, 0, 0), Vector4((temp_time / 10), 0, (temp_time / 10) + 0.1, 1)),
	}
	local Control = ptr_cast(view_TimeSell_window_ui.time:GetChildByIndex(5))
	temp_time = math.floor(t_SellBeginTime % 60 / 10)
	Control.Skin = Gui.ControlSkin
	{
		BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_numbe.dds", Vector4(0, 0, 0, 0), Vector4((temp_time / 10), 0, (temp_time / 10) + 0.1, 1)),
	}
	local Control = ptr_cast(view_TimeSell_window_ui.time:GetChildByIndex(4))
	temp_time = math.floor((t_SellBeginTime % 3600) / 60)%10
	Control.Skin = Gui.ControlSkin
	{
		BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_numbe.dds", Vector4(0, 0, 0, 0), Vector4((temp_time / 10), 0, (temp_time / 10) + 0.1, 1)),
	}
	local Control = ptr_cast(view_TimeSell_window_ui.time:GetChildByIndex(3))
	
	temp_time = math.floor((t_SellBeginTime % 3600) / 600)
	Control.Skin = Gui.ControlSkin
	{
		BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_numbe.dds", Vector4(0, 0, 0, 0), Vector4((temp_time / 10), 0, (temp_time / 10) + 0.1, 1)),
	}
	
	local Control = ptr_cast(view_TimeSell_window_ui.time:GetChildByIndex(2))
	temp_time = math.floor(t_SellBeginTime/3600) % 10
	Control.Skin = Gui.ControlSkin
	{
		BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_numbe.dds", Vector4(0, 0, 0, 0), Vector4((temp_time / 10), 0, (temp_time / 10) + 0.1, 1)),
	}
	local Control = ptr_cast(view_TimeSell_window_ui.time:GetChildByIndex(1))
	temp_time = math.floor(t_SellBeginTime/36000)
	Control.Skin = Gui.ControlSkin
	{
		BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_numbe.dds", Vector4(0, 0, 0, 0), Vector4((temp_time / 10), 0, (temp_time / 10) + 0.1, 1)),
	}
	local Control = ptr_cast(view_TimeSell_window_ui.time:GetChildByIndex(0))
	temp_time = math.floor(SellBeginTime/360000)
	Control.Skin = Gui.ControlSkin
	{
		BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_numbe.dds", Vector4(0, 0, 0, 0), Vector4((temp_time / 10), 0, (temp_time / 10) + 0.1, 1)),
	}
end

function ShowRapidShoppingWin()
	if Rapid_Shopping_Win_ui == nil then
		Rapid_Shopping_Win_ui = Gui.Create()(Rapid_Shopping_Win)
		--快速购买界面初始化
		RapidShopping_Window = ModalWindow.GetNew("Rapid_Shopping_Win_ui")
		RapidShopping_Window.screen.AllowEscToExit = false
		RapidShopping_Window.screen.Visible = false
		--RapidShopping_Window.screen.EventEscPressed = HideCharmBottleWin
		RapidShopping_Window.screen.EventEscPressed = nil
		RapidShopping_Window.root.Size = Vector2(1200, 900)
		Rapid_Shopping_Win_ui.Rapid_Shopping_root.Parent = RapidShopping_Window.root
	end
	Rapid_Shopping_Win_ui.des.FontSize = 16
	Rapid_Shopping_Win_ui.Tbox_Totle_num.Enable = true
	Rapid_Shopping_Win_ui.btn_left.Visible = true
	Rapid_Shopping_Win_ui.btn_right.Visible = true
	Rapid_Shopping_Win_ui.des.Text = lang:GetText("用来开启黄金宝盒的特定密码卡。")
	Rapid_Shopping_Win_ui.name.Text = lang:GetText("黄金卡")
	if RapidShopping_Window and RapidShopping_Window.screen then
		RapidShopping_Window.screen.Visible = true
		gui.EventEscPressed = nil
	end
	FileHummerItemBox()
end

function HideRapidShoppingWin()
	if RapidShopping_Window and RapidShopping_Window.screen then
		RapidShopping_Window.screen.Visible = false
		Rapid_Shopping_Win_ui = nil
	end
end

function FileHummerItemBox()
	Rapid_Shopping_Win_ui.itembox_hummer.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/goldCard.tga")
	Rapid_Shopping_Win_ui.Tbox_Totle_num.Text = 1
end

function SetHummerTotalMoney()
	if Rapid_Shopping_Win_ui.Tbox_Totle_num.Text == "" then
		Rapid_Shopping_Win_ui.Total_money.Text = "0"
		return
	end
	Rapid_Shopping_Win_ui.Total_money.Text = 1080 * Rapid_Shopping_Win_ui.Tbox_Totle_num.Text
end

function show_jiangli(i)
	local args = {index = i - 1}
	rpc.safecall("get_choicebox_items", args, 
	function (data)
		jiangli_list = data.items
		ShowViewJiangliWindow()
		L_MessageBox.CloseWaiter()
	end)	
end

function ShowViewJiangliWindow()
	if jiangli_ui == nil then
		jiangli_ui = Gui.Create()(jiangli)
	end
	if jiangli_window == nil then
		jiangli_window = ModalWindow.GetNew("jiangli_ui")
		jiangli_window.screen.AllowEscToExit = false
		jiangli_window.screen.Visible = false
		jiangli_window.root.Size = Vector2(1200,900)
		jiangli_window.screen.EventEscPressed = nil
		jiangli_ui.ctrl_view_jiangli_window.Parent = jiangli_window.root
		
		if jiangli_window and jiangli_window.screen then
			jiangli_window.screen.Visible = true
			gui.EventEscPressed = nil
		end
	end
	FillViewJiangli()
end

function HideViewJiangliWindow()
	if jiangli_window then
		jiangli_window:Close()
		jiangli_window = nil
	end
end

function FillViewJiangli()
	if jiangli_ui == nil then
		return
	end		
	for i = 1 , 9 do
		local ibbtn = ptr_cast(jiangli_ui.ctr_persent:GetChildByIndex(i - 1))
		ibbtn.ItemLevel = nil
		if jiangli_list[i] then
			if jiangli_list[i].color >= 1 and jiangli_list[i].color <= 8 then
				ibbtn.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..jiangli_list[i].name.."_"..jiangli_list[i].color..".tga")
			else
				ibbtn.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..jiangli_list[i].name..".tga")
			end
			if jiangli_list[i].common and jiangli_list[i].common.rareLevel then
				ibbtn.ItemLevel = Skin.rarelevel[math.ceil(jiangli_list[i].common.rareLevel/25)]
			end
			ibbtn.Selected = false
			ibbtn.Enable = true
		else
			ibbtn.ItemIcon = nil
			ibbtn.Enable = false
			ibbtn.ItemLevel = nil
		end
	end
end

function ResertZero()
	for i = 1 , 3 do
		view_TimeSell_window_ui["my_nums_black_"..i].Text = 0
		view_TimeSell_window_ui["my_nums_"..i].Text = 0
		view_TimeSell_window_ui["item_nums_"..i].Text = 0
		view_TimeSell_window_ui["least_nums_"..i].Text = 0
		view_TimeSell_window_ui["valid_nums_"..i].Text = 0
		view_TimeSell_window_ui["most_nums_"..i].Text = 0
		view_TimeSell_window_ui["bt_add_"..i].Text = lang:GetText("出价")
		view_TimeSell_window_ui["bt_add_"..i].Skin = Gui.ButtonSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/time_sell/lb_buylimit_button1_normal.dds", Vector4(0, 0, 0, 0)),
			HoverImage = Gui.Image("LobbyUI/ShoppingMall/time_sell/lb_buylimit_button1_hover.dds", Vector4(0, 0, 0, 0)),
			DownImage = Gui.Image("LobbyUI/ShoppingMall/time_sell/lb_buylimit_button1_down.dds", Vector4(0, 0, 0, 0)),
			DisabledImage = Gui.Image("LobbyUI/ShoppingMall/time_sell/lb_buylimit_button1_disabled.dds", Vector4(0, 0, 0, 0)),
		}
	end
end

function ChangeDate(t_date)
	if t_date == 1 then
		return lang:GetText("周日")
	elseif t_date == 2 then
		return lang:GetText("周一")
	elseif t_date == 3 then
		return lang:GetText("周二")
	elseif t_date == 4 then
		return lang:GetText("周三")
	elseif t_date == 5 then
		return lang:GetText("周四")
	elseif t_date == 6 then
		return lang:GetText("周五")
	elseif t_date == 7 then
		return lang:GetText("周六")
	end
end