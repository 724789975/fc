module("L_Mail", package.seeall)

Mail_root_ui = nil
gift_mail_modal = nil
--Type: 0 为收件箱; 1 为发件箱
Type = 0
--未读邮件的数量
no_read_count = nil
--新邮件的数量
new_count = nil
--当前选中邮件的发件人和主题
name = ""
theme = ""
--邮件是否合法  1为合法 0为不合法
flag = 1
--当前邮件的ID
m_id = nil
local warning1 = nil --选中的邮件有未读 
local warning2 = nil --选中的邮件有未领取的附件
current_selected = 1
rpc_date = nil
current_page = 1
current_pages = 1
email_itemid = 0
current_characters = 1
local gift_data = {{}}
--邮件界面
Mail_root = 
{
	Gui.Control "root"
	{
		Size = Vector2(1116, 586),
		Location = Vector2(19, 25),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/mail/lb_shop_bg2.dds", Vector4(14, 14, 14, 14)),
		},
		Gui.Control 
		{
			Size = Vector2(1101, 551),
			Location = Vector2(9, 35),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_daoju_bg.tga", Vector4(22, 22, 22, 22)),
			},
			Gui.Control
			{
				Size = Vector2(314, 499),
				Location = Vector2(35, 28),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/mail/lb_contact_bg2.dds", Vector4(27, 27, 27, 112)),
				},
				Gui.ScrollableControl "Scroll"
				{
					Size = Vector2(285, 410),
					Location = Vector2(14, 20),
					BackgroundColor = ARGB(255, 255, 255, 255),
					AutoScroll = true,
					Default_Size = 0,
					HScrollBarDisplay = "kHide",
					Skin = Gui.ScrollableControlSkin
					{
						UpButtonNormalImage = nil,
						UpButtonHoverImage = nil,
						UpButtonDownImage = nil,
						UpButtonDisabledImage = nil,

						DownButtonNormalImage = nil,
						DownButtonHoverImage = nil,
						DownButtonDownImage = nil,
						DownButtonDisabledImage = nil,

						VSliderNormalImage = Gui.Image("LobbyUI/team/lb_squad_scrollbar_button_normal.dds", Vector4(5, 5, 5, 5)),
						VSliderHoverImage = Gui.Image("LobbyUI/team/lb_squad_scrollbar_button_hover.dds", Vector4(5, 5, 5, 5)),
						VSliderDownImage = Gui.Image("LobbyUI/team/lb_squad_scrollbar_button_down.dds", Vector4(5, 5, 5, 5)),
						VSliderDisabledImage = Gui.Image("DLobbyUI/team/lb_squad_scrollbar_button_normal.dds", Vector4(5, 5, 5, 5)),

						VBarBackgroundImage = Gui.Image("LobbyUI/lb_common_scrollbar02_bg.dds", Vector4(0, 0, 0, 0)),
						BarCornerImage = nil,
					},
					Gui.TextArea "root_TextArea"
					{
						Size = Vector2(285, 440),
						Location = Vector2(0, 0),
						BackgroundColor = ARGB(0, 255, 0, 255),
						TextColor = ARGB(255, 53, 53, 51),
						FontSize = 20,
						Fold = true,
						Readonly = true,
					},
					Gui.FlowLayout "Image_Layout"
					{
						ControlSpace = 200,
						LineSpace = 15,
					},
				},
				
				-- Gui.Label "fujian_gift"
				-- {
					-- Size = Vector2(208, 39),
					-- Location = Vector2(10, 447),
					-- BackgroundColor = ARGB(255, 255, 255, 255),
					-- Visible = false,
					-- Skin = Gui.ControlSkin
					-- {
						-- BackgroundImage = nil,
					-- },
					-- TextColor = ARGB(255, 53, 53, 51),
					
					-- Gui.Control "gift_item_type"
					-- {
						-- Size = Vector2(28, 22),
						-- Location = Vector2(5, 11),
						-- BackgroundColor = ARGB(255, 255, 255, 255),
						-- Visible = false,
					-- },
				-- },
				
				Gui.Control "c_gift"
				{
					Size = Vector2(290, 190),
					Location = Vector2(11, 297),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Visible = false,
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/TopList/lb_rank_bg_02.dds", Vector4(10, 10, 10, 10)),
					},
					
					Gui.ItemBoxBtn "ibx_gift"
					{
						Style = "Gui.ItemBoxBtn_ib",
						Size = Vector2(200, 111),
						BackgroundColor = ARGB(0, 255, 255, 255),
						Location = Vector2(45, 29),
						EventMouseEnter = function(sender, e)
							L_ToolTips.FillToolTipsVIPPresent(1, Mail_root_ui.root, gift_data)
						end,
						
						EventToolTipsShow = function(sender, e)
							L_ToolTips.ShowToolTipsShowWindow(sender, Vector2(1116,586), sender.Location+sender.Parent.Location+ sender.Parent.Parent.Location)
						end,
						
						EventMouseLeave = function(sender, e)
							L_ToolTips.HideToolTipsWindow()
						end,
					},
				},
				
				Gui.Button "open_gift"
				{
					Visible = false,
					Size = Vector2(221, 34),
					Location = Vector2(47, 450),
					Padding = Vector4(0, 0, 0, 3),
					Text = lang:GetText("收取附件"),
					BackgroundColor = ARGB(255,255,255,255),
					TextAlign = "kAlignCenterMiddle",
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/Mission/lb_task_button01_normal.dds", Vector4(20, 5, 20, 5)),
						HoverImage = Gui.Image("LobbyUI/Mission/lb_task_button01_hover.dds", Vector4(20, 5, 20, 5)),
						DownImage = Gui.Image("LobbyUI/Mission/lb_task_button01_down.dds", Vector4(20, 5, 20, 5)),
						DisabledImage = Gui.Image("LobbyUI/Mission/lb_task_button01_disabled.dds", Vector4(20, 5, 20, 5)),	
					},
					TextColor = ARGB(255, 37, 37, 37),
					HighlightTextColor = ARGB(255, 37, 37, 37),
					EventClick = function()
						local args = {pid = ptr_cast(game.CurrentState):GetCharacterId(), mid = m_id, type = 1}
						rpc.safecall("email_detach", args, function(data) end)
						Mail_root_ui.open_gift.Visible = false
						-- Mail_root_ui.fujian_gift.Visible = false
						Mail_root_ui.c_gift.Visible = false
						FillMail()
						MessageBox.ShowWithTimer(2,lang:GetText("附件已放入仓库"))
					end
				},
			},	
			Gui.Control 
			{		
				Location = Vector2(377, 65),
				Size = Vector2(674, 390),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg3.dds", Vector4(42, 12, 16, 16)),
				},
				
			},
			Gui.ListTreeView "ltv_box"
			{
				Style = "Gui.ListTreeViewWith_VScroll_mail",
				Size = Vector2(696, 362),
				Location = Vector2(350, 79),
				ItemHeight = 60,
				TreeVisible = false,
				MY_SPLIT_WIDTH = 28, --CHECKBOX 鼠标点击的偏移量
				AlwaysSelect = false,
				CheckIndex = 0,
				HeaderVisible = false,
				VScrollBarDisplay = "kVisible",
				VScrollBarWidth = 32,
				VScrollBarButtonSize = 32,
				CanKeySelect = false,
				--Visible = false,
				--[[EventClick = function(sender, e)
					local item = sender.SelectedItem
					if item and sender.MouseSelectedItem == sender.SelectedItem then
						item.Check = not(item.Check)
					end
				end,]]

			},
			Gui.Button "In_Box"
			{
				PushDown = true,
				Text = lang:GetText("收件箱"),
				Location = Vector2(385,24),
				Size = Vector2(244, 50),
				TextColor = ARGB(255, 217, 209, 201),
				HighlightTextColor = ARGB(255, 217, 209, 201),
				FontSize = 18,
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_normal.dds", Vector4(14, 24, 14, 21)),
					HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_hover.dds", Vector4(14, 24, 14, 21)),
					DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_down.dds", Vector4(14, 24, 14, 21)),
					DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_normal.dds", Vector4(14, 24, 14, 21)),
				},
				EventClick = function()
					Type = 0
					Mail_root_ui.In_Box.PushDown = true
					Mail_root_ui.Out_Box.PushDown = false
					FillMail()
					Mail_root_ui.reply.Visible = false
					Mail_root_ui.open_gift.Visible = false
					-- Mail_root_ui.fujian_gift.Visible = false
					Mail_root_ui.c_gift.Visible = false
				end
			},
			Gui.Button "Out_Box"
			{
				Text = lang:GetText("发件箱"),
				Location = Vector2(625,24),
				Size = Vector2(244, 50),
				TextColor = ARGB(255, 217, 209, 201),
				HighlightTextColor = ARGB(255, 217, 209, 201),
				FontSize = 18,
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_normal.dds", Vector4(14, 24, 14, 21)),
					HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_hover.dds", Vector4(14, 24, 14, 21)),
					DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_down.dds", Vector4(14, 24, 14, 21)),
					DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_normal.dds", Vector4(14, 24, 14, 21)),
				},
				EventClick = function()
					Type = 1
					Mail_root_ui.Out_Box.PushDown = true
					Mail_root_ui.In_Box.PushDown = false
					FillMail()
					Mail_root_ui.reply.Visible = false
					Mail_root_ui.open_gift.Visible = false
					-- Mail_root_ui.fujian_gift.Visible = false
					Mail_root_ui.c_gift.Visible = false
				end
			},
			Gui.Label
			{
				Size = Vector2(134, 71),
				Location = Vector2(402, 462),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/mail/lb_common_button_bg01.dds", Vector4(15, 21, 15, 21)),
				},
				Gui.Button "btn_inbox_new"
				{
					Location = Vector2(7, 6),
					Size = Vector2(120, 60),
					BackgroundColor = ARGB(255,255,255,255),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/mail/lb_mail_button3_normal.dds", Vector4(5, 5, 5, 5)),
						HoverImage = Gui.Image("LobbyUI/mail/lb_mail_button3_hover.dds", Vector4(5, 5, 5, 5)),
						DownImage = Gui.Image("LobbyUI/mail/lb_mail_button3_down.dds", Vector4(5, 5, 5, 5)),
						DisabledImage = Gui.Image("LobbyUI/mail/lb_mail_button3_disabled.dds", Vector4(5, 5, 5, 5)),			
					},
					EventClick = function()
						setup_new_mail()
						Gui.Align(L_Mail.New_mail.new_mail_root, 0.5,0.5)
						flag = 1
						email_itemid = 0
						New_mail.close.Visible = false
						New_mail.add.Enable = true
						New_mail.red.Text = lang:GetText("绑定状态的物品无法添加附件")
						New_mail.item_type.Visible = false
						New_mail.outbox_fujian_text.Text = ""
					end
				},
			},
			
			Gui.Label "reply"
			{
				Visible = false,
				Size = Vector2(134, 71),
				Location = Vector2(540, 462),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/mail/lb_common_button_bg01.dds", Vector4(15, 21, 15, 21)),
				},
				Gui.Button
				{
					Location = Vector2(7, 6),
					Size = Vector2(120, 60),
					BackgroundColor = ARGB(255,255,255,255),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/mail/lb_reply_button01_normal.dds", Vector4(5, 5, 5, 5)),
						HoverImage = Gui.Image("LobbyUI/mail/lb_reply_button01_hover.dds", Vector4(5, 5, 5, 5)),
						DownImage = Gui.Image("LobbyUI/mail/lb_reply_button01_down.dds", Vector4(5, 5, 5, 5)),
						DisabledImage = Gui.Image("LobbyUI/mail/lb_reply_button01_normal.dds.dds", Vector4(5, 5, 5, 5)),			
					},
					EventClick = function()
						setup_new_mail()
						Gui.Align(New_mail.new_mail_root, 0.5,0.5)
						New_mail.outbox_name_text.Text = name
						New_mail.outbox_zhuti_text.Text = lang:GetText("回复：")..theme
						flag = 1
						New_mail.close.Visible = false
						New_mail.add.Enable = true
						email_itemid = 0
						New_mail.red.Text = lang:GetText("绑定状态的物品无法添加附件")
						New_mail.item_type.Visible = false
						New_mail.outbox_fujian_text.Text = ""
					end
				},
			},
			
			Gui.Label
			{
				Size = Vector2(278, 71),
				Location = Vector2(732, 461),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/mail/lb_common_button_bg01.dds", Vector4(15, 21, 15, 21)),
				},
				Gui.Button "all_select"
				{
					Location = Vector2(8, 6),
					Size = Vector2(132, 60),
					BackgroundColor = ARGB(255,255,255,255),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/mail/lb_mail_button4_normal.dds", Vector4(5, 5, 5, 5)),
						HoverImage = Gui.Image("LobbyUI/mail/lb_mail_button4_hover.dds", Vector4(5, 5, 5, 5)),
						DownImage = Gui.Image("LobbyUI/mail/lb_mail_button4_down.dds", Vector4(5, 5, 5, 5)),
						DisabledImage = nil,			
					},
					EventClick = function()
						AllSelectMail(Mail_root_ui.ltv_box)
					end
				},
				Gui.Button "btn_inbox_delete"
				{
					Location = Vector2(140, 6),
					Size = Vector2(132, 60),
					BackgroundColor = ARGB(255,255,255,255),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/mail/lb_mail_button2_normal.dds", Vector4(5, 5, 5, 5)),
						HoverImage = Gui.Image("LobbyUI/mail/lb_mail_button2_hover.dds", Vector4(5, 5, 5, 5)),
						DownImage = Gui.Image("LobbyUI/mail/lb_mail_button2_down.dds", Vector4(5, 5, 5, 5)),
						DisabledImage = Gui.Image("LobbyUI/mail/lb_mail_button2_disabled.dds", Vector4(5, 5, 5, 5)),			
					},
					EventClick = function()
						if IsSelected(Mail_root_ui.ltv_box) == false then
							MessageBox.ShowWithTimer(1,lang:GetText("请选择一封邮件！"))
						else
							local args = {type = Type}
							args.mid = GetSelectedMail(Mail_root_ui.ltv_box)
							if warning1 == 0 and warning2 == 0 then
								MessageBox.ShowWithConfirmCancel(lang:GetText("您确定要删除选中的邮件吗？"),
								function(sender,e)
									rpc.safecall("email_delete",args,
									function(data)
										nrcount()
										FillMail()
										Mail_root_ui.reply.Visible = false
										Mail_root_ui.open_gift.Visible = false
										-- Mail_root_ui.fujian_gift.Visible = false
										Mail_root_ui.c_gift.Visible = false
									end)
									name = ""
									theme = ""
								end,
								nil)
							elseif warning1 == 1 and warning2 == 0 then
								MessageBox.ShowWithConfirmCancel(lang:GetText("您选中的邮件有未读邮件\n确认删除吗？"),
								function(sender,e)
									rpc.safecall("email_delete",args,
									function(data)
										nrcount()
										FillMail()
										Mail_root_ui.reply.Visible = false
										Mail_root_ui.open_gift.Visible = false
										-- Mail_root_ui.fujian_gift.Visible = false
										Mail_root_ui.c_gift.Visible = false
									end)
									name = ""
									theme = ""
								end,
								nil)
							elseif warning1 == 0 and warning2 == 1 then
								MessageBox.ShowWithConfirmCancel(lang:GetText("您选中的邮件有未收取的附件\n确认删除吗？"),
								function(sender,e)
									rpc.safecall("email_delete",args,
									function(data)
										nrcount()
										FillMail()
										Mail_root_ui.reply.Visible = false
										Mail_root_ui.open_gift.Visible = false
										-- Mail_root_ui.fujian_gift.Visible = false
										Mail_root_ui.c_gift.Visible = false
									end)
									name = ""
									theme = ""
								end,
								nil)
							else
								MessageBox.ShowWithConfirmCancel(lang:GetText("您选中的邮件有未读邮件\n确认删除吗？"),
								function(sender,e)
									MessageBox.ShowWithConfirmCancel(lang:GetText("您选中的邮件有未收取的附件\n确认删除吗？"),
									function(sender,e)
										rpc.safecall("email_delete",args,
										function(data)
											nrcount()
											FillMail()
											Mail_root_ui.reply.Visible = false
											Mail_root_ui.open_gift.Visible = false
											-- Mail_root_ui.fujian_gift.Visible = false
											Mail_root_ui.c_gift.Visible = false
										end)
										name = ""
										theme = ""
									end,
									nil)
								end,
								nil)
							end
						end
					end
				},
			},
		},
		Gui.Button 
		{
			Size = Vector2(64, 52),
			Location = Vector2(1049, 3),
			PushDown = false,
			Hint = lang:GetText("关闭邮件并返回至战区"),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button01_normal.dds", Vector4(0, 0, 0, 0)),
				HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button01_hover.dds", Vector4(0, 0, 0, 0)),
				DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button01_down.dds", Vector4(0, 0, 0, 0)),
				DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button01_normal.dds", Vector4(0, 0, 0, 0)),
			},
			EventClick = function()
--				L_LobbyMain.HideAll()
				L_WarZone.Show(L_LobbyMain.LobbyMainWin_Boddy.LobbyMainWin_Boddy_Root)
			end
		},
	},
}

--新邮件
New_mail = Gui.Create()
{
	Gui.Control "root"
	{
		Size = Vector2(1200, 900),
		Location = Vector2(0, 0),
		BackgroundColor = ARGB(0, 255, 255, 255),
		Gui.Button
		{
			Size = Vector2(1200, 900),
			Location = Vector2(0, 0),
			BackgroundColor = ARGB(0, 255, 255, 255),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = nil,
				HoverImage = nil,
				DownImage = nil,
				DisabledImage = nil,	
			},
			EventClick = function()
				MessageBox.ShowWithConfirmCancel(lang:GetText("确定要退出新邮件吗？"), 
				function(sender,e)
					New_mail_modal.Close()
					New_mail_modal = nil
				end,
				nil)
			end
		},
		Gui.Control "new_mail_root"
		{
			Size = Vector2(590, 460),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/mail/lb_contact_bg1.dds", Vector4(38, 38, 38, 38)),
			},
			Gui.Control
			{
				Size = Vector2(562, 431),
				Location = Vector2(15, 13),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/mail/lb_contact_bg2.dds", Vector4(27, 27, 27, 112)),
				},
			},
			Gui.Label
			{
				Size = Vector2(100,30),
				Location = Vector2(40, 28),	
				Text = lang:GetText("收件人"),
				TextColor = ARGB(255, 53, 53, 51),
				BackgroundColor = ARGB(0, 255, 255, 255),
				TextAlign = "kAlignCenterMiddle",
			},
			Gui.ComboBox "outbox_name_text"
			{
				Skin = Gui.ComboBoxSkin
				{
					ButtonNormalImage= Gui.Image("LobbyUI/mail/lb_squad_combobox_button2_normal.dds", Vector4(0, 0, 0, 0)),
					ButtonHoverImage = Gui.Image("LobbyUI/mail/lb_squad_combobox_button2_hover.dds", Vector4(0, 0, 0, 0)),
					ButtonDownImage = Gui.Image("LobbyUI/mail/lb_squad_combobox_button2_down.dds", Vector4(0, 0, 0, 0)),
					
					TextNormalImage= Gui.Image("LobbyUI/mail/lb_squad_combobox2_text.dds", Vector4(6, 0, 0, 0)),
					TextHoverImage = Gui.Image("LobbyUI/mail/lb_squad_combobox2_text.dds", Vector4(6, 0, 0, 0)),
					TextDownImage = Gui.Image("LobbyUI/mail/lb_squad_combobox2_text.dds", Vector4(6, 0, 0, 0)),
					
				},
				ChildComboListStyle =  "Gui.mailComboList",
				Size = Vector2(212,28),
				Location = Vector2(146, 28),
				Readonly = false,
				TabFocus = true,
				TextColor = ARGB(255, 0, 0, 0),
				MaxLength = 128,
			},
			Gui.Button 
			{
				Size = Vector2(131, 32),
				Location = Vector2(410, 26),
				Text = lang:GetText("玩家列表"),
				TextColor = ARGB(255, 211, 211, 211),
				HighlightTextColor = ARGB(255, 211, 211, 211),
				TextAlign = "kAlignCenterMiddle",
				Padding = Vector4(0, 0, 0, 3),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/lb_contact_button_normal.dds", Vector4(5, 5, 5, 5)),
					HoverImage = Gui.Image("LobbyUI/team/lb_contact_button_hover.dds", Vector4(5, 5, 5, 5)),
					DownImage = Gui.Image("LobbyUI/team/lb_contact_button_down.dds", Vector4(5, 5, 5, 5)),
					DisabledImage = Gui.Image("LobbyUI/team/lb_contact_button_normal.dds", Vector4(5, 5, 5, 5)),			
				},
				EventClick = function()
					setup_player_list()
					FillFriendsList()
					Player_List.Friend.PushDown = true
					Player_List.Partner.PushDown = false
					Player_List.Zhandui.PushDown = false
					Player_List.Channel_Player.PushDown = false
				end
			},
			-- Gui.Button "add"
			-- {
				-- Size = Vector2(84, 32),
				-- Location = Vector2(450, 28),
				-- Text = lang:GetText("添加附件"),
				-- TextColor = ARGB(255, 211, 211, 211),
				-- HighlightTextColor = ARGB(255, 211, 211, 211),
				-- TextAlign = "kAlignCenterMiddle",
				-- Skin = Gui.ButtonSkin
				-- {
					-- BackgroundImage = Gui.Image("LobbyUI/team/lb_contact_button_normal.dds", Vector4(5, 5, 5, 5)),
					-- HoverImage = Gui.Image("LobbyUI/team/lb_contact_button_hover.dds", Vector4(5, 5, 5, 5)),
					-- DownImage = Gui.Image("LobbyUI/team/lb_contact_button_down.dds", Vector4(5, 5, 5, 5)),
					-- DisabledImage = Gui.Image("LobbyUI/team/lb_contact_button_normal.dds", Vector4(5, 5, 5, 5)),			
				-- },
				-- EventClick = function()
					-- setup_Player_storage()
					-- Player_storage.btn_OK.Enable = false
				-- end
			-- },

			-- Gui.Button "close"
			-- {
				-- Size = Vector2(24, 24),
				-- Location = Vector2(540, 35),
				-- BackgroundColor = ARGB(255, 255, 255, 255),
				-- Skin = Gui.ButtonSkin
				-- {
					-- BackgroundImage = Gui.Image("LobbyUI/mail/lb_close_buttn01_normal.dds", Vector4(5, 5, 5, 5)),
					-- HoverImage = Gui.Image("LobbyUI/mail/lb_close_buttn01_hover.dds", Vector4(5, 5, 5, 5)),
					-- DownImage = Gui.Image("LobbyUI/mail/lb_close_buttn01_down.dds", Vector4(5, 5, 5, 5)),
					-- DisabledImage = Gui.Image("LobbyUI/mail/lb_close_buttn01_normal.dds", Vector4(5, 5, 5, 5)),			
				-- },
				-- EventClick = function()
					-- New_mail.close.Visible = false
					-- New_mail.add.Enable = true
					-- New_mail.red.Text = lang:GetText("绑定状态的物品无法添加附件")
					-- email_itemid = 0
					-- New_mail.item_type.Visible = false
					-- New_mail.outbox_fujian_text.Text = ""
				-- end
			-- },
			
			
			Gui.Label
			{
				Size = Vector2(100,30),
				Location = Vector2(40, 60),
				Text = lang:GetText("主  题"),
				TextColor = ARGB(255, 53, 53, 51),
				BackgroundColor = ARGB(0, 255, 255, 255),
				TextAlign = "kAlignCenterMiddle",
			},
			Gui.Textbox "outbox_zhuti_text"
			{
				Size = Vector2(400,25),
				Location = Vector2(146, 60),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/mail/lb_contact_bg3_normal.dds", Vector4(14, 14, 14, 14)),
				},
				Readonly = false,
				TabFocus = true,
				--MaxLength = 40,
				TextColor = ARGB(255, 53, 53, 51),
			},
			
			Gui.Label
			{
				Size = Vector2(100,30),
				Location = Vector2(40, 92),
				Text = lang:GetText("附  件"),
				TextColor = ARGB(255, 53, 53, 51),
				BackgroundColor = ARGB(0, 255, 255, 255),
				TextAlign = "kAlignCenterMiddle",
			},
			
			Gui.Button "add"
			{
				Size = Vector2(155, 32),
				Location = Vector2(146, 92),
				Text = lang:GetText("添加附件"),
				TextColor = ARGB(255, 211, 211, 211),
				HighlightTextColor = ARGB(255, 211, 211, 211),
				TextAlign = "kAlignCenterMiddle",
				Padding = Vector4(0, 0, 0, 3),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/lb_contact_button_normal.dds", Vector4(5, 5, 5, 5)),
					HoverImage = Gui.Image("LobbyUI/team/lb_contact_button_hover.dds", Vector4(5, 5, 5, 5)),
					DownImage = Gui.Image("LobbyUI/team/lb_contact_button_down.dds", Vector4(5, 5, 5, 5)),
					DisabledImage = Gui.Image("LobbyUI/team/lb_contact_button_normal.dds", Vector4(5, 5, 5, 5)),			
				},
				EventClick = function()
					setup_Player_storage()
					Player_storage.btn_OK.Enable = false
				end
			},
			
			Gui.Label "outbox_fujian_text"
			{
				Size = Vector2(306,25),
				Location = Vector2(305, 92),
				TextPadding = Vector4(10,0,0,0),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = nil,
				},
				TextColor = ARGB(255, 53, 53, 51),
				
				Gui.Control "item_type"
				{
					Size = Vector2(28, 22),
					Location = Vector2(5, 2),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Visible = false,
				},
			},
			
			Gui.Button "close"
			{
				Size = Vector2(24, 24),
				Location = Vector2(0, 0),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/mail/lb_close_buttn01_normal.dds", Vector4(5, 5, 5, 5)),
					HoverImage = Gui.Image("LobbyUI/mail/lb_close_buttn01_hover.dds", Vector4(5, 5, 5, 5)),
					DownImage = Gui.Image("LobbyUI/mail/lb_close_buttn01_down.dds", Vector4(5, 5, 5, 5)),
					DisabledImage = Gui.Image("LobbyUI/mail/lb_close_buttn01_normal.dds", Vector4(5, 5, 5, 5)),			
				},
				EventClick = function()
					New_mail.close.Visible = false
					New_mail.add.Enable = true
					New_mail.red.Text = lang:GetText("绑定状态的物品无法添加附件")
					email_itemid = 0
					New_mail.item_type.Visible = false
					New_mail.outbox_fujian_text.Text = ""
				end
			},
			
			Gui.Label
			{
				Size = Vector2(509,235),
				Location = Vector2(43, 135),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/mail/lb_contact_bg3_normal.dds", Vector4(14, 14, 14, 14)),
				},
			},
			Gui.TextArea "neirong_text"
			{
				Size = Vector2(515,235),
				Location = Vector2(43, 135),
				Fold = true,
				FontSize = 20,
				Readonly = false,
				TabFocus = true,
				MaxLength = 1024,
				TextColor = ARGB(255, 53, 53, 51),
				EventTextChanged = function()
					if game:TextLenght(New_mail.neirong_text.Text) > 140 then
						flag = 0
						New_mail.abcd.Text = lang:GetText("已超出")..(game:TextLenght(New_mail.neirong_text.Text) - 140)..lang:GetText("字")						
						New_mail.abcd.TextColor = ARGB(255, 174, 9, 9)						
					else
						flag = 1
						New_mail.abcd.Text = lang:GetText("你还能输入")..(140 - game:TextLenght(New_mail.neirong_text.Text))..lang:GetText("个字")						
						New_mail.abcd.TextColor = ARGB(255, 81, 79, 79)						
					end
				end
			},
			Gui.Label "abcd"
			{
				Size = Vector2(500,29),
				Location = Vector2(46, 370),
				BackgroundColor = ARGB(0, 255, 255, 255),
				TextAlign = "kAlignCenterMiddle",
				--Text = lang:GetText("你还能输入140个字"),
				FontSize = 14,
				TextColor = ARGB(255, 81, 79, 79),
			},

			Gui.Button 
			{
				Size = Vector2(140,33),
				Location = Vector2(280, 405),
				Text = lang:GetText("发 送"),
				TextColor = ARGB(255, 211, 211, 211),
				HighlightTextColor = ARGB(255, 211, 211, 211),
				TextAlign = "kAlignCenterMiddle",
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/lb_onlinetime_button_2_normal.dds", Vector4(15, 0, 15, 0)),
					HoverImage = Gui.Image("LobbyUI/lb_onlinetime_button_2_hover.dds", Vector4(15, 0, 15, 0)),
					DownImage = Gui.Image("LobbyUI/lb_onlinetime_button_2_down.dds", Vector4(15, 0, 15, 0)),
					DisabledImage = Gui.Image("LobbyUI/lb_onlinetime_button_2_disabled.dds", Vector4(15, 0, 15, 0)),			
				},
				EventClick = function()
					if flag == 0 then
						MessageBox.ShowWithTimer(1,lang:GetText("字数超出限制！"))
					else
						if New_mail.outbox_name_text.Text == "" then
							MessageBox.ShowWithTimer(1,lang:GetText("收件人不能为空！"))
						elseif New_mail.outbox_zhuti_text.Text == "" then
							MessageBox.ShowWithTimer(1,lang:GetText("邮件主题不能为空！"))
						elseif New_mail.neirong_text.Text == "" then
							MessageBox.ShowWithTimer(1,lang:GetText("邮件内容不能为空！"))
						elseif game:TextLenght(New_mail.outbox_zhuti_text.Text) > 16 then
							MessageBox.ShowWithTimer(1,lang:GetText("邮件主题字数不能大于16个字！"))
 						else
							local c_id = ptr_cast(game.CurrentState):GetCharacterId()
							local args = {}
							args.receiver = New_mail.outbox_name_text.Text
							args.subject = New_mail.outbox_zhuti_text.Text
							args.content = New_mail.neirong_text.Text
							args.itemid = email_itemid
							print("email_itemid:"..email_itemid)
							rpc.safecall("email_create",{cid = c_id, content = args.content, subject = args.subject, receiver = args.receiver, itemId = args.itemid},
							function(data)
								if data.error == nil then
									MessageBox.ShowWithTimer(1,lang:GetText("发送成功！"))
									gui:PlayAudio("kUIA_SEND_MAIL")
								end
							end)
							FillMail()
							Mail_root_ui.reply.Visible = false
							Mail_root_ui.open_gift.Visible = false
							-- Mail_root_ui.fujian_gift.Visible = false
							Mail_root_ui.c_gift.Visible = false
							New_mail_modal.Close()
							New_mail_modal = nil
						end
					end
					
				end
			},
			Gui.Button 
			{
				Size = Vector2(140, 33),
				Location = Vector2(425, 405),
				Text = lang:GetText("取 消"),
				TextColor = ARGB(255, 211, 211, 211),
				HighlightTextColor = ARGB(255, 211, 211, 211),
				TextAlign = "kAlignCenterMiddle",
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/lb_onlinetime_button_2_normal.dds", Vector4(15, 0, 15, 0)),
					HoverImage = Gui.Image("LobbyUI/lb_onlinetime_button_2_hover.dds", Vector4(15, 0, 15, 0)),
					DownImage = Gui.Image("LobbyUI/lb_onlinetime_button_2_down.dds", Vector4(15, 0, 15, 0)),
					DisabledImage = Gui.Image("LobbyUI/lb_onlinetime_button_2_disabled.dds", Vector4(15, 0, 15, 0)),		
				},
				EventClick = function()
					New_mail_modal.Close()
					New_mail_modal = nil
				end
			},
			-- Gui.Button "add"
			-- {
				-- Size = Vector2(104, 36),
				-- Location = Vector2(31, 405),
				-- Text = lang:GetText("添加附件"),
				-- TextColor = ARGB(255, 211, 211, 211),
				-- HighlightTextColor = ARGB(255, 211, 211, 211),
				-- TextAlign = "kAlignCenterMiddle",
				-- Skin = Gui.ButtonSkin
				-- {
					-- BackgroundImage = Gui.Image("LobbyUI/team/lb_contact_button_normal.tga", Vector4(5, 5, 5, 5)),
					-- HoverImage = Gui.Image("LobbyUI/team/lb_contact_button_hover.tga", Vector4(5, 5, 5, 5)),
					-- DownImage = Gui.Image("LobbyUI/team/lb_contact_button_down.tga", Vector4(5, 5, 5, 5)),
					-- DisabledImage = Gui.Image("LobbyUI/team/lb_contact_button_normal.tga", Vector4(5, 5, 5, 5)),			
				-- },
				-- EventClick = function()
					-- setup_Player_storage()
					-- Player_storage.btn_OK.Enable = false
				-- end
			-- },
			
			Gui.Label "red"
			{
				Size = Vector2(255, 35),
				TextColor = ARGB(255,255,0,0),
				Text = lang:GetText("绑定状态的物品无法添加附件"),
				Location = Vector2(30, 405),
				BackgroundColor = ARGB(0, 255, 255, 255),
			},
			
			-- Gui.Control "close"
			-- {
				-- Visible = false,
				-- Size = Vector2(124, 44),
				-- Location = Vector2(38, 400),
				-- BackgroundColor = ARGB(0, 255, 255, 255),
				-- Gui.ItemBoxBtn "gift"
				-- {
					-- Size = Vector2(96, 44),
					-- Location = Vector2(0, 0),
					-- Empty = false,
					-- LoadingImage = Gui.AnimatedImage("LobbyUI/loading_ring.tga", 4, 2, 8),
					-- Type = 1,
					-- Skin = Gui.ItemBoxBtnSkin
					-- {
						-- NeutralNormalImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_wuqi_normal.dds", Vector4(10, 10, 10, 10)),
						-- NeutralHoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_wuqi_normal.dds", Vector4(10, 10, 10, 10)),
						-- NeutralSelectedImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_wuqi_normal.dds", Vector4(10, 10, 10, 10)),
						-- NeutralDisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_disable.dds", Vector4(10, 10, 10, 10)),
					-- },
				-- },
				-- Gui.Button
				-- {
					-- Size = Vector2(24, 24),
					-- Location = Vector2(100, 0),
					-- BackgroundColor = ARGB(255, 255, 255, 255),
					-- Skin = Gui.ButtonSkin
					-- {
						-- BackgroundImage = Gui.Image("LobbyUI/mail/lb_close_buttn01_normal.dds", Vector4(5, 5, 5, 5)),
						-- HoverImage = Gui.Image("LobbyUI/mail/lb_close_buttn01_hover.dds", Vector4(5, 5, 5, 5)),
						-- DownImage = Gui.Image("LobbyUI/mail/lb_close_buttn01_down.dds", Vector4(5, 5, 5, 5)),
						-- DisabledImage = Gui.Image("LobbyUI/mail/lb_close_buttn01_normal.dds", Vector4(5, 5, 5, 5)),			
					-- },
					-- EventClick = function()
						-- New_mail.close.Visible = false
						-- New_mail.add.Visible = true
						-- New_mail.red.Text = lang:GetText("绑定状态的物品无法添加附件")
						-- email_itemid = 0
					-- end
				-- },
			-- },
		},
	},
}

Gift_Win = Gui.Create()
{
	Gui.Control "Gift"
	{
		Size = Vector2(408, 277),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/mail/lb_contact_bg1.dds", Vector4(38, 38, 38, 38)),
		},
		Gui.Control 
		{
			Size = Vector2(385, 252),
			Location = Vector2(12, 10),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/mail/lb_contact_bg2.dds", Vector4(27, 27, 27, 112)),
			},
		},
		Gui.Control 
		{
			Size = Vector2(168, 156),
			Location = Vector2(125, 44),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/mail/lb_shop_box4_jiaoyi.dds", Vector4(5, 5, 5, 5)),
			},
			Gui.Control "Image"
			{
				BackgroundColor = ARGB(255, 255, 255, 255),
			},
		},
		Gui.Label "W_name"
		{
			Size = Vector2(408, 35),
			Location = Vector2(0, 10),
			BackgroundColor = ARGB(0, 255, 255, 255),
			TextAlign = "kAlignCenterMiddle",
			FontSize = 20,
			TextColor = ARGB(255, 37, 37, 37),
		},
		Gui.Button
		{
			Size = Vector2(104, 36),
			Location = Vector2(78, 226),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Text = lang:GetText("接受"),
			TextColor = ARGB(255, 211, 211, 211),
			Padding = Vector4(0, 0, 0, 5),
			HighlightTextColor = ARGB(255, 211, 211, 211),
			TextAlign = "kAlignCenterMiddle",
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/team/lb_contact_button_normal.tga", Vector4(5, 5, 5, 5)),
				HoverImage = Gui.Image("LobbyUI/team/lb_contact_button_hover.tga", Vector4(5, 5, 5, 5)),
				DownImage = Gui.Image("LobbyUI/team/lb_contact_button_down.tga", Vector4(5, 5, 5, 5)),
				DisabledImage = Gui.Image("LobbyUI/team/lb_contact_button_normal.tga", Vector4(5, 5, 5, 5)),			
			},
			EventClick = function()
				local args = {pid = ptr_cast(game.CurrentState):GetCharacterId(), mid = m_id, type = 1}
				rpc.safecall("email_detach", args, function(data) end)
				Mail_root_ui.open_gift.Visible = false
				gift_mail_modal.Close()
				gift_mail_modal = nil
				FillMail()
			end
		},
		Gui.Button
		{
			Size = Vector2(104, 36),
			Location = Vector2(227, 226),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Text = lang:GetText("拒绝"),
			TextColor = ARGB(255, 211, 211, 211),
			Padding = Vector4(0, 0, 0, 5),
			HighlightTextColor = ARGB(255, 211, 211, 211),
			TextAlign = "kAlignCenterMiddle",
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/team/lb_contact_button_normal.tga", Vector4(5, 5, 5, 5)),
				HoverImage = Gui.Image("LobbyUI/team/lb_contact_button_hover.tga", Vector4(5, 5, 5, 5)),
				DownImage = Gui.Image("LobbyUI/team/lb_contact_button_down.tga", Vector4(5, 5, 5, 5)),
				DisabledImage = Gui.Image("LobbyUI/team/lb_contact_button_normal.tga", Vector4(5, 5, 5, 5)),			
			},
			EventClick = function()
				MessageBox.ShowWithConfirmCancel(lang:GetText("拒绝礼物，礼物将会消失！"),
				function(data)
					local args = {pid = ptr_cast(game.CurrentState):GetCharacterId(), mid = m_id, type = 0}
					rpc.safecall("email_detach", args, function(data) end)
					Mail_root_ui.open_gift.Visible = false
					gift_mail_modal.Close()
					gift_mail_modal = nil
					FillMail()
				end)
			end
		},
	},
}

Player_List = Gui.Create()
{
	Gui.Control "root"
	{
		Size = Vector2(392, 522),
		Dock = "kDockCenter",
		BackgroundColor = ARGB(255, 255, 255, 255),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/mail/lb_contact_bg1.dds", Vector4(38, 38, 38, 38)),
		},
		Gui.Control
		{
			Size = Vector2(362, 496),
			Location = Vector2(15, 13),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/mail/lb_contact_bg2.dds", Vector4(27, 27, 27, 112)),
			},
			Gui.Control 
			{		
				Location = Vector2(8, 38),
				Size = Vector2(346, 409),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg3.dds", Vector4(42, 12, 16, 16)),
				},
				Gui.ListTreeView "ltv_box"
				{
					Style = "Gui.ListTreeViewWith_VScroll",
					Size = Vector2(336, 399),
					Location = Vector2(10, 14),
					CanKeySelect = false,
					TreeVisible = false,
					AlwaysSelect = false,
					VScrollBarWidth = 32,
					VScrollBarButtonSize = 32,
					FontSize = 14,
					TextColor = ARGB(255,216,217,208),
					VScrollBarDisplay = "kVisible",
					ItemHeight = 38,
					HeaderVisible = false,
					
					--双击鼠标
					EventDoubleClick = function(sender, e)
						if sender.SelectedItem then
							New_mail.outbox_name_text.Text = sender.SelectedItem:GetText()
						end
						if Player_list_modal then
							Player_list_modal.Close()
							Player_list_modal = nil
						end
					end,
				},
			},
			Gui.Button "Friend"
			{
				PushDown = true,
				Text = lang:GetText("好友"),
				Location = Vector2(16,8),
				Size = Vector2(84, 40),
				TextColor = ARGB(255, 217, 209, 201),
				HighlightTextColor = ARGB(255, 217, 209, 201),
				FontSize = 18,
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_normal.dds", Vector4(14, 19, 14, 19)),
					HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_hover.dds", Vector4(14, 19, 14, 19)),
					DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_down.dds", Vector4(14, 19, 14, 19)),
					DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_normal.dds", Vector4(14, 19, 14, 19)),
				},
				EventClick = function()
					Player_List.Friend.PushDown = true
					Player_List.Partner.PushDown = false
					Player_List.Zhandui.PushDown = false
					Player_List.Channel_Player.PushDown = false
					FillFriendsList()
				end
			},
			Gui.Button "Partner"
			{
				Text = lang:GetText("伙伴"),
				Location = Vector2(97,8),
				Size = Vector2(84, 40),
				TextColor = ARGB(255, 217, 209, 201),
				HighlightTextColor = ARGB(255, 217, 209, 201),
				FontSize = 18,
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_normal.dds", Vector4(14, 19, 14, 19)),
					HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_hover.dds", Vector4(14, 19, 14, 19)),
					DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_down.dds", Vector4(14, 19, 14, 19)),
					DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_normal.dds", Vector4(14, 19, 14, 19)),
				},
				EventClick = function()
					Player_List.Friend.PushDown = false
					Player_List.Partner.PushDown = true
					Player_List.Zhandui.PushDown = false
					Player_List.Channel_Player.PushDown = false
					FillPartnerList()
				end
			},
			Gui.Button "Zhandui"
			{
				Text = lang:GetText("战队"),
				Location = Vector2(178,8),
				Size = Vector2(84, 40),
				TextColor = ARGB(255, 217, 209, 201),
				HighlightTextColor = ARGB(255, 217, 209, 201),
				FontSize = 18,
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_normal.dds", Vector4(14, 19, 14, 19)),
					HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_hover.dds", Vector4(14, 19, 14, 19)),
					DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_down.dds", Vector4(14, 19, 14, 19)),
					DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_normal.dds", Vector4(14, 19, 14, 19)),
				},
				EventClick = function()
					Player_List.Friend.PushDown = false
					Player_List.Partner.PushDown = false
					Player_List.Zhandui.PushDown = true
					Player_List.Channel_Player.PushDown = false
					FillZhanduiList()
				end
			},
			Gui.Button "Channel_Player"
			{
				Text = lang:GetText("频道"),
				Location = Vector2(259,8),
				Size = Vector2(84, 40),
				TextColor = ARGB(255, 217, 209, 201),
				HighlightTextColor = ARGB(255, 217, 209, 201),
				FontSize = 18,
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_normal.dds", Vector4(14, 19, 14, 19)),
					HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_hover.dds", Vector4(14, 19, 14, 19)),
					DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_down.dds", Vector4(14, 19, 14, 19)),
					DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_normal.dds", Vector4(14, 19, 14, 19)),
				},
				EventClick = function()
					Player_List.Friend.PushDown = false
					Player_List.Partner.PushDown = false
					Player_List.Zhandui.PushDown = false
					Player_List.Channel_Player.PushDown = true
					FillChannelPlayerList()
				end
			},
			Gui.Button
			{
				Size = Vector2(104, 36),
				Location = Vector2(29, 455),
				Text = lang:GetText("确定"),
				TextColor = ARGB(255, 211, 211, 211),
				HighlightTextColor = ARGB(255, 211, 211, 211),
				TextAlign = "kAlignCenterMiddle",
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/lb_contact_button_normal.dds", Vector4(5, 5, 5, 5)),
					HoverImage = Gui.Image("LobbyUI/team/lb_contact_button_hover.dds", Vector4(5, 5, 5, 5)),
					DownImage = Gui.Image("LobbyUI/team/lb_contact_button_down.dds", Vector4(5, 5, 5, 5)),
					DisabledImage = Gui.Image("LobbyUI/team/lb_contact_button_normal.dds", Vector4(5, 5, 5, 5)),			
				},
				EventClick = function()
					local ltv = Player_List.ltv_box
					if ltv.SelectedItem then
						New_mail.outbox_name_text.Text = ltv.SelectedItem:GetText()
					end
					if Player_list_modal then
						Player_list_modal.Close()
						Player_list_modal = nil
					end
				end
				  
			},
			Gui.Button
			{
				Size = Vector2(104, 36),
				Location = Vector2(229, 455),
				Text = lang:GetText("取消"),
				TextColor = ARGB(255, 211, 211, 211),
				HighlightTextColor = ARGB(255, 211, 211, 211),
				TextAlign = "kAlignCenterMiddle",
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/lb_contact_button_normal.dds", Vector4(5, 5, 5, 5)),
					HoverImage = Gui.Image("LobbyUI/team/lb_contact_button_hover.dds", Vector4(5, 5, 5, 5)),
					DownImage = Gui.Image("LobbyUI/team/lb_contact_button_down.dds", Vector4(5, 5, 5, 5)),
					DisabledImage = Gui.Image("LobbyUI/team/lb_contact_button_normal.dds", Vector4(5, 5, 5, 5)),			
				},
				EventClick = function()
					if Player_list_modal then
						Player_list_modal.Close()
						Player_list_modal = nil
					end
				end
			},
		},
	},
}

--仓库
Player_storage = Gui.Create()
{
	Gui.Control "root"
	{
		Size = Vector2(1200, 900),
		Dock = "kDockCenter",
		BackgroundColor = ARGB(0, 255, 255, 255),
		
		Gui.Control 
		{
			Size = Vector2(706, 589),--706  573
			Dock = "kDockCenter",
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/mail/lb_contact_bg1.dds", Vector4(38, 38, 38, 38)),
			},
			Gui.Control
			{
				Size = Vector2(684, 563),--684  547
				Location = Vector2(11, 13),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/mail/lb_contact_bg2.dds", Vector4(27, 27, 27, 112)),
				},
				
				--职业列表
				L_Characters_tab.create_tab_characters_windows(Vector2(1,54)),
			
				Gui.Button "wuqi"
				{
					PushDown = true,
					--Text = lang:GetText("武器"),
					Location = Vector2(175,9),--155 14
					Size = Vector2(92, 56),--80  32
					TextColor = ARGB(255, 217, 209, 201),
					HighlightTextColor = ARGB(255, 217, 209, 201),
					FontSize = 18,
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_arms_normal.dds", Vector4(5, 5, 5, 5)),
						HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_arms_hover.dds", Vector4(5, 5, 5, 5)),
						DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_arms_down.dds", Vector4(5, 5, 5, 5)),
						DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_arms_normal.dds", Vector4(5, 5, 5, 5)),
					},
					EventClick = function(Sender,e)
						current_selected = 1
						current_page = 1
						ResetType()
						Sender.PushDown = true						
					end,
				},
				Gui.Button "fuzhuang"
				{
					--Text = lang:GetText("服装"),
					Location = Vector2(267,9),
					Size = Vector2(92, 56),
					TextColor = ARGB(255, 217, 209, 201),
					HighlightTextColor = ARGB(255, 217, 209, 201),
					FontSize = 18,
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_clothes_normal.dds", Vector4(5, 5, 5, 5)),
						HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_clothes_hover.dds", Vector4(5, 5, 5, 5)),
						DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_clothes_down.dds", Vector4(5, 5, 5, 5)),
						DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_clothes_normal.dds", Vector4(5, 5, 5, 5)),
					},
					EventClick = function(Sender,e)
						current_selected = 2
						current_page = 1
						ResetType()
						Sender.PushDown = true
					end,
				},
				Gui.Button "shipin"
				{
					--Text = lang:GetText("配饰"),
					Location = Vector2(359,9),
					Size = Vector2(92, 56),
					TextColor = ARGB(255, 217, 209, 201),
					HighlightTextColor = ARGB(255, 217, 209, 201),
					FontSize = 18,
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_hat_normal.dds", Vector4(5, 5, 5, 5)),
						HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_hat_hover.dds", Vector4(5, 5, 5, 5)),
						DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_hat_down.dds", Vector4(5, 5, 5, 5)),
						DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_hat_normal.dds", Vector4(5, 5, 5, 5)),
					},
					EventClick = function(Sender,e)
						current_selected = 3
						current_page = 1
						ResetType()
						Sender.PushDown = true						
					end,				
				},
				Gui.Button "daoju"
				{
					--Text = lang:GetText("道具"),
					Location = Vector2(451,9),
					Size = Vector2(92, 56),
					TextColor = ARGB(255, 217, 209, 201),
					HighlightTextColor = ARGB(255, 217, 209, 201),
					FontSize = 18,
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_props_normal.dds", Vector4(5, 5, 5, 5)),
						HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_props_hover.dds", Vector4(5, 5, 5, 5)),
						DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_props_down.dds", Vector4(5, 5, 5, 5)),
						DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_props_normal.dds", Vector4(5, 5, 5, 5)),
					},
					EventClick = function(Sender,e)
						current_selected = 4
						current_page = 1
						ResetType()
						Sender.PushDown = true						
					end,
				},
				Gui.Button "sucai"
				{
					--Text = lang:GetText("素材"),
					Location = Vector2(543,9),
					Size = Vector2(92, 56),
					TextColor = ARGB(255, 217, 209, 201),
					HighlightTextColor = ARGB(255, 217, 209, 201),
					FontSize = 18,
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_material_normal.dds", Vector4(5, 5, 5, 5)),
						HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_material_hover.dds", Vector4(5, 5, 5, 5)),
						DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_material_down.dds", Vector4(5, 5, 5, 5)),
						DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_material_normal.dds", Vector4(5, 5, 5, 5)),
					},
					EventClick = function(Sender,e)
						current_selected = 5
						current_page = 1
						ResetType()
						Sender.PushDown = true
					end,
				},
				-- Gui.Button "dalibao"
				-- {
					-- Text = lang:GetText("大礼包"),
					-- Location = Vector2(418,14),
					-- Size = Vector2(80, 32),
					-- TextColor = ARGB(255, 217, 209, 201),
					-- HighlightTextColor = ARGB(255, 217, 209, 201),
					-- FontSize = 18,
					-- Skin = Gui.ButtonSkin
					-- {
						-- BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_normal.dds", Vector4(5, 5, 5, 5)),
						-- HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_hover.dds", Vector4(5, 5, 5, 5)),
						-- DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_down.dds", Vector4(5, 5, 5, 5)),
						-- DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_normal.dds", Vector4(5, 5, 5, 5)),
					-- },
					-- EventClick = function(Sender,e)
						-- current_selected = 6
						-- current_page = 1
						-- ResetType()
						-- Sender.PushDown = true
					-- end
				-- },
				Gui.Control "right"
				{		
					Location = Vector2(143, 56),
					Size = Vector2(529, 454),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/mail/lb_mail_label_bg01.dds", Vector4(5, 5, 5, 5)),
					},
				},
				
				Gui.Control "ctrl_bottom_container"
				{							
					Size = Vector2(415, 49),
					Location = Vector2(133, 461),
					BackgroundColor = ARGB(0, 255, 255, 255),

					--上一页
					Gui.Button "btn_front_page"
					{
						Size = Vector2(14, 31),
						Location = Vector2(201, 9),
						--Text = "<",
						TextColor = ARGB(255, 255, 246, 235),
						FontSize = 18,
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button05_normal.dds", Vector4(0, 0, 0, 0)),
							HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button05_hover.dds", Vector4(0, 0, 0, 0)),
							DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button05_down.dds", Vector4(0, 0, 0, 0)),
							DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button05_normal.dds", Vector4(0, 0, 0, 0)),
						},
						EventClick = function()
							if current_page > 1 then
								current_page = current_page - 1
								FillStorage()
							end
						end
					},
					
					--页码
					Gui.Label "lb_page_number"
					{
						Location = Vector2(230, 9),
						Size = Vector2(75, 31),
						FontSize = 24,
						TextAlign = "kAlignCenterMiddle",
						TextColor = ARGB(255, 103, 102, 98),
						Text = "1/1",
						BackgroundColor = ARGB(255, 255, 255, 255),

						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button06_bg.dds", Vector4(14, 14, 14, 14)),
						},
					},

					--下一页
					Gui.Button "btn_next_page"
					{
						Size = Vector2(14, 31),
						Location = Vector2(320, 9),
						--Text = ">",
						TextColor = ARGB(255, 255, 246, 235),
						FontSize = 18,
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button06_normal.dds", Vector4(0, 0, 0, 0)),
							HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button06_hover.dds", Vector4(0, 0, 0, 0)),
							DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button06_down.dds", Vector4(0, 0, 0, 0)),
							DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button06_normal.dds", Vector4(0, 0, 0, 0)),
						},
						EventClick = function()
							if current_page < current_pages then
								current_page = current_page + 1
								FillStorage()
							end
						end
					},
				},
				
				Gui.Button "btn_OK"
				{
					Size = Vector2(220,36),
					Location = Vector2(118, 516),
					Text = lang:GetText("确 定"),
					TextColor = ARGB(255, 211, 211, 211),
					HighlightTextColor = ARGB(255, 211, 211, 211),
					TextAlign = "kAlignCenterMiddle",
					Enable = false,
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/lb_contact_button_normal.dds", Vector4(5, 5, 5, 5)),
						HoverImage = Gui.Image("LobbyUI/team/lb_contact_button_hover.dds", Vector4(5, 5, 5, 5)),
						DownImage = Gui.Image("LobbyUI/team/lb_contact_button_down.dds", Vector4(5, 5, 5, 5)),
						DisabledImage = Gui.Image("LobbyUI/team/lb_contact_button_normal.dds", Vector4(5, 5, 5, 5)),			
					},
					EventClick = function()
						email_itemid = 0
						New_mail.red.Text = ""
						if current_selected == 5 then
							for i = 1, 20 do
								local ibbtn = ptr_cast(material_info_page.ctrl_ib_container:GetChildByIndex(i-1))
								if ibbtn.Selected == true then
									email_itemid = rpc_date[i].playeritemid
									-- if rpc_date[i].color == 1 or rpc_date[i].color == 2 or rpc_date[i].color == 3 or rpc_date[i].color == 4 then
										-- New_mail.gift.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..rpc_date[i].name.."_"..rpc_date[i].color..".tga")
									-- else
										-- New_mail.gift.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..rpc_date[i].name..".tga")
									-- end
									ItemType(New_mail.item_type,5)
									New_mail.outbox_fujian_text.Text = "       "..rpc_date[i].display
									local width = New_mail.outbox_fujian_text:TextWidth(New_mail.outbox_fujian_text.Text)
									New_mail.close.Location = Vector2(New_mail.outbox_fujian_text.Location.x+20+width,92)
									New_mail.close.Visible = true
									New_mail.add.Enable = false
									break
								end
							end
						elseif current_selected == 1 then
							for i = 1, 12 do
								local ibbtn = ptr_cast(weapon_info_page.ctrl_ib_container:GetChildByIndex(i-1))
								if ibbtn.Selected == true then
									email_itemid = rpc_date[i].playeritemid
									print(rpc_date[i].playeritemid)
									-- if rpc_date[i].color == 1 or rpc_date[i].color == 2 or rpc_date[i].color == 3 or rpc_date[i].color == 4 then
										-- New_mail.gift.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..rpc_date[i].name.."_"..rpc_date[i].color..".tga")
									-- else
										-- New_mail.gift.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..rpc_date[i].name..".tga")
									-- end
									ItemType(New_mail.item_type,1)
									New_mail.outbox_fujian_text.Text = "       "..rpc_date[i].display
									local width = New_mail.outbox_fujian_text:TextWidth(New_mail.outbox_fujian_text.Text)
									New_mail.close.Location = Vector2(New_mail.outbox_fujian_text.Location.x+20+width,92)
									New_mail.close.Visible = true
									New_mail.add.Enable = false
									break
								end
							end
						elseif current_selected == 2 then
							for i = 1, 10 do
								local ibbtn = ptr_cast(dress_info_page.ctrl_ib_container:GetChildByIndex(i-1))
								if ibbtn.Selected == true then
									email_itemid = rpc_date[i].playeritemid
									-- if rpc_date[i].color == 1 or rpc_date[i].color == 2 or rpc_date[i].color == 3 or rpc_date[i].color == 4 then
										-- New_mail.gift.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..rpc_date[i].name.."_"..rpc_date[i].color..".tga")
									-- else
										-- New_mail.gift.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..rpc_date[i].name..".tga")
									-- end
									ItemType(New_mail.item_type,2)
									New_mail.outbox_fujian_text.Text = "       "..rpc_date[i].display
									local width = New_mail.outbox_fujian_text:TextWidth(New_mail.outbox_fujian_text.Text)
									New_mail.close.Location = Vector2(New_mail.outbox_fujian_text.Location.x+20+width,92)
									New_mail.close.Visible = true
									New_mail.add.Enable = false
									break
								end
							end
						elseif current_selected == 3 then
							for i = 1, 20 do
								local ibbtn = ptr_cast(accessories_info_page.ctrl_ib_container:GetChildByIndex(i-1))
								if ibbtn.Selected == true then
									email_itemid = rpc_date[i].playeritemid
									-- if rpc_date[i].color == 1 or rpc_date[i].color == 2 or rpc_date[i].color == 3 or rpc_date[i].color == 4 then
										-- New_mail.gift.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..rpc_date[i].name.."_"..rpc_date[i].color..".tga")
									-- else
										-- New_mail.gift.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..rpc_date[i].name..".tga")
									-- end
									ItemType(New_mail.item_type,3)
									New_mail.outbox_fujian_text.Text = "       "..rpc_date[i].display
									local width = New_mail.outbox_fujian_text:TextWidth(New_mail.outbox_fujian_text.Text)
									New_mail.close.Location = Vector2(New_mail.outbox_fujian_text.Location.x+20+width,92)
									New_mail.close.Visible = true
									New_mail.add.Enable = false
									break
								end
							end
						elseif current_selected == 4 then
							for i = 1, 20 do
								local ibbtn = ptr_cast(daoju_info_page.ctrl_ib_container:GetChildByIndex(i-1))
								if ibbtn.Selected == true then
									email_itemid = rpc_date[i].playeritemid
									-- if rpc_date[i].color == 1 or rpc_date[i].color == 2 or rpc_date[i].color == 3 or rpc_date[i].color == 4 then
										-- New_mail.gift.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..rpc_date[i].name.."_"..rpc_date[i].color..".tga")
									-- else
										-- New_mail.gift.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..rpc_date[i].name..".tga")
									-- end
									ItemType(New_mail.item_type,4)
									New_mail.outbox_fujian_text.Text = "       "..rpc_date[i].display
									local width = New_mail.outbox_fujian_text:TextWidth(New_mail.outbox_fujian_text.Text)
									New_mail.close.Location = Vector2(New_mail.outbox_fujian_text.Location.x+20+width,92)
									New_mail.close.Visible = true
									New_mail.add.Enable = false
									break
								end
							end
						end

						if Player_storage_modal then
							Player_storage_modal.Close()
							Player_storage_modal = nil
						end
					end
					  
				},
				Gui.Button
				{
					Size = Vector2(220, 36),
					Location = Vector2(375, 516),
					Text = lang:GetText("取消"),
					TextColor = ARGB(255, 211, 211, 211),
					HighlightTextColor = ARGB(255, 211, 211, 211),
					TextAlign = "kAlignCenterMiddle",
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/lb_contact_button_normal.dds", Vector4(5, 5, 5, 5)),
						HoverImage = Gui.Image("LobbyUI/team/lb_contact_button_hover.dds", Vector4(5, 5, 5, 5)),
						DownImage = Gui.Image("LobbyUI/team/lb_contact_button_down.dds", Vector4(5, 5, 5, 5)),
						DisabledImage = Gui.Image("LobbyUI/team/lb_contact_button_normal.dds", Vector4(5, 5, 5, 5)),							
					},
					EventClick = function()
						if Player_storage_modal then
							Player_storage_modal.Close()
							Player_storage_modal = nil
						end
					end
				},
			},
		},	
	},
}

for i = 1, 10 do
	Player_storage["tab_btn_"..i].EventClick = function(Sender,e)
		current_characters = i
		current_page = 1
		ResetCharacters()
		Sender.PushDown = true
	end
end

--武器
function create_weapon_page(index, line, list)
	return Gui.ItemBoxBtn
	{
		Style = "Gui.ItemBoxBtn_ib",
		Size = Vector2(172, 100),
		Location = Vector2(172*line, 100*list),
		
		EventSelected = function(sender, e)
			if weapon_info_page and sender.Loading == false then
				for i = 1, 12 do
					local ibbtn = ptr_cast(weapon_info_page.ctrl_ib_container:GetChildByIndex(i-1))
					if i == index then
						ibbtn.Selected = true
						Player_storage.btn_OK.Enable = true
					else
						ibbtn.Selected = false
					end
				end
			end
		end,
				
		EventMouseEnter = function(sender, e)
			L_ToolTips.FillMailWindow(index, Player_storage_modal.root)
		end,
		EventToolTipsShow = function(sender, e)
			L_ToolTips.ShowToolTipsShowWindow(sender,Vector2(1200,900),Vector2(406+172*line,222+100*list))
		end,
		EventMouseLeave = function(sender, e)
			L_ToolTips.HideToolTipsWindow()
		end,
		
		-- EventMouseRightDown = function(sender, e)
			-- if rpc_date[index] then
				-- tuozhuai.root.Parent = L_LobbyMain.LobbyMainWin.LobbyMain_Root
				-- index_tz = index
				-- tuozhuai.root.Visible = true
				-- local lobby_state = ptr_cast(game.CurrentState)
				-- local cursor_ScreenSize = lobby_state:GetScreenSize()
				-- local cursor_pos = lobby_state:GetCursorPos()
				-- tuozhuai.Image.Location = Vector2(cursor_pos.x-((cursor_ScreenSize.x - cursor_ScreenSize.y / 3 * 4) / 2) - 99, cursor_pos.y - 38)
				-- tuozhuai.Image.Size = Vector2(168, 76)
				-- if rpc_date[index].color == 1 or rpc_date[index].color == 2 or rpc_date[index].color == 3 or rpc_date[index].color == 4 then
					-- tuozhuai.Image.Skin = Gui.ControlSkin
					-- {
						-- BackgroundImage = Gui.Image("LobbyUI/ibt_icon/"..rpc_date[index].name.."_"..rpc_date[index].color..".tga", Vector4(0, 0, 0, 0)),
					-- }
				-- else
					-- tuozhuai.Image.Skin = Gui.ControlSkin
					-- {
						-- BackgroundImage = Gui.Image("LobbyUI/ibt_icon/"..rpc_date[index].name..".tga", Vector4(0, 0, 0, 0)),
					-- }
				-- end
				-- local ibbtn = ptr_cast(weapon_info_page.ctrl_ib_container:GetChildByIndex(index-1))
				-- ibbtn.ItemIcon.alpha = 80
			-- end
			-- Highlight(current_selected,rpc_date[index].mType)
		-- end,
		
		-- EventMouseUp = function(sender, e)
			-- index_right = index
			-- FillMachine(index)
			-- sender.Empty = true
			-- sender.Enable = false
		-- end,
	}
end

weapon_info_page = Gui.Create()
{
	Gui.Control "ctrl_ib_container"
	{							
		Size = Vector2(519, 400),
		Location = Vector2(5, 5),
		BackgroundColor = ARGB(0, 255, 255, 255),
		
		create_weapon_page(1, 0, 0),
		create_weapon_page(2, 1, 0),
		create_weapon_page(3, 2, 0),
		
		create_weapon_page(4, 0, 1),
		create_weapon_page(5, 1, 1),
		create_weapon_page(6, 2, 1),
		
		create_weapon_page(7, 0, 2),
		create_weapon_page(8, 1, 2),
		create_weapon_page(9, 2, 2),
		
		create_weapon_page(10, 0, 3),
		create_weapon_page(11, 1, 3),
		create_weapon_page(12, 2, 3),
	},
}

--服装
function create_dress_page(index, line, list)
	return Gui.ItemBoxBtn
	{
		Style = "Gui.ItemBoxBtn_ib",
		Size = Vector2(104, 196),
		Location = Vector2(104*line, 196*list),
		
		EventSelected = function(sender, e)
			if dress_info_page and sender.Loading == false then
				for i = 1, 10 do
					local ibbtn = ptr_cast(dress_info_page.ctrl_ib_container:GetChildByIndex(i-1))
					if i == index then
						ibbtn.Selected = true
						Player_storage.btn_OK.Enable = true
					else
						ibbtn.Selected = false
					end
				end
			end
		end,
		
		EventMouseEnter = function(sender, e)
			L_ToolTips.FillMailWindow(index, Player_storage_modal.root)
		end,
		EventToolTipsShow = function(sender, e)
			L_ToolTips.ShowToolTipsShowWindow(sender,Vector2(1200,900),Vector2(406+104*line,222+196*list))
		end,
		EventMouseLeave = function(sender, e)
			L_ToolTips.HideToolTipsWindow()
		end,
		-- EventMouseRightDown = function(sender, e)
			-- if rpc_date[index] then
				-- tuozhuai.root.Parent = L_LobbyMain.LobbyMainWin.LobbyMain_Root
				-- index_tz = index
				-- tuozhuai.root.Visible = true
				-- local lobby_state = ptr_cast(game.CurrentState)
				-- local cursor_ScreenSize = lobby_state:GetScreenSize()
				-- local cursor_pos = lobby_state:GetCursorPos()
				-- tuozhuai.Image.Location = Vector2(cursor_pos.x-((cursor_ScreenSize.x - cursor_ScreenSize.y / 3 * 4) / 2) - 55, cursor_pos.y - 78)
				-- tuozhuai.Image.Size = Vector2(80, 156)
				-- if rpc_date[index].color == 1 or rpc_date[index].color == 2 or rpc_date[index].color == 3 or rpc_date[index].color == 4 then
					-- tuozhuai.Image.Skin = Gui.ControlSkin
					-- {
						-- BackgroundImage = Gui.Image("LobbyUI/ibt_icon/"..rpc_date[index].name.."_"..rpc_date[index].color..".tga", Vector4(0, 0, 0, 0)),
					-- }
				-- else
					-- tuozhuai.Image.Skin = Gui.ControlSkin
					-- {
						-- BackgroundImage = Gui.Image("LobbyUI/ibt_icon/"..rpc_date[index].name..".tga", Vector4(0, 0, 0, 0)),
					-- }
				-- end
				-- local ibbtn = ptr_cast(dress_info_page.ctrl_ib_container:GetChildByIndex(index-1))
				-- ibbtn.ItemIcon.alpha = 80
			-- end
			-- Highlight(current_selected,rpc_date[index].mType)
		-- end,
		-- EventMouseEnter = function(sender, e)
			-- if sender.Loading == false then
				-- L_ToolTips.FillToolTipsWindow(5, index, sender)
			-- end
		-- end,
		-- EventToolTipsShow = function(sender, e)
			-- L_ToolTips.ShowToolTipsShowWindow(sender)
		-- end,
		-- EventMouseLeave = function(sender, e)
			-- L_ToolTips.HideToolTipsWindow()
		-- end,
		-- EventMouseUp = function(sender, e)
			-- index_right = index
			-- FillMachine(index)
			-- sender.Empty = true
			-- sender.Enable = false
		-- end,
	}
end

dress_info_page = Gui.Create()
{
	Gui.Control "ctrl_ib_container"
	{							
		Size = Vector2(519, 400),
		Location = Vector2(5, 5),
		BackgroundColor = ARGB(0, 255, 255, 255),

		create_dress_page(1, 0, 0),
		create_dress_page(2, 1, 0),
		create_dress_page(3, 2, 0),
		create_dress_page(4, 3, 0),
		create_dress_page(5, 4, 0),
		
		create_dress_page(6, 0, 1),
		create_dress_page(7, 1, 1),
		create_dress_page(8, 2, 1),
		create_dress_page(9, 3, 1),
		create_dress_page(10, 4, 1),
	},
}

--配饰
function create_accessories_page(index, line, list)
	return Gui.ItemBoxBtn
	{
		Style = "Gui.ItemBoxBtn_ib",
		Size = Vector2(104, 100),
		Location = Vector2(104*line, 100*list),
		
		EventSelected = function(sender, e)
			if accessories_info_page and sender.Loading == false then
				for i = 1, 20 do
					local ibbtn = ptr_cast(accessories_info_page.ctrl_ib_container:GetChildByIndex(i-1))
					if i == index then
						ibbtn.Selected = true
						Player_storage.btn_OK.Enable = true
					else
						ibbtn.Selected = false
					end
				end
			end
		end,
		EventMouseEnter = function(sender, e)
			L_ToolTips.FillMailWindow(index, Player_storage_modal.root)
		end,
		EventToolTipsShow = function(sender, e)
			L_ToolTips.ShowToolTipsShowWindow(sender,Vector2(1200,900),Vector2(406+104*line,222+100*list))
		end,
		EventMouseLeave = function(sender, e)
			L_ToolTips.HideToolTipsWindow()
		end,
		-- EventMouseRightDown = function(sender, e)
			-- if rpc_date[index] then
				-- tuozhuai.root.Parent = L_LobbyMain.LobbyMainWin.LobbyMain_Root
				-- index_tz = index
				-- tuozhuai.root.Visible = true
				-- local lobby_state = ptr_cast(game.CurrentState)
				-- local cursor_ScreenSize = lobby_state:GetScreenSize()
				-- local cursor_pos = lobby_state:GetCursorPos()
				-- tuozhuai.Image.Location = Vector2(cursor_pos.x-((cursor_ScreenSize.x - cursor_ScreenSize.y / 3 * 4) / 2) - 51, cursor_pos.y - 34)
				-- tuozhuai.Image.Size = Vector2(72, 68)
				-- if rpc_date[index].color == 1 or rpc_date[index].color == 2 or rpc_date[index].color == 3 or rpc_date[index].color == 4 then
					-- tuozhuai.Image.Skin = Gui.ControlSkin
					-- {
						-- BackgroundImage = Gui.Image("LobbyUI/ibt_icon/"..rpc_date[index].name.."_"..rpc_date[index].color..".tga", Vector4(0, 0, 0, 0)),
					-- }
				-- else
					-- tuozhuai.Image.Skin = Gui.ControlSkin
					-- {
						-- BackgroundImage = Gui.Image("LobbyUI/ibt_icon/"..rpc_date[index].name..".tga", Vector4(0, 0, 0, 0)),
					-- }
				-- end
				-- local ibbtn = ptr_cast(accessories_info_page.ctrl_ib_container:GetChildByIndex(index-1))
				-- ibbtn.ItemIcon.alpha = 80
			-- end
			-- Highlight(current_selected,rpc_date[index].mType)
		-- end,
		-- EventMouseEnter = function(sender, e)
			-- if sender.Loading == false then
				-- L_ToolTips.FillToolTipsWindow(5, index, sender)
			-- end
		-- end,
		-- EventToolTipsShow = function(sender, e)
			-- L_ToolTips.ShowToolTipsShowWindow(sender)
		-- end,
		-- EventMouseLeave = function(sender, e)
			-- L_ToolTips.HideToolTipsWindow()
		-- end,
		-- EventMouseUp = function(sender, e)
			-- index_right = index
			-- FillMachine(index)
			-- sender.Empty = true
			-- sender.Enable = false
		-- end,
	}
end

accessories_info_page = Gui.Create()
{
	Gui.Control "ctrl_ib_container"
	{							
		Size = Vector2(519, 400),
		Location = Vector2(5, 5),
		BackgroundColor = ARGB(0, 255, 255, 255),
			
		create_accessories_page(1, 0, 0),
		create_accessories_page(2, 1, 0),
		create_accessories_page(3, 2, 0),
		create_accessories_page(4, 3, 0),
		create_accessories_page(5, 4, 0),
		
		create_accessories_page(6, 0, 1),
		create_accessories_page(7, 1, 1),
		create_accessories_page(8, 2, 1),
		create_accessories_page(9, 3, 1),
		create_accessories_page(10, 4, 1),
		
		create_accessories_page(11, 0, 2),
		create_accessories_page(12, 1, 2),
		create_accessories_page(13, 2, 2),
		create_accessories_page(14, 3, 2),
		create_accessories_page(15, 4, 2),
		
		create_accessories_page(16, 0, 3),
		create_accessories_page(17, 1, 3),
		create_accessories_page(18, 2, 3),
		create_accessories_page(19, 3, 3),
		create_accessories_page(20, 4, 3),
	},
}

--道具
function create_daoju_page(index, line, list)
	return Gui.ItemBoxBtn
	{
		Style = "Gui.ItemBoxBtn_ib",
		Size = Vector2(104, 100),
		Location = Vector2(104*line, 100*list),
		
		EventSelected = function(sender, e)
			if daoju_info_page and sender.Loading == false then
				for i = 1, 20 do
					local ibbtn = ptr_cast(daoju_info_page.ctrl_ib_container:GetChildByIndex(i-1))
					if i == index then
						ibbtn.Selected = true
						Player_storage.btn_OK.Enable = true
					else
						ibbtn.Selected = false
					end
				end
			end
		end,
		
		EventMouseEnter = function(sender, e)
			L_ToolTips.FillMailWindow(index, Player_storage_modal.root)
		end,
		EventToolTipsShow = function(sender, e)
			L_ToolTips.ShowToolTipsShowWindow(sender,Vector2(1200,900),Vector2(406+104*line,222+100*list))
		end,
		EventMouseLeave = function(sender, e)
			L_ToolTips.HideToolTipsWindow()
		end,
		
		-- EventMouseRightDown = function(sender, e)
			-- if rpc_date[index] then
				-- tuozhuai.root.Parent = L_LobbyMain.LobbyMainWin.LobbyMain_Root
				-- index_tz = index
				-- tuozhuai.root.Visible = true
				-- local lobby_state = ptr_cast(game.CurrentState)
				-- local cursor_ScreenSize = lobby_state:GetScreenSize()
				-- local cursor_pos = lobby_state:GetCursorPos()
				-- tuozhuai.Image.Location = Vector2(cursor_pos.x-((cursor_ScreenSize.x - cursor_ScreenSize.y / 3 * 4) / 2) - 51, cursor_pos.y - 34)
				-- tuozhuai.Image.Size = Vector2(72, 68)
				-- if rpc_date[index].color == 1 or rpc_date[index].color == 2 or rpc_date[index].color == 3 or rpc_date[index].color == 4 then
					-- tuozhuai.Image.Skin = Gui.ControlSkin
					-- {
						-- BackgroundImage = Gui.Image("LobbyUI/ibt_icon/"..rpc_date[index].name.."_"..rpc_date[index].color..".tga", Vector4(0, 0, 0, 0)),
					-- }
				-- else
					-- tuozhuai.Image.Skin = Gui.ControlSkin
					-- {
						-- BackgroundImage = Gui.Image("LobbyUI/ibt_icon/"..rpc_date[index].name..".tga", Vector4(0, 0, 0, 0)),
					-- }
				-- end
				-- local ibbtn = ptr_cast(material_info_page.ctrl_ib_container:GetChildByIndex(index-1))
				-- ibbtn.ItemIcon.alpha = 80
			-- end
			-- Highlight(current_selected,rpc_date[index].mType)
		-- end,
		-- EventMouseEnter = function(sender, e)
			-- if sender.Loading == false then
				-- L_ToolTips.FillToolTipsWindow(5, index, sender)
			-- end
		-- end,
		-- EventToolTipsShow = function(sender, e)
			-- L_ToolTips.ShowToolTipsShowWindow(sender)
		-- end,
		-- EventMouseLeave = function(sender, e)
			-- L_ToolTips.HideToolTipsWindow()
		-- end,
		-- EventMouseUp = function(sender, e)
			-- index_right = index
			-- FillMachine(index)
			-- sender.Empty = true
			-- sender.Enable = false
			-- local c_control = ptr_cast(sender:GetChildByIndex(2))
			-- c_control.Visible = false
		-- end,
		-- SpawnNewpropControl()
	}
end

daoju_info_page = Gui.Create()
{
	Gui.Control "ctrl_ib_container"
	{							
		Size = Vector2(519, 400),
		Location = Vector2(5, 5),
		BackgroundColor = ARGB(0, 255, 255, 255),
			
		create_daoju_page(1, 0, 0),
		create_daoju_page(2, 1, 0),
		create_daoju_page(3, 2, 0),
		create_daoju_page(4, 3, 0),
		create_daoju_page(5, 4, 0),
		
		create_daoju_page(6, 0, 1),
		create_daoju_page(7, 1, 1),
		create_daoju_page(8, 2, 1),
		create_daoju_page(9, 3, 1),
		create_daoju_page(10, 4, 1),
		
		create_daoju_page(11, 0, 2),
		create_daoju_page(12, 1, 2),
		create_daoju_page(13, 2, 2),
		create_daoju_page(14, 3, 2),
		create_daoju_page(15, 4, 2),
		
		create_daoju_page(16, 0, 3),
		create_daoju_page(17, 1, 3),
		create_daoju_page(18, 2, 3),
		create_daoju_page(19, 3, 3),
		create_daoju_page(20, 4, 3),
	},
}

--素材
function create_material_page(index, line, list)
	return Gui.ItemBoxBtn
	{
		Style = "Gui.ItemBoxBtn_ib",
		Size = Vector2(104, 100),
		Location = Vector2(104*line, 100*list),
		
		EventSelected = function(sender, e)
			if material_info_page and sender.Loading == false then
				for i = 1, 20 do
					local ibbtn = ptr_cast(material_info_page.ctrl_ib_container:GetChildByIndex(i-1))
					if i == index then
						ibbtn.Selected = true
						Player_storage.btn_OK.Enable = true
					else
						ibbtn.Selected = false
					end
				end
			end
		end,
		
		EventMouseEnter = function(sender, e)
			L_ToolTips.FillMailWindow(index, Player_storage_modal.root)
		end,
		EventToolTipsShow = function(sender, e)
			L_ToolTips.ShowToolTipsShowWindow(sender,Vector2(1200,900),Vector2(406+104*line,222+100*list))
		end,
		EventMouseLeave = function(sender, e)
			L_ToolTips.HideToolTipsWindow()
		end,
		
		SpawnNewpropControl()
		-- EventMouseRightDown = function(sender, e)
			-- if rpc_date[index] then
				-- tuozhuai.root.Parent = L_LobbyMain.LobbyMainWin.LobbyMain_Root
				-- index_tz = index
				-- tuozhuai.root.Visible = true
				-- local lobby_state = ptr_cast(game.CurrentState)
				-- local cursor_ScreenSize = lobby_state:GetScreenSize()
				-- local cursor_pos = lobby_state:GetCursorPos()
				-- tuozhuai.Image.Location = Vector2(cursor_pos.x-((cursor_ScreenSize.x - cursor_ScreenSize.y / 3 * 4) / 2) - 51, cursor_pos.y - 34)
				-- tuozhuai.Image.Size = Vector2(72, 68)
				-- if rpc_date[index].color == 1 or rpc_date[index].color == 2 or rpc_date[index].color == 3 or rpc_date[index].color == 4 then
					-- tuozhuai.Image.Skin = Gui.ControlSkin
					-- {
						-- BackgroundImage = Gui.Image("LobbyUI/ibt_icon/"..rpc_date[index].name.."_"..rpc_date[index].color..".tga", Vector4(0, 0, 0, 0)),
					-- }
				-- else
					-- tuozhuai.Image.Skin = Gui.ControlSkin
					-- {
						-- BackgroundImage = Gui.Image("LobbyUI/ibt_icon/"..rpc_date[index].name..".tga", Vector4(0, 0, 0, 0)),
					-- }
				-- end
				-- local ibbtn = ptr_cast(material_info_page.ctrl_ib_container:GetChildByIndex(index-1))
				-- ibbtn.ItemIcon.alpha = 80
			-- end
			-- Highlight(current_selected,rpc_date[index].mType)
		-- end,
		-- EventMouseEnter = function(sender, e)
			-- if sender.Loading == false then
				-- L_ToolTips.FillToolTipsWindow(5, index, sender)
			-- end
		-- end,
		-- EventToolTipsShow = function(sender, e)
			-- L_ToolTips.ShowToolTipsShowWindow(sender)
		-- end,
		-- EventMouseLeave = function(sender, e)
			-- L_ToolTips.HideToolTipsWindow()
		-- end,
		-- EventMouseUp = function(sender, e)
			-- index_right = index
			-- FillMachine(index)
			-- sender.Empty = true
			-- sender.Enable = false
			-- local c_control = ptr_cast(sender:GetChildByIndex(2))
			-- c_control.Visible = false
		-- end,
		-- SpawnNewpropControl()
	}
end

function SpawnNewpropControl()
	return Gui.Control 
	{
		Size = Vector2(70, 16),
		Location = Vector2(29, 78),
		BackgroundColor = ARGB(0, 255, 255, 255),
		Gui.Control "c1"
		{
			Size = Vector2(20, 16),
			Location = Vector2(5, 0),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Visible = false,
		},
		Gui.Control "c2"
		{
			Size = Vector2(20, 16),
			Location = Vector2(20, 0),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Visible = false,
		},
		Gui.Control "c3"
		{
			Size = Vector2(20, 16),
			Location = Vector2(35, 0),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Visible = false,
		},
		Gui.Control "c4"
		{
			Size = Vector2(20, 16),
			Location = Vector2(50, 0),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Visible = false,
		},
	}
end

material_info_page = Gui.Create()
{
	Gui.Control "ctrl_ib_container"
	{							
		Size = Vector2(519, 400),
		Location = Vector2(5, 5),
		BackgroundColor = ARGB(0, 255, 255, 255),
			
		create_material_page(1, 0, 0),
		create_material_page(2, 1, 0),
		create_material_page(3, 2, 0),
		create_material_page(4, 3, 0),
		create_material_page(5, 4, 0),
		
		create_material_page(6, 0, 1),
		create_material_page(7, 1, 1),
		create_material_page(8, 2, 1),
		create_material_page(9, 3, 1),
		create_material_page(10, 4, 1),
		
		create_material_page(11, 0, 2),
		create_material_page(12, 1, 2),
		create_material_page(13, 2, 2),
		create_material_page(14, 3, 2),
		create_material_page(15, 4, 2),
		
		create_material_page(16, 0, 3),
		create_material_page(17, 1, 3),
		create_material_page(18, 2, 3),
		create_material_page(19, 3, 3),
		create_material_page(20, 4, 3),
	},
}

function FillStorage()
	weapon_info_page.ctrl_ib_container.Parent = nil
	dress_info_page.ctrl_ib_container.Parent = nil
	accessories_info_page.ctrl_ib_container.Parent = nil
	daoju_info_page.ctrl_ib_container.Parent = nil
	material_info_page.ctrl_ib_container.Parent = nil
	local args = nil
	
	if current_selected == 5 then
		for i = 1, 20 do
			local ibbtn = ptr_cast(material_info_page.ctrl_ib_container:GetChildByIndex(i-1))
			ibbtn.Selected = false
			ibbtn.Loading = true
			ibbtn.Enable = true
			ibbtn.ItemLevel = nil
		end
	elseif current_selected == 1 then
		for i = 1, 12 do
			local ibbtn = ptr_cast(weapon_info_page.ctrl_ib_container:GetChildByIndex(i-1))
			ibbtn.Selected = false
			ibbtn.Enable = true
			ibbtn.ItemLevel = nil
		end
	elseif current_selected == 2 then
		for i = 1, 10 do
			local ibbtn = ptr_cast(dress_info_page.ctrl_ib_container:GetChildByIndex(i-1))
			ibbtn.Selected = false
			ibbtn.Enable = true
			ibbtn.ItemLevel = nil
		end
	elseif current_selected == 3 then
		for i = 1, 20 do
			local ibbtn = ptr_cast(accessories_info_page.ctrl_ib_container:GetChildByIndex(i-1))
			ibbtn.Selected = false
			ibbtn.Enable = true
			ibbtn.ItemLevel = nil
		end
	elseif current_selected == 4 then
		for i = 1, 20 do
			local ibbtn = ptr_cast(daoju_info_page.ctrl_ib_container:GetChildByIndex(i-1))
			ibbtn.Selected = false
			ibbtn.Enable = true
			ibbtn.ItemLevel = nil
		end
	end
	
	args = {pid = ptr_cast(game.CurrentState):GetCharacterId(), cid = current_characters,type = current_selected, page = current_page}
	rpc.safecallload("email_item_list", args,
	function (data)
		rpc_date = data.items
		current_pages = data.pages
		Player_storage.lb_page_number.Text = current_page.."/"..current_pages
		local items = data.items
		
		if items then
			if current_selected == 1 then
				if weapon_info_page then
					for i = 1, 12 do
						if items[i] then
							local ibbtn = ptr_cast(weapon_info_page.ctrl_ib_container:GetChildByIndex(i-1))
							if items[i].color >= 1 and items[i].color <= 8 then
								ibbtn.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..items[i].name.."_"..items[i].color..".tga")
							else
								ibbtn.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..items[i].name..".tga")
							end
							ibbtn.ItemLevel = Skin.rarelevel[math.ceil(items[i].common.rareLevel/25)]
							ibbtn.Padding = Vector4(0, 0, 0, 7)
							if ibbtn.ItemIcon then
								ibbtn.ItemIcon.alpha = 255
							end
							
							if items[i].isBind == "N" then
								ibbtn.CanSelect = true
							else
								ibbtn.CanSelect = false
								ibbtn.ItemIcon.alpha = 80
							end
							ibbtn.Empty = false
							ibbtn.GoodsID = items[i].sid
						else
							local ibbtn = ptr_cast(weapon_info_page.ctrl_ib_container:GetChildByIndex(i-1))
							ibbtn.Enable = false
							ibbtn.ItemIcon = nil
							ibbtn.GoodsID = -1
							ibbtn.ItemLevel = nil
						end
					end
					-- if Weapon_table.page == current_page and Weapon_table.index ~= -1 and Weapon_table.cid == current_characters and Weapon_table.type == current_selected then
						-- local ibbtn = ptr_cast(weapon_info_page.ctrl_ib_container:GetChildByIndex(Weapon_table.index-1))
						-- ibbtn.Empty = true
						-- ibbtn.Enable = false
					-- end
				end
			elseif current_selected == 2 then
				if dress_info_page then
					for i = 1, 10 do
						if items[i] then
							local ibbtn = ptr_cast(dress_info_page.ctrl_ib_container:GetChildByIndex(i-1))
							if items[i].color >= 1 and items[i].color <= 8 then
								ibbtn.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..items[i].name.."_"..items[i].color..".tga")
							else
								ibbtn.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..items[i].name..".tga")
							end
							ibbtn.ItemLevel = Skin.rarelevel[math.ceil(items[i].common.rareLevel/25)]
							ibbtn.Padding = Vector4(0, 0, 0, 7)
							if items[i].isBind == "N" then
								ibbtn.CanSelect = true
							else
								ibbtn.CanSelect = false
								ibbtn.ItemIcon.alpha = 80
							end
							ibbtn.Empty = false
						else
							local ibbtn = ptr_cast(dress_info_page.ctrl_ib_container:GetChildByIndex(i-1))
							ibbtn.Enable = false
							ibbtn.ItemIcon = nil
							ibbtn.ItemLevel = nil
						end
					end
					-- if Weapon_table.page == current_page and Weapon_table.index ~= -1 and Weapon_table.cid == current_characters and Weapon_table.type == current_selected then
						-- local ibbtn = ptr_cast(dress_info_page.ctrl_ib_container:GetChildByIndex(Weapon_table.index-1))
						-- ibbtn.Empty = true
						-- ibbtn.Enable = false
					-- end
				end
			elseif current_selected == 3 then
				if accessories_info_page then
					for i = 1, 20 do
						if items[i] then
							local ibbtn = ptr_cast(accessories_info_page.ctrl_ib_container:GetChildByIndex(i-1))
							if items[i].color >= 1 and items[i].color <= 8 then
								ibbtn.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..items[i].name.."_"..items[i].color..".tga")
							else
								ibbtn.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..items[i].name..".tga")
							end
							ibbtn.ItemLevel = Skin.rarelevel[math.ceil(items[i].common.rareLevel/25)]
							ibbtn.Padding = Vector4(0, 0, 0, 7)
							if items[i].isBind == "N" then
								ibbtn.CanSelect = true
							else
								ibbtn.CanSelect = false
								ibbtn.ItemIcon.alpha = 80
							end
							ibbtn.Empty = false
						else
							local ibbtn = ptr_cast(accessories_info_page.ctrl_ib_container:GetChildByIndex(i-1))
							ibbtn.Enable = false
							ibbtn.ItemIcon = nil
							ibbtn.ItemLevel = nil
						end
					end
					-- if Weapon_table.page == current_page and Weapon_table.index ~= -1 and Weapon_table.cid == current_characters and Weapon_table.type == current_selected then
						-- local ibbtn = ptr_cast(accessories_info_page.ctrl_ib_container:GetChildByIndex(Weapon_table.index-1))
						-- ibbtn.Empty = true
						-- ibbtn.Enable = false
					-- end
				end
			elseif current_selected == 4 then
				if daoju_info_page then
					for i = 1, 20 do
						if items[i] then
							local ibbtn = ptr_cast(daoju_info_page.ctrl_ib_container:GetChildByIndex(i-1))
							if items[i].color >= 1 and items[i].color <= 8 then
								ibbtn.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..items[i].name.."_"..items[i].color..".tga")
							else
								ibbtn.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..items[i].name..".tga")
							end
							ibbtn.ItemLevel = Skin.rarelevel[math.ceil(items[i].common.rareLevel/25)]
							ibbtn.Padding = Vector4(0, 0, 0, 7)
							if items[i].isBind == "N" then
								ibbtn.CanSelect = true
							else
								ibbtn.CanSelect = false
								ibbtn.ItemIcon.alpha = 80
							end
							ibbtn.Empty = false
						else
							local ibbtn = ptr_cast(daoju_info_page.ctrl_ib_container:GetChildByIndex(i-1))
							ibbtn.Enable = false
							ibbtn.ItemIcon = nil
							ibbtn.ItemLevel = nil
						end
					end
					-- if Weapon_table.page == current_page and Weapon_table.index ~= -1 and Weapon_table.cid == current_characters and Weapon_table.type == current_selected then
						-- local ibbtn = ptr_cast(daoju_info_page.ctrl_ib_container:GetChildByIndex(Weapon_table.index-1))
						-- ibbtn.Empty = true
						-- ibbtn.Enable = false
					-- end
				end
			elseif current_selected == 5 then
				if material_info_page then
					for i = 1, 20 do
						local ibbtn = ptr_cast(material_info_page.ctrl_ib_container:GetChildByIndex(i-1))
						local c_control = ptr_cast(ibbtn:GetChildByIndex(2))
						if items[i] then
						
							if items[i].color >= 1 and items[i].color <= 8 then
								ibbtn.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..items[i].name.."_"..items[i].color..".tga")
							else
								ibbtn.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..items[i].name..".tga")
							end
							ibbtn.ItemLevel = Skin.rarelevel[math.ceil(items[i].common.rareLevel/25)]
							ibbtn.Padding = Vector4(0, 0, 0, 7)
							L_LobbyMain.FillNumber(items[i].common.quantity, c_control)
							if items[i].isBind == "N" then
								ibbtn.CanSelect = true
							else
								ibbtn.CanSelect = false
								ibbtn.ItemIcon.alpha = 80
							end
							c_control.Visible = true
						else
							local ibbtn = ptr_cast(material_info_page.ctrl_ib_container:GetChildByIndex(i-1))
							ibbtn.Enable = false
							ibbtn.ItemIcon = nil
							c_control.Visible = false
							ibbtn.ItemLevel = nil
						end
						ibbtn.Loading = false
					end
				end
			end
		end
	end)
	if current_selected == 1 then
		weapon_info_page.ctrl_ib_container.Parent = Player_storage.right
	elseif current_selected == 2 then
		dress_info_page.ctrl_ib_container.Parent = Player_storage.right
	elseif current_selected == 3 then
		accessories_info_page.ctrl_ib_container.Parent = Player_storage.right
	elseif current_selected == 4 then
		daoju_info_page.ctrl_ib_container.Parent = Player_storage.right
	elseif current_selected == 5 then
		material_info_page.ctrl_ib_container.Parent = Player_storage.right
	end
	Player_storage.btn_OK.Enable = false
end

function ResetType()
	Player_storage.wuqi.PushDown = false
	Player_storage.fuzhuang.PushDown = false
	Player_storage.shipin.PushDown = false
	Player_storage.daoju.PushDown = false
	Player_storage.sucai.PushDown = false
	-- Player_storage.dalibao.PushDown = false
	FillStorage()
end

function ResetCharacters()
	for i = 1, 10 do
		local btn = ptr_cast(Player_storage["tab_btn_"..i])
		if btn.Visible == true then
			btn.PushDown = false
		end
	end
	FillStorage()
end

function setup_new_mail()
	New_mail_modal = ModalWindow.GetNew()
	New_mail_modal.root.Size = Vector2(1200, 900)
	New_mail_modal.AllowEscToExit = false
	New_mail.root.Parent = New_mail_modal.root
	local cbx = New_mail.outbox_name_text
	cbx:RemoveAll()
	local list = L_LobbyMain.Friends_rpc_data
	for k, v in ipairs(list) do 
        cbx:AddItem(v[3])
	end
	New_mail.outbox_zhuti_text.Text = ""
	New_mail.neirong_text.Text = ""
	
	local Playerlist = Player_List.ltv_box
	Playerlist:DeleteColumns()
	Playerlist:AddColumn("",346, "kAlignCenterMiddle")
end

function setup_player_list()
	Player_list_modal = ModalWindow.GetNew()
	Player_list_modal.root.Size = Vector2(392, 522)
	Player_list_modal.AllowEscToExit = false
	Player_List.root.Parent = Player_list_modal.root
end

function setup_Player_storage()
	Player_storage_modal = ModalWindow.GetNew()
	Player_storage_modal.root.Size = Vector2(1200, 900)
	Player_storage_modal.AllowEscToExit = false
	Player_storage.root.Parent = Player_storage_modal.root
	ResetCharacters()
	Player_storage["tab_btn_1"].PushDown = true
end

function setup_gift_mail()
	gift_mail_modal = ModalWindow.GetNew()
	gift_mail_modal.root.Size = Vector2(408, 277)
	gift_mail_modal.AllowEscToExit = false
	Gift_Win.Gift.Parent = gift_mail_modal.root
	Gui.Align(Gift_Win.Gift, 0.5, 0.5)
end

function FillMail()
	if Mail_root_ui then
		Mail_root_ui.Scroll.AutoScrollMinSize = Vector2(0, 0)
		local ltv = Mail_root_ui.ltv_box
		local root = ltv.RootItem     
		ltv:DeleteAll()
		Mail_root_ui.btn_inbox_delete.Enable = false
		-- Mail_root_ui.open_gift.Visible = false
		Mail_root_ui.Image_Layout:OnDestroy()
		rpc.safecallload("email_list",{type = Type},
		function(data)
			local list = data.list
			local ltv = Mail_root_ui.ltv_box
			ltv:DeleteAll()
			local i = 1
			for _,v in ipairs(list) do
				Mail_root_ui.btn_inbox_delete.Enable = true
				local sub_item = ltv:AddItem(ltv.RootItem,nil)
				sub_item.CheckBoxSize = Vector2(34, 34)
				sub_item.CheckBoxLocation = Vector2(50, 15)
				sub_item.ID = v[1]
				sub_item:AddSubItem(v[4])
				if v[4] == lang:GetText("系统邮件") then
					sub_item.TextColor = ARGB(255, 212, 71, 56)
				else
					sub_item.TextColor = ARGB(255, 215, 232, 226)
				end
				sub_item.FontSize = 18
				sub_item.Deviate_x = 95
				sub_item.Deviate_y = -30
				sub_item.SecLineHighlightTextColor = ARGB(255, 81, 79, 79)
				sub_item.SecLineFontSize = 16
				sub_item.HighlightTextColor = ARGB(255, 1, 1, 1)
				sub_item.SecLineText = v[2]
				sub_item.SecLineColor = ARGB(255, 192, 186, 173)
				sub_item.SecLineTextColunm = 1
				sub_item:AddSubItem("")
				sub_item:AddSubItem(v[3])
				-- sub_item.NAME = 1 表示邮件未读 sub_item.VIP = 1 有附件 0表示没附件 2表示有附件已收
				if Type == 0 then
					if v[6] == "N" then
						sub_item.NAME = "1"
						if v[5] == "1" then
							sub_item:SetIcon(2, Gui.Icon("LobbyUI/mail/lb_mail_R_ico_attach.dds"),Vector4(0, 0, 0, 0))
							sub_item:SetIcon(3, Gui.Icon("LobbyUI/mail/lb_mail_R_ico_newmail.dds"),Vector4(0, 0, 0, 0))
						else
							sub_item:SetIcon(3, Gui.Icon("LobbyUI/mail/lb_mail_R_ico_newmail.dds"),Vector4(0, 0, 0, 0))
						end
					else
						sub_item.NAME = "0"
						if v[5] == "1" and v[7] == "Y" then
							sub_item:SetIcon(2, Gui.Icon("LobbyUI/mail/lb_mail_R_ico_attach.dds"),Vector4(0, 0, 0, 0))
						elseif v[5] == "1" and v[7] == "N" then
							sub_item:SetIcon(2, Gui.Icon("LobbyUI/mail/lb_mail_R_ico_openattach.dds"),Vector4(0, 0, 0, 0))
						end
						sub_item:SetIcon(3, Gui.Icon("LobbyUI/mail/lb_mail_R_ico_openmail.dds"),Vector4(0, 0, 0, 0))
					end
					if v[5] == "1" then
						if v[7] == "Y" then
							sub_item.VIP = 1
						else
							sub_item.VIP = 2
						end
					else
						sub_item.VIP = 0
					end
				end	
				if i % 2 == 1 then
					sub_item.BGSkin = Skin.ListItemSkin_MailSingleWitchCheck
				else
					sub_item.BGSkin = Skin.ListItemSkin_MailDoubleWitchCheck
				end
				i = i + 1
			end
			if i < 7 then
				local j 
				for j = i ,6 do
					local sub_item = ltv:AddItem(ltv.RootItem)
					sub_item.CanSelect = false
					sub_item.CheckBoxSize = Vector2(0, 0)
					sub_item.CheckVisible = false
					sub_item.ID = -1
					if j % 2 == 1 then
						sub_item.BGSkin = Skin.ListItemSkin_MailSingleWitchCheck
					else
						sub_item.BGSkin = Skin.ListItemSkin_MailDoubleWitchCheck
					end
				end
			end
		end)
	end
	MessageBox.CloseWaiter()
end

function FillFriendsList()
	local list = L_LobbyMain.Friends_rpc_data
	local ltv = Player_List.ltv_box   
	ltv:DeleteAll()
	local i = 1
	if list then
		for k, v in ipairs(list) do 
			local sub_item = ltv:AddItem(ltv.RootItem,v[3])
			if i % 2 == 1 then
				sub_item.BGSkin = Skin.ListItemSkin_Single
			else
				sub_item.BGSkin = Skin.ListItemSkin_Double
			end
			i = i + 1
		end
	end

	if i < 11 then
		local j 
		for j = i ,10 do
			local sub_item = ltv:AddItem(ltv.RootItem)
			sub_item.CanSelect = false
			sub_item.ID = -1
			if j % 2 == 1 then
				sub_item.BGSkin = Skin.ListItemSkin_Single
			else
				sub_item.BGSkin = Skin.ListItemSkin_Double
			end
		end
	end		
end

function FillPartnerList()
	local list
	local args = {pid = ptr_cast(game.CurrentState):GetCharacterId(), displayOnline = 0}
	rpc.safecall("partners_list",args,
				function (data) 
					list = data.partnerslist
					local ltv = Player_List.ltv_box   
					ltv:DeleteAll()
					-- local list = L_LobbyMain.partners_rpc_data
					local i = 1
					if list then
						for k, v in ipairs(list) do 
							local sub_item = ltv:AddItem(ltv.RootItem,v[3])
							if i % 2 == 1 then
								sub_item.BGSkin = Skin.ListItemSkin_Single
							else
								sub_item.BGSkin = Skin.ListItemSkin_Double
							end
							i = i + 1
						end
					end

					if i < 11 then
						local j 
						for j = i ,10 do
							local sub_item = ltv:AddItem(ltv.RootItem)
							sub_item.CanSelect = false
							sub_item.ID = -1
							if j % 2 == 1 then
								sub_item.BGSkin = Skin.ListItemSkin_Single
							else
								sub_item.BGSkin = Skin.ListItemSkin_Double
							end
						end
					end		
				end)

end

function FillZhanduiList()
	local list = L_Friends.Team_RPC_List
	local ltv = Player_List.ltv_box   
	ltv:DeleteAll()
	local i = 1
	if list then
		for k, v in ipairs(list) do 
			if v[4] ~= L_LobbyMain.PersonalInfo_data.name then
				local sub_item = ltv:AddItem(ltv.RootItem,v[4])
				if i % 2 == 1 then
					sub_item.BGSkin = Skin.ListItemSkin_Single
				else
					sub_item.BGSkin = Skin.ListItemSkin_Double
				end
				i = i + 1
			end
		end
	end

	if i < 11 then
		local j 
		for j = i ,10 do
			local sub_item = ltv:AddItem(ltv.RootItem)
			sub_item.CanSelect = false
			sub_item.ID = -1
			if j % 2 == 1 then
				sub_item.BGSkin = Skin.ListItemSkin_Single
			else
				sub_item.BGSkin = Skin.ListItemSkin_Double
			end
		end
	end		
end

function FillChannelPlayerList()
	local list = L_Friends.Channel_list
	local ltv = Player_List.ltv_box   
	ltv:DeleteAll()
	local i = 1
	while list do
		if list.name ~= L_LobbyMain.PersonalInfo_data.name then
			local sub_item = ltv:AddItem(ltv.RootItem,list.name)
			if i % 2 == 1 then
				sub_item.BGSkin = Skin.ListItemSkin_Single
			else
				sub_item.BGSkin = Skin.ListItemSkin_Double
			end
			i = i + 1
		end
		list = list.next
	end

	if i < 11 then
		local j 
		for j = i ,10 do
			local sub_item = ltv:AddItem(ltv.RootItem)
			sub_item.CanSelect = false
			sub_item.ID = -1
			if j % 2 == 1 then
				sub_item.BGSkin = Skin.ListItemSkin_Single
			else
				sub_item.BGSkin = Skin.ListItemSkin_Double
			end
		end
	end	
end

function nrcount()
	no_read_count = 0
	rpc.safecall("email_list",{type = 0},
	function(data)
	if no_read_count == 0 then
		local list = data.list
		for _,v in ipairs(list) do
			if v[6] == "N" then
				no_read_count = no_read_count + 1
			end
		end
		if no_read_count == 0 then
			L_LobbyMain.LobbyMainWin.youjian.Skin = Gui.ControlSkin{BackgroundImage = nil,}
			L_LobbyMain.LobbyMainWin.youjian_mun.Text = ""
			L_LobbyMain.LobbyMainWin_Foot.btn_Mail.blink = false
			L_LobbyMain.LobbyMainWin_Foot.btn_Mail.Text = ""
		else
			L_LobbyMain.LobbyMainWin.youjian.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/xin/lb_menu_tip.dds", Vector4(0 , 0, 0, 0)),}
			L_LobbyMain.LobbyMainWin.youjian_mun.Text = no_read_count
			L_LobbyMain.LobbyMainWin_Foot.btn_Mail.Text = ""
		end
		
		if Mail_root_ui then
			Mail_root_ui.In_Box.Text = lang:GetText("收件箱 (")..no_read_count..")"
		end
	end
	end)
end

function Initialize()
	nrcount()
end

function Finalize()
end

function Show(parent_win)
	L_LobbyMain.HideAll()
	L_LobbyMain.LobbyMainWin_Foot.btn_Mail.PushDown = true
	
	if Mail_root_ui then
		nrcount()
		FillMail()
		Mail_root_ui.reply.Visible = false
	else
		Mail_root_ui = Gui.Create(parent_win)(Mail_root)
		Mail_root_ui.root.Parent = parent_win
		local list = Mail_root_ui.ltv_box
		list:DeleteColumns()
		list:AddColumn("",115, "kAlignCenterMiddle")
		list:AddColumn(lang:GetText("主题"),340, "kAlignLeftMiddle")
		list:AddColumn("",100, "kAlignLeftMiddle")
		list:AddColumn(lang:GetText("日期"),100, "kAlignCenterMiddle")
		list:AddColumn("",80, "kAlignCenterMiddle")
		function list.EventSelectItemChange(sender)
			local mail = sender.SelectedItem
			local mail1
			if mail and mail.ID ~= -1 then
				MessageBox.ShowWaiter(lang:GetText("正在读取邮件..."))
				rpc.safecall("email_get",{type = Type,mid = mail.ID},function(data) 
				mail1 = data.mail
				if mail1 == nil then
					MessageBox.CloseWaiter()
					return
				end
				if mail1[2] == lang:GetText("系统邮件") then
					Mail_root_ui.root_TextArea.TextColor = ARGB(255, 145, 16, 11)
				else
					Mail_root_ui.root_TextArea.TextColor = ARGB(255, 53, 53, 51)
				end
				Mail_root_ui.root_TextArea.Text = mail1[4] 
				local t = {} -- table to store the indices  
				Mail_root_ui.root_TextArea.Size = Vector2(300, Mail_root_ui.root_TextArea.Count_n * 24 + 34)
				local count_Image = 0
				Mail_root_ui.Image_Layout:OnDestroy()
				if mail1.items[1] then
					for i,v in ipairs(mail1.items) do
						local Image = Gui.Create()
						{
							Gui.Control "Back"
							{
								Size = Vector2(172, 78),
								BackgroundColor = ARGB(0, 255, 255, 255),
								Gui.Control "root1"
								{
									BackgroundColor = ARGB(255, 255, 255, 255),
									Skin = Gui.ControlSkin
									{
										BackgroundImage = Gui.Image("LobbyUI/mail/lb_mail_item_bg.dds", Vector4(14, 14, 14, 14)),
									},
									Gui.Control "root"
									{
										Dock = "kDockFill",
										BackgroundColor = ARGB(255, 255, 255, 255),
									},
								},
							},
						}
						if v.type == 1 then
							count_Image = count_Image + 93
							Image.root1.Size = Vector2(172, 78)
							Image.root1.Location = Vector2(0, 0)
						elseif v.type == 2 then
							count_Image = count_Image + 171
							Image.root1.Size = Vector2(84, 156)
							Image.root1.Location = Vector2(44, 0)
							Image.Back.Size = Vector2(172, 156)
						else
							count_Image = count_Image + 126
							Image.root1.Size = Vector2(114, 111)
							Image.root1.Location = Vector2(29, 0)
							Image.Back.Size = Vector2(172, 111)
						end
						if v.color > 0 and v.color < 8 then
							Image.root.Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/ibt_icon/"..v.name.."_"..v.color..".tga", Vector4(0, 0, 0, 0)),
							}
						else
							Image.root.Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/ibt_icon/"..v.name..".tga", Vector4(0, 0, 0, 0)),
							}
						end
						Image.Back.Parent = Mail_root_ui.Image_Layout
						if v.unit_type == 2 then
							v.unit = 1
						end
						if v.unit_type ~= -1 then
							L_Characters.CreatPresentNumCtr(Image.root1,v.unit,Image.root1.Size.x,Image.root1.Size.y)
						end
					end
				end
				Mail_root_ui.Image_Layout.Size = Vector2(300, Mail_root_ui.root_TextArea.Count_n * 24 + 34 + count_Image + 15)
				Mail_root_ui.Image_Layout.Padding = Vector4(50, Mail_root_ui.root_TextArea.Count_n * 24 + 49, 0, 0)
				Mail_root_ui.Scroll.AutoScrollMinSize = Vector2(0, Mail_root_ui.root_TextArea.Count_n * 24 + 34 + count_Image + 15)
				Mail_root_ui.Scroll.VScrollBarWidth = 8
				Mail_root_ui.Scroll.VScrollBarButtonSize = 0.1
				name = mail1[2]
				theme = mail1[3]
				if Type == 0 then
					if name ~= lang:GetText("系统邮件") then
						Mail_root_ui.reply.Visible = true
					else
						Mail_root_ui.reply.Visible = false
					end
					if mail1.attachment then
						Mail_root_ui.open_gift.Visible = true
						-- Mail_root_ui.fujian_gift.Visible = true
						Mail_root_ui.c_gift.Visible = true
						Mail_root_ui.ibx_gift:OnDestroy()
						gift_data[1] = mail1.attachment
						if mail1.attachment.color > 0 and mail1.attachment.color < 8 then
							Mail_root_ui.ibx_gift.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..mail1.attachment.name.."_"..mail1.attachment.color..".tga", Vector4(0, 0, 0, 0))
						else
							Mail_root_ui.ibx_gift.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..mail1.attachment.name..".tga", Vector4(0, 0, 0, 0))
						end
						L_Characters.CreatPresentNumCtr(Mail_root_ui.ibx_gift,mail1.attachment.unit,200,111)
						-- Mail_root_ui.fujian_gift.Text = "       "..mail1.attachment.display_name
						-- ItemType(Mail_root_ui.gift_item_type,mail1.attachment.type)
						
						-- Gift_Win.W_name.Text = mail1.attachment.display_name
						m_id = mail1[1]
						-- if mail1.attachment.type == 1 then
							-- Gift_Win.Image.Size = Vector2(168, 76)
							-- Gift_Win.Image.Location = Vector2(0, 40)
						-- elseif mail1.attachment.type == 2 then
							-- Gift_Win.Image.Size = Vector2(80, 156)
							-- Gift_Win.Image.Location = Vector2(44, 0)
						-- else
							-- Gift_Win.Image.Size = Vector2(72, 68)
							-- Gift_Win.Image.Location = Vector2(50, 44)
						-- end
					else
						Mail_root_ui.open_gift.Visible = false
						-- Mail_root_ui.fujian_gift.Visible = false
						Mail_root_ui.c_gift.Visible = false
					end
					if mail.VIP == 1 then
						mail:SetIcon(2, Gui.Icon("LobbyUI/mail/lb_mail_R_ico_attach.dds"),Vector4(0, 0, 0, 0))
					elseif mail.VIP == 2 then
						mail:SetIcon(2, Gui.Icon("LobbyUI/mail/lb_mail_R_ico_openattach.dds"),Vector4(0, 0, 0, 0))
					end
					
					mail:SetIcon(3, Gui.Icon("LobbyUI/mail/lb_mail_R_ico_openmail.dds"),Vector4(0, 0, 0, 0))
					mail.NAME = "0"
				end
				MessageBox.CloseWaiter()
				nrcount()
				end)
			else
				Mail_root_ui.open_gift.Visible = false
				-- Mail_root_ui.fujian_gift.Visible = false
				Mail_root_ui.c_gift.Visible = false
				Mail_root_ui.root_TextArea.Text = ""
				MessageBox.CloseWaiter()
			end
		end
		nrcount()
		FillMail()
	end
	Mail_root_ui.root.Parent = parent_win
	rpc.safecall("character_list", {pid = ptr_cast(game.CurrentState):GetCharacterId()}, L_LobbyMain.FillCharacterClass)
end

function IsSelected(ltv)
	local flag = false
	local item = ltv.RootItem.FirstChild
	while item do
		if item.Check then
			flag = true
			break
		else
			item = item.Next
		end
	end
	return flag
end

function ItemType(btn,type)
	btn.Visible = true
	if type == 1 then
		btn.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/mail/lb_mail_sign_ico_wuqi.dds", Vector4(16, 12, 16, 45)),}
	elseif type == 2 then
		btn.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/mail/lb_mail_sign_ico_fuzhuang.dds", Vector4(16, 12, 16, 45)),}
	elseif type == 3 then
		btn.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/mail/lb_mail_sign_ico_peishi.dds", Vector4(16, 12, 16, 45)),}
	elseif type == 4 then
		btn.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/mail/lb_mail_sign_ico_daoju.dds", Vector4(16, 12, 16, 45)),}
	elseif type == 5 then
		btn.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/mail/lb_mail_sign_ico_sucai.dds", Vector4(16, 12, 16, 45)),}	
	elseif type == 7 then
		btn.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/mail/lb_mail_sign_ico_libao.dds", Vector4(16, 12, 16, 45)),}		
	end
end

function GetSelectedMail(ltv)
	warning1 = 0
	warning2 = 0
	local check_list = {}
	local item = ltv.RootItem.FirstChild
	while item do
		if item.Check then
			table.insert(check_list,item.ID)
			if item.NAME == "1" and warning1 == 0 then
				warning1 = 1
			end
			if item.VIP == 1 and warning2 == 0 then
				warning2 = 1
			end 
		end
		item = item.Next
	end
	local item = ltv.SelectedItem
	if #check_list > 0 then
		return table.concat(check_list,",")
	else
		return ""
	end
end

function AllSelectMail(ltv)
	local item = ltv.RootItem.FirstChild
	local flag = false
	while item do
		if item.Check == false then
			flag = true
			break
		end
		item = item.Next
	end
	item = ltv.RootItem.FirstChild
	while item do
		item.Check = flag
		item = item.Next
	end
end

function Hide()
	if	Mail_root_ui then
		Mail_root_ui.root.Parent = nil
	end
end