module("L_SecondCode", package.seeall)

SecondCode = Gui.Create()
{
	Gui.Control "root"
	{
		Size = Vector2(626, 532),
		Dock = "kDockCenter",
		BackgroundColor = ARGB(0, 255, 255, 255),
		Gui.Control
		{
			Size = Vector2(526, 432),
			Dock = "kDockCenter",
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/lb_common_up_bg_01.dds", Vector4(200, 20, 100, 0)),
			},
			Gui.Control "first_secondcode"
			{
				Size = Vector2(526, 432),
				Location = Vector2(0, 0),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Visible = false,
				Gui.Label
				{
					Size = Vector2(526, 35),
					Location = Vector2(0, 30),
					TextColor = ARGB(255, 0, 0, 0),
					FontSize = 28,
					TextAlign = "kAlignCenterMiddle",
					Text = lang:GetText("设置二级密码"),
				},
				Gui.Label
				{
					Size = Vector2(470, 90),
					Location = Vector2(28, 53),
					TextColor = ARGB(255, 193, 27, 27),
					FontSize = 16,
					TextAlign = "kAlignCenterMiddle",
					Text = lang:GetText("设置二级密码后，在游戏中进行敏感操作时将先进行二级\n密码验证，以保证你的虚拟财产安全。"),
				},
				Gui.Label
				{
					Size = Vector2(170, 35),
					Location = Vector2(30, 141),
					TextColor = ARGB(255, 0, 0, 0),
					FontSize = 20,
					TextAlign = "kAlignLeftMiddle",
					Text = lang:GetText("设置密码"),
				},
				Gui.Textbox "secondcode_password"
				{
					Size = Vector2(233,40),
					FontSize = 18,
					Location = Vector2(204, 140),
					BackgroundColor = ARGB(255, 255, 255, 255),
					TextColor = ARGB(255, 210, 209, 193),
					TextPassword = true,
					InputNumberCharacterOnly = true,
					MaxLength = 18,
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/TopList/lb_rank_bg_01.dds", Vector4(10, 10, 10, 10)),
					},
				},
				
				Gui.Label
				{
					Size = Vector2(300, 20),
					Location = Vector2(204, 195),
					TextColor = ARGB(255, 193, 27, 27),
					FontSize = 16,
					TextAlign = "kAlignLeftTop",
					Text = lang:GetText("6~18位字符，可由字母和数字组成。"),
				},
				
				Gui.Label
				{
					Size = Vector2(170, 35),
					Location = Vector2(30, 229),
					TextColor = ARGB(255, 0, 0, 0),
					FontSize = 20,
					TextAlign = "kAlignLeftMiddle",
					Text = lang:GetText("确认密码"),
				},
				Gui.Textbox "first_secondcode_password_confirm"
				{
					Size = Vector2(233,40),
					FontSize = 18,
					Location = Vector2(204, 228),
					BackgroundColor = ARGB(255, 255, 255, 255),
					TextColor = ARGB(255, 210, 209, 193),
					TextPassword = true,
					InputNumberCharacterOnly = true,
					MaxLength = 18,
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/TopList/lb_rank_bg_01.dds", Vector4(10, 10, 10, 10)),
					},
				},
				Gui.Label "first_warn"
				{
					Size = Vector2(250, 20),
					Location = Vector2(204, 283),
					TextColor = ARGB(255, 193, 27, 27),
					FontSize = 16,
					TextAlign = "kAlignLeftTop",
					Text = lang:GetText("请再次确认密码。"),
				},
			},
			
			Gui.Control "second_secondcode"
			{
				Size = Vector2(526, 432),
				Location = Vector2(0, 0),
				BackgroundColor = ARGB(0, 255, 255, 255),
				-- Visible = false,
				Gui.Label
				{
					Size = Vector2(526, 35),
					Location = Vector2(0, 30),
					TextColor = ARGB(255, 0, 0, 0),
					FontSize = 28,
					TextAlign = "kAlignCenterMiddle",
					Text = lang:GetText("修改二级密码"),
				},
				Gui.Label "delete_password"
				{
					Size = Vector2(426, 50),
					Location = Vector2(50, 70),
					TextColor = ARGB(255, 193, 27, 27),
					FontSize = 16,
					TextAlign = "kAlignCenterMiddle",
					Text = lang:GetText("你已经使用忘记密码功能，密码将在3天后被清除，\n在此期间验证密码将会退出清除状态"),
				},
				Gui.Label
				{
					Size = Vector2(200, 35),
					Location = Vector2(32, 124),
					TextColor = ARGB(255, 0, 0, 0),
					FontSize = 18,
					TextAlign = "kAlignLeftMiddle",
					Text = lang:GetText("请输入旧密码"),
				},
				Gui.Button "forget_password"
				{
					Size = Vector2(200, 20),
					Location = Vector2(147, 165),
					TextColor = ARGB(255, 193, 27, 27),
					HighlightTextColor = ARGB(255,246,139,106),
					FontSize = 16,
					TextAlign = "kAlignLeftTop",
					Text = lang:GetText("忘记密码"),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = nil,
						HoverImage = nil,
						DownImage = nil,
						DisabledImage = nil,	
					},
					EventClick = function()
						Hide_SecondCode()
						Show_ForgetCodeWarn()
					end,
				},
				Gui.Textbox "old_password"
				{
					Size = Vector2(217,40),
					FontSize = 18,
					Location = Vector2(246, 123),
					BackgroundColor = ARGB(255, 255, 255, 255),
					TextColor = ARGB(255, 210, 209, 193),
					TextPassword = true,
					InputNumberCharacterOnly = true,
					MaxLength = 18,
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/TopList/lb_rank_bg_01.dds", Vector4(10, 10, 10, 10)),
					},
				},
				
				Gui.Label
				{
					Size = Vector2(200, 35),
					Location = Vector2(32, 187),
					TextColor = ARGB(255, 0, 0, 0),
					FontSize = 18,
					TextAlign = "kAlignLeftMiddle",
					Text = lang:GetText("请输入新密码"),
				},
				
				Gui.Textbox "new_password"
				{
					Size = Vector2(217,40),
					FontSize = 18,
					Location = Vector2(246, 186),
					BackgroundColor = ARGB(255, 255, 255, 255),
					TextColor = ARGB(255, 210, 209, 193),
					TextPassword = true,
					InputNumberCharacterOnly = true,
					MaxLength = 18,
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/TopList/lb_rank_bg_01.dds", Vector4(10, 10, 10, 10)),
					},
				},
				
				Gui.Label
				{
					Size = Vector2(300, 20),
					Location = Vector2(246, 228),
					TextColor = ARGB(255, 193, 27, 27),
					FontSize = 16,
					TextAlign = "kAlignLeftTop",
					Text = lang:GetText("6~18位字符，可由字母和数字组成。"),
				},
				
				Gui.Label
				{
					Size = Vector2(250, 35),
					Location = Vector2(32, 250),
					TextColor = ARGB(255, 0, 0, 0),
					FontSize = 18,
					TextAlign = "kAlignLeftMiddle",
					Text = lang:GetText("请再次输入密码"),
				},
				Gui.Textbox "second_secondcode_password_confirm"
				{
					Size = Vector2(217,40),
					FontSize = 18,
					Location = Vector2(246, 249),
					BackgroundColor = ARGB(255, 255, 255, 255),
					TextColor = ARGB(255, 210, 209, 193),
					TextPassword = true,
					InputNumberCharacterOnly = true,
					MaxLength = 18,
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/TopList/lb_rank_bg_01.dds", Vector4(10, 10, 10, 10)),
					},
				},
				Gui.Label "second_warn"
				{
					Size = Vector2(250, 20),
					Location = Vector2(246, 291),
					TextColor = ARGB(255, 193, 27, 27),
					FontSize = 16,
					TextAlign = "kAlignLeftTop",
					Text = lang:GetText("请再次确认密码。"),
				},
			},
			--确定
			Gui.Button
			{
				Location = Vector2(90, 362),
				Size = Vector2(128, 40),
				BackgroundColor = ARGB(255,255,255,255),
				Text = lang:GetText("确 定"),
				TextAlign = "kAlignCenterMiddle",
				TextColor = ARGB(255,50,50,50),
				HighlightTextColor = ARGB(255, 50 ,50 ,50),
				Padding = Vector4(0, 0, 0, 5),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/lb_common_up_button_normal.dds", Vector4(20, 20, 20, 20)),
					HoverImage = Gui.Image("LobbyUI/lb_common_up_button_hover.dds", Vector4(20, 20, 20, 20)),
					DownImage = Gui.Image("LobbyUI/lb_common_up_button_down.dds", Vector4(20, 20, 20, 20)),
					DisabledImage = Gui.Image("LobbyUI/lb_common_up_button_disabled.dds", Vector4(20, 20, 20, 20)),			
				},
				
				EventClick = function()
					if SecondCode.first_secondcode.Visible then
						if game:TextLenght(SecondCode.secondcode_password.Text) < 6 or game:TextLenght(SecondCode.first_secondcode_password_confirm.Text) < 6 then
							Show_SecondCodeWarn(lang:GetText("二级密码格式"),lang:GetText("错误"),"!")
							return
						end
						if SecondCode.secondcode_password.Text == SecondCode.first_secondcode_password_confirm.Text then
							rpc.safecallload("setcheck_second_password", {pid = ptr_cast(game.CurrentState):GetCharacterId(),password = SecondCode.secondcode_password.Text,type = 0},
							function (data)
								if data.status == 0 then
									Show_SecondCodeWarn(lang:GetText("二级密码设置"),lang:GetText("失败"),"!")
								else
									Show_SecondCodeWarn(lang:GetText("二级密码设置"),lang:GetText("完成"),"!")
								end
								Hide_SecondCode()
							end)
						else
							SecondCode.first_warn.Text = lang:GetText("密码输入不一致")
						end
					elseif SecondCode.second_secondcode.Visible then
						if game:TextLenght(SecondCode.old_password.Text) < 6 then
							Show_SecondCodeWarn(lang:GetText("二级密码格式"),lang:GetText("错误"),"!")
							return
						end
						if game:TextLenght(SecondCode.new_password.Text) < 6 then
							Show_SecondCodeWarn(lang:GetText("二级密码格式"),lang:GetText("错误"),"!")
							return
						end
						if game:TextLenght(SecondCode.second_secondcode_password_confirm.Text) < 6 then
							Show_SecondCodeWarn(lang:GetText("二级密码格式"),lang:GetText("错误"),"!")
							return
						end
						if SecondCode.new_password.Text == SecondCode.second_secondcode_password_confirm.Text then
							rpc.safecallload("reset_second_password", {pid = ptr_cast(game.CurrentState):GetCharacterId(),newpassword = SecondCode.new_password.Text,oldpassword = SecondCode.old_password.Text},
							function (data)
								if data.status == 0 then
									Show_SecondCodeWarn(lang:GetText("二级密码修改"),lang:GetText("失败"),"!")
								else
									Show_SecondCodeWarn(lang:GetText("二级密码修改"),lang:GetText("完成"),"!")
								end
								Hide_SecondCode()
							end)
						else
							SecondCode.second_warn.Text = lang:GetText("密码输入不一致")
						end
					end
					
				end
			},
			
			--取消
			Gui.Button
			{
				Location = Vector2(308, 362),
				Size = Vector2(128, 40),
				BackgroundColor = ARGB(255,255,255,255),
				Text = lang:GetText("取 消"),
				TextAlign = "kAlignCenterMiddle",
				TextColor = ARGB(255,50,50,50),
				HighlightTextColor = ARGB(255, 50 ,50 ,50),
				Padding = Vector4(0, 0, 0, 5),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/lb_common_up_button_normal.dds", Vector4(20, 20, 20, 20)),
					HoverImage = Gui.Image("LobbyUI/lb_common_up_button_hover.dds", Vector4(20, 20, 20, 20)),
					DownImage = Gui.Image("LobbyUI/lb_common_up_button_down.dds", Vector4(20, 20, 20, 20)),
					DisabledImage = Gui.Image("LobbyUI/lb_common_up_button_disabled.dds", Vector4(20, 20, 20, 20)),			
				},
				
				EventClick = function()
					Hide_SecondCode()
				end
			},
		},	
		--退出
		Gui.Button
		{
			Size = Vector2(48,48),
			Location = Vector2(542, 36),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_normal.dds", Vector4(10, 10, 10, 10)),
				HoverImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_hover.dds", Vector4(10, 10, 10, 10)),
				DownImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_down.dds", Vector4(10, 10, 10, 10)),
				DisabledImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_disabled.dds", Vector4(0, 0, 0, 0)),	
			},
			EventClick = function()
				Hide_SecondCode()
			end,
		},
	},
}

SecondCodeWarn = Gui.Create()
{
	Gui.Control "root"
	{
		Size = Vector2(526, 272),
		Dock = "kDockCenter",
		BackgroundColor = ARGB(255, 255, 255, 255),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/lb_common_up_bg_01.dds", Vector4(200, 20, 100, 0)),
		},
		Gui.Control 
		{
			Size = Vector2(80,68),
			Location = Vector2(65, 79),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/mokuai_title02.dds",Vector4(0, 0, 0, 0)),
			},
		},
		
		Gui.RichEdit "warn_msg_1"
		{
			Size = Vector2(400, 40),
			Location = Vector2(152, 100),
			FontSize = 20,
			BackgroundColor = ARGB(0, 255, 255, 255),
		},

		--确定
		Gui.Button
		{
			Location = Vector2(204, 222),
			Size = Vector2(128, 40),
			BackgroundColor = ARGB(255,255,255,255),
			Text = lang:GetText("确 定"),
			TextAlign = "kAlignCenterMiddle",
			TextColor = ARGB(255,50,50,50),
			HighlightTextColor = ARGB(255, 50 ,50 ,50),
			Padding = Vector4(0, 0, 0, 5),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/lb_common_up_button_normal.dds", Vector4(20, 20, 20, 20)),
				HoverImage = Gui.Image("LobbyUI/lb_common_up_button_hover.dds", Vector4(20, 20, 20, 20)),
				DownImage = Gui.Image("LobbyUI/lb_common_up_button_down.dds", Vector4(20, 20, 20, 20)),
				DisabledImage = Gui.Image("LobbyUI/lb_common_up_button_disabled.dds", Vector4(20, 20, 20, 20)),			
			},
			
			EventClick = function()
				Hide_SecondCodeWarn()
			end
		},
	},
}

ForgetCodeWarn = Gui.Create()
{
	Gui.Control "root"
	{
		Size = Vector2(526, 272),
		Dock = "kDockCenter",
		BackgroundColor = ARGB(255, 255, 255, 255),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/lb_common_up_bg_01.dds", Vector4(200, 20, 100, 0)),
		},
		Gui.Control 
		{
			Size = Vector2(80,68),
			Location = Vector2(55, 49),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/mokuai_title02.dds",Vector4(0, 0, 0, 0)),
			},
		},
		
		-- Gui.Label
		-- {
			-- Size = Vector2(400, 80),
			-- Location = Vector2(246, 241),
			-- TextColor = ARGB(255, 0, 0, 0),
			-- FontSize = 20,
			-- TextAlign = "kAlignLeftTop",
			-- Text = lang:GetText("申请强制清除二级密码，3天后将清\n除，在此期间您可以使用正确的二级密\n码验证退出清除状态。"),
		-- },
		Gui.RichEdit "warn_msg_1"
		{
			Size = Vector2(330, 120),
			Location = Vector2(146, 56),
			FontSize = 20,
			BackgroundColor = ARGB(0, 255, 255, 255),
		},
		
		Gui.Label
		{
			Size = Vector2(526, 80),
			Location = Vector2(0, 157),
			TextColor = ARGB(255, 0, 0, 0),
			FontSize = 20,
			TextAlign = "kAlignCenterMiddle",
			Text = lang:GetText("请确认强制清除二级密码吗？"),
		},
		
		--确定
		Gui.Button
		{
			Location = Vector2(90, 222),
			Size = Vector2(128, 40),
			BackgroundColor = ARGB(255,255,255,255),
			Text = lang:GetText("确 定"),
			TextAlign = "kAlignCenterMiddle",
			TextColor = ARGB(255,50,50,50),
			HighlightTextColor = ARGB(255, 50 ,50 ,50),
			Padding = Vector4(0, 0, 0, 5),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/lb_common_up_button_normal.dds", Vector4(20, 20, 20, 20)),
				HoverImage = Gui.Image("LobbyUI/lb_common_up_button_hover.dds", Vector4(20, 20, 20, 20)),
				DownImage = Gui.Image("LobbyUI/lb_common_up_button_down.dds", Vector4(20, 20, 20, 20)),
				DisabledImage = Gui.Image("LobbyUI/lb_common_up_button_disabled.dds", Vector4(20, 20, 20, 20)),			
			},
			
			EventClick = function()
				rpc.safecallload("forget_second_password", {pid = ptr_cast(game.CurrentState):GetCharacterId()},
				function (data)
					-- if data.time then
						-- local day = math.floor(data.time/(24*3600))
							-- Show_SecondCodeWarn(lang:GetText("二级密码将于"),day..lang:GetText("天后"),lang:GetText("清除状态"))
						-- return
					-- end
					Show_SecondCodeWarn(lang:GetText("二级密码进入"),lang:GetText("清除状态"),"!")
					Hide_ForgetCodeWarn()
				end)
			end
		},
		
		--取消
		Gui.Button
		{
			Location = Vector2(308, 222),
			Size = Vector2(128, 40),
			BackgroundColor = ARGB(255,255,255,255),
			Text = lang:GetText("取 消"),
			TextAlign = "kAlignCenterMiddle",
			TextColor = ARGB(255,50,50,50),
			HighlightTextColor = ARGB(255, 50 ,50 ,50),
			Padding = Vector4(0, 0, 0, 5),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/lb_common_up_button_normal.dds", Vector4(20, 20, 20, 20)),
				HoverImage = Gui.Image("LobbyUI/lb_common_up_button_hover.dds", Vector4(20, 20, 20, 20)),
				DownImage = Gui.Image("LobbyUI/lb_common_up_button_down.dds", Vector4(20, 20, 20, 20)),
				DisabledImage = Gui.Image("LobbyUI/lb_common_up_button_disabled.dds", Vector4(20, 20, 20, 20)),			
			},
			
			EventClick = function()
				Hide_ForgetCodeWarn()
			end
		},
	},
}

SecondCodeConfirm = Gui.Create()
{
	Gui.Control "root"
	{
		Size = Vector2(626, 382),
		Dock = "kDockCenter",
		BackgroundColor = ARGB(0, 255, 255, 255),
		Gui.Control
		{
			Size = Vector2(526, 282),
			Dock = "kDockCenter",
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/lb_common_up_bg_01.dds", Vector4(200, 20, 100, 0)),
			},

			Gui.Label
			{
				Size = Vector2(526, 35),
				Location = Vector2(0, 30),
				TextColor = ARGB(255, 0, 0, 0),
				FontSize = 28,
				TextAlign = "kAlignCenterMiddle",
				Text = lang:GetText("二级密码验证"),
			},
			Gui.Label
			{
				Size = Vector2(500, 50),
				Location = Vector2(13, 63),
				TextColor = ARGB(255, 193, 27, 27),
				FontSize = 16,
				TextAlign = "kAlignCenterMiddle",
				Text = lang:GetText("根据你的操作进行敏感操作前需要进行二级密码确认。"),
			},
			Gui.Label "delete_password"
			{
				Size = Vector2(426, 50),
				Location = Vector2(50, 96),
				TextColor = ARGB(255, 193, 27, 27),
				FontSize = 16,
				TextAlign = "kAlignCenterMiddle",
				Text = lang:GetText("你已经使用忘记密码功能，密码将在3天后被清除，\n在此期间验证密码将会退出清除状态"),
			},
			Gui.Label
			{
				Size = Vector2(130, 35),
				Location = Vector2(70, 151),
				TextColor = ARGB(255, 0, 0, 0),
				FontSize = 28,
				TextAlign = "kAlignLeftMiddle",
				Text = lang:GetText("输入密码"),
			},
			Gui.Button "forget_password"
			{
				Size = Vector2(200, 20),
				Location = Vector2(80, 195),
				TextColor = ARGB(255, 193, 27, 27),
				HighlightTextColor = ARGB(255,246,139,106),
				FontSize = 16,
				TextAlign = "kAlignLeftTop",
				Text = lang:GetText("忘记密码"),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = nil,
					HoverImage = nil,
					DownImage = nil,
					DisabledImage = nil,	
				},
				EventClick = function()
					Hide_SecondCodeConfirm()
					Show_ForgetCodeWarn()
				end,
			},
			Gui.Textbox "secondcode_password"
			{
				Size = Vector2(233,40),
				FontSize = 18,
				Location = Vector2(204, 150),
				BackgroundColor = ARGB(255, 255, 255, 255),
				TextColor = ARGB(255, 210, 209, 193),
				TextPassword = true,
				InputNumberCharacterOnly = true,
				MaxLength = 18,
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/TopList/lb_rank_bg_01.dds", Vector4(10, 10, 10, 10)),
				},
			},
			Gui.Label
			{
				Size = Vector2(300, 20),
				Location = Vector2(204, 195),
				TextColor = ARGB(255, 193, 27, 27),
				FontSize = 16,
				TextAlign = "kAlignLeftTop",
				Text = lang:GetText("6~18位字符，可由字母和数字组成。"),
			},
		
			--确定
			Gui.Button
			{
				Location = Vector2(90, 232),
				Size = Vector2(128, 40),
				BackgroundColor = ARGB(255,255,255,255),
				Text = lang:GetText("确 定"),
				TextAlign = "kAlignCenterMiddle",
				TextColor = ARGB(255,50,50,50),
				HighlightTextColor = ARGB(255, 50 ,50 ,50),
				Padding = Vector4(0, 0, 0, 5),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/lb_common_up_button_normal.dds", Vector4(20, 20, 20, 20)),
					HoverImage = Gui.Image("LobbyUI/lb_common_up_button_hover.dds", Vector4(20, 20, 20, 20)),
					DownImage = Gui.Image("LobbyUI/lb_common_up_button_down.dds", Vector4(20, 20, 20, 20)),
					DisabledImage = Gui.Image("LobbyUI/lb_common_up_button_disabled.dds", Vector4(20, 20, 20, 20)),			
				},
				
				EventClick = function()
					if game:TextLenght(SecondCodeConfirm.secondcode_password.Text) < 6 then
						Show_SecondCodeWarn(lang:GetText("二级密码格式"),lang:GetText("错误"),"!")
						return
					end
					rpc.safecallload("setcheck_second_password", {pid = ptr_cast(game.CurrentState):GetCharacterId(),password = SecondCodeConfirm.secondcode_password.Text,type = 1},
					function (data)
						if data.status == 0 then
							Show_SecondCodeWarn(lang:GetText("二级密码验证"),lang:GetText("失败"),"!")
						else
							Show_SecondCodeWarn(lang:GetText("二级密码验证"),lang:GetText("成功"),"!")
						end
						Hide_SecondCode()
					end)
					Hide_SecondCodeConfirm()
				end
			},
			
			--取消
			Gui.Button
			{
				Location = Vector2(308, 232),
				Size = Vector2(128, 40),
				BackgroundColor = ARGB(255,255,255,255),
				Text = lang:GetText("取 消"),
				TextAlign = "kAlignCenterMiddle",
				TextColor = ARGB(255,50,50,50),
				HighlightTextColor = ARGB(255, 50 ,50 ,50),
				Padding = Vector4(0, 0, 0, 5),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/lb_common_up_button_normal.dds", Vector4(20, 20, 20, 20)),
					HoverImage = Gui.Image("LobbyUI/lb_common_up_button_hover.dds", Vector4(20, 20, 20, 20)),
					DownImage = Gui.Image("LobbyUI/lb_common_up_button_down.dds", Vector4(20, 20, 20, 20)),
					DisabledImage = Gui.Image("LobbyUI/lb_common_up_button_disabled.dds", Vector4(20, 20, 20, 20)),			
				},
				
				EventClick = function()
					Hide_SecondCodeConfirm()
				end
			},
		},	
		--退出
		Gui.Button
		{
			Size = Vector2(48,48),
			Location = Vector2(542, 36),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_normal.dds", Vector4(10, 10, 10, 10)),
				HoverImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_hover.dds", Vector4(10, 10, 10, 10)),
				DownImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_down.dds", Vector4(10, 10, 10, 10)),
				DisabledImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_disabled.dds", Vector4(0, 0, 0, 0)),	
			},
			EventClick = function()
				Hide_SecondCodeConfirm()
			end,
		},
	},
}

function Show_SecondCode()
	SecondCodemodel = ModalWindow.GetNew()
	SecondCodemodel.root.Size = Vector2(626,532)
	SecondCodemodel.AllowEscToExit = false
	SecondCode.root.Parent = SecondCodemodel.root
	SecondCode.first_warn.Text = lang:GetText("请再次确认密码。")
	SecondCode.second_warn.Text = lang:GetText("请再次确认密码。")
	SecondCode.secondcode_password.Text = ""
	SecondCode.first_secondcode_password_confirm.Text = ""
	SecondCode.old_password.Text = ""
	SecondCode.new_password.Text = ""
	SecondCode.second_secondcode_password_confirm.Text = ""
end

function Hide_SecondCode()
	if SecondCodemodel then
		SecondCodemodel.Close()
		SecondCodemodel = nil
	end
end

function Show_SecondCodeWarn(st1,st2,st3)
	SecondCodeWarnmodel = ModalWindow.GetNew()
	SecondCodeWarnmodel.root.Size = Vector2(526,272)
	SecondCodeWarnmodel.AllowEscToExit = false
	SecondCodeWarn.root.Parent = SecondCodeWarnmodel.root
	
	SecondCodeWarn.warn_msg_1:CleanAll()
	SecondCodeWarn.warn_msg_1:AddMsg(st1.." ",ARGB(255, 0, 0, 0),true,false)
	SecondCodeWarn.warn_msg_1:AddMsg(" "..st2,ARGB(255, 207, 64, 0),false,false)
	SecondCodeWarn.warn_msg_1:AddMsg(st3,ARGB(255, 0, 0, 0),false,false)
end

function Hide_SecondCodeWarn()
	if SecondCodeWarnmodel then
		SecondCodeWarnmodel.Close()
		SecondCodeWarnmodel = nil
	end
end

function Show_ForgetCodeWarn()
	ForgetCodeWarnmodel = ModalWindow.GetNew()
	ForgetCodeWarnmodel.root.Size = Vector2(526,272)
	ForgetCodeWarnmodel.AllowEscToExit = false
	ForgetCodeWarn.root.Parent = ForgetCodeWarnmodel.root
	
	ForgetCodeWarn.warn_msg_1:CleanAll()
	ForgetCodeWarn.warn_msg_1:AddMsg(lang:GetText("申请强制清除二级密码，"),ARGB(255, 0, 0, 0),true,false)
	ForgetCodeWarn.warn_msg_1:AddMsg("3",ARGB(255, 207, 64, 0),false,false)
	ForgetCodeWarn.warn_msg_1:AddMsg(lang:GetText("天后将清除，在此期间您可以使用正确的二级密码验证退出清除状态。"),ARGB(255, 0, 0, 0),false,false)
end

function Hide_ForgetCodeWarn()
	if ForgetCodeWarnmodel then
		ForgetCodeWarnmodel.Close()
		ForgetCodeWarnmodel = nil
	end
end

function Show_SecondCodeConfirm()
	SecondCodeConfirmmodel = ModalWindow.GetNew()
	SecondCodeConfirmmodel.root.Size = Vector2(626,372)
	SecondCodeConfirmmodel.AllowEscToExit = false
	SecondCodeConfirm.root.Parent = SecondCodeConfirmmodel.root
	
	SecondCodeConfirm.secondcode_password.Text = ""
	L_SecondCode.SecondCodeConfirm.delete_password.Visible = false
	L_SecondCode.SecondCodeConfirm.forget_password.Visible = true
	rpc.safecallload("get_second_password_status", {pid = ptr_cast(game.CurrentState):GetCharacterId()},
	function (data)
		if data then
			if data.status == 2 then
				local day = math.floor(data.time/(24*3600))
				L_SecondCode.SecondCodeConfirm.delete_password.Visible = true
				L_SecondCode.SecondCodeConfirm.delete_password.Text = lang:GetText("你已经使用忘记密码功能，密码将在")..day..lang:GetText("天后被清除，\n在此期间验证密码将会退出清除状态")
				L_SecondCode.SecondCodeConfirm.forget_password.Visible = false
			end	
		end	
	end)
	if L_Present.tigerMachine_window_ui then
		L_Present.tigerMachine_window_ui.tiger_present_buy.Visible = true
		L_Present.tigerMachine_window_ui.tiger_continue.Visible = true
		L_Present.tigerMachine_window_ui.tiger_present_five.Visible = true
		L_Present.tigerMachine_window_ui.tiger_present_ten.Visible = true
	end
	if L_Characters.Charm_Bottle_Win_ui then
		L_Characters.Charm_Bottle_Open_Start = false
		L_Characters.Charm_Bottle_Win_ui.BTN_Charm_Start.Enable = true
	end
	if L_Compose.ui then
		L_Compose.ui.start.Enable = true
		L_Compose.ui.start1.Enable = true
		L_Compose.ui.start2.Enable = true
	end
end

function Hide_SecondCodeConfirm()
	if SecondCodeConfirmmodel then
		SecondCodeConfirmmodel.Close()
		SecondCodeConfirmmodel = nil
	end
end