module("L_PlaceLevelUp",package.seeall)

modalLevelUp = nil
t_id = nil
placeLevelUp = Gui.Create()
{
	Gui.Control "root"
	{
		Size = Vector2(735, 602),
		Dock = "kDockCenter",
		BackgroundColor = ARGB(0, 0, 0, 0),
		Gui.Control
		{
			Size = Vector2(720, 587),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Location = Vector2(0, 15),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/team/lb_contact_bg1_01.dds",Vector4(185, 164, 31, 45)),
			},
			Gui.Control "up"
			{
				Size = Vector2(685, 55),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Location = Vector2(17, 19),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/lb_shop_bg3_1.dds",Vector4(10, 10, 10, 10)),
				},
				Gui.Control 
				{
					Size = Vector2(269, 34),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Location = Vector2(11, 11),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/lb_yaoqing_bg.dds",Vector4(0, 0, 0, 0)),
					},
					Gui.Label
					{
						Size = Vector2(68, 18),
						Location = Vector2(5,9),
						Text = lang:GetText("您当前"),
						FontSize = 16,
						TextColor = ARGB(255, 255, 255, 255),
						TextAlign = "kAlignCenterMiddle",
					},
					Gui.Control
					{
						Size = Vector2(68, 17),
						Location = Vector2(82,8),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Skin.priceLevelIcon,
					},
					
					Gui.FlowLayout "placeLevel"
					{
						Size = Vector2(23, 20),
						Location = Vector2(164,7),
						Direction = "kHorizontal",
						Align = "kAlignRightMiddle",
						ControlAlign = "kAlignCenterMiddle",
						ControlSpace = 0,
					},
				},
				Gui.Control 
				{
					Size = Vector2(162, 25),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Location = Vector2(253, 17),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/lb_com_bg.dds",Vector4(45,0,20,0)),
					},
					Gui.Label
					{
						Size = Vector2(38, 17),
						Location = Vector2(7,4),
						Text = lang:GetText("时间"),
						FontSize = 16,
						TextColor = ARGB(255, 255, 255, 255),
						TextAlign = "kAlignCenterMiddle",
					},
					Gui.Label "time_lb"
					{
						Dock = "kDockFill",
						FontSize = 16,
						TextColor = ARGB(255, 255, 255, 255),
						TextPadding = Vector4(0,0,10,0),
						TextAlign = "kAlignRightMiddle",
					},
					Gui.TimeControl "ctrlTimer"
					{
						Size = Vector2(5,5),
						Dock = "kDockCenter",
						BackgroundColor = ARGB(0, 255, 255, 255),
						
					},
				},
				Gui.Button "levelUp_btn"
				{
					Size = Vector2(207, 27),
					Location = Vector2(438,14),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Text = lang:GetText("升级"),
					Skin = Skin.LevelUpBtnSkin,
					
				},
			},
			Gui.Control "down"
			{
				Size = Vector2(685,485),
				Location = Vector2(17,81),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Gui.Control 
				{
					Size = Vector2(685,437),
					Location = Vector2(0, 47),
					Gui.Control "pic_1"
					{
						Dock = "kDockFill",
						BackgroundColor = ARGB(255,255,255,255),
						Skin = Skin.levelPic[1],
						Visible = false,
					},
					
					Gui.Control "pic_2"
					{
						Dock = "kDockFill",
						BackgroundColor = ARGB(255,255,255,255),
						Skin = Skin.levelPic[2], 
						Visible = false,						
					},
					Gui.Control "pic_3"
					{
						Dock = "kDockFill",
						BackgroundColor = ARGB(255,255,255,255),
						Skin = Skin.levelPic[3],
						Visible = false,
					},
					Gui.Control "pic_4"
					{
						Dock = "kDockFill",
						BackgroundColor = ARGB(255,255,255,255),
						Skin = Skin.levelPic[4],
						Visible = false,
					},
					Gui.Control "pic_5"
					{
						Dock = "kDockFill",
						BackgroundColor = ARGB(255,255,255,255),
						Skin = Skin.levelPic[5],
						Visible = false,
					},
				},
				Gui.Button "lv_1"
				{
					Size = Vector2(120,56),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Location = Vector2(36, 0),
					Text = lang:GetText("等级1"),
					PushDown = false,
					Style = "PlaceLevelUpTabStyle",
				},
				Gui.Button "lv_2"
				{
					Size = Vector2(120,56),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Location = Vector2(36+121, 0),
					Text = lang:GetText("等级2"),
					PushDown = false,
					Style = "PlaceLevelUpTabStyle",
				},
				Gui.Button "lv_3"
				{
					Size = Vector2(120,56),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Location = Vector2(36+(121*2), 0),
					Text = lang:GetText("等级3"),
					PushDown = false,
					Style = "PlaceLevelUpTabStyle",
				},
				Gui.Button "lv_4"
				{
					Size = Vector2(120,56),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Location = Vector2(36+(121*3), 0),
					Text = lang:GetText("等级4"),
					Style = "PlaceLevelUpTabStyle",
					PushDown = false,
					
				},
				Gui.Button "lv_5"
				{
					Size = Vector2(120,56),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Location = Vector2(36+(121*4), 0),
					Text = lang:GetText("等级5"),
					PushDown = false,
					Style = "PlaceLevelUpTabStyle",
					
				},
				
			},
			
		},
		Gui.Button "close"
		{
			Size = Vector2(48, 48),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Location = Vector2(687, 0),
			--Hint = lang:GetText("关闭"),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_normal.dds", Vector4(10, 10, 10, 10)),
				HoverImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_hover.dds", Vector4(10, 10, 10, 10)),
				DownImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_down.dds", Vector4(10, 10, 10, 10)),
				DisabledImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_disabled.dds", Vector4(0, 0, 0, 0)),					
			},
			EventClick = function()
				Hide_LevelUp()
			end
		},
	},
}

function RpcCallPlaceLevelUp(t_id)
	rpc.safecallload("team_item_manage", {playerId = ptr_cast(game.CurrentState):GetCharacterId(),teamId = t_id,teamItemId = 0,playerItemId = -1,manageType = 1,storageType = -1},
	function(data)
		if data.placeLevelUp then
			L_LobbyMain.ShowFightnums(placeLevelUp.placeLevel,data.placeLevelUp.level,"team/lb_squad_number_01.dds")
			for i = 1,5 do
				placeLevelUp["lv_"..i].PushDown = false
				placeLevelUp["pic_"..i].Visible = false
				placeLevelUp["lv_"..i].EventClick = function(sender,e)
					for j = 1,5 do
						placeLevelUp["lv_"..j].PushDown = false
						placeLevelUp["pic_"..j].Visible = false
					end
					sender.PushDown = true
					placeLevelUp["pic_"..i].Visible = true
				end	
			end			
			placeLevelUp["lv_"..data.placeLevelUp.level].PushDown = true
			placeLevelUp["pic_"..data.placeLevelUp.level].Visible =true
			if data.placeLevelUp.levelUpTime <= 0 and data.placeLevelUp.isCanLevelUp == 1 then
				placeLevelUp.levelUp_btn.Enable = true
				placeLevelUp.ctrlTimer:CleanAll()
				placeLevelUp.levelUp_btn.Text = lang:GetText("升级")
				placeLevelUp.time_lb.Text = L_FightTeam.GethourMinuteSeconds(0)
			elseif data.placeLevelUp.levelUpTime > 0 and data.placeLevelUp.isCanLevelUp == 0 then
				placeLevelUp.levelUp_btn.Enable = true
				placeLevelUp.levelUp_btn.Text = lang:GetText("立即完成")
				
				--时间控件
				local t1 = os.clock()
				placeLevelUp.ctrlTimer:CleanAll()
				placeLevelUp.ctrlTimer:AddTime(tonumber(data.placeLevelUp.levelUpTime)/1000)		
				placeLevelUp.ctrlTimer.EventTimeUpdate = function(sender, e)
					local t2 = os.clock()
					local da = tonumber(data.placeLevelUp.levelUpTime)/1000 - (t2-t1)
					placeLevelUp.time_lb.Text = L_FightTeam.GethourMinuteSeconds(da*1000)
				end
				placeLevelUp.ctrlTimer.EventTimeOut = function(sender, e)
					RpcCallPlaceLevelUp(t_id)
					L_FightTeam.Fill_Header_Team()
				end					
			else
				placeLevelUp.levelUp_btn.Enable = false
				placeLevelUp.ctrlTimer:CleanAll()
				placeLevelUp.levelUp_btn.Text = lang:GetText("升级")
				placeLevelUp.time_lb.Text = L_FightTeam.GethourMinuteSeconds(0)
			end
			placeLevelUp.levelUp_btn.EventClick = function()
				if data.placeLevelUp.levelUpTime > 0 then
					callAddCDRpc()
				else
					MessageBox.ShowWithTwoButtons(lang:GetText("本次升级需要战队黑铁").. data.placeLevelUp.money,lang:GetText("确定"),lang:GetText("取消"),
							function()
								rpc.safecallload("confirm_level_up", {playerId = ptr_cast(game.CurrentState):GetCharacterId(),teamId = t_id},
								function(data)
									RpcCallPlaceLevelUp(t_id)
								end)
							end,
							nil)
				end				
			end
		end
	end)
end

function Show_PlaceLevelUp(tid)
	modalLevelUp = ModalWindow.GetNew()
	modalLevelUp.root.Size = Vector2(832,604)
	modalLevelUp.AllowEscToExit = false
	placeLevelUp.root.Parent = modalLevelUp.root
	t_id = tid
	RpcCallPlaceLevelUp(t_id)	
	
end

function Hide_LevelUp()
	if modalLevelUp then
		modalLevelUp.Close()
		modalLevelUp = nil
	end
end

-----param---------
-- pid      - 玩家id
-- type     - 1:个人   2:团队
-- iid      -ItemId       即 道具的ID ，团队物品: teamItemId ,个人物品 playerItemId
-- atype    -ActionType  1:查询 2:购买
-- ptype    -PayType     0:(查询,不用付费)  1:(半价)    2:(全价)
function callAddCDRpc()
	rpc.safecallload("get_fc_price", {pid = ptr_cast(game.CurrentState):GetCharacterId(),type = 3,iid = 0,atype = 1,ptype = 0},
				function(data)
					if data.error then
						MessageBox.ShowWithTimer(1,data.error)
						return
					else
						MessageBox.ShowWithTwoButtons(lang:GetText("您需要花费")..data.PRICE.fccost.."\n"..lang:GetText("FC点来加速！"),lang:GetText("确定"),lang:GetText("取消"),
							function()
								rpc.safecallload("get_fc_price",{pid = ptr_cast(game.CurrentState):GetCharacterId(),type = 3,iid = 0,atype = 2,ptype = data.PRICE.type},
								function(data)
									MessageBox.ShowWithTimer(1,lang:GetText("加速成功！"))
									RpcCallPlaceLevelUp(t_id)
									L_FightTeam.Fill_Header_Team()
								end)
							end,
							nil)
					end
				end)
end