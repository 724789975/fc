module("L_Present", package.seeall)

local level_present = {}
local rand_present = {}
local view_present = {}
local view_pintu = {}
local rand_pos = 0
local Chip = 0
local g_data = nil
local pitch_on_present = -1
local pitch_on_iamge = nil
local witch_level_present = -1
local view_present_page = -1
local view_present_index = 0
local total_page = -1
local present_title = {lang:GetText("青铜彩盒"),lang:GetText("白银彩盒"),lang:GetText("黄金彩盒")}
local is_chip = false
local is_cmoney = false
local present_index = -1
local rpc_data = {{}}
local key_item = {}
local random_data = nil
main_present_window_ui = nil

local pintuchance = false
local pintu_id = -1
local pintu_OK = false -- 彩盒转完才能点拼图
local pintu_all = false -- 是否得到所有拼图
local pintu_display = nil
local pintu_name = nil
local present_times = 1
local static_present_times = 1
local fiveten_page = 1
local present_data = {}
local discount_data = nil
local discount_index = nil
local Rapid_Shopping_index = 1
local aaaaa = 0
function create_button(index)
	return Gui.Control
	{
		Size = Vector2(63, 143),
		BackgroundColor = ARGB(0, 255, 255, 255),
		Gui.Control
		{
			Size = Vector2(60, 116),
			Location = Vector2(3, 0),
			BackgroundColor = ARGB(0, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/Compose/lb_synthesis_strengthening_bg_03.dds", Vector4(0, 0, 0, 0)),
			},
			Gui.Label ("text1"..index)
			{
				Size = Vector2(63, 20),
				Location = Vector2(3, 0),
				TextAlign = "kAlignLeftMiddle",
				TextColor = ARGB(255, 255, 2, 0),
				FontSize = 12,
				Text = "124456",
			},
			Gui.Label ("text2"..index)
			{
				Size = Vector2(61, 20),
				Location = Vector2(0, 0),
				TextAlign = "kAlignRightMiddle",
				TextColor = ARGB(255, 255, 244, 0),
				FontSize = 16,
				Text = "11111",
				Visible = false,
			},
			Gui.Label ("text3"..index)
			{
				Size = Vector2(61, 20),
				Location = Vector2(0, 20),
				TextAlign = "kAlignRightMiddle",
				TextColor = ARGB(255, 219, 159, 50),
				FontSize = 16,
				Text = "11111",
				Visible = false,
			},
			Gui.Control 
			{
				Size = Vector2(26, 1),
				Location = Vector2(70, 31),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/WarZone/Present/ib_gift_discount_line.dds", Vector4(0, 0, 0, 0)),
				},
			},
			
			Gui.ItemBoxBtn ("icon"..index)
			{
				Style = "Gui.ItemBoxBtn_ib",
				CanSelect = false,
				Size = Vector2(70, 70),
				Location = Vector2(0, 28),
				Skin = Gui.ItemBoxBtnSkin
				{
					NeutralNormalImage = nil,
					NeutralHoverImage = nil,
					NeutralSelectedImage = nil,
					NeutralDisabledImage = nil,
				}
			},
			Gui.Control ("sellout"..index)
			{
				Size = Vector2(80, 80),
				Location = Vector2(0, 23),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/WarZone/Present/ib_gift_discount_sellout_ico.dds", Vector4(0, 0, 0, 0)),
				},
			},
		},
		
		Gui.Button ("btn"..index)
		{
			Size = Vector2(62, 35),
			Location = Vector2(0, 113),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Text = lang:GetText("购买"),
			TextColor = ARGB(255, 0, 0, 0),
			Padding = Vector4(0, 0, 0, 5),
			FontSize = 16,
			TextAlign = "kAlignCenterMiddle",
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_v2_01_normal.dds", Vector4(10, 10, 10, 10)),
				HoverImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_v2_01_hover.dds", Vector4(10, 10, 10, 10)),
				DownImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_v2_01_down.dds", Vector4(10, 10, 10, 10)),
				DisabledImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_v2_01_disabled.dds", Vector4(10, 10, 10, 10)),
			},
			EventClick = function(Sender,e)
				discount_index = (index - 1)%3 + 1
				if index > 3 then
					Rapid_Shopping_index = 2
				else
					Rapid_Shopping_index = 1
				end
				ShowRapidDiscount()
			end
		},
	}
end

local main_present_window =
{
	Gui.Control "ctrl_main_present_window"
	{
		Size = Vector2(1121, 586),
		Location = Vector2(14, 25),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/lb_shop_bg2.dds", Vector4(14, 14, 14, 14)),
		},
	
		Gui.AnimControl "Timer"
		{
			BackgroundColor = ARGB(0, 255, 255, 255),
			Size = Vector2(0.5, 0.5),
			
			EventFinish = function(Sender,e)
				Sender:ReStart()
				rand_pos = rand_pos + 1
				FillRandImage(1,rand_pos)
				FillRandImage(2,rand_pos)
				FillRandImage(3,rand_pos)
			end
		},
		
		Gui.Control "buy_present_BG"
		{
			Size = Vector2(1113, 551),
			Location = Vector2(6, 35),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_daoju_bg.tga", Vector4(22, 22, 22, 22)),
			},
			
			Gui.Control "button_back"
			{
				Size = Vector2(1108, 142),
				Location = Vector2(3, 412),
				BackgroundColor = ARGB(255, 255, 255, 255),
				
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/WarZone/Present/shop_gift_bar.dds", Vector4(0,0,0,0)),
				},
			},
		},
		
		Gui.Control 
		{
			Size = Vector2(160, 486),
			Location = Vector2(951, 48),
			BackgroundColor = ARGB(255, 255, 255, 255),
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/WarZone/Present/ib_gift_discount_bg_01.dds", Vector4(0, 0, 0, 0)),
			},
			Gui.FlowLayout "discount"
			{
				Size = Vector2(63, 430),
				Location = Vector2(10, 43),
				LineSpace = 0,
				create_button(1),
				create_button(2),
				create_button(3),
			},
			Gui.FlowLayout
			{
				Size = Vector2(63, 430),
				Location = Vector2(83, 43),
				LineSpace = 0,
				create_button(4),
				create_button(5),
				create_button(6),
			},
		},
		
		-- Gui.Control
		-- {
			-- Size = Vector2(20, 32),
			-- Location = Vector2(875, 527),
			-- BackgroundColor = ARGB(255, 255, 255, 255),
			
			-- Skin = Gui.ControlSkin
			-- {
				-- BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/free_change/medol_s01.dds", Vector4(0,0,0,0)),
			-- },
		-- },
		
		Gui.Label
		{
			Size = Vector2(80, 40),
			Location = Vector2(855, 529),
			TextColor = ARGB(255,0, 0, 0),
			BackgroundColor = ARGB(0, 255, 255, 255),
			FontSize = 14,
			TextAlign = "kAlignCenterMiddle",
			-- Text = lang:GetText("勋章库存："),
		},
		Gui.Label "left_chip_bg"
		{
			Size = Vector2(200, 40),
			Location = Vector2(936, 530),
			TextColor = ARGB(255,0, 0, 0),
			BackgroundColor = ARGB(0, 255, 255, 255),
			FontSize = 18,
			TextAlign = "kAlignLeftMiddle",
			Text = "",
		},
		
		Gui.Label "left_chip_bg"
		{
			Size = Vector2(200, 40),
			Location = Vector2(936, 530),
			TextColor = ARGB(255,0, 0, 0),
			BackgroundColor = ARGB(0, 255, 255, 255),
			FontSize = 18,
			TextAlign = "kAlignLeftMiddle",
			Text = "",
		},
		
		Gui.Label "xunzhang"
		{
			Size = Vector2(100, 40),
			Location = Vector2(220-15, 466),
			TextColor = ARGB(255,255, 244, 0),
			BackgroundColor = ARGB(0, 255, 255, 255),
			FontSize = 18,
			Enable = false,
			TextAlign = "kAlignCenterMiddle",
			Text = "1000/22",
		},
		Gui.Label "xunzhang1"
		{
			Size = Vector2(100, 40),
			Location = Vector2(537-15, 466),
			TextColor = ARGB(255,255, 244, 0),
			BackgroundColor = ARGB(0, 255, 255, 255),
			FontSize = 18,
			Enable = false,
			TextAlign = "kAlignCenterMiddle",
			Text = "1000/22",
		},
		Gui.Label "xunzhang2"
		{
			Size = Vector2(100, 40),
			Location = Vector2(848-15, 466),
			TextColor = ARGB(255,255, 244, 0),
			BackgroundColor = ARGB(0, 255, 255, 255),
			FontSize = 18,
			Enable = false,
			TextAlign = "kAlignCenterMiddle",
			Text = "1000/22",
		},
		Gui.Label "qingtong"
		{
			Size = Vector2(100, 40),
			Location = Vector2(100-45, 466),
			TextColor = ARGB(255,255, 244, 0),
			BackgroundColor = ARGB(0, 255, 255, 255),
			FontSize = 18,
			Enable = false,
			TextAlign = "kAlignCenterMiddle",
			Text = "1000/22",
		},
		Gui.Label "baiyin"
		{
			Size = Vector2(100, 40),
			Location = Vector2(537-160, 466),
			TextColor = ARGB(255,255, 244, 0),
			BackgroundColor = ARGB(0, 255, 255, 255),
			FontSize = 18,
			TextAlign = "kAlignCenterMiddle",
			Text = "1000/22",
			Enable = false,
		},
		Gui.Label "huangjin"
		{
			Size = Vector2(100, 40),
			Location = Vector2(848-160, 466),
			TextColor = ARGB(255,255, 244, 0),
			BackgroundColor = ARGB(0, 255, 255, 255),
			FontSize = 18,
			TextAlign = "kAlignCenterMiddle",
			Text = "1000/22",
			Enable = false,
		},
		Gui.Label
		{
			Size = Vector2(100, 40),
			Location = Vector2(200, 529),
			TextColor = ARGB(255,0, 0, 0),
			BackgroundColor = ARGB(0, 255, 255, 255),
			FontSize = 14,
			TextAlign = "kAlignCenterMiddle",
			-- Text = lang:GetText("青铜卡库存："),
		},
		
		Gui.Label "cooper_key_bg"
		{
			Size = Vector2(200, 40),
			Location = Vector2(301, 530),
			TextColor = ARGB(255,0, 0, 0),
			BackgroundColor = ARGB(0, 255, 255, 255),
			FontSize = 18,
			TextAlign = "kAlignLeftMiddle",
			Text = "",
		},
		
		Gui.Label "cooper_key"
		{
			Size = Vector2(200, 40),
			Location = Vector2(300, 529),
			TextColor = ARGB(255,255, 244, 0),
			BackgroundColor = ARGB(0, 255, 255, 255),
			FontSize = 18,
			TextAlign = "kAlignLeftMiddle",
			Text = "",
		},
		
		Gui.Label
		{
			Size = Vector2(100, 40),
			Location = Vector2(390, 529),
			TextColor = ARGB(255,0, 0, 0),
			BackgroundColor = ARGB(0, 255, 255, 255),
			FontSize = 14,
			TextAlign = "kAlignCenterMiddle",
			-- Text = lang:GetText("白银卡库存："),
		},
		
		Gui.Label "silver_key_bg"
		{
			Size = Vector2(200, 40),
			Location = Vector2(491, 530),
			TextColor = ARGB(255,0, 0, 0),
			BackgroundColor = ARGB(0, 255, 255, 255),
			FontSize = 18,
			TextAlign = "kAlignLeftMiddle",
			Text = "",
		},
		
		Gui.Label "silver_key"
		{
			Size = Vector2(200, 40),
			Location = Vector2(490, 529),
			TextColor = ARGB(255,255, 244, 0),
			BackgroundColor = ARGB(0, 255, 255, 255),
			FontSize = 18,
			TextAlign = "kAlignLeftMiddle",
			Text = "",
		},
		
		Gui.Label
		{
			Size = Vector2(100, 40),
			Location = Vector2(580, 529),
			TextColor = ARGB(255,0, 0, 0),
			BackgroundColor = ARGB(0, 255, 255, 255),
			FontSize = 14,
			TextAlign = "kAlignCenterMiddle",
			-- Text = lang:GetText("黄金卡库存："),
		},
		
		Gui.Label "gold_key_bg"
		{
			Size = Vector2(200, 40),
			Location = Vector2(681, 530),
			TextColor = ARGB(255,0, 0, 0),
			BackgroundColor = ARGB(0, 255, 255, 255),
			FontSize = 18,
			TextAlign = "kAlignLeftMiddle",
			Text = "",
		},
		
		Gui.Label "gold_key"
		{
			Size = Vector2(200, 40),
			Location = Vector2(680, 529),
			TextColor = ARGB(255,255, 244, 0),
			BackgroundColor = ARGB(0, 255, 255, 255),
			FontSize = 18,
			TextAlign = "kAlignLeftMiddle",
			Text = "",
		},
		
		Gui.Button "time_sell_btn"
		{
			Size = Vector2(152, 37),
			Location = Vector2(906, 0),
			Text = lang:GetText("限时抢购"),
			FontSize = 16,
			PushDown = false,
			blink = true,
			--blinkwheelTimer = 0.6,
			-- blink_shade = false,
			TextColor = ARGB(255,238,221,190),
			HighlightTextColor = ARGB(255, 50 ,50 ,50),
			Padding = Vector4(0 ,4 ,0 ,0),
			Visible = false,
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/time_sell/lb_shop_button_snapup_normal.dds", Vector4(53, 0, 35, 0)),
				HoverImage = Gui.Image("LobbyUI/ShoppingMall/time_sell/lb_shop_button_snapup_hover.dds", Vector4(53, 0, 35, 0)),
				DownImage = Gui.Image("LobbyUI/ShoppingMall/time_sell/lb_shop_button_snapup_down.dds", Vector4(53, 0, 35, 0)),
				DisabledImage = Gui.Image("LobbyUI/ShoppingMall/time_sell/lb_shop_button_snapup_normal.dds", Vector4(53, 0, 35, 0)),
				TwinkleImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab01_light.dds", Vector4(11, 11, 11, 11)),
			},
			
			EventClick = function(Sender,e)
				L_TimeSell.show()	
			end
		},
			
		--Close Button
		Gui.Button "btn_Close"
		{
			Size = Vector2(64, 52),
			Location = Vector2(1058, 1),
			PushDown = false,
			Hint = lang:GetText("关闭彩盒并返回至战区"),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button01_normal.dds", Vector4(0, 0, 0, 0)),
				HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button01_hover.dds", Vector4(0, 0, 0, 0)),
				DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button01_down.dds", Vector4(0, 0, 0, 0)),
				DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button01_normal.dds", Vector4(0, 0, 0, 0)),
			},
		},
	}
}

view_present_window = nil
view_present_window_ui = Gui.Create()
{	
	Gui.Control "ctrl_view_present_window"
	{
		Size = Vector2(539+424,533),
		Dock = "kDockCenter",
		BackgroundColor = ARGB(255, 255, 255, 255),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/main_bar01.dds", Vector4(20, 20, 20, 20)),
		},
		
		Gui.Control
		{
			Size = Vector2(513+424,510),
			Location = Vector2(12,12),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/WarZone/Present/lb_gift_biew_bg1.dds", Vector4(200,104,105,48)),
			},
					
			Gui.Button "bt_view_present_prev"
			{
				Size = Vector2(177,31),
				Location = Vector2(40+212, 468),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Text = lang:GetText("上一页"),
				TextColor = ARGB(255, 229, 255, 252),
				TextAlign = "kAlignCenterMiddle",
				HighlightTextColor = ARGB(255, 229, 255, 252),

				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_normal.dds", Vector4(15, 0, 15, 0)),
					HoverImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_hover.dds", Vector4(15, 0, 15, 0)),
					DownImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_down.dds", Vector4(15, 0, 15, 0)),
					DisabledImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_disabled.dds", Vector4(15, 0, 15, 0)),
				},
				
				EventClick = function(Sender ,e)
					view_present_page = view_present_page - 1
					view_present_window_ui.bt_view_present_next.Visible = true
					local args = {level = view_present_index , pageNo = view_present_page}	
					rpc.safecallload("chest_list", args,
						function(data)
							rand_present = data.random
							total_page = data.pageCount - 1
							FillViewPresent(view_present_index,view_present_page)
						end)
					if view_present_page == 0 then
						Sender.Visible = false
					end
				end
			},
			
			Gui.Button "bt_view_present_next"
			{
				Size = Vector2(177,31),
				Location = Vector2(295+212, 468),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Text = lang:GetText("下一页"),
				TextColor = ARGB(255, 229, 255, 252),
				TextAlign = "kAlignCenterMiddle",
				HighlightTextColor = ARGB(255, 229, 255, 252),

				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_normal.dds", Vector4(15, 0, 15, 0)),
					HoverImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_hover.dds", Vector4(15, 0, 15, 0)),
					DownImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_down.dds", Vector4(15, 0, 15, 0)),
					DisabledImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_disabled.dds", Vector4(15, 0, 15, 0)),
				},
				
				EventClick = function(Sender ,e)
					view_present_page = view_present_page + 1
					view_present_window_ui.bt_view_present_prev.Visible = true
					local args = {level = view_present_index , pageNo = view_present_page}	
					rpc.safecallload("chest_list", args,
						function(data)
							rand_present = data.random
							total_page = data.pageCount - 1
							FillViewPresent(view_present_index,view_present_page)
						end)
					if view_present_page == total_page then
						Sender.Visible = false
					end
				end
			},
		},
	},
}

view_pintu_window = nil
view_pintu_window_ui = Gui.Create()
{	
	Gui.Control "ctrl_view_pintu_window"
	{
		Size = Vector2(539,533),
		Location = Vector2(200,225),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/main_bar01.dds", Vector4(20, 20, 20, 20)),
		},
		
		Gui.Control
		{
			Size = Vector2(513,510),
			Location = Vector2(12,12),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/WarZone/Present/lb_gift_biew_bg1.dds", Vector4(200,104,105,48)),
			},
					
			Gui.Button "bt_view_pintu_prev"
			{
				Size = Vector2(177,31),
				Location = Vector2(40, 468),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Text = lang:GetText("上一页"),
				TextColor = ARGB(255, 229, 255, 252),
				TextAlign = "kAlignCenterMiddle",
				HighlightTextColor = ARGB(255, 229, 255, 252),
				Visible = false,
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_normal.dds", Vector4(15, 0, 15, 0)),
					HoverImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_hover.dds", Vector4(15, 0, 15, 0)),
					DownImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_down.dds", Vector4(15, 0, 15, 0)),
					DisabledImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_disabled.dds", Vector4(15, 0, 15, 0)),
				},
				
				EventClick = function(Sender ,e)

				end
			},
			
			Gui.Button "bt_view_pintu_next"
			{
				Size = Vector2(177,31),
				Location = Vector2(295, 468),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Text = lang:GetText("下一页"),
				TextColor = ARGB(255, 229, 255, 252),
				TextAlign = "kAlignCenterMiddle",
				HighlightTextColor = ARGB(255, 229, 255, 252),
				Visible = false,
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_normal.dds", Vector4(15, 0, 15, 0)),
					HoverImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_hover.dds", Vector4(15, 0, 15, 0)),
					DownImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_down.dds", Vector4(15, 0, 15, 0)),
					DisabledImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_disabled.dds", Vector4(15, 0, 15, 0)),
				},
				
				EventClick = function(Sender ,e)

				end
			},
		},
	},
}

view_present_window_title_ui = Gui.Create()
{	
	Gui.Control "ctrl_view_present_window_title"
	{
		Size = Vector2(518,50),
		Location = Vector2(212+30, 229),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/WarZone/Present/lb_gift_biew_title.dds", Vector4(0,0,0,0)),
		},
	}
}

view_present_window_cancel_ui = Gui.Create()
{
	Gui.Button "btn_Close"
	{
		Size = Vector2(48, 48),
		Location = Vector2(700+424-182, 223),
		PushDown = false,
		Skin = Gui.ButtonSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_normal.dds", Vector4(0, 0, 0, 0)),
			HoverImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_hover.dds", Vector4(0, 0, 0, 0)),
			DownImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_down.dds", Vector4(0, 0, 0, 0)),
			DisabledImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_disabled.dds", Vector4(0, 0, 0, 0)),
		},
		
		EventClick = function()
			if view_present_window then
				view_present_window:Close()
			end	
			if view_pintu_window then
				view_pintu_window:Close()
			end	
		end
	},
}

buy_gift_window = nil

sunshine_window_ui = Gui.Create()
{
	Gui.AnimControl "ctrl_sunshine_window"
	{
		Size = Vector2(700,700),
		Location = Vector2(70,50),
		BackgroundColor = ARGB(0, 255, 255, 255),
	}
}

function CreatePresentBtn(list,line,index)
	return Gui.Button
	{
		Size = Vector2(74,74),
		Location = Vector2(74*list,74*line),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Skin = Gui.ButtonSkin
		{
			BackgroundImage = nil,
			HoverImage = nil,
			DownImage = nil,
			DisabledImage = Gui.Image("LobbyUI/WarZone/Present/ib_gift_blockbox_puzzle_"..index..".dds", Vector4(0, 0, 0, 0)),
		},
	
		EventClick = function(Sender,e)
			if not pintuchance then
				return
			end
			if not pintu_OK then
				return
			end
			MessageBox.ShowWithTwoButtons(lang:GetText("一副拼图只有一次任意选择的机会，\n你确定要使用吗？"),lang:GetText("确定"),lang:GetText("取消"),
						function()
							local args = {pid = ptr_cast(game.CurrentState):GetCharacterId(),index = index - 1}
							rpc.safecall("add_pintu", args,
							function(data)
								pintuchance = false
								Sender.Enable = false
								tigerMachine_window_ui.re_msg_1:CleanAll()
								tigerMachine_window_ui.re_msg_1:AddMsg(lang:GetText("这张拼图有 "),ARGB(255, 205, 129, 60),true,false)
								tigerMachine_window_ui.re_msg_1:AddMsg(lang:GetText("0"),ARGB(255, 255, 0, 0),false,false)
								tigerMachine_window_ui.re_msg_1:AddMsg(lang:GetText(" 次自由选择的机会"),ARGB(255, 205, 129, 60),false,false)
								IsAllPintu()
								if data.misticAward and data.misticAward.name ~= nil then
									pintu_all = true
									pintu_display = data.misticAward.display
									pintu_name = data.misticAward.name
									tigerMachine_window_ui.blink_all.Visible = true
									tigerMachine_window_ui.blink_all:Clear()
									tigerMachine_window_ui.blink_all.Normsize = Vector2(336,336)
									tigerMachine_window_ui.blink_all.NormLocation = Vector2(471,82)
									tigerMachine_window_ui.blink_all:InsertMovePoint(Vector2(471,82),0.0,Vector2(336, 336),ARGB(0,255,255,255))
									tigerMachine_window_ui.blink_all:InsertMovePoint(Vector2(471,82),1.0,Vector2(336, 336),ARGB(255,255,255,255))
									tigerMachine_window_ui.blink_all:InsertMovePoint(Vector2(471,82),2.0,Vector2(336, 336),ARGB(0,255,255,255))
								else
									pintu_all = false
									pintu_display = nil
									pintu_name = nil
								end
							end)
						end,
						nil
						)
		end,
	}
end

tigerMachine_window_ui = Gui.Create()
{
	Gui.Control "ctrl_tigerMachine_window_ui"
	{
		Size = Vector2(821,570),
		Location = Vector2(190,127),
		BackgroundColor = ARGB(0, 255, 255, 255),
		Gui.Control "c_tiger"
		{
			Size = Vector2(459,570),
			Location = Vector2(0,0),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/WarZone/Present/ib_gift_blockbox_bg_01.dds", Vector4(33, 33, 33, 33)),
			},
			Gui.Control
			{
				Size = Vector2(420,492),
				Location = Vector2(20,33),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/WarZone/Present/lotterybar.dds", Vector4(0, 0, 0, 0)),
				},
				
				Gui.Control "Title"
				{
					Size = Vector2(172,40),
					Location = Vector2(128,78),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/WarZone/Present/lotterybar_1.dds", Vector4(0, 0, 0, 0)),
					},
				},
				
				
				
				-- Gui.Label "tiger_title"
				-- {
					-- Size = Vector2(420,50),
					-- Location = Vector2(0,65),
					-- BackgroundColor = ARGB(0, 255, 255, 255),
					-- TextColor = ARGB(255,255, 192, 1),
					-- TextAlign = "kAlignCenterMiddle",
					-- FontSize = 18,
					-- Text = lang:GetText("要hold住!别鸡冻!"),
				-- },
				
				Gui.Label "tiger_present1"
				{
					Size = Vector2(150,50),
					Location = Vector2(70,270),
					BackgroundColor = ARGB(0, 255, 255, 255),
					TextColor = ARGB(255,255, 255, 255),
					TextAlign = "kAlignCenterMiddle",
					FontSize = 18,
					Text = "Minigun",
				},
				
				Gui.Label "tiger_present1_content"
				{
					Size = Vector2(174,105),
					Location = Vector2(23,284),
					BackgroundColor = ARGB(255, 255, 255, 255),
				},
				
				Gui.Label "tiger_present2"
				{
					Size = Vector2(370,25),
					Location = Vector2(25,262),
					BackgroundColor = ARGB(0, 255, 255, 255),
					TextColor = ARGB(255,250, 250, 250),
					TextAlign = "kAlignCenterMiddle",
					FontSize = 14,
					Text = lang:GetText("免费馈赠"),
				},
				
				Gui.ChangeControl "light"
				{
					Size = Vector2(0,0),
					Location = Vector2(201,293),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Normsize = Vector2(0,0),
					NormLocation = Vector2(201,293),
					NormBackgroundColor = ARGB(255,255,255,255),
					Visible = false,
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/WarZone/Present/ib_gift_blockbox_light.dds", Vector4(0, 0, 0, 0)),
					},
					EventPlayEnd = function(Sender,e)
						Sender.Visible = false
					end
				},
				
				Gui.ItemBoxBtn "tiger_present2_content"
				{
					Style = "Gui.ItemBoxBtn_ib",
					Size = Vector2(174,105),
					Location = Vector2(233,275),
					Visible = false,
					Skin = Gui.ItemBoxBtnSkin
					{
						NeutralNormalImage = nil,
						NeutralDisabledImage = nil,
					},
					
					EventMouseEnter = function(sender, e)
						if tigerMachine_window_ui.tiger_present2_content.ItemIcon ~= nil then
							L_ToolTips.FillToolBigPresentWindow(1, buy_gift_window.root, rpc_data)
						end
					end,
					
					EventToolTipsShow = function(sender, e)
						if tigerMachine_window_ui.tiger_present2_content.ItemIcon ~= nil then
							L_ToolTips.ShowToolTipsShowWindow(sender, Vector2(1200,800), sender.Location + sender.Parent.Location + sender.Parent.Parent.Location)
						end
					end,
					
					EventMouseLeave = function(sender, e)
						L_ToolTips.HideToolTipsWindow()
					end,
				},
				
				Gui.ChangeControl "tiger_present2_change"
				{
					Size = Vector2(10,10),
					Location = Vector2(233,275),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Normsize = Vector2(10,10),
					NormLocation = Vector2(233,275),
					NormBackgroundColor = ARGB(255,255,255,255),
					Visible = false,
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/WarZone/Present/ib_gift_blockbox_light.dds", Vector4(0, 0, 0, 0)),
					},
					EventPlayEnd = function(Sender,e)
						if pintu_id < 0 then
							if present_times > 1 then
								Five_Ten()
							else
								present_times = present_times - 1
								pintu_OK = true
								tigerMachine_window_ui.tiger_present_buy.Visible = true
								tigerMachine_window_ui.tiger_continue.Visible = true
								tigerMachine_window_ui.tiger_present_five.Visible = true
								tigerMachine_window_ui.tiger_present_ten.Visible = true
								tigerMachine_window_ui.pintu_num.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/WarZone/Present/ib_gift_blockbox_bg_03.dds", Vector4(0, 0, 0, 0)),}
								InitPintuHover("lb_tutorial_square01")
								ShowFiveTenPresentWin()
								IsAllPintu()
							end
						end
					end,
				},
				
				Gui.ItemBoxBtn "tiger_present2_content_num"
				{
					Style = "Gui.ItemBoxBtn_ib",
					Size = Vector2(154,105),
					Location = Vector2(233,275),
					Enable = false,
					Skin = Gui.ItemBoxBtnSkin
					{
						NeutralNormalImage = nil,
						NeutralDisabledImage = nil,
					},
				},
				
				-- Gui.Label "tiger_present2_content_number"
				-- {
					-- Size = Vector2(174,105),
					-- Location = Vector2(100000,314),
					-- BackgroundColor = ARGB(0, 255, 255, 255),
				-- },
				
				Gui.AnimControl "Tiger"
				{
					Size = Vector2(165,96),
					Location = Vector2(128,127),
					BackgroundColor = ARGB(0, 255, 255, 255),
					
					EventFinish = function(Sender ,e)
						local index = witch_level_present		
						local c_present = level_present[index]
						local random_present = rand_present
						local present_name
						local size,x,y
						tigerMachine_window_ui.tiger_present2_change:Clear()
						tigerMachine_window_ui.tiger_present2_content_num:OnDestroy()
						tigerMachine_window_ui.tiger_present2_change.Size = Vector2(92,92)
						tigerMachine_window_ui.tiger_present2_change.Normsize = Vector2(92,92)
						tigerMachine_window_ui.tiger_present2_change.Location = Vector2(245,262)
						tigerMachine_window_ui.tiger_present2_change.NormLocation = Vector2(245+25,262+25)
						tigerMachine_window_ui.tiger_present2_change.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/"..pitch_on_iamge..".tga", Vector4(0, 0, 0, 0)),}
						tigerMachine_window_ui.tiger_present2_change:InsertMovePoint(Vector2(245+25,262+25),0,Vector2(92, 92),ARGB(255,255,255,255))
						tigerMachine_window_ui.tiger_present2_change:InsertMovePoint(Vector2(245,262),0.10 - 0.03*0.2*(static_present_times-present_times),Vector2(142, 142),ARGB(255,255,255,255))
						tigerMachine_window_ui.tiger_present2_change:InsertMovePoint(Vector2(245+25,262+25),0.5-0.03*(static_present_times-present_times),Vector2(92, 92),ARGB(255,255,255,255))
						tigerMachine_window_ui.tiger_present2_change.Visible = true
						tigerMachine_window_ui.tiger_present2_change:SetSize_Picture_side()
						L_Characters.CreatPresentNumCtr(tigerMachine_window_ui.tiger_present2_content_num,pitch_on_present,154,105)
						 --Tooltips
						tigerMachine_window_ui.tiger_present2_change.EventMouseEnter = function(sender, e)
							L_ToolTips.FillToolBigPresentWindow(1, buy_gift_window.root, rpc_data)
						end
						tigerMachine_window_ui.tiger_present2_change.EventToolTipsShow = function(sender, e)
							L_ToolTips.ShowToolTipsShowWindow(sender,Vector2(1200, 800),sender.Location + sender.Parent.Location + sender.Parent.Parent.Location + sender.Parent.Parent.Parent.Location + Vector2(40,-30))
						end
						tigerMachine_window_ui.tiger_present2_change.EventMouseLeave = function(sender, e)
							L_ToolTips.HideToolTipsWindow()
						end
						
						-- tigerMachine_window_ui.tiger_present2_content.BackgroundColor = ARGB(0, 255, 255, 255)
						-- tigerMachine_window_ui.tiger_present2_content.ItemIcon = nil
						-- tigerMachine_window_ui.tiger_present2_content:OnDestroy()
						-- tigerMachine_window_ui.tiger_present2_content.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..pitch_on_iamge..".tga")
						-- L_Characters.CreatPresentNumCtr(tigerMachine_window_ui.tiger_present2_content,pitch_on_present,164,95)
						sunshine_window_ui.ctrl_sunshine_window:StartAnimation()
						
						if random_data.onlineAward.name ~= nil then
							ShowPrsentprizeWin(random_data,1)
						end
						ShowFlyMove()
					end
				},
				
				Gui.Label "tiger_present_descption"
				{
					Size = Vector2(380,25),
					Location = Vector2(20,385),
					BackgroundColor = ARGB(0, 250, 250, 250),
					TextColor = ARGB(255,255, 255, 255),
					TextAlign = "kAlignCenterMiddle",
					FontSize = 14,
					Text = lang:GetText("馈赠物品将自动放入仓库"),
				},
				
				Gui.Button "tiger_present_buy"
				{
					Size = Vector2(134,32),
					Location = Vector2(275, 450),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Text = lang:GetText("关闭窗口"),
					TextColor = ARGB(255, 37, 37, 37),
					HighlightTextColor = ARGB(255, 37, 37, 37),
					TextAlign = "kAlignCenterMiddle",
					-- Visible = false,
					
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/Mission/lb_task_button01_normal.dds", Vector4(20, 5, 20, 5)),
						HoverImage = Gui.Image("LobbyUI/Mission/lb_task_button01_hover.dds", Vector4(20, 5, 20, 5)),
						DownImage = Gui.Image("LobbyUI/Mission/lb_task_button01_down.dds", Vector4(20, 5, 20, 5)),
						DisabledImage = Gui.Image("LobbyUI/Mission/lb_task_button01_disabled.dds", Vector4(20, 5, 20, 5)),	
					},
					
					EventClick = function(Sender ,e)				
						buy_gift_window:Close()
						tigerMachine_window_ui.Tiger:ClearAll()
						tigerMachine_window_ui.tiger_present2_content.BackgroundColor = ARGB(0, 255, 255, 255)
						tigerMachine_window_ui.Tiger:StopAnimation()
						main_present_window_ui.Timer:StartAnimation()
						sunshine_window_ui.ctrl_sunshine_window:StopAnimation()
						-- Sender.Visible = false
						-- tigerMachine_window_ui.tiger_continue.Visible = false
						tigerMachine_window_ui.tiger_present2_content.ItemIcon = nil
						tigerMachine_window_ui.pintu_num.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/WarZone/Present/ib_gift_blockbox_bg_03_disabled.dds", Vector4(0, 0, 0, 0)),}
						InitPintuHover("")
					end,
				},
				
				Gui.Button "tiger_present_five"
				{
					Size = Vector2(134,32),
					Location = Vector2(15, 450),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Text = lang:GetText("连抽5次"),
					TextColor = ARGB(255, 37, 37, 37),
					HighlightTextColor = ARGB(255, 37, 37, 37),
					TextAlign = "kAlignCenterMiddle",
					-- Visible = false,
					
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/Mission/lb_task_button01_normal.dds", Vector4(20, 5, 20, 5)),
						HoverImage = Gui.Image("LobbyUI/Mission/lb_task_button01_hover.dds", Vector4(20, 5, 20, 5)),
						DownImage = Gui.Image("LobbyUI/Mission/lb_task_button01_down.dds", Vector4(20, 5, 20, 5)),
						DisabledImage = Gui.Image("LobbyUI/Mission/lb_task_button01_disabled.dds", Vector4(20, 5, 20, 5)),	
					},
					
					EventClick = function(Sender ,e)
						tigerMachine_window_ui.tiger_present2_change.Visible = false
						tigerMachine_window_ui.tiger_present2_content_num:OnDestroy()
						present_times = 5
						static_present_times = 5
						GetPresent(present_times)						
					end,
				},
				
				Gui.Button "tiger_present_ten"
				{
					Size = Vector2(134,32),
					Location = Vector2(145, 450),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Text = lang:GetText("连抽10次"),
					TextColor = ARGB(255, 37, 37, 37),
					HighlightTextColor = ARGB(255, 37, 37, 37),
					TextAlign = "kAlignCenterMiddle",
					-- Visible = false,
					
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/Mission/lb_task_button01_normal.dds", Vector4(20, 5, 20, 5)),
						HoverImage = Gui.Image("LobbyUI/Mission/lb_task_button01_hover.dds", Vector4(20, 5, 20, 5)),
						DownImage = Gui.Image("LobbyUI/Mission/lb_task_button01_down.dds", Vector4(20, 5, 20, 5)),
						DisabledImage = Gui.Image("LobbyUI/Mission/lb_task_button01_disabled.dds", Vector4(20, 5, 20, 5)),	
					},
					
					EventClick = function(Sender ,e)
						tigerMachine_window_ui.tiger_present2_change.Visible = false
						tigerMachine_window_ui.tiger_present2_content_num:OnDestroy()
						present_times = 10
						static_present_times = 10
						GetPresent(present_times)					
					end,
				},
				
				Gui.Button "tiger_continue"
				{
					Size = Vector2(134,32),
					Location = Vector2(145, 410),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Text = lang:GetText("开始"),
					TextColor = ARGB(255, 37, 37, 37),
					HighlightTextColor = ARGB(255, 37, 37, 37),
					TextAlign = "kAlignCenterMiddle",
					-- Visible = false,
					
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/Mission/lb_task_button01_normal.dds", Vector4(20, 5, 20, 5)),
						HoverImage = Gui.Image("LobbyUI/Mission/lb_task_button01_hover.dds", Vector4(20, 5, 20, 5)),
						DownImage = Gui.Image("LobbyUI/Mission/lb_task_button01_down.dds", Vector4(20, 5, 20, 5)),
						DisabledImage = Gui.Image("LobbyUI/Mission/lb_task_button01_disabled.dds", Vector4(20, 5, 20, 5)),	
					},
					
					EventClick = function(Sender ,e)
						tigerMachine_window_ui.tiger_present2_change.Visible = false	
						tigerMachine_window_ui.tiger_present2_content_num:OnDestroy()						
						present_times = 1
						static_present_times = 1
						GetPresent(present_times)	
					end,
				},
			},
			Gui.Label
			{
				Size = Vector2(459,20),
				Location = Vector2(0,530),
				BackgroundColor = ARGB(0, 255, 255, 255),
				TextColor = ARGB(255, 205, 129, 60),
				FontSize = 16,
				TextAlign = "kAlignCenterMiddle",
				Text = lang:GetText("神秘拼图可在黄金彩盒中获得"),
			},
		},
		Gui.Control "c_pintu"
		{
			Size = Vector2(365,570),
			Location = Vector2(459,0),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/WarZone/Present/ib_gift_blockbox_bg_01.dds", Vector4(33, 33, 33, 33)),
			},
			Gui.Control
			{
				Size = Vector2(337,549),
				Location = Vector2(14,12),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/WarZone/Present/ib_gift_blockbox_bg_02.dds", Vector4(0, 0, 0, 0)),
				},
				Gui.Label
				{
					Size = Vector2(337,33),
					Location = Vector2(0,3),
					BackgroundColor = ARGB(0, 255, 255, 255),
					TextColor = ARGB(255, 255, 204, 0),
					FontSize = 18,
					TextAlign = "kAlignCenterMiddle",
					Text = lang:GetText("神秘拼图"),
				},
				Gui.RichEdit "re_msg_1"
				{
					Size = Vector2(337,40),
					Location = Vector2(45,60),
					BackgroundColor = ARGB(0, 255, 255, 255),
					TextColor = ARGB(255, 205, 129, 60),
					FontSize = 14,
					-- TextAlign = "kAlignCenterMiddle",
					Text = lang:GetText("这张拼图有1次自由选择的机会"),
				},
				Gui.Control "pintu_num"
				{
					Size = Vector2(296,296),
					Location = Vector2(21,90),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						-- BackgroundImage = Gui.Image("LobbyUI/WarZone/Present/ib_gift_blockbox_bg_03.dds", Vector4(0, 0, 0, 0)),
						BackgroundImage = Gui.Image("LobbyUI/WarZone/Present/ib_gift_blockbox_bg_03_disabled.dds", Vector4(0, 0, 0, 0)),
					},
					CreatePresentBtn(0,0,1),
					CreatePresentBtn(1,0,2),
					CreatePresentBtn(2,0,3),
					CreatePresentBtn(3,0,4),
					
					CreatePresentBtn(0,1,5),
					CreatePresentBtn(1,1,6),
					CreatePresentBtn(2,1,7),
					CreatePresentBtn(3,1,8),
					
					CreatePresentBtn(0,2,9),
					CreatePresentBtn(1,2,10),
					CreatePresentBtn(2,2,11),
					CreatePresentBtn(3,2,12),
					
					CreatePresentBtn(0,3,13),
					CreatePresentBtn(1,3,14),
					CreatePresentBtn(2,3,15),
					CreatePresentBtn(3,3,16),
				},
				Gui.Label
				{
					Size = Vector2(337,40),
					Location = Vector2(1,389),
					BackgroundColor = ARGB(0, 255, 255, 255),
					TextColor = ARGB(255, 254, 162, 27),
					FontSize = 18,
					TextAlign = "kAlignCenterMiddle",
					Text = lang:GetText("奖励"),
				},
				Gui.Label
				{
					Size = Vector2(337,40),
					Location = Vector2(0,388),
					BackgroundColor = ARGB(0, 255, 255, 255),
					TextColor = ARGB(255, 0, 0, 0),
					FontSize = 18,
					TextAlign = "kAlignCenterMiddle",
					Text = lang:GetText("奖励"),
				},

				-- Gui.Control "pintu_present"
				-- {
					-- Size = Vector2(156,68),
					-- Location = Vector2(85,437),
					-- BackgroundColor = ARGB(255, 255, 255, 255),
					-- Skin = Gui.ControlSkin
					-- {
						-- BackgroundImage = Gui.Image("LobbyUI/WarZone/Present/ib_gift_blockbox_ico_01.dds", Vector4(0, 0, 0, 0)),
					-- },
				-- },
				-- Gui.Control
				-- {
					-- Size = Vector2(32,28),
					-- Location = Vector2(286,435),
					-- BackgroundColor = ARGB(255, 255, 255, 255),
					-- Skin = Gui.ControlSkin
					-- {
						-- BackgroundImage = Gui.Image("LobbyUI/lb_shop_treasureico_xy.dds", Vector4(0, 0, 0, 0)),
					-- },
				-- },
				Gui.Button
				{
					Size = Vector2(44, 44),
					Location = Vector2(280, 460),
					BackgroundColor = ARGB(255,255,255,255),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/WarZone/Present/ib_gift_blockbox_button_check_normal.dds", Vector4(0, 0, 0, 0)),
						HoverImage = Gui.Image("LobbyUI/WarZone/Present/ib_gift_blockbox_button_check_hover.dds", Vector4(0, 0, 0, 0)),
						DownImage = Gui.Image("LobbyUI/WarZone/Present/ib_gift_blockbox_button_check_down.dds", Vector4(0, 0, 0, 0)),
						DisabledImage = Gui.Image("LobbyUI/WarZone/Present/ib_gift_blockbox_button_check_normal.dds", Vector4(0, 0, 0, 0)),	
					},					
					EventClick = function()
						GetRare_Present(1,0,true)
					end,
				},
				Gui.Button "look_award"
				{
					Size = Vector2(225, 34),
					Location = Vector2(60, 508),
					Text = lang:GetText("领取奖励"),
					BackgroundColor = ARGB(255,255,255,255),
					TextAlign = "kAlignCenterMiddle",
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/Mission/lb_task_button01_normal.dds", Vector4(20, 5, 20, 5)),
						HoverImage = Gui.Image("LobbyUI/Mission/lb_task_button01_hover.dds", Vector4(20, 5, 20, 5)),
						DownImage = Gui.Image("LobbyUI/Mission/lb_task_button01_down.dds", Vector4(20, 5, 20, 5)),
						DisabledImage = Gui.Image("LobbyUI/Mission/lb_task_button01_disabled.dds", Vector4(20, 5, 20, 5)),	
					},
					TextColor = ARGB(255, 37, 37, 37),
					HighlightTextColor = ARGB(255, 37, 37, 37),
					EventClick = function()
						ShowRare_List_Win()
					end
				},
			},
		},
	
		Gui.ChangeControl "fly"
		{
			Size = Vector2(48,48),
			Location = Vector2(233,338),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Normsize = Vector2(0,0),
			NormLocation = Vector2(233,338),
			NormBackgroundColor = ARGB(255,255,255,255),
			Visible = false,
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/WarZone/Present/ib_gift_blockbox_ico_02.dds", Vector4(0, 0, 0, 0)),
			},
			EventPlayEnd = function(Sender,e)
				Sender.Visible = false
				tigerMachine_window_ui.blink.Visible = true
				tigerMachine_window_ui.blink:Clear()
				tigerMachine_window_ui.blink.Normsize = Vector2(94,94)
				tigerMachine_window_ui.blink.NormLocation = Vector2(236+248+(pintu_id%4)*74,328-236+math.floor(pintu_id/4)*74)
				tigerMachine_window_ui.blink:InsertMovePoint(Vector2(236+248+(pintu_id%4)*74,328-236+math.floor(pintu_id/4)*74),0.5,Vector2(94, 94),ARGB(0,255,255,255))
				tigerMachine_window_ui.blink:InsertMovePoint(Vector2(236+248+(pintu_id%4)*74,328-236+math.floor(pintu_id/4)*74),1.0,Vector2(94, 94),ARGB(255,255,255,255))
				gui:PlayAudio("kUIA_PUZZLE_MATCH")
				-- tigerMachine_window_ui.blink:InsertMovePoint(Vector2(233+248+(pintu_id%4)*74,328-236+math.floor(pintu_id/4)*74),1.5,Vector2(94, 94),ARGB(0,255,255,255))
				-- tigerMachine_window_ui.blink:InsertMovePoint(Vector2(233+248+(pintu_id%4)*74,328-236+math.floor(pintu_id/4)*74),2.0,Vector2(94, 94),ARGB(255,255,255,255))
			end
		},
		
		Gui.ChangeControl "blink"
		{
			Size = Vector2(74,74),
			Location = Vector2(233,338),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Normsize = Vector2(74,74),
			NormLocation = Vector2(233,338),
			NormBackgroundColor = ARGB(255,255,255,255),
			Visible = false,
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/WarZone/Present/ib_gift_blockbox_light.dds", Vector4(0, 0, 0, 0)),
			},
			EventPlayEnd = function(Sender,e)
				Sender.Visible = false
				tigerMachine_window_ui.blink1.Visible = true
				tigerMachine_window_ui.blink1:Clear()
				tigerMachine_window_ui.blink1.Normsize = Vector2(74,74)
				tigerMachine_window_ui.blink1.NormLocation = Vector2(236+258+(pintu_id%4)*74,338-236+math.floor(pintu_id/4)*74)
				local index = pintu_id+1
				tigerMachine_window_ui.blink1.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/WarZone/Present/ib_gift_blockbox_puzzle_"..index..".dds", Vector4(0, 0, 0, 0)),}
				tigerMachine_window_ui.blink1:InsertMovePoint(Vector2(236+258+(pintu_id%4)*74,338-236+math.floor(pintu_id/4)*74),0.0,Vector2(74, 74),ARGB(0,255,255,255))
				tigerMachine_window_ui.blink1:InsertMovePoint(Vector2(236+258+(pintu_id%4)*74,338-236+math.floor(pintu_id/4)*74),0.5,Vector2(74, 74),ARGB(255,255,255,255))
			end
		},
		
		Gui.ChangeControl "blink1"
		{
			Size = Vector2(74,74),
			Location = Vector2(233,338),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Normsize = Vector2(74,74),
			NormLocation = Vector2(233,338),
			NormBackgroundColor = ARGB(255,255,255,255),
			Visible = false,
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/WarZone/Present/ib_gift_blockbox_puzzle_1.dds", Vector4(0, 0, 0, 0)),
			},
			EventPlayEnd = function(Sender,e)
				Sender.Visible = false
				print("pintu_id:"..pintu_id)
				if pintu_id < 0 then
					return
				end
				local ibbtn = tigerMachine_window_ui.pintu_num:GetChildByIndex(pintu_id)
				ibbtn.Enable = false
				if pintu_all then
					tigerMachine_window_ui.blink_all.Visible = true
					tigerMachine_window_ui.blink_all:Clear()
					tigerMachine_window_ui.blink_all.Normsize = Vector2(336,336)
					tigerMachine_window_ui.blink_all.NormLocation = Vector2(474,82)
					tigerMachine_window_ui.blink_all:InsertMovePoint(Vector2(474,82),0.0,Vector2(336, 336),ARGB(0,255,255,255))
					tigerMachine_window_ui.blink_all:InsertMovePoint(Vector2(474,82),1.0,Vector2(336, 336),ARGB(255,255,255,255))
					tigerMachine_window_ui.blink_all:InsertMovePoint(Vector2(474,82),2.0,Vector2(336, 336),ARGB(0,255,255,255))
					gui:PlayAudio("kUIA_PUZZLE_COMPLETE")
				end
				
				if present_times > 1 then
					Five_Ten()
				else
					pintu_id = -1
					pintu_OK = true
					tigerMachine_window_ui.tiger_present_buy.Visible = true
					tigerMachine_window_ui.tiger_continue.Visible = true
					tigerMachine_window_ui.tiger_present_five.Visible = true
					tigerMachine_window_ui.tiger_present_ten.Visible = true
					tigerMachine_window_ui.pintu_num.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/WarZone/Present/ib_gift_blockbox_bg_03.dds", Vector4(0, 0, 0, 0)),}
					InitPintuHover("lb_tutorial_square01")
					ShowFiveTenPresentWin()
					IsAllPintu()
				end
			end
		},
		Gui.ChangeControl "blink_all"
		{
			Size = Vector2(336,336),
			Location = Vector2(471,82),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Normsize = Vector2(336,336),
			NormLocation = Vector2(471,82),
			NormBackgroundColor = ARGB(255,255,255,255),
			Visible = false,
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/WarZone/Present/ib_gift_blockbox_light.dds", Vector4(34, 34, 34, 34)),
			},
			EventPlayEnd = function(Sender,e)
				Sender.Visible = false
				-- tigerMachine_window_ui.pintu_present.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/"..pintu_name..".tga", Vector4(0, 0, 0, 0)),}
				-- MessageBox.ShowWithConfirm(lang:GetText("恭喜你通过拼图获得了\n“"..pintu_display.."”"),
				-- function()
					-- InitPintu()
				-- end
				-- )
			end
		},
	},
}

function Logic()
	if main_present_window_ui then
	
		main_present_window_ui.btn_Close.EventClick = function()
			L_LobbyMain.LobbyMainWin_Foot.btn_WarZone.PushDown = true
			L_WarZone.Show(root_ui)
		end
	end
end

function GetPresent(i)
	buy_gift_window:Close()
	tigerMachine_window_ui.Tiger:ClearAll()
	tigerMachine_window_ui.tiger_present2_content.BackgroundColor = ARGB(0, 255, 255, 255)
	tigerMachine_window_ui.Tiger:StopAnimation()
	main_present_window_ui.Timer:StartAnimation()
	sunshine_window_ui.ctrl_sunshine_window:StopAnimation()	
	tigerMachine_window_ui.tiger_present2_content.ItemIcon = nil
	tigerMachine_window_ui.pintu_num.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/WarZone/Present/ib_gift_blockbox_bg_03_disabled.dds", Vector4(0, 0, 0, 0)),}
	InitPintuHover("")
	local index = present_index
	local my_keynum = 0
	for i = 1, 3 do
		if index == g_data.fix[i].level then
			index = i
			break
		end
	end		
	if present_index == 1 then
		my_keynum = Cooper
	elseif present_index == 2 then
		my_keynum = Silver
	elseif present_index == 3 then
		my_keynum = Gold
	end				
	if is_cmoney then
	print("my_keynum"..my_keynum)
	print("g_data.fix[index].payFC"..g_data.fix[index].payFC)
		if my_keynum >= i*g_data.fix[index].payFC then				
				-- MessageBox.ShowWithTwoButtons(lang:GetText("您确定要使用")..g_data.fix[index].payFC..lang:GetText("个")..key_name(index).."？",lang:GetText("确认"),lang:GetText("取消"),
				-- function() 
					tigerMachine_window_ui.tiger_present_buy.Visible = false
					tigerMachine_window_ui.tiger_continue.Visible = false
					tigerMachine_window_ui.tiger_present_five.Visible = false
					tigerMachine_window_ui.tiger_present_ten.Visible = false
					FillbuyPresent(index,1)
					witch_level_present = index
					main_present_window_ui.Timer:StopAnimation()
					-- gui:PlayAudio("kUIA_LAOHUJI")
				-- end,
				-- function() 
					-- return
				-- end
			-- )
		else
			MessageBox.ShowWithTwoButtons(lang:GetText("您的")..key_name(index)..lang:GetText("不足，请购买"),lang:GetText("购买"),lang:GetText("取消"),
				function() 
					-- gui:ShowIE()
					ShowRapidShoppingWin()
				end,
				function() 
					return
				end
				)
		end
	elseif is_chip then
		if Chip >= i*g_data.fix[index].payChip then
			MessageBox.ShowWithTwoButtons(lang:GetText("您确定要花费")..i*g_data.fix[index].payChip..lang:GetText("个勋章？"),lang:GetText("确认"),lang:GetText("取消"),
				function() 
					tigerMachine_window_ui.tiger_present_buy.Visible = false
					tigerMachine_window_ui.tiger_continue.Visible = false
					tigerMachine_window_ui.tiger_present_five.Visible = false
					tigerMachine_window_ui.tiger_present_ten.Visible = false
					FillbuyPresent(index,2)
					witch_level_present = index
					main_present_window_ui.Timer:StopAnimation()
					-- gui:PlayAudio("kUIA_LAOHUJI")
				end,
				function() 
					return
				end
			)
		else
			MessageBox.ShowWithTimer(3,lang:GetText("您的勋章不足"))
		end
	end
end

function SpawnNewIcon(i)
	local row,col = 0,0
	
	local HeadCon = Gui.Create(gui) {
					Gui.ItemBoxBtn "CHead"
					{
						Style = "Gui.ItemBoxBtn_ib",
						Size = Vector2(100,100),
						BackgroundColor = ARGB(255, 255, 255, 255),
						-- Skin = Gui.ControlSkin
						-- {
							-- BackgroundImage = Gui.Image("LobbyUI/WarZone/Present/lb_gift_biew_bg2.dds", Vector4(0, 0, 0, 0)),
						-- },
						
						Skin = Gui.ItemBoxBtnSkin
						{
							NeutralNormalImage = Gui.Image("LobbyUI/WarZone/Present/lb_gift_biew_bg2.dds", Vector4(0, 0, 0, 0)),
							--NeutralHoverImage = Gui.Image("LobbyUI/ShoppingMall/vip_chest/lb_vipgifts_slot_flash.dds", Vector4(0, 0, 0, 0)),
							NeutralSelectedImage = Gui.Image("LobbyUI/WarZone/Present/lb_gift_biew_bg2.dds", Vector4(0, 0, 0, 0)),
							NeutralDisabledImage = Gui.Image("LobbyUI/WarZone/Present/lb_gift_biew_bg2.dds", Vector4(0, 0, 0, 0)),
						},
						
						-- Gui.Label "Content"
						-- {
							-- Size = Vector2(100,100),
							-- BackgroundColor = ARGB(0, 255, 255, 255),
						-- },
						
						Gui.Label "quantity"
						{
							Size = Vector2(100,100),
							Location = Vector2(0,0),
							BackgroundColor = ARGB(0, 255, 255, 255),
						},
						
						EventMouseEnter = function(sender, e)
							L_ToolTips.FillToolBigPresentWindow(i, view_present_window.root, rand_present)
						end,
						EventToolTipsShow = function(sender, e)
							if rand_present[i] ~= nil then
								L_ToolTips.ShowToolTipsShowWindow(sender,Vector2(1000, 1000),sender.Location + sender.Parent.Location)
							end
						end,
						EventMouseLeave = function(sender, e)
							L_ToolTips.HideToolTipsWindow()
						end,
					}
				}
	
	col = i / 8
	col = math.floor(col)
	if i % 8 == 0 then
		col = col - 1
	end
	
	row = i - col * 8
	HeadCon.CHead.IntTag = i
	HeadCon.CHead.Location = Vector2((row-1)*106+61,col*106 +53)
	
	return HeadCon;
end

function SpawnNewPintuIcon(i)
	local row,col = 0,0
	
	local HeadCon = Gui.Create(gui) {
					Gui.ItemBoxBtn "CHead"
					{
						Style = "Gui.ItemBoxBtn_ib",
						Size = Vector2(100,100),
						BackgroundColor = ARGB(255, 255, 255, 255),
						-- Skin = Gui.ControlSkin
						-- {
							-- BackgroundImage = Gui.Image("LobbyUI/WarZone/Present/lb_gift_biew_bg2.dds", Vector4(0, 0, 0, 0)),
						-- },
						
						Skin = Gui.ItemBoxBtnSkin
						{
							NeutralNormalImage = Gui.Image("LobbyUI/WarZone/Present/lb_gift_biew_bg2.dds", Vector4(0, 0, 0, 0)),
							--NeutralHoverImage = Gui.Image("LobbyUI/ShoppingMall/vip_chest/lb_vipgifts_slot_flash.dds", Vector4(0, 0, 0, 0)),
							NeutralSelectedImage = Gui.Image("LobbyUI/WarZone/Present/lb_gift_biew_bg2.dds", Vector4(0, 0, 0, 0)),
							NeutralDisabledImage = Gui.Image("LobbyUI/WarZone/Present/lb_gift_biew_bg2.dds", Vector4(0, 0, 0, 0)),
						},
						
						-- Gui.Label "Content"
						-- {
							-- Size = Vector2(100,100),
							-- BackgroundColor = ARGB(0, 255, 255, 255),
						-- },
						
						Gui.Label "quantity"
						{
							Size = Vector2(100,100),
							Location = Vector2(0,0),
							BackgroundColor = ARGB(0, 255, 255, 255),
						},
						
						EventMouseEnter = function(sender, e)
							L_ToolTips.FillToolBigPresentWindow(i, view_pintu_window.root, rand_present)
						end,
						EventToolTipsShow = function(sender, e)
							if rand_present[i] ~= nil then
								L_ToolTips.ShowToolTipsShowWindow(sender,Vector2(1000, 1000),sender.Location + sender.Parent.Location)
							end
						end,
						EventMouseLeave = function(sender, e)
							L_ToolTips.HideToolTipsWindow()
						end,
					}
				}
	
	col = i / 4
	col = math.floor(col)
	if i % 4 == 0 then
		col = col - 1
	end
	
	row = i - col * 4
	HeadCon.CHead.IntTag = i
	HeadCon.CHead.Location = Vector2((row-1)*106+65,col*106 +53)
	
	return HeadCon;
end

function FillViewPage(index,page)
	local c_present = level_present[index]
	local random_present = rand_present
	local rand_size = #random_present
	local row,col = 0,0
	local present_name
	local x,y = 0,0
	print("rand_size = "..rand_size)
	for i = 1, 32 do
		local Icon = view_present[i]
		Icon.CHead.ItemLevel = nil
		if random_present[i] then
			-- Icon.Content.BackgroundColor = ARGB(255, 255, 255, 255)
			if random_present[i].color == 0 then
				present_name = random_present[i].name
			else
				present_name = random_present[i].name.."_"..random_present[i].color
			end
			if random_present[i].common and random_present[i].common.rareLevel then
				Icon.CHead.ItemLevel = Skin.rarelevel[math.ceil(random_present[i].common.rareLevel/25)]
			end
			local view_present = Gui.Image("LobbyUI/ibt_icon/"..present_name..".tga", Vector4(0, 0, 0, 0))
			x ,y = GetProperRect(view_present.Size,Vector2(100,100))
			-- Icon.Content.Size = Vector2(x,y)
			-- Icon.Content.Location = Vector2((100 - x)/2, (100 - y )/2)
			-- Icon.Content.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/"..present_name..".tga", Vector4(0, 0, 0, 0)),}
			Icon.CHead.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..present_name..".tga")
			if random_present[i].type >= 5 then
				FillNumber(Icon.quantity,random_present[i].quantity,95,93)
			else
				FillNumber(Icon.quantity,1,95,93)
			end
			
		else
			Icon.CHead.ItemIcon = nil
		end
	end
end

function FillViewPintuPage(page)
	local c_present = level_present[index]
	local random_present = rand_present
	local rand_size = #random_present
	local row,col = 0,0
	local present_name
	local x,y = 0,0
	print("rand_size = "..rand_size)
	for i = 1, 16 do
		local Icon = view_pintu[i]
		Icon.CHead.ItemLevel = nil
		if random_present[i] then
			-- Icon.Content.BackgroundColor = ARGB(255, 255, 255, 255)		
			present_name = random_present[i].name
			if random_present[i].common and random_present[i].common.rareLevel then
				Icon.CHead.ItemLevel = Skin.rarelevel[math.ceil(random_present[i].common.rareLevel/25)]
			end
			local view_pintu = Gui.Image("LobbyUI/ibt_icon/"..present_name..".tga", Vector4(0, 0, 0, 0))
			x ,y = GetProperRect(view_pintu.Size,Vector2(100,100))
			-- Icon.Content.Size = Vector2(x,y)
			-- Icon.Content.Location = Vector2((100 - x)/2, (100 - y )/2)
			-- Icon.Content.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/"..present_name..".tga", Vector4(0, 0, 0, 0)),}
			Icon.CHead.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..present_name..".tga")
			-- if random_present[i].type >= 5 then
				-- FillNumber(Icon.quantity,random_present[i].quantity,95,93)
			-- else
				FillNumber(Icon.quantity,1,95,93)
			-- end
			
		else
			Icon.CHead.ItemIcon = nil
		end
	end
end

function FillViewPresent(index,page)
	local c_present = level_present[index]
	local random_present = rand_present
	local rand_size = #random_present
	local row,col = 0,0
	local present_name
	local x,y = 0,0
	local name
	if index == 1 then
		name = "cooper"
	elseif index ==2 then
		name = "silver"
	elseif index == 3 then
		name = "gold"
	end
	for i = 1,32 do
		local Icon = view_present[i]
		Icon.CHead.ItemLevel = nil
		-- Icon.Content.BackgroundColor = ARGB(0, 255, 255, 255)
		Icon.CHead.Skin = Gui.ItemBoxBtnSkin
		{
			NeutralNormalImage = Gui.Image("LobbyUI/WarZone/Present/shop_gift_"..name.."_table.dds", Vector4(0, 0, 0, 0)),
			-- NeutralHoverImage = Gui.Image("LobbyUI/ShoppingMall/vip_chest/lb_vipgifts_slot_flash.dds", Vector4(0, 0, 0, 0)),
			NeutralSelectedImage = Gui.Image("LobbyUI/WarZone/Present/shop_gift_"..name.."_table.dds", Vector4(0, 0, 0, 0)),
			NeutralDisabledImage = Gui.Image("LobbyUI/WarZone/Present/shop_gift_"..name.."_table.dds", Vector4(0, 0, 0, 0)),
		},
		Icon.quantity:OnDestroy()
	end
	view_present_index = index
	FillViewPage(index,page)
end

function FillViewpintu(page)
	-- local c_present = level_present[index]
	-- local random_present = rand_present
	-- local rand_size = #random_present
	-- local row,col = 0,0
	-- local present_name
	-- local x,y = 0,0
	-- local name
	for i = 1,16 do
		local Icon = view_pintu[i]
		Icon.CHead.ItemLevel = nil
		-- Icon.Content.BackgroundColor = ARGB(0, 255, 255, 255)
		Icon.CHead.Skin = Gui.ItemBoxBtnSkin
		{
			NeutralNormalImage = Gui.Image("LobbyUI/WarZone/Present/shop_gift_gold_table.dds", Vector4(0, 0, 0, 0)),
			-- NeutralHoverImage = Gui.Image("LobbyUI/ShoppingMall/vip_chest/lb_vipgifts_slot_flash.dds", Vector4(0, 0, 0, 0)),
			NeutralSelectedImage = Gui.Image("LobbyUI/WarZone/Present/shop_gift_gold_table.dds", Vector4(0, 0, 0, 0)),
			NeutralDisabledImage = Gui.Image("LobbyUI/WarZone/Present/shop_gift_gold_table.dds", Vector4(0, 0, 0, 0)),
		},
		Icon.quantity:OnDestroy()
	end
	-- view_present_index = index
	FillViewPintuPage(page)
end

function ShowFlyMove()
	if pintu_id < 0 then
		-- if present_times > 1 then
			-- Five_Ten()
		-- else
			-- present_times = present_times - 1
			-- pintu_OK = true
			-- tigerMachine_window_ui.tiger_present_buy.Visible = true
			-- tigerMachine_window_ui.tiger_continue.Visible = true
			-- tigerMachine_window_ui.tiger_present_five.Visible = true
			-- tigerMachine_window_ui.tiger_present_ten.Visible = true
			-- tigerMachine_window_ui.pintu_num.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/WarZone/Present/ib_gift_blockbox_bg_03.dds", Vector4(0, 0, 0, 0)),}
			-- InitPintuHover("lb_tutorial_square01")
			-- ShowFiveTenPresentWin()
			-- IsAllPintu()
		-- end
		return
	end
	tigerMachine_window_ui.fly:Clear()
	tigerMachine_window_ui.fly.Location = Vector2(233+24,318+24)
	tigerMachine_window_ui.fly.Size = Vector2(0,0)
	tigerMachine_window_ui.fly.NormLocation = Vector2(233+24,318+24)
	tigerMachine_window_ui.fly:InsertMovePoint(Vector2(233+24,318+24),0,Vector2(0, 0),ARGB(255,255,255,255))
	-- tigerMachine_window_ui.fly:InsertMovePoint(Vector2(233+18,318+18),0.3,Vector2(12, 12),ARGB(255,255,255,255))
	-- tigerMachine_window_ui.fly:InsertMovePoint(Vector2(233+12,318+12),0.6,Vector2(24, 24),ARGB(255,255,255,255))
	-- tigerMachine_window_ui.fly:InsertMovePoint(Vector2(233+6,318+6),0.9,Vector2(36, 36),ARGB(255,255,255,255))
	tigerMachine_window_ui.fly:InsertMovePoint(Vector2(233,318),0.2,Vector2(48, 48),ARGB(255,255,255,255))
	tigerMachine_window_ui.fly:InsertMovePoint(Vector2(233,318),0.3,Vector2(48, 48),ARGB(255,255,255,255))
	tigerMachine_window_ui.fly:InsertMovePoint(Vector2(233+258+16+(pintu_id%4)*74,318-236+13+math.floor(pintu_id/4)*74),1.0,Vector2(48, 48),ARGB(255,255,255,255))
	tigerMachine_window_ui.fly.Visible = true
	
	tigerMachine_window_ui.light:Clear()
	tigerMachine_window_ui.light.Location = Vector2(183+54,253+54)
	tigerMachine_window_ui.light.Size = Vector2(0,0)
	tigerMachine_window_ui.light.NormLocation = Vector2(183+54,253+54)
	tigerMachine_window_ui.light:InsertMovePoint(Vector2(183+54,253+54),0,Vector2(0, 0),ARGB(0,255,255,255))
	tigerMachine_window_ui.light:InsertMovePoint(Vector2(183+54,253+54),0.15,Vector2(0, 0),ARGB(0,255,255,255))
	tigerMachine_window_ui.light:InsertMovePoint(Vector2(183,253),0.3,Vector2(108, 108),ARGB(255,255,255,255))
	tigerMachine_window_ui.light:InsertMovePoint(Vector2(183-18,253-18),0.5,Vector2(108+36, 108+36),ARGB(0,255,255,255))
	tigerMachine_window_ui.light.Visible = true
	gui:PlayAudio("kUIA_PUZZLE_MOVE")
end

function ShowViewPresent(index)
	view_present_window = ModalWindow.GetNew()
	view_present_window.root.Size = Vector2(1000,1000)
	view_present_window.screen.AllowEscToExit = false
	
	view_present_window_ui.ctrl_view_present_window.Parent = view_present_window.root
	view_present_window_title_ui.ctrl_view_present_window_title.Parent = view_present_window.root
	view_present_window_cancel_ui.btn_Close.Parent = view_present_window.root
	
	FillViewPresent(index,0)
end

function ShowViewpintu()
	view_pintu_window = ModalWindow.GetNew()
	view_pintu_window.root.Size = Vector2(1000,1000)
	view_pintu_window.screen.AllowEscToExit = false
	
	view_pintu_window_ui.ctrl_view_pintu_window.Parent = view_pintu_window.root
	view_present_window_title_ui.ctrl_view_present_window_title.Parent = view_pintu_window.root
	view_present_window_cancel_ui.btn_Close.Parent = view_pintu_window.root
	
	FillViewpintu(0)
end

function IsAllPintu()
	local flag = true
	for i = 1 , 16 do
		local ibbtn = tigerMachine_window_ui.pintu_num:GetChildByIndex(i - 1)
		if ibbtn.Enable == true then
			flag = false
			break
		end
	end
	if flag then
		tigerMachine_window_ui.look_award.Enable = true
	else
		tigerMachine_window_ui.look_award.Enable = false
	end
end

function ShowSunShine(index)
	pintu_OK = false
	if index < 3 then
		buy_gift_window = ModalWindow.GetNew()
		buy_gift_window.root.Size = Vector2(1200,800)
		buy_gift_window.screen.AllowEscToExit = false
		sunshine_window_ui.ctrl_sunshine_window.Location = Vector2(70+229,50)
		sunshine_window_ui.ctrl_sunshine_window.Parent = buy_gift_window.root
		
		-- tigerMachine_window_ui.ctrl_tigerMachine_window_ui.Size = Vector2(821,546)
		tigerMachine_window_ui.ctrl_tigerMachine_window_ui.Location = Vector2(190+229,127)
		tigerMachine_window_ui.ctrl_tigerMachine_window_ui.Parent = buy_gift_window.root
		tigerMachine_window_ui.c_pintu.Visible = false
	else
		buy_gift_window = ModalWindow.GetNew()
		buy_gift_window.root.Size = Vector2(1200,800)
		buy_gift_window.screen.AllowEscToExit = false
		sunshine_window_ui.ctrl_sunshine_window.Location = Vector2(70,50)
		sunshine_window_ui.ctrl_sunshine_window.Parent = buy_gift_window.root
		
		-- tigerMachine_window_ui.ctrl_tigerMachine_window_ui.Size = Vector2(821,546)
		tigerMachine_window_ui.ctrl_tigerMachine_window_ui.Location = Vector2(190,127)
		tigerMachine_window_ui.ctrl_tigerMachine_window_ui.Parent = buy_gift_window.root
		tigerMachine_window_ui.c_pintu.Visible = true
	end
end

function InitTiger()
	sunshine_window_ui.ctrl_sunshine_window:AddAnim("rotation",0.5,6)
	local sun =  Gui.Icon("LobbyUI/WarZone/Present/light.dds", Vector4(0, 0, 0, 0))
	sunshine_window_ui.ctrl_sunshine_window:AddFrame("rotation",sun)
	
	main_present_window_ui.Timer:AddAnim("Timer",3,4)
end

function InitPintu(data)
	pintuchance = true
	pintu_OK = true
	-- for i = 1 , 16 do
		-- local ibbtn = tigerMachine_window_ui.pintu_num:GetChildByIndex(i - 1)
		-- ibbtn.Enable = true
	-- end
	for i = 1 , 16 do
		local ibbtn = tigerMachine_window_ui.pintu_num:GetChildByIndex(i - 1)
		if data.misticAward.flags[i] == 1 then
			ibbtn.Enable = false
		else
			ibbtn.Enable = true
		end	
	end
	tigerMachine_window_ui.re_msg_1:CleanAll()
	tigerMachine_window_ui.re_msg_1:AddMsg(lang:GetText("这张拼图有 "),ARGB(255, 205, 129, 60),true,false)
	tigerMachine_window_ui.re_msg_1:AddMsg(lang:GetText("1"),ARGB(255, 255, 0, 0),false,false)
	tigerMachine_window_ui.re_msg_1:AddMsg(lang:GetText(" 次自由选择的机会"),ARGB(255, 205, 129, 60),false,false)
	tigerMachine_window_ui.look_award.Enable = false
	-- tigerMachine_window_ui.pintu_present.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/WarZone/Present/ib_gift_blockbox_ico_01.dds", Vector4(0, 0, 0, 0)),}
end

function InitPintuHover(pathname)
	for i = 1 , 16 do
		local ibbtn = tigerMachine_window_ui.pintu_num:GetChildByIndex(i - 1)
		ibbtn.Skin = Gui.ButtonSkin
		{
			BackgroundImage = nil,
			HoverImage = Gui.Image("LobbyUI/dailycheck/"..pathname..".dds", Vector4(10, 10, 10, 10)),
			DownImage = Gui.Image("LobbyUI/dailycheck/"..pathname..".dds", Vector4(10, 10, 10, 10)),
			DisabledImage = Gui.Image("LobbyUI/WarZone/Present/ib_gift_blockbox_puzzle_"..i..".dds", Vector4(0, 0, 0, 0)),
		}
	end
end

function InitPresent()
	for i = 1, 32 do
		local Icon = SpawnNewIcon(i)
		Icon.CHead.Parent = view_present_window_ui.ctrl_view_present_window
		view_present[i] = Icon
	end
end

function Init_Pintu()
	for i = 1, 16 do
		local Icon = SpawnNewPintuIcon(i)
		Icon.CHead.Parent = view_pintu_window_ui.ctrl_view_pintu_window
		view_pintu[i] = Icon
	end
end

function GetProperRect(imageSize,RectSize)
	local x,y = 0,0
	local ratio = imageSize.x/imageSize.y
	
	if imageSize.x <= RectSize.x and  imageSize.y <= RectSize.y then
		x = imageSize.x
		y = imageSize.y
	elseif imageSize.x > RectSize.x and imageSize.y <= RectSize.y then
		x = RectSize.x
		y = RectSize.x * (1/ratio)
	elseif imageSize.x <= RectSize.x and imageSize.y > RectSize.y then
		x = RectSize.y * ratio
		y = RectSize.y
	elseif imageSize.x > RectSize.x and imageSize.y > RectSize.y and imageSize.x >= imageSize.y then
		x = RectSize.x
		y = RectSize.x * (1/ratio)
	elseif imageSize.x > RectSize.x and imageSize.y > RectSize.y and imageSize.x <= imageSize.y then
		x = RectSize.y * ratio
		y = RectSize.y
	end
	
	return x,y
end

function FillRandImage(index,pos)
	local c_present = level_present[index]
	-- local random_present = rand_present[index]
	local rand_size = 10
	local x,y = 0,0
	local color = nil
	rand_pos = pos % rand_size
	
	local rand_pos1,rand_pos2,rand_pos3,rand_pos4
	rand_pos1 = (rand_pos + 0) % rand_size
	rand_pos2 = (rand_pos + 1) % rand_size
	rand_pos3 = (rand_pos + 2) % rand_size
	rand_pos4 = (rand_pos + 3) % rand_size
	
	if rand_pos1 == 0 then
		rand_pos1 = rand_size
	elseif rand_pos2 == 0 then
		rand_pos2 = rand_size
	elseif rand_pos3 == 0 then
		rand_pos3 = rand_size
	elseif rand_pos4 == 0 then
		rand_pos4 = rand_size
	end
-----------------------------------------------------------	
	-- present_name = random_present[rand_pos1].name
	-- if random_present[rand_pos1].color > 0 then
		-- present_name = present_name.."_"..random_present[rand_pos1].color
	-- end
	
	local rand_present1 = Gui.Image("LobbyUI/ibt_icon/gunlun"..index..".dds", Vector4(0, 0, 0, 0),Vector4(72*(rand_pos1-1)/720, 0, 72*rand_pos1/720, 1))
	x ,y = GetProperRect(rand_present1.Size,Vector2(72,72))
	x = x * 0.8
	y = y * 0.8
	c_present.present_rand_1.Size = Vector2(x,y)
	c_present.present_rand_1.Location = Vector2(20, 246)+ Vector2((72 - x)/2, (72 - y )/2)
	c_present.present_rand_1.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/gunlun"..index..".dds", Vector4(0, 0, 0, 0),Vector4(72*(rand_pos1-1)/720, 0, 72*rand_pos1/720, 1)),}
--------------------------------------------------------------------------
	-- present_name = random_present[rand_pos2].name
	-- if random_present[rand_pos2].color > 0 then
		-- present_name = present_name.."_"..random_present[rand_pos2].color
	-- end
	
	local rand_present2 = Gui.Image("LobbyUI/ibt_icon/gunlun"..index..".dds", Vector4(0, 0, 0, 0),Vector4(72*(rand_pos2-1)/720, 0, 72*rand_pos2/720, 1))
	x ,y = GetProperRect(rand_present2.Size,Vector2(72,72))
	x = x * 0.8
	y = y * 0.8
	c_present.present_rand_2.Size = Vector2(x,y)
	c_present.present_rand_2.Location = Vector2(90, 246) + Vector2((72 - x)/2, (72 - y )/2)
	c_present.present_rand_2.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/gunlun"..index..".dds", Vector4(0, 0, 0, 0),Vector4(72*(rand_pos2-1)/720, 0, 72*rand_pos2/720, 1)),}
-----------------------------------------------------------------------------
	-- present_name = random_present[rand_pos3].name
	-- if random_present[rand_pos3].color > 0 then
		-- present_name = present_name.."_"..random_present[rand_pos3].color
	-- end
	local rand_present3 = Gui.Image("LobbyUI/ibt_icon/gunlun"..index..".dds", Vector4(0, 0, 0, 0),Vector4(72*(rand_pos3-1)/720, 0, 72*rand_pos3/720, 1))
	x ,y = GetProperRect(rand_present3.Size,Vector2(72,72))
	x = x * 0.8
	y = y * 0.8
	c_present.present_rand_3.Size = Vector2(x,y)
	c_present.present_rand_3.Location = Vector2(160, 246) + Vector2((72 - x)/2, (72 - y )/2)
	c_present.present_rand_3.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/gunlun"..index..".dds", Vector4(0, 0, 0, 0),Vector4(72*(rand_pos3-1)/720, 0, 72*rand_pos3/720, 1)),}
-----------------------------------------------------------------------------
	-- present_name = random_present[rand_pos4].name
	-- if random_present[rand_pos4].color > 0 then
		-- present_name = present_name.."_"..random_present[rand_pos4].color
	-- end
	local rand_present4 = Gui.Image("LobbyUI/ibt_icon/gunlun"..index..".dds", Vector4(0, 0, 0, 0),Vector4(72*(rand_pos4-1)/720, 0, 72*rand_pos4/720, 1))
	x ,y = GetProperRect(rand_present4.Size,Vector2(72,72))
	x = x * 0.8
	y = y * 0.8
	c_present.present_rand_4.Size = Vector2(x,y)
	c_present.present_rand_4.Location = Vector2(230, 246) + Vector2((72 - x)/2, (72 - y )/2)
	c_present.present_rand_4.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/gunlun"..index..".dds", Vector4(0, 0, 0, 0),Vector4(72*(rand_pos4-1)/720, 0, 72*rand_pos4/720, 1)),}
	
	c_present.present_rand_1.BackgroundColor = ARGB(255, 255, 255, 255)
	c_present.present_rand_2.BackgroundColor = ARGB(255, 255, 255, 255)
	c_present.present_rand_3.BackgroundColor = ARGB(255, 255, 255, 255)
	c_present.present_rand_4.BackgroundColor = ARGB(255, 255, 255, 255)
	
	-- FillNumber(c_present.present_rand_1_b,random_present[rand_pos1].quantity,70,68)
	-- FillNumber(c_present.present_rand_2_b,random_present[rand_pos2].quantity,70,68)
	-- FillNumber(c_present.present_rand_3_b,random_present[rand_pos3].quantity,70,68)
	-- FillNumber(c_present.present_rand_4_b,random_present[rand_pos4].quantity,70,68)
end

function FillChest(data, i)
	local c_present = level_present[i]
	local present_name = data.name
	local size
	
	if data.color > 0 then
		present_name = present_name.."_"..data.color
	end
	
	c_present.present_name.Text = data.display
	size = c_present.present_content.Skin.BackgroundImage.Size
	c_present.present_content.Size = Vector2(size.x, size.y)
	c_present.present_content.Location = Vector2((321 - size.x)/2,80)
	FillRandImage(i,1)
end

function GetRandomPresent(data)
	random_data = data
	local c_present = level_present[witch_level_present]
	local random_present = data.list
	local rand_size = #random_present
	local temp_rand_size = #random_present
	local temp = {}
	local flag = {}
	local num = 0
	if rand_size < 60 then
		rand_size = 60
	end
	for i = 1, rand_size do
		flag[i] = 1
	end
	local m_max = rand_size
 	while m_max > 0 do
		num = math.random(rand_size)
		if  flag[num] ~= 0 then
			temp[rand_size - m_max + 1] = random_present[num%temp_rand_size+1]
			flag[num] = 0
			m_max = m_max - 1
		end
	end
	tigerMachine_window_ui.Tiger:ClearAll()
	tigerMachine_window_ui.Tiger:AddAnim("tiger",0.5,7)
	tigerMachine_window_ui.Tiger:SetFlipTimer("tiger",10,4.4078,2)
	print("rand_size:"..rand_size)
	present_data = data
	for i = 1, rand_size do
		present_name = temp[i].name
		local prize = Gui.Image("LobbyUI/ibt_icon/"..present_name..".tga", Vector4(0, 0, 0, 0))
		
		if present_name == data.random[static_present_times - present_times+1].name then 
			rpc_data[1] = data.random[static_present_times - present_times+1]
			if data.random[static_present_times - present_times+1].type >= 5 then
				pitch_on_present = data.random[static_present_times - present_times+1].quantity
			else
				pitch_on_present = 1
			end
			
			pitch_on_iamge =  data.random[static_present_times - present_times+1].name
			tigerMachine_window_ui.Tiger:AddFrame("tiger",prize,1)
		else
			tigerMachine_window_ui.Tiger:AddFrame("tiger",prize)
		end
	end
	tigerMachine_window_ui.Tiger:StartAnimation()
	gui:PlayAudio("kUIA_LAOHUJI")
	
	GetAllPintu(data)
end

function GetAllPintu(data)
	if data.flags[17] == 1 then
		pintuchance = true
	else
		pintuchance = false
	end
	tigerMachine_window_ui.re_msg_1:CleanAll()
	tigerMachine_window_ui.re_msg_1:AddMsg(lang:GetText("这张拼图有 "),ARGB(255, 205, 129, 60),true,false)
	tigerMachine_window_ui.re_msg_1:AddMsg(data.flags[17],ARGB(255, 255, 0, 0),false,false)
	tigerMachine_window_ui.re_msg_1:AddMsg(lang:GetText(" 次自由选择的机会"),ARGB(255, 205, 129, 60),false,false)
	for i = 1 , 16 do
		local ibbtn = tigerMachine_window_ui.pintu_num:GetChildByIndex(i - 1)
		if data.flags[i] == 1 then
			ibbtn.Enable = false
		else
			ibbtn.Enable = true
		end	
	end
	IsAllPintu()
	if data.indexs and data.indexs[present_times] and data.indexs[present_times] ~= -1 then
		pintu_id = data.indexs[present_times]
		print("pintu_id111:"..pintu_id)
	end
	if data.misticAward and data.misticAward.name ~= nil then
		pintu_all = true
		pintu_display = data.misticAward.display
		pintu_name = data.misticAward.name
	else
		pintu_all = false
		pintu_display = nil
		pintu_name = nil
	end
end

function Five_Ten()
	tigerMachine_window_ui.Tiger:ClearAll()
	tigerMachine_window_ui.Tiger:AddAnim("tiger",0.5,7)
	print("aaaaa:"..aaaaa)
	tigerMachine_window_ui.Tiger:SetFlipTimer("tiger",0.5,1.2,2)
	aaaaa = aaaaa + 1
	-- tigerMachine_window_ui.Tiger:SetFlipTimer("tiger",0.95,4.4078,2)
	local prize = Gui.Image("LobbyUI/ibt_icon/"..present_data.random[static_present_times - present_times + 1].name..".tga", Vector4(0, 0, 0, 0))
	tigerMachine_window_ui.Tiger:AddFrame("tiger",prize)
	present_times = present_times - 1
	prize = Gui.Image("LobbyUI/ibt_icon/"..present_data.random[static_present_times - present_times + 1].name..".tga", Vector4(0, 0, 0, 0))
	tigerMachine_window_ui.Tiger:AddFrame("tiger",prize)
	pintu_id = present_data.indexs[static_present_times -present_times+1]
	rpc_data[1] = present_data.random[static_present_times - present_times+1]
	if present_data.random[static_present_times - present_times+1].type >= 5 then
		pitch_on_present = present_data.random[static_present_times - present_times+1].quantity
	else
		pitch_on_present = 1
	end
	pitch_on_iamge = present_data.random[static_present_times - present_times+1].name
	tigerMachine_window_ui.Tiger:StartAnimation()
end

function FillbuyPresent(index,paytype)
	local c_present = level_present[index]
	local random_present = rand_present
	local rand_size = #random_present
	local present_name
	local size,x,y
	
	tigerMachine_window_ui.tiger_present2_content:OnDestroy()
	tigerMachine_window_ui.tiger_present1.Text = c_present.present_name.Text
	tigerMachine_window_ui.tiger_present1_content.Skin = c_present.present_content.Skin
	size = c_present.present_content.Skin.BackgroundImage.Size
	x,y = GetProperRect(size,Vector2(174,105))
	tigerMachine_window_ui.tiger_present1_content.Location = Vector2(23,284) + Vector2((174 - x)/2,(105 - y )/2)
	tigerMachine_window_ui.tiger_present1_content.Size = Vector2(x,y)
	
	tigerMachine_window_ui.Title.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/WarZone/Present/lotterybar_"..index..".dds", Vector4(0, 0, 0, 0)),}
	local args = {pid = ptr_cast(game.CurrentState):GetCharacterId(),level = index,payType = paytype,multiple = present_times}	
	rpc.safecall("chest_get",args,GetRandomPresent)
	args = {pid = ptr_cast(game.CurrentState):GetCharacterId()}
	rpc.safecall("chest_chip", args,
		function(data)
			-- main_present_window_ui.left_chip.Text = ""..data.chipNum
			-- main_present_window_ui.left_chip_bg.Text = ""..data.chipNum
			-- main_present_window_ui.cooper_key.Text = ""..data.copperyKeyNum
			-- main_present_window_ui.cooper_key_bg.Text = ""..data.copperyKeyNum
			-- main_present_window_ui.silver_key.Text = ""..data.silverKeyNum
			-- main_present_window_ui.silver_key_bg.Text = ""..data.silverKeyNum
			-- main_present_window_ui.gold_key.Text = ""..data.goldKeyNum
			-- main_present_window_ui.gold_key_bg.Text = ""..data.goldKeyNum
			Chip = data.chipNum
			Cooper = data.copperyKeyNum
			Silver = data.silverKeyNum
			Gold = data.goldKeyNum
			main_present_window_ui.qingtong.Text =tostring(Cooper).."/1"
			main_present_window_ui.baiyin.Text =tostring(Silver).."/1"
			main_present_window_ui.huangjin.Text =tostring(Gold).."/1"
			
			main_present_window_ui.xunzhang.Text =tostring(Chip).."/8"
			main_present_window_ui.xunzhang1.Text =tostring(Chip).."/15"
			main_present_window_ui.xunzhang2.Text =tostring(Chip).."/22"
			
			-- c_ribbon.bt_buy41.Text = tostring(Chip).."/8"
			-- c_ribbon["bt_buy42"].Text = tostring(Chip).."/15"
			-- c_ribbon["bt_buy43"].Text = tostring(Chip).."/22"

		end)		
	ShowSunShine(index)
end

function InitChest(i)
	local color = ""
	local text = ""
	local x,y
	local contentSkn
	if i == 1 then
		color = "cooper"
		text = lang:GetText("1000 C币")
		contentSkn = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/1000caladd_1.dds", Vector4(0, 0, 0, 0)),}
	elseif i == 2 then
		color = "silver"
		text = lang:GetText("2000 C币")
		contentSkn = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/2000caladd_2.dds", Vector4(0, 0, 0, 0)),}
	elseif i == 3 then
		color = "gold"
		text = lang:GetText("3000 C币")
		contentSkn = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/3000caladd_3.dds", Vector4(0, 0, 0, 0)),}
	end
	
	local c_bowknot = Gui.Create()
		{
			Gui.Control "bowknot"
			{
				Size = Vector2(331, 500),
				Location = Vector2(870, -1),
				BackgroundColor = ARGB(255, 255, 255, 255),
				
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/WarZone/Present/shop_gift_"..color..".dds", Vector4(0, 0, 0, 0)),
				},
			},
		}
	
	local c_present = Gui.Create()
		{
			Gui.Control "present"
			{
				Size = Vector2(321, 330),
				BackgroundColor = ARGB(0, 255, 255, 255),
				
				-- Skin = Gui.ControlSkin
				-- {
					-- BackgroundImage = Gui.Image("LobbyUI/WarZone/Present/shop_gift_"..color.."01.dds", Vector4(108, 226, 108, 12)),
				-- },
				
				-- Gui.Label "AddLabel"
				-- {
					-- Size = Vector2(40, 40),
					-- Location = Vector2(142, 181),
					-- BackgroundColor = ARGB(255, 255, 255, 255),
					-- Skin = Gui.ControlSkin
					-- {
						-- BackgroundImage = Gui.Image("LobbyUI/WarZone/Present/plus.dds", Vector4(0, 0, 0, 0)),
					-- },
				-- },
				
				-- Gui.Label "present_titel"
				-- {
					-- Size = Vector2(0, 0),
					-- Location = Vector2(0, 0),
					-- TextColor = ARGB(0,0, 0, 0),
					-- BackgroundColor = ARGB(0, 255, 255, 255),
					-- FontSize = 18,
					-- TextAlign = "kAlignCenterMiddle",
					-- Text = lang:GetText("超值A型礼包"),
				-- },
				
				Gui.Control "present_content"
				{
					Size = Vector2(221, 121),
					Location = Vector2(50, 80),
					BackgroundColor = ARGB(255, 255, 255, 255),
				},
				
				Gui.Label "present_name"
				{
					Size = Vector2(200, 50),
					Location = Vector2(60, 137),
					TextColor = ARGB(255, 229, 255, 252),
					BackgroundColor = ARGB(0, 255, 255, 255),
					FontSize = 14,
					TextAlign = "kAlignCenterMiddle",
					Text = "",
				},
				Gui.Control "loog1"
				{
					Size = Vector2(256, 112),
					Location = Vector2(32,87),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/WarZone/Present/shop_gift_cooper_bg.dds", Vector4(0, 0, 0, 0)),
						-- silverCard.tga
						-- goldCard.tga
					},
				},
				Gui.Control "loog2"
				{
					Size = Vector2(186, 98),
					Location = Vector2(65,100),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ibt_icon/rocket01025_6.tga", Vector4(0, 0, 0, 0)),
						-- silverCard.tga
						-- goldCard.tga
					},
				},
				Gui.Control "loog"
				{
					Size = Vector2(240, 64),
					Location = Vector2(30, 45),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/WarZone/Present/shop_gift_get_cooper.tga", Vector4(0, 0, 0, 0)),
						
					},
				},
				

				Gui.Button "bt_view_present"
				{
					Size = Vector2(70,35),
					Location = Vector2(232,215),
					Text = lang:GetText("查 看"),
					TextColor = ARGB(255, 0, 0, 0),
					FontSize = 18,
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_button_zhengli_normal.dds", Vector4(0, 0, 0, 0)),
						HoverImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_button_zhengli_hover.dds", Vector4(0, 0, 0, 0)),
						DownImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_button_zhengli_down.dds", Vector4(0, 0, 0, 0)),
						DisabledImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_button_zhengli_normal.dds", Vector4(0, 0, 0, 0)),
					},
					
					EventClick = function(Sender,e)
						local args = {level = Sender.Parent.IntTag , pageNo = 0}	
						rpc.safecallload("chest_list", args,
						function(data)
							rand_present = data.random
							view_present_page = 0
							total_page = data.pageCount - 1
							ShowViewPresent(Sender.Parent.IntTag)
							if view_present_page == 0 then
								view_present_window_ui.bt_view_present_prev.Visible = false
								view_present_window_ui.bt_view_present_next.Visible = true
							end
							if #data.random < 32 then
								view_present_window_ui.bt_view_present_prev.Visible = false
								view_present_window_ui.bt_view_present_next.Visible = false
							end
						end)
					end
				},
				
				Gui.Label "present_1"
				{
					Size = Vector2(72, 72),
					Location = Vector2(24, 246),
					BackgroundColor = ARGB(255, 255, 255, 255),
					
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/WarZone/Present/shop_gift_"..color.."_table.dds", Vector4(0, 0, 0, 0)),
					},
				},
				
				Gui.Label "present_rand_1"
				{
					Size = Vector2(72, 72),
					Location = Vector2(20, 246),
					BackgroundColor = ARGB(0, 255, 255, 255),
					
				},
				
				Gui.Label "present_rand_1_b"
				{
					Size = Vector2(72, 72),
					Location = Vector2(20, 246),
					BackgroundColor = ARGB(0, 255, 255, 255),
					
				},
							
				Gui.Label "present_2"
				{
					Size = Vector2(72, 72),
					Location = Vector2(90+3, 246),
					BackgroundColor = ARGB(255, 255, 255, 255),
					
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/WarZone/Present/shop_gift_"..color.."_table.dds", Vector4(0, 0, 0, 0)),
					},
				},
				
				Gui.Label "present_rand_2"
				{
					Size = Vector2(72, 72),
					Location = Vector2(90, 246),
					BackgroundColor = ARGB(0, 255, 255, 255),	
				},
				
				Gui.Label "present_rand_2_b"
				{
					Size = Vector2(72, 72),
					Location = Vector2(90, 246),
					BackgroundColor = ARGB(0, 255, 255, 255),
					
				},
				
				Gui.Label "present_3"
				{
					Size = Vector2(72, 72),
					Location = Vector2(160+3, 246),
					BackgroundColor = ARGB(255, 255, 255, 255),
					
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/WarZone/Present/shop_gift_"..color.."_table.dds", Vector4(0, 0, 0, 0)),
					},
				},
				
				Gui.Label "present_rand_3"
				{
					Size = Vector2(72, 72),
					Location = Vector2(160, 246),
					BackgroundColor = ARGB(0, 255, 255, 255),
				},
				
				Gui.Label "present_rand_3_b"
				{
					Size = Vector2(72, 72),
					Location = Vector2(160, 246),
					BackgroundColor = ARGB(0, 255, 255, 255),
					
				},
				
				Gui.Label "present_4"
				{
					Size = Vector2(72, 72),
					Location = Vector2(230+3, 246),
					BackgroundColor = ARGB(255, 255, 255, 255),
					
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/WarZone/Present/shop_gift_"..color.."_table.dds", Vector4(0, 0, 0, 0)),
					},
				},
				
				Gui.Label "present_rand_4"
				{
					Size = Vector2(72, 72),
					Location = Vector2(230, 246),
					BackgroundColor = ARGB(0, 255, 255, 255),
				},
				
				Gui.Label "present_rand_4_b"
				{
					Size = Vector2(72, 72),
					Location = Vector2(230, 246),
					BackgroundColor = ARGB(0, 255, 255, 255),
					
				},
			},
		}
	
	local c_ribbon = Gui.Create()
		{
			Gui.Control "present_bottom"
			{
				Size = Vector2(308, 156),
				Location = Vector2(161, 405),
				BackgroundColor = ARGB(0, 255, 255, 255),
				
				Gui.Label "present_fc"
				{
					Size = Vector2(40, 20),
					Location = Vector2(67, 63),
					TextColor = ARGB(255, 255, 255, 255),
					BackgroundColor = ARGB(0, 255, 255, 255),
					FontSize = 14,
					TextAlign = "kAlignCenterMiddle",
					Text = "",
				},
				
				Gui.Label "present_chip"
				{
					Size = Vector2(40, 20),
					Location = Vector2(192, 63),
					TextColor = ARGB(255, 255, 255, 255),
					BackgroundColor = ARGB(0, 255, 255, 255),
					FontSize = 14,
					TextAlign = "kAlignCenterMiddle",
					Text = "",
				},
				
				Gui.Button "bt_buy"
				{
					Size = Vector2(152,94),
					Location = Vector2(1, 0),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Text = lang:GetText(""),
					TextColor = ARGB(255, 229, 255, 252),
					TextAlign = "kAlignCenterMiddle",
					HighlightTextColor = ARGB(255, 229, 255, 252),
					-- Enable = false,

					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/WarZone/Present/lb_shop_gift_button_1_normal.tga", Vector4(0, 0, 0, 0)),
						HoverImage = Gui.Image("LobbyUI/WarZone/Present/lb_shop_gift_button_1_hover.tga", Vector4(0, 0, 0, 0)),
						DownImage = Gui.Image("LobbyUI/WarZone/Present/lb_shop_gift_button_1_down.tga", Vector4(0, 0, 0, 0)),
						DisabledImage = Gui.Image("LobbyUI/WarZone/Present/lb_shop_gift_button_1_disabled.tga", Vector4(0, 0, 0, 0)),
					},
					Gui.Label "bt_buy1"
					{
						Size = Vector2(100, 30),
						Text = lang:GetText("使用青铜卡"),
						FontSize = 20,
						TextColor = ARGB(255, 255, 255, 255),
						Location = Vector2(20, 7),
						TextAlign = "kAlignLeftMiddle",
					},
					Gui.Control "bt_buy2"
					{
						Size = Vector2(30, 30),
						Location = Vector2(30, 45),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ibt_icon/bronzeCard.tga", Vector4(0, 0, 0, 0)),
							-- silverCard.tga
							-- goldCard.tga
						},
					},
					-- Gui.Label "bt_buy3"
					-- {
						-- Size = Vector2(100, 30),
						-- Text = "",
						-- FontSize = 18,
						-- TextColor = ARGB(255, 255, 255, 255),
						-- Location = Vector2(40, 45),
						-- TextAlign = "kAlignCenterMiddle",
					-- },
					EventClick = function(Sender,e)
						local index = Sender.Parent.IntTag
						present_index = index
						--print("L_LobbyMain.PersonalInfo_data.newCR = "..L_LobbyMain.PersonalInfo_data.newCR)
						is_chip = false
						is_cmoney = true
						for i = 1, 3 do
							if index == g_data.fix[i].level then
								index = i
								break
							end
						end
						
						if present_index == 1 then
							my_keynum = Cooper
						elseif present_index == 2 then
							my_keynum = Silver
						elseif present_index == 3 then
							my_keynum = Gold
						end
						-- tigerMachine_window_ui.tiger_present2_content.BackgroundColor = ARGB(0, 255, 255, 255)
						-- tigerMachine_window_ui.tiger_present2_content.ItemIcon = nil
						-- tigerMachine_window_ui.tiger_present2_content:OnDestroy()
						tigerMachine_window_ui.tiger_present2_change.Visible = false
						tigerMachine_window_ui.tiger_present2_content_num:OnDestroy()
						local c_present = level_present[index]
						local size,x,y
						
						tigerMachine_window_ui.tiger_present1.Text = c_present.present_name.Text
						tigerMachine_window_ui.tiger_present1_content.Skin = c_present.present_content.Skin
						size = c_present.present_content.Skin.BackgroundImage.Size
						x,y = GetProperRect(size,Vector2(174,105))
						tigerMachine_window_ui.tiger_present1_content.Location = Vector2(23,284) + Vector2((174 - x)/2,(105 - y )/2)
						tigerMachine_window_ui.tiger_present1_content.Size = Vector2(x,y)
						tigerMachine_window_ui.Title.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/WarZone/Present/lotterybar_"..index..".dds", Vector4(0, 0, 0, 0)),}
						ShowSunShine(index)
						tigerMachine_window_ui.pintu_num.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/WarZone/Present/ib_gift_blockbox_bg_03.dds", Vector4(0, 0, 0, 0)),}
						InitPintuHover("lb_tutorial_square01")
						pintu_OK = true
						rpc.safecall("get_pintu_states", {pid = ptr_cast(game.CurrentState):GetCharacterId()},
						function(data)
							GetAllPintu(data)
						end)	
					end
				},
				
				
				Gui.Button "bt_change"
				{
					Size = Vector2(152,94),
					Location = Vector2(149, 0),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Text = lang:GetText(""),
					TextColor = ARGB(255, 229, 255, 252),
					TextAlign = "kAlignCenterMiddle",
					HighlightTextColor = ARGB(255, 229, 255, 252),

					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/WarZone/Present/lb_shop_gift_button_2_normal.tga", Vector4(0, 0, 0, 0)),
						HoverImage = Gui.Image("LobbyUI/WarZone/Present/lb_shop_gift_button_2_hover.tga", Vector4(0, 0, 0, 0)),
						DownImage = Gui.Image("LobbyUI/WarZone/Present/lb_shop_gift_button_2_down.tga", Vector4(0, 0, 0, 0)),
						DisabledImage = Gui.Image("LobbyUI/WarZone/Present/lb_shop_gift_button_2_disabled.tga", Vector4(0, 0, 0, 0)),
					},
					
					Gui.Label ""
					{
						Size = Vector2(80, 30),
						Text = lang:GetText("使用勋章"),
						FontSize = 20,
						TextColor = ARGB(255, 255, 255, 255),
						Location = Vector2(30, 7),
						TextAlign = "kAlignLeftMiddle",
					},
					Gui.Control ""
					{
						Size = Vector2(33, 33),
						Location = Vector2(27, 46),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ibt_icon/medal.tga", Vector4(0, 0, 0, 0)),
						
						},
					},
					Gui.Label "bt_buy41"
					{
						Size = Vector2(100, 30),
						Text = "",
						FontSize = 18,
						TextColor = ARGB(255, 255, 255, 255),
						Location = Vector2(40, 45),
						TextAlign = "kAlignCenterMiddle",
					},	
					EventClick = function(Sender,e)
						local index = Sender.Parent.IntTag
						present_index = index
						is_chip = true
						is_cmoney = false
					
						for i = 1, 3 do
							if index == g_data.fix[i].level then
								index = i
								break
							end
						end
						-- tigerMachine_window_ui.tiger_present2_content.BackgroundColor = ARGB(0, 255, 255, 255)
						-- tigerMachine_window_ui.tiger_present2_content.ItemIcon = nil
						-- tigerMachine_window_ui.tiger_present2_content:OnDestroy()
						tigerMachine_window_ui.tiger_present2_change.Visible = false
						tigerMachine_window_ui.tiger_present2_content_num:OnDestroy()
						local c_present = level_present[index]
						local size,x,y
						tigerMachine_window_ui.tiger_present1.Text = c_present.present_name.Text
						tigerMachine_window_ui.tiger_present1_content.Skin = c_present.present_content.Skin
						size = c_present.present_content.Skin.BackgroundImage.Size
						x,y = GetProperRect(size,Vector2(174,105))
						tigerMachine_window_ui.tiger_present1_content.Location = Vector2(23,284) + Vector2((174 - x)/2,(105 - y )/2)
						tigerMachine_window_ui.tiger_present1_content.Size = Vector2(x,y)
						tigerMachine_window_ui.Title.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/WarZone/Present/lotterybar_"..index..".dds", Vector4(0, 0, 0, 0)),}
						ShowSunShine(index)
						tigerMachine_window_ui.pintu_num.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/WarZone/Present/ib_gift_blockbox_bg_03.dds", Vector4(0, 0, 0, 0)),}
						InitPintuHover("lb_tutorial_square01")
						pintu_OK = true
						rpc.safecall("get_pintu_states", {pid = ptr_cast(game.CurrentState):GetCharacterId()},
						function(data)
							GetAllPintu(data)
						end)
					end
				},
				
			},
		}
	c_present.present_content.Skin = contentSkn
	x ,y = GetProperRect(c_present.present_content.Skin.BackgroundImage.Size,Vector2(221, 121))
	c_present.present_content.Size = Vector2(x,y)
	c_present.present_content.Location = Vector2(50, 80) + Vector2((221 - x)/2, (121 - y )/2 - 20)
				
	-- c_present.present_titel.Text = title
	c_present.present.IntTag = i
	-- c_present.present.Location = Vector2(1 + (i - 1) * 313, 71)
	
	-- c_ribbon.present_bottom.Location = Vector2(10 + (i - 1)* 317, 391)
	
	if  i == 1  then
		c_present.present.Location = Vector2(1 + (1 - 1) * 313, 71)
		c_present.loog.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/WarZone/Present/shop_gift_get_cooper.tga", Vector4(0, 0, 0, 0)),}
		c_present.loog1.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/WarZone/Present/shop_gift_cooper_bg.dds", Vector4(0, 0, 0, 0)),}
		c_present.loog2.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/sniper01005.tga", Vector4(0, 0, 0, 0)),}
		
		-- c_ribbon.present_bottom.Location = Vector2(12 + (1 - 1)* 317, 391)
		c_ribbon.bt_buy1.Text = lang:GetText("使用青铜卡")
		c_ribbon.bt_buy2.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/bronzeCard.tga", Vector4(0 , 0, 0, 0)),}
		-- c_ribbon.bt_buy3.Text = tostring(Cooper).."/1"
		main_present_window_ui.qingtong.Text =tostring(Cooper).."/1"
		main_present_window_ui.xunzhang.Text =tostring(Chip).."/8"
		c_ribbon.present_bottom.Location = Vector2(12 + (1 - 1)* 317, 391)
	end
	if i == 2 then
		c_present.present.Location = Vector2(1 + (2 - 1) * 313, 71)
		c_present.loog.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/WarZone/Present/shop_gift_get_silver.tga", Vector4(0, 0, 0, 0)),}
		c_present.loog1.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/WarZone/Present/shop_gift_silver_bg.dds", Vector4(0, 0, 0, 0)),}
		c_present.loog2.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/fatman02009_6.tga", Vector4(0, 0, 0, 0)),}
		
		c_ribbon.bt_buy1.Text = lang:GetText("使用白银卡")
		c_ribbon.bt_buy2.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/silverCard.tga", Vector4(0 , 0, 0, 0)),}
		
		main_present_window_ui.baiyin.Text =tostring(Silver).."/1"
		main_present_window_ui.xunzhang1.Text =tostring(Chip).."/15"
		
		c_ribbon.present_bottom.Location = Vector2(10 + (2 - 1)* 317, 391)
	end
	if i == 3 then
		c_present.present.Location = Vector2(1 + (3 - 1) * 313, 71)
		c_present.loog.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/WarZone/Present/shop_gift_get_gold.tga", Vector4(0, 0, 0, 0)),}
		c_present.loog1.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/WarZone/Present/shop_gift_gold_bg.dds", Vector4(0, 0, 0, 0)),}
		c_present.loog2.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/rocket01025_6.tga", Vector4(0, 0, 0, 0)),}
		
		c_ribbon.bt_buy1.Text = lang:GetText("使用黄金卡")
		c_ribbon.bt_buy2.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/goldCard.tga", Vector4(0 , 0, 0, 0)),}
		-- c_ribbon.bt_buy3.Text = tostring(Gold).."/1"
		main_present_window_ui.huangjin.Text =tostring(Gold).."/1"
		main_present_window_ui.xunzhang2.Text =tostring(Chip).."/22"
		c_ribbon.present_bottom.Location = Vector2(4 + (3 - 1)* 317, 391)
	end
	
	c_ribbon.present_bottom.IntTag = i
	c_bowknot.bowknot.Location = Vector2((i - 1) * 313, 5)
	-- c_present.present_name.Text = text
	
	return c_present,c_ribbon,c_bowknot
end

local Prsent_prize_Win = 
{
	Gui.Control "Shooting_prize_root"
	{	
		Size = Vector2(1200, 900),
		BackgroundColor = ARGB(0, 255, 255, 255),
		Location = Vector2(0, 0),
		
		Gui.Control
		{	
			Size = Vector2(361, 331),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Dock = "kDockCenter",
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/main_bar01.dds", Vector4(20, 20, 20, 20)),
			},

			Gui.Control
			{	
				Size = Vector2(339, 308),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Location = Vector2(11, 12),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/main_bar02.dds", Vector4(8, 8, 8, 8)),
				},
				
				Gui.Control
				{	
					Size = Vector2(339, 46),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Location = Vector2(0, 0),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/Shooting/lb_range_title_07.dds", Vector4(0, 0, 0, 0)),
					},
				},
					
				Gui.Control
				{	
					Size = Vector2(326, 179),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Location = Vector2(6, 50),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/Shooting/lb_range_tankuang.dds", Vector4(7, 7, 7, 7)),
					},
					
					Gui.Label "item_name"
					{
						Size = Vector2(167,20),
						Location = Vector2(80,20),
						TextColor = ARGB(255, 236, 206, 72),
						FontSize = 18,
						TextAlign = "kAlignCenterMiddle",
						BackgroundColor = ARGB(0,255,255,255),
					},
					
					Gui.ItemBoxBtn "IBTN_Shooting_prize"
					{
						Style = "Gui.ItemBoxBtn_ib",
						Size = Vector2(167,77),
						Location = Vector2(80,47),
						BackgroundColor = ARGB(255,255,255,255),
						Skin = Gui.ItemBoxBtnSkin
						{
							NeutralNormalImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_02.dds", Vector4(0, 0, 0, 0)),
							--NeutralHoverImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_02.dds", Vector4(0, 0, 0, 0)),
							NeutralSelectedImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_02.dds", Vector4(0, 0, 0, 0)),
							NeutralDisabledImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_02.dds", Vector4(0, 0, 0, 0)),
						},						
					},
				},
			},
			
			--确定
			Gui.Button "btn_close"
			{
				Size = Vector2(110,38),
				Location = Vector2(126, 260),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Text = lang:GetText("确 定"),
				TextColor = ARGB(255, 229, 255, 252),
				TextAlign = "kAlignCenterMiddle",
				HighlightTextColor = ARGB(255, 229, 255, 252),
				Padding = Vector4(0, 0, 0, 5),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_onlinetime_button_2_normal.dds", Vector4(0, 0, 0, 0)),
					HoverImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_onlinetime_button_2_hover.dds", Vector4(0, 0, 0, 0)),
					DownImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_onlinetime_button_2_down.dds", Vector4(0, 0, 0, 0)),
					DisabledImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_onlinetime_button_2_disabled.dds", Vector4(0, 0, 0, 0)),
				},
			},
		},
	},
}

function ShowPrsentprizeWin(data,num)
	if Prsent_prize_Win_ui == nil then
		Prsent_prize_Win_ui = Gui.Create()(Prsent_prize_Win)
		Prsentprize_Window = ModalWindow.GetNew("Prsent_prize_Win_ui")
		Prsentprize_Window.screen.AllowEscToExit = false
		Prsentprize_Window.screen.Visible = false
		Prsentprize_Window.screen.EventEscPressed = nil
		Prsentprize_Window.root.Size = Vector2(1200, 900)
		Prsent_prize_Win_ui.Shooting_prize_root.Parent = Prsentprize_Window.root
	end
	Prsent_prize_Win_ui.btn_close.EventClick = function()
													HidePrsentprizeWin()
												end
	if data and data.onlineAward.name ~= nil then
		local templist = {data.onlineAward}
		Prsent_prize_Win_ui.IBTN_Shooting_prize.EventMouseEnter = function(sender, e)
			L_ToolTips.FillToolTipsVIPPresent(num, Prsent_prize_Win_ui.Shooting_prize_root, templist)
		end
		Prsent_prize_Win_ui.IBTN_Shooting_prize.EventToolTipsShow = function(sender, e)
			local loc = sender.Location + sender.Parent.Location + sender.Parent.Parent.Location + sender.Parent.Parent.Parent.Location + sender.Parent.Parent.Parent.Parent.Location
			L_ToolTips.ShowToolTipsShowWindow(sender,Vector2(1200, 900),loc)
		end
		Prsent_prize_Win_ui.IBTN_Shooting_prize.EventMouseLeave = function(sender, e)
			L_ToolTips.HideToolTipsWindow()
		end
		Prsent_prize_Win_ui.IBTN_Shooting_prize:OnDestroy()
		if data.onlineAward.unit and data.onlineAward.common.type == 5 then
			L_Characters.CreatPresentNumCtr(Prsent_prize_Win_ui.IBTN_Shooting_prize,data.onlineAward.unit,167,77)
		elseif data.onlineAward.unit and data.onlineAward.common.type == 4 and data.onlineAward.common.subtype == 7 then
			L_Characters.CreatPresentNumCtr(Prsent_prize_Win_ui.IBTN_Shooting_prize,data.onlineAward.unit,167,77)
		end
		Prsent_prize_Win_ui.IBTN_Shooting_prize.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..data.onlineAward.name..".tga")
		Prsent_prize_Win_ui.item_name.Text = data.onlineAward.display
	end
	if Prsentprize_Window and Prsentprize_Window.screen then
		Prsentprize_Window.screen.Visible = true
		--gui.EventEscPressed = HideCharmBottleWin
		gui.EventEscPressed = nil
	end
end

function HidePrsentprizeWin()
	if Prsentprize_Window and Prsentprize_Window.screen then
		Prsentprize_Window.screen.Visible = false
		Prsentprize_Window:Close()
		Prsent_prize_Win_ui = nil
	end
end

function SpawnNewPresentIcon(i,x,y)
	return Gui.ItemBoxBtn ("ibtn"..i)
	{
		Style = "Gui.ItemBoxBtn_ib",
		Size = Vector2(93,93),
		Location = Vector2(x,y),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Skin = Gui.ItemBoxBtnSkin
		{
			NeutralNormalImage = Gui.Image("LobbyUI/WarZone/Present/lb_gift_biew_bg2.dds", Vector4(0, 0, 0, 0)),
			NeutralSelectedImage = Gui.Image("LobbyUI/WarZone/Present/lb_gift_biew_bg2.dds", Vector4(0, 0, 0, 0)),
			NeutralDisabledImage = Gui.Image("LobbyUI/WarZone/Present/lb_gift_biew_bg2.dds", Vector4(0, 0, 0, 0)),
		},
		EventMouseEnter = function(sender, e)
			L_ToolTips.FillToolBigPresentWindow(i+5*(fiveten_page-1), FiveTenPresent_Window.root, present_data.random)
		end,
		EventToolTipsShow = function(sender, e)
			if present_data.random[i+5*(fiveten_page-1)] ~= nil then
				L_ToolTips.ShowToolTipsShowWindow(sender,Vector2(1200, 900),sender.Location + sender.Parent.Location+sender.Parent.Parent.Location)
			end
		end,
		EventMouseLeave = function(sender, e)
			L_ToolTips.HideToolTipsWindow()
		end,
	}
end

Five_Ten_Present = Gui.Create()
{
	Gui.Control "root"
	{	
		Size = Vector2(1200, 900),
		BackgroundColor = ARGB(0, 255, 255, 255),
		Location = Vector2(0, 0),
		Gui.Control
		{	
			Size = Vector2(606, 257),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Dock = "kDockCenter",
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_contact_bg1_01.dds", Vector4(163,163,53,53)),
			},
			Gui.Control "Present"
			{	
				Size = Vector2(564, 174),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Location = Vector2(20, 20),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/WarZone/Present/ib_gift_blockbox_bg_04.dds", Vector4(0, 0, 0, 0)),
				},
				SpawnNewPresentIcon(1,45,60),
				SpawnNewPresentIcon(2,140,60),
				SpawnNewPresentIcon(3,235,60),
				SpawnNewPresentIcon(4,329,60),
				SpawnNewPresentIcon(5,424,60),
				
				Gui.Label
				{
					Size = Vector2(80,30),
					FontSize = 18,
					Location = Vector2(16,8),
					TextColor = ARGB(255, 165, 55, 0),
					TextAlign = "kAlignCenterMiddle",
					Text = lang:GetText("你获得了"),
					BackgroundColor = ARGB(0, 255, 255, 255),
				},
				Gui.Label
				{
					Size = Vector2(80,30),
					FontSize = 18,
					Location = Vector2(15,7),
					TextColor = ARGB(255, 37, 37, 37),
					TextAlign = "kAlignCenterMiddle",
					Text = lang:GetText("你获得了"),
					BackgroundColor = ARGB(0, 255, 255, 255),
				},
				
				Gui.Button "m_Left"
				{	
					Size = Vector2(33, 48),
					Location = Vector2(13,82),
					TextColor = ARGB(255, 209, 227, 221),
					Enable = false,
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/Compose/lb_fastsettlement_button03_normal.dds", Vector4(0, 0, 0, 0)),
						HoverImage = Gui.Image("LobbyUI/Compose/lb_fastsettlement_button03_hover.dds", Vector4(0, 0, 0, 0)),
						DownImage = Gui.Image("LobbyUI/Compose/lb_fastsettlement_button03_down.dds", Vector4(0, 0, 0, 0)),
						DisabledImage = Gui.Image("LobbyUI/Compose/lb_fastsettlement_button03_disabled.dds", Vector4(0, 0, 0, 0)),
					},
					EventClick = function(Sender ,e)
						Sender.Enable = false
						Five_Ten_Present.m_Right.Enable = true
						Five_Ten_Present.m_PageDisplay.Text = "1/2"
						fiveten_page = 1
						FillFiveTenPresent()
					end
					
				},
				
				Gui.Button "m_Right"
				{
					Size = Vector2(33, 48),
					Location = Vector2(517,82),
					TextColor = ARGB(255, 209, 227, 221),
					Enable = false,
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/Compose/lb_fastsettlement_button02_normal.dds", Vector4(0, 0, 0, 0)),
						HoverImage = Gui.Image("LobbyUI/Compose/lb_fastsettlement_button02_hover.dds", Vector4(0, 0, 0, 0)),
						DownImage = Gui.Image("LobbyUI/Compose/lb_fastsettlement_button02_down.dds", Vector4(0, 0, 0, 0)),
						DisabledImage = Gui.Image("LobbyUI/Compose/lb_fastsettlement_button02_disabled.dds", Vector4(0, 0, 0, 0)),
					},
					EventClick = function(Sender ,e)
						Sender.Enable = false
						Five_Ten_Present.m_Left.Enable = true
						Five_Ten_Present.m_PageDisplay.Text = "2/2"
						fiveten_page = 2
						FillFiveTenPresent()
					end
				},
				
				Gui.Label "m_PageDisplay"
				{
					Size = Vector2(80,30),
					FontSize = 18,
					Location = Vector2(484,10),
					TextColor = ARGB(255, 254, 169, 85),
					TextAlign = "kAlignCenterMiddle",
					Text = lang:GetText("1/2"),
					BackgroundColor = ARGB(0, 255, 255, 255),
				},
			},	
			
			--确定
			Gui.Button "btn_close"
			{
				Size = Vector2(201,46),
				Location = Vector2(196, 198),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Text = lang:GetText("确 定"),
				TextColor = ARGB(255, 229, 255, 252),
				TextAlign = "kAlignCenterMiddle",
				HighlightTextColor = ARGB(255, 229, 255, 252),
				Padding = Vector4(0, 0, 0, 5),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_normal.dds", Vector4(0, 0, 0, 0)),
					HoverImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_hover.dds", Vector4(0, 0, 0, 0)),
					DownImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_down.dds", Vector4(0, 0, 0, 0)),
					DisabledImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_disabled.dds", Vector4(0, 0, 0, 0)),
				},
				EventClick = function(Sender ,e)	
					HideFiveTenPresentWin()
				end,
			},
		},
	},
}

function ShowFiveTenPresentWin()
	fiveten_page = 1
	if static_present_times == 1 then
		Five_Ten_Present.m_Left.Enable = false
		Five_Ten_Present.m_Right.Enable = false
		return
	elseif static_present_times == 5 then
		Five_Ten_Present.m_Left.Enable = false
		Five_Ten_Present.m_Right.Enable = false
		Five_Ten_Present.m_PageDisplay.Text = "1/1"
	elseif static_present_times == 10 then
		Five_Ten_Present.m_Left.Enable = false
		Five_Ten_Present.m_Right.Enable = true
		Five_Ten_Present.m_PageDisplay.Text = "1/2"
	end
	FiveTenPresent_Window = ModalWindow.GetNew()
	FiveTenPresent_Window.root.Size = Vector2(1200, 900)
	FiveTenPresent_Window.screen.AllowEscToExit = false
	Five_Ten_Present.root.Parent = FiveTenPresent_Window.root
	FillFiveTenPresent()
end

function HideFiveTenPresentWin()
	if FiveTenPresent_Window then
		FiveTenPresent_Window:Close()
		FiveTenPresent_Window = nil
	end
end

function FillFiveTenPresent()
	for i = 1, 5 do
		Five_Ten_Present["ibtn"..i]:OnDestroy()
		Five_Ten_Present["ibtn"..i].ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..present_data.random[i+5*(fiveten_page-1)].name..".tga")
		if present_data.random[i+5*(fiveten_page-1)].type >= 5 then
			L_Characters.CreatPresentNumCtr(Five_Ten_Present["ibtn"..i],present_data.random[i+5*(fiveten_page-1)].quantity,93,93) 
		else
			L_Characters.CreatPresentNumCtr(Five_Ten_Present["ibtn"..i],1,93,93) 
		end
	end
end
--快速购买界面
local Rapid_Shopping_Win = 
{
	Gui.Control "Rapid_Shopping_root"
	{	
		Size = Vector2(1200, 900),
		BackgroundColor = ARGB(0, 255, 255, 255),
		Location = Vector2(0, 0),
		
		Gui.Control
		{	
			Size = Vector2(377, 375),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Dock = "kDockCenter",
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/main_bar01.dds", Vector4(20, 20, 20, 20)),
			},

			Gui.Control
			{	
				Size = Vector2(355, 352),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Location = Vector2(11, 12),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/main_bar02.dds", Vector4(8, 8, 8, 8)),
				},
				
				Gui.Label
				{
					Size = Vector2(353, 35),
					Location = Vector2(0, 0),
					TextColor = ARGB(255, 255, 210, 0),
					FontSize = 18,
					TextAlign = "kAlignLeftMiddle",
					Text = lang:GetText("快速购买"),
					BackgroundColor = ARGB(255,255,255,255),
					TextPadding = Vector4(8,0,0,8),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_onlinetime_bg_5.dds", Vector4(8, 8, 8, 8)),
					},
				},
				
				Gui.Control
				{	
					Size = Vector2(325, 260),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Location = Vector2(16, 39),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_01.dds", Vector4(40, 40, 40, 40)),
					},
					
					Gui.Control
					{	
						Size = Vector2(274, 208),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Location = Vector2(24, 10),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_06.dds", Vector4(32, 28, 32, 50)),
						},
						
						Gui.Label "name"
						{
							Size = Vector2(274, 28),
							Location = Vector2(0, 0),
							TextColor = ARGB(255, 255, 210, 0),
							FontSize = 18,
							TextAlign = "kAlignCenterMiddle",
							Text = lang:GetText("密码卡"),
							BackgroundColor = ARGB(0,255,255,255),
							TextPadding = Vector4(0,0,0,3),
						},
						
						Gui.TextArea "des"
						{
							Size = Vector2(200, 50),
							Location = Vector2(55, 110),
							TextColor = ARGB(255, 255, 210, 0),
							FontSize = 16,
							Readonly = true,
							Fold = true,
							BackgroundColor = ARGB(255,255,255,255),
						},
						-- Gui.Button "BTN_1"
						-- {
							-- Size = Vector2(44,56),
							-- Location = Vector2(23, 38),
							-- Skin = Gui.ButtonSkin
							-- {
								-- BackgroundImage = Gui.Image("LobbyUI/Compose/lb_fastsettlement_button03_normal.dds", Vector4(0, 0, 0, 0)),
								-- HoverImage = Gui.Image("LobbyUI/Compose/lb_fastsettlement_button03_hover.dds", Vector4(0, 0, 0, 0)),
								-- DownImage = Gui.Image("LobbyUI/Compose/lb_fastsettlement_button03_down.dds", Vector4(0, 0, 0, 0)),
								-- DisabledImage = Gui.Image("LobbyUI/Compose/lb_fastsettlement_button03_disabled.dds", Vector4(0, 0, 0, 0)),
							-- },
							-- EventClick = function()
								-- if Rapid_Shopping_index > 1 then
									-- Rapid_Shopping_index = Rapid_Shopping_index - 1
									-- Rapid_Shopping_Win.name.Text = discount_data.theItem[Rapid_Shopping_index].display
									-- Rapid_Shopping_Win.des.Text = discount_data.theItem[Rapid_Shopping_index].description
									-- -- shop_fast_buy.sid = discount_data.theItem[Rapid_Shopping_index].sid
									-- -- price = item_rpc.prices[Rapid_Shopping_index]
									-- Rapid_Shopping_Win_ui.itembox_hummer.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..discount_data.theItem[Rapid_Shopping_index].name..".tga")
									-- Rapid_Shopping_Win_ui.Total_money.Text = discount_data.discounts[Rapid_Shopping_index][discount_index] * discount_data.theItem[Rapid_Shopping_index].crprices[1].cost
								-- end
							-- end,
						-- },
						-- Gui.Button "BTN_2"
						-- {
							-- Size = Vector2(44,56),
							-- Location = Vector2(206, 38),
							-- Skin = Gui.ButtonSkin
							-- {
								-- BackgroundImage = Gui.Image("LobbyUI/Compose/lb_fastsettlement_button02_normal.dds", Vector4(0, 0, 0, 0)),
								-- HoverImage = Gui.Image("LobbyUI/Compose/lb_fastsettlement_button02_hover.dds", Vector4(0, 0, 0, 0)),
								-- DownImage = Gui.Image("LobbyUI/Compose/lb_fastsettlement_button02_down.dds", Vector4(0, 0, 0, 0)),
								-- DisabledImage = Gui.Image("LobbyUI/Compose/lb_fastsettlement_button02_disabled.dds", Vector4(0, 0, 0, 0)),
							-- },
							-- EventClick = function()
								-- if discount_data.theItem[Rapid_Shopping_index + 1] then
									-- Rapid_Shopping_index = Rapid_Shopping_index + 1
									-- Rapid_Shopping_Win.name.Text = discount_data.theItem[Rapid_Shopping_index].display
									-- Rapid_Shopping_Win.des.Text = discount_data.theItem[Rapid_Shopping_index].description
									-- -- shop_fast_buy.sid = item_rpc.items[Rapid_Shopping_index].sid
									-- -- price = item_rpc.prices[Rapid_Shopping_index]
									-- Rapid_Shopping_Win_ui.itembox_hummer.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..discount_data.theItem[Rapid_Shopping_index].name..".tga")
									-- Rapid_Shopping_Win_ui.Total_money.Text = discount_data.discounts[Rapid_Shopping_index][discount_index] * discount_data.theItem[Rapid_Shopping_index].crprices[1].cost
								-- end
							-- end,
						-- },
						
						Gui.Button "btn_left"
						{
							Size = Vector2(20,32),
							Location = Vector2(32, 167),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Skin = Gui.ButtonSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_fanye_button_normal_L.dds", Vector4(0, 0, 0, 0)),
								HoverImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_fanye_button_hover_L.dds", Vector4(0, 0, 0, 0)),
								DownImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_fanye_button_down_L.dds", Vector4(0, 0, 0, 0)),
								DisabledImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_fanye_button_disabled_L.dds", Vector4(0, 0, 0, 0)),
							},
							EventClick = function()
								Rapid_Shopping_Win_ui.Tbox_Totle_num.Text = math.ceil(tonumber(Rapid_Shopping_Win_ui.Tbox_Totle_num.Text)) - 1
							end,
						},
						
						Gui.Textbox "Tbox_Totle_num"
						{
							Size = Vector2(154, 34),
							Location = Vector2(61, 166),
							TextColor = ARGB(255, 255, 210, 0),
							DisabledTextColor = ARGB(255, 255, 210, 0),
							FontSize = 24,
							Text = "1",
							BackgroundColor = ARGB(255,255,255,255),
							TextPadding = Vector4(71,0,0,0),
							InputNumberOnly = true,
							Skin = Gui.TextboxSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_04.dds", Vector4(12, 0, 12, 0)),
								ActiveImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_04.dds", Vector4(12, 0, 12, 0)),
								DisabledImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_04.dds", Vector4(12, 0, 12, 0)),
							},
							
							EventTextChanged = function(sender, e)
								if Rapid_Shopping_Win_ui.Tbox_Totle_num.Text ~= "" then
									if math.ceil(tonumber(Rapid_Shopping_Win_ui.Tbox_Totle_num.Text)) > 300 then
										Rapid_Shopping_Win_ui.Tbox_Totle_num.Text = "300"
										return
									elseif math.ceil(tonumber(Rapid_Shopping_Win_ui.Tbox_Totle_num.Text)) < 1 then
										Rapid_Shopping_Win_ui.Tbox_Totle_num.Text = "1"
										return
									end
									if string.sub(Rapid_Shopping_Win_ui.Tbox_Totle_num.Text,1,1) == "0" then
										Rapid_Shopping_Win_ui.Tbox_Totle_num.Text = string.sub(Rapid_Shopping_Win_ui.Tbox_Totle_num.Text,2)
										return
									end
									Rapid_Shopping_Win_ui.Tbox_Totle_num.TextPadding = Vector4(77 - 6*string.len(Rapid_Shopping_Win_ui.Tbox_Totle_num.Text),0,0,0)
								end
								if Rapid_Shopping_Win_ui.btn_left.Visible == false then
									local temp = math.ceil(discount_data.discounts[Rapid_Shopping_index][discount_index] * discount_data.theItem[Rapid_Shopping_index].crprices[1].cost)
									Rapid_Shopping_Win_ui.Total_money.Text = temp-temp%10
								else
									SetHummerTotalMoney()
								end
							end,
							
							EventLeave = function()
								if Rapid_Shopping_Win_ui.Tbox_Totle_num.Text == "" then
									Rapid_Shopping_Win_ui.Tbox_Totle_num.Text = 1
								end
							end,
							
							EventValueNoNumber = function()
								Rapid_Shopping_Win_ui.lab_timer_ctr:Show()
							end,
						},
						
						Gui.Button "btn_right"
						{
							Size = Vector2(20,32),
							Location = Vector2(223, 167),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Skin = Gui.ButtonSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_fanye_button_normal_R.dds", Vector4(0, 0, 0, 0)),
								HoverImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_fanye_button_hover_R.dds", Vector4(0, 0, 0, 0)),
								DownImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_fanye_button_down_R.dds", Vector4(0, 0, 0, 0)),
								DisabledImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_fanye_button_disabled_R.dds", Vector4(0, 0, 0, 0)),
							},
							EventClick = function()
								Rapid_Shopping_Win_ui.Tbox_Totle_num.Text = math.ceil(tonumber(Rapid_Shopping_Win_ui.Tbox_Totle_num.Text)) + 1
							end,
						},
					},
					
					Gui.Label
					{
						Size = Vector2(110, 28),
						Location = Vector2(25, 220),
						TextColor = ARGB(255, 255, 210, 0),
						FontSize = 18,
						TextAlign = "kAlignCenterMiddle",
						Text = lang:GetText("您总共要支付"),
						BackgroundColor = ARGB(0,255,255,255),
						TextPadding = Vector4(0,0,0,3),
					},
					
					Gui.Label "Total_money"
					{
						Size = Vector2(118, 28),
						Location = Vector2(137, 220),
						TextColor = ARGB(255, 255, 210, 0),
						FontSize = 18,
						TextAlign = "kAlignCenterMiddle",
						Text = "0",
						BackgroundColor = ARGB(255,255,255,255),
						TextPadding = Vector4(0,0,0,3),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_03.dds", Vector4(8, 8, 8, 8)),
						},
					},
					
					Gui.Label
					{
						Size = Vector2(80, 28),
						Location = Vector2(257, 220),
						TextColor = ARGB(255, 255, 210, 0),
						FontSize = 18,
						TextAlign = "kAlignLeftMiddle",
						Text = lang:GetText("FC点"),
						BackgroundColor = ARGB(0,255,255,255),
						TextPadding = Vector4(0,0,0,3),
					},
					
					Gui.Label "lab_timer_ctr"
					{
						Size = Vector2(116,35),
						Location = Vector2(100, 207),
						BackgroundColor = ARGB(255, 255, 255, 255),
						TextColor = ARGB(255, 0, 0, 0),
						Visible = false,
						UseTimer = true,
						DisplayTime = 1,
						FontSize = 12,
						TextAlign = "kAlignCenterMiddle",
						Text = lang:GetText("只能输入数字0～9"),
						TextPadding = Vector4(0,8,0,0),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_05.dds", Vector4(37, 18, 14, 12)),
						},
						
						EventClose = function()
							
						end
					},
				},
				
				Gui.Button
				{
					Size = Vector2(124,44),
					Location = Vector2(113, 305),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Text = lang:GetText("购 买"),
					TextColor = ARGB(255, 229, 255, 252),
					TextAlign = "kAlignCenterMiddle",
					HighlightTextColor = ARGB(255, 229, 255, 252),
					Padding = Vector4(0, 0, 0, 5),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_onlinetime_button_2_normal.dds", Vector4(0, 0, 0, 0)),
						HoverImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_onlinetime_button_2_hover.dds", Vector4(0, 0, 0, 0)),
						DownImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_onlinetime_button_2_down.dds", Vector4(0, 0, 0, 0)),
						DisabledImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_onlinetime_button_2_disabled.dds", Vector4(0, 0, 0, 0)),
					},
					EventClick = function()
						if Rapid_Shopping_Win_ui.btn_left.Visible == false then
							if tonumber(Rapid_Shopping_Win_ui.Total_money.Text) > L_LobbyMain.PersonalInfo_data.newCR then
								MessageBox.ShowWithTwoButtons(lang:GetText("你的FC点不足，请充值"),lang:GetText("充值"),lang:GetText("取消"),
																function()
																	gui:ShowIE()
																end,
																nil
																)
							else
								rpc.safecallload("daily_discount_buy_item", {pid = ptr_cast(game.CurrentState):GetCharacterId(), sid = discount_data.theItem[Rapid_Shopping_index].sid, index = discount_index - 1},
								function(data)
									if data.result == 0 then
										MessageBox.ShowWithTimer(1,lang:GetText("购买成功"))
										if Rapid_Shopping_index == 1 then
										print("GoldGoldGoldGold.Gold.Gold.Gold.Gold:",Gold)
											print("main_present_window_ui.baiyin.Textmain_present_window_ui.baiyin.Text:",main_present_window_ui.huangjin.Text)
											main_present_window_ui.huangjin.Text = tostring(tonumber(Gold) + 1).."/1"
											-- main_present_window_ui.gold_key_bg.Text = tonumber(main_present_window_ui.gold_key_bg.Text) + 1
										elseif Rapid_Shopping_index == 2 then
										print("GoldGoldGoldGold.Gold.Gold.Gold.Gold1111:",Silver)
											print("main_present_window_ui.baiyin.Textmain_present_window_ui.baiyin.Text:",main_present_window_ui.baiyin.Text)
											main_present_window_ui.baiyin.Text = tostring(tonumber(Silver) + 1).."/1"
											-- main_present_window_ui.silver_key_bg.Text = tonumber(main_present_window_ui.silver_key_bg.Text) + 1
										end
									end
									update_discount()
								end)
							end
							HideRapidShoppingWin()
						else
							local key_num = 0
							for i = 1,3 do
								if tonumber(key_item[i].ivalue) == present_index then
									key_num = i
									break
								end
							end
							local args = {num = Rapid_Shopping_Win_ui.Tbox_Totle_num.Text, pid = ptr_cast(game.CurrentState):GetCharacterId(), sid = key_item[key_num].sid}
							local keynum = tonumber(Rapid_Shopping_Win_ui.Tbox_Totle_num.Text)
							rpc.safecall("shop_fast_buy", args,
							function(data)
								if data.result == 0 then
									MessageBox.ShowWithTwoButtons(lang:GetText("你的FC点不足，请充值"),lang:GetText("充值"),lang:GetText("取消"),
															function()
																gui:ShowIE()
															end,
															nil
															)
								else
									MessageBox.ShowWithTimer(1,lang:GetText("购买成功"))
									HideRapidShoppingWin()
									if key_num == 1 then
										Cooper = Cooper + keynum
									elseif key_num == 2 then
										Silver = Silver + keynum
									elseif key_num == 3 then
										Gold = Gold + keynum
									end
									main_present_window_ui.qingtong.Text =tostring(Cooper).."/1"
									main_present_window_ui.baiyin.Text =tostring(Silver).."/1"
									main_present_window_ui.huangjin.Text =tostring(Gold).."/1"
									
									-- main_present_window_ui.cooper_key.Text = ""..Cooper
									-- main_present_window_ui.cooper_key_bg.Text = ""..Cooper
									-- main_present_window_ui.silver_key.Text = ""..Silver
									-- main_present_window_ui.silver_key_bg.Text = ""..Silver
									-- main_present_window_ui.gold_key.Text = ""..Gold
									-- main_present_window_ui.gold_key_bg.Text = ""..Gold
								end
							end)
						end
					end,
				},
			},
		},
		
		Gui.ItemBoxBtn"itembox_hummer"
		{
			Style = "Gui.ItemBoxBtn_ib",
			Size = Vector2(153,79),
			Location = Vector2(522,353),--38 10
			--BtnLocation = Vector2(45, 72),
			--BtnText = lang:GetText("购买"),
			--Enable = false,
			BackgroundColor = ARGB(255,255,255,255),
			Skin = Gui.ItemBoxBtnSkin
			{
				NeutralNormalImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_02.dds", Vector4(0, 0, 0, 0)),
				--NeutralHoverImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_02.dds", Vector4(0, 0, 0, 0)),
				NeutralSelectedImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_02.dds", Vector4(0, 0, 0, 0)),
				NeutralDisabledImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_02.dds", Vector4(0, 0, 0, 0)),
			},
			
			--ItemIcon = Gui.Icon("LobbyUI/ibt_icon/machet_4.tga"),
			--Padding = Vector4(10,0,10,0),
			
			--ItemIconPastDue = Gui.Icon("LobbyUI/ShoppingMall/vip_chest/lb_vipgifts_slot_flash.dds"),
	--[[		EventMouseEnter = function(sender, e)
				L_ToolTips.FillToolTipsVIPPresent(1, Rapid_Shopping_Win_ui.Rapid_Shopping_root, magice_hummer_Info)
			end,
			EventToolTipsShow = function(sender, e)
				L_ToolTips.ShowToolTipsShowWindow(sender,Vector2(1200, 900),sender.Location + sender.Parent.Location)
			end,
			EventMouseLeave = function(sender, e)
				L_ToolTips.HideToolTipsWindow()
			end,]]
			
		},
		--退出
		Gui.Button
		{
			Size = Vector2(48,48),
			Location = Vector2(743, 270),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_normal.dds", Vector4(10, 10, 10, 10)),
				HoverImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_hover.dds", Vector4(10, 10, 10, 10)),
				DownImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_down.dds", Vector4(10, 10, 10, 10)),
				DisabledImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_disabled.dds", Vector4(0, 0, 0, 0)),	
			},
			EventClick = function()
				HideRapidShoppingWin()
			end,
		},
	},
}

function ShowRapidShoppingWin()
	if Rapid_Shopping_Win_ui == nil then
		Rapid_Shopping_Win_ui = Gui.Create()(Rapid_Shopping_Win)
		--快速购买界面初始化
		RapidShopping_Window = ModalWindow.GetNew("Rapid_Shopping_Win_ui")
		RapidShopping_Window.screen.AllowEscToExit = false
		RapidShopping_Window.screen.Visible = false
		--RapidShopping_Window.screen.EventEscPressed = HideCharmBottleWin
		RapidShopping_Window.screen.EventEscPressed = nil
		RapidShopping_Window.root.Size = Vector2(1200, 900)
		Rapid_Shopping_Win_ui.Rapid_Shopping_root.Parent = RapidShopping_Window.root
	end
	Rapid_Shopping_Win_ui.des.Size = Vector2(200, 50)
	Rapid_Shopping_Win_ui.des.Location = Vector2(55, 110)
	Rapid_Shopping_Win_ui.des.FontSize = 16
	
	local key_num = 0
	for i = 1,3 do
		print("key_item[i].ivalue"..key_item[i].ivalue)
		print("present_index"..present_index)
		if tonumber(key_item[i].ivalue) == present_index then
			key_num = i
			break
		end
	end
	if key_num <= 0 then
		return
	end
	Rapid_Shopping_Win_ui.Tbox_Totle_num.Enable = true
	Rapid_Shopping_Win_ui.btn_left.Visible = true
	Rapid_Shopping_Win_ui.btn_right.Visible = true
	Rapid_Shopping_Win_ui.des.Text = key_item[key_num].description
	Rapid_Shopping_Win_ui.name.Text = key_item[key_num].display
	if L_Present.RapidShopping_Window and L_Present.RapidShopping_Window.screen then
		L_Present.RapidShopping_Window.screen.Visible = true
		--gui.EventEscPressed = HideCharmBottleWin
		gui.EventEscPressed = nil
	end
	FileHummerItemBox()
end

function ShowRapidDiscount()
	if Rapid_Shopping_Win_ui == nil then
		Rapid_Shopping_Win_ui = Gui.Create()(Rapid_Shopping_Win)
		--快速购买界面初始化
		RapidShopping_Window = ModalWindow.GetNew("Rapid_Shopping_Win_ui")
		RapidShopping_Window.screen.AllowEscToExit = false
		RapidShopping_Window.screen.Visible = false
		--RapidShopping_Window.screen.EventEscPressed = HideCharmBottleWin
		RapidShopping_Window.screen.EventEscPressed = nil
		RapidShopping_Window.root.Size = Vector2(1200, 900)
		Rapid_Shopping_Win_ui.Rapid_Shopping_root.Parent = RapidShopping_Window.root
	end
	Rapid_Shopping_Win_ui.des.Size = Vector2(200, 50)
	Rapid_Shopping_Win_ui.des.Location = Vector2(55, 110)
	Rapid_Shopping_Win_ui.des.FontSize = 16
	
	Rapid_Shopping_Win_ui.des.Text = discount_data.theItem[Rapid_Shopping_index].description
	Rapid_Shopping_Win_ui.name.Text = discount_data.theItem[Rapid_Shopping_index].display
	Rapid_Shopping_Win_ui.itembox_hummer.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..discount_data.theItem[Rapid_Shopping_index].name..".tga")
	Rapid_Shopping_Win_ui.btn_left.Visible = false
	Rapid_Shopping_Win_ui.btn_right.Visible = false
	Rapid_Shopping_Win_ui.Tbox_Totle_num.Text = 1
	Rapid_Shopping_Win_ui.Tbox_Totle_num.Enable = false
	if L_Present.RapidShopping_Window and L_Present.RapidShopping_Window.screen then
		L_Present.RapidShopping_Window.screen.Visible = true
		--gui.EventEscPressed = HideCharmBottleWin
		gui.EventEscPressed = nil
	end
end

function HideRapidShoppingWin()
	if L_Present.RapidShopping_Window and L_Present.RapidShopping_Window.screen then
		L_Present.RapidShopping_Window.screen.Visible = false
		L_Present.Rapid_Shopping_Win_ui = nil
	end
end

function FileHummerItemBox()
	local key_num = 0
	for i = 1,3 do
		if tonumber(key_item[i].ivalue) == present_index then
			key_num = i
			break
		end
	end
	Rapid_Shopping_Win_ui.itembox_hummer.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..key_item[key_num].name..".tga")
	Rapid_Shopping_Win_ui.Tbox_Totle_num.Text = 1
end

function SetHummerTotalMoney()
	if Rapid_Shopping_Win_ui.Tbox_Totle_num.Text == "" then
		Rapid_Shopping_Win_ui.Total_money.Text = "0"
		return
	end
	for i = 1,3 do
		if tonumber(key_item[i].ivalue) == present_index then
			key_num = i
			break
		end
	end
	Rapid_Shopping_Win_ui.Total_money.Text = key_item[key_num].crprices[1].cost * Rapid_Shopping_Win_ui.Tbox_Totle_num.Text / key_item[key_num].crprices[1].unit
end

function InitControl()
	for i = 1, 3 do
		c_present,c_ribbon,c_bowknot= InitChest(i)
		c_bowknot.bowknot.Parent = main_present_window_ui.buy_present_BG
		c_ribbon.present_bottom.Parent = main_present_window_ui.buy_present_BG
		c_present.present.Parent = main_present_window_ui.buy_present_BG
		level_present[i] = c_present
	end
end

function InitGetAll(data)
	print("in InitGetAll")
	local fix = data.fix
	local temp = nil
	g_data = data
	Chip = data.chipNum
	Cooper = data.copperyKeyNum
	Silver = data.silverKeyNum
	Gold = data.goldKeyNum
	-- c_ribbon["bt_buy4_1"].Text = tostring(Chip).."/22"
	-- c_ribbon["bt_buy4_2"].Text = tostring(Chip).."/22"
	-- c_ribbon["bt_buy4_3"].Text = tostring(Chip).."/22"
	-- main_present_window_ui.left_chip.Text = ""..Chip
	-- main_present_window_ui.left_chip_bg.Text = ""..Chip
	-- main_present_window_ui.cooper_key.Text = ""..Cooper
	-- main_present_window_ui.cooper_key_bg.Text = ""..Cooper
	-- main_present_window_ui.silver_key.Text = ""..Silver
	-- main_present_window_ui.silver_key_bg.Text = ""..Silver
	-- main_present_window_ui.gold_key.Text = ""..Gold
	-- main_present_window_ui.gold_key_bg.Text = ""..Gold
	main_present_window_ui.xunzhang.Text =tostring(Chip).."/8"
	main_present_window_ui.xunzhang1.Text =tostring(Chip).."/15"
	main_present_window_ui.xunzhang2.Text =tostring(Chip).."/22"
	main_present_window_ui.qingtong.Text = tostring(Cooper).."/1"
	main_present_window_ui.baiyin.Text = tostring(Silver).."/1"
	main_present_window_ui.huangjin.Text = tostring(Gold).."/1"
	key_item = g_data.luckyPackages
	
	for i = 1, 3 do
		c_present,c_ribbon,c_bowknot= InitChest(i)
		for j = 1, 3 do
			if i == g_data.fix[j].level then
				c_ribbon.present_fc.Text = g_data.fix[j].payFC
				c_ribbon.present_chip.Text = g_data.fix[j].payChip
				break
			end
		end
		c_bowknot.bowknot.Parent = main_present_window_ui.buy_present_BG
		c_ribbon.present_bottom.Parent = main_present_window_ui.buy_present_BG
		c_present.present.Parent = main_present_window_ui.buy_present_BG
		level_present[i] = c_present
	end
	main_present_window_ui.Timer:StartAnimation()
	FillRandImage(1,1)
	FillRandImage(2,1)
	FillRandImage(3,1)
end

function key_name(index)
	local keyname = nil
	if index == 1 then
		keyname = lang:GetText("青铜卡")
	elseif index == 2 then
		keyname = lang:GetText("白银卡")
	elseif index == 3 then
		keyname = lang:GetText("黄金卡")
	end
	return keyname
end

function update_discount()
	rpc.safecallload("daily_discount_item", {pid = ptr_cast(game.CurrentState):GetCharacterId()},
	function(data)
		if data.error == nil then
			discount_data = data
			Rapid_Shopping_index = 1
			for i = 1, 3 do
				main_present_window_ui["text1"..i].Text = (data.discounts[Rapid_Shopping_index][i] * 10)..lang:GetText("折")
				main_present_window_ui["text2"..i].Text = (tonumber(data.theItem[Rapid_Shopping_index].crprices[1].cost) * tonumber(data.discounts[Rapid_Shopping_index][i])).."FC"
				main_present_window_ui["text3"..i].Text = data.theItem[Rapid_Shopping_index].crprices[1].cost.."FC"
				main_present_window_ui["icon"..i].ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..data.theItem[Rapid_Shopping_index].name..".tga")
				if data.flag[Rapid_Shopping_index][i] == 0 then
					main_present_window_ui["btn"..i].Enable = true
				else
					main_present_window_ui["btn"..i].Enable = false
				end
				main_present_window_ui["sellout"..i].Visible = not main_present_window_ui["btn"..i].Enable
			end
			Rapid_Shopping_index = 2
			for i = 4, 6 do
				main_present_window_ui["text1"..i].Text = (data.discounts[Rapid_Shopping_index][i-3] * 10)..lang:GetText("折")
				main_present_window_ui["text2"..i].Text = (tonumber(data.theItem[Rapid_Shopping_index].crprices[1].cost) * tonumber(data.discounts[Rapid_Shopping_index][i-3])).."FC"
				main_present_window_ui["text3"..i].Text = data.theItem[Rapid_Shopping_index].crprices[1].cost.."FC"
				main_present_window_ui["icon"..i].ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..data.theItem[Rapid_Shopping_index].name..".tga")
				if data.flag[Rapid_Shopping_index][i-3] == 0 then
					main_present_window_ui["btn"..i].Enable = true
				else
					main_present_window_ui["btn"..i].Enable = false
				end
				main_present_window_ui["sellout"..i].Visible = not main_present_window_ui["btn"..i].Enable
			end
		else
			MessageBox.ShowWithConfirm(data.error)
		end
	end)
end

function Initialize()
	main_present_window_ui = Gui.Create(root_ui)(main_present_window)
	InitPresent()
	Init_Pintu()
	InitControl()
	InitTiger()
	Logic()
end

function FillNumber(control,number,width,height)
	control:OnDestroy()
	L_Characters.CreatPresentNumCtr(control,number,width,height)
	--[[local temp,bit = 0,0
	local Size = control.Size
	local x,y = Size.x,Size.y
	local realNumbier = {}
	y = y - 22
	temp = number
	
	while temp > 0 do
		bit = bit + 1
		realNumbier[bit] = temp % 10
		temp = temp / 10
		temp = math.floor(temp)
	end
	
	for i = 1, bit do 
		local num = realNumbier[bit - i + 1]
		local numlabel = Gui.Create()
					{
						Gui.Control "num"
						{
							Size = Vector2(20,16),
							BackgroundColor = ARGB(255, 255, 255, 255),
						},
					}
		
		numlabel.num.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_number.dds", Vector4(0,0,0,0),Vector4((num)/10.0 , 0, (num + 1)/10.0,1)),}
		numlabel.num.Location = Vector2(x - 12*(bit - i + 1) -10,y)
		numlabel.num.Parent = control
	end
	
	if bit > 0 then
		local Xlabel = Gui.Create()
						{
							Gui.Control "X"
							{
								Size = Vector2(20,16),
								BackgroundColor = ARGB(255, 255, 255, 255),
							},
						}
		Xlabel.X.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_number_X.dds", Vector4(0,0,0,0)),}
		Xlabel.X.Location = Vector2(x - 12*(bit + 1)-12,y)
		Xlabel.X.Parent = control
	end]]
end

--稀有物品查看奖励界面头函数
local Rare_Present_Win_ui = nil
local Rare_Present_Win_Window = nil
local Rare_List = {}

function UpDataRare_List(type)
	if Rare_Present_Win_ui ~= nil and Rare_Present_Win_ui.Ctr_Rare_List ~= nil then
		local ibbtn = ptr_cast(Rare_Present_Win_ui.Ctr_Rare_List:GetChildByIndex(type - 1))
		local ibbtn_child
		local index = 1
		while index < 8  do
			ibbtn_child = ptr_cast(ibbtn:GetChildByIndex(index - 1))
			ibbtn_child.ItemIcon = nil
			ibbtn_child.ItemLevel = nil
			index = index + 1
		end
		index = 1
		while Rare_List[type].random[index] and index < 8 do
			ibbtn_child = ptr_cast(ibbtn:GetChildByIndex(index - 1))
			if type == 1 then
				ibbtn_child.Padding = Vector4(-10,-10,-10,-10)
			end
			ibbtn_child.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..Rare_List[type].random[index].name..".tga")
			if Rare_List[type].random[index].common and Rare_List[type].random[index].common.rareLevel then
				ibbtn_child.ItemLevel = Skin.rarelevel[math.ceil(Rare_List[type].random[index].common.rareLevel/25)]
			end
			index = index + 1
		end
		ibbtn_child = ptr_cast(ibbtn:GetChildByIndex(7))
		ibbtn_child.Text = (Rare_List[type].pageNo + 1).."/"..Rare_List[type].pageCount
		ibbtn_child = ptr_cast(ibbtn:GetChildByIndex(8))
		ibbtn_child.Text = (Rare_List[type].pageNo + 1).."/"..Rare_List[type].pageCount
	end
end

function GetRare_Present(type,page,is_new)
	local args = {page = page,type = type}
	rpc.safecall("pintu_awards", args,
	function(data)		
		if data then
			Rare_List[type] = data
			if is_new == false then
				UpDataRare_List(type)
			end
			if is_new and type < 4 then
				GetRare_Present(type + 1,page,is_new)
			end
			if is_new and type == 4 then
				ShowRare_Present_Win()
			end
		end
	end)
end

function CreateRarePresentItem(index,Type)
	return Gui.ItemBoxBtn
	{
		Style = "Gui.ItemBoxBtn_ib",
		Size = Vector2(78,78),
		Location = Vector2(46 + 79 * (index - 1),67),
		BackgroundColor = ARGB(255, 255, 255, 255),
		--BtnLocation = Vector2(45, 72),
		--BtnText = lang:GetText("购买"),
		--BtnVisible = true,
		--BtnLocation = Vector2(10, 10),
		--Enable = false,
		Padding = Vector4(-3,-3,-3,-3),
		Skin = Gui.ItemBoxBtnSkin
		{
			NeutralNormalImage = Gui.Image("LobbyUI/WarZone/Present/lb_gift_biew_bg2.dds", Vector4(0, 0, 0, 0)),
--			NeutralHoverImage = Gui.Image("LobbyUI/ShoppingMall/vip_chest/lb_vipgifts_slot_flash.dds", Vector4(0, 0, 0, 0)),
			NeutralSelectedImage = Gui.Image("LobbyUI/WarZone/Present/lb_gift_biew_bg2.dds", Vector4(0, 0, 0, 0)),
			NeutralDisabledImage = Gui.Image("LobbyUI/WarZone/Present/lb_gift_biew_bg2.dds", Vector4(0, 0, 0, 0)),
		},
		
		--ItemIcon = Gui.Icon("LobbyUI/ibt_icon/magic_4.tga"),
		--Padding = Vector4(1,1,1,1),
		
		--ItemIconPastDue = Gui.Icon("LobbyUI/ShoppingMall/vip_chest/lb_vipgifts_slot_flash.dds"),
		EventMouseEnter = function(sender, e)
			L_ToolTips.FillToolBigPresentWindow(index, Rare_Present_Win_ui.Rare_Present_root, Rare_List[Type].random)
		end,
		EventToolTipsShow = function(sender, e)
			if Rare_List[Type].random[index] then
				local loc = sender.Location + sender.Parent.Location + sender.Parent.Parent.Location + sender.Parent.Parent.Parent.Location
				L_ToolTips.ShowToolTipsShowWindow(sender,Vector2(1200, 900), loc)
			end
		end,
		EventMouseLeave = function(sender, e)
			L_ToolTips.HideToolTipsWindow()
		end,
	}
end

function CreateRarePresentType(name,Type)
	return Gui.Control
			{
				Size = Vector2(565+79, 176),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Location = Vector2(17, 80 + (Type - 1) * 181),
				
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/WarZone/Present/ib_gift_blockbox_bg_04.dds", Vector4(327,72,125,25)),
				},
				
				CreateRarePresentItem(1,Type),
				CreateRarePresentItem(2,Type),
				CreateRarePresentItem(3,Type),
				CreateRarePresentItem(4,Type),
				CreateRarePresentItem(5,Type),
				CreateRarePresentItem(6,Type),
				CreateRarePresentItem(7,Type),
				
				Gui.Label
				{
					Size = Vector2(80, 30),
					Location = Vector2(470+79, 8),
					BackgroundColor = ARGB(0,255,255,255),
					Text = "1/1",
					Padding = Vector4(0 ,0 ,0 ,5),
					FontSize = 18,
					TextAlign = "kAlignRightMiddle",
					TextColor = ARGB(255,0,0,0),
				},
				
				Gui.Label
				{
					Size = Vector2(80, 30),
					Location = Vector2(470+79, 7),
					BackgroundColor = ARGB(0,255,255,255),
					Text = "1/1",
					Padding = Vector4(0 ,0 ,0 ,5),
					FontSize = 18,
					TextAlign = "kAlignRightMiddle",
					TextColor = ARGB(255,254,169,85),
				},
				
				Gui.Label
				{
					Size = Vector2(300, 30),
					Location = Vector2(15, 8),
					BackgroundColor = ARGB(0,255,255,255),
					Text = name,
					Padding = Vector4(0 ,0 ,0 ,5),
					FontSize = 20,
					TextAlign = "kAlignLeftMiddle",
					TextColor = ARGB(255,165,55,0),
				},
				
				Gui.Label
				{
					Size = Vector2(300, 30),
					Location = Vector2(14, 7),
					BackgroundColor = ARGB(0,255,255,255),
					Text = name,
					Padding = Vector4(0 ,0 ,0 ,5),
					FontSize = 20,
					TextAlign = "kAlignLeftMiddle",
					TextColor = ARGB(255,0,0,0),
				},
					
				Gui.Button
				{
					Size = Vector2(44,56),
					Location = Vector2(11, 78),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/Compose/lb_fastsettlement_button03_normal.dds", Vector4(0, 0, 0, 0)),
						HoverImage = Gui.Image("LobbyUI/Compose/lb_fastsettlement_button03_hover.dds", Vector4(0, 0, 0, 0)),
						DownImage = Gui.Image("LobbyUI/Compose/lb_fastsettlement_button03_down.dds", Vector4(0, 0, 0, 0)),
						DisabledImage = Gui.Image("LobbyUI/Compose/lb_fastsettlement_button03_disabled.dds", Vector4(0, 0, 0, 0)),
					},
					EventClick = function()
						if Rare_List[Type].pageNo > 0 then
							GetRare_Present(Type,Rare_List[Type].pageNo - 1,false)
						end
					end,
				},
				
				Gui.Button
				{
					Size = Vector2(44,56),
					Location = Vector2(511+79, 78),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/Compose/lb_fastsettlement_button02_normal.dds", Vector4(0, 0, 0, 0)),
						HoverImage = Gui.Image("LobbyUI/Compose/lb_fastsettlement_button02_hover.dds", Vector4(0, 0, 0, 0)),
						DownImage = Gui.Image("LobbyUI/Compose/lb_fastsettlement_button02_down.dds", Vector4(0, 0, 0, 0)),
						DisabledImage = Gui.Image("LobbyUI/Compose/lb_fastsettlement_button02_disabled.dds", Vector4(0, 0, 0, 0)),
					},
					EventClick = function()
						if Rare_List[Type].pageNo < (Rare_List[Type].pageCount - 1) then
							GetRare_Present(Type,Rare_List[Type].pageNo + 1,false)
						end
					end,
				},
			}
end
--稀有物品查看界面
local Rare_Present_Win = 
{
	Gui.Control "Rare_Present_root"
	{	
		Size = Vector2(1200, 900),
		BackgroundColor = ARGB(0, 255, 255, 255),
		Location = Vector2(0, 0),
		
		Gui.Control
		{	
			Size = Vector2(632+79, 884),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Dock = "kDockCenter",
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_contact_bg1_01.dds", Vector4(163,163,53,53)),
			},

			Gui.Control "Ctr_Rare_List"
			{	
				Size = Vector2(596+79, 831),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Location = Vector2(17, 23),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/WarZone/Present/lb_gift_biew_bg1.dds", Vector4(195,104,85,60)),
				},
				CreateRarePresentType(lang:GetText("武器"),1),
				CreateRarePresentType(lang:GetText("服装"),2),
				CreateRarePresentType(lang:GetText("帽子"),3),
				CreateRarePresentType(lang:GetText("配饰"),4),
			},
			
			--奖励图片
			Gui.Control
			{
				Size = Vector2(513,50),
				Location = Vector2(60+40, 15),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/WarZone/Present/lb_gift_biew_title.dds", Vector4(0,0,0,0)),
				},
			},
			
			Gui.Label
			{
				Size = Vector2(632+79, 40),
				Location = Vector2(1, 66),
				BackgroundColor = ARGB(255,255,255,255),
				Text = lang:GetText("完成神秘拼图可选择获得以下奖品之一"),
				Padding = Vector4(0 ,0 ,0 ,10),
				FontSize = 20,
				TextAlign = "kAlignCenterMiddle",
				TextColor = ARGB(255,0,0,0),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/GameBalance/ig_bo2_reward_title_01.dds", Vector4(0,0,0,0)),
				},
			},
			
			Gui.Label
			{
				Size = Vector2(632+79, 40),
				Location = Vector2(0, 65),
				BackgroundColor = ARGB(0,255,255,255),
				Text = lang:GetText("完成神秘拼图可选择获得以下奖品之一"),
				Padding = Vector4(0 ,0 ,0 ,10),
				FontSize = 20,
				TextAlign = "kAlignCenterMiddle",
				TextColor = ARGB(255,255,182,0),
			},
			--退出
			Gui.Button
			{
				Size = Vector2(48,48),
				Location = Vector2(580+79, 5),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_normal.dds", Vector4(10, 10, 10, 10)),
					HoverImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_hover.dds", Vector4(10, 10, 10, 10)),
					DownImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_down.dds", Vector4(10, 10, 10, 10)),
					DisabledImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_disabled.dds", Vector4(0, 0, 0, 0)),	
				},
				EventClick = function()
					HideRare_Present_Win()
				end,
			},
		},
	},
}

function ShowRare_Present_Win()
	if Rare_Present_Win_ui == nil then
		Rare_Present_Win_ui = Gui.Create()(Rare_Present_Win)
		--稀有物品查看界面初始化
		Rare_Present_Win_Window = ModalWindow.GetNew("Rare_Present_Win_ui")
		Rare_Present_Win_Window.screen.AllowEscToExit = false
		Rare_Present_Win_Window.screen.Visible = false
		--Rare_Present_Win_Window.screen.EventEscPressed = HideCharmBottleWin
		Rare_Present_Win_Window.screen.EventEscPressed = nil
		Rare_Present_Win_Window.root.Size = Vector2(1200, 900)
		Rare_Present_Win_ui.Rare_Present_root.Parent = Rare_Present_Win_Window.root
	end
	UpDataRare_List(1)
	UpDataRare_List(2)
	UpDataRare_List(3)
	UpDataRare_List(4)
	if Rare_Present_Win_Window and Rare_Present_Win_Window.screen then
		Rare_Present_Win_Window.screen.Visible = true
		--gui.EventEscPressed = HideCharmBottleWin
		gui.EventEscPressed = nil
	end
end

function HideRare_Present_Win()
	if Rare_Present_Win_Window and Rare_Present_Win_Window.screen then
		Rare_Present_Win_Window.screen.Visible = false
		Rare_Present_Win_Window:Close()
		Rare_Present_Win_ui = nil
	end
end

--稀有物品获得列表头函数
local Rare_List_ui = nil
local Rare_List_Window = nil
function Create_Rare_Type(name,type,iS_Client)
	return Gui.Control
			{
				Size = Vector2(133, 168),
				Location = Vector2(48 + (type - 1)*133, 160),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_rank_bg_01.dds", Vector4(34, 34, 34, 34)),
				},
				
				Gui.Label
				{
					Size = Vector2(131, 30),
					Location = Vector2(1, 4),
					Text = name,
					FontSize = 24,
					TextColor = ARGB(255, 255, 201, 0),
					TextAlign = "kAlignCenterMiddle",
				},							
				
				Gui.Control
				{
					Size = Vector2(128, 100),
					Location = Vector2(2, 30),
					BackgroundColor = ARGB(255, 255, 255, 255),
					
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/Compose/lb_melting_slot_0"..(type + 1)..".dds", Vector4(0, 0, 0, 0)),
					},
				},
				
				Gui.Button
				{
					Size = Vector2(121,36),
					Location = Vector2(6, 128),
					BackgroundColor = ARGB(255, 255, 255, 255),
					TextColor = ARGB(255, 0, 0, 0),
					Padding = Vector4(0, 0, 0, 5),
					FontSize = 16,
					TextAlign = "kAlignCenterMiddle",
					HighlightTextColor = ARGB(255, 0, 0, 0),
					Text = lang:GetText("领取"),
					Enable = iS_Client,
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_v2_01_normal.dds", Vector4(26, 0, 20, 0)),
						HoverImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_v2_01_hover.dds", Vector4(26, 0, 20, 0)),
						DownImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_v2_01_down.dds", Vector4(26, 0, 20, 0)),
						DisabledImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_v2_01_disabled.dds", Vector4(26, 0, 20, 0)),
					},	
					EventClick = function()
						HideRare_List_Win()
						local args = {pid = ptr_cast(game.CurrentState):GetCharacterId(), type = type}
						rpc.safecall("pintu_gift",args,function(data)
															if data then
																InitPintu(data)
																L_Compose.Melting_get(data.misticAward)
															end
														end)
					end,
				},
			}
end
--稀有物品获得列表
local Rare_List = 
{
	Gui.Control "Rare_List_root"
	{
		Size = Vector2(628, 405),
		Dock = "kDockCenter",
		BackgroundColor = ARGB(255, 255, 255, 255),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_success.dds", Vector4(100, 174, 105, 100)),
		},
		Gui.Label
		{
			Size = Vector2(628, 60),
			Location = Vector2(1, 97),
			Text = lang:GetText("完成神秘拼图可\n选择获得以下奖品之一"),
			FontSize = 18,
			TextColor = ARGB(255, 0, 0, 0),
			TextAlign = "kAlignCenterMiddle",
		},
		Gui.Label
		{
			Size = Vector2(628, 60),
			Location = Vector2(1, 96),
			Text = lang:GetText("完成神秘拼图可\n选择获得以下奖品之一"),
			FontSize = 18,
			TextColor = ARGB(255, 255, 210, 0),
			TextAlign = "kAlignCenterMiddle",
		},
		Create_Rare_Type(lang:GetText("武器"),1,true),
		Create_Rare_Type(lang:GetText("服装"),2,true),
		Create_Rare_Type(lang:GetText("帽子"),3,true),
		Create_Rare_Type(lang:GetText("配饰"),4,true),
		Gui.Label
		{
			Size = Vector2(628, 22),
			Location = Vector2(1, 333),
			BackgroundColor = ARGB(0, 255, 255, 255),
			Text = lang:GetText("只能选择其中一个，请慎重考虑哦~"),
			FontSize = 18,
			TextColor = ARGB(255, 0, 0, 0),
			TextAlign = "kAlignCenterMiddle",
		},
		Gui.Label
		{
			Size = Vector2(628, 22),
			Location = Vector2(0, 332),
			BackgroundColor = ARGB(0, 255, 255, 255),
			Text = lang:GetText("只能选择其中一个，请慎重考虑哦~"),
			FontSize = 18,
			TextColor = ARGB(255, 255, 210, 0),
			TextAlign = "kAlignCenterMiddle",
		},
		
		Gui.Button
		{
			Size = Vector2(177,38),
			Location = Vector2(245, 355),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Text = lang:GetText("关闭"),
			TextColor = ARGB(255, 229, 255, 252),
			TextAlign = "kAlignCenterMiddle",
			HighlightTextColor = ARGB(255, 229, 255, 252),
			
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_normal.dds", Vector4(15, 0, 15, 0)),
				HoverImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_hover.dds", Vector4(15, 0, 15, 0)),
				DownImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_down.dds", Vector4(15, 0, 15, 0)),
				DisabledImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_disabled.dds", Vector4(15, 0, 15, 0)),
			},
			
			EventClick = function(Sender ,e)				
				HideRare_List_Win()
			end,
		},
	},
}

function ShowRare_List_Win()
	if Rare_List_ui == nil then
		Rare_List_ui = Gui.Create()(Rare_List)
		--稀有物品查看界面初始化
		Rare_List_Window = ModalWindow.GetNew("Rare_List_ui")
		Rare_List_Window.screen.AllowEscToExit = false
		Rare_List_Window.screen.Visible = false
		--Rare_List_Window.screen.EventEscPressed = HideCharmBottleWin
		Rare_List_Window.screen.EventEscPressed = nil
		Rare_List_Window.root.Size = Vector2(1200, 900)
		Rare_List_ui.Rare_List_root.Parent = Rare_List_Window.root
	end	
	if Rare_List_Window and Rare_List_Window.screen then
		Rare_List_Window.screen.Visible = true
		--gui.EventEscPressed = HideCharmBottleWin
		gui.EventEscPressed = nil
	end
end

function HideRare_List_Win()
	if Rare_List_Window and Rare_List_Window.screen then
		Rare_List_Window.screen.Visible = false
		Rare_List_Window:Close()
		Rare_List_ui = nil
	end
end

function InitQuickSell()
	if config:GetUISystemFlag(1) == 0 then
		if main_present_window_ui then
			main_present_window_ui.time_sell_btn.Visible = false
		end	
	else
		if main_present_window_ui then
			main_present_window_ui.time_sell_btn.Visible = true
			main_present_window_ui.time_sell_btn.blink = L_LobbyMain.Sell_flag 
		end
	end
end

function Show(parent_win)
	print("=================L_Characters Show()")
	L_LobbyMain.HideAll()
	L_LobbyMain.current_chosse_main_page = 22
	root_ui = parent_win
	local args = {pid = ptr_cast(game.CurrentState):GetCharacterId()}
	-- if g_data == nil then	
		rpc.safecallload("chest_price",args,InitGetAll)
	-- else
		-- rpc.safecall("chest_chip", args,
		-- function(data)
			-- main_present_window_ui.left_chip.Text = ""..data.chipNum
			-- main_present_window_ui.left_chip_bg.Text = ""..data.chipNum
			-- Chip = data.chipNum
		-- end)
	-- end
	
	main_present_window_ui.ctrl_main_present_window.Parent = root_ui	
	update_discount()
	InitQuickSell()
end

function Hide()
	if main_present_window_ui then
		main_present_window_ui.ctrl_main_present_window.Parent = nil
	end
	
	-- if buy_gift_window then
		-- buy_gift_window:Close()
	-- end
	
	if view_present_window then
		view_present_window:Close()
	end
	
	MessageBox.CloseWaiter()
end

function Finalize()
	print("=================L_PersonalInfo Finalize()")
	Hide()
end