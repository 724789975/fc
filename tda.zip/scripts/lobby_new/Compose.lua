module("L_Compose", package.seeall)

local font_color = 
{
	ARGB(255, 160, 0, 220), 
	ARGB(255, 5, 0, 199), 
	ARGB(255, 0, 139, 179), 
	ARGB(255, 0, 137, 52), 
	ARGB(255, 224, 68, 0), 
	ARGB(255, 181, 0, 0), 
	ARGB(255, 255, 0, 0), 
	ARGB(255, 37, 37, 37), --default color
}

local compareIcon2 =
{
						Gui.CompareIcon(L_ToolTips.ci_bg_path, L_ToolTips.ci_fg_path, L_ToolTips.ci_fg_path, L_ToolTips.ci_fg_minus_path, L_ToolTips.ci_bg_border, L_ToolTips.ci_fg_border),
						Gui.CompareIcon(L_ToolTips.ci_bg_path, L_ToolTips.ci_fg_path4, L_ToolTips.ci_fg_path4, L_ToolTips.ci_fg_minus_path, L_ToolTips.ci_bg_border, L_ToolTips.ci_fg_border),
						Gui.CompareIcon(L_ToolTips.ci_bg_path, L_ToolTips.ci_fg_path7, L_ToolTips.ci_fg_path7, L_ToolTips.ci_fg_minus_path, L_ToolTips.ci_bg_border, L_ToolTips.ci_fg_border),
						Gui.CompareIcon(L_ToolTips.ci_bg_path, L_ToolTips.ci_fg_path10, L_ToolTips.ci_fg_path10, L_ToolTips.ci_fg_minus_path, L_ToolTips.ci_bg_border, L_ToolTips.ci_fg_border),
						Gui.CompareIcon(L_ToolTips.ci_bg_path, L_ToolTips.ci_fg_path12, L_ToolTips.ci_fg_path12, L_ToolTips.ci_fg_minus_path, L_ToolTips.ci_bg_border, L_ToolTips.ci_fg_border),
						Gui.CompareIcon(L_ToolTips.ci_bg_path, L_ToolTips.ci_fg_path14, L_ToolTips.ci_fg_path14, L_ToolTips.ci_fg_minus_path, L_ToolTips.ci_bg_border, L_ToolTips.ci_fg_border),
						Gui.CompareIcon(L_ToolTips.ci_bg_path, L_ToolTips.ci_fg_path15, L_ToolTips.ci_fg_path15, L_ToolTips.ci_fg_minus_path, L_ToolTips.ci_bg_border, L_ToolTips.ci_fg_border),

						Gui.CompareIcon(L_ToolTips.ci_bg_path, L_ToolTips.ci_fg_path, L_ToolTips.ci_fg_path, L_ToolTips.ci_fg_minus_path, L_ToolTips.ci_bg_border, L_ToolTips.ci_fg_border),
						Gui.CompareIcon(L_ToolTips.ci_bg_path, L_ToolTips.ci_fg_path4, L_ToolTips.ci_fg_path4, L_ToolTips.ci_fg_minus_path, L_ToolTips.ci_bg_border, L_ToolTips.ci_fg_border),
						Gui.CompareIcon(L_ToolTips.ci_bg_path, L_ToolTips.ci_fg_path7, L_ToolTips.ci_fg_path7, L_ToolTips.ci_fg_minus_path, L_ToolTips.ci_bg_border, L_ToolTips.ci_fg_border),
						Gui.CompareIcon(L_ToolTips.ci_bg_path, L_ToolTips.ci_fg_path10, L_ToolTips.ci_fg_path10, L_ToolTips.ci_fg_minus_path, L_ToolTips.ci_bg_border, L_ToolTips.ci_fg_border),
						Gui.CompareIcon(L_ToolTips.ci_bg_path, L_ToolTips.ci_fg_path12, L_ToolTips.ci_fg_path12, L_ToolTips.ci_fg_minus_path, L_ToolTips.ci_bg_border, L_ToolTips.ci_fg_border),
						Gui.CompareIcon(L_ToolTips.ci_bg_path, L_ToolTips.ci_fg_path14, L_ToolTips.ci_fg_path14, L_ToolTips.ci_fg_minus_path, L_ToolTips.ci_bg_border, L_ToolTips.ci_fg_border),
						Gui.CompareIcon(L_ToolTips.ci_bg_path, L_ToolTips.ci_fg_path15, L_ToolTips.ci_fg_path15, L_ToolTips.ci_fg_minus_path, L_ToolTips.ci_bg_border, L_ToolTips.ci_fg_border),

						Gui.CompareIcon(L_ToolTips.ci_bg_path, L_ToolTips.ci_fg_path, L_ToolTips.ci_fg_path, L_ToolTips.ci_fg_minus_path, L_ToolTips.ci_bg_border, L_ToolTips.ci_fg_border),
						Gui.CompareIcon(L_ToolTips.ci_bg_path, L_ToolTips.ci_fg_path4, L_ToolTips.ci_fg_path4, L_ToolTips.ci_fg_minus_path, L_ToolTips.ci_bg_border, L_ToolTips.ci_fg_border),
						Gui.CompareIcon(L_ToolTips.ci_bg_path, L_ToolTips.ci_fg_path7, L_ToolTips.ci_fg_path7, L_ToolTips.ci_fg_minus_path, L_ToolTips.ci_bg_border, L_ToolTips.ci_fg_border),
						Gui.CompareIcon(L_ToolTips.ci_bg_path, L_ToolTips.ci_fg_path10, L_ToolTips.ci_fg_path10, L_ToolTips.ci_fg_minus_path, L_ToolTips.ci_bg_border, L_ToolTips.ci_fg_border),
						Gui.CompareIcon(L_ToolTips.ci_bg_path, L_ToolTips.ci_fg_path12, L_ToolTips.ci_fg_path12, L_ToolTips.ci_fg_minus_path, L_ToolTips.ci_bg_border, L_ToolTips.ci_fg_border),
						Gui.CompareIcon(L_ToolTips.ci_bg_path, L_ToolTips.ci_fg_path14, L_ToolTips.ci_fg_path14, L_ToolTips.ci_fg_minus_path, L_ToolTips.ci_bg_border, L_ToolTips.ci_fg_border),
						Gui.CompareIcon(L_ToolTips.ci_bg_path, L_ToolTips.ci_fg_path15, L_ToolTips.ci_fg_path15, L_ToolTips.ci_fg_minus_path, L_ToolTips.ci_bg_border, L_ToolTips.ci_fg_border),

						Gui.CompareIcon(L_ToolTips.ci_bg_path, L_ToolTips.ci_fg_path, L_ToolTips.ci_fg_path, L_ToolTips.ci_fg_minus_path, L_ToolTips.ci_bg_border, L_ToolTips.ci_fg_border),
						Gui.CompareIcon(L_ToolTips.ci_bg_path, L_ToolTips.ci_fg_path4, L_ToolTips.ci_fg_path4, L_ToolTips.ci_fg_minus_path, L_ToolTips.ci_bg_border, L_ToolTips.ci_fg_border),
						Gui.CompareIcon(L_ToolTips.ci_bg_path, L_ToolTips.ci_fg_path7, L_ToolTips.ci_fg_path7, L_ToolTips.ci_fg_minus_path, L_ToolTips.ci_bg_border, L_ToolTips.ci_fg_border),
						Gui.CompareIcon(L_ToolTips.ci_bg_path, L_ToolTips.ci_fg_path10, L_ToolTips.ci_fg_path10, L_ToolTips.ci_fg_minus_path, L_ToolTips.ci_bg_border, L_ToolTips.ci_fg_border),
						Gui.CompareIcon(L_ToolTips.ci_bg_path, L_ToolTips.ci_fg_path12, L_ToolTips.ci_fg_path12, L_ToolTips.ci_fg_minus_path, L_ToolTips.ci_bg_border, L_ToolTips.ci_fg_border),
						Gui.CompareIcon(L_ToolTips.ci_bg_path, L_ToolTips.ci_fg_path14, L_ToolTips.ci_fg_path14, L_ToolTips.ci_fg_minus_path, L_ToolTips.ci_bg_border, L_ToolTips.ci_fg_border),
						Gui.CompareIcon(L_ToolTips.ci_bg_path, L_ToolTips.ci_fg_path15, L_ToolTips.ci_fg_path15, L_ToolTips.ci_fg_minus_path, L_ToolTips.ci_bg_border, L_ToolTips.ci_fg_border),
					}

local ItemBoxBtn_Compose_a = Gui.ItemBoxBtnSkin
{
	NeutralNormalImage = Gui.Image("LobbyUI/Compose/lb_synthesis_mosaic_ico_01.dds", Vector4(0, 0, 0, 0)),
	NeutralHoverImage = nil,
	NeutralSelectedImage = Gui.Image("LobbyUI/Compose/lb_synthesis_mosaic_ico_01.dds", Vector4(0, 0, 0, 0)),
	NeutralDisabledImage = Gui.Image("LobbyUI/Compose/lb_synthesis_mosaic_ico_01.dds", Vector4(0, 0, 0, 0)),
	NeutralHighlightImage = nil,
}

local ItemBoxBtn_Compose_b = Gui.ItemBoxBtnSkin
{
	NeutralNormalImage = Gui.Image("LobbyUI/Compose/lb_synthesis_mosaic_ico_01_disabled.dds", Vector4(0, 0, 0, 0)),
	NeutralHoverImage = nil,
	NeutralSelectedImage = Gui.Image("LobbyUI/Compose/lb_synthesis_mosaic_ico_01_disabled.dds", Vector4(0, 0, 0, 0)),
	NeutralDisabledImage = Gui.Image("LobbyUI/Compose/lb_synthesis_mosaic_ico_01_disabled.dds", Vector4(0, 0, 0, 0)),
	NeutralHighlightImage = nil,
}

local ItemBoxBtn_Compose_c = Gui.ItemBoxBtnSkin
{
	NeutralNormalImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_slot_disabled.dds", Vector4(0, 0, 0, 0)),
	NeutralHoverImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_slot_flash_1.dds", Vector4(0, 0, 0, 0)),
	NeutralSelectedImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_slot_disabled.dds", Vector4(0, 0, 0, 0)),
	NeutralDisabledImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_slot_disabled.dds", Vector4(0, 0, 0, 0)),
	NeutralHighlightImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_slot_flash_1.dds", Vector4(0, 0, 0, 0)),
}

function create_star()
	return Gui.Control
	{
		Size = Vector2(16, 16),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/ToolTips/little_star.dds", Vector4(0, 0, 0, 0)),
		},
	}
end

function create_formula_sucai(index)
	return Gui.Control ("formula_sucai"..index)
	{
		Size = Vector2(310, 36),
		Location = Vector2(10, 121+index*38),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/ToolTips/lb_tooltips_bg_2.dds",Vector4(8, 8, 8, 8)),
		},
		
		Gui.ItemBoxBtn ("formula_sucai_resource"..index)
		{
			Size = Vector2(36, 36),
			Location = Vector2(5, 0),
			BackgroundColor = ARGB(0, 255, 255, 255),
			Empty = false,
			Type = 1,
			CanSelect = false,
			Skin = Gui.ItemBoxBtnSkin
			{
				BackgroundImage = nil,
			},
		},
		
		Gui.Label ("formula_sucai_name"..index)
		{
			Size = Vector2(224, 36),
			Location = Vector2(56, 0),
			BackgroundColor = ARGB(2, 255, 255, 255),
			TextColor = ARGB(255, 255, 180, 104),
			FontSize = 16,
			TextAlign = "kAlignLeftMiddle",
		},
		
		Gui.CheckBox ("formula_sucai_checkbox"..index)
		{
			Size = Vector2(20, 20),
			Location = Vector2(285, 8),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Check = false,
			Skin = Gui.CheckBoxSkin
			{
				OnImage = Gui.Image("LobbyUI/Compose/lb_blueprint_checkbox_down.dds", Vector4(0, 0, 0, 0)),
				OffImage = Gui.Image("LobbyUI/Compose/lb_blueprint_checkbox_normal.dds", Vector4(0, 0, 0, 0)),
			},
		},
	}
end

function create_btn(x, y, index)
	return Gui.ItemBoxBtn
	{
		Style = "Gui.ItemBoxBtn_Compose",
		Location = Vector2(x, y),
		Visible = temp,
		Padding = Vector4(12, 12, 12, 12),
		EventMouseUp = function(Sender,e)
			if rpc_date_object and rpc_date_object.combineDetail[index].state == 0 and rpc_date_object.combineDetail[index].open == 1 then
				if rpc_slotting.sloterItemId ~= 0 then
					MessageBox.ShowWithConfirmCancel(lang:GetText("此次改装需花费1000C币\n您是否要继续？"),
					function(data)
						rpc_slotting.index = index
						rpc_slotting.playerItemId = rpc_date_object.playeritemid
						rpc.safecallload("slotting",rpc_slotting,
						function(data)
							if data.result == 0 then
								MessageBox.ShowWithTimer(1,lang:GetText("成功！"))
								gui:PlayAudio("kUIA_COMPOUND_SUCCEED")
							else
								MessageBox.ShowWithTimer(1,lang:GetText("失败"))
								gui:PlayAudio("kUIA_COMPOUND_FAIL")
							end
							FillStorage()
							rpc_date_object = data.item
							if data.sloterItem.common then
								local btn = ui.dakong
								local control = ptr_cast(btn:GetChildByIndex(2))
								L_LobbyMain.FillNumber(data.sloterItem.common.quantity, control)
							else
								local btn = ui.dakong
								btn.ItemIcon = nil
								rpc_slotting.sloterItemId = 0
								Clean_hole()
							end
							FillMachine1(0)
						end)
					end)
				else
					ui.Help_part3.Visible = true
				end
			end
		end,
	}
end

function create_button(x, y, index)
	return Gui.Button
	{
		Style = "Gui.Button_Compose",
		Location = Vector2(x, y),
		Enable = false,
		Visible = temp,
		EventClick = function(Sender,e)
			if Sender.Text == lang:GetText("改装") then
				if rpc_slotting.sloterItemId ~= 0 then
					MessageBox.ShowWithConfirmCancel(lang:GetText("此次改装需花费1000C币\n您是否要继续？"),
					function(data)
						rpc_slotting.index = index
						rpc_slotting.playerItemId = rpc_date_object.playeritemid
						rpc.safecallload("slotting",rpc_slotting,
						function(data)
							if data.result == 0 then
								MessageBox.ShowWithTimer(1,lang:GetText("成功！"))
								gui:PlayAudio("kUIA_COMPOUND_SUCCEED")
							else
								MessageBox.ShowWithTimer(1,lang:GetText("失败"))
								gui:PlayAudio("kUIA_COMPOUND_FAIL")
							end
							FillStorage()
							rpc_date_object = data.item
							if data.sloterItem.common then
								local btn = ui.dakong
								local control = ptr_cast(btn:GetChildByIndex(2))
								L_LobbyMain.FillNumber(data.sloterItem.common.quantity, control)
							else
								local btn = ui.dakong
								btn.ItemIcon = nil
								rpc_slotting.sloterItemId = 0
								Clean_hole()
							end
							FillMachine1(0)
						end)
					end)
				else
					ui.Help_part3.Visible = true
				end
			elseif Sender.Text == lang:GetText("移除") then
				MessageBox.ShowWithConfirmCancel(lang:GetText("拆除此属性部件需要花费1000C币\n还要继续吗？"),
				function(data)
					rpc_remove.index = index
					rpc_remove.playerItemId = rpc_date_object.playeritemid
					rpc.safecallload("remove",rpc_remove,
					function(data)
						if data.result == 0 then
							MessageBox.ShowWithTimer(1,lang:GetText("成功！"))
							gui:PlayAudio("kUIA_COMPOUND_SUCCEED")
						else
							MessageBox.ShowWithTimer(1,lang:GetText("失败"))
							gui:PlayAudio("kUIA_COMPOUND_FAIL")
						end
						FillStorage()
						rpc_date_object = data.item
						FillMachine1(0)
					end)
				end)
			end
		end,
	}
end

function create_ItemBtn_shengxing(index)
	return Gui.ItemBoxBtn ("Item_btn_shengxing_"..index)
	{
		Size = Vector2(80, 80),
		Empty = false,
		Type = 1,
		CanSelect = false,
		BackgroundColor = ARGB(255, 255, 255, 255),
		Skin = Gui.ItemBoxBtnSkin
		{
			NeutralNormalImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_slot.dds", Vector4(0, 0, 0, 0)),
			NeutralHoverImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_slot_flash_1.dds", Vector4(0, 0, 0, 0)),
			NeutralDisabledImage = Gui.Image("LobbyUI/Compose/lb_synthesis_mosaic_ico_01.dds", Vector4(0, 0, 0, 0)),
		},
		EventMouseUp = function(sender, e)
			if sender.ItemIcon then
				sender.ItemIcon = nil
				if upstar[index].type == current_selected and upstar[index].page == current_page and upstar[index].cid == current_characters then
					local ibbtn
					if current_selected == 1 then
						ibbtn = ptr_cast(weapon_info_page.ctrl_ib_container:GetChildByIndex(upstar[index].index-1))
					elseif current_selected == 2 then
						ibbtn = ptr_cast(dress_info_page.ctrl_ib_container:GetChildByIndex(upstar[index].index-1))
					elseif current_selected == 3 then
						ibbtn = ptr_cast(accessories_info_page.ctrl_ib_container:GetChildByIndex(upstar[index].index-1))
					end
					-- ibbtn = ptr_cast(weapon_info_page.ctrl_ib_container:GetChildByIndex(upstar[index].index-1))
					rpc_date[upstar[index].index].common.quantity = rpc_date[upstar[index].index].common.quantity + 1
					local Control = ptr_cast(ibbtn:GetChildByIndex(2))
					L_LobbyMain.FillNumber(rpc_date[upstar[index].index].common.quantity, Control)
					ibbtn.ItemIcon.alpha = 255
				end
				Clean_upstar(index)
				FillMachine4(0)
			end
		end,
		-- Gui.Label ("temp_exp"..index)
		-- {
			-- Size = Vector2(80, 20),
			-- Location = Vector2(0, 5),
			-- FontSize = 12,
			-- TextAlign = "kAlignCenterTop",
			-- TextColor = ARGB(255, 0, 0, 0),
			-- Text = "0",
		-- },
	}
end

function create_ItemBtn(index)
	return Gui.ItemBoxBtn ("Item_btn_"..index)
	{
		Size = Vector2(80, 80),
		Empty = false,
		Type = 1,
		CanSelect = false,
		BackgroundColor = ARGB(255, 255, 255, 255),

		EventMouseUp = function(sender, e)
			if sender.ItemIcon then
				sender.ItemIcon = nil
				if melting[index].type == current_selected and melting[index].page == current_page and melting[index].cid == current_characters then
					local ibbtn
					if current_selected == 1 then
						ibbtn = ptr_cast(weapon_info_page.ctrl_ib_container:GetChildByIndex(melting[index].index-1))
					elseif current_selected == 2 then
						ibbtn = ptr_cast(dress_info_page.ctrl_ib_container:GetChildByIndex(melting[index].index-1))
					elseif current_selected == 3 then
						ibbtn = ptr_cast(accessories_info_page.ctrl_ib_container:GetChildByIndex(melting[index].index-1))
					elseif current_selected > 3 then
						ibbtn = ptr_cast(material_info_page.ctrl_ib_container:GetChildByIndex(melting[index].index-1))
						rpc_date[melting[index].index].common.quantity = rpc_date[melting[index].index].common.quantity + 1
						local Control = ptr_cast(ibbtn:GetChildByIndex(2))
						L_LobbyMain.FillNumber(rpc_date[melting[index].index].common.quantity, Control)
					end
					ibbtn.ItemIcon.alpha = 255
				end
				if current_selected == 3 then
					for i = 1, 16 do
						if rpc_date[i] then
							if rpc_date[i].playeritemid == melting[index].pid then
								local ibbtn = ptr_cast(accessories_info_page.ctrl_ib_container:GetChildByIndex(i-1))
								ibbtn.ItemIcon.alpha = 255
							end
						end
					end
				end
				Clean_melting(index)
			end
			FillMachine3(0)
		end
	}
end

function create_node_button(name,text, flowLayout, x, skin, data, color, highlighttextcolor)
	local image = nil
	if data and data.items then
		image = "lb_blueprint_bg_"..#data.items
	end
	local item = Gui.Create()
	{
		Gui.Control (name.."root")
		{
			Size = Vector2(249, 44),
			Gui.Control
			{
				Size = Vector2(x, 44),
				Location = Vector2(0, 0),
			},
			Gui.Button (name)
			{
				Size = Vector2(249 - x, 44),
				Location = Vector2(x, 0),
				Text = text,
				TextColor = color,
				HighlightTextColor = highlighttextcolor,
				Padding = Vector4(5, 0, 0, 0),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Compose/lb_melting_tab_0"..skin.."_normal.dds", Vector4(34, 0, 15, 0)),
					HoverImage = Gui.Image("LobbyUI/Compose/lb_melting_tab_0"..skin.."_hover.dds", Vector4(34, 0, 15, 0)),
					DownImage = Gui.Image("LobbyUI/Compose/lb_melting_tab_0"..skin.."_down.dds", Vector4(34, 0, 15, 0)),
					DisabledImage = Gui.Image("LobbyUI/Compose/lb_melting_tab_0"..skin.."_disabled.dds", Vector4(34, 0, 15, 0)),
				},
				EventClick = function(sender, e)
					if image then
						melting_list.image.Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/Compose/blueprint/"..image..".dds", Vector4(0, 0, 0, 0)),
						}
						for i = 1, 6 do
							if i == #data.items then
								melting_list["Background_"..i].Visible = true
							else
								melting_list["Background_"..i].Visible = false
							end
						end

						local count = #data.items
						for i = 1, count do
							local bg = ptr_cast(melting_list["Background_"..count]:GetChildByIndex(i - 1))
							local image = ptr_cast(bg:GetChildByIndex(0))
							image.Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/ibt_icon/"..data.items[i][2]..".tga", Vector4(0, 0, 0, 0)),
							}
							local lab = ptr_cast(bg:GetChildByIndex(1))
							lab.Text = data.items[i][3]
						end
						local bg = ptr_cast(melting_list["Background_"..count]:GetChildByIndex(count))
						bg.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..data.result[1].name..".tga")
						bg.EventMouseEnter = function(sender, e)
							L_ToolTips.FillToolBigPresentWindow(1, melting_list.root, data.result)
						end
						bg.EventToolTipsShow = function(sender, e)
							if data.result[1] then
								local loc = sender.Location + sender.Parent.Location + sender.Parent.Parent.Location + sender.Parent.Parent.Parent.Location + sender.Parent.Parent.Parent.Parent.Location + sender.Parent.Parent.Parent.Parent.Parent.Location + sender.Parent.Parent.Parent.Parent.Parent.Parent.Location   
								L_ToolTips.ShowToolTipsShowWindow(sender,Vector2(1200, 900), loc)
							end
						end
						bg.EventMouseLeave = function(sender, e)
							L_ToolTips.HideToolTipsWindow()
						end
						bg = ptr_cast(melting_list["Background_"..count]:GetChildByIndex(count + 1))
						local image = ptr_cast(bg:GetChildByIndex(0))
						image.Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ibt_icon/"..data.map[2]..".tga", Vector4(0, 0, 0, 0)),
						}
						local lab = ptr_cast(bg:GetChildByIndex(1))
						lab.Text = lang:GetText("蓝图")
						if Select_Button then
							Select_Button.PushDown = false
						end
						Select_Button = sender
						sender.PushDown = true
					else
						local iter = sender.Parent.Parent.FirstChild
						while(iter) do
							if iter.Text == flowLayout then
								if iter then
									iter.Visible = not iter.Visible
									sender.PushDown = not sender.PushDown
									melting_list.scroll.AutoScrollMinSize = Vector2(0, high(melting_list.Layout))
								end
								break
							end
							iter = iter.Next
						end
					end
				end
			},
		}
	}
	return item
end

function create_node_flowLayout(name)
	local item = Gui.Create()
	{
		Gui.FlowLayout (name)
		{
			Text = name,
			Visible = false,
			Size = Vector2(249, 300),
			ControlSpace = 0,
			LineSpace = 0,
			IntTag = 1,
		}
	}
	return item
end

function SpawnControl()
	return Gui.Control
	{
		Size = Vector2(70, 16),
		Location = Vector2(47, 73),
		BackgroundColor = ARGB(0, 255, 255, 255),
		Gui.Control "c1"
		{
			Size = Vector2(20, 16),
			Location = Vector2(5, 0),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Visible = false,
		},
		Gui.Control "c2"
		{
			Size = Vector2(20, 16),
			Location = Vector2(20, 0),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Visible = false,
		},
		Gui.Control "c3"
		{
			Size = Vector2(20, 16),
			Location = Vector2(35, 0),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Visible = false,
		},
		Gui.Control "c4"
		{
			Size = Vector2(20, 16),
			Location = Vector2(50, 0),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Visible = false,
		},
	}
end

function Melting_List_Control(str,index)
	return Gui.Button ("btn_"..index)
	{
		Size = Vector2(200, 44),
		Location = Vector2(10, 30 + (index - 1) * 54),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Text = lang:GetText("熔炼值")..str.."%",
		Padding = Vector4(0, 0, 0, 7),
		TextAlign = "kAlignCenterMiddle",
		FontSize = 14,
		TextColor = ARGB(255, 255, 198, 0),
		HighlightTextColor = ARGB(255, 255, 198, 0),
		Skin = Gui.ButtonSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/Compose/lb_melting_button_normal.dds", Vector4(0, 0, 0, 0)),
			HoverImage = Gui.Image("LobbyUI/Compose/lb_melting_button_hover.dds", Vector4(0, 0, 0, 0)),
			DownImage = Gui.Image("LobbyUI/Compose/lb_melting_button_down.dds", Vector4(0, 0, 0, 0)),
		},
		EventClick = function(Sender,e)
			FillMeltingList(index)
		end,	
	}
end

function Melting_List_image(Location_x, Location_y)
	return Gui.Control 
	{
		Size = Vector2(164, 90),
		Location = Vector2(Location_x - 50, Location_y),
		BackgroundColor = ARGB(0, 255, 255, 255),
		Gui.Control 
		{
			Size = Vector2(64, 64),
			Location = Vector2(50, 0),
			BackgroundColor = ARGB(255, 255, 255, 255),
		},
		Gui.Label 
		{
			Size = Vector2(164, 20),
			Location = Vector2(0, 67),
			FontSize = 12,
			TextAlign = "kAlignCenterMiddle",
			TextColor = ARGB(255, 219, 163, 6),
		},
	}
end

function Melting_List_Btn(index)
	return Gui.ItemBoxBtn ("Ibtn_"..index)
	{
		Style = "Gui.ItemBoxBtn_ib",
		CanSelect = false,
		Size = Vector2(100, 100),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Skin = Gui.ItemBoxBtnSkin
		{
			NeutralNormalImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_slot.dds", Vector4(0, 0, 0, 0)),
			NeutralHoverImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_slot_flash_1.dds", Vector4(0, 0, 0, 0)),
			NeutralDisabledImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_slot.dds", Vector4(0, 0, 0, 0)),
		},

		EventMouseEnter = function(sender, e)
			local i = index
			L_ToolTips.FillToolBigPresentWindow(i, meltinglistmodal.root, melting_rpc_data_list)
		end,
		EventToolTipsShow = function(sender, e)
			L_ToolTips.ShowToolTipsShowWindow(sender,Vector2(1200, 900),sender.Location + sender.Parent.Location + sender.Parent.Parent.Location + sender.Parent.Parent.Parent.Location + sender.Parent.Parent.Parent.Parent.Location + sender.Parent.Parent.Parent.Parent.Parent.Location)
		end,
		EventMouseLeave = function(sender, e)
			L_ToolTips.HideToolTipsWindow()
		end,
	}
end

main_type = nil
rpc_date = nil
price = -1
index_tz = 1
current_characters = 1
current_selected = 1
current_page = 1
rpc_date_object = nil
rpc_date_object_1 = {{},{}}
current_pages = nil
index_right = nil
data_temp = nil
modalFlash = nil
info = nil
residual_total = 0
Rapid_Shopping_index = nil
melting_rpc_data = {}
melting_rpc_data_list = {}
cost_lookover = 0
formula_right = false
melting_items = nil
melting_result = nil

local warning_level = 0
local success_level = -1
local is_formula = false
local MaxLevel = 18
local Select_Button = nil 
local to_rate = 0
local from_rate = 0
local bluemap = {}
local bluemaplist={
{
	
		name="枪械蓝图",
		item= nil, 
		
		children=
		{
			{
	
				name="火箭炮蓝图",
				item= nil, 
				
				children=
				{
					{
			
						name="毁灭公爵蓝图",
						item=
						{
							items={{4007,"namecard3","名片-战争之王",},{5176,"mater3_05","枪身组件",},{5174,"mater3_03","击发组件",},{5175,"mater3_04","枪管组件",},{5172,"mater3_01","供弹组件",},{5173,"mater3_02","瞄准组件",},},result={{5178,"rocket01015","毁灭公爵-离子炮",1,0,},},
						},
				
						children= nil,
				 
			
					},

				},
		 
	
			},
			{
				
					name="重机枪蓝图",
					item= nil, 
					
					children=
					{
						{
				
							name="火力风暴蓝图",
							item=
							{
								items={{5176,"mater3_05","枪身组件",},{4009,"namecard5","名片-纯爷们",},{5174,"mater3_03","击发组件",},{5175,"mater3_04","枪管组件",},{5172,"mater3_01","供弹组件",},{5173,"mater3_02","瞄准组件",},},result={{5179,"fatman01015","火力风暴-重型机枪",1,0,},},
							},
							
							children= nil,
					 
				
						},

					},
					 
				
			},
{
	
		name="突击抢蓝图",
		item= nil, 
		
		children=
		{
			{
	
		name="极速飙风蓝图",
		item=
		{
			items={{5176,"mater3_05","枪身组件",},{5174,"mater3_03","击发组件",},{4008,"namecard4","名片-性感红唇",},{5175,"mater3_04","枪管组件",},{5172,"mater3_01","供弹组件",},{5173,"mater3_02","瞄准组件",},},result={{5180,"sniper01015","穿膛先驱-镭射狙击枪",1,0,},},
		},
		
		children= nil,
		 
	
},

		},
		 
	
},
{
	
		name="狙击枪蓝图",
		item= nil, 
		
		children=
		{
			{
	
		name="传膛先驱蓝图",
		item=
		{
			items={{5176,"mater3_05","枪身组件",},{5174,"mater3_03","击发组件",},{5175,"mater3_04","枪管组件",},{5172,"mater3_01","供弹组件",},{4010,"namecard6","名片-枪王之王",},{5173,"mater3_02","瞄准组件",},},result={{5181,"striker01015","极速飙风-电磁突击枪",1,0,},},
		},
		
		children= nil,
		 
	
},

		},
		 
	
},
{
	
		name="火焰枪蓝图",
		item= nil, 
		
		children=
		{
			{
	
		name="雷霆狂徒蓝图",
		item=
		{
			items={{5176,"mater3_05","枪身组件",},{5174,"mater3_03","击发组件",},{5175,"mater3_04","枪管组件",},{4011,"namecard7","名片-火云邪神",},{5172,"mater3_01","供弹组件",},{5173,"mater3_02","瞄准组件",},},result={{5182,"firebat01015","雷霆狂徒-电幕枪",1,0,},},
		},
		
		children= nil,
		 
	
},

		},
		 
	
},
{
	
		name="弩枪蓝图",
		item= nil, 
		
		children=
		{
			{
	
		name="掠食者蓝图",
		item=
		{
			items={{5176,"mater3_05","枪身组件",},{5177,"namecard14","名片-粉红治愈",},{5174,"mater3_03","击发组件",},{5175,"mater3_04","枪管组件",},{5172,"mater3_01","供弹组件",},{5173,"mater3_02","瞄准组件",},},result={{5183,"medic01015","掠食者-震荡弩",1,0,},},
		},
		
		children= nil,
		 
	
},

		},
		 
	
},

		},
		 
	
},
}
local button_count = 0
local stack_count = 0

local t_Text =
{
	"",
	lang:GetText("极低"),
	lang:GetText("较低"),
	lang:GetText("中等"),
	lang:GetText("较高"),
	lang:GetText("极高"),
}

local t_Text1 =
{
	"",
	lang:GetText("您仍可以大胆转换。"),
	lang:GetText("您仍可以尝试转换。"),
	lang:GetText("您需要考虑一下。"),
	lang:GetText("您再考虑下吧？"),
	lang:GetText("相当危险喔~"),
}

-- 合成RPC
rpc_string = {pid = ptr_cast(game.CurrentState):GetCharacterId(), playerItemId = 0, strengthenItemId = 0, safeItemId = 0, stableItemId = 0}

--快速购买RPC
shop_fast_buy = {pid = ptr_cast(game.CurrentState):GetCharacterId(), sid = 1, num = 0}

--打孔RPC
rpc_slotting = {pid = ptr_cast(game.CurrentState):GetCharacterId(), playerItemId = 0, index = 0, sloterItemId = 0}

--镶嵌RPC
rpc_insert = {pid = ptr_cast(game.CurrentState):GetCharacterId(), playerItemId = 0, index = 0, propertyItemId = 0}

--移除宝石RPC
rpc_remove = {pid = ptr_cast(game.CurrentState):GetCharacterId(), playerItemId = 0, index = 0}

--转换RPC
rpc_convert = {pid = ptr_cast(game.CurrentState):GetCharacterId(), fromItemId = 0, toItemId = 0, islose = 1}

--强化界面 上面三个按钮的物品数据
index_table = {
				{playeritemid = -1, page = -1, index = -1, num = -1},
				{playeritemid = -1, page = -1, index = -1, num = -1},
				{playeritemid = -1, page = -1, index = -1, num = -1},
}

--强化和镶嵌界面中间按钮的物品数据
Weapon_table = {page = -1, index = -1, cid = -1, type = -1}

--镶嵌界面打孔工具的数据
hole = {playeritemid = -1, page = -1, index = -1, num = -1}

--转换
convert = {
			{page = -1, index = -1, cid = -1, type = -1},
			{page = -1, index = -1, cid = -1, type = -1},
		  }

--熔炼
melting =
{
	{page = -1, index = -1, cid = -1, type = -1, pid = -1, residual = -1, value = -1, sid = -1},
	{page = -1, index = -1, cid = -1, type = -1, pid = -1, residual = -1, value = -1, sid = -1},
	{page = -1, index = -1, cid = -1, type = -1, pid = -1, residual = -1, value = -1, sid = -1},
	{page = -1, index = -1, cid = -1, type = -1, pid = -1, residual = -1, value = -1, sid = -1},
	{page = -1, index = -1, cid = -1, type = -1, pid = -1, residual = -1, value = -1, sid = -1},
	{page = -1, index = -1, cid = -1, type = -1, pid = -1, residual = -1, value = -1, sid = -1},
	{page = -1, index = -1, cid = -1, type = -1, pid = -1, residual = -1, value = -1, sid = -1},
	{page = -1, index = -1, cid = -1, type = -1, pid = -1, residual = -1, value = -1, sid = -1},
	{page = -1, index = -1, cid = -1, type = -1, pid = -1, residual = -1, value = -1, sid = -1},
}

--升星
upstar =
{
	{page = -1, index = -1, cid = -1, type = -1, pid = -1, gstLevel = -1, gstExp = -1, sid = -1, rareLevel = -1, star = -1, damange = -1, damange_add = -1, speed = -1, speed_add = -1, wid = -1, display = nil , strength = -1 , gstExpAdd = -1 , cBloodAdd = -1 , cBloodAdd_add = -1 },
	{page = -1, index = -1, cid = -1, type = -1, pid = -1, gstLevel = -1, gstExp = -1, sid = -1, rareLevel = -1, star = -1, damange = -1, damange_add = -1, speed = -1, speed_add = -1, wid = -1, display = nil , strength = -1 , gstExpAdd = -1 , cBloodAdd = -1 , cBloodAdd_add = -1 },
	{page = -1, index = -1, cid = -1, type = -1, pid = -1, gstLevel = -1, gstExp = -1, sid = -1, rareLevel = -1, star = -1, damange = -1, damange_add = -1, speed = -1, speed_add = -1, wid = -1, display = nil , strength = -1 , gstExpAdd = -1 , cBloodAdd = -1 , cBloodAdd_add = -1 },
	{page = -1, index = -1, cid = -1, type = -1, pid = -1, gstLevel = -1, gstExp = -1, sid = -1, rareLevel = -1, star = -1, damange = -1, damange_add = -1, speed = -1, speed_add = -1, wid = -1, display = nil , strength = -1 , gstExpAdd = -1 , cBloodAdd = -1 , cBloodAdd_add = -1 },
	{page = -1, index = -1, cid = -1, type = -1, pid = -1, gstLevel = -1, gstExp = -1, sid = -1, rareLevel = -1, star = -1, damange = -1, damange_add = -1, speed = -1, speed_add = -1, wid = -1, display = nil , strength = -1 , gstExpAdd = -1 , cBloodAdd = -1 , cBloodAdd_add = -1 },
	{page = -1, index = -1, cid = -1, type = -1, pid = -1, gstLevel = -1, gstExp = -1, sid = -1, rareLevel = -1, star = -1, damange = -1, damange_add = -1, speed = -1, speed_add = -1, wid = -1, display = nil , strength = -1 , gstExpAdd = -1 , cBloodAdd = -1 , cBloodAdd_add = -1 },
	{page = -1, index = -1, cid = -1, type = -1, pid = -1, gstLevel = -1, gstExp = -1, sid = -1, rareLevel = -1, star = -1, damange = -1, damange_add = -1, speed = -1, speed_add = -1, wid = -1, display = nil , strength = -1 , gstExpAdd = -1 , cBloodAdd = -1 , cBloodAdd_add = -1 },
	{page = -1, index = -1, cid = -1, type = -1, pid = -1, gstLevel = -1, gstExp = -1, sid = -1, rareLevel = -1, star = -1, damange = -1, damange_add = -1, speed = -1, speed_add = -1, wid = -1, display = nil , strength = -1 , gstExpAdd = -1 , cBloodAdd = -1 , cBloodAdd_add = -1 },
	{page = -1, index = -1, cid = -1, type = -1, pid = -1, gstLevel = -1, gstExp = -1, sid = -1, rareLevel = -1, star = -1, damange = -1, damange_add = -1, speed = -1, speed_add = -1, wid = -1, display = nil , strength = -1 , gstExpAdd = -1 , cBloodAdd = -1 , cBloodAdd_add = -1 },
	{page = -1, index = -1, cid = -1, type = -1, pid = -1, gstLevel = -1, gstExp = -1, sid = -1, rareLevel = -1, star = -1, damange = -1, damange_add = -1, speed = -1, speed_add = -1, wid = -1, display = nil , strength = -1 , gstExpAdd = -1 , cBloodAdd = -1 , cBloodAdd_add = -1 },
}

upstar_AllExp = nil
upstar_RareExp = nil
everyDayExp = nil
everyDayIsVisiable = nil
everyDayCPoint = nil
adronArms = nil

melting_table = {playeritemid = -1, value = 0}

item_rpc = nil

qianghua_index = nil

characters_object = nil

ui = Gui.Create()
{
	Gui.Control "main"
	{
		Size = Vector2(1116, 586),
		Location = Vector2(19, 25),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/lb_shop_bg2.dds", Vector4(14, 14, 14, 14)),
		},

		Gui.Control "boddy_info_BG"
		{
			Size = Vector2(1101, 578),
			Location = Vector2(9, 8),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg.tga", Vector4(150, 22, 22, 22)),
			},
		},
		
		--职业列表
		L_Characters_tab.create_tab_characters_windows(Vector2(1,38)),

		--中间合成界面
		Gui.Control
		{
			Size = Vector2(469, 565),
			Location = Vector2(151, 10),
			BackgroundColor = ARGB(0, 255, 255, 255),
			
			
			Gui.Control
			{
				Size = Vector2(469, 530),
				Location = Vector2(0, 38),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg3.dds", Vector4(22, 22, 22, 22)),
				},
				
				Gui.Control	"buffbg_02"
				{
					Size = Vector2(464, 40),
					Location = Vector2(3, 8),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_buffbg.dds", Vector4(18, 18, 18, 18)),
					},
					
					Gui.Control
					{
						Size = Vector2(89, 40),
						Location = Vector2(0, 0),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_buffbg_02.dds", Vector4(0, 0, 0, 0)),
						},
					},
					Gui.Control
					{
						Size = Vector2(89, 40),
						Location = Vector2(375, 0),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_buffbg_02_b.dds", Vector4(0, 0, 0, 0)),
						},
					},
					
					Gui.Label
					{
						TextAlign = "kAlignLeftMiddle",
						Size = Vector2(400, 40),
						Location = Vector2(15, 0),
						FontSize = 18,
						TextColor = ARGB(255, 255, 86, 0),
						Text = lang:GetText("强化加成")..":",
					},
					
					Gui.FlowLayout "buff_layout"
					{
						Location = Vector2(190, 7),
						Size = Vector2(200,20),
						Direction = "kHorizontal",
						Align = "kAlignLeftMiddle",
						ControlSpace = 1,
					},
					
				},
				
				Gui.Control	"buffbg_03"
				{
					Visible = false,
					Size = Vector2(472, 56),
					Location = Vector2(3, 8),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_buffbg_03.dds", Vector4(0, 0, 0, 0)),
					},
				},
				
				Gui.Control "qianghua"
				{
					Size = Vector2(466, 494),
					Location = Vector2(3, 33),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/Compose/lb_synthesis_strengthening_bg_01.dds", Vector4(125, 32, 126, 300)),
					},
					Gui.Control
					{
						Size = Vector2(466, 252),
						Location = Vector2(0, 0),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_bg_02.dds", Vector4(0, 0, 0, 0)),
						},
					},
					Gui.ItemBoxBtn
					{
						Size = Vector2(100, 100),
						Location = Vector2(25, 27),
						Empty = false,
						Type = 1,
						CanSelect = false,
						Padding = Vector4(12, 12, 12, 12),
						Skin = Gui.ItemBoxBtnSkin
						{
							NeutralNormalImage = Gui.Image("LobbyUI/Compose/lb_synthesis_strengthening_slot_01.dds", Vector4(0, 0, 0, 0)),
							NeutralHoverImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_slot_flash_1.dds", Vector4(0, 0, 0, 0)),
							NeutralSelectedImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_slot_flash.dds", Vector4(0, 0, 0, 0)),
							NeutralDisabledImage = Gui.Image("LobbyUI/Compose/lb_synthesis_mosaic_ico_01.dds", Vector4(0, 0, 0, 0)),
							NeutralHighlightImage = Gui.Image("LobbyUI/Compose/lb_synthesis_strengthening_slot_flash.dds", Vector4(0, 0, 0, 0)),
							NeutralImage = Gui.Image("LobbyUI/Compose/lb_synthesis_strengthening_slot_flash_02.dds", Vector4(0, 0, 0, 0)),
						},
						EventMouseUp = function(Sender,e)
							Sender.ItemIcon = nil
							local lable = ptr_cast(ui.qianghua:GetChildByIndex(4))
							lable.TextColor = ARGB(255, 255, 0, 0)
							local control = ptr_cast(ui.Image:GetChildByIndex(1))
							control.Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_ico_01_normal.dds", Vector4(0, 0, 0, 0)),
							}
							control = ptr_cast(Sender:GetChildByIndex(2))
							control.Visible = false
							rpc_string.strengthenItemId = 0
							if current_selected > 3 and current_page == index_table[1].page then
								if material_info_page then
									local btn = ptr_cast(material_info_page.ctrl_ib_container:GetChildByIndex(index_table[1].index - 1))
									btn.ItemIcon.alpha = 255
								end
							end
							Clean_index_table(1)
							FillMachine(0)
						end,
						Gui.Control
						{
							Size = Vector2(70, 16),
							Location = Vector2(29, 78),
							BackgroundColor = ARGB(0, 255, 255, 255),
							Gui.Control "c1"
							{
								Size = Vector2(20, 16),
								Location = Vector2(5, 0),
								BackgroundColor = ARGB(255, 255, 255, 255),
								Visible = false,
							},
							Gui.Control "c2"
							{
								Size = Vector2(20, 16),
								Location = Vector2(20, 0),
								BackgroundColor = ARGB(255, 255, 255, 255),
								Visible = false,
							},
							Gui.Control "c3"
							{
								Size = Vector2(20, 16),
								Location = Vector2(35, 0),
								BackgroundColor = ARGB(255, 255, 255, 255),
								Visible = false,
							},
							Gui.Control "c4"
							{
								Size = Vector2(20, 16),
								Location = Vector2(50, 0),
								BackgroundColor = ARGB(255, 255, 255, 255),
								Visible = false,
							},
						}
					},
					Gui.ItemBoxBtn
					{
						Size = Vector2(100, 100),
						Location = Vector2(181, 27),
						Empty = false,
						Type = 1,
						CanSelect = false,
						Padding = Vector4(12, 12, 12, 12),
						Skin = Gui.ItemBoxBtnSkin
						{
							NeutralNormalImage = Gui.Image("LobbyUI/Compose/lb_synthesis_strengthening_slot_02.dds", Vector4(0, 0, 0, 0)),
							NeutralHoverImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_slot_flash_1.dds", Vector4(0, 0, 0, 0)),
							NeutralSelectedImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_slot_flash.dds", Vector4(0, 0, 0, 0)),
							NeutralDisabledImage = Gui.Image("LobbyUI/Compose/lb_synthesis_mosaic_ico_01.dds", Vector4(0, 0, 0, 0)),
							NeutralHighlightImage = Gui.Image("LobbyUI/Compose/lb_synthesis_strengthening_slot_flash.dds", Vector4(0, 0, 0, 0)),
						},
						EventMouseUp = function(Sender,e)
							Sender.ItemIcon = nil
							local control = ptr_cast(ui.Image:GetChildByIndex(2))
							control.Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_ico_01_normal.dds", Vector4(0, 0, 0, 0)),
							}
							control = ptr_cast(Sender:GetChildByIndex(2))
							control.Visible = false
							rpc_string.stableItemId = 0
							if current_selected > 3 and current_page == index_table[2].page then
								if material_info_page then
									local btn = ptr_cast(material_info_page.ctrl_ib_container:GetChildByIndex(index_table[2].index - 1))
									btn.ItemIcon.alpha = 255
								end
							end
							Clean_index_table(2)
							success_level = -1
						end,
						Gui.Control
						{
							Size = Vector2(70, 16),
							Location = Vector2(29, 78),
							BackgroundColor = ARGB(0, 255, 255, 255),
							Gui.Control "c1"
							{
								Size = Vector2(20, 16),
								Location = Vector2(5, 0),
								BackgroundColor = ARGB(255, 255, 255, 255),
								Visible = false,
							},
							Gui.Control "c2"
							{
								Size = Vector2(20, 16),
								Location = Vector2(20, 0),
								BackgroundColor = ARGB(255, 255, 255, 255),
								Visible = false,
							},
							Gui.Control "c3"
							{
								Size = Vector2(20, 16),
								Location = Vector2(35, 0),
								BackgroundColor = ARGB(255, 255, 255, 255),
								Visible = false,
							},
							Gui.Control "c4"
							{
								Size = Vector2(20, 16),
								Location = Vector2(50, 0),
								BackgroundColor = ARGB(255, 255, 255, 255),
								Visible = false,
							},
						}
					},
					Gui.ItemBoxBtn
					{
						Size = Vector2(100, 100),
						Location = Vector2(337, 27),
						Empty = false,
						Type = 1,
						CanSelect = false,
						Padding = Vector4(12, 12, 12, 12),
						Skin = Gui.ItemBoxBtnSkin
						{
							NeutralNormalImage = Gui.Image("LobbyUI/Compose/lb_synthesis_strengthening_slot_03.dds", Vector4(0, 0, 0, 0)),
							NeutralHoverImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_slot_flash_1.dds", Vector4(0, 0, 0, 0)),
							NeutralSelectedImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_slot_flash.dds", Vector4(0, 0, 0, 0)),
							NeutralDisabledImage = Gui.Image("LobbyUI/Compose/lb_synthesis_mosaic_ico_01.dds", Vector4(0, 0, 0, 0)),
							NeutralHighlightImage = Gui.Image("LobbyUI/Compose/lb_synthesis_strengthening_slot_flash.dds", Vector4(0, 0, 0, 0)),
						},
						EventMouseUp = function(Sender,e)
							Sender.ItemIcon = nil
							local control = ptr_cast(ui.Image:GetChildByIndex(3))
							control.Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_ico_01_normal.dds", Vector4(0, 0, 0, 0)),
							}
							control = ptr_cast(Sender:GetChildByIndex(2))
							control.Visible = false
							rpc_string.safeItemId = 0
							if current_selected > 3 and current_page == index_table[3].page then
								if material_info_page then
									local btn = ptr_cast(material_info_page.ctrl_ib_container:GetChildByIndex(index_table[3].index - 1))
									btn.ItemIcon.alpha = 255
								end
							end
							Clean_index_table(3)
						end,
						Gui.Control
						{
							Size = Vector2(70, 16),
							Location = Vector2(29, 78),
							BackgroundColor = ARGB(0, 255, 255, 255),
							Gui.Control "c1"
							{
								Size = Vector2(20, 16),
								Location = Vector2(5, 0),
								BackgroundColor = ARGB(255, 255, 255, 255),
								Visible = false,
							},
							Gui.Control "c2"
							{
								Size = Vector2(20, 16),
								Location = Vector2(20, 0),
								BackgroundColor = ARGB(255, 255, 255, 255),
								Visible = false,
							},
							Gui.Control "c3"
							{
								Size = Vector2(20, 16),
								Location = Vector2(35, 0),
								BackgroundColor = ARGB(255, 255, 255, 255),
								Visible = false,
							},
							Gui.Control "c4"
							{
								Size = Vector2(20, 16),
								Location = Vector2(50, 0),
								BackgroundColor = ARGB(255, 255, 255, 255),
								Visible = false,
							},
						}
					},
					Gui.Label
					{
						TextAlign = "kAlignCenterMiddle",
						Size = Vector2(126, 16),
						Location = Vector2(12, 11),
						FontSize = 14,
						TextColor = ARGB(255, 255, 0, 0),
					},
					Gui.Label
					{
						TextAlign = "kAlignCenterMiddle",
						Size = Vector2(126, 16),
						Location = Vector2(168, 11),
						FontSize = 14,
						TextColor = ARGB(255, 255, 163, 0),
					},
					Gui.Label
					{
						TextAlign = "kAlignCenterMiddle",
						Size = Vector2(126, 16),
						Location = Vector2(324, 11),
						FontSize = 14,
						TextColor = ARGB(255, 255, 163, 0),
					},
					Gui.Control "Image"
					{
						Size = Vector2(344, 68),
						Location = Vector2(60, 114),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_bg_01_a.dds", Vector4(40, 0, 40, 0)),
						},
						Gui.Control
						{
							Size = Vector2(31, 68),
							Location = Vector2(159, 0),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_bg_01_b.dds", Vector4(0, 0, 0, 0)),
							},
						},
						Gui.Control
						{
							Size = Vector2(28, 36),
							Location = Vector2(2, 5),
							BackgroundColor = ARGB(255, 255, 255, 255),
						},
						Gui.Control
						{
							Size = Vector2(28, 36),
							Location = Vector2(160, 5),
							BackgroundColor = ARGB(255, 255, 255, 255),
						},
						Gui.Control
						{
							Size = Vector2(28, 36),
							Location = Vector2(315, 5),
							BackgroundColor = ARGB(255, 255, 255, 255),
						},
					},

					Gui.Control
					{
						Size = Vector2(288, 164),
						Location = Vector2(88, 143),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/Compose/lb_synthesis_strengthening_bg_02.dds", Vector4(40, 0, 40, 0)),
						},
						Gui.ItemBoxBtn "object"
						{
							Style = "Gui.ItemBoxBtn_ib",
							Size = Vector2(176, 126),
							Location = Vector2(56, 19),
							CanSelect = false,
							Skin = Gui.ItemBoxBtnSkin
							{
								NeutralNormalImage = nil,
								NeutralHoverImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_slot_flash.dds", Vector4(0, 0, 0, 0)),
								NeutralSelectedImage = nil,
								NeutralDisabledImage = nil,
								NeutralHighlightImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_slot_flash.dds", Vector4(0, 0, 0, 0)),
							},
							EventMouseUp = function(Sender,e)
								rpc_date_object = nil
								Sender.ItemIcon = nil
								rpc_string.playerItemId = 0
								ui.name.Text = ""
								for i = 1, 10 do
									local Label = ptr_cast(ui.text:GetChildByIndex(i - 1))
									Label.Text = ""
								end
								ui.compare_demage1.Visible = false
								ui.compare_demage2.Visible = false
								for i = 1, 3 do
									local ibbtn = ptr_cast(ui.qianghua:GetChildByIndex(i))
									if i == 1 then
										ibbtn.Enough = false
									end
									local lable = ptr_cast(ui.qianghua:GetChildByIndex(i + 3))
									lable.Visible = false
								end
								if current_selected == 1 and current_page == Weapon_table.page and Weapon_table.cid == current_characters and Weapon_table.type == 1 then
									local btn = ptr_cast(weapon_info_page.ctrl_ib_container:GetChildByIndex(Weapon_table.index - 1))
									btn.ItemIcon.alpha = 255
								elseif current_selected == 2 and current_page == Weapon_table.page and Weapon_table.cid == current_characters and Weapon_table.type == 2 then
									local btn = ptr_cast(dress_info_page.ctrl_ib_container:GetChildByIndex(Weapon_table.index - 1))
									btn.ItemIcon.alpha = 255
								elseif current_selected == 3 and current_page == Weapon_table.page and Weapon_table.cid == current_characters and Weapon_table.type == 3 then
									local btn = ptr_cast(accessories_info_page.ctrl_ib_container:GetChildByIndex(Weapon_table.index - 1))
									btn.ItemIcon.alpha = 255
								end
								Clean_Weapon_table()
								local ibbtn = ptr_cast(ui.object:GetChildByIndex(2))
								ibbtn.Visible = false
								ibbtn = ptr_cast(ui.object:GetChildByIndex(3))
								ibbtn.Visible = false
								FillMachine(0)
							end,
							Gui.Control
							{
								Size = Vector2(54,30),
								Location = Vector2(115, 91),
								BackgroundColor = ARGB(255, 255, 255, 255),
								Visible = false,
							},
							Gui.Control
							{
								Size = Vector2(102,17),
								Location = Vector2(45, 5),
								BackgroundColor = ARGB(255, 255, 255, 255),
								Visible = false,
							},
						},
					},

					Gui.Button
					{
						Style = "Gui.Button_Compose",
						Size = Vector2(72, 20),
						Location = Vector2(38, 121),
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/Compose/lb_synthesis_mosaic_button_normal.dds", Vector4(0, 0, 0, 0)),
							HoverImage = Gui.Image("LobbyUI/Compose/lb_synthesis_mosaic_button_hover.dds", Vector4(0, 0, 0, 0)),
							DownImage = Gui.Image("LobbyUI/Compose/lb_synthesis_mosaic_button_down.dds", Vector4(0, 0, 0, 0)),
						},
						Text = lang:GetText("购买"),
						FontSize = 20,
						TextAlign = "kAlignCenterMiddle",
						EventClick = function()
							qianghua_index = 1
							ShowRapid(1, 1)
						end
					},
					Gui.Button
					{
						Style = "Gui.Button_Compose",
						Size = Vector2(72, 20),
						Location = Vector2(196, 121),
						Text = lang:GetText("购买"),
						FontSize = 20,
						TextAlign = "kAlignCenterMiddle",
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/Compose/lb_synthesis_mosaic_button_normal.dds", Vector4(0, 0, 0, 0)),
							HoverImage = Gui.Image("LobbyUI/Compose/lb_synthesis_mosaic_button_hover.dds", Vector4(0, 0, 0, 0)),
							DownImage = Gui.Image("LobbyUI/Compose/lb_synthesis_mosaic_button_down.dds", Vector4(0, 0, 0, 0)),
						},
						EventClick = function()
							qianghua_index = 2
							ShowRapid(1, 2)
						end
					},
					Gui.Button
					{
						Style = "Gui.Button_Compose",
						Size = Vector2(72, 20),
						Location = Vector2(352, 121),
						Text = lang:GetText("购买"),
						FontSize = 20,
						TextAlign = "kAlignCenterMiddle",
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/Compose/lb_synthesis_mosaic_button_normal.dds", Vector4(0, 0, 0, 0)),
							HoverImage = Gui.Image("LobbyUI/Compose/lb_synthesis_mosaic_button_hover.dds", Vector4(0, 0, 0, 0)),
							DownImage = Gui.Image("LobbyUI/Compose/lb_synthesis_mosaic_button_down.dds", Vector4(0, 0, 0, 0)),
						},
						EventClick = function()
							qianghua_index = 3
							ShowRapid(1, 3)
						end
					},

					Gui.Label "qianghuatext"
					{
						Style = "Gui.Label_Compose",
						Size = Vector2(128, 40),
						Location = Vector2(9, 183),
						TextColor = ARGB(255, 245, 181, 54),
						BackgroundColor = ARGB(0, 255, 255, 255),
						TextAlign = "kAlignRightMiddle",
					},
					Gui.Label "text1"
					{
						Style = "Gui.Label_Compose",
						Size = Vector2(128, 40),
						Location = Vector2(11, 157),
						TextColor = ARGB(255, 245, 181, 54),
						BackgroundColor = ARGB(0, 255, 255, 255),
						TextAlign = "kAlignRightMiddle",
					},
					Gui.TextArea "text2"
					{
						Size = Vector2(156, 70),
						Location = Vector2(327, 154),
						DisabledTextColor = ARGB(255, 245, 181, 54),
						BackgroundColor = ARGB(0, 255, 255, 255),
						Fold = true,
						Readonly = true,
						Enable = false,
					},

					Gui.Control
					{
						Size = Vector2(431, 124),
						Location = Vector2(18, 310),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/Compose/lb_synthesis_strengthening_bg_03.dds", Vector4(0, 0, 0, 0)),
						},
						Gui.Label "name"
						{
							Size = Vector2(431, 20),
							Location = Vector2(0, 5),
							FontSize = 16,
							TextColor = ARGB(255, 245, 181, 54),
							TextAlign = "kAlignCenterMiddle",
						},
						Gui.Control "text"
						{
							Size = Vector2(431, 124),
							Location = Vector2(0, 5),
							BackgroundColor = ARGB(0, 255, 255, 255),
							Gui.Label
							{
								Style = "Gui.Label_Compose",
								Location = Vector2(30, 20),
							},
							Gui.Label
							{
								Style = "Gui.Label_Compose",
								Location = Vector2(220, 20),
							},
							Gui.Label
							{
								Style = "Gui.Label_Compose",
								Location = Vector2(30, 40),
							},
							Gui.Label
							{
								Style = "Gui.Label_Compose",
								Location = Vector2(220, 40),
							},
							Gui.Label
							{
								Style = "Gui.Label_Compose",
								Location = Vector2(30, 60),
							},
							Gui.Label
							{
								Style = "Gui.Label_Compose",
								Location = Vector2(220, 60),
							},
							Gui.Label
							{
								Style = "Gui.Label_Compose",
								Location = Vector2(30, 80),
							},
							Gui.Label
							{
								Style = "Gui.Label_Compose",
								Location = Vector2(220, 80),
							},
							Gui.Label "percent"
							{
								Style = "Gui.Label_Compose",
								TextAlign = "kAlignCenterMiddle",
								TextColor = ARGB(255, 255, 110, 1),
								Size = Vector2(431, 20),
								Location = Vector2(0, 100),
							},

							Gui.CompareBar "compare_demage1"
							{
								Visible = false,
								Size = Vector2(90, 14),
								Location = Vector2(85, 45),
								Icon = Gui.CompareIcon("LobbyUI/ToolTips/skin_bar02_BG.tga", "LobbyUI/ToolTips/skin_bar02_content.tga", "LobbyUI/ToolTips/skin_bar02_content.tga", "LobbyUI/ToolTips/skin_bar02_content.tga", Vector4(4,4,4,4), Vector4(4,4,4,4)),
							},
							Gui.Label "ctrl_demage"
							{
								Size = Vector2(16, 24),
								Location = Vector2(186, 45),
								NormLocation = Vector2(186, 45),
								BackgroundColor = ARGB(255, 255, 255, 255),
								MoveLocation = Vector2(0,4),
								MoveWheelTime = 0.8,
								Skin = Gui.ControlSkin
								{
									BackgroundImage = nil,
								},
							},
							Gui.FlowLayout "star"
							{
								Size = Vector2(140, 20),
								ControlSpace = 0,
								Location = Vector2(85, 60),
								create_star(),
								Gui.Label
								{
									Size = Vector2(100, 20),
									Location = Vector2(20, 0),
								},
							},
							Gui.CompareBar "compare_demage2"
							{
								Visible = false,
								Size = Vector2(90, 14),
								Location = Vector2(310, 45),
								Icon = nil,
							},
							Gui.Label "ctrl_demage1"
							{
								Size = Vector2(16, 24),
								Location = Vector2(411, 45),
								NormLocation = Vector2(411, 45),
								BackgroundColor = ARGB(255, 255, 255, 255),
								MoveLocation = Vector2(0,4),
								MoveWheelTime = 0.8,
								Skin = Gui.ControlSkin
								{
									BackgroundImage = nil,
								},
							},
							Gui.FlowLayout "star1"
							{
								Size = Vector2(140, 20),
								ControlSpace = 0,
								Location = Vector2(310, 60),
								create_star(),
								Gui.Label
								{
									Size = Vector2(100, 20),
									Location = Vector2(20, 0),
								},
							},
						},
					},
					Gui.Button "start"
					{
						Size = Vector2(316, 60),
						Location = Vector2(69, 444),
						BackgroundColor = ARGB(255, 255, 255, 255),
						blink = true,
						blinkwheelTimer = 0.6,
						Enable = false,
						FontSize = 18,
						Text = lang:GetText("开始强化"),
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_button_01_normal.dds", Vector4(80, 0, 80, 0)),
							HoverImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_button_01_hover.dds", Vector4(80, 0, 80, 0)),
							DownImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_button_01_down.dds", Vector4(80, 0, 80, 0)),
							DisabledImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_button_01_disabled.dds", Vector4(80, 0, 80, 0)),
							TwinkleImage  = Gui.Image("LobbyUI/Compose/lb_synthesis_common_button_01_hover.dds", Vector4(80, 0, 80, 0)),
						},
						EventClick = function(Sender, e)
							if rpc_string.playerItemId == 0 then
								MessageBox.ShowWithConfirm(lang:GetText("请放入需要强化的武器"))
								return
							end
							if rpc_string.strengthenItemId == 0 then
								MessageBox.ShowWithConfirm(lang:GetText("强化部件不能为空"))
								return
							end

							local ibbtn = ptr_cast(ui.qianghua:GetChildByIndex(1))
							if ibbtn.Enough then
								MessageBox.ShowWithTwoButtons(lang:GetText("你的强化部件不足,请购买"),lang:GetText("购买"),lang:GetText("取消"),
								function()
									qianghua_index = 1
									ShowRapid(1, 1)
								end,
								nil)
								return
							end
							
							if rpc_date_object.common.strength == MaxLevel then
								MessageBox.ShowWithTimer(2,lang:GetText("已强化到最高等级"))
								return
							end

							if rpc_date_object.common.strength >= success_level and success_level ~= -1 then
								MessageBox.ShowWithConfirm(lang:GetText("强化增幅能源等级必须大于当前强化等级\n使用无效"))
								return
							end

							if rpc_string.safeItemId == 0 and rpc_date_object.common.strength >= success_level and rpc_date_object.common.strength > 2 then
								MessageBox.ShowWithThreeButtons(lang:GetText("小心！此次强化未使用安定芯片\n可能造成退级损失哦~ 是否购买安定芯片"), lang:GetText("继续强化"), lang:GetText("购买"), lang:GetText("取消强化"),
								function()
									Strengthen(Sender)
								end,
								function()
									qianghua_index = 3
									ShowRapid(1, 3)
								end,
								nil)
								return
							end
							Strengthen(Sender)
						end
					},
				},
				
				Gui.Control "shengxing"
				{
					Size = Vector2(466, 519),
					Location = Vector2(3, 7),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/Compose/shengxing/lb_synthesis_strengthening_bg_01.dds", Vector4(125, 32, 126, 300)),
					},
					Gui.Control
					{
						Size = Vector2(466, 330),
						Location = Vector2(0, 0),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_bg_02.dds", Vector4(0, 0, 0, 0)),
						},
					},
					
					Gui.Control
					{
						Size = Vector2(44, 43),
						Location = Vector2(140, 45),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/Compose/shengxing/lb_synthesis_conversion_ico_01.dds", Vector4(0, 0, 0, 0)),
						},
					},
					
					Gui.Control
					{
						Size = Vector2(117, 89),
						Location = Vector2(20, 20),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/Compose/lb_synthesis_conversion_bg_03.dds", Vector4(0, 0, 0, 0)),
						},
						Gui.ItemBoxBtn "main_weapon"
						{
							Style = "Gui.ItemBoxBtn_ib",
							Size = Vector2(97, 69),
							Location = Vector2(10, 10),
							CanSelect = false,
							Skin = Gui.ItemBoxBtnSkin
							{
								NeutralNormalImage = nil,
								NeutralHoverImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_slot_flash.dds", Vector4(0, 0, 0, 0)),
								NeutralSelectedImage = nil,
								NeutralDisabledImage = nil,
								NeutralHighlightImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_slot_flash.dds", Vector4(0, 0, 0, 0)),
							},
							EventMouseUp = function(sender, e)
								if sender.ItemIcon then
									sender.ItemIcon = nil
									ui.main_weapon_star.Skin = Gui.ControlSkin{BackgroundImage = nil,}
									ui.main_weapon_lv.Skin = Gui.ControlSkin{BackgroundImage = nil,}
									if upstar[1].type == current_selected and upstar[1].page == current_page and upstar[1].cid == current_characters then
										local ibbtn
										if current_selected == 1 then
											ibbtn = ptr_cast(weapon_info_page.ctrl_ib_container:GetChildByIndex(upstar[1].index-1))
										elseif current_selected == 2 then
											ibbtn = ptr_cast(dress_info_page.ctrl_ib_container:GetChildByIndex(upstar[1].index-1))
										elseif current_selected == 3 then
											ibbtn = ptr_cast(accessories_info_page.ctrl_ib_container:GetChildByIndex(upstar[1].index-1))
										end
										-- ibbtn = ptr_cast(weapon_info_page.ctrl_ib_container:GetChildByIndex(upstar[1].index-1))
										rpc_date[upstar[1].index].common.quantity = rpc_date[upstar[1].index].common.quantity + 1
										local Control = ptr_cast(ibbtn:GetChildByIndex(2))
										L_LobbyMain.FillNumber(rpc_date[upstar[1].index].common.quantity, Control)
										ibbtn.ItemIcon.alpha = 255
									end
									Clean_upstar(1)
								end
								FillMachine4(0)
							end
						},
						Gui.Control "main_weapon_lv"
						{
							Size = Vector2(54,30),
							Location = Vector2(50, 45),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Enable = false,
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/Compose/shengxing/lb_synthesis_conversion_star_05.dds", Vector4(0, 0, 0, 0)),
							},
						},
						Gui.Control "main_weapon_star"
						{
							Size = Vector2(68, 12),
							Location = Vector2(30, 13),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Enable = false,
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/Compose/shengxing/lb_synthesis_conversion_star_05.dds", Vector4(0, 0, 0, 0)),
							},
						},
						-- Gui.Label "temp_main_exp"
						-- {
							-- Size = Vector2(80, 20),
							-- Location = Vector2(0, 5),
							-- FontSize = 12,
							-- TextAlign = "kAlignCenterTop",
							-- TextColor = ARGB(255, 0, 0, 0),
							-- Text = "0",
						-- },
					},
					
					Gui.Control
					{
						Size = Vector2(250 ,244),
						Location = Vector2(196,10),
						BackgroundColor = ARGB(255, 255, 255, 255),

						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/Compose/shengxing/lb_melting_bg_02.dds", Vector4(0, 0, 0, 0)),
						},
						Gui.FlowLayout
						{
							Size = Vector2(250 ,244),
							Location = Vector2(5,2),
							ControlAlign = "kAlignCenterMiddle",
							ControlSpace = 0,
							LineSpace = 0,
							create_ItemBtn_shengxing(2),
							create_ItemBtn_shengxing(3),
							create_ItemBtn_shengxing(4),
							create_ItemBtn_shengxing(5),
							create_ItemBtn_shengxing(6),
							create_ItemBtn_shengxing(7),
							create_ItemBtn_shengxing(8),
							create_ItemBtn_shengxing(9),
							create_ItemBtn_shengxing(10),
						},
					},
					
					Gui.TextArea
					{
						Size = Vector2(210, 150),
						Location = Vector2(15, 125),
						TextColor = ARGB(0, 255, 180, 104),
						FontSize = 16,
						Readonly = true,
						Fold = true,
						Text = lang:GetText("品质越高的装备获得更多的升星经验，相同的装备能获得5倍经验\n等级不能增加升星经验"),						
					},
					
					Gui.Control "Compare_BG_3"
					{
						Size = Vector2(316, 68),
						Location = Vector2(77, 255),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/Compose/lb_melting_bar02_bg.dds", Vector4(0, 0, 0, 0)),
						},

						Gui.ChangeControl "Compare_3"
						{
							Size = Vector2(0, 53),
							Normsize = Vector2(0,53),
							Location = Vector2(28, 6),
							NormLocation = Vector2(28, 6),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/Compose/lb_melting_bar02_content.dds", Vector4(262, 0, 0, 0)),
							},
							EventPlayEnd = function(Sender,e)
								Sender.Normsize = Sender.Size
							end
						},
						Gui.Control "Compare_3_full"
						{
							Size = Vector2(68, 68),
							Location = Vector2(120, 0),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Visible = false,
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_max_ico.dds", Vector4(0, 0, 0, 0)),
							},
						},
					},
					
					Gui.Control
					{
						Size = Vector2(431, 124),
						Location = Vector2(18, 335),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/Compose/lb_synthesis_strengthening_bg_03.dds", Vector4(0, 0, 0, 0)),
						},
						Gui.Control "text_shengxing"
						{
							Size = Vector2(431, 124),
							Location = Vector2(0, 5),
							BackgroundColor = ARGB(0, 255, 255, 255),
							Visible = false,
							Gui.Label
							{
								Style = "Gui.Label_Compose",
								Location = Vector2(30, 20),
							},
							Gui.Label
							{
								Style = "Gui.Label_Compose",
								Location = Vector2(220, 20),
							},
							Gui.Label
							{
								Style = "Gui.Label_Compose",
								Location = Vector2(30, 40),
							},
							Gui.Label
							{
								Style = "Gui.Label_Compose",
								Location = Vector2(220, 40),
							},
							Gui.Label
							{
								Style = "Gui.Label_Compose",
								Location = Vector2(30, 60),
							},
							Gui.Label
							{
								Style = "Gui.Label_Compose",
								Location = Vector2(220, 60),
							},
							Gui.Label
							{
								Style = "Gui.Label_Compose",
								Location = Vector2(30, 80),
							},
							Gui.Label
							{
								Style = "Gui.Label_Compose",
								Location = Vector2(220, 80),
							},
							
							Gui.Control "fangju_shengxing_hp"
							{
								Size = Vector2(102, 17),
								BackgroundColor = ARGB(255, 255, 255, 255),
								Location = Vector2(130, 45),
								Visible = false,
								Skin = Gui.ControlSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/Compose/shengxing/lb_synthesis_conversion_hp_01.dds", Vector4(0, 0, 0, 0)),
								},
							},
							
							Gui.Label "percent_shengxing"
							{
								Style = "Gui.Label_Compose",
								TextAlign = "kAlignCenterMiddle",
								TextColor = ARGB(255, 255, 110, 1),
								Size = Vector2(431, 20),
								Location = Vector2(0, 100),
							},

							Gui.CompareBar "compare_demage1_shengxing"
							{
								Visible = false,
								Size = Vector2(90, 14),
								Location = Vector2(85, 45),
								Icon = Gui.CompareIcon("LobbyUI/ToolTips/skin_bar02_BG.tga", "LobbyUI/ToolTips/skin_bar02_content.tga", "LobbyUI/ToolTips/skin_bar02_content.tga", "LobbyUI/ToolTips/skin_bar02_content.tga", Vector4(4,4,4,4), Vector4(4,4,4,4)),
							},
							Gui.Label "ctrl_demage_shengxing"
							{
								Size = Vector2(16, 24),
								Location = Vector2(186, 45),
								NormLocation = Vector2(186, 45),
								BackgroundColor = ARGB(255, 255, 255, 255),
								MoveLocation = Vector2(0,4),
								MoveWheelTime = 0.8,
								Skin = Gui.ControlSkin
								{
									BackgroundImage = nil,
								},
							},
							Gui.FlowLayout "star_shengxing"
							{
								Size = Vector2(140, 20),
								ControlSpace = 0,
								Location = Vector2(85, 60),
								create_star(),
								Gui.Label
								{
									Size = Vector2(100, 20),
									Location = Vector2(20, 0),
								},
							},
							Gui.CompareBar "compare_demage2_shengxing"
							{
								Visible = false,
								Size = Vector2(90, 14),
								Location = Vector2(310, 45),
								Icon = nil,
							},
							Gui.Label "ctrl_demage1_shengxing"
							{
								Size = Vector2(16, 24),
								Location = Vector2(411, 45),
								NormLocation = Vector2(411, 45),
								BackgroundColor = ARGB(255, 255, 255, 255),
								MoveLocation = Vector2(0,4),
								MoveWheelTime = 0.8,
								Visible = false,
								Skin = Gui.ControlSkin
								{
									BackgroundImage = nil,
								},
							},
							Gui.Label "ctrl_demage2_shengxing"
							{
								Size = Vector2(16, 24),
								Location = Vector2(311, 20),
								NormLocation = Vector2(311, 20),
								BackgroundColor = ARGB(255, 255, 255, 255),
								MoveLocation = Vector2(0,4),
								MoveWheelTime = 0.8,
								Skin = Gui.ControlSkin
								{
									BackgroundImage = nil,
								},
							},
							Gui.FlowLayout "star1_shengxing"
							{
								Size = Vector2(140, 20),
								ControlSpace = 0,
								Location = Vector2(310, 60),
								create_star(),
								Gui.Label
								{
									Size = Vector2(100, 20),
									Location = Vector2(20, 0),
								},
							},
							Gui.CheckBox "cbox_daily_shengxing_exp"
							{
								Location = Vector2(30, 85),
								TextColor = ARGB(255, 207, 221, 230),
								Size = Vector2(25,25),
								EventCheckChanged = function(sender, e)
									if upstar[1].pid ~= -1 and upstar[1].gstLevel < 5 then
										local num = 0
										local flag = false
										for i = 2, 10 do
											if upstar[i].pid ~= -1 then
												if upstar[i].sid == upstar[1].sid then
													num = num + upstar[i].gstExpAdd*5
												else
													num = num + upstar[i].gstExpAdd
												end
												flag = true	
											end
										end
										if flag then
											ui.start3.Enable = true
										else
											ui.start3.Enable = false
										end
										num = num + upstar[1].gstExp
										if sender.Check then
											num = num + everyDayExp[math.ceil(upstar[1].rareLevel/25)-1]
											ui.daily_exp_tip.Visible = true
											ui.daily_exp_tip.Text = lang:GetText("（花费")..everyDayCPoint[math.ceil(upstar[1].rareLevel/25)-1]..lang:GetText("C币获得")..everyDayExp[math.ceil(upstar[1].rareLevel/25)-1]..lang:GetText("经验）")
										else
											ui.daily_exp_tip.Visible = false											
										end
										Fill_Help()
										local per = num/upstar_AllExp[math.ceil(upstar[1].rareLevel/25)-1][upstar[1].gstLevel+1] * 120										
										local nextLevel = 0
										if per > 120 then
											per = 120											
											local pow = nil
											local speed = nil			
											if upstar[1].gstLevel < 5 and num > upstar_AllExp[math.ceil(upstar[1].rareLevel/25)-1][upstar[1].gstLevel+1]  then
												nextLevel = upstar[1].gstLevel+1				
											end	
											if upstar[1].gstLevel < 4 and num > upstar_AllExp[math.ceil(upstar[1].rareLevel/25)-1][upstar[1].gstLevel+1] + upstar_AllExp[math.ceil(upstar[1].rareLevel/25)-1][upstar[1].gstLevel+2] then
												nextLevel = upstar[1].gstLevel+2
											end	
											if upstar[1].gstLevel < 3 and num > upstar_AllExp[math.ceil(upstar[1].rareLevel/25)-1][upstar[1].gstLevel+1] + upstar_AllExp[math.ceil(upstar[1].rareLevel/25)-1][upstar[1].gstLevel+2] + upstar_AllExp[math.ceil(upstar[1].rareLevel/25)-1][upstar[1].gstLevel+3] then	
												nextLevel = upstar[1].gstLevel+3
											end	
											if upstar[1].gstLevel < 2 and num > upstar_AllExp[math.ceil(upstar[1].rareLevel/25)-1][upstar[1].gstLevel+1] + upstar_AllExp[math.ceil(upstar[1].rareLevel/25)-1][upstar[1].gstLevel+2] + upstar_AllExp[math.ceil(upstar[1].rareLevel/25)-1][upstar[1].gstLevel+3] + upstar_AllExp[math.ceil(upstar[1].rareLevel/25)-1][upstar[1].gstLevel+4] then	
												nextLevel = upstar[1].gstLevel+4
											end
											if upstar[1].gstLevel < 1 and num > upstar_AllExp[math.ceil(upstar[1].rareLevel/25)-1][upstar[1].gstLevel+1] + upstar_AllExp[math.ceil(upstar[1].rareLevel/25)-1][upstar[1].gstLevel+2] + upstar_AllExp[math.ceil(upstar[1].rareLevel/25)-1][upstar[1].gstLevel+3] + upstar_AllExp[math.ceil(upstar[1].rareLevel/25)-1][upstar[1].gstLevel+4] + upstar_AllExp[math.ceil(upstar[1].rareLevel/25)-1][upstar[1].gstLevel+5] then	
												nextLevel = upstar[1].gstLevel+5
											end											
											Label = ptr_cast(ui.text_shengxing:GetChildByIndex(2))
											Label.TextColor = ARGB(255, 0, 255, 68)
											ui.ctrl_demage_shengxing.Visible = true
											ui.ctrl_demage_shengxing.Skin = Gui.ControlSkin
											{
												BackgroundImage = Gui.Image("LobbyUI/ToolTips/lb_tooltips_jiantou_green.dds",Vector4(0, 0, 0, 0)),
											}
											if current_selected == 1 then
												ui.ctrl_demage_shengxing.Location = Vector2(186, 45)
												ui.ctrl_demage_shengxing.NormLocation = Vector2(186, 45)
											else
												ui.ctrl_demage_shengxing.Location = Vector2(186+20*upstar[1].gstLevel, 45)
												ui.ctrl_demage_shengxing.NormLocation = Vector2(136+20*upstar[1].gstLevel, 40)
											end											
											Label = ptr_cast(ui.text_shengxing:GetChildByIndex(3))											
											ui.ctrl_demage1_shengxing.Visible = false
											ui.ctrl_demage1_shengxing.Skin = Gui.ControlSkin
											{
												BackgroundImage = Gui.Image("LobbyUI/ToolTips/lb_tooltips_jiantou_green.dds",Vector4(0, 0, 0, 0)),
											}
											Label = ptr_cast(ui.text_shengxing:GetChildByIndex(1))
											Label.TextColor = ARGB(255, 0, 255, 68)
											ui.ctrl_demage2_shengxing.Visible = true
											ui.ctrl_demage2_shengxing.Skin = Gui.ControlSkin
											{
												BackgroundImage = Gui.Image("LobbyUI/ToolTips/lb_tooltips_jiantou_green.dds",Vector4(0, 0, 0, 0)),
											}
											Label = ptr_cast(ui.text_shengxing:GetChildByIndex(0))
											Label.TextColor = ARGB(255,  0, 255, 68)
											Label.Text = lang:GetText("星级：")..upstar[1].gstLevel.." → "..nextLevel										
										else											
											Label = ptr_cast(ui.text_shengxing:GetChildByIndex(0))
											Label.TextColor = ARGB(255,  255, 255, 255)
											Label.Text = lang:GetText("星级：")..upstar[1].gstLevel
										    ui.ctrl_demage_shengxing.Visible = false
										    Label = ptr_cast(ui.text_shengxing:GetChildByIndex(2))
											Label.TextColor = ARGB(255, 255, 255, 255)										 
											ui.ctrl_demage2_shengxing.Visible = false
											Label = ptr_cast(ui.text_shengxing:GetChildByIndex(1))
											Label.TextColor = ARGB(255,255, 255, 255)										
										end	
										   ui.Compare_3.Normsize = ui.Compare_3.Size
										   ui.Compare_3:Clear()
										   ui.Compare_3:InsertMovePoint(ui.Compare_3.Location,0.5,Vector2(262 * (per / 120), 53),ARGB(255,255,255,255))
										
									end
								end	
							},
							Gui.Label
							{
								Style = "Gui.Label_Compose",
								Location = Vector2(60, 85),
								Text = lang:GetText("每日一次增加经验"),
							},
							Gui.Label "daily_exp_tip"
							{
								Style = "Gui.Label_Compose",
								Location = Vector2(180, 85),
								Text = "",
								TextColor = ARGB(255, 255, 0, 0),
								Visible = false,
							},
						},
					},	
					
					Gui.Button "start3"
					{
						Size = Vector2(316, 60),
						Location = Vector2(69, 467),
						BackgroundColor = ARGB(255, 255, 255, 255),
						blink = true,
						Enable = false,
						blinkwheelTimer = 0.6,
						FontSize = 18,
						Text = lang:GetText("开始升星"),
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_button_01_normal.dds", Vector4(80, 0, 80, 0)),
							HoverImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_button_01_hover.dds", Vector4(80, 0, 80, 0)),
							DownImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_button_01_down.dds", Vector4(80, 0, 80, 0)),
							DisabledImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_button_01_disabled.dds", Vector4(80, 0, 80, 0)),
							TwinkleImage  = Gui.Image("LobbyUI/Compose/lb_synthesis_common_button_01_hover.dds", Vector4(80, 0, 80, 0)),
						},
						EventClick = function(Sender, e)
							local flag = 0
							for i = 2, 10 do
								if upstar[i].pid ~= -1 then
									if math.ceil(upstar[i].rareLevel/25) == 4 then
										flag = 2
										break
									end
								end
							end
							for i = 2, 10 do
								if upstar[i].pid ~= -1 then
									if math.ceil(upstar[i].rareLevel/25) == 5 then
										flag = 3
										break
									end
								end
							end
							for i = 2, 10 do
								if upstar[i].pid ~= -1 then
									if math.ceil(upstar[i].rareLevel/25) == 6 then
										flag = 4
										break
									end
								end
							end
							for i = 2, 10 do
								if upstar[i].pid ~= -1 then
									if upstar[i].strength > 0 then
										flag = 1
										break
									end
								end
							end
							if flag == 1 then
								Show_ShengxingWarn(lang:GetText("材料中有强化过的装备，升星后会消失"),"","",lang:GetText("是否继续?"),ARGB(255, 0, 0, 0))
							elseif flag == 2 then
								Show_ShengxingWarn(lang:GetText("材料中有"),lang:GetText("[稀有]"),lang:GetText("装备，升星后会消失"),lang:GetText("是否继续?"),ARGB(255,181,58,212))
							elseif flag == 3 then
								Show_ShengxingWarn(lang:GetText("材料中有"),lang:GetText("[大师]"),lang:GetText("装备，升星后会消失"),lang:GetText("是否继续?"),ARGB(255,255,96,0))
							elseif flag == 4 then
								Show_ShengxingWarn(lang:GetText("材料中有"),lang:GetText("[传说]"),lang:GetText("装备，升星后会消失"),lang:GetText("是否继续?"),ARGB(255,255,96,0))
							elseif flag == 0 then
								if upstar[1].pid ~= -1 then
									local args = {}
									args.pid = ptr_cast(game.CurrentState):GetCharacterId()
									args.mainItemId = upstar[1].pid
									args.toItemId = ""
									if ui.cbox_daily_shengxing_exp.Check == true then
										args.isFree = 1
									else
										args.isFree = 0
									end
									
									for i = 2, 10 do
										if upstar[i].pid ~= -1 then
											if args.toItemId == "" then
												args.toItemId = args.toItemId..upstar[i].pid
											else
												args.toItemId = args.toItemId..":"..upstar[i].pid
											end
										end
									end
									rpc.safecallload("two_to_one", args,
									function (data)
										modalFlash = ModalWindow.GetNew()
										modalFlash.screen.AllowEscToExit = false
										modalFlash.root.Size = Vector2(776, 440)
										flash.root.Parent = modalFlash.root
										flash.Flash.Text = "synthesis_success"
										gui:PlayAudio("kUIA_COMPOUND_SUCCEED_SWF")
										flash.Flash:CleanData()
										flash.Flash.UseTime = true
										flash.Flash.Visible = true
										for i = 2, 10 do
											Clean_upstar(i)
											-- if i == 1 then
												-- ui.main_weapon.ItemIcon = nil
											-- else
												ui["Item_btn_shengxing_"..i].ItemIcon = nil
											-- end
										end
										FillStorage()
										num = data.mainItem.gstExp
										upstar[1].display = data.mainItem.display
										if upstar[1].gstLevel ~= data.mainItem.gstLevel then
											FillStarCongratulation(upstar[1].gstLevel,data.mainItem.gstLevel,data.mainItem.common.star)
											congratulationmodal = ModalWindow.GetNew()
											congratulationmodal.root.Size = Vector2(800,600)
											congratulation.root.Parent = congratulationmodal.root
											-- if rpc_date_object.common.strength == L_LobbyMain.PersonalInfo_data.maxLevel then
												-- gui:PlayAudio("kUIA_COMPOUND_SUCCEED_SWF_EX")
											-- end
										end	
										upstar[1].gstExp = data.mainItem.gstExp
										upstar[1].gstLevel = data.mainItem.gstLevel
										upstar[1].star = data.mainItem.common.star
										ui.main_weapon_star.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/Compose/shengxing/lb_synthesis_conversion_star_0"..upstar[1].gstLevel..".dds", Vector4(0, 0, 0, 0)),}
										if upstar[1].strength > 0 then
											ui.main_weapon_lv.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/badge_lv"..upstar[1].strength.."_small.dds", Vector4(0, 0, 0, 0)),}
										else
											ui.main_weapon_lv.Skin = Gui.ControlSkin{BackgroundImage = nil,}
										end
										ui.Compare_3_full.Visible = false	
										if upstar[1].gstLevel < 5 then
											local per = num/upstar_AllExp[math.ceil(data.mainItem.common.rareLevel/25)-1][data.mainItem.gstLevel+1] * 120
											ui.Compare_3.Normsize = ui.Compare_3.Size
											ui.Compare_3:Clear()
											ui.Compare_3:InsertMovePoint(ui.Compare_3.Location,0.5,Vector2(262 * (per / 120), 53),ARGB(255,255,255,255))
										elseif upstar[1].gstLevel == 5 then
											ui.Compare_3.Normsize = ui.Compare_3.Size
											ui.Compare_3:Clear()
											ui.Compare_3:InsertMovePoint(ui.Compare_3.Location,0.5,Vector2(262, 53),ARGB(255,255,255,255))
											ui.Compare_3_full.Visible = true												
										else
											ui.Compare_3.Normsize = ui.Compare_3.Size
											ui.Compare_3:Clear()
											ui.Compare_3:InsertMovePoint(ui.Compare_3.Location,0.5,Vector2(0, 53),ARGB(255,255,255,255))
										end	
										
										ui.start3.Enable = false
										ui.text_shengxing.Visible = true
										Label = ptr_cast(ui.text_shengxing:GetChildByIndex(1))
										Label.TextColor = ARGB(255, 213, 255, 254)
										Label.Text = lang:GetText("战斗力：")..data.mainItem.common.star
										upstar[1].star = data.mainItem.common.star
										Label = ptr_cast(ui.text_shengxing:GetChildByIndex(0))
										Label.TextColor = ARGB(255, 213, 255, 254)
										Label.Text = lang:GetText("星级：")..data.mainItem.gstLevel
										-- Label = ptr_cast(ui.text:GetChildByIndex(6))
										-- Label.TextColor = ARGB(255, 213, 255, 254)
										-- Label.Text = lang:GetText("开放的可钻孔数：")..rpc_date_object.common.holeNum
										local pow = nil
										local speed = nil
										if current_selected == 1 then
											Label = ptr_cast(ui.text_shengxing:GetChildByIndex(2))
											Label.Text = lang:GetText("攻击力：")
											upstar[1].damange = data.mainItem.performance.damange
											upstar[1].damange_add = data.mainItem.performance.damange_add
											ui.ctrl_demage_shengxing.Visible = false
											pow = math.floor((data.mainItem.performance.damange + data.mainItem.performance.damange_add) * 10) / 10
											Label.TextColor = ARGB(255, 213, 255, 254)

											ui.compare_demage1_shengxing.Visible = true
											if data.mainItem.wid == 4 then
												pow = pow * 3
											end
											local temp = (pow - (pow % 50)) / 50 + 1
											if temp > 1 then
												ui.star_shengxing.Visible = true
												local con = ptr_cast(ui.star_shengxing:GetChildByIndex(1))
												con.Text = " x  "..(temp - 1)
											else
												ui.star.Visible = false
											end
											if pow % 50 == 0 then
												temp = temp - 1
												ui.compare_demage1_shengxing.Icon = compareIcon2[temp]
												ui.compare_demage1_shengxing:ResetBaseValue(100)
											else
												if temp > 7 then
													temp = 7
												end
												ui.compare_demage1_shengxing.Icon = compareIcon2[temp]
												ui.compare_demage1_shengxing:ResetBaseValue(pow % 50 * 2)
											end
											ui.fangju_shengxing_hp.Visible = false
										else
											ui.ctrl_demage_shengxing.Visible = false
											upstar[1].cBloodAdd = data.mainItem.common.cBloodAdd 
											upstar[1].cBloodAdd_add = data.mainItem.common.cBloodAdd_add 
											Label = ptr_cast(ui.text_shengxing:GetChildByIndex(2))
											Label.Text = lang:GetText("增加血量：")..precision(upstar[1].cBloodAdd + upstar[1].cBloodAdd_add).."%"
											Label.TextColor = ARGB(255, 213, 255, 254)
											ui.fangju_shengxing_hp.Visible = true
											ui.star_shengxing.Visible = false
											ui.compare_demage1_shengxing.Visible = false
											if upstar[1].gstLevel > 0 then
												ui.fangju_shengxing_hp.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/Compose/shengxing/lb_synthesis_conversion_hp_0"..upstar[1].gstLevel..".dds", Vector4(0, 0, 0, 0)),}
											else
												ui.fangju_shengxing_hp.Visible = false
											end	
										end										
										
										if current_selected == 1 then
											Label = ptr_cast(ui.text_shengxing:GetChildByIndex(3))
											Label.Text = lang:GetText("攻击速度")..lang:GetText("：")

											upstar[1].speed = data.mainItem.performance.speed
											upstar[1].speed_add = data.mainItem.performance.speed_add
											Label.TextColor = ARGB(255, 213, 255, 254)
											speed = math.floor((data.mainItem.performance.speed + data.mainItem.performance.speed_add) * 10) / 10
											ui.ctrl_demage1_shengxing.Visible = false
											ui.ctrl_demage2_shengxing.Visible = false

											ui.compare_demage2_shengxing.Visible = true
											local temp = (speed - (speed % 50)) / 50 + 1
											if temp > 1 then
												ui.star1_shengxing.Visible = true
												local con = ptr_cast(ui.star1_shengxing:GetChildByIndex(1))
												con.Text = " x  "..(temp - 1)
											else
												ui.star1_shengxing.Visible = false
											end
											if speed % 50 == 0 then
												temp = temp - 1
												ui.compare_demage2_shengxing.Icon = compareIcon2[temp + 7]
												ui.compare_demage2_shengxing:ResetBaseValue(100)
											else
												if temp > 7 then
													temp = 7
												end
												ui.compare_demage2_shengxing.Icon = compareIcon2[temp + 7]
												ui.compare_demage2_shengxing:ResetBaseValue(speed % 50 * 2)
											end
										else
											Label = ptr_cast(ui.text_shengxing:GetChildByIndex(3))
											Label.Visible = false
											ui.ctrl_demage1_shengxing.Visible = false
											ui.ctrl_demage2_shengxing.Visible = false
											ui.compare_demage2_shengxing.Visible = false
											ui.star1_shengxing.Visible = false
										end										
										if ui.cbox_daily_shengxing_exp.Check == true then
											ui.cbox_daily_shengxing_exp.Check = false
											ui.cbox_daily_shengxing_exp.Enable = false
											ui.Help_part11.Visible = false
											ui.daily_exp_tip.Visible = false
										end
									end)
								end
							end
						end
					},
				},

				Gui.Control "gaizhuang"
				{
					Size = Vector2(466, 519),
					Location = Vector2(3, 7),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/Compose/lb_synthesis_mosaic_bg_01.dds", Vector4(114, 20, 114, 20)),
					},
					Gui.Control
					{
						Size = Vector2(466, 352),
						Location = Vector2(0, 0),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_bg_02.dds", Vector4(0, 0, 0, 0)),
						},
					},
					Gui.Control
					{
						Size = Vector2(312, 122),
						Location = Vector2(76, 76),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_bg_01_c.dds.dds", Vector4(0, 0, 0, 0)),
						},
					},			
			
					create_btn(69, 12, 1),
					create_btn(159, 12, 2),
					create_btn(249, 12, 3),
					create_btn(339, 12, 4),
					create_btn(6, 100, 5),
					create_btn(376, 146, 6),
					create_button(77, 87, 1),
					create_button(167, 87, 2),
					create_button(257, 87, 3),
					create_button(347, 87, 4),
					create_button(14, 175, 5),
					create_button(384, 221, 6),

					Gui.Control
					{
						Size = Vector2(288, 164),
						Location = Vector2(93, 142),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/Compose/lb_synthesis_strengthening_bg_02.dds", Vector4(40, 0, 40, 0)),
						},
						Gui.ItemBoxBtn "object1"
						{
							Style = "Gui.ItemBoxBtn_ib",
							Size = Vector2(176, 126),
							Location = Vector2(56, 19),
							CanSelect = false,
							Skin = Gui.ItemBoxBtnSkin
							{
								NeutralNormalImage = nil,
								NeutralHoverImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_slot_flash.dds", Vector4(0, 0, 0, 0)),
								NeutralSelectedImage = nil,
								NeutralDisabledImage = nil,
								NeutralHighlightImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_slot_flash.dds", Vector4(0, 0, 0, 0)),
							},
							EventMouseUp = function(Sender,e)
								ui.sucai.blink = false
								ui.arrows.Visible = false
								if current_selected == 1 and current_page == Weapon_table.page and Weapon_table.cid == current_characters and Weapon_table.type == 1 then
									local btn = ptr_cast(weapon_info_page.ctrl_ib_container:GetChildByIndex(Weapon_table.index - 1))
									btn.ItemIcon.alpha = 255
								elseif current_selected == 2 and current_page == Weapon_table.page and Weapon_table.cid == current_characters and Weapon_table.type == 2 then
									local btn = ptr_cast(dress_info_page.ctrl_ib_container:GetChildByIndex(Weapon_table.index - 1))
									btn.ItemIcon.alpha = 255
								elseif current_selected == 3 and current_page == Weapon_table.page and Weapon_table.cid == current_characters and Weapon_table.type == 3 then
									local btn = ptr_cast(accessories_info_page.ctrl_ib_container:GetChildByIndex(Weapon_table.index - 1))
									btn.ItemIcon.alpha = 255
								end
								rpc_slotting.playerItemId = 0
								rpc_slotting.index = 0
								rpc_insert = {pid = ptr_cast(game.CurrentState):GetCharacterId(), playerItemId = 0, index = 0, propertyItemId = 0}
								rpc_remove = {pid = ptr_cast(game.CurrentState):GetCharacterId(), playerItemId = 0, index = 0}
								Clean_Weapon_table()
								ui.object1.ItemIcon = nil
								local ibbtn = ptr_cast(ui.object1:GetChildByIndex(2))
								ibbtn.Visible = false
								ibbtn = ptr_cast(ui.object1:GetChildByIndex(3))
								ibbtn.Visible = false
								rpc_date_object = nil
								FillMachine1(0)
								for i = 1, 6 do
									local ibbtn = ptr_cast(ui.gaizhuang:GetChildByIndex(i + 1))
									ibbtn.ItemIcon = nil
									ibbtn.Hint = ""
									ibbtn.Skin = ItemBoxBtn_Compose_b
									local ibbtn = ptr_cast(ui.gaizhuang:GetChildByIndex(i + 7))
									ibbtn.Enable = false
									ibbtn.Text = lang:GetText("改装")
								end
							end,
							Gui.Control
							{
								Size = Vector2(54,30),
								Location = Vector2(115, 91),
								BackgroundColor = ARGB(255, 255, 255, 255),
								Visible = false,
							},
							Gui.Control
							{
								Size = Vector2(102,17),
								Location = Vector2(45, 5),
								BackgroundColor = ARGB(255, 255, 255, 255),
								Visible = false,
							},
						},
					},

					Gui.ItemBoxBtn "dakong"
					{
						Style = "Gui.ItemBoxBtn_Compose",
						Size = Vector2(100, 99),
						Location = Vector2(3, 225),
						Padding = Vector4(12, 12, 12, 12),
						CanSelect = false,
						Skin = Gui.ItemBoxBtnSkin
						{
							NeutralNormalImage = Gui.Image("LobbyUI/Compose/lb_synthesis_strengthening_slot_04.dds", Vector4(0, 0, 0, 0)),
							NeutralHoverImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_slot_flash_1.dds", Vector4(0, 0, 0, 0)),
							NeutralSelectedImage = Gui.Image("LobbyUI/Compose/lb_synthesis_strengthening_slot_04.dds", Vector4(0, 0, 0, 0)),
							NeutralDisabledImage = nil,
							NeutralHighlightImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_slot_flash_1.dds", Vector4(0, 0, 0, 0)),
						},
						EventMouseUp = function(Sender,e)
							Sender.ItemIcon = nil
							control = ptr_cast(Sender:GetChildByIndex(2))
							control.Visible = false
							if current_selected > 3 and current_page == hole.page then
								if material_info_page then
									local btn = ptr_cast(material_info_page.ctrl_ib_container:GetChildByIndex(hole.index - 1))
									btn.ItemIcon.alpha = 255
								end
							end
							Clean_hole()
							rpc_slotting.sloterItemId = 0
						end,
						Gui.Control
						{
							Size = Vector2(70, 16),
							Location = Vector2(29, 78),
							BackgroundColor = ARGB(0, 255, 255, 255),
							Gui.Control "c1"
							{
								Size = Vector2(20, 16),
								Location = Vector2(5, 0),
								BackgroundColor = ARGB(255, 255, 255, 255),
								Visible = false,
							},
							Gui.Control "c2"
							{
								Size = Vector2(20, 16),
								Location = Vector2(20, 0),
								BackgroundColor = ARGB(255, 255, 255, 255),
								Visible = false,
							},
							Gui.Control "c3"
							{
								Size = Vector2(20, 16),
								Location = Vector2(35, 0),
								BackgroundColor = ARGB(255, 255, 255, 255),
								Visible = false,
							},
							Gui.Control "c4"
							{
								Size = Vector2(20, 16),
								Location = Vector2(50, 0),
								BackgroundColor = ARGB(255, 255, 255, 255),
								Visible = false,
							},
						},
					},
					Gui.Button
					{
						Size = Vector2(72, 20),
						Text = lang:GetText("购买"),
						TextColor = ARGB(255, 37, 37, 37),
						HighlightTextColor = ARGB(255, 37, 37, 37),
						FontSize = 20,
						Padding = Vector4(0, 0, 0, 4),
						Location = Vector2(17, 319),
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/Compose/lb_synthesis_mosaic_button_normal.dds", Vector4(0, 0, 0, 0)),
							HoverImage = Gui.Image("LobbyUI/Compose/lb_synthesis_mosaic_button_hover.dds", Vector4(0, 0, 0, 0)),
							DownImage = Gui.Image("LobbyUI/Compose/lb_synthesis_mosaic_button_down.dds", Vector4(0, 0, 0, 0)),
						},
						EventClick = function()
							ShowRapid(1, 1)
						end
					},

					Gui.Control
					{
						Size = Vector2(434, 149),
						Location = Vector2(15, 337),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/Compose/lb_synthesis_mosaic_bg_02.dds", Vector4(0, 0, 0, 0)),
						},
						Gui.Control "main_2"
						{
							Size = Vector2(434, 158),
							Location = Vector2(0, 0),
							BackgroundColor = ARGB(0, 255, 255, 255),
							Gui.Label "count"
							{
								Size = Vector2(434, 19),
								Location = Vector2(0, 0),
								BackgroundColor = ARGB(0, 255, 255, 255),
								TextColor = ARGB(255, 245, 181, 54),
								TextAlign = "kAlignCenterMiddle",
								FontSize = 16,
							},
							Gui.FlowLayout "desc"
							{
								Size = Vector2(434, 120),
								Location = Vector2(0, 19),
								ControlSpace = 0,
								LineSpace = 0,
								Gui.Label
								{
									Size = Vector2(434, 20),
									TextColor = ARGB(255, 213, 255, 254),
									FontSize = 12,
									TextAlign = "kAlignLeftMiddle",
								},
								Gui.Label
								{
									Size = Vector2(434, 20),
									TextColor = ARGB(255, 213, 255, 254),
									FontSize = 12,
									TextAlign = "kAlignLeftMiddle",
								},
								Gui.Label
								{
									Size = Vector2(434, 20),
									TextColor = ARGB(255, 213, 255, 254),
									FontSize = 12,
									TextAlign = "kAlignLeftMiddle",
								},
								Gui.Label
								{
									Size = Vector2(434, 20),
									TextColor = ARGB(255, 213, 255, 254),
									FontSize = 12,
									TextAlign = "kAlignLeftMiddle",
								},
								Gui.Label
								{
									Size = Vector2(434, 20),
									TextColor = ARGB(255, 213, 255, 254),
									FontSize = 12,
									TextAlign = "kAlignLeftMiddle",
								},
								Gui.Label
								{
									Size = Vector2(434, 20),
									TextColor = ARGB(255, 213, 255, 254),
									FontSize = 12,
									TextAlign = "kAlignLeftMiddle",
								},
							},
						},
					},
				},
				
				Gui.Control "zhuanhuan"
				{
					Size = Vector2(466, 497),
					Location = Vector2(3, 30),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/Compose/lb_synthesis_conversion_bg_01.dds", Vector4(125, 32, 126, 80)),
					},
					Gui.Control
					{
						Size = Vector2(466, 196),
						Location = Vector2(0, 0),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_bg_02.dds", Vector4(0, 0, 0, 0)),
						},
						Gui.Control
						{
							Size = Vector2(334, 68),
							Location = Vector2(65, 120),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_bg_01_a.dds", Vector4(40, 0, 40, 0)),
							},
						},
						Gui.Control "X1"
						{
							Size = Vector2(72, 36),
							Location = Vector2(199, 49),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/Compose/lb_synthesis_conversion_ico.dds", Vector4(0, 0, 0, 0)),
							},
						},
						Gui.Control "X"
						{
							Visible = false,
							Size = Vector2(56, 56),
							Location = Vector2(207, 47),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/Compose/lb_synthesis_conversion_ico_x.dds", Vector4(0, 0, 0, 0)),
							},
						},
						Gui.Control
						{
							Size = Vector2(176, 132),
							Location = Vector2(14, 17),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/Compose/lb_synthesis_conversion_bg_03.dds", Vector4(0, 0, 0, 0)),
							},
							Gui.ItemBoxBtn "object2"
							{
								Style = "Gui.ItemBoxBtn_ib",
								Size = Vector2(142, 102),
								Location = Vector2(17, 15),
								CanSelect = false,
								Skin = Gui.ItemBoxBtnSkin
								{
									NeutralNormalImage = nil,
									NeutralHoverImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_slot_flash.dds", Vector4(0, 0, 0, 0)),
									NeutralSelectedImage = nil,
									NeutralDisabledImage = nil,
									NeutralHighlightImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_slot_flash.dds", Vector4(0, 0, 0, 0)),
								},
								EventMouseUp = function(Sender,e)
									Sender.ItemIcon = nil
									local ibbtn = ptr_cast(ui.object2:GetChildByIndex(2))
									ibbtn.Visible = false
									ibbtn = ptr_cast(ui.object2:GetChildByIndex(3))
									ibbtn.Visible = false
									ui.start1.Enable = false
									if current_selected < 4 and current_page == convert[1].page then
										if current_selected == 1 and current_page == convert[1].page and convert[1].cid == current_characters and convert[1].type == 1 then
											local btn = ptr_cast(weapon_info_page.ctrl_ib_container:GetChildByIndex(convert[1].index - 1))
											btn.ItemIcon.alpha = 255
										elseif current_selected == 2 and current_page == convert[1].page and convert[1].cid == current_characters and convert[1].type == 2 then
											local btn = ptr_cast(dress_info_page.ctrl_ib_container:GetChildByIndex(convert[1].index - 1))
											btn.ItemIcon.alpha = 255
										elseif current_selected == 3 and current_page == convert[1].page and convert[1].cid == current_characters and convert[1].type == 3 then
											local btn = ptr_cast(accessories_info_page.ctrl_ib_container:GetChildByIndex(convert[1].index - 1))
											btn.ItemIcon.alpha = 255
										end
									end
									rpc_convert.fromItemId = 0
									Clean_convert(1)
									rpc_date_object_1[1] = nil
									FillMachine2(0, 1)
								end,
								Gui.Control
								{
									Size = Vector2(54,30),
									Location = Vector2(85, 67),
									BackgroundColor = ARGB(255, 255, 255, 255),
									Visible = false,
								},
								Gui.Control
								{
									Size = Vector2(102,17),
									Location = Vector2(25, 5),
									BackgroundColor = ARGB(255, 255, 255, 255),
									Visible = false,
								},
							},
						},
						
						Gui.Label "zhuanghuan_xingji_tips"
						{
							Size = Vector2(100, 50),
							Location = Vector2(180, 90),
							TextColor = ARGB(255, 255, 0, 0),
							FontSize = 16,
							TextAlign = "kAlignCenterMiddle",
							Text = lang:GetText("星级\n不转换"),
							Visible = false,
						},
						
						Gui.Control
						{
							Size = Vector2(176, 132),
							Location = Vector2(272, 17),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/Compose/lb_synthesis_conversion_bg_03.dds", Vector4(0, 0, 0, 0)),
							},
							Gui.ItemBoxBtn "object3"
							{
								Style = "Gui.ItemBoxBtn_ib",
								Size = Vector2(142, 102),
								Location = Vector2(17, 15),
								CanSelect = false,
								Skin = Gui.ItemBoxBtnSkin
								{
									NeutralNormalImage = nil,
									NeutralHoverImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_slot_flash.dds", Vector4(0, 0, 0, 0)),
									NeutralSelectedImage = nil,
									NeutralDisabledImage = nil,
									NeutralHighlightImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_slot_flash.dds", Vector4(0, 0, 0, 0)),
								},
								EventMouseUp = function(Sender,e)
									Sender.ItemIcon = nil
									local ibbtn = ptr_cast(ui.object3:GetChildByIndex(2))
									ibbtn.Visible = false
									ibbtn = ptr_cast(ui.object3:GetChildByIndex(3))
									ibbtn.Visible = false
									ui.start1.Enable = false
									if current_selected < 4 and current_page == convert[2].page then
										if current_selected == 1 and current_page == convert[2].page and convert[2].cid == current_characters and convert[2].type == 1 then
											local btn = ptr_cast(weapon_info_page.ctrl_ib_container:GetChildByIndex(convert[2].index - 1))
											btn.ItemIcon.alpha = 255
										elseif current_selected == 2 and current_page == convert[2].page and convert[2].cid == current_characters and convert[2].type == 2 then
											local btn = ptr_cast(dress_info_page.ctrl_ib_container:GetChildByIndex(convert[2].index - 1))
											btn.ItemIcon.alpha = 255
										elseif current_selected == 3 and current_page == convert[2].page and convert[2].cid == current_characters and convert[2].type == 3 then
											local btn = ptr_cast(accessories_info_page.ctrl_ib_container:GetChildByIndex(convert[2].index - 1))
											btn.ItemIcon.alpha = 255
										end
									end
									Clean_convert(2)
									rpc_convert.toItemId = 0
									rpc_date_object_1[2] = nil
									FillMachine2(0, 1)
								end,
								Gui.Control
								{
									Size = Vector2(54,30),
									Location = Vector2(85, 67),
									BackgroundColor = ARGB(255, 255, 255, 255),
									Visible = false,
								},
								Gui.Control
								{
									Size = Vector2(102,17),
									Location = Vector2(25, 5),
									BackgroundColor = ARGB(255, 255, 255, 255),
									Visible = false,
								},
							},
						},
					},
					Gui.Control
					{
						Size = Vector2(431, 234),
						Location = Vector2(16, 209),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/Compose/lb_synthesis_conversion_bg_02.dds", Vector4(0, 0, 0, 0)),
						},
						Gui.Control "main_3"
						{
							Visible = false,
							Size = Vector2(431, 226),
							Location = Vector2(0, 0),
							BackgroundColor = ARGB(0, 255, 255, 255),
							Gui.Label
							{
								Size = Vector2(431, 20),
								Location = Vector2(0, 5),
								TextAlign = "kAlignCenterMiddle",
								TextColor = ARGB(255, 245, 181, 54),
								Text = lang:GetText("转换后数据参考"),
								FontSize = 16,
							},
							Gui.FlowLayout "desc1"
							{
								Visible = false,
								Size = Vector2(215, 206),
								Location = Vector2(0, 35),
								LineSpace = 3,
								Gui.Label
								{
									Size = Vector2(217, 16),
									TextColor = ARGB(255, 213, 255, 254),
									FontSize = 14,
									TextAlign = "kAlignLeftMiddle",
								},
								Gui.Label
								{
									Size = Vector2(217, 16),
									TextColor = ARGB(255, 213, 255, 254),
									FontSize = 14,
									TextAlign = "kAlignLeftMiddle",
								},
								Gui.Label
								{
									Size = Vector2(217, 16),
									TextColor = ARGB(255, 213, 255, 254),
									FontSize = 14,
									TextAlign = "kAlignLeftMiddle",
								},
								Gui.Label
								{
									Size = Vector2(217, 16),
									TextColor = ARGB(255, 213, 255, 254),
									FontSize = 14,
									TextAlign = "kAlignLeftMiddle",
								},
								Gui.Label
								{
									Size = Vector2(217, 16),
									TextColor = ARGB(255, 213, 255, 254),
									FontSize = 14,
									TextAlign = "kAlignLeftMiddle",
								},
								Gui.Label
								{
									Size = Vector2(217, 16),
									TextColor = ARGB(255, 213, 255, 254),
									FontSize = 14,
									TextAlign = "kAlignLeftMiddle",
								},
								Gui.Label
								{
									Size = Vector2(217, 16),
									TextColor = ARGB(255, 213, 255, 254),
									FontSize = 14,
									TextAlign = "kAlignLeftMiddle",
								},
								Gui.Label
								{
									Size = Vector2(217, 16),
									TextColor = ARGB(255, 213, 255, 254),
									FontSize = 14,
									TextAlign = "kAlignLeftMiddle",
								},
								Gui.Label
								{
									Size = Vector2(217, 16),
									TextColor = ARGB(255, 213, 255, 254),
									FontSize = 14,
									TextAlign = "kAlignLeftMiddle",
								},
								Gui.Label
								{
									Size = Vector2(217, 16),
									TextColor = ARGB(255, 213, 255, 254),
									FontSize = 14,
									TextAlign = "kAlignLeftMiddle",
								},
							},
							Gui.CompareBar "compare_demage3"
							{
								Size = Vector2(90, 14),
								Location = Vector2(85, 113),
								Icon = Gui.CompareIcon("LobbyUI/ToolTips/skin_bar02_BG.tga", "LobbyUI/ToolTips/skin_bar02_content.tga", "LobbyUI/ToolTips/skin_bar02_content.tga", "LobbyUI/ToolTips/skin_bar02_content.tga", Vector4(4,4,4,4), Vector4(4,4,4,4)),
							},
							Gui.Label "ctrl_demage2"
							{
								Size = Vector2(217, 16),
								Location = Vector2(180, 112),
								TextColor = ARGB(255, 213, 255, 254),
								FontSize = 12,
								TextAlign = "kAlignLeftMiddle",
							},
							Gui.FlowLayout "star2"
							{
								Size = Vector2(140, 20),
								ControlSpace = 0,
								Location = Vector2(90, 127),
								create_star(),
								Gui.Label
								{
									Size = Vector2(100, 20),
									Location = Vector2(20, 0),
								},
							},
							Gui.CompareBar "compare_demage4"
							{
								Size = Vector2(90, 14),
								Location = Vector2(85, 153),
								Icon = Gui.CompareIcon("LobbyUI/ToolTips/skin_bar02_BG.tga", "LobbyUI/ToolTips/skin_bar02_content.tga", "LobbyUI/ToolTips/skin_bar02_content.tga", "LobbyUI/ToolTips/skin_bar02_content.tga", Vector4(4,4,4,4), Vector4(4,4,4,4)),
							},
							Gui.Label "ctrl_demage3"
							{
								Size = Vector2(217, 16),
								Location = Vector2(180, 152),
								TextColor = ARGB(255, 213, 255, 254),
								FontSize = 12,
								TextAlign = "kAlignLeftMiddle",
							},
							Gui.FlowLayout "star3"
							{
								Size = Vector2(140, 20),
								ControlSpace = 0,
								Location = Vector2(90, 167),
								create_star(),
								Gui.Label
								{
									Size = Vector2(100, 20),
									Location = Vector2(20, 0),
								},
							},
							Gui.FlowLayout "desc2"
							{
								Visible = false,
								Size = Vector2(215, 206),
								Location = Vector2(216, 35),
								LineSpace = 3,
								Gui.Label
								{
									Size = Vector2(217, 16),
									TextColor = ARGB(255, 213, 255, 254),
									FontSize = 14,
									TextAlign = "kAlignLeftMiddle",
								},
								Gui.Label
								{
									Size = Vector2(217, 16),
									TextColor = ARGB(255, 213, 255, 254),
									FontSize = 14,
									TextAlign = "kAlignLeftMiddle",
								},
								Gui.Label
								{
									Size = Vector2(217, 16),
									TextColor = ARGB(255, 213, 255, 254),
									FontSize = 14,
									TextAlign = "kAlignLeftMiddle",
								},
								Gui.Label
								{
									Size = Vector2(217, 16),
									TextColor = ARGB(255, 213, 255, 254),
									FontSize = 14,
									TextAlign = "kAlignLeftMiddle",
								},
								Gui.Label
								{
									Size = Vector2(217, 16),
									TextColor = ARGB(255, 213, 255, 254),
									FontSize = 14,
									TextAlign = "kAlignLeftMiddle",
								},
								Gui.Label
								{
									Size = Vector2(217, 16),
									TextColor = ARGB(255, 213, 255, 254),
									FontSize = 14,
									TextAlign = "kAlignLeftMiddle",
								},
								Gui.Label
								{
									Size = Vector2(217, 16),
									TextColor = ARGB(255, 213, 255, 254),
									FontSize = 14,
									TextAlign = "kAlignLeftMiddle",
								},
								Gui.Label
								{
									Size = Vector2(217, 16),
									TextColor = ARGB(255, 213, 255, 254),
									FontSize = 14,
									TextAlign = "kAlignLeftMiddle",
								},
								Gui.Label
								{
									Size = Vector2(217, 16),
									TextColor = ARGB(255, 213, 255, 254),
									FontSize = 14,
									TextAlign = "kAlignLeftMiddle",
								},
								Gui.Label
								{
									Size = Vector2(217, 16),
									TextColor = ARGB(255, 213, 255, 254),
									FontSize = 14,
									TextAlign = "kAlignLeftMiddle",
								},
							},
							Gui.CompareBar "compare_demage5"
							{
								Size = Vector2(90, 14),
								Location = Vector2(301, 113),
								Icon = Gui.CompareIcon("LobbyUI/ToolTips/skin_bar02_BG.tga", "LobbyUI/ToolTips/skin_bar02_content.tga", "LobbyUI/ToolTips/skin_bar02_content.tga", "LobbyUI/ToolTips/skin_bar02_content.tga", Vector4(4,4,4,4), Vector4(4,4,4,4)),
							},
							Gui.Label "ctrl_demage4"
							{
								Size = Vector2(217, 16),
								Location = Vector2(391, 112),
								TextColor = ARGB(255, 213, 255, 254),
								FontSize = 12,
								TextAlign = "kAlignLeftMiddle",
							},
							Gui.FlowLayout "star4"
							{
								Size = Vector2(140, 20),
								ControlSpace = 0,
								Location = Vector2(306, 127),
								create_star(),
								Gui.Label
								{
									Size = Vector2(100, 20),
									Location = Vector2(20, 0),
								},
							},
							Gui.CompareBar "compare_demage6"
							{
								Size = Vector2(90, 14),
								Location = Vector2(301, 153),
								Icon = Gui.CompareIcon("LobbyUI/ToolTips/skin_bar02_BG.tga", "LobbyUI/ToolTips/skin_bar02_content.tga", "LobbyUI/ToolTips/skin_bar02_content.tga", "LobbyUI/ToolTips/skin_bar02_content.tga", Vector4(4,4,4,4), Vector4(4,4,4,4)),
							},
							Gui.Label "ctrl_demage5"
							{
								Size = Vector2(217, 16),
								Location = Vector2(391, 152),
								TextColor = ARGB(255, 213, 255, 254),
								FontSize = 12,
								TextAlign = "kAlignLeftMiddle",
							},
							Gui.FlowLayout "star5"
							{
								Size = Vector2(140, 20),
								ControlSpace = 0,
								Location = Vector2(306, 167),
								create_star(),
								Gui.Label
								{
									Size = Vector2(100, 20),
									Location = Vector2(20, 0),
								},
							},
						},
					},
					Gui.Control "left_3"
					{
						Size = Vector2(40, 28),
						Location = Vector2(130, 160),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_ico_03_normal.dds", Vector4(0, 0, 0, 0)),
						},
					},
					Gui.Control "right_3"
					{
						Size = Vector2(40, 28),
						Location = Vector2(300, 160),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_ico_03_b_normal.dds", Vector4(0, 0, 0, 0)),
						},
					},
					Gui.Button "start1"
					{
						Size = Vector2(316, 60),
						Location = Vector2(69, 442),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Enable = false,
						blink = true,
						FontSize = 18,
						Text = lang:GetText("开始转换"),
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_button_01_normal.dds",Vector4(80, 0, 80, 0)),
							HoverImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_button_01_hover.dds", Vector4(80, 0, 80, 0)),
							DownImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_button_01_down.dds", Vector4(80, 0, 80, 0)),
							DisabledImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_button_01_disabled.dds", Vector4(80, 0, 80, 0)),
							TwinkleImage  = Gui.Image("LobbyUI/Compose/lb_synthesis_common_button_01_hover.dds", Vector4(80, 0, 80, 0)),
						},
						EventClick = function(Sender, e)
							if rpc_convert.toItemId ~= 0 and rpc_convert.fromItemId ~= 0 then
								local t_text = nil
								if warning_level == 1 then
									t_text = lang:GetText("@!8@!转换需要扣除1000C币。还要继续么？")
								elseif warning_level < 7 then
									t_text = lang:GetText("@!8@!转换需要扣除1000C币。并且此次转换有@!")..warning_level.."@!"..t_Text[warning_level]..lang:GetText("@!8@!概率掉级。还要继续么？")
								elseif warning_level == 7 then
									t_text = lang:GetText("@!8@!转换需要扣除1000C币。并且此次转换@!7@!肯定掉级@!8@!。还要继续么？")
								end
								ShowConvert(t_text)
							else
								MessageBox.ShowWithTimer(1,lang:GetText("请放入要转换的物品"))
							end
						end
					},
				},

				Gui.Control "ronglian"
				{
					Size = Vector2(466, 497),
					Location = Vector2(2, 15),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/Compose/lb_melting_bg_01.dds", Vector4(0, 0, 0, 0)),
					},
					Gui.Label
					{
						Size = Vector2(156, 24),
						Location = Vector2(30, 15),
						TextAlign = "kAlignCenterMiddle",
						Text = lang:GetText("熔炼等级"),
						FontSize = 16,
						TextColor = ARGB(255, 196, 134, 54),
					},

					Gui.FlowLayout "Level"
					{
						Location = Vector2(150,15),
						Size = Vector2(40,24),
						Align = "kAlignCenterMiddle",
						ControlAlign = "kAlignCenterMiddle",
						ControlSpace = 0,
					},

					Gui.Control "Compare_BG_1"
					{
						Size = Vector2(200, 20),
						Location = Vector2(200, 16),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/Compose/lb_melting_bar01_bg.dds", Vector4(5, 5, 5, 5)),
						},
						Gui.Control "Compare_1"
						{
							Size = Vector2(200, 20),
							Location = Vector2(0, 0),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/Compose/lb_melting_bar01_content.dds", Vector4(5, 5, 5, 5)),
							},
						},
						Gui.Label "lab_1"
						{
							Size = Vector2(200, 20),
							Location = Vector2(0, 0),
							BackgroundColor = ARGB(0, 255, 255, 255),
							TextAlign = "kAlignCenterMiddle",
							TextPadding = Vector4(0, 0, 0, 2),
						},
					},
					Gui.FlowLayout
					{
						Size = Vector2(252 ,252),
						Location = Vector2(65,56),
						ControlAlign = "kAlignCenterMiddle",
						ControlSpace = 0,
						LineSpace = 0,
						create_ItemBtn(1),
						create_ItemBtn(2),
						create_ItemBtn(3),
						create_ItemBtn(4),
						create_ItemBtn(5),
						create_ItemBtn(6),
						create_ItemBtn(7),
						create_ItemBtn(8),
						create_ItemBtn(9),
					},
					Gui.ItemBoxBtn "ibtn_1"
					{
						Size = Vector2(97, 96),
						Location = Vector2(330, 63),
						Empty = false,
						Type = 1,
						CanSelect = false,
						Skin = Gui.ItemBoxBtnSkin
						{
							NeutralNormalImage = Gui.Image("LobbyUI/Compose/lb_melting_slot_01.dds", Vector4(0, 0, 0, 0)),
							NeutralHoverImage = Gui.Image("LobbyUI/Compose/lb_melting_slot_01.dds", Vector4(0, 0, 0, 0)),
							NeutralSelectedImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_slot_flash.dds", Vector4(0, 0, 0, 0)),
							NeutralDisabledImage = Gui.Image("LobbyUI/Compose/lb_melting_slot_01.dds", Vector4(0, 0, 0, 0)),
						},
						EventMouseUp = function(sender, e)
							ui.formula_info.Visible = false
							melting_items = nil
							melting_result = nil
							formula_right = false
							
							sender.ItemIcon = nil
							if melting_table.playeritemid ~= -1 then
								for j = 1, 16 do
									if rpc_date[j] and rpc_date[j].playeritemid == melting_table.playeritemid then
										local ibbtn = ptr_cast(material_info_page.ctrl_ib_container:GetChildByIndex(j-1))
										ibbtn.ItemIcon.alpha = 255
									end
								end
							end
							melting_table.playeritemid = -1
							melting_table.value = 0
							ui.lab_des.Text = ""
							is_formula = false
							local flag = IsExist()
							if flag then
								ui.start2.Enable = true
							else
								ui.start2.Enable = false
							end
							FillMachine3(0)
							Fill_Help()
						end

					},
					Gui.Button
					{
						Size = Vector2(72, 20),
						Location = Vector2(343, 155),
						Text = lang:GetText("购买"),
						TextColor = ARGB(255, 37, 37, 37),
						HighlightTextColor = ARGB(255, 37, 37, 37),
						FontSize = 20,
						Padding = Vector4(0, 0, 0, 4),
						TextAlign = "kAlignCenterMiddle",
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/Compose/lb_synthesis_mosaic_button_normal.dds", Vector4(0, 0, 0, 0)),
							HoverImage = Gui.Image("LobbyUI/Compose/lb_synthesis_mosaic_button_hover.dds", Vector4(0, 0, 0, 0)),
							DownImage = Gui.Image("LobbyUI/Compose/lb_synthesis_mosaic_button_down.dds", Vector4(0, 0, 0, 0)),
						},
						EventClick = function(Sender, e)
							ShowRapid(1, 1)
						end
					},
					Gui.TextArea "lab_des"
					{
						Size = Vector2(155, 100),
						Location = Vector2(310, 180),
						BackgroundColor = ARGB(0, 0, 0, 0),
						DisabledTextColor = ARGB(255, 213, 255, 254),
						FontSize = 12,
						Readonly = true,
						Fold = true,
						Enable = false,
					},
					Gui.Control "Compare_BG_2"
					{
						Size = Vector2(316, 68),
						Location = Vector2(47, 297),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/Compose/lb_melting_bar02_bg.dds", Vector4(0, 0, 0, 0)),
						},

						Gui.ChangeControl "Compare_2"
						{
							Size = Vector2(0, 53),
							Normsize = Vector2(0,53),
							Location = Vector2(28, 6),
							NormLocation = Vector2(28, 6),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/Compose/lb_melting_bar02_content.dds", Vector4(262, 0, 0, 0)),
							},
							EventPlayEnd = function(Sender,e)
								Sender.Normsize = Sender.Size
							end
						},
					},
					Gui.Label
					{
						Size = Vector2(50, 20),
						Location = Vector2(98, 361),
						FontSize = 14,
						TextColor = ARGB(255,219, 161, 80),
						Text = "20%",
					},
					Gui.Label
					{
						Size = Vector2(50, 20),
						Location = Vector2(140, 361),
						FontSize = 14,
						TextColor = ARGB(255,234, 161, 83),
						Text = "40%",
					},
					Gui.Label
					{
						Size = Vector2(50, 20),
						Location = Vector2(183, 361),
						FontSize = 14,
						TextColor = ARGB(255,255, 160, 96),
						Text = "60%",
					},
					Gui.Label
					{
						Size = Vector2(50, 20),
						Location = Vector2(226, 361),
						FontSize = 14,
						TextColor = ARGB(255,247, 106, 41),
						Text = "80%",
					},
					Gui.Label
					{
						Size = Vector2(50, 20),
						Location = Vector2(267, 361),
						FontSize = 14,
						TextColor = ARGB(255,239, 65, 6),
						Text = "100%",
					},
					Gui.Label
					{
						Size = Vector2(50, 20),
						Location = Vector2(308, 361),
						FontSize = 14,
						TextColor = ARGB(255,255, 55, 0),
						Text = "120%",
					},
					Gui.Label
					{
						Size = Vector2(160, 30),
						Location = Vector2(33, 376),
						FontSize = 18,
						TextColor = ARGB(255, 0, 0, 0),
						Text = lang:GetText("熔能："),
					},
					Gui.Label
					{
						Size = Vector2(160, 30),
						Location = Vector2(34, 375),
						FontSize = 18,
						TextColor = ARGB(255, 240, 81, 19),
						Text = lang:GetText("熔能："),
					},
					Gui.FlowLayout
					{
						Size = Vector2(48*3 + 12 ,20),
						Location = Vector2(187,380),
						ControlAlign = "kAlignCenterMiddle",
						ControlSpace = 6,
						Gui.Control
						{
							Size = Vector2(48, 20),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/Compose/lb_melting_bar01_bg.dds", Vector4(0, 0, 0, 0)),
							},
							Gui.Control "rongneng_1"
							{
								Size = Vector2(48, 20),
								Location = Vector2(0, 0),
								BackgroundColor = ARGB(255, 255, 255, 255),
								Skin = Gui.ControlSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/Compose/lb_melting_bar01_content.dds", Vector4(0, 0, 0, 0)),
								},
							},
						},
						Gui.Control
						{
							Size = Vector2(48, 20),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/Compose/lb_melting_bar01_bg.dds", Vector4(0, 0, 0, 0)),
							},
							Gui.Control "rongneng_2"
							{
								Size = Vector2(48, 20),
								Location = Vector2(0, 0),
								BackgroundColor = ARGB(255, 255, 255, 255),
								Skin = Gui.ControlSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/Compose/lb_melting_bar01_content.dds", Vector4(0, 0, 0, 0)),
								},
							},
						},
						Gui.Control
						{
							Size = Vector2(48, 20),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/Compose/lb_melting_bar01_bg.dds", Vector4(0, 0, 0, 0)),
							},
							Gui.Control "rongneng_3"
							{
								Size = Vector2(48, 20),
								Location = Vector2(0, 0),
								BackgroundColor = ARGB(255, 255, 255, 255),
								Skin = Gui.ControlSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/Compose/lb_melting_bar01_content.dds", Vector4(0, 0, 0, 0)),
								},
							},
						},
					},
					Gui.RichEdit "re_msg_2"
					{
						Size = Vector2(302, 20),
						Location = Vector2(32, 407),
						FontSize = 14,
						BackgroundColor = ARGB(0, 255, 255, 255),
						AutoScroll = true,
						HScrollBarDisplay = "kHide",
						VScrollBarDisplay = "kHide",
					},
					
					Gui.Label
					{
						Size = Vector2(88, 82),
						Location = Vector2(375, 352),
						TextAlign = "kAlignCenterMiddle",
						Text = lang:GetText("查看蓝图"),
						TextPadding = Vector4(0, 0, 0, 63),
						FontSize = 12,
						TextColor = ARGB(255, 255, 243, 175),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/Compose/lb_synthesis_mosaic_bg_02.dds", Vector4(0, 20, 0, 0)),
						},
						Gui.Button
						{
							Size = Vector2(52, 44),
							Location = Vector2(14, 29),
							TextColor = ARGB(255, 37, 37, 37),
							HighlightTextColor = ARGB(255, 37, 37, 37),
							Padding = Vector4(0, 0, 0, 3),
							FontSize = 16,
							Skin = Gui.ButtonSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/Compose/lb_melting_button_06_normal.dds", Vector4(0, 0, 0, 0)),
								HoverImage = Gui.Image("LobbyUI/Compose/lb_melting_button_06_hover.dds", Vector4(0, 0, 0, 0)),
								DownImage = Gui.Image("LobbyUI/Compose/lb_melting_button_06_down.dds", Vector4(0, 0, 0, 0)),
								DisabledImage = Gui.Image("LobbyUI/Compose/lb_melting_button_06_disabled.dds", Vector4(0, 0, 0, 0)),
							},
							EventClick = function(Sender, e)
								rpc.safecall("melting_output_list", {pid = ptr_cast(game.CurrentState):GetCharacterId()},
								function(data)
									melting_rpc_data_list = data.items
									FillMeltingList(1)
									if not meltinglistmodal then
										meltinglistmodal = ModalWindow.GetNew()
										meltinglistmodal.root.Size = Vector2(1200, 900)
										melting_list.root.Parent = meltinglistmodal.root
										melting_list.melting_list_1.Visible = true
										melting_list.melting_list_2.Visible = false
										melting_list.btn_1_1.PushDown = true
										melting_list.btn_2_2.PushDown = false
									end
								end)
							end
						},
					},


					Gui.TimeControl "Event"
					{
						Size = Vector2(5, 5),
						BackgroundColor = ARGB(0, 255, 255, 255),
						EventTimeOut = function(sender, e)
							if info.remaind > 0 then
								ui.re_msg_2:CleanAll()
								ui.re_msg_2:AddMsg(lang:GetText("还有"),ARGB(255,255, 186, 0),true,false)
								if ((info.remaind - (info.remaind % 60)) / 60) == 0 then
									ui.re_msg_2:AddMsg(lang:GetText("不足1分钟"),ARGB(255,240, 81, 19),false,false)
								else
									ui.re_msg_2:AddMsg(((info.remaind - (info.remaind % 60)) / 60)..lang:GetText("分钟"),ARGB(255,240, 81, 19),false,false)
								end
								ui.re_msg_2:AddMsg(lang:GetText("可以恢复一格熔能"),ARGB(255,255, 186, 0),false,false)
								if info.remaind >= 60 then
									info.remaind = info.remaind - 60
									ui.Event:CleanAll()
									ui.Event:AddTime(60)
								else
									ui.Event:CleanAll()
									ui.Event:AddTime(info.remaind)
									info.remaind = 0
								end
							else
								local args = {pid = ptr_cast(game.CurrentState):GetCharacterId()}
								rpc.safecall("melting_info_get",args,
								function(data)
									info = data.info
									print("66666666666666666666")
									if info then
										L_LobbyMain.ShowFightnums(ui.Level, info.meltingLevel)
										ui.Compare_1.Size = Vector2(200 * (info.exp / info.total_exp), 20)
										ui.lab_1.Text = info.exp.."/"..info.total_exp
										print("777777777777777777777777777",info.recycle_ratio)
										print("7777777777777777777777777771111111",info.residual)
										residual_total = getresidual_total(info.residual,info.recycle_ratio)
										ui.Compare_2.Normsize = ui.Compare_2.Size
										ui.Compare_2:Clear()
										ui.Compare_2:InsertMovePoint(ui.Compare_2.Location,0.5,Vector2(262 * (residual_total / 120), 53),ARGB(255,255,255,255))ui.Event:CleanAll()
										if info.remaind > 0 then
											ui.re_msg_2:CleanAll()
											ui.re_msg_2:AddMsg(lang:GetText("还有"),ARGB(255,255, 186, 0),true,false)
											if ((info.remaind - (info.remaind % 60)) / 60) == 0 then
												ui.re_msg_2:AddMsg(lang:GetText("不足1分钟"),ARGB(255,240, 81, 19),false,false)
											else
												ui.re_msg_2:AddMsg(((info.remaind - (info.remaind % 60)) / 60)..lang:GetText("分钟"),ARGB(255,240, 81, 19),false,false)
											end
											ui.re_msg_2:AddMsg(lang:GetText("可以恢复一格熔能"),ARGB(255,255, 186, 0),false,false)
											if info.remaind >= 60 then
												info.remaind = info.remaind - 60
												ui.Event:CleanAll()
												ui.Event:AddTime(60)
											else
												ui.Event:CleanAll()
												ui.Event:AddTime(info.remaind)
												info.remaind = 0
											end
										else
											ui.re_msg_2:CleanAll()
										end
										for i = 1, 3 do
											ui["rongneng_"..i].Visible = false
										end
										for i = 1, info.meltingEnergy do
											ui["rongneng_"..i].Visible = true
										end
										local flag = IsExist()
										if flag then
											ui.start2.Enable = true
										else
											ui.start2.Enable = false
										end
										Fill_Help()
									end
								end)
							end
						end
					},

					Gui.Button "start2"
					{
						Size = Vector2(316, 60),
						Location = Vector2(69, 433),
						BackgroundColor = ARGB(255, 255, 255, 255),
						blink = true,
						FontSize = 18,
						Text = lang:GetText("开始熔炼"),
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_button_01_normal.dds", Vector4(80, 0, 80, 0)),
							HoverImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_button_01_hover.dds", Vector4(80, 0, 80, 0)),
							DownImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_button_01_down.dds", Vector4(80, 0, 80, 0)),
							DisabledImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_button_01_disabled.dds", Vector4(80, 0, 80, 0)),
							TwinkleImage  = Gui.Image("LobbyUI/Compose/lb_synthesis_common_button_01_hover.dds", Vector4(80, 0, 80, 0)),
						},
						EventClick = function(Sender, e)
							Sender.Enable = false
							
							local args = {}
							args.pid = ptr_cast(game.CurrentState):GetCharacterId()
							args.meltingInputs = ""
							for i = 1, 9 do
								if melting[i].pid ~= -1 then
									if args.meltingInputs == "" then
										args.meltingInputs = args.meltingInputs..melting[i].pid
									else
										args.meltingInputs = args.meltingInputs..":"..melting[i].pid
									end
								end
							end
							args.qualityProps = melting_table.playeritemid
							rpc.safecallload("melting_input",args,
							function(data)
								if data.result == 0 then
									ui.formula_info.Visible = false
									gui:PlayAudio("kUIA_FUSION_START")
									print("444444444444444444444444444444")
									info = data.info
									cost_lookover = info.price
									for i = 1, 9 do
										Clean_melting(i)
										ui["Item_btn_"..i].ItemIcon = nil
									end
									ui.ibtn_1.ItemIcon = nil
									if melting_table.playeritemid ~= -1 then
										for j = 1, 16 do
											if rpc_date[j] and rpc_date[j].playeritemid == melting_table.playeritemid then
												local ibbtn = ptr_cast(material_info_page.ctrl_ib_container:GetChildByIndex(j-1))
												ibbtn.ItemIcon.alpha = 255
											end
										end
									end
									melting_table.playeritemid = -1
									melting_table.value = 0
									ui.lab_des.Text = ""
									FillStorage()
									FillMachine3(0)
									ui.Event:CleanAll()
									if info.remaind > 0 then
										ui.re_msg_2:CleanAll()
										ui.re_msg_2:AddMsg(lang:GetText("还有"),ARGB(255,255, 186, 0),true,false)
										if ((info.remaind - (info.remaind % 60)) / 60) == 0 then
											ui.re_msg_2:AddMsg(lang:GetText("不足1分钟"),ARGB(255,240, 81, 19),false,false)
										else
											ui.re_msg_2:AddMsg(((info.remaind - (info.remaind % 60)) / 60)..lang:GetText("分钟"),ARGB(255,240, 81, 19),false,false)
										end
										ui.re_msg_2:AddMsg(lang:GetText("可以恢复一格熔能"),ARGB(255,255, 186, 0),false,false)
										if info.remaind >= 60 then
											info.remaind = info.remaind - 60
											ui.Event:CleanAll()
											ui.Event:AddTime(60)
										else
											ui.Event:CleanAll()
											ui.Event:AddTime(info.remaind)
											info.remaind = 0
										end
									else
										ui.re_msg_2:CleanAll()
									end
									if data.item then
										Melting_get(data.item)
									else
										if info.rate == 1 then
											melting_ui.lab_1.Visible = true
											melting_ui.lab_2.Visible = true
										else
											melting_ui.lab_1.Visible = false
											melting_ui.lab_2.Visible = false
										end
										meltingmodal = ModalWindow.GetNew()
										meltingmodal.root.Size = Vector2(1200,900)
										meltingmodal.screen.AllowEscToExit = false
										Fillmelting()
										melting_ui.root.Parent = meltingmodal.root
									end
									if data.upgrade ~= 0 then
										MessageBox.ShowWithTimer(1,lang:GetText("恭喜，您的熔炼等级升级到")..data.upgrade..lang:GetText("级\n 第")..(data.upgrade + 1)..lang:GetText("个放置槽解锁了"))
									end
								else
									MessageBox.ShowWithTimer(1,lang:GetText("熔炼失败！"))
								end
							end)
						end
					},
				},
				EventMouseEnter = function(Sender,e)
					ui.TIPS.Location = Vector2(700, 67)
				end,
			},

			Gui.Button "btn_qianghua"
			{
				Style = "Gui.Button_type",
				Size = Vector2(90, 47),
				Location = Vector2(8, 0),
				FontSize = 16,
				Text = lang:GetText("强 化"),

				PushDown = true,
				EventClick = function(Sender,e)
					if main_type ~= 1 then
						main_type = 1
						ResetAll()
						ResetBtn()
						ui.wuqi.Enable = true
						ui.fuzhuang.Enable = true
						ui.shipin.Enable = true
						Sender.PushDown = true
						ui.buffbg_02.Visible = true
						ui.qianghua.Visible = true
					end
				end
			},
			
			Gui.Button "btn_shengxing"
			{
				Style = "Gui.Button_type",
				Size = Vector2(90, 47),
				Location = Vector2(94, 0),
				FontSize = 16,
				Text = lang:GetText("升 星"),
				EventClick = function(Sender,e)
					if main_type ~= 5 then
						main_type = 5
						ResetAll()
						ResetBtn()
						Sender.PushDown = true
						ui.shengxing.Visible = true
						ui.Compare_3.Normsize = ui.Compare_3.Size
						ui.Compare_3:Clear()
						ui.Compare_3:InsertMovePoint(ui.Compare_3.Location,0.5,Vector2(0, 53),ARGB(255,255,255,255))
						ui.Compare_3_full.Visible = false	
						ui.text_shengxing.Visible = false
						ui.wuqi.Enable = true
						ui.fuzhuang.Enable = true
						ui.shipin.Enable = true
					end
				end
			},
			
			Gui.Button "btn_gaizhuang"
			{
				Style = "Gui.Button_type",
				Size = Vector2(90, 47),
				Location = Vector2(184, 0),
				FontSize = 16,
				Text = lang:GetText("改 装"),
				EventClick = function(Sender,e)
					if main_type ~= 2 then
						main_type = 2
						ResetAll()
						ResetBtn()
						ui.wuqi.Enable = true
						ui.fuzhuang.Enable = true
						ui.shipin.Enable = true
						Sender.PushDown = true
						ui.gaizhuang.Visible = true
					end
				end
			},
			Gui.Button "btn_zhuanhuan"
			{
				Style = "Gui.Button_type",
				Size = Vector2(90, 47),
				Location = Vector2(274, 0),
				FontSize = 16,
				Text = lang:GetText("转 换"),
				EventClick = function(Sender,e)
					if main_type ~= 3 then
						main_type = 3
						ResetAll()
						ResetBtn()
						ui.wuqi.Enable = true
						ui.fuzhuang.Enable = true
						ui.shipin.Enable = true
						Sender.PushDown = true
						ui.buffbg_03.Visible = true
						ui.zhuanhuan.Visible = true
					end
				end
			},
			Gui.Button "btn_ronglian"
			{
				Style = "Gui.Button_type",
				Size = Vector2(90, 47),
				Location = Vector2(364, 0), -- 347
				Text = lang:GetText("熔 炼"),
				FontSize = 16,
				EventClick = function(Sender,e)
					if main_type ~= 4 then
						main_type = 4
						ResetAll()
						ResetBtn()
						ui.wuqi.Enable = true
						ui.fuzhuang.Enable = true
						ui.shipin.Enable = true
						Sender.PushDown = true
						ui.ronglian.Visible = true
						local args = {pid = ptr_cast(game.CurrentState):GetCharacterId()}
						rpc.safecall("melting_info_get",args,
						function(data)
							info = data.info
							print("5555555555555555555")
							FillMachine3(0)
							ui.Event:CleanAll()
							if info.remaind > 0 then
								ui.re_msg_2:CleanAll()
								ui.re_msg_2:AddMsg(lang:GetText("还有"),ARGB(255,255, 186, 0),true,false)
								if ((info.remaind - (info.remaind % 60)) / 60) == 0 then
									ui.re_msg_2:AddMsg(lang:GetText("不足1分钟"),ARGB(255,240, 81, 19),false,false)
								else
									ui.re_msg_2:AddMsg(((info.remaind - (info.remaind % 60)) / 60)..lang:GetText("分钟"),ARGB(255,240, 81, 19),false,false)
								end
								ui.re_msg_2:AddMsg(lang:GetText("可以恢复一格熔能"),ARGB(255,255, 186, 0),false,false)
								if info.remaind >= 60 then
									info.remaind = info.remaind - 60
									ui.Event:CleanAll()
									ui.Event:AddTime(60)
								else
									ui.Event:CleanAll()
									ui.Event:AddTime(info.remaind)
									info.remaind = 0
								end
							else
								ui.re_msg_2:CleanAll()
							end
							for i = 1, 3 do
								ui["rongneng_"..i].Visible = false
							end
							for i = 1, info.meltingEnergy do
								ui["rongneng_"..i].Visible = true
							end
						end)
					end
				end
			},
		},

		Gui.Label "arrows"
		{
			Visible = false,
			Size = Vector2(40, 40),
			NormLocation = Vector2(923, 40),
			BackgroundColor = ARGB(255, 255, 255, 255),
			MoveLocation = Vector2(0,4),
			MoveWheelTime = 0.8,
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/Manage/lb_tutorial_arrow04.dds", Vector4(0, 0, 0, 0)),
			},
		},
		
		Gui.Control "TIPS"
		{
			Visible = false,
			Size = Vector2(50, 50),
			BackgroundColor = ARGB(255, 0, 255, 255),
		},
		
		--右侧仓库
		Gui.Control
		{
			Size = Vector2(459, 508),
			Location = Vector2(631, 67),
			BackgroundColor = ARGB(0, 255, 255, 255),
			Gui.Control "right"
			{
				Size = Vector2(459, 465),
				Location = Vector2(0, 46),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg3.dds", Vector4(22, 22, 22, 22)),
				},
			},

			Gui.Button "wuqi"
			{
				Skin = Skin.ButtonSkin_Weapon,
				Size = Vector2(92, 56),
				Location = Vector2(5, 0),
				PushDown = true,
				EventClick = function(Sender,e)
					if current_selected ~= 1 then
						current_selected = 1
						current_page = 1
						ResetType()
						Sender.PushDown = true
						NeedBlink()
					end
				end
			},
			Gui.Button "fuzhuang"
			{
				Size = Vector2(92, 56),
				Location = Vector2(92, 0),
				Skin = Skin.ButtonSkin_Clothes,
				EventClick = function(Sender,e)
					if current_selected ~= 2 then
						current_selected = 2
						current_page = 1
						ResetType()
						Sender.PushDown = true
						NeedBlink()
					end
				end
			},
			Gui.Button "shipin"
			{
				Size = Vector2(92, 56),
				Location = Vector2(179, 0),
				Skin = Skin.ButtonSkin_Hat,
				EventClick = function(Sender,e)
					if current_selected ~= 3 then
						current_selected = 3
						current_page = 1
						ResetType()
						Sender.PushDown = true
						NeedBlink()
					end
				end
			},

			Gui.Button "sucai"
			{
				Size = Vector2(92, 56),
				Location = Vector2(266, 0),
				Skin = Skin.ButtonSkin_material,
				EventClick = function(Sender,e)
					if current_selected ~= 5 then
						current_selected = 5
						current_page = 1
						ResetType()
						Sender.PushDown = true
						Sender.blink = false
						ui.arrows.Visible = false
					end
				end
			},

			Gui.Button "daoju"
			{
				Size = Vector2(92, 56),
				Location = Vector2(353, 0),
				Skin = Skin.ButtonSkin_props,
				EventClick = function(Sender,e)
					if current_selected ~= 4 then
						current_selected = 4
						current_page = 1
						ResetType()
						Sender.PushDown = true
						NeedBlink()
					end
				end
			},

			Gui.Control "ctrl_bottom_container"
			{
				Size = Vector2(415, 49),
				Location = Vector2(15, 460),
				BackgroundColor = ARGB(0, 255, 255, 255),

				--上一页
				Gui.Button "btn_front_page"
				{
					Size = Vector2(14, 31),
					Location = Vector2(281, 9),
					--Text = "<",
					TextColor = ARGB(255, 255, 246, 235),
					FontSize = 18,
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button05_normal.dds", Vector4(0, 0, 0, 0)),
						HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button05_hover.dds", Vector4(0, 0, 0, 0)),
						DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button05_down.dds", Vector4(0, 0, 0, 0)),
						DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button05_normal.dds", Vector4(0, 0, 0, 0)),
					},
					EventClick = function()
						if current_page > 1 then
							current_page = current_page - 1
							FillStorage()
						end
					end
				},

				--页码
				Gui.Label "lb_page_number"
				{
					Location = Vector2(310, 9),
					Size = Vector2(75, 31),
					FontSize = 24,
					TextAlign = "kAlignCenterMiddle",
					TextColor = ARGB(255, 103, 102, 98),
					Text = "1/1",
					BackgroundColor = ARGB(255, 255, 255, 255),

					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button06_bg.dds", Vector4(14, 14, 14, 14)),
					},
				},

				--下一页
				Gui.Button "btn_next_page"
				{
					Size = Vector2(14, 31),
					Location = Vector2(400, 9),
					--Text = ">",
					TextColor = ARGB(255, 255, 246, 235),
					FontSize = 18,
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button06_normal.dds", Vector4(0, 0, 0, 0)),
						HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button06_hover.dds", Vector4(0, 0, 0, 0)),
						DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button06_down.dds", Vector4(0, 0, 0, 0)),
						DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button06_normal.dds", Vector4(0, 0, 0, 0)),
					},
					EventClick = function()
						if current_page < current_pages then
							current_page = current_page + 1
							FillStorage()
						end
					end
				},
			},

			Gui.Button "tidy"
			{
				Size = Vector2(223, 32),
				Location = Vector2(20, 470),
				Text = lang:GetText("整理素材"),
				TextColor = ARGB(255, 37, 37, 37),
				HighlightTextColor = ARGB(255, 37, 37, 37),
				Padding = Vector4(0, 0, 0, 3),
				FontSize = 18,
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Mission/lb_task_button01_normal.dds", Vector4(10, 10, 10, 10)),
					HoverImage = Gui.Image("LobbyUI/Mission/lb_task_button01_hover.dds", Vector4(10, 10, 10, 10)),
					DownImage = Gui.Image("LobbyUI/Mission/lb_task_button01_down.dds", Vector4(10, 10, 10, 10)),
					DisabledImage = Gui.Image("LobbyUI/Mission/lb_task_button01_disabled.dds", Vector4(10, 10, 10, 10)),
				},
				EventClick = function(sender, e)
					gui:PlayAudio("kUIA_CLEAN_UP")
					local args = {pid = ptr_cast(game.CurrentState):GetCharacterId(), type = 5}
					rpc.safecallload("sort_material",args,
					function(data)
						if data.result == 1 then
							MessageBox.ShowWithTimer(1,lang:GetText("整理成功"))
							ResetAll()
							FillStorage()
							if main_type == 1 then
								FillMachine(0)
							elseif main_type == 2 then
								FillMachine1(0)
							elseif main_type == 4 then
								FillMachine3(0)
							end
						end
					end)
				end
			},
			
			EventMouseEnter = function(Sender,e)
				ui.TIPS.Location = Vector2(500, 67)
			end,
		},
		
		Gui.CheckBox "cbox_help"
		{
			Size = Vector2(24, 24),
			Location = Vector2(670, 40),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Check = true,
			Skin = Gui.CheckBoxSkin
			{
				OnImage = Gui.Image("LobbyUI/mail/lb_contact_checkbox_down.dds", Vector4(0, 0, 0, 0)),
				OffImage = Gui.Image("LobbyUI/mail/lb_contact_checkbox_normal.dds", Vector4(0, 0, 0, 0)),
			},
		},
		Gui.Label
		{
			Size = Vector2(200, 16),
			Location = Vector2(700, 45),
			Text = lang:GetText("合成帮助"),
			Font = "simhei",
			FontSize = 16,
			TextColor = ARGB(255, 217, 209, 201),
		},

		--帮助界面
		Gui.Control "Help_part1"
		{
			Visible = false,
			Size = Vector2(460, 140),
			Location = Vector2(520, 220),
			Gui.Label
			{
				Size = Vector2(48, 48),
				Location = Vector2(0, 48),
				NormLocation = Vector2(0, 48),
				BackgroundColor = ARGB(255, 255, 255, 255),
				MoveLocation = Vector2(4,0),
				MoveWheelTime = 0.8,
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Manage/lb_tutorial_arrow02.dds", Vector4(0, 0, 0, 0)),
				},
			},
			Gui.Label
			{
				Size = Vector2(420, 140),
				Location = Vector2(38, 0),
				BackgroundColor = ARGB(255, 255, 255, 255),
				TextColor = ARGB(255, 0, 0, 0),
				FontSize = 20,
				Text = lang:GetText("在右侧装备栏内点击需要强化的装备"),
				TextAlign = "kAlignCenterMiddle",
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Manage/lb_tutorial_bg01.dds", Vector4(0, 0, 0, 0)),
				},
			},
			Gui.Button
			{
				Size = Vector2(36, 32),
				Location = Vector2(405, 12),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Manage/lb_synthesis_common_button_03_normal.dds", Vector4(5, 5, 5, 5)),
					HoverImage = Gui.Image("LobbyUI/Manage/lb_synthesis_common_button_03_hover.dds", Vector4(5, 5, 5, 5)),
					DownImage = Gui.Image("LobbyUI/Manage/lb_synthesis_common_button_03_down.dds", Vector4(5, 5, 5, 5)),
					DisabledImage = Gui.Image("LobbyUI/Manage/lb_synthesis_common_button_03_disabled.dds", Vector4(5, 5, 5, 5)),
				},
				EventClick = function(Sender,e)
					Sender.Parent.Visible = false
				end
			},
		},

		Gui.Control "Help_part2"
		{
			Visible = false,
			Size = Vector2(400, 140),
			Location = Vector2(270, 70),
			Gui.Label
			{
				Size = Vector2(48, 48),
				Location = Vector2(0, 48),
				NormLocation = Vector2(0, 48),
				BackgroundColor = ARGB(255, 255, 255, 255),
				MoveLocation = Vector2(4,0),
				MoveWheelTime = 0.8,
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Manage/lb_tutorial_arrow02.dds", Vector4(0, 0, 0, 0)),
				},
			},
			Gui.Label
			{
				Size = Vector2(360, 140),
				Location = Vector2(38, 0),
				BackgroundColor = ARGB(255, 255, 255, 255),
				TextColor = ARGB(255, 0, 0, 0),
				FontSize = 20,
				Text = lang:GetText("请将强化部件拖至这里，\n或点击“购买”直接购买"),
				TextAlign = "kAlignCenterMiddle",
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Manage/lb_tutorial_bg01.dds", Vector4(0, 0, 0, 0)),
				},
			},
			Gui.Button
			{
				Size = Vector2(36, 32),
				Location = Vector2(345, 12),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Manage/lb_synthesis_common_button_03_normal.dds", Vector4(5, 5, 5, 5)),
					HoverImage = Gui.Image("LobbyUI/Manage/lb_synthesis_common_button_03_hover.dds", Vector4(5, 5, 5, 5)),
					DownImage = Gui.Image("LobbyUI/Manage/lb_synthesis_common_button_03_down.dds", Vector4(5, 5, 5, 5)),
					DisabledImage = Gui.Image("LobbyUI/Manage/lb_synthesis_common_button_03_disabled.dds", Vector4(5, 5, 5, 5)),
				},
				EventClick = function(Sender,e)
					Sender.Parent.Visible = false
				end
			},
		},

		Gui.Control "Help_part3"
		{
			Visible = false,
			Size = Vector2(400, 140),
			Location = Vector2(254, 251),
			Gui.Label
			{
				Size = Vector2(48, 48),
				Location = Vector2(0, 48),
				NormLocation = Vector2(0, 48),
				BackgroundColor = ARGB(255, 255, 255, 255),
				MoveLocation = Vector2(4,0),
				MoveWheelTime = 0.8,
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Manage/lb_tutorial_arrow02.dds", Vector4(0, 0, 0, 0)),
				},
			},
			Gui.Label
			{
				Size = Vector2(360, 140),
				Location = Vector2(38, 0),
				BackgroundColor = ARGB(255, 255, 255, 255),
				TextColor = ARGB(255, 0, 0, 0),
				FontSize = 20,
				Text = lang:GetText("请将改装部件拖至这里\n或者直接点击“购买”键购买"),
				TextAlign = "kAlignCenterMiddle",
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Manage/lb_tutorial_bg01.dds", Vector4(0, 0, 0, 0)),
				},
			},
			Gui.Button
			{
				Size = Vector2(36, 32),
				Location = Vector2(345, 12),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Manage/lb_synthesis_common_button_03_normal.dds", Vector4(5, 5, 5, 5)),
					HoverImage = Gui.Image("LobbyUI/Manage/lb_synthesis_common_button_03_hover.dds", Vector4(5, 5, 5, 5)),
					DownImage = Gui.Image("LobbyUI/Manage/lb_synthesis_common_button_03_down.dds", Vector4(5, 5, 5, 5)),
					DisabledImage = Gui.Image("LobbyUI/Manage/lb_synthesis_common_button_03_disabled.dds", Vector4(5, 5, 5, 5)),
				},
				EventClick = function(Sender,e)
					Sender.Parent.Visible = false
				end
			},
		},

		Gui.Control "Help_part4"
		{
			Visible = false,
			Size = Vector2(400, 180),
			Location = Vector2(200, 220),
			Gui.Label
			{
				Size = Vector2(48, 48),
				Location = Vector2(0, 0),
				NormLocation = Vector2(0, 0),
				BackgroundColor = ARGB(255, 255, 255, 255),
				MoveLocation = Vector2(0,4),
				MoveWheelTime = 0.8,
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Manage/lb_tutorial_arrow01.dds", Vector4(0, 0, 0, 0)),
				},
			},
			Gui.Label
			{
				Size = Vector2(48, 48),
				Location = Vector2(328, 0),
				NormLocation = Vector2(328, 0),
				BackgroundColor = ARGB(255, 255, 255, 255),
				MoveLocation = Vector2(0,4),
				MoveWheelTime = 0.8,
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Manage/lb_tutorial_arrow01.dds", Vector4(0, 0, 0, 0)),
				},
			},
			Gui.Label
			{
				Size = Vector2(380, 140),
				Location = Vector2(0, 40),
				BackgroundColor = ARGB(255, 255, 255, 255),
				TextColor = ARGB(255, 0, 0, 0),
				FontSize = 20,
				Text = lang:GetText("在右侧装备栏内点击需要\n转换强化等级的两件装备"),
				TextAlign = "kAlignCenterMiddle",
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Manage/lb_tutorial_bg01.dds", Vector4(0, 0, 0, 0)),
				},
			},
			Gui.Button
			{
				Size = Vector2(36, 32),
				Location = Vector2(325, 52),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Manage/lb_synthesis_common_button_03_normal.dds", Vector4(5, 5, 5, 5)),
					HoverImage = Gui.Image("LobbyUI/Manage/lb_synthesis_common_button_03_hover.dds", Vector4(5, 5, 5, 5)),
					DownImage = Gui.Image("LobbyUI/Manage/lb_synthesis_common_button_03_down.dds", Vector4(5, 5, 5, 5)),
					DisabledImage = Gui.Image("LobbyUI/Manage/lb_synthesis_common_button_03_disabled.dds", Vector4(5, 5, 5, 5)),
				},
				EventClick = function(Sender,e)
					Sender.Parent.Visible = false
				end
			},
		},

		Gui.Control "Help_part5"
		{
			Visible = false,
			Size = Vector2(400, 180),
			Location = Vector2(200, 220),
			Gui.Label
			{
				Size = Vector2(48, 48),
				Location = Vector2(0, 0),
				NormLocation = Vector2(0, 0),
				BackgroundColor = ARGB(255, 255, 255, 255),
				MoveLocation = Vector2(0,4),
				MoveWheelTime = 0.8,
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Manage/lb_tutorial_arrow01.dds", Vector4(0, 0, 0, 0)),
				},
			},
			Gui.Label
			{
				Size = Vector2(48, 48),
				Location = Vector2(328, 0),
				NormLocation = Vector2(328, 0),
				BackgroundColor = ARGB(255, 255, 255, 255),
				MoveLocation = Vector2(0,4),
				MoveWheelTime = 0.8,
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Manage/lb_tutorial_arrow01.dds", Vector4(0, 0, 0, 0)),
				},
			},
			Gui.Control
			{
				Size = Vector2(380, 140),
				Location = Vector2(0, 40),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Manage/lb_tutorial_bg01.dds", Vector4(0, 0, 0, 0)),
				},
			},
			Gui.RichEdit "re_text"
			{
				Size = Vector2(300, 140),
				Location = Vector2(40, 50),
				FontSize = 20,
				BackgroundColor = ARGB(0, 255, 255, 255),
				HScrollBarDisplay = "kHide",
				VScrollBarDisplay = "kHide",
			},
	
			Gui.Button
			{
				Size = Vector2(36, 32),
				Location = Vector2(325, 52),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Manage/lb_synthesis_common_button_03_normal.dds", Vector4(5, 5, 5, 5)),
					HoverImage = Gui.Image("LobbyUI/Manage/lb_synthesis_common_button_03_hover.dds", Vector4(5, 5, 5, 5)),
					DownImage = Gui.Image("LobbyUI/Manage/lb_synthesis_common_button_03_down.dds", Vector4(5, 5, 5, 5)),
					DisabledImage = Gui.Image("LobbyUI/Manage/lb_synthesis_common_button_03_disabled.dds", Vector4(5, 5, 5, 5)),
				},
				EventClick = function(Sender,e)
					Sender.Parent.Visible = false
				end
			},
		},

		Gui.Control "Help_part6"
		{
			Visible = false,
			Size = Vector2(400, 200),
			Location = Vector2(180, 240),

			Gui.Label
			{
				Size = Vector2(48, 48),
				Location = Vector2(176, 150),
				NormLocation = Vector2(176, 150),
				BackgroundColor = ARGB(255, 255, 255, 255),
				MoveLocation = Vector2(0,4),
				MoveWheelTime = 0.8,
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Manage/lb_tutorial_arrow04.dds", Vector4(0, 0, 0, 0)),
				},
			},

			Gui.Label
			{
				Size = Vector2(380, 140),
				Location = Vector2(0, 0),
				BackgroundColor = ARGB(255, 255, 255, 255),
				TextColor = ARGB(255, 0, 0, 0),
				FontSize = 20,
				Text = lang:GetText("熔能不足了\n你可以保持在线以恢复熔能"),
				TextPadding = Vector4(0, 0, 0, 17),
				TextAlign = "kAlignCenterMiddle",
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Manage/lb_tutorial_bg01.dds", Vector4(0, 0, 0, 0)),
				},
			},
			Gui.Button
			{
				Size = Vector2(36, 32),
				Location = Vector2(325, 12),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Manage/lb_synthesis_common_button_03_normal.dds", Vector4(5, 5, 5, 5)),
					HoverImage = Gui.Image("LobbyUI/Manage/lb_synthesis_common_button_03_hover.dds", Vector4(5, 5, 5, 5)),
					DownImage = Gui.Image("LobbyUI/Manage/lb_synthesis_common_button_03_down.dds", Vector4(5, 5, 5, 5)),
					DisabledImage = Gui.Image("LobbyUI/Manage/lb_synthesis_common_button_03_disabled.dds", Vector4(5, 5, 5, 5)),
				},
				EventClick = function(Sender,e)
					Sender.Parent.Visible = false
				end
			},
		},

		Gui.Control "Help_part7"
		{
			Visible = false,
			Size = Vector2(400, 200),
			Location = Vector2(180, 200),

			Gui.Button
			{
				Size = Vector2(72, 20),
				Location = Vector2(316, 18),
				Text = lang:GetText("购买"),
				Padding = Vector4(0, 0, 0, 4),
				TextColor = ARGB(255, 37, 37, 37),
				HighlightTextColor = ARGB(255, 37, 37, 37),
				FontSize = 20,
				TextAlign = "kAlignCenterMiddle",
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Compose/lb_synthesis_mosaic_button_normal.dds", Vector4(0, 0, 0, 0)),
					HoverImage = Gui.Image("LobbyUI/Compose/lb_synthesis_mosaic_button_hover.dds", Vector4(0, 0, 0, 0)),
					DownImage = Gui.Image("LobbyUI/Compose/lb_synthesis_mosaic_button_down.dds", Vector4(0, 0, 0, 0)),
				},
				EventClick = function(Sender, e)
					ShowRapid(1, 1)
				end
			},

			Gui.Label
			{
				Size = Vector2(48, 48),
				Location = Vector2(56, 0),
				NormLocation = Vector2(56, 0),
				BackgroundColor = ARGB(255, 255, 255, 255),
				MoveLocation = Vector2(0,4),
				MoveWheelTime = 0.8,
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Manage/lb_tutorial_arrow01.dds", Vector4(0, 0, 0, 0)),
				},
			},

			Gui.Label
			{
				Size = Vector2(380, 140),
				Location = Vector2(0, 40),
				BackgroundColor = ARGB(255, 255, 255, 255),
				TextColor = ARGB(255, 0, 0, 0),
				FontSize = 20,
				Text = lang:GetText("在右侧仓库中点击需要熔炼的物品"),
				TextPadding = Vector4(0, 0, 0, 17),
				TextAlign = "kAlignCenterMiddle",
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Manage/lb_tutorial_bg01.dds", Vector4(0, 0, 0, 0)),
				},
			},
			Gui.Button
			{
				Size = Vector2(36, 32),
				Location = Vector2(325, 52),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Manage/lb_synthesis_common_button_03_normal.dds", Vector4(5, 5, 5, 5)),
					HoverImage = Gui.Image("LobbyUI/Manage/lb_synthesis_common_button_03_hover.dds", Vector4(5, 5, 5, 5)),
					DownImage = Gui.Image("LobbyUI/Manage/lb_synthesis_common_button_03_down.dds", Vector4(5, 5, 5, 5)),
					DisabledImage = Gui.Image("LobbyUI/Manage/lb_synthesis_common_button_03_disabled.dds", Vector4(5, 5, 5, 5)),
				},
				EventClick = function(Sender,e)
					Sender.Parent.Visible = false
				end
			},
		},

		Gui.Control "Help_part8"
		{
			Visible = false,
			Size = Vector2(420, 140),
			Location = Vector2(580, 113),

			Gui.Label
			{
				Size = Vector2(48, 48),
				Location = Vector2(0, 46),
				NormLocation = Vector2(0, 46),
				BackgroundColor = ARGB(255, 255, 255, 255),
				MoveLocation = Vector2(4,0),
				MoveWheelTime = 0.8,
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Manage/lb_tutorial_arrow02.dds", Vector4(0, 0, 0, 0)),
				},
			},

			Gui.Label
			{
				Size = Vector2(380, 140),
				Location = Vector2(40, 0),
				BackgroundColor = ARGB(255, 255, 255, 255),
				TextColor = ARGB(255, 0, 0, 0),
				FontSize = 18,
				Text = lang:GetText("放置加工装置可以提升熔炼品质哦~\n或者放置特殊模组可以合成特殊物品！"),
				TextPadding = Vector4(0, 0, 0, 17),
				TextAlign = "kAlignCenterMiddle",
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Manage/lb_tutorial_bg01.dds", Vector4(0, 0, 0, 0)),
				},
			},
			Gui.Button
			{
				Size = Vector2(36, 32),
				Location = Vector2(365, 12),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Manage/lb_synthesis_common_button_03_normal.dds", Vector4(5, 5, 5, 5)),
					HoverImage = Gui.Image("LobbyUI/Manage/lb_synthesis_common_button_03_hover.dds", Vector4(5, 5, 5, 5)),
					DownImage = Gui.Image("LobbyUI/Manage/lb_synthesis_common_button_03_down.dds", Vector4(5, 5, 5, 5)),
					DisabledImage = Gui.Image("LobbyUI/Manage/lb_synthesis_common_button_03_disabled.dds", Vector4(5, 5, 5, 5)),
				},
				EventClick = function(Sender,e)
					Sender.Parent.Visible = false
				end
			},
		},
		
		Gui.Control "Help_part9"
		{
			Size = Vector2(460, 140),
			Location = Vector2(320, 50),
			Visible = false,
			Gui.Label
			{
				Size = Vector2(48, 48),
				Location = Vector2(0, 48),
				NormLocation = Vector2(0, 48),
				BackgroundColor = ARGB(255, 255, 255, 255),
				MoveLocation = Vector2(4,0),
				MoveWheelTime = 0.8,
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Manage/lb_tutorial_arrow02.dds", Vector4(0, 0, 0, 0)),
				},
			},
			Gui.Label
			{
				Size = Vector2(420, 140),
				Location = Vector2(38, 0),
				BackgroundColor = ARGB(255, 255, 255, 255),
				TextColor = ARGB(255, 0, 0, 0),
				FontSize = 20,
				Text = lang:GetText("在右侧装备栏内点击需要升星的装备"),
				TextAlign = "kAlignCenterMiddle",
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Manage/lb_tutorial_bg01.dds", Vector4(0, 0, 0, 0)),
				},
			},
			Gui.Button
			{
				Size = Vector2(36, 32),
				Location = Vector2(405, 12),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Manage/lb_synthesis_common_button_03_normal.dds", Vector4(5, 5, 5, 5)),
					HoverImage = Gui.Image("LobbyUI/Manage/lb_synthesis_common_button_03_hover.dds", Vector4(5, 5, 5, 5)),
					DownImage = Gui.Image("LobbyUI/Manage/lb_synthesis_common_button_03_down.dds", Vector4(5, 5, 5, 5)),
					DisabledImage = Gui.Image("LobbyUI/Manage/lb_synthesis_common_button_03_disabled.dds", Vector4(5, 5, 5, 5)),
				},
				EventClick = function(Sender,e)
					Sender.Parent.Visible = false
				end
			},
		},
		
		Gui.Control "Help_part10"
		{
			Size = Vector2(460, 140),
			Location = Vector2(430, 40),
			Visible = false,
			Gui.Label
			{
				Size = Vector2(48, 48),
				Location = Vector2(0, 48),
				NormLocation = Vector2(0, 48),
				BackgroundColor = ARGB(255, 255, 255, 255),
				MoveLocation = Vector2(4,0),
				MoveWheelTime = 0.8,
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Manage/lb_tutorial_arrow02.dds", Vector4(0, 0, 0, 0)),
				},
			},
			Gui.Label
			{
				Size = Vector2(420, 140),
				Location = Vector2(38, 0),
				BackgroundColor = ARGB(255, 255, 255, 255),
				TextColor = ARGB(255, 0, 0, 0),
				FontSize = 20,
				Text = lang:GetText("在右侧装备栏内点击材料装备，\n升星后该材料将消失"),
				TextAlign = "kAlignCenterMiddle",
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Manage/lb_tutorial_bg01.dds", Vector4(0, 0, 0, 0)),
				},
			},
			Gui.Button
			{
				Size = Vector2(36, 32),
				Location = Vector2(405, 12),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Manage/lb_synthesis_common_button_03_normal.dds", Vector4(5, 5, 5, 5)),
					HoverImage = Gui.Image("LobbyUI/Manage/lb_synthesis_common_button_03_hover.dds", Vector4(5, 5, 5, 5)),
					DownImage = Gui.Image("LobbyUI/Manage/lb_synthesis_common_button_03_down.dds", Vector4(5, 5, 5, 5)),
					DisabledImage = Gui.Image("LobbyUI/Manage/lb_synthesis_common_button_03_disabled.dds", Vector4(5, 5, 5, 5)),
				},
				EventClick = function(Sender,e)
					Sender.Parent.Visible = false
				end
			},
		},
		
		Gui.Control "Help_part11"
		{
			Size = Vector2(460, 140),
			Location = Vector2(350, 380),
			Visible = false,
			Gui.Label
			{
				Size = Vector2(48, 48),
				Location = Vector2(0, 86),
				NormLocation = Vector2(0, 86),
				BackgroundColor = ARGB(255, 255, 255, 255),
				MoveLocation = Vector2(4,0),
				MoveWheelTime = 0.8,
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Manage/lb_tutorial_arrow02.dds", Vector4(0, 0, 0, 0)),
				},
			},
			Gui.Label
			{
				Size = Vector2(420, 140),
				Location = Vector2(38, 10),
				BackgroundColor = ARGB(255, 255, 255, 255),
				TextColor = ARGB(255, 0, 0, 0),
				FontSize = 20,
				Text = lang:GetText("勾选后可以花费少量C币为\n本次升星增加大量经验\n（每个品质的装备每日一次机会）"),
				TextAlign = "kAlignCenterMiddle",
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Manage/lb_tutorial_bg01.dds", Vector4(0, 0, 0, 0)),
				},
			},
			Gui.Button
			{
				Size = Vector2(36, 32),
				Location = Vector2(405, 12),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Manage/lb_synthesis_common_button_03_normal.dds", Vector4(5, 5, 5, 5)),
					HoverImage = Gui.Image("LobbyUI/Manage/lb_synthesis_common_button_03_hover.dds", Vector4(5, 5, 5, 5)),
					DownImage = Gui.Image("LobbyUI/Manage/lb_synthesis_common_button_03_down.dds", Vector4(5, 5, 5, 5)),
					DisabledImage = Gui.Image("LobbyUI/Manage/lb_synthesis_common_button_03_disabled.dds", Vector4(5, 5, 5, 5)),
				},
				EventClick = function(Sender,e)
					Sender.Parent.Visible = false
				end
			},
		},

		--熔炼公式fireball
		Gui.Control "formula_info"
		{
			Visible = false,
			Size = Vector2(330, 520),
			Location = Vector2(630, 45),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ToolTips/lb_tooltips_bg.dds",Vector4(10, 10, 10, 10)),
			},
			
			Gui.Control
			{
				Size = Vector2(330, 520),
				Location = Vector2(0, 0),
				BackgroundColor = ARGB(0, 255, 255, 255),
				
				Gui.Control 
				{							
					Size = Vector2(310, 67),
					Location = Vector2(10, 8),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ToolTips/lb_tooltips_bg_wqmc.dds",Vector4(10, 10, 10, 10)),
					},
					
					Gui.Label "formula_name" 
					{							
						Size = Vector2(310, 67),
						Location = Vector2(10, 8),
						BackgroundColor = ARGB(0, 255, 255, 255),
						TextColor = ARGB(255, 255, 180, 104),
						FontSize = 20,
						TextAlign = "kAlignCenterMiddle",
					},
				},
				
				Gui.Control
				{							
					Size = Vector2(310, 80),
					Location = Vector2(10, 77),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ToolTips/lb_tooltips_bg_2.dds",Vector4(8, 8, 8, 8)),
					},
					
					Gui.ItemBoxBtn "formula_icon"
					{
						Size = Vector2(156, 80),
						Location = Vector2(77, 0),
						BackgroundColor = ARGB(0, 255, 255, 255),
						Empty = false,
						Type = 1,
						CanSelect = false,
						Skin = Gui.ItemBoxBtnSkin
						{
							BackgroundImage = nil,
						},
					},
				},
				
				create_formula_sucai(1),
				create_formula_sucai(2),
				create_formula_sucai(3),
				create_formula_sucai(4),
				create_formula_sucai(5),
				create_formula_sucai(6),
				create_formula_sucai(7),
				create_formula_sucai(8),
				create_formula_sucai(9),
				
				EventMouseEnter = function(sender, e)
					if formula_right == false then
						ui.formula_info.Location = Vector2(630, 45)
						formula_right = true
					else
						ui.formula_info.Location = Vector2(260, 45)
						formula_right = false
					end
				end,
			},
		},
		
		Gui.Button "btn_Close"
		{
			Size = Vector2(63, 52),
			Location = Vector2(1040, 20),
			Hint = lang:GetText("关闭合成界面并返回至战区"),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button01_small_normal.dds", Vector4(0, 0, 0, 0)),
				HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button01_small_hover.dds", Vector4(0, 0, 0, 0)),
				DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button01_small_down.dds", Vector4(0, 0, 0, 0)),
				DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button01_small_normal.dds", Vector4(0, 0, 0, 0)),
			},

			EventClick = function()
				L_WarZone.Show(L_LobbyMain.LobbyMainWin_Boddy.LobbyMainWin_Boddy_Root)
			end
		},
	},
}

for i = 1, 10 do
	ui["tab_btn_"..i].EventClick = function(Sender,e)
		if current_characters ~= i then
			current_characters = i
			L_LobbyMain.current_choose_class = current_characters
			current_page = 1
			ResetCharacters()
			Sender.PushDown = true
		end
	end
end

flash = Gui.Create()
{
	Gui.Control "root"
	{
		Location = Vector2(0, 0),
		Size = Vector2(440, 440),
		BackgroundColor = ARGB(0, 255, 255, 255),
		Gui.FlashControl "Flash"
		{
			Visible = false,
			Text = "synthesis_success",
			Location = Vector2(0, 0),
			Size = Vector2(440, 440),
			BackgroundColor = ARGB(255, 255, 255, 255),
			UseTime = false,
			DisplayTime = 1,
			EventTimer = function(sender, e)
				flash.Flash.UseTime = false
				if modalFlash then
					modalFlash.Close()
					modalFlash = nil
				end
				if main_type == 1 then
					if data_temp.items[1] then
						rpc_date_object = data_temp.items[1]
					else
						rpc_date_object = nil
						Clean_Weapon_table()
					end
					if data_temp.result == 0 then
						FillCongratulation()
						congratulationmodal = ModalWindow.GetNew()
						congratulationmodal.root.Size = Vector2(800,600)
						congratulation.root.Parent = congratulationmodal.root
						if rpc_date_object.common.strength == L_LobbyMain.PersonalInfo_data.maxLevel then
							gui:PlayAudio("kUIA_COMPOUND_SUCCEED_SWF_EX")
						end
					else
						Fillfailed(data_temp.result)
						failedmodal = ModalWindow.GetNew()
						failedmodal.root.Size = Vector2(800,600)
						failed.root.Parent = failedmodal.root
						-- failed.time:CleanAll()
						-- failed.time:AddTime(2)
						gui:PlayAudio("kUIA_COMPOUND_FAIL")
					end
					ui.start.Enable = true
					for i = 1, 3 do
						local j = nil
						if i == 2 then
							j = 3
						elseif i == 3 then
							j = 2
						else
							j = i
						end
						if data_temp.items2[i].common then
							local btn = ptr_cast(ui.qianghua:GetChildByIndex(j))
							local control = ptr_cast(btn:GetChildByIndex(2))
							L_LobbyMain.FillNumber(data_temp.items2[i].common.quantity, control)
							index_table[j].num = data_temp.items2[i].common.quantity
						else
							if j == 1 then
								rpc_string.strengthenItemId = 0
							elseif j == 2 then
								rpc_string.stableItemId = 0
								success_level = -1
							elseif j == 3 then
								rpc_string.safeItemId = 0
							end
							local btn = ptr_cast(ui.qianghua:GetChildByIndex(j))
							btn.ItemIcon = nil
							Clean_index_table(j)
						end
						FillStorage()
						FillMachine(0)
					end
				elseif main_type == 3 then
					if data_temp.result == 5 then
						gui:PlayAudio("kUIA_COMPOUND_SUCCEED")
					end
					ui.start1.Enable = true
					FillStorage()
					rpc_date_object_1[1] = data_temp.from
					rpc_date_object_1[2] = data_temp.to
					from_rate = data_temp.from_rate
					to_rate = data_temp.to_rate
					FillMachine2_end()
				end
			end
		},
	},

}

tuozhuai = Gui.Create()
{
	Gui.Control "root"
	{
		Visible = false,
		Size = Vector2(1167, 900),
		Location = Vector2(17, 0),
		BackgroundColor = ARGB(0, 255, 255, 255),
		Gui.Control "Image"
		{
			BackgroundColor = ARGB(255, 255, 255, 255),
			Gui.DragLabel "tttt"
			{
				Size = Vector2(168, 156),
				Location = Vector2(0, 0),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Iimit = Vector4(-10000,-10000,10000,10000),
			},
		},
		EventMouseRightUp = function(Sender,e)
			local lobby_state = ptr_cast(game.CurrentState)
			local cursor_ScreenSize = lobby_state:GetScreenSize()
			local cursor_pos = lobby_state:GetCursorPos()
			local x = cursor_pos.x - ((cursor_ScreenSize.x - (cursor_ScreenSize.y / 3 * 4)) / 2)
			local y = cursor_pos.y
			print("x:"..x)
			print("y:"..y)
			local temp = 0
			local index
			index_right = index_tz
			if main_type == 3 then
				local flag = -1
				if x < 380 and x > 208 and y > 304 and y < 428 then
					temp = 1
					if convert[1].page == current_page and convert[1].index ~= -1 and convert[1].cid == current_characters and convert[1].type == current_selected then
						if current_selected == 1 then
							ibbtn = ptr_cast(weapon_info_page.ctrl_ib_container:GetChildByIndex(convert[1].index -1))
						elseif current_selected == 2 then
							ibbtn = ptr_cast(dress_info_page.ctrl_ib_container:GetChildByIndex(convert[1].index -1))
						elseif current_selected == 3 then
							ibbtn = ptr_cast(accessories_info_page.ctrl_ib_container:GetChildByIndex(convert[1].index -1))
						end
						ibbtn.ItemIcon.alpha = 255
					end
					convert[1].page = current_page
					convert[1].index = index_tz
					convert[1].cid = current_characters
					convert[1].type = current_selected
					flag = 1
				elseif x < 641 and x > 468 and y > 305 and y < 431 then
					temp = 1
					if convert[2].page == current_page and convert[2].index ~= -1 and convert[2].cid == current_characters and convert[2].type == current_selected then
						if current_selected == 1 then
							ibbtn = ptr_cast(weapon_info_page.ctrl_ib_container:GetChildByIndex(convert[2].index -1))
						elseif current_selected == 2 then
							ibbtn = ptr_cast(dress_info_page.ctrl_ib_container:GetChildByIndex(convert[2].index -1))
						elseif current_selected == 3 then
							ibbtn = ptr_cast(accessories_info_page.ctrl_ib_container:GetChildByIndex(convert[2].index -1))
						end
						ibbtn.ItemIcon.alpha = 255
					end
					convert[2].page = current_page
					convert[2].index = index_tz
					convert[2].cid = current_characters
					convert[2].type = current_selected
					flag = 2
				end
				if flag ~= -1 then
					FillMachine2(index_tz, flag)
				end
			elseif  x < 659 and x > 190 and y < 798 and y > 276 then
				if main_type == 4 then
					if current_selected < 4 then
						local ibbtn
						if current_selected == 1 then
							ibbtn = ptr_cast(weapon_info_page.ctrl_ib_container:GetChildByIndex(index_tz -1))
						elseif current_selected == 2 then
							ibbtn = ptr_cast(dress_info_page.ctrl_ib_container:GetChildByIndex(index_tz -1))
						elseif current_selected == 3 then
							ibbtn = ptr_cast(accessories_info_page.ctrl_ib_container:GetChildByIndex(index_tz -1))
						end
						if FillMachine3(index_tz) then
							temp = 1
						end
					else
						if rpc_date[index_tz].mType == 31 or rpc_date[index_tz].mType == 32 then
							if melting_table.playeritemid == -1 then
								melting_table.playeritemid = rpc_date[index_tz].playeritemid
								melting_table.value = rpc_date[index_tz].mValue
								ui.lab_des.Text = rpc_date[index_tz].description
								ui.ibtn_1.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..rpc_date[index_tz].name..".tga")
								FillMachine3(0)
								temp = 1
							end
						else
							local ibbtn = ptr_cast(material_info_page.ctrl_ib_container:GetChildByIndex(index_tz -1))
							if FillMachine3(index_tz) then
								if rpc_date[index_tz].common.quantity == 1 then
									rpc_date[index_tz].common.quantity = 0
									ibbtn.ItemIcon.alpha = 80
								else
									rpc_date[index_tz].common.quantity = rpc_date[index_tz].common.quantity - 1
								end
								local Control = ptr_cast(ibbtn:GetChildByIndex(2))
								L_LobbyMain.FillNumber(rpc_date[index_tz].common.quantity, Control)
							end
						end
					end
				elseif main_type == 5 then
					if FillMachine4(index_tz,x,y) then
						local ibbtn
						if current_selected == 1 then
							ibbtn = ptr_cast(weapon_info_page.ctrl_ib_container:GetChildByIndex(index_tz -1))
						elseif current_selected == 2 then
							ibbtn = ptr_cast(dress_info_page.ctrl_ib_container:GetChildByIndex(index_tz -1))
						elseif current_selected == 3 then
							ibbtn = ptr_cast(accessories_info_page.ctrl_ib_container:GetChildByIndex(index_tz -1))
						end
						ibbtn.ItemIcon.alpha = 80
						temp = 1
					end
				else
					temp = 1
					if current_selected < 4 then
						local ibbtn = nil
						if Weapon_table.page == current_page and Weapon_table.index ~= -1 and Weapon_table.cid == current_characters and Weapon_table.type == current_selected then
							if current_selected == 1 then
								ibbtn = ptr_cast(weapon_info_page.ctrl_ib_container:GetChildByIndex(Weapon_table.index -1))
							elseif current_selected == 2 then
								ibbtn = ptr_cast(dress_info_page.ctrl_ib_container:GetChildByIndex(Weapon_table.index -1))
							elseif current_selected == 3 then
								ibbtn = ptr_cast(accessories_info_page.ctrl_ib_container:GetChildByIndex(Weapon_table.index -1))
							end
							ibbtn.ItemIcon.alpha = 255
						end
						Weapon_table.page = current_page
						Weapon_table.index = index_tz
						Weapon_table.cid = current_characters
						Weapon_table.type = current_selected
						if main_type == 1 then
							rpc_string.playerItemId = rpc_date[index_tz].playeritemid
						elseif main_type == 2 then
							rpc_slotting.playerItemId = rpc_date[index_tz].playeritemid
							rpc_insert.playerItemId = rpc_date[index_tz].playeritemid
							rpc_remove.playerItemId = rpc_date[index_tz].playeritemid
						end
					else
						local ibbtn = nil
						if rpc_date[index_tz].mType == 1 then
							ibbtn = ptr_cast(ui.qianghua:GetChildByIndex(1))
							rpc_string.strengthenItemId = rpc_date[index_tz].playeritemid
							if index_table[1].page == current_page and index_table[1].index ~= -1 then
								local ibbtn = ptr_cast(material_info_page.ctrl_ib_container:GetChildByIndex(index_table[1].index -1))
								ibbtn.ItemIcon.alpha = 255
								local c_control = ptr_cast(ibbtn:GetChildByIndex(2))
								c_control.Visible = true
							end
							index_table[1].page = current_page
							index_table[1].index = index_tz
							index_table[1].playeritemid = rpc_date[index_tz].playeritemid
						elseif rpc_date[index_tz].mType == 2 or rpc_date[index_tz].mType == 5 then
							ibbtn = ptr_cast(ui.qianghua:GetChildByIndex(2))
							rpc_string.stableItemId = rpc_date[index_tz].playeritemid
							if index_table[2].page == current_page and index_table[2].index ~= -1 then
								local ibbtn = ptr_cast(material_info_page.ctrl_ib_container:GetChildByIndex(index_table[2].index -1))
								ibbtn.ItemIcon.alpha = 255
								local c_control = ptr_cast(ibbtn:GetChildByIndex(2))
								c_control.Visible = true
							end
							index_table[2].page = current_page
							index_table[2].index = index_tz
							index_table[2].playeritemid = rpc_date[index_tz].playeritemid
						elseif rpc_date[index_tz].mType == 3 or rpc_date[index_tz].mType == 4 then
							ibbtn = ptr_cast(ui.qianghua:GetChildByIndex(3))
							rpc_string.safeItemId = rpc_date[index_tz].playeritemid
							if index_table[3].page == current_page and index_table[3].index ~= -1 then
								local ibbtn = ptr_cast(material_info_page.ctrl_ib_container:GetChildByIndex(index_table[3].index -1))
								ibbtn.ItemIcon.alpha = 255
								local c_control = ptr_cast(ibbtn:GetChildByIndex(2))
								c_control.Visible = true
							end
							index_table[3].page = current_page
							index_table[3].index = index_tz
							index_table[3].playeritemid = rpc_date[index_tz].playeritemid
						elseif rpc_date[index_tz].mType == 11 then
							ibbtn = ui.dakong
							if hole.page == current_page and hole.index ~= -1 then
								local ibbtn = ptr_cast(material_info_page.ctrl_ib_container:GetChildByIndex(hole.index -1))
								ibbtn.ItemIcon.alpha = 255
								local c_control = ptr_cast(ibbtn:GetChildByIndex(2))
								c_control.Visible = true
							end
							rpc_slotting.sloterItemId = rpc_date[index_tz].playeritemid
						end
					end
					if main_type == 1 then
						FillMachine(index_tz)
					elseif main_type == 2 then
						rpc_insert.index = 0
						if rpc_date[index_tz].mType == 8 or rpc_date[index_tz].mType == 9 then
							if x < 339 and x > 269 and y < 366 and y > 295 then
								rpc_insert.index = 1
							elseif x < 429 and x > 359 and y < 366 and y > 295 then
								rpc_insert.index = 2
							elseif x < 520 and x > 450 and y < 366 and y > 295 then
								rpc_insert.index = 3
							elseif x < 610 and x > 540 and y < 366 and y > 295 then
								rpc_insert.index = 4
							elseif x < 277 and x > 206 and y < 454 and y > 384 then
								rpc_insert.index = 5
							elseif x < 644 and x > 576 and y < 496 and y > 431 then
								rpc_insert.index = 6
							end
							if rpc_insert.index == 0 or rpc_insert.playerItemId == 0 then
								FillStorage()
								FillMachine1(0)
								reset(temp,false)
								return
							end
							rpc_insert.propertyItemId = rpc_date[index_tz].playeritemid
							local cost= 0
							if rpc_date[index_tz].mValue == 1 then
								cost = 250
							elseif rpc_date[index_tz].mValue == 2 then
								cost = 500
							elseif rpc_date[index_tz].mValue == 3 then
								cost = 1000
							end
							MessageBox.ShowWithConfirmCancel(lang:GetText("镶嵌该属性部件需要花费")..cost..lang:GetText("C币\n您是否要继续？"),
							function()
								rpc.safecallload("insert",rpc_insert,
								function(data)
									if data.result == 1 then
										MessageBox.ShowWithTimer(1,data.msg)
										gui:PlayAudio("kUIA_COMPOUND_FAIL")
									else
										gui:PlayAudio("kUIA_COMPOUND_SUCCEED")
									end
									rpc_date_object = data.item
									FillStorage()
									FillMachine1(0)
									reset(temp,false)
									return
								end)
							end)
						end
						FillMachine1(index_tz)
					end
				end
			end
			reset(temp,false)
		end,
	},
}

function reset(temp , change)
	local ibbtn = nil
	if current_selected == 1 then
		ibbtn = ptr_cast(weapon_info_page.ctrl_ib_container:GetChildByIndex(index_tz-1))
	elseif current_selected == 2 then
		ibbtn = ptr_cast(dress_info_page.ctrl_ib_container:GetChildByIndex(index_tz-1))
	elseif current_selected == 3 then
		ibbtn = ptr_cast(accessories_info_page.ctrl_ib_container:GetChildByIndex(index_tz-1))
	elseif current_selected > 3 then
		ibbtn = ptr_cast(material_info_page.ctrl_ib_container:GetChildByIndex(index_tz-1))
	end
	if change == false then
		if ibbtn.ItemIcon then
			ibbtn.ItemIcon.alpha = 255
		end
		if temp == 1 then
			ibbtn.ItemIcon.alpha = 80
		end
	end	
	if main_type == 1 then
		ui.object.Highlight = false
		for i = 1, 3 do
			local ibbtn = ptr_cast(ui.qianghua:GetChildByIndex(i))
			ibbtn.Highlight = false
		end
	elseif main_type == 2 then
		ui.object1.Highlight = false
		ui.dakong.Highlight = false
		for i = 1, 6 do
			local ibbtn = ptr_cast(ui.gaizhuang:GetChildByIndex(i + 1))
			ibbtn.Highlight = false
		end
	elseif main_type == 3 then
		ui.object2.Highlight = false
		ui.object3.Highlight = false
	end
	tuozhuai.root.Visible = false
end

--武器
function create_weapon_page(index, line, list)
	return Gui.ItemBoxBtn
	{
		Style = "Gui.ItemBoxBtn_ib",
		Size = Vector2(212, 100),
		CanSelect = false,
		Location = Vector2(212*line, 100*list),
		BtnLocation = Vector2(212-45,100-28),
		BtnVisible = false,

		EventMouseRightDown = function(sender, e)
			if sender.ItemIcon.alpha ~= 80 then
				if rpc_date[index] then
					tuozhuai.root.Parent = L_LobbyMain.LobbyMainWin.LobbyMain_Root
					index_tz = index
					tuozhuai.root.Visible = true
					local lobby_state = ptr_cast(game.CurrentState)
					local cursor_ScreenSize = lobby_state:GetScreenSize()
					local cursor_pos = lobby_state:GetCursorPos()
					tuozhuai.Image.Location = Vector2(cursor_pos.x-((cursor_ScreenSize.x - cursor_ScreenSize.y / 3 * 4) / 2) - 99, cursor_pos.y - 38)
					tuozhuai.Image.Size = Vector2(168, 76)
					if rpc_date[index].color > 0 and rpc_date[index].color < 8 then
						tuozhuai.Image.Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ibt_icon/"..rpc_date[index].name.."_"..rpc_date[index].color..".tga", Vector4(0, 0, 0, 0)),
						}
					else
						tuozhuai.Image.Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ibt_icon/"..rpc_date[index].name..".tga", Vector4(0, 0, 0, 0)),
						}
					end
					local ibbtn = ptr_cast(weapon_info_page.ctrl_ib_container:GetChildByIndex(index-1))
					ibbtn.ItemIcon.alpha = 80
				end
				Highlight(current_selected,rpc_date[index].mType)
			end
		end,

		EventMouseEnter = function(sender, e)
			if sender.Loading == false then
				L_ToolTips.FillToolTipsWindow(5, index, sender)
			end
		end,
		EventToolTipsShow = function(sender, e)
			L_ToolTips.ShowToolTipsShowWindow(sender)
		end,
		EventMouseLeave = function(sender, e)
			L_ToolTips.HideToolTipsWindow()
		end,

		EventMouseUp = function(sender, e)
			if sender.ItemIcon.alpha ~= 80 then
				if main_type == 4 then
					if FillMachine3(index) then
						sender.ItemIcon.alpha = 80
					end
				elseif main_type == 5 then
					if FillMachine4(index) then
						sender.ItemIcon.alpha = 80
					end
				else
					if main_type ~= 3 then
						index_right = index
						if main_type == 1 then
							FillMachine(index)
						elseif main_type == 2 then
							FillMachine1(index)
						end
						sender.ItemIcon.alpha = 80
					else
						if ui.object2.ItemIcon == nil then
							convert[1].page = current_page
							convert[1].index = index
							convert[1].cid = current_characters
							convert[1].type = current_selected
							FillMachine2(index, 1)
							sender.ItemIcon.alpha = 80
						elseif ui.object2.ItemIcon ~= nil and ui.object3.ItemIcon == nil then
							convert[2].page = current_page
							convert[2].index = index
							convert[2].cid = current_characters
							convert[2].type = current_selected
							FillMachine2(index, 2)
							sender.ItemIcon.alpha = 80
						end
					end
				end
			end
		end,
		SpawnNewWeaponControl(),
		SpawnNewStarControl(),
	}
end

function SpawnNewWeaponControl()
	return Gui.Control
	{
		Visible = false,
		Size = Vector2(54,30),
		Location = Vector2(212 - 60,100 - 37),
		BackgroundColor = ARGB(255, 255, 255, 255),
	}
end

function SpawnNewStarControl()
	return Gui.Control "ib_star"
	{			
		Visible = false,
		Size = Vector2(68,12),
		Location = Vector2(212 - 112,10),
		BackgroundColor = ARGB(255, 255, 255, 255),
	}
end

weapon_info_page = Gui.Create()
{
	Gui.Control "ctrl_ib_container"
	{
		Size = Vector2(424, 400),
		Location = Vector2(19, 18),
		BackgroundColor = ARGB(0, 255, 255, 255),

		create_weapon_page(1, 0, 0),
		create_weapon_page(2, 1, 0),

		create_weapon_page(3, 0, 1),
		create_weapon_page(4, 1, 1),

		create_weapon_page(5, 0, 2),
		create_weapon_page(6, 1, 2),

		create_weapon_page(7, 0, 3),
		create_weapon_page(8, 1, 3),
	},
}

--服装
function create_dress_page(index, line, list)
	return Gui.ItemBoxBtn
	{
		Style = "Gui.ItemBoxBtn_ib1",
		Size = Vector2(104, 200),
		Location = Vector2(104*line, 200*list),
		BtnVisible = false,
		CanSelect = false,

		EventMouseRightDown = function(sender, e)
			if sender.ItemIcon.alpha ~= 80 then
				if rpc_date[index] then
					tuozhuai.root.Parent = L_LobbyMain.LobbyMainWin.LobbyMain_Root
					index_tz = index
					tuozhuai.root.Visible = true
					local lobby_state = ptr_cast(game.CurrentState)
					local cursor_ScreenSize = lobby_state:GetScreenSize()
					local cursor_pos = lobby_state:GetCursorPos()
					tuozhuai.Image.Location = Vector2(cursor_pos.x-((cursor_ScreenSize.x - cursor_ScreenSize.y / 3 * 4) / 2) - 55, cursor_pos.y - 78)
					tuozhuai.Image.Size = Vector2(80, 156)
					if rpc_date[index].color > 0 and rpc_date[index].color < 8 then
						tuozhuai.Image.Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ibt_icon/"..rpc_date[index].name.."_"..rpc_date[index].color..".tga", Vector4(0, 0, 0, 0)),
						}
					else
						tuozhuai.Image.Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ibt_icon/"..rpc_date[index].name..".tga", Vector4(0, 0, 0, 0)),
						}
					end
					local ibbtn = ptr_cast(dress_info_page.ctrl_ib_container:GetChildByIndex(index-1))
					ibbtn.ItemIcon.alpha = 80
				end
				Highlight(current_selected,rpc_date[index].mType)
			end
		end,
		EventMouseEnter = function(sender, e)
			if sender.Loading == false then
				L_ToolTips.FillToolTipsWindow(5, index, sender)
			end
		end,
		EventToolTipsShow = function(sender, e)
			L_ToolTips.ShowToolTipsShowWindow(sender)
		end,
		EventMouseLeave = function(sender, e)
			L_ToolTips.HideToolTipsWindow()
		end,
		EventMouseUp = function(sender, e)
			if sender.ItemIcon.alpha ~= 80 then
				if main_type == 4 then
					if FillMachine3(index) then
						sender.ItemIcon.alpha = 80
					end
				elseif main_type == 5 then
					if FillMachine4(index) then
						sender.ItemIcon.alpha = 80
					end
				else
					if main_type ~= 3 then
						index_right = index
						if main_type == 1 then
							FillMachine(index)
						elseif main_type == 2 then
							FillMachine1(index)
						end
						sender.ItemIcon.alpha = 80
					else
						if ui.object2.ItemIcon == nil then
							convert[1].page = current_page
							convert[1].index = index
							convert[1].cid = current_characters
							convert[1].type = current_selected
							FillMachine2(index, 1)
							sender.ItemIcon.alpha = 80
						elseif ui.object2.ItemIcon ~= nil and ui.object3.ItemIcon == nil then
							convert[2].page = current_page
							convert[2].index = index
							convert[2].cid = current_characters
							convert[2].type = current_selected
							FillMachine2(index, 2)
							sender.ItemIcon.alpha = 80
						end
					end
				end
			end
		end,
		SpawnNewDressControl(),
		SpawnNewDressStarControl()
	}
end

function SpawnNewDressControl()
	return Gui.Control
	{
		Visible = false,
		Size = Vector2(54,30),
		Location = Vector2(64 - 19,200 - 37),
		BackgroundColor = ARGB(255, 255, 255, 255),
	}
end

function SpawnNewDressStarControl()
	return Gui.Control "ib_star"
	{			
		Visible = false,
		Size = Vector2(60,12),
		Location = Vector2(10,10),
		BackgroundColor = ARGB(255, 255, 255, 255),
	}
end

dress_info_page = Gui.Create()
{
	Gui.Control "ctrl_ib_container"
	{
		Size = Vector2(415, 400),
		Location = Vector2(19, 18),
		BackgroundColor = ARGB(0, 255, 255, 255),

		create_dress_page(1, 0, 0),
		create_dress_page(2, 1, 0),
		create_dress_page(3, 2, 0),
		create_dress_page(4, 3, 0),
		create_dress_page(5, 0, 1),
		create_dress_page(6, 1, 1),
		create_dress_page(7, 2, 1),
		create_dress_page(8, 3, 1),
	},
}

--配饰
function create_accessories_page(index, line, list)
	return Gui.ItemBoxBtn
	{
		Style = "Gui.ItemBoxBtn_ib2",
		Size = Vector2(104, 100),
		Location = Vector2(104*line, 100*list),
		BtnVisible = false,
		CanSelect = false,

		EventMouseRightDown = function(sender, e)
			if sender.ItemIcon.alpha ~= 80 then
				if rpc_date[index] then
					tuozhuai.root.Parent = L_LobbyMain.LobbyMainWin.LobbyMain_Root
					index_tz = index
					tuozhuai.root.Visible = true
					local lobby_state = ptr_cast(game.CurrentState)
					local cursor_ScreenSize = lobby_state:GetScreenSize()
					local cursor_pos = lobby_state:GetCursorPos()
					tuozhuai.Image.Location = Vector2(cursor_pos.x-((cursor_ScreenSize.x - cursor_ScreenSize.y / 3 * 4) / 2) - 51, cursor_pos.y - 34)
					tuozhuai.Image.Size = Vector2(72, 68)
					if rpc_date[index].color > 0 and rpc_date[index].color < 8 then
						tuozhuai.Image.Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ibt_icon/"..rpc_date[index].name.."_"..rpc_date[index].color..".tga", Vector4(0, 0, 0, 0)),
						}
					else
						tuozhuai.Image.Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ibt_icon/"..rpc_date[index].name..".tga", Vector4(0, 0, 0, 0)),
						}
					end
					local ibbtn = ptr_cast(accessories_info_page.ctrl_ib_container:GetChildByIndex(index-1))
					ibbtn.ItemIcon.alpha = 80
				end
				Highlight(current_selected,rpc_date[index].mType)
			end
		end,
		EventMouseEnter = function(sender, e)
			if sender.Loading == false then
				L_ToolTips.FillToolTipsWindow(5, index, sender)
			end
		end,
		EventToolTipsShow = function(sender, e)
			L_ToolTips.ShowToolTipsShowWindow(sender)
		end,
		EventMouseLeave = function(sender, e)
			L_ToolTips.HideToolTipsWindow()
		end,
		EventMouseUp = function(sender, e)
			if sender.ItemIcon.alpha ~= 80 then
				if main_type == 4 then
					if FillMachine3(index) then
						sender.ItemIcon.alpha = 80
					end
				elseif main_type == 5 then
					if FillMachine4(index) then
						sender.ItemIcon.alpha = 80
					end
				else
					if main_type ~= 3 then
						index_right = index
						if main_type == 1 then
							FillMachine(index)
						elseif main_type == 2 then
							FillMachine1(index)
						end
						sender.ItemIcon.alpha = 80
					else
						if ui.object2.ItemIcon == nil then
							convert[1].page = current_page
							convert[1].index = index
							convert[1].cid = current_characters
							convert[1].type = current_selected
							FillMachine2(index, 1)
							sender.ItemIcon.alpha = 80
						elseif ui.object2.ItemIcon ~= nil and ui.object3.ItemIcon == nil then
							convert[2].page = current_page
							convert[2].index = index
							convert[2].cid = current_characters
							convert[2].type = current_selected
							FillMachine2(index, 2)
							sender.ItemIcon.alpha = 80
						end
					end
				end
			end
		end,
		SpawnNewAccessoriesControl(),
		SpawnNewAccessoriesStarControl()
	}
end

function SpawnNewAccessoriesControl()
	return Gui.Control
	{
		Visible = false,
		Size = Vector2(54,30),
		Location = Vector2(64 - 19,100 - 37),
		BackgroundColor = ARGB(255, 255, 255, 255),
	}
end

function SpawnNewAccessoriesStarControl()
	return Gui.Control "ib_star"
	{			
		Visible = false,
		Size = Vector2(60,12),
		Location = Vector2(10,10),
		BackgroundColor = ARGB(255, 255, 255, 255),
	}
end

accessories_info_page = Gui.Create()
{
	Gui.Control "ctrl_ib_container"
	{
		Size = Vector2(415, 400),
		Location = Vector2(19, 18),
		BackgroundColor = ARGB(0, 255, 255, 255),

		create_accessories_page(1, 0, 0),
		create_accessories_page(2, 1, 0),
		create_accessories_page(3, 2, 0),
		create_accessories_page(4, 3, 0),

		create_accessories_page(5, 0, 1),
		create_accessories_page(6, 1, 1),
		create_accessories_page(7, 2, 1),
		create_accessories_page(8, 3, 1),

		create_accessories_page(9, 0, 2),
		create_accessories_page(10, 1, 2),
		create_accessories_page(11, 2, 2),
		create_accessories_page(12, 3, 2),

		create_accessories_page(13, 0, 3),
		create_accessories_page(14, 1, 3),
		create_accessories_page(15, 2, 3),
		create_accessories_page(16, 3, 3),
	},
}

--素材
function create_material_page(index, line, list)
	return Gui.ItemBoxBtn
	{
		Style = "Gui.ItemBoxBtn_ib2",
		Size = Vector2(104, 100),
		Location = Vector2(104*line, 100*list),
		BtnVisible = false,
		CanSelect = false,

		EventMouseRightDown = function(sender, e)
			if sender.ItemIcon.alpha ~= 80 then
				if rpc_date[index] then
					tuozhuai.root.Parent = L_LobbyMain.LobbyMainWin.LobbyMain_Root
					index_tz = index
					tuozhuai.root.Visible = true
					local lobby_state = ptr_cast(game.CurrentState)
					local cursor_ScreenSize = lobby_state:GetScreenSize()
					local cursor_pos = lobby_state:GetCursorPos()
					tuozhuai.Image.Location = Vector2(cursor_pos.x-((cursor_ScreenSize.x - cursor_ScreenSize.y / 3 * 4) / 2) - 51, cursor_pos.y - 34)
					tuozhuai.Image.Size = Vector2(72, 68)
					if rpc_date[index].color > 0 and rpc_date[index].color < 8 then
						tuozhuai.Image.Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ibt_icon/"..rpc_date[index].name.."_"..rpc_date[index].color..".tga", Vector4(0, 0, 0, 0)),
						}
					else
						tuozhuai.Image.Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ibt_icon/"..rpc_date[index].name..".tga", Vector4(0, 0, 0, 0)),
						}
					end
					local ibbtn = ptr_cast(material_info_page.ctrl_ib_container:GetChildByIndex(index-1))
					ibbtn.ItemIcon.alpha = 80
				end
				Highlight(current_selected,rpc_date[index].mType)
			end
		end,
		EventMouseEnter = function(sender, e)
			if sender.Loading == false then
				L_ToolTips.FillToolTipsWindow(5, index, sender)
			end
		end,
		EventToolTipsShow = function(sender, e)
			L_ToolTips.ShowToolTipsShowWindow(sender)
		end,
		EventMouseLeave = function(sender, e)
			L_ToolTips.HideToolTipsWindow()
		end,
		EventMouseUp = function(sender, e)
			if sender.ItemIcon.alpha ~= 80 then
				if main_type == 4 then
					if rpc_date[index].mType == 31 or rpc_date[index].mType == 32 then
						if melting_table.playeritemid == -1 then
							sender.ItemIcon.alpha = 80
							if rpc_date[index].mType == 32 then
								is_formula = true
								melting_result = rpc_date[index].result
								ui.formula_info.Visible = true
							end
							ui.ibtn_1.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..rpc_date[index].name..".tga")
							melting_table.playeritemid = rpc_date[index].playeritemid
							melting_table.value = rpc_date[index].mValue
							ui.lab_des.Text = rpc_date[index].description
							melting_items = rpc_date[index].items
							FillMachine3(0)
						end
					else
						if FillMachine3(index) then
							if rpc_date[index].common.quantity == 1 then
								rpc_date[index].common.quantity = 0
								sender.ItemIcon.alpha = 80
							else
								rpc_date[index].common.quantity = rpc_date[index].common.quantity - 1
							end
							local Control = ptr_cast(sender:GetChildByIndex(2))
							L_LobbyMain.FillNumber(rpc_date[index].common.quantity, Control)
						end
					end
				else
					if rpc_date[index].mType ~= 8 and rpc_date[index].mType ~= 9 then
						index_right = index
						if main_type == 1 then
							FillMachine(index)
						elseif main_type == 2 then
							rpc_slotting.sloterItemId = rpc_date[index].playeritemid
							FillMachine1(index)
						end
						sender.ItemIcon.alpha = 80
					else
						if rpc_date_object then
							rpc_insert.index = 0
							for i = 1, 6 do
								if rpc_date_object.combineDetail[i].state == 1 and rpc_date_object.combineDetail[i].desc == "" then
									rpc_insert.index = i
									break
								end
							end
							if rpc_insert.index ~= 0 then
								rpc_insert.propertyItemId = rpc_date[index].playeritemid
								local cost= 0
								if rpc_date[index].mValue == 1 then
									cost = 250
								elseif rpc_date[index].mValue == 2 then
									cost = 500
								elseif rpc_date[index].mValue == 3 then
									cost = 1000
								end
								
								MessageBox.ShowWithConfirmCancel(lang:GetText("镶嵌该属性部件需要花费")..cost..lang:GetText("C币\n您是否要继续？"),
								function()
									rpc.safecallload("insert",rpc_insert,
									function(data)
										if data.result == 1 then
											MessageBox.ShowWithTimer(1,data.msg)
											gui:PlayAudio("kUIA_COMPOUND_FAIL")
										else
											gui:PlayAudio("kUIA_COMPOUND_SUCCEED")
										end
										rpc_date_object = data.item
										FillStorage()
										FillMachine1(0)
										reset(temp,false)
										return
									end)
								end)
							end
						end
					end
				end
			end
		end,
		SpawnNewpropControl(),
	}
end

function SpawnNewpropControl()
	return Gui.Control
	{
		Size = Vector2(70, 16),
		Location = Vector2(29, 78),
		BackgroundColor = ARGB(0, 255, 255, 255),
		Gui.Control "c1"
		{
			Size = Vector2(20, 16),
			Location = Vector2(5, 0),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Visible = false,
		},
		Gui.Control "c2"
		{
			Size = Vector2(20, 16),
			Location = Vector2(20, 0),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Visible = false,
		},
		Gui.Control "c3"
		{
			Size = Vector2(20, 16),
			Location = Vector2(35, 0),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Visible = false,
		},
		Gui.Control "c4"
		{
			Size = Vector2(20, 16),
			Location = Vector2(50, 0),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Visible = false,
		},
	}
end

material_info_page = Gui.Create()
{
	Gui.Control "ctrl_ib_container"
	{
		Size = Vector2(415, 400),
		Location = Vector2(19, 18),
		BackgroundColor = ARGB(0, 255, 255, 255),

		create_material_page(1, 0, 0),
		create_material_page(2, 1, 0),
		create_material_page(3, 2, 0),
		create_material_page(4, 3, 0),

		create_material_page(5, 0, 1),
		create_material_page(6, 1, 1),
		create_material_page(7, 2, 1),
		create_material_page(8, 3, 1),

		create_material_page(9, 0, 2),
		create_material_page(10, 1, 2),
		create_material_page(11, 2, 2),
		create_material_page(12, 3, 2),

		create_material_page(13, 0, 3),
		create_material_page(14, 1, 3),
		create_material_page(15, 2, 3),
		create_material_page(16, 3, 3),
	},
}

--快速购买界面
Rapid_Shopping_Win = Gui.Create()
{
	Gui.Control "Rapid_Shopping_root"
	{
		Size = Vector2(376, 375),
		BackgroundColor = ARGB(0, 255, 255, 255),

		Gui.Control
		{
			Size = Vector2(376, 375),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Location = Vector2(0, 0),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/main_bar01.dds", Vector4(20, 20, 20, 20)),
			},

			Gui.Control
			{
				Size = Vector2(344, 343),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Location = Vector2(16, 16),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/main_bar02.dds", Vector4(8, 8, 8, 8)),
				},

				Gui.Label
				{
					Size = Vector2(344, 35),
					Location = Vector2(0, 0),
					TextColor = ARGB(255, 255, 210, 0),
					FontSize = 18,
					TextAlign = "kAlignLeftMiddle",
					Text = lang:GetText("快速购买"),
					BackgroundColor = ARGB(255,255,255,255),
					TextPadding = Vector4(8,0,0,8),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_onlinetime_bg_5.dds", Vector4(8, 8, 8, 8)),
					},
				},

				Gui.Control
				{
					Size = Vector2(325, 251),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Location = Vector2(10, 38),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_01.dds", Vector4(40, 40, 40, 40)),
					},

					Gui.Control "bg"
					{
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_06.dds", Vector4(32, 28, 32, 50)),
						},

						Gui.ItemBoxBtn "Imgae"
						{
							Style = "Gui.ItemBoxBtn_ib",
							Size = Vector2(153,79),
							Location = Vector2(76,26),
							Enable = false,
							Visible = false,
							BackgroundColor = ARGB(255,255,255,255),
							Skin = Gui.ItemBoxBtnSkin
							{
								NeutralNormalImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_slot.dds", Vector4(10, 10, 10, 10)),
								NeutralHoverImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_slot.dds", Vector4(10, 10, 10, 10)),
								NeutralSelectedImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_slot.dds", Vector4(10, 10, 10, 10)),
								NeutralDisabledImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_slot.dds", Vector4(10, 10, 10, 10)),
							},
						},
						Gui.ItemBoxBtn "Imgae_a"
						{
							Style = "Gui.ItemBoxBtn_ib",
							Size = Vector2(134,89),
							Location = Vector2(22,26),
							CanSelect = false,
							--Visible = false,
							BackgroundColor = ARGB(255,255,255,255),
							Skin = Gui.ItemBoxBtnSkin
							{
								NeutralNormalImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_02.dds", Vector4(0, 0, 0, 0)),
								NeutralHoverImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_02.dds", Vector4(0, 0, 0, 0)),
								NeutralSelectedImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_02.dds", Vector4(0, 0, 0, 0)),
								NeutralDisabledImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_02.dds", Vector4(0, 0, 0, 0)),
							},
							EventMouseUp = function(sender, e)
								price = item_rpc.prices[3]
								shop_fast_buy.sid = item_rpc.items[3].sid
								sender.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/failnoback.tga")
								Rapid_Shopping_Win.Imgae_b.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/failnogone_disabled.tga")
								Rapid_Shopping_Win.Imgae_b.Selected = false
							end,
						},
						Gui.ItemBoxBtn "Imgae_b"
						{
							Style = "Gui.ItemBoxBtn_ib",
							Size = Vector2(134,89),
							Location = Vector2(158,26),
							--Visible = false,
							CanSelect = false,
							BackgroundColor = ARGB(255,255,255,255),
							Skin = Gui.ItemBoxBtnSkin
							{
								NeutralNormalImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_02.dds", Vector4(0, 0, 0, 0)),
								NeutralHoverImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_02.dds", Vector4(0, 0, 0, 0)),
								NeutralSelectedImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_02.dds", Vector4(0, 0, 0, 0)),
								NeutralDisabledImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_02.dds", Vector4(0, 0, 0, 0)),
							},
							EventMouseUp = function(sender, e)
								price = item_rpc.prices[4]
								shop_fast_buy.sid = item_rpc.items[4].sid
								sender.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/failnogone.tga")
								Rapid_Shopping_Win.Imgae_a.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/failnoback_disabled.tga")
								Rapid_Shopping_Win.Imgae_a.Selected = false
							end,
						},

						Gui.Button
						{
							Size = Vector2(28,28),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Text = "-",
							FontSize = 40,
							Padding = Vector4(0, 0, 0, 3),
							TextColor = ARGB(255, 255, 174, 0),
							HighlightTextColor = ARGB(255, 255, 174, 0),
							Skin = Gui.ButtonSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/Compose/lb_fastsettlement_button01_normal.dds", Vector4(0, 0, 0, 0)),
								HoverImage = Gui.Image("LobbyUI/Compose/lb_fastsettlement_button01_hover.dds", Vector4(0, 0, 0, 0)),
								DownImage = Gui.Image("LobbyUI/Compose/lb_fastsettlement_button01_down.dds", Vector4(0, 0, 0, 0)),
								DisabledImage = Gui.Image("LobbyUI/Compose/lb_fastsettlement_button01_disabled.dds", Vector4(0, 0, 0, 0)),
							},
							EventClick = function()
								if tonumber(Rapid_Shopping_Win.Tbox_Totle_num.Text) > 1 then
									Rapid_Shopping_Win.Tbox_Totle_num.Text = tonumber(Rapid_Shopping_Win.Tbox_Totle_num.Text) - 1
								end
							end,
						},

						Gui.Textbox "Tbox_Totle_num"
						{
							Size = Vector2(154, 34),
							TextColor = ARGB(255, 255, 210, 0),
							FontSize = 24,
							Text = "50",
							MaxLength = 4,
							BackgroundColor = ARGB(255,255,255,255),
							TextPadding = Vector4(72,0,0,0),
							InputNumberOnly = true,
							Skin = Gui.TextboxSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_04.dds", Vector4(12, 0, 12, 0)),
								ActiveImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_04.dds", Vector4(12, 0, 12, 0)),
								DisabledImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_04.dds", Vector4(12, 0, 12, 0)),
							},
							EventTextChanged = function()
								if Rapid_Shopping_Win.Tbox_Totle_num.Text == "" then
									Rapid_Shopping_Win.cost.Text = 0
								else
									if math.ceil(tonumber(Rapid_Shopping_Win.Tbox_Totle_num.Text)) > 300 then
										Rapid_Shopping_Win.Tbox_Totle_num.Text = "300"
										return
									elseif math.ceil(tonumber(Rapid_Shopping_Win.Tbox_Totle_num.Text)) < 1 then
										Rapid_Shopping_Win.Tbox_Totle_num.Text = "1"
										return
									end
									if string.sub(Rapid_Shopping_Win.Tbox_Totle_num.Text,1,1) == "0" then
										Rapid_Shopping_Win.Tbox_Totle_num.Text = string.sub(Rapid_Shopping_Win.Tbox_Totle_num.Text,2)
										return
									end
									Rapid_Shopping_Win.cost.Text = tonumber(Rapid_Shopping_Win.Tbox_Totle_num.Text) * price
								end
								Rapid_Shopping_Win.Tbox_Totle_num.TextPadding = Vector4(77 - 5*string.len(Rapid_Shopping_Win.Tbox_Totle_num.Text),0,0,0)
							end,

							EventLeave = function()
								if Rapid_Shopping_Win.Tbox_Totle_num.Text == "" then
									Rapid_Shopping_Win.Tbox_Totle_num.Text = 1
								end
							end,

							EventValueNoNumber = function()
								Rapid_Shopping_Win.lab_timer_ctr:Show()
							end,
						},

						Gui.Button
						{
							Size = Vector2(28,28),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Text = "+",
							FontSize = 28,
							TextColor = ARGB(255, 255, 174, 0),
							Padding = Vector4(0, 0, 0, 3),
							HighlightTextColor = ARGB(255, 255, 174, 0),
							Skin = Gui.ButtonSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/Compose/lb_fastsettlement_button01_normal.dds", Vector4(0, 0, 0, 0)),
								HoverImage = Gui.Image("LobbyUI/Compose/lb_fastsettlement_button01_hover.dds", Vector4(0, 0, 0, 0)),
								DownImage = Gui.Image("LobbyUI/Compose/lb_fastsettlement_button01_down.dds", Vector4(0, 0, 0, 0)),
								DisabledImage = Gui.Image("LobbyUI/Compose/lb_fastsettlement_button01_disabled.dds", Vector4(0, 0, 0, 0)),
							},
							EventClick = function()
								if tonumber(Rapid_Shopping_Win.Tbox_Totle_num.Text) < 300 then
									Rapid_Shopping_Win.Tbox_Totle_num.Text = tonumber(Rapid_Shopping_Win.Tbox_Totle_num.Text) + 1
								end
							end,
						},
						Gui.Label "W_name"
						{
							Size = Vector2(304, 28),
							Location = Vector2(0, 0),
							TextColor = ARGB(255, 241, 198, 0),
							FontSize = 16,
							TextAlign = "kAlignCenterMiddle",
						},
						Gui.TextArea "des"
						{
							Size = Vector2(260, 50),
							Location = Vector2(40, 105),
							TextColor = ARGB(255, 255, 204, 0),
							FontSize = 16,
							Readonly = true,
							--Enable = false,
							Fold = true,
							BackgroundColor = ARGB(255,255,255,255),
						},

						Gui.Button "BTN_1"
						{
							Size = Vector2(44,56),
							Location = Vector2(33, 38),
							Skin = Gui.ButtonSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/Compose/lb_fastsettlement_button03_normal.dds", Vector4(0, 0, 0, 0)),
								HoverImage = Gui.Image("LobbyUI/Compose/lb_fastsettlement_button03_hover.dds", Vector4(0, 0, 0, 0)),
								DownImage = Gui.Image("LobbyUI/Compose/lb_fastsettlement_button03_down.dds", Vector4(0, 0, 0, 0)),
								DisabledImage = Gui.Image("LobbyUI/Compose/lb_fastsettlement_button03_disabled.dds", Vector4(0, 0, 0, 0)),
							},
							EventClick = function()
								if Rapid_Shopping_index > 1 then
									Rapid_Shopping_index = Rapid_Shopping_index - 1
									Rapid_Shopping_Win.W_name.Text = item_rpc.items[Rapid_Shopping_index].display
									Rapid_Shopping_Win.des.Text = item_rpc.items[Rapid_Shopping_index].description
									shop_fast_buy.sid = item_rpc.items[Rapid_Shopping_index].sid
									price = item_rpc.prices[Rapid_Shopping_index]
									Rapid_Shopping_Win.Imgae.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..item_rpc.items[Rapid_Shopping_index].name..".tga")
									Rapid_Shopping_Win.cost.Text = price * tonumber(Rapid_Shopping_Win.Tbox_Totle_num.Text)
								end
							end,
						},
						Gui.Button "BTN_2"
						{
							Size = Vector2(44,56),
							Location = Vector2(226, 38),
							Skin = Gui.ButtonSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/Compose/lb_fastsettlement_button02_normal.dds", Vector4(0, 0, 0, 0)),
								HoverImage = Gui.Image("LobbyUI/Compose/lb_fastsettlement_button02_hover.dds", Vector4(0, 0, 0, 0)),
								DownImage = Gui.Image("LobbyUI/Compose/lb_fastsettlement_button02_down.dds", Vector4(0, 0, 0, 0)),
								DisabledImage = Gui.Image("LobbyUI/Compose/lb_fastsettlement_button02_disabled.dds", Vector4(0, 0, 0, 0)),
							},
							EventClick = function()
								if item_rpc.items[Rapid_Shopping_index + 1] then
									Rapid_Shopping_index = Rapid_Shopping_index + 1
									Rapid_Shopping_Win.W_name.Text = item_rpc.items[Rapid_Shopping_index].display
									Rapid_Shopping_Win.des.Text = item_rpc.items[Rapid_Shopping_index].description
									shop_fast_buy.sid = item_rpc.items[Rapid_Shopping_index].sid
									price = item_rpc.prices[Rapid_Shopping_index]
									Rapid_Shopping_Win.Imgae.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..item_rpc.items[Rapid_Shopping_index].name..".tga")
									Rapid_Shopping_Win.cost.Text = price * tonumber(Rapid_Shopping_Win.Tbox_Totle_num.Text)
								end
							end,
						},
					},

					Gui.Label
					{
						Size = Vector2(110, 28),
						Location = Vector2(25, 218),
						TextColor = ARGB(255, 255, 210, 0),
						FontSize = 16,
						TextAlign = "kAlignRightMiddle",
						Text = lang:GetText("您总共要支付"),
						BackgroundColor = ARGB(0,255,255,255),
						TextPadding = Vector4(0,0,0,3),
					},

					Gui.Label "cost"
					{
						Size = Vector2(118, 28),
						Location = Vector2(137, 218),
						TextColor = ARGB(255, 255, 210, 0),
						FontSize = 18,
						TextAlign = "kAlignCenterMiddle",
						Text = "999999",
						BackgroundColor = ARGB(255,255,255,255),
						TextPadding = Vector4(0,0,0,3),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_03.dds", Vector4(8, 8, 8, 8)),
						},
					},

					Gui.Label "FC"
					{
						Size = Vector2(60, 28),
						Location = Vector2(257, 218),
						TextColor = ARGB(255, 255, 210, 0),
						FontSize = 18,
						TextAlign = "kAlignCenterMiddle",
						Text = lang:GetText("FC点"),
						BackgroundColor = ARGB(0,255,255,255),
						TextPadding = Vector4(0,0,0,3),
					},

					Gui.Label "lab_timer_ctr"
					{
						Size = Vector2(116,35),
						Location = Vector2(100, 193),
						BackgroundColor = ARGB(255, 255, 255, 255),
						TextColor = ARGB(255, 0, 0, 0),
						Visible = false,
						UseTimer = true,
						DisplayTime = 1,
						FontSize = 12,
						TextAlign = "kAlignCenterMiddle",
						Text = lang:GetText("只能输入数字0～9"),
						TextPadding = Vector4(0,8,0,0),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_05.dds", Vector4(37, 18, 14, 12)),
						},

						EventClose = function()

						end
					},
				},

				Gui.Button
				{
					Size = Vector2(184,44),
					Location = Vector2(83, 298),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Text = lang:GetText("购 买"),
					TextColor = ARGB(255, 229, 255, 252),
					HighlightTextColor = ARGB(255, 229, 255, 252),
					Padding = Vector4(0, 0, 0, 5),
					FontSize = 18,
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_onlinetime_button_2_normal.dds", Vector4(63, 0, 57, 0)),
						HoverImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_onlinetime_button_2_hover.dds", Vector4(63, 0, 57, 0)),
						DownImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_onlinetime_button_2_down.dds", Vector4(63, 0, 57, 0)),
						DisabledImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_onlinetime_button_2_disabled.dds", Vector4(63, 0, 57, 0)),
					},
					EventClick = function()
						shop_fast_buy.num = tonumber(Rapid_Shopping_Win.Tbox_Totle_num.Text)
						rpc.safecallload("shop_fast_buy",shop_fast_buy,
						function(data)
							if data.result == 0 then
								MessageBox.ShowWithTwoButtons(lang:GetText("你的FC点不足，请充值"),lang:GetText("充值"),lang:GetText("取消"),
								function()
									gui:ShowIE()
								end,
								nil
								)
								if modal then
									modal.Close()
									modal = nil
								end
							else
								local ibbtn = nil
								if main_type == 1 then
									if qianghua_index == 1 then
										ibbtn = ptr_cast(ui.qianghua:GetChildByIndex(1))
										index_table[1].playeritemid = data.item.playeritemid
										index_table[1].num = data.item.common.quantity
										rpc_string.strengthenItemId = data.item.playeritemid
									elseif qianghua_index == 2 then
										ibbtn = ptr_cast(ui.qianghua:GetChildByIndex(2))
										index_table[2].playeritemid = data.item.playeritemid
										index_table[2].num = data.item.common.quantity
										rpc_string.stableItemId = data.item.playeritemid
									elseif qianghua_index == 3 then
										ibbtn = ptr_cast(ui.qianghua:GetChildByIndex(3))
										index_table[3].playeritemid = data.item.playeritemid
										index_table[3].num = data.item.common.quantity
										rpc_string.safeItemId = data.item.playeritemid
									end
								elseif main_type == 2 then
									ibbtn = ui.dakong
									rpc_slotting.sloterItemId = data.item.playeritemid
									hole.playeritemid = data.item.playeritemid
									hole.num = data.item.common.quantity
								elseif main_type == 4 then
									ibbtn = ui.ibtn_1
									melting_table.playeritemid = data.item.playeritemid
									melting_table.value = data.item.mValue
									ui.lab_des.Text = data.item.description
								end
								if data.item.color > 0 and data.item.color < 8 then
									ibbtn.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..data.item.name.."_"..data.item.color..".tga")
								else
									ibbtn.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..data.item.name..".tga")
								end
								if main_type ~= 4 then
									local Control = ptr_cast(ibbtn:GetChildByIndex(2))
									L_LobbyMain.FillNumber(data.item.common.quantity, Control)
									Control.Visible = true
								end
								FillStorage()
								if main_type == 1 then
									FillMachine(0)
								elseif main_type == 2 then
									FillMachine1(0)
								elseif main_type == 4 then
									FillMachine3(0)
								end
								if modal then
									modal.Close()
									modal = nil
								end
							end
						end)
					end,
				},
			},
		},

		--退出
		Gui.Button
		{
			Size = Vector2(48,48),
			Location = Vector2(328, 0),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_normal.dds", Vector4(10, 10, 10, 10)),
				HoverImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_hover.dds", Vector4(10, 10, 10, 10)),
				DownImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_down.dds", Vector4(10, 10, 10, 10)),
				DisabledImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_disabled.dds", Vector4(0, 0, 0, 0)),
			},
			EventClick = function()
				if modal then
					modal.Close()
					modal = nil
				end
			end,
		},
	},
}

--恭喜界面
congratulation = Gui.Create()
{
	Gui.Control "root"
	{
		Size = Vector2(488, 333),
		Dock = "kDockCenter",
		BackgroundColor = ARGB(255, 255, 255, 255),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_success.dds", Vector4(93, 179, 105, 73)),
		},
		Gui.Control
		{
			Size = Vector2(240, 80),
			Location = Vector2(124, 90),
			BackgroundColor = ARGB(0, 255, 255, 255),
			Gui.Control "level"
			{
				Size = Vector2(80, 80),
				Location = Vector2(0, 0),
				BackgroundColor = ARGB(255, 255, 255, 255),
			},
			Gui.Control
			{
				Size = Vector2(32, 20),
				Location = Vector2(105, 30),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Compose/lb_synthesis_jiantou_r.dds", Vector4(0, 0, 0, 0)),
				},
			},
			Gui.Control "level1"
			{
				Size = Vector2(80, 80),
				Location = Vector2(160, 0),
				BackgroundColor = ARGB(255, 255, 255, 255),
			},
		},


		Gui.Label "text"
		{
			Size = Vector2(468, 120),
			Location = Vector2(15, 143),
			TextColor = ARGB(255, 0, 0, 0),
			FontSize = 20,
			TextAlign = "kAlignCenterMiddle",
		},
		Gui.Label
		{
			Size = Vector2(164, 28),
			Location = Vector2(86, 240),
			Text = lang:GetText("战斗力提升到")..":",
			TextColor = ARGB(255, 0, 0, 0),
			FontSize = 18,
			TextAlign = "kAlignRightMiddle",
		},
		Gui.Label
		{
			Size = Vector2(164, 28),
			Location = Vector2(85, 239),
			Text = lang:GetText("战斗力提升到")..":",
			TextColor = ARGB(255, 255, 204, 0),
			TextAlign = "kAlignRightMiddle",
			FontSize = 18,
		},
		Gui.FlowLayout "fightnum"
		{
			Location = Vector2(246, 243),
			Size = Vector2(100, 24),
			Align = "kAlignCenterMiddle",
			ControlAlign = "kAlignCenterMiddle",
			ControlSpace = 0,
		},
		Gui.Control
		{
			Size = Vector2(21, 30),
			Location = Vector2(336, 238),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/Compose/lb_synthesis_jiantou.dds", Vector4(0, 0, 0, 0)),
			},
		},
		Gui.Button
		{
			Size = Vector2(124,44),
			Location = Vector2(181, 272),
			Text = lang:GetText("确 定"),
			TextColor = ARGB(255, 229, 255, 252),
			HighlightTextColor = ARGB(255, 229, 255, 252),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/lb_onlinetime_button_2_normal.dds", Vector4(5, 5, 5, 5)),
				HoverImage = Gui.Image("LobbyUI/lb_onlinetime_button_2_hover.dds", Vector4(5, 5, 5, 5)),
				DownImage = Gui.Image("LobbyUI/lb_onlinetime_button_2_down.dds", Vector4(5, 5, 5, 5)),
				DisabledImage = Gui.Image("LobbyUI/lb_onlinetime_button_2_disabled.dds", Vector4(5, 5, 5, 5)),
			},
			EventClick = function()
				if congratulationmodal then
					congratulationmodal.Close()
					congratulationmodal = nil
				end
			end
		},
	},
}

function CreateFailedAwards(index,x,y)
	return Gui.ItemBoxBtn
			{
				Style = "Gui.ItemBoxBtn_ib",
				Size = Vector2(72, 72),
				Location = Vector2(x, y),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Padding = Vector4(10,10,10,10),
				Skin = Gui.ItemBoxBtnSkin
				{
					NeutralNormalImage =  Gui.Image("LobbyUI/team/NewFight/lb_synthesis_common_slot.dds", Vector4(0, 0, 0, 0)),
					NeutralSelectedImage =  Gui.Image("LobbyUI/team/NewFight/lb_synthesis_common_slot.dds", Vector4(0, 0, 0, 0)),
					NeutralDisabledImage =  Gui.Image("LobbyUI/team/NewFight/lb_synthesis_common_slot.dds", Vector4(0, 0, 0, 0)),
				},
				EventMouseEnter = function(sender, e)
					L_ToolTips.FillToolTipsVIPPresent(index, failedmodal.root, data_temp.failAwards)
				end,
				EventToolTipsShow = function(sender, e)
					if data_temp.failAwards[index] then
						local loc = sender.Location + sender.Parent.Location + sender.Parent.Parent.Location
						L_ToolTips.ShowToolTipsShowWindow(sender,Vector2(800,600), loc)
					end
				end,
				EventMouseLeave = function(sender, e)
					L_ToolTips.HideToolTipsWindow()
				end,
			}
end

--失败界面
failed = Gui.Create()
{
	Gui.Control "root"
	{
		Size = Vector2(488, 405),
		Dock = "kDockCenter",
		BackgroundColor = ARGB(204, 255, 255, 255),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/lb_onlinetime_bg_4.dds", Vector4(20, 20, 20, 20)),
		},
		Gui.Control
		{
			Size = Vector2(240, 80),
			Location = Vector2(124, 30),
			BackgroundColor = ARGB(0, 255, 255, 255),
			Gui.Control "level"
			{
				Size = Vector2(80, 80),
				Location = Vector2(0, 0),
				BackgroundColor = ARGB(255, 255, 255, 255),
			},
			Gui.Control "jiantou_2"
			{
				Size = Vector2(32, 20),
				Location = Vector2(105, 30),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Compose/lb_synthesis_jiantou_2_r.dds", Vector4(0, 0, 0, 0)),
				},
			},
			Gui.Control "level1"
			{
				Size = Vector2(80, 80),
				Location = Vector2(160, 0),
				BackgroundColor = ARGB(255, 255, 255, 255),
			},
		},
		Gui.Label "text"
		{
			Size = Vector2(440, 120),
			Location = Vector2(24, 75),
			TextColor = ARGB(255, 0, 0, 0),
			FontSize = 24,
			TextAlign = "kAlignCenterMiddle",
		},
		Gui.Label "text2"
		{
			Size = Vector2(184, 28),
			Location = Vector2(56, 180),
			Text = lang:GetText("战斗力降低到")..":",
			TextColor = ARGB(255, 0, 0, 0),
			FontSize = 20,
			TextAlign = "kAlignRightMiddle",
		},
		Gui.Label "text1"
		{
			Size = Vector2(184, 28),
			Location = Vector2(55, 179),
			Text = lang:GetText("战斗力降低到")..":",
			TextColor = ARGB(255, 255, 204, 0),
			FontSize = 20,
			TextAlign = "kAlignRightMiddle",
		},
		Gui.FlowLayout "fightnum"
		{
			Location = Vector2(226, 183),
			Size = Vector2(100, 24),
			Align = "kAlignCenterMiddle",
			ControlAlign = "kAlignCenterMiddle",
			ControlSpace = 0,
		},
		Gui.Control "jiantou"
		{
			Size = Vector2(21, 30),
			Location = Vector2(316, 178),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/Compose/lb_synthesis_jiantou_2.dds", Vector4(0, 0, 0, 0)),
			},
		},
		
		Gui.Control "ctrl_failed_get_container"
		{
			Size = Vector2(460, 116),
			Location = Vector2(14, 215),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/dailycheck/numberbar02.dds", Vector4(10, 0, 10, 0)),
			},
			Gui.Label
			{
				Size = Vector2(460, 20),
				Location = Vector2(0, 0),
				Text = lang:GetText("获得以下失败产物"),
				TextColor = ARGB(255, 255, 192, 0),
				FontSize = 18,
				TextAlign = "kAlignCenterMiddle",
			},
			CreateFailedAwards(1,4,33),
			CreateFailedAwards(2,80,33),
			CreateFailedAwards(3,156,33),
			CreateFailedAwards(4,232,33),
			CreateFailedAwards(5,308,33),
			CreateFailedAwards(6,384,33),
		},
		
		Gui.Button
		{
			Size = Vector2(124,44), 
			Location = Vector2(182, 338),
			Text = lang:GetText("确 定"),
			TextColor = ARGB(255, 229, 255, 252),
			HighlightTextColor = ARGB(255, 229, 255, 252),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/lb_onlinetime_button_2_normal.dds", Vector4(5, 5, 5, 5)),
				HoverImage = Gui.Image("LobbyUI/lb_onlinetime_button_2_hover.dds", Vector4(5, 5, 5, 5)),
				DownImage = Gui.Image("LobbyUI/lb_onlinetime_button_2_down.dds", Vector4(5, 5, 5, 5)),
				DisabledImage = Gui.Image("LobbyUI/lb_onlinetime_button_2_disabled.dds", Vector4(5, 5, 5, 5)),
			},
			EventClick = function(sender, e)
				if failedmodal then
					failedmodal.Close()
					failedmodal = nil
				end
			end
		},

		-- Gui.TimeControl "time"
		-- {
			-- Size = Vector2(5,5),
			-- Dock = "kDockCenter",
			-- BackgroundColor = ARGB(0, 255, 255, 255),
			-- EventTimeOut = function(sender, e)
				-- if failedmodal then
					-- failedmodal.Close()
					-- failedmodal = nil
				-- end
			-- end
		-- },
	},
}

--熔炼领取界面
melting_ui = Gui.Create()
{
	Gui.Control "root"
	{
		Size = Vector2(488, 385),
		Dock = "kDockCenter",
		BackgroundColor = ARGB(255, 255, 255, 255),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_success.dds", Vector4(0, 0, 0, 0)),
		},
		Gui.Label
		{
			Size = Vector2(488, 32),
			Location = Vector2(1, 116),
			Text = lang:GetText("请选择熔炼产出物"),
			FontSize = 24,
			TextColor = ARGB(255, 0, 0, 0),
			TextAlign = "kAlignCenterMiddle",
		},
		Gui.Label
		{
			Size = Vector2(488, 32),
			Location = Vector2(0, 115),
			Text = lang:GetText("请选择熔炼产出物"),
			FontSize = 24,
			TextColor = ARGB(255, 255, 210, 0),
			TextAlign = "kAlignCenterMiddle",
		},
		Gui.Control
		{
			Size = Vector2(128, 132),
			Location = Vector2(53, 146),
			BackgroundColor = ARGB(0, 255, 255, 255),
			Gui.ItemBoxBtn "ibtn_1"
			{
				Size = Vector2(128, 100),
				Location = Vector2(0, 0),
				Empty = false,
				Type = 1,
				CanSelect = false,
				LoadingImage = Gui.AnimatedImage("LobbyUI/loading_ring.tga", 4, 2, 8),
				Skin = Gui.ItemBoxBtnSkin
				{
					NeutralNormalImage = Gui.Image("LobbyUI/Compose/lb_melting_slot_03.dds", Vector4(0, 0, 0, 0)),
					NeutralHoverImage = Gui.Image("LobbyUI/Compose/lb_melting_slot_03.dds", Vector4(0, 0, 0, 0)),
					NeutralSelectedImage = Gui.Image("LobbyUI/Compose/lb_melting_slot_03.dds", Vector4(0, 0, 0, 0)),
					NeutralDisabledImage = Gui.Image("LobbyUI/Compose/lb_melting_slot_03.dds", Vector4(0, 0, 0, 0)),
				},
				EventMouseEnter = function(sender, e)
					if sender.ItemIcon ~= nil then
						L_ToolTips.FillToolBigPresentWindow(1, meltingmodal.root, melting_rpc_data)
					end
				end,
				EventToolTipsShow = function(sender, e)
					if sender.ItemIcon ~= nil then
						if melting_rpc_data[1] ~= nil then
							L_ToolTips.ShowToolTipsShowWindow(sender,Vector2(1200,900),sender.Location + sender.Parent.Location + sender.Parent.Parent.Location)
						end
					end
				end,
				EventMouseLeave = function(sender, e)
					L_ToolTips.HideToolTipsWindow()
				end,
				SpawnControl()
			},
			Gui.Button "btn_1"
			{
				Size = Vector2(64, 32),
				Location = Vector2(0, 100),
				BackgroundColor = ARGB(255, 255, 255, 255),
				FontSize = 18,
				TextColor = ARGB(255, 37, 37, 37),
				TextAlign = "kAlignCenterMiddle",
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Compose/lb_melting_button_03_normal.dds", Vector4(0, 0, 0, 0)),
					HoverImage = Gui.Image("LobbyUI/Compose/lb_melting_button_03_hover.dds", Vector4(0, 0, 0, 0)),
					DownImage = Gui.Image("LobbyUI/Compose/lb_melting_button_03_down.dds", Vector4(0, 0, 0, 0)),
					DisabledImage = Gui.Image("LobbyUI/Compose/lb_melting_button_03_disabled.dds", Vector4(0, 0, 0, 0)),
				},
				EventClick = function(Sender,e)
					MessageBox.ShowWithConfirmCancel(lang:GetText("查看结果需要花费")..cost_lookover..lang:GetText("FC点您是否要继续？"),
					function()
						rpc.safecall("melting_output_lookover",{pid = ptr_cast(game.CurrentState):GetCharacterId(), index = 0},
						function(data)
							if data.result == 1 then
								MessageBox.ShowWithTwoButtons(lang:GetText("你的FC点不足，请充值"),lang:GetText("充值"),lang:GetText("取消"),
								function()
									gui:ShowIE()
								end,
								nil
								)
								if modal then
									modal.Close()
									modal = nil
								end
							else
								Sender.Enable = false
								Melting_lookover(1, data)
							end
						end)
					end)
				end
			},
			Gui.Button "btn_2"
			{
				Size = Vector2(64, 32),
				Location = Vector2(64, 100),
				BackgroundColor = ARGB(255, 255, 255, 255),
				FontSize = 18,
				TextColor = ARGB(255, 37, 37, 37),
				TextAlign = "kAlignCenterMiddle",
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Compose/lb_melting_button_03_b_normal.dds", Vector4(0, 0, 0, 0)),
					HoverImage = Gui.Image("LobbyUI/Compose/lb_melting_button_03_b_hover.dds", Vector4(0, 0, 0, 0)),
					DownImage = Gui.Image("LobbyUI/Compose/lb_melting_button_03_b_down.dds", Vector4(0, 0, 0, 0)),
					DisabledImage = Gui.Image("LobbyUI/Compose/lb_melting_button_03_b_disabled.dds", Vector4(0, 0, 0, 0)),
				},
				EventClick = function(Sender,e)
					Sender.Enable = false
					rpc.safecallload("melting_output_get",{pid = ptr_cast(game.CurrentState):GetCharacterId(), index = 0},
					function(data)
						Melting_get(data.item)
						Sender.Enable = true
					end)
				end
			},
		},
		Gui.Control
		{
			Size = Vector2(128, 132),
			Location = Vector2(179, 146),
			BackgroundColor = ARGB(0, 255, 255, 255),
			Gui.ItemBoxBtn "ibtn_2"
			{
				Size = Vector2(128, 100),
				Location = Vector2(0, 0),
				Empty = false,
				Type = 1,
				CanSelect = false,
				LoadingImage = Gui.AnimatedImage("LobbyUI/loading_ring.tga", 4, 2, 8),
				Skin = Gui.ItemBoxBtnSkin
				{
					NeutralNormalImage = Gui.Image("LobbyUI/Compose/lb_melting_slot_02.dds", Vector4(0, 0, 0, 0)),
					NeutralHoverImage = Gui.Image("LobbyUI/Compose/lb_melting_slot_02.dds", Vector4(0, 0, 0, 0)),
					NeutralSelectedImage = Gui.Image("LobbyUI/Compose/lb_melting_slot_02.dds", Vector4(0, 0, 0, 0)),
					NeutralDisabledImage = Gui.Image("LobbyUI/Compose/lb_melting_slot_02.dds", Vector4(0, 0, 0, 0)),
				},
				EventMouseEnter = function(sender, e)
					if sender.ItemIcon ~= nil then
						L_ToolTips.FillToolBigPresentWindow(2, meltingmodal.root, melting_rpc_data)
					end
				end,
				EventToolTipsShow = function(sender, e)
					if sender.ItemIcon ~= nil then
						if melting_rpc_data[2] ~= nil then
							L_ToolTips.ShowToolTipsShowWindow(sender,Vector2(1200,900),sender.Location + sender.Parent.Location + sender.Parent.Parent.Location)
						end
					end
				end,
				EventMouseLeave = function(sender, e)
					L_ToolTips.HideToolTipsWindow()
				end,
				SpawnControl()
			},
			Gui.Button "btn_3"
			{
				Size = Vector2(64, 32),
				Location = Vector2(0, 100),
				BackgroundColor = ARGB(255, 255, 255, 255),
				FontSize = 18,
				TextColor = ARGB(255, 37, 37, 37),
				TextAlign = "kAlignCenterMiddle",
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Compose/lb_melting_button_04_normal.dds", Vector4(0, 0, 0, 0)),
					HoverImage = Gui.Image("LobbyUI/Compose/lb_melting_button_04_hover.dds", Vector4(0, 0, 0, 0)),
					DownImage = Gui.Image("LobbyUI/Compose/lb_melting_button_04_down.dds", Vector4(0, 0, 0, 0)),
					DisabledImage = Gui.Image("LobbyUI/Compose/lb_melting_button_04_disabled.dds", Vector4(0, 0, 0, 0)),
				},
				EventClick = function(Sender,e)
					MessageBox.ShowWithConfirmCancel(lang:GetText("查看结果需要花费")..cost_lookover..lang:GetText("FC点您是否要继续？"),
					function()
						rpc.safecall("melting_output_lookover",{pid = ptr_cast(game.CurrentState):GetCharacterId(), index = 1},
						function(data)
							if data.result == 1 then
								MessageBox.ShowWithTwoButtons(lang:GetText("你的FC点不足，请充值"),lang:GetText("充值"),lang:GetText("取消"),
								function()
									gui:ShowIE()
								end,
								nil
								)
								if modal then
									modal.Close()
									modal = nil
								end
							else
								Sender.Enable = false
								Melting_lookover(2, data)
							end
						end)
					end)
				end
			},
			Gui.Button "btn_4"
			{
				Size = Vector2(64, 32),
				Location = Vector2(64, 100),
				BackgroundColor = ARGB(255, 255, 255, 255),
				FontSize = 18,
				TextColor = ARGB(255, 37, 37, 37),
				TextAlign = "kAlignCenterMiddle",
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Compose/lb_melting_button_04_b_normal.dds", Vector4(0, 0, 0, 0)),
					HoverImage = Gui.Image("LobbyUI/Compose/lb_melting_button_04_b_hover.dds", Vector4(0, 0, 0, 0)),
					DownImage = Gui.Image("LobbyUI/Compose/lb_melting_button_04_b_down.dds", Vector4(0, 0, 0, 0)),
					DisabledImage = Gui.Image("LobbyUI/Compose/lb_melting_button_04_b_disabled.dds", Vector4(0, 0, 0, 0)),
				},
				EventClick = function(Sender,e)
					Sender.Enable = false
					rpc.safecallload("melting_output_get",{pid = ptr_cast(game.CurrentState):GetCharacterId(), index = 1},
					function(data)
						Melting_get(data.item)
						Sender.Enable = true
					end)
				end
			},
		},
		Gui.Control
		{
			Size = Vector2(128, 132),
			Location = Vector2(305, 146),
			BackgroundColor = ARGB(0, 255, 255, 255),
			Gui.ItemBoxBtn "ibtn_3"
			{
				Size = Vector2(128, 100),
				Location = Vector2(0, 0),
				Empty = false,
				Type = 1,
				CanSelect = false,
				LoadingImage = Gui.AnimatedImage("LobbyUI/loading_ring.tga", 4, 2, 8),
				Skin = Gui.ItemBoxBtnSkin
				{
					NeutralNormalImage = Gui.Image("LobbyUI/Compose/lb_melting_slot_04.dds", Vector4(0, 0, 0, 0)),
					NeutralHoverImage = Gui.Image("LobbyUI/Compose/lb_melting_slot_04.dds", Vector4(0, 0, 0, 0)),
					NeutralSelectedImage = Gui.Image("LobbyUI/Compose/lb_melting_slot_04.dds", Vector4(0, 0, 0, 0)),
					NeutralDisabledImage = Gui.Image("LobbyUI/Compose/lb_melting_slot_04.dds", Vector4(0, 0, 0, 0)),
				},
				EventMouseEnter = function(sender, e)
					if sender.ItemIcon ~= nil then
						L_ToolTips.FillToolBigPresentWindow(3, meltingmodal.root, melting_rpc_data)
					end
				end,
				EventToolTipsShow = function(sender, e)
					if sender.ItemIcon ~= nil then
						if melting_rpc_data[3] ~= nil then
							L_ToolTips.ShowToolTipsShowWindow(sender,Vector2(1200,900),sender.Location + sender.Parent.Location + sender.Parent.Parent.Location)
						end
					end
				end,
				EventMouseLeave = function(sender, e)
					L_ToolTips.HideToolTipsWindow()
				end,
				SpawnControl()
			},
			Gui.Button "btn_5"
			{
				Size = Vector2(64, 32),
				Location = Vector2(0, 100),
				BackgroundColor = ARGB(255, 255, 255, 255),
				FontSize = 18,
				TextColor = ARGB(255, 37, 37, 37),
				TextAlign = "kAlignCenterMiddle",
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Compose/lb_melting_button_05_normal.dds", Vector4(0, 0, 0, 0)),
					HoverImage = Gui.Image("LobbyUI/Compose/lb_melting_button_05_hover.dds", Vector4(0, 0, 0, 0)),
					DownImage = Gui.Image("LobbyUI/Compose/lb_melting_button_05_down.dds", Vector4(0, 0, 0, 0)),
					DisabledImage = Gui.Image("LobbyUI/Compose/lb_melting_button_05_disabled.dds", Vector4(0, 0, 0, 0)),
				},
				EventClick = function(Sender,e)
					MessageBox.ShowWithConfirmCancel(lang:GetText("查看结果需要花费")..cost_lookover..lang:GetText("FC点您是否要继续？"),
					function()
						rpc.safecall("melting_output_lookover",{pid = ptr_cast(game.CurrentState):GetCharacterId(), index = 2},
						function(data)
							if data.result == 1 then
								MessageBox.ShowWithTwoButtons(lang:GetText("你的FC点不足，请充值"),lang:GetText("充值"),lang:GetText("取消"),
								function()
									gui:ShowIE()
								end,
								nil
								)
								if modal then
									modal.Close()
									modal = nil
								end
							else
								Sender.Enable = false
								Melting_lookover(3, data)
							end
						end)
					end)
				end
			},
			Gui.Button "btn_6"
			{
				Size = Vector2(64, 32),
				Location = Vector2(64, 100),
				BackgroundColor = ARGB(255, 255, 255, 255),
				FontSize = 18,
				TextColor = ARGB(255, 37, 37, 37),
				TextAlign = "kAlignCenterMiddle",
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Compose/lb_melting_button_05_b_normal.dds", Vector4(0, 0, 0, 0)),
					HoverImage = Gui.Image("LobbyUI/Compose/lb_melting_button_05_b_hover.dds", Vector4(0, 0, 0, 0)),
					DownImage = Gui.Image("LobbyUI/Compose/lb_melting_button_05_b_down.dds", Vector4(0, 0, 0, 0)),
					DisabledImage = Gui.Image("LobbyUI/Compose/lb_melting_button_05_b_disabled.dds", Vector4(0, 0, 0, 0)),
				},
				EventClick = function(Sender,e)
					Sender.Enable = false
					rpc.safecallload("melting_output_get",{pid = ptr_cast(game.CurrentState):GetCharacterId(), index = 2},
					function(data)
						Melting_get(data.item)
						Sender.Enable = true
					end)
				end
			},
		},
		Gui.Label
		{
			Size = Vector2(488, 22),
			Location = Vector2(1, 285),
			BackgroundColor = ARGB(0, 255, 255, 255),
			Text = lang:GetText("只能选择其中一个，请慎重考虑哦~"),
			FontSize = 18,
			TextColor = ARGB(255, 0, 0, 0),
			TextAlign = "kAlignCenterMiddle",
		},
		Gui.Label
		{
			Size = Vector2(488, 22),
			Location = Vector2(0, 284),
			BackgroundColor = ARGB(0, 255, 255, 255),
			Text = lang:GetText("只能选择其中一个，请慎重考虑哦~"),
			FontSize = 18,
			TextColor = ARGB(255, 255, 210, 0),
			TextAlign = "kAlignCenterMiddle",
		},
		Gui.Label "lab_1"
		{
			Size = Vector2(488, 42),
			Location = Vector2(1, 315),
			BackgroundColor = ARGB(0, 255, 255, 255),
			Text = lang:GetText("此次熔炼似乎产生好东西，您是否考虑先查看一下"),
			FontSize = 18,
			TextColor = ARGB(255, 0, 0, 0),
			TextAlign = "kAlignCenterMiddle",
		},
		Gui.Label "lab_2"
		{
			Size = Vector2(488, 42),
			Location = Vector2(0, 314),
			BackgroundColor = ARGB(0, 255, 255, 255),
			Text = lang:GetText("此次熔炼似乎产生好东西，您是否考虑先查看一下"),
			FontSize = 18,
			TextColor = ARGB(255, 255, 210, 0),
			TextAlign = "kAlignCenterMiddle",
		},
	},
}

--熔炼
melting_ui_1 = Gui.Create()
{
	Gui.Control "root"
	{
		Size = Vector2(488, 333),
		Dock = "kDockCenter",
		BackgroundColor = ARGB(255, 255, 255, 255),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_success.dds", Vector4(0, 0, 0, 0)),
		},
		Gui.Label
		{
			Size = Vector2(488, 28),
			Location = Vector2(1, 92),
			Text = lang:GetText("恭喜您获得"),
			TextAlign = "kAlignCenterMiddle",
			FontSize = 20,
			TextColor = ARGB(255, 0, 0, 0),
		},
		Gui.Label
		{
			Size = Vector2(488, 28),
			Location = Vector2(0, 91),
			Text = lang:GetText("恭喜您获得"),
			TextAlign = "kAlignCenterMiddle",
			FontSize = 20,
			TextColor = ARGB(255, 255, 210, 0),
		},
		Gui.Label "lab_1"
		{
			Size = Vector2(488, 28),
			Location = Vector2(1, 119),
			TextAlign = "kAlignCenterMiddle",
			FontSize = 20,
			TextColor = ARGB(255, 0, 0, 0),
		},
		Gui.Label "lab_2"
		{
			Size = Vector2(488, 28),
			Location = Vector2(0, 118),
			TextAlign = "kAlignCenterMiddle",
			FontSize = 20,
			TextColor = ARGB(255, 255, 255, 255),
		},
		Gui.Label
		{
			Size = Vector2(488, 28),
			Location = Vector2(1, 146),
			TextAlign = "kAlignCenterMiddle",
			Text = lang:GetText("请去仓库查看"),
			FontSize = 20,
			TextColor = ARGB(255, 0, 0, 0),
		},
		Gui.Label
		{
			Size = Vector2(488, 28),
			Location = Vector2(0, 145),
			TextAlign = "kAlignCenterMiddle",
			Text = lang:GetText("请去仓库查看"),
			FontSize = 20,
			TextColor = ARGB(255, 255, 210, 0),
		},
		Gui.ItemBoxBtn "ibtn_1"
		{
			Size = Vector2(212, 100),
			Location = Vector2(135, 172),
			Empty = false,
			Type = 1,
			CanSelect = false,
			LoadingImage = Gui.AnimatedImage("LobbyUI/loading_ring.tga", 4, 2, 8),
			Skin = Gui.ItemBoxBtnSkin
			{
				NeutralNormalImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_slot.dds", Vector4(10, 10, 10, 10)),
				NeutralHoverImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_slot.dds", Vector4(10, 10, 10, 10)),
				NeutralSelectedImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_slot.dds", Vector4(10, 10, 10, 10)),
				NeutralDisabledImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_slot.dds", Vector4(10, 10, 10, 10)),
			},
			EventMouseEnter = function(sender, e)
				if sender.ItemIcon ~= nil then
					L_ToolTips.FillToolBigPresentWindow(1, meltingmodal.root, melting_rpc_data)
				end
			end,
			EventToolTipsShow = function(sender, e)
				if sender.ItemIcon ~= nil then
					if melting_rpc_data[1] ~= nil then
						L_ToolTips.ShowToolTipsShowWindow(sender,Vector2(1200,900),sender.Location + sender.Parent.Location + sender.Parent.Parent.Location)
					end
				end
			end,
			EventMouseLeave = function(sender, e)
				L_ToolTips.HideToolTipsWindow()
			end,
		},
		Gui.Button
		{
			Size = Vector2(202, 44),
			Location = Vector2(140, 272),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Text = lang:GetText("确 定"),
			TextColor = ARGB(255, 211, 211, 211),
			HighlightTextColor = ARGB(255, 211, 211, 211),
			Padding = Vector4(0, 0, 0, 7),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/lb_onlinetime_button_2_normal.dds", Vector4(63, 0, 57, 0)),
				HoverImage = Gui.Image("LobbyUI/lb_onlinetime_button_2_hover.dds", Vector4(63, 0, 57, 0)),
				DownImage = Gui.Image("LobbyUI/lb_onlinetime_button_2_down.dds", Vector4(63, 0, 57, 0)),
				DisabledImage = Gui.Image("LobbyUI/lb_onlinetime_button_2_disabled.dds", Vector4(63, 0, 57, 0)),
			},
			EventClick = function(Sender,e)
				if meltingmodal then
					meltingmodal.Close()
					meltingmodal = nil
				end
			end
		},
	},
}

--熔炼产物列表
melting_list = Gui.Create()
{
	Gui.Control "root"
	{
		Size = Vector2(1200,900),
		Dock = "kDockCenter",
		BackgroundColor = ARGB(0, 255, 255, 255),
		
		Gui.Control 
		{
			Size = Vector2(927,570),
			Dock = "kDockCenter",
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_contact_bg1_01.dds", Vector4(163,163,53,53)),
			},

			Gui.Control "melting_list_1"
			{
				Size = Vector2(886,485),
				Location = Vector2(20,58),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg3.dds", Vector4(10, 10, 10, 10)),
				},
				
				Gui.Control
				{
					Size = Vector2(190,465),
					Location = Vector2(10, 10),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/Compose/lb_melting_bg_cwlb.dds", Vector4(0,0,0,0)),
					},
				},

				Gui.Control
				{
					Size = Vector2(668,453),
					Location = Vector2(207, 15),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_task_bg_6.dds", Vector4(50, 50, 50, 50)),
					},
					Gui.Control
					{
						Size = Vector2(591,419),
						Location = Vector2(41, 10),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_contact_bg_normal.dds", Vector4(20, 20, 20, 20)),
						},
						Gui.Control
						{
							Size = Vector2(36,417),
							Location = Vector2(2, 0),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/Compose/lb_blueprint_bg_01_l.dds", Vector4(0, 0, 0, 0)),
							},
						},
						Gui.Control
						{
							Size = Vector2(36,417),
							Location = Vector2(553, 0),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/Compose/lb_blueprint_bg_01_r.dds", Vector4(0, 0, 0, 0)),
							},
						},
						Gui.FlowLayout
						{
							Size = Vector2(469, 380),
							Location = Vector2(59, 19),
							ControlSpace = 23,
							LineSpace = 40,
							Melting_List_Btn(1),
							Melting_List_Btn(2),
							Melting_List_Btn(3),
							Melting_List_Btn(4),
							Melting_List_Btn(5),
							Melting_List_Btn(6),
							Melting_List_Btn(7),
							Melting_List_Btn(8),
							Melting_List_Btn(9),
							Melting_List_Btn(10),
							Melting_List_Btn(11),
							Melting_List_Btn(12),
						},
					},
				},
				Melting_List_Control(20,1),
				Melting_List_Control(40,2),
				Melting_List_Control(60,3),
				Melting_List_Control(80,4),
				Melting_List_Control(100,5),
				Melting_List_Control(120,6),
			},
			
			Gui.Control "melting_list_2"
			{
				Size = Vector2(886,485),
				Location = Vector2(20,58),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg3.dds", Vector4(10, 10, 10, 10)),
				},
				Gui.Control
				{
					Size = Vector2(291,453),
					Location = Vector2(13, 15),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_task_bg_6.dds", Vector4(50, 50, 50, 50)),
					},
					Gui.Control 
					{
						Size = Vector2(251, 420),
						Location = Vector2(10, 10),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_contact_bg_normal.dds", Vector4(20, 20, 20, 20)),
						},
						Gui.Control 
						{
							Size = Vector2(251, 420),
							Location = Vector2(0, 10),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/Compose/lb_melting_bg_cwlb.dds", Vector4(0,0,0,0)),
							},
						},
					},
					Gui.ScrollableControl "scroll"
					{
						Size = Vector2(269, 400),
						Location = Vector2(12, 20),
						Style = "Gui.Toplist",
						BackgroundColor = ARGB(255, 255, 255, 255),
						AutoScroll = true,
						Default_Width = 16,
						Default_Size = 16,
						--根节点
						Gui.FlowLayout "Layout"
						{
							Size = Vector2(249, 2000),
							Location = Vector2(0, 0),
							ControlSpace = 0,
							LineSpace = 0,
							IntTag = 1,
						},
					},
				},
				Gui.Control
				{
					Size = Vector2(568,453),
					Location = Vector2(304, 15),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_task_bg_6.dds", Vector4(50, 50, 50, 50)),
					},
					Gui.Control 
					{
						Size = Vector2(531, 418),
						Location = Vector2(19, 10),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_contact_bg_normal.dds", Vector4(20, 20, 20, 20)),
						},
						Gui.Control
						{
							Size = Vector2(36,417),
							Location = Vector2(2, 0),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/Compose/lb_blueprint_bg_01_l.dds", Vector4(0, 0, 0, 0)),
							},
						},
						Gui.Control
						{
							Size = Vector2(36,417),
							Location = Vector2(493, 0),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/Compose/lb_blueprint_bg_01_r.dds", Vector4(0, 0, 0, 0)),
							},
						},
						Gui.Control "image"
						{
							Size = Vector2(400, 400),
							Location = Vector2(75, 15),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/Compose/blueprint/lb_blueprint_bg_01_r.dds", Vector4(0, 0, 0, 0)),
							},
							Gui.Control "Background_6"
							{
								Visible = false,
								Size = Vector2(400, 400),
								Location = Vector2(0, 0),
								BackgroundColor = ARGB(0, 255, 255, 255),
								Melting_List_image(46, 48),
								Melting_List_image(163, 17),
								Melting_List_image(284, 47),
								Melting_List_image(47, 263),
								Melting_List_image(164, 307),
								Melting_List_image(284, 262),
								Gui.ItemBoxBtn 
								{
									Style = "Gui.ItemBoxBtn_ib",
									Size = Vector2(100, 110),
									Location = Vector2(149, 139),
									Empty = false,
									Type = 1,
									CanSelect = false,
									BackgroundColor = ARGB(255, 255, 255, 255),
									Skin = Gui.ItemBoxBtnSkin
									{
										NeutralNormalImage = nil,
										NeutralHoverImage = nil,
										NeutralSelectedImage = nil,
										NeutralDisabledImage = nil,
									}
								},
								Melting_List_image(303, 163),
							},
							Gui.Control "Background_5"
							{
								Visible = false,
								Size = Vector2(400, 400),
								Location = Vector2(0, 0),
								BackgroundColor = ARGB(0, 255, 255, 255),
								Melting_List_image(39, 165),
								Melting_List_image(164, 38),
								Melting_List_image(40, 288),
								Melting_List_image(165, 288),
								Melting_List_image(283, 288),
							
								Gui.ItemBoxBtn 
								{
									Style = "Gui.ItemBoxBtn_ib",
									Size = Vector2(100, 110),
									Location = Vector2(149, 147),
									Empty = false,
									Type = 1,
									CanSelect = false,
									BackgroundColor = ARGB(255, 255, 255, 255),
									Skin = Gui.ItemBoxBtnSkin
									{
										NeutralNormalImage = nil,
										NeutralHoverImage = nil,
										NeutralSelectedImage = nil,
										NeutralDisabledImage = nil,
									}
								},
								Melting_List_image(297, 170),
							},
							Gui.Control "Background_4"
							{
								Visible = false,
								Size = Vector2(400, 400),
								Location = Vector2(0, 0),
								BackgroundColor = ARGB(0, 255, 255, 255),
								Melting_List_image(47, 44),
								Melting_List_image(47, 274),
								Melting_List_image(281, 46),
								Melting_List_image(285, 275),
								Gui.ItemBoxBtn 
								{
									Style = "Gui.ItemBoxBtn_ib",
									Size = Vector2(100, 110),
									Location = Vector2(149, 147),
									Empty = false,
									Type = 1,
									CanSelect = false,
									BackgroundColor = ARGB(255, 255, 255, 255),
									Skin = Gui.ItemBoxBtnSkin
									{
										NeutralNormalImage = nil,
										NeutralHoverImage = nil,
										NeutralSelectedImage = nil,
										NeutralDisabledImage = nil,
									}
								},
								Melting_List_image(297, 170),
							},
							Gui.Control "Background_3"
							{
								Visible = false,
								Size = Vector2(400, 400),
								Location = Vector2(0, 0),
								BackgroundColor = ARGB(0, 255, 255, 255),
								Melting_List_image(164, 4),
								Melting_List_image(35, 229),
								Melting_List_image(292, 229),
								Gui.ItemBoxBtn 
								{
									Style = "Gui.ItemBoxBtn_ib",
									Size = Vector2(100, 110),
									Location = Vector2(149, 129),
									Empty = false,
									Type = 1,
									CanSelect = false,
									BackgroundColor = ARGB(255, 255, 255, 255),
									Skin = Gui.ItemBoxBtnSkin
									{
										NeutralNormalImage = nil,
										NeutralHoverImage = nil,
										NeutralSelectedImage = nil,
										NeutralDisabledImage = nil,
									}
								},
								Melting_List_image(166, 308),
							},
							Gui.Control "Background_2"
							{
								Visible = false,
								Size = Vector2(400, 400),
								Location = Vector2(0, 0),
								BackgroundColor = ARGB(0, 255, 255, 255),
								Melting_List_image(166, 39),
								Melting_List_image(166, 287),
								Gui.ItemBoxBtn 
								{
									Style = "Gui.ItemBoxBtn_ib",
									Size = Vector2(100, 109),
									Location = Vector2(149, 144),
									Empty = false,
									Type = 1,
									CanSelect = false,
									BackgroundColor = ARGB(255, 255, 255, 255),
									Skin = Gui.ItemBoxBtnSkin
									{
										NeutralNormalImage = nil,
										NeutralHoverImage = nil,
										NeutralSelectedImage = nil,
										NeutralDisabledImage = nil,
									}
								},
								Melting_List_image(297, 170),
							},
							Gui.Control "Background_1"
							{
								Visible = false,
								Size = Vector2(400, 400),
								Location = Vector2(0, 0),
								BackgroundColor = ARGB(0, 255, 255, 255),
								Melting_List_image(42, 50),
								Gui.ItemBoxBtn 
								{
									Style = "Gui.ItemBoxBtn_ib",
									Size = Vector2(100, 110),
									Location = Vector2(149, 139),
									Empty = false,
									Type = 1,
									CanSelect = false,
									BackgroundColor = ARGB(255, 255, 255, 255),
									Skin = Gui.ItemBoxBtnSkin
									{
										NeutralNormalImage = nil,
										NeutralHoverImage = nil,
										NeutralSelectedImage = nil,
										NeutralDisabledImage = nil,
									},
								},
								Melting_List_image(296, 158),
							},
						},
					},
				},
			},
			
			Gui.Button "btn_1_1"
			{
				Size = Vector2(278, 56),
				Location = Vector2(150, 11),
				Text = lang:GetText("熔炼产物列表"),
				TextColor = ARGB(255, 217, 209, 201),
				HighlightTextColor = ARGB(255, 217, 209, 201),
				FontSize = 20,
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_normal.dds", Vector4(15, 12, 15, 6)),
					HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_hover.dds", Vector4(15, 12, 15, 6)),
					DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_down.dds", Vector4(15, 12, 15, 6)),
					DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_normal.dds", Vector4(15, 12, 15, 6)),
				},
				EventClick = function(sender, e)
					sender.PushDown = true
					melting_list.btn_2_2.PushDown = false 
					melting_list.melting_list_1.Visible = true
					melting_list.melting_list_2.Visible = false
					FillMeltingList(1)
				end
			},
			
			Gui.Button "btn_2_2"
			{
				Size = Vector2(278, 56),
				Location = Vector2(450, 11),
				Text = lang:GetText("蓝图列表"),
				TextColor = ARGB(255, 217, 209, 201),
				HighlightTextColor = ARGB(255, 217, 209, 201),
				FontSize = 20,
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_normal.dds", Vector4(15, 12, 15, 6)),
					HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_hover.dds", Vector4(15, 12, 15, 6)),
					DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_down.dds", Vector4(15, 12, 15, 6)),
					DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_normal.dds", Vector4(15, 12, 15, 6)),
				},
				EventClick = function(sender, e)
					melting_list["Layout"]:OnDestroy()
					melting_list.scroll.AutoScrollMinSize = Vector2(0, 0)
					if bluemap[1] == nil then
						rpc.safecallload("get_bluemap_list", {pid = ptr_cast(game.CurrentState):GetCharacterId(),type = "11"},
						function(data)
							bluemap[1] = data.list[1]
						end)
						-- rpc.safecallload("get_bluemap_list", {pid = ptr_cast(game.CurrentState):GetCharacterId(),type = "21"},
						-- function(data)
							-- bluemap[2] = data.list[1]
						-- end)
						rpc.safecallload("get_bluemap_list", {pid = ptr_cast(game.CurrentState):GetCharacterId(),type = "12"},
						function(data)
							bluemap[3] = data.list[1]
						end)
						rpc.safecallload("get_bluemap_list", {pid = ptr_cast(game.CurrentState):GetCharacterId(),type = "31"},
						function(data)
							bluemap[4] = data.list[1]
						end)
						
						rpc.safecallload("get_bluemap_list", {pid = ptr_cast(game.CurrentState):GetCharacterId(),type = "32"},
						function(data)
							bluemap[5] = data.list[1]
						end)
						rpc.safecallload("get_bluemap_list", {pid = ptr_cast(game.CurrentState):GetCharacterId(),type = "51"},
						function(data)
						
							bluemap[6] = data.list[1]
							FillBlueMap(bluemap, melting_list["Layout"])
							sender.PushDown = true
							melting_list.btn_1_1.PushDown = false 
							melting_list.melting_list_1.Visible = false
							melting_list.melting_list_2.Visible = true
						end)
					else
						FillBlueMap(bluemap, melting_list["Layout"])
						sender.PushDown = true
						melting_list.btn_1_1.PushDown = false 
						melting_list.melting_list_1.Visible = false
						melting_list.melting_list_2.Visible = true
					end
				end
			},
			
			Gui.Control "btn_2_2_new"
			{
				Size = Vector2(56, 36),
				Location = Vector2(440, 8),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Enable = false,
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_newico.dds", Vector4(0, 0, 0, 0)),
				},
			},
			Gui.Button "btn_Close"
			{
				Size = Vector2(48, 48),
				Location = Vector2(867, 11),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_normal.dds", Vector4(0, 0, 0, 0)),
					HoverImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_hover.dds", Vector4(0, 0, 0, 0)),
					DownImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_down.dds", Vector4(0, 0, 0, 0)),
					DisabledImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_disabled.dds", Vector4(0, 0, 0, 0)),
				},
				EventClick = function()
					if meltinglistmodal then
						meltinglistmodal.Close()
						meltinglistmodal = nil
					end
				end
			},
		},
	},
}

message_box = Gui.Create()
{
	Gui.Control "panel"
	{
		Size = Vector2(576, 272),
		Padding = Vector4(10, 10, 10, 10),
		BackgroundColor = ARGB(204, 255, 255, 255),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/lb_common_up_bg_01.dds", Vector4(200, 20, 100, 0)),
		},
		
		Gui.Control "image_area"
		{
			Size = Vector2(80, 68),
			Location = Vector2(30, 20),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("", Vector4(0, 0, 0, 0)),
			},
		},
		
		Gui.RichEdit "re_msg"
		{
			Size = Vector2(400, 200),
			Location = Vector2(120, 40),
			FontSize = 24,
			BackgroundColor = ARGB(0, 255, 255, 255),
			AutoScrollMinSize = Vector2(350, 140),
			AutoScroll = true,
			HScrollBarDisplay = "kHide",
			VScrollBarDisplay = "kHide",
		},
		
		Gui.Control 
		{
			Size = Vector2(440, 100),
			Location = Vector2(80, 120),
			Gui.CheckBox "checkbox"
			{
				Size = Vector2(24, 24),
				Location = Vector2(0, 6),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Check = true,
				Skin = Gui.CheckBoxSkin
				{
					OnImage = Gui.Image("LobbyUI/mail/lb_contact_checkbox_down.dds", Vector4(0, 0, 0, 0)),
					OffImage = Gui.Image("LobbyUI/mail/lb_contact_checkbox_normal.dds", Vector4(0, 0, 0, 0)),
				},
			},
			Gui.TextArea "text"
			{
				Size = Vector2(435, 120),
				Location = Vector2(40, 0),
				FontSize = 24,
				Fold = true,
				TextColor = ARGB(255, 140, 28, 28),
			},
		},
		
		Gui.FlowLayout "button_area"
		{
			Size = Vector2(576, 80),
			Location = Vector2(0, 201),
			Align = "kAlignCenterMiddle",
			ControlAlign = "kAlignCenterMiddle",
			ControlSpace = 20,
			
			Gui.Button
			{
				Size = Vector2(128, 40),
				TextColor = ARGB(255, 0, 0, 0),
				HighlightTextColor = ARGB(255, 0, 0, 0),
				FontSize = 22,
				Text = lang:GetText("确 定"),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/lb_common_up_button_normal.dds", Vector4(20, 20, 20, 20)),
					HoverImage = Gui.Image("LobbyUI/lb_common_up_button_hover.dds", Vector4(20, 20, 20, 20)),
					DownImage = Gui.Image("LobbyUI/lb_common_up_button_down.dds", Vector4(20, 20, 20, 20)),
					DisabledImage = Gui.Image("LobbyUI/lb_common_up_button_disabled.dds", Vector4(20, 20, 20, 20)),			
				},
				EventClick = function(sender, e)
					ui.start1.Enable = false
					if message_box.checkbox.Check == true then
						rpc_convert.islose = 1
					else
						rpc_convert.islose = 0
					end
					rpc.safecallload("convert",rpc_convert,
					function(data)
						warning_level = getlevel(data.rate)
						ui.Help_part5.Visible = false
						if data.result == 5 then
							modalFlash = ModalWindow.GetNew()
							modalFlash.screen.AllowEscToExit = false
							modalFlash.root.Size = Vector2(776, 440)
							flash.root.Parent = modalFlash.root
							data_temp = data
							flash.Flash.Text = "synthesis_success"
							gui:PlayAudio("kUIA_COMPOUND_SUCCEED_SWF")
							flash.Flash:CleanData()
							flash.Flash.UseTime = true
							flash.Flash.Visible = true
						else
							gui:PlayAudio("kUIA_COMPOUND_FAIL")
							local text = lang:GetText("抱歉！装备转换过程中发生意外！")
							if data.result == 10 then
								text = text.."\n"..data.from.display..lang:GetText("强化等级倒退了")
								text = text.."\n"..data.to.display..lang:GetText("强化等级倒退了")
							elseif data.result == 6 then
								text = text.."\n"..data.to.display..lang:GetText("强化等级倒退了")
							else
								text = text.."\n"..data.from.display..lang:GetText("强化等级倒退了")
							end
							MessageBox.ShowWithConfirm(text)
							ui.start1.Enable = true
							FillStorage()
							rpc_date_object_1[1] = data.from
							rpc_date_object_1[2] = data.to
							from_rate = data.from_rate
							to_rate = data.to_rate
							FillMachine2_end()
						end
					end)
					if Convertmodal then
						Convertmodal.Close()
						Convertmodal = nil
					end
				end
			},
			
			Gui.Button
			{
				Size = Vector2(128, 40),
				TextColor = ARGB(255, 0, 0, 0),
				HighlightTextColor = ARGB(255, 0, 0, 0),
				FontSize = 22,
				Text = lang:GetText("取 消"),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/lb_common_up_button_normal.dds", Vector4(20, 20, 20, 20)),
					HoverImage = Gui.Image("LobbyUI/lb_common_up_button_hover.dds", Vector4(20, 20, 20, 20)),
					DownImage = Gui.Image("LobbyUI/lb_common_up_button_down.dds", Vector4(20, 20, 20, 20)),
					DisabledImage = Gui.Image("LobbyUI/lb_common_up_button_disabled.dds", Vector4(20, 20, 20, 20)),			
				},
				EventClick = function(sender, e)
					if Convertmodal then
						Convertmodal.Close()
						Convertmodal = nil
					end
				end
			},
		},
	},
}

ShengxingWarn = Gui.Create()
{
	Gui.Control "root"
	{
		Size = Vector2(526, 272),
		Dock = "kDockCenter",
		BackgroundColor = ARGB(255, 255, 255, 255),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/lb_common_up_bg_01.dds", Vector4(200, 20, 100, 0)),
		},

		Gui.RichEdit "warn_msg_1"
		{
			Size = Vector2(526, 272),
			Location = Vector2(75, 100),
			FontSize = 24,
			BackgroundColor = ARGB(0, 255, 255, 255),
		},
		
		--确定
		Gui.Button
		{
			Location = Vector2(100, 222),
			Size = Vector2(128, 40),
			BackgroundColor = ARGB(255,255,255,255),
			Text = lang:GetText("确 定"),
			TextAlign = "kAlignCenterMiddle",
			TextColor = ARGB(255,50,50,50),
			HighlightTextColor = ARGB(255, 50 ,50 ,50),
			Padding = Vector4(0, 0, 0, 5),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/lb_common_up_button_normal.dds", Vector4(20, 20, 20, 20)),
				HoverImage = Gui.Image("LobbyUI/lb_common_up_button_hover.dds", Vector4(20, 20, 20, 20)),
				DownImage = Gui.Image("LobbyUI/lb_common_up_button_down.dds", Vector4(20, 20, 20, 20)),
				DisabledImage = Gui.Image("LobbyUI/lb_common_up_button_disabled.dds", Vector4(20, 20, 20, 20)),			
			},
			
			EventClick = function()
				Hide_ShengxingWarn()
				if upstar[1].pid ~= -1 then
					local args = {}
					args.pid = ptr_cast(game.CurrentState):GetCharacterId()
					args.mainItemId = upstar[1].pid
					args.toItemId = ""
					if ui.cbox_daily_shengxing_exp.Check == true then
						args.isFree = 1
					else
						args.isFree = 0
					end
					
					for i = 2, 10 do
						if upstar[i].pid ~= -1 then
							if args.toItemId == "" then
								args.toItemId = args.toItemId..upstar[i].pid
							else
								args.toItemId = args.toItemId..":"..upstar[i].pid
							end
						end
					end
					rpc.safecallload("two_to_one", args,
					function (data)
						modalFlash = ModalWindow.GetNew()
						modalFlash.screen.AllowEscToExit = false
						modalFlash.root.Size = Vector2(776, 440)
						flash.root.Parent = modalFlash.root
						flash.Flash.Text = "synthesis_success"
						gui:PlayAudio("kUIA_COMPOUND_SUCCEED_SWF")
						flash.Flash:CleanData()
						flash.Flash.UseTime = true
						flash.Flash.Visible = true
						for i = 2, 10 do
							Clean_upstar(i)
							-- if i == 1 then
								-- ui.main_weapon.ItemIcon = nil
							-- else
								ui["Item_btn_shengxing_"..i].ItemIcon = nil
							-- end
						end
						FillStorage()
						num = data.mainItem.gstExp
						upstar[1].display = data.mainItem.display
						if upstar[1].gstLevel ~= data.mainItem.gstLevel then
							FillStarCongratulation(upstar[1].gstLevel,data.mainItem.gstLevel,data.mainItem.common.star)
							congratulationmodal = ModalWindow.GetNew()
							congratulationmodal.root.Size = Vector2(800,600)
							congratulation.root.Parent = congratulationmodal.root
							-- if rpc_date_object.common.strength == L_LobbyMain.PersonalInfo_data.maxLevel then
								-- gui:PlayAudio("kUIA_COMPOUND_SUCCEED_SWF_EX")
							-- end
						end	
						upstar[1].gstExp = data.mainItem.gstExp
						upstar[1].gstLevel = data.mainItem.gstLevel
						upstar[1].star = data.mainItem.common.star
						ui.main_weapon_star.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/Compose/shengxing/lb_synthesis_conversion_star_0"..upstar[1].gstLevel..".dds", Vector4(0, 0, 0, 0)),}
						if upstar[1].strength > 0 then
							ui.main_weapon_lv.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/badge_lv"..upstar[1].strength.."_small.dds", Vector4(0, 0, 0, 0)),}
						else
							ui.main_weapon_lv.Skin = Gui.ControlSkin{BackgroundImage = nil,}
						end
						ui.Compare_3_full.Visible = false	
						if upstar[1].gstLevel < 5 then
							local per = num/upstar_AllExp[math.ceil(data.mainItem.common.rareLevel/25)-1][data.mainItem.gstLevel+1] * 120
							ui.Compare_3.Normsize = ui.Compare_3.Size
							ui.Compare_3:Clear()
							ui.Compare_3:InsertMovePoint(ui.Compare_3.Location,0.5,Vector2(262 * (per / 120), 53),ARGB(255,255,255,255))
						elseif upstar[1].gstLevel == 5 then
							ui.Compare_3.Normsize = ui.Compare_3.Size
							ui.Compare_3:Clear()
							ui.Compare_3:InsertMovePoint(ui.Compare_3.Location,0.5,Vector2(262, 53),ARGB(255,255,255,255))
							ui.Compare_3_full.Visible = true												
						else
							ui.Compare_3.Normsize = ui.Compare_3.Size
							ui.Compare_3:Clear()
							ui.Compare_3:InsertMovePoint(ui.Compare_3.Location,0.5,Vector2(0, 53),ARGB(255,255,255,255))
						end	
						
						ui.start3.Enable = false
						ui.text_shengxing.Visible = true
						Label = ptr_cast(ui.text_shengxing:GetChildByIndex(1))
						Label.TextColor = ARGB(255, 213, 255, 254)
						Label.Text = lang:GetText("战斗力：")..data.mainItem.common.star
						upstar[1].star = data.mainItem.common.star
						Label = ptr_cast(ui.text_shengxing:GetChildByIndex(0))
						Label.TextColor = ARGB(255, 213, 255, 254)
						Label.Text = lang:GetText("星级：")..data.mainItem.gstLevel
						-- Label = ptr_cast(ui.text:GetChildByIndex(6))
						-- Label.TextColor = ARGB(255, 213, 255, 254)
						-- Label.Text = lang:GetText("开放的可钻孔数：")..rpc_date_object.common.holeNum
						local pow = nil
						local speed = nil
						if current_selected == 1 then
							Label = ptr_cast(ui.text_shengxing:GetChildByIndex(2))
							Label.Text = lang:GetText("攻击力：")
							upstar[1].damange = data.mainItem.performance.damange
							upstar[1].damange_add = data.mainItem.performance.damange_add
							ui.ctrl_demage_shengxing.Visible = false
							pow = math.floor((data.mainItem.performance.damange + data.mainItem.performance.damange_add) * 10) / 10
							Label.TextColor = ARGB(255, 213, 255, 254)

							ui.compare_demage1_shengxing.Visible = true
							if data.mainItem.wid == 4 then
								pow = pow * 3
							end
							local temp = (pow - (pow % 50)) / 50 + 1
							if temp > 1 then
								ui.star_shengxing.Visible = true
								local con = ptr_cast(ui.star_shengxing:GetChildByIndex(1))
								con.Text = " x  "..(temp - 1)
							else
								ui.star.Visible = false
							end
							if pow % 50 == 0 then
								temp = temp - 1
								ui.compare_demage1_shengxing.Icon = compareIcon2[temp]
								ui.compare_demage1_shengxing:ResetBaseValue(100)
							else
								if temp > 7 then
									temp = 7
								end
								ui.compare_demage1_shengxing.Icon = compareIcon2[temp]
								ui.compare_demage1_shengxing:ResetBaseValue(pow % 50 * 2)
							end
							ui.fangju_shengxing_hp.Visible = false
						else
							Label = ptr_cast(ui.text_shengxing:GetChildByIndex(2))
							Label.Text = lang:GetText("增加血量：")..precision(upstar[1].cBloodAdd + upstar[1].cBloodAdd_add).."%"
							Label.TextColor = ARGB(255, 213, 255, 254)
							ui.ctrl_demage_shengxing.Visible = false
							ui.fangju_shengxing_hp.Visible = true
							ui.star_shengxing.Visible = false
							ui.compare_demage1_shengxing.Visible = false
							if upstar[1].gstLevel > 0 then
								ui.fangju_shengxing_hp.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/Compose/shengxing/lb_synthesis_conversion_hp_0"..upstar[1].gstLevel..".dds", Vector4(0, 0, 0, 0)),}
							else
								ui.fangju_shengxing_hp.Visible = false
							end
						end						
						
						if current_selected == 1 then
							Label = ptr_cast(ui.text_shengxing:GetChildByIndex(3))
							Label.Text = lang:GetText("攻击速度")..lang:GetText("：")

							upstar[1].speed = data.mainItem.performance.speed
							upstar[1].speed_add = data.mainItem.performance.speed_add
							Label.TextColor = ARGB(255, 213, 255, 254)
							speed = math.floor((data.mainItem.performance.speed + data.mainItem.performance.speed_add) * 10) / 10
							ui.ctrl_demage1_shengxing.Visible = false
							ui.ctrl_demage2_shengxing.Visible = false

							ui.compare_demage2_shengxing.Visible = true
							local temp = (speed - (speed % 50)) / 50 + 1
							if temp > 1 then
								ui.star1_shengxing.Visible = true
								local con = ptr_cast(ui.star1_shengxing:GetChildByIndex(1))
								con.Text = " x  "..(temp - 1)
							else
								ui.star1_shengxing.Visible = false
							end
							if speed % 50 == 0 then
								temp = temp - 1
								ui.compare_demage2_shengxing.Icon = compareIcon2[temp + 7]
								ui.compare_demage2_shengxing:ResetBaseValue(100)
							else
								if temp > 7 then
									temp = 7
								end
								ui.compare_demage2_shengxing.Icon = compareIcon2[temp + 7]
								ui.compare_demage2_shengxing:ResetBaseValue(speed % 50 * 2)
							end
						else
							Label = ptr_cast(ui.text_shengxing:GetChildByIndex(3))
							Label.Visible = false
							ui.compare_demage2_shengxing.Visible = false
							ui.star1_shengxing.Visible = false
							ui.ctrl_demage1_shengxing.Visible = false
							ui.ctrl_demage2_shengxing.Visible = false
						end
						if ui.cbox_daily_shengxing_exp.Check == true then
							ui.cbox_daily_shengxing_exp.Check = false
							ui.cbox_daily_shengxing_exp.Enable = false
							ui.Help_part11.Visible = false
							ui.daily_exp_tip.Visible = false
						end
					end)
				end
			end
		},
		--取消
		Gui.Button
		{
			Location = Vector2(263, 222),
			Size = Vector2(128, 40),
			BackgroundColor = ARGB(255,255,255,255),
			Text = lang:GetText("取 消"),
			TextAlign = "kAlignCenterMiddle",
			TextColor = ARGB(255,50,50,50),
			HighlightTextColor = ARGB(255, 50 ,50 ,50),
			Padding = Vector4(0, 0, 0, 5),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/lb_common_up_button_normal.dds", Vector4(20, 20, 20, 20)),
				HoverImage = Gui.Image("LobbyUI/lb_common_up_button_hover.dds", Vector4(20, 20, 20, 20)),
				DownImage = Gui.Image("LobbyUI/lb_common_up_button_down.dds", Vector4(20, 20, 20, 20)),
				DisabledImage = Gui.Image("LobbyUI/lb_common_up_button_disabled.dds", Vector4(20, 20, 20, 20)),			
			},
			
			EventClick = function()
				Hide_ShengxingWarn()
			end
		},
	},
}

function Show_ShengxingWarn(text1,text2,text3,text4,color)
	ShengxingWarnmodel = ModalWindow.GetNew()
	ShengxingWarnmodel.root.Size = Vector2(538,332)
	ShengxingWarnmodel.AllowEscToExit = false
	ShengxingWarn.root.Parent = ShengxingWarnmodel.root
	
	ShengxingWarn.warn_msg_1:CleanAll()
	ShengxingWarn.warn_msg_1:AddMsg(text1,ARGB(255, 0, 0, 0),true,false)
	ShengxingWarn.warn_msg_1:AddMsg(text2,color,false,false)
	ShengxingWarn.warn_msg_1:AddMsg(text3,ARGB(255, 0, 0, 0),false,false)
	ShengxingWarn.warn_msg_1:AddMsg(text4,ARGB(255, 0, 0, 0),true,false)
end

function Hide_ShengxingWarn()
	if ShengxingWarnmodel then
		ShengxingWarnmodel.Close()
		ShengxingWarnmodel = nil
	end
end

function ShowConvert(text)
	message_box.image_area.Skin = Gui.ControlSkin
	{
		BackgroundImage = Gui.Image("LobbyUI/mokuai_title02.dds", Vector4(0, 0, 0, 0)),
	}
	message_box.re_msg:CleanAll()
	local msg_table = L_PushCmd.Split(text,"@!")
	local new = true
	for i=2, #msg_table do
		--颜色
		if i % 2 == 0 then
			if tonumber(msg_table[i]) > 0 and tonumber(msg_table[i]) < 9 then
				color = font_color[tonumber(msg_table[i])]
			else
				color = ARGB(255, 255, 255, 255)
			end
		--内容
		else
			if i == 5 then
				message_box.re_msg:AddMsg(msg_table[i],color,new,false)
			else
				message_box.re_msg:AddMsg(msg_table[i],color,new,false)
			end
			new = false
		end
	end
	local type
	if rpc_date_object_1[1].common.type == 1 then
		type = 6
	elseif rpc_date_object_1[1].common.type == 2 then
		type = 3
	else
		type = 1
	end
	local cost = math.floor(100 * type * (from_rate / 100 * math.pow(1.8, rpc_date_object_1[1].common.strength) + to_rate / 100 * math.pow(1.8, rpc_date_object_1[2].common.strength)))
	local temp = math.pow(10, math.floor(math.log(cost, 10)) - 1)
	if temp > 0 then
		cost = math.floor(cost / temp) * temp
	end
	message_box.checkbox.Check = true
	message_box.text.Text = lang:GetText("额外支付")..cost..lang:GetText("C币").."\n"..lang:GetText("可确保装备不掉级")
	Convertmodal = ModalWindow.GetNew()
	Convertmodal.root.Size = Vector2(576, 272)
	message_box.panel.Parent = Convertmodal.root
end

function getlevel(num)
	if num == 0 then
		return 1
	elseif num < 20 then
		return 2
	elseif num < 40 then
		return 3
	elseif num < 60 then
		return 4
	elseif num < 80 then
		return 5
	elseif num < 100 then
		return 6
	elseif num == 100 then
		return 7
	end
end

function precision(float)
	return math.floor((float + 0.5))
end

function getresidual_total(t,recycle)
print("00000.0.0.0.0.0.0.0.",recycle)
print("00000.0.0.0.0.0.0.011111.",t)
	local num = 0
	local count = 0
	local temp
	for i = 1, 9 do
		if melting[i].pid ~= -1 then
			num = num + melting[i].residual + melting[i].value
			count = count + 1
		end
	end
	temp = 0.9 * (num * (0.7 + (0.03 * count)) * (0.8 + (melting_table.value / 100)) + t)
	temp = temp*recycle/100
	if temp > 1314 then
		temp = 1314
	end
	return math.ceil(math.pow(temp, 2 / 3))
end

function IsExist()

	--配方
	if is_formula then
		for i = 1, 9 do
			if melting[i].pid ~= -1 then
				return true
			end
		end
	end

	--熔炼
	if info.meltingEnergy == 0 then
		return false
	end

	for i = 1, 9 do
		if melting[i].pid ~= -1 then
			return true
		end
	end

	return false
end

function Highlight(type, m_type)
	local ibbtn = nil
	if type == 5 then
		if main_type == 1 then
			if m_type == 1 then
				ibbtn = ptr_cast(ui.qianghua:GetChildByIndex(1))
			elseif m_type == 2 or m_type == 5 then
				ibbtn = ptr_cast(ui.qianghua:GetChildByIndex(2))
			else
				ibbtn = ptr_cast(ui.qianghua:GetChildByIndex(3))
			end
			ibbtn.Highlight = true
		elseif main_type == 2 then
			if m_type == 11 then
				ui.dakong.Highlight = true
			elseif m_type == 8 or m_type == 9 then
				for i = 1, 6 do
					if rpc_date_object then
						if rpc_date_object.combineDetail[i].open == 1 and rpc_date_object.combineDetail[i].level == 0 then
							ibbtn = ptr_cast(ui.gaizhuang:GetChildByIndex(i + 1))
							ibbtn.Highlight = true
						end
					end
				end
			end
		end
	else
		if main_type == 1 then
			ui.object.Highlight = true
		elseif main_type == 2 then
			ui.object1.Highlight = true
		elseif main_type == 3 then
			ui.object2.Highlight = true
			ui.object3.Highlight = true
		end
	end
end

function Strengthen(Sender)
	MessageBox.ShowWaiter(lang:GetText("正在强化..."))
	local flag = 0
	Sender.Enable = false
	rpc.safecallload("strengthen",rpc_string,
	function(data)
		if data.warning ~= nil then
			Sender.Enable = true
			MessageBox.CloseWaiter()
				if data.warning == "1"  then
					MessageBox.ShowWithTimer(2,lang:GetText("未激活相应战队技能\n无法继续强化"))
				elseif data.warning == "10"  then
					MessageBox.ShowWithTimer(2,lang:GetText("玩家等级未达到15级\n无法继续强化"))
				elseif data.warning == "11"  then
					MessageBox.ShowWithTimer(2,lang:GetText("玩家等级未达到21级\n无法继续强化"))
				elseif data.warning == "12"  then
					MessageBox.ShowWithTimer(2,lang:GetText("玩家等级未达到25级\n无法继续强化"))
				elseif data.warning == "13"  then
					MessageBox.ShowWithTimer(2,lang:GetText("无法继续强化\n不满足强化条件,您需要达成以下条件之一\n 1、等级达到29级                \n 2、等级达到25级且在VIP5级及以上"))
				elseif data.warning == "14"  then
					MessageBox.ShowWithTimer(2,lang:GetText("无法继续强化\n不满足强化条件,您需要达成以下条件之一\n 1、等级达到32级                \n 2、等级达到25级且在VIP6级及以上"))
				elseif data.warning == "15"  then
					MessageBox.ShowWithTimer(2,lang:GetText("无法继续强化\n不满足强化条件,您需要达成以下条件之一\n 1、等级达到36级                \n 2、等级达到25级且在VIP银钻及以上"))
				elseif data.warning == "16"  then
					MessageBox.ShowWithTimer(2,lang:GetText("无法继续强化\n不满足强化条件,您需要达成以下条件之一\n 1、等级达到40级              \n 2、等级达到25级且在VIP金钻"))
					
				end
			return
		end
		MessageBox.CloseWaiter()
		modalFlash = ModalWindow.GetNew()
		modalFlash.root.Size = Vector2(776, 440)
		flash.root.Parent = modalFlash.root
		modalFlash.screen.AllowEscToExit = false
		data_temp = data
		if data.result == 0 then
			flash.Flash.Text = "synthesis_success"
		else
			flash.Flash.Text = "synthesis_fail"
		end
		flash.Flash:CleanData()
		flash.Flash.UseTime = true
		if data.result == 0 then
			gui:PlayAudio("kUIA_COMPOUND_SUCCEED_SWF")
		else
			gui:PlayAudio("kUIA_COMPOUND_FAIL_SWF")
		end
		flash.Flash.Visible = true
	end)
end

function FillStorage()
	weapon_info_page.ctrl_ib_container.Parent = nil
	dress_info_page.ctrl_ib_container.Parent = nil
	accessories_info_page.ctrl_ib_container.Parent = nil
	material_info_page.ctrl_ib_container.Parent = nil
	local args = nil
	if current_selected > 3 then
		for i = 1, 16 do
			local ibbtn = ptr_cast(material_info_page.ctrl_ib_container:GetChildByIndex(i-1))
			ibbtn.Loading = true
			ibbtn.Enable = true
			local c_control = ptr_cast(ibbtn:GetChildByIndex(2))
			c_control.Visible = true
			ibbtn.ItemLevel = nil
		end
	elseif current_selected == 1 then
		for i = 1, 8 do
			local ibbtn = ptr_cast(weapon_info_page.ctrl_ib_container:GetChildByIndex(i-1))
			ibbtn.Loading = true
			ibbtn.Enable = true
			local c_control = ptr_cast(ibbtn:GetChildByIndex(2))
			c_control.Visible = false
			local c_star = ptr_cast(ibbtn:GetChildByIndex(3))
			c_star.Visible = false
			ibbtn.ItemLevel = nil
		end
	elseif current_selected == 2 then
		for i = 1, 8 do
			local ibbtn = ptr_cast(dress_info_page.ctrl_ib_container:GetChildByIndex(i-1))
			ibbtn.Loading = true
			ibbtn.Enable = true
			local c_control = ptr_cast(ibbtn:GetChildByIndex(2))
			c_control.Visible = false
			local c_star = ptr_cast(ibbtn:GetChildByIndex(3))
			c_star.Visible = false
			ibbtn.ItemLevel = nil
		end
	elseif current_selected == 3 then
		for i = 1, 16 do
			local ibbtn = ptr_cast(accessories_info_page.ctrl_ib_container:GetChildByIndex(i-1))
			ibbtn.Loading = true
			ibbtn.Enable = true
			local c_control = ptr_cast(ibbtn:GetChildByIndex(2))
			c_control.Visible = false
			local c_star = ptr_cast(ibbtn:GetChildByIndex(3))
			c_star.Visible = false
			ibbtn.ItemLevel = nil
		end
	end
	-- if main_type == 5 then
		-- main_type = 4
	-- end
	args = {pid = ptr_cast(game.CurrentState):GetCharacterId(), t = current_selected, cid = current_characters, p = current_page, st = 0, ct = main_type}
	rpc.safecallload("strength_item_list", args,
	function (data)
		upstar_AllExp = data.maxStartExp
		-- upstar_RareExp = data.rareStartExp
		everyDayExp = data.everyDayExp
		everyDayIsVisiable = data.everyDayIsVisiable
		everyDayCPoint = data.everyDayCPoint
		adronArms = data.adronArms
		rpc_date = data.items
		if current_page > data.pages then
			current_page = data.pages
		end
		current_pages = data.pages
		ui.lb_page_number.Text = current_page.."/"..current_pages
		local items = data.items
		if items then
			if current_selected == 1 then
				if weapon_info_page then
					for i = 1, 8 do
						local ibbtn = ptr_cast(weapon_info_page.ctrl_ib_container:GetChildByIndex(i-1))
						if items[i] then
							if items[i].color > 0 and items[i].color < 8 then
								ibbtn.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..items[i].name.."_"..items[i].color..".tga")
							else
								ibbtn.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..items[i].name..".tga")
							end
							ibbtn.ItemLevel = Skin.rarelevel[math.ceil(items[i].common.rareLevel/25)]
							local c_control = ptr_cast(ibbtn:GetChildByIndex(2))
							if items[i].common.strength > 0 then
								c_control.Visible = true
								c_control.Skin = Gui.ControlSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/badge_lv"..items[i].common.strength.."_small.dds", Vector4(0, 0, 0, 0)),
								}
							end
							local c_star = ptr_cast(ibbtn:GetChildByIndex(3))
							if items[i].gstLevel and items[i].gstLevel > 0  then
								c_star.Visible = true
								c_star.Skin = Gui.ControlSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/Compose/shengxing/lb_synthesis_conversion_star_0"..items[i].gstLevel..".dds", Vector4(0, 0, 0, 0)),
								}
							else
								c_star.Visible = false
							end
							ibbtn.Padding = Vector4(0, 0, 0, 7)
						else
							local ibbtn = ptr_cast(weapon_info_page.ctrl_ib_container:GetChildByIndex(i-1))
							ibbtn.Enable = false
							ibbtn.ItemIcon = nil
							ibbtn.ItemLevel = nil
							local c_control = ptr_cast(ibbtn:GetChildByIndex(2))
							c_control.Visible = false
							local c_star = ptr_cast(ibbtn:GetChildByIndex(3))
							c_star.Visible = false
						end
						ibbtn.Loading = false
					end
					if Weapon_table.page == current_page and Weapon_table.index ~= -1 and Weapon_table.cid == current_characters and Weapon_table.type == current_selected then
						local ibbtn = ptr_cast(weapon_info_page.ctrl_ib_container:GetChildByIndex(Weapon_table.index-1))
						ibbtn.ItemIcon.alpha = 80
					end
					for i = 1, 2 do
						if convert[i].page == current_page and convert[i].index ~= -1 and convert[i].cid == current_characters and convert[i].type == current_selected then
							local ibbtn = ptr_cast(weapon_info_page.ctrl_ib_container:GetChildByIndex(convert[i].index-1))
							ibbtn.ItemIcon.alpha = 80
						end
					end
					for i = 1, 9 do
						if melting[i].page == current_page and melting[i].index ~= -1 and melting[i].cid == current_characters and melting[i].type == current_selected then
							local ibbtn = ptr_cast(weapon_info_page.ctrl_ib_container:GetChildByIndex(melting[i].index-1))
							ibbtn.ItemIcon.alpha = 80
						end
					end
					
					for i = 1, 10 do
						if i == 1 then
							if upstar[i].page == current_page and upstar[i].index ~= -1 and upstar[i].cid == current_characters and upstar[i].type == current_selected then
								for j = 1, 8 do
									if rpc_date[j] then
										if upstar[i].pid == rpc_date[j].playeritemid then
											upstar[i].index = j
										end
									end	
								end
							end
						end
						if upstar[i].page == current_page and upstar[i].index ~= -1 and upstar[i].cid == current_characters and upstar[i].type == current_selected then
							local ibbtn = ptr_cast(weapon_info_page.ctrl_ib_container:GetChildByIndex(upstar[i].index-1))
							ibbtn.ItemIcon.alpha = 80
						end
					end
				end
			elseif current_selected == 2 then
				if dress_info_page then
					for i = 1, 8 do
						local ibbtn = ptr_cast(dress_info_page.ctrl_ib_container:GetChildByIndex(i-1))
						if items[i] then
							if items[i].color > 0 and items[i].color < 8 then
								ibbtn.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..items[i].name.."_"..items[i].color..".tga")
							else
								ibbtn.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..items[i].name..".tga")
							end
							ibbtn.ItemLevel = Skin.rarelevel[math.ceil(items[i].common.rareLevel/25)]
							local c_control = ptr_cast(ibbtn:GetChildByIndex(2))
							if items[i].common.strength > 0 then
								c_control.Visible = true
								c_control.Skin = Gui.ControlSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/badge_lv"..items[i].common.strength.."_small.dds", Vector4(0, 0, 0, 0)),
								}
							end
							local c_star = ptr_cast(ibbtn:GetChildByIndex(3))
							if items[i].gstLevel and items[i].gstLevel > 0  then
								c_star.Visible = true
								c_star.Skin = Gui.ControlSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/Compose/shengxing/lb_synthesis_conversion_star_0"..items[i].gstLevel..".dds", Vector4(0, 0, 0, 0)),
								}
							else
								c_star.Visible = false
							end
							ibbtn.Padding = Vector4(0, 0, 0, 7)
						else
							local ibbtn = ptr_cast(dress_info_page.ctrl_ib_container:GetChildByIndex(i-1))
							ibbtn.Enable = false
							ibbtn.ItemIcon = nil
							ibbtn.ItemLevel = nil
							local c_control = ptr_cast(ibbtn:GetChildByIndex(2))
							c_control.Visible = false
							local c_star = ptr_cast(ibbtn:GetChildByIndex(3))
							c_star.Visible = false
						end
						ibbtn.Loading = false
					end
					if Weapon_table.page == current_page and Weapon_table.index ~= -1 and Weapon_table.cid == current_characters and Weapon_table.type == current_selected then
						local ibbtn = ptr_cast(dress_info_page.ctrl_ib_container:GetChildByIndex(Weapon_table.index-1))
						ibbtn.ItemIcon.alpha = 80
					end
					for i = 1, 2 do
						if convert[i].page == current_page and convert[i].index ~= -1 and convert[i].cid == current_characters and convert[i].type == current_selected then
							local ibbtn = ptr_cast(dress_info_page.ctrl_ib_container:GetChildByIndex(convert[i].index-1))
							ibbtn.ItemIcon.alpha = 80
						end
					end
					for i = 1, 9 do
						if melting[i].page == current_page and melting[i].index ~= -1 and melting[i].cid == current_characters and melting[i].type == current_selected then
							local ibbtn = ptr_cast(dress_info_page.ctrl_ib_container:GetChildByIndex(melting[i].index-1))
							ibbtn.ItemIcon.alpha = 80
						end
					end
					for i = 1, 10 do
						if i == 1 then
							if upstar[i].page == current_page and upstar[i].index ~= -1 and upstar[i].cid == current_characters and upstar[i].type == current_selected then
								for j = 1, 8 do
									if rpc_date[j] then
										if upstar[i].pid == rpc_date[j].playeritemid then
											upstar[i].index = j
										end
									end	
								end
							end
						end
						if upstar[i].page == current_page and upstar[i].index ~= -1 and upstar[i].cid == current_characters and upstar[i].type == current_selected then
							local ibbtn = ptr_cast(dress_info_page.ctrl_ib_container:GetChildByIndex(upstar[i].index-1))
							ibbtn.ItemIcon.alpha = 80
						end
					end
				end
			elseif current_selected == 3 then
				if accessories_info_page then
					for i = 1, 16 do
						local ibbtn = ptr_cast(accessories_info_page.ctrl_ib_container:GetChildByIndex(i-1))
						if items[i] then
							if items[i].color > 0 and items[i].color < 8 then
								ibbtn.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..items[i].name.."_"..items[i].color..".tga")
							else
								ibbtn.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..items[i].name..".tga")
							end
							ibbtn.ItemLevel = Skin.rarelevel[math.ceil(items[i].common.rareLevel/25)]
							local c_control = ptr_cast(ibbtn:GetChildByIndex(2))
							if items[i].common.strength > 0 then
								c_control.Visible = true
								c_control.Skin = Gui.ControlSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/badge_lv"..items[i].common.strength.."_small.dds", Vector4(0, 0, 0, 0)),
								}
							end
							local c_star = ptr_cast(ibbtn:GetChildByIndex(3))
							if items[i].gstLevel and items[i].gstLevel > 0  then
								c_star.Visible = true
								c_star.Skin = Gui.ControlSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/Compose/shengxing/lb_synthesis_conversion_star_0"..items[i].gstLevel..".dds", Vector4(0, 0, 0, 0)),
								}
							else
								c_star.Visible = false
							end
							ibbtn.Padding = Vector4(0, 0, 0, 7)
						else
							local ibbtn = ptr_cast(accessories_info_page.ctrl_ib_container:GetChildByIndex(i-1))
							ibbtn.Enable = false
							ibbtn.ItemIcon = nil
							ibbtn.ItemLevel = nil
							local c_control = ptr_cast(ibbtn:GetChildByIndex(2))
							c_control.Visible = false
							local c_star = ptr_cast(ibbtn:GetChildByIndex(3))
							c_star.Visible = false
						end
						ibbtn.Loading = false
					end
					if Weapon_table.page == current_page and Weapon_table.index ~= -1 and Weapon_table.cid == current_characters and Weapon_table.type == current_selected then
						local ibbtn = ptr_cast(accessories_info_page.ctrl_ib_container:GetChildByIndex(Weapon_table.index-1))
						ibbtn.ItemIcon.alpha = 80
					end
					for i = 1, 2 do
						if convert[i].page == current_page and convert[i].index ~= -1 and convert[i].cid == current_characters and convert[i].type == current_selected then
							local ibbtn = ptr_cast(accessories_info_page.ctrl_ib_container:GetChildByIndex(convert[i].index-1))
							ibbtn.ItemIcon.alpha = 80
						end
					end
					for i = 1, 9 do
						if melting[i].pid ~= -1 then
							for j = 1, 16 do
								if rpc_date[j] then
									if rpc_date[j].playeritemid == melting[i].pid then
										local ibbtn = ptr_cast(accessories_info_page.ctrl_ib_container:GetChildByIndex(j-1))
										ibbtn.ItemIcon.alpha = 80
									end
								end
							end
						end
					end
					for i = 1, 10 do
						if i == 1 then
							if upstar[i].page == current_page and upstar[i].index ~= -1 and upstar[i].cid == current_characters and upstar[i].type == current_selected then
								for j = 1, 16 do
									if rpc_date[j] then
										if upstar[i].pid == rpc_date[j].playeritemid then
											upstar[i].index = j
										end
									end	
								end
							end
						end
						if upstar[i].page == current_page and upstar[i].index ~= -1 and upstar[i].cid == current_characters and upstar[i].type == current_selected then
							local ibbtn = ptr_cast(accessories_info_page.ctrl_ib_container:GetChildByIndex(upstar[i].index-1))
							ibbtn.ItemIcon.alpha = 80
						end
					end
				end
			elseif current_selected > 3 then
				if material_info_page then
					for i = 1, 16 do
						local ibbtn = ptr_cast(material_info_page.ctrl_ib_container:GetChildByIndex(i-1))
						local c_control = ptr_cast(ibbtn:GetChildByIndex(2))
						if items[i] then
							ibbtn.ItemLevel = Skin.rarelevel[math.ceil(items[i].common.rareLevel/25)]
							if items[i].color > 0 and items[i].color < 8 then
								ibbtn.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..items[i].name.."_"..items[i].color..".tga")
							else
								ibbtn.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..items[i].name..".tga")
							end
							ibbtn.Padding = Vector4(0, 0, 0, 7)
							L_LobbyMain.FillNumber(items[i].common.quantity, c_control)
							if main_type == 1 then
								for j = 1, 3 do
									if items[i].playeritemid == index_table[j].playeritemid then
										index_table[j].page = current_page
										index_table[j].index = i
										index_table[j].num = items[i].common.quantity
									end
								end
							elseif main_type == 2 then
								if items[i].playeritemid == hole.playeritemid then
									hole.page = current_page
									hole.index = i
									hole.num = items[i].common.quantity
								end
							end
						else
							local ibbtn = ptr_cast(material_info_page.ctrl_ib_container:GetChildByIndex(i-1))
							ibbtn.Enable = false
							ibbtn.ItemIcon = nil
							ibbtn.ItemLevel = nil
							c_control.Visible = false
						end
						ibbtn.Loading = false
					end
					if main_type == 1 then
						for i = 1, 3 do
							if index_table[i].page == current_page and index_table[i].index ~= -1 then
								local ibbtn = ptr_cast(material_info_page.ctrl_ib_container:GetChildByIndex(index_table[i].index-1))
								ibbtn.ItemIcon.alpha = 80
							end
						end
					elseif main_type == 2 then
						if hole.page == current_page and hole.index ~= -1 then
							local ibbtn = ptr_cast(material_info_page.ctrl_ib_container:GetChildByIndex(hole.index-1))
							ibbtn.ItemIcon.alpha = 80
						end
					elseif main_type == 4 then
						for i = 1, 9 do
							if melting[i].page == current_page and melting[i].index ~= -1 and melting[i].type == current_selected then
								melting[i].cid = current_characters
								if rpc_date[melting[i].index].common.quantity == 1 then
									rpc_date[melting[i].index].common.quantity = rpc_date[melting[i].index].common.quantity - 1
									local ibbtn = ptr_cast(material_info_page.ctrl_ib_container:GetChildByIndex(melting[i].index-1))
									ibbtn.ItemIcon.alpha = 80
									local Control = ptr_cast(ibbtn:GetChildByIndex(2))
									L_LobbyMain.FillNumber(rpc_date[melting[i].index].common.quantity, Control)
								else
									rpc_date[melting[i].index].common.quantity = rpc_date[melting[i].index].common.quantity - 1
									local ibbtn = ptr_cast(material_info_page.ctrl_ib_container:GetChildByIndex(melting[i].index-1))
									local Control = ptr_cast(ibbtn:GetChildByIndex(2))
									L_LobbyMain.FillNumber(rpc_date[melting[i].index].common.quantity, Control)
								end
							end
						end
						if melting_table.playeritemid ~= -1 then
							for j = 1, 16 do
								if rpc_date[j] and rpc_date[j].playeritemid == melting_table.playeritemid then
									local ibbtn = ptr_cast(material_info_page.ctrl_ib_container:GetChildByIndex(j-1))
									ibbtn.ItemIcon.alpha = 80
								end
							end
						end
					end
				end
			end
		end
	end)

	if current_selected == 1 then
		weapon_info_page.ctrl_ib_container.Parent = ui.right
	elseif current_selected == 2 then
		dress_info_page.ctrl_ib_container.Parent = ui.right
	elseif current_selected == 3 then
		accessories_info_page.ctrl_ib_container.Parent = ui.right
	elseif current_selected > 3 then
		material_info_page.ctrl_ib_container.Parent = ui.right
	end
end

function FillMachine(index)
	ui.Help_part5.Visible = false
	if index ~= 0 then
		if material_info_page.ctrl_ib_container.Parent == nil then
			gui:PlayAudio("kUIA_COMPOUND_PUT")
			if rpc_date[index] then
				rpc_date_object = rpc_date[index]
				if rpc_date_object.color > 0 and rpc_date_object.color < 8 then
					ui.object.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..rpc_date_object.name.."_"..rpc_date_object.color..".tga")
				else
					ui.object.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..rpc_date_object.name..".tga")
				end
				local ibbtn = ptr_cast(ui.object:GetChildByIndex(2))
				if rpc_date_object.common.strength > 0 then
					ibbtn.Visible = true
					ibbtn.Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/badge_lv"..rpc_date_object.common.strength.."_small.dds", Vector4(0, 0, 0, 0)),
					}
				else
					ibbtn.Visible = false
				end
				ibbtn = ptr_cast(ui.object:GetChildByIndex(3))
				if rpc_date_object.gstLevel > 0 then
					ibbtn.Visible = true
					ibbtn.Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/Compose/shengxing/lb_synthesis_conversion_star_0"..rpc_date_object.gstLevel..".dds", Vector4(0, 0, 0, 0)),
					}
				else
					ibbtn.Visible = false
				end
				rpc_string.playerItemId = rpc_date_object.playeritemid
				if Weapon_table.page == current_page and Weapon_table.index ~= -1 and Weapon_table.cid == current_characters and Weapon_table.type == current_selected then
					if current_selected == 1 then
						local ibbtn = ptr_cast(weapon_info_page.ctrl_ib_container:GetChildByIndex(Weapon_table.index - 1))
						ibbtn.ItemIcon.alpha = 255
					elseif current_selected == 2 then
						local ibbtn = ptr_cast(dress_info_page.ctrl_ib_container:GetChildByIndex(Weapon_table.index - 1))
						ibbtn.ItemIcon.alpha = 255
					elseif current_selected == 3 then
						local ibbtn = ptr_cast(accessories_info_page.ctrl_ib_container:GetChildByIndex(Weapon_table.index - 1))
						ibbtn.ItemIcon.alpha = 255
					end
				end
				Weapon_table.page = current_page
				Weapon_table.index = index
				Weapon_table.cid = current_characters
				Weapon_table.type = current_selected
			end
		else
			gui:PlayAudio("kUIA_COMPOUND_PUT_ITEM")
			if rpc_date[index] then
				local ibbtn = nil
				if rpc_date[index].mType == 1 then
					ibbtn = ptr_cast(ui.qianghua:GetChildByIndex(1))
					rpc_string.strengthenItemId = rpc_date[index].playeritemid
					if index_table[1].page == current_page and index_table[1].index ~= -1 then
						local ibbtn = ptr_cast(material_info_page.ctrl_ib_container:GetChildByIndex(index_table[1].index -1))
						ibbtn.ItemIcon.alpha = 255
					end
					index_table[1].playeritemid = rpc_date[index].playeritemid
					index_table[1].page = current_page
					index_table[1].index = index
					index_table[1].num = rpc_date[index].common.quantity
				elseif rpc_date[index].mType == 2 or rpc_date[index].mType == 5 then
					ibbtn = ptr_cast(ui.qianghua:GetChildByIndex(2))
					rpc_string.stableItemId = rpc_date[index].playeritemid
					if index_table[2].page == current_page and index_table[2].index ~= -1 then
						local ibbtn = ptr_cast(material_info_page.ctrl_ib_container:GetChildByIndex(index_table[2].index -1))
						ibbtn.ItemIcon.alpha = 255
					end
					index_table[2].playeritemid = rpc_date[index].playeritemid
					index_table[2].page = current_page
					index_table[2].index = index
					index_table[2].num = rpc_date[index].common.quantity
					if rpc_date[index].mType == 5 then
						success_level = rpc_date[index].mValue
					else
						success_level = -1
					end
				else
					ibbtn = ptr_cast(ui.qianghua:GetChildByIndex(3))
					rpc_string.safeItemId = rpc_date[index].playeritemid
					if index_table[3].page == current_page and index_table[3].index ~= -1 then
						local ibbtn = ptr_cast(material_info_page.ctrl_ib_container:GetChildByIndex(index_table[3].index -1))
						ibbtn.ItemIcon.alpha = 255
					end
					index_table[3].playeritemid = rpc_date[index].playeritemid
					index_table[3].page = current_page
					index_table[3].index = index
					index_table[3].num = rpc_date[index].common.quantity
				end
				if rpc_date[index].color > 0 and rpc_date[index].color < 8 then
					ibbtn.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..rpc_date[index].name.."_"..rpc_date[index].color..".tga")
				else
					ibbtn.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..rpc_date[index].name..".tga")
				end
				local Control = ptr_cast(ibbtn:GetChildByIndex(2))
				L_LobbyMain.FillNumber(rpc_date[index].common.quantity, Control)
			end
		end
	end

	if ui.object.ItemIcon and rpc_date_object then
		if ui.sucai.PushDown == false then
			ui.sucai.blink = true
			ui.arrows.Visible = true
		end
		ui.name.Text = ""
		for i = 1, 8 do
			local Label = ptr_cast(ui.text:GetChildByIndex(i - 1))
			Label.Text = ""
		end
		for i = 1, 3 do
			local lable = ptr_cast(ui.qianghua:GetChildByIndex(i + 3))
			if i == 1 then
				local ibbtn = ptr_cast(ui.qianghua:GetChildByIndex(i))
				if rpc_date_object.common.strength == MaxLevel then
					lable.Text = ""
				else
					lable.Text = lang:GetText("需求")..rpc_date_object.common.materialNeed..lang:GetText("个")
				end
				if rpc_date_object.common.materialNeed > index_table[1].num then
					lable.TextColor = ARGB(255, 255, 0, 0)
					ibbtn.Enough = true
				else
					lable.TextColor = ARGB(255, 255, 163, 0)
					ibbtn.Enough = false
				end
			else
				if rpc_date_object.common.strength == L_LobbyMain.PersonalInfo_data.maxLevel then
					lable.Text = ""
				else
					lable.Text = lang:GetText("需求1个")
				end
			end
			lable.Visible = true
		end

		if rpc_date_object.color > 0 and rpc_date_object.color < 8 then
			ui.object.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..rpc_date_object.name.."_"..rpc_date_object.color..".tga")
		else
			ui.object.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..rpc_date_object.name..".tga")
		end
		local ibbtn = ptr_cast(ui.object:GetChildByIndex(2))
		if rpc_date_object.common.strength > 0 then
			ibbtn.Visible = true
			ibbtn.Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/badge_lv"..rpc_date_object.common.strength.."_small.dds", Vector4(0, 0, 0, 0)),
			}
		else
			ibbtn.Visible = false
		end
		ibbtn = ptr_cast(ui.object:GetChildByIndex(3))
		if rpc_date_object.gstLevel and rpc_date_object.gstLevel > 0 then
			ibbtn.Visible = true
			ibbtn.Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/Compose/shengxing/lb_synthesis_conversion_star_0"..rpc_date_object.gstLevel..".dds", Vector4(0, 0, 0, 0)),
			}
		else
			ibbtn.Visible = false
		end
		ui.text.Visible = true
		ui.name.Text = rpc_date_object.display
		if rpc_date_object.common.strength == MaxLevel then
			ui.text1.Text = ""
			ui.qianghuatext.Text = ""
		else
		print("....................",rpc_date_object.common.strength)
			ui.text1.Text = lang:GetText("强化将花费\n")..rpc_date_object.common.gpNeed..lang:GetText("C币")
			if rpc_date_object.common.strength  < 9 then
				ui.qianghuatext.Text = ""
			elseif rpc_date_object.common.strength  ==  9 then
				ui.qianghuatext.Text = lang:GetText("等级需达15级")
			elseif rpc_date_object.common.strength  == 10 then
				ui.qianghuatext.Text = lang:GetText("等级需达21级")
			elseif rpc_date_object.common.strength  == 11 then
				ui.qianghuatext.Text = lang:GetText("等级需达25级")
			elseif rpc_date_object.common.strength  == 12 then
				ui.qianghuatext.Text = lang:GetText("等级需达29级")
			elseif rpc_date_object.common.strength  == 13 then
				ui.qianghuatext.Text = lang:GetText("等级需达32级")
			elseif rpc_date_object.common.strength  == 14 then
				ui.qianghuatext.Text = lang:GetText("等级需达36级")
			elseif rpc_date_object.common.strength  == 15 then
				ui.qianghuatext.Text = lang:GetText("等级需达40级")
			elseif rpc_date_object.common.strength  == 16 then
				ui.qianghuatext.Text = lang:GetText("战队等级需达11级")
			elseif rpc_date_object.common.strength  == 17 then
				ui.qianghuatext.Text = lang:GetText("战队等级需达12级")
			elseif rpc_date_object.common.strength  == 18 then
				ui.qianghuatext.Text = ""
			end
		end
		
		
		
		if rpc_date_object.common.strength < 3 then
			ui.percent.Text = ""
			ui.text2.Text = lang:GetText("必定成功")
		elseif rpc_date_object.common.strength < 4 then
			ui.percent.Text = lang:GetText("建议使用安定装置防止退级")
			ui.text2.Text = lang:GetText("成功率极高\n失败有可能退级")
		elseif rpc_date_object.common.strength < 6 then
			ui.percent.Text = lang:GetText("建议使用安定装置防止退级")
			ui.text2.Text = lang:GetText("成功率较高\n失败有可能退级")
		elseif rpc_date_object.common.strength < 10 then
			ui.percent.Text = lang:GetText("建议使用安定装置防止退级")
			ui.text2.Text = lang:GetText("成功率较低\n失败有可能退级")
		elseif rpc_date_object.common.strength < 13 then
			ui.percent.Text = lang:GetText("建议使用安定装置防止退级")
			ui.text2.Text = lang:GetText("成功率极低\n失败有可能退级")
		elseif rpc_date_object.common.strength < 17 then
			ui.percent.Text = lang:GetText("建议使用安定装置防止退级")
			ui.text2.Text = lang:GetText("离极品神器仅一步\n之遥，祝你好运！")
		end
		local btn = ptr_cast(ui.qianghua:GetChildByIndex(1))
		if btn.ItemIcon then
			ui.start.Enable = true
			Label = ptr_cast(ui.text:GetChildByIndex(1))
			if rpc_date_object.nextLevelDetail.star > rpc_date_object.common.star then
				Label.TextColor = ARGB(255, 0, 255, 68)
			elseif rpc_date_object.nextLevelDetail.star == rpc_date_object.common.star then
				Label.TextColor = ARGB(255, 213, 255, 254)
			else
				Label.TextColor = ARGB(255, 255, 0, 0)
			end
			Label.Text = lang:GetText("战斗力：")..rpc_date_object.common.star.." → "..rpc_date_object.nextLevelDetail.star

			Label = ptr_cast(ui.text:GetChildByIndex(0))
			if rpc_date_object.nextLevelDetail.level > rpc_date_object.common.strength then
				Label.TextColor = ARGB(255, 0, 255, 68)
			elseif rpc_date_object.nextLevelDetail.level == rpc_date_object.common.strength then
				Label.TextColor = ARGB(255, 213, 255, 254)
			else
				Label.TextColor = ARGB(255, 255, 0, 0)
			end
			Label.Text = lang:GetText("强化等级：")..rpc_date_object.common.strength.." → "..rpc_date_object.nextLevelDetail.level
			Label = ptr_cast(ui.text:GetChildByIndex(6))
			if rpc_date_object.nextLevelDetail.holesNum > rpc_date_object.common.holeNum then
				Label.TextColor = ARGB(255, 0, 255, 68)
			elseif rpc_date_object.nextLevelDetail.holesNum == rpc_date_object.common.holeNum then
				Label.TextColor = ARGB(255, 213, 255, 254)
			else
				Label.TextColor = ARGB(255, 255, 0, 0)
			end
			Label.Text = lang:GetText("开放的可钻孔数：")..rpc_date_object.common.holeNum.." → "..rpc_date_object.nextLevelDetail.holesNum
		else
			ui.start.Enable = false
			Label = ptr_cast(ui.text:GetChildByIndex(1))
			Label.TextColor = ARGB(255, 213, 255, 254)
			Label.Text = lang:GetText("战斗力：")..rpc_date_object.common.star
			Label = ptr_cast(ui.text:GetChildByIndex(0))
			Label.TextColor = ARGB(255, 213, 255, 254)
			Label.Text = lang:GetText("强化等级：")..rpc_date_object.common.strength
			Label = ptr_cast(ui.text:GetChildByIndex(6))
			Label.TextColor = ARGB(255, 213, 255, 254)
			Label.Text = lang:GetText("开放的可钻孔数：")..rpc_date_object.common.holeNum
		end
		if rpc_date_object.common.type == 1 then
			local pow = nil
			local speed = nil
			Label = ptr_cast(ui.text:GetChildByIndex(2))
			Label.Text = lang:GetText("攻击力：")
			if btn.ItemIcon then
				if rpc_date_object.nextLevelDetail.damange_add > rpc_date_object.performance.damange_add then
					Label.TextColor = ARGB(255, 0, 255, 68)
					ui.ctrl_demage.Visible = true
					ui.ctrl_demage.Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ToolTips/lb_tooltips_jiantou_green.dds",Vector4(0, 0, 0, 0)),
					}
				elseif rpc_date_object.nextLevelDetail.damange_add == rpc_date_object.performance.damange_add then
					Label.TextColor = ARGB(255, 213, 255, 254)
					ui.ctrl_demage.Visible = false
				else
					ui.ctrl_demage.Visible = true
					ui.ctrl_demage.Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ToolTips/lb_tooltips_jiantou_red.dds",Vector4(0, 0, 0, 0)),
					}
					Label.TextColor = ARGB(255, 255, 0, 0)
				end
				pow = math.floor((rpc_date_object.nextLevelDetail.damange_add + rpc_date_object.nextLevelDetail.damange) * 10 ) / 10
			else
				ui.ctrl_demage.Visible = false
				pow = math.floor((rpc_date_object.performance.damange + rpc_date_object.performance.damange_add) * 10) / 10
				Label.TextColor = ARGB(255, 213, 255, 254)
			end
			ui.compare_demage1.Visible = true
			if rpc_date_object.wid == 4 then
				pow = pow * 3
			end
			local temp = (pow - (pow % 50)) / 50 + 1
			if temp > 1 then
				ui.star.Visible = true
				local con = ptr_cast(ui.star:GetChildByIndex(1))
				con.Text = " x  "..(temp - 1)
			else
				ui.star.Visible = false
			end
			if pow % 50 == 0 then
				temp = temp - 1
				ui.compare_demage1.Icon = compareIcon2[temp]
				ui.compare_demage1:ResetBaseValue(100)
			else
				if temp > 7 then
					temp = 7
				end
				ui.compare_demage1.Icon = compareIcon2[temp]
				ui.compare_demage1:ResetBaseValue(pow % 50 * 2)
			end
			Label = ptr_cast(ui.text:GetChildByIndex(3))
			Label.Text = lang:GetText("攻击速度")..lang:GetText("：")
			if btn.ItemIcon then
				if rpc_date_object.nextLevelDetail.speed_add > rpc_date_object.performance.speed_add then
					Label.TextColor = ARGB(255, 0, 255, 68)
					ui.ctrl_demage1.Visible = true
					ui.ctrl_demage1.Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ToolTips/lb_tooltips_jiantou_green.dds",Vector4(0, 0, 0, 0)),
					}
				elseif rpc_date_object.nextLevelDetail.speed_add == rpc_date_object.performance.speed_add then
					Label.TextColor = ARGB(255, 213, 255, 254)
					ui.ctrl_demage1.Visible = false
					ui.ctrl_demage1.Skin = Gui.ControlSkin
				else
					Label.TextColor = ARGB(255, 255, 0, 0)
					ui.ctrl_demage1.Visible = true
					ui.ctrl_demage1.Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ToolTips/lb_tooltips_jiantou_green.dds",Vector4(0, 0, 0, 0)),
					}
				end
				speed = math.floor((rpc_date_object.nextLevelDetail.speed + rpc_date_object.nextLevelDetail.speed_add) * 10) / 10
			else
				Label.TextColor = ARGB(255, 213, 255, 254)
				speed = math.floor((rpc_date_object.performance.speed + rpc_date_object.performance.speed_add) * 10) / 10
				ui.ctrl_demage1.Visible = false
			end
			ui.compare_demage2.Visible = true
			local temp = (speed - (speed % 50)) / 50 + 1
			if temp > 1 then
				ui.star1.Visible = true
				local con = ptr_cast(ui.star1:GetChildByIndex(1))
				con.Text = " x  "..(temp - 1)
			else
				ui.star1.Visible = false
			end
			if speed % 50 == 0 then
				temp = temp - 1
				ui.compare_demage2.Icon = compareIcon2[temp + 7]
				ui.compare_demage2:ResetBaseValue(100)
			else
				if temp > 7 then
					temp = 7
				end
				ui.compare_demage2.Icon = compareIcon2[temp + 7]
				ui.compare_demage2:ResetBaseValue(speed % 50 * 2)
			end
		else
			ui.compare_demage1.Visible = false
			ui.compare_demage2.Visible = false
			ui.ctrl_demage.Visible = false
			ui.ctrl_demage1.Visible = false
			ui.star.Visible = false
			ui.star1.Visible = false
			Label = ptr_cast(ui.text:GetChildByIndex(2))
			if btn.ItemIcon then
				if rpc_date_object.nextLevelDetail.cResistanceFire > rpc_date_object.common.cResistanceFire_add then
					Label.TextColor = ARGB(255, 0, 255, 68)
				elseif rpc_date_object.nextLevelDetail.cResistanceFire == rpc_date_object.common.cResistanceFire_add then
					Label.TextColor = ARGB(255, 213, 255, 254)
				else
					Label.TextColor = ARGB(255, 255, 0, 0)
				end
				Label.Text = lang:GetText("火焰抗性").." "..precision(rpc_date_object.common.cResistanceFire + rpc_date_object.common.cResistanceFire_add).."% → "..precision(rpc_date_object.common.cResistanceFire + rpc_date_object.nextLevelDetail.cResistanceFire).."%"
			else
				Label.TextColor = ARGB(255, 213, 255, 254)
				Label.Text = lang:GetText("火焰抗性").." "..precision(rpc_date_object.common.cResistanceFire + rpc_date_object.common.cResistanceFire_add).."%"
			end
			Label = ptr_cast(ui.text:GetChildByIndex(3))
			if btn.ItemIcon then
				if rpc_date_object.nextLevelDetail.cResistanceBlast > rpc_date_object.common.cResistanceBlast_add then
					Label.TextColor = ARGB(255, 0, 255, 68)
				elseif rpc_date_object.nextLevelDetail.cResistanceBlast == rpc_date_object.common.cResistanceBlast_add then
					Label.TextColor = ARGB(255, 213, 255, 254)
				else
					Label.TextColor = ARGB(255, 255, 0, 0)
				end
				Label.Text = lang:GetText("爆炸抗性").." "..precision(rpc_date_object.common.cResistanceBlast + rpc_date_object.common.cResistanceBlast_add).."% → "..precision(rpc_date_object.nextLevelDetail.cResistanceBlast + rpc_date_object.common.cResistanceBlast).."%"
			else
				Label.TextColor = ARGB(255, 213, 255, 254)
				Label.Text = lang:GetText("爆炸抗性").." "..precision(rpc_date_object.common.cResistanceBlast + rpc_date_object.common.cResistanceBlast_add).."%"
			end
			Label = ptr_cast(ui.text:GetChildByIndex(4))
			if btn.ItemIcon then
				if rpc_date_object.nextLevelDetail.cResistanceBullet > rpc_date_object.common.cResistanceBullet_add then
					Label.TextColor = ARGB(255, 0, 255, 68)
				elseif rpc_date_object.nextLevelDetail.cResistanceBullet == rpc_date_object.common.cResistanceBullet_add then
					Label.TextColor = ARGB(255, 213, 255, 254)
				else
					Label.TextColor = ARGB(255, 255, 0, 0)
				end
				Label.Text = lang:GetText("子弹抗性").." "..precision(rpc_date_object.common.cResistanceBullet + rpc_date_object.common.cResistanceBullet_add).."% → "..precision(rpc_date_object.nextLevelDetail.cResistanceBullet + rpc_date_object.common.cResistanceBullet).."%"
			else
				Label.TextColor = ARGB(255, 213, 255, 254)
				Label.Text = lang:GetText("子弹抗性").." "..precision(rpc_date_object.common.cResistanceBullet + rpc_date_object.common.cResistanceBullet_add).."%"
			end
			Label = ptr_cast(ui.text:GetChildByIndex(5))
			if btn.ItemIcon then
				if rpc_date_object.nextLevelDetail.cResistanceKnife > rpc_date_object.common.cResistanceKnife_add then
					Label.TextColor = ARGB(255, 0, 255, 68)
				elseif rpc_date_object.nextLevelDetail.cResistanceKnife == rpc_date_object.common.cResistanceKnife_add then
					Label.TextColor = ARGB(255, 213, 255, 254)
				else
					Label.TextColor = ARGB(255, 255, 0, 0)
				end
				Label.Text = lang:GetText("近身抗性").." "..precision(rpc_date_object.common.cResistanceKnife + rpc_date_object.common.cResistanceKnife_add).."% → "..precision(rpc_date_object.nextLevelDetail.cResistanceKnife + rpc_date_object.common.cResistanceKnife).."%"
			else
				Label.TextColor = ARGB(255, 213, 255, 254)
				Label.Text = lang:GetText("近身抗性").." "..precision(rpc_date_object.common.cResistanceKnife + rpc_date_object.common.cResistanceKnife_add).."%"
			end
			Label = ptr_cast(ui.text:GetChildByIndex(6))
			if btn.ItemIcon then
				if rpc_date_object.nextLevelDetail.cBloodAdd_add > rpc_date_object.common.cBloodAdd_add then
					Label.TextColor = ARGB(255, 0, 255, 68)
				elseif rpc_date_object.nextLevelDetail.cBloodAdd_add == rpc_date_object.common.cBloodAdd_add then
					Label.TextColor = ARGB(255, 213, 255, 254)
				else
					Label.TextColor = ARGB(255, 255, 0, 0)
				end
				Label.Text = lang:GetText("增加血量").." "..precision(rpc_date_object.common.cBloodAdd + rpc_date_object.common.cBloodAdd_add).."% → "..precision(rpc_date_object.nextLevelDetail.cBloodAdd_add + rpc_date_object.common.cBloodAdd).."%"
			else
				Label.TextColor = ARGB(255, 213, 255, 254)
				Label.Text = lang:GetText("增加血量").." "..precision(rpc_date_object.common.cBloodAdd + rpc_date_object.common.cBloodAdd_add).."%"
			end
			Label = ptr_cast(ui.text:GetChildByIndex(7))
			if btn.ItemIcon then
				if rpc_date_object.nextLevelDetail.holesNum > rpc_date_object.common.holeNum then
					Label.TextColor = ARGB(255, 0, 255, 68)
				elseif rpc_date_object.nextLevelDetail.holesNum == rpc_date_object.common.holeNum then
					Label.TextColor = ARGB(255, 213, 255, 254)
				else
					Label.TextColor = ARGB(255, 255, 0, 0)
				end
				Label.Text = lang:GetText("开放的可钻孔数：")..rpc_date_object.common.holeNum.." → "..rpc_date_object.nextLevelDetail.holesNum
			else
				Label.TextColor = ARGB(255, 213, 255, 254)
				Label.Text = lang:GetText("开放的可钻孔数：")..rpc_date_object.common.holeNum
			end
		end
	else
		ui.name.Text = ""
		for i = 1, 10 do
			local Label = ptr_cast(ui.text:GetChildByIndex(i - 1))
			Label.Text = ""
		end
		ui.text1.Text = ""
		ui.qianghuatext.Text = ""
		ui.text2.Text = ""
		ui.object.ItemIcon = nil
		ui.text.Visible = false
		ui.star.Visible = false
		ui.star1.Visible = false
		ui.ctrl_demage.Visible = false
		ui.ctrl_demage1.Visible = false
		ui.start.Enable = false
		ui.sucai.blink = false
		ui.arrows.Visible = false
		for i = 1, 3 do
			local lable = ptr_cast(ui.qianghua:GetChildByIndex(i + 3))
			lable.Visible = false
		end
	end
	for i = 1, 3 do
		local ibbtn = ptr_cast(ui.qianghua:GetChildByIndex(i))
		local control = ptr_cast(ui.Image:GetChildByIndex(i))
		local control1 = ptr_cast(ibbtn:GetChildByIndex(2))
		if ibbtn.ItemIcon then
			control.Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_ico_01_down.dds", Vector4(0, 0, 0, 0)),
			}
			control1.Visible = true
		else
			control.Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_ico_01_normal.dds", Vector4(0, 0, 0, 0)),
			}
			control1.Visible = false
		end
	end
	local buff1 = true
	local buff2 = true
	local buff3 = true
	ui.buff_layout:OnDestroy()
	for i,v in ipairs(L_LobbyMain.bufflist) do
		if v[5] == 62 then
			buff1 = false
			local buffInfo = L_PersonalInfo.SpawnNewBuff(v,i)
			buffInfo.LBuff.Parent = ui.buff_layout
		end
		if v[5] == 33 then
			buff2 = false
			local buffInfo = L_PersonalInfo.SpawnNewBuff(v,i)
			buffInfo.LBuff.Parent = ui.buff_layout
		end
		if v[5] == 83 then
			buff3 = false
			local buffInfo = L_PersonalInfo.SpawnNewBuff(v,i)
			buffInfo.LBuff.Parent = ui.buff_layout
		end
	end
	if buff1 then
		local BuffCon = Gui.Create(gui)
		{
			Gui.ItemBoxBtn "LBuff"
			{
				Size = Vector2(16,16),
				BackgroundColor = ARGB(255,255,255,255),
				LoadingImage = Gui.AnimatedImage("LobbyUI/loading_ring.tga", 4, 2, 8),
				
				EventMouseEnter = function(sender, e)
					if sender.Loading == false then
						L_ToolTips.FillToolTipsBuffInfoWindow(nil, index, lang:GetText("SN4932"), lang:GetText("SD4932"), lang:GetText("加入战队后可激活此加成"))
					end
				end,
				EventToolTipsShow = function(sender, e)
					L_ToolTips.ShowToolTipsShowWindow(sender)
				end,
				EventMouseLeave = function(sender, e)
					L_ToolTips.HideToolTipsWindow()
				end,
			},	
		}
		BuffCon.LBuff.Skin = Gui.ItemBoxBtnSkin
		{
			NeutralNormalImage = Gui.Image("LobbyUI/persionalInfo/buff/buff_lb_squad_skill_02_hui.dds",Vector4(0, 0, 0, 0)),
			NeutralHoverImage = Gui.Image("LobbyUI/persionalInfo/buff/buff_lb_squad_skill_02_hui.dds",Vector4(0, 0, 0, 0)),
			NeutralSelectedImage = Gui.Image("LobbyUI/persionalInfo/buff/buff_lb_squad_skill_02_hui.dds",Vector4(0, 0, 0, 0)),
			NeutralDisabledImage = nil,
		}
		BuffCon.LBuff.Parent = ui.buff_layout
	end
	if buff2 then
		local BuffCon = Gui.Create(gui)
		{
			Gui.ItemBoxBtn "LBuff"
			{
				Size = Vector2(16,16),
				BackgroundColor = ARGB(255,255,255,255),
				LoadingImage = Gui.AnimatedImage("LobbyUI/loading_ring.tga", 4, 2, 8),
				
				EventMouseEnter = function(sender, e)
					if sender.Loading == false then
						L_ToolTips.FillToolTipsBuffInfoWindow(nil, index, lang:GetText("SN4712"), lang:GetText("SD4712"), lang:GetText("猜数字成功以后可获得此加成"))
					end
				end,
				EventToolTipsShow = function(sender, e)
					L_ToolTips.ShowToolTipsShowWindow(sender)
				end,
				EventMouseLeave = function(sender, e)
					L_ToolTips.HideToolTipsWindow()
				end,
			},	
		}
		BuffCon.LBuff.Skin = Gui.ItemBoxBtnSkin
		{
			NeutralNormalImage = Gui.Image("LobbyUI/persionalInfo/buff/buff_timeaddsucess_hui.dds",Vector4(0, 0, 0, 0)),
			NeutralHoverImage = Gui.Image("LobbyUI/persionalInfo/buff/buff_timeaddsucess_hui.dds",Vector4(0, 0, 0, 0)),
			NeutralSelectedImage = Gui.Image("LobbyUI/persionalInfo/buff/buff_timeaddsucess_hui.dds",Vector4(0, 0, 0, 0)),
			NeutralDisabledImage = nil,
		}
		BuffCon.LBuff.Parent = ui.buff_layout
	end
	if buff3 then
		local BuffCon = Gui.Create(gui)
		{
			Gui.ItemBoxBtn "LBuff"
			{
				Size = Vector2(16,16),
				BackgroundColor = ARGB(255,255,255,255),
				LoadingImage = Gui.AnimatedImage("LobbyUI/loading_ring.tga", 4, 2, 8),
				
				EventMouseEnter = function(sender, e)
					if sender.Loading == false then
						L_ToolTips.FillToolTipsBuffInfoWindow(nil, index, lang:GetText("SN5419"), lang:GetText("SD5419"), lang:GetText("成为VIP可获得此加成"))
					end
				end,
				EventToolTipsShow = function(sender, e)
					L_ToolTips.ShowToolTipsShowWindow(sender)
				end,
				EventMouseLeave = function(sender, e)
					L_ToolTips.HideToolTipsWindow()
				end,
			},	
		}
		BuffCon.LBuff.Skin = Gui.ItemBoxBtnSkin
		{
			NeutralNormalImage = Gui.Image("LobbyUI/persionalInfo/buff/buff_vip_hui.dds",Vector4(0, 0, 0, 0)),
			NeutralHoverImage = Gui.Image("LobbyUI/persionalInfo/buff/buff_vip_hui.dds",Vector4(0, 0, 0, 0)),
			NeutralSelectedImage = Gui.Image("LobbyUI/persionalInfo/buff/buff_vip_hui.dds",Vector4(0, 0, 0, 0)),
			NeutralDisabledImage = nil,
		}
		BuffCon.LBuff.Parent = ui.buff_layout
	end
	Fill_Help()
end

function FillMachine1(index)
	ui.Help_part5.Visible = false
	if index ~= 0 then
		if material_info_page.ctrl_ib_container.Parent == nil then
			gui:PlayAudio("kUIA_COMPOUND_PUT")
			rpc_date_object = rpc_date[index]
			if rpc_date_object.color > 0 and rpc_date_object.color < 8 then
				ui.object1.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..rpc_date_object.name.."_"..rpc_date_object.color..".tga")
			else
				ui.object1.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..rpc_date_object.name..".tga")
			end
			local ibbtn = ptr_cast(ui.object1:GetChildByIndex(2))
			if rpc_date_object.common.strength > 0 then
				ibbtn.Visible = true
				ibbtn.Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/badge_lv"..rpc_date_object.common.strength.."_small.dds", Vector4(0, 0, 0, 0)),
				}
			else
				ibbtn.Visible = false
			end
			
			ibbtn = ptr_cast(ui.object1:GetChildByIndex(3))
			if rpc_date_object.gstLevel > 0 then
				ibbtn.Visible = true
				ibbtn.Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Compose/shengxing/lb_synthesis_conversion_star_0"..rpc_date_object.gstLevel..".dds", Vector4(0, 0, 0, 0)),
				}
			else
				ibbtn.Visible = false
			end
			if Weapon_table.page == current_page and Weapon_table.index ~= -1 and Weapon_table.cid == current_characters and Weapon_table.type == current_selected then
				if current_selected == 1 then
					local ibbtn = ptr_cast(weapon_info_page.ctrl_ib_container:GetChildByIndex(Weapon_table.index - 1))
					ibbtn.ItemIcon.alpha = 255
				elseif current_selected == 2 then
					local ibbtn = ptr_cast(dress_info_page.ctrl_ib_container:GetChildByIndex(Weapon_table.index - 1))
					ibbtn.ItemIcon.alpha = 255
				elseif current_selected == 3 then
					local ibbtn = ptr_cast(accessories_info_page.ctrl_ib_container:GetChildByIndex(Weapon_table.index - 1))
					ibbtn.ItemIcon.alpha = 255
				end
			end
			Weapon_table.page = current_page
			Weapon_table.index = index
			Weapon_table.cid = current_characters
			Weapon_table.type = current_selected
		else
			gui:PlayAudio("kUIA_COMPOUND_PUT_ITEM")
			if rpc_date[index].mType == 11 then
				local ibbtn = ui.dakong
				if hole.page == current_page and hole.index ~= -1 then
					local ibbtn = ptr_cast(material_info_page.ctrl_ib_container:GetChildByIndex(hole.index - 1))
					ibbtn.ItemIcon.alpha = 255
				end
				if rpc_date[index].color > 0 and rpc_date[index].color < 8 then
					ui.dakong.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..rpc_date[index].name.."_"..rpc_date[index].color..".tga")
				else
					ui.dakong.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..rpc_date[index].name..".tga")
				end
				hole.index = index
				hole.page = current_page
				hole.num = rpc_date[index].common.quantity
				hole.playeritemid = rpc_date[index].playeritemid
				local Control = ptr_cast(ibbtn:GetChildByIndex(2))
				L_LobbyMain.FillNumber(rpc_date[index].common.quantity, Control)
			end
		end
	end
	if ui.object1.ItemIcon and rpc_date_object then
		if ui.sucai.PushDown == false then
			ui.sucai.blink = true
			ui.arrows.Visible = true
		end
		rpc_slotting.playerItemId = rpc_date_object.playeritemid
		rpc_insert.playerItemId = rpc_date_object.playeritemid
		rpc_remove.playerItemId = rpc_date_object.playeritemid
		local ibbtn = ptr_cast(ui.object1:GetChildByIndex(2))
		if rpc_date_object.common.strength > 0 then
			ibbtn.Visible = true
			ibbtn.Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/badge_lv"..rpc_date_object.common.strength.."_small.dds", Vector4(0, 0, 0, 0)),
			}
		else
			ibbtn.Visible = false
		end
		ibbtn = ptr_cast(ui.object1:GetChildByIndex(3))
		if rpc_date_object.gstLevel and rpc_date_object.gstLevel > 0 then
			ibbtn.Visible = true
			ibbtn.Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/Compose/shengxing/lb_synthesis_conversion_star_0"..rpc_date_object.gstLevel..".dds", Vector4(0, 0, 0, 0)),
			}
		else
			ibbtn.Visible = false
		end
		for i = 1, 6 do
			if rpc_date_object.combineDetail[i].open == 0 then
				local Control = ptr_cast(ui.gaizhuang:GetChildByIndex(i + 1))
				Control.Skin = ItemBoxBtn_Compose_b
				Control.ItemIcon = nil
				if rpc_date_object.common.type == 1 then
					if i == 1 then
						Control.Hint = lang:GetText("强化等级达到4级时开放")
					elseif i == 2 then
						Control.Hint = lang:GetText("强化等级达到7级时开放")
					elseif i == 3 then
						Control.Hint = lang:GetText("强化等级达到10级时开放")
					elseif i == 4 then
						Control.Hint = lang:GetText("强化等级达到12级时开放")
					elseif i == 5 then
						Control.Hint = lang:GetText("强化等级达到14级时开放")
					elseif i == 6 then
						Control.Hint = lang:GetText("强化等级达到15级时开放")
					end
				else
					if i == 1 then
						Control.Hint = lang:GetText("强化等级达到7级时开放")
					elseif i == 2 then
						Control.Hint = lang:GetText("强化等级达到12级时开放")
					elseif i == 3 then
						Control.Hint = lang:GetText("强化等级达到15级时开放")
					else
						Control.Hint = lang:GetText("暂不开放")
					end
				end
				
				Control = ptr_cast(ui.gaizhuang:GetChildByIndex(i + 7))
				Control.Enable = false
				Control.Text = lang:GetText("改装")
			elseif rpc_date_object.combineDetail[i].open == 1 then
		
				if rpc_date_object.combineDetail[i].state == 0 then
					local Control = ptr_cast(ui.gaizhuang:GetChildByIndex(i + 1))
					Control.Skin = ItemBoxBtn_Compose_a
					Control.Hint = lang:GetText("")
					Control.ItemIcon = nil
					Control = ptr_cast(ui.gaizhuang:GetChildByIndex(i + 7))
					Control.Enable = true
					Control.Text = lang:GetText("改装")
				else
					if rpc_date_object.combineDetail[i].level == 0 then
						local Control = ptr_cast(ui.gaizhuang:GetChildByIndex(i + 1))
						Control.Skin = ItemBoxBtn_Compose_c
						Control.ItemIcon = nil
						Control = ptr_cast(ui.gaizhuang:GetChildByIndex(i + 7))
						Control.Enable = false
						Control.Text = ""
					else
						local Control = ptr_cast(ui.gaizhuang:GetChildByIndex(i + 1))
						if rpc_date_object.common.type == 1 then
							Control.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/wepskillmodlv"..rpc_date_object.combineDetail[i].level..".tga")
						else
							Control.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/avatarskillmod"..rpc_date_object.combineDetail[i].level..".tga")
						end
						Control.Skin = ItemBoxBtn_Compose_c
						Control = ptr_cast(ui.gaizhuang:GetChildByIndex(i + 7))
						Control.Enable = true
						Control.Text = lang:GetText("移除")				
					end
				end
			end
		end
		ui.main_2.Visible = true
		local count = 0
		for i,v in ipairs(rpc_date_object.combineDetail) do
			if v.open == 1 then
				count = count + 1
			end
			local lab = ptr_cast(ui.desc:GetChildByIndex(i - 1))
			if v.desc ~= "" then
					lab.Text = v.desc
					lab.TextColor = ARGB(255, 213, 255, 254)
			else
				lab.TextColor = ARGB(255, 213, 255, 254)
				lab.Text = lang:GetText("未镶嵌")
			end
		end
		ui.count.Text = lang:GetText("开放的可钻孔数：")..count
	else
		ui.object1.ItemIcon = nil
		ui.sucai.blink = false
		ui.arrows.Visible = false
		for i = 1, 12 do
			local Control = ptr_cast(ui.gaizhuang:GetChildByIndex(i + 1))
			if i < 7 then
				Control.Skin = ItemBoxBtn_Compose_b
				Control.ItemIcon = nil
			else
				Control.Enable = false
			end
		end
		ui.main_2.Visible = false
	end

	local Control = ptr_cast(ui.dakong:GetChildByIndex(2))
	if ui.dakong.ItemIcon then
		Control.Visible = true
	else
		Control.Visible = false
	end
	Fill_Help()
end

function FillMachine2(index, type)
	if index ~= 0 then
		gui:PlayAudio("kUIA_COMPOUND_PUT")
		rpc_date_object_1[type] = rpc_date[index]

		if type == 1 then
			if rpc_date_object_1[type].color > 0 and rpc_date_object_1[type].color < 8 then
				ui.object2.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..rpc_date_object_1[type].name.."_"..rpc_date_object_1[type].color..".tga")
			else
				ui.object2.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..rpc_date_object_1[type].name..".tga")
			end
			local ibbtn = ptr_cast(ui.object2:GetChildByIndex(2))
			if rpc_date_object_1[type].common.strength > 0 then
				ibbtn.Visible = true
				ibbtn.Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/badge_lv"..rpc_date_object_1[type].common.strength.."_small.dds", Vector4(0, 0, 0, 0)),
				}
			else
				ibbtn.Visible = false
			end
			local ibbtn = ptr_cast(ui.object2:GetChildByIndex(3))
			if rpc_date_object_1[type].gstLevel > 0 then
				ibbtn.Visible = true
				ibbtn.Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Compose/shengxing/lb_synthesis_conversion_star_0"..rpc_date_object_1[type].gstLevel..".dds", Vector4(0, 0, 0, 0)),
				}
			else
				ibbtn.Visible = false
			end
		else
			if rpc_date_object_1[type].color > 0 and rpc_date_object_1[type].color < 8 then
				ui.object3.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..rpc_date_object_1[type].name.."_"..rpc_date_object_1[type].color..".tga")
			else
				ui.object3.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..rpc_date_object_1[type].name..".tga")
			end
			local ibbtn = ptr_cast(ui.object3:GetChildByIndex(2))
			if rpc_date_object_1[type].common.strength > 0 then
				ibbtn.Visible = true
				ibbtn.Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/badge_lv"..rpc_date_object_1[type].common.strength.."_small.dds", Vector4(0, 0, 0, 0)),
				}
			else
				ibbtn.Visible = false
			end
			
			local ibbtn = ptr_cast(ui.object3:GetChildByIndex(3))
			if rpc_date_object_1[type].gstLevel > 0 then
				ibbtn.Visible = true
				ibbtn.Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Compose/shengxing/lb_synthesis_conversion_star_0"..rpc_date_object_1[type].gstLevel..".dds", Vector4(0, 0, 0, 0)),
				}
			else
				ibbtn.Visible = false
			end
			
		end
		if convert[type].page == current_page and convert[type].index ~= -1 and convert[type].cid == current_characters then
			if current_selected == 1 then
				local ibbtn = ptr_cast(weapon_info_page.ctrl_ib_container:GetChildByIndex(convert[type].index - 1))
				ibbtn.ItemIcon.alpha = 255
			end
		elseif convert[type].page == current_page and convert[type].index ~= -1 and convert[type].cid == current_characters then
			if current_selected == 2 then
				local ibbtn = ptr_cast(dress_info_page.ctrl_ib_container:GetChildByIndex(convert[1].index - 1))
				ibbtn.ItemIcon.alpha = 255
			end
		elseif convert[type].page == current_page and convert[type].index ~= -1 and convert[type].cid == current_characters then
			if current_selected == 3 then
				local ibbtn = ptr_cast(accessories_info_page.ctrl_ib_container:GetChildByIndex(convert[type].index - 1))
				ibbtn.ItemIcon.alpha = 255
			end
		end
		convert[type].page = current_page
		convert[type].index = index
		convert[type].cid = current_characters
		convert[type].type = current_selected
	end
	ui.X.Visible = false
	ui.X1.Visible = true
	if (rpc_date_object_1[1] and rpc_date_object_1[1].gstLevel > 0) or (rpc_date_object_1[2] and rpc_date_object_1[2].gstLevel > 0) then
		ui.zhuanghuan_xingji_tips.Visible = true
	else
		ui.zhuanghuan_xingji_tips.Visible = false
	end
	if ui.object2.ItemIcon and ui.object3.ItemIcon then
		ui.left_3.Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_ico_03_down.dds", Vector4(0, 0, 0, 0)),
		}
		ui.right_3.Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_ico_03_b_down.dds", Vector4(0, 0, 0, 0)),
		}
		rpc_convert.fromItemId = rpc_date_object_1[1].playeritemid
		rpc_convert.toItemId = rpc_date_object_1[2].playeritemid
		if rpc_date_object_1[1].common.type ~= rpc_date_object_1[2].common.type then
			ui.X.Visible = true
			ui.X1.Visible = false
			ui.main_3.Visible = false
			ui.start1.Enable = false
		elseif rpc_date_object_1[1].common.subtype ~= rpc_date_object_1[2].common.subtype then
			ui.X.Visible = true
			ui.X1.Visible = false
			ui.main_3.Visible = false
			ui.start1.Enable = false
		else
			ui.main_3.Visible = true
			ui.start1.Enable = true
			local lab = ptr_cast(ui.main_3:GetChildByIndex(0))
			lab.Text = lang:GetText("转换后数据参考")
			ui.desc1.Visible = true
			ui.desc2.Visible = true
			rpc.safecallload("convert_per",rpc_convert,
			function(data)
				warning_level = getlevel(data.rate)
				ui.Help_part5.Visible = true
				ui.re_text:CleanAll()
				from_rate = data.from_rate
				to_rate = data.to_rate
				local t_text = nil
				if warning_level == 1 then
					t_text = lang:GetText("@!8@!当前转换@!")..warning_level..lang:GetText("@!肯定不掉级@!8@!，您可以放心转换！")
				elseif warning_level < 7 and warning_level > 1 then
					t_text = lang:GetText("@!8@!当前转换有@!")..warning_level.."@!"..t_Text[warning_level]..lang:GetText("@!8@!的掉级率，")..t_Text1[warning_level]
				elseif warning_level == 7 then
					t_text = lang:GetText("@!8@!当前转换@!")..warning_level..lang:GetText("@!肯定掉级@!8@!，您是否还要继续呢？")
				end
				local msg_table = L_PushCmd.Split(t_text,"@!")
				local new = true
				for i=2, #msg_table do
					--颜色
					if i % 2 == 0 then
						if tonumber(msg_table[i]) > 0 and tonumber(msg_table[i]) < 9 then
							color = MessageBox.font_color[tonumber(msg_table[i])]
						else
							color = ARGB(255, 255, 255, 255)
						end
					--内容
					else
						if i == 5 then
							ui.re_text:AddMsg(msg_table[i],color,new,false)
						else
							ui.re_text:AddMsg(msg_table[i],color,new,false)
						end
						new = false
					end
				end
				local lab = ptr_cast(ui.desc1:GetChildByIndex(0))
				lab.Text = lang:GetText("耐久值：")..data.from.common.durable
				local lab1 = ptr_cast(ui.desc2:GetChildByIndex(0))
				lab1.Text = lang:GetText("耐久值：")..data.to.common.durable
				if data.from.common.durable > rpc_date_object_1[1].common.durable then
					lab.TextColor = ARGB(255, 0, 255, 63)
				elseif data.from.common.durable == rpc_date_object_1[1].common.durable then
					lab.TextColor = ARGB(255, 213, 255, 254)
				else
					lab.TextColor = ARGB(255, 255, 0, 0)
				end
				if data.to.common.durable > rpc_date_object_1[2].common.durable then
					lab1.TextColor = ARGB(255, 0, 255, 63)
				elseif data.to.common.durable == rpc_date_object_1[2].common.durable then
					lab1.TextColor = ARGB(255, 213, 255, 254)
				else
					lab1.TextColor = ARGB(255, 255, 0, 0)
				end
				lab = ptr_cast(ui.desc1:GetChildByIndex(1))
				lab.Text = lang:GetText("战斗力：")..rpc_date_object_1[1].common.star.." → "..data.from.common.star
				lab1 = ptr_cast(ui.desc2:GetChildByIndex(1))
				lab1.Text = lang:GetText("战斗力：")..rpc_date_object_1[2].common.star.." → "..data.to.common.star
				if data.from.common.star > rpc_date_object_1[1].common.star then
					lab.TextColor = ARGB(255, 0, 255, 63)
				elseif data.from.common.star == rpc_date_object_1[1].common.star then
					lab.TextColor = ARGB(255, 213, 255, 254)
				else
					lab.TextColor = ARGB(255, 255, 0, 0)
				end
				if data.to.common.star > rpc_date_object_1[2].common.star then
					lab1.TextColor = ARGB(255, 0, 255, 63)
				elseif data.to.common.star == rpc_date_object_1[2].common.star then
					lab1.TextColor = ARGB(255, 213, 255, 254)
				else
					lab1.TextColor = ARGB(255, 255, 0, 0)
				end
				lab = ptr_cast(ui.desc1:GetChildByIndex(2))
				lab.Text = lang:GetText("强化等级：")..rpc_date_object_1[1].common.strength.." → "..data.from.common.strength
				lab1 = ptr_cast(ui.desc2:GetChildByIndex(2))
				lab1.Text = lang:GetText("强化等级：")..rpc_date_object_1[2].common.strength.." → "..data.to.common.strength
				if data.from.common.strength > rpc_date_object_1[1].common.strength then
					lab.TextColor = ARGB(255, 0, 255, 63)
				elseif data.from.common.strength == rpc_date_object_1[1].common.strength then
					lab.TextColor = ARGB(255, 213, 255, 254)
				else
					lab.TextColor = ARGB(255, 255, 0, 0)
				end
				if data.to.common.strength > rpc_date_object_1[2].common.strength then
					lab1.TextColor = ARGB(255, 0, 255, 63)
				elseif data.to.common.strength == rpc_date_object_1[2].common.strength then
					lab1.TextColor = ARGB(255, 213, 255, 254)
				else
					lab1.TextColor = ARGB(255, 255, 0, 0)
				end
				lab = ptr_cast(ui.desc1:GetChildByIndex(3))
				if data.from.isBind == "Y" then
					lab.Text = lang:GetText("绑定状态： 绑定")
				elseif data.from.isBind == "N" then
					lab.Text = lang:GetText("绑定状态： 未绑定")
				end
				lab1 = ptr_cast(ui.desc2:GetChildByIndex(3))
				if data.to.isBind == "Y" then
					lab1.Text = lang:GetText("绑定状态： 绑定")
				elseif data.to.isBind == "N" then
					lab1.Text = lang:GetText("绑定状态： 未绑定")
				end
				if rpc_date_object_1[1].common.type == 1 then
					ui.ctrl_demage2.Visible = true
					ui.ctrl_demage3.Visible = true
					ui.ctrl_demage4.Visible = true
					ui.ctrl_demage5.Visible = true
					lab = ptr_cast(ui.desc1:GetChildByIndex(4))
					lab.Text = lang:GetText("攻击力：")
					lab1 = ptr_cast(ui.desc2:GetChildByIndex(4))
					lab1.Text = lang:GetText("攻击力：")
					local percent = (data.from.performance.damange + data.from.performance.damange_add) / (rpc_date_object_1[1].performance.damange + rpc_date_object_1[1].performance.damange_add) - 1
					if percent > 0 then
						lab.TextColor = ARGB(255, 0, 255, 63)
						ui.ctrl_demage2.TextColor = ARGB(255, 0, 255, 63)
						ui.ctrl_demage2.Text = string.format("+%.0f%%", percent * 100)
					elseif percent == 0 then
						lab.TextColor = ARGB(255, 213, 255, 254)
						ui.ctrl_demage2.TextColor = ARGB(255, 213, 255, 254)
						ui.ctrl_demage2.Text = "0%"
					else
						lab.TextColor = ARGB(255, 255, 0, 0)
						ui.ctrl_demage2.TextColor = ARGB(255, 255, 0, 0)
						ui.ctrl_demage2.Text = string.format("-%.0f%%", percent * (-100))
					end
					percent = (data.to.performance.damange + data.to.performance.damange_add) / (rpc_date_object_1[2].performance.damange + rpc_date_object_1[2].performance.damange_add) - 1
					if percent > 0 then
						lab1.TextColor = ARGB(255, 0, 255, 63)
						ui.ctrl_demage4.TextColor = ARGB(255, 0, 255, 63)
						ui.ctrl_demage4.Text = string.format("+%.0f%%", percent * 100)
					elseif percent == 0 then
						lab1.TextColor = ARGB(255, 213, 255, 254)
						ui.ctrl_demage4.TextColor = ARGB(255, 213, 255, 254)
						ui.ctrl_demage4.Text = "0%"
					else
						lab1.TextColor = ARGB(255, 255, 0, 0)
						ui.ctrl_demage4.TextColor = ARGB(255, 255, 0, 0)
						ui.ctrl_demage4.Text = string.format("-%.0f%%", percent * (-100))
					end
					local pow = math.floor((data.from.performance.damange + data.from.performance.damange_add) * 10 ) / 10
					if data.from.wid == 4 then
						pow = pow * 3
					end
					local temp = (pow - (pow % 50)) / 50 + 1
					if temp > 1 then
						ui.star2.Visible = true
						local con = ptr_cast(ui.star2:GetChildByIndex(1))
						con.Text = " x  "..(temp - 1)
					else
						ui.star2.Visible = false
					end
					if pow % 50 == 0 then
						temp = temp - 1
						ui.compare_demage3.Icon = compareIcon2[temp]
						ui.compare_demage3:ResetBaseValue(100)
					else
						if temp > 7 then
							temp = 7
						end
						ui.compare_demage3.Icon = compareIcon2[temp]
						ui.compare_demage3:ResetBaseValue(pow % 50 * 2)
					end
					ui.compare_demage3.Visible = true
					pow = math.floor((data.to.performance.damange + data.to.performance.damange_add) * 10 ) / 10
					if data.to.wid == 4 then
						pow = pow * 3
					end
					temp = (pow - (pow % 50)) / 50 + 1
					if temp > 1 then
						ui.star4.Visible = true
						local con = ptr_cast(ui.star4:GetChildByIndex(1))
						con.Text = " x  "..(temp - 1)
					else
						ui.star4.Visible = false
					end
					if pow % 50 == 0 then
						temp = temp - 1
						ui.compare_demage5.Icon = compareIcon2[temp + 7]
						ui.compare_demage5:ResetBaseValue(100)
					else
						if temp > 7 then
							temp = 7
						end
						ui.compare_demage5.Icon = compareIcon2[temp + 7]
						ui.compare_demage5:ResetBaseValue(pow % 50 * 2)
					end
					
					ui.compare_demage5.Visible = true
					lab = ptr_cast(ui.desc1:GetChildByIndex(6))
					lab.Text = lang:GetText("攻击速度")..lang:GetText("：")
					lab1 = ptr_cast(ui.desc2:GetChildByIndex(6))
					lab1.Text = lang:GetText("攻击速度")..lang:GetText("：")
					percent = (data.from.performance.speed + data.from.performance.speed_add) / (rpc_date_object_1[1].performance.speed + rpc_date_object_1[1].performance.speed_add) - 1
					if percent > 0 then
						lab.TextColor = ARGB(255, 0, 255, 63)
						ui.ctrl_demage3.TextColor = ARGB(255, 0, 255, 63)
						ui.ctrl_demage3.Text = string.format("+%.0f%%", percent * 100)
					elseif percent == 0 then
						lab.TextColor = ARGB(255, 213, 255, 254)
						ui.ctrl_demage3.TextColor = ARGB(255, 213, 255, 254)
						ui.ctrl_demage3.Text = "0%"
					else
						lab.TextColor = ARGB(255, 255, 0, 0)
						ui.ctrl_demage3.TextColor = ARGB(255, 255, 0, 0)
						ui.ctrl_demage3.Text = string.format("-%.0f%%", percent * (-100))
					end
					percent = (data.to.performance.speed + data.to.performance.speed_add) / (rpc_date_object_1[2].performance.speed + rpc_date_object_1[2].performance.speed_add) - 1
					if percent > 0 then
						lab1.TextColor = ARGB(255, 0, 255, 63)
						ui.ctrl_demage5.TextColor = ARGB(255, 0, 255, 63)
						ui.ctrl_demage5.Text = string.format("+%.0f%%", percent * 100)
					elseif percent == 0 then
						lab1.TextColor = ARGB(255, 213, 255, 254)
						ui.ctrl_demage5.TextColor = ARGB(255, 213, 255, 254)
						ui.ctrl_demage5.Text = "0%"
					else
						lab1.TextColor = ARGB(255, 255, 0, 0)
						ui.ctrl_demage5.TextColor = ARGB(255, 255, 0, 0)
						ui.ctrl_demage5.Text = string.format("-%.0f%%", percent * (-100))
					end
					local speed = math.floor((data.from.performance.speed + data.from.performance.speed_add) * 10 ) / 10
					temp = (speed - (speed % 50)) / 50 + 1
					if temp > 1 then
						ui.star3.Visible = true
						local con = ptr_cast(ui.star3:GetChildByIndex(1))
						con.Text = " x  "..(temp - 1)
					else
						ui.star3.Visible = false
					end
					if speed % 50 == 0 then
						temp = temp - 1
						ui.compare_demage4.Icon = compareIcon2[temp + 14]
						ui.compare_demage4:ResetBaseValue(100)
					else
						if temp > 7 then
							temp = 7
						end
						ui.compare_demage4.Icon = compareIcon2[temp + 14]
						ui.compare_demage4:ResetBaseValue(speed % 50 * 2)
					end
					
					ui.compare_demage4.Visible = true
					speed = math.floor((data.to.performance.speed + data.to.performance.speed_add) * 10 ) / 10
					temp = (speed - (speed % 50)) / 50 + 1
					if temp > 1 then
						ui.star5.Visible = true
						local con = ptr_cast(ui.star5:GetChildByIndex(1))
						con.Text = " x  "..(temp - 1)
					else
						ui.star5.Visible = false
					end
					if speed % 50 == 0 then
						temp = temp - 1
						ui.compare_demage6.Icon = compareIcon2[temp + 21]
						ui.compare_demage6:ResetBaseValue(100)
					else
						if temp > 7 then
							temp = 7
						end
						ui.compare_demage6.Icon = compareIcon2[temp + 21]
						ui.compare_demage6:ResetBaseValue(speed % 50 * 2)
					end
					
					ui.compare_demage6.Visible = true
					lab = ptr_cast(ui.desc1:GetChildByIndex(8))
					lab.Text = lang:GetText("开放的可钻孔数：")..rpc_date_object_1[1].common.holeNum.." → "..data.from.common.holeNum
					lab1 = ptr_cast(ui.desc2:GetChildByIndex(8))
					lab1.Text = lang:GetText("开放的可钻孔数：")..rpc_date_object_1[2].common.holeNum.." → "..data.to.common.holeNum
					if data.from.common.holeNum > rpc_date_object_1[1].common.holeNum then
						lab.TextColor = ARGB(255, 0, 255, 63)
					elseif data.from.common.holeNum == rpc_date_object_1[1].common.holeNum then
						lab.TextColor = ARGB(255, 213, 255, 254)
					else
						lab.TextColor = ARGB(255, 255, 0, 0)
					end
					if data.to.common.holeNum > rpc_date_object_1[2].common.holeNum then
						lab1.TextColor = ARGB(255, 0, 255, 63)
					elseif data.to.common.holeNum == rpc_date_object_1[2].common.holeNum then
						lab1.TextColor = ARGB(255, 213, 255, 254)
					else
						lab1.TextColor = ARGB(255, 255, 0, 0)
					end
					lab = ptr_cast(ui.desc1:GetChildByIndex(7))
					lab.Text = ""
					lab1 = ptr_cast(ui.desc2:GetChildByIndex(7))
					lab1.Text = ""
					lab = ptr_cast(ui.desc1:GetChildByIndex(5))
					lab.Text = ""
					lab1 = ptr_cast(ui.desc2:GetChildByIndex(5))
					lab1.Text = ""
					lab = ptr_cast(ui.desc1:GetChildByIndex(9))
					lab.Text = ""
					lab1 = ptr_cast(ui.desc2:GetChildByIndex(9))
					lab1.Text = ""
				else
					ui.star2.Visible = false
					ui.compare_demage3.Visible = false
					ui.star3.Visible = false
					ui.compare_demage4.Visible = false
					ui.star4.Visible = false
					ui.compare_demage5.Visible = false
					ui.star5.Visible = false
					ui.compare_demage6.Visible = false
					ui.ctrl_demage2.Visible = false
					ui.ctrl_demage3.Visible = false
					ui.ctrl_demage4.Visible = false
					ui.ctrl_demage5.Visible = false
					lab = ptr_cast(ui.desc1:GetChildByIndex(4))
					lab.Text = lang:GetText("开放的可钻孔数：")..rpc_date_object_1[1].common.holeNum.." → "..data.from.common.holeNum
					lab1 = ptr_cast(ui.desc2:GetChildByIndex(4))
					lab1.Text = lang:GetText("开放的可钻孔数：")..rpc_date_object_1[2].common.holeNum.." → "..data.to.common.holeNum
					if data.from.common.holeNum > rpc_date_object_1[1].common.holeNum then
						lab.TextColor = ARGB(255, 0, 255, 63)
					elseif data.from.common.holeNum == rpc_date_object_1[1].common.holeNum then
						lab.TextColor = ARGB(255, 213, 255, 254)
					else
						lab.TextColor = ARGB(255, 255, 0, 0)
					end
					if data.to.common.holeNum > rpc_date_object_1[2].common.holeNum then
						lab1.TextColor = ARGB(255, 0, 255, 63)
					elseif data.to.common.holeNum == rpc_date_object_1[2].common.holeNum then
						lab1.TextColor = ARGB(255, 213, 255, 254)
					else
						lab1.TextColor = ARGB(255, 255, 0, 0)
					end
					lab = ptr_cast(ui.desc1:GetChildByIndex(5))
					lab.Text = lang:GetText("火焰抗性").." "..precision(rpc_date_object_1[1].common.cResistanceFire + rpc_date_object_1[1].common.cResistanceFire_add).."% → "..precision(data.from.common.cResistanceFire + data.from.common.cResistanceFire_add).."%"
					lab1 = ptr_cast(ui.desc2:GetChildByIndex(5))
					lab1.Text = lang:GetText("火焰抗性").." "..precision(rpc_date_object_1[2].common.cResistanceFire + rpc_date_object_1[2].common.cResistanceFire_add).."% → "..precision(data.to.common.cResistanceFire + data.to.common.cResistanceFire_add).."%"
					if data.from.common.cResistanceFire_add > rpc_date_object_1[1].common.cResistanceFire_add then
						lab.TextColor = ARGB(255, 0, 255, 63)
					elseif data.from.common.cResistanceFire_add == rpc_date_object_1[1].common.cResistanceFire_add then
						lab.TextColor = ARGB(255, 213, 255, 254)
					else
						lab.TextColor = ARGB(255, 255, 0, 0)
					end
					if data.to.common.cResistanceFire_add > rpc_date_object_1[2].common.cResistanceFire_add then
						lab1.TextColor = ARGB(255, 0, 255, 63)
					elseif data.to.common.cResistanceFire_add == rpc_date_object_1[2].common.cResistanceFire_add then
						lab1.TextColor = ARGB(255, 213, 255, 254)
					else
						lab1.TextColor = ARGB(255, 255, 0, 0)
					end
					lab = ptr_cast(ui.desc1:GetChildByIndex(6))
					lab.Text = lang:GetText("爆炸抗性").." "..precision(rpc_date_object_1[1].common.cResistanceBlast + rpc_date_object_1[1].common.cResistanceBlast_add).."% → "..precision(data.from.common.cResistanceBlast + data.from.common.cResistanceBlast_add).."%"
					lab1 = ptr_cast(ui.desc2:GetChildByIndex(6))
					lab1.Text = lang:GetText("爆炸抗性").." "..precision(rpc_date_object_1[2].common.cResistanceBlast + rpc_date_object_1[2].common.cResistanceBlast_add).."% → "..precision(data.to.common.cResistanceBlast + data.to.common.cResistanceBlast_add).."%"
					if data.from.common.cResistanceBlast_add > rpc_date_object_1[1].common.cResistanceBlast_add then
						lab.TextColor = ARGB(255, 0, 255, 63)
					elseif data.from.common.cResistanceBlast_add == rpc_date_object_1[1].common.cResistanceBlast_add then
						lab.TextColor = ARGB(255, 213, 255, 254)
					else
						lab.TextColor = ARGB(255, 255, 0, 0)
					end
					if data.to.common.cResistanceBlast_add > rpc_date_object_1[2].common.cResistanceBlast_add then
						lab1.TextColor = ARGB(255, 0, 255, 63)
					elseif data.to.common.cResistanceBlast_add == rpc_date_object_1[2].common.cResistanceBlast_add then
						lab1.TextColor = ARGB(255, 213, 255, 254)
					else
						lab1.TextColor = ARGB(255, 255, 0, 0)
					end
					lab = ptr_cast(ui.desc1:GetChildByIndex(7))
					lab.Text = lang:GetText("子弹抗性").." "..precision(rpc_date_object_1[1].common.cResistanceBullet + rpc_date_object_1[1].common.cResistanceBullet_add).."% → "..precision(data.from.common.cResistanceBullet + data.from.common.cResistanceBullet_add).."%"
					lab1 = ptr_cast(ui.desc2:GetChildByIndex(7))
					lab1.Text = lang:GetText("子弹抗性").." "..precision(rpc_date_object_1[2].common.cResistanceBullet + rpc_date_object_1[2].common.cResistanceBullet_add).."% → "..precision(data.to.common.cResistanceBullet + data.to.common.cResistanceBullet_add).."%"
					if data.from.common.cResistanceBullet_add > rpc_date_object_1[1].common.cResistanceBullet_add then
						lab.TextColor = ARGB(255, 0, 255, 63)
					elseif data.from.common.cResistanceBullet_add == rpc_date_object_1[1].common.cResistanceBullet_add then
						lab.TextColor = ARGB(255, 213, 255, 254)
					else
						lab.TextColor = ARGB(255, 255, 0, 0)
					end
					if data.to.common.cResistanceBullet_add > rpc_date_object_1[2].common.cResistanceBullet_add then
						lab1.TextColor = ARGB(255, 0, 255, 63)
					elseif data.to.common.cResistanceBullet_add == rpc_date_object_1[2].common.cResistanceBullet_add then
						lab1.TextColor = ARGB(255, 213, 255, 254)
					else
						lab1.TextColor = ARGB(255, 255, 0, 0)
					end
					lab = ptr_cast(ui.desc1:GetChildByIndex(8))
					lab.Text = lang:GetText("近身抗性").." "..precision(rpc_date_object_1[1].common.cResistanceKnife + rpc_date_object_1[1].common.cResistanceKnife_add).."% → "..precision(data.from.common.cResistanceKnife + data.from.common.cResistanceKnife_add).."%"
					lab1 = ptr_cast(ui.desc2:GetChildByIndex(8))
					lab1.Text = lang:GetText("近身抗性").." "..precision(rpc_date_object_1[2].common.cResistanceKnife + rpc_date_object_1[2].common.cResistanceKnife_add).."% → "..precision(data.to.common.cResistanceKnife + data.to.common.cResistanceKnife_add).."%"
					if data.from.common.cResistanceKnife_add > rpc_date_object_1[1].common.cResistanceKnife_add then
						lab.TextColor = ARGB(255, 0, 255, 63)
					elseif data.from.common.cResistanceKnife_add == rpc_date_object_1[1].common.cResistanceKnife_add then
						lab.TextColor = ARGB(255, 213, 255, 254)
					else
						lab.TextColor = ARGB(255, 255, 0, 0)
					end
					if data.to.common.cResistanceKnife_add > rpc_date_object_1[2].common.cResistanceKnife_add then
						lab1.TextColor = ARGB(255, 0, 255, 63)
					elseif data.to.common.cResistanceKnife_add == rpc_date_object_1[2].common.cResistanceKnife_add then
						lab1.TextColor = ARGB(255, 213, 255, 254)
					else
						lab1.TextColor = ARGB(255, 255, 0, 0)
					end
					lab = ptr_cast(ui.desc1:GetChildByIndex(9))
					lab.Text = lang:GetText("增加血量").." "..precision(rpc_date_object_1[1].common.cBloodAdd + rpc_date_object_1[1].common.cBloodAdd_add).."% → "..precision(data.from.common.cBloodAdd + data.from.common.cBloodAdd_add).."%"
					lab1 = ptr_cast(ui.desc2:GetChildByIndex(9))
					lab1.Text = lang:GetText("增加血量").." "..precision(rpc_date_object_1[2].common.cBloodAdd + rpc_date_object_1[2].common.cBloodAdd_add).."% → "..precision(data.to.common.cBloodAdd + data.to.common.cBloodAdd_add).."%"
					if data.from.common.cBloodAdd_add > rpc_date_object_1[1].common.cBloodAdd_add then
						lab.TextColor = ARGB(255, 0, 255, 63)
					elseif data.from.common.cBloodAdd_add == rpc_date_object_1[1].common.cBloodAdd_add then
						lab.TextColor = ARGB(255, 213, 255, 254)
					else
						lab.TextColor = ARGB(255, 255, 0, 0)
					end
					if data.to.common.cBloodAdd_add > rpc_date_object_1[2].common.cBloodAdd_add then
						lab1.TextColor = ARGB(255, 0, 255, 63)
					elseif data.to.common.cBloodAdd_add == rpc_date_object_1[2].common.cBloodAdd_add then
						lab1.TextColor = ARGB(255, 213, 255, 254)
					else
						lab1.TextColor = ARGB(255, 255, 0, 0)
					end
				end
			end)
		end

	elseif ui.object2.ItemIcon == nil and ui.object3.ItemIcon then
		ui.Help_part5.Visible = false
		ui.ctrl_demage2.Visible = false
		ui.ctrl_demage3.Visible = false
		ui.ctrl_demage4.Visible = false
		ui.ctrl_demage5.Visible = false
		ui.left_3.Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_ico_03_normal.dds", Vector4(0, 0, 0, 0)),
		}
		ui.right_3.Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_ico_03_b_down.dds", Vector4(0, 0, 0, 0)),
		}
		ui.main_3.Visible = true
		local lab = ptr_cast(ui.main_3:GetChildByIndex(0))
		lab.Text = lang:GetText("当前装备属性")
		ui.desc1.Visible = false
		ui.compare_demage3.Visible = false
		ui.star2.Visible = false
		ui.compare_demage4.Visible = false
		ui.star3.Visible = false
		ui.desc2.Visible = true
		if rpc_date_object_1[2].common.type == 1 then
			local lab = ptr_cast(ui.desc2:GetChildByIndex(0))
			lab.Text = lang:GetText("耐久值：")..rpc_date_object_1[2].common.durable
			lab.TextColor = ARGB(255, 213, 255, 254)
			lab = ptr_cast(ui.desc2:GetChildByIndex(1))
			lab.Text = lang:GetText("战斗力：")..rpc_date_object_1[2].common.star
			lab.TextColor = ARGB(255, 213, 255, 254)
			lab = ptr_cast(ui.desc2:GetChildByIndex(2))
			lab.Text = lang:GetText("强化等级：")..rpc_date_object_1[2].common.strength
			lab.TextColor = ARGB(255, 213, 255, 254)
			lab = ptr_cast(ui.desc2:GetChildByIndex(3))
			if rpc_date_object_1[2].isBind == "Y" then
				lab.Text = lang:GetText("绑定状态： 绑定")
			elseif rpc_date_object_1[2].isBind == "N" then
				lab.Text = lang:GetText("绑定状态： 未绑定")
			end
			lab = ptr_cast(ui.desc2:GetChildByIndex(4))
			lab.Text = lang:GetText("攻击力：")
			lab.TextColor = ARGB(255, 213, 255, 254)
			local pow = math.floor((rpc_date_object_1[2].performance.damange + rpc_date_object_1[2].performance.damange_add) * 10 ) / 10
			if rpc_date_object_1[2].wid == 4 then
				pow = pow * 3
			end
			local temp = (pow - (pow % 50)) / 50 + 1
			if temp > 1 then
				ui.star4.Visible = true
				local con = ptr_cast(ui.star4:GetChildByIndex(1))
				con.Text = " x  "..(temp - 1)
			else
				ui.star4.Visible = false
			end
			if pow % 50 == 0 then
				temp = temp - 1
				ui.compare_demage5.Icon = compareIcon2[temp]
				ui.compare_demage5:ResetBaseValue(100)
			else
				if temp > 7 then
					temp = 7
				end
				ui.compare_demage5.Icon = compareIcon2[temp]
				ui.compare_demage5:ResetBaseValue(pow % 50 * 2)
			end
			ui.compare_demage5.Visible = true
			
			lab = ptr_cast(ui.desc2:GetChildByIndex(6))
			lab.Text = lang:GetText("攻击速度")..lang:GetText("：")
			lab.TextColor = ARGB(255, 213, 255, 254)
			local speed = math.floor((rpc_date_object_1[2].performance.speed + rpc_date_object_1[2].performance.speed_add) * 10 ) / 10
			temp = (speed - (speed % 50)) / 50 + 1
			if temp > 1 then
				ui.star5.Visible = true
				local con = ptr_cast(ui.star5:GetChildByIndex(1))
				con.Text = " x  "..(temp - 1)
			else
				ui.star5.Visible = false
			end
			if speed % 50 == 0 then
				temp = temp - 1
				ui.compare_demage6.Icon = compareIcon2[temp + 7]
				ui.compare_demage6:ResetBaseValue(100)
			else
				if temp > 7 then
					temp = 7
				end
				ui.compare_demage6.Icon = compareIcon2[temp + 7]
				ui.compare_demage6:ResetBaseValue(speed % 50 * 2)
			end
			ui.compare_demage6.Visible = true
			
			lab = ptr_cast(ui.desc2:GetChildByIndex(8))
			lab.Text = lang:GetText("开放的可钻孔数：")..rpc_date_object_1[2].common.holeNum
			lab.TextColor = ARGB(255, 213, 255, 254)
			lab = ptr_cast(ui.desc2:GetChildByIndex(7))
			lab.Text = ""
			lab = ptr_cast(ui.desc2:GetChildByIndex(5))
			lab.Text = ""
			lab = ptr_cast(ui.desc2:GetChildByIndex(9))
			lab.Text = ""
		else
			ui.compare_demage5.Visible = false
			ui.star4.Visible = false
			ui.compare_demage6.Visible = false
			ui.star5.Visible = false
			local lab = ptr_cast(ui.desc2:GetChildByIndex(0))
			lab.Text = lang:GetText("耐久值：")..rpc_date_object_1[2].common.durable
			lab.TextColor = ARGB(255, 213, 255, 254)
			lab = ptr_cast(ui.desc2:GetChildByIndex(1))
			lab.Text = lang:GetText("战斗力：")..rpc_date_object_1[2].common.star
			lab.TextColor = ARGB(255, 213, 255, 254)
			lab = ptr_cast(ui.desc2:GetChildByIndex(2))
			lab.Text = lang:GetText("强化等级：")..rpc_date_object_1[2].common.strength
			lab.TextColor = ARGB(255, 213, 255, 254)
			lab = ptr_cast(ui.desc2:GetChildByIndex(3))
			if rpc_date_object_1[2].isBind == "Y" then
				lab.Text = lang:GetText("绑定状态： 绑定")
			elseif rpc_date_object_1[2].isBind == "N" then
				lab.Text = lang:GetText("绑定状态： 未绑定")
			end
			lab = ptr_cast(ui.desc2:GetChildByIndex(4))
			lab.Text = lang:GetText("开放的可钻孔数：")..rpc_date_object_1[2].common.holeNum
			lab.TextColor = ARGB(255, 213, 255, 254)
			lab = ptr_cast(ui.desc2:GetChildByIndex(5))
			lab.Text = lang:GetText("火焰抗性").." "..precision(rpc_date_object_1[2].common.cResistanceFire + rpc_date_object_1[2].common.cResistanceFire_add).."%"
			lab.TextColor = ARGB(255, 213, 255, 254)
			lab = ptr_cast(ui.desc2:GetChildByIndex(6))
			lab.Text = lang:GetText("爆炸抗性").." "..precision(rpc_date_object_1[2].common.cResistanceBlast + rpc_date_object_1[2].common.cResistanceBlast_add).."%"
			lab.TextColor = ARGB(255, 213, 255, 254)
			lab = ptr_cast(ui.desc2:GetChildByIndex(7))
			lab.Text = lang:GetText("子弹抗性").." "..precision(rpc_date_object_1[2].common.cResistanceBullet + rpc_date_object_1[2].common.cResistanceBullet_add).."%"
			lab.TextColor = ARGB(255, 213, 255, 254)
			lab = ptr_cast(ui.desc2:GetChildByIndex(8))
			lab.Text = lang:GetText("近身抗性").." "..precision(rpc_date_object_1[2].common.cResistanceKnife + rpc_date_object_1[2].common.cResistanceKnife_add).."%"
			lab.TextColor = ARGB(255, 213, 255, 254)
			lab = ptr_cast(ui.desc2:GetChildByIndex(9))
			lab.Text = lang:GetText("增加血量").." "..precision(rpc_date_object_1[2].common.cBloodAdd + rpc_date_object_1[2].common.cBloodAdd_add).."%"
			lab.TextColor = ARGB(255, 213, 255, 254)
		end
	elseif ui.object2.ItemIcon and ui.object3.ItemIcon == nil then
		ui.Help_part5.Visible = false
		ui.ctrl_demage2.Visible = false
		ui.ctrl_demage3.Visible = false
		ui.ctrl_demage4.Visible = false
		ui.ctrl_demage5.Visible = false
		ui.left_3.Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_ico_03_down.dds", Vector4(0, 0, 0, 0)),
		}
		ui.right_3.Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_ico_03_b_normal.dds", Vector4(0, 0, 0, 0)),
		}
		ui.main_3.Visible = true
		local lab = ptr_cast(ui.main_3:GetChildByIndex(0))
		lab.Text = lang:GetText("当前装备属性")
		ui.desc1.Visible = true
		ui.desc2.Visible = false
		ui.compare_demage5.Visible = false
		ui.star4.Visible = false
		ui.compare_demage6.Visible = false
		ui.star5.Visible = false
		if rpc_date_object_1[1].common.type == 1 then
			local lab = ptr_cast(ui.desc1:GetChildByIndex(0))
			lab.Text = lang:GetText("耐久值：")..rpc_date_object_1[1].common.durable
			lab.TextColor = ARGB(255, 213, 255, 254)
			lab = ptr_cast(ui.desc1:GetChildByIndex(1))
			lab.Text = lang:GetText("战斗力：")..rpc_date_object_1[1].common.star
			lab.TextColor = ARGB(255, 213, 255, 254)
			lab = ptr_cast(ui.desc1:GetChildByIndex(2))
			lab.Text = lang:GetText("强化等级：")..rpc_date_object_1[1].common.strength
			lab.TextColor = ARGB(255, 213, 255, 254)
			lab = ptr_cast(ui.desc1:GetChildByIndex(3))
			if rpc_date_object_1[1].isBind == "Y" then
				lab.Text = lang:GetText("绑定状态： 绑定")
			elseif rpc_date_object_1[1].isBind == "N" then
				lab.Text = lang:GetText("绑定状态： 未绑定")
			end
			lab = ptr_cast(ui.desc1:GetChildByIndex(4))
			lab.Text = lang:GetText("攻击力：")
			lab.TextColor = ARGB(255, 213, 255, 254)
			local pow = math.floor((rpc_date_object_1[1].performance.damange + rpc_date_object_1[1].performance.damange_add) * 10 ) / 10
			if rpc_date_object_1[1].wid == 4 then
				pow = pow * 3
			end
			local temp = (pow - (pow % 50)) / 50 + 1
			if temp > 1 then
				ui.star2.Visible = true
				local con = ptr_cast(ui.star2:GetChildByIndex(1))
				con.Text = " x  "..(temp - 1)
			else
				ui.star2.Visible = false
			end
			if pow % 50 == 0 then
				temp = temp - 1
				ui.compare_demage3.Icon = compareIcon2[temp]
				ui.compare_demage3:ResetBaseValue(100)
			else
				if temp > 7 then
					temp = 7
				end
				ui.compare_demage3.Icon = compareIcon2[temp]
				ui.compare_demage3:ResetBaseValue(pow % 50 * 2)
			end
			ui.compare_demage3.Visible = true
			
			lab = ptr_cast(ui.desc1:GetChildByIndex(6))
			lab.Text = lang:GetText("攻击速度")..lang:GetText("：")
			lab.TextColor = ARGB(255, 213, 255, 254)
			local speed = math.floor((rpc_date_object_1[1].performance.speed + rpc_date_object_1[1].performance.speed_add) * 10 ) / 10
			temp = (speed - (speed % 50)) / 50 + 1
			if temp > 1 then
				ui.star3.Visible = true
				local con = ptr_cast(ui.star3:GetChildByIndex(1))
				con.Text = " x  "..(temp - 1)
			else
				ui.star3.Visible = false
			end
			if speed % 50 == 0 then
				temp = temp - 1
				ui.compare_demage4.Icon = compareIcon2[temp + 7]
				ui.compare_demage4:ResetBaseValue(100)
			else
				if temp > 7 then
					temp = 7
				end
				ui.compare_demage4.Icon = compareIcon2[temp + 7]
				ui.compare_demage4:ResetBaseValue(speed % 50 * 2)
			end
			ui.compare_demage4.Visible = true
			
			lab = ptr_cast(ui.desc1:GetChildByIndex(8))
			lab.Text = lang:GetText("开放的可钻孔数：")..rpc_date_object_1[1].common.holeNum
			lab.TextColor = ARGB(255, 213, 255, 254)
			lab = ptr_cast(ui.desc1:GetChildByIndex(7))
			lab.Text = ""
			lab = ptr_cast(ui.desc1:GetChildByIndex(5))
			lab.Text = ""
			lab = ptr_cast(ui.desc1:GetChildByIndex(9))
			lab.Text = ""
		else
			ui.compare_demage3.Visible = false
			ui.star2.Visible = false
			ui.compare_demage4.Visible = false
			ui.star3.Visible = false
			local lab = ptr_cast(ui.desc1:GetChildByIndex(0))
			lab.Text = lang:GetText("耐久值：")..rpc_date_object_1[1].common.durable
			lab.TextColor = ARGB(255, 213, 255, 254)
			lab = ptr_cast(ui.desc1:GetChildByIndex(1))
			lab.Text = lang:GetText("战斗力：")..rpc_date_object_1[1].common.star
			lab.TextColor = ARGB(255, 213, 255, 254)
			lab = ptr_cast(ui.desc1:GetChildByIndex(2))
			lab.Text = lang:GetText("强化等级：")..rpc_date_object_1[1].common.strength
			lab.TextColor = ARGB(255, 213, 255, 254)
			lab = ptr_cast(ui.desc1:GetChildByIndex(3))
			if rpc_date_object_1[1].isBind == "Y" then
				lab.Text = lang:GetText("绑定状态： 绑定")
			elseif rpc_date_object_1[1].isBind == "N" then
				lab.Text = lang:GetText("绑定状态： 未绑定")
			end
			lab = ptr_cast(ui.desc1:GetChildByIndex(4))
			lab.Text = lang:GetText("开放的可钻孔数：")..rpc_date_object_1[1].common.holeNum
			lab.TextColor = ARGB(255, 213, 255, 254)
			lab = ptr_cast(ui.desc1:GetChildByIndex(5))
			lab.Text = lang:GetText("火焰抗性").." "..precision(rpc_date_object_1[1].common.cResistanceFire + rpc_date_object_1[1].common.cResistanceFire_add).."%"
			lab.TextColor = ARGB(255, 213, 255, 254)
			lab = ptr_cast(ui.desc1:GetChildByIndex(6))
			lab.Text = lang:GetText("爆炸抗性").." "..precision(rpc_date_object_1[1].common.cResistanceBlast + rpc_date_object_1[1].common.cResistanceBlast_add).."%"
			lab.TextColor = ARGB(255, 213, 255, 254)
			lab = ptr_cast(ui.desc1:GetChildByIndex(7))
			lab.Text = lang:GetText("子弹抗性").." "..precision(rpc_date_object_1[1].common.cResistanceBullet + rpc_date_object_1[1].common.cResistanceBullet_add).."%"
			lab.TextColor = ARGB(255, 213, 255, 254)
			lab = ptr_cast(ui.desc1:GetChildByIndex(8))
			lab.Text = lang:GetText("近身抗性").." "..precision(rpc_date_object_1[1].common.cResistanceKnife + rpc_date_object_1[1].common.cResistanceKnife_add).."%"
			lab.TextColor = ARGB(255, 213, 255, 254)
			lab = ptr_cast(ui.desc1:GetChildByIndex(9))
			lab.Text = lang:GetText("增加血量").." "..precision(rpc_date_object_1[1].common.cBloodAdd + rpc_date_object_1[1].common.cBloodAdd_add).."%"
			lab.TextColor = ARGB(255, 213, 255, 254)
		end
	else
		ui.Help_part5.Visible = false
		ui.left_3.Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_ico_03_normal.dds", Vector4(0, 0, 0, 0)),
		}
		ui.right_3.Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_ico_03_b_normal.dds", Vector4(0, 0, 0, 0)),
		}
		ui.main_3.Visible = false
		ui.zhuanghuan_xingji_tips.Visible = false
	end
	Fill_Help()
end

function FillMachine2_end()
	if rpc_date_object_1[1].color > 0 and rpc_date_object_1[1].color < 8 then
		ui.object2.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..rpc_date_object_1[1].name.."_"..rpc_date_object_1[1].color..".tga")
	else
		ui.object2.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..rpc_date_object_1[1].name..".tga")
	end
	local ibbtn = ptr_cast(ui.object2:GetChildByIndex(2))
	if rpc_date_object_1[1].common.strength > 0 then
		ibbtn.Visible = true
		ibbtn.Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/badge_lv"..rpc_date_object_1[1].common.strength.."_small.dds", Vector4(0, 0, 0, 0)),
		}
	else
		ibbtn.Visible = false
	end
	
	local ibbtn = ptr_cast(ui.object2:GetChildByIndex(3))
	if rpc_date_object_1[1].gstLevel > 0 then
		ibbtn.Visible = true
		ibbtn.Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/Compose/shengxing/lb_synthesis_conversion_star_0"..rpc_date_object_1[1].gstLevel..".dds", Vector4(0, 0, 0, 0)),
		}
	else
		ibbtn.Visible = false
	end
	
	if rpc_date_object_1[2].color > 0 and rpc_date_object_1[2].color < 8 then
		ui.object3.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..rpc_date_object_1[2].name.."_"..rpc_date_object_1[2].color..".tga")
	else
		ui.object3.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..rpc_date_object_1[2].name..".tga")
	end
	local ibbtn = ptr_cast(ui.object3:GetChildByIndex(2))
	if rpc_date_object_1[2].common.strength > 0 then
		ibbtn.Visible = true
		ibbtn.Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/badge_lv"..rpc_date_object_1[2].common.strength.."_small.dds", Vector4(0, 0, 0, 0)),
		}
	else
		ibbtn.Visible = false
	end
	local ibbtn = ptr_cast(ui.object3:GetChildByIndex(3))
	if rpc_date_object_1[2].gstLevel > 0 then
		ibbtn.Visible = true
		ibbtn.Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/Compose/shengxing/lb_synthesis_conversion_star_0"..rpc_date_object_1[2].gstLevel..".dds", Vector4(0, 0, 0, 0)),
		}
	else
		ibbtn.Visible = false
	end
	local lab = ptr_cast(ui.main_3:GetChildByIndex(0))
	lab.Text = lang:GetText("当前装备属性")
	lab = ptr_cast(ui.desc1:GetChildByIndex(0))
	lab.Text = lang:GetText("耐久值：")..rpc_date_object_1[1].common.durable
	local lab1 = ptr_cast(ui.desc2:GetChildByIndex(0))
	lab1.Text = lang:GetText("耐久值：")..rpc_date_object_1[2].common.durable
	lab.TextColor = ARGB(255, 213, 255, 254)
	lab1.TextColor = ARGB(255, 213, 255, 254)
	lab = ptr_cast(ui.desc1:GetChildByIndex(1))
	lab.Text = lang:GetText("战斗力：")..rpc_date_object_1[1].common.star
	lab1 = ptr_cast(ui.desc2:GetChildByIndex(1))
	lab1.Text = lang:GetText("战斗力：")..rpc_date_object_1[2].common.star
	lab.TextColor = ARGB(255, 213, 255, 254)
	lab1.TextColor = ARGB(255, 213, 255, 254)
	lab = ptr_cast(ui.desc1:GetChildByIndex(2))
	lab.Text = lang:GetText("强化等级：")..rpc_date_object_1[1].common.strength
	lab1 = ptr_cast(ui.desc2:GetChildByIndex(2))
	lab1.Text = lang:GetText("强化等级：")..rpc_date_object_1[2].common.strength
	lab.TextColor = ARGB(255, 213, 255, 254)
	lab1.TextColor = ARGB(255, 213, 255, 254)
	lab = ptr_cast(ui.desc1:GetChildByIndex(3))
	if rpc_date_object_1[1].isBind == "Y" then
		lab.Text = lang:GetText("绑定状态： 绑定")
	elseif rpc_date_object_1[1].isBind == "N" then
		lab.Text = lang:GetText("绑定状态： 未绑定")
	end
	lab1 = ptr_cast(ui.desc2:GetChildByIndex(3))
	if rpc_date_object_1[2].isBind == "Y" then
		lab1.Text = lang:GetText("绑定状态： 绑定")
	elseif rpc_date_object_1[2].isBind == "N" then
		lab1.Text = lang:GetText("绑定状态： 未绑定")
	end
	ui.ctrl_demage2.Visible = false
	ui.ctrl_demage3.Visible = false
	ui.ctrl_demage4.Visible = false
	ui.ctrl_demage5.Visible = false
	if rpc_date_object_1[1].common.type == 1 then
		lab = ptr_cast(ui.desc1:GetChildByIndex(4))
		lab.Text = lang:GetText("攻击力：")
		lab1 = ptr_cast(ui.desc2:GetChildByIndex(4))
		lab1.Text = lang:GetText("攻击力：")
		lab.TextColor = ARGB(255, 213, 255, 254)
		lab1.TextColor = ARGB(255, 213, 255, 254)
		local pow = math.floor((rpc_date_object_1[1].performance.damange + rpc_date_object_1[1].performance.damange_add) * 10 ) / 10
		if rpc_date_object_1[1].wid == 4 then
			pow = pow * 3
		end
		local temp = (pow - (pow % 50)) / 50 + 1
		if temp > 1 then
			ui.star2.Visible = true
			local con = ptr_cast(ui.star2:GetChildByIndex(1))
			con.Text = " x  "..(temp - 1)
		else
			ui.star2.Visible = false
		end
		if pow % 50 == 0 then
			temp = temp - 1
			ui.compare_demage3.Icon = compareIcon2[temp]
			ui.compare_demage3:ResetBaseValue(100)
		else
			if temp > 7 then
				temp = 7
			end
			ui.compare_demage3.Icon = compareIcon2[temp]
			ui.compare_demage3:ResetBaseValue(pow % 50 * 2)
		end
		
		ui.compare_demage3.Visible = true
		pow = math.floor((rpc_date_object_1[2].performance.damange + rpc_date_object_1[2].performance.damange_add) * 10 ) / 10
		if rpc_date_object_1[2].wid == 4 then
			pow = pow * 3
		end
		temp = (pow - (pow % 50)) / 50 + 1
		if temp > 1 then
			ui.star4.Visible = true
			local con = ptr_cast(ui.star4:GetChildByIndex(1))
			con.Text = " x  "..(temp - 1)
		else
			ui.star4.Visible = false
		end
		if pow % 50 == 0 then
			temp = temp - 1
			ui.compare_demage5.Icon = compareIcon2[temp + 7]
			ui.compare_demage5:ResetBaseValue(100)
		else
			if temp > 7 then
				temp = 7
			end
			ui.compare_demage5.Icon = compareIcon2[temp + 7]
			ui.compare_demage5:ResetBaseValue(pow % 50 * 2)
		end
		ui.compare_demage5.Visible = true
		lab = ptr_cast(ui.desc1:GetChildByIndex(6))
		lab.Text = lang:GetText("攻击速度")..lang:GetText("：")
		lab1 = ptr_cast(ui.desc2:GetChildByIndex(6))
		lab1.Text = lang:GetText("攻击速度")..lang:GetText("：")
		lab.TextColor = ARGB(255, 213, 255, 254)
		lab1.TextColor = ARGB(255, 213, 255, 254)
		local speed = math.floor((rpc_date_object_1[1].performance.speed + rpc_date_object_1[1].performance.speed_add) * 10 ) / 10
		temp = (speed - (speed % 50)) / 50 + 1
		if temp > 1 then
			ui.star3.Visible = true
			local con = ptr_cast(ui.star3:GetChildByIndex(1))
			con.Text = " x  "..(temp - 1)
		else
			ui.star3.Visible = false
		end
		if speed % 50 == 0 then
			temp = temp - 1
			ui.compare_demage4.Icon = compareIcon2[temp + 14]
			ui.compare_demage4:ResetBaseValue(100)
		else
			if temp > 7 then
				temp = 7
			end
			ui.compare_demage4.Icon = compareIcon2[temp + 14]
			ui.compare_demage4:ResetBaseValue(speed % 50 * 2)
		end
		
		ui.compare_demage4.Visible = true
		speed = math.floor((rpc_date_object_1[2].performance.speed + rpc_date_object_1[2].performance.speed_add) * 10 ) / 10
		temp = (speed - (speed % 50)) / 50 + 1
		if temp > 1 then
			ui.star5.Visible = true
			local con = ptr_cast(ui.star5:GetChildByIndex(1))
			con.Text = " x  "..(temp - 1)
		else
			ui.star5.Visible = false
		end
		if speed % 50 == 0 then
			temp = temp - 1
			ui.compare_demage6.Icon = compareIcon2[temp + 21]
			ui.compare_demage6:ResetBaseValue(100)
		else
			if temp > 7 then
				temp = 7
			end
			ui.compare_demage6.Icon = compareIcon2[temp + 21]
			ui.compare_demage6:ResetBaseValue(speed % 50 * 2)
		end
		
		ui.compare_demage6.Visible = true
		lab = ptr_cast(ui.desc1:GetChildByIndex(8))
		lab.Text = lang:GetText("开放的可钻孔数：")..rpc_date_object_1[1].common.holeNum
		lab1 = ptr_cast(ui.desc2:GetChildByIndex(8))
		lab1.Text = lang:GetText("开放的可钻孔数：")..rpc_date_object_1[2].common.holeNum
		lab.TextColor = ARGB(255, 213, 255, 254)
		lab1.TextColor = ARGB(255, 213, 255, 254)
	else
		lab = ptr_cast(ui.desc1:GetChildByIndex(4))
		lab.Text = lang:GetText("开放的可钻孔数：")..rpc_date_object_1[1].common.holeNum
		lab1 = ptr_cast(ui.desc2:GetChildByIndex(4))
		lab1.Text = lang:GetText("开放的可钻孔数：")..rpc_date_object_1[2].common.holeNum
		lab.TextColor = ARGB(255, 213, 255, 254)
		lab1.TextColor = ARGB(255, 213, 255, 254)
		lab = ptr_cast(ui.desc1:GetChildByIndex(5))
		lab.Text = lang:GetText("火焰抗性").." "..precision(rpc_date_object_1[1].common.cResistanceFire + rpc_date_object_1[1].common.cResistanceFire_add).."%"
		lab1 = ptr_cast(ui.desc2:GetChildByIndex(5))
		lab1.Text = lang:GetText("火焰抗性").." "..precision(rpc_date_object_1[2].common.cResistanceFire + rpc_date_object_1[2].common.cResistanceFire_add).."%"
		lab.TextColor = ARGB(255, 213, 255, 254)
		lab1.TextColor = ARGB(255, 213, 255, 254)
		lab = ptr_cast(ui.desc1:GetChildByIndex(6))
		lab.Text = lang:GetText("爆炸抗性").." "..precision(rpc_date_object_1[1].common.cResistanceBlast + rpc_date_object_1[1].common.cResistanceBlast_add).."%"
		lab1 = ptr_cast(ui.desc2:GetChildByIndex(6))
		lab1.Text = lang:GetText("爆炸抗性").." "..precision(rpc_date_object_1[2].common.cResistanceBlast + rpc_date_object_1[2].common.cResistanceBlast_add).."%"
		lab.TextColor = ARGB(255, 213, 255, 254)
		lab1.TextColor = ARGB(255, 213, 255, 254)
		lab = ptr_cast(ui.desc1:GetChildByIndex(7))
		lab.Text = lang:GetText("子弹抗性").." "..precision(rpc_date_object_1[1].common.cResistanceBullet + rpc_date_object_1[1].common.cResistanceBullet_add).."%"
		lab1 = ptr_cast(ui.desc2:GetChildByIndex(7))
		lab1.Text = lang:GetText("子弹抗性").." "..precision(rpc_date_object_1[2].common.cResistanceBullet + rpc_date_object_1[2].common.cResistanceBullet_add).."%"
		lab.TextColor = ARGB(255, 213, 255, 254)
		lab1.TextColor = ARGB(255, 213, 255, 254)
		lab = ptr_cast(ui.desc1:GetChildByIndex(8))
		lab.Text = lang:GetText("近身抗性").." "..precision(rpc_date_object_1[1].common.cResistanceKnife + rpc_date_object_1[1].common.cResistanceKnife_add).."%"
		lab1 = ptr_cast(ui.desc2:GetChildByIndex(8))
		lab1.Text = lang:GetText("近身抗性").." "..precision(rpc_date_object_1[2].common.cResistanceKnife + rpc_date_object_1[2].common.cResistanceKnife_add).."%"
		lab.TextColor = ARGB(255, 213, 255, 254)
		lab1.TextColor = ARGB(255, 213, 255, 254)
		lab = ptr_cast(ui.desc1:GetChildByIndex(9))
		lab.Text = lang:GetText("增加血量").." "..precision(rpc_date_object_1[1].common.cBloodAdd + rpc_date_object_1[1].common.cBloodAdd_add).."%"
		lab1 = ptr_cast(ui.desc2:GetChildByIndex(9))
		lab1.Text = lang:GetText("增加血量").." "..precision(rpc_date_object_1[2].common.cBloodAdd + rpc_date_object_1[2].common.cBloodAdd_add).."%"
		lab.TextColor = ARGB(255, 213, 255, 254)
		lab1.TextColor = ARGB(255, 213, 255, 254)
	end
end

function FillMachine3(index)
	ui.Help_part5.Visible = false
	if index ~= 0 then
		if rpc_date[index] then
			local t_index = nil
			for i = 1, info.slotNum do
				if melting[i].index == -1 then
					t_index = i
					break
				end
			end
			if t_index == nil then
				return false
			end
			if rpc_date[index].color > 0 and rpc_date[index].color < 8 then
				ui["Item_btn_"..t_index].ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..rpc_date[index].name.."_"..rpc_date[index].color..".tga")
			else
				ui["Item_btn_"..t_index].ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..rpc_date[index].name..".tga")
			end
			melting[t_index].page = current_page
			melting[t_index].index = index
			melting[t_index].type = current_selected
			melting[t_index].cid = current_characters
			melting[t_index].pid = rpc_date[index].playeritemid
			melting[t_index].value = GetValue(rpc_date[index])
			melting[t_index].residual = rpc_date[index].common.evaluateRmb
			melting[t_index].sid = rpc_date[index].sid
		end
		if material_info_page.ctrl_ib_container.Parent == nil then
			gui:PlayAudio("kUIA_COMPOUND_PUT")
		else
			gui:PlayAudio("kUIA_COMPOUND_PUT_ITEM")
		end
	end

	if info then
		L_LobbyMain.ShowFightnums(ui.Level, info.meltingLevel)
		ui.Compare_1.Size = Vector2(200 * (info.exp / info.total_exp), 20)
		ui.lab_1.Text = info.exp.."/"..info.total_exp
			print("88888888888888888888888888888888",info.recycle_ratio)
			print("888888888888888888888888888888881111111",info.residual)
		residual_total = getresidual_total(info.residual,info.recycle_ratio)
		ui.Compare_2.Normsize = ui.Compare_2.Size
		ui.Compare_2:Clear()
		ui.Compare_2:InsertMovePoint(ui.Compare_2.Location,0.5,Vector2(262 * (residual_total / 120), 53),ARGB(255,255,255,255))
		for i = 1, info.slotNum do
			ui["Item_btn_"..i].Hint = nil
			ui["Item_btn_"..i].Skin = Gui.ItemBoxBtnSkin
			{
				NeutralNormalImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_slot.dds", Vector4(0, 0, 0, 0)),
				NeutralHoverImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_slot_flash_1.dds", Vector4(0, 0, 0, 0)),
				NeutralDisabledImage = Gui.Image("LobbyUI/Compose/lb_synthesis_mosaic_ico_01.dds", Vector4(0, 0, 0, 0)),
			}
		end

		for i = info.slotNum + 1, 9 do
			ui["Item_btn_"..i].Hint = lang:GetText("熔炼等级达到")..(i - 1)..lang:GetText("级时开放")
			ui["Item_btn_"..i].Skin = Gui.ItemBoxBtnSkin
			{
				NeutralNormalImage = Gui.Image("LobbyUI/Compose/lb_synthesis_mosaic_ico_01.dds", Vector4(0, 0, 0, 0)),
				NeutralHoverImage = Gui.Image("LobbyUI/Compose/lb_synthesis_mosaic_ico_01.dds", Vector4(0, 0, 0, 0)),
				NeutralDisabledImage = Gui.Image("LobbyUI/Compose/lb_synthesis_mosaic_ico_01.dds", Vector4(0, 0, 0, 0)),
			}
		end

		for i = 1, 3 do
			ui["rongneng_"..i].Visible = false
		end
		for i = 1, info.meltingEnergy do
			ui["rongneng_"..i].Visible = true
		end
	end
	
	if melting_result then
		ui.formula_name.Text = melting_result[1][3]
		ui.formula_icon.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..melting_result[1][2]..".tga")
		ui.formula_icon:OnDestroy()
		if melting_result[1][4] > 1 then
			L_Characters.CreatPresentNumCtr(ui.formula_icon,melting_result[1][4],156,80)
		end
	end
	for i = 1, 9 do
		ui["formula_sucai"..i].Visible = false
	end
	if melting_items then
		local melting_num = 0
		table.foreach(melting_items, function(i, v)
			melting_num = i
			ui["formula_sucai"..i].Visible = true
			ui["formula_sucai_resource"..i].ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..v[2]..".tga")
			ui["formula_sucai_name"..i].Text = v[3]
			ui["formula_sucai_name"..i].TextColor = ARGB(255, 94, 94, 94)
			ui["formula_sucai_checkbox"..i].Check = false
		end)
		ui.formula_info.Size = Vector2(330,159+6+melting_num*38)	
		
		for i = 1, #melting do
			if melting[i].sid ~= -1 then
				for j,v in pairs(melting_items) do
					if melting[i].sid == v[1] then
						if ui["formula_sucai_checkbox"..j].Check == false then
							ui["formula_sucai_name"..j].TextColor = ARGB(255, 182, 175, 169)
							ui["formula_sucai_checkbox"..j].Check = true
							break
						end
					end
				end
			end
		end
	end
	
	local flag = IsExist()
	if flag then
		ui.start2.Enable = true
	else
		ui.start2.Enable = false
	end
	
	if flag and main_type == 4 and melting_table.playeritemid == -1 and ui.sucai.PushDown == false then
		ui.sucai.blink = true
		ui.arrows.Visible = true
	else
		ui.sucai.blink = false
		ui.arrows.Visible = false
	end
	
	Fill_Help()
	return true
end


function FillMachine4(index,x,y)
	Label = ptr_cast(ui.text_shengxing:GetChildByIndex(2))
	Label.TextColor = ARGB(255, 213, 255, 254)
	ui.ctrl_demage_shengxing.Visible = false
	Label = ptr_cast(ui.text_shengxing:GetChildByIndex(3))
	Label.TextColor = ARGB(255, 213, 255, 254)
	ui.ctrl_demage1_shengxing.Visible = false
	Label = ptr_cast(ui.text_shengxing:GetChildByIndex(1))
	Label.TextColor = ARGB(255, 213, 255, 254)
	ui.ctrl_demage2_shengxing.Visible = false	
	local t_index = nil
	ui.Compare_3_full.Visible = false


	ui.wuqi.Enable = true
	ui.fuzhuang.Enable = true
	ui.shipin.Enable = true	
	
	if index ~= 0 then	
		if rpc_date[index] then
			if x and y then
				if x < 324 and x > 206 and y < 377 and y > 300 then
					if upstar[1].index ~= -1 then
						if upstar[1].gstLevel == 5 then
							ui.Compare_3_full.Visible = true
							ui.cbox_daily_shengxing_exp.Enable = false
						end
						return false
					end
					t_index = 1
					if rpc_date[index].color > 0 and rpc_date[index].color < 8 then
						ui.main_weapon.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..rpc_date[index].name.."_"..rpc_date[index].color..".tga")
					else
						ui.main_weapon.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..rpc_date[index].name..".tga")
					end
					-- ui.temp_main_exp.Text = rpc_date[index].gstExp
					ui.main_weapon_star.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/Compose/shengxing/lb_synthesis_conversion_star_0"..rpc_date[index].gstLevel..".dds", Vector4(0, 0, 0, 0)),}
					if rpc_date[index].common.strength > 0 then
						ui.main_weapon_lv.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/badge_lv"..rpc_date[index].common.strength.."_small.dds", Vector4(0, 0, 0, 0)),}
					else
						ui.main_weapon_lv.Skin = Gui.ControlSkin{BackgroundImage = nil,}
					end
					upstar[t_index].page = current_page
					upstar[t_index].index = index
					upstar[t_index].type = current_selected
					upstar[t_index].cid = current_characters
					upstar[t_index].pid = rpc_date[index].playeritemid
					upstar[t_index].gstLevel = rpc_date[index].gstLevel
					upstar[t_index].gstExp = rpc_date[index].gstExp
					upstar[t_index].sid = rpc_date[index].sid
					upstar[t_index].rareLevel = rpc_date[index].common.rareLevel
					upstar[t_index].star = rpc_date[index].common.star
					upstar[t_index].damange = rpc_date[index].performance.damange
					upstar[t_index].damange_add = rpc_date[index].performance.damange_add
					upstar[t_index].speed = rpc_date[index].performance.speed
					upstar[t_index].speed_add = rpc_date[index].performance.speed_add
					upstar[t_index].wid = rpc_date[index].common.wid
					upstar[t_index].strength = rpc_date[index].common.strength
					upstar[t_index].gstExpAdd = rpc_date[index].gstExpAdd
					upstar[t_index].cBloodAdd = rpc_date[index].common.cBloodAdd 
					upstar[t_index].cBloodAdd_add = rpc_date[index].common.cBloodAdd_add
					
					if upstar[1].pid ~= -1 then
						ui.text_shengxing.Visible = true
						Label = ptr_cast(ui.text_shengxing:GetChildByIndex(1))
						Label.TextColor = ARGB(255, 213, 255, 254)
						Label.Text = lang:GetText("战斗力：")..upstar[1].star
						Label = ptr_cast(ui.text_shengxing:GetChildByIndex(0))
						Label.TextColor = ARGB(255, 213, 255, 254)
						Label.Text = lang:GetText("星级：")..upstar[1].gstLevel

						local pow = nil
						local speed = nil
						if current_selected == 1 then
							Label = ptr_cast(ui.text_shengxing:GetChildByIndex(2))
							Label.Text = lang:GetText("攻击力：")
							
							-- ui.ctrl_demage_shengxing.Visible = false
							pow = math.floor((upstar[1].damange + upstar[1].damange_add) * 10) / 10
							-- Label.TextColor = ARGB(255, 213, 255, 254)

							ui.compare_demage1_shengxing.Visible = true
							if upstar[1].wid == 4 then
								pow = pow * 3
							end
							local temp = (pow - (pow % 50)) / 50 + 1
							if temp > 1 then
								ui.star_shengxing.Visible = true
								local con = ptr_cast(ui.star_shengxing:GetChildByIndex(1))
								con.Text = " x  "..(temp - 1)
							else
								ui.star.Visible = false
							end
							if pow % 50 == 0 then
								temp = temp - 1
								ui.compare_demage1_shengxing.Icon = compareIcon2[temp]
								ui.compare_demage1_shengxing:ResetBaseValue(100)
							else
								if temp > 7 then
									temp = 7
								end
								ui.compare_demage1_shengxing.Icon = compareIcon2[temp]
								ui.compare_demage1_shengxing:ResetBaseValue(pow % 50 * 2)
							end
							ui.fangju_shengxing_hp.Visible = false
						else
							Label = ptr_cast(ui.text_shengxing:GetChildByIndex(2))
							Label.Text = lang:GetText("增加血量：")..precision(upstar[1].cBloodAdd + upstar[1].cBloodAdd_add).."%"
							ui.fangju_shengxing_hp.Visible = true
							ui.star_shengxing.Visible = false
							ui.compare_demage1_shengxing.Visible = false
							if upstar[1].gstLevel > 0 then
								ui.fangju_shengxing_hp.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/Compose/shengxing/lb_synthesis_conversion_hp_0"..upstar[1].gstLevel..".dds", Vector4(0, 0, 0, 0)),}
							else
								ui.fangju_shengxing_hp.Visible = false
							end
						end
						
						
						if current_selected == 1 then
							Label = ptr_cast(ui.text_shengxing:GetChildByIndex(3))
							Label.Text = lang:GetText("攻击速度")..lang:GetText("：")

							-- Label.TextColor = ARGB(255, 213, 255, 254)
							speed = math.floor((upstar[1].speed + upstar[1].speed_add) * 10) / 10
							-- ui.ctrl_demage1_shengxing.Visible = false

							ui.compare_demage2_shengxing.Visible = true
							local temp = (speed - (speed % 50)) / 50 + 1
							if temp > 1 then
								ui.star1_shengxing.Visible = true
								local con = ptr_cast(ui.star1_shengxing:GetChildByIndex(1))
								con.Text = " x  "..(temp - 1)
							else
								ui.star1_shengxing.Visible = false
							end
							if speed % 50 == 0 then
								temp = temp - 1
								ui.compare_demage2_shengxing.Icon = compareIcon2[temp + 7]
								ui.compare_demage2_shengxing:ResetBaseValue(100)
							else
								if temp > 7 then
									temp = 7
								end
								ui.compare_demage2_shengxing.Icon = compareIcon2[temp + 7]
								ui.compare_demage2_shengxing:ResetBaseValue(speed % 50 * 2)
							end
						else
							Label = ptr_cast(ui.text_shengxing:GetChildByIndex(3))
							Label.Visible = false
							ui.compare_demage2_shengxing.Visible = false
							ui.star1_shengxing.Visible = false
						end
						if everyDayIsVisiable[math.ceil(upstar[1].rareLevel/25)-1] == 1 then
							ui.cbox_daily_shengxing_exp.Enable = true
						else
							ui.cbox_daily_shengxing_exp.Enable = false
						end		
					else
						ui.text_shengxing.Visible = false
						ui.star_shengxing.Visible = false
						ui.star1_shengxing.Visible = false
						ui.ctrl_demage_shengxing.Visible = false
						ui.ctrl_demage1_shengxing.Visible = false
						ui.ctrl_demage2_shengxing.Visible = false
						ui.start3.Enable = false
						ui.cbox_daily_shengxing_exp.Check = false
						ui.daily_exp_tip.Visible = false
					end
					if upstar[1].pid ~= -1 and upstar[1].gstLevel < 5 then
						local num = 0
						local flag = false
						for i = 2, 10 do
							if upstar[i].pid ~= -1 then
								if upstar[i].sid == upstar[1].sid then
									num = num + upstar[i].gstExpAdd*5
								else
									num = num + upstar[i].gstExpAdd
								end
								flag = true	
							end
						end
						if flag then
							ui.start3.Enable = true
						else
							ui.start3.Enable = false
						end
						num = num + upstar[1].gstExp
						if ui.cbox_daily_shengxing_exp.Check then
							num = num + everyDayExp[math.ceil(upstar[1].rareLevel/25)-1]
						end
						local per = num/upstar_AllExp[math.ceil(upstar[1].rareLevel/25)-1][upstar[1].gstLevel+1] * 120
						local nextLevel = 0
						if upstar[1].gstLevel < 5 and num > upstar_AllExp[math.ceil(upstar[1].rareLevel/25)-1][upstar[1].gstLevel+1] then
							nextLevel = upstar[1].gstLevel+1
						end	
						if upstar[1].gstLevel < 4 and num > upstar_AllExp[math.ceil(upstar[1].rareLevel/25)-1][upstar[1].gstLevel+1] + upstar_AllExp[math.ceil(upstar[1].rareLevel/25)-1][upstar[1].gstLevel+2] then
							nextLevel = upstar[1].gstLevel+2
						end	
						if upstar[1].gstLevel < 3 and num > upstar_AllExp[math.ceil(upstar[1].rareLevel/25)-1][upstar[1].gstLevel+1] + upstar_AllExp[math.ceil(upstar[1].rareLevel/25)-1][upstar[1].gstLevel+2] + upstar_AllExp[math.ceil(upstar[1].rareLevel/25)-1][upstar[1].gstLevel+3] then	
							nextLevel = upstar[1].gstLevel+3
						end	
						if upstar[1].gstLevel < 2 and num > upstar_AllExp[math.ceil(upstar[1].rareLevel/25)-1][upstar[1].gstLevel+1] + upstar_AllExp[math.ceil(upstar[1].rareLevel/25)-1][upstar[1].gstLevel+2] + upstar_AllExp[math.ceil(upstar[1].rareLevel/25)-1][upstar[1].gstLevel+3] + upstar_AllExp[math.ceil(upstar[1].rareLevel/25)-1][upstar[1].gstLevel+4] then	
							nextLevel = upstar[1].gstLevel+4
						end
						if upstar[1].gstLevel < 1 and num > upstar_AllExp[math.ceil(upstar[1].rareLevel/25)-1][upstar[1].gstLevel+1] + upstar_AllExp[math.ceil(upstar[1].rareLevel/25)-1][upstar[1].gstLevel+2] + upstar_AllExp[math.ceil(upstar[1].rareLevel/25)-1][upstar[1].gstLevel+3] + upstar_AllExp[math.ceil(upstar[1].rareLevel/25)-1][upstar[1].gstLevel+4] + upstar_AllExp[math.ceil(upstar[1].rareLevel/25)-1][upstar[1].gstLevel+5] then	
							nextLevel = upstar[1].gstLevel+5
						end
						if per > 120 then
							per = 120
							local pow = nil
							local speed = nil
							Label = ptr_cast(ui.text_shengxing:GetChildByIndex(2))
							Label.TextColor = ARGB(255, 0, 255, 68)
							ui.ctrl_demage_shengxing.Visible = true
							ui.ctrl_demage_shengxing.Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/ToolTips/lb_tooltips_jiantou_green.dds",Vector4(0, 0, 0, 0)),
							}
							if current_selected == 1 then
								ui.ctrl_demage_shengxing.Location = Vector2(186, 45)
								ui.ctrl_demage_shengxing.NormLocation = Vector2(186, 45)
							else
								ui.ctrl_demage_shengxing.Location = Vector2(186+20*upstar[1].gstLevel, 45)
								ui.ctrl_demage_shengxing.NormLocation = Vector2(136+20*upstar[1].gstLevel, 40)
							end
							Label = ptr_cast(ui.text_shengxing:GetChildByIndex(3))
							-- Label.TextColor = ARGB(255, 0, 255, 68)
							ui.ctrl_demage1_shengxing.Visible = false
							ui.ctrl_demage1_shengxing.Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/ToolTips/lb_tooltips_jiantou_green.dds",Vector4(0, 0, 0, 0)),
							}
							Label = ptr_cast(ui.text_shengxing:GetChildByIndex(1))
							Label.TextColor = ARGB(255, 0, 255, 68)
							ui.ctrl_demage2_shengxing.Visible = true
							ui.ctrl_demage2_shengxing.Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/ToolTips/lb_tooltips_jiantou_green.dds",Vector4(0, 0, 0, 0)),
							}
							Label = ptr_cast(ui.text_shengxing:GetChildByIndex(0))
							Label.TextColor = ARGB(255,  0, 255, 68)
							Label.Text = lang:GetText("星级：")..upstar[1].gstLevel.." → "..nextLevel
						end
						ui.Compare_3.Normsize = ui.Compare_3.Size
						ui.Compare_3:Clear()
						ui.Compare_3:InsertMovePoint(ui.Compare_3.Location,0.5,Vector2(262 * (per / 120), 53),ARGB(255,255,255,255))
					elseif  upstar[1].pid ~= -1 and upstar[1].gstLevel == 5  then
						ui.Compare_3.Normsize = ui.Compare_3.Size
						ui.Compare_3:Clear()
						ui.Compare_3:InsertMovePoint(ui.Compare_3.Location,0.5,Vector2(262, 53),ARGB(255,255,255,255))	
						ui.Compare_3_full.Visible = true	
					else
						ui.Compare_3.Normsize = ui.Compare_3.Size
						ui.Compare_3:Clear()
						ui.Compare_3:InsertMovePoint(ui.Compare_3.Location,0.5,Vector2(0, 53),ARGB(255,255,255,255))	
					end
					for i = 1 , 10 do
						if upstar[i].index ~= -1 then
							if current_selected == 1 then
								ui.fuzhuang.Enable = false
								ui.shipin.Enable = false
							elseif current_selected == 2 then
								ui.wuqi.Enable = false
								ui.shipin.Enable = false
							elseif current_selected == 3 then
								ui.wuqi.Enable = false
								ui.fuzhuang.Enable = false
							end
							break
						end	
					end
					Fill_Help()
					return true
				elseif  x < 633 and x > 394 and y < 536 and y > 289 then
					local flag1 = false
					local num = 0
					
					t_index = -1
					for i = 2, 10 do
						if upstar[i].index == -1 then
							t_index = i
							break
						end
					end
					if t_index == -1 then
						return false
					end
					if rpc_date[index].color > 0 and rpc_date[index].color < 8 then
						ui["Item_btn_shengxing_"..t_index].ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..rpc_date[index].name.."_"..rpc_date[index].color..".tga")
					else
						ui["Item_btn_shengxing_"..t_index].ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..rpc_date[index].name..".tga")
					end
					-- ui["temp_exp"..t_index].Text = rpc_date[index].gstExpAdd
					upstar[t_index].page = current_page
					upstar[t_index].index = index
					upstar[t_index].type = current_selected
					upstar[t_index].cid = current_characters
					upstar[t_index].pid = rpc_date[index].playeritemid
					upstar[t_index].gstLevel = rpc_date[index].gstLevel
					upstar[t_index].gstExp = rpc_date[index].gstExp
					upstar[t_index].sid = rpc_date[index].sid
					upstar[t_index].rareLevel = rpc_date[index].common.rareLevel
					upstar[t_index].star = rpc_date[index].common.star
					upstar[t_index].damange = rpc_date[index].performance.damange
					upstar[t_index].damange_add = rpc_date[index].performance.damange_add
					upstar[t_index].speed = rpc_date[index].performance.speed
					upstar[t_index].speed_add = rpc_date[index].performance.speed_add
					upstar[t_index].wid = rpc_date[index].common.wid
					upstar[t_index].strength = rpc_date[index].common.strength
					upstar[t_index].gstExpAdd = rpc_date[index].gstExpAdd
					upstar[t_index].cBloodAdd = rpc_date[index].common.cBloodAdd 
					upstar[t_index].cBloodAdd_add = rpc_date[index].common.cBloodAdd_add
					
					if upstar[1].pid ~= -1 and upstar[1].gstLevel < 5 then
						for i = 2, 10 do
							if upstar[i].pid ~= -1 then
								if upstar[i].sid == upstar[1].sid then
									num = num + upstar[i].gstExpAdd*5
								else
									num = num + upstar[i].gstExpAdd
								end
								flag1 = true	
							end
						end
						if flag1 then
							ui.start3.Enable = true
						else
							ui.start3.Enable = false
						end
						num = num + upstar[1].gstExp
						if ui.cbox_daily_shengxing_exp.Check then
							num = num + everyDayExp[math.ceil(upstar[1].rareLevel/25)-1]
						end
						local per = num/upstar_AllExp[math.ceil(upstar[1].rareLevel/25)-1][upstar[1].gstLevel+1] * 120
						local nextLevel = 0
						if upstar[1].gstLevel < 5 and num > upstar_AllExp[math.ceil(upstar[1].rareLevel/25)-1][upstar[1].gstLevel+1] then
							nextLevel = upstar[1].gstLevel+1
						end	
						if upstar[1].gstLevel < 4 and num > upstar_AllExp[math.ceil(upstar[1].rareLevel/25)-1][upstar[1].gstLevel+1] + upstar_AllExp[math.ceil(upstar[1].rareLevel/25)-1][upstar[1].gstLevel+2] then
							nextLevel = upstar[1].gstLevel+2
						end	
						if upstar[1].gstLevel < 3 and num > upstar_AllExp[math.ceil(upstar[1].rareLevel/25)-1][upstar[1].gstLevel+1] + upstar_AllExp[math.ceil(upstar[1].rareLevel/25)-1][upstar[1].gstLevel+2] + upstar_AllExp[math.ceil(upstar[1].rareLevel/25)-1][upstar[1].gstLevel+3] then	
							nextLevel = upstar[1].gstLevel+3
						end	
						if upstar[1].gstLevel < 2 and num > upstar_AllExp[math.ceil(upstar[1].rareLevel/25)-1][upstar[1].gstLevel+1] + upstar_AllExp[math.ceil(upstar[1].rareLevel/25)-1][upstar[1].gstLevel+2] + upstar_AllExp[math.ceil(upstar[1].rareLevel/25)-1][upstar[1].gstLevel+3] + upstar_AllExp[math.ceil(upstar[1].rareLevel/25)-1][upstar[1].gstLevel+4] then	
							nextLevel = upstar[1].gstLevel+4
						end
						if upstar[1].gstLevel < 1 and num > upstar_AllExp[math.ceil(upstar[1].rareLevel/25)-1][upstar[1].gstLevel+1] + upstar_AllExp[math.ceil(upstar[1].rareLevel/25)-1][upstar[1].gstLevel+2] + upstar_AllExp[math.ceil(upstar[1].rareLevel/25)-1][upstar[1].gstLevel+3] + upstar_AllExp[math.ceil(upstar[1].rareLevel/25)-1][upstar[1].gstLevel+4] + upstar_AllExp[math.ceil(upstar[1].rareLevel/25)-1][upstar[1].gstLevel+5] then	
							nextLevel = upstar[1].gstLevel+5
						end
						if per > 120 then
							per = 120
							local pow = nil
							local speed = nil
							Label = ptr_cast(ui.text_shengxing:GetChildByIndex(2))
							Label.TextColor = ARGB(255, 0, 255, 68)
							ui.ctrl_demage_shengxing.Visible = true
							ui.ctrl_demage_shengxing.Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/ToolTips/lb_tooltips_jiantou_green.dds",Vector4(0, 0, 0, 0)),
							}
							if current_selected == 1 then
								ui.ctrl_demage_shengxing.Location = Vector2(186, 45)
								ui.ctrl_demage_shengxing.NormLocation = Vector2(186, 45)
							else
								ui.ctrl_demage_shengxing.Location = Vector2(186+20*upstar[1].gstLevel, 45)
								ui.ctrl_demage_shengxing.NormLocation = Vector2(136+20*upstar[1].gstLevel, 40)
							end
							Label = ptr_cast(ui.text_shengxing:GetChildByIndex(3))
							-- Label.TextColor = ARGB(255, 0, 255, 68)
							ui.ctrl_demage1_shengxing.Visible = false
							ui.ctrl_demage1_shengxing.Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/ToolTips/lb_tooltips_jiantou_green.dds",Vector4(0, 0, 0, 0)),
							}
							Label = ptr_cast(ui.text_shengxing:GetChildByIndex(1))
							Label.TextColor = ARGB(255, 0, 255, 68)
							ui.ctrl_demage2_shengxing.Visible = true
							ui.ctrl_demage2_shengxing.Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/ToolTips/lb_tooltips_jiantou_green.dds",Vector4(0, 0, 0, 0)),
							}
							Label = ptr_cast(ui.text_shengxing:GetChildByIndex(0))
							Label.TextColor = ARGB(255,  0, 255, 68)
							Label.Text = lang:GetText("星级：")..upstar[1].gstLevel.." → "..nextLevel
						end
						
						ui.Compare_3.Normsize = ui.Compare_3.Size
						ui.Compare_3:Clear()
						ui.Compare_3:InsertMovePoint(ui.Compare_3.Location,0.5,Vector2(262 * (per / 120), 53),ARGB(255,255,255,255))
					elseif  upstar[1].pid ~= -1 and upstar[1].gstLevel == 5  then
						ui.Compare_3.Normsize = ui.Compare_3.Size
						ui.Compare_3:Clear()
						ui.Compare_3:InsertMovePoint(ui.Compare_3.Location,0.5,Vector2(262, 53),ARGB(255,255,255,255))	
						ui.Compare_3_full.Visible = true	
					else
						ui.Compare_3.Normsize = ui.Compare_3.Size
						ui.Compare_3:Clear()
						ui.Compare_3:InsertMovePoint(ui.Compare_3.Location,0.5,Vector2(0, 53),ARGB(255,255,255,255))	
					end
					for i = 1 , 10 do
						if upstar[i].index ~= -1 then
							if current_selected == 1 then
								ui.fuzhuang.Enable = false
								ui.shipin.Enable = false
							elseif current_selected == 2 then
								ui.wuqi.Enable = false
								ui.shipin.Enable = false
							elseif current_selected == 3 then
								ui.wuqi.Enable = false
								ui.fuzhuang.Enable = false
							end
							break
						end	
					end
					Fill_Help()
					return true
				end
				return false
			end
			for i = 1, 10 do
				if upstar[i].index == -1 then
					t_index = i
					break
				end
			end
			if t_index == nil then
				return false
			end
			if rpc_date[index].color > 0 and rpc_date[index].color < 8 then
				if t_index == 1 then
					ui.main_weapon.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..rpc_date[index].name.."_"..rpc_date[index].color..".tga")
					-- ui.temp_main_exp.Text = rpc_date[index].gstExp
					ui.main_weapon_star.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/Compose/shengxing/lb_synthesis_conversion_star_0"..rpc_date[index].gstLevel..".dds", Vector4(0, 0, 0, 0)),}
					if rpc_date[index].common.strength > 0 then
						ui.main_weapon_lv.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/badge_lv"..rpc_date[index].common.strength.."_small.dds", Vector4(0, 0, 0, 0)),}
					else
						ui.main_weapon_lv.Skin = Gui.ControlSkin{BackgroundImage = nil,}
					end
				else
					ui["Item_btn_shengxing_"..t_index].ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..rpc_date[index].name.."_"..rpc_date[index].color..".tga")
					-- ui["temp_exp"..t_index].Text = rpc_date[index].gstExpAdd
				end
			else
				if t_index == 1 then
					ui.main_weapon.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..rpc_date[index].name..".tga")
					-- ui.temp_main_exp.Text = rpc_date[index].gstExp
					ui.main_weapon_star.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/Compose/shengxing/lb_synthesis_conversion_star_0"..rpc_date[index].gstLevel..".dds", Vector4(0, 0, 0, 0)),}
					if rpc_date[index].common.strength > 0 then
						ui.main_weapon_lv.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/badge_lv"..rpc_date[index].common.strength.."_small.dds", Vector4(0, 0, 0, 0)),}
					else
						ui.main_weapon_lv.Skin = Gui.ControlSkin{BackgroundImage = nil,}
					end
				else
					ui["Item_btn_shengxing_"..t_index].ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..rpc_date[index].name..".tga")
					-- ui["temp_exp"..t_index].Text = rpc_date[index].gstExpAdd
				end	
			end
			upstar[t_index].page = current_page
			upstar[t_index].index = index
			upstar[t_index].type = current_selected
			upstar[t_index].cid = current_characters
			upstar[t_index].pid = rpc_date[index].playeritemid
			upstar[t_index].gstLevel = rpc_date[index].gstLevel
			upstar[t_index].gstExp = rpc_date[index].gstExp
			upstar[t_index].sid = rpc_date[index].sid
			upstar[t_index].rareLevel = rpc_date[index].common.rareLevel
			upstar[t_index].star = rpc_date[index].common.star
			upstar[t_index].damange = rpc_date[index].performance.damange
			upstar[t_index].damange_add = rpc_date[index].performance.damange_add
			upstar[t_index].speed = rpc_date[index].performance.speed
			upstar[t_index].speed_add = rpc_date[index].performance.speed_add
			upstar[t_index].wid = rpc_date[index].common.wid
			upstar[t_index].strength = rpc_date[index].common.strength
			upstar[t_index].gstExpAdd = rpc_date[index].gstExpAdd
			upstar[t_index].cBloodAdd = rpc_date[index].common.cBloodAdd 
			upstar[t_index].cBloodAdd_add = rpc_date[index].common.cBloodAdd_add
			if t_index == 1 then
				print("upstar[t_index].damange:"..upstar[t_index].damange)
			end
		end
		-- if material_info_page.ctrl_ib_container.Parent == nil then
			-- gui:PlayAudio("kUIA_COMPOUND_PUT")
		-- else
			-- gui:PlayAudio("kUIA_COMPOUND_PUT_ITEM")
		-- end
	end
	
	if upstar[1].pid ~= -1 then
		ui.text_shengxing.Visible = true
		Label = ptr_cast(ui.text_shengxing:GetChildByIndex(1))
		Label.TextColor = ARGB(255, 213, 255, 254)
		Label.Text = lang:GetText("战斗力：")..upstar[1].star
		Label = ptr_cast(ui.text_shengxing:GetChildByIndex(0))
		Label.TextColor = ARGB(255, 213, 255, 254)
		Label.Text = lang:GetText("星级：")..upstar[1].gstLevel

		local pow = nil
		local speed = nil
		
		if current_selected == 1 then
			Label = ptr_cast(ui.text_shengxing:GetChildByIndex(2))
			Label.Text = lang:GetText("攻击力：")
			-- ui.ctrl_demage_shengxing.Visible = false
			pow = math.floor((upstar[1].damange + upstar[1].damange_add) * 10) / 10
			-- Label.TextColor = ARGB(255, 213, 255, 254)

			ui.compare_demage1_shengxing.Visible = true
			if upstar[1].wid == 4 then
				pow = pow * 3
			end
			local temp = (pow - (pow % 50)) / 50 + 1
			if temp > 1 then
				ui.star_shengxing.Visible = true
				local con = ptr_cast(ui.star_shengxing:GetChildByIndex(1))
				con.Text = " x  "..(temp - 1)
			else
				ui.star.Visible = false
			end
			if pow % 50 == 0 then
				temp = temp - 1
				ui.compare_demage1_shengxing.Icon = compareIcon2[temp]
				ui.compare_demage1_shengxing:ResetBaseValue(100)
			else
				if temp > 7 then
					temp = 7
				end
				ui.compare_demage1_shengxing.Icon = compareIcon2[temp]
				ui.compare_demage1_shengxing:ResetBaseValue(pow % 50 * 2)
			end
			ui.fangju_shengxing_hp.Visible = false
		else
			Label = ptr_cast(ui.text_shengxing:GetChildByIndex(2))
			Label.Text = lang:GetText("增加血量：")..precision(upstar[1].cBloodAdd + upstar[1].cBloodAdd_add).."%"
			ui.star_shengxing.Visible = false
			ui.compare_demage1_shengxing.Visible = false
			ui.fangju_shengxing_hp.Visible = true
			if upstar[1].gstLevel > 0 then
				ui.fangju_shengxing_hp.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/Compose/shengxing/lb_synthesis_conversion_hp_0"..upstar[1].gstLevel..".dds", Vector4(0, 0, 0, 0)),}
			else
				ui.fangju_shengxing_hp.Visible = false
			end	
		end		
	
		if current_selected == 1 then
			Label = ptr_cast(ui.text_shengxing:GetChildByIndex(3))
			Label.Text = lang:GetText("攻击速度")..lang:GetText("：")
			Label.Visible = true
			-- Label.TextColor = ARGB(255, 213, 255, 254)
			speed = math.floor((upstar[1].speed + upstar[1].speed_add) * 10) / 10
			-- ui.ctrl_demage1_shengxing.Visible = false

			ui.compare_demage2_shengxing.Visible = true
			local temp = (speed - (speed % 50)) / 50 + 1
			if temp > 1 then
				ui.star1_shengxing.Visible = true
				local con = ptr_cast(ui.star1_shengxing:GetChildByIndex(1))
				con.Text = " x  "..(temp - 1)
			else
				ui.star1_shengxing.Visible = false
			end
			if speed % 50 == 0 then
				temp = temp - 1
				ui.compare_demage2_shengxing.Icon = compareIcon2[temp + 7]
				ui.compare_demage2_shengxing:ResetBaseValue(100)
			else
				if temp > 7 then
					temp = 7
				end
				ui.compare_demage2_shengxing.Icon = compareIcon2[temp + 7]
				ui.compare_demage2_shengxing:ResetBaseValue(speed % 50 * 2)
			end
		else
			Label = ptr_cast(ui.text_shengxing:GetChildByIndex(3))
			Label.Visible = false
			ui.compare_demage2_shengxing.Visible = false
			ui.star1_shengxing.Visible = false
		end
		if everyDayIsVisiable[math.ceil(upstar[1].rareLevel/25)-1] == 1 then
			ui.cbox_daily_shengxing_exp.Enable = true
		else
			ui.cbox_daily_shengxing_exp.Enable = false
		end		
	else
		ui.text_shengxing.Visible = false
		ui.star_shengxing.Visible = false
		ui.star1_shengxing.Visible = false
		ui.ctrl_demage_shengxing.Visible = false
		ui.ctrl_demage1_shengxing.Visible = false
		ui.ctrl_demage2_shengxing.Visible = false
		ui.start3.Enable = false
		ui.cbox_daily_shengxing_exp.Check = false
		ui.daily_exp_tip.Visible = false
	end
	
	if upstar[1].pid ~= -1 and upstar[1].gstLevel < 5 then
		local num = 0
		local flag = false
		for i = 2, 10 do
			if upstar[i].pid ~= -1 then
				if upstar[i].sid == upstar[1].sid then
					num = num + upstar[i].gstExpAdd*5
				else
					num = num + upstar[i].gstExpAdd
				end
				flag = true	
			end
		end
		if flag then
			ui.start3.Enable = true
		else
			ui.start3.Enable = false
		end
		num = num + upstar[1].gstExp
		if ui.cbox_daily_shengxing_exp.Check then
			num = num + everyDayExp[math.ceil(upstar[1].rareLevel/25)-1]
		end
		local per = num/upstar_AllExp[math.ceil(upstar[1].rareLevel/25)-1][upstar[1].gstLevel+1] * 120
		local nextLevel = 0
		if upstar[1].gstLevel < 5 and num > upstar_AllExp[math.ceil(upstar[1].rareLevel/25)-1][upstar[1].gstLevel+1] then
			nextLevel = upstar[1].gstLevel+1
		end	
		if upstar[1].gstLevel < 4 and num > upstar_AllExp[math.ceil(upstar[1].rareLevel/25)-1][upstar[1].gstLevel+1] + upstar_AllExp[math.ceil(upstar[1].rareLevel/25)-1][upstar[1].gstLevel+2] then
			nextLevel = upstar[1].gstLevel+2
		end	
		if upstar[1].gstLevel < 3 and num > upstar_AllExp[math.ceil(upstar[1].rareLevel/25)-1][upstar[1].gstLevel+1] + upstar_AllExp[math.ceil(upstar[1].rareLevel/25)-1][upstar[1].gstLevel+2] + upstar_AllExp[math.ceil(upstar[1].rareLevel/25)-1][upstar[1].gstLevel+3] then	
			nextLevel = upstar[1].gstLevel+3
		end	
		if upstar[1].gstLevel < 2 and num > upstar_AllExp[math.ceil(upstar[1].rareLevel/25)-1][upstar[1].gstLevel+1] + upstar_AllExp[math.ceil(upstar[1].rareLevel/25)-1][upstar[1].gstLevel+2] + upstar_AllExp[math.ceil(upstar[1].rareLevel/25)-1][upstar[1].gstLevel+3] + upstar_AllExp[math.ceil(upstar[1].rareLevel/25)-1][upstar[1].gstLevel+4] then	
			nextLevel = upstar[1].gstLevel+4
		end
		if upstar[1].gstLevel < 1 and num > upstar_AllExp[math.ceil(upstar[1].rareLevel/25)-1][upstar[1].gstLevel+1] + upstar_AllExp[math.ceil(upstar[1].rareLevel/25)-1][upstar[1].gstLevel+2] + upstar_AllExp[math.ceil(upstar[1].rareLevel/25)-1][upstar[1].gstLevel+3] + upstar_AllExp[math.ceil(upstar[1].rareLevel/25)-1][upstar[1].gstLevel+4] + upstar_AllExp[math.ceil(upstar[1].rareLevel/25)-1][upstar[1].gstLevel+5] then	
			nextLevel = upstar[1].gstLevel+5
		end
		
		if per > 120 then
			per = 120
			Label = ptr_cast(ui.text_shengxing:GetChildByIndex(2))
			Label.TextColor = ARGB(255, 0, 255, 68)
			ui.ctrl_demage_shengxing.Visible = true
			ui.ctrl_demage_shengxing.Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ToolTips/lb_tooltips_jiantou_green.dds",Vector4(0, 0, 0, 0)),
			}
			if current_selected == 1 then
				ui.ctrl_demage_shengxing.Location = Vector2(186, 45)
				ui.ctrl_demage_shengxing.NormLocation = Vector2(186, 45)
			else
				ui.ctrl_demage_shengxing.Location = Vector2(186+20*upstar[1].gstLevel, 45)
				ui.ctrl_demage_shengxing.NormLocation = Vector2(136+20*upstar[1].gstLevel, 40)
			end
			Label = ptr_cast(ui.text_shengxing:GetChildByIndex(3))
			-- Label.TextColor = ARGB(255, 0, 255, 68)
			ui.ctrl_demage1_shengxing.Visible = false
			ui.ctrl_demage1_shengxing.Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ToolTips/lb_tooltips_jiantou_green.dds",Vector4(0, 0, 0, 0)),
			}
			Label = ptr_cast(ui.text_shengxing:GetChildByIndex(1))
			Label.TextColor = ARGB(255, 0, 255, 68)
			ui.ctrl_demage2_shengxing.Visible = true
			ui.ctrl_demage2_shengxing.Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ToolTips/lb_tooltips_jiantou_green.dds",Vector4(0, 0, 0, 0)),
			}
			Label = ptr_cast(ui.text_shengxing:GetChildByIndex(0))
			Label.TextColor = ARGB(255,  0, 255, 68)
			Label.Text = lang:GetText("星级：")..upstar[1].gstLevel.." → "..nextLevel
		end
		ui.Compare_3.Normsize = ui.Compare_3.Size
		ui.Compare_3:Clear()
		ui.Compare_3:InsertMovePoint(ui.Compare_3.Location,0.5,Vector2(262 * (per / 120), 53),ARGB(255,255,255,255))
	elseif  upstar[1].pid ~= -1 and upstar[1].gstLevel == 5 then
		ui.Compare_3.Normsize = ui.Compare_3.Size
		ui.Compare_3:Clear()
		ui.Compare_3:InsertMovePoint(ui.Compare_3.Location,0.5,Vector2(262, 53),ARGB(255,255,255,255))
		ui.Compare_3_full.Visible = true
		ui.cbox_daily_shengxing_exp.Enable = false		
	else
		ui.Compare_3.Normsize = ui.Compare_3.Size
		ui.Compare_3:Clear()
		ui.Compare_3:InsertMovePoint(ui.Compare_3.Location,0.5,Vector2(0, 53),ARGB(255,255,255,255))	
	end
	
	for i = 1 , 10 do
		if upstar[i].index ~= -1 then
			if current_selected == 1 then
				ui.fuzhuang.Enable = false
				ui.shipin.Enable = false
			elseif current_selected == 2 then
				ui.wuqi.Enable = false
				ui.shipin.Enable = false
			elseif current_selected == 3 then
				ui.wuqi.Enable = false
				ui.fuzhuang.Enable = false
			end
			break
		end	
	end
	Fill_Help()
	return true
end

function FillCongratulation()
	congratulation.level.Skin = Gui.ControlSkin
	{
		BackgroundImage = Gui.Image("LobbyUI/ToolTips/badge_lv"..(rpc_date_object.common.strength - 1)..".dds", Vector4(0, 0, 0, 0)),
	}
	congratulation.level1.Skin = Gui.ControlSkin
	{
		BackgroundImage = Gui.Image("LobbyUI/ToolTips/badge_lv"..rpc_date_object.common.strength..".dds", Vector4(0, 0, 0, 0)),
	}
	congratulation.text.Text = lang:GetText("恭喜你的").."\n"..rpc_date_object.display..lang:GetText("\n强化等级上升到")..rpc_date_object.common.strength..lang:GetText("级。")
	L_LobbyMain.ShowFightnums(congratulation.fightnum,rpc_date_object.common.star)
end
function FillStarCongratulation(lv1,lv2,star)
	congratulation.level.Skin = Gui.ControlSkin
	{
		BackgroundImage = Gui.Image("LobbyUI/Compose/shengxing/lb_synthesis_conversion_shengxin_0"..lv1..".dds", Vector4(0, 0, 0, 0)),
	}
	congratulation.level1.Skin = Gui.ControlSkin
	{
		BackgroundImage = Gui.Image("LobbyUI/Compose/shengxing/lb_synthesis_conversion_shengxin_0"..lv2..".dds", Vector4(0, 0, 0, 0)),
	}
	congratulation.text.Text = lang:GetText("恭喜你的").."\n"..upstar[1].display..lang:GetText("\n星级上升到")..lv2..lang:GetText("星。")
	L_LobbyMain.ShowFightnums(congratulation.fightnum,star)
end

function Fillfailed(t)
	if t == 2 then
		failed.level.Visible = true
		failed.level1.Visible = true
		failed.text1.Visible = true
		failed.text2.Visible = true
		failed.text1.Text = lang:GetText("战斗力降低到")..":"
		failed.text2.Text = lang:GetText("战斗力降低到")..":"
		failed.jiantou.Visible = true
		failed.fightnum.Visible = true
		failed.jiantou_2.Visible = true
		failed.level.Location = Vector2(0, 0)
		failed.text.Text = lang:GetText("对不起，您的")..rpc_date_object.display..lang:GetText("\n强化等级倒退到")..rpc_date_object.common.strength..lang:GetText("级。")
		failed.level.Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/ToolTips/badge_lv"..(rpc_date_object.common.strength + 1)..".dds", Vector4(0, 0, 0, 0)),
		}
		failed.level1.Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/ToolTips/badge_lv"..rpc_date_object.common.strength..".dds", Vector4(0, 0, 0, 0)),
		}
	elseif t == 1 then
		failed.level.Visible = true
		failed.text1.Visible = true
		failed.text2.Visible = true
		failed.text1.Text = lang:GetText("战斗力")..":"
		failed.text2.Text = lang:GetText("战斗力")..":"
		failed.jiantou.Visible = false
		failed.fightnum.Visible = true
		failed.level1.Visible = false
		failed.jiantou_2.Visible = false
		failed.level.Location = Vector2(80, 0)
		failed.text.Text = lang:GetText("对不起，您的")..rpc_date_object.display..lang:GetText("\n合成失败了。")
		failed.level.Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/ToolTips/badge_lv"..rpc_date_object.common.strength..".dds", Vector4(0, 0, 0, 0)),
		}
	elseif t == 3 then
		failed.level.Visible = false
		failed.text1.Visible = false
		failed.text2.Visible = false
		failed.jiantou.Visible = false
		failed.fightnum.Visible = false
		failed.level1.Visible = false
		failed.jiantou_2.Visible = false
		failed.text.Text = lang:GetText("对不起，您的")..rpc_date_object.display..lang:GetText("\n消失了。")
	end
	L_LobbyMain.ShowFightnums(failed.fightnum,rpc_date_object.common.star)
	FillFailedGet()
end

function Fillmelting()
	for i = 1, 3 do
		melting_ui["ibtn_"..i].ItemIcon = nil
		local c_control = ptr_cast(melting_ui["ibtn_"..i]:GetChildByIndex(2))
		c_control.Visible = false
		melting_ui["btn_"..((i - 1) * 2 + 1)].Enable = true
	end
end

function FillMeltingList(index)
	for i = 1, 6 do
		if i == index then
			melting_list["btn_"..i].PushDown = true
		else
			melting_list["btn_"..i].PushDown = false
		end
	end
	if index < 4 then
		for i = 1, 12 do
			if i < index + 1 and i < 6 then
				melting_list["Ibtn_"..i].ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..melting_rpc_data_list[i].name..".tga")
				melting_list["Ibtn_"..i].LoadingImage = Gui.AnimatedImage("LobbyUI/loading_ring.tga", 4, 2, 8)
				melting_list["Ibtn_"..i].Enable = true
			else
				melting_list["Ibtn_"..i].ItemIcon = nil
				melting_list["Ibtn_"..i].LoadingImage = nil
				melting_list["Ibtn_"..i].Enable = false
			end
		end
	elseif index < 6 then
		for i = 1, 12 do
			if i < 4 then
				melting_list["Ibtn_"..i].ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..melting_rpc_data_list[i].name..".tga")
				melting_list["Ibtn_"..i].LoadingImage = Gui.AnimatedImage("LobbyUI/loading_ring.tga", 4, 2, 8)
				melting_list["Ibtn_"..i].Enable = true
			elseif i <= index then
				melting_list["Ibtn_"..i].ItemIcon = Gui.Icon("LobbyUI/Compose/lb_melting_wenhao_ico.dds")
				melting_list["Ibtn_"..i].LoadingImage = nil
				melting_list["Ibtn_"..i].Enable = false
			else
				melting_list["Ibtn_"..i].ItemIcon = nil
				melting_list["Ibtn_"..i].LoadingImage = nil
				melting_list["Ibtn_"..i].Enable = false
			end
		end
	elseif index == 6 then
		for i = 1, 12 do
			melting_list["Ibtn_"..i].ItemIcon = Gui.Icon("LobbyUI/Compose/lb_melting_wenhao_ico.dds")
			melting_list["Ibtn_"..i].LoadingImage = nil
			melting_list["Ibtn_"..i].Enable = false
		end
	end
end

function FillFailedGet()
	for i = 1 , 6 do
		local New = ptr_cast(failed.ctrl_failed_get_container:GetChildByIndex(i))
		New:OnDestroy()
		if New and data_temp.failAwards and data_temp.failAwards[i] then
			New.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..data_temp.failAwards[i].name..".tga")
			L_Characters.CreatPresentNumCtr(New,data_temp.failAwards[i].item_num,67,67)
		else
			New.ItemIcon = nil
		end
	end
end

function FillBlueMap(data, root)
	table.foreach(data, function(i, v)
		if type(v) == "table" then
			if v.item == nil then
				button_count = button_count + 1
				local iter = root
				local count = 0
				while(iter) do
					if iter == melting_list["Layout"] then
						break
					end
					count = count + 1
					iter = iter.Next
				end
				local btn = create_node_button("button_"..button_count,v.name, "FlowLayout_"..button_count, count * 15, count + 1, nil, ARGB(255, 255, 205, 69), ARGB(255, 255, 205, 69))
				btn["button_"..button_count.."root"].Parent = root
				local flo = create_node_flowLayout("FlowLayout_"..button_count)
				flo["FlowLayout_"..button_count].Parent = root
				if data[i].children then
					FillBlueMap(data[i].children, flo["FlowLayout_"..button_count])
				end
			else
				button_count = button_count + 1
				local btn = create_node_button("button_"..button_count,v.name, nil, 30, 3, v.item, ARGB(255, 255, 205, 69), ARGB(255, 0, 0, 0))
				btn["button_"..button_count.."root"].Parent = root
			end
		end
	end)
end

function Melting_lookover(index, data)
	melting_rpc_data[index] = data.item
	if data.item.color > 0 and data.item.color < 8 then
		melting_ui["ibtn_"..index].ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..data.item.name.."_"..data.item.color..".tga")
	else
		melting_ui["ibtn_"..index].ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..data.item.name..".tga")
	end
	local c_control = ptr_cast(melting_ui["ibtn_"..index]:GetChildByIndex(2))
	c_control.Visible = true
	L_LobbyMain.FillNumber(data.item.quantity, c_control)
	gui:PlayAudio("kUIA_FUSION_LOOK")
end

function Melting_get(item)
	if meltingmodal then
		meltingmodal.Close()
		meltingmodal = nil
	end
	gui:PlayAudio("kUIA_GET_GOOD_REWARD")
	melting_rpc_data[1] = item
	melting_ui_1["lab_1"].Text = item.display
	melting_ui_1["lab_2"].Text = item.display
	if item.color > 0 and item.color < 8 then
		melting_ui_1["ibtn_1"].ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..item.name.."_"..item.color..".tga")
	else
		melting_ui_1["ibtn_1"].ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..item.name..".tga")
	end
	if item.common and item.common.rareLevel then
		melting_ui_1["ibtn_1"].ItemLevel = Skin.rarelevel[math.ceil(item.common.rareLevel/25)]
	else
		melting_ui_1["ibtn_1"].ItemLevel = nil
	end
	local c_control = ptr_cast(melting_ui_1["ibtn_1"]:GetChildByIndex(2))
	melting_ui_1["ibtn_1"]:OnDestroy()
	L_Characters.CreatPresentNumCtr(melting_ui_1["ibtn_1"],item.quantity,212,100)
	--L_LobbyMain.FillNumber(item.quantity, c_control)
	meltingmodal = ModalWindow.GetNew()
	meltingmodal.screen.AllowEscToExit = false
	meltingmodal.root.Size = Vector2(1200,900)
	melting_ui_1.root.Parent = meltingmodal.root
end

function GetValue(data)
	--无法强化的物品Value为0
	if data.common.strength == -1 then
		return 0
	end
	if data.common.type == 1 then
		return (math.pow(1.8, data.common.strength) - 1) / 0.8 * 9
	elseif data.common.type == 2 then
		return (math.pow(1.8, data.common.strength) - 1) / 0.8 * 4.5
	elseif data.common.type == 3 then
		if data.common.subtype == 1 then
			return (math.pow(1.8, data.common.strength) - 1) / 0.8 * 1.5
		elseif data.common.subtype == 2 then
			return (math.pow(1.8, data.common.strength) - 1) / 0.8 * 3
		end
	else
		return 0
	end
end

function Initialize()
	if config:GetUISystemFlag(0) == 0 then
		melting_list.btn_2_2.Visible = false
		melting_list.btn_2_2_new.Visible = false
	else
		melting_list.btn_2_2.Visible = true
		melting_list.btn_2_2_new.Visible = true
	end
end

function Finalize()
	print("=================L_Compose Finalize()")
end

function ShowRapid(type, index)
	if main_type == 4 then
		Rapid_Shopping_index = 1
		Rapid_Shopping_Win.BTN_1.Visible = true
		Rapid_Shopping_Win.BTN_2.Visible = true
	else
		Rapid_Shopping_Win.BTN_1.Visible = false
		Rapid_Shopping_Win.BTN_2.Visible = false
	end

	if type == 1 then
		Rapid_Shopping_Win.W_name.Text = item_rpc.items[index].display
		Rapid_Shopping_Win.des.Text = item_rpc.items[index].description
		shop_fast_buy.sid = item_rpc.items[index].sid
		price = item_rpc.prices[index]
		Rapid_Shopping_Win.Imgae.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..item_rpc.items[index].name..".tga")
		Rapid_Shopping_Win.cost.Text = price * tonumber(Rapid_Shopping_Win.Tbox_Totle_num.Text)
		Rapid_Shopping_Win.bg.Size = Vector2(304, 209)
		Rapid_Shopping_Win.bg.Location = Vector2(10, 10)
		Rapid_Shopping_Win.Imgae.Visible = true
		Rapid_Shopping_Win.Imgae_a.Visible = false
		Rapid_Shopping_Win.Imgae_b.Visible = false
		local btn = ptr_cast(Rapid_Shopping_Win.bg:GetChildByIndex(3))
		btn.Location = Vector2(44, 164)
		btn = ptr_cast(Rapid_Shopping_Win.bg:GetChildByIndex(4))
		btn.Location = Vector2(77, 161)
		btn = ptr_cast(Rapid_Shopping_Win.bg:GetChildByIndex(5))
		btn.Location =  Vector2(239, 164)

	elseif type == 2 then
		shop_fast_buy.sid = item_rpc.items[index].sid
		Rapid_Shopping_Win.W_name.Text = item_rpc.items[index].display
		price = item_rpc.prices[index]
		Rapid_Shopping_Win.Imgae_a.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..item_rpc.items[3].name..".tga")
		Rapid_Shopping_Win.Imgae_b.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..item_rpc.items[4].name.."_disabled.tga")
		Rapid_Shopping_Win.cost.Text = price * tonumber(Rapid_Shopping_Win.Tbox_Totle_num.Text)
		Rapid_Shopping_Win.bg.Size = Vector2(315, 158)
		Rapid_Shopping_Win.bg.Location = Vector2(5, 10)
		Rapid_Shopping_Win.Imgae.Visible = false
		Rapid_Shopping_Win.Imgae_a.Visible = true
		Rapid_Shopping_Win.Imgae_b.Visible = true
		local btn = ptr_cast(Rapid_Shopping_Win.bg:GetChildByIndex(3))
		btn.Location = Vector2(8, 117)
		btn = ptr_cast(Rapid_Shopping_Win.bg:GetChildByIndex(4))
		btn.Location = Vector2(81, 116)
		btn = ptr_cast(Rapid_Shopping_Win.bg:GetChildByIndex(5))
		btn.Location = Vector2(288, 117)
	end
	modal = ModalWindow.GetNew()
	modal.root.Size = Vector2(376, 375)
	modal.AllowEscToExit = true
	Rapid_Shopping_Win.Rapid_Shopping_root.Parent = modal.root
end

function Show(parent_win)
	ptr_cast(game.CurrentState):OnChange_Lobby_Music(0)
	main_type = 1
	current_characters = 1
	L_LobbyMain.current_choose_class = current_characters
	ResetAll()
	ResetBtn()
	ui.buffbg_02.Visible = true
	ui.qianghua.Visible = true
	for i = 1, 10 do
		local btn = ptr_cast(ui["tab_btn_"..i])
		if btn.Visible == true then
			btn.PushDown = false
		end
	end
	ui["tab_btn_1"].PushDown = true

	ui.btn_qianghua.PushDown = true
	ui.btn_gaizhuang.PushDown = false
	ui.btn_zhuanhuan.PushDown = false
	ui.btn_ronglian.PushDown = false

	ui.qianghua.Visible = true
	ui.gaizhuang.Visible = false
	ui.zhuanhuan.Visible = false
	ui.ronglian.Visible = false

	ui.daoju.Visible = false

	config:LoadTips()
	if config.Tips == false then
		ui.cbox_help.Check = false
	else
		ui.cbox_help.Check = true
	end
	ResetAll()
	rpc_string = {pid = ptr_cast(game.CurrentState):GetCharacterId(), playerItemId = 0, strengthenItemId = 0, safeItemId = 0, stableItemId = 0}
	rpc.safecallload("character_list", {pid = ptr_cast(game.CurrentState):GetCharacterId()}, L_LobbyMain.FillCharacterClass)
	ui.main.Parent = parent_win
	FillStorage()
	FillMachine(0)
	ui.cbox_help.EventCheckChanged = function()
		Fill_Help()
		config.Tips = ui.cbox_help.Check
		config:SaveTips()
	end
	
	ui.main.Parent = parent_win
end

function high(FlowLayout)
	local h = 0
	local iter = FlowLayout.FirstChild
	while(iter) do
		if iter.IntTag == 1 and iter.Visible == true then
			h = h + high(iter)
		elseif iter.Visible == true and iter.IntTag ~= 1 then
			h = h + iter.Size.y
			if iter.IntTag == 2 then
				iter.PushDown = false
			end
		end
		iter = iter.Next
	end
	FlowLayout.Size = Vector2(FlowLayout.Size.x, h)
	return FlowLayout.Size.y
end

function Hide()
	print("=================L_Compose Hide()")
	if ui.main.Parent ~= nil then
		ptr_cast(game.CurrentState):OnChange_Lobby_Music(2)
	end
	ui.formula_info.Visible = false
	melting_items = nil
	melting_result = nil
	formula_right = false
	ui.main.Parent = nil
end

function ResetCharacters()
	for i = 1, 10 do
		local btn = ptr_cast(ui["tab_btn_"..i])
		if btn.Visible == true then
			btn.PushDown = false
		end
	end
	FillStorage()
end

function ResetBtn()
	ui.btn_qianghua.PushDown = false
	ui.btn_shengxing.PushDown = false
	ui.btn_gaizhuang.PushDown = false
	ui.btn_zhuanhuan.PushDown = false
	ui.btn_ronglian.PushDown = false
	ui.qianghua.Visible = false
	ui.shengxing.Visible = false
	ui.gaizhuang.Visible = false
	ui.zhuanhuan.Visible = false
	ui.ronglian.Visible = false
	ui.buffbg_03.Visible = false
	ui.buffbg_02.Visible = false
	if main_type == 5 then
		ui.daoju.Visible = true
		ui.fuzhuang.Visible = true
		ui.shipin.Visible = true
		ui.sucai.Visible = false
	else
		ui.daoju.Visible = true
		ui.fuzhuang.Visible = true
		ui.shipin.Visible = true
		ui.sucai.Visible = true
	end
	if main_type == 4 then
		ui.daoju.Visible = true
	else
		ui.daoju.Visible = false
	end
	FillStorage()
end

function ResetType()
	ui.wuqi.PushDown = false
	ui.fuzhuang.PushDown = false
	ui.shipin.PushDown = false
	ui.sucai.PushDown = false
	ui.daoju.PushDown = false
	FillStorage()
end

function ResetAll()
	ui.Help_part5.Visible = false
	if main_type ~= 5 then
		rpc.safecallload("combine_get_price",{pid = ptr_cast(game.CurrentState):GetCharacterId(), type = main_type},
		function(data)
			item_rpc = data
		end)
	end	
	ui.wuqi.PushDown = true
	ui.fuzhuang.PushDown = false
	ui.shipin.PushDown = false
	ui.sucai.PushDown = false
	ui.daoju.PushDown = false
	ui.wuqi.Enable = true
	ui.fuzhuang.Enable = true
	ui.shipin.Enable = true
	ui.sucai.Enable = true
	ui.daoju.Enable = true
	index_tz = 1
	current_selected = 1
	current_page = 1
	for i = 1, 3 do
		Clean_index_table(i)
	end
	success_level = -1
	Clean_Weapon_table()
	Clean_hole()
	rpc_string = {pid = ptr_cast(game.CurrentState):GetCharacterId(), playerItemId = 0, strengthenItemId = 0, safeItemId = 0, stableItemId = 0}
	shop_fast_buy = {pid = ptr_cast(game.CurrentState):GetCharacterId(), sid = 1, num = 0}
	rpc_insert = {pid = ptr_cast(game.CurrentState):GetCharacterId(), playerItemId = 0, index = 0, propertyItemId = 0}
	rpc_remove = {pid = ptr_cast(game.CurrentState):GetCharacterId(), playerItemId = 0, index = 0}
	rpc_slotting = {pid = ptr_cast(game.CurrentState):GetCharacterId(), playerItemId = 0, index = 0, sloterItemId = 0}
	rpc_date_object = nil
	rpc_date_object_1 = {{},{}}
	ui.sucai.blink = false
	ui.arrows.Visible = false
	-- 强化
	for i = 1, 3 do
		local ibbtn = ptr_cast(ui.qianghua:GetChildByIndex(i))
		if i == 1 then
			ibbtn.Enough = false
		end
		local control = ptr_cast(ui.Image:GetChildByIndex(i))
		ibbtn.ItemIcon = nil
		local con = ptr_cast(ibbtn:GetChildByIndex(2))
		con.Visible = false
		control.Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_ico_01_normal.dds", Vector4(0, 0, 0, 0)),
		}
		local lable = ptr_cast(ui.qianghua:GetChildByIndex(i + 3))
		lable.Visible = false
	end
	ui.object.ItemIcon = nil
	local ibbtn = ptr_cast(ui.object:GetChildByIndex(2))
	ibbtn.Visible = false
	ibbtn = ptr_cast(ui.object:GetChildByIndex(3))
	ibbtn.Visible = false
	ui.name.Text = ""
	for i = 1, 10 do
		local Label = ptr_cast(ui.text:GetChildByIndex(i - 1))
		Label.Text = ""
	end
	ui.text1.Text = ""
	ui.qianghuatext.Text = ""
	ui.text2.Text = ""
	ui.compare_demage1.Visible = false
	ui.compare_demage2.Visible = false
	ui.star.Visible = false
	ui.star1.Visible = false
	ui.ctrl_demage.Visible = false
	ui.ctrl_demage1.Visible = false
	ui.start.Enable = false
	
	ui.formula_info.Visible = false
	melting_items = nil
	melting_result = nil
	formula_right = false
	
	ui.ibtn_1.ItemIcon = nil
	if melting_table.playeritemid ~= -1 then
		for j = 1, 16 do
			if rpc_date[j] and rpc_date[j].playeritemid == melting_table.playeritemid then
				local ibbtn = ptr_cast(material_info_page.ctrl_ib_container:GetChildByIndex(j-1))
				ibbtn.ItemIcon.alpha = 255
			end
		end
	end
	melting_table.playeritemid = -1
	melting_table.value = 0
	ui.lab_des.Text = ""

	-- 改装
	ui.object1.ItemIcon = nil
	local ibbtn = ptr_cast(ui.object1:GetChildByIndex(2))
	ibbtn.Visible = false
	local ibbtn = ptr_cast(ui.object1:GetChildByIndex(3))
	ibbtn.Visible = false
	for i = 1, 6 do
		local ibbtn = ptr_cast(ui.gaizhuang:GetChildByIndex(i + 1))
		ibbtn.ItemIcon = nil
		ibbtn.Skin = ItemBoxBtn_Compose_b
		ibbtn.Hint = ""
		local ibbtn = ptr_cast(ui.gaizhuang:GetChildByIndex(i + 7))
		ibbtn.Enable = false
		ibbtn.Text = lang:GetText("改装")
	end
	ui.dakong.ItemIcon = nil
	local ibbtn = ptr_cast(ui.dakong:GetChildByIndex(2))
	ibbtn.Visible = false
	ui.main_2.Visible = false

	-- 转换
	ui.object2.ItemIcon = nil
	ui.object3.ItemIcon = nil
	local ibbtn = ptr_cast(ui.object2:GetChildByIndex(2))
	ibbtn.Visible = false
	ibbtn = ptr_cast(ui.object2:GetChildByIndex(3))
	ibbtn.Visible = false
	ibbtn = ptr_cast(ui.object3:GetChildByIndex(2))
	ibbtn.Visible = false
	ibbtn = ptr_cast(ui.object3:GetChildByIndex(3))
	ibbtn.Visible = false
	rpc_date_object_1[1] = nil
	rpc_date_object_1[2] = nil
	ui.X.Visible = false
	ui.X1.Visible = true
	ui.main_3.Visible = false
	for i = 1, 2 do
		Clean_convert(i)
	end
	ui.left_3.Skin = Gui.ControlSkin
	{
		BackgroundImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_ico_03_normal.dds", Vector4(0, 0, 0, 0)),
	}
	ui.right_3.Skin = Gui.ControlSkin
	{
		BackgroundImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_ico_03_b_normal.dds", Vector4(0, 0, 0, 0)),
	}
	ui.start1.Enable = false

	--熔炼
	is_formula = false
	ui.start2.Enable = false
	for i = 1, 9 do
		Clean_melting(i)
		ui["Item_btn_"..i].ItemIcon = nil
	end
	
	for i = 1, 10 do
		Clean_upstar(i)
		if i == 1 then
			ui.main_weapon.ItemIcon = nil
			ui.main_weapon_star.Skin = Gui.ControlSkin{BackgroundImage = nil,}
			ui.main_weapon_lv.Skin = Gui.ControlSkin{BackgroundImage = nil,}
		else
			ui["Item_btn_shengxing_"..i].ItemIcon = nil
		end
	end
	ui.text_shengxing.Visible = false
	ui.cbox_daily_shengxing_exp.Check = false
	ui.start3.Enable = false
	
	Fill_Help()
end

function Clean_index_table(index)
	index_table[index].playeritemid = -1
	index_table[index].page = -1
	index_table[index].index = -1
	index_table[index].num = -1
end

function Clean_Weapon_table()
	Weapon_table.page = -1
	Weapon_table.index = -1
	Weapon_table.cid = -1
	Weapon_table.type = -1
end

function Clean_hole()
	hole.page = -1
	hole.index = -1
	hole.playeritemid = -1
	hole.num = -1
end

function Clean_convert(index)
	convert[index] = {page = -1, index = -1, cid = -1, type = -1}
end

function Clean_melting(index)
	melting[index].page = -1
	melting[index].index = -1
	melting[index].cid = -1
	melting[index].type = -1
	melting[index].pid = -1
	melting[index].value = -1
	melting[index].sid = -1
end

function Clean_upstar(index)
	upstar[index].page = -1
	upstar[index].index = -1
	upstar[index].cid = -1
	upstar[index].type = -1
	upstar[index].pid = -1
	upstar[index].gstLevel = -1
	upstar[index].gstExp = -1
	upstar[index].sid = -1
	upstar[index].rarelevel = -1
	upstar[index].star = -1
	upstar[index].damange = -1
	upstar[index].damange_add = -1
	upstar[index].speed = -1
	upstar[index].speed_add = -1
	upstar[index].wid = -1
	upstar[index].dislay = nil
	upstar[index].gstExpAdd = -1
	upstar[index].cBloodAdd = -1
	upstar[index].cBloodAdd_add = -1
end

function Fill_Help()
	if ui.cbox_help.Check then
		if main_type == 1 then
			local btn = ptr_cast(ui.qianghua:GetChildByIndex(1))
			if not rpc_date_object then
				ui.Help_part1.Visible = true
				ui.Help_part2.Visible = false
				ui.Help_part3.Visible = false
				ui.Help_part4.Visible = false
				ui.Help_part6.Visible = false
				ui.Help_part7.Visible = false
				ui.Help_part8.Visible = false
				ui.Help_part9.Visible = false
				ui.Help_part10.Visible = false
				ui.Help_part11.Visible = false
			elseif rpc_date_object and not btn.ItemIcon then
				ui.Help_part2.Visible = true
				ui.Help_part1.Visible = false
				ui.Help_part3.Visible = false
				ui.Help_part4.Visible = false
				ui.Help_part6.Visible = false
				ui.Help_part7.Visible = false
				ui.Help_part8.Visible = false
				ui.Help_part9.Visible = false
				ui.Help_part10.Visible = false
				ui.Help_part11.Visible = false				
			else
				ui.Help_part1.Visible = false
				ui.Help_part2.Visible = false
				ui.Help_part3.Visible = false
				ui.Help_part4.Visible = false
				ui.Help_part6.Visible = false
				ui.Help_part7.Visible = false
				ui.Help_part8.Visible = false
				ui.Help_part9.Visible = false
				ui.Help_part10.Visible = false
				ui.Help_part11.Visible = false				
			end
		elseif main_type == 2 then
			if not rpc_date_object then
				ui.Help_part1.Visible = true
				ui.Help_part2.Visible = false
				ui.Help_part3.Visible = false
				ui.Help_part4.Visible = false
				ui.Help_part6.Visible = false
				ui.Help_part7.Visible = false
				ui.Help_part8.Visible = false
				ui.Help_part9.Visible = false
				ui.Help_part10.Visible = false
				ui.Help_part11.Visible = false				
			else
				ui.Help_part1.Visible = false
				ui.Help_part2.Visible = false
				ui.Help_part3.Visible = false
				ui.Help_part4.Visible = false
				ui.Help_part6.Visible = false
				ui.Help_part7.Visible = false
				ui.Help_part8.Visible = false
				ui.Help_part9.Visible = false
				ui.Help_part10.Visible = false
				ui.Help_part11.Visible = false				
			end
		elseif main_type == 3 then
			if rpc_date_object_1[1] and rpc_date_object_1[2] then
				ui.Help_part1.Visible = false
				ui.Help_part2.Visible = false
				ui.Help_part3.Visible = false
				ui.Help_part4.Visible = false
				ui.Help_part6.Visible = false
				ui.Help_part7.Visible = false
				ui.Help_part8.Visible = false
				ui.Help_part9.Visible = false
				ui.Help_part10.Visible = false
				ui.Help_part11.Visible = false				
			else
				ui.Help_part1.Visible = false
				ui.Help_part2.Visible = false
				ui.Help_part3.Visible = false
				ui.Help_part4.Visible = true
				ui.Help_part6.Visible = false
				ui.Help_part7.Visible = false
				ui.Help_part8.Visible = false
				ui.Help_part9.Visible = false
				ui.Help_part10.Visible = false
				ui.Help_part11.Visible = false				
			end
		elseif main_type == 4 then
			ui.Help_part1.Visible = false
			ui.Help_part2.Visible = false
			ui.Help_part3.Visible = false
			ui.Help_part4.Visible = false
			ui.Help_part9.Visible = false
			ui.Help_part10.Visible = false
			ui.Help_part11.Visible = false
			if info then
				if info.meltingEnergy == 0 and not is_formula then
					ui.Help_part6.Visible = true
					ui.Help_part7.Visible = false
					ui.Help_part8.Visible = false
				else
					ui.Help_part6.Visible = false
					local flag = false
					for i = 1, info.slotNum do
						if melting[i].pid ~= -1 then
							flag = true
							break
						end
					end
					if not flag then
						ui.Help_part7.Visible = true
						ui.Help_part8.Visible = false
					elseif flag and melting_table.playeritemid == -1 then
						ui.Help_part7.Visible = false
						ui.Help_part8.Visible = true
					else
						ui.Help_part7.Visible = false
						ui.Help_part8.Visible = false
					end
				end
			else
				ui.Help_part1.Visible = false
				ui.Help_part2.Visible = false
				ui.Help_part3.Visible = false
				ui.Help_part4.Visible = false
				ui.Help_part6.Visible = false
				ui.Help_part7.Visible = false
				ui.Help_part8.Visible = false
				ui.Help_part9.Visible = false
				ui.Help_part10.Visible = false
				ui.Help_part11.Visible = false
			end
		elseif main_type == 5 then
			if upstar[1].pid == -1 then
				ui.Help_part1.Visible = false
				ui.Help_part2.Visible = false
				ui.Help_part3.Visible = false
				ui.Help_part4.Visible = false
				ui.Help_part6.Visible = false
				ui.Help_part7.Visible = false
				ui.Help_part8.Visible = false
				ui.Help_part9.Visible = true
				ui.Help_part10.Visible = false
			elseif upstar[2].pid == -1 and upstar[3].pid == -1  and upstar[4].pid == -1 and upstar[5].pid == -1 and upstar[6].pid == -1 and upstar[7].pid == -1 and upstar[8].pid == -1 and upstar[9].pid == -1 and upstar[10].pid == -1 then
				ui.Help_part1.Visible = false
				ui.Help_part2.Visible = false
				ui.Help_part3.Visible = false
				ui.Help_part4.Visible = false
				ui.Help_part6.Visible = false
				ui.Help_part7.Visible = false
				ui.Help_part8.Visible = false
				ui.Help_part9.Visible = false
				ui.Help_part10.Visible = true
			else
				ui.Help_part1.Visible = false
				ui.Help_part2.Visible = false
				ui.Help_part3.Visible = false
				ui.Help_part4.Visible = false
				ui.Help_part6.Visible = false
				ui.Help_part7.Visible = false
				ui.Help_part8.Visible = false
				ui.Help_part9.Visible = false
				ui.Help_part10.Visible = false			
			end
			if ui.text_shengxing.Visible and ui.cbox_daily_shengxing_exp.Enable and ui.cbox_daily_shengxing_exp.Check == false and ui.text_shengxing.Visible then
				ui.Help_part11.Visible = true
			else
				ui.Help_part11.Visible = false
			end
		end
	else
		ui.Help_part1.Visible = false
		ui.Help_part2.Visible = false
		ui.Help_part3.Visible = false
		ui.Help_part4.Visible = false
		ui.Help_part6.Visible = false
		ui.Help_part7.Visible = false
		ui.Help_part8.Visible = false
		ui.Help_part9.Visible = false
		ui.Help_part10.Visible = false
		ui.Help_part11.Visible = false
	end
end

function NeedBlink()
	if main_type == 4 and IsExist() and melting_table.playeritemid == -1 then
		ui.sucai.blink = true
		ui.arrows.Visible = true
	elseif ui.object.ItemIcon or ui.object1.ItemIcon and main_type ~= 3 then
		ui.sucai.blink = true
		ui.arrows.Visible = true
	else
		ui.sucai.blink = false
		ui.arrows.Visible = false
	end
end
