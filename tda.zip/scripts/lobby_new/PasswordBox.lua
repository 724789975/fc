module("L_PassWordBox", package.seeall)

msgBox = nil
local room_info = nil
local STATE = nil
local entranceFlag = nil

local function Hide(which)
	if which then
		which.root.Parent = nil
	end
end

--entrance = 1, called by normal procedure
--entrance = 2, called by AutoChangeRoom
function Show(root, state_arg, room_info_arg, entrance,password)
    entranceFlag = entrance
    STATE = state_arg

    --print("L_PassWordBox.Show, EntranceFlag:")
    --print(entranceFlag)

    room_info = room_info_arg

	if msgBox == nil then
		local page = 
		{
			Gui.Control "root"
			{
				Dock = "kDockCenter",
				BackgroundColor = ARGB(255,255,255,255),
				Size = Vector2(450, 200),
				Padding = Vector4(10, 10, 10, 0),
				
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_bg5.dds", Vector4(20, 20, 20, 20)),
				},
						
				Gui.FlowLayout "txt_area"
				{
					Size = Vector2(0, 52),
					Dock = "kDockTop",
					Align = "kAlignCenterMiddle",
					ControlAlign = "kAlignCenterMiddle",
					ControlSpace = 6,
					
					Gui.Label "lb"
					{
						Size = Vector2(200, 25),
						Location = Vector2(0, 0),
						FontSize = 20,
						TextColor = ARGB(255, 52, 50, 50),
						Text = "  "..lang:GetText("请输入房间密码"),
					},
				},

                Gui.FlowLayout "txt_pw"
				{
					Size = Vector2(0, 50),
					Dock = "kDockTop",
					Align = "kAlignCenterMiddle",
					ControlAlign = "kAlignCenterMiddle",
					ControlSpace = 6,
					
					Gui.Textbox "tb"
					{
						Size = Vector2(150, 40),
						TextColor = ARGB(255,195,189,176),
						MaxLength = 16,
						TextPassword = true,
						Text = "",
						FontSize = 20,
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/lb_common_textbox01_normal.dds", Vector4(5, 5, 5, 5)),
						},
					}
				},

				Gui.FlowLayout "button_area"
				{
						Size = Vector2(0, 60),
						Dock = "kDockBottom",
						Align = "kAlignCenterMiddle", 
						ControlAlign = "kAlignBottomMiddle",
						ControlSpace = 3,

						Gui.Button "btn_yes"
						{
							--Style = "MessageBoxStyle.Button",
							Text = lang:GetText("确　定"),
							Margin = Vector4(15, 0, 15, 0),
							Size = Vector2(104, 40),
							TextColor = ARGB(255, 211, 211, 211),
							Padding = Vector4(0, 0, 0, 7),
							HighlightTextColor = ARGB(255, 211, 211, 211),
							Skin = Gui.ButtonSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/team/lb_contact_button_normal.tga", Vector4(5, 5, 5, 5)),
								HoverImage = Gui.Image("LobbyUI/team/lb_contact_button_hover.tga", Vector4(5, 5, 5, 5)),
								DownImage = Gui.Image("LobbyUI/team/lb_contact_button_down.tga", Vector4(5, 5, 5, 5)),
								DisabledImage = Gui.Image("LobbyUI/team/lb_contact_button_normal.tga", Vector4(5, 5, 5, 5)),			
							},
							
						},

						Gui.Button "btn_no"
						{
							--Style = "MessageBoxStyle.Button",
							Size = Vector2(104, 40),
							TextColor = ARGB(255, 211, 211, 211),
							Padding = Vector4(0, 0, 0, 7),
							HighlightTextColor = ARGB(255, 211, 211, 211),
							Skin = Gui.ButtonSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/team/lb_contact_button_normal.tga", Vector4(5, 5, 5, 5)),
								HoverImage = Gui.Image("LobbyUI/team/lb_contact_button_hover.tga", Vector4(5, 5, 5, 5)),
								DownImage = Gui.Image("LobbyUI/team/lb_contact_button_down.tga", Vector4(5, 5, 5, 5)),
								DisabledImage = Gui.Image("LobbyUI/team/lb_contact_button_normal.tga", Vector4(5, 5, 5, 5)),			
							},
							Text = lang:GetText("取　消"),
							Margin = Vector4(15, 0, 15, 0),
						},
				},
			},
		}
		

		modal_window = ModalWindow.Show()
		msgBox = Gui.Create(modal_window.root)(page)

       	msgBox.tb.Text = ""
       	
         local funcConfirm = function(sender, e)
        	--print("EntranceFlag in event")
        	--print(entranceFlag)
            if entranceFlag==2 then
	        	if STATE then
	        		STATE.AutoPassword = msgBox.tb.Text
	        		STATE:ContinueAutoEnterRoom()
	        	else
	        		print("WTF?: No state lobby during auto changing")
	        	end
	        else
   	            password = msgBox.tb.Text
	            if STATE and STATE.AmILeader then
	                STATE:TeamEnterRoom(room_info.id,password)
	            else
	                STATE:EnterRoom(room_info.id,password)
	            end
			end
        	msgBox.root.Parent = nil
			ModalWindow.Close()
        end
        
        msgBox.btn_yes.EventClick = funcConfirm
        msgBox.tb.EventValueEnter = funcConfirm
        
		msgBox.btn_no.EventClick = function(sender, e)
            if entranceFlag==2 then
	        	if STATE then
	        		STATE:CancelAutoChange()
	        	else
	        		print("WTF?: No state lobby during auto changing")
	        	end
	        end
			msgBox.root.Parent = nil
			ModalWindow.Close()
		end

		msgBox.tb.Focused = true
		return
	end 
        

	modalWin = ModalWindow.Show()
	msgBox.root.Parent = modalWin.root

    msgBox.tb.Text = ""
	msgBox.tb.Focused = true
end

