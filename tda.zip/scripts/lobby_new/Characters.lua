module("L_Characters", package.seeall)

root_ui = nil
index_tz = 1
main_character_window_ui = nil
main_props_window_ui = nil
avatart_main_ui = nil
packge_main_ui = nil
user_bag_ui = nil
user_bag_info_ui = nil
ib_weapon_ui = nil
ib_dress_ui = nil
ib_accessories_ui = nil
prop_window_ui = nil
Renewals_window_ui = nil

current_selected = 0
current_selected_ibtn_index = -1
current_selected_item_class = -1

Renewals_window_page_ui = nil

--当前购买方式
current_goods_price_info = nil

--当前购物车结算方式
current_selected_price_way_cars = {1, 1, 1, 1, 1, 1, 1}

--当前购物车购买方式
current_selected_price_unit_cars = {1, 1, 1, 1, 1, 1, 1}

current_selected_type = {{4, 4}, {5, 1}, {4, 7}, {4, 1}, {5, 2}, {4, 2}, {8, 0}}

current_selected_type_index = 1

--选择的结算方式
current_selected_price_way = 1
price_way = {lang:GetText("FC点"), lang:GetText("C币"), lang:GetText("抵用券")}
price_unit = {lang:GetText("FC点"), lang:GetText("C币"), lang:GetText("抵用券")}
--结算方式
unittype_way = {lang:GetText("永久"), lang:GetText("个"), lang:GetText("天")}

--当前选择的购买方式 1：3天 2：7天 3：三十天 4：永久
cost_mode = 1

--VIP宝箱
playeritemid = 0

Vipchest_Window = nil
Vip_Chest_Win_ui = nil
local Vip_Box_Choose_Start = false
VipTime_speed = 1
VipTime_Total = 8
VipBox_Which = 1
VipBox_Confirm = -1
VipBox_Total = 15
VipBox_Last_Lap = false
Vip_Box_Confirm_list =
{
	-1,
	-1,
	-1,
	-1,
	-1,
}
VipBox_Last_lap_step = 0
Vip_Box_list = nil

--魔灌
CharmBottle_Window = nil
Charm_Bottle_Win_ui = nil
Charm_Bottle_Open_Start = false

--魔罐开启物品信息
Charm_Bottle_Present = {nil,}

local magic_prize_history_list = nil
local magic_prize_history_weapon_list = {nil, nil, nil, nil, nil, nil, nil, nil, nil, nil}
magice_hummer_Info = {nil,}

--快速购买
Rapid_Shopping_Win_ui = nil
RapidShopping_Window = nil

--查看奖励
present_page = 1
present_list = nil
present_last_page = 0

--查看奖励界面
view_present_window_ui = nil

--魔罐打开弹出框
local Charm_Bottle_Open_Win_ui = nil
local Charm_Bottle_Open_Window = nil

index_xufei = nil

local function Creat_ChooseBox(line,list,index)
	return Gui.ItemBoxBtn
	{
		Style = "Gui.ItemBoxBtn_ib",
		Size = Vector2(116, 100),
		Location = Vector2(118*list,102*line),
		BackgroundColor = ARGB(255, 255, 255, 255),
		--BtnLocation = Vector2(45, 72),
		--BtnText = lang:GetText("购买"),
		--Enable = false,
		
		Skin = Gui.ItemBoxBtnSkin
		{
			NeutralNormalImage = Gui.Image("LobbyUI/ShoppingMall/vip_chest/lb_vipgifts_slot_01_normal.dds", Vector4(0, 0, 0, 0)),
--			NeutralHoverImage = Gui.Image("LobbyUI/ShoppingMall/vip_chest/lb_vipgifts_slot_flash.dds", Vector4(0, 0, 0, 0)),
			NeutralSelectedImage = Gui.Image("LobbyUI/ShoppingMall/vip_chest/lb_vipgifts_slot_01_normal.dds", Vector4(0, 0, 0, 0)),
			NeutralDisabledImage = Gui.Image("LobbyUI/ShoppingMall/vip_chest/lb_vipgifts_slot_01_disabled.dds", Vector4(0, 0, 0, 0)),
		},
		
		--ItemIcon = Gui.Icon("LobbyUI/ibt_icon/magic_4.tga"),
		Padding = Vector4(5,5,5,5),
		
		--ItemIconPastDue = Gui.Icon("LobbyUI/ShoppingMall/vip_chest/lb_vipgifts_slot_flash.dds"),
		
		--ToolTips 行为
		EventMouseEnter = function(sender, e)
			if sender.Loading == false then
				if index <= 15 then
					L_ToolTips.FillToolTipsVIPPresent(index, L_Characters.Vip_Chest_Win_ui.Vip_Chest_root, L_Characters.Vip_Box_list)
				elseif Vip_Box_Confirm_list[index - 15] ~= -1 then
					L_ToolTips.FillToolTipsVIPPresent(Vip_Box_Confirm_list[index - 15], L_Characters.Vip_Chest_Win_ui.Vip_Chest_root, L_Characters.Vip_Box_list)
				end
			end
		end,
		EventToolTipsShow = function(sender, e)
			if index <= 15 or Vip_Box_Confirm_list[index - 15] ~= -1 then
				local loc = sender.Location + sender.Parent.Location + sender.Parent.Parent.Location
				L_ToolTips.ShowToolTipsShowWindow(sender,Vector2(1200, 900),loc)
			end
		end,
		EventMouseLeave = function(sender, e)
			if index <= 15 or Vip_Box_Confirm_list[index - 15] ~= -1 then
				L_ToolTips.HideToolTipsWindow()
			end
		end,
	}
end

local Vip_Chest_Win =
{
	Gui.Control "Vip_Chest_root"
	{	
		Size = Vector2(1200, 900),
		BackgroundColor = ARGB(0, 255, 255, 255),
		Location = Vector2(0, 0),
		
		Gui.Label "lab_timer_ctr"
		{
			Size = Vector2(1000,1000),
			Location = Vector2(0, 0),
			BackgroundColor = ARGB(0, 255, 255, 255),
			Visible = false,
			UseTimer = true,
			
			EventClose = function()
				L_Characters.ChangeVipBox()
				if L_Characters.VipTime_Total > 0 then
					L_Characters.VipTime_Total = L_Characters.VipTime_Total - L_Characters.VipTime_speed
					if L_Characters.VipTime_speed > 0.1 then
						L_Characters.VipTime_speed = L_Characters.VipTime_speed - 0.2
						if L_Characters.VipTime_speed < 0.1 then
							L_Characters.VipTime_speed = 0.1
						end
					end
				elseif L_Characters.VipTime_Total <= 0 then
					L_Characters.SetEndTimeSpeed()
				end
				SetVipBoxTime(L_Characters.VipTime_speed)
				gui:PlayAudio("kUIA_MVPMOVE")
			end
		},
		
		Gui.Control
		{	
			Size = Vector2(676, 744),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Location = Vector2(257, 78),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/vip_chest/lb_vipgifts_bg_01.dds", Vector4(64, 0, 64, 0)),
			},
			
			Gui.Control
			{	
				Size = Vector2(104, 24),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Location = Vector2(285, 30),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/vip_chest/lb_vipgifts_title01.dds", Vector4(64, 0, 64, 0)),
				},
			},
			
			Gui.Label
			{
				Size = Vector2(133, 28),
				Location = Vector2(50, 80),
				TextColor = ARGB(255, 255, 255, 255),
				FontSize = 18,
				TextAlign = "kAlignRightMiddle",
				Text = lang:GetText("开启机会"),
				BackgroundColor = ARGB(0,255,255,255),
				TextPadding = Vector4(0,0,0,5),
			},
			
			Gui.Label "Vip_Box_chance_num"
			{
				Size = Vector2(52, 28),
				Location = Vector2(185, 80),
				TextColor = ARGB(255, 255, 216, 0),
				FontSize = 18,
				TextAlign = "kAlignCenterMiddle",
				Text = "0",
				BackgroundColor = ARGB(255,255,255,255),
				TextPadding = Vector4(0,0,0,5),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/vip_chest/lb_vipgifts_numberbar01.dds", Vector4(0, 0, 0, 0)),
				},
			},
				
			Gui.Label
			{
				Size = Vector2(175, 28),
				Location = Vector2(244, 80),
				TextColor = ARGB(255, 255, 255, 255),
				FontSize = 18,
				TextAlign = "kAlignRightMiddle",
				Text = lang:GetText("此次开启需"),
				BackgroundColor = ARGB(0,255,255,255),
				TextPadding = Vector4(0,0,0,5),
			},
			
			Gui.Label "Vip_Box_consume_money"
			{
				Size = Vector2(52, 28),
				Location = Vector2(421, 80),
				TextColor = ARGB(255, 255, 216, 0),
				FontSize = 18,
				TextAlign = "kAlignCenterMiddle",
				Text = "0",
				BackgroundColor = ARGB(255,255,255,255),
				TextPadding = Vector4(0,0,0,5),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/vip_chest/lb_vipgifts_numberbar01.dds", Vector4(0, 0, 0, 0)),
				},
			},
			
			Gui.Label
			{
				Size = Vector2(150, 28),
				Location = Vector2(475, 80),
				TextColor = ARGB(255, 255, 255, 255),
				FontSize = 18,
				TextAlign = "kAlignLeftMiddle",
				Text = lang:GetText("个VIP保险柜"),
				BackgroundColor = ARGB(0,255,255,255),
				TextPadding = Vector4(0,0,0,5),
			},
			
			Gui.Label
			{
				Size = Vector2(369, 28),
				Location = Vector2(50, 106),
				TextColor = ARGB(255, 255, 255, 255),
				FontSize = 18,
				TextAlign = "kAlignRightMiddle",
				Text = lang:GetText("剩余"),
				BackgroundColor = ARGB(0,255,255,255),
				TextPadding = Vector4(0,0,0,5),
			},
			
			Gui.Label "Vip_Box_money"
			{
				Size = Vector2(52, 28),
				Location = Vector2(421, 106),
				TextColor = ARGB(255, 255, 216, 0),
				FontSize = 18,
				TextAlign = "kAlignCenterMiddle",
				Text = "0",
				BackgroundColor = ARGB(255,255,255,255),
				TextPadding = Vector4(0,0,0,5),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/vip_chest/lb_vipgifts_numberbar01.dds", Vector4(0, 0, 0, 0)),
				},
			},
			
			Gui.Label
			{
				Size = Vector2(150, 28),
				Location = Vector2(475, 106),
				TextColor = ARGB(255, 255, 255, 255),
				FontSize = 18,
				TextAlign = "kAlignLeftMiddle",
				Text = lang:GetText("个VIP保险柜"),
				BackgroundColor = ARGB(0,255,255,255),
				TextPadding = Vector4(0,0,0,5),
			},	
			
			Gui.Control "choose_box"
			{	
				Size = Vector2(590, 305),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Location = Vector2(44, 140),

				Creat_ChooseBox(0,0,1),
				Creat_ChooseBox(0,1,2),
				Creat_ChooseBox(0,2,3),
				Creat_ChooseBox(0,3,4),
				Creat_ChooseBox(0,4,5),
				
				Creat_ChooseBox(1,4,6),
				Creat_ChooseBox(1,3,7),
				Creat_ChooseBox(1,2,8),
				Creat_ChooseBox(1,1,9),
				Creat_ChooseBox(1,0,10),
				
				Creat_ChooseBox(2,0,11),
				Creat_ChooseBox(2,1,12),
				Creat_ChooseBox(2,2,13),
				Creat_ChooseBox(2,3,14),
				Creat_ChooseBox(2,4,15),
			},
			
			Gui.Control
			{	
				Size = Vector2(618, 108),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Location = Vector2(29, 450),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/vip_chest/lb_vipgifts_bg_02.dds", Vector4(0, 0, 0, 0)),
				},
				
				--开始
				Gui.Button "Vip_Box_Start"
				{
					Size = Vector2(320,64),
					Location = Vector2(147, 7),					
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/vip_chest/lb_vipgifts_button_01_normal.dds", Vector4(50, 0, 50, 0)),
						HoverImage = Gui.Image("LobbyUI/ShoppingMall/vip_chest/lb_vipgifts_button_01_hover.dds", Vector4(50, 0, 50, 0)),
						DownImage = Gui.Image("LobbyUI/ShoppingMall/vip_chest/lb_vipgifts_button_01_down.dds", Vector4(50, 0, 50, 0)),
						DisabledImage = Gui.Image("LobbyUI/ShoppingMall/vip_chest/lb_vipgifts_button_01_disabled.dds", Vector4(50, 0, 50, 0)),
					},
					EventClick = function()
						if math.ceil(Vip_Chest_Win_ui.Vip_Box_money.Text) < math.ceil(Vip_Chest_Win_ui.Vip_Box_consume_money.Text) then
							MessageBox.ShowWithTimer(1,lang:GetText("您的VIP保险柜不足！"))
							return
						end
						Vip_Chest_Win_ui.Vip_Box_Start.Enable = false
						Vip_Box_Choose_Start = true
						local args = {pid = ptr_cast(game.CurrentState):GetCharacterId(),playeritemid = playeritemid}
						rpc.safecall("vip_random_start", args, 
													function(data)
														if data.warning then
															MessageBox.ShowWithTimer(1,data.warning)
															Vip_Chest_Win_ui.Vip_Box_Start.Enable = true
															Vip_Box_Choose_Start = false
														else
															VipBox_Start(data)
														end
													end,
													function()
														Vip_Chest_Win_ui.Vip_Box_Start.Enable = true
														Vip_Box_Choose_Start = false
													end)
													
					end,
					
					Gui.Label
					{
						Size = Vector2(320,64),
						Location = Vector2(1, 1),
						TextColor = ARGB(255, 50, 50, 50),
						FontSize = 36,
						TextAlign = "kAlignCenterMiddle",
						Text = lang:GetText("开 始"),
						BackgroundColor = ARGB(0,255,255,255),
						TextPadding = Vector4(0,0,0,8),
					},
					
					Gui.Label
					{
						Size = Vector2(320,64),
						Location = Vector2(0, 0),
						TextColor = ARGB(255, 255, 210, 0),
						FontSize = 36,
						TextAlign = "kAlignCenterMiddle",
						Text = lang:GetText("开 始"),
						BackgroundColor = ARGB(0,255,255,255),
						TextPadding = Vector4(0,0,0,8),
					},
				},
			},
			
			Gui.Label
			{	
				Size = Vector2(564, 26),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Location = Vector2(59, 566),
				TextAlign = "kAlignCenterMiddle",
				TextColor = ARGB(255, 50, 50, 50),
				Text = lang:GetText("恭喜你获得以下物品"),
				FontSize = 20,
			},
			
			Gui.Label
			{	
				Size = Vector2(564, 26),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Location = Vector2(58, 565),
				TextAlign = "kAlignCenterMiddle",
				TextColor = ARGB(255, 255, 210, 0),
				Text = lang:GetText("恭喜你获得以下物品"),
				FontSize = 20,
			},
			
			Gui.Control "Vip_Box_Confirm_Box"
			{	
				Size = Vector2(590, 100),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Location = Vector2(44, 600),	
				
				Creat_ChooseBox(0,0,16),
				Creat_ChooseBox(0,1,17),
				Creat_ChooseBox(0,2,18),
				Creat_ChooseBox(0,3,19),
				Creat_ChooseBox(0,4,20),
			},
		},
		
		--退出
		Gui.Button
		{
			Size = Vector2(52,48),
			Location = Vector2(891, 73),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_normal.dds", Vector4(10, 10, 10, 10)),
				HoverImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_hover.dds", Vector4(10, 10, 10, 10)),
				DownImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_down.dds", Vector4(10, 10, 10, 10)),
				DisabledImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_disabled.dds", Vector4(0, 0, 0, 0)),	
			},
			EventClick = function()
				HideVipChestWin()
			end,
		},
	},
}

function CreateVipChestWin()
	HideVipChestWin()
	if Vip_Chest_Win_ui == nil then
		Vip_Chest_Win_ui = Gui.Create()(Vip_Chest_Win)
		--VIP宝箱界面初始化
		Vipchest_Window = ModalWindow.GetNew("Vip_Chest_Win_ui")
		Vipchest_Window.screen.AllowEscToExit = false
		Vipchest_Window.screen.Visible = false
		--Vipchest_Window.screen.EventEscPressed = HideVipChestWin
		Vipchest_Window.screen.EventEscPressed = nil
		Vipchest_Window.root.Size = Vector2(1200, 900)
		Vip_Chest_Win_ui.Vip_Chest_root.Parent = Vipchest_Window.root
	end
end

function ShowVipChestWin(data,id)
	--L_LobbyMain.On_Invite_State = false
	if L_Characters.Vipchest_Window and L_Characters.Vipchest_Window.screen then
		L_Characters.Vipchest_Window.screen.Visible = true
		--gui.EventEscPressed = HideVipChestWin
		gui.EventEscPressed = nil
		Vip_Chest_Win_ui.Vip_Box_Start.Enable = true
	end
	Vip_Box_Confirm_list = {-1, -1, -1, -1, -1}
	playeritemid = id
	Vip_Chest_Win_ui.Vip_Box_chance_num.Text = data.num
	Vip_Chest_Win_ui.Vip_Box_consume_money.Text = data.need
	Vip_Chest_Win_ui.Vip_Box_money.Text = data.vip_num
	Vip_Box_list = data.items
	FileVip_Box()
	FileVipBoxConfirmBox()
end

function FileVip_Box()
	local i = 1
	for _,v in ipairs(Vip_Box_list) do
		local ibbtn = ptr_cast(Vip_Chest_Win_ui.choose_box:GetChildByIndex(i - 1))
		ibbtn:OnDestroy()
		ibbtn.ItemLevel = nil
		if v.color == 0 then
			ibbtn.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..v.name..".tga")
		else
			ibbtn.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..v.name.."_"..v.color..".tga")
		end
		if v.common and v.common.rareLevel then
			ibbtn.ItemLevel = Skin.rarelevel[math.ceil(v.common.rareLevel/25)]
		end
		ibbtn.ItemIcon.alpha = 255
		ibbtn.Enable = true
		if v.item_num and v.common.type == 5 then
			CreatPresentNumCtr(ibbtn,v.item_num,116,100)
		elseif v.item_num and v.common.type == 4 and v.common.subtype == 7 then
			CreatPresentNumCtr(ibbtn,v.item_num,116,100)
		end
		i = i + 1
	end
end

function HideVipChestWin()
	if Vip_Box_Choose_Start then
		return
	end
	if L_Characters.Vipchest_Window and L_Characters.Vipchest_Window.screen and L_Characters.Vipchest_Window.screen.Visible then
		L_Characters.Vipchest_Window.screen.Visible = false	
		Vip_Chest_Win_ui = nil
		Vipchest_Window = nil
		VipBox_Confirm = -1
		
		if L_LobbyMain.current_character_storage > 3 then
			L_LobbyMain.current_character_storage = current_selected_type[current_selected_type_index][1]
			L_LobbyMain.FillClassStorage(current_selected_type[current_selected_type_index][2])
		else
			L_LobbyMain.FillClassStorage()
		end
	end
end

function GetConfirm(num)
	if num > 15 or num < 1 then
		return true
	end
	for i = 1, 5 do
		if num == Vip_Box_Confirm_list[i] then
			return true
		end
	end
	return false
end

function VipBox_Start(data)
	FileVipBoxFootBTN()
	if GetConfirm(data.stop_num + 1) then
		MessageBox.ShowWithConfirm(lang:GetText("数据处理错误"))
		--Vip_Chest_Win_ui.Vip_Box_Start.Enable = true
		Vip_Box_Choose_Start = false
		return
	end
	SetVipBox_Total()
	VipTime_speed = 1
	VipTime_Total = 5
	VipBox_Which = 15
	Vip_Chest_Win_ui.Vip_Box_chance_num.Text = data.num
	Vip_Chest_Win_ui.Vip_Box_consume_money.Text = data.need
	Vip_Chest_Win_ui.Vip_Box_money.Text = data.vip_num
	VipBox_Confirm = data.stop_num + 1
	VipBox_Last_Lap = false
	SetVipBoxTime(L_Characters.VipTime_speed)
	ChangeVipBox()
end

function SetVipBoxTime(timer)
	if timer < 0 then
		return
	end
	Vip_Chest_Win_ui.lab_timer_ctr.DisplayTime = timer
	Vip_Chest_Win_ui.lab_timer_ctr:Show()
end

function CancelVipBox()
	for i = 1, 15 do
		local ibbtn = ptr_cast(Vip_Chest_Win_ui.choose_box:GetChildByIndex(i - 1))
		ibbtn.ItemIconPastDue = nil
	end
end

function SetVipBox_Total()
	local TepNum = 0
	for i = 1, 15 do
		local ibbtn = ptr_cast(Vip_Chest_Win_ui.choose_box:GetChildByIndex(i - 1))
		if ibbtn.Enable then
			TepNum = TepNum + 1
		end
	end
	VipBox_Total = TepNum
end

function ChangeVipBox()
	CancelVipBox()
	local ibbtn = nil
	while 1 do
		VipBox_Which = VipBox_Which + 1
		if VipBox_Which > 15 then
			VipBox_Which = 1
		end
		ibbtn = ptr_cast(Vip_Chest_Win_ui.choose_box:GetChildByIndex(VipBox_Which - 1))
		if ibbtn.Enable then
			break
		end
	end
	ibbtn.ItemIconPastDue = Gui.Icon("LobbyUI/ShoppingMall/vip_chest/lb_vipgifts_slot_flash.dds")
end

function SetEndTimeSpeed()
	if VipBox_Last_Lap and VipBox_Which == VipBox_Confirm then
		L_Characters.VipTime_speed = -1
		CancelVipBox()
		local ibbtn = ptr_cast(Vip_Chest_Win_ui.choose_box:GetChildByIndex(VipBox_Confirm - 1))
		CreaterVipBoxShineBTN(ibbtn)
		if Vip_Chest_Win_ui.Vip_Box_chance_num.Text ~= "0" then
			Vip_Chest_Win_ui.Vip_Box_Start.Enable = true
		end
--[[		for i = 1 , 4 do
			if Vip_Box_Confirm_list[i] < 0 then
				Vip_Chest_Win_ui.Vip_Box_Start.Enable = true
				break
			end
		end]]
		gui:PlayAudio("kUIA_CONGRA_POP")
		Vip_Box_Choose_Start = false
		return
	end
	if VipBox_Which == VipBox_Confirm and VipBox_Last_Lap == false then
		VipBox_Last_Lap = true
		SetVipBox_Last_Num()
	end
	if VipBox_Last_Lap  and VipBox_Total - VipBox_Last_lap_step < 10 then
		L_Characters.VipTime_speed = L_Characters.VipTime_speed + 0.08
	end
	VipBox_Last_lap_step = VipBox_Last_lap_step + 1
end

function SetVipBox_Last_Num()
	VipBox_Last_lap_step = 1
end

function CreaterVipBoxShineBTN(m_parent)
	if Vip_Box_ShineBTN and Vip_Box_ShineBTN.Vip_Box_Shine_BTN then
		Vip_Box_ShineBTN.Vip_Box_Shine_BTN.Parent = nil
	end
	Vip_Box_ShineBTN = nil
	Vip_Box_ShineBTN = Gui.Create()
	{
		Gui.Button "Vip_Box_Shine_BTN"
		{
			Size = Vector2(116, 100),
			Location = Vector2(0, 0),
			BackgroundColor = ARGB(0, 255, 255, 255),
			blink = true,
			blinkwheelTimer = 0.6,
			Skin = Gui.ButtonSkin
			{
				--BackgroundImage = Gui.Image("LobbyUI/lb_menu_contact_normal.tga", Vector4(0, 0, 0, 0)),
				--HoverImage = Gui.Image("LobbyUI/lb_menu_contact_hover.tga", Vector4(0, 0, 0, 0)),
				--DownImage = Gui.Image("LobbyUI/lb_menu_contact_down.tga", Vector4(0, 0, 0, 0)),
				--DisabledImage = Gui.Image("LobbyUI/lb_menu_contact_disabled.tga", Vector4(0, 0, 0, 0)),
				TwinkleImage  = Gui.Image("LobbyUI/ShoppingMall/vip_chest/lb_vipgifts_slot_flash.dds", Vector4(0, 0, 0, 0)),
			},
			EventClick = function()
				FileVipBoxFootBTN()
			end,
			
			Gui.Label "lb_timer_ctr"
			{
				Size = Vector2(116, 100),
				Location = Vector2(0, 0),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Visible = false,
				UseTimer = true,
				DisplayTime = 2,
				EventClose = function()
					FileVipBoxFootBTN()
				end
			},
		},
	}
	Vip_Box_ShineBTN.lb_timer_ctr:Show()
	Vip_Box_ShineBTN.Vip_Box_Shine_BTN.Parent = m_parent
end

function FileVipBoxFootBTN()
	if Vip_Box_ShineBTN and Vip_Box_ShineBTN.Vip_Box_Shine_BTN then
		Vip_Box_ShineBTN.Vip_Box_Shine_BTN.Parent = nil
		Vip_Box_ShineBTN = nil
	end
	FileVipBoxConfirmlist()
	FileVipBoxConfirmBox()
	SetVipBoxEnableState()
end

function FileVipBoxConfirmlist()
	if VipBox_Confirm < 0 then
		return
	end
	for i = 1 , 5 do
		if Vip_Box_Confirm_list[i] < 0 then
			Vip_Box_Confirm_list[i] = VipBox_Confirm
			VipBox_Confirm = -1
			break
		end
	end
end

function SetVipBoxEnableState()
	for i = 1, 5 do
		if Vip_Box_Confirm_list[i] > 0 then
			local ibbtn = ptr_cast(Vip_Chest_Win_ui.choose_box:GetChildByIndex(Vip_Box_Confirm_list[i] - 1))
			ibbtn.Enable = false
			ibbtn.ItemIcon.alpha = 80
			ibbtn:OnDestroy()
		end
	end
end

function FileVipBoxConfirmBox()
	local ibbtn = nil
	local v = nil
	for i = 1 , 5 do
		ibbtn = ptr_cast(Vip_Chest_Win_ui.Vip_Box_Confirm_Box:GetChildByIndex(i - 1))
		ibbtn:OnDestroy()
		ibbtn.ItemLevel = nil
		if Vip_Box_Confirm_list[i] > 0 then
			v = Vip_Box_Confirm_list[i]
			if Vip_Box_list[v].color == 0 then
				ibbtn.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..Vip_Box_list[v].name..".tga")
			else
				ibbtn.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..Vip_Box_list[v].name.."_"..Vip_Box_list[v].color..".tga")
			end
			if Vip_Box_list[v].common and Vip_Box_list[v].common.rareLevel then
				ibbtn.ItemLevel = Skin.rarelevel[math.ceil(Vip_Box_list[v].common.rareLevel/25)]
			end
			if Vip_Box_list[v].item_num and Vip_Box_list[v].common.type == 5 then
				CreatPresentNumCtr(ibbtn,Vip_Box_list[v].item_num,116,100)
			elseif Vip_Box_list[v].item_num and Vip_Box_list[v].common.type == 4 and Vip_Box_list[v].common.subtype == 7 then
				CreatPresentNumCtr(ibbtn,Vip_Box_list[v].item_num,116,100)
			end
		else
			ibbtn.ItemLevel = nil
			ibbtn.ItemIcon = nil
		end
	end
end

--魔灌界面
local Charm_Bottle_Win =
{
	Gui.Control "Charm_Bottle_root"
	{	
		Size = Vector2(860, 532),
		BackgroundColor = ARGB(0, 255, 255, 255),
		Dock = "kDockCenter",
		
		Gui.Control
		{	
			Size = Vector2(850, 522),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Location = Vector2(0, 5),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/main_bar01.dds", Vector4(20, 20, 20, 20)),
			},
			
			Gui.Label "lab_timer_ctr"
			{
				Size = Vector2(10,10),
				Location = Vector2(0, 0),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Visible = false,
				UseTimer = true,
				DisplayTime = 120,
				
				EventClose = function()
					Get_magic_box_history_list()
				end
			},
			
			Gui.Control
			{	
				Size = Vector2(409, 488),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Location = Vector2(17, 18),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/main_bar02.dds", Vector4(8, 8, 8, 8)),
				},
				
				Gui.Control
				{	
					Size = Vector2(396, 340),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Location = Vector2(9, 1),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_bottle_bar.dds", Vector4(0, 0, 0, 0)),
					},
					
					Gui.FlashControl "Charm_Bottle_Normal"
					{
						Text = "lb_anime02_bottle",
						Location = Vector2(-106, -42),
						Size = Vector2(600, 480),
						BackgroundColor = ARGB(255, 255, 255, 255),
					},
					
					Gui.Button
					{
						Size = Vector2(230,125),
						Location = Vector2(80, 180),
						BackgroundColor = ARGB(0, 255, 255, 255),
						
						EventClick = function()
							local args = {page = 1}
							rpc.safecall("magic_box_gift_list", args, 
												function (data)
													if data.warning then
														MessageBox.ShowWithTimer(1,data.warning)
													else
														present_page = data.page
														present_list = data.items
														present_last_page = data.is_last_page
														ShowViewPresentWindow()
													end
												end)
						end,
					},
					
					Gui.Label
					{
						Size = Vector2(160, 20),
						Location = Vector2(20, 314),
						TextColor = ARGB(255, 211, 211, 211),
						FontSize = 14,
						TextAlign = "kAlignRightMiddle",
						Text = lang:GetText("开启需要消耗"),
						BackgroundColor = ARGB(0,255,255,255),
						TextPadding = Vector4(0,0,0,5),	
					},
					
					Gui.Label "lb_hummer_need_nums"
					{
						Size = Vector2(20, 20),
						Location = Vector2(182, 313),
						TextColor = ARGB(255, 255, 0, 0),
						FontSize = 16,
						TextAlign = "kAlignCenterMiddle",
						Text = "15",
						BackgroundColor = ARGB(0,255,255,255),
						TextPadding = Vector4(0,0,0,5),
					},
					
					Gui.Label
					{
						Size = Vector2(160, 20),
						Location = Vector2(204, 314),
						TextColor = ARGB(255, 211, 211, 211),
						FontSize = 14,
						TextAlign = "kAlignLeftMiddle",
						Text = lang:GetText("张密码卡"),
						BackgroundColor = ARGB(0,255,255,255),
						TextPadding = Vector4(0,0,0,5),	
					},
				},
				
				Gui.Control
				{	
					Size = Vector2(388, 140),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Location = Vector2(9, 340),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/warehouse_bar.dds", Vector4(52, 60, 56, 20)),
					},
					
					
					Gui.Label
					{
						Size = Vector2(100, 28),
						Location = Vector2(10, 12),
						TextColor = ARGB(255, 211, 211, 211),
						FontSize = 16,
						TextAlign = "kAlignCenterMiddle",
						Text = lang:GetText("仓库中现有："),
						BackgroundColor = ARGB(0,255,255,255),
						TextPadding = Vector4(0,0,0,5),
					},
					
					Gui.Control
					{	
						Size = Vector2(36, 36),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Location = Vector2(107, 9),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_icon_bottle.dds", Vector4(0, 0, 0, 0)),
						},
					},
					
					Gui.Label "lb_magic_box_nums"
					{
						Size = Vector2(64, 28),
						Location = Vector2(147, 12),
						TextColor = ARGB(255, 211, 211, 211),
						FontSize = 16,
						TextAlign = "kAlignCenterMiddle",
						Text = "0",
						BackgroundColor = ARGB(255,255,255,255),
						TextPadding = Vector4(0,0,0,5),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/number_bar.dds",Vector4(0, 0, 0, 0)),
						},	
					},
					
	--[[					Gui.Button
					{
						Size = Vector2(32,32),
						Location = Vector2(205, 12),
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_buy_button01_normal.dds", Vector4(0, 0, 0, 0)),
							HoverImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_buy_button01_hover.dds", Vector4(0, 0, 0, 0)),
							DownImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_buy_button01_down.dds", Vector4(0, 0, 0, 0)),
							DisabledImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_buy_button01_normal.dds", Vector4(0, 0, 0, 0)),
						},
						EventClick = function()
							L_Characters.ShowRapidShoppingWin()
						end,
					},
	]]					
					Gui.Control
					{	
						Size = Vector2(36, 36),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Location = Vector2(232, 9),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_icon_hammer.dds", Vector4(0, 0, 0, 0)),
						},
					},
					
					Gui.Label "lb_hummer_nums"
					{
						Size = Vector2(64, 29),
						Location = Vector2(270, 12),
						TextColor = ARGB(255, 211, 211, 211),
						FontSize = 16,
						TextAlign = "kAlignCenterMiddle",
						Text = "0",
						BackgroundColor = ARGB(255,255,255,255),
						TextPadding = Vector4(0,0,0,5),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/number_bar.dds",Vector4(0, 0, 0, 0)),
						},	
					},
					
					Gui.Button
					{
						Size = Vector2(32,32),
						Location = Vector2(342, 12),
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_buy_button01_normal.dds", Vector4(0, 0, 0, 0)),
							HoverImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_buy_button01_hover.dds", Vector4(0, 0, 0, 0)),
							DownImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_buy_button01_down.dds", Vector4(0, 0, 0, 0)),
							DisabledImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_buy_button01_normal.dds", Vector4(0, 0, 0, 0)),
						},
						EventClick = function()
							L_Characters.ShowRapidShoppingWin()
						end,
					},
					
					Gui.Button
					{
						Size = Vector2(180,64),
						Location = Vector2(12, 62),
						TextColor = ARGB(255, 255, 174, 20),
						FontSize = 24,
						Text = lang:GetText("查看奖励"),
						HighlightTextColor = ARGB(255, 255, 174, 20),
						TextAlign = "kAlignCenterMiddle",
						Padding = Vector4(0, 0, 0, 5),
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_open_button01_normal.dds", Vector4(10, 0, 10, 0)),
							HoverImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_open_button01_hover.dds", Vector4(10, 0, 10, 0)),
							DownImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_open_button01_down.dds", Vector4(10, 0, 10, 0)),
							DisabledImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_open_button01_normal.dds", Vector4(10, 0, 10, 0)),
						},
						EventClick = function()
							local args = {page = 1}
							rpc.safecall("magic_box_gift_list", args, 
												function (data)
													if data.warning then
														MessageBox.ShowWithTimer(1,data.warning)
													else
														present_page = data.page
														present_list = data.items
														present_last_page = data.is_last_page
														ShowViewPresentWindow()
													end
												end)
						end,
					},
					
					Gui.Button "BTN_Charm_Start"
					{
						Size = Vector2(180,64),
						Location = Vector2(200, 62),
						TextColor = ARGB(255, 255, 174, 20),
						FontSize = 26,
						Text = lang:GetText("开  启"),
						HighlightTextColor = ARGB(255, 255, 174, 20),
						TextAlign = "kAlignCenterMiddle",
						Padding = Vector4(0, 0, 0, 5),
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_open_button01_normal.dds", Vector4(10, 0, 10, 0)),
							HoverImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_open_button01_hover.dds", Vector4(10, 0, 10, 0)),
							DownImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_open_button01_down.dds", Vector4(10, 0, 10, 0)),
							DisabledImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_open_button01_normal.dds", Vector4(10, 0, 10, 0)),
						},
						EventClick = function()
							if Charm_Bottle_Win_ui.lb_magic_box_nums.Text == "0" then
								MessageBox.ShowWithTimer(1,lang:GetText("您的密码箱不足！"))
								return
							end
							if tonumber(Charm_Bottle_Win_ui.lb_hummer_nums.Text) < tonumber(Charm_Bottle_Win_ui.lb_hummer_need_nums.Text) then
								L_Characters.ShowRapidShoppingWin()
								MessageBox.ShowWithTimer(1,lang:GetText("您的密码卡不足！请购买后使用！"))
								return
							end
							Charm_Bottle_Win_ui.BTN_Charm_Start.Enable = false
							Charm_Bottle_Open_Start = true
							local args = {pid = ptr_cast(game.CurrentState):GetCharacterId(), playeritemid = playeritemid}
							rpc.safecall("magic_box_open", args,
														function(data)
															if data.warning then
																MessageBox.ShowWithTimer(1,data.warning)
																Charm_Bottle_Open_Start = false
															else
																Charm_Bottle_Present[1] = data.item
																Charm_Bottle_Win_ui.lb_magic_box_nums.Text = data.box_num
																Charm_Bottle_Win_ui.lb_hummer_nums.Text = data.hummer_num
																Charm_Bottle_Win_ui.lb_hummer_need_nums.Text = data.need
																CreatFlashControl()
																if flash_ctr and flash_ctr.Fctr_Charm_Bottle_Open then
																	if flash_ctr.CCtr_Timer then																						
																		flash_ctr.CCtr_Timer.Skin = Gui.ControlSkin
																		{
																			BackgroundImage = Gui.Image("LobbyUI/ibt_icon/"..data.item.name..".tga", Vector4(0, 0, 0, 0)),
																		}
																		flash_ctr.CCtr_Timer:Clear()
																		flash_ctr.CCtr_Timer:InsertMovePoint(Vector2(210,220),1.3,Vector2(100,55),ARGB(0,255,255,255))
																		flash_ctr.CCtr_Timer:InsertMovePoint(Vector2(210,220),1.3,Vector2(100,55),ARGB(255,255,255,255))
																		flash_ctr.CCtr_Timer:InsertMovePoint(Vector2(220,70),1.50,Vector2(160,88),ARGB(255,255,255,255))
																		flash_ctr.CCtr_Timer:InsertMovePoint(Vector2(230,155),1.70,Vector2(200,110),ARGB(255,255,255,255))
																		flash_ctr.CCtr_Timer:SetSize_Picture()
																	end
																	flash_ctr.Fctr_Charm_Bottle_Open.Parent = Charm_Bottle_Win_ui.Charm_Bottle_root
																	gui:PlayAudio("kUIA_OPEN_CODECASE")
																	Charm_Bottle_Win_ui.Charm_Bottle_Normal.Visible = false
																end
															end
															
														end)
						end,
					},
				},
			},
			
			Gui.Control
			{	
				Size = Vector2(400, 488),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Location = Vector2(432, 18),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/main_bar02.dds", Vector4(8, 8, 8, 8)),
				},
				
				Gui.Control
				{	
					Size = Vector2(394, 477),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Location = Vector2(3, 6),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_info_bar01.dds", Vector4(22, 45, 100, 26)),
					},
					
					Gui.Label
					{
						Size = Vector2(175, 20),
						Location = Vector2(16, 14),
						TextColor = ARGB(255, 211, 211, 211),
						FontSize = 16,
						TextAlign = "kAlignCenterMiddle",
						Text = lang:GetText("奖励记录"),
						BackgroundColor = ARGB(0,255,255,255),
						TextPadding = Vector4(0,0,0,5),
					},
										
					
				},
			},
			Gui.ScrollableControl "scroll"
			{
				Size = Vector2(370, 424),
				Location = Vector2(446, 60),
				AutoScroll = true,
				--VScrollBarPos = Vector2(-40,0),
				--Default_Width = 60,
				--Default_Size = 60,
				VScrollBarButtonSize = 32,
				VScrollBarWidth = 32,
				VScrollBarHeight = 424,
				VScrollBarDisplay = true,
				AutoScrollMinSize = Vector2(120,1000),
				BackgroundColor = ARGB(255,255,255,255),
				--Style = "Gui.MessagePanel",
				
				Gui.FlowLayout "scrollLayout"
				{
					AutoSize = true,
					LineSpace = 0,
				},
			},
		},
		
		--退出
		Gui.Button
		{
			Size = Vector2(48,48),
			Location = Vector2(797, 0),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_normal.dds", Vector4(10, 10, 10, 10)),
				HoverImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_hover.dds", Vector4(10, 10, 10, 10)),
				DownImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_down.dds", Vector4(10, 10, 10, 10)),
				DisabledImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_disabled.dds", Vector4(0, 0, 0, 0)),	
			},
			EventClick = function()
				HideCharmBottleWin()
			end,
		},
	}
}

function CreateCharmBottleWin()
	HideCharmBottleWin()
	if Charm_Bottle_Win_ui == nil then
		Charm_Bottle_Win_ui = Gui.Create()(Charm_Bottle_Win)
		--魔灌界面初始化
		CharmBottle_Window = ModalWindow.GetNew("Charm_Bottle_Win_ui")
		CharmBottle_Window.screen.AllowEscToExit = false
		CharmBottle_Window.screen.Visible = false
		--CharmBottle_Window.screen.EventEscPressed = HideCharmBottleWin
		CharmBottle_Window.screen.EventEscPressed = nil
		CharmBottle_Window.root.Size = Vector2(1200, 900)
		Charm_Bottle_Win_ui.Charm_Bottle_root.Parent = CharmBottle_Window.root
	end
end
function ShowCharmBottleWin(data,id)
	--L_LobbyMain.On_Invite_State = false
	if L_Characters.CharmBottle_Window and L_Characters.CharmBottle_Window.screen then
		L_Characters.CharmBottle_Window.screen.Visible = true
		--gui.EventEscPressed = HideCharmBottleWin
		gui.EventEscPressed = nil
	end
	playeritemid = id
	Charm_Bottle_Win_ui.lb_magic_box_nums.Text = data.box_num
	Charm_Bottle_Win_ui.lb_hummer_nums.Text = data.hummer_num
	Charm_Bottle_Win_ui.lb_hummer_need_nums.Text = data.need
	magic_prize_history_list = data.items
	magice_hummer_Info[1] = data.hummer
	L_Characters.InitialList()
	Charm_Bottle_Win_ui.lab_timer_ctr:Show()
end

function HideCharmBottleWin()
	if Charm_Bottle_Open_Start then
		return
	end
	if L_Characters.RapidShopping_Window and L_Characters.RapidShopping_Window.screen and L_Characters.RapidShopping_Window.screen.Visible then
		L_Characters.RapidShopping_Window.screen.Visible = false
		Rapid_Shopping_Win_ui = nil
		return
	end
	if ViewPresent_Window and ViewPresent_Window.screen and ViewPresent_Window.screen.Visible then
		ViewPresent_Window.screen.Visible = false
		view_present_window_ui = nil
		return
	end
	if Charm_Bottle_Open_Window and Charm_Bottle_Open_Window.screen and Charm_Bottle_Open_Window.screen.Visible then
		HideCharmBottleOpenPresentWin()
		return
	end
	if L_Characters.CharmBottle_Window and L_Characters.CharmBottle_Window.screen and L_Characters.CharmBottle_Window.screen.Visible then
		L_Characters.CharmBottle_Window.screen.Visible = false	
		Charm_Bottle_Win_ui = nil
		CharmBottle_Window = nil
		if L_LobbyMain.current_character_storage > 3 then
			L_LobbyMain.current_character_storage = current_selected_type[current_selected_type_index][1]
			L_LobbyMain.FillClassStorage(current_selected_type[current_selected_type_index][2])
		else
			L_LobbyMain.FillClassStorage()
		end
	end
end

function InitialList()
	if Charm_Bottle_Win_ui == nil then
		return
	end
	Charm_Bottle_Win_ui.scrollLayout:OnDestroy()
	local Tepnum = 0
	for _,v in ipairs(magic_prize_history_list) do
		Tepnum = Tepnum + 1
		CreateInfoControl(Charm_Bottle_Win_ui.scrollLayout,Tepnum,v)
		magic_prize_history_weapon_list[Tepnum] = v.item
	end
	while Tepnum < 6 do
		Tepnum = Tepnum + 1
		CreateInfoControl(Charm_Bottle_Win_ui.scrollLayout,Tepnum)
	end
	Charm_Bottle_Win_ui.scroll.AutoScrollMinSize = Vector2(120,Tepnum*70)
end

function CreatFlashControl()
	flash_ctr = Gui.Create()
	{
		Gui.FlashControl "Fctr_Charm_Bottle_Open"
		{
			Text = "lb_bottle_bar",
			Location = Vector2(-80, -18),
			Size = Vector2(600, 480),
			BackgroundColor = ARGB(255, 255, 255, 255),
			
			Gui.ChangeControl "CCtr_Timer"
			{
				Location = Vector2(210,220),--200,136
				NormLocation = Vector2(210,220),
				Size = Vector2(200,110),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Normsize = Vector2(200,110),
				NormBackgroundColor = ARGB(0,255,255,255),
				
				EventPlayEnd = function(Sender,e)					
					ShowCharmBottleOpenPresentWin()
					Charm_Bottle_Win_ui.BTN_Charm_Start.Enable = true
					Charm_Bottle_Open_Start = false
					Get_magic_box_history_list()
				end,
			},
		},
	}
end

function CreateInfoControl(m_parent,num,v)
	local ctr = nil
	if v == nil then
		ctr = Gui.Create()
		{
			Gui.Control "ctr_local"
			{	
				Size = Vector2(355, 70),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Location = Vector2(0, 0),
			}
		}
	else
		ctr =  Gui.Create()
		{
			Gui.Control "ctr_local"
			{	
				Size = Vector2(355, 70),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Location = Vector2(0, 0),
				
				Gui.Label
				{
					Size = Vector2(120, 23),
					Location = Vector2(3, 15),
					TextColor = ARGB(255, 255, 174, 20),
					FontSize = 14,
					TextAlign = "kAlignCenterMiddle",
					Text = lang:GetText("恭喜"),
					BackgroundColor = ARGB(0,255,255,255),
					TextPadding = Vector4(0,0,0,5),
				},
				
				--等级十位
				Gui.Control "lb_UserLevel_Ten"
				{
					Location = Vector2(131, 10),
					Size = Vector2(14, 33),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_summary_number_6b.dds",Vector4(0, 0, 0, 0), Vector4(0, 0, 0.1, 1)),
					},
				},
				
				--等级十位百分比
				Gui.Control "lb_UserLevel_TenState"
				{
					Location = Vector2(131, 10),
					Size = Vector2(14, 33),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_summary_number_7b.dds",Vector4(0, 0, 0, 0), Vector4(0, 0, 0.1, 1)),
					},
					
				},
			
				--等级个位
				Gui.Control "lb_UserLevel_Anold"
				{
					Location = Vector2(144, 10),
					Size = Vector2(14, 33),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_summary_number_6b.dds", Vector4(0, 0, 0, 0),Vector4(0, 0, 0.1, 1)),
					},
				},

				--等级个位百分比
				Gui.Control "lb_UserLevel_AnoldState"
				{
					Location = Vector2(144, 10),
					Size = Vector2(14, 33),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_summary_number_7b.dds", Vector4(0, 0, 0, 0),Vector4(0, 0, 0.1, 1)),
					},
				},
				
				Gui.Label "lb_name"
				{
					Size = Vector2(170, 23),
					Location = Vector2(160, 15),
					TextColor = ARGB(255, 211, 211, 211),
					FontSize = 14,
					TextAlign = "kAlignCenterMiddle",
					Text = v.name,
					--Text = "WWWWWWWWWWWW",
					BackgroundColor = ARGB(0,255,255,255),
					TextPadding = Vector4(0,0,0,0),
				},
				
				Gui.Control
				{	
					Size = Vector2(355, 20),
					BackgroundColor = ARGB(0, 255, 255, 255),
					Location = Vector2(3, 46),
					Gui.Control
					{	
						Size = Vector2(355, 20),
						BackgroundColor = ARGB(0, 255, 255, 255),
						Location = Vector2(5, 0),
						
						Gui.Label
						{
							Size = Vector2(6.5*string.len(lang:GetText("获得:")), 20),
							Location = Vector2(0, 0),
							TextColor = ARGB(255, 211, 211, 211),
							FontSize = 14,
							TextAlign = "kAlignCenterMiddle",
							Text = lang:GetText("获得:"),
							BackgroundColor = ARGB(0,255,255,255),
							TextPadding = Vector4(0,0,0,0),
						},
						
						Gui.ItemBoxBtn
						{
							Style = "Gui.ItemBoxBtn_ib",
							Size = Vector2(7.25*string.len(v.item.display) + 5,20),
							Location = Vector2(6.5*string.len(lang:GetText("获得:")) + 2,0),
							--BtnLocation = Vector2(45, 72),
							--BtnText = lang:GetText("购买"),
							--Enable = false,
							BackgroundColor = ARGB(0,255,255,255),
							Skin = Gui.ItemBoxBtnSkin
							{
								--NeutralNormalImage = Gui.Image("LobbyUI/ShoppingMall/vip_chest/lb_vipgifts_slot_01_normal.dds", Vector4(0, 0, 0, 0)),
								--NeutralHoverImage = Gui.Image("LobbyUI/ShoppingMall/vip_chest/lb_vipgifts_slot_flash.dds", Vector4(0, 0, 0, 0)),
								--NeutralSelectedImage = Gui.Image("LobbyUI/ShoppingMall/vip_chest/lb_vipgifts_slot_01_normal.dds", Vector4(0, 0, 0, 0)),
								--NeutralDisabledImage = Gui.Image("LobbyUI/ShoppingMall/vip_chest/lb_vipgifts_slot_01_disabled.dds", Vector4(0, 0, 0, 0)),
							},
							
							--ItemIcon = Gui.Icon("LobbyUI/ibt_icon/machet_4.tga"),
							--Padding = Vector4(10,0,10,0),
							
							--ItemIconPastDue = Gui.Icon("LobbyUI/ShoppingMall/vip_chest/lb_vipgifts_slot_flash.dds"),
							EventMouseEnter = function(sender, e)
								L_ToolTips.FillToolTipsVIPPresent(num, CharmBottle_Window.root, magic_prize_history_weapon_list)
							end,
							EventToolTipsShow = function(sender, e)
								local loc = sender.Location + sender.Parent.Location + sender.Parent.Parent.Location + sender.Parent.Parent.Parent.Location + sender.Parent.Parent.Parent.Parent.Location + sender.Parent.Parent.Parent.Parent.Parent.Location + sender.Parent.Parent.Parent.Parent.Parent.Parent.Location + sender.Parent.Parent.Parent.Parent.Parent.Parent.Parent.Location - Vector2(0,Charm_Bottle_Win_ui.scroll.VscrollBarValue)
								L_ToolTips.ShowToolTipsShowWindow(sender,Vector2(1200, 900),loc)
							end,
							EventMouseLeave = function(sender, e)
								L_ToolTips.HideToolTipsWindow()
							end,
							
							Gui.Label
							{
								Size = Vector2(7.25*string.len(v.item.display) + 5, 20),
								Location = Vector2(0, 0),
								TextColor = ARGB(255, 00, 210, 253),
								FontSize = 14,
								TextAlign = "kAlignLeftMiddle",
								Text = v.item.display,
								BackgroundColor = ARGB(0,255,255,255),
								TextPadding = Vector4(0,0,0,0),
							},
						},
						
						Gui.Label
						{
							Size = Vector2(100, 20),
							Location = Vector2(6.5*string.len(lang:GetText("获得:")) + 7.25*string.len(v.item.display) + 8, 0),
							TextColor = ARGB(255, 211, 211, 211),
							FontSize = 14,
							TextAlign = "kAlignLeftMiddle",
							Text = "×"..v.item.item_num,
							BackgroundColor = ARGB(0,255,255,255),
							TextPadding = Vector4(0,0,0,0),
						},
					},
				},
			},
		}
	end
	if num%2 == 1 then
		ctr.ctr_local.Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_bj01.dds", Vector4(0, 0, 0, 0)),
		}
	else
		ctr.ctr_local.Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_bj02.dds", Vector4(0, 0, 0, 0)),
		}
	end
	if v == nil then
		ctr.ctr_local.Parent = m_parent
		return
	end
	
	local Text_Begin = (v.rank % 10) * 0.1
	local Text_End   = Text_Begin + 0.1
	ctr.lb_UserLevel_Anold.Skin = Gui.ControlSkin
	{
		BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_summary_number_6b.dds",Vector4(0, 0, 0, 0), Vector4(Text_Begin, 0, Text_End, 1)),		
	}			
	local level_Percentage =  1.0 			
	if v.rank == 80 then
		level_Percentage =  1.0
	else
		level_Percentage = (v.exp - L_LobbyMain.LevelInfo_rpc_data[v.rank][2]) / (L_LobbyMain.LevelInfo_rpc_data[v.rank + 1][2] - L_LobbyMain.LevelInfo_rpc_data[v.rank][2])
	end
	ctr.lb_UserLevel_AnoldState.Location = Vector2(144, (36 - level_Percentage * 19))
	ctr.lb_UserLevel_AnoldState.Size = Vector2(14,(7 + level_Percentage * 19))
	ctr.lb_UserLevel_AnoldState.Skin = Gui.ControlSkin
	{
		BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_summary_number_7b.dds",Vector4(0, 0, 0, 0), Vector4(Text_Begin,(1 - ((7 + level_Percentage * 19) / 33)), Text_End, 1)),
	}
	
	Text_Begin   = ((v.rank % 100 - Text_Begin * 10) / 10) * 0.1
	Text_End     = Text_Begin + 0.1
	ctr.lb_UserLevel_Ten.Skin = Gui.ControlSkin
	{
		BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_summary_number_6b.dds",Vector4(0, 0, 0, 0), Vector4(Text_Begin, 0, Text_End, 1)),
	}
	ctr.lb_UserLevel_TenState.Location = Vector2(131, (36 - level_Percentage * 19))
	ctr.lb_UserLevel_TenState.Size = Vector2(14, (7 + level_Percentage * 19))
	ctr.lb_UserLevel_TenState.Skin = Gui.ControlSkin
	{
		BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_summary_number_7b.dds",Vector4(0, 0, 0, 0), Vector4(Text_Begin,(1 - ((7 + level_Percentage * 19) / 33)), Text_End, 1)),
	}
	
	ctr.ctr_local.Parent = m_parent
end

function Get_magic_box_history_list()
	Charm_Bottle_Win_ui.lab_timer_ctr:Show()
	rpc.safecall("magic_box_history_list", nil, 
									function(data)
										if data.warning then
											MessageBox.ShowWithTimer(1,data.warning)
										else
											magic_prize_history_list = data.items
											L_Characters.InitialList()
										end
									end)
end
--快速购买界面
local Rapid_Shopping_Win = 
{
	Gui.Control "Rapid_Shopping_root"
	{	
		Size = Vector2(1200, 900),
		BackgroundColor = ARGB(0, 255, 255, 255),
		Location = Vector2(0, 0),
		
		Gui.Control
		{	
			Size = Vector2(429, 375),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Dock = "kDockCenter",
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/main_bar01.dds", Vector4(20, 20, 20, 20)),
			},

			Gui.Control
			{	
				Size = Vector2(407, 352),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Location = Vector2(11, 12),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/main_bar02.dds", Vector4(8, 8, 8, 8)),
				},
				
				Gui.Label
				{
					Size = Vector2(405, 35),
					Location = Vector2(0, 0),
					TextColor = ARGB(255, 255, 210, 0),
					FontSize = 18,
					TextAlign = "kAlignLeftMiddle",
					Text = lang:GetText("快速购买"),
					BackgroundColor = ARGB(255,255,255,255),
					TextPadding = Vector4(8,0,0,8),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_onlinetime_bg_5.dds", Vector4(8, 8, 8, 8)),
					},
				},
				
				Gui.Control
				{	
					Size = Vector2(384, 260),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Location = Vector2(16, 39),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_01.dds", Vector4(40, 40, 40, 40)),
					},
					
					Gui.Control
					{	
						Size = Vector2(330, 208),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Location = Vector2(27, 10),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_06.dds", Vector4(32, 28, 32, 50)),
						},
						
						Gui.Label "name"
						{
							Size = Vector2(330, 28),
							Location = Vector2(0, 0),
							TextColor = ARGB(255, 255, 210, 0),
							FontSize = 18,
							TextAlign = "kAlignCenterMiddle",
							Text = lang:GetText("密码卡"),
							BackgroundColor = ARGB(0,255,255,255),
							TextPadding = Vector4(0,0,0,3),
						},
						
						Gui.TextArea "des"
						{
							Size = Vector2(270, 50),
							Location = Vector2(40, 110),
							TextColor = ARGB(255, 255, 210, 0),
							FontSize = 16,
							Readonly = true,
							Fold = true,
							BackgroundColor = ARGB(255,255,255,255),
						},
						
						Gui.Button
						{
							Size = Vector2(20,32),
							Location = Vector2(32, 167),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Skin = Gui.ButtonSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_fanye_button_normal_L.dds", Vector4(0, 0, 0, 0)),
								HoverImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_fanye_button_hover_L.dds", Vector4(0, 0, 0, 0)),
								DownImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_fanye_button_down_L.dds", Vector4(0, 0, 0, 0)),
								DisabledImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_fanye_button_disabled_L.dds", Vector4(0, 0, 0, 0)),
							},
							EventClick = function()
								Rapid_Shopping_Win_ui.Tbox_Totle_num.Text = math.ceil(tonumber(Rapid_Shopping_Win_ui.Tbox_Totle_num.Text)) - 1
							end,
						},
						
						Gui.Textbox "Tbox_Totle_num"
						{
							Size = Vector2(154, 34),
							Location = Vector2(89, 166),
							TextColor = ARGB(255, 255, 210, 0),
							FontSize = 24,
							Text = "1",
							BackgroundColor = ARGB(255,255,255,255),
							TextPadding = Vector4(71,0,0,0),
							InputNumberOnly = true,
							Skin = Gui.TextboxSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_04.dds", Vector4(12, 0, 12, 0)),
								ActiveImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_04.dds", Vector4(12, 0, 12, 0)),
								DisabledImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_04.dds", Vector4(12, 0, 12, 0)),
							},
							
							EventTextChanged = function()
								if Rapid_Shopping_Win_ui.Tbox_Totle_num.Text ~= "" then
									if math.ceil(tonumber(Rapid_Shopping_Win_ui.Tbox_Totle_num.Text)) > 99 then
										Rapid_Shopping_Win_ui.Tbox_Totle_num.Text = "99"
										return
									elseif math.ceil(tonumber(Rapid_Shopping_Win_ui.Tbox_Totle_num.Text)) < 1 then
										Rapid_Shopping_Win_ui.Tbox_Totle_num.Text = "1"
										return
									end
									if string.sub(Rapid_Shopping_Win_ui.Tbox_Totle_num.Text,1,1) == "0" then
										Rapid_Shopping_Win_ui.Tbox_Totle_num.Text = string.sub(Rapid_Shopping_Win_ui.Tbox_Totle_num.Text,2)
										return
									end
									Rapid_Shopping_Win_ui.Tbox_Totle_num.TextPadding = Vector4(77 - 6*string.len(Rapid_Shopping_Win_ui.Tbox_Totle_num.Text),0,0,0)
								end
								SetHummerTotalMoney()
							end,
							
							EventLeave = function()
								if Rapid_Shopping_Win_ui.Tbox_Totle_num.Text == "" then
									Rapid_Shopping_Win_ui.Tbox_Totle_num.Text = 1
								end
							end,
							
							EventValueNoNumber = function()
								Rapid_Shopping_Win_ui.lab_timer_ctr:Show()
							end,
						},
						
						Gui.Button
						{
							Size = Vector2(20,32),
							Location = Vector2(279, 167),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Skin = Gui.ButtonSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_fanye_button_normal_R.dds", Vector4(0, 0, 0, 0)),
								HoverImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_fanye_button_hover_R.dds", Vector4(0, 0, 0, 0)),
								DownImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_fanye_button_down_R.dds", Vector4(0, 0, 0, 0)),
								DisabledImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_fanye_button_disabled_R.dds", Vector4(0, 0, 0, 0)),
							},
							EventClick = function()
								Rapid_Shopping_Win_ui.Tbox_Totle_num.Text = math.ceil(tonumber(Rapid_Shopping_Win_ui.Tbox_Totle_num.Text)) + 1
							end,
						},
					},
					
					Gui.Label
					{
						Size = Vector2(140, 28),
						Location = Vector2(15, 220),
						TextColor = ARGB(255, 255, 210, 0),
						FontSize = 18,
						TextAlign = "kAlignCenterMiddle",
						Text = lang:GetText("您总共要支付"),
						BackgroundColor = ARGB(0,255,255,255),
						TextPadding = Vector4(0,0,0,3),
					},
					
					Gui.Label "Total_money"
					{
						Size = Vector2(118, 28),
						Location = Vector2(162, 220),
						TextColor = ARGB(255, 255, 210, 0),
						FontSize = 18,
						TextAlign = "kAlignCenterMiddle",
						Text = "0",
						BackgroundColor = ARGB(255,255,255,255),
						TextPadding = Vector4(0,0,0,3),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_03.dds", Vector4(8, 8, 8, 8)),
						},
					},
					
					Gui.Label
					{
						Size = Vector2(90, 28),
						Location = Vector2(287, 220),
						TextColor = ARGB(255, 255, 210, 0),
						FontSize = 18,
						TextAlign = "kAlignCenterMiddle",
						Text = lang:GetText("FC点"),
						BackgroundColor = ARGB(0,255,255,255),
						TextPadding = Vector4(0,0,0,3),
					},
					
					Gui.Label "lab_timer_ctr"
					{
						Size = Vector2(150,35),
						Location = Vector2(100, 207),
						BackgroundColor = ARGB(255, 255, 255, 255),
						TextColor = ARGB(255, 0, 0, 0),
						Visible = false,
						UseTimer = true,
						DisplayTime = 1,
						FontSize = 12,
						TextAlign = "kAlignCenterMiddle",
						Text = lang:GetText("只能输入数字0～9"),
						TextPadding = Vector4(0,8,0,0),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_05.dds", Vector4(37, 18, 14, 12)),
						},
						
						EventClose = function()
							
						end
					},
				},
				
				Gui.Button
				{
					Size = Vector2(180,44),
					Location = Vector2(113, 305),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Text = lang:GetText("购 买"),
					TextColor = ARGB(255, 229, 255, 252),
					TextAlign = "kAlignCenterMiddle",
					HighlightTextColor = ARGB(255, 229, 255, 252),
					Padding = Vector4(0, 0, 0, 5),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_onlinetime_button_2_normal.dds", Vector4(20, 0, 20, 0)),
						HoverImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_onlinetime_button_2_hover.dds", Vector4(20, 0, 20, 0)),
						DownImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_onlinetime_button_2_down.dds", Vector4(20, 0, 20, 0)),
						DisabledImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_onlinetime_button_2_disabled.dds", Vector4(20, 0, 20, 0)),
					},
					EventClick = function()
						local args = {num = Rapid_Shopping_Win_ui.Tbox_Totle_num.Text, pid = ptr_cast(game.CurrentState):GetCharacterId(), sid = magice_hummer_Info[1].sid}
						rpc.safecall("shop_fast_buy", args,
													function(data)
														if data.result == 0 then
															MessageBox.ShowWithTwoButtons(lang:GetText("你的FC点不足，请充值"),lang:GetText("充值"),lang:GetText("取消"),
																					function()
																						gui:ShowIE()
																					end,
																					nil
																					)
														else
															MessageBox.ShowWithTimer(1,lang:GetText("购买成功"))
															HideRapidShoppingWin()
															args = { pid = ptr_cast(game.CurrentState):GetCharacterId(), sid = magice_hummer_Info[1].sid}
															rpc.safecall("get_hummer_num", args,
																				function(data)
																					if data.warning then
																						MessageBox.ShowWithTimer(1,data.warning)
																					elseif Charm_Bottle_Win_ui then
																						Charm_Bottle_Win_ui.lb_hummer_nums.Text = data.hummer_num
																					end
																				end)
														end
													end)
					end,
				},
			},
		},
		
		Gui.ItemBoxBtn"itembox_hummer"
		{
			Style = "Gui.ItemBoxBtn_ib",
			Size = Vector2(153,79),
			Location = Vector2(536,353),--38 10
			--BtnLocation = Vector2(45, 72),
			--BtnText = lang:GetText("购买"),
			--Enable = false,
			BackgroundColor = ARGB(255,255,255,255),
			Skin = Gui.ItemBoxBtnSkin
			{
				NeutralNormalImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_02.dds", Vector4(0, 0, 0, 0)),
				--NeutralHoverImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_02.dds", Vector4(0, 0, 0, 0)),
				NeutralSelectedImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_02.dds", Vector4(0, 0, 0, 0)),
				NeutralDisabledImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_02.dds", Vector4(0, 0, 0, 0)),
			},
			
			--ItemIcon = Gui.Icon("LobbyUI/ibt_icon/machet_4.tga"),
			--Padding = Vector4(10,0,10,0),
			
			--ItemIconPastDue = Gui.Icon("LobbyUI/ShoppingMall/vip_chest/lb_vipgifts_slot_flash.dds"),
	--[[		EventMouseEnter = function(sender, e)
				L_ToolTips.FillToolTipsVIPPresent(1, Rapid_Shopping_Win_ui.Rapid_Shopping_root, magice_hummer_Info)
			end,
			EventToolTipsShow = function(sender, e)
				L_ToolTips.ShowToolTipsShowWindow(sender,Vector2(1200, 900),sender.Location + sender.Parent.Location)
			end,
			EventMouseLeave = function(sender, e)
				L_ToolTips.HideToolTipsWindow()
			end,]]
			
		},
		--退出
		Gui.Button
		{
			Size = Vector2(48,48),
			Location = Vector2(770, 265),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_normal.dds", Vector4(10, 10, 10, 10)),
				HoverImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_hover.dds", Vector4(10, 10, 10, 10)),
				DownImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_down.dds", Vector4(10, 10, 10, 10)),
				DisabledImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_disabled.dds", Vector4(0, 0, 0, 0)),	
			},
			EventClick = function()
				HideRapidShoppingWin()
			end,
		},
	},
}

function ShowRapidShoppingWin()
	if Rapid_Shopping_Win_ui == nil then
		Rapid_Shopping_Win_ui = Gui.Create()(Rapid_Shopping_Win)
		--快速购买界面初始化
		RapidShopping_Window = ModalWindow.GetNew("Rapid_Shopping_Win_ui")
		RapidShopping_Window.screen.AllowEscToExit = false
		RapidShopping_Window.screen.Visible = false
		--RapidShopping_Window.screen.EventEscPressed = HideCharmBottleWin
		RapidShopping_Window.screen.EventEscPressed = nil
		RapidShopping_Window.root.Size = Vector2(1200, 900)
		Rapid_Shopping_Win_ui.Rapid_Shopping_root.Parent = RapidShopping_Window.root
	end
	--Rapid_Shopping_Win_ui.des.Size = Vector2(200, 50)
	--Rapid_Shopping_Win_ui.des.Location = Vector2(55, 110)
	--Rapid_Shopping_Win_ui.des.FontSize = 16
	Rapid_Shopping_Win_ui.des.Text = magice_hummer_Info[1].description
	Rapid_Shopping_Win_ui.name.Text = magice_hummer_Info[1].display
	if L_Characters.RapidShopping_Window and L_Characters.RapidShopping_Window.screen then
		L_Characters.RapidShopping_Window.screen.Visible = true
		--gui.EventEscPressed = HideCharmBottleWin
		gui.EventEscPressed = nil
	end
	FileHummerItemBox()
end

function HideRapidShoppingWin()
	if L_Characters.RapidShopping_Window and L_Characters.RapidShopping_Window.screen then
		L_Characters.RapidShopping_Window.screen.Visible = false
		Rapid_Shopping_Win_ui = nil
	end
end

function FileHummerItemBox()
	Rapid_Shopping_Win_ui.itembox_hummer.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..magice_hummer_Info[1].name..".tga")
	Rapid_Shopping_Win_ui.Tbox_Totle_num.Text = 1
end

function SetHummerTotalMoney()
	if Rapid_Shopping_Win_ui.Tbox_Totle_num.Text == "" then
		Rapid_Shopping_Win_ui.Total_money.Text = "0"
		return
	end
	Rapid_Shopping_Win_ui.Total_money.Text = magice_hummer_Info[1].crprices[1].cost * Rapid_Shopping_Win_ui.Tbox_Totle_num.Text / magice_hummer_Info[1].crprices[1].unit
end

function CreatePresentBTN(list,line,index)
	return Gui.ItemBoxBtn
	{
		Style = "Gui.ItemBoxBtn_ib",
		Size = Vector2(100,100),
		Location = Vector2(106*list,106*line),
		BackgroundColor = ARGB(255, 255, 255, 255),
		--BtnLocation = Vector2(45, 72),
		--BtnText = lang:GetText("购买"),
		--BtnVisible = true,
		--BtnLocation = Vector2(10, 10),
		--Enable = false,
		
		Skin = Gui.ItemBoxBtnSkin
		{
			NeutralNormalImage = Gui.Image("LobbyUI/WarZone/Present/lb_gift_biew_bg2.dds", Vector4(0, 0, 0, 0)),
--			NeutralHoverImage = Gui.Image("LobbyUI/ShoppingMall/vip_chest/lb_vipgifts_slot_flash.dds", Vector4(0, 0, 0, 0)),
			NeutralSelectedImage = Gui.Image("LobbyUI/WarZone/Present/lb_gift_biew_bg2.dds", Vector4(0, 0, 0, 0)),
			NeutralDisabledImage = Gui.Image("LobbyUI/WarZone/Present/lb_gift_biew_bg2.dds", Vector4(0, 0, 0, 0)),
		},
		
		--ItemIcon = Gui.Icon("LobbyUI/ibt_icon/magic_4.tga"),
		Padding = Vector4(5,5,5,5),
		
		--ItemIconPastDue = Gui.Icon("LobbyUI/ShoppingMall/vip_chest/lb_vipgifts_slot_flash.dds"),
		EventMouseEnter = function(sender, e)
			if ViewPresent_Window then
				L_ToolTips.FillToolTipsVIPPresent(index, ViewPresent_Window.root, present_list)
			else
				L_ToolTips.FillToolTipsVIPPresent(index, L_FightTeam.ViewPresent_Window.root, present_list)
			end
		end,
		EventToolTipsShow = function(sender, e)
			if present_list[index] then
				local loc = sender.Location + sender.Parent.Location + sender.Parent.Parent.Location
				L_ToolTips.ShowToolTipsShowWindow(sender,Vector2(1200, 900), loc)
			end
		end,
		EventMouseLeave = function(sender, e)
			L_ToolTips.HideToolTipsWindow()
		end,
	}
end

function CreatPresentNumCtr(m_parent,num,width,height)
	if num == nil then
		return
	end
	local n = 0
	local Tep_unm = num
	if num == 0 then
		n = 1
	else
		while Tep_unm > 0 do
			Tep_unm = math.floor(Tep_unm/10)
			n = n + 1
		end
	end
	local ctr_num = Gui.Create()
	{
		Gui.Control "ctr_num_local"
		{
			Size = Vector2(30 + n*12,16),
			BackgroundColor = ARGB(0, 255, 255, 255),
			Location = Vector2(width - 32 - n*12 ,height - 21),
			
			Gui.Control
			{
				Size = Vector2(20,16),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Location = Vector2(0, 0),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_number_X.dds", Vector4(0,0,0,0)),
				},
			},
		},
	}
	if num == 0 then
		local ctr = Gui.Create()
		{
			Gui.Control "ctr_n"
			{
				Size = Vector2(20,16),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Location = Vector2(20 + (n - 1)*12, 0),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_number.dds", Vector4(0,0,0,0),Vector4(Tep_unm/10.0 , 0, (Tep_unm + 1)/10.0,1)),
				}
			},
		}
		ctr.ctr_n.Parent = ctr_num.ctr_num_local
	else
		while num > 0 do
			Tep_unm = num%10
			local ctr = Gui.Create()
			{
				Gui.Control "ctr_n"
				{
					Size = Vector2(20,16),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Location = Vector2(20 + (n - 1)*12, 0),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_number.dds", Vector4(0,0,0,0),Vector4(Tep_unm/10.0 , 0, (Tep_unm + 1)/10.0,1)),
					}
				},
			}
			ctr.ctr_n.Parent = ctr_num.ctr_num_local
			num = math.floor(num/10)
			n = n - 1
		end
	end
	ctr_num.ctr_num_local.Parent = m_parent
end

view_present_window_ui = Gui.Create()
{	
	Gui.Control "ctrl_view_present_window"
	{
		Size = Vector2(981,560),
		BackgroundColor = ARGB(0, 255, 255, 255),
		Dock = "kDockCenter",
		
		Gui.Control
		{	
			Size = Vector2(557, 551),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Dock = "kDockCenter",
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/main_bar01.dds", Vector4(20, 20, 20, 20)),
			},
			Gui.Control
			{
				Size = Vector2(513,510),
				Location = Vector2(20,20),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/WarZone/Present/lb_gift_biew_bg1.dds", Vector4(200,104,105,48)),
				},
						
				Gui.Button "bt_view_present_prev"
				{
					Size = Vector2(177,31),
					Location = Vector2(25, 468),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Text = lang:GetText("上一页"),
					TextColor = ARGB(255, 229, 255, 252),
					TextAlign = "kAlignCenterMiddle",
					HighlightTextColor = ARGB(255, 229, 255, 252),
					Padding = Vector4(0, 0, 0, 5),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_normal.dds", Vector4(15, 0, 15, 0)),
						HoverImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_hover.dds", Vector4(15, 0, 15, 0)),
						DownImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_down.dds", Vector4(15, 0, 15, 0)),
						DisabledImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_disabled.dds", Vector4(15, 0, 15, 0)),
					},
				},
				
				Gui.Button "bt_view_present_next"
				{
					Size = Vector2(177,31),
					Location = Vector2(310, 468),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Text = lang:GetText("下一页"),
					TextColor = ARGB(255, 229, 255, 252),
					TextAlign = "kAlignCenterMiddle",
					HighlightTextColor = ARGB(255, 229, 255, 252),
					Padding = Vector4(0, 0, 0, 5),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_normal.dds", Vector4(15, 0, 15, 0)),
						HoverImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_hover.dds", Vector4(15, 0, 15, 0)),
						DownImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_down.dds", Vector4(15, 0, 15, 0)),
						DisabledImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_disabled.dds", Vector4(15, 0, 15, 0)),
					},
				},
			},
			
		},
		
		Gui.Control "ctr_persent"
		{
			Size = Vector2(424,424),
			Location = Vector2(275,70),
			BackgroundColor = ARGB(0, 255, 255, 255),
			
			CreatePresentBTN(0,0,1),
			CreatePresentBTN(1,0,2),
			CreatePresentBTN(2,0,3),
			CreatePresentBTN(3,0,4),
			
			CreatePresentBTN(0,1,5),
			CreatePresentBTN(1,1,6),
			CreatePresentBTN(2,1,7),
			CreatePresentBTN(3,1,8),
			
			CreatePresentBTN(0,2,9),
			CreatePresentBTN(1,2,10),
			CreatePresentBTN(2,2,11),
			CreatePresentBTN(3,2,12),
			
			CreatePresentBTN(0,3,13),
			CreatePresentBTN(1,3,14),
			CreatePresentBTN(2,3,15),
			CreatePresentBTN(3,3,16),
			
--[[			CreatePresentBTN(0,2,17),
			CreatePresentBTN(1,2,18),
			CreatePresentBTN(2,2,19),
			CreatePresentBTN(3,2,20),
			CreatePresentBTN(4,2,21),
			CreatePresentBTN(5,2,22),
			CreatePresentBTN(6,2,23),
			CreatePresentBTN(7,2,24),
			
			CreatePresentBTN(0,3,25),
			CreatePresentBTN(1,3,26),
			CreatePresentBTN(2,3,27),
			CreatePresentBTN(3,3,28),
			CreatePresentBTN(4,3,29),
			CreatePresentBTN(5,3,30),
			CreatePresentBTN(6,3,31),
			CreatePresentBTN(7,3,32),]]
		},
		
		--奖励图片
		Gui.Control
		{
			Size = Vector2(513,50),
			Location = Vector2(235, 17),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/WarZone/Present/lb_gift_biew_title.dds", Vector4(0,0,0,0)),
			},
		},
		
		--退出
		Gui.Button "close"
		{
			Size = Vector2(52,48),
			Location = Vector2(725, 0),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_normal.dds", Vector4(10, 10, 10, 10)),
				HoverImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_hover.dds", Vector4(10, 10, 10, 10)),
				DownImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_down.dds", Vector4(10, 10, 10, 10)),
				DisabledImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_disabled.dds", Vector4(0, 0, 0, 0)),	
			},
		},
	},
}

function ShowViewPresentWindow()
		--VIP宝箱界面初始化
	ViewPresent_Window = ModalWindow.GetNew()
	ViewPresent_Window.root.Size = Vector2(1200,900)
	view_present_window_ui.ctrl_view_present_window.Parent = ViewPresent_Window.root
	view_present_window_ui.close.EventClick = function()
		HideViewPresentWindow()
	end
	view_present_window_ui.bt_view_present_next.EventClick = function(Sender ,e)
		present_page = present_page + 1
		local args = {page = present_page}
		rpc.safecall("magic_box_gift_list", args, 
		function (data)
			if data.warning then
				MessageBox.ShowWithTimer(1,data.warning)
			else
				present_page = data.page
				present_list = data.items
				present_last_page = data.is_last_page
				FillViewPresent()
			end
		end)
	end
	view_present_window_ui.bt_view_present_prev.EventClick = function(Sender ,e)
		present_page = present_page - 1
		if present_page < 1 then
			present_page = 1
		end
		local args = {page = present_page}
		rpc.safecall("magic_box_gift_list", args, 
		function (data)
			if data.warning then
				MessageBox.ShowWithTimer(1,data.warning)
			else
				present_page = data.page
				present_list = data.items
				present_last_page = data.is_last_page
				FillViewPresent()
			end
		end)
	end
	FillViewPresent()
end

function HideViewPresentWindow()
	if ViewPresent_Window then
		ViewPresent_Window:Close()
		ViewPresent_Window = nil
	end
end

function FillViewPresent()
	if present_last_page == 1 then
		view_present_window_ui.bt_view_present_next.Visible = false
	else
		view_present_window_ui.bt_view_present_next.Visible = true
	end
	if present_page == 1 then
		view_present_window_ui.bt_view_present_prev.Visible = false
	else
		view_present_window_ui.bt_view_present_prev.Visible = true
	end
	for i = 1 , 16 do
		local ibbtn = ptr_cast(view_present_window_ui.ctr_persent:GetChildByIndex(i - 1))
		ibbtn:OnDestroy()
		ibbtn.ItemLevel = nil
		if present_list[i] then
			if present_list[i].color == 0 then
				ibbtn.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..present_list[i].name..".tga")
			else
				ibbtn.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..present_list[i].name.."_"..present_list[i].color..".tga")
			end
			if present_list[i].common.type == 5 or present_list[i].common.type == 9 then
				CreatPresentNumCtr(ibbtn,present_list[i].item_num,100,100)
			elseif present_list[i].common.type == 4 and present_list[i].common.subtype == 7 then
				CreatPresentNumCtr(ibbtn,present_list[i].item_num,100,100)
			end
			if present_list[i].common and present_list[i].common.rareLevel then
				ibbtn.ItemLevel = Skin.rarelevel[math.ceil(present_list[i].common.rareLevel/25)]
			end
		else
			ibbtn.ItemIcon = nil
		end
	end
end

local Charm_Bottle_Open_Win = 
{		

	Gui.Control "Charm_Bottle_Open_root"
	{
		Size = Vector2(654, 654),
		Dock = "kDockCenter",
		BackgroundColor = ARGB(0, 255, 255, 255),	
		Gui.AnimControl "ctrl_sunshine_window"
		{
			Size = Vector2(654, 654),
			Dock = "kDockCenter",
			BackgroundColor = ARGB(0, 255, 255, 255),
		},
		Gui.Control 
		{
			Size = Vector2(376, 290),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Dock = "kDockCenter",
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/main_bar01.dds", Vector4(20, 20, 20, 20)),
			},

			Gui.Control
			{	
				Size = Vector2(346, 260),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Location = Vector2(15, 15),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/main_bar02.dds", Vector4(8, 8, 8, 8)),
				},
				
				Gui.Label "lb_weapon"
				{
					Size = Vector2(346, 20),
					Location = Vector2(0, 5),
					TextColor = ARGB(255, 37, 37, 37),
					FontSize = 16,
					TextAlign = "kAlignCenterMiddle",
					Text = lang:GetText("恭喜你获得真●巴祖卡火箭炮"),
					BackgroundColor = ARGB(0,255,255,255),
					TextPadding = Vector4(0,0,0,5),
				},
				
				-- Gui.Label
				-- {
					-- Size = Vector2(346, 20),
					-- Location = Vector2(0, 25),
					-- TextColor = ARGB(255, 37, 37, 37),
					-- FontSize = 16,
					-- TextAlign = "kAlignCenterMiddle",
					-- Text = lang:GetText("前去仓库查收"),
					-- BackgroundColor = ARGB(0,255,255,255),
					-- TextPadding = Vector4(0,0,0,5),
				-- },
				
				Gui.ItemBoxBtn "itembox_present"
				{
					Style = "Gui.ItemBoxBtn_ib",
					Size = Vector2(169,160),
					Location = Vector2(88,44),
					--BtnLocation = Vector2(45, 72),
					--BtnText = lang:GetText("购买"),
					--Enable = false,
					BackgroundColor = ARGB(255,255,255,255),
					Skin = Gui.ItemBoxBtnSkin
					{
						NeutralNormalImage = Gui.Image("LobbyUI/dailycheck/lb_onlinetime_bg_1.dds",Vector4(10, 10, 10, 10)),
						--NeutralHoverImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_02.dds", Vector4(0, 0, 0, 0)),
						NeutralSelectedImage = Gui.Image("LobbyUI/dailycheck/lb_onlinetime_bg_1.dds",Vector4(10, 10, 10, 10)),
						NeutralDisabledImage = Gui.Image("LobbyUI/dailycheck/lb_onlinetime_bg_1.dds",Vector4(10, 10, 10, 10)),
					},
					
					--ItemIcon = Gui.Icon("LobbyUI/ibt_icon/machet_4.tga"),
					--Padding = Vector4(10,0,10,0),
					
					--ItemIconPastDue = Gui.Icon("LobbyUI/ShoppingMall/vip_chest/lb_vipgifts_slot_flash.dds"),
					EventMouseEnter = function(sender, e)
						L_ToolTips.FillToolTipsVIPPresent(1, Charm_Bottle_Open_Window.root, Charm_Bottle_Present)
					end,
					EventToolTipsShow = function(sender, e)
						local loc = sender.Location + sender.Parent.Location + sender.Parent.Parent.Location + sender.Parent.Parent.Parent.Location
						L_ToolTips.ShowToolTipsShowWindow(sender,Vector2(1200, 900),loc)
					end,
					EventMouseLeave = function(sender, e)
						L_ToolTips.HideToolTipsWindow()
					end,
				},				
				
				Gui.Button
				{
					Size = Vector2(180,44),
					Location = Vector2(83, 210),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Text = lang:GetText("确 定"),
					TextColor = ARGB(255, 229, 255, 252),
					TextAlign = "kAlignCenterMiddle",
					HighlightTextColor = ARGB(255, 229, 255, 252),
					Padding = Vector4(0, 0, 0, 5),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_onlinetime_button_2_normal.dds", Vector4(20, 0, 20, 0)),
						HoverImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_onlinetime_button_2_hover.dds", Vector4(20, 0, 20, 0)),
						DownImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_onlinetime_button_2_down.dds", Vector4(20, 0, 20, 0)),
						DisabledImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_onlinetime_button_2_disabled.dds", Vector4(20, 0, 20, 0)),
					},
					EventClick = function()
						HideCharmBottleOpenPresentWin()
					end,
				},
			},
		},
	},
}

function ShowCharmBottleOpenPresentWin()
	if Charm_Bottle_Open_Win_ui == nil then
		Charm_Bottle_Open_Win_ui = Gui.Create()(Charm_Bottle_Open_Win)
	end
	--VIP宝箱界面初始化
	Charm_Bottle_Open_Window = ModalWindow.GetNew("Charm_Bottle_Open_Win_ui")
	Charm_Bottle_Open_Window.screen.AllowEscToExit = false
	Charm_Bottle_Open_Window.screen.Visible = false
	Charm_Bottle_Open_Window.root.Size = Vector2(1200,900)
	--Charm_Bottle_Open_Window.screen.EventEscPressed = HideCharmBottleWin
	Charm_Bottle_Open_Window.screen.EventEscPressed = nil
	Charm_Bottle_Open_Win_ui.Charm_Bottle_Open_root.Parent = Charm_Bottle_Open_Window.root
	
	Charm_Bottle_Open_Win_ui.ctrl_sunshine_window:AddAnim("rotation",0.5,6)
	local sun =  Gui.Icon("LobbyUI/WarZone/Present/light.dds", Vector4(0, 0, 0, 0))
	Charm_Bottle_Open_Win_ui.ctrl_sunshine_window:AddFrame("rotation",sun)
	Charm_Bottle_Open_Win_ui.ctrl_sunshine_window:StartAnimation()
	
	Charm_Bottle_Open_Win_ui.lb_weapon.Text = lang:GetText("恭喜你获得").."'"..Charm_Bottle_Present[1].display.."'"
	Charm_Bottle_Open_Win_ui.itembox_present.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..Charm_Bottle_Present[1].name..".tga")
	Charm_Bottle_Open_Win_ui.itembox_present:OnDestroy()
	if Charm_Bottle_Present[1].common.type == 4 and Charm_Bottle_Present[1].common.subtype == 7 or Charm_Bottle_Present[1].common.type == 5 or Charm_Bottle_Present[1].common.type == 9 then
		CreatPresentNumCtr(Charm_Bottle_Open_Win_ui.itembox_present,Charm_Bottle_Present[1].item_num,169,160)
	end
	if Charm_Bottle_Open_Window and Charm_Bottle_Open_Window.screen then
		Charm_Bottle_Open_Window.screen.Visible = true
		gui.EventEscPressed = nil
	end
end

function HideCharmBottleOpenPresentWin()
	if Charm_Bottle_Open_Window and Charm_Bottle_Open_Window.screen then
		Charm_Bottle_Open_Window.screen.Visible = false
		Charm_Bottle_Open_Win_ui = nil
	end
	if flash_ctr and flash_ctr.Fctr_Charm_Bottle_Open then
		flash_ctr.Fctr_Charm_Bottle_Open.Visible = false
		flash_ctr.Fctr_Charm_Bottle_Open.Parent = nil
		flash_ctr = nil
		if Charm_Bottle_Win_ui and Charm_Bottle_Win_ui.Charm_Bottle_Normal then
			Charm_Bottle_Win_ui.Charm_Bottle_Normal.Visible = true
		end
	end
end

function Judgenumber(str)
	local Tep_tab = {"0","1","2","3","4","5","6","7","8","9"}
	for i = 1 , 10 do
		if str == Tep_tab[i] then
			return false
		end
	end
	return true
end

tuozhuai = 
{
	--[[Gui.Control
	{
		Size = Vector2(176, 460),
		Location = Vector2(485, 330),
		BackgroundColor = ARGB(100, 255, 255, 255),
	},]]
	Gui.Control "root"
	{
		Visible = false,
		Size = Vector2(1167, 900),
		Location = Vector2(17, 0),
		BackgroundColor = ARGB(0, 255, 255, 255),
		Gui.Control "Image"
		{
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ibt_icon/ak47.tga", Vector4(0, 0, 0, 0)),
			},
			Gui.DragLabel "tttt"
			{
				Size = Vector2(168, 156),
				Location = Vector2(0, 0),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Iimit = Vector4(-10000,-10000,10000,10000),
			},
		},
		
		EventMouseRightUp = function(Sender,e)
			--if e.RightButtonDown ~= true then
				local lobby_state = ptr_cast(game.CurrentState)
				local cursor_ScreenSize = lobby_state:GetScreenSize()
				local cursor_pos = lobby_state:GetCursorPos()
				local x = cursor_pos.x - ((cursor_ScreenSize.x - (cursor_ScreenSize.y / 3 * 4)) / 2)
				local y = cursor_pos.y 	
				if  x < 650 and x > 175 and y < 798 and y > 292 then
					L_LobbyMain.RpcEquipWeapon(index_tz)
					current_selected_item_class = 0
					if L_LobbyMain.CharactersIB_rpc_data.items[index_tz].common.type == 1 then
						if L_LobbyMain.CharactersIB_rpc_data.items[index_tz].common.seq == 1 then
							current_selected_ibtn_index = 1
						elseif L_LobbyMain.CharactersIB_rpc_data.items[index_tz].common.seq == 2 then
							current_selected_ibtn_index = 2
						elseif L_LobbyMain.CharactersIB_rpc_data.items[index_tz].common.seq == 4 then
							current_selected_ibtn_index = 3
						else
							current_selected_ibtn_index = 4
						end
					elseif L_LobbyMain.CharactersIB_rpc_data.items[index_tz].common.type == 2 then
						current_selected_ibtn_index = 5
					elseif L_LobbyMain.CharactersIB_rpc_data.items[index_tz].common.type == 3 then
						if L_LobbyMain.CharactersIB_rpc_data.items[index_tz].common.seq == 2 then
							current_selected_ibtn_index = 6
						else
							current_selected_ibtn_index = 7
						end
					end
				end
				reset()
			--end
		end,
	},
}

function reset()
	if ib_weapon_ui then
		if index_tz < 9 then
			local ibbtn = ptr_cast(ib_weapon_ui.ctrl_ib_container:GetChildByIndex(index_tz-1))
			if ibbtn.ItemIcon then
				ibbtn.ItemIcon.alpha = 255
			end
		end
	end
	if ib_dress_ui then
		if index_tz < 9 then
			local ibbtn = ptr_cast(ib_dress_ui.ctrl_ib_container:GetChildByIndex(index_tz-1))
			if ibbtn.ItemIcon then
				ibbtn.ItemIcon.alpha = 255
			end
		end
	end
	if ib_accessories_ui then
		local ibbtn = ptr_cast(ib_accessories_ui.ctrl_ib_container:GetChildByIndex(index_tz-1))
		if ibbtn.ItemIcon then
			ibbtn.ItemIcon.alpha = 255
		end
	end
	if tuozhuai_ui then
		tuozhuai_ui.root.Visible = false
	end
	
	for i = 1, 7 do
		local ibbtn = ptr_cast(user_bag_info_ui.ctrl_ib_container:GetChildByIndex(i-1))
		ibbtn.Highlight = false
	end
end

--续费界面
Renewals_window_ui = Gui.Create()
{
	Gui.Control "ctrl_window_root"
	{
		Size = Vector2(520, 534),
		Location = Vector2(310, 220),
		Dock = "kDockCenter",
		BackgroundColor = ARGB(255, 255, 255, 255),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_contact_bg1_01.dds", Vector4(163,163,53,53)),
		},

		--续费
		Gui.Button "btn_buy_and_balance"
		{
			Size = Vector2(84, 28),
			Location = Vector2(35, 21),
			Text = lang:GetText("续费"),
			TextColor = ARGB(255, 242, 242, 242),
			Font = "simhei",
			FontSize = 16,
			PushDown = true,
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_contact_tab1_normal.dds", Vector4(10, 0, 10, 0)),
				HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_contact_tab1_hover.dds", Vector4(10, 0, 10, 0)),
				DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_contact_tab1_down.dds", Vector4(10, 0, 10, 0)),
				DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_contact_tab1_normal.dds", Vector4(10, 0, 10, 0)),
			},
			EventClick = function()
				if Renewals_window_ui then
					Renewals_window_ui.btn_buy_and_balance.PushDown = true
					Renewals_window_ui.btn_buy.Visible = true
				end
			end
		},

		--充值
		Gui.Button "btn_add_value"
		{
			Enable = true,
			Size = Vector2(108, 32),
			Location = Vector2(390, 12),
			Text = lang:GetText("充 值"),
			TextColor = ARGB(255, 37, 37, 37),
			HighlightTextColor = ARGB(255, 37, 37, 37),
			Padding = Vector4(0, 0, 0, 3),
			FontSize = 18,
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_button_zhengli_normal.dds", Vector4(0, 0, 0, 0)),
				HoverImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_button_zhengli_hover.dds", Vector4(0, 0, 0, 0)),
				DownImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_button_zhengli_down.dds", Vector4(0, 0, 0, 0)),
				DisabledImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_button_zhengli_disabled.dds", Vector4(0, 0, 0, 0)),
			},
			EventClick = function()
				gui:ShowIE()
			end
		},

		Gui.Control "ctrl_window_main"
		{
			Size = Vector2(477, 462),
			Location = Vector2(21, 46),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_contact_bg2.dds", Vector4(21, 25, 21, 46)),
			},
				
			--物品图片
			Gui.Control "ctrl_goods_image_root"
			{
				Size = Vector2(169, 156),
				Location = Vector2(17, 35),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_trading_box_01.dds", Vector4(10, 10, 10, 10)),
				},
				Gui.Control "ctrl_goods_image"
				{
					Dock = "kDockCenter",
					BackgroundColor = ARGB(255, 255, 255, 255),
				},
			},
			

			--物品名称
			Gui.Label "lbl_goods_name"
			{
				Size = Vector2(252, 20),
				Text = lang:GetText("物品名称"),
				Font = "simhei",
				FontSize = 18,
				Location = Vector2(180, 50),
				TextAlign = "kAlignCenterMiddle",
				TextColor = ARGB(255, 37, 37, 37),
			},
			Gui.Label "lbl_limited"
			{
				Size = Vector2(200, 160),
				-- Text = lang:GetText("总续费天数上限为30天"),
				Font = "simhei",
				FontSize = 18,
				Location = Vector2(190, 70),
				TextAlign = "kAlignCenterMiddle",
				TextColor = ARGB(255, 255, 0, 0),
			},
		
			
			--物品用途
			Gui.TextArea "lbl_goods_info"
			{
				Size = Vector2(252, 131),
				Text = lang:GetText("物品用途"),
				FontSize = 16,
				Location = Vector2(204, 76),
				TextColor = ARGB(255, 37, 37, 37),
				Readonly = true,
				Fold = true,
				VScrollBarWidth = 14,
				VScrollBarButtonSize = 20,
				HScrollBarDisplay = "kHide",
				VScrollBarDisplay = "kAuto",							
				Skin = Gui.TextAreaSkin
				{
					UpButtonNormalImage = nil,
					UpButtonHoverImage = nil,
					UpButtonDownImage = nil,
					UpButtonDisabledImage = nil,

					DownButtonNormalImage = nil,
					DownButtonHoverImage = nil,
					DownButtonDownImage = nil,
					DownButtonDisabledImage = nil,

					VSliderNormalImage = Gui.Image("LobbyUI/team/lb_squad_scrollbar_button_normal.dds", Vector4(5, 5, 5, 5)),
					VSliderHoverImage = Gui.Image("LobbyUI/team/lb_squad_scrollbar_button_hover.dds", Vector4(5, 5, 5, 5)),
					VSliderDownImage = Gui.Image("LobbyUI/team/lb_squad_scrollbar_button_down.dds", Vector4(5, 5, 5, 5)),
					VSliderDisabledImage = Gui.Image("DLobbyUI/team/lb_squad_scrollbar_button_normal.dds", Vector4(5, 5, 5, 5)),

					VBarBackgroundImage = Gui.Image("LobbyUI/lb_common_scrollbar02_bg.dds", Vector4(0, 0, 0, 0)),
					BarCornerImage = nil,
				},
			},

			--结算方式
			Gui.Control "ctrl_balance_mode"
			{
				Size = Vector2(443, 92),
				Location = Vector2(15, 233),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_box4_jiaoyi.dds", Vector4(10, 10, 10, 10)),
				},
				
				--结算方式
				Gui.Control "ctrl_balance_mode_bg"
				{
					Size = Vector2(434, 38),
					Location = Vector2(5, 6),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Visible = true,
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_line4.dds", Vector4(10, 10, 10, 10)),
					},

					--结算方式
					Gui.Label "lbl_balance_mode"
					{
						Size = Vector2(78, 24),
						Text = lang:GetText("结算方式"),
						Font = "simhei",
						FontSize = 18,
						Location = Vector2(118, 5),
						TextColor = ARGB(255, 37, 37, 37),
					},

					--上一种结算方式
					Gui.Button "btn_front_page"
					{
						Visible = false,
						Size = Vector2(20, 20),
						Location = Vector2(213, 7),
						--Text = "<",
						TextColor = ARGB(255, 191, 189, 184),
						FontSize = 16,
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button08_normal.dds", Vector4(8, 8, 8, 8)),
							HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button08_hover.dds", Vector4(8, 8, 8, 8)),
							DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button08_down.dds", Vector4(8, 8, 8, 8)),
							DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button08_normal.dds", Vector4(8, 8, 8, 8)),
						},
						EventClick = function()
							if Renewals_window_ui then
								local current_selected_ibtn_index1
								if L_LobbyMain.CharactersIB_rpc_data and L_LobbyMain.CharactersInfo_rpc_data then
									local rpc_data_items = L_LobbyMain.CharactersIB_rpc_data.items
									if current_selected_item_class == 1 then
										rpc_data_items = L_LobbyMain.CharactersIB_rpc_data.items
									elseif current_selected_item_class == 0 then
										if current_selected_ibtn_index > 0 and current_selected_ibtn_index < 5 then
											rpc_data_items = L_LobbyMain.CharactersInfo_rpc_data.items.weapons
											current_selected_ibtn_index1 = current_selected_ibtn_index
										elseif current_selected_ibtn_index > 4 and current_selected_ibtn_index < 8 then
											rpc_data_items = L_LobbyMain.CharactersInfo_rpc_data.items.costume
											current_selected_ibtn_index1 = current_selected_ibtn_index - 4
										end
									end
									
									local weapon_info = rpc_data_items[current_selected_ibtn_index1]
									if weapon_info then
										--付款方式
										local mode1 = weapon_info.crprices
										local mode2 = weapon_info.gpprices
										local mode3 = weapon_info.voucherprices
										local ncount = current_selected_price_way
										ncount = ncount - 1
										
										Renewals_window_ui.btn_three_days.PushDown = false
										Renewals_window_ui.btn_senven_days.PushDown = false
										Renewals_window_ui.btn_thirty_days.PushDown = false
										Renewals_window_ui.btn_forever.PushDown = false
										cost_mode = 1
										
										local flag = true
										while flag do
											if ncount == 0 then
												ncount = 3
											end												

											if ncount == 1 then
												if mode1[1] then
													Renewals_window_ui.lbl_spend_point.Text = rpc_data_items[current_selected_ibtn_index1].crprices[cost_mode].cost .. " " .. price_way[1]
													Renewals_window_ui.lbl_spend_GP.Text = "0 " .. price_way[2]
													Renewals_window_ui.lbl_spend_ticket.Text = "0 " .. price_way[3]
													current_selected_price_way = 1
													flag = false
													if mode1[1].unittype == 0 then
														Renewals_window_ui.btn_three_days.Text = unittype_way[mode1[1].unittype + 1]
													else
														Renewals_window_ui.btn_three_days.Text = mode1[1].unit..unittype_way[mode1[1].unittype + 1]
													end
													Renewals_window_ui.btn_three_days.Visible = true
													Renewals_window_ui.btn_three_days.PushDown = true
												else
													Renewals_window_ui.btn_three_days.Visible = false
													Renewals_window_ui.btn_three_days.PushDown = false
												end

												if mode1[2] then
													if mode1[2].unittype == 0 then
														Renewals_window_ui.btn_senven_days.Text = unittype_way[mode1[2].unittype + 1]
													else
														Renewals_window_ui.btn_senven_days.Text = mode1[2].unit..unittype_way[mode1[2].unittype + 1]
													end
													Renewals_window_ui.btn_senven_days.Visible = true
												else
													Renewals_window_ui.btn_senven_days.Visible = false
													Renewals_window_ui.btn_senven_days.PushDown = false
												end

												if mode1[3] then
													if mode1[2].unittype == 0 then
														Renewals_window_ui.btn_thirty_days.Text = unittype_way[mode1[3].unittype + 1]
													else
														Renewals_window_ui.btn_thirty_days.Text = mode1[3].unit..unittype_way[mode1[3].unittype + 1]
													end
													Renewals_window_ui.btn_thirty_days.Visible = true
												else
													Renewals_window_ui.btn_thirty_days.Visible = false
													Renewals_window_ui.btn_thirty_days.PushDown = false
												end

												if mode1[4] then
													if mode1[4].unittype == 0 then
														Renewals_window_ui.btn_forever.Text = unittype_way[mode1[4].unittype + 1]
													else
														Renewals_window_ui.btn_forever.Text = mode1[1].unit..unittype_way[mode1[4].unittype + 1]
													end
													Renewals_window_ui.btn_forever.Visible = true
												else
													Renewals_window_ui.btn_forever.Visible = false
													Renewals_window_ui.btn_forever.PushDown = false
												end
											
											end

											if ncount == 2 then
												if mode2[1] then
													Renewals_window_ui.lbl_spend_point.Text = "0 " .. price_way[1]
													Renewals_window_ui.lbl_spend_GP.Text = rpc_data_items[current_selected_ibtn_index1].gpprices[cost_mode].cost .. " " .. price_way[2]
													Renewals_window_ui.lbl_spend_ticket.Text = "0 " .. price_way[3]
													current_selected_price_way = 2
													flag = false
													if mode2[1].unittype == 0 then
														Renewals_window_ui.btn_three_days.Text = unittype_way[mode2[1].unittype + 1]
													else
														Renewals_window_ui.btn_three_days.Text = mode2[1].unit..unittype_way[mode2[1].unittype + 1]
													end
													Renewals_window_ui.btn_three_days.Visible = true
													Renewals_window_ui.btn_three_days.PushDown = true
												else
													Renewals_window_ui.btn_three_days.Visible = false
													Renewals_window_ui.btn_three_days.PushDown = false
												end

												if mode2[2] then
													if mode2[2].unittype == 0 then
														Renewals_window_ui.btn_senven_days.Text = unittype_way[mode2[2].unittype + 1]
													else
														Renewals_window_ui.btn_senven_days.Text = mode2[2].unit..unittype_way[mode2[2].unittype + 1]
													end
													Renewals_window_ui.btn_senven_days.Visible = true
												else
													Renewals_window_ui.btn_senven_days.Visible = false
													Renewals_window_ui.btn_senven_days.PushDown = false
												end

												if mode2[3] then
													if mode2[2].unittype == 0 then
														Renewals_window_ui.btn_thirty_days.Text = unittype_way[mode2[3].unittype + 1]
													else
														Renewals_window_ui.btn_thirty_days.Text = mode2[3].unit..unittype_way[mode2[3].unittype + 1]
													end
													Renewals_window_ui.btn_thirty_days.Visible = true
												else
													Renewals_window_ui.btn_thirty_days.Visible = false
													Renewals_window_ui.btn_thirty_days.PushDown = false
												end

												if mode2[4] then
													if mode2[4].unittype == 0 then
														Renewals_window_ui.btn_forever.Text = unittype_way[mode2[4].unittype + 1]
													else
														Renewals_window_ui.btn_forever.Text = mode2[4].unit..unittype_way[mode2[4].unittype + 1]
													end
													Renewals_window_ui.btn_forever.Visible = true
												else
													Renewals_window_ui.btn_forever.Visible = false
													Renewals_window_ui.btn_forever.PushDown = false
												end
												
											end

											if ncount ==3 then
												if mode3[1] then
													Renewals_window_ui.lbl_spend_point.Text = "0 " .. price_way[1]
													Renewals_window_ui.lbl_spend_GP.Text = "0 " .. price_way[2]
													Renewals_window_ui.lbl_spend_ticket.Text = rpc_data_items[current_selected_ibtn_index1].voucherprices[cost_mode].cost .. " " .. price_way[3]
													current_selected_price_way = 3
													flag = false
													if mode3[1].unittype == 0 then
														Renewals_window_ui.btn_three_days.Text = unittype_way[mode3[1].unittype + 1]
													else
														Renewals_window_ui.btn_three_days.Text = mode3[1].unit..unittype_way[mode3[1].unittype + 1]
													end
													Renewals_window_ui.btn_three_days.Visible = true
													Renewals_window_ui.btn_three_days.PushDown = true
												else
													Renewals_window_ui.btn_three_days.Visible = false
													Renewals_window_ui.btn_three_days.PushDown = false
												end

												if mode3[2] then
													if mode3[2].unittype == 0 then
														Renewals_window_ui.btn_senven_days.Text = unittype_way[mode3[2].unittype + 1]
													else
														Renewals_window_ui.btn_senven_days.Text = mode3[2].unit..unittype_way[mode3[2].unittype + 1]
													end
													Renewals_window_ui.btn_senven_days.Visible = true
												else
													Renewals_window_ui.btn_senven_days.Visible = false
													Renewals_window_ui.btn_senven_days.PushDown = false
												end

												if mode3[3] then
													if mode3[2].unittype == 0 then
														Renewals_window_ui.btn_thirty_days.Text = unittype_way[mode3[3].unittype + 1]
													else
														Renewals_window_ui.btn_thirty_days.Text = mode3[3].unit..unittype_way[mode3[3].unittype + 1]
													end
													Renewals_window_ui.btn_thirty_days.Visible = true
												else
													Renewals_window_ui.btn_thirty_days.Visible = false
													Renewals_window_ui.btn_thirty_days.PushDown = false
												end

												if mode3[4] then
													if mode3[4].unittype == 0 then
														Renewals_window_ui.btn_forever.Text = unittype_way[mode3[4].unittype + 1]
													else
														Renewals_window_ui.btn_forever.Text = mode3[4].unit..unittype_way[mode3[4].unittype + 1]
													end
													Renewals_window_ui.btn_forever.Visible = true
												else
													Renewals_window_ui.btn_forever.Visible = false
													Renewals_window_ui.btn_forever.PushDown = false
												end
												
											end
											ncount = ncount - 1
										end
										Renewals_window_ui.lb_page_number.Text = price_way[current_selected_price_way]
									end
								end
							end
						end
					},

					--FC点结算
					Gui.Label "lb_page_number"
					{
						Location = Vector2(246, 8),
						Size = Vector2(58, 20),
						Font = "simhei",
						FontSize = 18,
						TextAlign = "kAlignCenterMiddle",
						TextColor = ARGB(255, 37, 37, 37),
						Text = lang:GetText("FC点"),
					},

					--下一种结算方式
					Gui.Button "btn_next_page"
					{
						Visible = false,
						Size = Vector2(20, 20),
						Location = Vector2(317, 7),
						TextColor = ARGB(255, 191, 189, 184),
						FontSize = 16,
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button09_normal.dds", Vector4(8, 8, 8, 8)),
							HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button09_hover.dds", Vector4(8, 8, 8, 8)),
							DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button09_down.dds", Vector4(8, 8, 8, 8)),
							DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button09_normal.dds", Vector4(8, 8, 8, 8)),
						},
						EventClick = function()
							if Renewals_window_ui then
								local current_selected_ibtn_index1
								if L_LobbyMain.CharactersIB_rpc_data and L_LobbyMain.CharactersInfo_rpc_data then
									local rpc_data_items = L_LobbyMain.CharactersIB_rpc_data.items
									if current_selected_item_class == 1 then
										rpc_data_items = L_LobbyMain.CharactersIB_rpc_data.items
									elseif current_selected_item_class == 0 then
										if current_selected_ibtn_index > 0 and current_selected_ibtn_index < 5 then
											rpc_data_items = L_LobbyMain.CharactersInfo_rpc_data.items.weapons
											current_selected_ibtn_index1 = current_selected_ibtn_index
										elseif current_selected_ibtn_index > 4 and current_selected_ibtn_index < 8 then
											rpc_data_items = L_LobbyMain.CharactersInfo_rpc_data.items.costume
											current_selected_ibtn_index1 = current_selected_ibtn_index - 4
										end
									end
									
									local weapon_info = rpc_data_items[current_selected_ibtn_index1]
									if weapon_info then
										--付款方式
										local mode1 = weapon_info.crprices
										local mode2 = weapon_info.gpprices
										local mode3 = weapon_info.voucherprices
										local ncount = current_selected_price_way
										ncount = ncount + 1
										
										Renewals_window_ui.btn_three_days.PushDown = false
										Renewals_window_ui.btn_senven_days.PushDown = false
										Renewals_window_ui.btn_thirty_days.PushDown = false
										Renewals_window_ui.btn_forever.PushDown = false
										cost_mode = 1

										local flag = true
										while flag do
											if ncount == 4 then
												ncount = 1
											end

											if ncount == 1 then
												if mode1[1] then
													Renewals_window_ui.lbl_spend_point.Text = rpc_data_items[current_selected_ibtn_index1].crprices[cost_mode].cost .. " " .. price_way[1]
													Renewals_window_ui.lbl_spend_GP.Text = "0 " .. price_way[2]
													Renewals_window_ui.lbl_spend_ticket.Text = "0 " .. price_way[3]
													current_selected_price_way = 1
													flag = false
													if mode1[1].unittype == 0 then
														Renewals_window_ui.btn_three_days.Text = unittype_way[mode1[1].unittype + 1]
													else
														Renewals_window_ui.btn_three_days.Text = mode1[1].unit..unittype_way[mode1[1].unittype + 1]
													end
													Renewals_window_ui.btn_three_days.Visible = true
													Renewals_window_ui.btn_three_days.PushDown = true
												else
													Renewals_window_ui.btn_three_days.Visible = false
													Renewals_window_ui.btn_three_days.PushDown = false
												end

												if mode1[2] then
													if mode1[2].unittype == 0 then
														Renewals_window_ui.btn_senven_days.Text = unittype_way[mode1[2].unittype + 1]
													else
														Renewals_window_ui.btn_senven_days.Text = mode1[2].unit..unittype_way[mode1[2].unittype + 1]
													end
													Renewals_window_ui.btn_senven_days.Visible = true
												else
													Renewals_window_ui.btn_senven_days.Visible = false
													Renewals_window_ui.btn_senven_days.PushDown = false
												end

												if mode1[3] then
													if mode1[2].unittype == 0 then
														Renewals_window_ui.btn_thirty_days.Text = unittype_way[mode1[3].unittype + 1]
													else
														Renewals_window_ui.btn_thirty_days.Text = mode1[3].unit..unittype_way[mode1[3].unittype + 1]
													end
													Renewals_window_ui.btn_thirty_days.Visible = true
												else
													Renewals_window_ui.btn_thirty_days.Visible = false
													Renewals_window_ui.btn_thirty_days.PushDown = false
												end

												if mode1[4] then
													if mode1[4].unittype == 0 then
														Renewals_window_ui.btn_forever.Text = unittype_way[mode1[4].unittype + 1]
													else
														Renewals_window_ui.btn_forever.Text = mode1[1].unit..unittype_way[mode1[4].unittype + 1]
													end
													Renewals_window_ui.btn_forever.Visible = true
												else
													Renewals_window_ui.btn_forever.Visible = false
													Renewals_window_ui.btn_forever.PushDown = false
												end
												
											end

											if ncount == 2 then
												if mode2[1] then
													Renewals_window_ui.lbl_spend_point.Text = "0 " .. price_way[1]
													Renewals_window_ui.lbl_spend_GP.Text = rpc_data_items[current_selected_ibtn_index1].gpprices[cost_mode].cost .. " " .. price_way[2]
													Renewals_window_ui.lbl_spend_ticket.Text = "0 " .. price_way[3]
													current_selected_price_way = 2
													flag = false
													if mode2[1].unittype == 0 then
														Renewals_window_ui.btn_three_days.Text = unittype_way[mode2[1].unittype + 1]
													else
														Renewals_window_ui.btn_three_days.Text = mode2[1].unit..unittype_way[mode2[1].unittype + 1]
													end
													Renewals_window_ui.btn_three_days.Visible = true
													Renewals_window_ui.btn_three_days.PushDown = true
												else
													Renewals_window_ui.btn_three_days.Visible = false
													Renewals_window_ui.btn_three_days.PushDown = false
												end

												if mode2[2] then
													if mode2[2].unittype == 0 then
														Renewals_window_ui.btn_senven_days.Text = unittype_way[mode2[2].unittype + 1]
													else
														Renewals_window_ui.btn_senven_days.Text = mode2[2].unit..unittype_way[mode2[2].unittype + 1]
													end
													Renewals_window_ui.btn_senven_days.Visible = true
												else
													Renewals_window_ui.btn_senven_days.Visible = false
													Renewals_window_ui.btn_senven_days.PushDown = false
												end

												if mode2[3] then
													if mode2[2].unittype == 0 then
														Renewals_window_ui.btn_thirty_days.Text = unittype_way[mode2[3].unittype + 1]
													else
														Renewals_window_ui.btn_thirty_days.Text = mode2[3].unit..unittype_way[mode2[3].unittype + 1]
													end
													Renewals_window_ui.btn_thirty_days.Visible = true
												else
													Renewals_window_ui.btn_thirty_days.Visible = false
													Renewals_window_ui.btn_thirty_days.PushDown = false
												end

												if mode2[4] then
													if mode2[4].unittype == 0 then
														Renewals_window_ui.btn_forever.Text = unittype_way[mode2[4].unittype + 1]
													else
														Renewals_window_ui.btn_forever.Text = mode2[4].unit..unittype_way[mode2[4].unittype + 1]
													end
													Renewals_window_ui.btn_forever.Visible = true
												else
													Renewals_window_ui.btn_forever.Visible = false
													Renewals_window_ui.btn_forever.PushDown = false
												end
												
											end

											if ncount ==3 then
												if mode3[1] then
													Renewals_window_ui.lbl_spend_point.Text = "0 " .. price_way[1]
													Renewals_window_ui.lbl_spend_GP.Text = "0 " .. price_way[2]
													Renewals_window_ui.lbl_spend_ticket.Text = rpc_data_items[current_selected_ibtn_index1].voucherprices[cost_mode].cost .. " " .. price_way[3]
													current_selected_price_way = 3
													flag = false
													if mode3[1].unittype == 0 then
														Renewals_window_ui.btn_three_days.Text = unittype_way[mode3[1].unittype + 1]
													else
														Renewals_window_ui.btn_three_days.Text = mode3[1].unit..unittype_way[mode3[1].unittype + 1]
													end
													Renewals_window_ui.btn_three_days.Visible = true
													Renewals_window_ui.btn_three_days.PushDown = true
												else
													Renewals_window_ui.btn_three_days.Visible = false
													Renewals_window_ui.btn_three_days.PushDown = false
												end

												if mode3[2] then
													if mode3[2].unittype == 0 then
														Renewals_window_ui.btn_senven_days.Text = unittype_way[mode3[2].unittype + 1]
													else
														Renewals_window_ui.btn_senven_days.Text = mode3[2].unit..unittype_way[mode3[2].unittype + 1]
													end
													Renewals_window_ui.btn_senven_days.Visible = true
												else
													Renewals_window_ui.btn_senven_days.Visible = false
													Renewals_window_ui.btn_senven_days.PushDown = false
												end

												if mode3[3] then
													if mode3[2].unittype == 0 then
														Renewals_window_ui.btn_thirty_days.Text = unittype_way[mode3[3].unittype + 1]
													else
														Renewals_window_ui.btn_thirty_days.Text = mode3[3].unit..unittype_way[mode3[3].unittype + 1]
													end
													Renewals_window_ui.btn_thirty_days.Visible = true
												else
													Renewals_window_ui.btn_thirty_days.Visible = false
													Renewals_window_ui.btn_thirty_days.PushDown = false
												end

												if mode3[4] then
													if mode3[4].unittype == 0 then
														Renewals_window_ui.btn_forever.Text = unittype_way[mode3[4].unittype + 1]
													else
														Renewals_window_ui.btn_forever.Text = mode3[4].unit..unittype_way[mode3[4].unittype + 1]
													end
													Renewals_window_ui.btn_forever.Visible = true
												else
													Renewals_window_ui.btn_forever.Visible = false
													Renewals_window_ui.btn_forever.PushDown = false
												end
												
											end
											ncount = ncount + 1
										end
										Renewals_window_ui.lb_page_number.Text = price_way[current_selected_price_way]
									end
								end
							end
						end
					},
				},
				--三天
				Gui.Button "btn_three_days"
				{
					Size = Vector2(103, 26),
					Location = Vector2(8, 54),
					Text = lang:GetText("50/3天"),
					TextColor = ARGB(255, 242, 242, 242),
					HighlightTextColor = ARGB(255, 37, 37, 37),
					Font = "simhei",
					FontSize = 16,
					BackgroundColor = ARGB(255, 255, 255, 255),
					PushDown = true,
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_normal.dds", Vector4(10, 10, 10, 10)),
						HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_hover.dds", Vector4(10, 10, 10, 10)),
						DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_down.dds", Vector4(10, 10, 10, 10)),
						DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_normal.dds", Vector4(10, 10, 10, 10)),
					},
					EventClick = function()
						if  Renewals_window_ui then
							local rpc_data_items = L_LobbyMain.CharactersIB_rpc_data.items
							if current_selected_item_class == 1 then
								rpc_data_items = L_LobbyMain.CharactersIB_rpc_data.items
							elseif current_selected_item_class == 0 then
								if current_selected_ibtn_index > 0 and current_selected_ibtn_index < 5 then
									rpc_data_items = L_LobbyMain.CharactersInfo_rpc_data.items.weapons
								elseif current_selected_ibtn_index > 4 and current_selected_ibtn_index < 8 then
									rpc_data_items = L_LobbyMain.CharactersInfo_rpc_data.items.costume
								end
							end
								
							Renewals_window_ui.btn_three_days.PushDown = true
							Renewals_window_ui.btn_senven_days.PushDown = false
							Renewals_window_ui.btn_thirty_days.PushDown = false
							Renewals_window_ui.btn_forever.PushDown = false
							cost_mode = 1
							if current_selected_price_way == 1 then
								if current_selected_item_class == 0 and current_selected_ibtn_index > 4 and current_selected_ibtn_index < 8 then
									Renewals_window_ui.lbl_spend_point.Text = rpc_data_items[current_selected_ibtn_index - 4].crprices[cost_mode].cost .. " " .. price_way[1]
								else
									Renewals_window_ui.lbl_spend_point.Text = rpc_data_items[current_selected_ibtn_index].crprices[cost_mode].cost .. " " .. price_way[1]
								end
								Renewals_window_ui.lbl_spend_GP.Text = "0 " .. price_way[2]
								Renewals_window_ui.lbl_spend_ticket.Text = "0 " .. price_way[3]
							elseif current_selected_price_way == 2 then
								Renewals_window_ui.lbl_spend_point.Text = "0 " .. price_way[1]
								if current_selected_item_class == 0 and current_selected_ibtn_index > 4 and current_selected_ibtn_index < 8 then
									Renewals_window_ui.lbl_spend_GP.Text = rpc_data_items[current_selected_ibtn_index - 4].gpprices[cost_mode].cost .. " " .. price_way[2]
								else
									Renewals_window_ui.lbl_spend_GP.Text = rpc_data_items[current_selected_ibtn_index].gpprices[cost_mode].cost .. " " .. price_way[2]
								end
								Renewals_window_ui.lbl_spend_ticket.Text = "0 " .. price_way[3]
							elseif current_selected_price_way == 3 then
								Renewals_window_ui.lbl_spend_point.Text = "0 " .. price_way[1]
								Renewals_window_ui.lbl_spend_GP.Text = "0 " .. price_way[2]
								if current_selected_item_class == 0 and current_selected_ibtn_index > 4 and current_selected_ibtn_index < 8 then
									Renewals_window_ui.lbl_spend_ticket.Text = rpc_data_items[current_selected_ibtn_index - 4].voucherprices[cost_mode].cost .. " " .. price_way[3]
								else
									Renewals_window_ui.lbl_spend_ticket.Text = rpc_data_items[current_selected_ibtn_index].voucherprices[cost_mode].cost .. " " .. price_way[3]
								end
							end
						end
					end,
				},

				--七天
				Gui.Button "btn_senven_days"
				{
					Size = Vector2(103, 26),
					Location = Vector2(117, 54),
					Text = lang:GetText("100/7天"),
					TextColor = ARGB(255, 242, 242, 242),
					HighlightTextColor = ARGB(255, 37, 37, 37),
					Font = "simhei",
					FontSize = 16,
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_normal.dds", Vector4(10, 10, 10, 10)),
						HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_hover.dds", Vector4(10, 10, 10, 10)),
						DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_down.dds", Vector4(10, 10, 10, 10)),
						DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_normal.dds", Vector4(10, 10, 10, 10)),
					},
					EventClick = function()
						if Renewals_window_ui then
							local rpc_data_items = L_LobbyMain.CharactersIB_rpc_data.items
							--七天
							if current_selected_item_class == 1 then
								rpc_data_items = L_LobbyMain.CharactersIB_rpc_data.items
								--仓库
							elseif current_selected_item_class == 0 then
								--背包
								if current_selected_ibtn_index > 0 and current_selected_ibtn_index < 5 then
									--武器
									rpc_data_items = L_LobbyMain.CharactersInfo_rpc_data.items.weapons
								elseif current_selected_ibtn_index > 4 and current_selected_ibtn_index < 8 then
									--装备
									rpc_data_items = L_LobbyMain.CharactersInfo_rpc_data.items.costume
								end
							end
							
							Renewals_window_ui.btn_three_days.PushDown = false
							Renewals_window_ui.btn_senven_days.PushDown = true
							Renewals_window_ui.btn_thirty_days.PushDown = false
							Renewals_window_ui.btn_forever.PushDown = false
							cost_mode = 2
							if current_selected_price_way == 1 then
								if current_selected_item_class == 0 and current_selected_ibtn_index > 4 and current_selected_ibtn_index < 8 then
									Renewals_window_ui.lbl_spend_point.Text = rpc_data_items[current_selected_ibtn_index - 4].crprices[cost_mode].cost .. " " .. price_way[1]
								else
									Renewals_window_ui.lbl_spend_point.Text = rpc_data_items[current_selected_ibtn_index].crprices[cost_mode].cost .. " " .. price_way[1]
								end	
								Renewals_window_ui.lbl_spend_GP.Text = "0 " .. price_way[2]
								Renewals_window_ui.lbl_spend_ticket.Text = "0 " .. price_way[3]
							elseif current_selected_price_way == 2 then
								Renewals_window_ui.lbl_spend_point.Text = "0 " .. price_way[1]
								if current_selected_item_class == 0 and current_selected_ibtn_index > 4 and current_selected_ibtn_index < 8 then
									Renewals_window_ui.lbl_spend_GP.Text = rpc_data_items[current_selected_ibtn_index - 4].gpprices[cost_mode].cost .. " " .. price_way[2]
								else
									Renewals_window_ui.lbl_spend_GP.Text = rpc_data_items[current_selected_ibtn_index].gpprices[cost_mode].cost .. " " .. price_way[2]
								end
								Renewals_window_ui.lbl_spend_ticket.Text = "0 " .. price_way[3]
							else
								Renewals_window_ui.lbl_spend_point.Text = "0 " .. price_way[1]
								Renewals_window_ui.lbl_spend_GP.Text = "0 " .. price_way[2]
								if current_selected_item_class == 0 and current_selected_ibtn_index > 4 and current_selected_ibtn_index < 8 then
									Renewals_window_ui.lbl_spend_ticket.Text = rpc_data_items[current_selected_ibtn_index - 4].voucherprices[cost_mode].cost .. " " .. price_way[3]
								else
									Renewals_window_ui.lbl_spend_ticket.Text = rpc_data_items[current_selected_ibtn_index].voucherprices[cost_mode].cost .. " " .. price_way[3]
								end
							end
						end
					end,
				},

				--三十天
				Gui.Button "btn_thirty_days"
				{
					Size = Vector2(103, 26),
					Location = Vector2(226, 54),
					Text = lang:GetText("500/30天"),
					TextColor = ARGB(255, 242, 242, 242),
					HighlightTextColor = ARGB(255, 37, 37, 37),
					Font = "simhei",
					FontSize = 16,
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_normal.dds", Vector4(10, 10, 10, 10)),
						HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_hover.dds", Vector4(10, 10, 10, 10)),
						DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_down.dds", Vector4(10, 10, 10, 10)),
						DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_normal.dds", Vector4(10, 10, 10, 10)),
					},
					EventClick = function()
						if Renewals_window_ui then
							local rpc_data_items = L_LobbyMain.CharactersIB_rpc_data.items
							if current_selected_item_class == 1 then
								rpc_data_items = L_LobbyMain.CharactersIB_rpc_data.items
							elseif current_selected_item_class == 0 then
								if current_selected_ibtn_index > 0 and current_selected_ibtn_index < 5 then
									rpc_data_items = L_LobbyMain.CharactersInfo_rpc_data.items.weapons
								elseif current_selected_ibtn_index > 4 and current_selected_ibtn_index < 8 then
									rpc_data_items = L_LobbyMain.CharactersInfo_rpc_data.items.costume
								end
							end
							cost_mode = 3
							Renewals_window_ui.btn_three_days.PushDown = false
							Renewals_window_ui.btn_senven_days.PushDown = false
							Renewals_window_ui.btn_thirty_days.PushDown = true
							Renewals_window_ui.btn_forever.PushDown = false
							if current_selected_price_way == 1 then
								if current_selected_item_class == 0 and current_selected_ibtn_index > 4 and current_selected_ibtn_index < 8 then
									Renewals_window_ui.lbl_spend_point.Text = rpc_data_items[current_selected_ibtn_index - 4].crprices[cost_mode].cost .. " " .. price_way[1]
								else
									Renewals_window_ui.lbl_spend_point.Text = rpc_data_items[current_selected_ibtn_index].crprices[cost_mode].cost .. " " .. price_way[1]
								end
								Renewals_window_ui.lbl_spend_GP.Text = "0 " .. price_way[2]
								Renewals_window_ui.lbl_spend_ticket.Text = "0 " .. price_way[3]
							elseif current_selected_price_way == 2 then
								Renewals_window_ui.lbl_spend_point.Text = "0 " .. price_way[1]
								if current_selected_item_class == 0 and current_selected_ibtn_index > 4 and current_selected_ibtn_index < 8 then
									Renewals_window_ui.lbl_spend_GP.Text = rpc_data_items[current_selected_ibtn_index - 4].gpprices[cost_mode].cost .. " " .. price_way[2]
								else
									Renewals_window_ui.lbl_spend_GP.Text = rpc_data_items[current_selected_ibtn_index].gpprices[cost_mode].cost .. " " .. price_way[2]
								end
								Renewals_window_ui.lbl_spend_ticket.Text = "0 " .. price_way[3]
							else
								Renewals_window_ui.lbl_spend_point.Text = "0 " .. price_way[1]
								Renewals_window_ui.lbl_spend_GP.Text = "0 " .. price_way[2]
								if current_selected_item_class == 0 and current_selected_ibtn_index > 4 and current_selected_ibtn_index < 8 then
									Renewals_window_ui.lbl_spend_ticket.Text = rpc_data_items[current_selected_ibtn_index - 4].voucherprices[cost_mode].cost .. " " .. price_way[3]
								else
									Renewals_window_ui.lbl_spend_ticket.Text = rpc_data_items[current_selected_ibtn_index].voucherprices[cost_mode].cost .. " " .. price_way[3]
								end
							end
						end
					end,
				},

				--永久
				Gui.Button "btn_forever"
				{
					Size = Vector2(103, 26),
					Location = Vector2(335, 54),
					Text = lang:GetText("1000/永久"),
					TextColor = ARGB(255, 242, 242, 242),
					HighlightTextColor = ARGB(255, 37, 37, 37),
					Font = "simhei",
					FontSize = 16,
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_normal.dds", Vector4(10, 10, 10, 10)),
						HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_hover.dds", Vector4(10, 10, 10, 10)),
						DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_down.dds", Vector4(10, 10, 10, 10)),
						DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_normal.dds", Vector4(10, 10, 10, 10)),
					},
					EventClick = function()
						if Renewals_window_ui then
							local rpc_data_items = L_LobbyMain.CharactersIB_rpc_data.items
							if current_selected_item_class == 1 then
								rpc_data_items = L_LobbyMain.CharactersIB_rpc_data.items
							elseif current_selected_item_class == 0 then
								if current_selected_ibtn_index > 0 and current_selected_ibtn_index < 5 then
									rpc_data_items = L_LobbyMain.CharactersInfo_rpc_data.items.weapons
								elseif current_selected_ibtn_index > 4 and current_selected_ibtn_index < 8 then
									rpc_data_items = L_LobbyMain.CharactersInfo_rpc_data.items.costume
								end
							end
							
							cost_mode = 4
							Renewals_window_ui.btn_three_days.PushDown = false
							Renewals_window_ui.btn_senven_days.PushDown = false
							Renewals_window_ui.btn_thirty_days.PushDown = false
							Renewals_window_ui.btn_forever.PushDown = true
							if current_selected_price_way == 1 then
								if current_selected_item_class == 0 and current_selected_ibtn_index > 4 and current_selected_ibtn_index < 8 then
									Renewals_window_ui.lbl_spend_point.Text = rpc_data_items[current_selected_ibtn_index - 4].crprices[cost_mode].cost .. " " .. price_way[1]
								else
									Renewals_window_ui.lbl_spend_point.Text = rpc_data_items[current_selected_ibtn_index].crprices[cost_mode].cost .. " " .. price_way[1]
								end
								Renewals_window_ui.lbl_spend_GP.Text = "0 " .. price_way[2]
								Renewals_window_ui.lbl_spend_ticket.Text = "0 " .. price_way[3]
							elseif current_selected_price_way == 2 then
								Renewals_window_ui.lbl_spend_point.Text = "0 " .. price_way[1]
								if current_selected_item_class == 0 and current_selected_ibtn_index > 4 and current_selected_ibtn_index < 8 then
									Renewals_window_ui.lbl_spend_GP.Text = rpc_data_items[current_selected_ibtn_index - 4].gpprices[cost_mode].cost .. " " .. price_way[2]
								else
									Renewals_window_ui.lbl_spend_GP.Text = rpc_data_items[current_selected_ibtn_index].gpprices[cost_mode].cost .. " " .. price_way[2]
								end
								Renewals_window_ui.lbl_spend_ticket.Text = "0 " .. price_way[3]
							else
								Renewals_window_ui.lbl_spend_point.Text = "0 " .. price_way[1]
								Renewals_window_ui.lbl_spend_GP.Text = "0 " .. price_way[2]
								if current_selected_item_class == 0 and current_selected_ibtn_index > 4 and current_selected_ibtn_index < 8 then
									Renewals_window_ui.lbl_spend_ticket.Text = rpc_data_items[current_selected_ibtn_index - 4].voucherprices[cost_mode].cost .. " " .. price_way[3]
								else
									Renewals_window_ui.lbl_spend_ticket.Text = rpc_data_items[current_selected_ibtn_index].voucherprices[cost_mode].cost .. " " .. price_way[3]
								end
							end
						end
					end,
				},
			},

			--余额
			Gui.Label "lbl_balance"
			{
				Size = Vector2(60, 19),
				Text = lang:GetText("余额"),
				Font = "simhei",
				FontSize = 15,
				Location = Vector2(10, 335),
				TextColor = ARGB(255, 37, 37, 37),
				--BackgroundColor = ARGB(255, 0, 0, 255),
			},
			
			--FC点
			Gui.Label "lbl_balance_point"
			{
				Size = Vector2(151, 21),
				--Text = lang:GetText("500FC点"),
				Font = "simhei",
				FontSize = 16,
				Location = Vector2(68, 334),
				BackgroundColor = ARGB(255, 255, 255, 255),
				TextColor = ARGB(255, 37, 37, 37),
				TextAlign = "kAlignRightMiddle",
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_box_huafei.dds", Vector4(10, 10, 10, 10)),
				},
			},
			
			--C币
			Gui.Label "lbl_balance_GP"
			{
				Size = Vector2(151, 21),
				Font = "simhei",
				FontSize = 16,
				Location = Vector2(68, 357),
				BackgroundColor = ARGB(255, 255, 255, 255),
				TextColor = ARGB(255, 37, 37, 37),
				TextAlign = "kAlignRightMiddle",
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_box_huafei.dds", Vector4(10, 10, 10, 10)),
				},
			},
			
			--抵用券
			Gui.Label "lbl_balance_ticket"
			{
				Visible = false,
				Size = Vector2(151, 21),
				--Text = lang:GetText("10抵用券"),
				Font = "simhei",
				FontSize = 16,
				Location = Vector2(68, 380),
				TextColor = ARGB(255, 37, 37, 37),
				BackgroundColor = ARGB(255, 255, 255, 255),
				TextAlign = "kAlignRightMiddle",
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_box_huafei.dds", Vector4(10, 10, 10, 10)),
				},
			},

			--花费
			Gui.Label "lbl_spend"
			{
				Size = Vector2(37, 19),
				Text = lang:GetText("花费"),
				Font = "simhei",
				FontSize = 16,
				Location = Vector2(252, 335),
				TextColor = ARGB(255, 37, 37, 37),
				--BackgroundColor = ARGB(255, 0, 0, 255),
			},
			--FC点
			Gui.Label "lbl_spend_point"
			{
				Size = Vector2(151, 21),
				--Text = lang:GetText("500FC点"),
				Font = "simhei",
				FontSize = 16,
				Location = Vector2(296, 334),
				BackgroundColor = ARGB(255, 255, 255, 255),
				TextColor = ARGB(255, 37, 37, 37),
				TextAlign = "kAlignRightMiddle",
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_box_huafei.dds", Vector4(10, 10, 10, 10)),
				},
			},
			--C币
			Gui.Label "lbl_spend_GP"
			{
				Size = Vector2(151, 21),
				Font = "simhei",
				FontSize = 16,
				Location = Vector2(296, 357),
				BackgroundColor = ARGB(255, 255, 255, 255),
				TextColor = ARGB(255, 37, 37, 37),
				TextAlign = "kAlignRightMiddle",
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_box_huafei.dds", Vector4(10, 10, 10, 10)),
				},
			},
			--抵用券
			Gui.Label "lbl_spend_ticket"
			{
				Visible = false,
				Size = Vector2(151, 21),
				--Text = lang:GetText("10抵用券"),
				Font = "simhei",
				FontSize = 16,
				Location = Vector2(296, 380),
				BackgroundColor = ARGB(255, 255, 255, 255),
				TextColor = ARGB(255, 37, 37, 37),
				TextAlign = "kAlignRightMiddle",
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_box_huafei.dds", Vector4(10, 10, 10, 10)),
				},
			},

			--续费
			Gui.Button "btn_buy"
			{
				Size = Vector2(104, 36),
				Location = Vector2(244, 424),
				Text = lang:GetText("续费"),
				
				TextColor = ARGB(255, 211, 211, 211),
				Font = "simhei",
				FontSize = 20,
				TextAlign = "kAlignCenterMiddle",
				Padding = Vector4(0, 0, 0, 6),
				BackgroundColor = ARGB(255, 255, 255, 255),
				-- PushDown = true 
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/lb_contact_button_normal.dds", Vector4(0, 0, 0, 0)),
					HoverImage = Gui.Image("LobbyUI/team/lb_contact_button_hover.dds", Vector4(0, 0, 0, 0)),
					DownImage = Gui.Image("LobbyUI/team/lb_contact_button_down.dds", Vector4(0, 0, 0, 0)),
					DisabledImage = Gui.Image("LobbyUI/team/lb_contact_button_normal.dds", Vector4(0, 0, 0, 0)),
				},
				EventClick = function()
					--续费
					
						if L_LobbyMain.CharactersIB_rpc_data and L_LobbyMain.CharactersInfo_rpc_data then
							local rpc_data_items = L_LobbyMain.CharactersIB_rpc_data.items
							if current_selected_item_class == 1 then
								rpc_data_items = L_LobbyMain.CharactersIB_rpc_data.items
							elseif current_selected_item_class == 0 then
								if current_selected_ibtn_index > 0 and current_selected_ibtn_index < 5 then
									rpc_data_items = L_LobbyMain.CharactersInfo_rpc_data.items.weapons
								elseif current_selected_ibtn_index > 4 and current_selected_ibtn_index < 8 then
									rpc_data_items = L_LobbyMain.CharactersInfo_rpc_data.items.costume
								end
							end
									
							local weapon_info = nil
							if current_selected_item_class == 0 and current_selected_ibtn_index > 4 then
								weapon_info = rpc_data_items[current_selected_ibtn_index - 4]
							else
								weapon_info = rpc_data_items[current_selected_ibtn_index]
							end
							if weapon_info then								
								if weapon_info.common.type == 1 then
								--武器
									L_LobbyMain.ClassBagIndex_Characters[L_LobbyMain.current_choose_class] = weapon_info.common.seq
									L_LobbyMain.ClassWeaponIndex_Characters[L_LobbyMain.current_choose_class] = weapon_info.common.seq
								elseif weapon_info.common.type == 2 then
								--套装
									L_LobbyMain.ClassBagIndex_Characters[L_LobbyMain.current_choose_class] = 5
								elseif weapon_info.common.type == 3 then
								--配饰
									L_LobbyMain.ClassBagIndex_Characters[L_LobbyMain.current_choose_class] = weapon_info.common.seq + 5
								end
								local costid = -1
								if current_selected_price_way == 1 then
									costid = weapon_info.crprices[cost_mode].id
								elseif current_selected_price_way == 2 then
									costid = weapon_info.gpprices[cost_mode].id
								elseif current_selected_price_way == 3 then
									costid = weapon_info.voucherprices[cost_mode].id
								end
								
								L_LobbyMain.Renewals(weapon_info.playeritemid, weapon_info.common.type, costid)
							end
						end		
						CloseRenewalsWin()
										
				end
			},
			
			--取消
			Gui.Button "btn_cancel"
			{
				Size = Vector2(106, 36),
				Location = Vector2(356, 424),
				Text = lang:GetText("取消"),
				TextColor = ARGB(255, 211, 211, 211),
				FontSize = 20,
				TextAlign = "kAlignCenterMiddle",
				Padding = Vector4(0, 0, 0, 6),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/lb_contact_button_normal.dds", Vector4(0, 0, 0, 0)),
					HoverImage = Gui.Image("LobbyUI/team/lb_contact_button_hover.dds", Vector4(0, 0, 0, 0)),
					DownImage = Gui.Image("LobbyUI/team/lb_contact_button_down.dds", Vector4(0, 0, 0, 0)),
					DisabledImage = Gui.Image("LobbyUI/team/lb_contact_button_normal.dds", Vector4(0, 0, 0, 0)),
				},
				EventClick = function()
					CloseRenewalsWin()
				end
			},
		},
	},
}

--填充续费界面
function FillRenewalsWindow()
	if Renewals_window_ui then
		if L_LobbyMain.CharactersIB_rpc_data and L_LobbyMain.CharactersInfo_rpc_data then
			local rpc_data_items = L_LobbyMain.CharactersIB_rpc_data.items
			if current_selected_item_class == 1 then
				rpc_data_items = L_LobbyMain.CharactersIB_rpc_data.items
			elseif current_selected_item_class == 0 then
				if current_selected_ibtn_index > 0 and current_selected_ibtn_index < 5 then
					rpc_data_items = L_LobbyMain.CharactersInfo_rpc_data.items.weapons
				elseif current_selected_ibtn_index > 4 and current_selected_ibtn_index < 8 then
					rpc_data_items = L_LobbyMain.CharactersInfo_rpc_data.items.costume
				end
			end		
		
			if L_LobbyMain.PersonalInfo_data then
				--FC点
				Renewals_window_ui.lbl_balance_point.Text = L_LobbyMain.PersonalInfo_data.newCR .. " " .. price_way[1]
				--C币
				Renewals_window_ui.lbl_balance_GP.Text = L_LobbyMain.PersonalInfo_data.newGP .. " " .. price_way[2]
				--抵用券
				Renewals_window_ui.lbl_balance_ticket.Text = L_LobbyMain.PersonalInfo_data.newTicket .. " " .. price_way[3]				
			end
			
			Renewals_window_ui.lbl_spend_point.Text = "0 " .. price_way[1]
			--[[
			if current_selected_item_class == 0 and current_selected_ibtn_index > 4 then
				Renewals_window_ui.lbl_spend_GP.Text = rpc_data_items[current_selected_ibtn_index - 4].gpprices[1].cost .. " " .. price_way[2]
			else
				Renewals_window_ui.lbl_spend_GP.Text = rpc_data_items[current_selected_ibtn_index].gpprices[1].cost .. " " .. price_way[2]
			end
			]]--
			Renewals_window_ui.lbl_spend_ticket.Text = "0 " .. price_way[3]
			cost_mode = 1
			
			local weapon_info = nil
			if current_selected_item_class == 0 and current_selected_ibtn_index > 4 then
				weapon_info = rpc_data_items[current_selected_ibtn_index - 4]
			else
				weapon_info = rpc_data_items[current_selected_ibtn_index]	
			end
			
			if weapon_info then
				if weapon_info.common.type == 1 then
					Renewals_window_ui.ctrl_goods_image.Size = Vector2(128, 64)
					Renewals_window_ui.ctrl_goods_image_root.Size = Vector2(160, 156)
				elseif weapon_info.common.type == 2 then
					Renewals_window_ui.ctrl_goods_image.Size = Vector2(100, 195)
					Renewals_window_ui.ctrl_goods_image_root.Size = Vector2(160, 195)
				else
					Renewals_window_ui.ctrl_goods_image.Size = Vector2(100, 96)
					Renewals_window_ui.ctrl_goods_image_root.Size = Vector2(160, 156)
				end
				local color = weapon_info.color
				local name = weapon_info.name
				if color >= 1 and color <= 8 then
					Renewals_window_ui.ctrl_goods_image.Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ibt_icon/"..name.."_"..color..".tga", Vector4(0, 0, 0, 0)),
					}
				else
					Renewals_window_ui.ctrl_goods_image.Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ibt_icon/"..name..".tga", Vector4(0, 0, 0, 0)),
					}
				end
				Renewals_window_ui.lbl_goods_name.Text = weapon_info.display
				Renewals_window_ui.lbl_goods_info.Text = weapon_info.description

				--付款方式
				local mode1 = weapon_info.crprices
				local mode2 = weapon_info.gpprices
				local mode3 = weapon_info.voucherprices

				--抵用券
				if mode3[1] then
					if mode3[1] then
						current_selected_price_way = 3						
						Renewals_window_ui.lbl_spend_point.Text = "0 " .. price_way[1]
						Renewals_window_ui.lbl_spend_GP.Text = "0 " .. price_way[2]
						if current_selected_item_class == 0 and current_selected_ibtn_index > 4 then
							Renewals_window_ui.lbl_spend_ticket.Text = rpc_data_items[current_selected_ibtn_index - 4].voucherprices[1].cost .. " " .. price_way[3]	
						else
							Renewals_window_ui.lbl_spend_ticket.Text = rpc_data_items[current_selected_ibtn_index].voucherprices[1].cost .. " " .. price_way[3]
						end
						if mode3[1].unittype == 0 then
							Renewals_window_ui.btn_three_days.Text = unittype_way[mode3[1].unittype + 1]
						else
							Renewals_window_ui.btn_three_days.Text = mode3[1].unit..unittype_way[mode3[1].unittype + 1]
						end
						Renewals_window_ui.btn_three_days.Visible = true
					else
						Renewals_window_ui.btn_three_days.Visible = false
					end

					if mode3[2] then
						if mode3[2].unittype == 0 then
							Renewals_window_ui.btn_senven_days.Text = unittype_way[mode3[2].unittype + 1]
						else
							Renewals_window_ui.btn_senven_days.Text = mode3[2].unit..unittype_way[mode3[2].unittype + 1]
						end
						Renewals_window_ui.btn_senven_days.Visible = true
					else
						Renewals_window_ui.btn_senven_days.Visible = false
					end

					if mode3[3] then
						if mode3[2].unittype == 0 then
							Renewals_window_ui.btn_thirty_days.Text = unittype_way[mode3[3].unittype + 1]
						else
							Renewals_window_ui.btn_thirty_days.Text = mode3[3].unit..unittype_way[mode3[3].unittype + 1]
						end
						Renewals_window_ui.btn_thirty_days.Visible = true
					else
						Renewals_window_ui.btn_thirty_days.Visible = false
					end

					if mode3[4] then
						if mode3[4].unittype == 0 then
							Renewals_window_ui.btn_forever.Text = unittype_way[mode3[4].unittype + 1]
						else
							Renewals_window_ui.btn_forever.Text = mode3[4].unit..unittype_way[mode3[4].unittype + 1]
						end
						Renewals_window_ui.btn_forever.Visible = true
					else
						Renewals_window_ui.btn_forever.Visible = false
					end
				end

				--C币
				if mode2[1] then
					if mode2[1] then
						current_selected_price_way = 2
						Renewals_window_ui.lbl_spend_point.Text = "0 " .. price_way[1]
						if current_selected_item_class == 0 and current_selected_ibtn_index > 4 then
							Renewals_window_ui.lbl_spend_GP.Text = rpc_data_items[current_selected_ibtn_index - 4].gpprices[1].cost .. " " .. price_way[2]
						else
							Renewals_window_ui.lbl_spend_GP.Text = rpc_data_items[current_selected_ibtn_index].gpprices[1].cost .. " " .. price_way[2]
						end
						
						Renewals_window_ui.lbl_spend_ticket.Text = "0 " .. price_way[3]
						if mode2[1].unittype == 0 then
							Renewals_window_ui.btn_three_days.Text = unittype_way[mode2[1].unittype + 1]
						else
							Renewals_window_ui.btn_three_days.Text = mode2[1].unit..unittype_way[mode2[1].unittype + 1]
						end
						Renewals_window_ui.btn_three_days.Visible = true
					else
						Renewals_window_ui.btn_three_days.Visible = false
					end

					if mode2[2] then
						if mode2[2].unittype == 0 then
							Renewals_window_ui.btn_senven_days.Text = unittype_way[mode2[2].unittype + 1]
						else
							Renewals_window_ui.btn_senven_days.Text = mode2[2].unit..unittype_way[mode2[2].unittype + 1]
						end
						Renewals_window_ui.btn_senven_days.Visible = true
					else
						Renewals_window_ui.btn_senven_days.Visible = false
					end

					if mode2[3] then
						if mode2[2].unittype == 0 then
							Renewals_window_ui.btn_thirty_days.Text = unittype_way[mode2[3].unittype + 1]
						else
							Renewals_window_ui.btn_thirty_days.Text = mode2[3].unit..unittype_way[mode2[3].unittype + 1]
						end
						Renewals_window_ui.btn_thirty_days.Visible = true
					else
						Renewals_window_ui.btn_thirty_days.Visible = false
					end

					if mode2[4] then
						if mode2[4].unittype == 0 then
							Renewals_window_ui.btn_forever.Text = unittype_way[mode2[4].unittype + 1]
						else
							Renewals_window_ui.btn_forever.Text = mode2[4].unit..unittype_way[mode2[4].unittype + 1]
						end
						Renewals_window_ui.btn_forever.Visible = true
					else
						Renewals_window_ui.btn_forever.Visible = false
					end
				end

				--FC点
				if mode1[1] then
					if mode1[1] then
						current_selected_price_way = 1
						if current_selected_item_class == 0 and current_selected_ibtn_index > 4 then
							Renewals_window_ui.lbl_spend_point.Text = rpc_data_items[current_selected_ibtn_index - 4].crprices[1].cost .. " " .. price_way[1]
						else
							Renewals_window_ui.lbl_spend_point.Text = rpc_data_items[current_selected_ibtn_index].crprices[1].cost .. " " .. price_way[1]
						end
						Renewals_window_ui.lbl_spend_GP.Text = "0 " .. price_way[2]
						Renewals_window_ui.lbl_spend_ticket.Text = "0 " .. price_way[3]
						if mode1[1].unittype == 0 then
							Renewals_window_ui.btn_three_days.Text = unittype_way[mode1[1].unittype + 1]
						else
							Renewals_window_ui.btn_three_days.Text = mode1[1].unit..unittype_way[mode1[1].unittype + 1]
						end
						Renewals_window_ui.btn_three_days.Visible = true
					else
						Renewals_window_ui.btn_three_days.Visible = false
					end

					if mode1[2] then
						if mode1[2].unittype == 0 then
							Renewals_window_ui.btn_senven_days.Text = unittype_way[mode1[2].unittype + 1]
						else
							Renewals_window_ui.btn_senven_days.Text = mode1[2].unit..unittype_way[mode1[2].unittype + 1]
						end
						Renewals_window_ui.btn_senven_days.Visible = true
					else
						Renewals_window_ui.btn_senven_days.Visible = false
					end

					if mode1[3] then
						if mode1[2].unittype == 0 then
							Renewals_window_ui.btn_thirty_days.Text = unittype_way[mode1[3].unittype + 1]
						else
							Renewals_window_ui.btn_thirty_days.Text = mode1[3].unit..unittype_way[mode1[3].unittype + 1]
						end
						Renewals_window_ui.btn_thirty_days.Visible = true
					else
						Renewals_window_ui.btn_thirty_days.Visible = false
					end

					if mode1[4] then
						if mode1[4].unittype == 0 then
							Renewals_window_ui.btn_forever.Text = unittype_way[mode1[4].unittype + 1]
						else
							Renewals_window_ui.btn_forever.Text = mode1[4].unit..unittype_way[mode1[4].unittype + 1]
						end
						Renewals_window_ui.btn_forever.Visible = true
					else
						Renewals_window_ui.btn_forever.Visible = false
					end
				end
			
				Renewals_window_ui.lb_page_number.Text = price_way[current_selected_price_way]
			end
		end
	end
end

--关闭续费界面
function CloseRenewalsWin()
	if Renewals_window_page_ui then
		Renewals_window_page_ui.Close()
		Renewals_window_page_ui = nil
	end
end

--创建续费界面
local function setup_Renewals_window(parent_window)
	if L_LobbyMain.CharactersIB_rpc_data and L_LobbyMain.CharactersInfo_rpc_data then
		Renewals_window_ui.btn_three_days.PushDown = true
		Renewals_window_ui.btn_senven_days.PushDown = false
		Renewals_window_ui.btn_thirty_days.PushDown = false
		Renewals_window_ui.btn_forever.PushDown = false
		local rpc_data_items = L_LobbyMain.CharactersIB_rpc_data.items
		if current_selected_item_class == 1 then
			rpc_data_items = L_LobbyMain.CharactersIB_rpc_data.items
		elseif current_selected_item_class == 0 then
			if current_selected_ibtn_index > 0 and current_selected_ibtn_index < 5 then
				rpc_data_items = L_LobbyMain.CharactersInfo_rpc_data.items.weapons
			elseif current_selected_ibtn_index > 4 and current_selected_ibtn_index < 8 then
				rpc_data_items = L_LobbyMain.CharactersInfo_rpc_data.items.costume
			end
		end
		local weapon_info = nil
		if current_selected_item_class == 0 and current_selected_ibtn_index > 4 then
			weapon_info = rpc_data_items[current_selected_ibtn_index - 4]
		else
			weapon_info = rpc_data_items[current_selected_ibtn_index]	
		end
		if weapon_info then
			if weapon_info.unit_type == 0 then
				MessageBox.ShowWithConfirm(lang:GetText("此商品无需续费"))
				return
			end
		end
	end
	if Renewals_window_page_ui then
		Renewals_window_page_ui.Close()
		Renewals_window_page_ui = nil
	end
	--创建界面
	Renewals_window_page_ui = ModalWindow.GetNew()
	Renewals_window_page_ui.root.Size = Vector2(1200,900)
	Renewals_window_page_ui.AllowEscToExit = false
	Renewals_window_ui.ctrl_window_root.Parent = Renewals_window_page_ui.root
	Renewals_window_ui.lbl_goods_info.VScrollBarWidth = 5
	Renewals_window_ui.lbl_goods_info.VScrollBarButtonSize = 0.1
	FillRenewalsWindow()
end

-------------------------------------------------------------------------------------------
--道具界面
local function create_prop_page(index, line, list)
	return Gui.ItemBoxBtn
	{
		Style = "Gui.ItemBoxBtn_ib2",
		BtnText =lang:GetText("使用"),
		Size = Vector2(104, 100),
		Location = Vector2(117*line, 100*list),
		BtnLocation = Vector2(64, 70),
		BtnSize = Vector2(35, 25),
		
		EventSelected = function(sender, e)
			if prop_window_ui and sender.Loading == false then
				for i = 1, 28 do
					local ibbtn = ptr_cast(prop_window_ui.ctrl_ib_container:GetChildByIndex(i-1))
					if i == index then
						ibbtn.Selected = true
					else
						ibbtn.Selected = false
					end
				end
				FillPropInfo(index)
			end
		end,

		EventMouseEnter = function(sender, e)
			if sender.Loading == false then
				L_ToolTips.FillToolTipsWindow(1, index, sender)
			end
		end,
		EventToolTipsShow = function(sender, e)
			L_ToolTips.ShowToolTipsShowWindow(sender)
		end,
		EventMouseLeave = function(sender, e)
			L_ToolTips.HideToolTipsWindow()
		end,
		
		EventBtnClick = function()
			L_LobbyMain.UseProp(index)
		end,
	}
end

function SpawnNewpropDestory()
	local newbutton = Gui.Create(gui)
	{
		Gui.Button "ib_destory"
		{
			Visible = false,
			Location = Vector2(29 - 25,100 - 28),
			Size = Vector2(20,20),
			FontSize = 12,
			Skin = Skin.ButtonSkin_ItemBoxBtn_destory,
			
			EventClick = function(Sender,e)
				for i = 1, 28 do
					local ibbtn = ptr_cast(prop_window_ui.ctrl_ib_container:GetChildByIndex(i-1))
					if Sender.Parent == ibbtn then
						L_LobbyMain.DestroyItem(i)
					end						
				end
			end
		},
	}
	return newbutton
end

function SpawnNewpropButton()
	local newbutton = Gui.Create(gui)
	{
		Gui.Button "ib_donate"
		{
			Visible = false,
			Location = Vector2(64 - 35,100 - 30),
			Size = Vector2(35,25),
			FontSize = 12,
			Text = lang:GetText("续费"),
			Skin = Skin.ButtonSkin_ItemBoxBtn,
			TextColor = ARGB(255, 0, 0, 0),
			
			EventClick = function(Sender,e)
				local ibbtn = nil
				local index = 0
				for i = 1, 28 do
					ibbtn = ptr_cast(prop_window_ui.ctrl_ib_container:GetChildByIndex(i-1))
					if Sender.Parent == ibbtn then
						index = i
						break
					end						
				end
					
				if Sender.Text == lang:GetText("维修") then
					L_LobbyMain.ShowAddPowerWindow(1, index)
				elseif Sender.Text == lang:GetText("续费") then
					local rpc_data_items = L_LobbyMain.CharactersIB_rpc_data.items
					if rpc_data_items and rpc_data_items[index] then
						if rpc_data_items[index].unit_type == 2 then
							current_selected_ibtn_index = index
							current_selected_item_class = 1
							setup_Renewals_window(L_LobbyMain.LobbyMainWin.LobbyMain_Root)
						else
							MessageBox.ShowWithConfirm(lang:GetText("此道具不需要续费，请到商城购买"))
						end
					else
						MessageBox.ShowWithConfirm(lang:GetText("续费失败！"))
					end			
					setup_Renewals_window(L_LobbyMain.LobbyMainWin.LobbyMain_Root)
				end
			end
		},
	}
	return newbutton
end

function SpawnNewpropControl()
	local newControl = Gui.Create(gui)
	{
		Gui.Control "ib_donate"
		{
			Size = Vector2(70, 16),
			Location = Vector2(29, 78),
			BackgroundColor = ARGB(0, 255, 255, 255),
			Gui.Control "c1"
			{
				Size = Vector2(20, 16),
				Location = Vector2(5, 0),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Visible = false,
			},
			Gui.Control "c2"
			{
				Size = Vector2(20, 16),
				Location = Vector2(20, 0),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Visible = false,
			},
			Gui.Control "c3"
			{
				Size = Vector2(20, 16),
				Location = Vector2(35, 0),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Visible = false,
			},
			Gui.Control "c4"
			{
				Size = Vector2(20, 16),
				Location = Vector2(50, 0),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Visible = false,
			},
		},
	}
	return newControl
end

local prop_window_page = 
{
	Gui.Control "ctrl_ib_container"
	{							
		Size = Vector2(832, 400),
		Location = Vector2(10, 60),
		BackgroundColor = ARGB(0, 255, 255, 255),
	
		create_prop_page(1, 0, 0),
		create_prop_page(2, 1, 0),
		create_prop_page(3, 2, 0),
		create_prop_page(4, 3, 0),
		create_prop_page(5, 4, 0),
		create_prop_page(6, 5, 0),
		create_prop_page(7, 6, 0),
		
		create_prop_page(8, 0, 1),
		create_prop_page(9, 1, 1),
		create_prop_page(10, 2, 1),
		create_prop_page(11, 3, 1),
		create_prop_page(12, 4, 1),
		create_prop_page(13, 5, 1),
		create_prop_page(14, 6, 1),
		
		create_prop_page(15, 0, 2),
		create_prop_page(16, 1, 2),
		create_prop_page(17, 2, 2),
		create_prop_page(18, 3, 2),
		create_prop_page(19, 4, 2),
		create_prop_page(20, 5, 2),
		create_prop_page(21, 6, 2),
		
		
		create_prop_page(22, 0, 3),
		create_prop_page(23, 1, 3),
		create_prop_page(24, 2, 3),
		create_prop_page(25, 3, 3),
		create_prop_page(26, 4, 3),
		create_prop_page(27, 5, 3),
		create_prop_page(28, 6, 3),
	},
}

local function setup_ib_prop(parent_window)
	--界面是否存在
	if prop_window_ui then
		prop_window_ui.ctrl_ib_container.Parent = parent_window
		return
	end
	--创建界面
	prop_window_ui = Gui.Create(parent_window)(prop_window_page)
	
	for i = 1, 28 do
		local ibbtn = ptr_cast(prop_window_ui.ctrl_ib_container:GetChildByIndex(i-1))
		local newbutton = SpawnNewpropButton()
		local desrotyButton = SpawnNewpropDestory()
		local newControl = SpawnNewpropControl()
		ibbtn.ItemBtnSkin = Skin.ButtonSkin_ItemBoxBtn_buy
		newbutton.ib_donate.Parent = ibbtn
		desrotyButton.ib_destory.Parent = ibbtn
		newControl.ib_donate.Parent = ibbtn
	end
end

-------------------------------------------------------------------------------------------
--配饰界面
local function create_accessories_page(index, line, list)
	return Gui.ItemBoxBtn
	{
		Style = "Gui.ItemBoxBtn_ib2",
		Size = Vector2(104, 100),
		Location = Vector2(104*line, 100*list),
		BtnLocation = Vector2(104-40, 100-25),
		BtnSize = Vector2(35,25),
		
		--event function 
		EventSelected = function(sender, e)
			if ib_accessories_ui and sender.Loading == false then
				for i = 1, 16 do
					local ibbtn = ptr_cast(ib_accessories_ui.ctrl_ib_container:GetChildByIndex(i-1))
					if i == index then
						ibbtn.Selected = true
					else
						ibbtn.Selected = false
					end
				end
			end
			current_selected_item_class = 1
			current_selected_ibtn_index = index
			L_LobbyMain.ChangeAvatarPart()
			RestAllCharacterBagItemBoxBtn()
		end,
		
		EventMouseRightDown = function(sender, e)
			if tuozhuai_ui == nil then
				tuozhuai_ui = Gui.Create(L_LobbyMain.LobbyMainWin.LobbyMain_Root)(tuozhuai)
			end
			index_tz = index
			tuozhuai_ui.root.Visible = true 
			local lobby_state = ptr_cast(game.CurrentState)
			local cursor_ScreenSize = lobby_state:GetScreenSize()
			local cursor_pos = lobby_state:GetCursorPos()
			tuozhuai_ui.Image.Location = Vector2(cursor_pos.x-((cursor_ScreenSize.x - cursor_ScreenSize.y / 3 * 4) / 2) - 51, cursor_pos.y - 34)
			tuozhuai_ui.Image.Size = Vector2(72, 68)
			if L_LobbyMain.CharactersIB_rpc_data.items[index].color >= 1 and L_LobbyMain.CharactersIB_rpc_data.items[index].color <= 8 then
				tuozhuai_ui.Image.Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ibt_icon/"..L_LobbyMain.CharactersIB_rpc_data.items[index].name.."_"..L_LobbyMain.CharactersIB_rpc_data.items[index].color..".tga", Vector4(0, 0, 0, 0)),
				}
			else
				tuozhuai_ui.Image.Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ibt_icon/"..L_LobbyMain.CharactersIB_rpc_data.items[index].name..".tga", Vector4(0, 0, 0, 0)),
				}
			end
			local ibbtn = ptr_cast(ib_accessories_ui.ctrl_ib_container:GetChildByIndex(index-1))
			ibbtn.ItemIcon.alpha = 80
			Highlight_accessories_tip(index)
		end,

		EventMouseEnter = function(sender, e)
			if sender.Loading == false then
				L_ToolTips.FillToolTipsWindow(1, index, sender)
			end
		end,
		EventToolTipsShow = function(sender, e)
			L_ToolTips.ShowToolTipsShowWindowContrast(sender)
		end,
		EventMouseLeave = function(sender, e)
			L_ToolTips.HideToolTipsWindow()
		end,

		EventBtnClick = function(sender, e)
			L_LobbyMain.RpcEquipWeapon(index)
		end,
	}
end

function SpawnNewaccessoriesDestory()
	local newbutton = Gui.Create(gui)
    {
		Gui.Button "ib_destory"
		{
			Visible = false,
			Location = Vector2(29 - 20,100 - 23),
			Size = Vector2(20,20),
			FontSize = 12,
			Skin = Skin.ButtonSkin_ItemBoxBtn_destory,
			
			EventClick = function(Sender,e)
				for i = 1, 16 do
					local ibbtn = ptr_cast(ib_accessories_ui.ctrl_ib_container:GetChildByIndex(i-1))
					if Sender.Parent == ibbtn then
						L_LobbyMain.DestroyItem(i)
					end						
				end
			end
		},
    }
	return newbutton
end

function SpawnNewaccessoriesButton()
	local newbutton = Gui.Create(gui)
	{
		Gui.Button "ib_donate"
		{
			Visible = false,
			Location = Vector2(64 - 35,100 - 25),
			Size = Vector2(35,25),
			FontSize = 12,
			Text = lang:GetText("续费"),
			Skin = Skin.ButtonSkin_ItemBoxBtn,
			TextColor = ARGB(255, 0, 0, 0),
			
			EventClick = function(Sender,e)
				local ibbtn = nil
				local index = 0
				for i = 1, 16 do
					ibbtn = ptr_cast(ib_accessories_ui.ctrl_ib_container:GetChildByIndex(i-1))
					if Sender.Parent == ibbtn then
						index = i
						break
					end						
				end
					
				if Sender.Text == lang:GetText("维修") then
					L_LobbyMain.ShowAddPowerWindow(1, index)
				elseif Sender.Text == lang:GetText("续费") then
					current_selected_ibtn_index = index
					current_selected_item_class = 1
					setup_Renewals_window(L_LobbyMain.LobbyMainWin.LobbyMain_Root)
				end
			end
		},
	}
	return newbutton
end

function SpawnNewaccessoriesControl()
	local newcontrol = Gui.Create(gui)
	{
		Gui.Control "ib_Compose"
		{			
			Visible = false,
			Size = Vector2(54,30),
			Location = Vector2(64 - 19,100 - 55),
			BackgroundColor = ARGB(255, 255, 255, 255),
		},
	}
	return newcontrol
end

function SpawnNewaccessoriesStarControl()
	local newcontrol = Gui.Create(gui)
	{
		Gui.Control "ib_star"
		{			
			Visible = false,
			Size = Vector2(60,12),
			Location = Vector2(20,10),
			BackgroundColor = ARGB(255, 255, 255, 255),
		},
	}
	return newcontrol
end

local accessories_info_page =
{
	Gui.Control "ctrl_ib_container"
	{							
		Size = Vector2(415, 400),
		Location = Vector2(19, 55),
		BackgroundColor = ARGB(0, 255, 255, 255),
			
		create_accessories_page(1, 0, 0),
		create_accessories_page(2, 1, 0),
		create_accessories_page(3, 2, 0),
		create_accessories_page(4, 3, 0),
		
		create_accessories_page(5, 0, 1),
		create_accessories_page(6, 1, 1),
		create_accessories_page(7, 2, 1),
		create_accessories_page(8, 3, 1),
		
		create_accessories_page(9, 0, 2),
		create_accessories_page(10, 1, 2),
		create_accessories_page(11, 2, 2),
		create_accessories_page(12, 3, 2),
		
		create_accessories_page(13, 0, 3),
		create_accessories_page(14, 1, 3),
		create_accessories_page(15, 2, 3),
		create_accessories_page(16, 3, 3),
	},
}

local function setup_ib_accessories(parent_window)
	if ib_weapon_ui then
		ib_weapon_ui.Parent = nil
	end

	if ib_dress_ui then
		ib_dress_ui.Parent = nil
	end

	--界面是否存在
	if ib_accessories_ui then
		ib_accessories_ui.ctrl_ib_container.Parent = parent_window
		return
	end
	--创建界面
	ib_accessories_ui = Gui.Create(parent_window)(accessories_info_page)
	
	for i = 1, 16 do
		local ibbtn = ptr_cast(ib_accessories_ui.ctrl_ib_container:GetChildByIndex(i-1))
		local newbutton = SpawnNewaccessoriesButton()
		local desrotyButton = SpawnNewaccessoriesDestory()
		local Control = SpawnNewaccessoriesControl()
		local Star = SpawnNewaccessoriesStarControl()
		ibbtn.ItemBtnSkin = Skin.ButtonSkin_ItemBoxBtn_buy
		newbutton.ib_donate.Parent = ibbtn
		desrotyButton.ib_destory.Parent = ibbtn
		Control.ib_Compose.Parent = ibbtn
		Star.ib_star.Parent = ibbtn
		Star.ib_star.Location = Vector2(10,10)
	end
end

-------------------------------------------------------------------------------------------
--服装界面
local function create_dress_page(index, line, list)
	return Gui.ItemBoxBtn
	{
		Style = "Gui.ItemBoxBtn_ib1",
		Size = Vector2(104, 200),
		Location = Vector2(104*line, 200*list),
		BtnLocation = Vector2(104 - 40, 200 - 27),
		BtnSize = Vector2(35,25),
		
		--event function 
		EventSelected = function(sender, e)
			if ib_dress_ui and sender.Loading == false then
				for i = 1, 8 do
					local ibbtn = ptr_cast(ib_dress_ui.ctrl_ib_container:GetChildByIndex(i-1))
					if i == index then
						ibbtn.Selected = true
					else
						ibbtn.Selected = false
					end
				end
			end
			current_selected_item_class = 1
			current_selected_ibtn_index = index
			L_LobbyMain.ChangeAvatarPart()
			RestAllCharacterBagItemBoxBtn()
		end,
		
		EventMouseRightDown = function(sender, e)
			if tuozhuai_ui == nil then
				tuozhuai_ui = Gui.Create(L_LobbyMain.LobbyMainWin.LobbyMain_Root)(tuozhuai)
			end
			index_tz = index
			tuozhuai_ui.root.Visible = true
			local lobby_state = ptr_cast(game.CurrentState)
			local cursor_ScreenSize = lobby_state:GetScreenSize()
			local cursor_pos = lobby_state:GetCursorPos()
			tuozhuai_ui.Image.Location = Vector2(cursor_pos.x-((cursor_ScreenSize.x - cursor_ScreenSize.y / 3 * 4) / 2) - 55, cursor_pos.y - 78)
			tuozhuai_ui.Image.Size = Vector2(80, 156)
			if L_LobbyMain.CharactersIB_rpc_data.items[index].color >= 1 and L_LobbyMain.CharactersIB_rpc_data.items[index].color <= 8 then
				tuozhuai_ui.Image.Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ibt_icon/"..L_LobbyMain.CharactersIB_rpc_data.items[index].name.."_"..L_LobbyMain.CharactersIB_rpc_data.items[index].color..".tga", Vector4(0, 0, 0, 0)),
				}
			else
				tuozhuai_ui.Image.Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ibt_icon/"..L_LobbyMain.CharactersIB_rpc_data.items[index].name..".tga", Vector4(0, 0, 0, 0)),
				}
			end
			local ibbtn = ptr_cast(ib_dress_ui.ctrl_ib_container:GetChildByIndex(index-1))
			ibbtn.ItemIcon.alpha = 80
			user_bag_info_ui.ib_no_use.Highlight = true
		end,

		EventMouseEnter = function(sender, e)
			if sender.Loading == false then
				L_ToolTips.FillToolTipsWindow(1, index, sender)
			end
		end,
		EventToolTipsShow = function(sender, e)
			L_ToolTips.ShowToolTipsShowWindowContrast(sender)
		end,
		EventMouseLeave = function(sender, e)
			L_ToolTips.HideToolTipsWindow()
		end,

		EventBtnClick = function(sender, e)
			L_LobbyMain.RpcEquipWeapon(index)
		end,
	}
end


function SpawnNewdressDestory()
	local newbutton = Gui.Create(gui)
	{
		Gui.Button "ib_destory"
		{
			Visible = false,
			Location = Vector2(29  - 20,200 - 25),
			Size = Vector2(20,20),
			FontSize = 12,
			Skin = Skin.ButtonSkin_ItemBoxBtn_destory,
			
			EventClick = function(Sender,e)
				for i = 1, 8 do
					local ibbtn = ptr_cast(ib_dress_ui.ctrl_ib_container:GetChildByIndex(i-1))
					if Sender.Parent == ibbtn then
						L_LobbyMain.DestroyItem(i)
					end						
				end
			end
		},
	}
	return newbutton
end

function SpawnNewdressButton()
	local newbutton = Gui.Create(gui)
	{
		Gui.Button "ib_donate"
		{
			Visible = false,
			Location = Vector2(64 - 35,200 - 27),
			Size = Vector2(35,25),
			FontSize = 12,
			Text = lang:GetText("续费"),
			Skin = Skin.ButtonSkin_ItemBoxBtn,
			TextColor = ARGB(255, 0, 0, 0),
			EventClick = function(Sender,e)
				local ibbtn = nil
				local index = 0
				for i = 1, 8 do
					ibbtn = ptr_cast(ib_dress_ui.ctrl_ib_container:GetChildByIndex(i-1))
					if Sender.Parent == ibbtn then
						index = i
						break
					end						
				end
					
				if Sender.Text == lang:GetText("维修") then
					L_LobbyMain.ShowAddPowerWindow(1, index)
				elseif Sender.Text == lang:GetText("续费") then
					current_selected_ibtn_index = index
					current_selected_item_class = 1
					setup_Renewals_window(L_LobbyMain.LobbyMainWin.LobbyMain_Root)
				end
			end
		},
	}
	return newbutton
end

function SpawnNewdressControl()
	local newcontrol = Gui.Create(gui)
	{
		Gui.Control "ib_Compose"
		{			
			Visible = false,
			Size = Vector2(54,30),
			Location = Vector2(64 - 19,200 - 57),
			BackgroundColor = ARGB(255, 255, 255, 255),
		},
	}
	return newcontrol
end

function SpawnNewdressStarControl()
	local newcontrol = Gui.Create(gui)
	{
		Gui.Control "ib_star"
		{			
			Visible = false,
			Size = Vector2(60,12),
			Location = Vector2(0,10),
			BackgroundColor = ARGB(255, 255, 255, 255),
		},
	}
	return newcontrol
end

local dress_info_page =
{
	Gui.Control "ctrl_ib_container"
	{							
		Size = Vector2(415, 400),
		Location = Vector2(19, 55),
		BackgroundColor = ARGB(0, 255, 255, 255),

		create_dress_page(1, 0, 0),
		create_dress_page(2, 1, 0),
		create_dress_page(3, 2, 0),
		create_dress_page(4, 3, 0),
		create_dress_page(5, 0, 1),
		create_dress_page(6, 1, 1),
		create_dress_page(7, 2, 1),
		create_dress_page(8, 3, 1),
	},
}

local function setup_ib_dress(parent_window)
	if ib_weapon_ui then
		ib_weapon_ui.ctrl_ib_container.Parent = nil
	end

	if ib_accessories_ui then
		ib_accessories_ui.ctrl_ib_container.Parent = nil
	end

	--界面是否存在
	if ib_dress_ui then
		ib_dress_ui.ctrl_ib_container.Parent = parent_window
		return
	end
	--创建界面
	ib_dress_ui = Gui.Create(parent_window)(dress_info_page)
	
	for i = 1, 8 do
		local ibbtn = ptr_cast(ib_dress_ui.ctrl_ib_container:GetChildByIndex(i-1))
		local newbutton = SpawnNewdressButton()
		local desrotyButton = SpawnNewdressDestory()
		local Control = SpawnNewdressControl()
		local Star = SpawnNewdressStarControl()
		ibbtn.ItemBtnSkin = Skin.ButtonSkin_ItemBoxBtn_buy
		newbutton.ib_donate.Parent = ibbtn
		desrotyButton.ib_destory.Parent = ibbtn
		Control.ib_Compose.Parent = ibbtn
		Star.ib_star.Parent = ibbtn
		Star.ib_star.Location = Vector2(10,10)
	end
end

-------------------------------------------------------------------------------------------
--武器界面
local function create_weapon_page(index, line, list)
	return Gui.ItemBoxBtn
	{
		Style = "Gui.ItemBoxBtn_ib",
		Size = Vector2(212, 100),
		Location = Vector2(212*line, 100*list),
		BtnSize = Vector2(40,25),
		BtnLocation = Vector2(212-45,100-28),
		PBBaseSkin = Skin.EmpowermentBaseSkin,
		PBTopSkin = Skin.EmpowermentTopSkin,
		PBBaseLocation = Vector2(4, 25),
		PBTopLocation = Vector2(4, 25),
		PBBaseSize = Vector2(16, 48),
		PBTopSize = Vector2(16, 48),
			
		EventSelected = function(sender, e)
			if ib_weapon_ui and sender.Loading == false then
				for i = 1, 8 do
					local ibbtn = ptr_cast(ib_weapon_ui.ctrl_ib_container:GetChildByIndex(i-1))
					if i == index then
						ibbtn.Selected = true
					else
						ibbtn.Selected = false
					end
				end
			end
			current_selected_item_class = 1
			current_selected_ibtn_index = index
			L_LobbyMain.ChangeAvatarPart()
			RestAllCharacterBagItemBoxBtn()
		end,

		EventMouseRightDown = function(sender, e)
			if tuozhuai_ui == nil then
				tuozhuai_ui = Gui.Create(L_LobbyMain.LobbyMainWin.LobbyMain_Root)(tuozhuai)
			end
			index_tz = index
			tuozhuai_ui.root.Visible = true
			local lobby_state = ptr_cast(game.CurrentState)
			local cursor_ScreenSize = lobby_state:GetScreenSize()
			local cursor_pos = lobby_state:GetCursorPos()
			tuozhuai_ui.Image.Location = Vector2(cursor_pos.x-((cursor_ScreenSize.x - cursor_ScreenSize.y / 3 * 4) / 2) - 99, cursor_pos.y - 38)
			tuozhuai_ui.Image.Size = Vector2(168, 76)
			if L_LobbyMain.CharactersIB_rpc_data.items[index].color >= 1 and L_LobbyMain.CharactersIB_rpc_data.items[index].color <= 8 then
				tuozhuai_ui.Image.Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ibt_icon/"..L_LobbyMain.CharactersIB_rpc_data.items[index].name.."_"..L_LobbyMain.CharactersIB_rpc_data.items[index].color..".tga", Vector4(0, 0, 0, 0)),
				}
			else
				tuozhuai_ui.Image.Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ibt_icon/"..L_LobbyMain.CharactersIB_rpc_data.items[index].name..".tga", Vector4(0, 0, 0, 0)),
				}
			end
			local ibbtn = ptr_cast(ib_weapon_ui.ctrl_ib_container:GetChildByIndex(index-1))
			ibbtn.ItemIcon.alpha = 80
			Highlight_weapon_tip(index)
		end,
		
		EventMouseEnter = function(sender, e)
			if sender.Loading == false then
				L_ToolTips.FillToolTipsWindow(1, index, sender)
			end
		end,
		EventToolTipsShow = function(sender, e)
			L_ToolTips.ShowToolTipsShowWindowContrast(sender)
		end,
		EventMouseLeave = function(sender, e)
			L_ToolTips.HideToolTipsWindow()
		end,

		EventBtnClick = function(sender, e)
			L_LobbyMain.RpcEquipWeapon(index)
		end,
	}
end

function SpawnNewWeaponDestory()
	local newbutton = Gui.Create(gui)
	{
		Gui.Button "ib_destory"
		{
			Visible = false,
			Location = Vector2(212 - 200,100 - 25),
			Size = Vector2(20,20),
			FontSize = 12,
			Skin = Skin.ButtonSkin_ItemBoxBtn_destory,
			
			EventClick = function(Sender,e)
				for i = 1, 8 do
					local ibbtn = ptr_cast(ib_weapon_ui.ctrl_ib_container:GetChildByIndex(i-1))
					if Sender.Parent == ibbtn then
						L_LobbyMain.DestroyItem(i)
					end						
				end
			end
		},
	}
	return newbutton
end

function SpawnNewWeaponButton()
	local newbutton = Gui.Create(gui)
	{
		Gui.Button "ib_donate"
		{
			Visible = false,
			Location = Vector2(212 - 85,100 - 28),
			Size = Vector2(40,25),
			FontSize = 12,
			Text = lang:GetText("维修"),
			Skin = Skin.ButtonSkin_ItemBoxBtn,
			TextColor = ARGB(255, 0, 0, 0),
			
			EventClick = function(Sender,e)
				local ibbtn = nil
				local index = 0
				for i = 1, 8 do
					ibbtn = ptr_cast(ib_weapon_ui.ctrl_ib_container:GetChildByIndex(i-1))
					if Sender.Parent == ibbtn then
						index = i
						break
					end						
				end
					
				if Sender.Text == lang:GetText("维修") then
					L_LobbyMain.ShowAddPowerWindow(1, index)
				elseif Sender.Text == lang:GetText("续费") then
					current_selected_ibtn_index = index
					current_selected_item_class = 1
					setup_Renewals_window(L_LobbyMain.LobbyMainWin.LobbyMain_Root)
				end
			end
		},
	}
	return newbutton
end

function SpawnNewWeaponControl()
	local newcontrol = Gui.Create(gui)
	{
		Gui.Control "ib_Compose"
		{			
			Visible = false,
			Size = Vector2(54,30),
			Location = Vector2(212 - 60,100 - 57),
			BackgroundColor = ARGB(255, 255, 255, 255),
		},
	}
	return newcontrol
end

function SpawnNewStarControl()
	local newcontrol = Gui.Create(gui)
	{
		Gui.Control "ib_star"
		{			
			Visible = false,
			Size = Vector2(68,12),
			Location = Vector2(212 - 112,10),
			BackgroundColor = ARGB(255, 255, 255, 255),
		},
	}
	return newcontrol
end

function SpawnCharacterStarControl()
	local newcontrol = Gui.Create(gui)
	{
		Gui.Control "ib_star"
		{			
			Visible = false,
			Size = Vector2(46,12),
			Location = Vector2(10,10),
			BackgroundColor = ARGB(255, 255, 255, 255),
		},
	}
	return newcontrol
end

local weapon_info_page =
{
	Gui.Control "ctrl_ib_container"
	{							
		Size = Vector2(424, 400),
		Location = Vector2(19, 55),
		BackgroundColor = ARGB(0, 255, 255, 255),
		
		create_weapon_page(1, 0, 0),
		create_weapon_page(2, 1, 0),
		
		create_weapon_page(3, 0, 1),
		create_weapon_page(4, 1, 1),
		
		create_weapon_page(5, 0, 2),
		create_weapon_page(6, 1, 2),
		
		create_weapon_page(7, 0, 3),
		create_weapon_page(8, 1, 3),
	},
}

local function setup_ib_weapon(parent_window)
	if ib_dress_ui then
		ib_dress_ui.ctrl_ib_container.Parent = nil
	end

	if ib_accessories_ui then
		ib_accessories_ui.ctrl_ib_container.Parent = nil
	end

	if ib_weapon_ui then
		ib_weapon_ui.ctrl_ib_container.Parent = parent_window
		return
	end
	
	ib_weapon_ui = Gui.Create(parent_window)(weapon_info_page)
	
	for i = 1, 8 do
		local ibbtn = ptr_cast(ib_weapon_ui.ctrl_ib_container:GetChildByIndex(i-1))
		local newbutton = SpawnNewWeaponButton()
		local desrotyButton = SpawnNewWeaponDestory()
		local Control = SpawnNewWeaponControl()
		local Star = SpawnNewStarControl()
		ibbtn.ItemBtnSkin = Skin.ButtonSkin_ItemBoxBtn_buy
		newbutton.ib_donate.Parent = ibbtn
		desrotyButton.ib_destory.Parent = ibbtn
		Control.ib_Compose.Parent = ibbtn
		Star.ib_star.Parent = ibbtn
		Star.ib_star.Location = Vector2(212 - 112,10)
	end
end

-------------------------------------------------------------------------------------------

function Highlight_weapon_tip(index1)
	if L_LobbyMain.CharactersIB_rpc_data.items[index1].common.seq == 1 then
		user_bag_info_ui.ib_primary_weapon.Highlight = true
	elseif L_LobbyMain.CharactersIB_rpc_data.items[index1].common.seq == 2 then
		user_bag_info_ui.ib_secondary_weapon.Highlight = true
	elseif L_LobbyMain.CharactersIB_rpc_data.items[index1].common.seq == 3 then
		user_bag_info_ui.ib_melee_weapons.Highlight = true
	else
		user_bag_info_ui.ib_grenade.Highlight = true
	end
end

-------------------------------------------------------------------------------------------
--战场背包 
local user_bag_info_page =
{
	Gui.Control "ctrl_ib_container"
	{							
		Size = Vector2(180, 457),
		Location = Vector2(1, 0),
		BackgroundColor = ARGB(0, 255, 255, 255),
		
		--主武器
		Gui.ItemBoxBtn "ib_primary_weapon"
		{
			Style = "Gui.ItemBoxBtn_ib",
			Size = Vector2(175, 80),
			Location = Vector2(3, 46),
			PBBaseSkin = Skin.EmpowermentBaseSkin,
			PBTopSkin = Skin.EmpowermentTopSkin,
			PBBaseLocation = Vector2(4, 10),
			PBTopLocation = Vector2(4, 10),
			PBBaseSize = Vector2(16, 48),
			PBTopSize = Vector2(16, 48),
			Padding = Vector4(0, 0, 0, 4),
			Skin = Gui.ItemBoxBtnSkin
			{
				NeutralNormalImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche1_normal.dds", Vector4(10, 10, 10, 10)),
				NeutralHoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche1_hover.dds", Vector4(10, 10, 10, 10)),
				NeutralSelectedImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_wuqi_down.dds", Vector4(10, 10, 10, 10)),
				NeutralDisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_caowei_zhuwuqi.dds", Vector4(10, 10, 10, 10)),
				NeutralHighlightImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche1_hover.dds", Vector4(20, 20, 20, 20)),
			},
			ItemBtnSkin = Skin.ButtonSkin_ItemBoxBtn,
			BtnVisible = false,
			-- EventBtnClick = function(sender, e)
				-- rpc.safecall("storage_req_unpack", {pid = ptr_cast(game.CurrentState):GetCharacterId(), cid = L_LobbyMain.current_choose_class, t = 1, seq = 1},
							-- function(data)
							-- end)
			-- end,
			--event function
			EventSelected = function(sender, e)
				if user_bag_info_ui and sender.Loading == false then
					for i = 1, 7 do
						local ibbtn = ptr_cast(user_bag_info_ui.ctrl_ib_container:GetChildByIndex(i-1))
						if i == 1 then
							ibbtn.Selected = true
						else
							ibbtn.Selected = false
						end
					end
				end
				L_LobbyMain.ClassWeaponIndex_Characters[L_LobbyMain.current_choose_class] = 1
				L_LobbyMain.ClassBagIndex_Characters[L_LobbyMain.current_choose_class] = 1
				current_selected_item_class = 0
				current_selected_ibtn_index = 1
				L_LobbyMain.ChangeAvatarPart()
				RestAllStorgeItemBoxBtn()
			end,

			EventMouseEnter = function(sender, e)
				if sender.Loading == false then
					L_ToolTips.FillToolTipsWindow(3, 1, sender)
				end
			end,
			EventToolTipsShow = function(sender, e)
				L_ToolTips.ShowToolTipsShowWindow(sender)
			end,
			EventMouseLeave = function(sender, e)
				L_ToolTips.HideToolTipsWindow()
			end,
		},

		--副武器
		Gui.ItemBoxBtn "ib_secondary_weapon"
		{
			Style = "Gui.ItemBoxBtn_ib",
			Size = Vector2(175, 80),
			Location = Vector2(3, 126),
			PBBaseSkin = Skin.EmpowermentBaseSkin,
			PBTopSkin = Skin.EmpowermentTopSkin,
			PBBaseLocation = Vector2(4, 10),
			PBTopLocation = Vector2(4, 10),
			PBBaseSize = Vector2(16, 48),
			PBTopSize = Vector2(16, 48),
			Padding = Vector4(0, 0, 0, 4),
			
			Skin = Gui.ItemBoxBtnSkin
			{
				NeutralNormalImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche1_normal.dds", Vector4(10, 10, 10, 10)),
				NeutralHoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche1_hover.dds", Vector4(10, 10, 10, 10)),
				NeutralSelectedImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_wuqi_down.dds", Vector4(10, 10, 10, 10)),
				NeutralDisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_caowei_fuwuqi.dds", Vector4(10, 10, 10, 10)),
				NeutralHighlightImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche1_hover.dds", Vector4(20, 20, 20, 20)),
			},
			ItemBtnSkin = Skin.ButtonSkin_ItemBoxBtn,
			BtnVisible = false,
			-- EventBtnClick = function(sender, e)
				-- rpc.safecall("storage_req_unpack", {pid = ptr_cast(game.CurrentState):GetCharacterId(), cid = L_LobbyMain.current_choose_class, t = 1, seq = 2},
							-- function(data)
							-- end)
			-- end,
			EventSelected = function(sender, e)
				if user_bag_info_ui and sender.Loading == false then
					for i = 1, 7 do
						local ibbtn = ptr_cast(user_bag_info_ui.ctrl_ib_container:GetChildByIndex(i-1))
						if i == 2 then
							ibbtn.Selected = true
						else
							ibbtn.Selected = false
						end
					end
				end
				L_LobbyMain.ClassWeaponIndex_Characters[L_LobbyMain.current_choose_class] = 2
				L_LobbyMain.ClassBagIndex_Characters[L_LobbyMain.current_choose_class] = 2
				current_selected_item_class = 0
				current_selected_ibtn_index = 2
				L_LobbyMain.ChangeAvatarPart()
				RestAllStorgeItemBoxBtn()
			end,

			EventMouseEnter = function(sender, e)
				if sender.Loading == false then
					L_ToolTips.FillToolTipsWindow(3, 2, sender)
				end
			end,
			EventToolTipsShow = function(sender, e)
				L_ToolTips.ShowToolTipsShowWindow(sender)
			end,
			EventMouseLeave = function(sender, e)
				L_ToolTips.HideToolTipsWindow()
			end,
		},

		--手雷
		Gui.ItemBoxBtn "ib_grenade"
		{
			Style = "Gui.ItemBoxBtn_ib2",
			Size = Vector2(88, 80),
			Location = Vector2(3, 206),
			BtnText =lang:GetText("卸下"),
			BtnSize = Vector2(40,25),
			BtnLocation = Vector2(3, 50),
			PBBaseSkin = Skin.EmpowermentBaseSkin,
			PBTopSkin = Skin.EmpowermentTopSkin,
			PBBaseLocation = Vector2(4, 10),
			PBTopLocation = Vector2(4, 10),
			PBBaseSize = Vector2(16, 48),
			PBTopSize = Vector2(16, 48),

			Skin = Gui.ItemBoxBtnSkin
			{
				NeutralNormalImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche2_normal.dds", Vector4(10, 10, 10, 10)),
				NeutralHoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche2_hover.dds", Vector4(10, 10, 10, 10)),
				NeutralSelectedImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_wuqi_down.dds", Vector4(10, 10, 10, 10)),
				NeutralDisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_caowei_teshuwuqi.dds", Vector4(10, 10, 10, 10)),
				NeutralHighlightImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche2_hover.dds", Vector4(20, 20, 20, 20)),
			},
			ItemBtnSkin = Skin.ButtonSkin_ItemBoxBtn,
			BtnVisible = true,
			--event function 
			EventSelected = function(sender, e)
				if user_bag_info_ui and sender.Loading == false then
					for i = 1, 7 do
						local ibbtn = ptr_cast(user_bag_info_ui.ctrl_ib_container:GetChildByIndex(i-1))

						if i == 3 then
							ibbtn.Selected = true
						else
							ibbtn.Selected = false
						end
					end
				end
				L_LobbyMain.ClassWeaponIndex_Characters[L_LobbyMain.current_choose_class] = 4
				L_LobbyMain.ClassBagIndex_Characters[L_LobbyMain.current_choose_class] = 4
				current_selected_item_class = 0
				current_selected_ibtn_index = 4
				L_LobbyMain.ChangeAvatarPart()
				RestAllStorgeItemBoxBtn()
			end,
	
			EventMouseEnter = function(sender, e)
				if sender.Loading == false then
					L_ToolTips.FillToolTipsWindow(3, 4, sender)
				end
			end,
			EventToolTipsShow = function(sender, e)
				L_ToolTips.ShowToolTipsShowWindow(sender)
			end,
			EventMouseLeave = function(sender, e)
				L_ToolTips.HideToolTipsWindow()
			end,
			EventBtnClick = function()
				current_selected_ibtn_index = 0
				current_selected_item_class = 4
				L_LobbyMain.RpcRemoveEquip(1,4)
			end,
		},

		--近身武器
		Gui.ItemBoxBtn "ib_melee_weapons"
		{
			Style = "Gui.ItemBoxBtn_ib2",
			Size = Vector2(88, 80),
			Location = Vector2(91, 206),
			PBBaseSkin = Skin.EmpowermentBaseSkin,
			PBTopSkin = Skin.EmpowermentTopSkin,
			PBBaseLocation = Vector2(4, 10),
			PBTopLocation = Vector2(4, 10),
			PBBaseSize = Vector2(16, 48),
			PBTopSize = Vector2(16, 48),
			
			Skin = Gui.ItemBoxBtnSkin
			{
				NeutralNormalImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche2_normal.dds", Vector4(10, 10, 10, 10)),
				NeutralHoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche2_hover.dds", Vector4(10, 10, 10, 10)),
				NeutralSelectedImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_wuqi_down.dds", Vector4(10, 10, 10, 10)),
				NeutralDisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_caowei_jinshenwuqi.dds", Vector4(10, 10, 10, 10)),
				NeutralHighlightImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche2_hover.dds", Vector4(20, 20, 20, 20)),
			},
			ItemBtnSkin = Skin.ButtonSkin_ItemBoxBtn,
			BtnVisible = false,
			--event function 
			EventSelected = function(sender, e)
				if user_bag_info_ui and sender.Loading == false then
					for i = 1, 7 do
						local ibbtn = ptr_cast(user_bag_info_ui.ctrl_ib_container:GetChildByIndex(i-1))

						if i == 4 then
							ibbtn.Selected = true
						else
							ibbtn.Selected = false
						end
					end
				end
				L_LobbyMain.ClassWeaponIndex_Characters[L_LobbyMain.current_choose_class] = 3
				L_LobbyMain.ClassBagIndex_Characters[L_LobbyMain.current_choose_class] = 3
				current_selected_item_class = 0
				current_selected_ibtn_index = 3
				L_LobbyMain.ChangeAvatarPart()
				RestAllStorgeItemBoxBtn()
			end,

			EventMouseEnter = function(sender, e)
				if sender.Loading == false then
					L_ToolTips.FillToolTipsWindow(3, 3, sender)
				end
			end,
			EventToolTipsShow = function(sender, e)
				L_ToolTips.ShowToolTipsShowWindow(sender)
			end,
			EventMouseLeave = function(sender, e)
				L_ToolTips.HideToolTipsWindow()
			end,
		},

		--套装
		Gui.ItemBoxBtn "ib_no_use"
		{
			Style = "Gui.ItemBoxBtn_ib1",
			Size = Vector2(88, 160),
			Location = Vector2(3, 286),
			-- BtnText =lang:GetText("卸下"),
			-- BtnSize = Vector2(40,25),
			-- BtnLocation = Vector2(3, 130),
			IconDisplayType = "kIconTextFullFill",
			PBBaseSkin = Skin.EmpowermentBaseSkin,
			PBTopSkin = Skin.EmpowermentTopSkin,
			PBBaseLocation = Vector2(4, 10),
			PBTopLocation = Vector2(4, 10),
			PBBaseSize = Vector2(16, 48),
			PBTopSize = Vector2(16, 48),
			Skin = Gui.ItemBoxBtnSkin
			{
				NeutralNormalImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche3_normal.dds", Vector4(10, 10, 10, 10)),
				NeutralHoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche3_hover.dds", Vector4(10, 10, 10, 10)),
				NeutralSelectedImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_wuqi_down.dds", Vector4(10, 10, 10, 10)),
				NeutralDisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_caowei_juese.dds", Vector4(10, 10, 10, 10)),
				NeutralHighlightImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche3_hover.dds", Vector4(20, 20, 20, 20)),
			},
			ItemBtnSkin = Skin.ButtonSkin_ItemBoxBtn,
			BtnVisible = false,
			--event function 
			EventSelected = function(sender, e)
				if user_bag_info_ui and sender.Loading == false then
					for i = 1, 7 do
						local ibbtn = ptr_cast(user_bag_info_ui.ctrl_ib_container:GetChildByIndex(i-1))

						if i == 5 then
							ibbtn.Selected = true
						else
							ibbtn.Selected = false
						end
					end
				end
				--L_LobbyMain.ClassWeaponIndex_Characters[L_LobbyMain.current_choose_class] = 5
				L_LobbyMain.ClassBagIndex_Characters[L_LobbyMain.current_choose_class] = 5
				--L_LobbyMain.ChangeWeaponInBag()
				current_selected_item_class = 0
				current_selected_ibtn_index = 5
				L_LobbyMain.ChangeAvatarPart()
				RestAllStorgeItemBoxBtn()
			end,

			EventMouseEnter = function(sender, e)
				if sender.Loading == false then
					L_ToolTips.FillToolTipsWindow(3, 5, sender)
				end
			end,
			EventToolTipsShow = function(sender, e)
				L_ToolTips.ShowToolTipsShowWindow(sender)
			end,
			EventMouseLeave = function(sender, e)
				L_ToolTips.HideToolTipsWindow()
			end,
		},

		--帽子
		Gui.ItemBoxBtn "ib_hat"
		{
			Style = "Gui.ItemBoxBtn_ib2",
			Size = Vector2(88, 80),
			Location = Vector2(91, 286),
			BtnText =lang:GetText("卸下"),
			BtnSize = Vector2(40,25),
			BtnLocation = Vector2(3, 50),
			PBBaseSkin = Skin.EmpowermentBaseSkin,
			PBTopSkin = Skin.EmpowermentTopSkin,
			PBBaseLocation = Vector2(4, 10),
			PBTopLocation = Vector2(4, 10),
			PBBaseSize = Vector2(16, 48),
			PBTopSize = Vector2(16, 48),
			Skin = Gui.ItemBoxBtnSkin
			{
				NeutralNormalImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche2_normal.dds", Vector4(10, 10, 10, 10)),
				NeutralHoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche2_hover.dds", Vector4(10, 10, 10, 10)),
				NeutralSelectedImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_wuqi_down.dds", Vector4(10, 10, 10, 10)),
				NeutralDisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_caowei_maozi.dds", Vector4(10, 10, 10, 10)),
				NeutralHighlightImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche2_hover.dds", Vector4(20, 20, 20, 20)),
			},
			ItemBtnSkin = Skin.ButtonSkin_ItemBoxBtn,
			BtnVisible = true,
			--event function 
			EventSelected = function(sender, e)
				if user_bag_info_ui and sender.Loading == false then
					for i = 1, 7 do
						local ibbtn = ptr_cast(user_bag_info_ui.ctrl_ib_container:GetChildByIndex(i-1))

						if i == 6 then
							ibbtn.Selected = true
						else
							ibbtn.Selected = false
						end
					end
				end
				--L_LobbyMain.ClassWeaponIndex_Characters[L_LobbyMain.current_choose_class] = 6
				L_LobbyMain.ClassBagIndex_Characters[L_LobbyMain.current_choose_class] = 6
				current_selected_item_class = 0
				current_selected_ibtn_index = 6
				L_LobbyMain.ChangeAvatarPart()
				RestAllStorgeItemBoxBtn()
			end,

			EventMouseEnter = function(sender, e)
				if sender.Loading == false then
					L_ToolTips.FillToolTipsWindow(3, 6, sender)
				end
			end,
			EventToolTipsShow = function(sender, e)
				L_ToolTips.ShowToolTipsShowWindow(sender)
			end,
			EventMouseLeave = function(sender, e)
				L_ToolTips.HideToolTipsWindow()
			end,

			EventBtnClick = function()
				current_selected_ibtn_index = 0
				current_selected_item_class = 6
				L_LobbyMain.RpcRemoveEquip(3,2)
			end,
		},

		--徽章
		Gui.ItemBoxBtn "ib_last"
		{
			Style = "Gui.ItemBoxBtn_ib2",
			Size = Vector2(88, 80),
			Location = Vector2(91, 366),
			BtnText =lang:GetText("卸下"),
			BtnSize = Vector2(40,25),
			BtnLocation = Vector2(3, 50),
			PBBaseSkin = Skin.EmpowermentBaseSkin,
			PBTopSkin = Skin.EmpowermentTopSkin,
			PBBaseLocation = Vector2(4, 10),
			PBTopLocation = Vector2(4, 10),
			PBBaseSize = Vector2(16, 48),
			PBTopSize = Vector2(16, 48),
			Skin = Gui.ItemBoxBtnSkin
			{
				NeutralNormalImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche2_normal.dds", Vector4(10, 10, 10, 10)),
				NeutralHoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche2_hover.dds", Vector4(10, 10, 10, 10)),
				NeutralSelectedImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_wuqi_down.dds", Vector4(10, 10, 10, 10)),
				NeutralDisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_caowei_huizhang.dds", Vector4(10, 10, 10, 10)),
				NeutralHighlightImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche2_hover.dds", Vector4(20, 20, 20, 20)),
			},
			ItemBtnSkin = Skin.ButtonSkin_ItemBoxBtn,
			BtnVisible = true,
			--event function 
			EventSelected = function(sender, e)
				if user_bag_info_ui and sender.Loading == false then
					for i = 1, 7 do
						local ibbtn = ptr_cast(user_bag_info_ui.ctrl_ib_container:GetChildByIndex(i-1))

						if i == 7 then
							ibbtn.Selected = true
						else
							ibbtn.Selected = false
						end
					end
				end
				--L_LobbyMain.ClassWeaponIndex_Characters[L_LobbyMain.current_choose_class] = 7
				L_LobbyMain.ClassBagIndex_Characters[L_LobbyMain.current_choose_class] = 7
				--L_LobbyMain.ChangeWeaponInBag()
				current_selected_item_class = 0
				current_selected_ibtn_index = 7
				L_LobbyMain.ChangeAvatarPart()
				RestAllStorgeItemBoxBtn()
			end,

			EventMouseEnter = function(sender, e)
				if sender.Loading == false then
					L_ToolTips.FillToolTipsWindow(3, 7, sender)
				end
			end,
			EventToolTipsShow = function(sender, e)
				L_ToolTips.ShowToolTipsShowWindow(sender)
			end,
			EventMouseLeave = function(sender, e)
				L_ToolTips.HideToolTipsWindow()
			end,

			EventBtnClick = function()
				current_selected_ibtn_index = 0
				current_selected_item_class = 7
				L_LobbyMain.RpcRemoveEquip(3,3)
			end,
		},
	},
}

function SpawnNewButton()
	local newbutton = Gui.Create(gui)
	{
		Gui.Button "ib_donate"
		{
			Visible = false,
			Size = Vector2(40,25),
			FontSize = 12,
			Skin = Skin.ButtonSkin_ItemBoxBtn,
			TextColor = ARGB(255, 0, 0, 0),
			EventClick = function(Sender,e)
				local ibbtn = nil
				local index = 0
				for i = 1, 7 do
					ibbtn = ptr_cast(user_bag_info_ui.ctrl_ib_container:GetChildByIndex(i-1))
					if Sender.Parent == ibbtn then
						if i == 3 then
							index = 4
						elseif i == 4 then
							index = 3
						else
							index = i
						end
						break
					end						
				end
					
				if Sender.Text == lang:GetText("维修") then
					L_LobbyMain.ShowAddPowerWindow(0, index)
				elseif Sender.Text == lang:GetText("续费") then
					current_selected_ibtn_index = index
					current_selected_item_class = 0
					setup_Renewals_window(L_LobbyMain.LobbyMainWin.LobbyMain_Root)
				end
			end
		},
	}
	return newbutton
end

local function setup_user_bag(parent_window)
	--界面是否存在
	if user_bag_info_ui then
		user_bag_info_ui.Parent = parent_window
		return
	end
	--创建界面
	user_bag_info_ui = Gui.Create(parent_window)(user_bag_info_page)
	InitAllCharacterBagItemBoxBtnEvent()
	for i = 1, 7 do
		local ibbtn = ptr_cast(user_bag_info_ui.ctrl_ib_container:GetChildByIndex(i-1))
		local newbutton = SpawnNewButton()
		local newstar
		if i < 3 then
			newstar = SpawnNewStarControl()
			newstar.ib_star.Location = Vector2(212 - 142,10)
		else
			newstar = SpawnCharacterStarControl()
		end		

		newbutton.ib_donate.Parent = ibbtn
		newbutton.ib_donate.Location = Vector2(ibbtn.Size.x - 45, ibbtn.Size.y - 30)
		newstar.ib_star.Parent = ibbtn
	end
end

local user_bag_window =
{
	Gui.Control "ctrl_shopping_cart_Main"
	{							
		Size = Vector2(180, 507),
		Location = Vector2(0, 0),
		BackgroundColor = ARGB(0, 255, 255, 255),

		--参战装备
		Gui.Label
		{
			Size = Vector2(160, 30),
			Text = lang:GetText("参战装备"),
			FontSize = 17,
			Location = Vector2(11, 8),
			TextColor = ARGB(255, 159, 155, 155),
			BackgroundColor = ARGB(0, 255, 255, 255),
			TextAlign = "kAlignCenterMiddle",
		},
		
		Gui.Button "btn_repair"
		{
			Size = Vector2(122, 37),
			Location = Vector2(29, 445),
			TextAlign = "kAlignRightMiddle",
			Text = lang:GetText("一键维修"),
			Padding = Vector4(0,0,10,0),
			FontSize = 16,
			TextColor = ARGB(255, 0, 0, 0),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button_maintenance_normal.dds", Vector4(10, 10, 10, 10)),
				HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button_maintenance_hover.dds", Vector4(10, 10, 10, 10)),
				DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button_maintenance_down.dds", Vector4(10, 10, 10, 10)),
				DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button_maintenance_disabled.dds", Vector4(10, 10, 10, 10)),
			},
			EventClick = function()
				local total_cost = 0
				for i = 1, 4 do
					total_cost = total_cost + tonumber(L_LobbyMain.Characters_BagInfo_rpc_data.items.weapons[i].repair_cost)
				end
				for i = 1, 3 do
					total_cost = total_cost + tonumber(L_LobbyMain.Characters_BagInfo_rpc_data.items.costume[i].repair_cost)
				end
				local strShow = lang:GetText("维修需要消耗") .. total_cost .. lang:GetText("C币")
				MessageBox.ShowWithConfirmCancel(strShow,
					function(sender,e)
						local args = {pid = ptr_cast(game.CurrentState):GetCharacterId(), cid = L_LobbyMain.current_choose_class,}
						rpc.safecall("storage_fix_all", args,
						function(data)
							if result ~= 0 then
								MessageBox.ShowWithConfirm(lang:GetText("维修成功"))
								L_LobbyMain.FillClassBag(ptr_cast(game.CurrentState):GetCharacterId(), L_LobbyMain.current_choose_class)
							else
								MessageBox.ShowWithTwoButtons(lang:GetText("你的FC点不足，请充值"),lang:GetText("充值"),lang:GetText("取消"),
								function()
									gui:ShowIE()
								end,
								nil
								)
							end
						end)
					end,
				nil)
			end
		},
	},
}

function ShowUserBag(win_parent)
	--界面是否存在
	if user_bag_ui then
		user_bag_ui.ctrl_shopping_cart_Main.Parent = win_parent
		return
	end
	--创建界面
	user_bag_ui = Gui.Create(win_parent)(user_bag_window)
end

-------------------------------------------------------------------------------------------

local packge_window =
{
	Gui.Control "ctrl_Packge_Main_1"
	{							
		Size = Vector2(459, 458),
		Location = Vector2(631, 115),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg3.dds", Vector4(22, 22, 22, 22)),
		},
	},
	Gui.Control "ctrl_Packge_Main"
	{							
		Size = Vector2(459, 500),
		Location = Vector2(631, 69),
		BackgroundColor = ARGB(0, 255, 255, 255),

		Gui.Control "ctrl_btn_container"
		{							
			Size = Vector2(417, 56),
			Location = Vector2(9, -2),
			BackgroundColor = ARGB(0, 255, 255, 255),

			--武器
			Gui.Button "btn_Weapon"
			{
				Size = Vector2(92, 56),
				Location = Vector2(24, 0),
				PushDown = true,
				Skin = Skin.ButtonSkin_Weapon,
				
				EventClick = function()
					if L_LobbyMain.current_character_storage ~= 1 then
						L_LobbyMain.current_character_storage = 1
						if packge_main_ui then
							packge_main_ui.btn_Weapon.PushDown = true
							packge_main_ui.btn_Dress.PushDown = false
							packge_main_ui.btn_Accessories.PushDown = false
						end

						if ib_dress_ui then
							ib_dress_ui.ctrl_ib_container.Parent = nil
						end

						if ib_accessories_ui then
							ib_accessories_ui.ctrl_ib_container.Parent = nil
						end

						if packge_main_ui then
							setup_ib_weapon(packge_main_ui.ctrl_Packge_Main)
						end
						L_ShoppingMall.fill_cbx_Weapon_Type(packge_main_ui.cbx_Filter_Type, L_ShoppingMall.Fileter_Weapon_Storage_Type)
						--L_LobbyMain.FillClassStorage()
					end
				end
			},

			--服装
			Gui.Button "btn_Dress"
			{
				Size = Vector2(92, 56),
				Location = Vector2(116, 0),
				Skin = Skin.ButtonSkin_Clothes,
				
				EventClick = function()
					if L_LobbyMain.current_character_storage ~= 2 then
						L_LobbyMain.current_character_storage = 2
						if packge_main_ui then
							packge_main_ui.btn_Weapon.PushDown = false
							packge_main_ui.btn_Dress.PushDown = true
							packge_main_ui.btn_Accessories.PushDown = false
						end

						if ib_weapon_ui then
							ib_weapon_ui.ctrl_ib_container.Parent = nil
						end

						if ib_accessories_ui then
							ib_accessories_ui.ctrl_ib_container.Parent = nil
						end

						if packge_main_ui then									
							setup_ib_dress(packge_main_ui.ctrl_Packge_Main)
						end
						L_ShoppingMall.fill_cbx_Weapon_Type(packge_main_ui.cbx_Filter_Type, L_ShoppingMall.Fileter_Dress_Storage_Type)
						--L_LobbyMain.FillClassStorage()
					end
				end
			},

			--配饰
			Gui.Button "btn_Accessories"
			{
				Size = Vector2(92, 56),
				Location = Vector2(208, 0),
				Skin = Skin.ButtonSkin_Hat,
				
				EventClick = function()
					if L_LobbyMain.current_character_storage ~= 3 then
						L_LobbyMain.current_character_storage = 3
						if packge_main_ui then
							packge_main_ui.btn_Weapon.PushDown = false
							packge_main_ui.btn_Dress.PushDown = false
							packge_main_ui.btn_Accessories.PushDown = true
						end

						if ib_weapon_ui then
							ib_weapon_ui.ctrl_ib_container.Parent = nil
						end

						if ib_dress_ui then
							ib_dress_ui.ctrl_ib_container.Parent = nil
						end

						if packge_main_ui then
							setup_ib_accessories(packge_main_ui.ctrl_Packge_Main)
						end
						L_ShoppingMall.fill_cbx_Weapon_Type(packge_main_ui.cbx_Filter_Type, L_ShoppingMall.Fileter_Accessories_Storage_Type)
						--L_LobbyMain.FillClassStorage()
					end
				end
			},
		},
		
		Gui.ComboBox "cbx_Filter_Type"
		{
			Size = Vector2(126, 28),
			FontSize = 14,
			Readonly = true,
			Location = Vector2(330, 3),
			TextColor = ARGB(255,37,37,37),
			TextAlign = "kAlignCenterMiddle",
			TextPadding = Vector4(6,4,2,6),
			LikeButton = true,
			Skin = Gui.ComboBoxSkin
			{
				ButtonNormalImage= Gui.Image("LobbyUI/ShoppingMall/lb_filter_combobox_button_normal.dds", Vector4(0, 0, 0, 0)),
				ButtonHoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_filter_combobox_button_hover.dds", Vector4(0, 0, 0, 0)),
				ButtonDownImage = Gui.Image("LobbyUI/ShoppingMall/lb_filter_combobox_button_down.dds", Vector4(0, 0, 0, 0)),
				
				TextNormalImage= Gui.Image("LobbyUI/ShoppingMall/lb_filter_combobox_bg_normal.dds", Vector4(6, 6, 0, 6)),
				TextHoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_filter_combobox_bg_hover.dds", Vector4(6, 6, 0, 6)),
				TextDownImage = Gui.Image("LobbyUI/ShoppingMall/lb_filter_combobox_bg_down.dds", Vector4(6, 6, 0, 6)),
			},
			ChildComboListStyle =  "Gui.teamComboList",
			
			EventValueChanged = function(sender, args)
				if L_ShoppingMall.main_window_Creat == true then
					L_ShoppingMall.main_window_Creat = false
					return
				end
				L_LobbyMain.CurrentCharacterPages[L_LobbyMain.current_choose_class][L_LobbyMain.current_character_storage] = 1
				L_LobbyMain.FillClassStorage()
			end,
		},

		Gui.Control "ctrl_bottom_container"
		{							
			Size = Vector2(415, 54),
			Location = Vector2(1, 450),
			BackgroundColor = ARGB(0, 255, 255, 255),

			--上一页
			Gui.Button "btn_front_page"
			{
				Size = Vector2(14, 31),
				Location = Vector2(281, 9),
				--Text = "<",
				TextColor = ARGB(255, 255, 246, 235),
				FontSize = 18,
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button05_normal.dds", Vector4(0, 0, 0, 0)),
					HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button05_hover.dds", Vector4(0, 0, 0, 0)),
					DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button05_down.dds", Vector4(0, 0, 0, 0)),
					DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button05_normal.dds", Vector4(0, 0, 0, 0)),
				},
				EventClick = function()
					if L_LobbyMain.CurrentCharacterPages[L_LobbyMain.current_choose_class][L_LobbyMain.current_character_storage] then
						if L_LobbyMain.CurrentCharacterPages[L_LobbyMain.current_choose_class][L_LobbyMain.current_character_storage] <= 1 then
							return
						end
						if L_LobbyMain.CurrentCharacterPages[L_LobbyMain.current_choose_class][L_LobbyMain.current_character_storage] > 1 then
							L_LobbyMain.CurrentCharacterPages[L_LobbyMain.current_choose_class][L_LobbyMain.current_character_storage] = L_LobbyMain.CurrentCharacterPages[L_LobbyMain.current_choose_class][L_LobbyMain.current_character_storage] - 1
						else
							L_LobbyMain.CurrentCharacterPages[L_LobbyMain.current_choose_class][L_LobbyMain.current_character_storage] = 1
						end
					end
					L_LobbyMain.FillClassStorage()
				end
			},
			
			--页码
			Gui.Label "lb_page_number"
			{
				Location = Vector2(310, 9),
				Size = Vector2(75, 31),
				FontSize = 24,
				TextAlign = "kAlignCenterMiddle",
				TextColor = ARGB(255, 103, 102, 98),
				Text = "1/1",
				BackgroundColor = ARGB(255, 255, 255, 255),

				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button06_bg.dds", Vector4(14, 14, 14, 14)),
				},
			},

			--下一页
			Gui.Button "btn_next_page"
			{
				Size = Vector2(14, 31),
				Location = Vector2(400, 9),
				--Text = ">",
				TextColor = ARGB(255, 255, 246, 235),
				FontSize = 18,
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button06_normal.dds", Vector4(0, 0, 0, 0)),
					HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button06_hover.dds", Vector4(0, 0, 0, 0)),
					DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button06_down.dds", Vector4(0, 0, 0, 0)),
					DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button06_normal.dds", Vector4(0, 0, 0, 0)),
				},
				EventClick = function()
					if L_LobbyMain.CurrentCharacterPages[L_LobbyMain.current_choose_class][L_LobbyMain.current_character_storage] then
						if L_LobbyMain.CurrentCharacterPages[L_LobbyMain.current_choose_class][L_LobbyMain.current_character_storage] >= L_LobbyMain.CharactersIB_rpc_data.pages then
							return
						end
						if L_LobbyMain.CurrentCharacterPages[L_LobbyMain.current_choose_class][L_LobbyMain.current_character_storage] < L_LobbyMain.CharactersIB_rpc_data.pages then
							L_LobbyMain.CurrentCharacterPages[L_LobbyMain.current_choose_class][L_LobbyMain.current_character_storage] = L_LobbyMain.CurrentCharacterPages[L_LobbyMain.current_choose_class][L_LobbyMain.current_character_storage] + 1
						else
							L_LobbyMain.CurrentCharacterPages[L_LobbyMain.current_choose_class][L_LobbyMain.current_character_storage] = L_LobbyMain.CharactersIB_rpc_data.pages
						end
					end
					L_LobbyMain.FillClassStorage()
				end
			},
		},
	},
}

function ShowPackgeInfo(win_parent)
	--界面是否存在
	if packge_main_ui then
		packge_main_ui.ctrl_Packge_Main.Parent = win_parent
		return
	end
	--创建界面
	packge_main_ui = Gui.Create(win_parent)(packge_window)
	L_ShoppingMall.main_window_Creat = true
	L_ShoppingMall.fill_cbx_Weapon_Type(packge_main_ui.cbx_Filter_Type, L_ShoppingMall.Fileter_Weapon_Storage_Type)
end

local avatar_window =
{
	Gui.Control "ctrl_Avatar_Main"
	{
		Size = Vector2(472, 501),
		Location = Vector2(155, 75),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg3.dds", Vector4(22, 22, 22, 22)),
		},		
		
		--人物显示
		Gui.CharacterViewer "character_viewer"
		{
			Size = Vector2(290, 494),
			Location = Vector2(5, 1),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg3_guang.tga", Vector4(0, 0, 0, 0)),
			},
		},
		
		Gui.Control "ctrl_shopping_cart"
		{							
			Size = Vector2(181, 492),
			Location = Vector2(285, 2),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg4_guang.dds", Vector4(8, 28, 8, 8)),
			},
		},

		--旋转角色
		Gui.Button "btn_rotate_avatar"
		{
			Size = Vector2(68, 24),
			Location = Vector2(8, 470),
			Padding = Vector4(0, 0, 0, 4),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button10_normal.dds", Vector4(0, 0, 0, 0)),
				HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button10_hover.dds", Vector4(0, 0, 0, 0)),
				DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button10_down.dds", Vector4(0, 0, 0, 0)),
				DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button10_normal.dds", Vector4(0, 0, 0, 0)),
			},
			EventClick = function()
				lg:RotateCharacter()
			end
		},

		--切换阵营
		Gui.Button "btn_change_team"
		{
			Size = Vector2(88, 24),
			Location = Vector2(80, 470),
			Padding = Vector4(0, 0, 0, 4),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button11_normal.dds", Vector4(0, 0, 0, 0)),
				HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button11_hover.dds", Vector4(0, 0, 0, 0)),
				DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button11_down.dds", Vector4(0, 0, 0, 0)),
				DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button11_normal.dds", Vector4(0, 0, 0, 0)),
			},
			EventClick = function()
				L_LobbyMain.current_Avatar_Team = (L_LobbyMain.current_Avatar_Team + 1) % 2
				L_LobbyMain.ChangeAvatarPart()
			end
		},
		Gui.Control "fight_num_BG"
		{							
			Size = Vector2(280, 52),
			Location = Vector2(5, 1),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_power_bg_01.dds", Vector4(0, 0, 0, 0)),
			},
			Gui.FlowLayout "fightnum"
			{
				Location = Vector2(110,13),
				Size = Vector2(111,24),
				--Direction = "kHorizontal",
				Align = "kAlignCenterMiddle",
				ControlAlign = "kAlignCenterMiddle",
				ControlSpace = 0,
			},
			Gui.Button "des_button"
			{
				Size = Vector2(52, 32),
				Location = Vector2(221, 8),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_power_button_1_1_normal.dds", Vector4(0, 0, 0, 0)),
					HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_power_button_1_1_hover.dds", Vector4(0, 0, 0, 0)),
					DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_power_button_1_1_down.dds", Vector4(0, 0, 0, 0)),
					DisabledImage = nil,
				},
				EventClick = function(sender, e)
					if not L_LobbyMain.ui_des_bag.root.Parent then
						L_LobbyMain.ui_des_bag.root.Location = Vector2(400, 344)
						L_LobbyMain.ui_des_bag.root.Parent = L_LobbyMain.LobbyMainWin.LobbyMain_Root_Parent
					end
					sender.Visible = false
					avatart_main_ui.des_button_close.Visible = true
				end,
			},
			Gui.Button "des_button_close"
			{
				Size = Vector2(52, 32),
				Location = Vector2(221, 8),
				EventClick = function(sender, e)
					if L_LobbyMain.ui_des_bag.root.Parent then
						L_LobbyMain.ui_des_bag.root.Parent = nil
					end
					sender.Visible = false
					avatart_main_ui.des_button.Visible = true
				end,
			},
		},
	},
}

function ShowClassInfo(win_parent)
	--界面是否存在
	if avatart_main_ui then
		avatart_main_ui.ctrl_Avatar_Main.Parent = win_parent
		return
	end
	--创建界面
	avatart_main_ui = Gui.Create(win_parent)(avatar_window)
end

local main_props_window = 
{
	Gui.Control "ctrl_props_main"
	{
		Size = Vector2(1116, 586),
		Location = Vector2(19, 25),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/lb_shop_bg2.dds", Vector4(14, 14, 14, 14)),
		},

		Gui.Control "boddy_info_BG"
		{
			--Visible = false,
			Size = Vector2(1101, 551),
			Location = Vector2(9, 35),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_daoju_bg.tga", Vector4(22, 22, 22, 22)),
			},

			Gui.Control "ctrl_info_win"
			{
				Size = Vector2(861, 460),
				Location = Vector2(229, 77),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg3.dds", Vector4(20, 20, 20, 20)),
				},
			},
			Gui.Control "ctrl_info_win"
			{
				Size = Vector2(208, 496),
				Location = Vector2(16, 41),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg3.dds", Vector4(20, 20, 20, 20)),
				},
				Gui.Control "ctrl_prop_info_icon"
				{
					Size = Vector2(98, 94),
					Location = Vector2(56, 54),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_daoju_bg_l.dds", Vector4(0, 0, 0, 0)),
					},
					
					Gui.Control "ctrl_prop_info_icon"
					{
						Size = Vector2(98, 94),
						Location = Vector2(0, 0),
						BackgroundColor = ARGB(0, 255, 255, 255),
					},
				},
				
				Gui.TextArea "lbl_prop_info_title"
				{
					Text = "",
					FontSize = 18,
					Size = Vector2(200, 80),
					Location = Vector2(5, 170),
					DisabledTextColor = ARGB(255, 255, 189, 24),
					Fold = true,
					Enable = false,
				},
				
				Gui.TextArea "txtA_prop_info_body"
				{
					Size = Vector2(205, 405),
					Location = Vector2(5, 245),
					Readonly = false,
					FontSize = 18,
					Fold = true,
					Readonly = true,
					HScrollBarDisplay = "kHide",
					VScrollBarDisplay = "kHide",
					BackgroundColor = ARGB(0, 255, 255, 255),
					DisabledTextColor = ARGB(255, 191, 189, 184),
					Enable = false,
				},
			},

			Gui.Control "ctrl_prop_win"
			{
				Size = Vector2(835, 500),
				Location = Vector2(249, 31),
				BackgroundColor = ARGB(0, 255, 255, 255),
				
				Gui.Button "btn_gongneng"
				{
					Size = Vector2(92, 56),
					Location = Vector2(0 , 0),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_classification_03_normal.dds", Vector4(5, 5, 5, 5)),
						HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_classification_03_hover.dds", Vector4(5, 5, 5, 5)),
						DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_classification_03_down.dds", Vector4(5, 5, 5, 5)),
						DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_classification_03_normal.dds", Vector4(5, 5, 5, 5)),
					},
					PushDown = true,
					EventClick = function(sender, e)
						if sender.PushDown == false then
							L_LobbyMain.current_character_storage = 4
							current_selected_type_index = 1
							main_props_window_ui.btn_libao.PushDown = false
							main_props_window_ui.btn_gongneng.PushDown = true
							main_props_window_ui.btn_hecheng.PushDown = false
							main_props_window_ui.btn_xiaohao.PushDown = false
							main_props_window_ui.btn_jiacheng.PushDown = false
							main_props_window_ui.btn_lantu.PushDown = false
							main_props_window_ui.btn_mingpian.PushDown = false
							if L_LobbyMain.LobbyMainWin.new_daoju_sc.Visible == true then
								L_LobbyMain.LobbyMainWin.new_daoju_sc:Show()
								L_LobbyMain.LobbyMainWin.new_daoju_sc.UseTimer = true
								L_LobbyMain.LobbyMainWin.new_daoju_sc.DisplayTime = 0.5
								L_PushCmd.New_daoju_sc = 0
							end	
							FillPropInfo(-1)
							L_LobbyMain.CurrentCharacterPages[L_LobbyMain.current_choose_class][L_LobbyMain.current_character_storage] = 1
							L_LobbyMain.FillClassStorage(current_selected_type[current_selected_type_index][2])
						end
					end
				},
				
				Gui.Button "btn_hecheng"
				{
					Size = Vector2(92, 56),
					Location = Vector2(92 , 0),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_classification_02_normal.dds", Vector4(5, 5, 5, 5)),
						HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_classification_02_hover.dds", Vector4(5, 5, 5, 5)),
						DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_classification_02_down.dds", Vector4(5, 5, 5, 5)),
						DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_classification_02_normal.dds", Vector4(5, 5, 5, 5)),
					},
					PushDown = false,
					EventClick = function()
						if main_props_window_ui and main_props_window_ui.btn_hecheng.PushDown == false then
							L_LobbyMain.current_character_storage = 5
							current_selected_type_index = 2
							main_props_window_ui.btn_libao.PushDown = false
							main_props_window_ui.btn_gongneng.PushDown = false
							main_props_window_ui.btn_hecheng.PushDown = true
							main_props_window_ui.btn_xiaohao.PushDown = false
							main_props_window_ui.btn_jiacheng.PushDown = false
							main_props_window_ui.btn_lantu.PushDown = false
							main_props_window_ui.btn_mingpian.PushDown = false
							if L_LobbyMain.LobbyMainWin.new_daoju_kjx.Visible == true then
								L_LobbyMain.LobbyMainWin.new_daoju_kjx:Show()
								L_LobbyMain.LobbyMainWin.new_daoju_kjx.UseTimer = true
								L_LobbyMain.LobbyMainWin.new_daoju_kjx.DisplayTime = 0.5
								L_PushCmd.New_daoju_kjx = 0
							end
							FillPropInfo(-1)
							L_LobbyMain.CurrentCharacterPages[L_LobbyMain.current_choose_class][L_LobbyMain.current_character_storage] = 1
							L_LobbyMain.FillClassStorage(current_selected_type[current_selected_type_index][2])
						end
					end
				},
				
				Gui.Button "btn_xiaohao"
				{
					Size = Vector2(92, 56),
					Location = Vector2(184 , 0),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_classification_04_normal.dds", Vector4(5, 5, 5, 5)),
						HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_classification_04_hover.dds", Vector4(5, 5, 5, 5)),
						DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_classification_04_down.dds", Vector4(5, 5, 5, 5)),
						DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_classification_04_normal.dds", Vector4(5, 5, 5, 5)),
					},
					PushDown = false,
					EventClick = function()
						if main_props_window_ui and main_props_window_ui.btn_xiaohao.PushDown == false then
							L_LobbyMain.current_character_storage = 4
							current_selected_type_index = 3
							main_props_window_ui.btn_gongneng.PushDown = false
							main_props_window_ui.btn_hecheng.PushDown = false
							main_props_window_ui.btn_xiaohao.PushDown = true
							main_props_window_ui.btn_jiacheng.PushDown = false
							main_props_window_ui.btn_lantu.PushDown = false
							main_props_window_ui.btn_mingpian.PushDown = false
							main_props_window_ui.btn_libao.PushDown = false
							if L_LobbyMain.LobbyMainWin.new_daoju_dj.Visible == true then
								L_LobbyMain.LobbyMainWin.new_daoju_dj:Show()
								L_LobbyMain.LobbyMainWin.new_daoju_dj.UseTimer = true
								L_LobbyMain.LobbyMainWin.new_daoju_dj.DisplayTime = 0.5
								L_PushCmd.New_daoju_dj = 0
							end
							FillPropInfo(-1)
							L_LobbyMain.CurrentCharacterPages[L_LobbyMain.current_choose_class][L_LobbyMain.current_character_storage] = 1
							L_LobbyMain.FillClassStorage(current_selected_type[current_selected_type_index][2])
						end
					end
				},
				
				Gui.Button "btn_jiacheng"
				{
					Size = Vector2(92, 56),
					Location = Vector2(276 , 0),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_classification_05_normal.dds", Vector4(5, 5, 5, 5)),
						HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_classification_05_hover.dds", Vector4(5, 5, 5, 5)),
						DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_classification_05_down.dds", Vector4(5, 5, 5, 5)),
						DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_classification_05_normal.dds", Vector4(5, 5, 5, 5)),
					},
					PushDown = false,
					EventClick = function()
						if main_props_window_ui and main_props_window_ui.btn_jiacheng.PushDown == false then
							L_LobbyMain.current_character_storage = 4
							current_selected_type_index = 4
							main_props_window_ui.btn_libao.PushDown = false
							main_props_window_ui.btn_gongneng.PushDown = false
							main_props_window_ui.btn_hecheng.PushDown = false
							main_props_window_ui.btn_xiaohao.PushDown = false
							main_props_window_ui.btn_jiacheng.PushDown = true
							main_props_window_ui.btn_lantu.PushDown = false
							main_props_window_ui.btn_mingpian.PushDown = false
							if L_LobbyMain.LobbyMainWin.new_daoju_jiacheng.Visible == true then
								L_LobbyMain.LobbyMainWin.new_daoju_jiacheng:Show()
								L_LobbyMain.LobbyMainWin.new_daoju_jiacheng.UseTimer = true
								L_LobbyMain.LobbyMainWin.new_daoju_jiacheng.DisplayTime = 0.5
								L_PushCmd.New_daoju_jiacheng = 0
							end
							FillPropInfo(-1)
							L_LobbyMain.CurrentCharacterPages[L_LobbyMain.current_choose_class][L_LobbyMain.current_character_storage] = 1
							L_LobbyMain.FillClassStorage(current_selected_type[current_selected_type_index][2])
						end
					end
				},
				
				Gui.Button "btn_lantu"
				{
					Size = Vector2(92, 56),
					Location = Vector2(368 , 0),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_classification_06_normal.dds", Vector4(5, 5, 5, 5)),
						HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_classification_06_hover.dds", Vector4(5, 5, 5, 5)),
						DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_classification_06_down.dds", Vector4(5, 5, 5, 5)),
						DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_classification_06_normal.dds", Vector4(5, 5, 5, 5)),
					},
					PushDown = false,
					EventClick = function()
						if main_props_window_ui and main_props_window_ui.btn_lantu.PushDown == false then
							L_LobbyMain.current_character_storage = 5
							current_selected_type_index = 5
							main_props_window_ui.btn_libao.PushDown = false
							main_props_window_ui.btn_gongneng.PushDown = false
							main_props_window_ui.btn_hecheng.PushDown = false
							main_props_window_ui.btn_xiaohao.PushDown = false
							main_props_window_ui.btn_jiacheng.PushDown = false
							main_props_window_ui.btn_lantu.PushDown = true
							main_props_window_ui.btn_mingpian.PushDown = false
							if L_LobbyMain.LobbyMainWin.new_daoju_lantu.Visible == true then
								L_LobbyMain.LobbyMainWin.new_daoju_lantu:Show()
								L_LobbyMain.LobbyMainWin.new_daoju_lantu.UseTimer = true
								L_LobbyMain.LobbyMainWin.new_daoju_lantu.DisplayTime = 0.5
								L_PushCmd.New_daoju_lantu = 0
							end
							FillPropInfo(-1)
							L_LobbyMain.CurrentCharacterPages[L_LobbyMain.current_choose_class][L_LobbyMain.current_character_storage] = 1
							L_LobbyMain.FillClassStorage(current_selected_type[current_selected_type_index][2])
						end
					end
				},
				
				Gui.Button "btn_mingpian"
				{
					Size = Vector2(92, 56),
					Location = Vector2(460 , 0),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_classification_07_normal.dds", Vector4(5, 5, 5, 5)),
						HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_classification_07_hover.dds", Vector4(5, 5, 5, 5)),
						DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_classification_07_down.dds", Vector4(5, 5, 5, 5)),
						DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_classification_07_normal.dds", Vector4(5, 5, 5, 5)),
					},
					PushDown = false,
					EventClick = function()
						if main_props_window_ui and main_props_window_ui.btn_mingpian.PushDown == false then
							L_LobbyMain.current_character_storage = 4
							current_selected_type_index = 6
							main_props_window_ui.btn_libao.PushDown = false
							main_props_window_ui.btn_gongneng.PushDown = false
							main_props_window_ui.btn_hecheng.PushDown = false
							main_props_window_ui.btn_xiaohao.PushDown = false
							main_props_window_ui.btn_jiacheng.PushDown = false
							main_props_window_ui.btn_lantu.PushDown = false
							main_props_window_ui.btn_mingpian.PushDown = true
							if L_LobbyMain.LobbyMainWin.new_daoju_mingpian.Visible == true then
								L_LobbyMain.LobbyMainWin.new_daoju_mingpian:Show()
								L_LobbyMain.LobbyMainWin.new_daoju_mingpian.UseTimer = true
								L_LobbyMain.LobbyMainWin.new_daoju_mingpian.DisplayTime = 0.5
								L_PushCmd.New_daoju_mingpian = 0
							end
							FillPropInfo(-1)
							L_LobbyMain.CurrentCharacterPages[L_LobbyMain.current_choose_class][L_LobbyMain.current_character_storage] = 1
							L_LobbyMain.FillClassStorage(current_selected_type[current_selected_type_index][2])
						end
					end
				},
				
				Gui.Button "btn_libao"
				{
					Size = Vector2(92, 56),
					Location = Vector2(552 , 0),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_classification_08_normal.dds", Vector4(5, 5, 5, 5)),
						HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_classification_08_hover.dds", Vector4(5, 5, 5, 5)),
						DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_classification_08_down.dds", Vector4(5, 5, 5, 5)),
						DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_classification_08_normal.dds", Vector4(5, 5, 5, 5)),
					},
					PushDown = false,
					EventClick = function()
						if main_props_window_ui and main_props_window_ui.btn_libao.PushDown == false then
							L_LobbyMain.current_character_storage = 8
							current_selected_type_index = 7
							main_props_window_ui.btn_libao.PushDown = true
							main_props_window_ui.btn_gongneng.PushDown = false
							main_props_window_ui.btn_hecheng.PushDown = false
							main_props_window_ui.btn_xiaohao.PushDown = false
							main_props_window_ui.btn_jiacheng.PushDown = false
							main_props_window_ui.btn_lantu.PushDown = false
							main_props_window_ui.btn_mingpian.PushDown = false
							if L_LobbyMain.LobbyMainWin.new_daoju_libao.Visible == true then
								L_LobbyMain.LobbyMainWin.new_daoju_libao:Show()
								L_LobbyMain.LobbyMainWin.new_daoju_libao.UseTimer = true
								L_LobbyMain.LobbyMainWin.new_daoju_libao.DisplayTime = 0.5
								L_PushCmd.New_daoju_libao = 0
							end
							FillPropInfo(-1)
							L_LobbyMain.CurrentCharacterPages[L_LobbyMain.current_choose_class][L_LobbyMain.current_character_storage] = 1
							L_LobbyMain.FillClassStorage(current_selected_type[current_selected_type_index][2])
						end
					end
				},
				
				
				Gui.ComboBox "cbx_Filter_Type"
				{
					Size = Vector2(126, 28),
					FontSize = 14,
					Readonly = true,
					Location = Vector2(703, 5),
					TextColor = ARGB(255,37,37,37),
					TextAlign = "kAlignCenterMiddle",
					TextPadding = Vector4(6,4,2,6),
					LikeButton = true,
					Visible = false,
					Skin = Gui.ComboBoxSkin
					{
						ButtonNormalImage= Gui.Image("LobbyUI/ShoppingMall/lb_filter_combobox_button_normal.dds", Vector4(0, 0, 0, 0)),
						ButtonHoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_filter_combobox_button_hover.dds", Vector4(0, 0, 0, 0)),
						ButtonDownImage = Gui.Image("LobbyUI/ShoppingMall/lb_filter_combobox_button_down.dds", Vector4(0, 0, 0, 0)),
						
						TextNormalImage= Gui.Image("LobbyUI/ShoppingMall/lb_filter_combobox_bg_normal.dds", Vector4(6, 6, 0, 6)),
						TextHoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_filter_combobox_bg_hover.dds", Vector4(6, 6, 0, 6)),
						TextDownImage = Gui.Image("LobbyUI/ShoppingMall/lb_filter_combobox_bg_down.dds", Vector4(6, 6, 0, 6)),
					},
					ChildComboListStyle =  "Gui.teamComboList",
					
					EventValueChanged = function(sender, args)
						-- if L_ShoppingMall.main_window_Creat == true then
							-- L_ShoppingMall.main_window_Creat = false
							-- return
						-- end
						-- L_LobbyMain.CurrentCharacterPages[L_LobbyMain.current_choose_class][L_LobbyMain.current_character_storage] = 1
						-- L_LobbyMain.FillClassStorage()
						-- FillPropInfo(-1)
					end,
				},

				Gui.Button "tidy"
				{
					Size = Vector2(108, 32),
					Location = Vector2(0, 462),
					Text = lang:GetText("整理仓库"),
					TextColor = ARGB(255, 37, 37, 37),
					HighlightTextColor = ARGB(255, 37, 37, 37),
					FontSize = 18,
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_button_zhengli_normal.dds", Vector4(0, 0, 0, 0)),
						HoverImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_button_zhengli_hover.dds", Vector4(0, 0, 0, 0)),
						DownImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_button_zhengli_down.dds", Vector4(0, 0, 0, 0)),
						DisabledImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_button_zhengli_disabled.dds", Vector4(0, 0, 0, 0)),
					},
					EventClick = function()
						gui:PlayAudio("kUIA_CLEAN_UP")
						local args = {pid = ptr_cast(game.CurrentState):GetCharacterId(), type = L_LobbyMain.current_character_storage}
						rpc.safecallload("sort_material",args,
						function(data) 
							if data.result == 1 then
								MessageBox.ShowWithTimer(1,lang:GetText("整理成功"))
								if L_LobbyMain.current_character_storage > 3 then
									L_LobbyMain.current_character_storage = current_selected_type[current_selected_type_index][1]
									L_LobbyMain.FillClassStorage(current_selected_type[current_selected_type_index][2])
								else
									L_LobbyMain.FillClassStorage()
								end
							end
						end)
					end
				},
				
				--上一页
				Gui.Button "btn_front_page"
				{
					Size = Vector2(14, 31),
					Location = Vector2(660, 462),
					--Text = "<",
					TextColor = ARGB(255, 255, 246, 235),
					FontSize = 18,
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/lb_shop_button05_normal.dds", Vector4(0, 0, 0, 0)),
						HoverImage = Gui.Image("LobbyUI/lb_shop_button05_hover.dds", Vector4(0, 0, 0, 0)),
						DownImage = Gui.Image("LobbyUI/lb_shop_button05_down.dds", Vector4(0, 0, 0, 0)),
						DisabledImage = Gui.Image("LobbyUI/lb_shop_button05_normal.dds", Vector4(0, 0, 0, 0)),
					},
					EventClick = function()
						if L_LobbyMain.CurrentCharacterPages[L_LobbyMain.current_choose_class][L_LobbyMain.current_character_storage] then
							if L_LobbyMain.CurrentCharacterPages[L_LobbyMain.current_choose_class][L_LobbyMain.current_character_storage] <= 1 then
								return
							end
							if L_LobbyMain.CurrentCharacterPages[L_LobbyMain.current_choose_class][L_LobbyMain.current_character_storage] > 1 then
								L_LobbyMain.CurrentCharacterPages[L_LobbyMain.current_choose_class][L_LobbyMain.current_character_storage] = L_LobbyMain.CurrentCharacterPages[L_LobbyMain.current_choose_class][L_LobbyMain.current_character_storage] - 1
							else
								L_LobbyMain.CurrentCharacterPages[L_LobbyMain.current_choose_class][L_LobbyMain.current_character_storage] = 1
							end
						end
						if L_LobbyMain.current_character_storage > 3 then
							L_LobbyMain.current_character_storage = current_selected_type[current_selected_type_index][1]
							L_LobbyMain.FillClassStorage(current_selected_type[current_selected_type_index][2])
						else
							L_LobbyMain.FillClassStorage()
						end
						FillPropInfo(-1)
					end
				},
			
				--页码
				Gui.Label "lb_page_number"
				{
					Location = Vector2(689, 462),
					Size = Vector2(75, 31),
					FontSize = 24,
					TextAlign = "kAlignCenterMiddle",
					TextColor = ARGB(255, 103, 102, 98),
					Text = "1/1",
					BackgroundColor = ARGB(255, 255, 255, 255),

					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button06_bg.dds", Vector4(14, 14, 14, 14)),
					},
				},

				--下一页
				Gui.Button "btn_next_page"
				{
					Size = Vector2(14, 31),
					Location = Vector2(779, 462),
					--Text = ">",
					TextColor = ARGB(255, 255, 246, 235),
					FontSize = 18,
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/lb_shop_button06_normal.dds", Vector4(0, 0, 0, 0)),
						HoverImage = Gui.Image("LobbyUI/lb_shop_button06_hover.dds", Vector4(0, 0, 0, 0)),
						DownImage = Gui.Image("LobbyUI/lb_shop_button06_down.dds", Vector4(0, 0, 0, 0)),
						DisabledImage = Gui.Image("LobbyUI/lb_shop_button06_normal.dds", Vector4(0, 0, 0, 0)),
					},
					EventClick = function()
						if L_LobbyMain.CurrentCharacterPages[L_LobbyMain.current_choose_class][L_LobbyMain.current_character_storage] then
							if L_LobbyMain.CurrentCharacterPages[L_LobbyMain.current_choose_class][L_LobbyMain.current_character_storage] >= L_LobbyMain.CharactersIB_rpc_data.pages then
								return
							end
							if L_LobbyMain.CurrentCharacterPages[L_LobbyMain.current_choose_class][L_LobbyMain.current_character_storage] < L_LobbyMain.CharactersIB_rpc_data.pages then
								L_LobbyMain.CurrentCharacterPages[L_LobbyMain.current_choose_class][L_LobbyMain.current_character_storage] = L_LobbyMain.CurrentCharacterPages[L_LobbyMain.current_choose_class][L_LobbyMain.current_character_storage] + 1
							else
								L_LobbyMain.CurrentCharacterPages[L_LobbyMain.current_choose_class][L_LobbyMain.current_character_storage] = L_LobbyMain.CharactersIB_rpc_data.pages
							end
						end
						if L_LobbyMain.current_character_storage > 3 then
							L_LobbyMain.current_character_storage = current_selected_type[current_selected_type_index][1]
							L_LobbyMain.FillClassStorage(current_selected_type[current_selected_type_index][2])
						else
							L_LobbyMain.FillClassStorage()
						end
						FillPropInfo(-1)
					end
				},
			},
		},

		Gui.Control "ctrl_Button_BG"
		{
			Size = Vector2(606, 74),
			Location = Vector2(210, 0),
			BackgroundColor = ARGB(255, 255, 255, 255),

			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab01_bg.dds", Vector4(29, 32, 32, 19)),
			},

			--角色
			Gui.Button "btn_Characters"
			{
				Size = Vector2(272, 52),
				Location = Vector2(26 , 9),
				Text = lang:GetText("角色管理"),
				TextColor = ARGB(255, 37, 37, 37),
				HighlightTextColor = ARGB(255, 37, 37, 37),
				FontSize = 28,
				PushDown = true,
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_normal.dds", Vector4(10, 10, 10, 10)),
					HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_hover.dds", Vector4(10, 10, 10, 10)),
					DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_down.dds", Vector4(10, 10, 10, 10)),
					DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_normal.dds", Vector4(10, 10, 10, 10)),
				},
				EventClick = function()
					if current_selected ~= 0 then
						current_selected = 0
						if main_character_window_ui then
							main_character_window_ui.btn_Characters.PushDown = true
							main_character_window_ui.btn_Property.PushDown = false
							L_ToolTips.HideToolTipsWindow()
						end

						L_ShoppingMall.main_window_Creat = false
						if packge_main_ui then
							if packge_main_ui.btn_Weapon.PushDown == true then
								L_LobbyMain.current_character_storage = 1
							elseif packge_main_ui.btn_Dress.PushDown == true then
								L_LobbyMain.current_character_storage = 2
							elseif packge_main_ui.btn_Accessories.PushDown == true then
								L_LobbyMain.current_character_storage = 3
							end
						end
						
						ShowWhichWin(root_ui, current_selected)
						
						if main_props_window_ui then
							main_props_window_ui.btn_Characters.PushDown = true
							main_props_window_ui.btn_Property.PushDown = false
							main_props_window_ui.ctrl_props_main.Parent = nil
						end
						if L_LobbyMain.current_character_storage == 1 then
							setup_ib_weapon(packge_main_ui.ctrl_Packge_Main)
						elseif L_LobbyMain.current_character_storage == 2 then
							setup_ib_dress(packge_main_ui.ctrl_Packge_Main)
						elseif L_LobbyMain.current_character_storage == 3 then
							setup_ib_accessories(packge_main_ui.ctrl_Packge_Main)
						end
						L_LobbyMain.FillClassBag(ptr_cast(game.CurrentState):GetCharacterId(), L_LobbyMain.current_choose_class)
						L_LobbyMain.FillClassStorage()
						if L_LobbyMain.LobbyMainWin.new_jiaose.Visible == true then
							L_LobbyMain.LobbyMainWin.new_jiaose:Show()
							L_LobbyMain.LobbyMainWin.new_jiaose.UseTimer = true
							L_LobbyMain.LobbyMainWin.new_jiaose.DisplayTime = 0.5
							L_PushCmd.New_jiaose = 0
						end	
						L_LobbyMain.LobbyMainWin.new_daoju_dj.Visible = false
						L_LobbyMain.LobbyMainWin.new_daoju_sc.Visible = false
						L_LobbyMain.LobbyMainWin.new_daoju_kjx.Visible = false
						L_LobbyMain.LobbyMainWin.new_daoju_jiacheng.Visible = false
						L_LobbyMain.LobbyMainWin.new_daoju_lantu.Visible = false
						L_LobbyMain.LobbyMainWin.new_daoju_mingpian.Visible = false
						L_LobbyMain.LobbyMainWin.new_daoju_libao.Visible = false
					end
					gui:PlayAudio("kUIA_CLOSE_UI2")
				end
			},

			--道具
			Gui.Button "btn_Property"
			{
				Size = Vector2(272, 52),
				Location = Vector2(305, 9),
				Text = lang:GetText("道具管理"),
				TextColor = ARGB(255, 37, 37, 37),
				HighlightTextColor = ARGB(255, 37, 37, 37),
				FontSize = 28,
				PushDown = false,
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_normal.dds", Vector4(10, 10, 10, 10)),
					HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_hover.dds", Vector4(10, 10, 10, 10)),
					DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_down.dds", Vector4(10, 10, 10, 10)),
					DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_normal.dds", Vector4(10, 10, 10, 10)),
				},
				EventClick = function()
					gui:PlayAudio("kUIA_CLOSE_UI2")
--[[					if current_selected ~= 1 then
						current_selected = 1
						if main_character_window_ui then
							main_character_window_ui.btn_Characters.PushDown = false
							main_character_window_ui.btn_Property.PushDown = true
							main_character_window_ui.ctrl_character_main.Parent = nil
							L_ToolTips.HideToolTipsWindow()
						end
						
						ShowWhichWin(root_ui, current_selected)
						
						if main_props_window_ui then
							main_props_window_ui.btn_Characters.PushDown = false
							main_props_window_ui.btn_Property.PushDown = true
						end
						if L_LobbyMain.current_character_storage > 3 then
							setup_ib_prop(main_props_window_ui.ctrl_prop_win)
						end
						print(L_LobbyMain.current_character_storage)
						L_LobbyMain.FillClassStorage()
						FillPropInfo(-1)
					end]]
				end
			},
		},
		--Close Button
		Gui.Button "btn_Close"
		{
			Size = Vector2(64, 52),
			Location = Vector2(1049, 3),
			PushDown = false,
			Hint = lang:GetText("关闭仓库并返回至战区"),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button01_normal.dds", Vector4(0, 0, 0, 0)),
				HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button01_hover.dds", Vector4(0, 0, 0, 0)),
				DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button01_down.dds", Vector4(0, 0, 0, 0)),
				DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button01_normal.dds", Vector4(0, 0, 0, 0)),
			},
			EventClick = function()
				L_WarZone.Show(L_LobbyMain.LobbyMainWin_Boddy.LobbyMainWin_Boddy_Root)
			end
		},
	},
}

--重置职业列表
function RestAllCharactersClassBtn()
	for i = 1, 10 do
		main_character_window_ui["tab_btn_"..i].PushDown = false
	end
end

--同步职业列表
function SynchronousClassButton()
	if main_character_window_ui then
		RestAllCharactersClassBtn()
		main_character_window_ui["tab_btn_"..L_LobbyMain.current_choose_class].PushDown = true
	end
end

--职业列表事件
local function characters_tab_event()
	if main_character_window_ui == nil then
		return
	end
	
	for i = 1, 10 do
		main_character_window_ui["tab_btn_"..i].EventClick = function()
			if L_LobbyMain.character_classes[i].is_open == 1 then
				L_LobbyMain.current_choose_class = i
				L_LobbyMain.CurrentCharacterPages[L_LobbyMain.current_choose_class][L_LobbyMain.current_character_storage] = 1
				RestAllCharactersClassBtn()
				main_character_window_ui["tab_btn_"..i].PushDown = true
				ShowClassInfo(main_character_window_ui.ctrl_character_main)
				ShowPackgeInfo(main_character_window_ui.ctrl_character_main)
				L_LobbyMain.FillClassBag(ptr_cast(game.CurrentState):GetCharacterId(), i)
				L_LobbyMain.FillClassStorage()
				RestAllCharacterBagItemBoxBtn()
			end
		end
	end
end

local main_character_window =
{
	Gui.Control "ctrl_character_main"
	{
		Size = Vector2(1116, 586),
		Location = Vector2(19, 25),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/lb_shop_bg2.dds", Vector4(14, 14, 14, 14)),
		},	
		
		Gui.Control "boddy_info_BG"
		{
			Size = Vector2(1101, 551),
			Location = Vector2(9, 34),
			BackgroundColor = ARGB(255, 255, 255, 255),
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg.tga", Vector4(150, 22, 22, 22)),
			},
		},
		
		--职业列表
		L_Characters_tab.create_tab_characters_windows(Vector2(1,38)),

		Gui.Control "ctrl_Button_BG"
		{
			Size = Vector2(606, 74),
			Location = Vector2(210, 0),
			BackgroundColor = ARGB(255, 255, 255, 255),

			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab01_bg.dds", Vector4(29, 32, 32, 19)),
			},

			--角色
			Gui.Button "btn_Characters"
			{
				Size = Vector2(272, 52),
				Location = Vector2(26 , 9),
				Text = lang:GetText("角色管理"),
				TextColor = ARGB(255, 37, 37, 37),
				HighlightTextColor = ARGB(255, 37, 37, 37),
				FontSize = 28,
				PushDown = true,
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_normal.dds", Vector4(10, 10, 10, 10)),
					HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_hover.dds", Vector4(10, 10, 10, 10)),
					DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_down.dds", Vector4(10, 10, 10, 10)),
					DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_normal.dds", Vector4(10, 10, 10, 10)),
				},
				EventClick = function()
					gui:PlayAudio("kUIA_CLOSE_UI2")
					--[[
					if current_selected ~= 0 then
						current_selected = 0
						if main_character_window_ui then
							main_character_window_ui.btn_Characters.PushDown = true
							main_character_window_ui.btn_Property.PushDown = false
							L_ToolTips.HideToolTipsWindow()
						end
						
						ShowWhichWin(root_ui, current_selected)
						
						if main_props_window_ui then
							main_props_window_ui.btn_Characters.PushDown = true
							main_props_window_ui.btn_Property.PushDown = false
							main_props_window_ui.ctrl_props_main.Parent = nil
						end
						if L_LobbyMain.current_character_storage == 1 then
							setup_ib_weapon(packge_main_ui.ctrl_Packge_Main)
						elseif L_LobbyMain.current_character_storage == 2 then
							setup_ib_dress(packge_main_ui.ctrl_Packge_Main)
						elseif L_LobbyMain.current_character_storage == 3 then
							setup_ib_accessories(packge_main_ui.ctrl_Packge_Main)
						end
						print(L_LobbyMain.current_character_storage)
					end
					]]
				end
			},

			--道具
			Gui.Button "btn_Property"
			{
				Size = Vector2(272, 52),
				Location = Vector2(305, 9),
				Text = lang:GetText("道具管理"),
				TextColor = ARGB(255, 37, 37, 37),
				HighlightTextColor = ARGB(255, 37, 37, 37),
				FontSize = 28,
				PushDown = false,
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_normal.dds", Vector4(10, 10, 10, 10)),
					HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_hover.dds", Vector4(10, 10, 10, 10)),
					DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_down.dds", Vector4(10, 10, 10, 10)),
					DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_normal.dds", Vector4(10, 10, 10, 10)),
				},
				EventClick = function()
					if current_selected ~= 1 then
						current_selected = 1
						if main_character_window_ui then
							main_character_window_ui.btn_Characters.PushDown = false
							main_character_window_ui.btn_Property.PushDown = true
							main_character_window_ui.ctrl_character_main.Parent = nil
							L_ToolTips.HideToolTipsWindow()
						end
						
						if L_LobbyMain.ui_des_bag.root.Parent then
							L_LobbyMain.ui_des_bag.root.Parent = nil
						end
						
						ShowWhichWin(root_ui, current_selected)
						
						if main_props_window_ui then
							main_props_window_ui.btn_Characters.PushDown = false
							main_props_window_ui.btn_Property.PushDown = true
							
							L_LobbyMain.current_character_storage = current_selected_type[current_selected_type_index][1]
							L_LobbyMain.FillClassStorage(current_selected_type[current_selected_type_index][2])
						end
						if L_LobbyMain.current_character_storage > 3 then
							setup_ib_prop(main_props_window_ui.ctrl_prop_win)
						end
						-- L_LobbyMain.FillClassStorage()
						FillPropInfo(-1)
						if L_LobbyMain.LobbyMainWin.new_daoju.Visible == true then
							L_LobbyMain.LobbyMainWin.new_daoju:Show()
							L_LobbyMain.LobbyMainWin.new_daoju.UseTimer = true
							L_LobbyMain.LobbyMainWin.new_daoju.DisplayTime = 0.5
							L_PushCmd.New_daoju = 0
						end	

						if L_PushCmd.New_daoju_sc == 1 then
							L_LobbyMain.LobbyMainWin.new_daoju_sc.Location = Vector2(570, 290)
							L_LobbyMain.LobbyMainWin.new_daoju_sc.NormLocation = Vector2(570, 290)
							L_LobbyMain.LobbyMainWin.new_daoju_sc.UseTimer = false
							L_LobbyMain.LobbyMainWin.new_daoju_sc.Visible = true
							if main_props_window_ui and main_props_window_ui.btn_gongneng.PushDown == true then
								if L_LobbyMain.LobbyMainWin.new_daoju_sc.Visible == true then
									L_LobbyMain.LobbyMainWin.new_daoju_sc:Show()
									L_LobbyMain.LobbyMainWin.new_daoju_sc.UseTimer = true
									L_LobbyMain.LobbyMainWin.new_daoju_sc.DisplayTime = 0.5
									L_PushCmd.New_daoju_sc = 0
								end	
							end	
						end
						if L_PushCmd.New_daoju_kjx == 1 then
							L_LobbyMain.LobbyMainWin.new_daoju_kjx.Location = Vector2(660, 290)
							L_LobbyMain.LobbyMainWin.new_daoju_kjx.NormLocation = Vector2(660, 290)
							L_LobbyMain.LobbyMainWin.new_daoju_kjx.UseTimer = false
							L_LobbyMain.LobbyMainWin.new_daoju_kjx.Visible = true
							if main_props_window_ui and main_props_window_ui.btn_hecheng.PushDown == true then
								if L_LobbyMain.LobbyMainWin.new_daoju_kjx.Visible == true then
									L_LobbyMain.LobbyMainWin.new_daoju_kjx:Show()
									L_LobbyMain.LobbyMainWin.new_daoju_kjx.UseTimer = true
									L_LobbyMain.LobbyMainWin.new_daoju_kjx.DisplayTime = 0.5
									L_PushCmd.New_daoju_kjx = 0
								end	
							end	
						end
						if L_PushCmd.New_daoju_dj == 1 then
							L_LobbyMain.LobbyMainWin.new_daoju_dj.Location = Vector2(750, 290)
							L_LobbyMain.LobbyMainWin.new_daoju_dj.NormLocation = Vector2(750, 290)
							L_LobbyMain.LobbyMainWin.new_daoju_dj.UseTimer = false
							L_LobbyMain.LobbyMainWin.new_daoju_dj.Visible = true
							if main_props_window_ui and main_props_window_ui.btn_xiaohao.PushDown == true then
								if L_LobbyMain.LobbyMainWin.new_daoju_dj.Visible == true then
									L_LobbyMain.LobbyMainWin.new_daoju_dj:Show()
									L_LobbyMain.LobbyMainWin.new_daoju_dj.UseTimer = true
									L_LobbyMain.LobbyMainWin.new_daoju_dj.DisplayTime = 0.5
									L_PushCmd.New_daoju_dj = 0
								end	
							end	
						end
						if L_PushCmd.New_daoju_jiacheng == 1 then
							L_LobbyMain.LobbyMainWin.new_daoju_jiacheng.Location = Vector2(840, 290)
							L_LobbyMain.LobbyMainWin.new_daoju_jiacheng.NormLocation = Vector2(840, 290)
							L_LobbyMain.LobbyMainWin.new_daoju_jiacheng.UseTimer = false
							L_LobbyMain.LobbyMainWin.new_daoju_jiacheng.Visible = true
							if main_props_window_ui and main_props_window_ui.btn_jiacheng.PushDown == true then
								if L_LobbyMain.LobbyMainWin.new_daoju_jiacheng.Visible == true then
									L_LobbyMain.LobbyMainWin.new_daoju_jiacheng:Show()
									L_LobbyMain.LobbyMainWin.new_daoju_jiacheng.UseTimer = true
									L_LobbyMain.LobbyMainWin.new_daoju_jiacheng.DisplayTime = 0.5
									L_PushCmd.New_daoju_jiacheng = 0
								end	
							end	
						end
						if L_PushCmd.New_daoju_lantu == 1 then
							L_LobbyMain.LobbyMainWin.new_daoju_lantu.Location = Vector2(930, 290)
							L_LobbyMain.LobbyMainWin.new_daoju_lantu.NormLocation = Vector2(930, 290)
							L_LobbyMain.LobbyMainWin.new_daoju_lantu.UseTimer = false
							L_LobbyMain.LobbyMainWin.new_daoju_lantu.Visible = true
							if main_props_window_ui and main_props_window_ui.btn_lantu.PushDown == true then
								if L_LobbyMain.LobbyMainWin.new_daoju_lantu.Visible == true then
									L_LobbyMain.LobbyMainWin.new_daoju_lantu:Show()
									L_LobbyMain.LobbyMainWin.new_daoju_lantu.UseTimer = true
									L_LobbyMain.LobbyMainWin.new_daoju_lantu.DisplayTime = 0.5
									L_PushCmd.New_daoju_lantu = 0
								end	
							end	
						end
						if L_PushCmd.New_daoju_mingpian == 1 then
							L_LobbyMain.LobbyMainWin.new_daoju_mingpian.Location = Vector2(1020, 290)
							L_LobbyMain.LobbyMainWin.new_daoju_mingpian.NormLocation = Vector2(1020, 290)
							L_LobbyMain.LobbyMainWin.new_daoju_mingpian.UseTimer = false
							L_LobbyMain.LobbyMainWin.new_daoju_mingpian.Visible = true
							if main_props_window_ui and main_props_window_ui.btn_mingpian.PushDown == true then
								if L_LobbyMain.LobbyMainWin.new_daoju_mingpian.Visible == true then
									L_LobbyMain.LobbyMainWin.new_daoju_mingpian:Show()
									L_LobbyMain.LobbyMainWin.new_daoju_mingpian.UseTimer = true
									L_LobbyMain.LobbyMainWin.new_daoju_mingpian.DisplayTime = 0.5
									L_PushCmd.New_daoju_mingpian = 0
								end	
							end	
						end
						if L_PushCmd.New_daoju_libao == 1 then
							L_LobbyMain.LobbyMainWin.new_daoju_libao.Location = Vector2(1110, 290)
							L_LobbyMain.LobbyMainWin.new_daoju_libao.NormLocation = Vector2(1110, 290)
							L_LobbyMain.LobbyMainWin.new_daoju_libao.UseTimer = false
							L_LobbyMain.LobbyMainWin.new_daoju_libao.Visible = true
							if main_props_window_ui and main_props_window_ui.btn_libao.PushDown == true then
								if L_LobbyMain.LobbyMainWin.new_daoju_libao.Visible == true then
									L_LobbyMain.LobbyMainWin.new_daoju_libao:Show()
									L_LobbyMain.LobbyMainWin.new_daoju_libao.UseTimer = true
									L_LobbyMain.LobbyMainWin.new_daoju_libao.DisplayTime = 0.5
									L_PushCmd.New_daoju_libao = 0
								end	
							end	
						end
					end
					gui:PlayAudio("kUIA_CLOSE_UI2")
				end
			},
		},
		--Close Button
		Gui.Button "btn_Close"
		{
			Size = Vector2(64, 52),
			Location = Vector2(1049, 3),
			PushDown = false,
			Hint = lang:GetText("关闭仓库并返回至战区"),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button01_normal.dds", Vector4(0, 0, 0, 0)),
				HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button01_hover.dds", Vector4(0, 0, 0, 0)),
				DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button01_down.dds", Vector4(0, 0, 0, 0)),
				DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button01_normal.dds", Vector4(0, 0, 0, 0)),
			},

			EventClick = function()
				L_WarZone.Show(L_LobbyMain.LobbyMainWin_Boddy.LobbyMainWin_Boddy_Root)
			end
		},
	},
}

--0角色管理，1道具管理
function ShowWhichWin(win_parent, which)
	if which == 0 then
		if main_character_window_ui then
			main_character_window_ui.ctrl_character_main.Parent = win_parent
			if main_props_window_ui then
				main_props_window_ui.ctrl_props_main.Parent = nil
			end
			return
		end
		--在FillCharacterClass中填充
		main_character_window_ui = Gui.Create(win_parent)(main_character_window)
		main_character_window_ui["tab_btn_1"].PushDown = true
		characters_tab_event()
	elseif which == 1 then
		if main_props_window_ui then
			main_props_window_ui.ctrl_props_main.Parent = win_parent
			if main_character_window_ui then
				main_character_window_ui.ctrl_character_main.Parent = nil
			end
			return
		end
		main_props_window_ui = Gui.Create(win_parent)(main_props_window)
		L_ShoppingMall.main_window_Creat = true
		L_ShoppingMall.fill_cbx_Weapon_Type(main_props_window_ui.cbx_Filter_Type, L_ShoppingMall.Fileter_prop_Storage_Type)
		if main_props_window_ui then
			setup_ib_prop(main_props_window_ui.ctrl_prop_win)
		end
	end
end

function Initialize()
	current_selected_ibtn_index = -1
	current_selected_item_class = -1
	ShowWhichWin(root_ui, current_selected)

	--设置avatar窗口显示
	if main_character_window_ui then
		ShowClassInfo(main_character_window_ui.ctrl_character_main)
		ShowPackgeInfo(main_character_window_ui.ctrl_character_main)
		if avatart_main_ui then
			ShowUserBag(avatart_main_ui.ctrl_shopping_cart)
		end
		if user_bag_ui then
			setup_user_bag(user_bag_ui.ctrl_shopping_cart_Main)
		end
		if packge_main_ui then
			setup_ib_weapon(packge_main_ui.ctrl_Packge_Main)
		end		
	end
end

function Finalize()
	if root_ui then
		root_ui = nil
	end
	
	if main_character_window_ui then
		main_character_window_ui = nil
	end

	if main_props_window_ui then
		main_props_window_ui = nil
	end

	if avatart_main_ui then
		avatart_main_ui = nil
	end

	if packge_main_ui then
		packge_main_ui = nil
	end

	if user_bag_ui then
		user_bag_ui = nil
	end

	if user_bag_info_ui then
		user_bag_info_ui = nil
	end

	if ib_weapon_ui then
		ib_weapon_ui = nil
	end

	if ib_dress_ui then
		ib_dress_ui = nil
	end

	if ib_accessories_ui then
		ib_accessories_ui = nil
	end

	if prop_window_ui then
		prop_window_ui = nil
	end
	
	current_selected = 0
	bool_ib_prop = 
	{
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
	}
end

--角色管理
function Show(parent_win)
	L_LobbyMain.HideAll()

	L_LobbyMain.LobbyMainWin_Foot.btn_Characters.PushDown = true
	root_ui = parent_win
	ptr_cast(game.CurrentState):OnChange_Lobby_Music(0)
	if current_selected == 0 then
		if main_props_window_ui then
			main_props_window_ui.btn_Characters.PushDown = true
			main_props_window_ui.btn_Property.PushDown = false
			main_props_window_ui.ctrl_props_main.Parent = nil			
		end
		if main_character_window_ui then
			main_character_window_ui.ctrl_character_main.Parent = parent_win
			main_character_window_ui.btn_Characters.PushDown = true
			main_character_window_ui.btn_Property.PushDown = false
			
			if L_LobbyMain.current_character_storage == 1 then
				setup_ib_weapon(packge_main_ui.ctrl_Packge_Main)
			elseif L_LobbyMain.current_character_storage == 2 then
				setup_ib_dress(packge_main_ui.ctrl_Packge_Main)
			elseif L_LobbyMain.current_character_storage == 3 then
				setup_ib_accessories(packge_main_ui.ctrl_Packge_Main)
			end
		end
	elseif current_selected == 1 then
		if main_character_window_ui then
			main_character_window_ui.btn_Characters.PushDown = false
			main_character_window_ui.btn_Property.PushDown = true
			main_character_window_ui.ctrl_character_main.Parent = nil
		end
		if main_props_window_ui then
			main_props_window_ui.ctrl_props_main.Parent = parent_win
			main_props_window_ui.btn_Characters.PushDown = false
			main_props_window_ui.btn_Property.PushDown = true
			if L_LobbyMain.LobbyMainWin.new_daoju.Visible == true then
				L_LobbyMain.LobbyMainWin.new_daoju:Show()
				L_LobbyMain.LobbyMainWin.new_daoju.UseTimer = true
				L_LobbyMain.LobbyMainWin.new_daoju.DisplayTime = 0.5
				L_PushCmd.New_daoju = 0
			end	

			if L_PushCmd.New_daoju_sc == 1 then
				L_LobbyMain.LobbyMainWin.new_daoju_sc.Location = Vector2(570, 290)
				L_LobbyMain.LobbyMainWin.new_daoju_sc.NormLocation = Vector2(570, 290)
				L_LobbyMain.LobbyMainWin.new_daoju_sc.UseTimer = false
				L_LobbyMain.LobbyMainWin.new_daoju_sc.Visible = true
				if main_props_window_ui and main_props_window_ui.btn_gongneng.PushDown == true then
					if L_LobbyMain.LobbyMainWin.new_daoju_sc.Visible == true then
						L_LobbyMain.LobbyMainWin.new_daoju_sc:Show()
						L_LobbyMain.LobbyMainWin.new_daoju_sc.UseTimer = true
						L_LobbyMain.LobbyMainWin.new_daoju_sc.DisplayTime = 0.5
						L_PushCmd.New_daoju_sc = 0
					end	
				end	
			end
			if L_PushCmd.New_daoju_kjx == 1 then
				L_LobbyMain.LobbyMainWin.new_daoju_kjx.Location = Vector2(660, 290)
				L_LobbyMain.LobbyMainWin.new_daoju_kjx.NormLocation = Vector2(660, 290)
				L_LobbyMain.LobbyMainWin.new_daoju_kjx.UseTimer = false
				L_LobbyMain.LobbyMainWin.new_daoju_kjx.Visible = true
				if main_props_window_ui and main_props_window_ui.btn_hecheng.PushDown == true then
					if L_LobbyMain.LobbyMainWin.new_daoju_kjx.Visible == true then
						L_LobbyMain.LobbyMainWin.new_daoju_kjx:Show()
						L_LobbyMain.LobbyMainWin.new_daoju_kjx.UseTimer = true
						L_LobbyMain.LobbyMainWin.new_daoju_kjx.DisplayTime = 0.5
						L_PushCmd.New_daoju_kjx = 0
					end	
				end	
			end
			if L_PushCmd.New_daoju_dj == 1 then
				L_LobbyMain.LobbyMainWin.new_daoju_dj.Location = Vector2(750, 290)
				L_LobbyMain.LobbyMainWin.new_daoju_dj.NormLocation = Vector2(750, 290)
				L_LobbyMain.LobbyMainWin.new_daoju_dj.UseTimer = false
				L_LobbyMain.LobbyMainWin.new_daoju_dj.Visible = true
				if main_props_window_ui and main_props_window_ui.btn_xiaohao.PushDown == true then
					if L_LobbyMain.LobbyMainWin.new_daoju_dj.Visible == true then
						L_LobbyMain.LobbyMainWin.new_daoju_dj:Show()
						L_LobbyMain.LobbyMainWin.new_daoju_dj.UseTimer = true
						L_LobbyMain.LobbyMainWin.new_daoju_dj.DisplayTime = 0.5
						L_PushCmd.New_daoju_dj = 0
					end	
				end	
			end
			if L_PushCmd.New_daoju_jiacheng == 1 then
				L_LobbyMain.LobbyMainWin.new_daoju_jiacheng.Location = Vector2(840, 290)
				L_LobbyMain.LobbyMainWin.new_daoju_jiacheng.NormLocation = Vector2(840, 290)
				L_LobbyMain.LobbyMainWin.new_daoju_jiacheng.UseTimer = false
				L_LobbyMain.LobbyMainWin.new_daoju_jiacheng.Visible = true
				if main_props_window_ui and main_props_window_ui.btn_jiacheng.PushDown == true then
					if L_LobbyMain.LobbyMainWin.new_daoju_jiacheng.Visible == true then
						L_LobbyMain.LobbyMainWin.new_daoju_jiacheng:Show()
						L_LobbyMain.LobbyMainWin.new_daoju_jiacheng.UseTimer = true
						L_LobbyMain.LobbyMainWin.new_daoju_jiacheng.DisplayTime = 0.5
						L_PushCmd.New_daoju_jiacheng = 0
					end	
				end	
			end
			if L_PushCmd.New_daoju_lantu == 1 then
				L_LobbyMain.LobbyMainWin.new_daoju_lantu.Location = Vector2(930, 290)
				L_LobbyMain.LobbyMainWin.new_daoju_lantu.NormLocation = Vector2(930, 290)
				L_LobbyMain.LobbyMainWin.new_daoju_lantu.UseTimer = false
				L_LobbyMain.LobbyMainWin.new_daoju_lantu.Visible = true
				if main_props_window_ui and main_props_window_ui.btn_lantu.PushDown == true then
					if L_LobbyMain.LobbyMainWin.new_daoju_lantu.Visible == true then
						L_LobbyMain.LobbyMainWin.new_daoju_lantu:Show()
						L_LobbyMain.LobbyMainWin.new_daoju_lantu.UseTimer = true
						L_LobbyMain.LobbyMainWin.new_daoju_lantu.DisplayTime = 0.5
						L_PushCmd.New_daoju_lantu = 0
					end	
				end	
			end
			if L_PushCmd.New_daoju_mingpian == 1 then
				L_LobbyMain.LobbyMainWin.new_daoju_mingpian.Location = Vector2(1020, 290)
				L_LobbyMain.LobbyMainWin.new_daoju_mingpian.NormLocation = Vector2(1020, 290)
				L_LobbyMain.LobbyMainWin.new_daoju_mingpian.UseTimer = false
				L_LobbyMain.LobbyMainWin.new_daoju_mingpian.Visible = true
				if main_props_window_ui and main_props_window_ui.btn_mingpian.PushDown == true then
					if L_LobbyMain.LobbyMainWin.new_daoju_mingpian.Visible == true then
						L_LobbyMain.LobbyMainWin.new_daoju_mingpian:Show()
						L_LobbyMain.LobbyMainWin.new_daoju_mingpian.UseTimer = true
						L_LobbyMain.LobbyMainWin.new_daoju_mingpian.DisplayTime = 0.5
						L_PushCmd.New_daoju_mingpian = 0
					end	
				end	
			end
			if L_PushCmd.New_daoju_libao == 1 then
				L_LobbyMain.LobbyMainWin.new_daoju_libao.Location = Vector2(1110, 290)
				L_LobbyMain.LobbyMainWin.new_daoju_libao.NormLocation = Vector2(1110, 290)
				L_LobbyMain.LobbyMainWin.new_daoju_libao.UseTimer = false
				L_LobbyMain.LobbyMainWin.new_daoju_libao.Visible = true
				if main_props_window_ui and main_props_window_ui.btn_libao.PushDown == true then
					if L_LobbyMain.LobbyMainWin.new_daoju_libao.Visible == true then
						L_LobbyMain.LobbyMainWin.new_daoju_libao:Show()
						L_LobbyMain.LobbyMainWin.new_daoju_libao.UseTimer = true
						L_LobbyMain.LobbyMainWin.new_daoju_libao.DisplayTime = 0.5
						L_PushCmd.New_daoju_libao = 0
					end	
				end	
			end
			if L_LobbyMain.current_character_storage > 3 then
				setup_ib_prop(main_props_window_ui.ctrl_prop_win)
			end
		end
	end
end

function Hide()
	current_selected_ibtn_index = -1
	current_selected_item_class = -1
	if main_character_window_ui then
		if main_character_window_ui.ctrl_character_main.Parent ~= nil then
			ptr_cast(game.CurrentState):OnChange_Lobby_Music(2)
		end
		main_character_window_ui.ctrl_character_main.Parent = nil
	end

	if main_props_window_ui then
		if main_props_window_ui.ctrl_props_main.Parent ~= nil then
			ptr_cast(game.CurrentState):OnChange_Lobby_Music(2)
		end
		main_props_window_ui.ctrl_props_main.Parent = nil
	end
	if ib_weapon_ui then
		ib_weapon_ui.ctrl_ib_container.Parent = nil
	end
	
	if Renewals_window_page_ui then
		Renewals_window_page_ui.Close()
		Renewals_window_page_ui = nil
	end
	
	if tuozhuai_ui then
		tuozhuai_ui.root.Parent = nil
		tuozhuai_ui = nil
	end
	
	if L_LobbyMain.ui_des_bag.root then
		L_LobbyMain.ui_des_bag.root.Parent = nil
	end
	
end

function RestAllCharacterBagItemBoxBtn()
	if user_bag_info_ui then 
		user_bag_info_ui.ib_primary_weapon.Selected = false
		user_bag_info_ui.ib_secondary_weapon.Selected = false
		user_bag_info_ui.ib_grenade.Selected = false
		user_bag_info_ui.ib_melee_weapons.Selected = false
		user_bag_info_ui.ib_no_use.Selected = false
		user_bag_info_ui.ib_hat.Selected = false
		user_bag_info_ui.ib_last.Selected = false
	end
end

function RestAllStorgeItemBoxBtn()
	--武器界面
	if ib_weapon_ui then
		for i = 1, 8 do
			local ibbtn = ptr_cast(ib_weapon_ui.ctrl_ib_container:GetChildByIndex(i-1))
			if ibbtn then
				ibbtn.Selected = false
			end
		end
	end
	--套装界面
	if ib_dress_ui then
		for i = 1, 8 do
			local ibbtn = ptr_cast(ib_dress_ui.ctrl_ib_container:GetChildByIndex(i-1))
			if ibbtn then
				ibbtn.Selected = false
			end
		end
	end
	--配饰界面
	if ib_accessories_ui then
		for i = 1, 16 do
			local ibbtn = ptr_cast(ib_accessories_ui.ctrl_ib_container:GetChildByIndex(i-1))
			if ibbtn then
				ibbtn.Selected = false
			end
		end
	end
	--道具界面
	if prop_window_ui then
		for i = 1, 28 do
			local ibbtn = ptr_cast(prop_window_ui.ctrl_ib_container:GetChildByIndex(i-1))
			if ibbtn then
				ibbtn.Selected = false
			end
		end		
	end
end

function InitAllCharacterBagItemBoxBtnEvent()
	RestAllCharacterBagItemBoxBtn()
end



--填充左侧道具信息
function FillPropInfo(index)
	if index < 1 then
		if main_props_window_ui then
			main_props_window_ui.ctrl_prop_info_icon.BackgroundColor = ARGB(0, 255, 255, 255)
			main_props_window_ui.ctrl_prop_info_icon.Skin = nil			
			main_props_window_ui.lbl_prop_info_title.Text = ""
			main_props_window_ui.txtA_prop_info_body.Text = ""
		end
		return
	end
	
	if L_LobbyMain.CharactersIB_rpc_data and main_props_window_ui then
		
		local items = L_LobbyMain.CharactersIB_rpc_data.items
		if items then
			if items[index] then
				main_props_window_ui.ctrl_prop_info_icon.BackgroundColor = ARGB(255, 255, 255, 255)
				main_props_window_ui.ctrl_prop_info_icon.Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ibt_icon/"..items[index].name..".tga", Vector4(0, 0, 0, 0)),
				}
				main_props_window_ui.lbl_prop_info_title.Text = items[index].display
				main_props_window_ui.txtA_prop_info_body.Text = items[index].description
			end
		end
	end	
end

function Highlight_accessories_tip(index1)
	if L_LobbyMain.CharactersIB_rpc_data.items[index1].common.seq == 2 then
		user_bag_info_ui.ib_hat.Highlight = true
	else
		user_bag_info_ui.ib_last.Highlight = true
	end
end