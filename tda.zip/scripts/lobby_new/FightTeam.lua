module("L_FightTeam", package.seeall)

math.randomseed(os.clock())
province =
{
	lang:GetText("北京市"),              
	lang:GetText("天津市"),
	lang:GetText("重庆市"),
	lang:GetText("上海市"),
	lang:GetText("河北省"),
	lang:GetText("山西省"),
	lang:GetText("内蒙古自治区"),
	lang:GetText("辽宁省"),
	lang:GetText("吉林省"),
	lang:GetText("黑龙江省"),
	lang:GetText("江苏省"),
	lang:GetText("广西壮族自治区"),
	lang:GetText("浙江省"),
	lang:GetText("安徽省"),
	lang:GetText("福建省"),
	lang:GetText("江西省"),
	lang:GetText("山东省"),
	lang:GetText("河南省"),
	lang:GetText("湖北省"),
	lang:GetText("湖南省"),
	lang:GetText("广东省"),
	lang:GetText("海南省"),
	lang:GetText("四川省"),
	lang:GetText("贵州省"),
	lang:GetText("云南省"),
	lang:GetText("陕西省"),
	lang:GetText("西藏自治区"),
	lang:GetText("甘肃省"),
	lang:GetText("青海省"),
	lang:GetText("宁夏回族自治区"),
	lang:GetText("新疆维吾尔自治区"),
}

city =
{
	{lang:GetText("北京市"),},
	{lang:GetText("天津市"),},
	{lang:GetText("重庆市"),},
	{lang:GetText("上海市"),},
	{lang:GetText("石家庄市"),lang:GetText("邯郸市"),lang:GetText("邢台市"),lang:GetText("保定市"),lang:GetText("张家口市"),lang:GetText("承德市"),lang:GetText("唐山市"),lang:GetText("秦皇岛市"),lang:GetText("沧州市"),lang:GetText("廊坊市"),lang:GetText("衡水市"),},
	{lang:GetText("太原市"),lang:GetText("大同市"),lang:GetText("阳泉市"),lang:GetText("长治市"),lang:GetText("朔州市"),lang:GetText("榆次市"),lang:GetText("孝义市"),lang:GetText("临汾市"),lang:GetText("运城市"),},
	{lang:GetText("呼和浩特"),lang:GetText("包头市"),lang:GetText("巴林左旗"),lang:GetText("二连浩特市"),lang:GetText("满洲里市"),lang:GetText("通辽市"),lang:GetText("准格尔旗"),lang:GetText("乌兰浩特市"),},
	{lang:GetText("沈阳市"),lang:GetText("大连市"),lang:GetText("鞍山市"),lang:GetText("抚顺市"),lang:GetText("本溪市"),lang:GetText("丹东市"),lang:GetText("锦州市"),lang:GetText("营口市"),lang:GetText("阜新市"),lang:GetText("辽阳市"),lang:GetText("沈阳市"),},
	{lang:GetText("长春市"),lang:GetText("吉林市"),lang:GetText("四平市"),lang:GetText("辽源市"),lang:GetText("通化市"),lang:GetText("临江市"),lang:GetText("大安市"),lang:GetText("敦化市"),lang:GetText("珲春市"),},
	{lang:GetText("哈尔滨市"),lang:GetText("齐齐哈尔市"),lang:GetText("大庆市"),lang:GetText("伊春市"),lang:GetText("牡丹江市"),lang:GetText("佳木斯市"),lang:GetText("缓化市"),lang:GetText("漠河县"),lang:GetText("黑河市"),},
	{lang:GetText("南京市"),lang:GetText("徐州市"),lang:GetText("连云港市"),lang:GetText("淮安市"),lang:GetText("宿迁市"),lang:GetText("盐城市"),lang:GetText("扬州市"),lang:GetText("南通市"),lang:GetText("镇江市"),lang:GetText("常州市"),lang:GetText("无锡市"),lang:GetText("苏州市"),lang:GetText("常熟市"),},
	{lang:GetText("南宁市"),lang:GetText("柳州市"),lang:GetText("桂林市"),lang:GetText("梧州市"),lang:GetText("北海市"),lang:GetText("钦州市"),},
	{lang:GetText("杭州市"),lang:GetText("宁波市"),lang:GetText("嘉兴市"),lang:GetText("湖州市"),lang:GetText("绍兴市"),lang:GetText("金华市"),lang:GetText("衢州市"),lang:GetText("舟山市"),lang:GetText("温州市"),lang:GetText("台州市"),},
	{lang:GetText("合肥市"),lang:GetText("淮南市"),lang:GetText("蚌埠市"),lang:GetText("马鞍山市"),lang:GetText("安庆市"),lang:GetText("黄山市"),lang:GetText("滁州市"),lang:GetText("宿州市"),lang:GetText("巢湖市"),lang:GetText("宣州市"),},
	{lang:GetText("福州市"),lang:GetText("厦门市"),lang:GetText("三明市"),lang:GetText("莆田市"),lang:GetText("泉州市"),lang:GetText("漳州市"),lang:GetText("南平市"),lang:GetText("宁德市"),lang:GetText("龙岩市"),},
	{lang:GetText("南昌市"),lang:GetText("新余市"),lang:GetText("九江市"),lang:GetText("鹰潭市"),lang:GetText("上饶市"),lang:GetText("宜春市"),lang:GetText("临川市"),lang:GetText("吉安市"),lang:GetText("赣州市"),lang:GetText("景德镇市"),},
	{lang:GetText("济南市"),lang:GetText("青岛市"),lang:GetText("淄博市"),lang:GetText("潍坊市"),lang:GetText("烟台市"),lang:GetText("威海市"),lang:GetText("兖州市"),lang:GetText("日照市"),lang:GetText("德州市"),lang:GetText("郓城县"),},
	{lang:GetText("郑州市"),lang:GetText("开封市"),lang:GetText("洛阳市"),lang:GetText("新乡市"),lang:GetText("濮阳市"),lang:GetText("商丘市"),lang:GetText("南阳市"),lang:GetText("周口市"),lang:GetText("汝南县"),},
	{lang:GetText("武汉市"),lang:GetText("黄石市"),lang:GetText("襄樊市"),lang:GetText("十堰市"),lang:GetText("宜昌市"),lang:GetText("荆门市"),lang:GetText("孝感市"),lang:GetText("黄冈市"),lang:GetText("恩施市"),lang:GetText("荆沙"),},
	{lang:GetText("长沙市"),lang:GetText("株州市"),lang:GetText("湘潭市"),lang:GetText("衡阳市"),lang:GetText("岳阳市"),lang:GetText("常德市"),lang:GetText("郴州市"),lang:GetText("益阳市"),lang:GetText("冷水滩"),lang:GetText("怀化市"),lang:GetText("张家界"),},
	{lang:GetText("广州市"),lang:GetText("深圳市"),lang:GetText("珠海市"),lang:GetText("汕头市"),lang:GetText("韶关市"),lang:GetText("惠州市"),lang:GetText("东莞市"),lang:GetText("中山市"),lang:GetText("佛山市"),lang:GetText("湛江市"),},
	{lang:GetText("海口市"),lang:GetText("三亚市"),lang:GetText("儋州市"),},
	{lang:GetText("成都市"),lang:GetText("攀枝花市"),lang:GetText("德阳市"),lang:GetText("绵阳市"),lang:GetText("自贡市"),lang:GetText("内江市"),lang:GetText("乐山市"),lang:GetText("泸州市"),lang:GetText("宜宾市"),},
	{lang:GetText("贵阳市"),lang:GetText("遵义市"),lang:GetText("安顺市"),lang:GetText("六盘水市"),},
	{lang:GetText("昆明市"),lang:GetText("昭通市"),lang:GetText("曲靖市"),lang:GetText("江川市"),lang:GetText("思茅市"),lang:GetText("丽江县"),lang:GetText("开远市"),lang:GetText("楚雄市"),},
	{lang:GetText("西安市"),lang:GetText("铜川市"),lang:GetText("宝鸡市"),lang:GetText("渭南市"),lang:GetText("商州市"),},
	{lang:GetText("拉萨市"),lang:GetText("日喀则市"),lang:GetText("仁布县"),lang:GetText("丁青县"),lang:GetText("阿里地区"),},
	{lang:GetText("兰州市"),lang:GetText("金昌市"),lang:GetText("天水市"),lang:GetText("平凉市"),lang:GetText("玉门市"),lang:GetText("敦煌市"),},
	{lang:GetText("西宁市"),lang:GetText("平安县"),lang:GetText("格尔木市"),lang:GetText("玛沁县"),},
	{lang:GetText("银川市"),lang:GetText("石嘴山市"),lang:GetText("青铜峡市"),lang:GetText("海原县"),},
	{lang:GetText("乌鲁木齐市"),lang:GetText("克拉玛依市"),lang:GetText("吐鲁番市"),lang:GetText("喀什市"),lang:GetText("阿图什市"),lang:GetText("库尔勒市"),},
}
max_fightteam_level = 12
team_data = nil
team_ui = nil
my_mode = nil -- 1：基本信息 2：战队成员  
mode = 1 -- 1: 我的战队 2：战队列表
t_id = nil --战队ID
t_rank = nil --战队加入等级
team_create_data = {pid = ptr_cast(game.CurrentState):GetCharacterId(), name = "", description = "", logo = "", province = "", city = "", rank = "",playerItemId = 0}
num = nil --申请人数
max_num = nil --当前战队的最大人数
te_num = 0 --当前战队的人数
request_list_ui = nil
p_job = nil --战队等级 1：普通成员 4：战队队长
default_mode = 1
team_logo = nil --战队头像
team_description = nil
rank_select_page = 1 --当前选择页
rank_select_pages = 1
rank_page = 0 --当前排名的页数的基数
max_page = 9  --最大页数
t_info_ui = nil
tid_of_list = nil --当前战队列表中选择的tid
t_page = nil --当前战队成员的页数
t_pages = nil --当前战队成员最大页数
pt_id = nil
myteam_level = nil
current_level = nil
lead_vip = nil
lead_name = nil
Max_item = nil
s_province = ""
s_city = ""
s_key = nil
time_num = 0
key_item = {} -- 快速购买
key_num = 0
create_fightteam_room_option = nil
create_source_room_option = nil
-- state.battle_is_create = false
-- source_is_create = false
battle_ready = false
battle_pipei_success = false
source_pipei_success = false
defense_success = false
my_battle_info = nil
battle_all_player_info = {{},{},{},{},{},{}}
tiaozhan_battle_info = {{},{},{},{},{},{},{}}
three_battle_info = {{},{},{}}
three_battle_player_info = {
							{{},{},{},{},{},{}},
							{{},{},{},{},{},{}},
							{{},{},{},{},{},{}}
							}
three_battle_page = 0
is_in_fight_ui = false --判断点击战队按钮直接退到服务器列表
is_in_invite = false --判断战队邀请直接退到服务器列表
invite_group = -1 --邀请的战队
invite_server_id = 0
invite_channel_id = 0
invite_room_id = 0
my_contribution = 0
tiaozhan_page = 1
my_battle_province = ""
my_battle_city = ""
my_battle_name = ""
battle_host_id = 0
quick_buy_sid = {}
image_id = 1 -- 战队头像的ID
selsect_image_id = 1 -- 选择的战队头像ID
team_list_type = 1
s_name = ""
is_self = 0
items = nil --战队BUFF TOOLTIPS
is_first_in = false
attack_team_info = {{nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil},
					{nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil},
					{nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil},
					{nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil},
					{nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil},
					{nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil},
					{nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil},
					{nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil},
					{nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil},
					{nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil}
					}
TeamHeader_Data = nil --保存战队顶上的info数据
TeamWar_info = nil --保存战队资源站的info数据
Personal_info = nil --保存个人资源站的info数据
TreeInfo = {{},{},{},{}} --保存天赋树的info数据
is_Edit_create_room = false
defance_num = 0
p_UnusableResource = 0
local cType = 2 --仓库当前的类型选项值1 = 防御类。2=攻击类。3=消耗类
local tType = 2 --天赋树当前的类型选项值1 = 防御类。2=攻击类。3=消耗类
local sType = 3 --防御类1,攻击类2,个人坦克3,油罐是5
local cPage = 1 --当前的页数
local buff_cPage = 1 --buff界面当前的页数
local deployIndex = 0
local storageIndex = 0
local maxCount = 6 --仓库最大当前页格数
local towerTree = 9 --防御塔天赋树最大格数
local isTeamLeader = false
local isTeamOrPersonal = 0  --0是战队界面，1是个人界面
local selected_ibtn_index = 1 	--战队仓库防御塔选中框id
local selected_ibtn_index2 = 1	--战队仓库防御墙选中框id
local selected_ibtn_index3 = 1	--个人仓库坦克选中框id
local selected_ibtn_index9 = 1	--个人仓库BUFF选中框id
local selected_ibtn_index4 = 1 --战队仓库原石采矿机选中框id
local selected_ibtn_index5 = 1  --战队科技树防御塔选中框id
local selected_ibtn_index6 = 1  --战队科技树防御墙选中框id
local selected_ibtn_index7 = 1  --战队科技树挖掘机选中框id
local selected_ibtn_index8 = 1  --个人科技树坦克选中框id
local selected_person_exchange = 1
local selected_team_exchange = 1
local selected_team_buy = 1
local combox_selIdx = 1
local combox_selIdx2= 1
local combox_BuffSelFcIdx = 1
local combox_BuffSelResIdx = 1
local CharmBottle_Window = nil
local MagicBoxIId = 48  --不要动这个值

Res_ratio_status1 = 0
player_Res_ratio_status1 = 0



function initIdx()
	cType = 2 --仓库当前的类型选项值1 = 防御类。2=攻击类。3=消耗类
	tType = 2 --天赋树当前的类型选项值1 = 防御类。2=攻击类。3=消耗类
	sType = 3
	cPage = 1 --当前的页数
	deployIndex = 0
	storageIndex = 0
	selected_ibtn_index = 1 	--战队仓库防御塔选中框id
	selected_ibtn_index2 = 1	--战队仓库防御墙选中框id
	selected_ibtn_index3 = 1	--个人仓库坦克选中框id
	selected_ibtn_index4 = 1 --战队仓库原石采矿机选中框id
	selected_ibtn_index5 = 1  --战队科技树防御塔选中框id
	selected_ibtn_index6 = 1  --战队科技树防御墙选中框id
	selected_ibtn_index7 = 1  --战队科技树挖掘机选中框id
	selected_ibtn_index8 = 1  --个人科技树坦克选中框id
	selected_ibtn_index9 = 1	--个人仓库BUFF选中框id
	combox_selIdx = 1
	combox_selIdx2= 1
	combox_BuffSelFcIdx = 1
	combox_BuffSelResIdx = 1
	isP_Tree = false
	nIdx = 0
	pIdx = 0
end

isP_Tree = false
nIdx = 0
pIdx = 0
IT = 1 --1,威力2,射速3,hp4,射程5;转速
modalFlash = nil
saveInfo = {}
p_saveInfo = {}
save_T_res = nil
save_P_res = nil
local getPrice = 
{
	{TextPrice = lang:GetText("100   返：600黑晶石"),cost = 100,cur = 2},
	{TextPrice = lang:GetText("500   返：3000黑晶石"),cost = 500,cur = 2},
	{TextPrice = lang:GetText("2500  返：15000黑晶石"),cost = 2500,cur = 2},
	{TextPrice = lang:GetText("10000 返：60000黑晶石"),cost = 10000,cur = 2},
	{TextPrice = lang:GetText("50000 返：300000黑晶石"),cost = 50000,cur = 2},
	{TextPrice = lang:GetText("战队黑铁:25"),cost = 25,cur = 6},
	{TextPrice = lang:GetText("战队黑铁:125"),cost = 125,cur = 6},
	{TextPrice = lang:GetText("战队黑铁:625"),cost = 625,cur = 6},
	{TextPrice = lang:GetText("战队黑铁:2500"),cost = 2500,cur = 6},
	{TextPrice = lang:GetText("战队黑铁:12500"),cost = 12500,cur = 6},
}
local getPersonalPrice = 
{	
	{TextPrice = lang:GetText("个人黑晶石:1200"),cost = 1200,cur = 5},
	{TextPrice = lang:GetText("个人黑晶石:6000"),cost = 6000,cur = 5},	
	{TextPrice = lang:GetText("个人黑晶石:30000"),cost = 30000,cur = 5},	
	{TextPrice = lang:GetText("个人黑晶石:150000"),cost = 150000,cur = 5},	
	{TextPrice = lang:GetText("个人黑晶石:750000"),cost = 750000,cur = 5},
}
-- 提升攻击力BUFF			（43）
-- 提升攻击速度BUFF			（44）
-- 提升血量上限BUFF			(45）
-- 提升抗性BUFF			（46）
-- 提升移动速度BUFF		（47）
local getBuffName = 
{
	[39] = lang:GetText("恢复血量："),
	[40] = lang:GetText("补充弹药："),
	[43] = lang:GetText("提升攻击力："),
	[44] = lang:GetText("提升攻击速度："),
	[45] = lang:GetText("提升血量上限："),
	[46] = lang:GetText("提升抗性："),
	[47] = lang:GetText("提升移动速度："),
}
SourceFightType = 0 --0 匹配 1 挑战
SourceTiaozhanTid = 0
local invite_player = {} --已邀请玩家
local invite_index = 1
local update_time = 3
local search_type = 0
local request_page = 1
local request_pages = 0
local battel_exp = 0
local pipeiTimes = 1
local language_list = {"zh_CN","en_PH"}
local roompsd = {"a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z","0","1","2","3","4","5","6","7","8","9",}
local psd = ""
local source_start_time = 0
local source_defance_tid = 0
local map_config = nil
local is_exit_room = false
local battleFieldId = 0
local teamSpaceLevel = 0
local canRobUnuseRes = 0
local source_roomnum = 0
local exchange_Buff_Data = nil
local exchange_Item_Data = nil
local SHOP_PersonalTransform = nil
local SHOP_TeamTransofrm = nil
local SHOP_TeamBuy = nil
local idx = 1 --1是显示仓库，2是显示科技所
local pro_nor = {
	Gui.ProportionIcon(nil, "LobbyUI/team/lb_squad_jingyan01_bg.dds", nil, Vector4(0,0,8,6) ),
	Gui.ProportionIcon(nil, "LobbyUI/team/lb_squad_jingyan01_bg.dds", nil, Vector4(0,0,8,6) ),
	Gui.ProportionIcon(nil, "LobbyUI/team/lb_squad_jingyan01_bg.dds", nil, Vector4(0,0,8,6) ),
	Gui.ProportionIcon(nil, "LobbyUI/team/lb_squad_jingyan01_bg.dds", nil, Vector4(0,0,8,6) ),
	Gui.ProportionIcon(nil, "LobbyUI/team/lb_squad_jingyan01_bg.dds", nil, Vector4(0,0,8,6) ),
	Gui.ProportionIcon(nil, "LobbyUI/team/lb_squad_jingyan01_bg.dds", nil, Vector4(0,0,8,6) ),
	Gui.ProportionIcon(nil, "LobbyUI/team/lb_squad_jingyan01_bg.dds", nil, Vector4(0,0,8,6) ),
}
local pro_Personal = {
	Gui.ProportionIcon(nil, "LobbyUI/team/lb_squad_jingyan01_bg.dds", nil, Vector4(0,0,8,6) ),
	Gui.ProportionIcon(nil, "LobbyUI/team/lb_squad_jingyan01_bg.dds", nil, Vector4(0,0,8,6) ),
	Gui.ProportionIcon(nil, "LobbyUI/team/lb_squad_jingyan01_bg.dds", nil, Vector4(0,0,8,6) ),
	Gui.ProportionIcon(nil, "LobbyUI/team/lb_squad_jingyan01_bg.dds", nil, Vector4(0,0,8,6) ),
}
local nengLi_type_Text=
{
	lang:GetText("血量"),
	lang:GetText("威力"),
	lang:GetText("射速"),
	lang:GetText("转向"),
	lang:GetText("射程"),
	lang:GetText("弹药"),
	lang:GetText("耐久"),
}
local P_nengLi_type_Text=
{
	lang:GetText("威力"),
	lang:GetText("血量"),
	lang:GetText("射速"),
	lang:GetText("移动速度"),
}
local game_type_key=
{
	"kTeam",
	"kHoldPoint",
	"kPushVehicle",
	"",
	"kTeamDeathMatch",
	"kBoss",
	"kKnife",
	"kBomb",
	"kStreetBoy",
	"kZombie",
	"kBossPVE",
	"kCommonZombieMode",
	"kBossMode2",
	"kItemMode",
	"kEditMode",
	"kTDMode",
}
local game_type_table=
{
	kTeam = L_Text.kTeam,
	kHoldPoint = L_Text.kHoldPoint,
	kPushVehicle = L_Text.kPushVehicle,
	kTeamDeathMatch = L_Text.kTeamDeathMatch,
	kBoss = L_Text.kBoss,
	kKnife = L_Text.kKnife,
	kBomb = L_Text.kBomb,
	kStreetBoy = L_Text.kStreetBoy,
	kZombie = L_Text.kZombie,
	kBossPVE = L_Text.kBossPVE,
	kCommonZombieMode = L_Text.kCommonZombieMode,
	kBossMode2 = L_Text.kBossMode2,
	kItemMode = L_Text.kItemMode,
	kEditMode = L_Text.kEditMode,
	kTDMode = L_Text.kTDMode,
	kMoonMode = L_Text.kMoonMode,
}
local Fight_Random_GameType = 
{
	"kTeam",
	"kHoldPoint",
	"kPushVehicle",
	"kTeamDeathMatch",
	"kBomb",
	"kStreetBoy",
}

local vip_add = 
{
	0, 50, 60, 70, 80, 90, 100,110,120
}

local vip_keep = 
{
	0, 30, 30, 40, 40, 50, 50,60,60
}

local Rank_Source_Btn_Location  = 
{
	{558-83,436-332},
	{510-83,549-332},
	{679-83,546-332},
	{759-83,456-332},
	{360-83,463-332},
	{455-83,373-332},
	{699-83,374-332},
	{325-83,552-332},
	{437-83,629-332},
	{632-83,644-332},
	{271-83,403-332},
	{218-83,640-332-5},
	{160-83,519-332},
	{903-83,532-332},
	{905-83,384-332},
	-- {271-83,403-332},
	-- {455-83,373-332},
	-- {709-83,364-332},
	-- {905-83,384-332},
	-- {360-83,463-332},
	-- {558-83,426-332},
	-- {759-83,456-332},
	-- {160-83,519-332},
	-- {325-83,552-332},
	-- {510-83,549-332},
	-- {679-83,546-332},
	-- {903-83,532-332},
	-- {218-83,640-332-5},
	-- {437-83,629-332},
	-- {632-83,644-332},
}

function SpawnNewGongGao(id)
	local GongGaoIcon = Gui.Create(gui) {
							Gui.Control "c_gonggao"
							{
								Size = Vector2(448, 88),
								BackgroundColor = ARGB(255, 255, 255, 255),
								Skin = Gui.ControlSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_rank_bg_01.dds", Vector4(34, 34, 34, 34)),
								},
								Gui.Control "c_headicon"
								{
									Size = Vector2(44, 50),
									Location = Vector2(12, 12),
									BackgroundColor = ARGB(255, 255, 255, 255),
									Skin = Gui.ControlSkin
									{
										BackgroundImage = Gui.Image("LobbyUI/persionalInfo/HeadPic/lb_info_image01_b.dds", Vector4(0, 0, 0, 0)),
									},	
								},
								Gui.Label "l_speaker"
								{
									Size = Vector2(280, 25),
									Location = Vector2(71, 3),
									Text = "",
									BackgroundColor = ARGB(0, 255, 255, 255),
									TextAlign = "kAlignLeftMiddle",
									FontSize = 18,
									TextColor = ARGB(255, 255, 103, 1),
								},
								
								Gui.Label "l_date"
								{
									Size = Vector2(170, 20),
									Location = Vector2(71, 65),
									Text = "2012/12/21 12:25",
									BackgroundColor = ARGB(0, 255, 255, 255),
									TextAlign = "kAlignLeftMiddle",
									FontSize = 14,
									TextColor = ARGB(255, 214, 253, 255),
								},
								
								Gui.TextArea "t_text"
								{
									Size = Vector2(310, 50),
									Location = Vector2(71, 25),
									TextColor = ARGB(255, 255, 187, 0),
									FontSize = 16,
									Readonly = true,
									Fold = true,
									BackgroundColor = ARGB(255,255,255,255),
								},
								
								Gui.Button "del_gonggao"
								{
									Size = Vector2(28, 28),
									Location = Vector2(415, 55),
									BackgroundColor = ARGB(255, 255, 255, 255),
									Skin = Gui.ButtonSkin
									{
										BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_v2_02_normal.dds", Vector4(0, 0, 0, 0)),
										HoverImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_v2_02_hover.dds", Vector4(0, 0, 0, 0)),
										DownImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_v2_02_down.dds", Vector4(0, 0, 0, 0)),
										DisabledImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_v2_02_disabled.dds", Vector4(0, 0, 0, 0)),
									},
									
									EventClick = function()
										MessageBox.ShowWithTwoButtons(lang:GetText("确认删除公告？"),lang:GetText("确认"),lang:GetText("取消"),
										function()
											rpc.safecallload("team_proclamation_del", {tid = t_id , tpid = id , pid = ptr_cast(game.CurrentState):GetCharacterId()},
											function(data)
												if data.result == 1 then
													MessageBox.ShowWithTimer(2,lang:GetText("删除成功"))														
													-- FillGongGao()	
												else
													MessageBox.ShowWithTimer(2,lang:GetText("删除失败"))
												end	
											end)
										end,
										nil
										)
									end
								}
							}
						}
	return GongGaoIcon
end

function SpawnNewZhanJi(index)
	local NewZhanJiIcon = Gui.Create(gui) {
							Gui.Control "c_zhanji"
							{
								Size = Vector2(448, 149),
								BackgroundColor = ARGB(255, 255, 255, 255),
								Skin = Gui.ControlSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_rank_bg_01.dds", Vector4(34, 34, 34, 34)),
								},
								Gui.Label "l_moshi"
								{
									Size = Vector2(170, 20),
									Location = Vector2(10, 6),
									Text = lang:GetText("团队竞技："),
									BackgroundColor = ARGB(0, 255, 255, 255),
									TextAlign = "kAlignLeftMiddle",
									FontSize = 20,
									TextColor = ARGB(255, 214, 253, 255),
								},
								Gui.Control "c_map"
								{
									Size = Vector2(156, 105),
									Location = Vector2(10, 32),
									BackgroundColor = ARGB(255, 255, 255, 255),
									Skin = Gui.ControlSkin
									{
										BackgroundImage = Gui.Image("MapsAndBG/MapsIcon/battlefield_map_lv1.dds", Vector4(0, 0, 0, 0)),
									},
									Gui.Control "c_win"
									{
										Size = Vector2(50, 50),
										Location = Vector2(0, 0),
										BackgroundColor = ARGB(255, 255, 255, 255),
										Skin = Gui.ControlSkin
										{
											BackgroundImage = Gui.Image("LobbyUI/team/NewFight/summary_win_logo.dds", Vector4(0, 0, 0, 0)),
										},	
									},									
								},
								Gui.Label
								{
									Size = Vector2(100, 20),
									Location = Vector2(192, 39),
									Text = lang:GetText("比分"),
									BackgroundColor = ARGB(0, 255, 255, 255),
									TextAlign = "kAlignLeftMiddle",
									FontSize = 20,
									TextColor = ARGB(255, 255, 103, 1),
								},
								Gui.Control
								{
									Size = Vector2(104, 71),
									Location = Vector2(171, 72),
									BackgroundColor = ARGB(255, 255, 255, 255),
									Skin = Gui.ControlSkin
									{
										BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_vs_ico_02.dds", Vector4(0, 0, 0, 0)),
									},	
								},
								Gui.Label "l_date"
								{
									Size = Vector2(170, 20),
									Location = Vector2(280, 10),
									Text = "2012/12/21 12:25",
									BackgroundColor = ARGB(0, 255, 255, 255),
									TextAlign = "kAlignLeftMiddle",
									FontSize = 16,
									TextColor = ARGB(255, 214, 253, 255),
								},	
								Gui.Label "l_match"
								{
									Size = Vector2(170, 20),
									Location = Vector2(280, 40),
									Text = "100:99",
									BackgroundColor = ARGB(0, 255, 255, 255),
									TextAlign = "kAlignLeftMiddle",
									FontSize = 16,
									TextColor = ARGB(255, 255, 187, 0),
								},
								
								Gui.Label ("l_id_"..index)
								{
									Size = Vector2(0.1, 0.1),
									Location = Vector2(1280, 1140),
									Text = "0",
								},
								
								Gui.Label ("l_name_"..index)
								{
									Size = Vector2(0.1, 0.1),
									Location = Vector2(1280, 1140),
									Text = "0",
								},
								
								Gui.Label "l_vs"
								{
									Size = Vector2(200, 20),
									Location = Vector2(252, 84),
									Text = lang:GetText("大冲锋"),
									BackgroundColor = ARGB(0, 255, 255, 255),
									TextAlign = "kAlignCenterMiddle",
									FontSize = 16,
									TextColor = ARGB(255, 255, 187, 0),
								},
								
								Gui.Button
								{
									Size = Vector2(28, 28),
									Location = Vector2(410, 111),
									BackgroundColor = ARGB(255, 255, 255, 255),
									Skin = Gui.ButtonSkin
									{
										BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_v2_04_normal.dds", Vector4(0, 0, 0, 0)),
										HoverImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_v2_04_hover.dds", Vector4(0, 0, 0, 0)),
										DownImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_v2_04_down.dds", Vector4(0, 0, 0, 0)),
										DisabledImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_v2_04_disabled.dds", Vector4(0, 0, 0, 0)),
									},	
									EventClick = function(sender, e)
										local id = ptr_cast(sender.Parent:GetChildByIndex(6))
										FillT_Info(tonumber(id.Text))
										local name = ptr_cast(sender.Parent:GetChildByIndex(7))
										lead_name = name.Text
									end
								},
							}
						}
	return NewZhanJiIcon
end

function SpawnNewBuff(buff_id,index)
	local NewBuff = Gui.Create(gui) {
							Gui.Control "c_buff"
							{
								Size = Vector2(82, 168),
								BackgroundColor = ARGB(0, 255, 255, 255),
								Gui.Control "buff_pic_back"
								{
									Size = Vector2(80, 80),
									Location = Vector2(1, 0),
									BackgroundColor = ARGB(255, 255, 255, 255),
									Skin = Gui.ControlSkin
									{
										BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_synthesis_common_slot_disabled.dds", Vector4(0, 0, 0, 0)),
									},
									
									Gui.ItemBoxBtn "buff_pic"
									{
										Style = "Gui.ItemBoxBtn_ib",
										Size = Vector2(88, 88),
										Location = Vector2(-4, -9),
										BackgroundColor = ARGB(255, 255, 255, 255),
										--LoadingImage = Gui.AnimatedImage("LobbyUI/loading_ring.tga", 4, 2, 8),
										Skin = Gui.ItemBoxBtnSkin
										{
											NeutralNormalImage = nil,
											NeutralDisabledImage = nil,
										},
										EventMouseEnter = function(sender, e)
											L_ToolTips.FillToolTipsVIPPresent(index, team_ui.root, items)
										end,
										EventToolTipsShow = function(sender, e)
											if items[index] then
												local loc = sender.Location + sender.Parent.Location + sender.Parent.Parent.Location + sender.Parent.Parent.Parent.Location
												+sender.Parent.Parent.Parent.Parent.Location+sender.Parent.Parent.Parent.Parent.Parent.Location
												+sender.Parent.Parent.Parent.Parent.Parent.Parent.Location+sender.Parent.Parent.Parent.Parent.Parent.Parent.Parent.Location
												+sender.Parent.Parent.Parent.Parent.Parent.Parent.Parent.Parent.Location+sender.Parent.Parent.Parent.Parent.Parent.Parent.Parent.Parent.Parent.Location
												+sender.Parent.Parent.Parent.Parent.Parent.Parent.Parent.Parent.Parent.Parent.Location 
												- Vector2(0,team_ui.scroll_buff.VscrollBarValue)
												L_ToolTips.ShowToolTipsShowWindow(sender,Vector2(1116, 586), loc)
											end
										end,
										EventMouseLeave = function(sender, e)
											L_ToolTips.HideToolTipsWindow()
										end,
									},
									
									Gui.Control "lock_buff_state"
									{
										Size = Vector2(24, 24),
										Location = Vector2(56, 0),
										BackgroundColor = ARGB(255, 255, 255, 255),
										Enable = false,
										Visible = false,
										Skin = Gui.ControlSkin
										{
											BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_status_ico_1.dds", Vector4(0, 0, 0, 0)),
										},
									},
									
									Gui.Label "l_tips"
									{
										Size = Vector2(35, 18),
										Location = Vector2(38, 54),
										Text = "",
										BackgroundColor = ARGB(0, 255, 255, 255),
										TextAlign = "kAlignCenterMiddle",
										FontSize = 12,
										TextColor = ARGB(255, 255, 255, 255),
									},
									
									Gui.Control "lock_buff"
									{
										Size = Vector2(80, 80),
										Location = Vector2(0, 0),
										BackgroundColor = ARGB(255, 255, 255, 255),
										Enable = false,
										Skin = Gui.ControlSkin
										{
											BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_synthesis_weijiesuo.dds", Vector4(0, 0, 0, 0)),
										},
									},
								},
								
								Gui.Label "l_state_black"
								{
									Size = Vector2(82, 50),
									Location = Vector2(1, 78),
									Text = "",
									BackgroundColor = ARGB(0, 255, 255, 255),
									TextAlign = "kAlignCenterTop",
									FontSize = 14,
									TextColor = ARGB(255, 0, 0, 0),
								},
								Gui.Label "l_state"
								{
									Size = Vector2(82, 50),
									Location = Vector2(0, 77),
									Text = "",
									BackgroundColor = ARGB(0, 255, 255, 255),
									TextAlign = "kAlignCenterTop",
									FontSize = 14,
									TextColor = ARGB(255, 214, 253, 255),
								},
								
								Gui.Button "b_lock"
								{
									Size = Vector2(78, 50),
									Location = Vector2(3, 87),
									BackgroundColor = ARGB(255, 255, 255, 255),
									TextColor = ARGB(255, 255, 201, 0),
									Padding = Vector4(0, 0, 0, 5),
									FontSize = 16,
									TextAlign = "kAlignCenterMiddle",
									Skin = Gui.ButtonSkin
									{
										BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_v2_01_normal.dds", Vector4(0, 0, 0, 0)),
										HoverImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_v2_01_hover.dds", Vector4(0, 0, 0, 0)),
										DownImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_v2_01_down.dds", Vector4(0, 0, 0, 0)),
										DisabledImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_v2_01_disabled.dds", Vector4(0, 0, 0, 0)),
									},									
									EventClick = function(Sender,e)
										rpc.safecallload("team_buff_op", {tid = t_id, ptid = pt_id,action = 2,teambuffid = buff_id},
										function(data)
											if data.error == nil then
												MessageBox.ShowWithConfirm(Sender.Text..lang:GetText("成功"))
												FillBuffList()
											else
												MessageBox.ShowWithConfirm(data.error)
											end
										end)
									end
								},
								
								Gui.Label "l_usetime_black"
								{
									Size = Vector2(78, 35),
									Location = Vector2(4, 103),
									Text = "",
									BackgroundColor = ARGB(0, 255, 255, 255),
									TextAlign = "kAlignCenterMiddle",
									FontSize = 16,
									TextColor = ARGB(255, 0, 0, 0),
								},
								Gui.Label "l_usetime"
								{
									Size = Vector2(78, 35),
									Location = Vector2(3, 102),
									Text = "",
									BackgroundColor = ARGB(0, 255, 255, 255),
									TextAlign = "kAlignCenterMiddle",
									FontSize = 16,
									TextColor = ARGB(255, 214, 253, 255),
								},
								
								Gui.Control "c_xunzhang"
								{
									Size = Vector2(20, 26),
									Location = Vector2(6, 142),
									BackgroundColor = ARGB(255, 255, 255, 255),
									Skin = Gui.ControlSkin
									{
										BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_ico_cb.dds", Vector4(0, 0, 0, 0)),
									},
								},
								Gui.Label "xunzhang_black"
								{
									Size = Vector2(87, 30),
									Location = Vector2(11, 141),
									BackgroundColor = ARGB(0, 255, 255, 255),
									TextAlign = "kAlignCenterMiddle",
									Text = "300",
									FontSize = 16,
									TextColor = ARGB(255, 0, 0, 0),
								},
								Gui.Label "xunzhang"
								{
									Size = Vector2(87, 30),
									Location = Vector2(10, 140),
									BackgroundColor = ARGB(0, 255, 255, 255),
									TextAlign = "kAlignCenterMiddle",
									Text = "300",
									FontSize = 16,
									TextColor = ARGB(255, 214, 253, 255),
								},
							}	
						}
	return NewBuff
end

local request_list =
{
	Gui.Control "root"
	{
		Size = Vector2(1200, 900),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/lb_common_black_bg.dds", Vector4(0, 0, 0, 0)),
		},
		Gui.Control "register"
		{
			Size = Vector2(700, 594),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Dock = "kDockCenter",
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_contact_bg1_01.dds", Vector4(163,163,53,53)),
			},
			Gui.Control
			{
				Size = Vector2(658, 502),
				Location = Vector2(20, 69),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_contact_bg2.dds", Vector4(38, 41, 38, 66)),	
				},
				Gui.Control 
				{		
					Location = Vector2(10, 10),
					Size = Vector2(638, 435),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg3.dds", Vector4(22, 22, 22, 22)),
					},
					Gui.ListTreeView "p_reques"
					{
						ItemHeight = 34,
						Location = Vector2(16, 18),
						Size = Vector2(640, 365),
						BackgroundColor = ARGB(255, 255, 255, 255),
						AlwaysSelect = true,
						HeaderVisible = true,
						HScrollBarDisplay = "kHide",
						VScrollBarDisplay = "kHide",
						TreeVisible = false,
						CheckIndex = 0,
						HeaderHeight = 30,
						Style = "Gui.ListTreeViewWith_VScroll",
					},
				},
								
				Gui.Button "m_Left"
				{	
					Size = Vector2(72, 32),
					Visible = true,
					Location = Vector2(188,396),
					TextColor = ARGB(255, 209, 227, 221),
					Text = lang:GetText("上一页"),
					
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_page_normal.dds", Vector4(5, 5, 10, 5)),
						HoverImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_page_hover.dds", Vector4(5, 5, 10, 5)),
						DownImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_page_down.dds", Vector4(5, 5, 10, 5)),
						DisabledImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_page_bg.dds", Vector4(5, 5, 10, 5)),
					},
					EventClick = function()
						if request_page ~= 1 then
							request_page = request_page - 1
							FillRequestList()
						end
					end
				},
				
				Gui.Button "m_Right"
				{
					Size = Vector2(72, 32),
					Visible = true,
					Location = Vector2(425,396),
					TextColor = ARGB(255, 209, 227, 221),
					Text = lang:GetText("下一页"),
					
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_page_normal.dds", Vector4(5, 5, 10, 5)),
						HoverImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_page_hover.dds", Vector4(5, 5, 10, 5)),
						DownImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_page_down.dds", Vector4(5, 5, 10, 5)),
						DisabledImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_page_bg.dds", Vector4(5, 5, 10, 5)),
					},
					EventClick = function()
						if request_page ~= request_pages then
							request_page = request_page + 1
							FillRequestList()
						end
					end
				},
				
				Gui.Button "m_PageDisplay"
				{
					Size = Vector2(145,31),
					FontSize = 24,
					Visible = true,
					Location = Vector2(268,396),
					TextColor = ARGB(255, 37, 37, 37),
					HighlightTextColor = ARGB(255, 37, 37, 37),
					TextAlign = "kAlignCenterMiddle",
					Text = "1/1",
					BackgroundColor = ARGB(255, 255, 255, 255),
					
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/lb_common_fanye_down.tga", Vector4(5, 5, 10, 5)),
						--HoverImage = Gui.Image("LobbyUI/team/lb_common_fanye_down.tga", Vector4(5, 5, 10, 5)),
						--DownImage = Gui.Image("LobbyUI/team/lb_common_fanye_down.tga", Vector4(5, 5, 10, 5)),
						DisabledImage = Gui.Image("LobbyUI/team/lb_common_fanye_down.tga", Vector4(5, 5, 10, 5)),
					},
				},
				
				Gui.Button "select_all"
				{
					Size = Vector2(164,44),
					Location = Vector2(11, 451),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Text = lang:GetText("全选当前页"),
					TextColor = ARGB(255, 226, 217, 208),
					TextAlign = "kAlignCenterMiddle",
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_normal.dds", Vector4(32, 0, 32, 0)),
						HoverImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_hover.dds", Vector4(32, 0, 32, 0)),
						DownImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_down.dds", Vector4(32, 0, 32, 0)),
						DisabledImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_disabled.dds", Vector4(32, 0, 32, 0)),
					},
				
					EventClick = function()
						AllSelectRequest(request_list_ui.p_reques)
					end
				},
				Gui.Button "delete_all"
				{
					Size = Vector2(144,44),
					Location = Vector2(179, 451),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Text = lang:GetText("清空列表"),
					TextColor = ARGB(255, 226, 217, 208),
					TextAlign = "kAlignCenterMiddle",
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_normal.dds", Vector4(32, 0, 32, 0)),
						HoverImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_hover.dds", Vector4(32, 0, 32, 0)),
						DownImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_down.dds", Vector4(32, 0, 32, 0)),
						DisabledImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_disabled.dds", Vector4(0, 32, 32, 0)),
					},
				
					EventClick = function()
						rpc.safecallload("team_request_op",{tid = t_id, pids = -1, pid = ptr_cast(game.CurrentState):GetCharacterId(), action = "reject", job = 4},
						function(data)
						end)
						-- if request_list_ui then
							-- request_list_ui.Close()
							-- request_list_ui = nil
						-- end
						-- FillRequestList()
						FillTeam(true)
					end
				},
				Gui.Button "b_delete"
				{
					Size = Vector2(144,44),
					Location = Vector2(327, 451),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Text = lang:GetText("删除"),
					TextColor = ARGB(255, 226, 217, 208),
					TextAlign = "kAlignCenterMiddle",
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_normal.dds", Vector4(32, 0, 32, 0)),
						HoverImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_hover.dds", Vector4(32, 0, 32, 0)),
						DownImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_down.dds", Vector4(32, 0, 32, 0)),
						DisabledImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_disabled.dds", Vector4(32, 0, 32, 0)),
					},
				
					EventClick = function()
						if GetSelected(request_list_ui.p_reques) == "" then
							MessageBox.ShowWithTimer(1,lang:GetText("请选择一名玩家"))
							return
						end
						rpc.safecallload("team_request_op",{tid = t_id, pids = GetSelected(request_list_ui.p_reques), pid = ptr_cast(game.CurrentState):GetCharacterId(), action = "reject", job = 4},
						function(data)
						end)
						-- if request_list_ui then
							-- request_list_ui.Close()
							-- request_list_ui = nil
						-- end
						-- FillRequestList()
						FillTeam(true)
					end
				},
				Gui.Button "b_allow"
				{
					Size = Vector2(164,44),
					Location = Vector2(474, 451),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Text = lang:GetText("批准加入"),
					TextColor = ARGB(255, 226, 217, 208),
					TextAlign = "kAlignCenterMiddle",
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_normal.dds", Vector4(32, 0, 32, 0)),
						HoverImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_hover.dds", Vector4(32, 0, 32, 0)),
						DownImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_down.dds", Vector4(32, 0, 32, 0)),
						DisabledImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_disabled.dds", Vector4(32, 0, 32, 0)),
					},
				
					EventClick = function()
						if GetSelected(request_list_ui.p_reques) == "" then
							MessageBox.ShowWithTimer(1,lang:GetText("请选择一名玩家"))
							return
						end
						rpc.safecallload("team_request_op",{tid = t_id, pids = GetSelected(request_list_ui.p_reques), pid = ptr_cast(game.CurrentState):GetCharacterId(), action = "approve", job = 4},
						function(data)
							if data.fail.size[1] ~= nil or data.fail.expire[1] ~= nil then
								MessageBox.ShowWithTimer(1,lang:GetText("该战队申请已被处理"))
							elseif data.success[1] ~= nil then
								MessageBox.ShowWithTimer(1,lang:GetText("选中的玩家已加入你的战队"))
							end
						end)

						-- if request_list_ui then
							-- request_list_ui.Close()
							-- request_list_ui = nil
						-- end
						-- FillRequestList()
						FillTeam(true)
						L_Friends.GetTeamInfo()
					end
				},
			},
			Gui.Label "t1"
			{
				Size = Vector2(700, 20),
				Location = Vector2(0, 16),
				TextColor = ARGB(255, 255, 255, 255),
				FontSize = 20,
				TextAlign = "kAlignCenterMiddle",
			},
			Gui.Label "t2"
			{
				Size = Vector2(700, 20),
				Location = Vector2(0, 42),
				TextColor = ARGB(255, 255, 255, 255),
				FontSize = 20,
				TextAlign = "kAlignCenterMiddle",
			},
			Gui.Button "btn_Chat_ManyPeople_Exit"
			{
				Size = Vector2(48,48),
				Location = Vector2(646, 5),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_normal.dds", Vector4(10, 10, 10, 10)),
					HoverImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_hover.dds", Vector4(10, 10, 10, 10)),
					DownImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_down.dds", Vector4(10, 10, 10, 10)),
					DisabledImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_disabled.dds", Vector4(0, 0, 0, 0)),	
				},
				EventClick = function()
					if request_list_ui then
						request_list_ui.root.Parent = nil
					end
				end
			},
		},
	},
}

team_ui = Gui.Create()
{
	Gui.Control "root"
	{
		Size = Vector2(1116, 586),
		Location = Vector2(19, 25),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/lb_shop_bg2.dds", Vector4(10, 10, 10, 10)),
		}, 
		
		Gui.TimeControl "FightTimer"
		{
			Size = Vector2(5,5),
			Dock = "kDockCenter",
			BackgroundColor = ARGB(0, 255, 255, 255),
			EventTimeOut = function(sender, e)
				team_ui.begin_fight.Enable = true
			end
		},
		Gui.TimeControl "SourceTimer"
		{
			Size = Vector2(5,5),
			Dock = "kDockCenter",
			BackgroundColor = ARGB(0, 255, 255, 255),
			EventTimeOut = function(sender, e)
				pipeiTimes = pipeiTimes + 1
				BeginSourcePipei(false)
			end
		},
		Gui.TimeControl "SourceStartTimer"
		{
			Size = Vector2(5,5),
			Dock = "kDockCenter",
			BackgroundColor = ARGB(0, 255, 255, 255),
			EventTimeOut = function(sender, e)
				source_start_time = source_start_time - 1
				if source_start_time < 2 then
					source_success_ui.back_btn.Enable = false
					source_success_ui.b_source_pi.Enable = false
				end
				if source_start_time < 0 then
					if SourceFightType == 0 then
						rpc.safecall("handle_battlefield_battle", {tid = source_defance_tid,t = 1,pnames = GetMySourceMember(source_fight_ui.Fight_Team_Room_Player),config = map_config,canRobRes = canRobUnuseRes},
						function(data)
							if not data.error then
								team_ui.SourceBeginGame:CleanAll()
								team_ui.SourceBeginGame:AddTime(10)
								state:RequestTDData(battleFieldId,teamSpaceLevel,canRobUnuseRes,data.bfstartpre)
								source_time_ui.l_text.Text = lang:GetText("正在开始游戏......")
								source_time_ui.b_exit.Visible = false
								ShowSource_Time()
							end	
						end)
					elseif SourceFightType == 1 then
						rpc.safecall("battlefield_challenge", {lpid = ptr_cast(game.CurrentState):GetCharacterId(),dtid= source_defance_tid, pnames = GetMySourceMember(source_fight_ui.Fight_Team_Room_Player),config = map_config,canRobRes = canRobUnuseRes},
						function(data)
							if data.result == true then
								team_ui.SourceStartTimer:CleanAll()
								team_ui.SourceBeginGame:CleanAll()
								team_ui.SourceBeginGame:AddTime(10)
								state:RequestTDData(battleFieldId,teamSpaceLevel,canRobUnuseRes,"")
								source_time_ui.l_text.Text = lang:GetText("正在开始游戏......")
								source_time_ui.b_exit.Visible = false
								ShowSource_Time()
							else
								L_FightTeam.create_source_room_option = nil
								MessageBox.ShowWithConfirm(lang:GetText("挑战失败"))
								HideSource_Success()
								team_ui.SourceStartTimer:CleanAll()
								local state = ptr_cast(game.CurrentState)
								if state then
									state.source_is_create = false
									for i = 2 , 16 do
										state:ChangeSlotStatus(i,0)
									end
									state:LeaveChannel()
								end
							end
						end)
					end
				else
					team_ui.SourceStartTimer:CleanAll()
					team_ui.SourceStartTimer:AddTime(1)
					local Control = ptr_cast(source_success_ui.time:GetChildByIndex(4))
					Control.Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_number_01.dds", Vector4(0, 0, 0, 0), Vector4((source_start_time%10 / 10), 0, (source_start_time%10 / 10) + 0.1, 1)),
					}
					Control = ptr_cast(source_success_ui.time:GetChildByIndex(3))
					Control.Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_number_01.dds", Vector4(0, 0, 0, 0), Vector4((math.floor(source_start_time / 10) / 10), 0, (math.floor(source_start_time / 10) / 10) + 0.1, 1)),
					}
				end
			end
		},
		Gui.TimeControl "SourceBeginGame"
		{
			Size = Vector2(5,5),
			Dock = "kDockCenter",
			BackgroundColor = ARGB(0, 255, 255, 255),
			EventTimeOut = function(sender, e)
				rpc.safecall("push_battlefield_defense_invite", {atid = t_id,dtid = source_defance_tid,serverid = game.ClientAddress.server_id,channelid = game.ClientAddress.channel_id,roomid = game.ClientAddress.room_id,roompwd = create_source_room_option.password,restype = SourceFightType,config = map_config,robres = canRobUnuseRes,atknum = source_roomnum},
				function(data)
				end)
				state.source_is_create = false
				-- HideSource_Success()
				-- HideSource_Time()
				create_source_room_option = nil
				-- MessageBox.ShowWaiter(lang:GetText("正在开始游戏,请稍候..."))					
				state:StartGame()
			end
		},
		
		Gui.Control "image"
		{
			Size = Vector2(1101, 551),
			Location = Vector2(9, 34),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/team/lb_shop_daoju_bg.tga", Vector4(22, 22, 22, 22)),
			},
		},
		Gui.Control "my_team"
		{
			Visible = false,
			Dock = "kDockFill",
			BackgroundColor = ARGB(0, 255, 255, 255),
			Gui.Control "no_team"
			{
				Visible = false,
				Dock = "kDockFill",
				BackgroundColor = ARGB(0, 255, 255, 255),
				Gui.Control
				{
					Size = Vector2(538, 488),
					Location = Vector2(26, 81),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_v2_bg_011.dds", Vector4(0, 0, 0, 0)),
					},
					
					Gui.Control
					{
						Size = Vector2(456, 352),
						Location = Vector2(50, 64),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_v2_bg_02.dds", Vector4(0, 0, 0, 0)),
						},
					},

					Gui.Control
					{
						Size = Vector2(324, 60),
						Location = Vector2(80, 64),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_title_02.dds", Vector4(0, 0, 0, 0)),
						},
					},
					
					-- Gui.RichEdit "re_msg_1"
					-- {
						-- Size = Vector2(350, 50),
						-- Location = Vector2(112, 261),
						-- FontSize = 24,
						-- BackgroundColor = ARGB(0, 255, 255, 255),
						-- TextAlign = "kAlignCenterMiddle",
					-- },
					
					-- Gui.RichEdit "re_msg_2"
					-- {
						-- Size = Vector2(350, 50),
						-- Location = Vector2(132, 298),
						-- FontSize = 18,
						-- BackgroundColor = ARGB(0, 255, 255, 255),
					-- },
					Gui.Label "re_msg_1"
					{
						Size = Vector2(538, 60),
						Location = Vector2(0, 251),
						FontSize = 24,
						BackgroundColor = ARGB(0, 255, 255, 255),
						Text = lang:GetText("达到20级的玩家\n可以创建战队"),
						TextColor = ARGB(255, 255, 187, 0),
						TextAlign = "kAlignCenterMiddle",
					},
					
					Gui.Label "re_msg_2"
					{
						Size = Vector2(538, 50),
						Location = Vector2(0, 298),
						FontSize = 24,
						BackgroundColor = ARGB(0, 255, 255, 255),
						Text = lang:GetText("创建战队需要消耗10000C币能量"),
						TextColor = ARGB(255, 255, 187, 0),
						TextAlign = "kAlignCenterMiddle",
					},
					
					Gui.Button 
					{
						Size = Vector2(248, 56),
						Location = Vector2(139, 363),
						Text = lang:GetText("创建战队"),
						TextColor = ARGB(255, 30, 29, 29),
						HighlightTextColor = ARGB(255, 30, 29, 29),
						TextAlign = "kAlignCenterMiddle",
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_task_button_receive_normal.dds", Vector4(0, 0, 0, 0)),
							HoverImage = Gui.Image("LobbyUI/team/NewFight/lb_task_button_receive_hover.dds", Vector4(0, 0, 0, 0)),
							DownImage = Gui.Image("LobbyUI/team/NewFight/lb_task_button_receive_down.dds", Vector4(0, 0, 0, 0)),
							DisabledImage = Gui.Image("LobbyUI/team/NewFight/lb_task_button_receive_disabled.dds", Vector4(0, 0, 0, 0)),
						},
						EventClick = function()
							if L_LobbyMain.PersonalInfo_data.level < 20 then
								MessageBox.ShowWithConfirm(lang:GetText("您的等级不够20，不能创建！"))
							elseif L_LobbyMain.PersonalInfo_data.newGP < 10000 then
								MessageBox.ShowWithConfirm(lang:GetText("您的C币不够10000，不能创建！"))
							else
								register_team_ui = ModalWindow.GetNew()
								register_team_ui.root.Size = Vector2(605, 676)
								register_team_ui.AllowEscToExit = false
								register_team.root.Parent = register_team_ui.root
								register_team.team_name.Enable = true
								register_team.team_name.Skin = Gui.TextboxSkin{BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_contact_bg_normal.dds", Vector4(10, 10, 10, 10)),}
								register_team.province.Enable = true
								register_team.city.Enable = true
								register_team.abcd.Visible = true
								-- register_team.geshu.Visible = true
								register_team.team_name.Text = ""
								register_team.description.Text = ""
								register_team.b_create.Text = lang:GetText("创建")
								team_create_data.playerItemId = 0
								local cbx = register_team.rank
								cbx:RemoveAll()
								for i = 1, 50  do 
									cbx:AddItem( i )
								end
								cbx = register_team.province
								cbx:RemoveAll()
								for _,v in ipairs(province) do
									cbx:AddItem( v )
								end
								cbx.SelectedIndex = 0
								register_team.rank.Text = 1
								Gui.Align(register_team.register, 0.5, 0.5)
								selsect_image_id = 1
								image_id = 1
								Image_team.ib_image:AllPictureHL(false)
								register_team.zhandui_touxiang.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/team/FightHead/lb_squad_touxiang_1.dds",Vector4(0,0,0,0)),}
							end
						end
					},
				},
				Gui.Control
				{
					Size = Vector2(538, 488),
					Location = Vector2(554, 81),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_v2_bg_011.dds", Vector4(0, 0, 0, 0)),
					},
					
					Gui.Control
					{
						Size = Vector2(456, 352),
						Location = Vector2(50, 64),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_v2_bg_02.dds", Vector4(0, 0, 0, 0)),
						},
					},
					
					Gui.Control
					{
						Size = Vector2(324, 60),
						Location = Vector2(80, 64),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_title_01.dds", Vector4(0, 0, 0, 0)),
						},
					},
					Gui.Label
					{
						Size = Vector2(538, 70),
						Location = Vector2(0, 261),
						Text = lang:GetText("在战队列表中搜索战队加入"),
						BackgroundColor = ARGB(0, 255, 255, 255),
						FontSize = 30,
						TextColor = ARGB(255, 255, 187, 0),
						TextAlign = "kAlignCenterMiddle",
					},
					Gui.Button 
					{
						Size = Vector2(248, 56),
						Location = Vector2(139, 363),
						Text = lang:GetText("战队列表"),
						TextColor = ARGB(255, 30, 29, 29),
						HighlightTextColor = ARGB(255, 30, 29, 29),
						TextAlign = "kAlignCenterMiddle",
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_task_button_receive_normal.dds", Vector4(0, 0, 0, 0)),
							HoverImage = Gui.Image("LobbyUI/team/NewFight/lb_task_button_receive_hover.dds", Vector4(0, 0, 0, 0)),
							DownImage = Gui.Image("LobbyUI/team/NewFight/lb_task_button_receive_down.dds", Vector4(0, 0, 0, 0)),
							DisabledImage = Gui.Image("LobbyUI/team/NewFight/lb_task_button_receive_disabled.dds", Vector4(0, 0, 0, 0)),
						},
						EventClick = function()
							rank_select_page = 1
							team_list_type = 1
							default_mode = 1
							team_ui.btn_list.PushDown = true
							team_ui.btn_my.PushDown = false
							team_list_ui.root.Visible = true
							team_ui.my_team.Visible = false
							mode = 2
							L_LobbyMain.LobbyMainWin.LobbyMainWin_Header_Team.Visible = false
							L_LobbyMain.LobbyMainWin.lb_Announcement.Size = Vector2(390, 35)
							L_LobbyMain.LobbyMainWin.lb_Announcement.Location = Vector2(483, 180)
							Set_type_btn()
						end
					},
				},
			},
			Gui.Control "exist_team"
			{
				Dock = "kDockFill",
				--Visible = false,
				BackgroundColor = ARGB(0, 255, 255, 255),
				Gui.Control "team_info"
				{
					Size = Vector2(1083, 535),
					Location = Vector2(18, 100),
					BackgroundColor = ARGB(0, 255, 255, 255),
					Gui.Control
					{
						Size = Vector2(1083, 405),
						Location = Vector2(0, 0),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg3.dds", Vector4(22, 22, 22, 22)),
						},
					},
					Gui.Control
					{
						Size = Vector2(538, 182),
						Location = Vector2(15, 15),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_task_bg_6.dds", Vector4(12, 10, 42, 40)),
						},
						Gui.Control "team_image"
						{
							Size = Vector2(85, 88),
							Location = Vector2(14, 19),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_touxiang.dds", Vector4(0, 0, 0, 0)),
							},
						},
						Gui.Label
						{
							Size = Vector2(300, 30),
							Location = Vector2(108, 10),
							Text = lang:GetText("战队名称:"),
							FontSize = 18,
							TextColor = ARGB(255, 0, 0, 0),
							TextAlign = "kAlignLeftMiddle",
						},
						Gui.Label
						{
							Size = Vector2(300, 30),
							Location = Vector2(107, 9),
							Text = lang:GetText("战队名称:"),
							FontSize = 18,
							TextColor = ARGB(255, 255, 103, 1),
							TextAlign = "kAlignLeftMiddle",
						},
						Gui.Label "team_name_black"
						{
							Size = Vector2(280, 30),
							Location = Vector2(330, 9),
							Text = "",
							FontSize = 18,
							TextColor = ARGB(255, 0, 0, 0),
							TextAlign = "kAlignLeftMiddle",
						},
						Gui.Label "team_name"
						{
							Size = Vector2(280, 30),
							Location = Vector2(329, 8),
							Text = "",
							FontSize = 18,
							TextColor = ARGB(255, 255, 187, 0),
							TextAlign = "kAlignLeftMiddle",
						},
						Gui.Label
						{
							Size = Vector2(300, 30),
							Location = Vector2(108, 40),
							Text = lang:GetText("战队等级:"),
							FontSize = 18,
							TextColor = ARGB(255, 0, 0, 0),
							TextAlign = "kAlignLeftMiddle",
						},
						Gui.Label
						{
							Size = Vector2(300, 30),
							Location = Vector2(107, 39),
							Text = lang:GetText("战队等级:"),
							FontSize = 18,
							TextColor = ARGB(255, 255, 103, 1),
							TextAlign = "kAlignLeftMiddle",
						},
						Gui.Label "team_level_black"
						{
							Size = Vector2(30, 30),
							Location = Vector2(330, 39),
							Text = "",
							FontSize = 18,
							TextColor = ARGB(255, 0, 0, 0),
							TextAlign = "kAlignLeftMiddle",
						},
						Gui.Label "team_level"
						{
							Size = Vector2(30, 30),
							Location = Vector2(329, 38),
							Text = "",
							FontSize = 18,
							TextColor = ARGB(255, 255, 187, 0),
							TextAlign = "kAlignLeftMiddle",
						},
						Gui.Control "exp_back"
						{
							Size = Vector2(145, 19),
							Location = Vector2(375,47),
							BackgroundColor = ARGB(255, 255, 255, 255),
							-- Visible = false,
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_melting_bar01_bg.dds", Vector4(5, 5, 5, 5)),
							},
							Gui.Control "exp_font"
							{
								Size = Vector2(145, 19),
								Location = Vector2(0, 0),
								BackgroundColor = ARGB(255, 255, 255, 255),
								Skin = Gui.ControlSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_melting_bar01_content.dds", Vector4(5, 5, 5, 5)),
								},
							},
							Gui.Label "team_exp"
							{
								Size = Vector2(145, 19),
								Location = Vector2(0, 0),
								Text = "1/1",
								FontSize = 14,
								TextColor = ARGB(255, 214, 253, 255),
								TextAlign = "kAlignCenterMiddle",
							},
						},
						-- Gui.Label
						-- {
							-- Size = Vector2(150, 22),
							-- Location = Vector2(329, 104),
							-- Text = lang:GetText("战绩排名:"),
							-- FontSize = 20,
							-- TextColor = ARGB(255, 0, 0, 0),
						-- },
						-- Gui.Label
						-- {
							-- Size = Vector2(150, 22),
							-- Location = Vector2(328, 103),
							-- Text = lang:GetText("战绩排名:"),
							-- FontSize = 20,
							-- TextColor = ARGB(255, 255, 103, 1),
						-- },
						-- Gui.Label "team_num_black"
						-- {
							-- Size = Vector2(150, 22),
							-- Location = Vector2(436, 104),
							-- Text = "",
							-- FontSize = 20,
							-- TextColor = ARGB(255, 0, 0, 0),
						-- },
						-- Gui.Label "team_num"
						-- {
							-- Size = Vector2(150, 22),
							-- Location = Vector2(435, 103),
							-- Text = "",
							-- FontSize = 20,
							-- TextColor = ARGB(255, 255, 187, 0),
						-- },
						-- Gui.Control "team_num_up"
						-- {
							-- Size = Vector2(15, 24),
							-- Location = Vector2(500, 106),
							-- BackgroundColor = ARGB(255, 255, 255, 255),
							-- Skin = Gui.ControlSkin
							-- {
								-- BackgroundImage = Gui.Image("LobbyUI/ToolTips/lb_tooltips_jiantou_green.dds", Vector4(0, 0, 0, 0)),
							-- },
						-- },
						-- Gui.Label
						-- {
							-- Size = Vector2(150, 22),
							-- Location = Vector2(329, 144),
							-- Text = lang:GetText("战斗力排名:"),
							-- FontSize = 20,
							-- TextColor = ARGB(255, 0, 0, 0),
							-- Visible = false,
						-- },
						-- Gui.Label
						-- {
							-- Size = Vector2(150, 22),
							-- Location = Vector2(328, 143),
							-- Text = lang:GetText("战斗力排名:"),
							-- FontSize = 20,
							-- TextColor = ARGB(255, 255, 103, 1),
							-- Visible = false,
						-- },
						Gui.Label "team_fightnum_num"
						{
							Size = Vector2(150, 22),
							Location = Vector2(440, 144),
							Text = "",
							FontSize = 20,
							TextColor = ARGB(255, 255, 187, 0),
							Visible = false,
						},
						Gui.Control "team_fightnum_num_up"
						{
							Size = Vector2(15, 24),
							Location = Vector2(500, 144),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/ToolTips/lb_tooltips_jiantou_green.dds", Vector4(0, 0, 0, 0)),
							},
							Visible = false,
						},
						Gui.Label
						{
							Size = Vector2(300, 22),
							Location = Vector2(108, 70),
							Text = lang:GetText("战队胜率:"),
							FontSize = 18,
							TextColor = ARGB(255, 0, 0, 0),
							TextAlign = "kAlignLeftMiddle",
						},
						Gui.Label
						{
							Size = Vector2(300, 22),
							Location = Vector2(107, 69),
							Text = lang:GetText("战队胜率:"),
							FontSize = 18,
							TextColor = ARGB(255, 255, 103, 1),
							TextAlign = "kAlignLeftMiddle",
						},
						Gui.Label "win_percent_black"
						{
							Size = Vector2(150, 22),
							Location = Vector2(330, 69),
							Text = "",
							FontSize = 18,
							TextColor = ARGB(255, 0, 0, 0),
							TextAlign = "kAlignLeftMiddle",
						},
						Gui.Label "win_percent"
						{
							Size = Vector2(150, 22),
							Location = Vector2(329, 68),
							Text = "",
							FontSize = 18,
							TextColor = ARGB(255, 255, 187, 0),
							TextAlign = "kAlignLeftMiddle",
						},
						Gui.Label
						{
							Size = Vector2(300, 22),
							Location = Vector2(108, 98),
							Text = lang:GetText("战队战胜负场次:"),
							FontSize = 18,
							TextColor = ARGB(255, 0, 0, 0),
							TextAlign = "kAlignLeftMiddle",
						},
						Gui.Label
						{
							Size = Vector2(300, 22),
							Location = Vector2(107, 97),
							Text = lang:GetText("战队战胜负场次:"),
							FontSize = 18,
							TextColor = ARGB(255, 255, 103, 1),
							TextAlign = "kAlignLeftMiddle",
						},
						Gui.Label "win_lose_black"
						{
							Size = Vector2(150, 22),
							Location = Vector2(330, 99),
							Text = "",
							FontSize = 18,
							TextColor = ARGB(255, 0, 0, 0),
							TextAlign = "kAlignLeftMiddle",
						},
						Gui.Label "win_lose"
						{
							Size = Vector2(150, 22),
							Location = Vector2(329, 98),
							Text = "",
							FontSize = 18,
							TextColor = ARGB(255, 255, 187, 0),
							TextAlign = "kAlignLeftMiddle",
						},
						Gui.Label
						{
							Size = Vector2(300, 30),
							Location = Vector2(108, 122),
							Text = lang:GetText("战斗力:"),
							FontSize = 18,
							TextColor = ARGB(255, 0, 0, 0),
							TextAlign = "kAlignLeftMiddle",
						},
						Gui.Label
						{
							Size = Vector2(300, 30),
							Location = Vector2(107, 121),
							Text = lang:GetText("战斗力:"),
							FontSize = 18,
							TextColor = ARGB(255, 255, 103, 1),
							TextAlign = "kAlignLeftMiddle",
						},
						Gui.Label "team_fightnum_black"
						{
							Size = Vector2(150, 30),
							Location = Vector2(330, 122),
							Text = "",
							FontSize = 18,
							TextColor = ARGB(255, 0, 0, 0),
							TextAlign = "kAlignLeftMiddle",
						},
						Gui.Label "team_fightnum"
						{
							Size = Vector2(150, 30),
							Location = Vector2(329, 121),
							Text = "",
							FontSize = 18,
							TextColor = ARGB(255, 255, 187, 0),
							TextAlign = "kAlignLeftMiddle",
						},
						Gui.Label
						{
							Size = Vector2(300, 22),
							Location = Vector2(108, 151),
							Text = lang:GetText("战绩排名:"),
							FontSize = 18,
							TextColor = ARGB(255, 0, 0, 0),
							TextAlign = "kAlignLeftMiddle",
						},
						Gui.Label
						{
							Size = Vector2(300, 22),
							Location = Vector2(107, 150),
							Text = lang:GetText("战绩排名:"),
							FontSize = 18,
							TextColor = ARGB(255, 255, 103, 1),
							TextAlign = "kAlignLeftMiddle",
						},
						Gui.Label "team_num_black"
						{
							Size = Vector2(150, 22),
							Location = Vector2(330, 152),
							Text = "",
							FontSize = 18,
							TextColor = ARGB(255, 0, 0, 0),
							TextAlign = "kAlignLeftMiddle",
						},
						Gui.Label "team_num"
						{
							Size = Vector2(150, 22),
							Location = Vector2(329, 151),
							Text = "",
							FontSize = 18,
							TextColor = ARGB(255, 255, 187, 0),
							TextAlign = "kAlignLeftMiddle",
						},
						Gui.Control "team_num_up"
						{
							Size = Vector2(15, 24),
							Location = Vector2(430, 153),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/ToolTips/lb_tooltips_jiantou_green.dds", Vector4(0, 0, 0, 0)),
							},
						},
					},
					Gui.Control
					{
						Size = Vector2(538, 183),
						Location = Vector2(15, 205),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_task_bg_6.dds", Vector4(12, 10, 42, 40)),
						},
						Gui.Label
						{
							Size = Vector2(190, 30),
							Location = Vector2(9, 15),
							Text = lang:GetText("人数:"),
							FontSize = 20,
							TextColor = ARGB(255, 0, 0, 0),
							TextAlign = "kAlignLeftMiddle",
						},
						Gui.Label
						{
							Size = Vector2(190, 30),
							Location = Vector2(8, 14),
							Text = lang:GetText("人数:"),
							FontSize = 20,
							TextColor = ARGB(255, 255, 103, 1),
							TextAlign = "kAlignLeftMiddle",
						},
						Gui.Label "count_person_black"
						{
							Size = Vector2(330, 30),
							Location = Vector2(207, 15),
							Text = "",
							FontSize = 20,
							TextColor = ARGB(255, 0, 0, 0),
							TextAlign = "kAlignLeftMiddle",
						},
						Gui.Label "count_person"
						{
							Size = Vector2(330, 30),
							Location = Vector2(206, 14),
							Text = "",
							FontSize = 20,
							TextColor = ARGB(255, 255, 187, 0),
							TextAlign = "kAlignLeftMiddle",
						},
						Gui.Label
						{
							Size = Vector2(190, 30),
							Location = Vector2(9, 47),
							Text = lang:GetText("队长:"),
							FontSize = 20,
							TextColor = ARGB(255, 0, 0, 0),
							TextAlign = "kAlignLeftMiddle",
						},
						Gui.Label
						{
							Size = Vector2(190, 30),
							Location = Vector2(8, 46),
							Text = lang:GetText("队长:"),
							FontSize = 20,
							TextColor = ARGB(255, 255, 103, 1),
							TextAlign = "kAlignLeftMiddle",
						},
						Gui.Label "lead_black"
						{
							Size = Vector2(330, 30),
							Location = Vector2(207,47),
							Text = "",
							FontSize = 20,
							TextColor = ARGB(255, 0, 0, 0),
							TextAlign = "kAlignLeftMiddle",
						},
						Gui.Label "lead"
						{
							Size = Vector2(330, 30),
							Location = Vector2(207,46),
							Text = "",
							FontSize = 20,
							TextColor = ARGB(255, 255, 187, 0),
							TextAlign = "kAlignLeftMiddle",
						},
						Gui.Label
						{
							Size = Vector2(190, 30),
							Location = Vector2(8, 79),
							Text = lang:GetText("创建日期:"),
							FontSize = 20,
							TextColor = ARGB(255, 0, 0, 0),
							TextAlign = "kAlignLeftMiddle",
						},
						Gui.Label
						{
							Size = Vector2(190, 30),
							Location = Vector2(7, 78),
							Text = lang:GetText("创建日期:"),
							FontSize = 20,
							TextColor = ARGB(255, 255, 103, 1),
							TextAlign = "kAlignLeftMiddle",
						},
						Gui.Label "time_black"
						{
							Size = Vector2(330, 30),
							Location = Vector2(207, 79),
							Text = "",
							FontSize = 20,
							TextColor = ARGB(255, 0, 0, 0),
							TextAlign = "kAlignLeftMiddle",
						},
						Gui.Label "time"
						{
							Size = Vector2(330, 30),
							Location = Vector2(206, 78),
							Text = "",
							FontSize = 20,
							TextColor = ARGB(255, 255, 187, 0),
							TextAlign = "kAlignLeftMiddle",
						},
						Gui.Label
						{
							Size = Vector2(190, 30),
							Location = Vector2(8, 108),
							Text = lang:GetText("地区:"),
							FontSize = 20,
							TextColor = ARGB(255, 0, 0, 0),
							TextAlign = "kAlignLeftMiddle",
						},
						Gui.Label
						{
							Size = Vector2(190, 30),
							Location = Vector2(7, 107),
							Text = lang:GetText("地区:"),
							FontSize = 20,
							TextColor = ARGB(255, 255, 103, 1),
							TextAlign = "kAlignLeftMiddle",
						},
						Gui.Label "address_black"
						{
							Size = Vector2(330, 30),
							Location = Vector2(207, 108),
							Text = "",
							FontSize = 20,
							TextColor = ARGB(255, 0, 0, 0),
							TextAlign = "kAlignLeftMiddle",
						},
						Gui.Label "address"
						{
							Size = Vector2(330, 30),
							Location = Vector2(206, 107),
							Text = "",
							FontSize = 20,
							TextColor = ARGB(255, 255, 187, 0),
							TextAlign = "kAlignLeftMiddle",
						},
						Gui.Label
						{
							Size = Vector2(190, 30),
							Location = Vector2(8, 137),
							Text = lang:GetText("加入条件:"),
							FontSize = 20,
							TextColor = ARGB(255, 0, 0, 0),
							TextAlign = "kAlignLeftMiddle",
						},
						Gui.Label
						{
							Size = Vector2(190, 30),
							Location = Vector2(7, 136),
							Text = lang:GetText("加入条件:"),
							FontSize = 20,
							TextColor = ARGB(255, 255, 103, 1),
							TextAlign = "kAlignLeftMiddle",
						},
						Gui.Label "level_black"
						{
							Size = Vector2(330, 30),
							Location = Vector2(207, 137),
							Text = "",
							FontSize = 20,
							TextColor = ARGB(255, 0, 0, 0),
							TextAlign = "kAlignLeftMiddle",
						},
						Gui.Label "level"
						{
							Size = Vector2(330, 30),
							Location = Vector2(206, 136),
							Text = "",
							FontSize = 20,
							TextColor = ARGB(255, 255, 187, 0),
							TextAlign = "kAlignLeftMiddle",
						},
					},
					Gui.Control
					{
						Size = Vector2(489, 380),
						Location = Vector2(570, 10),
						BackgroundColor = ARGB(0, 255, 255, 255),
						Gui.Button "jieshao_btn"
						{
							Size = Vector2(166, 44),
							Location = Vector2(0, 3),
							Text = lang:GetText("战队介绍"),
							TextAlign = "kAlignCenterMiddle",
							FontSize = 14,
							TextColor = ARGB(255, 148, 115, 78),
							HighlightTextColor = ARGB(255, 255, 205, 69),
							PushDown = true,
							Skin = Gui.ButtonSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_tab_v2_normal.dds", Vector4(0, 0, 0, 0)),
								HoverImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_tab_v2_hover.dds", Vector4(0, 0, 0, 0)),
								DownImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_tab_v2_down.dds", Vector4(0, 0, 0, 0)),
								DisabledImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_tab_v2_normal.dds", Vector4(0, 0, 0, 0)),
							},
							EventClick = function()
								team_ui.c_jieshao.Visible = true
								team_ui.c_zhanji.Visible = false
								team_ui.c_gonggao.Visible = false
								team_ui.jieshao_btn.PushDown = true
								team_ui.zhanji_btn.PushDown = false
								team_ui.gonggao_btn.PushDown = false
								team_ui.new1.Visible = false	
							end
						},
						Gui.Button "zhanji_btn"
						{
							Size = Vector2(166, 44),
							Location = Vector2(160, 3),
							Text = lang:GetText("最近战绩"),
							TextAlign = "kAlignCenterMiddle",
							FontSize = 14,
							TextColor = ARGB(255, 148, 115, 78),
							HighlightTextColor = ARGB(255, 255, 205, 69),
							Skin = Gui.ButtonSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_tab_v2_normal.dds", Vector4(0, 0, 0, 0)),
								HoverImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_tab_v2_hover.dds", Vector4(0, 0, 0, 0)),
								DownImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_tab_v2_down.dds", Vector4(0, 0, 0, 0)),
								DisabledImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_tab_v2_normal.dds", Vector4(0, 0, 0, 0)),
							},
							EventClick = function()
								team_ui.c_jieshao.Visible = false
								team_ui.c_zhanji.Visible = true
								team_ui.c_gonggao.Visible = false
								team_ui.jieshao_btn.PushDown = false
								team_ui.zhanji_btn.PushDown = true
								team_ui.gonggao_btn.PushDown = false
								team_ui.new2.Visible = false	
								FillZhanJi()
							end
						},
						Gui.Button "gonggao_btn"
						{
							Size = Vector2(166, 44),
							Location = Vector2(320, 3),
							Text = lang:GetText("战队公告"),
							TextAlign = "kAlignCenterMiddle",
							FontSize = 14,
							TextColor = ARGB(255, 148, 115, 78),
							HighlightTextColor = ARGB(255, 255, 205, 69),
							Skin = Gui.ButtonSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_tab_v2_normal.dds", Vector4(0, 0, 0, 0)),
								HoverImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_tab_v2_hover.dds", Vector4(0, 0, 0, 0)),
								DownImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_tab_v2_down.dds", Vector4(0, 0, 0, 0)),
								DisabledImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_tab_v2_normal.dds", Vector4(0, 0, 0, 0)),
							},
							EventClick = function()
								team_ui.c_jieshao.Visible = false
								team_ui.c_zhanji.Visible = false
								team_ui.c_gonggao.Visible = true
								team_ui.jieshao_btn.PushDown = false
								team_ui.zhanji_btn.PushDown = false
								team_ui.gonggao_btn.PushDown = true
								team_ui.new3.Visible = false	
								if p_job == 4 or p_job == 3 then
									team_ui.send_btn.Enable = true
								else
									team_ui.send_btn.Enable = false
								end
								team_ui.t_gonggao.Text = ""
								FillGongGao()
							end
						},
						
						Gui.Label "new1"
						{			
							Size = Vector2(32,16),
							-- Location = Vector2(0, 20),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Visible = false,
							UseTimer = false,
							Enable = false,
							NormLocation = Vector2(0, 10),
							MoveLocation = Vector2(0,5),
							MoveWheelTime = 0.6,
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_new_ico.dds", Vector4(0, 0, 0, 0)),
							},
							EventClose = function()
								team_ui.new1.UseTimer = false
							end,
						},
						Gui.Label "new2"
						{			
							Size = Vector2(32,16),
							-- Location = Vector2(0, 20),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Visible = false,
							UseTimer = false,
							Enable = false,
							NormLocation = Vector2(170, 10),
							MoveLocation = Vector2(0,5),
							MoveWheelTime = 0.6,
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_new_ico.dds", Vector4(0, 0, 0, 0)),
							},
							EventClose = function()
								team_ui.new2.UseTimer = false
							end,
						},
						Gui.Label "new3"
						{			
							Size = Vector2(32,16),
							-- Location = Vector2(0, 20),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Visible = false,
							UseTimer = false,
							Enable = false,
							NormLocation = Vector2(340, 10),
							MoveLocation = Vector2(0,5),
							MoveWheelTime = 0.6,
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_new_ico.dds", Vector4(0, 0, 0, 0)),
							},
							EventClose = function()
								team_ui.new3.UseTimer = false
							end,
						},
						
						Gui.Control "c_jieshao"
						{
							Size = Vector2(489, 335),
							Location = Vector2(0, 43),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_task_bg_6.dds", Vector4(12, 10, 42, 40)),
							},
							Gui.Control
							{
								Size = Vector2(448, 287),
								Location = Vector2(15, 21),
								BackgroundColor = ARGB(255, 255, 255, 255),
								Skin = Gui.ControlSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_rank_bg_01.dds", Vector4(34, 34, 34, 34)),
								},
								Gui.Label 
								{
									Size = Vector2(400, 30),
									Location = Vector2(16, 16),
									Text = lang:GetText("战队介绍:"),
									FontSize = 24,
									TextColor = ARGB(255, 0, 0, 0),
									TextAlign = "kAlignLeftMiddle",
								},
								Gui.Label 
								{
									Size = Vector2(400, 30),
									Location = Vector2(15, 15),
									Text = lang:GetText("战队介绍:"),
									FontSize = 24,
									TextColor = ARGB(255, 255, 103, 1),
									TextAlign = "kAlignLeftMiddle",
								},
								Gui.TextArea "jieshao"
								{
									Readonly = true,
									Size = Vector2(463, 300),
									Location = Vector2(15, 49),
									Text = "",
									FontSize = 20,
									Fold = true,
									TextColor = ARGB(255, 255, 187, 0),
									VScrollBarWidth = 40,
									VScrollBarButtonSize = 45,
									Skin = Gui.ScrollableControlSkin
									{
										UpButtonNormalImage = Gui.Image("DefaultSkin/ScrollableControlNew/lb_common_crollbar01_t_normal.tga", Vector4(0, 0, 0, 0)),
										UpButtonHoverImage = Gui.Image("DefaultSkin/ScrollableControlNew/lb_common_crollbar01_t_hover.tga", Vector4(0, 0, 0, 0)),
										UpButtonDownImage = Gui.Image("DefaultSkin/ScrollableControlNew/lb_common_crollbar01_t_down.tga", Vector4(0, 0, 0, 0)),
										UpButtonDisabledImage = nil,

										DownButtonNormalImage = Gui.Image("DefaultSkin/ScrollableControlNew/lb_common_crollbar01_b_normal.tga", Vector4(0, 0, 0, 0)),
										DownButtonHoverImage = Gui.Image("DefaultSkin/ScrollableControlNew/lb_common_crollbar01_b_hover.tga", Vector4(0, 0, 0, 0)),
										DownButtonDownImage = Gui.Image("DefaultSkin/ScrollableControlNew/lb_common_crollbar01_b_down.tga", Vector4(0, 0, 0, 0)),
										DownButtonDisabledImage = nil,

										VSliderNormalImage = Gui.Image("DefaultSkin/ScrollableControlNew/lb_common_scrollbar01_slider_normal.tga", Vector4(0, 14, 0, 14)),
										VSliderHoverImage = Gui.Image("DefaultSkin/ScrollableControlNew/lb_common_scrollbar01_slider_hover.tga", Vector4(0, 14, 0, 14)),
										VSliderDownImage = Gui.Image("DefaultSkin/ScrollableControlNew/lb_common_scrollbar01_slider_down.tga", Vector4(0, 14, 0, 14)),
										VSliderDisabledImage = nil,

										VBarBackgroundImage = Gui.Image("DefaultSkin/ScrollableControlNew/lb_common_scrollbar01_bg.tga", Vector4(0, 55, 0, 55)),
										VBarDisabledBackgroundImage = nil,
										BarCornerImage = nil,
									},
								},
							},
						},
						
						Gui.Control "c_zhanji"
						{
							Size = Vector2(489, 335),
							Location = Vector2(0, 43),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Visible = false,
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_task_bg_6.dds", Vector4(12, 10, 42, 40)),
							},
							Gui.ScrollableControl "scroll_zhanji"
							{
								Size = Vector2(460, 305),
								Location = Vector2(15, 13),
								AutoScroll = true,
								--VScrollBarPos = Vector2(-40,0),
								--Default_Width = 60,
								--Default_Size = 60,
								VScrollBarButtonSize = 16,
								VScrollBarWidth = 16,
								VScrollBarHeight = 290,
								VScrollBarDisplay = true,
								AutoScrollMinSize = Vector2(120,305),
								BackgroundColor = ARGB(255,255,255,255),
								Skin = Gui.ScrollableControlSkin
								{
									UpButtonNormalImage = Gui.Image("LobbyUI/team/NewFight/lb_battlefield_scrollbar_button_01_normal.dds", Vector4(0, 0, 0, 0)),
									UpButtonHoverImage = Gui.Image("LobbyUI/team/NewFight/lb_battlefield_scrollbar_button_01_hover.dds", Vector4(0, 0, 0, 0)),
									UpButtonDownImage = Gui.Image("LobbyUI/team/NewFight/lb_battlefield_scrollbar_button_01_down.dds", Vector4(0, 0, 0, 0)),
									UpButtonDisabledImage = Gui.Image("LobbyUI/team/NewFight/lb_battlefield_scrollbar_button_01_normal.dds", Vector4(0, 0, 0, 0)),

									DownButtonNormalImage = Gui.Image("LobbyUI/team/NewFight/lb_battlefield_scrollbar_button_02_normal.dds", Vector4(0, 0, 0, 0)),
									DownButtonHoverImage = Gui.Image("LobbyUI/team/NewFight/lb_battlefield_scrollbar_button_02_hover.dds", Vector4(0, 0, 0, 0)),
									DownButtonDownImage = Gui.Image("LobbyUI/team/NewFight/lb_battlefield_scrollbar_button_02_down.dds", Vector4(0, 0, 0, 0)),
									DownButtonDisabledImage = Gui.Image("LobbyUI/team/NewFight/lb_battlefield_scrollbar_button_02_normal.dds", Vector4(0, 0, 0, 0)),
									
									VSliderNormalImage = Gui.Image("LobbyUI/team/NewFight/lb_battlefield_scrollbar_button_03_normal.dds", Vector4(3, 4, 5, 5)),
									VSliderHoverImage = Gui.Image("LobbyUI/team/NewFight/lb_battlefield_scrollbar_button_03_hover.dds", Vector4(3, 4, 5, 5)),
									VSliderDownImage = Gui.Image("LobbyUI/team/NewFight/lb_battlefield_scrollbar_button_03_down.dds", Vector4(3, 4, 5, 5)),
									VSliderDisabledImage = Gui.Image("LobbyUI/team/NewFight/lb_battlefield_scrollbar_button_03_normal.dds", Vector4(3, 4, 5, 5)),

									VBarBackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_battlefield_scrollbar_bg.dds", Vector4(3, 4, 5, 5)),
									BarCornerImage = nil,
								},
								
								Gui.FlowLayout "scrollLayout_zhanji"
								{
									AutoSize = true,
									LineSpace = 5,
								},
							},
						},
						
						Gui.Control "c_gonggao"
						{
							Size = Vector2(489, 335),
							Location = Vector2(0, 43),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Visible = false,
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_task_bg_6.dds", Vector4(12, 10, 42, 40)),
							},
							Gui.Label 
							{
								Size = Vector2(300, 37),
								Location = Vector2(16, 14),
								Text = lang:GetText("战队公告:"),
								FontSize = 24,
								TextColor = ARGB(255, 0, 0, 0),
							},
							Gui.Label 
							{
								Size = Vector2(300, 37),
								Location = Vector2(15, 13),
								Text = lang:GetText("战队公告:"),
								FontSize = 24,
								TextColor = ARGB(255, 255, 103, 1),
							},
							
							Gui.Textbox "t_gonggao"
							{
								Size = Vector2(250,37),
								Location = Vector2(175, 13),
								Skin = Gui.ControlSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_rank_bg_01.dds", Vector4(34, 34, 34, 34)),
								},
								Readonly = false,
								TabFocus = true,
								MaxLength = 180,
								TextColor = ARGB(255, 255, 187, 0),
							},
							
							Gui.Button "send_btn"
							{
								Size = Vector2(50, 37),
								Location = Vector2(430, 13),
								Text = lang:GetText("发送"),
								TextAlign = "kAlignCenterMiddle",
								FontSize = 20,
								TextColor = ARGB(255, 0, 0, 0),
								HighlightTextColor = ARGB(255, 0, 0, 0),
								Padding = Vector4(0, 0, 0, 5),
								Skin = Gui.ButtonSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_v2_01_normal.dds", Vector4(0, 0, 0, 0)),
									HoverImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_v2_01_hover.dds", Vector4(0, 0, 0, 0)),
									DownImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_v2_01_down.dds", Vector4(0, 0, 0, 0)),
									DisabledImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_v2_01_disabled.dds", Vector4(0, 0, 0, 0)),
								},
								EventClick = function()
									local gonggao = team_ui.t_gonggao.Text
									if game:TextLenght(gonggao) > 30 or game:TextLenght(gonggao) < 1 then
										MessageBox.ShowWithTimer(2,lang:GetText("字数超出限制！"))
										return
									end
									rpc.safecallload("team_proclamation_create", {pid = ptr_cast(game.CurrentState):GetCharacterId() , ptid = pt_id , tid = t_id , content = gonggao},
									function(data)
										if data.result == 1 then
											MessageBox.ShowWithTimer(2,lang:GetText("发送成功"))											
											-- FillGongGao()	
										else
											MessageBox.ShowWithTimer(2,lang:GetText("发送失败"))			
										end	
									end)
								end
							},
							
							Gui.ScrollableControl "scroll_gonggao"
							{
								Size = Vector2(465, 266),
								Location = Vector2(15, 55),
								AutoScroll = true,
								--VScrollBarPos = Vector2(-40,0),
								--Default_Width = 60,
								--Default_Size = 60,
								VScrollBarButtonSize = 16,
								VScrollBarWidth = 16,
								VScrollBarHeight = 250,
								VScrollBarDisplay = true,
								AutoScrollMinSize = Vector2(120,270),
								BackgroundColor = ARGB(255,255,255,255),
								Skin = Gui.ScrollableControlSkin
								{
									UpButtonNormalImage = Gui.Image("LobbyUI/team/NewFight/lb_battlefield_scrollbar_button_01_normal.dds", Vector4(0, 0, 0, 0)),
									UpButtonHoverImage = Gui.Image("LobbyUI/team/NewFight/lb_battlefield_scrollbar_button_01_hover.dds", Vector4(0, 0, 0, 0)),
									UpButtonDownImage = Gui.Image("LobbyUI/team/NewFight/lb_battlefield_scrollbar_button_01_down.dds", Vector4(0, 0, 0, 0)),
									UpButtonDisabledImage = Gui.Image("LobbyUI/team/NewFight/lb_battlefield_scrollbar_button_01_normal.dds", Vector4(0, 0, 0, 0)),

									DownButtonNormalImage = Gui.Image("LobbyUI/team/NewFight/lb_battlefield_scrollbar_button_02_normal.dds", Vector4(0, 0, 0, 0)),
									DownButtonHoverImage = Gui.Image("LobbyUI/team/NewFight/lb_battlefield_scrollbar_button_02_hover.dds", Vector4(0, 0, 0, 0)),
									DownButtonDownImage = Gui.Image("LobbyUI/team/NewFight/lb_battlefield_scrollbar_button_02_down.dds", Vector4(0, 0, 0, 0)),
									DownButtonDisabledImage = Gui.Image("LobbyUI/team/NewFight/lb_battlefield_scrollbar_button_02_normal.dds", Vector4(0, 0, 0, 0)),
									
									VSliderNormalImage = Gui.Image("LobbyUI/team/NewFight/lb_battlefield_scrollbar_button_03_normal.dds", Vector4(3, 4, 5, 5)),
									VSliderHoverImage = Gui.Image("LobbyUI/team/NewFight/lb_battlefield_scrollbar_button_03_hover.dds", Vector4(3, 4, 5, 5)),
									VSliderDownImage = Gui.Image("LobbyUI/team/NewFight/lb_battlefield_scrollbar_button_03_down.dds", Vector4(3, 4, 5, 5)),
									VSliderDisabledImage = Gui.Image("LobbyUI/team/NewFight/lb_battlefield_scrollbar_button_03_normal.dds", Vector4(3, 4, 5, 5)),

									VBarBackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_battlefield_scrollbar_bg.dds", Vector4(3, 4, 5, 5)),
									BarCornerImage = nil,
								},
								
								Gui.FlowLayout "scrollLayout_gonggao"
								{
									AutoSize = true,
									LineSpace = 0,
								},
							},
						},
					},
					
					Gui.Control "revise_btn"
					{
						Size = Vector2(71, 70),
						Location = Vector2(240, 405),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Visible = false,
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/lb_common_button_bg01.dds", Vector4(20, 20, 20, 20)),
						},
						Gui.Button
						{
							Size = Vector2(61, 60),
							Location = Vector2(5, 5),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Skin = Gui.ButtonSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_button5_normal.dds", Vector4(0, 0, 0, 0)),
								HoverImage = Gui.Image("LobbyUI/team/lb_squad_button5_hover.dds", Vector4(0, 0, 0, 0)),
								DownImage = Gui.Image("LobbyUI/team/lb_squad_button5_down.dds", Vector4(0, 0, 0, 0)),
								DisabledImage = Gui.Image("LobbyUI/team/lb_squad_button5_disabled.dds", Vector4(0, 0, 0, 0)),
							},
							EventClick = function()
								-- revise_team_ui = ModalWindow.GetNew()
								-- revise_team_ui.root.Size = Vector2(1200, 900)
								-- revise_team_ui.AllowEscToExit = false
								-- revise_team.root.Parent = revise_team_ui.root
								-- Gui.Align(revise_team.xiugai, 0.5,0.5)
								-- local cbx = revise_team.rank
								-- cbx:RemoveAll()
								-- for i = 1, 50  do 
									-- cbx:AddItem( i )
								-- end
								-- cbx.Text = t_rank
								-- revise_team.description.Text = team_description
								register_team_ui = ModalWindow.GetNew()
								register_team_ui.root.Size = Vector2(605, 676)
								register_team_ui.AllowEscToExit = false
								register_team.root.Parent = register_team_ui.root
								register_team.team_name.Text = ""
								register_team.description.Text = ""
								register_team.b_create.Text = lang:GetText("完成")
								team_create_data.playerItemId = 0
								if team_data then
									selsect_image_id = team_data[3]
									image_id = team_data[3]
									print("selsect_image_id:"..selsect_image_id)
									local col
									if selsect_image_id % 4 == 0 then
										col = 4
									else
										col = selsect_image_id % 4
									end
									local row = (selsect_image_id - col) / 4 + 1
									local pic = Image_team.ib_image:GetDisplayPicture(row, col)
									pic.Highlighted = true
									register_team.zhandui_touxiang.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/team/FightHead/lb_squad_touxiang_"..team_data[3]..".dds",Vector4(0,0,0,0)),}
								end
								local cbx = register_team.rank
								cbx:RemoveAll()
								for i = 1, 50  do 
									cbx:AddItem( i )
								end
								register_team.team_name.Enable = false
								register_team.team_name.Skin = Gui.TextboxSkin{BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_contact_bg_disabled.dds", Vector4(10, 10, 10, 10)),}
								register_team.province.Enable = false
								register_team.city.Enable = false
								register_team.abcd.Visible = false
								-- register_team.geshu.Visible = false
								register_team.province.Text = my_battle_province
								register_team.city.Text = my_battle_city
								register_team.team_name.Text = my_battle_name
								register_team.description.Text = team_description
								register_team.rank.Text = t_rank
								-- register_team.rank.Text = 1
								Gui.Align(register_team.register, 0.5, 0.5)
							end
						},
					},
					
					Gui.Control "request"
					{
						Visible = true,
						-- Enable = false,
						Size = Vector2(71, 70),
						Location = Vector2(155, 405),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/lb_common_button_bg01.dds", Vector4(20, 20, 20, 20)),
						},
						Gui.Button "request_btn"
						{
							Size = Vector2(61, 60),
							Location = Vector2(5, 5),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Skin = Gui.ButtonSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/team/lb_team_button01_normal.dds", Vector4(0, 0, 0, 0)),
								HoverImage = Gui.Image("LobbyUI/team/lb_team_button01_hover.dds", Vector4(0, 0, 0, 0)),
								DownImage = Gui.Image("LobbyUI/team/lb_team_button01_down.dds", Vector4(0, 0, 0, 0)),
								DisabledImage = Gui.Image("LobbyUI/team/lb_team_button01_disabled.dds", Vector4(0, 0, 0, 0)),
							},
							EventClick = function()
								if request_list_ui == nil then
									request_list_ui = Gui.Create(gui)(request_list)
								end
								request_list_ui.root.Parent = gui
								Gui.Align(request_list_ui.root, 0.5,0.5)
								request_page = 1
								FillRequestList()
							end,
							
							Gui.Button "request_num_btn"
							{
								Size = Vector2(21, 22),
								Location = Vector2(40, 0),
								BackgroundColor = ARGB(255, 255, 255, 255),
								Skin = Gui.ButtonSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_unviewed_bg.dds", Vector4(0, 0, 0, 0)),
									HoverImage = nil,
									DownImage = nil,
									DisabledImage = nil,
								},
							},
						},
					},
				},
				Gui.Control "team_person_info"
				{
					Size = Vector2(1083, 535),
					Location = Vector2(18, 100),
					BackgroundColor = ARGB(0, 255, 255, 255),
					Gui.Control
					{
						Size = Vector2(1083, 405),
						Location = Vector2(0, 0),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg3.dds", Vector4(22, 22, 22, 22)),
						},
					},
					
					Gui.Control
					{
						Size = Vector2(1063, 375),
						Location = Vector2(10, 10),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/lb_battlefield_serverlist_bg01b.tga", Vector4(7, 42, 7, 8)),
						},
					},
					Gui.ListTreeView "p_info"
					{
						ItemHeight = 33,
						Location = Vector2(10, 18),
						Size = Vector2(1097, 363),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Style = "Gui.ListTreeViewWith_VScroll",
						HScrollBarDisplay = "kHide",
						VScrollBarDisplay = "kHide",
						TreeVisible = false,
						AlwaysSelect = true,
						HeaderHeight = 30,
					},
					Gui.Button
					{
						Size = Vector2(72, 32),
						Location = Vector2(718, 350),
						BackgroundColor = ARGB(255, 255, 255, 255),
						TextColor = ARGB(255, 209, 227, 221),
						Text = lang:GetText("上一页"),
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_page_normal.dds", Vector4(5, 5, 10, 5)),
							HoverImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_page_hover.dds", Vector4(5, 5, 10, 5)),
							DownImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_page_down.dds", Vector4(5, 5, 10, 5)),
							DisabledImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_page_bg.dds", Vector4(5, 5, 10, 5)),
						},
						EventClick = function()
							if t_page ~= 1 then
								t_page = t_page - 1
								FillTeam()
							end
						end
					},
					Gui.Label "page_info"
					{
						Size = Vector2(145,31),
						Location = Vector2(805, 350),
						Text = "1/1",
						FontSize = 24,
						TextAlign = "kAlignCenterMiddle",
						TextColor = ARGB(255, 37, 37, 37),
						HighlightTextColor = ARGB(255, 37, 37, 37),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/team/lb_common_fanye_down.tga", Vector4(5, 5, 10, 5)),
						},
					},
					Gui.Button
					{
						Size = Vector2(72, 32),
						Location = Vector2(965, 350),
						BackgroundColor = ARGB(255, 255, 255, 255),
						TextColor = ARGB(255, 209, 227, 221),
						Text = lang:GetText("下一页"),
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_page_normal.dds", Vector4(5, 5, 10, 5)),
							HoverImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_page_hover.dds", Vector4(5, 5, 10, 5)),
							DownImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_page_down.dds", Vector4(5, 5, 10, 5)),
							DisabledImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_page_bg.dds", Vector4(5, 5, 10, 5)),
						},
						EventClick = function()
							if t_page ~= t_pages then
								t_page = t_page + 1
								FillTeam()
							end
						end
					},
					Gui.Label "l_change_black"
					{
						Size = Vector2(300,30),
						Location = Vector2(11, 421),
						Text = lang:GetText("更改队内等级为："),
						FontSize = 20,
						TextAlign = "kAlignCenterMiddle",
						TextColor = ARGB(255, 0, 0, 0),
					},
					Gui.Label "l_change"
					{
						Size = Vector2(300,30),
						Location = Vector2(10, 420),
						Text = lang:GetText("更改队内等级为："),
						FontSize = 20,
						TextAlign = "kAlignCenterMiddle",
						TextColor = ARGB(255, 255, 103, 1),
					},
					Gui.ComboBox "change_job"
					{
						Skin = Gui.ComboBoxSkin
						{
							ButtonNormalImage= Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_button_normal.dds", Vector4(0, 0, 0, 0)),
							ButtonHoverImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_button_hover.dds", Vector4(0, 0, 0, 0)),
							ButtonDownImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_button_down.dds", Vector4(0, 0, 0, 0)),
							
							TextNormalImage= Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_text.dds", Vector4(6, 0, 0, 0)),
							TextHoverImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_text.dds", Vector4(6, 0, 0, 0)),
							TextDownImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_text.dds", Vector4(6, 0, 0, 0)),
							
						},
						ChildComboListStyle =  "Gui.ChangeJobComboList",
						Size = Vector2(302,37),
						Location = Vector2(300, 420),
						Readonly = true,
						TextColor = ARGB(255, 214, 253, 255),
						MaxLength = 12,
						
						EventItemSelected = function(sender, args)
							local temp_job = 0
							local message = nil
							if team_ui.p_info.SelectedItem ~= nil then
								if sender.SelectedIndex == 0 then
									temp_job = 4
								elseif sender.SelectedIndex == 1 then
									temp_job = 3
								elseif sender.SelectedIndex == 2 then
									temp_job = 1
								end

								if team_ui.p_info.SelectedItem.ID == ptr_cast(game.CurrentState):GetCharacterId() then
									MessageBox.ShowWithTimer(1,lang:GetText("你不能更改自己"))
								else
								
								if temp_job == 4 then
									message = lang:GetText("你要将")..team_ui.p_info.SelectedItem.NAME..lang:GetText("任命为队长吗？\n任命后，你将变成普通队员，确定要这样做吗？")
								elseif temp_job == 3 then
									message = lang:GetText("你要将")..team_ui.p_info.SelectedItem.NAME.."\n"..lang:GetText("任命为管理员吗？")
								else
									message = lang:GetText("你要将")..team_ui.p_info.SelectedItem.NAME.."\n"..lang:GetText("任命为普通队员吗？")
								end
								MessageBox.ShowWithTwoButtons(message,lang:GetText("确认"),lang:GetText("取消"),
									function()
										rpc.safecallload("team_request_op",{tid = t_id, pids = team_ui.p_info.SelectedItem.ID, pid = ptr_cast(game.CurrentState):GetCharacterId(), action = "appoint", job = temp_job},
										function(data)
											MessageBox.ShowWithConfirm(lang:GetText("修改成功"))
											L_Friends.GetTeamInfo()
											FillTeam()
										end)
									end,
									nil
									)
								end	
							else
								MessageBox.ShowWithTimer(2,lang:GetText("请选择一名队员！"))
							end
						end,
					},
				},
				Gui.Control "team_gongxian_info"
				{
					Size = Vector2(1083, 535),
					Location = Vector2(18, 100),
					BackgroundColor = ARGB(0, 255, 255, 255),
					Gui.Control
					{
						Size = Vector2(1083, 405),
						Location = Vector2(0, 0),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg3.dds", Vector4(22, 22, 22, 22)),
						},
						Gui.Control
						{
							Size = Vector2(298, 385),
							Location = Vector2(11, 11),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_task_bg_6.dds", Vector4(12, 10, 42, 40)),
							},
							-- Gui.Label
							-- {
								-- Size = Vector2(150, 30),
								-- Location = Vector2(77, 16),
								-- Text = lang:GetText("战队等级:"),
								-- FontSize = 24,
								-- TextColor = ARGB(255, 0, 0, 0),
							-- },
							-- Gui.Label
							-- {
								-- Size = Vector2(150, 30),
								-- Location = Vector2(76, 15),
								-- Text = lang:GetText("战队等级:"),
								-- FontSize = 24,
								-- TextColor = ARGB(255, 255, 103, 1),
							-- },
							Gui.Label "team_level2_black"
							{
								Size = Vector2(298, 30),
								Location = Vector2(1, 16),
								Text = "Lv",
								FontSize = 24,
								TextColor = ARGB(255, 0, 0, 0),
								TextAlign = "kAlignCenterMiddle",
							},
							Gui.Label "team_level2"
							{
								Size = Vector2(298, 30),
								Location = Vector2(0, 15),
								Text = "Lv",
								FontSize = 24,
								TextColor = ARGB(255, 255, 187, 0),
								TextAlign = "kAlignCenterMiddle",
							},
							Gui.Control "exp_back2"
							{
								Size = Vector2(281, 301),
								Location = Vector2(9, 52),
								BackgroundColor = ARGB(255, 255, 255, 255),
								Skin = Gui.ControlSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_bar01_bg.dds", Vector4(0, 0, 0, 0)),
								},
								Gui.FlashControl "flash_chongneng"
								{
									Text = "chongneng",
									Location = Vector2(-22, -55),
									Size = Vector2(318, 376),
									BackgroundColor = ARGB(255, 255, 255, 255),
								},
								Gui.Control "exp_font2"
								{
									Size = Vector2(72, 200),
									Location = Vector2(104, 28),
									BackgroundColor = ARGB(255, 255, 255, 255),
									Skin = Gui.ControlSkin
									{
										BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_bar01_content.dds", Vector4(0, 0, 0, 0)),
									},
								},
								Gui.Control "exp_full"
								{
									Size = Vector2(72, 72),
									Location = Vector2(102, 92),
									BackgroundColor = ARGB(255, 255, 255, 255),
									Skin = Gui.ControlSkin
									{
										BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_max_ico.dds", Vector4(0, 0, 0, 0)),
									},
								},
								Gui.Label "team_exp2"
								{
									Size = Vector2(666, 19),
									Location = Vector2(0, 0),
									Text = "1/1",
									FontSize = 14,
									TextColor = ARGB(255, 214, 253, 255),
									TextAlign = "kAlignCenterMiddle",
									Visible = false,
								},
							},
							Gui.Control
							{
								Size = Vector2(28, 36),
								Location = Vector2(844, 60),
								BackgroundColor = ARGB(255, 255, 255, 255),
								Skin = Gui.ControlSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_xunzhang_ico.dds", Vector4(0, 0, 0, 0)),
								},
								Visible = false,
							},
							Gui.Label
							{
								Size = Vector2(150, 30),
								Location = Vector2(874, 65),
								Text = lang:GetText("勋章库存："),
								FontSize = 20,
								TextColor = ARGB(255, 255, 103, 1),
								Visible = false,
							},
							Gui.Label "xunzhang"
							{
								Size = Vector2(150, 30),
								Location = Vector2(977, 65),
								Text = "300",
								FontSize = 20,
								TextColor = ARGB(255, 255, 187, 0),
								Visible = false,
							},
				
							Gui.Button "chongneng_btn"
							{
								Size = Vector2(288, 54),
								Location = Vector2(1, 302),
								Text = lang:GetText("为战队充能"),
								TextAlign = "kAlignCenterMiddle",
								FontSize = 16,
								Skin = Gui.ButtonSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_power_button_normal.dds", Vector4(72, 0, 72, 0)),
									HoverImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_power_button_hover.dds", Vector4(72, 0, 72, 0)),
									DownImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_power_button_down.dds", Vector4(72, 0, 72, 0)),
									DisabledImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_power_button_disabled.dds", Vector4(72, 0, 72, 0)),	
								},
								EventClick = function()
									RequestQuickBuy()
									ShowQuickBuy()
								end
							},
						},
						Gui.Control
						{
							Size = Vector2(751, 383),
							Location = Vector2(317, 11),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_task_bg_6.dds", Vector4(12, 10, 42, 40)),
							},
							Gui.Control
							{
								Size = Vector2(28, 28),
								Location = Vector2(9, 12),
								BackgroundColor = ARGB(255, 255, 255, 255),
								Skin = Gui.ControlSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_rongyu_ico.dds", Vector4(0, 0, 0, 0)),
								},
							},
							Gui.Label
							{
								Size = Vector2(130, 30),
								Location = Vector2(36, 12),
								Text = lang:GetText("我的贡献值："),
								FontSize = 16,
								TextColor = ARGB(255, 0, 0, 0),
								TextAlign = "kAlignLeftMiddle",
							},
							Gui.Label
							{
								Size = Vector2(130, 30),
								Location = Vector2(35, 11),
								Text = lang:GetText("我的贡献值："),
								FontSize = 16,
								TextColor = ARGB(255, 255, 103, 1),
								TextAlign = "kAlignLeftMiddle",
							},
							Gui.Label "my_gongxian2_black"
							{
								Size = Vector2(150, 30),
								Location = Vector2(171, 12),
								Text = "300",
								FontSize = 16,
								TextColor = ARGB(255, 0, 0, 0),
								TextAlign = "kAlignLeftMiddle",
							},
							Gui.Label "my_gongxian2"
							{
								Size = Vector2(150, 30),
								Location = Vector2(170, 11),
								Text = "300",
								FontSize = 16,
								TextColor = ARGB(255, 255, 187, 0),
								TextAlign = "kAlignLeftMiddle",
							},
							Gui.Label
							{
								Size = Vector2(130, 30),
								Location = Vector2(36, 42),
								Text = lang:GetText("战队补给："),
								FontSize = 16,
								TextColor = ARGB(255, 0, 0, 0),
								TextAlign = "kAlignLeftMiddle",
							},
							Gui.Label
							{
								Size = Vector2(130, 30),
								Location = Vector2(35, 41),
								Text = lang:GetText("战队补给："),
								FontSize = 16,
								TextColor = ARGB(255, 255, 103, 1),
								TextAlign = "kAlignLeftMiddle",
							},
							Gui.Label "zhandui_buji_black"
							{
								Size = Vector2(150, 30),
								Location = Vector2(171, 42),
								Text = "LV20",
								FontSize = 16,
								TextColor = ARGB(255, 0, 0, 0),
								TextAlign = "kAlignLeftMiddle",
							},							
							Gui.Label "zhandui_buji"
							{
								Size = Vector2(150, 30),
								Location = Vector2(170, 41),
								Text = "LV20",
								FontSize = 16,
								TextColor = ARGB(255, 255, 187, 0),
								TextAlign = "kAlignLeftMiddle",
							},
							Gui.Control
							{
								Size = Vector2(494, 69),
								Location = Vector2(239, 7),
								BackgroundColor = ARGB(255, 255, 255, 255),
								Skin = Gui.ControlSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_rank_bg_01.dds", Vector4(34, 34, 34, 34)),
								},
							},
							Gui.Control
							{
								Size = Vector2(28, 28),
								Location = Vector2(251, 12),
								BackgroundColor = ARGB(255, 255, 255, 255),
								Skin = Gui.ControlSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_rongyu_ico.dds", Vector4(0, 0, 0, 0)),
								},
							},
							Gui.Label "l_gongxian_black"
							{
								Size = Vector2(200, 30),
								Location = Vector2(279, 6),
								Text = lang:GetText("需要贡献:"),
								FontSize = 20,
								TextColor = ARGB(255, 0, 0, 0),
								TextAlign = "kAlignLeftMiddle",
							},
							Gui.Label "l_gongxian"
							{
								Size = Vector2(200, 30),
								Location = Vector2(278, 5),
								Text = lang:GetText("需要贡献:"),
								FontSize = 20,
								TextColor = ARGB(255, 255, 103, 1),
								TextAlign = "kAlignLeftMiddle",
							},
							Gui.Label "team_gongxian2_black"
							{
								Size = Vector2(150, 30),
								Location = Vector2(499, 6),
								Text = "300000",
								FontSize = 20,
								TextColor = ARGB(255, 0, 0, 0),
							},
							Gui.Label "team_gongxian2"
							{
								Size = Vector2(150, 30),
								Location = Vector2(498, 5),
								Text = "300000",
								FontSize = 20,
								TextColor = ARGB(255, 255, 187, 0),
							},
							-- Gui.Control
							-- {
								-- Size = Vector2(33, 27),
								-- Location = Vector2(525, 11),
								-- BackgroundColor = ARGB(255, 255, 255, 255),
								-- Skin = Gui.ControlSkin
								-- {
									-- BackgroundImage = Gui.Image("LobbyUI/team/NewFight/mokuai_title02.dds", Vector4(0, 0, 0, 0)),
								-- },
							-- },
							Gui.Label "l_text_black"
							{
								Size = Vector2(400, 40),
								Location = Vector2(279, 33),
								Text = lang:GetText("战队等级达到20级，并由队长解锁补给"),
								FontSize = 16,
								TextColor = ARGB(255, 0, 0, 0),
								TextAlign = "kAlignLeftMiddle",
							},
							Gui.Label "l_text"
							{
								Size = Vector2(400, 40),
								Location = Vector2(278, 32),
								Text = lang:GetText("战队等级达到20级，并由队长解锁补给"),
								FontSize = 16,
								TextColor = ARGB(255, 214, 253, 255),
								TextAlign = "kAlignLeftMiddle",
							},
							Gui.Button "jiesuo_btn"
							{
								Size = Vector2(50, 43),
								Location = Vector2(675, 26),
								-- Text = lang:GetText("解锁"),
								-- TextAlign = "kAlignCenterMiddle",
								-- FontSize = 20,
								-- TextColor = ARGB(255, 0, 0, 0),
								-- HighlightTextColor = ARGB(255, 0, 0, 0),
								blink = false,
								blink_shade = false,
								Skin = Gui.ButtonSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_unlock_normal.dds", Vector4(0, 0, 0, 0)),
									HoverImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_unlock_hover.dds", Vector4(0, 0, 0, 0)),
									DownImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_unlock_down.dds", Vector4(0, 0, 0, 0)),
									DisabledImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_unlock_disabled.dds", Vector4(0, 0, 0, 0)),
									TwinkleImage  = Gui.Image("ui/LobbyUI/team/NewFight/lb_squad_button_unlock_flash.dds", Vector4(0, 0, 0, 0)),
								},								
								EventClick = function()
									if current_level > myteam_level then
										MessageBox.ShowWithConfirm(lang:GetText("战队等级未到,解锁失败"))
									else
										rpc.safecallload("team_buff_op", {tid = t_id, ptid = pt_id,action = 1,teambuffid = current_level},
										function(data)
											if data.error == nil then
												MessageBox.ShowWithConfirm(lang:GetText("解锁成功"))
												FillBuffList()
											else
												MessageBox.ShowWithConfirm(data.error)
											end
										end)
									end
								end
							},
							Gui.Control
							{
								-- Size = Vector2(1018, 195),
								-- Location = Vector2(18, 41),
								Size = Vector2(722, 248),
								Location = Vector2(14, 83),
								BackgroundColor = ARGB(255, 255, 255, 255),
								Skin = Gui.ControlSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_contact_bg_normal.dds", Vector4(5, 5, 5, 5)),
								},
								
								Gui.ScrollableControl "scroll_buff"
								{
									Size = Vector2(722, 248),
									Location = Vector2(0, 0),
									AutoScroll = true,
									--VScrollBarPos = Vector2(-40,0),
									--Default_Width = 60,
									--Default_Size = 60,
									VScrollBarButtonSize = 16,
									VScrollBarWidth = 16,
									-- VScrollBarHeight = 195,
									VScrollBarDisplay = true,
									--AutoScrollMinSize = Vector2(120,195),
									BackgroundColor = ARGB(255,255,255,255),
									Skin = Gui.ScrollableControlSkin
									{
										UpButtonNormalImage = Gui.Image("LobbyUI/team/NewFight/lb_battlefield_scrollbar_button_01_normal.dds", Vector4(0, 0, 0, 0)),
										UpButtonHoverImage = Gui.Image("LobbyUI/team/NewFight/lb_battlefield_scrollbar_button_01_hover.dds", Vector4(0, 0, 0, 0)),
										UpButtonDownImage = Gui.Image("LobbyUI/team/NewFight/lb_battlefield_scrollbar_button_01_down.dds", Vector4(0, 0, 0, 0)),
										UpButtonDisabledImage = Gui.Image("LobbyUI/team/NewFight/lb_battlefield_scrollbar_button_01_normal.dds", Vector4(0, 0, 0, 0)),

										DownButtonNormalImage = Gui.Image("LobbyUI/team/NewFight/lb_battlefield_scrollbar_button_02_normal.dds", Vector4(0, 0, 0, 0)),
										DownButtonHoverImage = Gui.Image("LobbyUI/team/NewFight/lb_battlefield_scrollbar_button_02_hover.dds", Vector4(0, 0, 0, 0)),
										DownButtonDownImage = Gui.Image("LobbyUI/team/NewFight/lb_battlefield_scrollbar_button_02_down.dds", Vector4(0, 0, 0, 0)),
										DownButtonDisabledImage = Gui.Image("LobbyUI/team/NewFight/lb_battlefield_scrollbar_button_02_normal.dds", Vector4(0, 0, 0, 0)),
										
										VSliderNormalImage = Gui.Image("LobbyUI/team/NewFight/lb_battlefield_scrollbar_button_03_normal.dds", Vector4(3, 4, 5, 5)),
										VSliderHoverImage = Gui.Image("LobbyUI/team/NewFight/lb_battlefield_scrollbar_button_03_hover.dds", Vector4(3, 4, 5, 5)),
										VSliderDownImage = Gui.Image("LobbyUI/team/NewFight/lb_battlefield_scrollbar_button_03_down.dds", Vector4(3, 4, 5, 5)),
										VSliderDisabledImage = Gui.Image("LobbyUI/team/NewFight/lb_battlefield_scrollbar_button_03_normal.dds", Vector4(3, 4, 5, 5)),

										VBarBackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_battlefield_scrollbar_bg.dds", Vector4(3, 4, 5, 5)),
										BarCornerImage = nil,
									},
									
									Gui.FlowLayout "scrollLayout_buff"
									{
										-- AutoSize = true,
										Size = Vector2(764, 290),
										Location = Vector2(40,45),
										LineSpace = 45,
										ControlSpace = 10,
										-- Margin = Vector4(41,11,0,0),
									},
								},
							},
							Gui.Button "get_battle_reward"
							{
								Size = Vector2(260, 37),
								Location = Vector2(16,335),
								Text = lang:GetText("领取战队报酬"),
								TextAlign = "kAlignCenterMiddle",
								FontSize = 16,
								TextColor = ARGB(255, 0, 0, 0),
								HighlightTextColor = ARGB(255, 0, 0, 0),
								DisabledTextColor = ARGB(255, 0, 0, 0),
								Padding = Vector4(0, 0, 0, 5),
								Skin = Gui.ButtonSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_v2_01_normal.dds", Vector4(25, 20, 20, 14)),
									HoverImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_v2_01_hover.dds", Vector4(25, 20, 20, 14)),
									DownImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_v2_01_down.dds", Vector4(25, 20, 20, 14)),
									DisabledImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_v2_01_disabled.dds", Vector4(25, 20, 20, 14)),
								},	
								EventClick = function()
									Show_GetBattleGift()
								end
							},
							Gui.Button "m_Left"
							{	
								Size = Vector2(152, 32),
								Visible = true,
								Location = Vector2(400,338),
								TextColor = ARGB(255, 209, 227, 221),
								Text = lang:GetText("上一级"),
								
								Skin = Gui.ButtonSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_page_normal.dds", Vector4(5, 5, 10, 5)),
									HoverImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_page_hover.dds", Vector4(5, 5, 10, 5)),
									DownImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_page_down.dds", Vector4(5, 5, 10, 5)),
									DisabledImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_page_bg.dds", Vector4(5, 5, 10, 5)),
								},
								EventClick = function(Sender,e)
									if current_level > 1 then
										current_level = current_level - 1
										FillBuffList()
									end
								end
							},
							Gui.Button "m_Right"
							{	
								Size = Vector2(152, 32),
								Visible = true,
								Location = Vector2(563,338),
								TextColor = ARGB(255, 209, 227, 221),
								Text = lang:GetText("下一级"),
								
								Skin = Gui.ButtonSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_page_normal.dds", Vector4(5, 5, 10, 5)),
									HoverImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_page_hover.dds", Vector4(5, 5, 10, 5)),
									DownImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_page_down.dds", Vector4(5, 5, 10, 5)),
									DisabledImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_page_bg.dds", Vector4(5, 5, 10, 5)),
								},
								EventClick = function(Sender,e)
									if current_level < 12 then
										current_level = current_level + 1
										FillBuffList()
									end
								end
							},
						},
					},
					Gui.Label ""
					{
						Size = Vector2(500, 60),
						Location = Vector2(10, 410),
						Text = lang:GetText("■ 使用能量块为战队充能\n\n■ 进行游戏（包括战队战）也能为战队充能"),
						FontSize = 16,
						TextColor = ARGB(255, 171, 213, 216),
					},
				},
				
				--基本信息
				Gui.Button "info_btn"
				{
					Size = Vector2(253, 45),
					Location = Vector2(25, 64),
					Text = lang:GetText("基本信息"),
					TextColor = ARGB(255, 217, 209, 201),
					HighlightTextColor = ARGB(255, 217, 209, 201),
					FontSize = 20,
					PushDown = true,
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_normal.dds", Vector4(15, 12, 15, 6)),
						HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_hover.dds", Vector4(15, 12, 15, 6)),
						DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_down.dds", Vector4(15, 12, 15, 6)),
						DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_normal.dds", Vector4(15, 12, 15, 6)),
					},
					EventClick = function()
						my_mode = 1
						team_ui.info_btn.PushDown = true,
						FillTeam()
					end
				},
				Gui.Button "p_btn"
				{
					Size = Vector2(253, 45),
					Location = Vector2(273, 64),
					Text = lang:GetText("战队成员"),
					TextAlign = "kAlignCenterMiddle",
					FontSize = 20,
					TextColor = ARGB(255, 217, 209, 201),
					HighlightTextColor = ARGB(255, 217, 209, 201),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_normal.dds", Vector4(15, 12, 15, 6)),
						HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_hover.dds", Vector4(15, 12, 15, 6)),
						DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_down.dds", Vector4(15, 12, 15, 6)),
						DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_normal.dds", Vector4(15, 12, 15, 6)),
					},
					EventClick = function()
						my_mode = 2
						t_page = 1
						team_ui.p_btn.PushDown = true
						FillTeam()
					end
				},
				Gui.Button "gongxian_btn"
				{
					Size = Vector2(253, 45),
					Location = Vector2(521, 64),
					Text = lang:GetText("战队贡献"),
					TextAlign = "kAlignCenterMiddle",
					FontSize = 20,
					TextColor = ARGB(255, 217, 209, 201),
					HighlightTextColor = ARGB(255, 217, 209, 201),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_normal.dds", Vector4(15, 12, 15, 6)),
						HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_hover.dds", Vector4(15, 12, 15, 6)),
						DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_down.dds", Vector4(15, 12, 15, 6)),
						DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_normal.dds", Vector4(15, 12, 15, 6)),
					},
					EventClick = function()
						my_mode = 3
						team_ui.gongxian_btn.PushDown = true
						FillTeam()
					end
				},
				
				--发起战队战
				Gui.Control
				{
					Size = Vector2(250, 69),
					Location = Vector2(850, 506),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/lb_common_button_bg01.dds", Vector4(20, 20, 20, 20)),
					},
					Gui.Button "begin_fight" 
					{
						Size = Vector2(120, 60),
						Location = Vector2(5, 4),
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_07_normal.dds", Vector4(0, 0, 0, 0)),
							HoverImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_07_hover.dds", Vector4(0, 0, 0, 0)),
							DownImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_07_down.dds", Vector4(0, 0, 0, 0)),
							DisabledImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_07_disabled.dds", Vector4(0, 0, 0, 0)),
						},
						EventClick = function()
							local flag = false
							state = ptr_cast(game.CurrentState)
							for i = 0, state:GetServerCount() - 1 do
								local info = state:GetServerInfo(i,true)
								print("info.isnovice:"..info.isnovice)
								if info.isnovice == 2 and info.online_count/info.online_max < 0.8 then
									-- state:EnterServer(info.id)
									flag = true
									state.is_fight_team_server = true
									state.battle_is_create = true
									team_ui.begin_fight.Enable = false
									team_ui.FightTimer:CleanAll()
									team_ui.FightTimer:AddTime(5)
									state:EnterServer(info.id)
									local randnum = 0
									create_fightteam_room_option = ptr_new ("Client.RoomOption")
									
									create_fightteam_room_option.name = lang:GetText("战队战")
									create_fightteam_room_option.client_count = 12
									create_fightteam_room_option.use_password = true
									create_fightteam_room_option.password = "sdfgde"
									create_fightteam_room_option.character_id = L_WarZone.single_character_id[1]
									create_fightteam_room_option.check_game_balance = false
									create_fightteam_room_option.round_rebirth_time_max = L_WarZone.rebirth_time[3]
									
									
									local cnt = state:GetLevelCount()
									local countnum = 0
									local countnum1 = 0
									for i = 1, cnt do
										local level_info = state:GetLevelInfo(i-1)
										countnum = countnum + level_info.gai_lv
									end
									randnum = math.random(countnum)
									countnum = 0
									for i = 1, cnt do
										local level_info = state:GetLevelInfo(i-1)
										countnum1 = countnum + level_info.gai_lv
										-- print("countnum:"..countnum)
										-- print("randnum:"..randnum)
										-- print("countnum1:"..countnum1)
										if randnum <= countnum1 and randnum > countnum then
											create_fightteam_room_option.game_type = level_info.type
											create_fightteam_room_option.map_name = level_info.name
										end
										countnum = countnum + level_info.gai_lv
									end
									
									-- print("create_fightteam_room_option.game_type:"..create_fightteam_room_option.game_type)
									-- print("create_fightteam_room_option.map_name:"..create_fightteam_room_option.map_name)
									if create_fightteam_room_option.game_type == "kTeam" then
										create_fightteam_room_option.rule_value = L_WarZone.kill_num[2]
									elseif create_fightteam_room_option.game_type == "kHoldPoint" then
										create_fightteam_room_option.rule_value = L_WarZone.common_game_round[2]
									elseif create_fightteam_room_option.game_type == "kPushVehicle" then
										create_fightteam_room_option.rule_value = L_WarZone.common_game_round[2]
									elseif create_fightteam_room_option.game_type == "kTeamDeathMatch" then
										create_fightteam_room_option.rule_value = L_WarZone.kTeamDeathMatch_game_round[2]
									elseif create_fightteam_room_option.game_type == "kBomb" then
										create_fightteam_room_option.rule_value = L_WarZone.bomb_and_hero_round[2]
									elseif create_fightteam_room_option.game_type == "kStreetBoy" then
										create_fightteam_room_option.rule_value = L_WarZone.bomb_and_hero_round[2]
									end
									create_fightteam_room_option.level_id = L_WarZone.map_id[create_fightteam_room_option.game_type][create_fightteam_room_option.map_name]
									print("create_fightteam_room_option.level_id:"..create_fightteam_room_option.level_id)
									create_fightteam_room_option.group_match = true
								end	 
							end
							if not flag then
								MessageBox.ShowWithTimer(3,lang:GetText("战队服务器已满"))
							end
						end
					},
					Gui.Button 
					{
						Size = Vector2(120, 60),
						Location = Vector2(125, 4),
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_06_normal.dds", Vector4(0, 0, 0, 0)),
							HoverImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_06_hover.dds", Vector4(0, 0, 0, 0)),
							DownImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_06_down.dds", Vector4(0, 0, 0, 0)),
							DisabledImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_06_normal.dds", Vector4(0, 0, 0, 0)),
						},
						EventClick = function()
							state = ptr_cast(game.CurrentState)
							
							ShowZhiHuiSuo()
							if team_data then
								state:GetBattleGroups(team_data[2],0+3*three_battle_page,3,0)
							end
						end	
					},
				},
				Gui.Control"quit1_btn"
				{
					Size = Vector2(130, 69),
					Location = Vector2(20, 506),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Visible = true,
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/lb_common_button_bg01.dds", Vector4(20, 20, 20, 20)),
					},
					Gui.Button "quit_btn"
					{
						Size = Vector2(120, 60),
						Location = Vector2(6, 4),
						BackgroundColor = ARGB(255, 255, 255, 255),
						-- Visible = false,
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_button2_normal.dds", Vector4(0, 0, 0, 0)),
							HoverImage = Gui.Image("LobbyUI/team/lb_squad_button2_hover.dds", Vector4(0, 0, 0, 0)),
							DownImage = Gui.Image("LobbyUI/team/lb_squad_button2_down.dds", Vector4(0, 0, 0, 0)),
							DisabledImage = Gui.Image("LobbyUI/team/lb_squad_button2_disabled.dds", Vector4(0, 0, 0, 0)),
						},
						EventClick = function()
							if p_job ~= 4 then
								Show_LeaveBattleWarn()
								-- MessageBox.ShowWithConfirmCancel(lang:GetText("确定要退出战队吗？"),
								-- function(sender,e)
									-- rpc.safecallload("team_request_op",{tid = t_id, pids = ptr_cast(game.CurrentState):GetCharacterId(), pid = ptr_cast(game.CurrentState):GetCharacterId(), action = "quit", job = p_job},
									-- function(data)
										-- MessageBox.ShowWithConfirm(lang:GetText("退出成功"))
										-- L_Friends.GetTeamInfo()
									-- end)
									-- FillTeam()
								-- end)
							else
								if te_num ~= 1 then
									MessageBox.ShowWithConfirm(lang:GetText("当前战队中还有其他成员，你无法解散战队"))
									return
								end
								MessageBox.ShowWithConfirmCancel(lang:GetText("确定要解散战队吗？"),
								function(sender,e)
									rpc.safecallload("team_dismiss",{tid = t_id, pid = ptr_cast(game.CurrentState):GetCharacterId()},
									function(data)
										MessageBox.ShowWithConfirm(lang:GetText("解散成功"))
										L_Friends.GetTeamInfo()
										gui:PlayAudio("kUIA_DISMISS_TEAM")
										allteam_source_ui.allteam.Visible = false
										FillTeam()
									end)
								end)
							end
						end
					},
				},
			},
		},
		Gui.Control
		{
			Visible = false,
			Size = Vector2(648, 70),
			Location = Vector2(281, 2),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab01_bg.dds", Vector4(29, 32, 32, 19)),
			},
			Gui.Button "btn_my"
			{
				Size = Vector2(296, 52),
				Location = Vector2(26 , 7),
				Text = lang:GetText("我的战队"),
				TextColor = ARGB(255, 37, 37, 37),
				HighlightTextColor = ARGB(255, 37, 37, 37),
				FontSize = 24,
				PushDown = true,
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_normal.dds", Vector4(10, 10, 10, 10)),
					HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_hover.dds", Vector4(10, 10, 10, 10)),
					DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_down.dds", Vector4(10, 10, 10, 10)),
					DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_normal.dds", Vector4(10, 10, 10, 10)),
				},
				EventClick = function()
					mode = 1
					FillTeam()
					team_ui.btn_my.PushDown = true
					team_ui.btn_list.PushDown = false
					team_list_ui.root.Visible = false
					team_ui.my_team.Visible = true
				end
			},
			Gui.Button "btn_list"
			{
				Size = Vector2(296, 52),
				Location = Vector2(325, 7),
				Text = lang:GetText("战队列表"),
				TextColor = ARGB(255, 37, 37, 37),
				HighlightTextColor = ARGB(255, 37, 37, 37),
				FontSize = 24,
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_normal.dds", Vector4(10, 10, 10, 10)),
					HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_hover.dds", Vector4(10, 10, 10, 10)),
					DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_down.dds", Vector4(10, 10, 10, 10)),
					DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_normal.dds", Vector4(10, 10, 10, 10)),
				},
				EventClick = function()
					default_mode = 1
					mode = 2
					rank_select_page = 1
					team_list_type = 1
					Set_type_btn()
					FillTeam()
					team_ui.btn_list.PushDown = true
					team_ui.btn_my.PushDown = false
					team_list_ui.root.Visible = true
					team_ui.my_team.Visible = false
					local cbx = team_list_ui.province
					cbx:RemoveAll()
					cbx:AddItem( lang:GetText("全部") )
					for _,v in ipairs(province) do
						cbx:AddItem( v )
					end
					team_list_ui.province.Text = lang:GetText("全部")
					team_list_ui.city.Text = lang:GetText("全部")
				end
			},
		},
		Gui.Button "btn_Close"
		{
			Visible = false,
			Size = Vector2(64, 52),
			Location = Vector2(1049, 3),
			PushDown = false,
			Hint = lang:GetText("关闭战队并返回至战区"),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button01_normal.dds", Vector4(0, 0, 0, 0)),
				HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button01_hover.dds", Vector4(0, 0, 0, 0)),
				DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button01_down.dds", Vector4(0, 0, 0, 0)),
				DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button01_normal.dds", Vector4(0, 0, 0, 0)),
			},

			EventClick = function()
--				L_LobbyMain.HideAll()
				L_WarZone.Show(L_LobbyMain.LobbyMainWin_Boddy.LobbyMainWin_Boddy_Root)
			end
		},
	},
}

team_list_ui = Gui.Create()
{
	Gui.Control "root"
	{
		Visible = false,
		Size = Vector2(1116, 515+71),
		Location = Vector2(0, 0),
		Gui.Control
		{
			Size = Vector2(1116, 515),
			Location = Vector2(0, 71),
			Gui.Label
			{
				Size = Vector2(130, 26),
				Location = Vector2(20, 10),
				Text = lang:GetText("省份："),
				FontSize = 22,
				TextColor = ARGB(255, 255, 103, 1),
				TextAlign = "kAlignRightMiddle",
			},
			Gui.ComboBox "province"
			{
				Size = Vector2(203, 37),
				Location = Vector2(165, 0),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Text = lang:GetText("全部"),
				TextColor = ARGB(255, 255, 187, 0),
				Skin = Gui.ComboBoxSkin
				{
					ButtonNormalImage= Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_button_normal.dds", Vector4(0, 0, 0, 0)),
					ButtonHoverImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_button_hover.dds", Vector4(0, 0, 0, 0)),
					ButtonDownImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_button_down.dds", Vector4(0, 0, 0, 0)),
					
					TextNormalImage= Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_text.dds", Vector4(6, 0, 0, 0)),
					TextHoverImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_text.dds", Vector4(6, 0, 0, 0)),
					TextDownImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_text.dds", Vector4(6, 0, 0, 0)),
					
				},
				ChildComboListStyle =  "Gui.ChangeJobComboList",
				EventValueChanged = function()
					if team_list_ui then
						local cbx
						cbx = team_list_ui.city
						cbx:RemoveAll()
						cbx:AddItem( lang:GetText("全部") )
						if team_list_ui.province.SelectedIndex ~= 0 then
							for _,v in ipairs(city[team_list_ui.province.SelectedIndex]) do
								cbx:AddItem( v )
							end
						end
						team_list_ui.city.Text = lang:GetText("全部")
					end
				end
			},
			Gui.Label
			{
				Size = Vector2(130, 26),
				Location = Vector2(384, 10),
				Text = lang:GetText("城市："),
				FontSize = 22,
				TextColor = ARGB(255, 255, 103, 1),
				TextAlign = "kAlignRightMiddle",
			},
			Gui.ComboBox "city"
			{
				Size = Vector2(203, 37),
				Location = Vector2(519,0),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Text = lang:GetText("全部"),
				TextColor = ARGB(255, 255, 187, 0),
				Skin = Gui.ComboBoxSkin
				{
					ButtonNormalImage= Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_button_normal.dds", Vector4(0, 0, 0, 0)),
					ButtonHoverImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_button_hover.dds", Vector4(0, 0, 0, 0)),
					ButtonDownImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_button_down.dds", Vector4(0, 0, 0, 0)),
					
					TextNormalImage= Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_text.dds", Vector4(6, 0, 0, 0)),
					TextHoverImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_text.dds", Vector4(6, 0, 0, 0)),
					TextDownImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_text.dds", Vector4(6, 0, 0, 0)),
				},
				ChildComboListStyle =  "Gui.ChangeJobComboList",
			},
			Gui.Button
			{
				Size = Vector2(32, 32),
				Location = Vector2(747, 1),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_button_v2_03_normal.dds", Vector4(0, 0, 0, 0)),
					HoverImage = Gui.Image("LobbyUI/team/lb_squad_button_v2_03_hover.dds", Vector4(0, 0, 0, 0)),
					DownImage = Gui.Image("LobbyUI/team/lb_squad_button_v2_03_down.dds", Vector4(0, 0, 0, 0)),
					DisabledImage = Gui.Image("LobbyUI/team/lb_squad_button_v2_03_disabled.dds", Vector4(0, 0, 0, 0)),
				},
				EventClick = function()
					default_mode = -1
					rank_page = 0
					rank_select_page = 1
					if team_list_ui.province.Text == lang:GetText("全部") then
						s_province = ""
					else
						s_province = team_list_ui.province.Text
					end
					if team_list_ui.city.Text == lang:GetText("全部") then
						s_city = ""
					else
						s_city = team_list_ui.city.Text
					end
					s_name = ""
					search_type = 1
					FillTeam()
				end
			},
			
			Gui.Control
			{
				Size = Vector2(1082, 368),
				Location = Vector2(18,66),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg3.dds", Vector4(22, 22, 22, 22)),
				},
				Gui.Label
				{
					Size = Vector2(190, 24),
					Location = Vector2(12,330),
					Text = lang:GetText("跳转至第"),
					TextAlign = "kAlignCenterMiddle",
					FontSize = 18,
					TextColor = ARGB(255, 215, 232, 227),
				},
				Gui.Textbox "tbx_page"
				{
					Size = Vector2(73, 31),
					Location = Vector2(218, 328),
					Text = "",
					TextPadding = Vector4(30, 0, 0, 0),
					FontSize = 20,
					TextColor = ARGB(255, 210, 209, 193),
					InputNumberOnly = true,
					MaxLength = 9,
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/TopList/lb_rank_bg_01.dds", Vector4(0, 0, 0, 0)),
					},
					EventTextChanged = function(Sender,e)
						
					end
				},
				Gui.Button
				{
					Size = Vector2(63, 31),
					Location = Vector2(300, 328),
					Padding = Vector4(0, 0, 0, 4),
					Text = lang:GetText("确定"),
					TextAlign = "kAlignCenterMiddle",
					TextColor = ARGB(255, 31, 31, 31),
					FontSize = 16,
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button04_normal.dds", Vector4(10, 10, 10, 10)),
						HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button04_hover.dds", Vector4(10, 10, 10, 10)),
						DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button04_down.dds", Vector4(10, 10, 10, 10)),
						DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button04_normal.dds", Vector4(10, 10, 10, 10)),
					},
					EventClick = function(Sender,e)
						rank_select_page = tonumber(team_list_ui.tbx_page.Text)
						FillTeam()
					end
				},
				Gui.Button "m_Left"
				{	
					Size = Vector2(14, 33),
					Location = Vector2(800,328),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/lb_shop_button05_normal.dds", Vector4(0, 0, 0, 0)),
						HoverImage = Gui.Image("LobbyUI/lb_shop_button05_hover.dds", Vector4(0, 0, 0, 0)),
						DownImage = Gui.Image("LobbyUI/lb_shop_button05_down.dds", Vector4(0, 0, 0, 0)),
						DisabledImage = Gui.Image("LobbyUI/lb_shop_button05_normal.dds", Vector4(0, 0, 0, 0)),
					},
					EventClick = function(Sender,e)
						if rank_select_page > 1 then
							rank_select_page = rank_select_page - 1
							FillTeam()
						end
					end
				},
				
				Gui.Button "m_Right"
				{
					Size = Vector2(14, 32),
					Location = Vector2(976,328),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/lb_shop_button06_normal.dds", Vector4(0, 0, 0, 0)),
						HoverImage = Gui.Image("LobbyUI/lb_shop_button06_hover.dds", Vector4(0, 0, 0, 0)),
						DownImage = Gui.Image("LobbyUI/lb_shop_button06_down.dds", Vector4(0, 0, 0, 0)),
						DisabledImage = Gui.Image("LobbyUI/lb_shop_button06_normal.dds", Vector4(0, 0, 0, 0)),
					},
					EventClick = function(Sender,e)
						if rank_select_page < rank_select_pages then
							rank_select_page = rank_select_page + 1
							FillTeam()
						end
					end
				},
				
				Gui.Label "m_PageDisplay"
				{
					Size = Vector2(143,33),
					FontSize = 24,
					Location = Vector2(826,328),
					TextColor = ARGB(255, 37, 37, 37),
					HighlightTextColor = ARGB(255, 37, 37, 37),
					TextAlign = "kAlignCenterMiddle",
					Text = "1/1",
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/lb_common_fanye_down.tga", Vector4(5, 5, 10, 5)),
					},
				},
			},
			Gui.Button "type_btn_1"
			{
				Style = "Gui.Button_type",
				Size = Vector2(180, 42),
				Location = Vector2(34, 34),
				Text = lang:GetText("战绩"),
				FontSize = 16,
				EventClick = function()
					team_list_type = 1
					Set_type_btn()
				end
			},
			Gui.Button "type_btn_2"
			{
				Style = "Gui.Button_type",
				Size = Vector2(180, 42),
				Location = Vector2(210, 34),
				FontSize = 16,
				Text = lang:GetText("等级"),
				EventClick = function()
					team_list_type = 2
					Set_type_btn()
				end
			},
			Gui.Button "type_btn_3"
			{
				Style = "Gui.Button_type",
				Size = Vector2(180, 42),
				Location = Vector2(386, 34),
				FontSize = 16,
				Text = lang:GetText("热门"),
				EventClick = function()
					team_list_type = 3
					Set_type_btn()
				end
			},
			Gui.Button "type_btn_4"
			{
				Style = "Gui.Button_type",
				Size = Vector2(180, 42),
				Location = Vector2(562, 34),
				FontSize = 16,
				Text = lang:GetText("最新"),
				EventClick = function()
					team_list_type = 4
					Set_type_btn()
				end
			},
			Gui.Control 
			{
				Size = Vector2(1054, 305),
				Location = Vector2(30,83),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/lb_battlefield_serverlist_bg01b.tga", Vector4(7, 42, 7, 8)),
				},
				Gui.ListTreeView "t_list"
				{
					ItemHeight = 33,
					Location = Vector2(0, 10),
					Size = Vector2(1087, 298),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Style = "Gui.ListTreeViewWith_VScroll",
					HScrollBarDisplay = "kHide",
					VScrollBarDisplay = "kHide",
					TreeVisible = false,
					AlwaysSelect = true,
					HeaderHeight = 30,
				},
			},
			
			Gui.Textbox "key"
			{
				Size = Vector2(261, 38),
				Location = Vector2(40, 450),
				TextColor = ARGB(255, 135, 132, 132),
				FontSize = 18,
				Text = lang:GetText("输入你要搜索战队的名称"),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin  = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_contact_bg_normal.dds", Vector4(5, 5, 5, 5)),
				},
				EventLeave = function(sender, e)
					if team_list_ui.key.Text == "" then
						team_list_ui.key.Text = lang:GetText("输入你要搜索战队的名称")
					end
					sender.Skin  = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_contact_bg_normal.dds", Vector4(5, 5, 5, 5)),
					}
				end,
				EventEnter= function(sender, e)
					if team_list_ui.key.Text == lang:GetText("输入你要搜索战队的名称") then
						team_list_ui.key.Text = ""
					end
					sender.Skin  = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_contact_bg_down.dds", Vector4(5, 5, 5, 5)),
					}
				end,
				EventTextChanged = function(sender, e)
					if sender.Text == "" or sender.Text == lang:GetText("输入你要搜索战队的名称") then
						team_list_ui.clear.Visible = false
					else
						team_list_ui.clear.Visible = true
					end
				end,
			},
			
			Gui.Button "clear"
			{
				Visible = false,
				Size = Vector2(20, 20),
				Location = Vector2(272, 459),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_X_ico_normal.dds", Vector4(0, 0, 0, 0)),
					HoverImage = Gui.Image("LobbyUI/team/lb_squad_X_ico_hover.dds", Vector4(0, 0, 0, 0)),
					DownImage = Gui.Image("LobbyUI/team/lb_squad_X_ico_down.dds", Vector4(0, 0, 0, 0)),
					DisabledImage = nil,
				},
				EventClick = function(sender, e)
					sender.Visible = false
					team_list_ui.key.Text = lang:GetText("输入你要搜索战队的名称")
					cbx = team_list_ui.province
					cbx:RemoveAll()
					cbx:AddItem( lang:GetText("全部") )
					for _,v in ipairs(province) do
						cbx:AddItem( v )
					end
					team_list_ui.province.Text = lang:GetText("全部")
					team_list_ui.city.Text = lang:GetText("全部")
					default_mode = -1
					rank_select_page = 1
					s_province = ""
					s_city = ""
					s_name = ""
					search_type = 2
					FillTeam()
				end
			},
			
			Gui.Button
			{
				Size = Vector2(32, 32),
				Location = Vector2(310, 453),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_button_v2_03_normal.dds", Vector4(0, 0, 0, 0)),
					HoverImage = Gui.Image("LobbyUI/team/lb_squad_button_v2_03_hover.dds", Vector4(0, 0, 0, 0)),
					DownImage = Gui.Image("LobbyUI/team/lb_squad_button_v2_03_down.dds", Vector4(0, 0, 0, 0)),
					DisabledImage = Gui.Image("LobbyUI/team/lb_squad_button_v2_03_disabled.dds", Vector4(0, 0, 0, 0)),
				},
				EventClick = function()
					if team_list_ui.key.Text == lang:GetText("输入你要搜索战队的名称") then
						team_list_ui.failed_lab.Location = Vector2(350, 453)
						team_list_ui.failed_lab.Text = lang:GetText("请输入战队名称")
						team_list_ui.failed_lab.Visible = true
						team_list_ui.Event:CleanAll()
						team_list_ui.Event:AddTime(5)
					else
						default_mode = -1
						rank_select_page = 1
						s_province = ""
						s_city = ""
						s_name = team_list_ui.key.Text
						search_type = 2
						FillTeam()
						s_name = ""
					end
				end
			},
			
			Gui.Label "failed_lab"
			{
				Visible = false,
				Size = Vector2(200, 32),
				Location = Vector2(450, 453),
				Text = lang:GetText("搜索失败"),
				FontSize = 20,
				TextColor = ARGB(255, 255, 0, 0),
			},
			
			Gui.Control
			{
				Size = Vector2(130, 69),
				Location = Vector2(654, 433),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/lb_common_button_bg01.dds", Vector4(20, 20, 20, 20)),
				},
				Gui.Button
				{
					Size = Vector2(120, 60),
					Location = Vector2(6, 4),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_button3_normal.dds", Vector4(0, 0, 0, 0)),
						HoverImage = Gui.Image("LobbyUI/team/lb_squad_button3_hover.dds", Vector4(0, 0, 0, 0)),
						DownImage = Gui.Image("LobbyUI/team/lb_squad_button3_down.dds", Vector4(0, 0, 0, 0)),
						DisabledImage = Gui.Image("LobbyUI/team/lb_squad_button3_disabled.dds", Vector4(0, 0, 0, 0)),
					},
					EventClick = function()
						if team_list_ui.t_list.SelectedItem == nil then
							MessageBox.ShowWithConfirm(lang:GetText("请选择一个战队！"))
						else
							FillT_Info(team_list_ui.t_list.SelectedItem.ID)
						end
					end
				},
			},
			Gui.Control
			{
				Size = Vector2(130, 69),
				Location = Vector2(795, 433),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/lb_common_button_bg01.dds", Vector4(20, 20, 20, 20)),
				},
				Gui.Button
				{
					Size = Vector2(120, 60),
					Location = Vector2(6, 4),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_button1_normal.dds", Vector4(0, 0, 0, 0)),
						HoverImage = Gui.Image("LobbyUI/team/lb_squad_button1_hover.dds", Vector4(0, 0, 0, 0)),
						DownImage = Gui.Image("LobbyUI/team/lb_squad_button1_down.dds", Vector4(0, 0, 0, 0)),
						DisabledImage = Gui.Image("LobbyUI/team/lb_squad_button1_disabled.dds", Vector4(0, 0, 0, 0)),
					},
					EventClick = function()
						local list = team_list_ui.t_list
						if list.SelectedItem == nil then
							MessageBox.ShowWithConfirm(lang:GetText("请选择一个战队！"))
						else
							L_LobbyMain.ChatPrivate(lead_name,lead_vip)
						end
					end
				},
			},
			Gui.Control
			{
				Size = Vector2(130, 69),
				Location = Vector2(936, 433),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/lb_common_button_bg01.dds", Vector4(20, 20, 20, 20)),
				},
				Gui.Button
				{
					Size = Vector2(120, 60),
					Location = Vector2(6, 4),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_button4_normal.dds", Vector4(0, 0, 0, 0)),
						HoverImage = Gui.Image("LobbyUI/team/lb_squad_button4_hover.dds", Vector4(0, 0, 0, 0)),
						DownImage = Gui.Image("LobbyUI/team/lb_squad_button4_down.dds", Vector4(0, 0, 0, 0)),
						DisabledImage = Gui.Image("LobbyUI/team/lb_squad_button4_disabled.dds", Vector4(0, 0, 0, 0)),
					},
					EventClick = function()
						local list = team_list_ui.t_list
						if list.SelectedItem == nil then
							MessageBox.ShowWithConfirm(lang:GetText("请选择一个战队！"))
						else
							rpc.safecallload("team_request_op", {tid = list.SelectedItem.ID, pid = ptr_cast(game.CurrentState):GetCharacterId(), pids  = ptr_cast(game.CurrentState):GetCharacterId(), action = "join"},
							function(data)
								MessageBox.ShowWithConfirm(lang:GetText("申请成功！\n（同时申请多个战队时只有最后一次申请有效）"))
							end)
						end
					end
				},
			},
			Gui.TimeControl "Event"
			{
				Size = Vector2(5, 5),
				BackgroundColor = ARGB(0, 255, 255, 255),
				EventTimeOut = function(sender, e)
					team_list_ui.failed_lab.Visible = false
				end
			},
		},
		Gui.Button "btn_Close"
		{
			Size = Vector2(43, 39),
			Location = Vector2(1064, 39),
			PushDown = false,
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button01_small_normal.dds", Vector4(0, 0, 0, 0)),
				HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button01_small_hover.dds", Vector4(0, 0, 0, 0)),
				DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button01_small_down.dds", Vector4(0, 0, 0, 0)),
				DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button01_small_normal.dds", Vector4(0, 0, 0, 0)),
			},

			EventClick = function()
				mode = 1
				-- L_FightTeam.FillTeam()
				L_LobbyMain.LobbyMainWin.btn_my.PushDown = true
				L_LobbyMain.LobbyMainWin.btn_list.PushDown = false
				L_LobbyMain.LobbyMainWin.btn_my.PushDown = false
				L_LobbyMain.LobbyMainWin.btn_sourcefight.PushDown = false
				L_LobbyMain.LobbyMainWin.btn_list.PushDown = false
				
				team_list_ui.root.Visible = false
				team_ui.my_team.Visible = true
				allteam_source_ui.allteam.Visible = false
				my_source_ui.root.Visible = false
			end
		},
	},
}

function create_rank_source_team(index)
	return Gui.Control ("source_tiaozhan_team"..index)
	{
		Size = Vector2(210, 68),
		Location = Vector2(0,0),
		BackgroundColor = ARGB(0, 255, 255, 255),
		Gui.Label ("l_teamname_black"..index)
		{
			Size = Vector2(210, 25),
			Location = Vector2(1, 2),
			BackgroundColor = ARGB(0, 255, 255, 255),
			Text = lang:GetText(""),
			FontSize = 14,
			TextColor = ARGB(255, 0, 0, 0),
			TextAlign = "kAlignCenterMiddle",
			-- HighlightTextColor = ARGB(255, 37, 37, 37),
		},
		Gui.Label ("l_teamname"..index)
		{
			Size = Vector2(210, 25),
			Location = Vector2(0, 0),
			BackgroundColor = ARGB(0, 255, 255, 255),
			Text = lang:GetText(""),
			FontSize = 14,
			TextColor = ARGB(255, 255, 255, 255),
			TextAlign = "kAlignCenterMiddle",
			-- HighlightTextColor = ARGB(255, 37, 37, 37),
		},
		Gui.Control ("b_source_rank"..index)
		{
			Size = Vector2(48, 46),
			Location = Vector2(2, 16),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Visible = false,
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_diyi.dds", Vector4(0, 0, 0, 0)),
			},
		},
		Gui.Button ("b_source_tiaozhan"..index)
		{
			Size = Vector2(105, 28),
			Location = Vector2(52, 24),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Text = lang:GetText("挑战"),
			-- FontSize = 14,
			TextColor = ARGB(255, 0, 0, 0),
			DisabledTextColor = ARGB(255, 0, 0, 0),
			Padding = Vector4(0,0,0,5),
			Enable = false,
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_button8_normal.dds", Vector4(0, 0, 0, 0)),
				HoverImage = Gui.Image("LobbyUI/team/lb_squad_button8_hover.dds", Vector4(0, 0, 0, 0)),
				DownImage = Gui.Image("LobbyUI/team/lb_squad_button8_down.dds", Vector4(0, 0, 0, 0)),
				DisabledImage = Gui.Image("LobbyUI/team/lb_squad_button8_disabled.dds", Vector4(0, 0, 0, 0)),
			},
			EventClick = function()
				if L_LobbyMain.PersonalInfo_data.newCR < tonumber(allteam_source_ui["l_teamFC"..index].Text)then
					MessageBox.ShowWithConfirm(lang:GetText("FC点不足"))
					return
				end
				SourceFightType = 1
				SourceTiaozhanTid = tonumber(allteam_source_ui["l_teamid"..index].Text)
				local flag = false
				state = ptr_cast(game.CurrentState)
				for i = 0, state:GetServerCount() - 1 do
					local info = state:GetServerInfo(i,true)
					print("info.isnovice:"..info.isnovice)
					if info.isnovice == 3 and info.online_count/info.online_max < 0.8 then
						-- state:EnterServer(info.id)
						psd = ""..roompsd[math.random(#roompsd)]..roompsd[math.random(#roompsd)]..roompsd[math.random(#roompsd)]..roompsd[math.random(#roompsd)]..roompsd[math.random(#roompsd)]..roompsd[math.random(#roompsd)]
						flag = true
						state.is_fight_team_server = true
						state.source_is_create = true
						state:EnterServer(info.id)
						create_source_room_option = ptr_new ("Client.RoomOption")
						create_source_room_option.name = lang:GetText("战队战")
						create_source_room_option.client_count = 6
						create_source_room_option.use_password = true
						create_source_room_option.password = psd
						create_source_room_option.character_id = L_WarZone.single_character_id[1]
						create_source_room_option.check_game_balance = false
						create_source_room_option.round_rebirth_time_max = L_WarZone.rebirth_time[3]
						create_source_room_option.game_type = "kTDMode"
						create_source_room_option.map_name = ""
						create_source_room_option.rule_value = 1
						create_source_room_option.level_id = 1
						-- create_fightteam_room_option.group_match = true
					end	 
				end
				if not flag then
					MessageBox.ShowWithTimer(3,lang:GetText("战队服务器已满"))
				end
			end
		},
		Gui.Label ("l_teamlv"..index)
		{
			Size = Vector2(210, 20),
			Location = Vector2(0, 49),
			BackgroundColor = ARGB(0, 255, 255, 255),
			Text = lang:GetText("上周NO："),
			FontSize = 14,
			TextColor = ARGB(255, 255, 255, 255),
			TextAlign = "kAlignCenterMiddle",
			-- HighlightTextColor = ARGB(255, 37, 37, 37),
		},
		Gui.Label ("l_teamid"..index)
		{
			Size = Vector2(1, 1),
			Location = Vector2(0, 0),
			BackgroundColor = ARGB(0, 255, 255, 255),
			Text = 0,
			FontSize = 14,
			TextColor = ARGB(0, 255, 255, 255),
			TextAlign = "kAlignCenterMiddle",
		},
		Gui.Label ("l_teamFC"..index)
		{
			Size = Vector2(1, 1),
			Location = Vector2(0, 0),
			BackgroundColor = ARGB(0, 255, 255, 255),
			Text = 0,
			FontSize = 14,
			TextColor = ARGB(0, 255, 255, 255),
			TextAlign = "kAlignCenterMiddle",
		},
	}
end

--仓库槽位格子
function CreateStorageListGrids(list,line,i)
	return Gui.ItemBoxBtn ("grids_icon"..i)			
	{
		Size = Vector2(92,92),
		Location = Vector2(106*list,112*line),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Empty = false,
		Type = 1,
		Skin = Gui.ItemBoxBtnSkin
		{
			NeutralNormalImage = Gui.Image("LobbyUI/team/lb_squad_1118_normal.dds", Vector4(10, 10, 10, 10)),
			NeutralHoverImage = Gui.Image("LobbyUI/team/lb_squad_1118_hover.dds.dds", Vector4(10, 10, 10, 10)),
			NeutralSelectedImage = Gui.Image("LobbyUI/team/lb_squad_1118_down.dds.dds", Vector4(10, 10, 10, 10)),
			NeutralDisabledImage = Gui.Image("LobbyUI/team/lb_squad_1118_disabled.dds.dds", Vector4(10, 10, 10, 10)),
		},
		Gui.FlowLayout ("grids_num"..i)
		{
			Size = Vector2(92, 16),
			Location = Vector2(0,3),
			Direction = "kHorizontal",
			Align = "kAlignRightMiddle",
			ControlAlign = "kAlignCenterMiddle",
			ControlSpace = -3,
		},
		-- Gui.Label("grids_num"..i)
		-- {
			-- Size = Vector2(0,15),
			-- Dock = "kDockTop",
			-- Margin = Vector4(0,3,0,0),
			-- TextPadding = Vector4(0,0,9,0),
			-- Visible = false,
			-- Enable = false,
			-- Text = "1/10",
			-- TextAlign = "kAlignRight",
			-- FontSize = 14,
			-- TextColor = ARGB(255, 255, 255, 255),
			
		-- },
		Gui.Control ("lv_Towercrtl"..i)
		{
			Size = Vector2(52,16),
			Location = Vector2(37,73),
			BackgroundColor = ARGB(0, 255, 255, 255),
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_bg_02.dds",Vector4(10, 10, 4, 4)),
			},
			Gui.Control("Level_Tower_"..i) 
			{
				Size = Vector2(48,15),
				Location = Vector2(4,1),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Visible = false,			
			},
			
		},
		Gui.Label("gridsLevel"..i)
		{
			Size = Vector2(52,16),
			Location = Vector2(37,73),
			Visible = false,
			Text = "LV 5",
			BackgroundColor = ARGB(255, 255, 255, 255),
			TextAlign = "kAlignCenter",
			FontSize = 12,
			TextColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_bg_02.dds",Vector4(10, 10, 0, 0)),
			},
		},
		
	}				
end
function CreateStorageWallListGrids(list,line,i)
	return Gui.ItemBoxBtn ("gridsWall_icon"..i)			
	{
		Size = Vector2(92,92),
		Location = Vector2(106*list,112*line),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Empty = false,
		Type = 1,
		Skin = Gui.ItemBoxBtnSkin
		{
			NeutralNormalImage = Gui.Image("LobbyUI/team/lb_squad_1118_normal.dds", Vector4(10, 10, 10, 10)),
			NeutralHoverImage = Gui.Image("LobbyUI/team/lb_squad_1118_hover.dds.dds", Vector4(10, 10, 10, 10)),
			NeutralSelectedImage = Gui.Image("LobbyUI/team/lb_squad_1118_down.dds.dds", Vector4(10, 10, 10, 10)),
			NeutralDisabledImage = Gui.Image("LobbyUI/team/lb_squad_1118_disabled.dds.dds", Vector4(10, 10, 10, 10)),
		},
		Gui.FlowLayout ("gridsWall_num"..i)
		{
			Size = Vector2(92, 16),
			Location = Vector2(0,3),
			Direction = "kHorizontal",
			Align = "kAlignRightMiddle",
			ControlAlign = "kAlignCenterMiddle",
			ControlSpace = -3,
		},
		-- Gui.Label("gridsWall_num"..i)
		-- {
			-- Size = Vector2(0,15),
			-- Dock = "kDockTop",
			-- Margin = Vector4(0,3,0,0),
			-- TextPadding = Vector4(0,0,9,0),
			-- Visible = false,
			-- Enable = false,
			-- Text = "1/10",
			-- TextAlign = "kAlignRight",
			-- FontSize = 14,
			-- TextColor = ARGB(255, 255, 255, 255),
			
		-- },
		Gui.Control ("lv_Wallcrtl"..i)
		{
			Size = Vector2(52,16),
			Location = Vector2(37,73),
			BackgroundColor = ARGB(0, 255, 255, 255),
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_bg_02.dds",Vector4(10, 10, 4, 4)),
			},
			Gui.Control("Level_W_"..i) 
			{
				Size = Vector2(48,14),
				Location = Vector2(4,1),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Visible = false,
			},
			
		},
		
	}				
end
function CreateStorageMachineListGrids(list,line,i)
	return Gui.ItemBoxBtn ("gridsMachine_icon"..i)			
	{
		Size = Vector2(92,92),
		Location = Vector2(106*list,112*line),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Empty = false,
		Type = 1,
		Skin = Gui.ItemBoxBtnSkin
		{
			NeutralNormalImage = Gui.Image("LobbyUI/team/lb_squad_1118_normal.dds", Vector4(10, 10, 10, 10)),
			NeutralHoverImage = Gui.Image("LobbyUI/team/lb_squad_1118_hover.dds.dds", Vector4(10, 10, 10, 10)),
			NeutralSelectedImage = Gui.Image("LobbyUI/team/lb_squad_1118_down.dds.dds", Vector4(10, 10, 10, 10)),
			NeutralDisabledImage = Gui.Image("LobbyUI/team/lb_squad_1118_disabled.dds.dds", Vector4(10, 10, 10, 10)),
		},
		Gui.FlowLayout ("gridsMachine_num"..i)
		{
			Size = Vector2(92, 16),
			Location = Vector2(0,3),
			Direction = "kHorizontal",
			Align = "kAlignRightMiddle",
			ControlAlign = "kAlignCenterMiddle",
			ControlSpace = -3,
		},
		-- Gui.Label("gridsMachine_num"..i)
		-- {
			-- Size = Vector2(0,15),
			-- Dock = "kDockTop",
			-- Margin = Vector4(0,3,0,0),
			-- TextPadding = Vector4(0,0,9,0),
			-- Visible = false,
			-- Enable = false,
			-- Text = "1/10",
			-- TextAlign = "kAlignRight",
			-- FontSize = 14,
			-- TextColor = ARGB(255, 255, 255, 255),
			
		-- },
		Gui.Control ("lv_Machinecrtl"..i)
		{
			Size = Vector2(52,16),
			Location = Vector2(37,73),
			BackgroundColor = ARGB(0, 255, 255, 255),
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_bg_02.dds",Vector4(10, 10, 4, 4)),
			},
			Gui.Control("Level_M_"..i)
			{
				Size = Vector2(48,15),
				Location = Vector2(4,1),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Visible = false,				
			},
		},
		
	}				
end
--个人界面仓库槽位坦克格子
function CreatePersonalStorageListGrids(list,line,i)
	return Gui.ItemBoxBtn 			
	{
		Size = Vector2(92,92),
		Location = Vector2(106*list,112*line),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Empty = false,
		Type = 1,
		Skin = Gui.ItemBoxBtnSkin
		{
			NeutralNormalImage = Gui.Image("LobbyUI/team/lb_squad_1118_normal.dds", Vector4(10, 10, 10, 10)),
			NeutralHoverImage = Gui.Image("LobbyUI/team/lb_squad_1118_hover.dds.dds", Vector4(10, 10, 10, 10)),
			NeutralSelectedImage = Gui.Image("LobbyUI/team/lb_squad_1118_down.dds.dds", Vector4(10, 10, 10, 10)),
			NeutralDisabledImage = Gui.Image("LobbyUI/team/lb_squad_1118_disabled.dds.dds", Vector4(10, 10, 10, 10)),
		},
		Gui.FlowLayout ("p_grids_num"..i)
		{
			Size = Vector2(92, 16),
			Location = Vector2(0,3),
			Direction = "kHorizontal",
			Align = "kAlignRightMiddle",
			ControlAlign = "kAlignCenterMiddle",
			ControlSpace = -3,
		},
		-- Gui.Label("p_grids_num"..i)
		-- {
			-- Size = Vector2(0,15),
			-- Dock = "kDockTop",
			-- Margin = Vector4(0,3,0,0),
			-- TextPadding = Vector4(0,0,9,0),
			-- Visible = false,
			-- Enable = false,
			-- Text = "1/10",
			-- TextAlign = "kAlignRight",
			-- FontSize = 14,
			-- TextColor = ARGB(255, 255, 255, 255),
			
		-- },
		Gui.Control ("p_lv_Tankcrtl"..i)
		{
			Size = Vector2(52,16),
			Location = Vector2(37,73),
			BackgroundColor = ARGB(0, 255, 255, 255),
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_bg_02.dds",Vector4(10, 10, 4, 4)),
			},
			Gui.Control ("p_Level_Tank_"..i)
			{
				Size = Vector2(48,15),
				Location = Vector2(4,1),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Visible = false,				
			},

		},
		Gui.Label("p_gridsLevel"..i)
		{
			Size = Vector2(52,16),
			Location = Vector2(37,73),
			Visible = false,
			Text = "LV 5",
			BackgroundColor = ARGB(255, 255, 255, 255),
			TextAlign = "kAlignCenter",
			FontSize = 12,
			TextColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_bg_02.dds",Vector4(10, 10, 0, 0)),
			},
		},
		
	}				
end
--个人界面仓库槽位BUFF格子
function CreatePersonalBuffListGrids(list,line,i)
	return Gui.ItemBoxBtn 			
	{
		Size = Vector2(92,92),
		Location = Vector2(106*list,112*line),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Empty = false,
		Type = 1,
		Skin = Gui.ItemBoxBtnSkin
		{
			NeutralNormalImage = Gui.Image("LobbyUI/team/lb_squad_1118_normal.dds", Vector4(10, 10, 10, 10)),
			NeutralHoverImage = Gui.Image("LobbyUI/team/lb_squad_1118_hover.dds.dds", Vector4(10, 10, 10, 10)),
			NeutralSelectedImage = Gui.Image("LobbyUI/team/lb_squad_1118_down.dds.dds", Vector4(10, 10, 10, 10)),
			NeutralDisabledImage = Gui.Image("LobbyUI/team/lb_squad_1118_disabled.dds.dds", Vector4(10, 10, 10, 10)),
		},
		Gui.FlowLayout ("p_grids_BuffNum"..i)
		{
			Size = Vector2(90, 16),
			Location = Vector2(0,3),
			Direction = "kHorizontal",
			Align = "kAlignRightMiddle",
			ControlAlign = "kAlignCenterMiddle",
			ControlSpace = -3,
		},
		-- Gui.Label("p_grids_BuffNum"..i)
		-- {
			-- Size = Vector2(0,15),
			-- Dock = "kDockTop",
			-- Margin = Vector4(0,3,0,0),
			-- TextPadding = Vector4(0,0,9,0),
			-- Visible = false,
			-- Enable = false,
			-- Text = "1/10",
			-- TextAlign = "kAlignRight",
			-- FontSize = 14,
			-- TextColor = ARGB(255, 255, 255, 255),
			
		-- },
		-- Gui.Control ("p_lv_Buffcrtl"..i)
		-- {
			-- Size = Vector2(52,16),
			-- Location = Vector2(37,73),
			-- BackgroundColor = ARGB(0, 255, 255, 255),
			-- Skin = Gui.ControlSkin
			-- {
				-- BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_bg_02.dds",Vector4(10, 10, 4, 4)),
			-- },
			-- Gui.Control ("p_Level_Buff_"..i)
			-- {
				-- Size = Vector2(48,15),
				-- Location = Vector2(4,1),
				-- BackgroundColor = ARGB(255, 255, 255, 255),
								
			-- },

		-- },
		-- Gui.Label("p_gridsLevel"..i)
		-- {
			-- Size = Vector2(52,16),
			-- Location = Vector2(37,73),
			-- Visible = false,
			-- Text = "LV 5",
			-- BackgroundColor = ARGB(255, 255, 255, 255),
			-- TextAlign = "kAlignCenter",
			-- FontSize = 12,
			-- TextColor = ARGB(255, 255, 255, 255),
			-- Skin = Gui.ControlSkin
			-- {
				-- BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_bg_02.dds",Vector4(10, 10, 0, 0)),
			-- },
		-- },	
	}				
end
--战队天赋树防御塔槽位格子
function CreateTreeListGrids(x,y,i)
	return Gui.ItemBoxBtn ("T_icon"..i)			
	{
		Size = Vector2(59,59),
		Location = Vector2(x,y),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Empty = false,
		Type = 1,
		Skin = Gui.ItemBoxBtnSkin
		{
			NeutralNormalImage = Gui.Image("LobbyUI/team/lb_squad_1118_normal.dds", Vector4(10, 10, 10, 10)),
			NeutralHoverImage = Gui.Image("LobbyUI/team/lb_squad_1118_hover.dds.dds", Vector4(10, 10, 10, 10)),
			NeutralSelectedImage = Gui.Image("LobbyUI/team/lb_squad_1118_down.dds.dds", Vector4(10, 10, 10, 10)),
			NeutralDisabledImage = Gui.Image("LobbyUI/team/lb_squad_1118_disabled.dds.dds", Vector4(10, 10, 10, 10)),
		},
		Gui.Control ("lv_crtl"..i)
		{
			Size = Vector2(38,12),
			Location = Vector2(21,47),
			BackgroundColor = ARGB(0, 255, 255, 255),
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_bg_02.dds",Vector4(10, 10, 4, 4)),
			},
			Gui.Control ("Level_T_"..i)
			{
				Size = Vector2(32,12),
				Location = Vector2(0,0),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Visible = false,			
			},
			
			-- Gui.Label("Level_T_"..i)
			-- {
				-- Size = Vector2(38,12),
				-- Location = Vector2(25,51),
				-- Visible = false,
				-- Text = "LV 5",
				-- BackgroundColor = ARGB(255, 255, 255, 255),
				-- TextAlign = "kAlignCenter",
				-- FontSize = 10,
				-- TextColor = ARGB(255, 255, 255, 255),
				-- Skin = Gui.ControlSkin
				-- {
					-- BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_bg_02.dds",Vector4(10, 10, 4, 4)),
				-- },
			-- },
		},	
	}				
end
--战队天赋树防御墙槽位格子
function CreateTreeWallListGrids(x,y,i)
	return Gui.ItemBoxBtn ("T_W_icon"..i)			
	{
		Size = Vector2(59,59),
		Location = Vector2(x,y),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Empty = false,
		Type = 1,
		Skin = Gui.ItemBoxBtnSkin
		{
			NeutralNormalImage = Gui.Image("LobbyUI/team/lb_squad_1118_normal.dds", Vector4(10, 10, 10, 10)),
			NeutralHoverImage = Gui.Image("LobbyUI/team/lb_squad_1118_hover.dds.dds", Vector4(10, 10, 10, 10)),
			NeutralSelectedImage = Gui.Image("LobbyUI/team/lb_squad_1118_down.dds.dds", Vector4(10, 10, 10, 10)),
			NeutralDisabledImage = Gui.Image("LobbyUI/team/lb_squad_1118_disabled.dds.dds", Vector4(10, 10, 10, 10)),
		},
		Gui.Control ("lv_W_crtl"..i)
		{
			Size = Vector2(38,12),
			Location = Vector2(21,47),
			BackgroundColor = ARGB(0, 255, 255, 255),
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_bg_02.dds",Vector4(10, 10, 4, 4)),
			},
			Gui.Control ("Level_T_W_"..i)
			{
				Size = Vector2(38,12),
				Location = Vector2(0,0),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Visible = false,			
			},
	
		},	
	}				
end
--战队天赋树挖掘机槽位格子
function CreateTreeMachineListGrids(x,y,i)
	return Gui.ItemBoxBtn ("T_M_icon"..i)			
	{
		Size = Vector2(59,59),
		Location = Vector2(x,y),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Empty = false,
		Type = 1,
		Skin = Gui.ItemBoxBtnSkin
		{
			NeutralNormalImage = Gui.Image("LobbyUI/team/lb_squad_1118_normal.dds", Vector4(10, 10, 10, 10)),
			NeutralHoverImage = Gui.Image("LobbyUI/team/lb_squad_1118_hover.dds.dds", Vector4(10, 10, 10, 10)),
			NeutralSelectedImage = Gui.Image("LobbyUI/team/lb_squad_1118_down.dds.dds", Vector4(10, 10, 10, 10)),
			NeutralDisabledImage = Gui.Image("LobbyUI/team/lb_squad_1118_disabled.dds.dds", Vector4(10, 10, 10, 10)),
		},
		Gui.Control ("lv_M_crtl"..i)
		{
			Size = Vector2(38,12),
			Location = Vector2(21,47),
			BackgroundColor = ARGB(0, 255, 255, 255),
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_bg_02.dds",Vector4(10, 10, 4, 4)),
			},
			Gui.Control ("Level_T_M_"..i)
			{
				Size = Vector2(38,12),
				Location = Vector2(0,0),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Visible = false,			
			},
			
		},	
	}				
end
--个人天赋树槽位格子
function CreatePersonalTreeListGrids(x,y,i)
	return Gui.ItemBoxBtn ("P_T_icon"..i)			
	{
		Size = Vector2(59,59),
		Location = Vector2(x,y),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Empty = false,
		Type = 1,
		Skin = Gui.ItemBoxBtnSkin
		{
			NeutralNormalImage = Gui.Image("LobbyUI/team/lb_squad_1118_normal.dds", Vector4(10, 10, 10, 10)),
			NeutralHoverImage = Gui.Image("LobbyUI/team/lb_squad_1118_hover.dds.dds", Vector4(10, 10, 10, 10)),
			NeutralSelectedImage = Gui.Image("LobbyUI/team/lb_squad_1118_down.dds.dds", Vector4(10, 10, 10, 10)),
			NeutralDisabledImage = Gui.Image("LobbyUI/team/lb_squad_1118_disabled.dds.dds", Vector4(10, 10, 10, 10)),
		},
		Gui.Control ("P_lv_crtl"..i)
		{
			Size = Vector2(38,12),
			Location = Vector2(21,47),
			BackgroundColor = ARGB(0, 255, 255, 255),
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_bg_02.dds",Vector4(10, 10, 4, 4)),
			},
			Gui.Control ("P_Level_T_"..i)
			{
				Size = Vector2(38,12),
				Location = Vector2(0,0),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Visible = false,				
			},
		},	
	}				
end

allteam_source_ui = Gui.Create()
{
	Gui.Control "root"
	{
		Size = Vector2(1116, 615),
		Location = Vector2(0, 0),
		BackgroundColor = ARGB(0, 255, 255, 255),
		
		Gui.Control
		{
			Size = Vector2(1057, 469),
			Location = Vector2(30, 100),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg3.dds", Vector4(22, 22, 22, 22)),
			},
			Gui.Control "allteam"
			{
				Size = Vector2(1036, 448),
				Location = Vector2(10, 10),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Visible = false,
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_daditu.dds", Vector4(0, 0, 0, 0)),
				},
				
				-- Gui.Label 
				-- {
					-- Size = Vector2(200, 20),
					-- Location = Vector2(780, 7),
					-- BackgroundColor = ARGB(0, 255, 255, 255),
					-- Text = lang:GetText("资源争夺战"),
					-- FontSize = 14,
					-- TextColor = ARGB(255, 145, 255, 130),
				-- },
				
				Gui.Control
				{
					Size = Vector2(140, 24),
					Location = Vector2(10, 10),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_lingditiaozhan.dds", Vector4(0, 0, 0, 0)),
					},
				},
				Gui.Label "source_start_time"
				{
					Size = Vector2(856, 40),
					Location = Vector2(10, 40),
					BackgroundColor = ARGB(0, 255, 255, 255),
					Text = lang:GetText("开始时间：1990/1/1\n结束时间：1990/1/1"),
					FontSize = 14,
					TextColor = ARGB(255, 255, 210, 0),
					TextAlign = "kAlignLeftMiddle",
				},
				Gui.Label
				{
					Size = Vector2(856, 40),
					Location = Vector2(160, 0),
					BackgroundColor = ARGB(0, 255, 255, 255),
					Text = lang:GetText("小队队长抢夺可获得【个人黑晶石】，队友抢夺可获得【个人原石】。"),
					FontSize = 14,
					TextColor = ARGB(255, 255, 210, 0),
					TextAlign = "kAlignLeftMiddle",
				},
				
				Gui.Label 
				{
				Size = Vector2(200, 46),
				Location = Vector2(10, 70),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Text = lang:GetText("争夺模式"),
				FontSize = 20,
				TextColor = ARGB(255, 255, 210, 0),
				TextAlign = "kAlignLeftMiddle",
				},
				
				Gui.Label 
				{
				Size = Vector2(200, 46),
				Location = Vector2(10, 90),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Text = lang:GetText("开放时间：每日9:00-24:00"),
				FontSize = 14,
				TextColor = ARGB(255, 255, 210, 0),
				TextAlign = "kAlignLeftMiddle",
				},
				
				create_rank_source_team(1),
				create_rank_source_team(2),
				create_rank_source_team(3),
				create_rank_source_team(4),
				create_rank_source_team(5),
				create_rank_source_team(6),
				create_rank_source_team(7),
				create_rank_source_team(8),
				create_rank_source_team(9),
				create_rank_source_team(10),
				create_rank_source_team(11),
				create_rank_source_team(12),
				create_rank_source_team(13),
				create_rank_source_team(14),
				create_rank_source_team(15),		
				
				Gui.Control "c_small"
				{
					Size = Vector2(148, 34),
					Location = Vector2(889, 2),
					BackgroundColor = ARGB(0, 255, 255, 255),
					-- Visible = false,
					Gui.Control
					{
						Size = Vector2(116, 34),--95
						Location = Vector2(0, 0),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_phb03.dds", Vector4(93,0,21,0)),
						},
						Gui.Label
						{
							Size = Vector2(75, 33),
							Location = Vector2(4, 0),
							BackgroundColor = ARGB(0, 255, 255, 255),
							Text = lang:GetText("排名"),
							FontSize = 20,
							TextColor = ARGB(255, 255, 210, 0),
							TextAlign = "kAlignCenterMiddle",
							-- HighlightTextColor = ARGB(255, 37, 37, 37),
						},
					},
					Gui.Button
					{
						Size = Vector2(32, 27),
						Location = Vector2(115, 0),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_jia_normal.dds", Vector4(0, 0, 0, 0)),
							HoverImage = Gui.Image("LobbyUI/team/lb_squad_jia_hover.dds", Vector4(0, 0, 0, 0)),
							DownImage = Gui.Image("LobbyUI/team/lb_squad_jia_down.dds", Vector4(0, 0, 0, 0)),
							DisabledImage = Gui.Image("LobbyUI/team/lb_squad_jia_disabled.dds", Vector4(0, 0, 0, 0)),
						},
						EventClick = function()
									    
							allteam_source_ui.c_small.Visible = false
							allteam_source_ui.c_big.Visible = true
							rpc.safecall("get_curzyzdzrank", {pid = ptr_cast(game.CurrentState):GetCharacterId()},
							function(data)
								FillSourceRank(data.curZYZDZRankList)
							end)
						end
					},
				},
				Gui.Control "c_big"
				{
					Size = Vector2(1036, 448),
					Location = Vector2(0, 0),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Visible = false,
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_phb_bg.dds", Vector4(0,0,0,0)),
					},
					Gui.Control
					{
						Size = Vector2(1004, 33),
						Location = Vector2(2, 2),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_phb03.dds", Vector4(93,0,21,0)),
						},
						Gui.Label
						{
							Size = Vector2(75, 33),
							Location = Vector2(3, 0),
							BackgroundColor = ARGB(0, 255, 255, 255),
							Text = lang:GetText("排名"),
							FontSize = 20,
							TextColor = ARGB(255, 255, 210, 0),
							TextAlign = "kAlignCenterMiddle",
							-- HighlightTextColor = ARGB(255, 37, 37, 37),
						},
						Gui.Label
						{
							Size = Vector2(200, 33),
							Location = Vector2(106, 0),
							BackgroundColor = ARGB(0, 255, 255, 255),
							Text = lang:GetText("战队名称"),
							FontSize = 20,
							TextColor = ARGB(255, 255, 210, 0),
							TextAlign = "kAlignLeftMiddle",
							-- HighlightTextColor = ARGB(255, 37, 37, 37),
						},
						Gui.Label
						{
							Size = Vector2(200, 33),
							Location = Vector2(306, 0),
							BackgroundColor = ARGB(0, 255, 255, 255),
							Text = lang:GetText("空间等级"),
							FontSize = 20,
							TextColor = ARGB(255, 255, 210, 0),
							TextAlign = "kAlignCenterMiddle",
							-- HighlightTextColor = ARGB(255, 37, 37, 37),
						},
						Gui.Label
						{
							Size = Vector2(200, 33),
							Location = Vector2(506, 0),
							BackgroundColor = ARGB(0, 255, 255, 255),
							Text = lang:GetText("抢夺次数"),
							FontSize = 20,
							TextColor = ARGB(255, 255, 210, 0),
							TextAlign = "kAlignCenterMiddle",
							-- HighlightTextColor = ARGB(255, 37, 37, 37),
						},
						Gui.Label
						{
							Size = Vector2(200, 33),
							Location = Vector2(708, 0),
							BackgroundColor = ARGB(0, 255, 255, 255),
							Text = lang:GetText("抢夺资源"),
							FontSize = 20,
							TextColor = ARGB(255, 255, 210, 0),
							TextAlign = "kAlignRightMiddle",
							-- HighlightTextColor = ARGB(255, 37, 37, 37),
						},
					},
					Gui.Button
					{
						Size = Vector2(32, 27),
						Location = Vector2(1004, 2),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_jian_normal.dds", Vector4(0, 0, 0, 0)),
							HoverImage = Gui.Image("LobbyUI/team/lb_squad_jian_hover.dds", Vector4(0, 0, 0, 0)),
							DownImage = Gui.Image("LobbyUI/team/lb_squad_jian_down.dds", Vector4(0, 0, 0, 0)),
							DisabledImage = Gui.Image("LobbyUI/team/lb_squad_jian_disabled.dds", Vector4(0, 0, 0, 0)),
						},
						EventClick = function()
							allteam_source_ui.c_small.Visible = true
							allteam_source_ui.c_big.Visible = false
						end
					},
					Gui.ListTreeView "fight_source_rank"
					{
						ItemHeight = 34,
						Location = Vector2(2, 35),
						Size = Vector2(1034, 339),
						BackgroundColor = ARGB(0, 255, 255, 255),
						Style = "Gui.ListTreeViewWith_VScroll_Source_Rank",
						TextColor = ARGB(255, 0, 0, 0),
						HighlightTextColor = ARGB(255, 255, 255, 255),
						TreeVisible = false,
						AlwaysSelect = false,
						HeaderVisible = false,
						VScrollBarDisplay = "kVisible",
						HScrollBarDisplay = "kHide",
						VScrollBarWidth = 31,
						VScrollBarButtonSize = 1,
						CanKeySelect = false,
						VScrollOffset = 31,
					},
				},
				
				Gui.Control
				{
					Size = Vector2(1027, 68),
					Location = Vector2(5, 379),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_xiamian_bg.dds", Vector4(0, 0, 0, 0)),
					},
					Gui.Control
					{
						Size = Vector2(333, 55),
						Location = Vector2(347, 6),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/team/lb_pipeizhengduomoshi.dds", Vector4(0, 0, 0, 0)),
						},
					},
					Gui.Label "team_prompting"
					{
						Size = Vector2(856, 30),
						Location = Vector2(430,0),
						BackgroundColor = ARGB(0, 255, 255, 255),
						Text = lang:GetText(""),
						FontSize = 16,
						TextColor = ARGB(255, 255, 210, 0),
						TextAlign = "kAlignLeftMiddle",
					},
					
					Gui.Label"team_prompting1" 
					{
						Size = Vector2(856, 30),
						Location = Vector2(430,25),
						BackgroundColor = ARGB(0, 255, 255, 255),
						Text = lang:GetText(""),
						FontSize = 16,
						TextColor = ARGB(255, 255, 210, 0),
						TextAlign = "kAlignLeftMiddle",
					},
					
					Gui.Button
					{
						Size = Vector2(163, 46),
						Location = Vector2(9, 18),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Text = lang:GetText("加入防守"),
						Padding = Vector4(0, 0, 0, 7),
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_button7_normal.dds", Vector4(0, 0, 0, 0)),
							HoverImage = Gui.Image("LobbyUI/team/lb_squad_button7_hover.dds", Vector4(0, 0, 0, 0)),
							DownImage = Gui.Image("LobbyUI/team/lb_squad_button7_down.dds", Vector4(0, 0, 0, 0)),
							DisabledImage = Gui.Image("LobbyUI/team/lb_squad_button7_disabled.dds", Vector4(0, 0, 0, 0)),
						},
						EventClick = function()
							ShowDenfanseFight()
						end,
						Gui.Button "defance_num_btn"
						{
							Size = Vector2(21, 22),
							Location = Vector2(142, 0),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Visible = false,
							Skin = Gui.ButtonSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_unviewed_bg.dds", Vector4(0, 0, 0, 0)),
								HoverImage = nil,
								DownImage = nil,
								DisabledImage = nil,
							},
						},
					},
				
					Gui.Button
					{
						Size = Vector2(163, 46),
						Location = Vector2(182, 18),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Text = lang:GetText("本周战绩"),
						Padding = Vector4(0, 0, 0, 7),
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_button7_normal.dds", Vector4(0, 0, 0, 0)),
							HoverImage = Gui.Image("LobbyUI/team/lb_squad_button7_hover.dds", Vector4(0, 0, 0, 0)),
							DownImage = Gui.Image("LobbyUI/team/lb_squad_button7_down.dds", Vector4(0, 0, 0, 0)),
							DisabledImage = Gui.Image("LobbyUI/team/lb_squad_button7_disabled.dds", Vector4(0, 0, 0, 0)),
						},
						EventClick = function()
							ShowWeekendRank()
						end,
					},	
					Gui.Button
					{
						Size = Vector2(163, 46),
						Location = Vector2(857, 18),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Text = lang:GetText("争夺模式"),
						Padding = Vector4(0, 0, 0, 7),
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_button7_normal.dds", Vector4(0, 0, 0, 0)),
							HoverImage = Gui.Image("LobbyUI/team/lb_squad_button7_hover.dds", Vector4(0, 0, 0, 0)),
							DownImage = Gui.Image("LobbyUI/team/lb_squad_button7_down.dds", Vector4(0, 0, 0, 0)),
							DisabledImage = Gui.Image("LobbyUI/team/lb_squad_button7_disabled.dds", Vector4(0, 0, 0, 0)),
						},
						EventClick = function()
							SourceFightType = 0
							local flag = false
							state = ptr_cast(game.CurrentState)
							for i = 0, state:GetServerCount() - 1 do
								local info = state:GetServerInfo(i,true)
								print("info.isnovice:"..info.isnovice)
								if info.isnovice == 3 and info.online_count/info.online_max < 0.8 then
									-- state:EnterServer(info.id)
									psd = ""..roompsd[math.random(#roompsd)]..roompsd[math.random(#roompsd)]..roompsd[math.random(#roompsd)]..roompsd[math.random(#roompsd)]..roompsd[math.random(#roompsd)]..roompsd[math.random(#roompsd)]
									flag = true
									state.is_fight_team_server = true
									state.source_is_create = true
									state:EnterServer(info.id)
									create_source_room_option = ptr_new ("Client.RoomOption")
									create_source_room_option.name = lang:GetText("战队战")
									create_source_room_option.client_count = 6
									create_source_room_option.use_password = true
									create_source_room_option.password = psd
									create_source_room_option.character_id = L_WarZone.single_character_id[1]
									create_source_room_option.check_game_balance = false
									create_source_room_option.round_rebirth_time_max = L_WarZone.rebirth_time[3]
									create_source_room_option.game_type = "kTDMode"
									create_source_room_option.map_name = ""
									create_source_room_option.rule_value = 1
									create_source_room_option.level_id = 1
									-- create_fightteam_room_option.group_match = true
								end	 
							end
							if not flag then
								MessageBox.ShowWithTimer(3,lang:GetText("战队服务器已满"))
							end
						end
					},
				},
			},	
			
			--tian 1--
			Gui.Control "buildteam"
			{
				Visible = false,
				--Size = Vector2(1116, 515),
				Dock = "kDockFill",
				--BackgroundColor = ARGB(125, 255, 255, 255),
				--Location = Vector2(0, 0),
				
				Gui.Control "B"--B区战队空间等级显示区域
				{
					Size = Vector2(1030, 59),
					Location = Vector2(13, 12),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_bg_02.dds",Vector4(10, 10, 2, 2)),
					},
					Gui.Label "canFC"
					{
						Size = Vector2(247, 25),
						Location = Vector2(52,18),
						Text = lang:GetText("8000"),
						FontSize = 14,
						TextPadding = Vector4(0,0,10,0),
						TextColor = ARGB(255, 255, 255, 255),
						TextAlign = "kAlignRightMiddle",
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/lb_com_bg.dds",Vector4(45,0,20,0)),
						},
					},
					Gui.Control --可用能源的小图标
					{
						Size = Vector2(30, 30),
						Location = Vector2(58, 13),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Skin.priceIcon[2],--6是黑铁图标,2是FC币图标,5是黑晶石图标（个人用）
						Hint = lang:GetText("我的FC"),
					},
					Gui.Label "canPower"
					{
						Size = Vector2(247, 25),
						Location = Vector2(349,18),
						Text = lang:GetText("8000"),
						FontSize = 14,
						TextPadding = Vector4(0,0,10,0),
						TextColor = ARGB(255, 255, 255, 255),
						TextAlign = "kAlignRightMiddle",
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/lb_com_bg.dds",Vector4(45,0,20,0)),
						},
					},
					Gui.Control --可用精油的小图标
					{
						Size = Vector2(30, 30),
						Location = Vector2(355, 13),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Skin.priceIcon[6],--6是精油图标,2是FC币图标
						Hint = lang:GetText("战队黑铁"),
					},
					
					Gui.Control
					{
						Size = Vector2(68, 17),
						Location = Vector2(9,21),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Skin.priceLevelIcon,
						Visible = false,
					},
					
					Gui.FlowLayout "placeLevel"
					{
						Size = Vector2(23, 19),
						Location = Vector2(103,20),
						Direction = "kHorizontal",
						Align = "kAlignRightMiddle",
						ControlAlign = "kAlignCenterMiddle",
						ControlSpace = 0,
						Visible = false,
					},
					
					Gui.Control
					{
						Size = Vector2(162, 25),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Location = Vector2(272, 17),
						Visible = false,
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/lb_com_bg.dds",Vector4(45,0,20,0)),
						},
						Gui.Label
						{
							Size = Vector2(32, 17),
							Location = Vector2(7,4),
							Text = lang:GetText("时间"),
							FontSize = 16,
							TextColor = ARGB(255, 255, 255, 255),
							TextAlign = "kAlignCenterMiddle",
						},
						Gui.Label "team_time_lb"
						{
							Dock = "kDockFill",
							FontSize = 16,
							TextColor = ARGB(255, 255, 255, 255),
							TextPadding = Vector4(0,0,10,0),
							TextAlign = "kAlignRightMiddle",
						},
						Gui.TimeControl "team_ctrlTimer"
						{
							Size = Vector2(5,5),
							Dock = "kDockCenter",
							BackgroundColor = ARGB(0, 255, 255, 255),
							
						},
					},
	
					Gui.Button "editTeam"
					{
						Size = Vector2(170, 32),
						Location = Vector2(749, 14),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Text = lang:GetText("编辑战队空间"),
						DisabledTextColor = ARGB(255, 0, 0, 0),
						Skin = Skin.TeamBtnSkin,
						
						EventClick = function()
							local flag = false
							state = ptr_cast(game.CurrentState)
							for i = 0, state:GetServerCount() - 1 do
								local info = state:GetServerInfo(i,true)
								if info.isnovice == 3 and info.online_count/info.online_max < 0.8 then
									rpc.safecallload("edit_map", {pid = ptr_cast(game.CurrentState):GetCharacterId()},
									function(data)
										FillMap(data.configs,2,0,data.tsl,data.name)
									end)
									psd = ""..roompsd[math.random(#roompsd)]..roompsd[math.random(#roompsd)]..roompsd[math.random(#roompsd)]..roompsd[math.random(#roompsd)]..roompsd[math.random(#roompsd)]..roompsd[math.random(#roompsd)]
									flag = true
									state.is_fight_team_server = true
									state:EnterServer(info.id)
									create_source_room_option = ptr_new ("Client.RoomOption")
									create_source_room_option.name = lang:GetText("战队战")
									create_source_room_option.client_count = 2
									create_source_room_option.use_password = true
									create_source_room_option.password = psd
									create_source_room_option.character_id = L_WarZone.single_character_id[1]
									create_source_room_option.check_game_balance = false
									create_source_room_option.round_rebirth_time_max = L_WarZone.rebirth_time[3]
									create_source_room_option.game_type = "kEditMode"
									create_source_room_option.map_name = ""
									create_source_room_option.rule_value = 1
									create_source_room_option.level_id = 185
									is_Edit_create_room = true
								end	 
							end
							if not flag then
								MessageBox.ShowWithTimer(3,lang:GetText("战队服务器已满"))
							end
						end
					},
					Gui.Button "LookTeamSpace"
					{
						Size = Vector2(80, 32),
						Location = Vector2(930, 14),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Text = lang:GetText("查看部署"),
						DisabledTextColor = ARGB(255, 0, 0, 0),
						Skin = Skin.TeamBtnSkin,
						EventClick = function()
							Showlook_my_space()
						end
					},
				
				},
				--仓库区域ui
				Gui.Control "E"--E.	（仓库）玩家在这里查看已拥有的建筑，并且进行配置
				{
					Size = Vector2(432, 339),
					Location = Vector2(10, 118),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Visible = true,
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/lb_shop_bg3.dds",Vector4(10, 10, 10, 10)),
					},
					Gui.Control 
					{
						Size = Vector2(406+125, 310),
						Location = Vector2(13, 13),
						BackgroundColor = ARGB(0, 255, 255, 255),
						Gui.Tabpad "tpd_storage"
						{
							--Size = Vector2(246,459),
							Dock = "kDockFill",
							-- Margin = Vector4(0,7,0,0),
							--Location = Vector2(0,65),
							TabSize = Vector2(93,24),
							TabGap = 1,
							--TabDock = "kDockTop",
						   -- TabPadding = Vector4(9,0,0,0),
							Index = 0,
							Skin = Gui.TabpadSkin
							{
								--Control skin
								BackgroundImage = nil,
								
								TabNormalImage= Gui.Image("LobbyUI/team/lb_squad_button11_normal.dds", Vector4(4,6,4,4)),
								TabHoverImage = Gui.Image("LobbyUI/team/lb_squad_button11_hover.dds", Vector4(4,6,4,4)),
								TabActiveImage = Gui.Image("LobbyUI/team/lb_squad_button11_down.dds", Vector4(4,6,4,4)),
								TabNormalDisabledImage = Gui.Image("LobbyUI/team/lb_squad_button11_disabled.dds", Vector4(4,6,4,4)),
							},
							
							Gui.Tabpage "tpg_tower"--防御塔
							{
								Text = lang:GetText("机械守卫"),
								Padding = Vector4(0,0,127,0),
								--LineSpace = 5,
							},				
							Gui.Tabpage "tpg_wall"--城墙
							{
								Text = lang:GetText("防御墙"),
								Padding = Vector4(0,0,127,0),
								--LineSpace = 5,
							},
							Gui.Tabpage "tpg_scene"--道具
							{
								Text = lang:GetText("原石挖掘机"),
								Padding = Vector4(0,0,127,0),
								--LineSpace = 5,
							},
						},
					},
					
				},
				Gui.Control "C"--C区科技树区域
				{
					Size = Vector2(432, 339),
					Location = Vector2(10, 118),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Visible = false,
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/lb_shop_bg3.dds",Vector4(10, 10, 10, 10)),
					},
					Gui.Control 
					{
						Size = Vector2(406+220, 310),
						Location = Vector2(13, 13),
						BackgroundColor = ARGB(0, 255, 255, 255),
						Gui.Tabpad "tpd_Tree"
						{
							Dock = "kDockFill",
							Margin = Vector4(0,0,0,0),
							--Location = Vector2(0,65),
							TabSize = Vector2(93,24),
							TabGap = 1,
							-- TabDock = "kDockTop",
							-- TabPadding = Vector4(50,0,0,0),
							Index = 0,
							Skin = Gui.TabpadSkin
							{
								--Control skin
								BackgroundImage = nil,
								
								TabNormalImage= Gui.Image("LobbyUI/team/lb_squad_button11_normal.dds", Vector4(4,6,4,4)),
								TabHoverImage = Gui.Image("LobbyUI/team/lb_squad_button11_hover.dds", Vector4(4,6,4,4)),
								TabActiveImage = Gui.Image("LobbyUI/team/lb_squad_button11_down.dds", Vector4(4,6,4,4)),
								TabNormalDisabledImage = Gui.Image("LobbyUI/team/lb_squad_button11_disabled.dds", Vector4(4,6,4,4)),
							},
							
							Gui.Tabpage "tpg_T_tower"--防御塔
							{
								Text = lang:GetText("机械守卫"),
								Padding = Vector4(0,0,220,0),
								--LineSpace = 5,
							},				
							Gui.Tabpage "tpg_T_wall"--城墙
							{
								Text = lang:GetText("防御墙"),
								Padding = Vector4(0,0,220,0),
								--LineSpace = 5,
							},
							--[[
							Gui.Tabpage "tpg_T_scene"--道具
							{
								Text = lang:GetText("原石挖掘机"),
								Padding = Vector4(0,0,117,0),
								Enable = false,
								--LineSpace = 5,
							},--]]
						},
					},
				
				},
				Gui.Button "showStorage_btn"
				{
					Size = Vector2(181, 56),
					Location = Vector2(30, 71),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Text = lang:GetText("仓库"),
					HighlightTextColor = ARGB(255,255,255,255),
					TextColor = ARGB(255,0,0,0),
					PushDown = true,
					Skin = Skin.StorageBtnSkin,
					EventClick = function(sender,e)
						allteam_source_ui.E.Visible = true
						allteam_source_ui.C.Visible = false
						sender.PushDown = true
						allteam_source_ui.showTree_btn.PushDown = false
						updataTeamInfo(1,cType)
					end
				},
				Gui.Button "showTree_btn"
				{
					Size = Vector2(181, 56),
					Location = Vector2(214, 71),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Text = lang:GetText("科技树"),
					HighlightTextColor = ARGB(255,255,255,255),
					TextColor = ARGB(255,0,0,0),
					PushDown = false,
					Skin = Skin.StorageBtnSkin,
					
					EventClick = function(sender,e)
						allteam_source_ui.E.Visible = false
						allteam_source_ui.C.Visible = true
						sender.PushDown = true
						allteam_source_ui.showStorage_btn.PushDown = false
						updataTreeInfo(tType)
					end
				},
				Gui.Control "F"--F.	建筑属性显示区域
				{
					Size = Vector2(597, 379),
					Location = Vector2(448, 77),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_bg_02.dds",Vector4(10, 10, 2, 2)),
					},
					Gui.Control 
					{
						Dock = "kDockFill",
						BackgroundColor = ARGB(127, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_haibao.dds",Vector4(0, 0, 0, 0)),
						},						
					},
				},
			},
			------tian 2----------------
			Gui.Control "buildSingle"
			{
				Visible = false,
				--Size = Vector2(1116, 515),
				Dock = "kDockFill",
				--BackgroundColor = ARGB(125, 255, 255, 255),
				--Location = Vector2(0, 0),
				
				Gui.Control "s_up"--B区个人空间等级显示区域
				{
					Size = Vector2(1030, 59),
					Location = Vector2(13, 12),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_bg_02.dds",Vector4(10, 10, 2, 2)),
					},
					Gui.Label "s_canFC"
					{
						Size = Vector2(247, 25),
						Location = Vector2(52,18),
						Text = lang:GetText("8000"),
						FontSize = 14,
						TextPadding = Vector4(0,0,10,0),
						TextColor = ARGB(255, 255, 255, 255),
						TextAlign = "kAlignRightMiddle",
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/lb_com_bg.dds",Vector4(45,0,20,0)),
						},
					},
					Gui.Control --可用能源的小图标
					{
						Size = Vector2(30, 30),
						Location = Vector2(58, 13),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Skin.priceIcon[2],--6是黑铁图标,2是FC币图标,5是黑晶石图标（个人用）
						Hint = lang:GetText("我的FC"),
					},
					Gui.Label "s_canPower"
					{
						Size = Vector2(247, 25),
						Location = Vector2(349,18),
						Text = lang:GetText("8000"),
						FontSize = 14,
						TextPadding = Vector4(0,0,10,0),
						TextColor = ARGB(255, 255, 255, 255),
						TextAlign = "kAlignRightMiddle",
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/lb_com_bg.dds",Vector4(45,0,20,0)),
						},
					},
					Gui.Control --可用能源的小图标
					{
						Size = Vector2(30, 30),
						Location = Vector2(355, 13),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Skin.priceIcon[5],--6是黑铁图标,2是FC币图标,5是黑晶石图标
						Hint = lang:GetText("个人黑晶石"),
					},
				},
				--仓库区域ui
				Gui.Control "s_storage"--E.	（个人仓库）玩家在这里查看已拥有的建筑，并且进行配置
				{
					Size = Vector2(432, 339),
					Location = Vector2(10, 118),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Visible = true,
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/lb_shop_bg3.dds",Vector4(10, 10, 10, 10)),
					},
					Gui.Control 
					{
						Size = Vector2(406, 310),
						Location = Vector2(13, 13),
						BackgroundColor = ARGB(0, 255, 255, 255),
						Gui.Button "btn_s_tank"
						{
							Size = Vector2(93,24),
							Location = Vector2(218, 1),
							BackgroundColor = ARGB(255, 255, 255, 255),
							HighlightTextColor = ARGB(255,255,255,255),
							TextColor = ARGB(255,0,0,0),
							Text = lang:GetText("载具"),
							PushDown = true,
							Skin = Gui.ButtonSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_button11_normal.dds", Vector4(0, 0, 0, 0)),
								HoverImage = Gui.Image("LobbyUI/team/lb_squad_button11_hover.dds", Vector4(0, 0, 0, 0)),
								DownImage = Gui.Image("LobbyUI/team/lb_squad_button11_down.dds", Vector4(0, 0, 0, 0)),
								DisabledImage = Gui.Image("LobbyUI/team/lb_squad_button11_disabled.dds", Vector4(0, 0, 0, 0)),
							},
							EventClick = function(sender,e)
								allteam_source_ui.s_storage_tank.Visible = true
								allteam_source_ui.s_storage_buff.Visible = false
								sender.PushDown = true
								allteam_source_ui.btn_s_buff.PushDown = false
								sType = 3
								updataPersonalInfo(1,sType)
							end
						},
						Gui.Button "btn_s_buff"
						{
							Size = Vector2(93,24),
							Location = Vector2(312, 1),
							BackgroundColor = ARGB(255, 255, 255, 255),
							HighlightTextColor = ARGB(255,255,255,255),
							TextColor = ARGB(255,0,0,0),
							Text = lang:GetText("补给品"),
							PushDown = false,
							Skin = Gui.ButtonSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_button11_normal.dds", Vector4(0, 0, 0, 0)),
								HoverImage = Gui.Image("LobbyUI/team/lb_squad_button11_hover.dds", Vector4(0, 0, 0, 0)),
								DownImage = Gui.Image("LobbyUI/team/lb_squad_button11_down.dds", Vector4(0, 0, 0, 0)),
								DisabledImage = Gui.Image("LobbyUI/team/lb_squad_button11_disabled.dds", Vector4(0, 0, 0, 0)),
							},
							EventClick = function(sender,e)
								allteam_source_ui.s_storage_buff.Visible = true
								allteam_source_ui.s_storage_tank.Visible = false
								sender.PushDown = true
								allteam_source_ui.btn_s_tank.PushDown = false
								sType = 6
								updataPersonalInfo(buff_cPage,sType)
							end
						},
						Gui.Control "s_storage_tank"--个人仓库坦克区域
						{
							Size = Vector2(406, 286),
							Location = Vector2(0, 24),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Visible = true,
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_bg_02.dds",Vector4(10, 10, 4, 4)),
							},
							Gui.Control "ctrl_tank"
							{
								Size = Vector2(305,204),
								Location = Vector2(50,36),
								CreatePersonalStorageListGrids(0,0,1),
								CreatePersonalStorageListGrids(1,0,2),
								CreatePersonalStorageListGrids(2,0,3),
								                              
								CreatePersonalStorageListGrids(0,1,4),
								CreatePersonalStorageListGrids(1,1,5),
								CreatePersonalStorageListGrids(2,1,6),		
							},	
						},
						Gui.Control "s_storage_buff"--个人仓库BUFF区域
						{
							Size = Vector2(406, 286),
							Location = Vector2(0, 24),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Visible = false,
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_bg_02.dds",Vector4(10, 10, 4, 4)),
							},
							Gui.Control "ctrl_buff"
							{
								Size = Vector2(305,204),
								Location = Vector2(50,36),
								CreatePersonalBuffListGrids(0,0,1),
								CreatePersonalBuffListGrids(1,0,2),
								CreatePersonalBuffListGrids(2,0,3),
								                              
								CreatePersonalBuffListGrids(0,1,4),
								CreatePersonalBuffListGrids(1,1,5),
								CreatePersonalBuffListGrids(2,1,6),		
							},
							Gui.Control "ctrl_bottom_buff"
							{							
								Size = Vector2(90, 23),
								Location = Vector2(154, 250),
								BackgroundColor = ARGB(255, 255, 255, 255),
								Visible = true,
								Skin = Gui.ControlSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/team/lb_huadong_bg.dds", Vector4(8, 8, 8, 8)),
								},
								--页码
								Gui.Label "lb_page_number_buff"
								{
									Dock = "kDockFill",
									FontSize = 14,
									TextAlign = "kAlignCenterMiddle",
									TextColor = ARGB(255, 255, 255, 255),
									Text = "1/1",
							
								},
								--上一页
								Gui.Button "btn_front_page_buff"
								{
									Size = Vector2(21, 21),
									--Location = Vector2(281, 9),
									Dock = "kDockLeft",			
									Skin = Gui.ButtonSkin
									{
										BackgroundImage = Gui.Image("LobbyUI/team/lb_z_normal.dds", Vector4(0, 0, 0, 0)),
										HoverImage = Gui.Image("LobbyUI/team/lb_z_hover.dds", Vector4(0, 0, 0, 0)),
										DownImage = Gui.Image("LobbyUI/team/lb_z_down.dds", Vector4(0, 0, 0, 0)),
										DisabledImage = Gui.Image("LobbyUI/team/lb_z_disabled.dds", Vector4(0, 0, 0, 0)),
									},
									
								},
								

								--下一页
								Gui.Button "btn_next_page_buff"
								{
									Size = Vector2(21, 21),
									--Location = Vector2(400, 9),
									Dock = "kDockRight",
									Skin = Gui.ButtonSkin
									{
										BackgroundImage = Gui.Image("LobbyUI/team/lb_y_normal.dds", Vector4(0, 0, 0, 0)),
										HoverImage = Gui.Image("LobbyUI/team/lb_y_hover.dds", Vector4(0, 0, 0, 0)),
										DownImage = Gui.Image("LobbyUI/team/lb_y_down.dds", Vector4(0, 0, 0, 0)),
										DisabledImage = Gui.Image("LobbyUI/team/lb_y_disabled.dds", Vector4(0, 0, 0, 0)),
									},
									
								},
							},
						},
						--[[
						Gui.Tabpad "tpd_s_storage"
						{
							--Size = Vector2(246,459),
							Dock = "kDockFill",
							-- Margin = Vector4(0,7,0,0),
							--Location = Vector2(0,65),
							TabSize = Vector2(93,24),
							TabGap = 1,
							--TabDock = "kDockTop",
						   -- TabPadding = Vector4(9,0,0,0),
							Index = 0,
							Skin = Gui.TabpadSkin
							{
								--Control skin
								BackgroundImage = nil,
								
								TabNormalImage= Gui.Image("LobbyUI/team/lb_squad_button11_normal.dds", Vector4(4,6,4,4)),
								TabHoverImage = Gui.Image("LobbyUI/team/lb_squad_button11_hover.dds", Vector4(4,6,4,4)),
								TabActiveImage = Gui.Image("LobbyUI/team/lb_squad_button11_down.dds", Vector4(4,6,4,4)),
								TabNormalDisabledImage = Gui.Image("LobbyUI/team/lb_squad_button11_disabled.dds", Vector4(4,6,4,4)),
							},
							
							Gui.Tabpage "tpg_s_tower"--防御塔
							{
								Text = lang:GetText("防御塔"),
								--Padding = Vector4(5,5,0,0),
								--LineSpace = 5,
							},				
							Gui.Tabpage "tpg_s_wall"--城墙
							{
								Text = lang:GetText("城墙"),
								--Padding = Vector4(5,5,0,0),
								--LineSpace = 5,
							},
							Gui.Tabpage "tpg_s_scene"--道具
							{
								Text = lang:GetText("道具"),
								--Padding = Vector4(5,5,0,0),
								--LineSpace = 5,
							},
						},--]]
					},
					
				},
				Gui.Control "s_tree"--个人建设区科技树区域
				{
					Size = Vector2(432, 339),
					Location = Vector2(10, 118),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Visible = false,
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/lb_shop_bg3.dds",Vector4(10, 10, 10, 10)),
					},
					
					Gui.Control 
					{
						Size = Vector2(406, 310),
						Location = Vector2(13, 13),
						BackgroundColor = ARGB(0, 255, 255, 255),
						Gui.Button "btn_sTree_tank"
						{
							Size = Vector2(93,24),
							Location = Vector2(312, 0),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Text = lang:GetText("载具"),
							HighlightTextColor = ARGB(255,255,255,255),
							TextColor = ARGB(255,0,0,0),
							PushDown = true,
							Skin = Gui.ButtonSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_button11_normal.dds", Vector4(0, 0, 0, 0)),
								HoverImage = Gui.Image("LobbyUI/team/lb_squad_button11_hover.dds", Vector4(0, 0, 0, 0)),
								DownImage = Gui.Image("LobbyUI/team/lb_squad_button11_down.dds", Vector4(0, 0, 0, 0)),
								DisabledImage = Gui.Image("LobbyUI/team/lb_squad_button11_disabled.dds", Vector4(0, 0, 0, 0)),
							},
							EventClick = function(sender,e)
								allteam_source_ui.s_tree_tank.Visible = true
								sender.PushDown = true
							end
						},
							
						Gui.Control "ctrl_Personal_tree"
						{
							Size = Vector2(406, 286),
							Location = Vector2(0, 24),
							BackgroundColor = ARGB(0, 255, 255, 255),
							
						},
						Gui.Control "s_tree_tank"--个人天赋树坦克区域
						{
							Size = Vector2(406, 286),
							Location = Vector2(0, 24),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_bg_02.dds",Vector4(10, 10, 2, 2)),
							},
							Gui.Label 
							{
								Size = Vector2(468, 50),
								Location = Vector2(0,10),
								TextAlign = "kAlignCenterMiddle",
								Text = lang:GetText("全属性升级到LV10以后\n开放下一层科技"),
								FontSize = 16,
								TextColor = ARGB(255, 255, 210, 0),
							},
							Gui.Control 
							{
								Size = Vector2(274,235),
								Location = Vector2(47,39),
								Skin = Gui.ControlSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/team/lb_kejishu_bg02.dds",Vector4(0, 0, 0, 0)),
								},
								Gui.Control "line_w1_p"
								{
									Size = Vector2(142,2),
									Location = Vector2(66,117),
									BackgroundColor = ARGB(255,108,130,179),
								},
								Gui.Control "ctrl_P_tree"
								{
									Dock = "kDockFill",
									BackgroundColor = ARGB(0,255,255,255),
									CreatePersonalTreeListGrids(36,88,1),
									CreatePersonalTreeListGrids(107,88,2),
									CreatePersonalTreeListGrids(178,88,3),
								},	
							},													
						},
						--[[
						Gui.Tabpad "tpd_s_Tree"
						{
							 Dock = "kDockFill",
							-- Margin = Vector4(0,7,0,0),
							--Location = Vector2(0,65),
							TabSize = Vector2(93,24),
							TabGap = 1,
						   -- TabPadding = Vector4(9,0,0,0),
							Index = 0,
							Skin = Gui.TabpadSkin
							{
								--Control skin
								BackgroundImage = nil,
								
								TabNormalImage= Gui.Image("LobbyUI/team/lb_squad_button11_normal.dds", Vector4(4,6,4,4)),
								TabHoverImage = Gui.Image("LobbyUI/team/lb_squad_button11_hover.dds", Vector4(4,6,4,4)),
								TabActiveImage = Gui.Image("LobbyUI/team/lb_squad_button11_down.dds", Vector4(4,6,4,4)),
								TabNormalDisabledImage = Gui.Image("LobbyUI/team/lb_squad_button11_disabled.dds", Vector4(4,6,4,4)),
							},
							
							Gui.Tabpage "tpg_ST_tower"--防御塔
							{
								Text = lang:GetText("防御塔"),
								--Padding = Vector4(5,5,0,0),
								--LineSpace = 5,
							},				
							Gui.Tabpage "tpg_ST_wall"--城墙
							{
								Text = lang:GetText("城墙"),
								--Padding = Vector4(5,5,0,0),
								--LineSpace = 5,
							},
							Gui.Tabpage "tpg_ST_scene"--道具
							{
								Text = lang:GetText("道具"),
								--Padding = Vector4(5,5,0,0),
								--LineSpace = 5,
							},
						},--]]
					},
				
				},
				Gui.Button "s_showStorage_btn"
				{
					Size = Vector2(181, 56),
					Location = Vector2(30, 71),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Text = lang:GetText("仓库"),
					HighlightTextColor = ARGB(255,255,255,255),
					TextColor = ARGB(255,0,0,0),
					PushDown = true,
					Skin = Skin.StorageBtnSkin,
					EventClick = function(sender,e)
						allteam_source_ui.s_storage.Visible = true
						allteam_source_ui.s_tree.Visible = false
						sender.PushDown = true
						allteam_source_ui.s_showTree_btn.PushDown = false
						updataPersonalInfo(1,sType)
						isP_Tree = false
					end
				},
				Gui.Button "s_showTree_btn"
				{
					Size = Vector2(181, 56),
					Location = Vector2(214, 71),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Text = lang:GetText("科技树"),
					HighlightTextColor = ARGB(255,255,255,255),
					TextColor = ARGB(255,0,0,0),
					PushDown = false,
					Skin = Skin.StorageBtnSkin,
					EventClick = function(sender,e)
						allteam_source_ui.s_storage.Visible = false
						allteam_source_ui.s_tree.Visible = true
						sender.PushDown = true
						allteam_source_ui.s_showStorage_btn.PushDown = false
						updataTreeInfo(3) --3是坦克科技树
						isP_Tree = true
					end
				},
				Gui.Control "s_tips"--个人建设属性显示区域
				{
					Size = Vector2(597, 379),
					Location = Vector2(448, 77),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_bg_02.dds",Vector4(10, 10, 2, 2)),
					},
					Gui.Control 
					{
						Dock = "kDockFill",
						BackgroundColor = ARGB(127, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_haibao.dds",Vector4(0, 0, 0, 0)),
						},						
					},
				},
			},
		},
		Gui.Button "info_btn"
		{
			Size = Vector2(254, 46),
			Location = Vector2(37, 62),
			Text = lang:GetText("首页"),
			HighlightTextColor = ARGB(255,255,255,255),
			TextColor = ARGB(255,0,0,0),
			FontSize = 16,
			PushDown = true,
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_normal.dds", Vector4(46, 0, 46, 0)),
				HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_hover.dds", Vector4(46, 0, 46, 0)),
				DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_down.dds", Vector4(46, 0, 46, 0)),
				DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_normal.dds", Vector4(46, 0, 46, 0)),
			},
			EventClick = function()

				allteam_source_ui.allteam.Visible = true
				allteam_source_ui.buildteam.Visible = false
				allteam_source_ui.buildSingle.Visible = false
				allteam_source_ui.info_btn.PushDown = true
				allteam_source_ui.person_btn.PushDown = false
				allteam_source_ui.team_btn.PushDown = false
				initIdx()
				Fill_Header_Team()
			end
		},
		Gui.Button "team_btn"
		{
			Size = Vector2(254, 46),
			Location = Vector2(285, 62),
			Text = lang:GetText("战队空间建设"),
			TextAlign = "kAlignCenterMiddle",
			FontSize = 16,
			HighlightTextColor = ARGB(255,255,255,255),
			TextColor = ARGB(255,0,0,0),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_normal.dds", Vector4(46, 0, 46, 0)),
				HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_hover.dds", Vector4(46, 0, 46, 0)),
				DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_down.dds", Vector4(46, 0, 46, 0)),
				DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_normal.dds", Vector4(46, 0, 46, 0)),
			},
			EventClick = function()
				allteam_source_ui.buildteam.Visible = true
				allteam_source_ui.allteam.Visible = false
				allteam_source_ui.buildSingle.Visible = false
				
				allteam_source_ui.info_btn.PushDown = false
				allteam_source_ui.person_btn.PushDown = false
				allteam_source_ui.team_btn.PushDown = true
				isTeamOrPersonal = 0
				--initIdx()
				FillMyTeamSource_ui()
				L_LobbyMain.LobbyMainWin.zhandui_source.Visible = true
				L_LobbyMain.LobbyMainWin.my_source.Visible = false
				L_LobbyMain.LobbyMainWin.b_zhandui.PushDown = true
				L_LobbyMain.LobbyMainWin.b_geren.PushDown = false
			end
		},
		Gui.Button "person_btn"
		{
			Size = Vector2(254, 46),
			Location = Vector2(533, 62),
			Text = lang:GetText("个人装备建设"),
			TextAlign = "kAlignCenterMiddle",
			FontSize = 16,
			HighlightTextColor = ARGB(255,255,255,255),
			TextColor = ARGB(255,0,0,0),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_normal.dds", Vector4(46, 0, 46, 0)),
				HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_hover.dds", Vector4(46, 0, 46, 0)),
				DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_down.dds", Vector4(46, 0, 46, 0)),
				DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_normal.dds", Vector4(46, 0, 46, 0)),
			},
			EventClick = function()
				allteam_source_ui.buildSingle.Visible = true
				allteam_source_ui.buildteam.Visible = false
				allteam_source_ui.allteam.Visible = false
				
				allteam_source_ui.info_btn.PushDown = false
				allteam_source_ui.person_btn.PushDown = true
				allteam_source_ui.team_btn.PushDown = false
				isTeamOrPersonal = 1
				FillPersonalSource_ui()
				L_LobbyMain.LobbyMainWin.zhandui_source.Visible = false
				L_LobbyMain.LobbyMainWin.my_source.Visible = true
				L_LobbyMain.LobbyMainWin.b_zhandui.PushDown = false
				L_LobbyMain.LobbyMainWin.b_geren.PushDown = true
			end
		},
		Gui.Button ""
		{
			Location = Vector2(788, 60),
			Size = Vector2(136, 41),
			BackgroundColor = ARGB(255,255,255,255),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_button14_normal.dds", Vector4(0, 0, 0, 0)),
				HoverImage = Gui.Image("LobbyUI/team/lb_squad_button14_hover.dds", Vector4(0, 0, 0, 0)),
				DownImage = Gui.Image("LobbyUI/team/lb_squad_button14_down.dds", Vector4(0, 0, 0, 0)),
				DisabledImage = Gui.Image("LobbyUI/team/lb_squad_button14_disabled.dds", Vector4(0, 0, 0, 0)),
			},
			EventClick = function(sender, e)
				ShowSource_Exchange()
			end,
		},
		Gui.Button
		{
			Location = Vector2(938, 58),
			Size = Vector2(79, 45),
			BackgroundColor = ARGB(255,255,255,255),
			blink = true,
			blinkwheelTimer = 1,
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_yindao_normal.dds", Vector4(0, 0, 0, 0)),
				HoverImage = Gui.Image("LobbyUI/team/lb_squad_yindao_hover.dds", Vector4(0, 0, 0, 0)),
				DownImage = Gui.Image("LobbyUI/team/lb_squad_yindao_down.dds", Vector4(0, 0, 0, 0)),
				DisabledImage = Gui.Image("LobbyUI/team/lb_squad_yindao_disabled.dds", Vector4(0, 0, 0, 0)),
				TwinkleImage  = Gui.Image("LobbyUI/team/lb_squad_yindao_hover.dds", Vector4(0, 0, 0, 0)),
			},
			EventClick = function(sender, e)
				L_FightTeamFAQ.Show_TeamFAQ()
			end,
		},
	},	
}

--show个人仓库UI界面
--显示仓库城墙的ui
function ShowPersonalStorageTankUI(dataInfo)
	local ST = {}
    if dataInfo then
		ST = dataInfo
		print("ST~~~~~",#ST)
		for i = 1,maxCount,1 do
			local ibbtn = ptr_cast(allteam_source_ui.ctrl_tank:GetChildByIndex(i-1))
			if ST[i] then
				if i == selected_ibtn_index3 then
					ibbtn.Selected = true
				else
					ibbtn.Selected = false
				end
				ibbtn.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..ST[i].name..".tga")
				if ST[i].value == 0 then
					ibbtn.ItemIcon.alpha = 70
				else
					ibbtn.ItemIcon.alpha = 255
				end
				FillGrids_PersonalTips(ST[selected_ibtn_index3],isP_Tree,false)
				ibbtn.EventSelected = function(sender, e)
					if allteam_source_ui and sender.Loading == false then
						for j = 1, maxCount do	
							local ib = ptr_cast(allteam_source_ui.ctrl_tank:GetChildByIndex(j - 1))
							if j == i then
								ib.Selected = true
								--allteam_source_ui.lihe_btn.Enable = true
								FillGrids_PersonalTips(ST[i],isP_Tree,false)
								selected_ibtn_index3 = j
							else
								ib.Selected = false
							end
						end
					end		
					--selected_ibtn_index = index
				end
				
				allteam_source_ui["p_lv_Tankcrtl"..i].Visible = true
				allteam_source_ui["p_Level_Tank_"..i].Skin = Skin.itemLevelIcon[tonumber(ST[i].level)]
				allteam_source_ui["p_grids_num"..i].Visible = true
				--allteam_source_ui["p_grids_num"..i].Text = ST[i].value 
				--L_LobbyMain.ShowFightnums(allteam_source_ui["p_grids_num"..i],tonumber(ST[i].value),"team/lb_shop_number01.dds")
				allteam_source_ui["p_grids_num"..i]:OnDestroy()
				L_Characters.CreatPresentNumCtr(allteam_source_ui["p_grids_num"..i],tonumber(ST[i].value),90, 0)	
				--ibbtn.Selected = false
				ibbtn.Enable = true
			else
				allteam_source_ui["p_lv_Tankcrtl"..i].Visible = false
				allteam_source_ui["p_grids_num"..i].Visible = false
				ibbtn.ItemIcon = nil
				ibbtn.Enable = false
			end			
		end	
	else
		for i = 1,maxCount,1 do
			local ibb = ptr_cast(allteam_source_ui.ctrl_tank:GetChildByIndex(i-1))
			ibb.ItemIcon = nil
			ibb.Enable = false			
		end
	end
 end
 
function ShowPersonalStorageBuffUI(dataInfo)
	local SB = {}
	if dataInfo and dataInfo.teamStorage.buff then
		SB = dataInfo.teamStorage.buff
		buff_cPage = SB.curPage
		allteam_source_ui.lb_page_number_buff.Text = SB.curPage .. "/" .. SB.pages
		allteam_source_ui.btn_front_page_buff.EventClick = function()
			if SB.curPage <= 1 then
				return
			else
				buff_cPage = SB.curPage - 1
				allteam_source_ui.lb_page_number_buff.Text = buff_cPage .. "/" .. SB.pages
				updataPersonalInfo(buff_cPage,sType)
			end
		end
		allteam_source_ui.btn_next_page_buff.EventClick = function()
			if SB.curPage >= SB.pages then
				return
			else
				buff_cPage = SB.curPage + 1
				allteam_source_ui.lb_page_number_buff.Text = buff_cPage .. "/" .. SB.pages
				updataPersonalInfo(buff_cPage,sType)
			end
		end
		
		print("SB~~~~~",#SB)
		for i = 1,maxCount,1 do
			local ibbtn = ptr_cast(allteam_source_ui.ctrl_buff:GetChildByIndex(i-1))
			if SB[i] then
				if i == selected_ibtn_index9 then
					ibbtn.Selected = true
				else
					ibbtn.Selected = false
				end
				ibbtn.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..SB[i].name..".tga")
				if SB[i].value == 0 then
					ibbtn.ItemIcon.alpha = 70
				else
					ibbtn.ItemIcon.alpha = 255
				end
				FillGrids_PersonalTips(SB[selected_ibtn_index9],isP_Tree,true)
				ibbtn.EventSelected = function(sender, e)
					if allteam_source_ui and sender.Loading == false then
						for j = 1, maxCount do	
							local ib = ptr_cast(allteam_source_ui.ctrl_buff:GetChildByIndex(j - 1))
							if j == i then
								ib.Selected = true
								--allteam_source_ui.lihe_btn.Enable = true
								FillGrids_PersonalTips(SB[i],isP_Tree,true)
								selected_ibtn_index9 = j
							else
								ib.Selected = false
							end
						end
					end		
				end
				
				allteam_source_ui["p_grids_BuffNum"..i].Visible = true
				--allteam_source_ui["p_grids_BuffNum"..i].Text = SB[i].value
				--L_LobbyMain.ShowFightnums(allteam_source_ui["p_grids_BuffNum"..i],tonumber(SB[i].value),"team/lb_shop_number01.dds",17,16)
				allteam_source_ui["p_grids_BuffNum"..i]:OnDestroy()
				L_Characters.CreatPresentNumCtr(allteam_source_ui["p_grids_BuffNum"..i],tonumber(SB[i].value),90, 0)
				ibbtn.Enable = true
			else
				allteam_source_ui["p_grids_BuffNum"..i].Visible = false
				ibbtn.ItemIcon = nil
				ibbtn.Enable = false
			end			
		end
	else
		for i = 1,maxCount,1 do		
			local ibb2 = ptr_cast(allteam_source_ui.ctrl_buff:GetChildByIndex(i-1))
			ibb2.ItemIcon = nil
			ibb2.Enable = false
		end
	end
 end
 
my_source_ui = Gui.Create()
{
	Gui.Control "root"
	{
		Visible = false,
		Dock = "kDockFill",
	},
}

my_source_shop = Gui.Create()
{
	Gui.Control "root"
	{
		Visible = false,
		Dock = "kDockFill",
	},
}

t_info = Gui.Create()
{
	Gui.Control "root"
	{
		Size = Vector2(1106, 551),
		Location = Vector2(0, 0),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_contact_bg1_01.dds", Vector4(163,163,53,53)),
		},
		Gui.Label
		{
			Size = Vector2(200, 30),
			Location = Vector2(32, 26),
			Text = lang:GetText("战队信息"),
			FontSize = 28,
			TextColor = ARGB(255, 0, 0, 0),
		},
		Gui.Label
		{
			Size = Vector2(200, 30),
			Location = Vector2(31, 25),
			Text = lang:GetText("战队信息"),
			FontSize = 28,
			TextColor = ARGB(255, 255, 103, 1),
		},
		--退出
		Gui.Button
		{
			Size = Vector2(48,48),
			Location = Vector2(1054, 5),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_normal.dds", Vector4(10, 10, 10, 10)),
				HoverImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_hover.dds", Vector4(10, 10, 10, 10)),
				DownImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_down.dds", Vector4(10, 10, 10, 10)),
				DisabledImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_disabled.dds", Vector4(0, 0, 0, 0)),	
			},
			EventClick = function()
				if t_info_ui then
					t_info_ui.Close()
					t_info_ui = nil
				end
			end,
		},
		Gui.Control
		{
			Size = Vector2(1066, 460),
			Location = Vector2(21, 66),
			BackgroundColor = ARGB(0, 255, 255, 255),
			Gui.Control
			{
				Size = Vector2(1066, 460),
				Location = Vector2(0, 0),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_contact_bg2.dds", Vector4(38, 41, 38, 66)),	
				},
			},
			-- Gui.Control
			-- {
				-- Size = Vector2(538, 182),
				-- Location = Vector2(15, 15),
				-- BackgroundColor = ARGB(255, 255, 255, 255),
				-- Skin = Gui.ControlSkin
				-- {
					-- BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_task_bg_6.dds", Vector4(12, 10, 42, 40)),
				-- },
				-- Gui.Control "team_image"
				-- {
					-- Size = Vector2(85, 88),
					-- Location = Vector2(14, 19),
					-- BackgroundColor = ARGB(255, 255, 255, 255),
					-- Skin = Gui.ControlSkin
					-- {
						-- BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_touxiang.dds", Vector4(0, 0, 0, 0)),
					-- },
				-- },
				-- Gui.Label
				-- {
					-- Size = Vector2(150, 30),
					-- Location = Vector2(108, 23),
					-- Text = lang:GetText("战队名称:"),
					-- FontSize = 20,
					-- TextColor = ARGB(255, 0, 0, 0),
				-- },
				-- Gui.Label
				-- {
					-- Size = Vector2(150, 30),
					-- Location = Vector2(107, 22),
					-- Text = lang:GetText("战队名称:"),
					-- FontSize = 20,
					-- TextColor = ARGB(255, 255, 103, 1),
				-- },
				-- Gui.Label "team_name_black"
				-- {
					-- Size = Vector2(170, 30),
					-- Location = Vector2(207, 22),
					-- Text = "",
					-- FontSize = 20,
					-- TextColor = ARGB(255, 0, 0, 0),
				-- },
				-- Gui.Label "team_name"
				-- {
					-- Size = Vector2(170, 30),
					-- Location = Vector2(206, 21),
					-- Text = "",
					-- FontSize = 20,
					-- TextColor = ARGB(255, 255, 187, 0),
				-- },
				-- Gui.Label
				-- {
					-- Size = Vector2(150, 30),
					-- Location = Vector2(382, 23),
					-- Text = lang:GetText("战斗力:"),
					-- FontSize = 20,
					-- TextColor = ARGB(255, 0, 0, 0),
				-- },
				-- Gui.Label
				-- {
					-- Size = Vector2(150, 30),
					-- Location = Vector2(381, 22),
					-- Text = lang:GetText("战斗力:"),
					-- FontSize = 20,
					-- TextColor = ARGB(255, 255, 103, 1),
				-- },
				-- Gui.Label "team_fightnum_black"
				-- {
					-- Size = Vector2(150, 30),
					-- Location = Vector2(456, 23),
					-- Text = "",
					-- FontSize = 20,
					-- TextColor = ARGB(255, 0, 0, 0),
				-- },
				-- Gui.Label "team_fightnum"
				-- {
					-- Size = Vector2(150, 30),
					-- Location = Vector2(455, 22),
					-- Text = "",
					-- FontSize = 20,
					-- TextColor = ARGB(255, 255, 187, 0),
				-- },
				-- Gui.Label
				-- {
					-- Size = Vector2(150, 30),
					-- Location = Vector2(108, 64),
					-- Text = lang:GetText("战队等级:"),
					-- FontSize = 20,
					-- TextColor = ARGB(255, 0, 0, 0),
				-- },
				-- Gui.Label
				-- {
					-- Size = Vector2(150, 30),
					-- Location = Vector2(107, 63),
					-- Text = lang:GetText("战队等级:"),
					-- FontSize = 20,
					-- TextColor = ARGB(255, 255, 103, 1),
				-- },
				-- Gui.Label "team_level_black"
				-- {
					-- Size = Vector2(150, 30),
					-- Location = Vector2(207, 63),
					-- Text = "",
					-- FontSize = 20,
					-- TextColor = ARGB(255, 0, 0, 0),
				-- },
				-- Gui.Label "team_level"
				-- {
					-- Size = Vector2(150, 30),
					-- Location = Vector2(206, 62),
					-- Text = "",
					-- FontSize = 20,
					-- TextColor = ARGB(255, 255, 187, 0),
				-- },
				-- Gui.Control "exp_back"
				-- {
					-- Size = Vector2(250, 19),
					-- Location = Vector2(256,70),
					-- BackgroundColor = ARGB(255, 255, 255, 255),
					-- Skin = Gui.ControlSkin
					-- {
						-- BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_melting_bar01_bg.dds", Vector4(5, 5, 5, 5)),
					-- },
					-- Gui.Control "exp_font"
					-- {
						-- Size = Vector2(250, 19),
						-- Location = Vector2(0, 0),
						-- BackgroundColor = ARGB(255, 255, 255, 255),
						-- Skin = Gui.ControlSkin
						-- {
							-- BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_melting_bar01_content.dds", Vector4(5, 5, 5, 5)),
						-- },
					-- },
					-- Gui.Label "team_exp"
					-- {
						-- Size = Vector2(250, 19),
						-- Location = Vector2(0, 0),
						-- Text = "1/1",
						-- FontSize = 14,
						-- TextColor = ARGB(255, 214, 253, 255),
						-- TextAlign = "kAlignCenterMiddle",
					-- },
				-- },
				-- Gui.Label
				-- {
					-- Size = Vector2(150, 22),
					-- Location = Vector2(329, 104),
					-- Text = lang:GetText("战绩排名:"),
					-- FontSize = 20,
					-- TextColor = ARGB(255, 0, 0, 0),
				-- },
				-- Gui.Label
				-- {
					-- Size = Vector2(150, 22),
					-- Location = Vector2(328, 103),
					-- Text = lang:GetText("战绩排名:"),
					-- FontSize = 20,
					-- TextColor = ARGB(255, 255, 103, 1),
				-- },
				-- Gui.Label "team_num_black"
				-- {
					-- Size = Vector2(150, 22),
					-- Location = Vector2(436, 104),
					-- Text = "",
					-- FontSize = 20,
					-- TextColor = ARGB(255, 0, 0, 0),
				-- },
				-- Gui.Label "team_num"
				-- {
					-- Size = Vector2(150, 22),
					-- Location = Vector2(435, 103),
					-- Text = "",
					-- FontSize = 20,
					-- TextColor = ARGB(255, 255, 187, 0),
				-- },
				-- Gui.Label
				-- {
					-- Size = Vector2(150, 22),
					-- Location = Vector2(329, 144),
					-- Text = lang:GetText("战斗力排名:"),
					-- FontSize = 20,
					-- TextColor = ARGB(255, 0, 0, 0),
					-- Visible = false,
				-- },
				-- Gui.Label
				-- {
					-- Size = Vector2(150, 22),
					-- Location = Vector2(328, 143),
					-- Text = lang:GetText("战斗力排名:"),
					-- FontSize = 20,
					-- TextColor = ARGB(255, 255, 103, 1),
					-- Visible = false,
				-- },
				-- Gui.Label "team_fightnum_num"
				-- {
					-- Size = Vector2(150, 22),
					-- Location = Vector2(440, 143),
					-- Text = "",
					-- FontSize = 20,
					-- TextColor = ARGB(255, 255, 187, 0),
					-- Visible = false,
				-- },
				-- Gui.Label
				-- {
					-- Size = Vector2(150, 22),
					-- Location = Vector2(108, 103),
					-- Text = lang:GetText("战队胜率:"),
					-- FontSize = 20,
					-- TextColor = ARGB(255, 0, 0, 0),
				-- },
				-- Gui.Label
				-- {
					-- Size = Vector2(150, 22),
					-- Location = Vector2(107, 102),
					-- Text = lang:GetText("战队胜率:"),
					-- FontSize = 20,
					-- TextColor = ARGB(255, 255, 103, 1),
				-- },
				-- Gui.Label "win_percent_black"
				-- {
					-- Size = Vector2(150, 22),
					-- Location = Vector2(207, 104),
					-- Text = "",
					-- FontSize = 20,
					-- TextColor = ARGB(255, 0, 0, 0),
				-- },
				-- Gui.Label "win_percent"
				-- {
					-- Size = Vector2(150, 22),
					-- Location = Vector2(206, 103),
					-- Text = "",
					-- FontSize = 20,
					-- TextColor = ARGB(255, 255, 187, 0),
				-- },
				-- Gui.Label
				-- {
					-- Size = Vector2(150, 22),
					-- Location = Vector2(47, 144),
					-- Text = lang:GetText("战队战胜负场次:"),
					-- FontSize = 20,
					-- TextColor = ARGB(255, 0, 0, 0),
				-- },
				-- Gui.Label
				-- {
					-- Size = Vector2(150, 22),
					-- Location = Vector2(46, 143),
					-- Text = lang:GetText("战队战胜负场次:"),
					-- FontSize = 20,
					-- TextColor = ARGB(255, 255, 103, 1),
				-- },
				-- Gui.Label "win_lose_black"
				-- {
					-- Size = Vector2(150, 22),
					-- Location = Vector2(207, 145),
					-- Text = "",
					-- FontSize = 20,
					-- TextColor = ARGB(255, 0, 0, 0),
				-- },
				-- Gui.Label "win_lose"
				-- {
					-- Size = Vector2(150, 22),
					-- Location = Vector2(206, 144),
					-- Text = "",
					-- FontSize = 20,
					-- TextColor = ARGB(255, 255, 187, 0),
				-- },
			-- },
			-- Gui.Control
			-- {
				-- Size = Vector2(538, 183),
				-- Location = Vector2(15, 205),
				-- BackgroundColor = ARGB(255, 255, 255, 255),
				-- Skin = Gui.ControlSkin
				-- {
					-- BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_task_bg_6.dds", Vector4(12, 10, 42, 40)),
				-- },
				-- Gui.Label
				-- {
					-- Size = Vector2(150, 20),
					-- Location = Vector2(20, 17),
					-- Text = lang:GetText("人数:"),
					-- FontSize = 20,
					-- TextColor = ARGB(255, 0, 0, 0),
				-- },
				-- Gui.Label
				-- {
					-- Size = Vector2(150, 20),
					-- Location = Vector2(19, 16),
					-- Text = lang:GetText("人数:"),
					-- FontSize = 20,
					-- TextColor = ARGB(255, 255, 103, 1),
				-- },
				-- Gui.Label "count_person_black"
				-- {
					-- Size = Vector2(300, 20),
					-- Location = Vector2(175, 18),
					-- Text = "",
					-- FontSize = 20,
					-- TextColor = ARGB(255, 0, 0, 0),
				-- },
				-- Gui.Label "count_person"
				-- {
					-- Size = Vector2(300, 20),
					-- Location = Vector2(174, 17),
					-- Text = "",
					-- FontSize = 20,
					-- TextColor = ARGB(255, 255, 187, 0),
				-- },
				-- Gui.Label
				-- {
					-- Size = Vector2(150, 30),
					-- Location = Vector2(20, 44),
					-- Text = lang:GetText("队长:"),
					-- FontSize = 20,
					-- TextColor = ARGB(255, 0, 0, 0),
				-- },
				-- Gui.Label
				-- {
					-- Size = Vector2(150, 30),
					-- Location = Vector2(19, 43),
					-- Text = lang:GetText("队长:"),
					-- FontSize = 20,
					-- TextColor = ARGB(255, 255, 103, 1),
				-- },
				-- Gui.Label "lead_black"
				-- {
					-- Size = Vector2(300, 30),
					-- Location = Vector2(175,47),
					-- Text = "",
					-- FontSize = 20,
					-- TextColor = ARGB(255, 0, 0, 0),
				-- },				
				-- Gui.Label "lead"
				-- {
					-- Size = Vector2(300, 30),
					-- Location = Vector2(174,46),
					-- Text = "",
					-- FontSize = 20,
					-- TextColor = ARGB(255, 255, 187, 0),
				-- },
				-- Gui.Label
				-- {
					-- Size = Vector2(150, 20),
					-- Location = Vector2(20, 83),
					-- Text = lang:GetText("创建日期:"),
					-- FontSize = 20,
					-- TextColor = ARGB(255, 0, 0, 0),
				-- },
				-- Gui.Label
				-- {
					-- Size = Vector2(150, 20),
					-- Location = Vector2(19, 82),
					-- Text = lang:GetText("创建日期:"),
					-- FontSize = 20,
					-- TextColor = ARGB(255, 255, 103, 1),
				-- },
				-- Gui.Label "time_black"
				-- {
					-- Size = Vector2(300, 20),
					-- Location = Vector2(175, 86),
					-- Text = "",
					-- FontSize = 20,
					-- TextColor = ARGB(255, 0, 0, 0),
				-- },				
				-- Gui.Label "time"
				-- {
					-- Size = Vector2(300, 20),
					-- Location = Vector2(174, 85),
					-- Text = "",
					-- FontSize = 20,
					-- TextColor = ARGB(255, 255, 187, 0),
				-- },
				-- Gui.Label
				-- {
					-- Size = Vector2(150, 20),
					-- Location = Vector2(20, 115),
					-- Text = lang:GetText("地区:"),
					-- FontSize = 20,
					-- TextColor = ARGB(255, 0, 0, 0),
				-- },
				-- Gui.Label
				-- {
					-- Size = Vector2(150, 20),
					-- Location = Vector2(19, 114),
					-- Text = lang:GetText("地区:"),
					-- FontSize = 20,
					-- TextColor = ARGB(255, 255, 103, 1),
				-- },
				-- Gui.Label "address_black"
				-- {
					-- Size = Vector2(300, 20),
					-- Location = Vector2(175, 119),
					-- Text = "",
					-- FontSize = 20,
					-- TextColor = ARGB(255, 0, 0, 0),
				-- },				
				-- Gui.Label "address"
				-- {
					-- Size = Vector2(300, 20),
					-- Location = Vector2(174, 118),
					-- Text = "",
					-- FontSize = 20,
					-- TextColor = ARGB(255, 255, 187, 0),
				-- },
				-- Gui.Label
				-- {
					-- Size = Vector2(150, 20),
					-- Location = Vector2(20, 148),
					-- Text = lang:GetText("加入条件:"),
					-- FontSize = 20,
					-- TextColor = ARGB(255, 0, 0, 0),
				-- },
				-- Gui.Label
				-- {
					-- Size = Vector2(150, 20),
					-- Location = Vector2(19, 147),
					-- Text = lang:GetText("加入条件:"),
					-- FontSize = 20,
					-- TextColor = ARGB(255, 255, 103, 1),
				-- },
				-- Gui.Label "level_black"
				-- {
					-- Size = Vector2(300, 20),
					-- Location = Vector2(175, 150),
					-- Text = "",
					-- FontSize = 20,
					-- TextColor = ARGB(255, 0, 0, 0),
				-- },
				-- Gui.Label "level"
				-- {
					-- Size = Vector2(300, 20),
					-- Location = Vector2(174, 149),
					-- Text = "",
					-- FontSize = 20,
					-- TextColor = ARGB(255, 255, 187, 0),
				-- },
			-- },
			Gui.Control
			{
				Size = Vector2(538, 182),
				Location = Vector2(15, 15),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_task_bg_6.dds", Vector4(12, 10, 42, 40)),
				},
				Gui.Control "team_image"
				{
					Size = Vector2(85, 88),
					Location = Vector2(14, 19),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_touxiang.dds", Vector4(0, 0, 0, 0)),
					},
				},
				Gui.Label
				{
					Size = Vector2(300, 30),
					Location = Vector2(108, 10),
					Text = lang:GetText("战队名称:"),
					FontSize = 18,
					TextColor = ARGB(255, 0, 0, 0),
					TextAlign = "kAlignLeftMiddle",
				},
				Gui.Label
				{
					Size = Vector2(300, 30),
					Location = Vector2(107, 9),
					Text = lang:GetText("战队名称:"),
					FontSize = 18,
					TextColor = ARGB(255, 255, 103, 1),
					TextAlign = "kAlignLeftMiddle",
				},
				Gui.Label "team_name_black"
				{
					Size = Vector2(280, 30),
					Location = Vector2(330, 9),
					Text = "",
					FontSize = 18,
					TextColor = ARGB(255, 0, 0, 0),
					TextAlign = "kAlignLeftMiddle",
				},
				Gui.Label "team_name"
				{
					Size = Vector2(280, 30),
					Location = Vector2(329, 8),
					Text = "",
					FontSize = 18,
					TextColor = ARGB(255, 255, 187, 0),
					TextAlign = "kAlignLeftMiddle",
				},
				Gui.Label
				{
					Size = Vector2(300, 30),
					Location = Vector2(108, 40),
					Text = lang:GetText("战队等级:"),
					FontSize = 18,
					TextColor = ARGB(255, 0, 0, 0),
					TextAlign = "kAlignLeftMiddle",
				},
				Gui.Label
				{
					Size = Vector2(300, 30),
					Location = Vector2(107, 39),
					Text = lang:GetText("战队等级:"),
					FontSize = 18,
					TextColor = ARGB(255, 255, 103, 1),
					TextAlign = "kAlignLeftMiddle",
				},
				Gui.Label "team_level_black"
				{
					Size = Vector2(30, 30),
					Location = Vector2(330, 39),
					Text = "",
					FontSize = 18,
					TextColor = ARGB(255, 0, 0, 0),
					TextAlign = "kAlignLeftMiddle",
				},
				Gui.Label "team_level"
				{
					Size = Vector2(30, 30),
					Location = Vector2(329, 38),
					Text = "",
					FontSize = 18,
					TextColor = ARGB(255, 255, 187, 0),
					TextAlign = "kAlignLeftMiddle",
				},
				Gui.Control "exp_back"
				{
					Size = Vector2(145, 19),
					Location = Vector2(375,47),
					BackgroundColor = ARGB(255, 255, 255, 255),
					-- Visible = false,
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_melting_bar01_bg.dds", Vector4(5, 5, 5, 5)),
					},
					Gui.Control "exp_font"
					{
						Size = Vector2(145, 19),
						Location = Vector2(0, 0),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_melting_bar01_content.dds", Vector4(5, 5, 5, 5)),
						},
					},
					Gui.Label "team_exp"
					{
						Size = Vector2(145, 19),
						Location = Vector2(0, 0),
						Text = "1/1",
						FontSize = 14,
						TextColor = ARGB(255, 214, 253, 255),
						TextAlign = "kAlignCenterMiddle",
					},
				},
				-- Gui.Label
				-- {
					-- Size = Vector2(150, 22),
					-- Location = Vector2(329, 104),
					-- Text = lang:GetText("战绩排名:"),
					-- FontSize = 20,
					-- TextColor = ARGB(255, 0, 0, 0),
				-- },
				-- Gui.Label
				-- {
					-- Size = Vector2(150, 22),
					-- Location = Vector2(328, 103),
					-- Text = lang:GetText("战绩排名:"),
					-- FontSize = 20,
					-- TextColor = ARGB(255, 255, 103, 1),
				-- },
				-- Gui.Label "team_num_black"
				-- {
					-- Size = Vector2(150, 22),
					-- Location = Vector2(436, 104),
					-- Text = "",
					-- FontSize = 20,
					-- TextColor = ARGB(255, 0, 0, 0),
				-- },
				-- Gui.Label "team_num"
				-- {
					-- Size = Vector2(150, 22),
					-- Location = Vector2(435, 103),
					-- Text = "",
					-- FontSize = 20,
					-- TextColor = ARGB(255, 255, 187, 0),
				-- },
				-- Gui.Control "team_num_up"
				-- {
					-- Size = Vector2(15, 24),
					-- Location = Vector2(500, 106),
					-- BackgroundColor = ARGB(255, 255, 255, 255),
					-- Skin = Gui.ControlSkin
					-- {
						-- BackgroundImage = Gui.Image("LobbyUI/ToolTips/lb_tooltips_jiantou_green.dds", Vector4(0, 0, 0, 0)),
					-- },
				-- },
				-- Gui.Label
				-- {
					-- Size = Vector2(150, 22),
					-- Location = Vector2(329, 144),
					-- Text = lang:GetText("战斗力排名:"),
					-- FontSize = 20,
					-- TextColor = ARGB(255, 0, 0, 0),
					-- Visible = false,
				-- },
				-- Gui.Label
				-- {
					-- Size = Vector2(150, 22),
					-- Location = Vector2(328, 143),
					-- Text = lang:GetText("战斗力排名:"),
					-- FontSize = 20,
					-- TextColor = ARGB(255, 255, 103, 1),
					-- Visible = false,
				-- },
				Gui.Label "team_fightnum_num"
				{
					Size = Vector2(150, 22),
					Location = Vector2(440, 144),
					Text = "",
					FontSize = 20,
					TextColor = ARGB(255, 255, 187, 0),
					Visible = false,
				},
				Gui.Control "team_fightnum_num_up"
				{
					Size = Vector2(15, 24),
					Location = Vector2(500, 144),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ToolTips/lb_tooltips_jiantou_green.dds", Vector4(0, 0, 0, 0)),
					},
					Visible = false,
				},
				Gui.Label
				{
					Size = Vector2(300, 22),
					Location = Vector2(108, 70),
					Text = lang:GetText("战队胜率:"),
					FontSize = 18,
					TextColor = ARGB(255, 0, 0, 0),
					TextAlign = "kAlignLeftMiddle",
				},
				Gui.Label
				{
					Size = Vector2(300, 22),
					Location = Vector2(107, 69),
					Text = lang:GetText("战队胜率:"),
					FontSize = 18,
					TextColor = ARGB(255, 255, 103, 1),
					TextAlign = "kAlignLeftMiddle",
				},
				Gui.Label "win_percent_black"
				{
					Size = Vector2(150, 22),
					Location = Vector2(330, 69),
					Text = "",
					FontSize = 18,
					TextColor = ARGB(255, 0, 0, 0),
					TextAlign = "kAlignLeftMiddle",
				},
				Gui.Label "win_percent"
				{
					Size = Vector2(150, 22),
					Location = Vector2(329, 68),
					Text = "",
					FontSize = 18,
					TextColor = ARGB(255, 255, 187, 0),
					TextAlign = "kAlignLeftMiddle",
				},
				Gui.Label
				{
					Size = Vector2(300, 22),
					Location = Vector2(108, 98),
					Text = lang:GetText("战队战胜负场次:"),
					FontSize = 18,
					TextColor = ARGB(255, 0, 0, 0),
					TextAlign = "kAlignLeftMiddle",
				},
				Gui.Label
				{
					Size = Vector2(300, 22),
					Location = Vector2(107, 97),
					Text = lang:GetText("战队战胜负场次:"),
					FontSize = 18,
					TextColor = ARGB(255, 255, 103, 1),
					TextAlign = "kAlignLeftMiddle",
				},
				Gui.Label "win_lose_black"
				{
					Size = Vector2(150, 22),
					Location = Vector2(330, 99),
					Text = "",
					FontSize = 18,
					TextColor = ARGB(255, 0, 0, 0),
					TextAlign = "kAlignLeftMiddle",
				},
				Gui.Label "win_lose"
				{
					Size = Vector2(150, 22),
					Location = Vector2(329, 98),
					Text = "",
					FontSize = 18,
					TextColor = ARGB(255, 255, 187, 0),
					TextAlign = "kAlignLeftMiddle",
				},
				Gui.Label
				{
					Size = Vector2(300, 30),
					Location = Vector2(108, 122),
					Text = lang:GetText("战斗力:"),
					FontSize = 18,
					TextColor = ARGB(255, 0, 0, 0),
					TextAlign = "kAlignLeftMiddle",
				},
				Gui.Label
				{
					Size = Vector2(300, 30),
					Location = Vector2(107, 121),
					Text = lang:GetText("战斗力:"),
					FontSize = 18,
					TextColor = ARGB(255, 255, 103, 1),
					TextAlign = "kAlignLeftMiddle",
				},
				Gui.Label "team_fightnum_black"
				{
					Size = Vector2(150, 30),
					Location = Vector2(330, 122),
					Text = "",
					FontSize = 18,
					TextColor = ARGB(255, 0, 0, 0),
					TextAlign = "kAlignLeftMiddle",
				},
				Gui.Label "team_fightnum"
				{
					Size = Vector2(150, 30),
					Location = Vector2(329, 121),
					Text = "",
					FontSize = 18,
					TextColor = ARGB(255, 255, 187, 0),
					TextAlign = "kAlignLeftMiddle",
				},
				Gui.Label
				{
					Size = Vector2(300, 22),
					Location = Vector2(108, 151),
					Text = lang:GetText("战绩排名:"),
					FontSize = 18,
					TextColor = ARGB(255, 0, 0, 0),
					TextAlign = "kAlignLeftMiddle",
				},
				Gui.Label
				{
					Size = Vector2(300, 22),
					Location = Vector2(107, 150),
					Text = lang:GetText("战绩排名:"),
					FontSize = 18,
					TextColor = ARGB(255, 255, 103, 1),
					TextAlign = "kAlignLeftMiddle",
				},
				Gui.Label "team_num_black"
				{
					Size = Vector2(150, 22),
					Location = Vector2(330, 152),
					Text = "",
					FontSize = 18,
					TextColor = ARGB(255, 0, 0, 0),
					TextAlign = "kAlignLeftMiddle",
				},
				Gui.Label "team_num"
				{
					Size = Vector2(150, 22),
					Location = Vector2(329, 151),
					Text = "",
					FontSize = 18,
					TextColor = ARGB(255, 255, 187, 0),
					TextAlign = "kAlignLeftMiddle",
				},
				Gui.Control "team_num_up"
				{
					Size = Vector2(15, 24),
					Location = Vector2(430, 153),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ToolTips/lb_tooltips_jiantou_green.dds", Vector4(0, 0, 0, 0)),
					},
				},
			},
			Gui.Control
			{
				Size = Vector2(538, 183),
				Location = Vector2(15, 205),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_task_bg_6.dds", Vector4(12, 10, 42, 40)),
				},
				Gui.Label
				{
					Size = Vector2(190, 30),
					Location = Vector2(9, 15),
					Text = lang:GetText("人数:"),
					FontSize = 20,
					TextColor = ARGB(255, 0, 0, 0),
					TextAlign = "kAlignLeftMiddle",
				},
				Gui.Label
				{
					Size = Vector2(190, 30),
					Location = Vector2(8, 14),
					Text = lang:GetText("人数:"),
					FontSize = 20,
					TextColor = ARGB(255, 255, 103, 1),
					TextAlign = "kAlignLeftMiddle",
				},
				Gui.Label "count_person_black"
				{
					Size = Vector2(330, 30),
					Location = Vector2(207, 15),
					Text = "",
					FontSize = 20,
					TextColor = ARGB(255, 0, 0, 0),
					TextAlign = "kAlignLeftMiddle",
				},
				Gui.Label "count_person"
				{
					Size = Vector2(330, 30),
					Location = Vector2(206, 14),
					Text = "",
					FontSize = 20,
					TextColor = ARGB(255, 255, 187, 0),
					TextAlign = "kAlignLeftMiddle",
				},
				Gui.Label
				{
					Size = Vector2(190, 30),
					Location = Vector2(9, 47),
					Text = lang:GetText("队长:"),
					FontSize = 20,
					TextColor = ARGB(255, 0, 0, 0),
					TextAlign = "kAlignLeftMiddle",
				},
				Gui.Label
				{
					Size = Vector2(190, 30),
					Location = Vector2(8, 46),
					Text = lang:GetText("队长:"),
					FontSize = 20,
					TextColor = ARGB(255, 255, 103, 1),
					TextAlign = "kAlignLeftMiddle",
				},
				Gui.Label "lead_black"
				{
					Size = Vector2(330, 30),
					Location = Vector2(207,47),
					Text = "",
					FontSize = 20,
					TextColor = ARGB(255, 0, 0, 0),
					TextAlign = "kAlignLeftMiddle",
				},
				Gui.Label "lead"
				{
					Size = Vector2(330, 30),
					Location = Vector2(207,46),
					Text = "",
					FontSize = 20,
					TextColor = ARGB(255, 255, 187, 0),
					TextAlign = "kAlignLeftMiddle",
				},
				Gui.Label
				{
					Size = Vector2(190, 30),
					Location = Vector2(8, 79),
					Text = lang:GetText("创建日期:"),
					FontSize = 20,
					TextColor = ARGB(255, 0, 0, 0),
					TextAlign = "kAlignLeftMiddle",
				},
				Gui.Label
				{
					Size = Vector2(190, 30),
					Location = Vector2(7, 78),
					Text = lang:GetText("创建日期:"),
					FontSize = 20,
					TextColor = ARGB(255, 255, 103, 1),
					TextAlign = "kAlignLeftMiddle",
				},
				Gui.Label "time_black"
				{
					Size = Vector2(330, 30),
					Location = Vector2(207, 79),
					Text = "",
					FontSize = 20,
					TextColor = ARGB(255, 0, 0, 0),
					TextAlign = "kAlignLeftMiddle",
				},
				Gui.Label "time"
				{
					Size = Vector2(330, 30),
					Location = Vector2(206, 78),
					Text = "",
					FontSize = 20,
					TextColor = ARGB(255, 255, 187, 0),
					TextAlign = "kAlignLeftMiddle",
				},
				Gui.Label
				{
					Size = Vector2(190, 30),
					Location = Vector2(8, 108),
					Text = lang:GetText("地区:"),
					FontSize = 20,
					TextColor = ARGB(255, 0, 0, 0),
					TextAlign = "kAlignLeftMiddle",
				},
				Gui.Label
				{
					Size = Vector2(190, 30),
					Location = Vector2(7, 107),
					Text = lang:GetText("地区:"),
					FontSize = 20,
					TextColor = ARGB(255, 255, 103, 1),
					TextAlign = "kAlignLeftMiddle",
				},
				Gui.Label "address_black"
				{
					Size = Vector2(330, 30),
					Location = Vector2(207, 108),
					Text = "",
					FontSize = 20,
					TextColor = ARGB(255, 0, 0, 0),
					TextAlign = "kAlignLeftMiddle",
				},
				Gui.Label "address"
				{
					Size = Vector2(330, 30),
					Location = Vector2(206, 107),
					Text = "",
					FontSize = 20,
					TextColor = ARGB(255, 255, 187, 0),
					TextAlign = "kAlignLeftMiddle",
				},
				Gui.Label
				{
					Size = Vector2(190, 30),
					Location = Vector2(8, 137),
					Text = lang:GetText("加入条件:"),
					FontSize = 20,
					TextColor = ARGB(255, 0, 0, 0),
					TextAlign = "kAlignLeftMiddle",
				},
				Gui.Label
				{
					Size = Vector2(190, 30),
					Location = Vector2(7, 136),
					Text = lang:GetText("加入条件:"),
					FontSize = 20,
					TextColor = ARGB(255, 255, 103, 1),
					TextAlign = "kAlignLeftMiddle",
				},
				Gui.Label "level_black"
				{
					Size = Vector2(330, 30),
					Location = Vector2(207, 137),
					Text = "",
					FontSize = 20,
					TextColor = ARGB(255, 0, 0, 0),
					TextAlign = "kAlignLeftMiddle",
				},
				Gui.Label "level"
				{
					Size = Vector2(330, 30),
					Location = Vector2(206, 136),
					Text = "",
					FontSize = 20,
					TextColor = ARGB(255, 255, 187, 0),
					TextAlign = "kAlignLeftMiddle",
				},
			},
			Gui.Control
			{
				Size = Vector2(489, 380),
				Location = Vector2(570, 10),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Gui.Button "jieshao_btn"
				{
					Size = Vector2(166, 44),
					Location = Vector2(0, 3),
					Text = lang:GetText("战队介绍"),
					TextAlign = "kAlignCenterMiddle",
					FontSize = 14,
					TextColor = ARGB(255, 148, 115, 78),
					HighlightTextColor = ARGB(255, 255, 205, 69),
					PushDown = true,
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_tab_v2_normal.dds", Vector4(0, 0, 0, 0)),
						HoverImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_tab_v2_hover.dds", Vector4(0, 0, 0, 0)),
						DownImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_tab_v2_down.dds", Vector4(0, 0, 0, 0)),
						DisabledImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_tab_v2_normal.dds", Vector4(0, 0, 0, 0)),
					},
					EventClick = function()
						t_info.c_jieshao.Visible = true
						t_info.c_zhanji.Visible = false
						t_info.c_gonggao.Visible = false
						t_info.jieshao_btn.PushDown = true
						t_info.zhanji_btn.PushDown = false
						t_info.gonggao_btn.PushDown = false
					end
				},
				Gui.Button "zhanji_btn"
				{
					Size = Vector2(166, 44),
					Location = Vector2(160, 3),
					Text = lang:GetText("最近战绩"),
					TextAlign = "kAlignCenterMiddle",
					FontSize = 14,
					TextColor = ARGB(255, 148, 115, 78),
					HighlightTextColor = ARGB(255, 255, 205, 69),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_tab_v2_normal.dds", Vector4(0, 0, 0, 0)),
						HoverImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_tab_v2_hover.dds", Vector4(0, 0, 0, 0)),
						DownImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_tab_v2_down.dds", Vector4(0, 0, 0, 0)),
						DisabledImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_tab_v2_normal.dds", Vector4(0, 0, 0, 0)),
					},
					EventClick = function()
						t_info.c_jieshao.Visible = false
						t_info.c_zhanji.Visible = true
						t_info.c_gonggao.Visible = false
						t_info.jieshao_btn.PushDown = false
						t_info.zhanji_btn.PushDown = true
						t_info.gonggao_btn.PushDown = false
						FillOtherTeamZhanJi()
					end
				},
				Gui.Button "gonggao_btn"
				{
					Size = Vector2(166, 44),
					Location = Vector2(320, 3),
					Text = lang:GetText("战队公告"),
					TextAlign = "kAlignCenterMiddle",
					FontSize = 14,
					TextColor = ARGB(255, 148, 115, 78),
					HighlightTextColor = ARGB(255, 255, 205, 69),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_tab_v2_normal.dds", Vector4(0, 0, 0, 0)),
						HoverImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_tab_v2_hover.dds", Vector4(0, 0, 0, 0)),
						DownImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_tab_v2_down.dds", Vector4(0, 0, 0, 0)),
						DisabledImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_tab_v2_normal.dds", Vector4(0, 0, 0, 0)),
					},
					EventClick = function()
						t_info.c_jieshao.Visible = false
						t_info.c_zhanji.Visible = false
						t_info.c_gonggao.Visible = true
						t_info.jieshao_btn.PushDown = false
						t_info.zhanji_btn.PushDown = false
						t_info.gonggao_btn.PushDown = true
						FillOtherTeamGongGao()
					end
				},
				Gui.Control "c_jieshao"
				{
					Size = Vector2(489, 335),
					Location = Vector2(0, 43),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_task_bg_6.dds", Vector4(12, 10, 42, 40)),
					},
					Gui.Control
					{
						Size = Vector2(448, 287),
						Location = Vector2(15, 21),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_rank_bg_01.dds", Vector4(34, 34, 34, 34)),
						},
						Gui.Label 
						{
							Size = Vector2(400, 30),
							Location = Vector2(16, 16),
							Text = lang:GetText("战队介绍:"),
							FontSize = 24,
							TextColor = ARGB(255, 0, 0, 0),
							TextAlign = "kAlignLeftMiddle",
						},
						Gui.Label 
						{
							Size = Vector2(400, 30),
							Location = Vector2(15, 15),
							Text = lang:GetText("战队介绍:"),
							FontSize = 24,
							TextColor = ARGB(255, 255, 103, 1),
							TextAlign = "kAlignLeftMiddle",
						},
						Gui.TextArea "jieshao"
						{
							Readonly = true,
							Size = Vector2(463, 300),
							Location = Vector2(15, 49),
							Text = "",
							FontSize = 20,
							Fold = true,
							TextColor = ARGB(255, 255, 187, 0),
							VScrollBarWidth = 40,
							VScrollBarButtonSize = 45,
							Skin = Gui.ScrollableControlSkin
							{
								UpButtonNormalImage = Gui.Image("DefaultSkin/ScrollableControlNew/lb_common_crollbar01_t_normal.tga", Vector4(0, 0, 0, 0)),
								UpButtonHoverImage = Gui.Image("DefaultSkin/ScrollableControlNew/lb_common_crollbar01_t_hover.tga", Vector4(0, 0, 0, 0)),
								UpButtonDownImage = Gui.Image("DefaultSkin/ScrollableControlNew/lb_common_crollbar01_t_down.tga", Vector4(0, 0, 0, 0)),
								UpButtonDisabledImage = nil,

								DownButtonNormalImage = Gui.Image("DefaultSkin/ScrollableControlNew/lb_common_crollbar01_b_normal.tga", Vector4(0, 0, 0, 0)),
								DownButtonHoverImage = Gui.Image("DefaultSkin/ScrollableControlNew/lb_common_crollbar01_b_hover.tga", Vector4(0, 0, 0, 0)),
								DownButtonDownImage = Gui.Image("DefaultSkin/ScrollableControlNew/lb_common_crollbar01_b_down.tga", Vector4(0, 0, 0, 0)),
								DownButtonDisabledImage = nil,

								VSliderNormalImage = Gui.Image("DefaultSkin/ScrollableControlNew/lb_common_scrollbar01_slider_normal.tga", Vector4(0, 14, 0, 14)),
								VSliderHoverImage = Gui.Image("DefaultSkin/ScrollableControlNew/lb_common_scrollbar01_slider_hover.tga", Vector4(0, 14, 0, 14)),
								VSliderDownImage = Gui.Image("DefaultSkin/ScrollableControlNew/lb_common_scrollbar01_slider_down.tga", Vector4(0, 14, 0, 14)),
								VSliderDisabledImage = nil,

								VBarBackgroundImage = Gui.Image("DefaultSkin/ScrollableControlNew/lb_common_scrollbar01_bg.tga", Vector4(0, 55, 0, 55)),
								VBarDisabledBackgroundImage = nil,
								BarCornerImage = nil,
							},
						},
					},
				},
				
				Gui.Control "c_zhanji"
				{
					Size = Vector2(489, 335),
					Location = Vector2(0, 43),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Visible = false,
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_task_bg_6.dds", Vector4(12, 10, 42, 40)),
					},
					Gui.ScrollableControl "scroll_zhanji"
					{
						Size = Vector2(460, 305),
						Location = Vector2(15, 13),
						AutoScroll = true,
						--VScrollBarPos = Vector2(-40,0),
						--Default_Width = 60,
						--Default_Size = 60,
						VScrollBarButtonSize = 16,
						VScrollBarWidth = 16,
						VScrollBarHeight = 290,
						VScrollBarDisplay = true,
						AutoScrollMinSize = Vector2(120,305),
						BackgroundColor = ARGB(255,255,255,255),
						Skin = Gui.ScrollableControlSkin
						{
							UpButtonNormalImage = Gui.Image("LobbyUI/team/NewFight/lb_battlefield_scrollbar_button_01_normal.dds", Vector4(0, 0, 0, 0)),
							UpButtonHoverImage = Gui.Image("LobbyUI/team/NewFight/lb_battlefield_scrollbar_button_01_hover.dds", Vector4(0, 0, 0, 0)),
							UpButtonDownImage = Gui.Image("LobbyUI/team/NewFight/lb_battlefield_scrollbar_button_01_down.dds", Vector4(0, 0, 0, 0)),
							UpButtonDisabledImage = Gui.Image("LobbyUI/team/NewFight/lb_battlefield_scrollbar_button_01_normal.dds", Vector4(0, 0, 0, 0)),

							DownButtonNormalImage = Gui.Image("LobbyUI/team/NewFight/lb_battlefield_scrollbar_button_02_normal.dds", Vector4(0, 0, 0, 0)),
							DownButtonHoverImage = Gui.Image("LobbyUI/team/NewFight/lb_battlefield_scrollbar_button_02_hover.dds", Vector4(0, 0, 0, 0)),
							DownButtonDownImage = Gui.Image("LobbyUI/team/NewFight/lb_battlefield_scrollbar_button_02_down.dds", Vector4(0, 0, 0, 0)),
							DownButtonDisabledImage = Gui.Image("LobbyUI/team/NewFight/lb_battlefield_scrollbar_button_02_normal.dds", Vector4(0, 0, 0, 0)),
							
							VSliderNormalImage = Gui.Image("LobbyUI/team/NewFight/lb_battlefield_scrollbar_button_03_normal.dds", Vector4(3, 4, 5, 5)),
							VSliderHoverImage = Gui.Image("LobbyUI/team/NewFight/lb_battlefield_scrollbar_button_03_hover.dds", Vector4(3, 4, 5, 5)),
							VSliderDownImage = Gui.Image("LobbyUI/team/NewFight/lb_battlefield_scrollbar_button_03_down.dds", Vector4(3, 4, 5, 5)),
							VSliderDisabledImage = Gui.Image("LobbyUI/team/NewFight/lb_battlefield_scrollbar_button_03_normal.dds", Vector4(3, 4, 5, 5)),

							VBarBackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_battlefield_scrollbar_bg.dds", Vector4(3, 4, 5, 5)),
							BarCornerImage = nil,
						},
						
						Gui.FlowLayout "scrollLayout_zhanji"
						{
							AutoSize = true,
							LineSpace = 5,
						},
					},
				},
				
				Gui.Control "c_gonggao"
				{
					Size = Vector2(489, 335),
					Location = Vector2(0, 43),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Visible = false,
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_task_bg_6.dds", Vector4(12, 10, 42, 40)),
					},
					Gui.Label 
					{
						Size = Vector2(300, 37),
						Location = Vector2(16, 14),
						Text = lang:GetText("战队公告:"),
						FontSize = 24,
						TextColor = ARGB(255, 0, 0, 0),
					},
					Gui.Label 
					{
						Size = Vector2(300, 37),
						Location = Vector2(15, 13),
						Text = lang:GetText("战队公告:"),
						FontSize = 24,
						TextColor = ARGB(255, 255, 103, 1),
					},
					
					Gui.Textbox "t_gonggao"
					{
						Size = Vector2(300,37),
						Location = Vector2(125, 13),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_rank_bg_01.dds", Vector4(34, 34, 34, 34)),
						},
						Visible = false,
						TabFocus = true,
						MaxLength = 64,
						TextColor = ARGB(255, 255, 187, 0),
					},
					
					Gui.Button "send_btn"
					{
						Size = Vector2(50, 37),
						Location = Vector2(430, 13),
						Text = lang:GetText("发送"),
						TextAlign = "kAlignCenterMiddle",
						FontSize = 20,
						TextColor = ARGB(255, 0, 0, 0),
						HighlightTextColor = ARGB(255, 0, 0, 0),
						Padding = Vector4(0, 0, 0, 5),
						Visible = false,
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_v2_01_normal.dds", Vector4(0, 0, 0, 0)),
							HoverImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_v2_01_hover.dds", Vector4(0, 0, 0, 0)),
							DownImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_v2_01_down.dds", Vector4(0, 0, 0, 0)),
							DisabledImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_v2_01_disabled.dds", Vector4(0, 0, 0, 0)),
						},
						EventClick = function()
							local gonggao = team_ui.t_gonggao.Text
							rpc.safecallload("team_proclamation_create", {pid = ptr_cast(game.CurrentState):GetCharacterId() , ptid = pt_id , tid = t_id , content = gonggao},
							function(data)
								if data.result == 1 then
									MessageBox.ShowWithTimer(2,lang:GetText("发送成功"))											
									-- FillGongGao()	
								else
									MessageBox.ShowWithTimer(2,lang:GetText("发送失败"))			
								end	
							end)
						end
					},
					
					Gui.ScrollableControl "scroll_gonggao"
					{
						Size = Vector2(465, 266),
						Location = Vector2(15, 55),
						AutoScroll = true,
						--VScrollBarPos = Vector2(-40,0),
						--Default_Width = 60,
						--Default_Size = 60,
						VScrollBarButtonSize = 16,
						VScrollBarWidth = 16,
						VScrollBarHeight = 250,
						VScrollBarDisplay = true,
						AutoScrollMinSize = Vector2(120,270),
						BackgroundColor = ARGB(255,255,255,255),
						Skin = Gui.ScrollableControlSkin
						{
							UpButtonNormalImage = Gui.Image("LobbyUI/team/NewFight/lb_battlefield_scrollbar_button_01_normal.dds", Vector4(0, 0, 0, 0)),
							UpButtonHoverImage = Gui.Image("LobbyUI/team/NewFight/lb_battlefield_scrollbar_button_01_hover.dds", Vector4(0, 0, 0, 0)),
							UpButtonDownImage = Gui.Image("LobbyUI/team/NewFight/lb_battlefield_scrollbar_button_01_down.dds", Vector4(0, 0, 0, 0)),
							UpButtonDisabledImage = Gui.Image("LobbyUI/team/NewFight/lb_battlefield_scrollbar_button_01_normal.dds", Vector4(0, 0, 0, 0)),

							DownButtonNormalImage = Gui.Image("LobbyUI/team/NewFight/lb_battlefield_scrollbar_button_02_normal.dds", Vector4(0, 0, 0, 0)),
							DownButtonHoverImage = Gui.Image("LobbyUI/team/NewFight/lb_battlefield_scrollbar_button_02_hover.dds", Vector4(0, 0, 0, 0)),
							DownButtonDownImage = Gui.Image("LobbyUI/team/NewFight/lb_battlefield_scrollbar_button_02_down.dds", Vector4(0, 0, 0, 0)),
							DownButtonDisabledImage = Gui.Image("LobbyUI/team/NewFight/lb_battlefield_scrollbar_button_02_normal.dds", Vector4(0, 0, 0, 0)),
							
							VSliderNormalImage = Gui.Image("LobbyUI/team/NewFight/lb_battlefield_scrollbar_button_03_normal.dds", Vector4(3, 4, 5, 5)),
							VSliderHoverImage = Gui.Image("LobbyUI/team/NewFight/lb_battlefield_scrollbar_button_03_hover.dds", Vector4(3, 4, 5, 5)),
							VSliderDownImage = Gui.Image("LobbyUI/team/NewFight/lb_battlefield_scrollbar_button_03_down.dds", Vector4(3, 4, 5, 5)),
							VSliderDisabledImage = Gui.Image("LobbyUI/team/NewFight/lb_battlefield_scrollbar_button_03_normal.dds", Vector4(3, 4, 5, 5)),

							VBarBackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_battlefield_scrollbar_bg.dds", Vector4(3, 4, 5, 5)),
							BarCornerImage = nil,
						},
						
						Gui.FlowLayout "scrollLayout_gonggao"
						{
							AutoSize = true,
							LineSpace = 0,
						},
					},
				},
			},
			Gui.Button "btn_touch_header"
			{
				--Enable = false,
				Size = Vector2(224, 44),
				Location = Vector2(287, 409),
				--FontSize = 20,
				Text = lang:GetText("联系队长"),
				Padding = Vector4(0, 0, 0, 7),
				TextColor = ARGB(255, 211, 211, 211),
				HighlightTextColor = ARGB(255, 211, 211, 211),
				TextAlign = "kAlignCenterMiddle",
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_normal.dds", Vector4(32, 0, 32, 0)),
					HoverImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_hover.dds", Vector4(32, 0, 32, 0)),
					DownImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_down.dds", Vector4(32, 0, 32, 0)),
					DisabledImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_disabled.dds", Vector4(32, 0, 32, 0)),		
				},
				EventClick = function()
					L_LobbyMain.ChatPrivate(lead_name,lead_vip)
					t_info_ui.Close()
					t_info_ui = nil
				end
			},
			Gui.Button "btn_application"
			{
				Size = Vector2(224, 44),
				Location = Vector2(608, 409),
				Text = lang:GetText("申请加入"),
				Padding = Vector4(0, 0, 0, 7),
				TextColor = ARGB(255, 211, 211, 211),
				HighlightTextColor = ARGB(255, 211, 211, 211),
				TextAlign = "kAlignCenterMiddle",
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_normal.dds", Vector4(32, 0, 32, 0)),
					HoverImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_hover.dds", Vector4(32, 0, 32, 0)),
					DownImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_down.dds", Vector4(32, 0, 32, 0)),
					DisabledImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_disabled.dds", Vector4(32, 0, 32, 0)),		
				},
				EventClick = function()
					rpc.safecallload("team_request_op", {tid = tid_of_list, pid = ptr_cast(game.CurrentState):GetCharacterId(), pids  = ptr_cast(game.CurrentState):GetCharacterId(), action = "join"},
					function(data)
						MessageBox.ShowWithConfirm(lang:GetText("申请成功！\n（同时申请多个战队时只有最后一次申请有效）"))
					end)
				end
			},
		},
	},
}

Image_team = Gui.Create()
{
	Gui.Control "root"
	{
		Size = Vector2(487, 676),
		Location = Vector2(0, 0),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_contact_bg1_01.dds", Vector4(163,163,53,53)),
		},
		Gui.Label
		{
			Size = Vector2(150, 50),
			Location = Vector2(28, 22),
			BackgroundColor = ARGB(0, 255, 255, 255),
			FontSize = 24,
			TextColor = ARGB(255, 0, 0, 0),
			Text = lang:GetText("战队头像："),
		},
		Gui.Label
		{
			Size = Vector2(150, 50),
			Location = Vector2(27, 21),
			BackgroundColor = ARGB(0, 255, 255, 255),
			FontSize = 24,
			TextColor = ARGB(255, 255, 103, 1),
			Text = lang:GetText("战队头像："),
		},
		Gui.Control
		{
			Size = Vector2(443, 588),
			Location = Vector2(21, 66),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_contact_bg2.dds", Vector4(38, 41, 38, 66)),	
			},
			Gui.Control
			{
				Size = Vector2(433, 500),
				Location = Vector2(5, 5),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_rank_bg_01.dds", Vector4(34, 34, 34, 34)),
				},
				Gui.ImageBrowser "ib_image"
				{
					Size = Vector2(443, 500),
					Location = Vector2(0, 30),
					-- Dock = "kDockFill",
					DisplayRowAndCol = Vector2(13, 11),
					PictureStyle = "Gui.ZhanduiPictureMapInBrowser",
					
					PWidth = 86,
					PHeight = 86,
				},
				
				Gui.Button "m_Left"
				{	
					Size = Vector2(69, 33),
					Visible = true,
					Location = Vector2(104,439),
					TextColor = ARGB(255, 209, 227, 221),
					Text = lang:GetText("上一页"),
					
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_page_normal.dds", Vector4(5, 5, 10, 5)),
						HoverImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_page_hover.dds", Vector4(5, 5, 10, 5)),
						DownImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_page_down.dds", Vector4(5, 5, 10, 5)),
						DisabledImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_page_bg.dds", Vector4(5, 5, 10, 5)),
					},
				},
				
				Gui.Button "m_Right"
				{
					Size = Vector2(69, 33),
					Visible = true,
					Location = Vector2(258,439),
					TextColor = ARGB(255, 209, 227, 221),
					Text = lang:GetText("下一页"),
					
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_page_normal.dds", Vector4(5, 5, 10, 5)),
						HoverImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_page_hover.dds", Vector4(5, 5, 10, 5)),
						DownImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_page_down.dds", Vector4(5, 5, 10, 5)),
						DisabledImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_page_bg.dds", Vector4(5, 5, 10, 5)),
					},

				},
				
				Gui.Button "m_PageDisplay"
				{
					Size = Vector2(80,33),
					FontSize = 24,
					Visible = true,
					Location = Vector2(175,439),
					TextColor = ARGB(255, 37, 37, 37),
					HighlightTextColor = ARGB(255, 37, 37, 37),
					TextAlign = "kAlignCenterMiddle",
					Text = "1/1",
					BackgroundColor = ARGB(255, 255, 255, 255),
					
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/lb_common_fanye_down.tga", Vector4(5, 5, 10, 5)),
						--HoverImage = Gui.Image("LobbyUI/team/lb_common_fanye_down.tga", Vector4(5, 5, 10, 5)),
						--DownImage = Gui.Image("LobbyUI/team/lb_common_fanye_down.tga", Vector4(5, 5, 10, 5)),
						DisabledImage = Gui.Image("LobbyUI/team/lb_common_fanye_down.tga", Vector4(5, 5, 10, 5)),
					},
				},
			},
			--完成
			Gui.Button "b_create"
			{
				Size = Vector2(124,44),
				Location = Vector2(49, 536),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Text = lang:GetText("完成"),
				TextColor = ARGB(255, 226, 217, 208),
				TextAlign = "kAlignCenterMiddle",
				-- HighlightTextColor = ARGB(255, 229, 255, 252),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_normal.dds", Vector4(32, 0, 32, 0)),
					HoverImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_hover.dds", Vector4(32, 0, 32, 0)),
					DownImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_down.dds", Vector4(32, 0, 32, 0)),
					DisabledImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_disabled.dds", Vector4(32, 0, 32, 0)),
				},
				EventClick = function()
					Image_team_ui.Close()
					Image_team_ui = nil
					selsect_image_id = image_id
					register_team.zhandui_touxiang.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/team/FightHead/lb_squad_touxiang_"..image_id..".dds",Vector4(0,0,0,0)),}
					register_team.root.Parent = register_team_ui.root
				end
			},
			--取消
			Gui.Button "b_cancel"
			{
				Size = Vector2(124,44),
				Location = Vector2(270, 536),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Text = lang:GetText("取消"),
				TextColor = ARGB(255, 226, 217, 208),
				TextAlign = "kAlignCenterMiddle",
				-- HighlightTextColor = ARGB(255, 229, 255, 252),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_normal.dds", Vector4(32, 0, 32, 0)),
					HoverImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_hover.dds", Vector4(32, 0, 32, 0)),
					DownImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_down.dds", Vector4(32, 0, 32, 0)),
					DisabledImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_disabled.dds", Vector4(32, 0, 32, 0)),
				},
				EventClick = function()
					Image_team_ui.Close()
					Image_team_ui = nil
				end
			},
		},
	},
}

register_team = Gui.Create()
{
	Gui.Control "root"
	{
		Size = Vector2(605, 676),
		Location = Vector2(0, 0),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_contact_bg1_01.dds", Vector4(163,163,53,53)),
		},
		Gui.Control
		{
			Size = Vector2(557, 632),
			Location = Vector2(24, 23),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_contact_bg2.dds", Vector4(38, 41, 38, 66)),	
			},
			Gui.Label
			{
				Size = Vector2(200, 25),
				Location = Vector2(12, 49),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Text = lang:GetText("战队图标："),
				FontSize = 20,
				TextColor = ARGB(255, 0, 0, 0),
			},
			Gui.Label
			{
				Size = Vector2(200, 25),
				Location = Vector2(11, 48),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Text = lang:GetText("战队图标："),
				FontSize = 20,
				TextColor = ARGB(255, 255, 103, 1),
			},
			
			Gui.Control
			{
				Size = Vector2(85, 87),
				Location = Vector2(222, 25),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_contact_bg_normal.dds", Vector4(5, 5, 5, 5)),	
				},
				Gui.Control "zhandui_touxiang"
				{
					Size = Vector2(69, 71),
					Location = Vector2(8, 8),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/FightHead/lb_squad_touxiang_1.dds",Vector4(0,0,0,0)),	
					},
				},
			},
			
			--修改
			Gui.Button
			{
				Size = Vector2(166,37),
				Location = Vector2(311, 74),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Text = lang:GetText("修改"),
				TextColor = ARGB(255, 0, 0, 0),
				TextAlign = "kAlignCenterMiddle",
				-- HighlightTextColor = ARGB(255, 229, 255, 252),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_v2_01_normal.dds", Vector4(5, 5, 5, 5)),
					HoverImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_v2_01_hover.dds", Vector4(5, 5, 5, 5)),
					DownImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_v2_01_down.dds", Vector4(5, 5, 5, 5)),
					DisabledImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_v2_01_disabled.dds", Vector4(5, 5, 5, 5)),
				},
				EventClick = function()
					-- register_team_ui.Close()
					-- register_team_ui = nil
					Image_team_ui = ModalWindow.GetNew()
					Image_team_ui.root.Size = Vector2(487, 676)
					Image_team_ui.AllowEscToExit = false
					Image_team.root.Parent = Image_team_ui.root
					Gui.Align(Image_team.register, 0.5,0.5)
					for i = 1, 4 do
						for j = 1 , 4 do
							local pic = Image_team.ib_image:GetDisplayPicture(i,j)
							pic.ForeGroundImage = Gui.Image("LobbyUI/team/FightHead/lb_squad_touxiang_"..(i-1)*4+j..".dds",Vector4(0,0,0,0))
							pic.EventClick = function(sender, e)
								Image_team.ib_image:AllPictureHL(false)
								pic.Highlighted = true
								image_id = (i-1)*4+j
								print("image_id:"..image_id)
							end	
						end
					end
					Image_team.ib_image.LeftBtn.Visible = false
					Image_team.ib_image.RightBtn.Visible = false
				end
			},
			
			Gui.Label
			{
				Size = Vector2(200, 40),
				Location = Vector2(12, 131),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Text = lang:GetText("战队名称："),
				FontSize = 20,
				TextColor = ARGB(255, 0, 0, 0),
			},
			Gui.Label
			{
				Size = Vector2(200, 40),
				Location = Vector2(11, 130),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Text = lang:GetText("战队名称："),
				FontSize = 20,
				TextColor = ARGB(255, 255, 103, 1),
			},
			Gui.Textbox "team_name"
			{
				Size = Vector2(310, 38),
				Location = Vector2(222, 130),
				Text = "",
				TextColor = ARGB(255, 255, 187, 0),
				DisabledTextColor = ARGB(255, 37, 37, 37),
				BackgroundColor = ARGB(255, 255, 255, 255),
				FontSize = 18,
				-- MaxLength = 16,
				Skin = Gui.TextboxSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_contact_bg_normal.dds", Vector4(10, 10, 10, 10)),
					DisabledImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_contact_bg_disabled.dds", Vector4(10, 10, 10, 10)),
				},
				EventTextChanged = function()
					if (config:GetBattleGroupNameLengthMax() - game:TextLenght(register_team.team_name.Text)) > -1 then
						register_team.abcd.Text = lang:GetText("你还能输入")..(config:GetBattleGroupNameLengthMax() - game:TextLenght(register_team.team_name.Text))..lang:GetText("个字")
					else
						register_team.abcd.Text = lang:GetText("已超出")..(game:TextLenght(register_team.team_name.Text) - config:GetBattleGroupNameLengthMax())..lang:GetText("个字")
					end
				end
			},
			Gui.Label "abcd"
			{
				Size = Vector2(260,29),
				Location = Vector2(253, 172),
				BackgroundColor = ARGB(0, 255, 255, 255),
				TextAlign = "kAlignCenterMiddle",
				Text = lang:GetText("你还能输入  个字"),
				FontSize = 20,
				TextColor = ARGB(255, 255, 54, 0),
				Visible = false,
			},
			-- Gui.Label "geshu"
			-- {
				-- Size = Vector2(32,29),
				-- Location = Vector2(355, 172),
				-- BackgroundColor = ARGB(0, 255, 255, 255),
				-- TextAlign = "kAlignCenterMiddle",
				-- FontSize = 20,
				-- TextColor = ARGB(255, 255, 54, 0),
				-- Text = "8"
			-- },
			Gui.Label
			{
				Size = Vector2(200, 40),
				Location = Vector2(12, 214),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Text = lang:GetText("省："),
				FontSize = 20,
				TextColor = ARGB(255, 0, 0, 0),
			},
			Gui.Label
			{
				Size = Vector2(200, 40),
				Location = Vector2(11, 213),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Text = lang:GetText("省："),
				FontSize = 20,
				TextColor = ARGB(255, 255, 103, 1),
			},
			Gui.ComboBox "province"
			{
				Size = Vector2(310, 38),
				Location = Vector2(222, 213),		
				Readonly = true,
				Text = lang:GetText("上海市"),
				TextColor = ARGB(255, 255, 187, 0),
				DisabledTextColor = ARGB(255, 37, 37, 37),
				TextAlign = "kAlignCenterMiddle",
				Skin = Gui.ComboBoxSkin
				{
					ButtonNormalImage= Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_button_normal.dds", Vector4(0, 0, 0, 0)),
					ButtonHoverImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_button_hover.dds", Vector4(0, 0, 0, 0)),
					ButtonDownImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_button_down.dds", Vector4(0, 0, 0, 0)),
					ButtonDisabledImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_button_disabled.dds", Vector4(0, 0, 0, 0)),
					
					TextNormalImage= Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_text.dds", Vector4(6, 0, 0, 0)),
					TextHoverImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_text.dds", Vector4(6, 0, 0, 0)),
					TextDownImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_text.dds", Vector4(6, 0, 0, 0)),
					TextDisabledImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_text_disabled.dds", Vector4(6, 0, 0, 0)),
				},
				ChildComboListStyle =  "Gui.ChangeJobComboList",
				EventValueChanged = function()
					if not register_team.province.Enable then
						return
					end
					
					if register_team ~= nil then
						cbx = register_team.city
						cbx:RemoveAll()
						for _,v in ipairs(city[register_team.province.SelectedIndex + 1]) do
							cbx:AddItem( v )
						end
						register_team.city.Text = city[register_team.province.SelectedIndex + 1][1]
					end
				end
			},
			Gui.Label
			{
				Size = Vector2(200, 40),
				Location = Vector2(12, 269),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Text = lang:GetText("市："),
				FontSize = 20,
				TextColor = ARGB(255, 0, 0, 0),
			},
			Gui.Label
			{
				Size = Vector2(200, 40),
				Location = Vector2(11, 268),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Text = lang:GetText("市："),
				FontSize = 20,
				TextColor = ARGB(255, 255, 103, 1),
			},
			Gui.ComboBox "city"
			{
				Size = Vector2(310, 38),
				Location = Vector2(222, 268),		
				Readonly = true,
				Text = lang:GetText("上海市"),
				TextColor = ARGB(255, 255, 187, 0),
				DisabledTextColor = ARGB(255, 37, 37, 37),
				TextAlign = "kAlignCenterMiddle",
				Skin = Gui.ComboBoxSkin
				{
					ButtonNormalImage= Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_button_normal.dds", Vector4(0, 0, 0, 0)),
					ButtonHoverImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_button_hover.dds", Vector4(0, 0, 0, 0)),
					ButtonDownImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_button_down.dds", Vector4(0, 0, 0, 0)),
					ButtonDisabledImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_button_disabled.dds", Vector4(0, 0, 0, 0)),
					
					TextNormalImage= Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_text.dds", Vector4(6, 0, 0, 0)),
					TextHoverImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_text.dds", Vector4(6, 0, 0, 0)),
					TextDownImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_text.dds", Vector4(6, 0, 0, 0)),
					TextDisabledImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_text_disabled.dds", Vector4(6, 0, 0, 0)),
				},
				ChildComboListStyle =  "Gui.ChangeJobComboList",
			},
			Gui.Label
			{
				Size = Vector2(200, 40),
				Location = Vector2(12, 326),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Text = lang:GetText("加入条件："),
				FontSize = 20,
				TextColor = ARGB(255, 0, 0, 0),
			},
			Gui.Label
			{
				Size = Vector2(200, 40),
				Location = Vector2(11, 325),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Text = lang:GetText("加入条件："),
				FontSize = 20,
				TextColor = ARGB(255, 255, 103, 1),
			},
			Gui.ComboBox "rank"
			{
				Size = Vector2(310, 38),
				Location = Vector2(222, 325),		
				Readonly = true,
				Text = "1",
				TextColor = ARGB(255, 255, 187, 0),
				DisabledTextColor = ARGB(255, 255, 187, 0),
				Skin = Gui.ComboBoxSkin
				{
					ButtonNormalImage= Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_button_normal.dds", Vector4(0, 0, 0, 0)),
					ButtonHoverImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_button_hover.dds", Vector4(0, 0, 0, 0)),
					ButtonDownImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_button_down.dds", Vector4(0, 0, 0, 0)),
					
					TextNormalImage= Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_text.dds", Vector4(6, 0, 0, 0)),
					TextHoverImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_text.dds", Vector4(6, 0, 0, 0)),
					TextDownImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_text.dds", Vector4(6, 0, 0, 0)),
					
				},
				ChildComboListStyle =  "Gui.ChangeJobComboList",
			},
			-- Gui.Label
			-- {
				-- Size = Vector2(50, 40),
				-- Location = Vector2(381, 326),
				-- BackgroundColor = ARGB(0, 255, 255, 255),
				-- Text = lang:GetText("级"),
				-- FontSize = 24,
				-- TextColor = ARGB(255, 0, 0, 0),
			-- },
			-- Gui.Label
			-- {
				-- Size = Vector2(50, 40),
				-- Location = Vector2(380, 325),
				-- BackgroundColor = ARGB(0, 255, 255, 255),
				-- Text = lang:GetText("级"),
				-- FontSize = 24,
				-- TextColor = ARGB(255, 255, 103, 1),
			-- },
			Gui.Label
			{
				Size = Vector2(200, 40),
				Location = Vector2(12, 381),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Text = lang:GetText("战队介绍："),
				FontSize = 20,
				TextColor = ARGB(255, 0, 0, 0),
			},
			Gui.Label
			{
				Size = Vector2(200, 40),
				Location = Vector2(11, 380),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Text = lang:GetText("战队介绍："),
				FontSize = 20,
				TextColor = ARGB(255, 255, 103, 1),
			},
			Gui.TextArea "description"
			{
				Size = Vector2(310, 159),
				Location = Vector2(222, 380),
				Readonly = false,
				Fold = true,
				HScrollBarDisplay = "kHide",
				VScrollBarDisplay = "kHide",
				BackgroundColor = ARGB(255, 255, 255, 255),
				TextColor = ARGB(255, 255, 187, 0),
				MaxLength = 256,
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_contact_bg_normal.dds", Vector4(10, 10, 10, 10)),
				},
				EventTextChanged = function()		
					if (140 - game:TextLenght(register_team.description.Text)) > -1 then
						register_team.geshu2.Text = lang:GetText("你还能输入")..(140 - game:TextLenght(register_team.description.Text))..lang:GetText("个字")
					else
						register_team.geshu2.Text = lang:GetText("已超出")..(game:TextLenght(register_team.description.Text) - 140)..lang:GetText("个字")
					end
				end
			},
			
			Gui.Label "geshu2"
			{
				Size = Vector2(260,29),
				Location = Vector2(234, 541),
				BackgroundColor = ARGB(0, 255, 255, 255),
				TextAlign = "kAlignCenterMiddle",
				Text = lang:GetText("你还能输入    个字"),
				FontSize = 20,
				TextColor = ARGB(255, 255, 54, 0),
				Visible = false,
			},
			-- Gui.Label "geshu2"
			-- {
				-- Size = Vector2(32,29),
				-- Location = Vector2(340, 541),
				-- BackgroundColor = ARGB(0, 255, 255, 255),
				-- TextAlign = "kAlignCenterMiddle",
				-- FontSize = 20,
				-- TextColor = ARGB(255, 255, 54, 0),
				-- Text = "140"
			-- },
			
			--创建
			Gui.Button "b_create"
			{
				Size = Vector2(205,44),
				Location = Vector2(73, 580),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Text = lang:GetText("创建"),
				TextColor = ARGB(255, 226, 217, 208),
				TextAlign = "kAlignCenterMiddle",
				-- HighlightTextColor = ARGB(255, 229, 255, 252),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_normal.dds", Vector4(32, 0, 32, 0)),
					HoverImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_hover.dds", Vector4(32, 0, 32, 0)),
					DownImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_down.dds", Vector4(32, 0, 32, 0)),
					DisabledImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_disabled.dds", Vector4(32, 0, 32, 0)),
				},
				EventClick = function()
					if register_team.b_create.Text == lang:GetText("创建") then
						-- MessageBox.ShowWaiter(lang:GetText("正在创建..."))
						team_create_data.logo = selsect_image_id
						team_create_data.name = register_team.team_name.Text
						team_create_data.province = register_team.province.Text
						team_create_data.city = register_team.city.Text
						team_create_data.rank = register_team.rank.Text
						team_create_data.description = register_team.description.Text
						local Tepnum = string.find(team_create_data.name,"　")
						local namelen = game:TextLenght(team_create_data.name)
						if Tepnum then
							MessageBox.ShowWithTimer(2,lang:GetText("战队名不能包含空格"))
							return
						end
						if namelen < config:GetBattleGroupNameLengthMin() then
							MessageBox.ShowWithTimer(2,lang:GetText("战队名称过短！"))
							return
						elseif namelen > config:GetBattleGroupNameLengthMax() then
							MessageBox.ShowWithTimer(2,lang:GetText("战队名称过长！"))
							return
						end
						rpc.safecallload("team_create",team_create_data,
						function(data)
							if data.warning[1] == "" and data.warning[2] == "" then
								-- MessageBox.CloseWaiter()
								MessageBox.ShowWithConfirm(lang:GetText("创建成功"),
								function(sender,e)
									register_team_ui.Close()
									register_team_ui = nil
									if L_LobbyMain.LobbyMainWin_Boddy then
										Show(L_LobbyMain.LobbyMainWin_Boddy.LobbyMainWin_Boddy_Root)
									end
									L_LobbyMain.current_chosse_main_page = 2
									lg:SetLobbyModules(2)
									L_Friends.GetTeamInfo()
								end)
								gui:PlayAudio("kUIA_CREATE_TEAM")
							else
								MessageBox.CloseWaiter()
								if data.warning[1] ~= "" then
									MessageBox.ShowWithConfirm(data.warning[1],
									function(sender,e)
										-- Image_team_ui.Close()
										-- Image_team_ui = nil
									end)
								elseif data.warning[1] == "" then
									MessageBox.ShowWithConfirm(data.warning[2],
									function(sender,e)
										-- Image_team_ui.Close()
										-- Image_team_ui = nil
									end)
								end
							end
						end)
					elseif register_team.b_create.Text == lang:GetText("完成") then
						rpc.safecallload("team_update_op",{pid = ptr_cast(game.CurrentState):GetCharacterId(), tid = t_id , logo = selsect_image_id, rank = register_team.rank.Text, description = register_team.description.Text}, 
						function(datd)
							MessageBox.ShowWithTimer(1,lang:GetText("修改成功"))
							register_team_ui.Close()
							register_team_ui = nil
							FillTeam()
						end)
					end
				end
			},
			--取消
			Gui.Button "b_cancel"
			{
				Size = Vector2(205,44),
				Location = Vector2(298, 580),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Text = lang:GetText("取消"),
				TextColor = ARGB(255, 226, 217, 208),
				TextAlign = "kAlignCenterMiddle",
				-- HighlightTextColor = ARGB(255, 229, 255, 252),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_normal.dds", Vector4(32, 0, 32, 0)),
					HoverImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_hover.dds", Vector4(32, 0, 32, 0)),
					DownImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_down.dds", Vector4(32, 0, 32, 0)),
					DisabledImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_disabled.dds", Vector4(32, 0, 32, 0)),
				},
				EventClick = function()
					if register_team_ui then
						register_team_ui.Close()
						register_team_ui = nil
					end
				end
			},
		},
	},
}

revise_team_Image = Gui.Create()
{
	Gui.Control "root"
	{
		Size = Vector2(1200, 900),
		Location = Vector2(0, 0),
		BackgroundColor = ARGB(0, 255, 255, 255),
		Gui.Control "register"
		{
			Size = Vector2(477, 441),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_contact_bg1_01.dds", Vector4(163,163,53,53)),
			},
			Gui.Control
			{
				Size = Vector2(447, 366),
				Location = Vector2(14, 60),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/lb_contact_bg2.dds", Vector4(16, 12, 16, 45)),
				},
				Gui.ImageBrowser "ib_image"
				{
					Size = Vector2(447, 366),
					Location = Vector2(-10, 30),
					--Dock = "kDockFill",
					DisplayRowAndCol = Vector2(13, 11),
					PictureStyle = "Gui.ZhanduiPictureMapInBrowser",
					PWidth = 72,
					PHeight = 72,
				},
			},
			Gui.Label
			{
				Size = Vector2(100, 20),
				Location = Vector2(18, 30),
				Text = lang:GetText("战队头像"),
				FontSize = 20,
				TextColor = ARGB(255, 52, 50, 50),
			},
			Gui.Button 
			{
				Size = Vector2(104, 36),
				Location = Vector2(122, 383),
				Text = lang:GetText("完成"),
				TextColor = ARGB(255, 211, 211, 211),
				HighlightTextColor = ARGB(255, 211, 211, 211),
				TextAlign = "kAlignCenterMiddle",
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/lb_contact_button_normal.tga", Vector4(5, 5, 5, 5)),
					HoverImage = Gui.Image("LobbyUI/team/lb_contact_button_hover.tga", Vector4(5, 5, 5, 5)),
					DownImage = Gui.Image("LobbyUI/team/lb_contact_button_down.tga", Vector4(5, 5, 5, 5)),
					DisabledImage = Gui.Image("LobbyUI/team/lb_contact_button_normal.tga", Vector4(5, 5, 5, 5)),			
				},
				EventClick = function()
					revise_team_Image_ui.Close()
					revise_team_Image_ui = nil
				end
			},
			Gui.Button 
			{
				Size = Vector2(104, 36),
				Location = Vector2(250, 383),
				Text = lang:GetText("取 消"),
				TextColor = ARGB(255, 211, 211, 211),
				HighlightTextColor = ARGB(255, 211, 211, 211),
				TextAlign = "kAlignCenterMiddle",
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/lb_contact_button_normal.tga", Vector4(5, 5, 5, 5)),
					HoverImage = Gui.Image("LobbyUI/team/lb_contact_button_hover.tga", Vector4(5, 5, 5, 5)),
					DownImage = Gui.Image("LobbyUI/team/lb_contact_button_down.tga", Vector4(5, 5, 5, 5)),
					DisabledImage = Gui.Image("LobbyUI/team/lb_contact_button_normal.tga", Vector4(5, 5, 5, 5)),			
				},
				EventClick = function()
					revise_team_Image_ui.Close()
					revise_team_Image_ui = nil
				end
			},
		},
	},
}

revise_team = Gui.Create()
{
	Gui.Control "root"
	{
		Size = Vector2(1200, 900),
		Location = Vector2(0, 0),
		BackgroundColor = ARGB(0, 255, 255, 255),
		Gui.Control "xiugai"
		{
			Size = Vector2(461, 382),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_contact_bg1_01.dds", Vector4(163,163,53,53)),
			},
			Gui.Control
			{
				Size = Vector2(431, 351),
				Location = Vector2(16, 16),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/lb_contact_bg2.dds", Vector4(16, 12, 16, 45)),
				},
				Gui.Label
				{
					Size = Vector2(200, 20),
					Location = Vector2(33, 13),
					FontSize = 20,
					TextColor = ARGB(255, 52, 50, 50),
					Text = lang:GetText("战队头像"),
				},
				Gui.Control "Image"
				{
					Size = Vector2(72, 72),
					Location = Vector2(39, 53),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_touxiang.dds", Vector4(0, 0, 0, 0)),
					},
				},
				Gui.Button
				{
					Size = Vector2(98, 34),
					Location = Vector2(27, 133),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Padding = Vector4(0, 0, 0, 7),
					Text = lang:GetText("修改"),
					TextAlign = "kAlignCenterMiddle",
					TextColor = ARGB(255, 255, 187, 0),
					HighlightTextColor = ARGB(255, 255, 246, 235),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/lb_contact_button_normal.tga", Vector4(5, 5, 5, 5)),
						HoverImage = Gui.Image("LobbyUI/team/lb_contact_button_hover.tga", Vector4(5, 5, 5, 5)),
						DownImage = Gui.Image("LobbyUI/team/lb_contact_button_down.tga", Vector4(5, 5, 5, 5)),
						DisabledImage = Gui.Image("LobbyUI/team/lb_contact_button_normal.tga", Vector4(5, 5, 5, 5)),			
					},
					EventClick = function()
						revise_team_Image_ui = ModalWindow.GetNew()
						revise_team_Image_ui.root.Size = Vector2(1200, 900)
						revise_team_Image_ui.AllowEscToExit = false
						revise_team_Image.root.Parent = revise_team_Image_ui.root
						Gui.Align(revise_team_Image.register, 0.5,0.5)
						for i = 1, 3 do
							for j = 1 , 5 do
								local pic = revise_team_Image.ib_image:GetDisplayPicture(i,j)
								pic.ForeGroundImage = Gui.Image("LobbyUI/team/lb_squad_touxiang.dds",Vector4(0,0,0,0))
								pic.EventClick = function(sender, e)
									revise_team_Image.ib_image:AllPictureHL(false)
									pic.Highlighted = true
								end	
							end
						end
						revise_team_Image.ib_image.LeftBtn.Visible = false
						revise_team_Image.ib_image.RightBtn.Visible = false
					end
					
				},
				Gui.Label
				{
					Size = Vector2(200, 20),
					Location = Vector2(174, 8),
					FontSize = 20,
					TextColor = ARGB(255, 52, 50, 50),
					Text = lang:GetText("战队介绍"),
				},
				Gui.Control "Image"
				{
					Size = Vector2(248, 237),
					Location = Vector2(168, 43),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/lb_contact_bg3_normal.dds", Vector4(10, 10, 10, 10)),
					},
				},
				Gui.TextArea "description"
				{
					Size = Vector2(248, 237),
					Location = Vector2(168, 43),
					Fold = true,
					Text = team_description,
					FontSize = 18,
					MaxLength = 150,
					TextColor = ARGB(255, 52, 50, 50),
					BackgroundColor = ARGB(0, 255, 255, 255),
					--VScrollBarButtonSize = 0,
				},
				Gui.Label
				{
					Size = Vector2(200, 20),
					Location = Vector2(184, 280),
					FontSize = 12,
					TextColor = ARGB(255, 52, 50, 50),
					Text = lang:GetText("最多输入75个汉字或150个字符"),
					BackgroundColor = ARGB(0, 255, 255, 255),
				},
				Gui.Label
				{
					Size = Vector2(200, 20),
					Location = Vector2(38, 195),
					FontSize = 20,
					TextColor = ARGB(255, 52, 50, 50),
					Text = lang:GetText("加入条件"),
				},
				Gui.ComboBox "rank"
				{
					Size = Vector2(128, 28),
					Location = Vector2(16, 219),		
					Readonly = true,
					Text = "1",
					TextColor = ARGB(255, 52, 50, 50),
					Skin = Gui.ComboBoxSkin
					{
						ButtonNormalImage= Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_button_normal.dds", Vector4(0, 0, 0, 0)),
						ButtonHoverImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_button_hover.dds", Vector4(0, 0, 0, 0)),
						ButtonDownImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_button_down.dds", Vector4(0, 0, 0, 0)),
						
						TextNormalImage= Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_text.dds", Vector4(6, 0, 0, 0)),
						TextHoverImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_text.dds", Vector4(6, 0, 0, 0)),
						TextDownImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_text.dds", Vector4(6, 0, 0, 0)),
						
					},
					ChildComboListStyle =  "Gui.ChangeJobComboList",
				},
				Gui.Label
				{
					Size = Vector2(20, 28),
					Location = Vector2(26, 219),
					Text = "Lv.",
					TextColor = ARGB(255, 52, 50, 50),
				},
				Gui.Button 
				{
					Size = Vector2(104, 36),
					Location = Vector2(81, 312),
					Text = lang:GetText("完成"),
					TextColor = ARGB(255, 211, 211, 211),
					HighlightTextColor = ARGB(255, 211, 211, 211),
					TextAlign = "kAlignCenterMiddle",
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/lb_contact_button_normal.tga", Vector4(5, 5, 5, 5)),
						HoverImage = Gui.Image("LobbyUI/team/lb_contact_button_hover.tga", Vector4(5, 5, 5, 5)),
						DownImage = Gui.Image("LobbyUI/team/lb_contact_button_down.tga", Vector4(5, 5, 5, 5)),
						DisabledImage = Gui.Image("LobbyUI/team/lb_contact_button_normal.tga", Vector4(5, 5, 5, 5)),			
					},
					EventClick = function()
						rpc.safecallload("team_update_op",{pid = ptr_cast(game.CurrentState):GetCharacterId(), tid = t_id , logo = "lb_squad_bg4", rank = revise_team.rank.Text, description = revise_team.description.Text}, 
						function(datd)
							MessageBox.ShowWithTimer(1,lang:GetText("修改成功"))
							revise_team_ui.Close()
							revise_team_ui = nil
							FillTeam()
						end)
					end
				},
				Gui.Button 
				{
					Size = Vector2(104, 36),
					Location = Vector2(235, 312),
					Text = lang:GetText("取消"),
					TextColor = ARGB(255, 211, 211, 211),
					HighlightTextColor = ARGB(255, 211, 211, 211),
					TextAlign = "kAlignCenterMiddle",
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/lb_contact_button_normal.tga", Vector4(5, 5, 5, 5)),
						HoverImage = Gui.Image("LobbyUI/team/lb_contact_button_hover.tga", Vector4(5, 5, 5, 5)),
						DownImage = Gui.Image("LobbyUI/team/lb_contact_button_down.tga", Vector4(5, 5, 5, 5)),
						DisabledImage = Gui.Image("LobbyUI/team/lb_contact_button_normal.tga", Vector4(5, 5, 5, 5)),			
					},
					EventClick = function()
						revise_team_ui.Close()
						revise_team_ui = nil
					end
				},
			},
		},
	},
}

fightteam_fight_ui = Gui.Create()
{
	Gui.Control "root"
	{
		Size = Vector2(789, 677),
		Location = Vector2(0, 0),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_contact_bg1_01.dds", Vector4(163,163,53,53)),
		},
		Gui.Control
		{
			Size = Vector2(403, 624),
			Location = Vector2(20, 27),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_contact_bg2.dds", Vector4(38, 41, 38, 66)),	
			},
			Gui.Control 
			{		
				Location = Vector2(13, 12),
				Size = Vector2(377, 272),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_rank_bg_01.dds", Vector4(34, 34, 34, 34)),
				},
				--战队战房间
				Gui.ListTreeView "Fight_Team_Room_Player"
				{
					Style = "Gui.ListTreeViewWith_VScroll_FightTeam",
					Size = Vector2(350, 272),
					Location = Vector2(10,15),
					ItemHeight = 40,
					TreeVisible = false,
					-- MY_SPLIT_WIDTH = 28, --CHECKBOX 鼠标点击的偏移量
					AlwaysSelect = false,
					HeaderVisible = false,
					-- VScrollBarDisplay = "kVisible",
					-- VScrollBarWidth = 16,
					-- VScrollBarButtonSize = 16,
					CanKeySelect = false,
					VScrollBarWidth = 1,
					VScrollBarButtonSize = 1,
				},
			},
			Gui.Control 
			{		
				Location = Vector2(13, 294),
				Size = Vector2(373, 272),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_rank_bg_01.dds", Vector4(34, 34, 34, 34)),
				},
				Gui.Control 
				{		
					Location = Vector2(66, 12),
					Size = Vector2(240, 148),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_battlefield_map_random_b.dds", Vector4(0, 0, 0, 0)),
					},
				},
				Gui.Label
				{		
					Location = Vector2(27, 167),
					Size = Vector2(110, 30),
					BackgroundColor = ARGB(0, 255, 255, 255),
					Text = lang:GetText("房主名称："),
					FontSize = 14,
					TextColor = ARGB(255, 255, 111, 56),
				},
				Gui.Label
				{		
					Location = Vector2(140, 167),
					Size = Vector2(80, 30),
					BackgroundColor = ARGB(0, 255, 255, 255),
					Text = "????",
					FontSize = 14,
					TextColor = ARGB(255, 226, 217, 208),
				},
				Gui.Label
				{		
					Location = Vector2(27, 187),
					Size = Vector2(110, 30),
					BackgroundColor = ARGB(0, 255, 255, 255),
					Text = lang:GetText("游戏模式："),
					FontSize = 14,
					TextColor = ARGB(255, 255, 111, 56),
				},
				Gui.Label
				{		
					Location = Vector2(140, 187),
					Size = Vector2(80, 30),
					BackgroundColor = ARGB(0, 255, 255, 255),
					Text = "????",
					FontSize = 14,
					TextColor = ARGB(255, 226, 217, 208),
				},
				Gui.Label
				{		
					Location = Vector2(27, 207),
					Size = Vector2(110, 30),
					BackgroundColor = ARGB(0, 255, 255, 255),
					Text = lang:GetText("中途加入："),
					FontSize = 14,
					TextColor = ARGB(255, 255, 111, 56),
				},
				Gui.Label
				{		
					Location = Vector2(140, 207),
					Size = Vector2(80, 30),
					BackgroundColor = ARGB(0, 255, 255, 255),
					Text = "????",
					FontSize = 14,
					TextColor = ARGB(255, 226, 217, 208),
				},
				Gui.Label
				{		
					Location = Vector2(27, 227),
					Size = Vector2(110, 30),
					BackgroundColor = ARGB(0, 255, 255, 255),
					Text = lang:GetText("复活时间："),
					FontSize = 14,
					TextColor = ARGB(255, 255, 111, 56),
				},
				Gui.Label
				{		
					Location = Vector2(140, 227),
					Size = Vector2(80, 30),
					BackgroundColor = ARGB(0, 255, 255, 255),
					Text = "????",
					FontSize = 14,
					TextColor = ARGB(255, 226, 217, 208),
				},
				
				Gui.Label
				{		
					Location = Vector2(193, 167),
					Size = Vector2(110, 30),
					BackgroundColor = ARGB(0, 255, 255, 255),
					Text = lang:GetText("胜利条件："),
					FontSize = 14,
					TextColor = ARGB(255, 255, 111, 56),
				},
				Gui.Label
				{		
					Location = Vector2(297, 167),
					Size = Vector2(80, 30),
					BackgroundColor = ARGB(0, 255, 255, 255),
					Text = "????",
					FontSize = 14,
					TextColor = ARGB(255, 226, 217, 208),
				},
				Gui.Label
				{		
					Location = Vector2(193, 187),
					Size = Vector2(110, 30),
					BackgroundColor = ARGB(0, 255, 255, 255),
					Text = lang:GetText("特殊战："),
					FontSize = 14,
					TextColor = ARGB(255, 255, 111, 56),
				},
				Gui.Label
				{		
					Location = Vector2(297, 187),
					Size = Vector2(80, 30),
					BackgroundColor = ARGB(0, 255, 255, 255),
					Text = "????",
					FontSize = 14,
					TextColor = ARGB(255, 226, 217, 208),
				},
				Gui.Label
				{		
					Location = Vector2(193, 207),
					Size = Vector2(110, 30),
					BackgroundColor = ARGB(0, 255, 255, 255),
					Text = lang:GetText("战力平衡："),
					FontSize = 14,
					TextColor = ARGB(255, 255, 111, 56),
				},
				Gui.Label
				{		
					Location = Vector2(297, 207),
					Size = Vector2(80, 30),
					BackgroundColor = ARGB(0, 255, 255, 255),
					Text = "????",
					FontSize = 14,
					TextColor = ARGB(255, 226, 217, 208),
				},
				Gui.Label
				{		
					Location = Vector2(193, 227),
					Size = Vector2(110, 30),
					BackgroundColor = ARGB(0, 255, 255, 255),
					Text = lang:GetText("自动开始："),
					FontSize = 14,
					TextColor = ARGB(255, 255, 111, 56),
				},
				Gui.Label
				{		
					Location = Vector2(297, 227),
					Size = Vector2(80, 30),
					BackgroundColor = ARGB(0, 255, 255, 255),
					Text = "????",
					FontSize = 14,
					TextColor = ARGB(255, 226, 217, 208),
				},
			},
			--匹配对手
			Gui.Button "b_pipei"
			{
				Size = Vector2(124,44),
				Location = Vector2(11, 573),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Text = lang:GetText("匹配对手"),
				TextColor = ARGB(255, 226, 217, 208),
				TextAlign = "kAlignCenterMiddle",
				FontSize = 16,
				DisabledTextColor = ARGB(255, 37, 37, 37),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_normal.dds", Vector4(32, 0, 32, 0)),
					HoverImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_hover.dds", Vector4(32, 0, 32, 0)),
					DownImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_down.dds", Vector4(32, 0, 32, 0)),
					DisabledImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_disabled.dds", Vector4(32, 0, 32, 0)),
				},
				
				EventClick = function()
					local state = ptr_cast(game.CurrentState)
					if fightteam_fight_ui.b_pipei.Text == lang:GetText("准备") then
						MessageBox.ShowWaiter(lang:GetText("正在准备游戏,请稍候..."))
						state:Ready(true)
						state:BattleGroupReady()
						battle_ready = true
						fightteam_fight_ui.b_pipei.Text = lang:GetText("取消准备")
						fightteam_fight_ui.b_exit.Enable = false
					elseif fightteam_fight_ui.b_pipei.Text == lang:GetText("取消准备") then
						MessageBox.ShowWaiter(lang:GetText("正在准备游戏,请稍候..."))
						state:Ready(false)
						state:BattleGroupReady()
						battle_ready = false
						fightteam_fight_ui.b_pipei.Text = lang:GetText("准备")
						fightteam_fight_ui.b_exit.Enable = true
					elseif fightteam_fight_ui.b_pipei.Text == lang:GetText("匹配对手") then
						state:BattleGroupStartSearch(0)
						fightteam_fight_ui.b_pipei.Enable = false
					end
				end
			},
			--挑战
			Gui.Button "b_tiaozhan"
			{
				Size = Vector2(124,44),
				Location = Vector2(141, 573),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Text = lang:GetText("战队聊天"),
				TextColor = ARGB(255, 226, 217, 208),
				TextAlign = "kAlignCenterMiddle",
				DisabledTextColor = ARGB(255, 37, 37, 37),
				FontSize = 16,
				-- Visible = false,
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_normal.dds", Vector4(32, 0, 32, 0)),
					HoverImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_hover.dds", Vector4(32, 0, 32, 0)),
					DownImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_down.dds", Vector4(32, 0, 32, 0)),
					DisabledImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_disabled.dds", Vector4(32, 0, 32, 0)),
				},
				EventClick = function()
					L_Friends.CreatePrivateChat(my_battle_name,6,nil,fightteam_fight_ui.root)
					-- ShowTiaoZhan()
					-- state:GetBattleGroups("",(tiaozhan_page-1)*7,7,1)
					-- -- FillTiaoZhan()
				end
			},
			--退出房间
			Gui.Button "b_exit"
			{
				Size = Vector2(124,44),
				Location = Vector2(271, 573),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Text = lang:GetText("退出房间"),
				TextColor = ARGB(255, 226, 217, 208),
				TextAlign = "kAlignCenterMiddle",
				FontSize = 16,
				DisabledTextColor = ARGB(255, 37, 37, 37),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_normal.dds", Vector4(32, 0, 32, 0)),
					HoverImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_hover.dds", Vector4(32, 0, 32, 0)),
					DownImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_down.dds", Vector4(32, 0, 32, 0)),
					DisabledImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_disabled.dds", Vector4(32, 0, 32, 0)),
				},
				EventClick = function()
					HideFightTeam()
					invite_player = {}
					invite_index = 1
					mode = 1
					is_exit_room = true				
					local state = ptr_cast(game.CurrentState)
					if state then
						-- state.is_fight_team_server = false
						state.battle_is_create = false
						battle_ready = false
						state:LeaveChannel()
						state:BattleGroupLeave(my_battle_info.battlegroup_id)
					end
				end
			},
		},
		Gui.Control
		{
			Size = Vector2(337, 624),
			Location = Vector2(431, 27),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_contact_bg2.dds", Vector4(38, 41, 38, 66)),	
			},
			Gui.Label
			{		
				Location = Vector2(0, 12),
				Size = Vector2(337, 30),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Text = lang:GetText("战队队友"),
				FontSize = 24,
				TextColor = ARGB(255, 255, 108, 0),
				TextAlign = "kAlignCenterMiddle",
			},
			
			Gui.Control 
			{		
				Location = Vector2(10, 48),
				Size = Vector2(318, 525),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_rank_bg_01.dds", Vector4(34, 34, 34, 34)),
				},
				--战队玩家列表
				Gui.ListTreeView "Fight_Team_Player_List"
				{
					Style = "Gui.ListTreeViewWith_VScroll_FightTeam",
					Size = Vector2(308, 510),
					Location = Vector2(10,15),
					ItemHeight = 33,
					TreeVisible = false,
					-- MY_SPLIT_WIDTH = 28, --CHECKBOX 鼠标点击的偏移量
					AlwaysSelect = false,
					HeaderVisible = false,
					VScrollBarDisplay = "kVisible",
					VScrollBarWidth = 16,
					VScrollBarButtonSize = 16,
					CanKeySelect = false,
					VScrollOffset = -20,
				},
			},
			--邀请
			Gui.Button "b_yaoqing"
			{
				Size = Vector2(124,44),
				Location = Vector2(111, 573),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Text = lang:GetText("邀请"),
				TextColor = ARGB(255, 226, 217, 208),
				TextAlign = "kAlignCenterMiddle",
				DisabledTextColor = ARGB(255, 37, 37, 37),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_normal.dds", Vector4(32, 0, 32, 0)),
					HoverImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_hover.dds", Vector4(32, 0, 32, 0)),
					DownImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_down.dds", Vector4(32, 0, 32, 0)),
					DisabledImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_disabled.dds", Vector4(32, 0, 32, 0)),
				},
				EventClick = function()
					if state then
						if	fightteam_fight_ui.Fight_Team_Player_List.SelectedItem then
							state:BattleGroupInvite(fightteam_fight_ui.Fight_Team_Player_List.SelectedItem.NAME)
							fightteam_fight_ui.Fight_Team_Player_List.SelectedItem.Invite_BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_select_ico.dds",Vector4(0, 0, 0, 0))
							fightteam_fight_ui.Fight_Team_Player_List.SelectedItem.Invite_localtion = Vector2(255,10)
							fightteam_fight_ui.Fight_Team_Player_List.SelectedItem.Invite_Size = Vector2(20,16)
							invite_player[invite_index] = fightteam_fight_ui.Fight_Team_Player_List.SelectedItem.NAME
							invite_index = invite_index + 1
						end
					end
				end
			},
		},
		
		Gui.TimeControl "StartGame"
		{
			Size = Vector2(5,5),
			Dock = "kDockCenter",
			BackgroundColor = ARGB(0, 255, 255, 255),
			EventTimeOut = function(sender, e)    
				print("jinjinjinjinjinjin")
				MessageBox.CloseWaiter() 
				MessageBox.ShowWaiter(lang:GetText("正在开始游戏,请稍候..."))						
				state:StartGame()	
			end
		},
	},
}

add_my_power_ui = Gui.Create()
{
	Gui.Control "root"
	{
		Size = Vector2(715, 423),
		Location = Vector2(0, 0),
		BackgroundColor = ARGB(0, 255, 255, 255),
		Gui.Control
		{
			Size = Vector2(615, 323),
			Location = Vector2(50, 50),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/team/lb_contact_bg1_01.dds", Vector4(185, 165, 32, 58)),
			},
			Gui.Label
			{
				Size = Vector2(615, 20),
				Location = Vector2(0, 10),
				BackgroundColor = ARGB(0, 255, 255, 255),
				TextAlign = "kAlignCenterMiddle",
				FontSize = 16,
				TextColor = ARGB(255, 255, 255, 255),
				Text = lang:GetText("获得个人黑晶石"),
			},
			Gui.Control
			{
				Size = Vector2(581, 104),
				Location = Vector2(16, 34),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/lb_shop_bg3_1.dds", Vector4(10, 10, 10, 10)),
				},
				Gui.Control 
				{
					Size = Vector2(30, 30),
					Location = Vector2(26, 20),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/lb_icon_res_02_1.dds", Vector4(0, 0, 0, 0)),
					},
				},
				Gui.Control
				{
					Size = Vector2(432, 25),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Location = Vector2(117, 27),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/lb_com_bg.dds",Vector4(45,0,20,0)),
					},
					Gui.Control "my_cannot_use_oil"
					{
						Size = Vector2(422, 17),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Location = Vector2(5, 4),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/team/lb_res_bg_02_3.dds",Vector4(0, 0, 0, 0)),
						},
					},
					Gui.Control
					{
						Size = Vector2(39, 25),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Location = Vector2(0, 0),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/lb_com_bg_03.dds",Vector4(69,0,112,0)),
						},
					},
					Gui.Label "my_cannot_use_rate"
					{
						Location = Vector2(0, 3),
						Size = Vector2(422, 17),
						FontSize = 16,
						TextAlign = "kAlignRightMiddle",
						TextColor = ARGB(255, 255, 255, 255),
						Text = lang:GetText("1/1"),
						BackgroundColor = ARGB(0, 255, 255, 255),
					},
				},
				Gui.Control 
				{
					Size = Vector2(30, 30),
					Location = Vector2(26, 54),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/lb_icon_res_03.dds", Vector4(0, 0, 0, 0)),
					},
				},
				Gui.Control
				{
					Size = Vector2(432, 25),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Location = Vector2(117, 57),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/lb_com_bg.dds",Vector4(45,0,20,0)),
					},
					Gui.Control "my_can_use_oil"
					{
						Size = Vector2(422, 17),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Location = Vector2(5, 4),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/team/lb_res_bg_03.dds",Vector4(0, 0, 0, 0)),
						},
					},
					-- Gui.Control
					-- {
						-- Size = Vector2(39, 25),
						-- BackgroundColor = ARGB(255, 255, 255, 255),
						-- Location = Vector2(0, 0),
						-- Skin = Gui.ControlSkin
						-- {
							-- BackgroundImage = Gui.Image("LobbyUI/lb_com_bg_01.dds",Vector4(69,0,112,0)),
						-- },
					-- },
					Gui.Label "my_can_use_rate"
					{
						Location = Vector2(0, 3),
						Size = Vector2(422, 17),
						FontSize = 16,
						TextAlign = "kAlignRightMiddle",
						TextColor = ARGB(255, 255, 255, 255),
						Text = lang:GetText("1/1"),
						BackgroundColor = ARGB(0, 255, 255, 255),
					},
				},
			},
			Gui.Control
			{
				Size = Vector2(584, 160),
				Location = Vector2(15, 144),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/lb_shop_bg3_1.dds", Vector4(10, 10, 10, 10)),
				},
				Gui.Control
				{
					Size = Vector2(269, 34),
					Location = Vector2(9, 9),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/lb_yaoqing_bg.dds", Vector4(10, 10, 10, 10)),
					},
				},	
				Gui.Label
				{
					Location = Vector2(10, 15),
					Size = Vector2(100, 20),
					FontSize = 16,
					TextAlign = "kAlignLeftMiddle",
					TextColor = ARGB(255, 255, 210, 0),
					Text = lang:GetText("个人剩余"),
					BackgroundColor = ARGB(0, 255, 255, 255),
				},
				Gui.Control
				{
					Size = Vector2(30, 30),
					Location = Vector2(110, 10),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/lb_icon_res_fc.dds", Vector4(0, 0, 0, 0)),
					},
				},
				Gui.Label "FC_left"
				{
					Location = Vector2(157, 15),
					Size = Vector2(200, 20),
					FontSize = 16,
					TextAlign = "kAlignLeftMiddle",
					TextColor = ARGB(255, 255, 255, 255),
					Text = lang:GetText("0FC点"),
					BackgroundColor = ARGB(0, 255, 255, 255),
				},
				Gui.Label
				{
					Location = Vector2(10, 58),
					Size = Vector2(100, 20),
					FontSize = 16,
					TextAlign = "kAlignLeftMiddle",
					TextColor = ARGB(255, 255, 210, 0),
					Text = lang:GetText("转换"),
					BackgroundColor = ARGB(0, 255, 255, 255),
				},
				Gui.Label "c_change_person_yuanshi"
				{
					Size = Vector2(127, 26),
					Location = Vector2(92,57),
					Text = "0",
					FontSize = 16,
					TextPadding = Vector4(0,0,20,0),
					TextColor = ARGB(255, 255, 255, 255),
					TextAlign = "kAlignRightMiddle",
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/lb_com_bg.dds",Vector4(45,0,20,0)),
					},
				},
				Gui.Control 
				{
					Size = Vector2(30, 30),
					Location = Vector2(100, 50),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/lb_icon_res_02_1.dds", Vector4(0, 0, 0, 0)),
					},
				},
				Gui.Control 
				{
					Size = Vector2(33, 19),
					Location = Vector2(228, 61),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/lb_zhuanhuan_jiantou.dds", Vector4(0, 0, 0, 0)),
					},
				},
				Gui.ComboBox "c_change_person"
				{
					Size = Vector2(158, 26),
					Location = Vector2(266,57),
					FontSize = 18,
					Readonly = true,
					TextColor = ARGB(255, 225, 255, 255),
					TextAlign = "kAlignRightMiddle",
					LikeButton = true,
					ChildComboListStyle =  "Gui.ExChangeList",
					TextPadding = Vector4(0,0,10,0),
					Skin = Gui.ComboBoxSkin
					{
						ButtonNormalImage= Gui.Image("LobbyUI/team/lb_xia_normal.dds", Vector4(0, 0, 0, 0)),
						ButtonHoverImage = Gui.Image("LobbyUI/team/lb_xia_hover.dds", Vector4(0, 0, 0, 0)),
						ButtonDownImage = Gui.Image("LobbyUI/team/lb_xia_down.dds", Vector4(0, 0, 0, 0)),
						
						TextNormalImage= Gui.Image("LobbyUI/lb_com_bg.dds", Vector4(45,0,20,0)),
						TextHoverImage = Gui.Image("LobbyUI/lb_com_bg.dds", Vector4(45,0,20,0)),
						TextDownImage = Gui.Image("LobbyUI/lb_com_bg.dds", Vector4(45,0,20,0)),
					},
					EventItemSelected = function(sender, args)
						if sender.SelectedIndex then
							selected_person_exchange = sender.SelectedIndex + 1
							add_my_power_ui.c_change_person_FC.Text = SHOP_PersonalTransform.costs[sender.SelectedIndex+1][1]--..lang:GetText("  FC点")
							add_my_power_ui.c_change_person_yuanshi.Text = SHOP_PersonalTransform.costs[sender.SelectedIndex+1][2]
						end
					end
				},
				Gui.Control 
				{
					Size = Vector2(30, 30),
					Location = Vector2(274, 50),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/lb_icon_res_03.dds", Vector4(0, 0, 0, 0)),
					},
				},
				Gui.Label
				{
					Location = Vector2(10, 92),
					Size = Vector2(100, 20),
					FontSize = 16,
					TextAlign = "kAlignLeftMiddle",
					TextColor = ARGB(255, 255, 210, 0),
					Text = lang:GetText("消耗"),
					BackgroundColor = ARGB(0, 255, 255, 255),
				},
				Gui.Label "c_change_person_FC"
				{
					Size = Vector2(332, 26),
					Location = Vector2(92,89),
					Text = lang:GetText("0FC点"),
					FontSize = 16,
					TextPadding = Vector4(0,0,35,0),
					TextColor = ARGB(255, 255, 255, 255),
					TextAlign = "kAlignRightMiddle",
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/lb_com_bg.dds",Vector4(45,0,20,0)),
					},
				},
				Gui.Control
				{
					Size = Vector2(30, 30),
					Location = Vector2(103, 86),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/lb_icon_res_fc.dds", Vector4(0, 0, 0, 0)),
					},
				},
				Gui.Button
				{
					Size = Vector2(107,27),
					Location = Vector2(449, 88),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Text = lang:GetText("转换"),
					TextColor = ARGB(255, 226, 217, 208),
					TextAlign = "kAlignCenterMiddle",
					DisabledTextColor = ARGB(255, 37, 37, 37),
					Skin = Skin.LevelUpBtnSkin,
					EventClick = function()
						if add_my_power_ui.c_change_person.SelectedIndex then
							rpc.safecallload("zyzdz_transform", {pid = ptr_cast(game.CurrentState):GetCharacterId(), type = SHOP_PersonalTransform.type, fccost = SHOP_PersonalTransform.costs[add_my_power_ui.c_change_person.SelectedIndex+1][1]},
							function(data)
								if data.succ then
									Fill_Header_Team()
								end	
							end)
						end
					end
				},
			},
		},	
		Gui.Button
		{
			Size = Vector2(48,48),
			Location = Vector2(636, 36),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_normal.dds", Vector4(10, 10, 10, 10)),
				HoverImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_hover.dds", Vector4(10, 10, 10, 10)),
				DownImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_down.dds", Vector4(10, 10, 10, 10)),
				DisabledImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_disabled.dds", Vector4(0, 0, 0, 0)),	
			},
			EventClick = function()
				Hide_MyAddPower()
			end,
		},
	},
}

add_team_power_ui = Gui.Create()
{
	Gui.Control "root"
	{
		Size = Vector2(715, 509),
		Location = Vector2(0, 0),
		BackgroundColor = ARGB(0, 255, 255, 255),
		Gui.Control
		{
			Size = Vector2(615, 409),
			Location = Vector2(50, 50),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/team/lb_contact_bg1_01.dds", Vector4(185, 165, 32, 58)),
			},
			Gui.Label
			{
				Size = Vector2(615, 20),
				Location = Vector2(0, 10),
				BackgroundColor = ARGB(0, 255, 255, 255),
				TextAlign = "kAlignCenterMiddle",
				FontSize = 16,
				TextColor = ARGB(255, 255, 255, 255),
				Text = lang:GetText("获得战队黑铁"),
			},
			Gui.Control
			{
				Size = Vector2(581, 104),
				Location = Vector2(16, 34),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/lb_shop_bg3_1.dds", Vector4(10, 10, 10, 10)),
				},
				-- Gui.Label "zhandui_fightsource_rate"
				-- {
					-- Size = Vector2(430, 17),
					-- Location = Vector2(88, 9),
					-- TextAlign = "kAlignRightMiddle",
					-- Text = lang:GetText("原石每小时转换：1000黑铁(自动转换)"),
				-- },
				Gui.Control 
				{
					Size = Vector2(30, 30),
					Location = Vector2(26, 20),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/lb_icon_res_02.dds", Vector4(0, 0, 0, 0)),
					},
				},
				Gui.Control
				{
					Size = Vector2(432, 25),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Location = Vector2(117, 27),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/lb_com_bg.dds",Vector4(45,0,20,0)),
					},
					Gui.Control "zhandui_cannot_use_oil"
					{
						Size = Vector2(422, 17),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Location = Vector2(5, 4),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/team/lb_res_bg_02.dds",Vector4(0, 0, 0, 0)),
						},
					},
					-- Gui.Control
					-- {
						-- Size = Vector2(39, 25),
						-- BackgroundColor = ARGB(255, 255, 255, 255),
						-- Location = Vector2(0, 0),
						-- Skin = Gui.ControlSkin
						-- {
							-- BackgroundImage = Gui.Image("LobbyUI/lb_com_bg_01.dds",Vector4(69,0,112,0)),
						-- },
					-- },
					Gui.Label "zhandui_cannot_use_rate"
					{
						Location = Vector2(0, 3),
						Size = Vector2(422, 17),
						FontSize = 16,
						TextAlign = "kAlignRightMiddle",
						TextColor = ARGB(255, 255, 255, 255),
						Text = lang:GetText("1/1"),
						BackgroundColor = ARGB(0, 255, 255, 255),
					},
				},
				Gui.Control 
				{
					Size = Vector2(30, 30),
					Location = Vector2(26, 54),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/lb_icon_res_01.dds", Vector4(0, 0, 0, 0)),
					},
				},
				Gui.Control
				{
					Size = Vector2(432, 25),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Location = Vector2(117, 57),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/lb_com_bg.dds",Vector4(45,0,20,0)),
					},
					Gui.Control "zhandui_can_use_oil"
					{
						Size = Vector2(422, 17),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Location = Vector2(5, 4),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/team/lb_res_bg_01.dds",Vector4(0, 0, 0, 0)),
						},
					},
					-- Gui.Control
					-- {
						-- Size = Vector2(39, 25),
						-- BackgroundColor = ARGB(255, 255, 255, 255),
						-- Location = Vector2(0, 0),
						-- Skin = Gui.ControlSkin
						-- {
							-- BackgroundImage = Gui.Image("LobbyUI/lb_com_bg_01.dds",Vector4(69,0,112,0)),
						-- },
					-- },
					Gui.Label "zhandui_can_use_rate"
					{
						Location = Vector2(0, 3),
						Size = Vector2(422, 17),
						FontSize = 16,
						TextAlign = "kAlignRightMiddle",
						TextColor = ARGB(255, 255, 255, 255),
						Text = lang:GetText("1/1"),
						BackgroundColor = ARGB(0, 255, 255, 255),
					},
				},
			},
			
			Gui.Control
			{
				Size = Vector2(584, 246),
				Location = Vector2(15, 144),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/lb_shop_bg3_1.dds", Vector4(10, 10, 10, 10)),
				},
				Gui.Control
				{
					Size = Vector2(269, 34),
					Location = Vector2(9, 9),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/lb_yaoqing_bg.dds", Vector4(10, 10, 10, 10)),
					},
				},	
				Gui.Label
				{
					Location = Vector2(10, 15),
					Size = Vector2(100, 20),
					FontSize = 16,
					TextAlign = "kAlignLeftMiddle",
					TextColor = ARGB(255, 255, 210, 0),
					Text = lang:GetText("个人剩余"),
					BackgroundColor = ARGB(0, 255, 255, 255),
				},
				Gui.Control
				{
					Size = Vector2(30, 30),
					Location = Vector2(110, 10),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/lb_icon_res_fc.dds", Vector4(0, 0, 0, 0)),
					},
				},
				Gui.Label "FC_left"
				{
					Location = Vector2(157, 15),
					Size = Vector2(200, 20),
					FontSize = 16,
					TextAlign = "kAlignLeftMiddle",
					TextColor = ARGB(255, 255, 255, 255),
					Text = lang:GetText("0FC点"),
					BackgroundColor = ARGB(0, 255, 255, 255),
				},
				Gui.Label
				{
					Location = Vector2(10, 58),
					Size = Vector2(100, 20),
					FontSize = 16,
					TextAlign = "kAlignLeftMiddle",
					TextColor = ARGB(255, 255, 210, 0),
					Text = lang:GetText("转换"),
					BackgroundColor = ARGB(0, 255, 255, 255),
				},
				Gui.Label "c_change_team_yuanshi"
				{
					Size = Vector2(127, 26),
					Location = Vector2(92,57),
					Text = "0",
					FontSize = 16,
					TextPadding = Vector4(0,0,10,0),
					TextColor = ARGB(255, 255, 255, 255),
					TextAlign = "kAlignRightMiddle",
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/lb_com_bg.dds",Vector4(45,0,20,0)),
					},
				},
				Gui.Control 
				{
					Size = Vector2(30, 30),
					Location = Vector2(100, 50),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/lb_icon_res_02.dds", Vector4(0, 0, 0, 0)),
					},
				},
				Gui.Control 
				{
					Size = Vector2(33, 19),
					Location = Vector2(228, 61),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/lb_zhuanhuan_jiantou.dds", Vector4(0, 0, 0, 0)),
					},
				},
				Gui.ComboBox "c_change_team"
				{
					Size = Vector2(138, 26),
					Location = Vector2(286,57),
					FontSize = 18,
					Readonly = true,
					TextColor = ARGB(255, 225, 255, 255),
					TextAlign = "kAlignRightMiddle",
					TextPadding = Vector4(0,0,10,0),
					LikeButton = true,
					ChildComboListStyle =  "Gui.ExChangeList",
					Skin = Gui.ComboBoxSkin
					{
						ButtonNormalImage= Gui.Image("LobbyUI/team/lb_xia_normal.dds", Vector4(0, 0, 0, 0)),
						ButtonHoverImage = Gui.Image("LobbyUI/team/lb_xia_hover.dds", Vector4(0, 0, 0, 0)),
						ButtonDownImage = Gui.Image("LobbyUI/team/lb_xia_down.dds", Vector4(0, 0, 0, 0)),
						
						TextNormalImage= Gui.Image("LobbyUI/lb_com_bg.dds", Vector4(45,0,20,0)),
						TextHoverImage = Gui.Image("LobbyUI/lb_com_bg.dds", Vector4(45,0,20,0)),
						TextDownImage = Gui.Image("LobbyUI/lb_com_bg.dds", Vector4(45,0,20,0)),
					},
					EventItemSelected = function(sender, args)
						if sender.SelectedIndex then
							selected_team_exchange = sender.SelectedIndex + 1
							add_team_power_ui.c_change_team_FC.Text = SHOP_TeamTransofrm.costs[sender.SelectedIndex+1][1]--..lang:GetText("  FC点")
							add_team_power_ui.c_change_team_yuanshi.Text = SHOP_TeamTransofrm.costs[sender.SelectedIndex+1][2]
							add_team_power_ui.c_change_team_back.Text = SHOP_TeamTransofrm.costs[sender.SelectedIndex+1][4]
						end
					end
				},
				Gui.Control 
				{
					Size = Vector2(30, 30),
					Location = Vector2(294, 50),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/lb_icon_res_01.dds", Vector4(0, 0, 0, 0)),
					},
				},
				Gui.Label
				{
					Location = Vector2(10, 91),
					Size = Vector2(100, 20),
					FontSize = 16,
					TextAlign = "kAlignLeftMiddle",
					TextColor = ARGB(255, 255, 210, 0),
					Text = lang:GetText("消耗"),
					BackgroundColor = ARGB(0, 255, 255, 255),
				},
				Gui.Label "c_change_team_FC"
				{
					Size = Vector2(127, 26),
					Location = Vector2(92,89),
					Text = lang:GetText("0FC点"),
					FontSize = 16,
					TextPadding = Vector4(0,0,10,0),
					TextColor = ARGB(255, 255, 255, 255),
					TextAlign = "kAlignRightMiddle",
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/lb_com_bg.dds",Vector4(45,0,20,0)),
					},
				},
				Gui.Control
				{
					Size = Vector2(30, 30),
					Location = Vector2(103, 86),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/lb_icon_res_fc.dds", Vector4(0, 0, 0, 0)),
					},
				},
				
				Gui.Label
				{
					Location = Vector2(219, 91),
					Size = Vector2(47, 20),
					FontSize = 16,
					TextAlign = "kAlignCenterMiddle",
					TextColor = ARGB(255, 255, 210, 0),
					Text = lang:GetText("返还"),
					BackgroundColor = ARGB(0, 255, 255, 255),
				},
				
				Gui.Label "c_change_team_back"
				{
					Size = Vector2(138, 26),
					Location = Vector2(286,89),
					Text = "0",
					FontSize = 16,
					TextPadding = Vector4(0,0,35,0),
					TextColor = ARGB(255, 255, 255, 255),
					TextAlign = "kAlignRightMiddle",
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/lb_com_bg.dds",Vector4(45,0,20,0)),
					},
				},

				Gui.Control 
				{
					Size = Vector2(30, 30),
					Location = Vector2(294, 86),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/lb_icon_res_03.dds", Vector4(0, 0, 0, 0)),
					},
				},
				
				Gui.Label
				{
					Size = Vector2(170, 50),
					Location = Vector2(250, 46),
					FontSize = 16,
					BackgroundColor = ARGB(0, 255, 255, 255),
					Text = "FC点：300\n原石：300",
					TextColor = ARGB(255, 225, 255, 255),
					TextAlign = "kAlignCenterMiddle",
					Visible = false,
				},
				Gui.Button
				{
					Size = Vector2(107,27),
					Location = Vector2(449, 88),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Text = lang:GetText("转换"),
					TextColor = ARGB(255, 226, 217, 208),
					TextAlign = "kAlignCenterMiddle",
					DisabledTextColor = ARGB(255, 37, 37, 37),
					Skin = Skin.LevelUpBtnSkin,
					EventClick = function()
						if add_team_power_ui.c_change_team.SelectedIndex then
							rpc.safecallload("zyzdz_transform", {pid = ptr_cast(game.CurrentState):GetCharacterId(), type = SHOP_TeamTransofrm.type, fccost = SHOP_TeamTransofrm.costs[add_team_power_ui.c_change_team.SelectedIndex+1][1]},
							function(data)
								if data.succ then
									Fill_Header_Team()
									if data.res and data.res > 0 then
										L_LevelUpEffect.Show_LevelUpEffect(data)			
									end
								end	
							end)
						end
					end
				},
				
				Gui.Control
				{
					Size = Vector2(574, 68),
					Location = Vector2(5, 134),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_xiamian_bg.dds", Vector4(10, 10, 10, 10)),
					},
				},	
				Gui.Label
				{
					Location = Vector2(10, 161),
					Size = Vector2(100, 20),
					FontSize = 16,
					TextAlign = "kAlignLeftMiddle",
					TextColor = ARGB(255, 255, 210, 0),
					Text = lang:GetText("购买"),
					BackgroundColor = ARGB(0, 255, 255, 255),
				},
				Gui.ComboBox "c_buy_team"
				{
					Size = Vector2(332, 26),
					Location = Vector2(92,161),
					FontSize = 18,
					Readonly = true,
					TextColor = ARGB(255, 225, 255, 255),
					TextAlign = "kAlignRightMiddle",
					TextPadding = Vector4(0,0,10,0),
					LikeButton = true,
					ChildComboListStyle =  "Gui.ExChangeList",
					Skin = Gui.ComboBoxSkin
					{
						ButtonNormalImage= Gui.Image("LobbyUI/team/lb_xia_normal.dds", Vector4(0, 0, 0, 0)),
						ButtonHoverImage = Gui.Image("LobbyUI/team/lb_xia_hover.dds", Vector4(0, 0, 0, 0)),
						ButtonDownImage = Gui.Image("LobbyUI/team/lb_xia_down.dds", Vector4(0, 0, 0, 0)),
						
						TextNormalImage= Gui.Image("LobbyUI/lb_com_bg.dds", Vector4(45,0,20,0)),
						TextHoverImage = Gui.Image("LobbyUI/lb_com_bg.dds", Vector4(45,0,20,0)),
						TextDownImage = Gui.Image("LobbyUI/lb_com_bg.dds", Vector4(45,0,20,0)),
					},
					EventItemSelected = function(sender, args)
						if sender.SelectedIndex then
							selected_team_buy = sender.SelectedIndex + 1
							add_team_power_ui.c_buy_team_FC.Text = SHOP_TeamBuy.costs[sender.SelectedIndex+1][1]--..lang:GetText("  FC点")
							add_team_power_ui.c_buy_team_back.Text = SHOP_TeamBuy.costs[sender.SelectedIndex+1][4]
						end
					end
				},
				Gui.Control 
				{
					Size = Vector2(30, 30),
					Location = Vector2(102, 154),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/lb_icon_res_01.dds", Vector4(0, 0, 0, 0)),
					},
				},
				
				Gui.Label
				{
					Location = Vector2(10, 198),
					Size = Vector2(100, 20),
					FontSize = 16,
					TextAlign = "kAlignLeftMiddle",
					TextColor = ARGB(255, 255, 210, 0),
					Text = lang:GetText("消耗"),
					BackgroundColor = ARGB(0, 255, 255, 255),
				},
				Gui.Label "c_buy_team_FC"
				{
					Size = Vector2(127, 26),
					Location = Vector2(92,195),
					TextColor = ARGB(255, 225, 255, 255),
					Text = lang:GetText("0FC点"),
					FontSize = 16,
					TextPadding = Vector4(0,0,10,0),
					TextAlign = "kAlignRightMiddle",
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/lb_com_bg.dds",Vector4(45,0,20,0)),
					},
				},
				Gui.Control
				{
					Size = Vector2(30, 30),
					Location = Vector2(103, 191),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/lb_icon_res_fc.dds", Vector4(0, 0, 0, 0)),
					},
				},
				
				Gui.Label
				{
					Location = Vector2(219, 198),
					Size = Vector2(47, 20),
					FontSize = 16,
					TextAlign = "kAlignCenterMiddle",
					TextColor = ARGB(255, 255, 210, 0),
					Text = lang:GetText("返还"),
					BackgroundColor = ARGB(0, 255, 255, 255),
				},
				
				Gui.Label "c_buy_team_back"
				{
					Size = Vector2(138, 26),
					Location = Vector2(286,195),
					Text = "0",
					FontSize = 16,
					TextPadding = Vector4(0,0,35,0),
					TextColor = ARGB(255, 255, 255, 255),
					TextAlign = "kAlignRightMiddle",
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/lb_com_bg.dds",Vector4(45,0,20,0)),
					},
				},

				Gui.Control 
				{
					Size = Vector2(30, 30),
					Location = Vector2(294, 191),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/lb_icon_res_03.dds", Vector4(0, 0, 0, 0)),
					},
				},
				
				Gui.Button
				{
					Size = Vector2(107,27),
					Location = Vector2(449, 193),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Text = lang:GetText("购买"),
					TextColor = ARGB(255, 226, 217, 208),
					TextAlign = "kAlignCenterMiddle",
					DisabledTextColor = ARGB(255, 37, 37, 37),
					Skin = Skin.LevelUpBtnSkin,
					EventClick = function()
						if add_team_power_ui.c_buy_team.SelectedIndex then
							rpc.safecallload("zyzdz_transform", {pid = ptr_cast(game.CurrentState):GetCharacterId(), type = SHOP_TeamBuy.type, fccost = SHOP_TeamBuy.costs[add_team_power_ui.c_buy_team.SelectedIndex+1][1]},
							function(data)
								if data.succ then
									Fill_Header_Team()
									if data.res and data.res > 0 then
										L_LevelUpEffect.Show_LevelUpEffect(data)			
									end
								end	
							end)
						end
					end
				},
			},
		},
		Gui.Button
		{
			Size = Vector2(48,48),
			Location = Vector2(636, 36),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_normal.dds", Vector4(10, 10, 10, 10)),
				HoverImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_hover.dds", Vector4(10, 10, 10, 10)),
				DownImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_down.dds", Vector4(10, 10, 10, 10)),
				DisabledImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_disabled.dds", Vector4(0, 0, 0, 0)),	
			},
			EventClick = function()
				Hide_TeamAddPower()
			end,
		},
	},
}

--添加查看战队信息按钮
function AddTeamInfoBtn(indx)
	return Gui.Button
	{
		Size = Vector2(112,37),
		Location = Vector2(20, 56),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Text = lang:GetText("详细信息"),
		TextColor = ARGB(255, 0, 0, 0),
		TextAlign = "kAlignCenterMiddle",
		HighlightTextColor = ARGB(255, 0, 0, 0),
		Padding = Vector4(0, 0, 0, 5),
		Visible = false,
		Skin = Gui.ButtonSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_v2_01_normal.dds", Vector4(0, 0, 0, 0)),
			HoverImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_v2_01_hover.dds", Vector4(0, 0, 0, 0)),
			DownImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_v2_01_down.dds", Vector4(0, 0, 0, 0)),
			DisabledImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_v2_01_disabled.dds", Vector4(0, 0, 0, 0)),
		},
		
		EventClick = function()
			if tiaozhan_battle_info[indx] and tiaozhan_battle_info[indx].group_id then
				FillT_Info(tiaozhan_battle_info[indx].group_id,true)
			end
		end,
	}
end
tiaozhan_ui = Gui.Create()
{
	Gui.Control "root"
	{
		Size = Vector2(543, 635),
		Location = Vector2(0, 0),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_contact_bg1_01.dds", Vector4(163,163,53,53)),
		},
		Gui.Label "re_msg_1"
		{
			Size = Vector2(500, 30),
			Location = Vector2(20, 21),
			FontSize = 24,
			BackgroundColor = ARGB(0, 255, 255, 255),
			Text = lang:GetText("您还可以选择某个战队，向他们发起挑战！"),
			TextColor = ARGB(255, 226, 217, 208),
			TextAlign = "kAlignLeftMiddle",
		},
		Gui.Control
		{
			Size = Vector2(503, 559),
			Location = Vector2(20, 52),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_contact_bg2.dds", Vector4(38, 41, 38, 66)),	
			},
			
			Gui.Control
			{
				Size = Vector2(476, 487),
				Location = Vector2(13, 14),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_rank_bg_01.dds", Vector4(34, 34, 34, 34)),
				},
				--挑战战队列表
				Gui.ListTreeView "TiaoZhan_Fight_Team"
				{
					Style = "Gui.ListTreeViewWith_VScroll_FightTeam",
					Size = Vector2(470, 450),
					Location = Vector2(18,25),
					ItemHeight = 56,
					TreeVisible = false,
					-- MY_SPLIT_WIDTH = 28, --CHECKBOX 鼠标点击的偏移量
					AlwaysSelect = false,
					HeaderVisible = false,
					-- VScrollBarDisplay = "kVisible",
					-- VScrollBarWidth = 16,
					-- VScrollBarButtonSize = 16,
					CanKeySelect = false,
					
					--添加详细信息按钮 7个
					Gui.Button "btn_info_1"
					{
						Size = Vector2(112,37),
						Location = Vector2(20, 56),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Text = lang:GetText("详细信息"),
						TextColor = ARGB(255, 0, 0, 0),
						TextAlign = "kAlignCenterMiddle",
						HighlightTextColor = ARGB(255, 0, 0, 0),
						Padding = Vector4(0, 0, 0, 5),
						Visible = false,
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_v2_01_normal.dds", Vector4(0, 0, 0, 0)),
							HoverImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_v2_01_hover.dds", Vector4(0, 0, 0, 0)),
							DownImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_v2_01_down.dds", Vector4(0, 0, 0, 0)),
							DisabledImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_v2_01_disabled.dds", Vector4(0, 0, 0, 0)),
						},	
						EventClick = function()
							if tiaozhan_battle_info[1] and tiaozhan_battle_info[1].group_id then
								FillT_Info(tiaozhan_battle_info[1].group_id,true)
							end
						end,
					},				
					AddTeamInfoBtn(2),
					AddTeamInfoBtn(3),
					AddTeamInfoBtn(4),
					AddTeamInfoBtn(5),
					AddTeamInfoBtn(6),
					AddTeamInfoBtn(7),
				},
				
				Gui.Button "m_Left"
				{	
					Size = Vector2(72, 32),
					Visible = true,
					Location = Vector2(85,434),
					TextColor = ARGB(255, 209, 227, 221),
					Text = lang:GetText("上一页"),
					
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_page_normal.dds", Vector4(5, 5, 10, 5)),
						HoverImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_page_hover.dds", Vector4(5, 5, 10, 5)),
						DownImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_page_down.dds", Vector4(5, 5, 10, 5)),
						DisabledImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_page_bg.dds", Vector4(5, 5, 10, 5)),
					},
					EventClick = function()
						if tiaozhan_page ~= 1 then
							tiaozhan_page = tiaozhan_page - 1
							tiaozhan_ui.m_PageDisplay.Text = lang:GetText("第")..tiaozhan_page..lang:GetText("页")
							state:GetBattleGroups("",(tiaozhan_page-1)*7,7,1)
						end
					end
					
				},
				
				Gui.Button "m_Right"
				{
					Size = Vector2(72, 32),
					Visible = true,
					Location = Vector2(332,434),
					TextColor = ARGB(255, 209, 227, 221),
					Text = lang:GetText("下一页"),
					
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_page_normal.dds", Vector4(5, 5, 10, 5)),
						HoverImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_page_hover.dds", Vector4(5, 5, 10, 5)),
						DownImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_page_down.dds", Vector4(5, 5, 10, 5)),
						DisabledImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_page_bg.dds", Vector4(5, 5, 10, 5)),
					},
					EventClick = function()
						tiaozhan_page = tiaozhan_page + 1
						tiaozhan_ui.m_PageDisplay.Text = lang:GetText("第")..tiaozhan_page..lang:GetText("页")
						state:GetBattleGroups("",(tiaozhan_page-1)*7,7,1)
					end
				},
				
				Gui.Button "m_PageDisplay"
				{
					Size = Vector2(145,31),
					FontSize = 24,
					Visible = true,
					Location = Vector2(172,434),
					TextColor = ARGB(255, 37, 37, 37),
					HighlightTextColor = ARGB(255, 37, 37, 37),
					TextAlign = "kAlignCenterMiddle",
					Text = lang:GetText("第1页"),
					BackgroundColor = ARGB(255, 255, 255, 255),
					
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/lb_common_fanye_down.tga", Vector4(5, 5, 10, 5)),
						--HoverImage = Gui.Image("LobbyUI/team/lb_common_fanye_down.tga", Vector4(5, 5, 10, 5)),
						--DownImage = Gui.Image("LobbyUI/team/lb_common_fanye_down.tga", Vector4(5, 5, 10, 5)),
						DisabledImage = Gui.Image("LobbyUI/team/lb_common_fanye_down.tga", Vector4(5, 5, 10, 5)),
					},
				},
			},
		},
		
		--挑战
		Gui.Button "c_tiaozhan"
		{
			Size = Vector2(223,44),
			Location = Vector2(39, 557),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Text = lang:GetText("挑 战"),
			TextColor = ARGB(255, 226, 217, 208),
			HighlightTextColor = ARGB(255, 226, 217, 208),
			TextAlign = "kAlignCenterMiddle",
			DisabledTextColor = ARGB(255, 37, 37, 37),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_normal.dds", Vector4(32, 0, 32, 0)),
				HoverImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_hover.dds", Vector4(32, 0, 32, 0)),
				DownImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_down.dds", Vector4(32, 0, 32, 0)),
				DisabledImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_disabled.dds", Vector4(32, 0, 32, 0)),
			},
			EventClick = function()
				if tiaozhan_ui.TiaoZhan_Fight_Team.SelectedItem then
					for i = 9 , 14 do
						state:ChangeSlotStatus(i,1)
					end
					state:BattleGroupChallenge(tiaozhan_ui.TiaoZhan_Fight_Team.SelectedItem.ID)
				end
			end
		},
		
		--取消
		Gui.Button "c_tiaozhan"
		{
			Size = Vector2(223,44),
			Location = Vector2(282, 557),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Text = lang:GetText("取 消"),
			TextColor = ARGB(255, 226, 217, 208),
			HighlightTextColor = ARGB(255, 226, 217, 208),
			TextAlign = "kAlignCenterMiddle",
			DisabledTextColor = ARGB(255, 37, 37, 37),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_normal.dds", Vector4(32, 0, 32, 0)),
				HoverImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_hover.dds", Vector4(32, 0, 32, 0)),
				DownImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_down.dds", Vector4(32, 0, 32, 0)),
				DisabledImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_disabled.dds", Vector4(32, 0, 32, 0)),
			},
			EventClick = function()
				HideTiaoZhan()
			end
		},
	},
}

function create_battle_room(index,x,y)
	return 	Gui.Control ("room_list"..index)
	{		
		Location = Vector2(x, y),
		Size = Vector2(324, 705),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_rank_bg_01.dds", Vector4(34, 34, 34, 34)),
		},
		--战队战房间
		Gui.ListTreeView ("Fight_Team_Room_Player"..index)
		{
			Style = "Gui.ListTreeViewWith_VScroll_FightTeam",
			Size = Vector2(300, 260),
			Location = Vector2(10,15),
			ItemHeight = 40,
			TreeVisible = false,
			-- MY_SPLIT_WIDTH = 28, --CHECKBOX 鼠标点击的偏移量
			AlwaysSelect = false,
			HeaderVisible = false,
			-- VScrollBarDisplay = "kVisible",
			-- VScrollBarWidth = 16,
			-- VScrollBarButtonSize = 16,
			CanKeySelect = false,
		},
		Gui.Control 
		{		
			Location = Vector2(10, 259),
			Size = Vector2(55, 20),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_vs_ico.dds", Vector4(0, 0, 0, 0)),
			},
		},
		
		Gui.Label ("vs_fightname"..index)
		{
			Location = Vector2(80, 259),
			Size = Vector2(200, 30),
			BackgroundColor = ARGB(0, 255, 255, 255),
			Text = lang:GetText("大冲锋"),
			FontSize = 14,
			TextColor = ARGB(255, 226, 217, 208),
			TextAlign = "kAlignLeftMiddle",
		},
		
		Gui.Control 
		{		
			Location = Vector2(9, 283),
			Size = Vector2(309, 366),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_task_bg_6.dds", Vector4(12, 10, 42, 40)),	
			},
			Gui.Control ("map_name"..index)
			{		
				Location = Vector2(29, 12),
				Size = Vector2(240, 148),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_battlefield_map_random_b.dds", Vector4(0, 0, 0, 0)),
				},
			},
			Gui.Label
			{		
				Location = Vector2(10, 167),
				Size = Vector2(140, 30),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Text = lang:GetText("房主名称："),
				FontSize = 14,
				TextColor = ARGB(255, 255, 111, 56),
				TextAlign = "kAlignRightMiddle",
			},
			Gui.Label ("host_name"..index)
			{		
				Location = Vector2(160, 167),
				Size = Vector2(170, 30),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Text = "????",
				FontSize = 14,
				TextColor = ARGB(255, 226, 217, 208),
				TextAlign = "kAlignLeftMiddle",
			},
			Gui.Label
			{		
				Location = Vector2(10, 188),
				Size = Vector2(140, 30),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Text = lang:GetText("游戏模式："),
				FontSize = 14,
				TextColor = ARGB(255, 255, 111, 56),
				TextAlign = "kAlignRightMiddle",
			},
			Gui.Label ("game_mode"..index)
			{		
				Location = Vector2(160, 188),
				Size = Vector2(170, 30),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Text = "????",
				FontSize = 14,
				TextColor = ARGB(255, 226, 217, 208),
				TextAlign = "kAlignLeftMiddle",
			},
			Gui.Label
			{		
				Location = Vector2(10, 209),
				Size = Vector2(140, 30),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Text = lang:GetText("中途加入："),
				FontSize = 14,
				TextColor = ARGB(255, 255, 111, 56),
				TextAlign = "kAlignRightMiddle",
			},
			Gui.Label ("can_join"..index)
			{		
				Location = Vector2(160, 209),
				Size = Vector2(170, 30),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Text = "????",
				FontSize = 14,
				TextColor = ARGB(255, 226, 217, 208),
				TextAlign = "kAlignLeftMiddle",
			},
			Gui.Label
			{		
				Location = Vector2(10, 230),
				Size = Vector2(140, 30),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Text = lang:GetText("复活时间："),
				FontSize = 14,
				TextColor = ARGB(255, 255, 111, 56),
				TextAlign = "kAlignRightMiddle",
			},
			Gui.Label ("fuhuo_time"..index)
			{		
				Location = Vector2(160, 230),
				Size = Vector2(170, 30),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Text = "????",
				FontSize = 14,
				TextColor = ARGB(255, 226, 217, 208),
				TextAlign = "kAlignLeftMiddle",
			},
			
			Gui.Label
			{		
				Location = Vector2(10, 251),
				Size = Vector2(140, 30),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Text = lang:GetText("胜利条件："),
				FontSize = 14,
				TextColor = ARGB(255, 255, 111, 56),
				TextAlign = "kAlignRightMiddle",
			},
			Gui.Label ("win"..index)
			{		
				Location = Vector2(160, 251),
				Size = Vector2(170, 30),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Text = "????",
				FontSize = 14,
				TextColor = ARGB(255, 226, 217, 208),
				TextAlign = "kAlignLeftMiddle",
			},
			Gui.Label
			{		
				Location = Vector2(10, 272),
				Size = Vector2(140, 30),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Text = lang:GetText("特殊战："),
				FontSize = 14,
				TextColor = ARGB(255, 255, 111, 56),
				TextAlign = "kAlignRightMiddle",
			},
			Gui.Label ("special_job"..index)
			{		
				Location = Vector2(160, 272),
				Size = Vector2(170, 30),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Text = "????",
				FontSize = 14,
				TextColor = ARGB(255, 226, 217, 208),
				TextAlign = "kAlignLeftMiddle",
			},
			Gui.Label
			{		
				Location = Vector2(10, 293),
				Size = Vector2(140, 30),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Text = lang:GetText("战力平衡："),
				FontSize = 14,
				TextColor = ARGB(255, 255, 111, 56),
				TextAlign = "kAlignRightMiddle",
			},
			Gui.Label ("war_balance"..index)
			{		
				Location = Vector2(160, 293),
				Size = Vector2(170, 30),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Text = "????",
				FontSize = 14,
				TextColor = ARGB(255, 226, 217, 208),
				TextAlign = "kAlignLeftMiddle",
			},
			Gui.Label
			{		
				Location = Vector2(10, 314),
				Size = Vector2(140, 30),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Text = lang:GetText("自动开始："),
				FontSize = 14,
				TextColor = ARGB(255, 255, 111, 56),
				TextAlign = "kAlignRightMiddle",
			},
			Gui.Label ("auto_begin"..index)
			{		
				Location = Vector2(160, 314),
				Size = Vector2(170, 30),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Text = "????",
				FontSize = 14,
				TextColor = ARGB(255, 226, 217, 208),
				TextAlign = "kAlignLeftMiddle",
			},
		},
		--加入
		Gui.Button ("b_join"..index)
		{
			Size = Vector2(190,37),
			Location = Vector2(59, 656),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Text = lang:GetText("加入"),
			TextColor = ARGB(255, 0, 0, 0),
			TextAlign = "kAlignCenterMiddle",
			-- HighlightTextColor = ARGB(255, 229, 255, 252),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_v2_01_normal.dds", Vector4(5, 5, 5, 5)),
				HoverImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_v2_01_hover.dds", Vector4(5, 5, 5, 5)),
				DownImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_v2_01_down.dds", Vector4(5, 5, 5, 5)),
				DisabledImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_v2_01_disabled.dds", Vector4(5, 5, 5, 5)),
			},
			EventClick = function()
				-- state.is_fight_team_server = true
				local state = ptr_cast(game.CurrentState)
				state:GetBattleGroupJoin(three_battle_info[index].battlegroup_id)
				
				-- L_LobbyMain.GotoPlayerRoom(three_battle_player_info[index][1].character_name)
				HideZhiHuiSuo()
			end
		},
	}
end 

zhihuisuo_ui = Gui.Create()
{
	Gui.Control "root"
	{
		Size = Vector2(1050, 859),
		Location = Vector2(0, 0),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_contact_bg1_01.dds", Vector4(163,163,53,53)),
		},
		Gui.Label
		{
			Location = Vector2(20, 20),
			Size = Vector2(1000, 30),
			BackgroundColor = ARGB(0, 255, 255, 255),
			Text = lang:GetText("交战指挥所"),
			FontSize = 24,
			TextColor = ARGB(255, 255, 111, 56),
			TextAlign = "kAlignLeftMiddle",
		},
		
		Gui.Control "c_three"
		{
			Size = Vector2(1010, 769),
			Location = Vector2(20, 59),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_contact_bg2.dds", Vector4(38, 41, 38, 66)),	
			},
			create_battle_room(1,7,11),
			create_battle_room(2,341,11),
			create_battle_room(3,675,11),
		},
		
		Gui.Button "m_Left"
		{
			Size = Vector2(222,44),
			Location = Vector2(182,780),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Text = lang:GetText("上一页"),
			TextColor = ARGB(255, 226, 217, 208),
			TextAlign = "kAlignCenterMiddle",
			DisabledTextColor = ARGB(255, 37, 37, 37),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_normal.dds", Vector4(32, 0, 32, 0)),
				HoverImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_hover.dds", Vector4(32, 0, 32, 0)),
				DownImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_down.dds", Vector4(32, 0, 32, 0)),
				DisabledImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_disabled.dds", Vector4(32, 0, 32, 0)),
			},
			EventClick = function()
				if three_battle_page ~= 0 then
					three_battle_page = three_battle_page - 1
					if three_battle_page == 0 then
						zhihuisuo_ui.m_Left.Enable = false
					end
					-- zhihuisuo_ui.m_Right.Enable = true
					if team_data then
						state:GetBattleGroups(team_data[2],0+3*three_battle_page,3,0)
					end
				end
			end
		},
		
		Gui.Button "m_Right"
		{
			Size = Vector2(222,44),
			Location = Vector2(414,780),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Text = lang:GetText("下一页"),
			TextColor = ARGB(255, 226, 217, 208),
			TextAlign = "kAlignCenterMiddle",
			DisabledTextColor = ARGB(255, 37, 37, 37),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_normal.dds", Vector4(32, 0, 32, 0)),
				HoverImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_hover.dds", Vector4(32, 0, 32, 0)),
				DownImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_down.dds", Vector4(32, 0, 32, 0)),
				DisabledImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_disabled.dds", Vector4(32, 0, 32, 0)),
			},
			EventClick = function()
				three_battle_page = three_battle_page + 1
				zhihuisuo_ui.m_Left.Enable = true
				if team_data then
					state:GetBattleGroups(team_data[2],0+3*three_battle_page,3,0)
				end
			end
		},
		
		Gui.Button "m_Refresh"
		{
			Size = Vector2(222,44),
			Location = Vector2(646,780),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Text = lang:GetText("刷新"),
			TextColor = ARGB(255, 226, 217, 208),
			TextAlign = "kAlignCenterMiddle",
			DisabledTextColor = ARGB(255, 37, 37, 37),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_normal.dds", Vector4(32, 0, 32, 0)),
				HoverImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_hover.dds", Vector4(32, 0, 32, 0)),
				DownImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_down.dds", Vector4(32, 0, 32, 0)),
				DisabledImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_disabled.dds", Vector4(32, 0, 32, 0)),
			},
			EventClick = function()
				if team_data then
					print("three_battle_page:"..three_battle_page)
					state:GetBattleGroups(team_data[2],0+3*three_battle_page,3,0)
					zhihuisuo_ui.update_info:CleanAll()
					zhihuisuo_ui.update_info:AddTime(update_time)
				end	
			end
		},
		
		--退出
		Gui.Button
		{
			Size = Vector2(48,48),
			Location = Vector2(992, 5),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_normal.dds", Vector4(10, 10, 10, 10)),
				HoverImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_hover.dds", Vector4(10, 10, 10, 10)),
				DownImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_down.dds", Vector4(10, 10, 10, 10)),
				DisabledImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_disabled.dds", Vector4(0, 0, 0, 0)),	
			},
			EventClick = function()
				HideZhiHuiSuo()
			end,
		},
		
		Gui.TimeControl "update_info"
		{
			Size = Vector2(5,5),
			Dock = "kDockCenter",
			BackgroundColor = ARGB(0, 255, 255, 255),
			EventTimeOut = function(sender, e)
				print("three_battle_page:"..three_battle_page)
				state:GetBattleGroups(team_data[2],0+3*three_battle_page,3,0)
				sender:AddTime(update_time)
			end
		},
	},
}	

battle_time_ui = Gui.Create()
{
	Gui.Control "root"
	{
		Size = Vector2(218,219),
		Location = Vector2(0, 0),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_rank_bg_01.dds", Vector4(34, 34, 34, 34)),
		},
		
		Gui.TimeControl "change_time"
		{
			Size = Vector2(5,5),
			Dock = "kDockCenter",
			BackgroundColor = ARGB(0, 255, 255, 255),
			EventTimeOut = function(sender, e)
				time_num = time_num+1
				battle_time_ui.change_time:AddTime(1)
				if time_num < 10 then
					battle_time_ui.ten_num.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("InGameUI/countdown_number.dds", Vector4(0, 0, 0, 0),Vector4(0, 0, 116/1160, 1))}
					battle_time_ui.one_num.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("InGameUI/countdown_number.dds", Vector4(0, 0, 0, 0),Vector4(time_num*116/1160, 0, (time_num+1)*116/1160, 1))}
				else
					battle_time_ui.ten_num.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("InGameUI/countdown_number.dds", Vector4(0, 0, 0, 0),Vector4(math.floor(time_num/10)*116/1160, 0, (math.floor(time_num/10)+1)*116/1160, 1))}
					battle_time_ui.one_num.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("InGameUI/countdown_number.dds", Vector4(0, 0, 0, 0),Vector4(time_num%10*116/1160, 0, (time_num%10+1)*116/1160, 1))}	
				end
				if time_num > 60 then
					MessageBox.ShowWithTimer(1,lang:GetText("暂时无法匹配，请稍后再试"))
					if battle_time_ui.b_exit.Visible then
						battle_time_ui.change_time:CleanAll()
						state:BattleGroupStartSearch(1)
						fightteam_fight_ui.b_pipei.Enable = true
						for i = 9 , 14 do
							state:ChangeSlotStatus(i,0)
						end
					--	HideBattleTime()
					end
				end
			end
		},
		
		-- Gui.Control "Cctr_flash_Bg"
		-- {
			-- Location = Vector2(10, 0),
			-- Size = Vector2(203, 160),
			-- BackgroundColor = ARGB(255, 255, 255, 255),
			-- UseTime = true,
			-- DisplayTime = 0.25,
		-- },
		
		Gui.Label
		{
			Location = Vector2(0, 5),
			Size = Vector2(218, 30),
			BackgroundColor = ARGB(0, 255, 255, 255),
			Text = lang:GetText("自动匹配......"),
			FontSize = 20,
			TextAlign = "kAlignCenterMiddle",
			TextColor = ARGB(255, 255, 111, 56),
		},
		
		Gui.Control "ten_num"
		{
			Size = Vector2(64, 97),
			Location = Vector2(42, 41),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = nil,	
			},
		},
		
		Gui.Control "one_num"
		{
			Size = Vector2(64, 97),
			Location = Vector2(110, 41),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = nil,
			},
		},
		
		Gui.Button "b_exit"
		{
			Size = Vector2(124,44),
			Location = Vector2(47, 150),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Text = lang:GetText("离开"),
			TextColor = ARGB(255, 226, 217, 208),
			TextAlign = "kAlignCenterMiddle",
			DisabledTextColor = ARGB(255, 37, 37, 37),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_normal.dds", Vector4(32, 0, 32, 0)),
				HoverImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_hover.dds", Vector4(32, 0, 32, 0)),
				DownImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_down.dds", Vector4(32, 0, 32, 0)),
				DisabledImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_disabled.dds", Vector4(32, 0, 32, 0)),
			},

			EventClick = function()
				state:BattleGroupStartSearch(1)
				fightteam_fight_ui.b_pipei.Enable = true
				for i = 9 , 14 do
					state:ChangeSlotStatus(i,0)
				end
			end
		},
	}
}

function create_quick_buy(index,x,y)
	return 	Gui.Control ("zhandui_quick"..index)
	{		
		Location = Vector2(x, y),
		Size = Vector2(202, 256),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_rank_bg_01.dds", Vector4(34, 34, 34, 34)),
		},
		Gui.Label ("quick_name"..index)
		{		
			Location = Vector2(0, 5),
			Size = Vector2(202, 30),
			BackgroundColor = ARGB(0, 255, 255, 255),
			Text = lang:GetText("战队能量块"),
			TextAlign = "kAlignCenterMiddle",
			FontSize = 18,
			TextColor = ARGB(255, 255, 133, 0),
		},
		Gui.ItemBoxBtn ("quick_pic"..index)
		{
			Size = Vector2(182, 80),
			Location = Vector2(12, 28),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Empty = false,
			Type = 1,
			Skin = Gui.ItemBoxBtnSkin
			{
				NeutralNormalImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_slot.dds", Vector4(10, 10, 10, 10)),
				NeutralHoverImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_slot.dds", Vector4(10, 10, 10, 10)),
				NeutralSelectedImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_slot.dds", Vector4(10, 10, 10, 10)),
				NeutralDisabledImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_slot.dds", Vector4(10, 10, 10, 10)),
			},
		},
		Gui.Label ("quick_description"..index)
		{		
			Location = Vector2(0, 116),
			Size = Vector2(202, 40),
			BackgroundColor = ARGB(0, 255, 255, 255),
			Text = lang:GetText("小幅度增加战队经验"),
			FontSize = 16,
			TextColor = ARGB(255, 255, 133, 0),
			TextAlign = "kAlignCenterMiddle",
		},
		Gui.Label
		{		
			Location = Vector2(3, 160),
			Size = Vector2(96, 30),
			BackgroundColor = ARGB(0, 255, 255, 255),
			Text = lang:GetText("剩余："),
			FontSize = 16,
			TextColor = ARGB(255, 238, 191, 11),
			TextAlign = "kAlignCenterMiddle",
		},
		Gui.Label ("quick_quantity"..index)
		{		
			Location = Vector2(100, 157),
			Size = Vector2(95, 31),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_fastuse_bg_01.dds", Vector4(0, 0, 0, 0)),
			},
			TextAlign = "kAlignCenterMiddle",
			Text = "1111111",
			FontSize = 18,
			TextColor = ARGB(255, 238, 191, 11),
		},
		
		Gui.Button
		{
			Size = Vector2(97,36),
			Location = Vector2(4, 206),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Text = lang:GetText("购买"),
			TextColor = ARGB(255, 0, 0, 0),
			TextAlign = "kAlignCenterMiddle",
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_v2_01_normal.dds", Vector4(0, 0, 0, 0)),
				HoverImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_v2_01_hover.dds", Vector4(0, 0, 0, 0)),
				DownImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_v2_01_down.dds", Vector4(0, 0, 0, 0)),
				DisabledImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_v2_01_disabled.dds", Vector4(0, 0, 0, 0)),
			},

			EventClick = function()
				key_num = index
				ShowRapidShoppingWin()
				if key_num == 1 then
					Rapid_Shopping_Win_ui.money_type.Text = lang:GetText("C币")
				else
					Rapid_Shopping_Win_ui.money_type.Text = lang:GetText("FC点")
				end
			end
		},
		
		Gui.Button
		{
			Size = Vector2(97,36),
			Location = Vector2(103, 206),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Text = lang:GetText("使用"),
			TextColor = ARGB(255, 0, 0, 0),
			TextAlign = "kAlignCenterMiddle",
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_v2_01_normal.dds", Vector4(0, 0, 0, 0)),
				HoverImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_v2_01_hover.dds", Vector4(0, 0, 0, 0)),
				DownImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_v2_01_down.dds", Vector4(0, 0, 0, 0)),
				DisabledImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_v2_01_disabled.dds", Vector4(0, 0, 0, 0)),
			},

			EventClick = function()
				L_MessageBox.ShowWaiter(lang:GetText("正在购买商品..."))
				rpc.safecallload("team_burnt_use", {pid = ptr_cast(game.CurrentState):GetCharacterId(), tid = t_id, sid = key_item[index].sid, ptid = pt_id},
				function(data)
					L_MessageBox.CloseWaiter()
					if data.error == nil then
						RequestQuickBuy()
						quick_buy_ui.battle_lv.Text = "LV"..data.info[1]
						if battel_exp == 0 then
							battel_exp = data.info[1]
						end
						if battel_exp ~= data.info[1] then
							gui:PlayAudio("kUIA_GET_GOOD_REWARD")
							battel_exp = data.info[1]
						end
						battel_exp = data.info[1]
						if data.info[1] ~= max_fightteam_level then
							quick_buy_ui.exp_font.Size = Vector2(464*(data.info[2]/data.info[3]), 19)
							quick_buy_ui.team_exp.Text = data.info[2].."/"..data.info[3]
							ShowLevelWindowMove(data.info[6],data.info[6])
						else
							quick_buy_ui.exp_font.Size = Vector2(0, 19)
							quick_buy_ui.team_exp.Text = "Max"
							ShowLevelWindowMove(0,data.info[6])
						end
						gui:PlayAudio("kUIA_USE_EXP")
					else
						MessageBox.ShowWithConfirm(data.error)
					end
				end)
			end
		},
	}	
end

quick_buy_ui = Gui.Create()
{
	Gui.Control "root"
	{
		Size = Vector2(773,421),
		Location = Vector2(0, 0),
		BackgroundColor = ARGB(0, 255, 255, 255),
		Gui.Control
		{
			Size = Vector2(660,411),
			Location = Vector2(100, 0),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_contact_bg1_01.dds", Vector4(163,163,53,53)),
			},
			Gui.Label
			{		
				Location = Vector2(33, 16),
				Size = Vector2(170, 30),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Text = lang:GetText("快速使用:"),
				FontSize = 28,
				TextColor = ARGB(255, 255, 133, 0),
				TextAlign = "kAlignLeftMiddle",
			},
			Gui.Label
			{		
				Location = Vector2(205, 20),
				Size = Vector2(400, 24),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Text = lang:GetText("使用能量块为你的战队提升等级"),
				FontSize = 18,
				TextColor = ARGB(255, 217, 209, 201),
				TextAlign = "kAlignLeftMiddle",
			},
			Gui.Label
			{		
				Location = Vector2(210, 40),
				Size = Vector2(400, 25),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Text = lang:GetText("(每天限用一次)"),
				FontSize = 22,
				TextColor = ARGB(255, 254, 17, 17),
				TextAlign = "kAlignLeftMiddle",
			},
			
			--退出
			Gui.Button
			{
				Size = Vector2(48,48),
				Location = Vector2(603, 8),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_normal.dds", Vector4(10, 10, 10, 10)),
					HoverImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_hover.dds", Vector4(10, 10, 10, 10)),
					DownImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_down.dds", Vector4(10, 10, 10, 10)),
					DisabledImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_disabled.dds", Vector4(0, 0, 0, 0)),	
				},
				EventClick = function()
					FillTeam()
					HideQuickBuy()
				end,
			},
			Gui.Label "des"
			{
				Size = Vector2(400, 24),
				Location = Vector2(20, 380),
			},
		},
		Gui.Control
		{
			Size = Vector2(618, 308),
			Location = Vector2(120, 71),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_contact_bg2.dds", Vector4(38, 41, 38, 66)),	
			},
		},
		Gui.Control
		{
			Size = Vector2(818, 308),
			Location = Vector2(120, 71),
			BackgroundColor = ARGB(0, 255, 255, 255),
	
			create_quick_buy(1,7,7),
			create_quick_buy(2,208,7),
			create_quick_buy(3,409,7),
			
			Gui.Label "battle_lv"
			{		
				Location = Vector2(7, 265),
				Size = Vector2(140, 30),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Text = "LV1",
				FontSize = 20,
				TextColor = ARGB(255, 255, 133, 0),
			},
			Gui.Control "exp_back"
			{
				Size = Vector2(545, 19),
				Location = Vector2(60,275),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_melting_bar01_bg.dds", Vector4(5, 5, 5, 5)),
				},
				Gui.Control "exp_font"
				{
					Size = Vector2(545, 19),
					Location = Vector2(0, 0),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_melting_bar01_content.dds", Vector4(5, 5, 5, 5)),
					},
				},
				Gui.Label "team_exp"
				{
					Size = Vector2(545, 19),
					Location = Vector2(0, 0),
					Text = "1/1",
					FontSize = 14,
					TextColor = ARGB(255, 214, 253, 255),
					TextAlign = "kAlignCenterMiddle",
				},
			},
			Gui.ChangeControl "ctr_up_level"
			{
				Size = Vector2(164, 56),
				Location = Vector2(60,225),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Normsize = Vector2(164, 56),
				NormLocation = Vector2(60,225),
				Visible = false,
				EventPlayEnd = function(Sender,e)
					Sender.Visible = false
				end
			},
		},		
	}
}

--快速购买界面
local Rapid_Shopping_Win = 
{
	Gui.Control "Rapid_Shopping_root"
	{	
		Size = Vector2(1200, 900),
		BackgroundColor = ARGB(0, 255, 255, 255),
		Location = Vector2(0, 0),
		
		Gui.Control
		{	
			Size = Vector2(397, 395),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Dock = "kDockCenter",
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_contact_bg1_01.dds", Vector4(163,163,53,53)),
			},

			Gui.Control
			{	
				Size = Vector2(355, 352),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Location = Vector2(21, 22),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/main_bar02.dds", Vector4(8, 8, 8, 8)),
				},
				
				Gui.Label
				{
					Size = Vector2(353, 35),
					Location = Vector2(0, 0),
					TextColor = ARGB(255, 255, 210, 0),
					FontSize = 18,
					TextAlign = "kAlignLeftMiddle",
					Text = lang:GetText("快速购买"),
					BackgroundColor = ARGB(255,255,255,255),
					TextPadding = Vector4(8,0,0,8),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_onlinetime_bg_5.dds", Vector4(8, 8, 8, 8)),
					},
				},
				
				Gui.Control
				{	
					Size = Vector2(325, 260),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Location = Vector2(16, 39),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_01.dds", Vector4(40, 40, 40, 40)),
					},
					
					Gui.Control
					{	
						Size = Vector2(274, 208),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Location = Vector2(24, 10),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_06.dds", Vector4(32, 28, 32, 50)),
						},
						
						Gui.Label "name"
						{
							Size = Vector2(274, 28),
							Location = Vector2(0, 0),
							TextColor = ARGB(255, 255, 210, 0),
							FontSize = 18,
							TextAlign = "kAlignCenterMiddle",
							Text = lang:GetText("密码卡"),
							BackgroundColor = ARGB(0,255,255,255),
							TextPadding = Vector4(0,0,0,3),
						},
						
						Gui.TextArea "des"
						{
							Size = Vector2(200, 50),
							Location = Vector2(55, 110),
							TextColor = ARGB(255, 255, 210, 0),
							FontSize = 16,
							Readonly = true,
							Fold = true,
							BackgroundColor = ARGB(255,255,255,255),
						},
						
						Gui.Button
						{
							Size = Vector2(20,32),
							Location = Vector2(32, 167),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Skin = Gui.ButtonSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_fanye_button_normal_L.dds", Vector4(0, 0, 0, 0)),
								HoverImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_fanye_button_hover_L.dds", Vector4(0, 0, 0, 0)),
								DownImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_fanye_button_down_L.dds", Vector4(0, 0, 0, 0)),
								DisabledImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_fanye_button_disabled_L.dds", Vector4(0, 0, 0, 0)),
							},
							EventClick = function()
								Rapid_Shopping_Win_ui.Tbox_Totle_num.Text = math.ceil(tonumber(Rapid_Shopping_Win_ui.Tbox_Totle_num.Text)) - 1
							end,
						},
						
						Gui.Textbox "Tbox_Totle_num"
						{
							Size = Vector2(154, 34),
							Location = Vector2(61, 166),
							TextColor = ARGB(255, 255, 210, 0),
							FontSize = 24,
							Text = "1",
							BackgroundColor = ARGB(255,255,255,255),
							TextPadding = Vector4(71,0,0,0),
							InputNumberOnly = true,
							Skin = Gui.TextboxSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_04.dds", Vector4(12, 0, 12, 0)),
								ActiveImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_04.dds", Vector4(12, 0, 12, 0)),
								DisabledImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_04.dds", Vector4(12, 0, 12, 0)),
							},
							
							EventTextChanged = function()
								if Rapid_Shopping_Win_ui.Tbox_Totle_num.Text ~= "" then
									if math.ceil(tonumber(Rapid_Shopping_Win_ui.Tbox_Totle_num.Text)) > 300 then
										Rapid_Shopping_Win_ui.Tbox_Totle_num.Text = "300"
										return
									elseif math.ceil(tonumber(Rapid_Shopping_Win_ui.Tbox_Totle_num.Text)) < 1 then
										Rapid_Shopping_Win_ui.Tbox_Totle_num.Text = "1"
										return
									end
									if string.sub(Rapid_Shopping_Win_ui.Tbox_Totle_num.Text,1,1) == "0" then
										Rapid_Shopping_Win_ui.Tbox_Totle_num.Text = string.sub(Rapid_Shopping_Win_ui.Tbox_Totle_num.Text,2)
										return
									end
									Rapid_Shopping_Win_ui.Tbox_Totle_num.TextPadding = Vector4(77 - 6*string.len(Rapid_Shopping_Win_ui.Tbox_Totle_num.Text),0,0,0)
								end
								SetHummerTotalMoney()
							end,
							
							EventLeave = function()
								if Rapid_Shopping_Win_ui.Tbox_Totle_num.Text == "" then
									Rapid_Shopping_Win_ui.Tbox_Totle_num.Text = 1
								end
							end,
							
							EventValueNoNumber = function()
								Rapid_Shopping_Win_ui.lab_timer_ctr:Show()
							end,
						},
						
						Gui.Button
						{
							Size = Vector2(20,32),
							Location = Vector2(223, 167),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Skin = Gui.ButtonSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_fanye_button_normal_R.dds", Vector4(0, 0, 0, 0)),
								HoverImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_fanye_button_hover_R.dds", Vector4(0, 0, 0, 0)),
								DownImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_fanye_button_down_R.dds", Vector4(0, 0, 0, 0)),
								DisabledImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_fanye_button_disabled_R.dds", Vector4(0, 0, 0, 0)),
							},
							EventClick = function()
								Rapid_Shopping_Win_ui.Tbox_Totle_num.Text = math.ceil(tonumber(Rapid_Shopping_Win_ui.Tbox_Totle_num.Text)) + 1
							end,
						},
					},
					
					Gui.Label
					{
						Size = Vector2(110, 28),
						Location = Vector2(25, 220),
						TextColor = ARGB(255, 255, 210, 0),
						FontSize = 18,
						TextAlign = "kAlignCenterMiddle",
						Text = lang:GetText("您总共要支付"),
						BackgroundColor = ARGB(0,255,255,255),
						TextPadding = Vector4(0,0,0,3),
					},
					
					Gui.Label "Total_money"
					{
						Size = Vector2(98, 28),
						Location = Vector2(137, 220),
						TextColor = ARGB(255, 255, 210, 0),
						FontSize = 18,
						TextAlign = "kAlignCenterMiddle",
						Text = "0",
						BackgroundColor = ARGB(255,255,255,255),
						TextPadding = Vector4(0,0,0,3),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_03.dds", Vector4(8, 8, 8, 8)),
						},
					},
					
					Gui.Label "money_type"
					{
						Size = Vector2(80, 28),
						Location = Vector2(252, 220),
						TextColor = ARGB(255, 255, 210, 0),
						FontSize = 18,
						TextAlign = "kAlignLeftMiddle",
						Text = lang:GetText("FC点"),
						BackgroundColor = ARGB(0,255,255,255),
						TextPadding = Vector4(0,0,0,3),
					},
					
					Gui.Label "lab_timer_ctr"
					{
						Size = Vector2(116,35),
						Location = Vector2(100, 207),
						BackgroundColor = ARGB(255, 255, 255, 255),
						TextColor = ARGB(255, 0, 0, 0),
						Visible = false,
						UseTimer = true,
						DisplayTime = 1,
						FontSize = 12,
						TextAlign = "kAlignCenterMiddle",
						Text = lang:GetText("只能输入数字0～9"),
						TextPadding = Vector4(0,8,0,0),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_05.dds", Vector4(37, 18, 14, 12)),
						},
						
						EventClose = function()
							
						end
					},
				},
				
				Gui.Button
				{
					Size = Vector2(124,44),
					Location = Vector2(113, 305),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Text = lang:GetText("购 买"),
					TextColor = ARGB(255, 229, 255, 252),
					TextAlign = "kAlignCenterMiddle",
					HighlightTextColor = ARGB(255, 229, 255, 252),
					Padding = Vector4(0, 0, 0, 5),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_onlinetime_button_2_normal.dds", Vector4(0, 0, 0, 0)),
						HoverImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_onlinetime_button_2_hover.dds", Vector4(0, 0, 0, 0)),
						DownImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_onlinetime_button_2_down.dds", Vector4(0, 0, 0, 0)),
						DisabledImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_onlinetime_button_2_disabled.dds", Vector4(0, 0, 0, 0)),
					},
					EventClick = function()
						local tempnum = Rapid_Shopping_Win_ui.Tbox_Totle_num.Text
						HideRapidShoppingWin()
						local args = {num = tempnum, pid = ptr_cast(game.CurrentState):GetCharacterId(), sid = key_item[key_num].sid}
						rpc.safecallload("shop_fast_buy", args,
													function(data)
														if data.result == 0 then
															MessageBox.ShowWithTwoButtons(lang:GetText("你的FC点不足，请充值"),lang:GetText("充值"),lang:GetText("取消"),
																					function()
																						gui:ShowIE()
																					end,
																					nil
																					)
														else
															MessageBox.ShowWithTimer(1,lang:GetText("购买成功"))
															RequestQuickBuy()
														end
													end)
					end,
				},
			},
		},
		
		Gui.ItemBoxBtn"itembox_hummer"
		{
			Style = "Gui.ItemBoxBtn_ib",
			Size = Vector2(153,79),
			Location = Vector2(522,353),--38 10
			--BtnLocation = Vector2(45, 72),
			--BtnText = lang:GetText("购买"),
			--Enable = false,
			BackgroundColor = ARGB(255,255,255,255),
			Skin = Gui.ItemBoxBtnSkin
			{
				NeutralNormalImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_02.dds", Vector4(0, 0, 0, 0)),
				--NeutralHoverImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_02.dds", Vector4(0, 0, 0, 0)),
				NeutralSelectedImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_02.dds", Vector4(0, 0, 0, 0)),
				NeutralDisabledImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_02.dds", Vector4(0, 0, 0, 0)),
			},
			
			--ItemIcon = Gui.Icon("LobbyUI/ibt_icon/machet_4.tga"),
			--Padding = Vector4(10,0,10,0),
			
			--ItemIconPastDue = Gui.Icon("LobbyUI/ShoppingMall/vip_chest/lb_vipgifts_slot_flash.dds"),
	--[[		EventMouseEnter = function(sender, e)
				L_ToolTips.FillToolTipsVIPPresent(1, Rapid_Shopping_Win_ui.Rapid_Shopping_root, magice_hummer_Info)
			end,
			EventToolTipsShow = function(sender, e)
				L_ToolTips.ShowToolTipsShowWindow(sender,Vector2(1200, 900),sender.Location + sender.Parent.Location)
			end,
			EventMouseLeave = function(sender, e)
				L_ToolTips.HideToolTipsWindow()
			end,]]
			
		},
		--退出
		Gui.Button
		{
			Size = Vector2(48,48),
			Location = Vector2(743, 260),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_normal.dds", Vector4(10, 10, 10, 10)),
				HoverImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_hover.dds", Vector4(10, 10, 10, 10)),
				DownImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_down.dds", Vector4(10, 10, 10, 10)),
				DisabledImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_disabled.dds", Vector4(0, 0, 0, 0)),	
			},
			EventClick = function()
				HideRapidShoppingWin()
			end,
		},
	},
}

GetBattleGift = Gui.Create()
{
	Gui.Control "main_gift"
	{
		Size = Vector2(538,332),
		Dock = "kDockCenter",
		BackgroundColor = ARGB(255, 255, 255, 255),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_contact_bg1_01.dds", Vector4(163,163,53,53)),
		},
		Gui.Control 
		{
			Size = Vector2(497,295),
			Dock = "kDockCenter",
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				--BackgroundImage = Gui.Image("LobbyUI/dailycheck/main_bar02.dds",Vector4(38, 38, 38, 38)),
			},
			Gui.Label "gift_name"
			{
				Size = Vector2(497, 32),
				Location = Vector2(0, 23),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Text = "",
				FontSize = 16,
				TextAlign = "kAlignCenterMiddle",
				TextColor = ARGB(255, 215, 232, 227),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/dailycheck/text_bar.dds",Vector4(70, 6, 70, 6)),
				},
			},
			Gui.ItemBoxBtn "gift_btn"
			{
				Size = Vector2(168, 80),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Location = Vector2(164, 83),
				Empty = false,
				LoadingImage = Gui.AnimatedImage("LobbyUI/loading_ring.tga", 4, 2, 8),
				Type = 1,
				Enable = false,
				Skin = Gui.ItemBoxBtnSkin
				{								
					--NeutralNormalImage = Gui.Image("LobbyUI/dailycheck/gift_14day.dds", Vector4(0, 0, 0, 0)),
					-- NeutralHoverImage = Gui.Image("LobbyUI/dailycheck/gift_bar.dds", Vector4(0, 0, 0, 0)),
					-- NeutralSelectedImage = Gui.Image("LobbyUI/dailycheck/gift_bar.dds", Vector4(0, 0, 0, 0)),
					NeutralDisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche1_normal.dds", Vector4(0, 0, 0, 0)),								
				},
				--ItemIcon = Gui.Icon("LobbyUI/dailycheck/gift_7day.dds"),				
			},
			
			Gui.Label
			{
				Size = Vector2(168, 20),
				Location = Vector2(164, 173),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Text = lang:GetText("每周限领1次"),
				FontSize = 16,
				TextAlign = "kAlignCenterMiddle",
				TextColor = ARGB(255, 255, 0, 0),
			},
			Gui.Button
			{
				Size = Vector2(124,44),
				Location = Vector2(186, 212),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Enable = true,
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_normal.dds", Vector4(32, 0, 32, 0)),
					HoverImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_hover.dds", Vector4(32, 0, 32, 0)),
					DownImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_down.dds", Vector4(32, 0, 32, 0)),
					DisabledImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_disabled.dds", Vector4(32, 0, 32, 0)),
				},
				Text = lang:GetText("确定"),
				TextColor = ARGB(255, 229, 255, 252),
				TextAlign = "kAlignCenterMiddle",
				HighlightTextColor = ARGB(255, 229, 255, 252),
				EventClick = function()
					Hide_GetBattleGift()
				end
			},
		},
	},
}

LeaveBattleWarn = Gui.Create()
{
	Gui.Control "root"
	{
		Size = Vector2(526, 272),
		Dock = "kDockCenter",
		BackgroundColor = ARGB(255, 255, 255, 255),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/lb_common_up_bg_01.dds", Vector4(200, 20, 100, 0)),
		},
		Gui.Control 
		{
			Size = Vector2(80,68),
			Location = Vector2(30, 30),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/mokuai_title02.dds",Vector4(0, 0, 0, 0)),
			},
		},
		
		Gui.RichEdit "warn_msg_1"
		{
			Size = Vector2(400, 30),
			Location = Vector2(122, 50),
			FontSize = 20,
			BackgroundColor = ARGB(0, 255, 255, 255),
		},
		
		Gui.Label
		{
			Location = Vector2(122, 100),
			Size = Vector2(400, 60),
			BackgroundColor = ARGB(0, 255, 255, 255),
			Text = lang:GetText("您的战队贡献将会清零，战队BUFF\n也会消失。"),
			FontSize = 24,
			TextColor = ARGB(255, 174, 2, 0),
			TextAlign = "kAlignLeftMiddle",
		},
		
		Gui.Label "des"
		{
			Location = Vector2(0, 150),
			Size = Vector2(526, 60),
			FontSize = 20,
			TextColor = ARGB(255, 174, 2, 0),
			TextAlign = "kAlignCenterMiddle",
		},
		
		--确定
		Gui.Button
		{
			Location = Vector2(100, 222),
			Size = Vector2(128, 40),
			BackgroundColor = ARGB(255,255,255,255),
			Text = lang:GetText("确 定"),
			TextAlign = "kAlignCenterMiddle",
			TextColor = ARGB(255,50,50,50),
			HighlightTextColor = ARGB(255, 50 ,50 ,50),
			Padding = Vector4(0, 0, 0, 5),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/lb_common_up_button_normal.dds", Vector4(20, 20, 20, 20)),
				HoverImage = Gui.Image("LobbyUI/lb_common_up_button_hover.dds", Vector4(20, 20, 20, 20)),
				DownImage = Gui.Image("LobbyUI/lb_common_up_button_down.dds", Vector4(20, 20, 20, 20)),
				DisabledImage = Gui.Image("LobbyUI/lb_common_up_button_disabled.dds", Vector4(20, 20, 20, 20)),			
			},
			
			EventClick = function()
				Hide_LeaveBattleWarn()
				rpc.safecallload("team_request_op",{tid = t_id, pids = ptr_cast(game.CurrentState):GetCharacterId(), pid = ptr_cast(game.CurrentState):GetCharacterId(), action = "quit", job = p_job},
				function(data)
					MessageBox.ShowWithConfirm(lang:GetText("退出成功"))
					allteam_source_ui.allteam.Visible = false
					FillTeam()
					L_Friends.GetTeamInfo()
				end)
			end
		},
		--取消
		Gui.Button
		{
			Location = Vector2(263, 222),
			Size = Vector2(128, 40),
			BackgroundColor = ARGB(255,255,255,255),
			Text = lang:GetText("取 消"),
			TextAlign = "kAlignCenterMiddle",
			TextColor = ARGB(255,50,50,50),
			HighlightTextColor = ARGB(255, 50 ,50 ,50),
			Padding = Vector4(0, 0, 0, 5),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/lb_common_up_button_normal.dds", Vector4(20, 20, 20, 20)),
				HoverImage = Gui.Image("LobbyUI/lb_common_up_button_hover.dds", Vector4(20, 20, 20, 20)),
				DownImage = Gui.Image("LobbyUI/lb_common_up_button_down.dds", Vector4(20, 20, 20, 20)),
				DisabledImage = Gui.Image("LobbyUI/lb_common_up_button_disabled.dds", Vector4(20, 20, 20, 20)),			
			},
			
			EventClick = function()
				Hide_LeaveBattleWarn()
			end
		},
	},
}

VS = Gui.Create()
{
	Gui.Control "root"
	{
		Dock = "kDockFill",
		BackgroundColor = ARGB(255, 255, 255, 255),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_contact_bg1_01.dds", Vector4(163,163,53,53)),
		},
		
		Gui.Label "title"
		{
			Size = Vector2(150, 32),
			Location = Vector2(247, 15),
			FontSize = 28,
			TextColor = ARGB(255, 255, 133, 0),
			Text = lang:GetText("战队匹配战"),
		},
		
		Gui.Control 
		{
			Size = Vector2(587, 176),
			Location = Vector2(22, 45),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_bg_tanchu.dds", Vector4(48, 30, 48, 40)),
			},
		},
		Gui.Control 
		{
			Size = Vector2(188, 128),
			Dock = "kDockCenter",
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_vs_ico_02.dds", Vector4(0, 0, 0, 0)),
			},
		},
		Gui.Label "t1_name"
		{
			Size = Vector2(280, 28),
			Location = Vector2(44, 56),
			FontSize = 24,
			TextColor = ARGB(255, 255, 133, 0),
			TextAlign = "kAlignCenterMiddle",
		},
		Gui.Label "t2_name"
		{
			Size = Vector2(280, 28),
			Location = Vector2(320, 172),
			FontSize = 24,
			TextColor = ARGB(255, 255, 133, 0),
			TextAlign = "kAlignCenterMiddle",
		},
		Gui.Label "t1_lv"
		{
			Size = Vector2(300, 20),
			Location = Vector2(42, 132),
			FontSize = 20,
			TextColor = ARGB(255, 255, 133, 0),
			TextAlign = "kAlignLeftMiddle",
		},
		Gui.Label "t2_lv"
		{
			Size = Vector2(300, 20),
			Location = Vector2(520, 132),
			FontSize = 20,
			TextColor = ARGB(255, 255, 133, 0),
			TextAlign = "kAlignLeftMiddle",
		},
		Gui.Control "t1_icon"
		{
			Size = Vector2(84, 84),
			Location = Vector2(103, 91),
			BackgroundColor = ARGB(255, 255, 255, 255),
		},
		Gui.Control "t2_icon"
		{
			Size = Vector2(84, 84),
			Location = Vector2(422, 91),
			BackgroundColor = ARGB(255, 255, 255, 255),
		},
		
		Gui.TimeControl "shenji_1"
		{
			Size = Vector2(5, 5),
			BackgroundColor = ARGB(0, 255, 255, 255),
			EventTimeOut = function(sender, e)
				state:EnterGame()
				VS.shenji_2:CleanAll()
				VS.shenji_2:AddTime(3)
			end
		},
		
		Gui.TimeControl "shenji_2"
		{
			Size = Vector2(5, 5),
			BackgroundColor = ARGB(0, 255, 255, 255),
			EventTimeOut = function(sender, e)
				HideFightTeam()
				local state = ptr_cast(game.CurrentState)
				if state then
					state.battle_is_create = false
					battle_ready = false
					state:LeaveChannel()
					state:BattleGroupLeave(my_battle_info.battlegroup_id)
				end
			end
		},
		
	},
}

source_fight_ui = Gui.Create()
{
	Gui.Control "root"
	{
		Size = Vector2(741, 684),
		Location = Vector2(0, 0),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/team/lb_contact_bg1_01.dds", Vector4(185, 165, 32, 58)),
		},
		Gui.Control
		{
			Size = Vector2(269, 29),
			Location = Vector2(22, 12),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/team/lb_yaoqing_bg.dds", Vector4(0, 0, 0, 0)),
			},
			Gui.Control
			{
				Size = Vector2(68, 17),
				Location = Vector2(10, 6),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/lb_yaoqing_z.dds", Vector4(0, 0, 0, 0)),
				},
			},
		},
		Gui.Control
		{
			Size = Vector2(269, 29),
			Location = Vector2(353, 12),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/team/lb_yaoqing_bg.dds", Vector4(0, 0, 0, 0)),
			},
			Gui.Control
			{
				Size = Vector2(68, 17),
				Location = Vector2(10, 6),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/lb_yaoqing_w.dds", Vector4(0, 0, 0, 0)),
				},
			},
		},
		Gui.Label "source_roomnum"
		{
			Size = Vector2(50, 25),
			Location = Vector2(476, 15),
			Text = "4/6",
			BackgroundColor = ARGB(0, 255, 255, 255),
			TextAlign = "kAlignCenterMiddle",
			FontSize = 18,
			TextColor = ARGB(255, 255, 255, 255),
		},

		Gui.Control 
		{		
			Location = Vector2(352, 45),
			Size = Vector2(373, 282),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/team/lb_shop_bg3_1.dds", Vector4(10, 10, 10, 10)),
			},
			Gui.Control 
			{		
				Location = Vector2(5, 207),
				Size = Vector2(362, 68),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_xiamian_bg.dds", Vector4(10, 10, 10, 10)),
				},
			},	
			--资源战房间
			Gui.ListTreeView "Fight_Team_Room_Player"
			{
				Style = "Gui.ListTreeViewWith_VScroll_Source",
				Size = Vector2(345, 200),
				Location = Vector2(12,14),
				ItemHeight = 31,
				TreeVisible = false,
				-- MY_SPLIT_WIDTH = 28, --CHECKBOX 鼠标点击的偏移量
				AlwaysSelect = true,
				HeaderVisible = false,
				VScrollBarDisplay = "kHide",
				-- VScrollBarWidth = 16,
				-- VScrollBarButtonSize = 16,
				CanKeySelect = false,
				VScrollBarWidth = 1,
				VScrollBarButtonSize = 1,
				CheckIndex = 0,
			},
			--移除
			Gui.Button "b_del"
			{
				Size = Vector2(116,27),
				Location = Vector2(241, 240),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Text = lang:GetText("移除"),
				TextColor = ARGB(255, 226, 217, 208),
				TextAlign = "kAlignCenterMiddle",
				DisabledTextColor = ARGB(255, 37, 37, 37),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_button12_normal.dds", Vector4(41,0,41,0)),
					HoverImage = Gui.Image("LobbyUI/team/lb_squad_button12_hover.dds", Vector4(41,0,41,0)),
					DownImage = Gui.Image("LobbyUI/team/lb_squad_button12_down.dds", Vector4(41,0,41,0)),
					DisabledImage = Gui.Image("LobbyUI/team/lb_squad_button12_disabled.dds", Vector4(41,0,41,0)),
				},
				EventClick = function()
					if GetSelected(source_fight_ui.Fight_Team_Room_Player) == "" then
						return
					end
					local kick_ids = L_PushCmd.Split(GetSelected(source_fight_ui.Fight_Team_Room_Player),",")
					for i = 1 , #kick_ids do
					print("kick_ids[i]:"..kick_ids[i])
						if tonumber(kick_ids[i]) == 1 then
							MessageBox.ShowError(lang:GetText("房主不可以关闭自己"))
							return
						end
						state:ChangeSlotStatus(tonumber(kick_ids[i]),0)
						state:ChangeSlotStatus(tonumber(kick_ids[i]),1)
					end
				end
			},
		},
		
		Gui.Control 
		{		
			Location = Vector2(18, 45),
			Size = Vector2(323, 557),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/team/lb_shop_bg3_1.dds", Vector4(10, 10, 10, 10)),
			},
			Gui.Control 
			{		
				Location = Vector2(5, 467),
				Size = Vector2(312, 68),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_xiamian_bg.dds", Vector4(10, 10, 10, 10)),
				},
			},
			--战队玩家列表
			Gui.ListTreeView "Fight_Team_Player_List"
			{
				Style = "Gui.ListTreeViewWith_VScroll_Source",
				Size = Vector2(292, 450),
				Location = Vector2(12,14),
				ItemHeight = 31,
				TreeVisible = false,
				-- MY_SPLIT_WIDTH = 28, --CHECKBOX 鼠标点击的偏移量
				AlwaysSelect = true,
				HeaderVisible = false,
				VScrollBarDisplay = "kVisible",
				VScrollBarWidth = 21,
				VScrollBarButtonSize = 21,
				CanKeySelect = false,
				VScrollOffset = -20,
				CheckIndex = 0,
			},

			Gui.Button "b_sourceall"
			{
				Size = Vector2(100,27),
				Location = Vector2(9, 503),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Text = lang:GetText("全选"),
				TextColor = ARGB(255, 226, 217, 208),
				TextAlign = "kAlignCenterMiddle",
				DisabledTextColor = ARGB(255, 37, 37, 37),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_button12_normal.dds", Vector4(41,0,41,0)),
					HoverImage = Gui.Image("LobbyUI/team/lb_squad_button12_hover.dds", Vector4(41,0,41,0)),
					DownImage = Gui.Image("LobbyUI/team/lb_squad_button12_down.dds", Vector4(41,0,41,0)),
					DisabledImage = Gui.Image("LobbyUI/team/lb_squad_button12_disabled.dds", Vector4(41,0,41,0)),
				},
				EventClick = function()
					AllSelectRequest(source_fight_ui.Fight_Team_Player_List)
				end
			},
			--邀请
			Gui.Button "b_yaoqing"
			{
				Size = Vector2(100,27),
				Location = Vector2(113, 503),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Text = lang:GetText("刷新"),
				TextColor = ARGB(255, 226, 217, 208),
				TextAlign = "kAlignCenterMiddle",
				DisabledTextColor = ARGB(255, 37, 37, 37),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_button12_normal.dds", Vector4(41,0,41,0)),
					HoverImage = Gui.Image("LobbyUI/team/lb_squad_button12_hover.dds", Vector4(41,0,41,0)),
					DownImage = Gui.Image("LobbyUI/team/lb_squad_button12_down.dds", Vector4(41,0,41,0)),
					DisabledImage = Gui.Image("LobbyUI/team/lb_squad_button12_disabled.dds", Vector4(41,0,41,0)),
				},
				EventClick = function()
					FillSourceZhanduiList()
				end
			},
			--邀请
			Gui.Button "b_yaoqing"
			{
				Size = Vector2(100,27),
				Location = Vector2(217, 503),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Text = lang:GetText("邀请"),
				TextColor = ARGB(255, 226, 217, 208),
				TextAlign = "kAlignCenterMiddle",
				DisabledTextColor = ARGB(255, 37, 37, 37),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_button12_normal.dds", Vector4(41,0,41,0)),
					HoverImage = Gui.Image("LobbyUI/team/lb_squad_button12_hover.dds", Vector4(41,0,41,0)),
					DownImage = Gui.Image("LobbyUI/team/lb_squad_button12_down.dds", Vector4(41,0,41,0)),
					DisabledImage = Gui.Image("LobbyUI/team/lb_squad_button12_disabled.dds", Vector4(41,0,41,0)),
				},
				EventClick = function()
					if GetSelected(source_fight_ui.Fight_Team_Player_List) == "" then
						return
					end
					rpc.safecallload("push_battlefield_invite", {pid = ptr_cast(game.CurrentState):GetCharacterId(),type = 0,serverid = game.ClientAddress.server_id,channelid = game.ClientAddress.channel_id,roomid = game.ClientAddress.room_id,tpid = GetSelected(source_fight_ui.Fight_Team_Player_List),roompwd = create_source_room_option.password},
					function(data)
					end)
				end
			},
		},
		
		Gui.Button "b_leave_pipei"
		{
			Size = Vector2(163,46),
			Location = Vector2(57, 619),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Text = lang:GetText("离开"),
			Padding = Vector4(0, 0, 0, 7),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_button7_normal.dds", Vector4(0, 0, 0, 0)),
				HoverImage = Gui.Image("LobbyUI/team/lb_squad_button7_hover.dds", Vector4(0, 0, 0, 0)),
				DownImage = Gui.Image("LobbyUI/team/lb_squad_button7_down.dds", Vector4(0, 0, 0, 0)),
				DisabledImage = Gui.Image("LobbyUI/team/lb_squad_button7_disabled.dds", Vector4(0, 0, 0, 0)),
			},
			EventClick = function()
				HideSourceFight()
				-- invite_player = {}
				-- invite_index = 1					
				local state = ptr_cast(game.CurrentState)
				if state then
					state.source_is_create = false
					-- battle_ready = false
					for i = 2 , 16 do
						state:ChangeSlotStatus(i,0)
					end
					state:LeaveChannel()
					create_source_room_option = nil
					ptr_cast(game.CurrentState):OnChange_Lobby_Music(2)
				end
			end
		},
		
		-- Gui.Control
		-- {
			-- Size = Vector2(25, 30),
			-- Location = Vector2(400, 400),
			-- BackgroundColor = ARGB(255, 255, 255, 255),
			-- Skin = Gui.ControlSkin
			-- {
				-- BackgroundImage = Gui.Image("LobbyUI/team/lb_icon_res_02.dds", Vector4(0, 0, 0, 0)),	
			-- },
		-- },
		
		-- Gui.Control
		-- {
			-- Size = Vector2(213, 20),
			-- Location = Vector2(384, 410),
			-- BackgroundColor = ARGB(255, 255, 255, 255),
			-- Skin = Gui.ControlSkin
			-- {
				-- BackgroundImage = Gui.Image("LobbyUI/team/lb_xiaohao_bg.dds", Vector4(0, 0, 0, 0)),	
			-- },
			-- Gui.Label
			-- {
				-- Size = Vector2(213, 25),
				-- Location = Vector2(45, 0),
				-- Text = lang:GetText("匹配花费：3000"),
				-- BackgroundColor = ARGB(0, 255, 255, 255),
				-- TextAlign = "kAlignLeftTop",
				-- FontSize = 18,
				-- TextColor = ARGB(255, 255, 103, 1),
			-- },
		-- },
		
		Gui.Button "b_source_pipei"
		{
			Size = Vector2(163,46),
			Location = Vector2(453, 619),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Text = lang:GetText("组队进入"),
			Padding = Vector4(0, 0, 0, 7),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_button7_normal.dds", Vector4(0, 0, 0, 0)),
				HoverImage = Gui.Image("LobbyUI/team/lb_squad_button7_hover.dds", Vector4(0, 0, 0, 0)),
				DownImage = Gui.Image("LobbyUI/team/lb_squad_button7_down.dds", Vector4(0, 0, 0, 0)),
				DisabledImage = Gui.Image("LobbyUI/team/lb_squad_button7_disabled.dds", Vector4(0, 0, 0, 0)),
			},
			EventClick = function()
				if SourceFightType == 1 then
					HideSourceFight()
					BeginSourcePipei(false)
				else
					pipeiTimes = 1
					HideSourceFight()
					ShowSource_Success()
				end
			end
		},
	},
}

function create_defanse_list(index)
	return 	Gui.Control ("defanse_list"..index)
	{
		Size = Vector2(683, 31),
		Location = Vector2(0, 0),
		BackgroundColor = ARGB(0, 255, 255, 255),
		Gui.Control
		{
			Size = Vector2(568, 31),
			Location = Vector2(0, 0),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/team/lb_opt_bg_hover.dds", Vector4(45, 0, 9, 0)),
			},
			Gui.Label ("defanse_type"..index)
			{
				Size = Vector2(348, 31),
				Location = Vector2(60, 0),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Text = lang:GetText("挑战"),
				TextAlign = "kAlignLeftMiddle",
				FontSize = 16,
				TextColor = ARGB(255, 213, 24, 30),
			},
			Gui.Label ("defanse_team_name"..index)
			{
				Size = Vector2(300, 31),
				Location = Vector2(130, 0),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Text = lang:GetText("领地遭受“啊啊啊啊啊啊啊啊啊啊”攻击"),
				TextAlign = "kAlignCenterMiddle",
				FontSize = 16,
				TextColor = ARGB(255, 213, 24, 30),
			},
			Gui.Label ("atk_num"..index)
			{
				Size = Vector2(348, 31),
				Location = Vector2(470, 0),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Text = lang:GetText("1人"),
				TextAlign = "kAlignLeftMiddle",
				FontSize = 16,
				TextColor = ARGB(255, 213, 24, 30),
			},
		},
		Gui.Button ("b_defanse"..index)
		{
			Size = Vector2(83, 27),
			Location = Vector2(600, 2),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Text = lang:GetText("防守"),
			TextColor = ARGB(255, 255, 255, 255),
			FontSize = 16,
			TextAlign = "kAlignCenterMiddle",
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_button12_normal.dds", Vector4(0, 0, 0, 0)),
				HoverImage = Gui.Image("LobbyUI/team/lb_squad_button12_hover.dds", Vector4(0, 0, 0, 0)),
				DownImage = Gui.Image("LobbyUI/team/lb_squad_button12_down.dds", Vector4(0, 0, 0, 0)),
				DisabledImage = Gui.Image("LobbyUI/team/lb_squad_button12_disabled.dds", Vector4(0, 0, 0, 0)),
			},
			EventClick = function()
				local state = ptr_cast(game.CurrentState)
				if state then
					HideDefanseFight()
					state.source_is_create = true
					defense_success = true
					is_in_invite = true
					state.is_fight_team_server = true
					L_WarZone.FightGetBack(L_WarZone.current_state)
					L_WarZone.battle_invite = false
					source_pipei_success = true
					state:AutoChangeRoomWithPassword(defanse_fight_ui["server_id_"..index].Text,defanse_fight_ui["channel_id_"..index].Text,defanse_fight_ui["room_id_"..index].Text,defanse_fight_ui["psd_"..index].Text)
					L_FightTeam.SourceFightType = attack_team_info[index][7]
					L_FightTeam.FillMap(attack_team_info[index][8],attack_team_info[index][7],attack_team_info[index][9],attack_team_info[index][10],attack_team_info[index][5])
					-- state:EnterGame()

					for i = 1,10 do
						if i == index then
							attack_team_info[i][1] = nil
							attack_team_info[i][2] = nil
							attack_team_info[i][3] = nil
							attack_team_info[i][4] = nil
							attack_team_info[i][5] = nil
							attack_team_info[i][6] = nil
							attack_team_info[i][7] = nil
							attack_team_info[i][8] = nil
							attack_team_info[i][9] = nil
							attack_team_info[i][10] = nil
							attack_team_info[i][11] = nil
							flag = false
							break
						end
					end
					
					for i = 1,10 do
						if i > index then
							attack_team_info[i-1][1] = attack_team_info[i][1]
							attack_team_info[i-1][2] = attack_team_info[i][2]
							attack_team_info[i-1][3] = attack_team_info[i][3]
							attack_team_info[i-1][4] = attack_team_info[i][4]
							attack_team_info[i-1][5] = attack_team_info[i][5]
							attack_team_info[i-1][6] = attack_team_info[i][6]
							attack_team_info[i-1][7] = attack_team_info[i][7]
							attack_team_info[i-1][8] = attack_team_info[i][8]
							attack_team_info[i-1][9] = attack_team_info[i][9]
							attack_team_info[i-1][10] = attack_team_info[i][10]
							attack_team_info[i-1][11] = attack_team_info[i][11]
						end
					end
					Fill_Defance_num()
				end
			end,
		},
		Gui.Label ("server_id_"..index)
		{
			Size = Vector2(1, 1),
			Location = Vector2(0, 0),
			BackgroundColor = ARGB(0, 255, 255, 255),
			Text = "",
			TextAlign = "kAlignLeftMiddle",
			FontSize = 16,
			TextColor = ARGB(0, 0, 0, 0),
		},
		Gui.Label ("channel_id_"..index)
		{
			Size = Vector2(1, 1),
			Location = Vector2(0, 0),
			BackgroundColor = ARGB(0, 255, 255, 255),
			Text = "",
			TextAlign = "kAlignLeftMiddle",
			FontSize = 16,
			TextColor = ARGB(0, 0, 0, 0),
		},
		Gui.Label ("room_id_"..index)
		{
			Size = Vector2(1, 1),
			Location = Vector2(0, 0),
			BackgroundColor = ARGB(0, 255, 255, 255),
			Text = "",
			TextAlign = "kAlignLeftMiddle",
			FontSize = 16,
			TextColor = ARGB(0, 0, 0, 0),
		},
		Gui.Label ("psd_"..index)
		{
			Size = Vector2(1, 1),
			Location = Vector2(0, 0),
			BackgroundColor = ARGB(0, 255, 255, 255),
			Text = "",
			TextAlign = "kAlignLeftMiddle",
			FontSize = 16,
			TextColor = ARGB(0, 0, 0, 0),
		},
	}
end

defanse_fight_ui = Gui.Create()
{
	Gui.Control "root"
	{
		Size = Vector2(863, 570),
		Location = Vector2(0, 0),
		BackgroundColor = ARGB(0, 255, 255, 255),
		Gui.Control
		{
			Size = Vector2(763, 470),
			Location = Vector2(50, 50),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/team/lb_contact_bg1_01.dds", Vector4(185, 165, 32, 58)),
			},
			Gui.Label
			{
				Size = Vector2(763, 20),
				Location = Vector2(0, 8),
				Text = lang:GetText("加入防守"),
				BackgroundColor = ARGB(0, 255, 255, 255),
				TextAlign = "kAlignCenterMiddle",
				FontSize = 18,
				TextColor = ARGB(255, 255, 255, 255),
			},
			Gui.Control
			{
				Size = Vector2(728, 419),
				Location = Vector2(18, 34),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/lb_shop_bg3_1.dds", Vector4(10, 10, 10, 10)),
				},
				Gui.Control
				{
					Size = Vector2(728, 419),
					Location = Vector2(0, 0),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/lb_fangshou_haibao.dds", Vector4(0, 0, 0, 0)),
					},
				},
				Gui.FlowLayout
				{
					Size = Vector2(728, 419),
					Location = Vector2(0, 0),
					Align = "kAlignCenterTop",
					ControlAlign = "kAlignCenterMiddle",
					Padding = Vector4(0, 10, 0, 0),
					LineSpace = 10,
					create_defanse_list(1),
					create_defanse_list(2),
					create_defanse_list(3),
					create_defanse_list(4),
					create_defanse_list(5),
					create_defanse_list(6),
					create_defanse_list(7),
					create_defanse_list(8),
					create_defanse_list(9),
					create_defanse_list(10),
				},
			},
		},
		--退出
		Gui.Button
		{
			Size = Vector2(48,48),
			Location = Vector2(779, 36),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_normal.dds", Vector4(10, 10, 10, 10)),
				HoverImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_hover.dds", Vector4(10, 10, 10, 10)),
				DownImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_down.dds", Vector4(10, 10, 10, 10)),
				DisabledImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_disabled.dds", Vector4(0, 0, 0, 0)),	
			},
			EventClick = function()
				HideDefanseFight()
			end,
		},
	},
}

weekend_rank_ui = Gui.Create()
{
	Gui.Control "root"
	{
		Size = Vector2(863, 626),
		Location = Vector2(0, 0),
		BackgroundColor = ARGB(0, 255, 255, 255),
		Gui.Control
		{
			Size = Vector2(763, 526),
			Location = Vector2(50, 50),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/team/lb_contact_bg1_01.dds", Vector4(185, 165, 32, 58)),
			},
			Gui.Label
			{
				Size = Vector2(763, 20),
				Location = Vector2(0, 8),
				Text = lang:GetText("本周战绩"),
				BackgroundColor = ARGB(0, 255, 255, 255),
				TextAlign = "kAlignCenterMiddle",
				FontSize = 18,
				TextColor = ARGB(255, 255, 255, 255),
			},
			Gui.Button "b_zhengduo"
			{
				Size = Vector2(157,56),
				Location = Vector2(27, 34),
				Text = lang:GetText("争夺模式"),
				HighlightTextColor = ARGB(255,255,255,255),
				TextColor = ARGB(255,0,0,0),
				FontSize = 16,
				PushDown = true,
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_normal.dds", Vector4(46, 0, 46, 0)),
					HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_hover.dds", Vector4(46, 0, 46, 0)),
					DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_down.dds", Vector4(46, 0, 46, 0)),
					DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_normal.dds", Vector4(46, 0, 46, 0)),
				},
				EventClick = function()
					weekend_rank_ui.b_zhengduo.PushDown = true
					weekend_rank_ui.b_tiaozhan.PushDown = false
					Weekend_Type = 1
					rpc.safecallload("team_res_record_list", {tid = t_id , type = Weekend_Type},
					function(data)
						FillWeekendRank(data)
					end)
				end,
			},
			Gui.Button "b_tiaozhan"
			{
				Size = Vector2(157,56),
				Location = Vector2(187, 34),
				Text = lang:GetText("挑战模式"),
				HighlightTextColor = ARGB(255,255,255,255),
				TextColor = ARGB(255,0,0,0),
				FontSize = 16,
				PushDown = false,
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_normal.dds", Vector4(46, 0, 46, 0)),
					HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_hover.dds", Vector4(46, 0, 46, 0)),
					DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_down.dds", Vector4(46, 0, 46, 0)),
					DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_normal.dds", Vector4(46, 0, 46, 0)),
				},
				EventClick = function()
					weekend_rank_ui.b_zhengduo.PushDown = false
					weekend_rank_ui.b_tiaozhan.PushDown = true
					Weekend_Type = 2
					rpc.safecallload("team_res_record_list", {tid = t_id , type = Weekend_Type},
					function(data)
						FillWeekendRank(data)
					end)
				end,
			},
			Gui.Control
			{
				Size = Vector2(728, 419),
				Location = Vector2(18, 80),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/lb_shop_bg3_1.dds", Vector4(10, 10, 10, 10)),
				},
				Gui.Control
				{
					Size = Vector2(728, 419),
					Location = Vector2(0, 0),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/lb_fangshou_haibao.dds", Vector4(0, 0, 0, 0)),
					},
				},
				Gui.RichEdit "r_data"
				{
					Size = Vector2(708, 399),
					Location = Vector2(10, 10),
					AutoScroll = true,
					FontSize = 16,
					VScrollBarButtonSize = 21,
					VScrollBarWidth = 21,
					AutoScrollMinSize = Vector2(0,0),
					BackgroundColor = ARGB(255,255,255,255),
					Skin = Gui.ScrollableControlSkin
					{

					UpButtonNormalImage = Gui.Image("LobbyUI/team/lb_shang_normal.dds", Vector4(0, 0, 0, 0)),
					UpButtonHoverImage = Gui.Image("LobbyUI/team/lb_shang_hover.dds", Vector4(0, 0, 0, 0)),
					UpButtonDownImage = Gui.Image("LobbyUI/team/lb_shang_down.dds", Vector4(0, 0, 0, 0)),
					UpButtonDisabledImage = Gui.Image("LobbyUI/team/lb_shang_disabled.dds", Vector4(0, 0, 0, 0)),

					DownButtonNormalImage = Gui.Image("LobbyUI/team/lb_xia_normal.dds", Vector4(0, 0, 0, 0)),
					DownButtonHoverImage = Gui.Image("LobbyUI/team/lb_xia_hover.dds", Vector4(0, 0, 0, 0)),
					DownButtonDownImage = Gui.Image("LobbyUI/team/lb_xia_down.dds", Vector4(0, 0, 0, 0)),
					DownButtonDisabledImage = Gui.Image("LobbyUI/team/lb_xia_disabled.dds", Vector4(0, 0, 0, 0)),

					VSliderNormalImage = Gui.Image("LobbyUI/team/lb_zhong_normal.dds", Vector4(5, 5, 5, 5)),
					VSliderHoverImage = Gui.Image("LobbyUI/team/lb_zhong_hover.dds", Vector4(5, 5, 5, 5)),
					VSliderDownImage = Gui.Image("LobbyUI/team/lb_zhong_down.dds", Vector4(5, 5, 5, 5)),
					VSliderDisabledImage = Gui.Image("LobbyUI/team/lb_zhong_disabled.dds", Vector4(5, 5, 5, 5)),

					VBarBackgroundImage = Gui.Image("LobbyUI/team/lb_huadong_bg.dds", Vector4(5, 5, 5, 5)),
					BarCornerImage = nil,
					},
				},
			},
		},
		--退出
		Gui.Button
		{
			Size = Vector2(48,48),
			Location = Vector2(779, 36),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_normal.dds", Vector4(10, 10, 10, 10)),
				HoverImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_hover.dds", Vector4(10, 10, 10, 10)),
				DownImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_down.dds", Vector4(10, 10, 10, 10)),
				DisabledImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_disabled.dds", Vector4(0, 0, 0, 0)),	
			},
			EventClick = function()
				HideWeekendRank()
			end,
		},
	},
}

source_success_ui = Gui.Create()
{
	Gui.Control "root"
	{
		Size = Vector2(1200, 900),
		Location = Vector2(0, 0),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/lb_bg_wallpaper04.dds", Vector4(255, 0, 0, 0)),
		},
		Gui.Control "time"
		{
			Size = Vector2(373, 64),
			Location = Vector2(37, 43),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/team/lb_xiaohao_bg.dds", Vector4(10, 10, 10, 10)),	
			},
			Gui.Control 
			{
				Location = Vector2(110, 18),
				Size = Vector2(38, 29),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_number_01.dds", Vector4(0, 0, 0, 0),Vector4(0, 0, 0.1, 1)),
				},
			},
			Gui.Control 
			{
				Location = Vector2(155, 18),
				Size = Vector2(38, 29),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_number_01.dds", Vector4(0, 0, 0, 0),Vector4(0, 0, 0.1, 1)),
				},
			},
			Gui.Control 
			{
				Location = Vector2(199, 20),
				Size = Vector2(18, 24),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/lb_maohao_bg.dds", Vector4(0, 0, 0, 0)),
				},
			},
			Gui.Control 
			{
				Location = Vector2(223, 18),
				Size = Vector2(38, 29),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_number_01.dds", Vector4(0, 0, 0, 0),Vector4(0, 0, 0.1, 1)),
				},
			},
			Gui.Control 
			{
				Location = Vector2(267, 18),
				Size = Vector2(38, 29),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_number_01.dds", Vector4(0, 0, 0, 0),Vector4(0, 0, 0.1, 1)),
				},
			},
		},
		Gui.Control
		{
			Size = Vector2(374, 433),
			Location = Vector2(54, 113),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/team/lb_contact_bg1_01.dds", Vector4(185, 165, 32, 58)),
			},
			Gui.Control
			{
				Size = Vector2(269, 29),
				Location = Vector2(25, 15),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/lb_yaoqing_bg.dds", Vector4(0, 0, 0, 0)),
				},
				Gui.Control
				{
					Size = Vector2(68, 17),
					Location = Vector2(10, 6),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/lb_yaoqing_w.dds", Vector4(0, 0, 0, 0)),
					},
				},
			},
			Gui.Control 
			{		
				Location = Vector2(25, 48),
				Size = Vector2(294, 351),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/lb_contact_bg2_01.dds", Vector4(95,109,55,61)),
				},
				--战队战房间
				Gui.ListTreeView "Fight_Team_Room_Player"
				{
					Style = "Gui.ListTreeViewWith_VScroll_Source",
					Size = Vector2(292, 296),
					Location = Vector2(0,5),
					ItemHeight = 37,
					TreeVisible = false,
					-- MY_SPLIT_WIDTH = 28, --CHECKBOX 鼠标点击的偏移量
					AlwaysSelect = true,
					HeaderVisible = false,
					VScrollBarDisplay = "kHide",
					-- VScrollBarWidth = 16,
					-- VScrollBarButtonSize = 16,
					CanKeySelect = false,
					VScrollBarWidth = 1,
					VScrollBarButtonSize = 1,
				},
			},
		},
		-- Gui.Control
		-- {
			-- Size = Vector2(373, 64),
			-- Location = Vector2(599, 43),
			-- BackgroundColor = ARGB(255, 255, 255, 255),
			-- Skin = Gui.ControlSkin
			-- {
				-- BackgroundImage = Gui.Image("LobbyUI/team/lb_xiaohao_bg.dds", Vector4(0, 0, 0, 0)),	
			-- },
			-- Gui.Control 
			-- {
				-- Location = Vector2(121, 6),
				-- Size = Vector2(145, 28),
				-- BackgroundColor = ARGB(255, 255, 255, 255),
				-- Skin = Gui.ControlSkin
				-- {
					-- BackgroundImage = Gui.Image("LobbyUI/team/lb_zyzd_loading.dds", Vector4(0, 0, 0, 0)),
				-- },
			-- },
			-- Gui.Label "get_source"
			-- {
				-- Size = Vector2(373, 20),
				-- Location = Vector2(0, 41),
				-- BackgroundColor = ARGB(0, 255, 255, 255),
				-- Text = lang:GetText("原油：5000点"),
				-- TextAlign = "kAlignCenterMiddle",
				-- FontSize = 16,
				-- TextColor = ARGB(255, 255, 255, 255),
			-- },
		-- },
		Gui.Control "background"
		{
			Size = Vector2(712, 557),
			Location = Vector2(442, 113),
			BackgroundColor = ARGB(0, 255, 255, 255),
			Gui.Control "map_bg"
			{
				Dock = "kDockFill",
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/lb_shop_daoju_bg.tga", Vector4(22, 22, 22, 22)),
				},
				Gui.Control "map"
				{
					Size = Vector2(688, 532),
					Location = Vector2(12, 12),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/map/lb_ditu_131213_01.dds", Vector4(0, 0, 0, 0)),
					},
				},
				Gui.Label "l_get_source"
				{
					Size = Vector2(200, 25),
					Location = Vector2(19, 20),
					BackgroundColor = ARGB(0, 255, 255, 255),
					Text = lang:GetText("可掠夺资源："),
					TextAlign = "kAlignLefTop",
					FontSize = 18,
					TextColor = ARGB(255, 116, 199, 107),
				},
				Gui.Label "get_source"
				{
					Size = Vector2(200, 25),
					Location = Vector2(230, 20),
					BackgroundColor = ARGB(0, 255, 255, 255),
					Text = lang:GetText("原石：5000点"),
					TextAlign = "kAlignLefTop",
					FontSize = 18,
					TextColor = ARGB(255, 255, 255, 255),
				},
				Gui.Label
				{
					Size = Vector2(200, 25),
					Location = Vector2(19, 50),
					FontSize = 18,
					Text = lang:GetText("战队名称："),
					TextColor = ARGB(255, 255, 210, 0),
					TextAlign = "kAlignLefTop",
					BackgroundColor = ARGB(0, 255, 255, 255),
				},
				Gui.Label "l_fightname"
				{
					Size = Vector2(200, 25),
					Location = Vector2(230, 50),
					FontSize = 18,
					Text = "",
					TextColor = ARGB(255, 255, 255, 255),
					TextAlign = "kAlignLefTop",
					BackgroundColor = ARGB(0, 255, 255, 255),
				},
				Gui.Label
				{
					Size = Vector2(200, 25),
					Location = Vector2(19, 80),			
					FontSize = 18,
					Text = lang:GetText("战队领地等级："),
					TextColor = ARGB(255, 255, 210, 0),
					TextAlign = "kAlignLefTop",
					BackgroundColor = ARGB(0, 255, 255, 255),
				},
				-- Gui.Label
				-- {
					-- Size = Vector2(500, 25),
					-- Location = Vector2(19, 110),			
					-- FontSize = 18,
					-- Text = lang:GetText("掠夺资源超过每日转换上限，收益降低:"),
					-- TextColor = ARGB(255, 255, 210, 0),
					-- TextAlign = "kAlignLefTop",
					-- BackgroundColor = ARGB(0, 255, 255, 255),
				-- },
				Gui.Label "l_fightroom_lv"
				{
					Size = Vector2(200, 25),
					Location = Vector2(230, 80),			
					FontSize = 18,
					Text = "10",
					TextColor = ARGB(255, 255, 255, 255),
					TextAlign = "kAlignLefTop",
					BackgroundColor = ARGB(0, 255, 255, 255),
				},
				Gui.Label
				{
					Size = Vector2(200, 25),
					Location = Vector2(19, 110),			
					FontSize = 18,
					Text = lang:GetText("战队资源战排名："),
					TextColor = ARGB(255, 255, 210, 0),
					TextAlign = "kAlignLefTop",
					BackgroundColor = ARGB(0, 255, 255, 255),
					Visible = false,
				},
				Gui.Label "l_source_rank"
				{
					Size = Vector2(200, 25),
					Location = Vector2(230, 110),			
					FontSize = 18,
					Text = "10",
					TextColor = ARGB(255, 255, 255, 255),
					TextAlign = "kAlignLefTop",
					BackgroundColor = ARGB(0, 255, 255, 255),
					Visible = false,
				},
			},
		},
		
				
		Gui.Control "c_cost_source_left_bg"
		{
			Size = Vector2(400, 20),
			Location = Vector2(436, 700),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/team/lb_xiaohao_bg.dds", Vector4(0, 0, 0, 0)),	
			},
			Gui.Label "c_cost_source_left"
			{
				Size = Vector2(400, 25),
				Location = Vector2(45, 0),
				Text = lang:GetText("个人消耗：3000"),
				BackgroundColor = ARGB(0, 255, 255, 255),
				TextAlign = "kAlignLeftTop",
				FontSize = 18,
				TextColor = ARGB(255, 255, 103, 1),
			},
		},
		Gui.Control "c_res_icon_left"
		{
			Size = Vector2(30, 30),
			Location = Vector2(488 - 50, 691),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/team/lb_icon_res_02_1.dds", Vector4(0, 0, 0, 0)),	
			},
		},
		
		Gui.Button "back_btn"
		{
			Size = Vector2(163,46),
			Location = Vector2(436, 747),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Text = lang:GetText("返回"),
			Padding = Vector4(0, 0, 0, 7),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_button7_normal.dds", Vector4(0, 0, 0, 0)),
				HoverImage = Gui.Image("LobbyUI/team/lb_squad_button7_hover.dds", Vector4(0, 0, 0, 0)),
				DownImage = Gui.Image("LobbyUI/team/lb_squad_button7_down.dds", Vector4(0, 0, 0, 0)),
				DisabledImage = Gui.Image("LobbyUI/team/lb_squad_button7_disabled.dds", Vector4(0, 0, 0, 0)),
			},
			EventClick = function()
				-- HideSource_Success()
				-- team_ui.SourceStartTimer:CleanAll()
				-- local state = ptr_cast(game.CurrentState)
				-- if state then
					-- state.source_is_create = false
					-- -- battle_ready = false
					-- for i = 2 , 16 do
						-- state:ChangeSlotStatus(i,0)
					-- end
					-- state:LeaveChannel()
				-- end
				if source_defance_tid ~= 0 then
					rpc.safecall("handle_battlefield_battle", {tid = source_defance_tid , t = 0},
					function(data)
					end)
					source_defance_tid = 0
				end
				team_ui.SourceStartTimer:CleanAll()
				HideSource_Success()
				ShowSourceFight()
				FillSourceZhanduiRoom()
				FillSourceZhanduiList()
			end
		},
		
		Gui.Button "b_source_pi"
		{
			Size = Vector2(163,46),
			Location = Vector2(774, 747),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Text = lang:GetText("匹配"),
			Padding = Vector4(0, 0, 0, 7),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_button7_normal.dds", Vector4(0, 0, 0, 0)),
				HoverImage = Gui.Image("LobbyUI/team/lb_squad_button7_hover.dds", Vector4(0, 0, 0, 0)),
				DownImage = Gui.Image("LobbyUI/team/lb_squad_button7_down.dds", Vector4(0, 0, 0, 0)),
				DisabledImage = Gui.Image("LobbyUI/team/lb_squad_button7_disabled.dds", Vector4(0, 0, 0, 0)),
			},
			EventClick = function()
				if source_defance_tid ~= 0 then
					rpc.safecall("handle_battlefield_battle", {tid = source_defance_tid , t = 0},
					function(data)
					end)
					source_defance_tid = 0
				end
				pipeiTimes = 1
				source_success_ui.b_source_pipei.Enable = false
				HideSourceFight()
				InitSource_Success()
				-- ShowSource_Time()
				source_success_ui.b_source_pi.Enable = false
				BeginSourcePipei(true)
			end
		},
		Gui.Control "c_cost_source_bg"
		{
			Size = Vector2(400, 20),
			Location = Vector2(774, 700),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/team/lb_xiaohao_bg.dds", Vector4(0, 0, 0, 0)),	
			},
			Gui.Label "c_cost_source"
			{
				Size = Vector2(400, 25),
				Location = Vector2(45, 0),
				Text = lang:GetText("个人消耗：3000"),
				BackgroundColor = ARGB(0, 255, 255, 255),
				TextAlign = "kAlignLeftTop",
				FontSize = 18,
				TextColor = ARGB(255, 255, 103, 1),
			},
		},
		Gui.Control "c_res_icon"
		{
			Size = Vector2(30, 30),
			Location = Vector2(826 - 50, 691),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/team/lb_icon_res_02_1.dds", Vector4(0, 0, 0, 0)),	
			},
		},
		Gui.Button "b_source_pipei"
		{
			Size = Vector2(163,46),
			Location = Vector2(978, 746),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Text = lang:GetText("开始战斗"),
			Padding = Vector4(0, 0, 0, 7),
			Enable = false,
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_button7_normal.dds", Vector4(0, 0, 0, 0)),
				HoverImage = Gui.Image("LobbyUI/team/lb_squad_button7_hover.dds", Vector4(0, 0, 0, 0)),
				DownImage = Gui.Image("LobbyUI/team/lb_squad_button7_down.dds", Vector4(0, 0, 0, 0)),
				DisabledImage = Gui.Image("LobbyUI/team/lb_squad_button7_disabled.dds", Vector4(0, 0, 0, 0)),
			},
			EventClick = function()
				if SourceFightType == 0 then
					team_ui.SourceStartTimer:CleanAll()
					-- rpc.safecall("push_battlefield_defense_invite", {atid = t_id,dtid = source_defance_tid,serverid = game.ClientAddress.server_id,channelid = game.ClientAddress.channel_id,roomid = game.ClientAddress.room_id,roompwd = create_source_room_option.password,restype = SourceFightType,config = map_config,canRobRes = canRobUnuseRes},
					-- function(data)
					-- end)
					rpc.safecall("handle_battlefield_battle", {tid = source_defance_tid,t = 1,pnames = GetMySourceMember(source_fight_ui.Fight_Team_Room_Player),config = map_config,canRobRes = canRobUnuseRes},
					function(data)
						if not data.error then
							team_ui.SourceBeginGame:CleanAll()
							team_ui.SourceBeginGame:AddTime(10)
							state:RequestTDData(battleFieldId,teamSpaceLevel,canRobUnuseRes,data.bfstartpre)
							source_time_ui.l_text.Text = lang:GetText("正在开始游戏......")
							source_time_ui.b_exit.Visible = false
							ShowSource_Time()
						end	
						-- state.source_is_create = false
						-- HideSource_Success()
						-- create_source_room_option = nil							
						-- MessageBox.ShowWaiter(lang:GetText("正在开始游戏,请稍候..."))					
						-- state:StartGame()
					end)
				elseif SourceFightType == 1 then
					rpc.safecall("battlefield_challenge", {lpid = ptr_cast(game.CurrentState):GetCharacterId(),dtid= source_defance_tid, pnames = GetMySourceMember(source_fight_ui.Fight_Team_Room_Player),config = map_config,canRobRes = canRobUnuseRes},
					function(data)
						if data.result == true then
							team_ui.SourceStartTimer:CleanAll()
							-- rpc.safecall("push_battlefield_defense_invite", {atid = t_id,dtid = source_defance_tid,serverid = game.ClientAddress.server_id,channelid = game.ClientAddress.channel_id,roomid = game.ClientAddress.room_id,roompwd = create_source_room_option.password,restype = SourceFightType,config = map_config,canRobRes = canRobUnuseRes,atknum = source_roomnum},
							-- function(data)
							-- end)
							-- rpc.safecall("handle_battlefield_battle", {tid = source_defance_tid,t = 1},
							-- function(data)
								team_ui.SourceBeginGame:CleanAll()
								team_ui.SourceBeginGame:AddTime(10)
								state:RequestTDData(battleFieldId,teamSpaceLevel,canRobUnuseRes,"")
								source_time_ui.l_text.Text = lang:GetText("正在开始游戏......")
								source_time_ui.b_exit.Visible = false
								ShowSource_Time()
								
								-- state.source_is_create = false
								-- HideSource_Success()
								-- create_source_room_option = nil	
								-- MessageBox.ShowWaiter(lang:GetText("正在开始游戏,请稍候..."))							
								-- state:StartGame()
							-- end)
						else
							L_FightTeam.create_source_room_option = nil
							MessageBox.ShowWithConfirm(lang:GetText("挑战失败"))
							HideSource_Success()
							team_ui.SourceStartTimer:CleanAll()
							local state = ptr_cast(game.CurrentState)
							if state then
								state.source_is_create = false
								-- battle_ready = false
								for i = 2 , 16 do
									state:ChangeSlotStatus(i,0)
								end
								state:LeaveChannel()
							end
						end
					end)
				end				
			end
		},
	},
}

source_time_ui = Gui.Create()
{
	Gui.Control "root"
	{
		Size = Vector2(780,194),
		Location = Vector2(0, 0),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/lb_com_tis_bg.dds", Vector4(0, 24, 0, 24)),
		},
		Gui.Label "l_text"
		{
			Location = Vector2(0, 80),
			Size = Vector2(780, 30),
			BackgroundColor = ARGB(0, 255, 255, 255),
			Text = lang:GetText("匹配中......"),
			FontSize = 20,
			TextAlign = "kAlignCenterMiddle",
			TextColor = ARGB(255, 255, 255, 255),
		},
		Gui.Button "b_exit"
		{
			Size = Vector2(83,27),
			Location = Vector2(340, 134),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Text = lang:GetText("取消"),
			TextColor = ARGB(255, 226, 217, 208),
			TextAlign = "kAlignCenterMiddle",
			DisabledTextColor = ARGB(255, 37, 37, 37),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_button12_normal.dds", Vector4(0, 0, 0, 0)),
				HoverImage = Gui.Image("LobbyUI/team/lb_squad_button12_hover.dds", Vector4(0, 0, 0, 0)),
				DownImage = Gui.Image("LobbyUI/team/lb_squad_button12_down.dds", Vector4(0, 0, 0, 0)),
				DisabledImage = Gui.Image("LobbyUI/team/lb_squad_button12_disabled.dds", Vector4(0, 0, 0, 0)),
			},
			EventClick = function()
				HideSource_Time()
				team_ui.SourceTimer:CleanAll()
				source_success_ui.b_source_pi.Enable = true
			end
		},
	}
}
look_my_space = Gui.Create()
{
	Gui.Control "root"
	{
		Size = Vector2(812,657),
		Location = Vector2(0, 0),
		BackgroundColor = ARGB(0, 255, 255, 255),
		Gui.Control "background"
		{
			Size = Vector2(712, 557),
			Location = Vector2(50, 50),
			BackgroundColor = ARGB(0, 255, 255, 255),
			Gui.Control "map_bg"
			{
				Dock = "kDockFill",
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/lb_shop_daoju_bg.tga", Vector4(22, 22, 22, 22)),
				},
				Gui.Control "map"
				{
					Size = Vector2(688, 532),
					Location = Vector2(12, 12),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/map/lb_ditu_131213_01.dds", Vector4(0, 0, 0, 0)),
					},
				},
				Gui.Label "l_get_source"
				{
					Size = Vector2(200, 25),
					Location = Vector2(19, 20),
					BackgroundColor = ARGB(0, 255, 255, 255),
					Text = lang:GetText("可掠夺资源："),
					TextAlign = "kAlignLefTop",
					FontSize = 18,
					TextColor = ARGB(255, 116, 199, 107),
				},
				Gui.Label "get_source"
				{
					Size = Vector2(200, 25),
					Location = Vector2(230, 20),
					BackgroundColor = ARGB(0, 255, 255, 255),
					Text = lang:GetText("原石：5000点"),
					TextAlign = "kAlignLefTop",
					FontSize = 18,
					TextColor = ARGB(255, 255, 255, 255),
				},
				Gui.Label
				{
					Size = Vector2(200, 25),
					Location = Vector2(19, 50),
					FontSize = 18,
					Text = lang:GetText("战队名称："),
					TextColor = ARGB(255, 255, 210, 0),
					TextAlign = "kAlignLefTop",
					BackgroundColor = ARGB(0, 255, 255, 255),
				},
				Gui.Label "l_fightname"
				{
					Size = Vector2(200, 25),
					Location = Vector2(230, 50),
					FontSize = 18,
					Text = "",
					TextColor = ARGB(255, 255, 255, 255),
					TextAlign = "kAlignLefTop",
					BackgroundColor = ARGB(0, 255, 255, 255),
				},
				Gui.Label
				{
					Size = Vector2(200, 25),
					Location = Vector2(19, 80),			
					FontSize = 18,
					Text = lang:GetText("战队领地等级："),
					TextColor = ARGB(255, 255, 210, 0),
					TextAlign = "kAlignLefTop",
					BackgroundColor = ARGB(0, 255, 255, 255),
				},
				Gui.Label "l_fightroom_lv"
				{
					Size = Vector2(200, 25),
					Location = Vector2(230, 80),			
					FontSize = 18,
					Text = "10",
					TextColor = ARGB(255, 255, 255, 255),
					TextAlign = "kAlignLefTop",
					BackgroundColor = ARGB(0, 255, 255, 255),
				},
				Gui.Label
				{
					Size = Vector2(200, 25),
					Location = Vector2(19, 110),			
					FontSize = 18,
					Text = lang:GetText("战队资源战排名："),
					TextColor = ARGB(255, 255, 210, 0),
					TextAlign = "kAlignLefTop",
					BackgroundColor = ARGB(0, 255, 255, 255),
					Visible = false,
				},
				Gui.Label "l_source_rank"
				{
					Size = Vector2(200, 25),
					Location = Vector2(230, 110),			
					FontSize = 18,
					Text = "10",
					TextColor = ARGB(255, 255, 255, 255),
					TextAlign = "kAlignLefTop",
					BackgroundColor = ARGB(0, 255, 255, 255),
					Visible = false,
				},
			},
		},
		--退出
		Gui.Button
		{
			Size = Vector2(48,48),
			Location = Vector2(728, 36),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_normal.dds", Vector4(10, 10, 10, 10)),
				HoverImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_hover.dds", Vector4(10, 10, 10, 10)),
				DownImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_down.dds", Vector4(10, 10, 10, 10)),
				DisabledImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_disabled.dds", Vector4(0, 0, 0, 0)),	
			},
			EventClick = function()
				Hidelook_my_space()
			end,
		},
	},
}
function CreatSourceItem(name,index,width,high)
	return Gui.Control
	{
		Size = Vector2(width,high),
		BackgroundColor = ARGB(0, 255, 255, 255),
		Gui.ItemBoxBtn (name..index)
		{
			Style = "Gui.ItemBoxBtn_ib",
			Size = Vector2(width, high),
			BackgroundColor = ARGB(255, 255, 255, 255),
			-- Empty = false,
			-- Type = 1,
			Enable = false,
			Skin = Gui.ItemBoxBtnSkin
			{
				NeutralNormalImage = Gui.Image("LobbyUI/team/lb_squad_1118_normal.dds", Vector4(10, 10, 10, 10)),
				NeutralHoverImage = Gui.Image("LobbyUI/team/lb_squad_1118_hover.dds.dds", Vector4(10, 10, 10, 10)),
				NeutralSelectedImage = Gui.Image("LobbyUI/team/lb_squad_1118_down.dds.dds", Vector4(10, 10, 10, 10)),
				NeutralDisabledImage = Gui.Image("LobbyUI/team/lb_squad_1118_disabled.dds.dds", Vector4(10, 10, 10, 10)),
			},
			EventMouseUp = function(Sender, e)
				local count = 0
				if name == "source_item_" then
					count = 10
					source_exchange_ui.cost_2.Text = TeamHeader_Data.p_UsableResource
					source_exchange_ui.cost_1.Text = exchange_Item_Data[index].resPricesList[1].cost
					source_exchange_ui.t1_2:CleanAll()
					source_exchange_ui.t1_2:AddMsg(lang:GetText("今天已兑换"),ARGB(255, 255, 255, 255),true,false)
					source_exchange_ui.t1_2:AddMsg(exchange_Item_Data[index].buyRecordTimes,ARGB(255, 145, 255, 130),false,false)
					source_exchange_ui.t1_2:AddMsg(lang:GetText("次"),ARGB(255, 255, 255, 255),false,false)
				end
				for i = 1, count do
					source_exchange_ui[name..i].Selected = false
				end
				Sender.Selected = true
				if Sender.IntTag == 3 then
					source_exchange_ui.exchange_btn.Enable = false
				else
					source_exchange_ui.exchange_btn.Enable = true
				end
				
				Filllab1con1()
			end,
			EventMouseEnter = function(sender, e)
				if sender.Loading == false then
					if name == "source_item_" then
						L_ToolTips.FillToolTipsVIPPresent(index, source_exchange_ui.root,exchange_Item_Data)
					end
				end
			end,
			EventToolTipsShow = function(sender, e)
				if name == "source_item_" then
					local loc = sender.Location + sender.Parent.Location + sender.Parent.Parent.Location+ sender.Parent.Parent.Parent.Location+ sender.Parent.Parent.Parent.Parent.Location
					L_ToolTips.ShowToolTipsShowWindow(sender,Vector2(820,705),loc)
				end
			end,
			EventMouseLeave = function(sender, e)
				if name == "source_item_" then
					L_ToolTips.HideToolTipsWindow()
				end
			end,
		},
		Gui.Control ("lock_item_"..index)
		{
			Size = Vector2(width, high),
			Location = Vector2(0, 0),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Enable = false,
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_synthesis_weijiesuo.dds", Vector4(0, 0, 0, 0)),
			},
		},
	}	
end

source_exchange_ui = Gui.Create()
{
	Gui.Control "root"
	{
		Size = Vector2(1600,900),
		Location = Vector2(0, 0),
		BackgroundColor = ARGB(0, 255, 255, 255),
		Gui.Control
		{
			Size = Vector2(720,524),
			Dock = "kDockCenter",
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/team/lb_contact_bg1_01.dds", Vector4(185, 165, 32, 58)),
			},
			Gui.Label
			{
				Location = Vector2(0, 7),
				Size = Vector2(720, 23),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Text = lang:GetText("个人兑换"),
				FontSize = 16,
				TextAlign = "kAlignCenterMiddle",
				TextColor = ARGB(255, 255, 255, 255),
			},
			Gui.Control "source_Item"
			{
				Size = Vector2(685,470),
				Location = Vector2(17, 33),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/lb_shop_bg3_1.dds", Vector4(10, 10, 10, 10)),
				},
				Gui.Control
				{
					Size = Vector2(269, 34),
					Location = Vector2(11, 12),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/lb_yaoqing_bg.dds", Vector4(10, 10, 10, 10)),
					},
					Gui.Label
					{
						Location = Vector2(15, 0),
						Size = Vector2(249, 34),
						Text = lang:GetText("您当前"),
						FontSize = 16,
						TextAlign = "kAlignLeftMiddle",
						TextColor = ARGB(255, 255, 255, 255),
					},
					Gui.Control
					{
						Size = Vector2(68,17),
						Location = Vector2(87, 9),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_zhanduikongjian.dds", Vector4(0, 0, 0, 0)),
						},
					},
					Gui.FlowLayout "placeLevel"
					{
						Size = Vector2(100, 34),
						Location = Vector2(169,1),
						Direction = "kHorizontal",
						Align = "kAlignLeftMiddle",
						ControlAlign = "kAlignCenterMiddle",
						ControlSpace = 0,
					},
				},
				Gui.FlowLayout
				{
					Location = Vector2(50,0),
					Size = Vector2(585,400),
					Direction = "kHorizontal",
					Align = "kAlignCenterMiddle",
					ControlAlign = "kAlignCenterMiddle",
					ControlSpace = 21,
					LineSpace = 21,
					
					CreatSourceItem("source_item_",1,92,92),
					CreatSourceItem("source_item_",2,92,92),
					CreatSourceItem("source_item_",3,92,92),
					CreatSourceItem("source_item_",4,92,92),
					CreatSourceItem("source_item_",5,92,92),
					CreatSourceItem("source_item_",6,92,92),
					CreatSourceItem("source_item_",7,92,92),
					CreatSourceItem("source_item_",8,92,92),
					CreatSourceItem("source_item_",9,92,92),
					CreatSourceItem("source_item_",10,92,92),
				},
				
				Gui.Label
				{
					Size = Vector2(446, 22),
					Location = Vector2(37, 324),
					Text = lang:GetText("提示：“快速获取”和“给战队空间设施升级”可立即获得"),
					TextColor = ARGB(255, 145, 255, 130),
				},
				
				Gui.Control
				{
					Size = Vector2(30, 30),
					Location = Vector2(488, 320),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/lb_icon_res_03.dds", Vector4(0, 0, 0, 0)),
					},
				},
				
				Gui.Control
				{
					Size = Vector2(675, 136),
					Location = Vector2(5, 353),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_xiamian_bg.dds", Vector4(10, 10, 10, 10)),
					},
					Gui.Label
					{
						Size = Vector2(75, 23),
						Location = Vector2(14, 28),
						Text = lang:GetText("剩余"),
						FontSize = 15,
						TextColor = ARGB(255, 255, 210, 0),
					},
					Gui.Label "cost_2"
					{
						Size = Vector2(369, 25),
						Location = Vector2(87, 26),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/lb_com_bg.dds",Vector4(45,0,20,0)),
						},
						Text = "0",
						TextAlign = "kAlignCenterMiddle",
						TextPadding = Vector4(0, 0, 89, 0),
					},
					Gui.Control 
					{
						Size = Vector2(30, 30),
						Location = Vector2(98, 20),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/team/lb_icon_res_03.dds", Vector4(0, 0, 0, 0)),
						},
					},
					Gui.Button
					{
						Size = Vector2(107, 27),
						Location = Vector2(509, 25),
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_button13_normal.dds", Vector4(10, 10, 10, 10)),
							HoverImage = Gui.Image("LobbyUI/team/lb_squad_button13_hover.dds", Vector4(10, 10, 10, 10)),
							DownImage = Gui.Image("LobbyUI/team/lb_squad_button13_down.dds", Vector4(10, 10, 10, 10)),
							DisabledImage = nil,	
						},
						Text = lang:GetText("快速获取"),
						EventClick = function()
							Show_MyAddPower()
						end,
					},
					
					Gui.Control "con1"
					{
						Size = Vector2(500, 500),
						Location = Vector2(0, 0),
						BackgroundColor = ARGB(0, 255, 255, 255),
						Visible = false,
						
						Gui.Label
						{
							Size = Vector2(75, 23),
							Location = Vector2(14, 73),
							Text = lang:GetText("消耗"),
							FontSize = 15,
							TextColor = ARGB(255, 255, 210, 0),
						},
						
						Gui.Label "cost_1"
						{
							Size = Vector2(257, 25),
							Location = Vector2(87, 71),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/lb_com_bg.dds",Vector4(45,0,20,0)),
							},
							Text = "0",
							TextAlign = "kAlignCenterMiddle",
							TextPadding = Vector4(0, 0, 5, 0),
						},
						
						Gui.Control 
						{
							Size = Vector2(30, 30),
							Location = Vector2(98, 65),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/team/lb_icon_res_03.dds", Vector4(0, 0, 0, 0)),
							},
						},
						
						Gui.RichEdit "t1_2"
						{
							Size = Vector2(131, 16),
							Location = Vector2(352, 76),
							FontSize = 14,
							BackgroundColor = ARGB(0, 255, 255, 255),
							AutoScroll = true,
							HScrollBarDisplay = "kHide",
							VScrollBarDisplay = "kHide",
						},
					},
					
					Gui.Label "lab1"
					{
						Size = Vector2(400, 26),
						Location = Vector2(58, 70),
						Text = lang:GetText("点击“兑换”进入开启宝箱界面"),
						TextColor = ARGB(255, 145, 255, 130),
						TextAlign = "kAlignRightMiddle",
						FontSize = 18,
					},
					
					Gui.Button "exchange_btn"
					{
						Size = Vector2(128, 46),
						Location = Vector2(498, 60),
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_duihuan_normal.dds", Vector4(10, 10, 10, 10)),
							HoverImage = Gui.Image("LobbyUI/team/lb_squad_duihuan_hover.dds", Vector4(10, 10, 10, 10)),
							DownImage = Gui.Image("LobbyUI/team/lb_squad_duihuan_down.dds", Vector4(10, 10, 10, 10)),
							DisabledImage = Gui.Image("LobbyUI/team/lb_squad_duihuan_disabled.dds", Vector4(10, 10, 10, 10)),	
						},
						EventClick = function()
							local flag = false
							for i = 1 , 10 do
								if source_exchange_ui["source_item_"..i].Selected then
									flag = true
									if exchange_Item_Data[i].iid == MagicBoxIId then
										ShowMagicBox()
									else
										rpc.safecallload("shop_zyzdz_ex_buy", {pid = ptr_cast(game.CurrentState):GetCharacterId() , sid = exchange_Item_Data[i].sid,costid = exchange_Item_Data[i].resPricesList[1].id},
										function(data)
											source_exchange_ui.exchange_btn.Enable = false
											Fill_Header_Team()
											ShowExchange_Item()
										end)
									end
									break
								end
							end
							if not flag then
								MessageBox.ShowWithTimer(1,lang:GetText("请选择一件商品进行购买！"))
							end
						end,
					},
				},
			},
		},
		--退出
		Gui.Button
		{
			Size = Vector2(48,48),
			Location = Vector2(1126, 180),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_normal.dds", Vector4(10, 10, 10, 10)),
				HoverImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_hover.dds", Vector4(10, 10, 10, 10)),
				DownImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_down.dds", Vector4(10, 10, 10, 10)),
				DisabledImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_disabled.dds", Vector4(0, 0, 0, 0)),	
			},
			EventClick = function()
				HideSource_Exchange()
			end,
		},
	},
}

local view_present_window_ui = nil

Charm_Bottle_Win_ui = Gui.Create()
{
	Gui.Control "Charm_Bottle_root"
	{	
		Size = Vector2(463, 532),
		BackgroundColor = ARGB(0, 255, 255, 255),
		Dock = "kDockCenter",
		
		Gui.Control
		{	
			Size = Vector2(443, 522),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Location = Vector2(10, 5),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/main_bar01.dds", Vector4(20, 20, 20, 20)),
			},
			
			Gui.Label "lab_timer_ctr"
			{
				Size = Vector2(10,10),
				Location = Vector2(0, 0),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Visible = false,
				UseTimer = true,
				DisplayTime = 120,
				
				EventClose = function()
					Get_magic_box_history_list()
				end
			},
			
			Gui.Control
			{	
				Size = Vector2(409, 488),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Location = Vector2(17, 18),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/main_bar02.dds", Vector4(8, 8, 8, 8)),
				},
				
				Gui.Control
				{	
					Size = Vector2(396, 340),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Location = Vector2(9, 1),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_bottle_bar.dds", Vector4(0, 0, 0, 0)),
					},
				},
				
				Gui.Control "icon"
				{	
					Size = Vector2(243, 241),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Location = Vector2(78, 108),
				},
				
				Gui.Label
				{
					Size = Vector2(200, 20),
					Location = Vector2(22, 313),
					Text = lang:GetText("个人黑晶石总量"),
				},
				
				Gui.Control 
				{
					Size = Vector2(30, 30),
					Location = Vector2(143, 305),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/lb_icon_res_03.dds", Vector4(0, 0, 0, 0)),
					},
				},
				
				Gui.Label "pRes"
				{
					Size = Vector2(200, 20),
					Location = Vector2(183, 313),
					Text = lang:GetText("：123456789"),
				},
				
				Gui.Control
				{	
					Size = Vector2(388, 140),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Location = Vector2(9, 340),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/warehouse_bar.dds", Vector4(52, 60, 56, 20)),
					},
					
					
					Gui.Label
					{
						Size = Vector2(200, 40),
						Location = Vector2(13, 7),
						TextAlign = "kAlignLeftMiddle",
						Text = lang:GetText("本次开启"),
					},
					Gui.Control 
					{
						Size = Vector2(30, 30),
						Location = Vector2(74, 10),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/team/lb_icon_res_03.dds", Vector4(0, 0, 0, 0)),
						},
					},
					Gui.Label "pRes_cost"
					{
						Size = Vector2(75, 28),
						Location = Vector2(113, 12),
						BackgroundColor = ARGB(255, 255, 255, 255),
						TextAlign = "kAlignCenterMiddle",
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/number_bar.dds", Vector4(0, 0, 0, 0)),
						},
					},
					Gui.Label
					{
						Size = Vector2(200, 40),
						Location = Vector2(195, 7),
						TextAlign = "kAlignLeftMiddle",
						Text = lang:GetText("下次开启"),
					},
					Gui.Control 
					{
						Size = Vector2(30, 30),
						Location = Vector2(268, 10),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/team/lb_icon_res_03.dds", Vector4(0, 0, 0, 0)),
						},
					},
					Gui.Label "next_pRes_cost"
					{
						Size = Vector2(75, 28),
						Location = Vector2(298, 12),
						BackgroundColor = ARGB(255, 255, 255, 255),
						TextAlign = "kAlignCenterMiddle",
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/number_bar.dds", Vector4(0, 0, 0, 0)),
						},
					},
					Gui.Button
					{
						Size = Vector2(180,64),
						Location = Vector2(12, 62),
						TextColor = ARGB(255, 255, 174, 20),
						FontSize = 24,
						Text = lang:GetText("查看奖励"),
						HighlightTextColor = ARGB(255, 255, 174, 20),
						TextAlign = "kAlignCenterMiddle",
						Padding = Vector4(0, 0, 0, 5),
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_open_button01_normal.dds", Vector4(10, 0, 10, 0)),
							HoverImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_open_button01_hover.dds", Vector4(10, 0, 10, 0)),
							DownImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_open_button01_down.dds", Vector4(10, 0, 10, 0)),
							DisabledImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_open_button01_normal.dds", Vector4(10, 0, 10, 0)),
						},
						EventClick = function()
							for i = 1 , 10 do
								if source_exchange_ui["source_item_"..i].Selected then
									rpc.safecallload("res_box_gift_list", {sid = exchange_Item_Data[i].sid, page = 1},
									function(data)
										--VIP宝箱界面初始化
										ViewPresent_Window = ModalWindow.GetNew()
										ViewPresent_Window.root.Size = Vector2(1200,900)
										L_Characters.present_page = data.page
										L_Characters.present_list = data.items
										L_Characters.present_last_page = data.is_last_page
										L_Characters.FillViewPresent()
										L_Characters.view_present_window_ui.ctrl_view_present_window.Parent = ViewPresent_Window.root
										L_Characters.view_present_window_ui.close.EventClick = function()
											if ViewPresent_Window then
												ViewPresent_Window:Close()
												ViewPresent_Window = nil
											end
										end
										L_Characters.view_present_window_ui.bt_view_present_next.EventClick = function(Sender ,e)
											L_Characters.present_page = L_Characters.present_page + 1
											local args = {sid = exchange_Item_Data[i].sid, page = L_Characters.present_page}
											rpc.safecall("res_box_gift_list", args, 
											function (data)
												if data.warning then
													MessageBox.ShowWithTimer(1,data.warning)
												else
													L_Characters.present_page = data.page
													L_Characters.present_list = data.items
													L_Characters.present_last_page = data.is_last_page
													L_Characters.FillViewPresent()
												end
											end)
										end
										L_Characters.view_present_window_ui.bt_view_present_prev.EventClick = function(Sender ,e)
											L_Characters.present_page = L_Characters.present_page - 1
											if L_Characters.present_page < 1 then
												L_Characters.present_page = 1
											end
											local args = {sid = exchange_Item_Data[i].sid, page = L_Characters.present_page}
											rpc.safecall("res_box_gift_list", args, 
											function (data)
												if data.warning then
													MessageBox.ShowWithTimer(1,data.warning)
												else
													L_Characters.present_page = data.page
													L_Characters.present_list = data.items
													L_Characters.present_last_page = data.is_last_page
													L_Characters.FillViewPresent()
												end
											end)
										end
									end)
									break
								end
							end
						end,
					},
					Gui.Button
					{
						Size = Vector2(180,64),
						Location = Vector2(200, 62),
						TextColor = ARGB(255, 255, 174, 20),
						FontSize = 24,
						Text = lang:GetText("开启"),
						HighlightTextColor = ARGB(255, 255, 174, 20),
						TextAlign = "kAlignCenterMiddle",
						Padding = Vector4(0, 0, 0, 5),
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_open_button01_normal.dds", Vector4(10, 0, 10, 0)),
							HoverImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_open_button01_hover.dds", Vector4(10, 0, 10, 0)),
							DownImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_open_button01_down.dds", Vector4(10, 0, 10, 0)),
							DisabledImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_open_button01_normal.dds", Vector4(10, 0, 10, 0)),
						},
						EventClick = function()
							for i = 1 , 10 do
								if source_exchange_ui["source_item_"..i].Selected then
									rpc.safecallload("res_box_open", {pid = ptr_cast(game.CurrentState):GetCharacterId(), sid = exchange_Item_Data[i].sid},
									function(data)
										if data.warning then
											MessageBox.ShowWithConfirm(data.warning)
										else
											L_Characters.Charm_Bottle_Present[1] = data.item
											L_Characters.ShowCharmBottleOpenPresentWin()
											FillMagicBox(data)
											gui:PlayAudio("kUIA_GETITEM")
										end
									end)
									break
								end
							end
						end,
					},
				},
			},
		},
		
		--退出
		Gui.Button
		{
			Size = Vector2(48,48),
			Location = Vector2(403, 0),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_normal.dds", Vector4(10, 10, 10, 10)),
				HoverImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_hover.dds", Vector4(10, 10, 10, 10)),
				DownImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_down.dds", Vector4(10, 10, 10, 10)),
				DisabledImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_disabled.dds", Vector4(0, 0, 0, 0)),	
			},
			EventClick = function()
				if CharmBottle_Window then
					CharmBottle_Window:Close()
					CharmBottle_Window = nil
				end
			end,
		},
	}
}

function ShowMagicBox()
	for i = 1 , 10 do
		if source_exchange_ui["source_item_"..i].Selected then
			rpc.safecallload("res_box_list", {pid = ptr_cast(game.CurrentState):GetCharacterId() , sid = exchange_Item_Data[i].sid},
			function(data)
				if not CharmBottle_Window then
					CharmBottle_Window = ModalWindow.GetNew()
					CharmBottle_Window.root.Size = Vector2(1200, 900)
					CharmBottle_Window.screen.AllowEscToExit = false
				end
				Charm_Bottle_Win_ui.Charm_Bottle_root.Parent = CharmBottle_Window.root
				FillMagicBox(data)
			end)
			break
		end
	end
end

function FillMagicBox(data)
	Charm_Bottle_Win_ui.pRes.Text = ":  "..data.pRes
	Charm_Bottle_Win_ui.pRes_cost.Text = data.cost
	Charm_Bottle_Win_ui.next_pRes_cost.Text = data.ncost
	for i = 1 , 10 do
		if source_exchange_ui["source_item_"..i].Selected then
			Charm_Bottle_Win_ui.icon.Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/"..exchange_Item_Data[i].name.."_1.dds", Vector4(0, 0, 0, 0)),
			}
			break
		end
	end
	
end

function ShowSource_Exchange()
	source_exchange_window = ModalWindow.GetNew()
	source_exchange_window.root.Size = Vector2(1600, 900)
	source_exchange_window.screen.AllowEscToExit = false
	source_exchange_ui.root.Parent = source_exchange_window.root
	FillSource_Exchange()
end

function FillSource_Exchange()
	source_exchange_ui.t1_2:CleanAll()
	source_exchange_ui.t1_2:AddMsg(lang:GetText("今天已兑换"),ARGB(255, 255, 255, 255),true,false)
	source_exchange_ui.t1_2:AddMsg("0",ARGB(255, 145, 255, 130),false,false)
	source_exchange_ui.t1_2:AddMsg(lang:GetText("次"),ARGB(255, 255, 255, 255),false,false)
	L_LobbyMain.ShowFightnums(source_exchange_ui.placeLevel,tonumber(TeamHeader_Data.t_teamSpaceLevel),"team/lb_squad_number_01.dds")
	ShowExchange_Item()
	source_exchange_ui.cost_2.Text = TeamHeader_Data.p_UsableResource
end

function Filllab1con1()
	for i = 1 , 10 do
		if source_exchange_ui["source_item_"..i].Selected then
			source_exchange_ui.con1.Visible = not (exchange_Item_Data[i].iid == MagicBoxIId)
			source_exchange_ui.lab1.Visible = (exchange_Item_Data[i].iid == MagicBoxIId)
			break
		end
	end
end

function ShowExchange_Buff()
	rpc.safecallload("shop_zyzdz_ex_list", {pid = ptr_cast(game.CurrentState):GetCharacterId() , page = 1 , type = 1},
	function(data)
		local num = 1
		exchange_Buff_Data = data.items
		for i,v in ipairs(data.items) do
			local ibbtn = source_exchange_ui["buff_"..i]
			ibbtn:OnDestroy()
			ibbtn.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..v.name..".tga")
			ibbtn.Enable = true
		end
		for i = num, 5 do
			local ibbtn = source_exchange_ui["buff_"..i]
			ibbtn:OnDestroy()
			ibbtn.ItemIcon = nil
			ibbtn.Enable = false
		end
		for i = 1, 5 do
			if source_exchange_ui["buff_"..i].Selected then
				source_exchange_ui.cost_2.Text = TeamHeader_Data.p_UsableResource
				source_exchange_ui.cost_1.Text = exchange_Buff_Data[i].resPricesList[1].cost
				source_exchange_ui.t1_2:CleanAll()
				source_exchange_ui.t1_2:AddMsg(lang:GetText("今天已兑换"),ARGB(255, 255, 255, 255),true,false)
				source_exchange_ui.t1_2:AddMsg(exchange_Buff_Data[i].buyRecordTimes,ARGB(255, 145, 255, 130),false,false)
				source_exchange_ui.t1_2:AddMsg(lang:GetText("次"),ARGB(255, 255, 255, 255),false,false)
				break
			end
		end
	end)
end

function ShowExchange_Item()
	rpc.safecallload("shop_zyzdz_ex_list", {pid = ptr_cast(game.CurrentState):GetCharacterId() , page = 1 , type = 2},
	function(data)
		source_exchange_ui.exchange_btn.Enable = true
		local num = 1
		exchange_Item_Data = data.items
		local select_flag = false
		for i,v in ipairs(data.items) do
			local ibbtn = source_exchange_ui["source_item_"..i]
			local lock = source_exchange_ui["lock_item_"..i]
			ibbtn:OnDestroy()
			ibbtn.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..v.name..".tga")
			ibbtn.Enable = true
			ibbtn.Selected = false
			num = num + 1
			if v.common.is_exchange == 3 then
				source_exchange_ui["lock_item_"..i].Visible = true
			else
				source_exchange_ui["lock_item_"..i].Visible = false
				if not select_flag then
					select_flag = true
					ibbtn.Selected = true
				end
			end
			source_exchange_ui["source_item_"..i].IntTag = v.common.is_exchange
		end
		for i = num , 10 do
			local ibbtn = source_exchange_ui["source_item_"..i]
			local lock = source_exchange_ui["lock_item_"..i]
			lock.Visible = false
			ibbtn:OnDestroy()
			ibbtn.ItemIcon = nil
			ibbtn.Enable = false
		end
		for i = 1, 10 do
			if source_exchange_ui["source_item_"..i].Selected then
				source_exchange_ui.cost_2.Text = TeamHeader_Data.p_UsableResource
				source_exchange_ui.cost_1.Text = exchange_Item_Data[i].resPricesList[1].cost
				source_exchange_ui.t1_2:CleanAll()
				source_exchange_ui.t1_2:AddMsg(lang:GetText("今天已兑换"),ARGB(255, 255, 255, 255),true,false)
				source_exchange_ui.t1_2:AddMsg(exchange_Item_Data[i].buyRecordTimes,ARGB(255, 145, 255, 130),false,false)
				source_exchange_ui.t1_2:AddMsg(lang:GetText("次"),ARGB(255, 255, 255, 255),false,false)
				break
			end
		end
		Filllab1con1()
	end)
end

function HideSource_Exchange()
	if source_exchange_window then
		source_exchange_window:Close()
		source_exchange_window = nil
	end
end

function ShowSource_Time()
	source_time_window = ModalWindow.GetNew()
	source_time_window.root.Size = Vector2(780, 194)
	source_time_window.screen.AllowEscToExit = false
	source_time_ui.root.Parent = source_time_window.root
end

function HideSource_Time()
	if source_time_window then
		source_time_window:Close()
		source_time_window = nil
	end
end

function Showlook_my_space()
	look_my_space_window = ModalWindow.GetNew()
	look_my_space_window.root.Size = Vector2(812, 657)
	look_my_space_window.screen.AllowEscToExit = false
	look_my_space.root.Parent = look_my_space_window.root
	rpc.safecallload("get_ourTeamLevel", {teamId = t_id},
	function(data)
		FillMap(data.configs,2,0,data.tsl,data.name)
	end)
	source_success_ui.map_bg.Parent = look_my_space.map_bg
end

function Hidelook_my_space()
	if look_my_space_window then
		look_my_space_window:Close()
		look_my_space_window = nil
	end
end

function ShowSource_Success(challengeCost)
	source_success_window = ModalWindow.GetNew()
	source_success_window.root.Size = Vector2(1200, 900)
	source_success_window.screen.AllowEscToExit = false
	source_success_ui.root.Parent = source_success_window.root
	local list = source_success_ui.Fight_Team_Room_Player
	list:DeleteColumns()
	list:AddColumn("",1, "kAlignCenterMiddle")
	list:AddColumn("",79, "kAlignCenterMiddle")
	list:AddColumn("",265, "kAlignLeftMiddle")
	print("team_data[2]:"..team_data[2])
	L_Friends.CreatePrivateChat(team_data[2],6,nil,source_success_ui.root)
	InitSource_Success()
	print("SourceFightType:"..SourceFightType)
	source_success_ui.c_cost_source_bg.Visible = true
	source_success_ui.c_res_icon.Visible = true
	if SourceFightType == 0 then
		source_success_ui.b_source_pi.Visible = true
		source_success_ui.b_source_pipei.Enable = false
		source_success_ui.c_cost_source_bg.Location = Vector2(741, 700)
		source_success_ui.c_res_icon.Location = Vector2(793 - 50, 691)
		source_success_ui.c_res_icon.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/team/lb_icon_res_02_1.dds", Vector4(0, 0, 0, 0)),}
		source_success_ui.c_cost_source.Text = lang:GetText("个人消耗：100")
		source_success_ui.c_res_icon_left.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/team/lb_icon_res_02_1.dds", Vector4(0, 0, 0, 0)),}
		source_success_ui.c_cost_source_left.Text = lang:GetText("个人剩余：")..p_UnusableResource
	elseif SourceFightType == 1 then
		source_success_ui.b_source_pi.Visible = false
		source_success_ui.b_source_pipei.Enable = true
		source_success_ui.c_cost_source_bg.Location = Vector2(925, 700)
		source_success_ui.c_res_icon.Location = Vector2(977 - 50, 691)
		source_success_ui.c_res_icon.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/team/lb_icon_res_fc.dds", Vector4(0, 0, 0, 0)),}
		if challengeCost then
			source_success_ui.c_cost_source.Text = lang:GetText("个人消耗：")..challengeCost
		else
			source_success_ui.c_cost_source.Text = lang:GetText("个人消耗：")
		end
		source_success_ui.c_res_icon_left.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/team/lb_icon_res_fc.dds", Vector4(0, 0, 0, 0)),}
		source_success_ui.c_cost_source_left.Text = lang:GetText("个人剩余：")..L_LobbyMain.PersonalInfo_data.newCR
	end
	source_success_ui.map:OnDestroy()
	ptr_cast(game.CurrentState):OnChange_Lobby_Music(1)
	source_success_ui.back_btn.Enable = true
	source_success_ui.b_source_pi.Enable = true
end

function HideSource_Success()
	if source_success_window then
		source_success_window:Close()
		source_success_window = nil
	end
end

function InitSource_Success()
	source_success_ui.map_bg.Parent = source_success_ui.background
	source_success_ui.l_source_rank.Text = ""
	source_success_ui.l_fightroom_lv.Text = ""
	source_success_ui.l_fightname.Text = ""
	source_success_ui.get_source.Text = ""
	team_ui.SourceStartTimer:CleanAll()
	source_start_time = 20
	local Control = ptr_cast(source_success_ui.time:GetChildByIndex(4))
	Control.Skin = Gui.ControlSkin
	{
		BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_number_01.dds", Vector4(0, 0, 0, 0), Vector4((source_start_time%10 / 10), 0, (source_start_time%10 / 10) + 0.1, 1)),
	}
	Control = ptr_cast(source_success_ui.time:GetChildByIndex(3))
	Control.Skin = Gui.ControlSkin
	{
		BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_number_01.dds", Vector4(0, 0, 0, 0), Vector4((math.floor(source_start_time / 10) / 10), 0, (math.floor(source_start_time / 10) / 10) + 0.1, 1)),
	}
	FillSource_Success_Room()
end

function FillSource_Success_Room()
	local ltv = source_success_ui.Fight_Team_Room_Player 
	ltv:DeleteAll()
	local i = 1
	state = ptr_cast(game.CurrentState)
	if not state then
		return
	end
	local client_count = state:GetClientCount()
	for i = 0, client_count - 1 do
		local client_info = state:GetClientInfo(i)
		local sub_item = ltv:AddItem(ltv.RootItem)
		sub_item:AddSubItem("LV:"..client_info.level)
		sub_item:AddSubItem(client_info.name)
		sub_item.NAME = client_info.name
		sub_item.BGSkin = Skin.ListSourceItemSkin
		i = i + 1
		sub_item.ID = client_info.id
	end
	
	if i < 8 then
		local j 
		for j = i ,7 do
			local sub_item = ltv:AddItem(ltv.RootItem)
			sub_item.CanSelect = false
			sub_item.ID = -1
			sub_item.BGSkin = Skin.ListSourceItemSkin
		end
	end
end

function Get_Angle(x, y, z, w)
	return math.floor((Quaternion(tonumber(x), tonumber(y), tonumber(z), tonumber(w)):GetAngle() * 180 / math.pi) + 0.00005)
end

function FillMap(str,FightType,canRobUnuseRes,teamSpaceLevel,name)
	if source_success_ui.map then
		source_success_ui.map:OnDestroy()
	end
	source_success_ui.l_get_source.Visible = true
	source_success_ui.get_source.Visible = true
	if FightType == 0 then
		source_success_ui.get_source.Text = lang:GetText("原石：")..canRobUnuseRes..lang:GetText("点")
	elseif FightType == 1 then
		source_success_ui.get_source.Text = lang:GetText("战队黑铁：")..canRobUnuseRes..lang:GetText("点")
	elseif FightType == 2 then
		source_success_ui.l_get_source.Visible = false
		source_success_ui.get_source.Visible = false
	end
	source_success_ui.l_source_rank.Text = ""
	source_success_ui.l_fightroom_lv.Text = teamSpaceLevel
	source_success_ui.l_fightname.Text = name
	local obj = L_PushCmd.Split(str, ";")
	for i = 1, #obj - 1 do
		local tab = L_PushCmd.Split(obj[i], ",")
		tab[6] = math.floor((tab[6] + 51.6) / 0.15)
		tab[8] = math.floor((tab[8] + 39.9) / 0.15)
		AddIcon(tab[6], tab[8], tab[1], Get_Angle(tab[2], tab[3], tab[4], tab[5]))
	end
end

function AddIcon(x, y, name, angel)
	local ui = Gui.Create()
	{
		Gui.Control "root"
		{		
			Size = Vector2(35, 35),
			Location = Vector2(x - 18, y - 18),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/team/map/lb_icon_ditu_"..name.."_"..angel..".dds", Vector4(0, 0, 0, 0)),
			},
		}
	}
	ui.root.Parent = source_success_ui.map
end

function ShowDenfanseFight()
	defanse_fight_window = ModalWindow.GetNew()
	defanse_fight_window.root.Size = Vector2(863, 570)
	defanse_fight_window.screen.AllowEscToExit = false
	defanse_fight_ui.root.Parent = defanse_fight_window.root
	FillDefanseFight()
end

function HideDefanseFight()
	if defanse_fight_window then
		defanse_fight_window:Close()
		defanse_fight_window = nil
	end
end

function FillDefanseFight()
	for i = 1 , 10 do
		if attack_team_info[i][1] then
			defanse_fight_ui["defanse_list"..i].Visible = true
			defanse_fight_ui["server_id_"..i].Text = attack_team_info[i][1]
			defanse_fight_ui["channel_id_"..i].Text = attack_team_info[i][2]
			defanse_fight_ui["room_id_"..i].Text = attack_team_info[i][3]
			defanse_fight_ui["psd_"..i].Text = attack_team_info[i][4]
			defanse_fight_ui["defanse_team_name"..i].Text = lang:GetText("领地遭受“")..attack_team_info[i][5]..lang:GetText("”攻击")
			defanse_fight_ui["atk_num"..i].Text = attack_team_info[i][11]..lang:GetText("人")
			if attack_team_info[i][7] == 0 then
				defanse_fight_ui["defanse_type"..i].Text = lang:GetText("争夺")
				defanse_fight_ui["defanse_type"..i].TextColor = ARGB(255, 255, 255, 255)
			elseif attack_team_info[i][7] == 1 then
				defanse_fight_ui["defanse_type"..i].Text = lang:GetText("挑战")
				defanse_fight_ui["defanse_type"..i].TextColor = ARGB(255, 213, 24, 30)
			end
		else
			defanse_fight_ui["defanse_list"..i].Visible = false
			defanse_fight_ui["server_id_"..i].Text = ""
			defanse_fight_ui["channel_id_"..i].Text = ""
			defanse_fight_ui["room_id_"..i].Text = ""
			defanse_fight_ui["psd_"..i].Text = ""
		end
	end
end

function ShowWeekendRank()
	weekend_rank_window = ModalWindow.GetNew()
	weekend_rank_window.root.Size = Vector2(863, 626)
	weekend_rank_window.screen.AllowEscToExit = false
	weekend_rank_ui.root.Parent = weekend_rank_window.root
	rpc.safecallload("team_res_record_list", {tid = t_id , type = Weekend_Type},
	function(data)
		FillWeekendRank(data)
	end)
end

function HideWeekendRank()
	if weekend_rank_window then
		weekend_rank_window:Close()
		weekend_rank_window = nil
	end
end

function FillWeekendRank(data)
	local size = #data.list
	local resourcename
	weekend_rank_ui.r_data:CleanAll()
	weekend_rank_ui.r_data.AutoScrollMinSize = Vector2(0,20*size)
	weekend_rank_ui.r_data.MaxLine = size
	for i = 1 , size do
		if data.list[i][1] == 1 then
			resourcename = lang:GetText("战队原石")
		else
			resourcename = lang:GetText("战队黑铁")
		end
		if data.list[i][2] then
			weekend_rank_ui.r_data:AddMsg(data.list[i][7]..lang:GetText("  发动对【")..data.list[i][4]..lang:GetText("】攻击，抢夺【"..resourcename.."】")..data.list[i][5],ARGB(255, 81, 138, 79),true,false)
		else
			weekend_rank_ui.r_data:AddMsg(data.list[i][7]..lang:GetText("  遭受【")..data.list[i][3]..lang:GetText("】攻击，损失【"..resourcename.."】")..data.list[i][6],ARGB(255, 151, 57, 38),true,false)
		end		
	end
end

function BeginSourcePipei(isPipei)
	if SourceFightType == 0 then
		rpc.safecallload("get_battlefield_match", {pid = ptr_cast(game.CurrentState):GetCharacterId(),c = pipeiTimes},
		function(data)
			if not data then
				if isPipei then
					source_time_ui.l_text.Text = lang:GetText("匹配中......")
					source_time_ui.b_exit.Visible = true
					ShowSource_Time()
				end
				team_ui.SourceTimer:CleanAll()
				team_ui.SourceTimer:AddTime(10)
				return
			end
			
			if data.outOfStones then
				MessageBox.ShowWithConfirm(lang:GetText("原石不足"))
				source_success_ui.b_source_pi.Enable = true
				return
			elseif data.outOfCount then
				MessageBox.ShowWithConfirm(lang:GetText("暂时没有可匹配的战队"))
				source_success_ui.b_source_pi.Enable = true
				return
			end
			
			if data.pDisResStone then
				source_success_ui.c_cost_source_left.Text = lang:GetText("个人剩余：")..data.pDisResStone
			end
			
			if isPipei then
				source_time_ui.l_text.Text = lang:GetText("匹配中......")
				source_time_ui.b_exit.Visible = true
				ShowSource_Time()
			end
			if not data.name then
				team_ui.SourceTimer:CleanAll()
				team_ui.SourceTimer:AddTime(10)
			else
				source_success_ui.b_source_pipei.Enable = true
				HideSource_Time()
				team_ui.SourceStartTimer:CleanAll()
				team_ui.SourceStartTimer:AddTime(1)
				source_start_time = 20
				local Control = ptr_cast(source_success_ui.time:GetChildByIndex(4))
				Control.Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_number_01.dds", Vector4(0, 0, 0, 0), Vector4((source_start_time%10 / 10), 0, (source_start_time%10 / 10) + 0.1, 1)),
				}
				Control = ptr_cast(source_success_ui.time:GetChildByIndex(3))
				Control.Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_number_01.dds", Vector4(0, 0, 0, 0), Vector4((math.floor(source_start_time / 10) / 10), 0, (math.floor(source_start_time / 10) / 10) + 0.1, 1)),
				}
				teamSpaceLevel = data.teamSpaceLevel
				battleFieldId = data.battleFieldId
				canRobUnuseRes = data.canRobUnuseRes
				create_source_room_option.level_id = data.battleFieldId
				local state = ptr_cast(game.CurrentState)
				-- if data.canRobUnuseRes then
					-- source_success_ui.get_source.Text = lang:GetText("原石：")..data.canRobUnuseRes..lang:GetText("点")
				-- end
				-- source_success_ui.l_source_rank.Text = ""
				-- source_success_ui.l_fightroom_lv.Text = data.teamSpaceLevel
				-- source_success_ui.l_fightname.Text = data.name
				FillMap(data.formatedConfig,SourceFightType,data.canRobUnuseRes,data.teamSpaceLevel,data.name)
				map_config = data.formatedConfig
				if state then
					state:RoomChangeOption(create_source_room_option)
					MessageBox.CloseWaiter()
					HideSourceFight()
					source_defance_tid = data.id
					-- rpc.safecall("handle_battlefield_battle", {tid = source_defance_tid,t = 1},
					-- function(data)
					-- end)
					-- rpc.safecall("push_battlefield_defense_invite", {atid = t_id,dtid = source_defance_tid,serverid = game.ClientAddress.server_id,channelid = game.ClientAddress.channel_id,roomid = game.ClientAddress.room_id,roompwd = create_source_room_option.password},
					-- function(data)
					-- end)
				end
				source_success_ui.b_source_pi.Enable = true
			end
		end)
	elseif SourceFightType == 1 then
		rpc.safecall("get_challenge_info", {tid = SourceTiaozhanTid},
		function(data)
			ShowSource_Success(data.challengeCost)
			team_ui.SourceStartTimer:CleanAll()
			team_ui.SourceStartTimer:AddTime(1)
			source_start_time = 20
			
			local Control = ptr_cast(source_success_ui.time:GetChildByIndex(4))
			Control.Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_number_01.dds", Vector4(0, 0, 0, 0), Vector4((source_start_time%10 / 10), 0, (source_start_time%10 / 10) + 0.1, 1)),
			}
			Control = ptr_cast(source_success_ui.time:GetChildByIndex(3))
			Control.Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_number_01.dds", Vector4(0, 0, 0, 0), Vector4((math.floor(source_start_time / 10) / 10), 0, (math.floor(source_start_time / 10) / 10) + 0.1, 1)),
			}
			
			teamSpaceLevel = data.teamSpaceLevel
			battleFieldId = data.battleFieldId
			canRobUnuseRes = data.canRobStones
			create_source_room_option.level_id = data.battleFieldId
			local state = ptr_cast(game.CurrentState)
			-- if data.canRobStones then
				-- source_success_ui.get_source.Text = lang:GetText("黑铁：")..data.canRobStones..lang:GetText("点")
			-- end
			-- source_success_ui.l_source_rank.Text = ""
			-- source_success_ui.l_fightroom_lv.Text = data.teamSpaceLevel
			-- source_success_ui.l_fightname.Text = data.name
			FillMap(data.formatedConfig,SourceFightType,data.canRobStones,data.teamSpaceLevel,data.name)
			map_config = data.formatedConfig
			if state then
				state:RoomChangeOption(create_source_room_option)
				MessageBox.CloseWaiter()
				HideSourceFight()
				source_defance_tid = data.id
			end
		end)
	end	
end

function ShowSourceFight()
	if source_fight_window or source_success_window then
		return
	end
	source_fight_window = ModalWindow.GetNew()
	source_fight_window.root.Size = Vector2(741, 684)
	source_fight_window.screen.AllowEscToExit = false
	source_fight_ui.root.Parent = source_fight_window.root
	
	local zhanduilist = source_fight_ui.Fight_Team_Player_List
	zhanduilist:DeleteColumns()
	zhanduilist:AddColumn("",37, "kAlignRightMiddle")
	zhanduilist:AddColumn("",20, "kAlignRightMiddle")
	zhanduilist:AddColumn("",123, "kAlignLeftMiddle")
	zhanduilist:AddColumn("",90, "kAlignRightMiddle")
	
	local list = source_fight_ui.Fight_Team_Room_Player
	list:DeleteColumns()
	list:AddColumn("",37, "kAlignRightMiddle")
	list:AddColumn("",20, "kAlignRightMiddle")
	list:AddColumn("",213, "kAlignLeftMiddle")
	-- list:AddColumn("",123, "kAlignRightMiddle")
	source_defance_tid = 0
	L_Friends.CreatePrivateChat(team_data[2],6,nil,source_fight_ui.root)
	-- if SourceFightType == 0 then
		-- source_fight_ui.b_source_pipei.Text = lang:GetText("开始匹配")
	-- elseif SourceFightType == 1 then
		-- source_fight_ui.b_source_pipei.Text = lang:GetText("确定")
	-- end
end

function HideSourceFight()
	if source_fight_window then
		source_fight_window:Close()
		source_fight_window = nil
	end
end

function FillSourceZhanduiList()
	if create_source_room_option then
		source_fight_ui.b_del.Enable = true
		source_fight_ui.b_yaoqing.Enable = true
		source_fight_ui.b_source_pipei.Enable = true
		source_fight_ui.b_sourceall.Enable = true
	else
		source_fight_ui.b_del.Enable = false
		source_fight_ui.b_yaoqing.Enable = false
		source_fight_ui.b_source_pipei.Enable = false
		source_fight_ui.b_sourceall.Enable = false
	end
	rpc.safecall("team_member_list", {tid = t_id, page = -1},
	function(data)
		local member = data.team.member
		local ltv = source_fight_ui.Fight_Team_Player_List   
		ltv:DeleteAll()
		local i = 1
		if member then
			for k, v in ipairs(member) do 
				if v[4] ~= L_LobbyMain.PersonalInfo_data.name then
					if v[5] == 1 then
						local sub_item = ltv:AddItem(ltv.RootItem)
						sub_item.CheckBoxSize = Vector2(34, 34)
						sub_item.CheckBoxLocation = Vector2(10, 0)
						sub_item.CheckVisible = true
						sub_item:AddSubItem(nil)
						sub_item:AddSubItem(v[4])
						sub_item.NAME = v[4]
						sub_item.ID = v[1]
						sub_item.BGSkin = Skin.ListSourceItemSkin
						i = i + 1
					end	
				end
			end
		end

		if i < 15 then
			local j 
			for j = i ,14 do
				local sub_item = ltv:AddItem(ltv.RootItem)
				sub_item.CanSelect = false
				sub_item.CheckBoxSize = Vector2(0, 0)
				sub_item.CheckVisible = false
				sub_item.ID = 0
				sub_item.BGSkin = Skin.ListSourceItemSkin
			end
		end	
	end)	
end

function FillSourceZhanduiRoom()
	if create_source_room_option then
		source_fight_ui.b_del.Enable = true
		source_fight_ui.b_yaoqing.Enable = true
	else
		source_fight_ui.b_del.Enable = false
		source_fight_ui.b_yaoqing.Enable = false
	end
	local ltv = source_fight_ui.Fight_Team_Room_Player 
	ltv:DeleteAll()
	local i = 1
	state = ptr_cast(game.CurrentState)
	if not state then
		return
	end
	local client_count = state:GetClientCount()
	source_fight_ui.source_roomnum.Text = client_count.."/6"
	source_roomnum = client_count
	for i = 0, client_count - 1 do
		local client_info = state:GetClientInfo(i)
		local sub_item = ltv:AddItem(ltv.RootItem)
		sub_item.CheckBoxSize = Vector2(34, 34)
		sub_item.CheckBoxLocation = Vector2(10, 0)
		sub_item.CheckVisible = true
		sub_item:AddSubItem(nil)
		sub_item:AddSubItem(client_info.name)
		sub_item.NAME = client_info.name
		sub_item.BGSkin = Skin.ListSourceItemSkin
		i = i + 1
		sub_item.ID = client_info.id
	end
	
	if i < 8 then
		local j 
		for j = i ,7 do
			local sub_item = ltv:AddItem(ltv.RootItem)
			sub_item.CanSelect = false
			sub_item.CheckBoxSize = Vector2(0, 0)
			sub_item.CheckVisible = false
			sub_item.NAME = ""
			sub_item.ID = 0
			sub_item.BGSkin = Skin.ListSourceItemSkin
		end
	end		
end

function ShowRapidShoppingWin()
	if Rapid_Shopping_Win_ui == nil then
		Rapid_Shopping_Win_ui = Gui.Create()(Rapid_Shopping_Win)
		--快速购买界面初始化
		RapidShopping_Window = ModalWindow.GetNew("Rapid_Shopping_Win_ui")
		RapidShopping_Window.screen.AllowEscToExit = false
		RapidShopping_Window.screen.Visible = false
		--RapidShopping_Window.screen.EventEscPressed = HideCharmBottleWin
		RapidShopping_Window.screen.EventEscPressed = nil
		RapidShopping_Window.root.Size = Vector2(1200, 900)
		Rapid_Shopping_Win_ui.Rapid_Shopping_root.Parent = RapidShopping_Window.root
	end
	Rapid_Shopping_Win_ui.des.Size = Vector2(200, 50)
	Rapid_Shopping_Win_ui.des.Location = Vector2(55, 110)
	Rapid_Shopping_Win_ui.des.FontSize = 16
	
	Rapid_Shopping_Win_ui.des.Text = key_item[key_num].description
	Rapid_Shopping_Win_ui.name.Text = key_item[key_num].display
	if RapidShopping_Window and RapidShopping_Window.screen then
		RapidShopping_Window.screen.Visible = true
		--gui.EventEscPressed = HideCharmBottleWin
		gui.EventEscPressed = nil
	end
	FileHummerItemBox()
end

function HideRapidShoppingWin()
	if RapidShopping_Window and RapidShopping_Window.screen then
		RapidShopping_Window.screen.Visible = false
		Rapid_Shopping_Win_ui = nil
	end
end

function FileHummerItemBox()
	Rapid_Shopping_Win_ui.itembox_hummer.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..key_item[key_num].name..".tga")
	Rapid_Shopping_Win_ui.Tbox_Totle_num.Text = 1
end

function SetHummerTotalMoney()
	if Rapid_Shopping_Win_ui.Tbox_Totle_num.Text == "" then
		Rapid_Shopping_Win_ui.Total_money.Text = "0"
		return
	end
	if key_num == 1 then
		Rapid_Shopping_Win_ui.Total_money.Text = key_item[key_num].gpprices[1].cost * Rapid_Shopping_Win_ui.Tbox_Totle_num.Text / key_item[key_num].gpprices[1].unit
	else
		Rapid_Shopping_Win_ui.Total_money.Text = key_item[key_num].crprices[1].cost * Rapid_Shopping_Win_ui.Tbox_Totle_num.Text / key_item[key_num].crprices[1].unit
	end
end

function ShowFightTeam()

	-- if L_WarZone.matchTime_window_ui then
		-- return
	-- end
	fightteam_fight_window = ModalWindow.GetNew()
	fightteam_fight_window.root.Size = Vector2(789, 677)
	fightteam_fight_window.screen.AllowEscToExit = false
	fightteam_fight_ui.root.Parent = fightteam_fight_window.root
	
	local zhanduilist = fightteam_fight_ui.Fight_Team_Player_List
	zhanduilist:DeleteColumns()
	zhanduilist:AddColumn("",10, "kAlignRightMiddle")
	zhanduilist:AddColumn("",35, "kAlignCenterMiddle")
	zhanduilist:AddColumn("",25, "kAlignRightMiddle")
	zhanduilist:AddColumn("",25, "kAlignLeftMiddle")
	zhanduilist:AddColumn("",170, "kAlignLeftMiddle")
	zhanduilist:AddColumn("",20, "kAlignCenterMiddle")
	
	local list = fightteam_fight_ui.Fight_Team_Room_Player
	list:DeleteColumns()
	list:AddColumn("",50, "kAlignCenterMiddle")
	list:AddColumn(lang:GetText("头像"), 35, "kAlignCenterMiddle")
	list:AddColumn(lang:GetText("等"), 22,"kAlignRightMiddle")
	list:AddColumn(lang:GetText("级"), 22,"kAlignLeftMiddle")
	list:AddColumn(lang:GetText("玩家昵称"),160,"kAlignCenterMiddle")
	list:AddColumn(lang:GetText("状态"),56,"kAlignCenterMiddle")
end

function HideFightTeam()
	if fightteam_fight_window then
		fightteam_fight_window:Close()
		fightteam_fight_window = nil
	end
end

function ShowTiaoZhan()
	tiaozhan_window = ModalWindow.GetNew()
	tiaozhan_window.root.Size = Vector2(543, 635)
	tiaozhan_window.screen.AllowEscToExit = false
	tiaozhan_ui.root.Parent = tiaozhan_window.root
	
	-- tiaozhan_ui.re_msg_1:CleanAll()
	-- tiaozhan_ui.re_msg_1:AddMsg(lang:GetText("您还可以选择某个战队，向他们发起挑战！"),ARGB(255, 226, 217, 208),true,false)
	-- tiaozhan_ui.re_msg_1:AddMsg(lang:GetText("挑战"),ARGB(255, 255, 111, 56),false,false)
	-- tiaozhan_ui.re_msg_1:AddMsg("！",ARGB(255, 226, 217, 208),false,false)
	InitialShowTeamInfoBTN()
	local list = tiaozhan_ui.TiaoZhan_Fight_Team
	list:DeleteColumns()
	list:AddColumn("",60, "kAlignCenterMiddle")
	list:AddColumn("", 60, "kAlignCenterMiddle")
	list:AddColumn("", 60,"kAlignCenterMiddle")
	list:AddColumn("", 150,"kAlignCenterMiddle")
	
	tiaozhan_page = 1
	tiaozhan_ui.m_PageDisplay.Text = lang:GetText("第")..tiaozhan_page..lang:GetText("页")
end

function HideTiaoZhan()
	if tiaozhan_window then
		tiaozhan_window:Close()
		tiaozhan_window = nil
	end
end

function ShowZhiHuiSuo()
	zhihuisuo_window = ModalWindow.GetNew()
	zhihuisuo_window.root.Size = Vector2(1050, 859)
	-- zhihuisuo_window.screen.AllowEscToExit = false
	zhihuisuo_ui.root.Parent = zhihuisuo_window.root
	for i = 1 , 3 do
		local list = zhihuisuo_ui["Fight_Team_Room_Player"..i]
		list:DeleteColumns()
		list:AddColumn("",50, "kAlignCenterMiddle")
		list:AddColumn(lang:GetText("头像"), 40, "kAlignCenterMiddle")
		list:AddColumn(lang:GetText("等"), 32,"kAlignRightMiddle")
		list:AddColumn(lang:GetText("级"), 32,"kAlignLeftMiddle")
		list:AddColumn(lang:GetText("玩家昵称"),80,"kAlignCenterMiddle")
		list:AddColumn(lang:GetText("状态"),56,"kAlignCenterMiddle")
	end
	three_battle_page = 0
	zhihuisuo_ui.m_Left.Enable = false
	zhihuisuo_ui.update_info:CleanAll()
	zhihuisuo_ui.update_info:AddTime(update_time)
end

function HideZhiHuiSuo()
	if zhihuisuo_window then
		zhihuisuo_window:Close()
		zhihuisuo_window = nil
	end
end

function ShowBattleTime()
	battle_time_window = ModalWindow.GetNew()
	battle_time_window.root.Size = Vector2(218,219)
	battle_time_window.screen.AllowEscToExit = false
	battle_time_ui.root.Parent = battle_time_window.root
	local state = ptr_cast(game.CurrentState)
	print("battle_host_id:"..battle_host_id)
	print("state:GetUserId():"..state:GetUserId())
	-- if battle_host_id == state:GetUserId() then
		-- battle_time_ui.b_exit.Visible = true
	-- else
		-- battle_time_ui.b_exit.Visible = false
	-- end
	if fightteam_fight_ui and fightteam_fight_ui.b_pipei.Text == lang:GetText("匹配对手") then
		battle_time_ui.b_exit.Visible = true
	else
		battle_time_ui.b_exit.Visible = false
	end
		
	-- battle_time_ui.Cctr_flash_Bg:DeleteAllImage()
	-- battle_time_ui.Cctr_flash_Bg:AddFrame(Gui.Image("LobbyUI/team/NewFight/lb_battlefield_number_flash.dds",Vector4(0, 0, 0, 0),Vector4(0, 0, 0.25, 1)))
	-- battle_time_ui.Cctr_flash_Bg:AddFrame(Gui.Image("LobbyUI/team/NewFight/lb_battlefield_number_flash.dds",Vector4(0, 0, 0, 0),Vector4(0.25, 0, 0.5, 1)))
	-- battle_time_ui.Cctr_flash_Bg:AddFrame(Gui.Image("LobbyUI/team/NewFight/lb_battlefield_number_flash.dds",Vector4(0, 0, 0, 0),Vector4(0.5, 0, 0.75, 1)))
	-- battle_time_ui.Cctr_flash_Bg:AddFrame(Gui.Image("LobbyUI/team/NewFight/lb_battlefield_number_flash.dds",Vector4(0, 0, 0, 0),Vector4(0.75, 0, 1, 1)))
end

function HideBattleTime()
	if battle_time_window then
		battle_time_window:Close()
		battle_time_window = nil
	end
end

function ShowQuickBuy()
	quick_buy_window = ModalWindow.GetNew()
	quick_buy_window.root.Size = Vector2(773,421)
	quick_buy_window.screen.AllowEscToExit = false
	quick_buy_ui.root.Parent = quick_buy_window.root
	
	quick_buy_ui.battle_lv.Text = team_ui.team_level2.Text
	quick_buy_ui.exp_font.Size = Vector2(team_ui.exp_font2.Size.y/200*545,19)
	quick_buy_ui.team_exp.Text = team_ui.team_exp2.Text
	if L_Vip.Viplevel == 0 then
		quick_buy_ui.des.Text = ""
	else
		quick_buy_ui.des.Text = "VIP"..L_Vip.Viplevel..lang:GetText("级使用能量块经验增加")..vip_add[L_Vip.Viplevel + 1]..lang:GetText("%;贡献值增加")..vip_add[L_Vip.Viplevel + 1].."%"
	end
	L_LobbyMain.On_Invite_State = false
end

function HideQuickBuy()
	if quick_buy_window then
		quick_buy_window:Close()
		quick_buy_window = nil
		L_LobbyMain.On_Invite_State = true
	end
end

function FillSourceRank(list)
	local ltv = allteam_source_ui.fight_source_rank   
	ltv:DeleteAll()
	local i = 1
	if list then
		for k, v in ipairs(list) do
			local sub_item = ltv:AddItem(ltv.RootItem)
			sub_item.BGSkin = Skin.SourceRankSkin
			sub_item.NeedProjection = false
			sub_item.HighlightTextColor = ARGB(255, 255, 255, 255)
			if k < 4 then
				iconHead = Gui.Icon("LobbyUI/team/lb_squad_number_"..k..".dds")
				sub_item:SetIcon(1, iconHead)
			else
				sub_item:AddSubItem(k)
			end
			sub_item:AddSubItem(nil)
			sub_item:AddSubItem(v[2])
			sub_item:AddSubItem(v[3])
			sub_item:AddSubItem(v[5])
			sub_item:AddSubItem(v[4])
			i = i + 1
		end
	end

	if i < 11 then
		local j 
		for j = i ,10 do
			local sub_item = ltv:AddItem(ltv.RootItem)
			sub_item.CanSelect = false
			sub_item.ID = -1
			sub_item.BGSkin = Skin.SourceRankSkin
		end
	end	
end

function FillZhanduiList()
	rpc.safecall("team_member_list", {tid = t_id, page = -1},
	function(data)
		local member = data.team.member
		local ltv = fightteam_fight_ui.Fight_Team_Player_List   
		ltv:DeleteAll()
		local i = 1
		if member then
			for k, v in ipairs(member) do 
				if v[4] ~= L_LobbyMain.PersonalInfo_data.name then
					if v[5] == 1 then
						local sub_item = ltv:AddItem(ltv.RootItem)
						sub_item:AddSubItem(nil)
						sub_item:AddSubItem(nil)
						sub_item:AddSubItem(nil)
						if v[18] ~= "" then
							iconHead = Gui.Icon("LobbyUI/persionalInfo/HeadPic/lb_battlefield_icon"..v[18]..".dds")
						end
						
						if iconHead == nil then
							iconHead = Gui.Icon("LobbyUI/persionalInfo/HeadPic/lb_battlefield_icon01_b.dds")
						end
						sub_item:SetIcon(1, iconHead)
						
						L_WarZone.FillLevel(v[3], v[11], sub_item)
						sub_item:AddSubItem(v[4])
						sub_item.NAME = v[4]
						-- if v[5] == 1 then
							-- sub_item.SpecialA = false
						-- else
							-- sub_item.SpecialA = true
							-- sub_item:SetSubItemColor(4, ARGB(255,114,111,108))	
						-- end
						for i = 1,invite_index do
							if invite_player[i] == sub_item.NAME then
								sub_item.Invite_BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_select_ico.dds",Vector4(0, 0, 0, 0))
								sub_item.Invite_localtion = Vector2(215,10)
								sub_item.Invite_Size = Vector2(20,16)
								break
							end
						end
						
						local num = 5
						sub_item.LV_BackgroundImage = Gui.Image("LobbyUI/lv"..(math.floor((v[3] - 1)/num)*num+1).."-"..(math.ceil(v[3]/num)*num)..".dds", Vector4(0, 0, 0, 0), Vector4(0, 0, 1, 1))
						sub_item.LV_localtion = Vector2(51,0)
						sub_item.LV_Size = Vector2(36,33)
						if i % 2 == 1 then
							sub_item.BGSkin = Skin.ListItemSkin_Single
						else
							sub_item.BGSkin = Skin.ListItemSkin_Double
						end
						i = i + 1
					end	
				end
			end
		end

		if i < 16 then
			local j 
			for j = i ,15 do
				local sub_item = ltv:AddItem(ltv.RootItem)
				sub_item.CanSelect = false
				sub_item.ID = -1
				if j % 2 == 1 then
					sub_item.BGSkin = Skin.ListItemSkin_Single
				else
					sub_item.BGSkin = Skin.ListItemSkin_Double
				end
			end
		end	
	end)	
end

function FillZhanduiRoom()
	local ltv = fightteam_fight_ui.Fight_Team_Room_Player 
	local flag = true	
	ltv:DeleteAll()
	local i = 1
	local state = ptr_cast(game.CurrentState)
	my_battle_info = state.b_player_info
	if my_battle_info.ownerclient_uid == state:GetUserId() then
		battle_host_id = my_battle_info.ownerclient_uid
		fightteam_fight_ui.b_pipei.Text = lang:GetText("匹配对手")
		-- fightteam_fight_ui.b_tiaozhan.Enable = true
		fightteam_fight_ui.b_yaoqing.Visible = true
	else
		if not battle_ready then
			fightteam_fight_ui.b_pipei.Text = lang:GetText("准备")
		else
			fightteam_fight_ui.b_pipei.Text = lang:GetText("取消准备")
		end
		-- fightteam_fight_ui.b_tiaozhan.Enable = false
		fightteam_fight_ui.b_yaoqing.Visible = false
	end
	-- fightteam_fight_ui.b_exit.Enable = true
	
	for j = 1,6 do
		local client_info = state:GetBattlePlayerInfo(j-1)
		if client_info.character_level ~= 0 then
			if client_info.is_ready ~= 1 then
				flag = false
				break
			end
		else
			flag = false
			break
		end
	end
	
	if fightteam_fight_ui.b_pipei.Text == lang:GetText("匹配对手") then
		fightteam_fight_ui.b_pipei.Enable = flag
		-- fightteam_fight_ui.b_tiaozhan.Enable = flag
	else
		fightteam_fight_ui.b_pipei.Enable = true
	end

	for j = 1,6 do
		local client_info = state:GetBattlePlayerInfo(j-1)
		battle_all_player_info[j] = client_info
		if client_info.character_level ~= 0 then
			local sub_item = ltv:AddItem(ltv.RootItem,"")
			if j % 2 == 1 then
				sub_item.BGSkin = Skin.ListItemSkin_Single_Black
			else
				sub_item.BGSkin = Skin.ListItemSkin_Double_Black
			end
			local status = ""
			local name = ""
			local iconVip = nil
			local iconN = nil
			local iconA = nil
			local iconH = nil
			local iconHead = nil
			local icon2,icon1 = nil,nil
			local isVip = client_info.is_vip
			print("isVip = ",isVip)
			local CardId = -1
			if client_info then	
				CardId = client_info.business_card
			end
			L_WarZone.LoadCard(sub_item,1,j,CardId)
			-- if isVip == 1 then
				-- iconVip = Icons.PlayerStatusIcons["Vip"]
			-- elseif isVip == 2 then
				-- iconVip = Icons.PlayerStatusIcons["XunLeiVip"]
			-- end
			
			if isVip > 0 then
				iconVip = Gui.Icon("LobbyUI/vip/vip/VIP_button_0"..isVip.."_normalred.dds")
			end
			
			if client_info.head_icon ~= "" then
				iconHead = Gui.Icon("LobbyUI/persionalInfo/HeadPic/lb_battlefield_icon"..client_info.head_icon..".dds")
			end
			
			if iconHead == nil then
				iconHead = Gui.Icon("LobbyUI/persionalInfo/HeadPic/lb_battlefield_icon01_b.dds")
			end
			
			--iconHead = Icons.PlayerStatusIcons["Head"]
			print("client_info.is_ready:"..client_info.is_ready)
			if client_info.is_ready == 2 then
				iconN = Icons.PlayerStatusIcons["PlayingC"]
				iconA = Icons.PlayerStatusIcons["PlayingC"]
			elseif client_info.is_ready == 1 then
				iconN = Icons.PlayerStatusIcons["ReadyN"]
				iconA = Icons.PlayerStatusIcons["ReadyA"]
			end
			if client_info.client_uid == state.b_player_info.ownerclient_uid then
				iconN = Icons.PlayerStatusIcons["Host"]
				iconA = Icons.PlayerStatusIcons["Host"]
			end
			name = client_info.character_name
			sub_item:SetIcon(0, iconVip)
			sub_item:SetIcon(1, iconHead)
			sub_item:SetText(4, name)
			sub_item:SetIcon(5, iconN)
			sub_item:SetHoverIcon(5, iconA)
			L_WarZone.FillLevel(client_info.character_level, client_info.character_exp, sub_item)
			
			local num = 5
			sub_item.LV_BackgroundImage = Gui.Image("LobbyUI/lv"..(math.floor((client_info.character_level - 1)/num)*num+1).."-"..(math.ceil(client_info.character_level/num)*num)..".dds", Vector4(0, 0, 0, 0), Vector4(0, 0, 1, 1))
			sub_item.LV_localtion = Vector2(84,0)
			sub_item.LV_Size = Vector2(46,42)
			-- sub_item.CheckVisible = false
			i = i + 1
		end
	end

	if i < 7 then
		local j 
		for j = i ,6 do
			local sub_item = ltv:AddItem(ltv.RootItem)
			sub_item.CanSelect = false
			sub_item.ID = -1
			if j % 2 == 1 then
				sub_item.BGSkin = Skin.ListItemSkin_Single_Black
			else
				sub_item.BGSkin = Skin.ListItemSkin_Double_Black
			end
		end
	end		
end

function FillVS(data)
	VS.t1_name.Text = data.teama[2]
	VS.t2_name.Text = data.teamb[2]
	VS.t1_lv.Text = "Lv."..data.teama[4]
	VS.t2_lv.Text = "Lv."..data.teamb[4]
	VS.t1_icon.Skin = Gui.ControlSkin
	{
		BackgroundImage = Gui.Image("LobbyUI/team/FightHead/lb_squad_touxiang_"..data.teama[3]..".dds", Vector4(0, 0, 0, 0)),
	}
	VS.t2_icon.Skin = Gui.ControlSkin
	{
		BackgroundImage = Gui.Image("LobbyUI/team/FightHead/lb_squad_touxiang_"..data.teamb[3]..".dds", Vector4(0, 0, 0, 0)),
	}
	HideBattleTime()
	VS_ui = ModalWindow.GetNew()
	VS_ui.root.Size = Vector2(631, 256)
	VS_ui.screen.AllowEscToExit = false
	VS.root.Parent = VS_ui.root
	VS.shenji_1:CleanAll()
	VS.shenji_1:AddTime(8)
end

function FillThreeZhanduiRoom(index, flag)
	local ltv = zhihuisuo_ui["Fight_Team_Room_Player"..index]
	ltv:DeleteAll()
	local i = 1
	local host_name = nil
	local show_roomoption = false
	local player_enough = true
	local is_playing = false
	for j = 1,6 do
		local client_info = three_battle_player_info[index][j]
		if client_info and client_info.character_level and client_info.character_level ~= 0 and flag then
			local sub_item = ltv:AddItem(ltv.RootItem,"")
			if j % 2 == 1 then
				sub_item.BGSkin = Skin.ListItemSkin_Single_Black
			else
				sub_item.BGSkin = Skin.ListItemSkin_Double_Black
			end
			local status = ""
			local name = ""
			local iconVip = nil
			local iconN = nil
			local iconA = nil
			local iconH = nil
			local iconHead = nil
			local icon2,icon1 = nil,nil
			local isVip = client_info.is_vip
			local CardId = -1
			if client_info then	
				CardId = client_info.business_card
			end
			print("isVip = ",isVip)
			L_WarZone.LoadCard(sub_item,1,j,CardId)
			-- if isVip == 1 then
				-- iconVip = Icons.PlayerStatusIcons["Vip"]
			-- elseif isVip == 2 then
				-- iconVip = Icons.PlayerStatusIcons["XunLeiVip"]
			-- end
			if isVip > 0 then
				iconVip = Gui.Icon("LobbyUI/vip/vip/VIP_button_0"..isVip.."_normalred.dds")
			end
			
			if client_info.head_icon ~= "" then
				iconHead = Gui.Icon("LobbyUI/persionalInfo/HeadPic/lb_battlefield_icon"..client_info.head_icon..".dds")
			end
			
			if iconHead == nil then
				iconHead = Gui.Icon("LobbyUI/persionalInfo/HeadPic/lb_battlefield_icon01_b.dds")
			end
			if client_info.is_ready == 2 then
				iconN = Icons.PlayerStatusIcons["PlayingC"]
				iconA = Icons.PlayerStatusIcons["PlayingC"]
				show_roomoption = true
				is_playing = true
			elseif client_info.is_ready == 1 then
				iconN = Icons.PlayerStatusIcons["ReadyN"]
				iconA = Icons.PlayerStatusIcons["ReadyA"]
			end
			if client_info.client_uid == three_battle_info[index].ownerclient_uid then
				iconN = Icons.PlayerStatusIcons["Host"]
				iconA = Icons.PlayerStatusIcons["Host"]
				host_name = client_info.character_name
			end
			name = client_info.character_name
			sub_item:SetIcon(0, iconVip)
			sub_item:SetIcon(1, iconHead)
			sub_item:SetText(4, name)
			sub_item:SetIcon(5, iconN)
			sub_item:SetHoverIcon(5, iconA)
			L_WarZone.FillLevel(client_info.character_level, client_info.character_exp, sub_item)
			
			local num = 5
			sub_item.LV_BackgroundImage = Gui.Image("LobbyUI/lv"..(math.floor((client_info.character_level - 1)/num)*num+1).."-"..(math.ceil(client_info.character_level/num)*num)..".dds", Vector4(0, 0, 0, 0), Vector4(0, 0, 1, 1))
			sub_item.LV_localtion = Vector2(99,0)
			sub_item.LV_Size = Vector2(46,42)
			-- sub_item.CheckVisible = false
			i = i + 1
		else
			player_enough = false
		end
	end
	
	if is_playing or player_enough then
		zhihuisuo_ui["b_join"..index].Enable = false
	end
	
	if three_battle_info[index].roomoption and show_roomoption then
		zhihuisuo_ui["vs_fightname"..index].Text = three_battle_info[index].vs_group_name
		zhihuisuo_ui[("host_name"..index)].Text = host_name
		zhihuisuo_ui[("auto_begin"..index)].Text = lang:GetText("关")
		zhihuisuo_ui[("war_balance"..index)].Text = lang:GetText("关")
		zhihuisuo_ui[("special_job"..index)].Text = lang:GetText("全部")
		if three_battle_info[index].roomoption.game_type == "kTeam" or three_battle_info[index].roomoption.game_type == "kKnife" then
			zhihuisuo_ui[("win"..index)].Text = three_battle_info[index].roomoption.rule_value .. lang:GetText("人")
		else
			zhihuisuo_ui[("win"..index)].Text = three_battle_info[index].roomoption.rule_value .. lang:GetText("回合")
		end
		zhihuisuo_ui[("fuhuo_time"..index)].Text = three_battle_info[index].roomoption.round_rebirth_time_max
		zhihuisuo_ui[("can_join"..index)].Text = lang:GetText("关")
		zhihuisuo_ui[("game_mode"..index)].Text = game_type_table[three_battle_info[index].roomoption.game_type]
		zhihuisuo_ui[("map_name"..index)].Skin = Gui.ControlSkin{BackgroundImage = L_WarZone.FindMapIcon(three_battle_info[index].roomoption.map_name).Icon_out,}
	else
		zhihuisuo_ui["vs_fightname"..index].Text = "????"
		zhihuisuo_ui[("host_name"..index)].Text = "????"
		zhihuisuo_ui[("auto_begin"..index)].Text = "????"
		zhihuisuo_ui[("war_balance"..index)].Text = "????"
		zhihuisuo_ui[("special_job"..index)].Text = "????"
		zhihuisuo_ui[("win"..index)].Text = "????"
		zhihuisuo_ui[("fuhuo_time"..index)].Text = "????"
		zhihuisuo_ui[("can_join"..index)].Text = "????"
		zhihuisuo_ui[("game_mode"..index)].Text = "????"
		zhihuisuo_ui[("map_name"..index)].Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_battlefield_map_random_b.dds", Vector4(0, 0, 0, 0)),}
	end		

	if i < 7 then
		local j 
		for j = i ,6 do
			local sub_item = ltv:AddItem(ltv.RootItem)
			sub_item.CanSelect = false
			sub_item.ID = -1
			if j % 2 == 1 then
				sub_item.BGSkin = Skin.ListItemSkin_Single_Black
			else
				sub_item.BGSkin = Skin.ListItemSkin_Double_Black
			end
		end
	end		
end

function InitialShowTeamInfoBTN()
	local ibbtn = tiaozhan_ui.btn_info_1
	ibbtn.Visible = false
	ibbtn.Location = Vector2(320, 10)
	for i = 2, 7 do
		if ibbtn then
			ibbtn = ibbtn.Next
			ibbtn.Visible = false
			ibbtn.Location = Vector2(320, 10 + (i - 1)*56)
		end
	end
end

function FillTiaoZhan()
	local ltv = tiaozhan_ui.TiaoZhan_Fight_Team   
	ltv:DeleteAll()
	local num = 1
	local ibbtn = tiaozhan_ui.btn_info_1
	print("state.zhihuisuo_num:"..state.zhihuisuo_num)
	for i = 1 , state.zhihuisuo_num - 1 do 
		local sub_item = ltv:AddItem(ltv.RootItem)
		if i % 2 == 1 then
			sub_item.BGSkin = Skin.ListItemSkin_Single
		else
			sub_item.BGSkin = Skin.ListItemSkin_Double
		end
		sub_item:AddSubItem(nil)
		sub_item:AddSubItem("LV"..tiaozhan_battle_info[i].group_level)
		sub_item:AddSubItem(tiaozhan_battle_info[i].group_name)
		sub_item.ID = tiaozhan_battle_info[i].battlegroup_id
		sub_item.NAME = tiaozhan_battle_info[i].battlegroup_id
		num = num + 1
		if ibbtn then
			ibbtn.Visible = true
			ibbtn = ibbtn.Next
		end
	end

	if num < 8 then
		local j 
		for j = num ,7 do
			local sub_item = ltv:AddItem(ltv.RootItem)
			sub_item.CanSelect = false
			sub_item.ID = -1
			if j % 2 == 1 then
				sub_item.BGSkin = Skin.ListItemSkin_Single
			else
				sub_item.BGSkin = Skin.ListItemSkin_Double
			end
			if ibbtn then
				ibbtn.Visible = false
				ibbtn = ibbtn.Next
			end
		end
	end
end

function SetupTeam(parent_win)
	team_list_ui.root.Parent = team_ui.root  
	team_list_ui.root.Location = Vector2(0, 0)
	allteam_source_ui.root.Parent = team_ui.root
	allteam_source_ui.root.Location = Vector2(0, 0)
	for i = 1 , 15 do
		if i == 1 then
			allteam_source_ui["l_teamname"..i].TextColor = ARGB(255,255,210,0)
			allteam_source_ui["l_teamname"..i].FontSize = 20
			allteam_source_ui["l_teamname_black"..i].FontSize = 20
			allteam_source_ui["b_source_rank"..i].Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_diyi.dds", Vector4(0, 0, 0, 0)),}
			allteam_source_ui["b_source_rank"..i].Visible = true
		elseif i == 2 then
			allteam_source_ui["l_teamname"..i].TextColor = ARGB(255,217,248,255)
			allteam_source_ui["l_teamname"..i].FontSize = 16
			allteam_source_ui["l_teamname_black"..i].FontSize = 16
			allteam_source_ui["b_source_rank"..i].Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_dier.dds", Vector4(0, 0, 0, 0)),}
			allteam_source_ui["b_source_rank"..i].Visible = true
		elseif i == 3 then
			allteam_source_ui["l_teamname"..i].TextColor = ARGB(255,255,190,114)
			allteam_source_ui["l_teamname"..i].FontSize = 16
			allteam_source_ui["l_teamname_black"..i].FontSize = 16
			allteam_source_ui["b_source_rank"..i].Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_disan.dds", Vector4(0, 0, 0, 0)),}
			allteam_source_ui["b_source_rank"..i].Visible = true
		end
		allteam_source_ui["source_tiaozhan_team"..i].Location = Vector2(Rank_Source_Btn_Location[i][1], Rank_Source_Btn_Location[i][2])
	end	
	local sourcelist = allteam_source_ui.fight_source_rank
	sourcelist:DeleteColumns()
	sourcelist:AddColumn("",1, "kAlignCenterMiddle")
	sourcelist:AddColumn("",75, "kAlignCenterMiddle")
	sourcelist:AddColumn("",30, "kAlignCenterMiddle")
	sourcelist:AddColumn("",200, "kAlignLeftMiddle")
	sourcelist:AddColumn("",200, "kAlignCenterMiddle")
	sourcelist:AddColumn("",200, "kAlignCenterMiddle")
	sourcelist:AddColumn("",200, "kAlignRightMiddle")
	
	my_source_ui.root.Parent = team_ui.root
	my_source_ui.root.Location = Vector2(0, 0)
	my_source_shop.root.Parent = team_ui.root
	my_source_shop.root.Location = Vector2(0, 0)
	local cbx = team_ui.p_info
	cbx:DeleteAll()
	cbx:AddColumn("",34, "kAlignRightMiddle")
	cbx:AddColumn("",25, "kAlignRightMiddle")
	cbx:AddColumn("",25, "kAlignLeftMiddle")
	cbx:AddColumn(lang:GetText("战队成员"),121, "kAlignLeftMiddle")
	cbx:AddColumn("",42, "kAlignCenterMiddle")
	cbx:AddColumn(lang:GetText("队内等级"),108, "kAlignCenterMiddle")
	cbx:AddColumn(lang:GetText("贡献度"),86, "kAlignCenterMiddle")
	cbx:AddColumn(lang:GetText("战队战场次"),120, "kAlignCenterMiddle")
	cbx:AddColumn(lang:GetText("综合战斗力"),102, "kAlignCenterMiddle")
	cbx:AddColumn(lang:GetText("积分"),83, "kAlignCenterMiddle")
	cbx:AddColumn(lang:GetText("击杀/死亡"),104, "kAlignCenterMiddle")
	cbx:AddColumn(lang:GetText("助攻"),64, "kAlignCenterMiddle")
	cbx:AddColumn(lang:GetText("加入时间"),140, "kAlignCenterMiddle")
	
	-- team_ui.re_msg_1:CleanAll()
	-- team_ui.re_msg_1:AddMsg(lang:GetText("达到"),ARGB(255, 255, 187, 0),true,false)
	-- team_ui.re_msg_1:AddMsg(lang:GetText("20级"),ARGB(255, 255, 103, 1),false,false)
	-- team_ui.re_msg_1:AddMsg(lang:GetText("的玩家可以创建战队"),ARGB(255, 255, 187, 0),false,false)

	-- team_ui.re_msg_2:CleanAll()
	-- team_ui.re_msg_2:AddMsg(lang:GetText("创建战队需要消耗"),ARGB(255, 255, 187, 0),true,false)
	-- team_ui.re_msg_2:AddMsg(lang:GetText("10000C币"),ARGB(255, 255, 103, 1),false,false)
	-- team_ui.re_msg_2:AddMsg(lang:GetText("能量"),ARGB(255, 255, 187, 0),false,false)
	-- FillTeam()
	team_ui.root.Parent = parent_win

end


---------- tian ↓ -------------------------------------------------
--刷新战队资源站的界面的info
function updataTeamInfo(c_Page,s_Type)
	rpc.safecallload("get_team_war", {playerId = ptr_cast(game.CurrentState):GetCharacterId(),teamId = t_id,storageType = s_Type,curPage = c_Page},
	function(data)
		TeamWar_info = nil
		TeamWar_info = data.teamResourceWar
		allteam_source_ui.placeLevel.Text = TeamWar_info.placeLevel
		L_LobbyMain.ShowFightnums(allteam_source_ui.placeLevel,tonumber(TeamWar_info.placeLevel),"team/lb_squad_number_01.dds")
		allteam_source_ui.canPower.Text = TeamWar_info.resoucesNum
		allteam_source_ui.canFC.Text = TeamWar_info.fc
		-- if TeamWar_info.time and TeamWar_info.time > 0 then
			-- UpdateTimeLable(allteam_source_ui.team_ctrlTimer,TeamWar_info.time,allteam_source_ui.team_time_lb)
			-- allteam_source_ui.team_ctrlTimer.EventTimeOut = function(sender, e)
				-- updataTeamInfo(1,s_Type)
			-- end
		-- else
			-- allteam_source_ui.team_time_lb.Text = GethourMinuteSeconds(0)
		-- end	
		isTeamLeader = (TeamWar_info.isLeader == 1) and true or false
		if isTeamLeader then
			allteam_source_ui.editTeam.Enable = true
		else
			allteam_source_ui.editTeam.Enable = false
		end
		print("storageIndex~~~",storageIndex)
		SelectedPageStorage(storageIndex,TeamWar_info)
		--ShowStorageTowerUI(TeamWar_info)
	end)
	
end

function FillMyTeamSource_ui()
	allteam_source_ui.showStorage_btn.PushDown = true
	allteam_source_ui.showTree_btn.PushDown = false
	allteam_source_ui.E.Visible = true
	allteam_source_ui.C.Visible = false
	allteam_source_ui.tpd_storage.Index = 0
	allteam_source_ui.tpd_Tree.Index = 0
	cType = 2
	tType = 2
	nIdx = 0
	GridTipsUI.tpd_nengli.Index = 0
	initIdx()
	updataTeamInfo(1,cType)
end

--刷新个人资源站的界面的info
function updataPersonalInfo(c_Page,sType)
	rpc.safecallload("get_personal_place", {playerId = ptr_cast(game.CurrentState):GetCharacterId(),teamId = t_id,storageType = sType,curPage = c_Page},
	function(data)
		Personal_info = nil
		Personal_info = data.teamResourceWar
		allteam_source_ui.s_canPower.Text = Personal_info.resoucesNum
		allteam_source_ui.s_canFC.Text = Personal_info.fc
		if data.teamResourceWar.teamStorage.tank then
			ShowPersonalStorageTankUI(data.teamResourceWar.teamStorage.tank)
		elseif data.teamResourceWar.teamStorage.buff then
			ShowPersonalStorageBuffUI(Personal_info)
		else
			print("meiyou")
		end
	end)
	
end
function FillPersonalSource_ui()
	allteam_source_ui.s_showStorage_btn.PushDown = true
	allteam_source_ui.s_showTree_btn.PushDown = false
	allteam_source_ui.s_storage.Visible = true
	allteam_source_ui.s_tree.Visible = false
	allteam_source_ui.s_storage_tank.Visible = true
	allteam_source_ui.s_storage_buff.Visible = false
	allteam_source_ui.btn_s_tank.PushDown = true
	allteam_source_ui.btn_s_buff.PushDown = false
	GridPersonalTipsUI.tpd_P_nengli.Index = 0
	buff_cPage = 1
	pIdx = 0
	initIdx()
	updataPersonalInfo(buff_cPage,3)
end
--刷新战队建设天赋树界面的info
-----param---------
-- int playerId,
-- int teamId,
-- int treeType,//防御类1,攻击类2,消耗类3
function updataTreeInfo(t_Type)
	rpc.safecallload("get_tree_item", {playerId = ptr_cast(game.CurrentState):GetCharacterId(),teamId = t_id,treeType = t_Type},
	function(data)
		if data.attack then
			TreeInfo[1] = data.attack
			SelectedPageTree(0,data.attack)
		elseif data.wall then
			TreeInfo[2] = data.wall
			SelectedPageTree(1,data.wall)
		elseif data.machine then
			TreeInfo[3] = data.machine
			SelectedPageTree(2,data.machine)
		elseif data.tank then
			TreeInfo[4] = data.tank
			FillTankTree(data.tank)
		else
			TreeInfo = {{},{},{},{}}
			print("空列表！！！")
		end
	end)
	
end
function FillTankTree(tankInfo)
	if tankInfo then
		for i = 1,3,1 do
			local ibbtn = ptr_cast(allteam_source_ui.ctrl_P_tree:GetChildByIndex(i-1))
			if tankInfo[i] then
				ibbtn.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..tankInfo[i].name..".tga")
				ibbtn.Hint = tankInfo[i].level.." "..lang:GetText("星").." "..tankInfo[i].display
				if tankInfo[i].isLight == 0 then
					ibbtn.ItemIcon.alpha = 70
				else
					ibbtn.ItemIcon.alpha = 255
				end
				if i == selected_ibtn_index8 then
					ibbtn.Selected = true
				else
					ibbtn.Selected = false
				end			
				FillGrids_PersonalTips(tankInfo[selected_ibtn_index8],isP_Tree,false)
				ibbtn.EventSelected = function(sender, e)
					if allteam_source_ui and sender.Loading == false then
						for j = 1, 3 do	
							local ib = ptr_cast(allteam_source_ui.ctrl_P_tree:GetChildByIndex(j - 1))
							if j == i then
								ib.Selected = true
								--TreeUI.lihe_btn.Enable = true
								selected_ibtn_index8 = j
								FillGrids_PersonalTips(tankInfo[j],isP_Tree,false)
							else
								ib.Selected = false
							end
						end
					end		
					--selected_ibtn_index = index
				end
				allteam_source_ui["P_lv_crtl"..i].Visible = true
				allteam_source_ui["P_Level_T_"..i].Skin = Skin.itemLevelIcon[tonumber(tankInfo[i].level)]
				--TreeUI["Level_T_"..i].Text = "LV." .. treeInfo[i].level
				--ibbtn.Selected = false
				ibbtn.Enable = true
			else
				allteam_source_ui["P_lv_crtl"..i].Visible = false
				ibbtn.ItemIcon = nil
				ibbtn.Enable = false
			end			
		end
	end
end
--创建每个配置的节点，有多少自动创建
local RootHeight = 46
local function CreateDeploiedNode(parent,tb)
	local ret = Gui.Create(parent)
	{
		Gui.Control "root"
		{
			Dock = "kDockTop",
			--Size = Vector2(0,35 + num*hei),
			Margin = Vector4(4,1,0,1),
			Size = Vector2(0,RootHeight-2),
			BackgroundColor = ARGB(255, 40, 51, 78),
				
			Gui.Control "show_icon"
			{
				Size = Vector2(46,45),
				Location = Vector2(0,0),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ibt_icon/"..tb.resource..".tga",Vector4(0, 0, 0, 0)),
				},
			},
			Gui.TextArea "name_lab"
			{
				Size = Vector2(103,32),
				Location = Vector2(52,7),
				TextColor = ARGB(255,130, 255, 150),
				FontSize = 14,
				Readonly = true,
				TextPadding = Vector4(0,0,0,0),
				Text = tb.name,
				Fold = true,
				--BackgroundColor = ARGB(255,255,255,255),
			},
			Gui.Label
			{
				Size = Vector2(38, 14),
				Location = Vector2(166, 15),
				Text = (tb.curNum and tb.curNum or 0) .."/" .. tb.maxNum,
				BackgroundColor = ARGB(0, 255, 255, 255),
				TextAlign = "kAlignLeftTop",
				FontSize = 14,
				TextColor = ARGB(255, 255, 255, 255),
			},		
		},
	}

	return ret
end

local function CreateNextDeployNode(parent,tb)
	local ret = Gui.Create(parent)
	{
		Gui.Control "root"
		{
			Dock = "kDockTop",
			--Size = Vector2(0,35 + num*hei),
			Margin = Vector4(4,1,0,1),
			Size = Vector2(0,RootHeight-2),
			BackgroundColor = ARGB(255, 40, 51, 78),
				
			Gui.Control "show_icon"
			{
				Size = Vector2(46,45),
				Location = Vector2(0,0),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ibt_icon/"..tb.resource..".tga",Vector4(0, 0, 0, 0)),
				},
			},
			Gui.TextArea "name_lab"
			{
				Size = Vector2(103,32),
				Location = Vector2(52,7),
				TextColor = ARGB(255, 130, 255, 150),
				FontSize = 14,
				Readonly = true,
				TextPadding = Vector4(0,0,0,0),
				Text = tb.name,
				Fold = true,
				--BackgroundColor = ARGB(255,255,255,255),
			},
			Gui.Label
			{
				Size = Vector2(46, 14),
				Location = Vector2(166, 15),
				Text = (tb.curMaxNum and tb.curMaxNum or 0) .."→" .. tb.maxNum,
				BackgroundColor = ARGB(0, 255, 255, 255),
				TextAlign = "kAlignLeftTop",
				FontSize = 14,
				TextColor = ARGB(255, 255, 255, 255),
			},		
		},
	}

	return ret
end

--天赋树区域ui
TreeUI = Gui.Create()
{
   Gui.Control "Tree_tower_list"--天赋树区域防御塔的显示
    {
        --Size = Vector2(548,307),
        --Padding = Vector4(5,5,5,5),	
        Dock = "kDockFill",
        Gui.Control "ctrl_1"
        {
            Size = Vector2(0,286),
			Margin = Vector4(0,0,0,0),
            Dock = "kDockTop",
            BackgroundColor = ARGB(255,255,255,255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_bg_02.dds",Vector4(10, 10, 2, 2)),
			},
			Gui.Label 
			{
				Size = Vector2(468, 50),
				Location = Vector2(0,10),
				TextAlign = "kAlignCenterMiddle",
				Text = lang:GetText("全属性升级到LV30以后\n开放下一层科技"),
				FontSize = 16,
				TextColor = ARGB(255, 255, 210, 0),
				
			},
			Gui.Control 
			{
				Size = Vector2(274,235),
				Location = Vector2(47,39),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/lb_kejishu_bg.dds",Vector4(0, 0, 0, 0)),
				},
			},
			Gui.Control "line_h1"
			{
				Size = Vector2(2,163),
				Location = Vector2(77,60),
				BackgroundColor = ARGB(255,108,130,179),
			},
			Gui.Control "line_w1"
			{
				Size = Vector2(229,2),
				Location = Vector2(77,112),
				BackgroundColor = ARGB(255,108,130,179),
			},
			Gui.Control "line_w2"
			{
				Size = Vector2(229,2),
				Location = Vector2(77,201),
				BackgroundColor = ARGB(255,108,130,179),
			},
			Gui.Control "ctrl_tree"
			{
				Dock = "kDockFill",
				BackgroundColor = ARGB(0,255,255,255),
				CreateTreeListGrids(47,39,1),
				CreateTreeListGrids(47,128,2),
				CreateTreeListGrids(47,217,3),
				CreateTreeListGrids(129,83,4),
				CreateTreeListGrids(200,83,5),
				CreateTreeListGrids(271,83,6),
				CreateTreeListGrids(129,172,7),
				CreateTreeListGrids(200,172,8),
				CreateTreeListGrids(271,172,9),
			},		
        },
    },
    
    Gui.Control "Tree_wall_list"--天赋树区域城墙的显示
    {
        --Size = Vector2(469,266),
        --Padding = Vector4(5,5,0,3),
        Dock = "kDockFill",
        Gui.Control "ctrl_2"
        {
            Size = Vector2(0,286),
			Margin = Vector4(0,0,0,0),
            Dock = "kDockTop",
            BackgroundColor = ARGB(255,255,255,255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_bg_02.dds",Vector4(10, 10, 2, 2)),
			},
			Gui.Label 
			{
				Size = Vector2(468, 50),
				Location = Vector2(0,10),
				TextAlign = "kAlignCenterMiddle",
				Text = lang:GetText("属性升级到LV10以后开放下一层科技"),
				FontSize = 16,
				TextColor = ARGB(255, 255, 210, 0),
			},
			Gui.Control 
			{
				Size = Vector2(274,235),
				Location = Vector2(47,39),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/lb_kejishu_bg01.dds",Vector4(0, 0, 0, 0)),
				},
				Gui.Control "line_w3"
				{
					Size = Vector2(142,2),
					Location = Vector2(66,117),
					BackgroundColor = ARGB(255,108,130,179),
				},
				Gui.Control "ctrl_wall_tree"
				{
					Dock = "kDockFill",
					BackgroundColor = ARGB(0,255,255,255),
					CreateTreeWallListGrids(36,88,1),
					CreateTreeWallListGrids(107,88,2),
					CreateTreeWallListGrids(178,88,3),
				},	
			},	
				
        },
       
    },
	Gui.Control "Tree_daoju_list"--天赋树区域挖掘机的显示
    {
        --Size = Vector2(469,266),
        --Padding = Vector4(5,5,0,3),
        Dock = "kDockFill",
        Gui.Control "ctrl_3"
        {
            Size = Vector2(0,286),
			Margin = Vector4(0,0,0,0),
            Dock = "kDockTop",
            BackgroundColor = ARGB(255,255,255,255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_bg_02.dds",Vector4(10, 10, 2, 2)),
			},
			Gui.Label 
			{
				Size = Vector2(359, 16),
				Location = Vector2(25,10),
				Text = lang:GetText(""),
				FontSize = 16,
				TextColor = ARGB(255, 255, 210, 0),
				TextAlign = "kAlignLeftMiddle",
			},
			Gui.Control 
			{
				Size = Vector2(274,235),
				Location = Vector2(47,39),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/lb_kejishu_bg03.dds",Vector4(0, 0, 0, 0)),
				},
				Gui.Control "line_w4"
				{
					Size = Vector2(142,2),
					Location = Vector2(66,117),
					BackgroundColor = ARGB(255,108,130,179),
				},
				Gui.Control "ctrl_machine_tree"
				{
					Dock = "kDockFill",
					BackgroundColor = ARGB(0,255,255,255),
					CreateTreeMachineListGrids(36,88,1),
					CreateTreeMachineListGrids(107,88,2),
					CreateTreeMachineListGrids(178,88,3),
				},	
			},				
        },     
    },
}

--显示天赋树区域的防御塔ui
function ShowTreeTowerUI(parent,treeInfo)
    TreeUI.Tree_tower_list.Visible = true
    TreeUI.Tree_tower_list.Parent = parent
    TreeUI.Tree_wall_list.Visible = false
	TreeUI.Tree_daoju_list.Visible = false
	if treeInfo then
		for i = 1,towerTree,1 do
			local ibbtn = ptr_cast(TreeUI.ctrl_tree:GetChildByIndex(i-1))
			if treeInfo[i] then
				ibbtn.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..treeInfo[i].name..".tga")
				ibbtn.Hint = treeInfo[i].level.." "..lang:GetText("星").." "..treeInfo[i].display
				if treeInfo[i].isLight == 0 then
					ibbtn.ItemIcon.alpha = 70
				else
					ibbtn.ItemIcon.alpha = 255
				end
				if i == selected_ibtn_index5 then
					ibbtn.Selected = true
					FillGridsTree_tips(treeInfo[selected_ibtn_index5])
				else
					ibbtn.Selected = false
				end			
				
				ibbtn.EventSelected = function(sender, e)
					if TreeUI and sender.Loading == false then
						for j = 1, towerTree do	
							local ib = ptr_cast(TreeUI.ctrl_tree:GetChildByIndex(j - 1))
							if j == i then
								ib.Selected = true
								--TreeUI.lihe_btn.Enable = true
								selected_ibtn_index5 = j
								FillGridsTree_tips(treeInfo[j])
							else
								ib.Selected = false
							end
						end
					end		
					--selected_ibtn_index = index
				end
				TreeUI["lv_crtl"..i].Visible = true
				TreeUI["Level_T_"..i].Skin = Skin.itemLevelIcon[tonumber(treeInfo[i].level)]
			
				--TreeUI["Level_T_"..i].Text = "LV." .. treeInfo[i].level
				--ibbtn.Selected = false
				ibbtn.Enable = true
			else
				TreeUI["lv_crtl"..i].Visible = false
				ibbtn.ItemIcon = nil
				ibbtn.Enable = false
			end			
		end
	end   
end

--显示天赋树区域的城墙ui
function ShowTreeWallUI(parent,treeInfo)
	TreeUI.Tree_wall_list.Visible = true
    TreeUI.Tree_wall_list.Parent = parent
    TreeUI.Tree_tower_list.Visible = false	
	TreeUI.Tree_daoju_list.Visible = false

	if treeInfo then
		for i = 1,3,1 do
			local ibbtn = ptr_cast(TreeUI.ctrl_wall_tree:GetChildByIndex(i-1))
			if treeInfo[i] then
				ibbtn.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..treeInfo[i].name..".tga")
				ibbtn.Hint = treeInfo[i].level.." "..lang:GetText("星").." "..treeInfo[i].display
				if treeInfo[i].isLight == 0 then
					ibbtn.ItemIcon.alpha = 70
				else
					ibbtn.ItemIcon.alpha = 255
				end
				if i == selected_ibtn_index6 then
					ibbtn.Selected = true
					FillGridsTree_tips(treeInfo[selected_ibtn_index6])
				else
					ibbtn.Selected = false
				end			
				
				ibbtn.EventSelected = function(sender, e)
					if TreeUI and sender.Loading == false then
						for j = 1, 3 do	
							local ib = ptr_cast(TreeUI.ctrl_wall_tree:GetChildByIndex(j - 1))
							if j == i then
								ib.Selected = true
								--TreeUI.lihe_btn.Enable = true
								selected_ibtn_index6 = j
								FillGridsTree_tips(treeInfo[j])
							else
								ib.Selected = false
							end
						end
					end		
					--selected_ibtn_index = index
				end
				TreeUI["lv_W_crtl"..i].Visible = true
				TreeUI["Level_T_W_"..i].Skin = Skin.itemLevelIcon[tonumber(treeInfo[i].level)]
				--TreeUI["Level_T_"..i].Text = "LV." .. treeInfo[i].level
				--ibbtn.Selected = false
				ibbtn.Enable = true
			else
				TreeUI["lv_W_crtl"..i].Visible = false
				ibbtn.ItemIcon = nil
				ibbtn.Enable = false
			end			
		end
	end
 end
 
--显示天赋树区域的挖掘机ui
function ShowTreeDaojuUI(parent,treeInfo)
	TreeUI.Tree_daoju_list.Visible = true
    TreeUI.Tree_daoju_list.Parent = parent
    TreeUI.Tree_tower_list.Visible = false	
	TreeUI.Tree_wall_list.Visible = false
	
	if treeInfo then
		for i = 1,3,1 do
			local ibbtn = ptr_cast(TreeUI.ctrl_machine_tree:GetChildByIndex(i-1))
			if treeInfo[i] then
				ibbtn.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..treeInfo[i].name..".tga")
				ibbtn.Hint = treeInfo[i].level.." "..lang:GetText("星").." "..treeInfo[i].display
				if treeInfo[i].isLight == 0 then
					ibbtn.ItemIcon.alpha = 70
				else
					ibbtn.ItemIcon.alpha = 255
				end
				if i == selected_ibtn_index7 then
					ibbtn.Selected = true
					FillGridsTree_tips(treeInfo[selected_ibtn_index7])
				else
					ibbtn.Selected = false
				end			
				ibbtn.EventSelected = function(sender, e)
					if TreeUI and sender.Loading == false then
						for j = 1, 3 do	
							local ib = ptr_cast(TreeUI.ctrl_machine_tree:GetChildByIndex(j - 1))
							if j == i then
								ib.Selected = true
								--TreeUI.lihe_btn.Enable = true
								selected_ibtn_index7 = j
								FillGridsTree_tips(treeInfo[j])
							else
								ib.Selected = false
							end
						end
					end		
					--selected_ibtn_index = index
				end
				TreeUI["lv_M_crtl"..i].Visible = true
				TreeUI["Level_T_M_"..i].Skin = Skin.itemLevelIcon[tonumber(treeInfo[i].level)]
				--TreeUI["Level_T_"..i].Text = "LV." .. treeInfo[i].level
				--ibbtn.Selected = false
				ibbtn.Enable = true
			else
				TreeUI["lv_M_crtl"..i].Visible = false
				ibbtn.ItemIcon = nil
				ibbtn.Enable = false
			end			
		end
	end
 end
--战队资源天赋树区域选择
function SelectedPageTree(idx,Tree_info)
	if Tree_info then
		if idx == 0 then
			deployIndex = 0
			ShowTreeTowerUI(allteam_source_ui.tpg_T_tower,Tree_info)
		elseif idx == 1 then
			deployIndex = 1
			ShowTreeWallUI(allteam_source_ui.tpg_T_wall,Tree_info)
		elseif idx == 2 then
			deployIndex = 2
			--ShowTreeDaojuUI(allteam_source_ui.tpg_T_scene,Tree_info)
		end 
	end	
end

--战队资源战天赋树区域选择事件
function onSelectedPageTreeChanged(sender)
	deployIndex = sender.Index
	if deployIndex == 0 then
		tType = 2
	elseif deployIndex == 1 then
		tType = 1
	elseif deployIndex == 2 then
		tType = 5
	end
	updataTreeInfo(tType)
    --SelectedPageTree(sender.Index,Tree_info)
end
allteam_source_ui.tpd_Tree.EventSelectedPageChanged = onSelectedPageTreeChanged

StorageUI = Gui.Create()
{
    Gui.Control "ctrl_tower_list"--防御塔的显示
    {
        --Size = Vector2(548,307),
        --Padding = Vector4(5,5,5,5),	
        Dock = "kDockFill",
        Gui.Control "ctrl_1"
        {
            Size = Vector2(0,286),
			Margin = Vector4(0,0,0,0),
            Dock = "kDockTop",
            BackgroundColor = ARGB(255,255,255,255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_bg_02.dds",Vector4(10, 10, 2, 2)),
			},
			Gui.Control "ctrl_tower"
			{
				Size = Vector2(305,204),
				Location = Vector2(50,36),
				CreateStorageListGrids(0,0,1),
				CreateStorageListGrids(1,0,2),
				CreateStorageListGrids(2,0,3),	                             
								
				CreateStorageListGrids(0,1,4),
				CreateStorageListGrids(1,1,5),
				CreateStorageListGrids(2,1,6),			
			},	
			Gui.Control "ctrl_bottom_container"
			{							
				Size = Vector2(119, 23),
				Location = Vector2(358, 343),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Visible = false,
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button06_bg.dds", Vector4(14, 14, 14, 14)),
				},
				--页码
				Gui.Label "lb_page_number_tower"
				{
					Dock = "kDockFill",
					FontSize = 18,
					TextAlign = "kAlignCenterMiddle",
					TextColor = ARGB(255, 255, 255, 255),
					Text = "1/1",
			
				},
				--上一页
				Gui.Button "btn_front_page_tower"
				{
					Size = Vector2(19, 19),
					--Location = Vector2(281, 9),
					Dock = "kDockLeft",			
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button05_normal.dds", Vector4(0, 0, 0, 0)),
						HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button05_hover.dds", Vector4(0, 0, 0, 0)),
						DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button05_down.dds", Vector4(0, 0, 0, 0)),
						DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button05_normal.dds", Vector4(0, 0, 0, 0)),
					},
					
				},
				

				--下一页
				Gui.Button "btn_next_page_tower"
				{
					Size = Vector2(19, 19),
					--Location = Vector2(400, 9),
					Dock = "kDockRight",
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button06_normal.dds", Vector4(0, 0, 0, 0)),
						HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button06_hover.dds", Vector4(0, 0, 0, 0)),
						DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button06_down.dds", Vector4(0, 0, 0, 0)),
						DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button06_normal.dds", Vector4(0, 0, 0, 0)),
					},
					
				},
			},
			Gui.Button "fixAll_tower"
			{
				Size = Vector2(116,27),
				Location = Vector2(25, 340),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Text = lang:GetText("全部维修"),
				Skin = Skin.TeamBtnSkin,
				Visible = false,
			},
			Gui.Button "fillAll_tower"
			{
				Size = Vector2(116,27),
				Location = Vector2(150, 340),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Text = lang:GetText("全部补给"),
				Skin = Skin.TeamBtnSkin,
				Visible = false,
			},
        },
    },
    
    Gui.Control "ctrl_wall_list"--城墙的显示
    {
        --Size = Vector2(469,266),
        --Padding = Vector4(5,5,0,3),
        Dock = "kDockFill",
        Gui.Control "ctrl_2"
        {
            Size = Vector2(0,286),
			Margin = Vector4(0,0,0,0),
            Dock = "kDockTop",
            BackgroundColor = ARGB(255,255,255,255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_bg_02.dds",Vector4(10, 10, 2, 2)),
			},
			Gui.Control "ctrl_wall"
			{
				Size = Vector2(305,204),
				Location = Vector2(50,36),
				CreateStorageWallListGrids(0,0,1),
				CreateStorageWallListGrids(1,0,2),
				CreateStorageWallListGrids(2,0,3),	                             
								
				CreateStorageWallListGrids(0,1,4),
				CreateStorageWallListGrids(1,1,5),
				CreateStorageWallListGrids(2,1,6),					
			},
			
			Gui.Button "fixAll_wall"
			{
				Size = Vector2(116,27),
				Location = Vector2(25, 340),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Text = lang:GetText("全部维修"),
				Skin = Skin.TeamBtnSkin,
				Visible = false,
			},
			Gui.Button "fillAll_wall"
			{
				Size = Vector2(116,27),
				Location = Vector2(150, 340),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Text = lang:GetText("全部补给"),
				Skin = Skin.TeamBtnSkin,
				Visible = false,
			},
        },
       
    },
	Gui.Control "ctrl_daoju_list"--道具的显示
    {
        --Size = Vector2(469,266),
        --Padding = Vector4(5,5,0,3),
        Dock = "kDockFill",
        Gui.Control "ctrl_3"
        {
            Size = Vector2(0,286),
			Margin = Vector4(0,0,0,0),
            Dock = "kDockTop",
            BackgroundColor = ARGB(255,255,255,255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_bg_02.dds",Vector4(10, 10, 2, 2)),
			},
			Gui.Control "ctrl_daoju"
			{
				Size = Vector2(305,204),
				Location = Vector2(50,36),
				CreateStorageMachineListGrids(0,0,1),
				CreateStorageMachineListGrids(1,0,2),
				CreateStorageMachineListGrids(2,0,3),	                             
								
				CreateStorageMachineListGrids(0,1,4),
				CreateStorageMachineListGrids(1,1,5),
				CreateStorageMachineListGrids(2,1,6),					
			 },
			--[[
			Gui.FlowLayout "gridsAll_daoju"
			{
				--Dock = "kDockFill",
				--BackgroundColor = ARGB(255,100,255,100),
				Size = Vector2(468,279),
				Location = Vector2(40,40),
				--Padding = Vector4(22,27,0,0),
				ControlSpace = 12,
				LineSpace = 19,
				Direction = "kHorizontal",
				ControlAlign = "kAlignLeft",
				Align = "kAlignTop",

				table.unpack(CreateStorageListGrids_daoju())
			},--]]
        },
       
    },
}

function CreateListGrids_nengli()
	local tb = {}
	for i=1,7,1 do
		tb[i] = Gui.Control
		{
			Size = Vector2(285,33),
			BackgroundColor = ARGB(0,255,255,255),
			Gui.Control("Grid_" .. i)
			{
				Dock = "kDockFill",
				Gui.Label ("type_text_"..i)
				{
					Size = Vector2(79, 33),
					Location = Vector2(0,0),
					Text = nengLi_type_Text[i],
					FontSize = 16,
					TextColor = ARGB(255, 255, 255, 255),
					TextAlign = "kAlignCenterMiddle",
				},
				Gui.ProportionBar ("team_nengliExp_"..i)
				{
					Visible = true,
					Size = Vector2(203, 33),
					Location = Vector2(81,0),
					BackgroundColor = ARGB(255,255,255,255),
					--Icon = Gui.ProportionIcon(nil, "LobbyUI/team/lb_squad_jingyan01_bg.dds", nil, Vector4(0,0,8,6) ),	
				},
				Gui.Label ("lb_"..i)
				{
					Size = Vector2(203, 33),
					Location = Vector2(79,0),
					Text = "",
					FontSize = 16,
					TextPadding = Vector4(15,0,0,0),
					TextColor = ARGB(255, 255, 255, 255),
					TextAlign = "kAlignLeftMiddle",
				},
				Gui.Label ("lb_level_"..i)
				{
					Size = Vector2(203, 33),
					Location = Vector2(79,0),
					Text = lang:GetText("80"),
					FontSize = 16,
					TextPadding = Vector4(0,0,15,0),
					TextColor = ARGB(255, 255, 255, 255),
					--TextShadowColor = ARGB(255,0,0,0),
					--TextLightSource = -math.pi/6,
					TextAlign = "kAlignRightMiddle",
				},
				--[[
				Gui.Control ("lv_icon_"..i)
				{
					Size = Vector2(26,11),
					Location = Vector2(203,11),
					BackgroundColor = ARGB(255,255,255,255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_lvmaohao_bg.dds",Vector4(0, 0, 0, 0)),
					},		
				},
				Gui.ChangeControl("change_lb_"..i)
				{
					Size = Vector2(40, 11),
					Location = Vector2(230,11),
					Normsize = Vector2(40, 11),
					NormLocation = Vector2(230,11),
					BackgroundColor = ARGB(0,255,255,255),
					Gui.FlowLayout ("lb_level_"..i)
					{
						Dock = "kDockFill",
						Direction = "kHorizontal",
						Align = "kAlignLeftMiddle",
						ControlAlign = "kAlignCenterMiddle",
						ControlSpace = 0,
					},
				},--]]
			},
						
		}
	end
	return tb
end

function CreateListGrids_xian(i)	
	return Gui.Control ("xian_" .. i)
	{
		Size = Vector2(42,270 - 35*i),
		Location = Vector2(0,i*35),
		BackgroundColor = ARGB(255,255,255,255),
		Visible = false,
		Skin = Skin.line1,
	}
end
GridTipsUI = Gui.Create()
{
    Gui.Control "F_Tips"--显示F区域的tips UI
    {
        Dock = "kDockFill",
		Visible = false,
		Gui.Control "Tips_ui"--显示F区域的tips UI
		{
			Dock = "kDockFill",
			Visible = false,
			Gui.ItemBoxBtn "ctrl_Icon"
			{
				Size = Vector2(361,409),
				Location = Vector2(236,0),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Empty = false,
				Type = 1,
				Skin = Gui.ItemBoxBtnSkin
				{
					NeutralNormalImage =   nil,--Gui.Image("LobbyUI/team/lb_shop_bg_gouwuche2_normal.dds", Vector4(10, 10, 10, 10)),
					NeutralHoverImage =    nil,--Gui.Image("LobbyUI/team/lb_shop_bg_gouwuche2_hover.dds", Vector4(10, 10, 10, 10)),
					NeutralSelectedImage = nil,--Gui.Image("LobbyUI/team/lb_shop_bg_gouwuche2_down.dds", Vector4(10, 10, 10, 10)),
					NeutralDisabledImage = nil,--Gui.Image("LobbyUI/team/lb_shop_bg_gouwuche2_normal.dds", Vector4(10, 10, 10, 10)),
				},
			},
			Gui.Control "tips_level"
			{
				Size = Vector2(48,15),
				Location = Vector2(18,9),
				BackgroundColor = ARGB(255,255,255,255),
			},
			Gui.Label "tips_name"
			{
				Size = Vector2(282, 23),
				Location = Vector2(87,5),
				TextColor = ARGB(255, 255, 210, 0),
				FontSize = 16,
				TextPadding = Vector4(0,0,0,0),
				Text = "",
				--BackgroundColor = ARGB(255,255,255,255),
			},
			
			Gui.Control "level_icon"
			{
				Size = Vector2(54,30),
				Location = Vector2(0,110),
				BackgroundColor = ARGB(255,255,255,255),
				Visible = false,
			},
			Gui.Tabpad "tpd_nengli"
			{
				Size = Vector2(285,245),
				-- Dock = "kDockTopCenter",
				-- Margin = Vector4(0,7,0,0),
				Location = Vector2(12,30),
				TabSize = Vector2(282,33),
				TabGap = 2,
			   -- TabPadding = Vector4(9,0,0,0),
				Index = 0,
				TabDock = "kDockLeft",
				TabTextAlign = "kAlignLeftMiddle",
				HighlightTextColor = ARGB(255,255,255,255),
				TextShadowColor = ARGB(128,210,210,210),
				TextColor = ARGB(255,255,255,255),
				Skin = Gui.TabpadSkin
				{
					--Control skin
					BackgroundImage = nil,
					
					TabNormalImage= Gui.Image("LobbyUI/team/lb_squad_sx01_bg.dds", Vector4(82,0,11,0)),
					TabHoverImage = Gui.Image("LobbyUI/team/lb_squad_sx02_bg.dds", Vector4(82,0,11,0)),
					TabActiveImage = Gui.Image("LobbyUI/team/lb_squad_sx03_bg.dds", Vector4(82,0,11,0)),
					TabNormalDisabledImage = nil
				},
				
				Gui.Tabpage "tpg_1"--威力
				{
					--Text = lang:GetText("威力"),
					--Padding = Vector4(0,110,0,0),
					--LineSpace = 5,
					
				},				
				Gui.Tabpage "tpg_2"--血量
				{
					--Text = lang:GetText("血量"),
					--Padding = Vector4(15,0,0,0),
					--LineSpace = 5,
					
				},
				Gui.Tabpage "tpg_3"--射速
				{
					--Text = lang:GetText("射速"),
					--Padding = Vector4(15,0,0,0),
					--LineSpace = 5,
					
				},				
				Gui.Tabpage "tpg_4"--转向
				{
					--Text = lang:GetText("转向"),
					--Padding = Vector4(15,0,0,0),
					--LineSpace = 5,
					
				},
				Gui.Tabpage "tpg_5"--射程
				{
					--Text = lang:GetText("射程"),
					--Padding = Vector4(15,0,0,0),
					--LineSpace = 5,
					
				},
				Gui.Tabpage "tpg_6"--弹药
				{
					--Text = lang:GetText("弹药"),
					--Padding = Vector4(15,0,0,0),
					--LineSpace = 5,
					
				},
				Gui.Tabpage "tpg_7"--耐久
				{
					--Text = lang:GetText("耐久"),
					--Padding = Vector4(15,0,0,0),
					--LineSpace = 5,
					
				},
			},
			Gui.Control
			{
				Size = Vector2(285,245),
				Location = Vector2(12,30),
				BackgroundColor = ARGB(0,255,255,255),
				Enable = false,
				Gui.FlowLayout "gridsList"
				{                            
					Dock = "kDockFill",      
					--BackgroundColor = ARGB(255,100,255,100),
					--Padding = Vector4(22,27,0,0),
					ControlSpace = 0,
					LineSpace = 2,
					Direction = "kHorizontal",
					ControlAlign = "kAlignLeft",
					Align = "kAlignTop",

					table.unpack(CreateListGrids_nengli())
				},
			},	
			
			--画连线
			Gui.Control
			{
				Size = Vector2(42,270),
				Location = Vector2(297,47),
				BackgroundColor = ARGB(0,255,255,255),
				CreateListGrids_xian(0),	
				CreateListGrids_xian(1),	
				CreateListGrids_xian(2),	
				CreateListGrids_xian(3),	
				CreateListGrids_xian(4),
			},
			Gui.Button "btn_5"
			{
				Size = Vector2(83,27),
				Location = Vector2(300, 206),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Text = lang:GetText("补给"),
				Visible = false,
				Skin = Skin.TeamBtnSkin,
			},
			Gui.Button "btn_6"
			{
				Size = Vector2(83,27),
				Location = Vector2(300, 240),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Text = lang:GetText("维修"),
				Visible = false,
				Skin = Skin.TeamBtnSkin,
			},		
			
			Gui.ComboBox "lb_enterPower"
			{
				--Style = "Gui.WarZoneCreateComboBox",
				Size = Vector2(221, 25),
				Location = Vector2(12,299),
				FontSize = 14,
				Readonly = true,
				TextColor = ARGB(255,255, 255, 255),
				TextAlign = "kAlignCenterMiddle",
				TextPadding = Vector4(0,0,0,0),
				--LikeButton = true,
				ChildComboListStyle =  "Gui.ChangeLevelUpPriceList",
				Skin = Gui.ComboBoxSkin
				{
					ButtonNormalImage= Gui.Image("LobbyUI/team/lb_xia_normal.dds", Vector4(0, 0, 0, 0)),
					ButtonHoverImage = Gui.Image("LobbyUI/team/lb_xia_hover.dds", Vector4(0, 0, 0, 0)),
					ButtonDownImage = Gui.Image("LobbyUI/team/lb_xia_down.dds", Vector4(0, 0, 0, 0)),
					
					TextNormalImage= Gui.Image("LobbyUI/lb_com_bg.dds", Vector4(45,0,20,0)),
					TextHoverImage = Gui.Image("LobbyUI/lb_com_bg.dds", Vector4(45,0,20,0)),
					TextDownImage = Gui.Image("LobbyUI/lb_com_bg.dds", Vector4(45,0,20,0)),
				},
				
			},
			Gui.Control "canIcon"--可用能源的小图标
			{
				Size = Vector2(30, 30),
				Location = Vector2(13, 294),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Skin.priceIcon[2],
				Hint = lang:GetText("我的FC"),

			},
			Gui.Button "levelUp_btn"
			{
				Size = Vector2(83,27),
				Location = Vector2(235, 298),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Text = lang:GetText("升级"),
				Skin = Skin.LevelUpBtnSkin,
			},
			Gui.Button "evolution_btn"--进化
			{
				Size = Vector2(123,55),
				Location = Vector2(393, 300),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Visible = true,
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_jinhua_normal.dds", Vector4(0, 0, 0, 0)),
					HoverImage = Gui.Image("LobbyUI/team/lb_squad_jinhua_hover.dds", Vector4(0, 0, 0, 0)),
					DownImage = Gui.Image("LobbyUI/team/lb_squad_jinhua_down.dds", Vector4(0, 0, 0, 0)),
					DisabledImage = Gui.Image("LobbyUI/team/lb_squad_jinhua_disabled.dds", Vector4(0, 0, 0, 0)),
				},
			},
			Gui.Label "lb_canPower"
			{
				Size = Vector2(221, 25),
				Location = Vector2(12,338),
				Text = lang:GetText("8000"),
				FontSize = 14,
				TextPadding = Vector4(0,0,10,0),
				TextColor = ARGB(255, 255, 255, 255),
				TextAlign = "kAlignRightMiddle",
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/lb_com_bg.dds",Vector4(45,0,20,0)),
				},
			},
			Gui.TimeControl "tips_ctrlTimer"
			{
				Size = Vector2(5,5),
				Dock = "kDockCenter",
				BackgroundColor = ARGB(0, 255, 255, 255),				
			},
			Gui.Control "c_icon"--可用能源的小图标
			{
				Size = Vector2(30, 30),
				Location = Vector2(13, 333),
				Visible = true,
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/lb_icon_res_01.dds",Vector4(0, 0, 0, 0)),
				},
				Hint = lang:GetText("战队黑铁"),
			},
			Gui.Button "make_btn"
			{
				Size = Vector2(83,27),
				Location = Vector2(235, 337),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Text = lang:GetText("建造"),
				DisabledTextColor = ARGB(255, 0, 0, 0),
				Skin = Skin.TeamBtnSkin,
			},
		},
		Gui.Control "Tips_Tree_ui"--显示tips UI科技树
		{
			Dock = "kDockFill",
			Visible = false,
			Gui.ItemBoxBtn "ctrl_T_Icon"
			{
				Size = Vector2(361,409),
				Location = Vector2(236,0),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Empty = false,
				Type = 1,
				Skin = Gui.ItemBoxBtnSkin
				{
					NeutralNormalImage =   nil,--Gui.Image("LobbyUI/team/lb_shop_bg_gouwuche2_normal.dds", Vector4(10, 10, 10, 10)),
					NeutralHoverImage =    nil,--Gui.Image("LobbyUI/team/lb_shop_bg_gouwuche2_hover.dds", Vector4(10, 10, 10, 10)),
					NeutralSelectedImage = nil,--Gui.Image("LobbyUI/team/lb_shop_bg_gouwuche2_down.dds", Vector4(10, 10, 10, 10)),
					NeutralDisabledImage = nil,--Gui.Image("LobbyUI/team/lb_shop_bg_gouwuche2_normal.dds", Vector4(10, 10, 10, 10)),
				},
			},
			Gui.Control "tips_T_level"
			{
				Size = Vector2(48,15),
				Location = Vector2(18,27),
				BackgroundColor = ARGB(255,255,255,255),
			},
			Gui.Label "tips_T_name"
			{
				Size = Vector2(282,27),
				Location = Vector2(87,21),
				TextColor = ARGB(255, 255, 210, 0),
				FontSize = 16,
				TextPadding = Vector4(0,0,0,0),
				Text = "",
				--BackgroundColor = ARGB(255,255,255,255),
			},
			Gui.TextArea "tips_T_description"
			{
				Size = Vector2(308,200),
				Location = Vector2(23,77),
				TextColor = ARGB(255, 255, 255, 255),
				FontSize = 18,
				Readonly = true,
				TextPadding = Vector4(0,0,0,0),
				Text = "",
				Fold = true,
			},
		},
    },
}

function CreateListGrids_P_nengli()
	local tb = {}
	for i=1,4,1 do
		tb[i] = Gui.Control --("Grid_" .. i)
		{
			Size = Vector2(285,33),
			BackgroundColor = ARGB(0,255,255,255),
			Gui.Label ("type_P_text_"..i)
			{
				Size = Vector2(79, 33),
				Location = Vector2(0,0),
				Text = P_nengLi_type_Text[i],
				FontSize = 14,
				TextColor = ARGB(255, 255, 255, 255),
				TextAlign = "kAlignCenterMiddle",
			},
			Gui.ProportionBar ("team_nengliExp_P_"..i)
			{
				Visible = true,
				Size = Vector2(203, 33),
				Location = Vector2(81,0),
				BackgroundColor = ARGB(255,255,255,255),
				--Icon = Gui.ProportionIcon(nil, "LobbyUI/team/lb_squad_jingyan01_bg.dds", nil, Vector4(0,0,8,6) ),	
			},
			Gui.Label ("lb_P_"..i)
			{
				Size = Vector2(203, 33),
				Location = Vector2(79,0),
				Text = "",
				FontSize = 16,
				TextPadding = Vector4(15,0,0,0),
				TextColor = ARGB(255, 255, 255, 255),
				TextAlign = "kAlignLeftMiddle",
			},
			Gui.Label ("lb_level_P_"..i)
			{
				Size = Vector2(203, 33),
				Location = Vector2(79,0),
				Text = lang:GetText("80"),
				FontSize = 16,
				TextPadding = Vector4(0,0,15,0),
				TextColor = ARGB(255, 255, 255, 255),
				TextAlign = "kAlignRightMiddle",
			},
			
		}
	end
	return tb
end

function CreateListGrids_xian_P(i)	
	return Gui.Control ("xian_P_" .. i)
	{
		Size = Vector2(42,270 - 35*i),
		Location = Vector2(0,i*35),
		BackgroundColor = ARGB(255,255,255,255),
		Visible = false,
		Skin = Skin.line1,
	}
end
GridPersonalTipsUI = Gui.Create()
{
    Gui.Control "Personal_Tips"--显示个人建设的tips UI
    {
        Dock = "kDockFill",
		Visible = false,
		Gui.Control "Personal_TankTips"--显示个人建设的坦克tips UI
		{
			Dock = "kDockFill",
			Visible = false,
			Gui.ItemBoxBtn "ctrl_P_Icon"
			{
				Size = Vector2(361,409),
				Location = Vector2(236,0),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Empty = false,
				Type = 1,
				Skin = Gui.ItemBoxBtnSkin
				{
					NeutralNormalImage =   nil,--Gui.Image("LobbyUI/team/lb_shop_bg_gouwuche2_normal.dds", Vector4(10, 10, 10, 10)),
					NeutralHoverImage =    nil,--Gui.Image("LobbyUI/team/lb_shop_bg_gouwuche2_hover.dds", Vector4(10, 10, 10, 10)),
					NeutralSelectedImage = nil,--Gui.Image("LobbyUI/team/lb_shop_bg_gouwuche2_down.dds", Vector4(10, 10, 10, 10)),
					NeutralDisabledImage = nil,--Gui.Image("LobbyUI/team/lb_shop_bg_gouwuche2_normal.dds", Vector4(10, 10, 10, 10)),
				},
			},
			Gui.Label "tips_P_level"
			{
				Size = Vector2(48,15),
				Location = Vector2(18,9),
				BackgroundColor = ARGB(255,255,255,255),
			},
			Gui.Label "tips_P_name"
			{
				Size = Vector2(282,23),
				Location = Vector2(87,5),
				TextColor = ARGB(255, 255, 210, 0),
				FontSize = 16,
				TextPadding = Vector4(0,0,0,0),
				Text = "",
				--BackgroundColor = ARGB(255,255,255,255),
			},
			
			Gui.Control "level_P_icon"
			{
				Size = Vector2(54,30),
				Location = Vector2(0,110),
				BackgroundColor = ARGB(255,255,255,255),
				Visible = false,
			},
			Gui.Tabpad "tpd_P_nengli"
			{
				Size = Vector2(285,245),
				-- Dock = "kDockTopCenter",
				-- Margin = Vector4(0,7,0,0),
				Location = Vector2(12,30),
				TabSize = Vector2(282,33),
				TabGap = 2,
			   -- TabPadding = Vector4(9,0,0,0),
				Index = 0,
				TabDock = "kDockLeft",
				TabTextAlign = "kAlignLeftMiddle",
				HighlightTextColor = ARGB(255,255,255,255),
				TextShadowColor = ARGB(128,210,210,210),
				TextColor = ARGB(255,255,255,255),
				Skin = Gui.TabpadSkin
				{
					--Control skin
					BackgroundImage = nil,
					
					TabNormalImage= Gui.Image("LobbyUI/team/lb_squad_sx01_bg.dds", Vector4(82,0,11,0)),
					TabHoverImage = Gui.Image("LobbyUI/team/lb_squad_sx02_bg.dds", Vector4(82,0,11,0)),
					TabActiveImage = Gui.Image("LobbyUI/team/lb_squad_sx03_bg.dds", Vector4(82,0,11,0)),
					TabNormalDisabledImage = Gui.Image("LobbyUI/team/lb_squad_sx01_bg.dds", Vector4(82,0,11,0)),
				},
				
				Gui.Tabpage "tpg_P_1"--威力
				{
					--Text = lang:GetText("威力"),
					--Padding = Vector4(15,0,0,0),
					--LineSpace = 5,
					
				},				
				Gui.Tabpage "tpg_P_2"--血量
				{
					--Text = lang:GetText("血量"),
					--Padding = Vector4(15,0,0,0),
					--LineSpace = 5,
					
				},
				Gui.Tabpage "tpg_P_3"--射速
				{
					--Text = lang:GetText("射速"),
					--Padding = Vector4(15,0,0,0),
					--LineSpace = 5,
					
				},				
				Gui.Tabpage "tpg_P_4"--移动速度
				{
					--Text = lang:GetText("转向"),
					--Padding = Vector4(15,0,0,0),
					--LineSpace = 5,
					
				},
				
			},
			Gui.Control
			{
				Size = Vector2(285,245),
				Location = Vector2(12,30),
				BackgroundColor = ARGB(0,255,255,255),
				Enable = false,
				Gui.FlowLayout "gridsList"
				{                            
					Dock = "kDockFill",      
					--BackgroundColor = ARGB(255,100,255,100),
					--Padding = Vector4(22,27,0,0),
					ControlSpace = 0,
					LineSpace = 2,
					Direction = "kHorizontal",
					ControlAlign = "kAlignLeft",
					Align = "kAlignTop",

					table.unpack(CreateListGrids_P_nengli())
				},
			},	
			
			--画连线
			Gui.Control
			{
				Size = Vector2(42,270),
				Location = Vector2(297,47),
				BackgroundColor = ARGB(0,255,255,255),
				CreateListGrids_xian_P(0),	
				CreateListGrids_xian_P(1),	
				CreateListGrids_xian_P(2),	
				CreateListGrids_xian_P(3),	
			},
			
			Gui.ComboBox "lb_P_enterPower"
			{
				--Style = "Gui.WarZoneCreateComboBox",
				Size = Vector2(221, 25),
				Location = Vector2(12,299),
				FontSize = 14,
				Readonly = true,
				TextColor = ARGB(255,255, 255, 255),
				TextAlign = "kAlignCenterMiddle",
				TextPadding = Vector4(0,0,0,0),
				--LikeButton = true,
				ChildComboListStyle =  "Gui.ChangeLevelUpPriceList",
				Skin = Gui.ComboBoxSkin
				{
					ButtonNormalImage= Gui.Image("LobbyUI/team/lb_xia_normal.dds", Vector4(0, 0, 0, 0)),
					ButtonHoverImage = Gui.Image("LobbyUI/team/lb_xia_hover.dds", Vector4(0, 0, 0, 0)),
					ButtonDownImage = Gui.Image("LobbyUI/team/lb_xia_down.dds", Vector4(0, 0, 0, 0)),
					
					TextNormalImage= Gui.Image("LobbyUI/lb_com_bg.dds", Vector4(45,0,20,0)),
					TextHoverImage = Gui.Image("LobbyUI/lb_com_bg.dds", Vector4(45,0,20,0)),
					TextDownImage = Gui.Image("LobbyUI/lb_com_bg.dds", Vector4(45,0,20,0)),
				},
				
			},
			Gui.Control "P_canIcon"--可用能源的小图标
			{
				Size = Vector2(30, 30),
				Location = Vector2(13, 294),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Skin.priceIcon[2],
				Hint = lang:GetText("个人黑晶石"),
			},
			Gui.Button "P_levelUp_btn"
			{
				Size = Vector2(83,27),
				Location = Vector2(235, 298),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Text = lang:GetText("升级"),
				Skin = Skin.LevelUpBtnSkin,
			},
			Gui.Label "lb_P_canPower"
			{
				Size = Vector2(221, 25),
				Location = Vector2(12,338),
				Text = lang:GetText("8000"),
				FontSize = 14,
				TextPadding = Vector4(0,0,10,0),
				TextColor = ARGB(255, 255, 255, 255),
				TextAlign = "kAlignRightMiddle",
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/lb_com_bg.dds",Vector4(45,0,20,0)),
				},
			},
			Gui.TimeControl "p_ctrlTimer"
			{
				Size = Vector2(5,5),
				Dock = "kDockCenter",
				BackgroundColor = ARGB(0, 255, 255, 255),
				
			},
			
			Gui.Control "c_P_icon"--可用能源的小图标
			{
				Size = Vector2(30, 30),
				Location = Vector2(13, 333),
				Visible = true,
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Skin.priceIcon[7],
				Hint = lang:GetText("个人原石"),
			},
			Gui.Button "make_P_btn"
			{
				Size = Vector2(83,27),
				Location = Vector2(235, 337),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Text = lang:GetText("建造"),
				DisabledTextColor = ARGB(255, 0, 0, 0),
				Skin = Skin.TeamBtnSkin,
			},
			
		},
		Gui.Control "Tips_P_Tree_ui"--显示tips UI科技树
		{
			Dock = "kDockFill",
			Visible = false,
			Gui.ItemBoxBtn "ctrl_PT_Icon"
			{
				Size = Vector2(361,409),
				Location = Vector2(236,0),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Empty = false,
				Type = 1,
				Skin = Gui.ItemBoxBtnSkin
				{
					NeutralNormalImage =   nil,--Gui.Image("LobbyUI/team/lb_shop_bg_gouwuche2_normal.dds", Vector4(10, 10, 10, 10)),
					NeutralHoverImage =    nil,--Gui.Image("LobbyUI/team/lb_shop_bg_gouwuche2_hover.dds", Vector4(10, 10, 10, 10)),
					NeutralSelectedImage = nil,--Gui.Image("LobbyUI/team/lb_shop_bg_gouwuche2_down.dds", Vector4(10, 10, 10, 10)),
					NeutralDisabledImage = nil,--Gui.Image("LobbyUI/team/lb_shop_bg_gouwuche2_normal.dds", Vector4(10, 10, 10, 10)),
				},
			},
			Gui.Control "tips_PT_level"
			{
				Size = Vector2(48,15),
				Location = Vector2(18,27),
				BackgroundColor = ARGB(255,255,255,255),
			},
			Gui.Label "tips_PT_name"
			{
				Size = Vector2(282,23),
				Location = Vector2(87,23),
				TextColor = ARGB(255, 255, 210, 0),
				FontSize = 16,
				TextPadding = Vector4(0,0,0,0),
				Text = "",
				--BackgroundColor = ARGB(255,255,255,255),
			},
			Gui.TextArea "tips_PT_description"
			{
				Size = Vector2(308,200),
				Location = Vector2(23,77),
				TextColor = ARGB(255, 255, 255, 255),
				FontSize = 18,
				Readonly = true,
				TextPadding = Vector4(0,0,0,0),
				Text = "",
				Fold = true,
				--BackgroundColor = ARGB(255,255,255,255),
			},
		},
    },
	Gui.Control "Tips_P_Buff_ui"--显示tips BuffUI
	{
		Dock = "kDockFill",
		Visible = false,
		Gui.Control "tip_PB_ib"
		{
			Dock = "kDockFill",
			BackgroundColor = ARGB(127, 255, 255, 255),			
		},
		
		Gui.Label "tips_PB_name"
		{
			Size = Vector2(282,23),
			Location = Vector2(23,23),
			TextColor = ARGB(255, 255, 210, 0),
			FontSize = 16,
			TextPadding = Vector4(0,0,0,0),
			Text = "",
			--BackgroundColor = ARGB(255,255,255,255),
		},
		Gui.TextArea "tips_PB_description"
		{
			Size = Vector2(308,200),
			Location = Vector2(23,77),
			TextColor = ARGB(255, 255, 255, 255),
			FontSize = 18,
			Readonly = true,
			TextPadding = Vector4(0,0,0,0),
			Text = "",
			Fold = true,
			--BackgroundColor = ARGB(255,255,255,255),
		},
		Gui.Label "addBuff_name"
		{
			Size = Vector2(120, 25),
			Location = Vector2(23,190),
			Text = lang:GetText("增加攻击速度："),
			FontSize = 18,
			TextPadding = Vector4(0,0,10,0),
			TextColor = ARGB(255, 255, 210, 0),
			TextAlign = "kAlignLeftMiddle",
			
		},
		Gui.Label "addBuff_num"
		{
			Size = Vector2(200, 25),
			Location = Vector2(143,190),
			Text = "8000HP",
			FontSize = 18,
			TextPadding = Vector4(0,0,10,0),
			TextColor = ARGB(255, 255, 255, 255),
			TextAlign = "kAlignLeftMiddle",
			
		},
		Gui.Label "addTime_name"
		{
			Size = Vector2(120, 25),
			Location = Vector2(23,230),
			Text = lang:GetText("持续时间："),
			FontSize = 18,
			TextPadding = Vector4(0,0,10,0),
			TextColor = ARGB(255, 255, 210, 0),
			TextAlign = "kAlignLeftMiddle",
			
		},
		Gui.Label "addTime_num"
		{
			Size = Vector2(200, 25),
			Location = Vector2(143,230),
			Text = "8000HP",
			FontSize = 18,
			TextPadding = Vector4(0,0,10,0),
			TextColor = ARGB(255, 255, 255, 255),
			TextAlign = "kAlignLeftMiddle",
			
		},
		Gui.Label "lb_Buff_Fc"
		{
			Size = Vector2(221, 25),
			Location = Vector2(12,299),
			Text = lang:GetText("8000"),
			FontSize = 14,
			TextPadding = Vector4(0,0,10,0),
			TextColor = ARGB(255, 255, 255, 255),
			TextAlign = "kAlignRightMiddle",
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/lb_com_bg.dds",Vector4(45,0,20,0)),
			},
		},
		
		Gui.Control "Buff_canIcon"--可用能源的小图标
		{
			Size = Vector2(30, 30),
			Location = Vector2(13, 294),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Skin.priceIcon[2],
			Hint = lang:GetText("我的FC"),
		},
		Gui.Button "Buff_buy_btn"
		{
			Size = Vector2(83,27),
			Location = Vector2(235, 298),
			BackgroundColor = ARGB(255, 255, 255, 255),
			DisabledTextColor = ARGB(255, 0, 0, 0),
			Text = lang:GetText("购买"),
			Skin = Skin.LevelUpBtnSkin,
		},
		Gui.Label "lb_canResource"
		{
			Size = Vector2(221, 25),
			Location = Vector2(12,338),
			Text = lang:GetText("8000"),
			FontSize = 14,
			TextPadding = Vector4(0,0,10,0),
			TextColor = ARGB(255, 255, 255, 255),
			TextAlign = "kAlignRightMiddle",
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/lb_com_bg.dds",Vector4(45,0,20,0)),
			},
		},
		--[[
		Gui.ComboBox "lb_canResource"
		{
			--Style = "Gui.WarZoneCreateComboBox",
			Size = Vector2(221, 25),
			Location = Vector2(12,338),
			FontSize = 14,
			Readonly = true,
			TextColor = ARGB(255,255, 255, 255),
			TextAlign = "kAlignCenterMiddle",
			TextPadding = Vector4(0,0,0,0),
			--LikeButton = true,
			ChildComboListStyle =  "Gui.ChangeLevelUpPriceList",
			Skin = Gui.ComboBoxSkin
			{
				ButtonNormalImage= Gui.Image("LobbyUI/team/lb_xia_normal.dds", Vector4(0, 0, 0, 0)),
				ButtonHoverImage = Gui.Image("LobbyUI/team/lb_xia_hover.dds", Vector4(0, 0, 0, 0)),
				ButtonDownImage = Gui.Image("LobbyUI/team/lb_xia_down.dds", Vector4(0, 0, 0, 0)),
				
				TextNormalImage= Gui.Image("LobbyUI/lb_com_bg.dds", Vector4(45,0,20,0)),
				TextHoverImage = Gui.Image("LobbyUI/lb_com_bg.dds", Vector4(45,0,20,0)),
				TextDownImage = Gui.Image("LobbyUI/lb_com_bg.dds", Vector4(45,0,20,0)),
			},
			
		},--]]
		Gui.Control "b_icon"--可用能源的小图标
		{
			Size = Vector2(30, 30),
			Location = Vector2(13, 333),
			Visible = true,
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Skin.priceIcon[5],
			Hint = lang:GetText("个人黑晶石"),			
		},
		Gui.Button "buff_btn"
		{
			Size = Vector2(83,27),
			Location = Vector2(235, 337),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Text = lang:GetText("补给"),
			DisabledTextColor = ARGB(255, 0, 0, 0),
			Skin = Skin.TeamBtnSkin,
		},
	},
}
--int teamId,
--int teamItemId,int playerItemId//两个传一个，另一个为空
-- int manageType,//点击动作,当type是全部维修和全部补给的时候要传storageType,
		-- TEAM_PALCE_UP(1),//升级战队空间
		-- DEPLOY(2),//配置（满了就不能配置，已配置不能配置）
		
		-- REPAIR_TEAM_ITEM(3),//修理
		-- SUPPLY(4),//补给
		
		-- TEAM_ITEM_UP(5),//升级//INTENSIFY_TEAM_ITEM(2),//强化
		-- SUPPLY_ALL(6),全部补给
		-- REPAIR_ALL(7),//全部修理
		-- DELETE_TEAM_ITEM(8),//删除
function CallRpcBtn(t_id,tId,pId,mt,sType)
	-- if mt == 6 or mt == 7 then
		-- sType = sType
	-- else
		-- sType = -1
	-- end
	print(ptr_cast(game.CurrentState):GetCharacterId(),t_id,tId,pId,mt,sType)
	rpc.safecallload("team_item_manage", {playerId = ptr_cast(game.CurrentState):GetCharacterId(),teamId = t_id,teamItemId = tId,playerItemId = pId,manageType = mt,storageType = sType},
			function(data)
				if data.error then
					MessageBox.ShowWithTimer(1,data.error)
					return
				else
					if mt == 3 then
						MessageBox.ShowWithTwoButtons(lang:GetText("您本次维修需要花费黑铁")..data.price,lang:GetText("确定"),lang:GetText("取消"),
						function()
							repairOrSupply(-1,-1,tId,mt)
						end,
						nil
						)
					elseif mt == 4 then
						MessageBox.ShowWithTwoButtons(lang:GetText("您本次补给需要花费黑铁")..data.price,lang:GetText("确定"),lang:GetText("取消"),
						function()
							repairOrSupply(-1,-1,tId,mt)
						end,
						nil
						)
					elseif mt == 6 then
						MessageBox.ShowWithTwoButtons(lang:GetText("您这次全部补给需要花费黑铁")..data.price,lang:GetText("确定"),lang:GetText("取消"),
						function()
							repairOrSupply(t_id,sType,tId,mt)
						end,
						nil
						)
					elseif mt == 7 then
						MessageBox.ShowWithTwoButtons(lang:GetText("您这次全部维修需要花费黑铁")..data.price,lang:GetText("确定"),lang:GetText("取消"),
						function()
							repairOrSupply(t_id,sType,tId,mt)
						end,
						nil
						)
					else
						updataTeamInfo(1,cType)
					end
					
				end
				
			end)
end

-----param---------
-- pid      - 玩家id
-- type     - 1:个人   2:团队
-- iid      -ItemId       即 道具的ID ，团队物品: teamItemId ,个人物品 playerItemId
-- atype    -ActionType  1:查询 2:购买
-- ptype    -PayType     0:(查询,不用付费)  1:(半价)    2:(全价)
function callAddSpeedCDRpc(Type,iId)
	rpc.safecallload("get_fc_price", {pid = ptr_cast(game.CurrentState):GetCharacterId(),type = Type,iid = iId,atype = 1,ptype = 0},
				function(data)
					if data.error then
						MessageBox.ShowWithTimer(1,data.error)
						return
					else
						MessageBox.ShowWithTwoButtons(lang:GetText("您需要花费")..data.PRICE.fccost.."\n"..lang:GetText("FC点来加速！"),lang:GetText("确定"),lang:GetText("取消"),
							function()
								rpc.safecallload("get_fc_price",{pid = ptr_cast(game.CurrentState):GetCharacterId(),type = Type,iid = iId,atype = 2,ptype = data.PRICE.type},
								function(data)
									MessageBox.ShowWithTimer(1,lang:GetText("加速成功！"))
									if Type == 1 then
										updataPersonalInfo(1,sType)
									else
										updataTeamInfo(1,cType)
									end
									Fill_Header_Team()
								end)
							end,
							nil)
					end
				end)
end

-- 参数列表
-- uid=帐号id
-- pid=帐号id
-- sid =准备要买的物品的id
-- t = 准备要买的物品的type 目前只有9 资源争夺战 1=武器、2=套装、3=配饰、4=道具、5=蓝图、6=素材、7=大礼包
-- costid = 1, 2, 3 付款方式的id
-- packid=1 装备到背包=1 购买不装备=0，目前都是穿0
function callBuildRpc(s_id,Type,cId,packId)
	print("s_id,Type,cId,packId ====",s_id,Type,cId,packId)
	rpc.safecallload("shop_req_zyzdzteam_buy", {pid = ptr_cast(game.CurrentState):GetCharacterId(),sid = s_id,t = Type,costid = cId,packid = packId},
				function(data)
					if data.error then
						MessageBox.ShowWithTimer(1,data.error)
						return
					else
						print("成功")
						Fill_Header_Team()
						updataTeamInfo(1,cType)
						if data.buildTime ~= 0 then
							L_LevelUpEffect.Show_MakeTimeEffect(data)
						end		
					end
				end)
end

-- playerId,
-- teamItemId,
-- teamId,
function callJinhuaRpc(t_iid)
	rpc.safecallload("confirm_itemLevelUp", {playerId = ptr_cast(game.CurrentState):GetCharacterId(),teamItemId = t_iid,teamId = t_id},
				function(data)
					if data.error then
						MessageBox.ShowWithTimer(1,data.error)
						return
					else
						if data.itemLevel then
							L_LevelUpEffect.Show_LevelUpEffect(data)
						end									
						updataTeamInfo(1,cType)
					end
				end)
end

-- teamItemId,
-- currency,2rmb,6res
-- cost,
-- intensifyType,1,威力2,射速3,hp4,射程5;转速
function callNengLiLevelUPRpc(t_iid,cur,price,it)
	print("t_iid,cur,price,it ====",t_iid,cur,price,it)
	rpc.safecallload("team_item_intensify", {playerId = ptr_cast(game.CurrentState):GetCharacterId(),teamItemId = t_iid,currency = cur,cost = price,intensifyType = it},
				function(data)
					if data.error then
						MessageBox.ShowWithTimer(1,data.error)
						return
					else
						print("升级成功")
						if (data.res and data.res > 0) or data.outOfCost > 0 then
							L_LevelUpEffect.Show_LevelUpEffect(data,cur)			
						end	
						Fill_Header_Team()
						updataTeamInfo(1,cType)						
					end
				end)
end
sCurrency = nil
sPrice=  nil
function FillGridsTree_tips(info)
	
	GridTipsUI.F_Tips.Visible = true
    GridTipsUI.F_Tips.Parent = allteam_source_ui.F
	GridTipsUI.Tips_ui.Visible = false
	GridTipsUI.Tips_Tree_ui.Visible = true
	local tInfo = info
	GridTipsUI.tips_T_name.Text = tInfo.display
	GridTipsUI.tips_T_level.Skin = Skin.itemLevelIcon[tInfo.level]
	GridTipsUI.ctrl_T_Icon.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..tInfo.name..".dds")
	GridTipsUI.tips_T_description.Text = tInfo.description
end
--填充右面的tips的UI界面
function FillGrids_tips(info)
	saveInfo = info
	
	GridTipsUI.F_Tips.Visible = true
    GridTipsUI.F_Tips.Parent = allteam_source_ui.F
	
		GridTipsUI.Tips_Tree_ui.Visible = false
		GridTipsUI.Tips_ui.Visible = true
		local sInfo = info
		SelectedTpd(nIdx,sInfo)
		print("SelectedTpd(nIdx,sInfo)")
		GridTipsUI.tips_name.Text = sInfo.display
		GridTipsUI.tips_level.Skin = Skin.itemLevelIcon[sInfo.level]
		GridTipsUI.ctrl_Icon.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..sInfo.name..".dds")
		if isTeamLeader then
			if info.isEvolve == 1 then
				GridTipsUI.evolution_btn.Enable = true
			else
				GridTipsUI.evolution_btn.Enable = false
			end	
			GridTipsUI.make_btn.Enable = true
		else
			GridTipsUI.evolution_btn.Enable = false
			GridTipsUI.make_btn.Enable = false
		end
		
		local mode1 = sInfo.resteamprice
		--建造按钮事件
		GridTipsUI.make_btn.EventClick = function()
			if tonumber(sInfo.buycd) > 0 then
				callAddSpeedCDRpc(2,sInfo.teamItemId)
			else
				if mode1 then
					if save_T_res and save_T_res < mode1.cost then
						print("save_T_res",save_T_res)
						MessageBox.ShowWithTimer(1,"战队黑铁不够！")
					else
						if isTeamLeader then
							callBuildRpc(sInfo.sysItemId,9,mode1.id,1)
						else
							MessageBox.ShowWithTimer(1,"建造需要战队队长权限！")
						end					
					end
				end
			end	
		end
		--升级属性能力按钮事件 
		GridTipsUI.levelUp_btn.EventClick = function(sender,e)			
			if IT ~= 0 then	
				if sInfo.value <= 0 then
					MessageBox.ShowWithTimer(1,"数量为0，请先建造至少一个才能升级！")
				else
					if sender.Enable == true then
						sender.Enable = false
					end
					
					callNengLiLevelUPRpc(sInfo.teamItemId,sCurrency,sPrice,IT)
				end			
			end
		end
		--进化按钮事件
		GridTipsUI.evolution_btn.EventClick = function()			
			callJinhuaRpc(sInfo.teamItemId)
		end
		--维修按钮事件
		GridTipsUI.btn_6.EventClick = function()
			if sInfo.durable >= 100 then
				MessageBox.ShowWithTimer(1,lang:GetText("耐久已满，不需要修理！"))
			else
				CallRpcBtn(-1,sInfo.teamItemId,-1,3,cType)
			end		
		end
		--填补弹药按钮事件
		GridTipsUI.btn_5.EventClick = function()
			if sInfo.bullet >= 100 then
				MessageBox.ShowWithTimer(1,lang:GetText("弹药已满，不需要补给！"))
			else
				CallRpcBtn(-1,sInfo.teamItemId,-1,4,cType)
			end		
		end
		GridTipsUI.lb_enterPower:RemoveAll()
		GridTipsUI.lb_enterPower.SelectedIndex = combox_selIdx-1
		sCurrency = getPrice[combox_selIdx].cur
		--local sp = L_PushCmd.Split(getPrice[combox_selIdx].TextPrice,":")
		sPrice = getPrice[combox_selIdx].cost--tonumber(sp[2])
		--切换价格事件
		GridTipsUI.lb_enterPower.EventValueChanged = function(sender, args)
			--combox_selIdx = sender.SelectedIndex+1
			--sCurrency = 2--getPrice[sender.SelectedIndex+1].cur
			--local textPrice = L_PushCmd.Split(getPrice[sender.SelectedIndex+1].TextPrice,":")
			--sPrice = getPrice[sender.SelectedIndex+1].cost--tonumber(textPrice[2])
			GridTipsUI.levelUp_btn.Enable = true
			if sender.SelectedIndex == 0 then
				sCurrency = getPrice[sender.SelectedIndex+1].cur
				sPrice = 	getPrice[sender.SelectedIndex+1].cost
				combox_selIdx =  1
			elseif sender.SelectedIndex == 1 then
				sCurrency = getPrice[sender.SelectedIndex+1].cur
				sPrice = 	getPrice[sender.SelectedIndex+1].cost
				combox_selIdx =  2
			elseif sender.SelectedIndex == 2 then
				sCurrency = getPrice[sender.SelectedIndex+1].cur
				sPrice = 	getPrice[sender.SelectedIndex+1].cost
				combox_selIdx =  3
			elseif sender.SelectedIndex == 3 then
				sCurrency = getPrice[sender.SelectedIndex+1].cur
				sPrice = 	getPrice[sender.SelectedIndex+1].cost
				combox_selIdx =  4
			elseif sender.SelectedIndex == 4 then
				sCurrency = getPrice[sender.SelectedIndex+1].cur
				sPrice = 	getPrice[sender.SelectedIndex+1].cost
				combox_selIdx =  5
			elseif sender.SelectedIndex == 5 then
				sCurrency = getPrice[sender.SelectedIndex+1].cur
				sPrice = 	getPrice[sender.SelectedIndex+1].cost
				combox_selIdx =  6
			elseif sender.SelectedIndex == 6 then
				sCurrency = getPrice[sender.SelectedIndex+1].cur
				sPrice = 	getPrice[sender.SelectedIndex+1].cost
				combox_selIdx =  7
			elseif sender.SelectedIndex == 7 then
				sCurrency = getPrice[sender.SelectedIndex+1].cur
				sPrice = 	getPrice[sender.SelectedIndex+1].cost
				combox_selIdx =  8
			elseif sender.SelectedIndex == 8 then
				sCurrency = getPrice[sender.SelectedIndex+1].cur
				sPrice = 	getPrice[sender.SelectedIndex+1].cost
				combox_selIdx =  9
			elseif sender.SelectedIndex == 9 then
				sCurrency = getPrice[sender.SelectedIndex+1].cur
				sPrice = 	getPrice[sender.SelectedIndex+1].cost
				combox_selIdx =  10
			end
			GridTipsUI.canIcon.Skin = Skin.priceIcon[sCurrency]
		end
		GridTipsUI.lb_enterPower.Text = getPrice[combox_selIdx].TextPrice
		GridTipsUI.canIcon.Skin = Skin.priceIcon[sCurrency]
		
		if isTeamLeader then
			for i = 1,#getPrice, 1 do
				if i <=5 then
					GridTipsUI.lb_enterPower:AddItemWithIcon(getPrice[i].TextPrice,0)
				else
					GridTipsUI.lb_enterPower:AddItemWithIcon(getPrice[i].TextPrice,1)
				end
			end
		else
			for i = 1,5, 1 do
				GridTipsUI.lb_enterPower:AddItemWithIcon(getPrice[i].TextPrice,0)
			end
		end
		local modal2 = sInfo.resteamprices 
		if sInfo.sysItemId == 5454 or sInfo.sysItemId == 5468 or sInfo.sysItemId == 5469 then
			GridTipsUI.make_btn.Visible = false
			GridTipsUI.lb_canPower.Visible = false
			GridTipsUI.c_icon.Visible = false
			GridTipsUI.evolution_btn.Visible = false
		else
			GridTipsUI.make_btn.Visible = true
			GridTipsUI.evolution_btn.Visible = true
			GridTipsUI.lb_canPower.Visible = true
			GridTipsUI.c_icon.Visible = true
			if tonumber(sInfo.buycd) > 0 then
				--GridTipsUI.lb_canPower.Text = GethourMinuteSeconds(tonumber(sInfo.buycd))
				GridTipsUI.c_icon.Visible = false
				GridTipsUI.make_btn.Text = lang:GetText("加速")
				GridTipsUI.make_btn.Shine = true
				UpdateTimeLable(GridTipsUI.tips_ctrlTimer,tonumber(sInfo.buycd),GridTipsUI.lb_canPower)
				GridTipsUI.tips_ctrlTimer.EventTimeOut = function(sender, e)
					updataTeamInfo(1,cType)
				end				
			else
				GridTipsUI.lb_canPower.Text = mode1.cost
				GridTipsUI.tips_ctrlTimer:CleanAll()				
				GridTipsUI.c_icon.Visible = true
				GridTipsUI.make_btn.Text = lang:GetText("建造")
				GridTipsUI.make_btn.Shine = false
			end
		end
				
		--GridTipsUI.level_icon.Skin = Skin.levelIcon[sInfo.level]
		for i = 1,7,1 do
			GridTipsUI["team_nengliExp_"..i].Icon = pro_nor[i]
			GridTipsUI["team_nengliExp_"..i].CurrentValue = 0
			GridTipsUI["team_nengliExp_"..i].MaxValue = 100
			GridTipsUI["Grid_"..i].Visible = true
			GridTipsUI["tpg_"..i].Enable = true
			--GridTipsUI["lv_icon_"..i].Visible = true
			--GridTipsUI["lb_level_"..i]:OnDestroy()
		end
		
		if sInfo.performance.hp then
			--GridTipsUI.lb_2.Text = sInfo.performance.hp.value .. "HP"
			GridTipsUI.lb_level_1.Text = "LV " .. sInfo.performance.hp.level
			--L_LobbyMain.ShowFightnums(GridTipsUI.lb_level_2,tonumber(sInfo.performance.hp.level),"team/lb_squad_numeral_bg.dds",11,11)
			GridTipsUI.team_nengliExp_1.Visible = true
			GridTipsUI.team_nengliExp_1.MaxValue = sInfo.performance.hp.maxExp
			GridTipsUI.team_nengliExp_1.CurrentValue = sInfo.performance.hp.curExp
		else
			--GridTipsUI.lb_2.Text = "--"
			GridTipsUI.lb_level_1.Text = "LV --"
			GridTipsUI.team_nengliExp_1.Visible = false
			GridTipsUI.Grid_1.Visible = false
			GridTipsUI.tpg_1.Enable = false
		end
		if sInfo.performance.power then
			--GridTipsUI.lb_1.Text = sInfo.performance.power.value
			GridTipsUI.lb_level_2.Text = "LV " .. sInfo.performance.power.level
			
			--L_LobbyMain.ShowFightnums(GridTipsUI.lb_level_1,tonumber(sInfo.performance.power.level),"team/lb_squad_numeral_bg.dds",11,11)
			GridTipsUI.team_nengliExp_2.Visible = true
			GridTipsUI.team_nengliExp_2.MaxValue = sInfo.performance.power.maxExp
			GridTipsUI.team_nengliExp_2.CurrentValue = sInfo.performance.power.curExp
		else
			--GridTipsUI.lb_1.Text = "--"
			GridTipsUI.lb_level_2.Text = "LV --"
			GridTipsUI.team_nengliExp_2.Visible = false
			GridTipsUI.Grid_2.Visible = false
			GridTipsUI.tpg_2.Enable = false
		end
		if sInfo.performance.fireSpeed then
			--GridTipsUI.lb_3.Text = info.performance.fireSpeed.value
			GridTipsUI.lb_level_3.Text = "LV " .. sInfo.performance.fireSpeed.level
			--L_LobbyMain.ShowFightnums(GridTipsUI.lb_level_3,tonumber(info.performance.fireSpeed.level),"team/lb_squad_numeral_bg.dds",11,11)
			GridTipsUI.team_nengliExp_3.Visible = true
			GridTipsUI.team_nengliExp_3.MaxValue = sInfo.performance.fireSpeed.maxExp
			GridTipsUI.team_nengliExp_3.CurrentValue = sInfo.performance.fireSpeed.curExp
		else
			--GridTipsUI.lb_3.Text = "--"
			GridTipsUI.lb_level_3.Text = "LV --"
			GridTipsUI.team_nengliExp_3.Visible = false
			GridTipsUI.Grid_3.Visible = false
			GridTipsUI.tpg_3.Enable = false
		end
		if sInfo.performance.rotateSpeed then
			--GridTipsUI.lb_4.Text = info.performance.rotateSpeed.value
			GridTipsUI.lb_level_4.Text = "LV " .. sInfo.performance.rotateSpeed.level
			--L_LobbyMain.ShowFightnums(GridTipsUI.lb_level_4,tonumber(info.performance.rotateSpeed.level),"team/lb_squad_numeral_bg.dds",11,11)
			GridTipsUI.team_nengliExp_4.Visible = true
			GridTipsUI.team_nengliExp_4.MaxValue = sInfo.performance.rotateSpeed.maxExp
			GridTipsUI.team_nengliExp_4.CurrentValue = sInfo.performance.rotateSpeed.curExp
		else
			--GridTipsUI.lb_4.Text = "--"
			GridTipsUI.lb_level_4.Text = "LV --"
			GridTipsUI.team_nengliExp_4.Visible = false
			GridTipsUI.Grid_4.Visible = false
			GridTipsUI.tpg_4.Enable = false
		end
		if sInfo.performance.fireDistance then
			--GridTipsUI.lb_5.Text = info.performance.fireDistance.value .. "M"
			GridTipsUI.lb_level_5.Text = "LV " .. sInfo.performance.fireDistance.level
			--L_LobbyMain.ShowFightnums(GridTipsUI.lb_level_5,tonumber(info.performance.fireDistance.level),"team/lb_squad_numeral_bg.dds",11,11)
			GridTipsUI.team_nengliExp_5.Visible = true
			GridTipsUI.team_nengliExp_5.MaxValue = sInfo.performance.fireDistance.maxExp
			GridTipsUI.team_nengliExp_5.CurrentValue = sInfo.performance.fireDistance.curExp
		else
			--GridTipsUI.lb_5.Text = "--"
			GridTipsUI.lb_level_5.Text = "LV --"
			GridTipsUI.team_nengliExp_5.Visible = false
			GridTipsUI.Grid_5.Visible = false
			GridTipsUI.tpg_5.Enable = false
		end
		if sInfo.bullet then
			GridTipsUI.lb_level_6.Text = sInfo.bullet.."%"
			GridTipsUI.team_nengliExp_6.Visible = true
			GridTipsUI.team_nengliExp_6.MaxValue = 100
			GridTipsUI.team_nengliExp_6.CurrentValue = sInfo.bullet
		else
			GridTipsUI.team_nengliExp_6.Visible = false
			GridTipsUI.Grid_6.Visible = false
			GridTipsUI.tpg_6.Enable = false
		end
		if sInfo.durable then
			GridTipsUI.lb_level_7.Text = sInfo.durable.."%"
			GridTipsUI.team_nengliExp_7.Visible = true
			GridTipsUI.team_nengliExp_7.MaxValue = 100
			GridTipsUI.team_nengliExp_7.CurrentValue = sInfo.durable
		else
			GridTipsUI.team_nengliExp_7.Visible = false
			GridTipsUI.Grid_7.Visible = false
			GridTipsUI.tpg_7.Enable = false
		end
		GridTipsUI.lb_6.Text = ""
		GridTipsUI.lb_7.Text = ""
		--GridTipsUI.lv_icon_6.Visible = false
		--GridTipsUI.lv_icon_7.Visible = false	
		--L_LobbyMain.ShowFightnums(GridTipsUI.lb_level_6,tonumber( info.bullet),"team/lb_squad_numeral_bg.dds",11,11)
		--L_LobbyMain.ShowFightnums(GridTipsUI.lb_level_7,tonumber( info.durable),"team/lb_squad_numeral_bg.dds",11,11)	
	
	
end

function SelectedTpd(idx,info)
	for i = 0,4,1 do
		GridTipsUI["xian_"..i].Visible = false
	end	
	-- for j = 1,7,1 do
		-- GridTipsUI["lb_level_"..j].TextColor = ARGB(255,0,0,0) 
		-- GridTipsUI["type_text_"..j].TextColor = ARGB(255,0,0,0)
	-- end
	GridTipsUI.btn_5.Visible = false
	GridTipsUI.btn_6.Visible = false
	if idx == 5 then
		if info.bullet then
			GridTipsUI.btn_5.Visible = true	
		else
			GridTipsUI.btn_5.Visible = false
		end	
		IT = 0
		GridTipsUI.levelUp_btn.Enable = false
	elseif idx == 6 then
		if info.durable then
			GridTipsUI.btn_6.Visible = true
		else
			GridTipsUI.btn_6.Visible = false
		end		
		IT = 0
		GridTipsUI.levelUp_btn.Enable = false
	else
		GridTipsUI["xian_"..idx].Visible = true
		GridTipsUI.levelUp_btn.Enable = true
		if idx == 0 then
			if  info.performance and info.performance.hp then
				IT = info.performance.hp.property
			else
				GridTipsUI.levelUp_btn.Enable = false
			end
		elseif idx == 1 then
			if info.performance and info.performance.power then
				IT = info.performance.power.property
			else
				GridTipsUI.levelUp_btn.Enable = false
			end			
		elseif idx == 2 then
			if  info.performance and info.performance.fireSpeed then
				IT = info.performance.fireSpeed.property
			else
				GridTipsUI.levelUp_btn.Enable = false
			end
			
		elseif idx == 3 then
			if info.performance and info.performance.rotateSpeed then
				IT = info.performance.rotateSpeed.property
			else
				GridTipsUI.levelUp_btn.Enable = false
			end		
		elseif idx == 4 then
			if info.performance and info.performance.fireDistance then
				IT = info.performance.fireDistance.property
			else
				GridTipsUI.levelUp_btn.Enable = false
			end			
		end
	end
	--GridTipsUI["lb_level_"..(idx+1)].TextColor = ARGB(255,255,255,255)
	--GridTipsUI["type_text_"..(idx+1)].TextColor = ARGB(255,255,255,255)
end
--能力属性选项事件
function onSelectedNengliChanged(sender)
	nIdx = sender.Index
    SelectedTpd(nIdx,saveInfo)
	print("SelectedTpd(nIdx,saveInfo)")
end
GridTipsUI.tpd_nengli.EventSelectedPageChanged = onSelectedNengliChanged

-- int playerId,
-- int playerItemId,
-- int currency,//只用个人可用资源点
-- int cost,
-- int intensifyType,1,威力 2,射速 3,hp 4,射程 5,转速 6,速度
function callPersonalNengLiLevelUPRpc(p_iid,cur,price,it)
	print("t_iid,cur,price,it ====",p_iid,cur,price,it)
	rpc.safecallload("personal_item_intensify", {playerId = ptr_cast(game.CurrentState):GetCharacterId(),playerItemId = p_iid,currency = 5,cost = price,intensifyType = it},
				function(data)
					GridPersonalTipsUI.P_levelUp_btn.Enable = true
					if data.error then
						MessageBox.ShowWithTimer(1,data.error)					
						return
					else
						if data.outOfCost and data.outOfCost > 0 then
							L_LevelUpEffect.Show_LevelUpEffect(data,cur)
						end					
						updataPersonalInfo(1,sType)
						Fill_Header_Team()
						GridPersonalTipsUI.P_levelUp_btn.Enable = true
					end
				end)
end
-- 参数列表
--- uid=帐号id
-- pid=帐号id
-- sid =准备要买的物品的id
-- t = 准备要买的物品的type 1=武器、2=套装、3=配饰、4=道具、5=蓝图、6=素材、7=大礼包 、8=打开类 、9=资源争夺战个人物品
-- cid = 角色id 4=道具、5=蓝图、6=素材、7=大礼包 cid=0
-- costid = 1, 2, 3 付款方式的id
-- packid=1 装备到背包=1 购买不装备=0
function callPersonalMakeTankRpc(s_id,Type,cId,isBuff)
	print("s_id,Type,cId,packId ====",s_id,Type,cId)
	rpc.safecallload("shop_req_buy", {pid = ptr_cast(game.CurrentState):GetCharacterId(),sid = s_id,t = Type,costid = cId,packid = 1},
				function(data)
					GridPersonalTipsUI.buff_btn.Enable = true
					GridPersonalTipsUI.Buff_buy_btn.Enable = true
					-- if data.error then
						-- MessageBox.ShowWithTimer(1,data.error)
						-- return
					if data.result == -2 or data.result == -3 then
						MessageBox.ShowWithTwoButtons(lang:GetText("你的FC点不足，请充值"),lang:GetText("充值"),lang:GetText("取消"),
						function()
							gui:ShowIE()
						end,
						nil
						)
					else
						print("成功")
						if isBuff then
							updataPersonalInfo(buff_cPage,sType)
						else
							updataPersonalInfo(1,sType)
						end		
						Fill_Header_Team()
						if data.buildTime ~= 0 then
							L_LevelUpEffect.Show_MakeTimeEffect(data)
						end					
					end
				end)
end
p_sCurrency = 5
p_sPrice=  nil
--填充右面的tips的UI界面
function FillGrids_PersonalTips(info,isPersonalTree,isBuff)
	p_saveInfo = info
		
	if isBuff then
		GridPersonalTipsUI.Personal_Tips.Visible = false
		GridPersonalTipsUI.Tips_P_Buff_ui.Visible = true
		GridPersonalTipsUI.Tips_P_Buff_ui.Parent = allteam_source_ui.s_tips
		GridPersonalTipsUI.tips_PB_name.Text = info.display
		GridPersonalTipsUI.tips_PB_description.Text = info.description
		GridPersonalTipsUI.tip_PB_ib.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_haibao.dds", Vector4(0,0,0,0)),}
		GridPersonalTipsUI.addBuff_name.Text = getBuffName[tonumber(info.lid)]
		GridPersonalTipsUI.addBuff_num.Text = math.abs(info.capacity).."%"
		GridPersonalTipsUI.addTime_num.Text = info.time.. lang:GetText("秒")
		local res = info.resPrices[1]
		local fc = info.crPrices[1]
		
		if fc then
			GridPersonalTipsUI.lb_Buff_Fc.Text = fc.cost
			GridPersonalTipsUI.Buff_buy_btn.Enable = true
		else
			GridPersonalTipsUI.Buff_buy_btn.Enable = false
		end
		
		GridPersonalTipsUI.Buff_buy_btn.EventClick = function(sender,e)
			if fc then
				if sender.Enable == true then
					sender.Enable = false
				end
				callPersonalMakeTankRpc(info.sysItemId,9,info.crPrices[combox_BuffSelFcIdx].id,isBuff)
			end
		end
	
		if res then
			GridPersonalTipsUI.lb_canResource.Text = res.cost
			GridPersonalTipsUI.buff_btn.Enable = true
		else
			GridPersonalTipsUI.buff_btn.Enable = false
		end
		
		GridPersonalTipsUI.buff_btn.EventClick = function(sender,e)
			if res then
				if sender.Enable == true then
					sender.Enable = false
				end
				callPersonalMakeTankRpc(info.sysItemId,9,info.resPrices[combox_BuffSelResIdx].id,isBuff)
			end
		end
	else
		GridPersonalTipsUI.Personal_Tips.Visible = true
		GridPersonalTipsUI.Tips_P_Buff_ui.Visible = false
		GridPersonalTipsUI.Personal_Tips.Parent = allteam_source_ui.s_tips
		if isPersonalTree then
			GridPersonalTipsUI.Personal_TankTips.Visible = false
			GridPersonalTipsUI.Tips_P_Tree_ui.Visible = true
			GridPersonalTipsUI.tips_PT_name.Text = info.display
			GridPersonalTipsUI.tips_PT_level.Skin = Skin.itemLevelIcon[info.level]
			GridPersonalTipsUI.ctrl_PT_Icon.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..info.name..".dds")
			GridPersonalTipsUI.tips_PT_description.Text = info.description
		else	
			GridPersonalTipsUI.Personal_TankTips.Visible = true
			GridPersonalTipsUI.Tips_P_Tree_ui.Visible = false
			SelectedTpd_P(pIdx,info)
			GridPersonalTipsUI.tips_P_name.Text = info.display
			GridPersonalTipsUI.tips_P_level.Skin = Skin.itemLevelIcon[info.level]
			GridPersonalTipsUI.ctrl_P_Icon.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..info.name..".dds")
			
			local mode1 = info.resDisPrice
			--建造按钮事件
			
			GridPersonalTipsUI.make_P_btn.EventClick = function()
				if tonumber(info.buycd) > 0 then
					callAddSpeedCDRpc(1,info.playerItemId)
				else
					if mode1 then
						if save_P_res and save_T_res < mode1.cost then
							MessageBox.ShowWithTimer(1,lang:GetText("个人黑晶石不足！"))
						else
							callPersonalMakeTankRpc(info.sysItemId,9,mode1.id)
						end
					end
				end
				
			end
			--升级属性能力按钮事件 
			GridPersonalTipsUI.P_levelUp_btn.EventClick = function(sender,e)
				if IT ~= 0 then	
					if p_saveInfo.value <= 0 then
						MessageBox.ShowWithTimer(1,"数量为0，请先建造至少一个才能升级！")
					else
						if sender.Enable == true then
							sender.Enable = false
						end
						callPersonalNengLiLevelUPRpc(info.playerItemId,p_sCurrency,p_sPrice,IT)
					end	
				end	
			end
			
			GridPersonalTipsUI.lb_P_enterPower:RemoveAll()
			GridPersonalTipsUI.lb_P_enterPower.SelectedIndex = combox_selIdx2-1
			p_sCurrency = getPersonalPrice[combox_selIdx2].cur
			p_sPrice = 	  getPersonalPrice[combox_selIdx2].cost
			--切换价格事件
			GridPersonalTipsUI.lb_P_enterPower.EventValueChanged = function(sender, args)
				GridPersonalTipsUI.P_levelUp_btn.Enable = true
				if sender.SelectedIndex == 0 then
					combox_selIdx2 =  1
					p_sCurrency = getPersonalPrice[combox_selIdx2].cur
					p_sPrice =    getPersonalPrice[combox_selIdx2].cost			
				elseif sender.SelectedIndex == 1 then
					combox_selIdx2 =  2
					p_sCurrency = getPersonalPrice[combox_selIdx2].cur
					p_sPrice =    getPersonalPrice[combox_selIdx2].cost
				elseif sender.SelectedIndex == 2 then
					combox_selIdx2 =  3
					p_sCurrency = getPersonalPrice[combox_selIdx2].cur
					p_sPrice =   getPersonalPrice[combox_selIdx2].cost
					
				elseif sender.SelectedIndex == 3 then
					combox_selIdx2 =  4
					p_sCurrency = getPersonalPrice[combox_selIdx2].cur
					p_sPrice =    getPersonalPrice[combox_selIdx2].cost
					
				elseif sender.SelectedIndex == 4 then
					combox_selIdx2 =  5
					p_sCurrency = getPersonalPrice[combox_selIdx2].cur
					p_sPrice =    getPersonalPrice[combox_selIdx2].cost	
				end
				GridPersonalTipsUI.P_canIcon.Skin = Skin.priceIcon[p_sCurrency]
			end
			GridPersonalTipsUI.lb_P_enterPower.Text = getPersonalPrice[combox_selIdx2].TextPrice
			GridPersonalTipsUI.P_canIcon.Skin = Skin.priceIcon[p_sCurrency]
			for i = 1,#getPersonalPrice, 1 do
				GridPersonalTipsUI.lb_P_enterPower:AddItemWithIcon(getPersonalPrice[i].TextPrice,2)
			end
			
			if tonumber(info.buycd) > 0 then
				--GridPersonalTipsUI.lb_P_canPower.Text = GethourMinuteSeconds(tonumber(info.buycd))
				GridPersonalTipsUI.c_P_icon.Visible = false
				GridPersonalTipsUI.make_P_btn.Text = lang:GetText("加速")
				GridPersonalTipsUI.make_P_btn.Shine = true
				UpdateTimeLable(GridPersonalTipsUI.p_ctrlTimer,tonumber(info.buycd),GridPersonalTipsUI.lb_P_canPower)
				GridPersonalTipsUI.p_ctrlTimer.EventTimeOut = function(sender, e)
					updataPersonalInfo(1,sType)
				end	
			else				
				GridPersonalTipsUI.lb_P_canPower.Text = mode1.cost
				GridPersonalTipsUI.p_ctrlTimer:CleanAll()
				GridPersonalTipsUI.c_P_icon.Visible = true
				GridPersonalTipsUI.make_P_btn.Text = lang:GetText("建造")
				GridPersonalTipsUI.make_P_btn.Shine = false
			end
			
			--GridTipsUI.level_icon.Skin = Skin.levelIcon[info.level]
			for i = 1,4,1 do
				GridPersonalTipsUI["team_nengliExp_P_"..i].Icon = pro_Personal[i]
				--GridPersonalTipsUI["team_nengliExp_P_"..i]..CurrentValue = 0
			end
			if info.performance.power then
				--GridTipsUI.lb_1.Text = info.performance.power.value
				GridPersonalTipsUI.lb_level_P_1.Text = "LV " .. info.performance.power.level
				GridPersonalTipsUI.team_nengliExp_P_1.Visible = true
				GridPersonalTipsUI.team_nengliExp_P_1.MaxValue = info.performance.power.maxExp
				GridPersonalTipsUI.team_nengliExp_P_1.CurrentValue = info.performance.power.curExp
			else
				--GridTipsUI.lb_1.Text = "--"
				GridPersonalTipsUI.lb_level_P_1.Text = "LV --"
				GridPersonalTipsUI.team_nengliExp_P_1.Visible = false
			end
			if info.performance.hp then
				--GridTipsUI.lb_2.Text = info.performance.hp.value .. "HP"
				GridPersonalTipsUI.lb_level_P_2.Text = "LV " .. info.performance.hp.level
				GridPersonalTipsUI.team_nengliExp_P_2.Visible = true
				GridPersonalTipsUI.team_nengliExp_P_2.MaxValue = info.performance.hp.maxExp
				GridPersonalTipsUI.team_nengliExp_P_2.CurrentValue = info.performance.hp.curExp
			else
				--GridTipsUI.lb_2.Text = "--"
				GridPersonalTipsUI.lb_level_P_2.Text = "LV --"
				GridPersonalTipsUI.team_nengliExp_P_2.Visible = false
			end
			if info.performance.fireSpeed then
				--GridTipsUI.lb_3.Text = info.performance.fireSpeed.value
				GridPersonalTipsUI.lb_level_P_3.Text = "LV " .. info.performance.fireSpeed.level
				GridPersonalTipsUI.team_nengliExp_P_3.Visible = true
				GridPersonalTipsUI.team_nengliExp_P_3.MaxValue = info.performance.fireSpeed.maxExp
				GridPersonalTipsUI.team_nengliExp_P_3.CurrentValue = info.performance.fireSpeed.curExp
			else
				--GridTipsUI.lb_3.Text = "--"
				GridPersonalTipsUI.lb_level_P_3.Text = "LV --"
				GridPersonalTipsUI.team_nengliExp_P_3.Visible = false
			end
			if info.performance.moveSpeed then
				--GridTipsUI.lb_4.Text = info.performance.rotateSpeed.value
				GridPersonalTipsUI.lb_level_P_4.Text = "LV " .. info.performance.moveSpeed.level
				GridPersonalTipsUI.team_nengliExp_P_4.Visible = true
				GridPersonalTipsUI.team_nengliExp_P_4.MaxValue = info.performance.moveSpeed.maxExp
				GridPersonalTipsUI.team_nengliExp_P_4.CurrentValue = info.performance.moveSpeed.curExp
			else
				--GridTipsUI.lb_4.Text = "--"
				GridPersonalTipsUI.lb_level_P_4.Text = "LV --"
				GridPersonalTipsUI.team_nengliExp_P_4.Visible = false
			end	
		end
	end
	
end

function SelectedTpd_P(idx,info)
	for i = 0,3,1 do
		GridPersonalTipsUI["xian_P_"..i].Visible = false
	end	
	-- for j = 1,4,1 do
		-- GridPersonalTipsUI["lb_level_P_"..j].TextColor = ARGB(255,0,0,0) 
		-- GridPersonalTipsUI["type_P_text_"..j].TextColor = ARGB(255,0,0,0)
	-- end
	GridPersonalTipsUI["xian_P_"..idx].Visible = true
	GridPersonalTipsUI.P_levelUp_btn.Enable = true
	if idx == 0 then
		if info.performance.power then
			IT = info.performance.power.property
		else
			GridPersonalTipsUI.P_levelUp_btn.Enable = false
		end		
	elseif idx == 1 then
		if info.performance.hp then
			IT = info.performance.hp.property
		else
			GridPersonalTipsUI.levelUp_btn.Enable = false
		end
		
	elseif idx == 2 then
		if  info.performance.fireSpeed then
			IT = info.performance.fireSpeed.property
		else
			GridPersonalTipsUI.P_levelUp_btn.Enable = false
		end
		
	elseif idx == 3 then
		if info.performance.moveSpeed then
			IT = info.performance.moveSpeed.property
		else
			GridPersonalTipsUI.P_levelUp_btn.Enable = false
		end		
	
	end	
	-- GridPersonalTipsUI["lb_level_P_"..(idx+1)].TextColor = ARGB(255,255,255,255) 
	-- GridPersonalTipsUI["type_P_text_"..(idx+1)].TextColor = ARGB(255,255,255,255)
end 
--能力属性选项事件
function onSelectedPersonalNengliChanged(sender)
	pIdx = sender.Index
    SelectedTpd_P(sender.Index,p_saveInfo)
end
GridPersonalTipsUI.tpd_P_nengli.EventSelectedPageChanged = onSelectedPersonalNengliChanged
-- teamId,
-- storageType,
-- teamItemId,
-- manageType,
function repairOrSupply(t_id,sType,tId,mt)
	rpc.safecallload("repair_or_supply", {pid = ptr_cast(game.CurrentState):GetCharacterId(),teamId = t_id,storageType = sType,teamItemId = tId,manageType = mt},
			function(data)
				if data.error then
					MessageBox.ShowWithTimer(1,data.error)
					return
				else
					print("成功")
					updataTeamInfo(1,cType)
				end
			end)
end

--显示仓库防御塔的ui
function ShowStorageTowerUI(parent,dataInfo)
	StorageUI.ctrl_tower_list.Visible = true
    StorageUI.ctrl_tower_list.Parent = parent
    StorageUI.ctrl_wall_list.Visible = false
	StorageUI.ctrl_daoju_list.Visible = false
	local DT = {}
    if dataInfo and dataInfo.teamStorage.attack then
		DT = dataInfo.teamStorage.attack
		--StorageUI.lb_page_number_tower.Text = DT.curPage .. "/" .. DT.pages
		-- StorageUI.btn_front_page_tower.EventClick = function()
			-- if DT.curPage <= 1 then
				-- return
			-- else
				-- local cPage = DT.curPage - 1
				-- StorageUI.lb_page_number_tower.Text = cPage .. "/" .. DT.pages
				-- updataTeamInfo(cType,cPage)
			-- end
		-- end
		-- StorageUI.btn_next_page_tower.EventClick = function()
			-- if DT.curPage >= DT.pages then
				-- return
			-- else
				-- local cPage = DT.curPage + 1
				-- StorageUI.lb_page_number_tower.Text = cPage .. "/" .. DT.pages
				-- updataTeamInfo(cType,cPage)
			-- end
		-- end
		-- StorageUI.fixAll_tower.EventClick = function()
			-- CallRpcBtn(t_id,-1,-1,7,cType)
		-- end
		-- StorageUI.fillAll_tower.EventClick = function()
			-- CallRpcBtn(t_id,-1,-1,6,cType)
		-- end
		print("DT~~~~~",#DT)
		for i = 1,maxCount,1 do
			local ibbtn = ptr_cast(StorageUI.ctrl_tower:GetChildByIndex(i-1))
			if DT[i] then
				ibbtn.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..DT[i].name..".tga")
				if DT[i].value == 0 then
					ibbtn.ItemIcon.alpha = 70
				else
					ibbtn.ItemIcon.alpha = 255
				end
				if i == selected_ibtn_index then
					ibbtn.Selected = true
					FillGrids_tips(DT[selected_ibtn_index])
				else
					ibbtn.Selected = false
				end						
				ibbtn.EventSelected = function(sender, e)
					if StorageUI and sender.Loading == false then
						for j = 1, maxCount do	
							local ib = ptr_cast(StorageUI.ctrl_tower:GetChildByIndex(j - 1))
							if j == i then
								ib.Selected = true
								--StorageUI.lihe_btn.Enable = true
								FillGrids_tips(DT[i])
								selected_ibtn_index = j
							else
								ib.Selected = false
							end
						end
					end		
				end
				StorageUI["lv_Towercrtl"..i].Visible = true
				StorageUI["Level_Tower_"..i].Skin = Skin.itemLevelIcon[tonumber(DT[i].level)]
				StorageUI["grids_num"..i].Visible = true
				--StorageUI["grids_num"..i].Text = DT[i].value 
				--L_LobbyMain.ShowFightnums(StorageUI["grids_num"..i],tonumber(DT[i].value),"team/lb_shop_number01.dds")
				StorageUI["grids_num"..i]:OnDestroy()
				L_Characters.CreatPresentNumCtr(StorageUI["grids_num"..i],tonumber(DT[i].value),90, 0)	
				--ibbtn.Selected = false
				ibbtn.Enable = true
			else
				StorageUI["lv_Towercrtl"..i].Visible = false
				StorageUI["grids_num"..i].Visible = false
				--allteam_source_ui["equipt_icon"..i].Visible = false
				ibbtn.ItemIcon = nil
				ibbtn.Enable = false
			end			
		end
	else
		for i = 1,maxCount,1 do
			local ibbtn = ptr_cast(StorageUI.ctrl_tower:GetChildByIndex(i-1))
			ibbtn.ItemIcon = nil
			ibbtn.Enable = false
		end
	end
end
--显示仓库城墙的ui
function ShowStorageWallUI(parent,dataInfo)
	StorageUI.ctrl_wall_list.Visible = true
    StorageUI.ctrl_wall_list.Parent = parent
    StorageUI.ctrl_tower_list.Visible = false
	StorageUI.ctrl_daoju_list.Visible = false
	local WI = {}
    if dataInfo and dataInfo.teamStorage.defense then
		WI = dataInfo.teamStorage.defense
		if WI[1] then
			print("Wi~~~~~",#WI)
			for i = 1,maxCount,1 do
				local ibbtn = ptr_cast(StorageUI.ctrl_wall:GetChildByIndex(i-1))
				if WI[i] then
					if i == selected_ibtn_index2 then
						ibbtn.Selected = true
						FillGrids_tips(WI[selected_ibtn_index2])
					else
						bbtn.Selected = false
					end
					ibbtn.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..WI[i].name..".tga")
					if WI[i].value == 0 then
						ibbtn.ItemIcon.alpha = 70
					else
						ibbtn.ItemIcon.alpha = 255
					end
					ibbtn.EventSelected = function(sender, e)
						if StorageUI and sender.Loading == false then
							for j = 1, maxCount do	
								local ib = ptr_cast(StorageUI.ctrl_wall:GetChildByIndex(j - 1))
								if j == i then
									ib.Selected = true
									--StorageUI.lihe_btn.Enable = true
									FillGrids_tips(WI[i])
									selected_ibtn_index2 = j
								else
									ib.Selected = false
								end
							end
						end		
						--selected_ibtn_index = index
					end
					
					StorageUI["lv_Wallcrtl"..i].Visible = true
					StorageUI["Level_W_"..i].Skin = Skin.itemLevelIcon[tonumber(WI[i].level)]
					StorageUI["gridsWall_num"..i].Visible = true
					--StorageUI["gridsWall_num"..i].Text = WI[i].value 
					--L_LobbyMain.ShowFightnums(StorageUI["gridsWall_num"..i],tonumber(WI[i].value),"team/lb_shop_number01.dds")	
					StorageUI["gridsWall_num"..i]:OnDestroy()
					L_Characters.CreatPresentNumCtr(StorageUI["gridsWall_num"..i],tonumber(WI[i].value),90, 0)
					--ibbtn.Selected = false
					ibbtn.Enable = true
				else
					StorageUI["lv_Wallcrtl"..i].Visible = false
					StorageUI["gridsWall_num"..i].Visible = false
					ibbtn.ItemIcon = nil
					ibbtn.Enable = false
				end			
			end
		else
			for i = 1,maxCount,1 do
				local ibb = ptr_cast(StorageUI.ctrl_wall:GetChildByIndex(i-1))
				ibb.ItemIcon = nil
				ibb.Enable = false
			end
		end		
	else
		for i = 1,maxCount,1 do
			local ibb = ptr_cast(StorageUI.ctrl_wall:GetChildByIndex(i-1))
			ibb.ItemIcon = nil
			ibb.Enable = false
		end
	end
 end
 --显示仓库挖掘机的ui
function ShowStorageDaojuUI(parent,dataInfo)
	StorageUI.ctrl_daoju_list.Visible = true
    StorageUI.ctrl_daoju_list.Parent = parent
    StorageUI.ctrl_tower_list.Visible = false
	StorageUI.ctrl_wall_list.Visible = false
	local MT = {}
    if dataInfo and dataInfo.teamStorage.machine then
		MT = dataInfo.teamStorage.machine
		--StorageUI.lb_page_number_tower.Text = DT.curPage .. "/" .. DT.pages
		-- StorageUI.btn_front_page_tower.EventClick = function()
			-- if DT.curPage <= 1 then
				-- return
			-- else
				-- local cPage = DT.curPage - 1
				-- StorageUI.lb_page_number_tower.Text = cPage .. "/" .. DT.pages
				-- updataTeamInfo(cType,cPage)
			-- end
		-- end
		-- StorageUI.btn_next_page_tower.EventClick = function()
			-- if DT.curPage >= DT.pages then
				-- return
			-- else
				-- local cPage = DT.curPage + 1
				-- StorageUI.lb_page_number_tower.Text = cPage .. "/" .. DT.pages
				-- updataTeamInfo(cType,cPage)
			-- end
		-- end
		-- StorageUI.fixAll_tower.EventClick = function()
			-- CallRpcBtn(t_id,-1,-1,7,cType)
		-- end
		-- StorageUI.fillAll_tower.EventClick = function()
			-- CallRpcBtn(t_id,-1,-1,6,cType)
		-- end
		print("scene~~~~~",#MT)
		for i = 1,maxCount,1 do
			local ibbtn = ptr_cast(StorageUI.ctrl_daoju:GetChildByIndex(i-1))
			if MT[i] then
				ibbtn.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..MT[i].name..".tga")
				if MT[i].value == 0 then
					ibbtn.ItemIcon.alpha = 70
				else
					ibbtn.ItemIcon.alpha = 255
				end
				if i == selected_ibtn_index4 then
					ibbtn.Selected = true
					FillGrids_tips(MT[selected_ibtn_index4])
				else
					ibbtn.Selected = false
				end			
				
				ibbtn.EventSelected = function(sender, e)
					if StorageUI and sender.Loading == false then
						for j = 1, maxCount do	
							local ib = ptr_cast(StorageUI.ctrl_daoju:GetChildByIndex(j - 1))
							if j == i then
								ib.Selected = true
								--StorageUI.lihe_btn.Enable = true
								FillGrids_tips(MT[i])
								selected_ibtn_index4 = j
							else
								ib.Selected = false
							end
						end
					end		
				end
				StorageUI["lv_Machinecrtl"..i].Visible = true
				StorageUI["Level_M_"..i].Skin = Skin.itemLevelIcon[tonumber(MT[i].level)]
				StorageUI["gridsMachine_num"..i].Visible = true
				--StorageUI["gridsMachine_num"..i].Text = MT[i].value 
				--L_LobbyMain.ShowFightnums(StorageUI["gridsMachine_num"..i],tonumber(MT[i].value),"team/lb_shop_number01.dds")
				StorageUI["gridsMachine_num"..i]:OnDestroy()
				L_Characters.CreatPresentNumCtr(StorageUI["gridsMachine_num"..i],tonumber(MT[i].value),90, 0)
				--ibbtn.Selected = false
				ibbtn.Enable = true
			else
				StorageUI["lv_Machinecrtl"..i].Visible = false
				StorageUI["gridsMachine_num"..i].Visible = false
				--allteam_source_ui["equipt_icon"..i].Visible = false
				ibbtn.ItemIcon = nil
				ibbtn.Enable = false
			end			
		end
	else
		for i = 1,maxCount,1 do
			local ibbtn = ptr_cast(StorageUI.ctrl_daoju:GetChildByIndex(i-1))
			ibbtn.ItemIcon = nil
			ibbtn.Enable = false
		end
	end	
 end
--战队资源战仓库区域选择
function SelectedPageStorage(idx,TeamWar_info)
	if TeamWar_info then
		if idx == 0 then
			storageIndex = 0
			ShowStorageTowerUI(allteam_source_ui.tpg_tower,TeamWar_info)
		elseif idx == 1 then
			storageIndex = 1
			ShowStorageWallUI(allteam_source_ui.tpg_wall,TeamWar_info)
		elseif idx == 2 then
			storageIndex = 2
			ShowStorageDaojuUI(allteam_source_ui.tpg_scene,TeamWar_info)
		end    
	end
end

--战队资源战仓库区域选择事件
function onSelectedStoragePageChanged(sender)
	storageIndex = sender.Index
	if storageIndex == 0 then
		cType = 2
	elseif storageIndex == 1 then
		cType = 1
	elseif storageIndex == 2 then
		cType = 5
	end
	GridTipsUI.tpd_nengli.Index = 0
	updataTeamInfo(cPage,cType)
   -- SelectedPageStorage(sender.Index,TeamWar_info)
end
allteam_source_ui.tpd_storage.EventSelectedPageChanged = onSelectedStoragePageChanged

------------ tian ↑ ----------------------------------------------------------------

function FillTeam(flag)
	local is_Fill_Header_Team = true
	if team_ui then
		if allteam_source_ui.allteam.Visible then
			Fill_Header_Team()
			is_Fill_Header_Team = false
		end
		if is_in_invite then
			L_LobbyMain.LobbyMainWin.btn_my.PushDown = false
			L_LobbyMain.LobbyMainWin.btn_list.PushDown = false
			L_LobbyMain.LobbyMainWin.btn_my.PushDown = false
			L_LobbyMain.LobbyMainWin.btn_sourcefight.PushDown = true
			L_LobbyMain.LobbyMainWin.btn_list.PushDown = false
			
			team_list_ui.root.Visible = false
			team_ui.my_team.Visible = false
			allteam_source_ui.allteam.Visible = true
			my_source_ui.root.Visible = false
		end
		
	
		if mode == 1 or mode == 3 then
			rpc.safecallload("team_info", {pid = ptr_cast(game.CurrentState):GetCharacterId()},
			function(data)
				team_data = data.team
				if team_data ~= nil and team_data[1] ~= nil then
					if is_Fill_Header_Team then
						Fill_Header_Team()
					end
					if mode == 2 then
						return
					end
					team_logo = team_data[3]
					p_job = team_data[10]
					team_description = team_data[4]
					t_rank = team_data[17]
					if team_ui and p_job == 4 then
						team_ui.revise_btn.Visible = true
						team_ui.request.Visible = true
						-- L_LobbyMain.LobbyMainWin.change_teaminfo.Enable = true
					elseif team_ui and p_job ~= 4 then
						team_ui.revise_btn.Visible = false
						team_ui.request.Visible = false
						-- L_LobbyMain.LobbyMainWin.change_teaminfo.Enable = false
					end
					if team_ui and p_job == 3 then
						team_ui.request.Visible = true
					end
					t_id = team_data[1]
					local state = ptr_cast(game.CurrentState)
					if state then
						if is_in_invite and state.source_is_create then
						
						elseif is_in_invite then
							state:GetBattleGroupJoin(invite_group)
						end
					end
					max_num = team_data[13]
					te_num = team_data[12]
					pt_id = data.application[3]
					if mode == 1 then
						team_ui.my_team.Visible = true
						team_ui.no_team.Visible = false
						team_ui.exist_team.Visible = true
						if my_mode == 1 then
							team_ui.info_btn.PushDown = true
							team_ui.p_btn.PushDown = false
							team_ui.gongxian_btn.PushDown = false
							team_ui.team_info.Visible = true
							team_ui.team_person_info.Visible = false
							team_ui.team_gongxian_info.Visible = false
							team_ui.quit1_btn.Visible = true
							
							team_ui.c_jieshao.Visible = true
							team_ui.c_zhanji.Visible = false
							team_ui.c_gonggao.Visible = false
							team_ui.jieshao_btn.PushDown = true
							team_ui.zhanji_btn.PushDown = false
							team_ui.gonggao_btn.PushDown = false
							
							team_ui.team_name.Text = team_data[2]
							team_ui.team_name_black.Text = team_data[2]
							team_ui.team_image.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/team/FightHead/lb_squad_touxiang_"..team_data[3]..".dds", Vector4(0, 0, 0, 0)),}
							team_ui.team_level.Text = team_data[18]
							team_ui.team_level_black.Text = team_data[18]
							if team_data[18] ~= max_fightteam_level then
								team_ui.exp_font.Size = Vector2(200*(team_data[19]/team_data[20]), 19)
								team_ui.team_exp.Text = team_data[19].."/"..team_data[20]
							else
								team_ui.exp_font.Size = Vector2(0, 19)
								team_ui.team_exp.Text = "Max"
							end	
							team_ui.team_fightnum.Text = team_data[21]
							team_ui.team_fightnum_black.Text = team_data[21]
							if team_data[22] ~= 0 then
								team_ui.team_num.Text = team_data[22]
								team_ui.team_num_black.Text = team_data[22]
							else
								team_ui.team_num.Text = lang:GetText("800名以外")
								team_ui.team_num_black.Text = lang:GetText("800名以外")
							end
							team_ui.team_fightnum_num.Text = team_data[24]
							if team_data[23] > 0 then
								team_ui.team_num_up.Visible = true
								team_ui.team_num_up.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ToolTips/lb_tooltips_jiantou_green.dds", Vector4(0, 0, 0, 0)),}
							elseif team_data[23] < 0 then
								team_ui.team_num_up.Visible = true
								team_ui.team_num_up.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ToolTips/lb_tooltips_jiantou_red.dds", Vector4(0, 0, 0, 0)),}
							else
								team_ui.team_num_up.Visible = false
							end
							if team_data[25] > 0 then
								team_ui.team_fightnum_num_up.Visible = true
								team_ui.team_fightnum_num_up.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ToolTips/lb_tooltips_jiantou_green.dds", Vector4(0, 0, 0, 0)),}
							elseif team_data[25] < 0 then
								team_ui.team_fightnum_num_up.Visible = true
								team_ui.team_fightnum_num_up.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ToolTips/lb_tooltips_jiantou_red.dds", Vector4(0, 0, 0, 0)),}
							else
								team_ui.team_fightnum_num_up.Visible = false
							end
							num = data.num
							team_ui.request_num_btn.Text = lang:GetText(num)
							if flag == true then
								FillRequestList()
							end
							if num == 0 then
								team_ui.request.Enable = false
								team_ui.request_num_btn.Visible = false
							else
								team_ui.request.Enable = true
								team_ui.request_num_btn.Visible = true
							end
							
							if team_data[8] == 0 then
								team_ui.win_percent.Text = "0.0%"
								team_ui.win_percent_black.Text = "0.0%"
							else
								team_ui.win_percent.Text = team_data[9]
								team_ui.win_percent_black.Text = team_data[9]
							end
							team_ui.win_lose.Text = team_data[7].."/"..(team_data[8]-team_data[7])
							team_ui.win_lose_black.Text = team_data[7].."/"..(team_data[8]-team_data[7])
							team_ui.count_person.Text = team_data[12].."/"..team_data[13]
							team_ui.count_person_black.Text = team_data[12].."/"..team_data[13]
							
							team_ui.lead.Text = team_data[14]
							team_ui.lead_black.Text = team_data[14]						
							team_ui.time.Text = team_data[11]
							team_ui.time_black.Text = team_data[11]
							team_ui.jieshao.Text = team_data[4]
							if config.UserLanguage == language_list[2] then
								team_ui.level.Text = lang:GetText("级")..team_data[17]
								team_ui.level_black.Text = lang:GetText("级")..team_data[17]
							else
								team_ui.level.Text = team_data[17]..lang:GetText("级")
								team_ui.level_black.Text = team_data[17]..lang:GetText("级")
							end
							team_ui.address.Text = team_data[16]
							team_ui.address_black.Text = team_data[16]
							my_battle_province = team_data[15]
							my_battle_city = team_data[16]
							my_battle_name = team_data[2]	
						elseif my_mode == 2 then
							team_ui.info_btn.PushDown = false
							team_ui.p_btn.PushDown = true
							team_ui.gongxian_btn.PushDown = false
							team_ui.team_info.Visible = false
							team_ui.team_person_info.Visible = true
							team_ui.team_gongxian_info.Visible = false
							team_ui.quit1_btn.Visible = false
							local cbx = team_ui.change_job
							cbx:RemoveAll()
							cbx:AddItem(lang:GetText("队长"))
							cbx:AddItem(lang:GetText("管理员"))
							cbx:AddItem(lang:GetText("普通队员"))
							if p_job == 4 then
								team_ui.l_change_black.Visible = true
								team_ui.l_change.Visible = true
								team_ui.change_job.Visible = true
							else
								team_ui.l_change_black.Visible = false
								team_ui.l_change.Visible = false
								team_ui.change_job.Visible = false
							end
							rpc.safecallload("team_member_list", {tid = t_id, page = t_page},
							function(data)
								t_pages = data.pages
								team_ui.page_info.Text = t_page.."/"..t_pages
								local member = data.team
								local cbx = team_ui.p_info
								cbx.PopupMenu.Style = "Gui.MenuNew"
								cbx.PopupMenu:RemoveAll()
								cbx.PopupMenu:AddItem(lang:GetText("私聊"))
								cbx.PopupMenu:AddItem(lang:GetText("加为好友"))
								cbx.PopupMenu:AddItem(lang:GetText("查看信息"))
								if p_job == 4 or p_job == 3 then
									cbx.PopupMenu:AddItem(lang:GetText("踢出战队"))
								end
								cbx.EventRightClick = function(sender, e)
									print("sender.SelectingIndex = "..sender.SelectingIndex)
									print("Max_item = "..Max_item)
									if sender.PopupMenu and sender.PointedItem and sender.PointedItem.CanSelect then
										sender.PopupMenu:Open()
									end
								end    	
								cbx.PopupMenu.EventClick = function(sender, e)
									local item = ptr_cast(sender.Tag)
									if sender.SelectedIndex == 0 and item and item.NAME ~= "" then
										L_LobbyMain.ChatPrivate(item.NAME,item.VIP,item.ID)
									elseif sender.SelectedIndex == 1 and item and item.NAME ~= "" then
										  L_Friends.FriendsAdd(nil,item.NAME)
									elseif sender.SelectedIndex == 2 and item and item.ID ~= 0 then
										if item.ID == ptr_cast(game.CurrentState):GetCharacterId() then
											L_PersonalInfo.Show(L_LobbyMain.LobbyMainWin_Boddy.LobbyMainWin_Boddy_Root)
											L_LobbyMain.InitPersonalInfoRPCInfo()
											lg:SetLobbyModules(12)
											L_LobbyMain.current_chosse_main_page = 12
											L_PersonalInfo.SynchronousClassButton()
											L_LobbyMain.FillClassBag(ptr_cast(game.CurrentState):GetCharacterId(), L_LobbyMain.current_choose_class)
										else
											L_PersonalInfo.ShowPerson(L_LobbyMain.LobbyMainWin_Boddy.LobbyMainWin_Boddy_Root, item.ID, "")
										end
										Hide()
									elseif sender.SelectedIndex == 3 and item and item.ID ~= 0 then 
										if item.ID == ptr_cast(game.CurrentState):GetCharacterId() then
											MessageBox.ShowWithTimer(1,lang:GetText("你不能踢出自己"))
										else
											MessageBox.ShowWithTwoButtons(lang:GetText("确定要将")..item.NAME.."\n"..lang:GetText("踢出战队吗"),lang:GetText("确定"),lang:GetText("取消"),
											function()
												rpc.safecallload("team_request_op",{tid = t_id, pids = item.ID, pid = ptr_cast(game.CurrentState):GetCharacterId(), action = "kick", job = 4},
												function(data)
													MessageBox.ShowWithTimer(3,item.NAME..lang:GetText("已被踢出战队"))
													FillTeam()
												end)
											end,
											nil
											)

										end
									end
								end
								cbx:DeleteAll()
								local i = 1
								for _,v in ipairs(member.member) do
									local sub_item = cbx:AddItem(cbx.RootItem)
									if v[5] == 1 then
										sub_item.SpecialA = false
									else
										sub_item.SpecialA = true
									end
									sub_item.ID = v[1]
									sub_item.NAME = v[4]
									sub_item.VIP = v[12]
									sub_item:AddSubItem(nil)
									sub_item:AddSubItem(nil)
									if v[12] > 0 then
										sub_item:SetIcon(0, Gui.Icon("LobbyUI/vip/vip/VIP_button_0"..v[12].."_normal.dds"),Vector4(0, 0, 0, 0))
									end
									L_WarZone.FillLevel(v[3], v[11], sub_item ,"d",2,1)
									sub_item:AddSubItem(v[4])
									sub_item:AddSubItem(nil)
									if v[16] == 1 then
										sub_item:SetIcon(4,Gui.Icon("LobbyUI/team/NewFight/lb_squad_new_ico.dds"), Vector4(0, 0, 0, 0))
									end
									if v[2] == 4 then
										sub_item:SetIcon(4,Gui.Icon("LobbyUI/team/NewFight/lb_squad_leader_ico.dds"), Vector4(0, 0, 0, 0))
									end
									
									if v[2] == 4 then
										sub_item:AddSubItem(lang:GetText("队长"))
									elseif v[2] == 3 then
										sub_item:AddSubItem(lang:GetText("管理员"))
									else
										sub_item:AddSubItem(lang:GetText("普通队员"))
									end
									sub_item:AddSubItem(v[13])
									sub_item:AddSubItem(v[14])
									sub_item:AddSubItem(v[17])
									sub_item:AddSubItem(v[6])
									sub_item:AddSubItem(v[7].."/"..v[8])
									sub_item:AddSubItem(v[9])
									sub_item:AddSubItem(v[15])
									
									local num = 5
									sub_item.LV_BackgroundImage = Gui.Image("LobbyUI/lv"..(math.floor((v[3] - 1)/num)*num+1).."-"..(math.ceil(v[3]/num)*num)..".dds", Vector4(0, 0, 0, 0), Vector4(0, 0, 1, 1))
									sub_item.LV_localtion = Vector2(40,0)
									sub_item.LV_Size = Vector2(36,33)
									if v[2] == 4 or v[2] == 3 then
										sub_item:SetSubItemColor(3, ARGB(255,239,191,12))
										sub_item:SetSubItemColor(5, ARGB(255,239,191,12))	
										sub_item:SetSubItemColor(6, ARGB(255,239,191,12))	
										sub_item:SetSubItemColor(7, ARGB(255,239,191,12))	
										sub_item:SetSubItemColor(8, ARGB(255,239,191,12))	
										sub_item:SetSubItemColor(9, ARGB(255,239,191,12))	
										sub_item:SetSubItemColor(10, ARGB(255,239,191,12))	
										sub_item:SetSubItemColor(11, ARGB(255,239,191,12))
										sub_item:SetSubItemColor(12, ARGB(255,239,191,12))		
									end
									if i % 2 == 1 then
										sub_item.BGSkin = Skin.ListItemSkin_Single
									else
										sub_item.BGSkin = Skin.ListItemSkin_Double
									end
									i = i + 1
								end
								Max_item = i - 1 
								if i < 10 then
									local j 
									for j = i ,9 do
										local sub_item = cbx:AddItem(cbx.RootItem)
										sub_item.CanSelect = false
										if j % 2 == 1 then
											sub_item.BGSkin = Skin.ListItemSkin_Single
										else
											sub_item.BGSkin = Skin.ListItemSkin_Double
										end
									end
								end
							end)
						elseif my_mode == 3 then
							team_ui.info_btn.PushDown = false
							team_ui.p_btn.PushDown = false
							team_ui.gongxian_btn.PushDown = true
							team_ui.team_info.Visible = false
							team_ui.team_person_info.Visible = false
							team_ui.team_gongxian_info.Visible = true
							team_ui.quit1_btn.Visible = false
							rpc.safecallload("team_contribution_get", {tid = t_id, ptid = pt_id, pid = ptr_cast(game.CurrentState):GetCharacterId()},
								function(data)
									local info = data.info
									team_ui.team_level2.Text = "Lv"..info[1]
									team_ui.team_level2_black.Text = "Lv"..info[1]
									if info[1] ~= max_fightteam_level then
										-- team_ui.exp_font2.Size = Vector2(72, 200*(info[2]/info[3]))
										print("info[2]/info[3]"..info[2]/info[3])
										team_ui.exp_font2.Location = Vector2(104, 28+200*(1-info[2]/info[3]))
										team_ui.exp_font2.Size = Vector2(72, 200*(info[2]/info[3]))
										team_ui.exp_font2.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_bar01_content.dds", Vector4(0, 0, 0, 0), Vector4(0, (1-info[2]/info[3]),1, 1)),}
										team_ui.exp_full.Visible = false
										team_ui.team_exp2.Text = info[2].."/"..info[3]
									else
										team_ui.exp_font2.Size = Vector2(0, 0)
										team_ui.exp_full.Visible = true
										team_ui.team_exp2.Text = "Max"
									end
									team_ui.team_gongxian2.Text = info[4]
									team_ui.team_gongxian2_black.Text = info[4]
									team_ui.my_gongxian2.Text = info[5]
									team_ui.my_gongxian2_black.Text = info[5]
									if info[4] > info[5] then
										team_ui.l_gongxian.TextColor = ARGB(255, 251, 14, 14)
										team_ui.team_gongxian2.TextColor = ARGB(255, 251, 14, 14)
									else
										team_ui.l_gongxian.TextColor =  ARGB(255, 255, 103, 1)
										team_ui.team_gongxian2.TextColor = ARGB(255, 255, 187, 0)
									end
									my_contribution = info[5]
									team_ui.xunzhang.Text = info[6]
									myteam_level = info[1]
									current_level = myteam_level
									if info[7] ~= 0 then
										team_ui.get_battle_reward.Enable = false
										team_ui.get_battle_reward.blink = false
									else
										team_ui.get_battle_reward.Enable = true
										team_ui.get_battle_reward.blink = true
									end
									FillBuffList()
								end)
						end
						if is_exit_room then
							mode = 1
							
							L_FightTeam.team_list_ui.root.Visible = false
							L_FightTeam.team_ui.my_team.Visible = false
							L_FightTeam.allteam_source_ui.root.Visible = false
							L_FightTeam.my_source_ui.root.Visible = false
							L_FightTeam.my_source_shop.root.Visible = false
							L_LobbyMain.LobbyMainWin.btn_sourcefight.PushDown = false
							L_LobbyMain.LobbyMainWin.btn_my.PushDown = false
							L_LobbyMain.LobbyMainWin.btn_list.PushDown = false
							
							L_LobbyMain.LobbyMainWin.btn_my.PushDown = true
							L_LobbyMain.LobbyMainWin.btn_list.PushDown = false
							L_LobbyMain.LobbyMainWin.btn_sourcefight.PushDown = false
						
							team_list_ui.root.Visible = false
							team_ui.my_team.Visible = true
							allteam_source_ui.allteam.Visible = false
							is_exit_room = false
							
							return
						end
					elseif mode == 3 then
						-- if is_exit_room then
							-- mode = 1
							-- L_LobbyMain.LobbyMainWin.btn_my.PushDown = true
							-- L_LobbyMain.LobbyMainWin.btn_list.PushDown = false
							-- L_LobbyMain.LobbyMainWin.btn_sourcefight.PushDown = false
							
							-- team_list_ui.root.Visible = false
							-- team_ui.my_team.Visible = true
							-- allteam_source_ui.allteam.Visible = false
							-- is_exit_room = false
							-- return
						-- end
						if is_first_in then
							if config:GetUISystemFlag(3) == 0 then
								allteam_source_ui.root.Visible = false
								allteam_source_ui.allteam.Visible = false
								team_list_ui.root.Visible = false
								team_ui.my_team.Visible = true
								L_LobbyMain.LobbyMainWin.btn_my.PushDown = true
								L_LobbyMain.LobbyMainWin.btn_list.PushDown = false
								L_LobbyMain.LobbyMainWin.btn_sourcefight.PushDown = false
								L_LobbyMain.LobbyMainWin.btn_my.Visible = true
								L_LobbyMain.LobbyMainWin.btn_sourcefight.Visible = false
								L_LobbyMain.LobbyMainWin.btn_list.Visible = true
								L_FightTeam.mode = 1
								L_FightTeam.FillTeam()
							elseif config:GetUISystemFlag(3) == 1 then
								allteam_source_ui.root.Visible = true
								allteam_source_ui.allteam.Visible = true
								team_list_ui.root.Visible = false
								team_ui.my_team.Visible = false
								L_LobbyMain.LobbyMainWin.btn_my.PushDown = false
								L_LobbyMain.LobbyMainWin.btn_list.PushDown = false
								L_LobbyMain.LobbyMainWin.btn_sourcefight.PushDown = true
								L_LobbyMain.LobbyMainWin.btn_my.Visible = true
								L_LobbyMain.LobbyMainWin.btn_sourcefight.Visible = true
								L_LobbyMain.LobbyMainWin.btn_list.Visible = true
							end
							is_first_in = false
						end
					end
				else
					team_data = nil
					team_ui.my_team.Visible = true
					team_ui.no_team.Visible = true
					team_ui.exist_team.Visible = false
					allteam_source_ui.root.Visible = false
					is_first_in = false
					if is_in_invite then
						local state = ptr_cast(game.CurrentState)
						state.is_fight_team_server = false
						is_in_invite = false
						MessageBox.ShowWithConfirm(lang:GetText("您已退出战队,无法加入!"))
					end	
					if mode ~= 1 then
						return
					end
					L_LobbyMain.LobbyMainWin.LobbyMainWin_Header_Team.Visible = false
					L_LobbyMain.LobbyMainWin.lb_Announcement.Size = Vector2(390, 35)
					L_LobbyMain.LobbyMainWin.lb_Announcement.Location = Vector2(483, 180)
				end
			end)
		elseif mode == 2 then
			if mode ~= 2 then
				return
			end
			FillTeamList()
		end
	end
end

function FillRequestList()
	rpc.safecallload("team_request_list", {tid = t_id , page = request_page},
	function(data)
		local requests = data.requests
		local cbx = request_list_ui.p_reques
		request_page = data.page
		request_pages = data.pages
		request_list_ui.m_PageDisplay.Text = request_page.."/"..request_pages
		cbx:DeleteAll()
		cbx:DeleteColumns()
		cbx:AddColumn("",50, "kAlignRightMiddle")
		cbx:AddColumn("",30, "kAlignLeftMiddle")
		cbx:AddColumn("",20, "kAlignRightMiddle")
		cbx:AddColumn("",20, "kAlignLeftMiddle")
		cbx:AddColumn(lang:GetText("玩家"),170, "kAlignCenterMiddle")
		cbx:AddColumn(lang:GetText("综合战斗力"),128, "kAlignCenterMiddle")
		cbx:AddColumn(lang:GetText("胜率"),82, "kAlignCenterMiddle")
		cbx:AddColumn(lang:GetText("申请时间"),111, "kAlignCenterMiddle")					
		local i = 1
		cbx.EventRightClick = function(sender, e)
			sender.PopupMenu:RemoveAll()
			sender.PopupMenu:AddItem(lang:GetText("私聊"))
			sender.PopupMenu:AddItem(lang:GetText("加为好友"))
			sender.PopupMenu:AddItem(lang:GetText("查看信息"))
			sender.PopupMenu.Style = "Gui.MenuNew"
			if sender.PopupMenu and sender.PointedItem and sender.PointedItem.CanSelect then
				sender.PopupMenu:Open()
			end
		end    	
		cbx.PopupMenu.EventClick = function(sender, e)
			local item = ptr_cast(sender.Tag)
			if sender.SelectedIndex == 0 and item and item.NAME ~= "" then
				L_LobbyMain.ChatPrivate(item.NAME,item.VIP,item.ID)
				if request_list_ui then
					request_list_ui.root.Parent = nil
				end
			elseif sender.SelectedIndex == 1 and item and item.NAME ~= "" then
				  L_Friends.FriendsAdd(nil,item.NAME)
			elseif sender.SelectedIndex == 2 and item and item.ID ~= 0 then
				if item.ID == ptr_cast(game.CurrentState):GetCharacterId() then
					L_PersonalInfo.Show(L_LobbyMain.LobbyMainWin_Boddy.LobbyMainWin_Boddy_Root)
					L_LobbyMain.InitPersonalInfoRPCInfo()
					lg:SetLobbyModules(12)
					L_LobbyMain.current_chosse_main_page = 12
					L_PersonalInfo.SynchronousClassButton()
					L_LobbyMain.FillClassBag(ptr_cast(game.CurrentState):GetCharacterId(), L_LobbyMain.current_choose_class)
				else
					L_PersonalInfo.ShowPerson(L_LobbyMain.LobbyMainWin_Boddy.LobbyMainWin_Boddy_Root, item.ID, "")
				end
				Hide()
			end
		end
		cbx:DeleteAll()
		for _,v in ipairs(requests) do
			local sub_item = cbx:AddItem(cbx.RootItem)
			sub_item.CheckBoxSize = Vector2(34, 34)
			sub_item.CheckBoxLocation = Vector2(10, 0)
			sub_item.CheckVisible = true
			sub_item:AddSubItem(nil)
			sub_item:AddSubItem(nil)
			sub_item:AddSubItem(nil)
			if v[2] > 0 then
				sub_item:SetIcon(1, Gui.Icon("LobbyUI/vip/vip/VIP_button_0"..v[2].."_normal.dds"),Vector4(0, 0, 0, 0))
			end
			L_WarZone.FillLevel(v[3], v[4], sub_item)
			sub_item:AddSubItem(v[5])
			sub_item:AddSubItem(v[7])
			local win_rate = v[8]*100
			sub_item:AddSubItem(win_rate.."%")
			sub_item:AddSubItem(v[6])
			sub_item.ID = v[1]
			sub_item.NAME = v[5]
			sub_item.VIP = v[2]
			if i % 2 == 1 then
				sub_item.BGSkin = Skin.ListItemSkin_Single
			else
				sub_item.BGSkin = Skin.ListItemSkin_Double
			end
			i = i + 1
		end
		if i < 11 then
			local j 
			for j = i ,10 do
				local sub_item = cbx:AddItem(cbx.RootItem)
				sub_item.CanSelect = false
				sub_item.CheckBoxSize = Vector2(0, 0)
				sub_item.CheckVisible = false
				if j % 2 == 1 then
					sub_item.BGSkin = Skin.ListItemSkin_Single
				else
					sub_item.BGSkin = Skin.ListItemSkin_Double
				end
				sub_item.ID = 0
			end
		end
		request_list_ui.t1.Text = num..lang:GetText("位玩家申请加入战队")
		request_list_ui.t2.Text = lang:GetText("你还可以添加")..(max_num-te_num)..lang:GetText("位战队成员")
	end)
end

function FillTeamList()
	if L_LobbyMain.current_chosse_main_page == 2 then
		if L_LobbyMain.LobbyMainWin.LobbyMainWin_Header_Team.Visible then
			team_list_ui.btn_Close.Visible = false
		else
			team_list_ui.btn_Close.Visible = true
		end
	else
		team_list_ui.btn_Close.Visible = false
	end	
	rpc.safecallload("get_team_top", {pid = ptr_cast(game.CurrentState):GetCharacterId(), type = team_list_type , pvc = s_province, cty = s_city, page = rank_select_page, self = is_self, name = s_name},
	function(data)
		local i = 1
		local ltv = team_list_ui.t_list
		if not data.data[2] then
			if search_type == 1 then
				team_list_ui.failed_lab.Location = Vector2(827, 1)
				team_list_ui.failed_lab.Text = lang:GetText("该地区没有战队")
			else
				team_list_ui.failed_lab.Location = Vector2(350, 453)
				team_list_ui.failed_lab.Text = lang:GetText("未找到该战队")
			end
			team_list_ui.failed_lab.Visible = true
			team_list_ui.Event:CleanAll()
			team_list_ui.Event:AddTime(5)
		else
			team_list_ui.failed_lab.Visible = false
		end
		ltv:DeleteAll()
		for _,v in ipairs(data.data) do
			if i ~= 1 then
				local sub_item = ltv:AddItem(ltv.RootItem, nil)
				sub_item:AddSubItem(v[1])
				sub_item:SetIcon(2, Gui.Icon("LobbyUI/team/FightHead/lb_squad_touxiang_"..v[3]..".dds"))
				sub_item:AddSubItem(v[2])
				sub_item:AddSubItem(v[4])
				sub_item:AddSubItem(v[5].."/"..v[6] - v[5])
				sub_item:AddSubItem(nil)
				sub_item:AddSubItem(nil)
				sub_item:AddSubItem(v[8])
				sub_item:AddSubItem(v[9].."/"..v[10])
				if config.UserLanguage == language_list[2] then
					sub_item:AddSubItem(lang:GetText("级")..v[11])
				else
					sub_item:AddSubItem(v[11]..lang:GetText("级"))
				end
				sub_item:AddSubItem(v[12])
				sub_item:AddSubItem(v[13])
				sub_item.ID = v[14]
				sub_item.NAME = v[15]
				local temp = (v[7] - (v[7] % 10)) / 100
				local icon1 =  Gui.Icon("LobbyUI/WarZone/lb_summary_number_6c.dds", Vector4(0, 0, 0, 0),Vector4(temp, 0, temp + 0.1, 1))
				local icon2 =  Gui.Icon("LobbyUI/WarZone/lb_summary_number_7c.dds", Vector4(0, 0, 0, 0),Vector4(temp, 0, temp + 0.1, 1))
				sub_item:SetIcon(6, icon1, icon2)
				temp = v[7] % 10 / 10
				icon1 =  Gui.Icon("LobbyUI/WarZone/lb_summary_number_6c.dds", Vector4(0, 0, 0, 0),Vector4(temp, 0, temp + 0.1, 1))
				icon2 =  Gui.Icon("LobbyUI/WarZone/lb_summary_number_7c.dds", Vector4(0, 0, 0, 0),Vector4(temp, 0, temp + 0.1, 1))
				sub_item:SetIcon(7, icon1, icon2)
				if i % 2 == 1 then
					sub_item.BGSkin = Skin.ListItemSkin_Single
				else
					sub_item.BGSkin = Skin.ListItemSkin_Double
				end
			end
			i = i + 1
		end
		if i < 10 then
			local j 
			for j = i ,9 do
				local sub_item = ltv:AddItem(ltv.RootItem)
				sub_item.CanSelect = false
				if j % 2 == 1 then
					sub_item.BGSkin = Skin.ListItemSkin_Single
				else
					sub_item.BGSkin = Skin.ListItemSkin_Double
				end
			end
		end
		team_list_ui.tbx_page.Text = data.page
		team_list_ui.m_PageDisplay.Text = data.page.."/"..data.pages
		rank_select_page = data.page
		rank_select_pages = data.pages
		team_ui.my_team.Visible = false
	end)
end

function Set_type_btn()
	for i = 1, 4 do
		if i == team_list_type then
			team_list_ui["type_btn_"..i].PushDown = true
		else
			team_list_ui["type_btn_"..i].PushDown = false
		end
	end
	FillTeam()
end

function FillGongGao()
	team_ui.scrollLayout_gonggao:OnDestroy()
	rpc.safecallload("team_proclamation_list", {tid = t_id},
	function(data)
		local list = data.list
		local num = 0
		for i, v in ipairs(list) do
			local new_gonggao = SpawnNewGongGao(v[1])
			new_gonggao.c_headicon.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/persionalInfo/HeadPic/lb_info_image"..v[2]..".dds", Vector4(0, 0, 0, 0)),}
			new_gonggao.l_speaker.Text = v[3]..lang:GetText("说：")
			new_gonggao.l_date.Text = v[5]
			new_gonggao.t_text.Text = v[4]
			if p_job == 4 or p_job == 3 then
				new_gonggao.del_gonggao.Enable = true
			else
				new_gonggao.del_gonggao.Enable = false
			end
			new_gonggao.c_gonggao.Parent = team_ui.scrollLayout_gonggao
			num = num + 1
		end
		team_ui.scroll_gonggao.AutoScrollMinSize = Vector2(0, num*88+2)
	end)
end

function FillOtherTeamGongGao()
	t_info.scrollLayout_gonggao:OnDestroy()
	rpc.safecallload("team_proclamation_list", {tid = tid_of_list},
	function(data)
		local list = data.list
		local num = 0
		for i, v in ipairs(list) do
			local new_gonggao = SpawnNewGongGao(v[1])
			new_gonggao.c_headicon.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/persionalInfo/HeadPic/lb_info_image"..v[2]..".dds", Vector4(0, 0, 0, 0)),}
			new_gonggao.l_speaker.Text = v[3]..lang:GetText("说：")
			new_gonggao.l_date.Text = v[5]
			new_gonggao.t_text.Text = v[4]
			new_gonggao.del_gonggao.Visible = false
			new_gonggao.c_gonggao.Parent = t_info.scrollLayout_gonggao
			num = num + 1
		end
		t_info.scroll_gonggao.AutoScrollMinSize = Vector2(0, num*88+2)
	end)
end		

function FillBuffList()
	local flag = false
	team_ui.zhandui_buji.Text = "Lv"..current_level
	team_ui.zhandui_buji_black.Text = "Lv"..current_level
	team_ui.l_text_black.Text = lang:GetText("战队等级达到")..current_level..lang:GetText("级,\n并由队长解锁补给")
	team_ui.l_text.Text = lang:GetText("战队等级达到")..current_level..lang:GetText("级,\n并由队长解锁补给")
	rpc.safecallload("team_buff_list", {tid = t_id, ptid = pt_id, rank = current_level},
	function(data)
		if data.contributionLimit > my_contribution then
			team_ui.l_text.TextColor = ARGB(255,251,14,14)
			team_ui.l_gongxian.TextColor = ARGB(255, 251, 14, 14)
			team_ui.team_gongxian2.TextColor = ARGB(255, 251, 14, 14)
			flag = false
		else
			team_ui.l_text.TextColor = ARGB(255,185,236,239)
			team_ui.l_gongxian.TextColor =  ARGB(255, 255, 103, 1)
			team_ui.team_gongxian2.TextColor = ARGB(255, 255, 187, 0)
			flag = true
		end
		team_ui.team_gongxian2.Text = data.contributionLimit
		team_ui.team_gongxian2_black.Text = data.contributionLimit
		team_ui.xunzhang.Text = data.medalNum
		team_ui.scrollLayout_buff:OnDestroy()
		-- for i = 1 , math.floor((data.num - 1)/10)+1 do
			-- local newBuffList = SpawnNewBuffList()
			-- newBuffList.c_bufflist.Parent = team_ui.scrollLayout_buff
		-- end
		-- team_ui.scroll_buff.AutoScrollMinSize = Vector2(0,195*math.floor((data.num)/10))
		items = data.items
		local jiesuo_flag = false
		for i, v in ipairs(items) do
			local newBuff = SpawnNewBuff(v.teambuffid,i)
			newBuff.buff_pic.ItemIcon = Gui.Icon("LobbyUI/team/FightBuff/"..v.name..".dds")
			newBuff.buff_pic_back.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_synthesis_common_slot.dds", Vector4(0, 0, 0, 0)),}
			newBuff.b_lock.Enable = flag
			if v.payType == 1 then
				newBuff.c_xunzhang.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_ico_cb.dds", Vector4(0, 0, 0, 0)),}
			elseif v.payType == 2 then
				newBuff.c_xunzhang.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_ico_fc.dds", Vector4(0, 0, 0, 0)),}
			end
			if v.status == 1 then
				newBuff.l_state_black.Text = lang:GetText("未解锁")
				-- newBuff.l_state.Text = current_level..lang:GetText("未解锁")
				newBuff.l_state.Text = lang:GetText("未解锁")
				newBuff.l_state.TextColor = ARGB(255,253,11,7)
				newBuff.buff_pic_back.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_synthesis_common_slot_disabled.dds", Vector4(0, 0, 0, 0)),}
				newBuff.lock_buff_state.Visible = false
				newBuff.b_lock.Visible = false
				newBuff.l_usetime.Visible = false
				newBuff.l_usetime_black.Visible = false
				newBuff.c_xunzhang.Visible = false
				newBuff.xunzhang_black.Visible = false
				newBuff.xunzhang.Visible = false
				jiesuo_flag = true
				newBuff.lock_buff.Visible = true
			elseif v.status == 2 then
				-- newBuff.l_state_black.Text = lang:GetText("已解锁")
				-- newBuff.l_state.Text = lang:GetText("已解锁")
				newBuff.l_state_black.Text = lang:GetText("")
				newBuff.l_state.Text = lang:GetText("")
				newBuff.l_state.TextColor = ARGB(255,230,210,149)
				if v.isBuff == 1 then
					newBuff.b_lock.Text = lang:GetText("激活")
				else
					newBuff.b_lock.Text = lang:GetText("领取")
				end
				newBuff.b_lock.Visible = true
				newBuff.lock_buff_state.Visible = true
				newBuff.lock_buff_state.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_status_ico_1.dds", Vector4(0, 0, 0, 0)),}
				newBuff.l_usetime_black.Visible = false
				newBuff.l_usetime.Visible = false
				newBuff.lock_buff.Visible = false
			elseif v.status == 3 then
				-- newBuff.l_state_black.Text = lang:GetText("已激活")
				-- newBuff.l_state.Text = lang:GetText("已激活")
				newBuff.l_state_black.Text = lang:GetText("")
				newBuff.l_state.Text = lang:GetText("")
				newBuff.l_state.TextColor = ARGB(255,255,119,0)
				if v.isBuff == 1 then
					newBuff.l_usetime_black.Text = lang:GetText("永久")
					newBuff.l_usetime.Text = lang:GetText("永久")--lang:GetText("剩余\n")..math.floor(v.common.minutes_left/60)..lang:GetText("小时")
				else
					newBuff.l_usetime.Text = lang:GetText("已领取")
				end
				newBuff.l_usetime.TextColor = ARGB(255,183,217,219)
				
				newBuff.b_lock.Visible = false
				newBuff.lock_buff_state.Visible = true
				newBuff.lock_buff_state.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_status_ico_2.dds", Vector4(0, 0, 0, 0)),}
				newBuff.l_usetime_black.Visible = true
				newBuff.l_usetime.Visible = true
				newBuff.lock_buff.Visible = false
			end
			newBuff.xunzhang_black.Text = v.cost
			newBuff.xunzhang.Text = v.cost
			if v.iBuffId >68 and v.iBuffId <73 then
				newBuff.l_tips.Text = "-"..v.iValue.."%"
			elseif v.iBuffId == 61 then
				newBuff.l_tips.Text = v.iValue
			elseif v.iBuffId == 0 then
				newBuff.l_tips.Text = ""
			else
				newBuff.l_tips.Text = "+"..v.iValue.."%"
			end
			-- newBuff.c_buff.Parent = team_ui.scrollLayout_buff:GetChildByIndex(math.floor((i - 1)/10))
			newBuff.c_buff.Parent = team_ui.scrollLayout_buff
		end
		if p_job == 4 then
			team_ui.jiesuo_btn.Visible = jiesuo_flag
		else
			team_ui.jiesuo_btn.Visible = false
		end
		if current_level > myteam_level then
			team_ui.jiesuo_btn.blink = false
		else
			team_ui.jiesuo_btn.blink = true
		end
		team_ui.scroll_buff.AutoScrollMinSize = Vector2(0,230*(math.floor((data.num-1)/7)+1))
		team_ui.scrollLayout_buff.Size =  Vector2(664,230*(math.floor((data.num-1)/7)+1))
		print("team_ui.scrollLayout_buff.Size"..230*(math.floor((data.num-1)/7)+1))
	end)
end

function FillOtherTeamZhanJi()
	t_info.scrollLayout_zhanji:OnDestroy()
	rpc.safecallload("team_record_list", {tid = tid_of_list},
	function(data)
		local list = data.list
		local num = 0
		for i, v in ipairs(list) do
			local new_zhanji = SpawnNewZhanJi(i)
			new_zhanji.l_moshi.Text = game_type_table[game_type_key[tonumber(v[2]) + 1]]
			new_zhanji.c_map.Skin = Gui.ControlSkin{BackgroundImage = L_WarZone.FindMapIcon(v[3]).Icon}
			new_zhanji.l_date.Text = v[5]
			new_zhanji.l_match.Text = v[4]
			new_zhanji.l_vs.Text = v[1]
			new_zhanji["l_id_"..i].Text = v[7]
			new_zhanji["l_name_"..i].Text = v[8]
			
			if tonumber(v[6]) == 1 then
				new_zhanji.c_win.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/team/NewFight/summary_win_logo.dds", Vector4(0, 0, 0, 0)),}
			else
				new_zhanji.c_win.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/team/NewFight/summary_lose_logo.dds", Vector4(0, 0, 0, 0))}
			end
			new_zhanji.c_zhanji.Parent = t_info.scrollLayout_zhanji
			num = num + 1
		end
		t_info.scroll_zhanji.AutoScrollMinSize = Vector2(0, num*149+(num-1)*5+2)
	end)	
end

function FillZhanJi()
	team_ui.scrollLayout_zhanji:OnDestroy()
	rpc.safecallload("team_record_list", {tid = t_id},
	function(data)
		local list = data.list
		local num = 0
		for i, v in ipairs(list) do
			local new_zhanji = SpawnNewZhanJi(i)
			new_zhanji.l_moshi.Text = game_type_table[game_type_key[tonumber(v[2]) + 1]]
			new_zhanji.c_map.Skin = Gui.ControlSkin{BackgroundImage = L_WarZone.FindMapIcon(v[3]).Icon}
			new_zhanji.l_date.Text = v[5]
			new_zhanji.l_match.Text = v[4]
			new_zhanji.l_vs.Text = v[1]
			new_zhanji["l_id_"..i].Text = v[7]
			new_zhanji["l_name_"..i].Text = v[8]
			
			if tonumber(v[6]) == 1 then
				new_zhanji.c_win.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/team/NewFight/summary_win_logo.dds", Vector4(0, 0, 0, 0)),}
			else
				new_zhanji.c_win.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/team/NewFight/summary_lose_logo.dds", Vector4(0, 0, 0, 0))}
			end
			new_zhanji.c_zhanji.Parent = team_ui.scrollLayout_zhanji
			num = num + 1
		end
		team_ui.scroll_zhanji.AutoScrollMinSize = Vector2(0, num*149+(num-1)*5+2)
	end)	
end
--显示战队信息框
function FillT_Info(tid,Is_Cilik)
	tid_of_list = tid
	rpc.safecallload("team_info_get", {tid = tid_of_list},
	function(data)
		if data.error ~= nil then
			return
		end
		if t_info_ui then
			t_info_ui.Close()
			t_info_ui = nil
		end
		
		t_info_ui = ModalWindow.GetNew()
		t_info_ui.root.Size = Vector2(1106, 551)
		t_info_ui.AllowEscToExit = false
		t_info.root.Parent = t_info_ui.root
		if Is_Cilik then
			t_info.btn_application.Visible = false
			t_info.btn_touch_header.Visible = false
		else
			t_info.btn_application.Visible = true
			t_info.btn_touch_header.Visible = true
		end
		Gui.Align(t_info.team_info, 0.5,0.5)
		if t_info_ui then
			local team_data = data.team
			t_info.c_jieshao.Visible = true
			t_info.c_zhanji.Visible = false
			t_info.c_gonggao.Visible = false
			t_info.jieshao_btn.PushDown = true
			t_info.zhanji_btn.PushDown = false
			t_info.gonggao_btn.PushDown = false
			
			t_info.team_name.Text = team_data[2]
			t_info.team_name_black.Text = team_data[2]
			t_info.team_image.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/team/FightHead/lb_squad_touxiang_"..team_data[3]..".dds", Vector4(0, 0, 0, 0)),}
			t_info.team_level.Text = team_data[18]
			t_info.team_level_black.Text = team_data[18]
			if team_data[18] ~= max_fightteam_level then
				t_info.exp_font.Size = Vector2(200*(team_data[19]/team_data[20]), 19)
				t_info.team_exp.Text = team_data[19].."/"..team_data[20]
			else
				t_info.exp_font.Size = Vector2(0, 19)
				t_info.team_exp.Text = "Max"
			end	
			t_info.team_fightnum.Text = team_data[21]
			t_info.team_fightnum_black.Text = team_data[21]
			if team_data[22] ~= 0 then
				t_info.team_num.Text = team_data[22]
				t_info.team_num_black.Text = team_data[22]
			else
				t_info.team_num.Text = lang:GetText("800名以外")
				t_info.team_num_black.Text = lang:GetText("800名以外")
			end
			t_info.team_fightnum_num.Text = team_data[24]
			if team_data[8] == 0 then
				t_info.win_percent.Text = "0.0%"
				t_info.win_percent_black.Text = "0.0%"
			else
				t_info.win_percent.Text = team_data[9]
				t_info.win_percent_black.Text = team_data[9]
			end
			t_info.win_lose.Text = team_data[7].."/"..(team_data[8]-team_data[7])
			t_info.win_lose_black.Text = team_data[7].."/"..(team_data[8]-team_data[7])
			t_info.count_person.Text = team_data[12].."/"..team_data[13]
			t_info.count_person_black.Text = team_data[12].."/"..team_data[13]
			t_info.lead.Text = team_data[14]
			t_info.lead_black.Text = team_data[14]
			t_info.time.Text = team_data[11]
			t_info.time_black.Text = team_data[11]
			t_info.jieshao.Text = team_data[4]
			if config.UserLanguage == language_list[2] then
				t_info.level.Text = lang:GetText("级")..team_data[17]
				t_info.level_black.Text = lang:GetText("级")..team_data[17]
			else
				t_info.level.Text = team_data[17]..lang:GetText("级")
				t_info.level_black.Text = team_data[17]..lang:GetText("级")
			end
			t_info.address.Text = team_data[16]
			t_info.address_black.Text = team_data[16]
		end
	end)
end

function RequestQuickBuy()
	rpc.safecallload("team_burnt_list", {pid = ptr_cast(game.CurrentState):GetCharacterId()},
	function(data)
		key_item = data.items
		for k, v in ipairs(data.items) do
			print("v.name:"..v.name)
			quick_buy_ui["quick_pic"..k].ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..v.name..".tga")
			quick_buy_ui["quick_name"..k].Text = v.display
			quick_buy_ui["quick_description"..k].Text = v.description
			quick_buy_ui["quick_quantity"..k].Text = v.quantity
			quick_buy_sid[k] = v.sid
		end
	end)
end

function ShowLevelWindowMove(exp,num)
	quick_buy_ui.ctr_up_level.Visible = true
	quick_buy_ui.ctr_up_level:Clear()
	quick_buy_ui.ctr_up_level.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_number_"..exp.."_"..num..".dds", Vector4(0, 0, 0, 0)),}
	quick_buy_ui.ctr_up_level.NormLocation = Vector2(quick_buy_ui.exp_font.Size.x,225)
	--quick_buy_ui.ctr_up_level:InsertMovePoint(Vector2(60, 245),0.05,Vector2(72, 24),ARGB(255,255,255,255))
	--quick_buy_ui.ctr_up_level:InsertMovePoint(Vector2(60, 235),0.1,Vector2(72, 24),ARGB(170,255,255,255))
	--quick_buy_ui.ctr_up_level:InsertMovePoint(Vector2(60, 225),0.15,Vector2(72, 24),ARGB(85,255,255,255))
	quick_buy_ui.ctr_up_level:InsertMovePoint(Vector2(quick_buy_ui.exp_font.Size.x, 195),0.5,Vector2(164, 56),ARGB(0,255,255,255))
end

function Show_GetBattleGift()
	GetBattlegiftmodel = ModalWindow.GetNew()
	GetBattlegiftmodel.root.Size = Vector2(538,332)
	GetBattlegiftmodel.AllowEscToExit = false
	GetBattleGift.main_gift.Parent = GetBattlegiftmodel.root
	team_ui.get_battle_reward.Enable = false
	SendBattleGift()
end

function Hide_GetBattleGift()
	if GetBattlegiftmodel then
		team_ui.get_battle_reward.Enable = false
		team_ui.get_battle_reward.blink = false
		GetBattlegiftmodel.Close()
		GetBattlegiftmodel = nil
	end
end

function Show_LeaveBattleWarn()
	LeaveBattleWarnmodel = ModalWindow.GetNew()
	LeaveBattleWarnmodel.root.Size = Vector2(538,332)
	LeaveBattleWarnmodel.AllowEscToExit = false
	LeaveBattleWarn.root.Parent = LeaveBattleWarnmodel.root
	
	LeaveBattleWarn.warn_msg_1:CleanAll()
	LeaveBattleWarn.warn_msg_1:AddMsg(lang:GetText("确定要退出"),ARGB(255, 0, 0, 0),true,false)
	LeaveBattleWarn.warn_msg_1:AddMsg(lang:GetText(my_battle_name),ARGB(255, 207, 64, 0),false,false)
	LeaveBattleWarn.warn_msg_1:AddMsg(lang:GetText("战队吗？"),ARGB(255, 0, 0, 0),false,false)
	if L_Vip.Viplevel < 7 then
		LeaveBattleWarn.des.Text = "(VIP"..L_Vip.Viplevel..lang:GetText("级离开战队仍保留")..vip_keep[L_Vip.Viplevel + 1]..lang:GetText("%的战队贡献）")
	elseif L_Vip.Viplevel == 7 then
		LeaveBattleWarn.des.Text = "(银钻"..lang:GetText("离开战队仍保留")..vip_keep[L_Vip.Viplevel + 1]..lang:GetText("%的战队贡献）")
	elseif L_Vip.Viplevel == 8 then
		LeaveBattleWarn.des.Text = "(金钻"..lang:GetText("离开战队仍保留")..vip_keep[L_Vip.Viplevel + 1]..lang:GetText("%的战队贡献）")
	end
end

function Hide_LeaveBattleWarn()
	if LeaveBattleWarnmodel then
		LeaveBattleWarnmodel.Close()
		LeaveBattleWarnmodel = nil
	end
end

function Show_MyAddPower()
	AddMyPowermodel = ModalWindow.GetNew()
	AddMyPowermodel.root.Size = Vector2(715, 423)
	AddMyPowermodel.AllowEscToExit = true
	add_my_power_ui.root.Parent = AddMyPowermodel.root
end

function Hide_MyAddPower()
	if AddMyPowermodel then
		AddMyPowermodel.Close()
		AddMyPowermodel = nil
	end
end

function Show_TeamAddPower()
	AddTeamPowermodel = ModalWindow.GetNew()
	AddTeamPowermodel.root.Size = Vector2(715, 509)
	AddTeamPowermodel.AllowEscToExit = true
	add_team_power_ui.root.Parent = AddTeamPowermodel.root
end

function Hide_TeamAddPower()
	if AddTeamPowermodel then
		AddTeamPowermodel.Close()
		AddTeamPowermodel = nil
	end
end

function SendBattleGift()
	local p_id = ptr_cast(game.CurrentState):GetCharacterId()
	rpc.safecallload("team_salary_get", {pid = p_id , tid = t_id},
	function (data)
		GetBattleGift.gift_name.Text = lang:GetText("你获得了 “")..data.info.display.."”"
		GetBattleGift.gift_btn:OnDestroy()
		L_Characters.CreatPresentNumCtr(GetBattleGift.gift_btn,data.info.item_num,158, 73)
		local color = data.info.color
		if color >= 2 and color <= 4 then
			color = "_"..color
		else
			color = ""
		end
		GetBattleGift.gift_btn.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..data.info.name..color..".tga"),
		L_MessageBox.CloseWaiter()
	end)
end

function Initialize()
	local cbx = team_list_ui.t_list
	cbx:DeleteAll()
	cbx:AddColumn("",10, "kAlignCenterMiddle")
	cbx:AddColumn(lang:GetText("排 名"),60, "kAlignCenterMiddle")
	cbx:AddColumn("",54, "kAlignCenterMiddle")
	cbx:AddColumn(lang:GetText("战队名称"),146, "kAlignCenterMiddle")
	cbx:AddColumn(lang:GetText("胜率"),64, "kAlignCenterMiddle")
	cbx:AddColumn(lang:GetText("胜/负场次"),139, "kAlignCenterMiddle")
	cbx:AddColumn(lang:GetText("等"),36, "kAlignRightMiddle")
	cbx:AddColumn(lang:GetText("级"),36, "kAlignLeftMiddle")
	cbx:AddColumn(lang:GetText("战斗力"),100, "kAlignCenterMiddle")
	cbx:AddColumn(lang:GetText("人数"),77, "kAlignCenterMiddle")
	cbx:AddColumn(lang:GetText("加入条件"),97, "kAlignCenterMiddle")
	cbx:AddColumn(lang:GetText("地区"),124, "kAlignCenterMiddle")
	cbx:AddColumn(lang:GetText("创建时间"),116, "kAlignCenterMiddle")
	cbx.EventClick = function(sender, e)
		local item = sender.SelectedItem
		if item then
			lead_vip = item.VIP
			lead_name = item.NAME
		end
	end
	cbx = team_list_ui.province
	cbx:RemoveAll()
	cbx:AddItem( lang:GetText("全部") )
	for _,v in ipairs(province) do
		cbx:AddItem( v )
	end
	team_list_ui.province.Text = lang:GetText("全部")
	team_list_ui.city.Text = lang:GetText("全部")
end

function Finalize()
end

function Hide()
	is_in_fight_ui = false
	if team_ui then		
		team_ui.root.Parent = nil
	end
	if request_list_ui then
		request_list_ui.root.Parent = nil
	end
	L_LobbyMain.LobbyMainWin.LobbyMainWin_Header_Team.Visible = false
	L_LobbyMain.LobbyMainWin.lb_Announcement.Size = Vector2(390, 35)
	L_LobbyMain.LobbyMainWin.lb_Announcement.Location = Vector2(483, 180)
end

function Fill_Defance_num()
	local num = 0
	for i = 1,10 do
		if L_FightTeam.attack_team_info[i][1] ~= nil then
			num = num + 1
		end
	end	
		
	allteam_source_ui.defance_num_btn.Text = num
	if num > 0 then
		allteam_source_ui.defance_num_btn.Visible = true
	else
		allteam_source_ui.defance_num_btn.Visible = false
	end	
end

function Fill_Header_Team()
	rpc.safecall("team_info",{pid = ptr_cast(game.CurrentState):GetCharacterId()},
	function(data)
		if data.team[1] then
			if L_LobbyMain.current_chosse_main_page == 2 then
				rpc.safecallload("get_fightresinfo", {pid = ptr_cast(game.CurrentState):GetCharacterId()},
				function(data)
					TeamHeader_Data = data
					L_LobbyMain.LobbyMainWin.team_name.Text = data.t_teamName
					L_LobbyMain.LobbyMainWin.team_lead.Text = data.t_teamLeader
					
					Res_ratio_status1 = data.Res_ratio_status
					player_Res_ratio_status1 = data.player_Res_ratio_status	
					
				
					L_LobbyMain.LobbyMainWin.c_touxiang.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/team/FightHead/lb_squad_touxiang_"..data.t_logo..".dds",Vector4(0,0,0,0)),}			
					L_LobbyMain.ShowFightnums(L_LobbyMain.LobbyMainWin.My_SourceLv_layout,tonumber(data.t_teamSpaceLevel),"team/lb_squad_number_01.dds")
					L_LobbyMain.ShowFightnums(L_LobbyMain.LobbyMainWin.Zhandui_SourceLv_layout,tonumber(data.t_teamSpaceLevel),"team/lb_squad_number_01.dds")
					L_LobbyMain.ShowFightnums(L_LobbyMain.LobbyMainWin.TeamLv_layout,tonumber(data.t_teamLevel),"team/lb_squad_number_01.dds")
					L_LobbyMain.ShowFightnums(L_LobbyMain.LobbyMainWin.FightNum_layout,tonumber(data.t_teamFightNum),"team/lb_squad_number_01.dds", 16, 15)
					L_LobbyMain.ShowFightnums(L_LobbyMain.LobbyMainWin.FightTop_layout,tonumber(data.t_recoreRankingCurr),"team/lb_squad_number_02.dds", 16, 15)
					L_LobbyMain.ShowFightnums(L_LobbyMain.LobbyMainWin.SourceTop_layout,tonumber(data.t_resourceRank),"team/lb_squad_number_02.dds", 16, 15)
					
					L_LobbyMain.LobbyMainWin.zhandui_fightsource_rate.Text = (data.t_transitionResource + data.t_addTransition*100)..lang:GetText("战队原石 → ")..((data.t_transitionResource + data.t_addTransition*100)/100)..lang:GetText("战队黑铁/每小时")
					-- L_LobbyMain.LobbyMainWin.zhandui_fightsource_rate:CleanAll()
					-- L_LobbyMain.LobbyMainWin.zhandui_fightsource_rate:AddMsg(lang:GetText("资源转换率："..data.t_transitionResource),ARGB(255, 255, 255, 255),true,false)
					-- L_LobbyMain.LobbyMainWin.zhandui_fightsource_rate:AddMsg("+"..data.t_addTransition.."（18：00）",ARGB(255, 95, 182, 108),false,false)
					-- L_LobbyMain.LobbyMainWin.zhandui_fightsource_rate:AddMsg("/hf",ARGB(255, 255, 255, 255),false,false)
					if tonumber(data.t_unusableResource) < tonumber(data.t_unusableResourceMAX) then
						L_LobbyMain.LobbyMainWin.zhandui_cannot_use_oil.Size = Vector2(422*(tonumber(data.t_unusableResource)/tonumber(data.t_unusableResourceMAX)), 17)
					else
						L_LobbyMain.LobbyMainWin.zhandui_cannot_use_oil.Size = Vector2(422, 17)
					end
					if tonumber(data.t_usableResource) < tonumber(data.t_usableResourceMAX) then
						L_LobbyMain.LobbyMainWin.zhandui_can_use_oil.Size = Vector2(0*(tonumber(data.t_usableResource)/tonumber(data.t_usableResourceMAX)), 17)
					else
						L_LobbyMain.LobbyMainWin.zhandui_can_use_oil.Size = Vector2(0, 17)
					end
					L_LobbyMain.LobbyMainWin.zhandui_cannot_use_rate.Text = data.t_unusableResource.."/"..data.t_unusableResourceMAX
					L_LobbyMain.LobbyMainWin.zhandui_can_use_rate.Text = data.t_usableResource--.."/"..data.t_usableResourceMAX
					
					L_LobbyMain.LobbyMainWin.my_fightsource_rate.Text = ((data.p_TransitionResource+data.p_AddTransition)*100)..lang:GetText("个人原石 → ")..(data.p_TransitionResource+data.p_AddTransition)..lang:GetText("个人黑晶石/每小时")
					-- L_LobbyMain.LobbyMainWin.my_fightsource_rate:CleanAll()
					-- L_LobbyMain.LobbyMainWin.my_fightsource_rate:AddMsg(lang:GetText("资源转换率："..data.p_TransitionResource),ARGB(255, 255, 255, 255),true,false)
					-- L_LobbyMain.LobbyMainWin.my_fightsource_rate:AddMsg("+"..data.p_AddTransition.."（18：00）",ARGB(255, 95, 182, 108),false,false)
					-- L_LobbyMain.LobbyMainWin.my_fightsource_rate:AddMsg("/hf",ARGB(255, 255, 255, 255),false,false)
					
					
					if tonumber(data.p_UnusableResource) < tonumber(data.p_UnusableResourceMAX) then
						L_LobbyMain.LobbyMainWin.my_cannot_use_oil.Size = Vector2(422*(tonumber(data.p_UnusableResource)/tonumber(data.p_UnusableResourceMAX)), 17)
					else
						L_LobbyMain.LobbyMainWin.my_cannot_use_oil.Size = Vector2(422, 17)
					end
					if tonumber(data.p_UsableResource) < tonumber(data.p_UsableResourceMAX) then
						L_LobbyMain.LobbyMainWin.my_can_use_oil.Size = Vector2(0*(tonumber(data.p_UsableResource)/tonumber(data.p_UsableResourceMAX)), 17)
					else
						L_LobbyMain.LobbyMainWin.my_can_use_oil.Size = Vector2(0, 17)
					end
					L_LobbyMain.LobbyMainWin.my_cannot_use_rate.Text = data.p_UnusableResource.."/"..data.p_UnusableResourceMAX
					L_LobbyMain.LobbyMainWin.my_can_use_rate.Text = data.p_UsableResource--.."/"..data.p_UsableResourceMAX
					p_UnusableResource = data.p_UnusableResource
					-- add_team_power_ui.zhandui_fightsource_rate.Text = lang:GetText("原石每小时转换：")..data.t_transitionResource..lang:GetText("黑铁(自动转换)")
					if tonumber(data.t_unusableResource) < tonumber(data.t_unusableResourceMAX) then
						add_team_power_ui.zhandui_cannot_use_oil.Size = Vector2(422*(tonumber(data.t_unusableResource)/tonumber(data.t_unusableResourceMAX)), 17)
					else
						add_team_power_ui.zhandui_cannot_use_oil.Size = Vector2(422, 17)
					end
					if tonumber(data.t_usableResource) < tonumber(data.t_usableResourceMAX) then
						add_team_power_ui.zhandui_can_use_oil.Size = Vector2(0*(tonumber(data.t_usableResource)/tonumber(data.t_usableResourceMAX)), 17)
					else
						add_team_power_ui.zhandui_can_use_oil.Size = Vector2(0, 17)
					end
					add_team_power_ui.zhandui_cannot_use_rate.Text = data.t_unusableResource.."/"..data.t_unusableResourceMAX
					add_team_power_ui.zhandui_can_use_rate.Text = data.t_usableResource--.."/"..data.t_usableResourceMAX
					
					-- add_my_power_ui.my_fightsource_rate.Text = lang:GetText("原石每小时转换：")..data.p_TransitionResource..lang:GetText("黑晶石(自动转换)")
					if tonumber(data.p_UnusableResource) < tonumber(data.p_UnusableResourceMAX) then
						add_my_power_ui.my_cannot_use_oil.Size = Vector2(422*(tonumber(data.p_UnusableResource)/tonumber(data.p_UnusableResourceMAX)), 17)
					else
						add_my_power_ui.my_cannot_use_oil.Size = Vector2(422, 17)
					end
					if tonumber(data.p_UsableResource) < tonumber(data.p_UsableResourceMAX) then
						add_my_power_ui.my_can_use_oil.Size = Vector2(0*(tonumber(data.p_UsableResource)/tonumber(data.p_UsableResourceMAX)), 17)
					else
						add_my_power_ui.my_can_use_oil.Size = Vector2(0, 17)
					end
					add_my_power_ui.my_cannot_use_rate.Text = data.p_UnusableResource.."/"..data.p_UnusableResourceMAX
					add_my_power_ui.my_can_use_rate.Text = data.p_UsableResource--.."/"..data.p_UsableResourceMAX
					allteam_source_ui.source_start_time.Text = lang:GetText("开始时间：")..data.challengeSDate.."\n"..lang:GetText("结束时间：")..data.challengeEDate
			
					--保存战队界面和个人界面的Fc点
					allteam_source_ui.canFC.Text = L_LobbyMain.PersonalInfo_data.newCR
					allteam_source_ui.s_canFC.Text = L_LobbyMain.PersonalInfo_data.newCR
					allteam_source_ui.canPower.Text = data.t_usableResource
					allteam_source_ui.s_canPower.Text = data.p_UsableResource
					save_T_res = tonumber(data.t_usableResource)
					save_P_res = tonumber(data.p_UsableResource)
					
					for i,v in ipairs(data.preZYZDZRankList) do
						if v[2] == "null" then
							allteam_source_ui["l_teamname"..i].Text = ""
							allteam_source_ui["l_teamname_black"..i].Text = ""
							allteam_source_ui["l_teamlv"..i].Text = lang:GetText("上周NO：")
							allteam_source_ui["b_source_tiaozhan"..i].Enable = false
						else
							allteam_source_ui["l_teamid"..i].Text = v[1]
							allteam_source_ui["l_teamname"..i].Text = v[2]
							allteam_source_ui["l_teamname_black"..i].Text = v[2]
							allteam_source_ui["l_teamlv"..i].Text = lang:GetText("上周NO：")..i
							allteam_source_ui["l_teamFC"..i].Text = v[8]
							allteam_source_ui["b_source_tiaozhan"..i].Hint = lang:GetText("挑战该领地队长需花费")..v[8]..lang:GetText("FC点\n小队队长至多可返还")..v[9]..lang:GetText("黑晶石\n")
							if v[4] == true then
								allteam_source_ui["b_source_tiaozhan"..i].Enable = true
							else
								allteam_source_ui["b_source_tiaozhan"..i].Enable = false
							end
						end
						if v[1] == t_id then
							allteam_source_ui["b_source_tiaozhan"..i].Enable = false
						end
					end
					-- FillSourceRank(data.curZYZDZRankList)
					L_LobbyMain.LobbyMainWin.LobbyMainWin_Header_Team.Visible = true
					L_LobbyMain.LobbyMainWin.buff_list_con.Visible = false
					L_LobbyMain.LobbyMainWin.lb_Announcement.Size = Vector2(858, 35)
					L_LobbyMain.LobbyMainWin.lb_Announcement.Location = Vector2(273, 28)
					
					SHOP_TeamTransofrm = data.SHOP_TeamTransofrm
					SHOP_TeamBuy = data.SHOP_TeamBuy
					SHOP_PersonalTransform = data.SHOP_PersonalTransform
					local cbx = add_team_power_ui.c_change_team
					cbx:RemoveAll()
					add_team_power_ui.FC_left.Text = L_LobbyMain.PersonalInfo_data.newCR..lang:GetText("  FC点")
					for _,v in ipairs(SHOP_TeamTransofrm.costs) do
						cbx:AddItem( v[3] )
					end
					cbx.SelectedIndex = selected_team_exchange - 1
					add_team_power_ui.c_change_team_FC.Text = SHOP_TeamTransofrm.costs[selected_team_exchange][1]--..lang:GetText("  FC点")
					add_team_power_ui.c_change_team_yuanshi.Text = SHOP_TeamTransofrm.costs[selected_team_exchange][2]
					add_team_power_ui.c_change_team_back.Text = SHOP_TeamTransofrm.costs[selected_team_exchange][4]
					cbx = add_team_power_ui.c_buy_team
					cbx:RemoveAll()
					for _,v in ipairs(SHOP_TeamBuy.costs) do
						cbx:AddItem( v[3] )
					end
					cbx.SelectedIndex = selected_team_buy - 1
					add_team_power_ui.c_buy_team_FC.Text = SHOP_TeamBuy.costs[selected_team_buy][1]--..lang:GetText("  FC点")
					add_team_power_ui.c_buy_team_back.Text = SHOP_TeamBuy.costs[selected_team_buy][4]
					cbx = add_my_power_ui.c_change_person
					cbx:RemoveAll()
					add_my_power_ui.FC_left.Text = L_LobbyMain.PersonalInfo_data.newCR..lang:GetText("  FC点")
					for _,v in ipairs(SHOP_PersonalTransform.costs) do
						cbx:AddItem( v[3] )
					end
					cbx.SelectedIndex = selected_person_exchange - 1
					add_my_power_ui.c_change_person_FC.Text = SHOP_PersonalTransform.costs[selected_person_exchange][1]--..lang:GetText("  FC点")
					add_my_power_ui.c_change_person_yuanshi.Text = SHOP_PersonalTransform.costs[selected_person_exchange][2]
					
					if config:GetUISystemFlag(3) == 0 then
						for i = 1, 4 do
							L_LobbyMain.LobbyMainWin["con_"..i].Visible = false
						end
						L_LobbyMain.LobbyMainWin.SourceTop_layout.Visible = false
						L_LobbyMain.LobbyMainWin.zhandui_source.Visible = false
						L_LobbyMain.LobbyMainWin.b_zhandui.Visible = false
						L_LobbyMain.LobbyMainWin.b_geren.Visible = false
						L_LobbyMain.LobbyMainWin.lb_Announcement.Visible = false
						L_LobbyMain.LobbyMainWin.f_billbord.Visible = true
					else
						L_LobbyMain.LobbyMainWin.f_billbord.Visible = false
					end
				end)
			end
		end
	end	)
end

function Show(parent_win)
	L_LobbyMain.HideAll()
	L_LobbyMain.LobbyMainWin_Foot.btn_FightTeam.PushDown = true
	is_in_fight_ui = true
	my_mode = 1
	team_list_type = 1
	if not is_exit_room then
		mode = 3
	end	
	team_list_ui.root.Visible = false
	team_ui.my_team.Visible = false
	allteam_source_ui.root.Visible = false
	my_source_ui.root.Visible = false
	my_source_shop.root.Visible = false
	L_LobbyMain.LobbyMainWin.btn_sourcefight.PushDown = true
	L_LobbyMain.LobbyMainWin.btn_my.PushDown = false
	L_LobbyMain.LobbyMainWin.btn_list.PushDown = false

	allteam_source_ui.root.Visible = true
	-- allteam_source_ui.allteam.Visible = true
	allteam_source_ui.buildteam.Visible = false
	allteam_source_ui.buildSingle.Visible = false
	allteam_source_ui.info_btn.PushDown = true
	allteam_source_ui.person_btn.PushDown = false
	allteam_source_ui.team_btn.PushDown = false

	
	team_list_ui.root.Visible = false
	is_first_in = true
	SetupTeam(parent_win)
	--Set_type_btn()
	L_LobbyMain.LobbyMainWin.video_button.Enable = false
	L_FightTeam.mode = 1
	L_LobbyMain.SetSourceBtn(L_LobbyMain.LobbyMainWin.btn_my, 2)
	L_FightTeam.FillTeam()
	L_FightTeam.team_ui.btn_my.PushDown = true
	L_FightTeam.team_ui.btn_list.PushDown = false
	L_FightTeam.team_list_ui.root.Visible = false
	L_FightTeam.team_ui.my_team.Visible = true

	
end

function AllSelectRequest(ltv)
	local item = ltv.RootItem.FirstChild
	local flag = false
	while item and item.ID do
		if item.Check == false then
			flag = true
			break
		end
		item = item.Next
	end
	item = ltv.RootItem.FirstChild
	while item do
		item.Check = flag
		item = item.Next
	end
end

function GetSelected(ltv)
	local check_list = {}
	local item = ltv.RootItem.FirstChild
	while item and item.ID ~= 0 do
		if item.Check then
			table.insert(check_list,item.ID)
		end
		item = item.Next
	end
	local item = ltv.SelectedItem
	if #check_list > 0 then
		return table.concat(check_list,",")
	else
		return ""
	end
end

function GetMySourceMember(ltv)
	local check_list = {}
	local item = ltv.RootItem.FirstChild
	while item and item.NAME ~= "" do
		if item.NAME ~= L_LobbyMain.PersonalInfo_data.name then
			table.insert(check_list,item.NAME)
		end	
		item = item.Next
	end
	if #check_list > 0 then
		return table.concat(check_list,"-")
	else
		return ""
	end
end

function FightTeamHideAll()
	if t_info_ui then
		t_info_ui.Close()
		t_info_ui = nil
	end
	if Image_team_ui then
		Image_team_ui.Close()
		Image_team_ui = nil
	end
	if request_list_ui then
		request_list_ui.root.Parent = nil
	end
	if register_team_ui then
		register_team_ui.Close()
		register_team_ui = nil
	end
	if revise_team_Image_ui then
		revise_team_Image_ui.Close()
		revise_team_Image_ui = nil
	end
	if revise_team_ui then
		revise_team_ui.Close()
		revise_team_ui = nil			
	end
end

--属性条计算公式（最大值计算）
function getMaxValue(maxValue,minValue)
	return (maxValue - minValue)
end
--属性条计算公式（当前值计算）
function getCurValue(maxValue,minValue,curValue)
	return (maxValue - minValue)*((curValue-minValue)/(maxValue - minValue))
end

--知道毫秒得到小时，分，秒的函数
function GethourMinuteSeconds(m)
	local h = nil
	local mi = nil
	local s = nil
	if m > 0 then
		h = math.floor((m/3600000)) < 10 and "0"..math.floor((m/3600000)) or math.floor((m/3600000))
		mi = math.floor((m%3600000)/60000)< 10 and "0"..math.floor((m%3600000)/60000) or math.floor((m%3600000)/60000)
		s = math.floor(((m%3600000)%60000)/1000)< 10 and "0"..math.floor(((m%3600000)%60000)/1000) or math.floor(((m%3600000)%60000)/1000)
	else
		h = "00"
		mi = "00"
		s = "00"
	end
	return tostring(h..":"..mi..":"..s)
end

--加动画
flash = Gui.Create()
{
	Gui.Control "root"
	{
		Location = Vector2(0, 0),
		Size = Vector2(440, 440),
		BackgroundColor = ARGB(0, 255, 255, 255),
		Gui.FlashControl "Flash"
		{
			Visible = false,
			Text = "synthesis_success",
			Location = Vector2(0, 0),
			Size = Vector2(440, 440),
			BackgroundColor = ARGB(255, 255, 255, 255),
			UseTime = false,
			DisplayTime = 1,
			EventTimer = function(sender, e)
				flash.Flash.UseTime = false
				if modalFlash then
					modalFlash.Close()
					modalFlash = nil
					ModalWindow.CloseAll()
				end
				gui:PlayAudio("kUIA_COMPOUND_SUCCEED_SWF")
			end
		},
	},

}
function UpdateTimeLable(parent,mm,parent_lab)
	local t1 = os.clock()
	parent:CleanAll()
	parent:AddTime(mm/1000)
	parent.EventTimeUpdate = function(sender, e)
		local t2 = os.clock()
		local da = mm/1000 - (t2-t1)
		parent_lab.Text = L_FightTeam.GethourMinuteSeconds(da*1000)
	end	
end
