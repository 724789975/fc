module("L_Shooting", package.seeall)

--靶场的靶数 最多9个靶子
local target_num = 7
--全部偷看消耗偷看道具数量
local All_look_target_num = 5
--偷看列表状态  0 初始状态未偷看  1 偷看过了
local look_list = {0,0,0,0,0,0,0,0,0}
--靶子位置
local shooting_btn_location_Parent = 
{
	{
		{20,133},
		{120,178},
		{105,27},
		{204,55},
		{297,176},
		{297,26},
		{389,76},
		{485,127},
	},
}
--靶场背景图片
local shooting_Background_Image = 
{
	Gui.Image("LobbyUI/Shooting/lb_range_range_01.dds", Vector4(0, 0, 0, 0)),
}
--以上可配参数

local shooting_btn_location = {}
local Rapid_Shopping_Win_ui = nil
local RapidShopping_Window = nil
local Shooting_jion_Win_ui = nil
local Shootingjion_Window = nil
local Shooting_Win_ui = nil
local Shooting_Window = nil
local Shooting_prize_Win_ui = nil
local Shootingprize_Window = nil
local Shooting_No_prize_Win_ui = nil
local ShootingNoprize_Window = nil
local Shooting_Dartleprize_Win_ui = nil
local Shooting_Dartleprize_Window = nil

local ammo_type = -1
local RPC_Shooting_Info = nil

local Shooting_state = false

--快速购买信息
local Shopping_info = nil

--子弹信息
local ammo_Info = nil

--连射奖励次数记录
local Shooting_Total_num = -1
local Shooting_Prize = nil

--连射奖励已领取
local dartelPrize_confirm = false

--随机生成的靶场界面参数
local Shooting_Background_num = 0

--添加稀有度度接口
function AddCtrrareLevel(m_parent,rareLevel,width,_high)
	local ctr = Gui.Create()
			{
				Gui.Control "ctr_rareLevel"
				{
					Size = Vector2(Skin.rarelevel_Image[math.ceil(rareLevel/25)].Size.x ,Skin.rarelevel_Image[math.ceil(rareLevel/25)].Size.y),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Location = Vector2(width - Skin.rarelevel_Image[math.ceil(rareLevel/25)].Size.x ,_high),			
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Skin.rarelevel_Image[math.ceil(rareLevel/25)],
					},
				},
			}
	ctr.ctr_rareLevel.Parent = m_parent
end

--添加装备等级接口
function AddCtrstrength(m_parent,strength,width,high)
	local ctr = Gui.Create()
			{
				Gui.Control "ctr_strength"
				{
					Size = Vector2(54 ,30),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Location = Vector2(width - 54 ,high - 30),			
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/badge_lv"..strength.."_small.dds", Vector4(0, 0, 0, 0)),
					},
				},
			}
	ctr.ctr_strength.Parent = m_parent
end

--随机生成 靶数
function RandomCreatShooting(num)
	local Tab_num = table.getn(shooting_btn_location_Parent[num])
	local rand_num = {}
	local n = Tab_num - target_num
	local i = 1
	while i <= n do
		rand_num[i] = RandomNum(rand_num,Tab_num)	
		i = i + 1
	end
	CopyShooting_Pos(rand_num,num)
end

function RandomNum(rand_num,Tab_num)
	local rand = -1
	while rand < 0 do
		rand = RandomOnly(rand_num,math.random(Tab_num))
	end
	return rand
end

function RandomOnly(rand_num,rand)
	local i = 1
	while rand_num[i] do
		if rand_num[i] == rand then
			return -1
		end
		i = i + 1
	end
	return rand
end

function CopyShooting_Pos(rand_num,num)
	shooting_btn_location = {}
	local i = 1
	local j = 1
	while shooting_btn_location_Parent[num][i] do
		if filtrationNum(rand_num,i) == true then
			shooting_btn_location[j] = shooting_btn_location_Parent[num][i]
			j = j + 1
		end
		i = i + 1
	end
end

function filtrationNum(rand_num,num)
	local i = 1
	while rand_num[i] do
		if rand_num[i] == num then
			return false
		end
		i = i + 1
	end
	return true
end

function AddNum(num,info)
	if info.sid == ammo_Info[1].sid and ammo_Info[1].i_value == ammo_type then
		RPC_Shooting_Info.ammo_num = RPC_Shooting_Info.ammo_num + num
	elseif info.sid == ammo_Info[2].sid and ammo_Info[2].i_value == ammo_type then
		RPC_Shooting_Info.ammo_num = RPC_Shooting_Info.ammo_num + num
	elseif info.sid == RPC_Shooting_Info.look_item.sid then
		RPC_Shooting_Info.look_item.unit = RPC_Shooting_Info.look_item.unit + num
	end
	ShowShootingState(RPC_Shooting_Info)
end

--快速购买界面
local Rapid_Shopping_Win = 
{
	Gui.Control "Rapid_Shopping_root"
	{	
		Size = Vector2(1200, 900),
		BackgroundColor = ARGB(0, 255, 255, 255),
		Location = Vector2(0, 0),
		
		Gui.Control
		{	
			Size = Vector2(429, 375), --377  375
			BackgroundColor = ARGB(255, 255, 255, 255),
			Dock = "kDockCenter",
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/main_bar01.dds", Vector4(20, 20, 20, 20)),
			},

			Gui.Control
			{	
				Size = Vector2(407, 352),--355 352
				BackgroundColor = ARGB(255, 255, 255, 255),
				Location = Vector2(11, 12),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/main_bar02.dds", Vector4(8, 8, 8, 8)),
				},
				
				Gui.Label
				{
					Size = Vector2(405, 35),--353  35
					Location = Vector2(0, 0),
					TextColor = ARGB(255, 255, 210, 0),
					FontSize = 18,
					TextAlign = "kAlignLeftMiddle",
					Text = lang:GetText("快速购买"),
					BackgroundColor = ARGB(255,255,255,255),
					TextPadding = Vector4(8,0,0,8),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_onlinetime_bg_5.dds", Vector4(8, 8, 8, 8)),
					},
				},
				
				Gui.Control
				{	
					Size = Vector2(384, 260),--325  260
					BackgroundColor = ARGB(255, 255, 255, 255),
					Location = Vector2(16, 39),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_01.dds", Vector4(40, 40, 40, 40)),
					},
					
					Gui.Control
					{	
						Size = Vector2(330, 208),--274  208
						BackgroundColor = ARGB(255, 255, 255, 255),
						Location = Vector2(27, 10),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_06.dds", Vector4(32, 28, 32, 50)),
						},
						
						Gui.Label "name"
						{
							Size = Vector2(330, 28),
							Location = Vector2(0, 0),
							TextColor = ARGB(255, 255, 210, 0),
							FontSize = 16,
							TextAlign = "kAlignCenterMiddle",
							Text = "",
							BackgroundColor = ARGB(0,255,255,255),
							TextPadding = Vector4(0,0,0,3),
						},
						
						Gui.TextArea "des"
						{
							Size = Vector2(270, 50),
							Location = Vector2(40, 110),
							TextColor = ARGB(255, 255, 210, 0),
							FontSize = 14,
							Readonly = true,
							Fold = true,
							BackgroundColor = ARGB(255,255,255,255),
						},
						
						Gui.Button
						{
							Size = Vector2(20,32),
							Location = Vector2(32, 167),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Skin = Gui.ButtonSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_fanye_button_normal_L.dds", Vector4(0, 0, 0, 0)),
								HoverImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_fanye_button_hover_L.dds", Vector4(0, 0, 0, 0)),
								DownImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_fanye_button_down_L.dds", Vector4(0, 0, 0, 0)),
								DisabledImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_fanye_button_disabled_L.dds", Vector4(0, 0, 0, 0)),
							},
							EventClick = function()
								Rapid_Shopping_Win_ui.Tbox_Totle_num.Text = math.ceil(tonumber(Rapid_Shopping_Win_ui.Tbox_Totle_num.Text)) - 1
							end,
						},
						
						Gui.Textbox "Tbox_Totle_num"
						{
							Size = Vector2(154, 34),
							Location = Vector2(89, 166),
							TextColor = ARGB(255, 255, 210, 0),
							FontSize = 24,
							Text = "1",
							BackgroundColor = ARGB(255,255,255,255),
							TextPadding = Vector4(71,0,0,0),
							InputNumberOnly = true,
							Skin = Gui.TextboxSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_04.dds", Vector4(12, 0, 12, 0)),
								ActiveImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_04.dds", Vector4(12, 0, 12, 0)),
								DisabledImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_04.dds", Vector4(12, 0, 12, 0)),
							},
							
							EventTextChanged = function()
								if Rapid_Shopping_Win_ui.Tbox_Totle_num.Text ~= "" then
									if math.ceil(tonumber(Rapid_Shopping_Win_ui.Tbox_Totle_num.Text)) > 300 then
										Rapid_Shopping_Win_ui.Tbox_Totle_num.Text = "300"
										return
									elseif math.ceil(tonumber(Rapid_Shopping_Win_ui.Tbox_Totle_num.Text)) < 1 then
										Rapid_Shopping_Win_ui.Tbox_Totle_num.Text = "1"
										return
									end
									if string.sub(Rapid_Shopping_Win_ui.Tbox_Totle_num.Text,1,1) == "0" then
										Rapid_Shopping_Win_ui.Tbox_Totle_num.Text = string.sub(Rapid_Shopping_Win_ui.Tbox_Totle_num.Text,2)
										return
									end
									Rapid_Shopping_Win_ui.Tbox_Totle_num.TextPadding = Vector4(77 - 6*string.len(Rapid_Shopping_Win_ui.Tbox_Totle_num.Text),0,0,0)
								end
								SetHummerTotalMoney()
							end,
							
							EventLeave = function()
								if Rapid_Shopping_Win_ui.Tbox_Totle_num.Text == "" then
									Rapid_Shopping_Win_ui.Tbox_Totle_num.Text = 1
								end
							end,
							
							EventValueNoNumber = function()
								Rapid_Shopping_Win_ui.lab_timer_ctr:Show()
							end,
						},
						
						Gui.Button
						{
							Size = Vector2(20,32),
							Location = Vector2(279, 167),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Skin = Gui.ButtonSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_fanye_button_normal_R.dds", Vector4(0, 0, 0, 0)),
								HoverImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_fanye_button_hover_R.dds", Vector4(0, 0, 0, 0)),
								DownImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_fanye_button_down_R.dds", Vector4(0, 0, 0, 0)),
								DisabledImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_fanye_button_disabled_R.dds", Vector4(0, 0, 0, 0)),
							},
							EventClick = function()
								Rapid_Shopping_Win_ui.Tbox_Totle_num.Text = math.ceil(tonumber(Rapid_Shopping_Win_ui.Tbox_Totle_num.Text)) + 1
							end,
						},
					},
					
					Gui.Label
					{
						Size = Vector2(140, 28),
						Location = Vector2(15, 220),
						TextColor = ARGB(255, 255, 210, 0),
						FontSize = 18,
						TextAlign = "kAlignCenterMiddle",
						Text = lang:GetText("您总共要支付"),
						BackgroundColor = ARGB(0,255,255,255),
						TextPadding = Vector4(0,0,0,3),
					},
					
					Gui.Label "Total_money"
					{
						Size = Vector2(118, 28),
						Location = Vector2(162, 220),
						TextColor = ARGB(255, 255, 210, 0),
						FontSize = 18,
						TextAlign = "kAlignCenterMiddle",
						Text = "0",
						BackgroundColor = ARGB(255,255,255,255),
						TextPadding = Vector4(0,0,0,3),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_03.dds", Vector4(8, 8, 8, 8)),
						},
					},
					
					Gui.Label
					{
						Size = Vector2(90, 28),
						Location = Vector2(287, 220),
						TextColor = ARGB(255, 255, 210, 0),
						FontSize = 18,
						TextAlign = "kAlignCenterMiddle",
						Text = lang:GetText("FC点"),
						BackgroundColor = ARGB(0,255,255,255),
						TextPadding = Vector4(0,0,0,3),
					},
					
					Gui.Label "lab_timer_ctr"
					{
						Size = Vector2(150,35),
						Location = Vector2(100, 207),
						BackgroundColor = ARGB(255, 255, 255, 255),
						TextColor = ARGB(255, 0, 0, 0),
						Visible = false,
						UseTimer = true,
						DisplayTime = 1,
						FontSize = 12,
						TextAlign = "kAlignCenterMiddle",
						Text = lang:GetText("只能输入数字0～9"),
						TextPadding = Vector4(0,8,0,0),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_05.dds", Vector4(37, 18, 14, 12)),
						},
						
						EventClose = function()
							
						end
					},
				},
				
				Gui.Button
				{
					Size = Vector2(180,44),
					Location = Vector2(113, 305),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Text = lang:GetText("购 买"),
					TextColor = ARGB(255, 229, 255, 252),
					TextAlign = "kAlignCenterMiddle",
					HighlightTextColor = ARGB(255, 229, 255, 252),
					Padding = Vector4(0, 0, 0, 5),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_onlinetime_button_2_normal.dds", Vector4(20, 0, 20, 0)),
						HoverImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_onlinetime_button_2_hover.dds", Vector4(20, 0, 20, 0)),
						DownImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_onlinetime_button_2_down.dds", Vector4(20, 0, 20, 0)),
						DisabledImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_onlinetime_button_2_disabled.dds", Vector4(20, 0, 20, 0)),
					},
					EventClick = function()
						local args = {num = Rapid_Shopping_Win_ui.Tbox_Totle_num.Text, pid = ptr_cast(game.CurrentState):GetCharacterId(), sid = Shopping_info.sid}
						rpc.safecall("shop_fast_buy", args,
													function(data)
														if data.result == 0 then
															MessageBox.ShowWithTwoButtons(lang:GetText("你的FC点不足，请充值"),lang:GetText("充值"),lang:GetText("取消"),
																					function()
																						gui:ShowIE()
																					end,
																					nil
																					)
														else
															MessageBox.ShowWithTimer(1,lang:GetText("购买成功"))
															AddNum(Rapid_Shopping_Win_ui.Tbox_Totle_num.Text,Shopping_info)
															HideRapidShoppingWin()
														end
													end)
					end,
				},
			},
		},
		
		Gui.ItemBoxBtn"itembox_hummer"
		{
			Style = "Gui.ItemBoxBtn_ib",
			Size = Vector2(153,79),
			Location = Vector2(536,353),--522  353
			--BtnLocation = Vector2(45, 72),
			--BtnText = lang:GetText("购买"),
			--Enable = false,
			BackgroundColor = ARGB(255,255,255,255),
			Skin = Gui.ItemBoxBtnSkin
			{
				NeutralNormalImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_02.dds", Vector4(0, 0, 0, 0)),
				--NeutralHoverImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_02.dds", Vector4(0, 0, 0, 0)),
				NeutralSelectedImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_02.dds", Vector4(0, 0, 0, 0)),
				NeutralDisabledImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_02.dds", Vector4(0, 0, 0, 0)),
			},
			
			--ItemIcon = Gui.Icon("LobbyUI/ibt_icon/machet_4.tga"),
			--Padding = Vector4(10,0,10,0),
			
			--ItemIconPastDue = Gui.Icon("LobbyUI/ShoppingMall/vip_chest/lb_vipgifts_slot_flash.dds"),
	--[[		EventMouseEnter = function(sender, e)
				L_ToolTips.FillToolTipsVIPPresent(1, Rapid_Shopping_Win_ui.Rapid_Shopping_root, magice_hummer_Info)
			end,
			EventToolTipsShow = function(sender, e)
				L_ToolTips.ShowToolTipsShowWindow(sender,Vector2(1200, 900),sender.Location + sender.Parent.Location)
			end,
			EventMouseLeave = function(sender, e)
				L_ToolTips.HideToolTipsWindow()
			end,]]
			
		},
		--退出
		Gui.Button
		{
			Size = Vector2(48,48),
			Location = Vector2(770, 265),--743  270
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_normal.dds", Vector4(10, 10, 10, 10)),
				HoverImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_hover.dds", Vector4(10, 10, 10, 10)),
				DownImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_down.dds", Vector4(10, 10, 10, 10)),
				DisabledImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_disabled.dds", Vector4(0, 0, 0, 0)),	
			},
			EventClick = function()
				HideRapidShoppingWin()
			end,
		},
	},
}

function ShowShootingShoppingWin(Info)
	print("--------------ShowShootingShoppingWin--------------------")
	if Info == nil then
		return
	end
	print("info = "..Info.display)
	if Rapid_Shopping_Win_ui == nil then
		Rapid_Shopping_Win_ui = Gui.Create()(Rapid_Shopping_Win)
		--快速购买界面初始化
		RapidShopping_Window = ModalWindow.GetNew("Rapid_Shopping_Win_ui")
		RapidShopping_Window.screen.AllowEscToExit = false
		RapidShopping_Window.screen.Visible = false
		--RapidShopping_Window.screen.EventEscPressed = HideCharmBottleWin
		RapidShopping_Window.screen.EventEscPressed = nil
		RapidShopping_Window.root.Size = Vector2(1200, 900)
		Rapid_Shopping_Win_ui.Rapid_Shopping_root.Parent = RapidShopping_Window.root
	end
	Shopping_info = Info
	Rapid_Shopping_Win_ui.des.Text = Shopping_info.description
	Rapid_Shopping_Win_ui.name.Text = Shopping_info.display
	if RapidShopping_Window and RapidShopping_Window.screen then
		RapidShopping_Window.screen.Visible = true
		--gui.EventEscPressed = HideCharmBottleWin
		gui.EventEscPressed = nil
	end
	FileHummerItemBox()
end

function HideRapidShoppingWin()
	if RapidShopping_Window and RapidShopping_Window.screen then
		RapidShopping_Window.screen.Visible = false
		Rapid_Shopping_Win_ui = nil
		RapidShopping_Window:Close()
	end
end

function FileHummerItemBox()
	Rapid_Shopping_Win_ui.itembox_hummer.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..Shopping_info.name..".tga")
	Rapid_Shopping_Win_ui.Tbox_Totle_num.Text = 1
end

function SetHummerTotalMoney()
	if Rapid_Shopping_Win_ui.Tbox_Totle_num.Text == "" then
		Rapid_Shopping_Win_ui.Total_money.Text = "0"
		return
	end
	Rapid_Shopping_Win_ui.Total_money.Text = Shopping_info.crprices[1].cost * Rapid_Shopping_Win_ui.Tbox_Totle_num.Text / Shopping_info.crprices[1].unit
end

--进入靶场子弹选择界面
local Shooting_jion_Win = 
{
	Gui.Control "Shooting_jion_root"
	{	
		Size = Vector2(1200, 900),
		BackgroundColor = ARGB(0, 255, 255, 255),
		Location = Vector2(0, 0),
		
		Gui.Control
		{	
			Size = Vector2(426, 317),--366
			BackgroundColor = ARGB(255, 255, 255, 255),
			Dock = "kDockCenter",
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/main_bar01.dds", Vector4(20, 20, 20, 20)),
			},

			Gui.Control
			{	
				Size = Vector2(404, 294),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Location = Vector2(11, 12),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/main_bar02.dds", Vector4(8, 8, 8, 8)),
				},
				
				Gui.Label
				{
					Size = Vector2(404, 35),
					Location = Vector2(0, 0),
					TextColor = ARGB(255, 216, 216, 216),
					FontSize = 16,
					TextAlign = "kAlignLeftMiddle",
					Text = lang:GetText("选择子弹后进入靶场"),
					BackgroundColor = ARGB(255,255,255,255),
					TextPadding = Vector4(16,0,0,8),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_onlinetime_bg_5.dds", Vector4(8, 8, 8, 8)),
					},
				},
				
				Gui.Control
				{	
					Size = Vector2(386, 182),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Location = Vector2(5, 39),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/Shooting/lb_range_tankuang.dds", Vector4(7, 7, 7, 7)),
					},
					
					Gui.Label "lb_gold_ammo_name"
					{
						Size = Vector2(150, 20),
						Location = Vector2(192, 19),--30  149
						TextColor = ARGB(255, 254, 224, 1),
						FontSize = 14,
						TextAlign = "kAlignCenterMiddle",
						BackgroundColor = ARGB(0,255,255,255),
						TextPadding = Vector4(0,0,0,2),
					},
					
					-- 黄金子弹
					Gui.ItemBoxBtn "gold_ammo"
					{
						Style = "Gui.ItemBoxBtn_ib",
						Size = Vector2(100,94),
						Location = Vector2(220, 46),-- 41  46
						--BtnLocation = Vector2(45, 72),
						--BtnText = lang:GetText("购买"),
						--Enable = false,
						BackgroundColor = ARGB(255,255,255,255),
						Skin = Gui.ItemBoxBtnSkin
						{
							NeutralNormalImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche2_normal.dds", Vector4(10, 10, 10, 10)),
							NeutralHoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_wuqi_hover.dds", Vector4(10, 10, 10, 10)),
							NeutralSelectedImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_wuqi_down.dds", Vector4(10, 10, 10, 10)),
							NeutralDisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_caowei_teshuwuqi.dds", Vector4(10, 10, 10, 10)),
						},
						
						--ItemIcon = Gui.Icon("LobbyUI/ibt_icon/machet_4.tga"),
						Padding = Vector4(5,5,5,5),
						
						EventSelected = function()
							
						end,
						
						--ItemIconPastDue = Gui.Icon("LobbyUI/ShoppingMall/vip_chest/lb_vipgifts_slot_flash.dds"),
						EventMouseEnter = function(sender, e)
							if ammo_Info[1].i_value == 1 then
								L_ToolTips.FillToolTipsVIPPresent(1, Shooting_jion_Win_ui.Shooting_jion_root, ammo_Info)
							elseif ammo_Info[2].i_value == 1 then
								L_ToolTips.FillToolTipsVIPPresent(2, Shooting_jion_Win_ui.Shooting_jion_root, ammo_Info)
							end
						end,
						EventToolTipsShow = function(sender, e)
							local loc = sender.Location + sender.Parent.Location + sender.Parent.Parent.Location + sender.Parent.Parent.Parent.Location + sender.Parent.Parent.Parent.Parent.Location
							L_ToolTips.ShowToolTipsShowWindow(sender,Vector2(1200, 900),loc)
						end,
						EventMouseLeave = function(sender, e)
							L_ToolTips.HideToolTipsWindow()
						end,
						
						Gui.Button
						{
							Size = Vector2(100,94),
							Location = Vector2(0, 0),
							BackgroundColor = ARGB(0, 255, 255, 255),
							Skin = Gui.ButtonSkin
							{
								BackgroundImage = nil,
								HoverImage = nil,
								DownImage = nil,
								DisabledImage = nil,	
							},
														
							EventClick = function()
								SetAmmoClick(1)
							end,
							
							EventDoubleClick = function()
								Select_Ammo()
							end,
						},
					},
					
					Gui.Label
					{
						Size = Vector2(150, 20),
						Location = Vector2(192, 149),--30  149
						TextColor = ARGB(255, 254, 224, 1),
						FontSize = 14,
						TextAlign = "kAlignCenterMiddle",
						Text = lang:GetText("进入黄金靶场"),
						BackgroundColor = ARGB(0,255,255,255),
						TextPadding = Vector4(0,0,0,2),
					},					
					
					Gui.Label "lb_silver_ammo_name"
					{
						Size = Vector2(150, 20),
						Location = Vector2(25, 19),-- 177  149
						TextColor = ARGB(255, 216, 216, 216),
						FontSize = 14,
						TextAlign = "kAlignCenterMiddle",
						BackgroundColor = ARGB(0,255,255,255),
						TextPadding = Vector4(0,0,0,2),
					},
					
					-- 白银子弹
					Gui.ItemBoxBtn "silver_ammo"
					{
						Style = "Gui.ItemBoxBtn_ib",
						Size = Vector2(100,94),
						Location = Vector2(51, 46), --190  46
						--BtnLocation = Vector2(45, 72),
						--BtnText = lang:GetText("购买"),
						--Enable = false,
						BackgroundColor = ARGB(255,255,255,255),
						Skin = Gui.ItemBoxBtnSkin
						{
							NeutralNormalImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche2_normal.dds", Vector4(10, 10, 10, 10)),
							NeutralHoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_wuqi_hover.dds", Vector4(10, 10, 10, 10)),
							NeutralSelectedImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_wuqi_down.dds", Vector4(10, 10, 10, 10)),
							NeutralDisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_caowei_teshuwuqi.dds", Vector4(10, 10, 10, 10)),
						},
						
						--ItemIcon = Gui.Icon("LobbyUI/ibt_icon/machet_4.tga"),
						Padding = Vector4(5,5,5,5),
						
						EventSelected = function()
							
						end,
						
						--ItemIconPastDue = Gui.Icon("LobbyUI/ShoppingMall/vip_chest/lb_vipgifts_slot_flash.dds"),
						EventMouseEnter = function(sender, e)
							if ammo_Info[1].i_value == 0 then
								L_ToolTips.FillToolTipsVIPPresent(1, Shooting_jion_Win_ui.Shooting_jion_root, ammo_Info)
							elseif ammo_Info[2].i_value == 0 then
								L_ToolTips.FillToolTipsVIPPresent(2, Shooting_jion_Win_ui.Shooting_jion_root, ammo_Info)
							end
						end,
						EventToolTipsShow = function(sender, e)
							local loc = sender.Location + sender.Parent.Location + sender.Parent.Parent.Location + sender.Parent.Parent.Parent.Location + sender.Parent.Parent.Parent.Parent.Location
							L_ToolTips.ShowToolTipsShowWindow(sender,Vector2(1200, 900),loc)
						end,
						EventMouseLeave = function(sender, e)
							L_ToolTips.HideToolTipsWindow()
						end,
						
						Gui.Button
						{
							Size = Vector2(100,94),
							Location = Vector2(0, 0),
							BackgroundColor = ARGB(0, 255, 255, 255),
							
							Skin = Gui.ButtonSkin
							{
								BackgroundImage = nil,
								HoverImage = nil,
								DownImage = nil,
								DisabledImage = nil,	
							},
							
							EventClick = function()
								SetAmmoClick(0)
							end,
							
							EventDoubleClick = function()
								Select_Ammo()
							end,
						},
					},
					
					Gui.Label
					{
						Size = Vector2(150, 20),
						Location = Vector2(25, 149),-- 177  149
						TextColor = ARGB(255, 216, 216, 216),
						FontSize = 14,
						TextAlign = "kAlignCenterMiddle",
						Text = lang:GetText("进入白银靶场"),
						BackgroundColor = ARGB(0,255,255,255),
						TextPadding = Vector4(0,0,0,2),
					},
				},
				
				--确定
				Gui.Button
				{
					Size = Vector2(180,38),
					Location = Vector2(20, 240),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Text = lang:GetText("确 定"),
					TextColor = ARGB(255, 229, 255, 252),
					TextAlign = "kAlignCenterMiddle",
					HighlightTextColor = ARGB(255, 229, 255, 252),
					Padding = Vector4(0, 0, 0, 5),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/lb_onlinetime_button_2_normal.dds", Vector4(20, 0, 20, 0)),
						HoverImage = Gui.Image("LobbyUI/lb_onlinetime_button_2_hover.dds", Vector4(20, 0, 20, 0)),
						DownImage = Gui.Image("LobbyUI/lb_onlinetime_button_2_down.dds", Vector4(20, 0, 20, 0)),
						DisabledImage = Gui.Image("LobbyUI/lb_onlinetime_button_2_disabled.dds", Vector4(20, 0, 20, 0)),
					},
					EventClick = function()
						Select_Ammo()
					end,
				},
				
				--取消
				Gui.Button
				{
					Size = Vector2(180,38),
					Location = Vector2(210, 240),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Text = lang:GetText("取消"),
					TextColor = ARGB(255, 229, 255, 252),
					TextAlign = "kAlignCenterMiddle",
					HighlightTextColor = ARGB(255, 229, 255, 252),
					Padding = Vector4(0, 0, 0, 5),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/lb_onlinetime_button_2_normal.dds", Vector4(20, 0, 20, 0)),
						HoverImage = Gui.Image("LobbyUI/lb_onlinetime_button_2_hover.dds", Vector4(20, 0, 20, 0)),
						DownImage = Gui.Image("LobbyUI/lb_onlinetime_button_2_down.dds", Vector4(20, 0, 20, 0)),
						DisabledImage = Gui.Image("LobbyUI/lb_onlinetime_button_2_disabled.dds", Vector4(20, 0, 20, 0)),
					},
					EventClick = function()
						HideShootingJionWin()
						L_WarZone.is_novice = false
					end,
				},
			},
		},
	},
}

function ShowShootingJionWin(data)
	if Shooting_jion_Win_ui == nil then
		Shooting_jion_Win_ui = Gui.Create()(Shooting_jion_Win)
		--进入靶场子弹选择界面初始化
		Shootingjion_Window = ModalWindow.GetNew("Shooting_jion_Win_ui")
		Shootingjion_Window.screen.AllowEscToExit = false
		Shootingjion_Window.screen.Visible = false
		--Shootingjion_Window.screen.EventEscPressed = HideCharmBottleWin
		Shootingjion_Window.screen.EventEscPressed = nil
		Shootingjion_Window.root.Size = Vector2(1200, 900)
		Shooting_jion_Win_ui.Shooting_jion_root.Parent = Shootingjion_Window.root
	end
	ammo_Info = data.list
	SetAmmoClick(0)
	if data and data.list then
		if data.list[1].i_value == 0 then
			L_Characters.CreatPresentNumCtr(Shooting_jion_Win_ui.silver_ammo,data.list[1].unit,100,94)
			L_Characters.CreatPresentNumCtr(Shooting_jion_Win_ui.gold_ammo,data.list[2].unit,100,94)
			Shooting_jion_Win_ui.silver_ammo.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..data.list[1].name..".tga")
			Shooting_jion_Win_ui.gold_ammo.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..data.list[2].name..".tga")
			Shooting_jion_Win_ui.lb_silver_ammo_name.Text = data.list[1].display
			Shooting_jion_Win_ui.lb_gold_ammo_name.Text = data.list[2].display
		elseif data.list[1].i_value == 1 then
			L_Characters.CreatPresentNumCtr(Shooting_jion_Win_ui.gold_ammo,data.list[1].unit,100,94)
			L_Characters.CreatPresentNumCtr(Shooting_jion_Win_ui.silver_ammo,data.list[2].unit,100,94)
			Shooting_jion_Win_ui.gold_ammo.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..data.list[1].name..".tga")
			Shooting_jion_Win_ui.silver_ammo.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..data.list[2].name..".tga")
			Shooting_jion_Win_ui.lb_silver_ammo_name.Text = data.list[2].display
			Shooting_jion_Win_ui.lb_gold_ammo_name.Text = data.list[1].display
		end
	end
	if Shootingjion_Window and Shootingjion_Window.screen then
		Shootingjion_Window.screen.Visible = true
		--gui.EventEscPressed = HideCharmBottleWin
		gui.EventEscPressed = nil
	end
end

function HideShootingJionWin()
	if Shootingjion_Window and Shootingjion_Window.screen then
		Shootingjion_Window.screen.Visible = false
		Shootingjion_Window:Close()
		Shooting_jion_Win_ui = nil
	end
end

function SetAmmoClick(num)
	if num == 1 then
		Shooting_jion_Win_ui.gold_ammo.Selected = true
		Shooting_jion_Win_ui.silver_ammo.Selected = false
	elseif num == 0 then
		Shooting_jion_Win_ui.gold_ammo.Selected = false
		Shooting_jion_Win_ui.silver_ammo.Selected = true
	end
	ammo_type = num
end

function Select_Ammo()
	HideShootingJionWin()
	rpc.safecall("shooting_join", {pid = ptr_cast(game.CurrentState):GetCharacterId(),type = ammo_type},Show,
																									function()
																										L_WarZone.is_novice = false
																									end)	
end

--靶场界面前头函数
function CreatShootingBtn()
	return Gui.Control
			{
				Size = Vector2(92, 154),--92  141
				--Location = Vector2(shooting_btn_location[num + 1][1], shooting_btn_location[num + 1][2]),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Visible = false,
				
				Gui.Label "lab_ctrtimer"
				{
					Size = Vector2(50,120),
					Location = Vector2(0, 0),
					BackgroundColor = ARGB(0, 255, 255, 255),
					Visible = false,
					UseTimer = true,
					DisplayTime = 3,
				},
				
				--偷看按钮
				Gui.Button "btn_look"
				{
					Size = Vector2(44,46),
					Location = Vector2(24, 36),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/Shooting/lb_range_button_peek_normal.dds", Vector4(0, 0, 0, 0)),
						HoverImage = Gui.Image("LobbyUI/Shooting/lb_range_button_peek_hover.dds", Vector4(0, 0, 0, 0)),
						DownImage = Gui.Image("LobbyUI/Shooting/lb_range_button_peek_down.dds", Vector4(0, 0, 0, 0)),
						DisabledImage = Gui.Image("LobbyUI/Shooting/lb_range_button_peek_normal.dds", Vector4(0, 0, 0, 0)),	
					},
					
				},
				
				--射击按钮
				Gui.AnimControl "Target"
				{
					Size = Vector2(54,79),--32 60
					BackgroundColor = ARGB(0, 255, 255, 255),
					Location = Vector2(19, 75), --9 60
					PushDown = false,
				},
				
				Gui.ChangeControl "CCtr_Look_bg"
				{
					Location = Vector2(0,0),
					NormLocation = Vector2(0,0),
					Size = Vector2(92,92),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Normsize = Vector2(92,92),
					Visible = false,
				},
				
				Gui.ChangeControl "CCtr_Look_item"
				{
					Location = Vector2(16,16),
					NormLocation = Vector2(16,16),
					Size = Vector2(92,92),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Normsize = Vector2(92,92),
					Visible = false,
				},
			}
end

--排行榜按钮
function ListBTNClick(num)
	Shooting_Win_ui.btn_shooting_list.PushDown = false
	Shooting_Win_ui.btn_goodluck_list.PushDown = false
	if num == 1 then
		Shooting_Win_ui.btn_shooting_list.PushDown = true
	elseif num == 2 then
		Shooting_Win_ui.btn_goodluck_list.PushDown = true
	end
	InitialList(num)
end
--靶场界面
local Shooting_Win = 
{
	Gui.Control "Shooting_Win_root"
	{
		Size = Vector2(1200, 900),
		Dock = "kDockCenter",
		BackgroundColor = ARGB(0, 255, 255, 255),
		Gui.Control 
		{			
			Size = Vector2(1116, 596),
			--Location = Vector2(19, 25),
			Dock = "kDockCenter",
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/mail/lb_shop_bg2.dds", Vector4(14, 14, 14, 14)),
			},
			Gui.Control 
			{
				Size = Vector2(1116, 575),
				Location = Vector2(0, 20),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_daoju_bg.tga", Vector4(22, 22, 22, 22)),
				},
				
				Gui.MouseControl "ctr_shooting_win_type"
				{
					Size = Vector2(688, 379),
					Location = Vector2(208, 49),
					BackgroundColor = ARGB(255, 255, 255, 255),
					
					Gui.ChangeControl "ctr_shooting_Back"
					{
						Size = Vector2(666, 363),
						Location = Vector2(10, 8),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Normsize = Vector2(666, 363),
						NormLocation = Vector2(10, 8),
						NormBackgroundColor = ARGB(255, 255, 255, 255),
						
						CreatShootingBtn(),
						CreatShootingBtn(),
						CreatShootingBtn(),
						CreatShootingBtn(),
						CreatShootingBtn(),
						CreatShootingBtn(),
						CreatShootingBtn(),
						CreatShootingBtn(),
						CreatShootingBtn(),
						
						--子弹
						Gui.ChangeControl "CCtr_Anim_Fly"
						{
							Size = Vector2(15,10),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Normsize = Vector2(15,10),
							Visible = false,
						},
						
						--罐子飞走控件
						Gui.ChangeControl "CCtr_Tin_Fly"
						{
							Size = Vector2(54,79),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Normsize = Vector2(54,79),
							Visible = false,
						},
						
						--子弹火花
						Gui.ChangeControl "CCtr_Anim_Light"
						{
							Size = Vector2(80,50),
							BackgroundColor = ARGB(255, 255, 255, 255),
							BackgroundColor = ARGB(255, 255, 255, 255),
							Normsize = Vector2(80,50),
							UseTime = true,
							DisplayTime = 0.05,
							Enable = false,
							Visible = false,
						},
					},
					
					Gui.Control
					{
						Size = Vector2(659, 41),
						Location = Vector2(13, 11),
						BackgroundColor = ARGB(255, 255, 255, 255),
						
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/Shooting/lb_range_round_bg.dds", Vector4(10, 0, 10, 0)),
						},
						
						Gui.Control
						{
							Size = Vector2(80, 20),
							Location = Vector2(11, 10),
							BackgroundColor = ARGB(255, 255, 255, 255),
							
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/Shooting/lb_range_round.dds", Vector4(0, 0, 0, 0)),
							},
						},
						
						Gui.FlowLayout "bout_num_layout"
						{
							Location = Vector2(95,10),
							Size = Vector2(100,20),
							Direction = "kHorizontal",
							Align = "kAlignLeftMiddle",
							ControlAlign = "kAlignCenterMiddle",
							ControlSpace = 2,
						},
						
						Gui.Control
						{
							Size = Vector2(62, 40),
							Location = Vector2(191, 0),
							BackgroundColor = ARGB(255, 255, 255, 255),
							
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/Shooting/lb_range_times.dds", Vector4(0, 0, 0, 0)),
							},
						},
						
						Gui.FlowLayout "dartle_num_layout"
						{
							Location = Vector2(262,10),
							Size = Vector2(100,20),
							Direction = "kHorizontal",
							Align = "kAlignLeftMiddle",
							ControlAlign = "kAlignCenterMiddle",
							ControlSpace = 2,
						},
						
						Gui.Control "ctr_look_tools"
						{
							Size = Vector2(72, 36),
							Location = Vector2(358, 1),
							BackgroundColor = ARGB(255, 255, 255, 255),							
						},
						
						Gui.FlowLayout "Look_num_layout"
						{
							Location = Vector2(433,10),
							Size = Vector2(100,20),
							Direction = "kHorizontal",
							Align = "kAlignLeftMiddle",
							ControlAlign = "kAlignCenterMiddle",
							ControlSpace = 2,
						},
						
						Gui.Control "ctr_ammo_nums"
						{
							Size = Vector2(44, 36),
							Location = Vector2(522, 2),
							BackgroundColor = ARGB(255, 255, 255, 255),						
						},
						
						Gui.FlowLayout "ammo_num_layout"
						{
							Location = Vector2(577,10),
							Size = Vector2(100,20),
							Direction = "kHorizontal",
							Align = "kAlignLeftMiddle",
							ControlAlign = "kAlignCenterMiddle",
							ControlSpace = 2,
						},
					},
				},
				
				
				Gui.Control
				{
					Size = Vector2(190, 498),
					Location = Vector2(19, 60),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/Shooting/lb_range_bg_01.dds", Vector4(0, 12, 0, 13)),
					},
				},
				
				Gui.Control
				{
					Size = Vector2(212, 111),
					Location = Vector2(7, 29),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/Shooting/lb_range_award_title.dds", Vector4(0, 0, 0, 0)),
					},
				},
				
				Gui.ShaderControl
				{
					Size = Vector2(212, 111),
					Location = Vector2(7, 29),
					BackgroundColor = ARGB(255, 255, 255, 255),
					ShaderPS = "control_anim",
					Skin = Gui.ShaderSkin
					{
						ResImage1 = Gui.Image("LobbyUI/Shooting/lb_range_award_title.dds", Vector4(0, 0, 0, 0)),
						ResImage2 = Gui.Image("LobbyUI/Shooting/chenjiu_mask_01.dds", Vector4(15, 15, 15, 15)),
						ResImage3 = Gui.Image("LobbyUI/effect/strip.dds", Vector4(15, 15, 15, 15)),
					},
				},
				 
				Gui.Control
				{
					Size = Vector2(182, 535),
					Location = Vector2(23, 27),
					BackgroundColor = ARGB(0, 255, 255, 255),
					
					-- 连射奖励
					Gui.ItemBoxBtn "IBTN_shootings_gift"
					{
						Style = "Gui.ItemBoxBtn_ib",
						Size = Vector2(165,76),
						Location = Vector2(8,98),
						--BtnLocation = Vector2(45, 72),
						--BtnText = lang:GetText("购买"),
						--Enable = false,
						BackgroundColor = ARGB(255,255,255,255),
						Skin = Gui.ItemBoxBtnSkin
						{
							NeutralNormalImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche1_normal.dds", Vector4(10, 10, 10, 10)),
							--NeutralHoverImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_02.dds", Vector4(0, 0, 0, 0)),
							NeutralSelectedImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche1_normal.dds", Vector4(10, 10, 10, 10)),
							NeutralDisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche1_normal.dds", Vector4(10, 10, 10, 10)),
						},
						
						--ItemIcon = Gui.Icon("LobbyUI/ibt_icon/machet_4.tga"),
						Padding = Vector4(5,5,5,5),
						
						--ItemIconPastDue = Gui.Icon("LobbyUI/ShoppingMall/vip_chest/lb_vipgifts_slot_flash.dds"),
						EventMouseEnter = function(sender, e)
							L_ToolTips.FillToolTipsVIPPresent_item(Shooting_Win_ui.Shooting_Win_root, RPC_Shooting_Info.dartle_gift)
						end,
						EventToolTipsShow = function(sender, e)
							local loc = sender.Location + sender.Parent.Location + sender.Parent.Parent.Location + sender.Parent.Parent.Parent.Location + sender.Parent.Parent.Parent.Parent.Location
							L_ToolTips.ShowToolTipsShowWindow(sender,Vector2(1200, 900),loc)
						end,
						EventMouseLeave = function(sender, e)
							L_ToolTips.HideToolTipsWindow()
						end,
					},
					
					Gui.Control
					{
						Size = Vector2(168, 32),
						Location = Vector2(7, 68),
						BackgroundColor = ARGB(255, 255, 255, 255),
						
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_onlinetime_bg_5.dds", Vector4(8, 8, 8, 8)),
						},
					},
					
					Gui.Control
					{
						Size = Vector2(36, 52),
						Location = Vector2(5, 64),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Enable = false,
						
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/Shooting/lb_range_win_02dds.dds", Vector4(0, 0, 0, 0)),
						},
					},
					
					Gui.Control "Cctr_flash_Bg"
					{
						Location = Vector2(97, 82),
						Size = Vector2(93, 60),
						BackgroundColor = ARGB(255, 255, 255, 255),
						UseTime = true,
						DisplayTime = 0.3,
						Enable = false,
					},				
					
					Gui.Control
					{
						Size = Vector2(128, 72),
						Location = Vector2(45, 60),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Enable = false,
						
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/Shooting/lb_range_title_03.dds", Vector4(0, 0, 0, 0)),
						},
					},
					
					Gui.FlowLayout "needDartle_Num_layout"
					{
						Location = Vector2(122, 82),
						Size = Vector2(50,50),
						Direction = "kHorizontal",
						Align = "kAlignCenterMiddle",
						ControlAlign = "kAlignCenterMiddle",
						ControlSpace = 2,
						Enable = false,
					},
					
					Gui.Control
					{
						Size = Vector2(168, 32),
						Location = Vector2(7, 190),
						BackgroundColor = ARGB(255, 255, 255, 255),
						
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_onlinetime_bg_5.dds", Vector4(8, 8, 8, 8)),
						},
					},
					
					Gui.ItemBoxBtn "IBTN_gold_shooting_gift"
					{
						Style = "Gui.ItemBoxBtn_ib",
						Size = Vector2(165,76),
						Location = Vector2(8,219),
						--BtnLocation = Vector2(45, 72),
						--BtnText = lang:GetText("购买"),
						--Enable = false,
						BackgroundColor = ARGB(255,255,255,255),
						Skin = Gui.ItemBoxBtnSkin
						{
							NeutralNormalImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche1_normal.dds", Vector4(10, 10, 10, 10)),
							--NeutralHoverImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_02.dds", Vector4(0, 0, 0, 0)),
							NeutralSelectedImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche1_normal.dds", Vector4(10, 10, 10, 10)),
							NeutralDisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche1_normal.dds", Vector4(10, 10, 10, 10)),
						},
						
						--ItemIcon = Gui.Icon("LobbyUI/ibt_icon/machet_4.tga"),
						Padding = Vector4(5,5,5,5),
						
						--ItemIconPastDue = Gui.Icon("LobbyUI/ShoppingMall/vip_chest/lb_vipgifts_slot_flash.dds"),
						EventMouseEnter = function(sender, e)
							L_ToolTips.FillToolTipsVIPPresent_item(Shooting_Win_ui.Shooting_Win_root, RPC_Shooting_Info.gold_gift)
						end,
						EventToolTipsShow = function(sender, e)
							local loc = sender.Location + sender.Parent.Location + sender.Parent.Parent.Location + sender.Parent.Parent.Parent.Location + sender.Parent.Parent.Parent.Parent.Location
							L_ToolTips.ShowToolTipsShowWindow(sender,Vector2(1200, 900),loc)
						end,
						EventMouseLeave = function(sender, e)
							L_ToolTips.HideToolTipsWindow()
						end,
						
					},
					
					Gui.Control
					{
						Size = Vector2(36, 52),
						Location = Vector2(5, 186),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Enable = false,
						
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/Shooting/lb_range_win_01.dds", Vector4(0, 0, 0, 0)),
						},
					},
					
					Gui.Control
					{
						Size = Vector2(92, 40),
						Location = Vector2(45, 186),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Enable = false,
						
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/Shooting/lb_range_title_01.dds", Vector4(0, 0, 0, 0)),
						},
					},
					
					Gui.Control
					{
						Size = Vector2(168, 32),
						Location = Vector2(7, 292),
						BackgroundColor = ARGB(255, 255, 255, 255),
						
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_onlinetime_bg_5.dds", Vector4(8, 8, 8, 8)),
						},
					},
					
					Gui.ItemBoxBtn "IBTN_silver_shooting_gift"
					{
						Style = "Gui.ItemBoxBtn_ib",
						Size = Vector2(165,76),
						Location = Vector2(8,320),
						--BtnLocation = Vector2(45, 72),
						--BtnText = lang:GetText("购买"),
						--Enable = false,
						BackgroundColor = ARGB(255,255,255,255),
						Skin = Gui.ItemBoxBtnSkin
						{
							NeutralNormalImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche1_normal.dds", Vector4(10, 10, 10, 10)),
							--NeutralHoverImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_02.dds", Vector4(0, 0, 0, 0)),
							NeutralSelectedImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche1_normal.dds", Vector4(10, 10, 10, 10)),
							NeutralDisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche1_normal.dds", Vector4(10, 10, 10, 10)),
						},
						
						--ItemIcon = Gui.Icon("LobbyUI/ibt_icon/machet_4.tga"),
						Padding = Vector4(5,5,5,5),
						
						--ItemIconPastDue = Gui.Icon("LobbyUI/ShoppingMall/vip_chest/lb_vipgifts_slot_flash.dds"),
						EventMouseEnter = function(sender, e)
							L_ToolTips.FillToolTipsVIPPresent_item( Shooting_Win_ui.Shooting_Win_root, RPC_Shooting_Info.silver_gift)
						end,
						EventToolTipsShow = function(sender, e)
							local loc = sender.Location + sender.Parent.Location + sender.Parent.Parent.Location + sender.Parent.Parent.Parent.Location + sender.Parent.Parent.Parent.Parent.Location
							L_ToolTips.ShowToolTipsShowWindow(sender,Vector2(1200, 900),loc)
						end,
						EventMouseLeave = function(sender, e)
							L_ToolTips.HideToolTipsWindow()
						end,
						
					},
					
					Gui.Control
					{
						Size = Vector2(36, 52),
						Location = Vector2(5, 288),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Enable = false,
						
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/Shooting/lb_range_win_02.dds", Vector4(0, 0, 0, 0)),
						},
					},
					
					Gui.Control
					{
						Size = Vector2(92, 40),
						Location = Vector2(45, 288),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Enable = false,
						
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/Shooting/lb_range_title_02.dds", Vector4(0, 0, 0, 0)),
						},
					},
					
					Gui.Control
					{
						Size = Vector2(168, 32),
						Location = Vector2(7, 410),
						BackgroundColor = ARGB(255, 255, 255, 255),
						
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_onlinetime_bg_5.dds", Vector4(8, 8, 8, 8)),
						},
					},
					
					Gui.ItemBoxBtn "IBTN_norm_shooting_gift"
					{
						Style = "Gui.ItemBoxBtn_ib",
						Size = Vector2(165,76),
						Location = Vector2(8,438),
						--BtnLocation = Vector2(45, 72),
						--BtnText = lang:GetText("购买"),
						--Enable = false,
						BackgroundColor = ARGB(255,255,255,255),
						Skin = Gui.ItemBoxBtnSkin
						{
							NeutralNormalImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche1_normal.dds", Vector4(10, 10, 10, 10)),
							--NeutralHoverImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_02.dds", Vector4(0, 0, 0, 0)),
							NeutralSelectedImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche1_normal.dds", Vector4(10, 10, 10, 10)),
							NeutralDisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche1_normal.dds", Vector4(10, 10, 10, 10)),
						},
						
						--ItemIcon = Gui.Icon("LobbyUI/ibt_icon/machet_4.tga"),
						Padding = Vector4(5,5,5,5),
						
						--ItemIconPastDue = Gui.Icon("LobbyUI/ShoppingMall/vip_chest/lb_vipgifts_slot_flash.dds"),
						EventMouseEnter = function(sender, e)
							L_ToolTips.FillToolTipsVIPPresent(1, Shooting_Win_ui.Shooting_Win_root, RPC_Shooting_Info.common_gift)
						end,
						EventToolTipsShow = function(sender, e)
							local loc = sender.Location + sender.Parent.Location + sender.Parent.Parent.Location + sender.Parent.Parent.Parent.Location + sender.Parent.Parent.Parent.Parent.Location
							L_ToolTips.ShowToolTipsShowWindow(sender,Vector2(1200, 900),loc)
						end,
						EventMouseLeave = function(sender, e)
							L_ToolTips.HideToolTipsWindow()
						end,
						
					},
					
					Gui.Control
					{
						Size = Vector2(36, 52),
						Location = Vector2(5, 406),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Enable = false,
						
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/Shooting/lb_range_win_04.dds", Vector4(0, 0, 0, 0)),
						},
					},
					
					Gui.Control
					{
						Size = Vector2(92, 40),
						Location = Vector2(45, 406),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Enable = false,
						
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/Shooting/lb_range_title_04.dds", Vector4(0, 0, 0, 0)),
						},
					},
				},
				
				-- 白银靶场按钮
				Gui.Button "btn_silver_Shooting"
				{
					Size = Vector2(236,44),
					Location = Vector2(405, 13),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/Shooting/lb_range_button_silver_normal.dds", Vector4(80, 0, 20, 0)),
						HoverImage = Gui.Image("LobbyUI/Shooting/lb_range_button_silver_hover.dds", Vector4(80, 0, 20, 0)),
						DownImage = Gui.Image("LobbyUI/Shooting/lb_range_button_silver_down.dds", Vector4(80, 0, 20, 0)),
						DisabledImage = Gui.Image("LobbyUI/Shooting/lb_range_button_silver_normal.dds", Vector4(80, 0, 20, 0)),
					},
					EventClick = function()
						if Shooting_Win_ui.btn_silver_Shooting.PushDown == false then
							MessageBox.ShowWithTwoButtons(lang:GetText("你确定要去白银靶场吗？\n你的连射次数将被清空").."  ",lang:GetText("确定"),lang:GetText("取消"), 
							function()
								ammo_type = 0
								rpc.safecall("shooting_join", {pid = ptr_cast(game.CurrentState):GetCharacterId(),type = ammo_type},ShowShootingWin)
							end,
							function()
								
							end
							)
						end
					end,
					
					Gui.Label
					{
						Size = Vector2(190, 44),
						Location = Vector2(49, 1),
						BackgroundColor = ARGB(0,255,255,255),
						Text = lang:GetText("白银靶场"),
						Padding = Vector4(0 ,0 ,0 ,0),
						FontSize = 16,
						TextAlign = "kAlignCenterMiddle",
						TextColor = ARGB(255,0,0,0),
					},
					
					Gui.Label
					{
						Size = Vector2(190, 44),
						Location = Vector2(48, 0),
						BackgroundColor = ARGB(0,255,255,255),
						Text = lang:GetText("白银靶场"),
						Padding = Vector4(0 ,0 ,0 ,0),
						FontSize = 16,
						TextAlign = "kAlignCenterMiddle",
						TextColor = ARGB(255,255,255,255),
					},
				},
				
				-- 黄金靶场按钮
				Gui.Button "btn_gold_Shooting"
				{
					Size = Vector2(236,44),
					Location = Vector2(642, 13),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/Shooting/lb_range_button_gold_normal.dds", Vector4(80, 0, 20, 0)),
						HoverImage = Gui.Image("LobbyUI/Shooting/lb_range_button_gold_hover.dds", Vector4(80, 0, 20, 0)),
						DownImage = Gui.Image("LobbyUI/Shooting/lb_range_button_gold_down.dds", Vector4(80, 0, 20, 0)),
						DisabledImage = Gui.Image("LobbyUI/Shooting/lb_range_button_gold_normal.dds", Vector4(80, 0, 20, 0)),
					},
					EventClick = function()
						if Shooting_Win_ui.btn_gold_Shooting.PushDown == false then
							MessageBox.ShowWithTwoButtons(lang:GetText("你确定要去黄金靶场吗？\n你的连射次数将被清空").."  ",lang:GetText("确定"),lang:GetText("取消"), 
							function()
								ammo_type = 1
								rpc.safecall("shooting_join", {pid = ptr_cast(game.CurrentState):GetCharacterId(),type = ammo_type},ShowShootingWin)
							end,
							function()
								
							end
							)
						end
					end,
					
					Gui.Label
					{
						Size = Vector2(190, 44),
						Location = Vector2(49, 1),
						BackgroundColor = ARGB(0,255,255,255),
						Text = lang:GetText("黄金靶场"),
						Padding = Vector4(0 ,0 ,0 ,0),
						FontSize = 16,
						TextAlign = "kAlignCenterMiddle",
						TextColor = ARGB(255,0,0,0),
					},
					
					Gui.Label
					{
						Size = Vector2(190, 44),
						Location = Vector2(48, 0),
						BackgroundColor = ARGB(0,255,255,255),
						Text = lang:GetText("黄金靶场"),
						Padding = Vector4(0 ,0 ,0 ,0),
						FontSize = 16,
						TextAlign = "kAlignCenterMiddle",
						TextColor = ARGB(255,255,250,163),
					},
				},
				
				Gui.Control "ctr_Shooting_Foot_bg"
				{
					Size = Vector2(678, 138),
					Location = Vector2(211, 418),
					BackgroundColor = ARGB(255, 255, 255, 255),
				},
				
				-- 游戏规则
				Gui.Control
				{
					Size = Vector2(354, 123),
					Location = Vector2(211, 428),
					BackgroundColor = ARGB(0, 255, 255, 255),
					
					Gui.Control
					{
						Size = Vector2(148, 48),
						Location = Vector2(8, 5),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/Shooting/lb_range_rule_bg.dds", Vector4(0, 0, 0, 0)),
						},
					},
					
					Gui.Label
					{
						Size = Vector2(300, 20),
						Location = Vector2(20, 8),
						TextColor = ARGB(255, 216, 216, 216),
						FontSize = 14,
						TextAlign = "kAlignLeftMiddle",
						Text = lang:GetText("游戏规则："),
						BackgroundColor = ARGB(0,255,255,255),
						--TextPadding = Vector4(0,0,0,0),
					},
					
					Gui.Label
					{
						Size = Vector2(300, 20),
						Location = Vector2(20, 28),
						TextColor = ARGB(255, 216, 216, 216),
						FontSize = 12,
						TextAlign = "kAlignLeftMiddle",
						Text = " ■ "..lang:GetText("使用白银/黄金子弹进入白银/黄金靶场"),
						BackgroundColor = ARGB(0,255,255,255),
						--TextPadding = Vector4(0,0,0,0),
					},
					Gui.Label
					{
						Size = Vector2(300, 20),
						Location = Vector2(20, 44),
						TextColor = ARGB(255, 255, 0, 0),
						FontSize = 12,
						TextAlign = "kAlignLeftMiddle",
						Text = " ■ "..lang:GetText("偷看可以看到标靶后面的奖励"),
						BackgroundColor = ARGB(0,255,255,255),
						--TextPadding = Vector4(0,0,0,0),
					},
					Gui.Label
					{
						Size = Vector2(300, 20),
						Location = Vector2(20, 60),
						TextColor = ARGB(255, 255, 0, 0),
						FontSize = 12,
						TextAlign = "kAlignLeftMiddle",
						Text = " ■ "..lang:GetText("当本轮的奖励都不合你意时，可以使用刷新功能"),
						BackgroundColor = ARGB(0,255,255,255),
						--TextPadding = Vector4(0,0,0,0),
					},
					Gui.Label
					{
						Size = Vector2(300, 20),
						Location = Vector2(20, 76),
						TextColor = ARGB(255, 216, 216, 0),
						FontSize = 12,
						TextAlign = "kAlignLeftMiddle",
						Text = " ■ "..lang:GetText("连续射击达到规定的次数可以获得丰厚连射奖励"),
						BackgroundColor = ARGB(0,255,255,255),
						--TextPadding = Vector4(0,0,0,0),
					},
					Gui.Label
					{
						Size = Vector2(300, 20),
						Location = Vector2(20, 92),
						TextColor = ARGB(255, 216, 216, 216),
						FontSize = 12,
						TextAlign = "kAlignLeftMiddle",
						Text = " ■ "..lang:GetText("退出靶场连射次数自动重置"),
						BackgroundColor = ARGB(0,255,255,255),
						--TextPadding = Vector4(0,0,0,0),
					},
				},
				
				Gui.Control
				{
					Size = Vector2(320, 128),
					Location = Vector2(552, 426),
					BackgroundColor = ARGB(0, 255, 255, 255),
					
					-- 刷新
					Gui.Button "btn_Refurbish"
					{
						Size = Vector2(96,40),
						Location = Vector2(90, 32),
						BackgroundColor = ARGB(255, 255, 255, 255),
						--blink_shade = false,
						--blink = false,
						
						EventClick = function()
							if Shooting_state == true then
								MessageBox.ShowWithTimer(1,lang:GetText("请稍候！"))
								return
							end
							local args = {pid = ptr_cast(game.CurrentState):GetCharacterId(),type = ammo_type,action_type = 4,index = 0}
							L_MessageBox.ShowWaiter(lang:GetText("正在请求数据..."))
							rpc.safecall("shooting",args ,
												function(data)
													if data then
														UpdataShootingStateInfo(data)
														ReSetLooklist()
													end
													L_MessageBox.CloseWaiter()
												end)
						end,
						
						Gui.FlashControl "flash_root"
						{
							Text = "lb_range_button_renovate_flash",
							Location = Vector2(0, 0),
							Size = Vector2(96,40),
							BackgroundColor = ARGB(80, 255, 255, 255),
							Visible = false,
							Enable = false,
						},
					},
					
					-- 全部偷看
					Gui.Button "btn_All_look_shooting"
					{
						Size = Vector2(88,88),
						Location = Vector2(221, 22),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/Shooting/lb_range_button_allpeek_normal.dds", Vector4(0, 0, 0, 0)),
							HoverImage = Gui.Image("LobbyUI/Shooting/lb_range_button_allpeek_hover.dds", Vector4(0, 0, 0, 0)),
							DownImage = Gui.Image("LobbyUI/Shooting/lb_range_button_allpeek_down.dds", Vector4(0, 0, 0, 0)),
							DisabledImage = Gui.Image("LobbyUI/Shooting/lb_range_button_allpeek_disabled.dds", Vector4(0, 0, 0, 0)),	
						},
						EventClick = function()
							if Shooting_state == true then
								MessageBox.ShowWithTimer(1,lang:GetText("请稍候！"))
								return
							end
							MessageBox.ShowWithTwoButtons(lang:GetText("全部偷看将消耗").." "..All_look_target_num.." "..lang:GetText("个")..RPC_Shooting_Info.look_item.display,lang:GetText("确定"),lang:GetText("取消"),
															function()
																local args = {pid = ptr_cast(game.CurrentState):GetCharacterId(),type = ammo_type,action_type = 3,index = 0}
																L_MessageBox.ShowWaiter(lang:GetText("正在请求数据..."))
																rpc.safecall("shooting",args ,
																				function(data)
																					if data.warning then
																						MessageBox.ShowWithTwoButtons(data.warning,lang:GetText("购买"),lang:GetText("返回"), 
																													function()																			
																														ShowShootingShoppingWin(RPC_Shooting_Info.look_item)
																													end,
																													function()
																														
																													end
																													)
																					else																						
																						UpdataShootingStateInfo(data)
																						ShowAllBackPrize(data.list)
																					end
																					L_MessageBox.CloseWaiter()
																				end)
															end,
															function()
															end)
						end,
					},
				},
				
				-- 排行榜
				Gui.Control
				{
					Size = Vector2(204, 483),
					Location = Vector2(895, 30),
					BackgroundColor = ARGB(255, 255, 255, 255),
					
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/Shooting/lb_range_charts_01.dds", Vector4(0, 50, 0, 8)),
					},
					
					--连射排行榜
					Gui.Button "btn_shooting_list"
					{
						Size = Vector2(100,44),
						Location = Vector2(4, 4),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/Shooting/lb_range_button_award_01_normal.dds", Vector4(0, 0, 0, 0)),
							HoverImage = Gui.Image("LobbyUI/Shooting/lb_range_button_award_01_hover.dds", Vector4(0, 0, 0, 0)),
							DownImage = Gui.Image("LobbyUI/Shooting/lb_range_button_award_01_down.dds", Vector4(0, 0, 0, 0)),
							DisabledImage = Gui.Image("LobbyUI/Shooting/lb_range_button_award_01_normal.dds", Vector4(0, 0, 0, 0)),
						},
						EventClick = function()
							ListBTNClick(1)
						end,
					},
					
					--好运排行榜
					Gui.Button "btn_goodluck_list"
					{
						Size = Vector2(100,44),
						Location = Vector2(100, 4),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/Shooting/lb_range_button_award_02_normal.dds", Vector4(0, 0, 0, 0)),
							HoverImage = Gui.Image("LobbyUI/Shooting/lb_range_button_award_02_hover.dds", Vector4(0, 0, 0, 0)),
							DownImage = Gui.Image("LobbyUI/Shooting/lb_range_button_award_02_down.dds", Vector4(0, 0, 0, 0)),
							DisabledImage = Gui.Image("LobbyUI/Shooting/lb_range_button_award_02_normal.dds", Vector4(0, 0, 0, 0)),
						},
						EventClick = function()
							ListBTNClick(2)
						end,
					},
					
					Gui.ScrollableControl "scroll"
					{
						Size = Vector2(196, 412),
						Location = Vector2(5, 55),
						AutoScroll = true,
						--VScrollBarPos = Vector2(-40,0),
						--Default_Width = 60,
						--Default_Size = 60,
						VScrollBarButtonSize = 32,
						VScrollBarWidth = 32,
						VScrollBarHeight = 407,
						VScrollBarDisplay = true,
						AutoScrollMinSize = Vector2(120,1000),
						BackgroundColor = ARGB(255,255,255,255),
						--Style = "Gui.MessagePanel",
						
						Gui.FlowLayout "scrollLayout"
						{
							AutoSize = true,
							LineSpace = 0,
						},
					},
				},
				
				Gui.Button 
				{
					Size = Vector2(203, 36),
					Location = Vector2(895, 515),
					--Hint = lang:GetText("关闭"),
					BackgroundColor = ARGB(255, 255, 255, 255),
					TextColor = ARGB(255, 0, 0, 0),
					HighlightTextColor = ARGB(255, 0, 0, 0),
					Padding = Vector4(0, 0, 0, 5),
					FontSize = 16,
					TextAlign = "kAlignCenterMiddle",
					Text = lang:GetText("购买子弹"),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_v2_01_normal.dds", Vector4(10, 0, 10, 0)),
						HoverImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_v2_01_hover.dds", Vector4(10, 0, 10, 0)),
						DownImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_v2_01_down.dds", Vector4(10, 0, 10, 0)),
						DisabledImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_v2_01_disabled.dds", Vector4(10, 0, 10, 0)),
					},									
					EventClick = function()
						if ammo_Info[1].i_value == ammo_type then
							ShowShootingShoppingWin(ammo_Info[1])
						elseif ammo_Info[2].i_value == ammo_type then
							ShowShootingShoppingWin(ammo_Info[2])
						end
					end,
				},
			},
			
			Gui.Button 
			{
				Size = Vector2(64, 52),
				Location = Vector2(1052, 0),
				Hint = lang:GetText("关闭"),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Shooting/lb_range_button_close_normal.dds", Vector4(0, 0, 0, 0)),
					HoverImage = Gui.Image("LobbyUI/Shooting/lb_range_button_close_hover.dds", Vector4(0, 0, 0, 0)),
					DownImage = Gui.Image("LobbyUI/Shooting/lb_range_button_close_down.dds", Vector4(0, 0, 0, 0)),
					DisabledImage = Gui.Image("LobbyUI/Shooting/lb_range_button_close_normal.dds", Vector4(0, 0, 0, 0)),
				},
				EventClick = function()
					if Shooting_state == true then
						MessageBox.ShowWithTimer(1,lang:GetText("请稍候！"))
						return
					end
					MessageBox.ShowWithTwoButtons(lang:GetText("你确定要退出靶场界面吗？\n你的连射次数将被清空").."    ",lang:GetText("确定"),lang:GetText("返回"), 
						function()
							HideShootingWin()
						end,
						function()
							
						end
						)
				end,
			},
		},
	},
}

function ShowShootingWin(data)
	if Shooting_Win_ui == nil then
		Shooting_Win_ui = Gui.Create()(Shooting_Win)
		--靶场界面初始化
		Shooting_Window = ModalWindow.GetNew("Shooting_Win_ui")
		Shooting_Window.screen.AllowEscToExit = false
		Shooting_Window.screen.Visible = false
		--Shooting_Window.screen.EventEscPressed = HideCharmBottleWin
		Shooting_Window.screen.EventEscPressed = nil
		Shooting_Window.root.Size = Vector2(1200, 900)
		Shooting_Win_ui.Shooting_Win_root.Parent = Shooting_Window.root
		
		Shooting_Win_ui.Cctr_flash_Bg:DeleteAllImage()
		Shooting_Win_ui.Cctr_flash_Bg:AddFrame(Gui.Image("LobbyUI/Shooting/lb_range_award_bg.dds",Vector4(0, 0, 0, 0)))
		Shooting_Win_ui.Cctr_flash_Bg:AddFrame(Gui.Image("LobbyUI/Shooting/lb_range_award_bg_1.dds",Vector4(0, 0, 0, 0)))
	end
	Shooting_Win_ui.ctr_Shooting_Foot_bg.Skin = Gui.ControlSkin
	{
		BackgroundImage = Gui.Image("LobbyUI/Shooting/lb_range_button_bg_0"..ammo_type..".dds", Vector4(30, 0, 400, 0)),
	}
	Shooting_Win_ui.ctr_look_tools.Skin = Gui.ControlSkin
	{
		BackgroundImage = Gui.Image("LobbyUI/Shooting/lb_range_peek_"..ammo_type..".dds", Vector4(0, 0, 0, 0)),
	}
	Shooting_Win_ui.ctr_ammo_nums.Skin = Gui.ControlSkin
	{
		BackgroundImage = Gui.Image("LobbyUI/Shooting/lb_range_bullet_"..ammo_type..".dds", Vector4(0, 0, 0, 0)),
	}
	Shooting_Win_ui.btn_Refurbish.Skin = Gui.ButtonSkin
	{
		BackgroundImage = Gui.Image("LobbyUI/Shooting/lb_range_button_renovate_"..ammo_type.."_normal.dds", Vector4(0, 0, 0, 0)),
		HoverImage = Gui.Image("LobbyUI/Shooting/lb_range_button_renovate_"..ammo_type.."_hover.dds", Vector4(0, 0, 0, 0)),
		DownImage = Gui.Image("LobbyUI/Shooting/lb_range_button_renovate_"..ammo_type.."_down.dds", Vector4(0, 0, 0, 0)),
		DisabledImage = Gui.Image("LobbyUI/Shooting/lb_range_button_renovate_"..ammo_type.."_normal.dds", Vector4(0, 0, 0, 0)),
		TwinkleImage  = Gui.Image("LobbyUI/Shooting/lb_range_button_renovate_"..ammo_type.."_flash.dds", Vector4(0, 0, 0, 0)),
	}
	RPC_Shooting_Info = data
	--连射奖励记录
	Shooting_Total_num = -1
	UpDataShootingDartlePrizeInfo()
	if data then
		ShowShootingAllState(data)
	end
	ShowShootingType(ammo_type)
	ListBTNClick(2)
	if Shooting_Window and Shooting_Window.screen then
		Shooting_Window.screen.Visible = true
		--gui.EventEscPressed = HideCharmBottleWin
		gui.EventEscPressed = nil
	end
end

function UpDataShootingDartlePrizeInfo()
	if Shooting_Total_num ~= RPC_Shooting_Info.needDartleNum then
		dartelPrize_confirm = false
	else
		return
	end
	Shooting_Total_num = RPC_Shooting_Info.needDartleNum
	Shooting_Prize = RPC_Shooting_Info.dartle_gift
end

function HideShootingWin()
	if Shooting_Window and Shooting_Window.screen then
		Shooting_Window.screen.Visible = false
		L_WarZone.is_novice = false
		Shooting_Window:Close()
		Shooting_Win_ui = nil
	end
	ptr_cast(game.CurrentState):OnChange_Lobby_Music(2)
end

function UpdataShootingStateInfo(data)
	RPC_Shooting_Info.bout_num = data.bout_num
	RPC_Shooting_Info.dartle_num = data.dartle_num
	RPC_Shooting_Info.ammo_num = data.ammo_num
	RPC_Shooting_Info.look_num = data.look_num
	RPC_Shooting_Info.dartle_gift = data.dartle_gift
	RPC_Shooting_Info.needDartleNum = data.needDartleNum
	RPC_Shooting_Info.look_item.unit = data.look_num
	if dartelPrize_confirm == false and RPC_Shooting_Info.dartle_num >= Shooting_Total_num then
		ShowShootingDartleprizeWin()
	end
	ShowShootingAllState(RPC_Shooting_Info)
end

function AddNumCtr(m_Parent,info,whith,hight,Is_Icon)
	m_Parent:OnDestroy()
	if info.unit and info.common.type == 5 then
		L_Characters.CreatPresentNumCtr(m_Parent,info.unit,whith,hight)
	elseif info.unit and info.common.type == 4 and info.common.subtype == 7 then
		L_Characters.CreatPresentNumCtr(m_Parent,info.unit,whith,hight)
	end
	--稀有度图片添加
	if info.common.rareLevel > 0 then
		AddCtrrareLevel(m_Parent,info.common.rareLevel,whith,0)
	end
	--装备等级图片添加
	if info.common.strength > 0 then
		AddCtrstrength(m_Parent,info.common.strength,whith,hight)
	end
	if Is_Icon then
		if info.color > 0 and info.color < 8 then
			m_Parent.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..info.name.."_"..info.color..".tga")
		else
			m_Parent.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..info.name..".tga")
		end
	end
end

function ShowShootingAllState(data)
	AddNumCtr(Shooting_Win_ui.IBTN_gold_shooting_gift,data.gold_gift,165,73,true)
	AddNumCtr(Shooting_Win_ui.IBTN_silver_shooting_gift,data.silver_gift,165,73,true)
	AddNumCtr(Shooting_Win_ui.IBTN_norm_shooting_gift,data.common_gift[1],165,73,true)
	AddNumCtr(Shooting_Win_ui.IBTN_shootings_gift,data.dartle_gift,165,73,true)
	ShowShootingState(data)
end

function ShowShootingState(data)
	L_LobbyMain.ShowFightnums(Shooting_Win_ui.bout_num_layout,data.bout_num)
	L_LobbyMain.ShowFightnums(Shooting_Win_ui.dartle_num_layout,data.dartle_num)
	L_LobbyMain.ShowFightnums(Shooting_Win_ui.Look_num_layout,data.look_item.unit)
	L_LobbyMain.ShowFightnums(Shooting_Win_ui.ammo_num_layout,data.ammo_num)
	L_LobbyMain.ShowFightnums(Shooting_Win_ui.needDartle_Num_layout,data.needDartleNum,"Shooting/lb_range_number.dds",13,42)
end

function ShowShootingType(type)
	print("------------ShowShootingType-----------")
	if type == 0 then
		Shooting_Win_ui.btn_silver_Shooting.PushDown = true
		Shooting_Win_ui.btn_gold_Shooting.PushDown = false
	elseif type == 1 then
		Shooting_Win_ui.btn_silver_Shooting.PushDown = false
		Shooting_Win_ui.btn_gold_Shooting.PushDown = true
	end
	Shooting_Win_ui.ctr_shooting_win_type.Skin = Gui.ControlSkin
	{
		BackgroundImage = Gui.Image("LobbyUI/Shooting/lb_range_screen_"..type..".dds", Vector4(138, 23, 115, 19)),
	}
	ReSetLooklist()
	ammo_type = type
end

--生成随机靶场界面参数
function SetShooting_BackgroundWhich()
	local which_Tep = Shooting_Background_num
	local Teb_num = table.getn(shooting_btn_location_Parent)
	if Teb_num > 1 then
		while which_Tep == Shooting_Background_num do
			which_Tep = math.random(Teb_num)
		end
	else
		which_Tep = Teb_num
	end
	Shooting_Background_num = which_Tep
	Shooting_Win_ui.ctr_shooting_Back.Skin = Gui.ControlSkin
	{
		BackgroundImage = shooting_Background_Image[Shooting_Background_num],
	}
end

--重置靶场状态
function ReSetLooklist()
	DeleteShootingBtn(Shooting_Win_ui.ctr_shooting_Back)
	Shooting_Win_ui.ctr_shooting_Back.BackgroundColor = ARGB(255,0,0,0)
	SetShooting_BackgroundWhich()
	Shooting_Win_ui.ctr_shooting_Back:Clear()
	Shooting_Win_ui.ctr_shooting_Back:InsertMovePoint(Vector2(10, 8),0,Vector2(666, 363),ARGB(255,0,0,0))
	Shooting_Win_ui.ctr_shooting_Back:InsertMovePoint(Vector2(10, 8),0.6,Vector2(666, 363),ARGB(255,250,250,250))
	Shooting_Win_ui.ctr_shooting_Back.EventPlayEnd = function(Sender,e)
												for i = 1, table.getn(look_list) do
													look_list[i] = 0
												end
												Shooting_Win_ui.ctr_shooting_Back.Size = Shooting_Win_ui.ctr_shooting_Back.Normsize
												Shooting_Win_ui.ctr_shooting_Back.Location = Shooting_Win_ui.ctr_shooting_Back.NormLocation
												Shooting_Win_ui.ctr_shooting_Back.BackgroundColor = Shooting_Win_ui.ctr_shooting_Back.NormBackgroundColor
												Shooting_Win_ui.btn_All_look_shooting.Enable = true
												Shooting_Win_ui.flash_root.Visible = false
												Shooting_state = false
												RandomCreatShooting(Shooting_Background_num)
												CreateShootingBtn(Shooting_Win_ui.ctr_shooting_Back)
											end		
end

--删除射击按钮
function DeleteShootingBtn(m_parent)
	--m_parent:OnDestroy()
	local i = 0
	local ibbtn = nil
	while ptr_cast(m_parent:GetChildByIndex(i)) do
		ibbtn = ptr_cast(m_parent:GetChildByIndex(i))
		ibbtn.Visible = false
		if ptr_cast(ibbtn:GetChildByIndex(1)) then
			ptr_cast(ibbtn:GetChildByIndex(1)).Visible = true
		end
		if ptr_cast(ibbtn:GetChildByIndex(2)) then
			ptr_cast(ibbtn:GetChildByIndex(2)).Visible = true
		end
		if ptr_cast(ibbtn:GetChildByIndex(3)) then
			ptr_cast(ibbtn:GetChildByIndex(3)).Visible = false
		end
		if ptr_cast(ibbtn:GetChildByIndex(4)) then
			ptr_cast(ibbtn:GetChildByIndex(4)).Visible = false
		end
		i = i + 1
	end
end

--创建射击偷看 BTN
function CreateShootingBtn(m_parent)
	local i = 0
	while shooting_btn_location[i + 1] do
		ShowShootingBtn(m_parent,i)
		i = i + 1
	end
end

function ShowShootingBtn(m_parent,num)
	local ibbtn = ptr_cast(m_parent:GetChildByIndex(num))
	local ibbtnblab_ctrtimer = ptr_cast(ibbtn:GetChildByIndex(0))
	local ibbtnbtn_look = ptr_cast(ibbtn:GetChildByIndex(1))
	local ibbtnTarget = ptr_cast(ibbtn:GetChildByIndex(2))
	local ibbtnCCtr_Look_bg = ptr_cast(ibbtn:GetChildByIndex(3))
	local ibbtnCCtr_Look_item = ptr_cast(ibbtn:GetChildByIndex(4))
	ibbtn.Location = Vector2(shooting_btn_location[num + 1][1], shooting_btn_location[num + 1][2])
	ibbtn.Visible = true
	ibbtnTarget.EventClick = function(Sender,e)
					if Shooting_state == true then
						MessageBox.ShowWithTimer(1,lang:GetText("请稍候！"))
						return
					end
					Shooting_state = true
					Shooting_Win_ui.flash_root.Visible = false
					local args = {pid = ptr_cast(game.CurrentState):GetCharacterId(),type = ammo_type,action_type = 1,index = num}
					--L_MessageBox.ShowWaiter(lang:GetText("正在请求数据..."))
					rpc.safecall("shooting",args ,
									function(data)
										if data then
											if data.warning then
												Shooting_state = false
												--MessageBox.ShowWithTimer(1,data.warning)
												-- 快速购买
												MessageBox.ShowWithTwoButtons(data.warning,lang:GetText("是"),lang:GetText("否"), 
																			function()
																				if ammo_Info[1].i_value == ammo_type then
																					ShowShootingShoppingWin(ammo_Info[1])
																				elseif ammo_Info[2].i_value == ammo_type then
																					ShowShootingShoppingWin(ammo_Info[2])
																				end
																			end,
																			function()
																				
																			end
																			)
											else
												ibbtnbtn_look.Visible = false
												CreatShootingFlyAnim(Sender,m_parent,num,function()
																						UpdataShootingStateInfo(data)
																						if data.list[num + 1].name == "emptyBottle" then
																							MessageBox.ShowWithConfirm(lang:GetText("你打中了空靶，连射中断了\n继续试试吧!"), ShowAllBackPrizeShootingEnd(data.list,num + 1,ReSetLooklist))
																							--ShowShootingNoprizeWin(data,num + 1)
																						else
																							ShowShootingprizeWin(data,num + 1)
																						end																						
																					  end)
											end
										end
										--L_MessageBox.CloseWaiter()
									end)
				end
	ibbtnbtn_look.EventClick = function()
					if Shooting_state == true then
						MessageBox.ShowWithTimer(1,lang:GetText("请稍候！"))
						return
					end
					if look_list[num + 1] == 1 then
						MessageBox.ShowWithTimer(1,lang:GetText("您已经偷看过了！"))
						return
					end
					local args = {pid = ptr_cast(game.CurrentState):GetCharacterId(),type = ammo_type,action_type = 2,index = num}
					L_MessageBox.ShowWaiter(lang:GetText("正在请求数据..."))
					rpc.safecall("shooting",args ,
								function(data)
									if data then
										if data.warning then
											MessageBox.ShowWithTwoButtons(data.warning,lang:GetText("购买"),lang:GetText("返回"), 
																		function()																			
																			ShowShootingShoppingWin(RPC_Shooting_Info.look_item)
																		end,
																		function()
																			
																		end
																		)
										else
											UpdataShootingStateInfo(data)
											ShowLookAnimCtr(ibbtnCCtr_Look_bg,ibbtnCCtr_Look_item,data.list[1],num + 1)
											--偷看翻牌 屏蔽
											--ShowBackPrize(ibbtnTarget,data.list[1],num + 1,ibbtnblab_ctrtimer)
										end
									end
									L_MessageBox.CloseWaiter()
								end)
				end
	ibbtnblab_ctrtimer.EventClose = function()
									ibbtnTarget:TrunCardContiue()
								end
	ibbtnTarget:AddAnim("TurnCard",0.5,5)
	
	ibbtnCCtr_Look_bg.EventPlayEnd = function(Sender,e)					
									ibbtnCCtr_Look_bg.Visible = false
								end
	ibbtnCCtr_Look_item.EventPlayEnd = function(Sender,e)					
									ibbtnCCtr_Look_item.Visible = false
								end
	
	ibbtnTarget:DeleteFrameList("TurnCard")
	local cardback =  Gui.Image("LobbyUI/Shooting/lb_range_target_"..ammo_type..".dds", Vector4(0, 0, 0, 0))
	local cardfront = Gui.Image("LobbyUI/GameBalance/lb_summary_flop_card_front.dds", Vector4(0,0,0,0))
	ibbtnTarget:AddFrame("TurnCard",cardback,Vector4(0, 0, 0, 0))
	ibbtnTarget:AddFrame("TurnCard",cardfront,Vector4(0, 0, 0, 0))
	ibbtnTarget:StartAnimation()
end

function CreatShootingFlyAnim(item,m_parent,num,event)
	Shooting_Win_ui.CCtr_Anim_Fly.Visible = true
	Shooting_Win_ui.CCtr_Anim_Fly.Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/Shooting/lb_range_ammunition"..ammo_type..".dds", Vector4(0, 0, 0, 0)),
							}
	Shooting_Win_ui.CCtr_Anim_Fly.Location = Vector2(700, 81 + shooting_btn_location[num + 1][2] + 30)
	Shooting_Win_ui.CCtr_Anim_Fly.NormLocation = Vector2(700, 81 + shooting_btn_location[num + 1][2] + 30)
	Shooting_Win_ui.CCtr_Anim_Fly.EventPlayEnd = function(Sender,e)
										item.Visible = false
										Shooting_Win_ui.CCtr_Anim_Fly.Visible = false
										CreatShootingFlyTin(m_parent,num,event)
										gui:PlayAudio("kUIA_SHOOTING_ON_HIT")
									end
	
	local f_pos = (700 - (19 + shooting_btn_location[num + 1][1] + 30))/2000
	Shooting_Win_ui.CCtr_Anim_Fly:Clear()
	Shooting_Win_ui.CCtr_Anim_Fly:InsertMovePoint(Vector2(19 + shooting_btn_location[num + 1][1] + 30,81 + shooting_btn_location[num + 1][2] + 30),f_pos,Vector2(15,10),ARGB(255,255,255,255))
end

function CreatShootingFlyTin(m_parent,num,event)
	Shooting_Win_ui.CCtr_Tin_Fly.Visible = true
	Shooting_Win_ui.CCtr_Tin_Fly.Location = Vector2(19 + shooting_btn_location[num + 1][1], 81 + shooting_btn_location[num + 1][2])
	Shooting_Win_ui.CCtr_Tin_Fly.NormLocation = Vector2(19 + shooting_btn_location[num + 1][1], 81 + shooting_btn_location[num + 1][2])
	Shooting_Win_ui.CCtr_Tin_Fly.Skin = Gui.ControlSkin
										{
											BackgroundImage = Gui.Image("LobbyUI/Shooting/lb_range_target_"..ammo_type..".dds", Vector4(0, 0, 0, 0)),
										}
	Shooting_Win_ui.CCtr_Tin_Fly.EventPlayEnd = function(Sender,e)				
										Sender.Visible = false
										if event then
											event()
										end
									end
	Shooting_Win_ui.CCtr_Tin_Fly:Clear()
	Shooting_Win_ui.CCtr_Tin_Fly:InsertMovePoint(Vector2(19 + shooting_btn_location[num + 1][1] - 100,81 + shooting_btn_location[num + 1][2] - 60),0.1,Vector2(54,79),ARGB(255,255,255,255))
	Shooting_Win_ui.CCtr_Tin_Fly:InsertMovePoint(Vector2(19 + shooting_btn_location[num + 1][1] - 280,81 + shooting_btn_location[num + 1][2] + 200),0.3,Vector2(54,79),ARGB(255,255,255,255))
	ShowShootingWindowMove()
	ShowShootingAnimLight(m_parent,num)
end

function ShowShootingWindowMove()
	Shooting_Win_ui.ctr_shooting_Back:Clear()
	Shooting_Win_ui.ctr_shooting_Back:InsertMovePoint(Vector2(12, 10),0.05,Vector2(666, 363),ARGB(255,255,255,255))
	Shooting_Win_ui.ctr_shooting_Back:InsertMovePoint(Vector2(10, 8),0.1,Vector2(666, 363),ARGB(255,255,255,255))
	Shooting_Win_ui.ctr_shooting_Back:InsertMovePoint(Vector2(12, 10),0.15,Vector2(666, 363),ARGB(255,255,255,255))
	Shooting_Win_ui.ctr_shooting_Back:InsertMovePoint(Vector2(10, 8),0.2,Vector2(666, 363),ARGB(255,255,255,255))
	Shooting_Win_ui.ctr_shooting_Back.EventPlayEnd = function(Sender,e)
												
											end	
end

function ShowShootingAnimLight(m_parent,num)
	Shooting_Win_ui.CCtr_Anim_Light.Location = Vector2(19 + shooting_btn_location[num + 1][1], 81 + shooting_btn_location[num + 1][2] + 10)
	Shooting_Win_ui.CCtr_Anim_Light.NormLocation = Vector2(19 + shooting_btn_location[num + 1][1], 81 + shooting_btn_location[num + 1][2] + 10)
	Shooting_Win_ui.CCtr_Anim_Light:DeleteAllImage()
	Shooting_Win_ui.CCtr_Anim_Light.Visible = true
	Shooting_Win_ui.CCtr_Anim_Light:AddFrame(Gui.Image("LobbyUI/Shooting/lb_range_spark.dds",Vector4(0, 0, 0, 0),Vector4(0, 0, 1.0/3.0, 0.5)))
	Shooting_Win_ui.CCtr_Anim_Light:AddFrame(Gui.Image("LobbyUI/Shooting/lb_range_spark.dds",Vector4(0, 0, 0, 0),Vector4(1.0/3.0, 0, 2.0/3.0, 0.5)))
	Shooting_Win_ui.CCtr_Anim_Light:AddFrame(Gui.Image("LobbyUI/Shooting/lb_range_spark.dds",Vector4(0, 0, 0, 0),Vector4(1.0/3.0, 0, 1.0, 0.5)))
	Shooting_Win_ui.CCtr_Anim_Light:AddFrame(Gui.Image("LobbyUI/Shooting/lb_range_spark.dds",Vector4(0, 0, 0, 0),Vector4(0, 0.5, 1.0/3.0, 1.0)))
	Shooting_Win_ui.CCtr_Anim_Light:AddFrame(Gui.Image("LobbyUI/Shooting/lb_range_spark.dds",Vector4(0, 0, 0, 0),Vector4(1.0/3.0, 0.5, 2.0/3.0, 1.0)))
	Shooting_Win_ui.CCtr_Anim_Light:AddFrame(Gui.Image("LobbyUI/Shooting/lb_range_spark.dds",Vector4(0, 0, 0, 0),Vector4(2.0/3.0, 0.5, 1.0, 1.0)))
	
	Shooting_Win_ui.CCtr_Anim_Light:Clear()
	Shooting_Win_ui.CCtr_Anim_Light:InsertMovePoint(Vector2(19 + shooting_btn_location[num + 1][1], 81 + shooting_btn_location[num + 1][2] + 10),0.25,Vector2(80,50),ARGB(255,255,255,255))
	
	Shooting_Win_ui.CCtr_Anim_Light.EventPlayEnd = function(Sender,e)					
										Sender.Visible = false
									end
end

--偷看翻牌
function ShowBackPrize(item,info,num,timecontrol)
	print("-----------------------ShowBackPrize---------------------------------")
	local cardback =  Gui.Image("LobbyUI/Shooting/lb_range_target_"..ammo_type..".dds", Vector4(0, 0, 0, 0))
	local cardfront = Gui.Image("LobbyUI/GameBalance/lb_summary_flop_card_front.dds", Vector4(0,0,0,0))
	item:DeleteFrameList("TurnCard")
	item:AddFrame("TurnCard",cardback,Vector4(0, 0, 0, 0))
	item:AddFrame("TurnCard",cardfront,Vector4(0, 0, 0, 0))
	item:StartAnimation()
	
	local cardcontent = Gui.Image("LobbyUI/ibt_icon/"..info.name..".tga", Vector4(0,0,0,0))
	item:AddFrame("TurnCard",cardcontent,Vector4(0, 0, 0, 0))	
	item:TurnCard()
	--look_list[num] = 1
	--item.Enable = false
	
	timecontrol:Show()
end

--偷看动画
function ShowLookAnimCtr(ctr_bg,ctr_item,info,num)
	print("-----------------------ShowLookAnimCtr---------------------------------")
	ctr_bg.Skin = Gui.ControlSkin
	{
		BackgroundImage = Gui.Image("LobbyUI/Shooting/lb_range_award_frame.dds", Vector4(0, 0, 0, 0)),
	}
	if info.color > 0 and info.color < 8 then
		ctr_item.Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/ibt_icon/"..info.name.."_"..info.color..".tga", Vector4(0, 0, 0, 0)),
		}
	else
		ctr_item.Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/ibt_icon/"..info.name..".tga", Vector4(0, 0, 0, 0)),
		}
	end
	AddNumCtr(ctr_bg,info,75,75)
	ctr_bg.Visible = true
	ctr_item.Visible = true
	
	ctr_bg.Normsize = Vector2(92,92)
	ctr_bg.Size = Vector2(92,92)
	ctr_bg:Clear()
	ctr_bg:InsertMovePoint(Vector2(41,120),0,Vector2(10,10),ARGB(255,255,255,255))
	ctr_bg:InsertMovePoint(Vector2(0,0),0.3,Vector2(92,92),ARGB(255,255,255,255))
	ctr_bg:InsertMovePoint(Vector2(0,0),3,Vector2(92,92),ARGB(255,255,255,255))
	ctr_bg:InsertMovePoint(Vector2(41,120),3.5,Vector2(10,10),ARGB(255,255,255,255))
	ctr_bg:SetSize_Picture()
	
	ctr_item.Normsize = Vector2(92,92)
	ctr_item.Size = Vector2(92,92)
	ctr_item:Clear()
	ctr_item:InsertMovePoint(Vector2(43,122),0,Vector2(6,6),ARGB(255,255,255,255))
	ctr_item:InsertMovePoint(Vector2(21,21),0.3,Vector2(50,50),ARGB(255,255,255,255))
	ctr_item:InsertMovePoint(Vector2(21,21),3,Vector2(50,50),ARGB(255,255,255,255))
	ctr_item:InsertMovePoint(Vector2(43,122),3.5,Vector2(6,6),ARGB(255,255,255,255))
	ctr_item:SetSize_Picture()
	
	--Tooltips
	ctr_item.EventMouseEnter = function(sender, e)
		L_ToolTips.FillToolTipsVIPPresent_item(Shooting_Win_ui.Shooting_Win_root, info)
	end
	ctr_item.EventToolTipsShow = function(sender, e)
		local loc = sender.Location + sender.Parent.Location + sender.Parent.Parent.Location + sender.Parent.Parent.Parent.Location + sender.Parent.Parent.Parent.Parent.Location + sender.Parent.Parent.Parent.Parent.Parent.Location + sender.Parent.Parent.Parent.Parent.Parent.Parent.Location
		L_ToolTips.ShowToolTipsShowWindow(sender,Vector2(1200, 900),loc)
	end
	ctr_item.EventMouseLeave = function(sender, e)
		L_ToolTips.HideToolTipsWindow()
	end
	if Shooting_Win_ui.btn_All_look_shooting.Enable == true then
		Shooting_Win_ui.btn_All_look_shooting.Enable = false
		Shooting_Win_ui.flash_root.Visible = true
	end
	look_list[num] = 1
end

--全部偷看翻牌
function ShowAllBackPrize(info)
	print("-----------------------ShowAllBackPrize---------------------------------")
	local i = 1
	while shooting_btn_location[i] do
		local ibbtn = ptr_cast(Shooting_Win_ui.ctr_shooting_Back:GetChildByIndex(i - 1))
		local ibbtnChildFirst = ptr_cast(ibbtn:GetChildByIndex(0))
		local ibbtnChild = ptr_cast(ibbtn:GetChildByIndex(2))
		local ibbtnChildCtr_bg = ptr_cast(ibbtn:GetChildByIndex(3))
		local ibbtnChildCtr_item = ptr_cast(ibbtn:GetChildByIndex(4))
		if ibbtnChildCtr_bg and ibbtnChildCtr_item and info[i] then
			ShowLookAnimCtr(ibbtnChildCtr_bg,ibbtnChildCtr_item,info[i],i)
		end
		--偷看翻牌 屏蔽
		--if ibbtn and ibbtnChild and info[i] then
		--	ShowBackPrize(ibbtnChild,info[i],i,ibbtnChildFirst)
		--end
		i = i + 1
	end
end

--射击完偷看动画
function ShowLookAnimCtrShootingEnd(ctr_bg,ctr_item,info,num,event)
	print("-----------------------ShowLookAnimCtr---------------------------------")
	ctr_bg.Skin = Gui.ControlSkin
	{
		BackgroundImage = Gui.Image("LobbyUI/Shooting/lb_range_award_frame.dds", Vector4(0, 0, 0, 0)),
	}
	if info.color > 0 and info.color < 8 then
		ctr_item.Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/ibt_icon/"..info.name.."_"..info.color..".tga", Vector4(0, 0, 0, 0)),
		}
	else
		ctr_item.Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/ibt_icon/"..info.name..".tga", Vector4(0, 0, 0, 0)),
		}
	end
	AddNumCtr(ctr_bg,info,75,75,false)
	ctr_bg.Visible = true
	ctr_item.Visible = true
	
	ctr_bg.Normsize = Vector2(92,92)
	ctr_bg.Size = Vector2(92,92)
	ctr_bg:Clear()
	ctr_bg:InsertMovePoint(Vector2(41,120),0,Vector2(10,10),ARGB(255,255,255,255))
	ctr_bg:InsertMovePoint(Vector2(0,0),0.3,Vector2(92,92),ARGB(255,255,255,255))
	ctr_bg:InsertMovePoint(Vector2(0,0),2,Vector2(92,92),ARGB(255,255,255,255))
	ctr_bg:SetSize_Picture()
	
	ctr_item.Normsize = Vector2(92,92)
	ctr_item.Size = Vector2(92,92)
	ctr_item:Clear()
	ctr_item:InsertMovePoint(Vector2(43,122),0,Vector2(6,6),ARGB(255,255,255,255))
	ctr_item:InsertMovePoint(Vector2(21,21),0.3,Vector2(50,50),ARGB(255,255,255,255))
	ctr_item:InsertMovePoint(Vector2(21,21),2,Vector2(50,50),ARGB(255,255,255,255))
	ctr_item:SetSize_Picture()
	
	--Tooltips
	ctr_item.EventMouseEnter = function(sender, e)
		L_ToolTips.FillToolTipsVIPPresent_item(Shooting_Win_ui.Shooting_Win_root, info)
	end
	ctr_item.EventToolTipsShow = function(sender, e)
		local loc = sender.Location + sender.Parent.Location + sender.Parent.Parent.Location + sender.Parent.Parent.Parent.Location + sender.Parent.Parent.Parent.Parent.Location + sender.Parent.Parent.Parent.Parent.Parent.Location + sender.Parent.Parent.Parent.Parent.Parent.Parent.Location
		L_ToolTips.ShowToolTipsShowWindow(sender,Vector2(1200, 900),loc)
	end
	ctr_item.EventMouseLeave = function(sender, e)
		L_ToolTips.HideToolTipsWindow()
	end
	
	ctr_item.EventPlayEnd = function(Sender,e)
								if event then
									event()
								end
							end
	--look_list[num] = 1
end

--射击完翻出其它靶
function ShowAllBackPrizeShootingEnd(info,num,event)
	print("-----------------------ShowAllBackPrize---------------------------------")
	local i = 1
	local bool_Evnet = true
	while shooting_btn_location[i] do
		if i ~= num then
			local ibbtn = ptr_cast(Shooting_Win_ui.ctr_shooting_Back:GetChildByIndex(i - 1))
			local ibbtnChildFirst = ptr_cast(ibbtn:GetChildByIndex(0))
			local ibbtnChild = ptr_cast(ibbtn:GetChildByIndex(2))
			local ibbtnChildCtr_bg = ptr_cast(ibbtn:GetChildByIndex(3))
			local ibbtnChildCtr_item = ptr_cast(ibbtn:GetChildByIndex(4))
			if ibbtnChildCtr_bg and ibbtnChildCtr_item and info[i] then
				if bool_Evnet == true then
					ShowLookAnimCtrShootingEnd(ibbtnChildCtr_bg,ibbtnChildCtr_item,info[i],i,event)
					bool_Evnet = false
				else
					ShowLookAnimCtrShootingEnd(ibbtnChildCtr_bg,ibbtnChildCtr_item,info[i],i)
				end
			end
			--偷看翻牌 屏蔽
			--if ibbtn and ibbtnChild and info[i] then
			--	ShowBackPrize(ibbtnChild,info[i],i,ibbtnChildFirst)
			--end
		end
		i = i + 1
	end
end

--排行榜列表填充
function InitialList(num)
	if Shooting_Win_ui == nil then
		return
	end
	Shooting_Win_ui.scrollLayout:OnDestroy()
	local l_num = 0
	while l_num < 10 do
		if num == 1 then
			CreateInfoControl(Shooting_Win_ui.scrollLayout,RPC_Shooting_Info.dartle_top_list[l_num + 1],l_num + 1)
		elseif num == 2 then
			CreateInfoControl_Totip(Shooting_Win_ui.scrollLayout,RPC_Shooting_Info.dartle_awards_list[l_num + 1],l_num + 1)
		end
		l_num = l_num + 1
	end
	Shooting_Win_ui.scroll.AutoScrollMinSize = Vector2(120,l_num*41)
end

function CreateInfoControl(m_parent,info,num)
	local ctr = nil
	ctr = Gui.Create()
	{
		Gui.Control "ctr_local"
		{	
			Size = Vector2(196, 41),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Location = Vector2(0, 0),
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/Shooting/lb_range_charts_1.dds", Vector4(0, 0, 0, 0)),
			},
			
			Gui.Label "lb_list_num"
			{
				Size = Vector2(20, 20),
				Location = Vector2(10, 0),
				TextColor = ARGB(255, 255, 252, 0),
				FontSize = 12,
				TextAlign = "kAlignCenterMiddle",
				Text = num,
				BackgroundColor = ARGB(0,255,255,255),
				--TextPadding = Vector4(0,0,0,0),
			},
						
			Gui.Control "ctr_Tenold_bg"
			{	
				Size = Vector2(10, 20),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Location = Vector2(34, 0),
			},
			
			Gui.Control "ctr_Tenold_item"
			{	
				Size = Vector2(10, 20),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Location = Vector2(34, 0),
			},
			
			Gui.Control "ctr_Anold_bg"
			{	
				Size = Vector2(10, 20),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Location = Vector2(43, 0),
			},
			
			Gui.Control "ctr_Anold_item"
			{	
				Size = Vector2(10, 20),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Location = Vector2(43, 0),
			},
			
			Gui.Label "lb_name"
			{
				Size = Vector2(140, 20),
				Location = Vector2(55, 0),
				TextColor = ARGB(255, 216, 216, 216),
				FontSize = 12,
				TextAlign = "kAlignCenterMiddle",
				Text = "",
				BackgroundColor = ARGB(0,255,255,255),
				--TextPadding = Vector4(0,0,0,0),
			},
			
			Gui.Label "lb_ammo_num"
			{
				Size = Vector2(150, 20),
				Location = Vector2(30, 20),
				TextColor = ARGB(255, 255, 252, 0),
				FontSize = 12,
				TextAlign = "kAlignCenterMiddle",
				Text = "",
				BackgroundColor = ARGB(0,255,255,255),
				--TextPadding = Vector4(0,0,0,0),
			},
		},
	}
	if info then
		ctr.lb_name.Text = info[1]
		ctr.lb_ammo_num.Text = lang:GetText("连射").." "..info[3].." "..lang:GetText("次")
	else
		ctr.lb_list_num.Text = ""
	end
	if info then
		local Tenold = math.floor(info[2]/10)
		local Anold = info[2] - 10*Tenold
		ctr.ctr_Anold_bg.Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_summary_number_6b.dds", Vector4(0, 0, 0, 0),Vector4((Anold)/10,0,(Anold + 1)/10,1)),
		} 
		ctr.ctr_Anold_item.Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_summary_number_7b.dds", Vector4(0, 0, 0, 0),Vector4((Anold)/10,0,(Anold + 1)/10,1)),
		} 
		ctr.ctr_Tenold_bg.Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_summary_number_6b.dds", Vector4(0, 0, 0, 0),Vector4((Tenold)/10,0,(Tenold + 1)/10,1)),
		} 
		ctr.ctr_Tenold_item.Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_summary_number_7b.dds", Vector4(0, 0, 0, 0),Vector4((Tenold)/10,0,(Tenold + 1)/10,1)),
		} 
	else
		ctr.ctr_Anold_bg.Visible = false
		ctr.ctr_Anold_item.Visible = false
		ctr.ctr_Tenold_bg.Visible = false
		ctr.ctr_Tenold_item.Visible = false
	end
	ctr.ctr_local.Parent = m_parent
end

function CreateInfoControl_Totip(m_parent,info,num)
	local ctr = nil
	ctr = Gui.Create()
	{
		Gui.Control "ctr_local"
		{	
			Size = Vector2(196, 41),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Location = Vector2(0, 0),
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/Shooting/lb_range_charts_2.dds", Vector4(0, 0, 0, 0)),
			},
			
			Gui.Label "lb_list_num"
			{
				Size = Vector2(20, 20),
				Location = Vector2(10, 0),
				TextColor = ARGB(255, 255, 252, 0),
				FontSize = 12,
				TextAlign = "kAlignCenterMiddle",
				Text = num,
				BackgroundColor = ARGB(0,255,255,255),
				--TextPadding = Vector4(0,0,0,0),
			},
						
			Gui.Control "ctr_Tenold_bg"
			{	
				Size = Vector2(10, 20),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Location = Vector2(34, 0),
			},
			
			Gui.Control "ctr_Tenold_item"
			{	
				Size = Vector2(10, 20),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Location = Vector2(34, 0),
			},
			
			Gui.Control "ctr_Anold_bg"
			{	
				Size = Vector2(10, 20),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Location = Vector2(43, 0),
			},
			
			Gui.Control "ctr_Anold_item"
			{	
				Size = Vector2(10, 20),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Location = Vector2(43, 0),
			},
			
			Gui.Label "lb_name"
			{
				Size = Vector2(140, 20),
				Location = Vector2(55, 0),
				TextColor = ARGB(255, 216, 216, 216),
				FontSize = 12,
				TextAlign = "kAlignCenterMiddle",
				Text = "",
				BackgroundColor = ARGB(0,255,255,255),
				--TextPadding = Vector4(0,0,0,0),
			},
			
			Gui.Label "lb_prize_equip_bg"
			{
				Size = Vector2(50, 20),
				Dock = "kDockLeftBottom",
				TextColor = ARGB(255, 255, 252, 0),
				FontSize = 12,
				TextAlign = "kAlignLeftMiddle",
				Text = "",
				BackgroundColor = ARGB(0,255,255,255),
				--TextPadding = Vector4(0,0,0,0),
				
				Gui.ItemBoxBtn "Ibt_Toptips"
				{
					Style = "Gui.ItemBoxBtn_ib",
					Size = Vector2(50,20),
					Location = Vector2(45, 0),
					--BtnLocation = Vector2(45, 72),
					--BtnText = lang:GetText("购买"),
					--Enable = false,
					BackgroundColor = ARGB(0,255,255,255),
					Skin = Gui.ItemBoxBtnSkin
					{
						--NeutralNormalImage = Gui.Image("LobbyUI/ShoppingMall/vip_chest/lb_vipgifts_slot_01_normal.dds", Vector4(0, 0, 0, 0)),
						--NeutralHoverImage = Gui.Image("LobbyUI/ShoppingMall/vip_chest/lb_vipgifts_slot_flash.dds", Vector4(0, 0, 0, 0)),
						--NeutralSelectedImage = Gui.Image("LobbyUI/ShoppingMall/vip_chest/lb_vipgifts_slot_01_normal.dds", Vector4(0, 0, 0, 0)),
						--NeutralDisabledImage = Gui.Image("LobbyUI/ShoppingMall/vip_chest/lb_vipgifts_slot_01_disabled.dds", Vector4(0, 0, 0, 0)),
					},
					
					--ItemIcon = Gui.Icon("LobbyUI/ibt_icon/machet_4.tga"),
					--Padding = Vector4(10,0,10,0),
					
					--ItemIconPastDue = Gui.Icon("LobbyUI/ShoppingMall/vip_chest/lb_vipgifts_slot_flash.dds"),
					
					Gui.Label "lb_prize_equip"
					{
						Size = Vector2(50, 20),
						Location = Vector2(0, 0),
						TextColor = ARGB(255, 00, 210, 253),
						FontSize = 12,
						TextAlign = "kAlignLeftMiddle",
						Text = "",
						BackgroundColor = ARGB(0,255,255,255),
						--TextPadding = Vector4(0,0,0,0),
					},
				},
				
				Gui.Label "lb_prize_equip_end"
				{
					Size = Vector2(10, 20),
					Location = Vector2(50, 0),
					TextColor = ARGB(255, 255, 252, 0),
					FontSize = 12,
					TextAlign = "kAlignLeftMiddle",
					Text = "",
					BackgroundColor = ARGB(0,255,255,255),
					--TextPadding = Vector4(0,0,0,0),
				},
			},
		},
	}
	if info then
		ctr.lb_name.Text = info[1]
		ctr.lb_prize_equip_bg.Text = lang:GetText("获得:")
		ctr.lb_prize_equip.Text = info[3].display
		local string_num = string.len(info[3].display)
		ctr.lb_prize_equip.Size = Vector2(string_num*6.875 + 3, 20)
		ctr.Ibt_Toptips.Size = ctr.lb_prize_equip.Size
		ctr.Ibt_Toptips.Location = Vector2(string.len(ctr.lb_prize_equip_bg.Text)*6 + 2, 0)
		ctr.lb_prize_equip_end.Location = Vector2(ctr.Ibt_Toptips.Location.x + 2 + string_num*6, 0)
		if (info[3].item_num and info[3].common.type == 5) or (info[3].item_num and info[3].common.type == 4 and info[3].common.subtype == 7) then
			ctr.lb_prize_equip_end.Text = "×"..info[3].item_num
			ctr.lb_prize_equip_end.Size = Vector2(string.len(ctr.lb_prize_equip_end.Text)*6 + 3,20)
			ctr.lb_prize_equip_bg.Size = Vector2((string_num + string.len(ctr.lb_prize_equip_end.Text))*6 + 45 + 3 + 4, 20)
		else
			ctr.lb_prize_equip_bg.Size = Vector2(string_num*6 + 45 + 10 + 4, 20)
		end
		ctr.Ibt_Toptips.EventMouseEnter = function(sender, e)
			L_ToolTips.FillToolTipsVIPPresent_item(Shooting_Win_ui.Shooting_Win_root, info[3])
		end
		ctr.Ibt_Toptips.EventToolTipsShow = function(sender, e)
			local loc = sender.Location + sender.Parent.Location + sender.Parent.Parent.Location + sender.Parent.Parent.Parent.Location
						+ sender.Parent.Parent.Parent.Parent.Location + sender.Parent.Parent.Parent.Parent.Parent.Location + sender.Parent.Parent.Parent.Parent.Parent.Parent.Location
						+ sender.Parent.Parent.Parent.Parent.Parent.Parent.Parent.Location + sender.Parent.Parent.Parent.Parent.Parent.Parent.Parent.Parent.Location - Vector2(0,Shooting_Win_ui.scroll.VscrollBarValue)
			L_ToolTips.ShowToolTipsShowWindow(sender,Vector2(1200, 900),loc)
		end
		ctr.Ibt_Toptips.EventMouseLeave = function(sender, e)
			L_ToolTips.HideToolTipsWindow()
		end
	else
		ctr.lb_list_num.Text = ""
	end
	if info then
		local Tenold = math.floor(info[2]/10)
		local Anold = info[2] - 10*Tenold
		ctr.ctr_Anold_bg.Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_summary_number_6b.dds", Vector4(0, 0, 0, 0),Vector4((Anold)/10,0,(Anold + 1)/10,1)),
		} 
		ctr.ctr_Anold_item.Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_summary_number_7b.dds", Vector4(0, 0, 0, 0),Vector4((Anold)/10,0,(Anold + 1)/10,1)),
		} 
		ctr.ctr_Tenold_bg.Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_summary_number_6b.dds", Vector4(0, 0, 0, 0),Vector4((Tenold)/10,0,(Tenold + 1)/10,1)),
		} 
		ctr.ctr_Tenold_item.Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_summary_number_7b.dds", Vector4(0, 0, 0, 0),Vector4((Tenold)/10,0,(Tenold + 1)/10,1)),
		} 
	else
		ctr.ctr_Anold_bg.Visible = false
		ctr.ctr_Anold_item.Visible = false
		ctr.ctr_Tenold_bg.Visible = false
		ctr.ctr_Tenold_item.Visible = false
	end
	ctr.ctr_local.Parent = m_parent
end

--打靶奖品界面
local Shooting_prize_Win = 
{
	Gui.Control "Shooting_prize_root"
	{	
		Size = Vector2(1200, 900),
		BackgroundColor = ARGB(0, 255, 255, 255),
		Location = Vector2(0, 0),
		
		Gui.Control
		{	
			Size = Vector2(361, 331),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Dock = "kDockCenter",
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/main_bar01.dds", Vector4(20, 20, 20, 20)),
			},

			Gui.Control
			{	
				Size = Vector2(339, 308),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Location = Vector2(11, 12),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/main_bar02.dds", Vector4(8, 8, 8, 8)),
				},
				
				Gui.Control
				{	
					Size = Vector2(339, 46),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Location = Vector2(0, 0),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/Shooting/lb_range_title_07.dds", Vector4(0, 0, 0, 0)),
					},
				},
					
				Gui.Control
				{	
					Size = Vector2(326, 179),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Location = Vector2(6, 50),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/Shooting/lb_range_tankuang.dds", Vector4(7, 7, 7, 7)),
					},
					
					Gui.Label "item_name"
					{
						Size = Vector2(267,20),
						Location = Vector2(30,20),
						TextColor = ARGB(255, 236, 206, 72),
						FontSize = 16,
						TextAlign = "kAlignCenterMiddle",
						BackgroundColor = ARGB(0,255,255,255),
					},
					
					Gui.ItemBoxBtn "IBTN_Shooting_prize"
					{
						Style = "Gui.ItemBoxBtn_ib",
						Size = Vector2(167,77),
						Location = Vector2(80,47),
						--BtnLocation = Vector2(45, 72),
						--BtnText = lang:GetText("购买"),
						--Enable = false,
						BackgroundColor = ARGB(255,255,255,255),
						Skin = Gui.ItemBoxBtnSkin
						{
							NeutralNormalImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_02.dds", Vector4(0, 0, 0, 0)),
							--NeutralHoverImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_02.dds", Vector4(0, 0, 0, 0)),
							NeutralSelectedImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_02.dds", Vector4(0, 0, 0, 0)),
							NeutralDisabledImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_02.dds", Vector4(0, 0, 0, 0)),
						},
						
						--ItemIcon = Gui.Icon("LobbyUI/ibt_icon/machet_4.tga"),
						--Padding = Vector4(10,0,10,0),
						
						--ItemIconPastDue = Gui.Icon("LobbyUI/ShoppingMall/vip_chest/lb_vipgifts_slot_flash.dds"),						
					},
					
					--Gui.Label
					--{
					--	Size = Vector2(167,20),
					--	Location = Vector2(80,130),
					--	TextColor = ARGB(255, 236, 206, 72),
					--	FontSize = 14,
					--	Text = lang:GetText("已放入仓库"),
					--	TextAlign = "kAlignCenterMiddle",
					--	BackgroundColor = ARGB(0,255,255,255),
					--},
				},
			},
			
			--确定
			Gui.Button "btn_close"
			{
				Size = Vector2(180,38),
				Location = Vector2(91, 260),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Text = lang:GetText("确 定"),
				TextColor = ARGB(255, 229, 255, 252),
				TextAlign = "kAlignCenterMiddle",
				HighlightTextColor = ARGB(255, 229, 255, 252),
				Padding = Vector4(0, 0, 0, 5),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_onlinetime_button_2_normal.dds", Vector4(20, 0, 20, 0)),
					HoverImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_onlinetime_button_2_hover.dds", Vector4(20, 0, 20, 0)),
					DownImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_onlinetime_button_2_down.dds", Vector4(20, 0, 20, 0)),
					DisabledImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_onlinetime_button_2_disabled.dds", Vector4(20, 0, 20, 0)),
				},
			},
		},
	},
}

function ShowShootingprizeWin(data,num)
	if Shooting_prize_Win_ui == nil then
		Shooting_prize_Win_ui = Gui.Create()(Shooting_prize_Win)
		--打靶奖品界面初始化
		Shootingprize_Window = ModalWindow.GetNew("Shooting_prize_Win_ui")
		Shootingprize_Window.screen.AllowEscToExit = false
		Shootingprize_Window.screen.Visible = false
		--Shootingprize_Window.screen.EventEscPressed = HideCharmBottleWin
		Shootingprize_Window.screen.EventEscPressed = nil
		Shootingprize_Window.root.Size = Vector2(1200, 900)
		Shooting_prize_Win_ui.Shooting_prize_root.Parent = Shootingprize_Window.root
	end
	Shooting_prize_Win_ui.btn_close.EventClick = function()
													HideShootingprizeWin()
													ShowAllBackPrizeShootingEnd(data.list,num,ReSetLooklist)
												end
	if data then
		Shooting_prize_Win_ui.IBTN_Shooting_prize.EventMouseEnter = function(sender, e)
			L_ToolTips.FillToolTipsVIPPresent(num, Shooting_prize_Win_ui.Shooting_prize_root, data.list)
		end
		Shooting_prize_Win_ui.IBTN_Shooting_prize.EventToolTipsShow = function(sender, e)
			local loc = sender.Location + sender.Parent.Location + sender.Parent.Parent.Location + sender.Parent.Parent.Parent.Location + sender.Parent.Parent.Parent.Parent.Location
			L_ToolTips.ShowToolTipsShowWindow(sender,Vector2(1200, 900),loc)
		end
		Shooting_prize_Win_ui.IBTN_Shooting_prize.EventMouseLeave = function(sender, e)
			L_ToolTips.HideToolTipsWindow()
		end
		AddNumCtr(Shooting_prize_Win_ui.IBTN_Shooting_prize,data.list[num],167,77,true)
		Shooting_prize_Win_ui.item_name.Text = data.list[num].display
	end
	if Shootingprize_Window and Shootingprize_Window.screen then
		Shootingprize_Window.screen.Visible = true
		--gui.EventEscPressed = HideCharmBottleWin
		gui.EventEscPressed = nil
	end
	gui:PlayAudio("kUIA_GETITEM")
end

function HideShootingprizeWin()
	if Shootingprize_Window and Shootingprize_Window.screen then
		Shootingprize_Window.screen.Visible = false
		Shootingprize_Window:Close()
		Shooting_prize_Win_ui = nil
	end
end

--打靶连射奖励界面
local Shooting_Dartleprize_Win =
{
	Gui.Control "Shooting_Dartleprize_root"
	{	
		Size = Vector2(1200, 900),
		BackgroundColor = ARGB(0, 255, 255, 255),
		Location = Vector2(0, 0),
		
		Gui.Control
		{	
			Size = Vector2(361, 331),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Dock = "kDockCenter",
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/main_bar01.dds", Vector4(20, 20, 20, 20)),
			},

			Gui.Control
			{	
				Size = Vector2(339, 308),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Location = Vector2(11, 12),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/main_bar02.dds", Vector4(8, 8, 8, 8)),
				},
				
				Gui.Control
				{	
					Size = Vector2(339, 46),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Location = Vector2(0, 0),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/Shooting/lb_range_title_08.dds", Vector4(0, 0, 0, 0)),
					},
				},
					
				Gui.Control
				{	
					Size = Vector2(326, 179),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Location = Vector2(6, 50),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/Shooting/lb_range_tankuang_01.dds", Vector4(7, 7, 7, 7)),
					},
					
					Gui.Label "item_name"
					{
						Size = Vector2(267,20),
						Location = Vector2(30,20),
						TextColor = ARGB(255, 236, 206, 72),
						FontSize = 16,
						TextAlign = "kAlignCenterMiddle",
						BackgroundColor = ARGB(0,255,255,255),
					},
					
					Gui.ItemBoxBtn "IBTN_Shooting_prize"
					{
						Style = "Gui.ItemBoxBtn_ib",
						Size = Vector2(167,77),
						Location = Vector2(80,47),
						--BtnLocation = Vector2(45, 72),
						--BtnText = lang:GetText("购买"),
						--Enable = false,
						BackgroundColor = ARGB(255,255,255,255),
						Skin = Gui.ItemBoxBtnSkin
						{
							NeutralNormalImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_02.dds", Vector4(0, 0, 0, 0)),
							--NeutralHoverImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_02.dds", Vector4(0, 0, 0, 0)),
							NeutralSelectedImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_02.dds", Vector4(0, 0, 0, 0)),
							NeutralDisabledImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_fastsettlement_bg_02.dds", Vector4(0, 0, 0, 0)),
						},
						
						--ItemIcon = Gui.Icon("LobbyUI/ibt_icon/machet_4.tga"),
						--Padding = Vector4(10,0,10,0),
						
						--ItemIconPastDue = Gui.Icon("LobbyUI/ShoppingMall/vip_chest/lb_vipgifts_slot_flash.dds"),						
					},
					
					Gui.Label "lab_Dartle_nums"
					{
						Size = Vector2(267,20),
						Location = Vector2(30,130),
						TextColor = ARGB(255, 236, 206, 72),
						FontSize = 14,
						TextAlign = "kAlignCenterMiddle",
						BackgroundColor = ARGB(0,255,255,255),
					},
				},
			},
			
			--确定
			Gui.Button "btn_close"
			{
				Size = Vector2(180,38),
				Location = Vector2(95, 260),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Text = lang:GetText("确 定"),
				TextColor = ARGB(255, 229, 255, 252),
				TextAlign = "kAlignCenterMiddle",
				HighlightTextColor = ARGB(255, 229, 255, 252),
				Padding = Vector4(0, 0, 0, 5),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_onlinetime_button_2_normal.dds", Vector4(20, 0, 20, 0)),
					HoverImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_onlinetime_button_2_hover.dds", Vector4(20, 0, 20, 0)),
					DownImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_onlinetime_button_2_down.dds", Vector4(20, 0, 20, 0)),
					DisabledImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/lb_onlinetime_button_2_disabled.dds", Vector4(20, 0, 20, 0)),
				},
			},
		},
	},
}

function ShowShootingDartleprizeWin()
	if Shooting_Dartleprize_Win_ui == nil then
		Shooting_Dartleprize_Win_ui = Gui.Create()(Shooting_Dartleprize_Win)
		--打靶连射奖励界面初始化
		Shooting_Dartleprize_Window = ModalWindow.GetNew("Shooting_Dartleprize_Win_ui")
		Shooting_Dartleprize_Window.screen.AllowEscToExit = false
		Shooting_Dartleprize_Window.screen.Visible = false
		--Shooting_Dartleprize_Window.screen.EventEscPressed = HideCharmBottleWin
		Shooting_Dartleprize_Window.screen.EventEscPressed = nil
		Shooting_Dartleprize_Window.root.Size = Vector2(1200, 900)
		Shooting_Dartleprize_Win_ui.Shooting_Dartleprize_root.Parent = Shooting_Dartleprize_Window.root
	end
	Shooting_Dartleprize_Win_ui.btn_close.EventClick = function()
													HideShootingDartleprizeWin()
													dartelPrize_confirm = true
													UpDataShootingDartlePrizeInfo()
												end
	if Shooting_Prize then
		Shooting_Dartleprize_Win_ui.IBTN_Shooting_prize.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..Shooting_Prize.name..".tga")
		Shooting_Dartleprize_Win_ui.IBTN_Shooting_prize.EventMouseEnter = function(sender, e)
			L_ToolTips.FillToolTipsVIPPresent_item(Shooting_Dartleprize_Win_ui.Shooting_Dartleprize_root, Shooting_Prize)
		end
		Shooting_Dartleprize_Win_ui.IBTN_Shooting_prize.EventToolTipsShow = function(sender, e)
			local loc = sender.Location + sender.Parent.Location + sender.Parent.Parent.Location + sender.Parent.Parent.Parent.Location + sender.Parent.Parent.Parent.Parent.Location
			L_ToolTips.ShowToolTipsShowWindow(sender,Vector2(1200, 900),loc)
		end
		Shooting_Dartleprize_Win_ui.IBTN_Shooting_prize.EventMouseLeave = function(sender, e)
			L_ToolTips.HideToolTipsWindow()
		end
		Shooting_Dartleprize_Win_ui.IBTN_Shooting_prize:OnDestroy()
		if Shooting_Prize.unit and Shooting_Prize.common.type == 5 then
			L_Characters.CreatPresentNumCtr(Shooting_Dartleprize_Win_ui.IBTN_Shooting_prize,Shooting_Prize.unit,167,77)
		elseif Shooting_Prize.unit and Shooting_Prize.common.type == 4 and Shooting_Prize.common.subtype == 7 then
			L_Characters.CreatPresentNumCtr(Shooting_Dartleprize_Win_ui.IBTN_Shooting_prize,Shooting_Prize.unit,167,77)
		end
		Shooting_Dartleprize_Win_ui.item_name.Text = Shooting_Prize.display
	end
	Shooting_Dartleprize_Win_ui.lab_Dartle_nums.Text = lang:GetText("连射").." "..Shooting_Total_num.." "..lang:GetText("次奖励")
	if Shooting_Dartleprize_Window and Shooting_Dartleprize_Window.screen then
		Shooting_Dartleprize_Window.screen.Visible = true
		--gui.EventEscPressed = HideCharmBottleWin
		gui.EventEscPressed = nil
	end
end

function HideShootingDartleprizeWin()
	if Shooting_Dartleprize_Window and Shooting_Dartleprize_Window.screen then
		Shooting_Dartleprize_Window.screen.Visible = false
		Shooting_Dartleprize_Window:Close()
		Shooting_Dartleprize_Win_ui = nil
	end
end

function Initialize()
	print("=================L_Shooting Initialize()")
end

function Finalize()
	print("=================L_Shooting Finalize()")
end

function Show(data)
	print("=================L_Shooting Show()")
	--L_LobbyMain.HideAll()
	ShowShootingWin(data)
	ptr_cast(game.CurrentState):OnChange_Lobby_Music(0)
end

function Hide()
	print("=================L_Shooting Hide()")
	HideShootingWin()
end
