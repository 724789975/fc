module("L_FightTeamFAQ", package.seeall)

local index = 1
local maxindex = 4
team_FAQ_ui = Gui.Create()
{
	Gui.Control "root"
	{
		Size = Vector2(1200, 900),
		Location = Vector2(0, 0),
		BackgroundColor = ARGB(0, 255, 255, 255),
		Gui.Button "b_1"
		{
			Size = Vector2(195,56),
			Location = Vector2(168, 75),
			Text = lang:GetText("介绍"),
			HighlightTextColor = ARGB(255,255,255,255),
			TextColor = ARGB(255,0,0,0),
			FontSize = 14,
			PushDown = true,
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_normal.dds", Vector4(46, 0, 46, 0)),
				HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_hover.dds", Vector4(46, 0, 46, 0)),
				DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_down.dds", Vector4(46, 0, 46, 0)),
				DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_normal.dds", Vector4(46, 0, 46, 0)),
			},
			EventClick = function()
				team_FAQ_ui.FAQ_1.Visible = true
				team_FAQ_ui.FAQ_2.Visible = false
				team_FAQ_ui.FAQ_3.Visible = false
				team_FAQ_ui.FAQ_4.Visible = false
				team_FAQ_ui.b_1.PushDown = true
				team_FAQ_ui.b_2.PushDown = false
				team_FAQ_ui.b_3.PushDown = false
				team_FAQ_ui.b_4.PushDown = false
				index = 1
			end,
		},
		Gui.Button "b_2"
		{
			Size = Vector2(195,56),
			Location = Vector2(365, 75),
			Text = lang:GetText("首页"),
			HighlightTextColor = ARGB(255,255,255,255),
			TextColor = ARGB(255,0,0,0),
			FontSize = 14,
			PushDown = false,
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_normal.dds", Vector4(46, 0, 46, 0)),
				HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_hover.dds", Vector4(46, 0, 46, 0)),
				DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_down.dds", Vector4(46, 0, 46, 0)),
				DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_normal.dds", Vector4(46, 0, 46, 0)),
			},
			EventClick = function()
				team_FAQ_ui.FAQ_1.Visible = false
				team_FAQ_ui.FAQ_2.Visible = true
				team_FAQ_ui.FAQ_3.Visible = false
				team_FAQ_ui.FAQ_4.Visible = false
				team_FAQ_ui.b_1.PushDown = false
				team_FAQ_ui.b_2.PushDown = true
				team_FAQ_ui.b_3.PushDown = false
				team_FAQ_ui.b_4.PushDown = false
				index = 2
			end,
		},
		Gui.Button "b_3"
		{
			Size = Vector2(195,56),
			Location = Vector2(560, 75),
			Text = lang:GetText("战队空间建设"),
			TextAlign = "kAlignCenterMiddle",
			FontSize = 14,
			HighlightTextColor = ARGB(255,255,255,255),
			TextColor = ARGB(255,0,0,0),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_normal.dds", Vector4(46, 0, 46, 0)),
				HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_hover.dds", Vector4(46, 0, 46, 0)),
				DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_down.dds", Vector4(46, 0, 46, 0)),
				DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_normal.dds", Vector4(46, 0, 46, 0)),
			},
			EventClick = function()
				team_FAQ_ui.FAQ_1.Visible = false
				team_FAQ_ui.FAQ_2.Visible = false
				team_FAQ_ui.FAQ_3.Visible = true
				team_FAQ_ui.FAQ_4.Visible = false
				team_FAQ_ui.b_1.PushDown = false
				team_FAQ_ui.b_2.PushDown = false
				team_FAQ_ui.b_3.PushDown = true
				team_FAQ_ui.b_4.PushDown = false
				index = 3
			end,
		},
		Gui.Button "b_4"
		{
			Size = Vector2(195,56),
			Location = Vector2(755, 75),
			Text = lang:GetText("个人装备建设"),
			TextAlign = "kAlignCenterMiddle",
			FontSize = 14,
			HighlightTextColor = ARGB(255,255,255,255),
			TextColor = ARGB(255,0,0,0),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_normal.dds", Vector4(46, 0, 46, 0)),
				HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_hover.dds", Vector4(46, 0, 46, 0)),
				DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_down.dds", Vector4(46, 0, 46, 0)),
				DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_normal.dds", Vector4(46, 0, 46, 0)),
			},
			EventClick = function()
				team_FAQ_ui.FAQ_1.Visible = false
				team_FAQ_ui.FAQ_2.Visible = false
				team_FAQ_ui.FAQ_3.Visible = false
				team_FAQ_ui.FAQ_4.Visible = true
				team_FAQ_ui.b_1.PushDown = false
				team_FAQ_ui.b_2.PushDown = false
				team_FAQ_ui.b_3.PushDown = false
				team_FAQ_ui.b_4.PushDown = true
				index = 4
			end,
		},
		Gui.Control
		{
			Size = Vector2(883, 627),
			Location = Vector2(153, 122),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/Team/FAQ/lb_squad_yindao_bg.dds", Vector4(0, 0, 0, 0)),
			},
			Gui.Label 
			{
				Size = Vector2(500, 20),
				Location = Vector2(73, 30),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Text = lang:GetText("提示：点击框选部分详细查看"),
				FontSize = 16,
				TextColor = ARGB(255, 255, 0, 0),
				TextAlign = "kAlignLeftTop",
			},
			Gui.Control "FAQ_1"
			{
				Size = Vector2(782, 552),
				Location = Vector2(69, 50),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Visible = true,
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Team/FAQ/lb_squad_moshijiangjie.dds", Vector4(0, 0, 0, 0)),
				},
			},
			Gui.Control "FAQ_2"
			{
				Size = Vector2(782, 552),
				Location = Vector2(69, 50),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Visible = false,
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Team/FAQ/lb_squad_yindao_bg01.dds", Vector4(0, 0, 0, 0)),
				},
				Gui.Button
				{
					Size = Vector2(57,54),
					Location = Vector2(386, 59),
					BackgroundColor = ARGB(0, 255, 255, 255),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = nil,
						HoverImage = nil,
						DownImage = nil,
						DisabledImage = nil,
						TwinkleImage = Gui.Image("LobbyUI/Team/FAQ/lb_squad_yindao_hover.dds", Vector4(8, 8, 8, 8)),
					},
					EventClick = function()
						Show_FAQInside("lb_squad_yindao_bg05")
					end,
					EventMouseEnter = function(Sender , e)
						Sender.AlwaysBlink = true
						Sender.blink = true
					end,
					EventMouseLeave = function(Sender , e)
						Sender.AlwaysBlink = false
						Sender.blink = false
					end,
				},
				Gui.Button
				{
					Size = Vector2(110,54),
					Location = Vector2(546, 168),
					BackgroundColor = ARGB(0, 255, 255, 255),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = nil,
						HoverImage = nil,
						DownImage = nil,
						DisabledImage = nil,
						TwinkleImage = Gui.Image("LobbyUI/Team/FAQ/lb_squad_yindao_hover.dds", Vector4(8, 8, 8, 8)),
					},
					EventClick = function()
						Show_FAQInside("lb_squad_yindao_bg04")
					end,
					EventMouseEnter = function(Sender , e)
						Sender.AlwaysBlink = true
						Sender.blink = true
					end,
					EventMouseLeave = function(Sender , e)
						Sender.AlwaysBlink = false
						Sender.blink = false
					end,
				},
				Gui.Button
				{
					Size = Vector2(117,54),
					Location = Vector2(358, 277),
					BackgroundColor = ARGB(0, 255, 255, 255),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = nil,
						HoverImage = nil,
						DownImage = nil,
						DisabledImage = nil,
						TwinkleImage = Gui.Image("LobbyUI/Team/FAQ/lb_squad_yindao_hover.dds", Vector4(8, 8, 8, 8)),
					},
					EventClick = function()
						Show_FAQInside("lb_squad_yindao_bg07")
					end,
					EventMouseEnter = function(Sender , e)
						Sender.AlwaysBlink = true
						Sender.blink = true
					end,
					EventMouseLeave = function(Sender , e)
						Sender.AlwaysBlink = false
						Sender.blink = false
					end,					
				},
				Gui.Button
				{
					Size = Vector2(117,54),
					Location = Vector2(84, 344),
					BackgroundColor = ARGB(0, 255, 255, 255),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = nil,
						HoverImage = nil,
						DownImage = nil,
						DisabledImage = nil,
						TwinkleImage = Gui.Image("LobbyUI/Team/FAQ/lb_squad_yindao_hover.dds", Vector4(8, 8, 8, 8)),
					},
					EventClick = function()
						Show_FAQInside("lb_squad_yindao_bg14")
					end,
					EventMouseEnter = function(Sender , e)
						Sender.AlwaysBlink = true
						Sender.blink = true
					end,
					EventMouseLeave = function(Sender , e)
						Sender.AlwaysBlink = false
						Sender.blink = false
					end,					
				},
				Gui.Button
				{
					Size = Vector2(125,54),
					Location = Vector2(31, 483),
					BackgroundColor = ARGB(0, 255, 255, 255),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = nil,
						HoverImage = nil,
						DownImage = nil,
						DisabledImage = nil,
						TwinkleImage = Gui.Image("LobbyUI/Team/FAQ/lb_squad_yindao_hover.dds", Vector4(8, 8, 8, 8)),
					},
					EventClick = function()
						Show_FAQInside("lb_squad_yindao_bg06")
					end,
					EventMouseEnter = function(Sender , e)
						Sender.AlwaysBlink = true
						Sender.blink = true
					end,
					EventMouseLeave = function(Sender , e)
						Sender.AlwaysBlink = false
						Sender.blink = false
					end,					
				},
				Gui.Button
				{
					Size = Vector2(125,54),
					Location = Vector2(630, 483),
					BackgroundColor = ARGB(0, 255, 255, 255),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = nil,
						HoverImage = nil,
						DownImage = nil,
						DisabledImage = nil,
						TwinkleImage = Gui.Image("LobbyUI/Team/FAQ/lb_squad_yindao_hover.dds", Vector4(8, 8, 8, 8)),
					},
					EventClick = function()
						Show_FAQInside("lb_squad_yindao_bg08")
					end,
					EventMouseEnter = function(Sender , e)
						Sender.AlwaysBlink = true
						Sender.blink = true
					end,
					EventMouseLeave = function(Sender , e)
						Sender.AlwaysBlink = false
						Sender.blink = false
					end,					
				},
			},
			Gui.Control "FAQ_3"
			{
				Size = Vector2(782, 552),
				Location = Vector2(69, 50),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Visible = false,
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Team/FAQ/lb_squad_yindao_bg02.dds", Vector4(0, 0, 0, 0)),
				},
				Gui.Button
				{
					Size = Vector2(98,28),
					Location = Vector2(498, 26),
					BackgroundColor = ARGB(0, 255, 255, 255),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = nil,
						HoverImage = nil,
						DownImage = nil,
						DisabledImage = nil,
						TwinkleImage = Gui.Image("LobbyUI/Team/FAQ/lb_squad_yindao_hover.dds", Vector4(8, 8, 8, 8)),
					},
					EventClick = function()
						Show_FAQInside("lb_squad_yindao_bg15")
					end,
					EventMouseEnter = function(Sender , e)
						Sender.AlwaysBlink = true
						Sender.blink = true
					end,
					EventMouseLeave = function(Sender , e)
						Sender.AlwaysBlink = false
						Sender.blink = false
					end,					
				},
				Gui.Button
				{
					Size = Vector2(136,41),
					Location = Vector2(547, 217),
					BackgroundColor = ARGB(0, 255, 255, 255),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = nil,
						HoverImage = nil,
						DownImage = nil,
						DisabledImage = nil,
						TwinkleImage = Gui.Image("LobbyUI/Team/FAQ/lb_squad_yindao_hover.dds", Vector4(8, 8, 8, 8)),
					},
					EventClick = function()
						Show_FAQInside("lb_squad_yindao_bg11")
					end,
					EventMouseEnter = function(Sender , e)
						Sender.AlwaysBlink = true
						Sender.blink = true
					end,
					EventMouseLeave = function(Sender , e)
						Sender.AlwaysBlink = false
						Sender.blink = false
					end,					
				},
				Gui.Button
				{
					Size = Vector2(239,218),
					Location = Vector2(340, 276),
					BackgroundColor = ARGB(0, 255, 255, 255),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = nil,
						HoverImage = nil,
						DownImage = nil,
						DisabledImage = nil,
						TwinkleImage = Gui.Image("LobbyUI/Team/FAQ/lb_squad_yindao_hover.dds", Vector4(8, 8, 8, 8)),
					},
					EventClick = function()
						Show_FAQInside("lb_squad_yindao_bg10")
					end,
					EventMouseEnter = function(Sender , e)
						Sender.AlwaysBlink = true
						Sender.blink = true
					end,
					EventMouseLeave = function(Sender , e)
						Sender.AlwaysBlink = false
						Sender.blink = false
					end,					
				},
				Gui.Button
				{
					Size = Vector2(104,54),
					Location = Vector2(603, 465),
					BackgroundColor = ARGB(0, 255, 255, 255),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = nil,
						HoverImage = nil,
						DownImage = nil,
						DisabledImage = nil,
						TwinkleImage = Gui.Image("LobbyUI/Team/FAQ/lb_squad_yindao_hover.dds", Vector4(8, 8, 8, 8)),
					},
					EventClick = function()
						Show_FAQInside("lb_squad_yindao_bg09")
					end,
					EventMouseEnter = function(Sender , e)
						Sender.AlwaysBlink = true
						Sender.blink = true
					end,
					EventMouseLeave = function(Sender , e)
						Sender.AlwaysBlink = false
						Sender.blink = false
					end,					
				},
			},
			Gui.Control "FAQ_4"
			{
				Size = Vector2(782, 552),
				Location = Vector2(69, 50),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Visible = false,
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Team/FAQ/lb_squad_yindao_bg03.dds", Vector4(0, 0, 0, 0)),
				},
				Gui.Button
				{
					Size = Vector2(76,35),
					Location = Vector2(251, 292),
					BackgroundColor = ARGB(0, 255, 255, 255),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = nil,
						HoverImage = nil,
						DownImage = nil,
						DisabledImage = nil,
						TwinkleImage = Gui.Image("LobbyUI/Team/FAQ/lb_squad_yindao_hover.dds", Vector4(8, 8, 8, 8)),
					},
					EventClick = function()
						Show_FAQInside("lb_squad_yindao_bg13")
					end,
					EventMouseEnter = function(Sender , e)
						Sender.AlwaysBlink = true
						Sender.blink = true
					end,
					EventMouseLeave = function(Sender , e)
						Sender.AlwaysBlink = false
						Sender.blink = false
					end,					
				},
				Gui.Button
				{
					Size = Vector2(418,266),
					Location = Vector2(337, 259),
					BackgroundColor = ARGB(0, 255, 255, 255),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = nil,
						HoverImage = nil,
						DownImage = nil,
						DisabledImage = nil,
						TwinkleImage = Gui.Image("LobbyUI/Team/FAQ/lb_squad_yindao_hover.dds", Vector4(8, 8, 8, 8)),
					},
					EventClick = function()
						Show_FAQInside("lb_squad_yindao_bg12")
					end,
					EventMouseEnter = function(Sender , e)
						Sender.AlwaysBlink = true
						Sender.blink = true
					end,
					EventMouseLeave = function(Sender , e)
						Sender.AlwaysBlink = false
						Sender.blink = false
					end,					
				},
			},
		},
		Gui.Button "left"
		{
			Size = Vector2(64, 116),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Location = Vector2(85, 338),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/VersionChange/lb_introduction_button01_normal.dds", Vector4(0, 0, 0, 0),Vector4(1, 0, 0, 1)),
				HoverImage = Gui.Image("LobbyUI/VersionChange/lb_introduction_button01_hover.dds", Vector4(0, 0, 0, 0),Vector4(1, 0, 0, 1)),
				DownImage = Gui.Image("LobbyUI/VersionChange/lb_introduction_button01_down.dds", Vector4(0, 0, 0, 0),Vector4(1, 0, 0, 1)),
				DisabledImage = Gui.Image("LobbyUI/VersionChange/lb_introduction_button01_disabled.dds", Vector4(0, 0, 0, 0),Vector4(1, 0, 0, 1)),							
			},
			EventClick = function()
				if index > 1 then
					index = index - 1
				end
				for i = 1 , 4 do
					if i == index then
						team_FAQ_ui["FAQ_"..i].Visible = true
						team_FAQ_ui["b_"..i].PushDown = true
					else
						team_FAQ_ui["FAQ_"..i].Visible = false
						team_FAQ_ui["b_"..i].PushDown = false
					end
				end
			end,
		},
		
		Gui.Button "right"
		{
			Size = Vector2(64, 116),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Location = Vector2(1042, 338),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/VersionChange/lb_introduction_button01_normal.dds", Vector4(0, 0, 0, 0)),
				HoverImage = Gui.Image("LobbyUI/VersionChange/lb_introduction_button01_hover.dds", Vector4(0, 0, 0, 0)),
				DownImage = Gui.Image("LobbyUI/VersionChange/lb_introduction_button01_down.dds", Vector4(0, 0, 0, 0)),
				DisabledImage = Gui.Image("LobbyUI/VersionChange/lb_introduction_button01_disabled.dds", Vector4(0, 0, 0, 0)),							
			},
			EventClick = function()
				if index < maxindex then
					index = index + 1
				end
				for i = 1 , 4 do
					if i == index then
						team_FAQ_ui["FAQ_"..i].Visible = true
						team_FAQ_ui["b_"..i].PushDown = true
					else
						team_FAQ_ui["FAQ_"..i].Visible = false
						team_FAQ_ui["b_"..i].PushDown = false
					end
				end
			end,
		},
		Gui.Button
		{
			Size = Vector2(48,48),
			Location = Vector2(1010, 103),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_normal.dds", Vector4(10, 10, 10, 10)),
				HoverImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_hover.dds", Vector4(10, 10, 10, 10)),
				DownImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_down.dds", Vector4(10, 10, 10, 10)),
				DisabledImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_disabled.dds", Vector4(0, 0, 0, 0)),	
			},
			EventClick = function()
				Hide_TeamFAQ()
			end,
		},
	},
}

FAQ_inside_ui = Gui.Create()
{
	Gui.Control "root"
	{
		Size = Vector2(1200, 900),
		Location = Vector2(0, 0),
		BackgroundColor = ARGB(0, 255, 255, 255),
		Gui.Control "c_1"
		{
			Size = Vector2(484,431),
			Location = Vector2(354, 195),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/Team/FAQ/lb_squad_yindao_bg04.dds", Vector4(0, 0, 0, 0)),
			},
		},
		Gui.Button
		{
			Size = Vector2(48,48),
			Location = Vector2(810, 179),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_normal.dds", Vector4(10, 10, 10, 10)),
				HoverImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_hover.dds", Vector4(10, 10, 10, 10)),
				DownImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_down.dds", Vector4(10, 10, 10, 10)),
				DisabledImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_disabled.dds", Vector4(0, 0, 0, 0)),	
			},
			EventClick = function()
				Hide_FAQInside()
			end,
		},
	},
}

function Show_TeamFAQ()
	TeamFAQmodel = ModalWindow.GetNew()
	TeamFAQmodel.root.Size = Vector2(1200, 900)
	TeamFAQmodel.AllowEscToExit = true
	team_FAQ_ui.root.Parent = TeamFAQmodel.root
end

function Hide_TeamFAQ()
	if TeamFAQmodel then
		TeamFAQmodel.Close()
		TeamFAQmodel = nil
	end
end

function Show_FAQInside(pathname)
	FAQInsidemodel = ModalWindow.GetNew()
	FAQInsidemodel.root.Size = Vector2(1200, 900)
	FAQInsidemodel.AllowEscToExit = true
	FAQ_inside_ui.root.Parent = FAQInsidemodel.root
	FAQ_inside_ui.c_1.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/Team/FAQ/"..pathname..".dds", Vector4(0, 0, 0, 0)),}
end

function Hide_FAQInside()
	if FAQInsidemodel then
		FAQInsidemodel.Close()
		FAQInsidemodel = nil
	end
end