module("L_LevelUpEffect",package.seeall)

modalEffect = nil
modalMake = nil
local currenceText = 
{
	[2] = " "..lang:GetText("FC点"),
	[5] = " "..lang:GetText("个人黑晶石"),
	[6] = " "..lang:GetText("战队黑铁"),
	[7] = " "..lang:GetText("个人原石"),
	[8] = " "..lang:GetText("战队原石"),
}
effect = Gui.Create()
{
	Gui.Control "root"
	{
		Dock = "kDockFill",
		BackgroundColor = ARGB(0, 0, 0, 0),
		Gui.ChangeControl "effect_text"
		{
			Size = Vector2(780, 189),
			Location = Vector2(210,256),
			Normsize = Vector2(780, 189),
			NormLocation = Vector2(210,456),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/lb_com_tis_bg.dds",Vector4(185, 14, 185, 14)),
			},
			EventPlayEnd = function(Sender,e)					
				Hide_Effect()
			end,
			Gui.Label"retrun_level"
			{
				Size = Vector2(780, 25),
				Dock = "kDockTop",
				Text = lang:GetText("升级机枪塔"),
				Margin = Vector4(0,50,0,0),
				FontSize = 20,
				TextColor = ARGB(255, 255, 255, 255),
				TextAlign = "kAlignCenterMiddle",
			},
			Gui.Label"return_res"
			{
				Size = Vector2(780, 20),
				Dock = "kDockCenter",
				Text = lang:GetText("返还你黑铁"),
				FontSize = 16,
				TextColor = ARGB(255, 255, 255, 255),
				TextAlign = "kAlignCenterMiddle",
			},
			Gui.Label"return_fc"
			{
				Size = Vector2(780, 20),
				Dock = "kDockBottom",
				Text = lang:GetText("返还你"),
				Margin = Vector4(0,50,0,50),
				FontSize = 16,
				TextColor = ARGB(255, 255, 255, 255),
				TextAlign = "kAlignCenterMiddle",
			},
		},
		Gui.ChangeControl"big_icon"
		{
			Size = Vector2(361, 409),
			Location = Vector2(630,146),
			Normsize = Vector2(0, 0),
			NormLocation = Vector2(410,350),
			BackgroundColor = ARGB(0, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ibt_icon/guard02_2.dds",Vector4(0, 0, 0, 0)),
			},
		},		
	},
}

function Show_LevelUpEffect(info,currence)
	modalEffect = ModalWindow.GetNew()
	modalEffect.root.Size = Vector2(1200,900)
	modalEffect.AllowEscToExit = false
	effect.root.Parent = modalEffect.root
	ctrl_change(effect.effect_text)
	if info then
		if info.res > 0 then
			effect.return_res.Visible = true
			effect.return_res.Text = lang:GetText("返还您个人黑晶石")..info.res
		else
			effect.return_res.Visible = false
		end
		if info.outOfCost and info.outOfCost > 0 then
			if currence then
				effect.return_fc.Visible = true
				effect.return_fc.Text = lang:GetText("升至顶级了，剩余")..info.outOfCost..currenceText[currence]..lang:GetText("返还给您。")
			end		
		else
			effect.return_fc.Visible = false
		end
		if info.itemLevel then
			effect.retrun_level.Visible = true
			effect.retrun_level.Text = info.name..lang:GetText("升级为 LV：")..info.itemLevel
			effect.big_icon.Visible = true
			effect.big_icon.Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ibt_icon/"..info.resources..".dds",Vector4(0, 0, 0, 0)),
			}
			ctrl_change2(effect.big_icon)
		 else
			 effect.retrun_level.Visible = false
			 effect.big_icon.Visible = false
		 end
	end
end

function Hide_Effect()
	if modalEffect then
		modalEffect.Close()
		modalEffect = nil
	end
end

--让图标闪烁的效果动画
--参数：parentIcon = 此图标的控件名字。
function ctrl_change(parentIcon)
	local par = parentIcon
	par:Clear()
	par:InsertMovePoint(Vector2(210,256),0.50,Vector2(780, 189),ARGB(255,255,255,255))
	par:InsertMovePoint(Vector2(210,256),2.00,Vector2(780, 189),ARGB(255,255,255,255))
	par:ReState()
end
function ctrl_change2(parentIcon)
	local par = parentIcon
	par:Clear()
	par:InsertMovePoint(Vector2(230,146),0.60,Vector2(361, 409),ARGB(255,255,255,255))
	par:InsertMovePoint(Vector2(630,146),0.80,Vector2(361, 409),ARGB(255,255,255,255))
	par:InsertMovePoint(Vector2(630,146),3.00,Vector2(361, 409),ARGB(255,255,255,255))
	par:ReState()
end

--建造时间界面
makeTimeUi = Gui.Create()
{
	Gui.Control "root"
	{
		Dock = "kDockFill",
		BackgroundColor = ARGB(0, 0, 0, 0),
		Gui.ChangeControl "makeBg"
		{
			Size = Vector2(780, 189),
			Location = Vector2(210,256),
			Normsize = Vector2(780, 189),
			NormLocation = Vector2(210,256),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/lb_com_tis_bg.dds",Vector4(185, 14, 185, 14)),
			},
			EventPlayEnd = function(Sender,e)					
				Hide_Make()
			end,
			Gui.Label
			{
				Size = Vector2(100, 25),
				Location = Vector2(274,50),
				Text = lang:GetText("建造时间："),
				--Margin = Vector4(0,50,0,0),
				FontSize = 18,
				TextColor = ARGB(255, 255, 255, 255),
				TextAlign = "kAlignRightMiddle",
			},
			Gui.AnimControl "AnimTime"
			{
				Size = Vector2(32,32),
				BackgroundColor = ARGB(0, 255, 255, 255),			
				Location = Vector2(374,43),
				-- EventFinish = function(Sender,e)
					-- Sender:Stop()
				-- end,
				
				EventTimeHide = function(Sender,e)
					Sender:StopAnimation()
				end,
			},
			Gui.Label
			{
				Size = Vector2(780, 25),
				Dock = "kDockBottom",
				Text = lang:GetText("花费FC点可以立即完成建造"),
				Margin = Vector4(0,0,0,50),
				FontSize = 18,
				TextColor = ARGB(255, 255, 255, 255),
				TextAlign = "kAlignCenterMiddle",
			},
		},
		Gui.Control"lb_time"
		{
			Size = Vector2(250, 25),
			Location = Vector2(624,306),
			--Normsize = Vector2(250, 25),
			--NormLocation = Vector2(624,306),
			--BackgroundColor = ARGB(0, 255, 255, 255),
			Gui.Label"time_level"
			{
				Dock = "kDockFill",
				Text = "88:88:88",
				FontSize = 18,
				TextColor = ARGB(255, 255, 255, 255),
				TextAlign = "kAlignLeftMiddle",
			},
		},			
	},
}
function Show_MakeTimeEffect(info)
	modalMake = ModalWindow.GetNew()
	modalMake.root.Size = Vector2(1200,900)
	modalMake.AllowEscToExit = false
	makeTimeUi.root.Parent = modalMake.root
	
	if info then
		makeTimeUi.time_level.Text = L_FightTeam.GethourMinuteSeconds(info.buildTime)
	end
	makeTimeUi.AnimTime:AddAnim("frameClock",0.5,1)
	for i = 1, 4 do
		local frame = Gui.Image("LobbyUI/lb_squad_shijiandonghua.dds", Vector4(0, 0, 0, 0),Vector4((i-1)/4,0,i/4,1))
		makeTimeUi.AnimTime:AddFrame("frameClock",frame)
	end		
	makeTimeUi.AnimTime:ReStart()
	makeTimeUi.AnimTime:StartAnimation()
	ctrl_changeMakebg(makeTimeUi.makeBg)
	--ctrl_changeMakeTime(makeTimeUi.lb_time)
end

function Hide_Make()
	if modalMake then
		modalMake.Close()
		modalMake = nil
		makeTimeUi.AnimTime:ClearAll()
	end
end

function ctrl_changeMakebg(parentIcon)
	local par = parentIcon
	par:Clear()
	par:InsertMovePoint(Vector2(210,256),3.50,Vector2(780, 189),ARGB(255,255,255,255))
	--par:InsertMovePoint(Vector2(210,256),3.80,Vector2(780, 189),ARGB(0,255,255,255))
	par:ReState()
end
function ctrl_changeMakeTime(parentIcon)
	local par = parentIcon
	par:Clear()
	par:InsertMovePoint(Vector2(624,306),0.01,Vector2(250, 25),ARGB(0,255,255,255))
	par:InsertMovePoint(Vector2(624,306),3.00,Vector2(250, 25),ARGB(0,255,255,255))
	par:InsertMovePoint(Vector2(680,760),3.50,Vector2(250, 25),ARGB(0,255,255,255))
	par:InsertMovePoint(Vector2(680,760),3.60,Vector2(0, 0),ARGB(0,255,255,255))
	par:ReState()
end