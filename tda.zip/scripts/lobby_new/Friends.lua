module("L_Friends", package.seeall)

current_selected = 0
Vip = 0
Search_Con = 0
--动态列表参数
changes_List = 0

--频道信息
Channel_name = nil
Channel_list = nil
channel_id = 0
--Channel_Id = 0

--房间信息
room_name = nil
room_list = nil

Create_Friend_ui = nil
Create_Friends_ui = nil
Creat_Friends_From_ui = nil

Create_Friends_Choose_ui = nil

Create_Friends_Create_ui = nil

Create_Invited_Win_ui = nil
Create_GroupInvited_Win_ui = nil
Create_TepGroupInvited_Win_ui = nil

Create_Group_AddMembers_ui = nil
Create_LeaveGroup_Win_ui = nil
Create_KickingGroup_Win_ui = nil
Create_LeaveOwnGroup_Win_ui = nil
Create_LeaveOwnGroup_Window = nil

Create_DeleteFriend_Win_ui = nil

Create_InviteGame_Win_ui = nil
--bool 控件
Players_Search_Push = false

function ShowCreateFriendsWin()
	L_LobbyMain.LobbyMainWin.ctr_FriendsWin_root_Parent.Visible = true
end

--通讯录列表
local Create_Friend_List = 
{
	Gui.Control "ctr_Friend_List"
	{
		Size = Vector2(285, 311),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Location = Vector2(0, 0),
		
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_bg2.dds", Vector4(21, 25, 21, 46)),
		},
			
		--搜索
		Gui.Textbox "tbox_Friend_search"
		{
			Location = Vector2(12, 5),
			Size = Vector2(230, 25),
			FontSize = 14,
			TextColor = ARGB(255, 167, 179, 176),
			Text = lang:GetText("搜索玩家..."),
			--BackgroundColor = ARGB(255,255,255,255),
			Skin = Gui.TextboxSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_bg3_normal.dds", Vector4(6, 6, 6, 6)),
				ActiveImage = Gui.Image("LobbyUI/Friends/lb_contact_bg3_down.dds", Vector4(6, 6, 6, 6)),
				DisabledImage = Gui.Image("LobbyUI/Friends/lb_contact_bg3_down.dds", Vector4(6, 6, 6, 6)),
			},
			EventEnter = function()
				if Create_Friend_ui.tbox_Friend_search.Text == lang:GetText("搜索玩家...") then
					Create_Friend_ui.tbox_Friend_search.Text = ""
					Create_Friend_ui.tbox_Friend_search.TextColor = ARGB(255, 62, 64, 63)
				end
				
			end,
			
			EventLeave = function()
				if Create_Friend_ui.tbox_Friend_search.Text == "" then
					Create_Friend_ui.tbox_Friend_search.Text = lang:GetText("搜索玩家...")
					Create_Friend_ui.tbox_Friend_search.TextColor = ARGB(255, 167, 179, 176)
				end
				
			end

		},
		
		--搜索
		Gui.Button "btn_Friend_Search"
		{
			Location = Vector2(248, 6),
			Size = Vector2(24, 24),
			BackgroundColor = ARGB(255,255,255,255),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_button_ss_normal.dds", Vector4(0, 0, 0, 0)),
				HoverImage = Gui.Image("LobbyUI/Friends/lb_contact_button_ss_hover.dds", Vector4(0, 0, 0, 0)),
				DownImage = Gui.Image("LobbyUI/Friends/lb_contact_button_ss_down.dds", Vector4(0, 0, 0, 0)),
				DisabledImage = Gui.Image("LobbyUI/Friends/lb_contact_button_ss_normal.dds", Vector4(0, 0, 0, 0)),
			},
			EventClick = function()
				--MessageBox.ShowWithConfirmCancel(lang:GetText("还在制作中？"), nil)
				if Create_Friend_ui.tbox_Friend_search.Text == lang:GetText("搜索玩家...") or Create_Friend_ui.tbox_Friend_search.Text == "" then
					MessageBox.ShowWithTimer(1,lang:GetText("请输入玩家名称"))
					return
				end
				TabFriendSearchWin(1)
				L_LobbyMain.FriendsSearch()
				Players_Search_Push = false
				Search_Con = 1
			end
		},
		
		--好友	
		Gui.Button "btn_Friend_Friend"
		{
			Location = Vector2(6, 33),
			Size = Vector2(270, 32),
			BackgroundColor = ARGB(255,255,255,255),
			TextColor = ARGB(255, 37, 37, 37),
			FontSize = 14,
			Text = lang:GetText("好 友"),
			HighlightTextColor = ARGB(255, 37, 37, 37),
			TextAlign = "kAlignLeftMiddle",
			Padding = Vector4(21, 0, 0, 3),

			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_tab2_normal.dds", Vector4(18, 5, 10, 10)),
				HoverImage = Gui.Image("LobbyUI/Friends/lb_contact_tab2_hover.dds", Vector4(18, 5, 10, 10)),
				DownImage = Gui.Image("LobbyUI/Friends/lb_contact_tab2_down.dds", Vector4(18, 5, 10, 10)),
				DisabledImage = Gui.Image("LobbyUI/Friends/lb_contact_tab2_normal.dds", Vector4(18, 5, 10, 10)),
			},
			EventClick = function()
				--MessageBox.ShowWithConfirmCancel(lang:GetText("还在制作中？"), nil)
				changes_List = 0
				ChangesList(changes_List)
			end,
			
			Gui.Label "lb_Friend_Friend"
			{
				Size = Vector2(80, 32),
				Location = Vector2(177, 0),
				TextColor = ARGB(255, 37, 37, 37),
				FontSize = 14,
				TextAlign = "kAlignRightMiddle",
				Text = "(50/50)",
				BackgroundColor = ARGB(0,255,255,255),
--					AutoSize = true,
			},
		},	
		
		--黑名单
		Gui.Button "btn_Friend_Blacklist"
		{
			Location = Vector2(6, 200),
			Size = Vector2(270, 32),
			BackgroundColor = ARGB(255,255,255,255),
			TextColor = ARGB(255, 37, 37, 37),
			FontSize = 14,
			Text = lang:GetText("黑名单"),
			HighlightTextColor = ARGB(255, 37, 37, 37),
			TextAlign = "kAlignLeftMiddle",
			Padding = Vector4(21, 0, 0, 3),
			
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_tab2_normal.dds", Vector4(23, 6, 9, 5)),
				HoverImage = Gui.Image("LobbyUI/Friends/lb_contact_tab2_hover.dds", Vector4(23, 6, 9, 5)),
				DownImage = Gui.Image("LobbyUI/Friends/lb_contact_tab2_down.dds", Vector4(23, 6, 9, 5)),
				DisabledImage = Gui.Image("LobbyUI/Friends/lb_contact_tab2_normal.dds", Vector4(23, 6, 9, 5)),
			},
			EventClick = function()
				--MessageBox.ShowWithConfirmCancel(lang:GetText("还在制作中？"), nil)
				changes_List = 1
				ChangesList(changes_List)
				
			end,
			Gui.Label"lb_Friend_Blacklist"
			{
				Size = Vector2(80, 32),
				Location = Vector2(177, 0),
				TextColor = ARGB(255, 37, 37, 37),
				FontSize = 14,
				TextAlign = "kAlignRightMiddle",
				Text = "(0/0)",
				BackgroundColor = ARGB(0,255,255,255),
--					AutoSize = true,
			},
		},
		
		--陌生人
		Gui.Button "btn_Friend_Stranger"
		{
			Location = Vector2(6, 229),
			Size = Vector2(270, 32),
			BackgroundColor = ARGB(255,255,255,255),
			TextColor = ARGB(255, 37, 37, 37),
			FontSize = 14,
			Text = lang:GetText("伙 伴"),
			HighlightTextColor = ARGB(255, 37, 37, 37),
			TextAlign = "kAlignLeftMiddle",
			Padding = Vector4(21, 0, 0, 3),
			
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_tab2_normal.dds", Vector4(23, 6, 9, 5)),
				HoverImage = Gui.Image("LobbyUI/Friends/lb_contact_tab2_hover.dds", Vector4(23, 6, 9, 5)),
				DownImage = Gui.Image("LobbyUI/Friends/lb_contact_tab2_down.dds", Vector4(23, 6, 9, 5)),
				DisabledImage = Gui.Image("LobbyUI/Friends/lb_contact_tab2_normal.dds", Vector4(23, 6, 9, 5)),
			},
			EventClick = function()
				--MessageBox.ShowWithConfirmCancel(lang:GetText("还在制作中？"), nil)
				changes_List = 2
				ChangesList(changes_List)
				
			end,
			Gui.Label"lb_Friend_Stranger"
			{
				Size = Vector2(80, 32),
				Location = Vector2(177, 0),
				TextColor = ARGB(255, 37, 37, 37),
				FontSize = 14,
				TextAlign = "kAlignRightMiddle",
				Text = "(0/0)",
				BackgroundColor = ARGB(0,255,255,255),
--					AutoSize = true,
			},				
		},
			
		--黑名单列表
		Gui.ListTreeView "list_room_info_back"
		{
			Size = Vector2(265, 132),
			Location = Vector2(8, 95),
			
			Style = "Gui.ListTreeViewWith_VScroll_Channl",
			HeaderVisible = false,

			ItemHeight = 32,
			FontSize = 14,
			TextColor = ARGB(255, 216, 217, 208),
			VScrollBarPos = Vector2(0, 0),
			VScrollBarWidth = 8,
			VScrollBarButtonSize = 1,
			HScrollBarWidth = 8,
			
			--双击鼠标
			EventDoubleClick = function(sender, e)
				
			end,
			
			--右击鼠标
			EventRightClick = function(sender, e)
				Create_Friend_ui.list_room_info_back.PopupMenu:RemoveAll()
				Create_Friend_ui.list_room_info_back.PopupMenu:AddItem(lang:GetText("加为好友"))
				Create_Friend_ui.list_room_info_back.PopupMenu:AddItem(lang:GetText("查看信息"))   
				Create_Friend_ui.list_room_info_back.PopupMenu:AddItem(lang:GetText("删除"))
				Create_Friend_ui.list_room_info_back.PopupMenu:AddItem(lang:GetText("我要举报"))
				Create_Friend_ui.list_room_info_back.PopupMenu.Style = "Gui.MenuNew"
				  
				Create_Friend_ui.list_room_info_back.PopupMenu.EventClick = function(sender, e)
					local item = ptr_cast(sender.Tag)	
					local itemName = item:GetText(4)
					if sender.SelectedIndex == 0 then
						if itemName ~= "" then
							FriendsAdd(L_LobbyMain.Black_rpc_data,itemName)
						end						
					elseif  sender.SelectedIndex == 1 then
						if itemName ~= "" then
							ShowPerson(L_LobbyMain.Black_rpc_data,itemName)
						end
					elseif  sender.SelectedIndex == 2 then
						if itemName ~= "" then
							local line = 1
							for _,v in ipairs(L_LobbyMain.Black_rpc_data) do
								if v[3] == itemName then
									break
								end
								line = line + 1
							end
							if L_LobbyMain.Black_rpc_data[line] then
								local args = {pid = ptr_cast(game.CurrentState):GetCharacterId(), action = "delete", id = L_LobbyMain.Black_rpc_data[line][1] , name =L_LobbyMain.Black_rpc_data[line][3]}
								rpc.safecall("friends_menu",args,nil,function () L_MessageBox.CloseWaiter() end)
							end
						end
					elseif sender.SelectedIndex == 3 then
						if itemName ~= "" then
							ShowReportWin(itemName,1)
						end
					end 
				end
				local item = sender.MouseSelectedItem
				if item then
					local itemName = item:GetText(4)
					if itemName ~= "" and itemName ~= L_LobbyMain.PersonalInfo_data.name then
						sender.PopupMenu:Open()	
					end
				end
			end,
		},
			
		--陌生人列表
		Gui.ListTreeView "list_room_info_stranger"
		{
			Size = Vector2(265, 132),
			Location = Vector2(8, 124),
			Style = "Gui.ListTreeViewWith_VScroll_Channl",
			HeaderVisible = false,

			ItemHeight = 32,
			FontSize = 14,
			TextColor = ARGB(255, 216, 217, 208),
			VScrollBarPos = Vector2(0, 0),
			VScrollBarWidth = 8,
			VScrollBarButtonSize = 1,
			HScrollBarWidth = 8,
			
			--双击鼠标
			EventDoubleClick = function(sender, e)
				local item = sender.SelectedItem
				if item then
					local itemName = item:GetText(4)
					for _,v in ipairs(L_LobbyMain.partners_rpc_data) do
						if v[3] == itemName then
							Vip = v[6]
							Name_Id = v[1]
							break
						end
					end
					CreatePrivateChat(itemName,1)
				end
			end,
			
			--右击鼠标
			EventRightClick = function(sender, e)
				Create_Friend_ui.list_room_info_stranger.PopupMenu:RemoveAll()
				Create_Friend_ui.list_room_info_stranger.PopupMenu:AddItem(lang:GetText("私聊"))
				Create_Friend_ui.list_room_info_stranger.PopupMenu:AddItem(lang:GetText("和TA一起玩"))
				Create_Friend_ui.list_room_info_stranger.PopupMenu:AddItem(lang:GetText("加为好友"))
				Create_Friend_ui.list_room_info_stranger.PopupMenu:AddItem(lang:GetText("加入黑名单"))
				Create_Friend_ui.list_room_info_stranger.PopupMenu:AddItem(lang:GetText("查看信息"))  
				Create_Friend_ui.list_room_info_stranger.PopupMenu:AddItem(lang:GetText("我要举报"))				
				Create_Friend_ui.list_room_info_stranger.PopupMenu.Style = "Gui.MenuNew"
				  
				Create_Friend_ui.list_room_info_stranger.PopupMenu.EventClick = function(sender, e)
					local item = ptr_cast(sender.Tag)
					local itemName = item:GetText(4)
					if sender.SelectedIndex == 0 then
						if itemName ~= "" then
							for _,v in ipairs(L_LobbyMain.partners_rpc_data) do
								if v[3] == itemName then
									Vip = v[6]
									Name_Id = v[1]
									break
								end
							end
							CreatePrivateChat(itemName,1)
						end
					elseif  sender.SelectedIndex == 1 then
						if itemName ~= "" then
							L_LobbyMain.GotoPlayerRoom(itemName,false)
						end
					elseif  sender.SelectedIndex == 2 then
						if itemName ~= "" then
							FriendsAdd(L_LobbyMain.partners_rpc_data,itemName)		
						end
					elseif  sender.SelectedIndex == 3 then
						if itemName ~= "" then
							L_Friends.BlackAdd(itemName)
						end
					elseif  sender.SelectedIndex == 4 then
						if itemName ~= "" then
							ShowPerson(L_LobbyMain.partners_rpc_data,itemName)
						end
					elseif  sender.SelectedIndex == 5 then
						if itemName ~= "" then
							ShowReportWin(itemName,1)
						end
					end 					
				end
				local item = sender.MouseSelectedItem
				if item then
					local itemName = item:GetText(4)
					if itemName ~= "" and itemName ~= L_LobbyMain.PersonalInfo_data.name then
						sender.PopupMenu:Open()	
					end
				end
			end
		},
			
		--好友列表
		Gui.ListTreeView "list_room_info_friend"
		{
			Size = Vector2(265, 132),
			Location = Vector2(8, 66),
			Style = "Gui.ListTreeViewWith_VScroll_Channl",			
			HeaderVisible = false,			
			ItemHeight = 32,
			FontSize = 14,
			TextColor = ARGB(255, 216, 217, 208),
			VScrollBarWidth = 8,
			VScrollBarButtonSize = 1,
			HScrollBarWidth = 8,
			VScrollBarPos = Vector2(0, 0),
			--双击鼠标
			EventDoubleClick = function(sender, e)
				local item = sender.SelectedItem
				local itemName = item:GetText(4)
				for _,v in ipairs(L_LobbyMain.Friends_rpc_data) do
					if v[3] == itemName then
						Vip = v[6]
						Name_Id = v[1]
						break
					end
				end
				CreatePrivateChat(itemName,1)
			end,
			EventRightClick = function(sender, e)
				Create_Friend_ui.list_room_info_friend.PopupMenu:RemoveAll()
				Create_Friend_ui.list_room_info_friend.PopupMenu:AddItem(lang:GetText("私聊"))
				Create_Friend_ui.list_room_info_friend.PopupMenu:AddItem(lang:GetText("和TA一起玩"))   
				Create_Friend_ui.list_room_info_friend.PopupMenu:AddItem(lang:GetText("查看信息")) 
				Create_Friend_ui.list_room_info_friend.PopupMenu:AddItem(lang:GetText("加入黑名单"))
				Create_Friend_ui.list_room_info_friend.PopupMenu:AddItem(lang:GetText("删除好友"))
				Create_Friend_ui.list_room_info_friend.PopupMenu.Style = "Gui.MenuNew"
				  
				Create_Friend_ui.list_room_info_friend.PopupMenu.EventClick = function(sender, e)
					local item = ptr_cast(sender.Tag)
					local itemName = item:GetText(4)
					if sender.SelectedIndex == 0 then
						if itemName ~= "" then
							for _,v in ipairs(L_LobbyMain.Friends_rpc_data) do
								if v[3] == itemName then
									Vip = v[6]
									Name_Id = v[1]
									break
								end
							end
							CreatePrivateChat(itemName,1)
						end						
					elseif  sender.SelectedIndex == 1 then
						if itemName ~= "" then
							L_LobbyMain.GotoPlayerRoom(itemName,false)
						end
					elseif  sender.SelectedIndex == 2 then	 
						if itemName ~= "" then
							ShowPerson(L_LobbyMain.Friends_rpc_data,itemName)
						end
					elseif  sender.SelectedIndex == 3 then
						if itemName ~= "" then
							L_Friends.BlackAdd(itemName)
						end
					elseif  sender.SelectedIndex == 4 then
						if itemName ~= "" then
							ShowDeleteFriendCreateWin(gui,itemName)
						end
					end                                         
				end
				
				local item = sender.MouseSelectedItem
				if item then
					local itemName = item:GetText(4)
					if itemName ~= "" then
						sender.PopupMenu:Open()	
					end
				end
			end,
		},
		
		--多人聊天
		Gui.Button "btn_Friend_MoreNews"
		{
			Location = Vector2(55, 270),
			Size = Vector2(178, 36),
			BackgroundColor = ARGB(255,255,255,255),
			Text = lang:GetText("发起群聊"),
			FontSize = 14,
			TextAlign = "kAlignCenterMiddle",
			TextColor = ARGB(255,211,211,211),
			HighlightTextColor = ARGB(255, 211 ,211 ,211),
			Enable = true,
			Padding = Vector4(0 ,0 ,0 ,4),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/lb_onlinetime_button_2_normal.dds", Vector4(15, 0, 15, 0)),
				HoverImage = Gui.Image("LobbyUI/lb_onlinetime_button_2_hover.dds", Vector4(15, 0, 15, 0)),
				DownImage = Gui.Image("LobbyUI/lb_onlinetime_button_2_down.dds", Vector4(15, 0, 15, 0)),
				DisabledImage = Gui.Image("LobbyUI/lb_onlinetime_button_2_disabled.dds", Vector4(15, 0, 15, 0)),
			},
			EventClick = function()
				--MessageBox.ShowWithConfirmCancel(lang:GetText("还在制作中？"), nil)
				ptr_cast(game.CurrentState):GroupCreate()
				Create_Friend_ui.btn_Friend_MoreNews.Enable = false
			end
		},
		
		--好友搜索窗口
		Gui.Control "ctr_Friend_Search"
		{
			Location = Vector2(0, 33),
			Size = Vector2(278, 280),
			BackgroundColor = ARGB(0,255,255,255),
			Visible = false,
			
			Gui.ListTreeView "list_room_FriendSearch"
			{
				Size = Vector2(265, 228),
				Location = Vector2(8,0),
				Style = "Gui.ListTreeViewWith_VScroll_Channl",
				HeaderVisible = false,

				ItemHeight = 32,
				FontSize = 14,
				TextColor = ARGB(255, 216, 217, 208),
				VScrollBarWidth = 8,
				VScrollBarButtonSize = 1,
				HScrollBarWidth = 8,
				VScrollBarPos = Vector2(0, 0),
			
				EventClick = function(sender, e)
					itemSearch = nil
					itemSearch = sender.SelectedItem
					Players_Search_Push = true
				end,
				
				--双击鼠标
				EventDoubleClick = function(sender, e)
					local item = sender.SelectedItem
					local itemName = item:GetText(2)
					if itemName == L_LobbyMain.PersonalInfo_data.name then
						ShowLeaveOwnGroupCreateWin(gui,lang:GetText("您不能和自己私聊！"))
					else
						for _,v in ipairs(L_LobbyMain.Search_rpc_data.list) do
							if v[3] == itemName then
								Vip = v[6]
								Name_Id = v[1]
								break
							end
						end
						CreatePrivateChat(itemName,1)
					end
				end,
				
				--右击鼠标
				EventRightClick = function(sender, e)
					Create_Friend_ui.list_room_FriendSearch.PopupMenu:RemoveAll()
					Create_Friend_ui.list_room_FriendSearch.PopupMenu:AddItem(lang:GetText("私聊"))
					Create_Friend_ui.list_room_FriendSearch.PopupMenu:AddItem(lang:GetText("和TA一起玩"))
					Create_Friend_ui.list_room_FriendSearch.PopupMenu:AddItem(lang:GetText("加为好友"))
					Create_Friend_ui.list_room_FriendSearch.PopupMenu:AddItem(lang:GetText("加入黑名单"))
					Create_Friend_ui.list_room_FriendSearch.PopupMenu:AddItem(lang:GetText("查看信息"))
					Create_Friend_ui.list_room_FriendSearch.PopupMenu:AddItem(lang:GetText("我要举报"))
					Create_Friend_ui.list_room_FriendSearch.PopupMenu.Style = "Gui.MenuNew"
					  
					Create_Friend_ui.list_room_FriendSearch.PopupMenu.EventClick = function(sender, e)
						local item = ptr_cast(sender.Tag)
						local itemName = item:GetText(2)
						if sender.SelectedIndex == 0 then
							if itemName ~= "" then
								if itemName == L_LobbyMain.PersonalInfo_data.name then
									ShowLeaveOwnGroupCreateWin(gui,lang:GetText("您不能和自己私聊！"))
								else
									for _,v in ipairs(L_LobbyMain.Search_rpc_data.list) do
										if v[3] == itemName then
											Vip = v[6]
											Name_Id = v[1]
											break
										end
									end
									CreatePrivateChat(itemName,1)
								end
							end
						elseif  sender.SelectedIndex == 1 then
							if itemName ~= "" then
								L_LobbyMain.GotoPlayerRoom(itemName,false)
							end
						elseif  sender.SelectedIndex == 2 then
							if item then
								FriendsAdd(L_LobbyMain.Search_rpc_data.list,itemName)		
							end
						elseif  sender.SelectedIndex == 3 then
							if itemName ~= "" then
								L_Friends.BlackAdd(itemName)
							end
						elseif  sender.SelectedIndex == 4 then
							if itemName ~= "" then
								if itemName == L_LobbyMain.PersonalInfo_data.name then
									if L_LobbyMain.LobbyMainWin_Boddy then
										L_PersonalInfo.Show(L_LobbyMain.LobbyMainWin_Boddy.LobbyMainWin_Boddy_Root)
									end
									L_LobbyMain.InitPersonalInfoRPCInfo()
									lg:SetLobbyModules(12)
									L_LobbyMain.current_chosse_main_page = 12
									L_PersonalInfo.SynchronousClassButton()
									L_LobbyMain.FillClassBag(ptr_cast(game.CurrentState):GetCharacterId(), L_LobbyMain.current_choose_class)
									return
								end
								ShowPerson(L_LobbyMain.Search_rpc_data.list,itemName)
							end
						--state:ChangeSlotStatus(item.ID, 2)
						elseif  sender.SelectedIndex == 5 then
							if itemName ~= "" then
								ShowReportWin(itemName,1)
							end
						end                                         
					end
					local item = sender.MouseSelectedItem
					if item then
						local itemName = item:GetText(2)
						if itemName ~= "" and itemName ~= L_LobbyMain.PersonalInfo_data.name then
							sender.PopupMenu:Open()
						end
					end
				end,
				
				Gui.Label "lab_Null_Player"
				{
					Size = Vector2(215,32),
					Location = Vector2(0,0),
					TextColor = ARGB(255, 216, 217, 208),
					FontSize = 14,
					Visible = false,
					Text = lang:GetText("没有搜索到相应的玩家！"),
					TextAlign = "kAlignCenterMiddle",
					BackgroundColor = ARGB(0,255,255,255),
				},
			},
			
			Gui.Button
			{
				Location = Vector2(15, 237),
				Size = Vector2(110, 36),
				BackgroundColor = ARGB(255,255,255,255),
				Text = lang:GetText("加为好友"),
				FontSize = 16,
				TextAlign = "kAlignCenterMiddle",
				TextColor = ARGB(255,215,232,227),
				HighlightTextColor = ARGB(255, 215 ,232 ,227),
				Padding = Vector4(0 ,0 ,0 ,4),
				
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_button_normal.tga", Vector4(14, 14, 14, 14)),
					HoverImage = Gui.Image("LobbyUI/Friends/lb_contact_button_hover.tga", Vector4(14, 14, 14, 14)),
					DownImage = Gui.Image("LobbyUI/Friends/lb_contact_button_down.tga", Vector4(14, 14, 14, 14)),
					DisabledImage = Gui.Image("LobbyUI/Friends/lb_contact_button_normal.tga", Vector4(14, 14, 14, 14)),
				},
				EventClick = function()
					--MessageBox.ShowWithConfirmCancel(lang:GetText("还在制作中？"), nil)
					if Players_Search_Push == true and itemSearch then
						FriendsAdd(L_LobbyMain.Search_rpc_data.list,itemSearch:GetText(2))
						TabFriendSearchWin(0)
						Players_Search_Push = false
					else
						MessageBox.ShowWithTimer(1,lang:GetText("请选择一位玩家加为好友！"))
					end
				end
			},
			
			Gui.Button
			{
				Location = Vector2(158, 237),
				Size = Vector2(110, 36),
				BackgroundColor = ARGB(255,255,255,255),
				Text = lang:GetText("取消"),
				FontSize = 16,
				TextAlign = "kAlignCenterMiddle",
				TextColor = ARGB(255,215,232,227),
				HighlightTextColor = ARGB(255, 215 ,232 ,227),
				Padding = Vector4(0 ,0 ,0 ,4),
				
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_button_normal.tga", Vector4(14, 14, 14, 14)),
					HoverImage = Gui.Image("LobbyUI/Friends/lb_contact_button_hover.tga", Vector4(14, 14, 14, 14)),
					DownImage = Gui.Image("LobbyUI/Friends/lb_contact_button_down.tga", Vector4(14, 14, 14, 14)),
					DisabledImage = Gui.Image("LobbyUI/Friends/lb_contact_button_normal.tga", Vector4(14, 14, 14, 14)),
				},
				EventClick = function()
					--MessageBox.ShowWithConfirmCancel(lang:GetText("还在制作中？"), nil)					
					Players_Search_Push = false
					TabFriendSearchWin(0)
				end
			},
		},
	},
}

--好友搜索切换窗口
function TabFriendSearchWin(which)
	if which == 1 then
		Create_Friend_ui.btn_Friend_Friend.Visible = false
		Create_Friend_ui.btn_Friend_Blacklist.Visible = false
		Create_Friend_ui.btn_Friend_Stranger.Visible = false
		Create_Friend_ui.btn_Friend_MoreNews.Visible = false
		Create_Friend_ui.ctr_Friend_Search.Visible = true
		Create_Friend_ui.list_room_info_back.Visible = false
		Create_Friend_ui.list_room_info_stranger.Visible = false
		Create_Friend_ui.list_room_info_friend.Visible = false
	else
		Create_Friend_ui.btn_Friend_Friend.Visible = true
		Create_Friend_ui.btn_Friend_Blacklist.Visible = true
		Create_Friend_ui.btn_Friend_Stranger.Visible = true
		Create_Friend_ui.btn_Friend_MoreNews.Visible = true
		Create_Friend_ui.ctr_Friend_Search.Visible = false
		if changes_List == 0 then
			Create_Friend_ui.list_room_info_friend.Visible = true
		elseif changes_List == 1 then
			Create_Friend_ui.list_room_info_back.Visible = true
		elseif changes_List == 2 then
			Create_Friend_ui.list_room_info_stranger.Visible = true
		end
		Search_Con = 0
	end
end

--多人聊天好友选择框
local Create_Friends_Choose = 
{
	Gui.Control "ctr_Friends_Choose"
	{
		Size = Vector2(1600, 900),
		BackgroundColor = ARGB(255, 255, 255, 255),
		
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/lb_common_black_bg.dds", Vector4(0, 0, 0, 0)),
		},

		Gui.Control
		{
			Size = Vector2(273, 309),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Dock = "kDockCenter",
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_bg1.dds", Vector4(28, 28, 28, 28)),
			},
			
			Gui.Control 
			{
				Size = Vector2(20, 20),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Location = Vector2(11, 15),
				
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_ico1.dds", Vector4(0, 0, 0, 0)),
				},
			},
			
			Gui.Label "lbl_Friends_Choose"
			{
				Size = Vector2(220, 24),
				Location = Vector2(30, 12),
				TextColor = ARGB(255,52, 50, 50),
				TextAlign = "kAlignCenterMiddle",
				FontSize = 14,
				BackgroundColor = ARGB(0, 255, 255, 255),
				Text = lang:GetText("你还可以添加23个参与者"),
			},
			
			Gui.Control 
			{
				Size = Vector2(257, 260),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Location = Vector2(8, 38),
				
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_bg2.dds", Vector4(21, 25, 21, 46)),
				},
				
				--好友
				Gui.Button
				{
					Location = Vector2(6, 8),
					Size = Vector2(244, 32),
					BackgroundColor = ARGB(255,255,255,255),
					TextColor = ARGB(255, 37, 37, 37),
					FontSize = 14,
					Text = lang:GetText("好 友"),
					HighlightTextColor = ARGB(255, 37, 37, 37),
					TextAlign = "kAlignLeftMiddle",
					Padding = Vector4(28, 0, 0, 3),
					
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_tab2_down.dds", Vector4(23, 6, 9, 5)),
					},
					
--[[					Gui.Label "lb_Friends_Choose"
					{
						Size = Vector2(80, 32),
						Location = Vector2(114, 0),
						TextColor = ARGB(255, 37, 37, 37),
						FontSize = 14,
						TextAlign = "kAlignRightMiddle",
						Text = "(50/50)",
						BackgroundColor = ARGB(0,255,255,255),
					},]]
				},
			
				--列表好友
				Gui.ListTreeView "list_Friends_Choose_room"
				{
					Location = Vector2(8, 40),
					Size = Vector2(236, 172),
					Style = "Gui.ListTreeViewWith_VScroll_Channl",
					HeaderVisible = false,
					CheckIndex = 0,
					
					ItemHeight = 28,
					FontSize = 14,
					TextColor = ARGB(255, 37, 37, 37),
					VScrollBarDisplay = "kVisible",
					VScrollBarWidth = 8,
					VScrollBarButtonSize = 1,
					HScrollBarWidth = 8,
					VScrollBarPos = Vector2(0, 0),
					
					EventCheckChanged = function (sender, e)
						local item = sender.SelectedItem
						local TepNum = 5 - GetAddMemberNumbers(Create_Friends_Choose_ui.list_Friends_Choose_room , nil) - TepGroupNums
						if TepNum < 0 then
							item.Check = false
							return
						end
						Create_Friends_Choose_ui.lbl_Friends_Choose.Text = lang:GetText("你还可以添加")..TepNum..lang:GetText("个参与者")
					end,
					
--[[					EventClick = function(sender, e)
						local item = sender.SelectedItem
						if item == nil then
							return
						end
						item.Check = not item.Check
						local TepNum = 5 - GetAddMemberNumbers(Create_Friends_Choose_ui.list_Friends_Choose_room , nil) - TepGroupNums
						if TepNum < 0 then
							item.Check = false
							return
						end
						Create_Friends_Choose_ui.lbl_Friends_Choose.Text = lang:GetText("你还可以添加")..TepNum..lang:GetText("个参与者")
					end,]]
				},			
			
				--确定
				Gui.Button 
				{
					Location = Vector2(22, 218),
					Size = Vector2(85, 36),
					BackgroundColor = ARGB(255,255,255,255),
					Text = lang:GetText("确 定"),
					TextAlign = "kAlignCenterMiddle",
					TextColor = ARGB(255,215,232,227),
					HighlightTextColor = ARGB(255, 215 ,232 ,227),
					Padding = Vector4(0, 0, 0, 3),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_button_normal.tga", Vector4(14, 14, 14, 14)),
						HoverImage = Gui.Image("LobbyUI/Friends/lb_contact_button_hover.tga", Vector4(14, 14, 14, 14)),
						DownImage = Gui.Image("LobbyUI/Friends/lb_contact_button_down.tga", Vector4(14, 14, 14, 14)),
						DisabledImage = Gui.Image("LobbyUI/Friends/lb_contact_button_normal.tga", Vector4(14, 14, 14, 14)),
					},
					EventClick = function()
						--MessageBox.ShowWithConfirmCancel(lang:GetText("还在制作中？"), nil)												
						if GroupListScan(Create_Friends_Choose_ui.list_Friends_Choose_room,nil) == false then
							return
						end
						HideChatChoose()
					end
				},
				
				--取消退出
				Gui.Button
				{
					Location = Vector2(150, 218),
					Size = Vector2(85, 36),
					BackgroundColor = ARGB(255,255,255,255),
					Text = lang:GetText("取消"),
					TextAlign = "kAlignCenterMiddle",
					TextColor = ARGB(255,215,232,227),
					HighlightTextColor = ARGB(255, 215 ,232 ,227),
					Padding = Vector4(0, 0, 0, 3),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_button_normal.tga", Vector4(14, 14, 14, 14)),
						HoverImage = Gui.Image("LobbyUI/Friends/lb_contact_button_hover.tga", Vector4(14, 14, 14, 14)),
						DownImage = Gui.Image("LobbyUI/Friends/lb_contact_button_down.tga", Vector4(14, 14, 14, 14)),
						DisabledImage = Gui.Image("LobbyUI/Friends/lb_contact_button_normal.tga", Vector4(14, 14, 14, 14)),
					},
					EventClick = function()
						HideChatChoose()
					end
				},
			},
		},
	},
}

function ShowFriendsChooseWin(win_parent)
	if Create_Friends_Choose_ui then
		Create_Friends_Choose_ui.ctr_Friends_Choose.Parent = win_parent
--		Create_Friends_Choose_ui.lb_Friends_Choose.Text = "("..L_LobbyMain.FriendOnlineNumbers.."/"..L_LobbyMain.FriendNumbers..")"
		Create_Friends_Choose_ui.list_Friends_Choose_room:DeleteColumns()
		Create_Friends_Choose_ui.list_Friends_Choose_room:AddColumn("", 230, "kAlignCenterMiddle")
		local TepNum = 5 - GetTepGroupMembers()
		Create_Friends_Choose_ui.lbl_Friends_Choose.Text = lang:GetText("你还可以添加")..TepNum..lang:GetText("个参与者")
		AlignUI()
		return
	end
	
	--创建多人聊天好友选择框
	Create_Friends_Choose_ui = Gui.Create(win_parent)(Create_Friends_Choose)
--	Create_Friends_Choose_ui.lb_Friends_Choose.Text = "("..L_LobbyMain.FriendOnlineNumbers.."/"..L_LobbyMain.FriendNumbers..")"
	Create_Friends_Choose_ui.list_Friends_Choose_room:DeleteColumns()
	Create_Friends_Choose_ui.list_Friends_Choose_room:AddColumn("", 230, "kAlignCenterMiddle")
	local TepNum = 5 - GetTepGroupMembers()
	Create_Friends_Choose_ui.lbl_Friends_Choose.Text = lang:GetText("你还可以添加")..TepNum..lang:GetText("个参与者")
	AlignUI()
end

function GetTepGroupMembers()
	local l = TepGroup_Member
	for i = 1 , 10 do
		if ChatBTNSign == ChatInfo[i][1] then
			while l do
				if l.group_id == ChatInfo[i][7] then
					for j = 1 , 5 do
						if l.member_id[j] == 0 then
							TepGroupNums = j - 1
							return TepGroupNums
						end
					end
					TepGroupNums = 5
					return TepGroupNums
				end
				l = l.next
			end
		end
	end
	return 0
end
--群组列表
local Create_Friends_List = 
{
	Gui.Control "ctr_Friends_List"
	{
		Size = Vector2(285, 311),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Location = Vector2(0, 0),
		
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_bg2.dds", Vector4(21, 25, 21, 46)),
		},
		
		--列表
		Gui.ListTreeView "list_Group_room"
		{
			Location = Vector2(8, 5),
			Size = Vector2(265, 260),
			--Size = Vector2(240, 297),
			--Location = Vector2(16,30),
			Style = "Gui.ListTreeViewWith_VScroll_Channl",
			HeaderVisible = false,

			ItemHeight = 32,
			FontSize = 14,
			TextColor = ARGB(255, 37, 37, 37),
			VScrollBarWidth = 8,
			VScrollBarButtonSize = 1,
			HScrollBarWidth = 8,
			VScrollBarPos = Vector2(0, 0),
			--双击鼠标
			EventDoubleClick = function(sender, e)
				--MessageBox.ShowWithConfirmCancel(lang:GetText("还在制作中？"), nil)
				local item = sender.SelectedItem
				local itemName = item:GetText(0)
				if itemName == Channel_name then
					CreatePrivateChat(itemName,4)
				elseif itemName == room_name then
					CreatePrivateChat(itemName,5)
				elseif itemName == Team_name_Add then
					CreatePrivateChat(Team_name,6)
				elseif 1 then
					CreatePrivateChat(itemName,3)
				end
			end,
			
			--右击鼠标
			EventRightClick = function(sender, e)
				Create_Friends_ui.list_Group_room.PopupMenu:RemoveAll()
				Create_Friends_ui.list_Group_room.PopupMenu.ItemText_LeftSpace = 10
				Create_Friends_ui.list_Group_room.PopupMenu:AddItem(lang:GetText("展开群聊"))
				Create_Friends_ui.list_Group_room.PopupMenu:AddItem(lang:GetText("离开群组"))
				Create_Friends_ui.list_Group_room.PopupMenu:AddItem(lang:GetText("删除群组"))
				Create_Friends_ui.list_Group_room.PopupMenu.Style = "Gui.MenuNew"
				  
				Create_Friends_ui.list_Group_room.PopupMenu.EventClick = function(sender, e)
					local item = ptr_cast(sender.Tag)	
					local itemName = item:GetText(0)
					if sender.SelectedIndex == 0 then
						if itemName == Channel_name then
							CreatePrivateChat(itemName,4)
						elseif itemName == room_name then
							CreatePrivateChat(itemName,5)
						elseif itemName == Team_name_Add then
							CreatePrivateChat(Team_name,6)
						elseif 1 then
							CreatePrivateChat(itemName,3)
						end
					elseif sender.SelectedIndex == 1 then 
						if L_LobbyMain.MyGroup_rpc_data[1] and itemName == L_LobbyMain.MyGroup_rpc_data[1][5] then
							ShowLeaveOwnGroupCreateWin(gui,lang:GetText("您不能离开自己创建的群！"))
						elseif Channel_name == itemName or room_name == itemName then
							ShowLeaveOwnGroupCreateWin(gui,lang:GetText("您不能离开系统聊天群！"))
						elseif itemName == Team_name_Add then
							ShowLeaveOwnGroupCreateWin(gui,lang:GetText("请先离开“")..Team_name..lang:GetText("”战队！"))
						elseif itemName ~= "" and itemName ~= "    "..lang:GetText("你可以创建一个聊天群！") then
							ShowLeaveGroupCreateWin(gui,itemName)
							LeaveGroupfont(itemName)
						end
					--state:ChangeSlotStatus(item.ID, 1)	
					elseif sender.SelectedIndex == 2 then
						if itemName ~= "" and itemName ~= "    "..lang:GetText("你可以创建一个聊天群！") then
							if Channel_name == itemName or room_name == itemName then
								ShowLeaveOwnGroupCreateWin(gui,lang:GetText("您不能删除系统聊天群！"))
							elseif itemName == Team_name_Add then
								ShowLeaveOwnGroupCreateWin(gui,lang:GetText("请先离开“")..Team_name..lang:GetText("”战队！"))
							elseif L_LobbyMain.MyGroup_rpc_data[1] ==nil then 
								ShowLeaveOwnGroupCreateWin(gui,lang:GetText("您不能删除其TA人创建的群！"))
							elseif	L_LobbyMain.MyGroup_rpc_data[1] and itemName ~= L_LobbyMain.MyGroup_rpc_data[1][5] then
								ShowLeaveOwnGroupCreateWin(gui,lang:GetText("您不能删除其TA人创建的群！"))
							elseif L_LobbyMain.MyGroup_rpc_data[1][5] == itemName then
								if L_LobbyMain.MyGroup_rpc_data[2] then
									ShowLeaveOwnGroupCreateWin(gui,lang:GetText("群内还有其TA成员，您不能删除该组！"))
								else
									local args = {pid = ptr_cast(game.CurrentState):GetCharacterId(), action = "delete_group", id = ptr_cast(game.CurrentState):GetCharacterId()}
									rpc.safecall("friends_menu",args,nil,function () L_MessageBox.CloseWaiter() end)
								end
							end
						end
					end
				end
				local item = sender.MouseSelectedItem
				if item then
					local itemName = item:GetText(0)
					if itemName ~= "" and itemName ~= "    "..lang:GetText("你可以创建一个聊天群！") then
						sender.PopupMenu:Open()
					end
				end
			end,
		},
		
		--创建群
		Gui.Button"btn_Create_Group"
		{
			Location = Vector2(55, 270),
			Size = Vector2(178, 36),
			BackgroundColor = ARGB(255,255,255,255),
			Text = lang:GetText("创建群组"),
			FontSize = 14,
			TextAlign = "kAlignCenterMiddle",
			TextColor = ARGB(255,211,211,211),
			HighlightTextColor = ARGB(255, 211 ,211 ,211),
			Padding = Vector4(0 ,0 ,0 ,4),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/lb_onlinetime_button_2_normal.dds", Vector4(15, 0, 15, 0)),
				HoverImage = Gui.Image("LobbyUI/lb_onlinetime_button_2_hover.dds", Vector4(15, 0, 15, 0)),
				DownImage = Gui.Image("LobbyUI/lb_onlinetime_button_2_down.dds", Vector4(15, 0, 15, 0)),
				DisabledImage = Gui.Image("LobbyUI/lb_onlinetime_button_2_disabled.dds", Vector4(15, 0, 15, 0)),
			},
			
			EventClick = function()
				--MessageBox.ShowWithConfirmCancel(lang:GetText("还在制作中？"), nil)
				ShowFriendsCreateWin(gui)
			end
		},
	},
}

--创建聊天组群框
local Create_Frends_Create =
{
	Gui.Control "ctr_Friends_Create"
	{
		Size = Vector2(1600, 900),
		BackgroundColor = ARGB(255, 255, 255, 255),
		
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/lb_common_black_bg.dds", Vector4(0, 0, 0, 0)),
		},
		
		Gui.Control
		{
			Size = Vector2(382, 149),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Location = Vector2(605, 390),
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/Friends/lb_chat_bg5.dds", Vector4(3, 3, 3, 8)),
			},
			
			Gui.Label
			{
				Size = Vector2(320, 30),
				Location = Vector2(25, 15),
				TextColor = ARGB(255,52, 50, 50),
				FontSize = 18,
				Text = lang:GetText("输入群组名称"),
				--AutoSize = true,
				TextAlign = "kAlignCenterMiddle",
				TextPadding = Vector4(0,0,0,5),
			},
			
			Gui.Textbox "tbox_GroupName"
			{
				Size = Vector2(309, 28),
				Location = Vector2(35 , 52),
				FontSize = 14,
				TextColor = ARGB(255,81, 79, 79),
				Skin = Gui.TextboxSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_bg3_normal.dds", Vector4(6, 6, 6, 6)),
					ActiveImage = Gui.Image("LobbyUI/Friends/lb_contact_bg3_down.dds", Vector4(6, 6, 6, 6)),
				},
			},
			
			--确定
			Gui.Button
			{
				Location = Vector2(59, 94),
				Size = Vector2(93, 31),
				BackgroundColor = ARGB(255,255,255,255),
				Text = lang:GetText("确 定"),
				TextAlign = "kAlignCenterMiddle",
				TextColor = ARGB(255,215,232,227),
				HighlightTextColor = ARGB(255, 215 ,232 ,227),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_button_normal.tga", Vector4(14, 14, 14, 14)),
					HoverImage = Gui.Image("LobbyUI/Friends/lb_contact_button_hover.tga", Vector4(14, 14, 14, 14)),
					DownImage = Gui.Image("LobbyUI/Friends/lb_contact_button_down.tga", Vector4(14, 14, 14, 14)),
					DisabledImage = Gui.Image("LobbyUI/Friends/lb_contact_button_normal.tga", Vector4(14, 14, 14, 14)),
				},
				
				EventClick = function()
					--MessageBox.ShowWithConfirmCancel(lang:GetText("还在制作中？"), nil)
					if game:TextLenght(Create_Friends_Create_ui.tbox_GroupName.Text) > 6 then
						ShowLeaveOwnGroupCreateWin(gui,lang:GetText("群组名称只能1到6个字！"))
						return
					end
					if game:TextLenght(Create_Friends_Create_ui.tbox_GroupName.Text) < 1 then
						ShowLeaveOwnGroupCreateWin(gui,lang:GetText("群组名称只能1到6个字！"))
						return
					end
					if string.find(Create_Friends_Create_ui.tbox_GroupName.Text," ") then
						ShowLeaveOwnGroupCreateWin(gui,lang:GetText("群组名称含有非法字符！"))
						return
					end
					CreateGroupChat()
					HideFriendsCreateWin()
				end
			},
			
			--取消
			Gui.Button
			{
				Location = Vector2(218, 94),
				Size = Vector2(93, 31),
				BackgroundColor = ARGB(255,255,255,255),
				Text = lang:GetText("取 消"),
				TextAlign = "kAlignCenterMiddle",
				TextColor = ARGB(255,215,232,227),
				HighlightTextColor = ARGB(255, 215 ,232 ,227),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_button_normal.tga", Vector4(14, 14, 14, 14)),
					HoverImage = Gui.Image("LobbyUI/Friends/lb_contact_button_hover.tga", Vector4(14, 14, 14, 14)),
					DownImage = Gui.Image("LobbyUI/Friends/lb_contact_button_down.tga", Vector4(14, 14, 14, 14)),
					DisabledImage = Gui.Image("LobbyUI/Friends/lb_contact_button_normal.tga", Vector4(14, 14, 14, 14)),
				},
				
				EventClick = function()
					--MessageBox.ShowWithConfirmCancel(lang:GetText("还在制作中？"), nil)
					HideFriendsCreateWin()
				end
			},
		},
	},
}

function ShowFriendsCreateWin(win_parent)
	if Create_Friends_Create_ui then
		Create_Friends_Create_ui.ctr_Friends_Create.Parent = win_parent
		AlignUI()
		return
	end
	
	--创建聊天组群框
	Create_Friends_Create_ui = Gui.Create(win_parent)(Create_Frends_Create)
	AlignUI()
end

--好友邀请弹出窗口
local Create_Invited_Win =
{
	Gui.Control "ctr_Invited_Win"
	{
		Size = Vector2(1600, 900),
		BackgroundColor = ARGB(255, 255, 255, 255),
		
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/lb_common_black_bg.dds", Vector4(0, 0, 0, 0)),
		},
		
		Gui.Control
		{
			Size = Vector2(382, 149),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Location = Vector2(605, 390),
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/Friends/lb_chat_bg5.dds", Vector4(3, 3, 3, 8)),
			},
			
			Gui.Control 
			{
				Size = Vector2(156, 136),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Location = Vector2(221, 5),
				
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_tubiao1.dds", Vector4(0, 0, 0, 0)),
				},
			},
			
			Gui.Label"lb_Invited_FriendName"
			{
				Size = Vector2(200, 30),
				Location = Vector2(94, 15),
				TextColor = ARGB(255,52, 50, 50),
				FontSize = 18,
				Text = lang:GetText("输入名称"),
				TextPadding = Vector4(0,0,0,5),
			},
			
			Gui.Label
			{
				Size = Vector2(200, 30),
				Location = Vector2(94, 55),
				TextColor = ARGB(255,52, 50, 50),
				FontSize = 18,
				Text = lang:GetText("加你为好友，是否同意？"),
				AutoSize = true,
				TextPadding = Vector4(0,0,0,5),
			},
			
			--同意
			Gui.Button
			{
				Location = Vector2(59, 94),
				Size = Vector2(93, 31),
				BackgroundColor = ARGB(255,255,255,255),
				Text = lang:GetText("同 意"),
				TextAlign = "kAlignCenterMiddle",
				TextColor = ARGB(255,215,232,227),
				HighlightTextColor = ARGB(255, 215 ,232 ,227),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_button_normal.tga", Vector4(14, 14, 14, 14)),
					HoverImage = Gui.Image("LobbyUI/Friends/lb_contact_button_hover.tga", Vector4(14, 14, 14, 14)),
					DownImage = Gui.Image("LobbyUI/Friends/lb_contact_button_down.tga", Vector4(14, 14, 14, 14)),
					DisabledImage = Gui.Image("LobbyUI/Friends/lb_contact_button_normal.tga", Vector4(14, 14, 14, 14)),
				},
				
				EventClick = function()
					--MessageBox.ShowWithConfirmCancel(lang:GetText("还在制作中？"), nil)
					
					-- pid=人物id(加你的ID)
					-- fid=ID(自己的帐号ID)
					-- type=1好友3自定义群组
					local args = {fid = ptr_cast(game.CurrentState):GetCharacterId(), pid = L_LobbyMain.FriendId, type = 1}
					rpc.safecall("friend_accept",args,function (data) 
													if data.warning then
														MessageBox.ShowWithTimer(1,data.warning)
													else
														MessageBox.ShowWithTimer(1,lang:GetText("好友添加成功！"))
													end
												end)
					L_LobbyMain.FriendAdd = L_LobbyMain.FriendAdd.next
					if L_LobbyMain.FriendAdd ~= nil then
						L_LobbyMain.FriendName = L_LobbyMain.FriendAdd.name
						L_LobbyMain.FriendId = L_LobbyMain.FriendAdd.id
						--L_LobbyMain.FriendAdd = L_LobbyMain.FriendAdd.next
						ShowInvitedCreateWin(gui)
					elseif L_LobbyMain.GroupAdd then
						L_LobbyMain.FriendName = nil
						L_LobbyMain.FriendId = 0
						HIdeInvitedCreateWin()
						L_LobbyMain.GroupAddName = L_LobbyMain.GroupAdd.name
						L_LobbyMain.GroupAddId = L_LobbyMain.GroupAdd.id
						--L_LobbyMain.GroupAdd = L_LobbyMain.GroupAdd.next
						L_Friends.ShowGroupInvitedCreateWin(gui)
					elseif L_LobbyMain.TepGroupAdd then
						L_LobbyMain.FriendName = nil
						L_LobbyMain.FriendId = 0
						HIdeInvitedCreateWin()
						L_LobbyMain.TepGroupAddName = L_LobbyMain.TepGroupAdd.groupname
						L_LobbyMain.TepAddName = L_LobbyMain.TepGroupAdd.name
						L_LobbyMain.TepGroupAddId = L_LobbyMain.TepGroupAdd.group_id
						--L_LobbyMain.TepGroupAdd = L_LobbyMain.TepGroupAdd.next
						L_Friends.ShowTepGroupInvitedCreateWin(gui)
					elseif 1 then
						L_LobbyMain.FriendName = nil
						L_LobbyMain.FriendId = 0
--						L_LobbyMain.LobbyMainWin_Foot.btn_Friends_Invited.Visible = false
						if L_LobbyMain.FriendAdd or L_LobbyMain.GroupAdd or L_LobbyMain.TepGroupAdd then
							L_LobbyMain.LobbyMainWin_Foot.btn_Friends.blink = true
						else
							L_LobbyMain.LobbyMainWin_Foot.btn_Friends.blink = false
						end
						HIdeInvitedCreateWin()
					end
					L_LobbyMain.GetFriendsList()
				end
			},
			
			--取消
			Gui.Button
			{
				Location = Vector2(218, 94),
				Size = Vector2(93, 31),
				BackgroundColor = ARGB(255,255,255,255),
				Text = lang:GetText("取 消"),
				TextAlign = "kAlignCenterMiddle",
				TextColor = ARGB(255,215,232,227),
				HighlightTextColor = ARGB(255, 215 ,232 ,227),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_button_normal.tga", Vector4(14, 14, 14, 14)),
					HoverImage = Gui.Image("LobbyUI/Friends/lb_contact_button_hover.tga", Vector4(14, 14, 14, 14)),
					DownImage = Gui.Image("LobbyUI/Friends/lb_contact_button_down.tga", Vector4(14, 14, 14, 14)),
					DisabledImage = Gui.Image("LobbyUI/Friends/lb_contact_button_normal.tga", Vector4(14, 14, 14, 14)),
				},
				
				EventClick = function()
					--MessageBox.ShowWithConfirmCancel(lang:GetText("还在制作中？"), nil)
					L_LobbyMain.FriendAdd = L_LobbyMain.FriendAdd.next
					if L_LobbyMain.FriendAdd ~= nil then
						L_LobbyMain.FriendName = L_LobbyMain.FriendAdd.name
						L_LobbyMain.FriendId = L_LobbyMain.FriendAdd.id
						--L_LobbyMain.FriendAdd = L_LobbyMain.FriendAdd.next
						ShowInvitedCreateWin(gui)
					elseif L_LobbyMain.GroupAdd then
						L_LobbyMain.FriendName = nil
						L_LobbyMain.FriendId = 0
						HIdeInvitedCreateWin()
						L_LobbyMain.GroupAddName = nil
						L_LobbyMain.GroupAddId = 0
						L_LobbyMain.GroupAddName = L_LobbyMain.GroupAdd.name
						L_LobbyMain.GroupAddId = L_LobbyMain.GroupAdd.id
						--L_LobbyMain.GroupAdd = L_LobbyMain.GroupAdd.next
						L_Friends.ShowGroupInvitedCreateWin(gui)
					elseif L_LobbyMain.TepGroupAdd then
						L_LobbyMain.FriendName = nil
						L_LobbyMain.FriendId = 0
						HIdeInvitedCreateWin()
						L_LobbyMain.TepGroupAddName = L_LobbyMain.TepGroupAdd.groupname
						L_LobbyMain.TepAddName = L_LobbyMain.TepGroupAdd.name
						L_LobbyMain.TepGroupAddId = L_LobbyMain.TepGroupAdd.group_id
						--L_LobbyMain.TepGroupAdd = L_LobbyMain.TepGroupAdd.next
						L_Friends.ShowTepGroupInvitedCreateWin(gui)
					elseif 1 then
						L_LobbyMain.FriendName = nil
						L_LobbyMain.FriendId = 0
--						L_LobbyMain.LobbyMainWin_Foot.btn_Friends_Invited.Visible = false
						if L_LobbyMain.FriendAdd or L_LobbyMain.GroupAdd or L_LobbyMain.TepGroupAdd then
							L_LobbyMain.LobbyMainWin_Foot.btn_Friends.blink = true
						else
							L_LobbyMain.LobbyMainWin_Foot.btn_Friends.blink = false
						end
						HIdeInvitedCreateWin()
					end
				end
			},
		},
	},
}

--创建邀请窗口
function ShowInvitedCreateWin(win_parent)
	if Create_Invited_Win_ui then
		Create_Invited_Win_ui.ctr_Invited_Win.Parent = win_parent
		Create_Invited_Win_ui.lb_Invited_FriendName.Text = L_LobbyMain.FriendName
		AlignUI()
		return
	end
	
	--创建邀请窗口
	Create_Invited_Win_ui = Gui.Create(win_parent)(Create_Invited_Win)
	Create_Invited_Win_ui.lb_Invited_FriendName.Text = L_LobbyMain.FriendName
	AlignUI()
end

--删除邀请窗口
function HIdeInvitedCreateWin()
	if Create_Invited_Win_ui then
		Create_Invited_Win_ui.ctr_Invited_Win.Parent = nil
	end
end

--群组邀请弹出窗口
local Create_GroupInvited_Win =
{
	Gui.Control "ctr_GroupInvited_Win"
	{
		Size = Vector2(1600, 900),
		BackgroundColor = ARGB(255, 255, 255, 255),
		
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/lb_common_black_bg.dds", Vector4(0, 0, 0, 0)),
		},
		Gui.Control 
		{
			Size = Vector2(382, 149),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Location = Vector2(605, 390),
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/Friends/lb_chat_bg5.dds", Vector4(3, 3, 3, 8)),
			},
			
			Gui.Control 
			{
				Size = Vector2(156, 136),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Location = Vector2(221, 5),
				
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_tubiao2.dds", Vector4(0, 0, 0, 0)),
				},
			},
			
			Gui.Label"lb_GroupInvited_FriendName"
			{
				Size = Vector2(300, 30),
				Location = Vector2(55, 15),
				TextColor = ARGB(255,52, 50, 50),
				FontSize = 18,
				Text = lang:GetText("输入名称"),
				TextPadding = Vector4(0,0,0,5),
			},
			
			Gui.Label
			{
				Size = Vector2(300, 30),
				Location = Vector2(55, 55),
				TextColor = ARGB(255,52, 50, 50),
				FontSize = 18,
				Text = lang:GetText("邀请你加入他的群组，是否同意？"),
				TextPadding = Vector4(0,0,0,5),
			},
			
			--同意
			Gui.Button
			{
				Location = Vector2(59, 94),
				Size = Vector2(93, 31),
				BackgroundColor = ARGB(255,255,255,255),
				Text = lang:GetText("同 意"),
				TextAlign = "kAlignCenterMiddle",
				TextColor = ARGB(255,215,232,227),
				HighlightTextColor = ARGB(255, 215 ,232 ,227),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_button_normal.tga", Vector4(14, 14, 14, 14)),
					HoverImage = Gui.Image("LobbyUI/Friends/lb_contact_button_hover.tga", Vector4(14, 14, 14, 14)),
					DownImage = Gui.Image("LobbyUI/Friends/lb_contact_button_down.tga", Vector4(14, 14, 14, 14)),
					DisabledImage = Gui.Image("LobbyUI/Friends/lb_contact_button_normal.tga", Vector4(14, 14, 14, 14)),
				},
				
				EventClick = function()
					-- pid=人物id(加你的ID)
					-- fid=ID(自己的帐号ID)
					-- type=1好友3自定义群组
					local args = {fid = ptr_cast(game.CurrentState):GetCharacterId(), pid = L_LobbyMain.GroupAddId, type = 3}
					rpc.safecall("friend_accept",args,
							function(data)
								if data.warning then
									ShowLeaveOwnGroupCreateWin(gui,data.warning)
								else
									L_LobbyMain.GerGroupList()
								end
							end)
					L_LobbyMain.GroupAdd = L_LobbyMain.GroupAdd.next	
					if L_LobbyMain.GroupAdd ~= nil then
						L_LobbyMain.GroupAddName = L_LobbyMain.GroupAdd.name
						L_LobbyMain.GroupAddId = L_LobbyMain.GroupAdd.id
						--L_LobbyMain.GroupAdd = L_LobbyMain.GroupAdd.next
						ShowGroupInvitedCreateWin(gui)
					elseif L_LobbyMain.TepGroupAdd then
						L_LobbyMain.GroupAddName = nil
						L_LobbyMain.GroupAddId = 0
						HIdeGroupInvitedCreateWin()
						L_LobbyMain.TepGroupAddName = L_LobbyMain.TepGroupAdd.groupname
						L_LobbyMain.TepAddName = L_LobbyMain.TepGroupAdd.name
						L_LobbyMain.TepGroupAddId = L_LobbyMain.TepGroupAdd.group_id
						--L_LobbyMain.TepGroupAdd = L_LobbyMain.TepGroupAdd.next
						L_Friends.ShowTepGroupInvitedCreateWin(gui)
					elseif 1 then
						L_LobbyMain.GroupAddName = nil
						L_LobbyMain.GroupAddId = 0
						if L_LobbyMain.FriendAdd or L_LobbyMain.GroupAdd or L_LobbyMain.TepGroupAdd then
							L_LobbyMain.LobbyMainWin_Foot.btn_Friends.blink = true
						else
							L_LobbyMain.LobbyMainWin_Foot.btn_Friends.blink = false
						end
--						L_LobbyMain.LobbyMainWin_Foot.btn_Grounp_Invited.Visible = false
						HIdeGroupInvitedCreateWin()
					end
				end
			},
			
			--取消
			Gui.Button
			{
				Location = Vector2(218, 94),
				Size = Vector2(93, 31),
				BackgroundColor = ARGB(255,255,255,255),
				Text = lang:GetText("取 消"),
				TextAlign = "kAlignCenterMiddle",
				TextColor = ARGB(255,215,232,227),
				HighlightTextColor = ARGB(255, 215 ,232 ,227),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_button_normal.tga", Vector4(14, 14, 14, 14)),
					HoverImage = Gui.Image("LobbyUI/Friends/lb_contact_button_hover.tga", Vector4(14, 14, 14, 14)),
					DownImage = Gui.Image("LobbyUI/Friends/lb_contact_button_down.tga", Vector4(14, 14, 14, 14)),
					DisabledImage = Gui.Image("LobbyUI/Friends/lb_contact_button_normal.tga", Vector4(14, 14, 14, 14)),
				},
				
				EventClick = function()
					--MessageBox.ShowWithConfirmCancel(lang:GetText("还在制作中？"), nil)
					L_LobbyMain.GroupAdd = L_LobbyMain.GroupAdd.next
					if L_LobbyMain.GroupAdd ~= nil then
						L_LobbyMain.GroupAddName = L_LobbyMain.GroupAdd.name
						L_LobbyMain.GroupAddId = L_LobbyMain.GroupAdd.id
						--L_LobbyMain.GroupAdd = L_LobbyMain.GroupAdd.next
						ShowGroupInvitedCreateWin(gui)
					elseif L_LobbyMain.TepGroupAdd then
						L_LobbyMain.GroupAddName = nil
						L_LobbyMain.GroupAddId = 0
						HIdeGroupInvitedCreateWin()
						L_LobbyMain.TepGroupAddName = L_LobbyMain.TepGroupAdd.groupname
						L_LobbyMain.TepAddName = L_LobbyMain.TepGroupAdd.name
						L_LobbyMain.TepGroupAddId = L_LobbyMain.TepGroupAdd.group_id
						--L_LobbyMain.TepGroupAdd = L_LobbyMain.TepGroupAdd.next
						L_Friends.ShowTepGroupInvitedCreateWin(gui)
					elseif 1 then
						L_LobbyMain.GroupAddName = nil
						L_LobbyMain.GroupAddId = 0
						if L_LobbyMain.FriendAdd or L_LobbyMain.GroupAdd or L_LobbyMain.TepGroupAdd then
							L_LobbyMain.LobbyMainWin_Foot.btn_Friends.blink = true
						else
							L_LobbyMain.LobbyMainWin_Foot.btn_Friends.blink = false
						end
--						L_LobbyMain.LobbyMainWin_Foot.btn_Grounp_Invited.Visible = false
						HIdeGroupInvitedCreateWin()
					end
				end
			},
		},
	},
}

--群组创建邀请窗口
function ShowGroupInvitedCreateWin(win_parent)
	if Create_GroupInvited_Win_ui then
		Create_GroupInvited_Win_ui.ctr_GroupInvited_Win.Parent = win_parent
		Create_GroupInvited_Win_ui.lb_GroupInvited_FriendName.Text = L_LobbyMain.GroupAddName
		AlignUI()
		return
	end
	
	--创建邀请窗口
	Create_GroupInvited_Win_ui = Gui.Create(win_parent)(Create_GroupInvited_Win)
	Create_GroupInvited_Win_ui.lb_GroupInvited_FriendName.Text = L_LobbyMain.GroupAddName
	AlignUI()
end

--删除群组邀请窗口
function HIdeGroupInvitedCreateWin()
	if Create_GroupInvited_Win_ui then
		Create_GroupInvited_Win_ui.ctr_GroupInvited_Win.Parent = nil
	end
end

--临时群组邀请弹出窗口
local Create_TepGroupInvited_Win =
{
	Gui.Control "ctr_TepGroupInvited_Win"
	{
		Size = Vector2(1600, 900),
		BackgroundColor = ARGB(255, 255, 255, 255),
		
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/lb_common_black_bg.dds", Vector4(0, 0, 0, 0)),
		},
		Gui.Control 
		{
			Size = Vector2(382, 149),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Location = Vector2(605, 390),
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/Friends/lb_chat_bg5.dds", Vector4(3, 3, 3, 8)),
			},
			
			Gui.Control 
			{
				Size = Vector2(156, 136),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Location = Vector2(221, 5),
				
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_tubiao2.dds", Vector4(0, 0, 0, 0)),
				},
			},
			
			Gui.Label"lb_TepGroupInvited_FriendName"
			{
				Size = Vector2(200, 30),
				Location = Vector2(55, 15),
				TextColor = ARGB(255,52, 50, 50),
				FontSize = 18,
				Text = lang:GetText("输入名称"),
				--AutoSize = true,
			},
			
			Gui.Label"lb_TepGroupInvited_Text"
			{
				Size = Vector2(200, 30),
				Location = Vector2(55, 55),
				TextColor = ARGB(255,52, 50, 50),
				FontSize = 18,
				Text = lang:GetText("邀请你加入他的群组，是否同意？"),
				AutoSize = true,
			},
			
			--同意
			Gui.Button
			{
				Location = Vector2(59, 94),
				Size = Vector2(93, 31),
				BackgroundColor = ARGB(255,255,255,255),
				Text = lang:GetText("同 意"),
				TextAlign = "kAlignCenterMiddle",
				TextColor = ARGB(255,215,232,227),
				HighlightTextColor = ARGB(255, 215 ,232 ,227),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_button_normal.tga", Vector4(14, 14, 14, 14)),
					HoverImage = Gui.Image("LobbyUI/Friends/lb_contact_button_hover.tga", Vector4(14, 14, 14, 14)),
					DownImage = Gui.Image("LobbyUI/Friends/lb_contact_button_down.tga", Vector4(14, 14, 14, 14)),
					DisabledImage = Gui.Image("LobbyUI/Friends/lb_contact_button_normal.tga", Vector4(14, 14, 14, 14)),
				},
				
				EventClick = function()
					--MessageBox.ShowWithConfirmCancel(lang:GetText("还在制作中？"), nil)
					ptr_cast(game.CurrentState):GroupJoin(L_LobbyMain.TepGroupAddId)
					L_Friends.CreatePrivateChat(L_LobbyMain.TepGroupAddName , 2 , L_LobbyMain.TepGroupAddId)
					L_LobbyMain.TepGroupAdd = L_LobbyMain.TepGroupAdd.next
					if L_LobbyMain.TepGroupAdd ~= nil then
						L_LobbyMain.TepGroupAddName = L_LobbyMain.TepGroupAdd.groupname
						L_LobbyMain.TepAddName = L_LobbyMain.TepGroupAdd.name
						L_LobbyMain.TepGroupAddId = L_LobbyMain.TepGroupAdd.group_id
						--L_LobbyMain.TepGroupAdd = L_LobbyMain.TepGroupAdd.next
						ShowTepGroupInvitedCreateWin(gui)
					else
						L_LobbyMain.TepGroupAddName = nil
						L_LobbyMain.TepAddName = nil
						L_LobbyMain.TepGroupAddId = 0
						if L_LobbyMain.FriendAdd or L_LobbyMain.GroupAdd or L_LobbyMain.TepGroupAdd then
							L_LobbyMain.LobbyMainWin_Foot.btn_Friends.blink = true
						else
							L_LobbyMain.LobbyMainWin_Foot.btn_Friends.blink = false
						end
--						L_LobbyMain.LobbyMainWin_Foot.btn_Grounp_Invited.Visible = false
						HIdeTepGroupInvitedCreateWin()
					end
				end
			},
			
			--取消
			Gui.Button
			{
				Location = Vector2(218, 94),
				Size = Vector2(93, 31),
				BackgroundColor = ARGB(255,255,255,255),
				Text = lang:GetText("取 消"),
				TextAlign = "kAlignCenterMiddle",
				TextColor = ARGB(255,215,232,227),
				HighlightTextColor = ARGB(255, 215 ,232 ,227),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_button_normal.tga", Vector4(14, 14, 14, 14)),
					HoverImage = Gui.Image("LobbyUI/Friends/lb_contact_button_hover.tga", Vector4(14, 14, 14, 14)),
					DownImage = Gui.Image("LobbyUI/Friends/lb_contact_button_down.tga", Vector4(14, 14, 14, 14)),
					DisabledImage = Gui.Image("LobbyUI/Friends/lb_contact_button_normal.tga", Vector4(14, 14, 14, 14)),
				},
				
				EventClick = function()
					--MessageBox.ShowWithConfirmCancel(lang:GetText("还在制作中？"), nil)
					L_LobbyMain.TepGroupAdd = L_LobbyMain.TepGroupAdd.next
					if L_LobbyMain.TepGroupAdd ~= nil then
						L_LobbyMain.TepGroupAddName = L_LobbyMain.TepGroupAdd.groupname
						L_LobbyMain.TepAddName = L_LobbyMain.TepGroupAdd.name
						L_LobbyMain.TepGroupAddId = L_LobbyMain.TepGroupAdd.group_id
						--L_LobbyMain.TepGroupAdd = L_LobbyMain.TepGroupAdd.next
						ShowTepGroupInvitedCreateWin(gui)
					else
						L_LobbyMain.TepGroupAddName = nil
						L_LobbyMain.TepAddName = nil
						L_LobbyMain.TepGroupAddId = 0
						if L_LobbyMain.FriendAdd or L_LobbyMain.GroupAdd or L_LobbyMain.TepGroupAdd then
							L_LobbyMain.LobbyMainWin_Foot.btn_Friends.blink = true
						else
							L_LobbyMain.LobbyMainWin_Foot.btn_Friends.blink = false
						end
--						L_LobbyMain.LobbyMainWin_Foot.btn_Grounp_Invited.Visible = false
						HIdeTepGroupInvitedCreateWin()
					end
				end
			},
		},
	},
}

--临时群组创建邀请窗口
function ShowTepGroupInvitedCreateWin(win_parent)
	if Create_TepGroupInvited_Win_ui then
		Create_TepGroupInvited_Win_ui.ctr_TepGroupInvited_Win.Parent = win_parent
		Create_TepGroupInvited_Win_ui.lb_TepGroupInvited_FriendName.Text = L_LobbyMain.TepAddName
		Create_TepGroupInvited_Win_ui.lb_TepGroupInvited_Text.Text = lang:GetText("邀请你加入临时群组，是否同意？")
		AlignUI()
		return
	end
	
	--创建邀请窗口
	Create_TepGroupInvited_Win_ui = Gui.Create(win_parent)(Create_TepGroupInvited_Win)
	Create_TepGroupInvited_Win_ui.lb_TepGroupInvited_FriendName.Text = L_LobbyMain.TepAddName
	Create_TepGroupInvited_Win_ui.lb_TepGroupInvited_Text.Text = lang:GetText("邀请你加入临时群组，是否同意？")
	AlignUI()
end

--删除临时群组邀请窗口
function HIdeTepGroupInvitedCreateWin()
	if Create_TepGroupInvited_Win_ui then
		Create_TepGroupInvited_Win_ui.ctr_TepGroupInvited_Win.Parent = nil
	end
end

--退出群组确定窗口
local Create_LeaveGroup_Win =
{
	Gui.Control "ctr_LeaveGroup_Win"
	{
		Size = Vector2(1600, 900),
		BackgroundColor = ARGB(255, 255, 255, 255),
		
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/lb_common_black_bg.dds", Vector4(0, 0, 0, 0)),
		},

		Gui.Control
		{
			Size = Vector2(382, 149),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Location = Vector2(605, 390),
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/Friends/lb_chat_bg5.dds", Vector4(3, 3, 3, 8)),
			},
			
			Gui.Label"lb_LeaveGroup_FriendName"
			{
				Size = Vector2(382, 30),
				Location = Vector2(0, 15),
				TextColor = ARGB(255,52, 50, 50),
				FontSize = 18,
				Text = lang:GetText("输入名称"),
				TextAlign = "kAlignCenterMiddle",
				TextPadding = Vector4(0,0,0,5),
			},
			
			Gui.Label
			{
				Size = Vector2(382, 30),
				Location = Vector2(0, 55),
				TextColor = ARGB(255,52, 50, 50),
				FontSize = 18,
				Text = lang:GetText("是否确定退出当前群组！"),
				TextAlign = "kAlignCenterMiddle",
				TextPadding = Vector4(0,0,0,5),
			},
			
			--确定
			Gui.Button
			{
				Location = Vector2(59, 94),
				Size = Vector2(93, 31),
				BackgroundColor = ARGB(255,255,255,255),
				Text = lang:GetText("确 定"),
				TextAlign = "kAlignCenterMiddle",
				TextColor = ARGB(255,215,232,227),
				HighlightTextColor = ARGB(255, 215 ,232 ,227),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_button_normal.tga", Vector4(14, 14, 14, 14)),
					HoverImage = Gui.Image("LobbyUI/Friends/lb_contact_button_hover.tga", Vector4(14, 14, 14, 14)),
					DownImage = Gui.Image("LobbyUI/Friends/lb_contact_button_down.tga", Vector4(14, 14, 14, 14)),
					DisabledImage = Gui.Image("LobbyUI/Friends/lb_contact_button_normal.tga", Vector4(14, 14, 14, 14)),
				},
				
				EventClick = function()
					--MessageBox.ShowWithConfirmCancel(lang:GetText("还在制作中？"), nil)
					HIdeLeaveGroupCreateWin()
					LeaveGroup()
					HideChatInfo(leaveName,3)
				end
			},
			
			--取消
			Gui.Button
			{
				Location = Vector2(218, 94),
				Size = Vector2(93, 31),
				BackgroundColor = ARGB(255,255,255,255),
				Text = lang:GetText("取 消"),
				TextAlign = "kAlignCenterMiddle",
				TextColor = ARGB(255,215,232,227),
				HighlightTextColor = ARGB(255, 215 ,232 ,227),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_button_normal.tga", Vector4(14, 14, 14, 14)),
					HoverImage = Gui.Image("LobbyUI/Friends/lb_contact_button_hover.tga", Vector4(14, 14, 14, 14)),
					DownImage = Gui.Image("LobbyUI/Friends/lb_contact_button_down.tga", Vector4(14, 14, 14, 14)),
					DisabledImage = Gui.Image("LobbyUI/Friends/lb_contact_button_normal.tga", Vector4(14, 14, 14, 14)),
				},
				
				EventClick = function()
					--MessageBox.ShowWithConfirmCancel(lang:GetText("还在制作中？"), nil)
					HIdeLeaveGroupCreateWin()
				end
			},
		},
	},
}

--退出群组确认窗口
function ShowLeaveGroupCreateWin(win_parent,Name)
	LeaveGroupName = Name
	if Create_LeaveGroup_Win_ui then
		Create_LeaveGroup_Win_ui.ctr_LeaveGroup_Win.Parent = win_parent
		Create_LeaveGroup_Win_ui.lb_LeaveGroup_FriendName.Text = Name..lang:GetText(" 群")
		AlignUI()
		return
	end
	
	--创建邀请窗口
	Create_LeaveGroup_Win_ui = Gui.Create(win_parent)(Create_LeaveGroup_Win)
	Create_LeaveGroup_Win_ui.lb_LeaveGroup_FriendName.Text = Name..lang:GetText(" 群")
	AlignUI()
end

--删除退出群组窗口
function HIdeLeaveGroupCreateWin()
	if Create_LeaveGroup_Win_ui then
		Create_LeaveGroup_Win_ui.ctr_LeaveGroup_Win.Parent = nil
	end
	LeaveGroupName = nil
end

--踢出群组确定窗口
local Create_KickingGroup_Win =
{
	Gui.Control "ctr_KickingGroup_Win"
	{
		Size = Vector2(1600, 900),
		BackgroundColor = ARGB(255, 255, 255, 255),
		
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/lb_common_black_bg.dds", Vector4(0, 0, 0, 0)),
		},
		
		Gui.Control
		{
			Size = Vector2(400, 149),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Location = Vector2(596, 390),
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/Friends/lb_chat_bg5.dds", Vector4(3, 3, 3, 8)),
			},
			
			Gui.Label"lb_KickingGroup_FriendName"
			{
				Size = Vector2(400, 30),
				Location = Vector2(0, 15),
				TextColor = ARGB(255,52, 50, 50),
				FontSize = 18,
				Text = lang:GetText("输入名称"),
				TextAlign = "kAlignCenterMiddle",
				TextPadding = Vector4(0,0,0,5),
			},
			
			Gui.Label
			{
				Size = Vector2(400, 30),
				Location = Vector2(0, 55),
				TextColor = ARGB(255,52, 50, 50),
				FontSize = 18,
				Text = lang:GetText("是否将此人踢出聊天群！"),
				TextAlign = "kAlignCenterMiddle",
				TextPadding = Vector4(0,0,0,5),
			},
			
			--确定
			Gui.Button
			{
				Location = Vector2(64, 94),
				Size = Vector2(93, 31),
				BackgroundColor = ARGB(255,255,255,255),
				Text = lang:GetText("确 定"),
				TextAlign = "kAlignCenterMiddle",
				TextColor = ARGB(255,215,232,227),
				HighlightTextColor = ARGB(255, 215 ,232 ,227),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_button_normal.tga", Vector4(14, 14, 14, 14)),
					HoverImage = Gui.Image("LobbyUI/Friends/lb_contact_button_hover.tga", Vector4(14, 14, 14, 14)),
					DownImage = Gui.Image("LobbyUI/Friends/lb_contact_button_down.tga", Vector4(14, 14, 14, 14)),
					DisabledImage = Gui.Image("LobbyUI/Friends/lb_contact_button_normal.tga", Vector4(14, 14, 14, 14)),
				},
				
				EventClick = function()
					--MessageBox.ShowWithConfirmCancel(lang:GetText("还在制作中？"), nil)
					HIdeKickingGroupCreateWin()
					KickingGroupMember()
					--L_LobbyMain.GerGroupList()
					--HideChatManyPeople(leavenum)
				end
			},
			
			--取消
			Gui.Button
			{
				Location = Vector2(223, 94),
				Size = Vector2(93, 31),
				BackgroundColor = ARGB(255,255,255,255),
				Text = lang:GetText("取 消"),
				TextAlign = "kAlignCenterMiddle",
				TextColor = ARGB(255,215,232,227),
				HighlightTextColor = ARGB(255, 215 ,232 ,227),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_button_normal.tga", Vector4(14, 14, 14, 14)),
					HoverImage = Gui.Image("LobbyUI/Friends/lb_contact_button_hover.tga", Vector4(14, 14, 14, 14)),
					DownImage = Gui.Image("LobbyUI/Friends/lb_contact_button_down.tga", Vector4(14, 14, 14, 14)),
					DisabledImage = Gui.Image("LobbyUI/Friends/lb_contact_button_normal.tga", Vector4(14, 14, 14, 14)),
				},
				
				EventClick = function()
					--MessageBox.ShowWithConfirmCancel(lang:GetText("还在制作中？"), nil)
					HIdeKickingGroupCreateWin()
				end
			},
		},
	},
}

--踢出群组确认窗口
function ShowKickingGroupCreateWin(win_parent)
	if Create_KickingGroup_Win_ui then
		Create_KickingGroup_Win_ui.ctr_KickingGroup_Win.Parent = win_parent
		Create_KickingGroup_Win_ui.lb_KickingGroup_FriendName.Text = L_LobbyMain.KickingGroupMemberName
		AlignUI()
		return
	end
	
	--创建邀请窗口
	Create_KickingGroup_Win_ui = Gui.Create(win_parent)(Create_KickingGroup_Win)
	Create_KickingGroup_Win_ui.lb_KickingGroup_FriendName.Text = L_LobbyMain.KickingGroupMemberName
	AlignUI()
end

--删除踢出群组窗口
function HIdeKickingGroupCreateWin()
	if Create_KickingGroup_Win_ui then
		Create_KickingGroup_Win_ui.ctr_KickingGroup_Win.Parent = nil
	end
end

--删除好友确定窗口
local Create_DeleteFriend_Win =
{
	Gui.Control "ctr_DeleteFriend_Win"
	{
		Size = Vector2(1600, 900),
		BackgroundColor = ARGB(255, 255, 255, 255),
		
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/lb_common_black_bg.dds", Vector4(0, 0, 0, 0)),
		},
		
		Gui.Control
		{
			Size = Vector2(382, 149),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Location = Vector2(605, 390),
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/Friends/lb_chat_bg5.dds", Vector4(3, 3, 3, 8)),
			},
			
			Gui.Label"lb_DeleteFriend_FriendName"
			{
				Size = Vector2(360, 30),
				Location = Vector2(14, 15),
				TextColor = ARGB(255,52, 50, 50),
				FontSize = 18,
				Text = lang:GetText("输入名称"),
				TextAlign = "kAlignCenterMiddle",
				TextPadding = Vector4(0,0,0,5),
			},
			
			Gui.Label
			{
				Size = Vector2(360, 30),
				Location = Vector2(14, 55),
				TextColor = ARGB(255,52, 50, 50),
				FontSize = 18,
				Text = lang:GetText("是否确定删除当前好友！"),
				TextAlign = "kAlignCenterMiddle",
				TextPadding = Vector4(0,0,0,5),
			},
			
			--确定
			Gui.Button
			{
				Location = Vector2(59, 94),
				Size = Vector2(93, 31),
				BackgroundColor = ARGB(255,255,255,255),
				Text = lang:GetText("确 定"),
				TextAlign = "kAlignCenterMiddle",
				TextColor = ARGB(255,215,232,227),
				HighlightTextColor = ARGB(255, 215 ,232 ,227),
				Padding = Vector4(0, 0, 0, 3),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_button_normal.tga", Vector4(14, 14, 14, 14)),
					HoverImage = Gui.Image("LobbyUI/Friends/lb_contact_button_hover.tga", Vector4(14, 14, 14, 14)),
					DownImage = Gui.Image("LobbyUI/Friends/lb_contact_button_down.tga", Vector4(14, 14, 14, 14)),
					DisabledImage = Gui.Image("LobbyUI/Friends/lb_contact_button_normal.tga", Vector4(14, 14, 14, 14)),
				},
				
				EventClick = function()
					local line = 1
					for _,v in ipairs(L_LobbyMain.Friends_rpc_data) do
						if v[3] == Create_DeleteFriend_Win_ui.lb_DeleteFriend_FriendName.Text then
							break
						end
						line = line + 1
					end
					if L_LobbyMain.Friends_rpc_data[line] then
						local args = {pid = ptr_cast(game.CurrentState):GetCharacterId(), action = "delete", id = L_LobbyMain.Friends_rpc_data[line][1] , name =L_LobbyMain.Friends_rpc_data[line][3]}
						rpc.safecall("friends_menu",args,nil,function () L_MessageBox.CloseWaiter() end)
					end
					HIdeDeleteFriendCreateWin()
				end
			},
			
			--取消
			Gui.Button
			{
				Location = Vector2(218, 94),
				Size = Vector2(93, 31),
				BackgroundColor = ARGB(255,255,255,255),
				Text = lang:GetText("取 消"),
				TextAlign = "kAlignCenterMiddle",
				TextColor = ARGB(255,215,232,227),
				HighlightTextColor = ARGB(255, 215 ,232 ,227),
				Padding = Vector4(0, 0, 0, 3),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_button_normal.tga", Vector4(14, 14, 14, 14)),
					HoverImage = Gui.Image("LobbyUI/Friends/lb_contact_button_hover.tga", Vector4(14, 14, 14, 14)),
					DownImage = Gui.Image("LobbyUI/Friends/lb_contact_button_down.tga", Vector4(14, 14, 14, 14)),
					DisabledImage = Gui.Image("LobbyUI/Friends/lb_contact_button_normal.tga", Vector4(14, 14, 14, 14)),
				},
				
				EventClick = function()
					--MessageBox.ShowWithConfirmCancel(lang:GetText("还在制作中？"), nil)
					HIdeDeleteFriendCreateWin()
				end
			},
		},
	},
}

--创建删除好友确认窗口
function ShowDeleteFriendCreateWin(win_parent,VText)
	if Create_DeleteFriend_Win_ui then
		Create_DeleteFriend_Win_ui.ctr_DeleteFriend_Win.Parent = win_parent
		Create_DeleteFriend_Win_ui.lb_DeleteFriend_FriendName.Text = VText
		AlignUI()
		return
	end
	
	--创建邀请窗口
	Create_DeleteFriend_Win_ui = Gui.Create(win_parent)(Create_DeleteFriend_Win)
	Create_DeleteFriend_Win_ui.lb_DeleteFriend_FriendName.Text = VText
	AlignUI()
end

--删除好友确认窗口
function HIdeDeleteFriendCreateWin()
	if Create_DeleteFriend_Win_ui then
		Create_DeleteFriend_Win_ui.ctr_DeleteFriend_Win.Parent = nil
	end
end

local Create_LeaveOwnGroup_Win =
{
	Gui.Control "ctr_LeaveOwnGroup_Win"
	{
		Size = Vector2(1200, 900),
		BackgroundColor = ARGB(0, 255, 255, 255),		
		
		Gui.Control
		{
			Size = Vector2(382, 149),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Dock = "kDockCenter",
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/Friends/lb_chat_bg5.dds", Vector4(3, 3, 3, 8)),
			},
			
			Gui.Control 
			{
				Size = Vector2(156, 136),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Location = Vector2(221, 5),
				
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_tubiao5.dds", Vector4(0, 0, 0, 0)),
				},
			},
			
			Gui.Label "btn_LeaveOwnGroup"
			{
				Size = Vector2(350, 60),
				Location = Vector2(16, 30),
				BackgroundColor = ARGB(0, 255, 255, 255),
				TextColor = ARGB(255,52, 50, 50),
				FontSize = 18,
				Text = "",
				TextAlign = "kAlignCenterMiddle",
				AutoWrap = true,
			},
			
			--确定
			Gui.Button
			{
				Location = Vector2(145, 94),
				Size = Vector2(93, 31),
				BackgroundColor = ARGB(255,255,255,255),
				Text = lang:GetText("确 定"),
				TextAlign = "kAlignCenterMiddle",
				TextColor = ARGB(255,215,232,227),
				HighlightTextColor = ARGB(255, 215 ,232 ,227),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_button_normal.tga", Vector4(14, 14, 14, 14)),
					HoverImage = Gui.Image("LobbyUI/Friends/lb_contact_button_hover.tga", Vector4(14, 14, 14, 14)),
					DownImage = Gui.Image("LobbyUI/Friends/lb_contact_button_down.tga", Vector4(14, 14, 14, 14)),
					DisabledImage = Gui.Image("LobbyUI/Friends/lb_contact_button_normal.tga", Vector4(14, 14, 14, 14)),
				},
				
				EventClick = function()
					--MessageBox.ShowWithConfirmCancel(lang:GetText("还在制作中？"), nil)
					HIdeLeaveOwnGroupCreateWin()
				end
			},
			
		},
	},
}

--确认窗口
function ShowLeaveOwnGroupCreateWin(win_parent,Vtext)
	if Create_LeaveOwnGroup_Win_ui == nil then
		Create_LeaveOwnGroup_Win_ui = Gui.Create()(Create_LeaveOwnGroup_Win)
		--快速购买界面初始化
		Create_LeaveOwnGroup_Window = ModalWindow.GetNew("Create_LeaveOwnGroup_Win_ui")
		Create_LeaveOwnGroup_Window.screen.AllowEscToExit = false
		Create_LeaveOwnGroup_Window.screen.Visible = false
		--Create_LeaveOwnGroup_Window.screen.EventEscPressed = HideCharmBottleWin
		Create_LeaveOwnGroup_Window.screen.EventEscPressed = nil
		Create_LeaveOwnGroup_Window.root.Size = Vector2(1200, 900)
		Create_LeaveOwnGroup_Win_ui.ctr_LeaveOwnGroup_Win.Parent = Create_LeaveOwnGroup_Window.root
	end
	if Vtext then
		Create_LeaveOwnGroup_Win_ui.btn_LeaveOwnGroup.Text = Vtext
	end
	if Create_LeaveOwnGroup_Window and Create_LeaveOwnGroup_Window.screen then
		Create_LeaveOwnGroup_Window.screen.Visible = true
		--gui.EventEscPressed = HideCharmBottleWin
		gui.EventEscPressed = nil
	end
end

--删除窗口
function HIdeLeaveOwnGroupCreateWin()
	if Create_LeaveOwnGroup_Window and Create_LeaveOwnGroup_Window.screen then
		Create_LeaveOwnGroup_Window.screen.Visible = false
		Create_LeaveOwnGroup_Win_ui = nil
		Create_LeaveOwnGroup_Window:Close()
	end
end

--添加群组成员窗口
local Create_Group_AddMembers =
{
	Gui.Control "ctr_Group_AddMembers"
	{
		Size = Vector2(1600, 900),
		BackgroundColor = ARGB(255, 255, 255, 255),
		
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/lb_common_black_bg.dds", Vector4(0, 0, 0, 0)),
		},

		Gui.Control
		{
			Size = Vector2(273, 309),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Dock = "kDockCenter",
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_bg1.dds", Vector4(28, 28, 28, 28)),
			},
			
			Gui.Control 
			{
				Size = Vector2(20, 20),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Location = Vector2(11, 15),
				
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_ico1.dds", Vector4(0, 0, 0, 0)),
				},
			},
			
			Gui.Label "lbl_Group_AddMembers"
			{
				Size = Vector2(220, 24),
				Location = Vector2(30, 12),
				TextColor = ARGB(255,52, 50, 50),
				TextAlign = "kAlignCenterMiddle",
				FontSize = 14,
				BackgroundColor = ARGB(0, 255, 255, 255),
				Text = "",
--				AutoSize = true,
			},
			
			Gui.Control 
			{
				Size = Vector2(257, 260),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Location = Vector2(8, 38),
				
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_bg2.dds", Vector4(21, 25, 21, 46)),
				},
				
				--好友	
				Gui.Button "btn_Group_AddMembers_Friend"
				{
					Location = Vector2(6, 8),
					Size = Vector2(244, 32),
					BackgroundColor = ARGB(255,255,255,255),
					TextColor = ARGB(255, 37, 37, 37),
					FontSize = 14,
					Text = lang:GetText("好 友"),
					HighlightTextColor = ARGB(255, 37, 37, 37),
					TextAlign = "kAlignLeftMiddle",
					Padding = Vector4(28, 0, 0, 3),
					
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_tab2_normal.dds", Vector4(23, 6, 9, 5)),
						HoverImage = Gui.Image("LobbyUI/Friends/lb_contact_tab2_hover.dds", Vector4(23, 6, 9, 5)),
						DownImage = Gui.Image("LobbyUI/Friends/lb_contact_tab2_down.dds", Vector4(23, 6, 9, 5)),
						DisabledImage = Gui.Image("LobbyUI/Friends/lb_contact_tab2_normal.dds", Vector4(23, 6, 9, 5)),
					},
					EventClick = function()
						--MessageBox.ShowWithConfirmCancel(lang:GetText("还在制作中？"), nil)
						TebGroupAddList(1)
					end,
					
--[[					Gui.Label "lb_Group_AddMembers_Friend"
					{
						Size = Vector2(80, 32),
						Location = Vector2(114, 0),
						TextColor = ARGB(255, 37, 37, 37),
						FontSize = 14,
						TextAlign = "kAlignRightMiddle",
						Text = "(50/50)",
						BackgroundColor = ARGB(0,255,255,255),
	--					AutoSize = true,
					},]]
				},
				
				--陌生人	
				Gui.Button "btn_Group_AddMembers_Stranger"
				{					
					Size = Vector2(244, 32),
					BackgroundColor = ARGB(255,255,255,255),
					TextColor = ARGB(255, 37, 37, 37),
					FontSize = 14,
					Text = lang:GetText("伙 伴"),
					HighlightTextColor = ARGB(255, 37, 37, 37),
					TextAlign = "kAlignLeftMiddle",
					Padding = Vector4(28, 0, 0, 3),
					
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_tab2_normal.dds", Vector4(23, 6, 9, 5)),
						HoverImage = Gui.Image("LobbyUI/Friends/lb_contact_tab2_hover.dds", Vector4(23, 6, 9, 5)),
						DownImage = Gui.Image("LobbyUI/Friends/lb_contact_tab2_down.dds", Vector4(23, 6, 9, 5)),
						DisabledImage = Gui.Image("LobbyUI/Friends/lb_contact_tab2_normal.dds", Vector4(23, 6, 9, 5)),
					},
					EventClick = function()
						--MessageBox.ShowWithConfirmCancel(lang:GetText("还在制作中？"), nil)
						TebGroupAddList(0)
					end,
					
--[[					Gui.Label "lb_Group_AddMembers_Stranger"
					{
						Size = Vector2(80, 32),
						Location = Vector2(114, 0),
						TextColor = ARGB(255, 37, 37, 37),
						FontSize = 14,
						TextAlign = "kAlignRightMiddle",
						Text = "(50/50)",
						BackgroundColor = ARGB(0,255,255,255),
	--					AutoSize = true,
					},]]
				},
				
				--列表好友
				Gui.ListTreeView "list_Group_AddMembers_info_Friend"
				{
					Location = Vector2(8, 39),
					Size = Vector2(236, 144),
					Style = "Gui.ListTreeViewWith_VScroll_Channl",
					HeaderVisible = false,
					CheckIndex = 0,
					
					ItemHeight = 28,
					FontSize = 14,
					TextColor = ARGB(255, 37, 37, 37),
					VScrollBarDisplay = "kVisible",
					VScrollBarWidth = 8,
					VScrollBarButtonSize = 1,
					HScrollBarWidth = 8,
					VScrollBarPos = Vector2(0, 0),
					EventCheckChanged = function (sender, e)
						local item = sender.SelectedItem
						local TepNum = 50 - GetAddMemberNumbers(Create_Group_AddMembers_ui.list_Group_AddMembers_info_Friend , Create_Group_AddMembers_ui.list_Group_AddMembers_info_stranger) - GetMyGroupMembers()
						if TepNum < 0 then
							item.Check = false
							return
						end
						Create_Group_AddMembers_ui.lbl_Group_AddMembers.Text = lang:GetText("你还可以添加")..TepNum..lang:GetText("个参与者")
					end,
					
--[[					EventClick = function(sender, e)
						local item = sender.SelectedItem
						if item == nil then
							return
						end
						item.Check = not item.Check
						local TepNum = 50 - GetAddMemberNumbers(Create_Group_AddMembers_ui.list_Group_AddMembers_info_Friend , Create_Group_AddMembers_ui.list_Group_AddMembers_info_stranger) - GetMyGroupMembers()
						if TepNum < 0 then
							item.Check = false
							return
						end
						Create_Group_AddMembers_ui.lbl_Group_AddMembers.Text = lang:GetText("你还可以添加")..TepNum..lang:GetText("个参与者")
					end,]]
				},
				
				--列表陌生人
				Gui.ListTreeView "list_Group_AddMembers_info_stranger"
				{
					Location = Vector2(8, 71),
					Size = Vector2(236, 144),
					Style = "Gui.ListTreeViewWith_VScroll_Channl",
					HeaderVisible = false,
					CheckIndex = 0,
					
					ItemHeight = 28,
					FontSize = 14,
					TextColor = ARGB(255, 37, 37, 37),
					VScrollBarDisplay = "kVisible",
					VScrollBarWidth = 8,
					VScrollBarButtonSize = 1,
					HScrollBarWidth = 8,
					VScrollBarPos = Vector2(0, 0),
					EventCheckChanged = function (sender, e)
						local item = sender.SelectedItem
						local TepNum = 50 - GetAddMemberNumbers(Create_Group_AddMembers_ui.list_Group_AddMembers_info_Friend , Create_Group_AddMembers_ui.list_Group_AddMembers_info_stranger) - GetMyGroupMembers()
						if TepNum < 0 then
							item.Check = false
							return
						end
						Create_Group_AddMembers_ui.lbl_Group_AddMembers.Text = lang:GetText("你还可以添加")..TepNum..lang:GetText("个参与者")
					end,
					
--[[					EventClick = function(sender, e)
						local item = sender.SelectedItem
						if item == nil then
							return
						end
						item.Check = not item.Check
						local TepNum = 50 - GetAddMemberNumbers(Create_Group_AddMembers_ui.list_Group_AddMembers_info_Friend , Create_Group_AddMembers_ui.list_Group_AddMembers_info_stranger) - GetMyGroupMembers()
						if TepNum < 0 then
							item.Check = false
							return
						end
						Create_Group_AddMembers_ui.lbl_Group_AddMembers.Text = lang:GetText("你还可以添加")..TepNum..lang:GetText("个参与者")
					end,]]
				},
			
				--确定
				Gui.Button
				{
					Location = Vector2(22, 218),
					Size = Vector2(85, 36),
					BackgroundColor = ARGB(255,255,255,255),
					Text = lang:GetText("确 定"),
					TextAlign = "kAlignCenterMiddle",
					TextColor = ARGB(255,215,232,227),
					HighlightTextColor = ARGB(255, 215 ,232 ,227),
					Padding = Vector4(0, 0, 0, 3),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_button_normal.tga", Vector4(14, 14, 14, 14)),
						HoverImage = Gui.Image("LobbyUI/Friends/lb_contact_button_hover.tga", Vector4(14, 14, 14, 14)),
						DownImage = Gui.Image("LobbyUI/Friends/lb_contact_button_down.tga", Vector4(14, 14, 14, 14)),
						DisabledImage = Gui.Image("LobbyUI/Friends/lb_contact_button_normal.tga", Vector4(14, 14, 14, 14)),
					},
					EventClick = function()
						--MessageBox.ShowWithConfirmCancel(lang:GetText("还在制作中？"), nil)
						if GroupListScan(Create_Group_AddMembers_ui.list_Group_AddMembers_info_Friend , Create_Group_AddMembers_ui.list_Group_AddMembers_info_stranger) == false then
							return
						end
						HideChatChoose()
					end
				},
				
				--取消退出
				Gui.Button
				{
					Location = Vector2(150, 218),
					Size = Vector2(85, 36),
					BackgroundColor = ARGB(255,255,255,255),
					Text = lang:GetText("取消"),
					TextAlign = "kAlignCenterMiddle",
					TextColor = ARGB(255,215,232,227),
					HighlightTextColor = ARGB(255, 215 ,232 ,227),
					Padding = Vector4(0, 0, 0, 3),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_button_normal.tga", Vector4(14, 14, 14, 14)),
						HoverImage = Gui.Image("LobbyUI/Friends/lb_contact_button_hover.tga", Vector4(14, 14, 14, 14)),
						DownImage = Gui.Image("LobbyUI/Friends/lb_contact_button_down.tga", Vector4(14, 14, 14, 14)),
						DisabledImage = Gui.Image("LobbyUI/Friends/lb_contact_button_normal.tga", Vector4(14, 14, 14, 14)),
					},
					EventClick = function()
						HideChatChoose()
					end
				},
			},
		},
	},
}

function ShowGroupAddWin(win_parent)
	if Create_Group_AddMembers_ui then
		Create_Group_AddMembers_ui.ctr_Group_AddMembers.Parent = win_parent
--		L_LobbyMain.GroupUpdata()
		local TepNum = 50 - GetMyGroupMembers()
		Create_Group_AddMembers_ui.lbl_Group_AddMembers.Text = lang:GetText("你还可以添加")..TepNum..lang:GetText("个参与者")
		Create_Group_AddMembers_ui.list_Group_AddMembers_info_Friend:DeleteColumns()
		Create_Group_AddMembers_ui.list_Group_AddMembers_info_Friend:AddColumn("", 230, "kAlignCenterMiddle")
		Create_Group_AddMembers_ui.list_Group_AddMembers_info_stranger:DeleteColumns()
		Create_Group_AddMembers_ui.list_Group_AddMembers_info_stranger:AddColumn("", 230, "kAlignCenterMiddle")
		AlignUI()
		return
	end
	
	--创建多人聊天好友选择框
	Create_Group_AddMembers_ui = Gui.Create(win_parent)(Create_Group_AddMembers)
--	L_LobbyMain.GroupUpdata()
	local TepNum = 50 - GetMyGroupMembers()
	Create_Group_AddMembers_ui.lbl_Group_AddMembers.Text = lang:GetText("你还可以添加")..TepNum..lang:GetText("个参与者")
	Create_Group_AddMembers_ui.list_Group_AddMembers_info_Friend:DeleteColumns()
	Create_Group_AddMembers_ui.list_Group_AddMembers_info_Friend:AddColumn("", 230, "kAlignCenterMiddle")
	Create_Group_AddMembers_ui.list_Group_AddMembers_info_stranger:DeleteColumns()
	Create_Group_AddMembers_ui.list_Group_AddMembers_info_stranger:AddColumn("", 230, "kAlignCenterMiddle")
	AlignUI()
end

function TebGroupAddList(which)
	if which == 1 then
		Create_Group_AddMembers_ui.btn_Group_AddMembers_Friend.PushDown = true
		Create_Group_AddMembers_ui.btn_Group_AddMembers_Stranger.PushDown = false
		Create_Group_AddMembers_ui.btn_Group_AddMembers_Stranger.Location = Vector2(6, 182)
		--Create_Group_AddMembers_ui.list_Group_AddMembers_info_Friend.Location = Vector2(9, 69)
		Create_Group_AddMembers_ui.list_Group_AddMembers_info_stranger.Visible = false
		Create_Group_AddMembers_ui.list_Group_AddMembers_info_Friend.Visible = true
		
	else
		Create_Group_AddMembers_ui.btn_Group_AddMembers_Friend.PushDown = false
		Create_Group_AddMembers_ui.btn_Group_AddMembers_Stranger.PushDown = true
		Create_Group_AddMembers_ui.btn_Group_AddMembers_Stranger.Location = Vector2(6, 38)
		--Create_Group_AddMembers_ui.list_Group_AddMembers_info.Location = Vector2(9, 95)
		Create_Group_AddMembers_ui.list_Group_AddMembers_info_stranger.Visible = true
		Create_Group_AddMembers_ui.list_Group_AddMembers_info_Friend.Visible = false
		
	end	
end

function GetAddMemberNumbers(list,listNext)
	local AddNumber = 0
	local item = list.RootItem.FirstChild
	local click = nil
	while item do
		if item.Check then
			AddNumber = AddNumber + 1
			click = {next = click , name = item:GetText(0)}
		end
		item = item.Next
	end
	if listNext then
		local item = listNext.RootItem.FirstChild
		while item do
			if item.Check then			
				AddNumber = AddNumber + CompareName(click,item:GetText(0))
			end
			item = item.Next
		end
	end
	return AddNumber
end

function CompareName(click,name)
	local l = click
	while l do
		if l.name == name then
			return 0
		end
		l = l.next
	end
	return 1
end

function GetMyGroupMembers()
	local MemberNum = 0
	for _,v in ipairs(L_LobbyMain.MyGroup_rpc_data) do
		MemberNum = MemberNum + 1
	end
	return MemberNum
end

function GroupListFill(data,ltv)
	local dataGroup = GetGroupList()
	local BOOL = true
	local roomlist = ltv
	local root = ltv.RootItem
	local Add = 1
	local item = nil
	roomlist:DeleteAll()
	
	if data then
		for _,v in ipairs(data) do
			BOOL = true
			if v[5] == 0 then
				BOOL = false
			end
			for _,Y in ipairs(dataGroup) do
				if Y[1] == v[1] then
					BOOL = false
					break
				end
			end
			if BOOL then
				item = roomlist:AddItem(root,Add)
				Add = Add + 1
				item.CanSelect = true
				item.BGSkin = Skin.ListItemSkin_Friends
--				if v[5] == 1 then
					item.SpecialA = true
					item.FontSize = 14
					item.TextColor = ARGB(255, 37, 37, 37)
--				else
--					item.SpecialA = false
--					item.FontSize = 14
--					item.TextColor = ARGB(255, 126, 124, 125)
--				end
				item.CheckVisible = true
				item.CheckBoxLocation = Vector2(10, 0)
				item.CheckBoxSize = Vector2(28, 28)
				item:SetText(0,v[3])
			end
		end
	end
	if Add < 6 then
		for i=Add, 5 do
			item = roomlist:AddItem(root,i)
			item.CanSelect = false
			item.BGSkin = Skin.ListItemSkin_Friends

			item.CheckVisible = false
			item:SetText(0,"")
		end
	end
end

function TepGroupListFill(data,ltv)
	local TepGroupList = GetTepGroupList()
	local BOOL = true
	local roomlist = ltv
	local root = ltv.RootItem
	local Add = 1
	local item = nil
	roomlist:DeleteAll()
	
	if data then
		for _,v in ipairs(data) do
			BOOL = true
			if v[5] == 0 then
				BOOL = false
			end
			for i = 1 , 5 do
				if TepGroupList.member_id[i] == 0 then
					break
				end
				if v[1] == TepGroupList.member_id[i] then
					BOOL = false
					break
				end
			end
			if BOOL == true then
				item = roomlist:AddItem(root,Add)
				Add = Add + 1
				item.CanSelect = true
				item.BGSkin = Skin.ListItemSkin_Friends
--				if v[5] == 1 then
--					item.SpecialA = true
					item.FontSize = 14
					item.TextColor = ARGB(255, 37, 37, 37)
--				else
--					item.SpecialA = false
--					item.FontSize = 14
--					item.TextColor = ARGB(255, 126, 124, 125)
--				end
				item.CheckVisible = true
				item.CheckBoxLocation = Vector2(10, 0)
				item.CheckBoxSize = Vector2(28, 28)
				item:SetText(0,v[3])
			end
		end
	end
	if Add < 7 then
		for i=Add, 6 do
			item = roomlist:AddItem(root,i)
			item.CanSelect = false
			item.BGSkin = Skin.ListItemSkin_Friends

			item.CheckVisible = false
			item:SetText(0,"")
		end
	end
end

--列表扫描
function GroupListScan(ltv,ltvnext)
	local check_list = nil
	local item = ltv.RootItem.FirstChild
	while item do
		if item.Check then
			check_list = {next = check_list , name = item:GetText(0)}
		end
		item = item.Next
	end
	if ltvnext then
		local item = ltvnext.RootItem.FirstChild
		while item do
			if item.Check then
				check_list = {next = check_list , name = item:GetText(0)}
			end
			item = item.Next
		end
	end
	if check_list == nil then
		ShowLeaveOwnGroupCreateWin(gui,lang:GetText("您至少选中一名玩家！"))
		return false
	end
	if ltvnext then
		GroupMemberAdd(check_list)
	else
		local Group_TepId = GetTepGroupId()
		local l = check_list
		while l do
			if l.name then
				ptr_cast(game.CurrentState):GroupInvite(l.name , Group_TepId)
			end
			l = l.next
		end
	end
	return true
end

--获得临时群Id
function GetTepGroupId()
	for i = 1 , 10 do
		if ChatBTNSign == ChatInfo[i][1] and ChatInfo[i][2] == 2 then			
			return ChatInfo[i][7]
		end
	end
end

--添加群组成员
-- pid=人物id
-- action = add_friend|add_black|delete|add_group|delete_group
-- id 操作目标的id
-- name
function GroupMemberAdd(list)
	local iTep = 1
	local IDTep = 0
	while list do
		IDTep = 0
		iTep = 1
		if L_LobbyMain.Friends_rpc_data then
			while 1 do
				if L_LobbyMain.Friends_rpc_data[iTep] == nil then
					break
				end
				if L_LobbyMain.Friends_rpc_data[iTep][3] == list.name then
					IDTep = L_LobbyMain.Friends_rpc_data[iTep][1]
					break
				end
				iTep = iTep + 1
			end
		end

		if IDTep == 0 then
			iTep = 1
			if L_LobbyMain.partners_rpc_data then
				while 1 do
					if L_LobbyMain.partners_rpc_data[iTep] == nil then
						break
					end
					if L_LobbyMain.partners_rpc_data[iTep][3] == list.name then
						IDTep = L_LobbyMain.partners_rpc_data[iTep][1]
						break
					end
					iTep = iTep + 1
				end
			end
		end
		if IDTep ~= 0 then
			local args = {pid = ptr_cast(game.CurrentState):GetCharacterId(), action = "add_group", id = IDTep , name = list.name}
			rpc.safecall("friends_menu",args,nil,function () L_MessageBox.CloseWaiter() end)
		end
		list = list.next
	end
end

function LeaveGroupfont(Name)
	for _,v in ipairs(L_LobbyMain.AddGroup_rpc_data) do
		if v[1][5] == Name then
			LeavePid = v[1][1]
			leaveName = Name
			return
		end
	end
end

--离开组
function LeaveGroup()
	local args = {pid = LeavePid, action = "delete_group", id = ptr_cast(game.CurrentState):GetCharacterId() , name = L_LobbyMain.PersonalInfo_data.name}
	rpc.safecall("friends_menu",args,L_LobbyMain.GerGroupList,function () L_MessageBox.CloseWaiter() end)
end

--踢人出组
function KickingGroupMember()
	for _,v in ipairs(L_LobbyMain.MyGroup_rpc_data) do 
		if v[3] == L_LobbyMain.KickingGroupMemberName then
			local args = {pid = ptr_cast(game.CurrentState):GetCharacterId(), action = "delete_group", id = v[1], name = v[3]}
			rpc.safecall("friends_menu",args,L_LobbyMain.GerGroupList,function () L_MessageBox.CloseWaiter() end)
			return
		end
	end
	L_Friends.ShowLeaveOwnGroupCreateWin(gui,lang:GetText("玩家").."“"..L_LobbyMain.KickingGroupMemberName.."”"..lang:GetText("不在你的群组！"))
end

function ShowCreateFriends(win_parent,which)
	if which == 0 then
		L_LobbyMain.LobbyMainWin.btn_Friends.PushDown = false
		L_LobbyMain.LobbyMainWin.btn_Friend.PushDown = true
		if Create_Friend_ui then
		
			Create_Friend_ui.ctr_Friend_List.Parent = win_parent
			
			if Create_Friends_ui then
				Create_Friends_ui.ctr_Friends_List.Parent = nil
			end
			return
		end
		
		if Create_Friends_ui then
			Create_Friends_ui.ctr_Friends_List.Parent = nil
		end
		--创建通讯录列表
		Create_Friend_ui = Gui.Create(win_parent)(Create_Friend_List)
	elseif which == 1 then
		L_LobbyMain.LobbyMainWin.btn_Friends.PushDown = true
		L_LobbyMain.LobbyMainWin.btn_Friend.PushDown = false
		if Create_Friends_ui then
			Create_Friends_ui.ctr_Friends_List.Parent = win_parent
			
			if Create_Friend_ui then
				Create_Friend_ui.ctr_Friend_List.Parent = nil
			end
			return
		end
		
		if Create_Friend_ui then
			Create_Friend_ui.ctr_Friend_List.Parent = nil
		end
		
		--创建群组列表
		Create_Friends_ui = Gui.Create(win_parent)(Create_Friends_List)
	end
end

--动态列表
-- uid=帐号id
-- cid=人物id
-- displayOnline = 1只显示在线好友0全部显示

function ChangesList(which)
	local BackList = 0
	local Stranger = 0
	
	if which == 0 then
		BackList = 200
		Stranger = 229
		Create_Friend_ui.btn_Friend_Friend.PushDown = true
		Create_Friend_ui.btn_Friend_Blacklist.PushDown = false
		Create_Friend_ui.btn_Friend_Stranger.PushDown = false
		FilFriendList(L_LobbyMain.Friends_rpc_data,Create_Friend_ui.list_room_info_friend)
		if Search_Con == 0 then
			Create_Friend_ui.list_room_info_friend.Visible = true
		end
		Create_Friend_ui.list_room_info_back.Visible = false
		Create_Friend_ui.list_room_info_stranger.Visible = false
	elseif which == 1 then
		BackList = 62
		Stranger = 229
		Create_Friend_ui.btn_Friend_Friend.PushDown = false
		Create_Friend_ui.btn_Friend_Blacklist.PushDown = true
		Create_Friend_ui.btn_Friend_Stranger.PushDown = false
		FilFriendList(L_LobbyMain.Black_rpc_data,Create_Friend_ui.list_room_info_back)
		Create_Friend_ui.list_room_info_friend.Visible = false
		if Search_Con == 0 then
			Create_Friend_ui.list_room_info_back.Visible = true
		end
		Create_Friend_ui.list_room_info_stranger.Visible = false
	elseif which == 2 then
		BackList = 62
		Stranger = 91
		Create_Friend_ui.btn_Friend_Friend.PushDown = false
		Create_Friend_ui.btn_Friend_Blacklist.PushDown = false
		Create_Friend_ui.btn_Friend_Stranger.PushDown = true
		FilFriendList(L_LobbyMain.partners_rpc_data,Create_Friend_ui.list_room_info_stranger)
		Create_Friend_ui.list_room_info_friend.Visible = false
		Create_Friend_ui.list_room_info_back.Visible = false
		if Search_Con == 0 then
			Create_Friend_ui.list_room_info_stranger.Visible = true
		end
	end
	Create_Friend_ui.btn_Friend_Blacklist.Location = Vector2(6, BackList)
	Create_Friend_ui.btn_Friend_Stranger.Location = Vector2(6, Stranger)
	
	L_LobbyMain.FriendsUpdate()
end

function FilFriendList(data,tvl)
	local roomlist = tvl
	local root = tvl.RootItem
	local Add = 1
	local item = nil
	roomlist:DeleteAll()
	local iconN = nil
	if data then
		for _,v in ipairs(data) do
			item = roomlist:AddItem(root)
			item.NeedProjection = false
			item.CanSelect = true			
			Setbusiness_card(item,v[9],v[6])
			Add = Add + 1
			iconN = Gui.Icon("LobbyUI/persionalInfo/HeadPic/lb_battlefield_icon"..v[7]..".dds")
			item:SetIcon(0,iconN)
			SetLeave(v[2],item)			
			SetVipIcon(item,v[6],3,v[8],nil,v[9])
			item:SetText(4,v[3])
			if v[5] == 0 then
				item.SpecialA = true
				item.FontSize = 14
				item.TextColor = ARGB(255, 126, 124, 125)
			else
				item.FontSize = 14
				item.SpecialA = false
			end
		end
	end
	
	if Add < 5 then
		for i=Add, 4 do
			item = roomlist:AddItem(root)
			item.CanSelect = false
			item.BGSkin = Skin.ListItemSkin_Friends
			item:SetText(0,"")
			item:SetText(1,"")
			item:SetText(2,"")
			item:SetText(3,"")
			item:SetText(4,"")
		end
	end
end

function SetLeave(level,item)
	local levelunit = level%10 + 1
	local leveldec = (level -levelunit + 1) /10
	
	leveldec = leveldec + 1
	
	local icon2 =  Gui.Icon("LobbyUI/WarZone/lb_summary_number_7b.dds", Vector4(0, 0, 0, 0),Vector4((leveldec-1)/10,0,(leveldec)/10,1))
	local icon1 =  Gui.Icon("LobbyUI/WarZone/lb_summary_number_6b.dds", Vector4(0, 0, 0, 0),Vector4((leveldec-1)/10,0,(leveldec)/10,1))
	
	item:SetIcon(1, icon1,icon2)
	
	icon2 =  Gui.Icon("LobbyUI/WarZone/lb_summary_number_7b.dds", Vector4(0, 0, 0, 0),Vector4((levelunit-1)/10,0,(levelunit)/10,1))
	icon1 =  Gui.Icon("LobbyUI/WarZone/lb_summary_number_6b.dds", Vector4(0, 0, 0, 0),Vector4((levelunit-1)/10,0,(levelunit)/10,1))	
		
	item:SetIcon(2, icon1,icon2)
	
end

function FilFriendSearchList(data)
	L_LobbyMain.Search_rpc_data = nil
	L_LobbyMain.Search_rpc_data = data
	local roomlist = Create_Friend_ui.list_room_FriendSearch
	local root = Create_Friend_ui.list_room_FriendSearch.RootItem
	local Add = 1
	local item = nil
	Create_Friend_ui.lab_Null_Player.Visible = false
	roomlist:DeleteAll()
	local iconN = nil
	if data.list then
		for _,v in ipairs(data.list) do
			item = roomlist:AddItem(root)
			item.CanSelect = true
			
			Setbusiness_card(item,v[8],v[6])

			Add = Add + 1
			iconN = Gui.Icon("LobbyUI/persionalInfo/HeadPic/lb_battlefield_icon"..v[7]..".dds")
			item:SetIcon(0,iconN)
			SetVipIcon(item,v[6],1,v[9],nil,v[8])
			item:SetText(2,v[3])
			if v[5] == 0 then
				item.SpecialA = true
				item.FontSize = 14
				item.TextColor = ARGB(255, 126, 124, 125)
			else
				item.FontSize = 14
				item.SpecialA = false
			end
		end
	end
	if Add == 1 then
		Create_Friend_ui.lab_Null_Player.Visible = true
	end
	
	if Add < 8 then
		for i=Add, 7 do
			item = roomlist:AddItem(root,Add)
			item.CanSelect = false
--			if i%2 == 1 then
--				item.BGSkin = Skin.ListItemSkin_Friends
--			else
				item.BGSkin = Skin.ListItemSkin_Friends
--			end
			item:SetText(0,"")
			item:SetText(1,"")
			item:SetText(2,"")
		end
	end
	
end

function FileGroupList(Mydata,Adddata)
	local roomlist = Create_Friends_ui.list_Group_room
	local root = Create_Friends_ui.list_Group_room.RootItem
	local Add = 1
	local item = nil
	roomlist:DeleteAll()
	
	item = roomlist:AddItem(root,Add)
--	if Add%2 == 1 then
--		item.BGSkin = Skin.ListItemSkin_Friends
--	else
		
--	end
	if Mydata and Mydata[1] then
		item:SetText(0,Mydata[1][5])
		item.NeedProjection = false
		item.CanSelect = true
		Create_Friends_ui.btn_Create_Group.Enable = false
		item.BGSkin = Skin.ListItemSkin_Friends_Group
	else
		item:SetText(0,"    "..lang:GetText("你可以创建一个聊天群！"))
		item.FontSize = 12
		item.CanSelect = false
		item.NeedProjection = false
		Create_Friends_ui.btn_Create_Group.Enable = true
		item.BGSkin = Skin.ListItemSkin_Friends
	end
	Add = Add + 1
	
	if Adddata then
		for _,v in ipairs(Adddata) do
			item = roomlist:AddItem(root,Add)
			Add = Add + 1
			item.NeedProjection = false
			item.CanSelect = true
--			if Add%2 == 1 then
				item.BGSkin = Skin.ListItemSkin_Friends_Group
--			else
--				item.BGSkin = Skin.ListItemSkin_Double
--			end
			item:SetText(0,v[1][5])
		end
	end
	if Team_name then
		item = roomlist:AddItem(root,Add)
--		if Add%2 == 1 then
			item.BGSkin = Skin.ListItemSkin_Friends_Group
--		else
--			item.BGSkin = Skin.ListItemSkin_Double
--		end
		Add = Add + 1
		item:SetText(0,Team_name_Add)
		--item:SetSubItemColor(0, ARGB(255, 135, 8, 12))
		item.CanSelect = true
		item.NeedProjection = false
		item.LV_BackgroundImage = Gui.Image("LobbyUI/Friends/lb_chat_ico_01.dds", Vector4(0, 0, 0, 0), Vector4(0, 0, 1, 1))
		item.LV_localtion = Vector2(5,3)
		item.LV_Size = Vector2(38,24)
	end
	if Channel_name then
		item = roomlist:AddItem(root,Add)
--		if Add%2 == 1 then
			item.BGSkin = Skin.ListItemSkin_Friends_Group
--		else
--			item.BGSkin = Skin.ListItemSkin_Double
--		end
		Add = Add + 1
		item:SetText(0,Channel_name)
		item.CanSelect = true
		item.NeedProjection = false
	end
	if room_name then
		item = roomlist:AddItem(root,Add)
--		if Add%2 == 1 then
			item.BGSkin = Skin.ListItemSkin_Friends_Group
	--	else
--			item.BGSkin = Skin.ListItemSkin_Double
--		end
		Add = Add + 1
		item:SetText(0,room_name)
		item.CanSelect = true
		item.NeedProjection = false
	end
	if Add < 9 then
		for i=Add, 8 do
			item = roomlist:AddItem(root,i)
			item.CanSelect = false
--			if i%2 == 1 then
				item.BGSkin = Skin.ListItemSkin_Friends
--			else
--				item.BGSkin = Skin.ListItemSkin_Double
	--		end
			item:SetText(0,"")
		end
	end
end

--频道列表填写
function FileChannelList(ltv,which)
	local roomlist = ltv
	local root = ltv.RootItem
	local Add = 1
	local item = nil
	roomlist:DeleteAll()
	Channel_list = nil
	
	local iconN = Icons.PlayerStatusIcons["VipSmall"]
	local iconN2 = Icons.PlayerStatusIcons["XunLeiVipSmall"]
	local state = ptr_cast(game.CurrentState)
	itemCount = state:GetChannelClientCount()
	
	for i=0, itemCount-1 do
		local info = state:GetChannelClientInfo(i)
		item = roomlist:AddItem(root)
		item.CanSelect = true		
		Setbusiness_card_war(item,info.business_card,info.is_vip)		
		Add = Add + 1
		item.FontSize = which
		SetVipIcon(item,info.is_vip,0,info.net_bar_level,"_min",1)
		item:SetText(1,info.name)
		item.NeedProjection = false
		Channel_list = { next = Channel_list, name = info.name, vip = info.is_vip , id = info.character_id}
	end
	
	if Add < 8 then
		for i = Add , 7 do
			item = roomlist:AddItem(root)
			item.CanSelect = false
			item.BGSkin = Skin.ListItemSkin_Friends
			Add = Add + 1
			item:SetText(0,"")
			item:SetText(1,"")
		end
	end
end

--房间列表填写
function FileRoomList()
	local roomlist = L_LobbyMain.LobbyMainWin.Chat_Room_List
	local root = L_LobbyMain.LobbyMainWin.Chat_Room_List.RootItem
	local Add = 1
	local item = nil
	roomlist:DeleteAll()
	room_list = nil
	local state = ptr_cast(game.CurrentState)
	itemCount = state:GetClientCount()

	for i=0, itemCount-1 do
		local info = state:GetClientInfo(i)
		item = roomlist:AddItem(root)
		item.CanSelect = true
		Setbusiness_card(item,info.business_card,info.is_vip)		
		Add = Add + 1
		item.FontSize = 14
		SetVipIcon(item,info.is_vip,0,info.net_bar_level,"_min",info.business_card)
		item:SetText(1,info.name)
		item.NeedProjection = false
		room_list = { next = room_list, name = info.name, vip = info.is_vip, id = info.character_id}
	end
	
	if Add < 8 then
		for i = Add , 7 do
			item = roomlist:AddItem(root)
			item.CanSelect = false
			item.BGSkin = Skin.ListItemSkin_Friends
			Add = Add + 1
			item:SetText(0,"")
			item:SetText(0,"")
		end
	end
end
--创建聊天窗口
function ShowCreateChatWin()
	L_LobbyMain.LobbyMainWin.ctr_ChatWin.Visible = true

	chatWindow.Parent = L_LobbyMain.LobbyMainWin_Boddy.ctr_ChatWin_Write
end

--列表初始化
function InitializeList()
	ShowCreateFriends(gui,0)
	Create_Friend_ui.list_room_info_friend:DeleteColumns()
	Create_Friend_ui.list_room_info_friend:AddColumn("", 40, "kAlignCenterMiddle")
	Create_Friend_ui.list_room_info_friend:AddColumn("", 12, "kAlignLeftMiddle")
	Create_Friend_ui.list_room_info_friend:AddColumn("", 12, "kAlignCenterMiddle")
	Create_Friend_ui.list_room_info_friend:AddColumn("", 30, "kAlignCenterMiddle")
	Create_Friend_ui.list_room_info_friend:AddColumn("", 170,"kAlignLeftMiddle")
	Create_Friend_ui.list_room_FriendSearch:DeleteColumns()
	Create_Friend_ui.list_room_FriendSearch:AddColumn("", 40, "kAlignCenterMiddle")
	Create_Friend_ui.list_room_FriendSearch:AddColumn("", 30, "kAlignCenterMiddle")
	Create_Friend_ui.list_room_FriendSearch:AddColumn("", 170,"kAlignLeftMiddle")
	
	--黑名单列表初始化
	Create_Friend_ui.list_room_info_back:DeleteColumns()
	Create_Friend_ui.list_room_info_back:AddColumn("", 40, "kAlignCenterMiddle")
	Create_Friend_ui.list_room_info_back:AddColumn("", 12, "kAlignLeftMiddle")
	Create_Friend_ui.list_room_info_back:AddColumn("", 12, "kAlignCenterMiddle")
	Create_Friend_ui.list_room_info_back:AddColumn("", 30, "kAlignCenterMiddle")
	Create_Friend_ui.list_room_info_back:AddColumn("", 170,"kAlignLeftMiddle")
	
	
	--陌生人列表初始化
	Create_Friend_ui.list_room_info_stranger:DeleteColumns()
	Create_Friend_ui.list_room_info_stranger:AddColumn("", 40, "kAlignCenterMiddle")
	Create_Friend_ui.list_room_info_stranger:AddColumn("", 12, "kAlignLeftMiddle")
	Create_Friend_ui.list_room_info_stranger:AddColumn("", 12, "kAlignCenterMiddle")
	Create_Friend_ui.list_room_info_stranger:AddColumn("", 30, "kAlignCenterMiddle")
	Create_Friend_ui.list_room_info_stranger:AddColumn("", 170,"kAlignLeftMiddle")
				
	ShowCreateFriends(L_LobbyMain.LobbyMainWin.ctr_ctr_FriendsWin_root,1)
	Create_Friends_ui.list_Group_room:DeleteColumns()
	Create_Friends_ui.list_Group_room:AddColumn("", 255, "kAlignCenterMiddle")
end

function Initialize()
	if Chat_BTN_Win_ui == nil then
		ShowChatBTNWin(L_LobbyMain.LobbyMainWin.ctr_ChatWin)
		InitializeList()
		Hide()
		HideChatChoose()
	end
	--L_LobbyMain.GetPartnerList()
	L_Friends.GetTeamInfo()
	local state = ptr_cast(game.CurrentState)
	chatWindow = state.ChatWindow
	chatWindow.gap = 0
	chatWindow.Size = Vector2(360,53)
	chatWindow.MessageDisplaySize = Vector2(360,1)
	chatWindow.MessageDisplayLoc = Vector2(5,5)
	chatWindow.MessageVisble = true 
	chatWindow.EventReceiveMessage = ChatPrivateMsg
	if ChatBTNSign ~= 0 then
		for i = 1, ChatBtn_WinNumber do
			if ChatBTNTrait[i][1] == ChatBTNSign then
				ShowChatWin(i)
				break
			end
		end
	end
end

function Finalize(FriendsWin)
	
end

function Show()
	ShowCreateFriendsWin()
	ShowCreateFriends(L_LobbyMain.LobbyMainWin.ctr_ctr_FriendsWin_root,current_selected)
	Create_Friend_ui.btn_Friend_Friend.PushDown = true
	L_LobbyMain.GetOnlineFriends()
	L_Friends.ChangesList(L_Friends.changes_List)
end

--添加好友
-- uid=帐号id
-- pid=人物id
-- action = add_friend|add_black|delete|add_group
-- id 操作目标的id
-- name
function FriendsAdd(list,name)
	if name == L_LobbyMain.PersonalInfo_data.name then
		ShowLeaveOwnGroupCreateWin(gui,lang:GetText("您不能添加自己为好友！"))
	elseif FriendJudge(name,L_LobbyMain.Friends_rpc_data) == true then
		ShowLeaveOwnGroupCreateWin(gui,lang:GetText("对方已经在您的好友中！"))
	else
		if list then
			local line = 1
			for _,v in ipairs(list) do
				if v[3] == name then
					break
				end
				line = line + 1
			end
			if list[line] then
				local args = {pid = ptr_cast(game.CurrentState):GetCharacterId(), action = "add_friend", id = list[line][1] , name = list[line][3]}
				rpc.safecall("friends_menu",args,
							function (data)
								if data.warning then
									MessageBox.ShowWithTimer(1,data.warning)
								else
									MessageBox.ShowWithTimer(1,lang:GetText("好友邀请发送成功！"))
								end
							end)
			end
		else
			local args = {pid = ptr_cast(game.CurrentState):GetCharacterId(), action = "add_friend",  name = name}
			rpc.safecall("friends_menu",args,
				function (data)
							if data.warning then
								MessageBox.ShowWithTimer(1,data.warning)
							else
								MessageBox.ShowWithTimer(1,lang:GetText("好友邀请发送成功！"))
							end
						end)
		end
	end
end

function BlackAdd(name)
	if name == L_LobbyMain.PersonalInfo_data.name then
		L_Friends.ShowLeaveOwnGroupCreateWin(gui,lang:GetText("您不能添加自己为黑名单！"))
		return
	elseif FriendJudge(name,L_LobbyMain.Black_rpc_data) == true then
		ShowLeaveOwnGroupCreateWin(gui,lang:GetText("对方已经在您的黑名单中！"))
		return
	end
	local args = {pid = ptr_cast(game.CurrentState):GetCharacterId(), action = "add_black", name =name}
	rpc.safecall("friends_menu",args,function(data)
										if data.warning then
											MessageBox.ShowWithTimer(1,data.warning)
										end
										end)
end

function FriendJudge(name,list)
	for _,v in ipairs(list) do
		if v[3] == name then
			return(true)
		end
	end
	return(false)
end

function HideFriendsCreateWin()
	if Create_Friends_Create_ui then
		Create_Friends_Create_ui.ctr_Friends_Create.Parent = nil
	end
end

function HideChatChoose()
	if Create_Friends_Choose_ui then
		Create_Friends_Choose_ui.ctr_Friends_Choose.Parent = nil
	end
	if Creat_Friends_From_ui then
		Creat_Friends_From_ui.ctr_Friends_From.Parent = nil
	end
	if Create_Group_AddMembers_ui then
		Create_Group_AddMembers_ui.ctr_Group_AddMembers.Parent = nil
	end
end

function HideChat()
	L_LobbyMain.LobbyMainWin.ctr_ChatWin.Visible = false
end

function Hide()
	if Create_Friend_ui then
		Create_Friend_ui.ctr_Friend_List.Parent = nil
	end
	if Create_Friends_ui then
		Create_Friends_ui.ctr_Friends_List.Parent = nil
	end
	L_LobbyMain.LobbyMainWin.ctr_FriendsWin_root_Parent.Visible = false
end

--关闭所有窗口
function HideAll()
--	Hide()
--	HideChat()
	HIdeInvitedCreateWin()
	HIdeGroupInvitedCreateWin()
	HIdeLeaveGroupCreateWin()
	HIdeKickingGroupCreateWin()
	HIdeDeleteFriendCreateWin()
	HIdeLeaveOwnGroupCreateWin()
	HIdeTepGroupInvitedCreateWin()
	HideChatChoose()
	HideInviteGameWin()
	HideFriendsCreateWin()
end

--申请创建群组
-- pid=昵称id
function CreateGroupChat()
	if Create_Friends_Create_ui.tbox_GroupName.Text then
		local args = {pid = ptr_cast(game.CurrentState):GetCharacterId(), name = Create_Friends_Create_ui.tbox_GroupName.Text}
		rpc.safecall("group_create",args,L_LobbyMain.GerGroupList,function () L_MessageBox.CloseWaiter() end)
	end
end

function AlignUI()
	if Create_Friends_Create_ui then
		Gui.Align(Create_Friends_Create_ui.ctr_Friends_Create, 0.5, 0.5)
	end
	if Create_Invited_Win_ui then
		Gui.Align(Create_Invited_Win_ui.ctr_Invited_Win, 0.5, 0.5)
	end
	if Create_GroupInvited_Win_ui then
		Gui.Align(Create_GroupInvited_Win_ui.ctr_GroupInvited_Win, 0.5, 0.5)
	end
	if Create_TepGroupInvited_Win_ui then
		Gui.Align(Create_TepGroupInvited_Win_ui.ctr_TepGroupInvited_Win, 0.5, 0.5)
	end
	if Creat_Friends_From_ui then
		Gui.Align(Creat_Friends_From_ui.ctr_Friends_From, 0.5, 0.5)
	end
	if Create_LeaveGroup_Win_ui then
		Gui.Align(Create_LeaveGroup_Win_ui.ctr_LeaveGroup_Win, 0.5, 0.5)
	end
	if Create_KickingGroup_Win_ui then
		Gui.Align(Create_KickingGroup_Win_ui.ctr_KickingGroup_Win, 0.5, 0.5)
	end
	if Create_Group_AddMembers_ui then
		Gui.Align(Create_Group_AddMembers_ui.ctr_Group_AddMembers, 0.5, 0.5)
	end
	if Create_Friends_Choose_ui then
		Gui.Align(Create_Friends_Choose_ui.ctr_Friends_Choose, 0.5, 0.5)
	end
	if Create_DeleteFriend_Win_ui then
		Gui.Align(Create_DeleteFriend_Win_ui.ctr_DeleteFriend_Win, 0.5, 0.5)
	end
	if Create_InviteGame_Win_ui then
		Gui.Align(Create_InviteGame_Win_ui.ctr_InviteGame_Win, 0.5, 0.5)
	end
end

--查看信息
function ShowPerson(list,name)
	for _,v in ipairs(list) do
		if name == v[3] then
			L_PersonalInfo.ShowPerson(L_LobbyMain.LobbyMainWin_Boddy.LobbyMainWin_Boddy_Root,v[1],v[3])
			break
		end
	end	
end

--新版本
Chat_BTN_Win_ui = nil

--聊天窗口显示个数(可配 最多5个)
ChatBtn_WinNumber = 4
--聊天BTN属性(BTN位置顺序，窗口类型，BTN名称)
ChatBTNTrait = 
{
	{0,0,nil},
	{0,0,nil},
	{0,0,nil},
	{0,0,nil},
	{0,0,nil},
}

--聊天信息(顺序，类型，名称，内容，闪烁状态，优先级,临时聊天组ID,人物Id)
ChatInfo = 
{
	{0,0,nil,nil,0,0,0,0},
	{0,0,nil,nil,0,0,0,0},
	{0,0,nil,nil,0,0,0,0},
	{0,0,nil,nil,0,0,0,0},
	{0,0,nil,nil,0,0,0,0},
	{0,0,nil,nil,0,0,0,0},
	{0,0,nil,nil,0,0,0,0},
	{0,0,nil,nil,0,0,0,0},
	{0,0,nil,nil,0,0,0,0},
	{0,0,nil,nil,0,0,0,0},
}

Name_Id = 0

--聊天BTN显示数
ChatNums = 0
ShowChatBTNFirst = 0
ChatBTNSign = 0

--频道聊天信息
Channl_Text = nil
--房间聊天信息
Room_Text = nil
--临时聊天群组创建Id
TepGroup_Id = 0
--临时聊天群组成员
TepGroup_Member = nil

--战队名称
Team_name = nil
Team_name_Add = nil

--战队列表
Team_RPC_List = nil

local Chat_BTN_Win =
{
	Gui.Control"ctr_Chat_BTN_Win"
	{
		Size = Vector2(910, 32),
		BackgroundColor = ARGB(0, 255, 255, 255),
		Location = Vector2(0, 0),
		
		Gui.Button "Chat_BTN1"
		{
			Location = Vector2(0, 0),
			Size = Vector2(130, 32),
			BackgroundColor = ARGB(255,255,255,255),
			TextAlign = "kAlignLeftMiddle",
			TextColor = ARGB(255, 37, 37, 37),
			HighlightTextColor = ARGB(255, 37, 37, 37),
			Padding = Vector4(5, 0, 0, 5),
			FontSize = 15,
			AutoEllipsis = true,
			AutoEllipsisArea = 20,
			Visible = false,
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/Friends/lb_chat_pop_normal.dds", Vector4(25, 7, 6, 12)),
				HoverImage = Gui.Image("LobbyUI/Friends/lb_chat_pop_hover.dds", Vector4(25, 7, 6, 12)),
				DownImage = Gui.Image("LobbyUI/Friends/lb_chat_pop_down.dds", Vector4(25, 7, 6, 12)),
				DisabledImage = Gui.Image("LobbyUI/Friends/lb_chat_pop_normal.dds", Vector4(25, 7, 6, 12)),
				TwinkleImage = Gui.Image("LobbyUI/Friends/lb_chat_pop.dds", Vector4(25, 7, 6, 12)),
			},
			EventClick = function()
				--MessageBox.ShowWithConfirmCancel(lang:GetText("还在制作中？"), nil)
				ShowChatWin(1)
			end,
			
			--退出
			Gui.Button
			{
				Size = Vector2(20,20),
				Location = Vector2(108, 4),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_buttonX2_normal.dds", Vector4(0, 0, 0, 0)),
					HoverImage = Gui.Image("LobbyUI/Friends/lb_contact_buttonX2_hover.dds", Vector4(0, 0, 0, 0)),
					DownImage = Gui.Image("LobbyUI/Friends/lb_contact_buttonX2_down.dds", Vector4(0, 0, 0, 0)),
					DisabledImage = Gui.Image("LobbyUI/Friends/lb_contact_buttonX2_normal.dds", Vector4(0, 0, 0, 0)),
				},
				EventClick = function()
					HideChatBTN(ChatBTNTrait[1][1],1)
				end
			},
		},
		
		Gui.Button "Chat_BTN2"
		{
			Location = Vector2(0, 0),
			Size = Vector2(130, 32),
			BackgroundColor = ARGB(255,255,255,255),
			TextAlign = "kAlignLeftMiddle",
			TextColor = ARGB(255, 37, 37, 37),
			HighlightTextColor = ARGB(255, 37, 37, 37),
			Padding = Vector4(5, 0, 0, 5),
			FontSize = 15,
			AutoEllipsis = true,
			AutoEllipsisArea = 20,
			Visible = false,
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/Friends/lb_chat_pop_normal.dds", Vector4(25, 7, 6, 12)),
				HoverImage = Gui.Image("LobbyUI/Friends/lb_chat_pop_hover.dds", Vector4(25, 7, 6, 12)),
				DownImage = Gui.Image("LobbyUI/Friends/lb_chat_pop_down.dds", Vector4(25, 7, 6, 12)),
				DisabledImage = Gui.Image("LobbyUI/Friends/lb_chat_pop_normal.dds", Vector4(25, 7, 6, 12)),
				TwinkleImage = Gui.Image("LobbyUI/Friends/lb_chat_pop.dds", Vector4(25, 7, 6, 12)),
			},
			EventClick = function()
				--MessageBox.ShowWithConfirmCancel(lang:GetText("还在制作中？"), nil)
				ShowChatWin(2)
			end,
			
			--退出
			Gui.Button
			{
				Size = Vector2(20,20),
				Location = Vector2(108, 4),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_buttonX2_normal.dds", Vector4(0, 0, 0, 0)),
					HoverImage = Gui.Image("LobbyUI/Friends/lb_contact_buttonX2_hover.dds", Vector4(0, 0, 0, 0)),
					DownImage = Gui.Image("LobbyUI/Friends/lb_contact_buttonX2_down.dds", Vector4(0, 0, 0, 0)),
					DisabledImage = Gui.Image("LobbyUI/Friends/lb_contact_buttonX2_normal.dds", Vector4(0, 0, 0, 0)),
				},
				EventClick = function()
					HideChatBTN(ChatBTNTrait[2][1],2)
				end
			},
		},
		
		Gui.Button "Chat_BTN3"
		{
			Location = Vector2(0, 0),
			Size = Vector2(130, 32),
			BackgroundColor = ARGB(255,255,255,255),
			TextAlign = "kAlignLeftMiddle",
			TextColor = ARGB(255, 37, 37, 37),
			HighlightTextColor = ARGB(255, 37, 37, 37),
			Padding = Vector4(5, 0, 0, 5),
			FontSize = 15,
			AutoEllipsis = true,
			AutoEllipsisArea = 20,
			Visible = false,
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/Friends/lb_chat_pop_normal.dds", Vector4(25, 7, 6, 12)),
				HoverImage = Gui.Image("LobbyUI/Friends/lb_chat_pop_hover.dds", Vector4(25, 7, 6, 12)),
				DownImage = Gui.Image("LobbyUI/Friends/lb_chat_pop_down.dds", Vector4(25, 7, 6, 12)),
				DisabledImage = Gui.Image("LobbyUI/Friends/lb_chat_pop_normal.dds", Vector4(25, 7, 6, 12)),
				TwinkleImage = Gui.Image("LobbyUI/Friends/lb_chat_pop.dds", Vector4(25, 7, 6, 12)),
			},
			EventClick = function()
				--MessageBox.ShowWithConfirmCancel(lang:GetText("还在制作中？"), nil)
				ShowChatWin(3)
			end,
			
			--退出
			Gui.Button
			{
				Size = Vector2(20,20),
				Location = Vector2(108, 4),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_buttonX2_normal.dds", Vector4(0, 0, 0, 0)),
					HoverImage = Gui.Image("LobbyUI/Friends/lb_contact_buttonX2_hover.dds", Vector4(0, 0, 0, 0)),
					DownImage = Gui.Image("LobbyUI/Friends/lb_contact_buttonX2_down.dds", Vector4(0, 0, 0, 0)),
					DisabledImage = Gui.Image("LobbyUI/Friends/lb_contact_buttonX2_normal.dds", Vector4(0, 0, 0, 0)),
				},
				EventClick = function()
					HideChatBTN(ChatBTNTrait[3][1],3)
				end
			},
		},
		
		Gui.Button "Chat_BTN4"
		{
			Location = Vector2(0, 0),
			Size = Vector2(130, 32),
			BackgroundColor = ARGB(255,255,255,255),
			TextAlign = "kAlignLeftMiddle",
			TextColor = ARGB(255, 37, 37, 37),
			HighlightTextColor = ARGB(255, 37, 37, 37),
			Padding = Vector4(5, 0, 0, 5),
			FontSize = 15,
			AutoEllipsis = true,
			AutoEllipsisArea = 20,
			Visible = false,
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/Friends/lb_chat_pop_normal.dds", Vector4(25, 7, 6, 12)),
				HoverImage = Gui.Image("LobbyUI/Friends/lb_chat_pop_hover.dds", Vector4(25, 7, 6, 12)),
				DownImage = Gui.Image("LobbyUI/Friends/lb_chat_pop_down.dds", Vector4(25, 7, 6, 12)),
				DisabledImage = Gui.Image("LobbyUI/Friends/lb_chat_pop_normal.dds", Vector4(25, 7, 6, 12)),
				TwinkleImage = Gui.Image("LobbyUI/Friends/lb_chat_pop.dds", Vector4(25, 7, 6, 12)),
			},
			EventClick = function()
				--MessageBox.ShowWithConfirmCancel(lang:GetText("还在制作中？"), nil)
				ShowChatWin(4)
			end,
			
			--退出
			Gui.Button
			{
				Size = Vector2(20,20),
				Location = Vector2(108, 4),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_buttonX2_normal.dds", Vector4(0, 0, 0, 0)),
					HoverImage = Gui.Image("LobbyUI/Friends/lb_contact_buttonX2_hover.dds", Vector4(0, 0, 0, 0)),
					DownImage = Gui.Image("LobbyUI/Friends/lb_contact_buttonX2_down.dds", Vector4(0, 0, 0, 0)),
					DisabledImage = Gui.Image("LobbyUI/Friends/lb_contact_buttonX2_normal.dds", Vector4(0, 0, 0, 0)),
				},
				EventClick = function()
					HideChatBTN(ChatBTNTrait[4][1],4)
				end
			},
		},
		
		Gui.Button "Chat_BTN5"
		{
			Location = Vector2(0, 0),
			Size = Vector2(130, 32),
			BackgroundColor = ARGB(255,255,255,255),
			TextAlign = "kAlignLeftMiddle",
			TextColor = ARGB(255, 37, 37, 37),
			HighlightTextColor = ARGB(255, 37, 37, 37),
			Padding = Vector4(5, 0, 0, 5),
			FontSize = 15,
			AutoEllipsis = true,
			AutoEllipsisArea = 20,
			Visible = false,
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/Friends/lb_chat_pop_normal.dds", Vector4(25, 7, 6, 12)),
				HoverImage = Gui.Image("LobbyUI/Friends/lb_chat_pop_hover.dds", Vector4(25, 7, 6, 12)),
				DownImage = Gui.Image("LobbyUI/Friends/lb_chat_pop_down.dds", Vector4(25, 7, 6, 12)),
				DisabledImage = Gui.Image("LobbyUI/Friends/lb_chat_pop_normal.dds", Vector4(25, 7, 6, 12)),
				TwinkleImage = Gui.Image("LobbyUI/Friends/lb_chat_pop.dds", Vector4(25, 7, 6, 12)),
			},
			EventClick = function()
				--MessageBox.ShowWithConfirmCancel(lang:GetText("还在制作中？"), nil)
				ShowChatWin(5)
			end,
			
			--退出
			Gui.Button
			{
				Size = Vector2(20,20),
				Location = Vector2(108, 4),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_buttonX2_normal.dds", Vector4(0, 0, 0, 0)),
					HoverImage = Gui.Image("LobbyUI/Friends/lb_contact_buttonX2_hover.dds", Vector4(0, 0, 0, 0)),
					DownImage = Gui.Image("LobbyUI/Friends/lb_contact_buttonX2_down.dds", Vector4(0, 0, 0, 0)),
					DisabledImage = Gui.Image("LobbyUI/Friends/lb_contact_buttonX2_normal.dds", Vector4(0, 0, 0, 0)),
				},
				EventClick = function()
					HideChatBTN(ChatBTNTrait[5][1],5)
				end
			},
		},
		
		Gui.Button "Chat_BTN_Left"
		{
			Location = Vector2(0, 0),
			Size = Vector2(28, 28),
			BackgroundColor = ARGB(255,255,255,255),
			Visible = false,
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/Friends/lb_chat_prevbutton_normal.dds", Vector4(0, 0, 0, 0)),
				HoverImage = Gui.Image("LobbyUI/Friends/lb_chat_prevbutton_hover.dds", Vector4(0, 0, 0, 0)),
				DownImage = Gui.Image("LobbyUI/Friends/lb_chat_prevbutton_down.dds", Vector4(0, 0, 0, 0)),
				DisabledImage = Gui.Image("LobbyUI/Friends/lb_chat_prevbutton_disabled.dds", Vector4(0, 0, 0, 0)),
				TwinkleImage = Gui.Image("LobbyUI/Friends/lb_chat_prevbutton_pop.dds", Vector4(0, 0, 0, 0)),
			},
			EventClick = function()
				--MessageBox.ShowWithConfirmCancel(lang:GetText("还在制作中？"), nil)
				ReChatBTNinfoLeft()
			end,
		},
		
		Gui.Button "Chat_BTN_Right"
		{
			Location = Vector2(678, 0),
			Size = Vector2(28, 28),
			BackgroundColor = ARGB(255,255,255,255),
			Visible = false,
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/Friends/lb_chat_nextbutton_normal.dds", Vector4(0, 0, 0, 0)),
				HoverImage = Gui.Image("LobbyUI/Friends/lb_chat_nextbutton_hover.dds", Vector4(0, 0, 0, 0)),
				DownImage = Gui.Image("LobbyUI/Friends/lb_chat_nextbutton_down.dds", Vector4(0, 0, 0, 0)),
				DisabledImage = Gui.Image("LobbyUI/Friends/lb_chat_nextbutton_disabled.dds", Vector4(0, 0, 0, 0)),
				TwinkleImage = Gui.Image("LobbyUI/Friends/lb_chat_nextbutton_pop.dds", Vector4(0, 0, 0, 0)),
			},
			EventClick = function()
				--MessageBox.ShowWithConfirmCancel(lang:GetText("还在制作中？"), nil)
				ReChatBTNinfoRight()
			end
		},
	},
}

function ShowChatBTNWin(Win_Parent)
	if Chat_BTN_Win_ui then
		Chat_BTN_Win_ui.ctr_Chat_BTN_Win.Parent = Win_Parent
		return
	end
	
	--聊天BTN创建
	Chat_BTN_Win_ui = Gui.Create(Win_Parent)(Chat_BTN_Win)
end

function HideChatBTNWin()
	if Chat_BTN_Win_ui then
		Chat_BTN_Win_ui.ctr_Chat_BTN_Win.Parent = nil
	end
end

function ShowChatBTN(name,type,order)	
	for i = 1 , ChatBtn_WinNumber do
		if ChatBTNTrait[i][1] == 0 then
			local ibbtn = ptr_cast(Chat_BTN_Win_ui.ctr_Chat_BTN_Win:GetChildByIndex(i - 1))
			ChatBTNTrait[i][1] = order
			ChatBTNTrait[i][2] = type
			ChatBTNTrait[i][3] = name
			ibbtn.Visible = true
			if type == 2 then
				ibbtn.Text = name..lang:GetText("的临时群")
			else
				ibbtn.Text = name
			end
			break
		end
	end
	SetChatBTNPosition()
end

function SetChatBTNPosition(parent)
	L_LobbyMain.LobbyMainWin.b_close.Visible = true
	if parent == L_FightTeam.fightteam_fight_ui.root  then
		L_LobbyMain.LobbyMainWin.ctr_Group_Team_Win.Visible = true
		L_LobbyMain.LobbyMainWin.ctr_Group_Team_Win.Location = Vector2(33, 321)
		L_LobbyMain.LobbyMainWin.ctr_Group_Team_Win.Parent = parent
		return
	elseif parent == L_FightTeam.source_success_ui.root  then
		L_LobbyMain.LobbyMainWin.ctr_Group_Team_Win.Visible = true
		L_LobbyMain.LobbyMainWin.ctr_Group_Team_Win.Location = Vector2(54, 559)
		L_LobbyMain.LobbyMainWin.b_close.Visible = false
		L_LobbyMain.LobbyMainWin.ctr_Group_Team_Win.Parent = parent
		return
	elseif parent == L_FightTeam.source_fight_ui.root  then
		L_LobbyMain.LobbyMainWin.ctr_Group_Team_Win.Visible = true
		L_LobbyMain.LobbyMainWin.ctr_Group_Team_Win.Location = Vector2(352, 332)
		L_LobbyMain.LobbyMainWin.b_close.Visible = false
		L_LobbyMain.LobbyMainWin.ctr_Group_Team_Win.Parent = parent
		return
	end
	local TepPositon = 28
	local ibbtn = nil
	L_LobbyMain.LobbyMainWin.ctr_Create_Chat_Private.Visible = false
	L_LobbyMain.LobbyMainWin.ctr_Group_Chat_Win.Visible = false
	L_LobbyMain.LobbyMainWin.ctr_Group_Team_Win.Visible = false
	for j = 1 , ChatBtn_WinNumber do
		for i = 1 , ChatBtn_WinNumber do
			if ChatBTNTrait[i][1] == ShowChatBTNFirst + j then
				ibbtn = ptr_cast(Chat_BTN_Win_ui.ctr_Chat_BTN_Win:GetChildByIndex(i-1))
				ibbtn.Location = Vector2( TepPositon , 0 )
				ibbtn.Visible = true
				if ChatBTNSign == ChatBTNTrait[i][1] then
					ibbtn.Visible = false
					if ChatBTNTrait[i][2] == 1 then
						L_LobbyMain.LobbyMainWin.ctr_Create_Chat_Private.Visible = true
						L_LobbyMain.LobbyMainWin.ctr_Create_Chat_Private.Location = Vector2(TepPositon + L_LobbyMain.LobbyMainWin.ctr_ChatWin.Location.x, 561)
						TepPositon = TepPositon + 244
					else
						if ChatBTNTrait[i][2] == 2 then
							GroupListInitial()
							FileTepGroupListMember(ChatBTNTrait[i][1])
						elseif ChatBTNTrait[i][2] == 3 then
							GroupListInitial()
							FileGroupListMember(ChatBTNTrait[i][3])
						elseif ChatBTNTrait[i][2] == 4 then
							L_LobbyMain.ChannlListInivate()
							FileChannelList(L_LobbyMain.LobbyMainWin.Chat_Channl_List,14)
						elseif ChatBTNTrait[i][2] == 5 then
							
						elseif ChatBTNTrait[i][2] == 6 then
							L_LobbyMain.ChannlListInivate()
							FileTeamListMember()
						end
						L_LobbyMain.LobbyMainWin.ctr_Group_Chat_Win.Visible = true
						L_LobbyMain.LobbyMainWin.ctr_Group_Chat_Win.Location = Vector2(TepPositon + L_LobbyMain.LobbyMainWin.ctr_ChatWin.Location.x, 561)
						
						-- if parent then
							-- L_LobbyMain.LobbyMainWin.ctr_Group_Team_Win.Visible = true
							-- L_LobbyMain.LobbyMainWin.ctr_Group_Team_Win.Location = Vector2(33, 321)
							-- L_LobbyMain.LobbyMainWin.ctr_Group_Team_Win.Parent = parent
						-- end
						TepPositon = TepPositon + 408
					end
				else
					TepPositon = TepPositon + 130
				end
				for k = 1 , 10 do
					if ChatBTNTrait[i][1] == ChatInfo[k][1] then
						if ChatInfo[k][5] == 1 then
							ibbtn.blink = true
						else
							ibbtn.blink = false
						end
					end
				end
				break
			end
		end
	end
	Chat_BTN_Win_ui.Chat_BTN_Right.Location = Vector2(TepPositon , 0)
end

function ChatInfoFill(name,Text,type,Id,parent)
	if type == -1 and parent then
		for i = 1 , ChatBtn_WinNumber do
			if ChatBTNSign == ChatBTNTrait[i][1] then
				if ChatBTNTrait[i][2] ~= 1 then
					L_LobbyMain.LobbyMainWin.tarea_Chat_Team:AddText(Text)
				end
				break
			end
		end
		return
	end
	if parent then
		for i = 1 , 10 do
			if ChatInfo[i][2] == type and ((ChatInfo[i][3] == name and type ~= 2) or (type == 2 and ChatInfo[i][7] == Id)) then
				if type ~= 1 then
					L_LobbyMain.LobbyMainWin.tarea_Chat_Team:AddText(Text)
				end
				return
			end
		end
	end

	if type == -1 then
		for i = 1 , ChatBtn_WinNumber do
			if ChatBTNSign == ChatBTNTrait[i][1] then
				if ChatBTNTrait[i][2] == 1 then
					L_LobbyMain.LobbyMainWin.tarea_Private:AddText(Text)
				else
					L_LobbyMain.LobbyMainWin.tarea_Chat_Group:AddText(Text)
					L_LobbyMain.LobbyMainWin.tarea_Chat_Team:AddText(Text)
				end
				break
			end
		end
		return
	end
	if L_LobbyMain.PersonalInfo_data and name == L_LobbyMain.PersonalInfo_data.name and type == 1 then
		L_LobbyMain.LobbyMainWin.tarea_Private:AddText(Text)
		return
	end
	
	for i = 1 , 10 do
		if ChatInfo[i][2] == type and ((ChatInfo[i][3] == name and type ~= 2) or (type == 2 and ChatInfo[i][7] == Id)) then
			if ChatBTNSign == ChatInfo[i][1] then
				if type == 1 then
					L_LobbyMain.LobbyMainWin.tarea_Private:AddText(Text)
				else
					L_LobbyMain.LobbyMainWin.tarea_Chat_Group:AddText(Text)
					L_LobbyMain.LobbyMainWin.tarea_Chat_Team:AddText(Text)
				end
			else
				ChatInfo[i][4] = ChatInfo[i][4]..Text
				if string.len(ChatInfo[i][4]) > 4096 then
					ChatInfo[i][4] = SetChatInfoText(ChatInfo[i][4])
				end
				ChatInfo[i][5] = 1
				ChatBTNPOP(ChatInfo[i][1],ChatInfo[i][5])
				ArrowheadPOP()
			end
			return
		end
	end
	if name == nil then
		return
	end
	if ChatNums == 10 then
		for i = 1 , 10 do
			if ChatInfo[i][6] == 10 then
				for j = 1 , ChatBtn_WinNumber do
					if ChatBTNTrait[j][1] == ChatInfo[i][1] then
						HideChatBTN(ChatInfo[i][1],j)
						break
					end
				end
				if ChatNums == 10 then
					HideChatBTN(ChatInfo[i][1],0)
				end
				break
			end
		end
	end
	ChatNums = ChatNums + 1
	for i = 1 , 10 do
		if ChatInfo[i][1] == 0 then
			ChatInfo[i][1] = ChatNums
			ChatInfo[i][2] = type
			ChatInfo[i][3] = name
			if type == 4 then
				if Text == Channl_Text then
					ChatInfo[i][4] = Text
				else
					ChatInfo[i][4] = Channl_Text..Text
				end
			elseif type == 5 then
				if Room_Text == nil or Text == Room_Text then
					ChatInfo[i][4] = Text
				else
					ChatInfo[i][4] = Room_Text..Text
				end
			else
				ChatInfo[i][4] = Text
			end
			ChatInfo[i][5] = 1
			if ChatBTNSign == 0 then
				ChatInfo[i][6] = 1
			else
				ChatInfo[i][6] = 2
			end
			if type == 2 then
				ChatInfo[i][7] = Id
			end
			if type == 1 then
				ChatInfo[i][8] = Name_Id
			end
			SetChatInfoPRI(ChatInfo[i][6],ChatInfo[i][1],1)
			if ChatInfo[i][1] > ShowChatBTNFirst and ChatInfo[i][1] < ShowChatBTNFirst + 6 then
				ShowChatBTN(ChatInfo[i][3],ChatInfo[i][2],ChatInfo[i][1])
			end
			break
		end
	end	
	ShowRollBTN()
end

function HideChatBTN(num,which)
	if num == 0 then
		return
	end
	if ChatBTNSign ==  num then
		for i = 1 , 10 do
			if ChatBTNSign == ChatInfo[i][1] and ( ChatInfo[i][2] == 4 or ChatInfo[i][2] == 5)then
				ChatInfo[i][4] = L_LobbyMain.LobbyMainWin.tarea_Chat_Group.Text
				break
			end
		end
		ChatBTNSign = 0
	end
	local l = {0,0,0,0,0}
	for i = 1 , 10 do
		if ChatInfo[i][1] == num then
			if ChatInfo[i][1] < ChatNums then
				for j = 1 , 10 do
					if ChatInfo[j][1] > ChatInfo[i][1] then
						if ChatBTNSign == ChatInfo[j][1] then
							ChatBTNSign = ChatBTNSign - 1
						end
						for k = 1 , ChatBtn_WinNumber do
							if ChatBTNTrait[k][1] == ChatInfo[j][1] and l[k] == 0 then
								ChatBTNTrait[k][1] = ChatBTNTrait[k][1] - 1
								l[k] = 1
								break
							end
						end
						ChatInfo[j][1] = ChatInfo[j][1] - 1
					end
				end
			end
			if ChatInfo[i][1] < ShowChatBTNFirst + 1 then
				ShowChatBTNFirst = ShowChatBTNFirst - 1
				ShowRollBTN()
			end
			SetChatInfoPRI(ChatInfo[i][6],ChatInfo[i][1],-1)
			if ChatInfo[i][2] == 2 then
				if ChatInfo[i][7] == TepGroup_Id then
					Create_Friend_ui.btn_Friend_MoreNews.Enable = true
					TepGroup_Id = 0
				end
				ptr_cast(game.CurrentState):GroupLeave(ChatInfo[i][7])
				deleteTepGroupMember(ChatInfo[i][7])
			elseif ChatInfo[i][2] == 4 then
				Channl_Text = ChatInfo[i][4]
			elseif ChatInfo[i][2] == 5 then
				Room_Text = ChatInfo[i][4]
			end
			ChatInfo[i][1] = 0
			ChatInfo[i][2] = 0
			ChatInfo[i][3] = nil
			ChatInfo[i][4] = nil
			ChatInfo[i][5] = 0
			ChatInfo[i][6] = 0
			ChatInfo[i][7] = 0
			ChatInfo[i][8] = 0
			ChatNums = ChatNums - 1
			ShowRollBTN()
			break
		end
	end
	if which ~= 0 then
		local ibbtn = ptr_cast(Chat_BTN_Win_ui.ctr_Chat_BTN_Win:GetChildByIndex(which-1))
		ChatBTNTrait[which][1] = 0
		ChatBTNTrait[which][2] = 0
		ChatBTNTrait[which][3] = nil
		ibbtn.Visible = false
		ReShowChatBTN()
	end
end

function deleteTepGroupMember(Id)
	if TepGroup_Member == nil then
		return
	end
	local l = TepGroup_Member
	local lTep = nil
	if l.group_id == Id then
		TepGroup_Member = TepGroup_Member.next
		return
	end
	while l do	
		if l.group_id == Id then
			lTep.next = l.next
			return
		end
		lTep = l
		l = l.next
	end
end

function ReShowChatBTN()
	if ChatNums > ChatBtn_WinNumber - 1 then
		if ChatNums == ChatBtn_WinNumber then
			if ShowChatBTNFirst == 0 then
				for i = 1 , 10 do
					if ChatInfo[i][1] == ChatBtn_WinNumber then
						ShowChatBTN(ChatInfo[i][3],ChatInfo[i][2],ChatInfo[i][1])
						break
					end
				end
			else
				ShowChatBTNFirst = 0
				for i = 1 , 10 do
					if ChatInfo[i][1] == 1 then
						ShowChatBTN(ChatInfo[i][3],ChatInfo[i][2],ChatInfo[i][1])
						break
					end
				end
			end
		elseif ChatNums > ShowChatBTNFirst + ChatBtn_WinNumber then
			for i = 1 , 10 do
				if ChatInfo[i][1] == ShowChatBTNFirst + ChatBtn_WinNumber then
					ShowChatBTN(ChatInfo[i][3],ChatInfo[i][2],ChatInfo[i][1])
					break
				end
			end
		elseif 1 then
			ShowChatBTNFirst = ShowChatBTNFirst - 1
			ShowRollBTN()
			for i = 1 , 10 do
				if ChatInfo[i][1] == ShowChatBTNFirst + 1 then
					ShowChatBTN(ChatInfo[i][3],ChatInfo[i][2],ChatInfo[i][1])
					break
				end
			end
		end
	else
		SetChatBTNPosition()
	end
end

function SetChatInfoPRI(num,number,Add)
	for i = 1 , 10 do
		if ChatInfo[i][6] > num - 1 and ChatInfo[i][1] ~= number then
			ChatInfo[i][6] = ChatInfo[i][6] + Add
		end
	end
end

function SetBTNChatInfoPRI(num)
	if ChatBTNSign ~= 0 then
		for i = 1 , 10 do
			if ChatBTNSign == ChatInfo[i][1] then
				if ChatInfo[i][2] == 1 then
					ChatInfo[i][4] = L_LobbyMain.LobbyMainWin.tarea_Private.Text
				else
					ChatInfo[i][4] = L_LobbyMain.LobbyMainWin.tarea_Chat_Group.Text
				end
				break
			end
		end
	end
	for i = 1 , 10 do
		if ChatInfo[i][1] == num then
			ChatBTNSign = num
			for j = 1 , 10 do
				if ChatInfo[j][6] ~= 0 and ChatInfo[j][6] < ChatInfo[i][6] then
					ChatInfo[j][6] = ChatInfo[j][6] + 1
				end
			end
			ChatInfo[i][6] = 1
			break
		end
	end
end

function ShowRollBTN()
	if ChatNums > ChatBtn_WinNumber then
		Chat_BTN_Win_ui.Chat_BTN_Right.Visible = true
		Chat_BTN_Win_ui.Chat_BTN_Left.Visible = true	
		if ShowChatBTNFirst > 0 then
			Chat_BTN_Win_ui.Chat_BTN_Left.Enable = true
		else
			Chat_BTN_Win_ui.Chat_BTN_Left.Enable = false
		end
		if ChatNums > ShowChatBTNFirst + ChatBtn_WinNumber then
			Chat_BTN_Win_ui.Chat_BTN_Right.Enable = true
		else
			Chat_BTN_Win_ui.Chat_BTN_Right.Enable = false
		end
	else
		Chat_BTN_Win_ui.Chat_BTN_Right.Visible = false
		Chat_BTN_Win_ui.Chat_BTN_Left.Visible = false	
	end
	ArrowheadPOP()
end

function ReChatBTNinfoRight()
	ShowChatBTNFirst = ShowChatBTNFirst + 1
	ShowRollBTN()
	for i = 1 , ChatBtn_WinNumber do
		if ChatBTNTrait[i][1] == ShowChatBTNFirst then
			ChatBTNTrait[i][1] = 0
			ChatBTNTrait[i][2] = 0
			ChatBTNTrait[i][3] = nil
			for j = 1 , 10 do
				if ChatInfo[j][1] == ShowChatBTNFirst + ChatBtn_WinNumber then
					ShowChatBTN(ChatInfo[j ][3],ChatInfo[j][2],ChatInfo[j][1])
					break
				end
			end
			break
		end
	end
end

function ReChatBTNinfoLeft()
	ShowChatBTNFirst = ShowChatBTNFirst - 1
	ShowRollBTN()
	for i = 1 , ChatBtn_WinNumber do
		if ChatBTNTrait[i][1] == ShowChatBTNFirst + ChatBtn_WinNumber + 1 then
			ChatBTNTrait[i][1] = 0
			ChatBTNTrait[i][2] = 0
			ChatBTNTrait[i][3] = nil
			for j = 1 , 10 do
				if ChatInfo[j][1] == ShowChatBTNFirst + 1 then
					ShowChatBTN(ChatInfo[j][3],ChatInfo[j][2],ChatInfo[j][1])
					break
				end
			end
			break
		end
	end
end

function ShowChatWin(num,parent)
	for i = 1 , 10 do
		if ChatBTNTrait[num][1] == ChatInfo[i][1] then
			SetWriteWin(ChatBTNTrait[num][3],ChatBTNTrait[num][2],ChatInfo[i][7])
			SetBTNChatInfoPRI(ChatBTNTrait[num][1])
			if ChatInfo[i][2] == 1 then
				L_LobbyMain.LobbyMainWin.lb_Name.Text = ChatBTNTrait[num][3]
				L_LobbyMain.LobbyMainWin.tarea_Private.Text = ChatInfo[i][4]
				if ChatInfo[i][8] > 0 then
					L_LobbyMain.LobbyMainWin.btn_play_info.Visible = true
				else
					L_LobbyMain.LobbyMainWin.btn_play_info.Visible = false
				end
			elseif ChatInfo[i][2] == 2 then
				--临时群
				L_LobbyMain.LobbyMainWin.ctr_list_type.Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Friends/lb_chat_ico_02.dds", Vector4(0, 0, 0, 0)),
				}
				L_LobbyMain.LobbyMainWin.lb_Group_Name.Text = ChatInfo[i][3]..lang:GetText("的临时群")
				L_LobbyMain.LobbyMainWin.tarea_Chat_Group.Text = ChatInfo[i][4]
				ShowList(2,ChatInfo[i][3])
			elseif ChatInfo[i][2] == 3 then
				--群组
				L_LobbyMain.LobbyMainWin.ctr_list_type.Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Friends/lb_chat_ico_02.dds", Vector4(0, 0, 0, 0)),
				}
				L_LobbyMain.LobbyMainWin.lb_Group_Name.Text = ChatInfo[i][3]
				L_LobbyMain.LobbyMainWin.tarea_Chat_Group.Text = ChatInfo[i][4]
				ShowList(3,ChatInfo[i][3])
			elseif ChatInfo[i][2] == 4 then
				--频道
				L_LobbyMain.LobbyMainWin.ctr_list_type.Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Friends/lb_chat_ico_02.dds", Vector4(0, 0, 0, 0)),
				}
				L_LobbyMain.LobbyMainWin.lb_Group_Name.Text = ChatInfo[i][3]
				L_LobbyMain.LobbyMainWin.tarea_Chat_Group.Text = ChatInfo[i][4]
				ShowList(4,nil)
			elseif ChatInfo[i][2] == 5 then
				--房间
				L_LobbyMain.LobbyMainWin.ctr_list_type.Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Friends/lb_chat_ico_02.dds", Vector4(0, 0, 0, 0)),
				}
				L_LobbyMain.LobbyMainWin.lb_Group_Name.Text = ChatInfo[i][3]
				L_LobbyMain.LobbyMainWin.tarea_Chat_Group.Text = ChatInfo[i][4]
				ShowList(5,nil)
			elseif ChatInfo[i][2] == 6 then
				--战队
				L_LobbyMain.LobbyMainWin.ctr_list_type.Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Friends/lb_chat_ico_01.dds", Vector4(0, 0, 0, 0)),
				}
				L_LobbyMain.LobbyMainWin.lb_Group_Name.Text = ChatInfo[i][3]
				L_LobbyMain.LobbyMainWin.tarea_Chat_Group.Text = ChatInfo[i][4]
				ShowList(6,nil)
			end
			ChatInfo[i][5] = 0
			break
		end
	end
	if parent then
		chatWindow.Size = L_LobbyMain.LobbyMainWin.ctr_Team_write.Size
		chatWindow.MessageDisplaySize = Vector2(L_LobbyMain.LobbyMainWin.ctr_Team_write.Size.x,1)
		chatWindow.MessageDisplayLoc = Vector2(0,0)
		chatWindow.Parent = L_LobbyMain.LobbyMainWin.ctr_Team_write
		TeamSpeak()
		--战队
		-- L_LobbyMain.LobbyMainWin.ctr_list_Team_type.Skin = Gui.ControlSkin
		-- {
			-- BackgroundImage = Gui.Image("LobbyUI/Friends/lb_chat_ico_01.dds", Vector4(0, 0, 0, 0)),
		-- }
		-- print("L_FightTeam.my_battle_name:"..L_FightTeam.my_battle_name)
		L_LobbyMain.LobbyMainWin.lb_Team_Name.Text = L_FightTeam.team_data[2]
	end
	SetChatBTNPosition(parent)
end

function HideChatPrivateWin()
	for i = 1 , ChatBtn_WinNumber do
		if ChatBTNSign == ChatBTNTrait[i][1] then
			HideChatBTN(ChatBTNTrait[i][1],i)
			break
		end
	end
end

function ChatPrivateWinMin()
	for i = 1 , 10 do
		if ChatBTNSign == ChatInfo[i][1] then
			ChatInfo[i][4] = L_LobbyMain.LobbyMainWin.tarea_Private.Text
			break
		end
	end
	ChatBTNSign = 0
	SetChatBTNPosition()
end

function ChatGroupWinWin()
	for i = 1 , 10 do
		if ChatBTNSign == ChatInfo[i][1] then
			ChatInfo[i][4] = L_LobbyMain.LobbyMainWin.tarea_Chat_Group.Text
			break
		end
	end
	ChatBTNSign = 0
	SetChatBTNPosition()
end

function ChatBTNPOP(num,POP)
	for i = 1 , ChatBtn_WinNumber do
		if num == ChatBTNTrait[i][1] then
			local ibbtn = ptr_cast(Chat_BTN_Win_ui.ctr_Chat_BTN_Win:GetChildByIndex(i-1))
			if POP == 1 then
				ibbtn.blink = true
			else
				ibbtn.blink = false
			end
		end
	end
end
function ArrowheadPOP()
	Chat_BTN_Win_ui.Chat_BTN_Left.blink = false
	Chat_BTN_Win_ui.Chat_BTN_Right.blink = false
	if ShowChatBTNFirst > 0 then
		for i = 1 , 10 do
			if ChatInfo[i][1] < ShowChatBTNFirst + 1 and ChatInfo[i][5] == 1 then
				Chat_BTN_Win_ui.Chat_BTN_Left.blink = true
				break
			end
		end
	end
	if ChatNums > ShowChatBTNFirst + ChatBtn_WinNumber then
		for i = 1 , 10 do
			if ChatInfo[i][1] > ShowChatBTNFirst + ChatBtn_WinNumber and ChatInfo[i][5] == 1 then
				Chat_BTN_Win_ui.Chat_BTN_Right.blink = true
				break
			end
		end
	end
end

function SetWriteWin(name,type,Id)
	if type == 1 then
		chatWindow.Size = L_LobbyMain.LobbyMainWin.ctr_Private_write.Size
		chatWindow.MessageDisplaySize = Vector2(L_LobbyMain.LobbyMainWin.ctr_Private_write.Size.x,1)
		chatWindow.MessageDisplayLoc = Vector2(0,0)
		chatWindow.Parent = L_LobbyMain.LobbyMainWin.ctr_Private_write
		chatWindow:Whisper(name)
	elseif type == 2 then
		chatWindow.Size = L_LobbyMain.LobbyMainWin.ctr_Group_write.Size
		chatWindow.MessageDisplaySize = Vector2(L_LobbyMain.LobbyMainWin.ctr_Group_write.Size.x,1)
		chatWindow.MessageDisplayLoc = Vector2(0,0)
		chatWindow.Parent = L_LobbyMain.LobbyMainWin.ctr_Group_write
		chatWindow:TepGroupSpeak(Id)
	elseif type == 3 then
		chatWindow.Size = L_LobbyMain.LobbyMainWin.ctr_Group_write.Size
		chatWindow.MessageDisplaySize = Vector2(L_LobbyMain.LobbyMainWin.ctr_Group_write.Size.x,1)
		chatWindow.MessageDisplayLoc = Vector2(0,0)
		chatWindow.Parent = L_LobbyMain.LobbyMainWin.ctr_Group_write
		GroupSpeak(name)
	elseif type == 4 then
		chatWindow.Size = L_LobbyMain.LobbyMainWin.ctr_Group_write.Size
		chatWindow.MessageDisplaySize = Vector2(L_LobbyMain.LobbyMainWin.ctr_Group_write.Size.x,1)
		chatWindow.MessageDisplayLoc = Vector2(0,0)
		chatWindow.Parent = L_LobbyMain.LobbyMainWin.ctr_Group_write
		chatWindow:ChannelSpeak()
	elseif type == 5 then
		chatWindow.Size = L_LobbyMain.LobbyMainWin.ctr_Group_write.Size
		chatWindow.MessageDisplaySize = Vector2(L_LobbyMain.LobbyMainWin.ctr_Group_write.Size.x,1)
		chatWindow.MessageDisplayLoc = Vector2(0,0)
		chatWindow.Parent = L_LobbyMain.LobbyMainWin.ctr_Group_write
		chatWindow:RoomSpeak()
	elseif type == 6 then
		chatWindow.Size = L_LobbyMain.LobbyMainWin.ctr_Group_write.Size
		chatWindow.MessageDisplaySize = Vector2(L_LobbyMain.LobbyMainWin.ctr_Group_write.Size.x,1)
		chatWindow.MessageDisplayLoc = Vector2(0,0)
		chatWindow.Parent = L_LobbyMain.LobbyMainWin.ctr_Group_write
		TeamSpeak()
	end
end

function GroupSpeak(name)
	local TepNames = nil
	if L_LobbyMain.MyGroup_rpc_data[1] and L_LobbyMain.MyGroup_rpc_data[1][5] == name then
		for _,v in ipairs(L_LobbyMain.MyGroup_rpc_data) do
--			if v[6] == 1 then
				if TepNames then
					TepNames = TepNames..v[3]..","
				else
					TepNames = v[3]..","
				end
--			end
		end
	else
		for _,v in ipairs(L_LobbyMain.AddGroup_rpc_data) do
			if v[1][5] == name then
				for _,v in ipairs(v) do

					if TepNames then
						TepNames = TepNames..v[3]..","
					else
						TepNames = v[3]..","
					end

				end
				break
			end
		end
	end
	chatWindow:GroupSpeak(name,TepNames)
end

function TeamSpeak()
	local TepNames = nil
	for _,v in ipairs(Team_RPC_List) do
		if TepNames then
			TepNames = TepNames..v[4]..","
		else
			TepNames = v[4]..","
		end
	end	
	chatWindow:GroupSpeak(Team_name.." ",TepNames)
end

function CreatePrivateChat(name,type,Id,parent)
	ChatInfoFill(name,"",type,Id,parent)
	for i = 1 , 10 do
		if ChatInfo[i][2] == type and ((type == 2 and ChatInfo[i][7] == Id ) or (ChatInfo[i][3] == name and type ~= 2)) then
			if ChatInfo[i][1] < ShowChatBTNFirst + 1 then
				while ShowChatBTNFirst > ChatInfo[i][1] - 1 do
					ReChatBTNinfoLeft()
				end
			elseif ChatInfo[i][1] > ShowChatBTNFirst + ChatBtn_WinNumber then
				while ShowChatBTNFirst < ChatInfo[i][1] - ChatBtn_WinNumber do
					ReChatBTNinfoRight()
				end
			end
			for j = 1 , ChatBtn_WinNumber do
				if ChatInfo[i][1] == ChatBTNTrait[j][1] then
					ShowChatWin(j,parent)
					break
				end
			end
			return
		end
	end
end

function ShowList(num,GroupName)
	if num == 2 then
		L_LobbyMain.LobbyMainWin.Chat_Channl_List.Visible = false
		L_LobbyMain.LobbyMainWin.Chat_Room_List.Visible = false
		L_LobbyMain.LobbyMainWin.Chat_Group_List.Visible = true
		L_LobbyMain.LobbyMainWin.btn_Group_Add.Visible = false
		L_LobbyMain.LobbyMainWin.btn_Group_From.Visible = false	
		L_LobbyMain.LobbyMainWin.btn_TepGroup_Add.Visible = true
	elseif num == 3 then
		L_LobbyMain.LobbyMainWin.Chat_Group_List.Visible = true
		if L_LobbyMain.MyGroup_rpc_data[1] and GroupName == L_LobbyMain.MyGroup_rpc_data[1][5] then
			L_LobbyMain.LobbyMainWin.btn_Group_Add.Visible = true
			L_LobbyMain.LobbyMainWin.btn_Group_From.Visible = false
		else
			L_LobbyMain.LobbyMainWin.btn_Group_From.Visible = true
			L_LobbyMain.LobbyMainWin.btn_Group_Add.Visible = false
		end
		L_LobbyMain.LobbyMainWin.Chat_Channl_List.Visible = false
		L_LobbyMain.LobbyMainWin.Chat_Room_List.Visible = false
		L_LobbyMain.LobbyMainWin.btn_TepGroup_Add.Visible = false
	elseif num == 4 then
		L_LobbyMain.LobbyMainWin.Chat_Channl_List.Visible = true
		L_LobbyMain.LobbyMainWin.Chat_Room_List.Visible = false
		L_LobbyMain.LobbyMainWin.Chat_Group_List.Visible = false
		L_LobbyMain.LobbyMainWin.btn_Group_Add.Visible = false
		L_LobbyMain.LobbyMainWin.btn_Group_From.Visible = false	
		L_LobbyMain.LobbyMainWin.btn_TepGroup_Add.Visible = false		
	elseif num == 5 then
		L_LobbyMain.LobbyMainWin.Chat_Channl_List.Visible = false
		L_LobbyMain.LobbyMainWin.Chat_Room_List.Visible = true
		L_LobbyMain.LobbyMainWin.Chat_Group_List.Visible = false
		L_LobbyMain.LobbyMainWin.btn_Group_Add.Visible = false
		L_LobbyMain.LobbyMainWin.btn_Group_From.Visible = false
		L_LobbyMain.LobbyMainWin.btn_TepGroup_Add.Visible = false
	elseif num == 6 then
		L_LobbyMain.LobbyMainWin.Chat_Channl_List.Visible = true
		L_LobbyMain.LobbyMainWin.Chat_Room_List.Visible = false
		L_LobbyMain.LobbyMainWin.Chat_Group_List.Visible = false
		L_LobbyMain.LobbyMainWin.btn_Group_Add.Visible = false
		L_LobbyMain.LobbyMainWin.btn_Group_From.Visible = false	
		L_LobbyMain.LobbyMainWin.btn_TepGroup_Add.Visible = false
	end
end

function ChatPrivateMsg()
	local Name = chatWindow.SenderName
	local TepSenderMSG = chatWindow.SenderMessage
	if L_LobbyMain.Black_rpc_data then
		for _,v in ipairs(L_LobbyMain.Black_rpc_data) do
			if Name == v[3] then
				return
			end
		end
	end
	Name_Id = 0
	if chatWindow.ChatForm == 1 then
		ChatInfoFill(Name,"["..Name.."]: "..TepSenderMSG.."\n",1)		
	elseif chatWindow.ChatForm == 2 then
		ChatInfoFill(Name,lang:GetText("玩家“")..Name..lang:GetText("”不在线").."\n",1)
	elseif chatWindow.ChatForm == 3 then
		local GroupName = chatWindow.SenderGroup
		if string.find(GroupName," ") then
			if Team_name then
				ChatInfoFill(Team_name,"["..Name.."]: "..TepSenderMSG.."\n",6)
			end
		else
			if Name == "" then
				ChatInfoFill(GroupName,TepSenderMSG.."\n",3)
			else
				ChatInfoFill(GroupName,"["..Name.."]: "..TepSenderMSG.."\n",3)
			end
		end
	elseif chatWindow.ChatForm == 4 then

		if L_WarZone.main_room_list_ui == nil then
			return
		end
		if Name == "" then
			local Tepnum = string.find(TepSenderMSG,"@!")
			if Tepnum then
				local Tepname = string.sub(TepSenderMSG,1,Tepnum - 1)
				if L_LobbyMain.Black_rpc_data then
					for _,v in ipairs(L_LobbyMain.Black_rpc_data) do
						if v[3] == Tepname then
							return
						end
					end
				end
				TepSenderMSG = string.sub(TepSenderMSG,Tepnum + 2)
			end
			L_WarZone.main_room_list_ui.MesPanel_channel:AddLineNew(TepSenderMSG,0)
			if L_WarZone.room_ui then
				L_WarZone.room_ui.MesPanel_room:AddLineNew(TepSenderMSG,0)
				L_WarZone.room_ui.MesPanel_room:DirtyLines(true)
				L_WarZone.room_ui.MesPanel_room:ScrollToEnd()
			end
			if L_WarZone.match_window_ui then
				L_WarZone.match_window_ui.MesPanel_match:AddLineNew(TepSenderMSG,0)
				L_WarZone.match_window_ui.MesPanel_match:DirtyLines(true)
				L_WarZone.match_window_ui.MesPanel_match:ScrollToEnd()
			end
		else
			if Name == lang:GetText("系统公告") then
				L_WarZone.main_room_list_ui.MesPanel_channel:AddLineNew("["..Name.."]: "..TepSenderMSG,0)
				if L_WarZone.room_ui then
					L_WarZone.room_ui.MesPanel_room:AddLineNew("["..Name.."]: "..TepSenderMSG,0)
					L_WarZone.room_ui.MesPanel_room:DirtyLines(true)
					L_WarZone.room_ui.MesPanel_room:ScrollToEnd()
				end
				if L_WarZone.match_window_ui then
					L_WarZone.match_window_ui.MesPanel_match:AddLineNew("["..Name.."]: "..TepSenderMSG,0)
					L_WarZone.match_window_ui.MesPanel_match:DirtyLines(true)
					L_WarZone.match_window_ui.MesPanel_match:ScrollToEnd()
				end
			else
				L_WarZone.main_room_list_ui.MesPanel_channel:AddLineNew("["..Name.."]: "..TepSenderMSG,1)
				if L_WarZone.room_ui then
					L_WarZone.room_ui.MesPanel_room:AddLineNew("["..Name.."]: "..TepSenderMSG,1)
					L_WarZone.room_ui.MesPanel_room:DirtyLines(true)
					L_WarZone.room_ui.MesPanel_room:ScrollToEnd()
				end
				
				if L_WarZone.match_window_ui then
					L_WarZone.match_window_ui.MesPanel_match:AddLineNew("["..Name.."]: "..TepSenderMSG,1)
					L_WarZone.match_window_ui.MesPanel_match:DirtyLines(true)
					L_WarZone.match_window_ui.MesPanel_match:ScrollToEnd()
				end
			end
		end
		L_WarZone.main_room_list_ui.MesPanel_channel:DirtyLines(true)
		L_WarZone.main_room_list_ui.MesPanel_channel:ScrollToEnd()
	elseif chatWindow.ChatForm == 5 then
		if Name == "" then	
			--ChatInfoFill(room_name,TepSenderMSG.."\n",5)
			if L_WarZone.match_window_ui == nil then
				L_WarZone.room_ui.MesPanel_room:AddLineNew(TepSenderMSG,0)
			else
				L_WarZone.match_window_ui.MesPanel_match:AddLineNew(TepSenderMSG,0)
			end
		else
			--ChatInfoFill(room_name,Name..": "..TepSenderMSG.."\n",5)
			if L_WarZone.match_window_ui == nil then
				L_WarZone.room_ui.MesPanel_room:AddLineNew("["..Name.."]: "..TepSenderMSG,1)
			else
				L_WarZone.match_window_ui.MesPanel_match:AddLineNew("["..Name.."]: "..TepSenderMSG,1)
			end
		end
		if L_WarZone.match_window_ui == nil then
			L_WarZone.room_ui.MesPanel_room:DirtyLines(true)
			L_WarZone.room_ui.MesPanel_room:ScrollToEnd()
		else	
			L_WarZone.match_window_ui.MesPanel_match:DirtyLines(true)
			L_WarZone.match_window_ui.MesPanel_match:ScrollToEnd()
		end
	elseif chatWindow.ChatForm == 6 then
		local Group_id = chatWindow.SenderGroup_id
		if Name ~= "" then
			ChatInfoFill(nil , "["..Name.."]: "..TepSenderMSG.."\n" , 2 ,Group_id)
		else
			ChatInfoFill(nil , TepSenderMSG.."\n" , 2 , Group_id)
		end
	elseif chatWindow.ChatForm == -1 then
		if chatWindow.Private_Chat then
			if ChatBTNSign ~= 0 then
				ChatInfoFill(nil,lang:GetText("您说话过快。\n"),-1)
			end
		else
			if L_WarZone.main_room_list_ui then
				L_WarZone.main_room_list_ui.MesPanel_channel:AddLineNew(lang:GetText("您说话过快。"),0)
				L_WarZone.main_room_list_ui.MesPanel_channel:DirtyLines(true)
				L_WarZone.main_room_list_ui.MesPanel_channel:ScrollToEnd()
			end
			if L_WarZone.room_ui then
				L_WarZone.room_ui.MesPanel_room:AddLineNew(lang:GetText("您说话过快。"),0)
				L_WarZone.room_ui.MesPanel_room:DirtyLines(true)
				L_WarZone.room_ui.MesPanel_room:ScrollToEnd()
			end
			if L_WarZone.match_window_ui then
				L_WarZone.match_window_ui.MesPanel_match:AddLineNew(lang:GetText("您说话过快。"),0)
				L_WarZone.match_window_ui.MesPanel_match:DirtyLines(true)
				L_WarZone.match_window_ui.MesPanel_match:ScrollToEnd()
			end
		end
	elseif chatWindow.ChatForm == 9 then
		if config.Invite == true then
			chatWindow:RefuseInvite(Name)
			return
		end
		if L_WarZone.is_novice == true then
			return
		end
		if L_WarZone.host_character_info and L_WarZone.host_character_info.is_host == false and L_WarZone.host_character_info.ready then
			return
		end
		if L_LobbyMain.On_Invite_State == false then
			return
		end
		local state = ptr_cast(game.CurrentState)
		if state.is_fight_team_server then
			return
		end
		local str
		if L_WarZone.matchTime_window_ui then
			return
		end
		if L_WarZone.matchTime_window then
			return
		end
		local flag = false
		if chatWindow.Servertype ~= 6 and chatWindow.Servertype ~= 7 then
			str = lang:GetText("\n邀请你进入TA的房间")
			flag = false
		else
			str = lang:GetText("\n邀请你进入匹配的房间")
			flag = true
		end
			MessageBox.ShowWithTimers(5,Name..str ,lang:GetText("接 受") ,lang:GetText("拒 绝") ,
												function()
													L_WarZone.is_invite = true
													L_WarZone.is_invite1 = true
													state.Is_in_invite = flag
													state.Is_in_invite1 = flag
													L_LobbyMain.GotoPlayerRoom(Name,true)
												end,
												function() 
													chatWindow:RefuseInvite(Name)
												end)
		
								
		 -- end										
	elseif chatWindow.ChatForm == -10 then
		 MessageBox.ShowWithTimer(1,lang:GetText("对不起，您已经被禁言。\n\n详细信息请与客服联系。"))
	end
end

--创建房间聊天组
function CreateChatRoom(roomName)
	if roomName then
		if room_name == nil then
			L_LobbyMain.LobbyMainWin.Chat_Room_List:DeleteColumns()
			L_LobbyMain.LobbyMainWin.Chat_Room_List:AddColumn("", 15, "kAlignCenterMiddle")
			L_LobbyMain.LobbyMainWin.Chat_Room_List:AddColumn("", 170, "kAlignLeftMiddle")
			
			room_name = roomName.." "
			Room_Text = nil
			
			if Channel_name then
				HideChatInfo(Channel_name,4)
				Channel_name = nil
			end
			
			L_Friends.ChatInfoFill(room_name,"",5)
		
			CreatePrivateChat(room_name,5)			
		end
	else
		if room_name then
			HideChatInfo(room_name,5)
			room_name = nil
		end
	end
	
	if Create_Friend_ui then
		L_Friends.FileGroupList(L_LobbyMain.MyGroup_rpc_data,L_LobbyMain.AddGroup_rpc_data)
	end
	
	if room_name then
		FileRoomList()
	end
end

--更新房间群组信息
function UpdateRoomInfo(roomName)
	room_name = roomName.." "
	if Create_Friend_ui then
		L_Friends.FileGroupList(L_LobbyMain.MyGroup_rpc_data,L_LobbyMain.AddGroup_rpc_data)
	end
	for i = 1 , 10 do
		if ChatInfo[i][2] == 5 then
			ChatInfo[i][3] = room_name
			if ChatBTNSign == ChatInfo[i][1] then
				L_LobbyMain.LobbyMainWin.lb_Group_Name.Text = ChatInfo[i][3]
			end
			break
		end
	end
	for i = 1 , ChatBtn_WinNumber do
		if ChatBTNTrait [i][2] == 5 then
			ChatBTNTrait [i][3] = room_name
			local ibbtn = ptr_cast(Chat_BTN_Win_ui.ctr_Chat_BTN_Win:GetChildByIndex(i - 1))
			ibbtn.Text = room_name
			break
		end
	end
end

function HideChatInfo(name,type,num)
	if type == 2 then
		for i = 1 , 10 do
			if ChatInfo[i][2] == type and ChatInfo[i][7] == num then
				for j = 1 , ChatBtn_WinNumber do
					if ChatBTNTrait[j][1] == ChatInfo[i][1] then
						HideChatBTN(ChatInfo[i][1],j)
						return
					end
				end
				HideChatBTN(ChatInfo[i][1],0)
				return
			end
		end
		return
	end
	for i = 1 , 10 do
		if ChatInfo[i][2] == type and ChatInfo[i][3] == name then
			for j = 1 , ChatBtn_WinNumber do
				if ChatBTNTrait[j][1] == ChatInfo[i][1] then
					HideChatBTN(ChatInfo[i][1],j)
					return
				end
			end
			HideChatBTN(ChatInfo[i][1],0)
			return
		end
	end
end

--群组列表初始化
function GroupListInitial()
	L_LobbyMain.LobbyMainWin.Chat_Group_List:DeleteColumns()
	L_LobbyMain.LobbyMainWin.Chat_Group_List:AddColumn("", 15, "kAlignCenterMiddle")
	L_LobbyMain.LobbyMainWin.Chat_Group_List:AddColumn("", 170, "kAlignLeftMiddle")
end

--填写群组成员列表
function FileGroupListMember(GroupName)
	local data = nil
	if L_LobbyMain.MyGroup_rpc_data and L_LobbyMain.MyGroup_rpc_data[1] and GroupName == L_LobbyMain.MyGroup_rpc_data[1][5] then
		data = L_LobbyMain.MyGroup_rpc_data
	else
		if L_LobbyMain.AddGroup_rpc_data and L_LobbyMain.AddGroup_rpc_data[1] then
			for _,v in ipairs(L_LobbyMain.AddGroup_rpc_data) do
				if v[1][5] == GroupName then
					data = v
					break
				end
			end
		else
			return
		end
	end
	
	local roomlist = L_LobbyMain.LobbyMainWin.Chat_Group_List
	local root = L_LobbyMain.LobbyMainWin.Chat_Group_List.RootItem
	local Add = 1
	local item = nil
	roomlist:DeleteAll()
	if data then
		for _,v in ipairs(data) do
			item = roomlist:AddItem(root)
			item.CanSelect = true			
			Setbusiness_card(item,v[8],v[7])			
			Add = Add + 1
			item.FontSize = 14
			-- SetVipIcon(item,v[7],0,v[9],"_min",v[8])
			if v[7] > 0 then
				item.TextColor = ARGB(255, 255, 210, 2)
				item.HighlightTextColor = ARGB(255, 255, 210, 2)
			elseif v[8] ~= nil and v[8] ~= 0 then
				item.TextColor = ARGB(255, 216, 217, 208)
				item.HighlightTextColor = ARGB(255, 216, 217, 208)
			else
				item.TextColor = ARGB(255, 37, 37, 37)
				item.HighlightTextColor = ARGB(255, 37, 37, 37)
			end
			item:SetText(1,v[3])
			item.NeedProjection = false
		end
	end
	if Add < 8 then
		for i=Add, 7 do
			item = roomlist:AddItem(root,i)
			item.CanSelect = false
			item.BGSkin = Skin.ListItemSkin_Friends

			item:SetText(0,"")
			item:SetText(1,"")
		end
	end
end


--填写临时群组列表
function FileTepGroupListMember(num)
	local roomlist = L_LobbyMain.LobbyMainWin.Chat_Group_List
	local root = L_LobbyMain.LobbyMainWin.Chat_Group_List.RootItem
	local Add = 1
	local item = nil
	roomlist:DeleteAll()	
	for i = 1 , 10 do
		if ChatInfo[i][1] == num then
			local l = TepGroup_Member
			while l do
				if l.group_id == ChatInfo[i][7] then
					for j = 1 , 5 do
						if l.member_id[j] == 0 then
							break
						end
						item = roomlist:AddItem(root)
						Add = Add + 1
						item.CanSelect = true					
						Setbusiness_card(item,l.business_card[j],l.is_vip[j])						
						item.FontSize = 14
						-- SetVipIcon(item,l.is_vip[j],0,l.net_bar_level[j],"_min",l.business_card[j])
						if l.is_vip[j] > 0 then
							item.TextColor = ARGB(255, 255, 210, 2)
							item.HighlightTextColor = ARGB(255, 255, 210, 2)
						elseif l.business_card[j] ~= nil and l.business_card[j] ~= 0 then
							item.TextColor = ARGB(255, 216, 217, 208)
							item.HighlightTextColor = ARGB(255, 216, 217, 208)
						else
							item.TextColor = ARGB(255, 37, 37, 37)
							item.HighlightTextColor = ARGB(255, 37, 37, 37)
						end
						item:SetText(1,l.member[j])
						item.NeedProjection = false
					end
					break
				end
				l = l.next
			end
		end
	end
	
	if Add < 7 then
		for i=Add, 6 do
			item = roomlist:AddItem(root,i)
			item.CanSelect = false
			item.BGSkin = Skin.ListItemSkin_Friends
			item:SetText(0,"")
			item:SetText(1,"")
		end
	end
end

--填写战队成员列表
function FileTeamListMember()
	if Team_RPC_List == nil then
		return
	end
	local roomlist = L_LobbyMain.LobbyMainWin.Chat_Channl_List
	local root = L_LobbyMain.LobbyMainWin.Chat_Channl_List.RootItem
	local Add = 1
	local item = nil
	roomlist:DeleteAll()	
	for _,v in ipairs(Team_RPC_List) do
		item = roomlist:AddItem(root)
		Add = Add + 1
		item.CanSelect = true		
		Setbusiness_card(item,v[13],v[12])		
		item.FontSize = 14
		-- SetVipIcon(item,v[12],0,v[14],"_min",v[13])
		if v[12] > 0 then
			item.TextColor = ARGB(255, 255, 210, 2)
			item.HighlightTextColor = ARGB(255, 255, 210, 2)
		elseif v[13] ~= nil and v[13] ~= 0 then
			item.TextColor = ARGB(255, 216, 217, 208)
			item.HighlightTextColor = ARGB(255, 216, 217, 208)
		else
			item.TextColor = ARGB(255, 37, 37, 37)
			item.HighlightTextColor = ARGB(255, 37, 37, 37)
		end
		
		if v[5] == 0 then
			item.SpecialA = true
			item.TextColor = ARGB(255, 126, 124, 125)
		else
			item.SpecialA = false
		end
		item:SetText(1,v[4])
		item.NeedProjection = false
	end
	
	if Add < 8 then
		for i=Add, 7 do
			item = roomlist:AddItem(root,i)
			item.CanSelect = false
			item.BGSkin = Skin.ListItemSkin_Friends
			item:SetText(0,"")
			item:SetText(1,"")
		end
	end
end

--获得群组列表
function GetGroupList()
	for i = 1 , ChatBtn_WinNumber do
		if ChatBTNTrait[i][1] == ChatBTNSign then
			if L_LobbyMain.MyGroup_rpc_data and L_LobbyMain.MyGroup_rpc_data[1] and ChatBTNTrait[i][3] == L_LobbyMain.MyGroup_rpc_data[1][5] then
				return L_LobbyMain.MyGroup_rpc_data
			else
				for _,v in ipairs(L_LobbyMain.AddGroup_rpc_data) do
					if v[1][5] == ChatBTNTrait[i][3] then
						return v
					end
				end
			end
		end
	end
end

--获得临时群组列表
function GetTepGroupList()
	for i = 1 , 10 do
		if ChatInfo[i][1] == ChatBTNSign then
			local l = TepGroup_Member
			while l do
				if l.group_id == ChatInfo[i][7] then
					return l
				end
				l = l.next
			end
		end
	end
end

--获得战队信息
function GetTeamInfo()
	rpc.safecall("team_info",{pid = ptr_cast(game.CurrentState):GetCharacterId()},
	function(data)
		if data.team[1] then
			rpc.safecall("team_member_all",{pid = ptr_cast(game.CurrentState):GetCharacterId(),tid = data.team[1]},TeamInfo)
		else
			if Team_name then
				L_Friends.ShowLeaveOwnGroupCreateWin(gui,lang:GetText("您已离开").."“"..Team_name.."”"..lang:GetText("战队！"))
				L_FightTeam.HideQuickBuy()
				L_FightTeam.HideRapidShoppingWin()
				if L_FightTeam.fightteam_fight_window then
					L_FightTeam.HideFightTeam()
					L_FightTeam.HideBattleTime()					
					local state = ptr_cast(game.CurrentState)
					if state then
						state.battle_is_create = false
						L_FightTeam.battle_ready = false
						state:LeaveChannel()
						state:BattleGroupLeave(L_FightTeam.my_battle_info.battlegroup_id)
					end
				end
				L_FightTeam.allteam_source_ui.allteam.Visible = false
				L_FightTeam.FillTeam()
			else
				return
			end
			Team_name = nil
			Team_name_Add = nil
			Team_RPC_List = nil
			if L_Friends.Create_Friend_ui then
				L_Friends.FileGroupList(L_LobbyMain.MyGroup_rpc_data,L_LobbyMain.AddGroup_rpc_data)
			end
			for i = 1 , 10 do
				if ChatInfo[i][2] == 6 then
					for j = 1 , ChatBtn_WinNumber do
						if L_Friends.ChatBTNTrait[j][1] == ChatInfo[i][1] then
							L_Friends.HideChatBTN(ChatInfo[i][1],j)
							return
						end
					end
					L_Friends.HideChatBTN(ChatInfo[i][1],0)
					break
				end
			end
		end
	end
	)
end

function TeamInfo(data)
	Team_name = data.team[2]
	Team_name_Add = " "..data.team[2].." "
	Team_RPC_List = data.team.member
	for i = 1 , 10 do
		if L_Friends.ChatInfo[i][2] == 6 then
			L_Friends.ChatInfo[i][3] = Team_name
			break
		end
	end
	for i = 1 , ChatBtn_WinNumber do
		if L_Friends.ChatBTNTrait[i][2] == 6 then
			L_Friends.ChatBTNTrait[i][3] = Team_name
			local ibbtn = ptr_cast(Chat_BTN_Win_ui.ctr_Chat_BTN_Win:GetChildByIndex(i - 1))
			ibbtn.Text = Team_name
			if L_Friends.ChatBTNSign == L_Friends.ChatBTNTrait[i][1] then
				L_LobbyMain.LobbyMainWin.lb_Group_Name.Text = Team_name
				L_Friends.FileTeamListMember()
				L_Friends.TeamSpeak()
				break
			end
		end
	end
	if L_Friends.Create_Friend_ui then
		L_Friends.FileGroupList(L_LobbyMain.MyGroup_rpc_data,L_LobbyMain.AddGroup_rpc_data)
	end
end

--邀请游戏弹出框

local Chilst = nil

local Create_InviteGame_Win =
{
	Gui.Control"ctr_InviteGame_Win"
	{
		Size = Vector2(1600, 900),
		BackgroundColor = ARGB(255, 255, 255, 255),
		
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/lb_common_black_bg.dds", Vector4(0, 0, 0, 0)),
		},
		
		Gui.Control
		{
			Size = Vector2(480, 361),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Location = Vector2(662, 306),
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_bg1.dds", Vector4(28, 28, 28, 28)),
			},
			
			--退出
			Gui.Button
			{
				Size = Vector2(20,20),
				Location = Vector2(440, 9),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_buttonX_normal.dds", Vector4(0, 0, 0, 0)),
					HoverImage = Gui.Image("LobbyUI/Friends/lb_contact_buttonX_hover.dds", Vector4(0, 0, 0, 0)),
					DownImage = Gui.Image("LobbyUI/Friends/lb_contact_buttonX_down.dds", Vector4(0, 0, 0, 0)),
					DisabledImage = Gui.Image("LobbyUI/Friends/lb_contact_buttonX_normal.dds", Vector4(0, 0, 0, 0)),
				},
				EventClick = function()
					HideInviteGameWin()
				end,
			},
			
			Gui.Control
			{
				Size = Vector2(462, 310),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Location = Vector2(9, 42),
				
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_bg2.dds", Vector4(21, 25, 21, 46)),
				},
				
				--频道列表
				Gui.ListTreeView "list_Channel_Invite"
				{
					Location = Vector2(4, 4),
					Size = Vector2(445, 260),
					Style = "Gui.ListTreeViewWith_VScroll_Channl",
					HeaderVisible = false,
					CheckIndex = 0,
					Visible = false,
					
					ItemHeight = 32,
					FontSize = 14,
					TextColor = ARGB(255, 37, 37, 37),
					VScrollBarDisplay = "kVisible",
					VScrollBarWidth = 8,
					VScrollBarButtonSize = 1,
					HScrollBarWidth = 8,
					VScrollBarPos = Vector2(0, 0),
				},	
				
				--好友列表
				Gui.ListTreeView "list_Friends_Invite"
				{
					Location = Vector2(4, 4),
					Size = Vector2(445, 260),
					Style = "Gui.ListTreeViewWith_VScroll_Channl",
					HeaderVisible = false,
					CheckIndex = 0,
					Visible = false,
					
					ItemHeight = 32,
					FontSize = 14,
					TextColor = ARGB(255, 37, 37, 37),
					VScrollBarDisplay = "kVisible",
					VScrollBarWidth = 8,
					VScrollBarButtonSize = 1,
					HScrollBarWidth = 8,
					VScrollBarPos = Vector2(0, 0),
				},	
				
				--陌生人列表
				Gui.ListTreeView "list_Stranger_Invite"
				{
					Location = Vector2(4, 4),
					Size = Vector2(445, 260),
					Style = "Gui.ListTreeViewWith_VScroll_Channl",
					HeaderVisible = false,
					CheckIndex = 0,
					Visible = false,
					
					ItemHeight = 32,
					FontSize = 14,
					TextColor = ARGB(255, 37, 37, 37),
					VScrollBarDisplay = "kVisible",
					VScrollBarWidth = 8,
					VScrollBarButtonSize = 1,
					HScrollBarWidth = 8,
					VScrollBarPos = Vector2(0, 0),
				},	
				
				--邀请
				Gui.Button
				{
					Location = Vector2(45, 270),
					Size = Vector2(150, 36),
					BackgroundColor = ARGB(255,255,255,255),
					Text = lang:GetText("邀 请"),
					FontSize = 20,
					TextAlign = "kAlignCenterMiddle",
					TextColor = ARGB(255,211,211,211),
					HighlightTextColor = ARGB(255, 211 ,211 ,211),
					Padding = Vector4(0, 0, 0, 4),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_button_normal.tga", Vector4(14, 14, 14, 14)),
						HoverImage = Gui.Image("LobbyUI/Friends/lb_contact_button_hover.tga", Vector4(14, 14, 14, 14)),
						DownImage = Gui.Image("LobbyUI/Friends/lb_contact_button_down.tga", Vector4(14, 14, 14, 14)),
						DisabledImage = Gui.Image("LobbyUI/Friends/lb_contact_button_normal.tga", Vector4(14, 14, 14, 14)),
					},
					EventClick = function()
						--MessageBox.ShowWithConfirmCancel(lang:GetText("还在制作中？"), nil)
						Chilst = nil
						InviteListScan(Create_InviteGame_Win_ui.list_Channel_Invite)
						InviteListScan(Create_InviteGame_Win_ui.list_Friends_Invite)
						InviteListScan(Create_InviteGame_Win_ui.list_Stranger_Invite)
						if Chilst == nil then
							ShowLeaveOwnGroupCreateWin(gui,lang:GetText("您至少选中一名玩家！"))
							return
						end
						SendInvite()
						HideInviteGameWin()
					end
				},
				
				--取消
				Gui.Button
				{
					Location = Vector2(245, 270),
					Size = Vector2(150, 36),
					BackgroundColor = ARGB(255,255,255,255),
					Text = lang:GetText("取 消"),
					FontSize = 20,
					TextAlign = "kAlignCenterMiddle",
					TextColor = ARGB(255,211,211,211),
					HighlightTextColor = ARGB(255, 211 ,211 ,211),
					Padding = Vector4(0, 0, 0, 4),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_button_normal.tga", Vector4(14, 14, 14, 14)),
						HoverImage = Gui.Image("LobbyUI/Friends/lb_contact_button_hover.tga", Vector4(14, 14, 14, 14)),
						DownImage = Gui.Image("LobbyUI/Friends/lb_contact_button_down.tga", Vector4(14, 14, 14, 14)),
						DisabledImage = Gui.Image("LobbyUI/Friends/lb_contact_button_normal.tga", Vector4(14, 14, 14, 14)),
					},
					EventClick = function()
						--MessageBox.ShowWithConfirmCancel(lang:GetText("还在制作中？"), nil)
						HideInviteGameWin()
					end
				},
			},
			Gui.Button "btn_Channl_Invite"
			{
				Size = Vector2(140, 31),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Location = Vector2(15, 14),
				Text = lang:GetText("频道内玩家"),
				TextColor = ARGB(255, 52, 50, 50),
				FontSize = 13,
				HighlightTextColor = ARGB(255, 52, 50, 50),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_tab1_normal.dds", Vector4(10, 0, 10, 0)),
					HoverImage = Gui.Image("LobbyUI/Friends/lb_contact_tab1_hover.dds", Vector4(10, 0, 10, 0)),
					DownImage = Gui.Image("LobbyUI/Friends/lb_contact_tab1_down.dds", Vector4(10, 0, 10, 0)),
					DisabledImage = Gui.Image("LobbyUI/Friends/lb_contact_tab1_normal.dds", Vector4(10, 0, 10, 0)),
				},

				EventClick = function()
					SetInviteListVisible(1)
				end
			},
			
			Gui.Button "btn_Friends_Invite"
			{
				Size = Vector2(140, 31),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Location = Vector2(155, 14),
				Text = lang:GetText("好 友"),
				TextColor = ARGB(255, 52, 50, 50),
				FontSize = 13,
				HighlightTextColor = ARGB(255, 52, 50, 50),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_tab1_normal.dds", Vector4(10, 0, 10, 0)),
					HoverImage = Gui.Image("LobbyUI/Friends/lb_contact_tab1_hover.dds", Vector4(10, 0, 10, 0)),
					DownImage = Gui.Image("LobbyUI/Friends/lb_contact_tab1_down.dds", Vector4(10, 0, 10, 0)),
					DisabledImage = Gui.Image("LobbyUI/Friends/lb_contact_tab1_normal.dds", Vector4(10, 0, 10, 0)),
				},

				EventClick = function()
					SetInviteListVisible(2)
				end
			},
			
			Gui.Button "btn_Stranger_Invite"
			{
				Size = Vector2(140, 31),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Location = Vector2(295, 14),
				Text = lang:GetText("战队成员"),
				-- Enable = false,
				TextColor = ARGB(255, 52, 50, 50),
				FontSize = 13,
				HighlightTextColor = ARGB(255, 52, 50, 50),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_tab1_normal.dds", Vector4(10, 0, 10, 0)),
					HoverImage = Gui.Image("LobbyUI/Friends/lb_contact_tab1_hover.dds", Vector4(10, 0, 10, 0)),
					DownImage = Gui.Image("LobbyUI/Friends/lb_contact_tab1_down.dds", Vector4(10, 0, 10, 0)),
					DisabledImage = Gui.Image("LobbyUI/Friends/lb_contact_tab1_normal.dds", Vector4(10, 0, 10, 0)),
				},

				EventClick = function()
					SetInviteListVisible(3)
				end
			},
		},
	},
}
function ShowInviteGameCreatematchWinmatch(win_parent)
	L_WarZone.automatic_match_ui.btn_invite.PushDown = true
	
	if Create_InviteGame_Win_ui then
		Create_InviteGame_Win_ui.ctr_InviteGame_Win.Parent = win_parent
		AlignUI()
		InitialList()
		--L_LobbyMain.GetPartnerList(2)
		FillInviteFriendsList(L_LobbyMain.Friends_rpc_data ,L_Friends.Create_InviteGame_Win_ui.list_Friends_Invite)
		FillInviteTeamMemberList(Team_RPC_List,L_Friends.Create_InviteGame_Win_ui.list_Stranger_Invite)
		FillInviteChannelList()
		SetInviteListVisible(1)
		return
	end
	
		--创建聊天组群框
	Create_InviteGame_Win_ui = Gui.Create(win_parent)(Create_InviteGame_Win)
	AlignUI()
	InitialList()
	--L_LobbyMain.GetPartnerList(2)
	FillInviteFriendsList(L_LobbyMain.Friends_rpc_data ,L_Friends.Create_InviteGame_Win_ui.list_Friends_Invite)
	FillInviteTeamMemberList(Team_RPC_List,L_Friends.Create_InviteGame_Win_ui.list_Stranger_Invite)
	FillInviteChannelList()
	SetInviteListVisible(1)
end



function ShowInviteGameCreatematchWin(win_parent)
	L_WarZone.match_window_ui.btn_invite.PushDown = true
	
	if Create_InviteGame_Win_ui then
		Create_InviteGame_Win_ui.ctr_InviteGame_Win.Parent = win_parent
		AlignUI()
		InitialList()
		--L_LobbyMain.GetPartnerList(2)
		FillInviteFriendsList(L_LobbyMain.Friends_rpc_data ,L_Friends.Create_InviteGame_Win_ui.list_Friends_Invite)
		FillInviteTeamMemberList(Team_RPC_List,L_Friends.Create_InviteGame_Win_ui.list_Stranger_Invite)
		FillInviteChannelList()
		SetInviteListVisible(1)
		return
	end
	
		--创建聊天组群框
	Create_InviteGame_Win_ui = Gui.Create(win_parent)(Create_InviteGame_Win)
	AlignUI()
	InitialList()
	--L_LobbyMain.GetPartnerList(2)
	FillInviteFriendsList(L_LobbyMain.Friends_rpc_data ,L_Friends.Create_InviteGame_Win_ui.list_Friends_Invite)
	FillInviteTeamMemberList(Team_RPC_List,L_Friends.Create_InviteGame_Win_ui.list_Stranger_Invite)
	FillInviteChannelList()
	SetInviteListVisible(1)
end


function ShowInviteGameCreateWin(win_parent)
	L_WarZone.room_ui.btn_invite.PushDown = true
	if Create_InviteGame_Win_ui then
		Create_InviteGame_Win_ui.ctr_InviteGame_Win.Parent = win_parent
		AlignUI()
		InitialList()
		--L_LobbyMain.GetPartnerList(2)
		FillInviteFriendsList(L_LobbyMain.Friends_rpc_data ,L_Friends.Create_InviteGame_Win_ui.list_Friends_Invite)
		FillInviteTeamMemberList(Team_RPC_List,L_Friends.Create_InviteGame_Win_ui.list_Stranger_Invite)
		FillInviteChannelList()
		SetInviteListVisible(1)
		return
	end
	
	--创建聊天组群框
	Create_InviteGame_Win_ui = Gui.Create(win_parent)(Create_InviteGame_Win)
	AlignUI()
	InitialList()
	--L_LobbyMain.GetPartnerList(2)
	FillInviteFriendsList(L_LobbyMain.Friends_rpc_data ,L_Friends.Create_InviteGame_Win_ui.list_Friends_Invite)
	FillInviteTeamMemberList(Team_RPC_List,L_Friends.Create_InviteGame_Win_ui.list_Stranger_Invite)
	FillInviteChannelList()
	SetInviteListVisible(1)
end

function HideInviteGameWin()
	if Create_InviteGame_Win_ui then
		Create_InviteGame_Win_ui.ctr_InviteGame_Win.Parent = nil
	end
	if L_WarZone.room_ui then
		L_WarZone.room_ui.btn_invite.PushDown = false
	end
	if L_WarZone.match_window_ui then
		L_WarZone.match_window_ui.btn_invite.PushDown = false
	end
	if L_WarZone.automatic_match_ui then
		L_WarZone.automatic_match_ui.btn_invite.PushDown = false
	end
end

function SetInviteListVisible(which)
	if which == 1 then
		Create_InviteGame_Win_ui.list_Channel_Invite.Visible = true
		Create_InviteGame_Win_ui.list_Friends_Invite.Visible = false
		Create_InviteGame_Win_ui.list_Stranger_Invite.Visible = false
		Create_InviteGame_Win_ui.btn_Stranger_Invite.PushDown = false
		Create_InviteGame_Win_ui.btn_Friends_Invite.PushDown = false
		Create_InviteGame_Win_ui.btn_Channl_Invite.PushDown = true
		Create_InviteGame_Win_ui.btn_Channl_Invite.TextColor = ARGB(255, 255, 246, 235)
		Create_InviteGame_Win_ui.btn_Channl_Invite.HighlightTextColor = ARGB(255, 255, 246, 235)
		Create_InviteGame_Win_ui.btn_Friends_Invite.TextColor = ARGB(255, 52, 50, 50)
		Create_InviteGame_Win_ui.btn_Friends_Invite.HighlightTextColor = ARGB(255, 52, 50, 50)
		Create_InviteGame_Win_ui.btn_Stranger_Invite.TextColor = ARGB(255, 52, 50, 50)
		Create_InviteGame_Win_ui.btn_Stranger_Invite.HighlightTextColor = ARGB(255, 52, 50, 50)
	elseif which == 2 then
		Create_InviteGame_Win_ui.list_Channel_Invite.Visible = false
		Create_InviteGame_Win_ui.list_Friends_Invite.Visible = true
		Create_InviteGame_Win_ui.list_Stranger_Invite.Visible = false
		Create_InviteGame_Win_ui.btn_Stranger_Invite.PushDown = false
		Create_InviteGame_Win_ui.btn_Friends_Invite.PushDown = true
		Create_InviteGame_Win_ui.btn_Channl_Invite.PushDown = false
		Create_InviteGame_Win_ui.btn_Friends_Invite.TextColor = ARGB(255, 255, 246, 235)
		Create_InviteGame_Win_ui.btn_Friends_Invite.HighlightTextColor = ARGB(255, 255, 246, 235)
		Create_InviteGame_Win_ui.btn_Channl_Invite.TextColor = ARGB(255, 52, 50, 50)
		Create_InviteGame_Win_ui.btn_Channl_Invite.HighlightTextColor = ARGB(255, 52, 50, 50)
		Create_InviteGame_Win_ui.btn_Stranger_Invite.TextColor = ARGB(255, 52, 50, 50)
		Create_InviteGame_Win_ui.btn_Stranger_Invite.HighlightTextColor = ARGB(255, 52, 50, 50)
	elseif which == 3 then
		Create_InviteGame_Win_ui.list_Channel_Invite.Visible = false
		Create_InviteGame_Win_ui.list_Friends_Invite.Visible = false
		Create_InviteGame_Win_ui.list_Stranger_Invite.Visible = true
		Create_InviteGame_Win_ui.btn_Stranger_Invite.PushDown = true
		Create_InviteGame_Win_ui.btn_Friends_Invite.PushDown = false
		Create_InviteGame_Win_ui.btn_Channl_Invite.PushDown = false
		Create_InviteGame_Win_ui.btn_Stranger_Invite.TextColor = ARGB(255, 255, 246, 235)
		Create_InviteGame_Win_ui.btn_Stranger_Invite.HighlightTextColor = ARGB(255, 255, 246, 235)
		Create_InviteGame_Win_ui.btn_Friends_Invite.TextColor = ARGB(255, 52, 50, 50)
		Create_InviteGame_Win_ui.btn_Friends_Invite.HighlightTextColor = ARGB(255, 52, 50, 50)
		Create_InviteGame_Win_ui.btn_Channl_Invite.TextColor = ARGB(255, 52, 50, 50)
		Create_InviteGame_Win_ui.btn_Channl_Invite.HighlightTextColor = ARGB(255, 52, 50, 50)
	end
end

function InitialList()
	if Create_InviteGame_Win_ui then
		Create_InviteGame_Win_ui.list_Channel_Invite:DeleteColumns()
		Create_InviteGame_Win_ui.list_Channel_Invite:AddColumn("", 80, "kAlignCenterMiddle")
		Create_InviteGame_Win_ui.list_Channel_Invite:AddColumn("", 30, "kAlignCenterMiddle")
		Create_InviteGame_Win_ui.list_Channel_Invite:AddColumn("", 300,"kAlignLeftMiddle")
		
		Create_InviteGame_Win_ui.list_Friends_Invite:DeleteColumns()
		Create_InviteGame_Win_ui.list_Friends_Invite:AddColumn("", 80, "kAlignCenterMiddle")
		Create_InviteGame_Win_ui.list_Friends_Invite:AddColumn("", 30, "kAlignCenterMiddle")
		Create_InviteGame_Win_ui.list_Friends_Invite:AddColumn("", 300,"kAlignLeftMiddle")
		
		Create_InviteGame_Win_ui.list_Stranger_Invite:DeleteColumns()
		Create_InviteGame_Win_ui.list_Stranger_Invite:AddColumn("", 80, "kAlignCenterMiddle")
		Create_InviteGame_Win_ui.list_Stranger_Invite:AddColumn("", 30, "kAlignCenterMiddle")
		Create_InviteGame_Win_ui.list_Stranger_Invite:AddColumn("", 300,"kAlignLeftMiddle")
	end
end

function FillInviteChannelList()
	local roomlist = Create_InviteGame_Win_ui.list_Channel_Invite
	local root = Create_InviteGame_Win_ui.list_Channel_Invite.RootItem
	local Add = 1
	local item = nil
	roomlist:DeleteAll()
	local iconN1 = nil
	local state = ptr_cast(game.CurrentState)
	itemCount = state:GetChannelClientCount()
	for i=0, itemCount-1 do
		local info = state:GetChannelClientInfo(i)
		if info.name ~= L_LobbyMain.PersonalInfo_data.name then
			item = roomlist:AddItem(root)
			item.CanSelect = true
			item.BGSkin = Skin.ListItemSkin_Friends
			Add = Add + 1
			item.FontSize = 14
			item.CheckVisible = true
			item.CheckBoxLocation = Vector2(10, 0)
			item.CheckBoxSize = Vector2(32, 32)			
			iconN1 = Gui.Icon("LobbyUI/persionalInfo/HeadPic/lb_battlefield_icon"..info.icon..".dds")
			item:SetIcon(0,iconN1)
			SetVipIcon(item,info.is_vip,1,info.net_bar_level)
			item:SetText(2,info.name)
			item:SetSubItemColor(2, ARGB(255, 210, 203, 202))	
		end
	end
	
	if Add < 9 then
		for i = Add , 8 do
			item = roomlist:AddItem(root)
			item.CanSelect = false
			item.BGSkin = Skin.ListItemSkin_Friends

			Add = Add + 1
			item.CheckVisible = false
			item:SetText(0,"")
			item:SetText(1,"")
			item:SetText(2,"")
		end
	end
end

function FillInviteFriendsList(data,ltv)
	local roomlist = ltv
	local root = ltv.RootItem
	local Add = 1
	local item = nil
	roomlist:DeleteAll()
	local iconN = nil
	if data then
		for _,v in ipairs(data) do
			if v[5] == 1 then
				item = roomlist:AddItem(root)
				Add = Add + 1
				item.CanSelect = true
				item.BGSkin = Skin.ListItemSkin_Friends
				item.FontSize = 14
				item.TextColor = ARGB(255, 37, 37, 37)				
				item.CheckVisible = true
				item.CheckBoxLocation = Vector2(10, 0)
				item.CheckBoxSize = Vector2(32, 32)
				iconN = Gui.Icon("LobbyUI/persionalInfo/HeadPic/lb_battlefield_icon"..v[7]..".dds")
				item:SetIcon(0,iconN)
				SetVipIcon(item,v[6],1,v[8])
				item:SetText(2,v[3])
				item:SetSubItemColor(2, ARGB(255, 210, 203, 202))	
			end
		end
	end
	if Add < 9 then
		for i=Add, 8 do
			item = roomlist:AddItem(root)
			item.CanSelect = false
			item.BGSkin = Skin.ListItemSkin_Friends

			item.CheckVisible = false
			item:SetText(0,"")
			item:SetText(1,"")
			item:SetText(2,"")
		end
	end
end

function FillInviteTeamMemberList(data,ltv)
	local roomlist = ltv
	local root = ltv.RootItem
	local Add = 1
	local item = nil
	roomlist:DeleteAll()
	local iconN = nil
	if data then
		for _,v in ipairs(data) do
			if v[5] == 1 and  v[4] ~= L_LobbyMain.PersonalInfo_data.name then
				item = roomlist:AddItem(root)
				Add = Add + 1
				item.CanSelect = true
				item.BGSkin = Skin.ListItemSkin_Friends
				item.FontSize = 14
				item.TextColor = ARGB(255, 37, 37, 37)				
				item.CheckVisible = true
				item.CheckBoxLocation = Vector2(10, 0)
				item.CheckBoxSize = Vector2(32, 32)
				iconN = Gui.Icon("LobbyUI/persionalInfo/HeadPic/lb_battlefield_icon01_r.dds")
				item:SetIcon(0,iconN)
				--SetVipIcon(item,vip,which,net_bar_level,Min,card)
				SetVipIcon(item,v[12],1,v[14])
				item:SetText(2,v[4])
				item:SetSubItemColor(2, ARGB(255, 210, 203, 202))	
			end
		end
	end
	if Add < 9 then
		for i=Add, 8 do
			item = roomlist:AddItem(root)
			item.CanSelect = false
			item.BGSkin = Skin.ListItemSkin_Friends

			item.CheckVisible = false
			item:SetText(0,"")
			item:SetText(1,"")
			item:SetText(2,"")
		end
	end
end

function InviteListScan(ltv)
	local item = ltv.RootItem.FirstChild
	local Name = nil
	while item do
		if item.Check then
			Name = item:GetText(2)
			if Sift(Chilst,Name) == true then
				Chilst = {next = Chilst , name = Name}
			end
		end
		item = item.Next
	end
end

function Sift(list,name)
	if list then
		local l = list
		while l do
			if l.name == name then
				return false
			end
			l = l.next
		end
	end
	return true
end

function SendInvite()
	-- local str
	-- if L_WarZone.server_id == 19 then
		-- str = ":1"
	-- else
		-- str = ":0"
	-- end
	while Chilst do
		chatWindow:InvitePlayer(Chilst.name)
		Chilst = Chilst.next
	end
	MessageBox.ShowWithTimer(1,lang:GetText("邀请已发送！"))
end

local ListItemSkin_Card = {}
local ListItemSkin_Card_war = {}

function Setbusiness_card(Item,card,vip)
	if card == nil or card == 0 then
		if vip == 1 then
			local l = FindListItemSkin_card(0)
			if l then
				Item.BGSkin = l.ItemSkin_Card
			else
				InsertListItemSkin_card(0)
				l = FindListItemSkin_card(0)
				Item.BGSkin = l.ItemSkin_Card
			end
		else
			Item.BGSkin = Skin.ListItemSkin_Friends
		end
	else
		local l = FindListItemSkin_card(card)
		if l then
			Item.BGSkin = l.ItemSkin_Card
		else
			InsertListItemSkin_card(card)
			l = FindListItemSkin_card(card)
			Item.BGSkin = l.ItemSkin_Card
		end
	end
end

function FindListItemSkin_card(num)
	if ListItemSkin_Card then
		local l = ListItemSkin_Card
		while l do
			if l.card == num then
				return l
			end
			l = l.next
		end
	end
	return nil
end

function InsertListItemSkin_card(num)
	if num == 0 then
		ListItemSkin_Card = {next = ListItemSkin_Card , card = num ,
						ItemSkin_Card = Gui.ListItemSkin
						{
							--control skin
							BackgroundImage = Gui.Image("LobbyUI/WarZone/Card/lb_common_listcontent02_vip_a.dds", Vector4(0, 0,0, 0),Vector4(0.2, 0,1, 1)),
							--SelfImage = Gui.Image("LobbyUI/GameBalance/lb_common_listcontent01_me.dds", Vector4(8,3,56,3)),
							--list item skin
							HoverImage = Gui.Image("LobbyUI/WarZone/Card/lb_contact_liebiao_hover02.dds", Vector4(0, 0, 0, 0)),
							SelectedImage = Gui.Image("LobbyUI/WarZone/Card/lb_chat_list_down.dds", Vector4( 3,3,11,3)),
							--DisabledImage = Gui.Image("LobbyUI/lb_common_listcontent02_disabled.dds", Vector4(8, 0, 318, 0)),
						}
						}
	else
		ListItemSkin_Card = {next = ListItemSkin_Card , card = num ,
						ItemSkin_Card = Gui.ListItemSkin
						{
							--control skin
							BackgroundImage = Gui.Image("LobbyUI/WarZone/Card/namecard"..num.."_r_single.dds", Vector4(0, 0,0, 0),Vector4(0.2, 0,1, 1)),
							--SelfImage = Gui.Image("LobbyUI/GameBalance/lb_common_listcontent01_me.dds", Vector4(8,3,56,3)),
							--list item skin
							HoverImage = Gui.Image("LobbyUI/WarZone/Card/lb_contact_liebiao_hover02.dds", Vector4(0, 0, 0, 0)),
							SelectedImage = Gui.Image("LobbyUI/WarZone/Card/lb_chat_list_down.dds", Vector4( 3,3,11,3)),
							--DisabledImage = Gui.Image("LobbyUI/lb_common_listcontent02_disabled.dds", Vector4(8, 0, 318, 0)),
						}
						}
	end
end

function Setbusiness_card_war(Item,card,vip)
	if card == nil or card == 0 then
		if vip == 1 then
			local l = FindListItemSkin_card_war(0)
			if l then
				Item.BGSkin = l.ItemSkin_Card
			else
				InsertListItemSkin_card_war(0)
				l = FindListItemSkin_card_war(0)
				Item.BGSkin = l.ItemSkin_Card
			end
		else
			Item.BGSkin = Skin.ListItemSkin_Friends
		end
	else
		local l = FindListItemSkin_card_war(card)
		if l then
			Item.BGSkin = l.ItemSkin_Card
		else
			InsertListItemSkin_card_war(card)
			l = FindListItemSkin_card_war(card)
			Item.BGSkin = l.ItemSkin_Card
		end
	end
end

function FindListItemSkin_card_war(num)
	if ListItemSkin_Card_war then
		local l = ListItemSkin_Card_war
		while l do
			if l.card == num then
				return l
			end
			l = l.next
		end
	end
	return nil
end

function InsertListItemSkin_card_war(num)
	if num == 0 then
		ListItemSkin_Card_war = {next = ListItemSkin_Card_war , card = num ,
						ItemSkin_Card = Gui.ListItemSkin
						{
							--control skin
							BackgroundImage = Gui.Image("LobbyUI/WarZone/Card/lb_common_listcontent02_vip_a.dds", Vector4(0, 0,0, 0),Vector4(0.2, 0,1, 1)),
							--SelfImage = Gui.Image("LobbyUI/GameBalance/lb_common_listcontent01_me.dds", Vector4(8,3,56,3)),
							--list item skin
							HoverImage = Gui.Image("LobbyUI/WarZone/Card/lb_contact_liebiao_hover02.dds", Vector4(0, 0, 0, 0)),
							SelectedImage = Gui.Image("LobbyUI/WarZone/Card/lb_chat_list_down_b.dds", Vector4( 3,3,11,3)),
							--DisabledImage = Gui.Image("LobbyUI/lb_common_listcontent02_disabled.dds", Vector4(8, 0, 318, 0)),
						}
						}
	else
		ListItemSkin_Card_war = {next = ListItemSkin_Card_war , card = num ,
						ItemSkin_Card = Gui.ListItemSkin
						{
							--control skin  namecard10_r_single.dds
							BackgroundImage = Gui.Image("LobbyUI/WarZone/Card/namecard"..num.."_r_single.dds", Vector4(0, 0,0, 0),Vector4(0.2, 0,1, 1)),
							--SelfImage = Gui.Image("LobbyUI/GameBalance/lb_common_listcontent01_me.dds", Vector4(8,3,56,3)),
							--list item skin
							HoverImage = Gui.Image("LobbyUI/WarZone/Card/lb_contact_liebiao_hover02.dds", Vector4(0, 0, 0, 0)),
							SelectedImage = Gui.Image("LobbyUI/WarZone/Card/lb_chat_list_down_b.dds", Vector4( 3,3,11,3)),
							--DisabledImage = Gui.Image("LobbyUI/lb_common_listcontent02_disabled.dds", Vector4(8, 0, 318, 0)),
						}
						}
	end
end

function SetChatInfoText(text)
	local TepNum = string.find(text,"\n") + 1
	return string.sub(text,TepNum,-1)
end

function SetVipIcon(item,vip,which,net_bar_level,Min,card)
	local iconN = nil
	if net_bar_level == nil then
		net_bar_level = 0
	end
	if card then
		card = tonumber(card)
	end
	if Min ~= nil then
		iconN = Gui.Icon("LobbyUI/vip/lb_"..vip.."_ico_"..net_bar_level..Min..".dds")
	else
		iconN = Gui.Icon("LobbyUI/vip/lb_"..vip.."_ico_"..net_bar_level..".dds")
	end
	if vip > 0 then
		iconN = Gui.Icon("LobbyUI/vip/vip/VIP_button_0"..vip.."_normal.dds")
	else
		iconN = nil
	end
	if vip > 0 then
		item.TextColor = ARGB(255, 255, 210, 2)
		item.HighlightTextColor = ARGB(255, 255, 210, 2)
	elseif card ~= nil and card ~= 0 then
		item.TextColor = ARGB(255, 216, 217, 208)
		item.HighlightTextColor = ARGB(255, 216, 217, 208)
	else
		item.TextColor = ARGB(255, 37, 37, 37)
		item.HighlightTextColor = ARGB(255, 37, 37, 37)
	end
	item:SetIcon(which,iconN)
end
