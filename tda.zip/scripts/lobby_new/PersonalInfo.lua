module("L_PersonalInfo", package.seeall)

root_ui = nil
DragWindow_ui = nil
Select_Drag_label = nil
Select_Drag_Skin = nil
Drag_Sender = nil

main_character_window_ui = nil
main_select_window_ui = nil
main_report_window_ui = nil
main_highlight_window_ui = nil
edit_persional_win_ui = nil
main_popup_window_ui = nil
tooltip_window_ui = nil
Level_data = nil

local buff_count = nil

IsFinish = 1

Anim_window_ui = nil
------------achievement control and data ----------------------
current_general_achievement_page = 1
general_achievement_totalpage = 1
general_achievement_list = nil

local character_info_data = nil

character_achievement_info = {}
character_achievement_info_data = {}
character_achievement_list = nil
current_select_character = 1
current_select_character_page = {1,1,1,1,1}
character_totalpage = {1,1,1,1,1}

main_general_achievement_window_ui = nil
main_task_achievement_window_ui = nil
main_character_achievement_window_ui = nil
------------achievement control and data end----------------------

----------selected state ----------------------

selected_headIcon = nil
selected_achname =nil
selected_achicon = nil
----------selected state end ------------------
Itemtips_ui = nil

achievementControl = nil
achievementCounter = 1
achievementData = nil
ReportData = nil
TaskData = nil

state = ptr_cast(game.CurrentState)

SelectHeadIcon = nil
SelectAchievementIcon = ""
SelectAchievementArray = {}
SelectAchievementButton = 0

--------title infomation ----------
total_title_page = 0
current_title_page = 1
title_data = nil
--------title infomation end ------

--------head infomation ----------
total_head_page = 0
current_head_page = 1
head_data = nil
--------head infomation end ------

--------achievement infomation ----------
current_achievement = 1
selected_achievement = nil
achievementIndextoID = {}
selected_button_text = nil

total_gen_achievement_page = 0
current_gen_achievement_page = 1
gen_achievement_data = nil

character_pages_info = {}

characterinfo_pages_info = {}

total_character_achievement_page = 0
current_character_achievement_page = 1
character_achievement_data = nil
--------achievement infomation end ------


tipsData = {}

report_limit = {}
highLight_limit = {}

OtherPid = -1
OtherUid = 0
MyName = ""

current_state = 0

MaxHeadPage = 1
NowHeadPage = 1

local DragWindow = 
{
	Gui.Control "root"
	{
		Visible = false,
		Location = Vector2(17, 0),
		Size = Vector2(1167, 900),
		BackgroundColor = ARGB(0, 255, 255, 255),
		Gui.Control "Image"
		{
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ibt_icon/ak47.tga", Vector4(0, 0, 0, 0)),
			},
			Gui.DragLabel "LDrag"
			{
				Size = Vector2(168, 156),
				Location = Vector2(0, 0),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Iimit = Vector4(-10000,-10000,10000,10000),
			},
		},
		EventMouseUp = function(sender, e)
			DragWindow_ui.root.Visible = false
			if Drag_Sender then
				Drag_Sender.Skin.BackgroundImage.alpha = 255
			end
		end,
	},
}

--ToolTips窗口
local tooltip_window =
{
	Gui.Control "ctrl_root"
	{							
		--Size = Vector2(246, 310),
		Size = Vector2(246, 210),
		Location = Vector2(1, 46),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/ToolTips/lb_tooltips_bg.dds",Vector4(10, 10, 10, 10)),
		},
		
		--物品名称
		Gui.Control "ctrl_title"
		{							
			Size = Vector2(228, 35),
			Location = Vector2(9, 11),
			BackgroundColor = ARGB(255,255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ToolTips/lb_tooltips_bg_wqmc.dds",Vector4(10, 10, 10, 10)),
			},
			
			Gui.Label "lbl_title"
			{
				Size = Vector2(213, 18),
				Location = Vector2(7, 9),
				TextColor = ARGB(255,216,217,208),
				FontSize = 18,
				TextAlign = "kAlignCenterMiddle",
				Text = lang:GetText("物品名称"),
			},
		},

	
		--icon窗口
		Gui.Control "ctrl_icon_bg"
		{							
			Size = Vector2(228,150),
			Location = Vector2(9, 50),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ToolTips/lb_tooltips_bg_2.dds",Vector4(8, 8, 8, 8)),
			},
			
			Gui.Control "ctrl_icon"
			{							
				Size = Vector2(128,64),
				Location = Vector2(50,43),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ToolTips/lb_tooltips_bg_wqmc.dds",Vector4(10, 10, 10, 10)),
				},
			},
			
			Gui.Label "LevelInfo"
			{
				Size = Vector2(225, 40),
				Location = Vector2(2, 2),
				TextColor = ARGB(255,128, 140, 139),
				BackgroundColor = ARGB(0, 255, 255, 255),
				FontSize = 18,
				Visible = false,
				TextAlign = "kAlignCenterMiddle",
			},
			
			Gui.TextArea "lbl_skill1"
			{
				Size = Vector2(240, 80),
				Location = Vector2(2, 2),
				TextColor = ARGB(255,128, 140, 139),
				BackgroundColor = ARGB(0, 255, 255, 255),
				HScrollBarDisplay = false,
				VScrollBarDisplay = true,
				Fold = true,
				FontSize = 18,
				Visible = false,
			},
		},
		
		--武器性能
		--[[
		Gui.Control "ctrl_performance"
		{							
			Size = Vector2(228, 86),
			Location = Vector2(9, 215),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ToolTips/lb_tooltips_bg_2.dds",Vector4(8, 8, 8, 8)),
			},
			
			--伤害力
			Gui.Label "lbl_demage"
			{
				Size = Vector2(49, 12),
				Location = Vector2(4, 14),
				TextColor = ARGB(255,215, 232, 227),
				FontSize = 12,
				TextAlign = "kAlignRightMiddle",
				Text = lang:GetText("攻击威力"),
			},
			Gui.Control "ctrl_progress1_bg"
			{							
				Size = Vector2(124, 14),
				Location = Vector2(65, 13),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ToolTips/lb_tooltips_gjwl_bg.dds",Vector4(6, 6, 6, 6)),
				},
				
				Gui.Control "ctrl_progress1_content"
				{							
					Size = Vector2(118, 8),
					Location = Vector2(3, 3),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ToolTips/lb_tooltips_gjwl_content.dds",Vector4(3, 3, 3, 3)),
					},
				},
			},
			Gui.Label "lbl_demage_number"
			{
				Size = Vector2(31, 10),
				Location = Vector2(193, 14),
				TextColor = ARGB(255,215, 232, 227),
				FontSize = 12,
				TextAlign = "kAlignLeftMiddle",
				Text = "",
			},
			
			--射击速度
			Gui.Label "lbl_speed"
			{
				Size = Vector2(49, 12),
				Location = Vector2(4, 39),
				TextColor = ARGB(255,215, 232, 227),
				FontSize = 12,
				TextAlign = "kAlignRightMiddle",
				Text = lang:GetText("射击速度"),
			},
			Gui.Control "ctrl_progress2_bg"
			{							
				Size = Vector2(124, 14),
				Location = Vector2(65, 40),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ToolTips/lb_tooltips_gjwl_bg.dds",Vector4(6, 6, 6, 6)),
				},
				
				Gui.Control "ctrl_progress2_content"
				{							
					Size = Vector2(118, 8),
					Location = Vector2(3, 3),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ToolTips/lb_tooltips_gjwl_content.dds",Vector4(3, 3, 3, 3)),
					},
				},
			},
			Gui.Label "lbl_speed_number"
			{
				Size = Vector2(31, 10),
				Location = Vector2(193, 41),
				TextColor = ARGB(255,215, 232, 227),
				FontSize = 12,
				TextAlign = "kAlignLeftMiddle",
				Text = "",
			},
			
			--上膛量
			Gui.Label "lbl_number1"
			{
				Size = Vector2(73, 14),
				Location = Vector2(14, 64),
				TextColor = ARGB(255,215, 232, 227),
				FontSize = 12,
				TextAlign = "kAlignCenterMiddle",
				Text = lang:GetText("上膛量："),
			},
			
			--载弹量
			Gui.Label "lbl_number2"
			{
				Size = Vector2(73, 14),
				Location = Vector2(146, 64),
				TextColor = ARGB(255,215, 232, 227),
				FontSize = 12,
				TextAlign = "kAlignCenterMiddle",
				Text = lang:GetText("载弹量："),
			},
		},
		--]]
	},
}

--创建Tooltipswindow
local function setup_tooltips_window(parent_window)
	--界面是否存在
	if tooltip_window_ui then
		tooltip_window_ui.ctrl_root.Parent = parent_window
		return
	end
	--创建界面
	tooltip_window_ui = Gui.Create(parent_window)(tooltip_window)
end

local function ShowToolTipsWindow(pos)
	local lobby_state = ptr_cast(game.CurrentState)
	if lobby_state and tooltip_window_ui and tooltip_window_ui.ctrl_root then
		local window_size = lobby_state:GetUIWindowSize()
		if pos.x + 246 > window_size.x then
			pos = Vector2(pos.x - 246 - 50, pos.y)
		end
		if pos.y + tooltip_window_ui.ctrl_root.Size.y > window_size.y then
			pos = Vector2(pos.x, pos.y-tooltip_window_ui.ctrl_root.Size.y-50)
		end
		if tooltip_window_ui then
			tooltip_window_ui.ctrl_root.Location = pos
		end
	end
end

function HideToolTipsWindow()
	if tooltip_window_ui then
		tooltip_window_ui.ctrl_root.Parent = nil
		tooltip_window_ui = nil
	end
end

function FillToolTipsWindow(data, first)
	--隐藏
	setup_tooltips_window(gui)
	
	if tooltip_window_ui then
		if first == 1 then
			tooltip_window_ui.ctrl_root.Location = Vector2(-5000,-5000)
		end
		local realtype = data[1]
		local length,ratio		
		local winSize = state:GetScreenSize()
		local tipswin = data[6]
		local weaponName = tipswin[3]
		local weaponCHName = tipswin[2]
		local damageScale = tipswin[4]
		local shotSpeed = tipswin[5]
		local loadNum = tipswin[6]
		local loadNum2 = tipswin[7]
		local color = tipswin[8]
		local seq = tipswin[9]
		local type = tipswin[1]
		
		if color == 1 then
			color = "_"..color
		elseif color == 2 then
			color = "_"..color
		elseif color == 3 then
			color = "_"..color
		elseif color == 4 then
			color = "_"..color
		else
			color = ""
		end
		
		-- print("/n")
		-- print("weaponName=",weaponName)
		-- print("type=",type)
		-- print("realtype = ",realtype)
		-- print("color = ",color)
		-- print("seq = ",seq)
		-- print(tipswin[6])
		-- print(tipswin[7])
		
		tooltip_window_ui.lbl_skill1.Visible = false
		tooltip_window_ui.LevelInfo.Visible = false

		--未知
		if realtype == 0 then
			local title = tipswin[2]
			local content = tipswin[3]
			local Size
			
			Size = tooltip_window_ui.ctrl_icon_bg.Size
			tooltip_window_ui.lbl_title.Text = title
			tooltip_window_ui.LevelInfo.Visible = true
			tooltip_window_ui.LevelInfo.Text = content
			return
		end
		
		--成就
		if realtype == 4 then
			local title = tipswin[2]
			local content = tipswin[3]
			local Size
			if type <= 9 then
				type = "0"..type
			end
			Size = tooltip_window_ui.ctrl_icon_bg.Size
			tooltip_window_ui.lbl_title.Text = title
			tooltip_window_ui.ctrl_icon.Location = Vector2(82,20)
			tooltip_window_ui.ctrl_icon.Size = Vector2(64,64)
			tooltip_window_ui.ctrl_icon.Skin =  Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/persionalInfo/achieves/acheive"..type..".dds", Vector4(0, 0, 0, 0)),}
			if string.len(content) > 20 then		
				tooltip_window_ui.lbl_skill1.Location = Vector2(10,90)
				tooltip_window_ui.lbl_skill1.Visible = true
				tooltip_window_ui.lbl_skill1.Text = content
			else
				tooltip_window_ui.LevelInfo.Location = Vector2(2,90)
				tooltip_window_ui.LevelInfo.Visible = true
				tooltip_window_ui.LevelInfo.Text = content
			end
			return
		end
		
		--称号
		if  realtype == 5 then
			local title = tipswin[2]
			local content = tipswin[3]
			local Size
			Size = tooltip_window_ui.ctrl_icon_bg.Size
			tooltip_window_ui.lbl_title.Text = title
			tooltip_window_ui.ctrl_icon.Visible = false
			if string.len(content) > 20 then
				tooltip_window_ui.lbl_skill1.Visible = true
				tooltip_window_ui.lbl_skill1.Text = content
			else
				tooltip_window_ui.LevelInfo.Visible = true
				tooltip_window_ui.LevelInfo.Text = content
			end
			return
		end
		
		--武器
		if color == "_1" then
			tooltip_window_ui.lbl_title.TextColor = ARGB(255, 205, 43, 55)
		elseif color == "_2" then
			tooltip_window_ui.lbl_title.TextColor = ARGB(255, 181, 58, 212)
		elseif color == "_3" then
			tooltip_window_ui.lbl_title.TextColor = ARGB(255, 101, 179, 239)
		elseif color == "_4" then
			tooltip_window_ui.lbl_title.TextColor = ARGB(255, 128, 239, 147)
		else
			tooltip_window_ui.lbl_title.TextColor = ARGB(255, 255, 255, 255)
		end
		tooltip_window_ui.lbl_title.Text = weaponCHName
		
		-- if loadNum == 0 then
			-- if weaponName == "airgun" then
				-- tooltip_window_ui.lbl_number1.Text = ""
				-- tooltip_window_ui.lbl_number2.Text = ""
				-- ratio = damageScale/200
				-- length = 118 * ratio
				-- tooltip_window_ui.ctrl_progress1_content.Size = Vector2(length,8)
				
				-- ratio = shotSpeed/200
				-- length = 118 * ratio
				-- tooltip_window_ui.ctrl_progress2_content.Size = Vector2(length,8)
			-- else
				-- tooltip_window_ui.ctrl_performance.Visible = false
				-- length = tooltip_window_ui.ctrl_root.Size.y - tooltip_window_ui.ctrl_performance.Size.y
				-- tooltip_window_ui.ctrl_root.Size = Vector2(246,length)
			-- end
		-- else
			-- tooltip_window_ui.lbl_number1.Text = tooltip_window_ui.lbl_number1.Text..loadNum
			-- tooltip_window_ui.lbl_number2.Text = tooltip_window_ui.lbl_number2.Text..loadNum2
			
			-- length = 118 * damageScale / 200
			-- tooltip_window_ui.ctrl_progress1_content.Size = Vector2(length,8)
			-- length = 118 * shotSpeed / 200
			-- tooltip_window_ui.ctrl_progress2_content.Size = Vector2(length,8)
		-- end
		
		if type == 1 then
			weaponName = weaponName
		elseif type == 2 then
			tooltip_window_ui.ctrl_icon.Location = Vector2(79,10)
			tooltip_window_ui.ctrl_icon.Size = Vector2(70,135)
		elseif type == 3 then
			tooltip_window_ui.ctrl_icon.Location = Vector2(79,30)
			tooltip_window_ui.ctrl_icon.Size = Vector2(72,68)
		elseif type >= 4 or type <= 7 then
			tooltip_window_ui.ctrl_icon.Location = Vector2(70,26)
			tooltip_window_ui.ctrl_icon.Size = Vector2(88,88)
		end	
		
		weaponName = weaponName..color
		tooltip_window_ui.ctrl_icon.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/ibt_icon/"..weaponName..".tga",Vector4(10, 10, 10, 10)),}
		
		if tooltip_window_ui.ctrl_root.Location.y + tooltip_window_ui.ctrl_root.Size.y >= winSize.y then
			local newLocY =  winSize.y - tooltip_window_ui.ctrl_root.Size.y - 20
			local newLocX = tooltip_window_ui.ctrl_root.Location.x
			tooltip_window_ui.ctrl_root.Location = Vector2(newLocX,newLocY)
		end
	end
end


local main_character_achievement_window = 
{
	Gui.Control "ctrl_character_achievement_window"
	{
		Size = Vector2(1116, 586),
		Location = Vector2(19, 25),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/lb_shop_bg2.dds", Vector4(14, 14, 14, 14)),
		},	
		
		
		Gui.Control "boddy_info_BG"
		{
			Size = Vector2(1101, 551),
			Location = Vector2(9, 34),
			BackgroundColor = ARGB(255, 255, 255, 255),
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg.tga", Vector4(150, 22, 22, 22)),
			},

			Gui.Control
			{
				Location = Vector2(150,45),
				Size = Vector2(920,490),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg3.dds", Vector4(22, 22, 22, 22)),
				},
				
				Gui.Label "Lname"
				{
					Size = Vector2(200,40),
					Location = Vector2(-20,35),
					BackgroundColor = ARGB(0,253,211,77),
					TextAlign = "kAlignCenterMiddle",
					TextColor = ARGB(255,253,211,77),
					FontSize = 18,
					Text = lang:GetText("角色成就进程"),
				},
				
				Gui.Label "flag1"
				{
					Size = Vector2(40,40),
					Location = Vector2(230,10),
					BackgroundColor = ARGB(255,255,255,255),
					
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_icon01_inactive.dds", Vector4(14, 14, 14, 14)),
					},
				},
				
				Gui.Label "flag2"
				{
					Size = Vector2(40,40),
					Location = Vector2(390,10),
					BackgroundColor = ARGB(255,255,255,255),
					
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_icon01_inactive.dds", Vector4(14, 14, 14, 14)),
					},
				},
				
				Gui.Label "flag3"
				{
					Size = Vector2(40,40),
					Location = Vector2(590,10),
					BackgroundColor = ARGB(255,255,255,255),
					
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_icon01_inactive.dds", Vector4(14, 14, 14, 14)),
					},
				},
				
				Gui.Label "Process_num"
				{
					Location = Vector2(645,45),
					Size = Vector2(80,20),
					BackgroundColor = ARGB(0,255,255,255),
					TextAlign = "kAlignLeftMiddle",
					TextColor = ARGB(255,253,211,77),
					FontSize = 20,
					Text = "7/35",
				},
				
				Gui.Label "Process_BG"
				{
					Size = Vector2(490,15),
					Location = Vector2(150,50),
					BackgroundColor = ARGB(255,255,255,255),
					
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_common_expbar01_bg.dds", Vector4(14, 0, 14, 0)),
					},
				},
				
				Gui.Label "Processbar"
				{
					Size = Vector2(0,15),
					Location = Vector2(150,50),
					BackgroundColor = ARGB(255,255,255,255),
					
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_bar02_content.dds", Vector4(14, 0, 14, 0)),
					},
				},
				
				--成就2
				Gui.Button "keep_shot"
				{
					Size = Vector2(198,32),
					Location = Vector2(710,20),
					TextAlign = "kAlignRightMiddle",
					Text = lang:GetText("保存截图").."",
					Enable = false,
					TextColor = ARGB(255,54,53,49),
					FontSize = 17,
					Skin = Skin.TakePicSkin
				},
			},
						
			Gui.ScrollableControl "scroll"
			{
				Location = Vector2(180,110),
				Size = Vector2(900,380),
				AutoScroll = true,
				VScrollBarPos = Vector2(-40,0),
				VScrollBarButtonSize = 40,
				VScrollBarWidth = 40,
				VScrollBarHeight = 380,
				VScrollBarDisplay = false,
				BackgroundColor = ARGB(255,255,255,255),
				
				Gui.FlowLayout "scrollLayout"
				{
					AutoSize = true,
					LineSpace = 5,
				},
			},
			
			Gui.Label "LJumpText"
			{
				Size = Vector2(300,32),
				Location = Vector2(176,480),
				FontSize = 20,
				TextColor = ARGB(255, 215, 232, 227),
				Text = lang:GetText("跳转至第"),
				TextAlign = "kAlignRightMiddle",
			},
			
			Gui.Textbox "tbox_PassWord"
			{
				Size =  Vector2(59,32),
				FontSize = 20,
				Location = Vector2(505, 480),
				TextColor = ARGB(255,195,189,176),
				MaxLength = 3,
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/lb_common_textbox01_normal.dds", Vector4(5, 5, 5, 5)),
				},
			},
			
			
			Gui.Label "LJumpText"
			{
				Size = Vector2(20,32),
				Location = Vector2(576,480),
				FontSize = 20,
				TextColor = ARGB(255, 215, 232, 227),
				Text = lang:GetText("页"),
			},
			
			Gui.Button "BJump"
			{
				Size =  Vector2(75,40),
				Location = Vector2(600, 477),
				FontSize = 20,
				Text = lang:GetText("确定"),
				TextColor = ARGB(255, 0, 0, 0),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_b_hover.dds", Vector4(20, 20, 20, 20)),
					HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_b_hover.dds", Vector4(20, 20, 20, 20)),
					DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_b_down.dds", Vector4(20, 20, 20, 20)),
					DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_normal.dds", Vector4(20, 20, 20, 20)),
				},
			},
			
			Gui.Button "m_AcheInfoLeft"
			{	Size = Vector2(20,35),
				Visible = true,
				Location = Vector2(790,480),
				
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button05_normal.dds", Vector4(0, 0, 0, 0)),
					HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button05_hover.dds", Vector4(0, 0, 0, 0)),
					DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button05_down.dds", Vector4(0, 0, 0, 0)),
					DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button05_normal.dds", Vector4(0, 0, 0, 0)),
				},
			},
			
			Gui.Label "m_AcheInfoPageDisplay"
			{
				Size = Vector2(109,35),
				FontSize = 24,
				Visible = true,
				Location = Vector2(820,480),
				TextColor = ARGB(255, 128, 128, 128),
				TextAlign = "kAlignCenterMiddle",
				Text = "1/1",
				BackgroundColor = ARGB(255, 255, 255, 255),
	
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button06_bg.dds", Vector4(14, 14, 14, 14)),
				},
			},
			
			Gui.Button "m_AcheInfoRight"
			{
				Size = Vector2(20,35),
				Visible = true,
				Location = Vector2(940,480),
				
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button06_normal.dds", Vector4(0, 0, 0, 0)),
					HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button06_hover.dds", Vector4(0, 0, 0, 0)),
					DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button06_down.dds", Vector4(0, 0, 0, 0)),
					DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button06_normal.dds", Vector4(0, 0, 0, 0)),
				},
	
			},
		},
		
		--职业列表
		L_Characters_tab.create_tab_characters_windows(Vector2(1,38)),
		
		Gui.Button "btn_Close"
		{
			Size = Vector2(64, 52),
			Location = Vector2(1049, 3),
			PushDown = false,
			Hint = lang:GetText("关闭个人信息并返回至战区"),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button01_normal.dds", Vector4(0, 0, 0, 0)),
				HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button01_hover.dds", Vector4(0, 0, 0, 0)),
				DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button01_down.dds", Vector4(0, 0, 0, 0)),
				DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button01_normal.dds", Vector4(0, 0, 0, 0)),
			},
		},
	},
}


local main_task_achievement_window = 
{
	Gui.Control "ctrl_task_achievement_window"
	{
		Size = Vector2(1116, 584),
		Location = Vector2(19,17),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/lb_shop_bg2.dds", Vector4(14, 14, 14, 14)),
		},
		
		Gui.Control "boddy_info_BG"
		{
			Size = Vector2(1200, 559),
			Location = Vector2(-90, 27),
			BackgroundColor = ARGB(255, 255, 255, 255),			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/lb_shop_bg.dds", Vector4(150, 22, 22, 22)),
			},
		},
		
		Gui.Button "btn_Close"
		{
			Size = Vector2(80, 60),
			Location = Vector2(1028, 3),
			PushDown = false,
			Hint = lang:GetText("关闭个人信息并返回至战区"),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button01_normal.dds", Vector4(5, 5, 5, 5)),
				HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button01_hover.dds", Vector4(5, 5, 5, 5)),
				DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button01_down.dds", Vector4(5, 5, 5, 5)),
				DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button01_normal.dds", Vector4(5, 5, 5, 5)),
			},
		},
		
		Gui.Label "Lname"
		{
			Size = Vector2(200,40),
			Location = Vector2(50,100),
			BackgroundColor = ARGB(0,253,211,77),
			TextAlign = "kAlignCenterMiddle",
			TextColor = ARGB(255,253,211,77),
			FontSize = 18,
			Text = lang:GetText("任务成就达成进程"),
		},
		
		Gui.Label "flag1"
		{
			Size = Vector2(40,40),
			Location = Vector2(360,75),
			BackgroundColor = ARGB(255,255,255,255),
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_icon01_inactive.dds", Vector4(14, 14, 14, 14)),
			},
		},
		
		Gui.Label "flag2"
		{
			Size = Vector2(40,40),
			Location = Vector2(560,75),
			BackgroundColor = ARGB(255,255,255,255),
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_icon01_inactive.dds", Vector4(14, 14, 14, 14)),
			},
		},
		
		Gui.Label "flag3"
		{
			Size = Vector2(40,40),
			Location = Vector2(760,75),
			BackgroundColor = ARGB(255,255,255,255),
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_icon01_inactive.dds", Vector4(14, 14, 14, 14)),
			},
		},
		
		Gui.Label "Process_num"
		{
			Location = Vector2(980,115),
			Size = Vector2(80,20),
			BackgroundColor = ARGB(0,255,255,255),
			TextAlign = "kAlignCenterMiddle",
			TextColor = ARGB(255,253,211,77),
			FontSize = 20,
			Text = "7/35",
		},
		
		Gui.Label "Process_BG"
		{
			Size = Vector2(700,15),
			Location = Vector2(260,115),
			BackgroundColor = ARGB(255,255,255,255),
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_common_expbar01_bg.dds", Vector4(0, 14, 0, 14)),
			},
		},
		
		Gui.Label "Processbar"
		{
			Size = Vector2(0,15),
			Location = Vector2(260,115),
			BackgroundColor = ARGB(255,255,255,255),
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_bar01_content.dds", Vector4(0, 14, 0, 14)),
			},
		},
		
		Gui.Control
		{
			Location = Vector2(45,145),
			Size = Vector2(940,420),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_bg02_normal.dds", Vector4(14, 14, 14, 14)),
			},
		},
						
		Gui.ScrollableControl "scroll"
		{
			Location = Vector2(70,160),
			Size = Vector2(1000,400),
			AutoScroll = true,
			VScrollBarHeight = 180,
			VScrollBarDisplay = true,
			AutoScrollMinSize = Vector2(600,520),
			BackgroundColor = ARGB(255,255,255,255),
			Text = lang:GetText("个人信息"),
			
			Gui.FlowLayout "scrollLayout"
			{
				AutoSize = true,
				LineSpace = 10,
				
				Gui.Control "cinfo1"
				{
					Size = Vector2(880,85),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_bg02_normal.dds", Vector4(14, 14, 14, 14)),
					},
					
					Gui.Label "LHead"
					{
						Location = Vector2(13,13),
						Size = Vector2(60,60),
						BackgroundColor = ARGB(255,0,0,0),					
					},
					
					Gui.Label "Linfo1"
					{
						Location = Vector2(80,10),
						Size = Vector2(200,40),
						BackgroundColor = ARGB(0, 255, 255, 255),
						TextAlign = "kAlignCenterMiddle",
						TextColor = ARGB(255,226,217,208),
						FontSize = 20,
					},
					
					Gui.Label "Progress_bg"
					{
						Location = Vector2(80,50),
						Size = Vector2(700,20),
						BackgroundColor = ARGB(255, 255, 255, 255),
						
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_common_expbar01_bg.dds", Vector4(14, 14, 14, 14)),
						},
					},
					
					Gui.Label "Progressbar"
					{
						Location = Vector2(80,50),
						Size = Vector2(0,20),
						BackgroundColor = ARGB(255, 255, 255, 255),
						
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_bar01_content.dds", Vector4(5, 0, 5, 0)),
						},
					},
					
					Gui.Label "tips"
					{
						Location = Vector2(700,10),
						Size = Vector2(160,40),
						BackgroundColor = ARGB(255, 255, 255, 255),
						TextAlign = "kAlignCenterTop",
						TextColor = ARGB(255,253,211,77),
						FontSize = 18,
						
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_nicknameBG01.dds", Vector4(14, 14, 14, 14)),
						},
					},
					
					Gui.Label "ratio"
					{
						Location = Vector2(785,45),
						Size = Vector2(90,40),
						BackgroundColor = ARGB(0, 255, 255, 255),
						TextAlign = "kAlignCenterMiddle",
						TextColor = ARGB(255,226,217,208),
						FontSize = 20,
					},
				},
				
				Gui.Control
				{
					Size = Vector2(880,85),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_bg02_normal.dds", Vector4(14, 14, 14, 14)),
					},				
				},
				
				Gui.Control
				{
					Size = Vector2(880,85),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_bg02_normal.dds", Vector4(14, 14, 14, 14)),
					},					
				},
				
				Gui.Control
				{
					Size = Vector2(880,85),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_bg02_normal.dds", Vector4(14, 14, 14, 14)),
					},					
				},
				
				Gui.Control
				{
					Size = Vector2(880,85),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_bg02_normal.dds", Vector4(14, 14, 14, 14)),
					},					
				},
			},
		},
	},
}

local main_general_achievement_window = 
{
	Gui.Control "ctrl_general_achievement_window"
	{
		Size = Vector2(1116, 586),
		Location = Vector2(19, 25),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/lb_shop_bg2.dds", Vector4(14, 14, 14, 14)),
		},
		
		Gui.Control "boddy_info_BG"
		{
			Size = Vector2(1101, 551),
			Location = Vector2(9, 35),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_daoju_bg.tga", Vector4(22, 22, 22, 22)),
			},
		},
		
		Gui.Button "btn_Close"
		{
			Size = Vector2(64, 52),
			Location = Vector2(1049, 3),
			PushDown = false,
			Hint = lang:GetText("关闭个人信息并返回至战区"),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button01_normal.dds", Vector4(0, 0, 0, 0)),
				HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button01_hover.dds", Vector4(0, 0, 0, 0)),
				DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button01_down.dds", Vector4(0, 0, 0, 0)),
				DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button01_normal.dds", Vector4(0, 0, 0, 0)),
			},

			EventClick = function()
				Hide()
			end
		},
		
		Gui.Control
		{
			Location = Vector2(30,85),
			Size = Vector2(1050,480),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg3.dds", Vector4(22, 22, 22, 22)),
			},
			
			Gui.Label "Lname"
			{
				Size = Vector2(150,40),
				Location = Vector2(5,35),
				BackgroundColor = ARGB(0,253,211,77),
				TextAlign = "kAlignCenterMiddle",
				TextColor = ARGB(255,253,211,77),
				FontSize = 16,
				Text = lang:GetText("一般成就进程"),
			},
			
			Gui.Label "flag1"
			{
				Size = Vector2(40,40),
				Location = Vector2(290,10),
				BackgroundColor = ARGB(255,255,255,255),
				
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_icon01_inactive.dds", Vector4(14, 14, 14, 14)),
				},
			},
			
			Gui.Label "flag2"
			{
				Size = Vector2(40,40),
				Location = Vector2(490,10),
				BackgroundColor = ARGB(255,255,255,255),
				
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_icon01_inactive.dds", Vector4(14, 14, 14, 14)),
				},
			},
			
			Gui.Label "flag3"
			{
				Size = Vector2(40,40),
				Location = Vector2(680,10),
				BackgroundColor = ARGB(255,255,255,255),
				
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_icon01_inactive.dds", Vector4(14, 14, 14, 14)),
				},
			},

			--成就1
			Gui.Button "keep_shot"
			{
				Size = Vector2(198,32),
				Location = Vector2(830,18),
				Text = lang:GetText("保存截图").." ",
				TextColor = ARGB(255, 0, 0, 0),
				FontSize = 17,
				PushDown = flase,
				Enable = false,
				TextAlign = "kAlignRightMiddle",
			},
			
			Gui.Label "Process_BG"
			{
				Size = Vector2(600,18),
				Location = Vector2(150,50),
				BackgroundColor = ARGB(255,255,255,255),
				
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_common_expbar01_bg.dds", Vector4(14, 0, 14, 0)),
				},
			},
			
			Gui.Label "Processbar"
			{
				Size = Vector2(0,18),
				Location = Vector2(150,50),
				BackgroundColor = ARGB(255,255,255,255),
				
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_bar02_content.dds", Vector4(14, 0, 14, 0)),
				},
			},
			
			Gui.Label "Process_num"
			{
				Location = Vector2(750,45),
				Size = Vector2(80,20),
				BackgroundColor = ARGB(0,255,255,255),
				TextAlign = "kAlignCenterMiddle",
				TextColor = ARGB(255,253,211,77),
				FontSize = 20,
			},
		},
						
		Gui.ScrollableControl "scroll"
		{
			Location = Vector2(40,160),
			Size = Vector2(1050,380),
			AutoScroll = true,
			VScrollBarPos = Vector2(-40,0),
			VScrollBarButtonSize = 40,
			VScrollBarWidth = 40,
			VScrollBarHeight = 380,
			VScrollBarDisplay = "kHide",
			AutoScrollMinSize = Vector2(0,0),
			BackgroundColor = ARGB(255,255,255,255),
			
			Gui.FlowLayout "scrollLayout"
			{
				AutoSize = true,
				LineSpace = 5,
			},
		},
		
		Gui.Label "LJumpText"
		{
			Size = Vector2(350,32),
			Location = Vector2(200,525),
			FontSize = 20,
			TextColor = ARGB(255, 215, 232, 227),
			Text = lang:GetText("跳转至第"),
			TextAlign = "kAlignRightMiddle",
		},
		
		Gui.Textbox "tbox_PassWord"
		{
			Size =  Vector2(59,32),
			FontSize = 20,
			Location = Vector2(565, 525),
			TextColor = ARGB(255,195,189,176),
			MaxLength = 3,
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/lb_common_textbox01_normal.dds", Vector4(5, 5, 5, 5)),
			},
		},
		
		
		Gui.Label "LJumpText"
		{
			Size = Vector2(20,32),
			Location = Vector2(626,525),
			FontSize = 20,
			TextColor = ARGB(255, 215, 232, 227),
			Text = lang:GetText("页"),
		},
		
		Gui.Button "BJump"
		{
			Size =  Vector2(75,40),
			Location = Vector2(650, 522),
			FontSize = 20,
			Text = lang:GetText("确定"),
			TextColor = ARGB(255, 0, 0, 0),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_b_hover.dds", Vector4(20, 20, 20, 20)),
				HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_b_hover.dds", Vector4(20, 20, 20, 20)),
				DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_b_down.dds", Vector4(20, 20, 20, 20)),
				DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_normal.dds", Vector4(20, 20, 20, 20)),
			},
		},
		
		Gui.Button "m_AcheInfoLeft"
		{	Size = Vector2(20,35),
			Visible = true,
			Location = Vector2(850,525),
			
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button05_normal.dds", Vector4(0, 0, 0, 0)),
				HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button05_hover.dds", Vector4(0, 0, 0, 0)),
				DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button05_down.dds", Vector4(0, 0, 0, 0)),
				DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button05_normal.dds", Vector4(0, 0, 0, 0)),
			},
		},
		
		Gui.Label "m_AcheInfoPageDisplay"
		{
			Size = Vector2(109,35),
			FontSize = 24,
			Visible = true,
			Location = Vector2(880,525),
			TextColor = ARGB(255, 128, 128, 128),
			TextAlign = "kAlignCenterMiddle",
			Text = "1/1",
			BackgroundColor = ARGB(255, 255, 255, 255),

			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button06_bg.dds", Vector4(14, 14, 14, 14)),
			},
		},
		
		Gui.Button "m_AcheInfoRight"
		{
			Size = Vector2(20,35),
			Visible = true,
			Location = Vector2(1000,525),
			
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button06_normal.dds", Vector4(0, 0, 0, 0)),
				HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button06_hover.dds", Vector4(0, 0, 0, 0)),
				DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button06_down.dds", Vector4(0, 0, 0, 0)),
				DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button06_normal.dds", Vector4(0, 0, 0, 0)),
			},

		},
	},
}

local edit_persional_win_ui = Gui.Create()
{
	Gui.Control "ctrl_main_edit_persional_window"
	{
		Size = Vector2(919,695),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_contact_bg1_01.dds", Vector4(163,163,53,53)),
		},
		Gui.Control
		{
			Size = Vector2(858,569),
			Location = Vector2(30,62),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg3.dds", Vector4(22, 22, 22, 22)),
			},
			Gui.Control
			{
				Size = Vector2(242,539),
				Location = Vector2(14,14),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_task_bg_6.dds", Vector4(41, 81, 44, 41)),
				},

				Gui.Control
				{
					Size = Vector2(206,41),
					Location = Vector2(16,11),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/Compose/lb_melting_button_down.dds", Vector4(0, 0, 0, 0)),
					},
					Gui.Label "head_text"
					{
						Size = Vector2(206,41),
						Location = Vector2(0,0),
						BackgroundColor = ARGB(0, 255, 255, 255),
						TextAlign = "kAlignCenterMiddle",
						FontSize = 20,
						Text = lang:GetText("我的头像"),
						TextColor = ARGB(255, 255, 205, 69),
					},
				},
				
				Gui.Control
				{
					Size = Vector2(205,419),
					Location = Vector2(16, 61),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_contact_bg_normal.dds", Vector4(16, 16, 16, 16)),
					},
					Gui.Control
					{
						Size = Vector2(205,419),
						Location = Vector2(0, 0),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/Compose/lb_melting_bg_cwlb.dds", Vector4(0,0,0,0)),
						},
						Gui.Control "CHead"
						{
							Location = Vector2(48,28),
							Size = Vector2(98,110),
							BackgroundColor = ARGB(255, 255, 255, 255),	
							Skin = Gui.ControlSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_bg_03.dds", Vector4(0, 0, 0, 0)),
							},	
					
							Gui.Label "Head"
							{
								Location = Vector2(5,5),
								Size = Vector2(88,100),
								BackgroundColor = ARGB(255, 255, 255, 255),
								
								Skin = Gui.ControlSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/persionalInfo/HeadPic/lb_info_image01_r.dds", Vector4(14, 14, 14, 14)),
								},
							},
						},
					},	
				},
			},
			Gui.Control
			{
				Size = Vector2(588,539),
				Location = Vector2(256,14),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_task_bg_6.dds", Vector4(41, 81, 44, 41)),
				},
				Gui.Control	"DisplayHead"
				{
				
					Size = Vector2(556,469),
					Location = Vector2(15,15),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg3.dds", Vector4(22, 22, 22, 22)),
					},
				},
				
				Gui.Button "m_HeadLeft"
				{	
					Size = Vector2(19,37),
					Location = Vector2(210,488),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/vip/vip/lb_shop_button05_normal.dds", Vector4(0, 0, 0, 0)),
						HoverImage = Gui.Image("LobbyUI/vip/vip/lb_shop_button05_hover.dds", Vector4(0, 0, 0, 0)),
						DownImage = Gui.Image("LobbyUI/vip/vip/lb_shop_button05_down.dds", Vector4(0, 0, 0, 0)),
						DisabledImage = Gui.Image("LobbyUI/vip/vip/lb_shop_button05_normal.dds", Vector4(0, 0, 0, 0)),
					},
					EventClick = function(sender, e)
						if NowHeadPage > 1 then
							NowHeadPage = NowHeadPage-1
							args = {pid = state:GetCharacterId(),type = 1,page = NowHeadPage}
							rpc.safecall("personal_edit_list",args,Fill_HeadInfo)
						end
					end
				},
				
				Gui.Label "m_HeadPageDisplay"
				{
					Size = Vector2(87,40),
					FontSize = 24,
					Location = Vector2(255,488),
					TextColor = ARGB(255, 128, 128, 128),
					TextAlign = "kAlignCenterMiddle",
					Text = "1/1",
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button06_bg.dds", Vector4(14, 14, 14, 14)),
					},
				},
				
				Gui.Button "m_HeadRight"
				{
					Size = Vector2(19,37),
					Location = Vector2(368,488),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/vip/vip/lb_shop_button06_normal.dds", Vector4(0, 0, 0, 0)),
						HoverImage = Gui.Image("LobbyUI/vip/vip/lb_shop_button06_hover.dds", Vector4(0, 0, 0, 0)),
						DownImage = Gui.Image("LobbyUI/vip/vip/lb_shop_button06_down.dds", Vector4(0, 0, 0, 0)),
						DisabledImage = Gui.Image("LobbyUI/vip/vip/lb_shop_button06_normal.dds", Vector4(0, 0, 0, 0)),
					},
					EventClick = function(sender, e)
						if NowHeadPage < MaxHeadPage then
							NowHeadPage = NowHeadPage+1
							args = {pid = state:GetCharacterId(),type = 1,page = NowHeadPage}
							rpc.safecall("personal_edit_list",args,Fill_HeadInfo)
						end
					end
				},
			},
		},
		
		Gui.Button "Change_head"
		{
			Size = Vector2(279, 57),
			Location = Vector2(171, 15),
			Text = lang:GetText("我的头像"),
			TextColor = ARGB(255, 255, 205, 69),
			HighlightTextColor = ARGB(255, 255, 205, 69),
			DisabledTextColor = ARGB(255, 217, 209, 201),
			FontSize = 20,
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_normal.dds", Vector4(15, 12, 15, 6)),
				HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_hover.dds", Vector4(15, 12, 15, 6)),
				DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_down.dds", Vector4(15, 12, 15, 6)),
				DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_normal.dds", Vector4(15, 12, 15, 6)),
			},
			EventClick = function(sender, e)

			end
		},
		
		Gui.Button "Change_achievement"
		{
			Size = Vector2(279, 57),
			Location = Vector2(473, 15),
			Text = lang:GetText("我的成就"),
			TextColor = ARGB(255, 255, 205, 69),
			HighlightTextColor = ARGB(255, 255, 205, 69),
			DisabledTextColor = ARGB(255, 217, 209, 201),
			FontSize = 20,
			Enable = false,
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_normal.dds", Vector4(15, 12, 15, 6)),
				HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_hover.dds", Vector4(15, 12, 15, 6)),
				DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_down.dds", Vector4(15, 12, 15, 6)),
				DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_normal.dds", Vector4(15, 12, 15, 6)),
			},
			EventClick = function(sender, e)
			
			end
		},
		
		Gui.Button "Save"
		{
			Size = Vector2(187,40),
			Location = Vector2(237,636),
			PushDown = false,
			Text = lang:GetText("确定"),
			FontSize = 20,
			TextColor = ARGB(255, 0, 0, 0),
			HighlightTextColor = ARGB(255, 0, 0, 0),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/lb_common_up_button_normal.dds", Vector4(20, 20, 20, 20)),
				HoverImage = Gui.Image("LobbyUI/lb_common_up_button_hover.dds", Vector4(20, 20, 20, 20)),
				DownImage = Gui.Image("LobbyUI/lb_common_up_button_down.dds", Vector4(20, 20, 20, 20)),
				DisabledImage = Gui.Image("LobbyUI/lb_common_up_button_disabled.dds", Vector4(20, 20, 20, 20)),		
			},
		},
		
		Gui.Button "Cancel"
		{
			Size = Vector2(187,40),
			Location = Vector2(521,636),
			PushDown = false,
			Text = lang:GetText("取消"),
			FontSize = 20,
			TextColor = ARGB(255, 0, 0, 0),
			HighlightTextColor = ARGB(255, 0, 0, 0),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/lb_common_up_button_normal.dds", Vector4(20, 20, 20, 20)),
				HoverImage = Gui.Image("LobbyUI/lb_common_up_button_hover.dds", Vector4(20, 20, 20, 20)),
				DownImage = Gui.Image("LobbyUI/lb_common_up_button_down.dds", Vector4(20, 20, 20, 20)),
				DisabledImage = Gui.Image("LobbyUI/lb_common_up_button_disabled.dds", Vector4(20, 20, 20, 20)),		
			},
		},
		
		Gui.Control "DisplayTitle"
		{
			Location = Vector2(313,29),
			Size = Vector2(665,510),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Visible = false,
			
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_tab01_right.dds", Vector4(20,20,20,20)),
			},
			
			Gui.Control "DisplayTitContent"
			{
				Location = Vector2(0,0),
				Size = Vector2(650,420),
				BackgroundColor = ARGB(0, 255, 255, 255),
			},
			
			Gui.Button "m_Left"
			{	Size = Vector2(20,31),
				Visible = true,
				Location = Vector2(500,440),
				
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/lb_shop_button05_normal.dds", Vector4(0, 0, 0, 0)),
					HoverImage = Gui.Image("LobbyUI/lb_shop_button05_hover.dds", Vector4(0, 0, 0, 0)),
					DownImage = Gui.Image("LobbyUI/lb_shop_button05_down.dds", Vector4(0, 0, 0, 0)),
					DisabledImage = Gui.Image("LobbyUI/lb_shop_button05_normal.dds", Vector4(0, 0, 0, 0)),
				},
			},
			
			Gui.Label "m_PageDisplay"
			{
				Size = Vector2(75,31),
				FontSize = 24,
				Visible = true,
				Location = Vector2(530,440),
				TextColor = ARGB(255, 128, 128, 128),
				TextAlign = "kAlignCenterMiddle",
				Text = "1/1",
				BackgroundColor = ARGB(255, 255, 255, 255),
	
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/lb_shop_button06_bg.dds", Vector4(14, 14, 14, 14)),
				},
			},
			
			Gui.Button "m_Right"
			{
				Size = Vector2(20,31),
				Visible = true,
				Location = Vector2(610,440),
				
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/lb_shop_button06_normal.dds", Vector4(0, 0, 0, 0)),
					HoverImage = Gui.Image("LobbyUI/lb_shop_button06_hover.dds", Vector4(0, 0, 0, 0)),
					DownImage = Gui.Image("LobbyUI/lb_shop_button06_down.dds", Vector4(0, 0, 0, 0)),
					DisabledImage = Gui.Image("LobbyUI/lb_shop_button06_normal.dds", Vector4(0, 0, 0, 0)),
				},
	
			},
		},
		
		Gui.Control "DisplayAchievement"
		{
			Location = Vector2(313,29),
			Size = Vector2(665,510),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Visible = false,
			
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_tab01_right.dds", Vector4(20 ,20,20,20)),
			},
			
			Gui.Button "bgeneral_achievement"
			{
				Location = Vector2(20,20),
				Size = Vector2(153,45),			
				BackgroundColor = ARGB(255, 255, 255, 255),				
				TextAlign = "kAlignCenterMiddle",
				TextColor = ARGB(255,236,224,208),
				FontSize = 20,
				Text = lang:GetText("一般成就"),
				
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_normal.dds", Vector4(10, 10, 10, 10)),
					HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_hover.dds", Vector4(10, 10, 10, 10)),
					DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_down.dds", Vector4(10, 10, 10, 10)),
					DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_normal.dds", Vector4(10, 10, 10, 10)),
				},
			},
			
			Gui.Button "bTask_achievement"
			{
				Location = Vector2(180,20),
				Size = Vector2(153,45),			
				BackgroundColor = ARGB(255, 255, 255, 255),				
				TextAlign = "kAlignCenterMiddle",
				TextColor = ARGB(255,236,224,208),
				FontSize = 20,
				Visible = false,
				Enable = false,
				Text = lang:GetText("任务成就"),
				
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_normal.dds", Vector4(10, 10, 10, 10)),
					HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_hover.dds", Vector4(10, 10, 10, 10)),
					DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_down.dds", Vector4(10, 10, 10, 10)),
					DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_normal.dds", Vector4(10, 10, 10, 10)),
				},
			},
			
			Gui.Button "bcharacter_achievement"
			{
				Location = Vector2(180,20),
				Size = Vector2(153,45),			
				BackgroundColor = ARGB(255, 255, 255, 255),				
				TextAlign = "kAlignCenterMiddle",
				TextColor = ARGB(255,236,224,208),
				FontSize = 20,
				Text = lang:GetText("角色成就"),
				
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_normal.dds", Vector4(10, 10, 10, 10)),
					HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_hover.dds", Vector4(10, 10, 10, 10)),
					DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_down.dds", Vector4(10, 10, 10, 10)),
					DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_normal.dds", Vector4(10, 10, 10, 10)),
				},
			},
			
			Gui.Control "General_Achievement"
			{
				Location = Vector2(20,70),
				Size = Vector2(600,350),
				BackgroundColor = ARGB(0, 255, 255, 255),
				
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/lb_info_xinxi_bg.dds", Vector4(14,14,14,14)),
				},
			},
			
			Gui.Control "Task_Achievement"
			{
				Location = Vector2(20,70),
				Size = Vector2(600,350),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Visible = false,
				
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/lb_info_xinxi_bg.dds", Vector4(14,14,14,14)),
				},
			},
			
			Gui.Control "character_Achievement"
			{
				Location = Vector2(20,70),
				Size = Vector2(600,350),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Visible = false,
				
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/lb_info_xinxi_bg.dds", Vector4(14,14,14,14)),
				},
			},
			
			Gui.Button "m_AcheLeft"
			{	
				Size = Vector2(20,31),
				Visible = true,
				Location = Vector2(500,440),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/lb_shop_button05_normal.dds", Vector4(0, 0, 0, 0)),
					HoverImage = Gui.Image("LobbyUI/lb_shop_button05_hover.dds", Vector4(0, 0, 0, 0)),
					DownImage = Gui.Image("LobbyUI/lb_shop_button05_down.dds", Vector4(0, 0, 0, 0)),
					DisabledImage = Gui.Image("LobbyUI/lb_shop_button05_normal.dds", Vector4(0, 0, 0, 0)),
				},
			},
			
			Gui.Label "m_AchePageDisplay"
			{
				Size = Vector2(75,31),
				FontSize = 24,
				Visible = true,
				Location = Vector2(530,440),
				TextColor = ARGB(255, 128, 128, 128),
				TextAlign = "kAlignCenterMiddle",
				Text = "1/1",
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/lb_shop_button06_bg.dds", Vector4(14, 14, 14, 14)),
				},
			},
			
			Gui.Button "m_AcheRight"
			{
				Size = Vector2(20,31),
				Visible = true,
				Location = Vector2(610,440),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/lb_shop_button06_normal.dds", Vector4(0, 0, 0, 0)),
					HoverImage = Gui.Image("LobbyUI/lb_shop_button06_hover.dds", Vector4(0, 0, 0, 0)),
					DownImage = Gui.Image("LobbyUI/lb_shop_button06_down.dds", Vector4(0, 0, 0, 0)),
					DisabledImage = Gui.Image("LobbyUI/lb_shop_button06_normal.dds", Vector4(0, 0, 0, 0)),
				},
	
			},
			
		},
		
		Gui.Button "Change_name"
		{
			Size = Vector2(282,125),
			Location = Vector2(25,225),
			BackgroundColor = ARGB(255, 255, 255, 255),
			--Enable = false,
			Visible = false,
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_bg_02.dds", Vector4(20,0,0,0)),
				DownImage = Gui.Image("LobbyUI/persionalInfo/lb_info_bg_02.dds", Vector4(20,0,0,0)),
			},
			
			Gui.Label "title_text"
			{
				Size = Vector2(96,26),
				Location = Vector2(101,10),
				BackgroundColor = ARGB(255, 255, 255, 255),
				
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_text02.dds", Vector4(0, 0, 0, 0)),
				},
			},
			
			Gui.Label "MyTitle1"
			{
				Location = Vector2(80,20),
				Size = Vector2(120,30),
				BackgroundColor = ARGB(0, 255, 255, 255),
				TextAlign = "kAlignCenterMiddle",
				TextColor = ARGB(255, 215, 232, 227),
				FontSize = 20,
				Visible = false,
				Text = lang:GetText("我的称号"),
			},
			
			Gui.Label "MyTitle2"
			{
				Location = Vector2(60,70),
				Size = Vector2(40,20),
				BackgroundColor = ARGB(0, 255, 255, 255),
				TextAlign = "kAlignCenterMiddle",
				TextColor = ARGB(255, 215, 232, 227),
				FontSize = 14,
				Visible = false,
				Text = lang:GetText("称号"),
			},
			
			Gui.Label "MyTitle3"
			{
				Location = Vector2(110,70),
				Size = Vector2(120,20),
				BackgroundColor = ARGB(0, 255, 255, 255),
				TextAlign = "kAlignCenterMiddle",
				TextColor = ARGB(255,253,211,77),
				FontSize = 14,
			},
			
		},
		
		Gui.Button
		{
			Size = Vector2(282,160),
			Location = Vector2(25,356),
			BackgroundColor = ARGB(255, 255, 255, 255),
			--Enable = false,
			Visible = false,
			Gui.Label "achievement_text"
			{
				Size = Vector2(122,26),
				Location = Vector2(88,13),
				BackgroundColor = ARGB(255, 255, 255, 255),
				
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_text03.dds", Vector4(0, 0, 0, 0)),
				},
			},
			
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_bg_02.dds", Vector4(20,0,0,0)),
				DownImage = Gui.Image("LobbyUI/persionalInfo/lb_info_bg_02.dds", Vector4(20,0,0,0)),
			},
			
			Gui.Label "MyAchievement1"
			{
				Location = Vector2(80,10),
				Size = Vector2(120,30),
				BackgroundColor = ARGB(0, 255, 255, 255),
				TextAlign = "kAlignCenterMiddle",
				TextColor = ARGB(255, 215, 232, 227),
				FontSize = 20,
				Visible = false,
				Text = lang:GetText("成就陈列架"),
			},
			
			Gui.Label "MyAchievement2Back"
			{
				Location = Vector2(2,37),
				Size = Vector2(70,70),
				Visible = false,
				BackgroundColor = ARGB(255,255, 255, 255),
				
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_acheive_bg.dds", Vector4(14, 14, 14, 14)),
				},
			},
			
			Gui.Button "MyAchievement2"
			{
				Location = Vector2(10,45),
				Size = Vector2(54,54),
				Visible = false,
				BackgroundColor = ARGB(255,255, 255, 255),
				
				EventMouseEnter = function(Sender,e)
					if Select_Drag_label  and Select_Drag_Skin then
						local Skin = nil
						Skin = Gui.ButtonSkin{BackgroundImage = Gui.Image("LobbyUI/persionalInfo/achieves/acheiveabc.dds", Vector4(14,14,14,14)),}
												
						for i = 1,4 do
							if SelectAchievementArray[i] == Select_Drag_label then
								SelectAchievementArray[i] = -1
								
								if i == 1 then
									edit_persional_win_ui.MyAchievement2.Skin = Skin
								elseif i == 2 then
									edit_persional_win_ui.MyAchievement3.Skin = Skin
								elseif i == 3 then
									edit_persional_win_ui.MyAchievement4.Skin = Skin
								elseif i == 4 then
									edit_persional_win_ui.MyAchievement5.Skin = Skin
								end
							end
						end
						
						Sender.Skin = Select_Drag_Skin
						SelectAchievementArray[1] = Select_Drag_label
						Select_Drag_Skin = nil
						Select_Drag_label = nil
					end
				end,
			},
			
			Gui.Button "BMyAchievement2"
			{
				Location = Vector2(10,110),
				Size = Vector2(60,30),
				BackgroundColor = ARGB(255,255, 255, 255),
				FontSize = 14,
				Text = lang:GetText("修改"),
				Visible = false,
				
				Skin = Skin.ButtonSkin_ItemBoxBtn,
				
				EventClick = function()
					edit_persional_win_ui.Change_head.PushDown = false
					edit_persional_win_ui.Change_name.PushDown = false
					edit_persional_win_ui.Change_achievement.PushDown = true
					
					edit_persional_win_ui.DisplayHead.Visible = false
					edit_persional_win_ui.DisplayTitle.Visible = false
					edit_persional_win_ui.DisplayAchievement.Visible = true
					
					edit_persional_win_ui.BMyAchievement2.PushDown = true
					edit_persional_win_ui.BMyAchievement3.PushDown = false
					edit_persional_win_ui.BMyAchievement4.PushDown = false
					edit_persional_win_ui.BMyAchievement5.PushDown = false
					SelectAchievementButton = 2
				end
			},
			
			Gui.Label "MyAchievement3Back"
			{
				Location = Vector2(72,37),
				Size = Vector2(70,70),
				Visible = false,
				BackgroundColor = ARGB(255,255, 255, 255),
				
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_acheive_bg.dds", Vector4(14, 14, 14, 14)),
				},
			},
			
			Gui.Button "MyAchievement3"
			{
				Location = Vector2(80,45),
				Size = Vector2(54,54),
				Visible = false,
				BackgroundColor = ARGB(255,255, 255, 255),
			},
			
			Gui.Button "BMyAchievement3"
			{
				Location = Vector2(80,110),
				Size = Vector2(60,30),
				BackgroundColor = ARGB(255,255, 255, 255),
				FontSize = 14,
				Text = lang:GetText("修改"),				
				Skin = Skin.ButtonSkin_ItemBoxBtn,
				Visible = false,
				
				EventClick = function()
					edit_persional_win_ui.Change_head.PushDown = false
					edit_persional_win_ui.Change_name.PushDown = false
					edit_persional_win_ui.Change_achievement.PushDown = true
					
					edit_persional_win_ui.DisplayHead.Visible = false
					edit_persional_win_ui.DisplayTitle.Visible = false
					edit_persional_win_ui.DisplayAchievement.Visible = true
					
					edit_persional_win_ui.BMyAchievement2.PushDown = false
					edit_persional_win_ui.BMyAchievement3.PushDown = true
					edit_persional_win_ui.BMyAchievement4.PushDown = false
					edit_persional_win_ui.BMyAchievement5.PushDown = false
					SelectAchievementButton = 3
				end
			},
			
			Gui.Label "MyAchievement4Back"
			{
				Location = Vector2(142,37),
				Size = Vector2(70,70),
				Visible = false,
				BackgroundColor = ARGB(255,255, 255, 255),
				
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_acheive_bg.dds", Vector4(14, 14, 14, 14)),
				},
			},
			
			Gui.Button "MyAchievement4"
			{
				Location = Vector2(150,45),
				Size = Vector2(54,54),
				Visible = false,
				BackgroundColor = ARGB(255,255, 255, 255),
			},
			
			Gui.Button "BMyAchievement4"
			{
				Location = Vector2(150,110),
				Size = Vector2(60,30),
				BackgroundColor = ARGB(255,255, 255, 255),
				FontSize = 14,
				Text = lang:GetText("修改"),				
				Skin = Skin.ButtonSkin_ItemBoxBtn,
				Visible = false,
				
				EventClick = function()
					edit_persional_win_ui.Change_head.PushDown = false
					edit_persional_win_ui.Change_name.PushDown = false
					edit_persional_win_ui.Change_achievement.PushDown = true
					
					edit_persional_win_ui.DisplayHead.Visible = false
					edit_persional_win_ui.DisplayTitle.Visible = false
					edit_persional_win_ui.DisplayAchievement.Visible = true
					
					edit_persional_win_ui.BMyAchievement2.PushDown = false
					edit_persional_win_ui.BMyAchievement3.PushDown = false
					edit_persional_win_ui.BMyAchievement4.PushDown = true
					edit_persional_win_ui.BMyAchievement5.PushDown = false
					SelectAchievementButton = 4
				end
			},
			
			Gui.Label "MyAchievement5Back"
			{
				Location = Vector2(212,37),
				Size = Vector2(70,70),
				Visible = false,
				BackgroundColor = ARGB(255,255, 255, 255),
				
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_acheive_bg.dds", Vector4(14, 14, 14, 14)),
				},
			},
			
			Gui.Button "MyAchievement5"
			{
				Location = Vector2(220,45),
				Size = Vector2(54,54),
				Visible = false,
				BackgroundColor = ARGB(255,255, 255, 255),
			},
			
			Gui.Button "BMyAchievement5"
			{
				Location = Vector2(220,110),
				Size = Vector2(60,30),
				BackgroundColor = ARGB(255,255, 255, 255),
				FontSize = 14,
				Text = lang:GetText("修改"),			
				Skin = Skin.ButtonSkin_ItemBoxBtn,
				Visible = false,
				
				EventClick = function()
					edit_persional_win_ui.Change_head.PushDown = false
					edit_persional_win_ui.Change_name.PushDown = false
					edit_persional_win_ui.Change_achievement.PushDown = true
					
					edit_persional_win_ui.DisplayHead.Visible = false
					edit_persional_win_ui.DisplayTitle.Visible = false
					edit_persional_win_ui.DisplayAchievement.Visible = true
			
					edit_persional_win_ui.BMyAchievement2.PushDown = false
					edit_persional_win_ui.BMyAchievement3.PushDown = false
					edit_persional_win_ui.BMyAchievement4.PushDown = false
					edit_persional_win_ui.BMyAchievement5.PushDown = true
					SelectAchievementButton = 5
				end
			},
		},
	},
}

local main_report_window = 
{
	Gui.Control "ctrl_main_report_window"
	{
		Size = Vector2(1116, 586),
		Location = Vector2(19, 25),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/mail/lb_shop_bg2.dds", Vector4(14, 14, 14, 14)),
		},
		
		Gui.Control "boddy_info_BG"
		{
			Size = Vector2(1101, 551),
			Location = Vector2(9, 35),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_daoju_bg.tga", Vector4(22, 22, 22, 22)),
			},
		},
		
		Gui.Control "boddy_info_content"
		{
			Size = Vector2(1045, 480),
			Location = Vector2(30, 85),
			BackgroundColor = ARGB(255, 255, 255, 255),			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg3.dds", Vector4(22, 22, 22, 22)),
			},
		},
		
		Gui.Button "btn_Close"
		{
			Size = Vector2(64, 52),
			Location = Vector2(1049, 3),
			PushDown = false,
			Hint = lang:GetText("关闭个人信息并返回至战区"),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button01_normal.dds", Vector4(0, 0, 0, 0)),
				HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button01_hover.dds", Vector4(0, 0, 0, 0)),
				DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button01_down.dds", Vector4(0, 0, 0, 0)),
				DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button01_normal.dds", Vector4(0, 0, 0, 0)),
			},
		},
		Gui.ComboBox "game_time"
		{
			Size = Vector2(350,36),
			FontSize = 18,
			Readonly = true,
			Location = Vector2(250,95),
			TextColor = ARGB(255,236,224,208),
			ChildComboListStyle =  "Gui.teamComboList",
			Text = lang:GetText("使用次数"),
		},
		
		-- Gui.Control "keep_pic_back"
		-- {
			-- Size = Vector2(131,50),
			-- Location = Vector2(795,86),
			-- BackgroundColor = ARGB(255, 255, 255, 255),

			-- Skin = Gui.ControlSkin
			-- {
				-- BackgroundImage = Gui.Image("LobbyUI/lb_common_button_bg01.dds", Vector4(20, 20, 20, 20)),
			-- },
		-- },
		
		Gui.Button "keep_shot"
		{
			Size = Vector2(220,32),
			Location = Vector2(800,98),
			TextAlign = "kAlignRightMiddle",
			Text = lang:GetText("保存截图").." ",
			Enable = false,
			TextColor = ARGB(255,54,53,49),
			FontSize = 17,
			-- Style = "Gui.TakeShotButton",
		},
		
		Gui.Label "Line1"
		{
			Size = Vector2(850,12),
			Location = Vector2(150,447),
			BackgroundColor = ARGB(255, 255, 255, 255),
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_line03.dds", Vector4(14, 0, 0, 0)),
			},
		},
		
		Gui.Label "limit1"
		{
			Location = Vector2(50,300),
			Size = Vector2(90,44),
			BackgroundColor = ARGB(0, 255, 255, 255),
			TextAlign = "kAlignCenterMiddle",
			TextColor = ARGB(255,253,211,77),
			FontSize = 18,
		},
		
		Gui.Label "Line2"
		{
			Size = Vector2(850,12),
			Location = Vector2(150,320),
			BackgroundColor = ARGB(255, 255, 255, 255),
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_line02.dds", Vector4(14, 0, 0, 0)),
			},
		},
		
		Gui.Label "LineSpace2"
		{
			Size = Vector2(24,88),
			Location = Vector2(150,342),
			BackgroundColor = ARGB(255, 255, 255, 255),
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_line04.dds", Vector4(0, 0, 0, 0)),
			},
		},
		
		Gui.Label "limit2"
		{
			Location = Vector2(50,170),
			Size = Vector2(90,44),
			BackgroundColor = ARGB(0, 255, 255, 255),
			TextAlign = "kAlignCenterMiddle",
			TextColor = ARGB(255,253,211,77),
			FontSize = 18,
		},
		
		Gui.Label "Line3"
		{
			Size = Vector2(850,12),
			Location = Vector2(150,191),
			BackgroundColor = ARGB(255, 255, 255, 255),
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_line02.dds", Vector4(14, 0, 0, 0)),
			},
		},
		
		Gui.Label "LineSpace1"
		{
			Size = Vector2(24,88),
			Location = Vector2(150,211),
			BackgroundColor = ARGB(255, 255, 255, 255),
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_line04.dds", Vector4(0, 0, 0, 0)),
			},
		},
		-----------------------------------------------------------------------------------------------
		Gui.Label "LNumLabel"
		{
			Location = Vector2(0,0),
			Size = Vector2(60,50),
			BackgroundColor = ARGB(0, 255, 255, 255),
			TextAlign = "kAlignCenterMiddle",
			TextColor = ARGB(255, 215, 232, 227),
			FontSize = 15,					
		},
		
		Gui.Label "colunm1"
		{
			Size = Vector2(80,0),
			Location = Vector2(280,450),
			BackgroundColor = ARGB(255,255,255,255),
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_bar03.tga", Vector4(8, 8, 8, 8)),
			},
		},
		
		Gui.Label "LPaoge"
		{
			Size = Vector2(50,50),
			Location = Vector2(288,460),
			BackgroundColor = ARGB(255, 255, 255, 255),
			TextAlign = "kAlignCenterMiddle",
			TextColor = ARGB(255,226,217,208),
			FontSize = 20,
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/GameBalance/summary_ico_fairman_win.dds", Vector4(0, 0, 0, 0)),
			},
		},
		
		Gui.Label "LPaoge_name"
		{
			Size = Vector2(70,30),
			Location = Vector2(278,510),
			BackgroundColor = ARGB(0, 255, 255, 255),
			TextAlign = "kAlignCenterMiddle",
			TextColor = ARGB(255,253,211,77),
			FontSize = 15,
			Text = lang:GetText("火箭兵"),
		},
		-----------------------------------------------------------------------------------------------
		Gui.Label "LNumLabe2"
		{
			Location = Vector2(0,0),
			Size = Vector2(60,50),
			BackgroundColor = ARGB(0, 255, 255, 255),
			TextAlign = "kAlignCenterMiddle",
			TextColor = ARGB(255, 215, 232, 227),
			FontSize = 15,					
		},
		
		Gui.Label "colunm2"
		{
			Size = Vector2(80,0),
			Location = Vector2(375,450),
			BackgroundColor = ARGB(255,255,255,255),
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_bar03.tga", Vector4(8, 8, 8, 8)),
			},
		},
		
		Gui.Label "LMizong"
		{
			Size = Vector2(50,50),
			Location = Vector2(383,460),
			BackgroundColor = ARGB(255, 255, 255, 255),
			TextAlign = "kAlignCenterMiddle",
			TextColor = ARGB(255,226,217,208),
			FontSize = 20,
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/GameBalance/summary_ico_butcher_win.dds", Vector4(0, 0, 0, 0)),
			},
		},
		
		Gui.Label "LMizong_name"
		{
			Size = Vector2(70,30),
			Location = Vector2(373,510),
			BackgroundColor = ARGB(0, 255, 255, 255),
			TextAlign = "kAlignCenterMiddle",
			TextColor = ARGB(255,253,211,77),
			FontSize = 15,
			Text = lang:GetText("重机枪手"),
		},
		-----------------------------------------------------------------------------------------------
		Gui.Label "LNumLabe3"
		{
			Location = Vector2(0,0),
			Size = Vector2(60,50),
			BackgroundColor = ARGB(0, 255, 255, 255),
			TextAlign = "kAlignCenterMiddle",
			TextColor = ARGB(255, 215, 232, 227),
			FontSize = 15,					
		},
		
		Gui.Label "colunm3"
		{
			Size = Vector2(80,0),
			Location = Vector2(470,450),
			BackgroundColor = ARGB(255,255,255,255),
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_bar03.tga", Vector4(8, 8, 8, 8)),
			},
		},
		
		Gui.Label "LSniper"
		{
			Size = Vector2(50,50),
			Location = Vector2(478,460),
			BackgroundColor = ARGB(255, 255, 255, 255),
			TextAlign = "kAlignCenterMiddle",
			TextColor = ARGB(255,226,217,208),
			FontSize = 20,
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/GameBalance/summary_ico_ol_win.dds", Vector4(0, 0, 0, 0)),
			},
		},
		
		Gui.Label "LSniper_name"
		{
			Size = Vector2(70,30),
			Location = Vector2(468,510),
			BackgroundColor = ARGB(0, 255, 255, 255),
			TextAlign = "kAlignCenterMiddle",
			TextColor = ARGB(255,253,211,77),
			FontSize = 15,
			Text = lang:GetText("狙击手"),
		},
		-----------------------------------------------------------------------------------------------
		Gui.Label "LNumLabe4"
		{
			Location = Vector2(0,0),
			Size = Vector2(60,50),
			BackgroundColor = ARGB(0, 255, 255, 255),
			TextAlign = "kAlignCenterMiddle",
			TextColor = ARGB(255, 215, 232, 227),
			FontSize = 15,					
		},
		
		Gui.Label "colunm4"
		{
			Size = Vector2(80,0),
			Location = Vector2(565,450),
			BackgroundColor = ARGB(255,255,255,255),
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_bar03.tga", Vector4(8, 8, 8, 8)),
			},
		},
		
		Gui.Label "LShangxiao"
		{
			Size = Vector2(50,50),
			Location = Vector2(572,460),
			BackgroundColor = ARGB(255, 255, 255, 255),
			TextAlign = "kAlignCenterMiddle",
			TextColor = ARGB(255,226,217,208),
			FontSize = 20,
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/GameBalance/summary_ico_teamleader_win.dds", Vector4(0, 0, 0, 0)),
			},
		},
		
		Gui.Label "LShangxiao_name"
		{
			Size = Vector2(70,30),
			Location = Vector2(562,510),
			BackgroundColor = ARGB(0, 255, 255, 255),
			TextAlign = "kAlignCenterMiddle",
			TextColor = ARGB(255,253,211,77),
			FontSize = 15,
			Text = lang:GetText("突击手"),
		},
		-----------------------------------------------------------------------------------------------
		Gui.Label "LNumLabe5"
		{
			Location = Vector2(0,0),
			Size = Vector2(60,50),
			BackgroundColor = ARGB(0, 255, 255, 255),
			TextAlign = "kAlignCenterMiddle",
			TextColor = ARGB(255, 215, 232, 227),
			FontSize = 15,					
		},
		
		Gui.Label "colunm5"
		{
			Size = Vector2(80,0),
			Location = Vector2(660,450),
			BackgroundColor = ARGB(255,255,255,255),
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_bar03.tga", Vector4(8, 8, 8, 8)),
			},
		},
		
		Gui.Label "Lfireman"
		{
			Size = Vector2(50,50),
			Location = Vector2(668,460),
			BackgroundColor = ARGB(255, 255, 255, 255),
			TextAlign = "kAlignCenterMiddle",
			TextColor = ARGB(255,226,217,208),
			FontSize = 20,
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/GameBalance/summary_ico_penhuobing_win.dds", Vector4(0, 0, 0, 0)),
			},
		},
		
		Gui.Label "Lfireman_none"
		{
			Size = Vector2(50,50),
			Location = Vector2(668,460),
			BackgroundColor = ARGB(255, 255, 255, 255),
			TextAlign = "kAlignCenterMiddle",
			TextColor = ARGB(255,226,217,208),
			FontSize = 20,
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_ch_none.dds", Vector4(0, 0, 0, 0)),
			},
		},
		
		Gui.Label "Lfireman_name"
		{
			Size = Vector2(70,30),
			Location = Vector2(658,510),
			BackgroundColor = ARGB(0, 255, 255, 255),
			TextAlign = "kAlignCenterMiddle",
			TextColor = ARGB(255,253,211,77),
			FontSize = 15,
			Text = lang:GetText("火焰兵"),
		},
		-----------------------------------------------------------------------------------------------
		Gui.Label "LNumLabe6"
		{
			Location = Vector2(0,0),
			Size = Vector2(60,50),
			BackgroundColor = ARGB(0, 255, 255, 255),
			TextAlign = "kAlignCenterMiddle",
			TextColor = ARGB(255, 215, 232, 227),
			FontSize = 15,					
		},
		
		Gui.Label "colunm6"
		{
			Size = Vector2(80,0),
			Location = Vector2(755,450),
			BackgroundColor = ARGB(255,255,255,255),
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_bar03.tga", Vector4(8, 8, 8, 8)),
			},
		},
		
		Gui.Label "LNurse"
		{
			Size = Vector2(50,50),
			Location = Vector2(763,460),
			BackgroundColor = ARGB(255, 255, 255, 255),
			TextAlign = "kAlignCenterMiddle",
			TextColor = ARGB(255,226,217,208),
			FontSize = 20,
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/GameBalance/summary_ico_nurse_win.dds", Vector4(0, 0, 0, 0)),
			},
		},
		
		Gui.Label "LNurse_name"
		{
			Size = Vector2(70,30),
			Location = Vector2(753,510),
			BackgroundColor = ARGB(0, 255, 255, 255),
			TextAlign = "kAlignCenterMiddle",
			TextColor = ARGB(255,253,211,77),
			FontSize = 15,
			Text = lang:GetText("医疗兵"),
		},
		
		Gui.Label "LNumLabe7"
		{
			Location = Vector2(0,0),
			Size = Vector2(60,50),
			BackgroundColor = ARGB(0, 255, 255, 255),
			TextAlign = "kAlignCenterMiddle",
			TextColor = ARGB(255, 215, 232, 227),
			FontSize = 15,					
		},
		
		Gui.Label "colunm7"
		{
			Size = Vector2(80,0),
			Location = Vector2(850,450),
			BackgroundColor = ARGB(255,255,255,255),
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_bar03.tga", Vector4(8, 8, 8, 8)),
			},
		},
		
		Gui.Label "LEngineer"
		{
			Size = Vector2(50,50),
			Location = Vector2(858,460),
			BackgroundColor = ARGB(255, 255, 255, 255),
			TextAlign = "kAlignCenterMiddle",
			TextColor = ARGB(255,226,217,208),
			FontSize = 20,
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/GameBalance/summary_ico_engineer_win.dds", Vector4(0, 0, 0, 0)),
			},
		},
		
		Gui.Label "LEngineer_name"
		{
			Size = Vector2(70,30),
			Location = Vector2(848,510),
			BackgroundColor = ARGB(0, 255, 255, 255),
			TextAlign = "kAlignCenterMiddle",
			TextColor = ARGB(255,253,211,77),
			FontSize = 15,
			Text = lang:GetText("工程兵"),
		},
	},	
}

local main_highlight_window = 
{
	Gui.Control "ctrl_main_highlight_window"
	{
		Size = Vector2(1116, 586),
		Location = Vector2(19, 25),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/mail/lb_shop_bg2.dds", Vector4(14, 14, 14, 14)),
		},
		
		Gui.Control "boddy_info_BG"
		{
			Size = Vector2(1101, 551),
			Location = Vector2(9, 35),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_daoju_bg.tga", Vector4(22, 22, 22, 22)),
			},
		},
		
		Gui.Control "boddy_info_content"
		{
			Size = Vector2(1045, 480),
			Location = Vector2(30, 85),
			BackgroundColor = ARGB(255, 255, 255, 255),			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg3.dds", Vector4(22, 22, 22, 22)),
			},
		},
		
		Gui.Button "btn_Close"
		{
			Size = Vector2(64, 52),
			Location = Vector2(1049, 3),
			PushDown = false,
			Hint = lang:GetText("关闭个人信息并返回至战区"),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button01_normal.dds", Vector4(0, 0, 0, 0)),
				HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button01_hover.dds", Vector4(0, 0, 0, 0)),
				DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button01_down.dds", Vector4(0, 0, 0, 0)),
				DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button01_normal.dds", Vector4(0, 0, 0, 0)),
			},
		},
		Gui.ComboBox "game_time"
		{
			Size = Vector2(350,36),
			FontSize = 18,
			Readonly = true,
			Location = Vector2(250,95),
			TextColor = ARGB(255,236,224,208),
			ChildComboListStyle =  "Gui.teamComboList",
			Text = lang:GetText("最高得分"),
		},
		
		-- Gui.Control "keep_pic_back"
		-- {
			-- Size = Vector2(131,50),
			-- Location = Vector2(795,86),
			-- BackgroundColor = ARGB(255, 255, 255, 255),

			-- Skin = Gui.ControlSkin
			-- {
				-- BackgroundImage = Gui.Image("LobbyUI/lb_common_button_bg01.dds", Vector4(20, 20, 20, 20)),
			-- },
		-- },
		
		Gui.Button "keep_shot"
		{
			Size = Vector2(220,32),
			Location = Vector2(800,98),
			TextAlign = "kAlignRightMiddle",
			Text = lang:GetText("保存截图").." ",
			Enable = false,
			TextColor = ARGB(255,54,53,49),
			FontSize = 17,
			-- Style = "Gui.TakeShotButton",
		},
		
		Gui.Label "Line1"
		{
			Size = Vector2(850,12),
			Location = Vector2(150,447),
			BackgroundColor = ARGB(255, 255, 255, 255),
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_line03.dds", Vector4(14, 0, 0, 0)),
			},
		},
		
		Gui.Label "limit1"
		{
			Location = Vector2(50,300),
			Size = Vector2(90,44),
			BackgroundColor = ARGB(0, 255, 255, 255),
			TextAlign = "kAlignCenterMiddle",
			TextColor = ARGB(255,253,211,77),
			FontSize = 18,
		},
		
		Gui.Label "Line2"
		{
			Size = Vector2(850,12),
			Location = Vector2(150,320),
			BackgroundColor = ARGB(255, 255, 255, 255),
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_line02.dds", Vector4(14, 0, 0, 0)),
			},
		},
		
		Gui.Label "LineSpace2"
		{
			Size = Vector2(24,88),
			Location = Vector2(150,342),
			BackgroundColor = ARGB(255, 255, 255, 255),
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_line04.dds", Vector4(0, 0, 0, 0)),
			},
		},
		
		Gui.Label "limit2"
		{
			Location = Vector2(50,170),
			Size = Vector2(95,44),
			BackgroundColor = ARGB(0, 255, 255, 255),
			TextAlign = "kAlignCenterMiddle",
			TextColor = ARGB(255,253,211,77),
			FontSize = 18,
		},
		
		Gui.Label "Line3"
		{
			Size = Vector2(850,12),
			Location = Vector2(150,191),
			BackgroundColor = ARGB(255, 255, 255, 255),
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_line02.dds", Vector4(14, 0, 0, 0)),
			},
		},
		
		Gui.Label "LineSpace1"
		{
			Size = Vector2(24,88),
			Location = Vector2(150,211),
			BackgroundColor = ARGB(255, 255, 255, 255),
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_line04.dds", Vector4(0, 0, 0, 0)),
			},
		},
		
		Gui.Label "LNumLabel"
		{
			Location = Vector2(0,0),
			Size = Vector2(60,50),
			BackgroundColor = ARGB(0, 255, 255, 255),
			TextAlign = "kAlignCenterMiddle",
			TextColor = ARGB(255, 215, 232, 227),
			FontSize = 15,					
		},
		
		Gui.Label "colunm1"
		{
			Size = Vector2(80,0),
			Location = Vector2(280,450),
			BackgroundColor = ARGB(255,255,255,255),
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_bar03.tga", Vector4(8, 8, 8, 8)),
			},
		},
		
		Gui.Label "LPaoge"
		{
			Size = Vector2(50,50),
			Location = Vector2(288,460),
			BackgroundColor = ARGB(255, 255, 255, 255),
			TextAlign = "kAlignCenterMiddle",
			TextColor = ARGB(255,226,217,208),
			FontSize = 20,
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/GameBalance/summary_ico_fairman_win.dds", Vector4(0, 0, 0, 0)),
			},
		},
		
		Gui.Label "LPaoge_name"
		{
			Size = Vector2(70,30),
			Location = Vector2(278,510),
			BackgroundColor = ARGB(0, 255, 255, 255),
			TextAlign = "kAlignCenterMiddle",
			TextColor = ARGB(255,253,211,77),
			FontSize = 15,
			Text = lang:GetText("火箭兵"),
		},
		
		Gui.Label "LNumLabe2"
		{
			Location = Vector2(0,0),
			Size = Vector2(60,50),
			BackgroundColor = ARGB(0, 255, 255, 255),
			TextAlign = "kAlignCenterMiddle",
			TextColor = ARGB(255, 215, 232, 227),
			FontSize = 15,					
		},
		
		Gui.Label "colunm2"
		{
			Size = Vector2(80,0),
			Location = Vector2(375,450),
			BackgroundColor = ARGB(255,255,255,255),
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_bar03.tga", Vector4(8, 8, 8, 8)),
			},
		},
		
		Gui.Label "LMizong"
		{
			Size = Vector2(50,50),
			Location = Vector2(383,460),
			BackgroundColor = ARGB(255, 255, 255, 255),
			TextAlign = "kAlignCenterMiddle",
			TextColor = ARGB(255,226,217,208),
			FontSize = 20,
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/GameBalance/summary_ico_butcher_win.dds", Vector4(0, 0, 0, 0)),
			},
		},
		
		Gui.Label "LMizong_name"
		{
			Size = Vector2(70,30),
			Location = Vector2(373,510),
			BackgroundColor = ARGB(0, 255, 255, 255),
			TextAlign = "kAlignCenterMiddle",
			TextColor = ARGB(255,253,211,77),
			FontSize = 15,
			Text = lang:GetText("重机枪手"),
		},
		
		Gui.Label "LNumLabe3"
		{
			Location = Vector2(0,0),
			Size = Vector2(60,50),
			BackgroundColor = ARGB(0, 255, 255, 255),
			TextAlign = "kAlignCenterMiddle",
			TextColor = ARGB(255, 215, 232, 227),
			FontSize = 15,					
		},
		
		Gui.Label "colunm3"
		{
			Size = Vector2(80,0),
			Location = Vector2(470,450),
			BackgroundColor = ARGB(255,255,255,255),
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_bar03.tga", Vector4(8, 8, 8, 8)),
			},
		},
		
		Gui.Label "LSniper"
		{
			Size = Vector2(50,50),
			Location = Vector2(478,460),
			BackgroundColor = ARGB(255, 255, 255, 255),
			TextAlign = "kAlignCenterMiddle",
			TextColor = ARGB(255,226,217,208),
			FontSize = 20,
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/GameBalance/summary_ico_ol_win.dds", Vector4(0, 0, 0, 0)),
			},
		},
		
		Gui.Label "LSniper_name"
		{
			Size = Vector2(70,30),
			Location = Vector2(468,510),
			BackgroundColor = ARGB(0, 255, 255, 255),
			TextAlign = "kAlignCenterMiddle",
			TextColor = ARGB(255,253,211,77),
			FontSize = 15,
			Text = lang:GetText("狙击手"),
		},
		
		Gui.Label "LNumLabe4"
		{
			Location = Vector2(0,0),
			Size = Vector2(60,50),
			BackgroundColor = ARGB(0, 255, 255, 255),
			TextAlign = "kAlignCenterMiddle",
			TextColor = ARGB(255, 215, 232, 227),
			FontSize = 15,					
		},
		
		Gui.Label "colunm4"
		{
			Size = Vector2(80,0),
			Location = Vector2(565,450),
			BackgroundColor = ARGB(255,255,255,255),
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_bar03.tga", Vector4(8, 8, 8, 8)),
			},
		},
		
		Gui.Label "LShangxiao"
		{
			Size = Vector2(50,50),
			Location = Vector2(572,460),
			BackgroundColor = ARGB(255, 255, 255, 255),
			TextAlign = "kAlignCenterMiddle",
			TextColor = ARGB(255,226,217,208),
			FontSize = 20,
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/GameBalance/summary_ico_teamleader_win.dds", Vector4(0, 0, 0, 0)),
			},
		},
		
		Gui.Label "LShangxiao_name"
		{
			Size = Vector2(70,30),
			Location = Vector2(562,510),
			BackgroundColor = ARGB(0, 255, 255, 255),
			TextAlign = "kAlignCenterMiddle",
			TextColor = ARGB(255,253,211,77),
			FontSize = 15,
			Text = lang:GetText("突击手"),
		},
		
		Gui.Label "LNumLabe5"
		{
			Location = Vector2(0,0),
			Size = Vector2(60,50),
			BackgroundColor = ARGB(0, 255, 255, 255),
			TextAlign = "kAlignCenterMiddle",
			TextColor = ARGB(255, 215, 232, 227),
			FontSize = 15,					
		},
		
		Gui.Label "colunm5"
		{
			Size = Vector2(80,0),
			Location = Vector2(660,450),
			BackgroundColor = ARGB(255,255,255,255),
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_bar03.tga", Vector4(8, 8, 8, 8)),
			},
		},
		
		Gui.Label "Lfireman"
		{
			Size = Vector2(50,50),
			Location = Vector2(668,460),
			BackgroundColor = ARGB(255, 255, 255, 255),
			TextAlign = "kAlignCenterMiddle",
			TextColor = ARGB(255,226,217,208),
			FontSize = 20,
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/GameBalance/summary_ico_penhuobing_win.dds", Vector4(0, 0, 0, 0)),
			},
		},
		
		Gui.Label "Lfireman_none"
		{
			Size = Vector2(50,50),
			Location = Vector2(668,460),
			BackgroundColor = ARGB(255, 255, 255, 255),
			TextAlign = "kAlignCenterMiddle",
			TextColor = ARGB(255,226,217,208),
			FontSize = 20,
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_ch_none.dds", Vector4(0, 0, 0, 0)),
			},
		},
		
		Gui.Label "Lfireman_name"
		{
			Size = Vector2(70,30),
			Location = Vector2(658,510),
			BackgroundColor = ARGB(0, 255, 255, 255),
			TextAlign = "kAlignCenterMiddle",
			TextColor = ARGB(255,253,211,77),
			FontSize = 15,
			Text = lang:GetText("火焰兵"),
		},
		
		Gui.Label "LNumLabe6"
		{
			Location = Vector2(0,0),
			Size = Vector2(60,50),
			BackgroundColor = ARGB(0, 255, 255, 255),
			TextAlign = "kAlignCenterMiddle",
			TextColor = ARGB(255, 215, 232, 227),
			FontSize = 15,					
		},
		
		Gui.Label "colunm6"
		{
			Size = Vector2(80,0),
			Location = Vector2(755,450),
			BackgroundColor = ARGB(255,255,255,255),
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_bar03.tga", Vector4(8, 8, 8, 8)),
			},
		},
		
		Gui.Label "LNurse"
		{
			Size = Vector2(50,50),
			Location = Vector2(763,460),
			BackgroundColor = ARGB(255, 255, 255, 255),
			TextAlign = "kAlignCenterMiddle",
			TextColor = ARGB(255,226,217,208),
			FontSize = 20,
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/GameBalance/summary_ico_nurse_win.dds", Vector4(0, 0, 0, 0)),
			},
		},
		
		Gui.Label "LNurse_name"
		{
			Size = Vector2(70,30),
			Location = Vector2(753,510),
			BackgroundColor = ARGB(0, 255, 255, 255),
			TextAlign = "kAlignCenterMiddle",
			TextColor = ARGB(255,253,211,77),
			FontSize = 15,
			Text = lang:GetText("医疗兵"),
		},
		
		Gui.Label "LNumLabe7"
		{
			Location = Vector2(0,0),
			Size = Vector2(60,50),
			BackgroundColor = ARGB(0, 255, 255, 255),
			TextAlign = "kAlignCenterMiddle",
			TextColor = ARGB(255, 215, 232, 227),
			FontSize = 15,					
		},
		
		Gui.Label "colunm7"
		{
			Size = Vector2(80,0),
			Location = Vector2(850,450),
			BackgroundColor = ARGB(255,255,255,255),
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_bar03.tga", Vector4(8, 8, 8, 8)),
			},
		},
		
		Gui.Label "LEngineer"
		{
			Size = Vector2(50,50),
			Location = Vector2(858,460),
			BackgroundColor = ARGB(255, 255, 255, 255),
			TextAlign = "kAlignCenterMiddle",
			TextColor = ARGB(255,226,217,208),
			FontSize = 20,
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/GameBalance/summary_ico_engineer_win.dds", Vector4(0, 0, 0, 0)),
			},
		},
		
		Gui.Label "LEngineer_name"
		{
			Size = Vector2(70,30),
			Location = Vector2(848,510),
			BackgroundColor = ARGB(0, 255, 255, 255),
			TextAlign = "kAlignCenterMiddle",
			TextColor = ARGB(255,253,211,77),
			FontSize = 15,
			Text = lang:GetText("工程兵"),
		},
	},
}

local main_select_window = 
{
	Gui.Control "ctrl_main_select_window"
	{
		Size = Vector2(888, 70),
		Location = Vector2(176, 35),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab01_bg.dds", Vector4(29, 32, 32, 19)),
		},
		Gui.FlowLayout 
		{
			Dock = "kDockFill",
			BackgroundColor = ARGB(0, 255, 255, 255),
			Margin = Vector4(20, 6, 0, 0),
			ControlSpace = 0,
			--基本信息
			Gui.Button "btn_Baseinfo"
			{
				Text = lang:GetText("基本信息"),
				Style = "Gui.tab_button",
			},
			
			--表现报告
			Gui.Button "btn_Report"
			{
				Text = lang:GetText("表现排名"),
				Style = "Gui.tab_button",
			},
			
			--精彩时刻
			Gui.Button "btn_HighlightPoint"
			{
				Text = lang:GetText("精彩时刻"),
				Style = "Gui.tab_button",
			},
		},	
		Gui.ComboBox "cbx_Mission"
		{
			Location = Vector2(665,6),
			LikeButton = true,
			Text = lang:GetText("一般成就"),
			Style = "Gui.ComboBoxLikeButton",
			ChildComboListStyle =  "Gui.teamComboList",
			TextAlign = "kAlignCenterMiddle",
		},		
	},	
}

--职业列表事件
local function characters_tab_event()
	if main_character_window_ui == nil then
		return
	end
	
	for i = 1, 10 do
		main_character_window_ui["tab_btn_"..i].EventClick = function()
			if L_LobbyMain.character_classes[i].is_open == 1 then
				L_LobbyMain.current_choose_class = i
				RestAllCharactersClassBtn()
				main_character_window_ui["tab_btn_"..i].PushDown = true
				if OtherPid < 0 then
					L_LobbyMain.FillClassBag(ptr_cast(game.CurrentState):GetCharacterId(), L_LobbyMain.current_choose_class)
				else
					L_LobbyMain.FillClassBag(OtherPid, L_LobbyMain.current_choose_class)
				end
			end
		end
	end
end

local function characters_achievement_tab_event()
	if main_character_achievement_window_ui == nil then
		return
	end
	
	for i = 1, 10 do
		main_character_achievement_window_ui["tab_btn_"..i].EventClick = function()
			if L_LobbyMain.character_classes[i].is_open == 1 then
				current_select_character = i
				FillCharacterAchievement()
				RestAllCharactersClassBtn()
				main_character_achievement_window_ui["tab_btn_"..i].PushDown = true
			end
		end
	end
end

--重置商城职业列表
function RestAllCharactersClassBtn()
	if main_character_window_ui then
		for i = 1, 10 do
			main_character_window_ui["tab_btn_"..i].PushDown = false
		end
	end
	
	if main_character_achievement_window_ui then
		for i = 1, 10 do
			main_character_achievement_window_ui["tab_btn_"..i].PushDown = false
		end
	end
end


--同步职业列表
function SynchronousClassButton()
	RestAllCharactersClassBtn()
	
	if main_character_window_ui then
		main_character_window_ui["tab_btn_"..L_LobbyMain.current_choose_class].PushDown = true
	end
	
	if main_character_achievement_window_ui then
		main_character_achievement_window_ui["tab_btn_"..current_select_character].PushDown = true
	end
end

local main_character_window =
{
	Gui.Control "ctrl_character_main"
	{
		Size = Vector2(1116, 586),
		Location = Vector2(19, 25),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/lb_shop_bg2.dds", Vector4(14, 14, 14, 14)),
		},	
		
		Gui.Control "boddy_info_BG"
		{
			Size = Vector2(1101, 551),
			Location = Vector2(9, 34),
			BackgroundColor = ARGB(255, 255, 255, 255),
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg.tga", Vector4(150, 22, 22, 22)),
			},
		},
		
		--职业列表
		L_Characters_tab.create_tab_characters_windows(Vector2(1,38)),

		--Close Button
		Gui.Button "btn_Close"
		{
			Size = Vector2(64, 52),
			Location = Vector2(1049, 3),
			PushDown = false,
			Hint = lang:GetText("关闭个人信息并返回至战区"),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button01_normal.dds", Vector4(0, 0, 0, 0)),
				HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button01_hover.dds", Vector4(0, 0, 0, 0)),
				DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button01_down.dds", Vector4(0, 0, 0, 0)),
				DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button01_normal.dds", Vector4(0, 0, 0, 0)),
			},
		},
		
		------角色显示
		Gui.Control "ctrl_Character_display_window"
		{
			Size = Vector2(292,480),
			Location = Vector2(154,80),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg3.dds", Vector4(22, 22, 22, 22)),
			},
			
			--人物显示
			Gui.CharacterViewer "character_viewer"
			{
				Size = Vector2(292, 474),
				Location = Vector2(4, 2),
				BackgroundColor = ARGB(255, 255, 255, 255),
				
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg3_guang.tga", Vector4(0, 0, 0, 0)),
				},
			},
	
			--旋转角色
			Gui.Button "btn_rotate_character"
			{
				Size = Vector2(68, 24),
				Location = Vector2(12,445),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button10_normal.dds", Vector4(0, 0, 0, 0)),
					HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button10_hover.dds", Vector4(0, 0, 0, 0)),
					DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button10_down.dds", Vector4(0, 0, 0, 0)),
					DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button10_normal.dds", Vector4(0, 0, 0, 0)),
				},
				EventClick = function()
					lg:RotateCharacter()
				end
			},
	
			--切换阵营
			Gui.Button "btn_change_team"
			{
				Size = Vector2(88, 24),
				Location = Vector2(82,445),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button11_normal.dds", Vector4(0, 0, 0, 0)),
					HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button11_hover.dds", Vector4(0, 0, 0, 0)),
					DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button11_down.dds", Vector4(0, 0, 0, 0)),
					DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button11_normal.dds", Vector4(0, 0, 0, 0)),
				},
				EventClick = function()
					L_LobbyMain.current_Avatar_Team = (L_LobbyMain.current_Avatar_Team + 1) % 2
					L_LobbyMain.ChangeAvatarPart()
				end
			},
			
			Gui.Button 
			{
				Size = Vector2(80, 24),
				Location = Vector2(170, 445),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/TopList/lb_rank_button02_normal.dds", Vector4(10, 10, 10, 10)),
					HoverImage = Gui.Image("LobbyUI/TopList/lb_rank_button02_hover.dds", Vector4(10, 10, 10, 10)),
					DownImage = Gui.Image("LobbyUI/TopList/lb_rank_button02_down.dds", Vector4(10, 10, 10, 10)),
					DisabledImage = nil,
				},
				EventClick = function()
					L_TopList.character_bag.root.Size = Vector2(588, 507)
					L_TopList.character_bag.root.Location = Vector2(441, 80)
					L_TopList.character_bag.root.Parent = main_character_window_ui.ctrl_character_main
					L_TopList.character_bag.rank_num_text.Visible = false
					L_TopList.character_bag.rank_num.Visible = false
					L_TopList.character_bag.root.Visible = not L_TopList.character_bag.root.Visible
				end
			},
			
			--战斗力值
			Gui.Control "fight_num_BG"
			{							
				Size = Vector2(280, 52),
				Location = Vector2(5, 1),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_power_bg_01.dds", Vector4(0, 0, 0, 0)),
				},
				Gui.FlowLayout "fightnum"
				{
					Location = Vector2(110,13),
					Size = Vector2(111,24),
					--Direction = "kHorizontal",
					Align = "kAlignCenterMiddle",
					ControlAlign = "kAlignCenterMiddle",
					ControlSpace = 0,
				},
				Gui.Button "des_button"
				{
					Size = Vector2(52, 32),
					Location = Vector2(221, 8),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_power_button_1_1_normal.dds", Vector4(0, 0, 0, 0)),
						HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_power_button_1_1_hover.dds", Vector4(0, 0, 0, 0)),
						DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_power_button_1_1_down.dds", Vector4(0, 0, 0, 0)),
						DisabledImage = nil,
					},
					EventClick = function(sender, e)
						if not L_LobbyMain.ui_des_bag.root.Parent then
							L_LobbyMain.ui_des_bag.root.Location = Vector2(400, 344)
							L_LobbyMain.ui_des_bag.root.Parent = L_LobbyMain.LobbyMainWin.LobbyMain_Root_Parent
						end
						sender.Visible = false
						main_character_window_ui.des_button_close.Visible = true
					end,
				},
				Gui.Button "des_button_close"
				{
					Size = Vector2(52, 32),
					Location = Vector2(221, 8),
					EventClick = function(sender, e)
						if L_LobbyMain.ui_des_bag.root.Parent then
							L_LobbyMain.ui_des_bag.root.Parent = nil
						end
						sender.Visible = false
						main_character_window_ui.des_button.Visible = true
					end,
				},
			},
		},
		
	
		Gui.Control "ctrl_personalInfo_window"
		{
			Size = Vector2(639,220),
			Location = Vector2(450,80),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg3.dds", Vector4(22, 22, 22, 22)),
			},
			
			Gui.Control "head"
			{
				Location = Vector2(10,4),
				Size = Vector2(100,135),
				BackgroundColor = ARGB(255, 255, 255, 255),
				
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_bg11.tga", Vector4(22, 22, 22, 22)),
				},
				
				----修改个人信息按钮-------------
				Gui.Button "bt_change_persionalInfo"
				{
					Size = Vector2(80,20),
					Location = Vector2(10,2),
					FontSize = 14,
					PushDown = flase,
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_edit_icon_normal.dds", Vector4(0, 0, 0, 0)),
						HoverImage = Gui.Image("LobbyUI/persionalInfo/lb_edit_icon_hover.dds", Vector4(0, 0, 0, 0)),
						DownImage = Gui.Image("LobbyUI/persionalInfo/lb_edit_icon_down.dds", Vector4(0, 0, 0, 0)),
						DisabledImage = Gui.Image("LobbyUI/persionalInfo/lb_edit_icon_normal.dds", Vector4(0, 0, 0, 0)),
					},
				},
				
				Gui.Label "head_label_back"
				{
					Size = Vector2(100,115),
					Location = Vector2(0,20),
					BackgroundColor = ARGB(255, 255, 255, 255),
					
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_acheive_bg.dds", Vector4(14, 14, 14, 14)),
					},
				},
				
				----玩家头像-------------
				Gui.Button "head_label"
				{
					Size = Vector2(84,98),
					Location = Vector2(8,28),
					BackgroundColor = ARGB(255, 255, 255, 255),
				},
			},

			Gui.Control
			{
				Size = Vector2(260, 20),
				Location = Vector2(144, 50),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Gui.FlowLayout "buff_layout"
				{
					Location = Vector2(0,0),
					Size = Vector2(600,20),
					Direction = "kHorizontal",
					Align = "kAlignLeftMiddle",
					ControlAlign = "kAlignCenterMiddle",
					ControlSpace = 4,
				},
			},
			
			Gui.Button
			{
				Size = Vector2(14, 20),
				Location = Vector2(127, 50),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Compose/lb_fastsettlement_button03_normal.dds", Vector4(0, 0, 0, 0)),
					HoverImage = Gui.Image("LobbyUI/Compose/lb_fastsettlement_button03_hover.dds", Vector4(0, 0, 0, 0)),
					DownImage = Gui.Image("LobbyUI/Compose/lb_fastsettlement_button03_down.dds", Vector4(0, 0, 0, 0)),
					DisabledImage = nil,
				},
				EventClick = function()
					if main_character_window_ui.buff_layout.Location.x ~= 0 then
						main_character_window_ui.buff_layout.Location = Vector2(main_character_window_ui.buff_layout.Location.x + 20, 0)
					end
				end
			},
			Gui.Button
			{
				Size = Vector2(14, 20),
				Location = Vector2(408, 50),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Compose/lb_fastsettlement_button02_normal.dds", Vector4(0, 0, 0, 0)),
					HoverImage = Gui.Image("LobbyUI/Compose/lb_fastsettlement_button02_hover.dds", Vector4(0, 0, 0, 0)),
					DownImage = Gui.Image("LobbyUI/Compose/lb_fastsettlement_button02_down.dds", Vector4(0, 0, 0, 0)),
					DisabledImage = nil,
				},
				EventClick = function()
					local count = 0
					if buff_count - 13 < 0 then
						count = 0
					else
						count = buff_count - 13
					end
					if main_character_window_ui.buff_layout.Location.x ~= count * (-20) then
						main_character_window_ui.buff_layout.Location = Vector2(main_character_window_ui.buff_layout.Location.x - 20, 0)
					end
				end
			},	
			
			Gui.Label	"name"
			{
				Size = Vector2(30,30),
				Location = Vector2(125,30),
				BackgroundColor = ARGB(0, 255, 255, 255),
				TextColor = ARGB(255, 215, 232, 227),
				FontSize = 14,
				Visible = false,
				Text = lang:GetText("称号："),
			},
		
			Gui.Label "lb_UserNickName"
			{
				Size = Vector2(285,20),
				Location = Vector2(125,30),
				BackgroundColor = ARGB(0, 255, 255, 255),
				TextColor = ARGB(255, 124, 211, 160),
				TextAlign = "kAlignLeftMiddle",
				FontSize = 14,
				Visible = false,
				Text = lang:GetText("总战斗力:"),
			},
			
			Gui.Label "player_title"
			{
				Size = Vector2(150,30),
				Location = Vector2(160,27),
				BackgroundColor = ARGB(0, 255, 255, 255),
				TextAlign = "kAlignLeftMiddle",
				TextColor = ARGB(255,253,211,77),
				FontSize = 14,
			},	
			
			Gui.Label "LVip"
			{
				Size = Vector2(40,28),
				Location = Vector2(125,10),
				BackgroundColor = ARGB(0,255,255,255),
			},	

			Gui.ItemBoxBtn
			{
				Style = "Gui.ItemBoxBtn_ib",
				Size = Vector2(40,28),
				Location = Vector2(125,10),
				BackgroundColor = ARGB(255, 255, 255, 255),
				
				Skin = Gui.ItemBoxBtnSkin
				{
					NeutralNormalImage = nil,
					NeutralHoverImage = nil,
					NeutralSelectedImage = nil,
					NeutralDisabledImage = nil,
				},
				EventMouseEnter = function(sender, e)
					if character_info_data ~= nil then
						local info = character_info_data.info
						if info and info.isVip == 1 then
							if OtherPid < 0 then
								L_ToolTips.FillToolUserLevelWindow(L_LobbyMain.PersonalInfo_data.leftMinites)
							else
								L_ToolTips.FillToolUserLevelWindow(info.leftMinites)
							end
						end
					end
				end,
				EventToolTipsShow = function(sender, e)
					if character_info_data and character_info_data.info and character_info_data.info.isVip == 1 then
						local pos = sender.Location + sender.Parent.Location + sender.Parent.Parent.Location + sender.Parent.Parent.Parent.Location + sender.Parent.Parent.Parent.Parent.Location
									+ sender.Parent.Parent.Parent.Parent.Parent.Location
						L_ToolTips.ShowToolTipsShowWindow(sender,Vector2(1116, 586),pos)
					end
				end,
				EventMouseLeave = function(sender, e)
					L_ToolTips.HideToolTipsWindow()
				end,
			},
			
			Gui.Label "lb_UserLevel"
			{
				Size = Vector2(40,30),
				Location = Vector2(125,4),
				BackgroundColor = ARGB(255,255,255,255),
				
				Skin = Gui.ControlSkin
				{
					BackgroundImage = nil,
				},
			},
			
			--十位
			Gui.Label "lb_UserLevel_Ten"
			{
				Size = Vector2(13,24),
				Location = Vector2(135,9),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_summary_number_6b.dds", Vector4(0, 0, 0, 0),Vector4(0, 0, 0.1, 1)),
				},
			},
			
			--十位百分比
			Gui.Label "lb_UserLevel_TenState"
			{
				Size = Vector2(13,0),
				Location = Vector2(135,33),
				BackgroundColor = ARGB(255, 255, 255, 255),			
			},
			
			--个位
			Gui.Label "lb_UserLevel_Anold"
			{
				Size = Vector2(13,24),
				Location = Vector2(145,9),
				BackgroundColor = ARGB(255,255,255,255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_summary_number_6b.dds", Vector4(0, 0, 0, 0),Vector4(0, 0, 0.1, 1)),
				},
			},
			
			--个位百分比
			Gui.Label "lb_UserLevel_AnoldState"
			{
				Size = Vector2(13,0),
				Location = Vector2(145,33),
				BackgroundColor = ARGB(255,255,255,255),
			},
			
			Gui.ItemBoxBtn
			{
				Style = "Gui.ItemBoxBtn_ib",
				Size = Vector2(44,44),
				Location = Vector2(123,0),
				BackgroundColor = ARGB(255, 255, 255, 255),
				
				Skin = Gui.ItemBoxBtnSkin
				{
					NeutralNormalImage = nil,
					NeutralHoverImage = nil,
					NeutralSelectedImage = nil,
					NeutralDisabledImage = nil,
				},
				
				EventMouseEnter = function(sender, e)
					if character_info_data and character_info_data.info then
						local info = character_info_data.info
						if info then
							L_ToolTips.FillToolUserLevelWindow(info.exp - Level_data[info.rank][2],Level_data[info.rank+1][2]-Level_data[info.rank][2])
						end
					end
				end,
				EventToolTipsShow = function(sender, e)
					if character_info_data then
						local pos = sender.Location + sender.Parent.Location + sender.Parent.Parent.Location + sender.Parent.Parent.Parent.Location + sender.Parent.Parent.Parent.Parent.Location
									+ sender.Parent.Parent.Parent.Parent.Parent.Location
						L_ToolTips.ShowToolTipsShowWindow(sender,Vector2(1116, 586),pos)
					end
				end,
				EventMouseLeave = function(sender, e)
					L_ToolTips.HideToolTipsWindow()
				end,
			},
			Gui.Control"player11111"
			{	
				Size = Vector2(83,29),
				Location = Vector2(280,15),
				BackgroundColor = ARGB(255, 255, 255, 255),
			},
			
			Gui.Label "player_nickname"
			{
				Size = Vector2(250,20),
				Location = Vector2(176,8),
				BackgroundColor = ARGB(0, 255, 255, 255),
				TextAlign = "kAlignLeftMiddle",
				TextColor = ARGB(255, 215, 232, 227),
				FontSize = 18,
			},
			
			Gui.Label "AcheBackground"
			{
				Location = Vector2(120,68),
				Size = Vector2(305,72),
				BackgroundColor = ARGB(255/2, 255, 255, 255),
				
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_bg11.tga", Vector4(22, 22, 22, 22)),
				},
			},
			
			Gui.Label	"AcheListbk1"
			{
				Size = Vector2(77,77),
				Location = Vector2(129,66),
				BackgroundColor = ARGB(255, 255, 255, 255),
				
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_acheive_bg.dds", Vector4(0, 0, 0, 0)),
				},
							
			},
			
			Gui.Label	"AcheList1"
			{
				Size = Vector2(60,60),
				Location = Vector2(138,74),
				BackgroundColor = ARGB(0, 255, 255, 255),				
			},
			
			Gui.Label	"AcheListbk2"
			{
				Size = Vector2(77,77),
				Location = Vector2(199,66),
				BackgroundColor = ARGB(255, 255, 255, 255),
				
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_acheive_bg.dds", Vector4(0, 0, 0, 0)),
				},
			},
			
			Gui.Label	"AcheList2"
			{
				Size = Vector2(60,60),
				Location = Vector2(208,74),
				BackgroundColor = ARGB(0, 255, 255, 255),
			},
			
			Gui.Label	"AcheListbk3"
			{
				Size = Vector2(77,77),
				Location = Vector2(269,66),
				BackgroundColor = ARGB(255, 255, 255, 255),
				
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_acheive_bg.dds", Vector4(0, 0, 0, 0)),
				},
			},
			
			Gui.Label	"AcheList3"
			{
				Size = Vector2(60,60),
				Location = Vector2(278,74),
				BackgroundColor = ARGB(0, 255, 255, 255),
			},
		
			Gui.Label	"AcheListbk4"
			{
				Size = Vector2(77,77),
				Location = Vector2(339,66),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Visible = true,
				
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_acheive_bg.dds", Vector4(0, 0, 0, 0)),
				},
			},
			
			Gui.Label	"AcheList4"
			{
				Size = Vector2(60,60),
				Location = Vector2(348,74),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Visible = true,
			},
			
			Gui.AnimControl "AnimNum"
			{
				Size = Vector2(77,77),
				Location = Vector2(336,66),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Visible =  false,
			},
			
			Gui.Control "progress"
			{
				Location = Vector2(10,145),
				Size = Vector2(415,67),
				BackgroundColor = ARGB(255, 255, 255, 255),
				
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_bg11.tga", Vector4(22, 22, 22, 22)),
				},
				
				Gui.Label "progress_name"
				{
					Size = Vector2(105,40),
					Location = Vector2(5,5),
					BackgroundColor = ARGB(0, 255, 255, 255),
					TextAlign = "kAlignCenterMiddle",
					TextColor = ARGB(255, 215, 232, 227),
					FontSize = 13,
					Text = lang:GetText("成就达成总进程"),
				},
				
				Gui.Label "icon_gold"
				{
					Size = Vector2(22,21),
					Location = Vector2(120,15),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_icon_gold.dds", Vector4(0, 0, 0, 0)),
					},
				},
				
				Gui.Label "gold_num"
				{
					Size = Vector2(40,21),
					Location = Vector2(144,12),
					BackgroundColor = ARGB(0, 255, 255, 255),
					TextAlign = "kAlignCenterMiddle",
					TextColor = ARGB(255,253,211,77),
					FontSize = 18,
				},
				
				Gui.Label "icon_silver"
				{
					Size = Vector2(22,21),
					Location = Vector2(200,15),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_icon_silver.dds", Vector4(0, 0, 0, 0)),
					},
				},
				
				Gui.Label "silver_num"
				{
					Size = Vector2(40,21),
					Location = Vector2(222,12),
					BackgroundColor = ARGB(0, 255, 255, 255),
					TextAlign = "kAlignCenterMiddle",
					TextColor = ARGB(255,253,211,77),
					FontSize = 18,
				},
				
				Gui.Label "icon_bronze"
				{
					Size = Vector2(22,21),
					Location = Vector2(280,15),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_icon_bronze.dds", Vector4(0, 0, 0, 0)),
					},
				},
				
				Gui.Label "bronze_num"
				{
					Size = Vector2(40,21),
					Location = Vector2(302,12),
					BackgroundColor = ARGB(0, 255, 255, 255),
					TextAlign = "kAlignCenterMiddle",
					TextColor = ARGB(255,253,211,77),
					FontSize = 18,
				},
				
				Gui.Label "progressbar_bg"
				{
					Location = Vector2(10,40),
					Size = Vector2(303,15);
					BackgroundColor = ARGB(255,255, 255, 255),
					
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_common_expbar01_bg.dds", Vector4(14, 14, 14, 14)),
					},
				},
				
				Gui.Label "progressbar"
				{
					Location = Vector2(10,40),
					Size = Vector2(0,12);
					BackgroundColor = ARGB(255,255, 255, 255),
					
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_bar02_content.dds", Vector4(5, 0, 5, 0)),
					},
				},
				
				Gui.Label "progress_label"
				{
					Size = Vector2(100,30),
					Location = Vector2(320,30),
					BackgroundColor = ARGB(0, 255, 255, 255),
					TextAlign = "kAlignCenterMiddle",
					TextColor = ARGB(255,253,211,77),
					FontSize = 18,
				},
			},
			
			Gui.Control "Paiming"
			{
				Location = Vector2(430,145),
				Size = Vector2(196,32),
				BackgroundColor = ARGB(255, 255, 255, 255),
				
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_bg09.tga", Vector4(23,15,8,15)),
				},
				
				Gui.Label "LPaiming"
				{
					Location = Vector2(25,3),
					Size = Vector2(85,28),
					BackgroundColor = ARGB(0, 255, 255, 255),
					TextColor = ARGB(255, 215, 232, 227),
					TextAlign = "kAlignLeftMiddle",
					Text = lang:GetText("排名"),
					FontSize = 14,
				},
				
				Gui.Label "PaimingConent"
				{
					Location = Vector2(120,3),
					Size = Vector2(70,28),
					TextColor = ARGB(255,253,211,77),
					BackgroundColor = ARGB(0, 255, 255, 255),
					TextAlign = "kAlignRightMiddle",
					FontSize = 18,
				},
			},
			
			
			Gui.Control "SuccessNum"
			{
				Location = Vector2(430,180),
				Size = Vector2(196,32),
				BackgroundColor = ARGB(255, 255, 255, 255),
				
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_bg10.tga", Vector4(23,15,8,15)),
				},
				
				Gui.Label "LSuccessNum"
				{
					Location = Vector2(25,3),
					Size = Vector2(85,28),
					BackgroundColor = ARGB(0, 255, 255, 255),
					TextColor = ARGB(255, 215, 232, 227),
					TextAlign = "kAlignLeftMiddle",
					Text = lang:GetText("胜/败"),
					FontSize = 14,
				},
				
				Gui.Label "SuccessNumContent"
				{
					Location = Vector2(90,3),
					Size = Vector2(100,28),
					TextColor = ARGB(255,253,211,77),
					BackgroundColor = ARGB(0, 255, 255, 255),
					TextAlign = "kAlignRightMiddle",
					FontSize = 18,
				},
			},
			
			
			
			-- Gui.Control "keep_pic_back"
			-- {
				-- Size = Vector2(131,50),
				-- Location = Vector2(495,11),
				-- BackgroundColor = ARGB(255, 255, 255, 255),

				-- Skin = Gui.ControlSkin
				-- {
					-- BackgroundImage = Gui.Image("LobbyUI/lb_common_button_bg01.dds", Vector4(20, 20, 20, 20)),
				-- },
			-- },
			
			--个人信息
			Gui.Button "keep_shot"
			{
				Size = Vector2(198,36),
				Location = Vector2(430,30),
				Text = lang:GetText("保存截图").." ",
				TextColor = ARGB(255, 0, 0, 0),
				FontSize = 14,
				PushDown = flase,
				Enable = false,
				TextAlign = "kAlignRightMiddle",
				-- Style = "Gui.TakeShotButton",
			},
			
			Gui.Label "success_ratio"
			{
				Size = Vector2(96,72),
				Location = Vector2(430,68),
				BackgroundColor = ARGB(255, 255, 255, 255),
				--TextAlign = "kAlignCenterBottom",
				TextColor = ARGB(255,253,211,77),
				FontSize = 20,
				
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_image_ratio.tga", Vector4(14, 14, 14, 14)),
				},
				
				-- Gui.Label
				-- {
					-- Size = Vector2(96,30),
					-- Location = Vector2(0,0),
					-- BackgroundColor = ARGB(0, 255, 255, 255),
					-- TextColor = ARGB(255,253,211,77),
					-- TextAlign = "kAlignCenterMiddle",
					-- Text = lang:GetText("胜率"),
					-- FontSize = 13,
				-- },
				
				Gui.Label "success_ratio_num"
				{
					Size = Vector2(80,25),
					Location = Vector2(8,40),
					BackgroundColor = ARGB(0, 255, 255, 255),
					TextColor = ARGB(255,253,211,77),
					TextAlign = "kAlignCenterBottom",
					FontSize = 20,
				},
			},
			
			Gui.Label "rank"
			{
				Size = Vector2(96,72),
				Location = Vector2(530,68),
				BackgroundColor = ARGB(255, 255, 255, 255),
				FontSize = 20,
				
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_image_rank.tga", Vector4(14, 14, 14, 14)),
				},
				
				-- Gui.Label
				-- {
					-- Size = Vector2(96,30),
					-- Location = Vector2(0,0),
					-- BackgroundColor = ARGB(0, 255, 255, 255),
					-- TextColor = ARGB(255,231,73,36),
					-- TextAlign = "kAlignCenterMiddle",
					-- Text = lang:GetText("逃跑率"),
					-- FontSize = 13,
				-- },
				
				Gui.Label "rank_num"
				{
					Size = Vector2(80,25),
					Location = Vector2(8,40),
					BackgroundColor = ARGB(0, 255, 255, 255),
					TextColor = ARGB(255,253,211,77),
					TextAlign = "kAlignCenterBottom",
					FontSize = 20,
				},
			},
		},
		
		Gui.Control "ctrl_personal_recent_info_window"
		{
			Size = Vector2(645,260),
			Location = Vector2(450,305),
			BackgroundColor = ARGB(255/2, 0, 0, 0),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_daoju_bg.dds", Vector4(22, 22, 22, 22)),
			},
		},
		
		Gui.ListTreeView "list_recent_info"
		{
			Location = Vector2(450,282),
			Size = Vector2(640,275),
			Style = "Gui.ListTreeViewWith_VScroll",
			ItemHeight = 33,
			VScrollBarWidth = 40,
			VScrollBarButtonSize = 36,
			VScrollBarPos = Vector2(0,30),
			VScrollBarHeight = 240,
		},
		--VIP
		Gui.Control "ctr_VIP"
		{
			Location = Vector2(440, 165),
			Size = Vector2(142, 77),
			BackgroundColor = ARGB(255,255,255,255),
			Visible = false,
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_bg_06.dds", Vector4(0, 0, 0, 0)),
			},
		},
		Gui.Button "ctr_VIP_num"
		{
			Location = Vector2(440+44, 165+30),
			Size = Vector2(50, 29),
			BackgroundColor = ARGB(255,255,255,255),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_button_06_normal.dds", Vector4(0, 0, 0, 0)),
				HoverImage = Gui.Image("LobbyUI/vip/vip/VIP_button_06_hover.dds", Vector4(0, 0, 0, 0)),
				DownImage = Gui.Image("LobbyUI/vip/vip/VIP_button_06_down.dds", Vector4(0, 0, 0, 0)),
				DisabledImage = Gui.Image("LobbyUI/vip/vip/VIP_button_06_normal.dds", Vector4(0, 0, 0, 0)),
			},
			EventClick = function()
				L_Vip.Show_VipShow()
			end,
			
			EventMouseEnter = function()
				main_character_window_ui.ctr_VIP.Visible = true
			end,
			
			EventMouseLeave = function()
				main_character_window_ui.ctr_VIP.Visible = false
			end
		},
	},
}

function Split(szFullString, szSeparator)
	local nFindStartIndex = 1
	local nSplitIndex = 1
	local nSplitArray = {}
	while true do
	   local nFindLastIndex = string.find(szFullString, szSeparator, nFindStartIndex)
	   if not nFindLastIndex then
	    nSplitArray[nSplitIndex] = string.sub(szFullString, nFindStartIndex, string.len(szFullString))
	    break
	   end
	   nSplitArray[nSplitIndex] = string.sub(szFullString, nFindStartIndex, nFindLastIndex - 1)
	   nFindStartIndex = nFindLastIndex + string.len(szSeparator)
	   nSplitIndex = nSplitIndex + 1
	end
	return nSplitArray
end

function Fill_HightLight()
	local index = main_highlight_window_ui.game_time.SelectedIndex
	local Text =  main_highlight_window_ui.game_time:GetItem(index)
	local limit = highLight_limit[Text]
	local unit = limit[5]
	main_highlight_window_ui.Lfireman_none.Visible = false
	
	local maxHeadshotMax,maxKillMax,maxHealthMax,maxDamageMax,
		maxAliveTimeMax,mvpNumMax= 0,0,0,0,0,0
		
	local useMax,useMax2,useNum,ratio
	
	if ReportData then
		for i,v in ipairs(ReportData) do		
			if maxHeadshotMax < v.maxHeadshot then
				maxHeadshotMax = v.maxHeadshot
			end
			
			if maxKillMax < v.maxKill then
				maxKillMax = v.maxKill
			end
			
			if maxHealthMax < v.maxHealth then
				maxHealthMax = v.maxHealth
			end
			
			if maxDamageMax < v.maxDamage then
				maxDamageMax = v.maxDamage
			end
			
			if maxAliveTimeMax < v.maxAliveTime then
				maxAliveTimeMax = v.maxAliveTime
			end
			
			if mvpNumMax < v.mvpNum then
				mvpNumMax = v.mvpNum
			end
		end
		
		
		if index == 0 then
			useMax = maxHeadshotMax
			--main_highlight_window_ui.Lfireman_none.Visible =  true
		elseif index == 1 then
			useMax = maxKillMax
		elseif index == 2 then
			useMax = maxHealthMax
		elseif index == 3 then
			useMax = maxDamageMax
		elseif index == 4 then
			useMax = maxAliveTimeMax
		elseif index == 5 then
			useMax = mvpNumMax
		end
		
		if useMax > limit[2] then
			useMax = limit[4]
			useMax2 = limit[3]
		else
			useMax = limit[2]
			useMax2 = limit[1]
		end
		
		main_highlight_window_ui.limit1.Text = useMax2.."\n"..unit
		main_highlight_window_ui.limit2.Text = useMax.."\n"..unit
		
		for i,v in ipairs(ReportData) do
			local LocationY,SizeY,MyLocation = 450,0,0
			local NumLabel
			
			if index == 0 then
				useNum = v.maxHeadshot
			elseif index == 1 then
				useNum = v.maxKill
			elseif index == 2 then
				useNum = v.maxHealth
			elseif index == 3 then
				useNum = v.maxDamage
			elseif index == 4 then
				useNum = v.maxAliveTime
			elseif index == 5 then
				useNum = v.mvpNum
			end
			
			SizeY = ((useNum)/(useMax - useMax2))*130
			
			if SizeY > 260 then
				SizeY = 270
			end
			
			LocationY = LocationY - SizeY
			
			if i == 1 then
				main_highlight_window_ui.colunm1.Location =  Vector2(280,LocationY)
				main_highlight_window_ui.colunm1.Size = Vector2(70,SizeY)
				MyLocation = main_highlight_window_ui.colunm1.Location
				main_highlight_window_ui.LNumLabel.Location = Vector2(MyLocation.x+7,MyLocation.y-40)
				main_highlight_window_ui.LNumLabel.Text = useNum
			elseif i == 2 then
				main_highlight_window_ui.colunm2.Location = Vector2(375,LocationY)
				main_highlight_window_ui.colunm2.Size = Vector2(70,SizeY)
				MyLocation = main_highlight_window_ui.colunm2.Location
				main_highlight_window_ui.LNumLabe2.Location = Vector2(MyLocation.x+7,MyLocation.y-40)
				main_highlight_window_ui.LNumLabe2.Text = useNum
			elseif i == 3 then
				main_highlight_window_ui.colunm3.Location = Vector2(470,LocationY)
				main_highlight_window_ui.colunm3.Size = Vector2(70,SizeY)
				MyLocation = main_highlight_window_ui.colunm3.Location
				main_highlight_window_ui.LNumLabe3.Location = Vector2(MyLocation.x+7,MyLocation.y-40)
				main_highlight_window_ui.LNumLabe3.Text = useNum
			elseif i == 4 then
				main_highlight_window_ui.colunm4.Location = Vector2(565,LocationY)
				main_highlight_window_ui.colunm4.Size = Vector2(70,SizeY)
				MyLocation = main_highlight_window_ui.colunm4.Location
				main_highlight_window_ui.LNumLabe4.Location = Vector2(MyLocation.x+7,MyLocation.y-40)
				main_highlight_window_ui.LNumLabe4.Text = useNum
			elseif i == 5 then
				main_highlight_window_ui.colunm5.Location = Vector2(660,LocationY)
				main_highlight_window_ui.colunm5.Size = Vector2(70,SizeY)
				MyLocation = main_highlight_window_ui.colunm5.Location
				main_highlight_window_ui.LNumLabe5.Location = Vector2(MyLocation.x+7,MyLocation.y-40)
				main_highlight_window_ui.LNumLabe5.Text = useNum
			elseif i == 6 then
				main_highlight_window_ui.colunm6.Location = Vector2(755,LocationY)
				main_highlight_window_ui.colunm6.Size = Vector2(70,SizeY)
				MyLocation = main_highlight_window_ui.colunm6.Location
				main_highlight_window_ui.LNumLabe6.Location = Vector2(MyLocation.x+7,MyLocation.y-40)
				main_highlight_window_ui.LNumLabe6.Text = useNum
			elseif i == 7 then
				main_highlight_window_ui.colunm7.Location = Vector2(850,LocationY)
				main_highlight_window_ui.colunm7.Size = Vector2(70,SizeY)
				MyLocation = main_highlight_window_ui.colunm7.Location
				main_highlight_window_ui.LNumLabe7.Location = Vector2(MyLocation.x+7,MyLocation.y-40)
				main_highlight_window_ui.LNumLabe7.Text = useNum
			end
		end
		
	end
end

function CreateInfoControl(data)
	local ratio,length
	local description = data[3]
	local title = data[2]
	local status = data[5]
	local currentNum = data[6]
	local AllNum = data[7]
	local acheID = data[1]
	
	local infoCon = Gui.Create(gui) 
	{
		Gui.Control "cinfo1"
		{
			Size = Vector2(1000,85),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_acheive_bg02_normal.tga", Vector4(0, 0, 0, 0)),
			},

			Gui.Label "LHeadback"
			{
				Location = Vector2(3,3),
				Size = Vector2(80,80),
				BackgroundColor = ARGB(255,255,255,255),
				
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_acheive_bg.dds", Vector4(0, 0, 0, 0)),
				},				
			},
			
			Gui.Label "LHead1"
			{
				Location = Vector2(13,13),
				Size = Vector2(60,60),
				BackgroundColor = ARGB(255,255,255,255),					
			},
			
			Gui.Label "Linfo1"
			{
				Location = Vector2(80,10),
				Size = Vector2(675,40),
				BackgroundColor = ARGB(0, 255, 255, 255),
				TextAlign = "kAlignLeftMiddle",
				TextColor = ARGB(255,226,217,208),
				FontSize = 20,
			},
			
			Gui.Label "Progress_bg1"
			{
				Location = Vector2(80,50),
				Size = Vector2(800,20),
				BackgroundColor = ARGB(255, 255, 255, 255),
				
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_common_expbar01_bg.dds", Vector4(14, 14, 14, 14)),
				},
			},
			
			Gui.Label "Progress_bar1"
			{
				Location = Vector2(80,50),
				Size = Vector2(0,20),
				BackgroundColor = ARGB(255, 255, 255, 255),
				
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_bar01_content.dds", Vector4(5, 0, 5, 0)),
				},
			},
			
			Gui.Label "tips1"
			{
				Location = Vector2(760,10),
				Size = Vector2(230,40),
				BackgroundColor = ARGB(255, 255, 255, 255),
				TextAlign = "kAlignCenterTop",
				TextColor = ARGB(255,253,211,77),
				FontSize = 18,
				
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_nicknameBG01.dds", Vector4(14, 14, 14, 14)),
				},
			},
			
			Gui.Label "ratio1"
			{
				Location = Vector2(885,45),
				Size = Vector2(90,40),
				BackgroundColor = ARGB(0, 255, 255, 255),
				TextColor = ARGB(255, 220, 245, 252),
				FontSize = 20,
			},
		}
	}
	
	infoCon.Linfo1.Text = description
	infoCon.tips1.Text = title
	ratio = currentNum
	ratio = ratio/AllNum *100
	ratio = math.floor(ratio)
	infoCon.ratio1.Text = ratio.."%"
	
	if acheID < 10 then
		acheID = "0"..acheID
	end
	 
	if AllNum ~= 0 then
		ratio = currentNum/AllNum
	else
		ratio = 0
	end
	
	infoCon.LHead1.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/persionalInfo/achieves/acheive"..acheID..".dds", Vector4(0, 0, 0, 0)),}
	if ratio >= 1 then
		ratio = 1
		infoCon.ratio1.Text = ""
		infoCon.ratio1.BackgroundColor = ARGB(255, 255, 255, 255)
		infoCon.ratio1.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_icon_accomplished.dds", Vector4(0,0,0,0)),}
		infoCon.ratio1.Size = Vector2(40,40)
		
	end
	
	length = ratio * 800
	infoCon.Progress_bar1.Size = Vector2(length,20)

	return infoCon
end

--个人信息成就栏
function CreateCharacterInfoControl(data)
	local ratio,length
	local description = data[3]
	local title = data[2]
	local status = data[5]
	local currentNum = data[6]
	local AllNum = data[7]
	local acheID = data[1]
	
	local infoCon = Gui.Create(gui) {
		Gui.Control "cinfo1"
		{
			Size = Vector2(870,85),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_acheive_bg02_normal.tga", Vector4(0, 0, 0, 0)),
			},

			Gui.Label "LHeadback"
			{
				Location = Vector2(3,3),
				Size = Vector2(80,80),
				BackgroundColor = ARGB(255,255,255,255),
				
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_acheive_bg.dds", Vector4(0, 0, 0, 0)),
				},				
			},
			
			--加载成就图标
			Gui.Label "LHead1"
			{
				Location = Vector2(13,13),
				Size = Vector2(60,60),
				BackgroundColor = ARGB(255,255,255,255),					
			},
			
			Gui.Label "Linfo1"
			{
				Location = Vector2(80,10),
				Size = Vector2(545,40),
				BackgroundColor = ARGB(0, 255, 255, 255),
				TextAlign = "kAlignLeftMiddle",
				TextColor = ARGB(255,226,217,208),
				FontSize = 20,
			},
			
			Gui.Label "Progress_bg1"
			{
				Location = Vector2(80,50),
				Size = Vector2(670,20),
				BackgroundColor = ARGB(255, 255, 255, 255),
				
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_common_expbar01_bg.dds", Vector4(14, 14, 14, 14)),
				},
			},
			
			Gui.Label "Progress_bar1"
			{
				Location = Vector2(80,50),
				Size = Vector2(0,20),
				BackgroundColor = ARGB(255, 255, 255, 255),
				
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_bar01_content.dds", Vector4(5, 0, 5, 0)),
				},
			},
			
			Gui.Label "tips1"
			{
				Location = Vector2(630,10),
				Size = Vector2(230,40),
				BackgroundColor = ARGB(255, 255, 255, 255),
				TextAlign = "kAlignCenterTop",
				TextColor = ARGB(255,253,211,77),
				FontSize = 18,
				
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_nicknameBG01.dds", Vector4(14, 14, 14, 14)),
				},
			},
			
			Gui.Label "ratio1"
			{
				Location = Vector2(765,45),
				Size = Vector2(90,40),
				BackgroundColor = ARGB(0, 255, 255, 255),
				TextColor = ARGB(255, 220, 245, 252),
				FontSize = 20,
			},
		}
	}
	
	infoCon.Linfo1.Text = description
	infoCon.tips1.Text = title
	ratio = currentNum
	ratio = ratio/AllNum *100
	ratio = math.floor(ratio)
	infoCon.ratio1.Text = ratio.."%"
	
	if acheID < 10 then
		acheID = "0"..acheID
	end
	 
	if AllNum ~= 0 then
		ratio = currentNum/AllNum
	else
		ratio = 0
	end
	
	infoCon.LHead1.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/persionalInfo/achieves/acheive"..acheID..".dds", Vector4(0, 0, 0, 0)),}
	if ratio >= 1 then
		ratio = 1
		infoCon.ratio1.Text = ""
		infoCon.ratio1.BackgroundColor = ARGB(255, 255, 255, 255)
		infoCon.ratio1.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_icon_accomplished.dds", Vector4(0,0,0,0)),}
		infoCon.ratio1.Size = Vector2(40,40)
	end
	
	length = ratio * 670
	infoCon.Progress_bar1.Size = Vector2(length,20)

	return infoCon
end

------------------------------------------------------------------------------------------------
--填充个人信息成就栏
function Fill_Character_achievement(data)
	local general_list
	local achievement
	local totalPages
	local AllNum,currentAll,ratio,totallength
	local pidstr = nil	
	pidstr = Getpidstr()
				
	if data then
		if data.warning then
			MessageBox.ShowWithTimer(1,data.warning)
			ptr_cast(game.CurrentState):Quit()
			return
		end
	end
	
	if data then
		if data.warning then
			MessageBox.ShowWithTimer(1,data.warning)
			ptr_cast(game.CurrentState):Quit()
			return
		end
	end
	
	achievement = data.achievement
	general_list = achievement.list
	
	main_character_achievement_window_ui.scrollLayout:OnDestroy()
	
	--填充一般成就列表
	for i,v in ipairs(general_list) do	
		if v then
			local Mycon = CreateCharacterInfoControl(v)
			Mycon.cinfo1.Parent = main_character_achievement_window_ui.scrollLayout
		end
	end
	
	characterinfo_pages_info[pidstr][current_select_character][2] = achievement.pages
		
	if characterinfo_pages_info[pidstr][current_select_character][1] > characterinfo_pages_info[pidstr][current_select_character][2] then
		characterinfo_pages_info[pidstr][current_select_character][1] = characterinfo_pages_info[pidstr][current_select_character][2]
	elseif characterinfo_pages_info[pidstr][current_select_character][1] < 1 then
		characterinfo_pages_info[pidstr][current_select_character][1] = 1
	end
	
	main_character_achievement_window_ui.m_AcheInfoPageDisplay.Text = characterinfo_pages_info[pidstr][current_select_character][1].."/"..characterinfo_pages_info[pidstr][current_select_character][2]
	
	AllNum = achievement.size
	currentAll = achievement.complete
		
	if AllNum ~= 0 then
		ratio = currentAll / AllNum
	else
		ratio = 0
	end
	
	totallength = 490 * ratio
	main_character_achievement_window_ui.Processbar.Size = Vector2(totallength,15)
	main_character_achievement_window_ui.Process_num.Text = currentAll.."/"..AllNum
	
	barlocation = main_character_achievement_window_ui.Processbar.Location.x + totallength
	flaglocation = main_character_achievement_window_ui.flag1.Location.x
	
	main_character_achievement_window_ui.flag1.Skin = Gui.ControlSkin{ BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_icon01_inactive.dds", Vector4(14, 14, 14, 14)),}
	main_character_achievement_window_ui.flag2.Skin = Gui.ControlSkin{ BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_icon01_inactive.dds", Vector4(14, 14, 14, 14)),}
	main_character_achievement_window_ui.flag3.Skin = Gui.ControlSkin{ BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_icon01_inactive.dds", Vector4(14, 14, 14, 14)),}
	
	if barlocation > flaglocation then
		main_character_achievement_window_ui.flag1.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_icon01_active.dds", Vector4(14, 14, 14, 14)),}
		if barlocation > flaglocation + 200 then
			main_character_achievement_window_ui.flag2.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_icon01_active.dds", Vector4(14, 14, 14, 14)),}
		end
		if barlocation > flaglocation + 400 then
			main_character_achievement_window_ui.flag3.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_icon01_active.dds", Vector4(14, 14, 14, 14)),}
		end
	end
end
 
function Fill_General_achievement(data)
	local general_list
	local achievement
	local totalratio,currentAll,totalNum
	
	local pidstr = nil	
	pidstr = Getpidstr()
				
	if data then
		if data.warning then
			MessageBox.ShowWithTimer(1,data.warning)
			ptr_cast(game.CurrentState):Quit()
			return
		end
	end
	
	achievement = data.achievement
	general_list = achievement.list
	
	main_general_achievement_window_ui.scrollLayout:OnDestroy()
	
	for i,v in ipairs(general_list) do	
		if v then
			local Mycon = CreateInfoControl(v)
			Mycon.cinfo1.Parent = main_general_achievement_window_ui.scrollLayout
		end
	end
	
	character_pages_info[pidstr][2] = achievement.pages
	
	if character_pages_info[pidstr][1] > character_pages_info[pidstr][2] then
		character_pages_info[pidstr][1] = character_pages_info[pidstr][2]
	elseif character_pages_info[pidstr][1] < 1 then
		character_pages_info[pidstr][1] = 1
	end
	
	main_general_achievement_window_ui.m_AcheInfoPageDisplay.Text = character_pages_info[pidstr][1].."/"..character_pages_info[pidstr][2]
	currentAll =  achievement.complete
	totalNum = achievement.size
	
	totalratio = currentAll/totalNum
	totallength = totalratio * 600
	main_general_achievement_window_ui.Processbar.Size = Vector2(totallength,18)
	
	totalratio = currentAll .."/"..totalNum
	
	main_general_achievement_window_ui.Process_num.Text = totalratio
	
	barlocation = main_general_achievement_window_ui.Processbar.Location.x + totallength
	flaglocation = main_general_achievement_window_ui.flag1.Location.x
	main_general_achievement_window_ui.flag1.Skin = Gui.ControlSkin{ BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_icon01_inactive.dds", Vector4(14, 14, 14, 14)),}
	main_general_achievement_window_ui.flag2.Skin = Gui.ControlSkin{ BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_icon01_inactive.dds", Vector4(14, 14, 14, 14)),}
	main_general_achievement_window_ui.flag3.Skin = Gui.ControlSkin{ BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_icon01_inactive.dds", Vector4(14, 14, 14, 14)),}
	
	if barlocation > flaglocation then
		main_general_achievement_window_ui.flag1.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_icon01_active.dds", Vector4(14, 14, 14, 14)),}
		
		if barlocation > flaglocation + 200 then
			main_general_achievement_window_ui.flag2.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_icon01_active.dds", Vector4(14, 14, 14, 14)),}
		end
		
		if barlocation > flaglocation + 400 then
			main_general_achievement_window_ui.flag3.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_icon01_active.dds", Vector4(14, 14, 14, 14)),}
		end
	end
end

function Getpidstr()
	local pid
	
	if OtherPid < 0 then
		pid = state:GetCharacterId()
	else
		pid = OtherPid
	end
	
	pid = pid .. "str"
	
	return pid
end

function FillCharacterAchievement()
	local pid = -1
	local pidstr = nil
	
	pidstr = Getpidstr()
				
	if OtherPid < 0 then
		args = {pid = state:GetCharacterId(),type = 3,characterid = current_select_character,page = characterinfo_pages_info[pidstr][current_select_character][1]}			
		rpc.safecall("player_achievement",args,Fill_Character_achievement)
	else
		args = {pid = OtherPid,type = 3,characterid = current_select_character,page = characterinfo_pages_info[pidstr][current_select_character][1]}	
		rpc.safecall("player_achievement",args,Fill_Character_achievement)
	end
end
------------------------------------------------------------------------------------------------

function Get_characterReport(data)
	if data then
		if data.warning then
			MessageBox.ShowWithTimer(1,data.warning)
			ptr_cast(game.CurrentState):Quit()
			return
		end
		ReportData = data.myData
	end
	
	Fill_HightLight()
end

function Fill_characterReport(data)
	if data then
		if data.warning then
			MessageBox.ShowWithTimer(1,data.warning)
			ptr_cast(game.CurrentState):Quit()
			return
		end
		ReportData = data.myData
	end

	local index = main_report_window_ui.game_time.SelectedIndex
	local Text =  main_report_window_ui.game_time:GetItem(index)
	local limit = report_limit[Text]
	local usedCountMax,killMax,deadMax,controlNumMax,
		revengeNumMax,assistNumMax,knifeKillMax = 0,0,0,0,0,0,0
	local useMax,useMax2,useNum,ratio
	local unit = limit[5]
	main_report_window_ui.Lfireman_none.Visible = false
	
	if ReportData then
		for i,v in ipairs(ReportData) do		
			if usedCountMax < v.usedCount then
				usedCountMax = v.usedCount
			end
			
			if killMax < v.kill then
				killMax = v.kill
			end
			
			if deadMax < v.dead then
				deadMax = v.dead
			end
			
			if controlNumMax < v.controlNum then
				controlNumMax = v.controlNum
			end
			
			if revengeNumMax < v.revengeNum then
				revengeNumMax = v.revengeNum
			end
			
			if assistNumMax < v.assistNum then
				assistNumMax = v.assistNum
			end
			
			if knifeKillMax < v.knifeKill then
				knifeKillMax = v.knifeKill
			end
		end
		
		if index == 0 then
			useMax = usedCountMax
		elseif index == 1 then
			useMax = killMax
		elseif index == 2 then
			useMax = deadMax
		elseif index == 3 then
			useMax = controlNumMax
		elseif index == 4 then
			useMax = revengeNumMax
		elseif index == 5 then
			useMax = assistNumMax
		elseif index == 6 then
			useMax = knifeKillMax
		end
		
		if useMax > limit[2] then
			useMax = limit[4]
			useMax2 = limit[3]
		else
			useMax = limit[2]
			useMax2 = limit[1]
		end
		
		main_report_window_ui.limit1.Text = useMax2.."\n"..unit
		main_report_window_ui.limit2.Text = useMax.."\n"..unit
		
		for i,v in ipairs(ReportData) do
			local LocationY,SizeY,MyLocation = 450,0,0
			local NumLabel
			
			if index == 0 then
				useNum = v.usedCount
			elseif index == 1 then
				useNum = v.kill
			elseif index == 2 then
				useNum = v.dead
			elseif index == 3 then
				useNum = v.controlNum
			elseif index == 4 then
				useNum = v.revengeNum
			elseif index == 5 then
				useNum = v.assistNum
			elseif index == 6 then
				useNum = v.knifeKill
			end
			
			SizeY = ((useNum)/(useMax - useMax2))*130
			
			if SizeY > 260 then
				SizeY = 270
			end
			
			LocationY = LocationY - SizeY
			
			if i == 1 then
				main_report_window_ui.colunm1.Location =  Vector2(280,LocationY)
				main_report_window_ui.colunm1.Size = Vector2(65,SizeY)
				MyLocation = main_report_window_ui.colunm1.Location
				main_report_window_ui.LNumLabel.Location = Vector2(MyLocation.x+7,MyLocation.y-40)
				main_report_window_ui.LNumLabel.Text = useNum
			elseif i == 2 then
				main_report_window_ui.colunm2.Location = Vector2(375,LocationY)
				main_report_window_ui.colunm2.Size = Vector2(65,SizeY)
				MyLocation = main_report_window_ui.colunm2.Location
				main_report_window_ui.LNumLabe2.Location = Vector2(MyLocation.x+7,MyLocation.y-40)
				main_report_window_ui.LNumLabe2.Text = useNum
			elseif i == 3 then
				main_report_window_ui.colunm3.Location = Vector2(470,LocationY)
				main_report_window_ui.colunm3.Size = Vector2(65,SizeY)
				MyLocation = main_report_window_ui.colunm3.Location
				main_report_window_ui.LNumLabe3.Location = Vector2(MyLocation.x+7,MyLocation.y-40)
				main_report_window_ui.LNumLabe3.Text = useNum
			elseif i == 4 then
				main_report_window_ui.colunm4.Location = Vector2(565,LocationY)
				main_report_window_ui.colunm4.Size = Vector2(65,SizeY)
				MyLocation = main_report_window_ui.colunm4.Location
				main_report_window_ui.LNumLabe4.Location = Vector2(MyLocation.x+7,MyLocation.y-40)
				main_report_window_ui.LNumLabe4.Text = useNum
			elseif i == 5 then
				main_report_window_ui.colunm5.Location = Vector2(660,LocationY)
				main_report_window_ui.colunm5.Size = Vector2(65,SizeY)
				MyLocation = main_report_window_ui.colunm5.Location
				main_report_window_ui.LNumLabe5.Location = Vector2(MyLocation.x+7,MyLocation.y-40)
				main_report_window_ui.LNumLabe5.Text = useNum
			elseif i == 6 then
				main_report_window_ui.colunm6.Location = Vector2(755,LocationY)
				main_report_window_ui.colunm6.Size = Vector2(65,SizeY)
				MyLocation = main_report_window_ui.colunm6.Location
				main_report_window_ui.LNumLabe6.Location = Vector2(MyLocation.x+7,MyLocation.y-40)
				main_report_window_ui.LNumLabe6.Text = useNum
			elseif i == 7 then
				main_report_window_ui.colunm7.Location = Vector2(850,LocationY)
				main_report_window_ui.colunm7.Size = Vector2(65,SizeY)
				MyLocation = main_report_window_ui.colunm7.Location
				main_report_window_ui.LNumLabe7.Location = Vector2(MyLocation.x+7,MyLocation.y-40)
				main_report_window_ui.LNumLabe7.Text = useNum
			end
		end
	end
end

function SpawnNewHead(name,i)
	local row,col = 0,0
	
	local HeadCon = Gui.Create(gui) {
					Gui.Control "CHead"
					{
						Size = Vector2(96,108),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_bg_03.dds", Vector4(0, 0, 0, 0)),
						},
				
						Gui.Button "BHead"
						{
							Location = Vector2(4,4),
							Size = Vector2(88,100),			
							BackgroundColor = ARGB(255, 255, 255, 255),
							TextColor = ARGB(0, 255, 255, 255),
							HighlightTextColor = ARGB(0, 255, 255, 255),
							DisabledTextColor = ARGB(0, 255, 255, 255),
							
							EventClick = function(Sender,e)
								if selected_headIcon then
									selected_headIcon.PushDown = false
								end
								Sender.PushDown = true
								selected_headIcon = Sender	
								edit_persional_win_ui.Head.Skin = Sender.Skin
								SelectHeadIcon = Sender.Text
							end,
							
							Gui.Control "Vip_Head"
							{
								Location = Vector2(19, 60),
								Size = Vector2(50, 29),
								BackgroundColor = ARGB(255,255,255,255),
								Visible = false,
								Skin = Gui.ControlSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_button_01_normal.dds", Vector4(0, 0, 0, 0)),
								},
							},
						},
					}
				}
	col = i / 5
	col = math.floor(col)
	if i % 5 == 0 then
		col = col - 1
	end
	
	row = i - col * 5
		
	HeadCon.CHead.Location = Vector2((row-1)*105+20,col*114 +9)
	HeadCon.BHead.Skin = Gui.ButtonSkin{
							BackgroundImage = Gui.Image("LobbyUI/persionalInfo/HeadPic/".."lb_info_image"..name..".dds", Vector4(14, 14, 14, 14)),
							HoverImage = Gui.Image("LobbyUI/persionalInfo/lb_info_acheive_hover.dds", Vector4(5, 5, 5, 5)),
							DownImage = Gui.Image("LobbyUI/persionalInfo/lb_info_acheive_hover.dds", Vector4(5, 5, 5, 5)),
							DisabledImage = Gui.Image("LobbyUI/persionalInfo/HeadPic/".."lb_info_image"..name..".dds", Vector4(14, 14, 14, 14)),
							}
	HeadCon.BHead.Text = name
	
	return HeadCon
end

function SpawnNewTitle(name,i)
	local row,col = 0,0
	local TitleCol = Gui.Create(gui) {
					Gui.Control "CTitle"
					{
						Location = Vector2(20,20),
						Size = Vector2(140,30),
						
						Gui.Button "BTitle"
						{
							Location = Vector2(0,0),
							Size = Vector2(140,30),			
							BackgroundColor = ARGB(255, 255, 255, 255),				
							TextAlign = "kAlignCenterMiddle",
							TextColor = ARGB(255,253,211,77),
							FontSize = 15,
							
							Skin = Gui.ButtonSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_titleBG_normal.dds", Vector4(14,14,14,14)),
								HoverImage = Gui.Image("LobbyUI/persionalInfo/lb_info_acheive_hover.dds", Vector4(5, 5, 5, 5)),
								DownImage = Gui.Image("LobbyUI/persionalInfo/lb_info_acheive_hover.dds", Vector4(5, 5, 5, 5)),
							},
							
							EventClick = function(Sender,e)
								edit_persional_win_ui.MyTitle3.Text = Sender.Text
								
								if selected_achname then
									selected_achname.PushDown = false
								end
								Sender.PushDown = true
								selected_achname = Sender							
							end
						},
					}
				  }
				  
	col = i / 4
	col = math.floor(col)
	if i % 4 == 0 then
		col = col - 1
	end
	
	row = i - col * 4
	
	TitleCol.CTitle.Location = Vector2((row-1)*145+45,col*45 +40)
	TitleCol.BTitle.Text = name[1]
	
	if name[2] == "0" then
		TitleCol.BTitle.Enable = false
	end
	
	return TitleCol
end

function IsInRect(rect,pos)
	if pos.x < rect.Location.x + rect.Size.x
	and pos.x > rect.Location.x and pos.y < rect.Location.y + rect.Size.y
	and pos.y > rect.Location.y then		
		return true
	else
		return false
	end
end

function SpawnNewAchievement(achievement,i)
	local row,col = 0,0
	local AchievementName = achievement[1]
	local Enable = achievement[3]
	local Skin 
	local Achievement = Gui.Create(gui) {
						Gui.Control "CAchievement"
						{
							Size = Vector2(63,62),
							BackgroundColor = ARGB(0, 255, 255, 255),

							
							Gui.Button "BAchievement"
							{
								Size = Vector2(63,62),
								Location = Vector2(0,0),
								BackgroundColor = ARGB(255, 255, 255, 255),
								TextColor = ARGB(0, 0, 0, 0),
								HighlightTextColor = ARGB(0, 0, 0, 0),
								IsNeedToolTip = true,
								
								Skin = Gui.ButtonSkin
								{
									BackgroundImage = Gui.Image("LobbyUI/lb_info_xinxi_bg.dds", Vector4(14,14,14,14)),
								},
								
								UpdateMouseMove = function(Sender,e)
									local lobby_state = ptr_cast(game.CurrentState)
									if lobby_state and tooltip_window_ui and tooltip_window_ui.ctrl_root then
										local cursor_pos = lobby_state:GetCursorPos()
										local pos = Vector2(cursor_pos.x+25,cursor_pos.y+25)
										ShowToolTipsWindow(pos)
									end
								end,
								
								EventMouseDown = function(sender, e)
									if IsFinish > 0 then
										if not DragWindow_ui then
											DragWindow_ui = Gui.Create(L_LobbyMain.LobbyMainWin.LobbyMain_Root)(DragWindow)
										end
										local DragSkin = nil
										DragWindow_ui.root.Visible = true
										local lobby_state = ptr_cast(game.CurrentState)
										local cursor_ScreenSize = lobby_state:GetScreenSize()
										local cursor_pos = lobby_state:GetCursorPos()
										DragWindow_ui.Image.Location = Vector2(cursor_pos.x-((cursor_ScreenSize.x - cursor_ScreenSize.y / 3 * 4) / 2) - 31, cursor_pos.y - 4)
										DragWindow_ui.Image.Size = Vector2(63, 62)
										DragSkin = Gui.ButtonSkin{
																BackgroundImage = Gui.Image("LobbyUI/persionalInfo/achieves/acheive"..sender.Text..".dds", Vector4(14,14,14,14)),
																HoverImage = Gui.Image("LobbyUI/persionalInfo/lb_info_acheive_hover.dds", Vector4(5, 5, 5, 5)),
																DownImage = Gui.Image("LobbyUI/persionalInfo/lb_info_acheive_hover.dds", Vector4(5, 5, 5, 5)),
															}
										DragWindow_ui.Image.Skin = DragSkin
										Select_Drag_label = sender.Text
										Select_Drag_Skin = DragSkin
										sender.Skin.BackgroundImage.alpha = 80
										Drag_Sender = sender
									end
								end,
	--[[							
								EventClick = function(Sender,e)
									if selected_achicon then
										selected_achicon.PushDown = false
									end
									Sender.PushDown = true
									selected_achicon = Sender
									
									local Skin = nil
									Skin = Gui.ButtonSkin{BackgroundImage = Gui.Image("LobbyUI/persionalInfo/achieves/acheiveabc.dds", Vector4(14,14,14,14)),}
									
									for i = 1,4 do
										if SelectAchievementArray[i] == Sender.Text then
											SelectAchievementArray[i] = -1
											
											if i == 1 then
												edit_persional_win_ui.MyAchievement2.Skin = Skin
											elseif i == 2 then
												edit_persional_win_ui.MyAchievement3.Skin = Skin
											elseif i == 3 then
												edit_persional_win_ui.MyAchievement4.Skin = Skin
											elseif i == 4 then
												edit_persional_win_ui.MyAchievement5.Skin = Skin
											end
										end
									end
									
									if SelectAchievementButton == 2 then
										edit_persional_win_ui.MyAchievement2.Skin = Sender.Skin
										SelectAchievementArray[1] = Sender.Text
									elseif SelectAchievementButton == 3 then
										edit_persional_win_ui.MyAchievement3.Skin = Sender.Skin
										SelectAchievementArray[2] = Sender.Text
									elseif SelectAchievementButton == 4 then
										edit_persional_win_ui.MyAchievement4.Skin = Sender.Skin
										SelectAchievementArray[3] = Sender.Text
									elseif SelectAchievementButton == 5 then
										edit_persional_win_ui.MyAchievement5.Skin = Sender.Skin
										SelectAchievementArray[4] = Sender.Text	
									end
								end,
	]]							
								EventMouseEnter = function(Sender,e)
									if IsFinish > 0 then
										local index = achievementIndextoID[Sender.Text]
										local achievement_data = nil
										if current_achievement == 1 then
											achievement_data = gen_achievement_data
										elseif current_achievement == 3 then
											achievement_data = character_achievement_data
										end
										
										if gen_achievement_data then
											local location = e.CursorPosition
											local data = {}
											local ach = achievement_data[index]
											local content = ach[2]
											local title = ach[4]
											local realIndex  = ach[1]
											
											data[1] = 4
											data[6] = {realIndex,title,content,0,0,0}
											setup_tooltips_window(gui)
											if tooltip_window_ui then
												tooltip_window_ui.ctrl_root.Location = location
											end
											FillToolTipsWindow(data,0)	
										end
									end
								end,
								
								EventMouseLeave = function(Sender,e)
									HideToolTipsWindow()
								end
							},
							
							Gui.Label "BAchievementLock"
							{
								Size = Vector2(63,62),
								Location = Vector2(0,0),
								BackgroundColor = ARGB(255, 255, 255, 255),
								Visible = false,
								
								Skin = Gui.ControlSkin{ 
									BackgroundImage = Gui.Image("LobbyUI/persionalInfo/acheive_lock.dds", Vector4(14, 14, 14, 14)),
								},
							},
						}
					}
	col = i / 8
	col = math.floor(col)
	if i % 8 == 0 then
		col = col - 1
	end
	
	row = i - col * 8
	
	if AchievementName <=9 then
		AchievementName = "0"..AchievementName
	else
		AchievementName = AchievementName..""
	end
	
	achievementIndextoID[AchievementName] = i
	
	if Enable == 0 then
		Achievement.BAchievement.Enable = false
		Achievement.BAchievementLock.Visible = true
	end

	
	Achievement.CAchievement.Location = Vector2((row-1)*72+28,col*68 +10)
	Achievement.BAchievement.Text = AchievementName
	Skin = Gui.ButtonSkin{
						BackgroundImage = Gui.Image("LobbyUI/persionalInfo/achieves/acheive"..AchievementName..".dds", Vector4(14,14,14,14)),
						HoverImage = Gui.Image("LobbyUI/persionalInfo/lb_info_acheive_hover.dds", Vector4(5, 5, 5, 5)),
						DownImage = Gui.Image("LobbyUI/persionalInfo/lb_info_acheive_hover.dds", Vector4(5, 5, 5, 5)),
					}
	Achievement.BAchievement.Skin = Skin
	
	return Achievement
end

function Fill_Achievement(data)
	local achievementdata,achievementlist
	local currentPage,totalPage = 0,0
	local edit_persional_data = nil
	local displayControl = nil
	
	achievementdata = data.achievement
	totalPage = achievementdata.totalPage
	
	if current_achievement == 1 then
		achievementlist = achievementdata.general_list
	elseif current_achievement == 3 then
		achievementlist = achievementdata.character_list
	end
	
	if not achievementlist then
		return
	end
	
	if current_achievement == 1 then
		edit_persional_win_ui.character_Achievement.Visible = false
		displayControl = edit_persional_win_ui.General_Achievement
		total_gen_achievement_page = totalPage
		currentPage = current_gen_achievement_page
		gen_achievement_data = achievementlist
	elseif current_achievement == 3 then
		edit_persional_win_ui.General_Achievement.Visible = false
		displayControl = edit_persional_win_ui.character_Achievement
		total_character_achievement_page = totalPage
		currentPage = current_character_achievement_page
		character_achievement_data = achievementlist
	end
	
	displayControl.Visible = true
	
	if currentPage <= 1 then
		currentPage = 1
	end
	
	if currentPage >= totalPage then
		currentPage = totalPage
	end
	
	if current_achievement == 1 then
		current_gen_achievement_page = currentPage
	elseif current_achievement == 3 then
		current_character_achievement_page = currentPage
	end
	
	displayControl:OnDestroy()
	
	local label = currentPage .."/"..totalPage
	edit_persional_win_ui.m_AchePageDisplay.Text = label
	
	for i,v in ipairs(achievementlist) do
		local Achievement = SpawnNewAchievement(v,i)
		Achievement.CAchievement.Parent = displayControl
	end	
end

function Fill_EditInfoAchievement(isleft)
	local currentPage,totalPage = 0,0
	local edit_persional_data = nil
	local displayControl = nil
	
	if current_achievement == 1 then
		totalPage = total_gen_achievement_page
		currentPage = current_gen_achievement_page
		edit_persional_data = gen_achievement_data
		displayControl = edit_persional_win_ui.General_Achievement
	elseif current_achievement == 3 then
		totalPage = total_character_achievement_page
		currentPage = current_character_achievement_page
		edit_persional_data = character_achievement_data
		displayControl = edit_persional_win_ui.character_Achievement
	end
	
	if isleft == true then
		currentPage = currentPage -1
	elseif isleft == false then
		currentPage = currentPage +1
	end
	
	if currentPage <= 1 then
		currentPage = 1
	end
	
	if currentPage >= totalPage then
		currentPage = totalPage
	end
	
	if current_achievement == 1 then
		current_gen_achievement_page = currentPage
	elseif current_achievement == 3 then
		current_character_achievement_page = currentPage
	end
	
	displayControl:OnDestroy()
	
	local label = currentPage .."/"..totalPage
	
	edit_persional_win_ui.m_AchePageDisplay.Text = label
	
	if edit_persional_data then
		for i=1,40 do
			local index = (currentPage - 1) * 40
			local data = edit_persional_data[i + index]
			if data then
				local Achievement = SpawnNewAchievement(data,i)
				Achievement.CAchievement.Parent = displayControl
			end	
		end
	end
end

function Fill_HeadInfo(data)
	MessageBox.CloseWaiter()
	if data.warning then
		MessageBox.ShowWithTimer(1,data.warning)
		ptr_cast(game.CurrentState):Quit()
		return
	end
	
	local headdata,head,achievement,achievementlist
	local headlist,title
	
	headdata = data.head
	headlist = headdata.data_list
	head = headdata.current
	achievement = headdata.current1
	title = headdata.current2
	MaxHeadPage = headdata.totalPage
	edit_persional_win_ui.m_HeadPageDisplay.Text = NowHeadPage.."/"..MaxHeadPage
	edit_persional_win_ui.DisplayHead:OnDestroy()
	print("MaxHeadPage = "..MaxHeadPage)
	local j = 1
	for i,v in ipairs(headlist) do
		if i % 2 == 1 then
			local vb = v.."_b"
			local HeadCol = SpawnNewHead(vb,j*2)
			if headlist[i+1] ~= 0 then
				if L_Vip.Viplevel < headlist[i+1] then
					HeadCol.Vip_Head.Visible = true
					HeadCol.Vip_Head.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_button_0"..headlist[i+1].."_disabled.dds", Vector4(0, 0, 0, 0)),}
					HeadCol.CHead.Enable = false
				else
					HeadCol.Vip_Head.Visible = true
					HeadCol.Vip_Head.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_button_0"..headlist[i+1].."_normal.dds", Vector4(0, 0, 0, 0)),}
					HeadCol.CHead.Enable = true
				end
			else
				HeadCol.Vip_Head.Visible = false
				HeadCol.CHead.Enable = true
			end	
			HeadCol.CHead.Parent = edit_persional_win_ui.DisplayHead
			j = j + 1
		end
	end
	
	j = 1
	for i,v in ipairs(headlist) do
		if i % 2 == 1 then
			local vr = v.."_r"
			local HeadCol = SpawnNewHead(vr,j*2 -1)
			if headlist[i+1] ~= 0 then
				if L_Vip.Viplevel < headlist[i+1] then
					HeadCol.Vip_Head.Visible = true
					HeadCol.Vip_Head.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_button_0"..headlist[i+1].."_disabled.dds", Vector4(0, 0, 0, 0)),}
					HeadCol.CHead.Enable = false
				else
					HeadCol.Vip_Head.Visible = true
					HeadCol.Vip_Head.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_button_0"..headlist[i+1].."_normal.dds", Vector4(0, 0, 0, 0)),}
					HeadCol.CHead.Enable = true
				end
			else
				HeadCol.Vip_Head.Visible = false
				HeadCol.CHead.Enable = true
			end	
			HeadCol.CHead.Parent = edit_persional_win_ui.DisplayHead
			j = j + 1
		end	
	end
	
	edit_persional_win_ui.MyTitle3.Text = title
--[[	
	achievementlist = Split(achievement,",")
	
	for i,v in ipairs(achievementlist) do
		local Skin = nil
		
		SelectAchievementArray[i] = v
		
		Skin = Gui.ButtonSkin{BackgroundImage = Gui.Image("LobbyUI/persionalInfo/achieves/acheive"..v..".dds", Vector4(14,14,14,14)),}
		
		if Skin then
			if i == 1 then
				edit_persional_win_ui.MyAchievement2.Skin = Skin
				edit_persional_win_ui.MyAchievement2Back.Visible = true
			elseif i == 2 then
				edit_persional_win_ui.MyAchievement3.Skin = Skin
				edit_persional_win_ui.MyAchievement3Back.Visible = true
			elseif  i == 3 then
				edit_persional_win_ui.MyAchievement4.Skin = Skin
				edit_persional_win_ui.MyAchievement4Back.Visible = true
			elseif i == 4 then
				edit_persional_win_ui.MyAchievement5.Skin = Skin
				edit_persional_win_ui.MyAchievement5Back.Visible = true
			end
		end
	end
]]	
	if head ~="null" then
		SelectHeadIcon = head
		
		headSkin = Gui.ControlSkin{ BackgroundImage = Gui.Image("LobbyUI/persionalInfo/HeadPic/lb_info_image"..head..".dds", Vector4(14, 14, 14, 14)),}
		
		edit_persional_win_ui.Head.Skin = headSkin
	end
end

function Fill_Title(data)
	MessageBox.CloseWaiter()
	if data.warning then
		MessageBox.ShowWithTimer(1,data.warning)
		ptr_cast(game.CurrentState):Quit()
		return
	end
	
	local titledata,title
	local titlelist
	
	titledata = data.title
	titlelist = titledata.data_list
	
	for i,v in ipairs(titlelist) do			
		local TitleCol = SpawnNewTitle(v,i)
		TitleCol.CTitle.Parent = edit_persional_win_ui.DisplayTitContent		
	end
	
	total_title_page = titledata.totalPage
	
	edit_persional_win_ui.m_PageDisplay.Text = current_title_page.."/"..total_title_page
end

function Fill_EditInfo(data)
	MessageBox.CloseWaiter()
	if data.warning then
		MessageBox.ShowWithTimer(1,data.warning)
		ptr_cast(game.CurrentState):Quit()
		return
	end
	
	local headdata,titledata,achievementdata,head,title,achievement,achievementlist
	local general_list,task_list,character_list
	local headlist,titlelist,headSkin
	local counter
	
	headdata = data.head
	titledata = data.title
	achievementdata = data.achievement
	
	general_list = achievementdata.general_list
	task_list = achievementdata.task_list
	character_list = achievementdata.character_list
	
	gen_achievement_data = general_list
	task_achievement_data = task_list
	character_achievement_data = character_list

	head = headdata.current
	title = titledata.current
	achievement = achievementdata.current
	headlist = headdata.data_list
	titlelist = titledata.data_list
	
	current_achievement = 1
	
	total_gen_achievement_page = math.ceil(#general_list/40)
	edit_persional_win_ui.m_AchePageDisplay.Text = current_gen_achievement_page.."/"..total_gen_achievement_page
	
	total_character_achievement_page = math.ceil(#character_list/40)
	
	counter = 0
	
	for i,v in ipairs(headlist) do
		local vb = v.."_b"
		local HeadCol = SpawnNewHead(vb,i*2)
		HeadCol.CHead.Parent = edit_persional_win_ui.DisplayHead
		counter = i
	end
	
	for i,v in ipairs(headlist) do
		local vr = v.."_r"
		local HeadCol = SpawnNewHead(vr,i*2 -1)
		HeadCol.CHead.Parent = edit_persional_win_ui.DisplayHead
	end
	
	title_data = titlelist
	counter = 0
	
	current_title_page = 1
	
	for i = 1,32 do		
		local v = titlelist[i]		
		local TitleCol = SpawnNewTitle(v,i)
		TitleCol.CTitle.Parent = edit_persional_win_ui.DisplayTitContent		
		counter = counter + 1
	end
	
	local titlenum = #titlelist/32
	titlenum = math.ceil(titlenum)
	total_title_page = titlenum
	edit_persional_win_ui.m_PageDisplay.Text = "1/"..titlenum
	
	if head ~="null" then
		SelectHeadIcon = head
		
		headSkin = Gui.ControlSkin{ BackgroundImage = Gui.Image("LobbyUI/persionalInfo/HeadPic/lb_info_image"..head..".dds", Vector4(14, 14, 14, 14)),}
		
		edit_persional_win_ui.Head.Skin = headSkin
	end
	
	if title ~= "null" then
		edit_persional_win_ui.MyTitle3.Text = title
	end
	
	achievementlist = Split(achievement,",")
	
	for i,v in ipairs(achievementlist) do
		local Skin = nil
		
		SelectAchievementArray[i] = v
		
		Skin = Gui.ButtonSkin{BackgroundImage = Gui.Image("LobbyUI/persionalInfo/achieves/acheive"..v..".dds", Vector4(14,14,14,14)),}
		
		if Skin then
			if i == 1 then
				edit_persional_win_ui.MyAchievement2.Skin = Skin
				edit_persional_win_ui.MyAchievement2Back.Visible = true
			elseif i == 2 then
				edit_persional_win_ui.MyAchievement3.Skin = Skin
				edit_persional_win_ui.MyAchievement3Back.Visible = true
			elseif  i == 3 then
				edit_persional_win_ui.MyAchievement4.Skin = Skin
				edit_persional_win_ui.MyAchievement4Back.Visible = true
			elseif i == 4 then
				edit_persional_win_ui.MyAchievement5.Skin = Skin
				edit_persional_win_ui.MyAchievement5Back.Visible = true
			end
		end
	end
end


local main_popup_window = 
{	
	Gui.ModalControl "ctrl_main_popup_window"
	{
	}
}

function CreateAchievementControl(data)
	main_popup_window_ui = Gui.Create(root_ui)(main_popup_window)
	main_popup_window = ModalWindow.GetNew("main_popup_window_ui")
	main_popup_window.screen.AllowEscToExit = false
	main_popup_window.screen.Visible = false
	main_popup_window_ui.ctrl_main_popup_window.Parent = gui
	main_popup_window_ui.ctrl_main_popup_window.RootPanel.Style = "Gui.SettingsWindow"
	main_popup_window_ui.ctrl_main_popup_window.RootPanel.Size = Vector2(512, 309)
	main_popup_window_ui.root = main_popup_window_ui.ctrl_main_popup_window.RootPanel
	
	local AchievementControl = Gui.Create(gui)
	{
		Gui.ShaderControl  "CAchievement"
		{
			Size = Vector2(512, 309),
			Location = Vector2(0, 0),
			BackgroundColor = ARGB(255, 255, 255, 255),
			ShaderPS = "control_anim",
			Skin = Gui.ShaderSkin
			{
				ResImage1 = Gui.Image("LobbyUI/persionalInfo/achievment/lb_chenjiu_bg1.dds", Vector4(15, 15, 15, 15)),
				ResImage2 = Gui.Image("LobbyUI/persionalInfo/achievment/chenjiu_mask.dds", Vector4(15, 15, 15, 15)),
				ResImage3 = Gui.Image("LobbyUI/effect/strip.dds", Vector4(15, 15, 15, 15)),
			},

			Gui.Control "CAchievement1"
			{
				Size = Vector2(475, 121),
				Location = Vector2(17, 22),
				BackgroundColor = ARGB(255, 255, 255, 255),
			
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/persionalInfo/achievment/lb_chenjiu_bg2.dds", Vector4(7, 7, 7, 7)),
				},
				
				Gui.Label "LAcheBck"
				{
					Size = Vector2(81, 80),
					Location = Vector2(1, 19),
					BackgroundColor = ARGB(255, 255, 255, 255),
					
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_acheive_bg.dds", Vector4(0, 0, 0, 0)),
					},
				},
				
				Gui.Label "LAche"
				{
					Size = Vector2(64, 64),
					Location = Vector2(9, 27),
					BackgroundColor = ARGB(255, 255, 255, 255),
				},
				
				Gui.TextArea "AcheName"
				{
					Size = Vector2(400, 115),
					Location = Vector2(80, 3),
					BackgroundColor = ARGB(0, 255, 255, 255),
					Readonly = true,
					Fold = true,
					TextColor = ARGB(255,255,255,206),
					FontSize = 24,
					Text = "",
				},
			},
			
			Gui.Control "CAchievement2"
			{
				Size = Vector2(475, 111),
				Location = Vector2(17, 149),
				BackgroundColor = ARGB(255, 255, 255, 255),
			
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/persionalInfo/achievment/lb_chenjiu_bg2.dds", Vector4(7, 7, 7, 7)),
				},
				
				Gui.Label "giftIcon"
				{
					BackgroundColor = ARGB(255, 255, 255, 255),
				},
				
				Gui.TextArea "giftDiscription"
				{
					Location = Vector2(180,15),
					Size = Vector2(280,101),
					Readonly = true,
					Fold = true,
					BackgroundColor = ARGB(0, 255, 255, 255),
					TextColor = ARGB(255,250,217,141),
					FontSize = 20,
				},
			},
			
			Gui.Button "OK"
			{
				Size = Vector2(104, 36),
				Location = Vector2(205, 265),
				BackgroundColor = ARGB(255, 255, 255, 255),
				TextAlign = "kAlignCenterMiddle",
				TextColor = ARGB(255,108,56,0),
				FontSize = 20,
				Text = lang:GetText("下一页"),
				
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/persionalInfo/achievment/lb_chenjiu_button_normal.dds", Vector4(10,10,10,10)),
					HoverImage = Gui.Image("LobbyUI/persionalInfo/achievment/lb_chenjiu_button_hover.dds", Vector4(10,10,10,10)),
					DownImage = Gui.Image("LobbyUI/persionalInfo/achievment/lb_chenjiu_button_down.dds", Vector4(10,10,10,10)),
				},
				
				EventClick = function (Sender,e)
					if achievementData then
						if Sender.Text == lang:GetText("确定") then
							main_popup_window_ui.ctrl_main_popup_window.Parent = nil
							main_popup_window_ui = nil
							return
						end
						
						if achievementCounter <= #achievementData then
							achievementCounter = achievementCounter + 1
						end
						
						if achievementCounter == #achievementData then
							Sender.Text = lang:GetText("确定")
						end
						
						local Data = achievementData[achievementCounter]
						
						if Data then
							local HeadIcon = Data[1]
							local AchievementName = Data[2]
							local AchievementContent = Data[3] 
							local giftIcon = Data[8]
							local giftIconnum = Data[9]
							local giftDiscription = lang:GetText("可用于兑换商城道具。")
							local giftType = Data[8]
							local color = Data[11]
							local giftImageSize = 0
							local y = 0
							local giftString = lang:GetText("恭喜你获得以下奖励\n")

							if giftIcon == "" or  giftIconnum == 0 then
								achievementControl.giftDiscription.Visible = false
							else
								achievementControl.giftDiscription.Visible = true
							end
							
							if HeadIcon < 10 then
								HeadIcon = "0"..HeadIcon
							end
							
							if color and color > 0 then
								giftIcon = giftIcon.."_"..color
							end
							
							achievementControl.LAche.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/persionalInfo/achieves/acheive"..HeadIcon..".dds", Vector4(0, 0, 0, 0)),}
							achievementControl.AcheName.Text = lang:GetText("恭喜你达成了以下成就条件\n")..AchievementContent.."\n"..AchievementName
					
							achievementControl.CAchievement.Size = Vector2(512, 309)
							achievementControl.CAchievement2.Visible = true
							achievementControl.OK.Location = Vector2(205, 265)
							
							if giftType == 0 then
								local CAchievementHeight,CAchievementWidth,CAchievement2Height,newHeight = 0,0,0,0
								local OKLocationY,OKLocationX = 0,0
								achievementControl.CAchievement2.Visible = false
								CAchievementHeight = achievementControl.CAchievement.Size.y
								CAchievementWidth = achievementControl.CAchievement.Size.x
								CAchievement2Height = achievementControl.CAchievement2.Size.y
								OKLocationY = achievementControl.OK.Location.y
								OKLocationX = achievementControl.OK.Location.x
								newHeight = CAchievementHeight - CAchievement2Height
								OKLocationY = OKLocationY - CAchievement2Height
								achievementControl.OK.Location = Vector2(OKLocationX,OKLocationY)
								achievementControl.CAchievement.Size = Vector2(CAchievementWidth,newHeight)
								return
							end
							
							local path = "LobbyUI/ibt_icon/"..giftIcon..".tga"
							achievementControl.giftIcon.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image(path, Vector4(0, 0, 0, 0)),}
							
							giftImageSize = achievementControl.giftIcon.Skin.BackgroundImage.Size
							L_Characters.CreatPresentNumCtr(achievementControl.giftIcon,giftIconnum,giftImageSize.x,giftImageSize.y)
							if achievementControl.CAchievement2.Size.y > giftImageSize.y then
								y = (achievementControl.CAchievement2.Size.y - giftImageSize.y)/2
								y = math.ceil(y)
								achievementControl.giftIcon.Location = Vector2(5,y)
								achievementControl.giftIcon.Size = Vector2(giftImageSize.x,giftImageSize.y)
							else
								ratio =  achievementControl.CAchievement2.Size.y/giftImageSize.y
								x = giftImageSize.x * ratio
								y = achievementControl.CAchievement2.Size.y
								achievementControl.giftIcon.Location = Vector2(5,0)								
								achievementControl.giftIcon.Size = Vector2(x,y)
							end
							
							if giftDiscription ~= nil then												
								if string.len(giftDiscription) > string.len(giftString) then
									local spacelen = string.len(giftDiscription) - string.len(giftString)
									spacelen = math.floor(spacelen/2)
									
									while spacelen > 0 do
										giftString = " "..giftString
										spacelen = spacelen - 1
									end
								else
									local spacelen = string.len(giftString) - string.len(giftDiscription)
									spacelen = math.floor(spacelen/2)
									
									while spacelen > 0 do
										giftDiscription = " "..giftDiscription
										spacelen = spacelen - 1
									end
								end
								
								achievementControl.giftDiscription.Text = giftString..giftDiscription
							 else
								
							end
						else
							main_popup_window_ui.ctrl_main_popup_window.Parent = nil
							main_popup_window_ui = nil
							return
						end
					else
						main_popup_window_ui.ctrl_main_popup_window.Parent = nil
						main_popup_window_ui = nil
						return
					end
				end
			},
		}
	}
	achievementCounter = 1
	AchievementControl.CAchievement.Parent = main_popup_window_ui.ctrl_main_popup_window.RootPanel
	
	achievementControl = AchievementControl
end

function InitAchievement(data)
	achievementData = data.list
	local achievementList = data.list
	local FirstData = achievementList[1]
	local HeadIcon = FirstData[1]
	local AchievementName = FirstData[2]
	local AchievementContent = FirstData[3]
	local giftType = FirstData[8]
	local giftIcon = FirstData[8]
	local giftIconnum = FirstData[9]
	local giftDiscription = lang:GetText("可用于兑换商城道具。")
	local color = FirstData[11]
	local giftImageSize
	local giftImageSize = 0
	local giftString = lang:GetText("恭喜你获得以下奖励\n")
	local y = 0
	
	if giftIcon == "" or  giftIconnum == 0 then
		achievementControl.giftDiscription.Visible = false
	else
		achievementControl.giftDiscription.Visible = true
	end
	
	if HeadIcon < 10 then
		HeadIcon = "0"..HeadIcon
	end
	
	if color and color > 0 then
		giftIcon = giftIcon.."_"..color
	end
												
	if achievementControl then
		if #achievementList == 1 then
			achievementControl.OK.Text = lang:GetText("确定")
		else
			achievementControl.OK.Text = lang:GetText("下一页")
		end
		
		achievementControl.LAche.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/persionalInfo/achieves/acheive"..HeadIcon..".dds", Vector4(0, 0, 0, 0)),}
		achievementControl.AcheName.Text = lang:GetText("恭喜你达成了以下成就条件 \n")..AchievementContent.."\n"..AchievementName
			
		achievementControl.CAchievement.Size = Vector2(512, 309)
		achievementControl.CAchievement2.Visible = true
		achievementControl.OK.Location = Vector2(205, 265)
		
		if giftType == 0 then
			local CAchievementHeight,CAchievementWidth,CAchievement2Height,newHeight = 0,0,0,0
			local OKLocationY,OKLocationX = 0,0
			achievementControl.CAchievement2.Visible = false
			CAchievementHeight = achievementControl.CAchievement.Size.y
			CAchievementWidth = achievementControl.CAchievement.Size.x
			CAchievement2Height = achievementControl.CAchievement2.Size.y
			OKLocationY = achievementControl.OK.Location.y
			OKLocationX = achievementControl.OK.Location.x
			newHeight = CAchievementHeight - CAchievement2Height
			OKLocationY = OKLocationY - CAchievement2Height
			achievementControl.OK.Location = Vector2(OKLocationX,OKLocationY)
			achievementControl.CAchievement.Size = Vector2(CAchievementWidth,newHeight)
			return
		end
		
		local path = "LobbyUI/ibt_icon/"..giftIcon..".tga"
		achievementControl.giftIcon.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image(path, Vector4(0, 0, 0, 0)),}
		
		giftImageSize = achievementControl.giftIcon.Skin.BackgroundImage.Size
		L_Characters.CreatPresentNumCtr(achievementControl.giftIcon,giftIconnum,giftImageSize.x,giftImageSize.y)
	
		if achievementControl.CAchievement2.Size.y > giftImageSize.y then
			y = (achievementControl.CAchievement2.Size.y - giftImageSize.y)/2
			y = math.ceil(y)
			achievementControl.giftIcon.Location = Vector2(5,y)
			achievementControl.giftIcon.Size = Vector2(giftImageSize.x,giftImageSize.y)
		else
			ratio =  achievementControl.CAchievement2.Size.y/giftImageSize.y
			x = giftImageSize.x * ratio
			y = achievementControl.CAchievement2.Size.y
			achievementControl.giftIcon.Location = Vector2(5,0)								
			achievementControl.giftIcon.Size = Vector2(x,y)
		end
		
		if giftDiscription ~= nil then
			if string.len(giftDiscription) > string.len(giftString) then
				local spacelen = string.len(giftDiscription) - string.len(giftString)
				spacelen = math.floor(spacelen/2)
				
				while spacelen > 0 do
					giftString = " "..giftString
					spacelen = spacelen - 1
				end
			else
				local spacelen = string.len(giftString) - string.len(giftDiscription)
				spacelen = math.floor(spacelen/2)
				
				while spacelen > 0 do
					giftDiscription = " "..giftDiscription
					spacelen = spacelen - 1
				end
			end
			achievementControl.giftDiscription.Text = giftString..giftDiscription	
		end
	end
	
end

function PopupAchievement(data)
	if not main_popup_window_ui then
		CreateAchievementControl()
	else
		main_popup_window_ui.ctrl_main_popup_window.Parent = gui
	end
	
	InitAchievement(data)
	
	if gui then
	   gui:PlayAudio("kUIA_CONGRA_POP") 
	end

	Gui.Align(main_popup_window_ui.ctrl_main_popup_window, 0.5, 0.5)
end

function FaceBook(data)
	local achievementList = data.list
	local FirstData = achievementList[1]
	gui:SetFaceBookData(FirstData[3])
end

function SpawnNewBuff(data, index)
	local BuffCon = Gui.Create(gui)
	{
		Gui.ItemBoxBtn "LBuff"
		{
			Size = Vector2(16,16),
			BackgroundColor = ARGB(255,255,255,255),
			LoadingImage = Gui.AnimatedImage("LobbyUI/loading_ring.tga", 4, 2, 8),
			
			EventMouseEnter = function(sender, e)
				if sender.Loading == false then
					L_ToolTips.FillToolTipsBuffInfoWindow(data,index)
				end
			end,
			EventToolTipsShow = function(sender, e)
				L_ToolTips.ShowToolTipsShowWindow(sender)
			end,
			EventMouseLeave = function(sender, e)
				L_ToolTips.HideToolTipsWindow()
			end,
			
			Skin = Gui.ItemBoxBtnSkin
			{
				NeutralNormalImage = Gui.Image("LobbyUI/persionalInfo/buff/buff_ammo_up_60.dds",Vector4(0, 0, 0, 0)),
				NeutralHoverImage = Gui.Image("LobbyUI/persionalInfo/buff/buff_ammo_up_60.dds",Vector4(0, 0, 0, 0)),
				NeutralSelectedImage = Gui.Image("LobbyUI/persionalInfo/buff/buff_ammo_up_60.dds",Vector4(0, 0, 0, 0)),
				NeutralDisabledImage = Gui.Image("LobbyUI/persionalInfo/buff/buff_ammo_up_60.dds",Vector4(0, 0, 0, 0)),
			}
		},	
	}
	BuffCon.LBuff.Skin = Gui.ItemBoxBtnSkin
	{
		NeutralNormalImage = Gui.Image("LobbyUI/persionalInfo/buff/buff_"..data[1]..".dds",Vector4(0, 0, 0, 0)),
		NeutralHoverImage = Gui.Image("LobbyUI/persionalInfo/buff/buff_"..data[1]..".dds",Vector4(0, 0, 0, 0)),
		NeutralSelectedImage = Gui.Image("LobbyUI/persionalInfo/buff/buff_"..data[1]..".dds",Vector4(0, 0, 0, 0)),
		NeutralDisabledImage = nil,
	}
	return BuffCon
end

function Fill_characterInfo(data)
	MessageBox.CloseWaiter()
	if data.warning then
		MessageBox.ShowWithTimer(1,data.warning)
		ptr_cast(game.CurrentState):Quit()
		return
	end
	character_info_data = data
	local info = data.info
	local news = data.newSimple
	local bufflist = info.buff_list
	local achievement = info.achievement
	
	main_character_window_ui.lb_UserNickName.Visible = true
	main_character_window_ui.lb_UserNickName.Text = lang:GetText("总战斗力：")..info.maxFightNum
	
	local achievementlist = Split(achievement,",")
	
	main_character_window_ui.AcheList1.BackgroundColor = ARGB(0, 255, 255, 255)
	main_character_window_ui.AcheList2.BackgroundColor = ARGB(0, 255, 255, 255)
	main_character_window_ui.AcheList3.BackgroundColor = ARGB(0, 255, 255, 255)
	main_character_window_ui.AcheList4.BackgroundColor = ARGB(0, 255, 255, 255)
	
	for i,v in ipairs(achievementlist) do
		local Skin	
		if v ~="" then
			Skin = Gui.ButtonSkin{BackgroundImage = Gui.Image("LobbyUI/persionalInfo/achieves/acheive"..v..".dds", Vector4(0,0,0,0)),}
			local CanVisible = false
			
			if v == "-1" then
				CanVisible = false
			else
				CanVisible = true
			end
			
			if i == 1 then
				main_character_window_ui.AcheList1.BackgroundColor = ARGB(255, 255, 255, 255)
				main_character_window_ui.AcheList1.Skin = Skin
			elseif i == 2 then
				main_character_window_ui.AcheList2.BackgroundColor = ARGB(255, 255, 255, 255)
				main_character_window_ui.AcheList2.Skin = Skin
			elseif  i == 3 then
				main_character_window_ui.AcheList3.BackgroundColor = ARGB(255, 255, 255, 255)
				main_character_window_ui.AcheList3.Skin = Skin
			elseif i == 4 then
				main_character_window_ui.AcheList4.BackgroundColor = ARGB(255, 255, 255, 255)
				main_character_window_ui.AcheList4.Skin = Skin
			end
		end
	end
	
	main_character_window_ui.buff_layout.Location = Vector2(0,0)
	main_character_window_ui.buff_layout:OnDestroy()
	
	if bufflist then
		buff_count = 0
		for i,v in ipairs(bufflist) do
			buff_count = buff_count + 1
			local buffInfo = SpawnNewBuff(v,i)
			buffInfo.LBuff.Parent = main_character_window_ui.buff_layout
		end
	end
	
	-- if OtherPid <	0 then
		-- L_LobbyMain.LobbyMainWin_Header.buff_layout:OnDestroy()
		
		-- if bufflist then
			-- for i,v in ipairs(bufflist) do
				-- local buffInfo = SpawnNewBuff(v,i)
				-- buffInfo.LBuff.Parent = L_LobbyMain.LobbyMainWin_Header.buff_layout
			-- end
		-- end
	-- end
	
	if main_character_window_ui then
		local success_ratio
		local ration,total,barlong,pbtext,headIcon,headSkin
		local success_num
		local runAway
		local matchrank
		main_character_window_ui.lb_UserLevel_AnoldState.Location = Vector2(145, 33)
		main_character_window_ui.lb_UserLevel_TenState.Location = Vector2(135, 33)
		L_LobbyMain.FillLevel(info.rank,main_character_window_ui,info.exp)	
		
	
		if L_LobbyMain.CharactersInfo_rpc_data then
			matchrank = L_LobbyMain.CharactersInfo_rpc_data.player.matchRank
		end
		print("matchrankmatchrankmatchrankmatchrankmatchrankmatchrank==",info.mateRank)
		if info.mateRank == -1 then
			main_character_window_ui.player11111.Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/pipei/icon_rank00.dds", Vector4(14, 14, 14, 14)),
			}
		elseif	info.mateRank == 0 then
			main_character_window_ui.player11111.Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/pipei/icon_rank01_1X.dds", Vector4(14, 14, 14, 14)),
			}
		elseif	info.mateRank == 1 then
			main_character_window_ui.player11111.Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/pipei/icon_rank01_2X.dds", Vector4(14, 14, 14, 14)),
			}
		elseif	info.mateRank == 2 then
			main_character_window_ui.player11111.Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/pipei/icon_rank01_3X.dds", Vector4(14, 14, 14, 14)),
			}
		elseif	info.mateRank == 3 then
			main_character_window_ui.player11111.Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/pipei/icon_rank02_1X.dds", Vector4(14, 14, 14, 14)),
			}
		elseif	info.mateRank == 4 then
			main_character_window_ui.player11111.Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/pipei/icon_rank02_2X.dds", Vector4(14, 14, 14, 14)),
			}
		elseif	info.mateRank == 5 then
			main_character_window_ui.player11111.Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/pipei/icon_rank02_3X.dds", Vector4(14, 14, 14, 14)),
			}
		elseif	info.mateRank == 6 then
			main_character_window_ui.player11111.Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/pipei/icon_rank03_1X.dds", Vector4(14, 14, 14, 14)),
			}
		elseif	info.mateRank == 7 then
			main_character_window_ui.player11111.Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/pipei/icon_rank03_2X.dds", Vector4(14, 14, 14, 14)),
			}
		elseif	info.mateRank == 8 then
			main_character_window_ui.player11111.Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/pipei/icon_rank03_3X.dds", Vector4(14, 14, 14, 14)),
			}
		elseif	info.mateRank == 9 then
			main_character_window_ui.player11111.Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/pipei/icon_rank04_1X.dds", Vector4(14, 14, 14, 14)),
			}
		elseif	info.mateRank == 10 then
			main_character_window_ui.player11111.Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/pipei/icon_rank04_2X.dds", Vector4(14, 14, 14, 14)),
			}
		elseif	info.mateRank == 11 then
			main_character_window_ui.player11111.Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/pipei/icon_rank04_3X.dds", Vector4(14, 14, 14, 14)),
			}
		elseif	info.mateRank == 12 then
			main_character_window_ui.player11111.Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/pipei/icon_rank05_3X.dds", Vector4(14, 14, 14, 14)),
			}
		end
		 
		main_character_window_ui.player_nickname.Text = info.nickName
				
		headIcon = info.headIcon
		
		main_character_window_ui.head_label.Skin = nil
		if headIcon ~= "null" then
			headSkin = Gui.ButtonSkin{ BackgroundImage = Gui.Image("LobbyUI/persionalInfo/HeadPic/lb_info_image"..headIcon..".dds", Vector4(14, 14, 14, 14)),}
			
			main_character_window_ui.head_label.Skin = headSkin
			
			if OtherPid < 0 then
				L_LobbyMain.LobbyMainWin_Header.img_UserHeadIcon.Skin = headSkin
			end
		end
		
		success_ratio = info.winRate *100
		success_ratio = success_ratio.."%"
		runAway = info.runAwayRate
		runAway = runAway * 100
		runAway = runAway .."%"
		
		main_character_window_ui.player_title.Text = ""
		if info.title ~= "null" then
			main_character_window_ui.player_title.Text = info.title
		end
		
		-- main_character_window_ui.LVip.BackgroundColor = ARGB(0,255,255,255)

		-- if info.isVip == 1 then
			-- main_character_window_ui.LVip.BackgroundColor = ARGB(255,255,255,255)
			-- main_character_window_ui.LVip.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/vip/lb_1_ico_0_big.dds", Vector4(0, 0, 0, 0)),}
		-- elseif info.isVip == 2 then
			-- main_character_window_ui.LVip.BackgroundColor = ARGB(255,255,255,255)
			-- main_character_window_ui.LVip.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/vip/lb_vip_xunlei_ico.dds", Vector4(0, 0, 0, 0)),}
		-- end
		-- main_character_window_ui.ctr_VIP.Visible = true
		main_character_window_ui.ctr_VIP_num.Visible = true
		if info.isVip ~= 0 then
			main_character_window_ui.ctr_VIP.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_bg_0"..info.isVip..".dds", Vector4(0, 0, 0, 0)),}
			main_character_window_ui.ctr_VIP_num.Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_button_0"..info.isVip.."_normal.dds", Vector4(0, 0, 0, 0)),
				HoverImage = Gui.Image("LobbyUI/vip/vip/VIP_button_0"..info.isVip.."_hover.dds", Vector4(0, 0, 0, 0)),
				DownImage = Gui.Image("LobbyUI/vip/vip/VIP_button_0"..info.isVip.."_down.dds", Vector4(0, 0, 0, 0)),
				DisabledImage = Gui.Image("LobbyUI/vip/vip/VIP_button_0"..info.isVip.."_normal.dds", Vector4(0, 0, 0, 0)),
			}
		else
			main_character_window_ui.ctr_VIP.Visible = false
			main_character_window_ui.ctr_VIP_num.Visible = false
		end
		
		success_num = info.gWin.."/"..info.gLose
		main_character_window_ui.SuccessNumContent.Text = success_num
		main_character_window_ui.success_ratio_num.Text = success_ratio
		main_character_window_ui.rank_num.Text = runAway
		main_character_window_ui.gold_num.Text = info.gold
		main_character_window_ui.silver_num.Text = info.silver
		main_character_window_ui.bronze_num.Text = info.bronze
		
		if info.top == 0 then
			main_character_window_ui.PaimingConent.Text = lang:GetText("未进入")
		else
			main_character_window_ui.PaimingConent.Text = info.top
		end
		
		total = info.gold + info.silver + info.bronze
		ration = total/info.total	
		barlong = 303 * ration
		
		if total == 0 then
			barlong = 0
		end
		
		barlong = barlong
		main_character_window_ui.progressbar.Size = Vector2(barlong,12)
		
		pbtext = total
		pbtext = pbtext.."/"
		pbtext = pbtext..info.total
		main_character_window_ui.progress_label.Text = pbtext

		if news then
			local infolist = main_character_window_ui.list_recent_info
			local dateTime = nil
			infolist:DeleteAll()
			local subitem,j
			local count = 0
			local SpareItemCount
			j = 1
			for i,v in ipairs(news) do
				local type = v[1]
				local date = v[2]
				local content = v[4]
				local tipsdata = v[6]
				date = string.sub(date,1,10)
				if type ~= -1 then
					if dateTime ~= date then
						dateTime = date
						subitem = infolist:AddItem(infolist.RootItem)
						subitem:SetText(0,"  "..date)
						subitem.BGSkin = Skin.ListItemSkin_Black
						subitem.CanSelect = false
						subitem.FontSize = 18
						subitem.TextColor = ARGB(255,255,211,78)				
						subitem.ToolTipText = 0
						
						subitem = infolist:AddItem(infolist.RootItem)	
						subitem:SetText(0,"  "..content)
						print("content = "..content)
						if count %2 == 0 then
							subitem.BGSkin = Skin.ListItemSkin_Double
						else
							subitem.BGSkin = Skin.ListItemSkin_Single
						end
						
						subitem.CanSelect = false
						subitem.FontSize = 14
						subitem.TextColor = ARGB(255, 215, 232, 227)
						if type == 0 then
							subitem.ToolTipText = 0
						else						
							subitem.ToolTipText = j
						end
						count = count + 1
					else
						subitem = infolist:AddItem(infolist.RootItem)	
						subitem:SetText(0,"  "..content)
						print("content = "..content)
						if count %2 == 0 then
							subitem.BGSkin = Skin.ListItemSkin_Double
						else
							subitem.BGSkin = Skin.ListItemSkin_Single
						end
						
						subitem.CanSelect = false
						subitem.FontSize = 14
						subitem.TextColor = ARGB(255, 215, 232, 227)
						
						if type == 0 then
							subitem.ToolTipText = 0
						else						
							subitem.ToolTipText = j
						end
						
						count = count + 1
					end
					
					tipsData[j] = v
					j = j + 1
				end
			end
			
			SpareItemCount = 10 - j
			
			if SpareItemCount > 0 then
			
				for i = j,8 do
					local item = infolist:AddItem(infolist.RootItem)
					item.CanSelect = false
					if i %2 == 0 then
						item.BGSkin = Skin.ListItemSkin_Single
					else
						item.BGSkin = Skin.ListItemSkin_Double
					end
					item.ToolTipText = 0
				end
			end
		end
	end
end

function ShowWhichWin(win_parent, which)
	if which == 0 then
		if not main_character_window_ui then
			main_character_window_ui = Gui.Create(win_parent)(main_character_window)
			main_character_window_ui["tab_btn_1"].PushDown = true
			characters_tab_event()
		else
			main_character_window_ui.ctrl_character_main.Parent = win_parent
		end
		if not main_select_window_ui then
			main_select_window_ui = Gui.Create(win_parent)(main_select_window)
		else
			main_select_window_ui.ctrl_main_select_window.Parent = win_parent
		end
		GetLevelData()
		local args
		if OtherPid <  0  then 
			args = {uid = state:GetUserId(),pid = state:GetCharacterId(),name=""}
		else
			rpc.safecall("character_list", {pid = OtherPid}, L_LobbyMain.FillCharacterClass)
			args = {uid = OtherUid,pid = OtherPid,name=MyName}
		end
		rpc.safecall("personal_info",args,Fill_characterInfo)
	elseif which == 1 then
		if not main_report_window_ui then
			main_report_window_ui = Gui.Create(root_ui)(main_report_window)
		else
			main_report_window_ui.ctrl_main_report_window.Parent = root_ui
		end
		if main_select_window_ui then
			main_select_window_ui.ctrl_main_select_window.Parent = root_ui
		end
		local args 
		if OtherPid < 0 then
			args = {pid = state:GetCharacterId()}			
		else
			args = {pid = OtherPid,name=MyName}
		end
		rpc.safecall("character_data",args,Fill_characterReport)
	elseif which == 2 then
		if not main_highlight_window_ui then
			main_highlight_window_ui = Gui.Create(root_ui)(main_highlight_window)
		else
			main_highlight_window_ui.ctrl_main_highlight_window.Parent = root_ui
		end
		if main_select_window_ui then
			main_select_window_ui.ctrl_main_select_window.Parent = root_ui
		end
		if OtherPid < 0 then
			args = {pid = state:GetCharacterId()}			
		else
			args = {pid = OtherPid,name=MyName}
		end
		rpc.safecall("character_data",args,Get_characterReport)		
	elseif which == 3 then
		if main_general_achievement_window_ui then
			main_general_achievement_window_ui.ctrl_general_achievement_window.Parent = root_ui
		end				
		if main_select_window_ui then
			main_select_window_ui.ctrl_main_select_window.Parent = root_ui
		end
	elseif which == 4 then
		if main_task_achievement_window_ui then
			main_task_achievement_window_ui.ctrl_task_achievement_window.Parent = root_ui
		end
		if main_select_window_ui then
			main_select_window_ui.ctrl_main_select_window.Parent = root_ui
		end
	elseif which == 5 then
		if main_character_achievement_window_ui then
			main_character_achievement_window_ui.ctrl_character_achievement_window.Parent = root_ui
			main_character_achievement_window_ui["tab_btn_1"].PushDown = true
			characters_achievement_tab_event()
		end 
		if main_select_window_ui then
			main_select_window_ui.ctrl_main_select_window.Parent = root_ui
		end
	end
end

----得到等级数据---------
function GetLevelData()
	rpc.safecall("rank_list", nil,
	function (data)
		if data then
			Level_data = data.rank
		end
	end)
end

function AchdataCheck()
	local pidstr = nil	
	pidstr = Getpidstr()
	
	if character_pages_info[pidstr] == nil then
		character_pages_info[pidstr] = {1,1}
	end
	
	if characterinfo_pages_info[pidstr] == nil then
		characterinfo_pages_info[pidstr] = {}
		
		for i = 1,10 do
			characterinfo_pages_info[pidstr][i] = {1,1}
		end
	end
end

----逻辑,事件处理
function logic()
	report_limit[lang:GetText("使用次数")] ={300,600,1000,2000,lang:GetText("次")}
	report_limit[lang:GetText("杀人数")] ={500,1000,2000,4000,lang:GetText("人")} 
	report_limit[lang:GetText("死亡数")] ={500,1000,2000,4000,lang:GetText("次")}
	report_limit[lang:GetText("赏金击杀数")] ={100,200,400,800,lang:GetText("次")} 
	report_limit[lang:GetText("复仇次数")] ={100,200,400,800,lang:GetText("次")} 
	report_limit[lang:GetText("助攻次数")] ={200,400,800,1600,lang:GetText("次")}
	report_limit[lang:GetText("刀杀次数")] ={200,400,800,1600,lang:GetText("次")}
	
	highLight_limit[lang:GetText("最大爆头数")] = {10,20,40,80,lang:GetText("人")}
	highLight_limit[lang:GetText("最大连杀数")] = {20,40,80,160,lang:GetText("人")}
	highLight_limit[lang:GetText("最大治疗量")] = {500,1000,2000,4000,lang:GetText("生命")}
	highLight_limit[lang:GetText("最大破坏力")] = {500,1000,2000,4000,lang:GetText("伤害")}
	highLight_limit[lang:GetText("最长存活时间")] = {150,300,600,1200,lang:GetText("秒")}
	highLight_limit[lang:GetText("本场最强次数")] = {50,100,200,400,lang:GetText("次")}
	
	if main_character_window_ui then
		
		------------修改个人信息------------------------------------
		main_character_window_ui.bt_change_persionalInfo.EventClick = function()
			if not edit_persional_win then
				--edit_persional_win_ui = Gui.Create(root_ui)(main_edit_persional_window)
				edit_persional_win = ModalWindow.GetNew()
				edit_persional_win.root.Size = Vector2(919,695)
				edit_persional_win.AllowEscToExit = true
				edit_persional_win_ui.ctrl_main_edit_persional_window.Parent = edit_persional_win.root
			end
			local args
			
			if OtherPid <0 then
				args = {pid = state:GetCharacterId(),type = 1,page = 1}
			else
				args = {pid = OtherPid,type = 1,page = 1}
			end
			NowHeadPage = 1
			rpc.safecall("personal_edit_list",args,Fill_HeadInfo)
		end
		
		main_character_window_ui.head_label.EventClick = function()			
			if  OtherPid <0 then
				if not edit_persional_win then
					--edit_persional_win_ui = Gui.Create(root_ui)(main_edit_persional_window)
					edit_persional_win = ModalWindow.GetNew()
					edit_persional_win.root.Size = Vector2(919,695)
					edit_persional_win.AllowEscToExit = true
					edit_persional_win_ui.ctrl_main_edit_persional_window.Parent = edit_persional_win.root
				end
				
				local args
			
				if OtherPid <0 then
					args = {pid = state:GetCharacterId(),type = 1,page = 1}
				else
					args = {pid = OtherPid,type = 1,page = 1}
				end
				NowHeadPage = 1
				rpc.safecall("personal_edit_list",args,Fill_HeadInfo)
			end
		end
		
		main_character_window_ui.btn_Close.EventClick = function()
			Hide()
			L_LobbyMain.LobbyMainWin_Foot.btn_WarZone.PushDown = true
			L_WarZone.Show(root_ui)
		end
		
		main_character_window_ui.keep_shot.EventClick = function()
			if main_character_window_ui.keep_shot.Text == lang:GetText("加为好友") and OtherPid > 0 then
				L_Friends.FriendsAdd(nil,main_character_window_ui.player_nickname.Text)
			elseif main_character_window_ui.keep_shot.Text == lang:GetText("保存截图").." " then
				ptr_cast(game.CurrentState):AutoPhoto()
			end
		end
		
		local infolist=main_character_window_ui.list_recent_info
		
		infolist:AddColumn("",700,"kAlignLeftMiddle")

		function infolist.UpdateMouseMove(sender,e)
			local lobby_state = ptr_cast(game.CurrentState)
			if lobby_state and tooltip_window_ui and tooltip_window_ui.ctrl_root then
				local cursor_pos = lobby_state:GetCursorPos()
				local pos = Vector2(cursor_pos.x+25,cursor_pos.y+25)
				ShowToolTipsWindow(pos)
			end
		end
		
		function infolist.EventNodeMouseEnter(sender,e)
			local item
			local index
			item = e.Item
			
			if item then
				index = item.ToolTipText + 0
				if index ~= 0 then
					FillToolTipsWindow(tipsData[index],1)
				end
			end
		end
		
		function infolist.EventNodeMouseLeave(sender,e)
			HideToolTipsWindow()
		end
	end
	
	if main_report_window_ui then
		main_report_window_ui.game_time:AddItem(lang:GetText("使用次数"))
		main_report_window_ui.game_time:AddItem(lang:GetText("杀人数"))
		main_report_window_ui.game_time:AddItem(lang:GetText("死亡数"))
		main_report_window_ui.game_time:AddItem(lang:GetText("赏金击杀数"))
		main_report_window_ui.game_time:AddItem(lang:GetText("复仇次数"))
		main_report_window_ui.game_time:AddItem(lang:GetText("助攻次数"))
		main_report_window_ui.game_time:AddItem(lang:GetText("刀杀次数"))
		main_report_window_ui.game_time.SelectedIndex = 0
		
		function main_report_window_ui.game_time:EventItemSelected(sender,e)
			local index = self.SelectedIndex	
			Fill_characterReport(nil)			
		end
		
		main_report_window_ui.btn_Close.EventClick = function()
			Hide()
			L_LobbyMain.LobbyMainWin_Foot.btn_WarZone.PushDown = true
			L_WarZone.Show(root_ui)
		end
		
		main_report_window_ui.keep_shot.EventClick = function()
			if main_report_window_ui.keep_shot.Text == lang:GetText("加为好友") and OtherPid > 0 then
				L_Friends.FriendsAdd(nil,main_character_window_ui.player_nickname.Text)
			elseif main_report_window_ui.keep_shot.Text == lang:GetText("保存截图").." " then
				ptr_cast(game.CurrentState):AutoPhoto()
			end
		end
	end
	
	if main_highlight_window_ui then
		main_highlight_window_ui.game_time:AddItem(lang:GetText("最大爆头数"))
		main_highlight_window_ui.game_time:AddItem(lang:GetText("最大连杀数"))
		main_highlight_window_ui.game_time:AddItem(lang:GetText("最大治疗量"))
		main_highlight_window_ui.game_time:AddItem(lang:GetText("最大破坏力"))
		main_highlight_window_ui.game_time:AddItem(lang:GetText("最长存活时间"))
		main_highlight_window_ui.game_time:AddItem(lang:GetText("本场最强次数"))
		main_highlight_window_ui.game_time.SelectedIndex = 0
		
		main_highlight_window_ui.btn_Close.EventClick = function()
			Hide()
			L_LobbyMain.LobbyMainWin_Foot.btn_WarZone.PushDown = true
			L_WarZone.Show(root_ui)
		end
		
		function main_highlight_window_ui.game_time:EventItemSelected(sender,e)
			local index = self.SelectedIndex
			Fill_HightLight()
		end
		
		main_highlight_window_ui.keep_shot.EventClick = function()
			if main_highlight_window_ui.keep_shot.Text == lang:GetText("加为好友") and OtherPid > 0 then
				L_Friends.FriendsAdd(nil,main_character_window_ui.player_nickname.Text)
			elseif main_highlight_window_ui.keep_shot.Text == lang:GetText("保存截图").." " then
				ptr_cast(game.CurrentState):AutoPhoto()
			end
		end
	end
	
	
	if main_general_achievement_window_ui then
		main_general_achievement_window_ui.btn_Close.EventClick = function()
			Hide()
			L_LobbyMain.LobbyMainWin_Foot.btn_WarZone.PushDown = true
			L_WarZone.Show(root_ui)
		end
		
		main_general_achievement_window_ui.keep_shot.EventClick = function()
			if main_general_achievement_window_ui.keep_shot.Text == lang:GetText("加为好友") and OtherPid > 0 then
				L_Friends.FriendsAdd(nil,main_character_window_ui.player_nickname.Text)
			elseif main_general_achievement_window_ui.keep_shot.Text == lang:GetText("保存截图").." " then
				ptr_cast(game.CurrentState):AutoPhoto()
			end
		end
		
		main_general_achievement_window_ui.m_AcheInfoLeft.EventClick = function()		
			local pidstr = nil	
			pidstr = Getpidstr()
			
			character_pages_info[pidstr][1] = character_pages_info[pidstr][1] - 1
			
			if character_pages_info[pidstr][1] <= 1 then
				character_pages_info[pidstr][1] = 1
			end
			
			local args 
				
			if OtherPid < 0 then
				args = {pid = state:GetCharacterId(),type = 1,characterid = 1,page = character_pages_info[pidstr][1]}			
				rpc.safecall("player_achievement",args,Fill_General_achievement)
			else
				args = {pid = OtherPid,type = 1,characterid = 1,page = character_pages_info[pidstr][1]}	
				rpc.safecall("player_achievement",args,Fill_General_achievement)
			end
		end
		
		main_general_achievement_window_ui.m_AcheInfoRight.EventClick = function()
			local pidstr = nil	
			pidstr = Getpidstr()
			
			character_pages_info[pidstr][1] = character_pages_info[pidstr][1] + 1
			
			if character_pages_info[pidstr][1] >= character_pages_info[pidstr][2] then
				character_pages_info[pidstr][1] = character_pages_info[pidstr][2]
			end
			
			local args 
				
			if OtherPid < 0 then
				args = {pid = state:GetCharacterId(),type = 1,characterid = 1,page = character_pages_info[pidstr][1]}			
				rpc.safecall("player_achievement",args,Fill_General_achievement)
			else
				args = {pid = OtherPid,type = 1,characterid = 1,page = character_pages_info[pidstr][1]}	
				rpc.safecall("player_achievement",args,Fill_General_achievement)
			end
		end
		
		main_general_achievement_window_ui.BJump.EventClick = function()
			local jumppage = tonumber(main_general_achievement_window_ui.tbox_PassWord.Text)
			
			if not jumppage then
				return
			end
			
			jumppage = math.floor(jumppage)
			
			if jumppage < 1 then
				jumppage = 1
			end
			
			local pidstr = nil	
			pidstr = Getpidstr()
			
			if jumppage > character_pages_info[pidstr][2] then
				jumppage = character_pages_info[pidstr][2]
			end
			
			main_general_achievement_window_ui.tbox_PassWord.Text = jumppage
			
			character_pages_info[pidstr][1] = jumppage
			
			local args 
				
			if OtherPid < 0 then
				args = {pid = state:GetCharacterId(),type = 1,characterid = 1,page = character_pages_info[pidstr][1]}			
				rpc.safecall("player_achievement",args,Fill_General_achievement)
			else
				args = {pid = OtherPid,type = 1,characterid = 1,page = character_pages_info[pidstr][1]}	
				rpc.safecall("player_achievement",args,Fill_General_achievement)
			end
		end
		
	end
	
	if main_task_achievement_window_ui then
		main_task_achievement_window_ui.btn_Close.EventClick = function()
			Hide()
			L_LobbyMain.LobbyMainWin_Foot.btn_WarZone.PushDown = true
			L_WarZone.Show(root_ui)
		end
	end
	
	
	if main_character_achievement_window_ui then
	
		main_character_achievement_window_ui.keep_shot.EventClick = function()
			if main_character_achievement_window_ui.keep_shot.Text == lang:GetText("加为好友") and OtherPid > 0 then
				L_Friends.FriendsAdd(nil,main_character_window_ui.player_nickname.Text)
			elseif main_character_achievement_window_ui.keep_shot.Text == lang:GetText("保存截图").." " then
				ptr_cast(game.CurrentState):AutoPhoto()
			end
		end
		
		main_character_achievement_window_ui.btn_Close.EventClick = function()
			Hide()
			L_LobbyMain.LobbyMainWin_Foot.btn_WarZone.PushDown = true
			L_WarZone.Show(root_ui)
		end
		
		main_character_achievement_window_ui.m_AcheInfoLeft.EventClick = function()
			local pidstr = nil	
			pidstr = Getpidstr()
			
			characterinfo_pages_info[pidstr][current_select_character][1] = characterinfo_pages_info[pidstr][current_select_character][1] - 1
			
			if characterinfo_pages_info[pidstr][current_select_character][1] <= 1 then
				characterinfo_pages_info[pidstr][current_select_character][1] = 1
			end
			
			FillCharacterAchievement()
		end
		
		main_character_achievement_window_ui.m_AcheInfoRight.EventClick = function()
			local pidstr = nil	
			pidstr = Getpidstr()
			
			characterinfo_pages_info[pidstr][current_select_character][1] = characterinfo_pages_info[pidstr][current_select_character][1] + 1
			
			if characterinfo_pages_info[pidstr][current_select_character][1] >= characterinfo_pages_info[pidstr][current_select_character][2] then
				characterinfo_pages_info[pidstr][current_select_character][1] = characterinfo_pages_info[pidstr][current_select_character][2]
			end
			
			FillCharacterAchievement()
		end
		
		main_character_achievement_window_ui.BJump.EventClick = function()	
			local pidstr = nil	
			pidstr = Getpidstr()
			
			local jumppage = tonumber(main_character_achievement_window_ui.tbox_PassWord.Text)
			local currentPage = characterinfo_pages_info[pidstr][current_select_character][1]
			local totalPage = characterinfo_pages_info[pidstr][current_select_character][2]
						
			if not jumppage then
				return
			end
			
			jumppage = math.floor(jumppage)
			
			if jumppage < 1  then
				jumppage = 1
			end
			
			if jumppage > totalPage then
				jumppage = totalPage
			end
			
			characterinfo_pages_info[pidstr][current_select_character][1] = jumppage
			
			main_character_achievement_window_ui.tbox_PassWord.Text = jumppage
			
			FillCharacterAchievement()
		end
		
	end

	if main_select_window_ui then
	
		main_select_window_ui.cbx_Mission:AddItem(lang:GetText("一般成就"))
		main_select_window_ui.cbx_Mission:AddItem(lang:GetText("角色成就"))
		main_select_window_ui.cbx_Mission.SelectedIndex = 0
		
		function main_select_window_ui.cbx_Mission:EventClick(sender,e)
			local index = self.SelectedIndex
			
			main_select_window_ui.cbx_Mission.PushDown = true
			main_select_window_ui.btn_Baseinfo.PushDown = false
			main_select_window_ui.btn_Report.PushDown = false
			main_select_window_ui.btn_HighlightPoint.PushDown = false
			
			Hide()
			
			local pidstr = nil	
			pidstr = Getpidstr()
	
			AchdataCheck()
			
			if index == 0 then
				if main_general_achievement_window_ui then
					main_general_achievement_window_ui.ctrl_general_achievement_window.Parent = root_ui
				end				
				
				current_state = 3
				
				
				local args 
				
				if OtherPid < 0 then
					args = {pid = state:GetCharacterId(),type = 1,characterid = 1,page = character_pages_info[pidstr][1]}			
					rpc.safecall("player_achievement",args,Fill_General_achievement)
				else
					args = {pid = OtherPid,type = 1,characterid = 1,page = character_pages_info[pidstr][1]}
					rpc.safecall("player_achievement",args,Fill_General_achievement)
				end
				
			elseif index == 1 then

				if main_character_achievement_window_ui then
					main_character_achievement_window_ui.ctrl_character_achievement_window.Parent = root_ui
				end				
				current_state = 5
					
				FillCharacterAchievement()
			end
			
			if main_select_window_ui then
				main_select_window_ui.ctrl_main_select_window.Parent = root_ui
			end			
		end
		
		function main_select_window_ui.cbx_Mission:EventItemSelected(sender, e)
			local index = self.SelectedIndex
			main_select_window_ui.cbx_Mission.PushDown = true
			
			local pidstr = nil	
			pidstr = Getpidstr()
	
			AchdataCheck()
			
			Hide()
			
			if index == 0 then
				if main_general_achievement_window_ui then
					main_general_achievement_window_ui.ctrl_general_achievement_window.Parent = root_ui
				end
				current_state = 3
				
				local args 
				
				if OtherPid < 0 then
					args = {pid = state:GetCharacterId(),type = 1,characterid = 1,page = character_pages_info[pidstr][1]}			
					rpc.safecall("player_achievement",args,Fill_General_achievement)
				else
					args = {pid = OtherPid,type = 1,characterid = 1,page = character_pages_info[pidstr][1]}
					rpc.safecall("player_achievement",args,Fill_General_achievement)
				end
				
			elseif index == 1 then
				if main_character_achievement_window_ui then
					main_character_achievement_window_ui.ctrl_character_achievement_window.Parent = root_ui
				end
				
				current_state = 5
				
				FillCharacterAchievement()
			end
			
			if main_select_window_ui then
				main_select_window_ui.ctrl_main_select_window.Parent = root_ui
			end
		end
		
		---------基本信息按键处理---------------
		main_select_window_ui.btn_Baseinfo.EventClick = function()
			main_select_window_ui.btn_Baseinfo.PushDown = true
			main_select_window_ui.btn_Report.PushDown = false
			main_select_window_ui.btn_HighlightPoint.PushDown = false
			main_select_window_ui.cbx_Mission.PushDown = false
			
			Hide()
			
			current_state = 0
			
			if main_character_window_ui then
				main_character_window_ui.ctrl_character_main.Parent = root_ui
			end
			
			if main_select_window_ui then
				main_select_window_ui.ctrl_main_select_window.Parent = root_ui
			end
			L_PersonalInfo.SynchronousClassButton()
			
			local args 
				
			if OtherPid < 0 then
				args = {uid = state:GetUserId(),pid = state:GetCharacterId(),name=""}			
				L_LobbyMain.FillClassBag(ptr_cast(game.CurrentState):GetCharacterId(), L_LobbyMain.current_choose_class)
				rpc.safecall("personal_info",args,Fill_characterInfo)
			else
				L_LobbyMain.FillClassBag(OtherPid, L_LobbyMain.current_choose_class)
				args = {uid = -1,pid = OtherPid,name=""}
				rpc.safecall("personal_info",args,Fill_characterInfo)
			end
		end
		
		---------表现报告按键处理-------------------
		main_select_window_ui.btn_Report.EventClick = function()
			main_select_window_ui.btn_Baseinfo.PushDown = false
			main_select_window_ui.btn_Report.PushDown = true
			main_select_window_ui.btn_HighlightPoint.PushDown = false
			main_select_window_ui.cbx_Mission.PushDown = false
			
			Hide()
			
			current_state = 1
			
			if not main_report_window_ui then
				main_report_window_ui = Gui.Create(root_ui)(main_report_window)
			else
				main_report_window_ui.ctrl_main_report_window.Parent = root_ui
			end
			
			if main_select_window_ui then
				main_select_window_ui.ctrl_main_select_window.Parent = root_ui
			end
			
			local args 
			
			if OtherPid < 0 then
				args = {pid = state:GetCharacterId()}			
			else
				args = {pid = OtherPid,name=MyName}
			end
		
			rpc.safecall("character_data",args,Fill_characterReport)
		end
		
		--------------精彩时刻按键处理-----------------------------
		main_select_window_ui.btn_HighlightPoint.EventClick = function()
			main_select_window_ui.btn_Baseinfo.PushDown = false
			main_select_window_ui.btn_Report.PushDown = false
			main_select_window_ui.btn_HighlightPoint.PushDown = true
			main_select_window_ui.cbx_Mission.PushDown = false
			
			Hide()
			
			current_state = 2
			
			if not main_highlight_window_ui then
				main_highlight_window_ui = Gui.Create(root_ui)(main_highlight_window)
			else
				main_highlight_window_ui.ctrl_main_highlight_window.Parent = root_ui
			end
			
			if main_select_window_ui then
				main_select_window_ui.ctrl_main_select_window.Parent = root_ui
			end
			
			
			if OtherPid < 0 then
				args = {pid = state:GetCharacterId()}			
			else
				args = {pid = OtherPid,name=MyName}
			end
				
			rpc.safecall("character_data",args,Get_characterReport)
			
		end		
	end
	

	if edit_persional_win_ui then
		edit_persional_win_ui.MyAchievement2.EventMouseEnter = function(Sender,e)
			if Select_Drag_label  and Select_Drag_Skin then
				local Skin = nil
				Skin = Gui.ButtonSkin{BackgroundImage = Gui.Image("LobbyUI/persionalInfo/achieves/acheiveabc.dds", Vector4(14,14,14,14)),}
										
				for i = 1,4 do
					if SelectAchievementArray[i] == Select_Drag_label then
						SelectAchievementArray[i] = -1
						
						if i == 1 then
							edit_persional_win_ui.MyAchievement2.Skin = Skin
						elseif i == 2 then
							edit_persional_win_ui.MyAchievement3.Skin = Skin
						elseif i == 3 then
							edit_persional_win_ui.MyAchievement4.Skin = Skin
						elseif i == 4 then
							edit_persional_win_ui.MyAchievement5.Skin = Skin
						end
					end
				end
				
				Sender.Skin = Select_Drag_Skin
				SelectAchievementArray[1] = Select_Drag_label
				Select_Drag_Skin = nil
				Select_Drag_label = nil
			end
		end
		
		edit_persional_win_ui.MyAchievement3.EventMouseEnter = function(Sender,e)
			if Select_Drag_label  and Select_Drag_Skin then
				local Skin = nil
				Skin = Gui.ButtonSkin{BackgroundImage = Gui.Image("LobbyUI/persionalInfo/achieves/acheiveabc.dds", Vector4(14,14,14,14)),}
										
				for i = 1,4 do
					if SelectAchievementArray[i] == Select_Drag_label then
						SelectAchievementArray[i] = -1
						
						if i == 1 then
							edit_persional_win_ui.MyAchievement2.Skin = Skin
						elseif i == 2 then
							edit_persional_win_ui.MyAchievement3.Skin = Skin
						elseif i == 3 then
							edit_persional_win_ui.MyAchievement4.Skin = Skin
						elseif i == 4 then
							edit_persional_win_ui.MyAchievement5.Skin = Skin
						end
					end
				end
				
				Sender.Skin = Select_Drag_Skin
				SelectAchievementArray[2] = Select_Drag_label
				Select_Drag_Skin = nil
				Select_Drag_label = nil
			end
		end
		
		edit_persional_win_ui.MyAchievement4.EventMouseEnter = function(Sender,e)
			if Select_Drag_label  and Select_Drag_Skin then
				local Skin = nil
				Skin = Gui.ButtonSkin{BackgroundImage = Gui.Image("LobbyUI/persionalInfo/achieves/acheiveabc.dds", Vector4(14,14,14,14)),}
										
				for i = 1,4 do
					if SelectAchievementArray[i] == Select_Drag_label then
						SelectAchievementArray[i] = -1
						
						if i == 1 then
							edit_persional_win_ui.MyAchievement2.Skin = Skin
						elseif i == 2 then
							edit_persional_win_ui.MyAchievement3.Skin = Skin
						elseif i == 3 then
							edit_persional_win_ui.MyAchievement4.Skin = Skin
						elseif i == 4 then
							edit_persional_win_ui.MyAchievement5.Skin = Skin
						end
					end
				end
				
				Sender.Skin = Select_Drag_Skin
				SelectAchievementArray[3] = Select_Drag_label
				Select_Drag_Skin = nil
				Select_Drag_label = nil
			end
		end
		
		edit_persional_win_ui.MyAchievement5.EventMouseEnter = function(Sender,e)
			if Select_Drag_label  and Select_Drag_Skin then
				local Skin = nil
				Skin = Gui.ButtonSkin{BackgroundImage = Gui.Image("LobbyUI/persionalInfo/achieves/acheiveabc.dds", Vector4(14,14,14,14)),}
										
				for i = 1,4 do
					if SelectAchievementArray[i] == Select_Drag_label then
						SelectAchievementArray[i] = -1
						
						if i == 1 then
							edit_persional_win_ui.MyAchievement2.Skin = Skin
						elseif i == 2 then
							edit_persional_win_ui.MyAchievement3.Skin = Skin
						elseif i == 3 then
							edit_persional_win_ui.MyAchievement4.Skin = Skin
						elseif i == 4 then
							edit_persional_win_ui.MyAchievement5.Skin = Skin
						end
					end
				end
				
				Sender.Skin = Select_Drag_Skin
				SelectAchievementArray[4] = Select_Drag_label
				Select_Drag_Skin = nil
				Select_Drag_label = nil
			end
		end
		
		edit_persional_win_ui.m_AcheLeft.EventClick = function(Sender,e)
			local current_page,Pagetype = 0,0,0
			local totalPage = 0
			local prePage = -1
			
			if current_achievement == 1 then
				prePage = current_gen_achievement_page
				current_gen_achievement_page = current_gen_achievement_page - 1
				current_page = current_gen_achievement_page
				totalPage = total_gen_achievement_page
				Pagetype = 3
			elseif current_achievement == 3 then
				prePage = current_character_achievement_page
				current_character_achievement_page = current_character_achievement_page - 1
				current_page = current_character_achievement_page
				totalPage = total_character_achievement_page
				Pagetype = 4
			end
		
			if current_page <= 1 then
				current_page = 1
			end
			
			if current_achievement == 1 then
				current_gen_achievement_page = current_page
			elseif current_achievement == 3 then
				current_character_achievement_page = current_page
			end
			
			if prePage ~= current_page then
				local args
				
				if OtherPid <0 then
					args = {pid = state:GetCharacterId(),type = Pagetype,page = current_page}
				else
					args = {pid = OtherPid,type = Pagetype,page = current_page}
				end
				
				rpc.safecall("personal_edit_list",args,Fill_Achievement)
			end
		end
		
		edit_persional_win_ui.m_AcheRight.EventClick = function()
			local current_page,Pagetype = 0,0
			local totalPage = 0
			local prePage = -1
			
			if current_achievement == 1 then
				prePage = current_gen_achievement_page
				current_gen_achievement_page = current_gen_achievement_page + 1
				current_page = current_gen_achievement_page
				totalPage = total_gen_achievement_page
				Pagetype = 3
			elseif current_achievement == 3 then
				prePage = current_character_achievement_page
				current_character_achievement_page = current_character_achievement_page + 1
				current_page = current_character_achievement_page
				totalPage = total_character_achievement_page
				Pagetype = 4
			end
		
			if current_page >= totalPage then
				current_page = totalPage
			end
			
			if current_achievement == 1 then
				current_gen_achievement_page = current_page
			elseif current_achievement == 3 then
				current_character_achievement_page = current_page
			end
			
			if prePage ~= current_page then
				local args
				
				if OtherPid <0 then
					args = {pid = state:GetCharacterId(),type = Pagetype,page = current_page}
				else
					args = {pid = OtherPid,type = Pagetype,page = current_page}
				end
				
				rpc.safecall("personal_edit_list",args,Fill_Achievement)
			end
		end
		
		edit_persional_win_ui.bgeneral_achievement.EventClick = function()
			current_achievement = 1
			local args
			if OtherPid <0 then
				args = {pid = state:GetCharacterId(),type = 3,page = current_gen_achievement_page}
			else
				args = {pid = OtherPid,type = 3,page = current_gen_achievement_page}
			end
			rpc.safecall("personal_edit_list",args,Fill_Achievement)
		end
		
		edit_persional_win_ui.bcharacter_achievement.EventClick = function()
			current_achievement = 3
			local args
			if OtherPid <0 then
				args = {pid = state:GetCharacterId(),type = 4,page = current_character_achievement_page}
			else
				args = {pid = OtherPid,type = 4,page = current_character_achievement_page}
			end
			rpc.safecall("personal_edit_list",args,Fill_Achievement)
		end
		
		edit_persional_win_ui.m_Left.EventClick = function()
			local prePage = current_title_page
			current_title_page = current_title_page - 1
			if current_title_page <= 1 then
				current_title_page = 1
			end
			if prePage ~= current_title_page then
				edit_persional_win_ui.DisplayTitContent:OnDestroy()
				local args
				if OtherPid <0 then
					args = {pid = state:GetCharacterId(),type = 2,page = current_title_page}
				else
					args = {pid = OtherPid,type = 2,page = current_title_page}
				end
				rpc.safecall("personal_edit_list",args,Fill_Title)
			end
		end
		
		edit_persional_win_ui.m_Right.EventClick = function()
			local prePage = current_title_page
			current_title_page = current_title_page + 1
			
			if current_title_page >= total_title_page then
				current_title_page = total_title_page
			end
			
			if prePage ~= current_title_page then
				edit_persional_win_ui.DisplayTitContent:OnDestroy()
				
				local args
				
				if OtherPid <0 then
					args = {pid = state:GetCharacterId(),type = 2,page = current_title_page}
				else
					args = {pid = OtherPid,type = 2,page = current_title_page}
				end
				
				rpc.safecall("personal_edit_list",args,Fill_Title)
			end		
		end
		
		edit_persional_win_ui.Cancel.EventClick = function()
			if edit_persional_win then
				edit_persional_win.Close()
				edit_persional_win = nil
			end
			--edit_persional_win_ui.ctrl_main_edit_persional_window.Parent = nil
		end
		
		edit_persional_win_ui.Change_head.PushDown = true
		
		edit_persional_win_ui.Change_head.EventClick = function()
			edit_persional_win_ui.Change_head.PushDown = true
			edit_persional_win_ui.Change_name.PushDown = false
			edit_persional_win_ui.Change_achievement.PushDown = false
			
			edit_persional_win_ui.DisplayHead.Visible = true
			edit_persional_win_ui.DisplayTitle.Visible = false
			edit_persional_win_ui.DisplayAchievement.Visible = false
		end
		
		edit_persional_win_ui.Change_name.EventClick = function()
			
			if edit_persional_win_ui.Change_name.PushDown == false then
				local args
				
				if OtherPid <0 then
					args = {pid = state:GetCharacterId(),type = 2,page = current_title_page}
				else
					args = {pid = OtherPid,type = 2,page = current_title_page}
				end
				rpc.safecall("personal_edit_list",args,Fill_Title)
			end
			
			edit_persional_win_ui.Change_head.PushDown = false
			edit_persional_win_ui.Change_name.PushDown = true
			edit_persional_win_ui.Change_achievement.PushDown = false
			
			edit_persional_win_ui.DisplayHead.Visible = false
			edit_persional_win_ui.DisplayTitle.Visible = true
			edit_persional_win_ui.DisplayAchievement.Visible = false
		end
		
		edit_persional_win_ui.Change_achievement.EventClick = function()
			
			current_achievement = 1
			
			if edit_persional_win_ui.Change_achievement.PushDown == false then
				local args
				
				if OtherPid <0 then
					args = {pid = state:GetCharacterId(),type = 3,page = current_gen_achievement_page}
				else
					args = {pid = OtherPid,type = 3,page = current_gen_achievement_page}
				end
				
				rpc.safecall("personal_edit_list",args,Fill_Achievement)
			end
			
			edit_persional_win_ui.Change_head.PushDown = false
			edit_persional_win_ui.Change_name.PushDown = false
			edit_persional_win_ui.Change_achievement.PushDown = true
			
			edit_persional_win_ui.DisplayHead.Visible = false
			edit_persional_win_ui.DisplayTitle.Visible = false
			edit_persional_win_ui.DisplayAchievement.Visible = true
			
		end
		
		edit_persional_win_ui.Save.EventClick = function()
			local Mytitle = edit_persional_win_ui.MyTitle3.Text
			local Myhead = edit_persional_win_ui.Head.Text
			
			--L_LobbyMain.LobbyMainWin_Header.lb_UserNickName.Text = Mytitle
			
			for i = 1,5 do
				local s = SelectAchievementArray[i]
				if s then
					SelectAchievementIcon = SelectAchievementIcon..s..","
				end
			end
			local args
			
			if OtherPid < 0 then
				args = {uid = state:GetUserId(),pid = state:GetCharacterId(),head = SelectHeadIcon,title = Mytitle,achievementList=SelectAchievementIcon}
				
				SelectAchievementIcon = ""
				
				rpc.safecall("personal_edit_save",args,nil)
				
				args = {uid = state:GetUserId(),pid = state:GetCharacterId(),name=""}
			
				rpc.safecall("personal_info",args,Fill_characterInfo)
			else
				args = {uid = OtherUid,pid = OtherPid,head = SelectHeadIcon,title = Mytitle,achievementList=SelectAchievementIcon}
				
				SelectAchievementIcon = ""
				
				rpc.safecall("personal_edit_save",args,nil)
				
				args = {uid = OtherUid,pid = OtherPid,name=MyName}
			
				rpc.safecall("personal_info",args,Fill_characterInfo)
			end
			
			SelectAchievementArray = {"-1","-1","-1","-1","-1"}
			
			if edit_persional_win then
				edit_persional_win.Close()
				edit_persional_win = nil
			end
		end
	end
end

function InitAnimation()
	main_character_window_ui.AnimNum:AddAnim("num",0.5,1)
	
	for i = 0,5 do
		local box =  Gui.Icon("loading_missile.dds", Vector4(0, 0, 0, 0),Vector4(i/6,0,(i+1)/6,1))	
		main_character_window_ui.AnimNum:AddFrame("num",box,Vector4(0, 0, 0, 0))
	end
	
	main_character_window_ui.AnimNum:ReStart()
	main_character_window_ui.AnimNum:StartAnimation()

end

function Initialize()
	main_character_window_ui = Gui.Create(root_ui)(main_character_window)
	main_character_window_ui["tab_btn_1"].PushDown = true
	characters_tab_event()
	
	main_select_window_ui = Gui.Create(root_ui)(main_select_window)
	main_report_window_ui = Gui.Create(root_ui)(main_report_window)
	main_highlight_window_ui = Gui.Create(root_ui)(main_highlight_window)

	main_general_achievement_window_ui = Gui.Create(root_ui)(main_general_achievement_window)
	main_task_achievement_window_ui = Gui.Create(root_ui)(main_task_achievement_window)
	
	main_character_achievement_window_ui = Gui.Create(root_ui)(main_character_achievement_window)
	main_character_achievement_window_ui["tab_btn_1"].PushDown = true
	characters_achievement_tab_event()

	Hide()
	
	logic()
end

function ShowOtherInit()
	current_state = 0
	
--	L_LobbyMain.HideAll()
	
	L_LobbyMain.InitPersonalInfoRPCInfo()
	lg:SetLobbyModules(12)
	L_LobbyMain.current_chosse_main_page = 12
	
	main_select_window_ui.btn_Baseinfo.PushDown = true
	main_select_window_ui.btn_Report.PushDown = false
	main_select_window_ui.btn_HighlightPoint.PushDown = false
	main_select_window_ui.cbx_Mission.PushDown = false
	
	L_PersonalInfo.SynchronousClassButton()
	L_LobbyMain.FillClassBag(OtherPid, L_LobbyMain.current_choose_class)
	
	main_character_window_ui.keep_shot.Text = lang:GetText("加为好友")
	main_character_window_ui.keep_shot.TextAlign = "kAlignCenterMiddle"
	main_character_window_ui.keep_shot.Skin = Skin.ButtonSkin_ItemBoxBtn
	main_character_window_ui.keep_shot.Enable = true
	
	main_report_window_ui.keep_shot.Text = lang:GetText("加为好友")
	main_report_window_ui.keep_shot.TextAlign = "kAlignCenterMiddle"
	main_report_window_ui.keep_shot.Skin = Skin.ButtonSkin_ItemBoxBtn
	main_report_window_ui.keep_shot.Enable = true
	
	main_highlight_window_ui.keep_shot.Text = lang:GetText("加为好友")
	main_highlight_window_ui.keep_shot.TextAlign = "kAlignCenterMiddle"
	main_highlight_window_ui.keep_shot.Skin = Skin.ButtonSkin_ItemBoxBtn
	main_highlight_window_ui.keep_shot.Enable = true
	
	main_general_achievement_window_ui.keep_shot.Text = lang:GetText("加为好友")
	main_general_achievement_window_ui.keep_shot.TextAlign = "kAlignCenterMiddle"
	main_general_achievement_window_ui.keep_shot.Skin = Skin.ButtonSkin_ItemBoxBtn
	main_general_achievement_window_ui.keep_shot.Enable = true
	
	main_character_achievement_window_ui.keep_shot.Text = lang:GetText("加为好友")
	main_character_achievement_window_ui.keep_shot.TextAlign = "kAlignCenterMiddle"
	main_character_achievement_window_ui.keep_shot.Skin = Skin.ButtonSkin_ItemBoxBtn
	main_character_achievement_window_ui.keep_shot.Enable = true
	
	main_character_window_ui.bt_change_persionalInfo.Enable = false
	main_character_window_ui.ctr_VIP_num.Enable = false
	
	SelectAchievementArray = {"-1","-1","-1","-1","-1"}
end

function ShowPerson(parent_win,pid,name)
	OtherPid = pid
	
	MyName = name
	
	L_LobbyMain.HideAll()
	
	ShowOtherInit()
	
	ShowOther(parent_win)
end

function ShowInit()
	OtherPid = -1
	current_state = 0
	
	main_select_window_ui.btn_Baseinfo.PushDown = true
	main_select_window_ui.btn_Report.PushDown = false
	main_select_window_ui.btn_HighlightPoint.PushDown = false
	main_select_window_ui.cbx_Mission.PushDown = false
			
	main_character_window_ui.keep_shot.Text = lang:GetText("保存截图").." "
	main_character_window_ui.keep_shot.TextAlign = "kAlignRightMiddle"
	main_character_window_ui.keep_shot.Skin = Skin.TakePicSkin
	main_character_window_ui.keep_shot.Enable = true
	
	main_report_window_ui.keep_shot.Text = lang:GetText("保存截图").." "
	main_report_window_ui.keep_shot.TextAlign = "kAlignRightMiddle"
	main_report_window_ui.keep_shot.Skin = Skin.TakePicSkin
	main_report_window_ui.keep_shot.Enable = true
	
	main_highlight_window_ui.keep_shot.Text = lang:GetText("保存截图").." "
	main_highlight_window_ui.keep_shot.TextAlign = "kAlignRightMiddle"
	main_highlight_window_ui.keep_shot.Skin = Skin.TakePicSkin
	main_highlight_window_ui.keep_shot.Enable = true
	
	main_general_achievement_window_ui.keep_shot.Text = lang:GetText("保存截图").." "
	main_general_achievement_window_ui.keep_shot.TextAlign = "kAlignRightMiddle"
	main_general_achievement_window_ui.keep_shot.Skin = Skin.TakePicSkin
	main_general_achievement_window_ui.keep_shot.Enable = true
	
	main_character_achievement_window_ui.keep_shot.Text = lang:GetText("保存截图").." "
	main_character_achievement_window_ui.keep_shot.TextAlign = "kAlignRightMiddle"
	main_character_achievement_window_ui.keep_shot.Skin = Skin.TakePicSkin
	main_character_achievement_window_ui.keep_shot.Enable = true
	
	main_character_window_ui.bt_change_persionalInfo.Enable = true
	main_character_window_ui.ctr_VIP_num.Enable = true
	
	L_TopList.character_bag.root.Size = Vector2(490, 507)
	L_TopList.character_bag.root.Location = Vector2(451, 60)
	L_TopList.character_bag.root.Visible = false
	L_TopList.character_bag.root.Parent = main_character_window_ui.ctrl_character_main
	
	SelectAchievementArray = {"-1","-1","-1","-1","-1"}
end

function Show(parent_win)
	L_LobbyMain.HideAll()
	root_ui = parent_win
	
	ShowInit()
	
	ShowWhichWin(parent_win,current_state)
end

function ShowOther(parent_win)
	root_ui = parent_win
	
	ShowWhichWin(parent_win,current_state)
end

function Hide()
	if DragWindow_ui then
		DragWindow_ui.root.Visible = false
	end
	
	if main_character_window_ui then
		main_character_window_ui.ctrl_character_main.Parent = nil
	end
	
	if main_report_window_ui then
		main_report_window_ui.ctrl_main_report_window.Parent = nil
	end
	
	if main_select_window_ui then
		main_select_window_ui.ctrl_main_select_window.Parent = nil
	end
	
	if main_highlight_window_ui then
		main_highlight_window_ui.ctrl_main_highlight_window.Parent = nil
	end
	
	if edit_persional_win then
		edit_persional_win.Close()
		edit_persional_win = nil
	end
	
	if main_general_achievement_window_ui then
		main_general_achievement_window_ui.ctrl_general_achievement_window.Parent = nil
	end
	
	if main_task_achievement_window_ui then
		main_task_achievement_window_ui.ctrl_task_achievement_window.Parent = nil
	end
	
	if main_character_achievement_window_ui then
		main_character_achievement_window_ui.ctrl_character_achievement_window.Parent = nil
	end
	
	if tooltip_window_ui then
		tooltip_window_ui.ctrl_root.Parent = nil
	end
	
	if L_LobbyMain.ui_des_bag.root then
		L_LobbyMain.ui_des_bag.root.Parent = nil
	end
end

function HidePopupWindow()
	if main_popup_window_ui then
		main_popup_window_ui.ctrl_main_popup_window.Parent = nil
	end
end

function Finalize()
	Hide()
end