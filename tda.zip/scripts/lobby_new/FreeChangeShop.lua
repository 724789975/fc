module("L_FreeChangeShop", package.seeall)

--查看奖励
local present_page = 1
local present_list = nil
local present_last_page = 0

match_list = nil
lantu = nil
suipian_a = nil
suipian_b = nil
suipian_c = nil
suipian_hecheng ={}
--查看奖励界面
local view_present_window_ui = nil
local ViewPresent_Window = nil
local buy_and_present_ui = nil
local buy_and_present_Window = nil

price_way = {lang:GetText("勋章"),lang:GetText("复活币"),lang:GetText("能量陨石"),lang:GetText("钛合金石"),lang:GetText("原子硅石")}
--结算方式
unittype_way = {lang:GetText("永久"), lang:GetText("个"), lang:GetText("天"), lang:GetText("C币")}

--购买 赠送好友界面
function show_buy_and_present_window()
	print("=================L_ShoppingMall setup_buy_and_present_window()")
	--创建界面
	--购买初始化
	buy_and_present_ui = ModalWindow.GetNew()
	buy_and_present_ui.root.Size = Vector2(1200, 900)
	buy_and_present_ui.AllowEscToExit = false
	buy_and_present_window_page.ctrl_bg.Parent = buy_and_present_ui.root
	buy_and_present_window_page.lbl_goods_info.VScrollBarWidth = 5
	buy_and_present_window_page.lbl_goods_info.VScrollBarButtonSize = 0.1
	FillBuyAndPresentWindow()
	--界面是否存在
	if buy_and_present_window_page then		
		buy_and_present_window_page.btn_three_days.PushDown = true
		buy_and_present_window_page.btn_senven_days.PushDown = false
		buy_and_present_window_page.btn_thirty_days.PushDown = false
		buy_and_present_window_page.btn_forever.PushDown = false
		FillBuyAndPresentWindow()
		return
	end	
end

function SpawnNewFreeChangeButton()
	local newbutton = Gui.Create(gui)
	{
		Gui.Button "ib_donate"
		{	
			Visible = true,
			Location = Vector2(5,72),
			Size = Vector2(45,24),
			FontSize = 14,
			Text = lang:GetText("赠送"),
			Skin = Skin.ButtonSkin_ItemBoxBtn,
				
			EventClick = function(Sender,e)
				local ibbtn = nil
				local index = 1
				for i = 1, 28 do
					local ibbtn = ptr_cast(view_present_window_ui.ctr_persent:GetChildByIndex(i - 1))
					if Sender.Parent == ibbtn then
						index = i
						break
					end						
				end
				
				if L_LobbyMain.LobbyMainWin.LobbyMain_Root_Parent then
					current_selected_ibtn_index = index
					show_buy_and_present_window()
				end
				
				if buy_and_present_window_page then			
					buy_and_present_window_page.lbl_present_to.Visible = true
					buy_and_present_window_page.cbx_friends_present.Visible = true
					buy_and_present_window_page.lbl_balance_mode.Location = Vector2(248, 6)
					buy_and_present_window_page.btn_front_page.Location = Vector2(323, 7)
					buy_and_present_window_page.lb_page_number.Location = Vector2(346, 6)
					buy_and_present_window_page.btn_next_page.Location = Vector2(408, 7)
					
					buy_and_present_window_page.lbl_spend_point.Text = ""
					buy_and_present_window_page.btn_buy_and_balance.PushDown = false
					buy_and_present_window_page.btn_buy_and_present.Visible = false
					--buy_and_present_window_page.cbox_buy_and_equip.Visible = false
					--buy_and_present_window_page.lbl_buy_and_equip.Visible = false
					buy_and_present_window_page.btn_three_days.PushDown = true
					buy_and_present_window_page.btn_senven_days.PushDown = false
					buy_and_present_window_page.btn_thirty_days.PushDown = false
					buy_and_present_window_page.btn_forever.PushDown = false
					buy_and_present_window_page.btn_buy.Text = lang:GetText("赠送")
					FillPresentWindow()										
				end
			end
		},
	}
	return newbutton
end

function CreatePresentBTN(list,line,index,parent)
	local temp = 0 
	if line > 2 then
		temp = 60
	end
	local BTN =  Gui.Create()
	{
		Gui.ItemBoxBtn "itbtn" 
		{
			Style = "Gui.ItemBoxBtn_ib",
			Size = Vector2(100,100),
			Location = Vector2(106*list,106*line + temp),
			BackgroundColor = ARGB(255, 255, 255, 255),
			BtnLocation = Vector2(20, 73),
			BtnText = lang:GetText("兑换"),
			BtnSize = Vector2(65, 24),
			ItemBtnSkin = Skin.ButtonSkin_ItemBoxBtn_buy,
			IntTag = 0,
			Skin = Gui.ItemBoxBtnSkin
			{
				NeutralNormalImage = Gui.Image("LobbyUI/WarZone/Present/lb_gift_biew_bg2.dds", Vector4(0, 0, 0, 0)),
	--			NeutralHoverImage = Gui.Image("LobbyUI/ShoppingMall/vip_chest/lb_vipgifts_slot_flash.dds", Vector4(0, 0, 0, 0)),
				NeutralSelectedImage = Gui.Image("LobbyUI/WarZone/Present/lb_gift_biew_bg2.dds", Vector4(0, 0, 0, 0)),
				NeutralDisabledImage = Gui.Image("LobbyUI/WarZone/Present/lb_gift_biew_bg2.dds", Vector4(0, 0, 0, 0)),
			},
			
			Gui.Control "vip"
			{
				Size = Vector2(44,32),
				Dock = "kDockLeftTop",
				BackgroundColor = ARGB(255,255,255,255),
				Enable = false,
			},
			
			Padding = Vector4(5,5,5,5),
			
			EventBtnClick = function(sender, e)
				current_selected_ibtn_index = sender.IntTag	
				show_buy_and_present_window()
			end,

			EventMouseEnter = function(sender, e)
				L_ToolTips.FillToolTipsVIPPresent(sender.IntTag	, ViewPresent_Window.root, present_list)
			end,
			EventToolTipsShow = function(sender, e)
				if present_list[sender.IntTag] then
					local loc = sender.Location + sender.Parent.Location + sender.Parent.Parent.Location
					L_ToolTips.ShowToolTipsShowWindow(sender,Vector2(1200, 900), loc)
				end
			end,
			EventMouseLeave = function(sender, e)
				L_ToolTips.HideToolTipsWindow()
			end,
		}
	}
	
	BTN.itbtn.Parent = parent
end

function CreatePresentBTN1(list,line,index,parent)

	local BTN =  Gui.Create()
	{
		Gui.ItemBoxBtn "itbtn" 
		{
			Style = "Gui.ItemBoxBtn_ib",
			Size = Vector2(100,100),
			Location = Vector2(106*list,106*line),
			BackgroundColor = ARGB(255, 255, 255, 255),
			BtnLocation = Vector2(20, 73),
			BtnText = lang:GetText("兑换"),
			BtnSize = Vector2(65, 24),
			ItemBtnSkin = Skin.ButtonSkin_ItemBoxBtn_buy,
			IntTag = 0,
			Skin = Gui.ItemBoxBtnSkin
			{
				NeutralNormalImage = Gui.Image("LobbyUI/WarZone/Present/lb_gift_biew_bg2.dds", Vector4(0, 0, 0, 0)),
	--			NeutralHoverImage = Gui.Image("LobbyUI/ShoppingMall/vip_chest/lb_vipgifts_slot_flash.dds", Vector4(0, 0, 0, 0)),
				NeutralSelectedImage = Gui.Image("LobbyUI/WarZone/Present/lb_gift_biew_bg2.dds", Vector4(0, 0, 0, 0)),
				NeutralDisabledImage = Gui.Image("LobbyUI/WarZone/Present/lb_gift_biew_bg2.dds", Vector4(0, 0, 0, 0)),
			},
			-- Gui.Control "vip"
			-- {
				-- Size = Vector2(44,32),
				-- Dock = "kDockLeftTop",
				-- BackgroundColor = ARGB(255,255,255,255),
				-- Enable = false,
			-- },
			Padding = Vector4(5,5,5,5),
			
			EventBtnClick = function(sender, e)
				current_selected_ibtn_index = sender.IntTag	
				show_buy_and_present_window()
			end,

			EventMouseEnter = function(sender, e)
				L_ToolTips.FillToolTipsVIPPresent(sender.IntTag	, ViewPresent_Window.root, present_list)
			end,
			EventToolTipsShow = function(sender, e)
				if present_list[sender.IntTag] then
					local loc = sender.Location + sender.Parent.Location + sender.Parent.Parent.Location
					L_ToolTips.ShowToolTipsShowWindow(sender,Vector2(1200, 900), loc)
				end
			end,
			EventMouseLeave = function(sender, e)
				L_ToolTips.HideToolTipsWindow()
			end,
		}
	}
	
	BTN.itbtn.Parent = parent
end


function CreatPresentNumCtr(m_parent,num,width,height)
	local n = 0
	local Tep_unm = num
	while Tep_unm > 0 do
		Tep_unm = math.floor(Tep_unm/10)
		n = n + 1
	end
	local ctr_num = Gui.Create()
	{
		Gui.Control "ctr_num_local"
		{
			Size = Vector2(30 + n*12,16),
			BackgroundColor = ARGB(0, 255, 255, 255),
			Location = Vector2(width - 32 - n*12 ,height - 21),
			
			Gui.Control
			{
				Size = Vector2(20,16),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Location = Vector2(0, 0),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_number_X.dds", Vector4(0,0,0,0)),
				},
			},
		},
	}
	while num > 0 do
		Tep_unm = num%10
		local ctr = Gui.Create()
		{
			Gui.Control "ctr_n"
			{
				Size = Vector2(20,16),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Location = Vector2(20 + (n - 1)*12, 0),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_number.dds", Vector4(0,0,0,0),Vector4(Tep_unm/10.0 , 0, (Tep_unm + 1)/10.0,1)),
				}
			},
		}
		ctr.ctr_n.Parent = ctr_num.ctr_num_local
		num = math.floor(num/10)
		n = n - 1
	end
	ctr_num.ctr_num_local.Parent = m_parent
end


view_freeChange_window =
{	
	Gui.Control "ctrl_view_present_window"
	{
		Size = Vector2(981,560 + 60 + 110),
		BackgroundColor = ARGB(0, 255, 255, 255),
		Dock = "kDockCenter",
		Gui.Button "btn_exchange"
		{
			Size = Vector2(76, 124),
			Location = Vector2(155, 15),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/WarZone/Present/lb_pipei_free_normal.dds", Vector4(5, 5, 5, 5)),
				HoverImage = Gui.Image("LobbyUI/WarZone/Present/lb_pipei_free_hover.dds", Vector4(5, 5, 5, 5)),
				DownImage = Gui.Image("LobbyUI/WarZone/Present/lb_pipei_free_down.dds", Vector4(5, 5, 5, 5)),
				DisabledImage = Gui.Image("LobbyUI/WarZone/Present/lb_pipei_free_normal.dds", Vector4(5, 5, 5, 5)),
			},
			PushDown = true,
			EventClick = function(sender, e)
				if sender.PushDown == false then
					view_present_window_ui.btn_exchange.PushDown = true
					view_present_window_ui.btn_exchange1.Visible = true
					view_present_window_ui.btn_match.PushDown = false
					view_present_window_ui.btn_exchange2.Visible = false
				end
			end
		},	
		Gui.Button "btn_match"
		{
			Size = Vector2(76, 124),
			Location = Vector2(155, 138),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/WarZone/Present/lb_pipei_match_normal.dds", Vector4(5, 5, 5, 5)),
				HoverImage = Gui.Image("LobbyUI/WarZone/Present/lb_pipei_match_hover.dds", Vector4(5, 5, 5, 5)),
				DownImage = Gui.Image("LobbyUI/WarZone/Present/lb_pipei_match_down.dds", Vector4(5, 5, 5, 5)),
				DisabledImage = Gui.Image("LobbyUI/WarZone/Present/lb_pipei_match_normal.dds", Vector4(5, 5, 5, 5)),
			},
			PushDown = false,
			EventClick = function()
				rpc.safecall("get_playeritems_by_sysid",{ pid = ptr_cast(game.CurrentState):GetCharacterId(),t = 1},function(data)
					if view_present_window_ui and view_present_window_ui.btn_match.PushDown == false then
						view_present_window_ui.btn_exchange.PushDown = false
						view_present_window_ui.btn_exchange1.Visible = false
						view_present_window_ui.btn_match.PushDown = true
						view_present_window_ui.btn_exchange2.Visible = true
						match_list = data.items
						if match_list[1].playeritemid ~= 0 then
							view_present_window_ui.icon_a2.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/pipei/icon_a2.dds", Vector4(5, 5, 5, 5)),}
						end
						if match_list[2].playeritemid ~= 0 then
							view_present_window_ui.icon_b2.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/pipei/icon_b2.dds", Vector4(5, 5, 5, 5)),}
						end
						if match_list[3].playeritemid ~= 0 then
							view_present_window_ui.icon_c2.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/pipei/icon_c2.dds", Vector4(5, 5, 5, 5)),}
						end
						if match_list[4].playeritemid ~= 0 then
							view_present_window_ui.lantu.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("LobbyUI/pipei/pipei_lantu_box.dds", Vector4(5, 5, 5, 5)),}
						end
						
						if match_list[1].subtype  == 1 then
							suipian_a = match_list[1].playeritemid 
						end
						if match_list[2].subtype == 1 then
							suipian_b = match_list[2].playeritemid 
						end
						if match_list[3].subtype == 1 then
							suipian_c = match_list[3].playeritemid 
						end
						-- end
						if match_list[4].subtype == 2 then
							lantu = match_list[4].playeritemid
						end
						
						if match_list[1].subtype ~= 1  or match_list[2].subtype ~= 1 or  match_list[3].subtype ~= 1  or  match_list[4].subtype ~= 2 then
							view_present_window_ui.compound.Enable = false 
						end
					end
				end)
			end
		},		
		Gui.Control"btn_exchange1"
		{	
			Size = Vector2(557, 551 + 60+ 110),
			BackgroundColor = ARGB(0, 255, 255, 255),
			Visible = true,
			Dock = "kDockCenter",
			-- Skin = Gui.ControlSkin
			-- {
				-- BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/main_bar02.dds", Vector4(10, 10, 10, 10)),
			-- },
		
			Gui.Control
			{
				Size = Vector2(545,540 + 60+ 110),
				Location = Vector2(7,5),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/WarZone/Present/lb_gift_biew_bg1.dds", Vector4(200,104,105,48)),
				},
						
				Gui.Button "bt_view_present_prev"
				{
					Size = Vector2(91,31),
					Location = Vector2(256, 468),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Text = lang:GetText("上一页"),
					TextColor = ARGB(255, 229, 255, 252),
					TextAlign = "kAlignCenterMiddle",
					HighlightTextColor = ARGB(255, 229, 255, 252),

					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_normal.dds", Vector4(0, 0, 0, 0)),
						HoverImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_hover.dds", Vector4(0, 0, 0, 0)),
						DownImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_down.dds", Vector4(0, 0, 0, 0)),
						DisabledImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_disabled.dds", Vector4(0, 0, 0, 0)),
					},
					
					EventClick = function(Sender ,e)
						present_page = present_page - 1
						if present_page < 1 then
							present_page = 1
						end
						local args = {pid = ptr_cast(game.CurrentState):GetCharacterId(),page = present_page}
						rpc.safecall("shop_exchange_list", args, 
						function (data)
							if data.warning then
								MessageBox.ShowWithTimer(1,data.warning)
							else
								present_page = data.page
								present_list = data.items
								--present_last_page = data.is_last_page
								FillViewPresent()
								view_present_window_ui.xunzhang_num.Text = data.chipNum
							end
						end)
					end
				},
				
				Gui.Button "bt_view_present_next"
				{
					Size = Vector2(91,31),
					Location = Vector2(386, 468),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Text = lang:GetText("下一页"),
					TextColor = ARGB(255, 229, 255, 252),
					TextAlign = "kAlignCenterMiddle",
					HighlightTextColor = ARGB(255, 229, 255, 252),

					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_normal.dds", Vector4(0, 0, 0, 0)),
						HoverImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_hover.dds", Vector4(0, 0, 0, 0)),
						DownImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_down.dds", Vector4(0, 0, 0, 0)),
						DisabledImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_disabled.dds", Vector4(0, 0, 0, 0)),
					},
					
					EventClick = function(Sender ,e)
						present_page = present_page + 1
						local args = {pid = ptr_cast(game.CurrentState):GetCharacterId(),page = present_page}
						rpc.safecall("shop_exchange_list", args, 
						function (data)
							if data.warning then
								MessageBox.ShowWithTimer(1,data.warning)
							else
								present_page = data.page
								present_list = data.items
								FillViewPresent()
								view_present_window_ui.xunzhang_num.Text = data.chipNum
							end
						end)
					end
				},
				Gui.Control
				{
					Size = Vector2(20,32),
					Location = Vector2(42, 468 + 60+ 140),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/free_change/medol_s01.dds", Vector4(0,0,0,0)),
					},
				},
				Gui.Label "xunzhang_num"
				{
					Size = Vector2(50, 32),
					Location = Vector2(62, 468 + 60+ 140),
					BackgroundColor = ARGB(0, 255, 255, 255),
					Text = "",
					FontSize = 16,
					TextAlign = "kAlignCenterMiddle",
					TextColor = ARGB(255, 37, 37, 37),
				},
				Gui.Control
				{
					Size = Vector2(32,32),
					Location = Vector2(112, 468 + 60+ 140),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ibt_icon/reliveCoin.tga", Vector4(0,0,0,0)),
					},
				},
				Gui.Label "reviceCoinNum"
				{
					Size = Vector2(50, 32),
					Location = Vector2(132, 468 + 60+ 140),
					BackgroundColor = ARGB(0, 255, 255, 255),
					Text = "",
					FontSize = 16,
					TextAlign = "kAlignCenterMiddle",
					TextColor = ARGB(255, 37, 37, 37),
				},
				-- Gui.Control
				-- {
					-- Size = Vector2(32,32),
					-- Location = Vector2(182, 468 + 60+ 140),
					-- BackgroundColor = ARGB(255, 255, 255, 255),
					-- Skin = Gui.ControlSkin
					-- {
						-- BackgroundImage = Gui.Image("LobbyUI/ibt_icon/reliveCoin.tga", Vector4(0,0,0,0)),
					-- },
				-- },
				-- Gui.Label "ANum"
				-- {
					-- Size = Vector2(50, 32),
					-- Location = Vector2(202, 468 + 60+ 140),
					-- BackgroundColor = ARGB(0, 255, 255, 255),
					-- Text = "",
					-- FontSize = 16,
					-- TextAlign = "kAlignCenterMiddle",
					-- TextColor = ARGB(255, 37, 37, 37),
				-- },
				-- Gui.Control
				-- {
					-- Size = Vector2(32,32),
					-- Location = Vector2(252, 468 + 60+ 140),
					-- BackgroundColor = ARGB(255, 255, 255, 255),
					-- Skin = Gui.ControlSkin
					-- {
						-- BackgroundImage = Gui.Image("LobbyUI/ibt_icon/reliveCoin.tga", Vector4(0,0,0,0)),
					-- },
				-- },
				-- Gui.Label "BNum"
				-- {
					-- Size = Vector2(50, 32),
					-- Location = Vector2(272, 468 + 60+ 140),
					-- BackgroundColor = ARGB(0, 255, 255, 255),
					-- Text = "",
					-- FontSize = 16,
					-- TextAlign = "kAlignCenterMiddle",
					-- TextColor = ARGB(255, 37, 37, 37),
				-- },
				-- Gui.Control
				-- {
					-- Size = Vector2(32,32),
					-- Location = Vector2(322, 468 + 60+ 140),
					-- BackgroundColor = ARGB(255, 255, 255, 255),
					-- Skin = Gui.ControlSkin
					-- {
						-- BackgroundImage = Gui.Image("LobbyUI/ibt_icon/reliveCoin.tga", Vector4(0,0,0,0)),
					-- },
				-- },
				-- Gui.Label "CNum"
				-- {
					-- Size = Vector2(50, 32),
					-- Location = Vector2(342, 468 + 60+ 140),
					-- BackgroundColor = ARGB(0, 255, 255, 255),
					-- Text = "",
					-- FontSize = 16,
					-- TextAlign = "kAlignCenterMiddle",
					-- TextColor = ARGB(255, 37, 37, 37),
				-- },
			},		
		
		
			Gui.Label 
			{
				Size = Vector2(424,60+ 220),
				Location = Vector2(275-200, 280),
				FontSize = 20,
				BackgroundColor = ARGB(0, 255, 255, 255),
				TextAlign = "kAlignCenterMiddle",
				TextColor = ARGB(255, 255, 235, 119),
				Text = lang:GetText("VIP专区"),
			},
			
			Gui.Control "ctr_persent"
			{
				Size = Vector2(424,424 + 60+ 140),
				Location = Vector2(275-200,70),
				BackgroundColor = ARGB(0, 255, 255, 255),
			},
			
			--logo头图片
			Gui.Control
			{
				Size = Vector2(513,50),
				Location = Vector2(235-220, 13),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/free_change/lb_shop_free_title.dds", Vector4(0,0,0,0)),
				},
			},
		},
		
		
		
		Gui.Control"btn_exchange2"
		{	
			Size = Vector2(557, 551 + 60+ 110),
			BackgroundColor = ARGB(0, 255, 255, 255),
			Visible = false,
			Dock = "kDockCenter",
			-- Skin = Gui.ControlSkin
			-- {
				-- BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/Charm_Bottle/main_bar02.dds", Vector4(10, 10, 10, 10)),
			-- },
		
			Gui.Control
			{
				Size = Vector2(545,540 + 60+ 110),
				Location = Vector2(7,5),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/WarZone/Present/lb_gift_biew_bg1.dds", Vector4(200,104,105,48)),
				},
				Gui.Control
				{
					Size = Vector2(32, 32),
					Location = Vector2(40, 468 + 60+ 140),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/pipei/icon_a1_small.dds", Vector4(0,0,0,0)),
					},
				},
				Gui.Label "ANum1"
				{
					Size = Vector2(32, 32),
					Location = Vector2(63, 468 + 60+ 140),
					BackgroundColor = ARGB(0, 255, 255, 255),
					Text = "",
					FontSize = 16,
					TextAlign = "kAlignCenterMiddle",
					TextColor = ARGB(255, 37, 37, 37),
				},
				Gui.Control
				{
					 Size = Vector2(32,32),
					Location = Vector2(112, 468 + 60+ 140),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/pipei/icon_b1_small.dds", Vector4(0,0,0,0)),
					},
				},
				Gui.Label "BNum1"
				{
					Size = Vector2(50, 32),
					Location = Vector2(132, 468 + 60+ 140),
					BackgroundColor = ARGB(0, 255, 255, 255),
					Text = "",
					FontSize = 16,
					TextAlign = "kAlignCenterMiddle",
					TextColor = ARGB(255, 37, 37, 37),
				},
				Gui.Control
				{
					Size = Vector2(32,32),
					Location = Vector2(182, 468 + 60+ 140),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/pipei/icon_c1_small.dds", Vector4(0,0,0,0)),
					},
				},
				Gui.Label "CNum1"
				{
					Size = Vector2(50, 32),
					Location = Vector2(202, 468 + 60+ 140),
					BackgroundColor = ARGB(0, 255, 255, 255),
					Text = "",
					FontSize = 16,
					TextAlign = "kAlignCenterMiddle",
					TextColor = ARGB(255, 37, 37, 37),
				},
			},		
			Gui.Control
			{
				Size = Vector2(255,50),
				Location = Vector2(275-120, 320),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/WarZone/Present/lb_gift_biew_title02.dds", Vector4(0,0,0,0)),
				},
			},
			
			Gui.Control
			{	
				Size = Vector2(470, 130),
				Location = Vector2(40, 360),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/WarZone/Present/lb_synthesis_strengthening_bg_02.dds", Vector4(20, 20, 20, 20)),
				},
				Gui.Control
				{	
					Size = Vector2(100, 100),
					Location = Vector2(20, 17),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche2_hover.dds", Vector4(5, 5, 5, 5)),
					},
					Gui.Control"icon_a2"
					{	
						Size = Vector2(88, 88),
						Location = Vector2(8, 3),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/pipei/icon_a0.dds", Vector4(5, 5, 5, 5)),
						},	
					},					
				},
				Gui.Control
				{	
					Size = Vector2(100, 100),
					Location = Vector2(130, 17),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche2_hover.dds", Vector4(5, 5, 5, 5)),
					},	
					Gui.Control"icon_b2"
					{	
						Size = Vector2(88, 88),
						Location = Vector2(8, 3),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/pipei/icon_b0.dds", Vector4(5, 5, 5, 5)),
						},	
					},		
				},
				Gui.Control
				{	
					Size = Vector2(100, 100),
					Location = Vector2(240, 17),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche2_hover.dds", Vector4(5, 5, 5, 5)),
					},
					Gui.Control"icon_c2"
					{	
						Size = Vector2(88, 88),
						Location = Vector2(8, 3),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/pipei/icon_c0.dds", Vector4(5, 5, 5, 5)),
						},	
					},							
				},
				Gui.Control
				{	
					Size = Vector2(100, 100),
					Location = Vector2(350, 17),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_gouwuche2_hover.dds", Vector4(5, 5, 5, 5)),
					},	
					Gui.Control"lantu"
					{	
						Size = Vector2(88, 88),
						Location = Vector2(8, 3),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/pipei/pipei_lantu_box_hui.dds", Vector4(5, 5, 5, 5)),
						},	
					},			
				},
			},
			Gui.Control
			{	
				Size = Vector2(33, 50),
				Location = Vector2(260, 483),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_ico_01_normal.dds", Vector4(5, 5, 5, 5)),
				},
			},
			Gui.Control
			{	
				Size = Vector2(180, 120),
				Location = Vector2(183, 540),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Compose/lb_synthesis_strengthening_bg_02.dds", Vector4(5, 5, 5, 5)),
				},
				Gui.Control
				{	
					Size = Vector2(88, 88),
					Location = Vector2(45, 13),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/pipei/icon_pipei_box.dds", Vector4(5, 5, 5, 5)),
					},
				},
			},
			
			Gui.Control "ctr_persent1"
			{
				Size = Vector2(424,424 + 60+ 140),
				Location = Vector2(275-200,70),
				BackgroundColor = ARGB(0, 255, 255, 255),
			},
			Gui.Button "compound"
			{
				Size = Vector2(100, 50),
				Location = Vector2(395, 600),
				Text = lang:GetText("合 成"),
				TextColor = ARGB(255, 37, 37, 37),
				HighlightTextColor = ARGB(255, 37, 37, 37),
				Padding = Vector4(0, 0, 0, 3),
				
				FontSize = 18,
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Mission/lb_task_button01_normal.dds", Vector4(10, 10, 10, 10)),
					HoverImage = Gui.Image("LobbyUI/Mission/lb_task_button01_hover.dds", Vector4(10, 10, 10, 10)),
					DownImage = Gui.Image("LobbyUI/Mission/lb_task_button01_down.dds", Vector4(10, 10, 10, 10)),
					DisabledImage = Gui.Image("LobbyUI/Mission/lb_task_button01_disabled.dds", Vector4(10, 10, 10, 10)),
				},
				EventClick = function()
				print("0.0.0.0.0.0.0.0.0")
						if match_list[1].subtype == 1  and match_list[2].subtype == 1 and  match_list[3].subtype == 1  and match_list[4].subtype == 2 then
							suipian_hecheng = suipian_a..":"..suipian_b..":"..suipian_c
							print("suipian_hechengsuipian_hechengsuipian_hechengsuipian_hechengsuipian_hechengsuipian_hechengsuipian_hechengsuipian_hecheng",suipian_hecheng)
							
							print("lantulantulantulantulantulantulantulantu",lantu)
							MessageBox.ShowWithTimer(3, lang:GetText("物品已放入仓库中！"))
							rpc.safecall("melting_input",{qualityProps = lantu,meltingInputs = suipian_hecheng, pid = ptr_cast(game.CurrentState):GetCharacterId()},function(data)
							
							end)
						else
							MessageBox.ShowWithTimer(5, lang:GetText("对不起材料不足，无法合成"))
						end
						
				end
			},
			Gui.Label 
			{
				Size = Vector2(513,50),
				Location = Vector2(140, 280),
				FontSize = 20,
				BackgroundColor = ARGB(0, 255, 255, 255),
				TextColor = ARGB(255, 255, 235, 119),
				Text = lang:GetText("熔炼等级达到2级以上才可合成"),
			},
			--logo头图片
			Gui.Control
			{
				Size = Vector2(513,50),
				Location = Vector2(235-220, 13),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/WarZone/Present/lb_gift_biew_title01.dds", Vector4(0,0,0,0)),
				},
			},
		},
		
		--退出
		Gui.Button
		{
			Size = Vector2(52,48),
			Location = Vector2(725, 0),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_normal.dds", Vector4(10, 10, 10, 10)),
				HoverImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_hover.dds", Vector4(10, 10, 10, 10)),
				DownImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_down.dds", Vector4(10, 10, 10, 10)),
				DisabledImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_disabled.dds", Vector4(0, 0, 0, 0)),	
			},
			EventClick = function()
				HideViewPresentWindow()
			end,
		},
	},
}

--购买结算 送给好友 界面
buy_and_present_window_page = Gui.Create()
{
	Gui.Control "ctrl_bg"
	{
		Size = Vector2(1200, 900),
		Location = Vector2(0, 0),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/lb_common_black_bg.dds",Vector4(0, 0, 0, 0)),
		},
		Gui.Control "ctrl_window_root"
		{
			Size = Vector2(520, 524),
			Location = Vector2(310, 220),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_bg1.dds", Vector4(28, 28, 28, 28)),
			},

			

			--送给好友
			Gui.Button "btn_buy_and_present"
			{
				Size = Vector2(84, 28),
				Location = Vector2(117, 20),
				Text = lang:GetText("送给好友"),
				TextColor = ARGB(255, 37, 37, 37),
				HighlightTextColor = ARGB(255, 242, 242, 242),
				Font = "simhei",
				FontSize = 16,
				PushDown = false,
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_tab1_normal.dds", Vector4(10, 0, 10, 0)),
					HoverImage = Gui.Image("LobbyUI/Friends/lb_contact_tab1_hover.dds", Vector4(10, 0, 10, 0)),
					DownImage = Gui.Image("LobbyUI/Friends/lb_contact_tab1_down.dds", Vector4(10, 0, 10, 0)),
					DisabledImage = Gui.Image("LobbyUI/Friends/lb_contact_tab1_normal.dds", Vector4(10, 0, 10, 0)),
				},
				EventClick = function()
					if buy_and_present_window_page then						
						buy_and_present_window_page.lbl_present_to.Visible = true
						buy_and_present_window_page.cbx_friends_present.Visible = true
						buy_and_present_window_page.lbl_balance_mode.Location = Vector2(248, 6)
						buy_and_present_window_page.btn_front_page.Location = Vector2(323, 7)
						buy_and_present_window_page.lb_page_number.Location = Vector2(346, 6)
						buy_and_present_window_page.btn_next_page.Location = Vector2(408, 7)
						
						buy_and_present_window_page.lbl_spend_point.Text = ""
						buy_and_present_window_page.btn_buy_and_balance.PushDown = false
						buy_and_present_window_page.btn_buy_and_present.Visible = false
						--buy_and_present_window_page.cbox_buy_and_equip.Visible = false
						--buy_and_present_window_page.lbl_buy_and_equip.Visible = false
						buy_and_present_window_page.btn_three_days.PushDown = true
						buy_and_present_window_page.btn_senven_days.PushDown = false
						buy_and_present_window_page.btn_thirty_days.PushDown = false
						buy_and_present_window_page.btn_forever.PushDown = false
						buy_and_present_window_page.btn_buy.Text = lang:GetText("赠送")
						FillPresentWindow()					
					end
				end
			},

			Gui.Control "ctrl_window_main"
			{
				Size = Vector2(477, 462),
				Location = Vector2(21, 46),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_bg2.dds", Vector4(21, 25, 21, 46)),
				},
					
				--物品图片
				Gui.Control "ctrl_goods_image_root"
				{
					Size = Vector2(169, 156),
					Location = Vector2(17, 35),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_box4_jiaoyi.dds", Vector4(10, 10, 10, 10)),
					},
					Gui.Control "ctrl_goods_image"
					{
						Dock = "kDockCenter",
						BackgroundColor = ARGB(255, 255, 255, 255),
					},
				},

				--物品名称
				Gui.Label "lbl_goods_name"
				{
					Size = Vector2(252, 20),
					Text = lang:GetText("物品名称"),
					Font = "simhei",
					FontSize = 18,
					Location = Vector2(180, 50),
					TextAlign = "kAlignCenterMiddle",
					TextColor = ARGB(255, 37, 37, 37),
					--BackgroundColor = ARGB(255, 0, 0, 255),
				},

				--物品用途
				Gui.TextArea "lbl_goods_info"
				{
					Size = Vector2(252, 131),
					Text = lang:GetText("物品用途"),
					FontSize = 16,
					Location = Vector2(204, 76),
					TextColor = ARGB(255, 37, 37, 37),
					Readonly = true,
					Fold = true,
					HScrollBarDisplay = "kHide",
					VScrollBarDisplay = "kAuto",							
					Skin = Gui.TextAreaSkin
					{
						UpButtonNormalImage = nil,
						UpButtonHoverImage = nil,
						UpButtonDownImage = nil,
						UpButtonDisabledImage = nil,

						DownButtonNormalImage = nil,
						DownButtonHoverImage = nil,
						DownButtonDownImage = nil,
						DownButtonDisabledImage = nil,

						VSliderNormalImage = Gui.Image("LobbyUI/team/lb_squad_scrollbar_button_normal.dds", Vector4(5, 5, 5, 5)),
						VSliderHoverImage = Gui.Image("LobbyUI/team/lb_squad_scrollbar_button_hover.dds", Vector4(5, 5, 5, 5)),
						VSliderDownImage = Gui.Image("LobbyUI/team/lb_squad_scrollbar_button_down.dds", Vector4(5, 5, 5, 5)),
						VSliderDisabledImage = Gui.Image("DLobbyUI/team/lb_squad_scrollbar_button_normal.dds", Vector4(5, 5, 5, 5)),

						VBarBackgroundImage = Gui.Image("LobbyUI/lb_common_scrollbar02_bg.dds", Vector4(0, 0, 0, 0)),
						BarCornerImage = nil,
					},
				},

				--结算方式
				Gui.Control "ctrl_balance_mode"
				{
					Size = Vector2(443, 92),
					Location = Vector2(15, 233),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_box4_jiaoyi.dds", Vector4(10, 10, 10, 10)),
					},
					
					--结算方式
					Gui.Control "ctrl_balance_mode_bg"
					{
						Size = Vector2(434, 38),
						Location = Vector2(5, 6),
						BackgroundColor = ARGB(255, 255, 255, 255),
						Visible = true,
						Skin = Gui.ControlSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_line4.dds", Vector4(10, 10, 10, 10)),
						},
						
						--赠送给
						Gui.Label "lbl_present_to"
						{
							Size = Vector2(58, 23),
							Text = lang:GetText("赠送给"),
							Font = "simhei",
							FontSize = 18,
							Visible = false,
							Location = Vector2(3, 6),
							TextColor = ARGB(255, 37, 37, 37),
						},
						
						--好友列表
						Gui.ComboBox "cbx_friends_present"
						{
							Size = Vector2(144, 28),
							Readonly = true,
							TextColor = ARGB(255, 37, 37, 37),
							Location = Vector2(63, 3),
							Text = lang:GetText("请选择一位好友"),
							Visible = false,
							Skin = Gui.ComboBoxSkin
							{
								ButtonNormalImage= Gui.Image("LobbyUI/mail/lb_squad_combobox_button2_normal.dds", Vector4(0, 0, 0, 0)),
								ButtonHoverImage = Gui.Image("LobbyUI/mail/lb_squad_combobox_button2_hover.dds", Vector4(0, 0, 0, 0)),
								ButtonDownImage = Gui.Image("LobbyUI/mail/lb_squad_combobox_button2_down.dds", Vector4(0, 0, 0, 0)),
								
								TextNormalImage= Gui.Image("LobbyUI/mail/lb_squad_combobox2_text.dds", Vector4(6, 0, 0, 0)),
								TextHoverImage = Gui.Image("LobbyUI/mail/lb_squad_combobox2_text.dds", Vector4(6, 0, 0, 0)),
								TextDownImage = Gui.Image("LobbyUI/mail/lb_squad_combobox2_text.dds", Vector4(6, 0, 0, 0)),								
							},
							ChildComboListStyle =  "Gui.teamComboList",
							
							EventItemSelected = function(sender, e)
								current_select_firend_index = sender.SelectedIndex
							end
						},

						--结算方式
						Gui.Label "lbl_balance_mode"
						{
							Size = Vector2(78, 24),
							Text = lang:GetText("结算方式"),
							Font = "simhei",
							FontSize = 18,
							Location = Vector2(118, 5),
							TextColor = ARGB(255, 37, 37, 37),
						},

						--上一种结算方式
						Gui.Button "btn_front_page"
						{
							Visible = false,
							Size = Vector2(20, 20),
							Location = Vector2(213, 7),
							--Text = "<",
							TextColor = ARGB(255, 191, 189, 184),
							FontSize = 16,
							Skin = Gui.ButtonSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button08_normal.dds", Vector4(8, 8, 8, 8)),
								HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button08_hover.dds", Vector4(8, 8, 8, 8)),
								DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button08_down.dds", Vector4(8, 8, 8, 8)),
								DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button08_normal.dds", Vector4(8, 8, 8, 8)),
							},
							EventClick = function()
								buy_and_present_window_page.lbl_spend_point.TextColor = ARGB(255, 37, 37, 37)
								--buy_and_present_ui.lbl_spend_GP.TextColor = ARGB(255, 37, 37, 37)
								--buy_and_present_ui.lbl_spend_ticket.TextColor = ARGB(255, 37, 37, 37)
								if buy_and_present_window_page then
									if present_list then
										local weapon_info = present_list[current_selected_ibtn_index]
										if weapon_info then
											--付款方式
											local mode1 = weapon_info.medalprices
											local ncount = current_selected_price_way
											ncount = ncount - 1
											
											buy_and_present_window_page.btn_three_days.PushDown = false
											buy_and_present_window_page.btn_senven_days.PushDown = false
											buy_and_present_window_page.btn_thirty_days.PushDown = false
											buy_and_present_window_page.btn_forever.PushDown = false
											cost_mode = 1
											
											local flag = true
											while flag do
												if ncount == 0 then
													ncount = 3
												end												

												if ncount == 1 then
													if mode1[1] then
														if present_list[current_selected_ibtn_index].medalprices[cost_mode].cost > xunzhang_num then
															buy_and_present_window_page.lbl_spend_point.TextColor = ARGB(255, 255, 0, 0)
														end
														buy_and_present_window_page.lbl_spend_point.Text = present_list[current_selected_ibtn_index].medalprices[cost_mode].cost .. " " .. price_way[1]
														current_selected_price_way = 1
														flag = false
														if mode1[1].unittype == 0 then
															buy_and_present_window_page.btn_three_days.Text = unittype_way[mode1[1].unittype + 1]
														else
															buy_and_present_window_page.btn_three_days.Text = mode1[1].unit..unittype_way[mode1[1].unittype + 1]
														end
														buy_and_present_window_page.btn_three_days.Visible = true
														buy_and_present_window_page.btn_three_days.PushDown = true
													else
														buy_and_present_window_page.btn_three_days.Visible = false
														buy_and_present_window_page.btn_three_days.PushDown = false
													end

													if mode1[2] then
														if mode1[2].unittype == 0 then
															buy_and_present_window_page.btn_senven_days.Text = unittype_way[mode1[2].unittype + 1]
														else
															buy_and_present_window_page.btn_senven_days.Text = mode1[2].unit..unittype_way[mode1[2].unittype + 1]
														end
														buy_and_present_window_page.btn_senven_days.Visible = true
													else
														buy_and_present_window_page.btn_senven_days.Visible = false
														buy_and_present_window_page.btn_senven_days.PushDown = false
													end

													if mode1[3] then
														if mode1[2].unittype == 0 then
															buy_and_present_window_page.btn_thirty_days.Text = unittype_way[mode1[3].unittype + 1]
														else
															buy_and_present_window_page.btn_thirty_days.Text = mode1[3].unit..unittype_way[mode1[3].unittype + 1]
														end
														buy_and_present_window_page.btn_thirty_days.Visible = true
													else
														buy_and_present_window_page.btn_thirty_days.Visible = false
														buy_and_present_window_page.btn_thirty_days.PushDown = false
													end

													if mode1[4] then
														if mode1[4].unittype == 0 then
															buy_and_present_window_page.btn_forever.Text = unittype_way[mode1[4].unittype + 1]
														else
															buy_and_present_window_page.btn_forever.Text = mode1[1].unit..unittype_way[mode1[4].unittype + 1]
														end
														buy_and_present_window_page.btn_forever.Visible = true
													else
														buy_and_present_window_page.btn_forever.Visible = false
														buy_and_present_window_page.btn_forever.PushDown = false
													end
												
												end
											end
											buy_and_present_window_page.lb_page_number.Text = price_way[current_selected_price_way]
										end
									end
								end
							end
						},

						--FC点
						Gui.Label "lb_page_number"
						{
							Location = Vector2(246, 8),
							Size = Vector2(100, 20),
							Font = "simhei",
							FontSize = 18,
							TextAlign = "kAlignCenterMiddle",
							TextColor = ARGB(255, 37, 37, 37),
							Text = lang:GetText("勋章"),
						},

						--下一种结算方式
						Gui.Button "btn_next_page"
						{
							Visible = false,
							Size = Vector2(20, 20),
							Location = Vector2(317, 7),
							TextColor = ARGB(255, 191, 189, 184),
							FontSize = 16,
							Skin = Gui.ButtonSkin
							{
								BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button09_normal.dds", Vector4(8, 8, 8, 8)),
								HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button09_hover.dds", Vector4(8, 8, 8, 8)),
								DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button09_down.dds", Vector4(8, 8, 8, 8)),
								DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button09_normal.dds", Vector4(8, 8, 8, 8)),
							},
							EventClick = function()
								buy_and_present_window_page.lbl_spend_point.TextColor = ARGB(255, 37, 37, 37)
								--buy_and_present_ui.lbl_spend_GP.TextColor = ARGB(255, 37, 37, 37)
								--buy_and_present_ui.lbl_spend_ticket.TextColor = ARGB(255, 37, 37, 37)
								if buy_and_present_window_page then
									if present_list then
										local weapon_info = present_list[current_selected_ibtn_index]
										if weapon_info then
											--付款方式
											local mode1 = weapon_info.medalprices
											local ncount = current_selected_price_way
											ncount = ncount + 1
											
											buy_and_present_window_page.btn_three_days.PushDown = false
											buy_and_present_window_page.btn_senven_days.PushDown = false
											buy_and_present_window_page.btn_thirty_days.PushDown = false
											buy_and_present_window_page.btn_forever.PushDown = false
											cost_mode = 1

											local flag = true
											while flag do
												if ncount == 4 then
													ncount = 1
												end

												if ncount == 1 then
													if mode1[1] then
														if present_list[current_selected_ibtn_index].medalprices[cost_mode].cost > xunzhang_num then
															buy_and_present_window_page.lbl_spend_point.TextColor = ARGB(255, 255, 0, 0)
														end
														buy_and_present_window_page.lbl_spend_point.Text = present_list[current_selected_ibtn_index].medalprices[cost_mode].cost .. " " .. price_way[1]
														current_selected_price_way = 1
														flag = false
														if mode1[1].unittype == 0 then
															buy_and_present_window_page.btn_three_days.Text = unittype_way[mode1[1].unittype + 1]
														else
															buy_and_present_window_page.btn_three_days.Text = mode1[1].unit..unittype_way[mode1[1].unittype + 1]
														end
														buy_and_present_window_page.btn_three_days.Visible = true
														buy_and_present_window_page.btn_three_days.PushDown = true
													else
														buy_and_present_window_page.btn_three_days.Visible = false
														buy_and_present_window_page.btn_three_days.PushDown = false
													end

													if mode1[2] then
														if mode1[2].unittype == 0 then
															buy_and_present_window_page.btn_senven_days.Text = unittype_way[mode1[2].unittype + 1]
														else
															buy_and_present_window_page.btn_senven_days.Text = mode1[2].unit..unittype_way[mode1[2].unittype + 1]
														end
														buy_and_present_window_page.btn_senven_days.Visible = true
													else
														buy_and_present_window_page.btn_senven_days.Visible = false
														buy_and_present_window_page.btn_senven_days.PushDown = false
													end

													if mode1[3] then
														if mode1[2].unittype == 0 then
															buy_and_present_window_page.btn_thirty_days.Text = unittype_way[mode1[3].unittype + 1]
														else
															buy_and_present_window_page.btn_thirty_days.Text = mode1[3].unit..unittype_way[mode1[3].unittype + 1]
														end
														buy_and_present_window_page.btn_thirty_days.Visible = true
													else
														buy_and_present_window_page.btn_thirty_days.Visible = false
														buy_and_present_window_page.btn_thirty_days.PushDown = false
													end

													if mode1[4] then
														if mode1[4].unittype == 0 then
															buy_and_present_window_page.btn_forever.Text = unittype_way[mode1[4].unittype + 1]
														else
															buy_and_present_window_page.btn_forever.Text = mode1[1].unit..unittype_way[mode1[4].unittype + 1]
														end
														buy_and_present_window_page.btn_forever.Visible = true
													else
														buy_and_present_window_page.btn_forever.Visible = false
														buy_and_present_window_page.btn_forever.PushDown = false
													end													
												end
											end
											buy_and_present_window_page.lb_page_number.Text = price_way[current_selected_price_way]
										end
									end
								end
							end
						},
					},
					
					--三天
					Gui.Button "btn_three_days"
					{
						Size = Vector2(103, 26),
						Location = Vector2(8, 54),
						Text = lang:GetText("50/3天"),
						TextColor = ARGB(255, 242, 242, 242),
						HighlightTextColor = ARGB(255, 37, 37, 37),
						Font = "simhei",
						FontSize = 16,
						BackgroundColor = ARGB(255, 255, 255, 255),
						PushDown = true,
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_normal.dds", Vector4(10, 10, 10, 10)),
							HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_hover.dds", Vector4(10, 10, 10, 10)),
							DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_down.dds", Vector4(10, 10, 10, 10)),
							DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_normal.dds", Vector4(10, 10, 10, 10)),
						},
						EventClick = function()
							
							--buy_and_present_ui.lbl_spend_GP.TextColor = ARGB(255, 37, 37, 37)
							--buy_and_present_ui.lbl_spend_ticket.TextColor = ARGB(255, 37, 37, 37)
							if  buy_and_present_window_page then
								buy_and_present_window_page.btn_three_days.PushDown = true
								buy_and_present_window_page.btn_senven_days.PushDown = false
								buy_and_present_window_page.btn_thirty_days.PushDown = false
								buy_and_present_window_page.btn_forever.PushDown = false
								cost_mode = 1
								if current_selected_price_way == 1 then
									if  present_list[current_selected_ibtn_index].medalprices[cost_mode].cost > xunzhang_num then
										buy_and_present_window_page.lbl_spend_point.TextColor = ARGB(255, 255, 0, 0)
									else
										buy_and_present_window_page.lbl_spend_point.TextColor = ARGB(255, 37, 37, 37)
									end
									buy_and_present_window_page.lbl_spend_point.Text = present_list[current_selected_ibtn_index].medalprices[cost_mode].cost .. " " .. price_way[1]
								elseif current_selected_price_way == 2 then
									if  present_list[current_selected_ibtn_index].revivecoins[cost_mode].cost > reviceCoinNum then
										buy_and_present_window_page.lbl_spend_point.TextColor = ARGB(255, 255, 0, 0)
									else
										buy_and_present_window_page.lbl_spend_point.TextColor = ARGB(255, 37, 37, 37)
									end
									buy_and_present_window_page.lbl_spend_point.Text = present_list[current_selected_ibtn_index].revivecoins[cost_mode].cost .. " " .. price_way[2]
								elseif current_selected_price_way == 3 then
									if  present_list[current_selected_ibtn_index].achipcoins[cost_mode].cost > A_num then
										buy_and_present_window_page.lbl_spend_point.TextColor = ARGB(255, 255, 0, 0)
									else
										buy_and_present_window_page.lbl_spend_point.TextColor = ARGB(255, 37, 37, 37)
									end
									buy_and_present_window_page.lbl_spend_point.Text = present_list[current_selected_ibtn_index].achipcoins[cost_mode].cost .. " " .. price_way[3]
								elseif current_selected_price_way == 4 then
									if  present_list[current_selected_ibtn_index].bchipcoins[cost_mode].cost > B_num then
										buy_and_present_window_page.lbl_spend_point.TextColor = ARGB(255, 255, 0, 0)
									else
										buy_and_present_window_page.lbl_spend_point.TextColor = ARGB(255, 37, 37, 37)
									end
									buy_and_present_window_page.lbl_spend_point.Text = present_list[current_selected_ibtn_index].bchipcoins[cost_mode].cost .. " " .. price_way[4]
								elseif current_selected_price_way == 5 then
									if  present_list[current_selected_ibtn_index].cchipcoins[cost_mode].cost > C_num then
										buy_and_present_window_page.lbl_spend_point.TextColor = ARGB(255, 255, 0, 0)
									else
										buy_and_present_window_page.lbl_spend_point.TextColor = ARGB(255, 37, 37, 37)
									end
									buy_and_present_window_page.lbl_spend_point.Text = present_list[current_selected_ibtn_index].cchipcoins[cost_mode].cost .. " " .. price_way[5]
								end
							end
						end,
					},

					--七天
					Gui.Button "btn_senven_days"
					{
						Size = Vector2(103, 26),
						Location = Vector2(117, 54),
						Text = lang:GetText("100/7天"),
						TextColor = ARGB(255, 242, 242, 242),
						HighlightTextColor = ARGB(255, 37, 37, 37),
						Font = "simhei",
						FontSize = 16,
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_normal.dds", Vector4(10, 10, 10, 10)),
							HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_hover.dds", Vector4(10, 10, 10, 10)),
							DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_down.dds", Vector4(10, 10, 10, 10)),
							DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_normal.dds", Vector4(10, 10, 10, 10)),
						},
						EventClick = function()
							buy_and_present_window_page.lbl_spend_point.TextColor = ARGB(255, 37, 37, 37)
							--buy_and_present_ui.lbl_spend_GP.TextColor = ARGB(255, 37, 37, 37)
							--buy_and_present_ui.lbl_spend_ticket.TextColor = ARGB(255, 37, 37, 37)
							if buy_and_present_window_page then
								buy_and_present_window_page.btn_three_days.PushDown = false
								buy_and_present_window_page.btn_senven_days.PushDown = true
								buy_and_present_window_page.btn_thirty_days.PushDown = false
								buy_and_present_window_page.btn_forever.PushDown = false
								cost_mode = 2
								if current_selected_price_way == 1 then
									if  present_list[current_selected_ibtn_index].medalprices[cost_mode].cost > xunzhang_num then
										buy_and_present_window_page.lbl_spend_point.TextColor = ARGB(255, 255, 0, 0)
									else
										buy_and_present_window_page.lbl_spend_point.TextColor = ARGB(255, 37, 37, 37)
									end
									buy_and_present_window_page.lbl_spend_point.Text = present_list[current_selected_ibtn_index].medalprices[cost_mode].cost .. " " .. price_way[1]
								elseif current_selected_price_way == 2 then
									if  present_list[current_selected_ibtn_index].revivecoins[cost_mode].cost > reviceCoinNum then
										buy_and_present_window_page.lbl_spend_point.TextColor = ARGB(255, 255, 0, 0)
									else
										buy_and_present_window_page.lbl_spend_point.TextColor = ARGB(255, 37, 37, 37)
									end
									buy_and_present_window_page.lbl_spend_point.Text = present_list[current_selected_ibtn_index].revivecoins[cost_mode].cost .. " " .. price_way[2]
								elseif current_selected_price_way == 3 then
									if  present_list[current_selected_ibtn_index].achipcoins[cost_mode].cost > A_num then
										buy_and_present_window_page.lbl_spend_point.TextColor = ARGB(255, 255, 0, 0)
									else
										buy_and_present_window_page.lbl_spend_point.TextColor = ARGB(255, 37, 37, 37)
									end
									buy_and_present_window_page.lbl_spend_point.Text = present_list[current_selected_ibtn_index].achipcoins[cost_mode].cost .. " " .. price_way[3]
								elseif current_selected_price_way == 4 then
									if  present_list[current_selected_ibtn_index].bchipcoins[cost_mode].cost > B_num then
										buy_and_present_window_page.lbl_spend_point.TextColor = ARGB(255, 255, 0, 0)
									else
										buy_and_present_window_page.lbl_spend_point.TextColor = ARGB(255, 37, 37, 37)
									end
									buy_and_present_window_page.lbl_spend_point.Text = present_list[current_selected_ibtn_index].bchipcoins[cost_mode].cost .. " " .. price_way[4]
								elseif current_selected_price_way == 5 then
									if  present_list[current_selected_ibtn_index].cchipcoins[cost_mode].cost > C_num then
										buy_and_present_window_page.lbl_spend_point.TextColor = ARGB(255, 255, 0, 0)
									else
										buy_and_present_window_page.lbl_spend_point.TextColor = ARGB(255, 37, 37, 37)
									end
									buy_and_present_window_page.lbl_spend_point.Text = present_list[current_selected_ibtn_index].cchipcoins[cost_mode].cost .. " " .. price_way[5]
								end
							end
						end,
					},

					--三十天
					Gui.Button "btn_thirty_days"
					{
						Size = Vector2(103, 26),
						Location = Vector2(226, 54),
						Text = lang:GetText("500/30天"),
						TextColor = ARGB(255, 242, 242, 242),
						HighlightTextColor = ARGB(255, 37, 37, 37),
						Font = "simhei",
						FontSize = 16,
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_normal.dds", Vector4(10, 10, 10, 10)),
							HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_hover.dds", Vector4(10, 10, 10, 10)),
							DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_down.dds", Vector4(10, 10, 10, 10)),
							DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_normal.dds", Vector4(10, 10, 10, 10)),
						},
						EventClick = function()
							buy_and_present_window_page.lbl_spend_point.TextColor = ARGB(255, 37, 37, 37)
							--buy_and_present_ui.lbl_spend_GP.TextColor = ARGB(255, 37, 37, 37)
							--buy_and_present_ui.lbl_spend_ticket.TextColor = ARGB(255, 37, 37, 37)
							if buy_and_present_window_page then
								cost_mode = 3
								buy_and_present_window_page.btn_three_days.PushDown = false
								buy_and_present_window_page.btn_senven_days.PushDown = false
								buy_and_present_window_page.btn_thirty_days.PushDown = true
								buy_and_present_window_page.btn_forever.PushDown = false
								if current_selected_price_way == 1 then
									if  present_list[current_selected_ibtn_index].medalprices[cost_mode].cost > xunzhang_num then
										buy_and_present_window_page.lbl_spend_point.TextColor = ARGB(255, 255, 0, 0)
									else
										buy_and_present_window_page.lbl_spend_point.TextColor = ARGB(255, 37, 37, 37)
									end
									buy_and_present_window_page.lbl_spend_point.Text = present_list[current_selected_ibtn_index].medalprices[cost_mode].cost .. " " .. price_way[1]																	
								elseif current_selected_price_way == 2 then
									if  present_list[current_selected_ibtn_index].revivecoins[cost_mode].cost > reviceCoinNum then
										buy_and_present_window_page.lbl_spend_point.TextColor = ARGB(255, 255, 0, 0)
									else
										buy_and_present_window_page.lbl_spend_point.TextColor = ARGB(255, 37, 37, 37)
									end
									buy_and_present_window_page.lbl_spend_point.Text = present_list[current_selected_ibtn_index].revivecoins[cost_mode].cost .. " " .. price_way[2]
								elseif current_selected_price_way == 3 then
									if  present_list[current_selected_ibtn_index].achipcoins[cost_mode].cost > A_num then
										buy_and_present_window_page.lbl_spend_point.TextColor = ARGB(255, 255, 0, 0)
									else
										buy_and_present_window_page.lbl_spend_point.TextColor = ARGB(255, 37, 37, 37)
									end
									buy_and_present_window_page.lbl_spend_point.Text = present_list[current_selected_ibtn_index].achipcoins[cost_mode].cost .. " " .. price_way[3]
								elseif current_selected_price_way == 4 then
									if  present_list[current_selected_ibtn_index].bchipcoins[cost_mode].cost > B_num then
										buy_and_present_window_page.lbl_spend_point.TextColor = ARGB(255, 255, 0, 0)
									else
										buy_and_present_window_page.lbl_spend_point.TextColor = ARGB(255, 37, 37, 37)
									end
									buy_and_present_window_page.lbl_spend_point.Text = present_list[current_selected_ibtn_index].bchipcoins[cost_mode].cost .. " " .. price_way[4]
								elseif current_selected_price_way == 5 then
									if  present_list[current_selected_ibtn_index].cchipcoins[cost_mode].cost > C_num then
										buy_and_present_window_page.lbl_spend_point.TextColor = ARGB(255, 255, 0, 0)
									else
										buy_and_present_window_page.lbl_spend_point.TextColor = ARGB(255, 37, 37, 37)
									end
									buy_and_present_window_page.lbl_spend_point.Text = present_list[current_selected_ibtn_index].cchipcoins[cost_mode].cost .. " " .. price_way[5]
								end
							end
						end,
					},

					--永久
					Gui.Button "btn_forever"
					{
						Size = Vector2(103, 26),
						Location = Vector2(335, 54),
						Text = lang:GetText("1000/永久"),
						TextColor = ARGB(255, 242, 242, 242),
						HighlightTextColor = ARGB(255, 37, 37, 37),
						Font = "simhei",
						FontSize = 16,
						BackgroundColor = ARGB(255, 255, 255, 255),
						Skin = Gui.ButtonSkin
						{
							BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_normal.dds", Vector4(10, 10, 10, 10)),
							HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_hover.dds", Vector4(10, 10, 10, 10)),
							DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_down.dds", Vector4(10, 10, 10, 10)),
							DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_buttonfukuan_normal.dds", Vector4(10, 10, 10, 10)),
						},
						EventClick = function()
							buy_and_present_window_page.lbl_spend_point.TextColor = ARGB(255, 37, 37, 37)
							--buy_and_present_ui.lbl_spend_GP.TextColor = ARGB(255, 37, 37, 37)
							--buy_and_present_ui.lbl_spend_ticket.TextColor = ARGB(255, 37, 37, 37)
							if buy_and_present_window_page then
								cost_mode = 4
								buy_and_present_window_page.btn_three_days.PushDown = false
								buy_and_present_window_page.btn_senven_days.PushDown = false
								buy_and_present_window_page.btn_thirty_days.PushDown = false
								buy_and_present_window_page.btn_forever.PushDown = true
								if current_selected_price_way == 1 then
									if  present_list[current_selected_ibtn_index].medalprices[cost_mode].cost > xunzhang_num then
										buy_and_present_window_page.lbl_spend_point.TextColor = ARGB(255, 255, 0, 0)
									else
										buy_and_present_window_page.lbl_spend_point.TextColor = ARGB(255, 37, 37, 37)
									end
									buy_and_present_window_page.lbl_spend_point.Text = present_list[current_selected_ibtn_index].medalprices[cost_mode].cost .. " " .. price_way[1]
								elseif current_selected_price_way == 2 then
									if  present_list[current_selected_ibtn_index].revivecoins[cost_mode].cost > reviceCoinNum then
										buy_and_present_window_page.lbl_spend_point.TextColor = ARGB(255, 255, 0, 0)
									else
										buy_and_present_window_page.lbl_spend_point.TextColor = ARGB(255, 37, 37, 37)
									end
									buy_and_present_window_page.lbl_spend_point.Text = present_list[current_selected_ibtn_index].revivecoins[cost_mode].cost .. " " .. price_way[2]
								elseif current_selected_price_way == 3 then
									if  present_list[current_selected_ibtn_index].achipcoins[cost_mode].cost > A_num then
										buy_and_present_window_page.lbl_spend_point.TextColor = ARGB(255, 255, 0, 0)
									else
										buy_and_present_window_page.lbl_spend_point.TextColor = ARGB(255, 37, 37, 37)
									end
									buy_and_present_window_page.lbl_spend_point.Text = present_list[current_selected_ibtn_index].achipcoins[cost_mode].cost .. " " .. price_way[3]
								elseif current_selected_price_way == 4 then
									if  present_list[current_selected_ibtn_index].bchipcoins[cost_mode].cost > B_num then
										buy_and_present_window_page.lbl_spend_point.TextColor = ARGB(255, 255, 0, 0)
									else
										buy_and_present_window_page.lbl_spend_point.TextColor = ARGB(255, 37, 37, 37)
									end
									buy_and_present_window_page.lbl_spend_point.Text = present_list[current_selected_ibtn_index].bchipcoins[cost_mode].cost .. " " .. price_way[4]
								elseif current_selected_price_way == 5 then
									if  present_list[current_selected_ibtn_index].cchipcoins[cost_mode].cost > C_num then
										buy_and_present_window_page.lbl_spend_point.TextColor = ARGB(255, 255, 0, 0)
									else
										buy_and_present_window_page.lbl_spend_point.TextColor = ARGB(255, 37, 37, 37)
									end
									buy_and_present_window_page.lbl_spend_point.Text = present_list[current_selected_ibtn_index].cchipcoins[cost_mode].cost .. " " .. price_way[5]
								end
							end
						end,
					},
				},

				--余额
				Gui.Label "lbl_balance"
				{
					Size = Vector2(60, 19),
					Text = lang:GetText("余额"),
					Font = "simhei",
					FontSize = 15,
					Location = Vector2(10, 335),
					TextColor = ARGB(255, 37, 37, 37),
					--BackgroundColor = ARGB(255, 0, 0, 255),
				},
				--FC点
				Gui.Label "lbl_balance_point"
				{
					Size = Vector2(151, 21),
					--Text = lang:GetText("500FC点"),
					Font = "simhei",
					FontSize = 16,
					Location = Vector2(78, 334),
					BackgroundColor = ARGB(255, 255, 255, 255),
					TextColor = ARGB(255, 37, 37, 37),
					TextAlign = "kAlignRightMiddle",
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_box_huafei.dds", Vector4(10, 10, 10, 10)),
					},
				},

				--花费
				Gui.Label "lbl_spend"
				{
					Size = Vector2(37, 19),
					Text = lang:GetText("花费"),
					Font = "simhei",
					FontSize = 16,
					Location = Vector2(252, 335),
					TextColor = ARGB(255, 37, 37, 37),
					--BackgroundColor = ARGB(255, 0, 0, 255),
				},
				--花费的勋章
				Gui.Label "lbl_spend_point"
				{
					Size = Vector2(151, 21),
					--Text = lang:GetText("500FC点"),
					Font = "simhei",
					FontSize = 16,
					Location = Vector2(296, 334),
					BackgroundColor = ARGB(255, 255, 255, 255),
					TextColor = ARGB(255, 37, 37, 37),
					TextAlign = "kAlignRightMiddle",
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_box_huafei.dds", Vector4(10, 10, 10, 10)),
					},
				},

				-- Gui.CheckBox "cbox_buy_and_equip"
				-- {
					-- Location = Vector2(32, 430),
					-- TextColor = ARGB(255, 207, 221, 230),
					-- Size = Vector2(24, 24),
					-- BackgroundColor = ARGB(255, 0, 0, 255),
					-- Check = is_buy_and_equip,
					-- Skin = Gui.CheckBoxSkin
					-- {
						-- OnImage = Gui.Image("LobbyUI/mail/lb_contact_checkbox_down.dds", Vector4(0, 0, 0, 0)),
						-- OffImage = Gui.Image("LobbyUI/mail/lb_contact_checkbox_normal.dds", Vector4(0, 0, 0, 0)),
					-- },
					-- EventCheckChanged = function()
						-- is_buy_and_equip = not is_buy_and_equip
					-- end
				-- },
				-- Gui.Label "lbl_buy_and_equip"
				-- {
					-- Size = Vector2(123, 21),
					-- Text = lang:GetText("购买完直接装备"),
					-- Font = "simhei",
					-- FontSize = 16,
					-- TextColor = ARGB(255, 37, 37, 37),
					-- Location = Vector2(62, 430),
				-- },

				--兑换
				Gui.Button "btn_buy"
				{
					Size = Vector2(104, 36),
					Location = Vector2(244, 424),
					Text = lang:GetText("兑换"),
					TextAlign = "kAlignCenterMiddle",
					Padding = Vector4(0, 0, 0, 6),
					TextColor = ARGB(255, 211, 211, 211),
					Font = "simhei",
					FontSize = 20,
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/lb_contact_button_normal.dds", Vector4(0, 0, 0, 0)),
						HoverImage = Gui.Image("LobbyUI/team/lb_contact_button_hover.dds", Vector4(0, 0, 0, 0)),
						DownImage = Gui.Image("LobbyUI/team/lb_contact_button_down.dds", Vector4(0, 0, 0, 0)),
						DisabledImage = Gui.Image("LobbyUI/team/lb_contact_button_normal.dds", Vector4(0, 0, 0, 0)),
					},
					EventClick = function()
						--购买
						if present_list then
							local weapon_info = present_list[current_selected_ibtn_index]		
							if view_present_window_ui.btn_match.PushDown == false and weapon_info.medalprices[1] then
								Buy_FreeGoods(ptr_cast(game.CurrentState):GetCharacterId(), weapon_info.sid, weapon_info.medalprices[cost_mode].id)
							elseif view_present_window_ui.btn_match.PushDown == false and weapon_info.revivecoins[1] then
								Buy_FreeGoods(ptr_cast(game.CurrentState):GetCharacterId(), weapon_info.sid, weapon_info.revivecoins[cost_mode].id)
							elseif view_present_window_ui.btn_match.PushDown == true and weapon_info.achipcoins[1] then
								Buy_FreeGoods(ptr_cast(game.CurrentState):GetCharacterId(), weapon_info.sid, weapon_info.achipcoins[cost_mode].id)
							elseif view_present_window_ui.btn_match.PushDown == true and weapon_info.bchipcoins[1] then
								Buy_FreeGoods(ptr_cast(game.CurrentState):GetCharacterId(), weapon_info.sid, weapon_info.bchipcoins[cost_mode].id)
							elseif view_present_window_ui.btn_match.PushDown == true and weapon_info.cchipcoins[1] then
								Buy_FreeGoods(ptr_cast(game.CurrentState):GetCharacterId(), weapon_info.sid, weapon_info.cchipcoins[cost_mode].id)
							end
						end	
						if buy_and_present_window_page.lbl_present_to.Visible == true and current_select_firend_index == -1 then
							return
						end	
					end
				},
				--取消
				Gui.Button "btn_cancel"
				{
					Size = Vector2(106, 36),
					Location = Vector2(356, 424),
					Text = lang:GetText("取消"),
					TextAlign = "kAlignCenterMiddle",
					Padding = Vector4(0, 0, 0, 6),
					TextColor = ARGB(255, 211, 211, 211),
					FontSize = 20,
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ButtonSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/team/lb_contact_button_normal.dds", Vector4(0, 0, 0, 0)),
						HoverImage = Gui.Image("LobbyUI/team/lb_contact_button_hover.dds", Vector4(0, 0, 0, 0)),
						DownImage = Gui.Image("LobbyUI/team/lb_contact_button_down.dds", Vector4(0, 0, 0, 0)),
						DisabledImage = Gui.Image("LobbyUI/team/lb_contact_button_normal.dds", Vector4(0, 0, 0, 0)),
					},
					EventClick = function()
						CloseBuyWin()
					end
				},
			},
			--兑换结算
			Gui.Button "btn_buy_and_balance"
			{
				Size = Vector2(125, 28),
				Location = Vector2(35, 20),
				Text = lang:GetText("兑换结算"),
				TextColor = ARGB(255, 255, 0, 0),
				HighlightTextColor = ARGB(255, 242, 242, 242),
				Font = "simhei",
				FontSize = 16,
				Enable = false,
				DisabledTextColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_tab1_normal.dds", Vector4(10, 0, 10, 0)),
					HoverImage = Gui.Image("LobbyUI/Friends/lb_contact_tab1_hover.dds", Vector4(10, 0, 10, 0)),
					DownImage = Gui.Image("LobbyUI/Friends/lb_contact_tab1_down.dds", Vector4(10, 0, 10, 0)),
					DisabledImage = Gui.Image("LobbyUI/Friends/lb_contact_tab1_down.dds", Vector4(10, 0, 10, 0)),
				},
				EventClick = function()
					if buy_and_present_window_page then
						--buy_and_present_ui.lbl_spend_point.Text = L_LobbyMain.free_goods_rpc_data.items[current_selected_ibtn_index].gpprices[cost_mode].cost..lang:GetText("C币")
						buy_and_present_window_page.btn_buy_and_balance.PushDown = false
						buy_and_present_window_page.btn_buy_and_present.Visible = false
						buy_and_present_window_page.btn_buy.Text = lang:GetText("兑换")
						buy_and_present_window_page.lbl_present_to.Visible = false
						buy_and_present_window_page.cbx_friends_present.Visible = false
						buy_and_present_window_page.lbl_balance_mode.Location = Vector2(118, 5)
						buy_and_present_window_page.btn_front_page.Location = Vector2(213, 7)
						buy_and_present_window_page.lb_page_number.Location = Vector2(246, 8)
						buy_and_present_window_page.btn_next_page.Location = Vector2(317, 7)
						local weapon_info = present_list[current_selected_ibtn_index]
						-- if weapon_info.common.type < 4 then
							-- buy_and_present_window_page.cbox_buy_and_equip.Visible = true
							-- buy_and_present_window_page.lbl_buy_and_equip.Visible = true
						-- else
							-- buy_and_present_window_page.cbox_buy_and_equip.Visible = false
							-- buy_and_present_window_page.lbl_buy_and_equip.Visible = false
						-- end
					end
					buy_and_present_window_page.btn_three_days.PushDown = true
					buy_and_present_window_page.btn_senven_days.PushDown = false
					buy_and_present_window_page.btn_thirty_days.PushDown = false
					buy_and_present_window_page.btn_forever.PushDown = false			
				end
			},
		},
	},
}


function show()
	local args = {pid = ptr_cast(game.CurrentState):GetCharacterId(),page = 1}
	rpc.safecall("shop_exchange_list", args, 
	function (data)
		if data.warning then
			MessageBox.ShowWithTimer(1,data.warning)
		else
			present_page = data.page
			present_list = data.items
			xunzhang_num = data.chipNum
			reviceCoinNum = data.reviceCoinNum
			A_num = data.aChipNum
			B_num = data.bChipNum
			C_num = data.cChipNum
			last_page = data.pages
			ShowViewPresentWindow()
		end
	end)
end

function ShowViewPresentWindow()
	print("ShowViewPresentWindow()")
	if view_present_window_ui == nil then
		view_present_window_ui = Gui.Create()(view_freeChange_window)
	end
	--免费兑换商城初始化
	if ViewPresent_Window and ViewPresent_Window.screen then
		ViewPresent_Window.screen.Visible = false
	end
	ViewPresent_Window = ModalWindow.GetNew("view_present_window_ui")
	ViewPresent_Window.screen.AllowEscToExit = false
	ViewPresent_Window.screen.Visible = false
	ViewPresent_Window.root.Size = Vector2(1200,900)
	ViewPresent_Window.screen.EventEscPressed = HideViewPresentWindow
	view_present_window_ui.ctrl_view_present_window.Parent = ViewPresent_Window.root
	
	if ViewPresent_Window and ViewPresent_Window.screen then
		ViewPresent_Window.screen.Visible = true
		gui.EventEscPressed = HideViewPresentWindow
	end
	
	FillViewPresent()
	FillViewPresent1()
end

function HideViewPresentWindow()
	if ViewPresent_Window and ViewPresent_Window.screen then
		ViewPresent_Window.screen.Visible = false
		view_present_window_ui = nil
	end
end


function FillViewPresent()

	if view_present_window_ui == nil then
		return
	end
	if present_page == last_page then
		view_present_window_ui.bt_view_present_next.Visible = false
	else
		view_present_window_ui.bt_view_present_next.Visible = true
	end
									
	if present_page == 1 then
		view_present_window_ui.bt_view_present_prev.Visible = false
	else
		view_present_window_ui.bt_view_present_prev.Visible = true
	end
	
	view_present_window_ui.xunzhang_num.Text = xunzhang_num
	view_present_window_ui.reviceCoinNum.Text = reviceCoinNum

	view_present_window_ui.ctr_persent:OnDestroy()
	-- view_present_window_ui.ctr_persent1:OnDestroy()
	local numTep = 1
	for i = 0 , 4 do
		for j = 0 , 3 do
			CreatePresentBTN(j,i,numTep,view_present_window_ui.ctr_persent)
			numTep = numTep + 1
		end
	end
	
	
	local vip_index = 0
	local nol_index = 0
	
	for i = 1, 20 do
		ibbtn = ptr_cast(view_present_window_ui.ctr_persent:GetChildByIndex(i - 1))
		ibbtn.ItemIcon = nil
		ibbtn.BtnVisible = false
		local v = ptr_cast(ibbtn:GetChildByIndex(4))
		v.Visible = false
	end
	
	for i = 1 , 20 do
		local ibbtn
		if present_list[i] and present_list[i].common.is_vip == 0 and (present_list[i].medalprices[1] or present_list[i].revivecoins[1]) then
			ibbtn = ptr_cast(view_present_window_ui.ctr_persent:GetChildByIndex(nol_index))
			ibbtn.IntTag = i
			nol_index = nol_index + 1
			local v = ptr_cast(ibbtn:GetChildByIndex(4))
			v.Visible = false
		elseif present_list[i] and (present_list[i].medalprices[1] or present_list[i].revivecoins[1]) then
			ibbtn = ptr_cast(view_present_window_ui.ctr_persent:GetChildByIndex(vip_index + 12))
			ibbtn.IntTag = i
			vip_index = vip_index + 1
			local v = ptr_cast(ibbtn:GetChildByIndex(4))
			v.Visible = true
			if present_list[i].common.is_vip > L_Vip.Viplevel then
				v.Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_button_0"..present_list[i].common.is_vip.."_disabled.dds", Vector4(0, 0, 0, 0)),
				}
				
			else
				v.Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_button_0"..present_list[i].common.is_vip.."_normal.dds", Vector4(0, 0, 0, 0)),
				}
			end
		end
		
		--赠送按钮隐藏掉，以后要用的话放开一行代码
		--local newbutton = SpawnNewFreeChangeButton()
		
		--ibbtn:OnDestroy()
			if present_list[i] and (present_list[i].medalprices[1] or present_list[i].revivecoins[1]) then
				if present_list[i].color >= 1 and present_list[i].color <= 8 then
					ibbtn.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..present_list[i].name.."_"..present_list[i].color..".tga")
				else
					ibbtn.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..present_list[i].name..".tga")
				end	
				if present_list[i].common.rareLevel then
					ibbtn.ItemLevel = Skin.rarelevel[math.ceil(present_list[i].common.rareLevel/25)]
				end
				--赠送按钮隐藏掉，以后要用的话放开一行代码
				--newbutton.ib_donate.Parent = ibbtn
							
				ibbtn.BtnVisible = true
			end
	end
end

function FillViewPresent1()

	if view_present_window_ui == nil then
		return
	end
	if present_page == last_page then
		view_present_window_ui.bt_view_present_next.Visible = false
	else
		view_present_window_ui.bt_view_present_next.Visible = true
	end
									
	if present_page == 1 then
		view_present_window_ui.bt_view_present_prev.Visible = false
	else
		view_present_window_ui.bt_view_present_prev.Visible = true
	end
	
	view_present_window_ui.xunzhang_num.Text = xunzhang_num
	view_present_window_ui.reviceCoinNum.Text = reviceCoinNum
	view_present_window_ui.ANum1.Text = A_num
	view_present_window_ui.BNum1.Text = B_num
	view_present_window_ui.CNum1.Text = C_num
	-- view_present_window_ui.ctr_persent:OnDestroy()
	view_present_window_ui.ctr_persent1:OnDestroy()
	local numTep = 1
	for i = 0 , 1 do
		for j = 0 , 3 do
			CreatePresentBTN1(j,i,numTep,view_present_window_ui.ctr_persent1)
			numTep = numTep + 1
		end
	end
	local vip_index = 0
	local nol_index = 0
	
	for i = 1, 8 do
		ibbtn = ptr_cast(view_present_window_ui.ctr_persent1:GetChildByIndex(i - 1))
		ibbtn.ItemIcon = nil
		ibbtn.BtnVisible = false
		local v = ptr_cast(ibbtn:GetChildByIndex(1))
		v.Visible = false
	end
	
	for i = 1 , 20 do
		local ibbtn
		if  present_list[i] and (present_list[i].achipcoins[1] or  present_list[i].bchipcoins[1] or  present_list[i].cchipcoins[1]) then
			ibbtn = ptr_cast(view_present_window_ui.ctr_persent1:GetChildByIndex(nol_index))
			ibbtn.IntTag = i
			nol_index = nol_index + 1
			local v = ptr_cast(ibbtn:GetChildByIndex(1))
			v.Visible = false
		-- elseif present_list[i] then
			-- ibbtn = ptr_cast(view_present_window_ui.ctr_persent1:GetChildByIndex(vip_index + 12))
			-- ibbtn.IntTag = i
			-- vip_index = vip_index + 1
			-- local v = ptr_cast(ibbtn:GetChildByIndex(1))
			-- v.Visible = true
			-- if present_list[i].common.is_vip > L_Vip.Viplevel then
				-- v.Skin = Gui.ControlSkin
				-- {
					-- BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_button_0"..present_list[i].common.is_vip.."_disabled.dds", Vector4(0, 0, 0, 0)),
				-- }
				
			-- else
				-- v.Skin = Gui.ControlSkin
				-- {
					-- BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_button_0"..present_list[i].common.is_vip.."_normal.dds", Vector4(0, 0, 0, 0)),
				-- }
			-- end
		end
		
		--赠送按钮隐藏掉，以后要用的话放开一行代码
		--local newbutton = SpawnNewFreeChangeButton()
		
		
		if present_list[i] and  (present_list[i].achipcoins[1] or  present_list[i].bchipcoins[1] or  present_list[i].cchipcoins[1]) then
			-- ibbtn:OnDestroy()
			if present_list[i].color >= 1 and present_list[i].color <= 8 then
				ibbtn.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..present_list[i].name.."_"..present_list[i].color..".tga")
			else
				ibbtn.ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..present_list[i].name..".tga")
			end	
			if present_list[i].common.rareLevel then
				ibbtn.ItemLevel = Skin.rarelevel[math.ceil(present_list[i].common.rareLevel/25)]
			end
			--赠送按钮隐藏掉，以后要用的话放开一行代码
			--newbutton.ib_donate.Parent = ibbtn
						
			ibbtn.BtnVisible = true
		end
	end
end
--填充好友界面
function FillBuyAndPresentWindow()
	print("FillBuyAndPresentWindow()")
	if buy_and_present_window_page then
		local num = nil
		local btn_group = nil
		num, btn_group = L_LobbyMain.GetShoppingMallBottonGroup()
		if num ~= nil and btn_group ~= nil then
			local ibbtn = ptr_cast(btn_group:GetChildByIndex(current_selected_ibtn_index-1))
			if ibbtn ~= nil then
				local b_denote = ptr_cast(ibbtn:GetChildByIndex(2))
				if b_denote ~= nil then
					buy_and_present_window_page.btn_buy_and_present.Visible = false
				end
			end
		end

		buy_and_present_window_page.lbl_present_to.Visible = false
		buy_and_present_window_page.cbx_friends_present.Visible = false
		buy_and_present_window_page.lbl_balance_mode.Location = Vector2(108, 6)
		buy_and_present_window_page.btn_front_page.Location = Vector2(666, 458)
		buy_and_present_window_page.lb_page_number.Location = Vector2(310, 9)
		buy_and_present_window_page.btn_next_page.Location = Vector2(400, 9)
		
		buy_and_present_window_page.lbl_spend_point.Text = ""
		buy_and_present_window_page.btn_buy_and_balance.PushDown = false
		buy_and_present_window_page.btn_buy_and_present.Visible = false
		--buy_and_present_window_page.cbox_buy_and_equip.Visible = true
		--buy_and_present_window_page.lbl_buy_and_equip.Visible = true
		buy_and_present_window_page.btn_buy.Text = lang:GetText("兑换")
		
		if present_list then
			-- if L_LobbyMain.PersonalInfo_data then
				-- -- FC点
				
				-- -- C币
				-- buy_and_present_window_page.lbl_balance_GP.Text = L_LobbyMain.PersonalInfo_data.newGP .. " " .. price_way[2]
				-- -- 抵用券
				-- buy_and_present_window_page.lbl_balance_ticket.Text = L_LobbyMain.PersonalInfo_data.newTicket .. " " .. price_way[3]				
			-- end
			cost_mode = 1
			if  view_present_window_ui.btn_match.PushDown == false and present_list[current_selected_ibtn_index].medalprices[cost_mode] then
				current_selected_price_way = 1
				print("view_present_window_ui.btn_match.PushDown : " , view_present_window_ui.btn_match.PushDown)
				if present_list[current_selected_ibtn_index].medalprices[cost_mode].cost > xunzhang_num then
					buy_and_present_window_page.lbl_spend_point.TextColor = ARGB(255, 255, 0, 0)
				else
					buy_and_present_window_page.lbl_spend_point.TextColor = ARGB(255, 37, 37, 37)
				end
			elseif view_present_window_ui.btn_match.PushDown == false and present_list[current_selected_ibtn_index].revivecoins[cost_mode] then
				current_selected_price_way = 2
				if present_list[current_selected_ibtn_index].revivecoins[cost_mode].cost > reviceCoinNum then
					buy_and_present_window_page.lbl_spend_point.TextColor = ARGB(255, 255, 0, 0)
				else
					buy_and_present_window_page.lbl_spend_point.TextColor = ARGB(255, 37, 37, 37)
				end
			elseif view_present_window_ui.btn_match.PushDown == true and present_list[current_selected_ibtn_index].achipcoins[cost_mode] then
				current_selected_price_way = 3
				print("view_present_window_ui.btn_match.PushDown : " , view_present_window_ui.btn_match.PushDown)
				print("present_list[current_selected_ibtn_index].achipcoins[cost_mode] : " , present_list[current_selected_ibtn_index].achipcoins[cost_mode])
				if present_list[current_selected_ibtn_index].achipcoins[cost_mode].cost > A_num then
					buy_and_present_window_page.lbl_spend_point.TextColor = ARGB(255, 255, 0, 0)
				else
					buy_and_present_window_page.lbl_spend_point.TextColor = ARGB(255, 37, 37, 37)
				end
			elseif view_present_window_ui.btn_match.PushDown == true and present_list[current_selected_ibtn_index].bchipcoins[cost_mode] then
				current_selected_price_way = 4
				if present_list[current_selected_ibtn_index].bchipcoins[cost_mode].cost > B_num then
					buy_and_present_window_page.lbl_spend_point.TextColor = ARGB(255, 255, 0, 0)
				else
					buy_and_present_window_page.lbl_spend_point.TextColor = ARGB(255, 37, 37, 37)
				end
			elseif view_present_window_ui.btn_match.PushDown == true and present_list[current_selected_ibtn_index].cchipcoins[cost_mode] then
				current_selected_price_way = 5
				if present_list[current_selected_ibtn_index].cchipcoins[cost_mode].cost > C_num then
					buy_and_present_window_page.lbl_spend_point.TextColor = ARGB(255, 255, 0, 0)
				else
					buy_and_present_window_page.lbl_spend_point.TextColor = ARGB(255, 37, 37, 37)
				end
			end
			
			--buy_and_present_window_page.lbl_spend_GP.TextColor = ARGB(255, 37, 37, 37)
			--buy_and_present_window_page.lbl_spend_ticket.TextColor = ARGB(255, 37, 37, 37)
			if view_present_window_ui.btn_match.PushDown == false and present_list[current_selected_ibtn_index].medalprices[1] then
				buy_and_present_window_page.lbl_balance_point.Text = xunzhang_num .. " " .. price_way[current_selected_price_way]
			elseif view_present_window_ui.btn_match.PushDown == false and present_list[current_selected_ibtn_index].revivecoins[1] then
				buy_and_present_window_page.lbl_balance_point.Text = reviceCoinNum .. " " .. price_way[current_selected_price_way]
			elseif view_present_window_ui.btn_match.PushDown == true and present_list[current_selected_ibtn_index].achipcoins[1] then
				buy_and_present_window_page.lbl_balance_point.Text = A_num .. " " .. price_way[current_selected_price_way]
			elseif view_present_window_ui.btn_match.PushDown == true and present_list[current_selected_ibtn_index].bchipcoins[1] then
				buy_and_present_window_page.lbl_balance_point.Text = B_num .. " " .. price_way[current_selected_price_way]
			elseif view_present_window_ui.btn_match.PushDown == true and present_list[current_selected_ibtn_index].cchipcoins[1] then
				buy_and_present_window_page.lbl_balance_point.Text = C_num .. " " .. price_way[current_selected_price_way]
			end
			buy_and_present_window_page.lbl_spend_point.Text = "0 " .. price_way[current_selected_price_way]
						
			local weapon_info = present_list[current_selected_ibtn_index]			
			if weapon_info then
				if weapon_info.common.type == 1 then
					buy_and_present_window_page.ctrl_goods_image.Size = Vector2(128, 64)
					buy_and_present_window_page.ctrl_goods_image_root.Size = Vector2(160, 156)
				elseif weapon_info.common.type == 2 then
					buy_and_present_window_page.ctrl_goods_image.Size = Vector2(100, 195)
					buy_and_present_window_page.ctrl_goods_image_root.Size = Vector2(160, 195)
				elseif weapon_info.common.type == 3 then
					buy_and_present_window_page.ctrl_goods_image.Size = Vector2(100, 96)
					buy_and_present_window_page.ctrl_goods_image_root.Size = Vector2(160, 156)
				else
					buy_and_present_window_page.ctrl_goods_image.Size = Vector2(100, 96)
					buy_and_present_window_page.ctrl_goods_image_root.Size = Vector2(160, 156)
				end
				
				-- --取消购买并装备
				-- if 	weapon_info.common.type > 3 then
					-- buy_and_present_window_page.lbl_buy_and_equip.Visible = false
					-- buy_and_present_window_page.cbox_buy_and_equip.Visible = false
					-- buy_and_present_window_page.lbl_buy_and_equip.Text = lang:GetText("购买完直接使用")
				-- else
					-- buy_and_present_window_page.lbl_buy_and_equip.Visible = true
					-- buy_and_present_window_page.cbox_buy_and_equip.Visible = true
					-- buy_and_present_window_page.lbl_buy_and_equip.Text = lang:GetText("购买完直接装备")
				-- end
				local color = weapon_info.color
				local name = weapon_info.name
				if color >= 1 and color <= 8 then
					buy_and_present_window_page.ctrl_goods_image.Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ibt_icon/"..name.."_"..color..".tga", Vector4(0, 0, 0, 0)),
					}
				else
					buy_and_present_window_page.ctrl_goods_image.Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ibt_icon/"..name..".tga", Vector4(0, 0, 0, 0)),
					}
				end
				buy_and_present_window_page.lbl_goods_name.Text = weapon_info.display
				buy_and_present_window_page.lbl_goods_info.Text = weapon_info.description

				--付款方式
				local mode1 = weapon_info.medalprices
				
				--勋章
				--FC点
				if view_present_window_ui.btn_match.PushDown == false and mode1[1] then
					if mode1[1] then
						current_selected_price_way = 1
						buy_and_present_window_page.lbl_spend_point.Text = present_list[current_selected_ibtn_index].medalprices[1].cost .. " " .. price_way[current_selected_price_way]
						if mode1[1].unittype == 0 then
							buy_and_present_window_page.btn_three_days.Text = unittype_way[mode1[1].unittype + 1]
						else
							buy_and_present_window_page.btn_three_days.Text = mode1[1].unit..unittype_way[mode1[1].unittype + 1]
						end
						buy_and_present_window_page.btn_three_days.Visible = true
					else
						buy_and_present_window_page.btn_three_days.Visible = false
					end

					if mode1[2] then
						if mode1[2].unittype == 0 then
							buy_and_present_window_page.btn_senven_days.Text = unittype_way[mode1[2].unittype + 1]
						else
							buy_and_present_window_page.btn_senven_days.Text = mode1[2].unit..unittype_way[mode1[2].unittype + 1]
						end
						buy_and_present_window_page.btn_senven_days.Visible = true
					else
						buy_and_present_window_page.btn_senven_days.Visible = false
					end

					if mode1[3] then
						if mode1[2].unittype == 0 then
							buy_and_present_window_page.btn_thirty_days.Text = unittype_way[mode1[3].unittype + 1]
						else
							buy_and_present_window_page.btn_thirty_days.Text = mode1[3].unit..unittype_way[mode1[3].unittype + 1]
						end
						buy_and_present_window_page.btn_thirty_days.Visible = true
					else
						buy_and_present_window_page.btn_thirty_days.Visible = false
					end

					if mode1[4] then
						if mode1[4].unittype == 0 then
							buy_and_present_window_page.btn_forever.Text = unittype_way[mode1[4].unittype + 1]
						else
							buy_and_present_window_page.btn_forever.Text = mode1[4].unit..unittype_way[mode1[4].unittype + 1]
						end
						buy_and_present_window_page.btn_forever.Visible = true
					else
						buy_and_present_window_page.btn_forever.Visible = false
					end
				end
				
				mode1 = weapon_info.revivecoins
				
				--勋章
				--FC点
				if view_present_window_ui.btn_match.PushDown == false and mode1[1] then
					if mode1[1] then
						current_selected_price_way = 2
						buy_and_present_window_page.lbl_spend_point.Text = present_list[current_selected_ibtn_index].revivecoins[1].cost .. " " .. price_way[current_selected_price_way]
						if mode1[1].unittype == 0 then
							buy_and_present_window_page.btn_three_days.Text = unittype_way[mode1[1].unittype + 1]
						else
							buy_and_present_window_page.btn_three_days.Text = mode1[1].unit..unittype_way[mode1[1].unittype + 1]
						end
						buy_and_present_window_page.btn_three_days.Visible = true
					else
						buy_and_present_window_page.btn_three_days.Visible = false
					end

					if mode1[2] then
						if mode1[2].unittype == 0 then
							buy_and_present_window_page.btn_senven_days.Text = unittype_way[mode1[2].unittype + 1]
						else
							buy_and_present_window_page.btn_senven_days.Text = mode1[2].unit..unittype_way[mode1[2].unittype + 1]
						end
						buy_and_present_window_page.btn_senven_days.Visible = true
					else
						buy_and_present_window_page.btn_senven_days.Visible = false
					end

					if mode1[3] then
						if mode1[2].unittype == 0 then
							buy_and_present_window_page.btn_thirty_days.Text = unittype_way[mode1[3].unittype + 1]
						else
							buy_and_present_window_page.btn_thirty_days.Text = mode1[3].unit..unittype_way[mode1[3].unittype + 1]
						end
						buy_and_present_window_page.btn_thirty_days.Visible = true
					else
						buy_and_present_window_page.btn_thirty_days.Visible = false
					end

					if mode1[4] then
						if mode1[4].unittype == 0 then
							buy_and_present_window_page.btn_forever.Text = unittype_way[mode1[4].unittype + 1]
						else
							buy_and_present_window_page.btn_forever.Text = mode1[4].unit..unittype_way[mode1[4].unittype + 1]
						end
						buy_and_present_window_page.btn_forever.Visible = true
					else
						buy_and_present_window_page.btn_forever.Visible = false
					end
				end
				
				mode1 = weapon_info.achipcoins
				--A
				if view_present_window_ui.btn_match.PushDown == true and mode1[1] then
					if mode1[1] then
						current_selected_price_way = 3
						buy_and_present_window_page.lbl_spend_point.Text = present_list[current_selected_ibtn_index].achipcoins[1].cost .. " " .. price_way[current_selected_price_way]
						if mode1[1].unittype == 0 then
							buy_and_present_window_page.btn_three_days.Text = unittype_way[mode1[1].unittype + 1]
						else
							buy_and_present_window_page.btn_three_days.Text = mode1[1].unit..unittype_way[mode1[1].unittype + 1]
						end
						buy_and_present_window_page.btn_three_days.Visible = true
					else
						buy_and_present_window_page.btn_three_days.Visible = false
					end

					if mode1[2] then
						if mode1[2].unittype == 0 then
							buy_and_present_window_page.btn_senven_days.Text = unittype_way[mode1[2].unittype + 1]
						else
							buy_and_present_window_page.btn_senven_days.Text = mode1[2].unit..unittype_way[mode1[2].unittype + 1]
						end
						buy_and_present_window_page.btn_senven_days.Visible = true
					else
						buy_and_present_window_page.btn_senven_days.Visible = false
					end

					if mode1[3] then
						if mode1[2].unittype == 0 then
							buy_and_present_window_page.btn_thirty_days.Text = unittype_way[mode1[3].unittype + 1]
						else
							buy_and_present_window_page.btn_thirty_days.Text = mode1[3].unit..unittype_way[mode1[3].unittype + 1]
						end
						buy_and_present_window_page.btn_thirty_days.Visible = true
					else
						buy_and_present_window_page.btn_thirty_days.Visible = false
					end

					if mode1[4] then
						if mode1[4].unittype == 0 then
							buy_and_present_window_page.btn_forever.Text = unittype_way[mode1[4].unittype + 1]
						else
							buy_and_present_window_page.btn_forever.Text = mode1[4].unit..unittype_way[mode1[4].unittype + 1]
						end
						buy_and_present_window_page.btn_forever.Visible = true
					else
						buy_and_present_window_page.btn_forever.Visible = false
					end
				end
				
				mode1 = weapon_info.bchipcoins
				--B
				if view_present_window_ui.btn_match.PushDown == true and mode1[1] then
					if mode1[1] then
						current_selected_price_way = 4
						buy_and_present_window_page.lbl_spend_point.Text = present_list[current_selected_ibtn_index].bchipcoins[1].cost .. " " .. price_way[current_selected_price_way]
						if mode1[1].unittype == 0 then
							buy_and_present_window_page.btn_three_days.Text = unittype_way[mode1[1].unittype + 1]
						else
							buy_and_present_window_page.btn_three_days.Text = mode1[1].unit..unittype_way[mode1[1].unittype + 1]
						end
						buy_and_present_window_page.btn_three_days.Visible = true
					else
						buy_and_present_window_page.btn_three_days.Visible = false
					end

					if mode1[2] then
						if mode1[2].unittype == 0 then
							buy_and_present_window_page.btn_senven_days.Text = unittype_way[mode1[2].unittype + 1]
						else
							buy_and_present_window_page.btn_senven_days.Text = mode1[2].unit..unittype_way[mode1[2].unittype + 1]
						end
						buy_and_present_window_page.btn_senven_days.Visible = true
					else
						buy_and_present_window_page.btn_senven_days.Visible = false
					end

					if mode1[3] then
						if mode1[2].unittype == 0 then
							buy_and_present_window_page.btn_thirty_days.Text = unittype_way[mode1[3].unittype + 1]
						else
							buy_and_present_window_page.btn_thirty_days.Text = mode1[3].unit..unittype_way[mode1[3].unittype + 1]
						end
						buy_and_present_window_page.btn_thirty_days.Visible = true
					else
						buy_and_present_window_page.btn_thirty_days.Visible = false
					end

					if mode1[4] then
						if mode1[4].unittype == 0 then
							buy_and_present_window_page.btn_forever.Text = unittype_way[mode1[4].unittype + 1]
						else
							buy_and_present_window_page.btn_forever.Text = mode1[4].unit..unittype_way[mode1[4].unittype + 1]
						end
						buy_and_present_window_page.btn_forever.Visible = true
					else
						buy_and_present_window_page.btn_forever.Visible = false
					end
				end
				
				mode1 = weapon_info.cchipcoins
				--C
				if view_present_window_ui.btn_match.PushDown == true and mode1[1] then
					if mode1[1] then
						current_selected_price_way = 5
						buy_and_present_window_page.lbl_spend_point.Text = present_list[current_selected_ibtn_index].cchipcoins[1].cost .. " " .. price_way[current_selected_price_way]
						if mode1[1].unittype == 0 then
							buy_and_present_window_page.btn_three_days.Text = unittype_way[mode1[1].unittype + 1]
						else
							buy_and_present_window_page.btn_three_days.Text = mode1[1].unit..unittype_way[mode1[1].unittype + 1]
						end
						buy_and_present_window_page.btn_three_days.Visible = true
					else
						buy_and_present_window_page.btn_three_days.Visible = false
					end

					if mode1[2] then
						if mode1[2].unittype == 0 then
							buy_and_present_window_page.btn_senven_days.Text = unittype_way[mode1[2].unittype + 1]
						else
							buy_and_present_window_page.btn_senven_days.Text = mode1[2].unit..unittype_way[mode1[2].unittype + 1]
						end
						buy_and_present_window_page.btn_senven_days.Visible = true
					else
						buy_and_present_window_page.btn_senven_days.Visible = false
					end

					if mode1[3] then
						if mode1[2].unittype == 0 then
							buy_and_present_window_page.btn_thirty_days.Text = unittype_way[mode1[3].unittype + 1]
						else
							buy_and_present_window_page.btn_thirty_days.Text = mode1[3].unit..unittype_way[mode1[3].unittype + 1]
						end
						buy_and_present_window_page.btn_thirty_days.Visible = true
					else
						buy_and_present_window_page.btn_thirty_days.Visible = false
					end

					if mode1[4] then
						if mode1[4].unittype == 0 then
							buy_and_present_window_page.btn_forever.Text = unittype_way[mode1[4].unittype + 1]
						else
							buy_and_present_window_page.btn_forever.Text = mode1[4].unit..unittype_way[mode1[4].unittype + 1]
						end
						buy_and_present_window_page.btn_forever.Visible = true
					else
						buy_and_present_window_page.btn_forever.Visible = false
					end
				end
			
				buy_and_present_window_page.lb_page_number.Text = price_way[current_selected_price_way]
			end
		end
	end
end

function FillPresentWindow()
	if buy_and_present_window_page then
		buy_and_present_window_page.cbx_friends_present:RemoveAll()
		current_select_firend_index = -1
		for _,v in ipairs(L_LobbyMain.Friends_rpc_data) do
			if v[1]then
				buy_and_present_window_page.cbx_friends_present:AddItem(v[3])
			end
		end
		
		if present_list then			
			--勋章
			buy_and_present_window_page.lbl_balance_point.Text = xunzhang_num .. " " .. price_way[1]					
			buy_and_present_window_page.lbl_spend_point.Text = "0 " .. price_way[1]

			cost_mode = 1
			
			local weapon_info = present_list[current_selected_ibtn_index]			
			if weapon_info then
				if weapon_info.common.type == 1 then
					buy_and_present_window_page.ctrl_goods_image.Size = Vector2(128, 64)
					buy_and_present_window_page.ctrl_goods_image_root.Size = Vector2(160, 156)
				elseif weapon_info.common.type == 2 then
					buy_and_present_window_page.ctrl_goods_image.Size = Vector2(100, 195)
					buy_and_present_window_page.ctrl_goods_image_root.Size = Vector2(160, 195)
				elseif weapon_info.common.type == 3 then
					buy_and_present_window_page.ctrl_goods_image.Size = Vector2(100, 96)
					buy_and_present_window_page.ctrl_goods_image_root.Size = Vector2(160, 156)
				else
					buy_and_present_window_page.ctrl_goods_image.Size = Vector2(100, 96)
					buy_and_present_window_page.ctrl_goods_image_root.Size = Vector2(160, 156)
				end
				
				local color = weapon_info.color
				local name = weapon_info.name
				if color >= 1 and color <= 8 then
					buy_and_present_window_page.ctrl_goods_image.Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ibt_icon/"..name.."_"..color..".tga", Vector4(0, 0, 0, 0)),
					}
				else
					buy_and_present_window_page.ctrl_goods_image.Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/ibt_icon/"..name..".tga", Vector4(0, 0, 0, 0)),
					}
				end
				
				buy_and_present_window_page.lbl_goods_name.Text = weapon_info.display
				buy_and_present_window_page.lbl_goods_info.Text = weapon_info.description

				--付款方式
				local mode1 = weapon_info.medalprices

				--FC点
				if mode1[1] then
					if mode1[1] then
						current_selected_price_way = 1
						buy_and_present_window_page.lbl_spend_point.Text = present_list[current_selected_ibtn_index].medalprices[1].cost .. " " .. price_way[1]
						if mode1[1].unittype == 0 then
							buy_and_present_window_page.btn_three_days.Text = unittype_way[mode1[1].unittype + 1]
						else
							buy_and_present_window_page.btn_three_days.Text = mode1[1].unit..unittype_way[mode1[1].unittype + 1]
						end
						buy_and_present_window_page.btn_three_days.Visible = true
					else
						buy_and_present_window_page.btn_three_days.Visible = false
					end

					if mode1[2] then
						if mode1[2].unittype == 0 then
							buy_and_present_window_page.btn_senven_days.Text = unittype_way[mode1[2].unittype + 1]
						else
							buy_and_present_window_page.btn_senven_days.Text = mode1[2].unit..unittype_way[mode1[2].unittype + 1]
						end
						buy_and_present_window_page.btn_senven_days.Visible = true
					else
						buy_and_present_window_page.btn_senven_days.Visible = false
					end

					if mode1[3] then
						if mode1[3].unittype == 0 then
							buy_and_present_window_page.btn_thirty_days.Text = unittype_way[mode1[3].unittype + 1]
						else
							buy_and_present_window_page.btn_thirty_days.Text = mode1[3].unit..unittype_way[mode1[3].unittype + 1]
						end
						buy_and_present_window_page.btn_thirty_days.Visible = true
					else
						buy_and_present_window_page.btn_thirty_days.Visible = false
					end

					if mode1[4] then
						if mode1[4].unittype == 0 then
							buy_and_present_window_page.btn_forever.Text = unittype_way[mode1[4].unittype + 1]
						else
							buy_and_present_window_page.btn_forever.Text = mode1[4].unit..unittype_way[mode1[4].unittype + 1]
						end
						buy_and_present_window_page.btn_forever.Visible = true
					else
						buy_and_present_window_page.btn_forever.Visible = false
					end
				end
			
				buy_and_present_window_page.lb_page_number.Text = price_way[current_selected_price_way]
			end
		end
	end
end

function CloseBuyWin()
	print("CloseBuyWin()")
	if buy_and_present_ui then
		buy_and_present_ui.Close()
		buy_and_present_ui = nil
		resetFreeChange()
	end
end

function resetFreeChange()
	local args = {pid = ptr_cast(game.CurrentState):GetCharacterId(),page = 1}
	rpc.safecall("shop_exchange_list", args, 
	function (data)
		xunzhang_num = data.chipNum
		reviceCoinNum = data.reviceCoinNum
		A_num = data.aChipNum
		B_num = data.bChipNum
		C_num = data.cChipNum

		if view_present_window_ui then		
			view_present_window_ui.xunzhang_num.Text = data.chipNum
			view_present_window_ui.reviceCoinNum.Text = data.reviceCoinNum
			view_present_window_ui.ANum1.Text = A_num
			view_present_window_ui.BNum1.Text = B_num
			view_present_window_ui.CNum1.Text = C_num			
		end	
	end)
end

function Buy_FreeGoods(p_id, s_id, cost_id)
	print("======================Buy_Goods()")
	L_MessageBox.ShowWaiter(lang:GetText("正在购买商品..."))
	rpc.safecall("shop_req_exchange", {pid = p_id, sid = s_id, costid = cost_id},
	function (data)
		local SuccessMsg = data.successMsg
		local Error = data.error
		if SuccessMsg then
			MessageBox.ShowWithConfirm(SuccessMsg)
			if gui then
				gui:PlayAudio("kUIA_BUY_SUCCESS")
			end
			CloseBuyWin()
		else
			if Error then
				MessageBox.ShowWithConfirm(Error)
			else
				MessageBox.ShowWithTimer(1, lang:GetText("购买成功"))
				if gui then
					gui:PlayAudio("kUIA_BUY_SUCCESS")
				end
				CloseBuyWin()
			end
		end
		L_MessageBox.CloseWaiter()
	end)
end