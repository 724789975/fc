module("L_Options", package.seeall)

function Initialize()
	print("=================L_Options Initialize()")
end

function Finalize()
	print("=================L_Options Finalize()")
end

function Show(parent_win)
	print("=================L_Options Show()")
end

function Hide()
	print("=================L_Options Hide()")
end