module("L_Characters_tab", package.seeall)

local function GetButton(i,pushdown)
	return Gui.Button ("tab_btn_"..i)
	{
		Size = Vector2(140, 48),
		Location = Vector2(1, 10+(48+8)*(i-1)),
		Visible = false,
		Enable = false,
		PushDown = pushdown,
	}
end

--���н���ѡ�������TAB
function create_tab_characters_windows(location)
	return Gui.Control "ctrl_Class_BG"
	{
		Size = Vector2(140, 544),
		Location = location,
		BackgroundColor = ARGB(0, 255, 255, 255),
		GetButton(1,true),
		GetButton(2,false),
		GetButton(3,false),
		GetButton(4,false),
		GetButton(5,false),
		GetButton(6,false),
		GetButton(7,false),
		GetButton(8,false),
		GetButton(9,false),
		GetButton(10,false),
	}
end