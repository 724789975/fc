-- state
local state =  ptr_cast(game.CurrentState, "Client.StateMainGame")

if not state then
	return
end

local escWindow = nil
local selectWindow = nil
local WebWindow = nil
local selectWeaponWindow = nil
local selectindex = 0
local selectweaponindex = 0
local select_txt_to_key = {}
local select_botton = {}
local select_weapon_botton = {}
local redio_id = 1
local Report_name = nil
local Report_Person_Num = 0

local edit_gun_info = nil

local line_count = {0, 0, 0}

WebWin = Gui.Create()
{
	Gui.Control "web_Window"
	{	
		Size = Vector2(606, 451),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Location = Vector2(0, 0),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("faq/lb_contact_bg1.dds", Vector4(25, 25, 25, 25)),
		},
		
		Gui.Control "bg_1"
		{
			Size = Vector2(586,431),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Location = Vector2(10, 10),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("faq/lb_contact_bg2.dds", Vector4(16, 12, 16, 45)),
			},
				
			Gui.Label "biaoti"
			{
				Size = Vector2(127, 25),
				Location = Vector2(5, 109),
				Text = lang:GetText("*标题:"),
				TextAlign = "kAlignRightMiddle",
				FontSize = 14,
				TextColor = ARGB(255, 37, 37, 37),
			},
			
			Gui.Textbox "biaoti_box"
			{
				Size = Vector2(429, 25),
				Location = Vector2(140, 109),
				Text = "",
				TextColor = ARGB(255, 37, 37, 37),
				BackgroundColor = ARGB(255, 255, 255, 255),
				FontSize = 14,
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("faq/lb_chat_bg4_normal.tga", Vector4(8, 8, 8, 8)),
				},
				MaxLength = 50,
			},
			
			Gui.Label "qhao"
			{
				Size = Vector2(127, 25),
				Location = Vector2(5, 139),
				Text = lang:GetText("q号:"),
				TextAlign = "kAlignRightMiddle",
				FontSize = 14,
				TextColor = ARGB(255, 37, 37, 37),
			},
			
			Gui.Textbox "qhao_box"
			{
				Size = Vector2(163, 25),
				Location = Vector2(140, 139),
				Text = "",
				TextColor = ARGB(255, 37, 37, 37),
				BackgroundColor = ARGB(255, 255, 255, 255),
				FontSize = 14,
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("faq/lb_chat_bg4_normal.tga", Vector4(8, 8, 8, 8)),
				},
				MaxLength = 20,
			},
			
			Gui.Label "shouji"
			{
				Size = Vector2(87, 25),
				Location = Vector2(310, 139),
				Text = lang:GetText("手机号:"),
				TextAlign = "kAlignRightMiddle",
				FontSize = 14,
				TextColor = ARGB(255, 37, 37, 37),
			},
			
			Gui.Textbox "shouji_box"
			{
				Size = Vector2(163, 25),
				Location = Vector2(405, 139),
				Text = "",
				TextColor = ARGB(255, 37, 37, 37),
				BackgroundColor = ARGB(255, 255, 255, 255),
				FontSize = 14,
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("faq/lb_chat_bg4_normal.tga", Vector4(8, 8, 8, 8)),
				},
				MaxLength = 11,
			},
			
			Gui.Label "leixin"
			{
				Size = Vector2(127, 25),
				Location = Vector2(4, 169),
				Text = lang:GetText("*问题类型:"),
				TextAlign = "kAlignRightMiddle",
				FontSize = 14,
				TextColor = ARGB(255, 37, 37, 37),
			},
			
			Gui.RadioGroup "leixin_rg"
			{
				Size = Vector2(429, 16),
				Location = Vector2(140, 174),
				ControlSpace = 20,
				LineSpace = 5,
				TextColor = ARGB(255, 37, 37, 37),
				Skin = Gui.CheckBoxSkin
				{
					OnImage = Gui.Image("faq/lb_common_radiobtn01_active.tga", Vector4(0, 0, 0, 0)),
					OffImage = Gui.Image("lb_common_radiobtn01_normal.tga", Vector4(0, 0, 0, 0)),
					OnDisabledImage = Gui.Image("faq/lb_common_radiobtn01_active.tga", Vector4(0, 0, 0, 0)),
					OffDisabledImage = Gui.Image("lb_common_radiobtn01_normal.tga", Vector4(0, 0, 0, 0)),
				},
				
				Gui.RadioButton "bt1"
				{
					Size = Vector2(100, 16),
					FontSize = 14,
					TextColor = ARGB(255, 37, 37, 37),
					Text = "BUG",
					ID = 1,
				},

				Gui.RadioButton "bt2"
				{
					Size = Vector2(292, 16),
					FontSize = 14,
					TextColor = ARGB(255, 37, 37, 37),
					Text = lang:GetText("举报或建议"),
					ID = 2,			
				},

				EventRadioChanged = function(sender, args)
					redio_id = sender.RadioCheckID
				end
			},
			
			Gui.Label "miaoshu"
			{
				Size = Vector2(127, 25),
				Location = Vector2(4, 199),
				Text = lang:GetText("*问题描述:"),
				TextAlign = "kAlignRightMiddle",
				FontSize = 14,
				TextColor = ARGB(255, 37, 37, 37),
			},
			
			Gui.TextArea "miaoshu_box"
			{
				Size = Vector2(429, 157),
				Text = "",
				FontSize = 14,
				Location = Vector2(140, 199),
				TextColor = ARGB(255, 37, 37, 37),
				Fold = true,
				VScrollBarWidth = 14,
				VScrollBarButtonSize = 14,
				HScrollBarDisplay = "kHide",
				VScrollBarDisplay = "kAuto",							
				Skin = Gui.TextAreaSkin
				{
					BackgroundImage = Gui.Image("faq/lb_chat_bg4_normal.tga", Vector4(8, 8, 8, 8)),
				
					UpButtonNormalImage = Gui.Image("LobbyUI/lb_shop_scrollbar01_button1normal.dds", Vector4(0, 4, 0, 4)),
					UpButtonHoverImage = Gui.Image("LobbyUI/lb_shop_scrollbar01_button1hover.dds", Vector4(0, 4, 0, 4)),
					UpButtonDownImage = Gui.Image("LobbyUI/lb_shop_scrollbar01_button1down.dds", Vector4(0, 4, 0, 4)),
					UpButtonDisabledImage = Gui.Image("LobbyUI/lb_shop_scrollbar01_button1normal.dds", Vector4(0, 4, 0, 4)),
					
					DownButtonNormalImage = Gui.Image("LobbyUI/lb_shop_scrollbar01_button02normal.dds", Vector4(0, 4, 0, 4)),
					DownButtonHoverImage = Gui.Image("LobbyUI/lb_shop_scrollbar01_button02hover.dds", Vector4(0, 4, 0, 4)),
					DownButtonDownImage = Gui.Image("LobbyUI/lb_shop_scrollbar01_button02down.dds", Vector4(0, 4, 0, 4)),
					DownButtonDisabledImage = Gui.Image("LobbyUI/lb_shop_scrollbar01_button02normal.dds", Vector4(0, 4, 0, 4)),

					VSliderNormalImage = Gui.Image("LobbyUI/lb_shop_scrollbar01_slidernormal.dds", Vector4(0, 4, 0, 4)),
					VSliderHoverImage = Gui.Image("LobbyUI/lb_shop_scrollbar01_sliderhover.dds", Vector4(0, 4, 0, 4)),
					VSliderDownImage = Gui.Image("LobbyUI/lb_shop_scrollbar01_sliderdown.dds", Vector4(0, 4, 0, 4)),
					VSliderDisabledImage = Gui.Image("LobbyUI/lb_shop_scrollbar01_slidernormal.dds", Vector4(0, 4, 0, 4)),

					VBarBackgroundImage = Gui.Image("LobbyUI/lb_shop_scrollbar01_bg.dds", Vector4(0, 4, 0, 4)),
					BarCornerImage = nil,
				},
				MaxLength = 650,
			},
		},
		
		Gui.Control "title"
		{
			Size = Vector2(585,39),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Location = Vector2(10, 10),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("faq/ntwg_title.tga", Vector4(12, 12, 12, 12)),
			},
			
			Gui.Label "title_text"
			{
				Size = Vector2(585, 39),
				Location = Vector2(0, 0),
				Text = lang:GetText("你提我改"),
				TextAlign = "kAlignCenterMiddle",
				FontSize = 22,
				TextColor = ARGB(255, 37, 37, 37),
			},
		},
		
		Gui.Control "text"
		{
			Size = Vector2(573,50),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Location = Vector2(15, 51),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("faq/ntwg_whitebg01.dds", Vector4(12, 12, 12, 12)),
			},
			
			Gui.Label "text_text1"
			{
				Size = Vector2(573, 25),
				Location = Vector2(0, 0),
				Text = lang:GetText("玩家可以通过你提我改进行游戏bug以及建议的提交,"),
				TextAlign = "kAlignCenterMiddle",
				FontSize = 16,
				TextColor = ARGB(255, 37, 37, 37),
			},
			
			Gui.Label "text_text2"
			{
				Size = Vector2(573, 25),
				Location = Vector2(0, 24),
				Text = lang:GetText("感谢您的支持和参与！"),
				TextAlign = "kAlignCenterMiddle",
				FontSize = 16,
				TextColor = ARGB(255, 37, 37, 37),
			},
		},
		
		Gui.Control "warning"
		{
			Size = Vector2(573,22),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Location = Vector2(15, 370),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("faq/ntwg_warning_bg.tga", Vector4(22,0,7,0)),
			},
			
			Gui.Label "warning_text1"
			{
				Size = Vector2(553, 22),
				Location = Vector2(45, 1),
				Text = lang:GetText("以上带*号为必填项"),
				TextAlign = "kAlignLeftMiddle",
				FontSize = 16,
				TextColor = ARGB(255, 37, 37, 37),
			},
		},
		
		Gui.Button "btn_ok"
		{
			Size = Vector2(176, 34),
			Location = Vector2(100, 402),
			Text = lang:GetText("确 定"),
			TextColor = ARGB(255, 211, 211, 211),
			HighlightTextColor = ARGB(255, 211, 211, 211),
			FontSize = 18,
			PushDown = false,
			Padding = Vector4(0, 0, 0, 5),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("faq/lb_contact_button_normal.tga", Vector4(20, 16, 20, 16)),
				HoverImage = Gui.Image("faq/lb_contact_button_hover.tga", Vector4(20, 16, 20, 16)),
				DownImage = Gui.Image("faq/lb_contact_button_down.tga", Vector4(20, 16, 20, 16)),
				DisabledImage = Gui.Image("faq/lb_contact_button_normal.tga", Vector4(20, 16, 20, 16)),
			},
			EventClick = function()
				if WebWin.miaoshu_box.Text == "" or WebWin.biaoti_box.Text == "" then
					MessageBox.ShowWithTimer(1, lang:GetText("请确认带*号项都已经填写完整！"))
				else
					returnvalue = state:HttpXLInfo(WebWin.biaoti_box.Text,WebWin.miaoshu_box.Text,WebWin.qhao_box.Text,WebWin.shouji_box.Text,redio_id)
					if returnvalue == 0 then
						MessageBox.ShowWithTimer(1, lang:GetText("提交成功"))
						WebWin.miaoshu_box.Text = ""
						WebWin.biaoti_box.Text = ""
						WebWin.shouji_box.Text = ""
						WebWin.qhao_box.Text = ""
					elseif returnvalue == -2 then
						MessageBox.ShowWithTimer(1, lang:GetText("请先进入频道"))
					else
						MessageBox.ShowWithTimer(1, lang:GetText("服务器暂时不可用"))
					end
				end
			end
		},
		
		Gui.Button "btn_reset"
		{
			Size = Vector2(176, 34),
			Location = Vector2(330, 402),
			Text = lang:GetText("重 置"),
			TextColor = ARGB(255, 211, 211, 211),
			HighlightTextColor = ARGB(255, 211, 211, 211),
			FontSize = 18,
			PushDown = false,
			Padding = Vector4(0, 0, 0, 5),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("faq/lb_contact_button_normal.tga", Vector4(20, 16, 20, 16)),
				HoverImage = Gui.Image("faq/lb_contact_button_hover.tga", Vector4(20, 16, 20, 16)),
				DownImage = Gui.Image("faq/lb_contact_button_down.tga", Vector4(20, 16, 20, 16)),
				DisabledImage = Gui.Image("faq/lb_contact_button_normal.tga", Vector4(20, 16, 20, 16)),
			},
			EventClick = function()
				WebWin.miaoshu_box.Text = ""
				WebWin.biaoti_box.Text = ""
				WebWin.shouji_box.Text = ""
				WebWin.qhao_box.Text = ""
			end
		},
		
		Gui.Button "btn_close"
		{
			Size = Vector2(20, 20),
			Location = Vector2(550, 20),
			PushDown = false,
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("faq/lb_contact_buttonX_normal.dds", Vector4(0, 0, 0, 0)),
				HoverImage = Gui.Image("faq/lb_contact_buttonX2_hover.dds", Vector4(0, 0, 0, 0)),
				DownImage = Gui.Image("faq/lb_contact_buttonX2_down.dds", Vector4(0, 0, 0, 0)),
				DisabledImage = Gui.Image("faq/lb_contact_buttonX_normal.dds", Vector4(0, 0, 0, 0)),
			},
			EventClick = function()
				if WebWindow and WebWindow.screen then
					WebWindow.screen.Visible = false
				end
				escWindow.screen.Visible = false
				gui.Focused = true
				state.EscHasFocus = false
			end
		},
	},
}

function AddControl(line,list)
	local X_pos = 19 + list*238
	local Y_pos = 57 + line*29
	if line%2 == 0 then
		return Gui.Control
		{	
			Size = Vector2(238, 29),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Location = Vector2(X_pos, Y_pos),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("faq/ig_esc_jubao_list_content_a.dds", Vector4(0, 0, 0, 0)),
			},
		}
	else
		return Gui.Control
		{	
			Size = Vector2(238, 29),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Location = Vector2(X_pos, Y_pos),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("faq/ig_esc_jubao_list_content_b.dds", Vector4(0, 0, 0, 0)),
			},
		}
	end
end

function create_line(index, text)
	return Gui.Control
	{
		Size = Vector2(776, 131),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("InGameUI/TD_mode/ig_xzzj_touxiang_03.dds", Vector4(20, 20, 20, 20)),
		},
		Gui.Label
		{
			Size = Vector2(192, 25),
			Location = Vector2(15, 4),
			Text = text,
			FontSize = 18,
			TextAlign = "kAlignLeftMiddle",
			TextColor = ARGB(255, 215, 232, 227),
		},
		Gui.Control
		{
			Size = Vector2(465, 131),
			Location = Vector2(67, 28),
			BackgroundColor = ARGB(0, 255, 255, 255),
			Gui.FlowLayout ("button_layout"..index)
			{
				Size = Vector2(1800, 78),
				Location = Vector2(0, 0),
				ControlSpace = 15,
			},
		},
		Gui.Button
		{
			Size = Vector2(38, 55),
			Location = Vector2(13, 42),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("InGameUI/TD_mode/ig_xxzj_button03_normal.dds", Vector4(0, 0, 0, 0)),
				HoverImage = Gui.Image("InGameUI/TD_mode/ig_xxzj_button03_hover.dds", Vector4(0, 0, 0, 0)),
				DownImage = Gui.Image("InGameUI/TD_mode/ig_xxzj_button03_down.dds", Vector4(0, 0, 0, 0)),
			},
			EventClick = function()
				if SelectWeapon["button_layout"..index].Location.x ~= 0 then
					SelectWeapon["button_layout"..index].Location = Vector2(SelectWeapon["button_layout"..index].Location.x + 96, SelectWeapon["button_layout"..index].Location.y)
				end
			end
		},
		Gui.Button
		{
			Size = Vector2(38, 55),
			Location = Vector2(540, 42),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("InGameUI/TD_mode/ig_xzzj_button02_normal.dds", Vector4(0, 0, 0, 0)),
				HoverImage = Gui.Image("InGameUI/TD_mode/ig_xxzj_button02_hover.dds", Vector4(0, 0, 0, 0)),
				DownImage = Gui.Image("InGameUI/TD_mode/ig_xxzj_button02_down.dds", Vector4(0, 0, 0, 0)),
			},
			EventClick = function()
				if line_count[index] > 5 and SelectWeapon["button_layout"..index].Location.x ~= (line_count[index] - 5) * 96 * (-1) then
					SelectWeapon["button_layout"..index].Location = Vector2(SelectWeapon["button_layout"..index].Location.x - 96, SelectWeapon["button_layout"..index].Location.y)
				end
			end
		},
		Gui.Label
		{
			Size = Vector2(200, 20),
			Location = Vector2(593, 35),
			Text = lang:GetText("可放置")..text..lang:GetText("："),
			TextColor = ARGB(255, 255, 255, 255),
		},
		Gui.Label ("max_count_"..index)
		{
			Size = Vector2(30, 20),
			Location = Vector2(723, 35),
			Text = "0",
			TextColor = ARGB(255, 255, 186, 0),
			TextAlign = "kAlignLeftMiddle",
		},
		Gui.Label
		{
			Size = Vector2(200, 20),
			Location = Vector2(593, 78),
			Text = lang:GetText("已放置")..text..lang:GetText("："),
			TextColor = ARGB(255, 255, 255, 255),
		},
		Gui.Label ("count_"..index)
		{
			Size = Vector2(30, 20),
			Location = Vector2(723, 78),
			Text = "0",
			TextColor = ARGB(255, 255, 186, 0),
			TextAlign = "kAlignLeftMiddle",
		},
	}
end

function create_btn()
	local c = Gui.Create()
	{
		Gui.ItemBoxBtn "root"
		{
			Empty = false,
			Type = 1,
			Size = Vector2(81, 78),
			Skin = Gui.ItemBoxBtnSkin
			{
				NeutralNormalImage = Gui.Image("InGameUI/TD_mode/ig_xxzj_bg_gouwuche2_normal.dds", Vector4(0, 0, 0, 0)),
				NeutralHoverImage = Gui.Image("InGameUI/TD_mode/ig_xxzj_bg_gouwuche2_hover.dds", Vector4(0, 0, 0, 0)),
				NeutralSelectedImage = Gui.Image("InGameUI/TD_mode/ig_xxzj_bg_gouwuche2_down.dds", Vector4(0, 0, 0, 0)),
			},
			EventMouseUp = function(sender, e)
				state:SetActiveTower(sender.IntTag)
				selectWeaponWindow.screen.Visible = false
				gui.Focused = true
				state.SelectHasFocus = false
			end,
			Gui.FlowLayout "count"
			{
				Size = Vector2(78, 16),
				Location = Vector2(0,3),
				Direction = "kHorizontal",
				Align = "kAlignRightMiddle",
				ControlAlign = "kAlignCenterMiddle",
				ControlSpace = -3,
			},
		}
	}
	return c
end

ReportWin = Gui.Create()
{
	Gui.Control "ReportWin_root"
	{	
		Size = Vector2(514, 576),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Location = Vector2(0, 0),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("faq/ig_esc_jubao_bg.dds", Vector4(25, 25, 25, 25)),
		},
		
		Gui.Label
		{
			Size = Vector2(500, 32),
			Location = Vector2(4, 22),
			Text = lang:GetText("请选择要举报的玩家"),
			FontSize = 20,
			TextAlign = "kAlignCenterMiddle",
			TextColor = ARGB(255, 37, 37, 37),
		},
		
		AddControl(0,0),
		AddControl(1,0),
		AddControl(2,0),
		AddControl(3,0),
		AddControl(4,0),
		AddControl(5,0),
		AddControl(6,0),
		AddControl(7,0),
		
		AddControl(0,1),
		AddControl(1,1),
		AddControl(2,1),
		AddControl(3,1),
		AddControl(4,1),
		AddControl(5,1),
		AddControl(6,1),
		AddControl(7,1),
		
		Gui.RadioGroup "Report_Id"
		{
			Size = Vector2(476, 232),
			Location = Vector2(23, 60),
			ControlSpace = 10,
			LineSpace = 9,
			RadioCheckID = -1,
			TextColor = ARGB(255, 37, 37, 37),

			EventRadioChanged = function(sender, args)
				Report_name = sender.RadioCheckText
			end
		},
		
		Gui.Label
		{
			Size = Vector2(500, 32),
			Location = Vector2(6, 295),
			Text = lang:GetText("举报理由"),
			FontSize = 20,
			TextAlign = "kAlignCenterMiddle",
			TextColor = ARGB(255, 37, 37, 37),
		},
		
		Gui.RadioGroup "Report_sake"
		{
			Size = Vector2(500, 20),
			Location = Vector2(26, 346),
			ControlSpace = 20,
			LineSpace = 5,
			TextColor = ARGB(255, 37, 37, 37),
			Skin = Gui.CheckBoxSkin
			{
				OnImage = Gui.Image("faq/lb_common_radiobtn01_active.tga", Vector4(0, 0, 0, 0)),
				OffImage = Gui.Image("lb_common_radiobtn01_normal.tga", Vector4(0, 0, 0, 0)),
				OnDisabledImage = Gui.Image("faq/lb_common_radiobtn01_active.tga", Vector4(0, 0, 0, 0)),
				OffDisabledImage = Gui.Image("lb_common_radiobtn01_normal.tga", Vector4(0, 0, 0, 0)),
			},
			
			Gui.RadioButton
			{
				Size = Vector2(105, 20),
				FontSize = 10,
				TextColor = ARGB(255, 37, 37, 37),
				Text = lang:GetText("使用外挂"),
				ID = 1,
			},
			
			Gui.RadioButton
			{
				Size = Vector2(105, 20),
				FontSize = 10,
				TextColor = ARGB(255, 37, 37, 37),
				Text = lang:GetText("恶意使用bug"),
				ID = 2,
			},
			
			Gui.RadioButton
			{
				Size = Vector2(125, 20),
				FontSize = 10,
				TextColor = ARGB(255, 37, 37, 37),
				Text = lang:GetText("无理谩骂"),
				ID = 3,
			},
			
			Gui.RadioButton
			{
				Size = Vector2(105, 20),
				FontSize = 10,
				TextColor = ARGB(255, 37, 37, 37),
				Text = lang:GetText("其它"),
				ID = 4,
			},

			EventRadioChanged = function(sender, args)
				
			end,
		},
		
		Gui.Label
		{
			Size = Vector2(500, 32),
			Location = Vector2(6, 383),
			Text = lang:GetText("问题描述"),
			FontSize = 20,
			TextAlign = "kAlignCenterMiddle",
			TextColor = ARGB(255, 37, 37, 37),
		},
		
		Gui.Control"ctr_Group_write"
		{
			Size = Vector2(476, 90),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Location = Vector2(18, 423),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_bg3_normal.dds", Vector4(8, 8, 8, 8)),
			},
			
			Gui.TextArea "tarea_Text"
			{
				Style = "Gui.TextAreaWithVBar",
				Size = Vector2(470, 80),
				FontSize = 14,
				Location = Vector2(0, 5),
				TextColor = ARGB(255, 37, 37, 37),
				HighlightTextColor = ARGB(255, 37, 37, 37),
				--Readonly = true,
				Fold = true,
				VScrollBarWidth = 8,
				VScrollBarButtonSize = 1,
				VScrollBarPos = Vector2(0, 0),
				Padding = Vector4(5, 5, 5, 5),
			
				EventTextChanged = function()
					
				end
			},
		},
		
		Gui.Button
		{
			Size = Vector2(103, 35),
			Location = Vector2(103, 522),
			Text = lang:GetText("确 定"),
			TextColor = ARGB(255, 211, 211, 211),
			HighlightTextColor = ARGB(255, 211, 211, 211),
			FontSize = 18,
			PushDown = false,
			Padding = Vector4(0, 0, 0, 5),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("faq/lb_contact_button_normal.tga", Vector4(20, 16, 20, 16)),
				HoverImage = Gui.Image("faq/lb_contact_button_hover.tga", Vector4(20, 16, 20, 16)),
				DownImage = Gui.Image("faq/lb_contact_button_down.tga", Vector4(20, 16, 20, 16)),
				DisabledImage = Gui.Image("faq/lb_contact_button_normal.tga", Vector4(20, 16, 20, 16)),
			},
			EventClick = function()
				if Report_name == nil then
					MessageBox.ShowWithTimer(1,lang:GetText("请选择一名玩家！"))
					return
				end
				if ReportWin.tarea_Text.Text == "" then
					MessageBox.ShowWithTimer(1,lang:GetText("问题描述不能为空！"))
					return
				end
				local returnvalue = state:HttpXLReport(Report_name,ReportWin.Report_sake.RadioCheckID,ReportWin.tarea_Text.Text)
				if returnvalue == 0 then
					MessageBox.ShowWithTimer(1, lang:GetText("提交成功"))
					DeleteAllReport()
				else
					MessageBox.ShowWithTimer(1, lang:GetText("提交失败"))
				end
			end,
		},
		
		Gui.Button
		{
			Size = Vector2(103, 35),
			Location = Vector2(300, 522),
			Text = lang:GetText("取 消"),
			TextColor = ARGB(255, 211, 211, 211),
			HighlightTextColor = ARGB(255, 211, 211, 211),
			FontSize = 18,
			PushDown = false,
			Padding = Vector4(0, 0, 0, 5),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("faq/lb_contact_button_normal.tga", Vector4(20, 16, 20, 16)),
				HoverImage = Gui.Image("faq/lb_contact_button_hover.tga", Vector4(20, 16, 20, 16)),
				DownImage = Gui.Image("faq/lb_contact_button_down.tga", Vector4(20, 16, 20, 16)),
				DisabledImage = Gui.Image("faq/lb_contact_button_normal.tga", Vector4(20, 16, 20, 16)),
			},
			EventClick = function()
				DeleteAllReport()
			end,
		},
	},
}

local escMenu = Gui.Create()
{
	Gui.Control "content"
	{
		Size = Vector2(300, 382),
		Dock = "kDockCenter",
		BackgroundColor = ARGB(255,255,255,255),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_contact_bg1_01.dds", Vector4(163,163,53,53)),
		},
		Gui.Button "cancel"
		{	
			Location = Vector2(30, 23),
			Size = Vector2(242,52),
			TextAlign = "kAlignCenterMiddle",
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/setting/lb_esc_button_fhyx_normal.dds", Vector4(75, 9, 15, 11)),
				HoverImage = Gui.Image("LobbyUI/setting/lb_esc_button_fhyx_hover.dds", Vector4(75, 9, 15, 11)),
				DownImage = Gui.Image("LobbyUI/setting/lb_esc_button_fhyx_down.dds", Vector4(75, 9, 15, 11)),
				DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_esc_button_fhyx_normal.dds", Vector4(75, 9, 15, 11)),
			},
			Padding = Vector4(2, 0, 0, 2),
			FontSize = 24,
			Text = "    "..lang:GetText("返回游戏"),
			TextColor = ARGB(255, 255, 255, 0),
			HighlightTextColor = ARGB(255, 255, 255, 0),
			Gui.Label
			{
				Size = Vector2(242,52),
				Location = Vector2(0, 0),
				Text = "    "..lang:GetText("返回游戏"),
				TextAlign = "kAlignCenterMiddle",
				TextPadding = Vector4(0, 0, 0, 4),
				FontSize = 24,
				Enable = false,
				TextColor = ARGB(255, 0, 0, 0), 
			},
		},
		Gui.Button "setting"
		{
			Location = Vector2(30, 78),
			Size = Vector2(242,52),	
			TextAlign = "kAlignCenterMiddle",
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/setting/lb_esc_button_yxsz_normal.dds", Vector4(75, 9, 15, 11)),
				HoverImage = Gui.Image("LobbyUI/setting/lb_esc_button_yxsz_hover.dds", Vector4(75, 9, 15, 11)),
				DownImage = Gui.Image("LobbyUI/setting/lb_esc_button_yxsz_down.dds", Vector4(75, 9, 15, 11)),
				DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_esc_button_yxsz_normal.dds", Vector4(75, 9, 15, 11)),
			},
			Padding = Vector4(2, 0, 0, 2),
			Text = "    "..lang:GetText("设置选项"),
			TextColor = ARGB(255, 203, 202, 200), 
			HighlightTextColor = ARGB(255, 203, 202, 200), 
			FontSize = 24,
			Gui.Label
			{
				Size = Vector2(242,52),
				Location = Vector2(0, 0),
				Text = "    "..lang:GetText("设置选项"),
				TextAlign = "kAlignCenterMiddle",
				TextPadding = Vector4(0, 0, 0, 4),
				FontSize = 24,
				Enable = false,
				TextColor = ARGB(255, 0, 0, 0),
			},
		},

		Gui.Button "character"
		{	
			Location = Vector2(30, 78),
			Size = Vector2(0,52),
			--Location = Vector2(18, 138),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/setting/lb_esc_button_normal.dds", Vector4(75, 9, 15, 11)),
				HoverImage = Gui.Image("LobbyUI/setting/lb_esc_button_hover.dds", Vector4(75, 9, 15, 11)),
				DownImage = Gui.Image("LobbyUI/setting/lb_esc_button_down.dds", Vector4(75, 9, 15, 11)),
				DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_esc_button_normal.dds", Vector4(75, 9, 15, 11)),
			},
			Text = lang:GetText("登录界面"),
		},
		
		Gui.Button "quit_combat"
		{	
			Location = Vector2(30, 133),
			Size = Vector2(242,52),
			TextAlign = "kAlignCenterMiddle",
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/setting/lb_esc_button_fhdt_normal.dds", Vector4(75, 9, 15, 11)),
				HoverImage = Gui.Image("LobbyUI/setting/lb_esc_button_fhdt_hover.dds", Vector4(75, 9, 15, 11)),
				DownImage = Gui.Image("LobbyUI/setting/lb_esc_button_fhdt_down.dds", Vector4(75, 9, 15, 11)),
				DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_esc_button_fhdt_normal.dds", Vector4(75, 9, 15, 11)),
			},
			Padding = Vector4(2, 0, 0, 2),
			Text = "    "..lang:GetText("返回大厅"),
			TextColor = ARGB(255, 203, 202, 200), 
			HighlightTextColor = ARGB(255, 203, 202, 200), 
			FontSize = 24,
			Gui.Label
			{
				Size = Vector2(242,52),
				Location = Vector2(0, 0),
				Text = "    "..lang:GetText("返回大厅"),
				TextAlign = "kAlignCenterMiddle",
				TextPadding = Vector4(0, 0, 0, 4),
				FontSize = 24,
				Enable = false,
				TextColor = ARGB(255, 0, 0, 0),
			},
		},
		
		Gui.Button "SaveMap_combat"
		{	
			Visible = false,
			Location = Vector2(30, 133),
			Size = Vector2(242,52),
			TextAlign = "kAlignCenterMiddle",
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/setting/lb_esc_button_fhdt_normal.dds", Vector4(75, 9, 15, 11)),
				HoverImage = Gui.Image("LobbyUI/setting/lb_esc_button_fhdt_hover.dds", Vector4(75, 9, 15, 11)),
				DownImage = Gui.Image("LobbyUI/setting/lb_esc_button_fhdt_down.dds", Vector4(75, 9, 15, 11)),
				DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_esc_button_fhdt_normal.dds", Vector4(75, 9, 15, 11)),
			},
			Padding = Vector4(2, 0, 0, 2),
			Text = "    "..lang:GetText("保存并退出"),
			TextColor = ARGB(255, 203, 202, 200), 
			HighlightTextColor = ARGB(255, 203, 202, 200), 
			FontSize = 24,
			Gui.Label
			{
				Size = Vector2(242,52),
				Location = Vector2(0, 0),
				Text = "    "..lang:GetText("保存并退出"),
				TextAlign = "kAlignCenterMiddle",
				TextPadding = Vector4(0, 0, 0, 4),
				FontSize = 24,
				Enable = false,
				TextColor = ARGB(255, 0, 0, 0),
			},
		},

		Gui.Button "quit_game"
		{		
			Visible = false,
			Size = Vector2(242, 52),
			Location = Vector2(30, 188),
			TextAlign = "kAlignCenterMiddle",
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/setting/lb_esc_button_tcyx_normal.dds", Vector4(75, 9, 15, 11)),
				HoverImage = Gui.Image("LobbyUI/setting/lb_esc_button_tcyx_hover.dds", Vector4(75, 9, 15, 11)),
				DownImage = Gui.Image("LobbyUI/setting/lb_esc_button_tcyx_down.dds", Vector4(75, 9, 15, 11)),
				DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_esc_button_tcyx_normal.dds", Vector4(75, 9, 15, 11)),
			},
			Text = lang:GetText("退出游戏"),
			TextColor = ARGB(255, 42, 43, 42),
			FontSize = 24,
		},
		Gui.Button "faq"
		{			
			TextAlign = "kAlignCenterMiddle",
			Size = Vector2(242,52),		
			Location = Vector2(30, 188),
			Padding = Vector4(2, 0, 0, 2),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/setting/lb_esc_button_ntwg_normal.dds", Vector4(75, 9, 15, 11)),
				HoverImage = Gui.Image("LobbyUI/setting/lb_esc_button_ntwg_hover.dds", Vector4(75, 9, 15, 11)),
				DownImage = Gui.Image("LobbyUI/setting/lb_esc_button_ntwg_down.dds", Vector4(75, 9, 15, 11)),
				DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_esc_button_ntwg_normal.dds", Vector4(75, 9, 15, 11)),
			},
			Text = "    "..lang:GetText("你提我改"),
			TextColor = ARGB(255, 203, 202, 200), 
			HighlightTextColor = ARGB(255, 203, 202, 200),  
			FontSize = 24,
			Gui.Label
			{
				Size = Vector2(242,52),
				Location = Vector2(0, 0),
				Text = "    "..lang:GetText("你提我改"),
				TextAlign = "kAlignCenterMiddle",
				TextPadding = Vector4(0, 0, 0, 4),
				FontSize = 24,
				Enable = false,
				TextColor = ARGB(255, 0, 0, 0),
			},			
		},
		Gui.Button "kick_person"
		{			
			Enable = false,
			TextAlign = "kAlignCenterMiddle",
			Size = Vector2(242,52),		
			Location = Vector2(30, 243),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/setting/lb_esc_button_tr_normal.dds", Vector4(75, 9, 15, 11)),
				HoverImage = Gui.Image("LobbyUI/setting/lb_esc_button_tr_hover.dds", Vector4(75, 9, 15, 11)),
				DownImage = Gui.Image("LobbyUI/setting/lb_esc_button_tr_down.dds", Vector4(75, 9, 15, 11)),
				DisabledImage = Gui.Image("LobbyUI/setting/lb_esc_button_tr_normal.dds", Vector4(75, 9, 15, 11)),
			},
			Text = "    "..lang:GetText("投票踢人"),
			TextColor = ARGB(255, 203, 202, 200), 
			HighlightTextColor = ARGB(255, 203, 202, 200), 
			Padding = Vector4(2, 0, 0, 2),
			FontSize = 24,
			Gui.Label
			{
				Size = Vector2(242,52),
				Location = Vector2(0, 0),
				Text = "    "..lang:GetText("投票踢人"),
				TextAlign = "kAlignCenterMiddle",
				TextPadding = Vector4(0, 0, 0, 4),
				FontSize = 24,
				Enable = false,
				TextColor = ARGB(255, 0, 0, 0),
			},	
		},
		Gui.Button "BTN_Report"
		{			
			Enable = true,
			TextAlign = "kAlignCenterMiddle",
			Size = Vector2(242,52),		
			Location = Vector2(30, 298),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/setting/lb_esc_button_jb_normal.dds", Vector4(75, 9, 15, 11)),
				HoverImage = Gui.Image("LobbyUI/setting/lb_esc_button_jb_hover.dds", Vector4(75, 9, 15, 11)),
				DownImage = Gui.Image("LobbyUI/setting/lb_esc_button_jb_down.dds", Vector4(75, 9, 15, 11)),
				DisabledImage = Gui.Image("LobbyUI/setting/lb_esc_button_tr_normal.dds", Vector4(75, 9, 15, 11)),
			},
			Text = "    "..lang:GetText("我要举报"),
			TextColor = ARGB(255, 203, 202, 200), 
			HighlightTextColor = ARGB(255, 203, 202, 200), 
			Padding = Vector4(2, 0, 0, 2),
			FontSize = 24,
			Gui.Label
			{
				Size = Vector2(242,52),
				Location = Vector2(0, 0),
				Text = "    "..lang:GetText("我要举报"),
				TextAlign = "kAlignCenterMiddle",
				TextPadding = Vector4(0, 0, 0, 4),
				FontSize = 24,
				Enable = false,
				TextColor = ARGB(255, 0, 0, 0),
			},	
		},
	},
}

local SelectMenu = Gui.Create()
{
	Gui.Control "content"
	{
		Size = Vector2(914, 430),
		Dock = "kDockCenter",
		BackgroundColor = ARGB(255, 255, 255, 255),
		
		Gui.Label
		{
			FontSize = 22,
			Size = Vector2(914, 30),
			Text = lang:GetText("选择角色后会在下次重生时生效"),
			Location = Vector2(0,7),
			TextColor = ARGB(255, 251, 240, 205),
			TextAlign = "kAlignCenterMiddle",
		},
		
		Gui.Button "enter"
		{
			Style = "Gui.ButtonCharacter",
			Text = lang:GetText("取消"),
			TextColor = ARGB(255, 55, 53, 56),
			Location = Vector2(377,384,0,0),
			ReceiveKey = false,
			EventClick = function()
				if state.IsCanCancel == true then
					selectWindow.screen.Visible = false
					gui.Focused = true
					state.SelectHasFocus = false
				end
			end
		},
		Gui.Label
		{
			FontSize = 20,
			AutoSize = true,
			Text = "[F1]",
			Location = Vector2(70,335),
			TextColor = ARGB(255, 251, 240, 205),
		},
		Gui.Label
		{
			FontSize = 20,
			AutoSize = true,
			Text = "[F2]",
			Location = Vector2(250,335),
			TextColor = ARGB(255, 251, 240, 205),
		},
		Gui.Label
		{
			FontSize = 20,
			AutoSize = true,
			Text = "[F3]",
			Location = Vector2(430,335),
			TextColor = ARGB(255, 251, 240, 205),
		},
		Gui.Label
		{
			FontSize = 20,
			AutoSize = true,
			Text = "[F4]",
			Location = Vector2(610,335),
			TextColor = ARGB(255, 251, 240, 205),
		},
		Gui.Label
		{
			FontSize = 20,
			AutoSize = true,
			Text = "[F5]",
			Location = Vector2(790,335),
			TextColor = ARGB(255, 251, 240, 205),
		},
	},
}

SelectWeapon = Gui.Create()
{
	Gui.Control "content"
	{
		Size = Vector2(810, 536),
		Dock = "kDockCenter",
		BackgroundColor = ARGB(255, 255, 255, 255),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("InGameUI/TD_mode/ig_xzzj_bg01.dds", Vector4(20, 20, 20, 20)),
		},
		Gui.Label
		{
			Size = Vector2(775, 33),
			Location = Vector2(17, 15),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("InGameUI/TD_mode/ig_xxzj_bg2.dds", Vector4(0, 0, 0, 0)),
			},
			TextAlign = "kAlignCenterMiddle",
			FontSize = 22,
			Text = lang:GetText("选择你要放置的建筑"),
			TextColor = ARGB(255, 255, 186, 0),
		},
		Gui.FlowLayout "layout"
		{
			Size = Vector2(776, 411),
			Location = Vector2(16, 55),
			LineSpace = 9,
			create_line(1, lang:GetText("防御墙")),
			create_line(2, lang:GetText("机械守卫")),
			create_line(3, lang:GetText("建筑")),
		},
		
		Gui.Button "enter"
		{
			Style = "Gui.ButtonCharacter",
			Text = lang:GetText("取消所有配置"),
			TextColor = ARGB(255, 55, 53, 56),
			Location = Vector2(331,480),
			ReceiveKey = false,
			EventClick = function()
				MessageBox.ShowWithConfirmCancel(lang:GetText("所有配置将清空\n确认清空吗"),
					function(sender,e)
						state:DestroyAllDummyObject()
						gui.Focused = true
						state.SelectHasFocus = false
						SelectWeaponUI()
					end,
				nil)
			end
		},
	},
}

function InitEscMenu()
	selectWindow = ModalWindow.GetNew("select")
	selectWindow.screen.AllowEscToExit = false
	selectWindow.screen.Visible = false
	selectWindow.screen.EventEscPressed = SwitchEscMenu
	selectWindow.screen.EventChangeState = SelectCharacter
	selectWindow.root.Size = Vector2(1024, 430)
	SelectMenu.content.Parent = selectWindow.root
	
	selectWeaponWindow = ModalWindow.GetNew("selectweapon")
	selectWeaponWindow.screen.AllowEscToExit = false
	selectWeaponWindow.screen.Visible = false
	selectWeaponWindow.screen.EventEscPressed = SwitchEscMenu
	selectWeaponWindow.screen.EventChangeState = SelectWeaponUI
	selectWeaponWindow.root.Size = Vector2(810, 536)
	SelectWeapon.content.Parent = selectWeaponWindow.root
	
	escWindow = ModalWindow.GetNew(1)
	escWindow.screen.AllowEscToExit = false
	escWindow.screen.Visible = false
	escWindow.screen.EventEscPressed = SwitchEscMenu
	escWindow.root.Size = Vector2(300, 382)
	escMenu.content.Parent = escWindow.root

	--web window
	WebWindow = ModalWindow.GetNew("WebWin")
	WebWindow.screen.AllowEscToExit = false
	WebWindow.screen.Visible = false
	WebWindow.screen.EventEscPressed = SwitchEscMenu
	WebWindow.root.Size = Vector2(606, 451)
	WebWin.web_Window.Parent = WebWindow.root
	
	--ReportWin Window
	ReportWindow = ModalWindow.GetNew("ReportWin")
	ReportWindow.screen.AllowEscToExit = false
	ReportWindow.screen.Visible = false
	ReportWindow.screen.EventEscPressed = SwitchEscMenu
	ReportWindow.root.Size = Vector2(514, 576)
	ReportWin.ReportWin_root.Parent = ReportWindow.root

	gui.Focused = true
	selectindex = 0
	selectweaponindex = 0
	
	escMenu.cancel.EventClick = function()
		escWindow.screen.Visible = false
		gui.Focused = true
		state.EscHasFocus = false
	end

	escMenu.setting.EventClick = function()
		escWindow.screen.Visible = false
		local settingWin = L_Settings.Show()
		settingWin.root.EventClose = function() state.EscHasFocus = false end
	end

	escMenu.kick_person.EventClick = function()
		escWindow.screen.Visible = false
		local kickpersonWin = L_Kickperson.Show()
		kickpersonWin.root.EventClose = function() state.EscHasFocus = false end
		state:ShowKickPerson(0)
	end
	
	escMenu.BTN_Report.EventClick = function()
		DeleteAllReport()
		ShowReportWin()
		state:ShowKickPerson(1)
	end
	
	escMenu.quit_combat.EventClick = function()
		if state.IsWatch == false and state.IsReplay == false then
		local message = nil
		if L_LobbyMain.PersonalInfo_data and L_LobbyMain.PersonalInfo_data.isvip > 0 then
			message = lang:GetText("您确定要退出本场游戏吗？\n中途退出将无法获得任何收益\n您是vip用户,该条件对您无效")
		else
			message = lang:GetText("您确定要退出本场游戏吗？\n中途退出将无法获得任何收益")
		end
			MessageBox.ShowWithConfirmCancel(message,
					function(sender,e)
						escWindow.screen.Visible = false
						gui.Focused = true
						state.EscHasFocus = false
						state:Quit()
						MessageBox.ShowWithTimer(3,lang:GetText("正在退出本场游戏..."))
					end,
				nil)
		else
			escWindow.screen.Visible = false
			gui.Focused = true
			state.EscHasFocus = false
			state:Quit()
			MessageBox.ShowWithTimer(3,lang:GetText("正在退出本场游戏..."))
		end
	end
	
	escMenu.SaveMap_combat.EventClick = function()
		escWindow.screen.Visible = false
		gui.Focused = true
		state.EscHasFocus = false
		state:SaveMap()
		state:Quit()
	end

	escMenu.quit_game.EventClick = function()
		MessageBox.ShowWithConfirmCancel(lang:GetText("您确定要退出并返回操作系统吗？"),
			function(sender,e)
				Thread.Quit()
			end,
			nil)
	end

	escMenu.faq.EventClick = function()
		ShowWebWin()
	end

end

function AllInit(change) 
	selectWindow.screen.Visible = false
	selectWeaponWindow.screen.Visible = false
	gui.Focused = true
	state.SelectHasFocus = false
	if change then
		ptr_cast(game.CurrentState):SetCharacterFromID()
	end
end

function DestroyEscMenu()
	escMenu.cancel.EventClick = nil
	escMenu.setting.EventClick = nil
	escMenu.quit_combat.EventClick = nil
	escMenu.SaveMap_combat.EventClick = nil
	escMenu.quit_game.EventClick = nil
	escMenu.kick_person.EventClick = nil
	escMenu.BTN_Report.EventClick = nil
	escMenu.content.Parent = nil
	
	escWindow.screen.EventEscPressed = nil
	escWindow.Close()
	escWindow=nil
	
	selectWindow.screen.EventEscPressed = nil
	selectWindow.screen.EventChangeState = nil
	selectWindow.Close()
	selectWindow=nil
	
	selectWeaponWindow.screen.EventEscPressed = nil
	selectWeaponWindow.screen.EventChangeState = nil
	selectWeaponWindow.Close()
	selectWeaponWindow=nil

	WebWin.web_Window.Parent = nil
	WebWindow.screen.EventEscPressed = nil
	WebWindow.Close()
	WebWindow = nil
	
	ReportWin.ReportWin_root.Parent = nil
	ReportWindow.screen.EventEscPressed = nil
	ReportWindow.Close()
	ReportWindow = nil
end

function SwitchEscMenu()
	if selectWeaponWindow and selectWeaponWindow.screen then
		if selectWeaponWindow.screen.Visible == true then
			selectWeaponWindow.screen.Visible = false
			state.EscHasFocus = false
			state.SelectHasFocus = selectWeaponWindow.screen.Visible
			return
		end
	end

	if state.SelectHasFocus == true then
		SelectCharacter()
	else
		if escMenu then
			if state.IsWatch == true or state.IsReplay == true then
				escMenu.kick_person.Enable = false
				escMenu.BTN_Report.Enable = false
			else
				escMenu.kick_person.Enable = true
				escMenu.BTN_Report.Enable = true
			end
			
			if state.IsEditMode then
				escMenu.SaveMap_combat.Visible = true
				escMenu.quit_combat.Visible = false
			else
				escMenu.SaveMap_combat.Visible = false
				escMenu.quit_combat.Visible = true
			end
		end
		
		if escWindow and escWindow.screen and WebWindow.screen.Visible == false and ReportWindow.screen.Visible == false then
			escWindow.screen.Visible = not escWindow.screen.Visible
			state.EscHasFocus = escWindow.screen.Visible
		end
	end

	if WebWindow and WebWindow.screen then
		if WebWindow.screen.Visible == true then
			WebWindow.screen.Visible = false
			state.EscHasFocus = false
		end		
	end
	
	if ReportWindow and ReportWindow.screen then
		if ReportWindow.screen.Visible == true then
			ReportWindow.screen.Visible = false
			state.EscHasFocus = false
		end		
	end
end

function SelectCharacter()
	if state.EscHasFocus == false then
		if selectWeaponWindow and selectWeaponWindow.screen then
			selectWeaponWindow.screen.Visible = false
		end
		if selectWindow and selectWindow.screen then
			selectWindow.screen.Visible = not selectWindow.screen.Visible
			if selectWindow.screen.Visible == true then
				for id, con in pairs(select_botton) do
					if select_txt_to_key[con.bt.Text] == state.SelectName then
						con.bt.PushDown = true
					else
						con.bt.PushDown = false
					end
				end
			end
			state.SelectHasFocus = selectWindow.screen.Visible
		end
	end
end

function SelectWeaponUI()
	if state.EscHasFocus == false then
		if selectWeaponWindow and selectWeaponWindow.screen then
			selectWeaponWindow.screen.Visible = not selectWeaponWindow.screen.Visible
			state.SelectHasFocus = selectWeaponWindow.screen.Visible
			if selectWeaponWindow.screen.Visible then
				SetEditGunInfo()
			end
		end
	end
end

function gui.EventSizeChanged()
	L_Settings.AlignUI()
	L_Kickperson.AlignUI()
end

function state.EventChooseCharacter()
		SelectCharacter()
end

function state.EventCloseCharacter()
	if state.SelectHasFocus == true then
		SelectCharacter()
	end
end

function state.EventClearSelectKickPerson()
	L_Kickperson.ClearPerson()
end

function state.EventCanKick(sender, e)
	L_Kickperson.SetNum(e.count)
end

function state.EventAddSelectKickPerson(sender, e)
	L_Kickperson.AddPerson(sender, e)
end

function state.EventAddSelectReportPerson(sender, e)
	if ReportWindow.screen.Visible then
		AddReportPerson(sender, e)
	end
end

function state.KickPersonError(sender, e)
	if e.error_id == 0 then
		MessageBox.ShowWithTimer(2, lang:GetText("正在投票中，请稍后再申请。"))
	end
	if e.error_id == 1 then
		MessageBox.ShowWithTimer(2, lang:GetText("错误的投票信息。"))
	end	
	if e.error_id == 2 then
		MessageBox.ShowWithTimer(2, lang:GetText("今天你已无发起投票的权利。"))
	end	
	if e.error_id == 3 then
		MessageBox.ShowWithTimer(2, lang:GetText("玩家不存在或已经离开房间。"))
	end
	if e.error_id == 4 then
		MessageBox.ShowWithTimer(2, lang:GetText("对不起，你没有权限踢出非队友玩家。"))
	end
	if e.error_id == 5 then
		MessageBox.ShowWithTimer(2, lang:GetText("你已经被请出该房间！"))
	end
	L_Kickperson.Hide()
end

function state.EventSavePhoto()
	MessageBox.ShowWithTimer(1,lang:GetText("截图成功保存在游戏目录的pictures文件夹"))
end

function state.EventCantSelectPerson(sender, e)
	if e.count == 1 then
		MessageBox.ShowWithTimer(2,lang:GetText("职业特殊战--“火箭兵”，不能更换角色"))
	elseif e.count == 2 then
		MessageBox.ShowWithTimer(2,lang:GetText("职业特殊战--“重机枪手”，不能更换角色"))
	elseif e.count == 3 then
		MessageBox.ShowWithTimer(2,lang:GetText("职业特殊战--“狙击手”，不能更换角色"))
	elseif e.count == 4 then
		MessageBox.ShowWithTimer(2,lang:GetText("职业特殊战--“突击手”，不能更换角色"))
	elseif e.count == 5 then
		MessageBox.ShowWithTimer(2,lang:GetText("职业特殊战--“火焰兵”，不能更换角色"))
	elseif e.count == 6 then
		MessageBox.ShowWithTimer(2,lang:GetText("职业特殊战--“医疗兵”，不能更换角色"))
	elseif e.count == 7 then
		MessageBox.ShowWithTimer(2,lang:GetText("职业特殊战--“工程兵”，不能更换角色"))
	end
end

function state.EventAddSelect(sender, e)
	select_txt_to_key[e.text_name] = e.key_name
	local selectCon = AddSelectBotton(e.text_name)
	selectCon.CSelect.Parent = SelectMenu.content
	
	if state.TeamIndex == 0 then
		SelectMenu.content.Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("InGameUI/select_person/ig_common_xuanren_bgred.dds", Vector4(34, 48, 34, 70)),
		}
		if e.key_name ~= "lock" and e.key_name ~= "slot" then
			selectCon.bt.Skin = Gui.InGameMainButtonSkin
			{
			GameUpperImage = Gui.Image("InGameUI/select_person/ig_common_xuanren_"..e.key_name..".dds", Vector4(0,0,0,0)),
			GameUpperHoverImage = Gui.Image("InGameUI/select_person/ig_common_xuanren_"..e.key_name..".dds", Vector4(0,0,0,0)),
			GameActiveUpperImage = Gui.Image("InGameUI/select_person/ig_common_xuanren_down_"..e.key_name.."_red.dds", Vector4(0,0,0,0)),
			}
			selectCon.bt.Enable = true
		elseif e.key_name == "slot" then
			selectCon.bt.Skin = Gui.InGameMainButtonSkin
			{
				GameUpperImage = Gui.Image("InGameUI/select_person/ig_common_xuanren_jiesuo_red_2.dds", Vector4(0,0,0,0)),
			}
			selectCon.bt.Enable = false
		else
			selectCon.bt.Skin = Gui.InGameMainButtonSkin
			{
				GameUpperImage = Gui.Image("InGameUI/select_person/ig_common_xuanren_lock_red.dds", Vector4(0,0,0,0)),
			}
			selectCon.bt.Enable = false
		end

	else
		SelectMenu.content.Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("InGameUI/select_person/ig_common_xuanren_bgblue.dds", Vector4(34, 48, 34, 70)),
		}
		if e.key_name ~= "lock" and e.key_name ~= "slot" then
			selectCon.bt.Skin =Gui.InGameMainButtonSkin
			{
				GameUpperImage = Gui.Image("InGameUI/select_person/ig_common_xuanren_"..e.key_name..".dds", Vector4(0,0,0,0)),
				GameUpperHoverImage = Gui.Image("InGameUI/select_person/ig_common_xuanren_"..e.key_name..".dds", Vector4(0,0,0,0)),
				GameActiveUpperImage = Gui.Image("InGameUI/select_person/ig_common_xuanren_down_"..e.key_name.."_blue.dds", Vector4(0,0,0,0)),
			}
			selectCon.bt.Enable = true
		elseif e.key_name == "slot" then
			selectCon.bt.Skin = Gui.InGameMainButtonSkin
			{
				GameUpperImage = Gui.Image("InGameUI/select_person/ig_common_xuanren_jiesuo_blue_2.dds", Vector4(0,0,0,0)),
			}
			selectCon.bt.Enable = false
		else
			selectCon.bt.Skin = Gui.InGameMainButtonSkin
			{
				GameUpperImage = Gui.Image("InGameUI/select_person/ig_common_xuanren_lock_blue.dds", Vector4(0,0,0,0)),
			}
			selectCon.bt.Enable = false
		end
	end
end

function AddSelectBotton(name)
	local SelectCon = Gui.Create(gui) 
	{
		Gui.Control "CSelect"
		{
			Size = Vector2(180, 310),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Text = "select",
			TextColor = ARGB(0, 255, 255, 255),
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = nil,
			},
			
			Gui.InGameMainButton "bt"
			{
				Size = Vector2(180,310),			
				BackgroundColor = ARGB(255, 255, 255, 255),
				TextColor = ARGB(255, 251, 240, 205),
				Text = name,
				CanPushDown = true,
				EventClick = function(Sender,e)
					for id, con in pairs(select_botton) do
						if state.SelectName == select_txt_to_key[name] then
							AllInit(false)
						else
							state.SelectName = select_txt_to_key[name]
							AllInit(true)
						end
					end
				end
			},
		},
	}
	--这个地方会随着人数的增加而修改
	SelectCon.CSelect.Location = Vector2((1+180)*selectindex,24)
	select_botton[selectindex] = SelectCon
	selectindex = selectindex + 1
	
	return SelectCon
end

function AddSelectWeaponBotton(name)
	local SelectCon = Gui.Create(gui) 
	{
		Gui.Control "WSelect"
		{
			Size = Vector2(180, 310),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Text = "selectweapon",
			TextColor = ARGB(0, 255, 255, 255),
			
			Skin = Gui.ControlSkin
			{
				BackgroundImage = nil,
			},
			
			Gui.InGameMainButton "bt"
			{
				Size = Vector2(180,310),			
				BackgroundColor = ARGB(255, 255, 255, 255),
				TextColor = ARGB(255, 251, 240, 205),
				Text = name,
				CanPushDown = true,
				Skin = Gui.InGameMainButtonSkin
				{
					GameUpperImage = Gui.Image("InGameUI/select_person/ig_common_xuanren_cell03.dds", Vector4(0,0,0,0)),
					GameUpperHoverImage = Gui.Image("InGameUI/select_person/ig_common_xuanren_cell03.dds", Vector4(0,0,0,0)),
					GameActiveUpperImage = Gui.Image("InGameUI/select_person/ig_common_xuanren_down_cell03.dds", Vector4(0,0,0,0)),
				},
				Enable = true,
				EventClick = function(Sender,e)
					
				end
			},
		},
	}
	--这个地方会随着人数的增加而修改
	SelectCon.WSelect.Location = Vector2((1+180)*selectweaponindex,24)
	selectweaponindex = selectweaponindex + 1
	
	return SelectCon
end

function state.EventLeave()
	gui.EventSizeChanged = nil
	gui.EventEscPressed = nil
	gui.EventChangeState = nil
	MessageBox.CloseWaiter()
	DestroyEscMenu()
	L_Settings.Hide()
	L_Kickperson.Hide()
	
	state.EventLeave = nil
	state = nil
	selectindex = 0
	selectweaponindex = 0
	--Clear any unfinished modal window
	--ModalWindow.CloseAll()
end



InitEscMenu()
gui.EventEscPressed = SwitchEscMenu
gui.EventChangeState = function(sender, e)
	if e.Code == "B" then
		if state.IsCanCancel == true then
			selectWeaponWindow.screen.Visible = false
			gui.Focused = true
			state.SelectHasFocus = false
		end
		SelectCharacter()
	elseif e.Code == "J" then
		if selectWindow.screen.Visible == false then
			gui.Focused = true
			state.SelectHasFocus = false
			SelectWeaponUI()
		end
	end
end


--[[
function ShowWebWin()
	if WebWindow and WebWindow.screen then
		WebWindow.screen.Visible = not WebWindow.screen.Visible
		state.EscHasFocus = WebWindow.screen.Visible
	end
end
]]
function ShowWebWin()
	if WebWindow and WebWindow.screen then
		WebWindow.screen.Visible = not WebWindow.screen.Visible
		state.EscHasFocus = WebWindow.screen.Visible

		if WebWindow.screen.Visible then
			escWindow.screen.Visible = false
		end

	end
end

function ShowReportWin()
	if ReportWindow and ReportWindow.screen then
		ReportWindow.screen.Visible = not ReportWindow.screen.Visible
		state.EscHasFocus = ReportWindow.screen.Visible

		if ReportWindow.screen.Visible then
			escWindow.screen.Visible = false
		end
	end
end

function Fill_Report_Id(name,id)
	local a = Gui.Create()
	{
		Gui.RadioButton "t"
		{
			Size = Vector2(230, 20),
			FontSize = 14,
			TextColor = ARGB(255, 37, 37, 37),
			Text = name,
			ID = id,
		}
	}
	return a
end

function AddReport(name,id)
	local a = Fill_Report_Id(name,id)
	a.t.Parent = ReportWin.Report_Id
end

function SetReport_RadioCheckID(id,name)
	if id == 1 then
		ReportWin.Report_Id.RadioCheckID = id
		Report_name = name
	end
end

function DeleteAllReport()
	if ReportWin then
		ReportWin.Report_Id:DeleteTableAll()
	end
	if ReportWindow and ReportWindow.screen then
		ReportWindow.screen.Visible = false
		state.EscHasFocus = ReportWindow.screen.Visible
	end
	Report_Person_Num = 0
	ReportWin.tarea_Text.Text = ""
	Report_name = nil
	ReportWin.Report_sake.RadioCheckID = 1
end

function AddReportPerson(sender, e)
	Report_Person_Num = Report_Person_Num + 1
	AddReport(e.person_name,Report_Person_Num)
	SetReport_RadioCheckID(Report_Person_Num,e.person_name)
end

function SetEditGunInfo()
	local count = state:GetTowerTypeCount()
	for i = 1, 3 do
		SelectWeapon["button_layout"..i]:OnDestroy()
	end
	line_count = {0, 0, 0}
	for i = 0, count - 1 do
		local c = create_btn()
		
		local info = state:GetTowerType(i)
		if info.DummyObjectType == 0 then
			c["root"].Parent = SelectWeapon["button_layout1"]
			SelectWeapon["count_1"].Text = state:GetDummyObjectCountBySubType(0)
			SelectWeapon["max_count_1"].Text = state:GetMaxWallCount()
		elseif info.DummyObjectType == 1 then
			c["root"].Parent = SelectWeapon["button_layout2"]
			SelectWeapon["count_2"].Text = state:GetDummyObjectCountBySubType(1)
			SelectWeapon["max_count_2"].Text = state:GetMaxGuardCount()
		end
		
		c["root"].ItemIcon = Gui.Icon("LobbyUI/ibt_icon/"..info.ResKey..".tga")
		L_LobbyMain.ShowFightnums(c["count"],tonumber(info.MaxCount - state:GetDummyObjectCount(info.DummyObjectType, info.ResKey)),"team/lb_shop_number01.dds")
		line_count[info.DummyObjectType + 1] = line_count[info.DummyObjectType + 1] + 1
		c["root"].IntTag = i
	end
end