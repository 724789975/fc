module("L_Login", package.seeall)

-- function cache
local Vector3 = Vector3
local Vector2 = Vector2
-------------------------------------------------------------------------------------------
-- rank list
-------------------------------------------------------------------------------------------
rank_list = nil
need_update = false

Interface_Control = true


-------------------------------------------------------------------------------------------
-- 登录界面布局
-------------------------------------------------------------------------------------------
UI_Login_Root = Gui.Create()
{

	Gui.WindowUI "UI_Login_Window"
	{
		Size = Vector2(800, 600),
		ShowCloseButton = false,
		BackgroundColor = ARGB(150,255,255,255),
		Text = lang:GetText("更新日志"),
		
		Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/lb_shop_button04_hover.dds", Vector4(5, 5, 5, 5)),
				},
				
		Gui.DragLabel "31231231"
			{
				Size = Vector2(800,50),
				Text = "",
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/lb_common_textbox01_normal.dds", Vector4(5, 5, 5, 5)),
				},
			},

		Gui.FlowLayout "layout_Login"
		{
			Dock = "kDockBottom",
			Direction = "kHorizontal",
			Align = "kAlignCenterMiddle",
			ControlAlign = "kAlignCenterMiddle",
			ControlSpace = 5,
			Size = Vector2(0, 40),

			Gui.Label "lbl_UserName"
			{
				AutoSize = true,
				Text = lang:GetText("帐号名称"),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/lb_common_textbox01_normal.dds", Vector4(5, 5, 5, 5)),
				},
			},

			Gui.Textbox "tbox_UserName"
			{
				Text = config.PlayerName,
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/lb_common_textbox01_normal.dds", Vector4(5, 5, 5, 5)),
				},
			},

			Gui.Button "btn_Login"
			{
				--Style = "Gui.Buttonsimhei14",
				Text = lang:GetText("登    录"),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/lb_shop_button02_normal.dds", Vector4(15, 15, 15, 15)),
					HoverImage = Gui.Image("LobbyUI/lb_shop_button02_hover.dds", Vector4(15, 15, 15, 15)),
					DownImage = Gui.Image("LobbyUI/lb_shop_button02_down.dds", Vector4(15, 15, 15, 15)),
					DisabledImage = Gui.Image("LobbyUI/lb_shop_button02_normal.dds", Vector4(15, 15, 15, 15)),
				},

				EventClick = function()
					ptr_cast(game.CurrentState):Login(UI_Login_Root.tbox_UserName.Text, "")
				end,
			},
		},

		Gui.TextArea "tarea_BuildLog"
		{
			Dock = "kDockFill",
			Readonly = true,
			HScrollBarDisplay = "kAuto",
			VScrollBarDisplay = "kAuto",
			Text = game.BuildLog,
			TextColor = ARGB(255, 255, 255, 255),
		},
	},

	Gui.Label "lbl_Version"
	{
		AutoSize = true,
		AutoWrap = false,
		Text = string.format(lang:GetText("版本: %s"), game.Version),
	},

	Gui.Control "UI_Login_Windowother"
	{
		Size = Vector2(420, 252),
		BackgroundColor = ARGB(255,255, 255, 255),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("Login/login_win01.dds", Vector4(0, 0, 0, 0)),
		},

--[[		-- 昵称	
		Gui.Label "lbl_UserNameother"
		{
			Size = Vector2(82, 37),
			Location = Vector2(87, 96),
			TextColor = ARGB(255,255, 239, 206),
			FontSize = 30,
			Text = lang:GetText("昵 称")
		},
]]		
		-- 玩家名字
		Gui.Textbox "tbox_UserNameother"
		{
			Size = Vector2(190, 34),
			Location = Vector2(115 , 111),
			FontSize = 30,
			TextColor = ARGB(255,37, 37, 37),
			Skin = Gui.TextboxSkin
			{
				BackgroundImage = Gui.Image("Login/login_textbox01.dds", Vector4(8, 8, 8, 8)),
				ActiveImage = Gui.Image("Login/login_textbox01.dds", Vector4(8, 8, 8,8)),
			},
			
			EventValueEnter  = function()
				local namelen = game:TextLenght(UI_Login_Root.tbox_UserNameother.Text)
				-- if namelen < 2 or namelen > 8 then
					-- MessageBox.ShowError(lang:GetText("名字只能2至8个字"))
					-- return
				-- end
				
				MessageBox.ShowWaiter(lang:GetText("正在创建角色..."))	
				ptr_cast(game.CurrentState):RequestNickNameCreate(UI_Login_Root.tbox_UserNameother.Text)
			end,
		},
			
		--创建按钮
		Gui.Button "btn_play_create"
		{
			Size = Vector2(104, 36),
			Location = Vector2(158 , 175),
			Text = lang:GetText("创 建"),
			--Style = "Gui.Buttonsimhei14",
			TextColor = ARGB(255,255, 239, 206),
			HighlightTextColor = ARGB(255,255, 239, 206),
			FontSize = 18,
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("Login/login_btn01_normal.dds", Vector4(0, 0,0,0)),
				HoverImage = Gui.Image("Login/login_btn01_hover.dds", Vector4(0, 0, 0, 0)),
				DownImage = Gui.Image("Login/login_btn01_down.dds", Vector4(0, 0, 0, 0)),
				DisabledImage = Gui.Image("Login/login_btn01_normal.dds", Vector4(0, 0,0,0)),
			},
			EventClick = function()
				local namelen = game:TextLenght(UI_Login_Root.tbox_UserNameother.Text)
				-- if namelen < 2 or namelen > 8 then
					-- MessageBox.ShowError(lang:GetText("名字只能2至8个字"))
					-- return
				-- end
				MessageBox.ShowWaiter(lang:GetText("正在创建角色..."))
				ptr_cast(game.CurrentState):RequestNickNameCreate(UI_Login_Root.tbox_UserNameother.Text)
			end,
		},


	},
--[[
	--设置选项/退出
	Gui.FlowLayout "layout_Actionsother"
	{
		Align = "kAlignRightBottom",
		Direction = "kVertical",
		Size = Vector2(175, 80),
		ControlSpace = 8,
		Visible = not game.MasterBuild,

		Gui.Button "btn_Settingother"
		{
			Size = Vector2(120, 31),
			Text     = lang:GetText("设置选项"),
			FontSize = 20,
			TextColor = ARGB(255,255,239,206),
			HighlightTextColor = ARGB(255,255, 239, 206),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("Login/lb_cj_button_bg.dds", Vector4(9, 9, 9, 9)),
				HoverImage = Gui.Image("Login/lb_cj_button_hover.dds", Vector4(9, 9, 9, 9)),
				DownImage = Gui.Image("Login/lb_cj_button_down.dds", Vector4(9, 9, 9, 9)),
				DisabledImage = Gui.Image("Login/lb_cj_button_bg.dds", Vector4(9, 9, 9, 9)),
			},

			EventClick = function()
				L_Settings.Show()
				
			end,
		},

		Gui.Button "btn_Exitother"
		{
			Size = Vector2(120, 31),
			Text     = lang:GetText("退    出"),
			FontSize = 20,
			TextColor = ARGB(255,255,239,206),
			HighlightTextColor = ARGB(255,255, 239, 206),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("Login/lb_cj_button_bg.dds", Vector4(9, 9,9,9)),
				HoverImage = Gui.Image("Login/lb_cj_button_hover.dds", Vector4(9, 9,9,9)),
				DownImage = Gui.Image("Login/lb_cj_button_down.dds", Vector4(9, 9,9,9)),
				DisabledImage = Gui.Image("Login/lb_cj_button_bg.dds", Vector4(9, 9,9,9)),
			},

			EventClick = function()
				game:Exit()
			end,
		},
	},
	]]
}


-------------------------------------------------------------------------------------------
-- 设置登录界面控件坐标
-------------------------------------------------------------------------------------------
function AlignUI()
	if Interface_Control then
		Gui.Align(UI_Login_Root.UI_Login_Window, 0.5, 0.5)
		Gui.Align(UI_Login_Root.lbl_Version, 10, -10)
	else 
		Gui.Align(UI_Login_Root.UI_Login_Windowother, 0.5, 0.9)
--		Gui.Align(UI_Login_Root.layout_Actionsother, -10, -10)
	end
end

-------------------------------------------------------------------------------------------
-- 登录界面函数定义
-------------------------------------------------------------------------------------------
local connectingMB = nil
--登录
function OnLogin()
	if Interface_Control then
		UI_Login_Root.UI_Login_Window.Visible = false
	else
		UI_Login_Root.UI_Login_Windowother.Visible = false
	end

	connectingMB = MessageBox.Show(lang:GetText("正在连接服务器..."), lang:GetText("取 消"), function()
		game:LogoutAccount()
		ShowLoginWindow()
		connectingMB = nil
	end)
end
--登录成功
function OnLoginSuccess()
	if connectingMB then
		connectingMB.Close()
		connectingMB = nil
	end

	MessageBox.ShowWaiter(lang:GetText("正在进入大厅..."))
	local state = ptr_cast(game.CurrentState, "Client.StateLogin")
	if state then
		state:RequestEnterLobby()
	end
end
--进入大厅成功
function OnEnterLobbySuccess()
	MessageBox.CloseWaiter()
	if Interface_Control then
		UI_Login_Root.lbl_Version.Visible = false
	end

	Interface_Control = true
	Visible = false
	
	if L_VersionChange.Version_number ~= config.Version then
		L_VersionChange.Show_VersionChange()  
	end
end
--客户端版本错误
function OnLoginVersionError()
	MessageBox.CloseWaiter()
	local state = ptr_cast(game.CurrentState, "Client.StateLogin")

	if state then
		state.EventDisconnected = nil
		UI_Login_Root.UI_Login_Window.Visible = false
		UI_Login_Root.UI_Login_Windowother.Visible = false
		MessageBox.Show(string.format(lang:GetText("检测到服务器版本为：%s 请更新客户端"), state.ServerVersion), lang:GetText("确定"), function()
			game:AutoUpdate()
		end)
	end
end

function OnCreateNickName()
	Interface_Control = false
	connectingMB.Close()
	connectingMB = nil
	ShowLoginWindow()
	AlignUI()
end

function OnCreateNickNameFiled()
	Interface_Control = false
	ShowErrorMessage()
	ShowLoginWindow()
	AlignUI()
end

local error_message_translate =
{
	connect_failed = lang:GetText("无法连接服务器"),
	login_failed = lang:GetText("登录失败"),
	disconnected = lang:GetText("与服务器已断开连接"),
	login_from_otherip = lang:GetText("您的帐号已经在其他的地方登录"),
	server_shutdown = lang:GetText("服务器已关闭"),
	version_error = lang:GetText("版本不一致"),
}
--错误信息提示
function ShowErrorMessage()
	MessageBox.CloseWaiter()
	if connectingMB then
		connectingMB.Close()
		connectingMB = nil
	end
	
	local msg = game.ErrorMessage
	game.ErrorMessage = ""

	-- HACK: show realname auth url
	if string.sub(msg, 1, 5) == "auth:" then
		MessageBox.Show(lang:GetText("请补填实名制信息"), lang:GetText("确 定"), function()
			ShowLoginWindow()
		end)
	else
		if msg == "disconnected" then
			MessageBox.MessageBox.ShowWithConfirm(lang:GetText("您与服务器已断开连接，请重新登录！"),
				function(sender,e)
					Thread.Quit()
				end,
			nil)
		end
		
		msg = error_message_translate[msg] or msg

		if msg ~= "" then
			MessageBox.Show(msg, lang:GetText("确 定"), function()
				ShowLoginWindow()
			end)
		end
	end
end
--断开连接
function OnDisconnected()
	ModalWindow.Close()

	if L_LobbyMain and L_LobbyMain.MarkResetLobby then
		L_LobbyMain.MarkResetLobby()
	end
	
	MessageBox.MessageBox.ShowWithConfirm(lang:GetText("您与服务器已断开连接，请重新登录！"),
		function(sender,e)
			Thread.Quit()
		end,
	nil)
	ShowErrorMessage()
end

function ShowLoginWindow()
	rpc.clear()

	local state = ptr_cast(game.CurrentState, "Client.StateLogin")

	if not state then
		return
	end
	if Interface_Control then
		UI_Login_Root.UI_Login_Windowother.Parent = nil
--		UI_Login_Root.layout_Actionsother.Parent = nil
		UI_Login_Root.UI_Login_Windowother.Visible = false

		UI_Login_Root.UI_Login_Window.Parent = gui
		UI_Login_Root.UI_Login_Window.Visible = true
		UI_Login_Root.tbox_UserName.Focused = true
	else 
		UI_Login_Root.UI_Login_Window.Parent = nil
		UI_Login_Root.UI_Login_Window.Visible = false

		UI_Login_Root.UI_Login_Windowother.Parent = gui
--		UI_Login_Root.layout_Actionsother.Parent = gui
		UI_Login_Root.UI_Login_Windowother.Visible = true
		UI_Login_Root.tbox_UserNameother.Focused = true
	end
	
	AlignUI()
end

local bg = nil

function Show()
	if not Visible then
		local state = ptr_cast(game.CurrentState, "Client.StateLogin")

		if not state then
			return
		end

		Visible = true
		if Interface_Control then
			UI_Login_Root.tbox_UserName.Focused = true
		else
			UI_Login_Root.tbox_UserNameother.Focused = true
		end

--[[		bg = Gui.Create(gui)
		{
			Gui.Picture "logo"
			{
				Style = "",
				BackgroundColor = ARGB(0,0,0,0),
				Margin = Vector4(10,10,10,10),
				Size = Vector2(470, 160),
				Dock = "kDockBottomCenter",
				ForeGroundImage = Gui.Image("MapsAndBG/BG/login_text.tga"),
			}
		}]]

		if game.ErrorMessage ~= "" then
			ShowErrorMessage()
		else
			ShowLoginWindow()
		end
		if Interface_Control then
			UI_Login_Root.lbl_Version.Parent = gui
		else 
--			UI_Login_Root.layout_Actionsother.Parent = gui
		end

		state.EventLogin = OnLogin
		state.EventLoginSuccess = OnLoginSuccess
		state.EventEnterLobbySuccess = OnEnterLobbySuccess
		state.EventDisconnected = OnDisconnected
		state.EventCreateNickName = OnCreateNickName
		state.EventCreateNickNameFiled = OnCreateNickNameFiled	
	end
	
	AlignUI()
end

function Hide()
	Visible = false

	UI_Login_Root.UI_Login_Window.Parent = nil		
	UI_Login_Root.lbl_Version.Parent = nil		
	UI_Login_Root.UI_Login_Windowother.Parent = nil
--	UI_Login_Root.layout_Actionsother.Parent = nil
--	UI_Login_Root.layout_Actionsother.Parent = nil

--	bg.logo.Parent = nil
	bg = nil

	local state = ptr_cast(game.CurrentState, "Client.StateLogin")

	if state then
		state.EventLogin = nil
		state.EventLoginSuccess = nil
		state.EventDisconnected = nil
		state.EventEnterLobbySuccess = nil
	end

	if connectingMB then
		connectingMB.Close()
		connectingMB = nil
	end
end
