module("Debug",package.seeall)

function CheckMasterBuild()
	if game.MasterBuild then
		gui:ShowMessage(lang:GetText("此功能开发中，暂未开放"))
		return true
	else
		return false
	end
end