module("CommonUtility", package.seeall)

cumulate = true

function ShowMessage(sender, args)
	if cumulate == false then
		return
	end
	cumulate = false
	if args then
		MessageBox.Show(args.Message, lang:GetText("我知道了"),function()
													CommonUtility.cumulate = true
												 end)
	end
end

function IsEventTriggeredByUser(e)
    if e and e.Source then
        return (e.Source == "kTriggerSourceMouse" or e.Source == "kTriggerSourceKeyboard" or e.Source == "kTriggerSourceUserInput")
    else
        print("Invalid eventArgs")
        return false
    end
end

local helpUI = Gui.Create()
{
	Gui.Control "content"
	{
		Size = Vector2(622,471),
		Dock = "kDockFill",

		Gui.Control
		{
			Size = Vector2(622,63),
			Dock = "kDockBottom",
			Gui.Button "buttonClose"
			{
				Size = Vector2(103, 53),
				Margin = Vector4(0,0,5,5),
				Dock = "kDockRightBottom",
				Text = lang:GetText("关   闭"),
			},
		},

		Gui.Tabpad "contentsTabs"
		{
			Size = Vector2(622,384),
			Dock = "kDockFill",
			TabLableAutoFill = true,
			Gui.Control
			{
				Text = lang:GetText("操作按键"),
				Gui.Picture "pic1_1"
				{
					Style = "",
					BackgroundColor = ARGB(0,0,0,0),
					Margin = Vector4(5,5,5,0),
					Size = Vector2(40, 26),
					Dock = "kDockTop",
					ForeGroundImage = Gui.Image("skinD/skinD_helpwindow11.tga"),
				},
				Gui.Picture "pic1_2"
				{
					Style = "",
					BackgroundColor = ARGB(0,0,0,0),
					Margin = Vector4(5,0,5,5),
					Size = Vector2(40, 316),
					Dock = "kDockBottom",
					ForeGroundImage = Gui.Image("skinD/skinD_helpwindow01.tga"),
				},
			},
			Gui.Control
			{
				Text = lang:GetText("快捷按键"),
				Gui.Picture "pic1_1"
				{
					Style = "",
					BackgroundColor = ARGB(0,0,0,0),
					Margin = Vector4(5,5,5,0),
					Size = Vector2(40, 26),
					Dock = "kDockTop",
					ForeGroundImage = Gui.Image("skinD/skinD_helpwindow11.tga"),
				},
				Gui.Picture "pic1_2"
				{
					Style = "",
					BackgroundColor = ARGB(0,0,0,0),
					Margin = Vector4(5,0,5,5),
					Size = Vector2(40, 316),
					Dock = "kDockBottom",
					ForeGroundImage = Gui.Image("skinD/skinD_helpwindow07.tga"),
				},
			},
		},
	},
}

local helpWin = nil
function InitHelpWindow()
	helpWin = ModalWindow.GetNew("settings")
	helpWin.screen.AllowEscToExit = false
	helpWin.screen.AllowF1 = true
	helpWin.screen.Visible = false
	helpWin.screen.EventEscPressed = SwitchHelp
	gui.Focused = true
	helpWin.root.Size = Vector2(622,514)
	helpUI.content.Parent = helpWin.root

	helpUI.buttonClose.EventClick = function()
		helpWin.screen.Visible = false
		gui.Focused = true
	end
end

function DestroyHelpWindow()
	helpUI.buttonClose.EventClick = nil
	helpUI.content.Parent = nil
	helpWin.screen.EventEscPressed = nil
	helpWin.Close()
	helpWin=nil
end

function SwitchHelp()
	if helpWin and helpWin.screen then
		helpWin.screen.Visible = not helpWin.screen.Visible
		if helpWin.screen.Visible then
			helpWin.root.Focused = true --Let it handle esc first
		else
			gui.Focused = true --Give esc handler from helpwin to gui
		end
	end
end
--[[
function ShowHelpWindow()
	helpWin = ModalWindow.GetNew("settings")
	helpWin.root.Size = Vector2(622,514)
	helpWin.AllowEscToExit = true
	helpUI.content.Parent = helpWin.root
	return helpWin
end
function CloseHelpWindow()
	if helpWin then
		helpWin.Close()
		helpWin = nil
	end
end
]]

gui.EventShowMessage = ShowMessage

local menu_map =
{
	IDM_VIEW =
	{
		lang:GetText("查看信息"),
		function(args) OtherView.Show(args.win,args.name) end,
	},
	IDM_MAIL =
	{
		lang:GetText("发送邮件"),
		function(args) QuickMail.Show(args.name) end,
	},
	IDM_WHISPER =
	{
		lang:GetText("发送密语"),
		function(args) Chat.ChatWindow:Whisper(args.name) end,
	},
	IDM_ADD_FRIEND =
	{
		lang:GetText("加为好友"),
		function(args) Friends.AddFriend(args.id or args.name) end,
	},
	IDM_DELETE_FRIEND =
	{
		lang:GetText("删除"),
		function(args) Friends.DeleteFriend(args.id,args.name) end,
	},
	IDM_ADD_BLACK =
	{
		lang:GetText("加入黑名单"),
		function(args) Friends.AddBlack(args.id or args.name) end,
	},
	IDM_DELETE_BLACK =
	{
		lang:GetText("删除"),
		function(args) Friends.DeleteBlack(args.id or args.name) end,
	},
	IDM_INVITE =
	{
		lang:GetText("组队"),
		function(args) ptr_cast(game.CurrentState):TeamInvite(args.name) end,
	},
	IDM_ROOM_INVITE =
	{
		lang:GetText("邀请"),
		function(args) ptr_cast(game.CurrentState):RoomInvite(args.name) end,
	},
	IDM_ENTER_ROOM =
	{
		lang:GetText("加入"),
		function(args) Lobby.GotoPlayerRoom(args.name,false) end,
	},
}

function InitMenu(menu,t)
	for _,v in ipairs(t) do
		if v ~= nil then
			menu:AddItem(menu_map[v][1],v)
		else
			menu:AddSeparator()
		end
	end
end

function ResponseMenu(menu,args)
	local id = menu:GetId(menu.SelectedIndex)
	menu_map[id][2](args)
end

function InitLtvHeader(ltv,t)
	for _,v in ipairs(t) do
		ltv:AddColumn(table.unpack(v))
	end
end
