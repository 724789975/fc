module("ModalWindow", package.seeall)

--local AllModalWindows = {}
AllModalWindows = {}

local emptyFunction = function() print("+++++++++++++++++++++++I'm ModalWindow: empty+++++++++++++++++++++") end

function GetNew(style)
	local modal_win = Gui.Create(gui)
	{
		Gui.ModalControl "screen"
		{
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/lb_common_black_bg.dds",Vector4(0, 0, 0, 0)),
			},
		},
	}
	if style and style=="transparent" then
		modal_win.screen.RootPanel.Style = "Gui.Control"
	elseif style and style=="otherview" then
		modal_win.screen.RootPanel.Style = "Gui.OtherViewWindow"
	elseif style and style=="settings" then
		modal_win.screen.RootPanel.Style = "Gui.SettingsWindow"
	elseif style and style=="select" then
		modal_win.screen.RootPanel.Style = "Gui.SelectWindow"
	elseif style and style=="WebWin" then
		modal_win.screen.RootPanel.Style = "Gui.Control"
	else
		modal_win.screen.RootPanel.Style = "Gui.ModalWindow"
	end
	modal_win.screen.RootPanel.Size = Vector2(554,268)
	modal_win.root = modal_win.screen.RootPanel
	modal_win.Close = function(bLaterRemove)
			--print("Modal Window Close")
			local found = -1
			for index, value in ipairs(AllModalWindows) do
				if value==modal_win then
					--print("Found modal window handle:  deleting")
					found = index
				end
			end
			if found>0 and (not bLaterRemove) then
				table.remove(AllModalWindows, found)
			end
			modal_win.root:Close()
			modal_win.Close = emptyFunction
		end
	table.insert(AllModalWindows, modal_win)
	return modal_win
end

local singletonMW = nil
function Show(style)
	--print("ModalWindow.Show")
	if singletonMW then
		singletonMW.Close()
		singletonMW = nil
	end
	singletonMW = GetNew(style)
	return singletonMW
end

function Close()
	--print("ModalWindow.Close")
	if singletonMW then
		--print("There is a modal window left, now closing")
		singletonMW.Close()
		singletonMW = nil
	end
end

function CloseAll()
	--Close singletonMW
	Close()
	
	--Close all other windows
	while #AllModalWindows > 0 do
		print("Found "..#AllModalWindows.." modal window left, cleaning...")
		AllModalWindows[1].Close(true)								--Mark it as later remove in next statement, otherwise the while coule be a infinite loop if Close() can not remove it from AllModalWindows
																	--For messagebox, this clearance only clear it from the screen, it's still in memory
																	--because messageBoxXX.Close() still reference to modalwindow non-empty Close function,
																	--the reference circle is still there
																	--function modalWindow.FuncNonEmpty()
																	--function modalWindow.FuncEmpty()
																	--modal.Close = modalWindow.FuncNonEmpty
																	--mb.Close = modal.Close (= modalWindow.FuncNonEmpty)
																	--after this clearance: modal.Close = modalWindow.FuncEmpty
																	--but mb.Close (still) = modalWindow.FuncNonEmpty
		table.remove(AllModalWindows, 1)		--Unnessecary since *.Close() will remove it from AllModalWindows
		print("Cleaning finished, now "..#AllModalWindows.." modal window left")
	end
end