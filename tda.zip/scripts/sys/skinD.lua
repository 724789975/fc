module("Skin", package.seeall)

require("iconsD.lua")

-- cache functions
local Style = Gui.Style
local Vector2 = Vector2
local Vector3 = Vector3
local Vector4 = Vector4
local ARGB = ARGB
local XRGB = XRGB

rarelevel = {
				Gui.Icon("LobbyUI/lb_shop_treasureico_pt.dds"),
				Gui.Icon("LobbyUI/lb_shop_treasureico_jl.dds"),
				Gui.Icon("LobbyUI/lb_shop_treasureico_zy.dds"),
				Gui.Icon("LobbyUI/lb_shop_treasureico_xy.dds"),
				Gui.Icon("LobbyUI/lb_shop_treasureico_ds.dds"),
				Gui.Icon("LobbyUI/lb_shop_treasureico_cs.dds"),
			}
rarelevel_Image = 
			{
				Gui.Image("LobbyUI/lb_shop_treasureico_pt.dds", Vector4(0,0,0,0)),
				Gui.Image("LobbyUI/lb_shop_treasureico_jl.dds", Vector4(0,0,0,0)),
				Gui.Image("LobbyUI/lb_shop_treasureico_zy.dds", Vector4(0,0,0,0)),
				Gui.Image("LobbyUI/lb_shop_treasureico_xy.dds", Vector4(0,0,0,0)),
				Gui.Image("LobbyUI/lb_shop_treasureico_ds.dds", Vector4(0,0,0,0)),
				Gui.Image("LobbyUI/lb_shop_treasureico_cs.dds", Vector4(0,0,0,0)),
			}

EmpowermentBaseSkin = Gui.ControlSkin
{
	BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_manage_power_white.dds", Vector4(0, 0, 0, 0)),
}

EmpowermentTopSkin = Gui.ControlSkin
{
	BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_manage_power_content.dds", Vector4(0, 0, 0, 0)),
}


local newScrollableSkin = Gui.ScrollableControlSkin
{
	--Control skin
	--BackgroundImage = Gui.Image("LobbyUI/lb_common_scrollbar01_bg.dds", Vector4(0, 0, 0, 0)),
	
	--ScrollableControl skin
	UpButtonNormalImage = Gui.Image("DefaultSkin/ScrollableControlNew/lb_common_crollbar01_t_normal.tga", Vector4(0, 0, 0, 0)),
	UpButtonHoverImage = Gui.Image("DefaultSkin/ScrollableControlNew/lb_common_crollbar01_t_hover.tga", Vector4(0, 0, 0, 0)),
	UpButtonDownImage = Gui.Image("DefaultSkin/ScrollableControlNew/lb_common_crollbar01_t_down.tga", Vector4(0, 0, 0, 0)),
	UpButtonDisabledImage = Gui.Image("DefaultSkin/ScrollableControlNew/lb_common_crollbar01_t_disabled.tga", Vector4(0, 0, 0, 0)),

	DownButtonNormalImage = Gui.Image("DefaultSkin/ScrollableControlNew/lb_common_crollbar01_b_normal.tga", Vector4(0, 0, 0, 0)),
	DownButtonHoverImage = Gui.Image("DefaultSkin/ScrollableControlNew/lb_common_crollbar01_b_hover.tga", Vector4(0, 0, 0, 0)),
	DownButtonDownImage = Gui.Image("DefaultSkin/ScrollableControlNew/lb_common_crollbar01_b_down.tga", Vector4(0, 0, 0, 0)),
	DownButtonDisabledImage = Gui.Image("DefaultSkin/ScrollableControlNew/lb_common_crollbar01_b_disabled.tga", Vector4(0, 0, 0, 0)),

	VSliderNormalImage = Gui.Image("DefaultSkin/ScrollableControlNew/lb_common_scrollbar01_slider_normal.tga", Vector4(0, 14, 0, 14)),
	VSliderHoverImage = Gui.Image("DefaultSkin/ScrollableControlNew/lb_common_scrollbar01_slider_hover.tga", Vector4(0, 14, 0, 14)),
	VSliderDownImage = Gui.Image("DefaultSkin/ScrollableControlNew/lb_common_scrollbar01_slider_down.tga", Vector4(0, 14, 0, 14)),
	VSliderDisabledImage = Gui.Image("DefaultSkin/ScrollableControlNew/lb_common_scrollbar01_slider_normal.tga", Vector4(0, 14, 0, 14)),

	VBarBackgroundImage = Gui.Image("DefaultSkin/ScrollableControlNew/lb_common_scrollbar01_bg.tga", Vector4(0, 45, 0, 45)),
	BarCornerImage = nil,
}

local commonScrSkin = Gui.ScrollableControlSkin
{
		--Control skin
		--BackgroundImage = Gui.Image("skinD/skinD_common_window04.tga", Vector4(5, 5, 5, 5)),

		--ScrollableControl skin
		UpButtonNormalImage = Gui.Image("DefaultSkin/ScrollableControl/skinD_common_scrollbar01_button_up_normal.tga", Vector4(0, 0, 0, 0)),
		UpButtonHoverImage = Gui.Image("DefaultSkin/ScrollableControl/skinD_common_scrollbar01_button_up_hover.tga", Vector4(0, 0, 0, 0)),
		UpButtonDownImage = Gui.Image("DefaultSkin/ScrollableControl/skinD_common_scrollbar01_button_up_down.tga", Vector4(0, 0, 0, 0)),
		UpButtonDisabledImage = Gui.Image("DefaultSkin/ScrollableControl/skinD_common_scrollbar01_button_up_disabled.tga", Vector4(0, 0, 0, 0)),

		DownButtonNormalImage = Gui.Image("DefaultSkin/ScrollableControl/skinD_common_scrollbar01_button_down_normal.tga", Vector4(0, 0, 0, 0)),
		DownButtonHoverImage = Gui.Image("DefaultSkin/ScrollableControl/skinD_common_scrollbar01_button_down_hover.tga", Vector4(0, 0, 0, 0)),
		DownButtonDownImage = Gui.Image("DefaultSkin/ScrollableControl/skinD_common_scrollbar01_button_down_down.tga", Vector4(0, 0, 0, 0)),
		DownButtonDisabledImage = Gui.Image("DefaultSkin/ScrollableControl/skinD_common_scrollbar01_button_down_disabled.tga", Vector4(0, 0, 0, 0)),

		LeftButtonNormalImage = Gui.Image("DefaultSkin/ScrollableControl/skinD_common_scrollbar01_button_left_normal.tga", Vector4(0, 0, 0, 0)),
		LeftButtonHoverImage = Gui.Image("DefaultSkin/ScrollableControl/skinD_common_scrollbar01_button_left_hover.tga", Vector4(0, 0, 0, 0)),
		LeftButtonDownImage = Gui.Image("DefaultSkin/ScrollableControl/skinD_common_scrollbar01_button_left_down.tga", Vector4(0, 0, 0, 0)),
		LeftButtonDisabledImage = Gui.Image("DefaultSkin/ScrollableControl/skinD_common_scrollbar01_button_left_disabled.tga", Vector4(0, 0, 0, 0)),

		RightButtonNormalImage = Gui.Image("DefaultSkin/ScrollableControl/skinD_common_scrollbar01_button_right_normal.tga", Vector4(0, 0, 0, 0)),
		RightButtonHoverImage = Gui.Image("DefaultSkin/ScrollableControl/skinD_common_scrollbar01_button_right_hover.tga", Vector4(0, 0, 0, 0)),
		RightButtonDownImage = Gui.Image("DefaultSkin/ScrollableControl/skinD_common_scrollbar01_button_right_down.tga", Vector4(0, 0, 0, 0)),
		RightButtonDisabledImage = Gui.Image("DefaultSkin/ScrollableControl/skinD_common_scrollbar01_button_right_disabled.tga", Vector4(0, 0, 0, 0)),

		VSliderNormalImage = Gui.Image("DefaultSkin/ScrollableControl/skinD_common_scrollbar01_slider_normal.tga", Vector4(5, 11, 5, 11)),
		VSliderHoverImage = Gui.Image("DefaultSkin/ScrollableControl/skinD_common_scrollbar01_slider_hover.tga", Vector4(5, 11, 5, 11)),
		VSliderDownImage = Gui.Image("DefaultSkin/ScrollableControl/skinD_common_scrollbar01_slider_hover.tga", Vector4(5, 11, 5, 11)),
		VSliderDisabledImage = Gui.Image("DefaultSkin/ScrollableControl/skinD_common_scrollbar01_slider_normal.tga", Vector4(5, 11, 5, 11)),

		HSliderNormalImage = Gui.Image("DefaultSkin/ScrollableControl/skinD_common_scrollbar01_hslider_normal.tga", Vector4(11, 5, 11, 5)),
		HSliderHoverImage = Gui.Image("DefaultSkin/ScrollableControl/skinD_common_scrollbar01_hslider_hover.tga", Vector4(11, 5, 11, 5)),
		HSliderDownImage = Gui.Image("DefaultSkin/ScrollableControl/skinD_common_scrollbar01_hslider_hover.tga", Vector4(11, 5, 11, 5)),
		HSliderDisabledImage = Gui.Image("DefaultSkin/ScrollableControl/skinD_common_scrollbar01_hslider_normal.tga", Vector4(11, 5, 11, 5)),

		VBarBackgroundImage = Gui.Image("DefaultSkin/ScrollableControl/skinD_common_scrollbar01_background.tga", Vector4(5, 34, 5, 34)),
		HBarBackgroundImage = Gui.Image("DefaultSkin/ScrollableControl/skinD_common_scrollbar01_hbackground.tga", Vector4(34, 5, 34, 5)),
}

Style "Gui.ScrollableControl"
{
	Skin = newScrollableSkin,
	BackgroundColor = ARGB(210,20,23,31),
}

Style "Gui.Control_Compose_down"
{
	Size = Vector2(28, 36),
	BackgroundColor = ARGB(255, 255, 255, 255),
	Skin = Gui.ControlSkin
	{
		BackgroundImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_ico_01_normal.dds", Vector4(0, 0, 0, 0)),
	},
}

Style "Gui.Control_Compose_up"
{
	Size = Vector2(28, 36),
	BackgroundColor = ARGB(255, 255, 255, 255),
	Skin = Gui.ControlSkin
	{
		BackgroundImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_ico_01_up_normal.dds", Vector4(0, 0, 0, 0)),
	},
}

Style "Gui.tab_button"
{
	Size = Vector2(215, 52),
	Skin = Gui.ButtonSkin
	{
		BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_normal.dds", Vector4(10, 10, 10, 10)),
		HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_hover.dds", Vector4(10, 10, 10, 10)),
		DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_down.dds", Vector4(10, 10, 10, 10)),
		DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_normal.dds", Vector4(10, 10, 10, 10)),
	},
	BackgroundColor = ARGB(255,255,255,255),
	TextColor = ARGB(255, 37, 37, 37),
	HighlightTextColor = ARGB(255, 30, 29, 29),
	FontSize = 18,
}

Style "Gui.Mission_button"
{
	FontSize = 18,
	Size = Vector2(104, 36),
	Skin = Gui.ButtonSkin
	{
		BackgroundImage = Gui.Image("LobbyUI/team/lb_contact_button_normal.tga", Vector4(5, 5, 5, 5)),
		HoverImage = Gui.Image("LobbyUI/team/lb_contact_button_hover.tga", Vector4(5, 5, 5, 5)),
		DownImage = Gui.Image("LobbyUI/team/lb_contact_button_down.tga", Vector4(5, 5, 5, 5)),
		DisabledImage = Gui.Image("LobbyUI/team/lb_contact_button_normal.tga", Vector4(5, 5, 5, 5)),			
	},
	BackgroundColor = ARGB(255,255,255,255),
	TextColor = ARGB(255, 211, 211, 211),
	HighlightTextColor = ARGB(255, 211, 211, 211),
}

-------------------------------------------------------------------------------
ButtonSkin_ItemBoxBtn = Gui.ButtonSkin
{
	BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button7_normal.dds", Vector4(10, 8, 10, 8)),
	HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button7_hover.dds", Vector4(10, 8, 10, 8)),
	DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button7_down.dds", Vector4(10, 8, 10, 8)),
	DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button7_normal.dds", Vector4(10, 8, 10, 8)),
}

ButtonSkin_ItemBoxBtn_gift = Gui.ButtonSkin
{
	BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button7_give_normal.dds", Vector4(10, 8, 10, 8)),
	HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button7_give_hover.dds", Vector4(10, 8, 10, 8)),
	DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button7_give_down.dds", Vector4(10, 8, 10, 8)),
	DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button7_give_normal.dds", Vector4(10, 8, 10, 8)),
}

ButtonSkin_ItemBoxBtn_buy = Gui.ButtonSkin
{
	BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button8_normal.dds", Vector4(10, 8, 10, 8)),
	HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button8_hover.dds", Vector4(10, 8, 10, 8)),
	DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button8_down.dds", Vector4(10, 8, 10, 8)),
	DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button8_normal.dds", Vector4(10, 8, 10, 8)),
}

ButtonSkin_ItemBoxBtn_destory = Gui.ButtonSkin
{
	BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button9_normal.dds", Vector4(10, 8, 10, 8)),
	HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button9_hover.dds", Vector4(10, 8, 10, 8)),
	DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button9_down.dds", Vector4(10, 8, 10, 8)),
	DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button9_normal.dds", Vector4(10, 8, 10, 8)),
}

ButtonSkin_Weapon = Gui.ButtonSkin
{
	BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_arms_normal.dds", Vector4(5, 5, 5, 5)),
	HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_arms_hover.dds", Vector4(5, 5, 5, 5)),
	DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_arms_down.dds", Vector4(5, 5, 5, 5)),
	DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_arms_normal.dds", Vector4(5, 5, 5, 5)),
}

ButtonSkin_Clothes = Gui.ButtonSkin
{
	BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_clothes_normal.dds", Vector4(5, 5, 5, 5)),
	HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_clothes_hover.dds", Vector4(5, 5, 5, 5)),
	DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_clothes_down.dds", Vector4(5, 5, 5, 5)),
	DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_clothes_normal.dds", Vector4(5, 5, 5, 5)),
}

ButtonSkin_Hat = Gui.ButtonSkin
{
	BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_hat_normal.dds", Vector4(5, 5, 5, 5)),
	HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_hat_hover.dds", Vector4(5, 5, 5, 5)),
	DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_hat_down.dds", Vector4(5, 5, 5, 5)),
	DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_hat_normal.dds", Vector4(5, 5, 5, 5)),
}

ButtonSkin_material = Gui.ButtonSkin
{
	BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_material_normal.dds", Vector4(5, 5, 5, 5)),
	HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_material_hover.dds", Vector4(5, 5, 5, 5)),
	DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_material_down.dds", Vector4(5, 5, 5, 5)),
	DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_material_normal.dds", Vector4(5, 5, 5, 5)),
	TwinkleImage  = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_flash.dds", Vector4(5, 5, 5, 5)),
}

ButtonSkin_props = Gui.ButtonSkin
{
	BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_props_normal.dds", Vector4(5, 5, 5, 5)),
	HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_props_hover.dds", Vector4(5, 5, 5, 5)),
	DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_props_down.dds", Vector4(5, 5, 5, 5)),
	DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_props_normal.dds", Vector4(5, 5, 5, 5)),
}

ButtonSkin_spree = Gui.ButtonSkin
{
	BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_spree_normal.dds", Vector4(5, 5, 5, 5)),
	HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_spree_hover.dds", Vector4(5, 5, 5, 5)),
	DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_spree_down.dds", Vector4(5, 5, 5, 5)),
	DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_spree_normal.dds", Vector4(5, 5, 5, 5)),
}
-------------------------------------------------------------------------------
TakePicSkin = Gui.ButtonSkin
{
	BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_button01_normal.dds", Vector4(45,0,6,0)),
	HoverImage = Gui.Image("LobbyUI/persionalInfo/lb_info_button01_hover.dds", Vector4(45,0,6,0)),
	DownImage = Gui.Image("LobbyUI/persionalInfo/lb_info_button01_down.dds", Vector4(45,0,6,0)),
}

ComboBoxSkin_ItemBoxBtn = Gui.ComboBoxSkin
{
 	ButtonNormalImage= Gui.Image("LobbyUI/lb_shop_combobox_button_normal.dds", Vector4(7, 7, 7, 7)),
	ButtonHoverImage = Gui.Image("LobbyUI/lb_shop_combobox_button_hover.dds", Vector4(7, 7, 7, 7)),
	ButtonDownImage = Gui.Image("LobbyUI/lb_shop_combobox_button_down.dds", Vector4(7, 7, 7, 7)),
	--ButtonDisabledImage = Gui.Image("DefaultSkin/DefaultSkin_common_combobox01_button_disabled.tga", Vector4(0, 6, 10, 6)),
		
 	--TextNormalImage= Gui.Image("LobbyUI/lb_shop_combobox_downbg.dds", Vector4(5, 5, 5, 5)),
	TextHoverImage = Gui.Image("LobbyUI/lb_shop_combobox_downbg.dds", Vector4(5, 5, 5, 5)),
	TextDownImage = Gui.Image("LobbyUI/lb_shop_combobox_downbg.dds", Vector4(5, 5, 5, 5)),
	--TextDisabledImage = Gui.Image("DefaultSkin/DefaultSkin_common_combobox01_text_disabled.tga", Vector4(6, 6, 0, 6)),
}

Style "Gui.ComboListSkin_ItemBoxBtn"
{
	Skin = Gui.ComboListSkin
	{
		--Control skin
		BackgroundImage = Gui.Image("LobbyUI/lb_shop_bg2.dds", Vector4(17, 17, 17, 17)),
		
		--Scrollable Control skin
		UpButtonNormalImage = Gui.Image("DefaultSkin/combolist/lb_common_combobox01_button_normal.dds", Vector4(0, 0, 0, 0)),
		UpButtonHoverImage = Gui.Image("DefaultSkin/combolist/lb_common_combobox01_button_hover.dds", Vector4(0, 0, 0, 0)),
		UpButtonDownImage = Gui.Image("DefaultSkin/combolist/lb_common_combobox01_button_down.dds", Vector4(0, 0, 0, 0)),
		UpButtonDisabledImage = Gui.Image("DefaultSkin/combolist/lb_common_combobox01_button_normal.dds", Vector4(0, 0, 0, 0)),

		DownButtonNormalImage = Gui.Image("DefaultSkin/combolist/lb_common_combobox01_button_normal.dds", Vector4(0, 0, 0, 0)),
		DownButtonHoverImage = Gui.Image("DefaultSkin/combolist/lb_common_combobox01_button_hover.dds", Vector4(0, 0, 0, 0)),
		DownButtonDownImage = Gui.Image("DefaultSkin/combolist/lb_common_combobox01_button_down.dds", Vector4(0, 0, 0, 0)),
		DownButtonDisabledImage = Gui.Image("DefaultSkin/combolist/lb_common_combobox01_button_normal.dds", Vector4(0, 0, 0, 0)),
		
		--ComboList skin
		ItemHoverImage = Gui.Image("DefaultSkin/combolist/lb_common_combobox01_dropdown_hover.dds", Vector4(10, 0, 32, 0)),
		ItemActiveImage = Gui.Image("DefaultSkin/combolist/lb_common_combobox01_dropdown_down.dds", Vector4(10, 0, 32, 0)),
	},
	
	TextColor = ARGB(255, 255, 255, 255),
	ItemAlign = "kAlignCenterMiddle",
	Border = Vector4(0, 0, 0, 0),
}

ButtonSkin_EnterGame = Gui.ButtonSkin
{
	BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_enter03_normal.dds", Vector4(0, 0, 0, 0)),
	HoverImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_enter03_hover.dds", Vector4(0, 0, 0, 0)),
	DownImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_enter03_down.dds", Vector4(0, 0, 0, 0)),
	DisabledImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_enter03_disabled.dds", Vector4(0, 0, 0, 0)),
}

ButtonSkin_StartGame = Gui.ButtonSkin
{
	BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_play_normal.dds", Vector4(0, 0, 0, 0)),
	HoverImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_play_hover.dds", Vector4(0, 0, 0, 0)),
	DownImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_play_down.dds", Vector4(0, 0, 0, 0)),
	DisabledImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_play_disabled.dds", Vector4(0, 0, 0, 0)),
}

ButtonSkin_Ready = Gui.ButtonSkin
{
	BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_ready_normal.dds", Vector4(0, 0, 0, 0)),
	HoverImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_ready_hover.dds", Vector4(0, 0, 0, 0)),
	DownImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_ready_down.dds", Vector4(0, 0, 0, 0)),
	DisabledImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_ready_disabled.dds", Vector4(0, 0, 0, 0)),
}

ButtonSkin_ReadyCancel = Gui.ButtonSkin
{
	BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_cancel_normal.dds", Vector4(0, 0, 0, 0)),
	HoverImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_cancel_hover.dds", Vector4(0, 0, 0, 0)),
	DownImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_cancel_down.dds", Vector4(0, 0, 0, 0)),
	DisabledImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_button_cancel_disabled.dds", Vector4(0, 0, 0, 0)),
}

ListItemSkin_Black = Gui.ListItemSkin
{	--control skin
	BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_info_list_title01.dds", Vector4(8,3,50,3)),
}

ListItemSkin_Single = Gui.ListItemSkin
{
	--control skin
	BackgroundImage = Gui.Image("LobbyUI/lb_common_listcontent02_normal_a.dds", Vector4(8, 0, 42, 0)),
	SelfImage = Gui.Image("LobbyUI/GameBalance/lb_common_listcontent01_me.dds", Vector4(8,3,56,3)),
	--list item skin
	HoverImage = Gui.Image("LobbyUI/lb_common_listcontent02_hover.dds", Vector4(8, 0, 42, 0)),
	SelectedImage = Gui.Image("LobbyUI/lb_common_listcontent02_down.dds", Vector4(8, 0, 42, 0)),
	DisabledImage = Gui.Image("LobbyUI/lb_common_listcontent02_disabled.dds", Vector4(8, 0, 318, 0)),
}

ListItemSkin_Normal_Single = Gui.ListItemSkin
{
	--control skin
	BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_common_listcontent02_1_normal_a.dds", Vector4(8, 0, 42, 0)),
	SelfImage = Gui.Image("LobbyUI/GameBalance/lb_common_listcontent01_me1.dds", Vector4(8,3,56,3)),
	--list item skin
	HoverImage = Gui.Image("LobbyUI/GameBalance/lb_common_listcontent02_1_hover.dds", Vector4(8, 0, 42, 0)),
	SelectedImage = Gui.Image("LobbyUI/GameBalance/lb_common_listcontent02_1_down.dds", Vector4(8, 0, 42, 0)),
	DisabledImage = Gui.Image("LobbyUI/GameBalance/lb_common_listcontent02_1_disabled.dds", Vector4(8, 0, 318, 0)),
}

SourceRankSkin = Gui.ListItemSkin
{
	--control skin
	BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_phb01.dds", Vector4(93,0,21,0)),
	-- SelfImage = Gui.Image("LobbyUI/GameBalance/lb_common_listcontent01_me.dds", Vector4(8,3,56,3)),
	--list item skin
	HoverImage = Gui.Image("LobbyUI/team/lb_squad_phb02.dds", Vector4(93,0,21,0)),
	SelectedImage = Gui.Image("LobbyUI/team/lb_squad_phb02.dds", Vector4(93,0,21,0)),
	DisabledImage = Gui.Image("LobbyUI/team/lb_squad_phb01.dds", Vector4(93,0,21,0)),
}

ListSourceItemSkin = Gui.ListItemSkin
{
	--control skin
	BackgroundImage = nil,
	SelfImage = Gui.Image("LobbyUI/GameBalance/lb_common_listcontent01_me.dds", Vector4(8,3,56,3)),
	--list item skin
	HoverImage = Gui.Image("LobbyUI/team/lb_opt_bg_hover.dds", Vector4(45, 0, 9, 0)),
	SelectedImage = Gui.Image("LobbyUI/team/lb_opt_bg_down.dds", Vector4(45, 0, 9, 0)),
	DisabledImage = nil,
	CheckOnIcon = Gui.Icon("LobbyUI/team/lb_contact_checkbox_down_01.dds", Vector4(0, 0, 0, 0)),
	CheckOffIcon = Gui.Icon("LobbyUI/team/lb_contact_checkbox_normal_01.dds", Vector4(0, 0, 0, 0)),
}

ListItemSkin_TopList_Single = Gui.ListItemSkin
{
	--control skin
	BackgroundImage = Gui.Image("LobbyUI/lb_common_listcontent02_normal_a.dds", Vector4(8, 0, 42, 0)),
	SelfImage = Gui.Image("LobbyUI/GameBalance/lb_common_listcontent01_me.dds", Vector4(8,3,56,3)),
	--list item skin
	HoverImage = Gui.Image("LobbyUI/TopList/lb_rank_list_hover.dds", Vector4(40, 0, 0, 0)),
	SelectedImage = Gui.Image("LobbyUI/TopList/lb_rank_list_down.dds", Vector4(40, 0, 0, 0)),
	DisabledImage = Gui.Image("LobbyUI/lb_common_listcontent02_disabled.dds", Vector4(8, 0, 318, 0)),
}

ListItemSkin_Single_02 = Gui.ListItemSkin
{
	--control skin
	BackgroundImage = Gui.Image("LobbyUI/lb_common_listcontent03_normal_a.dds", Vector4(8, 0, 42, 0)),
	SelfImage = Gui.Image("LobbyUI/GameBalance/lb_room_list_bluebg_me_full.dds", Vector4(4,4,10,4)),
	--list item skin
	HoverImage = Gui.Image("LobbyUI/WarZone/lb_room_list_bluebg_me_full.dds", Vector4(4,4,10,4)),
	SelectedImage = Gui.Image("LobbyUI/WarZone/lb_room_list_bluebg_me_full.dds", Vector4(4,4,10,4)),
	--DisabledImage = Gui.Image("LobbyUI/lb_common_listcontent02_disabled.dds", Vector4(8, 0, 318, 0)),
}


ListItemSkin_Single_Red = Gui.ListItemSkin
{
	--control skin
	BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_room_list_redbg_a.dds", Vector4(8, 2, 2, 2)),
	SelfImage = Gui.Image("LobbyUI/WarZone/lb_room_list_redbg_me.dds", Vector4(10,4,4,4)),
	--list item skin
	HoverImage = Gui.Image("LobbyUI/WarZone/lb_room_list_redbg_hover.dds", Vector4(8, 2, 2, 2)),
	SelectedImage = Gui.Image("LobbyUI/WarZone/lb_room_list_redbg_down.dds", Vector4(8, 2, 2, 2)),
}

ListItemSkin_Single_Black = Gui.ListItemSkin
{
	--control skin
	BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_squad_list_blackbg_a.dds", Vector4(4, 2, 2, 2)),
	SelfImage = Gui.Image("LobbyUI/WarZone/lb_room_list_redbg_me.dds", Vector4(10,4,4,4)),
	--list item skin
	HoverImage = Gui.Image("LobbyUI/WarZone/lb_room_list_redbg_hover.dds", Vector4(8, 2, 2, 2)),
	SelectedImage = Gui.Image("LobbyUI/WarZone/lb_room_list_redbg_down.dds", Vector4(8, 2, 2, 2)),
}


ListItemSkin_Single_Blue = Gui.ListItemSkin
{
	--control skin
	BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_room_list_bluebg_a.dds", Vector4(2, 2, 8, 2)),
	SelfImage = Gui.Image("LobbyUI/WarZone/lb_room_list_bluebg_me.dds", Vector4(4,4,10,4)),
	--list item skin
	HoverImage = Gui.Image("LobbyUI/WarZone/lb_room_list_bluebg_hover.dds", Vector4(2, 2, 8, 2)),
	SelectedImage = Gui.Image("LobbyUI/WarZone/lb_room_list_bluebg_down.dds", Vector4(2, 2, 8, 2)),
}



ListItemSkin_Single_RoomVip = Gui.ListItemSkin
{
	BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_room_list_vipbg_normal_b.dds", Vector4(2, 2, 42, 2)),
	HoverImage = Gui.Image("LobbyUI/WarZone/lb_serverlist2_hover.dds", Vector4(8, 0, 42, 0)),
	SelectedImage = Gui.Image("LobbyUI/WarZone/lb_room_list_vipbg_down.dds", Vector4(2, 2, 42, 2)),
}

ListItemSkin_Double_RoomVip = Gui.ListItemSkin
{
	BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_room_list_vipbg_normal_a.dds", Vector4(2, 2, 42, 2)),
	HoverImage = Gui.Image("LobbyUI/WarZone/lb_serverlist2_hover.dds", Vector4(8, 0, 42, 0)),
	SelectedImage = Gui.Image("LobbyUI/WarZone/lb_room_list_vipbg_down.dds", Vector4(2, 2, 42, 2)),
}

ListItemSkin_Video_a = Gui.ListItemSkin
{
	BackgroundImage = Gui.Image("LobbyUI/WarZone/Video/lb_video_bg_normal_a.dds", Vector4(0, 0, 0, 0)),
	HoverImage = Gui.Image("LobbyUI/WarZone/Video/lb_video_bg_hover.dds", Vector4(8, 0, 42, 0)),
	SelectedImage = Gui.Image("LobbyUI/WarZone/Video/lb_video_bg_down.dds", Vector4(0, 0, 0, 0)),
}

ListItemSkin_Video_b = Gui.ListItemSkin
{
	BackgroundImage = Gui.Image("LobbyUI/WarZone/Video/lb_video_bg_normal_b.dds", Vector4(0, 0, 0, 0)),
	HoverImage = Gui.Image("LobbyUI/WarZone/Video/lb_video_bg_hover.dds", Vector4(8, 0, 42, 0)),
	SelectedImage = Gui.Image("LobbyUI/WarZone/Video/lb_video_bg_down.dds", Vector4(0, 0, 0, 0)),
}

Style "Gui.ListTreeViewWith_VScroll_Video"
{
	Skin = Gui.ScrollableControlSkin
	{
		VSliderNormalImage = Gui.Image("LobbyUI/Friends/lb_chat_scrollbar_slider_normal.dds",  Vector4(0, 9, 0, 9)),
		VSliderHoverImage = Gui.Image("LobbyUI/Friends/lb_chat_scrollbar_slider_hover.dds",  Vector4(0, 9, 0, 9)),
		VSliderDownImage = Gui.Image("LobbyUI/Friends/lb_chat_scrollbar_slider_down.dds",  Vector4(0, 9, 0, 9)),
		VSliderDisabledImage = Gui.Image("LobbyUI/Friends/lb_chat_scrollbar_slider_normal.dds",  Vector4(0, 9, 0, 9)),

		VBarBackgroundImage = Gui.Image("LobbyUI/Friends/lb_chat_scrollbar.dds", Vector4(3, 4, 5, 5)),
		BarCornerImage = nil,
	},

	TreeVisible = false,
	HScrollBarDisplay = "kHide",
	VScrollBarDisplay = "kVisible",
	
	BackgroundColor = ARGB(255, 255, 255, 255),
	TextColor = ARGB(255, 215, 232, 227),
}

ListItemSkin_Single_Vip = Gui.ListItemSkin
{
	--control skin
	BackgroundImage = Gui.Image("LobbyUI/lb_common_listcontent02_vip_a.dds", Vector4(8, 3,50, 3)),
	SelfImage = Gui.Image("LobbyUI/GameBalance/lb_common_listcontent01_me.dds", Vector4(8,3,56,3)),
	--list item skin
	HoverImage =  Gui.Image("LobbyUI/persionalInfo/lb_common_listcontent02_vip_down.dds", Vector4( 7,5,57,5)),
	SelectedImage = Gui.Image("LobbyUI/persionalInfo/lb_common_listcontent02_vip_down.dds", Vector4( 7,5,57,5)),
	DisabledImage = Gui.Image("LobbyUI/lb_common_listcontent02_disabled.dds", Vector4(8, 0, 318, 0)),
}

ListItemSkin_Single_Card01 = Gui.ListItemSkin
{
	--control skin
	BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_common_listcontent02_card01_a.dds", Vector4(8, 3,50, 3)),
	--SelfImage = Gui.Image("LobbyUI/GameBalance/lb_common_listcontent01_me.dds", Vector4(8,3,56,3)),
	--list item skin
	HoverImage = Gui.Image("LobbyUI/Friends/lb_contact_liebiao_hover02.dds", Vector4(8, 3, 50, 3)),
	SelectedImage = Gui.Image("LobbyUI/persionalInfo/lb_common_listcontent02_card01_down.dds", Vector4( 7,5,57,5)),
	--DisabledImage = Gui.Image("LobbyUI/lb_common_listcontent02_disabled.dds", Vector4(8, 0, 318, 0)),
}

ListItemSkin_Double_Card01 = Gui.ListItemSkin
{
	--control skin
	BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_common_listcontent02_card01_b.dds", Vector4(8, 3, 50, 3)),
	SelfImage = Gui.Image("LobbyUI/GameBalance/lb_common_listcontent01_me.dds", Vector4(8,3,56,3)),
	HoverImage = Gui.Image("LobbyUI/lb_common_listcontent02_hover.dds", Vector4(8, 3, 50, 3)),
	SelectedImage = Gui.Image("LobbyUI/persionalInfo/lb_common_listcontent02_card01_down.dds", Vector4( 7,5,57,5)),
	DisabledImage = Gui.Image("LobbyUI/lb_common_listcontent02_disabled.dds", Vector4(8, 0, 318, 0)),
}

ListItemSkin_Single_Card02 = Gui.ListItemSkin
{
	--control skin
	BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_common_listcontent02_card02_a.dds", Vector4(8, 3,50, 3)),
	--SelfImage = Gui.Image("LobbyUI/GameBalance/lb_common_listcontent01_me.dds", Vector4(8,3,56,3)),
	--list item skin
	HoverImage = Gui.Image("LobbyUI/Friends/lb_contact_liebiao_hover02.dds", Vector4(8, 3, 50, 3)),
	SelectedImage = Gui.Image("LobbyUI/persionalInfo/lb_common_listcontent02_card02_down.dds", Vector4( 7,5,57,5)),
	--DisabledImage = Gui.Image("LobbyUI/lb_common_listcontent02_disabled.dds", Vector4(8, 0, 318, 0)),
}

ListItemSkin_Double_Card02 = Gui.ListItemSkin
{
	--control skin
	BackgroundImage = Gui.Image("LobbyUI/persionalInfo/lb_common_listcontent02_card02_b.dds", Vector4(8, 3, 50, 3)),
	SelfImage = Gui.Image("LobbyUI/GameBalance/lb_common_listcontent01_me.dds", Vector4(8,3,56,3)),
	HoverImage = Gui.Image("LobbyUI/lb_common_listcontent02_hover.dds", Vector4(8, 3, 50, 3)),
	SelectedImage = Gui.Image("LobbyUI/persionalInfo/lb_common_listcontent02_card02_down.dds", Vector4( 7,5,57,5)),
	DisabledImage = Gui.Image("LobbyUI/lb_common_listcontent02_disabled.dds", Vector4(8, 0, 318, 0)),
}

ListItemSkin_Single_Card01_Red = Gui.ListItemSkin
{
	--control skin
	BackgroundImage = Gui.Image("LobbyUI/WarZone/Card/lb_common_listcontent02_card01_a.dds", Vector4(8, 3,10, 3)),
	SelfImage = Gui.Image("LobbyUI/WarZone/lb_room_list_redbg_me.dds", Vector4(10,4,4,4)),
	HoverImage = Gui.Image("LobbyUI/WarZone/lb_room_list_redbg_hover.dds", Vector4(8, 2, 2, 2)),
	SelectedImage = Gui.Image("LobbyUI/WarZone/Card/lb_common_listcontent02_card01_down.dds", Vector4(8, 3, 10, 3)),
	DisabledImage = Gui.Image("LobbyUI/lb_common_listcontent02_disabled.dds", Vector4(8, 0, 318, 0)),
}

ListItemSkin_Double_Card01_Red = Gui.ListItemSkin
{
	--control skin
	BackgroundImage = Gui.Image("LobbyUI/WarZone/Card/lb_common_listcontent02_card01_b.dds", Vector4(8, 3,10, 3)),
	SelfImage = Gui.Image("LobbyUI/WarZone/lb_room_list_redbg_me.dds", Vector4(10,4,4,4)),
	HoverImage = Gui.Image("LobbyUI/WarZone/lb_room_list_redbg_hover.dds", Vector4(8, 2, 2, 2)),
	SelectedImage = Gui.Image("LobbyUI/WarZone/Card/lb_common_listcontent02_card01_down.dds", Vector4(8, 3, 10, 3)),
	DisabledImage = Gui.Image("LobbyUI/lb_common_listcontent02_disabled.dds", Vector4(8, 0, 318, 0)),
}


ListItemSkin_Single_Card01_Blue = Gui.ListItemSkin
{
	--control skin
	BackgroundImage = Gui.Image("LobbyUI/WarZone/Card/lb_common_listcontent02_card01_c.dds", Vector4(8, 3,10, 3)),
	SelfImage = Gui.Image("LobbyUI/WarZone/lb_room_list_bluebg_me.dds", Vector4(4,4,10,4)),
	HoverImage = Gui.Image("LobbyUI/WarZone/lb_room_list_bluebg_hover.dds", Vector4(2, 2, 8, 2)),
	SelectedImage = Gui.Image("LobbyUI/WarZone/Card/lb_common_listcontent02_card01_down2.dds", Vector4(8, 3, 10, 3)),
	DisabledImage = Gui.Image("LobbyUI/lb_common_listcontent02_disabled.dds", Vector4(8, 0, 318, 0)),
}

ListItemSkin_Double_Card01_Blue = Gui.ListItemSkin
{
	--control skin
	BackgroundImage = Gui.Image("LobbyUI/WarZone/Card/lb_common_listcontent02_card01_d.dds", Vector4(8, 3,10, 3)),
	SelfImage = Gui.Image("LobbyUI/WarZone/lb_room_list_bluebg_me.dds", Vector4(4,4,10,4)),
	HoverImage = Gui.Image("LobbyUI/WarZone/lb_room_list_bluebg_hover.dds", Vector4(2, 2, 8, 2)),
	SelectedImage = Gui.Image("LobbyUI/WarZone/Card/lb_common_listcontent02_card01_down2.dds", Vector4(8, 3, 10, 3)),
	DisabledImage = Gui.Image("LobbyUI/lb_common_listcontent02_disabled.dds", Vector4(8, 0, 318, 0)),
}



ListItemSkin_Single_Card02_Red = Gui.ListItemSkin
{
	--control skin
	BackgroundImage = Gui.Image("LobbyUI/WarZone/Card/lb_common_listcontent02_card02_a.dds", Vector4(8, 3,10, 3)),
	SelfImage = Gui.Image("LobbyUI/WarZone/lb_room_list_redbg_me.dds", Vector4(10,4,4,4)),
	HoverImage = Gui.Image("LobbyUI/WarZone/lb_room_list_redbg_hover.dds", Vector4(8, 2, 2, 2)),
	SelectedImage = Gui.Image("LobbyUI/WarZone/Card/lb_common_listcontent02_card02_down2.dds", Vector4(8, 3, 10, 3)),
	DisabledImage = Gui.Image("LobbyUI/lb_common_listcontent02_disabled.dds", Vector4(8, 0, 318, 0)),
}

ListItemSkin_Double_Card02_Red = Gui.ListItemSkin
{
	--control skin
	BackgroundImage = Gui.Image("LobbyUI/WarZone/Card/lb_common_listcontent02_card02_b.dds", Vector4(8, 3,10, 3)),
	SelfImage = Gui.Image("LobbyUI/WarZone/lb_room_list_redbg_me.dds", Vector4(10,4,4,4)),
	HoverImage = Gui.Image("LobbyUI/WarZone/lb_room_list_redbg_hover.dds", Vector4(8, 2, 2, 2)),
	SelectedImage = Gui.Image("LobbyUI/WarZone/Card/lb_common_listcontent02_card02_down2.dds", Vector4(8, 3, 10, 3)),
	DisabledImage = Gui.Image("LobbyUI/lb_common_listcontent02_disabled.dds", Vector4(8, 0, 318, 0)),
}


ListItemSkin_Single_Card02_Blue = Gui.ListItemSkin
{
	--control skin
	BackgroundImage = Gui.Image("LobbyUI/WarZone/Card/lb_common_listcontent02_card02_c.dds", Vector4(8, 3,10, 3)),
	SelfImage = Gui.Image("LobbyUI/WarZone/lb_room_list_bluebg_me.dds", Vector4(4,4,10,4)),
	HoverImage = Gui.Image("LobbyUI/WarZone/lb_room_list_bluebg_hover.dds", Vector4(2, 2, 8, 2)),
	SelectedImage = Gui.Image("LobbyUI/WarZone/Card/lb_common_listcontent02_card02_down.dds", Vector4(8, 3, 10, 3)),
	DisabledImage = Gui.Image("LobbyUI/lb_common_listcontent02_disabled.dds", Vector4(8, 0, 318, 0)),
}

ListItemSkin_Double_Card02_Blue = Gui.ListItemSkin
{
	--control skin
	BackgroundImage = Gui.Image("LobbyUI/WarZone/Card/lb_common_listcontent02_card02_d.dds", Vector4(8, 3,10, 3)),
	SelfImage = Gui.Image("LobbyUI/WarZone/lb_room_list_bluebg_me.dds", Vector4(4,4,10,4)),
	HoverImage = Gui.Image("LobbyUI/WarZone/lb_room_list_bluebg_hover.dds", Vector4(2, 2, 8, 2)),
	SelectedImage = Gui.Image("LobbyUI/WarZone/Card/lb_common_listcontent02_card02_down.dds", Vector4(8, 3, 10, 3)),
	DisabledImage = Gui.Image("LobbyUI/lb_common_listcontent02_disabled.dds", Vector4(8, 0, 318, 0)),
}

CardTable = {}
CardType = ""
SingleOrDouble = ""
HoverAndDown = ""

for i = 1, 50 do
	CardTable[i] = {}
	for j = 1, 4 do
		if j == 1 then
			CardType = "r"
			HoverAndDown = "red"
			SingleOrDouble = "single"
		elseif j == 2 then
			CardType = "r"
			HoverAndDown = "red"
			SingleOrDouble = "single"
		elseif j == 3 then
			CardType = "b"
			HoverAndDown = "blue"
			SingleOrDouble = "double"
		elseif j == 4 then
			CardType = "b"
			HoverAndDown = "blue"
			SingleOrDouble = "double"
		end
		CardTable[i][j] = Gui.ListItemSkin
						{
							--control skin
							BackgroundImage = Gui.Image("LobbyUI/WarZone/Card/namecard"..i.."_"..CardType.."_"..SingleOrDouble..".dds", Vector4(8, 3,10, 3)),
							SelfImage = Gui.Image("LobbyUI/WarZone/lb_room_list_"..HoverAndDown.."bg_me.dds", Vector4(10,10,10,10)),
							HoverImage = Gui.Image("LobbyUI/WarZone/lb_room_list_"..HoverAndDown.."bg_hover.dds", Vector4(8, 3, 10, 3)),
							SelectedImage = Gui.Image("LobbyUI/WarZone/Card/namecard"..i.."_down_"..CardType..".dds", Vector4(8, 3, 10, 3)),
						}
	end
end

ListItemSkin_KickPerson = Gui.ListItemSkin
{
	--control skin
	BackgroundImage = nil,
	SelfImage = nil,
	--list item skin
	HoverImage = Gui.Image("InGameUI/kick/ig_tr_xuanren_hover.dds", Vector4(8, 8, 20, 8)),
	SelectedImage = Gui.Image("InGameUI/kick/ig_tr_xuanren_down.dds", Vector4(8, 8, 20, 8)),
	DisabledImage = nil,
}

ListItemSkin_Double = Gui.ListItemSkin
{
	--control skin
	BackgroundImage = Gui.Image("LobbyUI/lb_common_listcontent02_normal_b.dds", Vector4(8, 0, 42, 0)),
	SelfImage = Gui.Image("LobbyUI/GameBalance/lb_common_listcontent01_me.dds", Vector4(8,3,56,3)),
	HoverImage = Gui.Image("LobbyUI/lb_common_listcontent02_hover.dds", Vector4(8, 0, 42, 0)),
	SelectedImage = Gui.Image("LobbyUI/lb_common_listcontent02_down.dds", Vector4(8, 0, 42, 0)),
	DisabledImage = Gui.Image("LobbyUI/lb_common_listcontent02_disabled.dds", Vector4(8, 0, 318, 0)),
}

ListItemSkin_Normal_Double = Gui.ListItemSkin
{
	--control skin
	BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_common_listcontent02_1_normal_b.dds", Vector4(8, 0, 42, 0)),
	SelfImage = Gui.Image("LobbyUI/GameBalance/lb_common_listcontent01_me1.dds", Vector4(8,3,56,3)),
	HoverImage = Gui.Image("LobbyUI/GameBalance/lb_common_listcontent02_1_hover.dds", Vector4(8, 0, 42, 0)),
	SelectedImage = Gui.Image("LobbyUI/GameBalance/lb_common_listcontent02_1_down.dds", Vector4(8, 0, 42, 0)),
	DisabledImage = Gui.Image("LobbyUI/GameBalance/lb_common_listcontent02_1_disabled.dds", Vector4(8, 0, 318, 0)),
}

ListItemSkin_TopList_Double = Gui.ListItemSkin
{
	--control skin
	BackgroundImage = Gui.Image("LobbyUI/lb_common_listcontent02_normal_b.dds", Vector4(8, 0, 42, 0)),
	SelfImage = Gui.Image("LobbyUI/GameBalance/lb_common_listcontent01_me.dds", Vector4(8,3,56,3)),
	HoverImage = Gui.Image("LobbyUI/TopList/lb_rank_list_hover.dds", Vector4(40, 0, 0, 0)),
	SelectedImage = Gui.Image("LobbyUI/TopList/lb_rank_list_down.dds", Vector4(40, 0, 0, 0)),
	DisabledImage = Gui.Image("LobbyUI/lb_common_listcontent02_disabled.dds", Vector4(8, 0, 318, 0)),
}

ListItemSkin_Double_02 = Gui.ListItemSkin
{
	--control skin
	BackgroundImage = Gui.Image("LobbyUI/lb_common_listcontent03_normal_b.dds", Vector4(8, 0, 42, 0)),
	SelfImage = Gui.Image("LobbyUI/GameBalance/lb_common_listcontent01_me.dds", Vector4(8,3,56,3)),
	HoverImage = Gui.Image("LobbyUI/WarZone/lb_room_list_bluebg_me_full.dds", Vector4(4,4,10,4)),
	SelectedImage = Gui.Image("LobbyUI/WarZone/lb_room_list_bluebg_me_full.dds", Vector4(4,4,10,4)),
	DisabledImage = Gui.Image("LobbyUI/lb_common_listcontent02_disabled.dds", Vector4(8, 0, 318, 0)),
}

ListItemSkin_Single_balance = Gui.ListItemSkin
{
	--control skin
	BackgroundImage = Gui.Image("LobbyUI/lb_common_listcontent02_normal_a.dds", Vector4(8, 0, 42, 0)),
	SelfImage = Gui.Image("LobbyUI/GameBalance/lb_common_listcontent01_me_balance.dds", Vector4(8,3,56,3)),
	HoverImage = Gui.Image("LobbyUI/GameBalance/lb_summary_listcontent02_hover.dds", Vector4(8, 0, 48, 0)),
	SelectedImage = Gui.Image("LobbyUI/GameBalance/lb_summary_listcontent02_down.dds", Vector4(8, 0, 48, 0)),
	DisabledImage = Gui.Image("LobbyUI/lb_common_listcontent02_disabled.dds", Vector4(8, 0, 318, 0)),
}

ListItemSkin_Single_Normal_balance = Gui.ListItemSkin
{
	--control skin
	BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_common_listcontent02_1_normal_a.dds", Vector4(8, 0, 42, 0)),
	SelfImage = Gui.Image("LobbyUI/GameBalance/lb_common_listcontent01_me1_balance.dds", Vector4(8,3,56,3)),
	HoverImage = Gui.Image("LobbyUI/GameBalance/lb_summary_listcontent02_1_hover.dds", Vector4(8, 0, 48, 0)),
	SelectedImage = Gui.Image("LobbyUI/GameBalance/lb_summary_listcontent02_1_down.dds", Vector4(8, 0, 48, 0)),
	DisabledImage = Gui.Image("LobbyUI/GameBalance/lb_common_listcontent02_1_disabled.dds", Vector4(8, 0, 318, 0)),
}

ListItemSkin_Double_balance = Gui.ListItemSkin
{
	--control skin
	BackgroundImage = Gui.Image("LobbyUI/lb_common_listcontent02_normal_b.dds", Vector4(8, 0, 42, 0)),
	SelfImage = Gui.Image("LobbyUI/GameBalance/lb_common_listcontent01_me_balance.dds", Vector4(8,3,56,3)),
	HoverImage = Gui.Image("LobbyUI/GameBalance/lb_summary_listcontent02_hover.dds", Vector4(8, 0, 48, 0)),
	SelectedImage = Gui.Image("LobbyUI/GameBalance/lb_summary_listcontent02_down.dds", Vector4(8, 0, 48, 0)),
	DisabledImage = Gui.Image("LobbyUI/lb_common_listcontent02_disabled.dds", Vector4(8, 0, 318, 0)),
}

ListItemSkin_Double_Normal_balance = Gui.ListItemSkin
{
	--control skin
	BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_common_listcontent02_1_normal_b.dds", Vector4(8, 0, 42, 0)),
	SelfImage = Gui.Image("LobbyUI/GameBalance/lb_common_listcontent01_me1_balance.dds", Vector4(8,3,56,3)),
	HoverImage = Gui.Image("LobbyUI/GameBalance/lb_summary_listcontent02_1_hover.dds", Vector4(8, 0, 48, 0)),
	SelectedImage = Gui.Image("LobbyUI/GameBalance/lb_summary_listcontent02_1_down.dds", Vector4(8, 0, 48, 0)),
	DisabledImage = Gui.Image("LobbyUI/GameBalance/lb_common_listcontent02_1_disabled.dds", Vector4(8, 0, 318, 0)),
}

ListItemSkin_Double_Red = Gui.ListItemSkin
{
	--control skin
	BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_room_list_redbg_b.dds", Vector4(8, 2, 2, 2)),
	SelfImage = Gui.Image("LobbyUI/WarZone/lb_room_list_redbg_me.dds", Vector4(10,4,4,4)),
	HoverImage = Gui.Image("LobbyUI/WarZone/lb_room_list_redbg_hover.dds", Vector4(8, 2, 2, 2)),
	SelectedImage = Gui.Image("LobbyUI/WarZone/lb_room_list_redbg_down.dds", Vector4(8, 2, 2, 2)),
	DisabledImage = Gui.Image("LobbyUI/lb_common_listcontent02_disabled.dds", Vector4(8, 0, 318, 0)),
}

ListItemSkin_Double_Black = Gui.ListItemSkin
{
	--control skin
	BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_squad_list_blackbg_b.dds", Vector4(4, 2, 2, 2)),
	SelfImage = Gui.Image("LobbyUI/WarZone/lb_room_list_redbg_me.dds", Vector4(10,4,4,4)),
	HoverImage = Gui.Image("LobbyUI/WarZone/lb_room_list_redbg_hover.dds", Vector4(8, 2, 2, 2)),
	SelectedImage = Gui.Image("LobbyUI/WarZone/lb_room_list_redbg_down.dds", Vector4(8, 2, 2, 2)),
	DisabledImage = Gui.Image("LobbyUI/lb_common_listcontent02_disabled.dds", Vector4(8, 0, 318, 0)),
}

ListItemSkin_Double_Blue = Gui.ListItemSkin
{
	--control skin
	BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_room_list_bluebg_b.dds", Vector4(2, 2, 8, 2)),
	SelfImage = Gui.Image("LobbyUI/WarZone/lb_room_list_bluebg_me.dds", Vector4(4,4,10,4)),
	HoverImage = Gui.Image("LobbyUI/WarZone/lb_room_list_bluebg_hover.dds", Vector4(2, 2, 8, 2)),
	SelectedImage = Gui.Image("LobbyUI/WarZone/lb_room_list_bluebg_down.dds", Vector4(2, 2, 8, 2)),
	DisabledImage = Gui.Image("LobbyUI/lb_common_listcontent02_disabled.dds", Vector4(8, 0, 318, 0)),
}

ListItemSkin_Double_Vip = Gui.ListItemSkin
{
	--control skin
	BackgroundImage = Gui.Image("LobbyUI/lb_common_listcontent02_vip_b.dds", Vector4(8, 3, 50, 3)),
	SelfImage = Gui.Image("LobbyUI/GameBalance/lb_common_listcontent01_me.dds", Vector4(8,3,56,3)),
	HoverImage =  Gui.Image("LobbyUI/persionalInfo/lb_common_listcontent02_vip_down.dds", Vector4( 7,5,57,5)),
	SelectedImage = Gui.Image("LobbyUI/persionalInfo/lb_common_listcontent02_vip_down.dds", Vector4( 7,5,57,5)),
	DisabledImage = Gui.Image("LobbyUI/lb_common_listcontent02_disabled.dds", Vector4(8, 0, 318, 0)),
}

ListItemSkin_Double_Vip_Balance = Gui.ListItemSkin
{
	--control skin
	BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_summary_listcontent02_vip_b.dds", Vector4(8, 3, 260, 3)),
	SelfImage = Gui.Image("LobbyUI/GameBalance/lb_common_listcontent01_me_balance.dds", Vector4(8,3,56,3)),
	HoverImage =  Gui.Image("LobbyUI/persionalInfo/lb_common_listcontent02_vip_down.dds", Vector4( 7,5,57,5)),
	SelectedImage = Gui.Image("LobbyUI/persionalInfo/lb_common_listcontent02_vip_down.dds", Vector4( 7,5,57,5)),
	DisabledImage = Gui.Image("LobbyUI/lb_common_listcontent02_disabled.dds", Vector4(8, 0, 318, 0)),
}

ListItemSkin_Single_Vip_Balance = Gui.ListItemSkin
{
	--control skin
	BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_summary_listcontent02_vip_a_balance.dds", Vector4(8, 3,260, 3)),
	SelfImage = Gui.Image("LobbyUI/GameBalance/lb_common_listcontent01_me_balance.dds", Vector4(8,3,56,3)),--list item skin
	HoverImage =  Gui.Image("LobbyUI/persionalInfo/lb_common_listcontent02_vip_down.dds", Vector4( 7,5,57,5)),
	SelectedImage = Gui.Image("LobbyUI/persionalInfo/lb_common_listcontent02_vip_down.dds", Vector4( 7,5,57,5)),
	DisabledImage = Gui.Image("LobbyUI/lb_common_listcontent02_disabled.dds", Vector4(8, 0, 318, 0)),
}


ListItemSkin_Double_Vip_Red = Gui.ListItemSkin
{
	--control skin
	BackgroundImage = Gui.Image("LobbyUI/WarZone/Card/lb_common_listcontent02_vip_b.dds", Vector4(8, 3, 10, 3)),
	SelfImage = Gui.Image("LobbyUI/WarZone/lb_room_list_redbg_me.dds", Vector4(10,4,4,4)),
	HoverImage = Gui.Image("LobbyUI/WarZone/lb_room_list_redbg_hover.dds", Vector4(8, 2, 2, 2)),
	SelectedImage = Gui.Image("LobbyUI/WarZone/Card/lb_common_listcontent02_vip_down.dds", Vector4(8, 3, 10, 3)),
	DisabledImage = Gui.Image("LobbyUI/lb_common_listcontent02_disabled.dds", Vector4(8, 0, 318, 0)),
}

ListItemSkin_Single_Vip_Red = Gui.ListItemSkin
{
	--control skin
	BackgroundImage = Gui.Image("LobbyUI/WarZone/Card/lb_common_listcontent02_vip_a.dds", Vector4(8, 3, 10, 3)),
	SelfImage = Gui.Image("LobbyUI/WarZone/lb_room_list_redbg_me.dds", Vector4(10,4,4,4)),
	HoverImage = Gui.Image("LobbyUI/WarZone/lb_room_list_redbg_hover.dds", Vector4(8, 2, 2, 2)),
	SelectedImage = Gui.Image("LobbyUI/WarZone/Card/lb_common_listcontent02_vip_down.dds", Vector4(8, 3, 10, 3)),
	DisabledImage = Gui.Image("LobbyUI/lb_common_listcontent02_disabled.dds", Vector4(8, 0, 318, 0)),
}

ListItemSkin_Double_Vip_Blue = Gui.ListItemSkin
{
	--control skin
	BackgroundImage = Gui.Image("LobbyUI/WarZone/Card/lb_common_listcontent02_vip_d.dds", Vector4(8, 3, 10, 3)),
	SelfImage = Gui.Image("LobbyUI/WarZone/lb_room_list_bluebg_me.dds", Vector4(4,4,10,4)),
	HoverImage = Gui.Image("LobbyUI/WarZone/lb_room_list_bluebg_hover.dds", Vector4(2, 2, 8, 2)),
	SelectedImage = Gui.Image("LobbyUI/WarZone/Card/lb_common_listcontent02_vip_down2.dds", Vector4(8, 3, 10, 3)),
	DisabledImage = Gui.Image("LobbyUI/lb_common_listcontent02_disabled.dds", Vector4(8, 0, 318, 0)),
}

ListItemSkin_Single_Vip_Blue = Gui.ListItemSkin
{
	--control skin
	BackgroundImage = Gui.Image("LobbyUI/WarZone/Card/lb_common_listcontent02_vip_c.dds", Vector4(8, 3, 10, 3)),
	SelfImage = Gui.Image("LobbyUI/WarZone/lb_room_list_bluebg_me.dds", Vector4(4,4,10,4)),
	HoverImage = Gui.Image("LobbyUI/WarZone/lb_room_list_bluebg_hover.dds", Vector4(2, 2, 8, 2)),
	SelectedImage = Gui.Image("LobbyUI/WarZone/Card/lb_common_listcontent02_vip_down2.dds", Vector4(8, 3, 10, 3)),
	DisabledImage = Gui.Image("LobbyUI/lb_common_listcontent02_disabled.dds", Vector4(8, 0, 318, 0)),
}


ListItemSkin_SingleWitchCheck = Gui.ListItemSkin
{
	--control skin
	BackgroundImage = Gui.Image("LobbyUI/lb_common_listcontent02_normal_a.tga", Vector4(8, 3, 50, 3)),
	SelfImage = Gui.Image("LobbyUI/GameBalance/lb_common_listcontent01_me_balance.dds", Vector4(8,3,56,3)),
	--list item skin
	HoverImage = Gui.Image("LobbyUI/lb_common_listcontent02_hover.dds", Vector4(8, 3, 50, 3)),
	SelectedImage = Gui.Image("LobbyUI/lb_common_listcontent02_down.dds", Vector4( 7,5,57,5)),
	DisabledImage = Gui.Image("LobbyUI/lb_common_listcontent02_disabled.dds", Vector4(8, 0, 318, 0)),
	CheckOnIcon = Gui.Icon("LobbyUI/mail/lb_contact_checkbox_down.dds", Vector4(0, 0, 0, 0)),
	CheckOffIcon = Gui.Icon("LobbyUI/mail/lb_contact_checkbox_normal.dds", Vector4(0, 0, 0, 0)),
}
	
ListItemSkin_DoubleWitchCheck = Gui.ListItemSkin
{
	--control skin
	BackgroundImage = Gui.Image("LobbyUI/lb_common_listcontent02_normal_b.tga", Vector4(8, 3, 50, 3)),
	SelfImage = Gui.Image("LobbyUI/GameBalance/lb_common_listcontent01_me_balance.dds", Vector4(8,3,56,3)),
	HoverImage = Gui.Image("LobbyUI/lb_common_listcontent02_hover.dds", Vector4(8, 3, 50, 3)),
	SelectedImage = Gui.Image("LobbyUI/lb_common_listcontent02_down.dds", Vector4( 7,5,57,5)),
	DisabledImage = Gui.Image("LobbyUI/lb_common_listcontent02_disabled.dds", Vector4(8, 0, 318, 0)),
	CheckOnIcon = Gui.Icon("DefaultSkin/checkbox/lb_shop_checkbox_content.dds", Vector4(0, 0, 0, 0)),
	CheckOffIcon = Gui.Icon("DefaultSkin/checkbox/lb_shop_checkbox_bg.dds", Vector4(0, 0, 0, 0)),
}

ListItemSkin_MailSingleWitchCheck = Gui.ListItemSkin
{
	BackgroundImage = Gui.Image("LobbyUI/mail/lb_mail_R_bg2_a.dds", Vector4(51, 0, 0, 0)),
	SelfImage = Gui.Image("LobbyUI/mail/lb_mail_R_bg2_a.dds", Vector4(51, 0, 0, 0)),
	
	HoverImage = Gui.Image("LobbyUI/mail/lb_mail_R_bg2_hover.dds", Vector4(51, 0, 0, 0)),
	SelectedImage = Gui.Image("LobbyUI/mail/lb_mail_R_bg2_down.dds", Vector4(51, 0, 0, 0)),
	DisabledImage = Gui.Image("LobbyUI/mail/lb_mail_R_bg2_a.dds", Vector4(51, 0, 0, 0)),
	CheckOnIcon = Gui.Icon("LobbyUI/mail/lb_contact_checkbox_down.dds", Vector4(0, 0, 0, 0)),
	CheckOffIcon = Gui.Icon("LobbyUI/mail/lb_contact_checkbox_normal.dds", Vector4(0, 0, 0, 0)),
}	

ListItemSkin_MailDoubleWitchCheck = Gui.ListItemSkin
{
	BackgroundImage = Gui.Image("LobbyUI/mail/lb_mail_R_bg2_b.dds", Vector4(51, 0, 0, 0)),
	SelfImage = Gui.Image("LobbyUI/mail/lb_mail_R_bg2_b.dds", Vector4(51, 0, 0, 0)),
	
	HoverImage = Gui.Image("LobbyUI/mail/lb_mail_R_bg2_hover.dds", Vector4(51, 0, 0, 0)),
	SelectedImage = Gui.Image("LobbyUI/mail/lb_mail_R_bg2_down.dds", Vector4(51, 0, 0, 0)),
	DisabledImage = Gui.Image("LobbyUI/mail/lb_mail_R_bg2_b.dds", Vector4(51, 0, 0, 0)),
	CheckOnIcon = Gui.Icon("LobbyUI/mail/lb_contact_checkbox_down.dds", Vector4(0, 0, 0, 0)),
	CheckOffIcon = Gui.Icon("LobbyUI/mail/lb_contact_checkbox_normal.dds", Vector4(0, 0, 0, 0)),
}

ListItemSkin_MissionSingle = Gui.ListItemSkin
{
	BackgroundImage = Gui.Image("LobbyUI/Mission/lb_re_listcontent02_a.dds", Vector4(0, 0, 60, 0)),
	SelfImage = Gui.Image("LobbyUI/GameBalance/lb_common_listcontent01_me.dds", Vector4(8, 3, 56, 3)),
	
	HoverImage = Gui.Image("LobbyUI/Mission/lb_task_list_hover.dds", Vector4(14, 0, 200, 0)),
	SelectedImage = Gui.Image("LobbyUI/Mission/lb_task_list_down.dds", Vector4(14, 0, 200, 0)),
	DisabledImage = Gui.Image("LobbyUI/lb_common_listcontent02_disabled.dds", Vector4(8, 0, 318, 0)),

}	

ListItemSkin_MissionDouble = Gui.ListItemSkin
{
	BackgroundImage = Gui.Image("LobbyUI/Mission/lb_re_listcontent01_b.dds", Vector4(0, 0, 60, 0)),
	SelfImage = Gui.Image("LobbyUI/GameBalance/lb_common_listcontent01_me.dds", Vector4(8,3,56,3)),
	HoverImage = Gui.Image("LobbyUI/Mission/lb_task_list_hover.dds", Vector4(14, 0, 200, 0)),
	SelectedImage = Gui.Image("LobbyUI/Mission/lb_task_list_down.dds", Vector4(14, 0, 200, 0)),
	DisabledImage = Gui.Image("LobbyUI/lb_common_listcontent02_disabled.dds", Vector4(8, 0, 318, 0)),
	
}

ListItemSkin_SingleWitchCheck_Friend = Gui.ListItemSkin
{
	--control skin
	BackgroundImage = Gui.Image("LobbyUI/lb_common_listcontent02_normal_a.dds", Vector4(12, 3, 50, 3)),
	SelfImage = Gui.Image("LobbyUI/GameBalance/lb_common_listcontent01_me.dds", Vector4(8,3,56,3)),
	--list item skin
	HoverImage = Gui.Image("LobbyUI/Friends/lb_contact_liebiao_hover.dds", Vector4(8, 3, 50, 3)),
	SelectedImage = Gui.Image("LobbyUI/Friends/lb_contact_liebiao_down.dds", Vector4(8,3,56,3)),
	DisabledImage = Gui.Image("LobbyUI/lb_common_listcontent02_disabled.dds", Vector4(8, 0, 318, 0)),
	CheckOnIcon = Gui.Icon("LobbyUI/mail/lb_contact_checkbox_down.dds", Vector4(0, 0, 0, 0)),
	CheckOffIcon = Gui.Icon("LobbyUI/mail/lb_contact_checkbox_normal.dds", Vector4(0, 0, 0, 0)),
}	
	
ListItemSkin_TeamWitchCheck = Gui.ListItemSkin
{
	--control skin
	--BackgroundImage = Gui.Image("LobbyUI/lb_common_listcontent02_normal_a.tga", Vector4(8, 3, 50, 3)),
	--SelfImage = Gui.Image("LobbyUI/GameBalance/lb_common_listcontent01_me.dds", Vector4(8,3,56,3)),
	--list item skin
	--HoverImage = Gui.Image("LobbyUI/lb_common_listcontent02_hover.dds", Vector4(8, 3, 50, 3)),
	--SelectedImage = Gui.Image("LobbyUI/lb_common_listcontent02_down.dds", Vector4( 7,5,57,5)),
	--DisabledImage = Gui.Image("LobbyUI/lb_common_listcontent02_disabled.dds", Vector4(8, 0, 318, 0)),
	CheckOnIcon = Gui.Icon("LobbyUI/team/lb_contact_checkbox_down.dds", Vector4(0, 0, 0, 0)),
	CheckOffIcon = Gui.Icon("LobbyUI/team/lb_contact_checkbox_normal.dds", Vector4(0, 0, 0, 0)),
}

ListItemSkin_Single_Inroom = Gui.ListItemSkin
{
	--control skin
	BackgroundImage = Gui.Image("LobbyUI/lb_common_listcontent02_normal_a.tga", Vector4(8, 3, 50, 3)),
	
	--list item skin
	HoverImage = Gui.Image("LobbyUI/lb_common_listcontent02_hover.dds", Vector4(8, 3, 50, 3)),
	SelectedImage = Gui.Image("LobbyUI/GameBalance/lb_common_listcontent01_me.dds", Vector4(8,3,56,3)),
	DisabledImage = Gui.Image("LobbyUI/lb_common_listcontent02_disabled.dds", Vector4(8, 0, 318, 0)),
	
}

ListItemSkin_Friends = Gui.ListItemSkin
{
	--control skin
--	BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_liebiao02_normal.dds", Vector4(8, 3, 50, 3)),
--	SelfImage = Gui.Image("LobbyUI/GameBalance/lb_common_listcontent01_me.dds", Vector4(8,3,56,3)),
	--list item skin
	HoverImage = Gui.Image("LobbyUI/Friends/lb_contact_liebiao_hover.dds", Vector4(8, 3, 46, 3)),
	SelectedImage = Gui.Image("LobbyUI/Friends/lb_contact_liebiao_down.dds", Vector4(8,3,54,3)),
--	DisabledImage = Gui.Image("", Vector4(0, 0, 0, 0)),
}

ListItemSkin_Friends_Group = Gui.ListItemSkin
{
	--control skin
	BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_liebiao02_normal.dds", Vector4(8, 3, 20, 3)),
--	SelfImage = Gui.Image("LobbyUI/GameBalance/lb_common_listcontent01_me.dds", Vector4(8,3,56,3)),
	--list item skin
	HoverImage = Gui.Image("LobbyUI/Friends/lb_contact_liebiao_hover.dds", Vector4(8, 3, 50, 3)),
	SelectedImage = Gui.Image("LobbyUI/Friends/lb_contact_liebiao_down.dds", Vector4(8,3,56,3)),
--	DisabledImage = Gui.Image("", Vector4(0, 0, 0, 0)),
}

Style "Gui.ListTreeViewWith_Nothing"
{	
	ItemSkin = ListItemSkin_SingleWitchCheck,

	TreeVisible = false,
	HeaderVisible = false,
	HScrollBarDisplay = "kHide",
	VScrollBarDisplay = "kHide",
	
	BackgroundColor = ARGB(0, 255, 255, 255),
	--TextColor = ARGB(255, 255, 255, 255),
}


Style "Gui.ListTreeViewWith_match_VScroll"
{
	Skin = Gui.ScrollableControlSkin
	{
		--Control skin
		--BackgroundImage = Gui.Image("LobbyUI/lb_common_scrollbar01_bg.dds", Vector4(0, 0, 0, 0)),
		
		--ScrollableControl skin
		UpButtonNormalImage = Gui.Image("DefaultSkin/ScrollableControlNew/lb_common_crollbar01_t_normal.tga", Vector4(0, 0, 0, 0)),
		UpButtonHoverImage = Gui.Image("DefaultSkin/ScrollableControlNew/lb_common_crollbar01_t_hover.tga", Vector4(0, 0, 0, 0)),
		UpButtonDownImage = Gui.Image("DefaultSkin/ScrollableControlNew/lb_common_crollbar01_t_down.tga", Vector4(0, 0, 0, 0)),
		UpButtonDisabledImage = Gui.Image("DefaultSkin/ScrollableControlNew/lb_common_crollbar01_t_disabled.tga", Vector4(0, 0, 0, 0)),

		DownButtonNormalImage = Gui.Image("DefaultSkin/ScrollableControlNew/lb_common_crollbar01_b_normal.tga", Vector4(0, 0, 0, 0)),
		DownButtonHoverImage = Gui.Image("DefaultSkin/ScrollableControlNew/lb_common_crollbar01_b_hover.tga", Vector4(0, 0, 0, 0)),
		DownButtonDownImage = Gui.Image("DefaultSkin/ScrollableControlNew/lb_common_crollbar01_b_down.tga", Vector4(0, 0, 0, 0)),
		DownButtonDisabledImage = Gui.Image("DefaultSkin/ScrollableControlNew/lb_common_crollbar01_b_disabled.tga", Vector4(0, 0, 0, 0)),

		VSliderNormalImage = Gui.Image("DefaultSkin/ScrollableControlNew/lb_common_scrollbar01_slider_normal.tga", Vector4(0, 14, 0, 14)),
		VSliderHoverImage = Gui.Image("DefaultSkin/ScrollableControlNew/lb_common_scrollbar01_slider_hover.tga", Vector4(0, 14, 0, 14)),
		VSliderDownImage = Gui.Image("DefaultSkin/ScrollableControlNew/lb_common_scrollbar01_slider_down.tga", Vector4(0, 14, 0, 14)),
		VSliderDisabledImage = Gui.Image("DefaultSkin/ScrollableControlNew/lb_common_scrollbar01_slider_normal.tga", Vector4(0, 14, 0, 14)),

		VBarBackgroundImage = Gui.Image("DefaultSkin/ScrollableControlNew/lb_common_scrollbar01_bg.tga", Vector4(0, 45, 0, 45)),
		VBarDisabledBackgroundImage = Gui.Image("DefaultSkin/ScrollableControlNew/lb_common_scrollbar01_bg.tga", Vector4(0, 45, 0, 45)),
		BarCornerImage = nil,
	},
	
	ItemSkin = ListItemSkin_SingleWitchCheck,

	HeaderSkin = Gui.HeaderSkin
	{
		--control skin
	
		--list item skin
		NormalImage = nil,
		HoverImage = nil,
		DownImage = nil,
		--DisabledImage = nil,
		SortNormalImage = nil,
		SortReverseImage = nil,	
	},

	HScrollBarDisplay = "kHide",
	VScrollBarDisplay = "kVisible",
	
	BackgroundColor = ARGB(255, 255, 255, 255),
	TextColor = ARGB(255, 215, 232, 227),
	FontSize = 20
}


Style "Gui.ListTreeViewWith_VScroll"
{
	Skin = Gui.ScrollableControlSkin
	{
		--Control skin
		--BackgroundImage = Gui.Image("LobbyUI/lb_common_scrollbar01_bg.dds", Vector4(0, 0, 0, 0)),
		
		--ScrollableControl skin
		UpButtonNormalImage = Gui.Image("DefaultSkin/ScrollableControlNew/lb_common_crollbar01_t_normal.tga", Vector4(0, 0, 0, 0)),
		UpButtonHoverImage = Gui.Image("DefaultSkin/ScrollableControlNew/lb_common_crollbar01_t_hover.tga", Vector4(0, 0, 0, 0)),
		UpButtonDownImage = Gui.Image("DefaultSkin/ScrollableControlNew/lb_common_crollbar01_t_down.tga", Vector4(0, 0, 0, 0)),
		UpButtonDisabledImage = Gui.Image("DefaultSkin/ScrollableControlNew/lb_common_crollbar01_t_disabled.tga", Vector4(0, 0, 0, 0)),

		DownButtonNormalImage = Gui.Image("DefaultSkin/ScrollableControlNew/lb_common_crollbar01_b_normal.tga", Vector4(0, 0, 0, 0)),
		DownButtonHoverImage = Gui.Image("DefaultSkin/ScrollableControlNew/lb_common_crollbar01_b_hover.tga", Vector4(0, 0, 0, 0)),
		DownButtonDownImage = Gui.Image("DefaultSkin/ScrollableControlNew/lb_common_crollbar01_b_down.tga", Vector4(0, 0, 0, 0)),
		DownButtonDisabledImage = Gui.Image("DefaultSkin/ScrollableControlNew/lb_common_crollbar01_b_disabled.tga", Vector4(0, 0, 0, 0)),

		VSliderNormalImage = Gui.Image("DefaultSkin/ScrollableControlNew/lb_common_scrollbar01_slider_normal.tga", Vector4(0, 14, 0, 14)),
		VSliderHoverImage = Gui.Image("DefaultSkin/ScrollableControlNew/lb_common_scrollbar01_slider_hover.tga", Vector4(0, 14, 0, 14)),
		VSliderDownImage = Gui.Image("DefaultSkin/ScrollableControlNew/lb_common_scrollbar01_slider_down.tga", Vector4(0, 14, 0, 14)),
		VSliderDisabledImage = Gui.Image("DefaultSkin/ScrollableControlNew/lb_common_scrollbar01_slider_normal.tga", Vector4(0, 14, 0, 14)),

		VBarBackgroundImage = Gui.Image("DefaultSkin/ScrollableControlNew/lb_common_scrollbar01_bg.tga", Vector4(0, 45, 0, 45)),
		VBarDisabledBackgroundImage = Gui.Image("DefaultSkin/ScrollableControlNew/lb_common_scrollbar01_bg.tga", Vector4(0, 45, 0, 45)),
		BarCornerImage = nil,
	},
	
	ItemSkin = ListItemSkin_SingleWitchCheck,

	HeaderSkin = Gui.HeaderSkin
	{
		--control skin
	
		--list item skin
		NormalImage = nil,
		HoverImage = nil,
		DownImage = nil,
		--DisabledImage = nil,
		SortNormalImage = nil,
		SortReverseImage = nil,	
	},

	HScrollBarDisplay = "kHide",
	VScrollBarDisplay = "kVisible",
	
	BackgroundColor = ARGB(255, 255, 255, 255),
	TextColor = ARGB(255, 215, 232, 227),
}

Style "Gui.Team_ListTreeViewWith_VScroll"
{
	Skin = Gui.ScrollableControlSkin
	{
		--Control skin
		--BackgroundImage = Gui.Image("LobbyUI/lb_common_scrollbar01_bg.dds", Vector4(0, 0, 0, 0)),
		
		--ScrollableControl skin
		UpButtonNormalImage = nil,
		UpButtonHoverImage = nil,
		UpButtonDownImage = nil,
		UpButtonDisabledImage = nil,

		DownButtonNormalImage = nil,
		DownButtonHoverImage = nil,
		DownButtonDownImage = nil,
		DownButtonDisabledImage = nil,
		
		VSliderNormalImage = Gui.Image("LobbyUI/team/lb_squad_scrollbar_button_normal.dds", Vector4(5, 5, 5, 5)),
		VSliderHoverImage = Gui.Image("LobbyUI/team/lb_squad_scrollbar_button_hover.dds", Vector4(5, 5, 5, 5)),
		VSliderDownImage = Gui.Image("LobbyUI/team/lb_squad_scrollbar_button_down.dds", Vector4(5, 5, 5, 5)),
		VSliderDisabledImage = Gui.Image("DLobbyUI/team/lb_squad_scrollbar_button_normal.dds", Vector4(5, 5, 5, 5)),

		VBarBackgroundImage = Gui.Image("LobbyUI/lb_common_scrollbar01_bg.dds", Vector4(0, 45, 0, 45)),
		VBarDisabledBackgroundImage = nil,
		BarCornerImage = nil,
	},
	
	ItemSkin = ListItemSkin_TeamWitchCheck,

	HeaderSkin = Gui.HeaderSkin
	{
		--control skin
	
		--list item skin
		NormalImage = nil,
		HoverImage = nil,
		DownImage = nil,
		--DisabledImage = nil,
		SortNormalImage = nil,
		SortReverseImage = nil,	
	},

	TreeVisible = false,
	HScrollBarDisplay = "kHide",
	VScrollBarDisplay = "kAuto",
	
	BackgroundColor = ARGB(255, 255, 255, 255),
	TextColor = ARGB(255, 215, 232, 227),
}

Style "Gui.ListTreeViewWith_VScroll_mail"
{
	Skin = Gui.ScrollableControlSkin
	{
		--Control skin
		--BackgroundImage = Gui.Image("LobbyUI/lb_common_scrollbar01_bg.dds", Vector4(0, 0, 0, 0)),
		
		--ScrollableControl skin
		UpButtonNormalImage = Gui.Image("DefaultSkin/ScrollableControlNew/lb_common_crollbar01_t_normal.tga", Vector4(0, 0, 0, 0)),
		UpButtonHoverImage = Gui.Image("DefaultSkin/ScrollableControlNew/lb_common_crollbar01_t_hover.tga", Vector4(0, 0, 0, 0)),
		UpButtonDownImage = Gui.Image("DefaultSkin/ScrollableControlNew/lb_common_crollbar01_t_down.tga", Vector4(0, 0, 0, 0)),
		UpButtonDisabledImage = Gui.Image("DefaultSkin/ScrollableControlNew/lb_common_crollbar01_t_disabled.tga", Vector4(0, 0, 0, 0)),

		DownButtonNormalImage = Gui.Image("DefaultSkin/ScrollableControlNew/lb_common_crollbar01_b_normal.tga", Vector4(0, 0, 0, 0)),
		DownButtonHoverImage = Gui.Image("DefaultSkin/ScrollableControlNew/lb_common_crollbar01_b_hover.tga", Vector4(0, 0, 0, 0)),
		DownButtonDownImage = Gui.Image("DefaultSkin/ScrollableControlNew/lb_common_crollbar01_b_down.tga", Vector4(0, 0, 0, 0)),
		DownButtonDisabledImage = Gui.Image("DefaultSkin/ScrollableControlNew/lb_common_crollbar01_b_disabled.tga", Vector4(0, 0, 0, 0)),

		VSliderNormalImage = Gui.Image("DefaultSkin/ScrollableControlNew/lb_common_scrollbar01_slider_normal.tga", Vector4(0, 14, 0, 14)),
		VSliderHoverImage = Gui.Image("DefaultSkin/ScrollableControlNew/lb_common_scrollbar01_slider_hover.tga", Vector4(0, 14, 0, 14)),
		VSliderDownImage = Gui.Image("DefaultSkin/ScrollableControlNew/lb_common_scrollbar01_slider_down.tga", Vector4(0, 14, 0, 14)),
		VSliderDisabledImage = Gui.Image("DefaultSkin/ScrollableControlNew/lb_common_scrollbar01_slider_normal.tga", Vector4(0, 14, 0, 14)),

		VBarBackgroundImage = Gui.Image("DefaultSkin/ScrollableControlNew/lb_common_scrollbar01_bg.tga", Vector4(0, 45, 0, 45)),
		VBarDisabledBackgroundImage = Gui.Image("DefaultSkin/ScrollableControlNew/lb_common_scrollbar01_bg.tga", Vector4(0, 45, 0, 45)),BarCornerImage = nil,
	},
	
	ItemSkin = ListItemSkin_MailSingleWitchCheck,

	HeaderSkin = Gui.HeaderSkin
	{
		--control skin
	
		--list item skin
		NormalImage = nil,
		HoverImage = nil,
		DownImage = nil,
		--DisabledImage = nil,
		SortNormalImage = nil,
		SortReverseImage = nil,	
	},

	TreeVisible = false,
	HScrollBarDisplay = "kHide",
	VScrollBarDisplay = "kAuto",
	
	BackgroundColor = ARGB(255, 255, 255, 255),
	TextColor = ARGB(255, 215, 232, 227),
}

Style "Gui.ListTreeViewWith_VScroll_FightTeam"
{
	Skin = Gui.ScrollableControlSkin
	{
	
		UpButtonNormalImage = Gui.Image("LobbyUI/Friends/lb_battlefield_scrollbar_button_01_normal.dds", Vector4(0, 0, 0, 0)),
		UpButtonHoverImage = Gui.Image("LobbyUI/Friends/lb_battlefield_scrollbar_button_01_hover.dds", Vector4(0, 0, 0, 0)),
		UpButtonDownImage = Gui.Image("LobbyUI/Friends/lb_battlefield_scrollbar_button_01_down.dds", Vector4(0, 0, 0, 0)),
		UpButtonDisabledImage = Gui.Image("LobbyUI/Friends/lb_battlefield_scrollbar_button_01_normal.dds", Vector4(0, 0, 0, 0)),

		DownButtonNormalImage = Gui.Image("LobbyUI/Friends/lb_battlefield_scrollbar_button_02_normal.dds", Vector4(0, 0, 0, 0)),
		DownButtonHoverImage = Gui.Image("LobbyUI/Friends/lb_battlefield_scrollbar_button_02_hover.dds", Vector4(0, 0, 0, 0)),
		DownButtonDownImage = Gui.Image("LobbyUI/Friends/lb_battlefield_scrollbar_button_02_down.dds", Vector4(0, 0, 0, 0)),
		DownButtonDisabledImage = Gui.Image("LobbyUI/Friends/lb_battlefield_scrollbar_button_02_normal.dds", Vector4(0, 0, 0, 0)),
		
		VSliderNormalImage = Gui.Image("LobbyUI/Friends/lb_battlefield_scrollbar_button_03_normal.dds", Vector4(3, 4, 5, 5)),
		VSliderHoverImage = Gui.Image("LobbyUI/Friends/lb_battlefield_scrollbar_button_03_hover.dds", Vector4(3, 4, 5, 5)),
		VSliderDownImage = Gui.Image("LobbyUI/Friends/lb_battlefield_scrollbar_button_03_down.dds", Vector4(3, 4, 5, 5)),
		VSliderDisabledImage = Gui.Image("LobbyUI/Friends/lb_battlefield_scrollbar_button_03_normal.dds", Vector4(3, 4, 5, 5)),

		VBarBackgroundImage = Gui.Image("LobbyUI/Friends/lb_battlefield_scrollbar_bg.dds", Vector4(3, 4, 5, 5)),
		BarCornerImage = nil,
	},
	ItemSkin = 
	{
		BackgroundImage = Gui.Image("LobbyUI/lb_common_listcontent02_normal_a.dds", Vector4(0, 0, 0, 0)),
		SelfImage = Gui.Image("LobbyUI/mail/lb_mail_R_bg2_a.dds", Vector4(51, 0, 0, 0)),
		
		HoverImage = Gui.Image("LobbyUI/mail/lb_mail_R_bg2_hover.dds", Vector4(51, 0, 0, 0)),
		SelectedImage = Gui.Image("LobbyUI/mail/lb_mail_R_bg2_down.dds", Vector4(51, 0, 0, 0)),
		DisabledImage = Gui.Image("LobbyUI/mail/lb_mail_R_bg2_a.dds", Vector4(51, 0, 0, 0)),
		CheckOnIcon = Gui.Icon("LobbyUI/mail/lb_contact_checkbox_down.dds", Vector4(0, 0, 0, 0)),
		CheckOffIcon = Gui.Icon("LobbyUI/mail/lb_contact_checkbox_normal.dds", Vector4(0, 0, 0, 0)),
	},
}

Style "Gui.ListTreeViewWith_VScroll_Source_Rank"
{
	Skin = Gui.ScrollableControlSkin
	{
	
		-- UpButtonNormalImage = Gui.Image("LobbyUI/Friends/lb_battlefield_scrollbar_button_01_normal.dds", Vector4(0, 0, 0, 0)),
		-- UpButtonHoverImage = Gui.Image("LobbyUI/Friends/lb_battlefield_scrollbar_button_01_hover.dds", Vector4(0, 0, 0, 0)),
		-- UpButtonDownImage = Gui.Image("LobbyUI/Friends/lb_battlefield_scrollbar_button_01_down.dds", Vector4(0, 0, 0, 0)),
		-- UpButtonDisabledImage = Gui.Image("LobbyUI/Friends/lb_battlefield_scrollbar_button_01_normal.dds", Vector4(0, 0, 0, 0)),

		-- DownButtonNormalImage = Gui.Image("LobbyUI/Friends/lb_battlefield_scrollbar_button_02_normal.dds", Vector4(0, 0, 0, 0)),
		-- DownButtonHoverImage = Gui.Image("LobbyUI/Friends/lb_battlefield_scrollbar_button_02_hover.dds", Vector4(0, 0, 0, 0)),
		-- DownButtonDownImage = Gui.Image("LobbyUI/Friends/lb_battlefield_scrollbar_button_02_down.dds", Vector4(0, 0, 0, 0)),
		-- DownButtonDisabledImage = Gui.Image("LobbyUI/Friends/lb_battlefield_scrollbar_button_02_normal.dds", Vector4(0, 0, 0, 0)),
		
		VSliderNormalImage = Gui.Image("LobbyUI/team/lb_zhong_normal.dds", Vector4(5, 5, 5, 5)),
		VSliderHoverImage = Gui.Image("LobbyUI/team/lb_zhong_hover.dds", Vector4(5, 5, 5, 5)),
		VSliderDownImage = Gui.Image("LobbyUI/team/lb_zhong_down.dds", Vector4(5, 5, 5, 5)),
		VSliderDisabledImage = Gui.Image("LobbyUI/team/lb_zhong_disabled.dds", Vector4(5, 5, 5, 5)),

		VBarBackgroundImage = Gui.Image("LobbyUI/team/lb_squad_you_bg.dds", Vector4(5, 5, 5, 5)),
		VBarDisabledBackgroundImage = Gui.Image("LobbyUI/team/lb_squad_you_bg.dds", Vector4(5, 5, 5, 5)),
		BarCornerImage = nil,
	},
	-- ItemSkin = 
	-- {
		-- BackgroundImage = Gui.Image("LobbyUI/lb_common_listcontent02_normal_a.dds", Vector4(0, 0, 0, 0)),
		-- SelfImage = Gui.Image("LobbyUI/mail/lb_mail_R_bg2_a.dds", Vector4(51, 0, 0, 0)),
		
		-- HoverImage = Gui.Image("LobbyUI/mail/lb_mail_R_bg2_hover.dds", Vector4(51, 0, 0, 0)),
		-- SelectedImage = Gui.Image("LobbyUI/mail/lb_mail_R_bg2_down.dds", Vector4(51, 0, 0, 0)),
		-- DisabledImage = Gui.Image("LobbyUI/mail/lb_mail_R_bg2_a.dds", Vector4(51, 0, 0, 0)),
		-- CheckOnIcon = Gui.Icon("LobbyUI/mail/lb_contact_checkbox_down.dds", Vector4(0, 0, 0, 0)),
		-- CheckOffIcon = Gui.Icon("LobbyUI/mail/lb_contact_checkbox_normal.dds", Vector4(0, 0, 0, 0)),
	-- },
}

Style "Gui.ListTreeViewWith_VScroll_Source"
{
	Skin = Gui.ScrollableControlSkin
	{
	
		UpButtonNormalImage = Gui.Image("LobbyUI/team/lb_shang_normal.dds", Vector4(0, 0, 0, 0)),
		UpButtonHoverImage = Gui.Image("LobbyUI/team/lb_shang_hover.dds", Vector4(0, 0, 0, 0)),
		UpButtonDownImage = Gui.Image("LobbyUI/team/lb_shang_down.dds", Vector4(0, 0, 0, 0)),
		UpButtonDisabledImage = Gui.Image("LobbyUI/team/lb_shang_disabled.dds", Vector4(0, 0, 0, 0)),

		DownButtonNormalImage = Gui.Image("LobbyUI/team/lb_xia_normal.dds", Vector4(0, 0, 0, 0)),
		DownButtonHoverImage = Gui.Image("LobbyUI/team/lb_xia_hover.dds", Vector4(0, 0, 0, 0)),
		DownButtonDownImage = Gui.Image("LobbyUI/team/lb_xia_down.dds", Vector4(0, 0, 0, 0)),
		DownButtonDisabledImage = Gui.Image("LobbyUI/team/lb_xia_disabled.dds", Vector4(0, 0, 0, 0)),
		
		VSliderNormalImage = Gui.Image("LobbyUI/team/lb_zhong_normal.dds", Vector4(5, 5, 5, 5)),
		VSliderHoverImage = Gui.Image("LobbyUI/team/lb_zhong_hover.dds", Vector4(5, 5, 5, 5)),
		VSliderDownImage = Gui.Image("LobbyUI/team/lb_zhong_down.dds", Vector4(5, 5, 5, 5)),
		VSliderDisabledImage = Gui.Image("LobbyUI/team/lb_zhong_disabled.dds", Vector4(5, 5, 5, 5)),

		VBarBackgroundImage = Gui.Image("LobbyUI/team/lb_huadong_bg.dds", Vector4(5, 5, 5, 5)),
		BarCornerImage = nil,
	},

	ItemSkin = Gui.ListItemSkin
	{
		-- BackgroundImage = Gui.Image("LobbyUI/lb_common_listcontent02_normal_a.dds", Vector4(0, 0, 0, 0)),
		-- SelfImage = Gui.Image("LobbyUI/mail/lb_mail_R_bg2_a.dds", Vector4(51, 0, 0, 0)),
		
		-- HoverImage = Gui.Image("LobbyUI/mail/lb_mail_R_bg2_hover.dds", Vector4(51, 0, 0, 0)),
		-- SelectedImage = Gui.Image("LobbyUI/mail/lb_mail_R_bg2_down.dds", Vector4(51, 0, 0, 0)),
		-- DisabledImage = Gui.Image("LobbyUI/mail/lb_mail_R_bg2_a.dds", Vector4(51, 0, 0, 0)),
		CheckOnIcon = Gui.Icon("LobbyUI/team/lb_contact_checkbox_down_01.dds", Vector4(0, 0, 0, 0)),
		CheckOffIcon = Gui.Icon("LobbyUI/team/lb_contact_checkbox_normal_01.dds", Vector4(0, 0, 0, 0)),
	},
}

Style "Gui.ListTreeViewWith_VScroll_Friend"
{
	Skin = Gui.ScrollableControlSkin
	{
		--Control skin
		--BackgroundImage = Gui.Image("LobbyUI/lb_common_scrollbar01_bg.dds", Vector4(0, 0, 0, 0)),
		
		--ScrollableControl skin
		UpButtonNormalImage = Gui.Image("LobbyUI/Friends/lb_contact_scrollbar1_button_u_normal.dds", Vector4(5, 5, 5, 5)),
		UpButtonHoverImage = Gui.Image("LobbyUI/Friends/lb_contact_scrollbar1_button_u_hover.dds", Vector4(5, 5, 5, 5)),
		UpButtonDownImage = Gui.Image("LobbyUI/Friends/lb_contact_scrollbar1_button_u_down.dds", Vector4(5, 5, 5, 5)),
		UpButtonDisabledImage = Gui.Image("LobbyUI/Friends/lb_contact_scrollbar1_button_u_normal.dds", Vector4(5, 5, 5, 5)),

		DownButtonNormalImage = Gui.Image("LobbyUI/Friends/lb_contact_scrollbar1_button_d_normal.dds", Vector4(5, 5, 5, 5)),
		DownButtonHoverImage = Gui.Image("LobbyUI/Friends/lb_contact_scrollbar1_button_d_hover.dds", Vector4(5, 5, 5, 5)),
		DownButtonDownImage = Gui.Image("LobbyUI/Friends/lb_contact_scrollbar1_button_d_down.dds", Vector4(5, 5, 5, 5)),
		DownButtonDisabledImage = Gui.Image("LobbyUI/Friends/lb_contact_scrollbar1_button_d_normal.dds", Vector4(5, 5, 5, 5)),

		VSliderNormalImage = Gui.Image("LobbyUI/Friends/lb_contact_scrollbar1_slider_normal.dds", Vector4(8, 8, 3, 3)),
		VSliderHoverImage = Gui.Image("LobbyUI/Friends/lb_contact_scrollbar1_slider_hover.dds", Vector4(8, 8, 3, 3)),
		VSliderDownImage = Gui.Image("LobbyUI/Friends/lb_contact_scrollbar1_slider_down.dds", Vector4(8, 8, 3, 3)),
		VSliderDisabledImage = Gui.Image("LobbyUI/Friends/lb_contact_scrollbar1_slider_normal.dds", Vector4(8, 8, 3, 3)),

		VBarBackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_scrollbar1_bg.dds", Vector4(7, 7, 7, 7)),
		BarCornerImage = nil,
	},
	
	ItemSkin = ListItemSkin_SingleWitchCheck,

	HeaderSkin = Gui.HeaderSkin
	{
		--control skin
	
		--list item skin
		NormalImage = nil,
		HoverImage = nil,
		DownImage = nil,
		--DisabledImage = nil,
		SortNormalImage = nil,
		SortReverseImage = nil,	
	},

	TreeVisible = false,
	HScrollBarDisplay = "kHide",
	VScrollBarDisplay = "kVisible",
	
	BackgroundColor = ARGB(255, 255, 255, 255),
	TextColor = ARGB(255, 215, 232, 227),
}

Style "Gui.ListTreeViewWith_VScroll_Channl"
{
	Skin = Gui.ScrollableControlSkin
	{
		--Control skin
		--BackgroundImage = Gui.Image("LobbyUI/lb_common_scrollbar01_bg.dds", Vector4(0, 0, 0, 0)),
		
		--ScrollableControl skin

		VSliderNormalImage = Gui.Image("LobbyUI/Friends/lb_chat_scrollbar_slider_normal.dds", Vector4(0, 9, 0, 9)),
		VSliderHoverImage = Gui.Image("LobbyUI/Friends/lb_chat_scrollbar_slider_hover.dds", Vector4(0, 9, 0, 9)),
		VSliderDownImage = Gui.Image("LobbyUI/Friends/lb_chat_scrollbar_slider_down.dds", Vector4(0, 9, 0, 9)),
		VSliderDisabledImage = Gui.Image("LobbyUI/Friends/lb_chat_scrollbar_slider_normal.dds", Vector4(0, 9, 0, 9)),

		VBarBackgroundImage = Gui.Image("LobbyUI/Friends/lb_chat_scrollbar.dds", Vector4(0, 9, 0, 9)),
		BarCornerImage = nil,
	},
	
	ItemSkin = ListItemSkin_SingleWitchCheck_Friend,

	HeaderSkin = Gui.HeaderSkin
	{
		--control skin
	
		--list item skin
		NormalImage = nil,
		HoverImage = nil,
		DownImage = nil,
		--DisabledImage = nil,
		SortNormalImage = nil,
		SortReverseImage = nil,	
	},

	TreeVisible = false,
	HScrollBarDisplay = "kHide",
	VScrollBarDisplay = "kVisible",
	
	BackgroundColor = ARGB(255, 255, 255, 255),
	TextColor = ARGB(255, 215, 232, 227),
}

Style "Gui.ListTreeViewWith_VScroll_Channl_War"
{
	Skin = Gui.ScrollableControlSkin
	{
		--Control skin
		--BackgroundImage = Gui.Image("LobbyUI/lb_common_scrollbar01_bg.dds", Vector4(0, 0, 0, 0)),
		
		--ScrollableControl skin

		VSliderNormalImage = Gui.Image("LobbyUI/Friends/lb_chat_scrollbar_slider_normal.dds",  Vector4(0, 9, 0, 9)),
		VSliderHoverImage = Gui.Image("LobbyUI/Friends/lb_chat_scrollbar_slider_hover.dds",  Vector4(0, 9, 0, 9)),
		VSliderDownImage = Gui.Image("LobbyUI/Friends/lb_chat_scrollbar_slider_down.dds",  Vector4(0, 9, 0, 9)),
		VSliderDisabledImage = Gui.Image("LobbyUI/Friends/lb_chat_scrollbar_slider_normal.dds",  Vector4(0, 9, 0, 9)),

		VBarBackgroundImage = Gui.Image("LobbyUI/WarZone/lb_chat_scrollbarb.dds", Vector4(3, 4, 5, 5)),
		BarCornerImage = nil,
	},
	
	ItemSkin = ListItemSkin_SingleWitchCheck_Friend,

	HeaderSkin = Gui.HeaderSkin
	{
		--control skin
	
		--list item skin
		NormalImage = nil,
		HoverImage = nil,
		DownImage = nil,
		--DisabledImage = nil,
		SortNormalImage = nil,
		SortReverseImage = nil,	
	},

	TreeVisible = false,
	HScrollBarDisplay = "kHide",
	VScrollBarDisplay = "kVisible",
	
	BackgroundColor = ARGB(255, 255, 255, 255),
	TextColor = ARGB(255, 215, 232, 227),
}

Style "Gui.ListTreeViewWith_VScroll_KickPerson"
{
	Skin = Gui.ScrollableControlSkin
	{
		--Control skin
		BackgroundImage = Gui.Image("InGameUI/kick/ig_tr_bg2.dds", Vector4(25, 25, 25, 25)),
		
		--ScrollableControl skin
		UpButtonNormalImage = nil,
		UpButtonHoverImage = nil,
		UpButtonDownImage = nil,
		UpButtonDisabledImage = nil,

		DownButtonNormalImage = nil,
		DownButtonHoverImage = nil,
		DownButtonDownImage = nil,
		DownButtonDisabledImage = nil,

		VSliderNormalImage = Gui.Image("InGameUI/kick/ig_tr_scrollbar_slider_normal.dds", Vector4(0, 5, 0, 5)),
		VSliderHoverImage = Gui.Image("InGameUI/kick/ig_tr_scrollbar_slider_hover.dds", Vector4(0, 5, 0, 5)),
		VSliderDownImage = Gui.Image("InGameUI/kick/ig_tr_scrollbar_slider_down.dds", Vector4(0, 5, 0, 5)),
		VSliderDisabledImage = Gui.Image("InGameUI/kick/ig_tr_scrollbar_slider_normal.dds", Vector4(0, 5, 0, 5)),

		VBarBackgroundImage = Gui.Image("InGameUI/kick/ig_tr_scrollbar.dds", Vector4(0, 5, 0, 5)),
		BarCornerImage = nil,
	},
	
	ItemSkin = ListItemSkin_Single_Inroom,

	HeaderSkin = Gui.HeaderSkin
	{
		--control skin
		--list item skin
		NormalImage = nil,
		HoverImage = nil,
		DownImage = nil,
		DisabledImage = nil,
		SortNormalImage = nil,
		SortReverseImage = nil,	
	},

	TreeVisible = false,
	HScrollBarDisplay = "kHide",
	VScrollBarDisplay = "kVisible",
	
	BackgroundColor = ARGB(255, 255, 255, 255),
	TextColor = ARGB(255, 84, 82, 77),
}

Style "Gui.ListTreeViewWith_VScroll_Inroom"
{
	Skin = Gui.ScrollableControlSkin
	{
		--Control skin
		--BackgroundImage = Gui.Image("LobbyUI/lb_common_scrollbar01_bg.dds", Vector4(0, 0, 0, 0)),
		
		--ScrollableControl skin
		UpButtonNormalImage = Gui.Image("LobbyUI/lb_common_scrollbar01_button_t_normal.dds", Vector4(0, 0, 0, 0)),
		UpButtonHoverImage = Gui.Image("LobbyUI/lb_common_scrollbar01_button_t_hover.dds", Vector4(0, 0, 0, 0)),
		UpButtonDownImage = Gui.Image("LobbyUI/lb_common_scrollbar01_button_t_down.dds", Vector4(0, 0, 0, 0)),
		UpButtonDisabledImage = Gui.Image("LobbyUI/lb_common_scrollbar01_button_t_normal.dds", Vector4(0, 0, 0, 0)),

		DownButtonNormalImage = Gui.Image("LobbyUI/lb_common_scrollbar01_button_b_normal.dds", Vector4(0, 0, 0, 0)),
		DownButtonHoverImage = Gui.Image("LobbyUI/lb_common_scrollbar01_button_b_hover.dds", Vector4(0, 0, 0, 0)),
		DownButtonDownImage = Gui.Image("LobbyUI/lb_common_scrollbar01_button_b_down.dds", Vector4(0, 0, 0, 0)),
		DownButtonDisabledImage = Gui.Image("LobbyUI/lb_common_scrollbar01_button_b_normal.dds", Vector4(0, 0, 0, 0)),

		VSliderNormalImage = Gui.Image("LobbyUI/lb_common_scrollbar01_slider_normal.dds", Vector4(0, 14, 0, 14)),
		VSliderHoverImage = Gui.Image("LobbyUI/lb_common_scrollbar01_slider_hover.dds", Vector4(0, 14, 0, 14)),
		VSliderDownImage = Gui.Image("LobbyUI/lb_common_scrollbar01_slider_down.dds", Vector4(0, 14, 0, 14)),
		VSliderDisabledImage = Gui.Image("LobbyUI/lb_common_scrollbar01_slider_normal.dds", Vector4(0, 14, 0, 14)),

		VBarBackgroundImage = Gui.Image("LobbyUI/lb_common_scrollbar01_bg.dds", Vector4(0, 45, 0, 45)),
		BarCornerImage = nil,
	},
	
	ItemSkin = ListItemSkin_Single_Inroom,

	HeaderSkin = Gui.HeaderSkin
	{
		--control skin
	
		--list item skin
		NormalImage = nil,
		HoverImage = nil,
		DownImage = nil,
		--DisabledImage = nil,
		SortNormalImage = nil,
		SortReverseImage = nil,	
	},

	TreeVisible = false,
	HScrollBarDisplay = "kHide",
	VScrollBarDisplay = "kVisible",
	
	BackgroundColor = ARGB(255, 255, 255, 255),
	TextColor = ARGB(255, 215, 232, 227),
}

local ItemBoxBtn_Skin = Gui.ItemBoxBtnSkin
{
	NeutralNormalImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_wuqi_normal.dds", Vector4(10, 10, 10, 10)),
	NeutralHoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_wuqi_hover.dds", Vector4(10, 10, 10, 10)),
	NeutralSelectedImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_wuqi_down.dds", Vector4(10, 10, 10, 10)),
	NeutralDisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_wuqi_disable.dds", Vector4(10, 10, 10, 10)),
}

local ItemBoxBtn_Skin1 = Gui.ItemBoxBtnSkin
{
	NeutralNormalImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_fuzhuang_normal.dds", Vector4(10, 10, 10, 10)),
	NeutralHoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_fuzhuang_hover.dds", Vector4(10, 10, 10, 10)),
	NeutralSelectedImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_fuzhuang_down.dds", Vector4(10, 10, 10, 10)),
	NeutralDisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_fuzhuang_disable.dds", Vector4(10, 10, 10, 10)),
}

local ItemBoxBtn_Skin2 = Gui.ItemBoxBtnSkin
{
	NeutralNormalImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_peishi_normal.dds", Vector4(10, 10, 10, 10)),
	NeutralHoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_peishi_hover.dds", Vector4(10, 10, 10, 10)),
	NeutralSelectedImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_peishi_down.dds", Vector4(10, 10, 10, 10)),
	NeutralDisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_peishi_disabled.dds", Vector4(10, 10, 10, 10)),
}

local ButtonSkin_Present_Skin = Gui.ItemBoxBtnSkin
{
	NeutralNormalImage = Gui.Image("LobbyUI/ShoppingMall/open_box/lb_gift_biew_bg2.dds", Vector4(0, 0, 0, 0)),
	NeutralHoverImage = Gui.Image("LobbyUI/ShoppingMall/vip_chest/lb_vipgifts_slot_flash.dds", Vector4(0, 0, 0, 0)),
	NeutralSelectedImage = Gui.Image("LobbyUI/ShoppingMall/open_box/lb_gift_select_bg2.dds", Vector4(0, 0, 0, 0)),
	NeutralDisabledImage = Gui.Image("LobbyUI/ShoppingMall/vip_chest/lb_vipgifts_slot_01_disabled.dds", Vector4(0, 0, 0, 0)),
}
-------------------------------------------------------------------------
Style "Gui.ItemBoxBtn_destory"
{
	Empty = false,
	LoadingImage = Gui.AnimatedImage("LobbyUI/loading_ring.tga", 4, 2, 8),
	Type = 1,
	BtnSize = Vector2(20, 20),
	ItemBtnSkin = Skin.ButtonSkin_ItemBoxBtn_destory,
}

Style "Gui.ItemBoxBtn_ib"
{
	Empty = false,
	LoadingImage = Gui.AnimatedImage("LobbyUI/loading_ring.tga", 4, 2, 8),
	Type = 1,

	BtnText =lang:GetText("装备"),
	BtnVisible = false,
	BtnSize = Vector2(54, 24),
	BtnLocation = Vector2(150, 75),
	Padding = Vector4(0, 10, 0, 0),
	Skin = ItemBoxBtn_Skin,
	ItemBtnSkin = Skin.ButtonSkin_ItemBoxBtn,
}

Style "Gui.ItemBoxBtn_ib1"
{
	Empty = false,
	LoadingImage = Gui.AnimatedImage("LobbyUI/loading_ring.tga", 4, 2, 8),
	Type = 1,

	BtnText =lang:GetText("装备"),
	BtnVisible = false,
	BtnSize = Vector2(54, 24),
	BtnLocation = Vector2(150, 75),

	Skin = ItemBoxBtn_Skin1,
	ItemBtnSkin = Skin.ButtonSkin_ItemBoxBtn,
}

Style "Gui.ItemBoxBtn_ib2"
{
	Empty = false,
	LoadingImage = Gui.AnimatedImage("LobbyUI/loading_ring.tga", 4, 2, 8),
	Type = 1,

	BtnText =lang:GetText("装备"),
	BtnVisible = false,
	BtnSize = Vector2(54, 24),
	BtnLocation = Vector2(150, 75),

	Skin = ItemBoxBtn_Skin2,
	ItemBtnSkin = Skin.ButtonSkin_ItemBoxBtn,
}
-------------------------------------------------------------------------
Style "Gui.ItemBoxBtn_Compose"
{
	Empty = false,
	Type = 1,
	Size = Vector2(80, 80),
	CanSelect = false,
	Skin = Gui.ItemBoxBtnSkin
	{
		NeutralNormalImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_slot.dds", Vector4(0, 0, 0, 0)),
		NeutralHoverImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_slot_flash.dds", Vector4(0, 0, 0, 0)),
		NeutralSelectedImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_slot_flash.dds", Vector4(0, 0, 0, 0)),
		NeutralDisabledImage = Gui.Image("LobbyUI/Compose/lb_synthesis_mosaic_ico_01.dds", Vector4(0, 0, 0, 0)),
		NeutralHighlightImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_slot_flash.dds", Vector4(0, 0, 0, 0)),
	}
}

Style "Gui.ItemBoxBtn_Itemlist"
{
	Empty = false,
	Type = 1,
	Skin = Gui.ItemBoxBtnSkin
	{
		NeutralNormalImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_wuqi_normal.dds", Vector4(10, 10, 10, 10)),
		NeutralHoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_wuqi_hover.dds", Vector4(10, 10, 10, 10)),
		NeutralSelectedImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_wuqi_down.dds", Vector4(10, 10, 10, 10)),
		NeutralDisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_bg_disable.dds", Vector4(10, 10, 10, 10)),
	}
}

Style "Gui.ItemBoxBtn_ib_Avatar"
{
	Empty = false,
	LoadingImage = Gui.AnimatedImage("LobbyUI/loading_ring_avatar.tga", 4, 2, 8),
	Type = 1,

	BtnText =lang:GetText("装备"),
	BtnVisible = false,
	BtnSize = Vector2(54, 24),
	BtnLocation = Vector2(150, 75),

	Skin = ItemBoxBtn_Skin,
	ItemBtnSkin = Skin.ButtonSkin_ItemBoxBtn,
}

Style "Gui.ItemBoxBtn_ib_Prop"
{
	Empty = false,
	LoadingImage = Gui.AnimatedImage("LobbyUI/loading_ring_prop.tga", 4, 2, 8),
	Type = 1,

	BtnText =lang:GetText("装备"),
	BtnVisible = false,
	BtnSize = Vector2(54, 24),
	BtnLocation = Vector2(150, 75),

	Skin = ItemBoxBtn_Skin,
	ItemBtnSkin = Skin.ButtonSkin_ItemBoxBtn,
}

Style "Gui.ItemBoxBtn_Present"
{
	Empty = false,
	LoadingImage = Gui.AnimatedImage("LobbyUI/loading_ring.tga", 4, 2, 8),
	Type = 1,
	Skin = ButtonSkin_Present_Skin,
	--ItemBtnSkin = Skin.ButtonSkin_ItemBoxBtn_Present,
}

-----------------------------------------------------------------------------------
-- 默认控件样式
-----------------------------------------------------------------------------------
Style "Gui.Control"
{
	BackgroundColor = ARGB(0,255,255,255),
}

Style "Gui.Button"
{
	Skin = Gui.ButtonSkin
	{
		BackgroundImage = nil,
		HoverImage = nil,
		DownImage = nil,
		DisabledImage = nil,			
	},
	FontSize = 18,	
	TextColor = ARGB(255, 255, 255, 255),
	HighlightTextColor = ARGB(255,0,0,0),
	TextShadowColor = ARGB(64,255,255,255),
	
	BackgroundColor = ARGB(255,255,255,255),
	Size = Vector2(84, 18),
}

Style "Gui.Button_Characters"
{
	BackgroundColor = ARGB(255,255,255,255),
	Size = Vector2(140, 48),
	Visible = false,
	Enable = false,
	FontSize = 20,
	TextAlign = "kAlignRightMiddle",
}

Style "Gui.Button_type"
{
	Size = Vector2(100, 32),
	TextColor = ARGB(255, 217, 209, 201),
	HighlightTextColor = ARGB(255, 217, 209, 201),
	FontSize = 20,
	blinkwheelTimer = 0.6,
	Skin = Gui.ButtonSkin
	{
		BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_normal.dds", Vector4(10, 10, 10, 10)),
		HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_hover.dds", Vector4(10, 10, 10, 10)),
		DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_down.dds", Vector4(10, 10, 10, 10)),
		DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_normal.dds", Vector4(10, 10, 10, 10)),
		TwinkleImage  = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_flash.dds", Vector4(10, 10, 10, 10)),
	},
}

Style "Gui.Button_type_2"
{
	Size = Vector2(90, 36),
	TextColor = ARGB(255, 217, 209, 201),
	HighlightTextColor = ARGB(255, 217, 209, 201),
	FontSize = 17,
	blinkwheelTimer = 0.6,
	Skin = Gui.ButtonSkin
	{
		BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_normal.dds", Vector4(5, 5, 5, 5)),
		HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_hover.dds", Vector4(5, 5, 5, 5)),
		DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_down.dds", Vector4(5, 5, 5, 5)),
		DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_normal.dds", Vector4(5, 5, 5, 5)),
		TwinkleImage  = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_flash.dds", Vector4(5, 5, 5, 5)),
	},
}

Style "Gui.Button_Compose"
{
	Size = Vector2(64, 20),
	Text = lang:GetText("钻孔"),
	TextColor = ARGB(255, 37, 37, 37),
	HighlightTextColor = ARGB(255, 37, 37, 37),
	Padding = Vector4(0, 0, 0, 4),
	FontSize = 12,
	Skin = Gui.ButtonSkin
	{
		BackgroundImage = Gui.Image("LobbyUI/Compose/lb_synthesis_mosaic_button_normal.dds", Vector4(0, 0, 0, 0)),
		HoverImage = Gui.Image("LobbyUI/Compose/lb_synthesis_mosaic_button_hover.dds", Vector4(0, 0, 0, 0)),
		DownImage = Gui.Image("LobbyUI/Compose/lb_synthesis_mosaic_button_down.dds", Vector4(0, 0, 0, 0)),
		DisabledImage = Gui.Image("LobbyUI/Compose/lb_synthesis_mosaic_button_disabled.dds", Vector4(0, 0, 0, 0)),
	},
}

--[[Style "Gui.Button_type"
{
	Size = Vector2(100, ),
}]]

Style "Gui.Buttonsimhei14"
{
	Skin = Gui.ButtonSkin
	{
	},
	FontSize = 14,
	BackgroundColor = ARGB(255,255,255,255),
	Size = Vector2(84, 18),	
}

Style "Gui.CheckBox"
{
	Skin = Gui.CheckBoxSkin
	{
		OnImage = Gui.Image("LobbyUI/team/lb_contact_checkbox_down.dds", Vector4(0, 0, 0, 0)),
		OffImage = Gui.Image("LobbyUI/team/lb_contact_checkbox_normal.dds", Vector4(0, 0, 0, 0)),
		OnDisabledImage = Gui.Image("LobbyUI/team/lb_contact_checkbox_disabled.dds", Vector4(0, 0, 0, 0)),
		OffDisabledImage = Gui.Image("LobbyUI/team/lb_contact_checkbox_disabled.dds", Vector4(0, 0, 0, 0)),
	},
	TextColor = ARGB(255, 255, 255, 255),
	BackgroundColor = ARGB(0, 0, 0, 0),
}


Style "Gui.RadioGroup"
{
	BackgroundColor = ARGB(0,255,255,255),
}

Style "Gui.Textbox"
{
	Skin = Gui.TextboxSkin
	{
	},
	TextPadding = Vector4(6,2,6,2),
	TextColor = ARGB(255, 0, 0, 0),
	SelectionColor = ARGB(255, 255, 255, 255),
	SelectionBgColor = ARGB(255, 80, 80, 80),
	
	Size = Vector2(100, 18),
}

local commonScrTextArea = Gui.ScrollableControlSkin
{
}

local commonScrTextAreaVBar = Gui.ScrollableControlSkin
{
	VSliderNormalImage = Gui.Image("LobbyUI/Friends/lb_chat_scrollbar_slider_normal.dds",  Vector4(0, 9, 0, 9)),
	VSliderHoverImage = Gui.Image("LobbyUI/Friends/lb_chat_scrollbar_slider_hover.dds",  Vector4(0, 9, 0, 9)),
	VSliderDownImage = Gui.Image("LobbyUI/Friends/lb_chat_scrollbar_slider_down.dds",  Vector4(0, 9, 0, 9)),
	VSliderDisabledImage = Gui.Image("LobbyUI/Friends/lb_chat_scrollbar_slider_normal.dds",  Vector4(0, 9, 0, 9)),

	VBarBackgroundImage = Gui.Image("LobbyUI/Friends/lb_chat_scrollbar.dds", Vector4(3, 4, 5, 5)),
	BarCornerImage = nil,
}

local commonScrTextAreaVBarRO = Gui.ScrollableControlSkin
{
}

local commonScrSkinTree = Gui.ScrollableControlSkin
{
		--Control skin
	
		BarCornerImage = nil,
}

Style "Gui.TextArea"
{
	Skin = commonScrTextArea,
	--FontSize = 60,
	TextColor = ARGB(255, 0, 0, 0),
	SelectionColor = ARGB(255, 255, 255, 255),
	SelectionBgColor = ARGB(255, 80, 80, 80),

	TextPadding = Vector4(6,4,6,4),
}

Style "Gui.TextAreaWithVBar"
{
	Skin = commonScrTextAreaVBar,
	--FontSize = 60,
	TextColor = ARGB(255, 0, 0, 0),
	SelectionColor = ARGB(255, 255, 255, 255),
	SelectionBgColor = ARGB(255, 80, 80, 80),

	TextPadding = Vector4(6,4,6,4),
}

Style "Gui.TextAreaWithVBarRO"
{
	Skin = commonScrTextAreaVBarRO,
	--FontSize = 60,
	TextColor = ARGB(255, 0, 0, 0),
	SelectionColor = ARGB(255, 255, 255, 255),
	SelectionBgColor = ARGB(255, 80, 80, 80),

	TextPadding = Vector4(6,4,6,4),
	Readonly = true,
}

Style "Gui.mailComboList"
{
	Skin = Gui.ComboListSkin
	{
		--Control skin
		BackgroundImage = Gui.Image("LobbyUI/mail/lb_mail_xiala_bg.dds", Vector4(10, 10, 10, 10)),
		
		--ComboList skin
		ItemHoverImage = Gui.Image("LobbyUI/mail/lb_mail_xiala_hover.dds", Vector4(10, 10, 10, 10)),
		ItemActiveImage = Gui.Image("LobbyUI/mail/lb_mail_xiala_down.dds", Vector4(10, 10, 10, 10)),
	},
	Pad_x = 10,
	TextColor = ARGB(255, 0, 0, 0),
	HighlightTextColor = ARGB(255, 0, 0, 0),
	ItemAlign = "kAlignCenterMiddle",
	Border = Vector4(8,12,8,12),
}

Style "Gui.ChangeJobComboList"
{
	Skin = Gui.ComboListSkin
	{
		BackgroundImage = Gui.Image("LobbyUI/team/NewFight/ib_common_combobox_bg.dds", Vector4(10, 10, 10, 10)),
		
		VBarBackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_common_scrollbar_02_bg.dds", Vector4(5, 5, 5, 5)),
		
		VSliderNormalImage = Gui.Image("LobbyUI/team/NewFight/lb_common_scrollbar_02_slider.dds", Vector4(5, 5, 5, 5)),
		VSliderHoverImage = Gui.Image("LobbyUI/team/NewFight/lb_common_scrollbar_02_slider.dds", Vector4(5, 5, 5, 5)),
		VSliderDownImage = Gui.Image("LobbyUI/team/NewFight/lb_common_scrollbar_02_slider.dds", Vector4(5, 5, 5, 5)),
		
		ItemHoverImage = Gui.Image("LobbyUI/team/NewFight/ib_common_combobox_bg_02_hover.dds", Vector4(5, 5, 5, 5)),
		ItemActiveImage = Gui.Image("LobbyUI/team/NewFight/ib_common_combobox_bg_02_hover.dds", Vector4(5, 5, 5, 5)),
		ItemIconImage = Gui.Image("LobbyUI/WarZone/lb_battlefield_ico_new.dds", Vector4(0, 0, 0, 0)),
		ItemIconImage1 = Gui.Image("LobbyUI/WarZone/lb_battlefield_ico_recommend.dds", Vector4(10, 10, 10, 10)),
		ItemIconImage2 = Gui.Image("LobbyUI/WarZone/lb_battlefield_ico_reandnew.dds", Vector4(10, 10, 10, 10)),
		ItemDisableImage = Gui.Image("LobbyUI/ib_common_combobox_bg_02_disabled.dds", Vector4(10, 10, 10, 10)),
	},
	Pad_x = 10,
	TextColor = ARGB(255, 216, 216, 216),
	ItemAlign = "kAlignCenterMiddle",
	HighlightTextColor = ARGB(255, 243, 194, 10),
	Border = Vector4(0, 2, 0, 0),
	Default_Width = 8,
	Default_Size = 0.1,
	VScrollBarPos = Vector2(-5, 0),
}
Style "Gui.ChangeLevelUpPriceList"
{
	Skin = Gui.ComboListSkin
	{
		BackgroundImage = Gui.Image("LobbyUI/team/NewFight/ib_common_combobox_bg.dds", Vector4(10, 10, 10, 10)),
		
		VBarBackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_common_scrollbar_02_bg.dds", Vector4(5, 5, 5, 5)),
		
		VSliderNormalImage = Gui.Image("LobbyUI/team/NewFight/lb_common_scrollbar_02_slider.dds", Vector4(5, 5, 5, 5)),
		VSliderHoverImage = Gui.Image("LobbyUI/team/NewFight/lb_common_scrollbar_02_slider.dds", Vector4(5, 5, 5, 5)),
		VSliderDownImage = Gui.Image("LobbyUI/team/NewFight/lb_common_scrollbar_02_slider.dds", Vector4(5, 5, 5, 5)),
		
		ItemHoverImage = Gui.Image("LobbyUI/team/NewFight/ib_common_combobox_bg_02_hover.dds", Vector4(5, 5, 5, 5)),
		ItemActiveImage = Gui.Image("LobbyUI/team/NewFight/ib_common_combobox_bg_02_hover.dds", Vector4(5, 5, 5, 5)),
		ItemIconImage = Gui.Image("LobbyUI/team/lb_icon_res_fc.dds", Vector4(0, 0, 0, 0)),
		ItemIconImage1 = Gui.Image("LobbyUI/team/lb_icon_res_01.dds", Vector4(0, 0, 0, 0)),
		ItemIconImage2 = Gui.Image("LobbyUI/team/lb_icon_res_03.dds", Vector4(0, 0, 0, 0)),
		ItemDisableImage = Gui.Image("LobbyUI/ib_common_combobox_bg_02_disabled.dds", Vector4(10, 10, 10, 10)),
	},
	Pad_x = 10,
	TextColor = ARGB(255, 216, 216, 216),
	ItemAlign = "kAlignLeftMiddle",
	HighlightTextColor = ARGB(255, 243, 194, 10),
	Border = Vector4(0, 2, 0, 0),
	Default_Width = 8,
	Default_Size = 0.1,
	TextPadding = Vector4(53, 0, 0, 0),
	VScrollBarPos = Vector2(-5, 0),
}
Style "Gui.ExChangeList"
{
	Skin = Gui.ComboListSkin
	{
		BackgroundImage = Gui.Image("LobbyUI/team/NewFight/ib_common_combobox_bg.dds", Vector4(10, 10, 10, 10)),
		
		VBarBackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_common_scrollbar_02_bg.dds", Vector4(5, 5, 5, 5)),
		
		VSliderNormalImage = Gui.Image("LobbyUI/team/NewFight/lb_common_scrollbar_02_slider.dds", Vector4(5, 5, 5, 5)),
		VSliderHoverImage = Gui.Image("LobbyUI/team/NewFight/lb_common_scrollbar_02_slider.dds", Vector4(5, 5, 5, 5)),
		VSliderDownImage = Gui.Image("LobbyUI/team/NewFight/lb_common_scrollbar_02_slider.dds", Vector4(5, 5, 5, 5)),
		
		ItemHoverImage = Gui.Image("LobbyUI/team/NewFight/ib_common_combobox_bg_02_hover.dds", Vector4(5, 5, 5, 5)),
		ItemActiveImage = Gui.Image("LobbyUI/team/NewFight/ib_common_combobox_bg_02_hover.dds", Vector4(5, 5, 5, 5)),
		ItemIconImage = Gui.Image("LobbyUI/team/lb_icon_res_fc.dds", Vector4(0, 0, 0, 0)),
		ItemIconImage1 = Gui.Image("LobbyUI/team/lb_icon_res_01.dds", Vector4(0, 0, 0, 0)),
		ItemIconImage2 = Gui.Image("LobbyUI/team/lb_icon_res_03.dds", Vector4(0, 0, 0, 0)),
		ItemDisableImage = Gui.Image("LobbyUI/ib_common_combobox_bg_02_disabled.dds", Vector4(10, 10, 10, 10)),
	},
	Pad_x = 10,
	TextColor = ARGB(255, 216, 216, 216),
	ItemAlign = "kAlignRightMiddle",
	HighlightTextColor = ARGB(255, 243, 194, 10),
	Border = Vector4(0, 2, 0, 0),
	Default_Width = 8,
	Default_Size = 0.1,
	TextPadding = Vector4(0, 0, 35, 0),
	VScrollBarPos = Vector2(-5, 0),
}
Style "Gui.teamComboList"
{
	AutoScroll = true,
	Skin = Gui.ComboListSkin
	{
		--Control skin
		BackgroundImage = Gui.Image("LobbyUI/mail/lb_mail_xiala_bg.dds", Vector4(10, 10, 10, 10)),
		VBarBackgroundImage = Gui.Image("LobbyUI/team/lb_squad_scrollbar_bg2.dds", Vector4(5, 5, 5, 5)),
		
		VSliderNormalImage = Gui.Image("LobbyUI/team/lb_squad_scrollbar_button_normal.dds", Vector4(5, 5, 5, 5)),
		VSliderHoverImage = Gui.Image("LobbyUI/team/lb_squad_scrollbar_button_hover.dds", Vector4(5, 5, 5, 5)),
		VSliderDownImage = Gui.Image("LobbyUI/team/lb_squad_scrollbar_button_down.dds", Vector4(5, 5, 5, 5)),
		VSliderDisabledImage = Gui.Image("DLobbyUI/team/lb_squad_scrollbar_button_normal.dds", Vector4(5, 5, 5, 5)),
		
		--ComboList skin
		ItemHoverImage = Gui.Image("LobbyUI/mail/lb_mail_xiala_hover.dds", Vector4(10, 10, 10, 10)),
		ItemActiveImage = Gui.Image("LobbyUI/mail/lb_mail_xiala_down.dds", Vector4(10, 10, 10, 10)),
	},
	FontSize = 14,
	TextColor = ARGB(255, 0, 0, 0),
	HighlightTextColor = ARGB(255, 253, 173, 1),
	ItemAlign = "kAlignCenterMiddle",
	Border = Vector4(8,12,8,12),
	Default_Size = 0,
	Default_Width = 5,
}

Style "Gui.WarZoneCreateComboBox"
{
	Skin = Gui.ComboBoxSkin
	{
		ButtonNormalImage= Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_button_normal.dds", Vector4(0, 0, 0, 0)),
		ButtonHoverImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_button_hover.dds", Vector4(0, 0, 0, 0)),
		ButtonDownImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_button_down.dds", Vector4(0, 0, 0, 0)),
		
		TextNormalImage= Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_text.dds", Vector4(6, 0, 0, 0)),
		TextHoverImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_text.dds", Vector4(6, 0, 0, 0)),
		TextDownImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_combobox_text.dds", Vector4(6, 0, 0, 0)),
	},
	Readonly = true,
	TextAlign = "kAlignCenterMiddle",
	ChildComboListStyle = "Gui.ComboList",
	DropDownHeight = 333,
}


Style "Gui.New_teamComboList"
{
	AutoScroll = true,
	Skin = Gui.ComboListSkin
	{
		--Control skin
		BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_summary_flop_bg_04.dds", Vector4(15, 15, 15, 15)),
		
		
		VBarBackgroundImage = Gui.Image("LobbyUI/team/lb_squad_scrollbar_bg2.dds", Vector4(5, 5, 5, 5)),
		
		VSliderNormalImage = Gui.Image("LobbyUI/team/lb_squad_scrollbar_button_normal.dds", Vector4(5, 5, 5, 5)),
		VSliderHoverImage = Gui.Image("LobbyUI/team/lb_squad_scrollbar_button_hover.dds", Vector4(5, 5, 5, 5)),
		VSliderDownImage = Gui.Image("LobbyUI/team/lb_squad_scrollbar_button_down.dds", Vector4(5, 5, 5, 5)),
		VSliderDisabledImage = Gui.Image("DLobbyUI/team/lb_squad_scrollbar_button_normal.dds", Vector4(5, 5, 5, 5)),
		
		--ComboList skin
		ItemHoverImage = Gui.Image("LobbyUI/dailycheck/lb_lucky_xiala_down.dds", Vector4(10, 10, 10, 10)),
		ItemActiveImage = Gui.Image("LobbyUI/mail/lb_mail_xiala_down.dds", Vector4(10, 10, 10, 10)),
	},
	TextColor = ARGB(255, 0, 0, 0),
	HighlightTextColor = ARGB(255, 217, 209, 210),
	ItemAlign = "kAlignCenterMiddle",
	Border = Vector4(8,8,8,8),
	Default_Size = 0,
	Default_Width = 5,
}

Style "Gui.TopListComboList"
{
	AutoScroll = true,
	Skin = Gui.ComboListSkin
	{
		--Control skin
		BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_summary_flop_bg_04.dds", Vector4(15, 15, 15, 15)),
		
		
		VBarBackgroundImage = Gui.Image("LobbyUI/team/lb_squad_scrollbar_bg2.dds", Vector4(5, 5, 5, 5)),
		
		VSliderNormalImage = Gui.Image("LobbyUI/team/lb_squad_scrollbar_button_normal.dds", Vector4(5, 5, 5, 5)),
		VSliderHoverImage = Gui.Image("LobbyUI/team/lb_squad_scrollbar_button_hover.dds", Vector4(5, 5, 5, 5)),
		VSliderDownImage = Gui.Image("LobbyUI/team/lb_squad_scrollbar_button_down.dds", Vector4(5, 5, 5, 5)),
		VSliderDisabledImage = Gui.Image("DLobbyUI/team/lb_squad_scrollbar_button_normal.dds", Vector4(5, 5, 5, 5)),
		
		--ComboList skin
		ItemHoverImage = Gui.Image("LobbyUI/dailycheck/lb_lucky_xiala_down.dds", Vector4(10, 10, 10, 10)),
		ItemActiveImage = Gui.Image("LobbyUI/mail/lb_mail_xiala_down.dds", Vector4(10, 10, 10, 10)),
	},
	TextColor = ARGB(255, 37, 37, 37),
	HighlightTextColor = ARGB(255, 37, 37, 37),
	ItemAlign = "kAlignCenterMiddle",
	Border = Vector4(8,8,8,8),
	Default_Size = 0,
	Default_Width = 5,
}

Style "Gui.ComboList"
{
	Skin = Gui.ComboListSkin
	{
		--Control skin
		BackgroundImage = Gui.Image("DefaultSkin/combolist/lb_common_combobox01_dropdown_bg.dds", Vector4(15,15,32,24)),
		
		--Scrollable Control skin
		UpButtonNormalImage = Gui.Image("DefaultSkin/combolist/lb_common_combobox01_button_normal.dds", Vector4(0, 0, 0, 0)),
		UpButtonHoverImage = Gui.Image("DefaultSkin/combolist/lb_common_combobox01_button_hover.dds", Vector4(0, 0, 0, 0)),
		UpButtonDownImage = Gui.Image("DefaultSkin/combolist/lb_common_combobox01_button_down.dds", Vector4(0, 0, 0, 0)),
		UpButtonDisabledImage = Gui.Image("DefaultSkin/combolist/lb_common_combobox01_button_normal.dds", Vector4(0, 0, 0, 0)),

		DownButtonNormalImage = Gui.Image("DefaultSkin/combolist/lb_common_combobox01_button_normal.dds", Vector4(0, 0, 0, 0)),
		DownButtonHoverImage = Gui.Image("DefaultSkin/combolist/lb_common_combobox01_button_hover.dds", Vector4(0, 0, 0, 0)),
		DownButtonDownImage = Gui.Image("DefaultSkin/combolist/lb_common_combobox01_button_down.dds", Vector4(0, 0, 0, 0)),
		DownButtonDisabledImage = Gui.Image("DefaultSkin/combolist/lb_common_combobox01_button_normal.dds", Vector4(0, 0, 0, 0)),
--[[
		VSliderNormalImage = Gui.Image("DefaultSkin/combolist/skinD_common_scrollbar01_slider_normal.tga", Vector4(5, 11, 5, 11)),
		VSliderHoverImage = Gui.Image("DefaultSkin/combolist/skinD_common_scrollbar01_slider_hover.tga", Vector4(5, 11, 5, 11)),
		VSliderDownImage = Gui.Image("DefaultSkin/combolist/skinD_common_scrollbar01_slider_hover.tga", Vector4(5, 11, 5, 11)),
		VSliderDisabledImage = Gui.Image("DefaultSkin/combolist/skinD_common_scrollbar01_slider_normal.tga", Vector4(5, 11, 5, 11)),
		
		VBarBackgroundImage = Gui.Image("DefaultSkin/combolist/skinD_common_scrollbar01_background.tga", Vector4(5, 34, 5, 34)),
]]--		
		--ComboList skin
		ItemHoverImage = Gui.Image("DefaultSkin/combolist/lb_common_combobox01_dropdown_hover.dds", Vector4(10, 0, 32, 0)),
		ItemActiveImage = Gui.Image("DefaultSkin/combolist/lb_common_combobox01_dropdown_down.dds", Vector4(10, 0, 32, 0)),
	},
	
	TextColor = ARGB(255, 255, 255, 255),
	ItemAlign = "kAlignCenterMiddle",
	Border = Vector4(6,9,10,24),
}

Style "Gui.ComboBox"
{
	Skin = Gui.ComboBoxSkin
	{
 		ButtonNormalImage= Gui.Image("DefaultSkin/combolist/lb_common_combobox01_button_normal.tga", Vector4(0, 6, 10, 6)),
		ButtonHoverImage = Gui.Image("DefaultSkin/combolist/lb_common_combobox01_button_hover.tga", Vector4(0, 6, 10, 6)),
		ButtonDownImage = Gui.Image("DefaultSkin/combolist/lb_common_combobox01_button_down.tga", Vector4(0, 6, 10, 6)),
		--ButtonDisabledImage = Gui.Image("DefaultSkin/DefaultSkin_common_combobox01_button_disabled.tga", Vector4(0, 6, 10, 6)),
		
 		TextNormalImage= Gui.Image("DefaultSkin/combolist/lb_common_combobox01_text_normal.tga", Vector4(8, 6, 0, 6)),
		TextHoverImage = Gui.Image("DefaultSkin/combolist/lb_common_combobox01_text_hover.tga", Vector4(8, 6, 0, 6)),
		TextDownImage = Gui.Image("DefaultSkin/combolist/lb_common_combobox01_text_down.tga", Vector4(8, 6, 0, 6)),
		--TextDisabledImage = Gui.Image("DefaultSkin/DefaultSkin_common_combobox01_text_disabled.tga", Vector4(6, 6, 0, 6)),
	},
	Readonly = true,
	TextAlign = "kAlignCenterMiddle",
	ChildComboListStyle = "Gui.ComboList",
	DropDownHeight = 333,
}

Style "Gui.ComboBoxLikeButton"
{
	Skin = Gui.ComboBoxSkin
	{
		TextDisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_normal.dds", Vector4(10, 10, 10, 10)),
 		TextNormalImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_normal.dds", Vector4(10, 10, 10, 10)),
		TextHoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_hover.dds", Vector4(10, 10, 10, 10)),
		TextDownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_button02_down.dds", Vector4(10, 10, 10, 10)),
	},
	BackgroundColor = ARGB(255,255,255,255),
	TextColor = ARGB(255, 37, 37, 37),
	HighlightTextColor = ARGB(255, 30, 29, 29),
	FontSize = 18,
	Size = Vector2(252, 52),
	Readonly = true,
	ChildComboListStyle = "Gui.ComboList",
	DropDownHeight = 333,
}

Style "Gui.WarZoneComboBox"
{
	Skin = Gui.ComboBoxSkin
	{
 		ButtonNormalImage= Gui.Image("LobbyUI/WarZone/lb_common_combobox01_button_normal.dds", Vector4(0, 6, 10, 6)),
		ButtonHoverImage = Gui.Image("LobbyUI/WarZone/lb_common_combobox01_button_hover.dds", Vector4(0, 6, 10, 6)),
		ButtonDownImage = Gui.Image("LobbyUI/WarZone/lb_common_combobox01_button_down.dds", Vector4(0, 6, 10, 6)),
		--ButtonDisabledImage = Gui.Image("DefaultSkin/DefaultSkin_common_combobox01_button_disabled.tga", Vector4(0, 6, 10, 6)),
		
 		TextNormalImage= Gui.Image("LobbyUI/WarZone/lb_common_combobox01_text_normal.dds", Vector4(8, 6, 0, 6)),
		TextHoverImage = Gui.Image("LobbyUI/WarZone/lb_common_combobox01_text_hover.dds", Vector4(8, 6, 0, 6)),
		TextDownImage = Gui.Image("LobbyUI/WarZone/lb_common_combobox01_text_down.dds", Vector4(8, 6, 0, 6)),
		--TextDisabledImage = Gui.Image("DefaultSkin/DefaultSkin_common_combobox01_text_disabled.tga", Vector4(6, 6, 0, 6)),
	},
	Readonly = true,
	TextAlign = "kAlignCenterMiddle",
	ChildComboListStyle = "Gui.ComboList",
	DropDownHeight = 333,
}

Style "Gui.Menu"
{
	Skin = Gui.MenuSkin
	{
		--ControlSkin
		BackgroundImage = Gui.Image("DefaultSkin/combolist/lb_common_combobox01_dropdown_bg.dds", Vector4(15,15,32,24)),
		
		--Own skin
		ItemHoverImage = Gui.Image("DefaultSkin/combolist/lb_common_combobox01_dropdown_hover.dds", Vector4(10, 0, 32, 0)),
		
	},
	TextColor = ARGB(255,255,255,255),
	Border = Vector4(6,9,10,24),
	ItemWidth = 148,
	SeparatorHeight = 6,
}

Style "Gui.MenuNew"
{
	Skin = Gui.MenuSkin
	{
		--ControlSkin
		BackgroundImage = Gui.Image("LobbyUI/Friends/lb_tooltips_bg.dds", Vector4(12, 12, 12, 12)),
		--Own skin
		ItemHoverImage = Gui.Image("LobbyUI/Friends/lb_contact_youjian_down.dds", Vector4(8, 8, 8, 8)),
		
	},
	TextColor = ARGB(255,255,255,255),
	Border = Vector4(6,9,10,24),
	ItemWidth = 148,
	SeparatorHeight = 6,
}

Style "Gui.Tabpad"
{
	Skin = Gui.TabpadSkin
	{
		--Control skin
		BackgroundImage = Gui.Image("DefaultSkin/DefaultSkin_winBG01_tabBG.tga", Vector4(2, 34, 2, 2)),
		
 	    TabNormalImage= Gui.Image("DefaultSkin/DefaultSkin_common_tabpad01_tab_normal.tga", Vector4(4,6,4,4)),
		TabHoverImage = Gui.Image("DefaultSkin/DefaultSkin_common_tabpad01_tab_hover.tga", Vector4(4,6,4,4)),
		TabActiveImage = Gui.Image("DefaultSkin/DefaultSkin_common_tabpad01_tab_down.tga", Vector4(4,6,4,4)),
		TabNormalDisabledImage = Gui.Image("DefaultSkin/DefaultSkin_common_tabpad01_tab_disabled.tga", Vector4(0,0,0,0)),
	},
	FontSize = 16,
	
	HighlightTextColor = ARGB(255,255,255,255),
	TextShadowColor = ARGB(128,210,210,210),
	TextColor = ARGB(255,0,0,0),

	TabSize = Vector2(88, 28),
	TabPadding = Vector4(3,0,3,0),
	TabLabelPadding = Vector4(0,0,0,0),
	TabGap =3,
}

Style "Gui.Tabpage"
{
	BackgroundColor = ARGB(0,255,255,255),
}

Style "Gui.Slider"
{
	Skin = Gui.SliderSkin
	{
		--Control
		BackgroundImage = Gui.Image("DefaultSkin/DefaultSkin_common_slider01_bg.tga", Vector4(10, 0, 10, 0)),
		
		--Slider
		ThumbNormalImage= Gui.Image("DefaultSkin/DefaultSkin_common_slider01_button_normal.tga", Vector4(0, 0, 0, 0)),
		ThumbHoverImage = Gui.Image("DefaultSkin/DefaultSkin_common_slider01_button_down.tga", Vector4(0, 0, 0, 0)),
		ThumbDownImage = Gui.Image("DefaultSkin/DefaultSkin_common_slider01_button_down.tga", Vector4(0, 0, 0, 0)),
		ThumbDisabledImage = nil,
	},
	ThumbSize = Vector2(11,20),
}

Style "Gui.Label"
{
	BackgroundColor = ARGB(0, 0, 0, 0),
	TextColor = ARGB(255, 255, 255, 255),
}

Style "Gui.Label_Compose"
{
	Size = Vector2(240, 20),
	BackgroundColor = ARGB(0, 0, 0, 0),
	FontSize = 14,
	TextColor = ARGB(255, 213, 255, 254),
	TextAlign = "kAlignLeftMiddle",
}

Style "Gui.QuitLabel"
{
	Size = Vector2(29, 41),
	TextColor = ARGB(255, 255, 211, 78),
	FontSize = 36,
	TextAlign = "kAlignCenterMiddle",
	TextPadding = Vector4(0, 0, 0, 3),
	BackgroundColor = ARGB(255, 255, 255, 255),
	Skin = Gui.ControlSkin
	{
		BackgroundImage = Gui.Image("LobbyUI/summary_number_l_bg.dds",Vector4(10, 10, 10, 10)),
	},
}

Style "Gui.BigTitle"
{
	Font = "simhei",
	FontSize = 44,
	BackgroundColor = ARGB(0,0,0,0),
	TextColor = ARGB(255,255,255,255),	
}

Style "Gui.FlowLayout"
{
	BackgroundColor = ARGB(0, 0, 0, 0),
}

Style "Gui.Picture"
{
	Skin = Gui.PictureSkin
	{
		--control skin
		BackgroundImage = Gui.Image("DefaultSkin/DefaultSkin_BG50%.tga", Vector4(3, 3, 3, 3)),
		
		--picture skin
		HoverFrame = Gui.Image("DefaultSkin/DefaultSkin_BG30%.tga", Vector4(3, 3, 3, 3)),
		HighlightFrame = Gui.Image("DefaultSkin/DefaultSkin_room_map_down.tga", Vector4(8, 8, 8, 8)),
	},
	TextColor = ARGB(255,144,144,144),
	Padding = Vector4(4,6,4,6),
}

Style "Gui.PictureMapInBrowser"
{
	Skin = Gui.ItemPictureSkin
	{
		--control skin
		BackgroundImage = Gui.Image("DefaultSkin/DefaultSkin_BG50%.tga", Vector4(3, 3, 3, 3)),
		
		--picture skin
		HoverFrame = Gui.Image("MapsAndBG/MapsIcon/lb_battlefield_map_hover.dds", Vector4(3, 3, 3, 3)),
		HighlightFrame = Gui.Image("MapsAndBG/MapsIcon/frame.dds", Vector4(8, 8, 8, 8)),
		
		EmptyFrame = Gui.Image("DefaultSkin/DefaultSkin_BG50%.tga", Vector4(3, 3, 3, 3)),
	},
	KeepAspect = false,
	TextColor = ARGB(255,144,144,144),
	Padding = Vector4(3,3,3,3),
}

Style "Gui.ZhanduiPictureMapInBrowser"
{
	Skin = Gui.ItemPictureSkin
	{
		--control skin
		BackgroundImage = Gui.Image("DefaultSkin/DefaultSkin_BG50%.tga", Vector4(3, 3, 3, 3)),
		
		--picture skin
		HoverFrame = Gui.Image("MapsAndBG/MapsIcon/lb_battlefield_map_hover.dds", Vector4(3, 3, 3, 3)),
		HighlightFrame = Gui.Image("LobbyUI/team/NewFight/lb_tutorial_square01.dds", Vector4(8, 8, 8, 8)),
		
		EmptyFrame = Gui.Image("DefaultSkin/DefaultSkin_BG50%.tga", Vector4(3, 3, 3, 3)),
	},
	KeepAspect = false,
	TextColor = ARGB(255,144,144,144),
	Padding = Vector4(3,3,3,3),
}


Style "Gui.ImageBrowser"
{
	Skin = Gui.ControlSkin
	{
		BackgroundImage = nil,
	},
	PictureStyle = "Gui.Picture",
}

ListItemSkin1 = Gui.ListItemSkin	--normal list item
{
	--control skin
	BackgroundImage = nil,
	
	--list item skin
	BackgroundImageOp = nil,
	HoverImage = Gui.Image("DefaultSkin/DefaultSkin_row01_hover.tga", Vector4(8, 4, 8, 6)),
	SelectedImage = Gui.Image("DefaultSkin/DefaultSkin_row01_down.tga", Vector4(8, 4, 8, 6)),
	DisabledImage = Gui.Image("DefaultSkin/DefaultSkin_row01_disabled.tga", Vector4(8, 4, 8, 6)),
	FrameImage = Gui.Image("DefaultSkin/DefaultSkin_row01_frame.tga", Vector4(6, 6, 6, 6)),
	CheckOnIcon = Gui.Icon("DefaultSkin/DefaultSkin_common_checkbox01_on_normal.tga", Vector4(5, 5, 5, 5)),
	CheckOffIcon = Gui.Icon("DefaultSkin/DefaultSkin_common_checkbox01_off_normal.tga", Vector4(5, 5, 5, 5)),
}

ListHeaderSkin1 = Gui.HeaderSkin
{
	NormalImage = nil,
	HoverImage = nil,
	DownImage = nil,
	SortNormalImage = Gui.Image("DefaultSkin/DefaultSkin_list01_sort_normal.tga", Vector4(0,0,0,0)),
	SortReverseImage = Gui.Image("DefaultSkin/DefaultSkin_list01_sort_reverse.tga", Vector4(0,0,0,0)),	
}

Style "Gui.ListTreeView"
{
	Skin = commonScrSkinTree,
	
	ItemSkin = Skin.ListItemSkin1,
	HeaderSkin = Skin.ListHeaderSkin1,

	TreeVisible = false,
	
	BackgroundColor = ARGB(255, 255, 255, 255),
	TextColor = ARGB(255, 255, 255, 255),
}

Style "Gui.ListTreeViewSPA"
{
	Skin = commonScrSkinTree,
	
	ItemSkin = Skin.ListItemSkin1,
	HeaderSkin = Skin.ListHeaderSkin1,

	HeaderHeight = 30,
	BackgroundColor = ARGB(255, 255, 255, 255),
	TextColor = ARGB(255, 255, 255, 255),
}

Gui.Style "Gui.WindowUI"
{
	Skin = Gui.ControlSkin
	{
		BackgroundImage = Gui.Image("DefaultSkin/DefaultSkin_winBG01.tga", Vector4(286,70,0,0)),
	},

	Font = "simhei",
	FontSize = 24,
	BackgroundColor = ARGB(255,255,255,255),
	Padding = Vector4(0,67,0,0),
	ContentSize = Vector2(428, 396),
	CloseButtonStyle = "Window.CloseButton",
}

Gui.Style "Gui.OtherViewWindow"
{
	Skin = Gui.ControlSkin
	{
		BackgroundImage = Gui.Image("DefaultSkin/DefaultSkin_winBG01other.tga", Vector4(215,70,0,0)),
	},

	Font = "simhei",
	FontSize = 24,
	BackgroundColor = ARGB(255,255,255,255),
	Padding = Vector4(0,67,0,0),
}

Gui.Style "Gui.SettingsWindow"
{
	Skin = Gui.ControlSkin
	{
		BackgroundImage = Gui.Image("DefaultSkin/DefaultSkin_winBG01settings.tga", Vector4(215,70,0,0)),
	},

	Font = "simhei",
	FontSize = 24,
	BackgroundColor = ARGB(255,255,255,255),
	Padding = Vector4(0,67,0,0),
}

Style "Gui.ModalWindow"
{
	BackgroundColor = ARGB(0, 255, 255, 255),
}

Style "Gui.SelectWindow"
{
	BackgroundColor = ARGB(0,255,255,255),
}

Style "Gui.SettingWindow"
{
	Skin = Gui.ControlSkin
	{
		BackgroundImage = Gui.Image("DefaultSkin/DefaultSkin_setting_win01.tga", Vector4(0,45,0,0)),
	},

	Font = "simhei",
	FontSize = 24,
	BackgroundColor = ARGB(255,255,255,255),
}

Style "Gui.EscMenuButton"
{
	Skin = Gui.ButtonSkin
	{
		BackgroundImage = Gui.Image("DefaultSkin/DefaultSkin_button01_normal.tga", Vector4(8,8,8,8)),
		HoverImage = Gui.Image("DefaultSkin/DefaultSkin_button01_hover.tga", Vector4(8,8,8,8)),
		DownImage = Gui.Image("DefaultSkin/DefaultSkin_button01_down.tga", Vector4(8,8,8,8)),
		DisabledImage = Gui.Image("DefaultSkin/DefaultSkin_button01_disabled.tga", Vector4(8,8,8,8)),
	},
	FontSize = 18,	
	BackgroundColor = ARGB(255,255,255,255),
	Size = Vector2(142, 48),
}


Gui.Style "Window.CloseButton"
{
	Skin = Gui.ButtonSkin
	{
		BackgroundImage = Gui.Image("DefaultSkin/DefaultSkin_button02_normal.tga", Vector4(8,8,8,8)),
		HoverImage = Gui.Image("DefaultSkin/DefaultSkin_button02_hover.tga", Vector4(8,8,8,8)),
		DownImage = Gui.Image("DefaultSkin/DefaultSkin_button02_down.tga", Vector4(8,8,8,8)),
		DisabledImage = Gui.Image("DefaultSkin/DefaultSkin_button02_disabled.tga", Vector4(8,8,8,8)),
	},

	Margin = Vector4(0, 12, 32, 0),
	Size = Vector2(16, 16),
}

Gui.Style "Transparent"
{
	BackgroundColor = ARGB(0, 0, 0, 0),
}
-------------------------------------------------------------------------------------------
-- common background skin
-------------------------------------------------------------------------------------------
Gui.Style "MessageBoxStyle.Text"
{
	Size = Vector2(526, 200),
	TextAlign = "kAlignCenterMiddle",
	BackgroundColor = ARGB(0, 0, 0, 0),
	TextColor = ARGB(255, 37, 37, 37),
	FontSize = 24,
}

Gui.Style "MessageBoxStyle.Button"
{
	Skin = Gui.ButtonSkin
	{
		BackgroundImage = Gui.Image("LobbyUI/lb_shop_button04_normal.dds", Vector4(10, 8, 10, 8)),
		HoverImage = Gui.Image("LobbyUI/lb_shop_button04_hover.dds", Vector4(10, 8, 10, 8)),
		DownImage = Gui.Image("LobbyUI/lb_shop_button04_down.dds", Vector4(10, 8, 10, 8)),
		DisabledImage = Gui.Image("LobbyUI/lb_shop_button04_normal.dds", Vector4(10, 8, 10, 8)),
	},
	FontSize = 20,	
	
	--TextColor = ARGB(255, 255, 255, 255),
	--TextLightSource = -math.pi/6,
	TextColor = ARGB(255,0,0,0),
	HighlightTextColor = ARGB(255,0,0,0),
	TextShadowColor = ARGB(64,255,255,255),

	BackgroundColor = ARGB(255,255,255,255),
	Size = Vector2(106, 58),
}

Style "Gui.ButtonCharacter"
{
	Skin = Gui.ButtonSkin
	{
		BackgroundImage = Gui.Image("InGameUI/select_person/ig_common_xuanren_button_normal.dds", Vector4(0,0,0,0)),
		HoverImage = Gui.Image("InGameUI/select_person/ig_common_xuanren_button_hover.dds", Vector4(0,0,0,0)),
		DownImage = Gui.Image("InGameUI/select_person/ig_common_xuanren_button_down.dds", Vector4(0,0,0,0)),
	},
	FontSize = 18,
	BackgroundColor = ARGB(255, 255, 255, 255),
	Size = Vector2(148, 32),	
}

Style "Gui.Tooltip"
{
	Skin = Gui.TooltipSkin
	{
		BackgroundImage = Gui.Image("defaultskin/tooltip/defaultskin_tips01_a.tga", Vector4(6, 6, 6, 10)),
		ArrowDownImage = Gui.Image("defaultskin/tooltip/defaultskin_tips01_b.tga", Vector4(0, 6, 0, 10)),
		ArrowUpImage = Gui.Image("defaultskin/tooltip/defaultskin_tips01_b2.tga", Vector4(0, 6, 0, 10)),
	},
	TextColor = ARGB(255,0,0,0),
	--TextLightSource = math.pi*3/4,
	TextShadowColor = ARGB(128,255,255,255),

	--TextPadding = Vector4(10,12,10,16),
	TextPadding = Vector4(3+15,3+5,3+15,7+5),
	MaxWidth = 360,
	ArrowWidth = 18,
}

Style "Gui.MessagePanel"
{
	Skin = Gui.ScrollableControlSkin
	{
		VSliderNormalImage = Gui.Image("LobbyUI/Friends/lb_battlefield_scrollbar_button_03_normal.dds", Vector4(3, 4, 5, 5)),
		VSliderHoverImage = Gui.Image("LobbyUI/Friends/lb_battlefield_scrollbar_button_03_hover.dds", Vector4(3, 4, 5, 5)),
		VSliderDownImage = Gui.Image("LobbyUI/Friends/lb_battlefield_scrollbar_button_03_down.dds", Vector4(3, 4, 5, 5)),
		VSliderDisabledImage = Gui.Image("LobbyUI/Friends/lb_battlefield_scrollbar_button_03_normal.dds", Vector4(3, 4, 5, 5)),

		VBarBackgroundImage = Gui.Image("LobbyUI/Friends/lb_battlefield_scrollbar_bg.dds", Vector4(3, 4, 5, 5)),
		BarCornerImage = nil,
	},
}

Style "Gui.Toplist"
{
	Skin = Gui.ScrollableControlSkin
	{
	
		UpButtonNormalImage = Gui.Image("LobbyUI/Friends/lb_battlefield_scrollbar_button_01_normal.dds", Vector4(0, 0, 0, 0)),
		UpButtonHoverImage = Gui.Image("LobbyUI/Friends/lb_battlefield_scrollbar_button_01_hover.dds", Vector4(0, 0, 0, 0)),
		UpButtonDownImage = Gui.Image("LobbyUI/Friends/lb_battlefield_scrollbar_button_01_down.dds", Vector4(0, 0, 0, 0)),
		UpButtonDisabledImage = nil,

		DownButtonNormalImage = Gui.Image("LobbyUI/Friends/lb_battlefield_scrollbar_button_02_normal.dds", Vector4(0, 0, 0, 0)),
		DownButtonHoverImage = Gui.Image("LobbyUI/Friends/lb_battlefield_scrollbar_button_02_hover.dds", Vector4(0, 0, 0, 0)),
		DownButtonDownImage = Gui.Image("LobbyUI/Friends/lb_battlefield_scrollbar_button_02_down.dds", Vector4(0, 0, 0, 0)),
		DownButtonDisabledImage = nil,
		
		VSliderNormalImage = Gui.Image("LobbyUI/Friends/lb_battlefield_scrollbar_button_03_normal.dds", Vector4(3, 4, 5, 5)),
		VSliderHoverImage = Gui.Image("LobbyUI/Friends/lb_battlefield_scrollbar_button_03_hover.dds", Vector4(3, 4, 5, 5)),
		VSliderDownImage = Gui.Image("LobbyUI/Friends/lb_battlefield_scrollbar_button_03_down.dds", Vector4(3, 4, 5, 5)),
		VSliderDisabledImage = Gui.Image("LobbyUI/Friends/lb_battlefield_scrollbar_button_03_normal.dds", Vector4(3, 4, 5, 5)),

		VBarBackgroundImage = Gui.Image("LobbyUI/Friends/lb_battlefield_scrollbar_bg.dds", Vector4(3, 4, 5, 5)),
		BarCornerImage = nil,
	},
}

Style "Gui.ChatBarStyle"
{
	Skin = Gui.ControlSkin
	{
		BackgroundImage = Gui.Image("skinD/skinD_chat_BG02.tga", Vector4(28, 0, 2, 0)),
	},
	BackgroundColor = ARGB(255,255,255,255),
}

Style "Gui.ChatTab"
{
	Skin = Gui.TabpadSkin
	{
		--Control skin
		BackgroundImage = Gui.Image("skinD/skinD_chat_BG01.tga", Vector4(2, 28, 2, 2)),

 	    TabNormalImage= Gui.Image("skinD/skinD_chat_tab_normal.tga", Vector4(0,0,0,0)),
		TabHoverImage = Gui.Image("skinD/skinD_chat_tab_hover.tga", Vector4(0,0,0,0)),
		TabActiveImage = Gui.Image("skinD/skinD_chat_tab_down.tga", Vector4(0,0,0,0)),
		TabNormalDisabledImage = Gui.Image("skinD/skinD_chat_tab_normal.tga", Vector4(0,0,0,0)),
		TabActiveDisabledImage = Gui.Image("skinD/skinD_chat_tab_normal.tga", Vector4(0,0,0,0)),
	},
}

Style "Gui.ChatAddButton"
{
	Skin = Gui.ButtonSkin
	{
		BackgroundImage = Gui.Image("skinD/skinD_chat_button01_normal.tga", Vector4(2,2,2,2)),
		HoverImage = Gui.Image("skinD/skinD_chat_button01_hover.tga", Vector4(2,2,2,2)),
		DownImage = Gui.Image("skinD/skinD_chat_button01_down.tga", Vector4(2,2,2,2)),
		DisabledImage = nil,
	},

	BackgroundColor = ARGB(255,255,255,255),
}

Style "Gui.ChatTextBoxStyle"
{
	Skin = Gui.TextboxSkin
	{
		BackgroundImage = nil,
		ActiveImage = nil,
		DisabledImage = nil,
	},
	TextColor = ARGB(255, 255, 255, 255),
}

Style "Gui.ChatComboBox"
{
	Skin = Gui.ComboBoxSkin
	{
 		ButtonNormalImage= Gui.Image("skinD/skinD_chat_button02_normal.tga", Vector4(2, 2, 2, 2)),
		ButtonHoverImage = Gui.Image("skinD/skinD_chat_button02_hover.tga", Vector4(2, 2, 2, 2)),
		ButtonDownImage = Gui.Image("skinD/skinD_chat_button02_down.tga", Vector4(2, 2, 2, 2)),
		ButtonDisabledImage = nil,
	},

	ChildComboListStyle = "Gui.ComboList",
}

Style "Gui.ChatButton"
{
	Skin = Gui.ButtonSkin
	{
		BackgroundImage = Gui.Image("skinD/skinD_button02_normal.tga", Vector4(8,8,8,8)),
		HoverImage = Gui.Image("skinD/skinD_button02_hover.tga", Vector4(8,8,8,8)),
		DownImage = Gui.Image("skinD/skinD_button02_down.tga", Vector4(8,8,8,8)),
		DisabledImage = Gui.Image("skinD/skinD_button01_disabled.tga", Vector4(8,8,8,8)),
	},

	TextColor = ARGB(255,0,0,0),
	HighlightTextColor = ARGB(255,0,0,0),
	TextShadowColor = ARGB(64,255,255,255),

	BackgroundColor = ARGB(255,255,255,255),
}

Style "Gui.RadioButton"
{
	Skin = Gui.CheckBoxSkin
	{
		OnImage = Gui.Image("InGameUI/kick/ig_tr_radiobutton_down.dds", Vector4(0, 0, 0, 0)),
		OffImage = Gui.Image("InGameUI/kick/ig_tr_radiobutton_normal.dds", Vector4(0, 0, 0, 0)),
		OnDisabledImage = Gui.Image("InGameUI/kick/ig_tr_radiobutton_down.dds", Vector4(0, 0, 0, 0)),
		OffDisabledImage = Gui.Image("InGameUI/kick/ig_tr_radiobutton_normal.dds", Vector4(0, 0, 0, 0)),
	},
	TextColor = ARGB(255, 84, 82, 77),
	BackgroundColor = ARGB(0, 0, 0, 0),
}

Style "Gui.ChatToBottom_up"
{
	Skin = Gui.ButtonSkin
	{
		BackgroundImage = Gui.Image("LobbyUI/Friends/lb_battlefield_scrollbar_button_01_normal.dds", Vector4(0, 0, 0, 0)),
		HoverImage = Gui.Image("LobbyUI/Friends/lb_battlefield_scrollbar_button_01_hover.dds", Vector4(0, 0, 0, 0)),
		DownImage = Gui.Image("LobbyUI/Friends/lb_battlefield_scrollbar_button_01_down.dds", Vector4(0, 0, 0, 0)),
		DisabledImage = Gui.Image("LobbyUI/Friends/lb_battlefield_scrollbar_button_01_normal.dds", Vector4(0, 0, 0, 0)),
	},
	
	BackgroundColor = ARGB(255,255,255,255),
}

Style "Gui.ChatToBottom_down"
{
	Skin = Gui.ButtonSkin
	{
		BackgroundImage = Gui.Image("LobbyUI/Friends/lb_battlefield_scrollbar_button_02_normal.dds", Vector4(0, 0, 0, 0)),
		HoverImage = Gui.Image("LobbyUI/Friends/lb_battlefield_scrollbar_button_02_hover.dds", Vector4(0, 0, 0, 0)),
		DownImage = Gui.Image("LobbyUI/Friends/lb_battlefield_scrollbar_button_02_down.dds", Vector4(0, 0, 0, 0)),
		DisabledImage = Gui.Image("LobbyUI/Friends/lb_battlefield_scrollbar_button_02_normal.dds", Vector4(0, 0, 0, 0)),
	},
	
	BackgroundColor = ARGB(255,255,255,255),
}

-------------资源争夺战图片加载----------------------------------------------
--资源战各按钮资源
TeamBtnSkin = Gui.ButtonSkin
{
	BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_button12_normal.dds", Vector4(10, 10, 10, 10)),
	HoverImage = Gui.Image("LobbyUI/team/lb_squad_button12_hover.dds", Vector4(10, 10, 10, 10)),
	DownImage = Gui.Image("LobbyUI/team/lb_squad_button12_down.dds", Vector4(10, 10, 10, 10)),
	DisabledImage = Gui.Image("LobbyUI/team/lb_squad_button12_disabled.dds", Vector4(10, 10, 10, 10)),
}
--连线资源
line1 = Gui.ControlSkin
{
    BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_xian_bg.dds", Vector4(0,3,3,3)),
}
--删除按钮的资源
DelBtnSkin = Gui.ButtonSkin
{
	BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_v2_02_normal.dds", Vector4(0, 0, 0, 0)),
	HoverImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_v2_02_hover.dds", Vector4(0, 0, 0, 0)),
	DownImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_v2_02_down.dds", Vector4(0, 0, 0, 0)),
	DisabledImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_v2_02_disabled.dds", Vector4(0, 0, 0, 0)),
}
--仓库按钮资源
StorageBtnSkin = Gui.ButtonSkin
{
	BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_normal.dds", Vector4(15, 12, 15, 6)),
	HoverImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_hover.dds", Vector4(15, 12, 15, 6)),
	DownImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_down.dds", Vector4(15, 12, 15, 6)),
	DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_shop_tab03_normal.dds", Vector4(15, 12, 15, 6)),
}
--升级按钮资源
LevelUpBtnSkin = Gui.ButtonSkin
{
	BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_button13_normal.dds", Vector4(5, 5, 5, 5)),
	HoverImage = Gui.Image("LobbyUI/team/lb_squad_button13_hover.dds", Vector4(5, 5, 5, 5)),
	DownImage = Gui.Image("LobbyUI/team/lb_squad_button13_down.dds", Vector4(5, 5, 5, 5)),
	DisabledImage = Gui.Image("LobbyUI/team/lb_squad_button13_disabled.dds", Vector4(5, 5, 5, 5)),
}

levelPic = {}
for i = 1,5,1 do
    levelPic[i] = Gui.ControlSkin
    {
        BackgroundImage = Gui.Image("LobbyUI/team/lb_kongjianshengji_0" .. i .. ".dds", Vector4(0,0,0,0)),
    }
end

priceIcon =
{
	[2] = Gui.ControlSkin{ BackgroundImage = Gui.Image("LobbyUI/team/lb_icon_res_fc.dds", Vector4(0,0,0,0)),},--FC点图标
	[5] = Gui.ControlSkin{ BackgroundImage = Gui.Image("LobbyUI/team/lb_icon_res_03.dds", Vector4(0,0,0,0)),},--个人黑晶石图标
	[6] = Gui.ControlSkin{ BackgroundImage = Gui.Image("LobbyUI/team/lb_icon_res_01.dds",Vector4(0, 0, 0, 0)),},--战队黑铁图标
	[7] = Gui.ControlSkin{ BackgroundImage = Gui.Image("LobbyUI/team/lb_icon_res_02_1.dds",Vector4(0, 0, 0, 0)),},--个人不可用能源图标
	[8] = Gui.ControlSkin{ BackgroundImage = Gui.Image("LobbyUI/team/lb_icon_res_02.dds",Vector4(0, 0, 0, 0)),},--战队不可用能源图标
}

priceLevelIcon = Gui.ControlSkin{ BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_zhanduikongjian.dds", Vector4(0,0,0,0)),}--空间等级图标

itemLevelIcon =
{
	[1] = Gui.ControlSkin{ BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_lv_bg01.dds", Vector4(0,0,0,0)),},  --一颗星 
	[2] = Gui.ControlSkin{ BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_lv_bg02.dds", Vector4(0,0,0,0)),},  --二颗星 
	[3] = Gui.ControlSkin{ BackgroundImage = Gui.Image("LobbyUI/team/lb_squad_lv_bg03.dds",Vector4(0, 0, 0, 0)),},--三颗星 
}
--空间升级内的tab按钮
Gui.Style "PlaceLevelUpTabStyle"
{
	Skin = Gui.ButtonSkin
	{
		BackgroundImage = Gui.Image("LobbyUI/team/lb_shop_tab03_normal.dds", Vector4(15, 12, 15, 6)),
		HoverImage = Gui.Image("LobbyUI/team/lb_shop_tab03_hover.dds", Vector4(15, 12, 15, 6)),
		DownImage = Gui.Image("LobbyUI/team/lb_shop_tab03_down.dds", Vector4(15, 12, 15, 6)),
		DisabledImage = Gui.Image("LobbyUI/team/lb_shop_tab03_normal.dds", Vector4(15, 12, 15, 6)),
	},
	FontSize = 18,	
	--TextLightSource = -math.pi/6,
	TextColor = ARGB(255,0,0,0),
	HighlightTextColor = ARGB(255,255,255,255),
	TextShadowColor = ARGB(64,0,0,0),

	BackgroundColor = ARGB(255,255,255,255),
	Size = Vector2(120,56),
}