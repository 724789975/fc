module("MessageBox", package.seeall)

local message_box = nil

font_color = 
{
	ARGB(255, 160, 0, 220), 
	ARGB(255, 5, 0, 199), 
	ARGB(255, 0, 139, 179), 
	ARGB(255, 0, 137, 52), 
	ARGB(255, 224, 68, 0), 
	ARGB(255, 181, 0, 0), 
	ARGB(255, 255, 0, 0), 
	ARGB(255, 37, 37, 37), --default color
}

--function GetStandardMB(message, button, clicked)
function Show(message, button, clicked)
	local tempMB = GetStandardMB(message)
	if button then
		AddButton(button, function() 
			if clicked then
				clicked()
			end
			if tempMB.root then
				tempMB.Close()
			end
		end, true)
	end
	return tempMB
end

function ShowWithTimer(time, message, button, clicked)
	local tempMB = GetTimerMB(time, message,button)
	if button then
		AddButton(button, function() 
			if clicked then
				clicked()
			end
			if tempMB.root then
				tempMB.Close()
			end
		end, true)
	end
	return tempMB
end

function ShowWithTimers(time, message, buttonA, buttonB ,clickedA ,clickedB)
	local tempMB = GetTimerMB(time, message,buttonA)
	if buttonA then
		print(buttonA)
		AddButton(buttonA, function() 
			if clickedA then
				clickedA()
			end
			if tempMB.root then
				tempMB.Close()
			end
		end,
		true)
	end
	if buttonB then
		print(buttonB)
		AddButton(buttonB, function() 
			if clickedB then
				clickedB()
			end
			if tempMB.root then
				tempMB.Close()
			end
		end,
		true)
	end
	return tempMB
end

function ShowWithAButton(message, str, clicked, style)
	local tempMB = GetStandardMB(message)
	if str then
		AddButton(str, function() 
			if clicked then
				clicked()
			end
			if tempMB.root then
				tempMB.Close()
			end
		end,
		false,
		style)
	end
	
	return tempMB	
end

function ShowWithConfirm(message, clicked)
	ShowWithAButton(message, lang:GetText("确 定"), clicked, nil)
	if gui then
		gui:PlayAudio("kUIA_CONFIRM_MESSAGE")
	end
end

function ShowWithTwoButtons(message, strA, strB, clickedA, clickedB, styleA, styleB)
	local tempMB = GetStandardMB(message)
	if strA then
		AddButton(strA, function() 
			if clickedA then
				clickedA()
			end
			if tempMB.root then
				tempMB.Close()
			end
		end,
		false,
		styleA)
	end
	if strB then
		AddButton(strB, function() 
			if clickedB then
				clickedB()
			end
			if tempMB.root then
				tempMB.Close()
			end
		end,
		false,
		styleB)
	end	
	--------------------------------------------------------------
	----------------------------------------------------------
	
	if gui then
		gui:PlayAudio("kUIA_CONFIRM_MESSAGE")
	end
	return tempMB	
end

function ShowWithThreeButtons(message, strA, strB, strC, clickedA, clickedB, clickedC, styleA, styleB, styleC)
	local tempMB = GetStandardMB(message)
	if strA then
		AddButton(strA, function() 
			if clickedA then
				clickedA()
			end
			if tempMB.root then
				tempMB.Close()
			end
		end,
		false,
		styleA)
	end
	if strB then
		AddButton(strB, function() 
			if clickedB then
				clickedB()
			end
			if tempMB.root then
				tempMB.Close()
			end
		end,
		false,
		styleB)
	end	
	
	if strC then
		AddButton(strC, function() 
			if clickedC then
				clickedC()
			end
			if tempMB.root then
				tempMB.Close()
			end
		end,
		false,
		styleC)
	end	
	
	if gui then
		gui:PlayAudio("kUIA_CONFIRM_MESSAGE")
	end
	return tempMB	
end

function ShowWithConfirmCancel(message, clickedA, clickedB)
	ShowWithTwoButtons(message, lang:GetText("确 定"), lang:GetText("取 消"), clickedA, clickedB, nil, nil)
end

function GetStandardMB(message)
	message_box = Gui.Create
	{
		Gui.Control "panel"
		{
			--Size = Vector2(400, 260),
			Dock = "kDockFill",
			Padding = Vector4(10, 10, 10, 10),
			BackgroundColor = ARGB(204, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/lb_common_up_bg_01.dds", Vector4(200, 20, 100, 0)),
			},
			
			Gui.FlowLayout "message_area"
			{
				Size = Vector2(526, 200),
				Location = Vector2(0, 20),
				BackgroundColor = ARGB(0, 0, 0, 0),
				--Align = "kAlignCenterMiddle",
				ControlAlign = "kAlignCenterMiddle",
			},
			
			Gui.FlowLayout "button_area"
			{
				Size = Vector2(526, 80),
				Location = Vector2(0, 201),
				Align = "kAlignCenterMiddle",
				ControlAlign = "kAlignCenterMiddle",
				ControlSpace = 20,
			},
		},
	}
	AddMessage(message)
	--AddButton(button, clicked)
	
	local return_mb = message_box		--message_box is a local variable to this whole scritps, if 2 messagebox is created sequencially, then the first
										--messagebox's Close function will set the second one's Close funtion to the empty function.   a tough bug 
	local modalwin = ModalWindow.GetNew()
	modalwin.screen.AllowEscToExit = false
	modalwin.root.Size = Vector2(526, 272)
	return_mb.panel.Parent = modalwin.root
	return_mb.root = modalwin.root
	return_mb.Close = function()
			--print("MessageBox Close")
			--print(return_mb.root)
			modalwin.Close()
			return_mb.Close = function() print("+++++++++++++++++++++++I'm MessageBox:empty+++++++++++++++++++++") print(return_mb.root) end
		end
	--print("New message box created:") print(return_mb.root)
	return return_mb
end

function GetTimerMB(time, message,button)
	local mb = GetStandardMB(message)
	if button == nil then
		mb.button_area.Size = Vector2(0,0)
	end
	mb.root.Timer = time
	return mb
end

function AddMessage(message)
	if message_box then
		local message_control

		if type(message) == "string" then
			message_control = ptr_new "Gui.Label"
			message_control.Style = "MessageBoxStyle.Text"
			message_control.Location = Vector2(0, 0)
			--message_control.AutoSize = true
			--message_control.TextColor = ARGB(255, 255, 255, 255)
			message_control.Text = message
			--message_control.BackgroundColor = ARGB(0, 0, 0, 0)
		else
			message_control = ptr_cast(message, "Gui.Control")
		end

		if message_control then
			message_control.Parent = message_box.message_area
		end
	end
end

function SetMessage(message)
	if message_box then
		Gui.Clear(message_box.message_area)
		AddMessage(message)
	end
end

function AddButton(button, clicked, bFocused,style)
	if message_box then
		local button_control
		
		if type(button) == "string" then
			button_control = ptr_new "Gui.Button"
			if type(style) == "string" then
				button_control.Style = style
			else
				button_control.Style = "MessageBoxStyle.Button"
			end
			button_control.Text = button
			button_control.Size = Vector2(128, 40)
			button_control.TextColor = ARGB(255, 0, 0, 0)
			button_control.HighlightTextColor = ARGB(255, 0, 0, 0)
			button_control.FontSize = 22
			button_control.Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/lb_common_up_button_normal.dds", Vector4(20, 20, 20, 20)),
				HoverImage = Gui.Image("LobbyUI/lb_common_up_button_hover.dds", Vector4(20, 20, 20, 20)),
				DownImage = Gui.Image("LobbyUI/lb_common_up_button_down.dds", Vector4(20, 20, 20, 20)),
				DisabledImage = Gui.Image("LobbyUI/lb_common_up_button_disabled.dds", Vector4(20, 20, 20, 20)),			
			}
			if bFocused then
				print("message box button have focuse now")
				button_control.Focused = true
			end
		else 
			button_control = ptr_cast(button, "Gui.Button")
		end

		if button_control then
			button_control.Parent = message_box.button_area
			if type(clicked) == "function" then
				button_control.EventClick = clicked
			end
		end
	end
end

function AllowEsc(bAllow)
	if message_box then
		if bAllow==true or bAllow==false then
			local msscreen = ptr_cast(message_box.panel.Parent.Parent)
			if msscreen then
				msscreen.AllowEscToExit = bAllow
			end
		end
	end
end

function SetSize(size)
	if message_box then
		message_box.panel.Size = size
		message_box.root.Size = size
	end
end

--[[  not neccesary
function FinishSetting()
	if message_box then
		print("Finishing Setting, clear local holder")
		message_box = nil
	end
end
]]

function ShowType1(str)
	ShowError(str)
end

function ShowType2(str)
	ShowWithTimer(1, str)
end

function ShowType3(message, clickedA, clickedB)
	ShowWithConfirmCancel(message, clickedA, clickedB)
end

function ShowError(err,click)
	Show(tostring(err),lang:GetText("确 定"),click)
end

function ShowMultiline(msg)
	local modalwin = ModalWindow.GetNew()
	modalwin.screen.AllowEscToExit = false
	modalwin.root.Size = Vector2(526, 272)
	local content =
	{
		Gui.Control "root"
		{
			Dock = "kDockFill",
			
			Gui.FlowLayout "buttonArea"
			{
				Size = Vector2(0, 80),
				Dock = "kDockBottom",
				Align = "kAlignCenterMiddle",
				ControlAlign = "kAlignCenterMiddle",
				ControlSpace = 6,
				
				Gui.Button "buttonConfirm"
				{
					Text = lang:GetText("我知道了"),
					Dock = "kDockCenter",
					Style = "MessageBoxStyle.Button",
				},
			},
			
			Gui.TextArea "messageArea"
			{
				Style = "Gui.TextAreaWithVBarRO",
				Dock = "kDockFill",
				Fold = true,
				Margin = Vector4(20,10,20,10),
				HScrollBarDisplay = "kHide",
				VScrollBarDisplay = "kVisible",
			},
		},
	}
	local msgBox = Gui.Create(modalwin.root)(content)
	msgBox.buttonConfirm.EventClick = function() modalwin.Close() msgBox.buttonConfirm.EventClick = nil end
	msgBox.messageArea.Text = msg
end

local wmbHolder = nil
function ShowWaiter(msg)
	--print("ShowWaiter")
	if wmbHolder then
		wmbHolder.Close()
		wmbHolder = nil
	end
	wmbHolder = MessageBox.Show(msg)
	wmbHolder.button_area.Size = Vector2(0,0)
	wmbHolder.root.Size = Vector2(526, 272)
end

function CloseWaiter()
	--print("CloseWaiter")
	if wmbHolder then
		wmbHolder.Close()
		wmbHolder = nil
	end
end