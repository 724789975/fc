module("Gui", package.seeall)

local styles = {}
local skins = {}

local function WidgetConstructor(ctor, id, t)
	return function (parent, vars)
		local widget = ctor()

		-- global var
		if vars then
			table.insert(vars, widget)

			if id then
				vars[id] = widget
			end
		end

		-- set style first.
		if t.Style then
			widget.Style = t.Style
		else
			widget.Style = ptr_typename(widget)
		end

		-- set attributes
		for attr, value in pairs(t) do
			if type(attr) == "string" then
				if attr ~= "Style" and attr ~= "EventCreate" then
					widget[attr] = value
				end
			end
		end

		-- set parent
		if t.Parent == nil and parent then
			widget.Parent = parent
		end

		-- childs
		for id, creator in ipairs(t) do
			creator(widget, vars)
		end

		-- on create
		if t.EventCreate then
			t.EventCreate(widget)
		end

		return widget
	end
end

local function ImportWidget(className)
	local typeInfo = ptr_typeof(className)

	if typeInfo then
		local ctor = typeInfo:GetConstructor()

		return function(id)
			if type(id) == "table" then
				return WidgetConstructor(ctor, nil, id)
			else
				return function (t)
					return WidgetConstructor(ctor, id, t)
				end
			end
		end
	else
		error("can not import widget:" .. className)
	end
end

local function ImportSkin(className)
	local ctor = class.import(className)

	if ctor then
		return function(id)
			if type(id) == "table" then
				return ctor(id)
			else
				return function (t)
					local skin = ctor(t)
					skins[id] = skin
					return skin
				end
			end
		end
	else
		error("can not import skin:" .. className)
	end
end

local function ApplyStyle(widget, style)
	local tb = styles[style]

	-- to original type
	widget = ptr_cast(widget)

	if tb then
		for attr, value in pairs(tb) do
			widget[attr] = value
		end
	end
end

function Create(parent, vars)
	vars = vars or {}

	if type(parent) == "table" then
		for id, creator in ipairs(parent) do
			creator(gui, vars)
		end
	else
		return function (t)
			for id, creator in ipairs(t) do
				creator(parent, vars)
			end
			return vars
		end
	end

	return vars
end

function Clear(parent)
	if type(parent) == "table" then
		for id, ui in ipairs(parent) do
			ui.Parent = nil
		end
	else
		if parent then
			while parent.FirstChild do
				parent.FirstChild.Parent = nil
			end
		end
	end
end

function Style(name)
	return function(t)
		styles[name] = t
	end
end

function Align(control, px, py)
	if control and control.Parent then
		local cs = control.Size
		local ps = control.Parent.Size

		local mx = ps.x - cs.x
		local my = ps.y - cs.y

		if px < 0 then
			if px < -1 then px = mx + px
			else px = mx - mx * px end
		end

		if px > 0 then
			if px > 1 then px = px
			else px = mx * px end
		end

		if py < 0 then
			if py < -1 then py = my + py
			else py = my - my * py end
		end

		if py > 0 then
			if py > 1 then py = py
			else py = my * py end
		end

		px = math.floor(px)
		py = math.floor(py)

		local win = ptr_cast(control, "Gui.Window")

		if win then
			win.WorldLocation = Vector3(px, py, 0)
		else
			control.Location = Vector2(px, py)
		end
	end
end


function gui.EventControlStyleChanged(sender, e)
	ApplyStyle(e.control, e.style)
end

-- objects
--Image = class.import("Gui.Image")
Image = class.import("Gui.Image")
Icon = class.import("Gui.Icon")
ProportionIcon = class.import("Gui.ProportionIcon")
CompareIcon = class.import("Gui.CompareIcon")
ComplexImage = class.import("Gui.ComplexImage")
AnimatedImage = class.import("Gui.AnimatedImage")

-- skins
ControlSkin = ImportSkin("Gui.ControlSkin")
ButtonSkin = ImportSkin("Gui.ButtonSkin")
ShaderButtonSkin = ImportSkin("Gui.ShaderButtonSkin")
CheckBoxSkin = ImportSkin("Gui.CheckBoxSkin")
TextboxSkin = ImportSkin("Gui.TextboxSkin")
ScrollableControlSkin = ImportSkin("Gui.ScrollableControlSkin")
TextAreaSkin = ImportSkin("Gui.TextAreaSkin")
ComboBoxSkin = ImportSkin("Gui.ComboBoxSkin")
ComboListSkin = ImportSkin("Gui.ComboListSkin")
TabpadSkin = ImportSkin("Gui.TabpadSkin")
SliderSkin = ImportSkin("Gui.SliderSkin")
CalendarSkin = ImportSkin("Gui.CalendarSkin")
ListItemSkin = ImportSkin("Gui.ListItemSkin")
ListTreeViewSkin = ImportSkin("Gui.ListTreeViewSkin")
HeaderSkin = ImportSkin("Gui.HeaderSkin")
PageBarSkin = ImportSkin("Gui.PageBarSkin")
ItemBoxSkin = ImportSkin("Gui.ItemBoxSkin")
ItemBoxBtnSkin = ImportSkin("Gui.ItemBoxBtnSkin")
PictureSkin = ImportSkin("Gui.PictureSkin")
ItemPictureSkin = ImportSkin("Gui.ItemPictureSkin")
MenuSkin = ImportSkin("Gui.MenuSkin")
LobbyMainButtonSkin = ImportSkin("Gui.LobbyMainButtonSkin")
InGameMainButtonSkin = ImportSkin("Gui.InGameMainButtonSkin")
SquadBlockSkin = ImportSkin("Gui.SquadBlockSkin")
ChartSkin = ImportSkin("Gui.ChartSkin")
BalloonSkin = ImportSkin("Gui.BalloonSkin")
TooltipSkin = ImportSkin("Gui.TooltipSkin")
MutexControlSkin = ImportSkin("Gui.MutexControlSkin")
MailItemSkin = ImportSkin("Gui.MailItemSkin")
ShaderSkin = ImportSkin("Gui.ShaderSkin")

-- controls
Window = ImportWidget("Gui.Window")
Control = ImportWidget("Gui.Control")
ScrollNumberButton = ImportWidget("Gui.ScrollNumberButton")
ScrollableControl = ImportWidget("Gui.ScrollableControl")
Label = ImportWidget("Gui.Label")
DragLabel = ImportWidget("Gui.DragLabel")
ProportionBar = ImportWidget("Gui.ProportionBar")
ExperienceBar = ImportWidget("Gui.ExperienceBar")
CompareBar = ImportWidget("Gui.CompareBar")
Picture = ImportWidget("Gui.Picture")
Button = ImportWidget("Gui.Button")
Textbox = ImportWidget("Gui.Textbox")
TextArea = ImportWidget("Gui.TextArea")
CheckBox = ImportWidget("Gui.CheckBox")
RadioButton = ImportWidget("Gui.RadioButton")
RadioGroup = ImportWidget("Gui.RadioGroup")
Slider = ImportWidget("Gui.Slider")
ComboBox = ImportWidget("Gui.ComboBox")
Header = ImportWidget("Gui.Header")
ListItem = ImportWidget("Gui.ListItem")
ListTreeView = ImportWidget("Gui.ListTreeView")
ListTreeViewSPA = ImportWidget("Gui.ListTreeViewSPA")
FlowLayout = ImportWidget("Gui.FlowLayout")
Tabpad = ImportWidget("Gui.Tabpad")
MessagePanel = ImportWidget("Gui.MessagePanel")
Tabpage = ImportWidget("Gui.Tabpage")
PageBar = ImportWidget("Gui.PageBar")
ItemBox = ImportWidget("Gui.ItemBox")
ItemBoxBtn = ImportWidget("Gui.ItemBoxBtn")
ItemPicture = ImportWidget("Gui.ItemPicture")
ChatWindow = ImportWidget("Gui.ChatWindow")
SysMessageBar = ImportWidget("Gui.SysMessageBar")
PdePropertyItem=ImportWidget("Gui.PdePropertyItem")
PropertyGrid=ImportWidget("Gui.PropertyGrid")
PropertyView=ImportWidget("Gui.PropertyView")
ComboList = ImportWidget("Gui.ComboList")
ImageBrowser =ImportWidget("Gui.ImageBrowser")
SplineView =ImportWidget("Gui.SplineView")
AttributePlate = ImportWidget("Gui.AttributePlate")
WindowUI = ImportWidget("Gui.WindowUI")
FadingWindowUI = ImportWidget("Gui.FadingWindowUI")
TimerWindowUI = ImportWidget("Gui.TimerWindowUI")
PagedWindowUI = ImportWidget("Gui.PagedWindowUI")
LobbyMainButton = ImportWidget("Gui.LobbyMainButton")
InGameMainButton = ImportWidget("Gui.InGameMainButton")
ModalControl = ImportWidget("Gui.ModalControl")
SquadBlock = ImportWidget("Gui.SquadBlock")
SquadPanel = ImportWidget("Gui.SquadPanel")
LobbyPList = ImportWidget("Gui.LobbyPList")
Chart = ImportWidget("Gui.Chart")
Balloon = ImportWidget("Gui.Balloon")
MutexControl = ImportWidget("Gui.MutexControl")
Menu = ImportWidget("Gui.Menu")
KeyBox = ImportWidget("Gui.KeyBox")
TimeControl = ImportWidget("Gui.TimeControl")
Calendar = ImportWidget("Gui.Calendar")
OtherPortrait = ImportWidget("Gui.OtherPortrait")
CharacterViewer = ImportWidget("Gui.CharacterViewer")
MailItem = ImportWidget("Gui.MailItem")
AnimControl = ImportWidget("Gui.AnimControl")
RichEdit = ImportWidget("Gui.RichEdit")
ShaderControl = ImportWidget("Gui.ShaderControl")
ShaderButton = ImportWidget("Gui.ShaderButton")
FlashControl = ImportWidget("Gui.FlashControl")
ButtonList = ImportWidget("Gui.ButtonList")
ChangeControl = ImportWidget("Gui.ChangeControl")
MouseControl = ImportWidget("Gui.MouseControl")