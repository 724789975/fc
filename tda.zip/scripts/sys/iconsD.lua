module("Icons", package.seeall)

RoomStatusIcons =
{
	PlayingN = Gui.Icon("DefaultSkin/DefaultSkin_common_icon01_normal.dds"),
	PlayingA = Gui.Icon("DefaultSkin/DefaultSkin_common_icon01_hover.dds"),
	WaitingN = Gui.Icon("DefaultSkin/DefaultSkin_common_icon02_normal.dds"),
	WaitingA = Gui.Icon("DefaultSkin/DefaultSkin_common_icon02_hover.dds"),
	FullN = Gui.Icon("DefaultSkin/DefaultSkin_common_icon03_normal.dds"),
	FullA = Gui.Icon("DefaultSkin/DefaultSkin_common_icon03_hover.dds"),
	PasswordN = Gui.Icon("DefaultSkin/DefaultSkin_common_icon04_normal.dds"),
	PasswordA = Gui.Icon("DefaultSkin/DefaultSkin_common_icon04_hover.dds"),
	VipRoom = Gui.Icon("LobbyUI/vip/lb_vip_ico4.dds"),
	XunLeiVipRoom = Gui.Icon("LobbyUI/vip/lb_vip_xunlei_ico4.dds"),
}

PlayerStatusIcons =
{
	Host = Gui.Icon("LobbyUI/lb_battlefield_icon_host.dds"),
	ReadyN = Gui.Icon("LobbyUI/WarZone/lb_battlefield_icon01_ready.dds"),
	ReadyA = Gui.Icon("LobbyUI/WarZone/lb_battlefield_icon01_ready.dds"),
	PlayingN = Gui.Icon("DefaultSkin/DefaultSkin_room_icon17.tga"),
	PlayingA = Gui.Icon("DefaultSkin/DefaultSkin_room_icon17.tga"),
	PlayingC = Gui.Icon("LobbyUI/WarZone/lb_battlefield_icon_play.dds"),
	Close	=Gui.Icon("LobbyUI/WarZone/lb_room_closed_bg.dds"),
	CloseHover =Gui.Icon("LobbyUI/WarZone/lb_room_closed_bg_hover.dds"),
	WatchPlayingA = Gui.Icon("LobbyUI/WarZone/lb_room_spectator_bg.dds"),
	WatchPlayingHover = Gui.Icon("LobbyUI/WarZone/lb_room_spectator_bg_hover.dds"),
	WatchPlayingB = Gui.Icon("LobbyUI/WarZone/lb_battlefield_icon01_spectator.dds"),
	Head = Gui.Icon("LobbyUI/WarZone/lb_battlefield_icon02_01.dds"),	
	Vip = Gui.Icon("LobbyUI/vip/lb_1_ico_0_big.dds"),
	XunLeiVip = Gui.Icon("LobbyUI/vip/lb_2_ico_0_big.dds"),
	VipSmall = Gui.Icon("LobbyUI/vip/lb_1_ico_0.dds"),
	XunLeiVipSmall = Gui.Icon("LobbyUI/vip/lb_2_ico_0.dds"),
}

--[[
PreviewMaps =
{
	testmapb_out	= Gui.Image("MapsAndBG/previewMaps/skinC_smallmap_testmapb.tga",Vector4(0,0,0,0)),
	testmapb	= Gui.Image("MapsAndBG/previewMaps/skinC_smallmap_testmapb.tga",Vector4(0,0,0,0)),
	
	level_random= Gui.Image("MapsAndBG/MapsIcon/battlefield_map_random.tga",Vector4(0,0,0,0)),
	
	level1_cp_out = Gui.Image("MapsAndBG/MapsIcon/lb_battlefield_map_lv01_b.dds",Vector4(0,0,0,0)),
	level1_td_out = Gui.Image("MapsAndBG/MapsIcon/lb_battlefield_map_lv01_b.dds",Vector4(0,0,0,0)),
	
	level1_cp = Gui.Image("MapsAndBG/MapsIcon/lb_battlefield_map_lv01_s_normal.dds",Vector4(0,0,0,0)),
	level1_td = Gui.Image("MapsAndBG/MapsIcon/lb_battlefield_map_lv01_s_normal.dds",Vector4(0,0,0,0)),
	
	level2_td = Gui.Image("MapsAndBG/MapsIcon/battlefield_map_lv2.dds",Vector4(0,0,0,0)),
	level2_td_out = Gui.Image("MapsAndBG/MapsIcon/lb_battlefield_map_lv02_b.dds",Vector4(0,0,0,0)),
	
	level2_cp = Gui.Image("MapsAndBG/MapsIcon/battlefield_map_lv2.dds",Vector4(0,0,0,0)),
	level2_cp_out = Gui.Image("MapsAndBG/MapsIcon/lb_battlefield_map_lv02_b.dds",Vector4(0,0,0,0)),
	
	level3_cp = Gui.Image("MapsAndBG/MapsIcon/battlefield_map_lv3.dds",Vector4(0,0,0,0)),
	level3_cp_out = Gui.Image("MapsAndBG/MapsIcon/lb_battlefield_map_lv03_b.dds",Vector4(0,0,0,0)),
	
	level3_td = Gui.Image("MapsAndBG/MapsIcon/battlefield_map_lv3.dds",Vector4(0,0,0,0)),
	level3_td_out = Gui.Image("MapsAndBG/MapsIcon/lb_battlefield_map_lv03_b.dds",Vector4(0,0,0,0)),
	
	level4_pl	= Gui.Image("MapsAndBG/MapsIcon/battlefield_map_lv4.dds",Vector4(0,0,0,0)),
	level4_pl_out	= Gui.Image("MapsAndBG/MapsIcon/lb_battlefield_map_lv04_b.dds",Vector4(0,0,0,0)),
	
	level13_pl	= Gui.Image("MapsAndBG/MapsIcon/battlefield_map_lv13.dds",Vector4(0,0,0,0)),
	level13_pl_out	= Gui.Image("MapsAndBG/MapsIcon/lb_battlefield_map_lv13_b.dds",Vector4(0,0,0,0)),
	
	level5_pl	= Gui.Image("MapsAndBG/MapsIcon/battlefield_map_lv5.dds",Vector4(0,0,0,0)),
	level5_pl_out	= Gui.Image("MapsAndBG/MapsIcon/lb_battlefield_map_lv05_b.dds",Vector4(0,0,0,0)),
	
	level6_bo      = Gui.Image("MapsAndBG/MapsIcon/battlefield_map_lv6.dds",Vector4(0,0,0,0)),
	level6_bo_out  = Gui.Image("MapsAndBG/MapsIcon/lb_battlefield_map_lv06_b.dds",Vector4(0,0,0,0)),
	
	level7_td =   Gui.Image("MapsAndBG/MapsIcon/battlefield_map_lv7.dds",Vector4(0,0,0,0)),
	level7_td_out = Gui.Image("MapsAndBG/MapsIcon/lb_battlefield_map_lv07_b.dds",Vector4(0,0,0,0)),
	
	level7_wo		= Gui.Image("MapsAndBG/MapsIcon/battlefield_map_lv7.dds",Vector4(0,0,0,0)),
	level7_wo_out = Gui.Image("MapsAndBG/MapsIcon/lb_battlefield_map_lv07_b.dds",Vector4(0,0,0,0)),

	level8_td = Gui.Image("MapsAndBG/MapsIcon/battlefield_map_lv1.dds",Vector4(0,0,0,0)),
	level8_td_out = Gui.Image("MapsAndBG/MapsIcon/lb_battlefield_map_lv08_b.dds",Vector4(0,0,0,0)),
	
	level9_wo = Gui.Image("MapsAndBG/MapsIcon/battlefield_map_lv9.dds",Vector4(0,0,0,0)),
	level9_wo_out = Gui.Image("MapsAndBG/MapsIcon/lb_battlefield_map_lv09_b.dds",Vector4(0,0,0,0)),
	
	level0_pl		= Gui.Image("MapsAndBG/previewMaps/skinC_smallmap_level7.tga",Vector4(0,0,0,0)),
	level0_cp		= Gui.Image("MapsAndBG/previewMaps/skinC_smallmap_level7.tga",Vector4(0,0,0,0)),
	level0_td		= Gui.Image("MapsAndBG/previewMaps/skinC_smallmap_level7.tga",Vector4(0,0,0,0)),
	level0_bo		= Gui.Image("MapsAndBG/previewMaps/skinC_smallmap_level7.tga",Vector4(0,0,0,0)),
	level0_bo_out = Gui.Image("MapsAndBG/previewMaps/skinC_smallmap_level7.tga",Vector4(0,0,0,0)),
	level0_pl_out	= Gui.Image("MapsAndBG/previewMaps/skinC_smallmap_level7.tga",Vector4(0,0,0,0)),
	level0_cp_out	= Gui.Image("MapsAndBG/previewMaps/skinC_smallmap_level7.tga",Vector4(0,0,0,0)),
	level0_knife		= Gui.Image("MapsAndBG/previewMaps/skinC_smallmap_level7.tga",Vector4(0,0,0,0)),
	level0_knife_out = Gui.Image("MapsAndBG/previewMaps/skinC_smallmap_level7.tga",Vector4(0,0,0,0)),
	level10_knife = Gui.Image("MapsAndBG/MapsIcon/battlefield_map_lv10.dds",Vector4(0,0,0,0)),
	level10_knife_out = Gui.Image("MapsAndBG/MapsIcon/lb_battlefield_map_lv10_b.dds",Vector4(0,0,0,0)),
	
	level11_td		= Gui.Image("MapsAndBG/MapsIcon/battlefield_map_lv11.dds",Vector4(0,0,0,0)),
	level11_td_out	= Gui.Image("MapsAndBG/MapsIcon/lb_battlefield_map_lv11_b.dds",Vector4(0,0,0,0)),
	
	level12_td		= Gui.Image("MapsAndBG/previewMaps/skinC_smallmap_level12.tga",Vector4(0,0,0,0)),
	level12_td_out	= Gui.Image("MapsAndBG/previewMaps/skinC_smallmap_level12.tga",Vector4(0,0,0,0)),
	
	level_bo	= Gui.Image("MapsAndBG/previewMaps/skinC_smallmap_level_bo_test.tga",Vector4(0,0,0,0)),
	level_bo_out	= Gui.Image("MapsAndBG/previewMaps/skinC_smallmap_level_bo_test.tga",Vector4(0,0,0,0)),
	
	level_bo2	= Gui.Image("MapsAndBG/previewMaps/skinC_smallmap_level_bo2_test.tga",Vector4(0,0,0,0)),
	level_bo2_out	= Gui.Image("MapsAndBG/previewMaps/skinC_smallmap_level_bo2_test.tga",Vector4(0,0,0,0)),
}
]]

PlayerRankingIconsNum =
{
}

for level = 1, 10 do
	PlayerRankingIconsNum[level] = Gui.Icon("LobbyUI/WarZone/lb_summary_number_7b.dds",Vector4(0,0,0,0),Vector4((level-1)/10,0,(level)/10,1))
end

PlayerRankingIconsBalance =
{
}

for level = 1, 10 do
	PlayerRankingIconsBalance[level] = Gui.Icon("LobbyUI/WarZone/lb_summary_number_7.dds",Vector4(0,0,0,0),Vector4((level-1)/10,0,(level)/10,1))
end

PlayerRankingIconsNumBK =
{
}

for level = 1, 10 do
	PlayerRankingIconsNumBK[level] = Gui.Icon("LobbyUI/WarZone/lb_summary_number_7.dds",Vector4(0,0,0,0),Vector4((level-1)/10,0,(level)/10,1))
end


function GetWeaponIcon(weaponName)
	if not weaponName then
		print("Error: weapon name not valid")
		return nil
	end
	return Gui.Icon("ItemIcons/weapons/skinC_"..weaponName..".tga")
	--return Gui.Icon("output/skinC_"..weaponName..".dds")
end

function GetWeaponComponentIcon(weaponName)
	if not weaponName then
		print("Error: weapon component name not valid")
		return nil
	end
	return Gui.Icon("ItemIcons/weapons/skinC_"..weaponName..".tga")
end

local AvatarPath = { {M="G_M_", F="G_W_",}, {M="P_M_", F="P_W_",}, {M="GP_M_", F="GP_W_",},}
function GetAvatarIcon(itemName, side)
	if not itemName then
		return nil
	end
	if not side then
		return nil
	end
	return Gui.Icon("ItemIcons/avatars/"..AvatarPath[side+1]..itemName..".tga")
end

function GetPropertyIcon(itemName)
	if not itemName then
		print("Error: item name not valid")
		return nil
	end
	return Gui.Icon("ItemIcons/properties/"..itemName..".tga")
end

--[[local ModeIDTable = 
{
	kTeam = 1,
	kHoldPoint = 2,
	kPushVehicle = 3,
	kTeamDeathMatch = 4,
	kKnife = 6,
}]]

function GetLoadingMap(mapName, modeName)
	if not mapName then
		print("Error: map name not valid")
		return nil
	end
	--[[if (not modeName) or (not ModeIDTable[modeName]) then
		print("Error: mode name not valid")
		return nil
	end]]
	return Gui.Image(string.format("MapsAndBG/Loading/loadingmap_%s.dds", mapName))
end

function GetTeamLogo(logoName)
	local index = tonumber(logoName)
	if index and index >0 and index < 6 then
		return TeamLogos[index]
	else
		return TeamLogos[1]
	end
end
