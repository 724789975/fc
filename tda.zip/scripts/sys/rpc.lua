module("rpc", package.seeall)
debug = false

local debug_count = 0
--rpc class
----1: normal request which will not be ignored
----2: nil
----3: item list
----4: character_avatar
----5: weapon_avatar
----6: friends list
----7: mail list
----8: modgun item list
----9: bag item list
local rpc_maxclass = 9

--rpc api
local rpc_api = game.RpcCall
local rpc_queue = {}
local rpc_inclass = {}
local rpc_current = nil

local function rpc_api_test(_, name, args, callback)
	Task.Schedule(function()
		local file = io.open("/rpc_test/"..name, "r")
		local result = nil
		local err = nil

		if file then
			result = file:read("*a")
			file:close()
		else
			err = "error open file"
		end

		callback(result, err)
	end, 0.1)

	return true
end

-- function declare
local rpc_new
local rpc_update
local rpc_completed


-- function define
function rpc_completed(buff, err)
	local callback = nil
	if rpc_current then
		callback = rpc_current.callback
		rpc_current = nil
	end

	rpc_update()

	if callback then
		callback(buff, err)
	end
end

function rpc_update()
	if not rpc_current then
		rpc_current = rpc_queue[1]

		if rpc_current then
			if rpc_current.api(game, rpc_current.name, rpc_current.args, rpc_completed) then
				table.remove(rpc_queue, 1)
			else
				rpc_current = nil
			end
		else
			local i = 2
			while (not rpc_current) and i<=rpc_maxclass do
				rpc_current = rpc_inclass[i]
				i = i+1
			end

			if rpc_current then
				if rpc_current.api(game, rpc_current.name, rpc_current.args, rpc_completed) then
					rpc_inclass[i-1]=nil
				else
					rpc_current = nil
				end
			end
		end
	else
		if rpc_current.class ~= 1 then
			if rpc_inclass[rpc_current.class] then
				rpc_current.callback = nil		--disable the callback function for ignored task
			end
		end
	end
end

function rpc_new(name, args, callback, class, api)
	assert(type(name) == "string")

	rpc_args = {}
	if type(args) == "table" then
		for k, v in pairs(args) do
			if type(k) == "string" then
				rpc_args[k] = tostring(v)
			end
		end
	end

	local t =
	{
		name = name,
		callback = callback,
		args = rpc_args,
		api = api,
		class = class or 1,
	}
	--print("########***********############:"..t.name)
	--print("########***********############:"..t.class)

	if t.class == 1 then
		table.insert(rpc_queue, t)
	else
		rpc_inclass[class]=t
	end

	rpc_update()

	return t
end

function call(name, args, callback, class)
	if debug then
		local args_table = {}
		local args_str = "nil"
		if type(args) == "table" then
			table.foreach(args,
			function(k,v)
				if type(v) == "string" then
					args_table[#args_table + 1] = k.." = \""..v.."\""
				else
					args_table[#args_table + 1] = k.." = "..v
				end
			end)
			args_str = table.concat(args_table,",")
			args_str = "{"..args_str.."}"
		end
		local test_code = "rpc.safecall(\""..name.."\"\,"..args_str..",function(data) end)"
		debug_count = debug_count + 1
		print("test_code "..debug_count.."	:"..test_code)
		console.Text = test_code
	end
	return rpc_new(name, args, callback, class, rpc_api)
end

function clear()
	rpc_queue = {}
	rpc_inclass = {}
	if rpc_current then
		rpc_current = nil
	end
end

function cancel(rpc_struct)
	--print("########***********############: canceling a task")

	if not rpc_struct then
		return
	end

	--print("########***********############: canceling"..rpc_struct.name)


	--Cancel the running task
	if rpc_struct == rpc_current then
		--print("########***********############: canceling current task")

		rpc_current.callback = nil
		return
	end

	--Cancel class 1 task
	found = -1
	for i = 1, #rpc_queue, 1 do
		if rpc_struct == rpc_queue[i] then
			found = i
		end
	end
	if found>0 then
		--print("########***********############: canceling class 1 task")

		table.remove(rpc_queue, found)
		return
	end

	--Cancel other class task
	for i=2, rpc_maxclass, 1 do
		if rpc_struct == rpc_inclass[i] then
			--print("########***********############: canceling class:"..i)

			rpc_inclass[i] = nil
		end
	end
end


function test_call(name, args, callback, class)
	rpc_new(name, args, callback, class, rpc_api_test)
end

function load_result(result, env)
	if debug then
		if debug == 2 then
			print(result)
		end
		local file = io.open("d:\\result.lua","w+")
		if file then
		   file:write(result)
		   file:close()
		end
	end
	env = env or {}
	local func, err = loadin(env, result)

	if func then
		func, err = pcall(func)
	end

	if func then
		if env.error == nil then
			return env
		else
			return env, tostring(env.error)
		end
	else
		return nil, err
	end
end

function ErrorHandler(callback, callbackfailed)
	return function(result ,err)
		if result then
		local data, load_err = load_result(result)
			if data then
				if data.error then
					if callbackfailed then
						callbackfailed()
					end
					MessageBox.CloseWaiter()
					L_MessageBox.CloseWaiter()
					if data.error == "need input second password" then
						L_SecondCode.Show_SecondCodeConfirm()
					else
						MessageBox.ShowError(data.error)
					end
					gui:PlayAudio("kUIA_CONFIRM_MESSAGE")
				else
					if callback then
						local status, call_err = pcall(callback, data)
						if not status then
							if callbackfailed then
								callbackfailed()
							end
							if debug then
								print("call_err",call_err)
							else
								MessageBox.CloseWaiter()
								L_MessageBox.CloseWaiter()
								MessageBox.Show(lang:GetText("数据处理错误!"),lang:GetText("确定"),function(sender,e) game:LogoutAccount() end)
							end
						end
					end
				end
			else
				if callbackfailed then
					callbackfailed()
				end
				if debug then
					print("load_err",load_err)
				else
					MessageBox.CloseWaiter()
					L_MessageBox.CloseWaiter()
					MessageBox.Show(lang:GetText("加载数据失败!"),lang:GetText("确定"),function(sender,e) game:LogoutAccount() end)
				end
			end
		else
			if callbackfailed then
				callbackfailed()
			end
			if debug then
				print("err",err)
			else
				MessageBox.CloseWaiter()
				L_MessageBox.CloseWaiter()
				MessageBox.Show(lang:GetText("访问数据失败!"),lang:GetText("确定"),function(sender,e) game:LogoutAccount()end)
			end
		end
	end
end

function ErrorHandlerLoad(callback, callbackfailed)
	return function(result ,err)
		if result then
		local data, load_err = load_result(result)
			if data then
				if data.error then
					if callbackfailed then
						callbackfailed()
					end
					MessageBox.CloseWaiter()
					L_MessageBox.CloseWaiter()
					L_Loading.Hide()
					if data.error == "need input second password" then
						L_SecondCode.Show_SecondCodeConfirm()
					else
						MessageBox.ShowError(data.error)
					end
				else
					if callback then
						local status, call_err = pcall(callback, data)
						if not status then
							if callbackfailed then
								callbackfailed()
							end
							if debug then
								print("call_err",call_err)
							else
								MessageBox.CloseWaiter()
								L_MessageBox.CloseWaiter()
								L_Loading.Hide()
								MessageBox.Show(lang:GetText("数据处理错误!"),lang:GetText("确定"),function(sender,e) game:LogoutAccount() end)
							end
						else
							L_Loading.HideToTime()
						end
					end
				end
			else
				if callbackfailed then
					callbackfailed()
				end
				if debug then
					print("load_err",load_err)
				else
					MessageBox.CloseWaiter()
					L_MessageBox.CloseWaiter()
					MessageBox.Show(lang:GetText("加载数据失败!"),lang:GetText("确定"),function(sender,e) game:LogoutAccount() end)
				end
				L_Loading.Hide()
			end
		else
			if callbackfailed then
				callbackfailed()
			end
			if debug then
				print("err",err)
			else
				MessageBox.CloseWaiter()
				L_MessageBox.CloseWaiter()
				MessageBox.Show(lang:GetText("访问数据失败!"),lang:GetText("确定"),function(sender,e) game:LogoutAccount()end)
			end
			L_Loading.Hide()
		end
	end
end

function safecall(name, args, callback, callbackfailed, class)
	call(name, args, ErrorHandler(callback, callbackfailed), class)
end

function safecallload(name, args, callback, callbackfailed, class)
	L_Loading.Hide()
	L_Loading.Show()
	call(name, args, ErrorHandlerLoad(callback, callbackfailed), class)
end

function load_avatar(team, avata)
	local info = ptr_new "Client.CharacterInfo"
	info.team = team

	for _, i in ipairs(avata) do
		if i ~= "" then
			info:AddPart(i)
		end
	end
	return info
end

function new_load_avatar(team, avata)
	for _, i in ipairs(avata) do
		lg:SetAvatarPart(team, i, false)
	end

end

local weapon_types =
{
	[1] = "Client.PistolInfo",
	[2] = "Client.SubMachineGunInfo",
	[3] = "Client.RifleInfo",
	[4] = "Client.SniperGunInfo",
	[5] = "Client.ShotGunInfo",
	[6] = "Client.MachineGunInfo",
	[10] = "Client.KnifeInfo",
	[20] = "Client.GrenadeInfo",
	[21] = "Client.FlashInfo",
	[22] = "Client.SmokeInfo",
	[30] = "Client.BombInfo",
}

function load_weapon(weapon_info)
	local weapon_type = weapon_types[weapon_info.type]
	if weapon_type then
		local info = ptr_new(weapon_type)
		if info then
			for _, i in ipairs(weapon_info) do
				info:AddPart(i)
			end

			return info
		end
	end
	return nil
end

function get_real_result(result)
	if type(result) == "table" then
		table.foreach(result, function(i, v)
			if type(v) == "string" and string.find(v, "|") == 1 then
				result[i] = translate(result[i])
			elseif type(v) == "table" then
				get_real_result(result[i])
			end
		end)
	end
end

function translate(temp)	
	local TABLE = Split(temp, ",")
	local TABLE1 = Split(lang:GetText(TABLE[2]), "|")
	local str = ""
	for i = 1, #TABLE1 do
		if TABLE[i + 3] then
			str = str..TABLE1[i]..TABLE[i + 3]
		else
			str = str..TABLE1[i]
		end
	end
	return str
end

function Split(szFullString, szSeparator)
	local nFindStartIndex = 1
	local nSplitIndex = 1
	local nSplitArray = {}
	while true do
	   local nFindLastIndex = string.find(szFullString, szSeparator,nFindStartIndex)
	   if not nFindLastIndex then
		nSplitArray[nSplitIndex] = string.sub(szFullString, nFindStartIndex, string.len(szFullString))
		break
	   end
	   nSplitArray[nSplitIndex] = string.sub(szFullString, nFindStartIndex, nFindLastIndex - 1)
	   nFindStartIndex = nFindLastIndex + string.len(szSeparator)
	   nSplitIndex = nSplitIndex + 1
	end
	return nSplitArray
end