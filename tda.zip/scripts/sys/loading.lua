module("L_Loading",package.seeall)

ui = Gui.Create()
{
	Gui.AnimControl "loading_picture"
	{
		Size = Vector2(128,200),
		BackgroundColor = ARGB(0, 255, 255, 255),			
		Location = Vector2(0,380),
		EventFinish = function(Sender,e)
			ui.loading_picture:ReStart()
		end,
		
		EventTimeHide = function(Sender,e)
			Hide()
		end,
	},
}

local modal_win = nil

function Show()
	modal_win = ModalWindow.GetNew("loading")
	modal_win.root.Size = Vector2(128,600)
	modal_win.screen.AllowEscToExit = false
	
	ui.loading_picture:AddAnim("frame",0.1,1)
	for i = 1, 12 do
		local frame = Gui.Image("LobbyUI/loading_missile.dds", Vector4(0, 0, 0, 0),Vector4((i-1)/12,0,i/12,1))
		ui.loading_picture:AddFrame("frame",frame)
	end	
	ui.loading_picture:ReStart()
	ui.loading_picture:StartAnimation()
	
	ui.loading_picture.Parent = modal_win.root
	modal_win.root.BackgroundColor = ARGB(0, 255, 255, 255)
	
	return modal_win
end

function Hide()
    if modal_win then
		ui.loading_picture:ClearAll()
		modal_win.Close()
		modal_win = nil
	end
end

function HideToTime()
    if ui.loading_picture then
		ui.loading_picture:TimeToHide()
	end
end