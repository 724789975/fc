require "sys/all.lua"
local state = ptr_cast(game.CurrentState)

function CreateBtn(m_Parent)
	local btn = Gui.Create()
	{
		Gui.Button "AAAAAA"
		{
			Size = Vector2(120, 60),
			Location = Vector2(5, 4),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_06_normal.dds", Vector4(0, 0, 0, 0)),
				HoverImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_06_hover.dds", Vector4(0, 0, 0, 0)),
				DownImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_06_down.dds", Vector4(0, 0, 0, 0)),
				DisabledImage = Gui.Image("LobbyUI/team/NewFight/lb_squad_button_06_normal.dds", Vector4(0, 0, 0, 0)),
			},
			EventClick = function()
				state = ptr_cast(game.CurrentState)
			end	
		},
	}
	btn.AAAAAA.Parent = m_Parent
end

LogoWindow = Gui.Create()
{
	Gui.Control "logo_window"
	{
		Size = Vector2(1280, 960),
		Dock = "kDockCenter",
		BackgroundColor = ARGB(255, 255, 255, 255),	
	},
}

state.EventInit = function()
	LogoWindow.logo_window.Parent = gui
	CreateBtn(LogoWindow.logo_window)
end

state.EventLeave = function()
	LogoWindow.logo_window.Parent = nil
	LogoWindow = nil
end

state.EventTest = function()
	CreateBtn(LogoWindow.logo_window)
end