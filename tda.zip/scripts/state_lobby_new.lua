require "lobby_new/LobbyMain.lua"
require "lobby_new/Characters_tab.lua"
require "lobby_new/ToolTips.lua"
require "lobby_new/BlackMarket.lua"
require "lobby_new/Characters.lua"
require "lobby_new/Chat.lua"
require "lobby_new/Compose.lua"
require "lobby_new/FightTeam.lua"
require "lobby_new/Friends.lua"
require "lobby_new/Mail.lua"
require "lobby_new/MainMenu.lua"
require "lobby_new/Options.lua"
require "lobby_new/ShoppingMall.lua"
require "lobby_new/TopList.lua"
require "lobby_new/WarZone.lua"
require "lobby_new/Present.lua"
require "lobby_new/PasswordBox.lua"
require "lobby_new/PushCmd.lua"
require "lobby_new/PersonalInfo.lua"
require "lobby_new/Mission.lua"
require "game_boss_balance.lua"
require "lobby_new/dailyCheck.lua"
require "lobby_new/Characters_manage.lua"
require "lobby_new/Compose.lua"
require "lobby_new/FreeChangeShop.lua"
require "lobby_new/Shooting.lua"
require "lobby_new/TimeSell.lua"
require "lobby_new/SecondCode.lua"
require "lobby_new/Vip.lua"
require "lobby_new/LevelUPEffect.lua"
require "lobby_new/placeLevelUp.lua"	--空间升级界面
require "lobby_new/FightTeamFAQ.lua"

window_state = window_state or {}

local state = ptr_cast(game.CurrentState)

local escWindow = nil
local WebWindow = nil
local Quitmodal = nil
--local Meirimodal = nil
local redio_id = 1
local ReportWindow = nil
local Report_name = nil

local sum = nil
WebWin = Gui.Create()
{
	Gui.Control "web_Window"
	{	
		Size = Vector2(606, 451),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Location = Vector2(0, 0),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("faq/lb_contact_bg1.dds", Vector4(25, 25, 25, 25)),
		},
		
		Gui.Control "bg_1"
		{
			Size = Vector2(586,431),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Location = Vector2(10, 10),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("faq/lb_contact_bg2.dds", Vector4(16, 12, 16, 45)),
			},
				
			Gui.Label "biaoti"
			{
				Size = Vector2(127, 25),
				Location = Vector2(5, 109),
				Text = lang:GetText("*标题:"),
				TextAlign = "kAlignRightMiddle",
				FontSize = 14,
				TextColor = ARGB(255, 37, 37, 37),
			},
			
			Gui.Textbox "biaoti_box"
			{
				Size = Vector2(429, 25),
				Location = Vector2(140, 109),
				Text = "",
				TextColor = ARGB(255, 37, 37, 37),
				BackgroundColor = ARGB(255, 255, 255, 255),
				FontSize = 14,
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("faq/lb_chat_bg4_normal.tga", Vector4(8, 8, 8, 8)),
				},
				MaxLength = 50,
			},
			
			Gui.Label "qhao"
			{
				Size = Vector2(127, 25),
				Location = Vector2(5, 139),
				Text = lang:GetText("q号:"),
				TextAlign = "kAlignRightMiddle",
				FontSize = 14,
				TextColor = ARGB(255, 37, 37, 37),
			},
			
			Gui.Textbox "qhao_box"
			{
				Size = Vector2(163, 25),
				Location = Vector2(140, 139),
				Text = "",
				TextColor = ARGB(255, 37, 37, 37),
				BackgroundColor = ARGB(255, 255, 255, 255),
				FontSize = 14,
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("faq/lb_chat_bg4_normal.tga", Vector4(8, 8, 8, 8)),
				},
				MaxLength = 20,
			},
			
			Gui.Label "shouji"
			{
				Size = Vector2(87, 25),
				Location = Vector2(310, 139),
				Text = lang:GetText("手机号:"),
				TextAlign = "kAlignRightMiddle",
				FontSize = 14,
				TextColor = ARGB(255, 37, 37, 37),
			},
			
			Gui.Textbox "shouji_box"
			{
				Size = Vector2(163, 25),
				Location = Vector2(405, 139),
				Text = "",
				TextColor = ARGB(255, 37, 37, 37),
				BackgroundColor = ARGB(255, 255, 255, 255),
				FontSize = 14,
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("faq/lb_chat_bg4_normal.tga", Vector4(8, 8, 8, 8)),
				},
				MaxLength = 11,
			},
			
			Gui.Label "leixin"
			{
				Size = Vector2(127, 25),
				Location = Vector2(4, 169),
				Text = lang:GetText("*问题类型:"),
				TextAlign = "kAlignRightMiddle",
				FontSize = 14,
				TextColor = ARGB(255, 37, 37, 37),
			},
			
			Gui.RadioGroup "leixin_rg"
			{
				Size = Vector2(429, 16),
				Location = Vector2(140, 174),
				ControlSpace = 20,
				LineSpace = 5,
				TextColor = ARGB(255, 37, 37, 37),
				Skin = Gui.CheckBoxSkin
				{
					OnImage = Gui.Image("faq/lb_common_radiobtn01_active.tga", Vector4(0, 0, 0, 0)),
					OffImage = Gui.Image("lb_common_radiobtn01_normal.tga", Vector4(0, 0, 0, 0)),
					OnDisabledImage = Gui.Image("faq/lb_common_radiobtn01_active.tga", Vector4(0, 0, 0, 0)),
					OffDisabledImage = Gui.Image("lb_common_radiobtn01_normal.tga", Vector4(0, 0, 0, 0)),
				},
				
				Gui.RadioButton "bt1"
				{
					Size = Vector2(100, 16),
					FontSize = 14,
					TextColor = ARGB(255, 37, 37, 37),
					Text = "BUG",
					ID = 1,
				},

				Gui.RadioButton "bt2"
				{
					Size = Vector2(292, 16),
					FontSize = 14,
					TextColor = ARGB(255, 37, 37, 37),
					Text = lang:GetText("举报或建议"),
					ID = 2,			
				},

				EventRadioChanged = function(sender, args)
					redio_id = sender.RadioCheckID
				end
			},
			
			Gui.Label "miaoshu"
			{
				Size = Vector2(127, 25),
				Location = Vector2(4, 199),
				Text = lang:GetText("*问题描述:"),
				TextAlign = "kAlignRightMiddle",
				FontSize = 14,
				TextColor = ARGB(255, 37, 37, 37),
			},
			
			Gui.TextArea "miaoshu_box"
			{
				Size = Vector2(429, 157),
				Text = "",
				FontSize = 14,
				Location = Vector2(140, 199),
				TextColor = ARGB(255, 37, 37, 37),
				Fold = true,
				VScrollBarWidth = 14,
				VScrollBarButtonSize = 14,
				HScrollBarDisplay = "kHide",
				VScrollBarDisplay = "kAuto",							
				Skin = Gui.TextAreaSkin
				{
					BackgroundImage = Gui.Image("faq/lb_chat_bg4_normal.tga", Vector4(8, 8, 8, 8)),
				
					UpButtonNormalImage = Gui.Image("LobbyUI/lb_shop_scrollbar01_button1normal.dds", Vector4(0, 4, 0, 4)),
					UpButtonHoverImage = Gui.Image("LobbyUI/lb_shop_scrollbar01_button1hover.dds", Vector4(0, 4, 0, 4)),
					UpButtonDownImage = Gui.Image("LobbyUI/lb_shop_scrollbar01_button1down.dds", Vector4(0, 4, 0, 4)),
					UpButtonDisabledImage = Gui.Image("LobbyUI/lb_shop_scrollbar01_button1normal.dds", Vector4(0, 4, 0, 4)),
					
					DownButtonNormalImage = Gui.Image("LobbyUI/lb_shop_scrollbar01_button02normal.dds", Vector4(0, 4, 0, 4)),
					DownButtonHoverImage = Gui.Image("LobbyUI/lb_shop_scrollbar01_button02hover.dds", Vector4(0, 4, 0, 4)),
					DownButtonDownImage = Gui.Image("LobbyUI/lb_shop_scrollbar01_button02down.dds", Vector4(0, 4, 0, 4)),
					DownButtonDisabledImage = Gui.Image("LobbyUI/lb_shop_scrollbar01_button02normal.dds", Vector4(0, 4, 0, 4)),

					VSliderNormalImage = Gui.Image("LobbyUI/lb_shop_scrollbar01_slidernormal.dds", Vector4(0, 4, 0, 4)),
					VSliderHoverImage = Gui.Image("LobbyUI/lb_shop_scrollbar01_sliderhover.dds", Vector4(0, 4, 0, 4)),
					VSliderDownImage = Gui.Image("LobbyUI/lb_shop_scrollbar01_sliderdown.dds", Vector4(0, 4, 0, 4)),
					VSliderDisabledImage = Gui.Image("LobbyUI/lb_shop_scrollbar01_slidernormal.dds", Vector4(0, 4, 0, 4)),

					VBarBackgroundImage = Gui.Image("LobbyUI/lb_shop_scrollbar01_bg.dds", Vector4(0, 4, 0, 4)),
					BarCornerImage = nil,
				},
				MaxLength = 650,
			},
		},
		
		Gui.Control "title"
		{
			Size = Vector2(585,39),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Location = Vector2(10, 10),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("faq/ntwg_title.tga", Vector4(12, 12, 12, 12)),
			},
			
			Gui.Label "title_text"
			{
				Size = Vector2(585, 39),
				Location = Vector2(0, 0),
				Text = lang:GetText("你提我改"),
				TextAlign = "kAlignCenterMiddle",
				FontSize = 22,
				TextColor = ARGB(255, 37, 37, 37),
			},
		},
		
		Gui.Control "text"
		{
			Size = Vector2(573,50),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Location = Vector2(15, 51),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("faq/ntwg_whitebg01.dds", Vector4(12, 12, 12, 12)),
			},
			
			Gui.Label "text_text1"
			{
				Size = Vector2(573, 25),
				Location = Vector2(0, 0),
				Text = lang:GetText("玩家可以通过你提我改进行游戏bug以及建议的提交,"),
				TextAlign = "kAlignCenterMiddle",
				FontSize = 16,
				TextColor = ARGB(255, 37, 37, 37),
			},
			
			Gui.Label "text_text2"
			{
				Size = Vector2(573, 25),
				Location = Vector2(0, 24),
				Text = lang:GetText("感谢您的支持和参与！"),
				TextAlign = "kAlignCenterMiddle",
				FontSize = 16,
				TextColor = ARGB(255, 37, 37, 37),
			},
		},
		
		Gui.Control "warning"
		{
			Size = Vector2(573,22),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Location = Vector2(15, 370),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("faq/ntwg_warning_bg.tga", Vector4(22,0,7,0)),
			},
			
			Gui.Label "warning_text1"
			{
				Size = Vector2(553, 22),
				Location = Vector2(45, 1),
				Text = lang:GetText("以上带*号为必填项"),
				TextAlign = "kAlignLeftMiddle",
				FontSize = 16,
				TextColor = ARGB(255, 37, 37, 37),
			},
		},
		
		Gui.Button "btn_ok"
		{
			Size = Vector2(176, 34),
			Location = Vector2(100, 402),
			Text = lang:GetText("确 定"),
			TextColor = ARGB(255, 211, 211, 211),
			HighlightTextColor = ARGB(255, 211, 211, 211),
			FontSize = 18,
			PushDown = false,
			Padding = Vector4(0, 0, 0, 5),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("faq/lb_contact_button_normal.tga", Vector4(20, 16, 20, 16)),
				HoverImage = Gui.Image("faq/lb_contact_button_hover.tga", Vector4(20, 16, 20, 16)),
				DownImage = Gui.Image("faq/lb_contact_button_down.tga", Vector4(20, 16, 20, 16)),
				DisabledImage = Gui.Image("faq/lb_contact_button_normal.tga", Vector4(20, 16, 20, 16)),
			},
			EventClick = function()
				if WebWin.miaoshu_box.Text == "" or WebWin.biaoti_box.Text == "" then
					MessageBox.ShowWithTimer(1, lang:GetText("请确认带*号项都已经填写完整！"))
				else
					returnvalue = state:HttpXLInfo(WebWin.biaoti_box.Text,WebWin.miaoshu_box.Text,WebWin.qhao_box.Text,WebWin.shouji_box.Text,redio_id)
					if returnvalue == 0 then
						MessageBox.ShowWithTimer(1, lang:GetText("提交成功"))
						WebWin.miaoshu_box.Text = ""
						WebWin.biaoti_box.Text = ""
						WebWin.shouji_box.Text = ""
						WebWin.qhao_box.Text = ""
					elseif returnvalue == -2 then
						MessageBox.ShowWithTimer(1, lang:GetText("请先进入频道"))
					else
						MessageBox.ShowWithTimer(1, lang:GetText("服务器暂时不可用"))
					end
				end
			end
		},
		
		Gui.Button "btn_reset"
		{
			Size = Vector2(176, 34),
			Location = Vector2(330, 402),
			Text = lang:GetText("重 置"),
			TextColor = ARGB(255, 211, 211, 211),
			HighlightTextColor = ARGB(255, 211, 211, 211),
			FontSize = 18,
			PushDown = false,
			Padding = Vector4(0, 0, 0, 5),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("faq/lb_contact_button_normal.tga", Vector4(20, 16, 20, 16)),
				HoverImage = Gui.Image("faq/lb_contact_button_hover.tga", Vector4(20, 16, 20, 16)),
				DownImage = Gui.Image("faq/lb_contact_button_down.tga", Vector4(20, 16, 20, 16)),
				DisabledImage = Gui.Image("faq/lb_contact_button_normal.tga", Vector4(20, 16, 20, 16)),
			},
			EventClick = function()
				WebWin.miaoshu_box.Text = ""
				WebWin.biaoti_box.Text = ""
				WebWin.shouji_box.Text = ""
				WebWin.qhao_box.Text = ""
			end
		},
		
		Gui.Button "btn_close"
		{
			Size = Vector2(20, 20),
			Location = Vector2(550, 20),
			PushDown = false,
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("faq/lb_contact_buttonX_normal.dds", Vector4(0, 0, 0, 0)),
				HoverImage = Gui.Image("faq/lb_contact_buttonX2_hover.dds", Vector4(0, 0, 0, 0)),
				DownImage = Gui.Image("faq/lb_contact_buttonX2_down.dds", Vector4(0, 0, 0, 0)),
				DisabledImage = Gui.Image("faq/lb_contact_buttonX_normal.dds", Vector4(0, 0, 0, 0)),
			},
			EventClick = function()
				if WebWindow and WebWindow.screen then
					WebWindow.screen.Visible = false
				end
				escWindow.screen.Visible = false
				gui.Focused = true
			end
		},
	},
}

function AddControl(line,list)
	local X_pos = 19 + list*238
	local Y_pos = 57 + line*29
	if line%2 == 0 then
		return Gui.Control
		{	
			Size = Vector2(238, 29),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Location = Vector2(X_pos, Y_pos),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("faq/ig_esc_jubao_list_content_a.dds", Vector4(0, 0, 0, 0)),
			},
		}
	else
		return Gui.Control
		{	
			Size = Vector2(238, 29),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Location = Vector2(X_pos, Y_pos),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("faq/ig_esc_jubao_list_content_b.dds", Vector4(0, 0, 0, 0)),
			},
		}
	end
end

ReportWin = Gui.Create()
{
	Gui.Control "ReportWin_root"
	{	
		Size = Vector2(514, 576),
		BackgroundColor = ARGB(255, 255, 255, 255),
		Location = Vector2(0, 0),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("faq/ig_esc_jubao_bg.dds", Vector4(25, 25, 25, 25)),
		},
		
		Gui.Label
		{
			Size = Vector2(500, 32),
			Location = Vector2(4, 22),
			Text = lang:GetText("请选择要举报的玩家"),
			FontSize = 20,
			TextAlign = "kAlignCenterMiddle",
			TextColor = ARGB(255, 37, 37, 37),
		},
		
		AddControl(0,0),
		AddControl(1,0),
		AddControl(2,0),
		AddControl(3,0),
		AddControl(4,0),
		AddControl(5,0),
		AddControl(6,0),
		AddControl(7,0),
		
		AddControl(0,1),
		AddControl(1,1),
		AddControl(2,1),
		AddControl(3,1),
		AddControl(4,1),
		AddControl(5,1),
		AddControl(6,1),
		AddControl(7,1),
		
		Gui.RadioGroup "Report_Id"
		{
			Size = Vector2(476, 232),
			Location = Vector2(23, 60),
			ControlSpace = 10,
			LineSpace = 9,
			RadioCheckID = -1,
			TextColor = ARGB(255, 37, 37, 37),

			EventRadioChanged = function(sender, args)
				Report_name = sender.RadioCheckText
			end,
		},
		
		Gui.Label
		{
			Size = Vector2(500, 32),
			Location = Vector2(6, 295),
			Text = lang:GetText("举报理由"),
			FontSize = 20,
			TextAlign = "kAlignCenterMiddle",
			TextColor = ARGB(255, 37, 37, 37),
		},
		
		Gui.RadioGroup "Report_sake"
		{
			Size = Vector2(500, 20),
			Location = Vector2(26, 346),
			ControlSpace = 20,
			LineSpace = 5,
			TextColor = ARGB(255, 37, 37, 37),
			Skin = Gui.CheckBoxSkin
			{
				OnImage = Gui.Image("faq/lb_common_radiobtn01_active.tga", Vector4(0, 0, 0, 0)),
				OffImage = Gui.Image("lb_common_radiobtn01_normal.tga", Vector4(0, 0, 0, 0)),
				OnDisabledImage = Gui.Image("faq/lb_common_radiobtn01_active.tga", Vector4(0, 0, 0, 0)),
				OffDisabledImage = Gui.Image("lb_common_radiobtn01_normal.tga", Vector4(0, 0, 0, 0)),
			},
			
			Gui.RadioButton
			{
				Size = Vector2(105, 20),
				FontSize = 10,
				TextColor = ARGB(255, 37, 37, 37),
				Text = lang:GetText("使用外挂"),
				ID = 1,
			},
			
			Gui.RadioButton
			{
				Size = Vector2(105, 20),
				FontSize = 10,
				TextColor = ARGB(255, 37, 37, 37),
				Text = lang:GetText("恶意使用bug"),
				ID = 2,
			},
			
			Gui.RadioButton
			{
				Size = Vector2(125, 20),
				FontSize = 10,
				TextColor = ARGB(255, 37, 37, 37),
				Text = lang:GetText("无理谩骂"),
				ID = 3,
			},
			
			Gui.RadioButton
			{
				Size = Vector2(105, 20),
				FontSize = 10,
				TextColor = ARGB(255, 37, 37, 37),
				Text = lang:GetText("其它"),
				ID = 4,
			},

			EventRadioChanged = function(sender, args)
				
			end,
		},
		
		Gui.Label
		{
			Size = Vector2(500, 32),
			Location = Vector2(6, 383),
			Text = lang:GetText("问题描述"),
			FontSize = 20,
			TextAlign = "kAlignCenterMiddle",
			TextColor = ARGB(255, 37, 37, 37),
		},
		
		Gui.Control"ctr_Group_write"
		{
			Size = Vector2(476, 90),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Location = Vector2(18, 423),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/Friends/lb_contact_bg3_normal.dds", Vector4(8, 8, 8, 8)),
			},
			
			Gui.TextArea "tarea_Text"
			{
				Style = "Gui.TextAreaWithVBar",
				Size = Vector2(470, 80),
				FontSize = 14,
				Location = Vector2(0, 5),
				TextColor = ARGB(255, 37, 37, 37),
				HighlightTextColor = ARGB(255, 37, 37, 37),
				Fold = true,
				VScrollBarWidth = 8,
				VScrollBarButtonSize = 1,
				VScrollBarPos = Vector2(0, 0),
				Padding = Vector4(5, 5, 5, 5),
			
				EventTextChanged = function()
					
				end
			},
		},
		
		Gui.Button
		{
			Size = Vector2(103, 35),
			Location = Vector2(103, 522),
			Text = lang:GetText("确 定"),
			TextColor = ARGB(255, 211, 211, 211),
			HighlightTextColor = ARGB(255, 211, 211, 211),
			FontSize = 18,
			PushDown = false,
			Padding = Vector4(0, 0, 0, 5),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("faq/lb_contact_button_normal.tga", Vector4(20, 16, 20, 16)),
				HoverImage = Gui.Image("faq/lb_contact_button_hover.tga", Vector4(20, 16, 20, 16)),
				DownImage = Gui.Image("faq/lb_contact_button_down.tga", Vector4(20, 16, 20, 16)),
				DisabledImage = Gui.Image("faq/lb_contact_button_normal.tga", Vector4(20, 16, 20, 16)),
			},
			EventClick = function()
				if Report_name == nil then
					MessageBox.ShowWithTimer(1,lang:GetText("请选择一名玩家！"))
					return
				end
				if ReportWin.tarea_Text.Text == "" then
					MessageBox.ShowWithTimer(1,lang:GetText("问题描述不能为空！"))
					return
				end
				local returnvalue = state:HttpXLReport(Report_name,ReportWin.Report_sake.RadioCheckID,ReportWin.tarea_Text.Text)
				if returnvalue == 0 then
					MessageBox.ShowWithTimer(1, lang:GetText("提交成功"))
					DeleteAllReport()
				else
					MessageBox.ShowWithTimer(1, lang:GetText("提交失败"))
				end
			end,
		},
		
		Gui.Button
		{
			Size = Vector2(103, 35),
			Location = Vector2(300, 522),
			Text = lang:GetText("取 消"),
			TextColor = ARGB(255, 211, 211, 211),
			HighlightTextColor = ARGB(255, 211, 211, 211),
			FontSize = 18,
			PushDown = false,
			Padding = Vector4(0, 0, 0, 5),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("faq/lb_contact_button_normal.tga", Vector4(20, 16, 20, 16)),
				HoverImage = Gui.Image("faq/lb_contact_button_hover.tga", Vector4(20, 16, 20, 16)),
				DownImage = Gui.Image("faq/lb_contact_button_down.tga", Vector4(20, 16, 20, 16)),
				DisabledImage = Gui.Image("faq/lb_contact_button_normal.tga", Vector4(20, 16, 20, 16)),
			},
			EventClick = function()
				DeleteAllReport()
			end,
		},
	},
}
local escMenu = Gui.Create()
{
	Gui.Control "content"
	{
		Size = Vector2(193, 270),
		Dock = "kDockCenter",
		BackgroundColor = ARGB(255,255,255,255),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/setting/ig_esc_bg2.dds",Vector4(10, 10, 10, 10)),
		},	
		Gui.Button "cancel"
		{	
			Location = Vector2(18, 25),
			Size = Vector2(157,52),
			TextAlign = "kAlignRightMiddle",
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/setting/lb_esc_button_fhyx_normal.dds", Vector4(5, 5, 5, 5)),
				HoverImage = Gui.Image("LobbyUI/setting/lb_esc_button_fhyx_hover.dds", Vector4(5, 5, 5, 5)),
				DownImage = Gui.Image("LobbyUI/setting/lb_esc_button_fhyx_down.dds", Vector4(5, 5, 5, 5)),
				DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_esc_button_fhyx_normal.dds", Vector4(5, 5, 5, 5)),
			},
			Text = lang:GetText("返回游戏").." ",
			TextColor = ARGB(255, 42, 43, 42),
			FontSize = 24,
		},
		Gui.Button "setting"
		{
		
			Location = Vector2(18, 80),
			Size = Vector2(157,52),	
			TextAlign = "kAlignRightMiddle",
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/setting/lb_esc_button_yxsz_normal.dds", Vector4(5, 5, 5, 5)),
				HoverImage = Gui.Image("LobbyUI/setting/lb_esc_button_yxsz_hover.dds", Vector4(5, 5, 5, 5)),
				DownImage = Gui.Image("LobbyUI/setting/lb_esc_button_yxsz_down.dds", Vector4(5, 5, 5, 5)),
				DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_esc_button_yxsz_normal.dds", Vector4(5, 5, 5, 5)),
			},
			Text = lang:GetText("设置选项").." ",
			TextColor = ARGB(255, 42, 43, 42),
			FontSize = 24,
		},

		Gui.Button "character"
		{	
			Location = Vector2(18, 80),
			Size = Vector2(0,52),
			--Location = Vector2(18, 138),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/setting/lb_esc_button_normal.dds", Vector4(5, 5, 5, 5)),
				HoverImage = Gui.Image("LobbyUI/setting/lb_esc_button_hover.dds", Vector4(5, 5, 5, 5)),
				DownImage = Gui.Image("LobbyUI/setting/lb_esc_button_down.dds", Vector4(5, 5, 5, 5)),
				DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_esc_button_normal.dds", Vector4(5, 5, 5, 5)),
			},
			Text = lang:GetText("登录界面 "),
		},

		Gui.Button "quit"
		{		
		
			Size = Vector2(157,52),
			Location = Vector2(18, 135),
			TextAlign = "kAlignRightMiddle",
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/setting/lb_esc_button_tcyx_normal.dds", Vector4(5, 5, 5, 5)),
				HoverImage = Gui.Image("LobbyUI/setting/lb_esc_button_tcyx_hover.dds", Vector4(5, 5, 5, 5)),
				DownImage = Gui.Image("LobbyUI/setting/lb_esc_button_tcyx_down.dds", Vector4(5, 5, 5, 5)),
				DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_esc_button_tcyx_normal.dds", Vector4(5, 5, 5, 5)),
			},
			Text = lang:GetText("退出游戏 "),
			TextColor = ARGB(255, 42, 43, 42),
			FontSize = 24,
		},
		Gui.Button "faq"
		{			
			TextAlign = "kAlignRightMiddle",
			Size = Vector2(157,52),		
			Location = Vector2(18, 190),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/setting/lb_esc_button_ntwg_normal.dds", Vector4(5, 5, 5, 5)),
				HoverImage = Gui.Image("LobbyUI/setting/lb_esc_button_ntwg_hover.dds", Vector4(5, 5, 5, 5)),
				DownImage = Gui.Image("LobbyUI/setting/lb_esc_button_ntwg_down.dds", Vector4(5, 5, 5, 5)),
				DisabledImage = Gui.Image("LobbyUI/ShoppingMall/lb_esc_button_ntwg_normal.dds", Vector4(5, 5, 5, 5)),
			},
			Text = lang:GetText("你提我改").." ",
			TextColor = ARGB(255, 42, 43, 42),
			FontSize = 24,
		},
	},
}

local Quit_count = nil

function create_mission()
	return Gui.Control
	{
		Size = Vector2(196, 222),
		BackgroundColor = ARGB(0, 255, 255, 255),
		Gui.Control
		{
			Size = Vector2(196, 186),
			Location = Vector2(0, 0),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/lb_top_ad_black.dds",Vector4(10, 10, 10, 10)),
			},
		},
		Gui.Control
		{
			Size = Vector2(196, 132),
			Location = Vector2(0, 54),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("MapsAndBG/MapsIcon/lb_task_W_6.dds",Vector4(0, 0, 0, 0)),
			},
		},
		Gui.Control
		{
			Visible = false,
			Size = Vector2(87, 87),
			Location = Vector2(109, 98),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/Mission/lb_task_ico_wancheng.dds",Vector4(0, 0, 0, 0)),
			},
		},
		Gui.TextArea
		{
			Size = Vector2(230, 54),
			Location = Vector2(0, 0),
			TextColor = ARGB(255, 255, 211, 78),
			FontSize = 14,
			Fold = true,
			Readonly = true,
		},
		Gui.Label
		{
			Size = Vector2(196, 26),
			Location = Vector2(0, 186),
			TextColor = ARGB(255, 255, 211, 78),
			FontSize = 18,
			TextAlign = "kAlignCenterMiddle",
		},
	}
end

Quit = Gui.Create()
{
	Gui.Control "content"
	{
		Size = Vector2(888 + 250, 688),
		Dock = "kDockCenter",
		BackgroundColor = ARGB(255, 255, 255, 255),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/lb_contact_bg1_01.dds", Vector4(163,163,53,53)),
		},
		Gui.Control
		{
			Size = Vector2(525, 297),
			Location = Vector2(25, 23),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/lb_quit_right_bg.dds",Vector4(20, 50, 20, 20)),
			},
			Gui.Label
			{
				Size = Vector2(525, 28),
				Location = Vector2(0, 6),
				TextColor = ARGB(255, 197, 211, 207),
				FontSize = 18,
				Text = lang:GetText("今日表现"),
				TextAlign = "kAlignCenterMiddle",
			},
			Gui.Control
			{
				Size = Vector2(64, 64),
				Location = Vector2(17, 39),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/lb_quit_win.dds",Vector4(0, 0, 0, 0)),
				},
			},
			Gui.Label "winlose"
			{
				Size = Vector2(358, 45),
				Location = Vector2(89, 51),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/lb_quit_numeral_bg.dds",Vector4(10, 20, 10, 10)),
				},
				Text = "100/0",
				FontSize = 23,
				TextColor = ARGB(255, 197, 211, 207),
				TextAlign = "kAlignCenterMiddle",
			},
			Gui.Control
			{
				Size = Vector2(64, 64),
				Location = Vector2(454, 39),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/lb_quit_lose.dds",Vector4(0, 0, 0, 0)),
				},
			},
			Gui.Control
			{
				Size = Vector2(515, 45),
				Location = Vector2(6, 99),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/lb_quit_numeral_bg.dds",Vector4(10, 20, 10, 10)),
				},
				Gui.Label "kill"
				{
					Size = Vector2(160, 20),
					Location = Vector2(60, 22),
					Text = lang:GetText("击杀"),
					FontSize = 18,
					TextColor = ARGB(255, 197, 211, 207),
					TextAlign = "kAlignLeftMiddle",
				},
				Gui.Label "assist"
				{
					Size = Vector2(160, 20),
					Location = Vector2(220, 22),
					Text = lang:GetText("助攻"),
					FontSize = 18,
					TextColor = ARGB(255, 197, 211, 207),
					TextAlign = "kAlignLeftMiddle",
				},
				Gui.Label "dead"
				{
					Size = Vector2(160, 20),
					Location = Vector2(360, 22),
					Text = lang:GetText("死亡"),
					FontSize = 18,
					TextColor = ARGB(255, 197, 211, 207),
					TextAlign = "kAlignLeftMiddle",
				},
			},
			Gui.Control
			{
				Size = Vector2(515, 45),
				Location = Vector2(6, 149),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/lb_quit_numeral_bg.dds",Vector4(10, 20, 10, 10)),
				},
				Gui.Label
				{
					Size = Vector2(235, 20),
					Location = Vector2(0, 22),
					Text = lang:GetText("获得分数"),
					TextColor = ARGB(255, 255, 211, 78),
					FontSize = 14,
					TextAlign = "kAlignLeftMiddle",
				},
				Gui.Control
				{
					Size = Vector2(268, 45),
					Location = Vector2(251, 0),
					BackgroundColor = ARGB(0, 255, 255, 255),
					Gui.FlowLayout "score"
					{
						Dock = "kDockFill",
						ControlSpace = 1,
						Gui.Label
						{
							Style = "Gui.QuitLabel",
						},
						Gui.Label
						{
							Style = "Gui.QuitLabel",
						},
						Gui.Label
						{
							Style = "Gui.QuitLabel",
						},
						Gui.Label
						{
							Style = "Gui.QuitLabel",
						},
						Gui.Label
						{
							Style = "Gui.QuitLabel",
						},
						Gui.Label
						{
							Style = "Gui.QuitLabel",
						},
						Gui.Label
						{
							Style = "Gui.QuitLabel",
						},
						Gui.Label
						{
							Style = "Gui.QuitLabel",
						},
					},
				},
			},
			Gui.Control
			{
				Size = Vector2(515, 45),
				Location = Vector2(6, 199),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/lb_quit_numeral_bg.dds",Vector4(10, 20, 10, 10)),
				},
				Gui.Label
				{
					Size = Vector2(235, 20),
					Location = Vector2(0, 22),
					Text = lang:GetText("获得经验值"),
					TextColor = ARGB(255, 255, 211, 78),
					FontSize = 14,
					TextAlign = "kAlignLeftMiddle",
				},
				Gui.Control
				{
					Size = Vector2(268, 45),
					Location = Vector2(251, 0),
					BackgroundColor = ARGB(0, 255, 255, 255),
					Gui.FlowLayout "exp"
					{
						Dock = "kDockFill",
						ControlSpace = 1,
						Gui.Label
						{
							Style = "Gui.QuitLabel",
						},
						Gui.Label
						{
							Style = "Gui.QuitLabel",
						},
						Gui.Label
						{
							Style = "Gui.QuitLabel",
						},
						Gui.Label
						{
							Style = "Gui.QuitLabel",
						},
						Gui.Label
						{
							Style = "Gui.QuitLabel",
						},
						Gui.Label
						{
							Style = "Gui.QuitLabel",
						},
						Gui.Label
						{
							Style = "Gui.QuitLabel",
						},
						Gui.Label
						{
							Style = "Gui.QuitLabel",
						},
					},
				},
			},
			Gui.Control
			{
				Size = Vector2(515, 45),
				Location = Vector2(6, 249),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/lb_quit_numeral_bg.dds",Vector4(10, 20, 10, 10)),
				},
				Gui.Label
				{
					Size = Vector2(235, 20),
					Location = Vector2(0, 22),
					Text = lang:GetText("获得C币"),
					TextColor = ARGB(255, 255, 211, 78),
					FontSize = 14,
					TextAlign = "kAlignLeftMiddle",
				},
				Gui.Control
				{
					Size = Vector2(268, 45),
					Location = Vector2(251, 0),
					BackgroundColor = ARGB(0, 255, 255, 255),
					Gui.FlowLayout "gp"
					{
						Dock = "kDockFill",
						ControlSpace = 1,
						Gui.Label
						{
							Style = "Gui.QuitLabel",
						},
						Gui.Label
						{
							Style = "Gui.QuitLabel",
						},
						Gui.Label
						{
							Style = "Gui.QuitLabel",
						},
						Gui.Label
						{
							Style = "Gui.QuitLabel",
						},
						Gui.Label
						{
							Style = "Gui.QuitLabel",
						},
						Gui.Label
						{
							Style = "Gui.QuitLabel",
						},
						Gui.Label
						{
							Style = "Gui.QuitLabel",
						},
						Gui.Label
						{
							Style = "Gui.QuitLabel",
						},
					},
				},
			},
		},
		
		Gui.Control
		{
			Size = Vector2(312, 297),
			Location = Vector2(554, 23),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/lb_quit_right_bg.dds",Vector4(20, 50, 20, 20)),
			},
			Gui.Label
			{
				Size = Vector2(312, 28),
				Location = Vector2(0, 6),
				TextColor = ARGB(255, 197, 211, 207),
				FontSize = 18,
				Text = lang:GetText("当前等级"),
				TextAlign = "kAlignCenterMiddle",
			},
			
			Gui.Control "level_bg"
			{
				Size = Vector2(160, 144),
				Location = Vector2(67, 41),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/lv1-5.dds",Vector4(0, 0, 0, 0)),
				},
			},
			
			Gui.Control
			{
				Size = Vector2(60, 105),
				Location = Vector2(143, 51),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Gui.Control "big_bg_one"
				{
					Size = Vector2(60, 105),
					Location = Vector2(0, 0),
					BackgroundColor = ARGB(255, 255, 255, 255),
				},
				Gui.Control "big_one"
				{
					Size = Vector2(60, 105 * (4+97)/105),
					Location = Vector2(0, 105 * (1 - (4+97)/105)),
					BackgroundColor = ARGB(255, 255, 255, 255),
				},
			},
			Gui.Control
			{
				Size = Vector2(60, 105),
				Location = Vector2(92, 51),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Gui.Control "big_bg_ten"
				{
					Size = Vector2(60, 105),
					Location = Vector2(0, 0),
					BackgroundColor = ARGB(255, 255, 255, 255),
				},
				Gui.Control "big_ten"
				{
					Size = Vector2(60, 105 * (4+97)/105),
					Location = Vector2(0, 105 * (1 - (4+97)/105)),
					BackgroundColor = ARGB(255, 255, 255, 255),
				},
			},
			Gui.Control
			{
				Size = Vector2(20, 16),
				Location = Vector2(18, 202),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/lb_icon_lv.dds",Vector4(0, 0, 0, 0)),
				},
			},
			Gui.Control "small1_bg_ten"
			{
				Size = Vector2(13, 31),
				Location = Vector2(38, 193),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_summary_number_6b.dds",Vector4(0, 0, 0, 0),Vector4(0.6, 0, 0.7, 1)),
				},
				Gui.Control "small1_ten"
				{
					Size = Vector2(13, 31),
					Location = Vector2(0, 0),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_summary_number_7b.dds",Vector4(0, 0, 0, 0),Vector4(0.6, 0, 0.7, 1)),
					},
				},
			},
			Gui.Control "small1_bg_one"
			{
				Size = Vector2(13, 31),
				Location = Vector2(48, 193),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_summary_number_6b.dds",Vector4(0, 0, 0, 0),Vector4(0.6, 0, 0.7, 1)),
				},
				Gui.Control "small1_one"
				{
					Size = Vector2(13, 31),
					Location = Vector2(0, 0),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_summary_number_7b.dds",Vector4(0, 0, 0, 0),Vector4(0.6, 0, 0.7, 1)),
					},
				},
			},
			
			Gui.Control "mark"
			{
				Size = Vector2(50, 50),
				Location = Vector2(49, 170),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Gui.Label "Percent"
				{
					Size = Vector2(50, 20),
					Location = Vector2(0, 0),
					Text = "10%",
					FontSize = 18,
					TextAlign = "kAlignCenterMiddle",
					TextColor = ARGB(255, 255, 78, 2),
				},
				Gui.Control
				{
					Size = Vector2(8, 8),
					Location = Vector2(21, 20),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/lb_quit_triangle.dds",Vector4(0, 0, 0, 0)),
					},
				},
			},
			
			Gui.Control 
			{
				Size = Vector2(170, 20),
				Location = Vector2(68, 199),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_common_expbar01_bg.dds",Vector4(10, 10, 10, 10)),
				},
				Gui.Control "bar"
				{
					Size = Vector2(15, 13),
					Location = Vector2(5, 4),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_bar_content_02.dds",Vector4(10, 10, 10, 10)),
					},
				},
			},
			
			Gui.Control "lv_image"
			{
				Size = Vector2(20, 16),
				Location = Vector2(247, 202),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/lb_icon_lv.dds",Vector4(0, 0, 0, 0)),
				},
			},
			Gui.Control "small2_bg_ten"
			{
				Size = Vector2(13, 31),
				Location = Vector2(267, 193),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_summary_number_6b.dds",Vector4(0, 0, 0, 0),Vector4(0.6, 0, 0.7, 1)),
				},
				Gui.Control "small2_ten"
				{
					Size = Vector2(13, 31),
					Location = Vector2(0, 0),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_summary_number_7b.dds",Vector4(0, 0, 0, 0),Vector4(0.6, 0, 0.7, 1)),
					},
				},
			}, 
			Gui.Control "small2_bg_one"
			{
				Size = Vector2(13, 31),
				Location = Vector2(277, 193),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_summary_number_6b.dds",Vector4(0, 0, 0, 0),Vector4(0.6, 0, 0.7, 1)),
				},
				Gui.Control "small2_one"
				{
					Size = Vector2(13, 31),
					Location = Vector2(0, 0),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_summary_number_7b.dds",Vector4(0, 0, 0, 0),Vector4(0.6, 0, 0.7, 1)),
					},
				},
			},
			Gui.Control
			{
				Size = Vector2(298, 71),
				Location = Vector2(5, 221),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/lb_quit_numeral_bg.dds",Vector4(10, 20, 10, 10)),
				},
				Gui.Label
				{
					Size = Vector2(298, 28),
					Location = Vector2(0, 0),
					Text = lang:GetText("距离升级还需经验值"),
					TextColor = ARGB(255, 255, 211, 78),
					FontSize = 14,
					TextAlign = "kAlignCenterMiddle",
				},
				Gui.Control
				{
					Size = Vector2(286, 45),
					Location = Vector2(20, 25),
					BackgroundColor = ARGB(0, 255, 255, 255),
					Gui.FlowLayout "need_exp"
					{
						Dock = "kDockFill",
						ControlSpace = 1,
						Gui.Label
						{
							Style = "Gui.QuitLabel",
						},
						Gui.Label
						{
							Style = "Gui.QuitLabel",
						},
						Gui.Label
						{
							Style = "Gui.QuitLabel",
						},
						Gui.Label
						{
							Style = "Gui.QuitLabel",
						},
						Gui.Label
						{
							Style = "Gui.QuitLabel",
						},
						Gui.Label
						{
							Style = "Gui.QuitLabel",
						},
						Gui.Label
						{
							Style = "Gui.QuitLabel",
						},
						Gui.Label
						{
							Style = "Gui.QuitLabel",
						},
					},
				},
			},
		
			Gui.Label "max"
			{
				Size = Vector2(298, 71),
				Location = Vector2(5, 221),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/lb_quit_numeral_bg.dds",Vector4(10, 20, 10, 10)),
				},
				Visible = false,
				Text = lang:GetText("您已经达到顶级"),
				TextAlign = "kAlignCenterMiddle",
				TextColor = ARGB(255, 255, 211, 78),
				FontSize = 26,
			},
		
		},
		
		Gui.Control
		{
			Size = Vector2(250, 297),
			Location = Vector2(869, 23),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/lb_quit_right_bg.dds",Vector4(20, 50, 20, 20)),
			},
			
			Gui.Label
			{
				Size = Vector2(250, 28),
				Location = Vector2(0, 6),
				TextColor = ARGB(255, 197, 211, 207),
				FontSize = 18,
				Text = lang:GetText("当前VIP等级"),
				TextAlign = "kAlignCenterMiddle",
			},
			
			Gui.Control "ctr_VIP"
			{
				Location = Vector2(35, 70),
				Size = Vector2(142 * 1.3, 77 * 1.3),
				BackgroundColor = ARGB(255,255,255,255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_bg_06.dds", Vector4(0, 0, 0, 0)),
				},
				Gui.Control "ctr_VIP_num"
				{
					Location = Vector2(44 * 1.3, 30 * 1.3),
					Size = Vector2(50 * 1.3, 29 * 1.3),
					BackgroundColor = ARGB(255,255,255,255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_button_06_normal.dds", Vector4(0, 0, 0, 0)),
					},
				},
			},
			
			Gui.Label "vip_exp_text"
			{
				Size = Vector2(250,25),
				Location = Vector2(0, 170),
				BackgroundColor = ARGB(0, 255, 255, 255),
				TextAlign = "kAlignCenterMiddle",
				Text = lang:GetText("您还不是VIP，无法获得经验"),
			},
			
			Gui.Control
			{
				Size = Vector2(220,25),
				Location = Vector2(20, 200),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/vip/vip/lb_VIP_scrollbar_slider.dds", Vector4(10, 10, 20, 10)),
				},
				Gui.Control "exp_bar"
				{
					Size = Vector2(0,25),
					Location = Vector2(0, 0),
					BackgroundColor = ARGB(255, 255, 255, 255),
					Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("LobbyUI/vip/vip/lb_VIP_scrollbar_bg.dds", Vector4(10, 10, 20, 10)),
					},
				},
			},
			
			Gui.Control
			{
				Size = Vector2(240, 71),
				Location = Vector2(5, 221),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/lb_quit_numeral_bg.dds",Vector4(10, 20, 10, 10)),
				},
				Gui.Label "vip_Label"
				{
					Size = Vector2(240, 28),
					Location = Vector2(0, 0),
					Text = lang:GetText("距离升级还需经验值"),
					TextColor = ARGB(255, 255, 211, 78),
					FontSize = 14,
					TextAlign = "kAlignCenterMiddle",
				},
				Gui.Control
				{
					Size = Vector2(210 + 64, 45),
					Location = Vector2(0, 25),
					BackgroundColor = ARGB(0, 255, 255, 255),
					Gui.FlowLayout "need_exp_vip"
					{
						Dock = "kDockFill",
						ControlSpace = 1,
						Gui.Label
						{
							Style = "Gui.QuitLabel",
						},
						Gui.Label
						{
							Style = "Gui.QuitLabel",
						},
						Gui.Label
						{
							Style = "Gui.QuitLabel",
						},
						Gui.Label
						{
							Style = "Gui.QuitLabel",
						},
						Gui.Label
						{
							Style = "Gui.QuitLabel",
						},
						Gui.Label
						{
							Style = "Gui.QuitLabel",
						},
						Gui.Label
						{
							Style = "Gui.QuitLabel",
						},
						Gui.Label
						{
							Style = "Gui.QuitLabel",
						},
					},
				},
			},
		},
		
		Gui.Control
		{
			Size = Vector2(840 + 250, 269),
			Location = Vector2(25, 325),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/lb_quit_right_bg.dds",Vector4(20, 50, 20, 20)),
			},
			Gui.Label
			{
				Size = Vector2(100, 28),
				Location = Vector2(312 + 125, 6),
				TextColor = ARGB(255, 197, 211, 207),
				FontSize = 18,
				Text = lang:GetText("我的任务"),
				TextAlign = "kAlignCenterMiddle",
			},
			Gui.Control
			{
				Size = Vector2(727 + 250, 221),
				Location = Vector2(75, 47),
				BackgroundColor = ARGB(0, 255, 255, 255),
				Gui.Control
				{
					Size = Vector2(250 * 7, 222),
					Location = Vector2(0, 0),
					BackgroundColor = ARGB(0, 255, 255, 255),
					Gui.FlowLayout "mission"
					{
						Dock = "kDockFill",
						ControlSpace = 54,
						create_mission(),
						create_mission(),
						create_mission(),
						create_mission(),
						create_mission(),
						create_mission(),
						create_mission(),
						create_mission(),
						create_mission(),
						create_mission(),
					},
				},
			},
			
			Gui.Button
			{
				Size = Vector2(32, 44),
				Location = Vector2(17, 143),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/lb_quit_prev_normal.dds", Vector4(0, 0, 0, 0)),
					HoverImage = Gui.Image("LobbyUI/lb_quit_prev_hover.dds", Vector4(0, 0, 0, 0)),
					DownImage = Gui.Image("LobbyUI/lb_quit_prev_down.dds", Vector4(0, 0, 0, 0)),
					DisabledImage = nil,
				},
				EventClick = function()
					if Quit_count > 0 then
						Quit_count = Quit_count - 1
						Quit.mission.Parent.Location =  Vector2(Quit_count * 250 * -1, 0)
					end
				end
			},
			Gui.Button
			{
				Size = Vector2(32, 44),
				Location = Vector2(795 + 250, 143),
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/lb_quit_next_normal.dds", Vector4(0, 0, 0, 0)),
					HoverImage = Gui.Image("LobbyUI/lb_quit_next_hover.dds", Vector4(0, 0, 0, 0)),
					DownImage = Gui.Image("LobbyUI/lb_quit_next_down.dds", Vector4(0, 0, 0, 0)),
					DisabledImage = nil,
				},
				EventClick = function()
					if Quit_count < sum - 5 then
						Quit_count = Quit_count + 1
						Quit.mission.Parent.Location =  Vector2(Quit_count * 250 * -1, 0)
					end
				end
			},
		},
		
		Gui.Label "is_open"
		{
			Visible = false,
			Size = Vector2(840 + 250, 269),
			Location = Vector2(25, 325),
			BackgroundColor = ARGB(255, 255, 255, 255),
			TextColor = ARGB(255, 169, 163, 143),
			TextAlign = "kAlignCenterMiddle",
			FontSize = 24,
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/Mission/lb_task_bg4.dds", Vector4(257, 0, 124, 0)),
			},
			
			Gui.RichEdit "re_msg"
			{
				Size = Vector2(500, 200),
				Location = Vector2(320, 80),
				FontSize = 24,
				BackgroundColor = ARGB(255, 255, 255, 255),
				Line_Space = 5,
				Text_Shadow = true,
				
				VScrollBarWidth = 16,
				VScrollBarButtonSize = 1,
				Style = "Gui.MessagePanel",
				AutoScroll = true,
				AutoScrollMinSize = Vector2(464, 140),
				HScrollBarDisplay = "kHide",
				VScrollBarDisplay = "kAuto",
				
			},
		},
		
		Gui.Button
		{
			Size = Vector2(145, 53),
			Location = Vector2(100, 611),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Text = lang:GetText("继续游戏"),
			FontSize = 24,
			TextAlign = "kAlignCenterMiddle",
			TextColor = ARGB(255, 255, 255, 255),
			
			HighlightTextColor = ARGB(255, 255, 255, 255),
			Padding = Vector4(0, 0, 0, 7),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_battlecreate_button_create_normal.dds", Vector4(20, 20, 20, 20)),
				HoverImage = Gui.Image("LobbyUI/WarZone/lb_battlecreate_button_create_hover.dds", Vector4(20, 20, 20, 20)),
				DownImage = Gui.Image("LobbyUI/WarZone/lb_battlecreate_button_create_down.dds", Vector4(20, 20, 20, 20)),
				DisabledImage = Gui.Image("LobbyUI/WarZone/lb_battlecreate_button_create_disabled.dds", Vector4(20, 20, 20, 20)),
			},
			EventClick = function()
				if Quitmodal then
					Quitmodal.Close()
					Quitmodal = nil
				end
			end
		},
		Gui.Button
		{
			Size = Vector2(145, 53),
			Location = Vector2(350, 611),
			BackgroundColor = ARGB(255, 255, 255, 255),
			TextColor = ARGB(255, 255, 255, 255),
			HighlightTextColor = ARGB(255, 255, 255, 255),
			Text = lang:GetText("退出游戏"),
			Padding = Vector4(0, 0, 0, 7),
			FontSize = 24,
			TextAlign = "kAlignCenterMiddle",
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_battlecreate_button_create_normal.dds", Vector4(20, 20, 20, 20)),
				HoverImage = Gui.Image("LobbyUI/WarZone/lb_battlecreate_button_create_hover.dds", Vector4(20, 20, 20, 20)),
				DownImage = Gui.Image("LobbyUI/WarZone/lb_battlecreate_button_create_down.dds", Vector4(20, 20, 20, 20)),
				DisabledImage = Gui.Image("LobbyUI/WarZone/lb_battlecreate_button_create_disabled.dds", Vector4(20, 20, 20, 20)),
			},
			EventClick = function(Sender,e)
				MessageBox.ShowWithConfirmCancel(lang:GetText("您确定要退出游戏吗？"),
					function(sender,e)
						Thread.Quit()
					end,
					function()
						Sender.Parent.Focused = true
					end,
				nil,nil)
			end
		},
		Gui.Button
		{
			Size = Vector2(145, 53),
			Location = Vector2(600, 611),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Text = lang:GetText("你提我改"),
			TextColor = ARGB(255, 255, 255, 255),
			HighlightTextColor = ARGB(255, 255, 255, 255),
			Padding = Vector4(0, 0, 0, 7),
			FontSize = 24,
			TextAlign = "kAlignCenterMiddle",
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_battlecreate_button_create_normal.dds", Vector4(20, 20, 20, 20)),
				HoverImage = Gui.Image("LobbyUI/WarZone/lb_battlecreate_button_create_hover.dds", Vector4(20, 20, 20, 20)),
				DownImage = Gui.Image("LobbyUI/WarZone/lb_battlecreate_button_create_down.dds", Vector4(20, 20, 20, 20)),
				DisabledImage = Gui.Image("LobbyUI/WarZone/lb_battlecreate_button_create_disabled.dds", Vector4(20, 20, 20, 20)),
			},
			EventClick = function()
				ShowWebWin()
				if Quitmodal then
					Quitmodal.Close()
					Quitmodal = nil
				end
			end
		},
		Gui.Button
		{
			Size = Vector2(145, 53),
			Location = Vector2(850, 611),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Text = lang:GetText("取 消"),
			TextColor = ARGB(255, 255, 255, 255),
			HighlightTextColor = ARGB(255, 255, 255, 255),
			Padding = Vector4(0, 0, 0, 7),
			FontSize = 24,
			TextAlign = "kAlignCenterMiddle",
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_battlecreate_button_create_normal.dds", Vector4(20, 20, 20, 20)),
				HoverImage = Gui.Image("LobbyUI/WarZone/lb_battlecreate_button_create_hover.dds", Vector4(20, 20, 20, 20)),
				DownImage = Gui.Image("LobbyUI/WarZone/lb_battlecreate_button_create_down.dds", Vector4(20, 20, 20, 20)),
				DisabledImage = Gui.Image("LobbyUI/WarZone/lb_battlecreate_button_create_disabled.dds", Vector4(20, 20, 20, 20)),
			},
			EventClick = function()
				if Quitmodal then
					Quitmodal.Close()
					Quitmodal = nil
				end
			end
		},
	},
}

function Show_QuitWin()
	Quitmodal = ModalWindow.GetNew()
	Quitmodal.root.Size = Vector2(888 + 250,688)
	Quitmodal.AllowEscToExit = false
	Quit.content.Parent = Quitmodal.root
	Quit_count = 0
	Fill_QuitWin()
end

function Fill_QuitWin()
	rpc.safecall("keep_stay",{pid = ptr_cast(game.CurrentState):GetCharacterId()},
	function(data)
		if data then
			--左上填充
			Quit.winlose.Text = data.today.win.."/"..data.today.lose
			Quit.kill.Text = lang:GetText("击杀：")..data.today.kill
			Quit.assist.Text = lang:GetText("助攻：")..data.today.assist
			Quit.dead.Text = lang:GetText("死亡：")..data.today.dead
			local score = data.today.score
			local i = 0
			
			if score == 0 then
				local ibbtn = ptr_cast(Quit.score:GetChildByIndex(7))
				ibbtn.Text = score
			else
				while score > 0 do
					local ibbtn = ptr_cast(Quit.score:GetChildByIndex(7-i))
					ibbtn.Text = score % 10
					score = (score - (score % 10)) / 10
					i = i + 1
				end
			end
			score = data.today.exp
			i = 0
			if score == 0 then
				local ibbtn = ptr_cast(Quit.exp:GetChildByIndex(7))
				ibbtn.Text = score
			else
				while score > 0 do
					local ibbtn = ptr_cast(Quit.exp:GetChildByIndex(7-i))
					ibbtn.Text = score % 10
					score = (score - (score % 10)) / 10
					i = i + 1
				end
			end
			score = data.today.gp
			i = 0
			if score > 99999999 then
				score = 99999999
			end
			if score == 0 then
				local ibbtn = ptr_cast(Quit.gp:GetChildByIndex(7))
				ibbtn.Text = score
			else
				while score > 0 do
					local ibbtn = ptr_cast(Quit.gp:GetChildByIndex(7-i))
					ibbtn.Text = score % 10
					score = (score - (score % 10)) / 10
					i = i + 1
				end
			end
			--右上填充
			local level1 = L_LobbyMain.PersonalInfo_data.level % 10 --等级个位
			local level2 = (L_LobbyMain.PersonalInfo_data.level - level1) / 10 --等级十位
			local preson_level = math.floor((L_LobbyMain.PersonalInfo_data.level-1)/5)
			local percent
			if L_LobbyMain.PersonalInfo_data.level == 80 then
				percent = 1
				Quit.max.Visible = true
				Quit.lv_image.Visible = false
				Quit.small2_bg_ten.Visible = false
				Quit.small2_bg_one.Visible = false
			else
				percent = (L_LobbyMain.PersonalInfo_data.exp - L_LobbyMain.LevelInfo_rpc_data[L_LobbyMain.PersonalInfo_data.level][2]) / (L_LobbyMain.LevelInfo_rpc_data[L_LobbyMain.PersonalInfo_data.level + 1][2] - L_LobbyMain.LevelInfo_rpc_data[L_LobbyMain.PersonalInfo_data.level][2]) 
				percent = string.format("%.2f", percent)
				Quit.max.Visible = false
				Quit.lv_image.Visible = true
				Quit.small2_bg_ten.Visible = true
				Quit.small2_bg_one.Visible = true
			end
			
			local num = 5
			Quit.level_bg.Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/GameBalance/lb_exp_ico_" ..preson_level..".dds",Vector4(0, 0, 0, 0)),
			}
			
			Quit.big_bg_one.Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("InGameUI/lb_summary_number_6.dds",Vector4(0, 0, 0, 0),Vector4(level1 / 10, 0, (level1 + 1) / 10, 1)),
			}
			Quit.big_one.Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Icon("LobbyUI/WarZone/lb_summary_number_7.dds",Vector4(0, 0, 0, 0),Vector4(level1 / 10, 1 - (4 + percent * 112) / 120, (level1 + 1) / 10, 1.0)),
			}
			Quit.big_one.Size = Vector2(60, 105 * ( 4 + percent * 97) / 105)
			Quit.big_one.Location = Vector2(0, 105 * (1 - ( 4 + percent * 97) / 105))
			
			Quit.big_bg_ten.Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("InGameUI/lb_summary_number_6.dds",Vector4(0, 0, 0, 0),Vector4(level2 / 10, 0, (level2 + 1) / 10, 1)),
			}
			Quit.big_ten.Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Icon("LobbyUI/WarZone/lb_summary_number_7.dds",Vector4(0, 0, 0, 0),Vector4(level2 / 10, 1 - ( 4 + percent * 112) / 120, (level2 + 1) / 10, 1.0)),
			}
			Quit.big_ten.Size = Vector2(60, 105 * ( 4 + percent * 97) / 105)
			Quit.big_ten.Location = Vector2(0, 105 * (1 - ( 4 + percent * 97) / 105))
			Quit.small1_bg_ten.Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_summary_number_6b.dds",Vector4(0, 0, 0, 0),Vector4(level2 / 10, 0, (level2 + 1) / 10, 1)),
			}
			Quit.small1_ten.Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_summary_number_7b.dds",Vector4(0, 0, 0, 0),Vector4(level2 / 10, 0, (level2 + 1) / 10, 1)),
			}
			Quit.small1_bg_one.Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_summary_number_6b.dds",Vector4(0, 0, 0, 0),Vector4(level1 / 10, 0, (level1 + 1) / 10, 1)),
			}
			Quit.small1_one.Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_summary_number_7b.dds",Vector4(0, 0, 0, 0),Vector4(level1 / 10, 0, (level1 + 1) / 10, 1)),
			}
			level1 = (L_LobbyMain.PersonalInfo_data.level + 1) % 10
			level2 = ((L_LobbyMain.PersonalInfo_data.level + 1) - level1) / 10
			Quit.small2_bg_ten.Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_summary_number_6b.dds",Vector4(0, 0, 0, 0),Vector4(level2 / 10, 0, (level2 + 1) / 10, 1)),
			}
			Quit.small2_ten.Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_summary_number_7b.dds",Vector4(0, 0, 0, 0),Vector4(level2 / 10, 0, (level2 + 1) / 10, 1)),
			}
			Quit.small2_bg_one.Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_summary_number_6b.dds",Vector4(0, 0, 0, 0),Vector4(level1 / 10, 0, (level1 + 1) / 10, 1)),
			}
			Quit.small2_one.Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/WarZone/lb_summary_number_7b.dds",Vector4(0, 0, 0, 0),Vector4(level1 / 10, 0, (level1 + 1) / 10, 1)),
			}
			Quit.mark.Location = Vector2(49 + 160 * percent, 170)
			Quit.Percent.Text = (percent * 100).."%"
			Quit.bar.Size = Vector2(160 * percent, 13)
			score = L_LobbyMain.LevelInfo_rpc_data[L_LobbyMain.PersonalInfo_data.level + 1][2] - L_LobbyMain.PersonalInfo_data.exp
			i = 0
			if score == 0 then
				local ibbtn = ptr_cast(Quit.need_exp:GetChildByIndex(7))
				ibbtn.Text = score
			else
				while score > 0 do
					local ibbtn = ptr_cast(Quit.need_exp:GetChildByIndex(7-i))
					if ibbtn then
						ibbtn.Text = score % 10
					end
					score = (score - (score % 10)) / 10
					i = i + 1
				end
			end
			
			Quit.ctr_VIP.Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_bg_0"..L_Vip.Viplevel..".dds", Vector4(0, 0, 0, 0)),
			}
			
			Quit.ctr_VIP_num.Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/vip/vip/VIP_button_0"..L_Vip.Viplevel.."_normal.dds", Vector4(0, 0, 0, 0)),
			}
			
			if L_Vip.Viplevel == 0 then
				Quit.exp_bar.Size = Vector2(0, 25)
				Quit.vip_exp_text.Visible = true
				score = L_Vip.vip_exp[L_Vip.Viplevel+1]-L_Vip.Vipexp
			elseif L_Vip.now_box == 15 then
				Quit.exp_bar.Size = Vector2(220, 25)
				score = 0
				Quit.vip_exp_text.Visible = false
				Quit.vip_Label.Text = lang:GetText("已达到最高级")
			elseif L_Vip.Viplevel == L_Vip.VipMaxlevel - 1 then
				Quit.vip_Label.Text = lang:GetText("下一个宝箱需要经验：")
				Quit.vip_exp_text.Visible = false
				print("L_Vip.Vipexp = "..L_Vip.Vipexp)
				if (L_Vip.vip_box_exp[L_Vip.now_box]-L_Vip.Vipexp) <= 0 then
					Quit.exp_bar.Size = Vector2(220, 25)
					score = 0
				else
					if L_Vip.now_box == 1 then
						Quit.exp_bar.Size = Vector2((1 - ((L_Vip.vip_box_exp[L_Vip.now_box]-L_Vip.Vipexp) / (L_Vip.vip_box_exp[L_Vip.now_box] - L_Vip.vip_exp[8])))*220,25)
					else
						Quit.exp_bar.Size = Vector2((1 - ((L_Vip.vip_box_exp[L_Vip.now_box]-L_Vip.Vipexp) / (L_Vip.vip_box_exp[L_Vip.now_box] - L_Vip.vip_box_exp[L_Vip.now_box - 1])))*220,25)
					end
					score = (L_Vip.vip_box_exp[L_Vip.now_box]-L_Vip.Vipexp)
				end
			else
				Quit.vip_exp_text.Visible = false
				Quit.vip_Label.Text = lang:GetText("下一级需要经验：")
				Quit.exp_bar.Size = Vector2((1 - ((L_Vip.vip_exp[L_Vip.Viplevel+1]-L_Vip.Vipexp) / (L_Vip.vip_exp[L_Vip.Viplevel+1] - L_Vip.vip_exp[L_Vip.Viplevel])))*220,25)
				score = L_Vip.vip_exp[L_Vip.Viplevel+1] - L_Vip.Vipexp
			end
			
			i = 0
			if score == 0 then
				local ibbtn = ptr_cast(Quit.need_exp_vip:GetChildByIndex(7))
				ibbtn.Text = score
			else
				while score > 0 do
					local ibbtn = ptr_cast(Quit.need_exp_vip:GetChildByIndex(7-i))
					if ibbtn then
						ibbtn.Text = score % 10
					end
					score = (score - (score % 10)) / 10
					i = i + 1
				end
			end
			
			for j = i , 7 do
				local ibbtn = ptr_cast(Quit.need_exp_vip:GetChildByIndex(7-j))
				if ibbtn then
					if j == 0 then
						ibbtn.Text = "0"
					else
						ibbtn.Text = ""
					end
				end
			end
	
			--下方填充
			if L_LobbyMain.module_state.DailyMission.state == 0 then
				Quit.is_open.Visible = true
				Quit.re_msg:CleanAll()
				Quit.re_msg:AddMsg(lang:GetText("达成以下条件开启"),ARGB(255, 169, 163, 143),true,false)
				Quit.re_msg:AddMsg(lang:GetText("“每日任务、每周任务”"),ARGB(255,181, 51, 0),false,false)
				Quit.re_msg:AddMsg(lang:GetText("："),ARGB(255, 169, 163, 143),false,false)
				Quit.re_msg:AddMsg(lang:GetText("1．等级达到"),ARGB(255, 169, 163, 143),true,false)
				Quit.re_msg:AddMsg(13,ARGB(255,181, 51, 0),false,false)
				Quit.re_msg:AddMsg(lang:GetText("级  "),ARGB(255, 169, 163, 143),false,false)
				Quit.re_msg:AddMsg(lang:GetText("2．完成主线任务"),ARGB(255, 169, 163, 143),true,false)
				Quit.re_msg:AddMsg(lang:GetText("“最终试炼”"),ARGB(255,181, 51, 0),false,false)
			else
				Quit.is_open.Visible = false
				sum = data.num
				for i = 1, data.num do
					local ibbtn = ptr_cast(Quit.mission:GetChildByIndex(i - 1))
					ibbtn.Visible = true
					local ibbtn1 = ptr_cast(ibbtn:GetChildByIndex(1))
					ibbtn1.Skin = Gui.ControlSkin
					{
						BackgroundImage = Gui.Image("MapsAndBG/MapsIcon/"..data.mission[i][2]..".dds",Vector4(0, 0, 0, 0)),
					}
					ibbtn1 = ptr_cast(ibbtn:GetChildByIndex(2))
					if data.mission[i][7] == 1 then
						ibbtn1.Visible = true
					else
						ibbtn1.Visible = false
					end
					local ibbtn2 = ptr_cast(ibbtn:GetChildByIndex(3))
					ibbtn2.Text = data.mission[i][4]
					local ibbtn3 = ptr_cast(ibbtn:GetChildByIndex(4))
					if data.mission[i][5] < data.mission[i][6] then
						ibbtn3.Text = lang:GetText("已完成")..data.mission[i][5].."/"..data.mission[i][5]
					else
						ibbtn3.Text = lang:GetText("已完成")..data.mission[i][6].."/"..data.mission[i][5]
					end
				end
				for i = sum + 1, 7 do
					local ibbtn = ptr_cast(Quit.mission:GetChildByIndex(i - 1))
					ibbtn.Visible = false
				end
			end
			Quit.mission.Parent.Location =  Vector2(0, 0)
		end
	end)
end

function create_present_page(index)
	return Gui.ItemBoxBtn
	{
		Style = "Gui.ItemBoxBtn_Present",
		Size = Vector2(99, 101),
		Padding = Vector4(5, 5, 5, 5),
		
		EventMouseEnter = function(sender, e)
			if sender.Loading == false then
				L_ToolTips.FillToolTipsPresentWindow(index)
			end
		end,
		EventToolTipsShow = function(sender, e)
			local line = 0
			if index > 3 then
				line = 1
			else
				line = 0
			end
			L_ToolTips.ShowToolTipsShowWindow(sender,Vector2(800, 600),Vector2(248+math.ceil((index-1)%3)*110, 223+line*100))
		end,
		EventMouseLeave = function(sender, e)
			L_ToolTips.HideToolTipsWindow()
		end,
	}
end

Present = Gui.Create()
{
	Gui.Control "content"
	{
		Size = Vector2(800,610),
		Dock = "kDockCenter",
		BackgroundColor = ARGB(0, 0, 0, 0),
		
		Gui.Control
		{
			Size = Vector2(373,385),
			Location = Vector2(213, 112),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/open_box/main_bar01.dds",Vector4(20, 20, 20, 20)),
			},
			
			Gui.Control
			{
				Size = Vector2(343,355),
				Location = Vector2(15, 15),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/open_box/main_bar02.dds",Vector4(20, 20, 20, 20)),
				},
			},
			
			Gui.TextArea "text"
			{
				Size = Vector2(343, 60),
				Location = Vector2(15, 45),
				FontSize = 14,
				DisabledTextColor = ARGB(255, 255, 255, 255),
				Fold = true,
				Enable = false,
			},
			
			Gui.TextArea "ol_exp"
			{
				Size = Vector2(343, 60),
				Location = Vector2(15, 65),
				FontSize = 14,
				DisabledTextColor = ARGB(255, 255, 0, 0),
				Fold = true,
				Enable = false,
				Text = lang:GetText("经验奖励：0")
			},
			
			Gui.Control
			{
				Size = Vector2(335, 232),
				Location = Vector2(18, 87),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/open_box/main_bar03.dds", Vector4(10, 10, 10, 10)),
				},
				
				Gui.FlowLayout "list"
				{							
					Size = Vector2(328, 205),
					Location = Vector2(8, 9),
					ControlAlign = "kAlignCenterMiddle",
					ControlSpace = 12,
					LineSpace = 4,
					create_present_page(1),
					create_present_page(2),
					create_present_page(3),
				
					create_present_page(4),
					create_present_page(5),
					create_present_page(6),
				},
			},
			
			Gui.Button "BTN"
			{
				Size = Vector2(248,44),
				Location = Vector2(62, 322),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Enable = true,
				FontSize = 14,
				--blinkwheelTimer = 0.6,
				blink_shade = false,
				Skin = Gui.ButtonSkin
				{
					BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_normal.dds", Vector4(63, 0, 57, 0)),
					HoverImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_hover.dds", Vector4(63, 0, 57, 0)),
					DownImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_down.dds", Vector4(63, 0, 57, 0)),
					DisabledImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_disabled.dds", Vector4(63, 0, 57, 0)),
					TwinkleImage  = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_flash.dds", Vector4(63, 0, 57, 0)),
				},
				Text = lang:GetText("领取奖励"),
				TextColor = ARGB(255, 229, 255, 252),
				TextAlign = "kAlignCenterMiddle",
				HighlightTextColor = ARGB(255, 229, 255, 252),
				EventClick = function()
					if Presentmodal then
						Presentmodal.Close()
						Presentmodal = nil
					end
					rpc.safecall("online_award_get",{pid = ptr_cast(game.CurrentState):GetCharacterId()},
					function(data)
						if not data.error then
							if data.time >= 0 then
								L_LobbyMain.OLTime = data.time
								L_LobbyMain.LobbyMainWin_Header.Event:CleanAll()
								L_LobbyMain.LobbyMainWin_Header.Event:AddTime(1)
							elseif data.time ~= -2 then
								L_LobbyMain.OLTime = 0
							else
								L_LobbyMain.OLTime = -2
							end
							L_LobbyMain.OL_Award_List = data.items
							L_LobbyMain.FillPresent(data.award_time)
							Present.ol_exp.Text = lang:GetText("经验奖励：")..data.currentExp
							if L_Characters.main_props_window_ui then
								if L_LobbyMain.current_character_storage > 3 then
									L_LobbyMain.current_character_storage = L_Characters.current_selected_type[L_Characters.current_selected_type_index][1]
									L_LobbyMain.FillClassStorage(L_Characters.current_selected_type[L_Characters.current_selected_type_index][2])
								else
									L_LobbyMain.FillClassStorage()
								end
							end
							-- L_LobbyMain.current_character_storage = 1
							-- L_LobbyMain.FillClassStorage(0)
							-- L_LobbyMain.FillClassStorage()
							Show_PresentOK()
							gui:PlayAudio("kUIA_CONGRA_POP")
							L_LobbyMain.OnUpdateTime()
						end
					end)
				end
			},
		},
		
		Gui.Control
		{
			Size = Vector2(355,55),
			Location = Vector2(237,114),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ControlSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/ShoppingMall/open_box/title.dds", Vector4(0, 0, 0, 0)),
			},
		},
		
		Gui.Button "close"
		{
			Size = Vector2(48,48),
			Location = Vector2(556, 99),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_normal.dds", Vector4(0, 0, 0, 0)),
				HoverImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_hover.dds", Vector4(0, 0, 0, 0)),
				DownImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_down.dds", Vector4(0, 0, 0, 0)),
				DisabledImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_3_disabled.dds", Vector4(0, 0, 0, 0)),
			},
			EventClick = function()
				if Presentmodal then
					Presentmodal.Close()
					Presentmodal = nil
				end
			end
		},
	},
}

function Show_Present()
	Presentmodal = ModalWindow.GetNew()
	Presentmodal.root.Size = Vector2(800,610)
	Presentmodal.AllowEscToExit = false
	Present.content.Parent = Presentmodal.root
	if L_LobbyMain.OLTime <= 0 then
		Present.BTN.Enable = true
		Present.BTN.blink = true
	else
		Present.BTN.Enable = false
		Present.BTN.blink = false
	end
end

PresentOK = Gui.Create()
{
	Gui.Control "content"
	{
		Size = Vector2(488,288),
		Dock = "kDockCenter",
		BackgroundColor = ARGB(255, 255, 255, 255),
		Skin = Gui.ControlSkin
		{
			BackgroundImage = Gui.Image("LobbyUI/Compose/lb_synthesis_common_success.dds",Vector4(93, 179, 105, 73)),
		},
		
		Gui.Label
		{
			Size = Vector2(400, 150),
			Location = Vector2(44, 75),
			Text = lang:GetText("恭喜您获得了在线时长奖励，\n请去仓库查看"),
			FontSize = 20,
			TextColor = ARGB(255, 0, 0, 0),
			TextAlign = "kAlignCenterMiddle",
		},
		
		Gui.Button
		{
			Size = Vector2(124,44),
			Location = Vector2(182, 230),
			BackgroundColor = ARGB(255, 255, 255, 255),
			Enable = true,
			Skin = Gui.ButtonSkin
			{
				BackgroundImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_normal.dds", Vector4(63, 0, 57, 0)),
				HoverImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_hover.dds", Vector4(63, 0, 57, 0)),
				DownImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_down.dds", Vector4(63, 0, 57, 0)),
				DisabledImage = Gui.Image("LobbyUI/OL_award/lb_onlinetime_button_2_disabled.dds", Vector4(63, 0, 57, 0)),
			},
			Text = lang:GetText("确定"),
			TextColor = ARGB(255, 229, 255, 252),
			TextAlign = "kAlignCenterMiddle",
			HighlightTextColor = ARGB(255, 229, 255, 252),
			EventClick = function()
				if PresentOKmodal then
					PresentOKmodal.Close()
					PresentOKmodal = nil
				end
			end
		},
	},
}

function Show_PresentOK()
	PresentOKmodal = ModalWindow.GetNew()
	PresentOKmodal.root.Size = Vector2(488,288)
	PresentOKmodal.AllowEscToExit = false
	PresentOK.content.Parent = PresentOKmodal.root
end

function InitEscMenu()
	escWindow = ModalWindow.GetNew(1)
	escWindow.screen.AllowEscToExit = false
	escWindow.screen.Visible = false
	escWindow.screen.EventEscPressed = SwitchEscMenu
	gui.Focused = true
	escWindow.root.Size = Vector2(193, 270)
	escMenu.content.Parent = escWindow.root
	

	--web window
	WebWindow = ModalWindow.GetNew("WebWin")
	WebWindow.screen.AllowEscToExit = false
	WebWindow.screen.Visible = false
	WebWindow.screen.EventEscPressed = SwitchEscMenu
	WebWindow.root.Size = Vector2(606, 451)
	WebWin.web_Window.Parent = WebWindow.root
	
	--ReportWin Window
	ReportWindow = ModalWindow.GetNew("ReportWin")
	ReportWindow.screen.AllowEscToExit = false
	ReportWindow.screen.Visible = false
	ReportWindow.screen.EventEscPressed = SwitchEscMenu
	ReportWindow.root.Size = Vector2(514, 576)
	ReportWin.ReportWin_root.Parent = ReportWindow.root
	

	escMenu.cancel.EventClick = function()
		escWindow.screen.Visible = false
		gui.Focused = true
	end

	escMenu.setting.EventClick = function()
		escWindow.screen.Visible = false
		L_Settings.Show()
	end

	escMenu.character.EventClick = function()
		MessageBox.ShowWithConfirmCancel(lang:GetText("您确定要退出并返回登录界面吗？"),
			function(sender,e)
				L_LobbyMain.resetLobby = true
				L_LobbyMain.OnLogoutCharacter()
				game:LogoutCharacter()
				game:LogoutAccount()
			end,
		nil)
	end

	escMenu.quit.EventClick = function()
		MessageBox.ShowWithConfirmCancel(lang:GetText("您确定要退出并返回操作系统吗？"),
			function(sender,e)
				Thread.Quit()
			end,
		nil)
	end

	escMenu.faq.EventClick = function()		
		ShowWebWin()
	end
end

function DestroyEscMenu()
	escMenu.cancel.EventClick = nil
	escMenu.setting.EventClick = nil
	escMenu.character.EventClick = nil
	escMenu.quit.EventClick = nil
	escMenu.faq.EventClick = nil
	escMenu.content.Parent = nil
	escWindow.screen.EventEscPressed = nil
	escWindow:Close()
	escWindow=nil

	WebWin.web_Window.Parent = nil
	WebWindow.screen.EventEscPressed = nil
	WebWindow.Close()
	WebWindow=nil
	
	ReportWin.ReportWin_root.Parent = nil
	ReportWindow.screen.EventEscPressed = nil
	ReportWindow.Close()
	ReportWindow = nil
end

function SwitchEscMenu()
	L_ShoppingMall.reset()
	L_Characters.reset()
	--[[if WebWindow.screen.Visible == false and L_WarZone.current_state == 0 and L_LobbyMain.current_chosse_main_page == 5 then
		Show_QuitWin()
	end]]

	if WebWindow and WebWindow.screen then
		WebWindow.screen.Visible = false
	end
	DeleteAllReport()
end

function ShowWebWin()
	if WebWindow and WebWindow.screen then
		WebWindow.screen.Visible = not WebWindow.screen.Visible

		if WebWindow.screen.Visible then
			escWindow.screen.Visible = false
		end

	end
end

function gui.EventSizeChanged(sender,e)
	L_LobbyMain.AlignUI()
end

function gui.EventSizeChangedAdd()
	L_WarZone.WinSizeChange()
end

function state.EventLeave()
	L_LobbyMain.OnLeaveLobby()
	state.EventLeave = nil
	gui.EventSizeChanged = nil
	gui.EventEscPressed = nil
	--DestroyEscMenu()
	--Clear any unfinished modal window
	--ModalWindow.CloseAll()
	L_WarZone.Hide()
	--Tooltips隐藏
	L_ToolTips.HideToolTipsWindow()
	L_PersonalInfo.HideToolTipsWindow()
end

function state.EventSavePhoto()
	MessageBox.ShowWithTimer(1,lang:GetText("截图成功保存在游戏目录的pictures文件夹"))
end

function state.EventAddressChanged()
	--MessageBox.MessageBox.ShowWithConfirmCancel(lang:GetText("您与服务器已断开连接，程序将退出！"),
	--	function(sender,e)
	--		Thread.Quit()
	--	end,
	--nil)
end

--Application

--temp
getSubWindow = L_LobbyMain.getSubWindow
allSubWindowHide = L_LobbyMain.allSubWindowHide
--end temp

LobbyModules =
{
	--左侧
	L_Mail,--邮件
	L_FightTeam,--战队
	L_Friends,--好友
	L_Chat,--聊天
	--中间
	L_WarZone,--战区
	L_Characters,--角色管理
	--右侧
	L_ShoppingMall,--商城
	L_BlackMarket,--黑市
	L_Compose,--合成
	L_TopList,--排行榜
	L_Options,--设置
	L_PersonalInfo,--个人详细信息
	L_Present,
	L_Shooting, -- 打靶
}

function state.EventInitUI()
	--init esc menu
	InitEscMenu()
	gui.EventEscPressed = SwitchEscMenu

	--init L_LobbyMain
	L_LobbyMain.OnEnterLobby()
end

function state.EventRestoreUI()
	--init esc menu
	InitEscMenu()
	gui.EventEscPressed = SwitchEscMenu

	--restore L_LobbyMain
	L_LobbyMain.OnRestoreLobby()
end

function state.EventOnDisconnected()
	L_LobbyMain.OnLogoutCharacter()
	L_LobbyMain.HideLobbyMainWindow()
end

function ShowReportWin(name,id)
	if L_LobbyMain.Channl_Enter == false then
		MessageBox.ShowWithTimer(1,lang:GetText("请先进入频道！"))
		return
	end
	if name == L_LobbyMain.PersonalInfo_data.name then
		MessageBox.ShowWithTimer(1,lang:GetText("您选中的是自己！"))
		return
	end
	DeleteAllReport()
	InitEscMenu()
	gui.EventEscPressed = SwitchEscMenu
	if ReportWindow and ReportWindow.screen then
		ReportWindow.screen.Visible = true
	end
	AddReport(name,id)
	SetReport_RadioCheckID(id,name)
end

function Fill_Report_Id(name,id)
	local a = Gui.Create()
	{
		Gui.RadioButton "t"
		{
			Size = Vector2(230, 20),
			FontSize = 14,
			TextColor = ARGB(255, 37, 37, 37),
			Text = name,
			ID = id,
		}
	}
	return a
end

function AddReport(name,id)
	local a = Fill_Report_Id(name,id)
	a.t.Parent = ReportWin.Report_Id
end

function SetReport_RadioCheckID(id,name)
	ReportWin.Report_Id.RadioCheckID = id
	Report_name = name
end

function DeleteAllReport()


	if ReportWin then
		ReportWin.Report_Id:DeleteTableAll()
	end
	if ReportWindow and ReportWindow.screen then
		ReportWindow.screen.Visible = false
	end
	ReportWin.tarea_Text.Text = ""
	Report_name = nil
	ReportWin.Report_sake.RadioCheckID = 1
end

