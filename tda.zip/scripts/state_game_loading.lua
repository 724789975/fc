-- function cache
local Vector3 = Vector3
local Vector2 = Vector2

-- current state
local state = ptr_cast(game.CurrentState)

-- loading progress
local progress_image = Gui.ProportionIcon("DefaultSkin/DefaultSkin_bar01_BG.dds", "DefaultSkin/DefaultSkin_bar01_content.dds", Vector4(16,0,16,0), Vector4(16,0,16,0))

--print("*****************"..state.map_name)
--[[
local Hints = 
{
	kTeam = "",
	kHoldPoint = "",
	kPushVehicle = "",
}
]]
math.randomseed(os.clock())

local ClewText =
{
	{
		lang:GetText("小提示：在游戏中，您可以按键盘上z、x、c，呼出无线电菜单"),
		lang:GetText("小提示：在游戏中选择职业将会在下次重生以后生效"),
		lang:GetText("小提示：在游戏中按“b”键可更换职业"),
		lang:GetText("小提示：您在游戏中战斗获得的积分越多，在结算时就可能获得更多的翻牌机会"),
		lang:GetText("小提示：地图中的医疗包和弹药包拾取过后每隔一段时间会重新刷新"),
		lang:GetText("小提示：记住医疗包和弹药包有利于您在战场上存活更长时间"),
		lang:GetText("小提示：拾取地图中的医疗包可以熄灭身上的火焰"),
		lang:GetText("小提示：拾取敌人掉落的武器可以补充自己的弹药喔！"),
		lang:GetText("小提示：您可以在个人信息界面里更换自己的头像"),
		lang:GetText("小提示：点击“查看详情”按钮可以查看你的个人信息"),
		lang:GetText("小提示：在好友列表中可以右键点击好友，选择与好友一起游戏"),
		lang:GetText("小提示：游戏内按esc键可以呼出“你提我改”界面"),
		lang:GetText("小提示：当玩家被踢出房间后，该房间一段时间内无法再次进入"),
		lang:GetText("小提示：只有在3人以上的房间才能记录成就所需的条件喔"),
		lang:GetText("小提示：在游戏设置中可对狙击手以及突击手主武器开镜后的灵敏度进行单独调整"),
		lang:GetText("小提示：在第一次进入对战前最好先去训练关了解下每个职业的特性"),
		lang:GetText("小提示：在占点和推车模式中，只有胜利的一方才能拾取掉落的金币！"),
		lang:GetText("小提示：占点模式中，.一旦占领了据点，即使不站在据点范围内时间也会倒数。"),
		lang:GetText("小提示：占点模式中，在据点范围内的同伴越多占点速度就会越快！"),
		lang:GetText("小提示：推车模式中，在运输车周围的同伴越多运输车的移动速度就会越快！"),
		lang:GetText("小提示：推车模式中，在运输车周围会得到弹药和血量补给。"),
		lang:GetText("小提示：歼灭模式中，单回合内玩家无法复活"),
		lang:GetText("小提示：团队竞技模式中，多兵种配合会更容易取得胜利！"),
		lang:GetText("小提示：刀战模式中，和队友一起行动才是生存之道"),
		-- lang:GetText("小提示：英雄模式中，只要你击杀了对方的英雄，下回合你就一定会成为本队英雄"),
		lang:GetText("小提示：英雄模式中，如果对方的人数越多，己方的英雄也会越强大"),
		lang:GetText("小提示：英雄模式中，如果你拿刀，可以无限复活，如果你拿枪的话要小心，你没有机会复活"),
		lang:GetText("小提示：爆破模式中，无论是埋雷还是拆雷前，一定要先确定你的周围没有敌人"),
		lang:GetText("小提示：爆破模式中，雷包的爆炸时间很短，在得知雷包已被埋下后要赶紧前去拆雷"),
		lang:GetText("小提示：如果你是埋雷方，随时观察持雷包队友的位置，以便保护其安全埋雷"),
		lang:GetText("小提示：如果你是拆雷方，在击杀对方持雷包敌人后，守住掉落的雷包是胜利的关键"),
		lang:GetText("小提示：当房间内玩家数不多的时候，记得邀请你的好友一起来游戏"),
		lang:GetText("小提示：根据当前战斗形势选择适当的职业以取得战场上的优势！"),
		lang:GetText("小提示：部分兵种道具有冷却时间，冷却完毕以后可重复使用！"),
		lang:GetText("小提示：火箭炮有是范围伤害，所以瞄准对方的脚底或是旁边的墙壁是不错的选择"),
		lang:GetText("小提示：使用战鼓时，周围的同伴同样会得到攻击加成的效果"),
		lang:GetText("小提示：重机枪手的血量是最多的，尽量站在前面为队友抵挡攻击吧！"),
		lang:GetText("小提示：转轮枪远距离伤害很低，近距离的伤害很高！"),
		lang:GetText("小提示：转轮枪按住右键可以进行热枪，热枪状态时可以随时开火！"),
		lang:GetText("小提示：如果使用重机枪手进攻时远处有狙击手或突击手的话还是绕道走比较好"),
		lang:GetText("小提示：重机枪手使用奶瓶时无法移动和攻击。所以藏在不被人发现的角落再使用吧！"),
		lang:GetText("小提示：狙击枪开镜时充电槽满格的时候，威力最大！"),
		lang:GetText("小提示：狙击手使用狙击枪击中敌人头部能给予致命伤害！"),
		lang:GetText("小提示：狙击手很脆弱，尽量不要处于交火区域的最前线"),
		lang:GetText("小提示：突击手属于战斗支援型职业，所以尽量和同伴一起行动吧"),
		lang:GetText("小提示：突击手使用自动步枪时可以按鼠标右键开镜瞄准以获得更稳定的射击"),
		lang:GetText("小提示：突击手按数字键“4”可选择投掷类武器"),
		lang:GetText("小提示：突击手使用自动步枪击中敌人头部能给予极大伤害！"),
		lang:GetText("小提示：使用喷火枪时弹药消耗的很快。所以在战斗时要时刻注意自己的弹量"),
		lang:GetText("小提示：喷火枪可以对敌人造成持续的燃烧伤害！"),
		lang:GetText("小提示：使用喷火枪时，按右键可以为队友熄灭身上的火焰"),
		lang:GetText("小提示：喷火枪的射击距离有限。抓准时机近距离偷袭对手是很有效的战术"),
		lang:GetText("小提示：火焰弹发射器射出的火焰弹飞的越远伤害越高！"),
	},
	{
		lang:GetText("小提示：每局游戏之后别忘记去任务界面查看完成进度或是领取奖品哦！"),
		lang:GetText("小提示：游戏商城内购买武器后会自动装备"),
		lang:GetText("小提示：随意搭配您的衣服、帽子和徽章，打造自己个性化的角色吧！"),
		lang:GetText("小提示：在商城页面中，您可以用右键随意拖拽物品到人物身上来预览和装备"),
		lang:GetText("小提示：在个人仓库页面里，您可以用右键随意拖拽物品到人物身上来装备物品"),
		lang:GetText("小提示：经常在好友列表中使用右键菜单中的“查看信息”功能以关注好友动态"),
		lang:GetText("小提示：风车小镇的小巷通常是交火密集区域"),
		lang:GetText("小提示：乡间伐木场的地下通道是进入高楼二楼的捷径"),
		lang:GetText("小提示：法老神殿中的坡路会导致运输车下滑"),
		lang:GetText("小提示：boss战中，boss的某些技能会造成灼烧及鼠标反转等特殊效果"),
		lang:GetText("小提示：在游戏中按“f“键可以呼叫医生，使附近的医疗兵玩家知道你受伤了"),
		lang:GetText("小提示：每天登陆游戏后别忘记点击“每日签到“以及”免费领取“哦"),
		lang:GetText("小提示：累计一定数量的“每日签到“可以获得丰厚的奖励"),
		lang:GetText("小提示：保持一定时间的在线时长可以获得丰厚的奖励"),
		lang:GetText("小提示：在“参战名单“中可以选择最喜欢的5个职业进入游戏"),
		lang:GetText("小提示：强化武器和装备可以大幅提升你的战斗力"),
		lang:GetText("小提示：各职业的特殊武器不能被强化"),
		lang:GetText("小提示：只能对永久时限的基础白色装备进行强化"),
		lang:GetText("小提示：尽可能多的获取“强化部件“，因为他是强化过程中必不可少的道具"),
		lang:GetText("小提示：“增幅装置“可以有效的提高强化时的成功几率"),
		lang:GetText("小提示：只有同类型的装备可以进行转换，但是可以是不同职业的"),
	},
	{
		lang:GetText("小提示：装备的物品过期的情况下，进入游戏时会自动替换为初始装备"),
		lang:GetText("小提示：邮件系统将会对您快过期的物品进行提示"),
		lang:GetText("小提示：每日任务可以让您在游戏过程中获得更多奖励"),
		lang:GetText("小提示：在游戏中投票踢人只能选取本方阵营的玩家"),
		lang:GetText("小提示：角色等级达到20级后可创建战队"),
		lang:GetText("小提示：“每日任务”和“每周任务”是帮助你获得各种道具的最好途径"),
		lang:GetText("小提示：完成任务后记得去领取奖励哦"),
		lang:GetText("小提示：来预测每天的幸运数字试试你的运气吧"),
		lang:GetText("小提示：武器装备每强化一定等级，外观都会变得更为炫丽"),
		lang:GetText("小提示：武器装备每强化一定等级，都会相应的增加1个属性槽位"),
		lang:GetText("小提示：在强化高级装备时记得使用“安定装置“来减少风险"),
		lang:GetText("小提示：如果幸运的获得了“强化增幅装置“，一定记得在最重要的时候去使用它"),
		lang:GetText("小提示：在属性槽位插入属性部件需要先对该槽位进行打孔，插入合理的属性部件会使战斗力更上一层楼"),
		lang:GetText("小提示：属性部件在被插入时会随机产生一种属性，如果对属性不满意可以点击“移除“来清除该属性"),
		lang:GetText("小提示：转换系统可以把一件装备上的强化等级和属性部件完全的转换到另一件装备上"),
	},
	-- lang:GetText("小提示：在游戏中，您可以按键盘上Z、X、C，呼出无线电菜单"),							--1
	-- lang:GetText("小提示：在游戏中选择职业将会在下次重生以后生效"),									--2
	-- lang:GetText("小提示：在游戏中按“B”键可更换职业"),
	-- lang:GetText("小提示：装备的物品过期的情况下，进入游戏时会自动替换为初始装备"),
	-- lang:GetText("小提示：邮件系统会对您快过期的物品进行提示"),
	-- lang:GetText("小提示：每日任务可以让您在游戏过程中获得更多奖励"),
	-- lang:GetText("小提示：在游戏中投票踢人只能选取本方阵营的玩家"),									--3
	-- lang:GetText("小提示：您在游戏中战斗获得的积分越多，在结算时就可能获得更多的宝箱"),				--4
	-- lang:GetText("小提示：地图中的医疗包和弹药包拾取过后每隔一段时间会重新刷新"),						--5
	-- lang:GetText("小提示：记住医疗包和弹药包有利于您在战场上存活更长时间"),							--6
	-- lang:GetText("小提示：拾取地图中的医疗包可以熄灭身上的火焰"),										--7
	-- lang:GetText("小提示：拾取敌人掉落的武器可以补充自己的弹药喔！"),
	-- lang:GetText("小提示：每局游戏之后别忘记去任务界面查看完成进度或是领取奖品哦！"),					--8
	-- lang:GetText("小提示：您可以在个人信息界面里更换自己的头像"),										--9
	-- lang:GetText("小提示：点击“查看详情”按钮可以查看你的个人信息"),
	-- lang:GetText("小提示：在好友列表中可以右键点击好友，选择与好友一起游戏"),
	-- lang:GetText("小提示：游戏商城内购买武器后会自动装备"),
	-- lang:GetText("小提示：角色等级达到20级后可创建战队"),
	-- lang:GetText("小提示：游戏内按ESC键可以呼出“你提我改”界面"),
	-- lang:GetText("小提示：当玩家被踢出房间后，该房间一段时间内无法再次进入"),
	-- lang:GetText("小提示：在游戏设置中可对狙击手以及突击手主武器开镜后的灵敏度进行单独调整"),	
	-- lang:GetText("小提示：在商城页面中，您可以用右键随意拖拽物品到人物身上来预览和装备"),				--10
	-- lang:GetText("小提示：在个人仓库页面里，您可以用右键随意拖拽物品到人物身上来装备物品"),			--11
	-- lang:GetText("小提示：经常在好友列表中使用右键菜单中的“查看信息”功能以关注好友动态"),				--12
	-- lang:GetText("小提示：随意搭配您的衣服、帽子和徽章，打造自己个性化的角色吧！"),					--13
	-- lang:GetText("小提示：在第一次进入对战前最好先去训练关了解下每个职业的特性"),						--14
	-- lang:GetText("小提示：只有在6人以上的房间才能记录成就所需的条件喔！"),
	-- lang:GetText("小提示：只有在6人以上的房间才能记录任务所需的数据喔！"),
	-- lang:GetText("小提示：在占点和推车模式中，只有胜利的一方才能拾取掉落的金币！"),					--15
	-- lang:GetText("小提示：占点模式中，一旦占领了据点，即使不站在据点范围内时间也会倒数。"),			--16
	-- lang:GetText("小提示：占点模式中，在据点范围内的同伴越多占点速度就会越快！"),						--17
	-- lang:GetText("小提示：推车模式中，在运输车周围的同伴越多运输车的移动速度就会越快！"),				--18
	-- lang:GetText("小提示：推车模式中，在运输车周围会得到弹药和血量补给。"),							--19
	-- lang:GetText("小提示：歼灭模式中，单回合内玩家无法复活"),
	-- lang:GetText("小提示：团队竞技模式中，多兵种配合会更容易取得胜利！"),
	-- lang:GetText("小提示：刀战模式中，和队友一起行动才是生存之道"),
	-- lang:GetText("小提示：根据当前战斗形势选择适当的职业以取得战场上的优势！"),						--20
	-- lang:GetText("小提示：部分兵种道具有冷却时间，冷却完毕以后可重复使用！"),
	-- lang:GetText("小提示：火箭炮是范围伤害，所以瞄准对方的脚底或是旁边的墙壁是不错的选择"),			--21
	-- lang:GetText("小提示：使用战鼓时，周围的同伴同样会得到攻击加成的效果"),							--22
	-- lang:GetText("小提示：重机枪手的血量是最多的，尽量站在前面为队友抵挡攻击吧！"),						--23
	-- lang:GetText("小提示：转轮枪远距离伤害很低，近距离的伤害很高！"),									--24
	-- lang:GetText("小提示：转轮枪按住右键可以进行热枪，热枪状态时可以随时开火！"),
	-- lang:GetText("小提示：如果使用重机枪手进攻时远处有狙击手或突击手的话还是绕道走比较好"),			--25
	-- lang:GetText("小提示：重机枪手使用奶瓶时无法移动和攻击。所以藏在不被人发现的角落再使用吧！"),		--26
	-- lang:GetText("小提示：狙击枪开镜时充电槽满格的时候，威力最大！"),									--27
	-- lang:GetText("小提示：狙击手使用狙击枪击中敌人头部能给予致命伤害！"),								--28
	-- lang:GetText("小提示：狙击手很脆弱，尽量不要处于交火区域的最前线"),								--29
	-- lang:GetText("小提示：突击手属于战斗支援型职业，所以尽量和同伴一起行动吧"),						--30
	-- lang:GetText("小提示：突击手使用自动步枪时可以按鼠标右键开镜瞄准以获得更稳定的射击"),				--31
	-- lang:GetText("小提示：突击手使用自动步枪击中敌人头部能给予极大伤害！"),							--32
	-- lang:GetText("小提示：使用喷火枪时弹药消耗的很快。所以在战斗时要时刻注意自己的弹量"),				--33
	-- lang:GetText("小提示：喷火枪可以对敌人造成持续的燃烧伤害！"),
	-- lang:GetText("小提示：使用喷火枪时，按右键可以为队友熄灭身上的火焰"),
	-- lang:GetText("小提示：喷火枪的射击距离有限。抓准时机近距离偷袭对手是很有效的战术"),				--35
	-- lang:GetText("小提示：火焰弹发射器射出的火焰弹飞的越远伤害越高！"),								--36
	-- lang:GetText("小提示：风车小镇的小巷通常是交火密集区域"),
	-- lang:GetText("小提示：乡间伐木场的地下通道是进入高楼二楼的捷径"),
	-- lang:GetText("小提示：法老神殿中的坡路会导致运输车下滑"),
}
local num = 0
local n = 0
if L_LobbyMain.PersonalInfo_data.level < 6 then
	n = 1
elseif L_LobbyMain.PersonalInfo_data.level < 11 then
	n = 2
else
	n = 3
end
num = math.random(table.getn(ClewText[n]))
-- login window
local ui = Gui.Create
{
	Gui.FlowLayout
	{
		Dock = "kDockFill",
		Align = "kAlignCenterBottom",

		Gui.Picture "background"
		{
			Style = "",
			BackgroundColor = ARGB(255,0,0,0),
			Dock = "kDockFill",
			ForeGroundImage = Icons.GetLoadingMap(state.map_name, state.gameMode),
			--Expand = true,
			KeepAspect = true,	
			Gui.Picture
			{
				-- Size = Vector2(1680, 512),
				Dock = "kDockFill",
				BackgroundColor = ARGB(255, 255, 255, 255),
				ForeGroundImage = Gui.Image("MapsAndBG/Loading/loadingmap_xunzhang.dds"),
				KeepAspect = true,	
				
			},
			
			Gui.Label "Hint"
			{
				FontSize = 20,
				Text = ClewText[n][num],
				TextColor = ARGB(255, 191, 189, 184),
				TextAlign = "kAlignLeftTop",
				AutoWrap = true,
				BackgroundColor = ARGB(0, 255, 255, 255),
			},
			
			Gui.Label "MAP_name_bg"
			{
				FontSize = 26,
				Text = L_WarZone.map_show_name_of_key[state.map_name],
				TextColor = ARGB(255, 50, 50, 50),
				TextAlign = "kAlignCenterMiddle",
				AutoWrap = true,
				BackgroundColor = ARGB(0, 255, 255, 255),
			},
			
			Gui.Label "MAP_name"
			{
				FontSize = 26,
				Text = L_WarZone.map_show_name_of_key[state.map_name],
				TextColor = ARGB(255, 250, 250, 250),
				TextAlign = "kAlignCenterMiddle",
				AutoWrap = true,
				BackgroundColor = ARGB(0, 255, 255, 255),
			},
			
			Gui.Control "bg"
			{
				Size = Vector2(288, 56),
				Location = Vector2(60, 300),
				BackgroundColor = ARGB(255, 255, 255, 255),
				Skin = Gui.ControlSkin
				{
					BackgroundImage = Gui.Image("DefaultSkin/DefaultSkin_bar01_BG.dds", Vector4(0, 0, 0, 0)),
				},
			},
			
			Gui.Control "content"
			{
				Size = Vector2(0, 0),
				Location = Vector2(60, 300),
				BackgroundColor = ARGB(255, 255, 255, 255),
			},
		},


		-- Gui.Control
		-- {
			-- Size = Vector2(1100, 65),
			-- Margin = Vector4(0, 0, 0, 50),
	
			-- Gui.Label
			-- {
				-- Style = "Transparent",
				-- Size = Vector2(math.ceil(gui.Size.x/3), math.ceil(gui.Size.y/40) + 18),
				-- Icon = progress_image,
				-- Dock = "kDockTopCenter",
			-- },
		-- }
	},
}

ui.background.EventSizeChanged = function()
	local Window_Aspect = ui.background.Size.x/ui.background.Size.y
	local Picture_Aspect = 1680/1052
	if Picture_Aspect > Window_Aspect then
		ui.Hint.Location = Vector2(ui.background.Size.x*(92.0/1680),(ui.background.Size.x/Picture_Aspect)*(259.0/1052) +((ui.background.Size.y - ui.background.Size.x/Picture_Aspect)/2 + 0.5))
		ui.Hint.Size = Vector2(ui.background.Size.x*(347.0/1680),(ui.background.Size.x/Picture_Aspect)*(227.0/1052))
		ui.MAP_name.Location = Vector2(ui.background.Size.x*(565.0/1680),(ui.background.Size.x/Picture_Aspect)*(50.0/1052) +((ui.background.Size.y - ui.background.Size.x/Picture_Aspect)/2 + 0.5))
		ui.MAP_name.Size = Vector2(ui.background.Size.x*(558.0/1680),(ui.background.Size.x/Picture_Aspect)*(40.0/1052))
		ui.bg.Location = Vector2(ui.background.Size.x*(696.0/1680),(ui.background.Size.x/Picture_Aspect)*(677.0/1052) +((ui.background.Size.y - ui.background.Size.x/Picture_Aspect)/2 + 0.5))
		ui.bg.Size = Vector2(ui.background.Size.x*(288.0/1680),(ui.background.Size.x/Picture_Aspect)*(56.0/1052))
	elseif Picture_Aspect < Window_Aspect then
		ui.Hint.Location = Vector2(ui.background.Size.y*Picture_Aspect*(92.0/1680) + ((ui.background.Size.x - ui.background.Size.y*Picture_Aspect)/2 + 0.5),ui.background.Size.y*(259.0/1052))
		ui.Hint.Size = Vector2(ui.background.Size.y*Picture_Aspect*(347.0/1680),ui.background.Size.y*(227.0/1052))
		ui.MAP_name.Location = Vector2(ui.background.Size.y*Picture_Aspect*(565.0/1680) + ((ui.background.Size.x - ui.background.Size.y*Picture_Aspect)/2 + 0.5),ui.background.Size.y*(50.0/1052))
		ui.MAP_name.Size = Vector2(ui.background.Size.y*Picture_Aspect*(558.0/1680),ui.background.Size.y*(40.0/1052))
		ui.bg.Location = Vector2(ui.background.Size.y*Picture_Aspect*(696.0/1680) + ((ui.background.Size.x - ui.background.Size.y*Picture_Aspect)/2 + 0.5),ui.background.Size.y*(677.0/1052))
		ui.bg.Size = Vector2(ui.background.Size.y*Picture_Aspect*(288.0/1680),ui.background.Size.y*(56.0/1052))
	else
		ui.Hint.Location = Vector2(ui.background.Size.x*(92.0/1680),ui.background.Size.y*(259.0/1052))
		ui.Hint.Size = Vector2(ui.background.Size.x*(347.0/1680),ui.background.Size.y*(227.0/1052))
		ui.MAP_name.Location = Vector2(ui.background.Size.x*(565.0/1680),ui.background.Size.y*(50.0/1052))
		ui.MAP_name.Size = Vector2(ui.background.Size.x*(558.0/1680),ui.background.Size.y*(40.0/1052))
		ui.bg.Location = Vector2(ui.background.Size.x*(696.0/1680),ui.background.Size.y*(677.0/1052))
		ui.bg.Size = Vector2(ui.background.Size.x*(288.0/1680),ui.background.Size.y*(56.0/1052))
	end
	ui.MAP_name_bg.Location = Vector2(ui.MAP_name.Location.x + 2,ui.MAP_name.Location.y + 2)
	ui.MAP_name_bg.Size = ui.MAP_name.Size
	ui.content.Location = ui.bg.Location
	ui.content.Size = Vector2(ui.bg.Size.x*state.Progress,ui.bg.Size.y)
end

function state.EventLeave()
	Gui.Clear(ui)
	ui = nil
	state.EventLeave = nil
	state.EventProgressMove = nil
	state = nil
end

function state.EventProgressMove()
	-- progress_image.Proportion = state.Progress
	ui.content.Size = Vector2(ui.bg.Size.x*state.Progress, ui.bg.Size.y)
	ui.content.Skin = Gui.ControlSkin{BackgroundImage = Gui.Image("DefaultSkin/DefaultSkin_bar01_content.dds", Vector4(0, 0, 0, 0),Vector4(0, 0, state.Progress, 1))}
end
