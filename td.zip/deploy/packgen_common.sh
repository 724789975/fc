#!/bin/sh

VERSION_DIR=$1

# common.pde
mkdir $VERSION_DIR/common
mv -f $VERSION_DIR/data/version $VERSION_DIR/common/version
mv -f $VERSION_DIR/data/language $VERSION_DIR/common/language
mv -f $VERSION_DIR/data/common $VERSION_DIR/common/common
mv -f $VERSION_DIR/data/lod $VERSION_DIR/common/lod
pack.exe $VERSION_DIR/common $VERSION_DIR/common.pde
