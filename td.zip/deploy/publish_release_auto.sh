#!/bin/sh

BUILD_DIR=../code/build
DIR=../`date +%Y_%m_%d_%H_%M`

mkdir -p $DIR

echo "copy files..."
cp -rf  $BUILD_DIR/release/client.exe $DIR
cp -rf  ./release_data/* $DIR
cp -rf  $BUILD_DIR/release/client.pdb $DIR


mv -f ../cache/ $DIR


echo "package files..."
Rar -m0 a $DIR.rar $DIR

echo "copy to server..."
mv -f  $DIR/cache/ ../cache/ 
cp -rf $DIR.rar //server1/OTO2/�ͻ���/ 

echo "$DIR.rar update success..."

rm -rf $DIR





