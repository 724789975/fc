#!/bin/sh

BUILD_DIR=../code/build
CACHE_DIR=../cache
PUBLISH_DIR=${1:-192.168.5.4::o2o_share}

rsync -av --delete "$CACHE_DIR/" "$PUBLISH_DIR/data"
rsync -vdt --delete --exclude 'data' --exclude 'plug-ins' "$BUILD_DIR/release/" "$PUBLISH_DIR"

echo "Release version published to $PUBLISH_DIR"
