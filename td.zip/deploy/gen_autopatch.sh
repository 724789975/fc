#!/bin/sh
WORK_DIR=${1:-../../master}
OLD_DIR=$WORK_DIR/old
NEW_DIR=$WORK_DIR/new

OLD_VERSION=`cat $OLD_DIR/data/version`
NEW_VERSION=`cat $NEW_DIR/data/version`

[ -z "$OLD_VERSION" ] && exit 1
[ -z "$NEW_VERSION" ] && exit 1
[ "$OLD_VERSION" == "$NEW_VERSION" ] && exit 1

echo "Generating autopatch $OLD_VERSION - $NEW_VERSION"

PATCH_NAME="patch-$OLD_VERSION-$NEW_VERSION"
CURRENT_DIR="$WORK_DIR/patch/$PATCH_NAME"
VERSION_DAT="$WORK_DIR/patch/ver.dat"
PATCH_FILE="$CURRENT_DIR/$PATCH_NAME.zip"

mkdir -p $CURRENT_DIR

New_DirCompair_0813.exe "$OLD_DIR" "$NEW_DIR" $CURRENT_DIR/$PATCH_NAME
rm -f $CURRENT_DIR/plist.txt
7z.exe a -tzip $PATCH_FILE $CURRENT_DIR/$PATCH_NAME/* -r
rm -fr $CURRENT_DIR/$PATCH_NAME

echo "generating md5..."
MD5VALUE=`md5 $PATCH_FILE | sed -nr 's/([0-9A-F]+).*/\1/p'` 
printf "!$PATCH_NAME.zip\t$MD5VALUE" >"$CURRENT_DIR/plist.txt"

if [ ! -e "$VERSION_DAT" ]; then
cat >$VERSION_DAT <<EOF
[Info]
VersionBegin=$OLD_VERSION

[Default]
Version=$OLD_VERSION
EOF
fi

sed -r "s/^Version=.+$/Version=$NEW_VERSION/"  -i $VERSION_DAT
echo "$OLD_VERSION=$NEW_VERSION|$PATCH_NAME/plist.txt|0,0" >>$VERSION_DAT

rsync -av --delete $NEW_DIR/ $OLD_DIR
