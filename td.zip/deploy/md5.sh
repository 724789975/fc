#!/bin/sh

VERSION=$1
cd ../../master/$VERSION

md5sum ./FinalCombat.exe
md5sum ./finalcombat.pde

echo  $'\n'

ls -lh|grep finalcombat.pde 

echo $VERSION

echo  $'\n'

echo "//client_package/full_package/ver_$VERSION/"
