#!/bin/sh

function convert_path()
{
sed '
s:\\:/:g
/\.svn/ d
s/..\/data//
s/\(^.*$\)/"\1",/
'
}

function gen_shader_list()
{
	VD9_LIST="vs.fx"
	PD9_LIST="ps.fx ps_lod_0.fx ps_lod_1.fx ps_lod_2.fx ps_postprocess.fx"

	for file in $VD9_LIST; do
		sed -nr '
		s#^[a-zA-Z0-9_]+[ \t]+([a-zA-Z0-9_]+)[ \t]*\(.*\) : POSITION#/shader/\1.vd9#p
		s#^.+_VS_.+[ \t]+([a-zA-z0-9_]+)\(.*\)#/shader/\1.vd9#p
		s#^void[ \t]+([a-zA-z0-9_]+)\(.*\)#/shader/\1.vd9#p
		' ../data/shader/$file
	done

	for file in $PD9_LIST; do
		sed -nr 's#^(half4|float4)[ \t]+([a-zA-Z0-9_]+)[ \t]*\(.*\) : (COLOR0|POSITION)#/shader/\2.pd9#p' ../data/shader/$file
	done
}

echo "resource = {"
gen_shader_list | convert_path
find ../data/shader -type f -name "*.vd9" | convert_path
find ../data/shader -type f -name "*.pd9" | convert_path
echo "}"

echo "physx = {"
echo "}"

echo "copy = {"
echo "}"
