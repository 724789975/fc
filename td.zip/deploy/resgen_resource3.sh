#!/bin/sh

function convert_path()
{
sed '
s:\\:/:g
/\.svn/ d
s/..\/data//
s/\(^.*$\)/"\1",/
'
}

echo "resource = {"
find ../data/skeleton -type f | convert_path
echo "}"

echo "physx = {"
find ../data/mesh/scene/level* -type f -name "*.mesh" | convert_path
echo "}"

echo "copy = {"
echo "}"
