#!/bin/sh

VERSION=$1
FTP_ADDRESS=123.150.185.14
FTP_USER_NAME=dcf
FTP_USER_PASSWORD=1mkW9SUy



wput -v ../../master/$VERSION/FinalCombat.exe ftp://$FTP_USER_NAME:$FTP_USER_PASSWORD@$FTP_ADDRESS//client_package/full_package/ver_$VERSION/FinalCombat.exe
wput -v ../../master/$VERSION/finalcombat.pde ftp://$FTP_USER_NAME:$FTP_USER_PASSWORD@$FTP_ADDRESS//client_package/full_package/ver_$VERSION/finalcombat.pde


