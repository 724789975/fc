#!/bin/sh

function convert_path()
{
sed '
s:\\:/:g
/\.svn/ d
s/..\/data//
s/\(^.*$\)/"\1",/
'
}

echo "resource = {"
echo "}"

echo "physx = {"
echo "}"

echo "copy = {"
find ../data/audio -type f | convert_path
echo "}"
