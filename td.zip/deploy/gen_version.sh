#!/bin/sh

VERSION="1.0."
REVISION=0
TITLEVISION=0

REV_CODE=`svn info ../code | sed -nr 's/Last Changed Rev: ([0-9]+)/\1/p'`
REV_DATA=`svn info ../data | sed -nr 's/Last Changed Rev: ([0-9]+)/\1/p'`

[ $REV_CODE -gt $REVISION ] && REVISION=$REV_CODE
[ $REV_DATA -gt $REVISION ] && REVISION=$REV_DATA

TITLEVISION=`expr $REVISION / 10000`
REVISION=`expr $REVISION % 10000`


if (( $REVISION < 10 ))
then
	echo "$VERSION$TITLEVISION.000$REVISION"

else if ((  $REVISION < 100 ))
then 
	echo "$VERSION$TITLEVISION.00$REVISION"


else if ((  $REVISION < 1000 ))
then 
	echo "$VERSION$TITLEVISION.0$REVISION"
else
	echo "$VERSION$TITLEVISION.$REVISION"
fi
fi
fi



