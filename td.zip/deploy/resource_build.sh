#!/bin/sh

CODE_DIR=$1
DATA_DIR=$2
DEPENDENCE=$3
TARGET=$4

./resgen_$TARGET.sh >$DATA_DIR/cache_$TARGET.lua

$CODE_DIR/build/builder/client.exe -dependence $DEPENDENCE -exec gen_$TARGET.lua >gen_$TARGET.log

rm $DATA_DIR/cache_$TARGET.lua
