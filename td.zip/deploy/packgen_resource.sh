#!/bin/sh

VERSION_DIR=$1

# resource.pde
mkdir $VERSION_DIR/resource
mv -f $VERSION_DIR/data/animation $VERSION_DIR/resource/animation
mv -f $VERSION_DIR/data/mesh $VERSION_DIR/resource/mesh
mv -f $VERSION_DIR/data/skeleton $VERSION_DIR/resource/skeleton
pack.exe $VERSION_DIR/resource $VERSION_DIR/resource.pde
