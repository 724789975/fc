#terrible code....
import os
import sys
filesArray = [] 

photoshop = ''
targetPath = ''
checkList = []
numList = []


def ReadSetting():
    setDir = os.path.dirname(sys.argv[0])
    s1 = open(setDir + '\\setting.inf' , 'r')
    global photoshop 
    photoshop = s1.readline().strip()
    global targetPath
    targetPath = s1.readline().strip()
    

def dfs(path):
    aa = os.listdir(path)
    for i in aa:
        if (i != '.svn') and (i != '.mayaSwatches'):
            if ( not os.path.isdir(path+i) ):
                if ( (path+i).lower().split(".")[-1] == 'dds' ):
                    filesArray.append(path+i)
            else:
                dfs(path + i + '\\')


def doit():
    dfs(targetPath)
    global checkList
    global numList
    for i in range(len(filesArray)):
	numList.append(0)
        for j in range(len(filesArray)):
            if (i != j) and (filesArray[i] != '' and filesArray[j] != '') and (os.path.basename(filesArray[i]) == os.path.basename(filesArray[j])):
		checkList.append(filesArray[j])
		numList[i] = numList[i] + 1
                filesArray[j] = ''
	if (numList[i] != 0):
		checkList.append(filesArray[i])

def printIt ():
    global numList
    global checkList
    numCount = 0
    for i in range(len(numList)):
	if numList[i] != 0:
	    print str(i) + ' : '
	    for j in range(numList[i]+1):
		print '\t' + str(checkList[numCount])
		numCount = numCount + 1

		
def getType():
    global numList
    global checkList
    
    id = -1
    while id == -1 :
	try:
	    id = int(raw_input('Type ID:\n').strip())
	except:
	    id = -1
	numCount = 0
	if id != -1:
	    for i in range(len(numList)):
		if numList[i] != 0 :
		    for j in range(numList[i]+1):
			if (i == id):
			    #print '\t' + str(checkList[numCount])
			    os.popen(photoshop + ' ' + checkList[numCount])
			numCount = numCount + 1
	    #for i in range(len(numList)):
		#if (i != id):
		    #numCount = numCount + numList[i]
		    #continue
		#if numList[i] != 0:
		    #print str(i) + ' : '
		    #for j in range(numList[i]+1):
			#os.popen(photoshop + ' ' + checkList[j+numCount] )
			#print checkList[numCount]
			#numCount = numCount + 1
	id = -1
    
ReadSetting()
doit()
printIt()
getType()
