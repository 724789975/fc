#!/bin/sh

CACHE_DIR=../cache
BUILD_DIR=../code/build
MASTER_DIR=../../master
PUBLISH_DIR=192.168.5.1::o2o_patch
PACK_NAME=finalcombat.pde
PACK_PATH=../$PACK_NAME
CODE_DIR=../code

# make a clean rebuild
[ -e $CACHE_DIR ] && rm -fr $CACHE_DIR
[ -e $BUILD_DIR ] && rm -fr $BUILD_DIR/master

# generate version info
VERSION=`./gen_version.sh`
printf $VERSION >../data/version
printf "const char * client_version = \"$VERSION\";" >../code/client/version.cpp

# create empty pack
#printf "" >$PACK_PATH

echo "Building..."
./build_lang.sh Master || exit 1

mv "$CODE_DIR/build/master/client.exe" "$CODE_DIR/build/master/FinalCombat.exe"

cp -f ../data/language $CACHE_DIR/language
cp -f ../scene.mesh.cache $CACHE_DIR/mesh/scene/level7/scene.mesh.cache

# backup exe and pdb file
mkdir -p $MASTER_DIR/pdb
mv -f $BUILD_DIR/master/client.pdb $MASTER_DIR/pdb/FinalCombat.$VERSION.pdb
cp -af $BUILD_DIR/master/FinalCombat.exe $MASTER_DIR/pdb/FinalCombat.$VERSION.exe

echo "generating new version..."
VERSION_DIR=$MASTER_DIR/$VERSION
mkdir -p $VERSION_DIR
rsync -vrt --delete --exclude 'plug-ins' --exclude '*.pdb' "$BUILD_DIR/master/" "$VERSION_DIR"
#mv "$PACK_PATH" "$VERSION_DIR/$PACK_NAME"
mv -f $CACHE_DIR $VERSION_DIR
mv -f $VERSION_DIR/cache $VERSION_DIR/data

echo "generating package..."
pack.exe $VERSION_DIR/data $VERSION_DIR/finalcombat.pde

echo "generating autopatch..."
# generate autopatch
#./gen_autopatch.sh || exit 1

echo "Master version build finished."
