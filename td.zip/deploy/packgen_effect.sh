#!/bin/sh

VERSION_DIR=$1

# effect.pde
mkdir $VERSION_DIR/effect
mv -f $VERSION_DIR/data/decal $VERSION_DIR/effect/decal
mv -f $VERSION_DIR/data/spray $VERSION_DIR/effect/spray
mv -f $VERSION_DIR/data/vfx $VERSION_DIR/effect/vfx
pack.exe $VERSION_DIR/effect $VERSION_DIR/effect.pde
