#!/bin/sh
WORK_DIR=$1
WORK_DIR=${WORK_DIR:=../../master}
OLD_DIR=old
NEW_DIR=new

pushd $WORK_DIR

OLD_VERSION=`cat $OLD_DIR/data/version`
NEW_VERSION=`cat $NEW_DIR/data/version`

[ -z "$OLD_VERSION" ] && exit 1
[ -z "$NEW_VERSION" ] && exit 1
[ "$OLD_VERSION" == "$NEW_VERSION" ] && exit 1

echo "Generating autopatch $OLD_VERSION - $NEW_VERSION"

PATCH_NAME="patch-$OLD_VERSION-$NEW_VERSION"
PATCH_DIR="patch/$PATCH_NAME"
VERSION_DAT="patch/ver.dat"
PLIST_TXT="$PATCH_DIR/plist.txt"
FLIST_TXT="$PATCH_DIR/flist.txt"

mkdir -p "$PATCH_DIR"

function diff_list()
{
diff -rq $OLD_DIR $NEW_DIR | sed -nr "
s|^Only in ($OLD_DIR.*): (.+)|\1/\2|p
s|^Only in ($NEW_DIR.*): (.+)|\1/\2|p
s|^Files $OLD_DIR(.+) and ($NEW_DIR.+) differ|\2|p
" 
}

function file_list()
{
	while read line; do
		if [ -d "$line" ]; then
			find "$line" -type f
		else
			echo "$line"
		fi
	done
}

function process_file()
{
	case "$1" in
		$NEW_DIR/*)
			FILE=${1#$NEW_DIR/}
			echo A $FILE
			echo $FILE >>$FLIST_TXT
			#MD5=`md5 "$1"`
			#printf "$FILE\t${MD5:0:32}\t\r\n" >>$PLIST_TXT
		;;

		$OLD_DIR/*)
			FILE=${1#$OLD_DIR/}
			MD5=`md5 "$1"`
			echo D $FILE
			printf "~$FILE\t${MD5:0:32}\t\r\n" >>$PLIST_TXT
		;;
	esac
}

function process()
{
	printf "" >$PLIST_TXT
	printf "" >$FLIST_TXT

	while read line; do
		process_file "$line"
	done
	
	#rsync -v "--files-from=$FLIST_TXT" "$NEW_DIR" "$PATCH_DIR/"
	pushd new
	rm -f "../$PATCH_DIR/$PATCH_NAME.zip"
	7z a -tzip -scsWIN "../$PATCH_DIR/$PATCH_NAME.zip" "@../$FLIST_TXT"
	popd

	MD5=`md5 "$PATCH_DIR/$PATCH_NAME.zip"`
	printf "!$PATCH_NAME.zip\t${MD5:0:32}\t\r\n" >>$PLIST_TXT
	sed -r "s|/|\\\\|g" -i "$PLIST_TXT"

	rm -fr "$FLIST_TXT"
}

diff_list | file_list | process

if [ ! -e "$VERSION_DAT" ]; then
cat >$VERSION_DAT <<EOF
[Info]
VersionBegin=$OLD_VERSION

[Default]
Version=$OLD_VERSION
EOF
fi

sed -r "s/^Version=.+$/Version=$NEW_VERSION/"  -i $VERSION_DAT
echo "$OLD_VERSION=$NEW_VERSION|$PATCH_NAME/plist.txt|0,0" >>$VERSION_DAT

rsync -av --delete $NEW_DIR/ $OLD_DIR
