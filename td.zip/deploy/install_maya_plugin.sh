#!/bin/sh

PLUGIN_PATH=$PROJECT_PATH/tools/maya_plugin

[ ! -x $PLUGIN_PATH/bin ] && mkdir -p $PLUGIN_PATH/bin
[ ! -x $PLUGIN_PATH/scripts ] && mkdir -p $PLUGIN_PATH/scripts

cp -f "$SOURCE_PATH/code/build/release/plug-ins/*.mll" "$PLUGIN_PATH/bin"
cp -f "$SOURCE_PATH/code/editor/scripts/*.mel" "$PLUGIN_PATH/scripts"
