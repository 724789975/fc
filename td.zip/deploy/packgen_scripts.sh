#!/bin/sh

VERSION_DIR=$1

# scripts.pde
mkdir $VERSION_DIR/scripts
mv -f $VERSION_DIR/data/character $VERSION_DIR/scripts/character
mv -f $VERSION_DIR/data/level $VERSION_DIR/scripts/level
mv -f $VERSION_DIR/data/weapon $VERSION_DIR/scripts/weapon
mv -f $VERSION_DIR/data/scripts $VERSION_DIR/scripts/scripts
pack.exe $VERSION_DIR/scripts $VERSION_DIR/scripts.pde
