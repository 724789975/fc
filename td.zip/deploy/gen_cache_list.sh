#!/bin/sh

function convert_path()
{
sed '
s:\\:/:g
/\.svn/ d
s/..\/data//
s/\(^.*$\)/"\1",/
'
}

function gen_shader_list()
{
	VD9_LIST="vs.fx"
	PD9_LIST="ps.fx ps_lod_0.fx ps_lod_1.fx ps_lod_2.fx ps_postprocess.fx"

	for file in $VD9_LIST; do
		sed -nr '
		s#^[a-zA-Z0-9_]+[ \t]+([a-zA-Z0-9_]+)[ \t]*\(.*\) : POSITION#/shader/\1.vd9#p
		s#^.+_VS_.+[ \t]+([a-zA-z0-9_]+)\(.*\)#/shader/\1.vd9#p
		s#^void[ \t]+([a-zA-z0-9_]+)\(.*\)#/shader/\1.vd9#p
		' ../data/shader/$file
	done

	for file in $PD9_LIST; do
		sed -nr 's#^(half4|float4)[ \t]+([a-zA-Z0-9_]+)[ \t]*\(.*\) : (COLOR0|POSITION)#/shader/\2.pd9#p' ../data/shader/$file
	done
}

echo "resource = {"
gen_shader_list | convert_path
find ../data -type f -name "*.dds" -or -type f -name "*.tga" | convert_path
find ../data/skeleton -type f -name "*.skel" | convert_path
find ../data/mesh -type f -name "*.mesh" | convert_path
find ../data/vfx -type f -name "*.vfx" | convert_path
find ../data/weapon ../data/character ../data/mesh/scene ../data/level ../data/scripts -type f -name "*.lua" | convert_path
find ../data/mesh/scene -type f -name "*.occ" | convert_path
find ../data/animation -type f -name "*.anim" | convert_path
find ../data/shader -type f -name "*.vd9" | convert_path
find ../data/shader -type f -name "*.pd9" | convert_path
find ../data/decal -type f -name "*.dcl" | convert_path
find ../data/spray -type f -name "*.dds" -or -type f -name "*.spr" | convert_path
echo "}"

echo "physx = {"
find ../data/mesh/scene -type f -name "*.mesh" | convert_path
echo "}"

echo "copy = {"
echo "\"/version\","
find ../data/audio ../data/fonts ../data/flash -type f | convert_path
echo "}"
