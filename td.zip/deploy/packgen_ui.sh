#!/bin/sh

VERSION_DIR=$1

# ui.pde
mkdir $VERSION_DIR/ui
mv -f $VERSION_DIR/data/flash $VERSION_DIR/ui/flash
mv -f $VERSION_DIR/data/fonts $VERSION_DIR/ui/fonts
mv -f $VERSION_DIR/data/ui $VERSION_DIR/ui/ui
mv -f $VERSION_DIR/data/lang $VERSION_DIR/ui/lang
pack.exe $VERSION_DIR/ui $VERSION_DIR/ui.pde
