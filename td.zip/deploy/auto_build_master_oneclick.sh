#!/bin/sh

CACHE_DIR=../cache
BUILD_DIR=../code/build
MASTER_DIR=../../master
PUBLISH_DIR=192.168.5.1::o2o_patch
PACK_NAME=finalcombat.pde
PACK_PATH=../$PACK_NAME
CODE_DIR=../code

# generate version info
VERSION=`./gen_version.sh`

./auto_build_master_ssd.sh

echo "generate md5 ...."
rm -rf ./mail.txt
./md5.sh $VERSION > mail.txt

echo "generate mail ...."
./mail.sh $VERSION


echo "update ftp files ...."
./ftp.sh $VERSION


echo "all finished ...."
cat mail.txt