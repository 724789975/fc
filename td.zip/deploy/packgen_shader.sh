#!/bin/sh

VERSION_DIR=$1

# shader.pde
mkdir $VERSION_DIR/shader
mv -f $VERSION_DIR/data/shader $VERSION_DIR/shader/shader
pack.exe $VERSION_DIR/shader $VERSION_DIR/shader.pde
