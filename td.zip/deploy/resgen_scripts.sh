#!/bin/sh

function convert_path()
{
sed '
s:\\:/:g
/\.svn/ d
s/..\/data//
s/\(^.*$\)/"\1",/
'
}

echo "resource = {"
find ../data/weapon -type f | convert_path
find ../data/character -type f | convert_path
find ../data/level -type f | convert_path
find ../data/scripts -type f | convert_path
echo "}"

echo "physx = {"
echo "}"

echo "copy = {"
echo "}"
