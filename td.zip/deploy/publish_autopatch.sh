#!/bin/sh

MASTER_DIR=../../master
PUBLISH_DIR=${1:-192.168.5.1::o2o_patch}

# publish autopatch
rsync -av "$MASTER_DIR/patch/" "$PUBLISH_DIR"
