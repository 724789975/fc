#!/bin/sh

VERSION=$1

DATE=`date +%Y_%m_%d`

blat -install auth.smtp.1and1.co.uk  lizheng@pearldigital.com
blat ./mail.txt -to  zengming@pearldigital.com  -u  lizheng@pearldigital.com  -pw zheng123123  -subject  $DATE_version_$VERSION

