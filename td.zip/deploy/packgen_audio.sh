#!/bin/sh

VERSION_DIR=$1

# audio.pde
mkdir $VERSION_DIR/audio
mv -f $VERSION_DIR/data/audio $VERSION_DIR/audio/audio
pack.exe $VERSION_DIR/audio $VERSION_DIR/audio.pde
