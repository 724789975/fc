#!/bin/sh

function convert_path()
{
sed '
s:\\:/:g
/\.svn/ d
s/..\/data//
s/\(^.*$\)/"\1",/
'
}

echo "resource = {"
find ../data/mesh -type f | convert_path
echo "}"

echo "physx = {"
echo "}"

echo "copy = {"
echo "}"
