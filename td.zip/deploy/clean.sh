#!/bin/sh
rm -fr ../code/build
rm -fr ../cache
