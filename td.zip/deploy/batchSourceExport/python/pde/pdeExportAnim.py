#!/usr/bin/env python
import os
import sys
import re
import maya.cmds as mc
import maya.mel as mm
PDEANIMTYPE = []
PDEANIMVIEW = []
PDEANIMCHARACTER = []
PDEANIMPROPS = []#['mk18','m1911','m82','mg3','mp7']
PDEFSTANIMSEQS = [] #['change','idle','reload','shoot','runforward','pelt','stab','lightstab']
PDETHDCOMANIMSEQS = []
PDETHDANIMSEQS = []
gPdeFstPropSeqs = []
def matchSeqName(matchSeqs,matchLine,split):
    isMatch = 0
    matchWord = r'(.*'+split+')(('
    for eachSeq in matchSeqs  :
        matchWord += str(eachSeq).lower()
        matchWord += '|'
    matchWord += r'))'+split+'.*'
    matchSen = re.compile(matchWord)
    matchGrp = matchSen.match(str(matchLine).lower())
    if matchGrp:
        return str(matchGrp.group(2))
    return ''
            
class pdeExportAnim:
    def __init__(self,value):
        if len(value):
            self.path = value
            self.matchPath = str(value).lower()
            matchGrp = re.match(r'^(.*)(Animation)/*',self.path)
            self.root = matchGrp.group(0)
            self.type = matchSeqName(self.PDEANIMTYPE,self.matchPath,'/')
            self.view = matchSeqName(self.PDEANIMVIEW,self.matchPath,'/')
            self.character = matchSeqName(self.PDEANIMCHARACTER,self.matchPath,'/')
            self.prop = matchSeqName(self.PDEANIMPROPS,self.matchPath,'/')
            
            self.seq = ''
            self.bCommon = 0
            if not self.seq:
                self.seq = matchSeqName(self.PDEFSTANIMSEQS,self.matchPath,'_')
            if not self.seq:
                self.seq = matchSeqName(self.PDETHDCOMANIMSEQS,self.matchPath,'_')
                if (self.prop == 'mk18') and (self.seq ):
                    self.bCommon = 1
            if not self.seq:
                self.seq = matchSeqName(self.PDETHDANIMSEQS,self.matchPath,'_')
            
            
            self.exportRoot = ''
            
        else :
            self.path = ''
            self.matchPath = ''
            self.type = ''
            self.view = ''
            self.character = ''
            self.prop = ''
            self.root = ''
            self.exportRoot = ''
            self.bCommon = 0
    def getPath(self):
        return self.path
    
    def isValid(self):
        #print [' | exportRoot : '+self.exportRoot+ ' | type : '+self.type+"/"+' | view : '+
            #self.view+"/"+' | character : '+self.character+"/"+' | prop : '+self.prop+"/"+' | seq : '+self.seq]
        if self.character and self.prop and self.seq and self.type and self.view :
            return 1
        else: return 0
        
    def getExportPath(self):
        return self.exportRoot+ self.type+"/"+self.view+"/"+self.character+"/"+self.prop+"/"+self.seq
    def setThdPerComSeqs(seqs):
        PDETHDCOMANIMSEQS = seqs
        print PDETHDCOMANIMSEQS
    def getThdPerComSeqs():
        print PDETHDCOMANIMSEQS
        return PDETHDCOMANIMSEQS
    
    def export(self):
        mc.file( self.path, force = 1,  ignoreVersion = 1,  type = "mayaBinary" ,open = True )
        if (self.seq in self.gPdeFstPropSeqs) and (self.view == "firstperson"):
            selecPropJoint = ''
            shapes = mc.listRelatives('prop')
            for each in shapes:
                    if mc.nodeType( each , api=True ) == 'kJoint' :
                            selecPropJoint = each
                            break
            if selecPropJoint: 
                mc.select(selecPropJoint ,r=1)
                exportPath = self.exportRoot+ "prop/"+ self.prop +"/"+ self.seq
                evalCmd = 'pdeExportAnimation -f \"'+str(exportPath)+'\"'
                #print 'prop anim seq is ' + exportPath
                mm.eval(evalCmd)
        mc.select('root',r = 1)
        if self.bCommon:
            exportPath = self.exportRoot+ self.type+"/"+self.view+"/"+self.character+"/"+"common"+"/"+self.seq
        else:
            exportPath = self.exportRoot+ self.type+"/"+self.view+"/"+self.character+"/"+self.prop+"/"+self.seq
        
        evalCmd = 'pdeExportAnimation -f \"'+str(exportPath)+'\"'
        mm.eval(evalCmd)
        pass