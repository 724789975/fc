#!/bin/sh

CACHE_DIR=../cache
BUILD_DIR=../code/build
RELEASE_DIR=../../release

# generate version info
VERSION=`./gen_version.sh`
rm -f $CACHE_DIR/version
printf $VERSION >../data/version
printf "const char * client_version = \"$VERSION\";" >../code/client/version.cpp

echo "Building $VERSION..."
./build_lang.sh Release || exit 1
./gen_build_log.sh >$CACHE_DIR/build.log

cp -f ../data/language $CACHE_DIR/language
# backup exe and pdb file
mkdir -p $RELEASE_DIR/pdb
cp -f $BUILD_DIR/release/client.pdb $RELEASE_DIR/pdb/client.$VERSION.pdb
cp -af $BUILD_DIR/release/client.exe $RELEASE_DIR/pdb/client.$VERSION.exe

echo "Release version build finished : $VERSION"
