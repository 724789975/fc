#!/bin/sh

function convert_path()
{
sed '
s:\\:/:g
/\.svn/ d
s/..\/data//
s/\(^.*$\)/"\1",/
'
}

echo "resource = {"
find ../data/common -type f | convert_path
find ../data/lod -type f | convert_path
echo "}"

echo "physx = {"
echo "}"

echo "copy = {"
echo "\"/version\","
echo "}"
