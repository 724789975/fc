#!/bin/sh

TARGET=$1
TARGET=${TARGET:=Release}

CODE_DIR=../code
DATA_DIR=../data
BUILD_DIR=../code/build

mkdir $BUILD_DIR

# copy dlls to build dir
rsync -rtv --exclude '.svn' "$CODE_DIR/sdk/dll/" "$CODE_DIR/build/release"

# run gen cache script
DEPENDENCE=1
if [ "$TARGET" == "Master" ]; then
	DEPENDENCE=0
fi

rm -rf $BUILD_DIR/builder/
cp -rf builder/ $BUILD_DIR/

# build
if [ "$TARGET" == "Master" ]; then
	echo "Build Master..."
	# clean target
	rm -fr "$CODE_DIR/build/master"
	msbuild.exe $CODE_DIR/game.sln /p:Configuration=Master /nologo  /v:d &
else
	echo "Build Release..."
	# clean target
	#rm -fr "$CODE_DIR/build/release"
	msbuild.exe $CODE_DIR/game.sln /p:Configuration=Release /nologo  /v:d &
fi

echo "Generating cache..."
# gen cache list
./resource_build.sh $CODE_DIR $DATA_DIR $DEPENDENCE "common" &
./resource_build.sh $CODE_DIR $DATA_DIR $DEPENDENCE "audio" &
./resource_build.sh $CODE_DIR $DATA_DIR $DEPENDENCE "ui" &
./resource_build.sh $CODE_DIR $DATA_DIR $DEPENDENCE "effect" &
./resource_build.sh $CODE_DIR $DATA_DIR $DEPENDENCE "shader" &
./resource_build.sh $CODE_DIR $DATA_DIR $DEPENDENCE "scripts" &
./resource_build.sh $CODE_DIR $DATA_DIR $DEPENDENCE "resource1" &
./resource_build.sh $CODE_DIR $DATA_DIR $DEPENDENCE "resource2" &
./resource_build.sh $CODE_DIR $DATA_DIR $DEPENDENCE "resource3" &

wait

rm -rf $BUILD_DIR/builder/

if [ "$?" != "0" ]; then
	echo error while building cache.
	exit 1
fi

echo "Generate cache finished"


if [ "$?" != "0" ]; then
	echo error while building master.
	exit 1
fi

# copy runtime to master dir
rsync -rtv --exclude '.svn' "$CODE_DIR/sdk/redist/" "$CODE_DIR/build/master"
