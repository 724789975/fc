#!/bin/sh

get_rev()
{
	sed -nr 's/Last Changed Rev: ([0-9]+)/\1/p'
}

while [ "1"=="1" ]; do
	BASE_REVISION=`svn info ../ -r BASE | get_rev`
	HEAD_REVISION=`svn info ../ -r HEAD | get_rev`

	if [ "$BASE_REVISION" != "$HEAD_REVISION" ]; then
		echo "New revision dectected. updating..."
		svn up ../
		
		./clean.sh
		./auto_build_release.sh
		./publish_release.sh
	fi

	sleep 600
done
