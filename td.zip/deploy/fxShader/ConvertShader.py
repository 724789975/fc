#!/usr/bin/env python

import sys
import os , re , copy
import historyLog
#******************************************************
# read configer file and get need values
#******************************************************
configFileName = r'convertConfiger'
configFile = open(configFileName,'r')
configFileDict = {}

for line in configFile.readlines():
    
    splits = str(line.rstrip()).split(' , ')
    dictValue = []
    for split in splits[1:]:
        dictValue.append(split)
    configFileDict[str(splits[0]).rstrip()] = dictValue
configFile.close()

def getConfigValue(attributeName,configDict):
    allKeys = configDict.keys()
    attribute = []
    for key in allKeys:
        if str(key) == attributeName :
            attribute = configDict[key]
    return attribute


fxShaderDir = getConfigValue("FxShaderDir",configFileDict)[0] #fxShader file folder
shaderImportPath = getConfigValue("ShaderImportPath",configFileDict)[0] #.fx file folder
shaderOutputPath = getConfigValue("ShaderOutputPath",configFileDict)[0] #game shader file folder
psCompileFile = getConfigValue("PsCompileFile",configFileDict) #need compile ps file
vsCompileFile = getConfigValue("VsCompileFile",configFileDict) #need compile vs file
shaderTempPath = getConfigValue("ShaderTempPath",configFileDict)[0]#temp compile shader file folder

psPost = '.pd9' 
vsPost = '.vd9' 
vsFile = vsCompileFile
psFile = psCompileFile
shaderPath = shaderImportPath
#******************************************************
#create need compile shader list
#******************************************************
listFilePath = fxShaderDir + "/shader_list" 
shaderFiles = []
listFile = open(listFilePath , "w")
for eachFile in psFile:
    
    openPath = shaderPath   + eachFile
    
    file = open(openPath , 'r')
    
    for line1 in file:
        matchLine1 = re.match('^(half|float)4 (.*)\(.*\) : (COLOR0|POSITION)',line1.lstrip())
        if matchLine1:
            shaderFileName = matchLine1.group(2)
            fixName = "".join(shaderFileName).strip()
            
            listFile.write( fixName + psPost +'\n')
    file.close()
for eachFile in vsFile:
    openPath = shaderPath + '/' + eachFile
    file = open(openPath , 'r')
    for line in file:
        matchLine = re.match('(.* (.*)\(.*\) : POSITION)|(.*_VS_.* (.*)\(.*\)|(^void (.*)\(.*\)))' , line)
        if matchLine :
            
            if matchLine.group(2)  :
                writeVSName = matchLine.group(2)
            elif matchLine.group(4):
                writeVSName =  matchLine.group(4)
            elif matchLine.group(6):
                writeVSName =  matchLine.group(6)
            listFile.write( writeVSName + vsPost +'\n')
listFile.close()

#******************************************************
#Use ShaderCompile.exe to compile 
#******************************************************
os.system("ShaderCompile.exe shader_list")

#******************************************************
# copy update shader file to game data folder 
#******************************************************
tempFilePath = shaderTempPath
walkPaths = os.walk(tempFilePath) 
root = ''
folders = []
files = []
allFiles = []
allFolders = []
noIncludeFolders = ['.svn','.mayaSwatches']

for walkPath in walkPaths :
    root,folders,files = walkPath
    validFolders = []
    i = 0
    isNotValidRoot = 0
    for each in noIncludeFolders:
        if  each in root:
            isNotValidRoot = 1
            break
    if not isNotValidRoot:
        for file in files:
            allFiles.append( os.path.join(root,file))
            
for eachFile in allFiles :
    fileNameToks = eachFile.split("/")
    fileName = fileNameToks[len(fileNameToks)-1]

sourceFilePath = shaderTempPath
targetFilePath = shaderOutputPath
historyLog.readHistoryLog()

if os.path.isdir(sourceFilePath) != True:
    print 'Error: source is not a directory'
    exit()
k=0
filelist = os.listdir(sourceFilePath)
print len(filelist)
t = 0
for name in filelist :
    if name.find('pd9') == -1 and name.find('vd9') == -1 :
        del(filelist[t])
    t = t + 1

for name in filelist :
    historyLog.fileName = sourceFilePath  + name
    
    if historyLog.needUpdate() :
        print name
        srcFilename = sourceFilePath + "\\" + name
        srcFilename = '"' + srcFilename + '"'
        desFilename = targetFilePath  + "\\" + name
        desFilename = '"' + desFilename + '"'
        
        copy_command = "copy %s %s" % (srcFilename, desFilename)
        #print copy_command
        if os.system(copy_command) == 0:
            k = k + 1
            print 'Successful backup to copy from', srcFilename, 'to' ,desFilename
        else:
            print 'Fail to copy', srcFilename, 'to', desFilename

historyLog.updateHistoryLog()





