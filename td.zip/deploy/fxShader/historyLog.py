#!/usr/bin/env python
#-*- coding:UTF-8 -*-
#! 记录文件处理条目及时间

import sys
import os
import re
import copy
import time

logFilePath = r'pdeHistoryLog.txt'
fileName = r'pdeHistoryLog.txt'
historyLogs  = {}



def setFileName( file ) :
    global fileName
    fileName = file.rstrip().lstrip()
    
def clearHistoryLog():
    openFile = open(logFilePath , 'w')
    openFile.close()
def newHistoryLog():
    openFile = open(logFilePath , 'w')
    openFile.close()
    
def getFileUpdateDate(fileName):
    return os.path.getmtime( fileName )

def readHistoryLog():
    global historyLogs
    if os.path.exists(logFilePath):
        openFile = open( logFilePath , 'r')
        allLines = {}
        for line in openFile :
            if not re.match('^$',line) :
                line = line.rstrip().lstrip()
                lineSplits = line.split('||')
                allLines[lineSplits[0].rstrip().lstrip()] = lineSplits[1].rstrip().lstrip()
        historyLogs = allLines
    else:
        newHistoryLog()
        historyLogs = {}
    

def isExistsFile():
    global historyLogs
    allHistory = historyLogs
    #print historyLogs
    for key  in allHistory :
        if fileName == key:
            return True
    return False
 
def addHistoryLog():
    global fileName
    openFile = open( logFilePath , 'a')
    fileDate = getFileUpdateDate(fileName)
    writeData = fileName + " || " + str(fileDate) + '\n'
    openFile.write( writeData )
    openFile.close

def writeHistoryLog():
    if not os.path.exists(fileName) :
        print fileName + ' is nor exists ! '
        return False
    addHistoryLog( )
    
def needUpdate():
    global historyLogs
    global fileName
    allHistory = historyLogs
    if isExistsFile() :
        if allHistory[fileName] == str(getFileUpdateDate(fileName)) :
            return False
        else :
            print 'different date'
            allHistory[fileName] = str(getFileUpdateDate(fileName))
            return True
    else:
        allHistory[fileName] = str(getFileUpdateDate(fileName))
        return True

def replaceHistoryLog():
    global fileName
    global historyLogs
    allHistory = historyLogs
    if isExistsFile() :
        allHistory[fileName] = getFileUpdateDate(fileName)
    openFile = open( logFilePath , 'w')
    for eachFile in allHistory :
        setFileName(eachFile)
        writeHistoryLog()
    openFile.close()
 
def updateHistoryLog():
    global historyLogs
    
    openFile = open( logFilePath , 'w')
    for key in historyLogs:
        fileDate = getFileUpdateDate(key)
        writeData = key + " || " + str(fileDate) + '\n'
        openFile.write( writeData )
    openFile.close()
    



