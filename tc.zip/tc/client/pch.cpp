#include "pch.h"

// directx
#pragma comment(lib, "dxerr.lib" )
#pragma comment(lib, "dxguid.lib" )
#pragma comment(lib, "d3d9.lib" )

#pragma comment(lib, "nvapi.lib")

#if defined(DEBUG) || defined(_DEBUG)
#pragma comment(lib, "d3dx9d.lib" )
#else
#pragma comment(lib, "d3dx9.lib" )
#endif

/// fmod
#pragma comment(lib, "fmod_event.lib")
#pragma comment(lib, "fmodex_vc.lib")
//#pragma comment(lib, "fmod_static.lib")
//#pragma comment(lib, "fmod_event_static.lib")
//#pragma comment(lib, "celt_static.lib" )
//#pragma comment(lib, "libFLAC_static.lib" )
//#pragma comment(lib, "msacm32.lib" )

// physix
#pragma comment(lib, "PhysXLoader.lib")
//#pragma comment(lib, "PhysXCore.lib")
#ifndef MASTER
#pragma comment(lib, "PhysXCooking.lib")
#endif

#ifdef USE_WEB
#if defined(DEBUG) || defined(_DEBUG)
#pragma comment(lib, "libcefd.lib" )
#else
#pragma comment(lib, "libcef.lib" )
#endif
#endif
//#pragma comment(lib, "VMProtectSDK32.lib")
