#include "pch.h"
#include <string>
#include <time.h>
using namespace Core;
using namespace Gui;
using namespace Client;

DEFINE_PDE_TYPE_CLASS(Gui::ItemBoxBtnSkin)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::ControlSkin);
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_PROPERTY_RW(NeutralNormalImage);
		ADD_PDE_PROPERTY_RW(NeutralHoverImage);
		ADD_PDE_PROPERTY_RW(NeutralSelectedImage);
		ADD_PDE_PROPERTY_RW(NeutralDisabledImage);
		ADD_PDE_PROPERTY_RW(NeutralHighlightImage);
		ADD_PDE_PROPERTY_RW(NeutralImage);
		

		ADD_PDE_PROPERTY_RW(RedNormalImage);
		ADD_PDE_PROPERTY_RW(RedHoverImage);
		ADD_PDE_PROPERTY_RW(RedSelectedImage);

		ADD_PDE_PROPERTY_RW(BlueNormalImage);
		ADD_PDE_PROPERTY_RW(BlueHoverImage);
		ADD_PDE_PROPERTY_RW(BlueSelectedImage);

		ADD_PDE_PROPERTY_RW(LockedImage);
		ADD_PDE_PROPERTY_RW(PackAImage);
		ADD_PDE_PROPERTY_RW(PackBImage);
		ADD_PDE_PROPERTY_RW(PackCImage);
		ADD_PDE_PROPERTY_RW(PackDImage);
		ADD_PDE_PROPERTY_RW(PackEImage);
		ADD_PDE_PROPERTY_RW(RepairImage);
		ADD_PDE_PROPERTY_RW(EmptyImage);

		ADD_PDE_PROPERTY_RW(NotSuitImage);

		ADD_PDE_PROPERTY_RW(TuneNoImage);
		ADD_PDE_PROPERTY_RW(TuneYesImage);
		ADD_PDE_PROPERTY_RW(TunedImage);

		ADD_PDE_PROPERTY_RW(UsingYesImage);
		ADD_PDE_PROPERTY_RW(UsingNoImage);

		ADD_PDE_PROPERTY_RW(SlotWeaponFirst);
		ADD_PDE_PROPERTY_RW(SlotWeaponSecond);
		ADD_PDE_PROPERTY_RW(SlotWeaponGrenade);
		ADD_PDE_PROPERTY_RW(SlotWeaponFlash);
		ADD_PDE_PROPERTY_RW(SlotWeaponSmoke);

		ADD_PDE_PROPERTY_RW(SlotCharacterArmet);
		ADD_PDE_PROPERTY_RW(SlotCharacterMask);
		ADD_PDE_PROPERTY_RW(SlotCharacterClothes);
		ADD_PDE_PROPERTY_RW(SlotCharacterGloves);
		ADD_PDE_PROPERTY_RW(SlotCharacterTrou);
		ADD_PDE_PROPERTY_RW(SlotCharacterShoes);
		ADD_PDE_PROPERTY_RW(SlotCharacterBadge);

		ADD_PDE_PROPERTY_RW(NameNormalColor);
		ADD_PDE_PROPERTY_RW(NameHighlightColor);
		ADD_PDE_PROPERTY_RW(LeftHighlightColor);
	}
};


DEFINE_PDE_TYPE_CLASS(Gui::ItemBoxBtn)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::Control);
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_EVENT(EventMouseEnter);
		ADD_PDE_EVENT(EventMouseLeave);
		ADD_PDE_EVENT(EventMouseDown);
		ADD_PDE_EVENT(EventMouseRightDown);
		ADD_PDE_EVENT(EventMouseUp);
		ADD_PDE_EVENT(EventToolTipsShow);
		ADD_PDE_EVENT(EventSelected);
		ADD_PDE_EVENT(EventDoubleClick);
		ADD_PDE_EVENT(EventCancel);
		ADD_PDE_PROPERTY_RW(Empty);
		ADD_PDE_PROPERTY_RW(Loading);
		ADD_PDE_PROPERTY_RW(Locked);
		ADD_PDE_PROPERTY_RW(Selected);
		ADD_PDE_PROPERTY_RW(CanCancel);
		ADD_PDE_PROPERTY_RW(CanSelect);
		ADD_PDE_PROPERTY_RW(Highlight);
		ADD_PDE_PROPERTY_RW(Enough);
		ADD_PDE_PROPERTY_RW(Hovered);
		
		ADD_PDE_PROPERTY_R(ClientLocation);
		ADD_PDE_PROPERTY_RW(ID);

		ADD_PDE_PROPERTY_RW(ItemName);
		ADD_PDE_PROPERTY_RW(ItemIcon);
		ADD_PDE_PROPERTY_RW(LoadingImage);

		ADD_PDE_PROPERTY_RW(ItemIconNew);
		ADD_PDE_PROPERTY_RW(ItemIconVIP);
		ADD_PDE_PROPERTY_RW(ItemLevel);
		ADD_PDE_PROPERTY_RW(ItemIconPastDue);
		ADD_PDE_PROPERTY_RW(Cost);
		ADD_PDE_PROPERTY_RW(CostType);

		ADD_PDE_PROPERTY_RW(Suit);

		ADD_PDE_PROPERTY_RW(PID);
		ADD_PDE_PROPERTY_RW(SID);
		ADD_PDE_PROPERTY_RW(Where);

		ADD_PDE_PROPERTY_RW(Period);

		ADD_PDE_PROPERTY_RW(Side);

		ADD_PDE_PROPERTY_RW(UnitType);
		ADD_PDE_PROPERTY_RW(TimeLeftType);
		ADD_PDE_PROPERTY_RW(TimeLeft);
		ADD_PDE_PROPERTY_RW(Quantity);
		ADD_PDE_PROPERTY_RW(Durable);

		ADD_PDE_PROPERTY_RW(InPack);
		ADD_PDE_PROPERTY_RW(ModState);
		ADD_PDE_PROPERTY_RW(UseState);

		ADD_PDE_PROPERTY_RW(Type);	
		ADD_PDE_PROPERTY_RW(SubType);
		ADD_PDE_PROPERTY_RW(BagSP1);

		ADD_PDE_METHOD(Clear);
		ADD_PDE_METHOD(SetTimer);
		ADD_PDE_METHOD(IsShowTimer);
		ADD_PDE_PROPERTY_RW(LastSelected);

		//button
		ADD_PDE_PROPERTY_RW (ItemBtn);
		ADD_PDE_PROPERTY_RW(BtnText);
		ADD_PDE_PROPERTY_RW(BtnSize);
		ADD_PDE_PROPERTY_RW(BtnLocation);
		ADD_PDE_PROPERTY_RW(BtnVisible);
		ADD_PDE_PROPERTY_RW(ItemBtnSkin);
		ADD_PDE_EVENT(EventBtnClick);

		//ItemIcon
		ADD_PDE_PROPERTY_RW(IconDisplayType);

		//ComboBox
		ADD_PDE_PROPERTY_RW(ItemCombo);
		ADD_PDE_PROPERTY_RW(ComboText);
		ADD_PDE_PROPERTY_RW(ComboSize);
		ADD_PDE_PROPERTY_RW(ComboLocation);
		ADD_PDE_PROPERTY_RW(ComboVisible);
		ADD_PDE_PROPERTY_RW(ItemComboSkin);
		ADD_PDE_PROPERTY_RW(ItemComboListStyle);
		ADD_PDE_EVENT(EventComboSelect);

		//ProcessBar

		ADD_PDE_PROPERTY_RW(ItemPBBase);
		ADD_PDE_PROPERTY_RW(ItemPBTop);
		ADD_PDE_PROPERTY_RW(PBBaseSize);
		ADD_PDE_PROPERTY_RW(PBTopSize);
		ADD_PDE_PROPERTY_RW(PBBaseLocation);
		ADD_PDE_PROPERTY_RW(PBTopLocation);
		ADD_PDE_PROPERTY_RW(PBBaseSkin);		
		ADD_PDE_PROPERTY_RW(PBTopSkin);
		ADD_PDE_PROPERTY_RW(PBTOPBGColor);

		ADD_PDE_PROPERTY_RW(PBVisible);

		ADD_PDE_PROPERTY_RW(GoodsID);
	}
};

REGISTER_PDE_TYPE(Gui::ItemBoxBtnSkin);
REGISTER_PDE_TYPE(Gui::ItemBoxBtn);

namespace Gui
{
	ItemBoxBtn::ItemBoxBtn()
		:m_Selected(false)
		,m_Highlight(false)
		,m_Enough(false)
		,m_Lock(false)
		,m_IsLoading(false)
		,m_Hovered(false)
		,m_IsEmpty(false)
		,m_CanCancel(false)
		,m_CanSelect(true)
		,m_SelectColor(ARGB(127, 77, 77, 77))
		,m_HoverColor(ARGB(127, 100, 100, 100))
		,m_NormalColor(ARGB(127, 133, 133, 133))
		,m_DisableColor(ARGB(127, 177, 177, 177))
		,m_ID(0)
		,m_PID(-1)
		,m_SID(-1)
		,m_ItemName("item name")
		,m_ModState(-1)
		,m_UseState(-1)
		,m_UnitType(-1)
		,m_TimeLeftType(-1)
		,m_TimeLeft(-1)
		,m_Quantity(-1)
		,m_Durable(-1)
		,m_CostType(0)
		,m_Cost(13000)
		,m_Period(-1)
		,m_InPack(-1)
		,m_Suit(true)
		,m_Side(-1)
		,m_Type(-1)
		,m_SubType(-1)
		,m_BagSP1(-1)
		,m_LastSelected(false)
		,m_Where(-1)
		,m_StartLoading(false)
		,m_ClientLocation(0,0)
		//button
		, m_BtnVisible(false)
		, m_BtnLocation(Core::Vector2(0, 0))
		, m_BtnSize(Core::Vector2(40, 20))
		, m_BtnText("")
		, m_ismouse_here(false)
		, m_tooltipStartshow(0.f)
		//Combox
		,m_ComboVisible(false)
		,m_ComboSize(Core::Vector2(25,15))
		,m_ComboLocation(Core::Vector2(10,60))
		,m_ItemComboListStyle("")

		//ProcessBar
		,m_PBVisible(false)
		,m_PBBaseLocation(Core::Vector2(0, 0))
		,m_PBBaseSize(Core::Vector2(16, 48))
		,m_PBTopLocation(Core::Vector2(0, 0))
		,m_PBTopSize(Core::Vector2(16, 48))
		,m_PBTOPBGColor(Core::ARGB(255, 255, 255, 255))
		,m_GoodsID(-1)
		,m_ShowTimer(false)
		,m_HaveTime(0)
		,m_UseTime(0)
	{
		m_Text = "New ItemBoxBtn";
		m_Size = Vector2(192,70);
		m_BackgroundColor = m_NormalColor;
		m_IconDisplayType = Icon::kIconTextActualSize;
	}

	ItemBoxBtn::~ItemBoxBtn()
	{

	}
}

namespace Gui
{
	PDE_ATTRIBUTE_GETTER(ItemBoxBtn, Empty, bool)
	{
		return m_IsEmpty;
	}
	PDE_ATTRIBUTE_SETTER(ItemBoxBtn, Empty, bool)
	{
		if(m_IsEmpty == value)
			return;
		m_IsEmpty = value;
		Invalid();
	}

	PDE_ATTRIBUTE_GETTER(ItemBoxBtn, Selected, bool)
	{
		return m_Selected;
	}
	PDE_ATTRIBUTE_SETTER(ItemBoxBtn, Selected, bool)
	{
		if(m_Selected == value)
			return;

		m_Selected = value;
		if(m_Selected)
			EventSelected.Fire(ptr_static_cast<ItemBoxBtn>(this), ValueChangeEventArgs());
		else
			EventCancel.Fire(ptr_static_cast<ItemBoxBtn>(this), ValueChangeEventArgs());
		Invalid();
	}

	PDE_ATTRIBUTE_GETTER(ItemBoxBtn, Locked, bool)
	{
		return m_Lock;
	}
	PDE_ATTRIBUTE_SETTER(ItemBoxBtn, Locked, bool)
	{
		if(m_Lock == value)
			return;

		m_Lock = value;
		Invalid();
	}

	PDE_ATTRIBUTE_GETTER(ItemBoxBtn, Loading, bool)
	{
		return m_IsLoading;
	}
	PDE_ATTRIBUTE_SETTER(ItemBoxBtn, Loading, bool)
	{
		if(m_IsLoading == value)
			return;

		m_IsLoading = value;
		if(m_IsLoading)
			m_StartLoading = true;
		else
			m_StartLoading = false;
		Invalid();
	}

	PDE_ATTRIBUTE_GETTER(ItemBoxBtn, CostType, int)
	{
		return m_CostType;
	}
	PDE_ATTRIBUTE_SETTER(ItemBoxBtn, CostType, int)
	{
		if(m_CostType == value)
			return;

		m_CostType = value;
		Invalid();
	}

	PDE_ATTRIBUTE_GETTER(ItemBoxBtn, Cost, int)
	{
		return m_Cost;
	}
	PDE_ATTRIBUTE_SETTER(ItemBoxBtn, Cost, int)
	{
		if(m_Cost == value)
			return;

		m_Cost = value;
		Invalid();
	}

	PDE_ATTRIBUTE_GETTER(ItemBoxBtn, Period, int)
	{
		return m_Period;
	}
	PDE_ATTRIBUTE_SETTER(ItemBoxBtn, Period, int)
	{
		if(m_Period == value)
			return;

		m_Period = value;
		Invalid();
	}

	PDE_ATTRIBUTE_GETTER(ItemBoxBtn, ID, int)
	{
		return m_ID;
	}
	PDE_ATTRIBUTE_SETTER(ItemBoxBtn, ID, int)
	{
		if(m_ID == value)
			return;
		m_ID = value;
	}

	PDE_ATTRIBUTE_GETTER(ItemBoxBtn, CanSelect, bool)
	{
		return m_CanSelect;
	}
	PDE_ATTRIBUTE_SETTER(ItemBoxBtn, CanSelect, bool)
	{
		if(m_CanSelect == value)
			return;
		m_CanSelect = value;
	}

	PDE_ATTRIBUTE_GETTER(ItemBoxBtn, Highlight, bool)
	{
		return m_Highlight;
	}
	PDE_ATTRIBUTE_SETTER(ItemBoxBtn, Highlight, bool)
	{
		if(m_Highlight == value)
			return;
		m_Highlight = value;
	}

	PDE_ATTRIBUTE_GETTER(ItemBoxBtn, Enough, bool)
	{
		return m_Enough;
	}
	PDE_ATTRIBUTE_SETTER(ItemBoxBtn, Enough, bool)
	{
		if(m_Enough == value)
			return;
		m_Enough = value;
	}

	PDE_ATTRIBUTE_GETTER(ItemBoxBtn, Hovered, bool)
	{
		return m_Hovered;
	}
	PDE_ATTRIBUTE_SETTER(ItemBoxBtn, Hovered, bool)
	{
		if(m_Hovered == value)
			return;
		m_Hovered = value;
	}

	PDE_ATTRIBUTE_GETTER(ItemBoxBtn, Suit, bool)
	{
		return m_Suit;
	}
	PDE_ATTRIBUTE_SETTER(ItemBoxBtn, Suit, bool)
	{
		if(m_Suit == value)
			return;

		m_Suit = value;
		Invalid();
	}

	PDE_ATTRIBUTE_GETTER(ItemBoxBtn, ItemName, String)
	{
		return m_ItemName;
	}
	PDE_ATTRIBUTE_SETTER(ItemBoxBtn, ItemName, String)
	{
		if(m_ItemName == value)
			return;

		m_ItemName = value;
		Invalid();
	}

	PDE_ATTRIBUTE_GETTER(ItemBoxBtn, ItemIcon, tempc_ptr(Icon))
	{
		return m_ItemIcon;
	}
	PDE_ATTRIBUTE_SETTER(ItemBoxBtn, ItemIcon, tempc_ptr(Icon))
	{
		if(m_ItemIcon!=value)
		{
			m_ItemIcon = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(ItemBoxBtn, ItemIconNew, tempc_ptr(Icon))
	{
		return m_ItemIconNew;
	}
	PDE_ATTRIBUTE_SETTER(ItemBoxBtn, ItemIconNew, tempc_ptr(Icon))
	{
		if(m_ItemIconNew!=value)
		{
			m_ItemIconNew = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(ItemBoxBtn, ItemIconVIP, tempc_ptr(Icon))
	{
		return m_ItemIconVIP;
	}
	PDE_ATTRIBUTE_SETTER(ItemBoxBtn, ItemIconVIP, tempc_ptr(Icon))
	{
		if(m_ItemIconVIP!=value)
		{
			m_ItemIconVIP = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(ItemBoxBtn, ItemLevel, tempc_ptr(Icon))
	{
		return m_ItemLevel;
	}
	PDE_ATTRIBUTE_SETTER(ItemBoxBtn, ItemLevel, tempc_ptr(Icon))
	{
		if(m_ItemLevel!=value)
		{
			m_ItemLevel = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(ItemBoxBtn, ItemIconPastDue, tempc_ptr(Icon))
	{
		return m_ItemIcon_PastDue;
	}
	PDE_ATTRIBUTE_SETTER(ItemBoxBtn, ItemIconPastDue, tempc_ptr(Icon))
	{
		if(m_ItemIcon_PastDue!=value)
		{
			m_ItemIcon_PastDue = value;
			Invalid();
		}
	}
	
	PDE_ATTRIBUTE_GETTER(ItemBoxBtn, TimeLeftType, int)
	{
		return m_TimeLeftType;
	}
	PDE_ATTRIBUTE_SETTER(ItemBoxBtn, TimeLeftType, int)
	{
		if(m_TimeLeftType!=value)
		{
			m_TimeLeftType = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(ItemBoxBtn, TimeLeft, int)
	{
		return m_TimeLeft;
	}
	PDE_ATTRIBUTE_SETTER(ItemBoxBtn, TimeLeft, int)
	{
		if(m_TimeLeft!=value)
		{
			m_TimeLeft = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(ItemBoxBtn, Quantity, int)
	{
		return m_Quantity;
	}
	PDE_ATTRIBUTE_SETTER(ItemBoxBtn, Quantity, int)
	{
		if(m_Quantity!=value)
		{
			m_Quantity = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(ItemBoxBtn, Side, int)
	{
		return m_Side;
	}
	PDE_ATTRIBUTE_SETTER(ItemBoxBtn, Side, int)
	{
		if(m_Side!=value)
		{
			m_Side = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(ItemBoxBtn, InPack, int)
	{
		return m_InPack;
	}
	PDE_ATTRIBUTE_SETTER(ItemBoxBtn, InPack, int)
	{
		if(m_InPack!=value)
		{
			m_InPack = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(ItemBoxBtn, PID, int)
	{
		return m_PID;
	}
	PDE_ATTRIBUTE_SETTER(ItemBoxBtn, PID, int)
	{
		if(m_PID == value)
			return;
		m_PID = value;
	}

	PDE_ATTRIBUTE_GETTER(ItemBoxBtn, SID, int)
	{
		return m_SID;
	}
	PDE_ATTRIBUTE_SETTER(ItemBoxBtn, SID, int)
	{
		if(m_SID == value)
			return;
		m_SID = value;
	}

	PDE_ATTRIBUTE_GETTER(ItemBoxBtn, Type, int)
	{
		return m_Type;
	}
	PDE_ATTRIBUTE_SETTER(ItemBoxBtn, Type, int)
	{
		if(m_Type == value)
			return;
		m_Type = value;
	}

	PDE_ATTRIBUTE_GETTER(ItemBoxBtn, SubType, int)
	{
		return m_SubType;
	}
	PDE_ATTRIBUTE_SETTER(ItemBoxBtn, SubType, int)
	{
		if(m_SubType == value)
			return;
		m_SubType = value;
	}

	PDE_ATTRIBUTE_GETTER(ItemBoxBtn, BagSP1, int)
	{
		return m_BagSP1;
	}
	PDE_ATTRIBUTE_SETTER(ItemBoxBtn, BagSP1, int)
	{
		if(m_BagSP1 != value)
		{
			m_BagSP1 = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(ItemBoxBtn, LastSelected, bool)
	{
		return m_LastSelected;
	}
	PDE_ATTRIBUTE_SETTER(ItemBoxBtn, LastSelected, bool)
	{
		if(m_LastSelected == value)
			return;
		m_LastSelected = value;
	}

	PDE_ATTRIBUTE_GETTER(ItemBoxBtn, Where, int)
	{
		return m_Where;
	}
	PDE_ATTRIBUTE_SETTER(ItemBoxBtn, Where, int)
	{
		if(m_Where != value)
		{
			m_Where = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(ItemBoxBtn, ModState, int)
	{
		return m_ModState;
	}
	PDE_ATTRIBUTE_SETTER(ItemBoxBtn, ModState, int)
	{
		if(m_ModState != value)
		{
			m_ModState = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(ItemBoxBtn, UseState, int)
	{
		return m_UseState;
	}
	PDE_ATTRIBUTE_SETTER(ItemBoxBtn, UseState, int)
	{
		if(m_UseState != value)
		{
			m_UseState = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(ItemBoxBtn, UnitType, int)
	{
		return m_UnitType;
	}
	PDE_ATTRIBUTE_SETTER(ItemBoxBtn, UnitType, int)
	{
		if(m_UnitType != value)
		{
			m_UnitType = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(ItemBoxBtn, Durable, int)
	{
		return m_Durable;
	}
	PDE_ATTRIBUTE_SETTER(ItemBoxBtn, Durable, int)
	{
		if(m_Durable != value)
		{
			m_Durable = value;
			Invalid();
		}
	}

	//Button Get and Set
	PDE_ATTRIBUTE_GETTER(ItemBoxBtn, BtnSize, Core::Vector2)
	{
		return m_BtnSize;
	}
	PDE_ATTRIBUTE_SETTER(ItemBoxBtn, BtnSize, Core::Vector2)
	{
		if(m_BtnSize == value)
			return;

		m_BtnSize = value;
		Invalid();
	}

	PDE_ATTRIBUTE_GETTER(ItemBoxBtn, BtnLocation, Core::Vector2)
	{
		return m_BtnLocation;
	}
	PDE_ATTRIBUTE_SETTER(ItemBoxBtn, BtnLocation, Core::Vector2)
	{
		if(m_BtnLocation == value)
			return;

		m_BtnLocation = value;
		Invalid();
	}

	PDE_ATTRIBUTE_GETTER(ItemBoxBtn, BtnText, Core::String)
	{
		return m_BtnText;
	}
	PDE_ATTRIBUTE_SETTER(ItemBoxBtn, BtnText, Core::String)
	{
		if(m_BtnText == value)
			return;

		m_BtnText = value;
		Invalid();
	}

	PDE_ATTRIBUTE_GETTER(ItemBoxBtn, BtnVisible, bool)
	{
		return m_BtnVisible;
	}
	PDE_ATTRIBUTE_SETTER(ItemBoxBtn, BtnVisible, bool)
	{
		if(m_BtnVisible == value)
			return;

		m_BtnVisible = value;
		m_ItemBtn->SetVisible(m_BtnVisible);

		//��������Ϊ��TOOLTIPS ���ǿ��ܳ�������������Ҫ��һ��ȷ��
		m_ismouse_here = false;
		m_tooltipStartshow = 0.5f;
		EventMouseLeave.Fire(ptr_static_cast<ItemBoxBtn>(this),Client::InputEventArgs());

		Invalid();
	}

	PDE_ATTRIBUTE_GETTER(ItemBoxBtn, ItemBtnSkin, tempc_ptr(Gui::ButtonSkin))
	{
		return m_ItemBtnSkin;
	}

	PDE_ATTRIBUTE_SETTER(ItemBoxBtn, ItemBtnSkin, tempc_ptr(Gui::ButtonSkin))
	{
		if(m_ItemBtnSkin == value)
			return;

		m_ItemBtnSkin = value;
		Invalid();
	}

	PDE_ATTRIBUTE_GETTER(ItemBoxBtn, IconDisplayType, Icon::IconTextDisplay)
	{
		return m_IconDisplayType;
	}

	PDE_ATTRIBUTE_SETTER(ItemBoxBtn, IconDisplayType, Icon::IconTextDisplay)
	{
		if(m_IconDisplayType == value)
			return;

		m_IconDisplayType = value;
		Invalid();
	}

	PDE_ATTRIBUTE_GETTER(ItemBoxBtn, GoodsID, int)
	{
		return m_GoodsID;
	}
	PDE_ATTRIBUTE_SETTER(ItemBoxBtn, GoodsID, int)
	{
		if(m_GoodsID == value)
			return;

		m_GoodsID = value;
		Invalid();
	}


	//ComboBox Get and Set
	PDE_ATTRIBUTE_GETTER(ItemBoxBtn, ComboLocation, Core::Vector2)
	{
		return m_ComboLocation;
	}
	PDE_ATTRIBUTE_SETTER(ItemBoxBtn, ComboLocation, Core::Vector2)
	{
		if(m_ComboLocation == value)
			return;

		m_ComboLocation = value;
		Invalid();
	}

	PDE_ATTRIBUTE_GETTER(ItemBoxBtn, ComboSize, Core::Vector2)
	{
		return m_ComboSize;
	}

	PDE_ATTRIBUTE_SETTER(ItemBoxBtn, ComboSize, Core::Vector2)
	{
		if(m_ComboSize == value)
			return;

		m_ComboSize = value;
		Invalid();
	}

	PDE_ATTRIBUTE_GETTER(ItemBoxBtn, ComboText, Core::String)
	{
		return m_ComboText;
	}
	PDE_ATTRIBUTE_SETTER(ItemBoxBtn, ComboText, Core::String)
	{
		if(m_ComboText == value)
			return;

		m_ComboText = value;
		Invalid();;
	}

	PDE_ATTRIBUTE_GETTER(ItemBoxBtn, ComboVisible, bool)
	{
		return m_ComboVisible;
	}

	PDE_ATTRIBUTE_SETTER(ItemBoxBtn,ComboVisible, bool)
	{
		if(m_ComboVisible==value)
			return;

		m_ComboVisible=value;
		Invalid();
	}

	PDE_ATTRIBUTE_GETTER(ItemBoxBtn, ItemComboSkin, tempc_ptr(Gui::ComboBoxSkin))
	{
		return m_ItemComboSkin;
	}

	PDE_ATTRIBUTE_SETTER(ItemBoxBtn, ItemComboSkin, tempc_ptr(Gui::ComboBoxSkin))
	{
		if(m_ItemComboSkin == value)
			return;

		m_ItemComboSkin = value;
		Invalid();
	}

	PDE_ATTRIBUTE_GETTER(ItemBoxBtn, ItemComboListStyle, Core::String)
	{
		return m_ItemComboListStyle;
	}

	PDE_ATTRIBUTE_SETTER(ItemBoxBtn, ItemComboListStyle, Core::String)
	{
		if(m_ItemComboListStyle == value)
			return;

		m_ItemComboListStyle = value;
		Invalid();
	}

	PDE_ATTRIBUTE_GETTER(ItemBoxBtn, PBBaseLocation, Core::Vector2)
	{
		return m_PBBaseLocation;
	}
	PDE_ATTRIBUTE_SETTER(ItemBoxBtn, PBBaseLocation, Core::Vector2)
	{
		if(m_PBBaseLocation == value)
			return;

		m_PBBaseLocation = value;
		Invalid();
	}

	PDE_ATTRIBUTE_GETTER(ItemBoxBtn, PBBaseSize, Core::Vector2)
	{
		return m_PBBaseSize;
	}

	PDE_ATTRIBUTE_SETTER(ItemBoxBtn, PBBaseSize, Core::Vector2)
	{
		if(m_PBBaseSize == value)
			return;

		m_PBBaseSize = value;
		Invalid();
	}

	PDE_ATTRIBUTE_GETTER(ItemBoxBtn, PBBaseSkin,tempc_ptr(Gui::ControlSkin))
	{
		return m_PBBaseSkin;
	}

	PDE_ATTRIBUTE_SETTER(ItemBoxBtn, PBBaseSkin,tempc_ptr(Gui::ControlSkin))
	{
		if(m_PBBaseSkin == value)
			return;

		m_PBBaseSkin = value;
		Invalid();
	}

	PDE_ATTRIBUTE_GETTER(ItemBoxBtn, PBTopLocation, Core::Vector2)
	{
		return m_PBTopLocation;
	}
	PDE_ATTRIBUTE_SETTER(ItemBoxBtn, PBTopLocation, Core::Vector2)
	{
		if(m_PBTopLocation == value)
			return;

		m_PBTopLocation = value;
		Invalid();
	}

	PDE_ATTRIBUTE_GETTER(ItemBoxBtn, PBTopSize, Core::Vector2)
	{
		return m_PBTopSize;
	}

	PDE_ATTRIBUTE_SETTER(ItemBoxBtn, PBTopSize, Core::Vector2)
	{
		if(m_PBTopSize == value)
			return;

		m_PBTopSize = value;
		Invalid();
	}

	PDE_ATTRIBUTE_GETTER(ItemBoxBtn, PBTopSkin,tempc_ptr(Gui::ControlSkin))
	{
		return m_PBTopSkin;
	}

	PDE_ATTRIBUTE_SETTER(ItemBoxBtn, PBTopSkin,tempc_ptr(Gui::ControlSkin))
	{
		if(m_PBTopSkin == value)
			return;

		m_PBTopSkin = value;
		Invalid();
	}

	PDE_ATTRIBUTE_GETTER(ItemBoxBtn, PBTOPBGColor, Core::ARGB)
	{
		return m_PBTOPBGColor;
	}

	PDE_ATTRIBUTE_SETTER(ItemBoxBtn, PBTOPBGColor, Core::ARGB)
	{
		if(m_PBTOPBGColor == value)
			return;

		m_PBTOPBGColor = value;
		Invalid();
	}

	PDE_ATTRIBUTE_GETTER(ItemBoxBtn, PBVisible, bool)
	{
		return m_PBVisible;
	}

	PDE_ATTRIBUTE_SETTER(ItemBoxBtn,PBVisible, bool)
	{
		if(m_PBVisible==value)
			return;

		m_PBVisible=value;
		Invalid();
	}

	PDE_ATTRIBUTE_GETTER(ItemBoxBtn, ClientLocation, Core::Vector2)
	{
		return m_ClientLocation;
	}
}

namespace Gui
{
	void ItemBoxBtn::OnCreate()
	{
		Super::OnCreate();

		m_ItemBtn = ptr_new Button;
		m_ItemBtn->SetVisible(m_BtnVisible);
		m_ItemBtn->SetParent(ptr_static_cast<ItemBoxBtn>(this));
		m_ItemBtn->SetStyle("Gui.LobbyPListButton");
		m_ItemBtn->SetLocation(m_BtnLocation);
		m_ItemBtn->SetSize(m_BtnSize);
		m_ItemBtn->SetText(m_BtnText);
		m_ItemBtn->SetFontSize(12);
		m_ItemBtn->SetTextColor(Core::ARGB(255, 14, 14, 14));
		m_ItemBtn->EventClick.Subscribe(NewDelegate(&ItemBoxBtn::_OnBtnClick,ptr_static_cast<ItemBoxBtn>(this)));

		m_ItemCombo = ptr_new ComboBox;
		m_ItemCombo->SetVisible(m_ComboVisible);
		m_ItemCombo->SetParent(ptr_static_cast<ItemBoxBtn>(this));
		m_ItemCombo->SetLocation(m_ComboLocation);
		m_ItemCombo->SetStyle("Gui.ComboBox");
		//m_ItemCombo->SetText(m_ComboText);
		m_ItemCombo->SetSize(m_ComboSize);
		//m_ItemCombo->SetFontSize(18);
		//m_ItemCombo->SetDock(kDockLeft);
		m_ItemCombo->SetDropDownWidth(100);
		//m_ItemCombo->AddItem(gLang->GetTextW(L"����"));
		//m_ItemCombo->AddItem(gLang->GetTextW(L"����"));
		m_ItemCombo->AddItem(gLang->GetTextW(L"����"));
		m_ItemCombo->EventItemSelected.Subscribe(NewDelegate(&ItemBoxBtn::OnComboBoxItemSelected,ptr_static_cast<ItemBoxBtn>(this)));

		m_ItemPBBase = ptr_new Control;
		m_ItemPBBase->SetVisible(m_PBVisible);
		m_ItemPBBase->SetParent(ptr_static_cast<ItemBoxBtn>(this));
		m_ItemPBBase->SetLocation(m_PBBaseLocation);
		m_ItemPBBase->SetSize(m_PBBaseSize);
		//m_ItemPBBase->SetSkin(m_PBBaseSkin);

		m_ItemPBTop = ptr_new Control;
		m_ItemPBTop->SetVisible(m_PBVisible);
		m_ItemPBTop->SetParent(ptr_static_cast<ItemBoxBtn>(this));
		m_ItemPBTop->SetLocation(m_PBTopLocation);
		m_ItemPBTop->SetSize(m_PBTopSize);
		//m_ItemPBTop->SetSkin(m_PBTopSkin);

	}

	void ItemBoxBtn::OnDestroy()
	{
		Super::OnDestroy();
	}

	void ItemBoxBtn::Clear()
	{
		m_Selected = false;
		m_LastSelected = false;
		m_ItemName = "";
		m_InPack = -1;
		m_Where = -2;
		m_ModState = -1;
		m_UseState = -1;
		m_UnitType = -1;
		m_Durable = -1;
		m_Type = -1;
		m_SubType = -1;

		m_ItemIcon = NullPtr;
		m_ItemIconNew = NullPtr;
		m_ItemIconVIP = NullPtr;
		m_ItemLevel = NullPtr;
		m_ItemIcon_PastDue = NullPtr;

		m_StartLoading = false;

		Invalid();
	}
}

namespace Gui
{

	void ItemBoxBtn::OnFrameUpdate( EventArgs & e )
	{
		if(m_IsLoading && m_LoadingImage)
		{
			m_LoadingImage->SetFrameTime(10.0 / 8);
			float frameTime = Task::GetFrameTime();

			int oldFrame = m_LoadingImage->GetCurrentFrame();
			int newFrame = m_LoadingImage->Update(frameTime);

			if(m_StartLoading)
			{
				m_LoadingImage->Reset();
				m_StartLoading = false;
			}

			if(oldFrame!=newFrame)
				Invalid();
		}

		if (!m_IsLoading && m_LoadingImage && m_ismouse_here)
		{
			if (m_tooltipStartshow < 0.5f)
			{
				m_tooltipStartshow += Task::GetFrameTime();
			}
			else
			{
				m_ClientLocation = Vector2::kZero;
				tempc_ptr(Control) pRoot;
				tempc_ptr(Control) pCurrent = ptr_static_cast<Control>(this);
				while(pCurrent)
				{
					pRoot = pCurrent;
					pCurrent = pCurrent->GetParent();
					m_ClientLocation.x += pRoot->GetLocation().x;
					m_ClientLocation.y += pRoot->GetLocation().y;
				}
				m_ismouse_here = false;
				EventToolTipsShow.Fire(ptr_static_cast<Control>(this), e);
			}
		}
	}

	void ItemBoxBtn::OnInputEvent(Client::InputEventArgs & e)
	{
		if(e.Handled)
			return;
		if(m_IsEmpty || /*m_Type == -1 ||*/ m_Where == 6)
		{
			if (!e.Handled)
			{
				Control::OnInputEvent(e);
			}
			return;
		}
		if(e.IsMouseEvent())
		{
			switch (e.Type)
			{
			case InputEventArgs::kMouseUp:
				if (e.LeftButtonUp)
				{
					if(!m_Selected && m_CanSelect)
					{
						SetSelected(true);
					}
					else
					{
						if(GetCanCancel())
						{
							SetSelected(false);
						}
					}
				}
				break;
			case InputEventArgs::kMouseMove:
				if(!m_Hovered)
				{
					m_Hovered = true;
					Invalid();
				}
				break;
			case InputEventArgs::kMouseDoubleClick:
				break;
			case InputEventArgs::kMouseEnter:
				break;
			case InputEventArgs::kMouseDown:
				break;
			case InputEventArgs::kMouseLeave:
				if(m_Hovered)
				{
					m_Hovered = false;
					Invalid();
				}
				break;
			default:break;
			}
		}
		if (!e.Handled)
		{
			Control::OnInputEvent(e);
		}
	}

	void ItemBoxBtn::OnPaint(PaintEventArgs & e)
	{
		tempc_ptr(ItemBoxBtnSkin) skin = ptr_dynamic_cast<ItemBoxBtnSkin>(GetSkin());
		Core::Vector2 meSize = GetSize();
		Core::Rectangle uvrect = Core::Rectangle(0, 0, 1, 1);
		if(skin)
		{
			tempc_ptr(Image) normalImage;
			tempc_ptr(Image) selectedImage;
			tempc_ptr(Image) hoverImage;
			tempc_ptr(Image) disabledImage;
			tempc_ptr(Image) HighlightImage;
			tempc_ptr(Image) inImage;

			normalImage = skin->GetNeutralNormalImage();
			selectedImage = skin->GetNeutralSelectedImage();
			hoverImage = skin->GetNeutralHoverImage();
			disabledImage = skin->GetNeutralDisabledImage();
			HighlightImage = skin->GetNeutralHighlightImage();
			inImage = skin->GetNeutralImage();


			if (!GetEnable())
			{
				Skin::DrawImage(e.render, disabledImage, GetClientRect());
			}
			else if(m_Selected)
			{
				Skin::DrawImage(e.render, selectedImage, GetClientRect());
			}
			else if(m_Hovered)
			{
				Skin::DrawImage(e.render, normalImage, GetClientRect());
				if(m_Enough) 
					Skin::DrawImage(e.render, inImage, GetClientRect());
				else
					Skin::DrawImage(e.render, hoverImage, GetClientRect());
			}
			else if (GetHighlight())
			{
				Skin::DrawImage(e.render, normalImage, GetClientRect());
				Skin::DrawImage(e.render, HighlightImage, GetClientRect());
			}
			else
			{
				Skin::DrawImage(e.render, normalImage, GetClientRect());
				if(m_Enough) 
					Skin::DrawImage(e.render, inImage, GetClientRect());
			}
		}
		else
		{
			if(m_IsEmpty || m_Type == -1)
				e.render->DrawRectangle(GetClientRect(), uvrect, Core::ARGB(255, 22, 66, 22));
			else if(m_Lock)
				e.render->DrawRectangle(GetClientRect(), uvrect, m_DisableColor);
			else if(m_Selected)
				e.render->DrawRectangle(GetClientRect(), uvrect, m_SelectColor);
			else if(m_Hovered)
				e.render->DrawRectangle(GetClientRect(), uvrect, m_HoverColor);
			else
				e.render->DrawRectangle(GetClientRect(), uvrect, m_NormalColor);
		}

		if(m_IsLoading)
		{
			if(m_LoadingImage)
				Skin::DrawImage(e.render, m_LoadingImage, GetClientRect());
			else
				e.render->DrawString(GetFont(), ARGB(255, 255, 255, 255), Core::ARGB(0,0,0,0), GetClientRect(), "Loading", Unit::kAlignLeftMiddle);

			return;
		}

		if(m_IsEmpty || m_Type == -1)
			return;

		Core::Vector4 Padding = GetPadding();
		Core::Rectangle rect = GetClientRect();
		rect.Max -=  Vector2(Padding.z, Padding.w);
		rect.Min += Vector2(Padding.x, Padding.y);
		Skin::DrawIconText(e.render, GetItemIcon(), NullPtr, "", rect , Unit::kAlignCenterMiddle
			, m_Lock?ARGB(255, 128, 128, 128):ARGB(255,255,255,255), ARGB(255,255,255,255), true, false);
		Skin::DrawIconText(e.render, GetItemIconPastDue(), NullPtr, "", GetClientRect(), Unit::kAlignCenterMiddle
			, m_Lock?ARGB(255, 128, 128, 128):ARGB(255,255,255,255), ARGB(255,255,255,255), true, false);
		Skin::DrawIconText(e.render, GetItemIconNew(), NullPtr, "", Core::Rectangle(GetClientRect().Min.x, GetClientRect().Min.y, GetClientRect().Min.x + 44, GetClientRect().Min.y + 44), Unit::kAlignCenterMiddle
			, m_Lock?ARGB(255, 128, 128, 128):ARGB(255,255,255,255), ARGB(255,255,255,255), true, false);
		Skin::DrawIconText(e.render, GetItemIconVIP(), NullPtr, "", Core::Rectangle(GetClientRect().Min.x, GetClientRect().Min.y, GetClientRect().Min.x + 60, GetClientRect().Min.y + 60), Unit::kAlignCenterMiddle
			, m_Lock?ARGB(255, 128, 128, 128):ARGB(255,255,255,255), ARGB(255,255,255,255), true, false);
		Skin::DrawIconText(e.render, GetItemLevel(), NullPtr, "", Core::Rectangle(GetClientRect().Max.x-43, GetClientRect().Min.y+2, GetClientRect().Max.x + 5, GetClientRect().Min.y + 30), Unit::kAlignCenterMiddle
			, m_Lock?ARGB(255, 128, 128, 128):ARGB(255,255,255,255), ARGB(255,255,255,255), true, false);

		if (m_ShowTimer && m_UseTime - m_HaveTime > 0)
		{
			int time = m_UseTime - m_HaveTime;
			m_HaveTime += Task::GetFrameTime();
			Core::String str;
			int h = time / 3600;
			int m = time / 60 % 60;
			int s = time % 60;
			str = Core::String::Format("%02d:%02d:%02d",h,m,s);
			Core::Rectangle rect = GetClientRect();
			rect.Min.y-=10;
			rect.Max.y-=10;
			e.render->DrawString(e.render->font_simhei_20, ARGB(255, 0, 0, 0), Core::ARGB(0,0,0,0), rect, str, Unit::kAlignCenterMiddle);
		}
		else if(m_ShowTimer)
		{
			Core::String str;
			str = Core::String::Format("00:00:00");
			Core::Rectangle rect = GetClientRect();
			rect.Min.y-=10;
			rect.Max.y-=10;
			e.render->DrawString(e.render->font_simhei_20, ARGB(255, 0, 0, 0), Core::ARGB(0,0,0,0), rect, str, Unit::kAlignCenterMiddle);
		}
	}

	void ItemBoxBtn::OnMouseEnter(Client::InputEventArgs & e)
	{
		m_ismouse_here = true;
		m_tooltipStartshow = 0.f;
		EventMouseEnter.Fire(ptr_static_cast<ItemBoxBtn>(this),Client::InputEventArgs());
		if (!e.Handled && (m_Hint.Length() != 0))
		{
			if (!s_ToolTip) {
				s_ToolTip = ptr_new ToolTip;
			}

			Vector2 origin = ClientToGlobalScreen(Vector2::kZero);
			s_ToolTip->ShowStart(ptr_static_cast<Control>(gGame->guiSys), Core::Rectangle::LeftTop(origin, GetSize()), m_Hint);
		}
	}

	void ItemBoxBtn::OnMouseLeave(Client::InputEventArgs & e)
	{
		m_ismouse_here = false;
 		m_tooltipStartshow = 0.5f;
		EventMouseLeave.Fire(ptr_static_cast<ItemBoxBtn>(this),Client::InputEventArgs());
	}

	void ItemBoxBtn::OnMouseDown(Client::InputEventArgs & e)
	{
		if (e.Code == MC_LEFT_BUTTON)
			EventMouseDown.Fire(ptr_static_cast<ItemBoxBtn>(this),Client::InputEventArgs());
		else
			if (!e.LeftButtonDown)
			{
				EventMouseRightDown.Fire(ptr_static_cast<ItemBoxBtn>(this),Client::InputEventArgs());
			}
	}

	void ItemBoxBtn::OnMouseUp(Client::InputEventArgs & e)
	{
		EventMouseUp.Fire(ptr_static_cast<ItemBoxBtn>(this),Client::InputEventArgs());
	}

	void ItemBoxBtn::OnDoubleClick(Client::InputEventArgs & e)
	{
		EventDoubleClick.Fire(ptr_static_cast<ItemBoxBtn>(this), Client::InputEventArgs());
	}

	int ItemBoxBtn::CalculateStringWidth(String str)
	{
		Core::Rectangle tempRect = Core::Rectangle(0, 0, 0, 0);
		Vector2 o = GetFont()->MeasureString(tempRect, str, -1, Unit::kAlignCenterMiddle).GetExtent();
		return (int)o.x;
	}

	void ItemBoxBtn::_OnBtnClick(by_ptr(void) sender, InputEventArgs & e)
	{
		EventBtnClick.Fire(ptr_static_cast<ItemBoxBtn>(this), e);
	}

	void ItemBoxBtn::OnComboBoxItemSelected(by_ptr(void) sender,EventArgs & e)
	{
		S32 index = m_ItemCombo->GetSelectedIndex();

		EventComboSelect.Fire(ptr_static_cast<ItemBoxBtn>(this),(InputEventArgs &)e);

		m_ItemCombo->SetText("");
	}

	void ItemBoxBtn::Invalid()
	{

		m_ItemBtn->SetVisible(m_BtnVisible);
		m_ItemBtn->SetLocation(m_BtnLocation);
		m_ItemBtn->SetSize(m_BtnSize);
		m_ItemBtn->SetText(m_BtnText);
		if (m_ItemBtnSkin)
		{
			m_ItemBtn->SetSkin(m_ItemBtnSkin);
		}

		if (m_ItemIcon)
		{
			m_ItemIcon->SetDisplayType(m_IconDisplayType);
		}

		m_ItemCombo->SetVisible(m_ComboVisible);
		m_ItemCombo->SetLocation(m_ComboLocation);
		m_ItemCombo->SetSize(m_ComboSize);
		if (m_ItemComboSkin)
		{
			m_ItemCombo->SetSkin(m_ItemComboSkin);			
		}
		m_ItemCombo->SetChildComboListStyle(m_ItemComboListStyle);

		m_ItemPBBase->SetVisible(m_PBVisible);
		m_ItemPBBase->SetParent(ptr_static_cast<ItemBoxBtn>(this));
		m_ItemPBBase->SetLocation(m_PBBaseLocation);
		m_ItemPBBase->SetSize(m_PBBaseSize);
		if (m_PBBaseSkin)
		{
			m_ItemPBBase->SetSkin(m_PBBaseSkin);
		}
		
		m_ItemPBTop->SetVisible(m_PBVisible);
		m_ItemPBTop->SetParent(ptr_static_cast<ItemBoxBtn>(this));
		m_ItemPBTop->SetLocation(m_PBTopLocation);
		m_ItemPBTop->SetSize(m_PBTopSize);
		m_ItemPBTop->SetBackgroundColor(m_PBTOPBGColor);
		if (m_PBTopSkin)
		{
			m_ItemPBTop->SetSkin(m_PBTopSkin);
		}		

		Super::Invalid();
	}

	void ItemBoxBtn::SetTimer(long t,long now, float alltime)
	{
		//�ܵ�ʱ��
		m_UseTime = alltime;
		IsShowTimer(true);

		//time_t ltime;
		//time( &ltime );
		//struct tm today = { 0, 0, 12, 25, 11, 93 };
		//_localtime64_s( &today, &ltime );
		m_HaveTime = now - t;
		if (t < 0)
			m_HaveTime = alltime;
	}

	void ItemBoxBtn::IsShowTimer(bool show)
	{
		m_ShowTimer = show;
	}
}

