#include "pch.h"

namespace Gui
{
	/// constructor
	ScriptCommand::ScriptCommand(tempc_ptr(CommandQueue) owner)
		: m_Owner(owner)
	{
	}


	/// redo this command
	void ScriptCommand::OnRedo(Command & e)
	{
		EventRedo.Fire(m_Owner, *this);
	}

	/// undo this command
	void ScriptCommand::OnUndo(Command & e)
	{
		EventUndo.Fire(m_Owner, *this);
	}

	/// release this command
	void ScriptCommand::Release()
	{
		EventDestroy.Fire(m_Owner, *this);
		delete this;
	}
}



namespace Gui
{
	CommandQueue::CommandQueue()
		: m_UndoLimit(0)
	{
	}

	CommandQueue::~CommandQueue()
	{
		// clear undo list
		while (!m_UndoList.Empty())
			m_UndoList.PopFront()->Release();

		// clear redo list
		while (!m_RedoList.Empty())
			m_RedoList.PopFront()->Release();
	}
}


namespace Gui
{
	/// can undo
	PDE_ATTRIBUTE_GETTER(CommandQueue, CanUndo, bool)
	{
		return !m_UndoList.Empty();
	}

	/// can redo
	PDE_ATTRIBUTE_GETTER(CommandQueue, CanRedo, bool)
	{
		return !m_RedoList.Empty();
	}

	PDE_ATTRIBUTE_GETTER(CommandQueue, UndoLimit, U32)
	{
		return m_UndoLimit;
	}

	PDE_ATTRIBUTE_SETTER(CommandQueue, UndoLimit, U32)
	{
		if (m_UndoLimit != value)
		{
			m_UndoLimit = value;

			if (m_UndoLimit > 0)
			{
				while (m_UndoList.Size() > m_UndoLimit)
				{
					m_UndoList.PopFront()->Release();
				}
			}
		}
	}

	/// add new command
	void CommandQueue::AddCommand(Command * command, bool addToRedo)
	{
		// clear redo list
		while (!m_RedoList.Empty())
			m_RedoList.PopFront()->Release();

		// pop undo list
		if (m_UndoLimit > 0)
		{
			while (m_UndoList.Size() + 1 > m_UndoLimit)
			{
				m_UndoList.PopFront()->Release();
			}
		}

		if (addToRedo)
		{
			// add this command to redo list
			m_RedoList.PushFront(command);
		}
		else
		{
			// add this command to undo list
			m_UndoList.PushBack(command);
		}
	}

	/// new script command
	ScriptCommand * CommandQueue::AddNewScriptCommand(bool addToRedo)
	{
		ScriptCommand * pCommand = new ScriptCommand(ptr_static_cast<CommandQueue>(this));
		AddCommand(pCommand, addToRedo);
		return pCommand;
	}


	/// redo
	void CommandQueue::Redo(int steps)
	{
		for (int i = 0; i < steps; i ++)
		{
			if (!m_RedoList.Empty())
			{
				Command * pCommand = m_RedoList.PopFront();
				pCommand->OnRedo(*pCommand);
				m_UndoList.PushBack(pCommand);
			}
		}
	}

	/// undo
	void CommandQueue::Undo(int steps)
	{
		for (int i = 0; i < steps; i ++)
		{
			if (!m_UndoList.Empty())
			{
				Command * pCommand = m_UndoList.PopBack();
				pCommand->OnUndo(*pCommand);
				m_RedoList.PushFront(pCommand);
			}
		}
	}
}