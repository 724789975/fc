#include "pch.h"

using namespace Core;
using namespace Gui;
using namespace Client;

DEFINE_PDE_TYPE_CLASS(Gui::CalendarSkin)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::ControlSkin);
		ADD_PDE_DEFAULT_CONSTRUCTOR();
		ADD_PDE_PROPERTY_RW(DisabledImage);
		ADD_PDE_PROPERTY_RW(ActivateImage);
		ADD_PDE_PROPERTY_RW(InActivateImage);
	}
};

DEFINE_PDE_TYPE_CLASS(Gui::Calendar)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::Control);
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_PROPERTY_RW(ButtonSpace);
		ADD_PDE_PROPERTY_RW(HighSpace);
		ADD_PDE_PROPERTY_RW(BtnSkin);
		ADD_PDE_PROPERTY_RW(BtnSkinSupply);
		ADD_PDE_PROPERTY_RW(BtnSkinPrepare);
		ADD_PDE_PROPERTY_RW(CanSupplyNum);
		ADD_PDE_PROPERTY_RW(CanPrepareNum);
		ADD_PDE_PROPERTY_RW(CheckValue);

		ADD_PDE_METHOD(SetTime);
		ADD_PDE_METHOD(SetDayActivate);

		ADD_PDE_EVENT(EventButtonClick);
	}
};
REGISTER_PDE_TYPE(Gui::CalendarSkin);
REGISTER_PDE_TYPE(Gui::Calendar);
//---------------------------------------------------------------------------------------
// attributes.
//---------------------------------------------------------------------------------------
namespace Gui
{
	Calendar::Calendar()
		: m_HighSpace(0.0f)
		, m_ButtonSpace(0, 0)
		, m_Year(-1)
		, m_Month(-1)
		, m_Day(-1)
		, m_Week(-1)
	{

	}

	Calendar::~Calendar()
	{

	}

	PDE_ATTRIBUTE_GETTER(Calendar, ButtonSpace, Core::Vector2)
	{
		return m_ButtonSpace;
	}

	PDE_ATTRIBUTE_SETTER(Calendar, ButtonSpace, Core::Vector2)
	{
		if(m_ButtonSpace!=value)
			m_ButtonSpace = value;
	}

	PDE_ATTRIBUTE_GETTER(Calendar, HighSpace, F32)
	{
		return m_HighSpace;
	}

	PDE_ATTRIBUTE_SETTER(Calendar, HighSpace, F32)
	{
		if(m_HighSpace!=value)
			m_HighSpace = value;
	}

	PDE_ATTRIBUTE_GETTER(Calendar, BtnSkin, tempc_ptr(Gui::ButtonSkin))
	{
		return m_itBtnSkin;
	}

	PDE_ATTRIBUTE_SETTER(Calendar, BtnSkin, tempc_ptr(Gui::ButtonSkin))
	{
		if(m_itBtnSkin!=value)
			m_itBtnSkin = value;
	}
	
	PDE_ATTRIBUTE_GETTER(Calendar, BtnSkinSupply, tempc_ptr(Gui::ButtonSkin))
	{
		return m_BtnSkinSupply;
	}

	PDE_ATTRIBUTE_SETTER(Calendar, BtnSkinSupply, tempc_ptr(Gui::ButtonSkin))
	{
		if(m_BtnSkinSupply!=value)
			m_BtnSkinSupply = value;
	}

	PDE_ATTRIBUTE_GETTER(Calendar, BtnSkinPrepare, tempc_ptr(Gui::ButtonSkin))
	{
		return m_BtnSkinPrepare;
	}

	PDE_ATTRIBUTE_SETTER(Calendar, BtnSkinPrepare, tempc_ptr(Gui::ButtonSkin))
	{
		if(m_BtnSkinPrepare!=value)
			m_BtnSkinPrepare = value;
	}

	PDE_ATTRIBUTE_GETTER(Calendar, CanSupplyNum, int)
	{
		return m_CanSupplyNum;
	}

	PDE_ATTRIBUTE_SETTER(Calendar, CanSupplyNum, int)
	{
		if(m_CanSupplyNum!=value)
			m_CanSupplyNum = value;
	}

	PDE_ATTRIBUTE_GETTER(Calendar, CanPrepareNum, int)
	{
		return m_CanPrepareNum;
	}

	PDE_ATTRIBUTE_SETTER(Calendar, CanPrepareNum, int)
	{
		if(m_CanPrepareNum!=value)
			m_CanPrepareNum = value;
	}

	PDE_ATTRIBUTE_GETTER(Calendar, CheckValue, int)
	{
		return m_CheckValue;
	}

	PDE_ATTRIBUTE_SETTER(Calendar, CheckValue, int)
	{
		if(m_CheckValue!=value)
			m_CheckValue = value;
	}
}

namespace Gui
{
	void Calendar::OnCreate()
	{
		Control::OnCreate();

		m_Month_Day_Num[0] = 31;
		m_Month_Day_Num[1] = 31;
		m_Month_Day_Num[2] = 28;
		m_Month_Day_Num[3] = 31;
		m_Month_Day_Num[4] = 30;
		m_Month_Day_Num[5] = 31;
		m_Month_Day_Num[6] = 30;
		m_Month_Day_Num[7] = 31;
		m_Month_Day_Num[8] = 31;
		m_Month_Day_Num[9] = 30;
		m_Month_Day_Num[10]= 31;
		m_Month_Day_Num[11]= 30;
		m_Month_Day_Num[12]= 31;
		m_CanPrepareNum = 0;
		m_CanSupplyNum = 0;
		m_CheckValue = -1;
		for(int i = 0; i < 32;++i)
			m_AllDay_Signin[i] = false;

		m_itBtn = ptr_new Button;
		m_itBtn->SetParent(ptr_static_cast<Calendar>(this));
		m_itBtn->SetSize(Core::Vector2(0,0));
		m_itBtn->SetLocation(Core::Vector2(0,0));
		m_itBtn->SetTextColor(Core::ARGB(255, 0, 0, 0));
		m_itBtn->Setblink(true);
		m_itBtn->SetblinkwheelTimer(0.6f);
		m_itBtn->EventClick.Subscribe(NewDelegate(&Calendar::_OnBtnClick,ptr_static_cast<Calendar>(this)));

		for(int i = 0; i < 30;++i)
		{
			m_Buttons[i] = ptr_new Button;
			m_Buttons[i]->SetParent(ptr_static_cast<Calendar>(this));
			m_Buttons[i]->SetSize(Core::Vector2(0,0));
			m_Buttons[i]->SetLocation(Core::Vector2(0,0));
			m_Buttons[i]->SetTextColor(Core::ARGB(255, 0, 0, 0));
			m_Buttons[i]->Setblink(true);
			m_Buttons[i]->SetblinkwheelTimer(0.6f);
			m_Buttons[i]->EventClick.Subscribe(NewDelegate(&Calendar::_OnBtnClick,ptr_static_cast<Calendar>(this)));
		}
	}

	void Calendar::OnFrameUpdate(EventArgs & e)
	{
		Control::OnFrameUpdate(e);

		if (m_itBtn)
			m_itBtn->OnFrameUpdate(e);
	}

	void Calendar::OnPaint(PaintEventArgs & e)
	{
		Control::OnPaint(e);
		
		tempc_ptr(CalendarSkin) skin = ptr_static_cast<CalendarSkin>(GetSkin());
		if (skin)
		{
			Skin::DrawImage(e.render, skin->GetBackgroundImage(), GetBackgroundRect());
		}

		if (m_Week != -1 && m_Year != -1 && m_Month != -1 && m_Day != -1)
		{
			//for debug
			//m_Year = 2012;
			//m_Month = 4;
			//m_Day = 30;
			//m_Week = 2;

			int startday = 1;
			int year = m_Year;
			int month = m_Month;
			int week = m_Week;
			while (week - m_Day % 7 <= 0)
			{
				week += 7;
			}
			int startweek = week - m_Day % 7; 

			if (year % 4 == 0)
				m_Month_Day_Num[2] = 29;

			if (startweek > 0)
			{
				month -= 1;
				startday = m_Month_Day_Num[month]-startweek+1;
			}

			for(int i = 0; i < 42; ++i)
			{
				if (startday > m_Month_Day_Num[month])
				{
					startday = 1;
					month++;
					if (month > 12)
					{
						month = 1;
						year += 1;
					}
				}

				Core::Vector2 bt_size;
				bt_size.x = (GetSize().x-m_ButtonSpace.x*8)/7;
				bt_size.y = (GetSize().y-m_HighSpace-m_ButtonSpace.y*7)/6;
				Core::Vector2 bt_location;
				bt_location.x = (m_ButtonSpace.x+bt_size.x)*(i%7)+m_ButtonSpace.x;
				bt_location.y = m_HighSpace + (m_ButtonSpace.y+bt_size.y)*(i/7)+m_ButtonSpace.y;
				m_Text = Core::String::Format("%d", startday);
				Core::Rectangle rect = Core::Rectangle::LeftTop(bt_location,bt_size);

				if (startday == m_Day && !m_AllDay_Signin[startday])
				{
					if (month == m_Month)
					{
						m_itBtn->SetVisible(true);
						m_itBtn->SetSkin(m_itBtnSkin);
						m_itBtn->SetSize(bt_size);
						m_itBtn->SetLocation(Core::Vector2(bt_location));
						m_itBtn->SetFontSize(GetFontSize());
						m_itBtn->SetText(m_Text);
						m_itBtn->SetTextColor(GetTextColor());
						m_itBtn->SetHighlightTextColor(GetTextColor());
					}
					else
					{
						Skin::DrawImage(e.render, skin->GetDisabledImage(),rect);
					}
				}
				else if (startday != m_Day)
				{
					if (month != m_Month)
					{
						Skin::DrawImage(e.render, skin->GetDisabledImage(),rect);
					}
					else
					{
						if (startday > m_Day)
						{
							int num = startday - m_Day - 1;
							if (startday - m_Day <= m_CanPrepareNum && m_CanPrepareNum > 0)
							{
								if (!m_AllDay_Signin[startday])
								{
									m_Buttons[num]->SetVisible(true);
									m_Buttons[num]->SetSkin(m_BtnSkinPrepare);
									m_Buttons[num]->SetSize(bt_size);
									m_Buttons[num]->SetLocation(Core::Vector2(bt_location));
									m_Buttons[num]->SetFontSize(GetFontSize());
									m_Buttons[num]->SetText(m_Text);
									m_Buttons[num]->SetTextColor(GetTextColor());
									m_Buttons[num]->SetHighlightTextColor(GetTextColor());
								}
								else
								{
									m_Buttons[num]->SetVisible(false);
									Skin::DrawImage(e.render, skin->GetActivateImage(),rect);
								}
							}
							else
							{
								Skin::DrawImage(e.render, skin->GetDisabledImage(),rect);
							}
						}
						else
						{
							int num = startday - m_Day + m_CanSupplyNum;
							if (m_Day - startday <= m_CanSupplyNum && m_CanSupplyNum > 0)
							{
								if (!m_AllDay_Signin[startday])
								{
									m_Buttons[num]->SetVisible(true);
									m_Buttons[num]->SetSkin(m_BtnSkinSupply);
									m_Buttons[num]->SetSize(bt_size);
									m_Buttons[num]->SetLocation(Core::Vector2(bt_location));
									m_Buttons[num]->SetFontSize(GetFontSize());
									m_Buttons[num]->SetText(m_Text);
									m_Buttons[num]->SetTextColor(GetTextColor());
									m_Buttons[num]->SetHighlightTextColor(GetTextColor());
								}
								else
								{
									m_Buttons[num]->SetVisible(false);
									Skin::DrawImage(e.render, skin->GetActivateImage(),rect);
								}
							}
							else
							{
								if (m_AllDay_Signin[startday])
									Skin::DrawImage(e.render, skin->GetActivateImage(),rect);
								else
									Skin::DrawImage(e.render, skin->GetInActivateImage(),rect);
							}
						}
					}
				}
				else
				{
					if (month == m_Month)
					{
						m_itBtn->SetVisible(false);
						Skin::DrawImage(e.render, skin->GetActivateImage(),rect);
					}
					else
					{
						m_itBtn->SetVisible(false);
						Skin::DrawImage(e.render, skin->GetDisabledImage(),rect);
					}
				}

				Core::ARGB textcolor = GetTextColor();
				if (month != m_Month)
					textcolor = Core::ARGB(255,180,180,180);
				else
					textcolor = GetTextColor();
				e.render->DrawString(GetFont(), textcolor, ARGB(0, 0, 0, 0), rect, m_Text, Unit::kAlignCenterMiddle);

				startday++;
			}
		}
	}

	void Calendar::_OnBtnClick(by_ptr(void) sender, InputEventArgs & e)
	{
		sharedc_ptr(Button) btn = ptr_static_cast<Button>(sender);
		if (btn)
		{
			m_CheckValue = atoi(btn->GetText().Str());
		}
		EventButtonClick.Fire(ptr_static_cast<Calendar>(this), e);
	}

	void Calendar::OnInputEvent(Client::InputEventArgs &e)
	{
		if (!e.Handled)
			Control::OnInputEvent(e);
	}

	void Calendar::SetTime(int year, int month, int day, int week)
	{
		if (m_Month != -1 && m_Month != month)
		{
			for (int i = 0; i < 32; i++)
			{
				m_AllDay_Signin[i] = false;
			}
		}
		m_Year = year;
		m_Month = month;
		m_Day = day;
		m_Week = week+1;	//�����һ
		m_CheckValue = -1;
		m_itBtn->SetVisible(false);
		for(int i = 0; i < 30;++i)
		{
			m_Buttons[i]->SetVisible(false);
		}
	}

	void Calendar::SetDayActivate(int day)
	{
		if (day >= 1 && day <= 31)
		{
			m_AllDay_Signin[day] = true;
		}
	}
}