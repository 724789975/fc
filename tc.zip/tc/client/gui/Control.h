//Macro
#define INLINE_PDE_GUI_ATTRIBUTE_R(attrName, attrType)									\
	DECLARE_PDE_ATTRIBUTE_R(attrName, attrType) { return m_##attrName; }

#define INLINE_PDE_GUI_ATTRIBUTE_W(attrName, attrType)									\
	DECLARE_PDE_ATTRIBUTE_W(attrName, attrType) { if (m_##attrName != value) {m_##attrName = value; Invalid();}}

#define INLINE_PDE_GUI_ATTRIBUTE_RW(attrName, attrType)									\
	INLINE_PDE_GUI_ATTRIBUTE_R(attrName, attrType);										\
	INLINE_PDE_GUI_ATTRIBUTE_W(attrName, attrType)


namespace Gui
{
	class ToolTip;
	class Balloon;
	class PopupFrame;
	class NoticeBoard;

	// control class
	class Control : public Core::Object
	{
		friend class GuiSystem;
		friend class Window;
		friend class RegionHelper;
		friend class ControlSkin;

	public:
		enum DockKind
		{
			kDockNone,
			kDockLeft,
			kDockTop,
			kDockRight,
			kDockBottom,
			kDockFill,
			kDockLeftTop,
			kDockRightTop,
			kDockLeftBottom,
			kDockRightBottom,
			kDockCenter,
			kDockTopCenter,
			kDockBottomCenter,
			kDockHorizontalCenter,
		};

	public:
		DECLARE_PDE_EVENT(EventDragEnter,			DragEventArgs);
		DECLARE_PDE_EVENT(EventDragLeave,			DragEventArgs);
		DECLARE_PDE_EVENT(EventDragOver,			DragEventArgs);
		DECLARE_PDE_EVENT(EventDragDrop,			DragEventArgs);

		DECLARE_PDE_EVENT(EventEnter,				EventArgs);
		DECLARE_PDE_EVENT(EventLeave,				EventArgs);

		DECLARE_PDE_EVENT(EventMouseEnter, InputEventArgs);
		DECLARE_PDE_EVENT(EventMouseLeave, InputEventArgs);
		DECLARE_PDE_EVENT(EventMouseDown, InputEventArgs);
		DECLARE_PDE_EVENT(EventMouseUp, InputEventArgs);
		DECLARE_PDE_EVENT(EventMouseRightUp, InputEventArgs);

		DECLARE_PDE_EVENT(EventActiveChanged,		EventArgs);
		DECLARE_PDE_EVENT(EventTextChanged,			EventArgs);
		DECLARE_PDE_EVENT(EventFocusChanged,		EventArgs);
		DECLARE_PDE_EVENT(EventFocusControlChanged,	EventArgs);
		DECLARE_PDE_EVENT(EventTextColorChanged,	EventArgs);
		DECLARE_PDE_EVENT(EventSizeChanged,			ResizeEventArgs);
		DECLARE_PDE_EVENT(EventParentChanged,		EventArgs);
		DECLARE_PDE_EVENT(EventEscPressed,			InputEventArgs);
		DECLARE_PDE_EVENT(EventChangeState,			InputEventArgs);

	public:
		DECLARE_PDE_ATTRIBUTE_RW(Parent,			tempc_ptr(Control));
		DECLARE_PDE_ATTRIBUTE_R (Root,				tempc_ptr(Control));
		DECLARE_PDE_ATTRIBUTE_R (Next,				tempc_ptr(Control));
		DECLARE_PDE_ATTRIBUTE_R (Previous,			tempc_ptr(Control));
		DECLARE_PDE_ATTRIBUTE_R (FirstChild,		tempc_ptr(Control));
		DECLARE_PDE_ATTRIBUTE_R (LastChild,			tempc_ptr(Control));

		DECLARE_PDE_ATTRIBUTE_RW(Location,			Core::Vector2);
		DECLARE_PDE_ATTRIBUTE_RW(Size,				Core::Vector2);
		DECLARE_PDE_ATTRIBUTE_R (Scroll,			Core::Vector2);

		DECLARE_PDE_ATTRIBUTE_RW(Visible,			bool);
		DECLARE_PDE_ATTRIBUTE_RW(Enable,			bool);
		DECLARE_PDE_ATTRIBUTE_RW(AutoSize,			bool);

		DECLARE_PDE_ATTRIBUTE_RW(Dock,				DockKind);
		DECLARE_PDE_ATTRIBUTE_RW(Margin,			Core::Vector4);
		DECLARE_PDE_ATTRIBUTE_RW(Padding,			Core::Vector4);

		DECLARE_PDE_ATTRIBUTE_RW(Text,				const Core::String &);
		SIMPLE_PDE_ATTRIBUTE_RW(UseTextKey,			bool);
		DECLARE_PDE_ATTRIBUTE_RW(Hint,				const Core::String &);
		DECLARE_PDE_ATTRIBUTE_RW(Tag,				tempc_ptr(void));

		DECLARE_PDE_ATTRIBUTE_R (BackgroundRect,	Core::Rectangle);
		//Actual paint rect in local space
		DECLARE_PDE_ATTRIBUTE_R (ActualPaintRect,	Core::Rectangle);
		DECLARE_PDE_ATTRIBUTE_R (ClientRect,		Core::Rectangle);
		DECLARE_PDE_ATTRIBUTE_R (DisplayRect,		Core::Rectangle);
		DECLARE_PDE_ATTRIBUTE_R (DisplayPadding,	Core::Vector4);

		DECLARE_PDE_ATTRIBUTE_RW(TextColor,			Core::ARGB);
		DECLARE_PDE_ATTRIBUTE_RW(TextShadowColor,	Core::ARGB);
		DECLARE_PDE_ATTRIBUTE_RW(TextLightSource,	F32);
		DECLARE_PDE_ATTRIBUTE_RW(HighlightTextColor,Core::ARGB);
		DECLARE_PDE_ATTRIBUTE_RW(DisabledTextColor,	Core::ARGB);
		DECLARE_PDE_ATTRIBUTE_RW(BackgroundColor,	Core::ARGB);

		DECLARE_PDE_ATTRIBUTE_RW(UseTime,		bool);
		DECLARE_PDE_ATTRIBUTE_RW(DisplayTime,	F32);

		DECLARE_PDE_ATTRIBUTE_R (Active,			Core::Bool);
		DECLARE_PDE_ATTRIBUTE_RW(CanFocus,			Core::Bool);
		DECLARE_PDE_ATTRIBUTE_RW(Focused,			Core::Bool);
		DECLARE_PDE_ATTRIBUTE_RW(Capture,			Core::Bool);

		INLINE_PDE_ATTRIBUTE_RW(TabFocus,			Core::Bool);

		DECLARE_PDE_ATTRIBUTE_RW(Style,				const Core::String &);
		DECLARE_PDE_ATTRIBUTE_RW(Skin,				tempc_ptr(ControlSkin));

		DECLARE_PDE_ATTRIBUTE_R (Font,				tempc_ptr(Client::Font));
		DECLARE_PDE_ATTRIBUTE_W (Font,				const Core::String &);
		DECLARE_PDE_ATTRIBUTE_RW(FontSize,			Core::Float);


		DECLARE_PDE_ATTRIBUTE_R(MinimumSize,	Core::Vector2) { return Core::Vector2(0, 0); }
		DECLARE_PDE_ATTRIBUTE_R(DefaultSize,	Core::Vector2) { return Core::Vector2(16, 16); }

		INLINE_PDE_ATTRIBUTE_RW(Shine,				Core::Bool);
		SIMPLE_PDE_ATTRIBUTE_RW(TextEllipsis,			bool);
		
		//Debug: for fine-tune
		INLINE_PDE_ATTRIBUTE_RW(CONTROL_HOVER_EFFECT_DURATION,		F32);
		INLINE_PDE_ATTRIBUTE_RW(CONTROL_SHINE_EFFECT_DURATION,		F32);
		INLINE_PDE_ATTRIBUTE_RW(CONTROL_BALLOON_FRAME_DURATION,		F32);

		SIMPLE_PDE_ATTRIBUTE_RW(IntTag,		int);		//could be some marking use in lua

	public:
		// on create
		virtual void OnCreate();

		// on destroy
		virtual void OnDestroy();

		// on frame update
		virtual void OnFrameUpdate(EventArgs & e);

		// on event
		virtual void OnInputEvent(InputEventArgs & e);

		// on enter
		virtual void OnEnter(EventArgs & e);

		// on leave
		virtual void OnLeave(EventArgs & e);

		virtual void OnMouseEnter(InputEventArgs & e);

		virtual void OnMouseLeave(InputEventArgs & e);

		virtual void OnMouseDown(InputEventArgs & e);

		virtual void OnMouseUp(InputEventArgs & e);

		/// on active changed
		virtual void OnActiveChanged(EventArgs & e);

		// on focus control changed
		virtual void OnFocusControlChanged(FocusEventArgs & e);

		// on focus changed
		virtual void OnFocusChanged(EventArgs & e);

		// on paint
		virtual void OnPaint(PaintEventArgs & e);

		// on autosize
		virtual void OnAutoSize(AutoSizeEventArgs & e);

		// on layout
		virtual void OnLayout(EventArgs & e);

		// on visible changed
		virtual void OnVisibleChanged(EventArgs & e);

		// on text changed
		virtual void OnTextChanged(EventArgs & e);

		// on enable changed
		virtual void OnEnableChanged(EventArgs & e);

		// on size changed
		virtual void OnLocationChanged(MoveEventArgs & e);

		// on size changed
		virtual void OnSizeChanged(ResizeEventArgs & e);

		// on background color changed
		virtual void OnBackgroundColorChanged(EventArgs & e);

		// on font changed
		virtual void OnFontChanged(EventArgs & e);

		// update style
		virtual void OnStyleChanged(EventArgs & e);

		// on parent changed
		virtual void OnChildrenChanged(ChildrenChangedEventArgs & e);

		virtual void RearrangeChildren();
		// on parent changed
		virtual void OnParentChanged(EventArgs & e);

		// on language changed
		virtual void OnLanguageChanged(EventArgs & e);

		// Add Image
		virtual void AddFrame(sharedc_ptr(Image) &e);

		// Delete All Image
		virtual void DeleteAllImage();

	public:
		// constructor.
		Control();

		// destructor.
		~Control();

		// change parent of this control.
		void ChangeParent(by_ptr(Control) parent, by_ptr(Control) insertBefore, bool parentNeedRearrangeChildren = true);

		void ReleaseFocus(void);

		// invalid
		void Invalid();

		// invalid rect
		void InvalidRect(const Core::Rectangle & rect);

		// screen to local
		virtual Core::Vector2 ScreenToClient(const Core::Vector2 & pos);

		// local to screen
		virtual Core::Vector2 ClientToScreen(const Core::Vector2 & pos);

		// screen to local
		virtual Core::Vector2 GlobalScreenToClient(const Core::Vector2 & pos);

		// local to screen
		virtual Core::Vector2 ClientToGlobalScreen(const Core::Vector2 & pos);
		
		// get text width
		virtual F32 TextWidth(const Core::String & text);

		/// get next node
		Control* GetNextNode(bool bSkipChilds = false);

		/// get prev node
		Control* GetPrevNode(bool bSkipChilds = false);

		// control from location. 
		virtual tempc_ptr(Control) ControlFromLocation(const Core::Vector2 & pos);

		// render
		virtual void Render(RenderEventArgs & e);

		// dirty layout
		void DirtyLayout(bool dirtyChilds = false);

		// find child
		tempc_ptr(Control) FindChildByText(const Core::String & text);

		// get child by id
		tempc_ptr(Control) GetChildByIndex(int index);

		/// check if this control is the other control's child
		bool IsChildOf(by_ptr(Control) control);

		virtual void BalloonInternal(const Core::String& str, int style, Core::Rectangle rect);
		virtual void Balloon(const Core::String& str);
		virtual void Balloon2(const Core::String& str);
		virtual void CancelBalloon();
		virtual void UpdateBalloon();

		virtual void PopNoticeBoardInternal(const Core::String& str, Core::Rectangle rect);
		virtual void PopNoticeBoard(const Core::String& str);
		virtual void CancelNoticeBoard();
		virtual void UpdateNoticeBoard();

		virtual void PopFrameInternal(Core::Rectangle rect);
		virtual void PopFrame();
		virtual void CancelFrame();
		virtual void UpdateFrame();

		void ClearAllFrames();
		void ClearAllBalloons();
		void ClearAllNoticeBoards();

		virtual bool GetVisibility();

		// Mouse over effect parameter
		virtual void IncreaseHoverPower(bool bHover = true);
		virtual void DecreaseHoverPower(bool bHover = true);
		float GetHoverPower(void);

		virtual void Shine(void);

		// set cursor shape
		void SetCursorShape(Client::Screen::CursorShape shape);

		//Utility
	public:
		static int SplitString(const Core::String& source, Core::String& target, const Core::Rectangle& rect, tempc_ptr(Client::Font) font);
		static int SplitString(const Core::String& source, Core::String& target, F32 maxWidth, tempc_ptr(Client::Font) font);
		static int EllipsisString(const Core::String& source, Core::String& target, const Core::Vector2& boundary, tempc_ptr(Client::Font) font);

	protected:
		// update layout
		void UpdateLayout(bool updateChilds = false);
		void RemoveAllChildren();
		tempc_ptr(Control) GetNextLeaf();
		tempc_ptr(Control) GetPrevLeaf();
		tempc_ptr(Control) GetNextFocusableControl();
		tempc_ptr(Control) GetPrevFocusableControl();

	protected:
		Control * m_Parent;
		Control * m_Next;
		Control * m_Prev;
		Control * m_FirstChild;
		Control * m_LastChild;

		Core::Vector2	m_Location;
		Core::Vector2	m_Size;
		Core::Vector2	m_TextureSize;
		Core::Vector2	m_Scroll;
		Core::String	m_Text;
		Core::String	m_TextKey;
		Core::String	m_Hint;
		Core::Vector4	m_Margin;
		Core::Vector4	m_Padding;
		DockKind		m_Dock;
		Core::String	m_Style;

		Core::Rectangle m_DockClient;
		Core::Rectangle	m_DirtyRect;

		Core::ARGB			m_TextColor;
		Core::ARGB			m_TextShadowColor;
		F32					m_TextLightSource;
		Core::ARGB			m_HighlightTextColor;
		Core::ARGB			m_DisabledTextColor;
		Core::ARGB		m_BackgroundColor;
		Core::Bool		m_Active;
		Core::Bool		m_CanFocus;
		Core::Bool		m_TabFocus;

		bool m_Enable : 1;
		bool m_Visible : 1;
		bool m_AutoSize: 1;
		bool m_LayoutDirty : 1;
		bool m_RegionDirty : 1;
		bool m_Shine : 1;
		
	protected:
		Core::String				m_FontName;
		sharedc_ptr(Gui::Balloon)	m_Balloon;
		sharedc_ptr(Gui::PopupFrame)	m_PopupFrame;
		sharedc_ptr(Gui::NoticeBoard)	m_NoticeBoard;


	private:
		sharedc_ptr(Client::Font)	m_Font;
		float						m_FontSize;
		sharedc_ptr(ControlSkin)		m_Skin;
		sharedc_ptr(void)			m_Tag;
		F32							m_Timer;
		bool						m_UseTime;
		F32							m_DisplayTime;
		uint                        m_BackgroundSum;
		uint						m_BackChoose;
		Core::Array<sharedc_ptr(Image)>  m_BackgroundImages;
	
	public:
		static sharedc_ptr(ToolTip)	s_ToolTip;

	protected:
		float m_HoverPower;
		float m_CONTROL_HOVER_EFFECT_DURATION;
		float m_CONTROL_SHINE_EFFECT_DURATION;
		float m_CONTROL_BALLOON_FRAME_DURATION;
		bool  m_HoverIncreasing;
	};
}

namespace Gui
{
	// control skin
	class ControlSkin : public Core::Object
	{
	public:
		INLINE_PDE_ATTRIBUTE_RW(BackgroundImage,	tempc_ptr(Image));

	public:
		ControlSkin(){}

	private:
		sharedc_ptr(Image)	m_BackgroundImage;
	};
}

namespace Gui
{
	// control skin
	class TimeControl : public Control
	{
		DECLARE_PDE_OBJECT(TimeControl, Control);

	public:
		DECLARE_PDE_EVENT(EventTimeOut, EventArgs);
		DECLARE_PDE_EVENT(EventTimeUpdate, EventArgs);

		// on paint
		virtual void OnFrameUpdate(EventArgs & e);
		
		void AddTime(float t);
		void CleanAll();

	private:
		Core::Array<float> mTimers; 
	};
}
