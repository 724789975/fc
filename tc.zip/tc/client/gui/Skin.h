namespace Gui
{
	struct Skin
	{
		// draw image
		static void DrawImage(by_ptr(Client::UIRender) render, by_ptr(Gui::Image) image, const Core::Rectangle & rect, Core::ARGB color = Core::ARGB(255, 255, 255, 255));
	
		// draw icon text
		static void DrawIconText(by_ptr(Client::UIRender) render, by_ptr(Gui::Icon) icon, by_ptr(Client::Font) font, const CHAR* text, const Core::Rectangle & rect, Client::Unit::Align align, Core::ARGB iconColor, Core::ARGB textColor, bool iconEnable = true, bool textEnable = true, F32 space = 4, F32 space_x = 0, F32 space_y = 0);

		// measure icon text
		static Core::Vector2 MeasureIconText(by_ptr(Gui::Icon) icon, by_ptr(Client::Font) font, const CHAR* text, F32 space = 4);

	};
}