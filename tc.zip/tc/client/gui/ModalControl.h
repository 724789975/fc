
namespace Gui
{
	class ModalControlRoot: public Control
	{
		DECLARE_PDE_OBJECT(ModalControlRoot, Control);
	public:
		DECLARE_PDE_EVENT(EventClose,		Core::EventArgs);
		DECLARE_PDE_EVENT(EventTimeUp,		Core::EventArgs);
		INLINE_PDE_ATTRIBUTE_RW(Timer,		F32);
		DECLARE_PDE_ATTRIBUTE_RW(Icon,			tempc_ptr(ProportionIcon));
		DECLARE_PDE_ATTRIBUTE_RW (ContentSize,	Core::Vector2);

	public:
		ModalControlRoot();
		// on frame update
		virtual void OnFrameUpdate(EventArgs & e);

		virtual void OnPaint(PaintEventArgs & e);

		virtual void Close();

	protected:
		F32						m_Timer;
		F32						m_TimeRunning;
		bool					m_Closed;	//In case of closed window held by lua

		sharedc_ptr(ProportionIcon)	m_Icon;
	};
	class ModalControl: public Control
	{
		DECLARE_PDE_OBJECT(ModalControl, Control);

	public:
		INLINE_PDE_ATTRIBUTE_RW (RootPanel,		tempc_ptr(ModalControlRoot));
		INLINE_PDE_ATTRIBUTE_RW(AllowEscToExit, bool);
		INLINE_PDE_ATTRIBUTE_RW(AllowF1,		bool);
	public:
		ModalControl();
		~ModalControl();

		// on create
		virtual void OnCreate();

		// on input event
		virtual	void OnInputEvent(Client::InputEventArgs &e);

		virtual void Close();

	protected:
		sharedc_ptr(ModalControlRoot)		m_RootPanel;
		bool					m_AllowEscToExit;
		bool					m_AllowF1;
	};
}