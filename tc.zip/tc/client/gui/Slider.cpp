#include "pch.h"

using namespace Core;
using namespace Gui;
using namespace Client;


DEFINE_PDE_TYPE_CLASS(Gui::SliderSkin)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::ControlSkin);
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_PROPERTY_RW(ThumbNormalImage);
		ADD_PDE_PROPERTY_RW(ThumbHoverImage);
		ADD_PDE_PROPERTY_RW(ThumbDownImage);
		ADD_PDE_PROPERTY_RW(ThumbDisabledImage);
	}
};

DEFINE_PDE_TYPE_ENUM(Slider::Direction)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_ENUM_ITEM("kHorizontal",		Slider::kHorizontal);
		ADD_PDE_ENUM_ITEM("kVertical",			Slider::kVertical);

		ADD_PDE_ENUM_CONSTRUCTOR();
	}
};

DEFINE_PDE_TYPE_ENUM(Slider::SliderType)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{

		ADD_PDE_ENUM_ITEM("kNormal",				Slider::kNormal);
		ADD_PDE_ENUM_ITEM("kRGB",					Slider::kRGB);
		ADD_PDE_ENUM_ITEM("kHSV",					Slider::kHSV);

		ADD_PDE_ENUM_CONSTRUCTOR();
	}

};

DEFINE_PDE_TYPE_CLASS(Gui::Slider)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::Control);

		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_PROPERTY_R(ThumbPos);
		ADD_PDE_PROPERTY_RW(Type);
		ADD_PDE_PROPERTY_RW(Shape);
		ADD_PDE_PROPERTY_RW(Index);
		ADD_PDE_PROPERTY_RW(Value);
		ADD_PDE_PROPERTY_RW(ThumbSize);
		ADD_PDE_PROPERTY_RW(CurValue);
		ADD_PDE_PROPERTY_RW(MinValue);
		ADD_PDE_PROPERTY_RW(MaxValue);
		ADD_PDE_PROPERTY_RW(Minimum);
		ADD_PDE_PROPERTY_RW(Maximum);
		ADD_PDE_PROPERTY_RW(LargeChange);
		ADD_PDE_PROPERTY_RW(IsInt);

		ADD_PDE_EVENT(EventValueChange);
		ADD_PDE_EVENT(EventValueChangedEnd);


	}
};

REGISTER_PDE_TYPE(Gui::SliderSkin);
REGISTER_PDE_TYPE(Gui::Slider);
REGISTER_PDE_TYPE(Gui::Slider::Direction);
REGISTER_PDE_TYPE(Gui::Slider::SliderType);

namespace Gui
{
	static const F32 BORDER_WIDTH	= 1;

	Slider::Slider()
		: m_Type(kNormal)
		, m_Shape(kHorizontal)
		, m_Index(0)
		, m_Value(Vector4::kZero)
		, m_ThumbSize(8, 8)
		, m_ThumbPos(0.f)
		, m_CurValue(0.f)
		, m_MinValue(0.f)
		, m_MaxValue(1.f)
		, m_Moving(false)
		, m_IsInt(false)
		, m_ThumbPointed(false)
		, m_Minimum(0)
		, m_Maximum(10)
		, m_LargeChange(5)

		, m_OldValue(0.f)
	{
	}

	Slider::~Slider()
	{
	}
}

//--------------------------------------------------------------------------------------
// Attribute
//--------------------------------------------------------------------------------------
namespace Gui
{
	PDE_ATTRIBUTE_GETTER(Slider, Type, Slider::SliderType)
	{
		return m_Type;
	}


	PDE_ATTRIBUTE_SETTER(Slider, Type, Slider::SliderType)
	{
		if (m_Type != value)
		{
			m_Type = value;

			//if (m_Type == kRGB || m_Type == kHSV)
			//	SetBorderStyle(BorderStyle::kOutset);
			DirtyLayout();

			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(Slider, Shape, Slider::Direction)
	{
		return m_Shape;
	}


	PDE_ATTRIBUTE_SETTER(Slider, Shape, Slider::Direction)
	{
		if (m_Shape != value)
		{
			m_Shape = value;

			SetThumbSize(Vector2(m_ThumbSize.y, m_ThumbSize.x));
			ChangeCurValue(GetCurValue());
			DirtyLayout();
		}
	}

	PDE_ATTRIBUTE_GETTER(Slider, Index, U32)
	{
		return m_Index;
	}


	PDE_ATTRIBUTE_SETTER(Slider, Index, U32)
	{
		if (m_Index != value && value < 4 && value > 0)
		{
			m_Index = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(Slider, Value, Vector4)
	{
		return m_Value;
	}


	PDE_ATTRIBUTE_SETTER(Slider, Value, Vector4)
	{
		if (m_Value != value)
		{
			m_Value = value;
			if (m_Type == kRGB || m_Type == kHSV)
			{
				ChangeCurValue(m_Value[m_Index]);
			}

			Invalid();
		}
	}


	PDE_ATTRIBUTE_GETTER(Slider, ThumbPos, F32)
	{
		return m_ThumbPos;
	}

	PDE_ATTRIBUTE_GETTER(Slider, ThumbSize, Vector2)
	{
		return m_ThumbSize;
	}


	PDE_ATTRIBUTE_SETTER(Slider, ThumbSize, Vector2)
	{
		if (m_ThumbSize != value)
		{
			m_ThumbSize = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(Slider, CurValue, F32)
	{
		return m_CurValue;
	}


	PDE_ATTRIBUTE_SETTER(Slider, CurValue, F32)
	{

		ChangeCurValue(value);
		Core::EventArgs args;
		args.Source = Core::EventArgs::kTriggerSourceSetter;
		OnValueChange(args);
		Invalid();
	}

	PDE_ATTRIBUTE_GETTER(Slider, MinValue, F32)
	{
		return m_MinValue;
	}


	PDE_ATTRIBUTE_SETTER(Slider, MinValue, F32)
	{
		if (m_MinValue != value)
		{
			if (value > GetMaxValue())
				value = GetMaxValue();

			m_MinValue = value;

			SetCurValue(GetCurValue());
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(Slider, MaxValue, F32)
	{
		return m_MaxValue;
	}


	PDE_ATTRIBUTE_SETTER(Slider, MaxValue, F32)
	{
		if (m_MaxValue != value)
		{
			if (value < GetMinValue())
				value = GetMinValue();

			m_MaxValue = value;

			SetCurValue(GetCurValue());
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(Slider, Minimum, U32)
	{
		return m_Minimum;
	}


	PDE_ATTRIBUTE_SETTER(Slider, Minimum, U32)
	{
		if (m_Minimum != value)
		{
			m_Minimum = value;

			if (value > GetMaximum())
				SetMaximum(value);
		}
	}

	PDE_ATTRIBUTE_GETTER(Slider, Maximum, U32)
	{
		return m_Maximum;
	}


	PDE_ATTRIBUTE_SETTER(Slider, Maximum, U32)
	{
		if (m_Maximum != value)
		{
			m_Maximum = value;

			if (value < GetMinimum())
				SetMinimum(value);
		}
	}

	PDE_ATTRIBUTE_GETTER(Slider, LargeChange, U32)
	{
		return m_LargeChange;
	}


	PDE_ATTRIBUTE_SETTER(Slider, LargeChange, U32)
	{
		if (m_LargeChange != value)
			m_LargeChange = value;
	}

	PDE_ATTRIBUTE_GETTER(Slider, IsInt, bool)
	{
		return m_IsInt;
	}


	PDE_ATTRIBUTE_SETTER(Slider, IsInt, bool)
	{
		if (m_IsInt != value)
		{
			m_IsInt = value;
			SetValue(GetValue());
		}
	}

	PDE_ATTRIBUTE_GETTER(Slider, StepValue, F32)
	{
		U32 marksCount = GetMaximum() - GetMinimum();

		if (marksCount == 0)
			return -1.f;

		F32 minValue = GetMinValue();
		F32 maxValue = GetMaxValue();

		F32 value = maxValue - minValue;

		if (value <= 0)
			return -1.f;

		return value / marksCount;
	}
}

//--------------------------------------------------------------------------------------
// Event
//--------------------------------------------------------------------------------------
namespace Gui
{
	/// on paint
	void Slider::OnPaint(PaintEventArgs & e)
	{
		Control::OnPaint(e);
		switch(m_Shape)
		{
		case kHorizontal:
			m_ThumbSize.y = m_Size.y;
			break;
		case kVertical:
			m_ThumbSize.x = m_Size.x;
			break;
		}

		if (m_Type == kRGB)
		{
			ARGB color;
			color.r = m_Value.r * 255.f;
			color.g = m_Value.g * 255.f;
			color.b = m_Value.b * 255.f;
			color.a = m_Value.a * 255.f;

			switch( m_Index )
			{
			case 0:     m_BackColor = XRGB(255, color.g, color.b);     break;
			case 1:     m_BackColor = XRGB(color.r, 255, color.b);     break;
			case 2:     m_BackColor = XRGB(color.r, color.g, 255);     break;
			case 3:     m_BackColor = ARGB(255, color.r, color.g, color.b);		break;
			}
		}

		Core::Rectangle rect(GetDisplayRect());

		switch (m_Type)
		{
		case kRGB:
			//skin.FillRGBRect(rect, m_BackColor, m_Index, m_Shape == EdtUILayout::kVertical);
			break;

		case kHSV:
			//skin.FillHSVRect(rect, Vector4(m_Value.rgb, 1), m_Index, m_Shape == EdtUILayout::kVertical);
			break;

		case kNormal:
			switch(m_Shape)
			{
			case kHorizontal:
				//				rect.Shrink(2, rect.GetExtent().y / 2  - 2, 2, rect.GetExtent().y / 2  - 2);
				break;

			case kVertical:
				//				rect.Shrink(rect.GetExtent().x / 2  - 2, 2, rect.GetExtent().x / 2  - 2, 2);
				break;
			}

			//e.render->DrawRectangle(rect,Core::Rectangle(0,0),ARGB(128,255,0,0));
			//skin.DrawBorder(rect, 1, XRGB(128, 128, 128), XRGB(255, 255, 255));
			//			rect.Shrink(1);
			//skin.DrawBorder(rect, 1, XRGB(64, 64, 64), XRGB(212, 208, 200));
			//e.render->DrawRectangle(rect,Core::Rectangle(0,0),ARGB(128,0,0,255));
			break;
		}

		Core::Rectangle thumbRect;

		switch(m_Shape)
		{
		case kHorizontal:
			thumbRect = Rectangle::LeftTop(GetDisplayRect().Min + Vector2(Core::Floor(m_ThumbPos+0.5f),0), m_ThumbSize);
			break;
		case kVertical:
			thumbRect = Rectangle::LeftTop(GetDisplayRect().Min + Vector2(0,Core::Floor(m_ThumbPos+0.5f)), m_ThumbSize);
			break;
		}

		tempc_ptr(SliderSkin) skin = ptr_dynamic_cast<SliderSkin>(GetSkin());
		if(skin)
		{
			if(m_Moving)
				Skin::DrawImage(e.render, skin->GetThumbDownImage(), thumbRect);
			else if(m_ThumbPointed)
				Skin::DrawImage(e.render, skin->GetThumbHoverImage(), thumbRect);
			else if(GetEnable())
				Skin::DrawImage(e.render, skin->GetThumbNormalImage(), thumbRect);
			else
				Skin::DrawImage(e.render, skin->GetThumbDisabledImage(), thumbRect);
		}
		else
		{
			e.render->DrawRectangle(thumbRect,thumbRect,XRGB(128,128,128));
		}
	}


	/// on input event
	void Slider::OnInputEvent(Client::InputEventArgs & e)
	{
		if (e.IsMouseEvent())
		{
			Vector2 localPos = ScreenToClient(e.CursorPosition);
			Core::Rectangle rectClient(GetDisplayRect());
			bool pointed = rectClient.IsPointInside(localPos);

			switch(e.Type)
			{
			case Client::InputEventArgs::kMouseDown:
				{
					if (e.Code == MC_LEFT_BUTTON && !m_Moving && pointed)
					{
						SetCapture(true);
						m_OldValue = GetCurValue();
						ChangeValueByMouse(localPos);
						m_Moving = true;
						e.Handled = true;
					}
				}
				break;

			case Client::InputEventArgs::kMouseUp:
				{
					if (e.Code == MC_LEFT_BUTTON && m_Moving)
					{
						SetCapture(false);
						m_Moving = false;
						e.Handled = true;
						Core::ValueChangeEventArgs valueEvent;
						valueEvent.OldValue = Boxing<F32>::ByValue(m_OldValue);
						valueEvent.NewValue = Boxing<F32>::ByValue(GetCurValue());
						OnValueChangedEnd(valueEvent);
					}
				}
				break;

			case Client::InputEventArgs::kMouseWheel:
				{
					if (GetActive())
					{
						Core::ValueChangeEventArgs valueEvent;
						valueEvent.OldValue = Boxing<F32>::ByValue(GetCurValue());
						switch( m_Shape )
						{
						case kHorizontal:
							ChangeValueByMouse(Vector2(10.f * e.Value + m_ThumbPos, 0));
							break;

						case kVertical:
							ChangeValueByMouse(Vector2(0, 10.f * e.Value + m_ThumbPos));
							break;
						}
						valueEvent.NewValue = Boxing<F32>::ByValue(GetCurValue());
						OnValueChangedEnd(valueEvent);

						e.Handled = true;
					}
				}
				break;

			case Client::InputEventArgs::kMouseMove:
				{
					if (m_Moving)
					{
						ChangeValueByMouse(localPos);
					}
					else
					{
						Core::Rectangle thumbRect;

						switch(m_Shape)
						{
						case kHorizontal:
							thumbRect = Rectangle::LeftTop(GetDisplayRect().Min + Vector2(m_ThumbPos,0), m_ThumbSize);
							break;
						case kVertical:
							thumbRect = Rectangle::LeftTop(GetDisplayRect().Min + Vector2(0,m_ThumbPos), m_ThumbSize);
							break;
						}
						if(thumbRect.IsPointInside(localPos))
						{
							if(!m_ThumbPointed)
							{
								m_ThumbPointed = true;
								Invalid();
							}
						}
						else
						{
							if(m_ThumbPointed)
							{
								m_ThumbPointed = false;
								Invalid();
							}
						}
					}

					e.Handled = true;
				}
				break;

			case Client::InputEventArgs::kMouseLeave:
				if(m_ThumbPointed)
				{
					m_ThumbPointed = false;
					Invalid();
				}
				break;
			}

		}

		if (e.IsKeyEvent())
			OnKeyEvent(e);

		if (!e.Handled)
			Control::OnInputEvent(e);

	}

	/// on key event
	void Slider::OnKeyEvent(Client::InputEventArgs & e)
	{
		// key down
		if (e.Type == Client::InputEventArgs::kKeyDown && !(e.ShiftKeyDown || e.ControlKeyDown || e.AltKeyDown))
		{
			U32 curMarkIndex = CurMarkIndex();

			switch (e.Code)
			{
			case KC_LEFT:
			case KC_UP:
				if (curMarkIndex > 0)
					ChangeToMarkIndex(curMarkIndex - 1);

				e.Handled = true;
				break;

			case KC_RIGHT:
			case KC_DOWN:
				ChangeToMarkIndex(curMarkIndex + 1);

				e.Handled = true;
				break;

			case KC_PGUP:
				if (curMarkIndex > 0)
				{
					U32 large = GetLargeChange();
					U32 min = GetMinimum();
					U32 index = (curMarkIndex > large + min)? curMarkIndex - large: min;

					ChangeToMarkIndex(index);
				}
				e.Handled = true;
				break;

			case KC_PGDOWN:
				{
					U32 large = GetLargeChange();
					U32 max = GetMaximum();
					U32 index = (curMarkIndex + large) < max? curMarkIndex + large: max;

					ChangeToMarkIndex(index);
				}
				e.Handled = true;
				break;

			case KC_HOME:
				if (curMarkIndex > GetMinimum())
					ChangeToMarkIndex(GetMinimum());

				e.Handled = true;
				break;

			case KC_END:
				if (curMarkIndex < GetMaximum())
					ChangeToMarkIndex(GetMaximum());

				e.Handled = true;
				break;

			default:
				break;
			}
		}
	}


	void Slider::OnLayout(Core::EventArgs & e)
	{
		Control::OnLayout(e);

		if (m_Type == kRGB || m_Type == kHSV)
		{
			switch (m_Shape)
			{
			case kHorizontal:
				{
					m_ThumbSize.y = GetDisplayRect().GetExtent().y;
				}
				break;
			case kVertical:
				{
					m_ThumbSize.x = GetDisplayRect().GetExtent().x;
				}
				break;
			}

			if (m_Type == kHSV && m_Index == 0)
			{
				SetMaxValue(359.99f);
			}
		}
	}
	
	///on value change
	void Slider::OnValueChange(Core::EventArgs & e)
	{
		EventValueChange.Fire(ptr_static_cast<Slider>(this), e);
	}

	/// on value changed end
	void Slider::OnValueChangedEnd(Core::ValueChangeEventArgs & e)
	{
		EventValueChangedEnd.Fire(ptr_static_cast<Slider>(this),e);
	}



}


//--------------------------------------------------------------------------------------
// Method
//--------------------------------------------------------------------------------------
namespace Gui
{
	void Slider::ChangeValueByMouse(Vector2 pos)
	{
		switch (m_Shape)
		{
		case kHorizontal:
			{
				F32 minPos = GetDisplayRect().Min.x;
				F32 maxPos = GetDisplayRect().Max.x - m_ThumbSize.x;
				m_ThumbPos = Clamp(pos.x - m_ThumbSize.x / 2 + 1, minPos, maxPos);
				ChangeCurValue(m_MinValue + (m_MaxValue - m_MinValue) * (m_ThumbPos - minPos) / (maxPos - minPos));
			}
			break;

		case kVertical:
			{
				F32 minPos = GetDisplayRect().Min.y;
				F32 maxPos = GetDisplayRect().Max.y - m_ThumbSize.y;
				m_ThumbPos = Clamp(pos.y - m_ThumbSize.y / 2 + 1, minPos, maxPos);
				ChangeCurValue(m_MaxValue - (m_MaxValue - m_MinValue) * (m_ThumbPos - minPos) / (maxPos - minPos));
			}
			break;
		}
		Core::EventArgs args;
		args.Source = Core::EventArgs::kTriggerSourceMouse;
		OnValueChange(args);
		Invalid();
	}

	void Slider::ChangeCurValue(F32 value)
	{
		if (value < m_MinValue)
		{
			m_CurValue = m_MinValue;
		}
		else if (value> m_MaxValue)
		{
			m_CurValue = m_MaxValue;
		}
		else
		{
			m_CurValue = value;
		}

		m_CurValue = GetIsInt()? (S32)m_CurValue: m_CurValue;

		m_Value[m_Index] = value;

		switch (m_Shape)
		{
		case kHorizontal:
			{
				F32 minPos = GetDisplayRect().Min.x;
				F32 maxPos = GetDisplayRect().Max.x - m_ThumbSize.x;
				m_ThumbPos = minPos + (maxPos - minPos) * (m_CurValue - m_MinValue) / (m_MaxValue - m_MinValue);
			}
			break;
		case kVertical:
			{
				F32 minPos = GetDisplayRect().Min.y;
				F32 maxPos = GetDisplayRect().Max.y - m_ThumbSize.y;
				m_ThumbPos = maxPos - (maxPos - minPos) * (m_CurValue - m_MinValue) / (m_MaxValue - m_MinValue);
			}
			break;
		}
	}

	/// changed to mark
	bool Slider::ChangeToMarkIndex(U32 markIndex)
	{
		if (markIndex < GetMinimum() || markIndex > GetMaximum())
			return false;

		F32 stepValue = GetStepValue();

		if (stepValue < 0)
			return false;

		F32 value = GetMinValue() + (markIndex - GetMinimum()) * stepValue;

		if (value > GetMaxValue())
			return false;

		Core::ValueChangeEventArgs valueEvent;
		valueEvent.OldValue = Boxing<F32>::ByValue(GetCurValue());

		ChangeCurValue(value);

		valueEvent.NewValue = Boxing<F32>::ByValue(GetCurValue());
		Core::EventArgs args;
		args.Source = Core::EventArgs::kTriggerSourceKeyboard;
		OnValueChange(args);
		OnValueChangedEnd(valueEvent);
		Invalid();

		return true;
	}

	/// get current mark index
	U32 Slider::CurMarkIndex()
	{
		F32 stepValue = GetStepValue();

		if (stepValue < 0)
			return 0;

		F32 value = GetCurValue() - GetMinValue();

		if (value < 0)
			return 0;

		return GetMinimum() + value / stepValue + EPSILON;
	}
}


