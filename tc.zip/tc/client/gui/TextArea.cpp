#include "pch.h"

using namespace Core;
using namespace Client;

namespace Gui
{
	TextArea::TextArea()
		: m_CursorVisible(false)
		, m_MaxLength(4096)
		, m_Count_n(0)
		, m_CursorTime(0)
		, m_Readonly(false)
		, m_Fold(false)
		, m_TextPadding(6,4,6,4)
	{
		SetTextBuffer(&m_Text);
		SetMultiline(true);
		//SetBorderStyle(BorderStyle::kOutset);
		SetBackgroundColor(XRGB(255,255,255));
		SetSelectionColor(XRGB(255, 255, 255));
		SetSelectionBgColor(XRGB(49, 106, 197));

		SetAcceptTab(true);
		m_HScrollBarDisplay = ScrollableControl::kVisible;
		m_VScrollBarDisplay = ScrollableControl::kVisible;

		m_CommandQueue = ptr_new CommandQueue;
	}

	TextArea::~TextArea()
	{
		m_CommandQueue = NullPtr;
	}
}

//--------------------------------------------------------------------------------------
// Attribute
//--------------------------------------------------------------------------------------
namespace Gui
{
	PDE_ATTRIBUTE_GETTER(TextArea, MaxLength, U32)
	{
		return m_MaxLength;
	}


	PDE_ATTRIBUTE_SETTER(TextArea, MaxLength, U32)
	{
		if (m_MaxLength != value)
		{
			m_MaxLength = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(TextArea, Count_n, int)
	{
		return m_Count_n;
	}


	PDE_ATTRIBUTE_SETTER(TextArea, Count_n, int)
	{
		if (m_Count_n != value)
		{
			m_Count_n = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(TextArea, TextPadding, Vector4)
	{
		return m_TextPadding;
	}

	PDE_ATTRIBUTE_SETTER(TextArea, TextPadding, Vector4)
	{
		if(m_TextPadding != value)
		{
			m_TextPadding = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(TextArea, SelectionColor, ARGB)
	{
		return m_SelectionColor;
	}

	PDE_ATTRIBUTE_SETTER(TextArea, SelectionColor, ARGB)
	{
		if (m_SelectionColor != value)
		{
			m_SelectionColor = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(TextArea, SelectionBgColor, ARGB)
	{
		return m_SelectionBgColor;
	}

	PDE_ATTRIBUTE_SETTER(TextArea, SelectionBgColor, ARGB)
	{
		if (m_SelectionBgColor != value)
		{
			m_SelectionBgColor = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(TextArea, Text, const Core::String &)
	{
		if(!m_Fold)
			return m_Text;
		else
			return GetRealText();
	}

	PDE_ATTRIBUTE_SETTER(TextArea, Text, const Core::String &)
	{
		m_VirtualEnterPos.Clear();
		m_Text = value;
		OnTextChanged(EventArgs());
	}

	PDE_ATTRIBUTE_GETTER(TextArea, Readonly, bool)
	{
		return m_Readonly;
	}


	PDE_ATTRIBUTE_SETTER(TextArea, Readonly, bool)
	{
		if (m_Readonly != value)
		{
			m_Readonly = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(TextArea, Fold, bool)
	{
		return m_Fold;
	}


	PDE_ATTRIBUTE_SETTER(TextArea, Fold, bool)
	{
		if (m_Fold != value)
		{
			m_Fold = value;
			if(m_Fold)
			{
				SetHScrollBarDisplay(ScrollableControl::kHide);
				SetVScrollBarDisplay(ScrollableControl::kVisible);
			}
			else
			{
				SetHScrollBarDisplay(ScrollableControl::kVisible);
				SetVScrollBarDisplay(ScrollableControl::kVisible);
			}
		}
	}

	PDE_ATTRIBUTE_SETTER(TextArea, TabFocus, Core::Bool)
	{
		Super::SetTabFocus(value);
		if(value)
		{
			SetAcceptTab(false);
		}
	}

	PDE_ATTRIBUTE_GETTER(TextArea, AllowEnter, bool)
	{
		return GetMultiline();
	}

	PDE_ATTRIBUTE_SETTER(TextArea, AllowEnter, bool)
	{
		SetMultiline(value);
	}
}


//--------------------------------------------------------------------------------------
// Event
//--------------------------------------------------------------------------------------
namespace Gui
{
	/// on create
	void TextArea::OnCreate()
	{
		ScrollableControl::OnCreate();
		SetAutoScroll(true);
	}


	/// on frame update
	void TextArea::OnFrameUpdate(EventArgs & e)
	{
		bool showCursor = false;

		if (GetFocused())
			showCursor = GetFocused() && ((static_cast<U32>((Core::Task::GetTotalTime() - m_CursorTime) * 2) & 1) == 0);

		if (m_CursorVisible != showCursor)
		{
			m_CursorVisible = showCursor;
			Invalid();
		}

		ScrollableControl::OnFrameUpdate(e);
	}


	// 	/// on render
	// 	void TextArea::OnPaintBorder(EdtUIPaintEventArgs & e)
	// 	{
	// 		Super::OnPaintBorder(e);
	// 
	// 		EdtUISkin & skin = *GUISystem->Skin;
	// 
	// 		// control rectangle
	// 		PdeRectangle displayRect = GetDisplayRect();
	// 		displayRect.Move(GetClientRect().Min);
	// 		
	// 		// draw background
	// 		if (!e.ControlEnable)
	// 			skin.FillRect(displayRect, XRGB(236,233,216));
	// 	}


	/// on paint
	void TextArea::OnPaint(PaintEventArgs & e)
	{
		ScrollableControl::OnPaint(e);

		// control rectangle
		Core::Rectangle clientRect(Vector2::kZero, GetClientRect().GetExtent());

		// move client rect
		clientRect.Shrink(GetTextPadding());

		// set scissor
		Core::Rectangle old_scissor = e.render->GetScissorRect();
		Core::Rectangle clip = GetDisplayRect();
		clip.Shrink(GetTextPadding());
		Core::Rectangle scissorClip = Core::Rectangle::LeftTop(ClientToScreen(Vector2::kZero + m_Scroll), GetSize());
		scissorClip.Shrink(GetDisplayPadding());
		scissorClip.Shrink(GetTextPadding());
		scissorClip.IntersectWith(old_scissor);

		tempc_ptr(TextAreaSkin) skin = ptr_dynamic_cast<TextAreaSkin>(GetSkin());

		if (!scissorClip.IsEmpty())
		{
			e.render->SetScissorRect(scissorClip);

			// draw input text
			DrawInputText(e.render, clientRect.Min, clip, e.Enable?GetTextColor():GetDisabledTextColor(), GetSelectionColor(), GetSelectionBgColor(), m_CursorVisible, GetFocused(), GetFont());

			// restore region
			e.render->SetScissorRect(old_scissor);
		}
	}


	/// on input event
	void TextArea::OnInputEvent(InputEventArgs & e)
	{
		if (e.IsKeyEvent())
		{
			// 			m_Hotkey.OnKeyEvent(GetHandle(), e);
			// 
			// 			if (e.Handled)
			// 				return;

			if (!GetReadonly())
			{
				// undo / redo
				if (e.Type == InputEventArgs::kKeyDown && e.ControlKeyDown)
				{
					switch (e.Code)
					{
					case KC_Z:
						DeleteVirtualEnter();
						ResetHistory();

						if (m_CommandQueue->GetCanUndo())
						{
							m_CommandQueue->Undo(1);
							e.Handled = true;
						}
						AddVirtualEnter();
						break;

					case KC_Y:
						DeleteVirtualEnter();
						ResetHistory();

						if (m_CommandQueue->GetCanRedo())
						{
							m_CommandQueue->Redo(1);
							e.Handled = true;
						}
						AddVirtualEnter();
						break;
					}
				}
			}

			if (!e.Handled)
			{
				if (OnKeyEvent(e, GetReadonly(), GetFont()))
				{
					e.Handled = true;
					return;
				}
			}
		}

		if (e.IsMouseEvent())
		{
			// client pos
			Vector2 pos = ScreenToClient(e.CursorPosition);

			if (GetSelecting() || GetDisplayRect().IsPointInside(pos))
			{
				Core::Rectangle TextRect = GetDisplayRect();
				if(GetSelecting() || TextRect.IsPointInside(pos))
				{
					// to text space
					pos.x = pos.x - GetTextPadding().x;
					pos.y = pos.y - GetTextPadding().y;

					if (OnMouseEvent(e, pos, GetFont()))
					{
						e.Handled = true;
						SetCapture(GetSelecting());
					}
					else if (e.Type == InputEventArgs::kMouseMove && !(e.LeftButtonDown || e.MiddleButtonDown || e.RightButtonDown))
					{
						e.Handled = true;
					}

					if (e.Handled)
						SetCursorShape(Screen::kCursorInput);
				}
				else
				{
					//In scrollbar area
					ScrollableControl::OnInputEvent(e);
				}
			}
		}

		if (!e.Handled)
			ScrollableControl::OnInputEvent(e);
	}


	/// on lost focus
	void TextArea::OnLeave(EventArgs & e)
	{
		Invalid();
		ScrollableControl::OnLeave(e);
	}


	/// on text changed
	void TextArea::OnTextChanged(EventArgs & e)
	{
		DeleteVirtualEnter();

		if (m_MaxLength > 0)
		{
			if (m_Text.Length() > m_MaxLength)
			{
				CRefStr & str = m_Text.RefStr(0);
				str.setlen(m_MaxLength);
				str.validate();
				SetCursorPosition(GetCursorPosition());
				EventLengthExceed.Fire(ptr_static_cast<TextArea>(this), Core::EventArgs());
			}
		}

		EventTextChanged.Fire(ptr_static_cast<TextArea>(this), e);
		AddVirtualEnter();
		//UpdateText();
	}

	/// on cursor move
	void TextArea::OnCursorMove(EventArgs & e)
	{
		// update cursor
		m_CursorTime = Core::Task::GetTotalTime();

		// update scroll
		Vector2 cursorPos;
		F32 lineHeight = GetFont()->GetLineHeight();

		if (IndexToPosition(GetFont(), GetCursorPosition(), cursorPos))
		{
			Vector4 textPadding = GetTextPadding();
			Vector2 anchorPoint(m_Fold?0:cursorPos.x, cursorPos.y);
			ScrollToView(Core::Rectangle::LeftTop(anchorPoint, Vector2(1 + textPadding.z + textPadding.x, lineHeight + textPadding.y + textPadding.w)));
		}

		Vector2 caret_pos = ClientToScreen(Vector2(cursorPos.x, cursorPos.y));

		// HACK : window
		sharedc_ptr(Window) window = ptr_dynamic_cast<Window>(GetRoot());
		if (window)
		{
			caret_pos += window->GetWorldLocation().xy;
		}

		ImeUi_SetCaretPosition(caret_pos.x, caret_pos.y);

		Invalid();
	}

	/// on font changed
	void TextArea::OnFontChanged(EventArgs & e)
	{
		DeleteVirtualEnter();
		AddVirtualEnter();
		//UpdateText();
		ScrollableControl::OnFontChanged(e);
	}



	/// on new history
	void TextArea::OnHistoryReset(InputHistory & e)
	{
		struct TextAreaUndoCommand : public Command
		{
			TextInput::InputHistory	m_History;
			TextInput&				m_Input;

			TextAreaUndoCommand(TextInput & input, const TextInput::InputHistory & history)
				: m_History(history)
				, m_Input(input)
			{
			}


			/// execute this command
			void OnRedo(Command & e)
			{
				m_Input.DoHistory(m_History, false);
			}

			/// unexecute this command
			void OnUndo(Command & e)
			{
				m_Input.DoHistory(m_History, true);
			}
		};

		m_CommandQueue->AddCommand(new TextAreaUndoCommand(*this, e), false);
	}

	void TextArea::OnFocusChanged(EventArgs & e)
	{
		Control::OnFocusChanged(e);
		if (GetFocused())
		{
			ImeUi_EnableIme(true);
			if(!m_Readonly)
				SelectAll();
		}
		else
		{
			ImeUi_FinalizeString();
			ImeUi_EnableIme(false);
		}
	}

	const Core::String& TextArea::GetRealText()
	{
		if(!m_Fold)
			return m_Text;

		m_RealText = m_Text;
		size_t Size = m_VirtualEnterPos.Size();

		if (Size > 0)
		{
			for (size_t i = 0; i < Size; i++)
			{
				size_t Pos = m_VirtualEnterPos[Size - i - 1];
				m_RealText.RefStr(0).remove(Pos);
			}
		}
		return m_RealText;
	}

	void TextArea::DeleteVirtualEnter()
	{
		if(!m_Fold)
			return;
		size_t start = GetSelectionStart();
		size_t end = GetSelectionEnd();

		size_t Size = m_VirtualEnterPos.Size();

		if (Size > 0)
		{
			size_t CPNew = GetCursorPosition();

			for (size_t i = 0; i < Size; i++)
			{
				size_t Pos = m_VirtualEnterPos[Size - i - 1];
				if (m_Text.RefStr(0).remove(Pos) > 0)
				{
					if (CPNew > Pos) CPNew--;
					if (start > Pos) start--;
					if (end > Pos) end--;
				}
			}

			m_VirtualEnterPos.Clear();
			SetCursorPosition(CPNew);
			SetSelection(start,end);
		}
	}

	void TextArea::AddVirtualEnter()
	{
		if(!m_Fold)
			return;

		tempc_ptr(Font) font = GetFont();
		if (font)
		{
			//m_VirtualEnterPos.Clear();
			DeleteVirtualEnter();		//Without this call, AddVirtualEnter could recognize virtual enter as a real enter

			size_t slStart = GetSelectionStart();
			size_t slEnd = GetSelectionEnd();

			Core::Rectangle displayRect = GetDisplayRect();
			displayRect.Shrink(GetTextPadding());
			Core::Vector2 controlSize = displayRect.GetExtent();
			//controlSize.x -= 15;

			//In case of the size is too small to fold
			if(controlSize.x<20)
				return;

			const CHAR* start = m_Text.Str();

			//build text info in font
			font->PreBuild(start);

			F32 cx = 0;
			size_t CP = GetCursorPosition();
			size_t CPNew = CP;
			m_Count_n = 0;
			// foreach character
			for (size_t i = 0;;)
			{
				size_t off = 1;
				F32 letterW;
#ifdef USE_UTF8
				U16 letter = 0;

				S32 len = GetUTF8CharLength((U8*)&start[i], -1);
				if (len)
				{
					UTF8toUTF16((U8*)&start[i], len, &letter, 1);
					i += len;
				}
#else
				U16 letter = start[i++];

				if (IsDBCSLeadByteEx(936, letter))
				{
					letter = (letter << 8) | (U8)start[i++];
					off++;
				}
#endif
				// string end
				if (letter == 0)
					break;

				if (letter == '\r' || letter == '\n')
				{
					cx = 0;
					m_Count_n++;
					continue;
				}

				// character info
				const Font::CharInfo & info = font->GetCharacterInfo(letter);
				letterW = info.horiAdvance + font->GetCharSpace();
#ifdef USE_UTF8
				size_t Pos = i - len;
#else
				size_t Pos = i - off;
#endif
				if(cx + letterW <= controlSize.x)
				{
					cx += letterW;
				}
				else if (m_Text.RefStrGrow(1, 32).insert(Pos, '\n') > 0)
				{
					m_VirtualEnterPos.PushBack(Pos);
					start = m_Text.Str();
#ifdef USE_UTF8
					i -= len;
#else
					i -= off - 1;
#endif
					cx = 0;
					m_Count_n++;
					if (CPNew > Pos) CPNew++;
					if (slStart > Pos) slStart++;
					if (slEnd > Pos) slEnd++;
				}
			}

			if (CP != CPNew)
				SetCursorPosition(CPNew);
			SetSelection(slStart, slEnd);

			UpdateText();
		}
	}
}


//--------------------------------------------------------------------------------------
// Method
//--------------------------------------------------------------------------------------
namespace Gui
{
	void TextArea::UpdateText()
	{
		Invalid();

		if (GetFont())
		{
			tempc_ptr(Font) font = GetFont();

			Vector2 size = Vector2::kZero;

			// currient character
			const CHAR* s = m_Text.Str();

			// init x
			F32 cx = 0;
			F32 cy = 0;

			// foreach character
			for (;;)
			{
#ifdef USE_UTF8
				U16 letter = 0;

				S32 len = GetUTF8CharLength((U8*)s, -1);
				if (len)
				{
					UTF8toUTF16((U8*)s, len, &letter, 1);
					s += len;
				}
#else
				U16 letter = *s++;
#endif
				
				// string end
				if (letter == 0)
					break;

				if (letter == '\r')
					continue;

				// character info
				const Font::CharInfo & info = font->GetCharacterInfo(letter);

				cx += info.horiAdvance + font->GetCharSpace();

				size.x = Max(size.x, cx);

				// line end
				if (letter == '\n')
				{
					cx = 0;
					cy += font->GetLineHeight();
					size.y = Max(size.y, cy + font->GetLineHeight());
				}			
			}

			size.x += GetTextPadding().x + GetTextPadding().z + 1;
			size.y += GetTextPadding().y + GetTextPadding().w;
			SetAutoScrollMinSize(size);
		}
	}

	void TextArea::OnSizeChanged( ResizeEventArgs & e )
	{
		Super::OnSizeChanged(e);
		DeleteVirtualEnter();
		AddVirtualEnter();
		//UpdateText();
	}

	void TextArea::AddText(Core::String & string)
	{
		F32 totalLength,spareLength;

		CRefStr & addstr = string.RefStr(0);
		CRefStr & str = m_Text.RefStr(m_MaxLength);

		totalLength = string.Length() + str.calclen();
		spareLength = m_MaxLength - totalLength - 1;

		if(spareLength > 0)
		{
			str.insert(str.calclen(),addstr,string.Length());
		}
		else
		{
			bool hasSpare = false;
			DeleteVirtualEnter();
			while(!hasSpare)
			{
				S32 pos = str.find('\n');
				str.remove(0,pos+1);

				if(m_MaxLength - str.calclen() > string.Length())
					hasSpare = true;
			}

			str.insert(str.calclen(),addstr,string.Length());
			AddVirtualEnter();
		}
		OnTextChanged(EventArgs());
	}

	void TextArea::ScrollToEnd()
	{
		SetCursorPosition(-1);
	}
}

//--------------------------------------------------------------------------------------
// Register
//--------------------------------------------------------------------------------------
DEFINE_PDE_TYPE_CLASS(Gui::TextAreaSkin)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::ScrollableControlSkin);
		ADD_PDE_DEFAULT_CONSTRUCTOR();
	}
};

DEFINE_PDE_TYPE_CLASS(Gui::TextArea)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::ScrollableControl);

		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_PROPERTY_RW(MaxLength);
		ADD_PDE_PROPERTY_RW(Count_n);
		ADD_PDE_PROPERTY_RW(Readonly);
		ADD_PDE_PROPERTY_RW(TextPadding);
		ADD_PDE_PROPERTY_RW(Fold);
		ADD_PDE_PROPERTY_RW(SelectionColor);
		ADD_PDE_PROPERTY_RW(SelectionBgColor);
		ADD_PDE_PROPERTY_RW(AllowEnter);
		ADD_PDE_METHOD(AddText);
		ADD_PDE_METHOD(ScrollToEnd);

		ADD_PDE_EVENT(EventTextChanged);
		ADD_PDE_EVENT(EventLengthExceed);
	}
};

REGISTER_PDE_TYPE(Gui::TextAreaSkin);
REGISTER_PDE_TYPE(Gui::TextArea);