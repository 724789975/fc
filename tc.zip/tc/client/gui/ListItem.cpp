#include "pch.h"

using namespace Core;
using namespace Client;
using namespace Gui;

DEFINE_PDE_TYPE_CLASS(Gui::ListItemSkin)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::ControlSkin);
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_PROPERTY_RW(BackgroundImageOp);
		ADD_PDE_PROPERTY_RW(HoverImage);
		ADD_PDE_PROPERTY_RW(SelectedImage);
		ADD_PDE_PROPERTY_RW(DisabledImage);
		ADD_PDE_PROPERTY_RW(FrameImage);
		ADD_PDE_PROPERTY_RW(CheckOnIcon);
		ADD_PDE_PROPERTY_RW(CheckOffIcon);
		ADD_PDE_PROPERTY_RW(SelfImage);
	}
};

DEFINE_PDE_TYPE_CLASS(Gui::ListItem)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_PROPERTY_RW(Check);
		ADD_PDE_PROPERTY_RW(UserData);
		ADD_PDE_PROPERTY_RW(BGSkin);
		ADD_PDE_PROPERTY_R (Selected);
		ADD_PDE_PROPERTY_RW(CanSelect);
		ADD_PDE_PROPERTY_RW(ColCantSelect);
		ADD_PDE_PROPERTY_RW(Expanded);
		ADD_PDE_PROPERTY_RW(CanExpand);
		ADD_PDE_PROPERTY_RW(Level);
		ADD_PDE_PROPERTY_RW(ColumnCount);
		ADD_PDE_PROPERTY_RW(Tag);
		ADD_PDE_PROPERTY_R (Owner);
		ADD_PDE_PROPERTY_RW(Parent);
		ADD_PDE_PROPERTY_R (FirstChild);
		ADD_PDE_PROPERTY_R (LastChild);
		ADD_PDE_PROPERTY_R (Next);
		ADD_PDE_PROPERTY_R (Prev);
		ADD_PDE_PROPERTY_RW(ToolTipText);
		ADD_PDE_PROPERTY_RW(ID);
		ADD_PDE_PROPERTY_RW(VIP);
		ADD_PDE_PROPERTY_RW(NAME);
		ADD_PDE_PROPERTY_RW(SpecialA);
		ADD_PDE_PROPERTY_RW(WithFrame);
		ADD_PDE_PROPERTY_RW(IsSelfItem);
		ADD_PDE_PROPERTY_RW(CustomBg);
		ADD_PDE_PROPERTY_RW(LV_BackgroundImage);
		ADD_PDE_PROPERTY_RW(Invite_BackgroundImage);
		ADD_PDE_PROPERTY_RW(CustomTextColor);
		ADD_PDE_PROPERTY_RW(UseCustomTextColor);
		ADD_PDE_PROPERTY_RW(CheckBoxSize);
		ADD_PDE_PROPERTY_RW(CheckBoxLocation);
		ADD_PDE_PROPERTY_RW(LV_localtion);
		ADD_PDE_PROPERTY_RW(LV_Size);
		ADD_PDE_PROPERTY_RW(Invite_localtion);
		ADD_PDE_PROPERTY_RW(Invite_Size);
		ADD_PDE_PROPERTY_RW(CheckVisible);
		ADD_PDE_PROPERTY_RW(NeedProjection);
		
		ADD_PDE_PROPERTY_RW(FontSize);
		ADD_PDE_PROPERTY_RW(TextColor);
		ADD_PDE_PROPERTY_RW(HighlightTextColor);
		ADD_PDE_PROPERTY_RW(SecLineHighlightTextColor);
		ADD_PDE_PROPERTY_RW(SecLineColor);
		ADD_PDE_PROPERTY_RW(SecLineText);
		ADD_PDE_PROPERTY_RW(Deviate_x);
		ADD_PDE_PROPERTY_RW(Deviate_y);
		ADD_PDE_PROPERTY_RW(SecLineFontSize);
		ADD_PDE_PROPERTY_RW(SecLineTextColunm);
		

		ADD_PDE_METHOD(GetText);
		ADD_PDE_METHOD(GetText_Show);
		ADD_PDE_METHOD(GetIcon);
		ADD_PDE_METHOD(GetSubItemColor);
		ADD_PDE_METHOD(GetIcon2);
		ADD_PDE_METHOD(GetHoverIcon);
		ADD_PDE_METHOD(SetText);
		ADD_PDE_METHOD(SetText_Show);
		ADD_PDE_METHOD(SetIcon);
		ADD_PDE_METHOD(SetHoverIcon);
		ADD_PDE_METHOD(AddSubItem);
		ADD_PDE_METHOD(SetSubItemColor);
		ADD_PDE_METHOD(GetNextNode);
		ADD_PDE_METHOD(GetPrevNode);
		ADD_PDE_METHOD(FindChildItem);
		ADD_PDE_METHOD(IsChildOf);
		ADD_PDE_METHOD(FindChildByTag);
		ADD_PDE_METHOD(InsertBefore);
		ADD_PDE_METHOD(InsertAfter);
	}
};

DEFINE_PDE_TYPE_CLASS(Gui::ListItemRoot)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(ListItem);
	}
};

REGISTER_PDE_TYPE(Gui::ListItemSkin);
REGISTER_PDE_TYPE(Gui::ListItem);
REGISTER_PDE_TYPE(Gui::ListItemRoot);


namespace Gui
{
	/// constructor.
	ListItem::ListItem()
		: m_Check(false)
		, m_UserData(-1)
		, m_Selected(false)
		, m_CanSelect(true)
		, m_Expanded(false)
		, m_CanExpand(false)
		, m_ColCantSelect(false)
		, m_Visible(true)
		, m_SpecialA(false)
		, m_WithFrame(false)
		, m_IsSelfItem(false)
		, m_Level(0)
		, m_FontSize(0)
		, m_TextColor(ARGB(0,0,0,0))
		, m_ColumnCount(1)
		, m_FirstChild(NULL)
		, m_LastChild(NULL)
		, m_Next(NULL)
		, m_Prev(NULL)
		, m_Parent(NULL)
		, m_CheckVisible(true)
		, m_NeedProjection(true)
		, m_CheckBoxLocation(Vector2(0,0))
		, m_LV_localtion(Vector2(0,0))
		, m_LV_Size(Vector2(0,0))
		, m_Invite_localtion(Vector2(0,0))
		, m_Invite_Size(Vector2(0,0))
		, m_CheckBoxSize(Vector2::kZero)
		, m_CustomTextColor(255,255,255,255)
		, m_HighlightTextColor(255,0,0,0)
		, m_SecLineHighlightTextColor(255,0,0,0)
		, m_UseCustomTextColor(false)
		, m_BGSkin(NullPtr)
		, m_SecLineColor(ARGB(0,0,0,0))
		, m_Deviate_x(0)
		, m_Deviate_y(0)
		, m_SecLineFontSize(0)
		, m_SecLineTextColunm(-1)
		, m_LV_BackgroundImage(NullPtr)
		,m_Invite_BackgroundImage(NullPtr)
	{
	}

	/// destructor
	ListItem::~ListItem()
	{
	}
}
//--------------------------------------------------------------------------------------
// Attribute
//--------------------------------------------------------------------------------------
namespace Gui
{
	PDE_ATTRIBUTE_GETTER(ListItem, Check, bool)
	{
		return m_Check;
	}

	PDE_ATTRIBUTE_SETTER(ListItem, Check, bool)
	{
		if (value != m_Check)
		{
			m_Check = value;
		}
	}
	
	PDE_ATTRIBUTE_GETTER(ListItem, CheckVisible, bool)
	{
		return m_CheckVisible;
	}

	PDE_ATTRIBUTE_SETTER(ListItem, CheckVisible, bool)
	{
		if (value != m_CheckVisible)
		{
			m_CheckVisible = value;
		}
	}

	PDE_ATTRIBUTE_GETTER(ListItem, NeedProjection, bool)
	{
		return m_NeedProjection;
	}

	PDE_ATTRIBUTE_SETTER(ListItem, NeedProjection, bool)
	{
		if (value != m_NeedProjection)
		{
			m_NeedProjection = value;
		}
	}
	

	PDE_ATTRIBUTE_GETTER(ListItem, FontSize, F32)
	{
		return m_FontSize;
	}

	PDE_ATTRIBUTE_SETTER(ListItem, FontSize, F32)
	{
		if (value != m_FontSize)
		{
			m_FontSize = value;
		}
	}

	PDE_ATTRIBUTE_GETTER(ListItem, Deviate_x, F32)
	{
		return m_Deviate_x;
	}

	PDE_ATTRIBUTE_SETTER(ListItem, Deviate_x, F32)
	{
		if (value != m_Deviate_x)
		{
			m_Deviate_x = value;
		}
	}

	PDE_ATTRIBUTE_GETTER(ListItem, Deviate_y, F32)
	{
		return m_Deviate_y;
	}

	PDE_ATTRIBUTE_SETTER(ListItem, Deviate_y, F32)
	{
		if (value != m_Deviate_y)
		{
			m_Deviate_y = value;
		}
	}

	PDE_ATTRIBUTE_GETTER(ListItem, TextColor, Core::ARGB)
	{
		return m_TextColor;
	}

	PDE_ATTRIBUTE_SETTER(ListItem, TextColor, Core::ARGB)
	{
		if (value != m_TextColor)
		{
			m_TextColor = value;
		}
	}

	PDE_ATTRIBUTE_GETTER(ListItem, HighlightTextColor, Core::ARGB)
	{
		return m_HighlightTextColor;
	}

	PDE_ATTRIBUTE_SETTER(ListItem, HighlightTextColor, Core::ARGB)
	{
		if (value != m_HighlightTextColor)
		{
			m_HighlightTextColor = value;
		}
	}

	PDE_ATTRIBUTE_GETTER(ListItem, SecLineHighlightTextColor, Core::ARGB)
	{
		return m_SecLineHighlightTextColor;
	}

	PDE_ATTRIBUTE_SETTER(ListItem, SecLineHighlightTextColor, Core::ARGB)
	{
		if (value != m_SecLineHighlightTextColor)
		{
			m_SecLineHighlightTextColor = value;
		}
	}

	PDE_ATTRIBUTE_GETTER(ListItem, BGSkin, tempc_ptr(ListItemSkin))
	{
		return m_BGSkin;
	}

	PDE_ATTRIBUTE_SETTER(ListItem, BGSkin, tempc_ptr(ListItemSkin))
	{
		if (value != m_BGSkin)
		{
			m_BGSkin = value;
		}
	}
	
	PDE_ATTRIBUTE_GETTER(ListItem, ColCantSelect, bool)
	{
		return m_ColCantSelect;
	}

	PDE_ATTRIBUTE_SETTER(ListItem, ColCantSelect, bool)
	{
		if (value != m_ColCantSelect)
		{
			m_ColCantSelect = value;
		}
	}

	PDE_ATTRIBUTE_GETTER(ListItem, Selected, bool)
	{
		return m_Selected;
	}

	PDE_ATTRIBUTE_SETTER(ListItem, Selected, bool)
	{
		if (m_Selected != value)
		{
			if (value && !GetCanSelect())
				return;

			tempc_ptr(Control) hOwner = GetOwner();

			ListTreeView * owner = ptr_static_cast<ListTreeView>(hOwner);

			if (owner)
				owner->BeforeSelect(ptr_static_cast<ListItem>(this));

			m_Selected = value;

			if (owner)
				owner->AfterSelect(ptr_static_cast<ListItem>(this));
		}
	}

	PDE_ATTRIBUTE_GETTER(ListItem, CanSelect, bool)
	{
		return m_CanSelect;
	}

	PDE_ATTRIBUTE_SETTER(ListItem, CanSelect, bool)
	{
		if (m_CanSelect != value)
		{
			m_CanSelect = value;
		}
	}

	PDE_ATTRIBUTE_GETTER(ListItem, Expanded, bool)
	{
		return m_Expanded;
	}

	PDE_ATTRIBUTE_SETTER(ListItem, Expanded, bool)
	{
		if (m_Expanded != value)
		{
			tempc_ptr(Control) hOwner = GetOwner();

			ListTreeView * owner = ptr_static_cast<ListTreeView>(hOwner);

			if (value && !(owner? owner->CanExpand(ptr_static_cast<ListItem>(this)): GetCanExpand()))
				return;

			if (owner)
				owner->BeforeExpand(ptr_static_cast<ListItem>(this));

			m_Expanded = value; 

			if (owner)
				owner->AfterExpand(ptr_static_cast<ListItem>(this));
		}
	}

	PDE_ATTRIBUTE_GETTER(ListItem, CanExpand, bool)
	{
		return m_CanExpand;
	}

	PDE_ATTRIBUTE_SETTER(ListItem, CanExpand, bool)
	{
		if (m_CanExpand != value)
		{
			m_CanExpand = value;

			tempc_ptr(Control) hOwner = GetOwner();

			if(hOwner)
			{
				hOwner->Invalid();
			}
		}
	}

	PDE_ATTRIBUTE_GETTER(ListItem, Visible, bool)
	{
		return m_Visible;
	}

	PDE_ATTRIBUTE_SETTER(ListItem, Visible, bool)
	{
		if (m_Visible != value)
		{
			m_Visible = value;

			tempc_ptr(Control) hOwner = GetOwner();

			if(hOwner)
			{
				hOwner->Invalid();
			}
		}
	}

	PDE_ATTRIBUTE_GETTER(ListItem, Level, S32)
	{
		return m_Level;
	}

	PDE_ATTRIBUTE_SETTER(ListItem, Level, S32)
	{
		if (m_Level != value)
		{
			m_Level = value;

			for (tempc_ptr(ListItem) item = GetFirstChild(); item; item = item->GetNext())
			{
				item->SetLevel(value + 1);
			}

			tempc_ptr(Control) owner = GetOwner();

			if(owner)
			{
				owner->Invalid();
			}
		}
	}

	PDE_ATTRIBUTE_GETTER(ListItem, ColumnCount, U32)
	{
		return m_ColumnCount;
	}

	PDE_ATTRIBUTE_SETTER(ListItem, ColumnCount, U32)
	{
		if (m_ColumnCount != value)
		{
			m_ColumnCount = value;
		}
	}

	PDE_ATTRIBUTE_GETTER(ListItem, Tag, tempc_ptr(void))
	{
		return m_Tag;
	}

	PDE_ATTRIBUTE_SETTER(ListItem, Tag, tempc_ptr(void))
	{
		if (m_Tag != value)
		{
			m_Tag = value;
		}
	}

	PDE_ATTRIBUTE_GETTER(ListItem, Owner, tempc_ptr(Control))
	{
		sharedc_ptr(ListItem) parent = GetParent();
		return parent ? parent->GetOwner(): NullPtr;
	}

	PDE_ATTRIBUTE_GETTER(ListItem, Parent, tempc_ptr(ListItem))
	{
		return ptr_static_cast<ListItem>(m_Parent);
	}

	PDE_ATTRIBUTE_SETTER(ListItem, Parent, tempc_ptr(ListItem))
	{
		ChangeParent(value, NullPtr, true);
	}

	PDE_ATTRIBUTE_GETTER(ListItem, FirstChild, tempc_ptr(ListItem))
	{
		return ptr_static_cast<ListItem>(m_FirstChild);
	}

	PDE_ATTRIBUTE_GETTER(ListItem, LastChild, tempc_ptr(ListItem))
	{
		return ptr_static_cast<ListItem>(m_LastChild);
	}

	PDE_ATTRIBUTE_GETTER(ListItem, Next, tempc_ptr(ListItem))
	{
		return ptr_static_cast<ListItem>(m_Next);
	}

	PDE_ATTRIBUTE_GETTER(ListItem, Prev, tempc_ptr(ListItem))
	{
		return ptr_static_cast<ListItem>(m_Prev);
	}

	PDE_ATTRIBUTE_GETTER(ListItem, ToolTipText, const Core::String &)
	{
		return m_ToolTipText;
	}

	PDE_ATTRIBUTE_SETTER(ListItem, ToolTipText, const Core::String &)
	{
		if (m_ToolTipText != value)
			m_ToolTipText = value;
	}	

	PDE_ATTRIBUTE_GETTER(ListItem, ID, U32)
	{
		return m_ID;
	}

	PDE_ATTRIBUTE_SETTER(ListItem, ID, U32)
	{
		if (m_ID != value)
			m_ID = value;
	}

	PDE_ATTRIBUTE_GETTER(ListItem, VIP, U32)
	{
		return m_VIP;
	}

	PDE_ATTRIBUTE_SETTER(ListItem, VIP, U32)
	{
		if (m_VIP != value)
			m_VIP = value;
	}

	PDE_ATTRIBUTE_GETTER(ListItem, NAME, Core::String &)
	{
		return m_NAME;
	}

	PDE_ATTRIBUTE_SETTER(ListItem, NAME, Core::String &)
	{
		if (m_NAME != value)
			m_NAME = value;
	}

	PDE_ATTRIBUTE_GETTER(ListItem, CheckBoxSize, Core::Vector2)
	{
		return m_CheckBoxSize;
	}

	PDE_ATTRIBUTE_SETTER(ListItem, CheckBoxSize, Core::Vector2)
	{
		if (m_CheckBoxSize != value)
			m_CheckBoxSize = value;
	}
	
	PDE_ATTRIBUTE_GETTER(ListItem, CheckBoxLocation, Core::Vector2)
	{
		return m_CheckBoxLocation;
	}

	PDE_ATTRIBUTE_SETTER(ListItem, CheckBoxLocation, Core::Vector2)
	{
		if (m_CheckBoxLocation != value)
			m_CheckBoxLocation = value;
	}
	
	PDE_ATTRIBUTE_GETTER(ListItem, LV_localtion, Core::Vector2)
	{
		return m_LV_localtion;
	}

	PDE_ATTRIBUTE_SETTER(ListItem, LV_localtion, Core::Vector2)
	{
		if (m_LV_localtion != value)
			m_LV_localtion = value;
	}
	
	PDE_ATTRIBUTE_GETTER(ListItem, LV_Size, Core::Vector2)
	{
		return m_LV_Size;
	}

	PDE_ATTRIBUTE_SETTER(ListItem, LV_Size, Core::Vector2)
	{
		if (m_LV_Size != value)
			m_LV_Size = value;
	}

	PDE_ATTRIBUTE_GETTER(ListItem, Invite_localtion, Core::Vector2)
	{
		return m_Invite_localtion;
	}

	PDE_ATTRIBUTE_SETTER(ListItem, Invite_localtion, Core::Vector2)
	{
		if (m_Invite_localtion != value)
			m_Invite_localtion = value;
	}

	PDE_ATTRIBUTE_GETTER(ListItem, Invite_Size, Core::Vector2)
	{
		return m_Invite_Size;
	}

	PDE_ATTRIBUTE_SETTER(ListItem, Invite_Size, Core::Vector2)
	{
		if (m_Invite_Size != value)
			m_Invite_Size = value;
	}
	PDE_ATTRIBUTE_GETTER(ListItem, SecLineColor, Core::ARGB)
	{
		return m_SecLineColor;
	}

	PDE_ATTRIBUTE_SETTER(ListItem, SecLineColor, Core::ARGB)
	{
		if (value != m_SecLineColor)
		{
			m_SecLineColor = value;
		}
	}

	PDE_ATTRIBUTE_GETTER(ListItem, SecLineFontSize, F32)
	{
		return m_SecLineFontSize;
	}

	PDE_ATTRIBUTE_SETTER(ListItem, SecLineFontSize, F32)
	{
		if (value != m_SecLineFontSize)
		{
			m_SecLineFontSize = value;
		}
	}

	PDE_ATTRIBUTE_GETTER(ListItem, SecLineText, const Core::String &)
	{
		return m_SecLineText;
	}

	PDE_ATTRIBUTE_SETTER(ListItem, SecLineText, const Core::String &)
	{
		if (value != m_SecLineText)
		{
			m_SecLineText = value;
		}
	}
	
	PDE_ATTRIBUTE_GETTER(ListItem, SecLineTextColunm, F32)
	{
		return m_SecLineTextColunm;
	}

	PDE_ATTRIBUTE_SETTER(ListItem, SecLineTextColunm, F32)
	{
		if (value != m_SecLineTextColunm)
		{
			m_SecLineTextColunm = value;
		}
	}

	PDE_ATTRIBUTE_GETTER(ListItem, UserData, int)
	{
		return m_UserData;
	}

	PDE_ATTRIBUTE_SETTER(ListItem, UserData, int)
	{
		if (value != m_UserData)
		{
			m_UserData = value;
		}
	}
}


//--------------------------------------------------------------------------------------
// Event
//--------------------------------------------------------------------------------------
namespace Gui
{
	void ListItem::OnCreate()
	{
		Super::OnCreate();

		m_Items.Reserve(m_ColumnCount);
	}

	void ListItem::OnDestroy()
	{
		// clear childs
		while (m_FirstChild)
			m_FirstChild->ChangeParent(NullPtr, NullPtr, true);

		Super::OnDestroy();
	}

	/// on child changed
	void ListItem::OnItemsChanged(EventArgs & e)
	{	
		sharedc_ptr(Control) hOwner = ptr_static_cast<Control>(GetOwner());

		if(hOwner)
		{
			hOwner->DirtyLayout();
		}
	}

	/// on draw background
	void ListItem::OnDrawBackground(DrawItemEventArgs & e)
	{
		tempc_ptr(ListItemSkin) skin = e.ItemSkin;

		if(m_BGSkin)
			skin = m_BGSkin;

		if (!e.Handled)
		{
			if(skin)
			{

				Skin::DrawImage(e.render,skin->GetBackgroundImage(), e.Rect);
	
			}
			else
			{
				if(m_CustomBg)
				{
					Skin::DrawImage(e.render, m_CustomBg, e.Rect);
				}
				else
				{
					Skin::DrawImage(e.render, e.Row%2?skin->GetBackgroundImageOp():skin->GetBackgroundImage(), e.Rect);
				}
			}
		}
	}

	void ListItem::OnDrawLV_Background(DrawItemEventArgs & e)
	{
		if (m_LV_BackgroundImage)
		{
			if ((m_SpecialA || !GetCanSelect()) && !m_ColCantSelect)
			{
				Skin::DrawImage(e.render,m_LV_BackgroundImage , Core::Rectangle(e.Rect.Min + m_LV_localtion,e.Rect.Min + m_LV_localtion + m_LV_Size),ARGB(255/3,255,255,255));
			}
			else
			{
				Skin::DrawImage(e.render,m_LV_BackgroundImage , Core::Rectangle(e.Rect.Min + m_LV_localtion,e.Rect.Min + m_LV_localtion + m_LV_Size));
			}
			
		}
	}

	void ListItem::OnDrawInvite_Background(DrawItemEventArgs & e)
	{
		if (m_Invite_BackgroundImage)
		{
			if ((m_SpecialA || !GetCanSelect()) && !m_ColCantSelect)
			{
				Skin::DrawImage(e.render,m_Invite_BackgroundImage , Core::Rectangle(e.Rect.Min + m_Invite_localtion,e.Rect.Min + m_Invite_localtion + m_Invite_Size),ARGB(255/3,255,255,255));
			}
			else
			{
				Skin::DrawImage(e.render,m_Invite_BackgroundImage , Core::Rectangle(e.Rect.Min + m_Invite_localtion,e.Rect.Min + m_Invite_localtion + m_Invite_Size));
			}

		}
	}
	
	
	/// on draw item
	void ListItem::OnDrawColumn(DrawItemEventArgs & e,float FontSize,Core::ARGB FontColor)
	{
		if (!e.Handled)
		{
			tempc_ptr(ListTreeView) owner = ptr_static_cast<ListTreeView>(GetOwner());

			if (owner)
			{
				Core::Rectangle Line2Rect(e.Rect.Min,e.Rect.Max);
				Core::Rectangle Icon2Rect(e.Rect.Min,e.Rect.Max);
				bool UseSecLine = false;

				ARGB iconColor = ARGB(255, 255, 255, 255);
				ARGB textColor;
				ARGB SectextColor = GetSecLineColor(); 


				if(e.ItemSkin)
					textColor = e.Selected && GetCanSelect() ? ARGB(0,0,0) : (m_UseCustomTextColor?m_CustomTextColor : e.ItemSkin->GetTextColor());
				else
					textColor = e.Selected && GetCanSelect() ? ARGB(0,0,0) : ARGB(0, 0, 0);

				F32  OldTextSize = owner->GetFontSize();
				F32  OldTextCol  = owner->GetTextColor();

				ARGB iconColorOld = iconColor;
				ARGB textColorOld = textColor;

				if(m_SpecialA || !GetCanSelect())
				{
					iconColor.a/=3;
					textColor.a/=3;
				}

				if(m_ColCantSelect)
				{
					iconColor = iconColorOld;
					textColor = textColorOld;
				}

				if(FontSize != 0)
				{
					owner->SetFontSize(FontSize);
					textColor = FontColor;
				}

				if(m_FontSize != 0)
				{
					owner->SetFontSize(m_FontSize);
					textColor = m_TextColor;
				}
				
				if (e.Column == owner->GetCheckIndex()&&m_CheckVisible)
				{
					Core::Rectangle checkRect;

					tempc_ptr(ListItemSkin) skin = e.ItemSkin;

					tempc_ptr(ListTreeView) tree = ptr_dynamic_cast<ListTreeView>(GetOwner());		
					if(tree)
					{
						if(m_CheckBoxSize!=Vector2::kZero && m_CheckBoxLocation!=Vector2::kZero)
						{
							checkRect = Core::Rectangle::LeftTop(m_CheckBoxLocation,m_CheckBoxSize);
							e.Rect.Min.x = e.Rect.Min.x + 35;
						}
						else
						{
							checkRect = Core::Rectangle::LeftTop(e.Rect.Min,Vector2(tree->GetItemHeight(),tree->GetItemHeight()));
							e.Rect.Min.x = e.Rect.Min.x + tree->GetItemHeight();
						}
						checkRect.Shrink(5);
						if(skin)
						{
							Skin::DrawImage(e.render, m_Check?skin->GetCheckOnIcon():skin->GetCheckOffIcon(), checkRect);
						}
						else
						{
							e.render->DrawRectangle(checkRect,checkRect,m_Check?ARGB(128,0,255,0):ARGB(128,128,0,0));
						}
					}
					else
					{
						LogSystem.WriteLinef("list item parent not found!!");
					}
				}

				if(GetSecLineText().Length() != 0 && e.Column == GetSecLineTextColunm() )
				{				
					F32 ItemHeight = e.Rect.Max.y - e.Rect.Min.y;
					e.Rect.Shrink(0, 0, 0, ItemHeight/2);
					Line2Rect.Shrink(0, ItemHeight/2, 0, 0);
					UseSecLine = true;
				}

				if((e.Item == owner->GetPointedItem()||(owner->GetSelectedItem() == ptr_static_cast<ListItem>(this)))&&GetCanSelect())
				{				
					textColor = m_HighlightTextColor;
					SectextColor = m_SecLineHighlightTextColor;
				}
				if ( (owner->GetSelectedItem() == ptr_static_cast<ListItem>(this) || owner->GetPointedItem() == ptr_static_cast<ListItem>(this)) && GetHoverIcon(e.Column))
				{
					Skin::DrawIconText(e.render, GetHoverIcon(e.Column), owner->GetFont(), GetText_Show(e.Column) != "" ?  GetText_Show(e.Column) : GetText(e.Column), e.Rect, e.Align, iconColor, textColor, e.ControlEnable, e.ControlEnable,4, m_Deviate_x, m_Deviate_y);
				}
				else
				{
					Core::ARGB old;
					bool newcolor = GetSubItemColor(e.Column) != Core::ARGB(255,255,255,255);
					if (newcolor)
					{
						old = textColor;
						textColor = GetSubItemColor(e.Column);
					}
					/* ���ֵ�ͶӰ*/
					if ( m_NeedProjection && !(owner->GetSelectedItem() == ptr_static_cast<ListItem>(this) || owner->GetPointedItem() == ptr_static_cast<ListItem>(this)) && /* ���ֻ�ͼƬ���ǻ��� */ *(GetText(e.Column)) != 0)
						Skin::DrawIconText(e.render, GetIcon(e.Column), owner->GetFont(), GetText_Show(e.Column) != "" ?  GetText_Show(e.Column) : GetText(e.Column), e.Rect + Vector2(1, 1), e.Align, iconColor, ARGB(230, 0, 0, 0), e.ControlEnable, e.ControlEnable,4, m_Deviate_x, m_Deviate_y);
					
					
					Skin::DrawIconText(e.render, GetIcon(e.Column), owner->GetFont(), GetText_Show(e.Column) != "" ?  GetText_Show(e.Column) : GetText(e.Column), e.Rect, e.Align, iconColor, textColor, e.ControlEnable, e.ControlEnable,4, m_Deviate_x, m_Deviate_y);
					
					if (newcolor)
					{
						textColor = old;
					}
				}
				
				if(UseSecLine && e.Column == GetSecLineTextColunm())
				{
					if(GetSecLineColor() == Core::ARGB(0 , 0, 0, 0))
						SetSecLineColor(SectextColor);

					if(GetSecLineFontSize() == 0)
						SetSecLineFontSize(owner->GetFontSize());

					owner->SetFontSize(GetSecLineFontSize());
					Skin::DrawIconText(e.render, NullPtr, owner->GetFont(), GetSecLineText(), Line2Rect, e.Align, iconColor, SectextColor, e.ControlEnable, e.ControlEnable,4, m_Deviate_x, m_Deviate_y);
				}

				if(GetIcon2(e.Column))
				{
					Core::Rectangle Rect2(Icon2Rect);
					float Height = Rect2.Max.y-Rect2.Min.y;
					sharedc_ptr(Gui::Icon) icon2 = GetIcon2(e.Column);
					
					Height = Height*(icon2->Getuv().w-icon2->Getuv().y);
					Rect2.Min.y = Rect2.Max.y - Height;

					Skin::DrawIconText(e.render,icon2, owner->GetFont(), GetText(e.Column),Rect2, e.Align, iconColor, textColor, e.ControlEnable, e.ControlEnable, 4,m_Deviate_x, m_Deviate_y);
				}
				
				owner->SetFontSize(OldTextSize);
			}
		}
	}
}


//--------------------------------------------------------------------------------------
// Method
//--------------------------------------------------------------------------------------
namespace Gui
{
	sharedc_ptr(ListItem) ListItem::CreateItem()
	{
		sharedc_ptr(ListItem) hItem = ptr_new ListItem;

		if (hItem)
			hItem->SetParent(ptr_static_cast<ListItem>(this));

		return hItem;
	}

	void ListItem::AddSubItem(const Core::String & text)
	{
		SubItem subItem;
		subItem.Text = text;
		subItem.Text_Show = "";
		subItem.Color = ARGB::ARGB(255,255,255,255);
		m_Items.PushBack(subItem);
	}

	const Core::String & ListItem::GetText(U32 columnId)
	{
		if (columnId < m_Items.Size())
			return m_Items[columnId].Text;

		return Core::String::kEmpty;
	}

	void ListItem::SetText(U32 columnId, const Core::String & value)
	{
		if (columnId >= m_ColumnCount)
			return;

		if (columnId >= m_Items.Size())
			m_Items.Resize(columnId+1);

		if (m_Items[columnId].Text != value)
		{
			m_Items[columnId].Text = value;
			m_Items[columnId].Color = ARGB::ARGB(255,255,255,255);
			tempc_ptr(Control) hOwner = GetOwner();

			if (hOwner)
			{
				hOwner->DirtyLayout();
			}
		}
	}
	
	const Core::String & ListItem::GetText_Show(U32 columnId)
	{
		if (columnId < m_Items.Size())
			return m_Items[columnId].Text_Show;

		return Core::String::kEmpty;
	}
	void ListItem::SetText_Show(U32 columnId, const Core::String & value)
	{
		if (columnId >= m_ColumnCount)
			return;

		if (columnId >= m_Items.Size())
			m_Items.Resize(columnId+1);

		if (m_Items[columnId].Text_Show != value)
		{
			m_Items[columnId].Text_Show = value;
			m_Items[columnId].Color = ARGB::ARGB(255,255,255,255);
			tempc_ptr(Control) hOwner = GetOwner();

			if (hOwner)
			{
				hOwner->DirtyLayout();
			}
		}
	}

	void ListItem::SetSubItemColor(U32 columnId, const Core::ARGB & value)
	{
		if (columnId >= m_ColumnCount)
			return;

		if (m_Items[columnId].Color != value)
		{
			m_Items[columnId].Color = value;
		}
	}

	tempc_ptr(Gui::Icon) ListItem::GetIcon(U32 columnId)
	{
		if (columnId < m_Items.Size())
			return m_Items[columnId].Icon;

		return NullPtr;
	}

	const Core::ARGB ListItem::GetSubItemColor(U32 columnId)
	{
		if (columnId < m_Items.Size())
			return m_Items[columnId].Color;

		return ARGB(255,255,255,255);
	}

	tempc_ptr(Gui::Icon) ListItem::GetIcon2(U32 columnId)
	{
		if (columnId < m_Items.Size())
			return m_Items[columnId].Icon2;

		return NullPtr;
	}

	tempc_ptr(Gui::Icon) ListItem::GetHoverIcon(U32 columnId)
	{
		if (columnId < m_Items.Size())
		{
			return m_Items[columnId].HoverIcon;
		}
		return NullPtr;
	}

	void ListItem::SetIcon(U32 columnId, by_ptr(Gui::Icon) icon,by_ptr(Gui::Icon) icon2)
	{
		if (columnId >= m_ColumnCount)
			return;

		if (columnId >= m_Items.Size())
			m_Items.Resize(columnId+1);
		
		m_Items[columnId].Icon = icon;
		
		//if(!icon)
		//	m_Items[columnId].Icon2 = icon;

		//if(icon2)
			m_Items[columnId].Icon2 = icon2;

		sharedc_ptr(Control) hOwner = GetOwner();

		if (hOwner)
		{
			hOwner->DirtyLayout();
		}
	}

	void ListItem::SetHoverIcon(U32 columnId, by_ptr(Gui::Icon) hoverIcon)
	{
		if (columnId > m_ColumnCount)
			return;

		if (columnId >= m_Items.Size())
			m_Items.Resize(columnId + 1);

		m_Items[columnId].HoverIcon = hoverIcon;

		sharedc_ptr(Control) hOwner = GetOwner();

		if (hOwner)
		{
			hOwner->DirtyLayout();
		}
	}

	sharedc_ptr(ListItem) ListItem::GetNextNode(bool bSkipChilds)
	{
		if (!bSkipChilds && m_FirstChild)
			return ptr_static_cast<ListItem>(m_FirstChild);

		if (m_Next)
			return ptr_static_cast<ListItem>(m_Next);

		ListItem * result = m_Parent;
		while (result)
		{
			if (result->m_Next) return ptr_static_cast<ListItem>(result->m_Next);
			result = result->m_Parent;
		}

		return ptr_static_cast<ListItem>(result);
	}

	sharedc_ptr(ListItem) ListItem::GetPrevNode(bool bSkipChilds)
	{
		if (m_Prev)
		{
			if (!bSkipChilds)
			{
				ListItem* result = m_Prev;
				while (result)
				{
					if (!result->m_LastChild)
						return ptr_static_cast<ListItem>(result);

					result = result->m_LastChild;
				}
			}

			return ptr_static_cast<ListItem>(m_Prev);
		}

		return ptr_static_cast<ListItem>(m_Parent);
	}


	tempc_ptr(ListItem) ListItem::FindChildItem(U32 column, const Core::String & text)
	{
		tempc_ptr(ListItem) pNext = GetNextNode(true);
		for (tempc_ptr(ListItem) pNode = GetNextNode(false); pNode != pNext; pNode = pNode->GetNextNode())
			if (pNode->GetText(column) == text)
				return pNode;

		return NullPtr;
	}

	// find child item by tag
	tempc_ptr(ListItem) ListItem::FindChildByTag(tempc_ptr(void) tag)
	{
		if (tag)
		{
			tempc_ptr(ListItem) pNext = GetNextNode(true);
			for (tempc_ptr(ListItem) pNode = GetNextNode(false); pNode != pNext; pNode = pNode->GetNextNode())
				if (pNode->GetTag() == tag)
					return pNode;
		}

		return NullPtr;
	}

	bool ListItem::IsChildOf(tempc_ptr(ListItem) item)
	{
		if (item)
		{
			sharedc_ptr(ListItem) node = ptr_static_cast<ListItem>(GetPtrOwner());

			while (node && node != item)
				node = node->GetParent();

			return node && node == item;
		}

		return false;
	}

	/// change parent
	bool ListItem::ChangeParent(by_ptr(ListItem) parent, by_ptr(ListItem) node, bool before)
	{
		// check recursive
		for (tempc_ptr(ListItem) temp = parent; temp; temp = temp->GetParent())
		{
			if (temp == this)
			{
				return false;
			}
		}

		if (m_Parent != parent || (before ? m_Prev : m_Next) /*!= node*/)
		{
			// remove it first
			if (m_Parent)
			{
				m_Parent->m_FirstChild = m_Parent->m_FirstChild == this ? m_Next : m_Parent->m_FirstChild;
				m_Parent->m_LastChild = m_Parent->m_LastChild == this ? m_Prev : m_Parent->m_LastChild;

				if (this->m_Prev) this->m_Prev->m_Next = this->m_Next;
				if (this->m_Next) this->m_Next->m_Prev = this->m_Prev;

				this->m_Prev = NULL;
				this->m_Next = NULL;
			}
			else
			{
				ptr_static_cast<ListItem>(this).GetPtrData()->AddRef();
			}

			if (m_Parent)
				m_Parent->OnItemsChanged(EventArgs());

			m_Parent = parent;

			// insert
			if (m_Parent)
			{
				if (before)
				{
					if (node && node->m_Parent == m_Parent)
					{
						// link next
						if (node->m_Prev)
						{
							node->m_Prev->m_Next = this;
							this->m_Prev = node->m_Prev;
						}

						// link prev
						node->m_Prev = this;
						this->m_Next = node;

						//fix bug
						if (node->m_Next == this)
							node->m_Next = 0;

						// set last child
						m_Parent->m_FirstChild = this->m_Prev == NULL ? this : m_Parent->m_FirstChild;
					}
					else
					{
						// insert as last child
						this->m_Prev = m_Parent->m_LastChild;
						if (this->m_Prev) this->m_Prev->m_Next = this;

						m_Parent->m_LastChild = this;
						m_Parent->m_FirstChild = m_Parent->m_FirstChild == NULL ? this : m_Parent->m_FirstChild;
					}
				}
				else
				{
					if (node && node->m_Parent == m_Parent)
					{
						// link next
						if (node->m_Next)
						{
							node->m_Next->m_Prev = this;
							this->m_Next = node->m_Next;
						}

						// link prev
						node->m_Next = this;
						this->m_Prev = node;

						// set last child
						m_Parent->m_LastChild = this->m_Next == NULL ? this : m_Parent->m_LastChild;
					}
					else
					{
						// insert as fist child
						this->m_Next = m_Parent->m_FirstChild;
						if (this->m_Next) this->m_Next->m_Prev = this;

						m_Parent->m_FirstChild = this;
						m_Parent->m_LastChild = m_Parent->m_LastChild == NULL ? this : m_Parent->m_LastChild;
					}
				}

				// update level
				SetLevel(m_Parent->GetLevel() + 1);
				m_Parent->OnItemsChanged(EventArgs());
			}
			else
			{
				ptr_static_cast<ListItem>(this).GetPtrData()->Release();
			}
		}

		return false;
	}

	bool ListItem::InsertBefore(tempc_ptr(ListItem) item)
	{
		if(item)
		{
			return ChangeParent(item->GetParent(), item, true);
		}
		return false;
	}

	bool ListItem::InsertAfter(tempc_ptr(ListItem) item)
	{
		if(item)
		{
			return ChangeParent(item->GetParent(), item, false);
		}
		return false;
	}

	void ListItem::Invalid()
	{
		ListTreeView * owner = ptr_static_cast<ListTreeView>(GetOwner());

		if (owner)
		{
			owner->Invalid();
		}
	}
}


namespace Gui
{
	PDE_ATTRIBUTE_GETTER(ListItemRoot, Owner, tempc_ptr(Control))
	{
		return m_Owner;
	}

	PDE_ATTRIBUTE_SETTER(ListItemRoot, Owner, tempc_ptr(Control))
	{
		if (m_Owner != value)
		{
			m_Owner = value;
		}
	}
}
