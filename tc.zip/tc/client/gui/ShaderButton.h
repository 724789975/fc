namespace Gui
{	
	class ShaderButtonSkin : public ButtonSkin
	{
	public:
		INLINE_PDE_ATTRIBUTE_RW(ResImage1,	tempc_ptr(Image)); 
		INLINE_PDE_ATTRIBUTE_RW(ResImage2,	tempc_ptr(Image)); 
		INLINE_PDE_ATTRIBUTE_RW(ResImage3,	tempc_ptr(Image)); 
	private:
		sharedc_ptr(Image)	m_ResImage1;
		sharedc_ptr(Image)	m_ResImage2;
		sharedc_ptr(Image)	m_ResImage3;
	};

	class ShaderButton : public Button
	{
	public:
		DECLARE_PDE_OBJECT(ShaderButton, Control);

		ShaderButton();
		~ShaderButton();
		
		virtual void OnPaint(PaintEventArgs & e);

		DECLARE_PDE_ATTRIBUTE_RW(ShaderPS,	const Core::String &);
		DECLARE_PDE_ATTRIBUTE_RW(ShaderVS,	const Core::String &);
		DECLARE_PDE_ATTRIBUTE_RW(IsShowTime, bool);

	private:
		bool			m_IsShowTime;
		Core::String	m_ShaderVS;
		Core::String	m_ShaderPS;
	};
}

