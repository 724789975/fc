namespace Gui
{
	/// command interface
	struct Command : public Core::LinkBase<Command>
	{
		/// destructor
		Command() {}
		virtual ~Command() {}

		/// release
		virtual void Release() { delete this; }

		/// execute this command
		virtual void OnRedo(Command & e) = 0;

		/// unexecute this command
		virtual void OnUndo(Command & e) = 0;
	};

	class CommandQueue;

	/// script command
	class ScriptCommand : public Command
	{
	public:
		/// constructor
		ScriptCommand(tempc_ptr(CommandQueue) owner);


	public:
		DECLARE_PDE_EVENT(EventRedo,	ScriptCommand);
		DECLARE_PDE_EVENT(EventUndo,	ScriptCommand);
		DECLARE_PDE_EVENT(EventDestroy,	ScriptCommand);

	public:
		/// execute this command
		virtual void OnRedo(Command & e);

		/// unexecute this command
		virtual void OnUndo(Command & e);

		/// release
		virtual void Release();

	private:
		tempc_ptr(CommandQueue) m_Owner;
	};


	class CommandQueue : public Core::Object
	{
	public:
		CommandQueue();
		~CommandQueue();

	public:
		DECLARE_PDE_ATTRIBUTE_RW(UndoLimit,		U32);
		DECLARE_PDE_ATTRIBUTE_R (CanUndo,		bool);
		DECLARE_PDE_ATTRIBUTE_R (CanRedo,		bool);

	public:
		/// undo
		void Undo(int steps);

		/// redo
		void Redo(int steps);

		/// add new command
		void AddCommand(Command * command, bool addToRedo);

		/// new script command
		ScriptCommand * AddNewScriptCommand(bool addToRedo);

	private:
		Core::LinkList<Command> m_UndoList;
		Core::LinkList<Command> m_RedoList;
		U32 m_UndoLimit;
	};
}