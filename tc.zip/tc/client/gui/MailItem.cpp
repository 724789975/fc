#include "pch.h"

using namespace Core;
using namespace Client;
using namespace Gui;

DEFINE_PDE_TYPE_CLASS(Gui::MailItem)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::Control);
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_EVENT(EventSelectedChanged);

		ADD_PDE_PROPERTY_RW(Selected);
		ADD_PDE_PROPERTY_RW(Check);
		ADD_PDE_PROPERTY_RW(Unread);
		ADD_PDE_PROPERTY_RW(ID);
		ADD_PDE_PROPERTY_RW(Title);
		ADD_PDE_PROPERTY_RW(Content);
		ADD_PDE_PROPERTY_RW(Date);
		ADD_PDE_PROPERTY_RW(Icon);
	}
};
REGISTER_PDE_TYPE(Gui::MailItem);

DEFINE_PDE_TYPE_CLASS(Gui::MailItemSkin)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::ControlSkin);
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_PROPERTY_RW(CheckIcon);
		ADD_PDE_PROPERTY_RW(UncheckIcon);
		ADD_PDE_PROPERTY_RW(SelectedImage);
	}
};

REGISTER_PDE_TYPE(Gui::MailItemSkin);

namespace Gui
{
	MailItem::MailItem(void)
		: m_Selected(false)
		, m_Check(false)
		, m_Unread(true)
		, m_CheckRect(14, 7, 24 + 14, 20 + 7)
	{

	}

	MailItem::~MailItem(void)
	{

	}

	PDE_ATTRIBUTE_GETTER(MailItem,Selected,bool)
	{
		return m_Selected;
	}

	PDE_ATTRIBUTE_SETTER(MailItem,Selected,bool)
	{
		if (value != m_Selected)
		{
			m_Selected = value;
			OnSelectedChanged(EventArgs());
			if (value)
			{
				tempc_ptr(Control) parent = GetParent();
				tempc_ptr(MailItem) mailItem;
				if (parent)
				{
					Control* child = parent->GetFirstChild();
					while(child)
					{
						mailItem = ptr_dynamic_cast<MailItem>(child);
						if (mailItem && mailItem != ptr_dynamic_cast<MailItem>(this))
						{
							mailItem->SetSelected(false);
						}

						child = child->GetNext();
					}
				}
			}
			Invalid();
		}
	}

	void MailItem::OnPaint(PaintEventArgs & e)
	{
		Control::OnPaint(e);
		Core::Rectangle rect = GetDisplayRect();
		tempc_ptr(MailItemSkin) skin = ptr_static_cast<MailItemSkin>(GetSkin());
		if (skin)
		{
			if (m_Selected)
			{
				Skin::DrawImage(e.render,skin->GetSelectedImage(),rect);
			} 

			Skin::DrawImage(e.render, m_Check?skin->GetCheckIcon():skin->GetUncheckIcon(), m_CheckRect);
		}

		Core::Rectangle titleRect = Core::Rectangle::LeftTop(66, 9, 300, 27);
		Core::Rectangle contentRect = Core::Rectangle::LeftTop(66, 36, 300, 24);
		Core::Rectangle iconRect = Core::Rectangle::LeftTop(497, 13, 72, 44);
		Core::Rectangle dateRect = Core::Rectangle::LeftTop(497, 13, 72, 20);
		XRGB titleColor;
		XRGB contentColor;
		if (m_Unread)
		{
			if (m_Selected)
			{
				titleColor =  XRGB(1, 1, 1);
				contentColor = XRGB(81, 79, 79);
			}
			else
			{
				titleColor = XRGB(215, 232, 226);
				contentColor = XRGB(192, 186, 173);
			}
		}
		else
		{
			titleColor = XRGB(215, 232, 226);
			contentColor = XRGB(192, 186, 173);
		}

		SetFontSize(18);
		e.render->DrawString(GetFont(), titleColor, ARGB(0, 0, 0, 0), titleRect, m_Title, Client::Unit::kAlignLeftMiddle);
		SetFontSize(16);
		e.render->DrawString(GetFont(), contentColor, ARGB(0, 0, 0, 0), contentRect, m_Content, Client::Unit::kAlignLeftMiddle);
		if (m_Icon)
		{
			m_Icon->Draw(e.render, iconRect, ARGB(255, 255, 255, 255));
		}
		e.render->DrawString(GetFont(), titleColor, ARGB(0, 0, 0, 0), dateRect, m_Date, Client::Unit::kAlignLeftMiddle);
	}

	void MailItem::OnInputEvent(InputEventArgs & e)
	{
		if (e.IsMouseEvent())
		{
			Vector2 localPostion = ScreenToClient(e.CursorPosition);
			switch (e.Type)
			{
			case InputEventArgs::kMouseUp:
				if (m_CheckRect.IsPointInside(localPostion))
				{
					m_Check = !m_Check;
				}
				else
				{
					m_Selected = !m_Selected;
					OnSelectedChanged(EventArgs());
				}
				e.Handled = true;
				break;
			default:
				break;
			}
		}
		if (!e.Handled)
		{
			Super::OnInputEvent(e);
		}
	}

	void MailItem::OnSelectedChanged(Core::EventArgs & e)
	{
		EventSelectedChanged.Fire(ptr_static_cast<MailItem>(this),e);
	}
}
