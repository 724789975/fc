#include "pch.h"

using namespace Core;
using namespace Client;
using namespace Gui;

//--------------------------------------------------------------------------------------
// type info
//--------------------------------------------------------------------------------------
DEFINE_PDE_TYPE_CLASS(Chart)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Control);
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_METHOD(Clear);
		ADD_PDE_METHOD(AddNode);
	}
};

REGISTER_PDE_TYPE(Chart);

DEFINE_PDE_TYPE_CLASS(Gui::ChartSkin)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::ControlSkin);
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_PROPERTY_RW(ChartBGImage);
	}
};
REGISTER_PDE_TYPE(Gui::ChartSkin);

namespace Gui
{
	Chart::Chart(void)
	{
		m_aRateColor[0] = XRGB(178,178,178);
		m_aRateColor[1] = XRGB(217,204,172);
		m_aRateColor[2] = XRGB(227,200,128);
		m_aRateColor[3] = XRGB(255,185,110);
		m_aRateColor[4] = XRGB(239,132,46);
		m_aRateColor[5] = XRGB(255,112,24);
	}

	Chart::~Chart(void)
	{

	}

	void Chart::OnCreate()
	{
		Control::OnCreate();
		SetSize(Vector2(410,140));
	}

	void Chart::OnPaint(PaintEventArgs & e)
	{
		Core::Rectangle chartRect = Core::Rectangle::LeftTop(48,9,343,112);
		tempc_ptr(ChartSkin) skin = ptr_static_cast<ChartSkin>(GetSkin());

		if (skin)
		{
			Skin::DrawImage(e.render, skin->GetChartBGImage(), chartRect);
		}
		chartRect = Core::Rectangle::LeftTop(133.75,9,85.75,112);
		e.render->DrawRectangle(chartRect,chartRect,ARGB(15,255,255,255));
		chartRect = Core::Rectangle::LeftTop(305.25,9,85.75,112);
		e.render->DrawRectangle(chartRect,chartRect,ARGB(20,255,255,255));
		Core::Rectangle rateRect(0,0,37,122);
		CStrBuf<255> str;
		for (U32 i = 0;i < 6;i++)
		{
			str.format("%d%%",20*i);
			e.render->DrawString(GetFont(),m_aRateColor[i],ARGB(0,0,0,0),rateRect,str,Unit::kAlignRightBottom);
			rateRect.Move(Vector2(0,-20));
		}

		U32 count = m_aNode.Size();
		if (count > 1)
		{
			Core::Rectangle dateRect = Core::Rectangle::LeftTop(3,126,90,15);
			Core::Rectangle lineRect;
			Vector2 start;
			Vector2 location = ClientToScreen(Vector2::kZero);
			F32 width = 0.f;
			F32 roll = 0.f;
			Matrix44 oldWold = e.render->GetWorld();
			Matrix44 newWorld = oldWold;
			for(U32 i = 0 ;i < count && i < 5;i++)
			{
				e.render->DrawString(GetFont(),XRGB(189,197,201),ARGB(0,0,0,0),dateRect,m_aNode[i].Date,Unit::kAlignCenterMiddle);
				dateRect.Move(Vector2(85.75,0));
			}
			UIRender::VertexMode oldVertexMode = e.render->GetVertexMode();
			e.render->SetVertexMode(UIRender::kFloatVertexCoord);
			for (U32 i = 0;i < count - 1 && i < 4;i++)
			{
				start = Vector2(85.75*i + 48,112*(1 - m_aNode[i].Rate)+9);
				width = sqrt(85.75*85.75 + (112*Abs(m_aNode[i + 1].Rate - m_aNode[i].Rate))*(112*Abs(m_aNode[i + 1].Rate - m_aNode[i].Rate)));
				roll = atan(112*(m_aNode[i].Rate - m_aNode[i + 1].Rate)/85.75);
				if (roll > 0)
				{
					width += 2;
				}
				lineRect = Core::Rectangle::LeftTop(0,0,width,2).Move(Vector2(0,-2));
				newWorld = oldWold;
				newWorld.SetRotationYawPitchRoll(0,0,roll);
				newWorld.TranslateXYZ(location.x + start.x,location.y + start.y,0);
				e.render->SetWorld(newWorld);
				e.render->DrawRectangle(lineRect,lineRect,ARGB(255,255,112,24));
			}
			e.render->SetVertexMode(oldVertexMode);
			e.render->SetWorld(oldWold);
		}
	}

	void Chart::Clear()
	{
		m_aNode.Clear();
		Invalid();
	}

	void Chart::AddNode(const Core::String & data,F32 rate)
	{
		rate = Clamp(rate,0,1);
		Node node(data,rate);
		m_aNode.PushBack(node);
		Invalid();
	}
}
