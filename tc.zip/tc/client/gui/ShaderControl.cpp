#include "pch.h"

using namespace Core;
using namespace Gui;
using namespace Client;
//---------------------------------------------------------------------------------------
// type info.
//---------------------------------------------------------------------------------------
DEFINE_PDE_TYPE_CLASS(Gui::ShaderSkin)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::ControlSkin);
		ADD_PDE_DEFAULT_CONSTRUCTOR();
		ADD_PDE_PROPERTY_RW(ResImage1);
		ADD_PDE_PROPERTY_RW(ResImage2);
		ADD_PDE_PROPERTY_RW(ResImage3);

	}
};

REGISTER_PDE_TYPE(Gui::ShaderSkin);

DEFINE_PDE_TYPE_CLASS(Gui::ShaderControl)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::Control);
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_PROPERTY_RW(ShaderVS);
		ADD_PDE_PROPERTY_RW(ShaderPS);
	}
};

REGISTER_PDE_TYPE(Gui::ShaderControl);

//---------------------------------------------------------------------------------------
// attributes.
//---------------------------------------------------------------------------------------


namespace Gui
{
	ShaderControl::ShaderControl()
	{
	}

	PDE_ATTRIBUTE_GETTER(ShaderControl, ShaderVS, const Core::String &)
	{
		return m_ShaderVS;
	}

	PDE_ATTRIBUTE_SETTER(ShaderControl, ShaderVS, const Core::String &)
	{
		if (m_ShaderVS != value)
		{
			m_ShaderVS = value;
		}
	}

	PDE_ATTRIBUTE_GETTER(ShaderControl, ShaderPS, const Core::String &)
	{
		return m_ShaderPS;
	}

	PDE_ATTRIBUTE_SETTER(ShaderControl, ShaderPS, const Core::String &)
	{
		if (m_ShaderPS != value)
		{
			m_ShaderPS = value;
		}
	}

	ShaderControl::~ShaderControl()
	{
	}

	void ShaderControl::OnPaint(PaintEventArgs & e)
	{
		Control::OnPaint(e);

		UIRender * ui_render = gRender->ui_render;
		bool useCustomShader = false;
		UIRender::ShaderMode mode;
		if (m_ShaderPS.Size()) useCustomShader = true;

		if (useCustomShader)
		{
			mode = ui_render->GetShaderMode();
			if (ui_render->SetShaderMode(m_ShaderPS))
			{
				tempc_ptr(ShaderSkin) skin = ptr_static_cast<ShaderSkin>(GetSkin());
				if (skin)
				{
					sharedc_ptr(Image) ResMap1 = skin->GetResImage1();
					if (ResMap1)
					{
						sharedc_ptr(Client::Texture2D) ResTex1 = ResMap1->GetTexture();
						ResTex1->SetTexture(RESMAP1);
					}

					sharedc_ptr(Image) ResMap2 = skin->GetResImage2();
					if (ResMap2)
					{
						sharedc_ptr(Client::Texture2D) ResTex2 = ResMap2->GetTexture();
						ResTex2->SetTexture(RESMAP2);
					}

					sharedc_ptr(Image) ResMap3 = skin->GetResImage3();
					if (ResMap3)
					{
						sharedc_ptr(Client::Texture2D) ResTex3 = ResMap3->GetTexture();
						ResTex3->SetTexture(RESMAP3);
					}
					DWORD state1[3],state2[3],state3[3];
					gDx9Device->GetSamplerState(RESMAP1,D3DSAMP_MAGFILTER,&state1[0]);
					gDx9Device->GetSamplerState(RESMAP1,D3DSAMP_MINFILTER,&state2[0]);
					gDx9Device->GetSamplerState(RESMAP1,D3DSAMP_MIPFILTER,&state3[0]);
					gDx9Device->GetSamplerState(RESMAP1,D3DSAMP_MAGFILTER,&state1[1]);
					gDx9Device->GetSamplerState(RESMAP1,D3DSAMP_MINFILTER,&state2[1]);
					gDx9Device->GetSamplerState(RESMAP1,D3DSAMP_MIPFILTER,&state3[1]);
					gDx9Device->GetSamplerState(RESMAP1,D3DSAMP_MAGFILTER,&state1[2]);
					gDx9Device->GetSamplerState(RESMAP1,D3DSAMP_MINFILTER,&state2[2]);
					gDx9Device->GetSamplerState(RESMAP1,D3DSAMP_MIPFILTER,&state3[2]);

					gDx9Device->SetSamplerState(RESMAP1,D3DSAMP_MAGFILTER, D3DTEXF_POINT);
					gDx9Device->SetSamplerState(RESMAP1,D3DSAMP_MINFILTER, D3DTEXF_POINT);
					gDx9Device->SetSamplerState(RESMAP1,D3DSAMP_MIPFILTER, D3DTEXF_POINT);
					gDx9Device->SetSamplerState(RESMAP2,D3DSAMP_MAGFILTER, D3DTEXF_POINT);
					gDx9Device->SetSamplerState(RESMAP2,D3DSAMP_MINFILTER, D3DTEXF_POINT);
					gDx9Device->SetSamplerState(RESMAP2,D3DSAMP_MIPFILTER, D3DTEXF_POINT);
					gDx9Device->SetSamplerState(RESMAP3,D3DSAMP_MAGFILTER, D3DTEXF_POINT);
					gDx9Device->SetSamplerState(RESMAP3,D3DSAMP_MINFILTER, D3DTEXF_POINT);
					gDx9Device->SetSamplerState(RESMAP3,D3DSAMP_MIPFILTER, D3DTEXF_POINT);

					Skin::DrawImage(e.render, skin->GetResImage1(), GetBackgroundRect());
					
					gDx9Device->SetSamplerState(RESMAP1,D3DSAMP_MAGFILTER, state1[0]);
					gDx9Device->SetSamplerState(RESMAP1,D3DSAMP_MINFILTER, state2[0]);
					gDx9Device->SetSamplerState(RESMAP1,D3DSAMP_MIPFILTER, state3[0]);
					gDx9Device->SetSamplerState(RESMAP1,D3DSAMP_MAGFILTER, state1[1]);
					gDx9Device->SetSamplerState(RESMAP1,D3DSAMP_MINFILTER, state2[1]);
					gDx9Device->SetSamplerState(RESMAP1,D3DSAMP_MIPFILTER, state3[1]);
					gDx9Device->SetSamplerState(RESMAP1,D3DSAMP_MAGFILTER, state1[2]);
					gDx9Device->SetSamplerState(RESMAP1,D3DSAMP_MINFILTER, state2[2]);
					gDx9Device->SetSamplerState(RESMAP1,D3DSAMP_MIPFILTER, state3[2]);
				}
				if (useCustomShader)
				{
					ui_render->SetShaderMode(UIRender::kCommon);
				}
			}
		}
	}

	void ShaderControl::BlurEffect(PaintEventArgs & e)
	{
		UIRender * ui_render = gRender->ui_render;
		tempc_ptr(ShaderSkin) skin = ptr_static_cast<ShaderSkin>(GetSkin());
		Vector2 screen_size	 = gGame->screen->GetSize();
		gDx9Device->SetPixelShaderConstantF(PS_CONSTANT_SCALEXDIVY, &screen_size.x);

		IDirect3DSurface9* pOrgTarget = NULL;
		gDx9Device->GetRenderTarget(0, &pOrgTarget);

		Core::Rectangle clientRect = GetClientRect();;
		Core::Rectangle uv,rect;
		uv = Rectangle::LeftTop(clientRect.Min, Vector2(GetSize().x, GetSize().y));
		rect = uv;

		gDx9Device->StretchRect( gGame->dx9->render_target, NULL, gRender->lobby_pipeline->screen_downsample_rt->GetSurface(), NULL, D3DTEXF_LINEAR) ;

		{
			gDx9Device->SetRenderTarget(0, gRender->lobby_pipeline->screen_downsample_rt->GetSurface());
			ui_render->SetShaderMode(UIRender::kBlurh);
			gDx9Device->StretchRect( gRender->lobby_pipeline->screen_downsample_rt->GetSurface(), NULL, gRender->lobby_pipeline->screen_downsample_map->GetSurface(), NULL, D3DTEXF_LINEAR) ;

			gDx9Device->SetTexture(LASTSCENEDOWNSAMPLE_MAP, gRender->lobby_pipeline->screen_downsample_map->GetTexture());

			e.render->DrawRectangle(rect, uv,ARGB(0, 0, 0, 1));

			ui_render->SetShaderMode(UIRender::kBlurw);
			gDx9Device->StretchRect( gRender->lobby_pipeline->screen_downsample_rt->GetSurface(), NULL,gRender->lobby_pipeline->screen_downsample_map->GetSurface(), NULL, D3DTEXF_LINEAR) ;
			gDx9Device->SetTexture(LASTSCENEDOWNSAMPLE_MAP, gRender->lobby_pipeline->screen_downsample_map->GetTexture());

			e.render->DrawRectangle(rect, uv,ARGB(0, 0, 0, 1));
		}

		ui_render->SetShaderMode(UIRender::kBlurh);
		gDx9Device->StretchRect( gRender->lobby_pipeline->screen_downsample_rt->GetSurface(), NULL, gRender->lobby_pipeline->screen_downsample_map->GetSurface(), NULL, D3DTEXF_LINEAR);
		gDx9Device->SetTexture(LASTSCENEDOWNSAMPLE_MAP, gRender->lobby_pipeline->screen_downsample_map->GetTexture());
		e.render->DrawRectangle(rect, uv,ARGB(0, 0, 0, 1));

		ui_render->SetShaderMode(UIRender::kBlurw);
		gDx9Device->StretchRect( gRender->lobby_pipeline->screen_downsample_rt->GetSurface(), NULL,gRender->lobby_pipeline->screen_downsample_map->GetSurface(), NULL, D3DTEXF_LINEAR) ;
		gDx9Device->SetTexture(LASTSCENEDOWNSAMPLE_MAP, gRender->lobby_pipeline->screen_downsample_map->GetTexture());
		e.render->DrawRectangle(rect, uv,ARGB(0, 0, 0, 1));

		gDx9Device->StretchRect( gRender->lobby_pipeline->screen_downsample_rt->GetSurface(), NULL, pOrgTarget, NULL, D3DTEXF_LINEAR);
		gDx9Device->SetRenderTarget(0, pOrgTarget); 

		pOrgTarget->Release();
	}

}