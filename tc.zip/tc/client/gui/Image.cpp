#include "pch.h"

using namespace Core;
using namespace Client;

//---------------------------------------------------------------------------------------
// type info.
//---------------------------------------------------------------------------------------
DEFINE_PDE_TYPE_CLASS(Gui::Image)
{
	static sharedc_ptr(Gui::Image) constructor(Core::IArguments & args)
	{
		ArgumentPtr<Identifier> path(args, 0);
		ArgumentPtr<Vector4> border(args, 1);
		ArgumentPtr<Vector4> uv(args,2);

		sharedc_ptr(Gui::Image) image = ptr_new Gui::Image;

		if (path) image->SetPath(*path);
		if (border) image->SetBorder(*border);
		if (uv)	image->Setuv(*uv);
		return image;
	}

	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_CONSTRUCTOR(&constructor);

		ADD_PDE_PROPERTY_RW(Border);
		ADD_PDE_PROPERTY_RW(Path);
		ADD_PDE_PROPERTY_RW(alpha);
		ADD_PDE_PROPERTY_R (Size);
	}
};

DEFINE_PDE_TYPE_CLASS(Gui::AnimatedImage)
{
	static sharedc_ptr(Gui::AnimatedImage) constructor(Core::IArguments & args)
	{
		ArgumentPtr<Identifier> path(args, 0);
		ArgumentPtr<int> ArgNumX(args, 1);
		ArgumentPtr<int> ArgNumY(args, 2);
		ArgumentPtr<int> ArgCount(args, 3);

		int numX = 1;
		int numY = 1;
		if(ArgNumX)
			numX = *ArgNumX;
		if(ArgNumY)
			numY = *ArgNumY;
		int frameCount = numX*numY;
		if(ArgCount)
			frameCount = *ArgCount;

		sharedc_ptr(Gui::AnimatedImage) aniImage = NullPtr;
		if(path)
			 aniImage = ptr_new Gui::AnimatedImage(*path, numX, numY, frameCount);

		return aniImage;
	}

	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_CONSTRUCTOR(&constructor);

		ADD_PDE_SUPER(Gui::Image);
		ADD_PDE_PROPERTY_R(NumX);
		ADD_PDE_PROPERTY_R(NumY);
		ADD_PDE_PROPERTY_R(CurrentFrame);
		ADD_PDE_PROPERTY_RW(FrameTime);
		ADD_PDE_PROPERTY_RW(FrameCount);

		ADD_PDE_METHOD(Reset);
	}
};

DEFINE_PDE_TYPE_CLASS(Gui::ComplexImage)
{
	static sharedc_ptr(Gui::ComplexImage) constructor(Core::IArguments & args)
	{
		ArgumentPtr<Identifier> path(args, 0);
		ArgumentPtr<Vector4> border(args, 1);
		ArgumentPtr<Vector2> center(args, 2);

		sharedc_ptr(Gui::ComplexImage) complexImage = ptr_new Gui::ComplexImage;

		if (path) complexImage->SetPath(*path);
		if (border) complexImage->SetBorder(*border);
		if (center) complexImage->SetCenter(*center);

		return complexImage;
	}

	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_CONSTRUCTOR(&constructor);

		ADD_PDE_SUPER(Gui::Image);
		ADD_PDE_PROPERTY_RW(Center);
	}
};

REGISTER_PDE_TYPE(Gui::Image);
REGISTER_PDE_TYPE(Gui::AnimatedImage);
REGISTER_PDE_TYPE(Gui::ComplexImage);


namespace Gui
{
	// default constructor.
	Image::Image()
		: m_rotate(Unit::kRotateNone)
		, m_Border(0, 0, 0, 0)
		, m_uv(0,0,1,1)
		, m_alpha(-1)
	{
	}
	
	// constructor.
	Image::Image(const Core::Identifier & path, const Core::Vector4 & border,Core::Vector4 uv)
		: m_rotate(Unit::kRotateNone)
		, m_uv(uv)
	{
		SetPath(path);
		SetBorder(border);
	}
	
	// destructor
	Image::~Image()
	{
	}
}

namespace Gui
{
	PDE_ATTRIBUTE_GETTER(Image, Rotate, Unit::Rotate)
	{
		return m_rotate;
	}

	PDE_ATTRIBUTE_SETTER(Image, Rotate, Unit::Rotate)
	{
		m_rotate = value;
	}


	PDE_ATTRIBUTE_GETTER(Image, Border, const Core::Vector4 &)
	{
		return m_Border;
	}

	PDE_ATTRIBUTE_SETTER(Image, Border, const Core::Vector4 &)
	{
		m_Border = value;
	}

	PDE_ATTRIBUTE_GETTER(Image, alpha, int)
	{
		return m_alpha;
	}

	PDE_ATTRIBUTE_SETTER(Image, alpha, int)
	{
		m_alpha = value;
	}

	PDE_ATTRIBUTE_GETTER(Image, uv, Core::Vector4)
	{	

		return m_uv;
	}

	PDE_ATTRIBUTE_SETTER(Image, uv, Core::Vector4)
	{
	
		m_uv = value;
	}

	PDE_ATTRIBUTE_GETTER(Image, Path, const Core::Identifier &)
	{
		if (m_Texture)
		{
			return m_Texture->GetKey();
		}
		else
		{
			return Core::Identifier::kNull;
		}
	}

	PDE_ATTRIBUTE_SETTER(Image, Path, const Core::Identifier &)
	{
		if (!m_Texture || m_Texture->GetKey() != value)
		{
//#ifdef MASTER
//#else
//			if(value.Length() > MAX_PATH)
//			{
//				Core::ThrowErrorString(gLang->GetTextW(L"·����������󳤶ȣ�"));
//			}
//#endif	
			CStrBuf<MAX_PATH> new_path;
			new_path.format("ui/%s/%s",gGame->language, value);		
			m_Texture = ptr_dynamic_cast<Texture2D>(Resource::Load(new_path));
		}
	}

	PDE_ATTRIBUTE_GETTER(Image, Size, Core::Vector2)
	{
		float wu = m_uv.z-m_uv.x;
		float wv = m_uv.w-m_uv.y;

		if (m_Texture && m_Texture->IsReady())
		{
			return Vector2(m_Texture->GetWidth() * wu, m_Texture->GetHeight() * wv);
		}

		return Vector2::kZero;
	}
}

namespace Gui
{
	void Image::Draw(by_ptr(Client::UIRender) render, const Core::Rectangle & rect,Core::ARGB color)
	{
		if ( m_alpha != -1 )
			color.a = m_alpha;
		if (m_Texture && m_Texture->IsReady())
		{
			tempc_ptr(TextureBase) orgTexture = render->GetTexture();

			render->SetTexture(m_Texture);
			
			if (m_Border == Vector4::kZero)
			{
				render->DrawRectangle(rect,Core::Rectangle(m_uv.x, m_uv.y, m_uv.z, m_uv.w), color);
			}
			else
			{
				float width = m_Texture->GetWidth();
				float height = m_Texture->GetHeight();

				Core::Rectangle window_margin(m_Border.x, m_Border.y, m_Border.z, m_Border.w);
				Core::Rectangle uv_margin(m_Border.x / width, m_Border.y / height, m_Border.z / width, m_Border.w / height);

				render->DrawWindow(rect, window_margin, uv_margin, color, color, m_rotate);
			}

			//restore original texture
			render->SetTexture(orgTexture);
		}

	}

	void Image::DrawRotation(by_ptr(Client::UIRender) render, Vector3 Min,Vector3 Max,Core::ARGB color)
	{
		if ( m_alpha != -1 )
			color.a = m_alpha;
		if (m_Texture && m_Texture->IsReady())
		{
			tempc_ptr(TextureBase) orgTexture = render->GetTexture();

			render->SetTexture(m_Texture);

			if (m_Border == Vector4::kZero)
			{
				
				render->DrawRotation(Min, Max, Core::Rectangle(m_uv.x, m_uv.y, m_uv.z, m_uv.w), color);
				
			}

			render->SetTexture(orgTexture);
		}
	}

	void Image::DrawRotation(by_ptr(Client::UIRender) render, Vector3 Min,Vector3 Max,Vector3 TopRight,Vector3 BottomLeft,Core::ARGB color)
	{
		if ( m_alpha != -1 )
			color.a = m_alpha;
		if (m_Texture && m_Texture->IsReady())
		{
			tempc_ptr(TextureBase) orgTexture = render->GetTexture();

			render->SetTexture(m_Texture);

			if (m_Border == Vector4::kZero)
			{

				render->DrawRotation(Min, Max,TopRight,BottomLeft, Core::Rectangle(m_uv.x, m_uv.y, m_uv.z, m_uv.w), color);

			}

			render->SetTexture(orgTexture);
		}
	}
}

	
//======================================================
// AnimatedImage
//======================================================
namespace Gui
{
	// default constructor.
	AnimatedImage::AnimatedImage()
		: m_NumX(1)
		, m_NumY(1)
		, m_CurrentFrame(0)
		, m_FrameTime(1.0f/8.0f)
		, m_Accumulator(0.0f)
		, m_FrameCount(1)
	{
	}

	// constructor.
	AnimatedImage::AnimatedImage(const Core::Identifier & path, int numX, int numY, int frameCount)
		: m_CurrentFrame(0)
		, m_FrameTime(1.0f/8.0f)
		, m_Accumulator(0.0f)
	{
		SetPath(path);
		m_NumX = numX>0?numX:1;
		m_NumY = numY>0?numY:1;
		if(frameCount>0)
			m_FrameCount = frameCount;
		else
			m_FrameCount = m_NumX*m_NumY;
	}

	// destructor
	AnimatedImage::~AnimatedImage()
	{
	}
}

namespace Gui
{
	PDE_ATTRIBUTE_GETTER(AnimatedImage, FrameTime, F32)
	{
		return m_FrameTime;
	}
	PDE_ATTRIBUTE_SETTER(AnimatedImage, FrameTime, F32)
	{
		if(value>0.f)
		{
			m_FrameTime = value;
		}
	}

	PDE_ATTRIBUTE_GETTER(AnimatedImage, FrameCount, int)
	{
		return m_FrameCount;
	}
	PDE_ATTRIBUTE_SETTER(AnimatedImage, FrameCount, int)
	{
		if(value>0 && value<=m_NumX*m_NumY)
		{
			m_FrameCount = value;
		}
	}
}

namespace Gui
{
	int AnimatedImage::Update(F32 updateTime)
	{
		m_Accumulator+=updateTime;
		int newFrame = (int)(m_Accumulator/m_FrameTime);
		int newRound = newFrame/m_FrameCount;
		m_CurrentFrame = newFrame%m_FrameCount;
		m_Accumulator-=newRound*m_FrameTime*m_FrameCount;
		return m_CurrentFrame;
	}
	void AnimatedImage::Reset()
	{
		m_CurrentFrame = 0;
		m_Accumulator = 0.0f;
	}
	void AnimatedImage::Draw(by_ptr(Client::UIRender) render, const Core::Rectangle & rect, Core::ARGB color)
	{
		if (m_Texture && m_Texture->IsReady() && m_NumX>0 && m_NumY>0 && m_CurrentFrame>=0 && m_CurrentFrame<m_FrameCount)
		{
			tempc_ptr(TextureBase) orgTexture = render->GetTexture();

			render->SetTexture(m_Texture);

			Core::Rectangle currentUV;
			currentUV.Min.x = (1.0f/m_NumX)*(m_CurrentFrame%m_NumX);
			currentUV.Max.x = (1.0f/m_NumX)*(m_CurrentFrame%m_NumX+1);
			currentUV.Min.y = (1.0f/m_NumY)*(m_CurrentFrame/m_NumX);
			currentUV.Max.y = (1.0f/m_NumY)*(m_CurrentFrame/m_NumX+1);

			render->DrawRectangle(rect, currentUV, color);

			//restore original texture
			render->SetTexture(orgTexture);
		}
	}
}


//======================================================
// ComplexImage
//======================================================
namespace Gui
{
	// default constructor.
	ComplexImage::ComplexImage()
		: m_Center(0, 0)
	{
	}

	// constructor.
	ComplexImage::ComplexImage(const Core::Identifier & path, const Core::Vector4 & border, const Core::Vector2 & center)
	{
		SetPath(path);
		SetBorder(border);
		SetCenter(center);
	}

	// destructor
	ComplexImage::~ComplexImage()
	{
	}
}

namespace Gui
{
	PDE_ATTRIBUTE_GETTER(ComplexImage, Center, const Core::Vector2 &)
	{
		return m_Center;
	}

	PDE_ATTRIBUTE_SETTER(ComplexImage, Center, const Core::Vector2 &)
	{
		m_Center = value;
	}
}

namespace Gui
{
	void ComplexImage::Draw(by_ptr(Client::UIRender) render, const Core::Rectangle & rect, Core::ARGB color)
	{
		if (m_Texture && m_Texture->IsReady())
		{
			tempc_ptr(TextureBase) orgTexture = render->GetTexture();

			render->SetTexture(m_Texture);

			if (m_Border == Vector4::kZero && m_Center == Vector2::kZero)
			{
				render->DrawRectangle(rect, Core::Rectangle(0, 0, 1, 1), color);
			}
			else
			{
				float width = m_Texture->GetWidth();
				float height = m_Texture->GetHeight();

				Core::Rectangle window_margin(m_Border.x, m_Border.y, m_Border.z, m_Border.w);
				Core::Rectangle uv_margin(m_Border.x / width, m_Border.y / height, m_Border.z / width, m_Border.w / height);
				F32		horiTex = (width-m_Center.x)/2;
				F32     vertTex = (height-m_Center.y)/2;
				F32		horiWin = (rect.GetExtent().x-m_Center.x)/2;
				F32		vertWin = (rect.GetExtent().y-m_Center.y)/2;
				Core::Rectangle window_center(horiWin, vertWin, horiWin, vertWin);
				Core::Rectangle uv_center(horiTex/width, vertTex/height, horiTex/width, vertTex/height);

				render->DrawComplexWindow(rect, window_margin, uv_margin, window_center, uv_center, color, m_rotate);
			}

			//restore original texture
			render->SetTexture(orgTexture);
		}
	}
}