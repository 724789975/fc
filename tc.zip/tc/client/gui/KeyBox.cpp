#include "pch.h"

using namespace Core;
using namespace Client;
using namespace Gui;

DEFINE_PDE_TYPE_CLASS(Gui::KeyBox)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_DEFAULT_CONSTRUCTOR();
		ADD_PDE_SUPER(Gui::Control);

		ADD_PDE_EVENT(EventKeyNameChanged);
		ADD_PDE_EVENT(EventKeyConflict);
		ADD_PDE_EVENT(EventKeyForbidden);
		ADD_PDE_METHOD(Empty);
		ADD_PDE_PROPERTY_RW(KeyName);
	}
};

REGISTER_PDE_TYPE(Gui::KeyBox);

namespace Gui
{
	static struct KeyTable
	{
		const wchar_t*	Text;
		const CHAR*		Name;
		InputCode		Value;
		bool			Enable;
	}
	keyBoxTalbe[] = 
	{
		{ L"δ����",		"UNUSED",          KC_UNUSED,			false },
		{ L"",				"ESCAPE",          KC_ESCAPE,			false },
		{ L"",				"1",               KC_1,				false },
		{ L"",				"2",               KC_2,				false },
		{ L"",				"3",               KC_3,				false },
		{ L"",				"4",               KC_4,				false },
		{ L"",				"5",               KC_5,				false },
		{ L"",				"6",               KC_6,				false },
		{ L"",				"7",               KC_7,				false },
		{ L"",				"8",               KC_8,				false },
		{ L"",				"9",               KC_9,				false },
		{ L"",				"0",               KC_0,				false },
		{ L"-",         	"MINUS",           KC_MINUS,			true },
		{ L"=",        		"EQUALS",          KC_EQUALS,			true },
		{ L"��",			"BACK",            KC_BACK,				true },
		{ L"TAB",          	"TAB",             KC_TAB,				true },
		{ L"Q",            	"Q",               KC_Q,				true },
		{ L"W",            	"W",               KC_W,				true },
		{ L"E",            	"E",               KC_E,				true },
		{ L"R",             "R",               KC_R,				true },
		{ L"T",            	"T",               KC_T,				true },
		{ L"Y",            	"Y",               KC_Y,				true },
		{ L"U",            	"U",               KC_U,				true },
		{ L"I",            	"I",               KC_I,				true },
		{ L"O",            	"O",               KC_O,				true },
		{ L"P",            	"P",               KC_P,				true },
		{ L"[",      		"LBRACKET",        KC_LBRACKET,			true },
		{ L"]",      		"RBRACKET",        KC_RBRACKET,			true },
		{ L"",        		"RETURN",          KC_RETURN,			false },
		{ L"��Ctrl",      	"LCONTROL",        KC_LCONTROL,			true },
		{ L"A",              "A",               KC_A,				true },
		{ L"S",             	"S",               KC_S,				true },
		{ L"D",             	"D",               KC_D,				true },
		{ L"F",             	"F",               KC_F,				true },
		{ L"G",             	"G",               KC_G,				true },
		{ L"H",             	"H",               KC_H,				true },
		{ L"J",             	"J",               KC_J,				false },
		{ L"K",             	"K",               KC_K,				true },
		{ L"L",             	"L",               KC_L,				true },
		{ L";",     			"SEMICOLON",       KC_SEMICOLON,		true },
		{ L"'",    			"APOSTROPHE",      KC_APOSTROPHE,		true },
		{ L"~",				"GRAVE",           KC_GRAVE,			true },
		{ L"��Shift",        "LSHIFT",          KC_LSHIFT,			true },
		{ L"\\",     		"BACKSLASH",       KC_BACKSLASH,		true },
		{ L"Z",				"Z",               KC_Z,				true },
		{ L"X",             	"X",               KC_X,				true },
		{ L"C",             	"C",               KC_C,				true },
		{ L"V",             	"V",               KC_V,				true },
		{ L"B",             	"B",               KC_B,				true },
		{ L"N",             	"N",               KC_N,				true },
		{ L"M",             	"M",               KC_M,				true },
		{ L",",         		"COMMA",           KC_COMMA,			true },
		{ L".",        		"PERIOD",          KC_PERIOD,			true },
		{ L"/",         		"SLASH",           KC_SLASH,			true },
		{ L"��Shift",        "RSHIFT",          KC_RSHIFT,			true },
		{ L"С����*",      	"MULTIPLY",        KC_MULTIPLY,			true },
		{ L"��Alt",         	"LMENU",           KC_LMENU,			true },
		{ L"�ո�",         	"SPACE",           KC_SPACE,			true },
		{ L"Caps Lock",      "CAPITAL",         KC_CAPITAL,			true },
		{ L"F1",            	"F1",              KC_F1,				false },
		{ L"F2",            	"F2",              KC_F2,				false },
		{ L"F3",            	"F3",              KC_F3,				false },
		{ L"F4",            	"F4",              KC_F4,				false },
		{ L"F5",            	"F5",              KC_F5,				false },
		{ L"F6",            	"F6",              KC_F6,				false },
		{ L"F7",            	"F7",              KC_F7,				false },
		{ L"F8",            	"F8",              KC_F8,				false },
		{ L"F9",            	"F9",              KC_F9,				false },
		{ L"F10",           	"F10",             KC_F10,				false },
		{ L"Num Lock",       "NUMLOCK",         KC_NUMLOCK,			true },
		{ L"",        		"SCROLL",          KC_SCROLL,			false },
		{ L"С����7",       	"NUMPAD7",         KC_NUMPAD7,			true },
		{ L"С����8",       	"NUMPAD8",         KC_NUMPAD8,			true },
		{ L"С����9",       	"NUMPAD9",         KC_NUMPAD9,			true },
		{ L"С����-",      	"SUBTRACT",        KC_SUBTRACT,			true },
		{ L"С����4",       	"NUMPAD4",         KC_NUMPAD4,			true },
		{ L"С����5",       	"NUMPAD5",         KC_NUMPAD5,			true },
		{ L"С����6",       	"NUMPAD6",         KC_NUMPAD6,			true },
		{ L"С����+",        "ADD",             KC_ADD,				true },
		{ L"С����1",       	"NUMPAD1",         KC_NUMPAD1,			true },
		{ L"С����2",       	"NUMPAD2",         KC_NUMPAD2,			true },
		{ L"С����3",       	"NUMPAD3",         KC_NUMPAD3,			true },
		{ L"С����0",       	"NUMPAD0",         KC_NUMPAD0,			true },
		{ L"С����Del",      "DECIMAL",         KC_DECIMAL,			true },
		{ L"",       		"OEM_102",         KC_OEM_102,			false },
		{ L"",           	"F11",             KC_F11,				false },
		{ L"",           	"F12",             KC_F12,				false },
		{ L"",           	"F13",             KC_F13,				false },
		{ L"",           	"F14",             KC_F14,				false },
		{ L"",           	"F15",             KC_F15,				false },
		{ L"",          	"KANA",            KC_KANA,				false },
		{ L"",       		"ABNT_C1",         KC_ABNT_C1,			false },
		{ L"",       		"CONVERT",         KC_CONVERT,			false },
		{ L"",     			"NOCONVERT",       KC_NOCONVERT,		false },
		{ L"",           	"YEN",             KC_YEN,				false },
		{ L"",       		"ABNT_C2",         KC_ABNT_C2,			false },
		{ L"",  			"NUMPADEQUALS",    KC_NUMPADEQUALS,		false },
		{ L"",     			"PREVTRACK",       KC_PREVTRACK,		false },
		{ L"",            	"AT",              KC_AT,				false },
		{ L"",         		"COLON",           KC_COLON,			false },
		{ L"",     			"UNDERLINE",       KC_UNDERLINE,		false },
		{ L"",         		"KANJI",           KC_KANJI,			false },
		{ L"",          	"STOP",            KC_STOP,				false },
		{ L"",            	"AX",              KC_AX,				false },
		{ L"",     			"UNLABELED",       KC_UNLABELED,		false },
		{ L"",     			"NEXTTRACK",       KC_NEXTTRACK,		false },
		{ L"",   			"NUMPADENTER",     KC_NUMPADENTER,		false },
		{ L"��Ctrl",      	"RCONTROL",        KC_RCONTROL,			true },
		{ L"",          	"MUTE",            KC_MUTE,				false },
		{ L"",    			"CALCULATOR",      KC_CALCULATOR,		false },
		{ L"",     			"PLAYPAUSE",       KC_PLAYPAUSE,		false },
		{ L"",     			"MEDIASTOP",       KC_MEDIASTOP,		false },
		{ L"",    			"VOLUMEDOWN",      KC_VOLUMEDOWN,		false },
		{ L"",      		"VOLUMEUP",        KC_VOLUMEUP,			false },
		{ L"",       		"WEBHOME",         KC_WEBHOME,			false },
		{ L"",   			"NUMPADCOMMA",     KC_NUMPADCOMMA,		false },
		{ L"",        		"DIVIDE",          KC_DIVIDE,			false },
		{ L"",				"SYSRQ",           KC_SYSRQ,			false },
		{ L"��Alt",         	"RMENU",           KC_RMENU,			true },
		{ L"/",         		"INCLINEND",       KC_INCLINEND,		false },
		{ L"",         		"PAUSE",           KC_PAUSE,			false },
		{ L"",          	"HOME",            KC_HOME,				false },
		{ L"��",            	"UP",              KC_UP,				true },
		{ L"Page Up",        "PGUP",            KC_PGUP,				true },
		{ L"��",          	"LEFT",            KC_LEFT,				true },
		{ L"��",         	"RIGHT",           KC_RIGHT,			true },
		{ L"End",           	"END",             KC_END,				false },
		{ L"��",          	"DOWN",            KC_DOWN,				true },
		{ L"Page Down",      "PGDOWN",          KC_PGDOWN,			true },
		{ L"Insert",        	"INSERT",          KC_INSERT,			true },
		{ L"Delete",        	"DELETE",          KC_DELETE,			true },
		{ L"",          	"LWIN",            KC_LWIN,				false },
		{ L"",				"RWIN",            KC_RWIN,				false },
		{ L"",          	"APPS",            KC_APPS,				false },
		{ L"",         		"POWER",           KC_POWER,			false },
		{ L"",         		"SLEEP",           KC_SLEEP,			false },
		{ L"",				"WAKE",            KC_WAKE,				false },
		{ L"",     			"WEBSEARCH",       KC_WEBSEARCH,		false },
		{ L"",  			"WEBFAVORITES",    KC_WEBFAVORITES,		false },
		{ L"",    			"WEBREFRESH",      KC_WEBREFRESH,		false },
		{ L"",       		"WEBSTOP",         KC_WEBSTOP,			false },
		{ L"",    			"WEBFORWARD",      KC_WEBFORWARD,		false },
		{ L"",       		"WEBBACK",         KC_WEBBACK,			false },
		{ L"",    			"MYCOMPUTER",      KC_MYCOMPUTER,		false },
		{ L"",				"MAIL",            KC_MAIL,				false },
		{ L"",   			"MEDIASELECT",     KC_MEDIASELECT,		false },

		{ L"������",   	"LEFT_BUTTON",	   MC_LEFT_BUTTON,		true },
		{ L"����Ҽ�",   	"RIGHT_BUTTON",	   MC_RIGHT_BUTTON,		true },

	};

	PDE_ATTRIBUTE_GETTER(KeyBox, KeyName, String)
	{
		return m_KeyName;
	}

	PDE_ATTRIBUTE_SETTER(KeyBox, KeyName, String)
	{
		if (value != m_KeyName)
		{
			m_KeyName = value;
			for (U32 i = 0; i < ELEMENTS_OF(keyBoxTalbe); i++)
			{
				if (m_KeyName == keyBoxTalbe[i].Name)
				{
					m_KeyText = gLang->GetTextW(keyBoxTalbe[i].Text);
					Invalid();
					OnKeyNameChanged();
					break;
				}
			}
		}

	}
	KeyBox::KeyBox()
		: m_CursorVisible(false)
		, m_Setting(false)
	{

	}

	KeyBox::~KeyBox()
	{

	}

	void KeyBox::OnPaint(PaintEventArgs & e)
	{
		Super::OnPaint(e);
		Core::Rectangle rect(GetDisplayRect());

		if (m_CursorVisible)
		{
			AlphaBlendMode blend = e.render->GetBlendMode();
			e.render->SetBlendMode(kInverseColor);
			e.render->SetTexture(NullPtr);
			e.render->DrawLine2d(Vector2(2,2),Vector2(2,m_Size.y - 2), ARGB(255,255,255,255));
			e.render->SetBlendMode(blend);
		}
		if (m_Setting)
			e.render->DrawString(GetFont(),ARGB(255,255,0,0),ARGB(0,0,0,0),rect,m_KeyText,Unit::kAlignCenterMiddle);
		else
			e.render->DrawString(GetFont(),m_TextColor,ARGB(0,0,0,0),rect,m_KeyText,Unit::kAlignCenterMiddle);
	}

	void KeyBox::OnInputEvent(InputEventArgs & e)
	{
		if (m_Setting)
		{
			if (gGame->input->IsKeyDown(KC_ESCAPE))
			{
				SetFocused(false);
				if (GetParent())
				{
					GetParent()->SetFocused(true);
				}
				e.Handled = true;
				return;
			}
			for (U32 i = 0;i < ELEMENTS_OF(keyBoxTalbe);i++)
			{
				if (gGame->input->IsKeyDown(keyBoxTalbe[i].Value))
				{
					if (gGame->config->IsInputChangeable(keyBoxTalbe[i].Value))
					{
						if (keyBoxTalbe[i].Enable)
						{
							m_KeyName = keyBoxTalbe[i].Name;
							m_KeyText = gLang->GetTextW(keyBoxTalbe[i].Text);
							m_Setting = false;
							Invalid();
							OnKeyNameChanged();
						}
						else
						{
							OnKeyForbidden();
						}
					}
					else
					{
						OnKeyConflict();
					}
					break;
					e.Handled = true;
				}
			}
		}
		else
		{
			if (GetFocused() && gGame->input->IsKeyDown(MC_LEFT_BUTTON))
			{
				m_Setting = true;
				e.Handled = true;
			}
		}
	}

	void KeyBox::OnFrameUpdate(EventArgs & e)
	{
		bool showCursor = m_Setting && static_cast<U32>(Core::Task::GetTotalTime()*2) & 1;

		if (m_CursorVisible != showCursor)
		{
			m_CursorVisible = showCursor;
			Invalid();
		}
	}

	void KeyBox::OnLeave(EventArgs & e)
	{
		m_Setting = false;
		Super::OnLeave(e);
	}

	void KeyBox::OnKeyNameChanged()
	{
		EventKeyNameChanged.Fire(ptr_static_cast<KeyBox>(this),EventArgs());
	}

	void KeyBox::OnKeyConflict()
	{
		EventKeyConflict.Fire(ptr_static_cast<KeyBox>(this),EventArgs());
	}

	void KeyBox::OnKeyForbidden()
	{
		EventKeyForbidden.Fire(ptr_static_cast<KeyBox>(this),EventArgs());
	}

	void KeyBox::Empty()
	{
		m_KeyName =  "UNUSED";
		m_KeyText = gLang->GetTextW(L"δ����");
		Invalid();
	}
}