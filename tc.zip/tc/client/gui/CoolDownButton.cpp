#include "pch.h"

using namespace Core;
using namespace Gui;
using namespace Client;

//---------------------------------------------------------------------------------------
// type info.
//---------------------------------------------------------------------------------------
DEFINE_PDE_TYPE_CLASS(Gui::CoolDownButton)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::Control);
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_EVENT(EventClick);
		ADD_PDE_EVENT(EventDoubleClick);

		ADD_PDE_PROPERTY_RW(TextAlign);
		ADD_PDE_PROPERTY_RW(AlphaTestValue);
		ADD_PDE_PROPERTY_RW(AlphaBlendValue);
		ADD_PDE_PROPERTY_RW(CoolDownTime);
	}
};

DEFINE_PDE_TYPE_CLASS(Gui::CoolDownButtonSkin)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::ControlSkin);
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_PROPERTY_RW(OriginalImage);
		ADD_PDE_PROPERTY_RW(MaskImage);
	}
};

REGISTER_PDE_TYPE(Gui::CoolDownButton);
REGISTER_PDE_TYPE(Gui::CoolDownButtonSkin);


#define CLICK_EFFECT_DURATION 0.4f

//---------------------------------------------------------------------------------------
// attributes.
//---------------------------------------------------------------------------------------
namespace Gui
{
	CoolDownButton::CoolDownButton()
		: m_TextAlign(Client::Unit::kAlignCenterMiddle)
		, m_AlphaTestValue(1.0)
		, m_AlphaBlendValue(1.0)
		, m_CoolDownTime(1.5)
		, m_IsCoolDown(false)
		, m_IsMouseHoldDown(false)
		, m_IsMousePointed(false)
	{
	}

	CoolDownButton::~CoolDownButton()
	{
	}

	PDE_ATTRIBUTE_GETTER(CoolDownButton, TextAlign, Client::Unit::Align)
	{
		return m_TextAlign;
	}


	PDE_ATTRIBUTE_SETTER(CoolDownButton, TextAlign, Client::Unit::Align)
	{
		if (m_TextAlign != value)
		{
			m_TextAlign = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_SETTER(CoolDownButton, AlphaTestValue, float)
	{
		m_AlphaTestValue = value;
	}

	PDE_ATTRIBUTE_GETTER(CoolDownButton, AlphaTestValue, float)
	{
		return m_AlphaTestValue;
	}

	PDE_ATTRIBUTE_SETTER(CoolDownButton, AlphaBlendValue, float)
	{
		m_AlphaBlendValue = value;
	}

	PDE_ATTRIBUTE_GETTER(CoolDownButton, AlphaBlendValue, float)
	{
		return m_AlphaBlendValue;
	}

	PDE_ATTRIBUTE_SETTER(CoolDownButton, CoolDownTime, float)
	{
		m_CoolDownTime = value;
	}

	PDE_ATTRIBUTE_GETTER(CoolDownButton, CoolDownTime, float)
	{
		return m_CoolDownTime;
	}
}

//--------------------------------------------------------------------------------------
// events.
//--------------------------------------------------------------------------------------
namespace Gui
{
	void CoolDownButton::OnFrameUpdate(EventArgs & e)
	{
		Control::OnFrameUpdate(e);
	}

	void CoolDownButton::OnPaint(PaintEventArgs & e)
	{
		Control::OnPaint(e);

		tempc_ptr(CoolDownButtonSkin) skin = ptr_static_cast<CoolDownButtonSkin>(GetSkin());

		if (skin)
		{
			if(e.Enable)
			{
				Skin::DrawImage(e.render, skin->GetOriginalImage(), GetBackgroundRect());
				e.render->DrawString(GetFont(), GetTextColor(), ARGB(0, 0, 0, 0), GetBackgroundRect().Shrink(GetPadding()), m_Text, GetTextAlign());
			}
		}
		else
		{
			e.render->DrawString(GetFont(), m_TextColor, m_BackgroundColor, GetBackgroundRect().Shrink(GetPadding()), m_Text, GetTextAlign());
		}
	}


	void CoolDownButton::OnInputEvent( Client::InputEventArgs &e )
	{
		if (e.IsMouseEvent())
		{

			Core::Vector2 localPos = ScreenToClient(e.CursorPosition);
			m_IsMousePointed =  GetDisplayRect().IsPointInside(localPos);

			switch (e.Type)
			{
			case InputEventArgs::kMouseDown:
			case InputEventArgs::kMouseDoubleClick:
				{
					if(m_IsMousePointed && e.Code == MC_LEFT_BUTTON )
					{
						if (e.Type == InputEventArgs::kMouseDoubleClick)
						{
							OnDoubleClick(e);
						}
						Invalid();
						SetCapture(true);
						m_IsMouseHoldDown = true;
						e.Handled = true;
					}
				}
				break;

			case InputEventArgs::kMouseUp:
				{
					if(e.Code == MC_LEFT_BUTTON && m_IsMouseHoldDown)
					{					
						Invalid();
						m_IsMouseHoldDown = false;

						SetCapture(false);

						if(m_IsMousePointed)
						{
							OnClick(e);
						}
						e.Handled = true;
					}
				}
				break;

			case InputEventArgs::kMouseLeave:
				{
					m_IsMousePointed = false;
					e.Handled = false;
				}
				break;
			}
		}

		if(e.IsKeyEvent())
			OnKeyEvent(e);

		if (!e.Handled)
			Control::OnInputEvent(e);
	}

	void CoolDownButton::OnKeyEvent(Client::InputEventArgs &e)
	{
		//key down
		if(e.Type == InputEventArgs::kKeyDown && !(e.ShiftKeyDown || e.ControlKeyDown || e.AltKeyDown))
		{	
			switch(e.Code)
			{
			case KC_SPACE:
			case KC_RETURN:
			default:
				break; 

			}
		}
		//key up
		if(e.Type == InputEventArgs::kKeyUp)
		{
			switch(e.Code)
			{
			case KC_SPACE:
			case KC_RETURN:
			default:
				break;

			}
		}

	}


	void CoolDownButton::OnClick(Client::InputEventArgs &e)
	{
		SetShine(false);
		EventClick.Fire(ptr_static_cast<CoolDownButton>(this), e);
	}

	void CoolDownButton::OnDoubleClick(Client::InputEventArgs & e)
	{
		EventDoubleClick.Fire(ptr_static_cast<CoolDownButton>(this), e);
	}
}