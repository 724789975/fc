#include "pch.h"

using namespace Core;
using namespace Gui;
using namespace Client;
//---------------------------------------------------------------------------------------
// type info.
//---------------------------------------------------------------------------------------
DEFINE_PDE_TYPE_CLASS(Gui::FlashSkin)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::ControlSkin);
		ADD_PDE_DEFAULT_CONSTRUCTOR();
	}
};
REGISTER_PDE_TYPE(Gui::FlashSkin);

DEFINE_PDE_TYPE_CLASS(Gui::FlashControl)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::Control);
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_EVENT(EventTimer);

		ADD_PDE_METHOD(CleanData);

		ADD_PDE_PROPERTY_RW(UseTime);
		ADD_PDE_PROPERTY_RW(DisplayTime);
		ADD_PDE_PROPERTY_RW(IsUrl);
	}
};
REGISTER_PDE_TYPE(Gui::FlashControl);

//---------------------------------------------------------------------------------------
// attributes.
//---------------------------------------------------------------------------------------
namespace Gui
{

	FlashControl::FlashControl()
		: flash_player(NullPtr)
		, reset_time(0)
		, m_UseTime(false)
		, m_IsUrl(false)
		, m_DisplayTime(0.f)
	{
		
	}

	FlashControl::~FlashControl()
	{
	}

	PDE_ATTRIBUTE_SETTER(FlashControl, UseTime, bool)
	{
		if (m_UseTime != value)
		{
			m_UseTime = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(FlashControl, UseTime, bool)
	{
		return m_UseTime;
	}

	PDE_ATTRIBUTE_SETTER(FlashControl, DisplayTime, F32)
	{
		if (m_DisplayTime != value)
		{
			m_DisplayTime = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(FlashControl, DisplayTime, F32)
	{
		return m_DisplayTime;
	}

	PDE_ATTRIBUTE_SETTER(FlashControl, IsUrl, bool)
	{
		if (m_IsUrl != value)
		{
			m_IsUrl = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(FlashControl, IsUrl, bool)
	{
		return m_IsUrl;
	}


	void FlashControl::OnPaint(PaintEventArgs & e)
	{
		if (e.render)
		{
			if (!flash_player)
			{
				flash_player = ptr_new FlashPlayer;
				if(!m_IsUrl)
				{
					Core::String str = Core::String::Format("flash/%s.swf",m_Text);
					flash_player->Initialize(m_Size.x,m_Size.y,str.Str(),false);
					str = Core::String::Format("LobbyUI/flash/%s.dds",m_Text);
					temp_picture = RESOURCE_LOAD_NEW(str.Str(), true, Texture2D);
				}
				else
				{
					flash_player->Initialize(m_Size.x,m_Size.y,m_Text.Str(),true);
				}
				
			}
			else
			{
				flash_player->OnRender();

				//D3DXSaveTextureToFileA("c:/a.dds", D3DXIFF_DDS, flash_player->texture_flash->GetTexture(), NULL);
				if (flash_player->texture_flash)
				{
					if (m_UseTime)
					{
						if(reset_time <= 0)
							reset_time = Task::GetTotalTime();
						if ((Task::GetTotalTime() - reset_time) > m_DisplayTime)
						{
							reset_time = Task::GetTotalTime();
							EventTimer.Fire(ptr_static_cast<FlashControl>(this), Core::EventArgs());
						}
					}

					tempc_ptr(TextureBase) orgTexture = e.render->GetTexture();

					if (flash_player->texture_flash)
					{
						e.render->SetTexture(flash_player->texture_flash);
					}
					else
					{
						e.render->SetTexture(temp_picture);
						m_UseTime = false;
						EventTimer.Fire(ptr_static_cast<FlashControl>(this), Core::EventArgs());
					}
					e.render->DrawWindow(Core::Rectangle(0,0,m_Size.x,m_Size.y), Core::Rectangle(0,0,0,0), Core::Rectangle(0,0,0,0),Core::ARGB(255, 255, 255),m_BackgroundColor);

					e.render->SetTexture(orgTexture);
				}
			}
		}
	}

	void FlashControl::CleanData()
	{
		reset_time = 0;
		if (flash_player)
			flash_player = NullPtr;
	}

	void FlashControl::OnInputEvent(InputEventArgs & e)
	{
		InputEventArgs e_tmp(e);
		e_tmp.CursorPosition = ScreenToClient(e_tmp.CursorPosition);

		if (flash_player)
		{
			if (e_tmp.IsMouseEvent())
			{
				flash_player->OnMouseInput(e_tmp);
			}
			else if (e_tmp.IsKeyEvent())
			{
				flash_player->OnKeyInput(e_tmp);
			}
		}

		if (!e_tmp.Handled)
			Control::OnInputEvent(e);
	}

	void FlashControl::OnLayout(EventArgs & e)
	{
		if (flash_player)
		{
			flash_player->DoForceRender();
		}
	}

	void FlashControl::OnSizeChanged(ResizeEventArgs & e)
	{
		if (flash_player)
		{
			flash_player->Resize(m_Size.x, m_Size.y);
		}
	}
}
