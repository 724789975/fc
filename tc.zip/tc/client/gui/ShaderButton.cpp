#include "pch.h"

using namespace Core;
using namespace Gui;
using namespace Client;

//---------------------------------------------------------------------------------------
// type info.
//---------------------------------------------------------------------------------------
DEFINE_PDE_TYPE_CLASS(Gui::ShaderButton)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::Button);
		ADD_PDE_DEFAULT_CONSTRUCTOR();
		ADD_PDE_PROPERTY_RW(IsShowTime);
		ADD_PDE_PROPERTY_RW(ShaderVS);
		ADD_PDE_PROPERTY_RW(ShaderPS);
	}
};

DEFINE_PDE_TYPE_CLASS(Gui::ShaderButtonSkin)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::ButtonSkin);
		ADD_PDE_DEFAULT_CONSTRUCTOR();
		ADD_PDE_PROPERTY_RW(ResImage1);
		ADD_PDE_PROPERTY_RW(ResImage2);
		ADD_PDE_PROPERTY_RW(ResImage3);
	}
};

REGISTER_PDE_TYPE(Gui::ShaderButton);
REGISTER_PDE_TYPE(Gui::ShaderButtonSkin);

namespace Gui
{
	ShaderButton::ShaderButton()
	{
		m_IsShowTime = false;
	}
	
	ShaderButton::~ShaderButton()
	{
	}

	PDE_ATTRIBUTE_GETTER(ShaderButton, ShaderVS, const Core::String &)
	{
		return m_ShaderVS;
	}

	PDE_ATTRIBUTE_SETTER(ShaderButton, ShaderVS, const Core::String &)
	{
		if (m_ShaderVS != value)
		{
			m_ShaderVS = value;
		}
	}

	PDE_ATTRIBUTE_GETTER(ShaderButton, ShaderPS, const Core::String &)
	{
		return m_ShaderPS;
	}

	PDE_ATTRIBUTE_SETTER(ShaderButton, ShaderPS, const Core::String &)
	{
		if (m_ShaderPS != value)
		{
			m_ShaderPS = value;
		}
	}

	PDE_ATTRIBUTE_GETTER(ShaderButton, IsShowTime, bool)
	{
		return m_IsShowTime;
	}

	PDE_ATTRIBUTE_SETTER(ShaderButton, IsShowTime, bool)
	{
		if (m_IsShowTime != value)
		{
			m_IsShowTime = value;
		}
	}

	void ShaderButton::OnPaint( PaintEventArgs & e )
	{
		Button::OnPaint(e);

		UIRender * ui_render = gRender->ui_render;
		bool useCustomShader = false;
		UIRender::ShaderMode mode;
		if (m_ShaderPS.Size()) useCustomShader = true;

		if (useCustomShader && m_IsShowTime && m_Enable)
		{
			mode = ui_render->GetShaderMode();
			if (ui_render->SetShaderMode(m_ShaderPS))
			{
				tempc_ptr(ShaderButtonSkin) skin = ptr_static_cast<ShaderButtonSkin>(GetSkin());
				if (skin)
				{
					sharedc_ptr(Image) ResMap1 = skin->GetResImage1();
					if (ResMap1)
					{
						sharedc_ptr(Client::Texture2D) ResTex1 = ResMap1->GetTexture();
						ResTex1->SetTexture(RESMAP1);
					}

					sharedc_ptr(Image) ResMap2 = skin->GetResImage2();
					if (ResMap2)
					{
						sharedc_ptr(Client::Texture2D) ResTex2 = ResMap2->GetTexture();
						ResTex2->SetTexture(RESMAP2);
					}

					sharedc_ptr(Image) ResMap3 = skin->GetResImage3();
					if (ResMap3)
					{
						sharedc_ptr(Client::Texture2D) ResTex3 = ResMap3->GetTexture();
						ResTex3->SetTexture(RESMAP3);
					}
					DWORD state1[3],state2[3],state3[3];
					gDx9Device->GetSamplerState(RESMAP1,D3DSAMP_MAGFILTER,&state1[0]);
					gDx9Device->GetSamplerState(RESMAP1,D3DSAMP_MINFILTER,&state2[0]);
					gDx9Device->GetSamplerState(RESMAP1,D3DSAMP_MIPFILTER,&state3[0]);
					gDx9Device->GetSamplerState(RESMAP1,D3DSAMP_MAGFILTER,&state1[1]);
					gDx9Device->GetSamplerState(RESMAP1,D3DSAMP_MINFILTER,&state2[1]);
					gDx9Device->GetSamplerState(RESMAP1,D3DSAMP_MIPFILTER,&state3[1]);
					gDx9Device->GetSamplerState(RESMAP1,D3DSAMP_MAGFILTER,&state1[2]);
					gDx9Device->GetSamplerState(RESMAP1,D3DSAMP_MINFILTER,&state2[2]);
					gDx9Device->GetSamplerState(RESMAP1,D3DSAMP_MIPFILTER,&state3[2]);

					gDx9Device->SetSamplerState(RESMAP1,D3DSAMP_MAGFILTER, D3DTEXF_POINT);
					gDx9Device->SetSamplerState(RESMAP1,D3DSAMP_MINFILTER, D3DTEXF_POINT);
					gDx9Device->SetSamplerState(RESMAP1,D3DSAMP_MIPFILTER, D3DTEXF_POINT);
					gDx9Device->SetSamplerState(RESMAP2,D3DSAMP_MAGFILTER, D3DTEXF_POINT);
					gDx9Device->SetSamplerState(RESMAP2,D3DSAMP_MINFILTER, D3DTEXF_POINT);
					gDx9Device->SetSamplerState(RESMAP2,D3DSAMP_MIPFILTER, D3DTEXF_POINT);
					gDx9Device->SetSamplerState(RESMAP3,D3DSAMP_MAGFILTER, D3DTEXF_POINT);
					gDx9Device->SetSamplerState(RESMAP3,D3DSAMP_MINFILTER, D3DTEXF_POINT);
					gDx9Device->SetSamplerState(RESMAP3,D3DSAMP_MIPFILTER, D3DTEXF_POINT);

					Skin::DrawImage(e.render, skin->GetResImage1(), GetBackgroundRect());

					gDx9Device->SetSamplerState(RESMAP1,D3DSAMP_MAGFILTER, state1[0]);
					gDx9Device->SetSamplerState(RESMAP1,D3DSAMP_MINFILTER, state2[0]);
					gDx9Device->SetSamplerState(RESMAP1,D3DSAMP_MIPFILTER, state3[0]);
					gDx9Device->SetSamplerState(RESMAP1,D3DSAMP_MAGFILTER, state1[1]);
					gDx9Device->SetSamplerState(RESMAP1,D3DSAMP_MINFILTER, state2[1]);
					gDx9Device->SetSamplerState(RESMAP1,D3DSAMP_MIPFILTER, state3[1]);
					gDx9Device->SetSamplerState(RESMAP1,D3DSAMP_MAGFILTER, state1[2]);
					gDx9Device->SetSamplerState(RESMAP1,D3DSAMP_MINFILTER, state2[2]);
					gDx9Device->SetSamplerState(RESMAP1,D3DSAMP_MIPFILTER, state3[2]);
				}
				if (useCustomShader)
				{
					ui_render->SetShaderMode(UIRender::kCommon);
				}
			}
		}
	}
}