#include "pch.h"

using namespace Core;
using namespace Client;
using namespace Gui;

//--------------------------------------------------------------------------------------
// type info
//--------------------------------------------------------------------------------------

DEFINE_PDE_TYPE_CLASS(Gui::ComboListSkin)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::ScrollableControlSkin);
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_PROPERTY_RW(ItemHoverImage);
		ADD_PDE_PROPERTY_RW(ItemActiveImage);
		ADD_PDE_PROPERTY_RW(ItemIconImage);
		ADD_PDE_PROPERTY_RW(ItemIconImage1);
		ADD_PDE_PROPERTY_RW(ItemIconImage2);
		ADD_PDE_PROPERTY_RW(ItemDisableImage);
		
	}
};

DEFINE_PDE_TYPE_CLASS(Gui::ComboList)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::ScrollableControl);
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_PROPERTY_RW(DropDownWidth);
		ADD_PDE_PROPERTY_RW(DropDownHeight);
		ADD_PDE_PROPERTY_RW(SelectedIndex);
		ADD_PDE_PROPERTY_RW(ActiveIndex);
		ADD_PDE_PROPERTY_RW(Pad_x);
		ADD_PDE_EVENT(EventListClick);
		ADD_PDE_PROPERTY_R(ItemCount);
		ADD_PDE_PROPERTY_RW(ItemAlign);
		ADD_PDE_PROPERTY_RW(TextPadding);

		ADD_PDE_METHOD(AddItem);
		ADD_PDE_METHOD(SetItemDisable);
		ADD_PDE_METHOD(IndexToText);
		ADD_PDE_METHOD(TextToIndex);
	}
};

REGISTER_PDE_TYPE(Gui::ComboListSkin);
REGISTER_PDE_TYPE(Gui::ComboList);

const U32 Gui::ComboList::ITEM_HEIGHT=25;

namespace Gui
{
	ComboList::ComboList()
		: m_SelectedIndex(INDEX_NONE)
		, m_ActiveIndex(INDEX_NONE)
		, m_ItemCount(0)
		, m_DropDownHeight(0)
		, m_DropDownWidth(0)
		, m_Pad_x(0)
		, m_ItemAlign(Unit::kAlignLeftMiddle)
		, m_TextPadding(0, 0, 0, 0)
	{

	}

	ComboList::~ComboList()
	{
		m_aItems.Clear();
	}
}


//--------------------------------------------------------------------------------------
// Attribute
//--------------------------------------------------------------------------------------
namespace Gui
{
	PDE_ATTRIBUTE_GETTER(ComboList, SelectedIndex, S32)
	{
		return m_SelectedIndex;
	}


	PDE_ATTRIBUTE_SETTER(ComboList, SelectedIndex, S32)
	{
		if (m_SelectedIndex != value && value < (S32)m_ItemCount)
		{
			if (value < 0)
			{
				m_SelectedIndex = INDEX_NONE;
			}
			else
			{
				m_SelectedIndex = value;
				Invalid();
			}
		}
	}

	PDE_ATTRIBUTE_GETTER(ComboList, ActiveIndex, S32)
	{
		return m_ActiveIndex;
	}


	PDE_ATTRIBUTE_SETTER(ComboList, ActiveIndex, S32)
	{
		if (m_ActiveIndex != value && value < (S32)m_ItemCount)
		{
			if (value < 0)
			{
				m_ActiveIndex = INDEX_NONE;
			}
			else
			{
				m_ActiveIndex = value;
				SetText(IndexToText());
				Invalid();
			}
		}
	}

	PDE_ATTRIBUTE_GETTER(ComboList, DropDownHeight, U32)
	{
		return m_DropDownHeight;
	}


	PDE_ATTRIBUTE_SETTER(ComboList, DropDownHeight, U32)
	{
		m_DropDownHeight = value;
		DirtyLayout();
	}

	PDE_ATTRIBUTE_GETTER(ComboList, DropDownWidth, U32)
	{
		return m_DropDownWidth;
	}


	PDE_ATTRIBUTE_SETTER(ComboList, DropDownWidth, U32)
	{
		m_DropDownWidth = value;
		DirtyLayout();
	}

	PDE_ATTRIBUTE_GETTER(ComboList, Pad_x, F32)
	{
		return m_Pad_x;
	}


	PDE_ATTRIBUTE_SETTER(ComboList, Pad_x, F32)
	{
		m_Pad_x = value;
		DirtyLayout();
	}

	PDE_ATTRIBUTE_GETTER(ComboList, ItemCount, U32)
	{
		return m_ItemCount;
	}

	PDE_ATTRIBUTE_GETTER(ComboList, ItemAlign, Unit::Align)
	{
		return m_ItemAlign;
	}

	PDE_ATTRIBUTE_SETTER(ComboList, ItemAlign, Unit::Align)
	{
		if (value != m_ItemAlign)
		{
			m_ItemAlign = value;
			Invalid();
		}
	}
}


//--------------------------------------------------------------------------------------
// Event
//--------------------------------------------------------------------------------------
namespace Gui
{

	/// on paint client
	void ComboList::OnPaint(PaintEventArgs & e)
	{
		Super::OnPaint(e);

		Core::Rectangle oldScissor = e.render->GetScissorRect();
		Core::Rectangle newScissor = oldScissor;
		newScissor.Shrink(GetDisplayPadding());

		e.render->SetScissorRect(newScissor);

		tempc_ptr(ComboListSkin) skin = ptr_dynamic_cast<ComboListSkin>(GetSkin());
		if(skin)
		{
			for (U8 i=0; i<m_ItemCount; ++i)
			{
				Core::Rectangle itemRect = Core::Rectangle::LeftTop(Vector2(0, ITEM_HEIGHT * i),Vector2(GetSize().x, ITEM_HEIGHT));
				if(m_VScrollBarDisplay!=kHide && m_VScrollBar && m_VScrollBar->GetVisible())
					itemRect.Max.x -=  m_VScrollBar->GetSize().x - m_VScrollBarPos.x;
				Core::Rectangle textRect = itemRect;
				textRect.Shrink(Vector4(4, 0, 4, 0) + m_TextPadding);
				itemRect.Move(Vector2(0, m_Border.y));
				textRect.Move(Vector2(0, m_Border.y));

				if(m_aItems[i].disabled)
				{
					Skin::DrawImage(e.render, skin->GetItemDisableImage(), itemRect);
					e.render->DrawString(GetFont(), Core::ARGB(255,128,128,128), Core::ARGB(0, 255, 255, 255),textRect, m_aItems[i].Text, m_ItemAlign);
				}
				else
				{
					if(m_ActiveIndex == i)
					{
						Skin::DrawImage(e.render, skin->GetItemActiveImage(), itemRect);
						e.render->DrawString(GetFont(), GetHighlightTextColor(), Core::ARGB(0, 255, 255, 255),textRect, m_aItems[i].Text, m_ItemAlign);
					}
					else if(m_SelectedIndex == i)
					{
						Skin::DrawImage(e.render, skin->GetItemHoverImage(), itemRect);
						e.render->DrawString(GetFont(), GetHighlightTextColor(), Core::ARGB(0, 255, 255, 255),textRect, m_aItems[i].Text, m_ItemAlign);
					}
					else
					{
						e.render->DrawString(GetFont(), GetTextColor(), Core::ARGB(0, 255, 255, 255),textRect, m_aItems[i].Text, m_ItemAlign);
					}
				}

				sharedc_ptr(Image) Image_Icon[3] = {skin->GetItemIconImage(),skin->GetItemIconImage1(),skin->GetItemIconImage2()}; 
				int which = m_aItems[i].icon_Index;
				if(m_aItems[i].with_icon && Image_Icon[which] && m_ComboBox)
				{
					Vector2 icon_size = Vector2(Image_Icon[which]->GetTexture()->GetWidth(),Image_Icon[which]->GetTexture()->GetHeight());
					sharedc_ptr(ComboBox) owner= m_ComboBox;
					Vector2 p[4];
					itemRect.ComputePoints(p);
					Vector2 target = Vector2(p[0].x + owner->GetWithIconOffset().x, p[0].y + owner->GetWithIconOffset().y);
					Core::Rectangle rc_icon = Core::Rectangle::LeftTop(target,icon_size);
					Skin::DrawImage(e.render, Image_Icon[which], rc_icon);
				}
				textRect.Min.x += m_Pad_x;
			}
		}
		else
		{
			for (U8 i=0; i<m_ItemCount; ++i)
			{
				Core::Rectangle textRect = Core::Rectangle::LeftTop(Vector2(4, ITEM_HEIGHT * i),Vector2(GetSize().x - 8, ITEM_HEIGHT));
				e.render->DrawString(GetFont(), m_TextColor, (m_SelectedIndex == i) ?XRGB(128,128,128):XRGB(255,255,255),textRect, m_aItems[i].Text, m_ItemAlign);
			}
		}

		e.render->SetScissorRect(oldScissor);
	}

	/// on layout event
	void ComboList::OnLayout(EventArgs & e)
	{

		U32 width = GetDropDownWidth();
		U32 height = GetDropDownHeight();
		U32 itemsHeight = ITEM_HEIGHT * GetItemCount()+m_Border.y+m_Border.w;

		if (height == 0 || height > itemsHeight)
			height = itemsHeight;

		sharedc_ptr(ComboBox) owner = m_ComboBox;

		if(owner)
			width = Core::Max((U32)owner->GetSize().x,width);

		SetAutoScroll(height < itemsHeight);
		SetSize(Vector2(width, height));

		if (GetAutoScroll())
		{
			Vector2 autoSize(0, itemsHeight);
			SetAutoScrollMinSize(autoSize);
			if(m_VScrollBar)
				m_VScrollBar->SetSmallChange(ITEM_HEIGHT);
		}

		Super::OnLayout(e);

	}

	/// on input event
	void ComboList::OnInputEvent(InputEventArgs & e)
	{
		if (e.IsMouseEvent())
		{
			//First let the scrollbar handle the input
			if (GetAutoScroll())
			{
				if (m_HScrollBarDisplay!=kHide && m_HScrollBar && m_HScrollBar->GetVisible())
					m_HScrollBar->OnInputEvent(ptr_static_cast<Control>(this), e);

				if (e.Handled)
				{
					SetSelectedIndex(INDEX_NONE);
					Invalid();
					return;
				}

				if (m_VScrollBarDisplay!=kHide && m_VScrollBar && m_VScrollBar->GetVisible())
					m_VScrollBar->OnInputEvent(ptr_static_cast<Control>(this), e);

				if (e.Handled)
				{
					SetSelectedIndex(INDEX_NONE);
					Invalid();
					return;
				}
			}
			Vector2 localPos = ScreenToClient(e.CursorPosition);
			bool pointed = GetDisplayRect().IsPointInside(localPos);
			Core::Rectangle selectRect = GetDisplayRect();
			bool isSelecting = selectRect.IsPointInside(localPos);
			switch(e.Type)
			{
			case InputEventArgs::kMouseDown:
			case InputEventArgs::kMouseDoubleClick:
				{
					if(pointed || isSelecting)
						e.Handled = true;
				}
				break;
			case InputEventArgs::kMouseUp:
				{
					if (e.Code == MC_LEFT_BUTTON && isSelecting)
					{
						int newIndex = PosToIndex(localPos);
						if(newIndex!=INDEX_NONE)
						{
							SetSelectedIndex(newIndex);
							SetActiveIndex(newIndex);
						}
						OnListClick(e);
						Close();
						e.Handled = true;
					}
				}
				break;

			case InputEventArgs::kMouseMove:

				{
					if (isSelecting)
					{
						SetSelectedIndex(PosToIndex(localPos));

						e.Handled = true;
					}
				}
				break;

			case InputEventArgs::kMouseWheel:
				{
					if (!GetAutoScroll())
						e.Handled = true;
					break;
				}
				break;
			case InputEventArgs::kMouseLeave:
				{
					SetSelectedIndex(INDEX_NONE);
					Invalid();
				}
				break;
			}
		}
		if (e.IsKeyEvent())
		{
			if (e.Type == InputEventArgs::kKeyDown && e.Code == KC_ESCAPE)
			{
				sharedc_ptr(ComboBox) owner = m_ComboBox;
				if(owner)
				{
					owner->SetFocused(true);
				}
				else
				{
					LogSystem.WriteLine("Combolist without combobox?");
				}
				Close();
				e.Handled = true;
			}
		}

		if (!e.Handled)
			Super::OnInputEvent(e);

	}


	void ComboList::OnLeave( EventArgs & e )
	{
		if(m_ComboBox)
		{
			if(gGame->guiSys->GetFocusedControl() == m_ComboBox)
				return;
			else
			{
				sharedc_ptr(ComboBox) owner = m_ComboBox;
				owner->SetPushDown(false);
			}
		}
		Super::OnLeave(e);
		Close();
	}

	/// on click
	void ComboList::OnListClick(InputEventArgs & e)
	{
		EventListClick.Fire(ptr_static_cast<ComboList>(this),(EventArgs&)e);
	}
}

//--------------------------------------------------------------------------------------
// Method
//--------------------------------------------------------------------------------------
namespace Gui
{
	/// show
	void ComboList::Show()
	{
		sharedc_ptr(ComboBox) owner= m_ComboBox;
		Vector2 sizeComboBox = owner->GetSize();
		Vector2 posComboBox = owner->ClientToGlobalScreen(Vector2(0,0));

		SetParent(gGame->guiSys);
		Core::Rectangle rect = gGame->guiSys->GetDisplayRect();
		
		//Scroll to the first option
		if(GetAutoScroll())
		{
			ScrollToIndex(0);
		}

		U32 height = GetDropDownHeight();
		U32 itemsHeight = ITEM_HEIGHT * GetItemCount()+m_Border.y+m_Border.w;

		if (height == 0 || height > itemsHeight)
			height = itemsHeight;

		switch (owner->GetPopup())
		{
		case ComboBox::kPopupBottom:
			{
				Vector2 newLocation;
				if(posComboBox.y+sizeComboBox.y+height>rect.Max.y)
				{
					//top
					newLocation = posComboBox - Vector2(0, height);
				}
				else
				{
					//bottom
					newLocation = posComboBox + Vector2(0,sizeComboBox.y);
				}
				SetLocation(newLocation);
			}
			break;
		case ComboBox::kPopupTop:
			{
				Vector2 newLocation;
				if(posComboBox.y-height<rect.Min.y)
				{
					//bottom
					newLocation = posComboBox + Vector2(0, sizeComboBox.y);
				}
				else
				{
					//top
					newLocation = posComboBox - Vector2(0, height);
				}
				SetLocation(newLocation);
			}
			break;
		case ComboBox::kPopupRight:
			{
				SetLocation(posComboBox + Vector2(sizeComboBox.x,0));
			}
			break;
		}
		SetVisible(true);
	}

	///Close
	void ComboList::Close()
	{
		SetParent(NullPtr);
		SetVisible(false);
	}


	void ComboList::UpdateScreenPosition()
	{
		if(!m_Parent || !m_Visible)
			return;

		sharedc_ptr(ComboBox) owner= m_ComboBox;
		Vector2 sizeComboBox = owner->GetSize();
		Vector2 posComboBox = owner->ClientToGlobalScreen(Vector2(0,0));

		Core::Rectangle rect = gGame->guiSys->GetDisplayRect();

		U32 height = GetDropDownHeight();
		U32 itemsHeight = ITEM_HEIGHT * GetItemCount()+m_Border.y+m_Border.w;

		if (height == 0 || height > itemsHeight)
			height = itemsHeight;

		switch (owner->GetPopup())
		{
		case ComboBox::kPopupBottom:
			{
				Vector2 newLocation;
				if(posComboBox.y+sizeComboBox.y+height>rect.Max.y)
				{
					//top
					newLocation = posComboBox - Vector2(0, height);
				}
				else
				{
					//bottom
					newLocation = posComboBox + Vector2(0,sizeComboBox.y);
				}
				SetLocation(newLocation);
			}
			break;
		case ComboBox::kPopupTop:
			{
				Vector2 newLocation;
				if(posComboBox.y-height<rect.Min.y)
				{
					//bottom
					newLocation = posComboBox + Vector2(0, sizeComboBox.y);
				}
				else
				{
					//top
					newLocation = posComboBox - Vector2(0, height);
				}
				SetLocation(newLocation);
			}
			break;
		case ComboBox::kPopupRight:
			{
				SetLocation(posComboBox + Vector2(sizeComboBox.x,0));
			}
			break;
		}
	}

	/// add item
	S32 ComboList::AddItem(const String & item, bool with_icon,int index)
	{
		m_aItems.PushBack(ComboItem(item,with_icon,index));
		++m_ItemCount;

		DirtyLayout();

		return m_ItemCount - 1;
	}

	void ComboList::SetItemDisable(S32 index, bool flag)
	{
		if(index < (S32)m_ItemCount)
		{
			m_aItems[index].disabled = flag;
		}
		
	}

	/// insert item
	S32 ComboList::InsertItem(S32 index, const String & item)
	{
		m_aItems.Insert(index, ComboItem(item));
		++m_ItemCount;

		DirtyLayout();

		return index < (S32)m_ItemCount && index >= 0? index: m_ItemCount - 1;
	}

	/// remove item
	void ComboList::RemoveItem(S32 index)
	{
		if (index < (S32)m_ItemCount && index >=0)
		{
			m_aItems.RemoveAt(index);
			--m_ItemCount;

			if(m_SelectedIndex==index)
			{
				SetSelectedIndex(INDEX_NONE);
			}
			else if(m_SelectedIndex>index)
			{
				SetSelectedIndex(m_SelectedIndex-1);
			}

			if(m_ActiveIndex==index)
			{
				SetActiveIndex(INDEX_NONE);
			}
			else if(m_ActiveIndex>index)
			{
				SetActiveIndex(m_ActiveIndex-1);
			}
		}
	}

	/// move item
	void ComboList::MoveItem(S32 index, S32 newIndex)
	{
		if (index < (S32)m_ItemCount && index >= 0)
		{
			S32 moveIndex = newIndex < index? newIndex < 0? 0: newIndex: newIndex + 1;
			m_aItems.Insert(moveIndex, ComboItem(m_aItems[index]));
			index = newIndex < index? index + 1: index;
			m_aItems.RemoveAt(index);
		}
	}

	/// get id
	S32 ComboList::GetId(S32 index)
	{
		if (index < (S32)m_ItemCount && index >=0)
		{
			return m_aItems[index].Index == S32_MIN? index: m_aItems[index].Index;
		}

		return S32_MIN;
	}

	/// set id
	void ComboList::SetId(S32 index, S32 id)
	{
		if (index < (S32)m_ItemCount && index >= 0)
		{
			m_aItems[index].Index = id;
		}
	}

	/// text to index
	S32 ComboList::TextToIndex(const String & item)
	{
		for (U32 i=0; i<m_ItemCount; ++i)
		{
			if (m_aItems[i].Text == item)
				return i;
		}

		return INDEX_NONE;
	}

	/// index to text
	const String & ComboList::IndexToText(S32 index)
	{
		if (index == INDEX_NONE && m_ActiveIndex != INDEX_NONE)
		{
			return m_aItems[m_ActiveIndex].Text;
		}
		if (index < (S32)m_ItemCount && index >= 0)
		{
			return m_aItems[index].Text;
		}

		return String::kEmpty;
	}

	/// scroll to index
	void ComboList::ScrollToIndex(S32 index)
	{
		if (index >= (S32)m_ItemCount)
			return;

		Core::Rectangle rect;

		if (index < 0)
			rect = Core::Rectangle(0,0,0,0);
		else
			rect = Core::Rectangle::LeftTop(Vector2(0, ITEM_HEIGHT * index/*+m_Border.y*/), Vector2(0, ITEM_HEIGHT));

		ScrollToView(rect);
		Invalid();
	}

	int ComboList::PosToIndex( Core::Vector2 pos )
	{
		if(pos.y<0 || pos.y>GetDisplayRect().Max.y)
			return INDEX_NONE;
		int roughIndex = (pos.y-m_Border.y)/ITEM_HEIGHT;
		if(roughIndex<0 || roughIndex>=(int)GetItemCount() || m_aItems[roughIndex].disabled)
			return INDEX_NONE;
		Core::Rectangle itemRect = Rectangle::LeftTop(Vector2(0, m_Border.y+ITEM_HEIGHT * roughIndex),Vector2(GetSize().x, ITEM_HEIGHT));
		Core::Vector4 dispPadding = GetDisplayPadding();
		itemRect.Shrink(Vector4(dispPadding.x, 0, dispPadding.z, 0));
		if(itemRect.IsPointInside(pos))
			return roughIndex;
		else
			return INDEX_NONE;
	}
}