#include "pch.h"

#include <curl/curl.h>
#pragma comment(lib, "wldap32.lib" )

using namespace Core;
using namespace Client;

#define UI_SOFTWARE_PICK

namespace Gui
{
	//Override attributes
	PDE_ATTRIBUTE_SETTER(GuiSystem, Location, Vector2)
	{

	}
}

namespace Gui
{
	GuiSystem::GuiSystem()
		: bActive(false)
		, bDebugDrawUV(false)
		, m_DrawDG(false)
		, m_AvatarRotating(false)
		, m_FOV(75)
	{
		m_UseTextKey = false;

		vertex_shader = RESOURCE_LOAD("/shader/uimousehandler_vs.vd9", false, VertexShaderDx9);
		pixel_shader = RESOURCE_LOAD("/shader/uimousehandler_ps.pd9", false, PixelShaderDx9);
		texdata_1x1.CreateRenderTarget(1, 1, D3DFMT_A32B32G32R32F, D3DMULTISAMPLE_NONE, true);
		texdata_1x1.CreateDepthStencil(D3DFMT_D24S8, true);
		m_bWideScreen = gGame->camera->wide_screen_mode;
	}

	GuiSystem::~GuiSystem()
	{
	}

	void GuiSystem::OnCreate(void)
	{
		Super::OnCreate();
		DeviceCreate();

		m_AudioResouceNames.Resize(kUIA_MAX);
		m_AudioResouceNames[kUIA_lOBBY_MUSIC] = "bj/music/lobby";
		m_AudioResouceNames[kUIA_MATCH] = "bj/music/match";
		m_AudioResouceNames[kUIA_MOUSE_CLICK] = "bj/ui/mouse_click";
		m_AudioResouceNames[kUIA_BUY_SUCCESS] = "bj/ui/purchase";
		m_AudioResouceNames[kUIA_NEW_MAIL] = "bj/ui/new_mail";
		m_AudioResouceNames[kUIA_LEVEL_UP] = "bj/ui/level_up";
		m_AudioResouceNames[kUIA_CHAT_MESSAGE] = "bj/ui/new_message";
		m_AudioResouceNames[kUIA_TREASURE_BOX] = "bj/ui/treasure_box";
		m_AudioResouceNames[kUIA_CONGRA_POP] = "bj/ui/congra_pop";
		m_AudioResouceNames[kUIA_CONFIRM_MESSAGE] = "bj/ui/confirm_pop";
		m_AudioResouceNames[kUIA_GAME_WIN] = "bj/event/stage_win";
		m_AudioResouceNames[kUIA_GAME_LOSE] = "bj/event/stage_lose";

		m_AudioResouceNames[kUIA_SYSTEM_MESSAGE] = "o2o/ui/system_message";
		m_AudioResouceNames[kUIA_BALLOON] = "o2o/ui/balloon";
		m_AudioResouceNames[kUIA_WEAPON_MOD] = "o2o/ui/weapon_mod";
		m_AudioResouceNames[kUIA_TEAM_INVITED] = "o2o/ui/team_invited";
		m_AudioResouceNames[kUIA_USE_EQUIP_ITEM] = "o2o/ui/use_equip_item";

		m_AudioResouceNames[kUIA_COMPOUND_SUCCEED] = "bj/ui/compound_succeed";//ǿ�������ף���Ƕ�ɹ���Ч
		m_AudioResouceNames[kUIA_COMPOUND_FAIL] = "bj/ui/compound_fail";	  //ǿ�������ף���Ƕʧ����Ч
		m_AudioResouceNames[kUIA_COMPOUND_SUCCEED_SWF] = "bj/ui/compound_succeed_swf";//ǿ��FLASH�ɹ���Ч
		m_AudioResouceNames[kUIA_COMPOUND_FAIL_SWF] = "bj/ui/compound_fail_swf";//ǿ��FLASHʧ����Ч
		m_AudioResouceNames[kUIA_COMPOUND_SUCCEED_SWF_EX] = "bj/ui/compound_succeed_swf_ex";//ǿ��FLASHʧ����Ч
		m_AudioResouceNames[kUIA_COMPOUND_PUT] = "bj/ui/compound_put";//�ŵ���λ
		
		m_AudioResouceNames[kUIA_OPEN_SUCCEED] = "bj/ui/open_succeed";		  //�򿪴���������и߼����ؽ��ң����и߼�ǩ����к�����Ч
		m_AudioResouceNames[kUIA_LOTTERY] = "bj/ui/lottery";				  //��ħ�ޣ�vip���ᣬ���˲ʺк�����Ч
		m_AudioResouceNames[kUIA_STAGE_TURNCARD] = "bj/ui/lottery";				  //���ؽ��� ������Ч
		m_AudioResouceNames[kUIA_LAOHUJI] = "bj/ui/luckybox_roll";				  //�ϻ���

		m_AudioResouceNames[kUIA_MVPMOVE] = "bj/ui/vip_move";                 //mvp�ƶ�
		m_AudioResouceNames[kUIA_GETITEM] = "bj/ui/get_good_reward";				//�����Ʒʱ����ʾ��Ч
		m_AudioResouceNames[kUIA_OPEN_CODECASE] = "bj/ui/open_codecase";				//��������Ĺ���Ч����Ч
		m_AudioResouceNames[kUIA_USE_EXP] = "bj/ui/use_exp";				//ʹ��exp����ʱ��Ч����Ч
		m_AudioResouceNames[kUIA_USE_EXP_LEVELUP] = "bj/ui/use_exp_levelup";				//ʹ��exp����ʱ���������Ч����Ч
		m_AudioResouceNames[kUIA_USE_ITEM] = "bj/ui/use_item";				//ʹ�õ���ʱ����ʾ��Ч
		m_AudioResouceNames[kUIA_EQUIPMENT] = "bj/ui/equipment";				//�ڲֿ���װ����Ʒʱ����ʾ��Ч
		m_AudioResouceNames[kUIA_GET_GOOD_REWARD] = "bj/ui/get_good_reward";				//��������ýϺ���Ʒʱ�Ľ�����Ч
		m_AudioResouceNames[kUIA_GET_REWARD] = "bj/ui/get_reward";				//���������һ����Ʒʱ�Ľ�����Ч
		m_AudioResouceNames[kUIA_CLOSE_TIME] = "bj/ui/stage_clear_countdown";	  //���ؽ��� ������Ч
		m_AudioResouceNames[kUIA_CLEAN_UP] = "bj/ui/clean_up";	//�����ֿⰴť��Ч
		m_AudioResouceNames[kUIA_CREATE_TEAM] = "bj/ui/create_team";	//����ս�ӳɹ���Ч
		m_AudioResouceNames[kUIA_DISMISS_TEAM] = "bj/ui/dismiss_team";	//����ս��ʧ����Ч
		m_AudioResouceNames[kUIA_SEND_MAIL] = "bj/ui/send_mail";		//�����ʼ��ɹ���Ч
		m_AudioResouceNames[kUIA_COMPOUND_PUT_ITEM] = "bj/ui/compound_put_item";	//�ϳ��ز�������Ч
		m_AudioResouceNames[kUIA_MISSION_REWARD] = "bj/ui/mission_reward";	//�ϳ��ز�������Ч
		m_AudioResouceNames[kUIA_UNLOCK_MODULE] = "bj/ui/unlock_module";	//�ϳ��ز�������Ч
		m_AudioResouceNames[kUIA_POKERCARD_TRUN] = "bj/ui/pokercard_turn";	//���ؽ��㷭����Ч
		m_AudioResouceNames[kUIA_CLOSE_UI] = "bj/ui/close_ui";				//�����л���Ч
		m_AudioResouceNames[kUIA_CLOSE_UI2] = "bj/ui/close_ui_2nd";				//�����л���Ч
		m_AudioResouceNames[kUIA_USE_MONEY] = "bj/ui/use_money";			//ʹ��Ǯ������Ч
		m_AudioResouceNames[kUIA_STORAGE] = "bj/music/storage";				//ʹ�òֿ⣬�ϳɽ��汳������
		m_AudioResouceNames[kUIA_SHOOTING_ON_HIT] = "bj/ui/shot_target";	//���й��ӵ���Ч
		m_AudioResouceNames[kUIA_FUSION_START] = "bj/ui/fusion";			//���й��ӵ���Ч
		m_AudioResouceNames[kUIA_FUSION_LOOK] = "bj/ui/fusion_check";		//���й��ӵ���Ч
		m_AudioResouceNames[kUIA_PUZZLE_COMPLETE] = "bj/ui/puzzle_complete";	//ƴͼ���ʱ������
		m_AudioResouceNames[kUIA_PUZZLE_MATCH] = "bj/ui/puzzle_match";			//ƴͼ��Ƭ�ƶ���ƴͼ��ʱ������
		m_AudioResouceNames[kUIA_PUZZLE_MOVE] = "bj/ui/bj/ui/puzzle_move";		//ƴͼ��Ƭ�ƶ�ʱ������

	}

	void GuiSystem::OnDestroy(void)
	{
		DeviceDestory();
		Super::OnDestroy();
	}

	void GuiSystem::UpdateVirtualSize()
	{
		//Camera
		F32 fov = m_FOV;
		F32 screenSizeX = gGame->screen->GetSize().x;
		F32 screenSizeY = gGame->screen->GetSize().y;

		if (gGame->config->GetUIVirtualSize() > 0)
		{
			screenSizeX = gGame->config->GetUIVirtualSize() * screenSizeX / screenSizeY;
			screenSizeY = gGame->config->GetUIVirtualSize();
		}

		SetSize(Vector2(screenSizeX, screenSizeY));
		gRender->font_manager->SetFontScale(gGame->screen->GetSize().y / screenSizeY);
#ifdef USE_WEB
		WebPlayer::SetScale(gGame->screen->GetSize().y / screenSizeY);
#endif

		Client::Camera camera;
		camera.position = Vector3(screenSizeX/2, screenSizeY/2, Core::Ctan(fov/2*DEG2RAD)*screenSizeX/2);
		camera.fov = fov;
		camera.aspect = screenSizeX/screenSizeY;
		camera.SetNear(0.05f);
		camera.SetFar(Core::Ctan(fov/2*DEG2RAD)*screenSizeX/2 *4);
		camera.rotation.SetIdentity();
		camera.CalculateViewProjectionMatrix(m_ViewMatrix, m_ProjMatrix);
		m_ViewMatrix.Scale(Vector3(1, -1, 1));

		for (tempc_ptr(Control) control = GetFirstChild(); control; control = control->GetNext())
		{
			control->Invalid();
			control->DirtyLayout();
		}
	}


	void GuiSystem::DeviceCreate()
	{
		DeviceReset();
	}

	void GuiSystem::DeviceReset()
	{
		if(!m_WinGlowTexture)
			m_WinGlowTexture = RESOURCE_LOAD_NEW("skinD/skinD_window_ray.tga", false, Texture2D);

		UpdateVirtualSize();
	}

	void GuiSystem::DeviceLost()
	{
	}

	void GuiSystem::DeviceDestory()
	{
	}

	PDE_ATTRIBUTE_SETTER(GuiSystem, FocusedControl, sharedc_ptr(Control))
	{
		ChangeFocusedControl(value);
	}
	PDE_ATTRIBUTE_GETTER(GuiSystem, FocusedControl, sharedc_ptr(Control))
	{
		sharedc_ptr(Control) pControl(m_FocusedControl);
		if(pControl)
			return pControl;
		else
		{
			m_FocusedControl = NullPtr;
			return NullPtr;
		}
	}

	PDE_ATTRIBUTE_GETTER(GuiSystem, PointedControl, sharedc_ptr(Control))
	{
		sharedc_ptr(Control) pControl(m_PointedControl);
		if(pControl)
			return pControl;
		else
		{
			m_PointedControl = NullPtr;
			return NullPtr;
		}
	}

	void GuiSystem::OnFocusControlChanged(FocusEventArgs & e)
	{
	}

	bool GuiSystem::ChangeFocusedControl( tempc_ptr(Control) pValue )
	{
		if(m_FocusedControl == pValue)
			return false;

		if(pValue && !pValue->GetCanFocus())
			return false;

		sharedc_ptr(Control) pFocusedControl(m_FocusedControl);
		m_FocusedControl = pValue;

		if(pFocusedControl)
			pFocusedControl->OnFocusChanged(ValueChangeEventArgs());

		bool bHandled = ChangeFocusedLine(pFocusedControl, pValue);
		if(pValue)
			pValue->OnFocusChanged(ValueChangeEventArgs());
		return bHandled;
	}

	bool GuiSystem::ChangeFocusedLine( tempc_ptr(Control) pFrom, tempc_ptr(Control) pTo )
	{
		bool bHandled = false;

		Core::StaticArray<tempc_ptr(Control), 32> oldFocusedLine;
		Core::StaticArray<tempc_ptr(Control), 32> newFocusedLine;

		tempc_ptr(Control) itrControl = pFrom;
		while (itrControl)
		{
			oldFocusedLine.PushBack(itrControl);
			itrControl = itrControl->GetParent();
		}

		itrControl = pTo;
		while (itrControl)
		{
			newFocusedLine.PushBack(itrControl);
			itrControl = itrControl->GetParent();
		}

		// remove same controls
		while (	!oldFocusedLine.Empty() &&
			!newFocusedLine.Empty() &&
			oldFocusedLine.Back() == newFocusedLine.Back())
		{
			oldFocusedLine.PopBack();
			newFocusedLine.PopBack();
		}

		// send leave message
		for (U32 i = 0; i < oldFocusedLine.Size(); i++)
		{
			if (oldFocusedLine[i])
			{
				oldFocusedLine[i]->OnLeave(Core::EventArgs());
			}
		}

		// send enter message
		for (U32 i = 0; i < newFocusedLine.Size(); i++)
		{
			tempc_ptr(Control) back = newFocusedLine.Back(i);
			if (back)
			{
				Core::EventArgs e;
				back->OnEnter(e);

				if (e.Handled)
					bHandled = true;

				tempc_ptr(Control) pParent = back->GetParent();
				if (pParent)
				{
					FocusEventArgs focusEvent;
					focusEvent.Control = back;
					pParent->OnFocusControlChanged(focusEvent);
				}
			}
		}

		return bHandled;
	}

	void GuiSystem::UpdateFocusedLine( tempc_ptr(Control) pControl )
	{

	}

	void GuiSystem::SetCaptureControl( tempc_ptr(Control) pControl, bool bCapture )
	{
		if(pControl)
		{
			if(bCapture)
			{
				if(!pControl == m_CaptureControl)
					m_CaptureControl = pControl;
			}
			else
			{
				if(pControl == m_CaptureControl)
					m_CaptureControl = NullPtr;
			}
		}
		else
		{
			m_CaptureControl = NullPtr;
		}

		if(m_CaptureControl)
		{
			AccquireCapture();
		}
		else
		{
			ReleaseCapture();
		}
	}

	tempc_ptr(Control) GuiSystem::GetCaptureControl()
	{
		sharedc_ptr(Control) pControl(m_CaptureControl);
		if(pControl)
			return pControl;
		else
		{
			m_CaptureControl = NullPtr;
			return NullPtr;
		}
	}

	void GuiSystem::AccquireCapture()
	{
		::SetCapture(gGame->screen->GetHWND());
	}

	void GuiSystem::ReleaseCapture()
	{
		::ReleaseCapture();
	}

	void GuiSystem::Render(by_ptr(UIRender) renderer)
	{
		PROFILE("GuiSystem::Render");

		renderer->SetWorld(Matrix44::kIdentity);
		renderer->SetView(m_ViewMatrix);
		renderer->SetProjection(m_ProjMatrix);
		renderer->SetVirtualViewport(Core::Rectangle(Vector2::kZero, GetSize()));
		renderer->SetScissorRect(Core::Rectangle(Vector2::kZero, GetSize()));

		if (renderer->BeginDraw(gGame->dx9->render_target, gGame->dx9->depth_stencil))
		{
			for (tempc_ptr(Control) control = GetFirstChild(); control; control = control->GetNext())
			{
				if (control->GetVisible())
				{
					Gui::RenderEventArgs arg;
					arg.render = renderer;
					arg.Enable = true;
					arg.BackgroundColor = ARGB(0, 0, 0, 0);
					arg.Offset = Vector2::kZero;

					renderer->SetWorld(Matrix44::kIdentity);
					renderer->SetView(m_ViewMatrix);
					renderer->SetProjection(m_ProjMatrix);
					renderer->SetVirtualViewport(Core::Rectangle(Vector2::kZero, GetSize()));
					renderer->SetScissorRect(Core::Rectangle(Vector2::kZero, GetSize()));

					control->Render(arg);
				}
			}

			renderer->EndDraw();
		}

		//Draw the dirty glass
		if(m_DrawDG)
		{
			if ((m_bWideScreen != gGame->camera->wide_screen_mode) || (!m_dgTexture))
			{
				m_bWideScreen = gGame->camera->wide_screen_mode;

				if (m_bWideScreen)
					m_dgTexture = RESOURCE_LOAD_NEW("skinD/BG/bg_dirt_1280x800.tga", false, Texture2D);
				else
					m_dgTexture = RESOURCE_LOAD_NEW("skinD/BG/bg_dirt_1280.tga", false, Texture2D);
			}
			renderer->SetWorld(Core::Matrix44::kIdentity);
			renderer->SetView(m_ViewMatrix);
			renderer->SetProjection(m_ProjMatrix);
			renderer->SetVirtualViewport(Core::Rectangle(Vector2::kZero, GetSize()));
			renderer->SetScissorRect(Core::Rectangle::kInvalid);
			renderer->SetTexture(m_dgTexture);
			renderer->DrawRectangle(GetClientRect(), Core::Rectangle(0, 0, 1, 1));
		}

		renderer->SetScissorRect(Core::Rectangle::kInvalid);
		//renderer->DrawLine2d(Vector2(-10,-10), Vector2(-5,-5),ARGB(0,0,0,0));

		return;
	}

	void GuiSystem::OnScreenInput( Client::InputEventArgs& e )
	{

		if(e.IsKeyEvent())
		{
			sharedc_ptr(Control) pControl(m_FocusedControl);
			if(pControl)
			{
				pControl->OnInputEvent(e);
			}
			else
			{
				m_FocusedControl = NullPtr;
				this->OnInputEvent(e);
			}
		}

		if(e.IsMouseEvent())
		{
			m_newCursorShape = Screen::kCursorCount;
			//hover
			if(e.Type!=InputEventArgs::kMouseMove)
			{
				if(e.Type==InputEventArgs::kMouseUp)
				{
					PlayAudio(kUIA_MOUSE_CLICK);
				}
				int nothing=0;
				if(e.Type!=InputEventArgs::kMouseDown)
				{
					int noghting = 0;
				}
				else
				{
					int nothing = 0;
				}
			}
			Vector2	windowLocalPos;
			sharedc_ptr(Control) captureControl = GetCaptureControl();
			sharedc_ptr(Control) pointedControl = captureControl;

			if(captureControl)
			{
				tempc_ptr(Control) rootControl = captureControl->GetRoot();
				if(rootControl)
				{
					GetWindowAndPos(e.CursorPosition, windowLocalPos, rootControl);
				}
				else
				{
					if(ptr_dynamic_cast<GuiSystem>(captureControl))
					{
						//capture control is guisystem itself
						windowLocalPos.x=0;
						windowLocalPos.y=0;
					}
					else
					{
						captureControl->SetCapture(false);
						return;
					}
					
				}
			}
			else
			{

				tempc_ptr(Control) pRoot = GetWindowAndPos(e.CursorPosition, windowLocalPos);
				if(pRoot)
					pointedControl = pRoot->ControlFromLocation(windowLocalPos);
				else
					pointedControl = ptr_static_cast<Control>(this);
			}

			InputEventArgs dupE(e);
			dupE.CursorPosition = windowLocalPos;

			// set pointed control
			{
				sharedc_ptr(Control) oldPointedControl = m_PointedControl;

				if (oldPointedControl != pointedControl)
				{
					m_PointedControl = pointedControl;

					InputEventArgs argLeave(dupE);
					InputEventArgs argEnter(dupE);

					if (oldPointedControl)
					{
						argLeave.Type = InputEventArgs::kMouseLeave;
						oldPointedControl->OnInputEvent(argLeave);

						tempc_ptr(Window) oldWindow = ptr_dynamic_cast<Window>(oldPointedControl->GetRoot());
						if(oldWindow && oldWindow!=oldPointedControl)
						{
							argLeave.Type = InputEventArgs::kMouseLeave;
							oldWindow->OnMouseLeave(argLeave);
						}
					}

					if (pointedControl)
					{
						tempc_ptr(Window) newWindow = ptr_dynamic_cast<Window>(pointedControl->GetRoot());
						if(newWindow && newWindow!=pointedControl)
						{
							argEnter.Type = InputEventArgs::kMouseEnter;
							newWindow->OnMouseEnter(argEnter);
						}


						argEnter.Type = InputEventArgs::kMouseEnter;
						pointedControl->OnInputEvent(argEnter);
					}
				}
			}

			if(dupE.Type == InputEventArgs::kMouseMove)
			{
				//Mouse move event
				if(captureControl)
				{
					if(captureControl->GetEnable())
					{
						captureControl->OnInputEvent(dupE);
					}
				}
				else
				{
					if(pointedControl)
						pointedControl->OnInputEvent(dupE);
				}
			}
			else if(dupE.Type == InputEventArgs::kMouseWheel && m_FocusedControl)
			{
				//Focused control get mouse wheel event, like combolist
				sharedc_ptr(Control) focusedControl = m_FocusedControl;
				if(focusedControl)
					focusedControl->OnInputEvent(dupE);
			}
			else if(pointedControl)
			{
				//Mouse click event
				if(captureControl)
				{
					if(captureControl->GetEnable())
					{
						captureControl->OnInputEvent(dupE);
					}
				}

				if(!dupE.Handled)
				{
					//Mouse up does not change focus
					if (dupE.Type == InputEventArgs::kMouseDown ||
// 						dupE.Type == InputEventArgs::kMouseUp ||
						dupE.Type == InputEventArgs::kMouseDoubleClick)
					{
						if(ChangeFocusedControl(pointedControl))
							return;
					}
					if(pointedControl->GetEnable())
						pointedControl->OnInputEvent(dupE);
				}
			}

			if(m_newCursorShape==Screen::kCursorCount)
			{
				ActuallySetCursorShape(Screen::kCursorArrow);
			}
			else
			{
				ActuallySetCursorShape(m_newCursorShape);
			}
		}
	}

	void GuiSystem::OnSizeChangedAdd()
	{
		EventSizeChangedAdd.Fire(ptr_static_cast<GuiSystem>(this), (Core::EventArgs &)NullPtr);
	}
	tempc_ptr(Control) GuiSystem::GetWindowAndPosSoft( const Core::Vector2 & pos, Core::Vector2 & outLocalPos, tempc_ptr(Control) lockToThisWindow /*= NullPtr*/ )
	{
		tempc_ptr(Control) outWindow = NullPtr;
		outLocalPos = Vector2::kZero;
		for (tempc_ptr(Control) control = GetFirstChild(); control; control = control->GetNext())
		{
			if (!control->GetVisible())
				continue;
			if(!control->GetEnable())
				continue;

			tempc_ptr(Control) pCurrentWindow = control;

			if(lockToThisWindow)
			{
				if(pCurrentWindow != lockToThisWindow)
				{
					continue;
				}
			}

			{
				Vector2 localPos = gGame->screen->ScreenToClient(pos);
				Vector2 screenSize = gGame->screen->GetSize();
				F32 scale = gGame->config->GetUIVirtualSize()/screenSize.y;
				localPos*=scale;
				screenSize*= scale;
				F32 zPos = Core::Ctan(m_FOV/2*DEG2RAD)*screenSize.x/2;

				tempc_ptr(Window) asWindow = ptr_dynamic_cast<Window>(pCurrentWindow);
				Vector3 ControlPosi(pCurrentWindow->GetLocation());
				Vector3 ControlRotate(Vector3::kZero);
				if(asWindow)
				{
					ControlPosi = asWindow->GetWorldLocation();
					ControlRotate = asWindow->GetWorldRotation();
				}
				
				Vector2 ControlSize = GetSize();
				
				Matrix44 ControlMatrix;
				ControlMatrix.SetRotationQuaternion(Quaternion(ControlRotate.y, ControlRotate.x, ControlRotate.z));
				ControlMatrix.Translate(ControlPosi);


				///input data
				Vector3 mousePosi = Vector3(localPos.x, localPos.y, 0.f);
 				Vector3 eyePosi = Vector3(screenSize.x / 2.f, screenSize.y / 2.f, zPos); //667.2514f);

				Vector3 controlLeftTop = Vector3(0.f, 0.f, 0.f);
				Vector3 controlNormal = Vector3(0, 0, 1);

				TransformCoord(controlLeftTop, controlLeftTop, ControlMatrix);
				TransformNormal(controlNormal, controlNormal, ControlMatrix);

				Vector3 intersectionPosi;// = Vector3.kZero;

				Plane3d controlPlane = Plane3d(controlLeftTop, controlNormal);
				bool flag = controlPlane.GetIntersectionWithLine(eyePosi, mousePosi - eyePosi, intersectionPosi);
				
				if(flag)
				{

					Inverse(ControlMatrix, ControlMatrix);
					TransformCoord(intersectionPosi, intersectionPosi, ControlMatrix);
					
					Core::Rectangle clientRect = Core::Rectangle::LeftTop(Vector2::kZero, pCurrentWindow->GetSize());
					if(clientRect.IsPointInside(intersectionPosi) || lockToThisWindow)
					{
						outWindow = pCurrentWindow;
						outLocalPos = Vector2(intersectionPosi);
					}
				}				
			}
		}

		return outWindow;
	}

	tempc_ptr(Control) GuiSystem::GetWindowAndPosHard(const Core::Vector2 & pos, Core::Vector2 & outLocalPos, tempc_ptr(Control) lockToThisWindow)
	{
		if (gGame->dx9->IsDeviceLost())
		{
			outLocalPos.x = 0;
			outLocalPos.y = 0;
			return NullPtr;
		}

		//extend the window to 'extentTimes' times, only used in lockToThisWindow case.
		//100 should be enough. Even for 1920*1080, the window is already smaller than 20*10
		float extentTimes = 5;

		const F32 screenSizeX = gGame->screen->GetSize().x;
		const F32 screenSizeY = gGame->screen->GetSize().y;

		Vector2 localPos2d = gGame->screen->ScreenToClient(pos);

		//Write render target pixel value precisely to avoid data format conversion in D3DDevice->Clear (May still need Clear to clear Z)
		D3DLOCKED_RECT lc;
		if (!texdata_1x1.GetSurface())
		{
			return NullPtr;
		}
		if (SUCCEEDED(texdata_1x1.GetSurface()->LockRect(&lc, NULL, 0)))
		{
			//D3DFMT_A32B32G32R32F
			memset(lc.pBits, 0, 16);
			texdata_1x1.GetSurface()->UnlockRect();
		}
		else
		{
			outLocalPos.x = 0;
			outLocalPos.y = 0;
			return NullPtr;
		}

		//BeginDraw
		gDx9Device->SetRenderTarget(0, texdata_1x1.GetSurface());
 		gDx9Device->SetDepthStencilSurface(NULL);

		gDx9Device->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);
		gDx9Device->SetRenderState(D3DRS_ZENABLE, FALSE);
		gDx9Device->SetRenderState(D3DRS_ZWRITEENABLE, FALSE);
		gDx9Device->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
		gDx9Device->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
		gDx9Device->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);
		gDx9Device->SetRenderState(D3DRS_SCISSORTESTENABLE, FALSE);
		
		vertex_shader->SetShader();
		pixel_shader->SetShader();

		//Calculate matrices
		Matrix44 matProj = m_ProjMatrix;
		matProj.TranslateXYZ(-localPos2d.x / screenSizeX * 2, localPos2d.y / screenSizeY * 2, 0);
		gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_VIEW, m_ViewMatrix);
		gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_PROJ, matProj);
		gDx9Device->SetVertexDeclaration(VD::GetVertexDeclaration(VertexDeclaration::kUI));

		//Debug check render target pixel
		if (!texdata_1x1.GetSurface())
		{
			return NullPtr;
		}
		if (SUCCEEDED(texdata_1x1.GetSurface()->LockRect(&lc, NULL, 0)))
		{
			float dataR = *((float*)lc.pBits+0);
			texdata_1x1.GetSurface()->UnlockRect();
		}
		//End debug

		gDx9Device->BeginScene();

		for (tempc_ptr(Control) control = GetFirstChild(); control; control = control->GetNext())
		{
			if (!control->GetVisible())
				continue;
			if(!control->GetEnable())
				continue;

			tempc_ptr(Control) pCurrentWindow = control;

			if(lockToThisWindow)
			{
				if(pCurrentWindow != lockToThisWindow)
				{
					continue;
				}
			}

			const F32 windowSizeX = pCurrentWindow->GetSize().x;
			const F32 windowSizeY = pCurrentWindow->GetSize().y;

			Matrix44 matLocalToWorld;
			matLocalToWorld.SetIdentity();
			tempc_ptr(Window) pCastWindow = ptr_dynamic_cast<Window>(pCurrentWindow);
			if(pCastWindow)
			{
				Vector3 windRotation(pCastWindow->GetWorldRotation());				
				matLocalToWorld.SetRotationQuaternion(Quaternion(windRotation.y, windRotation.x, windRotation.z));
				matLocalToWorld.Translate(pCastWindow->GetWorldLocation());
			}
			else
			{
				matLocalToWorld.SetTranslationXYZ(pCurrentWindow->GetLocation().x, pCurrentWindow->GetLocation().y, 0);
			}

			gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_WORLD, matLocalToWorld);
			U32 buff[4] = {(U32)(pCurrentWindow.ToPointer()), 0, 0, 0 };
			gDx9Device->SetPixelShaderConstantF(PS_CONSTANT_CUSTOM_F1, (F32*)buff);

			if(pCastWindow && pCastWindow->GetSurfaceType() == Window::kCylinder)
			{
				//Begin TriangleList
				Core::Array<DrawingVertex> vertices;
				vertices.Reserve(180);

				int k = 30;
				for (int i = 0; i < k; i ++)
				{
					Core::Color4 color(1, 1, 1, 1);

					float x1 = i * k;
					float x2 = i * k + k;
					float y1 = 0;
					float y2 = windowSizeY;

					float u1 = i / (float)k;
					float v1 = 0;
					float u2 = (i+1) / (float)k;
					float v2 = 1;

					float z1 = -Sin(i * DEG2RAD * 6) * 100;
					float z2 = -Sin((i + 1) * DEG2RAD * 6) * 100;

					vertices.PushBack(DrawingVertex(x1, y1, z1, u1, v1, color));
					vertices.PushBack(DrawingVertex(x2, y1, z2,	u2, v1, color));
					vertices.PushBack(DrawingVertex(x1, y2, z1, u1, v2, color));

					vertices.PushBack(DrawingVertex(x2, y1, z2,	u2, v1, color));
					vertices.PushBack(DrawingVertex(x1, y2, z1, u1, v2, color));
					vertices.PushBack(DrawingVertex(x2, y2, z2, u2, v2, color));
				}
				//Trianglelist End
				gDx9Device->SetVertexDeclaration(VD::GetVertexDeclaration(VertexDeclaration::kUI));
				gDx9Device->DrawPrimitiveUP(D3DPT_TRIANGLELIST, 60, vertices.GetData(), sizeof(DrawingVertex));
				vertices.Resize(0);
			}
			else if( (pCastWindow && pCastWindow->GetSurfaceType() == Window::kPlane) || control )
			{
				//Begin TriangleList
				Core::Array<DrawingVertex> vertices;
				vertices.Reserve(6);

				float x1, x2, y1, y2, z;
				if(!lockToThisWindow)
				{
					x1 = 0;
					x2 = windowSizeX;
					y1 = 0;
					y2 = windowSizeY;
					z  = 0;
				}
				else
				{
					x1 = -windowSizeX*extentTimes/2;
					x2 = windowSizeX*extentTimes/2;
					y1 = -windowSizeY*extentTimes/2;
					y2 = windowSizeY*extentTimes/2;
					z  = 0;
				}
				float u1 = 0;
				float u2 = 1;
				float v1 = 0;
				float v2 = 1;					
				ARGB color;
				color.argb = (U32)pCurrentWindow.ToPointer();

				vertices.PushBack(DrawingVertex(x1, y1, z, u1, v1, color));
				vertices.PushBack(DrawingVertex(x2, y1, z, u2, v1, color));
				vertices.PushBack(DrawingVertex(x1, y2, z, u1, v2, color));

				vertices.PushBack(DrawingVertex(x2, y1, z,	u2, v1, color));
				vertices.PushBack(DrawingVertex(x1, y2, z, u1, v2, color));
				vertices.PushBack(DrawingVertex(x2, y2, z, u2, v2, color));

				gDx9Device->SetVertexDeclaration(VD::GetVertexDeclaration(VertexDeclaration::kUI));
				gDx9Device->DrawPrimitiveUP(D3DPT_TRIANGLELIST, 2, vertices.GetData(), sizeof(DrawingVertex));
				vertices.Resize(0);
			}
		}

		gDx9Device->EndScene();

		bDebugDrawUV = false;

		if (!texdata_1x1.GetSurface())
		{
			return NullPtr;
		}

		if (SUCCEEDED(texdata_1x1.GetSurface()->LockRect(&lc, NULL, 0)))
		{
			float dataR = *((float*)lc.pBits+0);
			float dataG = *((float*)lc.pBits+1);
			Control* dataB = *((Control**)lc.pBits+2);
			texdata_1x1.GetSurface()->UnlockRect();
			
			Control* pMouseWindow = dataB;
			if(!pMouseWindow)
			{
				outLocalPos.x = 0;
				outLocalPos.y = 0;
				return NullPtr;
			}

			if(!lockToThisWindow)
			{
				outLocalPos.x = Core::Ceil(dataR * pMouseWindow->GetSize().x+0.5);
				outLocalPos.y = Core::Ceil(dataG * pMouseWindow->GetSize().y+0.5);
			}
			else
			{
				PDE_ASSERT(pMouseWindow == lockToThisWindow.ToPointer(), "Error: Captured window message error");
				outLocalPos.x = Core::Ceil((dataR-0.5)*extentTimes * pMouseWindow->GetSize().x+0.5);
				outLocalPos.y = Core::Ceil((dataG-0.5)*extentTimes * pMouseWindow->GetSize().y+0.5);
			}

			return ptr_static_cast<Control>(pMouseWindow);
		}
		outLocalPos.x = 0;
		outLocalPos.y = 0;
		return NullPtr;
	}


	tempc_ptr(Control) GuiSystem::GetWindowAndPos( const Core::Vector2 & pos, Core::Vector2 & outLocalPos, tempc_ptr(Control) lockToThisWindow /*= NullPtr*/ )
	{
#ifdef UI_SOFTWARE_PICK
		return GetWindowAndPosSoft(pos, outLocalPos, lockToThisWindow);
#else
		return GetWindowAndPosHard(pos, outLocalPos, lockToThisWindow);
#endif
	}

	void GuiSystem::Update( void )
	{
		// frame update
		for (Control * control = this; control; control = control->GetNextNode())
			control->OnFrameUpdate(EventArgs());

		// update layout
		for (Control * control = this; control; control = control->GetNextNode())
			control->UpdateLayout();
	}
}

namespace Gui
{
	// control style changed
	void GuiSystem::OnControlStyleChanged(StyleChangeEventArgs & e)
	{
		EventControlStyleChanged.Fire(ptr_static_cast<GuiSystem>(this), e);
	}

	// language changed
	void GuiSystem::OnLanguageChanged(EventArgs & e)
	{
		for (tempc_ptr(Control) control = GetFirstChild(); control; control = control->GetNext())
		{
			control->OnLanguageChanged(e);
		}
	}

	void GuiSystem::OnInputEvent( InputEventArgs & e )
	{
		if (e.IsKeyEvent())
		{
			if (e.Type == InputEventArgs::kKeyDown && e.Code == KC_ESCAPE)
			{
				EventEscPressed.Fire(ptr_static_cast<GuiSystem>(this), e);
				e.Handled = true;
			}
			else if (gGame->config->IsActionDown(kActionUIPack))
			{
				if(gLevel->game_type == RoomOption::kNovice && gLevel->room_option.character_id > 0)
				{
					e.Handled = true;
					return;
				}
/*				else if(gLevel->game_type == RoomOption::kTeamDeathMatch || gLevel->game_type == RoomOption::kBoss)
				{

					if(gLevel && gLevel->GetPlayer())
					{
						if(gLevel->GetPlayer()->IsDied() || gLevel->round_start_wait_time > 0.f)
						{
							EventChangeState.Fire(ptr_static_cast<GuiSystem>(this), e);
							e.Handled = true;
						}		
					}
					

					e.Handled = true;
					return;				

				}	*/	

				EventChangeState.Fire(ptr_static_cast<GuiSystem>(this), e);
				e.Handled = true;
			}
			else if (gGame->config->IsActionDown(kActionUIWeaponPack))
			{
				if(gLevel->game_type == RoomOption::kEditMode)
				{
					e.Handled = true;
					EventChangeState.Fire(ptr_static_cast<GuiSystem>(this), e);
				}
			}
		}

		if(e.IsMouseEvent())
		{
			if(e.Type!=InputEventArgs::kMouseMove)
			{
				int nothing=0;
			}
			
			/*switch(e.Type)
			{
			case InputEventArgs::kMouseDown:
				{
					if(gGame)
					{
						Vector2 clientPos = gGame->screen->ScreenToClient(e.CursorScreenPosition);
						if(gGame->render)
							if(gGame->render->GetLobby())
							{
								LobbyPipeline::PickType resultType = LobbyPipeline::kPickNone;
								resultType = gGame->render->GetLobby()->Pick(clientPos, InputEventArgs::kMouseDown);
								if(resultType == LobbyPipeline::kPickCharChged)
								{
									OnAvatarSwitched();	
								}
								else if(resultType == LobbyPipeline::kPickCharRot)
								{
									m_AvatarRotating = true;
									SetCursorShape(Screen::kCursorRotate);
								}
								else if(resultType == LobbyPipeline::kPickModifyWeapon)
								{
									m_AvatarRotating = true;
									SetCursorShape(Screen::kCursorRotate);
								}
							}
					}
					SetCapture(true);
					e.Handled = true;
				}
				break;
			case InputEventArgs::kMouseUp:
				{
					if(gGame)
					{
						Vector2 clientPos = gGame->screen->ScreenToClient(e.CursorScreenPosition);
						if(gGame->render)
							if(gGame->render->GetLobby())
								gGame->render->GetLobby()->Pick(clientPos, InputEventArgs::kMouseUp);
					}
					m_AvatarRotating = false;
					SetCapture(false);
					e.Handled = true;
				}
				break;
			case InputEventArgs::kMouseMove:
				{
					if(gGame)
					{
						Vector2 clientPos = gGame->screen->ScreenToClient(e.CursorScreenPosition);
						if(gGame->render)
							if(gGame->render->lobby_pipeline)
							{
								LobbyPipeline::PickType resultType = LobbyPipeline::kPickNone;
								resultType = gGame->render->GetLobby()->Pick(clientPos, InputEventArgs::kMouseMove);
								gGame->render->lobby_pipeline->UpdateCursor(clientPos);
								if(GetCapture() && m_AvatarRotating)
								{
									SetCursorShape(Screen::kCursorRotate);
								}
								else
								{
									switch(resultType)
									{
									case LobbyPipeline::kPickCharChg:
										SetCursorShape(Screen::kCursorSwitch);
										break;
									case LobbyPipeline::kPickCharRot:
										SetCursorShape(Screen::kCursorRotate);
										break;
									case LobbyPipeline::kPickModifyWeapon:
										SetCursorShape(Screen::kCursorRotate);
										break;
									case LobbyPipeline::kPickNone:
										SetCursorShape(Screen::kCursorArrow);
										break;
									}
								}
							}
					}
					e.Handled = true;
				}
				break;
			default:
				break;
			}*/
		}
		if(!e.Handled)
			Super::OnInputEvent(e);
	}

	void GuiSystem::ShowMessage( const Core::String& errorMsg )
	{
		MessageEventArgs args;
		args.Message = errorMsg;
		EventShowMessage.Fire(ptr_static_cast<GuiSystem>(this), args);
	}


	void GuiSystem::ShowIE()
	{	
		String result = gHttpConfig.http_pay_set.Get(gGame->account_type, "");
		
		if(result != "")
		{
			ShellExecuteA(NULL, "open", "iexplore.exe", result.Str(), NULL, SW_SHOW);
		}
		else
		{
			result = gHttpConfig.http_pay_set.Get(1, "");
			if(result != "")
			{
				ShellExecuteA(NULL, "open", "iexplore.exe", result.Str(), NULL, SW_SHOW);
			}
		}
	}

	void GuiSystem::ShowFCM()
	{	
		if(gHttpConfig.http_fcm != "")
		{
			ShellExecuteA(NULL, "open", "explorer.exe",gHttpConfig.http_fcm, NULL, SW_SHOW);
		}
		
	}
	void GuiSystem::ShowGW()
	{
		if(gHttpConfig.http_gw != "")
		{
			ShellExecuteA(NULL, "open", "explorer.exe",gHttpConfig.http_gw, NULL, SW_SHOW);
		}

	}
	void GuiSystem::SetFaceBookData(const Core::String& mark)
	{
		char md5calcbuffer[2048] ={0};
		char bufMD5[1024] = {0};
		char buf[1024] = {0};

		gFaceBookInterface.mark = mark;
		gFaceBookInterface.userid = g_InGameInfo_collection.account;
		gFaceBookInterface.time = Core::String::Format("%u",Task::GetTotalTime());

		sprintf_s(buf, sizeof(buf), "%s%s%s%s%s", gFaceBookInterface.key, gFaceBookInterface.secret, gFaceBookInterface.mark, gFaceBookInterface.userid, gFaceBookInterface.time);
		strcat_s(md5calcbuffer, sizeof(md5calcbuffer), buf);

		int len = strlen(md5calcbuffer);
		MD5::ReadBuf2MD5Low(md5calcbuffer, len, bufMD5, sizeof(bufMD5));

		gFaceBookInterface.sign = Core::String::Format("%s", bufMD5);

		if (gGame->HttpFaceBook() == -1)
		{
			LogSystem.WriteLinef("facebookerr");
		}
	}

	void GuiSystem::ActuallySetCursorShape(Client::Screen::CursorShape shape)
	{
		if (gGame && gGame->screen)
			gGame->screen->SetCursorShape(shape);
	}

	void GuiSystem::TrySetCursorShape( Client::Screen::CursorShape shape )
	{
		m_newCursorShape = shape;
	}

	void GuiSystem::PlayAudio( UIAudioEnum audio )
	{
		if (audio>=0 && audio<kUIA_MAX)
		{
			FmodSystem::PlayEvent(m_AudioResouceNames[audio]);
		}
	}

	const Core::String& GuiSystem::GetAudioResourceName( UIAudioEnum audio )
	{
		if(audio>=0 && audio<kUIA_MAX)
			return m_AudioResouceNames[audio];
		else
			return Core::String::kEmpty;
	}

	void GuiSystem::OnAvatarSwitched()
	{
		EventAvatarSwitched.Fire(ptr_static_cast<GuiSystem>(this), Core::EventArgs());
	}

	bool GuiSystem::GetVisibility()
	{
		return true;
	}

	tempc_ptr(CharacterSlot) GuiSystem::GetActiveCharSlot()
	{
		return m_ActiveCharSlot;
	}
	void GuiSystem::SetActiveCharSlot(tempc_ptr(CharacterSlot) slot, bool bActive)
	{
		if(slot)
		{
			if(slot == m_ActiveCharSlot)
			{
				if(!bActive)
				{
					m_ActiveCharSlot = NullPtr;
				}
			}
			else
			{
				if(bActive)
				{
					m_ActiveCharSlot = slot;
				}
			}
		}
	}

	void GuiSystem::SetAllCharPlatesClickable( bool bClickable )
	{
		if(m_CharPlatesPool.Size()>0)
		{
			HashSet<U32, sharedc_ptr(CharacterPlate)>::Enumerator it(m_CharPlatesPool);
			while(it.MoveNext())
			{
				if(it.Value())
				{
					it.Value()->SetClickable(bClickable);
				}
			}
		}
	}

	void GuiSystem::RearrangeChildren()
	{
		bool Rearranged = false;
		Core::Array<sharedc_ptr(Control)> topLayerControls;
		for (tempc_ptr(Control) t = GetFirstChild(); t; t = t->GetNext())
		{
			tempc_ptr(ModalControl) bModal = ptr_dynamic_cast<ModalControl>(t);
			if (bModal)
			{
				topLayerControls.Add(t);
			}
		}
		for(int i=0; i<topLayerControls.GetCount(); i++)
		{
			Rearranged = true;
			topLayerControls[i]->ChangeParent(ptr_static_cast<GuiSystem>(this), NullPtr, false);
		}
		topLayerControls.Clear();

		if(Rearranged)
		{
			//Make all combolist/balloon/frame/noticeboard/etc. which belongs to modalwindow above modalwindow
			for (tempc_ptr(Control) t = GetFirstChild(); t; t = t->GetNext())
			{
				tempc_ptr(ComboList) bComboList = ptr_dynamic_cast<ComboList>(t);
				tempc_ptr(Gui::Balloon)	bBalloon = ptr_dynamic_cast<Gui::Balloon>(t);
				tempc_ptr(Gui::PopupFrame) bFrame = ptr_dynamic_cast<Gui::PopupFrame>(t);
				if (bComboList/* || bBalloon || bFrame*/)
				{
					tempc_ptr(Control) bRoot = t->GetRoot();
					if(bRoot)
					{
						tempc_ptr(ModalControl) bModal  = ptr_dynamic_cast<ModalControl>(bRoot);
						topLayerControls.Add(t);
					}
				}
			}
			for(int i=0; i<topLayerControls.GetCount(); i++)
			{
				topLayerControls[i]->ChangeParent(ptr_static_cast<GuiSystem>(this), NullPtr, false);
			}
		}
		topLayerControls.Clear();

#ifndef MASTER
		//If console is visible, make it top again
		if(gGame->console->GetParent())
			gGame->console->ChangeParent(ptr_static_cast<GuiSystem>(this), NullPtr, false);
#endif
	}
}

DEFINE_PDE_TYPE_ENUM(Gui::GuiSystem::UIAudioEnum)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_ENUM_ITEM("kUIA_lOBBY_MUSIC",		Gui::GuiSystem::kUIA_lOBBY_MUSIC);
		ADD_PDE_ENUM_ITEM("kUIA_MOUSE_CLICK",		Gui::GuiSystem::kUIA_MOUSE_CLICK);
		ADD_PDE_ENUM_ITEM("kUIA_BUY_SUCCESS",		Gui::GuiSystem::kUIA_BUY_SUCCESS);
		ADD_PDE_ENUM_ITEM("kUIA_NEW_MAIL",			Gui::GuiSystem::kUIA_NEW_MAIL);
		ADD_PDE_ENUM_ITEM("kUIA_SYSTEM_MESSAGE",	Gui::GuiSystem::kUIA_SYSTEM_MESSAGE);
		ADD_PDE_ENUM_ITEM("kUIA_CONFIRM_MESSAGE",	Gui::GuiSystem::kUIA_CONFIRM_MESSAGE);
		ADD_PDE_ENUM_ITEM("kUIA_BALLOON",			Gui::GuiSystem::kUIA_BALLOON);
		ADD_PDE_ENUM_ITEM("kUIA_WEAPON_MOD",		Gui::GuiSystem::kUIA_WEAPON_MOD);
		ADD_PDE_ENUM_ITEM("kUIA_TEAM_INVITED",		Gui::GuiSystem::kUIA_TEAM_INVITED);
		ADD_PDE_ENUM_ITEM("kUIA_USE_EQUIP_ITEM",	Gui::GuiSystem::kUIA_USE_EQUIP_ITEM);
		ADD_PDE_ENUM_ITEM("kUIA_LEVEL_UP",			Gui::GuiSystem::kUIA_LEVEL_UP);
		ADD_PDE_ENUM_ITEM("kUIA_CHAT_MESSAGE",		Gui::GuiSystem::kUIA_CHAT_MESSAGE);
		ADD_PDE_ENUM_ITEM("kUIA_TREASURE_BOX",		Gui::GuiSystem::kUIA_TREASURE_BOX);
		ADD_PDE_ENUM_ITEM("kUIA_CONGRA_POP",		Gui::GuiSystem::kUIA_CONGRA_POP);
		ADD_PDE_ENUM_ITEM("kUIA_GAME_WIN",			Gui::GuiSystem::kUIA_GAME_WIN);
		ADD_PDE_ENUM_ITEM("kUIA_GAME_LOSE",			Gui::GuiSystem::kUIA_GAME_LOSE);
		//timmy���ӵ���Ч
		ADD_PDE_ENUM_ITEM("kUIA_COMPOUND_SUCCEED",	Gui::GuiSystem::kUIA_COMPOUND_SUCCEED);
		ADD_PDE_ENUM_ITEM("kUIA_COMPOUND_FAIL",		Gui::GuiSystem::kUIA_COMPOUND_FAIL);
		ADD_PDE_ENUM_ITEM("kUIA_COMPOUND_SUCCEED_SWF",	Gui::GuiSystem::kUIA_COMPOUND_SUCCEED_SWF);
		ADD_PDE_ENUM_ITEM("kUIA_COMPOUND_FAIL_SWF",		Gui::GuiSystem::kUIA_COMPOUND_FAIL_SWF);
		ADD_PDE_ENUM_ITEM("kUIA_COMPOUND_SUCCEED_SWF_EX",		Gui::GuiSystem::kUIA_COMPOUND_SUCCEED_SWF_EX);
		ADD_PDE_ENUM_ITEM("kUIA_COMPOUND_PUT",		Gui::GuiSystem::kUIA_COMPOUND_PUT);
		ADD_PDE_ENUM_ITEM("kUIA_OPEN_SUCCEED",		Gui::GuiSystem::kUIA_OPEN_SUCCEED);
		ADD_PDE_ENUM_ITEM("kUIA_LOTTERY",			Gui::GuiSystem::kUIA_LOTTERY);
		ADD_PDE_ENUM_ITEM("kUIA_STAGE_TURNCARD",	Gui::GuiSystem::kUIA_STAGE_TURNCARD);
		ADD_PDE_ENUM_ITEM("kUIA_LAOHUJI",			Gui::GuiSystem::kUIA_LAOHUJI);
		ADD_PDE_ENUM_ITEM("kUIA_MVPMOVE",			Gui::GuiSystem::kUIA_MVPMOVE);
		ADD_PDE_ENUM_ITEM("kUIA_CLOSE_TIME",	Gui::GuiSystem::kUIA_CLOSE_TIME);
		ADD_PDE_ENUM_ITEM("kUIA_CLEAN_UP",	Gui::GuiSystem::kUIA_CLEAN_UP);
		ADD_PDE_ENUM_ITEM("kUIA_CREATE_TEAM",	Gui::GuiSystem::kUIA_CREATE_TEAM);
		ADD_PDE_ENUM_ITEM("kUIA_DISMISS_TEAM",	Gui::GuiSystem::kUIA_DISMISS_TEAM);
		ADD_PDE_ENUM_ITEM("kUIA_SEND_MAIL",	Gui::GuiSystem::kUIA_SEND_MAIL);
		ADD_PDE_ENUM_ITEM("kUIA_COMPOUND_PUT_ITEM",	Gui::GuiSystem::kUIA_COMPOUND_PUT_ITEM);
		ADD_PDE_ENUM_ITEM("kUIA_MISSION_REWARD",	Gui::GuiSystem::kUIA_MISSION_REWARD);
		ADD_PDE_ENUM_ITEM("kUIA_UNLOCK_MODULE",	Gui::GuiSystem::kUIA_UNLOCK_MODULE);
		ADD_PDE_ENUM_ITEM("kUIA_POKERCARD_TRUN",	Gui::GuiSystem::kUIA_POKERCARD_TRUN);
		ADD_PDE_ENUM_ITEM("kUIA_CLOSE_UI",			Gui::GuiSystem::kUIA_CLOSE_UI);
		ADD_PDE_ENUM_ITEM("kUIA_CLOSE_UI2",			Gui::GuiSystem::kUIA_CLOSE_UI2);
		ADD_PDE_ENUM_ITEM("kUIA_USE_MONEY",			Gui::GuiSystem::kUIA_USE_MONEY);
		ADD_PDE_ENUM_ITEM("kUIA_STORAGE",			Gui::GuiSystem::kUIA_STORAGE);
		ADD_PDE_ENUM_ITEM("kUIA_SHOOTING_ON_HIT",			Gui::GuiSystem::kUIA_SHOOTING_ON_HIT);
		ADD_PDE_ENUM_ITEM("kUIA_FUSION_START",			Gui::GuiSystem::kUIA_FUSION_START);
		ADD_PDE_ENUM_ITEM("kUIA_FUSION_LOOK",			Gui::GuiSystem::kUIA_FUSION_LOOK);
		ADD_PDE_ENUM_ITEM("kUIA_PUZZLE_COMPLETE",			Gui::GuiSystem::kUIA_PUZZLE_COMPLETE);
		ADD_PDE_ENUM_ITEM("kUIA_PUZZLE_MATCH",			Gui::GuiSystem::kUIA_PUZZLE_MATCH);
		ADD_PDE_ENUM_ITEM("kUIA_PUZZLE_MOVE",			Gui::GuiSystem::kUIA_PUZZLE_MOVE);
		

		ADD_PDE_ENUM_ITEM("kUIA_GETITEM",			Gui::GuiSystem::kUIA_GETITEM);
		ADD_PDE_ENUM_ITEM("kUIA_OPEN_CODECASE", 	Gui::GuiSystem::kUIA_OPEN_CODECASE); 
		ADD_PDE_ENUM_ITEM("kUIA_USE_EXP",			Gui::GuiSystem::kUIA_USE_EXP);
		ADD_PDE_ENUM_ITEM("kUIA_USE_EXP_LEVELUP",	Gui::GuiSystem::kUIA_USE_EXP_LEVELUP);
		ADD_PDE_ENUM_ITEM("kUIA_USE_ITEM",			Gui::GuiSystem::kUIA_USE_ITEM);
		ADD_PDE_ENUM_ITEM("kUIA_EQUIPMENT",			Gui::GuiSystem::kUIA_EQUIPMENT);
		ADD_PDE_ENUM_ITEM("kUIA_GET_GOOD_REWARD",	Gui::GuiSystem::kUIA_GET_GOOD_REWARD);
		ADD_PDE_ENUM_ITEM("kUIA_GET_REWARD",		Gui::GuiSystem::kUIA_GET_REWARD);

		ADD_PDE_ENUM_CONSTRUCTOR();
	}
};

DEFINE_PDE_TYPE_CLASS(Gui::GuiSystem)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::Control);

		ADD_PDE_EVENT(EventControlStyleChanged);
		ADD_PDE_EVENT(EventShowMessage);
		ADD_PDE_EVENT(EventAvatarSwitched);
		ADD_PDE_EVENT(EventShowHelp);
		ADD_PDE_EVENT(EventSizeChangedAdd);
		ADD_PDE_PROPERTY_RW(DrawDG);
		ADD_PDE_PROPERTY_R (FocusedControl);

		ADD_PDE_METHOD(ShowMessage);
		ADD_PDE_METHOD(PlayAudio);
		ADD_PDE_METHOD(ShowIE);
		ADD_PDE_METHOD(ShowFCM);
		ADD_PDE_METHOD(ShowGW);
		ADD_PDE_METHOD(SetFaceBookData);
	}
};

REGISTER_PDE_TYPE(Gui::GuiSystem::UIAudioEnum);
REGISTER_PDE_TYPE(Gui::GuiSystem);