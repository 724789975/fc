namespace Gui
{
	class CharacterViewer:	public Control
	{
	public:
		CharacterViewer();

		~CharacterViewer();
		// on input event as a control
		virtual void OnInputEvent(InputEventArgs & e);
			
		virtual void OnCreate();
		// on paint
		virtual void OnPaint(PaintEventArgs & e);
	protected:
		//assistant variable
		sharedc_ptr(Client::RenderTexture)	render_texture;
		float aspect; 
	};
}