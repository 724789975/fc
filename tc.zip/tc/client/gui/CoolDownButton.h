namespace Gui
{
	class CoolDownButton: public Control
	{
		DECLARE_PDE_OBJECT(CoolDownButton, Control);

	public:
		DECLARE_PDE_EVENT(EventClick, Client::InputEventArgs);
		DECLARE_PDE_EVENT(EventDoubleClick, Client::InputEventArgs);

	public:
		DECLARE_PDE_ATTRIBUTE_RW(TextAlign, Client::Unit::Align);
		DECLARE_PDE_ATTRIBUTE_RW(AlphaTestValue, float);
		DECLARE_PDE_ATTRIBUTE_RW(AlphaBlendValue, float);
		DECLARE_PDE_ATTRIBUTE_RW(CoolDownTime, float);

	public:
		CoolDownButton();
		~CoolDownButton();

		// on frame update
		virtual void OnFrameUpdate(EventArgs & e);

		// on input event
		virtual	void OnInputEvent(Client::InputEventArgs & e);

		// on key event
		virtual void OnKeyEvent(Client::InputEventArgs & e);

		// on paint
		virtual void OnPaint(PaintEventArgs & e);

		// on click
		virtual void OnClick(Client::InputEventArgs & e);

		//on double click
		virtual void OnDoubleClick(Client::InputEventArgs & e);

	protected:
		Client::Unit::Align m_TextAlign;
		float				m_AlphaTestValue;
		float				m_AlphaBlendValue;
		float				m_CoolDownTime;
		bool				m_IsCoolDown:1;
		bool				m_IsMouseHoldDown:1;
		bool				m_IsMousePointed:1;
	};

	class CoolDownButtonSkin : public ControlSkin
	{
	public:
		INLINE_PDE_ATTRIBUTE_RW(OriginalImage, tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(MaskImage,	   tempc_ptr(Image));

	private:
		sharedc_ptr(Image) m_OriginalImage;
		sharedc_ptr(Image) m_MaskImage;
	};
}