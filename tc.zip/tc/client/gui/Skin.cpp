#include "pch.h"

using namespace Core;
using namespace Client;
using namespace Gui;

// draw icon
void Skin::DrawImage(by_ptr(Client::UIRender) render, by_ptr(Gui::Image) image, const Core::Rectangle & rect,ARGB color)
{
	if (image)
	{
		image->Draw(render, rect, color);
	}
}


// draw icon text
void Skin::DrawIconText(by_ptr(Client::UIRender) render, by_ptr(Gui::Icon) icon, by_ptr(Client::Font) font, const CHAR* text, const Core::Rectangle & rect, Unit::Align align, Core::ARGB iconColor, Core::ARGB textColor, bool iconEnable, bool textEnable, F32 space, F32 space_x, F32 space_y)
{
	Core::Rectangle textRect(rect);
	Core::Rectangle iconRect(rect);

	if (iconEnable && icon && icon->IsReady())
	{
		Core::Vector2 iconSize = icon->GetSize();
		// �Ƚ�ͼƬ����δ�С ����������ͼƬ
		Vector2 tempSize = Vector2::kZero;
		tempSize.x = rect.Max.x - rect.Min.x;
		tempSize.y = rect.Max.y - rect.Min.y;
		if (iconSize.x > tempSize.x || iconSize.y > tempSize.y)
		{
			if ((iconSize.x - tempSize.x) > (iconSize.y - tempSize.y))
				tempSize.y =  iconSize.y * tempSize.x / iconSize.x;
			else
				tempSize.x = iconSize.x * tempSize.y / iconSize.y;

			iconSize = tempSize;
		}

		if(icon->GetDisplayType() == Icon::kIconTextActualSize)
		{

			textRect.Min.x += space ;
			textRect.Min.y += space_y;
			if (textEnable && text && text[0] && font)
			{
				Core::Rectangle rect = font->MeasureString(textRect, text, -1, align);
				iconRect.Max.x -= rect.GetExtent().x + space;
			}

			iconRect.Min.x += Floor((iconRect.Max.x - iconRect.Min.x - iconSize.x + space_x) * ((align & Unit::kAlignHorizontalMask) >> 0) * 0.5f);
			iconRect.Min.y += Floor((iconRect.Max.y - iconRect.Min.y - iconSize.y) * ((align & Unit::kAlignVerticalMask) >> 4) * 0.5f);

			iconRect.Max = iconRect.Min + iconSize;
			
		}
		else if(icon->GetDisplayType() == Icon::kIconTextFullFill)
		{

			if (text && text[0] && font)
			{
				Core::Rectangle tempRect = font->MeasureString(rect, text, -1, align);
				iconRect.Max.x -= tempRect.GetExtent().x + space*2;
				textRect.Min.x = iconRect.Max.x +space;
				textRect.Max.x -=space;
			}
			else
 			{
 				iconRect.Min.x+=space;
 				iconRect.Max.x-=space;
 			}
 			iconRect.Shrink(Vector4(0, 3, 0, 2));	
		}

		icon->Draw(render, iconRect, iconColor);
	}

	if (textEnable && font && text && text[0])
	{
		//render->DrawString(font, textColor, ARGB(0, 0, 0, 0), textRect, text, align, -1);
		render->DrawStringShadow(font,textColor, ARGB(75,0,0,0), ARGB(0,0,0,0), textRect, text, align, -1);
	}
}

// measure icon text
Core::Vector2 Skin::MeasureIconText(by_ptr(Gui::Icon) icon, by_ptr(Client::Font) font, const CHAR* text, F32 space)
{
	Vector2 size = Vector2::kZero;

	//If the icon requires full fill display, the total size can not be measured until display time
	if (icon && icon->IsReady())
	{
		if(icon->GetDisplayType() == Icon::kIconTextFullFill)
			return Vector2::kZero;
	}

	if (icon && icon->IsReady())
		size = icon->GetSize();

	if (font && text && text[0])
	{
		Vector2 textSize = font->MeasureString(Core::Rectangle(0, 0, 0, 0), text, -1).GetExtent();
		size.x += textSize.x;

		if (icon && icon->IsReady())
			size.x += space;

		size.y = Max(size.y, textSize.y);
	}

	return size;
}