#include "pch.h"

using namespace Core;
using namespace Gui;
using namespace Client;

//---------------------------------------------------------------------------------------
// type info.
//---------------------------------------------------------------------------------------
DEFINE_PDE_TYPE_ENUM(Control::DockKind)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_ENUM_ITEM("kDockNone",			Control::kDockNone);
		ADD_PDE_ENUM_ITEM("kDockLeft",			Control::kDockLeft);
		ADD_PDE_ENUM_ITEM("kDockRight",			Control::kDockRight);
		ADD_PDE_ENUM_ITEM("kDockTop",			Control::kDockTop);
		ADD_PDE_ENUM_ITEM("kDockBottom",		Control::kDockBottom);
		ADD_PDE_ENUM_ITEM("kDockFill",			Control::kDockFill);
		ADD_PDE_ENUM_ITEM("kDockLeftTop",		Control::kDockLeftTop);
		ADD_PDE_ENUM_ITEM("kDockRightTop",		Control::kDockRightTop);
		ADD_PDE_ENUM_ITEM("kDockLeftBottom",	Control::kDockLeftBottom);
		ADD_PDE_ENUM_ITEM("kDockRightBottom",	Control::kDockRightBottom);
		ADD_PDE_ENUM_ITEM("kDockCenter",		Control::kDockCenter);
		ADD_PDE_ENUM_ITEM("kDockTopCenter",		Control::kDockTopCenter);
		ADD_PDE_ENUM_ITEM("kDockBottomCenter",		Control::kDockBottomCenter);
		ADD_PDE_ENUM_ITEM("kDockHorizontalCenter",	Control::kDockHorizontalCenter);

		ADD_PDE_ENUM_CONSTRUCTOR();
	}
};

DEFINE_PDE_TYPE_CLASS(ControlSkin)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_PROPERTY_RW(BackgroundImage);
	}
};


DEFINE_PDE_TYPE_CLASS(Control)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_EVENT(EventSizeChanged);
		ADD_PDE_EVENT(EventEnter);
		ADD_PDE_EVENT(EventLeave);
		ADD_PDE_EVENT(EventActiveChanged);
		ADD_PDE_EVENT(EventEscPressed);
		ADD_PDE_EVENT(EventChangeState);
		ADD_PDE_EVENT(EventMouseEnter);
		ADD_PDE_EVENT(EventMouseLeave);
		ADD_PDE_EVENT(EventMouseDown);
		ADD_PDE_EVENT(EventMouseUp);
		ADD_PDE_EVENT(EventMouseRightUp);


		ADD_PDE_PROPERTY_RW(Location);
		ADD_PDE_PROPERTY_RW(Size);
		ADD_PDE_PROPERTY_RW(UseTextKey);
		ADD_PDE_PROPERTY_RW(Text);
		ADD_PDE_PROPERTY_RW(Hint);
		ADD_PDE_PROPERTY_RW(TextColor);
		ADD_PDE_PROPERTY_RW(TextShadowColor);
		ADD_PDE_PROPERTY_RW(HighlightTextColor);
		ADD_PDE_PROPERTY_RW(TextLightSource);
		ADD_PDE_PROPERTY_RW(DisabledTextColor);
		ADD_PDE_PROPERTY_RW(BackgroundColor);
		ADD_PDE_PROPERTY_R(Active);
		ADD_PDE_PROPERTY_RW(CanFocus);
		ADD_PDE_PROPERTY_RW(Focused);
		ADD_PDE_PROPERTY_RW(Visible);
		ADD_PDE_PROPERTY_RW(AutoSize);
		ADD_PDE_PROPERTY_RW(Enable);

		ADD_PDE_PROPERTY_RW(TabFocus);

		ADD_PDE_PROPERTY_RW(Tag);
		ADD_PDE_PROPERTY_RW(Parent);
		ADD_PDE_PROPERTY_R(Next);
		ADD_PDE_PROPERTY_R(Previous);
		ADD_PDE_PROPERTY_R(FirstChild);
		ADD_PDE_PROPERTY_R(LastChild);

		ADD_PDE_PROPERTY_RW(Dock);
		ADD_PDE_PROPERTY_RW(Margin);
		ADD_PDE_PROPERTY_RW(Padding);
		ADD_PDE_PROPERTY_W(Font);
		ADD_PDE_PROPERTY_RW(FontSize);
		ADD_PDE_PROPERTY_RW(Style);
		ADD_PDE_PROPERTY_RW(Skin);
		ADD_PDE_PROPERTY_RW(Shine);

		ADD_PDE_PROPERTY_RW(UseTime);
		ADD_PDE_PROPERTY_RW(DisplayTime);

		ADD_PDE_PROPERTY_RW(CONTROL_HOVER_EFFECT_DURATION);
		ADD_PDE_PROPERTY_RW(CONTROL_SHINE_EFFECT_DURATION);
		ADD_PDE_PROPERTY_RW(CONTROL_BALLOON_FRAME_DURATION);

		ADD_PDE_PROPERTY_RW(IntTag);

		ADD_PDE_METHOD(ChangeParent);
		ADD_PDE_METHOD(FindChildByText);
		ADD_PDE_METHOD(GetChildByIndex);
		ADD_PDE_METHOD(Balloon);
		ADD_PDE_METHOD(Balloon2);
		ADD_PDE_METHOD(CancelBalloon);
		ADD_PDE_METHOD(PopFrame);
		ADD_PDE_METHOD(CancelFrame);
		ADD_PDE_METHOD(PopNoticeBoard);
		ADD_PDE_METHOD(CancelNoticeBoard);

		ADD_PDE_METHOD(ClearAllFrames);
		ADD_PDE_METHOD(ClearAllBalloons);
		ADD_PDE_METHOD(ClearAllNoticeBoards);
		ADD_PDE_METHOD(OnDestroy);
		ADD_PDE_METHOD(ClientToGlobalScreen);
		ADD_PDE_METHOD(TextWidth);

		ADD_PDE_METHOD(AddFrame);
		ADD_PDE_METHOD(DeleteAllImage);
	}
};

DEFINE_PDE_TYPE_CLASS(Gui::TimeControl)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::Control);
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_EVENT(EventTimeOut);
		ADD_PDE_EVENT(EventTimeUpdate);	

		ADD_PDE_METHOD(AddTime);
		ADD_PDE_METHOD(CleanAll);
	}
};

REGISTER_PDE_TYPE(Control::DockKind);
REGISTER_PDE_TYPE(ControlSkin);
REGISTER_PDE_TYPE(Control);
REGISTER_PDE_TYPE(TimeControl);

//---------------------------------------------------------------------------------------
// macro.
//---------------------------------------------------------------------------------------
// #define CONTROL_HOVER_EFFECT_DURATION 1.0f

//---------------------------------------------------------------------------------------
// attributes.
//---------------------------------------------------------------------------------------
namespace Gui
{
	sharedc_ptr(ToolTip) Control::s_ToolTip = NullPtr;

	Control::Control()
		: m_Parent(NULL)
		, m_Next(NULL)
		, m_Prev(NULL)
		, m_FirstChild(NULL)
		, m_LastChild(NULL)
		, m_Location(0, 0)
		, m_Scroll(0, 0)
		, m_Size(0, 0)
		, m_Enable(true)
		, m_Visible(true)
		, m_UseTextKey(false)
		, m_Active(false)
		, m_CanFocus(true)
		, m_TabFocus(false)
		, m_AutoSize(false)
		, m_TextColor(Core::ARGB(255, 220, 220, 220))
		, m_TextShadowColor(Core::ARGB(128, 0, 0, 0))
		, m_HighlightTextColor(Core::ARGB(255, 255, 255, 255))
		, m_DisabledTextColor(Core::ARGB(255, 128, 128, 128))
		, m_TextLightSource(Core::PI*3/4)
		, m_BackgroundColor(255, 255, 255, 255)
		, m_LayoutDirty(true)
		, m_RegionDirty(true)
		, m_DockClient(0, 0, 0, 0)
		, m_Dock(kDockNone)
		, m_Padding(0, 0, 0, 0)
		, m_Margin(0, 0, 0, 0)
		, m_FontSize(14)
		, m_DirtyRect(Vector2::kZero, Vector2::kZero)
		, m_HoverPower(0.0f)
		, m_FontName("simhei")
		, m_Shine(false)
		, m_HoverIncreasing(false)
		, m_TextEllipsis(false)
		, m_CONTROL_HOVER_EFFECT_DURATION(0.2f)
		, m_CONTROL_SHINE_EFFECT_DURATION(0.5f)
		, m_CONTROL_BALLOON_FRAME_DURATION(10.f)
		, m_Hint(NULL)
		, m_Timer(0)
		, m_UseTime(false)
		, m_DisplayTime(5)
		, m_BackChoose(0)
		, m_BackgroundSum(0)
	{
	}

	Control::~Control()
	{
	}

	PDE_ATTRIBUTE_GETTER(Control, Location, Vector2)
	{
		return m_Location;
	}

	PDE_ATTRIBUTE_SETTER(Control, Location, Vector2)
	{
		if (m_Location != value)
		{
			MoveEventArgs e;
			e.OldPosition = m_Location;
			e.NewPosition = value;

			m_Location = value;

			OnLocationChanged(e);
		}
	}

	PDE_ATTRIBUTE_GETTER(Control, Size, Vector2)
	{
		return m_Size;
	}

	PDE_ATTRIBUTE_SETTER(Control, Size, Vector2)
	{
		if (m_Size != value)
		{
			ResizeEventArgs e;
			e.OldSize = m_Location;
			e.NewSize = value;

			m_Size = value;

			OnSizeChanged(e);
		}
	}

	PDE_ATTRIBUTE_GETTER(Control, Scroll, Vector2)
	{
		return m_Scroll;
	}


	PDE_ATTRIBUTE_GETTER(Control, Visible, bool)
	{
		return m_Visible;
	}

	PDE_ATTRIBUTE_SETTER(Control, Visible, bool)
	{
		if (m_Visible != value)
		{
			m_Visible = value;

			OnVisibleChanged(EventArgs());
		}
	}

	PDE_ATTRIBUTE_GETTER(Control, Enable, bool)
	{
		return m_Enable;
	}

	PDE_ATTRIBUTE_SETTER(Control, Enable, bool)
	{
		if (m_Enable != value)
		{
			m_Enable = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(Control, AutoSize, bool)
	{
		return m_AutoSize;
	}

	PDE_ATTRIBUTE_SETTER(Control, AutoSize, bool)
	{
		if(m_AutoSize != value)
		{
			m_AutoSize = value;
			DirtyLayout();
		}
	}

	PDE_ATTRIBUTE_SETTER(Control, UseTime, bool)
	{
		if (m_UseTime != value)
		{
			m_UseTime = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(Control, UseTime, bool)
	{
		return m_UseTime;
	}

	PDE_ATTRIBUTE_SETTER(Control, DisplayTime, F32)
	{
		if (m_DisplayTime != value)
		{
			m_DisplayTime = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(Control, DisplayTime, F32)
	{
		return m_DisplayTime;
	}

	PDE_ATTRIBUTE_GETTER(Control, Root, tempc_ptr(Control))
	{
		Control * control = this;
		for (;;)
		{
			Control * parent = control->m_Parent;
			if (parent)
			{
				if(ptr_dynamic_cast<GuiSystem>(parent))
				{
					return ptr_static_cast<Control>(control);
				}
				control = parent;
			}
			else
			{
				return NullPtr;
			}
		}
	}

	PDE_ATTRIBUTE_GETTER(Control, Parent, tempc_ptr(Control))
	{
		return ptr_static_cast<Control>(m_Parent);
	}

	PDE_ATTRIBUTE_GETTER(Control, Next, tempc_ptr(Control))
	{
		return ptr_static_cast<Control>(m_Next);
	}

	PDE_ATTRIBUTE_GETTER(Control, Previous, tempc_ptr(Control))
	{
		return ptr_static_cast<Control>(m_Prev);
	}

	PDE_ATTRIBUTE_GETTER(Control, FirstChild, tempc_ptr(Control))
	{
		return ptr_static_cast<Control>(m_FirstChild);
	}

	PDE_ATTRIBUTE_GETTER(Control, LastChild, tempc_ptr(Control))
	{
		return ptr_static_cast<Control>(m_LastChild);
	}

	PDE_ATTRIBUTE_SETTER(Control, Parent, tempc_ptr(Control))
	{
		ChangeParent(value, NullPtr);
	}

	PDE_ATTRIBUTE_GETTER(Control, ClientRect, Core::Rectangle)
	{
		return Core::Rectangle::LeftTop(Vector2::kZero, m_Size);
	}

	PDE_ATTRIBUTE_GETTER(Control, BackgroundRect, Core::Rectangle)
	{
		return Core::Rectangle::LeftTop(m_Scroll, m_Size);
	}

	PDE_ATTRIBUTE_GETTER(Control, DisplayRect, Core::Rectangle)
	{
		return Core::Rectangle::LeftTop(m_Scroll, m_Size).Shrink(GetDisplayPadding());
	}

	PDE_ATTRIBUTE_GETTER(Control, ActualPaintRect, Core::Rectangle)
	{
		bool treeScrollded = false;
		Control * control = this;
		for(;;)
		{
			if (!(control && control->m_Visible))
				break;
			if(Core::Abs(control->m_Scroll.x)>Core::EPSILON || Core::Abs(control->m_Scroll.y)>Core::EPSILON)
			{
				//Scrolled
				treeScrollded = true;
				break;
			}
			control = control->m_Parent;
		}
		if(!treeScrollded)
			return GetBackgroundRect();
		else
		{
			Control * control = this;
			Vector2 finalZero = Vector2::kZero;
			Core::Rectangle bkRect = GetBackgroundRect();
			for(;;)
			{
				if (!(control && control->m_Visible))
					break;

				// control' display rectangle
				bkRect.IntersectWith(control->GetBackgroundRect());

				if (bkRect.IsEmpty())
					break;

				bkRect.Move(control->m_Location - control->m_Scroll);
				finalZero+=(control->m_Location - control->m_Scroll);
				control = control->m_Parent;
			}
			bkRect.Move(-finalZero);
			return bkRect;
		}
	}

	PDE_ATTRIBUTE_GETTER(Control, DisplayPadding, Vector4)
	{
		return Vector4::kZero;
	}

	PDE_ATTRIBUTE_GETTER(Control, TextColor, ARGB)
	{
		return m_TextColor;
	}

	PDE_ATTRIBUTE_SETTER(Control, TextColor, ARGB)
	{
		if (m_TextColor != value)
		{
			m_TextColor = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(Control, TextShadowColor, ARGB)
	{
		return m_TextShadowColor;
	}

	PDE_ATTRIBUTE_SETTER(Control, TextShadowColor, ARGB)
	{
		if (m_TextShadowColor != value)
		{
			m_TextShadowColor = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(Control, HighlightTextColor, ARGB)
	{
		return m_HighlightTextColor;
	}

	PDE_ATTRIBUTE_SETTER(Control, HighlightTextColor, ARGB)
	{
		if (m_HighlightTextColor != value)
		{
			m_HighlightTextColor = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(Control, TextLightSource, F32)
	{
		return m_TextLightSource;
	}

	PDE_ATTRIBUTE_SETTER(Control, TextLightSource, F32)
	{
		if (m_TextLightSource != value)
		{
			m_TextLightSource = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(Control, DisabledTextColor, ARGB)
	{
		return m_DisabledTextColor;
	}

	PDE_ATTRIBUTE_SETTER(Control, DisabledTextColor, ARGB)
	{
		if (m_DisabledTextColor != value)
		{
			m_DisabledTextColor = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(Control, BackgroundColor, ARGB)
	{
		return m_BackgroundColor;
	}

	PDE_ATTRIBUTE_SETTER(Control, BackgroundColor, ARGB)
	{
		if (m_BackgroundColor != value)
		{
			m_BackgroundColor = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(Control, Text, const Core::String &)
	{
		return m_Text;
	}

	PDE_ATTRIBUTE_SETTER(Control, Text, const Core::String &)
	{
		Core::String text = value;
		if (m_UseTextKey && value.Length() > 0 && m_TextKey != value)
		{
			m_TextKey = value;
			text = gLang->GetText(value);
		}

		if (m_Text != text)
		{
			m_Text = text;
			OnTextChanged(EventArgs());
		}
	}

	PDE_ATTRIBUTE_GETTER(Control, Hint, const Core::String &)
	{
		return m_Hint;
	}

	PDE_ATTRIBUTE_SETTER(Control, Hint, const Core::String &)
	{
		if (m_Hint != value)
		{
			m_Hint = value;
		}
	}

	PDE_ATTRIBUTE_GETTER(Control, Tag, tempc_ptr(void))
	{
		return m_Tag;
	}

	PDE_ATTRIBUTE_SETTER(Control, Tag, tempc_ptr(void))
	{
		if (m_Tag != value)
		{
			m_Tag = value;
		}
	}

	PDE_ATTRIBUTE_GETTER(Control, Active, Bool)
	{
		return m_Active;
	}

	PDE_ATTRIBUTE_SETTER(Control, CanFocus, Bool)
	{
		m_CanFocus = value;
	}

	PDE_ATTRIBUTE_GETTER(Control, CanFocus, Bool)
	{
		return m_CanFocus;
	}

	PDE_ATTRIBUTE_SETTER(Control, Focused, Bool)
	{
		if (!gGame || !gGame->guiSys)
			return;

		if(value)
		{
			gGame->guiSys->SetFocusedControl(ptr_static_cast<Control>(this));
		}
		else
		{
			gGame->guiSys->SetFocusedControl(NullPtr);
		}
	}

	PDE_ATTRIBUTE_GETTER(Control, Focused, Bool)
	{
		if (!gGame || !gGame->guiSys)
			return false;

		return gGame->guiSys->GetFocusedControl() == this;
	}

	PDE_ATTRIBUTE_SETTER(Control, Capture, Bool)
	{
		if (!gGame || !gGame->guiSys)
			return;

		return gGame->guiSys->SetCaptureControl(ptr_static_cast<Control>(this), value);
	}

	PDE_ATTRIBUTE_GETTER(Control, Capture, Bool)
	{
		if (!gGame || !gGame->guiSys)
			return false;

		return gGame->guiSys->GetCaptureControl() == this;
	}

	PDE_ATTRIBUTE_SETTER(Control, Dock, Control::DockKind)
	{
		if (m_Dock != value)
		{
			m_Dock = value;

			if (m_Parent)
				m_Parent->DirtyLayout();
		}
	}

	PDE_ATTRIBUTE_GETTER(Control, Dock, Control::DockKind)
	{
		return m_Dock;
	}

	PDE_ATTRIBUTE_SETTER(Control, Margin, Core::Vector4)
	{
		if (m_Margin != value)
		{
			m_Margin = value;

			if (m_Parent)
				m_Parent->DirtyLayout();
		}
	}

	PDE_ATTRIBUTE_GETTER(Control, Margin, Core::Vector4)
	{
		return m_Margin;
	}

	PDE_ATTRIBUTE_SETTER(Control, Padding, Core::Vector4)
	{
		if (m_Padding != value)
		{
			m_Padding = value;
			DirtyLayout();
		}
	}

	PDE_ATTRIBUTE_GETTER(Control, Padding, Core::Vector4)
	{
		return m_Padding;
	}


	PDE_ATTRIBUTE_SETTER(Control, FontSize, float)
	{
		if (m_FontSize != value)
		{
			m_FontSize = value;
			OnFontChanged(EventArgs());
		}
	}

	PDE_ATTRIBUTE_GETTER(Control, FontSize, float)
	{
		return m_FontSize;
	}

	PDE_ATTRIBUTE_GETTER(Control, Font, tempc_ptr(Client::Font))
	{
		if (!m_Font || m_Font->GetFontSize() != m_FontSize)
		{
			if (gGame)
				m_Font = gRender->font_manager->GetFont(m_FontName, m_FontSize, 0);
		}

		return m_Font;
	}

	PDE_ATTRIBUTE_SETTER(Control, Font, const String&)
	{
		if(m_FontName!=value)
			m_FontName = value;
	}

	PDE_ATTRIBUTE_GETTER(Control, Style, const String &)
	{
		return m_Style;
	}

	PDE_ATTRIBUTE_SETTER(Control, Style, const String &)
	{
		if (m_Style != value)
		{
			m_Style = value;
			OnStyleChanged(EventArgs());
		}
	}

	PDE_ATTRIBUTE_GETTER(Control, Skin, tempc_ptr(Gui::ControlSkin))
	{
		return m_Skin;
	}

	PDE_ATTRIBUTE_SETTER(Control, Skin, tempc_ptr(Gui::ControlSkin))
	{
		if (m_Skin != value)
		{
			m_Skin = value;
			Invalid();
		}
	}
}

//--------------------------------------------------------------------------------------
// methods.
//--------------------------------------------------------------------------------------
namespace Gui
{
	/// get next node
	Control* Control::GetNextNode(bool bSkipChilds)
	{
		if (!bSkipChilds && m_FirstChild) return m_FirstChild;
		if (m_Next) return m_Next;

		Control* result = m_Parent;
		while (result)
		{
			if (result->m_Next) return result->m_Next;
			result = result->m_Parent;
		}

		return NULL;
	}


	/// get prev node
	Control* Control::GetPrevNode(bool bSkipChilds)
	{
		if (m_Prev)
		{
			if (!bSkipChilds)
			{
				Control* result = m_Prev;
				while (result)
				{
					if (!result->m_LastChild) return result;
					result = result->m_LastChild;
				}
			}

			return m_Prev;
		}

		return m_Parent;
	}

	void Control::Invalid()
	{
		InvalidRect(GetBackgroundRect());
	}

	void Control::InvalidRect(const Core::Rectangle & rect)
	{
		Core::Rectangle invalid = rect;
		Control * control = this;

		if (rect.IsEmpty())
			return;

		for(;;)
		{
			if (!(control && control->m_Visible))
				break;

			// control' display rectangle
// 			invalid.IntersectWith(control->GetBackgroundRect());	//Will be wrong when there is a scrollable control in the tree(when the dirty rect is out of scroll scope, children dirtied but parents not, when unioned with other dirty rect within scroll scope, parents will not be redrawn but children will, see bug 1525)
			invalid.IntersectWith(control->GetActualPaintRect());

			if (invalid.IsEmpty())
				break;

			// update control's dirty region.
			control->m_DirtyRect.UnionWith(invalid);

			invalid.Move(control->m_Location - control->m_Scroll);
			control = control->m_Parent;
		}
	}

	void Control::ChangeParent(by_ptr(Control) parentControl, by_ptr(Control) insertBefore, bool parentNeedRearrangeChildren)
	{
		Control * parent = parentControl.ToPointer();
		Control * node = insertBefore.ToPointer();

		// check recursive
		for (Control * temp = parent; temp != NULL; temp = temp->m_Parent)
		{
			if (temp == this)
			{
				parent = NULL;
				node = NULL;
				break;
			}
		}

		if (m_Parent != parent || m_Next != node)
		{
			ChildrenChangedEventArgs e;
			e.Control = ptr_static_cast<Control>(this);

			sharedc_ptr(Control) old_parent = ptr_static_cast<Control>(m_Parent);
			sharedc_ptr(Control) new_parent = ptr_static_cast<Control>(parent);

			// remove it first
			if (m_Parent)
			{
				m_Parent->m_FirstChild = m_Parent->m_FirstChild == this ? m_Next : m_Parent->m_FirstChild;
				m_Parent->m_LastChild = m_Parent->m_LastChild == this ? m_Prev : m_Parent->m_LastChild;

				if (this->m_Prev) this->m_Prev->m_Next = this->m_Next;
				if (this->m_Next) this->m_Next->m_Prev = this->m_Prev;

				this->m_Prev = NULL;
				this->m_Next = NULL;

			}
			else
			{
				ptr_static_cast<Control>(this).GetPtrData()->AddRef();
			}

			m_Parent = parent;

			if (m_Parent)
			{
				if (node && node->m_Parent == m_Parent)
				{
					// link next
					if (node->m_Prev)
					{
						node->m_Prev->m_Next = this;
						this->m_Prev = node->m_Prev;
					}

					// link prev
					node->m_Prev = this;
					this->m_Next = node;

					// set last child
					m_Parent->m_FirstChild = this->m_Prev == NULL ? this : m_Parent->m_FirstChild;
				}
				else
				{
					// insert as last child
					this->m_Prev = m_Parent->m_LastChild;
					if (this->m_Prev) this->m_Prev->m_Next = this;

					m_Parent->m_LastChild = this;
					m_Parent->m_FirstChild = m_Parent->m_FirstChild == NULL ? this : m_Parent->m_FirstChild;
				}
			}
			else
			{
				ReleaseFocus();
				ptr_static_cast<Control>(this).GetPtrData()->Release();
			}

			if (old_parent)
			{
				e.removed = true;
				old_parent->OnChildrenChanged(e);
				old_parent->Invalid();
				old_parent->DirtyLayout();
			}

			if (new_parent)
			{
				e.removed = false;
				new_parent->OnChildrenChanged(e);
				new_parent->Invalid();
				new_parent->DirtyLayout();
				if(parentNeedRearrangeChildren)
					new_parent->RearrangeChildren();
			}

			OnParentChanged(EventArgs());
			Invalid();
		}
	}

	void Control::ReleaseFocus()
	{
		if(gGame)
		{
			if(gGame->guiSys)
			{
				if(gGame->guiSys->GetFocusedControl() == this)
				{
					gGame->guiSys->SetFocusedControl(NullPtr);
				}
				for (Control * control = m_FirstChild; control; control = control->m_Next)
				{
					control->ReleaseFocus();
				}
			}
		}
	}

	tempc_ptr(Control) Control::ControlFromLocation(const Vector2 & location)
	{
		Vector2 localPos = ScreenToClient(location) - m_Scroll;

		if (!Core::Rectangle(Vector2::kZero, GetSize()).IsPointInside(localPos))
			return NullPtr;

		if (!Core::Rectangle(Vector2::kZero, GetSize()).Shrink(GetDisplayPadding()).IsPointInside(localPos))
			return ptr_static_cast<Control>(this);

		for(Control * pControl = m_LastChild; pControl != NULL; pControl = pControl->m_Prev)
		{
			if(pControl->GetVisible() && pControl->GetEnable())
			{
				tempc_ptr(Control) ret = pControl->ControlFromLocation(location);
				if(ret)
				{
					return ret;
				}
			}
		}

		return ptr_static_cast<Control>(this);
	}

	void Control::Render(RenderEventArgs & e)
	{
		Vector3	old_offset = e.Offset;
		Core::Rectangle old_scissor = e.render->GetScissorRect();

		Core::Rectangle scissor = old_scissor;
		scissor.IntersectWith(Core::Rectangle::LeftTop(e.Offset + m_Location, m_Size));
		scissor.IntersectWith(e.render->GetVirtualViewport());

		// transform to local space.
		e.Offset += m_Location - m_Scroll;


		if (!scissor.IsEmpty())
		{
			// update dirty rect.
			for (U32 i = 0; i < e.DirtyRegion.Size(); i ++)
			{
				Core::Rectangle rect(e.DirtyRegion[i]);
				rect.IntersectWith(scissor);

				if (!rect.IsEmpty())
				{
					rect.Move(-e.Offset);
					rect.IntersectWith(GetBackgroundRect());

					if (!rect.IsEmpty())
					{
						if (m_DirtyRect.IsEmpty())
							m_DirtyRect = rect;
						else
							m_DirtyRect.UnionWith(rect);
					}
				}
			}

			Core::Rectangle dirty_scissor(scissor);

			if (e.Cached)
			{
				// control is dirty
				if (!m_DirtyRect.IsEmpty())
				{
					// update dirty rect
					m_DirtyRect.Move(e.Offset);
					dirty_scissor.IntersectWith(m_DirtyRect);

					if (!dirty_scissor.IsEmpty())
					{
						// update screen dirty region
						e.DirtyRegion.PushBack(dirty_scissor);
					}

					m_DirtyRect = Core::Rectangle::kInvalid;
				}
				else
				{
					dirty_scissor = Core::Rectangle::kInvalid;
				}
			}

			PaintEventArgs arg;
			arg.render = e.render;
			arg.Enable = e.Enable && m_Enable;
			arg.Offset = e.Offset;

			// draw control
			if (!dirty_scissor.IsEmpty())
			{
				// move dirty region to world space.
				Matrix44 world;
				Vector2 offset = e.Offset;
				world.SetTranslationXYZ(offset.x, offset.y, 0);

				e.render->SetScissorRect(dirty_scissor);
				e.render->SetWorld(world);

				OnPaint(arg);
			}

			// restore scissor to client.
			scissor.Shrink(GetDisplayPadding());
			e.render->SetScissorRect(scissor);

			for (Control * control = m_FirstChild; control; control = control->m_Next)
			{
				if (control->GetVisible())
				{
					e.Enable = arg.Enable;

					control->Render(e);
				}
			}
		}

		e.Offset = old_offset;
		e.render->SetScissorRect(old_scissor);
	}


	Core::Vector2 Control::ScreenToClient( const Vector2 & pos )
	{
		if (m_Parent)
		{
			if(!(ptr_dynamic_cast<GuiSystem>(m_Parent)))
				return m_Parent->ScreenToClient(pos) + m_Scroll - GetLocation();
			else
				return pos + m_Scroll;
		}
		else
		{
			return pos - GetLocation() + m_Scroll;
		}
	}

	Core::Vector2 Control::ClientToScreen( const Vector2 & pos )
	{
		if(m_Parent)
		{
			if(!(ptr_dynamic_cast<GuiSystem>(m_Parent)))
				return m_Parent->ClientToScreen(pos + GetLocation() -m_Scroll);
			else
			{
				if(ptr_dynamic_cast<Window>(this))
					return pos;
				else
					return pos+GetLocation() - m_Scroll;
			}
		}
		else
		{
			return pos + GetLocation() - m_Scroll;
		}
	}

	Core::Vector2 Control::GlobalScreenToClient( const Vector2 & pos )
	{
		if (m_Parent)
		{
			if(!(ptr_dynamic_cast<GuiSystem>(m_Parent)))
				return m_Parent->GlobalScreenToClient(pos) + m_Scroll - GetLocation();
			else
				return pos + m_Scroll - GetLocation();
		}
		else
		{
			return pos - GetLocation() + m_Scroll;
		}
	}

	Core::Vector2 Control::ClientToGlobalScreen( const Vector2 & pos )
	{
		if(m_Parent)
		{
			if(!(ptr_dynamic_cast<GuiSystem>(m_Parent)))
				return m_Parent->ClientToGlobalScreen(pos + GetLocation() -m_Scroll);
			else
			{
				return pos+GetLocation() - m_Scroll;
			}
		}
		else
		{
			return pos + GetLocation() - m_Scroll;
		}
	}	

	F32 Control::TextWidth( const Core::String & text )
	{
		Core::Rectangle rect = GetFont()->MeasureString(Core::Rectangle(0, 0, 0, 0), text, -1, 0);
		F32 length = rect.Max.x - rect.Min.x;
		return length;
	}	

	void Control::DirtyLayout(bool dirtyChilds)
	{
		if (!m_LayoutDirty)
		{
			m_LayoutDirty = true;
			m_RegionDirty = true;

			if (dirtyChilds)
			{
				for (Control * pControl = m_FirstChild; pControl; pControl = pControl->m_Next)
					pControl->DirtyLayout(dirtyChilds);
			}
		}

		Invalid();
	}

	void Control::UpdateLayout(bool updateChilds)
	{
		if (m_LayoutDirty)
		{
			// update layout
			OnLayout(EventArgs());

			m_LayoutDirty = false;

			// update autosize
			if (GetAutoSize())
			{
				AutoSizeEventArgs arg;
				arg.clientRect = Core::Rectangle(0, 0, 0, 0);
				arg.dockRect = Core::Rectangle(0, 0, 0, 0);
				OnAutoSize(arg);
			}

			if (updateChilds)
			{
				for (Control * pControl = m_FirstChild; pControl; pControl = pControl->m_Next)
					if (pControl->GetVisible())
						pControl->UpdateLayout(updateChilds);
			}
		}

	}

	void Control::RemoveAllChildren()
	{
		Core::Array<Control*> AllChildren;
		for (Control * pControl = m_FirstChild; pControl; pControl = pControl->m_Next)
			AllChildren.PushBack(pControl);
		for (int i=0; i<AllChildren.GetCount(); ++i)
		{
			AllChildren[i]->ChangeParent(NullPtr, NullPtr);
		}

		return;
	}

	void Control::IncreaseHoverPower(bool bHover /* = true */)
	{
		float frameTime = Task::GetFrameTime();

		if(m_HoverPower<=0.99f)
		{
			m_HoverPower += frameTime/(bHover?m_CONTROL_HOVER_EFFECT_DURATION:m_CONTROL_SHINE_EFFECT_DURATION);
		}
		if(m_HoverPower>0.99f)
			m_HoverPower = 1.f;
	}

	void Control::DecreaseHoverPower(bool bHover /* = true */)
	{
		float frameTime = Task::GetFrameTime();

		if(m_HoverPower>=0.01f)
		{
			m_HoverPower -= frameTime/(bHover?m_CONTROL_HOVER_EFFECT_DURATION:m_CONTROL_SHINE_EFFECT_DURATION);
		}
		if(m_HoverPower<0.01f)
			m_HoverPower = 0.f;
	}

	void Control::Shine()
	{
		if(m_Shine)
		{
			if(m_HoverIncreasing)
				IncreaseHoverPower(false);
			else
				DecreaseHoverPower(false);

			if(m_HoverPower>0.99f)
			{
				m_HoverIncreasing = false;
			}
			else if(m_HoverPower<0.01f)
			{
				m_HoverIncreasing = true;
			}
			Invalid();
		}
	}

	float Control::GetHoverPower()
	{
		return m_HoverPower;
	}
	// find child
	tempc_ptr(Control) Control::FindChildByText(const Core::String & text)
	{
		for (tempc_ptr(Control) t = GetFirstChild(); t; t = t->GetNext())
		{
			if (t->GetText() == text)
			{
				return t;
			}
		}

		return NullPtr;
	}


	// get child by id
	tempc_ptr(Control) Control::GetChildByIndex(int index)
	{
		tempc_ptr(Control) t = GetFirstChild();

		for (int i = 0; t && i <= index; i ++, t = t->GetNext())
		{
			if (i == index)
				return t;
		}

		return NullPtr;
	}

	/// check if this control is the other control's child
	bool Control::IsChildOf(by_ptr(Control) control)
	{
		tempc_ptr(Control) pParent = control;

		if (pParent)
		{
			tempc_ptr(Control) ptr = GetParent();

			while(ptr && ptr != pParent)
				ptr = ptr->GetParent();

			return ptr == pParent;
		}

		return false;
	}

	// set cursor shape
	void Control::SetCursorShape(Screen::CursorShape shape)
	{
		if (gGame && gGame->guiSys)
			gGame->guiSys->TrySetCursorShape(shape);
	}
}

//--------------------------------------------------------------------------------------
// events
//--------------------------------------------------------------------------------------
namespace Gui
{
	void Control::OnCreate()
	{
		Object::OnCreate();
		m_Size = GetDefaultSize();
	}


	void Control::OnDestroy()
	{
		// release capture
		SetCapture(false);

		ClearAllFrames();
		ClearAllBalloons();
		ClearAllNoticeBoards();

		// remove all children.
		while (m_FirstChild)
			m_FirstChild->ChangeParent(NullPtr, NullPtr);

		Object::OnDestroy();
	}

	void Control::OnInputEvent( InputEventArgs &e )
	{
		switch (e.Type)
		{
		case InputEventArgs::kMouseEnter:	
			OnMouseEnter(e);
			break;
		case InputEventArgs::kMouseLeave:	
			OnMouseLeave(e);
			break;
		case InputEventArgs::kMouseDown:	
			OnMouseDown(e);
			break;
		case InputEventArgs::kMouseUp:	
			OnMouseUp(e);
			break;
		}

		//Mouse event should not penetrate the panel directly under guisystem
		//Or the avatar underneath would be picked through a panel
		if(e.IsMouseEvent())
		{
			if(ptr_dynamic_cast<GuiSystem>(m_Parent))
			{
				e.Handled = true;
			}
		}

		if(e.Type == InputEventArgs::kKeyDown && e.Code == KC_TAB)
		{
			if(GetTabFocus() && !e.Handled)
			{
				if(e.ShiftKeyDown)
				{
					tempc_ptr(Control) prevF = GetPrevFocusableControl();
					if(prevF)
					{
						prevF->SetFocused(true);
					}
				}
				else
				{
					tempc_ptr(Control) nextF = GetNextFocusableControl();
					if(nextF)
					{
						nextF->SetFocused(true);
					}
				}
				e.Handled = true;
			}
		}

		if (!e.Handled && m_Parent)
		{
			m_Parent->OnInputEvent(e);
		}
	}

	void Control::OnPaint(PaintEventArgs & e)
	{
		Core::Rectangle bg_rect = GetBackgroundRect();

		if (m_UseTime)
		{
			if(m_Timer == 0)
				m_Timer = Task::GetTotalTime();
			if ((Task::GetTotalTime() - m_Timer) > m_DisplayTime)
			{
				m_Timer = Task::GetTotalTime();
				m_BackChoose++;
				if (m_BackChoose >= m_BackgroundSum)
				{
					m_BackChoose = 0;
				}	
			}
			if(m_BackgroundImages.Size() > m_BackChoose)
				Skin::DrawImage(e.render, m_BackgroundImages.GetAt(m_BackChoose), bg_rect, m_BackgroundColor);
		}
		else
		{
			tempc_ptr(ControlSkin) skin = GetSkin();
			if (skin)
			{
				Skin::DrawImage(e.render, skin->GetBackgroundImage(), bg_rect, m_BackgroundColor);
			}
			else
			{
				if (m_BackgroundColor.a)
				{
					e.render->SetTexture(NullPtr);
					e.render->DrawRectangle(bg_rect, bg_rect, m_BackgroundColor);
				}
			}
		}
	}

	void Control::OnActiveChanged( EventArgs & e )
	{
		EventActiveChanged.Fire(ptr_static_cast<Control>(this), e);
	}

	void Control::OnEnter( EventArgs & e )
	{
		EventEnter.Fire(ptr_static_cast<Control>(this), e);

		m_Active = true;
		OnActiveChanged(e);
	}

	void Control::OnLeave( EventArgs & e )
	{
		EventLeave.Fire(ptr_static_cast<Control>(this), e);

		m_Active = false;
		OnActiveChanged(e);
	}

	void Control::OnMouseDown(Client::InputEventArgs & e)
	{
		EventMouseDown.Fire(ptr_static_cast<Control>(this), e);
	}

	void Control::OnMouseUp(Client::InputEventArgs & e)
	{
		if (e.Code == MC_RIGHT_BUTTON)
			EventMouseRightUp.Fire(ptr_static_cast<Control>(this), e);
		else
			EventMouseUp.Fire(ptr_static_cast<Control>(this), e);
	}

	void Control::OnMouseEnter(Client::InputEventArgs & e)
	{
		EventMouseEnter.Fire(ptr_static_cast<Control>(this), e);
		if (!e.Handled && (m_Hint.Length() != 0))
		{
			if (!s_ToolTip) {
				s_ToolTip = ptr_new ToolTip;
			}

			Vector2 origin = ClientToGlobalScreen(Vector2::kZero);
			s_ToolTip->ShowStart(ptr_static_cast<Control>(gGame->guiSys), Core::Rectangle::LeftTop(origin, GetSize()), m_Hint);
		}
	}

	void Control::OnMouseLeave(Client::InputEventArgs & e)
	{
		EventMouseLeave.Fire(ptr_static_cast<Control>(this), e);
		if (!e.Handled)
		{
			if(s_ToolTip) {
				s_ToolTip->Close();
			}
		}
	}
	void Control::OnFocusChanged(EventArgs & e)
	{
	}

	void Control::OnFocusControlChanged(FocusEventArgs & e)
	{
		EventFocusControlChanged.Fire(ptr_static_cast<Control>(this), e);
	}

	void Control::OnFrameUpdate( EventArgs & e )
	{
// 		if(m_Balloon && m_Balloon->GetParent())
// 		{
// 			m_Balloon->SetVisible(GetVisibility());
// 		}
	}

	void Control::OnVisibleChanged(EventArgs & e)
	{
		Invalid();

		if (m_Parent)
			m_Parent->DirtyLayout();
	}

	void Control::OnTextChanged(EventArgs & e)
	{
		Invalid();
	}


	void Control::OnEnableChanged(EventArgs & e)
	{
		Invalid();
	}

	void Control::OnLocationChanged(MoveEventArgs & e)
	{
		Invalid();

		if (m_Parent)
			m_Parent->DirtyLayout();

		UpdateBalloon();
		UpdateFrame();
		UpdateNoticeBoard();
	}

	void Control::OnSizeChanged(ResizeEventArgs & e)
	{
		EventSizeChanged.Fire(ptr_static_cast<Control>(this), e);

		Invalid();
		DirtyLayout();

		if (m_Parent)
			m_Parent->DirtyLayout();

		UpdateBalloon();
		UpdateFrame();
		UpdateNoticeBoard();
	}


	void Control::OnAutoSize(AutoSizeEventArgs & e)
	{
		// childs
		for (Control * pControl = m_FirstChild; pControl; pControl = pControl->m_Next)
		{
			if(pControl->GetVisible())
			{
				const Vector2& ctrlLocation = pControl->GetLocation();
				const Vector2& ctrlSize = pControl->GetSize();
				const Vector4& ctrlMargin = pControl->GetMargin();

				switch(pControl->GetDock())
				{
				case kDockNone:
					e.clientRect.UnionWith(Core::Rectangle(ctrlLocation-Vector2(ctrlMargin.x, ctrlMargin.y), ctrlLocation+ctrlSize+Vector2(ctrlMargin.z, ctrlMargin.w)));
					break;

				case kDockLeft:
					e.dockRect.Min.x -= ctrlSize.x + ctrlMargin.x + ctrlMargin.z;
					break;

				case kDockRight:
					e.dockRect.Max.x += ctrlSize.x + ctrlMargin.x + ctrlMargin.z;
					break;

				case kDockTop:
					e.dockRect.Min.y -= ctrlSize.y + ctrlMargin.y + ctrlMargin.w;
					break;

				case kDockBottom:
					e.dockRect.Max.y += ctrlSize.y + ctrlMargin.y + ctrlMargin.w;
					break;
				}
			}
		}
		Vector4 padding = GetPadding();
		Vector2 newSize = e.GetSize() + Vector2(padding.x + padding.z, padding.y + padding.w);
		switch (GetDock())
		{
		case kDockTop:
		case kDockBottom:	newSize.x = GetSize().x; break;
		case kDockLeft:
		case kDockRight:	newSize.y = GetSize().y; break;
		case kDockFill:		newSize = GetSize();	 break;
		}
		SetSize(newSize);
	}

	void Control::OnLayout(EventArgs & e)
	{
		m_DockClient.Min = Vector2::kZero;
		m_DockClient.Max = m_Size;
		m_DockClient.Shrink(GetPadding());

		// childs
		for (Control * pControl = m_FirstChild; pControl; pControl = pControl->m_Next)
		{
			if (pControl->GetVisible())
			{
				// location and size
				Vector2 location = pControl->GetLocation();
				Vector2 size = pControl->GetSize();
				Vector4 margin = pControl->GetMargin();
				Core::Rectangle & dockClient = m_DockClient;

				// calculate dock
				switch (pControl->m_Dock)
				{
				case kDockLeft:
					location.x = dockClient.Min.x + margin.x;
					location.y = dockClient.Min.y + margin.y;
					size.y = dockClient.Max.y - dockClient.Min.y - margin.y - margin.w;
					dockClient.Min.x += size.x + margin.x + margin.z;
					break;

				case kDockRight:
					location.x = dockClient.Max.x - margin.z - size.x;
					location.y = dockClient.Min.y + margin.y;
					size.y = dockClient.Max.y - dockClient.Min.y - margin.y - margin.w;
					dockClient.Max.x -= size.x + margin.x + margin.z;
					break;

				case kDockTop:
					location.x = dockClient.Min.x + margin.x;
					location.y = dockClient.Min.y + margin.y;
					size.x = dockClient.Max.x - dockClient.Min.x - margin.x - margin.z;
					dockClient.Min.y += size.y + margin.y + margin.w;
					break;

				case kDockBottom:
					location.x = dockClient.Min.x + margin.x;
					location.y = dockClient.Max.y - margin.w - size.y;
					size.x = dockClient.Max.x - dockClient.Min.x - margin.x - margin.z;
					dockClient.Max.y -= size.y + margin.y + margin.w;
					break;

				case kDockFill:
					location.x = dockClient.Min.x + margin.x;
					location.y = dockClient.Min.y + margin.y;
					size.x = dockClient.Max.x - dockClient.Min.x - margin.x - margin.z;
					size.y = dockClient.Max.y - dockClient.Min.y - margin.y - margin.w;

					break;
				case kDockLeftTop:
					location.x = dockClient.Min.x + margin.x;
					location.y = dockClient.Min.y + margin.y;
					break;

				case kDockRightTop:
					location.x = dockClient.Max.x - size.x - margin.z;
					location.y = dockClient.Min.y + margin.y;
					break;

				case kDockLeftBottom:
					location.x = dockClient.Min.x+margin.x;
					location.y = dockClient.Max.y-size.y-margin.w;
					break;

				case kDockRightBottom:
					location.x = dockClient.Max.x - size.x - margin.z;
					location.y = dockClient.Max.y - size.y - margin.w;
					break;

				case kDockCenter:
					location.x = dockClient.Min.x +(dockClient.Max.x - dockClient.Min.x - size.x)/2;
					location.y = dockClient.Min.y +(dockClient.Max.y - dockClient.Min.y - size.y)/2;
					break;

				case kDockTopCenter:
					location.x = dockClient.Min.x +(dockClient.Max.x-dockClient.Min.x-size.x)/2;
					location.y = dockClient.Min.y + margin.y;
					break;

				case kDockHorizontalCenter:
					location.x = dockClient.Min.x + margin.x;
					location.y = dockClient.Min.y + (dockClient.Max.y-dockClient.Min.y-size.y)/2;
					size.x = dockClient.Max.x - dockClient.Min.x - margin.x - margin.z;
					break;

				case kDockBottomCenter:
					location.x = dockClient.Min.x +(dockClient.Max.x-dockClient.Min.x-size.x)/2;
					location.y = dockClient.Max.y - size.y - margin.w;
					break;
				};
				
				location.x = Core::Floor(location.x+0.5f);
				location.y = Core::Floor(location.y+0.5f);
				size.x = Core::Floor(size.x+0.5f);
				size.y = Core::Floor(size.y+0.5f);
				pControl->SetLocation(location);
				pControl->SetSize(size);
			}
		}
	}

	// on background color changed
	void Control::OnBackgroundColorChanged(EventArgs & e)
	{

	}

	// on font changed
	void Control::OnFontChanged(EventArgs & e)
	{
	}

	// on style changed
	void Control::OnStyleChanged(EventArgs & e)
	{
		StyleChangeEventArgs arg;
		arg.control = ptr_static_cast<Control>(this);
		arg.style = m_Style;

		if (gGame && gGame->guiSys)
			gGame->guiSys->OnControlStyleChanged(arg);
	}

	//on parent changed
	void Control::OnChildrenChanged(ChildrenChangedEventArgs & e)
	{

	}

	// on parent changed
	void Control::OnParentChanged(EventArgs & e)
	{
	}

	// on language changed
	void Control::OnLanguageChanged(EventArgs & e)
	{
		if (m_UseTextKey && m_TextKey.Length() > 0)
		{
			Core::String value = gLang->GetText(m_TextKey);
			if (m_Text != value)
			{
				m_Text = value;
				OnTextChanged(EventArgs());
			}
		}

		for (tempc_ptr(Control) control = GetFirstChild(); control; control = control->GetNext())
		{
			control->OnLanguageChanged(e);
		}
	}

	void Control::AddFrame(sharedc_ptr(Image) &e)
	{
		if (e)
		{
			m_BackgroundImages.Add(e);
			m_BackgroundSum++;
		}	
	}

	void Control::DeleteAllImage()
	{
		m_BackgroundImages.Clear();
		m_BackgroundSum = 0;
		m_BackChoose = 0;
	}

	int Control::SplitString( const Core::String& source, Core::String& target, const Core::Rectangle& rect, tempc_ptr(Client::Font) font )
	{
		if(!rect.IsValid() || rect.IsEmpty())
			return 0;
		F32 maxWidth = rect.GetExtent().x;
		return SplitString(source, target, maxWidth, font);
	}

	int Control::SplitString( const Core::String& source, Core::String& target, F32 maxWidth, tempc_ptr(Client::Font) font )
	{
		if(!font)
			return 0;
		if(maxWidth<20)
			return 0;
		int lineNum = source.Length()?1:0;
		target = source;
		while(true)
		{
			Core::Rectangle tempRect = Core::Rectangle(0,0,0,0);
			Vector2 o = font->MeasureString(tempRect, target, -1, Unit::kAlignCenterMiddle).GetExtent();

			if(o.x<maxWidth)
				break;

			lineNum++;

			size_t pt = target.Length();
			do{
				pt--;
				o = font->MeasureString(tempRect, target, pt, Unit::kAlignCenterMiddle).GetExtent();				
			}while(o.x>=maxWidth);
#ifdef USE_UTF8
			while (!IsUTF8LeadByte(target[pt]))
			{
				pt--;
			}
#else
			if (!IsASCIIByte(target[pt]) && IsDBCSLeadByteEx(936, target[pt-1]))
			{
				pt--;
			}
#endif
			CRefStr &str = target.RefStr(target.Length()+2);
			str.insert(pt, '\n');

			if(lineNum>40)
				break;
		}
		return lineNum;
	}

	int Control::EllipsisString( const Core::String& source, Core::String& target, const Core::Vector2& boundary, tempc_ptr(Client::Font) font )
	{
		if(!font || source.Length()<=0)
		{
			target = source;
			return -1;
		}

		F32 ellipsisWidth = 24;
		char* ellipsis = ".";
		font->PreBuild(ellipsis);
		const Font::CharInfo info = font->GetCharacterInfo('.');
		ellipsisWidth = (info.horiBearingX + info.width)*4;

		if(boundary.x<ellipsisWidth || boundary.y<8)
		{
			target = source;
			return -1;
		}

		bool bMultiline = (source.RefStr().find('\n')>=0);
		if(!bMultiline)
		{
			int lastChar = font->MeasureFindFirstExceedingChar(boundary, source);
			if(lastChar>=0)
			{
				lastChar = font->MeasureFindFirstExceedingChar(Vector2(boundary.x-ellipsisWidth, boundary.y), source);
				
				String cstr = String::Format("%s", source);
				CRefStr str(cstr.RefStr());
				str.setlen(lastChar);
				str.contract("...");
				target=str;
				return lastChar;
			}
			else
			{
				target = source;
				return -1;
			}
		}
		else
		{
			int lastChar = font->MeasureFindFirstExceedingChar(boundary, source);
			if(lastChar>=0)
			{
				String cstr = String::Format("%s", source);
				CRefStr str(cstr.RefStr());
				str.setlen(lastChar);
				int lastReturn = str.rfind('\n');
				if(lastReturn<0)
				{
					//Same as single line
					lastChar = font->MeasureFindFirstExceedingChar(Vector2(boundary.x-ellipsisWidth, boundary.y), source);
					if(lastChar<0)
					{
						str.contract("...");
					}
					else
					{
						str.setlen(lastChar);
						str.contract("...");							
					}
				}
				else
				{
					str.setlen(lastReturn);
					str.contract("\n...");
				}
				target=str;
				return lastChar;
			}
			else
			{
				target = source;
				return -1;
			}			
		}
	}

	void Control::BalloonInternal(const Core::String& str, int style, Core::Rectangle rect)
	{
		if(!m_Balloon)
		{
			m_Balloon = ptr_new Gui::Balloon;
		}
		m_Balloon->SetOwner(ptr_static_cast<Control>(this));
		switch (style)
		{
		case 0:
			m_Balloon->SetStyle("Gui.Balloon");
			break;
		case 1:
			m_Balloon->SetStyle("Gui.SmallBalloon");
			break;
		default:
			m_Balloon->SetStyle("Gui.Balloon");
		}
		m_Balloon->SetText(str);
		m_Balloon->Show(rect, m_CONTROL_BALLOON_FRAME_DURATION);

	}

	void Control::Balloon( const Core::String& str )
	{
		Vector2 origin = ClientToGlobalScreen(Vector2::kZero);
		BalloonInternal(str, 0, Core::Rectangle::LeftTop(origin, GetSize()));
	}
	void Control::Balloon2( const Core::String& str )
	{
		Vector2 origin = ClientToGlobalScreen(Vector2::kZero);
		BalloonInternal(str, 1, Core::Rectangle::LeftTop(origin, GetSize()));
	}

	bool Control::GetVisibility()
	{
		if(m_Parent)
			return (m_Visible && m_Parent->GetVisibility());
		else
			return false;
	}

	void Control::CancelBalloon()
	{
		if(m_Balloon)
			m_Balloon->Cancel();
	}

	void Control::UpdateBalloon()
	{
		if(m_Balloon && m_Balloon->GetParent())
		{
			Vector2 origin = ClientToGlobalScreen(Vector2::kZero);
			m_Balloon->UpdateLocation(Core::Rectangle::LeftTop(origin, GetSize()));
		}

		for (Control * control = m_FirstChild; control; control = control->m_Next)
		{
			control->UpdateBalloon();
		}
	}


	void Control::PopFrameInternal( Core::Rectangle rect )
	{

		if(!m_PopupFrame)
		{
			m_PopupFrame = ptr_new Gui::PopupFrame;
		}
		m_PopupFrame->SetOwner(ptr_static_cast<Control>(this));
		m_PopupFrame->SetStyle("Gui.PopupFrame");
		m_PopupFrame->Show(rect, m_CONTROL_BALLOON_FRAME_DURATION);
	}

	void Control::PopFrame()
	{
		Vector2 origin = ClientToGlobalScreen(Vector2::kZero);
		PopFrameInternal(Core::Rectangle::LeftTop(origin, GetSize()));
	}

	void Control::CancelFrame()
	{
		if(m_PopupFrame)
			m_PopupFrame->Cancel();
	}

	void Control::UpdateFrame()
	{
		if(m_PopupFrame && m_PopupFrame->GetParent())
		{
			Vector2 origin = ClientToGlobalScreen(Vector2::kZero);
			m_PopupFrame->UpdateLocation(Core::Rectangle::LeftTop(origin, GetSize()));
		}

		for (Control * control = m_FirstChild; control; control = control->m_Next)
		{
			control->UpdateFrame();
		}		
	}

	void Control::PopNoticeBoardInternal( const Core::String& str, Core::Rectangle rect )
	{
		if(!m_NoticeBoard)
		{
			m_NoticeBoard = ptr_new Gui::NoticeBoard;
		}
		m_NoticeBoard->SetOwner(ptr_static_cast<Control>(this));
		m_NoticeBoard->SetStyle("Gui.NoticeBoard");
		m_NoticeBoard->SetText(str);
		m_NoticeBoard->Show(rect, m_CONTROL_BALLOON_FRAME_DURATION);
	}

	void Control::PopNoticeBoard( const Core::String& str )
	{
		Vector2 origin = ClientToGlobalScreen(Vector2::kZero);
		PopNoticeBoardInternal(str, Core::Rectangle::LeftTop(origin, GetSize()));
	}

	void Control::CancelNoticeBoard()
	{
		if(m_NoticeBoard)
			m_NoticeBoard->Cancel();
	}

	void Control::UpdateNoticeBoard()
	{
		if(m_NoticeBoard && m_NoticeBoard->GetParent())
		{
			Vector2 origin = ClientToGlobalScreen(Vector2::kZero);
			m_NoticeBoard->UpdateLocation(Core::Rectangle::LeftTop(origin, GetSize()));
		}

		for (Control * control = m_FirstChild; control; control = control->m_Next)
		{
			control->UpdateNoticeBoard();
		}
	}

	tempc_ptr(Control) Control::GetNextLeaf()
	{
		tempc_ptr(Control) nextNode = GetNext();
		if(nextNode)
		{
			while(nextNode->GetFirstChild())
			{
				nextNode = nextNode->GetFirstChild();
			}
			return nextNode;
		}
		else
		{
			tempc_ptr(Control) parent = GetParent();
			if(parent)
			{
				return parent->GetNextLeaf();
			}
			else
			{
				return NullPtr;
			}
		}
	}

	tempc_ptr(Control) Control::GetPrevLeaf()
	{
		tempc_ptr(Control) prevNode = GetPrevious();
		if(prevNode)
		{
			while(prevNode->GetLastChild())
			{
				prevNode = prevNode->GetLastChild();
			}
			return prevNode;
		}
		else
		{
			tempc_ptr(Control) parent = GetParent();
			if(parent)
			{
				return parent->GetPrevLeaf();
			}
			else
			{
				return NullPtr;
			}
		}		
	}

	tempc_ptr(Control) Control::GetNextFocusableControl()
	{
		tempc_ptr(Control) nextLeaf = GetNextLeaf();
		while(nextLeaf)
		{
			if(nextLeaf->GetVisible() && nextLeaf->GetEnable() && nextLeaf->GetCanFocus() && nextLeaf->GetTabFocus())
			{
				break;
			}
			nextLeaf = nextLeaf->GetNextLeaf();
		}
		return nextLeaf;
	}

	tempc_ptr(Control) Control::GetPrevFocusableControl()
	{
		tempc_ptr(Control) prevLeaf = GetPrevLeaf();
		while(prevLeaf)
		{
			if(prevLeaf->GetVisible() && prevLeaf->GetEnable() && prevLeaf->GetCanFocus() && prevLeaf->GetTabFocus())
			{
				break;
			}
			prevLeaf = prevLeaf->GetPrevLeaf();
		}
		return prevLeaf;
	}

	void Control::ClearAllFrames()
	{
		if(m_PopupFrame)
			m_PopupFrame->Terminate();
		for (tempc_ptr(Control) control = GetFirstChild(); control; control = control->GetNext())
		{
			control->ClearAllFrames();
		}	
	}

	void Control::ClearAllBalloons()
	{
		if(m_Balloon)
			m_Balloon->Terminate();
		for (tempc_ptr(Control) control = GetFirstChild(); control; control = control->GetNext())
		{
			control->ClearAllBalloons();
		}	
	}

	void Control::ClearAllNoticeBoards()
	{
		if(m_NoticeBoard)
			m_NoticeBoard->Terminate();
		for (tempc_ptr(Control) control = GetFirstChild(); control; control = control->GetNext())
		{
			control->ClearAllNoticeBoards();
		}
	}

	void Control::RearrangeChildren()
	{

	}
}

namespace Gui
{
	void TimeControl::AddTime(float t)
	{
		mTimers.PushBack(t);
	}
	void TimeControl::CleanAll()
	{
		mTimers.Clear();
	}
	void TimeControl::OnFrameUpdate(EventArgs & e)
	{
		if (mTimers.Size() > 0)
		{
			if (mTimers[0] > 0)
			{
				mTimers[0] -= Task::GetFrameTime();
				EventTimeUpdate.Fire(ptr_static_cast<TimeControl>(this), e);
			}
			else
			{
				mTimers.RemoveAt(0);
				EventTimeOut.Fire(ptr_static_cast<TimeControl>(this), e);
			}
		}
	}
}