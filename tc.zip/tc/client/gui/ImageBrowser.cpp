#include "pch.h"

using namespace Core;
using namespace Gui;
using namespace Client;

//--------------------------------------------------------------------------------------
// type info
//--------------------------------------------------------------------------------------
DEFINE_PDE_TYPE_CLASS(ImageBrowser)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Control);
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_METHOD(GetDisplayPicture);
		ADD_PDE_METHOD(LeftBtnClick);
		ADD_PDE_METHOD(RightBtnClick);
		ADD_PDE_METHOD(AllPictureHL);
		ADD_PDE_METHOD(AllPictureClicked);

		ADD_PDE_PROPERTY_R(LeftBtn);
		ADD_PDE_PROPERTY_R(RightBtn);
		ADD_PDE_PROPERTY_RW(NumSkip);
		ADD_PDE_PROPERTY_RW(DisplayRowAndCol);
		ADD_PDE_PROPERTY_RW(PictureStyle);
		ADD_PDE_PROPERTY_RW(LButtonStyle);
		ADD_PDE_PROPERTY_RW(RButtonStyle);
		ADD_PDE_PROPERTY_RW(PWidth);
		ADD_PDE_PROPERTY_RW(PHeight);

		ADD_PDE_PROPERTY_RW(Loading);
		ADD_PDE_PROPERTY_RW(LoadingImage);
	}
};
REGISTER_PDE_TYPE(ImageBrowser);

namespace Gui
{
	ImageBrowser::ImageBrowser()
	: m_display_row(2)
	, m_display_col(3)
	, m_NumSkip(1)
	, m_PHeight(0)
	, m_PWidth(0)
	, m_IsLoading(false)
	, m_StartLoading(false)
	{
		SetBackgroundColor(ARGB(0,255,255,255));
	}

	ImageBrowser::~ImageBrowser()
	{
	}
}

//--------------------------------------------------------------------------------------
// Attribute
//--------------------------------------------------------------------------------------
namespace Gui
{
	PDE_ATTRIBUTE_GETTER(ImageBrowser,PWidth,F32)
	{
		return m_PWidth;
	}

	PDE_ATTRIBUTE_SETTER(ImageBrowser,PWidth,F32)
	{
		m_PWidth = value;
	}

	PDE_ATTRIBUTE_GETTER(ImageBrowser,PHeight,F32)
	{
		return m_PHeight;
	}

	PDE_ATTRIBUTE_SETTER(ImageBrowser,PHeight,F32)
	{
		m_PHeight = value;
	}


	PDE_ATTRIBUTE_GETTER(ImageBrowser, DisplayRowAndCol, Vector2)
	{
		return Vector2(m_display_row, m_display_col);
	}


	PDE_ATTRIBUTE_SETTER(ImageBrowser, DisplayRowAndCol, Vector2)
	{
		m_display_row = value.x;
		m_display_col = value.y;
		Init();
	}	
	
	PDE_ATTRIBUTE_GETTER(ImageBrowser, LeftBtn, sharedc_ptr(Button))
	{
		return m_Left;
	}


	PDE_ATTRIBUTE_GETTER(ImageBrowser, RightBtn, sharedc_ptr(Button))
	{
		return m_Right;
	}

	PDE_ATTRIBUTE_GETTER(ImageBrowser, LButtonStyle, const Core::String&)
	{
		if(m_Left)
			return m_Left->GetStyle();
		else
			return Core::String::kEmpty;
	}

	PDE_ATTRIBUTE_SETTER(ImageBrowser, LButtonStyle, const Core::String&)
	{
		if(m_Left)
			m_Left->SetStyle(value);
		//No need to invalid
	}	

	PDE_ATTRIBUTE_GETTER(ImageBrowser, RButtonStyle, const Core::String&)
	{
		if(m_Right)
			return m_Right->GetStyle();
		else
			return Core::String::kEmpty;
	}

	PDE_ATTRIBUTE_SETTER(ImageBrowser, RButtonStyle, const Core::String&)
	{
		if(m_Right)
			m_Right->SetStyle(value);
		//No need to invalid
	}	

	PDE_ATTRIBUTE_GETTER(ImageBrowser, PictureStyle, const Core::String&)
	{
		return m_PictureStyle;
	}

	PDE_ATTRIBUTE_SETTER(ImageBrowser, PictureStyle, const Core::String&)
	{
		m_PictureStyle = value;
		//No need to invalid
	}	
		
	PDE_ATTRIBUTE_GETTER(ImageBrowser, NumSkip, U32)
	{
		return m_NumSkip;
	}

	PDE_ATTRIBUTE_SETTER(ImageBrowser, NumSkip, U32)
	{
		m_NumSkip = value;
	}

	PDE_ATTRIBUTE_GETTER(ImageBrowser, Loading, bool)
	{
		return m_IsLoading;
	}
	PDE_ATTRIBUTE_SETTER(ImageBrowser, Loading, bool)
	{
		if(m_IsLoading == value)
			return;

		m_IsLoading = value;
		if(m_IsLoading)
			m_StartLoading = true;
		else
			m_StartLoading = false;

		for(U32 i=0; i<m_display_row; ++i) 
		{
			for(U32 j=0; j<=m_display_col; j++) {
				if(m_Row.GetCount()>0)
					m_Row[i]->GetAt(j)->SetLoading(m_IsLoading);
			}
		}
	}

	PDE_ATTRIBUTE_GETTER(ImageBrowser, LoadingImage, tempc_ptr(AnimatedImage))
	{
		return m_LoadingImage;
	}

	PDE_ATTRIBUTE_SETTER(ImageBrowser, LoadingImage, tempc_ptr(AnimatedImage))
	{
		if(m_LoadingImage!=value)
		{
			m_LoadingImage = value;
		}
	}

}

namespace Gui
{	
	sharedc_ptr(ItemPicture) ImageBrowser::GetDisplayPicture(U32 row, U32 col)
	{
		return m_Row[row-1]->GetAt(col-1);
	}
}

namespace Gui
{
	void ImageBrowser::Init()
	{
		for(int i=0; i<m_Row.GetCount(); i++)
		{
			tempc_ptr(Array<sharedc_ptr(ItemPicture)>) tempRow = m_Row[i];
			for(int j=0; j<tempRow->GetCount(); j++)
			{
				tempRow->GetAt(j)->SetParent(NullPtr);
			}
		}
		m_Row.Clear();
		for(U32 i=0; i<m_display_row; ++i) {
			sharedc_ptr(Array<sharedc_ptr(ItemPicture)>) row = ptr_new Array<sharedc_ptr(ItemPicture)>;
			m_Row.Add(row);
			for(U32 j=0; j<=m_display_col; j++) {
				sharedc_ptr(ItemPicture) pPic = ptr_new ItemPicture;
				pPic->SetBackgroundColor(Core::ARGB(0,255,255,255));
				pPic->SetParent(ptr_static_cast<Self>(this));
				pPic->SetBeStatic(false);
				pPic->SetStyle(m_PictureStyle);
				pPic->SetLoadingImage(m_LoadingImage);		
				pPic->SetID(j + 1);
				m_Row[i]->Add(pPic);
			}
		}
		DirtyLayout();
	}

	void ImageBrowser::LeftBtnClick()
	{
		sharedc_ptr(ItemPicture) temp = NullPtr;
		sharedc_ptr(Array<sharedc_ptr(ItemPicture)>) row = NullPtr;
#if 1
		for(U32 i = 0; i < m_display_row; ++i) {
			row = m_Row[i];
			temp = row->GetAt(0);
			temp->SetForeGroundImage(NullPtr);
			for(U32 j = 1; j <= m_display_col; ++j) {
				(*row)[j-1] = row->GetAt(j);
				if( j == m_display_col ) (*row)[j] = temp;
			}
		}
#endif

#if 0
		for(U32 i = 0; i < m_display_row; ++i) {
			row = m_Row[i];
			if(m_NumSkip < m_display_col) {
				for(U32 n = 0; n < m_NumSkip; ++n) {
					temp = row->GetAt(0);
					for(U32 j = 1; j <= m_display_col; ++j) {
						(*row)[j-1] = row->GetAt(j);
						if(j == m_display_col) (*row)[j]=temp;
					}
				}
			}
			else {
			}
		}
#endif
		for(U32 i=0; i<m_display_row; ++i) {
			m_Row[i]->GetAt(m_display_col)->SetVisible(false);
			for(U32 j=0; j < m_display_col; ++j) {
				m_Row[i]->GetAt(j)->SetID(j + 1);
			}
		}
	}

	void ImageBrowser::RightBtnClick()
	{		
		sharedc_ptr(ItemPicture) temp = NullPtr;
		sharedc_ptr(Array<sharedc_ptr(ItemPicture)>) row = NullPtr;
		
#if 1
		for(U32 i = 0; i < m_display_row; ++i) {
			row = m_Row[i];
			temp = row->GetAt(m_display_col);
			temp->SetForeGroundImage(NullPtr);
			for(S32 j = m_display_col-1; j >= 0; --j) {
				(*row)[j+1] = row->GetAt(j);
				if( j==0 ) (*row)[j] = temp;
			}
		}
#endif

#if 0
		for(U32 i = 0; i < m_display_row; ++i) {
			row = m_Row[i];
			for(U32 n = 0; n < m_NumSkip; ++n) {
				temp=row->GetAt(m_display_col);
				for(S32 j = m_display_col-1; j >= 0; --j) {
					(*row)[j+1] = row->GetAt(j);
					if(j==0) (*row)[j]=temp;
				}
			}
		}
#endif
		for(U32 i=0; i<m_display_row; ++i) {
			m_Row[i]->GetAt(m_display_col)->SetVisible(false);
			for(U32 j=0; j < m_display_col; ++j) {
				m_Row[i]->GetAt(j)->SetID(j + 1);
			}
		}
	}

	void ImageBrowser::AllPictureHL(bool b)
	{			
		for(U32 i=0; i<m_display_row; ++i) {
			for(U32 j=0; j<=m_display_col; j++) {
				if(m_Row.GetCount()>0)
					m_Row[i]->GetAt(j)->SetHighlighted(b);
			}
		}
	}	
	
	void ImageBrowser::AllPictureClicked(bool b)
	{			
		for(U32 i=0; i<m_display_row; ++i) {
			for(U32 j=0; j<=m_display_col; j++) {
				if(m_Row.GetCount()>0)
					m_Row[i]->GetAt(j)->SetClicked(false);
			}
		}
	}
}

namespace Gui
{
	void ImageBrowser::OnCreate()
	{
		Super::OnCreate();
		m_Left = ptr_new Button;
		m_Left->SetParent(ptr_static_cast<Self>(this));
		m_Right = ptr_new Button;
		m_Right->SetParent(ptr_static_cast<Self>(this));

		m_Left->SetSize(Vector2(18,18));
		m_Right->SetSize(Vector2(18,18));

		Init();
	}

	

	void ImageBrowser::OnLayout(EventArgs & e)
	{
		m_Left->SetLocation(Vector2(0, m_Size.y-m_Left->GetSize().y));
		m_Right->SetLocation(Vector2(GetSize().x-m_Right->GetSize().x, m_Size.y - m_Right->GetSize().y));

		/*
		if(m_PWidth!=0&&m_PHeight!=0)
		{
			ratio = m_PWidth/m_PHeight;

		}
		*/
		//set display layout
		float width=(m_Size.x-80) / m_display_col;
		float height=(m_Size.y-28) / m_display_row;
        if(m_display_col == 4) {
		    width=(m_Size.x-90) / m_display_col;
		    height=(m_Size.y-30) / m_display_row;
        }
		
		if(m_PWidth!=0&&m_PHeight!=0)
		{
			width = m_PWidth;
			height = m_PHeight;
		}
		//width = height*ratio;

		for(U32 i=0; i<m_display_row; ++i) {

			for(U32 j=0; j<=m_display_col; j++) {

				tempc_ptr(ItemPicture) pic = m_Row[i]->GetAt(j);
				
				pic->SetDock(Control::kDockNone);

				pic->SetSize(Vector2(width, height));
				
				pic->SetLocation(Vector2(30 + j*(width+10), 10 + i*(height+10)));

				if((pic->GetLocation()).x > width*m_display_col)
					pic->SetVisible(false);
				else {
					pic->SetVisible(true);
				}
				
				//pic->SetBackgroundColor(XRGB(128, 128, 128));
			}
		}
		
		Super::OnLayout(e);

		Invalid();
	}

	void ImageBrowser::OnFrameUpdate(EventArgs & e)
	{
		if(m_IsLoading && m_LoadingImage)
		{
			float frameTime = Task::GetFrameTime();

			int oldFrame = m_LoadingImage->GetCurrentFrame();
			int newFrame = m_LoadingImage->Update(frameTime);

			if(m_StartLoading)
			{
				m_LoadingImage->Reset();
				m_StartLoading = false;
			}

			if(oldFrame!=newFrame && m_Row.GetCount()>0)
			{
				for(U32 i=0; i<m_display_row; ++i) 
				{
					for(U32 j=0; j<=m_display_col; j++)
					{
						m_Row[i]->GetAt(j)->Invalid();
					}
				}
			}
		}
	}

	void ImageBrowser::OnPaint(PaintEventArgs & e)
	{
		Super::OnPaint(e);
	}

	void ImageBrowser::OnInputEvent(InputEventArgs & e)
	{
		if (e.IsMouseEvent())
		{
			Core::Vector2 localPos = ScreenToClient(e.CursorPosition);

			Core::Rectangle displayRect = GetDisplayRect();

			bool pointed = false;
			pointed = displayRect.IsPointInside(localPos);

			//if (pointed)
			//{
				switch(e.Type)
				{
				case InputEventArgs::kMouseDown:
					{
						if ((e.Code == MC_LEFT_BUTTON || e.Code == MC_RIGHT_BUTTON) && pointed)
						{
							SetCapture(true);

							e.Handled = true;

							Invalid();
						}
					}
					break;

				case InputEventArgs::kMouseUp:
					{
						SetCapture(false);
						
						e.Handled = true;
					}
					break;

				case InputEventArgs::kMouseMove:
					{				
						e.Handled = true;
					}
					break;
				}
		//	}
		}

		if (!e.Handled)
			Super::OnInputEvent(e);
	}
}

