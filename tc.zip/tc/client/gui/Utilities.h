namespace Gui
{
	class Control;
	class ListItem;
	class ListItemSkin;

	using Core::EventArgs;
	using Client::InputEventArgs;
	using Core::ValueChangeEventArgs;

	/// when send msg ,event.Fire(e)
	struct MsgSendEventArgs : public EventArgs
	{
		int ChannelID;
		Core::String From;
		Core::String To;
		Core::String Content;
	};
	
	/// parent changed event args
	struct ChildrenChangedEventArgs : public EventArgs
	{
		Core::Bool removed;
		sharedc_ptr(Control) Control;
		//ChildrenChangedEventArgs()
		//	: removed(true)
		//{}
	};

	/// tab changed event args
	struct TabChangedEventArgs : public ValueChangeEventArgs
	{
		Core::Bool byUserOp;	//by mouse or by statement
	};

	/// Focus event args
	struct FocusEventArgs : public EventArgs
	{
		tempc_ptr(Control) Control;
	};


	// resize event args
	struct ResizeEventArgs : public EventArgs
	{
		Core::Vector2 OldSize;
		Core::Vector2 NewSize;
	};

	// resize BorderSize event args
	struct ReBorderSizeEventArgs : public EventArgs
	{
		Core::Vector4 OldBorderSize;
		Core::Vector4 NewBorderSize;
	};

	// move event args
	struct MoveEventArgs : public EventArgs
	{
		Core::Vector2 OldPosition;
		Core::Vector2 NewPosition;
	};

	// paint event args
	struct PaintEventArgs : public EventArgs
	{
		tempc_ptr(Client::UIRender) render;
		tempc_ptr(Gui::Control) control;

		Core::Bool		Enable;
		Core::Vector2	Offset;
		Core::ARGB		BackgroundColor ;

		PaintEventArgs()
			: Enable(true)
		{}
	};

	/// Header event args
	struct HeaderEventArgs : public EventArgs
	{
		U32 Column;

		// constructor
		HeaderEventArgs()
			: Column(0)
		{
		}
	};

	// render event args
	struct RenderEventArgs : public PaintEventArgs
	{
		bool Cached;
		Core::Array<Core::Rectangle> DirtyRegion;

		RenderEventArgs() : Cached(false) {}
		RenderEventArgs(const PaintEventArgs & p)
		{
			Cached = false;
			render = p.render;
			Enable = p.Enable;
			Offset = p.Offset;
		}
	};

	// style changed event args
	struct StyleChangeEventArgs : public EventArgs
	{
		tempc_ptr(Control) control;
		Core::String style;
	};


	/// drag event args  must initialize input
	struct DragEventArgs : EventArgs
	{
		enum DragDropEfferts
		{
			kNone = 0,
			kCopy = 1,
			kMove = 2,
			kLink = 4,
			kScroll = 8,
			kAll = 15,
		};

		enum ItemDragEfferts
		{
			kBefore,
			kMiddle,
			kAfter,
		};

		sharedc_ptr(Control)	SourceControl;
		uint				AllowedEfferts;
		DragDropEfferts		Effert;
		sharedc_ptr(void)	Data;
		ItemDragEfferts		ItemDragEffert;


		// constructor
		DragEventArgs()
			: Effert(kNone)
			, AllowedEfferts(kCopy)
			, ItemDragEffert(kBefore)
		{}
	};

	/// resize event args
	struct AutoSizeEventArgs : public EventArgs
	{
		Core::Rectangle clientRect;
		Core::Rectangle dockRect;

		DECLARE_PDE_ATTRIBUTE_R(Size, Core::Vector2)
		{
			return Max(clientRect.Max, -dockRect.Min) + dockRect.Max;
		}
	};

	/// own paint event args
	struct OwnPaintEventArgs : public EventArgs
	{
		sharedc_ptr(Client::UIRender) render;

		bool	ControlEnable;

		// constructor
		OwnPaintEventArgs(PaintEventArgs & e)
			: render(e.render)
			, ControlEnable(e.Enable)
		{}
		Core::Rectangle Rect;
	};

	/// listitem event args
	struct ListItemEventArgs : public EventArgs
	{
		sharedc_ptr(ListItem)		Item;
		U32				Column;
		bool			Flag;

		// constructor
		ListItemEventArgs()
			: Column(0)
			, Flag(false)
		{
		}
	};

	/// list item mouse event args
	struct ListItemInputEventArgs : InputEventArgs
	{
		sharedc_ptr(ListItem)	Item;
		U32				Column;

		// constructor
		ListItemInputEventArgs()
			: Column(0)
		{
		}

		// constructor
		ListItemInputEventArgs(InputEventArgs & e)
			: InputEventArgs(e)
			, Column(0)
		{
		}
	};

	/// listtreeview eidt column event args
	struct EditColumnEventArgs : public ListItemEventArgs
	{
		Core::String Text;
	};

	/// listTreeView item own draw event args
	struct DrawItemEventArgs : public OwnPaintEventArgs
	{
		// constructor
		DrawItemEventArgs(PaintEventArgs & e)
			: OwnPaintEventArgs(e)
			, Column(0)
		{
		}

		sharedc_ptr(ListItem)	Item;
		tempc_ptr(ListItemSkin)	ItemSkin;
		U32				Row;
		U32				Column;
		bool			Selected;
		Client::Unit::Align	Align;
		sharedc_ptr(Client::Font) Font;
	};

	/// listtreeview eidt column event args
	struct MessageEventArgs : public EventArgs
	{
		Core::String Message;
	};
}

namespace Gui
{
	/// process move
	class MoveController
	{
	public:
		INLINE_PDE_ATTRIBUTE_RW(Snap, const Core::Vector2 &);

	public:
		// constructor
		MoveController();


		// is moving
		bool IsMoving() const { return m_Control; }


		// control
		tempc_ptr(Control) GetControl() const { return m_Control; }


		// begin move
		void BeginMove(by_ptr(Control) control, const Core::Vector2 & cursorPosition);


		// end move
		void EndMove();


		// process event
		bool ProcessInputEvent(InputEventArgs & e);


		// move control
		virtual void OnMove(const Core::Vector2 & position);

	private:
		// offset
		Core::Vector2 m_Offset;

		// control
		sharedc_ptr(Control) m_Control;

		// snap
		Core::Vector2 m_Snap;
	};



	/// process size
	class SizeController
	{
	public:
		enum ControlPoint
		{
			kLeftTop,
			kCenterTop,
			kRightTop,
			kLeftCenter,
			kRightCenter,
			kLeftBottom,
			kCenterBottom,
			kRightBottom,
			kNone
		};

	public:
		// constructor
		SizeController();


		// is sizing
		bool IsSizing() const { return m_Control; }


		// control
		tempc_ptr(Control) GetControl() const { return m_Control; }


		// get scale point
		ControlPoint GetControlPoint() const { return m_ControlPoint; }


		// begin scale
		void BeginScale(by_ptr(Control) control, const Core::Vector2 & cursorPosition, ControlPoint point);


		// end scale
		void EndScale();


		// scale point to cursor
		//static GsInput::CursorShape ControlPointToCursor(ControlPoint point);


		// process event
		bool ProcessInputEvent(InputEventArgs & e);


		// move control
		virtual void OnScale(const Core::Vector2 & size);

	private:
		// start point
		Core::Vector2 m_StartPoint;

		// start size
		Core::Vector2 m_StartSize;

		// point
		ControlPoint m_ControlPoint;

		// control
		sharedc_ptr(Control) m_Control;;
	};
}
