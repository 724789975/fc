namespace Gui
{
	struct Hotkey
	{
		struct HashFunc
		{
			U32 operator()(const Hotkey & obj) const
			{
				return
					(obj.Shift << 0) |
					(obj.Alt << 1) |
					(obj.Control << 2) |
					(obj.Code << 3);
			}
		};

		Client::InputCode   Code;
		bool		Control;
		bool		Alt;
		bool		Shift;

		Hotkey()
			: Code(Client::KC_UNUSED)
			, Control(false)
			, Alt(false)
			, Shift(false)
		{}

		Hotkey(Client::InputCode code, bool control, bool alt, bool shift)
			: Code(code)
			, Control(control)
			, Alt(alt)
			, Shift(shift)
		{}

		friend inline bool operator == (const Hotkey & a, const Hotkey & b)
		{
			return
				a.Code == b.Code &&
				a.Control == b.Control && 
				a.Alt == b.Alt && 
				a.Shift == b.Shift;
		}

		static Hotkey FromName(const char * name);
	};


	struct HotkeyManager
	{
	public:
		typedef Core::HashSet<Hotkey, Core::Event<InputEventArgs>, Hotkey::HashFunc> HotkeySet;

	public:
		/// add hotkey
		Core::Event<InputEventArgs> & Set(const Hotkey & hotkey);

		/// find hotkey
		Core::Event<InputEventArgs> * Get(const Hotkey & hotkey);

		/// remove
		void Remove(const Hotkey & hotkey);

		/// get iterator
		HotkeySet::EnumeratorRef GetEnumerator() const { return m_HotkeySet.GetEnumerator(); }

	public:
		/// on input event
		void OnKeyEvent(Core::Object sender, InputEventArgs & e);

	private:
		HotkeySet m_HotkeySet;
	};

}