namespace Gui
{
	class TooltipSkin: public ControlSkin
	{
	public:
		INLINE_PDE_ATTRIBUTE_RW(ArrowDownImage, tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(ArrowUpImage, tempc_ptr(Image));
	private:
		sharedc_ptr(Image)	m_ArrowDownImage;
		sharedc_ptr(Image)	m_ArrowUpImage;
	};

	class ToolTip : public Control
	{
		DECLARE_PDE_OBJECT(ToolTip, Control)

	public:
		ToolTip();
		~ToolTip();

		INLINE_PDE_ATTRIBUTE_RW (TextPadding,		Core::Vector4);
		INLINE_PDE_ATTRIBUTE_RW (MaxWidth,			F32);
		INLINE_PDE_ATTRIBUTE_RW (ArrowWidth,		F32);

	public:

		void ShowStart(by_ptr(Control) hOwner, const Core::Rectangle& globalBaseRect, const Core::String & text);
		void Close();

	private:
		void Show();
		
	public:
		/// on create
		virtual void OnCreate();

		/// on frame update
		virtual void OnFrameUpdate(EventArgs & e);
	
		/// on paint
		void OnPaint(PaintEventArgs & e);

		/// on input
		virtual void OnInputEvent(InputEventArgs & e);


	private:
		F64		m_Timer;
		bool	m_TimerStart;

		U32		m_AutomaticDelay;
		U32		m_AutoPopDelay;
		U32		m_ReshowDelay;
		bool	m_Reshow;

		//Properties
		Core::Vector4			m_TextPadding;
		Core::String			m_MultiLineStr;
		F32						m_MaxWidth;
		F32						m_ArrowWidth;

		//Variables
		F32						m_ArrowCenter;
		bool					m_AboveBase;
	};
}