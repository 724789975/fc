#include "pch.h"

using namespace Core;
using namespace Client;
using namespace Gui;

DEFINE_PDE_TYPE_CLASS(SplineView)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Control);
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_PROPERTY_RW(GridVisible);
		ADD_PDE_PROPERTY_RW(GridColor);
		ADD_PDE_PROPERTY_RW(LineColor);
		ADD_PDE_PROPERTY_RW(MinValue);
		ADD_PDE_PROPERTY_RW(MaxValue);
		ADD_PDE_PROPERTY_RW(MinLife);
		ADD_PDE_PROPERTY_RW(MaxLife);
		ADD_PDE_PROPERTY_RW(Spline);
		ADD_PDE_PROPERTY_R (ControlPointCount);
		
		ADD_PDE_METHOD(LifeToValue);
		ADD_PDE_EVENT(EventValueChange);
	}
};


REGISTER_PDE_TYPE(SplineView);

namespace Gui
{
	SplineView::SplineView()
		: m_ArmLength(25)
		, m_GridColor(ARGB(128, 128, 128))
		, m_LineColor(ARGB(128, 255, 128))
		, m_WorkRect(0,0,0,0)
		, m_GridVisible(true)
		, m_ControlPointMoving(false)
		, m_WorkRectMoving(false)
		, m_ScaleKind(ScaleBoth)
		, m_VisibleLife(1.0f)
		, m_VisibleValue(1.0f)
		, m_BothArmMoving(true)
		, m_LeftArmMoving(false)
		, m_LeftArmPos(Vector2(0,0))
		, m_RightArmMoving(false)
		, m_ArmVisible(false)
		, m_RightArmPos(Vector2(0,0))
		, m_MinValue(-10.f)
		, m_MaxValue(10.f)
		, m_MinLife(-10.f)
		, m_MaxLife(10.f)
		, m_LifeStep(0.5f)
		, m_ValueStep(0.5f)
		, m_SelectedIdx(-1)
		, m_SingleSelecting(false)
		, m_MultiSelecting(false)
		, m_PointedIdx(-1)
	{
	}

	SplineView::~SplineView()
	{
		m_aMultiSelectedIdx.Clear();
	}
}

//--------------------------------------------------------------------------------------
// Attribute
//--------------------------------------------------------------------------------------
namespace Gui
{
	PDE_ATTRIBUTE_GETTER(SplineView, GridVisible, bool)
	{
		return m_GridVisible;
	}

	PDE_ATTRIBUTE_SETTER(SplineView, GridVisible, bool)
	{
		if (m_GridVisible != value)
		{
			m_GridVisible = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(SplineView, GridColor, ARGB)
	{
		return m_GridColor;
	}

	PDE_ATTRIBUTE_SETTER(SplineView, GridColor, ARGB)
	{
		if (m_GridColor != value)
		{
			m_GridColor = value;

			if (GetGridVisible())
				Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(SplineView, LineColor, ARGB)
	{
		return m_LineColor;
	}

	PDE_ATTRIBUTE_SETTER(SplineView, LineColor, ARGB)
	{
		if (m_LineColor != value)
		{
			m_LineColor = value;

			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(SplineView, MinValue, F32)
	{
		return m_MinValue;
	}

	PDE_ATTRIBUTE_SETTER(SplineView, MinValue, F32)
	{
		if (m_MinValue != value)
		{
			m_MinValue = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(SplineView, MaxValue, F32)
	{
		return m_MaxValue;
	}

	PDE_ATTRIBUTE_SETTER(SplineView, MaxValue, F32)
	{
		if (m_MaxValue != value)
		{
			m_MaxValue = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(SplineView, MinLife, F32)
	{
		return m_MinLife;
	}

	PDE_ATTRIBUTE_SETTER(SplineView, MinLife, F32)
	{
		if (m_MinLife != value)
		{
			m_MinLife = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(SplineView, MaxLife, F32)
	{
		return m_MaxLife;
	}

	PDE_ATTRIBUTE_SETTER(SplineView, MaxLife, F32)
	{
		if (m_MaxLife != value)
		{
			m_MaxLife = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(SplineView, ControlPointCount, S32)
	{
		return m_Spline->GetControlPointCount();
	}

	PDE_ATTRIBUTE_GETTER(SplineView, Spline, sharedc_ptr(PdeSplineF32))
	{
		return m_Spline;
	}

	PDE_ATTRIBUTE_SETTER(SplineView, Spline, sharedc_ptr(PdeSplineF32))
	{
		m_Spline = value;
		DirtyLayout();
	}

	PDE_ATTRIBUTE_GETTER(SplineView, WorkRect, Core::Rectangle)
	{
		return m_WorkRect;
	}

	PDE_ATTRIBUTE_SETTER(SplineView, WorkRect, Core::Rectangle)
	{
		if (m_WorkRect != value)
		{
			m_WorkRect = value;
			Invalid();
		}
	}
}

//--------------------------------------------------------------------------------------
// Event
//--------------------------------------------------------------------------------------
namespace Gui
{
	/// on create
	void SplineView::OnCreate()
	{
		Super::OnCreate();
		SetBackgroundColor(ARGB(140, 140, 140));
	}

	/// on paint
	void SplineView::OnPaint(PaintEventArgs & e)
	{
		Super::OnPaint(e);
		if (!m_Spline)
			return;
		e.render->BeginLineList(0);
		Vector2 origin =NodeToPos(0,0);
		if (GetGridVisible())
		{
			ARGB gridColor = e.Enable? GetGridColor(): ARGB(170, 170, 170);

			e.render->VertexARGB(GetGridColor());

			Core::Rectangle displayRect(GetDisplayRect());
			F32 leftLife = XToLife(displayRect.Min.x);
			F32 rightLife = XToLife(displayRect.Max.x);
			F32 topValue = YToValue(displayRect.Min.y);
			F32 bottomValue = YToValue(displayRect.Max.y);

			CStrBuf<256> str;
			for (F32 life = -m_LifeStep;life > leftLife;life -= m_LifeStep)
			{	
				Vector2 firstPoint = NodeToPos(life,topValue);
				Vector2 secondPoint = NodeToPos(life,bottomValue);
				e.render->Vertex2f(firstPoint.x,firstPoint.y);
				e.render->Vertex2f(secondPoint.x,secondPoint.y);
				str.format("%.2f",life);
				e.render->DrawString(GetFont(), m_TextColor, m_BackgroundColor, Core::Rectangle::LeftTop(NodeToPos(life,0),Vector2::kZero),str, Unit::kAlignCenterTop);
			}

			for (F32 life = m_LifeStep;life < rightLife;life += m_LifeStep)
			{
				Vector2 firstPoint = NodeToPos(life,topValue);
				Vector2 secondPoint = NodeToPos(life,bottomValue);
				e.render->Vertex2f(firstPoint.x,firstPoint.y);
				e.render->Vertex2f(secondPoint.x,secondPoint.y);

				str.format("%.2f",life);
				e.render->DrawString(GetFont(), m_TextColor, m_BackgroundColor, Core::Rectangle::LeftTop(NodeToPos(life,0),Vector2::kZero),str, Unit::kAlignCenterTop);
			}

			for (F32 value = -m_ValueStep;value > bottomValue;value -= m_ValueStep)
			{
				Vector2 firstPoint = NodeToPos(leftLife,value);
				Vector2 secondPoint = NodeToPos(rightLife,value);
				e.render->Vertex2f(firstPoint.x,firstPoint.y);
				e.render->Vertex2f(secondPoint.x,secondPoint.y);
				str.format("%.2f",value);
				e.render->DrawString(GetFont(), m_TextColor, m_BackgroundColor, Core::Rectangle::LeftTop(NodeToPos(0,value),Vector2::kZero),str, Unit::kAlignRightMiddle);
			}

			for (F32 value = m_ValueStep;value < topValue;value += m_ValueStep)
			{

				Vector2 firstPoint = NodeToPos(leftLife,value);
				Vector2 secondPoint = NodeToPos(rightLife,value);
				e.render->Vertex2f(firstPoint.x,firstPoint.y);
				e.render->Vertex2f(secondPoint.x,secondPoint.y);
				str.format("%.2f",value);
				e.render->DrawString(GetFont(), m_TextColor, m_BackgroundColor, Core::Rectangle::LeftTop(NodeToPos(0,value),Vector2::kZero),str, Unit::kAlignRightMiddle);

			}

		}


		ARGB borderColor = e.Enable? ARGB(75, 75, 75): ARGB(128, 128, 128);
		e.render->VertexARGB(borderColor);

		e.render->Vertex2f(m_WorkRect.Min.x, origin.y);
		e.render->Vertex2f(m_WorkRect.Max.x, origin.y);

		e.render->Vertex2f(origin.x, m_WorkRect.Min.y);
		e.render->Vertex2f(origin.x, m_WorkRect.Max.y);

		U32 pointCount = m_Spline->GetControlPointCount();

		if (e.Enable && pointCount > 0)
		{
			Vector2 start = m_WorkRect.Min;
			Vector2 end;
			F32 workRectWidth = m_WorkRect.GetExtent().x;
			F32 workRectHeight = m_WorkRect.GetExtent().y;
			F32 lifeRange = m_MaxLife - m_MinLife;
			F32 valueRange = m_MaxValue - m_MinValue;
			Core::Rectangle rect(GetDisplayRect());

			for(F32 x =rect.Min.x; x < rect.Max.x + 1.0f;x += 1.0f)
			{
				F32 t = (x - m_WorkRect.Min.x) / workRectWidth * lifeRange + m_MinLife;

				F32 v = LifeToValue(t);

				F32 y = (1 - (v - m_MinValue) / valueRange) * workRectHeight + m_WorkRect.Min.y;

				end = Vector2(x, y);
				if (x > m_WorkRect.Min.x)
				{
					e.render->VertexARGB(GetLineColor());
					e.render->Vertex2f(start.x, start.y);
					e.render->Vertex2f(end.x, end.y);

				}
				start = end;
			}


			for (U32 i = 0; i < pointCount; ++i)
			{
				Vector2 nodePos = IndexToPos(i);
				Core::Rectangle nodeRect(nodePos.x - 3, nodePos.y -3, nodePos.x + 3,nodePos. y + 3);

				XRGB color = XRGB(220,220,0);
				if (i == m_SelectedIdx)
				{
					color = XRGB(255,0,0);
				}
				else if (m_aMultiSelectedIdx.Contains(i))
				{
					color = XRGB(0,255,0);
				}
				e.render->DrawRectangle(nodeRect,nodeRect,color);

			}

			if (m_SelectedIdx > -1 && m_ArmVisible)
			{
				Core::Rectangle leftRect(m_LeftArmPos.x - 3, m_LeftArmPos.y - 3, m_LeftArmPos.x + 3, m_LeftArmPos.y + 3);
				e.render->DrawRectangle(leftRect, leftRect,XRGB(0,255,0));
				Core::Rectangle rightRect(m_RightArmPos.x - 3, m_RightArmPos.y - 3, m_RightArmPos.x + 3, m_RightArmPos.y+3);
				e.render->DrawRectangle(rightRect,rightRect,XRGB(0, 255, 0));

				Vector2 selectedPos = IndexToPos(m_SelectedIdx);

				e.render->VertexARGB(XRGB(255, 0, 0));
				e.render->Vertex2f(m_LeftArmPos.x, m_LeftArmPos.y);
				e.render->Vertex2f(selectedPos.x, selectedPos.y);

				e.render->Vertex2f(selectedPos.x, selectedPos.y);
				e.render->Vertex2f(m_RightArmPos.x, m_RightArmPos.y);
			}

			if (m_PointedIdx > -1)
			{
				Vector2 nodePos = IndexToPos(m_PointedIdx);
				CStrBuf<256> str;
				str.format("%.2f,%.2f",m_Spline->GetT(m_PointedIdx),m_Spline->GetValue(m_PointedIdx));
				e.render->DrawString(GetFont(), m_TextColor, m_BackgroundColor,  Core::Rectangle::LeftTop(nodePos,Vector2::kZero), str, Unit::kAlignCenterBottom);
			}
			if (m_MultiSelecting)
			{
				e.render->DrawRectangle(m_MultiSelectedRect,m_MultiSelectedRect,ARGB(128,0, 128, 0));
			}
		}
		e.render->End();
	}

	/// on input event
	void SplineView::OnInputEvent(InputEventArgs & e)
	{
		if(!m_Spline)
			return;
		if (e.IsMouseEvent())
		{
			Vector2 localPos = ScreenToClient(e.CursorPosition);
			switch(e.Type)
			{
			case InputEventArgs::kMouseDown:
				{
					if (e.Code == MC_LEFT_BUTTON)
					{
						S32 idx = PosToIndex(localPos);
						if (idx > -1)
						{
							m_SelectedIdx = idx;
							m_ControlPointMoving = true;
							m_ArmVisible = true;
							if (m_SingleSelecting)
							{
								m_ArmVisible = false;
								if(m_aMultiSelectedIdx.Contains(idx))
								{
									m_aMultiSelectedIdx.Remove(idx);
								}
								else
								{
									m_aMultiSelectedIdx.PushBack(idx);
								}
							}
							InitBothtArm();
						}
						else if(Abs(localPos - m_LeftArmPos) < Vector2(8, 8))
						{
							m_LeftArmMoving = true;
						}
						else if (Abs(localPos - m_RightArmPos) < Vector2(8, 8))
						{
							m_RightArmMoving = true;
						}
						else 
						{
							m_SelectedIdx = -1;
							m_WorkRectMoving = true;
						}
						if (e.ShiftKeyDown)
						{
							m_MultiSelecting = true;
							m_MultiSelectedRect.Min = localPos;
						}
						Invalid();
						SetCapture(true);
					}

					e.Handled = true;
				}
				break;

			case InputEventArgs::kMouseDoubleClick:
				{
					if (e.Code == MC_LEFT_BUTTON)
					{
						S32 idx= PosToIndex(localPos);

						if (idx < 0 && IsPointedOnLine(localPos))
						{
							idx = AddSplineNode(localPos);
							m_aMultiSelectedIdx.Clear();

							if (m_SelectedIdx != idx)
								m_SelectedIdx = idx;
							m_PointedIdx = idx;
							InitBothtArm();
						}
						else if (idx > -1)
						{
							m_Spline->RemoveControlPoint(idx);
							m_aMultiSelectedIdx.Clear();
							if (idx == m_Spline->GetControlPointCount())
							{
								m_SelectedIdx = -1;
							}
							else
							{
								InitBothtArm();
							}
						}
						Invalid();
					}
					e.Handled = true;
				}
				break;

			case InputEventArgs::kMouseUp:
				{
					if (e.Code == MC_LEFT_BUTTON)
					{
						m_ControlPointMoving = false;
						m_LeftArmMoving = false;
						m_RightArmMoving = false;
						m_WorkRectMoving = false;
						SelectMultiControlPoint();
						m_MultiSelecting = false;
						SetCapture(false);
					}
					Invalid();
					e.Handled = true;
				}
				break;

			case InputEventArgs::kMouseMove:
				{
					Vector2 selectedPos = IndexToPos(m_SelectedIdx);
					if (m_ControlPointMoving)
					{
						MoveControlPoint(localPos,m_SelectedIdx);
						MoveMultiControlPoint(e.CursorMove,m_SelectedIdx);
						InitBothtArm();
						OnValueChange(EventArgs());
					}
					else if (m_LeftArmMoving)
					{
						MoveLeftArm(localPos,selectedPos);
						if (m_BothArmMoving)
						{
							MoveRightArm(2*selectedPos - localPos,selectedPos);
							OnValueChange(EventArgs());
						}
					}
					else if (m_RightArmMoving)
					{
						MoveRightArm(localPos,selectedPos);
						if (m_BothArmMoving)
						{
							MoveLeftArm(2*selectedPos - localPos,selectedPos);
							OnValueChange(EventArgs());
						}

					}
					else if (m_WorkRectMoving & !m_MultiSelecting)
					{
						m_ArmVisible = false;
						if (m_WorkRect.IsPointInside(GetDisplayRect().Min - e.CursorMove) && m_WorkRect.IsPointInside(GetDisplayRect().Max - e.CursorMove) )
						{
							m_WorkRect.Move(e.CursorMove);
						}
					}

					else if(e.ShiftKeyDown)
					{
						m_MultiSelectedRect.Max = localPos;

					}
					else
					{
						m_PointedIdx = PosToIndex(localPos) > -1?PosToIndex(localPos):-1;
					}
					Invalid();
					e.Handled = true;
				}
				break;
			case InputEventArgs::kMouseWheel:
				{
					m_ArmVisible = false;
					Vector2 diplaySize = GetDisplayRect().GetExtent();
					Vector4 shrink((1.0f - m_MaxLife) * diplaySize.x * 0.01,(1.0f - m_MaxValue) * diplaySize.y * 0.01,(1.0f - m_MaxLife) * diplaySize.x * 0.01,(1.0f - m_MaxValue) * diplaySize.y * 0.01);
					SetWorkRect(m_WorkRect.Shrink(shrink));
					if (e.Value > 0)
					{
						ScaleWorkRect(0.1f);
					}
					else
					{
						ScaleWorkRect(-0.1f);
					}
					Invalid();
					e.Handled = true;
					break;
				}
			default:
				break;
			}
		}

		if (e.IsKeyEvent())
		{
			if (e.Type == InputEventArgs::kKeyDown)
			{
				switch (e.Code)
				{
				case KC_SPACE:
					if (m_SelectedIdx > -1)
					{
						SwitchCurvature(m_SelectedIdx);
						InitBothtArm();
						Invalid();
					}

					e.Handled = true;
					return;
				case KC_DOWN:
					m_BothArmMoving = !m_BothArmMoving;
					e.Handled = true;
					return;
				case KC_S:
					SwitchScaleKind();
					e.Handled = true;
					return;
				case KC_R:
					m_VisibleLife = 1.0f;
					m_VisibleValue = 1.0f;
					DirtyLayout();
					m_ArmVisible = false;
					e.Handled = true;
					return;
				case KC_C:
					m_Spline->Clear();
					e.Handled = true;
					return;
				case KC_LCONTROL:
					m_SingleSelecting = true;
					e.Handled = true;
					return;
				}
				Invalid();
			}
			else if (e.Type == InputEventArgs::kKeyUp)
			{
				switch (e.Code)
				{
				case KC_LCONTROL:
					m_SingleSelecting = false;
					e.Handled = true;
					return;
				case KC_LSHIFT:
					m_MultiSelecting = false;
					e.Handled = true;
					return;
				}
			}
		}

		if (!e.Handled)
			Super::OnInputEvent(e);

	}

	/// on layout
	void SplineView::OnLayout(EventArgs & e)
	{
		Super::OnLayout(e);
		Core::Rectangle displayRect(GetDisplayRect());
		Vector2 size = displayRect.GetExtent();
		m_WorkRect = displayRect.Move(Vector2(-0.4f*size.x,0.4f*size.y));
		ScaleWorkRect(0.0f);
	}

	/// on value change
	void SplineView::OnValueChange(EventArgs & e)
	{
		EventValueChange.Fire(ptr_static_cast<SplineView>(this),e);
	}
}



//--------------------------------------------------------------------------------------
// Method
//--------------------------------------------------------------------------------------
namespace Gui
{
	S32 SplineView::AddSplineNode(const Vector2 & pos)
	{
		if (!m_Spline)
			return -1;
		F32 width = m_WorkRect.GetExtent().x;
		F32 height = m_WorkRect.GetExtent().y;

		F32 life = m_MinLife + (m_MaxLife - m_MinLife)*((pos.x - m_WorkRect.Min.x) / width);
		F32 value = m_MinValue;

		value += Abs(pos.y - m_WorkRect.Max.y) / height*(m_MaxValue - m_MinValue);
		S32 idx = m_Spline->AddControlPoint(PdeSpline<F32>::ControlPoint(life, value, 0, 0, PdeSpline<F32>::kCustom));

		m_Spline->UpdataControlPointTCB(idx);

		OnValueChange(EventArgs());

		return idx;
	}

	S32 SplineView::PosToIndex(const Vector2 & pos)
	{
		if(!m_Spline)
			return -1;
		F32 width = m_WorkRect.GetExtent().x;
		F32 height = m_WorkRect.GetExtent().y;

		for (U32 i = 0; i < (U32)m_Spline->GetControlPointCount(); ++i)
		{
			Vector2 nodePos;
			nodePos.x = m_WorkRect.Min.x + (m_Spline->GetControlPoint(i).T - m_MinLife) / (m_MaxLife - m_MinLife) * width;
			nodePos.y = m_WorkRect.Max.y - (m_Spline->GetControlPoint(i).Value - m_MinValue) / (m_MaxValue - m_MinValue) * height;

			if (Abs(pos - nodePos) < Vector2(5, 5))
				return i;
		}

		return -1;
	}

	Vector2 SplineView::IndexToPos(S32 idx)
	{
		if(!m_Spline)
			return Vector2::kZero;
		for (U32 i = 0; i < (U32)m_Spline->GetControlPointCount(); ++i)
		{
			if (i == idx)
			{
				return NodeToPos(m_Spline->GetControlPoint(i).T,m_Spline->GetControlPoint(i).Value);
			}
		}

		return Vector2::kZero;
	}

	Vector2 SplineView::NodeToPos(F32 t, F32 v)
	{
		F32 width = m_WorkRect.GetExtent().x;
		F32 height = m_WorkRect.GetExtent().y;
		F32 lifeRange = m_MaxLife - m_MinLife;
		F32 valueRange = m_MaxValue - m_MinValue;

		Vector2 pos;
		pos.x = m_WorkRect.Min.x + (t - m_MinLife) / lifeRange * width;
		pos.y = m_WorkRect.Max.y - (v - m_MinValue) / valueRange * height;

		return pos;
	}
	
	F32 SplineView::XToLife(F32 x)
	{
		F32 width = m_WorkRect.GetExtent().x;
		F32 height = m_WorkRect.GetExtent().y;
		F32 lifeRange = m_MaxLife - m_MinLife;
		F32 valueRange = m_MaxValue - m_MinValue;
		
		return (x - m_WorkRect.Min.x)*lifeRange/width + m_MinLife;

	}

	F32 SplineView::YToValue(F32 y)
	{
		F32 width = m_WorkRect.GetExtent().x;
		F32 height = m_WorkRect.GetExtent().y;
		F32 lifeRange = m_MaxLife - m_MinLife;
		F32 valueRange = m_MaxValue - m_MinValue;

		return (m_WorkRect.Max.y - y)*valueRange/height + m_MinValue;

	}
	F32 SplineView::LifeToValue(F32 life)
	{
		if(!m_Spline)
			return 0;
		F32 value = m_MinValue;

		if (m_Spline->GetControlPointCount() > 0)
			m_Spline->Interpolation(life, value);

		return value;
	}

	void SplineView::SwitchCurvature(S32 idx)
	{
		if(!m_Spline)
			return;
		S32 count = m_Spline->GetControlPointCount();
		if (idx > -1 && idx < count)
		{
			PdeSpline<F32>::ControlPoint * p = &m_Spline->GetControlPoint(idx);

			switch (p->Type)
			{
			case PdeSpline<F32>::kLinear:
				p->Type = PdeSpline<F32>::kCustom;
				p->StartTangent = 0;
				p->EndTangent = 0;

				break;

			case PdeSpline<F32>::kCustom:
				p->Type = PdeSpline<F32>::kLinear;
				break;
			}

			m_Spline->UpdataControlPointTCB(idx);
		}
	}

	void SplineView::SwitchScaleKind()
	{
		switch (m_ScaleKind)
		{
		case ScaleLife:
			m_ScaleKind = ScaleValue;
			break;
		case ScaleValue:
			m_ScaleKind = ScaleBoth;
			break;
		case ScaleBoth:
			m_ScaleKind = ScaleLife;
			break;
		default:
			m_ScaleKind = ScaleBoth;
			break;
		}
	}

	bool SplineView::IsPointedOnLine(const Vector2 & pos)
	{
		if(!m_Spline)
			return false;
		F32 width = m_WorkRect.GetExtent().x;
		F32 lifeRange = m_MaxLife - m_MinLife;

		if (!m_WorkRect.IsPointInside(pos))
			return false;

		for (U32 i = 0; i < (U32)m_Spline->GetControlPointCount(); ++i)
		{
			F32 x;
			x = m_WorkRect.Min.x + (m_Spline->GetControlPoint(i).T - m_MinLife) / lifeRange * width;

			if (Abs(pos.x - x) < 5.f)
				return false;
		}

		return true;
	}

	void SplineView::InitBothtArm()
	{
		if (!m_Spline)
		return;
		Vector2 selectPos = IndexToPos(m_SelectedIdx);

		if (m_Spline->GetControlPoint(m_SelectedIdx).Type ==  PdeSpline<F32>::kLinear)
		{
			F32 tanLeft = (IndexToPos(m_SelectedIdx).y - IndexToPos(m_SelectedIdx - 1).y)/(IndexToPos(m_SelectedIdx).x - IndexToPos(m_SelectedIdx - 1).x);
			F32 tanRight = (IndexToPos(m_SelectedIdx + 1).y - IndexToPos(m_SelectedIdx).y)/(IndexToPos(m_SelectedIdx + 1).x - IndexToPos(m_SelectedIdx).x);

			m_LeftArmPos.x = selectPos.x - m_ArmLength/sqrt(1 + tanLeft*tanLeft);

			if (tanLeft > 0)
			{
				m_LeftArmPos.y = selectPos.y - m_ArmLength/sqrt(1 + 1/(tanLeft*tanLeft));
			}
			else
			{
				m_LeftArmPos.y = selectPos.y + m_ArmLength/sqrt(1 + 1/(tanLeft*tanLeft));
			}

			m_RightArmPos.x = selectPos.x + m_ArmLength/sqrt(1 + tanRight*tanRight);

			if (tanRight > 0)
			{
				m_RightArmPos.y = selectPos.y + m_ArmLength/sqrt(1 + 1/(tanRight*tanRight));
			}
			else
			{
				m_RightArmPos.y = selectPos.y - m_ArmLength/sqrt(1 + 1/(tanRight*tanRight));
			}
		}
		else 
		{
			F32 deltLeftT = m_Spline->GetT(m_SelectedIdx) - m_Spline->GetT(m_SelectedIdx - 1);
			F32 deltRightT = m_Spline->GetT(m_SelectedIdx + 1) - m_Spline->GetT(m_SelectedIdx);
			F32 tanLeft = m_Spline->GetEndTangent(m_SelectedIdx)/deltLeftT;
			F32 tanRight = m_Spline->GetStartTangent(m_SelectedIdx)/deltRightT;

			m_LeftArmPos.x = selectPos.x - m_ArmLength/sqrt(1 + tanLeft*tanLeft);

			if (deltLeftT > 0 && m_Spline->GetEndTangent(m_SelectedIdx) > 0)
			{
				m_LeftArmPos.y = selectPos.y + m_ArmLength/sqrt(1 + 1/(tanLeft*tanLeft));
			}
			else
			{
				m_LeftArmPos.y = selectPos.y - m_ArmLength/sqrt(1 + 1/(tanLeft*tanLeft));
			}

			m_RightArmPos.x = selectPos.x + m_ArmLength/sqrt(1 + tanRight*tanRight);

			if (deltRightT > 0 && m_Spline->GetStartTangent(m_SelectedIdx) > 0)
			{
				m_RightArmPos.y = selectPos.y - m_ArmLength/sqrt(1 + 1/(tanRight*tanRight));
			}
			else
			{
				m_RightArmPos.y = selectPos.y + m_ArmLength/sqrt(1 + 1/(tanRight*tanRight));
			}
		}
	}

	void SplineView::MoveLeftArm(Vector2 cursorPos,Vector2 selectedPos)
	{
		if(!m_Spline)
			return;
		if ( cursorPos.x < selectedPos.x)
		{
			m_LeftArmPos = selectedPos + (cursorPos - selectedPos).Normalize()*m_ArmLength;
			F32 tan = -(m_LeftArmPos.y - selectedPos.y)/(m_LeftArmPos.x - selectedPos.x);
			F32 endTan = tan*(m_Spline->GetT(m_SelectedIdx) - m_Spline->GetT(m_SelectedIdx - 1));
			m_Spline->SetEndTangent(m_SelectedIdx,endTan);
		}
	}

	void SplineView::MoveRightArm(Vector2 cursorPos,Vector2 selectedPos)
	{
		if(!m_Spline)
			return;
		if (cursorPos.x > selectedPos.x)
		{
			m_RightArmPos = selectedPos + (cursorPos - selectedPos).Normalize()*m_ArmLength;
			F32 tan = -(m_RightArmPos.y - selectedPos.y)/(m_RightArmPos.x - selectedPos.x);
			F32 endTan = tan*(m_Spline->GetT(m_SelectedIdx + 1) - m_Spline->GetT(m_SelectedIdx));
			m_Spline->SetStartTangent(m_SelectedIdx,endTan);
		}
	}

	void SplineView::MoveControlPoint(Vector2 cursorPos, S32& Idx)
	{
		if(!m_Spline)
			return;
		F32 width = m_WorkRect.GetExtent().x;
		F32 height = m_WorkRect.GetExtent().y;

		F32 value = m_MaxValue - (cursorPos.y - m_WorkRect.Min.y) / height * (m_MaxValue - m_MinValue);
		m_Spline->GetControlPoint(Idx).Value = Clamp(value, m_MinValue, m_MaxValue);

		F32 life = m_MinLife + (cursorPos.x - m_WorkRect.Min.x) / width * (m_MaxLife - m_MinLife);

		U32 index = m_Spline->SetControlPointT(Idx, Clamp(life, m_MinLife, m_MaxLife));

		if (index != Idx)
		{
			Idx = index;
		}
		m_PointedIdx = index;
		m_Spline->UpdataControlPointTCB(Idx);
	}

	void SplineView::MoveMultiControlPoint(Vector2 cursorMove,S32& Idx)
	{
		if(!m_Spline)
			return;
		for (U32 i = 0;i < m_aMultiSelectedIdx.Size();i++)
		{	
			Vector2 nodePos = IndexToPos(m_aMultiSelectedIdx.GetAt(i));
			MoveControlPoint(nodePos + cursorMove,const_cast<S32&>(m_aMultiSelectedIdx.GetAt(i)));
		}
	}

	void SplineView::SelectMultiControlPoint()
	{
		if(!m_Spline)
			return;
		U32 pointCount = m_Spline->GetControlPointCount();
		if (m_MultiSelecting)
		{
			for (U32 i = 0; i < pointCount; ++i)
			{
				Vector2 nodePos = IndexToPos(i);
				if (m_MultiSelectedRect.IsPointInside(nodePos))
				{
					if (m_aMultiSelectedIdx.Contains(i))
					{
						m_aMultiSelectedIdx.Remove(i);
					} 
					else
					{
						m_aMultiSelectedIdx.PushBack(i);
					}
				}
			}
		}
	}
	void SplineView::ScaleWorkRect(F32 scale)
	{
		if(!m_Spline)
			return;
		switch (m_ScaleKind)
		{
		case ScaleLife:
			m_VisibleLife += scale;
			break;
		case ScaleValue:
			m_VisibleValue += scale;
			break;
		case ScaleBoth:
			m_VisibleLife += scale;
			m_VisibleValue += scale;
			break;
		default:
			m_VisibleLife += scale;
			m_VisibleValue += scale;
			break;
		}

		Vector2 displaySize = GetDisplayRect().GetExtent();
		Vector2 screenSize = gGame->screen->GetSize();
		m_VisibleLife = Clamp(m_VisibleLife,0.5f,m_MaxLife);
		m_VisibleValue = Clamp(m_VisibleValue,0.5f,m_MaxValue);

		m_LifeStep = 0.03f*m_VisibleLife*screenSize.x/displaySize.x;
		m_ValueStep = 0.03f*m_VisibleValue*screenSize.y/displaySize.y;

		Vector3 center = m_WorkRect.GetCenter();
		m_WorkRect = Core::Rectangle::LeftTop(center,Vector2::kZero);

		Vector4 shrink(0.5f*displaySize.x*m_MaxLife/(0.5f *m_VisibleLife),0.5*displaySize.y*m_MaxValue/(0.5f *m_VisibleValue),0.5f*displaySize.x*m_MaxLife/(0.5f*m_VisibleLife),0.5*displaySize.y*m_MaxValue/(0.5f*m_VisibleValue));
		SetWorkRect(m_WorkRect.Shrink(-shrink));

	}
}