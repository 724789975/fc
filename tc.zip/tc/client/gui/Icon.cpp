#include "pch.h"

using namespace Core;
using namespace Client;

//---------------------------------------------------------------------------------------
// type info.
//---------------------------------------------------------------------------------------
DEFINE_PDE_TYPE_ENUM(Gui::Icon::IconTextDisplay)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_ENUM_ITEM("kIconTextActualSize",		Gui::Icon::kIconTextActualSize);
		ADD_PDE_ENUM_ITEM("kIconTextFullFill",			Gui::Icon::kIconTextFullFill);

		ADD_PDE_ENUM_CONSTRUCTOR();
	}
};

DEFINE_PDE_TYPE_CLASS(Gui::Icon)
{
	static sharedc_ptr(Gui::Icon) constructor(Core::IArguments & args)
	{
		ArgumentPtr<Identifier> path(args, 0);
		ArgumentPtr<Vector4> border(args, 1);
		ArgumentPtr<Vector4> uv(args, 2);

		sharedc_ptr(Gui::Icon) icon = ptr_new Gui::Icon;

		if (path) icon->SetPath(*path);
		if (border) icon->SetBorder(*border);
		if (uv)	icon->Setuv(*uv);
		return icon;
	}

	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::Image);
		ADD_PDE_CONSTRUCTOR(&constructor);

		ADD_PDE_PROPERTY_RW(DisplayType);
	}
};

DEFINE_PDE_TYPE_CLASS(Gui::ProportionIcon)
{
	static sharedc_ptr(Gui::ProportionIcon) constructor(Core::IArguments & args)
	{
		ArgumentPtr<Identifier> bg_path(args, 0);
		ArgumentPtr<Identifier> fg_path(args, 1);
		ArgumentPtr<Vector4> bg_border(args, 2);
		ArgumentPtr<Vector4> fg_border(args, 3);
		ArgumentPtr<F32>	proportion(args,4);

		sharedc_ptr(Gui::ProportionIcon) icon = ptr_new Gui::ProportionIcon;

		if (bg_path) icon->SetBgPath(*bg_path);
		if (fg_path) icon->SetFgPath(*fg_path);
		if (bg_border) icon->SetBgBorder(*bg_border);
		if (fg_border) icon->SetFgBorder(*fg_border);
		if (proportion) icon->SetProportion(*proportion);

		return icon;
	}

	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::Icon);
		ADD_PDE_CONSTRUCTOR(&constructor);

		ADD_PDE_PROPERTY_RW(BgBorder);
		ADD_PDE_PROPERTY_RW(FgBorder);
		ADD_PDE_PROPERTY_RW(BgPath);
		ADD_PDE_PROPERTY_RW(FgPath);
		ADD_PDE_PROPERTY_RW(Proportion);
		ADD_PDE_PROPERTY_RW(BarPadding);
	}
};

DEFINE_PDE_TYPE_CLASS(Gui::CompareIcon)
{
	static sharedc_ptr(Gui::CompareIcon) constructor(Core::IArguments & args)
	{
		ArgumentPtr<Identifier> bg_path(args, 0);
		ArgumentPtr<Identifier> fg_path(args, 1);
		ArgumentPtr<Identifier> fg_plus_path(args, 2);
		ArgumentPtr<Identifier> fg_minus_path(args, 3);
		ArgumentPtr<Vector4> bg_border(args, 4);
		ArgumentPtr<Vector4> fg_border(args, 5);

		sharedc_ptr(Gui::CompareIcon) icon = ptr_new Gui::CompareIcon;

		if (bg_path) icon->SetBgPath(*bg_path);
		if (fg_path) icon->SetFgPath(*fg_path);
		if (fg_plus_path) icon->SetFgPlusPath(*fg_plus_path);
		if (fg_minus_path) icon->SetFgMinusPath(*fg_minus_path);
		if (bg_border) icon->SetBgBorder(*bg_border);
		if (fg_border) icon->SetFgBorder(*fg_border);

		return icon;
	}

	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::Icon);
		ADD_PDE_CONSTRUCTOR(&constructor);

		ADD_PDE_PROPERTY_RW(BgBorder);
		ADD_PDE_PROPERTY_RW(FgBorder);
		ADD_PDE_PROPERTY_RW(BgPath);
		ADD_PDE_PROPERTY_RW(FgPath);
		ADD_PDE_PROPERTY_RW(FgPlusPath);
		ADD_PDE_PROPERTY_RW(FgMinusPath);
		ADD_PDE_PROPERTY_RW(BaseValue);
		ADD_PDE_PROPERTY_RW(ComparativeValue);
	}
};


REGISTER_PDE_TYPE(Gui::Icon);
REGISTER_PDE_TYPE(Gui::Icon::IconTextDisplay);
REGISTER_PDE_TYPE(Gui::ProportionIcon);
REGISTER_PDE_TYPE(Gui::CompareIcon);

namespace Gui
{
	// default constructor.
	Icon::Icon()
		:m_DisplayType(kIconTextActualSize)
	{
	}

	// constructor.
	Icon::Icon(const Core::Identifier & path, const Core::Vector4 & border,Core::Vector4 uv)
		:Image(path, border,uv)
		
		,m_DisplayType(kIconTextFullFill)
	{
		
	}

	// destructor
	Icon::~Icon()
	{
	}
}

namespace Gui
{
	// default constructor.
	ProportionIcon::ProportionIcon()
		:m_FgBorder(0,0,0,0)
		,m_BarPadding(1,1,1,1)
		,m_Propotion(0.f)
	{
		SetDisplayType(Icon::kIconTextFullFill);
	}

	// constructor.
	ProportionIcon::ProportionIcon(const Core::Identifier & bg_path, const Core::Identifier & fg_path, const Core::Vector4 & bg_border, const Core::Vector4 & fg_border)
		:m_FgBorder(0,0,0,0)
		,m_BarPadding(1,1,1,1)
		,m_Propotion(0.f)
	{
		SetBgPath(bg_path);
		SetFgPath(fg_path);
		SetBgBorder(bg_border);
		SetFgBorder(fg_border);
		SetDisplayType(Icon::kIconTextFullFill);
	}

	// destructor
	ProportionIcon::~ProportionIcon()
	{
	}
}

namespace Gui
{
	PDE_ATTRIBUTE_GETTER(ProportionIcon, BgBorder, const Core::Vector4 &)
	{
		return Super::GetBorder();
	}

	PDE_ATTRIBUTE_SETTER(ProportionIcon, BgBorder, const Core::Vector4 &)
	{
		Super::SetBorder(value);
	}

	PDE_ATTRIBUTE_GETTER(ProportionIcon, FgBorder, const Core::Vector4 &)
	{
		return m_FgBorder;
	}

	PDE_ATTRIBUTE_SETTER(ProportionIcon, FgBorder, const Core::Vector4 &)
	{
		m_FgBorder = value;
	}

	PDE_ATTRIBUTE_GETTER(ProportionIcon, BgPath, const Core::Identifier &)
	{
		return Super::GetPath();
	}

	PDE_ATTRIBUTE_SETTER(ProportionIcon, BgPath, const Core::Identifier &)
	{
		Super::SetPath(value);
	}

	PDE_ATTRIBUTE_GETTER(ProportionIcon, FgPath, const Core::Identifier &)
	{
		if (m_FgTexture)
		{
			return m_FgTexture->GetKey();
		}
		else
		{
			return Core::Identifier::kNull;
		}
	}

	PDE_ATTRIBUTE_SETTER(ProportionIcon, FgPath, const Core::Identifier &)
	{
		if (!m_FgTexture || m_FgTexture->GetKey() != value)
		{
//#ifdef MASTER
//#else
//			if(value.Length() > MAX_PATH)
//			{
//				Core::ThrowErrorString(gLang->GetTextW(L"·����������󳤶ȣ�"));
//			}
//#endif	
			CStrBuf<256> new_path;
			new_path.format("ui/%s/%s",gGame->language, value);
			m_FgTexture = ptr_dynamic_cast<Texture2D>(Resource::Load(new_path));
		}
	}

	PDE_ATTRIBUTE_GETTER(ProportionIcon, Proportion, F32)
	{
		return m_Propotion;
	}

	PDE_ATTRIBUTE_SETTER(ProportionIcon, Proportion, F32)
	{
		if(value>1.f) 
			m_Propotion = 1.f;
		else if(value<0.f)	
			m_Propotion = 0.f;
		else 
			m_Propotion = value;
	}

	PDE_ATTRIBUTE_GETTER(ProportionIcon, BarPadding, const Core::Vector4 &)
	{
		return m_BarPadding;
	}

	PDE_ATTRIBUTE_SETTER(ProportionIcon, BarPadding, const Core::Vector4 &)
	{
		m_BarPadding = value;
	}
}

namespace Gui
{
	void ProportionIcon::Draw(by_ptr(Client::UIRender) render, const Core::Rectangle & rect, Core::ARGB color)
	{
		Core::Rectangle iconRect = rect;
		iconRect.Shrink(m_BarPadding);
		Super::Draw(render, iconRect, color);

		if (m_FgTexture && m_FgTexture->IsReady() && GetProportion()>0.1f/100.f)
		{
			Core::Rectangle FgRect(iconRect);
			FgRect.Shrink(m_FgBorder.x+m_FgBorder.z, 0, 0, 0);
			FgRect.Max.x = FgRect.Min.x + (FgRect.Max.x-FgRect.Min.x)*GetProportion();
			FgRect.Min.x = iconRect.Min.x;

			render->SetTexture(m_FgTexture);

			if (m_FgBorder == Vector4::kZero)
			{
				render->DrawRectangle(FgRect, Core::Rectangle(0, 0, 1, 1), color);
			}
			else
			{
				float width = m_FgTexture->GetWidth();
				float height = m_FgTexture->GetHeight();

				Core::Rectangle window_margin(m_FgBorder.x, m_FgBorder.y, m_FgBorder.z, m_FgBorder.w);
				Core::Rectangle uv_margin(m_FgBorder.x / width, m_FgBorder.y / height, m_FgBorder.z / width, m_FgBorder.w / height);

				render->DrawWindow(FgRect, window_margin, uv_margin, color, color, m_rotate);
			}
		}
	}
}


namespace Gui
{
	// default constructor.
	CompareIcon::CompareIcon()
		:m_FgBorder(0,0,0,0)
		,m_BarPadding(1,1,1,1)
		,m_BaseValue(0.0f)
		,m_ComparativeValue(0.0f)
	{
		SetDisplayType(Icon::kIconTextFullFill);
	}

	// constructor.
	CompareIcon::CompareIcon(const Core::Identifier & bg_path, const Core::Identifier & fg_path, const Core::Identifier & fg_plus_path, const Core::Identifier & fg_minus_path , const Core::Vector4 & bg_border, const Core::Vector4 & fg_border)
		:m_FgBorder(0,0,0,0)
		,m_BarPadding(1,1,1,1)
		,m_BaseValue(0.0f)
		,m_ComparativeValue(0.0f)
	{
		SetBgPath(bg_path);
		SetFgPath(fg_path);
		SetFgPlusPath(fg_plus_path);
		SetFgMinusPath(fg_minus_path);
		SetBgBorder(bg_border);
		SetFgBorder(fg_border);
		SetDisplayType(Icon::kIconTextFullFill);
	}

	// destructor
	CompareIcon::~CompareIcon()
	{
	}
}

namespace Gui
{
	PDE_ATTRIBUTE_GETTER(CompareIcon, BgBorder, const Core::Vector4 &)
	{
		return Super::GetBorder();
	}

	PDE_ATTRIBUTE_SETTER(CompareIcon, BgBorder, const Core::Vector4 &)
	{
		Super::SetBorder(value);
	}

	PDE_ATTRIBUTE_GETTER(CompareIcon, FgBorder, const Core::Vector4 &)
	{
		return m_FgBorder;
	}

	PDE_ATTRIBUTE_SETTER(CompareIcon, FgBorder, const Core::Vector4 &)
	{
		m_FgBorder = value;
	}

	PDE_ATTRIBUTE_GETTER(CompareIcon, BgPath, const Core::Identifier &)
	{
		return Super::GetPath();
	}

	PDE_ATTRIBUTE_SETTER(CompareIcon, BgPath, const Core::Identifier &)
	{
		Super::SetPath(value);
	}

	PDE_ATTRIBUTE_GETTER(CompareIcon, FgPath, const Core::Identifier &)
	{
		if (m_FgTexture)
		{
			return m_FgTexture->GetKey();
		}
		else
		{
			return Core::Identifier::kNull;
		}
	}

	PDE_ATTRIBUTE_SETTER(CompareIcon, FgPath, const Core::Identifier &)
	{
		if (!m_FgTexture || m_FgTexture->GetKey() != value)
		{
			CStrBuf<MAX_PATH> new_path;
			new_path.format("ui/%s/%s",gGame->language, value);		
			m_FgTexture = ptr_dynamic_cast<Texture2D>(Resource::Load(new_path));
		}
	}

	PDE_ATTRIBUTE_GETTER(CompareIcon, FgPlusPath, const Core::Identifier &)
	{
		if (m_FgPlusTexture)
		{
			return m_FgPlusTexture->GetKey();
		}
		else
		{
			return Core::Identifier::kNull;
		}
	}

	PDE_ATTRIBUTE_SETTER(CompareIcon, FgPlusPath, const Core::Identifier &)
	{
		if (!m_FgPlusTexture || m_FgPlusTexture->GetKey() != value)
		{
			CStrBuf<MAX_PATH> new_path;
			new_path.format("ui/%s/%s",gGame->language, value);
			m_FgPlusTexture = ptr_dynamic_cast<Texture2D>(Resource::Load(new_path));
		}
	}

	PDE_ATTRIBUTE_GETTER(CompareIcon, FgMinusPath, const Core::Identifier &)
	{
		if (m_FgMinusTexture)
		{
			return m_FgMinusTexture->GetKey();
		}
		else
		{
			return Core::Identifier::kNull;
		}
	}

	PDE_ATTRIBUTE_SETTER(CompareIcon, FgMinusPath, const Core::Identifier &)
	{
		if (!m_FgMinusTexture || m_FgMinusTexture->GetKey() != value)
		{
			CStrBuf<MAX_PATH> new_path;
			new_path.format("ui/%s/%s",gGame->language, value);
			m_FgMinusTexture = ptr_dynamic_cast<Texture2D>(Resource::Load(new_path));
		}
	}

	PDE_ATTRIBUTE_GETTER(CompareIcon, BaseValue, F32)
	{
		return m_BaseValue;
	}

	PDE_ATTRIBUTE_SETTER(CompareIcon, BaseValue, F32)
	{
		m_BaseValue = Core::Clamp(value, 0.f, 1.f);
	}

	PDE_ATTRIBUTE_GETTER(CompareIcon, ComparativeValue, F32)
	{
		return m_ComparativeValue;
	}

	PDE_ATTRIBUTE_SETTER(CompareIcon, ComparativeValue, F32)
	{
		m_ComparativeValue = Core::Clamp(value, 0.f, 1.f);
	}

	PDE_ATTRIBUTE_GETTER(CompareIcon, BarPadding, const Core::Vector4 &)
	{
		return m_BarPadding;
	}

	PDE_ATTRIBUTE_SETTER(CompareIcon, BarPadding, const Core::Vector4 &)
	{
		m_BarPadding = value;
	}
}

namespace Gui
{
	void CompareIcon::Draw(by_ptr(Client::UIRender) render, const Core::Rectangle & rect, Core::ARGB color)
	{
		Super::Draw(render, rect, color);

		Core::Rectangle iconRect = rect;
		iconRect.Shrink(m_BarPadding);
		Super::Draw(render, iconRect, color);

		if(m_ComparativeValue-m_BaseValue > Core::EPSILON)
		{
			if (m_FgPlusTexture && m_FgPlusTexture->IsReady() && GetComparativeValue()>0.1f/100.f)
			{
				Core::Rectangle FgRect(iconRect);
				FgRect.Shrink(m_FgBorder.x+m_FgBorder.z, 0, 0, 0);
				FgRect.Max.x = FgRect.Min.x + (FgRect.Max.x-FgRect.Min.x)*GetComparativeValue();
				FgRect.Min.x = iconRect.Min.x;
				render->SetTexture(m_FgPlusTexture);

				if (m_FgBorder == Vector4::kZero)
				{
					render->DrawRectangle(FgRect, Core::Rectangle(0, 0, 1, 1), color);
				}
				else
				{
					float width = m_FgPlusTexture->GetWidth();
					float height = m_FgPlusTexture->GetHeight();

					Core::Rectangle window_margin(m_FgBorder.x, m_FgBorder.y, m_FgBorder.z, m_FgBorder.w);
					Core::Rectangle uv_margin(m_FgBorder.x / width, m_FgBorder.y / height, m_FgBorder.z / width, m_FgBorder.w / height);

					render->DrawWindow(FgRect, window_margin, uv_margin, color, color, m_rotate);
				}
			}

			if (m_FgTexture && m_FgTexture->IsReady() && GetBaseValue()>0.1f/100.f)
			{
				Core::Rectangle FgRect(iconRect);
				FgRect.Shrink(m_FgBorder.x+m_FgBorder.z, 0, 0, 0);
				FgRect.Max.x = FgRect.Min.x + (FgRect.Max.x-FgRect.Min.x)*GetBaseValue();
				FgRect.Min.x = iconRect.Min.x;
				render->SetTexture(m_FgTexture);

				if (m_FgBorder == Vector4::kZero)
				{
					render->DrawRectangle(FgRect, Core::Rectangle(0, 0, 1, 1), color);
				}
				else
				{
					float width = m_FgTexture->GetWidth();
					float height = m_FgTexture->GetHeight();

					Core::Rectangle window_margin(m_FgBorder.x, m_FgBorder.y, m_FgBorder.z, m_FgBorder.w);
					Core::Rectangle uv_margin(m_FgBorder.x / width, m_FgBorder.y / height, m_FgBorder.z / width, m_FgBorder.w / height);

					render->DrawWindow(FgRect, window_margin, uv_margin, color, color, m_rotate);
				}
			}
		}
		else if(m_BaseValue - m_ComparativeValue > Core::EPSILON)
		{
			if (m_FgMinusTexture && m_FgMinusTexture->IsReady() && GetBaseValue()>0.1f/100.f)
			{
				Core::Rectangle FgRect(iconRect);
				FgRect.Shrink(m_FgBorder.x+m_FgBorder.z, 0, 0, 0);
				FgRect.Max.x = FgRect.Min.x + (FgRect.Max.x-FgRect.Min.x)*GetBaseValue();
				FgRect.Min.x = iconRect.Min.x;
				render->SetTexture(m_FgMinusTexture);

				if (m_FgBorder == Vector4::kZero)
				{
					render->DrawRectangle(FgRect, Core::Rectangle(0, 0, 1, 1), color);
				}
				else
				{
					float width = m_FgMinusTexture->GetWidth();
					float height = m_FgMinusTexture->GetHeight();

					Core::Rectangle window_margin(m_FgBorder.x, m_FgBorder.y, m_FgBorder.z, m_FgBorder.w);
					Core::Rectangle uv_margin(m_FgBorder.x / width, m_FgBorder.y / height, m_FgBorder.z / width, m_FgBorder.w / height);

					render->DrawWindow(FgRect, window_margin, uv_margin, color, color, m_rotate);
				}
			}

			if (m_FgTexture && m_FgTexture->IsReady() && GetComparativeValue()>0.1f/100.f)
			{
				Core::Rectangle FgRect(iconRect);
				FgRect.Shrink(m_FgBorder.x+m_FgBorder.z, 0, 0, 0);
				FgRect.Max.x = FgRect.Min.x + (FgRect.Max.x-FgRect.Min.x)*GetComparativeValue();
				FgRect.Min.x = iconRect.Min.x;
				render->SetTexture(m_FgTexture);

				if (m_FgBorder == Vector4::kZero)
				{
					render->DrawRectangle(FgRect, Core::Rectangle(0, 0, 1, 1), color);
				}
				else
				{
					float width = m_FgTexture->GetWidth();
					float height = m_FgTexture->GetHeight();

					Core::Rectangle window_margin(m_FgBorder.x, m_FgBorder.y, m_FgBorder.z, m_FgBorder.w);
					Core::Rectangle uv_margin(m_FgBorder.x / width, m_FgBorder.y / height, m_FgBorder.z / width, m_FgBorder.w / height);

					render->DrawWindow(FgRect, window_margin, uv_margin, color, color, m_rotate);
				}
			}
		}
		else
		{
			//Exactly the same
			if (m_FgTexture && m_FgTexture->IsReady() && GetBaseValue()>0.1f/100.f)
			{
				Core::Rectangle FgRect(iconRect);
				FgRect.Shrink(m_FgBorder.x+m_FgBorder.z, 0, 0, 0);
				FgRect.Max.x = FgRect.Min.x + (FgRect.Max.x-FgRect.Min.x)*GetBaseValue();
				FgRect.Min.x = iconRect.Min.x;
				render->SetTexture(m_FgTexture);

				if (m_FgBorder == Vector4::kZero)
				{
					render->DrawRectangle(FgRect, Core::Rectangle(0, 0, 1, 1), color);
				}
				else
				{
					float width = m_FgTexture->GetWidth();
					float height = m_FgTexture->GetHeight();

					Core::Rectangle window_margin(m_FgBorder.x, m_FgBorder.y, m_FgBorder.z, m_FgBorder.w);
					Core::Rectangle uv_margin(m_FgBorder.x / width, m_FgBorder.y / height, m_FgBorder.z / width, m_FgBorder.w / height);

					render->DrawWindow(FgRect, window_margin, uv_margin, color, color, m_rotate);
				}
			}
		}
	}
}