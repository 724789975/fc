#include "pch.h"

#ifdef USE_WEB

using namespace Core;
using namespace Gui;
using namespace Client;
//---------------------------------------------------------------------------------------
// type info.
//---------------------------------------------------------------------------------------
DEFINE_PDE_TYPE_CLASS(Gui::WebSkin)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::ControlSkin);
		ADD_PDE_DEFAULT_CONSTRUCTOR();
	}
};
REGISTER_PDE_TYPE(Gui::WebSkin);

DEFINE_PDE_TYPE_CLASS(Gui::WebControl)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::Control);
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_METHOD(CleanData);
	}
};
REGISTER_PDE_TYPE(Gui::WebControl);

//---------------------------------------------------------------------------------------
// attributes.
//---------------------------------------------------------------------------------------
namespace Gui
{

	WebControl::WebControl()
		: web_player(NullPtr)
		, world_pos(Vector2::kZero)
	{
	}

	WebControl::~WebControl()
	{
	}

	void WebControl::OnPaint(PaintEventArgs & e)
	{
		if (e.render)
		{
			if (!web_player)
			{
				web_player = ptr_new WebPlayer;
				web_player->InitBrowser(world_pos.x,world_pos.y,m_Size.x,m_Size.y,m_Text.Str(),false);
			}
			else
			{
				web_player->OnRender();

				if (web_player->texture_data)
				{
					tempc_ptr(TextureBase) orgTexture = e.render->GetTexture();

					e.render->SetTexture(web_player->texture_data);
					e.render->DrawWindow(Core::Rectangle(0,0,m_Size.x,m_Size.y), Core::Rectangle(0,0,0,0), Core::Rectangle(0,0,0,0));
					e.render->SetTexture(orgTexture);
				}
			}
		}
	}

	void WebControl::OnInputEvent(InputEventArgs & e)
	{
		InputEventArgs e_tmp(e);
		e_tmp.CursorPosition = ScreenToClient(e_tmp.CursorPosition);

		if (web_player)
		{
			if (e_tmp.IsMouseEvent())
			{
				web_player->OnMouseInput(e_tmp);
			}
			else if (e_tmp.IsKeyEvent())
			{
				web_player->OnKeyInput(e_tmp);
			}
		}

		if (!e_tmp.Handled)
			Control::OnInputEvent(e);
	}

	void WebControl::OnLocationChanged(MoveEventArgs & e)
	{
		CalcWorldLocation();
	}

	void WebControl::OnSizeChanged(ResizeEventArgs & e)
	{
		if (web_player)
		{
			web_player->Resize(m_Size.x, m_Size.y);
		}
	}

	void WebControl::OnFocusChanged(EventArgs & e)
	{
		Control::OnFocusChanged(e);

		if (GetFocused())
		{
			ImeUi_EnableIme(true);

			CalcWorldLocation();

			ImeUi_SetCaretPosition(world_pos.x, world_pos.y);
		}
		else
		{
			ImeUi_FinalizeString();
			ImeUi_EnableIme(false);
		}

		if (web_player)
		{
			web_player->OnFocusChanged(GetFocused());
		}
	}

	void WebControl::CalcWorldLocation()
	{
		Vector2 caret_pos(GetLocation());

		sharedc_ptr(Control) pParent = GetParent();
		while (pParent)
		{
			caret_pos += pParent->GetLocation();

			pParent = pParent->GetParent();
		}

		world_pos = caret_pos;

		if (web_player)
		{
			web_player->Relocation(world_pos.x, world_pos.y);
		}
	}

	void WebControl::CleanData()
	{
		if (web_player)
			web_player = NullPtr;
	}
}

#endif
