namespace Gui
{
	class PopupFrameSkin : public ControlSkin
	{
	public:
		PopupFrameSkin()
		{}

	public:
		INLINE_PDE_ATTRIBUTE_RW(HighlightImage,		tempc_ptr(Image));

	private:
		sharedc_ptr(Image)		m_HighlightImage;
	};

}


namespace Gui
{
	class PopupFrame : public Control
	{
		DECLARE_PDE_OBJECT(PopupFrame,Control)

	public:
		INLINE_PDE_ATTRIBUTE_RW (Owner,				tempc_ptr(Control));
		INLINE_PDE_ATTRIBUTE_RW (OutwardBoundary,	Core::Vector4);

	public:
		PopupFrame();

		~PopupFrame();

		/// on frame update
		void OnFrameUpdate(EventArgs & e);
		
		/// on paint
		void OnPaint(PaintEventArgs & e);

		/// on input event
		void OnInputEvent(InputEventArgs & e);

		void Show(const Core::Rectangle& globalBaseRect, F32 timer);

		void UpdateLocation(const Core::Rectangle& globalBaseRect);

		bool CheckVisibility();

		void IncreaseAlpha();

		void DecreaseAlpha();

		void Cancel();

		void Terminate();

	protected:
		F32						m_Timer;
		bool					m_Started;

		bool					m_Showing;

		F32						m_Alpha;
		
		Core::Vector4			m_OutwardBoundary;
		sharedc_ptr(Control)		m_Owner;
	};
}