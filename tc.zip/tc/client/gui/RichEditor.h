namespace Gui
{
	struct RichMsg 
	{
		Core::String		msg;
		Core::Rectangle		rect;
		Core::ARGB			color;
		int					line;
		sharedc_ptr(Button)	m_Button;
		sharedc_ptr(MouseControl) m_MouseCtr;
		RichMsg()
			: m_Button(NullPtr)
			, m_MouseCtr(NullPtr)
		{
		}
		
	};
	struct UsualMsg 
	{
		Core::String		msg;
		Core::ARGB			color;
		bool				isnew;
		sharedc_ptr(Button)	m_Button;
		sharedc_ptr(MouseControl) m_MouseCtr;
		UsualMsg()
			: m_Button(NullPtr)
			, m_MouseCtr(NullPtr)
		{
		}
	};

	class RichEdit : public ScrollableControl
	{
	public:
		DECLARE_PDE_OBJECT(RichEdit, ScrollableControl);
		DECLARE_PDE_ATTRIBUTE_RW(MaxLine, int);
		DECLARE_PDE_ATTRIBUTE_R	(Click_Name,		Core::String);
		DECLARE_PDE_ATTRIBUTE_W	(Line_Space,		float);
		DECLARE_PDE_ATTRIBUTE_RW(Text_Shadow,		bool);

		DECLARE_PDE_EVENT(EventClick_Name,		EventArgs);
	public:
		RichEdit();
		~RichEdit();
		virtual void OnCreate();
		virtual void OnPaint(PaintEventArgs & e);
		
		void AddMsg(Core::String & msg, Core::ARGB color, bool isnew, bool is_btn = false);
		void CleanAll();

	private:
		void CheckMsg(Core::String & msg, Core::ARGB color, bool isnew,sharedc_ptr(Button) btn = NullPtr,sharedc_ptr(MouseControl) MouseCtr = NullPtr);
		void CheckMaxLine();

		void On_ButtonClick(by_ptr(void) sender, InputEventArgs & e);

	protected:
		int mLineNum;
		int mMaxLine;
		//cursor`s postion
		float pos_x;
		Core::String	m_Click_Name;
		float			m_Line_Space;
		bool			m_Text_Shadow;

	private:
		Core::Array<UsualMsg> all_msg;
		Core::Array<RichMsg> all_richmsg;
	};
}
