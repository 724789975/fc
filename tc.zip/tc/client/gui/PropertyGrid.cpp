#include "pch.h"

using namespace Core;
using namespace Gui;
using namespace Client;


DEFINE_PDE_TYPE_CLASS(Gui::PropertyGrid)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::ListTreeView);
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_METHOD(AddItem);
		ADD_PDE_METHOD(DeleteChild);

		ADD_PDE_EVENT(EventItemChange);
		ADD_PDE_EVENT(EventPropertyChanged);
		ADD_PDE_EVENT(EventDropDown);

		ADD_PDE_PROPERTY_RW(EditorTextboxStyle);
		ADD_PDE_PROPERTY_RW(EditorComboBoxStyle);
		ADD_PDE_PROPERTY_RW(EditorButtonStyle);
	}
};

REGISTER_PDE_TYPE(Gui::PropertyGrid);
namespace Gui
{
	PropertyGrid::PropertyGrid()
		: m_Splitting(false)
		, m_SplitRate(0.5f)
		, m_SelectProperty(NullPtr)//PdeHandle::kNull)
		, m_OldValueSaved(false)
	{
	}

	PropertyGrid::~PropertyGrid()
	{
	}
}


//--------------------------------------------------------------------------------------
// Attribute
//--------------------------------------------------------------------------------------
namespace Gui
{

	PDE_ATTRIBUTE_GETTER(PropertyGrid, GroupRoot, by_ptr(PdePropertyItem))
	{
		return m_GroupRoot;
	}
}


//--------------------------------------------------------------------------------------
// Event
//--------------------------------------------------------------------------------------
namespace Gui
{

	//static const PdeClassPtr kEmpty;
	static sharedc_ptr(void) kEmpty;
	static const F32 OWNDRAW_WIDTH = 20.f;

	void PropertyGrid::OnCreate()
	{
		Super::OnCreate();

		m_GroupRoot = ptr_static_cast<PdePropertyItem>(CreateItem());

		AddColumn("Name");
		AddColumn("Value");

		SetGridLines(true);
		SetShowLines(false);
		SetHeaderVisible(false);
		SetHScrollBarDisplay(ScrollableControl::kHide);
		SetShowNodeToolTip(true);
	}

	void PropertyGrid::OnDestroy()
	{
		if (m_GroupRoot/*.IsValid()*/)
		{
		}

		Super::OnDestroy();
	}

	void PropertyGrid::OnLayout(EventArgs & e)
	{
		Super::OnLayout(e);

		m_SplitterPos = (S32)(GetSize().x * m_SplitRate);

		if (m_DropDownBtn)// != PdeHandle::kNull)
		{
			m_DropDownBtn->SetSize(Vector2(m_ItemHeight - 1, m_ItemHeight - 1));
			m_DropDownBtn->SetLocation(Vector2(GetDisplayRect().GetExtent().x - m_ItemHeight - 1, m_ItemHeight * ItemToDisplayIndex(GetSelectedItem()) + 1));
		}

		if (m_Editor)// != PdeHandle::kNull)
		{
			by_ptr(PdePropertyItem) item = ptr_static_cast<PdePropertyItem>(GetSelectedItem());

			Vector2 pos(m_SplitterPos + 1, m_ItemHeight * ItemToDisplayIndex(GetSelectedItem()) + 1);

			if (item/*.IsValid()*/ && item->GetOwnDraw())
				pos.x += OWNDRAW_WIDTH;

			F32 btnWidth = m_DropDownBtn /*!= PdeHandle::kNull && m_DropDownBtn.IsValid()*/? m_DropDownBtn->GetSize().x: 0;
			F32 width = GetDisplayRect().GetExtent().x - pos.x - btnWidth - 8;
			m_Editor->SetSize(Vector2(width, m_ItemHeight - 1));
			m_Editor->SetLocation(pos);
		}

		GetColumns()->SetWidth(0, m_SplitterPos);
		GetColumns()->SetWidth(1, GetDisplayRect().GetExtent().x - m_SplitterPos);

		Invalid();
	}

	bool PropertyGrid::OnMouseEvent(InputEventArgs & input)
	{
		bool handled = false;

		Vector2 localPos = ScreenToClient(input.CursorPosition);

		bool pointed = GetDisplayRect().IsPointInside(localPos);

		bool isSplit = CheckSplit(localPos);

		if (isSplit)
		{
			SetCursorShape(Screen::kCursorSizeWE);
			handled = true;
		}

		switch(input.Type)
		{
		case InputEventArgs::kMouseDown:
		case InputEventArgs::kMouseDoubleClick:
			if (input.Code == MC_LEFT_BUTTON)
			{
				if (isSplit)
				{
					SetCapture(true);

					m_Splitting = true;
					handled = true;
				}

				if (input.ControlKeyDown && GetMultiSelect())
				{
					U32 index = localPos.y / m_ItemHeight;
					sharedc_ptr(ListItem) item = DisplayIndexToItem(index);

					Vector2 pos(m_SplitterPos, m_ItemHeight * index);
					Core::Rectangle rect(pos, Vector2(GetDisplayRect().GetExtent().x, m_ItemHeight * (index + 1)));

					if (item/*.IsValid()*/ && item->GetSelected() && rect.IsPointInside(localPos))
					{
						SetSelectedItem(item);
						handled = true;
					}
				}
			}
			break;

		case InputEventArgs::kMouseUp:
			if (input.Code == MC_LEFT_BUTTON && m_Splitting)
			{
				SetCapture(false);

				m_Splitting = false;
				handled = true;
			}
			break;

		case InputEventArgs::kMouseMove:
			if (m_Splitting)
			{
				m_SplitterPos = Min(Max(localPos.x, LEVELSPACE + MIN_WIDTH), GetDisplayRect().Max.x - MIN_WIDTH);
				m_SplitRate = m_SplitterPos / GetSize().x;

				DirtyLayout();
				handled = true;
			}
			break;
		}

		return handled;
	}

	void PropertyGrid::OnInputEvent(InputEventArgs & e)
	{

		if (e.IsMouseEvent())
		{
			e.Handled = OnMouseEvent(e);
		}

		if (!e.Handled)
			Super::OnInputEvent(e);
	}

	/// on enter
	void PropertyGrid::OnEnter(EventArgs & e)
	{
		Super::OnEnter(e);
		///--?
		if (m_SelectProperty/*.IsValid()*/ && m_SelectProperty == GetSelectedItem() 
			&& 
			!m_Editor/*PdeHandle::kNull*/ && 
			!m_DropDownBtn/*PdeHandle::kNull*/
			)
		{
			CreateEditor(m_SelectProperty);
		}
	}

	/// on leave
	void PropertyGrid::OnLeave(EventArgs & e)
	{
		Super::OnLeave(e);
	}

	/// on node column mouse enter
	void PropertyGrid::OnNodeColumnMouseEnter(ListItemInputEventArgs & e)
	{
		sharedc_ptr(PdePropertyItem) p = ptr_static_cast<PdePropertyItem>(e.Item);

		U32 index = e.Column;
		sharedc_ptr(Header) hHeader = GetColumns();

		if (!GetShowNodeToolTip())
			return;

		if(p && !p->GetIsGroup() && index < 2)
		{
		}
	}

	void PropertyGrid::OnSelectItemChanged(ListItemEventArgs & e)
	{
		by_ptr(PdePropertyItem) p = ptr_static_cast<PdePropertyItem>(e.Item);

		if (m_SelectProperty != p || !m_Editor/*.IsValid()*/)
		{
			if (m_Editor/*.IsValid()*/)
			{
				m_Editor->SetParent(NullPtr);//PdeHandle::kNull);
				m_Editor = NullPtr;// PdeHandle::kNull;
			}

			if (m_DropDownBtn/*.IsValid()*/)
			{
				m_DropDownBtn->SetParent(NullPtr);//PdeHandle::kNull);
				m_DropDownBtn = NullPtr;//PdeHandle::kNull;
			}

			if (p/*.IsValid()*/)
			{
				CreateEditor(p);
			}

			m_SelectProperty = p;

			Super::OnSelectItemChanged(e);
		}
	}

	void PropertyGrid::OnItemChange(ListItemEventArgs & e)
	{
		EventItemChange.Fire(ptr_static_cast<Self>(this)/*GetHandle()*/, e);
	}

	/// on property changed
	void PropertyGrid::OnPropertyChanged(ValueChangeEventArgs & e)
	{
		EventPropertyChanged.Fire(ptr_static_cast<Self>(this)/*GetHandle()*/, e);
	}

	//bug?
	void PropertyGrid::OnDrawItem(DrawItemEventArgs & e)
	{
		by_ptr(PdePropertyItem) item = ptr_static_cast<PdePropertyItem>(e.Item);

		if (item/*.IsValid()*/)
		{
			if (!e.Item->GetCanSelect())
			{
				e.Handled = true;
				return;
			}

			XRGB color = !e.ControlEnable || item->GetReadonly()? XRGB(128, 128, 128): XRGB(0, 0, 0);
			Core::Rectangle rect = e.Rect;

			rect.Shrink(0, 1, 0, 0);
			switch (e.Column)
			{
			case 0:
				{
				color = e.Selected? XRGB(255,0,0): color;
				Core::String str=item->GetText(0);
				e.render->DrawString(
					GetFont(), 
					color,//text color 
					ARGB(0,255,255,255),//GetBackgroundColor(), 
					rect,//text rect
					e.Item->GetText(0),//what text
					Unit::kAlignLeftMiddle);

				e.Handled = true;
				}
				break;

			case 1:
				{
					/// draw onw item rect
					if (item->GetOwnDraw())
					{
						rect.Max.x = rect.Min.x + OWNDRAW_WIDTH;
						Core::Rectangle drawRect(rect);
						drawRect.Shrink(0, 1, 2, 1);
						drawRect.Shrink(1);

						// backup worldmatrix  rect
						Matrix44 OrgWorld = e.render->GetWorld();
						Matrix44 newWorld(OrgWorld);

						newWorld.TranslateLocal(Vector3(drawRect.Min, 0));
						e.render->SetWorld(newWorld);
						
						drawRect.Move(-drawRect.Min);

						DrawItemEventArgs drawEvent(e);
						drawEvent.Item = item;
						drawEvent.Rect = drawRect;

						OnItemOwnDraw(drawEvent);

						e.render->SetWorld(OrgWorld);

						rect.Min.x = rect.Max.x;
						rect.Max.x = e.Rect.Max.x;
					}

					Core::String str=item->GetItemString();

					if(!e.Selected || !m_Editor)
					{
						//Only draw the value when it's not selected, when selected, we will draw the edit control
						e.render->DrawString(
							GetFont(), 
							color,//text color 
							ARGB(0,255,255,255),//GetBackgroundColor(), 
							rect,//text rect
							item->GetItemString(),//what text
							GetColumns()->GetAlign(e.Column));
					}

					e.Handled = true;
				}
				break;

			default:
				break;
			}
		}

		if (!e.Handled)
			Super::OnDrawItem(e);
	}

	void PropertyGrid::OnDrawItemBackgroud(DrawItemEventArgs & e)
	{
		by_ptr(PdePropertyItem) item = ptr_static_cast<PdePropertyItem>(e.Item);
		
		tempc_ptr(ListItemSkin) skin = GetItemSkin();


		if (item)
		{
			if(skin)
			{
				Core::Rectangle rect = e.Rect;

				Skin::DrawImage(e.render, e.Row%2?skin->GetBackgroundImageOp():skin->GetBackgroundImage(), rect);

				if (!e.Item->GetCanSelect())
				{
					e.Handled = true;
				}
				else if (e.Selected)
				{
					rect.Max.x = m_SplitterPos;

					Skin::DrawImage(e.render, skin->GetSelectedImage(), rect);

					e.Handled = true;
				}
				else if(m_PointedItem == e.Item)
				{
					rect.Max.x = m_SplitterPos;

					Skin::DrawImage(e.render, skin->GetHoverImage(), rect);
					e.Handled = true;
				}
			}
			else
			{
				Core::Rectangle rect = e.Rect;
				///??Font change
				rect.Max.x = rect.Min.x + 16;

				e.render->DrawRectangle(rect,rect,ARGB(212,208,200));

				rect.Min.x = rect.Max.x;

				if (item->GetIsGroup())
				{
					rect.Max.x = e.Rect.Max.x;

					e.render->DrawRectangle(rect,rect,ARGB(128,212,208,200));
				}
				else if (!e.Item->GetCanSelect())
				{
					e.Handled = true;
				}
				else if (e.Selected)
				{
					rect.Max.x = m_SplitterPos;
					XRGB selectColor = !e.ControlEnable || GetActive() ? XRGB(49,106,197) : XRGB(128,128,128);

					e.render->DrawRectangle(rect,rect,selectColor);

					e.Handled = true;
				}
			}
		}
	}

	void PropertyGrid::OnItemOwnDraw(DrawItemEventArgs & e)
	{
		by_ptr(PdePropertyItem) item = ptr_static_cast<PdePropertyItem>(e.Item);

		if (item/*.IsValid()*/)
		{
			//const PdeClassPtr & value = item->GetValue();
			const sharedc_ptr(void) value = ptr_static_cast<void>(item->GetValue());

			ARGB * color = NULL;
			
			if (value)
			{
				//--?
				//PdeClassPtr ptr = PdeTypeInfo::ChangeType(value, PdeTypeTraits<ARGB>::Type());

				tempc_ptr(ARGB) ptr = ptr_static_cast<ARGB>(value);

				if (ptr)
					color = Boxing<ARGB*>::Unboxing(ptr);
				if (color)
				{
					ARGB cpColor(*color);
					cpColor.a = 255;
					e.render->DrawRectangle(e.Rect,e.Rect,cpColor);
				}
			}
		}
	}

	void PropertyGrid::OnDropDownClick(by_ptr(void) sender, Client::InputEventArgs & e)
	{
		ListItemEventArgs dropDownEvent;
		dropDownEvent.Item = GetSelectedItem();
		EventDropDown.Fire(ptr_static_cast<Self>(this)/*GetHandle()*/, dropDownEvent);
	}

	void PropertyGrid::Editor_ValueEnter(by_ptr(void) sender, EventArgs & e)
	{
#if 1		
		if (m_Editor/*.IsValid()*/)
		{
			CStrBuf<256> buf;
			Core::String str;
			tempc_ptr(PdePropertyItem) select = ptr_static_cast<PdePropertyItem>(GetSelectedItem());

			// value changed event
			bool changed = false;
			ValueChangeEventArgs changedEvent;

			by_ptr(PdePropertyItem) changedItem = select/*->GetHandle()*/;
			by_ptr(PdePropertyItem) p = ptr_static_cast<PdePropertyItem>(changedItem->GetParent());

			while (p/*.IsValid()*/ && (p != GetRootItem()) && p->GetPropertiesSupported())
			{
				changedItem = p;
				p = ptr_static_cast<PdePropertyItem>(p->GetParent());
			}

			if (changedItem/*.IsValid()*/)
			{
				changedEvent.OldValue = changedItem->GetValue();
			}
#if 0
			if (select && select->IsNumeric())
			{
				buf.format("%f", ((HEdtUISpinBox)m_Editor)->GetValue());
				str = buf;

				if (changedItem/*.IsValid()*/ && !m_OldValueSaved)
				{
					m_OldValue = changedItem->GetValue();
					m_OldValueSaved = true;
				}
			}
			else
			{
				str = m_Editor->GetText();
				changed = true;
			}

			ValueEnter(str);
#endif

#define XB_ADD
#if defined XB_ADD
#if 0
			str = m_Editor->GetText();
			ValueEnter(str);
#endif
#if 1
			if (select && select->IsNumeric())
			{
				str = (ptr_static_cast<Textbox>(m_Editor))->GetText();

				if (changedItem/*.IsValid()*/ && !m_OldValueSaved)
				{
					m_OldValue = changedItem->GetValue();
					m_OldValueSaved = true;
				}
			}
			else //
			{
				str = m_Editor->GetText();
				changed = true;
			}

			ValueEnter(str);
#endif

#endif
			if (select && m_Editor/*.IsValid()*/)
			{
				String itemText = select->GetItemString();
				m_Editor->SetText(itemText);
				//EdtUITextBox * control = handle_cast<EdtUITextBox>(m_Editor);
				tempc_ptr(Textbox) control = ptr_static_cast<Textbox>(m_Editor);

				if (control)
					control->SetSelection(0, -1);
			}

			if (changed && changedItem/*.IsValid()*/)
			{
				changedEvent.NewValue = changedItem->GetValue();
				OnPropertyChanged(changedEvent);
			}
		}
#endif
	}

	/// spin box value changed end
	void PropertyGrid::SpinBox_ValueChangedEnd(by_ptr(void) sender, ValueChangeEventArgs & e)
	{
#if 1
		tempc_ptr(PdePropertyItem) select = ptr_static_cast<PdePropertyItem>(GetSelectedItem());

#endif
	}

}


//--------------------------------------------------------------------------------------
// Method
//--------------------------------------------------------------------------------------
namespace Gui
{

	void PropertyGrid::ValueEnter(const Core::String & value)
	{
		bool flag = false;

		sharedc_ptr(PdePropertyItem) selectedItem = ptr_static_cast<PdePropertyItem>(GetSelectedItem());
		
		if (!selectedItem)
			return;

		tempc_ptr(ListItem) item = GetRootItem()->GetFirstChild();
		for (item; item; item = item->GetNextNode(flag))
		{
			flag = !GetTreeVisible() || !item->GetExpanded();
			by_ptr(PdePropertyItem) p = ptr_static_cast<PdePropertyItem>(item);

			if (p && p->GetSelected())
			{
				p->StringToValue(value);

				if (p->GetInvalid())
				{
					by_ptr(PdePropertyItem) update = p;

					while (UpdateParent(update))
						update = ptr_static_cast<PdePropertyItem>(update->GetParent());

					p->SetInvalid(false);
					ListItemEventArgs e;
					e.Item = update;
					OnItemChange(e);

					Invalid();
				}
			}
		}
	}

	bool PropertyGrid::UpdateParent(by_ptr(PdePropertyItem) item)
	{
		if (item/*.IsValid()*/)
		{
			by_ptr(PdePropertyItem) p = ptr_static_cast<PdePropertyItem>(item->GetParent());

			if (p/*.IsValid()*/ && (p != GetRootItem()/*GetRoot*/) && p->GetPropertiesSupported())
			{
				p->SetProperty(item);
				return true;
			}
		}
		return false;
	}

	void PropertyGrid::CreateEditor(by_ptr(PdePropertyItem) item)
	{
#if 1
		if (item/*.IsValid()*/)
		{
			const tempc_ptr(void) value = item->GetValue();

			if (item->GetStandardValuesSupported() && !item->GetReadonly())
			{
				m_Editor = ptr_static_cast<ComboBox>(PdeTypeInfo::CreateInstance(PDE_TYPE_NAME(ComboBox)));
				m_Editor->SetParent(ptr_static_cast<Self>(this));
				ptr_static_cast<ComboBox>(m_Editor)->SetReadonly(true);
				m_Editor->SetStyle(m_EditorComboBoxStyle);				
				m_Editor->SetFocused(true);

				Core::Array<PdeEnumInfo::EnumItem> values = item->GetStandardValues(); 
				
				for (U32 i=0; i<values.Size(); ++i)
				{
					(ptr_static_cast<ComboBox>(m_Editor))->AddItem(values[i].name);
					if (values[i].id != -1)
						(ptr_static_cast<ComboBox>(m_Editor))->SetId(i, values[i].id);
				}

				(ptr_static_cast<ComboBox>(m_Editor))->SetText(item->GetItemString());
				(ptr_static_cast<ComboBox>(m_Editor))->SetReadonly(true);
				(ptr_static_cast<ComboBox>(m_Editor))->EventValueChanged.Subscribe(
					NewDelegate(&Self::Editor_ValueEnter, ptr_static_cast<Self>(this))
					);
			}
			else
			{
				if (item->IsNumeric() && !item->GetReadonly())
				{
#if 0
					//all spinbox change to textbox
					m_Editor = CreateControl(PDE_TYPE_NAME(EdtUISpinBox));

					((HEdtUISpinBox)m_Editor)->SetBorderStyle(BorderStyle::kNone);
					((HEdtUISpinBox)m_Editor)->SetIsInt(item->VariableType() != PdeTypeInfo::kFloat && item->VariableType() != PdeTypeInfo::kDouble);

					if (item->VariableType() == PdeTypeInfo::kUInt32
						|| item->VariableType() == PdeTypeInfo::kUInt16
						|| item->VariableType() == PdeTypeInfo::kUInt8)
						((HEdtUISpinBox)m_Editor)->SetMinValue(0);

					if (value && value->GetType()->IsNumeric())
					{
						((HEdtUISpinBox)m_Editor)->SetValue(static_cast<const PdeNumericTypeInfo*>(value->GetType())->ToNumber(value));
					}
					//m_Editor->SetFocus(true);
					((HEdtUISpinBox)m_Editor)->SetSelection(0, -1);
					((HEdtUISpinBox)m_Editor)->EventValueChange.Subscribe(GetHandle(), &Self::Editor_ValueEnter);
					((HEdtUISpinBox)m_Editor)->EventValueChangedEnd.Subscribe(GetHandle(), &Self::SpinBox_ValueChangedEnd);
#endif

					m_Editor = ptr_static_cast<Textbox>(PdeTypeInfo::CreateInstance(PDE_TYPE_NAME(Textbox)));

					m_Editor->SetParent(ptr_static_cast<Self>(this));

					m_Editor->SetStyle(m_EditorTextboxStyle);

					//m_Editor->SetFocus(true);
					m_Editor->SetText(item->GetItemString());

					(ptr_static_cast<Textbox>(m_Editor))->SetSelection(0, -1);
					m_Editor->SetFocused(true);

					(ptr_static_cast<Textbox>(m_Editor))->EventValueEnter.Subscribe(
						NewDelegate(&Self::Editor_ValueEnter, ptr_static_cast<Self>(this)));

				}
				else
				{
					m_Editor = ptr_static_cast<Textbox>(PdeTypeInfo::CreateInstance(PDE_TYPE_NAME(Textbox)));

					m_Editor->SetParent(ptr_static_cast<Self>(this));

					m_Editor->SetStyle(m_EditorTextboxStyle);

					m_Editor->SetText(item->GetItemString());

					(ptr_static_cast<Textbox>(m_Editor))->SetSelection(0, -1);
					m_Editor->SetFocused(true);
					(ptr_static_cast<Textbox>(m_Editor))->EventValueEnter.Subscribe(
						NewDelegate(&Self::Editor_ValueEnter, ptr_static_cast<Self>(this)));
				}


				if (item->GetReadonly())
				{
					(ptr_static_cast<Textbox>(m_Editor))->SetReadonly(true);
					(ptr_static_cast<Textbox>(m_Editor))->SetTextColor(XRGB(128, 128, 128));
				}
			}

			by_ptr(PdePropertyItem) parent = ptr_static_cast<PdePropertyItem>(item->GetParent());
#if 1
			if (item->GetEditStyle() == PdePropertyItem::kModal)
			{
				m_DropDownBtn = ptr_new Button;

				m_DropDownBtn->SetBackgroundColor(ARGB(255, 255, 255, 0));
				
				m_DropDownBtn->SetParent(ptr_static_cast<Self>(this));

				m_DropDownBtn->SetStyle(m_EditorButtonStyle);
				
				m_DropDownBtn->EventClick.Subscribe(
					NewDelegate(&Self::OnDropDownClick, ptr_static_cast<Self>(this)));
			}
			else
			{
				tempc_ptr(const PdeTypeInfo) propertyType = item->GetPropertyType();

#if 0
				//temp modify --?
				if (propertyType &&
					!item->GetReadonly())
#endif
				{
					m_DropDownBtn = ptr_new Button;

					m_DropDownBtn->SetBackgroundColor(ARGB(255, 255, 0, 0));
					
					m_DropDownBtn->SetParent(ptr_static_cast<Self>(this));

					m_DropDownBtn->SetStyle(m_EditorButtonStyle);

					m_DropDownBtn->EventClick.Subscribe(
						NewDelegate(&Self::OnDropDownClick, ptr_static_cast<Self>(this)));
				}
			}
#endif
		}
#endif
	}

	bool PropertyGrid::CanExpand(by_ptr(ListItem) item)
	{
		return Super::CanExpand(item);
	}

	sharedc_ptr(ListItem) PropertyGrid::CreateItem()
	{
		return ptr_static_cast<ListItem>(PdeTypeInfo::CreateInstance(PDE_TYPE_NAME(PdePropertyItem)));
	}

	// create item
	sharedc_ptr(ListItem) PropertyGrid::CreateItem(by_ptr(PdeTypeInfo) typeInfo)//const PdeTypeInfo * typeInfo)
	{
		return ptr_static_cast<ListItem>(PdeTypeInfo::CreateInstance(PdePropertyItem::PropertyItemType(typeInfo)));
	}

	sharedc_ptr(PdePropertyItem) PropertyGrid::AddItem(by_ptr(ListItem) parent, const Core::String & name, 
		//const PdeClassPtr & value, 
		by_ptr(void) value,
		bool canExpand, bool readonly)
	{
		return AddItemWithType(parent, name, value, NullPtr, canExpand, readonly);
	}

	/// add item with typeinfo
	sharedc_ptr(PdePropertyItem) PropertyGrid::AddItemWithType(by_ptr(ListItem) parent, const Core::String & name, 
		by_ptr(void) value,
		by_ptr(PdeTypeInfo) typeInfo,
		bool canExpand, bool readonly)
	{
		sharedc_ptr(PdePropertyItem) item = ptr_static_cast<PdePropertyItem>(CreateItem(typeInfo));

		if (item/*.IsValid()*/)
		{
			item->SetText(0, name);
			item->SetValue(value);
			item->SetCanExpand(item->GetPropertiesSupported()? true: canExpand);
			item->SetParent(parent);
			item->SetLevel(!parent/*.IsValid()*/? 0: parent->GetLevel() + 1);
			item->SetReadonly(readonly);
			item->SetPropertyType(typeInfo);

			DirtyLayout();
		}

		return item;
	}

	void PropertyGrid::DeleteChild(by_ptr(ListItem) item)
	{
		if (item && item->GetFirstChild())
		{
			while (item->GetFirstChild())
			{
				DeleteNode(item->GetFirstChild());
			}
		}
	}

	void PropertyGrid::ToggleExpand(by_ptr(ListItem) item)
	{
		by_ptr(PdePropertyItem) p = ptr_static_cast<PdePropertyItem>(item);
		
		if (p/*.IsValid()*/ && p->GetPropertiesSupported())
		{
			if (!p->GetExpanded())
			{
				DeleteChild(p);
			}
			else
			{
				Core::Array<PdePropertyItem::PropertyItem> temp = p->GetProperties();

				for (U32 i=0; i<temp.Size(); ++i)
				{
					by_ptr(PdePropertyItem) item = AddItemWithType(p, temp[i].Name, temp[i].Value, PdeTypeInfo::FromName(temp[i].TypeName));

					if (item/*.IsValid()*/)
						item->SetReadonly(p->GetReadonly());
				}
			}
		}
	}

	bool PropertyGrid::CheckSplit(const Vector2 & pos)
	{
		if (pos.x > m_SplitterPos - SPLIT_WIDTH && pos.x < m_SplitterPos + SPLIT_WIDTH)
		{
			return true;
		}

		return false;
	}
}
