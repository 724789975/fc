namespace Gui
{
	/// base class of ui elements
	class  ScrollNumberButton : public Control
	{
		DECLARE_PDE_OBJECT(ScrollNumberButton, Control)

	public:
		DECLARE_PDE_EVENT(EventClick, InputEventArgs);
		DECLARE_PDE_EVENT(OnComplete, EventArgs);
	public:	
		DECLARE_PDE_ATTRIBUTE_RW(BackGroundImage, tempc_ptr(Image));
		DECLARE_PDE_ATTRIBUTE_RW(NumberGroundImage, tempc_ptr(Image));
		DECLARE_PDE_ATTRIBUTE_RW(ItemName, const Core::String &);
		DECLARE_PDE_ATTRIBUTE_RW(ItemType, const Core::String &);
		DECLARE_PDE_ATTRIBUTE_RW(ScrollNumRange, const Core::String &);
		DECLARE_PDE_ATTRIBUTE_RW(Level, const Core::Vector2 &);
		DECLARE_PDE_ATTRIBUTE_RW(LevelRatio, const Core::Vector2 &);
		DECLARE_PDE_ATTRIBUTE_RW(ItemVSpace, const Core::String &);
		DECLARE_PDE_ATTRIBUTE_RW(ScrollTime, float);
		DECLARE_PDE_ATTRIBUTE_RW(ScrollTipNum, int);
		DECLARE_PDE_ATTRIBUTE_RW(ItemSpace,int);

		/*DECLARE_PDE_ATTRIBUTE_RW(ForeGroundImage, tempc_ptr(Image));
		DECLARE_PDE_ATTRIBUTE_RW(KeepAspect, bool);
		DECLARE_PDE_ATTRIBUTE_RW(Expand, bool);
		DECLARE_PDE_ATTRIBUTE_R (DefaultSize,	Core::Vector2) { return Core::Vector2(20, 20); }
		DECLARE_PDE_ATTRIBUTE_RW(BeStatic, bool);
		DECLARE_PDE_ATTRIBUTE_RW(Highlighted, bool);*/
	public:
		///constructor
		ScrollNumberButton();

		///destructor
		~ScrollNumberButton();

		/// on autosize
		virtual void OnAutoSize(AutoSizeEventArgs & e);

		/// on paint
		virtual void OnPaint(PaintEventArgs & e);

		/// on input event
		virtual void OnInputEvent(InputEventArgs & e);			

		// on click
		virtual void OnClick(Client::InputEventArgs &e);

		///new virtual functions
		virtual void PaintBackground(PaintEventArgs & e);

		// frame update
		virtual void OnFrameUpdate(Core::EventArgs & e);

		void Reset();
	public:
		//virtual void Click();

	protected:
		bool				m_KeepAspect;
		bool				m_Expand;
		sharedc_ptr(Image)	m_BackGroundImage;		
		sharedc_ptr(Image)   m_NumberGroundImage;
		sharedc_ptr(Client::Texture2D) m_Number_Image[10];

		Core::String	        m_ItemName;
		Core::String           m_ItemType;
		Core::String           m_ItemVSpace;
		Core::String          m_ItemNumberRange;
		Core::Vector2          m_Level;
		Core::Vector2          m_LevelRatio;
		float					m_all_scroll_time;
		int					m_ScrollTipNum;

		struct ItemInfo
		{
			Core::String name;
			float vspace;
			Core::String type;
		};
		Core::Array<ItemInfo> m_ItemList;
		Core::Array<Core::Vector2> m_NumRange;

		bool		m_MouseHoldDown	:1;
		bool		m_MousePointed	:1;		
		bool		m_Highlighted	:1;
		bool		m_IsStatic		:1;

		int        m_start_num;
		int			m_end_num;

		int        m_per_num;
		float		m_per_time;
		float		m_per_time1;
		float      m_scroll_time;
		float      m_scroll_time1;
		float      m_scroll_ratio;
		int	       m_scroll_index;

		float     m_up_ratio;
		float     m_up_pertime;
		float     m_up_time;
		int       m_up_flag;
		int       m_ItemSpace;
		int      m_movetext_flag;
		float     m_movetext_time;
		float     m_movetext_max_time;
		float     m_movetext_offset;

		bool    m_isRun: 1;

		sharedc_ptr(Client::Font) font_1;
		sharedc_ptr(Client::Font) font_2;
	};
}