namespace Gui
{
	class Chart :	public Control
	{
		struct Node 
		{
			Core::String	Date;
			F32				Rate;
			Node(const Core::String & data,F32 rate)
				: Date(data)
				, Rate(rate)
			{

			}
		};
	public:
		Chart(void);

		~Chart(void);

		void OnCreate();

		void OnPaint(PaintEventArgs & e);

	public:
		void Clear();

		void AddNode(const Core::String & data,F32 rate);

	private:
		Core::FixedArray<Core::XRGB,6>		m_aRateColor;
		Core::Array<Node>					m_aNode;
		sharedc_ptr(Client::Texture2D)		m_chartBG;
	};
}

namespace Gui
{
	class ChartSkin : public ControlSkin
	{
	public:
		INLINE_PDE_ATTRIBUTE_RW(ChartBGImage,	tempc_ptr(Image));

	private:
		sharedc_ptr(Image) m_ChartBGImage;
	};
}