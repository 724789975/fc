#include "pch.h"

using namespace Core;
using namespace Gui;
using namespace Client;

DEFINE_PDE_TYPE_CLASS(Gui::CBWindowSkin)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::ControlSkin);
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		//skin
		ADD_PDE_PROPERTY_RW(CBNormalImage);
		ADD_PDE_PROPERTY_RW(CBHoverImage);
		ADD_PDE_PROPERTY_RW(CBDownImage);
	}
};
REGISTER_PDE_TYPE(Gui::CBWindowSkin);

DEFINE_PDE_TYPE_CLASS(Gui::CBWindow)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::Control);
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		//close button
		ADD_PDE_PROPERTY_RW(CBSize);
		ADD_PDE_PROPERTY_RW(CBLocation);
		ADD_PDE_PROPERTY_RW(CBVisible);
		ADD_PDE_EVENT(EventCBClick);
	}
};
REGISTER_PDE_TYPE(Gui::CBWindow);

namespace Gui
{
	//close button Get and Set
	PDE_ATTRIBUTE_GETTER(CBWindow, CBSize, Core::Vector2)
	{
		return m_CBSize;
	}
	PDE_ATTRIBUTE_SETTER(CBWindow, CBSize, Core::Vector2)
	{
		if(m_CBSize == value)
			return;

		m_CBSize = value;
		Invalid();
	}

	PDE_ATTRIBUTE_GETTER(CBWindow, CBLocation, Core::Vector2)
	{
		return m_CBLocation;
	}
	PDE_ATTRIBUTE_SETTER(CBWindow, CBLocation, Core::Vector2)
	{
		if(m_CBLocation == value)
			return;

		m_CBLocation = value;
		Invalid();
	}

	PDE_ATTRIBUTE_GETTER(CBWindow, CBVisible, bool)
	{
		return m_CBVisible;
	}
	PDE_ATTRIBUTE_SETTER(CBWindow, CBVisible, bool)
	{
		if(m_CBVisible == value)
			return;

		m_CBVisible = value;
		Invalid();
	}
}

namespace Gui
{
	CBWindow::CBWindow()
	: m_CBSize(Core::Vector2(25, 20))
	, m_CBLocation(Core::Vector2(0, 0))
	, m_CBVisible(false)
	{
	}

	CBWindow::~CBWindow()
	{
	}

	void CBWindow::OnCreate()
	{
		Super::OnCreate();

		m_CloseBtn = ptr_new Button;
		m_CloseBtn->SetVisible(m_CBVisible);
		m_CloseBtn->SetParent(ptr_static_cast<CBWindow>(this));
		m_CloseBtn->SetLocation(m_CBLocation);
		m_CloseBtn->SetSize(m_CBSize);
		m_CloseBtn->EventClick.Subscribe(NewDelegate(&CBWindow::_OnCBClick,ptr_static_cast<CBWindow>(this)));
	}

	void CBWindow::OnDestroy()
	{
		Super::OnDestroy();
	}

	// invalid
	void CBWindow::Invalid()
	{
		m_CloseBtn->SetVisible(m_CBVisible);
		m_CloseBtn->SetLocation(m_CBLocation);
		m_CloseBtn->SetSize(m_CBSize);

		Super::Invalid();
	}

	void CBWindow::_OnCBClick(by_ptr(void) sender, InputEventArgs & e)
	{
		EventCBClick.Fire(ptr_static_cast<CBWindow>(this), e);
	}


}