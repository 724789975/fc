#include "pch.h"

using namespace Core;
using namespace Client;
using namespace Gui;


DEFINE_PDE_TYPE_CLASS(Gui::ChangeControl)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::Control);
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_EVENT(EventPlayEnd);
		ADD_PDE_EVENT(EventPlayNextPoint);
		ADD_PDE_EVENT(EventToolTipsShow);

		ADD_PDE_PROPERTY_RW(NormLocation);
		ADD_PDE_PROPERTY_RW(Normsize);
		ADD_PDE_PROPERTY_RW(NormBackgroundColor);
		
		ADD_PDE_METHOD(SetSize_Picture);
		ADD_PDE_METHOD(SetSize_Picture_side);
		ADD_PDE_METHOD(InsertMovePoint);
		ADD_PDE_METHOD(Clear);
		ADD_PDE_METHOD(ReState);
	}
};

REGISTER_PDE_TYPE(Gui::ChangeControl);

namespace Gui
{
	ChangeControl::ChangeControl()
		: m_which(0)
		, m_Totale_timer(0.0f)
		, m_Normsize(Core::Vector2(0,0))
		, m_NormLocation(Core::Vector2(0,0))
		, m_tooltipStartshow(0.0f)
		, m_NormBackgroundColor(Core::ARGB(255,255,255,255))
	{
	}

	ChangeControl::~ChangeControl()
	{
	}

	PDE_ATTRIBUTE_GETTER(ChangeControl, NormLocation, Vector2)
	{
		return m_NormLocation;
	}

	PDE_ATTRIBUTE_SETTER(ChangeControl, NormLocation, Vector2)
	{
		if (m_NormLocation != value)
		{
			m_NormLocation = value;
		}
	}

	PDE_ATTRIBUTE_GETTER(ChangeControl, Normsize, Vector2)
	{
		return m_Normsize;
	}

	PDE_ATTRIBUTE_SETTER(ChangeControl, Normsize, Vector2)
	{
		if (m_Normsize != value)
		{
			m_Normsize = value;
		}
	}
	
	PDE_ATTRIBUTE_GETTER(ChangeControl, NormBackgroundColor, Core::ARGB)
	{
		return m_NormBackgroundColor;
	}

	PDE_ATTRIBUTE_SETTER(ChangeControl, NormBackgroundColor, Core::ARGB)
	{
		if (m_NormBackgroundColor != value)
		{
			m_NormBackgroundColor = value;
		}
	}

	void ChangeControl::OnFrameUpdate( EventArgs & e )
	{
		Control::OnFrameUpdate(e);
		// Tooltips
		if (m_tooltipStartshow > 0)
		{
			m_tooltipStartshow -= Task::GetFrameTime();
			if (m_tooltipStartshow <= 0)
			{
				m_tooltipStartshow = 0;
				EventToolTipsShow.Fire(ptr_static_cast<Control>(this), e);
			}
		}

		if (m_MovePoint.GetCount() == 0 || m_which >= m_MovePoint.GetCount())
		{
			return;
		}
		OnValidate();
		if (m_which >= m_MovePoint.GetCount())
		{
			return;
		}
		OnUpdateChangeControl();
	}

	void ChangeControl::SetSize_Picture()
	{
		tempc_ptr(ControlSkin) skin = GetSkin();
		if (skin && skin->GetBackgroundImage())
		{
			tempc_ptr(Image) BackImage = skin->GetBackgroundImage();
			Core::Vector2 size = BackImage->GetSize();
			m_NormLocation = m_NormLocation + (m_Normsize - size)/2;
			SetSize(size);
			SetLocation(m_NormLocation);
			F32 F_x = size.x/m_Normsize.x;
			F32 F_y = size.y/m_Normsize.y;
			int Tep_i = 0;
			while (Tep_i < m_MovePoint.GetCount())
			{
				Transition point =  m_MovePoint.GetAt(Tep_i);
				point.m_MovePosition += Core::Vector2(point.m_size.x * (1 - F_x) / 2 , point.m_size.y * (1 - F_y) / 2);
				point.m_size =  Core::Vector2(point.m_size.x * F_x ,point.m_size.y * F_y);
				m_MovePoint.SetAt(Tep_i,point);
				Tep_i++;
			}
			m_Normsize = size;
		}
	}

	void ChangeControl::SetSize_Picture_side()
	{
		tempc_ptr(ControlSkin) skin = GetSkin();
		if (skin && skin->GetBackgroundImage())
		{
			tempc_ptr(Image) BackImage = skin->GetBackgroundImage();
			Core::Vector2 size = BackImage->GetSize();
			m_NormLocation = m_NormLocation + (m_Normsize - size)/2;
			SetSize(size);
			SetLocation(m_NormLocation);
			F32 F_n = 0;
			if (size.x == size.y)
			{
				return;
			} 
			else
			{
				F_n = size.y / size.x;
			}
			int Tep_i = 0;
			while (Tep_i < m_MovePoint.GetCount())
			{
				Transition point =  m_MovePoint.GetAt(Tep_i);
				if (F_n > 1)
				{
					point.m_MovePosition += Core::Vector2(point.m_size.x * (1 - 1/F_n) / 2 , 0);
					point.m_size =  Core::Vector2(point.m_size.x / F_n ,point.m_size.y);
				} 
				else
				{
					point.m_MovePosition += Core::Vector2(0 , point.m_size.y * (1 - F_n) / 2);
					point.m_size =  Core::Vector2(point.m_size.x ,point.m_size.y * F_n);
				}
					
				m_MovePoint.SetAt(Tep_i,point);
				Tep_i++;
			}
			m_Normsize = size;
		}
	}

	void ChangeControl::InsertMovePoint(Core::Vector2 moveposition,F64 time,Core::Vector2 size,Core::ARGB color)
	{
		Transition NewPoint;
		NewPoint.m_Timer = time;
		NewPoint.m_size = size;
		NewPoint.m_MovePosition = moveposition;
		NewPoint.m_BackgroundColor = color;
		m_MovePoint.Add(NewPoint);
	}

	void ChangeControl::Clear()
	{
		m_MovePoint.Clear();
		ReState();
	}

	void ChangeControl::OnMouseEnter(Client::InputEventArgs & e)
	{
		EventMouseEnter.Fire(ptr_static_cast<Control>(this), e);
		m_tooltipStartshow = 0.5f;
	}

	void ChangeControl::OnMouseLeave(Client::InputEventArgs & e)
	{
		EventMouseLeave.Fire(ptr_static_cast<Control>(this), e);
		m_tooltipStartshow = 0.0f;
	}

	void ChangeControl::OnValidate()
	{
		while (m_Totale_timer > m_MovePoint.GetAt(m_which).m_Timer)
		{
			m_which++;
			if (m_which >= m_MovePoint.GetCount())
			{
				EventPlayEnd.Fire(ptr_static_cast<ChangeControl>(this),Client::InputEventArgs());
				break;
			}
			else
			{
				//SetBackgroundColor(m_MovePoint.GetAt(m_which).m_BackgroundColor);
				EventPlayNextPoint.Fire(ptr_static_cast<ChangeControl>(this),Client::InputEventArgs());
			}
		}
	}

	void ChangeControl::OnUpdateChangeControl()
	{
		F64 time =  Task::GetFrameTime();
		m_Totale_timer += time;
		F64 f;
		if (m_which > 0)
		{
			f = (m_Totale_timer - m_MovePoint.GetAt(m_which - 1).m_Timer) /(m_MovePoint.GetAt(m_which).m_Timer - m_MovePoint.GetAt(m_which - 1).m_Timer);
		} 
		else
		{
			f = m_Totale_timer / m_MovePoint.GetAt(m_which).m_Timer;
		}
		if (f > 1.0f)
			f = 1.0f;
		SetNewPosition(f);
		SetNewSize(f);
		SetNewBackgroundColor(f);
	}

	void ChangeControl::SetNewPosition(F64 n)
	{
		Core::Vector2 position = GetWhichLocation() + GetWhichLocationChange()*n;
		SetLocation(position);
	}

	Core::Vector2 ChangeControl::GetWhichLocation()
	{
		if (m_which > 0)
		{
			return m_MovePoint.GetAt(m_which - 1).m_MovePosition;
		} 
		else
		{
			return m_NormLocation;
		}
	}

	Core::Vector2 ChangeControl::GetWhichLocationChange()
	{
		if (m_which > 0)
		{
			return m_MovePoint.GetAt(m_which).m_MovePosition - m_MovePoint.GetAt(m_which - 1).m_MovePosition;
		} 
		else
		{
			return m_MovePoint.GetAt(m_which).m_MovePosition - m_NormLocation;
		}
	}

	void ChangeControl::SetNewSize(F64 n)
	{
		Core::Vector2 size = GetWhichSize() + GetWhichSizeChange()*n;
		SetSize(size);
	}

	Core::Vector2 ChangeControl::GetWhichSize()
	{
		if (m_which > 0)
		{
			return m_MovePoint.GetAt(m_which - 1).m_size;
		} 
		else
		{
			return m_Normsize;
		}
	}

	Core::Vector2 ChangeControl::GetWhichSizeChange()
	{
		if (m_which > 0)
		{
			return m_MovePoint.GetAt(m_which).m_size - m_MovePoint.GetAt(m_which - 1).m_size;
		} 
		else
		{
			return m_MovePoint.GetAt(m_which).m_size - m_Normsize;
		}
	}

	void ChangeControl::SetNewBackgroundColor(F64 n)
	{
		Core::ARGB ChangeColor = GetWhichBackgroundColorChange();
		Core::ARGB NormColor = GetWhichBackgroundColor();
		Core::ARGB color;
		if (m_which > 0)
		{
			if (m_MovePoint.GetAt(m_which).m_BackgroundColor.a > m_MovePoint.GetAt(m_which - 1).m_BackgroundColor.a)
			{
				color.a = NormColor.a + ChangeColor.a*n;
			} 
			else
			{
				color.a = NormColor.a - ChangeColor.a*n;
			}
			if (m_MovePoint.GetAt(m_which).m_BackgroundColor.b > m_MovePoint.GetAt(m_which - 1).m_BackgroundColor.b)
			{
				color.b = NormColor.b + ChangeColor.b*n;
			} 
			else
			{
				color.b = NormColor.b - ChangeColor.b*n;
			}
			if (m_MovePoint.GetAt(m_which).m_BackgroundColor.r > m_MovePoint.GetAt(m_which - 1).m_BackgroundColor.r)
			{
				color.r = NormColor.r + ChangeColor.r*n;
			} 
			else
			{
				color.r = NormColor.r - ChangeColor.r*n;
			}
			if (m_MovePoint.GetAt(m_which).m_BackgroundColor.g > m_MovePoint.GetAt(m_which - 1).m_BackgroundColor.g)
			{
				color.g = NormColor.g + ChangeColor.g*n;
			} 
			else
			{
				color.g = NormColor.g - ChangeColor.g*n;
			}
		} 
		else
		{
			if (m_NormBackgroundColor.a > m_MovePoint.GetAt(m_which).m_BackgroundColor.a)
			{
				color.a = NormColor.a - ChangeColor.a*n;
			} 
			else
			{
				color.a = NormColor.a + ChangeColor.a*n;
			}
			if (m_NormBackgroundColor.b > m_MovePoint.GetAt(m_which).m_BackgroundColor.b)
			{
				color.b = NormColor.b - ChangeColor.b*n;
			} 
			else
			{
				color.b = NormColor.b + ChangeColor.b*n;
			}
			if (m_NormBackgroundColor.r > m_MovePoint.GetAt(m_which).m_BackgroundColor.r)
			{
				color.r = NormColor.r - ChangeColor.r*n;
			} 
			else
			{
				color.r = NormColor.r + ChangeColor.r*n;
			}
			if (m_NormBackgroundColor.g > m_MovePoint.GetAt(m_which).m_BackgroundColor.g)
			{
				color.g = NormColor.g - ChangeColor.g*n;
			} 
			else
			{
				color.g = NormColor.g + ChangeColor.g*n;
			}
		}
		SetBackgroundColor(color);
	}
	
	Core::ARGB ChangeControl::GetWhichBackgroundColor()
	{
		if (m_which > 0)
		{
			return m_MovePoint.GetAt(m_which - 1).m_BackgroundColor;
		} 
		else
		{
			return m_NormBackgroundColor;
		}
	}

	Core::ARGB ChangeControl::GetWhichBackgroundColorChange()
	{
		Core::ARGB color;
		if (m_which > 0)
		{
			if (m_MovePoint.GetAt(m_which).m_BackgroundColor.a > m_MovePoint.GetAt(m_which - 1).m_BackgroundColor.a)
			{
				color.a = m_MovePoint.GetAt(m_which).m_BackgroundColor.a - m_MovePoint.GetAt(m_which - 1).m_BackgroundColor.a;
			} 
			else
			{
				color.a = m_MovePoint.GetAt(m_which - 1).m_BackgroundColor.a - m_MovePoint.GetAt(m_which).m_BackgroundColor.a;
			}
			if (m_MovePoint.GetAt(m_which).m_BackgroundColor.b > m_MovePoint.GetAt(m_which - 1).m_BackgroundColor.b)
			{
				color.b = m_MovePoint.GetAt(m_which).m_BackgroundColor.b - m_MovePoint.GetAt(m_which - 1).m_BackgroundColor.b;
			} 
			else
			{
				color.b = m_MovePoint.GetAt(m_which - 1).m_BackgroundColor.b - m_MovePoint.GetAt(m_which).m_BackgroundColor.b;
			}
			if (m_MovePoint.GetAt(m_which).m_BackgroundColor.r > m_MovePoint.GetAt(m_which - 1).m_BackgroundColor.r)
			{
				color.r = m_MovePoint.GetAt(m_which).m_BackgroundColor.r - m_MovePoint.GetAt(m_which - 1).m_BackgroundColor.r;
			} 
			else
			{
				color.r = m_MovePoint.GetAt(m_which - 1).m_BackgroundColor.r - m_MovePoint.GetAt(m_which).m_BackgroundColor.r;
			}
			if (m_MovePoint.GetAt(m_which).m_BackgroundColor.g > m_MovePoint.GetAt(m_which - 1).m_BackgroundColor.g)
			{
				color.g = m_MovePoint.GetAt(m_which).m_BackgroundColor.g - m_MovePoint.GetAt(m_which - 1).m_BackgroundColor.g;
			} 
			else
			{
				color.g = m_MovePoint.GetAt(m_which - 1).m_BackgroundColor.g - m_MovePoint.GetAt(m_which).m_BackgroundColor.g;
			}
		} 
		else
		{
			if (m_NormBackgroundColor.a > m_MovePoint.GetAt(m_which).m_BackgroundColor.a)
			{
				color.a = m_NormBackgroundColor.a - m_MovePoint.GetAt(m_which).m_BackgroundColor.a;
			} 
			else
			{
				color.a = m_MovePoint.GetAt(m_which).m_BackgroundColor.a - m_NormBackgroundColor.a;
			}
			if (m_NormBackgroundColor.b > m_MovePoint.GetAt(m_which).m_BackgroundColor.b)
			{
				color.b = m_NormBackgroundColor.b - m_MovePoint.GetAt(m_which).m_BackgroundColor.b;
			} 
			else
			{
				color.b = m_MovePoint.GetAt(m_which).m_BackgroundColor.b - m_NormBackgroundColor.b;
			}
			if (m_NormBackgroundColor.r > m_MovePoint.GetAt(m_which).m_BackgroundColor.r)
			{
				color.r = m_NormBackgroundColor.r - m_MovePoint.GetAt(m_which).m_BackgroundColor.r;
			} 
			else
			{
				color.r = m_MovePoint.GetAt(m_which).m_BackgroundColor.r - m_NormBackgroundColor.r;
			}
			if (m_NormBackgroundColor.g > m_MovePoint.GetAt(m_which).m_BackgroundColor.g)
			{
				color.g = m_NormBackgroundColor.g - m_MovePoint.GetAt(m_which).m_BackgroundColor.g;
			} 
			else
			{
				color.g = m_MovePoint.GetAt(m_which).m_BackgroundColor.g - m_NormBackgroundColor.g;
			}
		}
		return color;
	}
	void ChangeControl::ReState()
	{
		m_which = 0;
		m_Totale_timer = 0.0f;
	}
}