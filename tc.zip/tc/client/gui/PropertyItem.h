namespace Gui
{
#if 1
	/// enum info
	class PdeEnumInfo : public Core::PdeTypeInfo
	{
	public:
		struct EnumItem
		{
			Core::Identifier name;
			U32 id;
			S32 enum_id;

			bool operator == (const EnumItem & item) const { return name == item.name; }

			EnumItem(const Core::Identifier & name, U32 id, S32 enum_id) : name(name), id(id), enum_id(enum_id) {};
		};

	public:
		/// constructor
		PdeEnumInfo(const Core::Identifier & name);
		~PdeEnumInfo();

		/// get kind
		virtual Kind GetTypeKind() const { return kEnum; }

		/// to number
		//virtual double ToNumber(const PdeClassPtr & ptr) const;

		/// to string
		//virtual PdeString ConvertToString(const PdeClassPtr & ptr) const;

		/// create instance
		//virtual PdeClassPtr CreateInterface() const;

		/// parse
		//virtual PdeClassPtr Parse(const PdeString & str) const;

		/// is equal
		//virtual bool EqualsInternal(const PdeClassPtr & src, const PdeClassPtr & des) const;

	public:
		void AddItem(const Core::Identifier & name, U32 id, S32 enum_id);

		/// items
		Core::Array<EnumItem> & Items() { return m_Items; }

		/// items
		const Core::Array<EnumItem> & Items() const { return m_Items; }

		/// to name
		const Core::Identifier & ToName(U32 id) const;

		/// to id
		U32 ToId(const Core::Identifier & name, U32 defaultValue = -1, bool * error = NULL) const;

	private:
		Core::Array<EnumItem> m_Items;
	};
#endif
}

namespace Gui
{
	class PdePropertyItem : public ListItem
	{
		DECLARE_PDE_OBJECT(PdePropertyItem, ListItem)

	public:
		PdePropertyItem();
		~PdePropertyItem();

	public:
		enum EditStyle
		{
			kNone,
			kModal,
			kDropDown,
		};

		struct PropertyItem
		{
			Core::String Name;
			sharedc_ptr(void) Value;
			Core::String TypeName;
			
			PropertyItem(const Core::String & name, tempc_ptr(void) value, const Core::String & typeName)
				: Name(name)
				, Value(value)
				, TypeName(typeName)
			{
			}
			PropertyItem() {};
		};

	public:
		DECLARE_PDE_ATTRIBUTE_RW(Value,						tempc_ptr(void));
		DECLARE_PDE_ATTRIBUTE_RW(Group,						tempc_ptr(PdePropertyItem));
		DECLARE_PDE_ATTRIBUTE_RW(Readonly,					bool);
		DECLARE_PDE_ATTRIBUTE_RW(OwnDraw,					bool);
		DECLARE_PDE_ATTRIBUTE_RW(IsGroup,					bool);
		DECLARE_PDE_ATTRIBUTE_RW(Invalid,					bool);
		DECLARE_PDE_ATTRIBUTE_RW(PropertyType,				tempc_ptr(Core::PdeTypeInfo));
		DECLARE_PDE_ATTRIBUTE_R	(PropertiesSupported,		bool);
		DECLARE_PDE_ATTRIBUTE_R	(StandardValuesSupported,	bool);

	public:
		virtual void OnCreate();

	public:
		virtual EditStyle GetEditStyle();

		virtual bool UpdateProperties();

		virtual Core::Array<PdePropertyItem::PropertyItem> GetProperties();

		virtual bool SetProperty(sharedc_ptr(PdePropertyItem) item);

		virtual Core::Array<PdeEnumInfo::EnumItem> GetStandardValues();

		virtual void AddStandardValue(const Core::String & value, S32 id, S32 enum_id);
		
		Core::String GetItemString();

		void StringToValue(const Core::String & value);

		Core::String ValueToString(by_ptr(void) value);

		Core::PdeTypeInfo::Kind VariableType();

		bool IsNumeric();

		/// Property type
		static const Core::Identifier & PropertyItemType(by_ptr(Core::PdeTypeInfo) typeInfo);

	private:
		virtual bool ChangeItemProperty(by_ptr(PdePropertyItem) item);

	private:
		sharedc_ptr(void)					m_Value;
		Core::Array<PdeEnumInfo::EnumItem>	m_Values;

		bool								m_Invalid;
		bool								m_Readonly;
		bool								m_IsGroup;
		bool								m_OwnDraw;

		sharedc_ptr(PdePropertyItem)			m_Group;
		sharedc_ptr(Core::PdeTypeInfo)	m_PropertyType;
	};

	class PdePropertyItemQuaternion : public PdePropertyItem
	{
		DECLARE_PDE_OBJECT(PdePropertyItemQuaternion, PdePropertyItem)
	public:
		PdePropertyItemQuaternion();
		~PdePropertyItemQuaternion();
	
	public:
		virtual Core::Array<PropertyItem> GetProperties();

		virtual bool ChangeItemProperty(by_ptr(PdePropertyItem) item);
	};
#if 0
	//do not support array
	class PdePropertyItemArray : public PdePropertyItem
	{
		DECLARE_PDE_OBJECT(PdePropertyItemArray, PdePropertyItem)
	public:
		PdePropertyItemArray();
		~PdePropertyItemArray();

	public:
		OVERRIDE_PDE_ATTRIBUTE_R(PropertiesSupported,	bool);

	public:
		virtual Core::Array<PropertyItem> GetProperties();

		virtual bool ChangeItemProperty(by_ptr(PdePropertyItem) item);
	};
#endif
}