#include "pch.h"

using namespace Core;
using namespace Gui;
using namespace Client;


//---------------------------------------------------------------------------------------
// type info.
//---------------------------------------------------------------------------------------
DEFINE_PDE_TYPE_CLASS(Gui::SquadBlockSkin)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::ControlSkin);
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_PROPERTY_RW(LeaderImage);
	}
};

DEFINE_PDE_TYPE_CLASS(Gui::SquadBlock)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::Control);
		ADD_PDE_DEFAULT_CONSTRUCTOR();
		ADD_PDE_PROPERTY_R(IsLeader);
		ADD_PDE_PROPERTY_R(HostIsLeader);
		ADD_PDE_PROPERTY_R(IsMyself);
		ADD_PDE_PROPERTY_R(Name);
	}
};

DEFINE_PDE_TYPE_CLASS(Gui::SquadPanel)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::Control);
		ADD_PDE_DEFAULT_CONSTRUCTOR();
		ADD_PDE_PROPERTY_R(IsReady);
		ADD_PDE_PROPERTY_R(ContextualMenu);
		ADD_PDE_METHOD(Ready);
		ADD_PDE_METHOD(Rebuild);
		ADD_PDE_METHOD(Clear);
		ADD_PDE_METHOD(AddLevel);
	}
};

REGISTER_PDE_TYPE(Gui::SquadBlockSkin);
REGISTER_PDE_TYPE(Gui::SquadBlock);
REGISTER_PDE_TYPE(Gui::SquadPanel);

#define TIMER_MAX 10.f

namespace Gui
{
	SquadMemberAddress::SquadMemberAddress( const Client::ClientAddress& address )
	{
		server_id = address.server_id;
		channel_id = address.channel_id;
		room_id = address.room_id;
		server_name = address.server_name;
		channel_name = address.channel_name;
	}

	const SquadMemberAddress& SquadMemberAddress::operator=( const Client::ClientAddress& address )
	{
		server_id = address.server_id;
		channel_id = address.channel_id;
		room_id = address.room_id;
		server_name = address.server_name;
		channel_name = address.channel_name;
		return *this;
	}

	bool SquadMemberAddress::operator==( const Client::ClientAddress& address )
	{
		return (server_id == address.server_id 
			&&	channel_id == address.channel_id
			&&	room_id == address.room_id
			&&	server_name == address.server_name
			&&	channel_name == address.channel_name);
	}
}

namespace Gui
{
	SquadBlock::SquadBlock()
		: m_IsLeader(false)
		, m_IsMyself(false)
		, m_Level(-1)
		, m_Exp(0)
		, m_Status(-1)
		, m_Empty(true)
	{

	}

	SquadBlock::~SquadBlock()
	{

	}

	PDE_ATTRIBUTE_GETTER(SquadBlock, IsLeader, bool)
	{
		return m_IsLeader;
	}

	PDE_ATTRIBUTE_SETTER(SquadBlock, IsLeader, bool)
	{
		if(m_IsLeader!=value)
		{
			m_IsLeader = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(SquadBlock, HostIsLeader, bool)
	{
		if(gGame->lobby_connection)
		{
			tempc_ptr(SquadPanel) panel = gGame->lobby_connection->m_SquadPanel;
			if(panel)
			{
				return panel->GetHostIsLeader();
			}
		}
		return false;
	}

	PDE_ATTRIBUTE_GETTER(SquadBlock, IsMyself, bool)
	{
		return m_IsMyself;
	}

	PDE_ATTRIBUTE_SETTER(SquadBlock, IsMyself, bool)
	{
		if(m_IsMyself!=value)
		{
			m_IsMyself = value;
			if(m_ExpBar)
			{
				if(m_IsMyself)
					m_ExpBar->SetPlayerName(gLang->GetTextW(L"���Լ�"));
				else
					m_ExpBar->SetPlayerName(m_Name);
			}
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(SquadBlock, Name, const Core::String& )
	{
		return m_Name;
	}

	PDE_ATTRIBUTE_SETTER(SquadBlock, Name, const Core::String& )
	{
		if(m_Name!=value)
		{
			m_Name = value;
			if(m_ExpBar)
			{
				if(m_IsMyself)
					m_ExpBar->SetPlayerName(gLang->GetTextW(L"���Լ�"));
				else
					m_ExpBar->SetPlayerName(m_Name);
			}
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(SquadBlock, Level, int)
	{
		return m_Level;
	}

	PDE_ATTRIBUTE_SETTER(SquadBlock, Level, int)
	{
		if(m_Level!=value)
		{
			m_Level = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(SquadBlock, Status, int)
	{
		return m_Status;
	}

	PDE_ATTRIBUTE_SETTER(SquadBlock, Status, int)
	{
		if(m_Status!=value)
		{
			m_Status = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(SquadBlock, ClientAddress, const SquadMemberAddress&)
	{
		return m_ClientAddress;
	}

	PDE_ATTRIBUTE_SETTER(SquadBlock, ClientAddress, const Client::ClientAddress&)
	{
		if(!(m_ClientAddress==value))
		{
			m_ClientAddress = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(SquadBlock, Empty, bool)
	{
		return m_Empty;
	}

	PDE_ATTRIBUTE_SETTER(SquadBlock, Empty, bool)
	{
		if(m_Empty!=value)
		{
			m_Empty = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(SquadBlock, Exp, F32)
	{
		return m_Exp;
	}

	PDE_ATTRIBUTE_GETTER(SquadBlock, ExpBar, tempc_ptr(ExperienceBar))
	{
		return m_ExpBar;
	}

	void SquadBlock::OnCreate()
	{
		Super::OnCreate();
		m_ButtonFollow = ptr_new Button;
		m_ButtonFollow->SetStyle("Gui.SquadButtonFollow");
		m_ButtonFollow->ChangeParent(ptr_static_cast<Control>(this), NullPtr);
		m_ButtonFollow->EventClick.Subscribe(NewDelegate(&Self::OnButtonFollowClick, ptr_static_cast<Self>(this)));
		m_ButtonFollow->SetVisible(false);

		m_ButtonCall = ptr_new Button;
		m_ButtonCall->SetStyle("Gui.SquadButtonCall");
		m_ButtonCall->ChangeParent(ptr_static_cast<Control>(this), NullPtr);
		m_ButtonCall->EventClick.Subscribe(NewDelegate(&Self::OnButtonCallClick, ptr_static_cast<Self>(this)));
		m_ButtonCall->SetVisible(false);

		m_ExpBar = ptr_new ExperienceBar;
		m_ExpBar->SetBackgroundColor(ARGB(0,0,0,0));
		m_ExpBar->SetSize(Vector2(100, 40));
		m_ExpBar->SetMargin(Vector4(0,0,24,0));
		m_ExpBar->SetDock(Control::kDockFill);
		m_ExpBar->SetParent(ptr_static_cast<Control>(this));
		m_ExpBar->SetIcon(ptr_new Gui::ProportionIcon("skinD/skinD_bar02_BG.tga", "skinD/skinD_bar02_content.tga"
			, Core::Vector4(4,4,4,4), Core::Vector4(4,4,4,4)));
		m_ExpBar->SetMini(true);
	}

	void SquadBlock::OnDestroy()
	{
		Super::OnDestroy();
	}

	void SquadBlock::OnFrameUpdate( EventArgs & e )
	{
	}

	void SquadBlock::OnInputEvent( InputEventArgs & e )
	{
		if (!m_Empty && e.IsMouseEvent())
		{
			switch (e.Type)
			{
			case InputEventArgs::kMouseUp:
				{
					if(MC_RIGHT_BUTTON == e.Code)
					{
						if(gGame->lobby_connection)
						{
							tempc_ptr(SquadPanel) panel = gGame->lobby_connection->m_SquadPanel;
							if(panel)
							{
								tempc_ptr(Menu) menu = panel->GetContextualMenu();
								Vector2 menuPos =  ClientToGlobalScreen(ScreenToClient(e.CursorPosition));
								menu->SetLocation(menuPos);

								//reset menu content
								menu->RemoveAll();
								if(GetHostIsLeader())
								{
									if(m_IsMyself)
									{
										menu->AddItem(gLang->GetTextW(L"�˳�С��"));
									}
									else
									{
										menu->AddItem(gLang->GetTextW(L"�ٻ����ҷ���"));
										menu->AddItem(gLang->GetTextW(L"��������"));
										menu->AddItem(gLang->GetTextW(L"��Ȩ�ӳ�"));
										menu->AddItem(gLang->GetTextW(L"�����С��"));
									}
								}
								else
								{
									if(m_IsMyself)
									{
										menu->AddItem(gLang->GetTextW(L"�˳�С��"));
									}
									else
									{
										menu->AddItem(gLang->GetTextW(L"��������"));
									}
								}
								menu->SetTag(ptr_static_cast<void>(this));
								menu->Open();
								e.Handled = true;
							}
						}
					}
				}
				break;
			}
		}
		if(!e.Handled)
			Super::OnInputEvent(e);
	}

	void SquadBlock::OnPaint( PaintEventArgs & e )
	{
		if(!m_Empty)
		{
			Super::OnPaint(e);
			Core::Rectangle leaderRect = Core::Rectangle::RightTop(GetSize().x, 0, 24, 25);
 			if(m_IsLeader)
			{
				tempc_ptr(SquadBlockSkin) skin = ptr_dynamic_cast<SquadBlockSkin>(GetSkin());
				if(skin)
				{
					Skin::DrawImage(e.render, skin->GetLeaderImage(), leaderRect);
				}
				else
				{
					e.render->DrawString(GetFont(), ARGB(255,255,255), ARGB(0,0,0,0), leaderRect, "leader"
					, Unit::kAlignLeftMiddle);
				}
			}
		}
	}

	void SquadBlock::OnButtonFollowClick( by_ptr(void) sender, InputEventArgs &e )
	{
		tempc_ptr(StateLobby) lobby = ptr_dynamic_cast<StateLobby>(gGame->machine.CurrentState());
		if(lobby)
		{
			lobby->AutoChangeRoom(m_ClientAddress.server_id, m_ClientAddress.channel_id, m_ClientAddress.room_id);
		}
		else
		{
			gGame->guiSys->ShowMessage(gLang->GetTextW(L"�����ڲ��ڴ���״̬���޷�����TA�ķ���"));
		}
	}

	void SquadBlock::OnButtonCallClick( by_ptr(void) sender, InputEventArgs &e )
	{
		tempc_ptr(GameState) state = gGame->machine.CurrentState();
		if(state)
		{
			state->TeamCall(GetName());
		}	
	}

	void SquadBlock::Show()
	{
		SetEmpty(false);
	}

	void SquadBlock::Hide()
	{
		m_IsLeader = false;
		m_IsMyself = false;
		//m_Name = "";	//comment out for debug
		m_Level  = -1;
		SetBaseExp(0);
		m_Status = -1;
		m_ClientAddress.Clear();
		SetButtonVisibility(false, false);
		SetEmpty(true);
		//Move it outside the panel
		SetLocation(Vector2(0, 60));
	}

	void SquadBlock::MoveForward()
	{
		SetLocation(GetLocation()-GetParent()->GetSize()/5);
	}

	void SquadBlock::MoveBackward()
	{
		SetLocation(GetLocation()+GetParent()->GetSize()/5);
	}

	tempc_ptr(SquadBlock) SquadBlock::NextBlock()
	{
		return ptr_dynamic_cast<SquadBlock>(GetNext());
	}

	void SquadBlock::SetButtonVisibility( bool bFollow, bool bCall )
	{
		m_ButtonFollow->SetVisible(bFollow);
		m_ButtonCall->SetVisible(bCall);
	}

	void SquadBlock::SetBaseExp(F32 baseExp)
	{
		m_Exp = baseExp;
		if(m_ExpBar)
		{
			m_ExpBar->SetBaseValue(baseExp);
			m_ExpBar->Ready();
		}
	}

	void SquadBlock::SetNewExp(F32 newExp)
	{
		m_Exp = newExp;
		if(m_ExpBar)
		{
			m_ExpBar->SetNewValue(newExp);
			m_ExpBar->Start();
		}
	}
}

namespace Gui
{
	SquadPanel::SquadPanel()
		: m_PanelState(kSquadEmpty)
		, m_InviterUid(-1)
		, m_Timer(0.f)
		, m_Ready(false)
	{

	}

	SquadPanel::~SquadPanel()
	{

	}

	PDE_ATTRIBUTE_GETTER(SquadPanel, HostIsLeader, bool)
	{
		return GetFirstBlock()->GetIsLeader();
	}

	PDE_ATTRIBUTE_GETTER(SquadPanel, HostAddress, const SquadMemberAddress&)
	{
		return GetFirstBlock()->GetClientAddress();
	}

	PDE_ATTRIBUTE_GETTER(SquadPanel, IsReady, bool)
	{
		return m_Ready;
	}

	void SquadPanel::OnCreate()
	{
		Super::OnCreate();
		SetFontSize(18);
		m_RootNode = ptr_new Control;
		m_RootNode->SetParent(ptr_static_cast<Control>(this));
		m_RootNode->SetDock(Control::kDockFill);
		m_RootNode->SetBackgroundColor(ARGB(0,0,0,0));
		for(int i=0; i<5; i++)
		{
			sharedc_ptr(SquadBlock) tempBlock = ptr_new SquadBlock;
			tempBlock->SetParent(m_RootNode);
			tempBlock->SetStyle("Gui.SquadBlock");
			tempBlock->SetSize(Vector2((GetSize().x-37)/5, GetSize().y));
			tempBlock->SetEmpty(true);
			tempBlock->SetIsMyself(false);
			if(i==0)
			{
				tempBlock->SetIsMyself(true);
				tempBlock->SetLocation(Vector2(37,0));
				tempBlock->SetEmpty(false);
			}
		}
		m_ButtonConfirm = ptr_new Button;
		m_ButtonConfirm->SetStyle("Gui.Button");
		m_ButtonConfirm->SetParent(ptr_static_cast<Control>(this));
		m_ButtonConfirm->SetSize(Vector2(80, 30));
		m_ButtonConfirm->SetLocation(Vector2(m_Size.x-300+20, 5));
		m_ButtonConfirm->SetText(gLang->GetTextW(L"ͬ��"));
		m_ButtonConfirm->SetVisible(false);
		m_ButtonConfirm->EventClick.Subscribe(NewDelegate(&SquadPanel::OnButtonConfirm,ptr_static_cast<SquadPanel>(this)));

		m_ButtonReject = ptr_new Button;
		m_ButtonReject->SetStyle("Gui.Button");
		m_ButtonReject->SetParent(ptr_static_cast<Control>(this));
		m_ButtonReject->SetSize(Vector2(80, 30));
		m_ButtonReject->SetLocation(Vector2(m_Size.x-300+140, 5));
		m_ButtonReject->SetText(gLang->GetTextW(L"�ܾ�"));
		m_ButtonReject->SetVisible(false);
		m_ButtonReject->EventClick.Subscribe(NewDelegate(&SquadPanel::OnButtonReject,ptr_static_cast<SquadPanel>(this)));

		m_ContextualMenu = ptr_new Menu;
		m_ContextualMenu->SetStyle("Gui.Menu");

		m_ProportionIcon = ptr_new ProportionIcon("skinD/skinD_bar01_BG.tga", "skinD/skinD_bar01_content.tga", Vector4(5,6,5,3), Vector4(5,6,5,3));

		ChangeState(kSquadEmpty);
	}

	void SquadPanel::OnDestroy()
	{
		while(m_RootNode->GetFirstChild())
		{
			m_RootNode->GetFirstChild()->SetParent(NullPtr);
		}
		m_RootNode->SetParent(NullPtr);
		m_RootNode = NullPtr;
		m_ButtonConfirm->SetParent(NullPtr);
		m_ButtonConfirm = NullPtr;
		m_ButtonReject->SetParent(NullPtr);
		m_ButtonReject = NullPtr;
		Super::OnDestroy();
	}

	void SquadPanel::OnLayout( EventArgs & e )
	{
		Super::OnLayout(e);
		tempc_ptr(SquadBlock) curBlock = GetFirstBlock();
		int i=0;
		while(curBlock && !curBlock->GetEmpty())
		{
			F32 blockLength = (GetSize().x-37)/5;
			F32 headerLength = 37;
			if(curBlock->GetIsMyself())
			{
				curBlock->SetSize(Vector2(blockLength, GetSize().y));
				curBlock->SetLocation(Vector2(headerLength,0));				
			}
			else
			{
				curBlock->SetSize(Vector2(blockLength, GetSize().y));
				curBlock->SetLocation(Vector2(headerLength+blockLength*i,0));
			}
			curBlock=curBlock->NextBlock();
			i++;
		}
		m_ButtonConfirm->SetLocation(Vector2(m_Size.x-300+20, 5));
		m_ButtonReject->SetLocation(Vector2(m_Size.x-300+140, 5));
	}

	void SquadPanel::OnFrameUpdate( EventArgs & e )
	{
		//Update timer bar
		if(m_Timer>Core::EPSILON)
		{
			m_Timer-=Task::GetFrameTime();
			m_ProportionIcon->SetProportion((TIMER_MAX-m_Timer)/TIMER_MAX);
			Invalid();
			if(m_Timer<Core::EPSILON)
			{
				if(m_PanelState == kInvitedQuery)
				{
					ChangeState(kSquadEmpty);
				}
				else if(m_PanelState == kCalledQuery)
				{
					ChangeState(kSquadNormal);
				}
			}
		}

		//Update squad member buttons
		if(m_PanelState == kSquadNormal)
		{
			if(GetHostIsLeader())
			{
				if(GetHostAddress().room_id)
				{
					tempc_ptr(SquadBlock) curBlock = GetFirstBlock();
					curBlock->SetButtonVisibility(false, false);
					curBlock = curBlock->NextBlock();
					while(curBlock && !curBlock->GetEmpty())
					{
						curBlock->SetButtonVisibility(false, true);
						curBlock=curBlock->NextBlock();
					}
				}
				else
				{
					tempc_ptr(SquadBlock) curBlock = GetFirstBlock();
					while(curBlock && !curBlock->GetEmpty())
					{
						curBlock->SetButtonVisibility(false, false);
						curBlock=curBlock->NextBlock();
					}
				}
			}
			else
			{
				tempc_ptr(SquadBlock) curBlock = GetFirstBlock();
				curBlock=curBlock->NextBlock();
				while(curBlock && !curBlock->GetEmpty())
				{
					if(curBlock->GetIsLeader() && curBlock->GetClientAddress().room_id)
					{
						curBlock->SetButtonVisibility(true, false);
					}
					else
					{
						curBlock->SetButtonVisibility(false, false);
					}
					curBlock=curBlock->NextBlock();
				}	
			}
		}
		else
		{
			tempc_ptr(SquadBlock) curBlock = GetFirstBlock();
			while(curBlock && !curBlock->GetEmpty())
			{
				curBlock->SetButtonVisibility(false, false);
				curBlock=curBlock->NextBlock();
			}
		}
	}

	void SquadPanel::OnInputEvent( InputEventArgs & e )
	{

	}

	void SquadPanel::OnPaint( PaintEventArgs & e )
	{
		if(m_PanelState == kSquadEmpty)
		{
			e.render->DrawString(GetFont(), ARGB(255,255,255), ARGB(0,0,0,0), GetBackgroundRect()
				, gLang->GetTextW(L"����Ժ���ԺͶ�Աһ�������뿪��Ϸ����"), Unit::kAlignCenterMiddle);
		}
		else if (m_PanelState == kInvitedQuery)
		{
			Core::Rectangle msgRect = GetBackgroundRect();
			msgRect.Shrink(Vector4(0,0,300, 20));
			Core::Rectangle barRect = msgRect;
			barRect.Move(Vector2(0, 20));
			barRect.Shrink(Vector4(100, 4, 100, 4));
			e.render->DrawString(GetFont(), ARGB(255,255,255), ARGB(0,0,0,0), msgRect
				, Core::String::Format(gLang->GetTextW(L"%s���������TA��С��"),m_InviterName), Unit::kAlignCenterMiddle);
			m_ProportionIcon->Draw(e.render, barRect, ARGB(255,255,255,255));
		}
		else if (m_PanelState == kCalledQuery)
		{
			Core::Rectangle msgRect = GetBackgroundRect();
			msgRect.Shrink(Vector4(0,0,300, 20));
			Core::Rectangle barRect = msgRect;
			barRect.Move(Vector2(0, 20));
			barRect.Shrink(Vector4(100, 4, 100, 4));
			e.render->DrawString(GetFont(), ARGB(255,255,255), ARGB(0,0,0,0), msgRect
				, Core::String::Format(gLang->GetTextW(L"��Ķӳ�%s�ٻ������TA�ķ���"),m_CallerName), Unit::kAlignCenterMiddle);
			m_ProportionIcon->Draw(e.render, barRect, ARGB(255,255,255,255));
		}
	}

	void SquadPanel::ChangeState( PanelStates newState )
	{
		m_PanelState = newState;
		if(m_PanelState == kInvitedQuery || m_PanelState==kCalledQuery)
		{
			m_RootNode->SetVisible(false);
			m_ButtonConfirm->SetVisible(true);
			m_ButtonReject->SetVisible(true);
		}
		else if(m_PanelState == kSquadEmpty)
		{
			ClearBlocks();
			m_RootNode->SetVisible(false);
			m_ButtonConfirm->SetVisible(false);
			m_ButtonReject->SetVisible(false);			
		}
		else if(m_PanelState == kSquadNormal)
		{
			RebuildSquadList();
			m_RootNode->SetVisible(true);
			m_ButtonConfirm->SetVisible(false);
			m_ButtonReject->SetVisible(false);
		}
	}

	void SquadPanel::RebuildSquadList()
	{
		if(gGame->lobby_connection)
		{
			ClearBlocks();
			const Core::Array<Client::TeamMember>& teamRaw = gGame->lobby_connection->team_members;
			for(int i=0; i<teamRaw.GetCount(); i++)
			{
				NewMember(teamRaw[i]);
			}
		}
	}

	void SquadPanel::UpdateSquadList()
	{

	}

	void SquadPanel::UpdateMember( const Client::TeamMember& member )
	{
		tempc_ptr(SquadBlock) curBlock = FindMember(member.name);
		if(curBlock)
		{
			curBlock->SetLevel(member.level);
			curBlock->SetNewExp(member.exp);
			curBlock->SetStatus(member.state);
			curBlock->SetClientAddress(member.address);
		}
	}

	void SquadPanel::NewMember( const Client::TeamMember& member )
	{
		if(member.name == gGame->lobby_connection->character_name)
		{
			tempc_ptr(SquadBlock) selfBlock = GetFirstBlock();
			PDE_ASSERT(selfBlock->GetIsMyself(), "SquadPanel: First block is not self block, things go wrong");
			selfBlock->SetName(member.name);
			selfBlock->SetLevel(member.level);
			selfBlock->SetBaseExp(member.exp);
			selfBlock->SetStatus(member.state);
			selfBlock->SetClientAddress(member.address);
			selfBlock->SetIsLeader(member.leader);
			selfBlock->SetIsMyself(true);
			selfBlock->SetEmpty(false);
		}
		else
		{
			tempc_ptr(SquadBlock) newBlock = GetFirstEmptyBlock();
			if(newBlock)
			{
				newBlock->SetName(member.name);
				newBlock->SetLevel(member.level);
				newBlock->SetBaseExp(member.exp);
				newBlock->SetStatus(member.state);
				newBlock->SetClientAddress(member.address);
				newBlock->SetIsLeader(member.leader);
				newBlock->SetIsMyself(false);
				newBlock->SetEmpty(false);
				DirtyLayout();
			}
		}
	}

	void SquadPanel::RemoveMember( const Core::String& name )
	{
		sharedc_ptr(SquadBlock) curBlock = FindMember(name);
		if(curBlock)
		{
			curBlock->Balloon2(Core::String::Format(gLang->GetTextW(L"%s�뿪��С��"),name));
			curBlock->SetParent(NullPtr);
			curBlock->SetParent(m_RootNode);
			curBlock->Hide();
			DirtyLayout();
		}		
	}

	void SquadPanel::OnLeaderChanged( const Core::String& name )
	{
		tempc_ptr(SquadBlock) curBlock = GetFirstBlock();
		while(curBlock && !curBlock->GetEmpty())
		{
			if(curBlock->GetName()==name)
			{
				curBlock->SetIsLeader(true);
				if(curBlock->GetIsMyself())
					curBlock->Balloon2(gLang->GetTextW(L"������Ȩ��Ϊ�ӳ�"));
				else
					curBlock->Balloon2(Core::String::Format(gLang->GetTextW(L"%s����Ȩ��Ϊ�ӳ�"),name));
			}
			else
			{
				curBlock->SetIsLeader(false);
			}
			curBlock=curBlock->NextBlock();
		}	
	}

	int SquadPanel::GetMemberCount()
	{
		tempc_ptr(SquadBlock) curBlock = GetFirstBlock();
		int nCount = 0;
		while(curBlock && !curBlock->GetEmpty())
		{
			nCount++;
			curBlock=curBlock->NextBlock();
		}
		return nCount;
	}

	tempc_ptr(SquadBlock) SquadPanel::GetFirstEmptyBlock()
	{
		tempc_ptr(SquadBlock) curBlock = GetFirstBlock();
		while(curBlock && !curBlock->GetEmpty())
		{
			curBlock=curBlock->NextBlock();
		}
		if(curBlock && curBlock->GetEmpty())
			return curBlock;
		else
			return NullPtr;
	}

	tempc_ptr(SquadBlock) SquadPanel::FindMember(const Core::String& name)
	{
		tempc_ptr(SquadBlock) curBlock = GetFirstBlock();
		bool bFound = false;
		while(curBlock && !curBlock->GetEmpty())
		{
			if(curBlock->GetName()==name)
			{
				bFound=true;
				break;
			}
			curBlock=curBlock->NextBlock();
		}
		if(bFound)
			return curBlock;
		else
			return NullPtr;
	}

	void SquadPanel::OnTeamInvite( const Core::String& name, int uid )
	{
		m_InviterName = name;
		m_InviterUid = uid;
		m_Timer = TIMER_MAX;
		ChangeState(kInvitedQuery);
		if(gGame&&gGame->guiSys)
		{
			gGame->guiSys->PlayAudio(GuiSystem::kUIA_TEAM_INVITED);
		}
	}

	void SquadPanel::OnTeamLeave()
	{
		ChangeState(kSquadEmpty);
	}

	void SquadPanel::OnLeaderCall(uint server_id, uint channel_id, ushort room_id, const Core::String& invite_name)
	{
		m_CallerName = invite_name;

		m_CallerServer = server_id;
		m_CallerChannel = channel_id;
		m_CallerRoom = room_id;
		m_Timer = TIMER_MAX;
		ChangeState(kCalledQuery);
	}

	void SquadPanel::OnLeaderCancelCall(uint server_id, uint channel_id, ushort room_id)
	{
		if(m_CallerServer==server_id && m_CallerChannel==channel_id && m_CallerRoom==room_id)
		{
			m_Timer = 0.0f;
			ChangeState(kSquadNormal);
		}
	}

	void SquadPanel::OnResponseTeamInvite( const Core::String& name, int result )
	{
		if (result == kErrorProxyTeamInviteAlreadyInTeam)
		{
			tempc_ptr(SquadBlock) tempBlock = FindMember(name);
			if(tempBlock)
			{
				tempBlock->Balloon2(Core::String::Format(gLang->GetTextW(L"%s�Ѿ������С����"), name));
			}
		}
	}

	void SquadPanel::OnResponseTeamJoin( const Core::String& name, int result )
	{
		if(result==kErrorNone)
		{
			ChangeState(kSquadNormal);
		}
		else
		{
			ChangeState(kSquadEmpty);
		}
	}

	tempc_ptr(SquadBlock) SquadPanel::GetFirstBlock()
	{
		return ptr_dynamic_cast<SquadBlock>(m_RootNode->GetFirstChild());
	}

	void SquadPanel::OnButtonConfirm(by_ptr(void) sender, InputEventArgs &e)
	{
		if(m_PanelState == kInvitedQuery)
		{
			tempc_ptr(GameState) state = gGame->machine.CurrentState();
			if(state)
			{
				m_Timer = 0.f;
				state->TeamJoin(m_InviterName, m_InviterUid);
			}
		}
		else if(m_PanelState == kCalledQuery)
		{
			tempc_ptr(StateLobby) lobby = ptr_dynamic_cast<StateLobby>(gGame->machine.CurrentState());
			if(lobby)
			{
				m_Timer = 0.f;
				lobby->AutoChangeRoom(m_CallerServer, m_CallerChannel, m_CallerRoom);
				ChangeState(kSquadNormal);
			}
			else
			{
				m_Timer = 0.f;
				gGame->guiSys->ShowMessage(gLang->GetTextW(L"�����ڲ��ڴ���״̬���޷�����TA�ķ���"));
				ChangeState(kSquadNormal);
			}
		}
	}

	void SquadPanel::OnButtonReject(by_ptr(void) sender, InputEventArgs &e)
	{
		if(m_PanelState == kInvitedQuery)
		{
			tempc_ptr(GameState) state = gGame->machine.CurrentState();
			if(state)
			{
				state->TeamRefuse(m_InviterName, m_InviterUid);
			}
			m_Timer = 0.f;
			ChangeState(kSquadEmpty);
		}
		else if(m_PanelState == kCalledQuery)
		{
			tempc_ptr(GameState) state = gGame->machine.CurrentState();
			if(state)
			{
				state->TeamRefusePreserve(m_CallerName, m_CallerServer, m_CallerChannel, m_CallerRoom);
			}
			m_Timer = 0.f;
			ChangeState(kSquadNormal);
		}
	}

	void SquadPanel::ClearBlocks()
	{
		tempc_ptr(SquadBlock) curBlock = GetFirstBlock();
		while(curBlock && !curBlock->GetEmpty())
		{
			if(curBlock->GetIsMyself())
			{
				curBlock->SetName("");
				curBlock->SetLevel(-1);
				curBlock->SetBaseExp(0);
				curBlock->SetStatus(-1);
				curBlock->SetClientAddress(ClientAddress(0,0,0));
				curBlock->SetIsLeader(false);
			}
			else
			{
				curBlock->Hide();
			}
			curBlock=curBlock->NextBlock();
		}
	}

	void SquadPanel::Rebuild()
	{
		if(gGame->lobby_connection)
		{
			if(gGame->lobby_connection->team_members.GetCount()>1)
			{
				ChangeState(kSquadNormal);
			}
			else
			{
				ChangeState(kSquadEmpty);
			}
		}
	}

	void SquadPanel::Clear()
	{
		ClearBlocks();
		tempc_ptr(SquadBlock) curBlock = GetFirstBlock();
		while(curBlock)
		{
			if(curBlock->GetExpBar())
				curBlock->GetExpBar()->ClearLevels();
			curBlock=curBlock->NextBlock();
		}
		m_Ready = false;
		ChangeState(kSquadEmpty);
	}

	void SquadPanel::AddLevel( F32 fValue, const Core::String& rank, tempc_ptr(Gui::Icon) rankIcon )
	{
		tempc_ptr(SquadBlock) curBlock = GetFirstBlock();
		while(curBlock)
		{
			if(curBlock->GetExpBar())
			{
				curBlock->GetExpBar()->AddLevel(fValue, rank, rankIcon);
			}
			curBlock=curBlock->NextBlock();
		}	
	}

	void SquadPanel::Ready()
	{
		tempc_ptr(SquadBlock) curBlock = GetFirstBlock();
		while(curBlock)
		{
			if(curBlock->GetExpBar())
			{
				curBlock->GetExpBar()->Ready();
			}
			curBlock=curBlock->NextBlock();
		}	
		m_Ready = true;
	}
}