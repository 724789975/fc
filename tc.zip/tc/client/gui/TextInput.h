namespace Gui
{

	class TextInput
	{
	public:
		struct InputHistory
		{
			Core::String	OldText;
			Core::String	NewText;
			size_t		Position;
			size_t		OldSelectionStart;
			size_t		OldSelectionEnd;

			InputHistory() : Position(-1), OldSelectionStart(0), OldSelectionEnd(0) {}
		};

	public:
		// constructor
		TextInput();

		// destructor
		~TextInput();

	public:
		DECLARE_PDE_ATTRIBUTE_RW(TextBuffer,		Core::String *);
		DECLARE_PDE_ATTRIBUTE_RW(Multiline,			bool);
		DECLARE_PDE_ATTRIBUTE_R (Selecting,			bool);
		DECLARE_PDE_ATTRIBUTE_RW(AcceptTab,			bool);
		DECLARE_PDE_ATTRIBUTE_RW(AcceptReturn,		bool);

	public:
		/// on key event
		virtual bool OnKeyEvent(Client::InputEventArgs & input, bool readonly, tempc_ptr(Client::Font) font = NullPtr);

		/// on mouse event
		virtual bool OnMouseEvent(Client::InputEventArgs & input, const Core::Vector2 & pos, tempc_ptr(Client::Font) font);

		/// on text changed
		virtual void OnTextChanged(Core::EventArgs & e);

		/// on cursor move
		virtual void OnCursorMove(Core::EventArgs & e);

		/// on new history
		virtual void OnHistoryReset(InputHistory & e);

		/// delete virtual enter for textArea
		virtual void DeleteVirtualEnter();

		/// add virtual enter for textArea
		virtual void AddVirtualEnter();

	public:    
        /// Inserts the first nCount characters of the string pStr at specified index.  If count == -1, the entire string is inserted. If index == -1, insert to the end.
        size_t InsertString(size_t index, const CHAR* str, size_t count);

        /// Remove string
        size_t RemoveString(size_t startIndex, size_t endIndex);

		/// add string to cursor position
		int AddString(const CHAR * str, size_t count);

        /// Set cursor position
        void SetCursorPosition(size_t position, bool select = false);

		/// Get cursor postition.
		size_t GetCursorPosition();

		/// move cursor
		void MoveCursor(int line, int character, bool select = false);

        /// Set selection
        void SetSelection(size_t start, size_t end);

		/// Get selection start
		size_t GetSelectionStart();

		/// Get selection end
		size_t GetSelectionEnd();

        /// Has selection
        bool HasSelection();

		/// Select word
		void SelectWord();

		/// Select all
		void SelectAll();

        /// copy to clipboard
        void CopyText();

        /// paste from clipboard
        void PasteText();

		/// draw text
		void DrawInputText(tempc_ptr(Client::UIRender) render, const Core::Vector2 & location, const Core::Rectangle & clip, Core::XRGB textColor, Core::XRGB selectionTextColor, Core::XRGB selectionBgColor, bool drawCursor, bool drawSelection, tempc_ptr(Client::Font) font, bool drawShadow = false, bool drawPassword = false);

		/// convert from location to index
		bool PositionToIndex(tempc_ptr(Client::Font) font, const Core::Vector2 & position, size_t & index);

		/// convert from index to location
		bool IndexToPosition(tempc_ptr(Client::Font) font, size_t index, Core::Vector2 & position);

		/// do history
		void DoHistory(const InputHistory & history, bool undo);

		/// indent selection
		bool Indent(size_t start, size_t end, bool unindent);

		/// new line
		void NewLine();

		/// clear
		void Clear();

	protected:
        /// Inserts the char at specified index. If index == -1, insert to the end.
        size_t InsertChar(size_t index, ushort character);

        /// Removes the char at specified index. If index == -1, remove the last char.
        size_t RemoveChar(size_t index);

		/// Reset history
		void ResetHistory();

		/// set old history text
		void SetHistoryTextOld(size_t start, size_t end);
		
		/// set old history text
		void SetHistoryTextNew(size_t start, size_t end);

	private:
		Core::String *	m_TextBuffer;
        size_t		m_CursorPosition;
        size_t		m_SelectionStart, m_SelectionEnd;
		bool		m_Multiline		: 1;
		bool		m_Selecting		: 1;
		bool		m_AcceptTab		: 1;
		bool		m_AcceptReturn	: 1;

		// history
		InputHistory m_InputHistory;
	};
}