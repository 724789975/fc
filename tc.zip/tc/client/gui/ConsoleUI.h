namespace Gui
{
	class ConsoleUI : public Window, public TextInput
	{
		enum Constants
		{
			HISTORY_COUNT		= 16,
		};


	public:
		OVERRIDE_PDE_ATTRIBUTE_R(MinimumSize,	Core::Vector2) { return Core::Vector2(0, 0); }
		OVERRIDE_PDE_ATTRIBUTE_R(DefaultSize,	Core::Vector2) { return Core::Vector2(16, 16); }

	public:
		// constructor.
		ConsoleUI();

		// destructor.
		~ConsoleUI();

		// on create
		virtual void OnCreate();

		// process input
		virtual void OnInputEvent(Client::InputEventArgs & e);

		/// Draw console output.
		virtual void OnPaint(PaintEventArgs & e);

		// frame update
		virtual void OnFrameUpdate(Core::EventArgs & e);

		/// on cursor move
		virtual void OnCursorMove(Core::EventArgs & e);

	private:
		// add history
		void AddHistory(const char* cmd);

		// get history
		const char * GetHistoryCommand(bool prev);

		// get input rect
		Core::Rectangle GetInputRect();

	public:
		// clear
		void Clear();

	private:
		// command buffer
		Core::String	m_CmdHistorys[HISTORY_COUNT];
		U32				m_FirstCmd;
		U32				m_HistoryCmdID;
		
		bool			m_CursorVisible;
		float			m_CursorTime;
		float			m_ScrollX;

		Core::PdeDirtyFlag	m_OutputDirtyFlag;

	};


}