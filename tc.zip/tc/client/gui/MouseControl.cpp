#include "pch.h"

using namespace Core;
using namespace Client;
using namespace Gui;


DEFINE_PDE_TYPE_CLASS(Gui::MouseControl)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::Control);
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_PROPERTY_W(MouseType);
	}
};

REGISTER_PDE_TYPE(Gui::MouseControl);

namespace Gui
{
	MouseControl::MouseControl()
				: m_MouseType(0)
	{
	}

	MouseControl::~MouseControl()
	{
	}

	PDE_ATTRIBUTE_SETTER(MouseControl, MouseType, int)
	{
		if (m_MouseType != value)
		{
			m_MouseType = value;
		}
	}

	void MouseControl::OnInputEvent( InputEventArgs & e )
	{

		if(e.IsMouseEvent())
		{
			switch(e.Type)
			{
			case InputEventArgs::kMouseDown:
			case InputEventArgs::kMouseUp:
			case InputEventArgs::kMouseMove:
			case InputEventArgs::kMouseEnter:
				{
					if (m_MouseType == 0)
					{
						SetCursorShape(Screen::KCursorShoot);
					} 
					else if (m_MouseType == 1)
					{
						SetCursorShape(Screen::KCursorTalk);
					}
				}
				break;
			default:
				break;
			}

			//Mouse event should not penetrate the panel directly under guisystem
			//Or the avatar underneath would be picked through a panel
			if(ptr_dynamic_cast<GuiSystem>(m_Parent))
			{
				e.Handled = true;
			}
		}

		if (!e.Handled)
			Control::OnInputEvent(e);

	}
}