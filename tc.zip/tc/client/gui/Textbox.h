namespace Gui
{
	class TextboxSkin : public ControlSkin
	{
	public:
		TextboxSkin()
			: m_TextColor(Core::ARGB(255, 255, 255, 255))
		{}

	public:
		INLINE_PDE_ATTRIBUTE_RW(ActiveImage,	tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(DisabledImage,	tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(TextColor,		Core::ARGB);

	private:
		sharedc_ptr(Image) m_ActiveImage;
		sharedc_ptr(Image) m_DisabledImage;
		Core::ARGB m_TextColor;
	};
}

namespace Gui
{
	class Textbox: public Control, public TextInput
	{
	public:
		Textbox();
		~Textbox();

	public:
		DECLARE_PDE_OBJECT(Textbox, Control);
		DECLARE_PDE_EVENT(EventValueEnter, Core::EventArgs);
		DECLARE_PDE_EVENT(EventValueNoNumber, Core::EventArgs);
		DECLARE_PDE_EVENT(EventTextChanged, Core::EventArgs);
		DECLARE_PDE_EVENT(EventLengthExceed, Core::EventArgs);

	public:
		DECLARE_PDE_ATTRIBUTE_RW(Readonly,			bool);
		DECLARE_PDE_ATTRIBUTE_RW(InputNumberOnly,	bool);
		DECLARE_PDE_ATTRIBUTE_RW(InputNumberCharacterOnly,	bool);
		DECLARE_PDE_ATTRIBUTE_RW(MaxLength,			U32);
		DECLARE_PDE_ATTRIBUTE_RW(TextAutoSize,			bool);
		DECLARE_PDE_ATTRIBUTE_RW(TextAutoSizeMaxWidth,	F32);
		DECLARE_PDE_ATTRIBUTE_RW(SelectionColor,		Core::ARGB);
		DECLARE_PDE_ATTRIBUTE_RW(SelectionBgColor,			Core::ARGB);
		DECLARE_PDE_ATTRIBUTE_RW(TextPassword,      bool);
		DECLARE_PDE_ATTRIBUTE_RW(TBSkin,			tempc_ptr(Gui::TextboxSkin));
		DECLARE_PDE_ATTRIBUTE_RW(TextPadding,		Core::Vector4);
		OVERRIDE_PDE_ATTRIBUTE_W(Text,				const Core::String &);
		OVERRIDE_PDE_ATTRIBUTE_W(TabFocus,			Core::Bool);

	public:
		/// on frame update
		virtual void OnFrameUpdate(Core::EventArgs & e);

		/// on paint
		//virtual void OnPaintClient(EdtUIPaintEventArgs & e);
		virtual void OnPaint(PaintEventArgs & e);

		/// on input event
		virtual void OnInputEvent(Client::InputEventArgs &e);

		/// on leave
		virtual void OnLeave(Core::EventArgs & e);

		/// on text changed
		virtual void OnTextChanged(Core::EventArgs & e);

		/// on cursor move
		virtual void OnCursorMove(Core::EventArgs & e);

		/// on value enter
		virtual void OnValueEnter(Core::EventArgs & e);

		/// on value no number
		virtual void OnValueNoNumber(Core::EventArgs & e);

		/// on layout
		virtual void OnLayout(Core::EventArgs & e);

		/// on focus changed
		virtual void OnFocusChanged(EventArgs & e);

	public:
		/// text autosize
 		virtual void OnTextAutoSize();

		/// on new history
 		virtual void OnHistoryReset(InputHistory & e);

	private:

		bool			m_Readonly;
		bool			m_BorderVisible;
		bool			m_InputNumberOnly;
		bool			m_InputNumberCharacterOnly;

		F64				m_CursorTime;
		F32				m_ScrollX;
		U32				m_MaxLength;

		bool			m_CursorVisible;

		bool			m_TextAutoSize;
		F32				m_TextAutoSizeMaxWidth;

		InputHistory	m_InputHistory;
		bool			m_UndoHistory;

		Core::ARGB		m_SelectionColor;
		Core::ARGB		m_SelectionBgColor;

		Core::Vector4	m_TextPadding;

		bool            m_Password;
		Core::String    m_PassBuffer;
		tempc_ptr(Gui::TextboxSkin)		m_TBSkin;
	};
}