#include "pch.h"

using namespace Core;
using namespace Client;
using namespace Gui;

//--------------------------------------------------------------------------------------
// type info
//--------------------------------------------------------------------------------------
DEFINE_PDE_TYPE_CLASS(Gui::RadioButtonSkin)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::ControlSkin);
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_PROPERTY_RW(OnImage);
		ADD_PDE_PROPERTY_RW(OffImage);
		ADD_PDE_PROPERTY_RW(OnHoverImage);
		ADD_PDE_PROPERTY_RW(OffHoverImage);
		ADD_PDE_PROPERTY_RW(OnDisabledImage);
		ADD_PDE_PROPERTY_RW(OffDisabledImage);
	}
};

DEFINE_PDE_TYPE_CLASS(RadioButton)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Control);
		ADD_PDE_DEFAULT_CONSTRUCTOR();
		ADD_PDE_PROPERTY_RW(ID);
		ADD_PDE_PROPERTY_RW(CheckPosition);
	}
};

DEFINE_PDE_TYPE_CLASS(RadioGroup)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(FlowLayout);
		ADD_PDE_DEFAULT_CONSTRUCTOR();
		ADD_PDE_PROPERTY_RW(RadioCheckID);
		ADD_PDE_PROPERTY_R (RadioCheckText);
		ADD_PDE_EVENT(EventRadioChanged);

		ADD_PDE_METHOD(DeleteTableAll);
	}
};


REGISTER_PDE_TYPE(RadioButtonSkin)
REGISTER_PDE_TYPE(RadioButton)
REGISTER_PDE_TYPE(RadioGroup)


namespace Gui
{
	RadioButton::RadioButton()
		: m_ID(0)
		, m_Check(false)
		, m_CheckPosition(CheckBox::kCheckLeft)
	{
	}

	RadioButton::~RadioButton()
	{
	}
}

//--------------------------------------------------------------------------------------
// Attribute
//--------------------------------------------------------------------------------------
namespace Gui
{
	PDE_ATTRIBUTE_GETTER(RadioButton, ID, int)
	{
		return m_ID;
	}

	PDE_ATTRIBUTE_SETTER(RadioButton, ID, int)
	{
		if (m_ID!= value)
		{
			m_ID = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(RadioButton, Check, bool)
	{
		return m_Check;
	}

	PDE_ATTRIBUTE_SETTER(RadioButton, Check, bool)
	{
		if (m_Check != value)
		{
			m_Check = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(RadioButton, CheckPosition, CheckBox::CheckPosition)
	{
		return m_CheckPosition;
	}

	PDE_ATTRIBUTE_SETTER(RadioButton, CheckPosition, CheckBox::CheckPosition)
	{
		if (m_CheckPosition != value)
		{
			m_CheckPosition = value;
			Invalid();
		}
	}
}


//--------------------------------------------------------------------------------------
// Event
//--------------------------------------------------------------------------------------
namespace Gui
{
	///on paint
	void RadioButton::OnPaint(PaintEventArgs & e)
	{
		Super::OnPaint(e);

		Core::Rectangle clientRect = GetClientRect();;
		Core::Rectangle checkRect;
		Core::Rectangle StringRect;

		if(m_CheckPosition == CheckBox::kCheckLeft)
		{
			checkRect = Rectangle::LeftTop(clientRect.Min,Vector2(GetSize().y,GetSize().y));
			StringRect = Rectangle::RightBottom(clientRect.Max, Vector2(GetSize().x-GetSize().y- 5, GetSize().y));
		}
		else	//kCheckRight
		{
			checkRect = Rectangle::RightBottom(clientRect.Max,Vector2(GetSize().y,GetSize().y));
			StringRect = Rectangle::LeftTop(clientRect.Min, Vector2(GetSize().x-GetSize().y - 5, GetSize().y));
		}		
		ARGB color = e.Enable?ARGB(255, 255 ,255): ARGB(212, 208, 200);
		tempc_ptr(CheckBoxSkin) skin = ptr_dynamic_cast<CheckBoxSkin>(GetSkin());

		if(skin)
		{
			if(e.Enable)
			{
				if (GetCheck())
				{
					Skin::DrawImage(e.render, skin->GetOnImage(), checkRect);
				}
				else
				{
					Skin::DrawImage(e.render, skin->GetOffImage(), checkRect);
				}
				clientRect.Min.x = 20;
				e.render->DrawString(GetFont(),GetTextColor(),GetBackgroundColor(),StringRect,GetText(), m_CheckPosition==CheckBox::kCheckLeft?Unit::kAlignLeftMiddle:Unit::kAlignRightMiddle);
			}
			else
			{
				if (GetCheck())
				{
					Skin::DrawImage(e.render, skin->GetOnDisabledImage(), checkRect);
				}
				else
				{
					Skin::DrawImage(e.render, skin->GetOffDisabledImage(), checkRect);
				}
				clientRect.Min.x = 20;
				e.render->DrawString(GetFont(),GetDisabledTextColor(),GetBackgroundColor(),StringRect,GetText(), m_CheckPosition==CheckBox::kCheckLeft?Unit::kAlignLeftMiddle:Unit::kAlignRightMiddle);
			}
		}
		else
		{
			if(GetCheck())
			{
				e.render->DrawRectangle(checkRect,checkRect,e.Enable? ARGB(0, 0, 0): ARGB(128,128,128));
			}
			else
			{
				e.render->DrawRectangle(checkRect,checkRect,e.Enable? ARGB(128, 128, 128): ARGB(0,0,0));
			}
			clientRect.Min.x = 20;
			e.render->DrawString(GetFont(),GetTextColor(),GetBackgroundColor(),StringRect,GetText(), m_CheckPosition==CheckBox::kCheckLeft?Unit::kAlignLeftMiddle:Unit::kAlignRightMiddle);
		}
	}

	/// on input event
	void RadioButton::OnInputEvent( Client::InputEventArgs &e )
	{
		if (e.IsMouseEvent())
		{
			Core::Vector2 localPos = ScreenToClient(e.CursorPosition);
			Core::Rectangle clientRect = GetClientRect();
			Core::Rectangle checkRect;
			if(m_CheckPosition == CheckBox::kCheckLeft)
			{
				checkRect = Rectangle::LeftTop(clientRect.Min,Vector2(GetSize().y,GetSize().y));
			}
			else	//kCheckRight
			{
				checkRect = Rectangle::RightBottom(clientRect.Max,Vector2(GetSize().y,GetSize().y));
			}
			bool pointed = 	checkRect.IsPointInside(localPos);	

			switch (e.Type)
			{
			//ʹ������ؼ�����ܶ�Σ��ͻ����SetCapture��������⡣
			//case InputEventArgs::kMouseDown:
			//case InputEventArgs::kMouseDoubleClick:
			//	{
			//		if(e.Code == MC_LEFT_BUTTON && pointed)
			//		{
			//			SetCapture(true);
			//		}
			//	}
			//	e.Handled = true;
			//	break;

			case InputEventArgs::kMouseUp:
				{
					if(e.Code == MC_LEFT_BUTTON && pointed)
					{					
						SetCapture(false);
						OnClick(e);
// 						SetCheck(!GetCheck());
// 						OnCheckChanged(EventArgs());
					}
					e.Handled = true;

				}
				break;
			}
		}

		if (!e.Handled)
			Super::OnInputEvent(e);
	}

	///on check changed

	void RadioButton::OnClick( EventArgs & e )
	{
		EventClick.Fire(ptr_static_cast<RadioButton>(this), Core::EventArgs());
	}

	void RadioButton::OnVisibleChanged( EventArgs & e )
	{
		Super::OnVisibleChanged(e);
		EventVisibleChange.Fire(ptr_static_cast<RadioButton>(this), Core::EventArgs());
	}
}

namespace Gui
{
	RadioGroup::RadioGroup()
		:m_RadioCheckID(-1)
	{
		
	}

	RadioGroup::~RadioGroup()
	{

	}

	PDE_ATTRIBUTE_GETTER(RadioGroup, RadioCheckID, int)
	{
		return m_RadioCheckID;
	}
	PDE_ATTRIBUTE_SETTER(RadioGroup, RadioCheckID, int)
	{
		if(m_RadioCheckID != value)
		{
			ChangeRadioCheckID(value, false);
		}
	}

	PDE_ATTRIBUTE_GETTER(RadioGroup, RadioCheckText, const Core::String&)
	{
		Core::HashSet<sharedc_ptr(RadioButton), int>::Enumerator itr(m_table);
		while (itr.MoveNext())
		{
			if(itr.Value() == m_RadioCheckID)
			{
				return itr.Key()->GetText();
			}
		}
		return Core::String::kEmpty;
	}

	void RadioGroup::OnFrameUpdate(EventArgs & e)
	{
		Super::OnFrameUpdate(e);
		for (tempc_ptr(Control) pControl = GetFirstChild(); pControl; pControl = pControl->GetNext())
		{
			tempc_ptr(RadioButton) pButton = ptr_dynamic_cast<RadioButton>(pControl);
			if(pButton)
			{
				if(!m_table.Contains(pButton))
				{
					m_table.Add(pButton, pButton->GetID());
					pButton->EventClick.Subscribe(NewDelegate(&Self::OnChildClick, ptr_static_cast<Self>(this)));
					pButton->EventVisibleChange.Subscribe(NewDelegate(&Self::OnChildVisibleChange, ptr_static_cast<Self>(this)));
				}
			}
		}
		if(m_RadioCheckID<0)
		{
			ChangeRadioCheckID(GetMinID(), false);
		}
	}

	void RadioGroup::OnRadioCheckChanged( EventArgs & e )
	{
		EventRadioChanged.Fire(ptr_static_cast<RadioGroup>(this), e);
	}

	void RadioGroup::OnChildClick( by_ptr(void) sender,EventArgs & e )
	{
		tempc_ptr(RadioButton) pButton = ptr_dynamic_cast<RadioButton>(sender);
		if(pButton)
		{
			if(pButton->GetID()!=m_RadioCheckID)
			{
				ChangeRadioCheckID(pButton->GetID(), true);
			}
		}
	}

	void RadioGroup::OnChildVisibleChange( by_ptr(void) sender, EventArgs& e )
	{
		tempc_ptr(Control) pButton = ptr_dynamic_cast<RadioButton>(sender);
		if(GetVisibleCount()>0)
		{
			ChangeRadioCheckID(GetMinID(), true);
			DirtyLayout();
		}
		else
		{
			pButton->SetVisible(true);
		}
	}

	void RadioGroup::ChangeRadioCheckID(int radioCheckID, bool triggerEvent)
	{
		if(m_RadioCheckID!=radioCheckID && radioCheckID>=0)
		{
			bool bFound = false;
			Core::HashSet<sharedc_ptr(RadioButton), int>::Enumerator itr(m_table);
			while (itr.MoveNext())
			{
				if(itr.Value() == radioCheckID)
				{
					bFound = true;
					itr.Key()->SetCheck(true);
					break;
				}
			}

			if(bFound)
			{
				itr.Reset();
				while (itr.MoveNext())
				{
					if(itr.Value() != radioCheckID)
					{
						itr.Key()->SetCheck(false);
					}
				}
				m_RadioCheckID = radioCheckID;
			}

			if(triggerEvent)
			{
				OnRadioCheckChanged(Core::EventArgs());
			}
		}
	}

	int RadioGroup::GetMinID()
	{
		int minID = S32_MAX;
		Core::HashSet<sharedc_ptr(RadioButton), int>::Enumerator itr(m_table);
		while (itr.MoveNext())
		{
			if(!itr.Key()->GetVisible())
				continue;
			if(itr.Value() < minID)
			{
				minID = itr.Value();
			}
		}
		if(minID<S32_MAX)
			return minID;
		else
			return -1;
	}

	int RadioGroup::GetVisibleCount()
	{
		int nCount = 0;
		Core::HashSet<sharedc_ptr(RadioButton), int>::Enumerator itr(m_table);
		while (itr.MoveNext())
		{
			if(itr.Key()->GetVisible())
				nCount++;
		}
		return nCount;
	}

	void RadioGroup::DeleteTableAll()
	{
		for (tempc_ptr(Control) pControl = GetFirstChild();pControl;)
		{
			tempc_ptr(RadioButton) pButton = ptr_dynamic_cast<RadioButton>(pControl);
			pControl = pControl->GetNext();
			if(pButton)
			{
				pButton->SetParent(NullPtr);
			}
		}
		m_table.Clear();
		m_RadioCheckID = -1;
	}
}
