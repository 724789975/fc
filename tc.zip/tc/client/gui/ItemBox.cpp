#include "pch.h"
#include <string>
using namespace Core;
using namespace Gui;
using namespace Client;

DEFINE_PDE_TYPE_CLASS(Gui::ItemBoxSkin)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::ControlSkin);
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_PROPERTY_RW(NeutralNormalImage);
		ADD_PDE_PROPERTY_RW(NeutralHoverImage);
		ADD_PDE_PROPERTY_RW(NeutralSelectedImage);

		ADD_PDE_PROPERTY_RW(RedNormalImage);
		ADD_PDE_PROPERTY_RW(RedHoverImage);
		ADD_PDE_PROPERTY_RW(RedSelectedImage);

		ADD_PDE_PROPERTY_RW(BlueNormalImage);
		ADD_PDE_PROPERTY_RW(BlueHoverImage);
		ADD_PDE_PROPERTY_RW(BlueSelectedImage);

		ADD_PDE_PROPERTY_RW(LockedImage);
		ADD_PDE_PROPERTY_RW(PackAImage);
		ADD_PDE_PROPERTY_RW(PackBImage);
		ADD_PDE_PROPERTY_RW(PackCImage);
		ADD_PDE_PROPERTY_RW(PackDImage);
		ADD_PDE_PROPERTY_RW(PackEImage);
		ADD_PDE_PROPERTY_RW(RepairImage);
		ADD_PDE_PROPERTY_RW(EmptyImage);

		ADD_PDE_PROPERTY_RW(NotSuitImage);

		ADD_PDE_PROPERTY_RW(TuneNoImage);
		ADD_PDE_PROPERTY_RW(TuneYesImage);
		ADD_PDE_PROPERTY_RW(TunedImage);

		ADD_PDE_PROPERTY_RW(UsingYesImage);
		ADD_PDE_PROPERTY_RW(UsingNoImage);

		ADD_PDE_PROPERTY_RW(SlotWeaponFirst);
		ADD_PDE_PROPERTY_RW(SlotWeaponSecond);
		ADD_PDE_PROPERTY_RW(SlotWeaponGrenade);
		ADD_PDE_PROPERTY_RW(SlotWeaponFlash);
		ADD_PDE_PROPERTY_RW(SlotWeaponSmoke);

		ADD_PDE_PROPERTY_RW(SlotCharacterArmet);
		ADD_PDE_PROPERTY_RW(SlotCharacterMask);
		ADD_PDE_PROPERTY_RW(SlotCharacterClothes);
		ADD_PDE_PROPERTY_RW(SlotCharacterGloves);
		ADD_PDE_PROPERTY_RW(SlotCharacterTrou);
		ADD_PDE_PROPERTY_RW(SlotCharacterShoes);
		ADD_PDE_PROPERTY_RW(SlotCharacterBadge);

		ADD_PDE_PROPERTY_RW(NameNormalColor);
		ADD_PDE_PROPERTY_RW(NameHighlightColor);
		ADD_PDE_PROPERTY_RW(LeftHighlightColor);
	}
};


DEFINE_PDE_TYPE_CLASS(Gui::ItemBox)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::Control);
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_EVENT(EventMouseEnter);
		ADD_PDE_EVENT(EventMouseLeave);
		ADD_PDE_EVENT(EventSelected);
		ADD_PDE_EVENT(EventDoubleClick);
		ADD_PDE_EVENT(EventCancel);
		ADD_PDE_PROPERTY_RW(Empty);
		ADD_PDE_PROPERTY_RW(Loading);
		ADD_PDE_PROPERTY_RW(Locked);
		ADD_PDE_PROPERTY_RW(Selected);
		ADD_PDE_PROPERTY_RW(CanCancel);

		ADD_PDE_PROPERTY_RW(ID);

		ADD_PDE_PROPERTY_RW(ItemName);
		ADD_PDE_PROPERTY_RW(ItemIcon);
		ADD_PDE_PROPERTY_RW(LoadingImage);

		ADD_PDE_PROPERTY_RW(Cost);
		ADD_PDE_PROPERTY_RW(CostType);

		ADD_PDE_PROPERTY_RW(Suit);

		ADD_PDE_PROPERTY_RW(PID);	
		ADD_PDE_PROPERTY_RW(SID);
		ADD_PDE_PROPERTY_RW(Where);

		ADD_PDE_PROPERTY_RW(Period);

		ADD_PDE_PROPERTY_RW(Side);

		ADD_PDE_PROPERTY_RW(UnitType);
		ADD_PDE_PROPERTY_RW(TimeLeftType);
		ADD_PDE_PROPERTY_RW(TimeLeft);
		ADD_PDE_PROPERTY_RW(Quantity);
		ADD_PDE_PROPERTY_RW(Durable);

		ADD_PDE_PROPERTY_RW(InPack);
		ADD_PDE_PROPERTY_RW(ModState);
		ADD_PDE_PROPERTY_RW(UseState);

		ADD_PDE_PROPERTY_RW(Type);	
		ADD_PDE_PROPERTY_RW(SubType);
		ADD_PDE_PROPERTY_RW(BagSP1);

		ADD_PDE_METHOD(Clear);

		ADD_PDE_PROPERTY_RW(LastSelected);

	}
};

REGISTER_PDE_TYPE(Gui::ItemBoxSkin);
REGISTER_PDE_TYPE(Gui::ItemBox);

namespace Gui
{
	ItemBox::ItemBox()
		:m_Selected(false)
		,m_Lock(false)
		,m_IsLoading(false)
		,m_Hovered(false)
		,m_IsEmpty(false)
		,m_CanCancel(false)
		,m_SelectColor(ARGB(127, 77, 77, 77))
		,m_HoverColor(ARGB(127, 100, 100, 100))
		,m_NormalColor(ARGB(127, 133, 133, 133))
		,m_DisableColor(ARGB(127, 177, 177, 177))
		,m_ID(0)
		,m_PID(-1)
		,m_SID(-1)
		,m_ItemName("item name")
		,m_ModState(-1)
		,m_UseState(-1)
		,m_UnitType(-1)
		,m_TimeLeftType(-1)
		,m_TimeLeft(-1)
		,m_Quantity(-1)
		,m_Durable(-1)
		,m_CostType(0)
		,m_Cost(13000)
		,m_Period(-1)
		,m_InPack(-1)
		,m_Suit(true)
		,m_Side(-1)
		,m_Type(-1)
		,m_SubType(-1)
		,m_BagSP1(-1)
		,m_LastSelected(false)
		,m_Where(-1)
		,m_StartLoading(false)
	{
		m_Text = "New ItemBox";
		m_Size = Vector2(192,70);
		m_BackgroundColor = m_NormalColor;
	}

	ItemBox::~ItemBox()
	{

	}
}

namespace Gui
{
	PDE_ATTRIBUTE_GETTER(ItemBox, Empty, bool)
	{
		return m_IsEmpty;
	}
	PDE_ATTRIBUTE_SETTER(ItemBox, Empty, bool)
	{
		if(m_IsEmpty == value)
			return;
		m_IsEmpty = value;
		Invalid();
	}

	PDE_ATTRIBUTE_GETTER(ItemBox, Selected, bool)
	{
		return m_Selected;
	}
	PDE_ATTRIBUTE_SETTER(ItemBox, Selected, bool)
	{
		if(m_Selected == value)
			return;

		m_Selected = value;
		if(m_Selected)
			EventSelected.Fire(ptr_static_cast<ItemBox>(this), ValueChangeEventArgs());
		else
			EventCancel.Fire(ptr_static_cast<ItemBox>(this), ValueChangeEventArgs());
		Invalid();
	}

	PDE_ATTRIBUTE_GETTER(ItemBox, Locked, bool)
	{
		return m_Lock;
	}
	PDE_ATTRIBUTE_SETTER(ItemBox, Locked, bool)
	{
		if(m_Lock == value)
			return;

		m_Lock = value;
		Invalid();
	}

	PDE_ATTRIBUTE_GETTER(ItemBox, Loading, bool)
	{
		return m_IsLoading;
	}
	PDE_ATTRIBUTE_SETTER(ItemBox, Loading, bool)
	{
		if(m_IsLoading == value)
			return;

		m_IsLoading = value;
		if(m_IsLoading)
			m_StartLoading = true;
		else
			m_StartLoading = false;
		Invalid();
	}

	PDE_ATTRIBUTE_GETTER(ItemBox, CostType, int)
	{
		return m_CostType;
	}
	PDE_ATTRIBUTE_SETTER(ItemBox, CostType, int)
	{
		if(m_CostType == value)
			return;

		m_CostType = value;
		Invalid();
	}

	PDE_ATTRIBUTE_GETTER(ItemBox, Cost, int)
	{
		return m_Cost;
	}
	PDE_ATTRIBUTE_SETTER(ItemBox, Cost, int)
	{
		if(m_Cost == value)
			return;

		m_Cost = value;
		Invalid();
	}

	PDE_ATTRIBUTE_GETTER(ItemBox, Period, int)
	{
		return m_Period;
	}
	PDE_ATTRIBUTE_SETTER(ItemBox, Period, int)
	{
		if(m_Period == value)
			return;

		m_Period = value;
		Invalid();
	}

	PDE_ATTRIBUTE_GETTER(ItemBox, ID, int)
	{
		return m_ID;
	}
	PDE_ATTRIBUTE_SETTER(ItemBox, ID, int)
	{
		if(m_ID == value)
			return;
		m_ID = value;
	}

	PDE_ATTRIBUTE_GETTER(ItemBox, Suit, bool)
	{
		return m_Suit;
	}
	PDE_ATTRIBUTE_SETTER(ItemBox, Suit, bool)
	{
		if(m_Suit == value)
			return;

		m_Suit = value;
		Invalid();
	}

	PDE_ATTRIBUTE_GETTER(ItemBox, ItemName, String)
	{
		return m_ItemName;
	}
	PDE_ATTRIBUTE_SETTER(ItemBox, ItemName, String)
	{
		if(m_ItemName == value)
			return;

		m_ItemName = value;
		Invalid();
	}

	PDE_ATTRIBUTE_GETTER(ItemBox, ItemIcon, tempc_ptr(Icon))
	{
		return m_ItemIcon;
	}
	PDE_ATTRIBUTE_SETTER(ItemBox, ItemIcon, tempc_ptr(Icon))
	{
		if(m_ItemIcon!=value)
		{
			m_ItemIcon = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(ItemBox, TimeLeftType, int)
	{
		return m_TimeLeftType;
	}
	PDE_ATTRIBUTE_SETTER(ItemBox, TimeLeftType, int)
	{
		if(m_TimeLeftType!=value)
		{
			m_TimeLeftType = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(ItemBox, TimeLeft, int)
	{
		return m_TimeLeft;
	}
	PDE_ATTRIBUTE_SETTER(ItemBox, TimeLeft, int)
	{
		if(m_TimeLeft!=value)
		{
			m_TimeLeft = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(ItemBox, Quantity, int)
	{
		return m_Quantity;
	}
	PDE_ATTRIBUTE_SETTER(ItemBox, Quantity, int)
	{
		if(m_Quantity!=value)
		{
			m_Quantity = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(ItemBox, Side, int)
	{
		return m_Side;
	}
	PDE_ATTRIBUTE_SETTER(ItemBox, Side, int)
	{
		if(m_Side!=value)
		{
			m_Side = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(ItemBox, InPack, int)
	{
		return m_InPack;
	}
	PDE_ATTRIBUTE_SETTER(ItemBox, InPack, int)
	{
		if(m_InPack!=value)
		{
			m_InPack = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(ItemBox, PID, int)
	{
		return m_PID;
	}
	PDE_ATTRIBUTE_SETTER(ItemBox, PID, int)
	{
		if(m_PID == value)
			return;
		m_PID = value;
	}

	PDE_ATTRIBUTE_GETTER(ItemBox, SID, int)
	{
		return m_SID;
	}
	PDE_ATTRIBUTE_SETTER(ItemBox, SID, int)
	{
		if(m_SID == value)
			return;
		m_SID = value;
	}

	PDE_ATTRIBUTE_GETTER(ItemBox, Type, int)
	{
		return m_Type;
	}
	PDE_ATTRIBUTE_SETTER(ItemBox, Type, int)
	{
		if(m_Type == value)
			return;
		m_Type = value;
	}

	PDE_ATTRIBUTE_GETTER(ItemBox, SubType, int)
	{
		return m_SubType;
	}
	PDE_ATTRIBUTE_SETTER(ItemBox, SubType, int)
	{
		if(m_SubType == value)
			return;
		m_SubType = value;
	}

	PDE_ATTRIBUTE_GETTER(ItemBox, BagSP1, int)
	{
		return m_BagSP1;
	}
	PDE_ATTRIBUTE_SETTER(ItemBox, BagSP1, int)
	{
		if(m_BagSP1 != value)
		{
			m_BagSP1 = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(ItemBox, LastSelected, bool)
	{
		return m_LastSelected;
	}
	PDE_ATTRIBUTE_SETTER(ItemBox, LastSelected, bool)
	{
		if(m_LastSelected == value)
			return;
		m_LastSelected = value;
	}

	PDE_ATTRIBUTE_GETTER(ItemBox, Where, int)
	{
		return m_Where;
	}
	PDE_ATTRIBUTE_SETTER(ItemBox, Where, int)
	{
		if(m_Where != value)
		{
			m_Where = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(ItemBox, ModState, int)
	{
		return m_ModState;
	}
	PDE_ATTRIBUTE_SETTER(ItemBox, ModState, int)
	{
		if(m_ModState != value)
		{
			m_ModState = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(ItemBox, UseState, int)
	{
		return m_UseState;
	}
	PDE_ATTRIBUTE_SETTER(ItemBox, UseState, int)
	{
		if(m_UseState != value)
		{
			m_UseState = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(ItemBox, UnitType, int)
	{
		return m_UnitType;
	}
	PDE_ATTRIBUTE_SETTER(ItemBox, UnitType, int)
	{
		if(m_UnitType != value)
		{
			m_UnitType = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(ItemBox, Durable, int)
	{
		return m_Durable;
	}
	PDE_ATTRIBUTE_SETTER(ItemBox, Durable, int)
	{
		if(m_Durable != value)
		{
			m_Durable = value;
			Invalid();
		}
	}
}

namespace Gui
{
	void ItemBox::Clear()
	{
		m_Selected = false;
		m_LastSelected = false;
		m_ItemName = "";
		m_InPack = -1;
		m_Where = -2;
		m_ModState = -1;
		m_UseState = -1;
		m_UnitType = -1;
		m_Durable = -1;
		m_Type = -1;
		m_SubType = -1;

		m_ItemIcon = NullPtr;
		m_StartLoading = false;

		Invalid();
	}
}

///////////
namespace Gui
{

	void ItemBox::OnFrameUpdate( EventArgs & e )
	{
		if(m_IsLoading && m_LoadingImage)
		{
			float frameTime = Task::GetFrameTime();

			int oldFrame = m_LoadingImage->GetCurrentFrame();
			int newFrame = m_LoadingImage->Update(frameTime);

			if(m_StartLoading)
			{
				m_LoadingImage->Reset();
				m_StartLoading = false;
			}

			if(oldFrame!=newFrame)
				Invalid();
		}
	}

	void ItemBox::OnInputEvent(Client::InputEventArgs & e)
	{
		if(m_IsEmpty || /*m_Type == -1 ||*/ m_Where == 6)
		{
			if (!e.Handled)
			{
				Control::OnInputEvent(e);
			}
			return;
		}
		if(e.IsMouseEvent())
		{
			switch (e.Type)
			{
			case InputEventArgs::kMouseDoubleClick:
				OnDoubleClick(e);
				break;
			case InputEventArgs::kMouseUp:
				if(!m_Selected)
				{
					SetSelected(true);
				}
				else
				{
					if(GetCanCancel())
					{
						SetSelected(false);
					}
				}
				break;
			case InputEventArgs::kMouseMove:
				if(!m_Hovered)
				{
					m_Hovered = true;
					Invalid();
				}
				break;
			case InputEventArgs::kMouseEnter:
				{
				}
				break;
			case InputEventArgs::kMouseLeave:
				if(m_Hovered)
				{
					m_Hovered = false;
					Invalid();
				}
				break;
			default:break;
			}
		}
		if (!e.Handled)
			Control::OnInputEvent(e);
	}

	void ItemBox::OnPaint(PaintEventArgs & e)
	{
		tempc_ptr(ItemBoxSkin) skin = ptr_dynamic_cast<ItemBoxSkin>(GetSkin());
		Core::Vector2 meSize = GetSize();
		Core::Rectangle uvrect = Core::Rectangle(0, 0, 1, 1);
		if(skin)
		{
			tempc_ptr(Image) normalImage;
			tempc_ptr(Image) selectedImage;
			tempc_ptr(Image) hoverImage;
			if(GetType()==2)
			{
				switch(GetSide())
				{
				case 0:
					normalImage = skin->GetRedNormalImage();
					selectedImage = skin->GetRedSelectedImage();
					hoverImage = skin->GetRedHoverImage();
					break;
				case 1:
					normalImage = skin->GetBlueNormalImage();
					selectedImage = skin->GetBlueSelectedImage();
					hoverImage = skin->GetBlueHoverImage();
					break;
				default:
					normalImage = skin->GetNeutralNormalImage();
					selectedImage = skin->GetNeutralSelectedImage();
					hoverImage = skin->GetNeutralHoverImage();
					break;
				}
			}
			else
			{
				normalImage = skin->GetNeutralNormalImage();
				selectedImage = skin->GetNeutralSelectedImage();
				hoverImage = skin->GetNeutralHoverImage();
			}

			if(m_IsEmpty || m_Type == -1)
			{
				Skin::DrawImage(e.render, skin->GetEmptyImage(), GetClientRect());
				if(m_Where==-1 || m_Where == 6)
				{
					if(m_Selected)
						Skin::DrawImage(e.render, skin->GetNeutralSelectedImage(), GetClientRect());
					else if(m_Hovered)
						Skin::DrawImage(e.render, skin->GetNeutralHoverImage(), GetClientRect());
					if(m_BagSP1==1)
					{
						Core::String slotName;

						switch(m_ID)
						{
						case 1:
							{
								Skin::DrawImage(e.render, skin->GetSlotWeaponFirst(), GetClientRect());
								slotName = gLang->GetTextW(L"��������");
							}
							break;
						case 2:
							{
								Skin::DrawImage(e.render, skin->GetSlotWeaponSecond(), GetClientRect());
								slotName = gLang->GetTextW(L"��������");
							}
							break;
						case 4:
							{
								Skin::DrawImage(e.render, skin->GetSlotWeaponGrenade(), GetClientRect());
								slotName = gLang->GetTextW(L"���ײ�");
							}
							break;
						case 5:
							{
								Skin::DrawImage(e.render, skin->GetSlotWeaponFlash(), GetClientRect());
								slotName = gLang->GetTextW(L"�����ײ�");
							}
							break;
						case 6:
							{
								Skin::DrawImage(e.render, skin->GetSlotWeaponSmoke(), GetClientRect());
								slotName = gLang->GetTextW(L"��������");
							}
							break;
						}

						Core::Rectangle nameRect = Core::Rectangle::LeftTop(8, 6, 180, 20);
						if(skin)
							e.render->DrawString(GetFont(), m_Selected?skin->GetNameHighlightColor():skin->GetNameNormalColor(), Core::ARGB(0,0,0,0), nameRect, slotName, Unit::kAlignLeftMiddle);
						else
							e.render->DrawString(GetFont(), Core::ARGB(255, 255, 255, 255), Core::ARGB(0,0,0,0), nameRect, slotName, Unit::kAlignLeftMiddle);

					}
					else if(m_BagSP1==2)
					{
						Core::String slotName;

						switch(m_ID)
						{
						case 1:
							{
								Skin::DrawImage(e.render, skin->GetSlotCharacterArmet(), GetClientRect());
								slotName = gLang->GetTextW(L"ͷ����Ʒ��");
							}
							break;
						case 2:
							{
								Skin::DrawImage(e.render, skin->GetSlotCharacterMask(), GetClientRect());
								slotName = gLang->GetTextW(L"�沿��Ʒ��");
							}
							break;
						case 3:
							{
								Skin::DrawImage(e.render, skin->GetSlotCharacterClothes(), GetClientRect());
								slotName = gLang->GetTextW(L"���²�");
							}
							break;
						case 4:
							{
								Skin::DrawImage(e.render, skin->GetSlotCharacterGloves(), GetClientRect());
								slotName = gLang->GetTextW(L"���ײ�");
							}
							break;
						case 5:
							{
								Skin::DrawImage(e.render, skin->GetSlotCharacterTrou(), GetClientRect());
								slotName = gLang->GetTextW(L"���Ӳ�");
							}
							break;
						case 6:
							{
								Skin::DrawImage(e.render, skin->GetSlotCharacterShoes(), GetClientRect());
								slotName = gLang->GetTextW(L"Ь�Ӳ�");
							}
							break;
						case 7:
							{
								Skin::DrawImage(e.render, skin->GetSlotCharacterBadge(), GetClientRect());
								slotName = gLang->GetTextW(L"���²�");
							}
							break;
						}

						Core::Rectangle nameRect = Core::Rectangle::LeftTop(8, 6, 180, 20);
						if(skin)
							e.render->DrawString(GetFont(), m_Selected?skin->GetNameHighlightColor():skin->GetNameNormalColor(), Core::ARGB(0,0,0,0), nameRect, slotName, Unit::kAlignLeftMiddle);
						else
							e.render->DrawString(GetFont(), Core::ARGB(255, 255, 255, 255), Core::ARGB(0,0,0,0), nameRect, slotName, Unit::kAlignLeftMiddle);

					}
				}
			}
			else if(m_Selected)
				Skin::DrawImage(e.render, selectedImage, GetClientRect());
			else if(m_Hovered)
			{
				Skin::DrawImage(e.render, normalImage, GetClientRect());
				Skin::DrawImage(e.render, hoverImage, GetClientRect());
			}			
			else
				Skin::DrawImage(e.render, normalImage, GetClientRect());
		}
		else
		{
			if(m_IsEmpty || m_Type == -1)
				e.render->DrawRectangle(GetClientRect(), uvrect, Core::ARGB(255, 22, 66, 22));
			else if(m_Lock)
				e.render->DrawRectangle(GetClientRect(), uvrect, m_DisableColor);
			else if(m_Selected)
				e.render->DrawRectangle(GetClientRect(), uvrect, m_SelectColor);
			else if(m_Hovered)
				e.render->DrawRectangle(GetClientRect(), uvrect, m_HoverColor);
			else
				e.render->DrawRectangle(GetClientRect(), uvrect, m_NormalColor);
		}

		if(m_IsLoading)
		{
			if(m_LoadingImage)
				Skin::DrawImage(e.render, m_LoadingImage, GetClientRect());
			else
				e.render->DrawString(GetFont(), ARGB(255, 255, 255, 255), Core::ARGB(0,0,0,0), GetClientRect(), "Loading", Unit::kAlignLeftMiddle);

			return;
		}

		if(m_IsEmpty || m_Type == -1)
			return;

		if((m_Where == 1 || m_Where == 4) && m_InPack>0)
		{
			Core::Rectangle packRect = Core::Rectangle::LeftBottom(7, meSize.y-7, 60, 20);
			if(skin)
			{
				tempc_ptr(Image) packImage;
				switch(m_InPack)
				{
				case 1:
					packImage = skin->GetPackAImage();
					break;
				case 2:
					packImage = skin->GetPackBImage();
					break;
				case 3:
					packImage = skin->GetPackCImage();
					break;
				case 4:
					packImage = skin->GetPackDImage();
					break;
				case 5:
					packImage = skin->GetPackEImage();
					break;
				}
				Skin::DrawImage(e.render, packImage, packRect);
			}
			else
				e.render->DrawRectangle(packRect, uvrect, ARGB(25, 0, 255, 0));
		}

		Skin::DrawIconText(e.render, GetItemIcon(), NullPtr, "", GetClientRect(), Unit::kAlignCenterMiddle
			, m_Lock?ARGB(255, 128, 128, 128):ARGB(255,255,255,255), ARGB(255,255,255,255), true, false);
		Core::String itemName = m_ItemName;
		if(m_ModState==2)
			itemName = Core::String::Format(gLang->GetTextW(L"%s(��)"), m_ItemName);
		Core::Rectangle nameRect = Core::Rectangle::LeftTop(8, 6, 180, 20);
		if(skin)
			e.render->DrawString(GetFont(), m_Selected?skin->GetNameHighlightColor():skin->GetNameNormalColor(), Core::ARGB(0,0,0,0), nameRect, itemName, Unit::kAlignLeftMiddle);
		else
			e.render->DrawString(GetFont(), Core::ARGB(255, 255, 255, 255), Core::ARGB(0,0,0,0), nameRect, m_ItemName, Unit::kAlignLeftMiddle);

		if(GetType()==1)
		{
			if(skin)
			{
				Core::Rectangle tuneRect = Core::Rectangle::RightTop(meSize.x-8, 6, 47, 18);
				if(m_ModState == 1 || m_ModState == 2)
				{
					Skin::DrawImage(e.render, skin->GetTuneYesImage(), tuneRect);
				}
			}
		}
		else if(GetType()==4 && m_UnitType!=3)
		{
			Core::Rectangle useRect = Core::Rectangle::LeftBottom(7, meSize.y-7, 60, 20);
			if(m_UseState > 0)
			{
				Skin::DrawImage(e.render, skin->GetUsingYesImage(), useRect);
			}
		}

		if(m_Where == 3) //In shop
		{
			sharedc_ptr(Client::Font) font2 = gRender->font_manager->GetFont("simhei", 12, 0);
			if(!font2)
				font2 = GetFont();

			CStrBuf<256> buff;
			CStrBuf<256> GP_CR;

			if(m_CostType == 0)
				GP_CR.format(gLang->GetTextW(L"G��"));
			else
				GP_CR.format(gLang->GetTextW(L"��ȯ"));
			if(m_UnitType == 3)
			{
				buff.format(gLang->GetTextW(L"%s / %d��"), GP_CR.buff(), m_Period);
			}
			else
			{
				if(m_Period>0)
					buff.format(gLang->GetTextW(L"%s / %d��"), GP_CR.buff(), m_Period);
				else
					buff.format(gLang->GetTextW(L"%s / ����"), GP_CR.buff());
			}

			Core::Rectangle tempRect = Core::Rectangle(0,0,0,0);
			F32 width = GetFont()->MeasureString(tempRect, buff, -1, Unit::kAlignCenterMiddle).GetExtent().x;

			Vector2 clientSize = GetSize();
			Core::Rectangle CostRect = Core::Rectangle(clientSize.x-80-width-8, clientSize.y-26, clientSize.x-width-8, clientSize.y-6);
			Core::Rectangle UnitRect = Core::Rectangle(clientSize.x-width-8, clientSize.y-26, clientSize.x-8, clientSize.y-6);

			e.render->DrawString(font2, Core::ARGB(255, 255, 255, 255), Core::ARGB(0,0,0,0)
				, UnitRect, buff, Unit::kAlignRightBottom);

			buff.format("%d", GetCost());
			e.render->DrawString(GetFont(), Core::ARGB(255, 255, 255, 255), Core::ARGB(0,0,0,0)
				, CostRect, buff, Unit::kAlignRightBottom);

		}
		else
		{
			Vector2 clientSize = GetSize();
			Core::Rectangle TimeRect = Core::Rectangle(clientSize.x-80-55-8, clientSize.y-26, clientSize.x-8, clientSize.y-6);
			CStrBuf<256> buff;
			if(m_UnitType == 4)  //time based
			{
				switch(m_TimeLeftType)
				{
				case 1:
					buff.format(gLang->GetTextW(L"ʣ��%d����"), m_TimeLeft);
					break;
				case 2:
					buff.format(gLang->GetTextW(L"ʣ��%dСʱ"), m_TimeLeft);
					break;
				case 3:
					buff.format(gLang->GetTextW(L"ʣ��%d��"), m_TimeLeft);
					break;
				default:
					buff.format(gLang->GetTextW(L"������Ч"));
					break;
				}
				if(skin)
				{
					e.render->DrawString(GetFont(), m_Selected?skin->GetLeftHighlightColor():skin->GetNameNormalColor(), Core::ARGB(0,0,0,0)
						, TimeRect, buff, Unit::kAlignRightBottom);
				}
				else
				{
					e.render->DrawString(GetFont(), Core::ARGB(255, 255, 255, 255), Core::ARGB(0,0,0,0)
						, TimeRect, buff, Unit::kAlignRightBottom);
				}
			}
			else if(m_UnitType == 3 && m_Where>3)	//Unit based
			{
				buff.format(gLang->GetTextW(L"ʣ��%d��"), m_Quantity);
				e.render->DrawString(GetFont(), Core::ARGB(255, 255, 255, 255), Core::ARGB(0,0,0,0)
					, TimeRect, buff, Unit::kAlignRightBottom);
			}
			else if(m_UnitType == 2)  //Damage based
			{
				if(m_Durable>=0 && m_Durable<=20)
				{
					Core::Rectangle repairRect = Core::Rectangle::LeftBottom(7, meSize.y-30, 18, 18);
					if(skin)
						Skin::DrawImage(e.render, skin->GetRepairImage(), repairRect);
					else
						e.render->DrawRectangle(repairRect, uvrect, ARGB(64, 255, 0, 0));
				}
			}
		}

		if(m_Lock)
		{
			Core::Rectangle lockRect = Core::Rectangle::LeftBottom(9, meSize.y-10, 44, 44);
			if(skin)
				Skin::DrawImage(e.render, skin->GetLockedImage(), lockRect);
			else
				e.render->DrawRectangle(lockRect, uvrect, ARGB(128, 0, 0, 0));
		}
		if(!m_Suit)
		{
			if(skin)
				Skin::DrawImage(e.render, skin->GetNotSuitImage(), GetClientRect());
			else
				e.render->DrawRectangle(GetClientRect(), uvrect, Core::ARGB(178, 0, 0, 0));
		}
	}

	void ItemBox::OnMouseEnter(Client::InputEventArgs & e)
	{
		EventMouseEnter.Fire(ptr_static_cast<ItemBox>(this),Client::InputEventArgs());
	}

	void ItemBox::OnMouseLeave(Client::InputEventArgs & e)
	{
		EventMouseLeave.Fire(ptr_static_cast<ItemBox>(this),Client::InputEventArgs());
	}

	void ItemBox::OnDoubleClick(Client::InputEventArgs & e)
	{
		EventDoubleClick.Fire(ptr_static_cast<ItemBox>(this), Client::InputEventArgs());
	}
	/// 

	int ItemBox::CalculateStringWidth(String str)
	{
		Core::Rectangle tempRect = Core::Rectangle(0, 0, 0, 0);
		Vector2 o = GetFont()->MeasureString(tempRect, str, -1, Unit::kAlignCenterMiddle).GetExtent();
		return (int)o.x;
	}
}

