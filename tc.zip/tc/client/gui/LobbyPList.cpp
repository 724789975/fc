#include "pch.h"

using namespace Core;
using namespace Client;
using namespace Gui;

//--------------------------------------------------------------------------------------
// type info
//--------------------------------------------------------------------------------------
DEFINE_PDE_TYPE_CLASS(LobbyPList)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Control);
		ADD_PDE_DEFAULT_CONSTRUCTOR();
		ADD_PDE_PROPERTY_R (ChannelPlayerList);
		ADD_PDE_PROPERTY_R (FriendsPlayerList);
		ADD_PDE_PROPERTY_R (ButtonInvite);
		ADD_PDE_PROPERTY_R (ButtonJoin);
		ADD_PDE_PROPERTY_R (SelectedPlayer);
		ADD_PDE_PROPERTY_RW(Duration);
	}
};

REGISTER_PDE_TYPE(LobbyPList);

#define LIST_SIZE_Y		180		//193->180
#define TARGET_POS_1	(Vector2(3,2))
#define TARGET_POS_2	(Vector2(3,26))
#define TARGET_POS_3	(Vector2(3,GetSize().y-46-24))  //193->180, 33->46

F32 Gui::LobbyPList::m_Duration = 0.25f;

namespace Gui
{
	LobbyPList::LobbyPList()
		: m_ChannelPCollapsed(false)
		, m_FriendsPCollapsed(true)
	{
	}

	LobbyPList::~LobbyPList()
	{
	}

	PDE_ATTRIBUTE_GETTER(LobbyPList, SelectedPlayer, const Core::String&)
	{
		tempc_ptr(ListItem) selectedItem;
		if(m_ChannelPlayerList->GetVisible())
			selectedItem = m_ChannelPlayerList->GetSelectedItem();
		else if(m_FriendsPlayerList->GetVisible())
			selectedItem = m_FriendsPlayerList->GetSelectedItem();
		if(selectedItem)
			return selectedItem->GetText(0);
		else
			return Core::String::kEmpty;
	}

	void LobbyPList::OnCreate()
	{
		Super::OnCreate();
		SetStyle("Gui.LobbyPList");
		SetSize(Vector2(163,276));
		SetPadding(Vector4(3,2,3,2));
		m_PanelCh = ptr_new Control;
		m_PanelCh->SetParent(ptr_static_cast<Control>(this));
		m_PanelCh->SetBackgroundColor(ARGB(0,255,255,255));
		m_PanelCh->SetSize(Vector2(157, LIST_SIZE_Y+24));
		m_PanelCh->SetLocation(TARGET_POS_1);
		m_PanelFr = ptr_new Control;
		m_PanelFr->SetParent(ptr_static_cast<Control>(this));
		m_PanelFr->SetBackgroundColor(ARGB(0,255,255,255));
		m_PanelFr->SetSize(Vector2(157, LIST_SIZE_Y+24));
		m_PanelFr->SetLocation(TARGET_POS_3);

		m_TitleCh = ptr_new Button;
		m_TitleCh->SetStyle("Gui.LobbyPListTitle");
		m_TitleCh->SetParent(m_PanelCh);
		m_TitleCh->SetSize(Vector2(157,24));
		m_TitleCh->SetLocation(Vector2::kZero);
		m_TitleCh->SetText(gLang->GetTextW(L"Ƶ������б�"));
		m_TitleCh->EventClick.Subscribe(NewDelegate(&Self::OnExpandButtonChClick, ptr_static_cast<Self>(this)));
		m_ChannelPlayerList = ptr_new ListTreeView;
		m_ChannelPlayerList->SetStyle("Gui.ListTreeViewLobbyPList");
		m_ChannelPlayerList->SetParent(m_PanelCh);
		m_ChannelPlayerList->SetSize(Vector2(157,LIST_SIZE_Y));
		m_ChannelPlayerList->SetLocation(Vector2(0,24));
		m_ChannelPlayerList->AddColumn("PlayerList", 157-15);
		m_ChannelPlayerList->SetVisible(false);
		m_ChEmptyLabel = ptr_new Label;
		m_ChEmptyLabel->SetParent(m_PanelCh);
		m_ChEmptyLabel->SetSize(Vector2(157, LIST_SIZE_Y));
		m_ChEmptyLabel->SetLocation(Vector2(0,24));
		m_ChEmptyLabel->SetBackgroundColor(ARGB(0, 255, 255, 255));
		m_ChEmptyLabel->SetVisible(false);
		m_ChEmptyLabel->SetTextAlign(Unit::kAlignCenterMiddle);
		m_ChEmptyLabel->SetFontSize(18);
		m_ChEmptyLabel->SetTextColor(ARGB(255, 255, 255, 255));
		m_ChEmptyLabel->SetTextPadding(Vector4(6,6,6,6));
		m_ChEmptyLabel->SetAutoWrap(true);

		m_TitleFr = ptr_new Button;
		m_TitleFr->SetStyle("Gui.LobbyPListTitle");
		m_TitleFr->SetParent(m_PanelFr);
		m_TitleFr->SetSize(Vector2(157,24));
		m_TitleFr->SetLocation(Vector2::kZero);
		m_TitleFr->SetText(gLang->GetTextW(L"���ߺ����б�"));
		m_TitleFr->EventClick.Subscribe(NewDelegate(&Self::OnExpandButtonFrClick, ptr_static_cast<Self>(this)));
		m_FriendsPlayerList = ptr_new ListTreeView;
		m_FriendsPlayerList->SetStyle("Gui.ListTreeViewLobbyPList");
		m_FriendsPlayerList->SetParent(m_PanelFr);
		m_FriendsPlayerList->SetSize(Vector2(157,LIST_SIZE_Y));
		m_FriendsPlayerList->SetLocation(Vector2(0,24));
		m_FriendsPlayerList->AddColumn("PlayerList", 157-15);
		m_FriendsPlayerList->SetVisible(false);
		m_FrEmptyLabel = ptr_new Label;
		m_FrEmptyLabel->SetParent(m_PanelFr);
		m_FrEmptyLabel->SetSize(Vector2(157, LIST_SIZE_Y));
		m_FrEmptyLabel->SetLocation(Vector2(0,24));
		m_FrEmptyLabel->SetBackgroundColor(ARGB(0, 255, 255, 255));
		m_FrEmptyLabel->SetVisible(false);
		m_FrEmptyLabel->SetTextAlign(Unit::kAlignCenterMiddle);
		m_FrEmptyLabel->SetFontSize(18);
		m_FrEmptyLabel->SetTextColor(ARGB(255, 255, 255, 255));
		m_FrEmptyLabel->SetTextPadding(Vector4(6,6,6,6));
		m_FrEmptyLabel->SetAutoWrap(true);

		m_IconPlus = ptr_new Icon("skinD/skinD_OL_icon_plus.tga", Vector4(0,0,0,0));
		m_IconMinus = ptr_new Icon("skinD/skinD_OL_icon_minus.tga", Vector4(0,0,0,0));
		m_ExpandCh = ptr_new Label;
		m_ExpandCh->SetParent(ptr_static_cast<Control>(m_TitleCh));
		m_ExpandCh->SetStyle("Gui.Label");
		m_ExpandCh->SetSize(Vector2(15,15));
		m_ExpandCh->SetLocation(Vector2(137, 5));
		m_ExpandCh->SetTextPadding(Vector4(0,0,0,0));
		m_ExpandCh->SetIcon(m_IconMinus);
		
		m_ExpandFr = ptr_new Label;
		m_ExpandFr->SetParent(ptr_static_cast<Control>(m_TitleFr));
		m_ExpandFr->SetStyle("Gui.Label");
		m_ExpandFr->SetSize(Vector2(15,15));
		m_ExpandFr->SetLocation(Vector2(137, 5));
		m_ExpandFr->SetTextPadding(Vector4(0,0,0,0));
		m_ExpandFr->SetIcon(m_IconPlus);

		sharedc_ptr(Control) bottom_line = ptr_new Control;
		bottom_line->SetStyle("Gui.Line02");
		bottom_line->SetBackgroundColor(ARGB(255,255,255,255));
		bottom_line->SetParent(ptr_static_cast<Control>(this));
		bottom_line->SetSize(Vector2(GetSize().x, 2));
		bottom_line->SetLocation(Vector2(0, GetSize().y-43));   //33+13-3
		sharedc_ptr(Control) bottom_panel = ptr_new Control;
		bottom_panel->SetBackgroundColor(ARGB(0,255,255,255));
		bottom_panel->SetParent(ptr_static_cast<Control>(this));
		bottom_panel->SetSize(Vector2(157, 41));		//33-2+13-3
		bottom_panel->SetDock(Control::kDockBottom);
		m_ButtonInvite = ptr_new Button;
		m_ButtonInvite->SetStyle("Gui.LobbyPListButton");
		m_ButtonInvite->SetParent(bottom_panel);
		m_ButtonInvite->SetSize(Vector2(54,23));
		m_ButtonInvite->SetLocation(Vector2(21, 10));
		m_ButtonInvite->SetText(gLang->GetTextW(L"ԼTA��"));

		m_ButtonJoin = ptr_new Button;
		m_ButtonJoin->SetStyle("Gui.LobbyPListButton");
		m_ButtonJoin->SetParent(bottom_panel);
		m_ButtonJoin->SetSize(Vector2(54,23));
		m_ButtonJoin->SetLocation(Vector2(81, 10));
		m_ButtonJoin->SetText(gLang->GetTextW(L"����TA"));

		ChPlayerListOnOff(true);
		FrPlayerListOnOff(false);
	}

	void LobbyPList::OnDestroy()
	{
		Super::OnDestroy();
	}

	void LobbyPList::OnFrameUpdate( EventArgs & e )
	{
		Vector2 targetPos;
		Vector2 currentSize = GetSize();
		Vector2 targetSize;
		if(m_ChannelPCollapsed && !m_FriendsPCollapsed)
		{
			//Panel size
			F32 targetSizeY = 276;
			F32 currentSizeY = GetSize().y;
			if(Core::Abs(targetSizeY-currentSizeY)>Core::EPSILON)
			{
				F32 frameTime = Task::GetFrameTime();
				F32 newSizeY = currentSizeY + LIST_SIZE_Y*frameTime/m_Duration;
				if(newSizeY>targetSizeY)
				{
					newSizeY = targetSizeY;
				}
				SetSize(Vector2(GetSize().x, newSizeY));
			}

			//Label Pos
			F32 targetPosY = TARGET_POS_2.y;
			F32 currentPosY = m_PanelFr->GetLocation().y;
			if(Core::Abs(targetPosY-currentPosY)>Core::EPSILON)
			{
				F32 frameTime = Task::GetFrameTime();
				F32 newPosY = currentPosY - LIST_SIZE_Y*frameTime/m_Duration;
				if(newPosY<targetPosY)
				{
					newPosY = targetPosY;
				}
				m_PanelFr->SetLocation(Vector2(TARGET_POS_2.x, newPosY));
			}

			//list visibility
			if(Core::Abs(targetSizeY-currentSizeY)<=Core::EPSILON && Core::Abs(targetPosY-currentPosY)<=Core::EPSILON)
			{
				FrPlayerListOnOff(true);
			}
		}
		else if(!m_ChannelPCollapsed && m_FriendsPCollapsed)
		{
			//Panel Size
			F32 targetSizeY = 276;
			F32 currentSizeY = GetSize().y;
			if(Core::Abs(targetSizeY-currentSizeY)>Core::EPSILON)
			{
				F32 frameTime = Task::GetFrameTime();
				F32 newSizeY = currentSizeY + LIST_SIZE_Y*frameTime/m_Duration;
				if(newSizeY>targetSizeY)
				{
					newSizeY = targetSizeY;
				}
				SetSize(Vector2(GetSize().x, newSizeY));
			}

			//Label Pos
			F32 targetPosY = TARGET_POS_3.y;
			F32 currentPosY = m_PanelFr->GetLocation().y;
			if(Core::Abs(targetPosY-currentPosY)>Core::EPSILON)
			{
				F32 frameTime = Task::GetFrameTime();
				F32 newPosY = currentPosY + LIST_SIZE_Y*frameTime/m_Duration;
				if(newPosY>targetPosY)
				{
					newPosY = targetPosY;
				}
				m_PanelFr->SetLocation(Vector2(TARGET_POS_3.x, newPosY));
			}

			//list visibility
			if(Core::Abs(targetSizeY-currentSizeY)<=Core::EPSILON && Core::Abs(targetPosY-currentPosY)<=Core::EPSILON)
			{
				ChPlayerListOnOff(true);
			}
		}
		else if(m_ChannelPCollapsed && m_ChannelPCollapsed)
		{
			//Panel Size
			F32 targetSizeY = 83+13;
			F32 currentSizeY = GetSize().y;
			if(Core::Abs(targetSizeY-currentSizeY)>Core::EPSILON)
			{
				F32 frameTime = Task::GetFrameTime();
				F32 newSizeY = currentSizeY - LIST_SIZE_Y*frameTime/m_Duration;
				if(newSizeY<targetSizeY)
				{
					newSizeY = targetSizeY;
				}
				SetSize(Vector2(GetSize().x, newSizeY));
			}

			//Label Pos
			F32 targetPosY = TARGET_POS_2.y;
			F32 currentPosY = m_PanelFr->GetLocation().y;
			if(Core::Abs(targetPosY-currentPosY)>Core::EPSILON)
			{
				F32 frameTime = Task::GetFrameTime();
				F32 newPosY = currentPosY - LIST_SIZE_Y*frameTime/m_Duration;
				if(newPosY<targetPosY)
				{
					newPosY = targetPosY;
				}
				m_PanelFr->SetLocation(Vector2(TARGET_POS_2.x, newPosY));
			}
		}
	}

	void LobbyPList::OnExpandButtonChClick( by_ptr(void) sender, InputEventArgs &e )
	{
		m_ChannelPCollapsed = !m_ChannelPCollapsed;
		if(!m_ChannelPCollapsed)
			m_FriendsPCollapsed = true;
		ChPlayerListOnOff(false);
		FrPlayerListOnOff(false);
		if(m_ChannelPCollapsed)
		{
			m_ExpandCh->SetIcon(m_IconPlus);
		}
		else
		{
			m_ExpandCh->SetIcon(m_IconMinus);
		}
		if(m_FriendsPCollapsed)
		{
			m_ExpandFr->SetIcon(m_IconPlus);
		}
		else
		{
			m_ExpandFr->SetIcon(m_IconMinus);
		}
	}

	void LobbyPList::OnExpandButtonFrClick( by_ptr(void) sender, InputEventArgs &e )
	{
		m_FriendsPCollapsed = !m_FriendsPCollapsed;
		if(!m_FriendsPCollapsed)
			m_ChannelPCollapsed = true;
		ChPlayerListOnOff(false);
		FrPlayerListOnOff(false);
		if(m_ChannelPCollapsed)
		{
			m_ExpandCh->SetIcon(m_IconPlus);
		}
		else
		{
			m_ExpandCh->SetIcon(m_IconMinus);
		}
		if(m_FriendsPCollapsed)
		{
			m_ExpandFr->SetIcon(m_IconPlus);
		}
		else
		{
			m_ExpandFr->SetIcon(m_IconMinus);
		}
	}

	void LobbyPList::OnPaint( PaintEventArgs & e )
	{
		Super::OnPaint(e);
	}

	void LobbyPList::ClearChannelPlayerList()
	{
		if(m_ChannelPlayerList)
			m_ChannelPlayerList->DeleteAll();
	}

	void LobbyPList::ClearFriendsPlayerList()
	{
		if(m_FriendsPlayerList)
			m_FriendsPlayerList->DeleteAll();
	}

	void LobbyPList::ChPlayerListOnOff( bool bOn )
	{
		if(bOn)
		{
			if(!gGame->channel_connection)
			{
				m_ChannelPlayerList->SetVisible(false);
				m_ChEmptyLabel->SetVisible(true);
				m_ChEmptyLabel->SetText(gLang->GetTextW(L"û�н���Ƶ��"));
			}
			else if(m_ChannelPlayerList->GetItemCount()<=0)
			{
				m_ChannelPlayerList->SetVisible(false);
				m_ChEmptyLabel->SetVisible(true);
				m_ChEmptyLabel->SetText(gLang->GetTextW(L"Ƶ����û�����"));
			}
			else
			{
				m_ChannelPlayerList->SetVisible(true);
				m_ChEmptyLabel->SetVisible(false);
			}
		}
		else
		{
			m_ChannelPlayerList->SetVisible(false);
			m_ChEmptyLabel->SetVisible(false);		
		}
	}

	void LobbyPList::FrPlayerListOnOff( bool bOn )
	{
		if(bOn)
		{
			if(m_FriendsPlayerList->GetItemCount()<=0)
			{
				m_FriendsPlayerList->SetVisible(false);
				m_FrEmptyLabel->SetVisible(true);
				m_FrEmptyLabel->SetText(gLang->GetTextW(L"û�к�������"));
			}
			else
			{
				m_FriendsPlayerList->SetVisible(true);
				m_FrEmptyLabel->SetVisible(false);
			}
		}
		else
		{
			m_FriendsPlayerList->SetVisible(false);
			m_FrEmptyLabel->SetVisible(false);
		}
	}
}
