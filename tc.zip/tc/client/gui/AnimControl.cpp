#include "pch.h"

using namespace Core;
using namespace Gui;
using namespace Client;


DEFINE_PDE_TYPE_CLASS(Gui::AnimControl)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::Control);
		ADD_PDE_DEFAULT_CONSTRUCTOR();
		
		ADD_PDE_EVENT(EventClick);
		ADD_PDE_EVENT(EventFinish);
		ADD_PDE_EVENT(EventTimeHide);
		ADD_PDE_PROPERTY_RW(PushDown);
		ADD_PDE_METHOD(DeleteAnimation);
		ADD_PDE_METHOD(StartAnimation);
		ADD_PDE_METHOD(SetAnimationTimer);
		ADD_PDE_METHOD(ClearAll);
		ADD_PDE_METHOD(AddAnim);
		ADD_PDE_METHOD(AddFrame);
		ADD_PDE_METHOD(DeleteFrameList);
		ADD_PDE_METHOD(ReStart);
		ADD_PDE_METHOD(TimeToHide);
		ADD_PDE_METHOD(TurnCard);
		ADD_PDE_METHOD(TrunCardContiue);
		ADD_PDE_METHOD(SetScrollParam);
		ADD_PDE_METHOD(StopAnimation);
		ADD_PDE_METHOD(SetFlipTimer);
	}
};

REGISTER_PDE_TYPE(Gui::AnimControl);


namespace Gui
{
	
	#define CONSTSPEED   300

	CAnimation::CAnimation(const Core::String & value, float	m_fTime,int type):
							m_AnimationName(value),
							m_frameTime(m_fTime),
							m_TimerAnimation(m_fTime),
							m_type(type),
							m_isFinish(false),
							m_needChange(false),
							m_turnCard(false),
							m_changeRatio(0.1f),
							m_imageRatio(0.0f),
							m_frameImage(NullPtr),
							m_rootFrame(NullPtr),
							next(NullPtr),
							m_parent(NULL),
							m_displacement(0),
							m_stopTime(0.0f),
							m_TurnTime(0),
							m_decelerateTime(0),
							m_bit(0),
							m_score(0),
							m_Timer(0),
							m_isFirst(false),
							m_start(true),
							m_TimeToStopSroll(0.f),
							m_totalstep(0),
							m_currentFrame(0),
							m_stoppedFrame(0),
							m_TurnCardIsContiue(false)
							
	{ 
		
	}	
	

	void CAnimation::StartDraw()			
	{  
		if(m_start)
		{
			m_Timer = Core::Task::GetTotalTime(); 
			m_TimerScale = Core::Task::GetTotalTime();
			m_TimeToStopSroll = Task::GetTotalTime();
			m_currentFrame = 0;
			m_scaleRatio = 1.0f;
			m_imageRatio = 0.0f;
			m_changeRatio = 0.1f;
			m_start = false;

			m_isFirst = false;
			m_totalstep = 0;
		}
	}

	void CAnimation::ReStart()
	{
		m_Timer = Core::Task::GetTotalTime();
		m_TimerScale = Core::Task::GetTotalTime();
		m_TimeToStopSroll = Task::GetTotalTime();
		m_TimerAnimation = m_frameTime;
		m_stopTime = 0.f;
		m_currentFrame = 0;
		m_scaleRatio = 1.0f;
		m_imageRatio = 0.0f;
		m_changeRatio = 0.1f;
		m_displacement = 0;
		m_isFinish = false;
		m_start = false;
		m_TurnCardIsContiue = false;
	}

	void CAnimation::AddFrame(by_ptr(Image) Animframe,BOOL NeedStopped)
	{
		sharedc_ptr(FrameImage) frame = ptr_new FrameImage();
		frame->m_vFrame = Animframe;
		frame->NendStopped = NeedStopped;

		if(NeedStopped)
			m_stoppedFrame = m_FrameList.Size();

		m_FrameList.PushBack(frame);			
	}

	void CAnimation::OnPaint(PaintEventArgs & e,const Core::Rectangle & rect)
	{
		if(m_type == 1)
			DrawAnimation(e,rect);
		else if(m_type == 2)
			DrawZoomAnimation(e,rect);
		else if(m_type == 3)
			DrawScaleAnimation(e,rect);
		else if(m_type == 4)
			DrawTimerAnimation(e,rect);
		else if(m_type == 5)
			DrawTurnCardAnimation(e,rect);
		else if(m_type == 6)
			DrawTurnAround(e,rect);
		else if(m_type == 7)
			DrawFlipAnimation(e,rect);
		else if(m_type == 8)
			DrawScrollableNum(e,rect);
	}

	void CAnimation::DrawAnimation(PaintEventArgs & e , const Core::Rectangle & rect)
	{
		F64 timer = Task::GetTotalTime() - m_Timer;
		Core::ARGB color = ARGB(255,255,255,255);
		Core::Rectangle Rect(rect);
		Core::Rectangle drawRect;
		Core::Vector2 ImageSize = Vector2::kZero;

		tempc_ptr(FrameImage) currframe  = m_FrameList[m_currentFrame];
		

		if(currframe && timer > m_frameTime)
		{		
			m_Timer =  Task::GetTotalTime();

			m_currentFrame = m_currentFrame + 1;
		}

		if(m_currentFrame > m_FrameList.Size() - 1)
		{
			m_currentFrame = m_FrameList.Size() - 1;
			m_isFinish = true;
		}
		
		ImageSize = currframe->m_vFrame->GetSize();

		Core::Rectangle	ImageRect(Vector2::kZero,ImageSize);

		GetProperRect(Rect,ImageRect,drawRect);

		drawRect.Move(Rect.GetCenter() - drawRect.GetExtent()/2);

		if(currframe)
			currframe->m_vFrame->Draw(e.render,drawRect,color);
	}

	void CAnimation::DrawZoomAnimation(PaintEventArgs & e , const Core::Rectangle & rect)
	{
		F64 timer = Task::GetTotalTime() - m_Timer;
		Core::ARGB color = ARGB(255,255,255,255);
		Core::Rectangle zoomRect(rect);
		Core::Rectangle	drawRect;
		Core::Vector2 ImageSize = Vector2::kZero;

		F32 width = (rect.Max.x - rect.Min.x)/2;
		F32 height = (rect.Max.y - rect.Min.y)/2;
		
		FrameImage *currframe  = m_FrameList[m_currentFrame];
		
		if(m_scaleRatio < 0.0f )
		{
			m_scaleRatio = 0.0f;
			m_isFinish = true;
		}

		zoomRect.Shrink(width*m_scaleRatio,height*m_scaleRatio,width*m_scaleRatio,height*m_scaleRatio);

		ImageSize = currframe->m_vFrame->GetSize();
		ImageSize.x = ImageSize.x * (1 - m_scaleRatio);
		ImageSize.y = ImageSize.y * (1 - m_scaleRatio);

		Core::Rectangle ImageRect(Vector2::kZero,ImageSize);

		GetProperRect(zoomRect,ImageRect,drawRect);

		if(currframe && timer > m_frameTime)
		{		
			m_Timer =  Task::GetTotalTime();
			m_scaleRatio = m_scaleRatio - 0.2f;
		}

		if(m_scaleRatio <= 0.5f && !m_isFinish)
			m_displacement += 4;

		else if(m_scaleRatio >= 0.5f && !m_isFinish)
			m_displacement -= 4;

		if( m_displacement > 0 )
			m_displacement = 0;
		
		drawRect.Move(Vector2(0, m_displacement));		

		if(currframe)
			currframe->m_vFrame->Draw(e.render,drawRect,color);

	}

	void CAnimation::DrawScaleAnimation(PaintEventArgs & e , const Core::Rectangle & rect)
	{
		F64 timer = Task::GetTotalTime() - m_Timer;
		F64 timerscale = Task::GetTotalTime() - m_TimerScale;
		Core::Rectangle zoomRect(rect);
		Core::Vector2 ImageSize = Vector2::kZero;

		Core::ARGB color = ARGB(255,255,255,255);

		F32 width = (rect.Max.x - rect.Min.x)/2;
		F32 height = (rect.Max.y - rect.Min.y)/2;

		FrameImage *currframe  = m_FrameList[m_currentFrame];

		float realRatio = 1 - m_imageRatio;

		zoomRect.Shrink(width*realRatio,height*realRatio,width*realRatio,height*realRatio);
		
		if(timer > m_frameTime)
		{
			m_Timer =  Task::GetTotalTime();
			m_currentFrame = m_currentFrame + 1;
		}
		

		if(m_currentFrame > m_FrameList.Size() - 1)
		{
			m_currentFrame = m_FrameList.Size() - 1;
			m_isFinish = true;
		}


		if(m_imageRatio && timerscale > m_frameTime/20.f)
		{
			m_imageRatio -= m_changeRatio;
			m_TimerScale = Task::GetTotalTime();
		}

		if(m_imageRatio <= 0.5f)
		{
			m_imageRatio = 0.5f;
			m_changeRatio = - m_changeRatio;
		}
		else if(m_imageRatio >= 1.0f)
		{
			m_imageRatio = 1.0f;
			m_changeRatio = - m_changeRatio;
		}
		
		if(currframe)
			currframe->m_vFrame->Draw(e.render,zoomRect,color);
	}

	void CAnimation::DrawTimerAnimation(PaintEventArgs & e , const Core::Rectangle & rect)
	{
		Core::String TimerString;
		F64 timer = Task::GetTotalTime() - m_Timer;
		F64 timerChange = Task::GetTotalTime() - m_TimerScale;
		ARGB TextColor;

		int minute,second,secondUnit,secondDec;
		int tempTime;

		if(timer >= 1)
		{
			m_TimerAnimation -= 1;
			m_Timer = Task::GetTotalTime();
		}
		
		if(timerChange > 0.3f)
		{
			m_needChange = !m_needChange;
			m_TimerScale = Task::GetTotalTime();
		}

		TextColor = m_needChange ? ARGB(255, 255, 0, 0):ARGB(255, 232, 230, 226);

		if(m_TimerAnimation <= 0)
		{
			m_TimerAnimation = 0;
			m_isFinish = true;
		}
		
		tempTime = m_TimerAnimation;
		second = tempTime % 60;
		tempTime = tempTime/60;
		minute = tempTime %60;
		
		secondDec = second/10;
		secondUnit = second - secondDec*10;
		TimerString = Core::String::Format("%d:%d%d",minute,secondDec,secondUnit);
		e.render->DrawString(m_parent->GetFont(), TextColor, ARGB(0, 0, 0, 0), rect, TimerString.Str(), Unit::kAlignCenterMiddle, -1);

	}
	
	void CAnimation::TurnCard()
	{
		m_turnCard = true;
		m_Timer = Task::GetTotalTime();
		m_TurnCardIsContiue = false;
	}

	void CAnimation::TrunCardContiue()
	{
		m_turnCard = true;
		m_Timer = Task::GetTotalTime();
		m_TurnCardIsContiue = true;
	}

	void CAnimation::DrawTurnCardAnimation(PaintEventArgs & e , const Core::Rectangle & rect)
	{
		tempc_ptr(FrameImage) currframe  = m_FrameList[m_currentFrame];
		tempc_ptr(FrameImage) backframe  = m_FrameList[m_currentFrame + 1];
		tempc_ptr(FrameImage) contentframe;

		if(m_FrameList.Size() >= 3)
		{
			if(m_currentFrame + 2 < m_FrameList.Size())
			{
				contentframe  = m_FrameList[m_currentFrame + 2];
			}
			else
			{
				return;
			}
		}


		Core::Rectangle drawRect;
		Vector2 ImageSize;
			
		tempc_ptr(FrameImage) Drawframe;
		Core::ARGB color = ARGB(255,255,255,255);
		F64 timer = (Task::GetTotalTime() - m_Timer)*2;
		Scalar Angle = 0;

		if(m_turnCard)
		{
			Angle = pow(timer,3);
			
			if (m_TurnCardIsContiue)
			{
				Angle += D3DX_PI;
				if(Angle >= 2*D3DX_PI)
				{
					Angle = 2*D3DX_PI;
					m_isFinish = true;
				}
			} 
			else
			{
				if(Angle >= D3DX_PI)
				{
					Angle = D3DX_PI;
					m_isFinish = true;
				}
			}
		}
	
		Quaternion qRot(Vector3(0,1,0), Angle);

		F32 Width = rect.Max.x - rect.Min.x;
		F32 Height = rect.Max.y - rect.Min.y;
		
		Vector3 Min(-Width/2, -Height/2, 0);
		Vector3 Max( Width/2,  Height/2, 0);
		Vector3 RightMost(Width/2,-Height/2, 0);

		Vector2 Center = rect.GetCenter();
		Min = Min * qRot;
		Max = Max * qRot;
		RightMost = RightMost * qRot;
		
		Min.x += Center.x; Min.y += Center.y;
		Max.x += Center.x; Max.y += Center.y;

		Vector3 L1 = RightMost - Min;
		Vector3 L2 = Max - RightMost;
		Vector3 N = Cross(L1,L2);
		N.Normalize();
		
		Vector3 L3 = gGame->camera->position - (Max - Min)/2;
		Scalar cosAngle = Dot(L3,N);

		if(cosAngle > 0)
		{
			Drawframe = currframe;
		}
		else
			Drawframe = backframe;

		if(Drawframe)
		{	
			Drawframe->m_vFrame->DrawRotation(e.render, Min, Max, color);
		}

		if(cosAngle <= 0 && contentframe)
		{
			ImageSize = contentframe->m_vFrame->GetSize();

			Core::Rectangle	ImageRect(Vector2::kZero,ImageSize);

			GetProperRect(rect,ImageRect,drawRect);

			F32 Width = drawRect.Max.x - drawRect.Min.x;
			F32 Height = drawRect.Max.y - drawRect.Min.y;

			Vector3 Min(-Width/2, -Height/2, 0);
			Vector3 Max( Width/2,  Height/2, 0);
	
			Vector2 Center = drawRect.GetCenter();

			Quaternion PI_YRot(Vector3(0,1,0), D3DX_PI);
			Min = Min * qRot * PI_YRot;
			Max = Max * qRot * PI_YRot;

			Min.x += Center.x; Min.y += Center.y;
			Max.x += Center.x; Max.y += Center.y;

			contentframe->m_vFrame->DrawRotation(e.render, Min, Max, color);
		}
	}

	void CAnimation::DrawTurnAround(PaintEventArgs & e , const Core::Rectangle & rect)
	{
		tempc_ptr(FrameImage) currframe  = m_FrameList[m_currentFrame];
		Core::ARGB color = ARGB(255,255,255,255);
		F64 timer = Task::GetTotalTime() - m_Timer;
		Scalar Angle = timer;
		
		Quaternion qRot(Vector3(0,0,1), Angle);

		F32 Width = rect.Max.x - rect.Min.x;
		F32 Height = rect.Max.y - rect.Min.y;

		Vector3 Min(-Width/2, -Height/2, 0);
		Vector3 Max( Width/2,  Height/2, 0);
		Vector3 TopRight(Width/2, -Height/2, 0);
		Vector3 bottomLeft(-Width/2, Height/2, 0);

		Vector2 Center = rect.GetCenter();
		Min = Min * qRot;
		Max = Max * qRot;
		TopRight = TopRight * qRot;
		bottomLeft = bottomLeft *qRot;

		Min.x += Center.x; Min.y += Center.y;
		Max.x += Center.x; Max.y += Center.y;
		TopRight.x += Center.x; TopRight.y += Center.y;
		bottomLeft.x += Center.x; bottomLeft.y += Center.y;

		if(currframe)
			currframe->m_vFrame->DrawRotation(e.render, Min, Max,TopRight,bottomLeft, color);
	}

	void CAnimation::DrawFlipAnimation(PaintEventArgs & e , const Core::Rectangle & rect)
	{
		Vector2 size = m_parent->GetSize();
		Vector2 ImageSize;
		Core::ARGB color = ARGB(255,255,255,255);
		Core::Rectangle drawRect;
		U32 frame1,frame2;
		int Width = size.x;
		int distance,Space;
		
		if(m_FrameList.Size() > 2)
		{
			distance = ScrollAnimation(CONSTSPEED,m_FrameList.Size());
			
			frame1 = distance / Width;
			frame2 = frame1 + 1;
			
			if(m_FrameList.Size()<55)
			{
				if(frame1+ m_FrameList.Size() == 54)
				{
					frame2 = m_stoppedFrame;
				}
				if(frame1+ m_FrameList.Size() == 55)
				{
					frame1 = m_stoppedFrame;
				}
			}
			else
			{
				if(frame1 == 54)
				{
					frame2 = m_stoppedFrame;
				}
				if(m_FrameList.Size()==55 && frame1 == 0)
				{
					frame1 = m_stoppedFrame;
				}
				else if(frame1 == 55)
				{
					frame1 = m_stoppedFrame;
				}
			}

			if(frame2 > m_FrameList.Size() - 1)
				frame2 = 0;

			//if(m_isFinish)
			//{
			//	tempc_ptr(FrameImage) currframe = m_FrameList[m_stoppedFrame];

			//	ImageSize = currframe->m_vFrame->GetSize();

			//	Core::Rectangle	ImageRect(Vector2::kZero,ImageSize);

			//	GetProperRect(rect,ImageRect,drawRect);

			//	if(currframe)
			//		currframe->m_vFrame->Draw(e.render,drawRect,color);
			//}
			//else
			//{
				tempc_ptr(FrameImage) currframe1 = m_FrameList[frame1];
				tempc_ptr(FrameImage) currframe2 = m_FrameList[frame2];

				Vector2 Min,Max;
				Min.y = rect.Min.y;
				Max.y = rect.Max.y;
				Space = distance % Width;
				Max.x = rect.Max.x + Space;
				Min.x = Max.x - Width;

				Core::Rectangle rect1(Min,Max);
				ImageSize = currframe1->m_vFrame->GetSize();

				Core::Rectangle	ImageRect(Vector2::kZero,ImageSize);

				GetProperRect(rect1,ImageRect,drawRect);

				if(currframe1)
					currframe1->m_vFrame->Draw(e.render,drawRect,color);

				Max.x = Space;
				Min.x = Max.x - Width;
				Core::Rectangle rect2(Min,Max);

				ImageSize = currframe2->m_vFrame->GetSize();

				Core::Rectangle	ImageRect2(Vector2::kZero,ImageSize);

				GetProperRect(rect2,ImageRect2,drawRect);

				if(currframe2)
					currframe2->m_vFrame->Draw(e.render,drawRect,color);


				if(Core::Task::GetTotalTime() - m_Timer > m_accTime)
					m_isFinish = true;

			//}
		}
		else if (m_FrameList.Size() == 2)
		{
			distance = ScrollAnimationTwo(CONSTSPEED,m_FrameList.Size());
			frame1 = distance / Width;
			frame2 = frame1 + 1;
			if(frame1 == 1)
			{
				frame2 = m_stoppedFrame;
			}
			tempc_ptr(FrameImage) currframe1 = m_FrameList[frame1];
			tempc_ptr(FrameImage) currframe2 = m_FrameList[frame2];
			Vector2 Min,Max;
			Min.y = rect.Min.y;
			Max.y = rect.Max.y;
			Space = distance % Width;
			Max.x = rect.Max.x + Space;
			Min.x = Max.x - Width;

			Core::Rectangle rect1(Min,Max);
			ImageSize = currframe1->m_vFrame->GetSize();

			Core::Rectangle	ImageRect(Vector2::kZero,ImageSize);

			GetProperRect(rect1,ImageRect,drawRect);

			if(currframe1)
				currframe1->m_vFrame->Draw(e.render,drawRect,color);

			Max.x = Space;
			Min.x = Max.x - Width;
			Core::Rectangle rect2(Min,Max);

			ImageSize = currframe2->m_vFrame->GetSize();

			Core::Rectangle	ImageRect2(Vector2::kZero,ImageSize);

			GetProperRect(rect2,ImageRect2,drawRect);

			if(currframe2)
				currframe2->m_vFrame->Draw(e.render,drawRect,color);
			if(Core::Task::GetTotalTime() - m_Timer > m_accTime)
				m_isFinish = true;
		}
	}	


	int CAnimation::GetNewDsiance(int A,int MaxSpeed)
	{
		int newdistance = 0;
		F64 timer = (Task::GetTotalTime() - m_Timer) ;	
		newdistance = timer * MaxSpeed;
		
		int length = m_parent->GetSize().y * 10;
		newdistance = newdistance % length;
		return newdistance;
	}

	int CAnimation::ScrollAnimation(uint StopSpeed,uint framesize)
	{
		Vector2 size = m_parent->GetSize();
		int distance,Length;
		int Width = size.x;
		Length = Width * framesize;
		F64 timer = (Task::GetTotalTime() - m_Timer) ;
		F64 A = 1600 / m_avgTime ;

		if(timer>5)
		{
			distance = ( Pow(5, 2) * A )/ 2 + A*5*(timer-5)-(Pow((timer-5), 2)*A)/2;
		}
		else
		{
			distance = ( Pow(timer, 2) * A )/ 2;
		}

		if (m_isFinish)
		{
			distance = A*5*5;
		}

		if(Length <= 0)
			return 0;
		distance = distance % Length;

		return distance;
	}

	int CAnimation::ScrollAnimationTwo(uint StopSpeed,uint framesize)
	{
		Vector2 size = m_parent->GetSize();
		int distance,Length;
		int Width = size.x;
		Length = Width * framesize;
		F64 timer = (Task::GetTotalTime() - m_Timer) ;
		F64 A = 1600 / m_avgTime ;
		distance = ( Pow(timer, 2) * A )/ 2;

		if (m_isFinish)
		{
			distance = 160;
		}

		if(Length <= 0)
			return 0;
		distance = distance % Length;

		return distance;
	}

	void CAnimation::SetScrollParam(uint score,uint bit)
	{
		m_score = score;
		m_bit = bit;
	}

	void CAnimation::DrawScrollableNum(PaintEventArgs & e , const Core::Rectangle & rect)
	{
		Core::ARGB color = ARGB(255,255,255,255);
		Vector2 size = m_parent->GetSize();

		int Height = size.y;
		int init_num = 999999;
		int distance,Space;
		int scorebits = 0; int scoreSpace = 0;
		
		U32  frame1,frame2;
		uint length = (rect.Max.x - rect.Min.x)/m_bit;
		uint temp = m_score;
		int Score[20];
		
		if(m_FrameList.Size() < 2)
			return;

		while(temp)
		{
			Score[scorebits] = temp % 10;
			temp /= 10;
			scorebits++;
		}
		
		scoreSpace = m_bit - scorebits;
		for(uint i= scorebits;i < m_bit; i++)
			Score[i] = -1;
		
		for(uint i = 0 ;i < m_bit; i++)
		{
			F32 actor = i % 2 == 1 ?1: -1;
			actor = actor * i * 20;
			m_TimeToStartDis[i] = GetNewDsiance(0,300 + actor);
		}
		distance = m_TimeToStartDis[0];

		for(uint i = m_totalstep;i < m_bit; i++)
		{
			sharedc_ptr(Gui::Image) ScoreImage = m_FrameList[m_currentFrame]->m_vFrame;
			sharedc_ptr(Gui::Image) ScoreImageSec = m_FrameList[m_currentFrame]->m_vFrame;
			int tempdistance = m_TimeToStartDis[i];
			
			Vector2 Min,Max;	
			Space = tempdistance % Height;
			Max.y = rect.Max.y + Space;
			Min.y = Max.y - Height;
			Min.x = i * length;
			Max.x = Min.x + length;

			frame1 = tempdistance / Height;
			frame2 = frame1 + 1;

			if(frame1 > 9)
				frame1 = frame1 % 9;
			else if(frame1 < 0)
				frame1 = 9;

			if(frame2 > 9)
				frame2 = frame2 % 9;
			else if(frame2 < 0)
				frame2 = 9;

			Core::Rectangle drawRect(Min, Max);

			Max.y = Space;
			Min.y = Max.y - Height;
			Core::Rectangle rect2(Min,Max);
			
			if(ScoreImage)
			{
				ScoreImage->Setuv(Vector4((frame1)/10.0 , 0, (frame1 + 1)/10.0,1 ));
				ScoreImage->Draw(e.render,drawRect,color);
			}

			if(ScoreImageSec)
			{
				ScoreImageSec->Setuv(Vector4((frame2)/10.0, 0, (frame2 + 1)/10.0,1 ));
				ScoreImageSec->Draw(e.render,rect2,color);
			}
		}

		if(Task::GetTotalTime() >= m_TimeToStopSroll + 5)
		{
			m_TimeToStopSroll += 1.0f;
			
			m_totalstep++;
		}
		
		if(m_totalstep > m_bit)
			m_totalstep = m_bit;

		if(distance > Height * 9)
			m_isFirst = false;

		
		for(uint i = 1;i <= m_totalstep; i++)
		{
			tempc_ptr(FrameImage) currframe = m_FrameList[m_currentFrame];
			tempc_ptr(FrameImage) backframe = m_FrameList[m_currentFrame + 1];
			Vector2 Min,Max;
			Min.y = rect.Min.y;
			Max.y = rect.Max.y;	
			Min.x = (i - 1) * length;
			Max.x = Min.x + length;
			Core::Rectangle drawRect(Min, Max);
			int frame = Score[m_bit - i];
		
			if(frame >= 0)
			{
				currframe->m_vFrame->Setuv(Vector4((frame)/10.0 , 0, (frame + 1)/10.0,1 ));

				if(currframe)
					currframe->m_vFrame->Draw(e.render,drawRect,color);
			}
			else
			{
				if(currframe)
				{
					currframe->m_vFrame->Setuv(Vector4(0.0f , 0, 0.1f,1 ));
					currframe->m_vFrame->Draw(e.render,drawRect,color);
				}
			}
		}
		
	}

	void CAnimation::GetProperRect(const Core::Rectangle &rect1, const Core::Rectangle &rect2, Core::Rectangle &resultRect)
	{
		F32 MoveX,MoveY;

		F32 rect1length = rect1.Max.x - rect1.Min.x;
		F32 rect1height = rect1.Max.y - rect1.Min.y;

		F32 rect2length = rect2.Max.x - rect2.Min.x;
		F32 rect2height = rect2.Max.y - rect2.Min.y;
		
		Core::Rectangle ResultRect(rect1.Min, rect1.Max);

		//����ͼƬ����

		float ratio = 0.0f;
		ratio = rect2length / rect2height;

		if(rect2length > rect1length && rect2height < rect1height)
		{
			rect1height = rect1length * (1 / ratio);
		}
		else if(rect2height > rect1height && rect2length < rect1length)
		{
			rect1length = rect1height * ratio;
		}
		else if(rect2length > rect1length && rect2height > rect1height)
		{
			if ((rect2length - rect1length) > (rect2height -  rect1height))
					rect1height = rect1length * (1 / ratio);
			else if((rect2length - rect1length) < (rect2height -  rect1height))
					rect1length = rect1height * ratio;
		}
		else if(rect2length < rect1length && rect2height < rect1height)
		{
			rect1length = rect2length;
			rect1height = rect2height;
		}
		ResultRect.Max.x = ResultRect.Min.x + rect1length;
		ResultRect.Max.y = ResultRect.Min.y + rect1height;
		
		//��������
	   rect1length = rect1.Max.x - rect1.Min.x;
	   rect1height = rect1.Max.y - rect1.Min.y;

	   rect2length = ResultRect.Max.x - ResultRect.Min.x;
	   rect2height = ResultRect.Max.y - ResultRect.Min.y;

		MoveX = (rect1length - rect2length)/2;
		MoveY = (rect1height - rect2height)/2;

		ResultRect.Move(Vector2(MoveX, MoveY));

		resultRect.Max = ResultRect.Max;
		resultRect.Min = ResultRect.Min;
	}

	void CAnimation::SetFlipTimer(float accTime,float avgTime,float decTime)
	{
		m_accTime = accTime;
		m_avgTime = avgTime;
		m_decTime = decTime;
	}
}

namespace Gui
{
	AnimControl::AnimControl()
		:m_currAnim(0)
		,m_AnimationSize(0)
		,m_start(false)
		,m_fired(false)
		,m_Animation(NullPtr)
		,m_RootAnimation(NullPtr)
		,m_usetimer(false)
	{
	}
	
	AnimControl::~AnimControl()
	{
		ClearAll();
	}
	
	PDE_ATTRIBUTE_GETTER(AnimControl, PushDown, bool)
	{
		return m_PushDown;
	}

	PDE_ATTRIBUTE_SETTER(AnimControl, PushDown, bool)
	{
		if(m_PushDown != value)
		{
			m_PushDown = value;
			OnPushDownChanged();
			Invalid();
		}
	}

	void AnimControl::OnPaint(PaintEventArgs & e)
	{	
		Super::OnPaint(e);

		if(m_start)
		{

			Core::Rectangle rect = GetBackgroundRect();

			CAnimation * currAnimation = m_RootAnimation;

			for(U32 i = 0 ;i<m_currAnim;i++)
				currAnimation = currAnimation->next;
		
			if(currAnimation)
			{
				currAnimation->StartDraw();
				currAnimation->OnPaint(e,rect);

				if(currAnimation->IsFinish())
					m_currAnim = m_currAnim + 1;

				if( m_currAnim > m_AnimationSize - 1)
					m_currAnim = m_AnimationSize - 1;

				if(m_Animation->IsFinish() && ! m_fired)
				{
					m_fired = true;
					EventFinish.Fire(ptr_static_cast<AnimControl>(this),(Client::InputEventArgs &)NullPtr);
				}

				if (m_usetimer)
				{
					if (m_time < 0)
					{
						m_usetimer = false;
						EventTimeHide.Fire(ptr_static_cast<AnimControl>(this), EventArgs());
					}
					else
					{
						m_time -= Task::GetFrameTime();
					}
				}
			}
		}
	}

	void AnimControl::TimeToHide()
	{
		m_usetimer = true;
		m_time = 0.15f;
	}

	void AnimControl::OnInputEvent(Client::InputEventArgs & e)
	{
		Super::OnInputEvent(e);
	}

	void AnimControl::OnClick(Client::InputEventArgs &e)
	{
		Super::OnClick(e);

		EventClick.Fire(ptr_static_cast<AnimControl>(this), e);
	}

	void AnimControl::AddAnim(const Core::String & value,float fTime,int type)
	{
		sharedc_ptr(CAnimation) mAnimation = ptr_new CAnimation(value,fTime,type);
		mAnimation->SetParent(this);

		m_AnimationSize = m_AnimationSize + 1;

		if( !m_Animation )
		{
			m_Animation = mAnimation;
			m_RootAnimation = m_Animation;
		}
		else
		{
			m_Animation->next = mAnimation;
			m_Animation = m_Animation->next;
		}
	}

	void AnimControl::DeleteAnimation(const Core::String & value)
	{
		sharedc_ptr(CAnimation) DeleteAnim, DeleteAnimPtr;

		if(m_RootAnimation->GetAnimationName() == value)
		{
			DeleteAnim = m_RootAnimation;

			if(m_RootAnimation->next)
			{
				m_RootAnimation = m_RootAnimation->next;
				DeleteAnim = NullPtr;
				//delete DeleteAnim;
			}
			else
			{
				m_RootAnimation = NullPtr;
				m_Animation = NullPtr;
			}
			
			m_AnimationSize = m_AnimationSize - 1;
			return;
		}
		
		DeleteAnim = m_RootAnimation;

		while(DeleteAnim)
		{
			if(DeleteAnim->next->GetAnimationName() == value)
			{
				DeleteAnimPtr = DeleteAnim->next;
				
				if(DeleteAnimPtr->next)
				   DeleteAnim->next = DeleteAnim->next->next;
				else
					DeleteAnim->next = NullPtr;

				delete DeleteAnimPtr;

				return;
			}

			DeleteAnim = DeleteAnim->next;
		}
	}

	void AnimControl::AddFrame(const Core::String & value, by_ptr(Image) frame,BOOL NeedStopped)
	{
		tempc_ptr(CAnimation) AnimPtr = GetAnimationByName(value);

		if(AnimPtr)
			AnimPtr->AddFrame(frame,NeedStopped);
	}

	void AnimControl::DeleteFrameList(const Core::String & value)
	{
		tempc_ptr(CAnimation) AnimPtr = GetAnimationByName(value);

		if(AnimPtr)
			AnimPtr->DeleteFrameList();
	}

	sharedc_ptr(CAnimation) AnimControl::GetAnimationByName(const Core::String & value)
	{
		sharedc_ptr(CAnimation) CurrAnimation = m_RootAnimation;

		while(CurrAnimation)
		{
			if( CurrAnimation->GetAnimationName() ==  value)
				return CurrAnimation;
			
			CurrAnimation = CurrAnimation->next;
		}
		
		return NullPtr;
	}

	void AnimControl::ReStart()
	{
		
		m_currAnim = 0;
		m_fired = false;
		CAnimation * currAnimation = m_RootAnimation;
		
		while(currAnimation){
			currAnimation->ReStart();
			currAnimation = currAnimation->next;
		}
	}

	void AnimControl::ClearAll()
	{
		if(m_RootAnimation)
		{
			//sharedc_ptr(CAnimation) currAnimation = m_RootAnimation;

			//while(currAnimation->next)
			//{
			//	CAnimation * PreAnimation = currAnimation;
			//	currAnimation = currAnimation->next;
			//	delete PreAnimation;
			//}

			//delete currAnimation;
			m_currAnim = 0;
			m_AnimationSize = 0;
			m_RootAnimation = NullPtr;
			m_fired = false;
			m_Animation = NullPtr;
		}
	}
	
	void AnimControl::SetAnimationTimer(const Core::String & value,float fTime)
	{
		sharedc_ptr(CAnimation) CurrAnimation = m_RootAnimation;

		while(CurrAnimation)
		{
			if( CurrAnimation->GetAnimationName() ==  value)
			{
				CurrAnimation->SetTimer(fTime);
				break;
			}

			CurrAnimation = CurrAnimation->next;
		}
	}

	void AnimControl::StartAnimation()
	{
		m_start = true;
	}

	void AnimControl::TurnCard()
	{
		sharedc_ptr(CAnimation) CurrAnimation = m_RootAnimation;

		while(CurrAnimation)
		{
			
			CurrAnimation->TurnCard();

			CurrAnimation = CurrAnimation->next;
		}
	}
	
	void AnimControl::TrunCardContiue()
	{
		sharedc_ptr(CAnimation) CurrAnimation = m_RootAnimation;

		while(CurrAnimation)
		{

			CurrAnimation->TrunCardContiue();

			CurrAnimation = CurrAnimation->next;
		}
	}

	void AnimControl::SetScrollParam(const Core::String & value,uint score,uint bit)
	{
		sharedc_ptr(CAnimation) CurrAnimation = m_RootAnimation;

		while(CurrAnimation)
		{
			if( CurrAnimation->GetAnimationName() ==  value)
			{
				CurrAnimation->SetScrollParam(score,bit);
				break;
			}

			CurrAnimation = CurrAnimation->next;
		}
	}

	bool AnimControl::isFinish()
	{
		return m_Animation->IsFinish();
	}

	void AnimControl::StopAnimation()
	{
		m_start = false;
	}

	void AnimControl::SetFlipTimer(const Core::String & value,float accTime,float avgTime,float decTime)
	{
		sharedc_ptr(CAnimation) CurrAnimation = m_RootAnimation;

		while(CurrAnimation)
		{
			if( CurrAnimation->GetAnimationName() ==  value)
			{
				CurrAnimation->SetFlipTimer(accTime, avgTime,decTime);
				break;
			}

			CurrAnimation = CurrAnimation->next;
		}
	}
}