namespace Gui
{
	class MouseControl : public Control
	{
		DECLARE_PDE_OBJECT(MouseControl, Control)	

	public:
		DECLARE_PDE_ATTRIBUTE_W(MouseType,		int);

	public:
		MouseControl();
		~MouseControl();

		// on input event as a control
		virtual void OnInputEvent(InputEventArgs & e);
	private:
	protected:
	private:
		int		m_MouseType;
	};
}