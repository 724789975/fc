#include "pch.h"

using namespace Core;
using namespace Gui;
using namespace Client;

namespace Gui
{
	ScrollBar::ScrollBar()
		: m_Minimum(0)
		, m_Maximum(0)
		, m_SmallChange(1)
		, m_LargeChange(0)
		, m_Value(0)
		, m_ActiveButton(6)
		, m_HoverButton(6)
		, m_Location(0, 0)
		, m_Size(30, 30)
		, m_ButtonSize(18)
		, m_Horizontal(false)
		, m_HVFixed(false)
		, m_Visible(true)
	{
	}

	ScrollBar::~ScrollBar()
	{
	}
}

//--------------------------------------------------------------------------------------
// Attribute
//--------------------------------------------------------------------------------------
namespace Gui
{
	PDE_ATTRIBUTE_GETTER(ScrollBar, Location, Vector2)
	{
		return m_Location;
	}

	PDE_ATTRIBUTE_SETTER(ScrollBar, Location, Vector2)
	{
		if (m_Location != value)
		{
			m_Location = value;
		}
	}

	PDE_ATTRIBUTE_GETTER(ScrollBar, Size, Vector2)
	{
		return m_Size;
	}

	PDE_ATTRIBUTE_SETTER(ScrollBar, Size, Vector2)
	{
		if (m_Size != value)
		{
			m_Size = value;
		}
	}

	PDE_ATTRIBUTE_GETTER(ScrollBar, Width, F32)
	{
		return GetHorizontal()?m_Size.y:m_Size.x;
	}


	PDE_ATTRIBUTE_SETTER(ScrollBar, Width, F32)
	{
		if(GetHorizontal())
		{
			if (m_Size.y != value)
			{
				m_Size.y = value;
			}
		}
		else
		{
			if (m_Size.x != value)
			{
				m_Size.x = value;
			}
		}
	}

	PDE_ATTRIBUTE_GETTER(ScrollBar, ButtonSize, F32)
	{
		return m_ButtonSize;
	}


	PDE_ATTRIBUTE_SETTER(ScrollBar, ButtonSize, F32)
	{
		m_ButtonSize = value;
	}

	PDE_ATTRIBUTE_GETTER(ScrollBar, Minimum, F32)
	{
		return m_Minimum;
	}


	PDE_ATTRIBUTE_SETTER(ScrollBar, Minimum, F32)
	{
		if (m_Minimum != value)
		{
			m_Minimum = value;
			if (GetValue() < m_Minimum)
				SetValue(m_Maximum);
		}
	}

	PDE_ATTRIBUTE_GETTER(ScrollBar, Maximum, F32)
	{
		return m_Maximum;
	}


	PDE_ATTRIBUTE_SETTER(ScrollBar, Maximum, F32)
	{
		if (m_Maximum != value)
		{
			m_Maximum = value;
			if (GetValue() > m_Maximum)
				SetValue(m_Maximum);
		}
	}


	PDE_ATTRIBUTE_GETTER(ScrollBar, SmallChange, F32)
	{
		return m_SmallChange;
	}


	PDE_ATTRIBUTE_SETTER(ScrollBar, SmallChange, F32)
	{
		m_SmallChange = value;
	}


	PDE_ATTRIBUTE_GETTER(ScrollBar, LargeChange, F32)
	{
		return m_LargeChange;
	}


	PDE_ATTRIBUTE_SETTER(ScrollBar, LargeChange, F32)
	{
		if (m_LargeChange != value)
		{
			m_LargeChange = value;
		}
	}


	PDE_ATTRIBUTE_GETTER(ScrollBar, Value, F32)
	{
		return m_Value;
	}


	PDE_ATTRIBUTE_SETTER(ScrollBar, Value, F32)
	{
		if (m_Value != value)
		{
			m_Value = value;
			OnValueChanged(EventArgs());
		}
	}


	PDE_ATTRIBUTE_GETTER(ScrollBar, Horizontal, bool)
	{
		return m_Horizontal;
	}

	PDE_ATTRIBUTE_SETTER(ScrollBar, Horizontal, bool)
	{
		//This setting is valid for just one time
		if(!m_HVFixed)
		{
			m_Horizontal = value;
			m_HVFixed = true;
		}
	}

	PDE_ATTRIBUTE_GETTER(ScrollBar, Valid, bool)
	{
		return GetLargeChange() > 0 && GetMinimum() < GetMaximum();
	}


	PDE_ATTRIBUTE_GETTER(ScrollBar, Visible, bool)
	{
		return m_Visible;
	}

	PDE_ATTRIBUTE_SETTER(ScrollBar, Visible, bool)
	{
		if (m_Visible != value)
		{
			m_Visible = value;
		}
	}
}


//--------------------------------------------------------------------------------------
// Event
//--------------------------------------------------------------------------------------
namespace Gui
{
	/// on paint
	void ScrollBar::OnPaint(PaintEventArgs & e, tempc_ptr(ScrollableControlSkin) scrSkin)
	{
		bool bHorizonal = GetHorizontal();

		// control offset
		F32 offset[6];
		GetControlOffset(offset);

		if(!scrSkin)
		{
			//Draw with color block

			// client rect
			Core::Rectangle rect(Vector2::kZero, GetSize());

			// control offset
			F32 offset[6];
			GetControlOffset(offset);

			bool enable = e.Enable && GetValid();

			ARGB color = enable ? ARGB(255, 255, 255) : ARGB(128, 128, 128);

			// button
			rect = GetControlRect(offset, 0);
			e.render->DrawRectangle(rect,Core::Rectangle(0,0),XRGB(255,255,0));
			if (enable)
			{
				rect = GetControlRect(offset, 2);
				e.render->DrawRectangle(rect,Core::Rectangle(0,0),XRGB(0,255,255));

			}

			rect = GetControlRect(offset, 4);
			e.render->DrawRectangle(rect,Core::Rectangle(0,0),XRGB(255,255,0));
			return;
		}

		// client rect
		Core::Rectangle rect = GetControlRect(offset, 5);

		bool enable = e.Enable && GetValid();
		//// background
		if(bHorizonal)
		{
			Skin::DrawImage(e.render, scrSkin->GetHBarBackgroundImage(), rect);
		}
		else
		{
			if(enable)
				Skin::DrawImage(e.render, scrSkin->GetVBarBackgroundImage(), rect);
			else
				Skin::DrawImage(e.render, scrSkin->GetVBarDisabledBackgroundImage(), rect);
		}

		ARGB color = enable ? ARGB(255, 255, 255) : ARGB(128, 128, 128);

		if(bHorizonal) //Horizontal
		{
			//left button
			rect = GetControlRect(offset, 0);
			if(enable)
			{
				if(m_ActiveButton == 0)
				{
					Skin::DrawImage(e.render, scrSkin->GetLeftButtonDownImage(), rect);			
				}
				else if(m_HoverButton == 0)
				{
						Skin::DrawImage(e.render, scrSkin->GetLeftButtonHoverImage(), rect);			
				}
				else
				{
						Skin::DrawImage(e.render, scrSkin->GetLeftButtonNormalImage(), rect);			
				}
			}
			else
			{
					Skin::DrawImage(e.render, scrSkin->GetLeftButtonDisabledImage(), rect);			
			}

			// slider
			rect = GetControlRect(offset, 2);
			if (enable)
			{
				if(m_ActiveButton == 2)
				{
						Skin::DrawImage(e.render, scrSkin->GetHSliderDownImage(), rect);
				}
				else if(m_HoverButton == 2)
				{
						Skin::DrawImage(e.render, scrSkin->GetHSliderHoverImage(), rect);
				}
				else
				{
						Skin::DrawImage(e.render, scrSkin->GetHSliderNormalImage(), rect);
				}
			}
			else
			{
				Skin::DrawImage(e.render, scrSkin->GetHSliderDisabledImage(), rect);
			}

			// right button
			rect = GetControlRect(offset, 4);
			if(enable)
			{
				if(m_ActiveButton == 4)
				{
					Skin::DrawImage(e.render, scrSkin->GetRightButtonDownImage(), rect);
				}
				else if(m_HoverButton == 4)
				{
					Skin::DrawImage(e.render, scrSkin->GetRightButtonHoverImage(), rect);
				}
				else
				{
					Skin::DrawImage(e.render, scrSkin->GetRightButtonNormalImage(), rect);
				}
			}
			else
			{
				Skin::DrawImage(e.render, scrSkin->GetRightButtonDisabledImage(), rect);
			}
		}
		else	//Vertical
		{
			//up button
			rect = GetControlRect(offset, 0);
			if(enable)
			{
				rect.Min += Vector2(2,1);
				
				if(m_ActiveButton == 0)
				{
						Skin::DrawImage(e.render, scrSkin->GetUpButtonDownImage(), rect);			
				}
				else if(m_HoverButton == 0)
				{
						Skin::DrawImage(e.render, scrSkin->GetUpButtonHoverImage(), rect);			
				}
				else
				{
						Skin::DrawImage(e.render, scrSkin->GetUpButtonNormalImage(), rect);			
				}
			}
			else
			{
					Skin::DrawImage(e.render, scrSkin->GetUpButtonDisabledImage(), rect);			
			}

			// slider
			rect = GetControlRect(offset, 2);
			if (enable)
			{
	//			rect.Min.x += 2;
				if(m_ActiveButton == 2)
				{
						Skin::DrawImage(e.render, scrSkin->GetVSliderDownImage(), rect);
				}
				else if(m_HoverButton == 2)
				{
						Skin::DrawImage(e.render, scrSkin->GetVSliderHoverImage(), rect);
				}
				else
				{
						Skin::DrawImage(e.render, scrSkin->GetVSliderNormalImage(), rect);
				}
			}
			else
			{
				Skin::DrawImage(e.render, scrSkin->GetVSliderDisabledImage(), rect);
			}

			// down button
			rect = GetControlRect(offset, 4);
			if(enable)
			{
				rect.Min.x += 2;
				rect.Max.y += 1;

				if(m_ActiveButton == 4)
				{
					Skin::DrawImage(e.render, scrSkin->GetDownButtonDownImage(), rect);
				}
				else if(m_HoverButton == 4)
				{
					Skin::DrawImage(e.render, scrSkin->GetDownButtonHoverImage(), rect);
				}
				else
				{
					Skin::DrawImage(e.render, scrSkin->GetDownButtonNormalImage(), rect);
				}
			}
			else
			{
				Skin::DrawImage(e.render, scrSkin->GetDownButtonDisabledImage(), rect);
			}
		}
	}


	/// on input event
	void ScrollBar::OnInputEvent(by_ptr(Control) control, InputEventArgs & e)
	{
		if (control && GetValid())
		{
			U32 old_hover = m_HoverButton;
			U32 old_active = m_ActiveButton;

			if (e.IsMouseEvent())
			{
				// control range
				F32 offset[6];
				GetControlOffset(offset);

				// cursor position
				Vector2 localPos = control->ScreenToClient(e.CursorPosition);

				// if mount is out of scrollbar's rectangle. 
				Core::Rectangle scrollbar_rect = Core::Rectangle::LeftTop(m_Location, m_Size);

				if (!scrollbar_rect.IsPointInside(localPos) || e.Type == InputEventArgs::kMouseLeave)
				{
					if (m_ActiveButton == 6)
					{
						if (m_HoverButton != 6)
						{
							m_HoverButton = 6;
							control->InvalidRect(scrollbar_rect);
						}
						return;
					}
				}

				// move pos
				F32 movePos = (GetHorizontal() ? localPos.x : localPos.y) - offset[1];

				switch (e.Type)
				{
				case InputEventArgs::kMouseDown:
				case InputEventArgs::kMouseDoubleClick:
					if (e.Code == MC_LEFT_BUTTON)
					{
						for (m_ActiveButton = 0; m_ActiveButton < 6; m_ActiveButton++)
							if (GetControlRect(offset, m_ActiveButton).IsPointInside(localPos))
								break;

						if (m_ActiveButton < 6)
						{
							control->SetCapture(true);
							m_Timer = Core::Task::GetTotalTime() + 0.2;

							F32 value = GetValue();

							switch (m_ActiveButton)
							{
							case 0:	value -= GetSmallChange(); break;
							case 1:	value -= GetLargeChange(); break;
							case 2:	m_ScrollOffset = movePos - (offset[2] - offset[1]); break;
							case 3:	value += GetLargeChange(); break;
							case 4:	value += GetSmallChange(); break;
							}
							
							if(value == movePos)
								value = movePos;

							// clamp value
							value = Clamp(value, GetMinimum(), GetMaximum());

							if (value != GetValue())
								SetValue(value);
						}

						e.Handled = true;
					}
					break;


				case InputEventArgs::kMouseMove:
					if (m_ActiveButton == 6)
					{
						//Hover
// 						for (m_HoverButton = 0; m_HoverButton < 6; m_HoverButton++)
// 							if (GetControlRect(offset, m_HoverButton).IsPointInside(localPos))
// 								break;
						U32 m_HoverButtonB = m_HoverButton;
						for (m_HoverButtonB = 0; m_HoverButtonB < 6; m_HoverButtonB++)
							if (GetControlRect(offset, m_HoverButtonB).IsPointInside(localPos))
								break;
						if(m_HoverButton!=m_HoverButtonB)
							m_HoverButton = m_HoverButtonB;
					}
					else if (m_ActiveButton == 2)
					{
						// scroll pos
						F32 range = (offset[4] - offset[1]) - (offset[3] - offset[2]);
						F32 maximum = GetMaximum();
						F32 minimum = GetMinimum();

						F32 pos = (movePos - m_ScrollOffset) / range;
						F32 value = (maximum - minimum) * pos;
						value = value - Fmod(value, GetSmallChange());

						SetValue(minimum + Clamp(value, minimum, maximum));
					}
					e.Handled = true;
					break;


				case InputEventArgs::kMouseUp:
					if (e.Code == MC_LEFT_BUTTON)
					{
						control->SetCapture(false);
						m_ActiveButton = 6;
						e.Handled = true;
					}
					break;


				case InputEventArgs::kMouseWheel:
					{
						if (m_ActiveButton == 6)
						{
							F32 value = GetValue() - GetSmallChange() * e.Value;

							// clamp value
							value = Clamp(value, GetMinimum(), GetMaximum());

							if (value != GetValue())
								SetValue(value);

							e.Handled = true;
						}
					}
					break;

				}
			}

			if (old_hover != m_HoverButton || old_active != m_ActiveButton)
			{
				control->InvalidRect(Core::Rectangle::LeftTop(m_Location, m_Size));
			}
		}
	}


	/// on update
	void ScrollBar::OnFrameUpdate(EventArgs & e)
	{
		return;
		m_ActiveButton = 6;
 		if (m_ActiveButton < 6 && m_ActiveButton != 2)
		{
			if (Core::Task::GetTotalTime() - m_Timer > 0.1)
			{
				m_Timer = Core::Task::GetTotalTime();

				F32 value = GetValue();

				switch (m_ActiveButton)
				{
				case 0:	value -= GetSmallChange(); break;
				case 1:	value -= GetLargeChange(); break;
				case 3:	value += GetLargeChange(); break;
				case 4:	value += GetSmallChange(); break;
				}

				// clamp value
				value = Clamp(value, GetMinimum(), GetMaximum());

				if (value != GetValue())
					SetValue(value);
			}
		}
	}

	/// on value changed
	void ScrollBar::OnValueChanged(EventArgs & e)
	{
		EventValueChanged.Fire(ptr_static_cast<ScrollBar>(this), e);
	}


	void ScrollBar::OnMouseEnter( InputEventArgs & e )
	{

	}

	void ScrollBar::OnMouseLeave( InputEventArgs & e )
	{
		if (m_HoverButton != 6)
		{
			m_HoverButton = 6;
			e.Handled = true;
		}
	}
}


//--------------------------------------------------------------------------------------
// Method
//--------------------------------------------------------------------------------------
namespace Gui
{
	void ScrollBar::GetControlOffset(F32 location[5])
	{
		// length
		F32 length = GetHorizontal() ? m_Size.x : m_Size.y;
		F32 start = GetHorizontal() ? m_Location.x : m_Location.y;

		// params
		F32 range = GetMaximum() - GetMinimum();
		F32 value = Clamp(GetValue() - GetMinimum(), 0, GetMaximum() - GetMinimum());

		// scroll length
		F32 scrollLength = length - m_ButtonSize * 2;
		F32 scrollPage = Max(Ceil(scrollLength * GetLargeChange() / (range + GetLargeChange())), 6.0);

		// location
		location[0] = start;
		location[5] = start + length;

		if (scrollLength > 0)
		{
			location[1] = location[0] + m_ButtonSize;
			location[2] = location[1] + Ceil((scrollLength - scrollPage) * (value / range));
			location[3] = location[2] + scrollPage;
			location[4] = location[5] - m_ButtonSize;
		}
		else
		{
			location[1] = location[2] = location[3] = location[4] = length / 2;
		}
	}

	Core::Rectangle ScrollBar::GetControlRect(F32 location[6], U32 id)
	{
		if (id < 5)
		{
			// make rect
			if (GetHorizontal())
			{
				return Core::Rectangle(Floor(location[id]), m_Location.y, Floor(location[id+1]), m_Location.y + m_Size.y);
			}
			else
			{
				return Core::Rectangle(m_Location.x, Floor(location[id]), m_Location.x + m_Size.x, Floor(location[id+1]));
			}
		}

		return Core::Rectangle(m_Location, m_Location + m_Size);
	}
}