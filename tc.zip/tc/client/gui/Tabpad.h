namespace Gui
{
	class TabpadSkin : public ControlSkin
	{
	public:
		TabpadSkin()
		{}

	public:
		INLINE_PDE_ATTRIBUTE_RW(TabNormalImage,		tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(TabHoverImage,		tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(TabActiveImage,		tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(TabNormalDisabledImage,	tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(TabActiveDisabledImage,	tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(TabBgImage,			tempc_ptr(Image));

	private:
		sharedc_ptr(Image) m_TabNormalImage;
		sharedc_ptr(Image) m_TabHoverImage;
		sharedc_ptr(Image) m_TabActiveImage;
		sharedc_ptr(Image) m_TabNormalDisabledImage;
		sharedc_ptr(Image) m_TabActiveDisabledImage;
		sharedc_ptr(Image) m_TabBgImage;
	};
}

namespace Gui
{
	class Tabpad: public Control
	{
	public:
		DECLARE_PDE_EVENT(EventSelectedPageChanged, Gui::TabChangedEventArgs);
		DECLARE_PDE_EVENT(EventRightClick, Client::InputEventArgs);
		DECLARE_PDE_ATTRIBUTE_RW(SelectedPage, sharedc_ptr(Control));
		DECLARE_PDE_ATTRIBUTE_RW(Index, int);
		DECLARE_PDE_ATTRIBUTE_RW(TabDock, DockKind);
		DECLARE_PDE_ATTRIBUTE_RW(TabSize, Core::Vector2);
		DECLARE_PDE_ATTRIBUTE_RW(TabGap, float);
		DECLARE_PDE_ATTRIBUTE_RW(TabPadding, Core::Vector4);
		DECLARE_PDE_ATTRIBUTE_RW(TabTextAlign, Client::Unit::Align);
		DECLARE_PDE_ATTRIBUTE_RW(TabLabelPadding, Core::Vector4);
		DECLARE_PDE_ATTRIBUTE_RW(TabLableAutoSize, bool);
		DECLARE_PDE_ATTRIBUTE_RW(TabLableAutoFill, bool);
		DECLARE_PDE_ATTRIBUTE_RW(ActiveTextShadow, bool);
	public:
		Tabpad();
		~Tabpad();
		virtual void OnDestroy();
		virtual void OnSelectedPageChanged(Gui::TabChangedEventArgs &e);
		virtual	void OnInputEvent(Client::InputEventArgs &e);
		virtual void OnPaint(PaintEventArgs & e);
		virtual void OnChildrenChanged(ChildrenChangedEventArgs & e);
		virtual void OnSizeChanged(ResizeEventArgs & e);
		//virtual void OnBorderSizeChanged(ReBorderSizeEventArgs & e);
		virtual void OnFrameUpdate(EventArgs & e);

	public:
		virtual void reCalculateAllSonsPosition();
		virtual void reCalculateOffset(int tempint);
		virtual void SelectPage(sharedc_ptr(Control) son, bool byMouse = false);
		virtual void SelectPageByIndex(int index, bool byMouse = false);
		virtual void SelectFirstPage();
		virtual void SelectLastPage();
		virtual int GetSonCount();
		virtual int GetSonIndex(tempc_ptr(Control) son);
		virtual Core::Vector2 GetTabClientPosi();
		virtual Core::Vector2 GetTabClientSize();
		virtual Core::Rectangle GetTabLableRect(int i);
		virtual Core::Vector2 GetTabLableScreentPos(int index);

	private:
		virtual bool ClickOrHoverEffect(bool flag, Core::Vector2 mouseLocalPos);
		virtual void HoveredPage(sharedc_ptr(Control) son, int index);
		virtual void DragTabsEffect(Core::Vector2 moved);
		virtual void PaintTabLables(PaintEventArgs & e);
		virtual void PaintTabBody(PaintEventArgs & e);
		//virtual Core::Rectangle GetTabLableRect(int i);
		virtual Core::Rectangle GetIntRect(Core::Rectangle fRect);
		virtual Core::Rectangle GetTabHeadRect();
		virtual int CalculateStringWidth(Core::String str);
		virtual void reCalculateTabHeadLength();
		virtual int SumStringLength(int i);
		virtual void OnTabRightClick(InputEventArgs & e);

	protected:
		sharedc_ptr(Control)		m_SelectedPage;
		sharedc_ptr(Control)		m_HoverPage;
		int						m_sonCount;
		int						m_Index;

	private:
		float					tabLableWidth;
		float					tabLableHeight;
		float					m_tabGap;

		float					tabLableLocationOffset;
		float					tabLableLocationAimOffset;
		float					pre_tabLableLocationOffset;

		DockKind				m_tabDock;

		float					m_ShowNextPreLableLength;
		float					m_TabHeadLength;
		float                   m_TabHeadHeight;
		Core::Vector4			m_TabPadding;
		Core::Vector4			m_TabLabelPadding;
		Client::Unit::Align		m_TabTextAlign;
		bool					m_TabLableAutoSize;
		bool					m_TabLableAutoFill;
		bool					m_ActiveTextShadow;

		bool					m_patch_flag_dont_fireEvent;
	};
}