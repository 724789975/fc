namespace Gui
{
	class WebSkin : public ControlSkin
	{

	};

	class WebControl: public Control
	{
		DECLARE_PDE_OBJECT(WebControl, Control);
	public:
		WebControl();
		~WebControl();

		void OnPaint(PaintEventArgs & e);

		void OnInputEvent(InputEventArgs & e);

		void OnLocationChanged(MoveEventArgs & e);

		void OnSizeChanged(ResizeEventArgs & e);

		void OnFocusChanged(EventArgs & e);

		void CalcWorldLocation();
		
		void CleanData();

	private:
		sharedc_ptr(Client::WebPlayer) web_player;

		Core::Vector2 world_pos;
	};
}