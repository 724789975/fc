#include "pch.h"

using namespace Core;
using namespace Client;
using namespace Gui;


DEFINE_PDE_TYPE_CLASS(AttributePlate)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Control);
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_PROPERTY_RW(Count);
		ADD_PDE_PROPERTY_RW(MaxValue);
		ADD_PDE_PROPERTY_RW(NameWidth);
		ADD_PDE_PROPERTY_RW(TipTextColor);
		ADD_PDE_PROPERTY_RW(OutsideLineColor);
		ADD_PDE_PROPERTY_RW(InsideLineColor);
		ADD_PDE_PROPERTY_RW(OutsidePolygonColor);
		ADD_PDE_PROPERTY_RW(InsidePolygonColor);

		ADD_PDE_METHOD(AddAttribute);
		ADD_PDE_METHOD(Clear);
	}
};


REGISTER_PDE_TYPE(AttributePlate);


namespace Gui
{
	AttributePlate::AttributePlate()
		: m_Count(8)
		, m_MaxValue(100)
		, m_NameWidth(40)
		, m_PointedVertex(-1)
		, m_TipTextColor(255,0,0,0)
		, m_OutsideLineColor(255,255,255,255)
		, m_InsideLineColor(255,255,255,255)
		, m_OutsidePolygonColor(255,128,128,128)
		, m_InsidePolygonColor(255,0,255,0)
	{

	}
	AttributePlate::~AttributePlate()
	{

	}

	PDE_ATTRIBUTE_GETTER(AttributePlate, Count, U32)
	{
		return m_Count;
	}

	PDE_ATTRIBUTE_SETTER(AttributePlate, Count, U32)
	{
		if (m_Count != value)
		{
			m_Count = value;
			m_aAttributes.Clear();
			DirtyLayout();
		}
	}

	PDE_ATTRIBUTE_GETTER(AttributePlate, MaxValue, U32)
	{
		return m_MaxValue;
	}

	PDE_ATTRIBUTE_SETTER(AttributePlate, MaxValue, U32)
	{
		if (m_MaxValue != value)
		{
			m_MaxValue = value;
			m_aAttributes.Clear();
			DirtyLayout();
		}
	}


	PDE_ATTRIBUTE_GETTER(AttributePlate, NameWidth, F32)
	{
		return m_NameWidth;
	}

	PDE_ATTRIBUTE_SETTER(AttributePlate, NameWidth, F32)
	{
		if (m_NameWidth != value)
		{
			m_NameWidth = value;
			DirtyLayout();
		}
	}

	PDE_ATTRIBUTE_GETTER(AttributePlate, TipTextColor, ARGB)
	{
		return m_TipTextColor;
	}

	PDE_ATTRIBUTE_SETTER(AttributePlate, TipTextColor, ARGB)
	{
		if (m_TipTextColor != value)
		{
			m_TipTextColor = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(AttributePlate, OutsideLineColor, ARGB)
	{
		return m_OutsideLineColor;
	}

	PDE_ATTRIBUTE_SETTER(AttributePlate, OutsideLineColor, ARGB)
	{
		if (m_OutsideLineColor != value)
		{
			m_OutsideLineColor = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(AttributePlate, InsideLineColor, ARGB)
	{
		return m_InsideLineColor;
	}

	PDE_ATTRIBUTE_SETTER(AttributePlate, InsideLineColor, ARGB)
	{
		if (m_InsideLineColor != value)
		{
			m_InsideLineColor = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(AttributePlate, OutsidePolygonColor, ARGB)
	{
		return m_OutsidePolygonColor;
	}

	PDE_ATTRIBUTE_SETTER(AttributePlate, OutsidePolygonColor, ARGB)
	{
		if (m_OutsidePolygonColor != value)
		{
			m_OutsidePolygonColor = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(AttributePlate, InsidePolygonColor, ARGB)
	{
		return m_InsidePolygonColor;
	}

	PDE_ATTRIBUTE_SETTER(AttributePlate, InsidePolygonColor, ARGB)
	{
		if (m_InsidePolygonColor != value)
		{
			m_InsidePolygonColor = value;
			Invalid();
		}
	}


	void AttributePlate::OnPaint(PaintEventArgs& e)
	{
		Control::OnPaint(e);

		Core::Rectangle rect(GetDisplayRect());
		F32 angle = 2.0f*Core::PI/m_Count;

		Vector2 center = GetDisplayRect().GetCenter();

		e.render->BeginTriangleList(0);

		for (U32 i = 0;i < m_Count - 1;i++)
		{
			e.render->VertexColor(m_OutsidePolygonColor);
			e.render->Vertex2f(m_aOutsideVertexs.GetAt(i).x,m_aOutsideVertexs.GetAt(i).y);
			e.render->Vertex2f(center.x,center.y);
			e.render->Vertex2f(m_aOutsideVertexs.GetAt(i + 1).x,m_aOutsideVertexs.GetAt(i + 1).y);

			e.render->VertexColor(m_InsidePolygonColor);
			e.render->Vertex2f(m_aInsideVertexs.GetAt(i).x,m_aInsideVertexs.GetAt(i).y);
			e.render->Vertex2f(center.x,center.y);
			e.render->Vertex2f(m_aInsideVertexs.GetAt(i + 1).x,m_aInsideVertexs.GetAt(i + 1).y);
		}

		e.render->VertexColor(m_OutsidePolygonColor);
		e.render->Vertex2f(m_aOutsideVertexs.Back().x,m_aOutsideVertexs.Back().y);
		e.render->Vertex2f(center.x,center.y);
		e.render->Vertex2f(m_aOutsideVertexs.Front().x,m_aOutsideVertexs.Front().y);

		e.render->VertexColor(m_InsidePolygonColor);
		e.render->Vertex2f(m_aInsideVertexs.Back().x,m_aInsideVertexs.Back().y);
		e.render->Vertex2f(center.x,center.y);
		e.render->Vertex2f(m_aInsideVertexs.Front().x,m_aInsideVertexs.Front().y);

		e.render->End();

		e.render->BeginLineList(0);

		for (U32 i = 0;i < m_aOutsideVertexs.Size() - 1;i++)
		{
			e.render->VertexColor(m_OutsideLineColor);
			e.render->Vertex2f(m_aOutsideVertexs.GetAt(i).x,m_aOutsideVertexs.GetAt(i).y);
			e.render->Vertex2f(m_aOutsideVertexs.GetAt(i + 1).x,m_aOutsideVertexs.GetAt(i + 1).y);
			e.render->VertexColor(m_InsideLineColor);
			e.render->Vertex2f(m_aOutsideVertexs.GetAt(i).x,m_aOutsideVertexs.GetAt(i).y);
			e.render->Vertex2f(center.x,center.y);
		}

		e.render->VertexColor(m_OutsideLineColor);
		e.render->Vertex2f(m_aOutsideVertexs.Back().x,m_aOutsideVertexs.Back().y);
		e.render->Vertex2f(m_aOutsideVertexs.Front().x,m_aOutsideVertexs.Front().y);
		e.render->VertexColor(m_InsideLineColor);
		e.render->Vertex2f(m_aOutsideVertexs.Back().x,m_aOutsideVertexs.Back().y);
		e.render->Vertex2f(center.x,center.y);

		e.render->End();

		for (U32 i = 0;i < m_aAttributes.Size();i++)
		{
			Vector2 strPos  = Vector2(static_cast<S32>(m_aOutsideVertexs.GetAt(i).x),static_cast<S32>(m_aOutsideVertexs.GetAt(i).y));
			e.render->DrawString(GetFont(),m_TextColor,ARGB(0,0,0,0),Core::Rectangle::LeftTop(strPos,Vector2::kZero),m_aAttributes.GetAt(i).Name,m_aAttributes.GetAt(i).Align);

		}

		if (m_PointedVertex > -1 && m_PointedVertex < static_cast<S32>(m_aAttributes.Size()))
		{
			CStrBuf<256> str;
			str.format("%.0f",m_aAttributes.GetAt(m_PointedVertex).Size);
			Vector2 strPos  = Vector2(static_cast<S32>(m_aInsideVertexs.GetAt(m_PointedVertex).x),static_cast<S32>(m_aInsideVertexs.GetAt(m_PointedVertex).y));
			e.render->DrawString(GetFont(),m_TipTextColor,ARGB(0,0,0,0),Core::Rectangle::LeftTop(strPos,Vector2::kZero),str,Unit::kAlignCenterMiddle);

		}
	}

	void AttributePlate::OnInputEvent(InputEventArgs & e)
	{
		if (e.IsMouseEvent())
		{
			Core::Vector2 localPos = ScreenToClient(e.CursorPosition);
			switch (e.Type)
			{
			case InputEventArgs::kMouseMove:
				for (U32 i = 0;i < m_Count;i++)
				{
					if (Abs(localPos - m_aInsideVertexs.GetAt(i)) < Vector2(3,3))
					{
						m_PointedVertex  = i;
						break;
					}
					else
					{
						m_PointedVertex = -1;
					}
				}
				e.Handled = true;
				break;
			}
		}
		if (!e.Handled)
			Super::OnInputEvent(e);
	}
	void AttributePlate::OnLayout(EventArgs & e)
	{
		SetBackgroundColor(ARGB(0,0,0,0));
		SetTextColor(ARGB(255,0,255,0));
		m_aOutsideVertexs.Clear();
		m_aInsideVertexs.Clear();

		F32 angle = -2.f*PI/m_Count;
		Vector2 size(GetDisplayRect().GetExtent());
		Vector2 center(GetDisplayRect().GetCenter());
		F32 R = Min(size.x*.5f,size.y*.5f) - m_NameWidth;
		F32 r = 0.f;

		U32 count = m_aAttributes.Size();
		for (U32 i = 0;i < m_Count;i++)
		{
			r = i < count?R*(m_aAttributes.GetAt(i).Size)/m_MaxValue:R; 

			m_aOutsideVertexs.PushBack(Vector2(R*Cos(i*angle),R*Sin(i*angle)) + center);
			m_aInsideVertexs.PushBack(Vector2(r*Cos(i*angle),r*Sin(i*angle)) + center);
		}
	}

	void AttributePlate::AddAttribute(const Core::String& attributeName,Client::Unit::Align attributeNameAlign,const F32 attributeSize)
	{
		if (m_aAttributes.Size() < m_Count && attributeSize <= m_MaxValue)
		{
			m_aAttributes.PushBack(Attribute(attributeName,attributeNameAlign,attributeSize));
			DirtyLayout();
		}
	}

	void AttributePlate::Clear()
	{
		m_aAttributes.Clear();
		DirtyLayout();
	}
}