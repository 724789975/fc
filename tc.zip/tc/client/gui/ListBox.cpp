#include "pch.h"

using namespace Core;
using namespace Gui;
using namespace Client;

#include "ListBox.h"
//--------------------------------------------------------------------------------------
// Register
//--------------------------------------------------------------------------------------
DEFINE_PDE_TYPE_CLASS(Gui::ListBoxSkin)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::ScrollableControlSkin);
		ADD_PDE_DEFAULT_CONSTRUCTOR();
	}
};

DEFINE_PDE_TYPE_CLASS(Gui::ListBox)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::Control);
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_EVENT(EventListClick);
		ADD_PDE_EVENT(EventSelectChange);
		ADD_PDE_EVENT(EventDelete);
		ADD_PDE_EVENT(EventItemChange);

		ADD_PDE_PROPERTY_RW(SelectIndex);
		ADD_PDE_PROPERTY_R (ItemCount);

		ADD_PDE_METHOD(AddItem);
		ADD_PDE_METHOD(DeleteItem);
		ADD_PDE_METHOD(DeleteAll);
		ADD_PDE_METHOD(DeleteSelectItem);
		ADD_PDE_METHOD(GetItemText);
		ADD_PDE_METHOD(SetItemText);
		ADD_PDE_METHOD(SetSelect);
		ADD_PDE_METHOD(IsSelect);
		ADD_PDE_METHOD(ToggleSelect);

	}
};

REGISTER_PDE_TYPE(Gui::ListBoxSkin);
REGISTER_PDE_TYPE(Gui::ListBox);


// Implementations
namespace Gui
{
	ListBox::ListBox()
		: m_SelectIndex(INDEX_NONE)
		, m_ItemCount(0)
		, m_LastIndex(0)
		, m_BorderVisible(false)
		, m_MultiSelect(false)
		, m_Selecting(false)
	{
		//SetBorderStyle(BorderStyle::kOutset);
		SetBackgroundColor(ARGB(255, 255, 255));
	}

	ListBox::~ListBox()
	{
		//m_aItems.Clear();
	}
}


//--------------------------------------------------------------------------------------
// Attribute
//--------------------------------------------------------------------------------------
namespace Gui
{
	PDE_ATTRIBUTE_GETTER(ListBox, SelectIndex, S32)
	{
		return m_SelectIndex;
	}


	PDE_ATTRIBUTE_SETTER(ListBox, SelectIndex, S32)
	{
		if (m_SelectIndex != value && value < (S32)m_ItemCount)
		{
			if (value < 0)
			{
				m_SelectIndex = INDEX_NONE;
			}
			else
			{
				m_SelectIndex = value;
			}
			EventArgs e;
			OnItemSelectedChanged(e);
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(ListBox, ItemCount, U32)
	{
		return m_ItemCount;
	}

	PDE_ATTRIBUTE_GETTER(ListBox, BorderVisible, bool)
	{
		return m_BorderVisible;
	}

	PDE_ATTRIBUTE_SETTER(ListBox, BorderVisible, bool)
	{
		if (m_BorderVisible != value)
		{
			m_BorderVisible = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(ListBox, DisplayPadding, Vector4)
	{
		return Super::GetDisplayPadding();
	}
}


//--------------------------------------------------------------------------------------
// Event
//--------------------------------------------------------------------------------------
namespace Gui
{
	static const F32 ITEM_HEIGHT = 16;

	void ListBox::OnCreate()
	{
		Super::OnCreate();
		SetAutoScroll(true);
	}

	void ListBox::OnFrameUpdate(EventArgs & e)
	{
		Super::OnFrameUpdate(e);
	}

	void ListBox::OnLayout(EventArgs & e)
	{
		Super::OnLayout(e);
	}
#if 0
	void ListBox::OnPaintClient(PaintEventArgs & e)
	{

		Super::OnPaintClient(e);

		if (GetAutoScroll())
		{
			Vector2 autoSize(GetDisplayWidth() + 4, (ITEM_HEIGHT * m_ItemCount));
			SetAutoScrollMinSize(autoSize);
			m_VScrollBar->SetSmallChange(ITEM_HEIGHT);
		}

		EdtUISkin & skin = *GUISystem->Skin;
		F32 width = Max(GetSize().x, GetDisplayWidth() + 4);

		U32 index = 0;

		for (U32 i = 0; i<GetItemCount(); ++i)
		{
			bool selected = IsSelect(i);

			if (selected)
			{
				Core::Rectangle selectRect(Vector2(0, ITEM_HEIGHT * index), Vector2(width, ITEM_HEIGHT * (index + 1)));

				skin.FillRect(selectRect, XRGB(49,106,197));
			}

			Core::Rectangle textRect = Core::Rectangle::LeftTop(Vector2(4, ITEM_HEIGHT * index), Vector2(width - 4, ITEM_HEIGHT));

			skin.DrawString(selected? XRGB(255,255,255): GetTextColor(), textRect, m_aItems[i].Name, -1, GsUnit::kAlignLeftMiddle);

			++index;
		}

	}
#endif	
	void ListBox::OnPaint(PaintEventArgs & e)
	{
		Super::OnPaint(e);

		if (GetAutoScroll())
		{
			Vector2 autoSize(GetDisplayWidth() + 4, (ITEM_HEIGHT * m_ItemCount));
			SetAutoScrollMinSize(autoSize);
			m_VScrollBar->SetSmallChange(ITEM_HEIGHT);
		}


		//EdtUISkin & skin = *GUISystem->Skin;
		F32 width = Max(GetSize().x, GetDisplayWidth() + 4);

		U32 index = 0;

		for (U32 i = 0; i<GetItemCount(); ++i)
		{
			bool selected = IsSelect(i);

			if (selected)
			{
				Core::Rectangle selectRect(Vector2(0, ITEM_HEIGHT * index), Vector2(width, ITEM_HEIGHT * (index + 1)));

				//skin.FillRect(selectRect, XRGB(49,106,197));

				e.render->DrawRectangle(selectRect,selectRect,ARGB(200,255,197,0));
			}

			Core::Rectangle textRect = Core::Rectangle::LeftTop(Vector2(4, ITEM_HEIGHT * index), Vector2(width - 4, ITEM_HEIGHT));

			//skin.DrawString(selected? XRGB(255,255,255): GetTextColor(), textRect, m_aItems[i].Name, -1, GsUnit::kAlignLeftMiddle);

			e.render->DrawString(
				GetFont(), 
				GetTextColor(), 
				ARGB(0,255,255,255),//GetBackgroundColor(), 
				textRect, 
				m_aItems[i].Name, 
				Unit::kAlignLeftMiddle);
			
			++index;
		}
	}

	void ListBox::OnInputEvent(Client::InputEventArgs & e)
	{
#if 1
		if (e.IsMouseEvent())
		{
			Vector2 localPos = ScreenToClient(e.CursorPosition);

			bool pointed = GetDisplayRect().IsPointInside(localPos);

			switch(e.Type)
			{
			case Client::InputEventArgs::kMouseDown:
				{
					if (e.Code == MC_LEFT_BUTTON && !m_Selecting && pointed)
					{
						SetCapture(true);

						U32 item = localPos.y / ITEM_HEIGHT;

						if (e.ShiftKeyDown && m_MultiSelect)
						{
							U32 uMin  = Min(m_LastIndex, item);
							U32 uMax  = Max(m_LastIndex, item);

							if (IsSelect(m_LastIndex))
							{
								ReleaseAllSelect();
								SetSelect(m_LastIndex);
							}
							else
							{
								ReleaseAllSelect();
							}

							SetSelect(item);
							
							for (U32 i=uMin+1; i<uMax; ++i)
							{
								SetSelect(i);
							}
						}
						else if (e.ControlKeyDown && m_MultiSelect)
						{
							ToggleSelect(item);
						}
						else
						{
							ReleaseAllSelect();

							m_SelectRect.Min = m_SelectRect.Max = localPos;
							m_Selecting = true;

							ToggleSelect(item);
						}

						Invalid();
						OnListClick(e);
						e.Handled = true;
					}
				}
				break;

			case Client::InputEventArgs::kMouseUp:
				{
					if (e.Code == MC_LEFT_BUTTON)
					{
						SetCapture(false);
						m_Selecting = false;
						e.Handled = true;
					}
				}
				break;

			case Client::InputEventArgs::kMouseMove:
				{
					if (m_MultiSelect && m_Selecting)
					{
						U32 item = localPos.y / ITEM_HEIGHT;

						if (0 <= item && item < GetItemCount())
						{
							ScrollToView(Core::Rectangle::LeftTop(Vector2(0, ITEM_HEIGHT * item), Vector2(GetDisplayRect().Max.x, ITEM_HEIGHT)));

							Core::Rectangle rect;
							m_SelectRect.Max = localPos;
							rect.Min = Min(m_SelectRect.Min, m_SelectRect.Max);
							rect.Max = Max(m_SelectRect.Min, m_SelectRect.Max);

							if (GetDisplayRect().IntersectWith(rect))
							{
								U32 uMin  = rect.Min.y / ITEM_HEIGHT;
								U32 uMax  = rect.Max.y / ITEM_HEIGHT;

								ReleaseAllSelect();

								for (U32 i=uMin; i<=uMax; ++i)
								{
									SetSelect(i);
								}

								m_LastIndex = m_SelectRect.Min.y / ITEM_HEIGHT;
							}

							Invalid();
						}
						e.Handled = true;
					}
				}
				break;
			}

		}

		if (!e.Handled)
			Super::OnInputEvent(e);
#endif
	}

	/// on click
	void ListBox::OnListClick(Client::InputEventArgs & e)
	{
		EventListClick.Fire(ptr_static_cast<ListBox>(this), e);
	}

	void ListBox::OnItemSelectedChanged(EventArgs & e)
	{
		EventSelectChange.Fire(ptr_static_cast<ListBox>(this), e);
	}

	void ListBox::OnDelete(Client::InputEventArgs & e)
	{
		EventDelete.Fire(ptr_static_cast<ListBox>(this), e);
	}

	void ListBox::OnItemChange(EventArgs & e)
	{
		ItemChange();
		EventItemChange.Fire(ptr_static_cast<ListBox>(this), e);
	}

}

//--------------------------------------------------------------------------------------
// Method
//--------------------------------------------------------------------------------------
namespace Gui
{
	void ListBox::ItemChange()
	{
		Invalid();
	}

	void ListBox::ToggleSelect(U32 index)
	{
		if (IsSelect(index))
			SetSelect(index, false);
		else
			SetSelect(index);

		m_LastIndex = index;
	}

	bool ListBox::IsSelect(U32 index)
	{
		if ( index < 0 || index >= GetItemCount())
		{
			return false;
		}

		return m_aItems[index].IsSelect;
	}

	void ListBox::SetSelect(U32 index, bool flag)
	{
		if ( index >= 0 && index < GetItemCount())
		{
			m_aItems[index].IsSelect = flag;
			SetSelectIndex(index);
		}
		else
		{
			SetSelectIndex(INDEX_NONE);
		}
	}

	void ListBox::ReleaseAllSelect()
	{
		for (U32 i = 0; i< GetItemCount(); ++i)
		{
			SetSelect(i, false);
		}
	}

	void ListBox::AddItem(const Core::String & item)
	{
		++m_ItemCount;
		m_aItems.PushBack(item);

		EventArgs e;
		OnItemChange(e);
	}

	void ListBox::DeleteItem(U32 index)
	{
		if ( index >= 0 && index < GetItemCount())
		{
			m_aItems.RemoveAt(index);

			EventArgs e;
			OnItemChange(e);
		}
	}

	void ListBox::DeleteAll()
	{
		m_ItemCount = 0;
		m_aItems.Clear();
		Invalid();

		EventArgs e;
		OnItemChange(e);
	}

	void ListBox::DeleteSelectItem()
	{
		U32 count = 0;
		bool flag = false;

		for (U32 i = 0; i < GetItemCount(); ++i)
		{
			if (IsSelect(i))
			{
				++count;
				flag = true;
			}
			else if (flag)
			{
				m_aItems.RemoveRange(i - count, count);

				count = 0;
				flag = false;

			}
		}

		EventArgs e;
		OnItemSelectedChanged(e);
	}

	String ListBox::GetItemText(U32 index)
	{
		if (index >= 0 && index < GetItemCount())
		{
			return m_aItems[index].Name;
		}

		return String::kEmpty;
	}

	void ListBox::SetItemText(U32 index, const String & text)
	{
		if ( index >= 0 && index < GetItemCount())
		{
			if (m_aItems[index].Name != text)
			{
				m_aItems[index].Name = text;
				Invalid();
			}
		}
	}

	F32 ListBox::GetDisplayWidth()
	{
		F32 width = 0;
#if 0
		EdtUISkin & skin = *GUISystem->Skin;
		HGsXResFont hFont =skin.GetDefaultFont();

		if (hFont.IsReady())
		{
			for (U32 i = 0; i < GetItemCount(); ++i)
			{
				Vector2 size = skin.MeasureIconText(hFont, PdeHandle::kNull, m_aItems[i].Name);
				width = Max(size.x, width);
			}
		}
#endif


#if 1
		if (1)
		{
			for (U32 i = 0; i < GetItemCount(); ++i)
			{
				/// measure string
				//Core::Rectangle MeasureString(const Core::Rectangle &dst, const char* text, U32 length = -1, U32 format = 0);
				Core::Rectangle rect;
				rect = GetFont()->MeasureString(rect, m_aItems[i].Name);
				F32 x = rect.Max.x-rect.Min.x;
				width = Max(x, width);
			}
		}

#endif


		return width;
	}
}


