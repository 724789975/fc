namespace Gui
{
	struct  Transition
	{
		Core::Vector2	m_MovePosition;
		Core::Vector2	m_size;
		F64				m_Timer;
		Core::ARGB		m_BackgroundColor;
		Transition()
			: m_MovePosition(Core::Vector2(0,0))
			, m_size(Core::Vector2(0,0))
			, m_Timer(0.0f)
			, m_BackgroundColor(255,255,255,255)
		{
		}
	};
	class ChangeControl : public Control
	{
		DECLARE_PDE_OBJECT(ChangeControl, Control)
	public:
		DECLARE_PDE_EVENT(EventPlayEnd, Client::InputEventArgs);
		DECLARE_PDE_EVENT(EventPlayNextPoint, Client::InputEventArgs);
	public:
		DECLARE_PDE_ATTRIBUTE_RW(NormLocation,		Core::Vector2);
		DECLARE_PDE_ATTRIBUTE_RW(Normsize,			Core::Vector2);
		DECLARE_PDE_ATTRIBUTE_RW(NormBackgroundColor,	Core::ARGB);
		DECLARE_PDE_EVENT(EventToolTipsShow,		Core::EventArgs);
	public:
		ChangeControl();
		~ChangeControl();

		void OnFrameUpdate( EventArgs & e );
		
		void SetSize_Picture();
		void SetSize_Picture_side();
		void InsertMovePoint(Core::Vector2 moveposition,F64 time,Core::Vector2 size,Core::ARGB color = Core::ARGB(255,255,255,255));
		void Clear();
		void ReState();

		virtual void OnMouseEnter(InputEventArgs & e);

		virtual void OnMouseLeave(InputEventArgs & e);
	private:
		void OnValidate();
		void OnUpdateChangeControl();
		void SetNewPosition(F64 n);
		void SetNewSize(F64 n);
		void SetNewBackgroundColor(F64 n);
		Core::Vector2 GetWhichLocation();
		Core::Vector2 GetWhichLocationChange();
		Core::Vector2 GetWhichSize();
		Core::Vector2 GetWhichSizeChange();
		Core::ARGB GetWhichBackgroundColor();
		Core::ARGB GetWhichBackgroundColorChange();
	protected:
	private:
		Core::Array<Transition>		m_MovePoint;
		int							m_which;
		F64							m_Totale_timer;
		Core::Vector2				m_Normsize;
		Core::Vector2				m_NormLocation;
		float						m_tooltipStartshow;
		Core::ARGB					m_NormBackgroundColor;
	};
}