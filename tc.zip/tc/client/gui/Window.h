namespace Gui
{
	class Window : public Control	
	{
	public:
		friend class GuiSystem;
		DECLARE_PDE_OBJECT(Window, Control);
	public:
		enum SurfaceType
		{
			kPlane = 0,
			kCylinder,
			kNone
		};
	public:
		OVERRIDE_PDE_ATTRIBUTE_W (Size,			Core::Vector2);
		OVERRIDE_PDE_ATTRIBUTE_RW(Location,		Core::Vector2);
		OVERRIDE_PDE_ATTRIBUTE_W(Visible,		bool);

		DECLARE_PDE_ATTRIBUTE_RW (ContentSize,	Core::Vector2);

		DECLARE_PDE_ATTRIBUTE_RW(SurfaceType,	SurfaceType);
		DECLARE_PDE_ATTRIBUTE_RW(WorldLocation,	Core::Vector3);
		DECLARE_PDE_ATTRIBUTE_RW(WorldRotation,	Core::Vector3);

		DECLARE_PDE_ATTRIBUTE_RW(Opacity,		F32);
		DECLARE_PDE_ATTRIBUTE_RW(Moveable,		bool);

		DECLARE_PDE_ATTRIBUTE_R(DefaultSize,	Core::Vector2) { return Core::Vector2(0, 0); }
		DECLARE_PDE_ATTRIBUTE_R(MinimumSize,	Core::Vector2) { return Core::Vector2(16, 16); }
	public:
		// constructor.
		Window();

		// destructor.
		~Window();

		// on paint
		void OnPaint(PaintEventArgs & e);

		// process input
		void OnInputEvent(Client::InputEventArgs & e);

		// render
		virtual void Render(RenderEventArgs & e);

		virtual bool GetVisibility();

		//screen to local
		Core::Vector2 ScreenToClient(const Core::Vector2 & pos);

		// local to screen
		Core::Vector2 ClientToScreen(const Core::Vector2 & pos);
		

	public:
		IDirect3DTexture9 * GetTexture() { return static_cast<IDirect3DTexture9*>(m_Texture->GetTexture()); }

	public:
		// on window input
		void OnWindowInput(Client::InputEventArgs & e);

		// change parent of this control.
		void ChangeParent(by_ptr(Control) parent, by_ptr(Control) insertBefore, bool parentNeedRearrangeChildren = true);

	protected:
		bool				m_showGlowRay;
		Core::Vector2		m_GlowOffset;
	private:
		Core::Vector3		m_worldLocation;
		Core::Vector3		m_worldRotation;
		Core::Bool			m_Moveable;
		F32					m_Opacity;


		Client::InputCode	m_MouseButton;

		sharedc_ptr(Client::TextureBase)	m_Texture;

		SurfaceType			m_SurfaceType;
	};
}