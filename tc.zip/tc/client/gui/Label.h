namespace Gui
{
	/// base class of ui elements
	class  Label : public Control
	{
		DECLARE_PDE_OBJECT(Label, Control)

	public:
		DECLARE_PDE_EVENT(EventClick, InputEventArgs);
		DECLARE_PDE_EVENT(EventClose, InputEventArgs);

	public:
		DECLARE_PDE_ATTRIBUTE_RW	(Icon,			tempc_ptr(Icon));
		DECLARE_PDE_ATTRIBUTE_RW	(TextAlign,		Client::Unit::Align);
		DECLARE_PDE_ATTRIBUTE_RW	(AutoWrap,		bool);
		DECLARE_PDE_ATTRIBUTE_RW	(AutoFontSize,	bool);
		DECLARE_PDE_ATTRIBUTE_RW	(AutoEllipsis,	bool);
		DECLARE_PDE_ATTRIBUTE_RW	(UseTimer,		bool);
		DECLARE_PDE_ATTRIBUTE_RW	(TextPadding,	Core::Vector4);
		DECLARE_PDE_ATTRIBUTE_RW	(MoveLocation,	Core::Vector2);
		DECLARE_PDE_ATTRIBUTE_RW	(DisplayTime,	F32);
		DECLARE_PDE_ATTRIBUTE_RW	(MoveWheelTime,	F64);
		DECLARE_PDE_ATTRIBUTE_RW	(NormLocation,	Core::Vector2);
		OVERRIDE_PDE_ATTRIBUTE_R	(DefaultSize,	Core::Vector2) { return Core::Vector2(50, 18); }

	public:
		///constructor
		Label();

		///destructor
		~Label();

		/// on autosize
		virtual void OnAutoSize(AutoSizeEventArgs & e);

		// on size changed
		virtual void OnSizeChanged(ResizeEventArgs & e);

		/// on text changed
		virtual void OnTextChanged(EventArgs & e);

		/// on paint
		virtual void OnPaint(PaintEventArgs & e);

		/// on input event
		virtual void OnInputEvent(InputEventArgs & e);

		virtual void Show();

		virtual void Close();

	protected:
		void	ReWrapText();
		void	CalcFontSize();
		void	EllipsisMyText();
		tempc_ptr(Client::Font)	GetAutoFont();
		
	private:
		Client::Unit::Align		m_TextAlign;
		Core::Vector4			m_TextPadding;
		sharedc_ptr(Icon)		m_Icon;
		bool					m_AutoWrap;
		Core::String			m_MultiLineStr;
		Core::String			m_EllipsisStr;
		bool					m_AutoFontSize;
		bool					m_AutoEllipsis;
		F32						m_ResultFontSize;		//for auto-font-size
		F64						m_Timer;
		F32						m_DisplayTime;
		bool					m_UseTimer;
		Core::Vector2			m_MoveLocation;
		F64						m_MoveWheelTime;
		F64						m_MoveTimer;
		Core::Vector2			m_NormLocation;
	};
}