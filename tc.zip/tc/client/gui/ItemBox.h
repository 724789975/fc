namespace Gui
{
	class ItemBoxSkin: public ControlSkin
	{
	public:
		INLINE_PDE_ATTRIBUTE_RW(NeutralNormalImage, tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(NeutralHoverImage, tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(NeutralSelectedImage, tempc_ptr(Image));

		INLINE_PDE_ATTRIBUTE_RW(RedNormalImage, tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(RedHoverImage, tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(RedSelectedImage, tempc_ptr(Image));

		INLINE_PDE_ATTRIBUTE_RW(BlueNormalImage, tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(BlueHoverImage, tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(BlueSelectedImage, tempc_ptr(Image));

		INLINE_PDE_ATTRIBUTE_RW(LockedImage, tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(PackAImage, tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(PackBImage, tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(PackCImage, tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(PackDImage, tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(PackEImage, tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(RepairImage, tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(EmptyImage, tempc_ptr(Image));

		INLINE_PDE_ATTRIBUTE_RW(NotSuitImage, tempc_ptr(Image));

		INLINE_PDE_ATTRIBUTE_RW(TuneNoImage, tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(TuneYesImage, tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(TunedImage, tempc_ptr(Image));

		INLINE_PDE_ATTRIBUTE_RW(UsingNoImage, tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(UsingYesImage, tempc_ptr(Image));

		INLINE_PDE_ATTRIBUTE_RW(SlotWeaponFirst, tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(SlotWeaponSecond, tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(SlotWeaponGrenade, tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(SlotWeaponFlash, tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(SlotWeaponSmoke, tempc_ptr(Image));

		INLINE_PDE_ATTRIBUTE_RW(SlotCharacterArmet, tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(SlotCharacterMask, tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(SlotCharacterClothes, tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(SlotCharacterGloves, tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(SlotCharacterTrou, tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(SlotCharacterShoes, tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(SlotCharacterBadge, tempc_ptr(Image));

		SIMPLE_PDE_ATTRIBUTE_RW(NameNormalColor, Core::ARGB);
		SIMPLE_PDE_ATTRIBUTE_RW(NameHighlightColor, Core::ARGB);
		SIMPLE_PDE_ATTRIBUTE_RW(LeftHighlightColor, Core::ARGB);

	private:
		sharedc_ptr(Image) m_NeutralNormalImage;
		sharedc_ptr(Image) m_NeutralHoverImage;
		sharedc_ptr(Image) m_NeutralSelectedImage;

		sharedc_ptr(Image) m_RedNormalImage;
		sharedc_ptr(Image) m_RedHoverImage;
		sharedc_ptr(Image) m_RedSelectedImage;

		sharedc_ptr(Image) m_BlueNormalImage;
		sharedc_ptr(Image) m_BlueHoverImage;
		sharedc_ptr(Image) m_BlueSelectedImage;

		sharedc_ptr(Image) m_LockedImage;
		sharedc_ptr(Image) m_PackAImage;
		sharedc_ptr(Image) m_PackBImage;
		sharedc_ptr(Image) m_PackCImage;
		sharedc_ptr(Image) m_PackDImage;
		sharedc_ptr(Image) m_PackEImage;
		sharedc_ptr(Image) m_RepairImage;
		sharedc_ptr(Image) m_EmptyImage;

		sharedc_ptr(Image) m_NotSuitImage;

		sharedc_ptr(Image) m_TuneNoImage;
		sharedc_ptr(Image) m_TuneYesImage;
		sharedc_ptr(Image) m_TunedImage;

		sharedc_ptr(Image) m_UsingNoImage;
		sharedc_ptr(Image) m_UsingYesImage;

		sharedc_ptr(Image) m_SlotWeaponFirst;
		sharedc_ptr(Image) m_SlotWeaponSecond;
		sharedc_ptr(Image) m_SlotWeaponGrenade;
		sharedc_ptr(Image) m_SlotWeaponFlash;
		sharedc_ptr(Image) m_SlotWeaponSmoke;

		sharedc_ptr(Image) m_SlotCharacterArmet;
		sharedc_ptr(Image) m_SlotCharacterMask;
		sharedc_ptr(Image) m_SlotCharacterClothes;
		sharedc_ptr(Image) m_SlotCharacterGloves;
		sharedc_ptr(Image) m_SlotCharacterTrou;
		sharedc_ptr(Image) m_SlotCharacterShoes;
		sharedc_ptr(Image) m_SlotCharacterBadge;
	};
}

namespace Gui
{
	class ItemBox: public Control
	{
	public:
		DECLARE_PDE_EVENT(EventMouseEnter, Client::InputEventArgs);
		DECLARE_PDE_EVENT(EventMouseLeave, Client::InputEventArgs);
		DECLARE_PDE_EVENT(EventSelected, Core::ValueChangeEventArgs);
		DECLARE_PDE_EVENT(EventCancel, Core::ValueChangeEventArgs);
		DECLARE_PDE_EVENT(EventDoubleClick, Client::InputEventArgs);
		DECLARE_PDE_ATTRIBUTE_RW(Selected, bool);
		DECLARE_PDE_ATTRIBUTE_RW(Empty, bool);
		INLINE_PDE_ATTRIBUTE_RW(CanCancel, bool);

		DECLARE_PDE_ATTRIBUTE_RW(Loading, bool);
		DECLARE_PDE_ATTRIBUTE_RW(Locked, bool);

		DECLARE_PDE_ATTRIBUTE_RW(ID, int);

		DECLARE_PDE_ATTRIBUTE_RW(ItemName, Core::String);

		DECLARE_PDE_ATTRIBUTE_RW(Cost, int);
		DECLARE_PDE_ATTRIBUTE_RW(CostType, int);
		DECLARE_PDE_ATTRIBUTE_RW(Period, int);

		DECLARE_PDE_ATTRIBUTE_RW(Suit, bool);
		DECLARE_PDE_ATTRIBUTE_RW(ItemIcon, tempc_ptr(Icon));
		INLINE_PDE_ATTRIBUTE_RW(LoadingImage, tempc_ptr(AnimatedImage));


		//new add
		DECLARE_PDE_ATTRIBUTE_RW(PID, int);
		DECLARE_PDE_ATTRIBUTE_RW(SID, int);
		DECLARE_PDE_ATTRIBUTE_RW(Where, int);

		DECLARE_PDE_ATTRIBUTE_RW(Type, int);
		DECLARE_PDE_ATTRIBUTE_RW(SubType, int);
		DECLARE_PDE_ATTRIBUTE_RW(BagSP1, int);

		DECLARE_PDE_ATTRIBUTE_RW(Side, int);

		DECLARE_PDE_ATTRIBUTE_RW(UnitType, int);
		DECLARE_PDE_ATTRIBUTE_RW(TimeLeftType, int);
		DECLARE_PDE_ATTRIBUTE_RW(TimeLeft, int);
		DECLARE_PDE_ATTRIBUTE_RW(Quantity, int);
		DECLARE_PDE_ATTRIBUTE_RW(Durable, int);

		DECLARE_PDE_ATTRIBUTE_RW(InPack, int);
		DECLARE_PDE_ATTRIBUTE_RW(ModState, int);
		DECLARE_PDE_ATTRIBUTE_RW(UseState, int);

		DECLARE_PDE_ATTRIBUTE_RW(LastSelected, bool);

	public:
		ItemBox();
		~ItemBox();

		void Clear();

		// on frame update
		virtual void OnFrameUpdate(EventArgs & e);

		virtual void OnInputEvent(Client::InputEventArgs & e);
		virtual void OnPaint(PaintEventArgs & e);
		virtual void OnMouseEnter(Client::InputEventArgs & e);
		virtual void OnMouseLeave(Client::InputEventArgs & e);
		virtual void OnDoubleClick(Client::InputEventArgs & e);
		virtual int CalculateStringWidth(Core::String str);

	public:

	private:
		bool					m_Lock;//lock state
		bool					m_Selected;
		bool					m_Hovered;
		bool					m_IsEmpty;
		bool					m_IsLoading;
		bool					m_CanCancel;
		Core::ARGB				m_SelectColor;
		Core::ARGB				m_HoverColor;
		Core::ARGB				m_NormalColor;
		Core::ARGB				m_DisableColor;

		int						m_ID;	//������������
		int						m_PID;	//new add ��ƷID
		int						m_SID;	//new add SYSTEM ID

		int						m_Type;
		int						m_SubType;
		int						m_BagSP1;	//Only in bag when empty, 1: weapon 2: character


		Core::String			m_ItemName;
		int						m_ModState;	//0(���ɸ�װ),1(�ɸ�װδ��װ),2(�Ѹ�װ)
		int						m_UseState; //0(not Used), >0(using)

		int						m_UnitType; // 1 Permanent, 2 Damage Based, 3 Unit Based, 4 Time Based
		int						m_TimeLeftType;	// hour/day/month
		int						m_TimeLeft;		// time left
		int						m_Quantity;
		int						m_Durable;		// health value

		int						m_CostType;		//CR or GP
		int						m_Cost;			//cost
		int						m_Period;		//Period


		int						m_InPack;		//equip info, in which pack


		bool					m_Suit:1;		//suit current gender/weapon or not
		bool					m_LastSelected:1;
		int						m_Side;			//character costume side
		int						m_Where;		// -1: bag 1:wc 2:cc 3:shop 4:depot 5:room 6:other bag

		sharedc_ptr(Icon)		m_ItemIcon;
		sharedc_ptr(AnimatedImage) m_LoadingImage;
		bool					m_StartLoading;
	};
}
