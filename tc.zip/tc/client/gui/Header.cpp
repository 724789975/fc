#include "pch.h"

using namespace Core;
using namespace Gui;
using namespace Client;

DEFINE_PDE_TYPE_CLASS(Gui::HeaderSkin)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::ControlSkin);
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_PROPERTY_RW(NormalImage);
		ADD_PDE_PROPERTY_RW(HoverImage);
		ADD_PDE_PROPERTY_RW(DownImage);
		ADD_PDE_PROPERTY_RW(DisabledImage);
		ADD_PDE_PROPERTY_RW(SortNormalImage);
		ADD_PDE_PROPERTY_RW(SortReverseImage);
	}
};

DEFINE_PDE_TYPE_CLASS(Gui::Header)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::Control);
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_PROPERTY_RW(Clickable);
		ADD_PDE_PROPERTY_RW(Movable);
		ADD_PDE_PROPERTY_RW(Sizeable);
		ADD_PDE_PROPERTY_R (ItemCount);
		ADD_PDE_PROPERTY_R (AllWidth);
		ADD_PDE_PROPERTY_RW(SortID);
		ADD_PDE_PROPERTY_RW(SortReverse);

		ADD_PDE_METHOD(GetPos);
		ADD_PDE_METHOD(GetWidth);
		ADD_PDE_METHOD(SetWidth);
		ADD_PDE_METHOD(GetAlign);
		ADD_PDE_METHOD(SetAlign);
		ADD_PDE_METHOD(GetText);
		ADD_PDE_METHOD(SetText);
		ADD_PDE_METHOD(DisplayIndexToIndex);
		ADD_PDE_METHOD(IndexToDisplayIndex);
	
		ADD_PDE_METHOD(DeleteAll);

		ADD_PDE_EVENT(EventItemClick);

	}
};

REGISTER_PDE_TYPE(Gui::HeaderSkin);
REGISTER_PDE_TYPE(Gui::Header);


//--------------------------------------------------------------------------------------
// constructor.
//--------------------------------------------------------------------------------------
namespace Gui
{
	Header::Header()
		: m_Clickable(false)
		, m_Movable(false)
		, m_Sizeable(false)
		, m_PushDown(false)
		, m_SplitID(-1)
		, m_MoveID(-1)
		, m_SortID(-1)
		, m_SortReverse(false)
		, m_Moved(false)
	{
	}

	Header::~Header()
	{
	}
}

//--------------------------------------------------------------------------------------
// Attribute
//--------------------------------------------------------------------------------------
namespace Gui
{
	PDE_ATTRIBUTE_GETTER(Header, Clickable, bool)
	{
		return m_Clickable;
	}

	PDE_ATTRIBUTE_SETTER(Header, Clickable, bool)
	{
		if (m_Clickable != value)
		{
			m_Clickable = value;
		}
	}

	PDE_ATTRIBUTE_GETTER(Header, Movable, bool)
	{
		return m_Movable;
	}

	PDE_ATTRIBUTE_SETTER(Header, Movable, bool)
	{
		if (m_Movable != value)
		{
			m_Movable = value;
		}
	}

	PDE_ATTRIBUTE_GETTER(Header, Sizeable, bool)
	{
		return m_Sizeable;
	}

	PDE_ATTRIBUTE_SETTER(Header, Sizeable, bool)
	{
		if (m_Sizeable != value)
		{
			m_Sizeable = value;
		}
	}

	PDE_ATTRIBUTE_GETTER(Header, SortID, S32)
	{
		return m_SortID;
	}

	PDE_ATTRIBUTE_SETTER(Header, SortID, S32)
	{
		if (m_SortID != value && m_Items.Size() > 0)
		{
			if (value < (int)m_Items.Size() && m_Items[value].Text != "")
			{
				m_SortID = value;
				Invalid();
			}
		}
	}

	PDE_ATTRIBUTE_GETTER(Header, SortReverse, bool)
	{
		return m_SortReverse;
	}

	PDE_ATTRIBUTE_SETTER(Header, SortReverse, bool)
	{
		if (m_SortReverse != value)
		{
			m_SortReverse = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(Header, CurrentSorter, tempc_ptr(ListTreeView::SortFunc))
	{
		return m_CurrentSorter;
	}

	PDE_ATTRIBUTE_SETTER(Header, CurrentSorter, tempc_ptr(ListTreeView::SortFunc))
	{
		if (m_CurrentSorter != value)
		{
			m_CurrentSorter = value;
		}
	}

	PDE_ATTRIBUTE_GETTER(Header, ItemCount, U32)
	{
		return m_Items.Size();
	}

	PDE_ATTRIBUTE_GETTER(Header, AllWidth, F32)
	{
		F32 width = 0;
		for (U32 i=0; i<m_Items.Size(); ++i)
		{
			if (m_Items[i].DisplayIndex < m_Items.Size())
			{
				width += m_Items[i].Width;
			}
		}
		return width;
	}

	PDE_ATTRIBUTE_GETTER(Header, Items, const Core::Array<Header::HeaderItem> &)
	{
		return m_Items;
	}
}


//--------------------------------------------------------------------------------------
// Event
//--------------------------------------------------------------------------------------
namespace Gui
{
	static const F32 SPLIT_WIDTH = 0.f;

	void Header::OnLayout(EventArgs & e)
	{
		Super::OnLayout(e);
	}

	void Header::OnPaint(PaintEventArgs & e)
	{
		Super::OnPaint(e);

		Core::Rectangle clientRect(Core::Vector2::kZero, GetSize());
		F32	height = GetSize().y;

		tempc_ptr(HeaderSkin) skin = ptr_dynamic_cast<HeaderSkin>(GetSkin());
		if(skin)
		{
			for (U32 i=0; i<m_Items.Size(); ++i)
			{
				if (m_Items[i].DisplayIndex != -1)
				{
					F32 width = m_Items[i].Width;
					Core::Rectangle rect(Core::Vector2(m_Items[i].Pos, 0), Core::Vector2(m_Items[i].Pos + width, height));

					Core::Rectangle old_scissor = e.render->GetScissorRect();
					e.render->AddScissorRectWithWorldMatrix(rect);

					tempc_ptr(Image) pHeaderItemImage = NullPtr;
					if(m_Items[i].PushDown)
					{
						pHeaderItemImage = skin->GetDownImage();
					}
					else if(m_Items[i].Hover)
					{
						pHeaderItemImage = skin->GetHoverImage();
					}
					else
					{
						pHeaderItemImage = skin->GetNormalImage();
					}
					
					Skin::DrawImage(e.render, pHeaderItemImage, rect);
					if(m_SortID==i && m_Items[i].Text != "")
					{
						Core::Rectangle sortRect(rect);
						sortRect.Min.x = sortRect.Max.x-20;
						if(m_SortReverse)
							Skin::DrawImage(e.render, skin->GetSortReverseImage(), sortRect);
						else
							Skin::DrawImage(e.render, skin->GetSortNormalImage(), sortRect);
					}

					//TextPadding
					rect.Shrink(Vector4(1, 0, 1, 0));
					e.render->AddScissorRectWithWorldMatrix(rect);
					
					if(!m_Items[i].m_comboBox)
						e.render->DrawString(GetFont(), GetTextColor(), ARGB(0,0,0,0), rect, m_Items[i].Text, m_Items[i].Align);

					e.render->SetScissorRect(old_scissor);
				}
			}
		}
		else
		{
			for (U32 i=0; i<m_Items.Size(); ++i)
			{
				if (m_Items[i].DisplayIndex != -1)
				{
					F32 width = m_Items[i].Width;
					Core::Rectangle rect(Core::Vector2(m_Items[i].Pos, 0), Core::Vector2(m_Items[i].Pos + width, height));

					rect.Shrink(SPLIT_WIDTH, 0, SPLIT_WIDTH, 0);

					Core::Rectangle old_scissor = e.render->GetScissorRect();
					e.render->AddScissorRectWithWorldMatrix(rect);

					if (m_SortID == i)
					{
						rect.Max.x -= 18;
						e.render->AddScissorRectWithWorldMatrix(rect);
					}

					e.render->DrawRectangle(rect,rect,ARGB(200,60 + i*10,160 + i*10,80 + i*10));


					if(!m_Items[i].m_comboBox)
					{
						e.render->DrawString(GetFont(), 
							ARGB(0, 0, 0), 
							0,
							rect, 
							m_Items[i].Text, 
							m_Items[i].Align);
					}

					e.render->SetScissorRect(old_scissor);
				}
			}

			F32 end = GetAllWidth();
			F32 width = GetSize().x - end + 1;
			if (width >0)
			{
				Core::Rectangle rect(Core::Vector2(end, 0), Core::Vector2(end + width, height));
			}

		}

	}

	void Header::OnInputEvent(InputEventArgs & e)
	{
		if (e.IsMouseEvent())
		{
			Core::Vector2 localPos = ScreenToClient(e.CursorPosition);

			bool pointed = GetDisplayRect().IsPointInside(localPos);

			U32 splitID = m_Sizeable ? GetSplitItem(localPos.x) : -1;

			if (m_Items.Size() > splitID || m_Items.Size() > m_SplitID)
			{
				SetCursorShape(Screen::kCursorSizeWE);
			}

			switch(e.Type)
			{
			case InputEventArgs::kMouseDown:
				{
					if (e.Code == MC_LEFT_BUTTON && pointed)
					{
						SetCapture(true);

						m_SplitID = m_Sizeable ? splitID : -1;
						m_MoveID = GetPointItem(localPos);

						if (m_SplitID > m_Items.Size() && m_Items.Size() > m_MoveID)
						{
							m_PushDown = true;
							m_Items[m_MoveID].PushDown = m_Clickable && true;
							Invalid();
						}

						e.Handled = true;
					}
				}
				break;

			case InputEventArgs::kMouseUp:
				{
					if (e.Code == MC_LEFT_BUTTON)
					{
						m_SplitID = -1;
						
						if (m_Items.Size() > m_MoveID)
						{
							m_Items[m_MoveID].PushDown = false;

							if (!m_Moved && m_PushDown && m_Clickable)
							{
								HeaderEventArgs clickEvent;
								clickEvent.Column = m_MoveID;
								OnItemClick(clickEvent);
							}

							m_MoveID = -1;
							Invalid();
						}

						SetCapture(false);

						m_PushDown = false;
						m_Moved = false;
						e.Handled = true;
					}
				}
				break;

			case InputEventArgs::kMouseDoubleClick:
				{
					if (e.Code == MC_LEFT_BUTTON)
					{
						if(m_Items.Size() > splitID)
						{
							HeaderEventArgs splitEvent;
							splitEvent.Column = splitID;
							OnSplitDoubleClick(splitEvent);
						}

						e.Handled = true;
					}
				}
				break;

			case InputEventArgs::kMouseMove:
				{
					if (m_Items.Size() > m_SplitID)
					{
						F32 posMin = m_Items[m_SplitID].Pos + 10;
						F32 pos = Max(localPos.x, posMin);
						m_Items[m_SplitID].Width = pos - m_Items[m_SplitID].Pos;

						ResetPos();
						Invalid();
					}
					else if (m_Items.Size() > m_MoveID)
					{
						U32 index = GetPointItem(localPos);

						if (m_Movable && m_Items.Size() > index && index != m_MoveID)
						{
							if (IsMove(index, m_MoveID, localPos))
							{
								U32 temp = m_Items[m_MoveID].DisplayIndex;
								m_Items[m_MoveID].DisplayIndex = m_Items[index].DisplayIndex;
								m_Items[index].DisplayIndex = temp;
								m_Moved = true;

								ResetPos();
								Invalid();
							}

						}
					}
					else
					{
						if (m_Movable || m_Clickable)
						{
							U32 hoveredItem = GetPointItem(localPos);
							bool hoverChanged = false;
							for(int i=0; i<m_Items.GetCount(); i++)
							{
								if(hoveredItem == i)
								{
									if(!m_Items[i].Hover)
									{
										m_Items[i].Hover = true;
										hoverChanged = true;
									}
								}
								else
								{
									if(m_Items[i].Hover)
									{
										m_Items[i].Hover = false;
										hoverChanged = true;
									}
								}
							}
							if(hoverChanged)
								Invalid();
						}
					}
					e.Handled = true;
				}
				break;
			case InputEventArgs::kMouseLeave:
				{
					for(int i=0; i<m_Items.GetCount(); i++)
					{
						m_Items[i].Hover = false;
					}
					Invalid();
					break;
				}
			default:
				break;
			}
		}
		if (!e.Handled)
			Super::OnInputEvent(e);
	}

	void Header::OnItemChange(EventArgs & e)
	{
		tempc_ptr(ListTreeView) owner = ptr_dynamic_cast<ListTreeView>(GetParent());
		if (owner)
		{
			owner->DirtyLayout();
		}
	}

	void Header::OnSplitDoubleClick(HeaderEventArgs & e)
	{
		EventSplitDoubleClick.Fire(ptr_static_cast<Header>(this), e);
	}

	void Header::OnItemClick(HeaderEventArgs & e)
	{
		EventItemClick.Fire(ptr_static_cast<Header>(this), e);
		
#if 0
		ptr_static_cast<ListTreeView>(m_Parent)->Sort(
			ptr_static_cast<ListTreeView>(m_Parent)->GetListTreeViewRoot(),
			ListTreeView::SortCompare(e.Column),
			true,true);
#endif
	}

	void Header::OnComboBoxValueChanged( by_ptr(void) sender, EventArgs & e )
	{
		tempc_ptr(ComboBox) senderComboBox = ptr_dynamic_cast<ComboBox>(sender);
		if(!senderComboBox)
			return;
		U32 column = *(ptr_static_cast<U32>(senderComboBox->GetTag()));
		tempc_ptr(ListTreeView) parentTree = ptr_dynamic_cast<ListTreeView>(GetParent());
		tempc_ptr(ListItem) bakSelItem = parentTree->GetSelectedItem();
		//Begin applying filters
		parentTree->SetAllItemsVisible(true);
		S32 index = senderComboBox->GetSelectedIndex();
		if(index==0)
		{
			//remove filter
			m_Filters.Remove(IndexToItem(column));
		}
		else
		{
			if(!m_Filters.Contains(IndexToItem(column)))
			{
				m_Filters.Add(IndexToItem(column));
			}
		}
		U32 sizeFilters = m_Filters.GetCount();
		for(U32 i=0; i<sizeFilters; i++)
		{
			tempc_ptr(ComboBox) curCbBox = m_Filters[i]->m_comboBox;
			if(!curCbBox)
			{
				//Assert
				continue;
			}
			parentTree->FilterColumn(DisplayIndexToIndex(m_Filters[i]->DisplayIndex), curCbBox->GetText());
		}

		//Restore selected item, if there was one
		if(bakSelItem && bakSelItem->GetVisible())
		{
			parentTree->SetSelectedItem(bakSelItem);
		}
		else
		{
			parentTree->SetSelectedItem(NullPtr);
		}
		parentTree->DirtyLayout();
	}


	void Header::ReapplyAllConditions()
	{
		tempc_ptr(ListTreeView) parentTree = ptr_dynamic_cast<ListTreeView>(GetParent());
		tempc_ptr(ListItem) bakSelItem = parentTree->GetSelectedItem();
		//Sort
		if(GetSortID()>=0)
		{
			parentTree->SortColumn(GetSortID(), false, m_CurrentSorter);
		}
		//Filter
		U32 sizeFilters = m_Filters.GetCount();
		for(U32 i=0; i<sizeFilters; i++)
		{
			tempc_ptr(ComboBox) curCbBox = m_Filters[i]->m_comboBox;
			if(!curCbBox)
			{
				//Assert
				continue;
			}
			parentTree->FilterColumn(DisplayIndexToIndex(m_Filters[i]->DisplayIndex), curCbBox->GetText());
		}

		//Restore selected item, if there was one
		if(bakSelItem && bakSelItem->GetVisible())
		{
			parentTree->SetSelectedItem(bakSelItem);
		}
		else
		{
			parentTree->SetSelectedItem(NullPtr);
		}

		parentTree->DirtyLayout();
	}
}

//--------------------------------------------------------------------------------------
// Private Method
//--------------------------------------------------------------------------------------
namespace Gui
{
	Header::HeaderItem * Header::DisplayIndexToItem(U32 displayIndex)
	{
		if (displayIndex<m_Items.Size())
		{
			for (U32 i=0; i<m_Items.Size(); ++i)
			{
				if (displayIndex == m_Items[i].DisplayIndex)
				{
					return &m_Items[i];
				}
			}
		}

		return NULL;
	}

	U32 Header::GetSplitItem(F32 pos)
	{
		F32 splitPos = 0;

		for (U32 i=0; i<m_Items.Size(); ++i)
		{
			F32 splitPos = m_Items[i].Pos + m_Items[i].Width;

			if ((pos > splitPos - SPLIT_WIDTH) && (pos < splitPos + SPLIT_WIDTH))
			{
				return i;
			}
		}
		return -1;
	}

	U32 Header::GetPointItem(const Core::Vector2 & pos)
	{
		for (U32 i=0; i<m_Items.Size(); ++i)
		{
			if (m_Items[i].DisplayIndex != -1)
			{
				Core::Rectangle rect(Core::Vector2(m_Items[i].Pos, 0), Core::Vector2(m_Items[i].Pos + m_Items[i].Width, GetSize().y));

				if (rect.IsPointInside(pos))
				{
					return i;
				}
			}
		}
		return -1;
	}

	void Header::ResetPos()
	{
		F32 pos = 0;
		F32 width = 0;
		for (U32 i=0; i<m_Items.Size(); ++i)
		{
			HeaderItem * item = DisplayIndexToItem(i);
			if (item)
			{
				item->Pos = pos;
				pos += item->Width;
			}
		}

		OnItemChange(EventArgs());
	}

	bool Header::IsMove(U32 des, U32 src, const Core::Vector2 & pos)
	{
		bool flag =false;

		if (m_Items[des].DisplayIndex < m_Items[src].DisplayIndex)
		{
			Core::Rectangle rect(Core::Vector2(m_Items[des].Pos, 0), Core::Vector2(m_Items[des].Pos + m_Items[src].Width, GetSize().y));
			flag = rect.IsPointInside(pos);
		}
		else
		{
			Core::Rectangle rect = Core::Rectangle::RightTop(Core::Vector2(m_Items[des].Pos + m_Items[des].Width, 0), Core::Vector2(m_Items[src].Width, GetSize().y));
			flag = rect.IsPointInside(pos);
		}

		return flag;
	}
}

//--------------------------------------------------------------------------------------
// Method
//--------------------------------------------------------------------------------------
namespace Gui
{
	U32 Header::AddItem(const Core::String & text, F32 width /* = 60.f */, bool bFilter /* = false */, Client::Unit::Align itemAlign /* = Client::Unit::kAlignLeftMiddle */)
	{
		HeaderItem item;
		item.Text = text;
		item.Width = width == 0.f ? 60.f : width;
		item.DisplayIndex = m_Items.Size();
		item.PushDown = false;
		item.Hover = false;
		item.Pos = GetAllWidth();
		item.Align = itemAlign;
		HeaderItem& realItem = m_Items.PushBack(item);
		if(bFilter)
		{
			realItem.m_comboBox = ptr_new ComboBox;
			realItem.m_comboBox->SetParent(ptr_static_cast<Control>(this));
			realItem.m_comboBox->SetLocation(Vector2(item.Pos, 0));
			realItem.m_comboBox->SetSize(Vector2(width, GetSize().y));
			realItem.m_comboBox->SetReadonly(true);
			realItem.m_comboBox->SetTag(ptr_new U32(item.DisplayIndex));
			realItem.m_comboBox->SetStyle("Gui.EmbededComboBox");
			realItem.m_comboBox->EventValueChanged.Subscribe(NewDelegate(&Header::OnComboBoxValueChanged, ptr_static_cast<Header>(this)));
		}
		return m_Items.Size() - 1;
	}

	void Header::DeleteAll()
	{
		for(int i=0; i<m_Items.GetCount(); i++)
		{
			if(m_Items[i].m_comboBox)
			{
				m_Items[i].m_comboBox->SetParent(NullPtr);
				m_Items[i].m_comboBox=NullPtr;
			}
		}
		m_Items.Clear();
		m_SortID = -1;
		m_SortReverse = false;
		m_Filters.Clear();
		DirtyLayout();
	}

	F32 Header::GetPos(U32 index)
	{
		if (index < m_Items.Size())
		{
			return m_Items[index].Pos;
		}
		return 0.f;
	}

	F32 Header::GetWidth(U32 index)
	{
		if (index < m_Items.Size())
		{
			return m_Items[index].Width;
		}
		return 0.f;
	}

	const Core::String & Header::GetText(U32 index)
	{
		if (index < m_Items.Size())
		{
			return m_Items[index].Text;
		}
		return Core::String::kEmpty;
	}

	Client::Unit::Align Header::GetAlign(U32 index)
	{
		if (index < m_Items.Size())
		{
			return m_Items[index].Align;
		}
		return Client::Unit::kAlignLeftMiddle;
	}

	U32 Header::IndexToDisplayIndex(U32 index)
	{
		if (index < m_Items.Size())
		{
			return m_Items[index].DisplayIndex;
		}
		return -1;
	}

	U32 Header::DisplayIndexToIndex(U32 displayIndex)
	{
		if (displayIndex < m_Items.Size())
		{
			for (U32 i=0; i<m_Items.Size(); ++i)
			{
				if (displayIndex == m_Items[i].DisplayIndex)
				{
					return i;
				}
			}
		}
		return -1;
	}

	void Header::SetWidth(U32 index, F32 width)
	{
		if (index < m_Items.Size() && width != m_Items[index].Width)
		{
			m_Items[index].Width = width;
			ResetPos();
			Invalid();
		}
	}

	void Header::SetText(U32 index, const Core::String & text)
	{
		if (index < m_Items.Size() && text != m_Items[index].Text)
		{
			m_Items[index].Text = text;
			Invalid();
		}
	}

	void Header::SetAlign(U32 index, Client::Unit::Align align)
	{
		if (index < m_Items.Size() && align != m_Items[index].Align)
		{
			m_Items[index].Align = (Client::Unit::Align)(align & Client::Unit::kAlignHorizontalMask | Client::Unit::kAlignMiddle);
			Invalid();
			OnItemChange(EventArgs());
		}
	}

	void Header::SetDisplayIndex(U32 index, U32 displayIndex)
	{
		if (index < m_Items.Size() && displayIndex != m_Items[index].DisplayIndex)
		{
			if (displayIndex < m_Items.Size())
			{
				if (m_Items[index].DisplayIndex != -1)
				{
					DisplayIndexToItem(displayIndex)->DisplayIndex = m_Items[index].DisplayIndex;
					m_Items[index].DisplayIndex = displayIndex;
				}
				else
				{
					for (U32 i = m_Items.Size() - 1; i<m_Items.Size() && i>=displayIndex; --i)
					{
						HeaderItem * item = DisplayIndexToItem(i);
						if (item)
						{
							item->DisplayIndex += 1;
						}
					}
					m_Items[index].DisplayIndex = displayIndex;
				}
			}
			else if (m_Items[index].DisplayIndex != -1)
			{
				U32 temp = m_Items[index].DisplayIndex;
				m_Items[index].DisplayIndex = -1;
				
				for (U32 i=temp + 1; i<m_Items.Size(); ++i)
				{
					HeaderItem * item = DisplayIndexToItem(i);
					if (item)
					{
						item->DisplayIndex -= 1;
					}
				}
			}
			ResetPos();
			Invalid();
		}
	}

	Header::HeaderItem * Header::IndexToItem(U32 index)
	{
		if (index<m_Items.Size())
		{
			return &m_Items[index];
		}

		return NULL;
	}

	/// pos to Index
	U32 Header::PosToIndex(F32 pos)
	{
		for (U32 i=0; i<m_Items.Size(); ++i)
		{
			if (pos > m_Items[i].Pos && pos < m_Items[i].Pos + m_Items[i].Width)
				return i;
		}

		return -1;
	}

	void Header::UpdateComboBoxes()
	{
		tempc_ptr(ListTreeView) parentTree = ptr_dynamic_cast<ListTreeView>(GetParent());
		tempc_ptr(ListItem) rootItem = parentTree->GetRootItem();
		size_t subCount = m_Items.GetCount();
		for(size_t i=0; i<subCount; i++)
		{
			tempc_ptr(ComboBox) cbBox = IndexToItem(i)->m_comboBox;
			if(cbBox)
			{
				Core::String bakStr;
				if(cbBox->GetSelectedIndex()>0)
					bakStr = cbBox->GetText();

				cbBox->RemoveAll();
				cbBox->AddItem(Core::String::Format("%s%s", gLang->GetTextW(L"ȫ��"), IndexToItem(i)->Text));

				tempc_ptr(ListItem) curItem = rootItem->GetFirstChild();
				Core::HashSet<Core::String, int> hSet;
				while(curItem)
				{
					hSet.Add(curItem->GetText(i), 0);
					curItem = curItem->GetNext();
				}
				Core::Array<Core::String> tempArray;
				Core::HashSet<Core::String, int>::Enumerator hSetEnum(hSet);
				while(hSetEnum.MoveNext())
				{
					tempArray.Add(hSetEnum.Key());
				}
				//Sort
				S32 q=0;
				while (q+1<tempArray.GetCount())
				{
					S32 min = q;
					S32 p = q+1;

					while (p<tempArray.GetCount())
					{
						if(tempArray[min]>tempArray[p])
						{
							min = p;
						}
						++p;
					}
					if(min!=q)
					{
						Core::String tempStr = tempArray[min];
						tempArray[min]=tempArray[q];
						tempArray[q]=tempStr;
					}
					++q;
				}
				//end sort
				for(q=0;q<tempArray.GetCount();q++)
				{
					cbBox->AddItem(tempArray[q]);
				}
				//restore filter state
				if(bakStr.Length())
				{
					S32 selIndex = cbBox->TextToIndex(bakStr);
					if(selIndex>0)
						cbBox->SetSelectedIndex(selIndex);
					else
						cbBox->SetSelectedIndex(0);
				}
				else
				{
					cbBox->SetSelectedIndex(0);
				}
			}
		}
	}
}
