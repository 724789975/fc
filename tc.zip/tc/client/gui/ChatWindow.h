namespace Client
{
	struct ChatMessage;
}

namespace Gui
{
	class MessagePanel;
	class ChatWindow : public Control
	{
		friend class MessagePanel;
	public:
		DECLARE_PDE_OBJECT(ChatWindow, Control)
		
		enum ChannelIndex
		{	
			kNone			= 0,
			kSys			= 1<<1,
			kInfo			= 1<<2,
			kChannel		= 1<<3,
			kTeam			= 1<<4,
			kGroup			= 1<<5,
			kRoom			= 1<<6,
			kWhisper		= 1<<7,
			kSmallSpeaker	= 1<<8,
			kBigSpeaker		= 1<<9,
			kAll			= 0xFFF,
		};

		enum ChannelColor
		{
			kNoneColor				= 0xFFB7ABA5,
			kSysColor				= 0xFFDA0006,
			kInfoColor				= 0xFFFFFFFF,
			kChannelColor			= 0xFFFFFFFF,
			kTeamColor				= 0xFF829BAD,
			kGroupColor				= 0xFFFBA176,
			kRoomColor				= 0xFFFFFFFF,
			kWhisperColor			= 0xFFEBE5DA,
			kSmallSpeakerColor		= 0xFFEAE1AA,
			kBigSpeakerColor		= 0xFFFFF000,
			kChatColor		        = 0xFF252525,
		};
		struct Line 
		{
			ChannelIndex	Index;
			Core::String	LinkContent;
			Core::ARGB		Color;
			Core::String	Text;
			F32				LinkStart;
			F32				LinkEnd;
			uint			type;
			sharedc_ptr(Button)		m_Button;
			sharedc_ptr(MouseControl)		m_MouseCtr;
			Line()
				: Index(kAll)
				, LinkStart(-1.f)
				, LinkEnd(-1.f)
				, m_Button(NullPtr)
				, m_MouseCtr(NullPtr)
				, type(0)
			{

			}
		};

	public:
		DECLARE_PDE_ATTRIBUTE_R(Textbox, tempc_ptr(Textbox));
		DECLARE_PDE_ATTRIBUTE_RW(MessageDisplayLoc,Core::Vector2);
		DECLARE_PDE_ATTRIBUTE_RW(MessageDisplaySize,Core::Vector2);
		DECLARE_PDE_ATTRIBUTE_RW(gap,				float);
		DECLARE_PDE_ATTRIBUTE_RW(MessageVisble,		bool);
		INLINE_PDE_ATTRIBUTE_RW(ManuallyOn, bool);
		DECLARE_PDE_ATTRIBUTE_R(PopupMenu,	sharedc_ptr(Menu));
		DECLARE_PDE_ATTRIBUTE_R(ClickedName,Core::String);
		DECLARE_PDE_ATTRIBUTE_R(SenderMessage, Core::String);
		DECLARE_PDE_ATTRIBUTE_R(Servertype, uint );
		DECLARE_PDE_ATTRIBUTE_R(SenderGroup, Core::String);
		DECLARE_PDE_ATTRIBUTE_R(SenderGroup_id, uint);
		DECLARE_PDE_ATTRIBUTE_R(SenderName,Core::String);
		DECLARE_PDE_ATTRIBUTE_R(ChatForm,F32);
		DECLARE_PDE_ATTRIBUTE_R(ChatFormColor,F32);
		DECLARE_PDE_ATTRIBUTE_R(Private_Chat,		bool);
		
		DECLARE_PDE_EVENT(EventReceiveMessage,EventArgs);
	public:
		ChatWindow(void);

		~ChatWindow(void);

		void OnCreate();

		void OnInputEvent(InputEventArgs & e);

		void OnComplementaryDraw(PaintEventArgs & e, F32 opacity);

		void OnTabpadRightClick(by_ptr(void) sender, InputEventArgs & e);

		void OnTabpadSelectedPageChanged(by_ptr(void) sender, Gui::TabChangedEventArgs & e);

		void OnNewWindowButtonClick(by_ptr(void) sender, Client::InputEventArgs & e);

		void NewWindow();

		void ResetNewWindowButtonLocation();

		void OnComboBoxItemSelected(by_ptr(void) sender,EventArgs & e);

		void OnTextboxTextChanged(by_ptr(void) sender, Core::EventArgs & e);

		void OnTextboxValueEnter(by_ptr(void) sender, Core::EventArgs & e);

		void OnRenameValueEnter(by_ptr(void) sender, Core::EventArgs & e);

		void OnRenameLeave(by_ptr(void) sender, Core::EventArgs & e );

		void Rename();

		void OnSendButtonClick(by_ptr(void) sender, Client::InputEventArgs & e);

		void ReceiveMessage(Client::ChatMessage & message);

		void SendMessage();

		void SetChannel(Core::ARGB channelColor, Core::Identifier to, Core::String labelText, Core::String textboxText = Core::String::kEmpty);

		void Whisper(Core::String to);

		void ChannelSpeak();

		void RoomSpeak();

		void GroupSpeak(Core::String Group ,Core::String to);

		void TepGroupSpeak(F32 to);

		void InvitePlayer(Core::String to);

		void RefuseInvite(Core::String to);

		void OnMainMenuClick(by_ptr(void) sender, InputEventArgs &e);

		void OnShowMenuClick(by_ptr(void) sender, InputEventArgs & e);

		void OnPopupMenuClick(by_ptr(void) sender, InputEventArgs & e);

		void OnMenuOpen(by_ptr(void) sender, EventArgs & e);

		void OnMenuClose(by_ptr(void) sender, EventArgs & e);

		void AddLine(const Line & line);

		void Chat(const Core::String &string,const Core::String &str);

	private:

		Core::Identifier								m_To;
		F32			                                    m_nTo;
		Core::Identifier								m_ReplyObject;
		Core::String									m_ChatText;
		Core::Rectangle									m_TextRect;
		Core::String									m_OldWindowName;
		F32												m_CurrentLinkStart;

		U32												m_MaxAllLine;
		Core::Array<Line>								m_AllLines;
		Core::Array<Core::String>                       m_GroupNames;

		sharedc_ptr(Tabpad)								m_Tabpad;
		sharedc_ptr(MessagePanel)						m_MessagePanel;
		sharedc_ptr(Button)								m_NewWindowButton;
		sharedc_ptr(Control)								m_Control;
		sharedc_ptr(ComboBox)							m_ComboBox;
		sharedc_ptr(Label)								m_Label;
		sharedc_ptr(Textbox)								m_Textbox;
		sharedc_ptr(Button)								m_SendButton;
		sharedc_ptr(Textbox)								m_Rename;

		sharedc_ptr(Menu)								m_MainMenu;
		sharedc_ptr(Menu)								m_ShowMenu;
		sharedc_ptr(Menu)								m_PopupMenu;

		bool											m_ManuallyOn;

		Core::String									m_MessagePanelStyle;

		Core::Vector2									m_MessageDisplayLoc;
		Core::Vector2									m_MessageDisplaySize;
		F32												m_ChatForm;
		F32												m_ChatFormColor;
		Core::String									m_SenderName;
		Core::String									m_SenderMessage;
		uint 											m_Servertype;
		Core::String									m_SenderGroup;
		uint											m_SenderGroup_id;
		float											m_gap;
		bool											m_MessageVisble;
		bool											m_Private_Chat;
	};
}

namespace Gui
{
	class  SysMessageBar: public Control
	{
		DECLARE_PDE_OBJECT(SysMessageBar, Control)

	public:
		DECLARE_PDE_ATTRIBUTE_R(SenderName,Core::String);
		DECLARE_PDE_ATTRIBUTE_R(SenderMessage,Core::String);
		DECLARE_PDE_ATTRIBUTE_R(Servertype, uint );
		DECLARE_PDE_EVENT(EventHornMessage,EventArgs);
		DECLARE_PDE_EVENT(EventSpeakerMessage,EventArgs);
		DECLARE_PDE_EVENT(EventSeverPresent,EventArgs);

	public:
		struct SysMessage
		{
			Core::String			Text;
			Core::ARGB				TextColor;
			Client::Unit::Align		Align;
			Core::Rectangle			TextRect;
			Core::Rectangle			PaintRect;
			Core::UInt				Times;
			F32						FontSize;
			Core::Array<Core::String> ArString;
			SysMessage()
				: Times(0)
				, FontSize(16)
			{

			}
		};

	public:
		///constructor
		SysMessageBar();

		///destructor
		~SysMessageBar();

		/// on paint
		virtual void OnPaint(PaintEventArgs & e);

		// on frame update
		virtual void OnFrameUpdate(EventArgs & e);

		int	GetWarningMessageArraySize();

	public:
		void ReceiveMessage(Client::ChatMessage & message);

	private:
		F32								m_FrameTimer;
		SysMessage						m_BigSpeakerMessage;
		SysMessage						m_WarningMessage;
		Core::Array<SysMessage>         m_WarningMessageArray;
		Core::Rectangle					m_IconRect;
		sharedc_ptr(Icon)				m_Icon;
		sharedc_ptr(Icon)				m_IconSpeaker;

		Core::String					m_SenderName;
		Core::String					m_SenderMessage;
		uint					m_Servertype;
		Core::ARGB						Prize_Color[9];
	};
}