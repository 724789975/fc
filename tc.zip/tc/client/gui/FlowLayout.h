namespace Gui
{
	class FlowLayout: public Control
	{
		DECLARE_PDE_OBJECT(FlowLayout, Control)
	public:
		enum Direction
		{
			kHorizontal,
			kVertical,
		};

	public:
		DECLARE_PDE_ATTRIBUTE_RW(ControlSpace,	F32);
		DECLARE_PDE_ATTRIBUTE_RW(LineSpace,		F32);
		DECLARE_PDE_ATTRIBUTE_RW(Direction,		Direction);
		DECLARE_PDE_ATTRIBUTE_RW(ControlAlign,	Client::Unit::Align);
		DECLARE_PDE_ATTRIBUTE_RW(Align,			Client::Unit::Align);

	public:
		FlowLayout();
		~FlowLayout();
		virtual void OnLayout(Core::EventArgs & e);

		virtual void OnMouseEnter(InputEventArgs & e);

		virtual void OnMouseLeave(InputEventArgs & e);
	private:
		Direction			m_Direction;
		F32					m_ControlSpace;
		F32					m_LineSpace;
		Client::Unit::Align				m_ControlAlign;
		Client::Unit::Align				m_Align;
	};
}