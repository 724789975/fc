#include "pch.h"

using namespace Core;
using namespace Client;
using namespace Gui;

//---------------------------------------------------------------------------------------
// typeinfo.
//---------------------------------------------------------------------------------------
DEFINE_PDE_TYPE_CLASS(CachedControl)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Control);
		ADD_PDE_DEFAULT_CONSTRUCTOR();
	}
};

REGISTER_PDE_TYPE(CachedControl);


//---------------------------------------------------------------------------------------
// constructor.
//---------------------------------------------------------------------------------------
namespace Gui
{
	CachedControl::CachedControl()
	{
	}

	CachedControl::~CachedControl()
	{
	}
}

//---------------------------------------------------------------------------------------
// attributes.
//---------------------------------------------------------------------------------------
namespace Gui
{
}

//---------------------------------------------------------------------------------------
// events
//---------------------------------------------------------------------------------------
namespace Gui
{
	void CachedControl::OnCreate()
	{
		Control::OnCreate();

		m_Texture = ptr_new RenderTexture;
		ptr_static_cast<RenderTexture>(m_Texture)->CreateRenderTexture(m_Size.x, m_Size.y, 1, D3DUSAGE_RENDERTARGET, D3DFMT_A8R8G8B8);
	}


	void CachedControl::OnDestroy()
	{
		Control::OnDestroy();
	}

	void CachedControl::OnPaint(PaintEventArgs & e)
	{
		ARGB bgcolor = GetBackgroundColor(); bgcolor.a = 0;

		Core::Rectangle bg_rect(GetBackgroundRect());
		e.render->SetBlendMode(kBlendNone);
		e.render->SetTexture(NullPtr);
		e.render->DrawRectangle(bg_rect, bg_rect, bgcolor);
		e.render->SetBlendMode(kAlphaBlend);

		Control::OnPaint(e);
	}

	void CachedControl::OnSizeChanged(ResizeEventArgs & e)
	{
		if (m_Size.x > 0 && m_Size.y > 0)
		{
			m_Texture->SetSize(m_Size.x, m_Size.y);
		}

		Super::OnSizeChanged(e);
	}

	void CachedControl::Render(RenderEventArgs & e)
	{
		Matrix44 old_view = e.render->GetView();
		Matrix44 old_proj = e.render->GetProjection();

		if (e.render->BeginDraw(m_Texture->GetSurface()))
		{
			Matrix44 world, view;
			Vector3 rt_size = e.render->GetRenderTargetSize();

			view.SetScaleXYZ(2.0f / rt_size.x, -2.0f / rt_size.y, 0);
			view.TranslateXYZ(-1, 1, 0);
			view.TranslateLocalXYZ(-0.5f, -0.5f, 0);

			e.render->SetWorld(Matrix44::kIdentity);
			e.render->SetView(view);
			e.render->SetProjection(Matrix44::kIdentity);

			if (gGame->input->IsKeyDown(KC_F5))
			{
				for (Control * control = this; control; control = control->GetNextNode())
					control->Invalid();
			}

			e.Enable = m_Enable;
			e.Offset = Vector2::kZero;
			e.Cached = true;

			e.render->SetScissorRect(e.render->GetVirtualViewport());
			Control::Render(e);

			if (gGame->input->IsKeyPressed(KC_F6))
			{
				e.render->SetWorld(Matrix44::kIdentity);
				e.render->SetScissorRect(Core::Rectangle::kInvalid);
				e.render->SetTexture(NullPtr);
				e.render->BeginRectangleList(1);
				e.render->VertexColor(ARGB(255, 0, 0, 0));
				e.render->Vertex2f(0, 0);
				e.render->Vertex2f(rt_size.x, rt_size.y);
				e.render->End();
			}

			e.render->EndDraw();
		}


		if (e.render->BeginDraw(gGame->dx9->render_target, NULL))
		{
			Vector2 wd_size = GetSize();

			Matrix44 matrix;
			matrix.SetIdentity();

			e.render->SetWorld(matrix);
			e.render->SetView(old_view);
			e.render->SetProjection(old_proj);

			e.render->SetScissorRect(Core::Rectangle::kInvalid);

			e.render->SetTexture(m_Texture);
			e.render->DrawRectangle(Core::Rectangle(0, 0, wd_size.x, wd_size.y), Core::Rectangle(0, 0, 1, 1));

			e.render->EndDraw();
		}
	}

	Core::Vector2 CachedControl::ScreenToClient( const Core::Vector2 & pos )
	{
		return pos;
	}

	Core::Vector2 CachedControl::ClientToScreen( const Core::Vector2 & pos )
	{
		return pos;
	}
}

