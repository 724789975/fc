namespace Gui
{
	/// base class of ui elements
	class Tabpage : public Control
	{
		DECLARE_PDE_OBJECT(Tabpage, Control)

	public:
		DECLARE_PDE_EVENT(EventSelectChanged, EventArgs);
		DECLARE_PDE_EVENT(EventParentChanged, EventArgs);

	public:
		DECLARE_PDE_ATTRIBUTE_RW(Selected,		bool);
		DECLARE_PDE_ATTRIBUTE_RW(NormalIcon,	tempc_ptr(Icon));
		DECLARE_PDE_ATTRIBUTE_RW(ActiveIcon,	tempc_ptr(Icon));
		INLINE_PDE_ATTRIBUTE_RW(EllipsisStr,	Core::String);

	public:
		///constructor
		Tabpage();

		///destructor
		~Tabpage();

		/// on text changed
		virtual void OnTextChanged(EventArgs & e);

		/// on text changed
		virtual void OnSelectChanged(EventArgs & e);

		/// on parent changed
		virtual void OnParentChanged(EventArgs & e);

	protected:
		sharedc_ptr(Icon)	m_NormalIcon;
		sharedc_ptr(Icon)	m_ActiveIcon;
		Core::String		m_EllipsisStr;
	};
}