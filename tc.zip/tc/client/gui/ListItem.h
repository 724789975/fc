namespace Gui
{
	class ListItemSkin: public ControlSkin
	{
	public:
		INLINE_PDE_ATTRIBUTE_RW(BackgroundImageOp, tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(HoverImage,		tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(SelectedImage,	tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(SelfImage,	tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(DisabledImage,	tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(FrameImage,		tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(CheckOnIcon,		tempc_ptr(Icon));
		INLINE_PDE_ATTRIBUTE_RW(CheckOffIcon,		tempc_ptr(Icon));
		INLINE_PDE_ATTRIBUTE_RW(TextColor,		Core::ARGB);

	public:
		ListItemSkin()
			: m_TextColor(255,255,255,255)
		{

		}

	private:
		sharedc_ptr(Image) m_BackgroundImageOp;
		sharedc_ptr(Image) m_HoverImage;
		sharedc_ptr(Image) m_SelectedImage;
		sharedc_ptr(Image) m_DisabledImage;
		sharedc_ptr(Image) m_FrameImage;
		sharedc_ptr(Image) m_SelfImage;
		sharedc_ptr(Icon) m_CheckOnIcon;
		sharedc_ptr(Icon) m_CheckOffIcon;
		Core::ARGB			m_TextColor;
	};
}
namespace Gui
{
	/// list item
	class ListItem : public Core::Object
	{
		DECLARE_PDE_OBJECT(ListItem, Core::Object)

	public:
		struct SubItem
		{
			Core::String						Text;
			Core::String						Text_Show;
			sharedc_ptr(Gui::Icon)				Icon;
			sharedc_ptr(Gui::Icon)				Icon2;
			sharedc_ptr(Gui::Icon)				HoverIcon;
			Core::ARGB							Color;
		};

	public:
		ListItem();
		~ListItem();

	public:
		DECLARE_PDE_ATTRIBUTE_RW(Check,			bool);
		DECLARE_PDE_ATTRIBUTE_RW(Selected,		bool);
		DECLARE_PDE_ATTRIBUTE_RW(CanSelect,		bool);
		DECLARE_PDE_ATTRIBUTE_RW(ColCantSelect,	bool);
		DECLARE_PDE_ATTRIBUTE_RW(Expanded,		bool);
		DECLARE_PDE_ATTRIBUTE_RW(CanExpand,		bool);
		DECLARE_PDE_ATTRIBUTE_RW(Visible,		bool);
		DECLARE_PDE_ATTRIBUTE_RW(Level,			S32);
		DECLARE_PDE_ATTRIBUTE_RW(ColumnCount,	U32);
		DECLARE_PDE_ATTRIBUTE_RW(Tag,			tempc_ptr(void));
		DECLARE_PDE_ATTRIBUTE_R (Owner,			tempc_ptr(Control));
		DECLARE_PDE_ATTRIBUTE_RW(Parent,		tempc_ptr(ListItem));
		DECLARE_PDE_ATTRIBUTE_R	(FirstChild,	tempc_ptr(ListItem));
		DECLARE_PDE_ATTRIBUTE_R	(LastChild,		tempc_ptr(ListItem));
		DECLARE_PDE_ATTRIBUTE_R	(Next,			tempc_ptr(ListItem));
		DECLARE_PDE_ATTRIBUTE_R	(Prev,			tempc_ptr(ListItem));
		DECLARE_PDE_ATTRIBUTE_RW(BGSkin,			tempc_ptr(ListItemSkin));
		DECLARE_PDE_ATTRIBUTE_RW(ToolTipText,	const Core::String &);
		DECLARE_PDE_ATTRIBUTE_RW(ID,			U32);
		DECLARE_PDE_ATTRIBUTE_RW(VIP,			U32);
		DECLARE_PDE_ATTRIBUTE_RW(NAME,			Core::String &);
		DECLARE_PDE_ATTRIBUTE_RW(CheckBoxSize,	Core::Vector2);
		DECLARE_PDE_ATTRIBUTE_RW(CheckBoxLocation,	Core::Vector2);
		DECLARE_PDE_ATTRIBUTE_RW(LV_localtion,	Core::Vector2);
		DECLARE_PDE_ATTRIBUTE_RW(LV_Size,	Core::Vector2);
		DECLARE_PDE_ATTRIBUTE_RW(Invite_localtion,	Core::Vector2);
		DECLARE_PDE_ATTRIBUTE_RW(Invite_Size,	Core::Vector2);
		DECLARE_PDE_ATTRIBUTE_RW(CheckVisible,	bool);
		DECLARE_PDE_ATTRIBUTE_RW(NeedProjection,	bool);
		DECLARE_PDE_ATTRIBUTE_RW(FontSize,		F32);
		DECLARE_PDE_ATTRIBUTE_RW(TextColor,Core::ARGB);
		INLINE_PDE_ATTRIBUTE_RW (SpecialA,		bool);
		INLINE_PDE_ATTRIBUTE_RW	(WithFrame,		bool);
		INLINE_PDE_ATTRIBUTE_RW (IsSelfItem,	bool);
		INLINE_PDE_ATTRIBUTE_RW(CustomBg,		tempc_ptr(Gui::Image));
		INLINE_PDE_ATTRIBUTE_RW(LV_BackgroundImage,		tempc_ptr(Gui::Image));
		INLINE_PDE_ATTRIBUTE_RW(Invite_BackgroundImage,		tempc_ptr(Gui::Image));
		INLINE_PDE_ATTRIBUTE_RW(CustomTextColor, Core::ARGB);
		INLINE_PDE_ATTRIBUTE_RW(UseCustomTextColor, bool);
		DECLARE_PDE_ATTRIBUTE_RW(HighlightTextColor,	Core::ARGB);
		DECLARE_PDE_ATTRIBUTE_RW(SecLineHighlightTextColor,	Core::ARGB);
		DECLARE_PDE_ATTRIBUTE_RW(SecLineColor,	Core::ARGB);
		DECLARE_PDE_ATTRIBUTE_RW(SecLineText,	const Core::String &);
		DECLARE_PDE_ATTRIBUTE_RW(Deviate_x,			F32);
		DECLARE_PDE_ATTRIBUTE_RW(Deviate_y,			F32);
		DECLARE_PDE_ATTRIBUTE_RW(SecLineFontSize,	F32);
		DECLARE_PDE_ATTRIBUTE_RW(SecLineTextColunm,		F32);
		DECLARE_PDE_ATTRIBUTE_RW(UserData,		int);
	public:
		/// on create
		virtual void OnCreate();

		/// on destroy
		virtual void OnDestroy();

		/// on items changed
		virtual void OnItemsChanged(EventArgs & e);

		/// on draw background
		virtual void OnDrawBackground(DrawItemEventArgs & e);

		/// on draw LV_backgruound
		virtual void OnDrawLV_Background(DrawItemEventArgs & e);

		/// on draw Invite_backgruound
		virtual void OnDrawInvite_Background(DrawItemEventArgs & e);

		/// on draw item
		virtual void OnDrawColumn(DrawItemEventArgs & e,float FontSize = 0,Core::ARGB FontColor = Core::ARGB(0.0f,0.0f,0.0f,0.0f));

	public:
		virtual sharedc_ptr(ListItem) CreateItem();

		virtual void AddSubItem(const Core::String & text);

		virtual const Core::String & GetText(U32 columnId);

		virtual const Core::String & GetText_Show(U32 columnId);

		virtual tempc_ptr(Gui::Icon) GetIcon(U32 columnId);

		virtual tempc_ptr(Gui::Icon) GetIcon2(U32 columnId);

		virtual const Core::ARGB GetSubItemColor(U32 columnId);

		virtual tempc_ptr(Gui::Icon) GetHoverIcon(U32 columnId);

		virtual void SetText(U32 columnId, const Core::String & value);

		virtual void SetText_Show(U32 columnId, const Core::String & value);

		virtual void SetSubItemColor(U32 columnId, const Core::ARGB & value);

		virtual void SetIcon(U32 columnId, by_ptr(Gui::Icon) icon,by_ptr(Gui::Icon) icon2 = NullPtr);

		virtual	void SetHoverIcon(U32 columnId, by_ptr(Gui::Icon) hoverIcon);

		sharedc_ptr(ListItem) GetNextNode(bool bSkipChilds = false);

		sharedc_ptr(ListItem) GetPrevNode(bool bSkipChilds = false);

		/// is child of
		bool IsChildOf(by_ptr(ListItem) item);

		/// insert before
		bool InsertBefore(by_ptr(ListItem) item);

		/// insert after
		bool InsertAfter(by_ptr(ListItem) item);

		/// change parent
		bool ChangeParent(by_ptr(ListItem) parent, by_ptr(ListItem) insert, bool after);

		// items array
		Core::Array<SubItem> & Items() { return m_Items; }

		// find item
		tempc_ptr(ListItem) FindChildItem(U32 columnId, const Core::String & text);

		// find child item by tag
		tempc_ptr(ListItem) FindChildByTag(tempc_ptr(void) tag);

		// invalid
		void Invalid();

	private:
		ListItem * m_Parent;
		ListItem * m_Next;
		ListItem * m_Prev;
		ListItem * m_FirstChild;
		ListItem * m_LastChild;

		Core::Array<SubItem>	m_Items;
		bool				m_Check		: 1;
		bool				m_Selected	: 1;
		bool				m_CanSelect	: 1;
		bool				m_Expanded	: 1;
		bool				m_CanExpand	: 1;
		bool				m_Visible	: 1;
		bool				m_SpecialA	: 1;
		bool				m_WithFrame : 1;

		U32					m_ColumnCount;
		U32					m_Level;
		sharedc_ptr(void)	m_Tag;

		int					m_UserData;

		Core::String		m_ToolTipText;
		sharedc_ptr(ListItemSkin)  m_BGSkin;
		sharedc_ptr(Gui::Image)	m_CustomBg;
		sharedc_ptr(Gui::Image)	m_LV_BackgroundImage;
		sharedc_ptr(Gui::Image) m_Invite_BackgroundImage;
		Core::ARGB				m_CustomTextColor;
		bool					m_UseCustomTextColor;
		bool					m_ColCantSelect;
		bool					m_IsSelfItem;
		bool					m_CheckVisible;
		bool					m_NeedProjection;


		U32					m_ID;
		U32					m_VIP;
		Core::String		m_NAME;
		Core::Vector2				m_CheckBoxSize;
		Core::Vector2				m_CheckBoxLocation;
		Core::Vector2				m_LV_localtion;
		Core::Vector2				m_LV_Size;
		Core::Vector2				m_Invite_localtion;
		Core::Vector2				m_Invite_Size;
		F32					m_FontSize;
		Core::ARGB			m_TextColor;

		Core::ARGB			m_HighlightTextColor;
		Core::ARGB			m_SecLineHighlightTextColor;
		Core::ARGB			m_SecLineColor;
		Core::String		m_SecLineText;
		F32					m_Deviate_x;
		F32					m_Deviate_y;
		F32					m_SecLineFontSize;
		F32               m_SecLineTextColunm;
	};

	class ListItemRoot : public ListItem
	{
	public:
		DECLARE_PDE_ATTRIBUTE_RW(Owner,			tempc_ptr(Control));

	private:
		tempc_ptr(Control) m_Owner;
	};
}