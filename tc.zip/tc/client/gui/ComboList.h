namespace Gui
{
	class ComboList : public ScrollableControl
	{
		DECLARE_PDE_OBJECT(ComboList, ScrollableControl)
		friend class ComboBox;
	public:
		struct ComboItem
		{
			Core::String	Text;
			S32			Index;
			bool		with_icon;
			int			icon_Index;
			bool		disabled;

			ComboItem(const Core::String & text)
				: Text(text)
				, Index(S32_MIN)
				, with_icon(false)
				, disabled(false)
				, icon_Index(0)
			{
			}

			ComboItem(const Core::String & text, bool _with_icon, int indx)
				: Text(text)
				, Index(S32_MIN)
				, with_icon(_with_icon)
				, disabled(false)
				, icon_Index(indx)
			{
			}

			ComboItem(const ComboItem & item)
				: Text(item.Text)
				, Index(item.Index)
				, with_icon(item.with_icon)
				, disabled(false)
				, icon_Index(item.icon_Index)
			{
			}

		private:
			ComboItem();
		};

	public:
		static const S32 INDEX_NONE = -1;
		static const U32 ITEM_HEIGHT;

	public:
		DECLARE_PDE_EVENT(EventListClick,	EventArgs);
		DECLARE_PDE_EVENT(EventClose,		EventArgs);

	public:
		DECLARE_PDE_ATTRIBUTE_RW	(SelectedIndex,	S32);
		DECLARE_PDE_ATTRIBUTE_RW	(ActiveIndex,	S32);
		DECLARE_PDE_ATTRIBUTE_R		(ItemCount,		U32);
		DECLARE_PDE_ATTRIBUTE_RW	(Pad_x,			F32);
		DECLARE_PDE_ATTRIBUTE_RW	(ItemAlign,		Client::Unit::Align);
		INLINE_PDE_ATTRIBUTE_RW		(TextPadding,	Core::Vector4);

		/// dropdown size
		DECLARE_PDE_ATTRIBUTE_RW(DropDownHeight,	U32);
		DECLARE_PDE_ATTRIBUTE_RW(DropDownWidth,		U32);

	public:
		///constructor
		ComboList();

		///destructor
		~ComboList();

		/// on paint
		virtual	void OnPaint(PaintEventArgs & e);

		/// on input event
		virtual void OnInputEvent(InputEventArgs & e);

		/// on layout event
		virtual void OnLayout(EventArgs & e);

		// on leave
		virtual void OnLeave(EventArgs & e);

		/// on click
		virtual void OnListClick(InputEventArgs & e);

		int			PosToIndex(Core::Vector2 pos);

	public:
		/// show
		void Show();

		///close
		void Close();

		/// update screen position
		void UpdateScreenPosition();

		/// add item
		S32 AddItem(const Core::String & item, bool with_icon = false,int index = 0);

		/// insert item
		S32 InsertItem(S32 index, const Core::String & item);

		void SetItemDisable(S32 index, bool flag);

		/// remove item
		void RemoveItem(S32 index);

		/// move item
		void MoveItem(S32 index, S32 newIndex);

		/// get id
		S32 GetId(S32 index);

		/// set id
		void SetId(S32 index, S32 id);

		/// index to text
		const Core::String & IndexToText(S32 index = INDEX_NONE);

		/// text to index
		S32 TextToIndex(const Core::String & item);

		/// scroll to index
		void ScrollToIndex(S32 index);
	private:
		Core::Array<ComboItem>	m_aItems;
		weakc_ptr(ComboBox)		m_ComboBox;
		S32						m_SelectedIndex;
		S32						m_ActiveIndex;
		U32						m_ItemCount;
		U32						m_DropDownWidth;
		U32						m_DropDownHeight;
		F32						m_Pad_x;
		Client::Unit::Align		m_ItemAlign;
		Core::Vector4			m_TextPadding;
	};
}

namespace Gui
{
	class ComboListSkin : public ScrollableControlSkin
	{
	public:
		INLINE_PDE_ATTRIBUTE_RW(ItemHoverImage,		tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(ItemActiveImage,	tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(ItemIconImage,		tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(ItemIconImage1,		tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(ItemIconImage2,		tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(ItemDisableImage,	tempc_ptr(Image));
		

	private:
		sharedc_ptr(Image) m_ItemHoverImage;
		sharedc_ptr(Image) m_ItemActiveImage;
		sharedc_ptr(Image) m_ItemIconImage;
		sharedc_ptr(Image) m_ItemIconImage1;
		sharedc_ptr(Image) m_ItemIconImage2;
		sharedc_ptr(Image) m_ItemDisableImage;
	};
}