#include "pch.h"

using namespace Core;
using namespace Client;

#define ANIPERIOD 0.3f
//---------------------------------------------------------------------------------------
// typeinfo.
//---------------------------------------------------------------------------------------
DEFINE_PDE_TYPE_CLASS(Gui::WindowUI)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::Window);
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_EVENT(EventClose);
		ADD_PDE_PROPERTY_RW(ShowCloseButton);
		ADD_PDE_PROPERTY_RW(CloseButtonStyle);
		ADD_PDE_PROPERTY_RW(IconA);
		ADD_PDE_PROPERTY_RW(IconB);
		ADD_PDE_METHOD(Show);
		ADD_PDE_METHOD(Hide);
		ADD_PDE_METHOD(DisconnectContent);
		ADD_PDE_METHOD(SetScreenPos);
	}
};

DEFINE_PDE_TYPE_CLASS(Gui::FadingWindowUI)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::WindowUI);
		ADD_PDE_DEFAULT_CONSTRUCTOR();
	}
};

DEFINE_PDE_TYPE_CLASS(Gui::TimerWindowUI)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::WindowUI);
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_EVENT(EventTimeUp);
		ADD_PDE_PROPERTY_RW(Timer);
		ADD_PDE_PROPERTY_RW(AutoStart);
		ADD_PDE_METHOD(Start);
	}
};

DEFINE_PDE_TYPE_CLASS(Gui::PagedWindowUI)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::WindowUI);
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_PROPERTY_RW(TabStyle);
		ADD_PDE_PROPERTY_R (Container);
		ADD_PDE_METHOD(AddPage);
		ADD_PDE_METHOD(AddExistedPage);
		ADD_PDE_METHOD(GetPageByIndex);
		ADD_PDE_METHOD(GetPageByTitle);
		ADD_PDE_METHOD(RemovePageByIndex);
		ADD_PDE_METHOD(RemovePageByTitle);
		ADD_PDE_METHOD(SetActivePageByIndex);
		ADD_PDE_METHOD(SetActivePageByTitle);
		ADD_PDE_METHOD(SetFirstPageActive);
		ADD_PDE_METHOD(SetLastPageActive);
	}
};

REGISTER_PDE_TYPE(Gui::WindowUI);
REGISTER_PDE_TYPE(Gui::FadingWindowUI);
REGISTER_PDE_TYPE(Gui::TimerWindowUI);
REGISTER_PDE_TYPE(Gui::PagedWindowUI);

namespace Gui
{
	WindowUI::WindowUI()
		: m_ShowCloseButton(false)
		, m_Fade(0.0f)
		, m_State(kNormal)
		, m_FadeMode(0)
		, m_ScreenAnchor(0)
		, m_ScreenU(0.f)
		, m_ScreenV(0.f)
		, m_FixedPosition(0,0,0)
		, m_TargetPosition(0,0,0)
	{

	}

	WindowUI::~WindowUI()
	{

	}
}

namespace Gui
{
	PDE_ATTRIBUTE_GETTER(WindowUI, ShowCloseButton, Bool)
	{
		return m_ShowCloseButton;
	}
	PDE_ATTRIBUTE_SETTER(WindowUI, ShowCloseButton, bool)
	{
		if(m_ShowCloseButton!=value)
		{
			m_ShowCloseButton = value;
			m_CloseButton->SetVisible(value);
		}
	}
	
	PDE_ATTRIBUTE_GETTER(WindowUI, CloseButtonStyle, const Core::String &)
	{
		return m_CloseButton->GetStyle();
	}

	PDE_ATTRIBUTE_SETTER(WindowUI, CloseButtonStyle, const Core::String &)
	{
		m_CloseButton->SetStyle(value);
	}

	PDE_ATTRIBUTE_GETTER(WindowUI, DuringFading, bool)
	{
		return m_State == kFading;
	}

	PDE_ATTRIBUTE_GETTER(WindowUI, DuringShowing, bool)
	{
		return m_State == kShowing;
	}

	PDE_ATTRIBUTE_SETTER(WindowUI, Size, Core::Vector2)
	{
		Super::SetSize(value);
		if(m_State==kNormal)
		{
			//Only allow location changed by SetLocation when it's not showing/fading to ensure smooth animation
			SetScreenPos(m_ScreenAnchor, m_ScreenU, m_ScreenV);
		}
	}

	PDE_ATTRIBUTE_SETTER(WindowUI, Location, Core::Vector2)
	{
		if(m_State==kNormal)
		{
			//Only allow location changed by SetLocation when it's not showing/fading to ensure smooth animation
			Super::SetLocation(value);
		}
	}
}

namespace Gui
{
	void WindowUI::OnCreate()
	{
		Super::OnCreate();
		m_CloseButton = ptr_new Button;
		m_CloseButton->ChangeParent(ptr_static_cast<Control>(this), NullPtr);
		m_CloseButton->EventClick.Subscribe(NewDelegate(&Self::OnCloseButtonClick, ptr_static_cast<Self>(this)));
		m_CloseButton->SetVisible(m_ShowCloseButton);
	}

	void WindowUI::OnFrameUpdate(EventArgs & e)
	{
		Super::OnFrameUpdate(e);

		switch(m_FadeMode)
		{
		case 0: //None
			{
				if(m_State == kFading)
				{
					SetVisible(false);
					m_State = kNormal;
				}
				else if(m_State == kShowing)
				{
					SetVisible(true);
					m_State = kNormal;
					m_showGlowRay = false;
					SetOpacity(1.0f);
				}
			}
			break;
		case 1:	//Rotation: y-left flip
			{
				if(m_State == kFading)
				{
					float frameTime = Task::GetFrameTime();
					m_Fade += frameTime/0.4f;

					SetWorldRotation(Vector3(0.0f, m_Fade*Core::PI/2, 0.0f));

					if(m_Fade>=1)
					{
						m_Fade = 1;
						SetVisible(false);
						SetWorldRotation(Vector3::kZero);
						m_State = kNormal;
					}
					SetOpacity(1.0f-m_Fade);
				}
				else if(m_State == kShowing)
				{
					SetVisible(true);

					float frameTime = Task::GetFrameTime();
					m_Fade -= frameTime/0.4f;

					SetWorldRotation(Vector3(0.0f, m_Fade*Core::PI/2, 0.0f));

					if(m_Fade<=0.f)
					{
						m_Fade = 0.f;
						m_State = kNormal;
						m_showGlowRay = false;
						SetWorldRotation(Vector3::kZero);
					}
					SetOpacity(1.0f-m_Fade);
				}
			}
			break;
		case 3:	//fading&slip 3:left 4:right 5:in
		case 4:
		case 5:
			{
				if(m_State == kFading)
				{
					float frameTime = Task::GetFrameTime();
					m_Fade += frameTime/ANIPERIOD;

					Vector3 vDistance(0,0,0);
					if(m_FadeMode==3)
						vDistance.x = -gGame->guiSys->GetSize().x/2;
					else if(m_FadeMode==4)
						vDistance.x = gGame->guiSys->GetSize().x/2;
					else
						vDistance.z = -40;
					m_TargetPosition = m_FixedPosition+vDistance;
					SetWorldLocation( GetWorldLocation()+(m_TargetPosition-GetWorldLocation())*m_Fade );

					if(m_Fade>=1)
					{
						m_Fade = 1;
						SetVisible(false);
						SetWorldLocation(m_FixedPosition);
						m_State = kNormal;
					}
					SetOpacity(1.0f-m_Fade);
				}
				else if(m_State == kShowing)
				{
					SetVisible(true);

					float frameTime = Task::GetFrameTime();
					m_Fade -= frameTime/ANIPERIOD;

					Vector3 vDistance(0,0,0);
					if(m_FadeMode==3)
						vDistance.x = -300;
					else if(m_FadeMode==4)
						vDistance.x = 300;
					else
						vDistance.z = -40;
					SetWorldLocation( m_FixedPosition+vDistance*m_Fade );
					m_GlowOffset.y = GetSize().y*(m_Fade*2-1);

					if(m_Fade<=0.f)
					{
						m_Fade = 0.f;
						m_State = kNormal;
						m_showGlowRay = false;
						m_GlowOffset = Core::Vector2::kZero;
						SetWorldLocation(m_FixedPosition);
					}
					SetOpacity(1.0f-m_Fade);
				}
			}
			break;
		case 128:		//Mod weapon left
		case 129:		//Mod weapon bottom
			{
				if(m_State == kFading)
				{
					float frameTime = Task::GetFrameTime();
					m_Fade += frameTime/ANIPERIOD;

					Vector3 vDistance(0,0,0);
					if(m_FadeMode==128)
						vDistance.x = 223;
					else if(m_FadeMode==129)
						vDistance.y = 192;
					m_TargetPosition = m_FixedPosition+vDistance;
					SetWorldLocation( GetWorldLocation()+(m_TargetPosition-GetWorldLocation())*m_Fade );

					if(m_Fade>=1)
					{
						m_Fade = 1;
						SetVisible(false);
						SetWorldLocation(m_FixedPosition);
						m_State = kNormal;
					}
// 					SetOpacity(1.0f-m_Fade);
				}
				else if(m_State == kShowing)
				{
					float frameTime = Task::GetFrameTime();
					m_Fade -= frameTime/ANIPERIOD;

					Vector3 vDistance(0,0,0);
					if(m_FadeMode==128)
						vDistance.x = 223;
					else if(m_FadeMode==129)
						vDistance.y = 192;
					SetWorldLocation( m_FixedPosition+vDistance*m_Fade );

					if(m_Fade<=0.f)
					{
						m_Fade = 0.f;
						m_State = kNormal;
						m_showGlowRay = false;
						m_GlowOffset = Core::Vector2::kZero;
						SetWorldLocation(m_FixedPosition);
					}
// 					SetOpacity(1.0f-m_Fade);
					SetVisible(true);
				}
			}
			break;
		default: //0 and others: x&y flip
			{
				if(m_State == kFading)
				{
					float frameTime = Task::GetFrameTime();
					m_Fade += frameTime/0.4f;

					SetWorldRotation(Vector3(m_Fade*Core::PI/2, m_Fade*Core::PI/2, 0.0f));

					if(m_Fade>=1)
					{
						m_Fade = 1;
						SetVisible(false);
						m_State = kNormal;
						SetWorldRotation(Vector3::kZero);
					}
					SetOpacity(1.0f-m_Fade);
				}
				else if(m_State == kShowing)
				{
					SetVisible(true);

					float frameTime = Task::GetFrameTime();
					m_Fade -= frameTime/0.4f;

					SetWorldRotation(Vector3(m_Fade*Core::PI/2, m_Fade*Core::PI/2, 0.0f));

					if(m_Fade<=0.f)
					{
						m_Fade = 0.f;
						m_State = kNormal;
						m_showGlowRay = false;
						SetWorldRotation(Vector3::kZero);
					}
					SetOpacity(1.0f-m_Fade);
				}
			}
			break;
		}
	}


	void WindowUI::OnPaint( PaintEventArgs & e )
	{
		Super::OnPaint(e);
		if(m_IconA&&m_IconA->IsReady()&&m_IconB&&m_IconB->IsReady())
		{
			F32 leftTopX = 0;
// 			F32 leftTopY = (m_Padding.y-m_IconA->GetSize().y)/2;		//Center
			F32 leftTopY = m_Padding.y-m_IconA->GetSize().y;			//Bottom
			Core::Rectangle iconARect = Core::Rectangle::LeftTop(leftTopX, leftTopY, m_IconA->GetSize().x, m_IconA->GetSize().y);
			leftTopX = iconARect.Max.x;
// 			leftTopY = (m_Padding.y-m_IconB->GetSize().y)/2;			//Center
			leftTopY = m_Padding.y-m_IconB->GetSize().y-10;			//Bottom-10
			Core::Rectangle iconBRect = Core::Rectangle::LeftTop(leftTopX, leftTopY, m_IconB->GetSize().x, m_IconB->GetSize().y);
			Skin::DrawImage(e.render, m_IconA, iconARect);
			Skin::DrawImage(e.render, m_IconB, iconBRect);
		}
	}

	void WindowUI::OnClose(EventArgs& e)
	{
		EventClose.Fire(ptr_static_cast<WindowUI>(this), e);
	}

	void WindowUI::OnCloseButtonClick(by_ptr(void) sender,InputEventArgs & e)
	{
// 		SetVisible(false);
		OnClose(e);
	}

	void WindowUI::RepositionCloseButton()
	{
		Core::Vector4 buttonMargin = m_CloseButton->GetMargin();
		Core::Vector2 buttonSize = m_CloseButton->GetSize();
		Core::Vector2 windowSize = GetSize();
		m_CloseButton->SetLocation(Core::Vector2(windowSize.x-buttonSize.x-buttonMargin.z, buttonMargin.y));
	}

	void WindowUI::OnLayout( EventArgs & e )
	{
		Super::OnLayout(e);
		RepositionCloseButton();
	}

	void WindowUI::Show(U32 mode)
	{
		m_FixedPosition = GetFixedPosition(m_ScreenAnchor, m_ScreenU, m_ScreenV);
		SetWorldRotation(Core::Vector3::kZero);
		switch(m_State)
		{
		case kNormal:
			if(!GetVisible())
			{
				m_FadeMode = mode;
				m_State = kShowing;
				if(mode==4)
					m_showGlowRay = true;
				m_Fade = 1.0f;
			}
			break;
		case kFading:
			m_FadeMode = mode;
			m_State = kShowing;
			m_showGlowRay = true;
			break;
		case kShowing:
			break;
		default:
			break;
		}
	}

	void WindowUI::Hide(U32 mode)
	{
		m_FixedPosition = GetWorldLocation();
		SetWorldRotation(Core::Vector3::kZero);
		switch(m_State)
		{
		case kNormal:
			if(GetVisible())
			{
				m_FadeMode = mode;
				m_State = kFading;
				m_Fade = 0.f;
			}
			break;
		case kFading:
			break;
		case kShowing:
			m_FadeMode = mode;
			m_State = kFading;
			break;
		default:
			break;
		}
	}

	void WindowUI::DisconnectContent()
	{
		Super::RemoveAllChildren();
		if(m_CloseButton)
			m_CloseButton->ChangeParent(ptr_static_cast<Control>(this), NullPtr);
	}

	Core::Vector3 WindowUI::GetFixedPosition( U32 anchor, F32 uv_u, F32 uv_v )
	{
		Core::Vector2 screenSize = gGame->guiSys->GetSize();
		F32 screenU = uv_u*screenSize.x;
		F32 screenV = uv_v*screenSize.y;
		F32 finalU = GetWorldLocation().x;
		F32 finalV = GetWorldLocation().y;
		switch(anchor)
		{
		case 1:	//left top
			{
				finalU = screenU;
				finalV = screenV;
			}
			break;
		case 2:	//right top
			{
				finalU = screenU-GetSize().x;
				finalV = screenV;
			}
			break;
		case 3: //left bottom
			{
				finalU = screenU;
				finalV = screenV-GetSize().y;
			}
			break;
		case 4: //right bottom
			{
				finalU = screenU - GetSize().x;
				finalV = screenV - GetSize().y;
			}
			break;
		case 5:	//center
			{
				finalU = screenU - GetSize().x/2;
				finalV = screenV - GetSize().y/2;
			}
			break;
		case 6:	//left
			{
				Super::SetSize(Vector2(GetSize().x, gGame->guiSys->GetSize().y));
				finalU = 0;
				finalV = 0;
			}
			break;
		case 7: //top
			{
				Super::SetSize(Vector2(gGame->guiSys->GetSize().x, GetSize().y));	//Call Super::SetSize to avoid infinite loop
				finalU = 0;
				finalV = 0;
			}
			break;
		case 8:	//Right
			{				
				Super::SetSize(Vector2(GetSize().x, gGame->guiSys->GetSize().y));
				finalU = gGame->guiSys->GetSize().x-GetSize().x;
				finalV = 0;
			}
			break;
		case 9:	//Bottom
			{
				Super::SetSize(Vector2(gGame->guiSys->GetSize().x, GetSize().y));
				finalU = 0;
				finalV = gGame->guiSys->GetSize().y-GetSize().y;
			}
			break;

			//Specials
		case 61:		//Lobby: Main menu
			{
				finalU = screenSize.x - GetSize().x;
				finalV = screenSize.y - GetSize().y;
			}
			break;
		case 62:		//Lobby: Main Window
			{
				F32 validWidth = screenSize.x;
				F32 validHeight = screenSize.y-42-58;
				Vector2 winSize = GetSize();
				if(winSize.x<validWidth/2-20)
				{
					finalU = validWidth*3/4 - winSize.x/2;
				}
				else
				{
					finalU = validWidth - winSize.x - 10;
				}
				finalV = 42 + (validHeight-winSize.y)/2;
			}
			break;
		case 63:		//Lobby: Chat
			{
				finalU = 5;
				finalV = screenSize.y-GetSize().y-7;
			}
			break;
		case 64:		//Lobby Weapon Tune Vertical Panel
			{
				finalU = screenSize.x - GetSize().x - 4;
				finalV = 105;
			}
			break;
		default:	//invalid
			break;
		}
		return Vector3(Core::Floor(finalU+0.5f), Core::Floor(finalV+0.5f), 0);
	}

	void WindowUI::SetScreenPos( U32 anchor, F32 uv_u, F32 uv_v )
	{
		Core::Vector3 finalLocation = GetFixedPosition(anchor, uv_u, uv_v);
		SetWorldLocation(finalLocation);
		m_ScreenAnchor = anchor;
		m_ScreenU = uv_u;
		m_ScreenV = uv_v;
	}
}

namespace Gui
{
	FadingWindowUI::FadingWindowUI()
		: m_MouseIn(false)
	{

	}

	FadingWindowUI::~FadingWindowUI()
	{

	}

	void FadingWindowUI::OnFrameUpdate( EventArgs & e )
	{
		Super::OnFrameUpdate(e);

		if(IsActive())
		{
			if( Core::Abs(GetOpacity()-1.0f)>Core::EPSILON)
			{
				float frameTime = Task::GetFrameTime();
				SetOpacity(1.0f + Pow(0.001f, frameTime) * (GetOpacity() - 1.0f));
				Invalid();
			}
		}
		else
		{
			if( Core::Abs(GetOpacity()-0.3f)>Core::EPSILON)
			{
				float frameTime = Task::GetFrameTime();
				SetOpacity(0.3f + Pow(0.001f, frameTime) * (GetOpacity() - 0.3f));
				Invalid();
			}			
		}
	}

	void FadingWindowUI::OnMouseEnter( InputEventArgs & e )
	{
		m_MouseIn = true;
		Super::OnMouseEnter(e);
	}

	void FadingWindowUI::OnMouseLeave( InputEventArgs & e )
	{
		m_MouseIn = false;
		Super::OnMouseLeave(e);
	}

	void FadingWindowUI::Render( RenderEventArgs & e )
	{
		Super::Render(e);

		for (Control * control = m_FirstChild; control; control = control->GetNext())
		{
			tempc_ptr(ChatWindow) chatWindow = ptr_dynamic_cast<ChatWindow>(control);
			if(chatWindow)
			{
				chatWindow->OnComplementaryDraw(e, GetOpacity());
				break;
			}
		}
	}

	bool FadingWindowUI::IsActive()
	{
		bool bInFocus = false;
		tempc_ptr(Control) focusedControl = gGame->guiSys->GetFocusedControl();
		if(focusedControl)
		{
			if(focusedControl->IsChildOf(ptr_static_cast<Control>(this)))
				bInFocus = true;
		}

		bool bManuallyHoldOn = false;
		for (Control * control = m_FirstChild; control; control = control->GetNext())
		{
			tempc_ptr(ChatWindow) chatWindow = ptr_dynamic_cast<ChatWindow>(control);
			if(chatWindow)
			{
				bManuallyHoldOn = chatWindow->GetManuallyOn();
				break;
			}
		}

		if(bInFocus || m_MouseIn || bManuallyHoldOn)
			return true;
		else
			return false;
	}
}

namespace Gui
{
	TimerWindowUI::TimerWindowUI()
		: m_Timer(0.0f)
		, m_TimeRunning(0.0f)
		, m_Started(false)
		, m_AutoStart(false)
	{

	}
	TimerWindowUI::~TimerWindowUI()
	{

	}

	PDE_ATTRIBUTE_GETTER(TimerWindowUI, Timer, F32)
	{
		return m_Timer;
	}

	PDE_ATTRIBUTE_SETTER(TimerWindowUI, Timer, F32)
	{
		m_Timer = value;
	}

	PDE_ATTRIBUTE_GETTER(TimerWindowUI, AutoStart, bool)
	{
		return m_AutoStart;
	}

	PDE_ATTRIBUTE_SETTER(TimerWindowUI, AutoStart, bool)
	{
		m_AutoStart = value;
		if(m_AutoStart)
		{
			Start();
		}
	}

	void TimerWindowUI::OnFrameUpdate(EventArgs & e)
	{
		Super::OnFrameUpdate(e);

		if(m_Started)
		{
			F32 timeElapsed = Task::GetFrameTime();
			m_TimeRunning+=timeElapsed;
			if(m_TimeRunning>m_Timer)
			{
				EventTimeUp.Fire(ptr_static_cast<TimerWindowUI>(this), Core::EventArgs());
				Reset();
			}
		}
	}

	void TimerWindowUI::Start()
	{
		m_Started = true;
	}

	void TimerWindowUI::Reset()
	{
		m_TimeRunning = 0.0f;
	}
}

namespace Gui
{
	PagedWindowUI::PagedWindowUI()
	{

	}

	PagedWindowUI::~PagedWindowUI()
	{

	}
}

namespace Gui
{
	PDE_ATTRIBUTE_GETTER(PagedWindowUI, TabStyle, const Core::String &)
	{
		return m_Tabpad->GetStyle();
	}

	PDE_ATTRIBUTE_SETTER(PagedWindowUI, TabStyle, const Core::String &)
	{
		m_Tabpad->SetStyle(value);
	}

	PDE_ATTRIBUTE_GETTER(PagedWindowUI, Container, tempc_ptr(Tabpad))
	{
		return m_Tabpad;
	}
}

namespace Gui
{
	void PagedWindowUI::OnCreate()
	{
		Super::OnCreate();
		m_Tabpad = ptr_new Tabpad;
		m_Tabpad->ChangeParent(ptr_static_cast<Control>(this), NullPtr);
		m_Tabpad->SetDock(kDockFill);
	}

	tempc_ptr(Control) PagedWindowUI::AddPage( const Core::String& pageTitle )
	{
		sharedc_ptr(Control) newPage = ptr_new Tabpage;
		newPage->ChangeParent(m_Tabpad, NullPtr);
		newPage->SetBackgroundColor(Core::ARGB(0,0,0,0));
		newPage->SetText(pageTitle);
		return newPage;
	}

	tempc_ptr(Control) PagedWindowUI::AddExistedPage( tempc_ptr(Tabpage) page )
	{
		if(page)
		{
			page->ChangeParent(m_Tabpad, NullPtr);
			page->SetBackgroundColor(Core::ARGB(0,0,0,0));
		}
		return page;
	}

	tempc_ptr(Control) PagedWindowUI::GetPageByIndex( U32 index )
	{
		return m_Tabpad->GetChildByIndex(index);
	}

	tempc_ptr(Control) PagedWindowUI::GetPageByTitle( const Core::String& pageTitle )
	{
		return m_Tabpad->FindChildByText(pageTitle);
	}

	bool PagedWindowUI::RemovePageByIndex( U32 index )
	{
		tempc_ptr(Control) page = GetPageByIndex(index);
		if(page)
		{
			page->ChangeParent(NullPtr, NullPtr);
			return true;
		}
		return false;
	}

	bool PagedWindowUI::RemovePageByTitle( const Core::String& pageTitle )
	{
		tempc_ptr(Control) page = GetPageByTitle(pageTitle);
		if(page)
		{
			page->ChangeParent(NullPtr, NullPtr);
			return true;
		}
		return false;
	}

	bool PagedWindowUI::SetActivePageByIndex( U32 index )
	{
		tempc_ptr(Control) page = GetPageByIndex(index);
		if(page)
		{
			m_Tabpad->SelectPage(page);
			return true;
		}
		return false;
	}

	bool PagedWindowUI::SetActivePageByTitle( const Core::String& pageTitle )
	{
		tempc_ptr(Control) page = GetPageByTitle(pageTitle);
		if(page)
		{
			m_Tabpad->SelectPage(page);
			return true;
		}
		return false;
	}

	void PagedWindowUI::SetFirstPageActive()
	{
		m_Tabpad->SelectFirstPage();
	}

	void PagedWindowUI::SetLastPageActive()
	{
		m_Tabpad->SelectLastPage();
	}
}