#include "pch.h"

using namespace Core;
using namespace Client;
using namespace Gui;

//--------------------------------------------------------------------------------------
// type info
//--------------------------------------------------------------------------------------
DEFINE_PDE_TYPE_CLASS(Tabpage)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Control);
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_PROPERTY_RW(Selected);
		ADD_PDE_PROPERTY_RW(NormalIcon);
		ADD_PDE_PROPERTY_RW(ActiveIcon);

		ADD_PDE_EVENT(EventSelectChanged);
		ADD_PDE_EVENT(EventParentChanged);
	}
};

REGISTER_PDE_TYPE(Tabpage);

namespace Gui
{
	Tabpage::Tabpage()
	{
	}

	Tabpage::~Tabpage()
	{
	}
}


//--------------------------------------------------------------------------------------
// Attribute
//--------------------------------------------------------------------------------------
namespace Gui
{

	PDE_ATTRIBUTE_GETTER(Tabpage, Selected, bool)
	{
		tempc_ptr(Tabpad) owner = ptr_dynamic_cast<Tabpad>(GetParent());

		if (owner)
			return owner->GetSelectedPage().ToPointer() == this;

		return false;
	}


	PDE_ATTRIBUTE_SETTER(Tabpage, Selected, bool)
	{
		tempc_ptr(Tabpad) owner = ptr_dynamic_cast<Tabpad>(GetParent());

		if (owner)
			return owner->SetSelectedPage(ptr_static_cast<Tabpage>(this));
	}

	PDE_ATTRIBUTE_GETTER(Tabpage, NormalIcon, tempc_ptr(Icon))
	{
		return m_NormalIcon;
	}

	PDE_ATTRIBUTE_SETTER(Tabpage, NormalIcon, tempc_ptr(Icon))
	{
		if(m_NormalIcon != value)
		{
			m_NormalIcon = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(Tabpage, ActiveIcon, tempc_ptr(Icon))
	{
		return m_ActiveIcon;
	}

	PDE_ATTRIBUTE_SETTER(Tabpage, ActiveIcon, tempc_ptr(Icon))
	{
		if(m_ActiveIcon != value)
		{
			m_ActiveIcon = value;
			Invalid();
		}
	}
}


//--------------------------------------------------------------------------------------
// Event
//--------------------------------------------------------------------------------------
namespace Gui
{
	/// on text changed
	void Tabpage::OnTextChanged(EventArgs & e)
	{
		tempc_ptr(Tabpad) owner = ptr_dynamic_cast<Tabpad>(GetParent());

		if (owner)
		{
			owner->DirtyLayout();
			int index = owner->GetSonIndex(ptr_static_cast<Control>(this));
			if(index>=0)
			{
				Core::Rectangle myRect = owner->GetTabLableRect(index);
				myRect.Shrink(owner->GetTabLabelPadding());
				int resultPos = Control::EllipsisString(m_Text, m_EllipsisStr, myRect.GetExtent(), owner->GetFont());
				if(resultPos>=0)
				{
					SetTextEllipsis(true);
				}
				else
				{
					SetTextEllipsis(false);
				}
			}
		}
	}

	/// on text changed
	void Tabpage::OnSelectChanged(EventArgs & e)
	{
		EventSelectChanged.Fire(ptr_static_cast<Self>(this), e);
	}

	/// on parent changed
	void Tabpage::OnParentChanged(EventArgs & e)
	{
		EventParentChanged.Fire(ptr_static_cast<Self>(this), e);
	}
}

