namespace Gui
{
	class FlashSkin : public ControlSkin
	{

	};

	class FlashControl: public Control
	{
		DECLARE_PDE_OBJECT(FlashControl, Control);
	public:
		DECLARE_PDE_ATTRIBUTE_RW(UseTime,		bool);
		DECLARE_PDE_ATTRIBUTE_RW(DisplayTime,	F32);
		DECLARE_PDE_ATTRIBUTE_RW(IsUrl,	bool);

		DECLARE_PDE_EVENT(EventTimer,		EventArgs);
	public:
		FlashControl();
		~FlashControl();

		void OnPaint(PaintEventArgs & e);

		void OnInputEvent(InputEventArgs & e);

		void OnLayout(EventArgs & e);

		void OnSizeChanged(ResizeEventArgs & e);
		
		void CleanData();

	private:
		sharedc_ptr(Client::FlashPlayer) flash_player;
		sharedc_ptr(Client::Texture2D) temp_picture;

		F32 reset_time;
		
		bool m_UseTime;
		F32	 m_DisplayTime;
		bool m_IsUrl;
	};
}