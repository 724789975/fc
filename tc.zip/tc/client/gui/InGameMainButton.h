namespace Gui
{
	class InGameMainButton : public Button
	{
	public:
		DECLARE_PDE_OBJECT(InGameMainButton, Button);
		SIMPLE_PDE_ATTRIBUTE_RW(Clickable, bool);
	public:
		InGameMainButton();
		~InGameMainButton();
		virtual void OnCreate();
		virtual void OnInputEvent(Client::InputEventArgs & e);
		virtual void OnFrameUpdate(EventArgs & e);
		virtual void OnClick(Client::InputEventArgs &e);
		virtual void OnPaint(PaintEventArgs & e);

	protected:
		sharedc_ptr(Client::Font) m_NotificationFont;
	};

	class InGameMainButtonSkin : public ControlSkin
	{
	public:
		INLINE_PDE_ATTRIBUTE_RW(GameUpperImage,		tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(GameUpperHoverImage,tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(GameGlowUpperImage,	tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(GameActiveUpperImage, tempc_ptr(Image));

	private:
		sharedc_ptr(Image)	m_GameUpperImage;
		sharedc_ptr(Image)	m_GameUpperHoverImage;
		sharedc_ptr(Image)	m_GameGlowUpperImage;
		sharedc_ptr(Image)	m_GameActiveUpperImage;
	};
}