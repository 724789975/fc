#include "pch.h"

using namespace Core;
using namespace Gui;
using namespace Client;


//---------------------------------------------------------------------------------------
// type info.
//---------------------------------------------------------------------------------------
DEFINE_PDE_TYPE_CLASS(Gui::ModalControlRoot)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::Control);
		ADD_PDE_DEFAULT_CONSTRUCTOR();
		ADD_PDE_EVENT(EventClose);
		ADD_PDE_EVENT(EventTimeUp);
		ADD_PDE_PROPERTY_RW(Timer);
		ADD_PDE_PROPERTY_RW(Icon);
		ADD_PDE_PROPERTY_RW(ContentSize);
		ADD_PDE_METHOD(Close);
	}
};

DEFINE_PDE_TYPE_CLASS(Gui::ModalControl)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::Control);
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_PROPERTY_RW (RootPanel);
		ADD_PDE_PROPERTY_RW(AllowEscToExit);
		ADD_PDE_PROPERTY_RW(AllowF1);
	}
};

REGISTER_PDE_TYPE(Gui::ModalControlRoot);
REGISTER_PDE_TYPE(Gui::ModalControl);

//---------------------------------------------------------------------------------------
// attributes.
//---------------------------------------------------------------------------------------
namespace Gui
{
	ModalControlRoot::ModalControlRoot()
		: m_TimeRunning(0.0f)
		, m_Timer(FLT_MAX)
		, m_Closed(false)
	{
		
	}

	PDE_ATTRIBUTE_GETTER(ModalControlRoot, Icon, tempc_ptr(ProportionIcon))
	{
		return m_Icon;
	}


	PDE_ATTRIBUTE_SETTER(ModalControlRoot, Icon, tempc_ptr(ProportionIcon))
	{
		if (m_Icon != value)
		{
			m_Icon = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(ModalControlRoot, ContentSize, Vector2)
	{
		Vector4 padding = GetPadding();
		return GetSize()-Vector2(padding.x+padding.z, padding.y+padding.w);
	}

	PDE_ATTRIBUTE_SETTER(ModalControlRoot, ContentSize, Vector2)
	{
		Vector4 padding = GetPadding();
		SetSize(value + Vector2(padding.x+padding.z, padding.y+padding.w));
	}

	void ModalControlRoot::OnFrameUpdate(EventArgs & e)
	{
		Super::OnFrameUpdate(e);

		bool bRunning = (m_TimeRunning<=m_Timer);
		F32 timeElapsed = Task::GetFrameTime();
		m_TimeRunning+=timeElapsed;
		if(m_Icon)
		{
			m_Icon->SetProportion(m_TimeRunning/m_Timer);
		}
		if(m_TimeRunning>m_Timer)
		{
			if(bRunning)
				EventTimeUp.Fire(ptr_static_cast<ModalControlRoot>(this), Core::EventArgs());
			Task::Post(NewGenericTask(&ModalControlRoot::Close, ptr_static_cast<ModalControlRoot>(this)));
		}
	}

	void ModalControlRoot::Close()
	{
		if(!m_Closed)
		{
			tempc_ptr(ModalControl) parent = ptr_dynamic_cast<ModalControl>(GetParent());
			if(parent)
			{
				m_Closed = true;
				EventClose.Fire(ptr_static_cast<ModalControlRoot>(this), Core::EventArgs());
				parent->Close();
			}
			else
			{
				PDE_ASSERT(false, "ModalConrolRoot without parent");
			}
		}
	}

	void ModalControlRoot::OnPaint( PaintEventArgs & e )
	{
		Super::OnPaint(e);
		//Draw title
		if(m_Padding.y>0)
		{
			Core::Rectangle bg_rect(GetBackgroundRect());
			e.render->DrawString(GetFont(), ARGB(255,255,255,255), ARGB(0, 0, 0, 0), Core::Rectangle::LeftTop(0, 0, bg_rect.Max.x-bg_rect.Min.x, m_Padding.y), m_Text, Unit::kAlignCenterMiddle);
		}
	}
}

namespace Gui
{
	ModalControl::ModalControl()
		: m_AllowEscToExit(true)
		, m_AllowF1(false)
	{
	}

	ModalControl::~ModalControl()
	{
	}

	void ModalControl::OnCreate()
	{
		Super::OnCreate();
		if(gGame->guiSys)
		{
			SetParent(gGame->guiSys);
			SetSize(gGame->guiSys->GetSize()); //without this, the initial size is too small to cover the whole screen, and onlayout happens
												//in the next frame, between this-next frame, some user can trigger several mouse event which
												//will not be blocked by this modal control
			SetDock(Control::kDockFill);
			SetBackgroundColor(ARGB(32, 0, 0, 0));
		}
		m_RootPanel = ptr_new Gui::ModalControlRoot;
		m_RootPanel->SetParent(ptr_static_cast<Control>(this));
		//m_RootPanel->SetStyle("Gui.ModalWindow");
		m_RootPanel->SetSize(Core::Vector2(600, 180));
		m_RootPanel->SetDock(Control::kDockCenter);
		m_RootPanel->SetFocused(true);
	}

	void ModalControl::OnInputEvent( Client::InputEventArgs &e )
	{
		if (e.IsKeyEvent())
		{
			if (e.Type == InputEventArgs::kKeyDown && e.Code == KC_ESCAPE)
			{
				EventEscPressed.Fire(ptr_static_cast<ModalControl>(this), e);
				if(m_AllowEscToExit)
				{
					m_RootPanel->Close();
				}
				e.Handled = true;
			}
			if (e.Type == InputEventArgs::kKeyDown && e.Code == KC_F1)
			{
				//If there is a modal window on the screen, whether allow the gui to handle F1
				if(!m_AllowF1)
				{
					e.Handled = true;
				}
			}
		}
		if(!e.Handled)
			Super::OnInputEvent(e);
	}

	void ModalControl::Close()
	{
		SetParent(NullPtr);		
	}
}