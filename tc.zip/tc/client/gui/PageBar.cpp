#include "pch.h"

using namespace Core;
using namespace Gui;
using namespace Client;

//Register
DEFINE_PDE_TYPE_CLASS(Gui::PageBarSkin)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::ControlSkin);
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_PROPERTY_RW(ButtonNormalImage);
		ADD_PDE_PROPERTY_RW(ButtonHoverImage);
		ADD_PDE_PROPERTY_RW(ButtonDownImage);
	}
};

DEFINE_PDE_TYPE_CLASS(Gui::PageBar)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::Control);
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_EVENT(EventIndexChanged);

		ADD_PDE_PROPERTY_RW(Index);
		ADD_PDE_PROPERTY_RW(Count);
		ADD_PDE_PROPERTY_RW(ShowCount);
		ADD_PDE_PROPERTY_RW(Gap);
		ADD_PDE_PROPERTY_RW(ArrowWidth);
		ADD_PDE_PROPERTY_RW(ButtonLeftStyle);
		ADD_PDE_PROPERTY_RW(ButtonRightStyle);
	}
};

REGISTER_PDE_TYPE(Gui::PageBarSkin);
REGISTER_PDE_TYPE(Gui::PageBar);

namespace Gui
{
	PageBar::PageBar()
		: m_Index(-1)
		, m_HoverIndex(-1)
		, m_DownIndex(-1)
		, m_Count(1)
		, m_ShowCount(5)
		, m_Gap(4)
		, m_ArrowWidth(19)
		, m_ScrollX(0)
		, m_RightMostIndex(0)
		, m_TargetScrollX(0)
		, m_ButtonLTargetPos(0)
	{

	}

	PageBar::~PageBar()
	{

	}

	PDE_ATTRIBUTE_GETTER(PageBar, Index, int)
	{
		return m_Index-1;
	}
	PDE_ATTRIBUTE_SETTER(PageBar, Index, int)
	{
		ChangeIndexTo(value+1);
	}
	PDE_ATTRIBUTE_GETTER(PageBar, Count, int)
	{
		return m_Count;
	}
	PDE_ATTRIBUTE_SETTER(PageBar, Count, int)
	{
		if(m_Count!=value)
		{
			m_Count = value;
			Init();
		}
	}

	PDE_ATTRIBUTE_GETTER(PageBar, ShowCount, int)
	{
		return m_ShowCount;
	}
	PDE_ATTRIBUTE_SETTER(PageBar, ShowCount, int)
	{
		if(m_ShowCount!=value)
		{
			m_ShowCount = value;
			Init();
		}
	}

	PDE_ATTRIBUTE_GETTER(PageBar, Gap,	F32)
	{
		return m_Gap;
	}
	PDE_ATTRIBUTE_SETTER(PageBar, Gap,	F32)
	{
		if(m_Gap!=value)
		{
			m_Gap = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(PageBar, ArrowWidth, F32)
	{
		return m_ArrowWidth;
	}
	PDE_ATTRIBUTE_SETTER(PageBar, ArrowWidth, F32)
	{
		if(m_ArrowWidth!=value)
		{
			m_ArrowWidth = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(PageBar, ButtonLeftStyle, Core::String)
	{
		if(m_ButtonLeft)
		{
			return m_ButtonLeft->GetStyle();
		}
		return Core::String::kEmpty;
	}
	PDE_ATTRIBUTE_SETTER(PageBar, ButtonLeftStyle, Core::String)
	{
		if(m_ButtonLeft)
		{
			m_ButtonLeft->SetStyle(value);
		}
	}
	
	PDE_ATTRIBUTE_GETTER(PageBar, ButtonRightStyle, Core::String)
	{
		if(m_ButtonRight)
		{
			return m_ButtonRight->GetStyle();
		}
		return Core::String::kEmpty;
	}
	PDE_ATTRIBUTE_SETTER(PageBar, ButtonRightStyle, Core::String)
	{
		if(m_ButtonRight)
		{
			m_ButtonRight->SetStyle(value);
		}
	}

	void PageBar::OnCreate()
	{
		Super::OnCreate();
		m_ButtonLeft = ptr_new Gui::Button;
		m_ButtonLeft->SetParent(ptr_static_cast<Control>(this));
		m_ButtonLeft->SetSize(Vector2(m_ArrowWidth, m_Size.y));
		m_ButtonLeft->EventClick.Subscribe(NewDelegate(&Self::OnButtonLeftClick, ptr_static_cast<Self>(this)));

		m_ButtonRight = ptr_new Gui::Button;
		m_ButtonRight->SetParent(ptr_static_cast<Control>(this));
		m_ButtonRight->SetSize(Vector2(m_ArrowWidth, m_Size.y));
		m_ButtonRight->EventClick.Subscribe(NewDelegate(&Self::OnButtonRightClick, ptr_static_cast<Self>(this)));

		Init();
	}

	void PageBar::Init()
	{
		if(m_Count>=1 && m_ShowCount>=1)
		{
			m_PageWidths.Clear();
			m_PageWidths.Resize(m_Count+1, 0.0f);
			m_PagePositions.Clear();
			m_PagePositions.Resize(m_Count+2, 0.0f);
			for(int i=1; i<=m_Count; i++)
			{
				Core::Rectangle tempRect = Core::Rectangle(0,0,0,0);
				F32 width = GetFont()->MeasureString(tempRect, Core::String::Format("%d", i), -1, Unit::kAlignCenterMiddle).GetExtent().x;
				m_PageWidths[i] = width+6;
				m_PagePositions[i+1] = m_PagePositions[i]+width+6+m_Gap;
			}

			ChangeIndexTo(1, true);
			m_ScrollX = m_TargetScrollX;
			m_Scroll = Vector2(-m_ScrollX, 0);
			m_ButtonRight->SetLocation(Vector2(m_Size.x-m_ArrowWidth-m_Gap-m_ScrollX, 0));
			m_ButtonLeft->SetLocation(Vector2(m_ButtonLTargetPos, 0));
		}

		Invalid();
	}

	void PageBar::OnFrameUpdate( EventArgs & e )
	{
		Super::OnFrameUpdate(e);
		if(Core::Abs(m_TargetScrollX-m_ScrollX)>Core::EPSILON)
		{
			float frameTime = Task::GetFrameTime();
			m_ScrollX = m_TargetScrollX + Pow(0.001f, frameTime) * (m_ScrollX - m_TargetScrollX);

			if(Core::Abs(m_TargetScrollX-m_ScrollX)<1.f)
			{
				m_ScrollX = m_TargetScrollX;
			}
			m_Scroll = Vector2(-m_ScrollX, 0);
			Invalid();
			m_ButtonRight->SetLocation(Vector2(m_Size.x-m_ArrowWidth-m_Gap-m_ScrollX, 0));
		}

		F32 buttonLCurrentPos = m_ButtonLeft->GetLocation().x;
		if(Core::Abs(m_ButtonLTargetPos-buttonLCurrentPos)>Core::EPSILON)
		{
			float frameTime = Task::GetFrameTime();
			//Ani1: Pow
			F32 buttonLNewPos = m_ButtonLTargetPos + Pow(0.001f, frameTime) * (buttonLCurrentPos-m_ButtonLTargetPos);
			if(Core::Floor(buttonLNewPos+0.5f)==Core::Floor(buttonLCurrentPos+0.5f) 
				&& Core::Floor(buttonLCurrentPos+0.5f)!=Core::Floor(m_ButtonLTargetPos+0.5f))
			{
				if(buttonLCurrentPos < m_ButtonLTargetPos)
					buttonLNewPos+=0.5f;
				else
					buttonLNewPos-=0.5f;
			}

			if(Core::Abs(m_ButtonLTargetPos-buttonLNewPos)<1.f)
			{
				buttonLNewPos = m_ButtonLTargetPos;
			}
			m_ButtonLeft->SetLocation(Vector2(buttonLNewPos, 0));
		}

		//Temp bug fix
		Invalid();
	}

	void PageBar::ChangeIndexTo(int index, bool forceUpdate /* = false */)
	{
		bool changed = (m_Index!=index);
		if(index>0 && index<=m_Count && (m_Index!=index||forceUpdate))
		{
			m_Index = index;
			if(m_Index-m_ShowCount/2<=0)
			{
				m_RightMostIndex = m_ShowCount>m_Count?m_Count:m_ShowCount;
			}
			else if(m_Index+m_ShowCount/2<=m_Count)
			{
				m_RightMostIndex = m_Index+m_ShowCount/2;
			}
			else
			{
				m_RightMostIndex = m_Count;
			}
			m_TargetScrollX = m_Size.x-m_ArrowWidth-m_PagePositions[m_RightMostIndex+1];
			m_ButtonLTargetPos = m_PagePositions[GetLeftMostIndex()]-m_Gap-m_ArrowWidth;
			m_TargetScrollX = Core::Floor(m_TargetScrollX+0.5f);
			m_ButtonLTargetPos = Core::Floor(m_ButtonLTargetPos+0.5f);
			
			SetButtonLRVisibility();

			if(changed)		//This statement is necessary because the index may not be changed when force updated
				OnIndexChanged(Core::ValueChangeEventArgs());
		}
	}

	void PageBar::OnInputEvent( Client::InputEventArgs & e )
	{
		if (e.IsMouseEvent())
		{

			Core::Vector2 localPos = ScreenToClient(e.CursorPosition);

			if (localPos.x>m_ButtonRight->GetLocation().x-m_Gap/2 ||
				localPos.x<m_ButtonLeft->GetLocation().x+m_ArrowWidth+m_Gap/2)
			{
				e.Type = InputEventArgs::kMouseLeave;
			}

			switch (e.Type)
			{
			case InputEventArgs::kMouseDown:
				{
					int page = WhichRectContains(localPos);
					if(page>=GetLeftMostIndex() && page<=m_RightMostIndex)
					{
						m_DownIndex = page;
					}
					m_MouseDown = true;
					SetCapture(true);
					Invalid();
					e.Handled = true;
				}
				break;
			case InputEventArgs::kMouseUp:
				{
					int page = WhichRectContains(localPos);
					if(page == m_DownIndex && page>0)
					{
						ChangeIndexTo(page);
					}
					m_DownIndex = -1;
					m_MouseDown = false;
					SetCapture(false);
					Invalid();
					e.Handled = true;
				}
				break;
			case InputEventArgs::kMouseMove:
				{
					if(!m_MouseDown)
					{
						int page = WhichRectContains(localPos);
						if(page>=GetLeftMostIndex() && page<=m_RightMostIndex)
						{
							m_HoverIndex = page;
						}
						else
						{
							m_HoverIndex = -1;
						}
						Invalid();
					}
					e.Handled = true;
				}
				break;
			case InputEventArgs::kMouseLeave:
				{
					m_DownIndex = -1;
					m_MouseDown = false;
					m_HoverIndex = -1;
					Invalid();
				}
				break;
			}
		}
		if(!e.Handled)
			Super::OnInputEvent(e);
	}

	void PageBar::OnPaint( PaintEventArgs & e )
	{
		Super::OnPaint(e);

		Core::Rectangle oldScissor = e.render->GetScissorRect();
		F32 xLength = (m_ButtonRight->GetLocation().x-m_Gap) - (m_ButtonLeft->GetLocation().x+m_ArrowWidth+m_Gap) + m_Gap;
		Core::Rectangle newScissor = Core::Rectangle::LeftTop(ClientToScreen(Vector2(m_ButtonLeft->GetLocation().x+m_ArrowWidth+m_Gap-m_Gap/2, 0)),
			Vector2(xLength, GetSize().y));
		newScissor.IntersectWith(oldScissor);

		e.render->SetScissorRect(newScissor);

		tempc_ptr(PageBarSkin) skin = ptr_static_cast<PageBarSkin>(GetSkin());

		for(int i=1; i<=m_Count; i++)
		{
			Core::Rectangle numRect = Core::Rectangle::LeftTop(m_PagePositions[i], 0, m_PageWidths[i], GetSize().y);
			if(skin)
			{
				Core::ARGB numColor(128,255,255,255);
				if(i==m_DownIndex||i==m_Index)
				{
					Skin::DrawImage(e.render, skin->GetButtonDownImage(), numRect);
					numColor.a = 255;
				}
				else if(i==m_HoverIndex)
				{
					Skin::DrawImage(e.render, skin->GetButtonHoverImage(), numRect);
					numColor.a = 187;
				}
				else
				{
					Skin::DrawImage(e.render, skin->GetButtonNormalImage(), numRect);
				}
				e.render->DrawString(GetFont(), numColor, Core::ARGB(0,0,0,0), numRect, Core::String::Format("%d", i), Unit::kAlignCenterMiddle);
			}
			else
			{
				Core::Rectangle uvRect(0,0,1,1);
				if(i==m_DownIndex||i==m_Index)
				{
					e.render->DrawRectangle(numRect, uvRect, ARGB(255,255,0,0));
				}
				else if(i==m_HoverIndex)
				{
					e.render->DrawRectangle(numRect, uvRect, ARGB(255,255,255,0));
				}
				else
				{
					e.render->DrawRectangle(numRect, uvRect, ARGB(255,255,255,255));
				}
				e.render->DrawString(GetFont(), ARGB(255,0,0,0), Core::ARGB(0,0,0,0), numRect, Core::String::Format("%d", i), Unit::kAlignCenterMiddle);
			}			
		}

		e.render->SetScissorRect(oldScissor);
	}

	void PageBar::OnIndexChanged( ValueChangeEventArgs & e )
	{
		EventIndexChanged.Fire(ptr_static_cast<PageBar>(this), e);
	}

	void PageBar::OnButtonLeftClick( by_ptr(void) sender, InputEventArgs &e )
	{
		m_RightMostIndex = (m_RightMostIndex-m_ShowCount)>m_ShowCount?(m_RightMostIndex-m_ShowCount):(m_ShowCount>m_Count?m_Count:m_ShowCount);
		m_TargetScrollX = m_Size.x-m_ArrowWidth-m_PagePositions[m_RightMostIndex+1];
		m_ButtonLTargetPos = m_PagePositions[GetLeftMostIndex()]-m_Gap-m_ArrowWidth;
		m_TargetScrollX = Core::Floor(m_TargetScrollX+0.5f);
		m_ButtonLTargetPos = Core::Floor(m_ButtonLTargetPos+0.5f);

		SetButtonLRVisibility();
	}

	void PageBar::OnButtonRightClick( by_ptr(void) sender, InputEventArgs &e )
	{
		m_RightMostIndex = (m_RightMostIndex+m_ShowCount)>m_Count?m_Count:(m_RightMostIndex+m_ShowCount);
		m_TargetScrollX = m_Size.x-m_ArrowWidth-m_PagePositions[m_RightMostIndex+1];
		m_ButtonLTargetPos = m_PagePositions[GetLeftMostIndex()]-m_Gap-m_ArrowWidth;
		m_TargetScrollX = Core::Floor(m_TargetScrollX+0.5f);
		m_ButtonLTargetPos = Core::Floor(m_ButtonLTargetPos+0.5f);

		SetButtonLRVisibility();
	}

	F32 PageBar::GetTotalWidth( int start, int end )
	{
		if(start>0 && start<=m_Count && end>0 && end<=m_Count && start<=end)
		{
			return m_PagePositions[end+1]-m_PagePositions[start]-m_Gap;
		}
		else
		{
			return 0.0f;
		}
	}

	int PageBar::GetLeftMostIndex()
	{
		return (m_RightMostIndex-m_ShowCount+1)>0?(m_RightMostIndex-m_ShowCount+1):1;
	}

	int PageBar::WhichRectContains( Core::Vector2 cursorPosi )
	{
		if(cursorPosi.x<0 || cursorPosi.y<0.f || cursorPosi.y>GetSize().y)
		{
			return -1;
		}
		int i=m_Count+1;
		for(; i>0; i--)
		{
			if(m_PagePositions[i]<=cursorPosi.x)
			{
				break;
			}
		}
		if(i<=m_Count && m_PagePositions[i]<=cursorPosi.x && m_PagePositions[i]+m_PageWidths[i]>=cursorPosi.x)
		{
			return i;
		}
		return -1;
	}

	bool PageBar::IsLeftMost()
	{
		if(GetLeftMostIndex()<=1)
			return true;
		else
			return false;
	}

	bool PageBar::IsRightMost()
	{
		if(m_RightMostIndex>=m_Count)
			return true;
		else
			return false;
	}

	void PageBar::SetButtonLRVisibility()
	{
		if(IsLeftMost())
			m_ButtonLeft->SetVisible(false);
		else
			m_ButtonLeft->SetVisible(true);
		if(IsRightMost())
			m_ButtonRight->SetVisible(false);
		else
			m_ButtonRight->SetVisible(true);
	}

	void PageBar::OnSizeChanged( ResizeEventArgs & e )
	{
		Super::OnSizeChanged(e);
		m_ButtonLeft->SetSize(Vector2(m_ArrowWidth, m_Size.y));
		m_ButtonRight->SetSize(Vector2(m_ArrowWidth, m_Size.y));
		ChangeIndexTo(m_Index, true);
	}
}