namespace Gui
{
	class MailItem : public Control
	{
		DECLARE_PDE_OBJECT(MailItem,Control);
	public:
		DECLARE_PDE_EVENT(EventSelectedChanged,	Core::EventArgs);

	public:
		DECLARE_PDE_ATTRIBUTE_RW(Selected,			bool);
		INLINE_PDE_GUI_ATTRIBUTE_RW(Check,			bool);
		INLINE_PDE_GUI_ATTRIBUTE_RW(Unread,			bool);
		SIMPLE_PDE_ATTRIBUTE_RW(ID,					U32);
		INLINE_PDE_GUI_ATTRIBUTE_RW(Title,			Core::String);
		INLINE_PDE_GUI_ATTRIBUTE_RW(Content,		Core::String);
		INLINE_PDE_GUI_ATTRIBUTE_RW(Date,			Core::String);
		INLINE_PDE_GUI_ATTRIBUTE_RW(Icon,			tempc_ptr(Icon));

	public:
		MailItem(void);

		~MailItem(void);

	public:
		virtual void OnPaint(PaintEventArgs & e);

		virtual void OnInputEvent(Client::InputEventArgs & e);

		virtual void OnSelectedChanged(Core::EventArgs & e);

	private:
		bool				m_Selected	:1;
		bool				m_Check		:1;
		bool				m_Unread	:1;
		Core::String		m_Title;
		Core::String		m_Content;
		Core::String		m_Date;
		sharedc_ptr(Icon)	m_Icon;
		Core::Rectangle		m_CheckRect;
	};
}

namespace Gui
{
	class MailItemSkin : public ControlSkin
	{
	public:
		INLINE_PDE_ATTRIBUTE_RW(CheckIcon,		tempc_ptr(Icon));
		INLINE_PDE_ATTRIBUTE_RW(UncheckIcon,	tempc_ptr(Icon));
		INLINE_PDE_ATTRIBUTE_RW(SelectedImage,	tempc_ptr(Image));

	private:
		sharedc_ptr(Icon)		m_CheckIcon;
		sharedc_ptr(Icon)		m_UncheckIcon;
		sharedc_ptr(Image)		m_SelectedImage;
	};
}