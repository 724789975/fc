
namespace Gui
{
	class Header;

	/// base class of ui elements
	class ListView : public ScrollableControl
	{
		DECLARE_PDE_OBJECT(ListView, ScrollableControl)

		static const S32 INDEX_NONE = -1;
	public:
		ListView();
		~ListView();

	public:
		DECLARE_PDE_EVENT(EventListClick,				InputEventArgs);
		DECLARE_PDE_EVENT(EventSelectChange,			EventArgs);
		DECLARE_PDE_EVENT(EventDelete,					InputEventArgs);
		DECLARE_PDE_EVENT(EventItemChange,				EventArgs);

	public:
		DECLARE_PDE_ATTRIBUTE_RW	(SelectedIndex,		S32);
		DECLARE_PDE_ATTRIBUTE_RW	(BorderVisible,		bool);
		DECLARE_PDE_ATTRIBUTE_RW	(MultiSelect,		bool);

		DECLARE_PDE_ATTRIBUTE_R		(ItemCount,			U32);
		DECLARE_PDE_ATTRIBUTE_R		(Columns,			sharedc_ptr(Header));

		OVERRIDE_PDE_ATTRIBUTE_R	(DisplayPadding,	Core::Vector4);

	public:
		virtual void OnCreate();

		virtual void OnFrameUpdate(EventArgs & e);

		virtual void OnLayout(EventArgs & e);

		virtual void OnPaint(PaintEventArgs & e);

        virtual void OnInputEvent(InputEventArgs & e);

		virtual void OnListClick(InputEventArgs & e);

		virtual void OnItemSelectedChanged(EventArgs & e);

		virtual void OnDelete(InputEventArgs & e);

		virtual void OnItemChange(EventArgs & e);

		/// on active changed
		virtual void OnActiveChanged(EventArgs & e);

	private:
		void Header_OnItemChange(tempc_ptr(Core::Object) sender, EventArgs & e);

	public:
		/// Gets item array.
		Core::Array<sharedc_ptr(ListItem)> & Items() { return m_Items; }

		virtual sharedc_ptr(ListItem) CreateItem();

		/// Adds a new item.
		U32 AddItem(const Core::String & value);

		/// Adds subitem.
		void AddSubItem(U32 index, const Core::String & value);

		/// Index to item.
		sharedc_ptr(ListItem) IndexToItem(U32 index);

		/// Item to index.
		U32 ItemToIndex(sharedc_ptr(ListItem) item);


		void ToggleSelect(U32 index);


		bool IsSelected(U32 index);

		void SetSelect(U32 index, bool flag = true);

		void ClearSelection();

		void AddColumn(const Core::String & string);

		Core::String GetItemText(U32 row, U32 column);

		F32 GetDisplayWidth();

		void Clear();

        sharedc_ptr(ListItem) AddStringItem(const Core::String & value);

		void AddStringSubItem(sharedc_ptr(ListItem) item, const Core::String & value);

	private:
		S32									m_SelectedIndex;
		U32									m_LastIndex;
		bool								m_BorderVisible	: 1;
		bool								m_MultiSelect	: 1;
		bool								m_Selecting		: 1;
		Core::Rectangle						m_SelectRect;
		Core::Array<sharedc_ptr(ListItem)>	m_Items;
		sharedc_ptr(Header)					m_Header;
	};
}