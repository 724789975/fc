namespace Gui
{
	class ListItemSPA: public ListItem
	{
		//Special Uses for special sub classes
	public:
		enum SPAStates
		{
			kSPAStateNormal,
			kSPAStateClose,
			kSPAStateView,
		};

	public:
		DECLARE_PDE_OBJECT(ListItemSPA, ListItem);

	public:
		OVERRIDE_PDE_ATTRIBUTE_W(Parent,		tempc_ptr(ListItem));
		DECLARE_PDE_ATTRIBUTE_RW(ComboVisible,	bool);
		DECLARE_PDE_ATTRIBUTE_RW(SpaStates,		SPAStates);
		DECLARE_PDE_ATTRIBUTE_RW(Booked,		bool);
	public:
		ListItemSPA();
		void OnCreate();
		void OnDestroy();

	protected:
		SPAStates				m_SpaStates;
		bool					m_Booked;
		sharedc_ptr(ComboBox)	m_comboBox;
	};
}

namespace Gui
{
	class ListTreeViewSPA: public ListTreeView
	{
	public:
		DECLARE_PDE_OBJECT(ListTreeViewSPA, ListTreeView);
		DECLARE_PDE_ATTRIBUTE_RW(IsHost,		bool);
		DECLARE_PDE_ATTRIBUTE_RW(ComboVisible,	bool);

	public:
		DECLARE_PDE_EVENT(EventItemOpen, ListItemEventArgs);
		DECLARE_PDE_EVENT(EventItemClose, ListItemEventArgs);
		DECLARE_PDE_EVENT(EventItemView, ListItemEventArgs);
	public:
		ListTreeViewSPA();
		~ListTreeViewSPA();
		virtual void OnFrameUpdate(EventArgs & e);
		virtual void OnInputEvent(InputEventArgs & e);
		virtual void OnPaint(PaintEventArgs & e);
		virtual void OnComboBoxValueChanged(by_ptr(void) sender, EventArgs & e);

		/// Adds a new item.
		sharedc_ptr(ListItem) AddItem(tempc_ptr(ListItem) parent, const Core::String & value);

		void	OpenItem(tempc_ptr(ListItem) openItem);
		void	CloseItem(tempc_ptr(ListItem) closeItem);
		void	SetItemToView(tempc_ptr(ListItem) tpItem);
		void	SetItemBooked(tempc_ptr(ListItem) tpItem, bool bBooked);
		void	SetItemMyself(tempc_ptr(ListItem) tpItem, bool bSelf);
	protected:
		bool					m_IsHost;
		bool					m_ComboVisible;
	};
}