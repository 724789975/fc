#include "pch.h"

using namespace Core;
using namespace Gui;
using namespace Client;

DEFINE_PDE_TYPE_CLASS(Gui::ListItemSPA)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::ListItem);
		ADD_PDE_DEFAULT_CONSTRUCTOR();
	}
};

DEFINE_PDE_TYPE_CLASS(Gui::ListTreeViewSPA)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::ListTreeView);
		ADD_PDE_DEFAULT_CONSTRUCTOR();
		ADD_PDE_EVENT(EventItemOpen);
		ADD_PDE_EVENT(EventItemClose);
		ADD_PDE_EVENT(EventItemView);
		ADD_PDE_PROPERTY_RW(IsHost);
		ADD_PDE_PROPERTY_RW(ComboVisible);
		ADD_PDE_METHOD(OpenItem);
		ADD_PDE_METHOD(CloseItem);
		ADD_PDE_METHOD(SetItemToView);
		ADD_PDE_METHOD(SetItemBooked);
		ADD_PDE_METHOD(SetItemMyself);
	}
};

REGISTER_PDE_TYPE(Gui::ListItemSPA);
REGISTER_PDE_TYPE(Gui::ListTreeViewSPA);

namespace Gui
{
	ListItemSPA::ListItemSPA()
		: m_SpaStates(kSPAStateNormal)
		, m_Booked(false)
	{

	}

	PDE_ATTRIBUTE_SETTER(ListItemSPA, Parent, tempc_ptr(ListItem))
	{
		if(value)
		{
			Super::SetParent(value);
			m_comboBox->SetParent(GetOwner());
			tempc_ptr(ListTreeViewSPA) tree = ptr_dynamic_cast<ListTreeViewSPA>(GetOwner());		
			if(tree)
			{
				U32 sIndex = tree->ItemToDisplayIndex(ptr_static_cast<ListItem>(this));		
				F32 sPosY = (sIndex+1)*(tree->GetItemHeight() + tree->GetItemGap())+2;
				F32 sPosX = tree->GetSize().x-70;
				m_comboBox->SetLocation(Core::Vector2(sPosX, sPosY));
				m_comboBox->SetTag(ptr_static_cast<void>(this));
				m_comboBox->EventValueChanged.Subscribe(NewDelegate(&ListTreeViewSPA::OnComboBoxValueChanged, tree));
			}
		}
		else
		{
			m_comboBox->SetTag(NullPtr);
			m_comboBox->SetParent(NullPtr);
			Super::SetParent(value);
		}
	}

	PDE_ATTRIBUTE_GETTER(ListItemSPA, ComboVisible, bool)
	{
		return m_comboBox->GetVisible();
	}

	PDE_ATTRIBUTE_SETTER(ListItemSPA, ComboVisible, bool)
	{
		m_comboBox->SetVisible(value);
	}

	PDE_ATTRIBUTE_GETTER(ListItemSPA, SpaStates,  ListItemSPA::SPAStates)
	{
		return m_SpaStates;
	}

	PDE_ATTRIBUTE_SETTER(ListItemSPA, SpaStates,  ListItemSPA::SPAStates)
	{
		if(m_SpaStates!=value)
		{
			m_SpaStates = value;
			tempc_ptr(Control) tree = GetOwner();
			if(tree)
			{
				tree->Invalid();
			}
		}
	}

	PDE_ATTRIBUTE_GETTER(ListItemSPA, Booked,  bool)
	{
		return m_Booked;
	}

	PDE_ATTRIBUTE_SETTER(ListItemSPA, Booked,  bool)
	{
		if(m_Booked!=value)
		{
			m_Booked = value;
			SetSpecialA(m_Booked);
			tempc_ptr(Control) tree = GetOwner();
			if(tree)
			{
				tree->Invalid();
			}
		}
	}
	void ListItemSPA::OnCreate()
	{
		Super::OnCreate();
		m_comboBox = ptr_new Gui::ComboBox;
		m_comboBox->SetSize(Core::Vector2(30,30));
		m_comboBox->SetDropDownWidth(50);
		m_comboBox->SetTextColor(Core::ARGB(0,255,255,255));
		m_comboBox->SetReadonly(true);
		m_comboBox->SetStyle("Gui.ComboBoxForSPA");
		m_comboBox->AddItem(gLang->GetTextW(L"��"));
		m_comboBox->AddItem(gLang->GetTextW(L"��"));
		m_comboBox->AddItem(gLang->GetTextW(L"��ս"));
		m_comboBox->SetVisible(false);
	}

	void ListItemSPA::OnDestroy()
	{
		Super::OnDestroy();
	}
}

namespace Gui
{
	ListTreeViewSPA::ListTreeViewSPA()
		: m_IsHost(false)
		,m_ComboVisible(true)
	{
	}

	ListTreeViewSPA::~ListTreeViewSPA()
	{

	}

	PDE_ATTRIBUTE_GETTER(ListTreeViewSPA, ComboVisible, bool)
	{
		return m_ComboVisible;
	}

	PDE_ATTRIBUTE_SETTER(ListTreeViewSPA, ComboVisible, bool)
	{
		m_ComboVisible = value;
	}


	PDE_ATTRIBUTE_GETTER(ListTreeViewSPA, IsHost, bool)
	{
		return m_IsHost;
	}

	PDE_ATTRIBUTE_SETTER(ListTreeViewSPA, IsHost, bool)
	{
		if(m_IsHost!=value)
		{
			m_IsHost = value;
			for (tempc_ptr(ListItem) node = m_RootItem->GetFirstChild(); node; node = node->GetNextNode(true))
			{
				tempc_ptr(ListItemSPA) nodeSP = ptr_dynamic_cast<ListItemSPA>(node);
				nodeSP->SetComboVisible(m_IsHost);
			}
		}
	}

	void ListTreeViewSPA::OnFrameUpdate( EventArgs & e )
	{
		Super::OnFrameUpdate(e);
	}

	void ListTreeViewSPA::OnInputEvent( InputEventArgs & e )
	{
		Super::OnInputEvent(e);
	}

	void ListTreeViewSPA::OnPaint( PaintEventArgs & e )
	{
		ScrollableControl::OnPaint(e);

		tempc_ptr(ListTreeViewSkin) skin = ptr_dynamic_cast<ListTreeViewSkin>(GetSkin());

		F32 allWidth = m_Header->GetAllWidth();
		F32 width = Max(GetSize().x, allWidth);

		bool flag = false;
		S32 index = 0;

		Core::Rectangle displayRect = GetDisplayRect();
		Core::Rectangle selectRect;
		Core::Rectangle textRect;
		DrawItemEventArgs drawEvent(e);

		// to items space
		Matrix44 world_backup = e.render->GetWorld();
		Core::Rectangle scissorRect = GetDisplayRect();

		if (m_Header->GetVisible())
		{
			float header_height = m_Header->GetSize().y;

			scissorRect.Max.y -= header_height;
			world_backup.TranslateLocalXYZ(0, header_height, 0);
			e.render->SetWorld(world_backup);
		}

		e.render->AddScissorRectWithWorldMatrix(scissorRect);
		scissorRect = e.render->GetScissorRect();

		for (tempc_ptr(ListItem) item = m_RootItem->GetFirstChild(); item; item = item->GetNextNode(flag))
		{
			flag = !m_TreeVisible || !item->GetExpanded();
			if ((index + 1) * (m_ItemHeight+m_ItemGap) >= displayRect.Min.y && displayRect.Max.y >= index*(m_ItemHeight+m_ItemGap)+m_ItemGap)
			{
				selectRect = Core::Rectangle(0, (m_ItemHeight+m_ItemGap)*index+m_ItemGap, width, (m_ItemHeight+m_ItemGap)*(index + 1));

				bool selected = item->GetSelected();

				//draw gird lines
				if (m_GridLines)
					e.render->DrawLine2d(Core::Vector2(0, (m_ItemHeight+m_ItemGap) * index + 1), Core::Vector2(GetDisplayRect().Max.x, (m_ItemHeight+m_ItemGap) * index + 1), skin?skin->GetGridLineColor():XRGB(255,0,0));

				// move world matrix to selection space
				Matrix44 world = world_backup;
				world.TranslateLocal(Vector3(selectRect.Min, 0));
				e.render->SetWorld(world);

				// move selection to world space
				Core::Rectangle local_select_rect(Vector2::kZero, selectRect.GetExtent());

				if (m_GridLines)
					local_select_rect.Min.y += 1;

				// update scissor
				e.render->SetScissorRect(scissorRect);
				e.render->AddScissorRectWithWorldMatrix(local_select_rect);
				if (e.render->GetScissorRect().IsEmpty())
				{
					++index;
					continue;
				}

				// draw item background
				drawEvent.Handled = false;
				drawEvent.Item = item;
				drawEvent.ItemSkin = m_ItemSkin;
				drawEvent.Rect = local_select_rect;
				drawEvent.Selected = selected;
				drawEvent.Row = index;
				OnDrawItemBackgroud(drawEvent);

				U32 count = m_Header->GetItemCount();

				tempc_ptr(ListItemSPA) itemSP = ptr_static_cast<ListItemSPA>(item);
				itemSP->SetComboVisible(m_ComboVisible);
				switch(itemSP->GetSpaStates())
				{
				case ListItemSPA::kSPAStateClose:
					{
						/*e.render->DrawString(GetFont(), 
							(selected&&itemSP->GetCanSelect())?Core::ARGB(255,0,0,0):Core::ARGB(255, 144, 144, 144)
							, Core::ARGB(0,0,0,0), local_select_rect, gLang->GetTextW(L"��  ��"), Client::Unit::kAlignCenterMiddle);*/
					}
					break;
				case ListItemSPA::kSPAStateView:
					{
					  /*	if(item->GetText(1)==Core::String::kEmpty)
						{
							e.render->DrawString(GetFont(), (selected&&itemSP->GetCanSelect())?Core::ARGB(255,0,0,0):Core::ARGB(255, 144, 144, 144)
								, Core::ARGB(0,0,0,0), local_select_rect, gLang->GetTextW(L"��  ս"), Client::Unit::kAlignCenterMiddle);
						}
						*/
					}
					break;
				}
				for (U32 j=0; j<count; ++j)
				{
					U32 columnIndex = m_Header->IndexToDisplayIndex(j);
					if (columnIndex < count)
					{
						/// draw grid lines
						if (m_GridLines)
						{
							F32 pos = m_Header->GetPos(j) + m_Header->GetWidth(j) - BORDER_WIDTH;
							F32 height =/* Min(GetDisplayRect().Max.y, GetDisplayCount() * m_ItemHeight)*/(m_ItemHeight+m_ItemGap);
							e.render->DrawLine2d(Core::Vector2(pos, 0), Core::Vector2(pos, height), skin?skin->GetGridLineColor():XRGB(255,0,0));
						}

						textRect = selectRect;
						textRect.Min.x = m_Header->GetPos(j);
						textRect.Max.x = textRect.Min.x + m_Header->GetWidth(j);
						//textRect.Shrink(SPLIT_WIDTH, 0, SPLIT_WIDTH, 0);

						Matrix44 world = world_backup;
						world.TranslateLocal(Vector3(textRect.Min, 0));
						e.render->SetWorld(world);
						textRect.Move(-textRect.Min);
						e.render->SetScissorRect(scissorRect);
						e.render->AddScissorRectWithWorldMatrix(textRect);

						if (e.render->GetScissorRect().IsEmpty())
						{
							continue;
						}

						if (m_TreeVisible && columnIndex == 0)
						{
							textRect.Shrink((1 + item->GetLevel()) * LEVELSPACE , 0, 0, 0);
							DisplayNodeDashed(e.render, item, index);
						}

						drawEvent.Handled = false;
						drawEvent.Column = j;
						drawEvent.Rect = textRect;
						drawEvent.Align = m_Header->GetAlign(j);
						drawEvent.Font = GetFont();
						tempc_ptr(ListItemSPA) itemSP = ptr_static_cast<ListItemSPA>(item);
						switch(itemSP->GetSpaStates())
						{
						case ListItemSPA::kSPAStateNormal:
							{
								OnDrawItem(drawEvent);							
							}
							break;
						case ListItemSPA::kSPAStateView:
							{						
									OnDrawItem(drawEvent);
							}
							break;
						case ListItemSPA::kSPAStateClose:
							{
								OnDrawItem(drawEvent);							
							}
							break;
						}
					}
				}
				//Restore scissor rect
				e.render->SetWorld(world_backup);
				e.render->SetScissorRect(scissorRect);
			}
			++index;
		}

		if (GetActive() && m_SelectingIndex < GetDisplayCount())
		{
			Core::Rectangle brokenRect(Core::Vector2(0, m_ItemHeight * m_SelectingIndex), Core::Vector2(allWidth - 1, m_ItemHeight * (m_SelectingIndex + 1) - 1));
		}
	}

	void ListTreeViewSPA::OnComboBoxValueChanged( by_ptr(void) sender, EventArgs & e )
	{
		ListItemEventArgs le;
		tempc_ptr(ComboBox) cBox = ptr_dynamic_cast<ComboBox>(sender);
		if(!cBox)
			return;
		tempc_ptr(ListItem) opItem = ptr_dynamic_cast<ListItem>(cBox->GetTag());
		if(!opItem)
			return;
		le.Item = opItem;
		S32 index = cBox->GetSelectedIndex();

		//clear the select state, enable all options for next-time op
		cBox->SetSelectedIndex(-1);

		switch(index)
		{
		case 0:
			{
				EventItemOpen.Fire(ptr_static_cast<ListTreeViewSPA>(this), le);
			}
			break;
		case 1:
			{
				EventItemClose.Fire(ptr_static_cast<ListTreeViewSPA>(this), le);
			}
			break;
		case 2:
			{
				EventItemView.Fire(ptr_static_cast<ListTreeViewSPA>(this), le);
			}
			break;
		default:
			break;
		}
	}

	sharedc_ptr(ListItem) ListTreeViewSPA::AddItem(tempc_ptr(ListItem) parent, const Core::String & string)
	{
		if (parent)
		{
			sharedc_ptr(ListItem) item = ptr_new ListItemSPA;

			if (item)
			{
				item->SetColumnCount(m_Header->GetItemCount());
				item->SetText(0, string);
				item->SetParent(parent);
				item->SetLevel(parent->GetLevel() + 1);

				EventArgs e;
				OnItemChange(e);

				if (m_AutoColumnSize)
					AutoColumnSize(0);

				DirtyLayout();
			}

			return item;
		}
		return NullPtr;
	}

	void ListTreeViewSPA::OpenItem( tempc_ptr(ListItem) openItem )
	{
		if(openItem)
		{
			tempc_ptr(ListItemSPA) itemSP = ptr_dynamic_cast<ListItemSPA>(openItem);
			if(itemSP)
			{
				itemSP->SetSpaStates(ListItemSPA::kSPAStateNormal);
			}
		}
	}
	void ListTreeViewSPA::CloseItem( tempc_ptr(ListItem) closeItem )
	{
		if(closeItem)
		{
			ListItemEventArgs le;
			tempc_ptr(ListItemSPA) itemSP = ptr_dynamic_cast<ListItemSPA>(closeItem);
			if(itemSP)
			{
				itemSP->SetSpaStates(ListItemSPA::kSPAStateClose);
				le.Item = itemSP;
				EventItemClose.Fire(ptr_static_cast<ListTreeViewSPA>(this), le);
			}
		}
	}

	void ListTreeViewSPA::SetItemToView( tempc_ptr(ListItem) tpItem )
	{
		if(tpItem)
		{	
			ListItemEventArgs le;
			tempc_ptr(ListItemSPA) itemSP = ptr_dynamic_cast<ListItemSPA>(tpItem);
			if(itemSP)
			{
				itemSP->SetSpaStates(ListItemSPA::kSPAStateView);
				le.Item = itemSP;
				EventItemView.Fire(ptr_static_cast<ListTreeViewSPA>(this),le);
			}
		}
	}

	void ListTreeViewSPA::SetItemMyself( tempc_ptr(ListItem) tpItem, bool bSelf )
	{
		if(tpItem)
		{
			tpItem->SetWithFrame(bSelf);
		}
	}

	void ListTreeViewSPA::SetItemBooked(tempc_ptr(ListItem) tpItem, bool bBooked)
	{
		if(tpItem)
		{
			tempc_ptr(ListItemSPA) itemSP = ptr_dynamic_cast<ListItemSPA>(tpItem);
			if(itemSP)
			{
				itemSP->SetBooked(bBooked);
			}
		}
	}
}