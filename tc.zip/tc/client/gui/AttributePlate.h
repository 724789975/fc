namespace Gui
{
	class AttributePlate : public Control
	{
		struct Attribute 
		{
			Attribute(const Core::String& name, Client::Unit::Align align,const F32 size)
				: Name(name)
				, Align(align)
				, Size(size)
			{

			}
			Core::String		Name;
			Client::Unit::Align	Align;
			F32					Size;
		};
	public:
		DECLARE_PDE_OBJECT(AttributePlate, Control);
	public:
		DECLARE_PDE_ATTRIBUTE_RW(Count,					U32);
		DECLARE_PDE_ATTRIBUTE_RW(MaxValue,				U32);
		DECLARE_PDE_ATTRIBUTE_RW(NameWidth,				F32);
		DECLARE_PDE_ATTRIBUTE_RW(TipTextColor,			Core::ARGB);
		DECLARE_PDE_ATTRIBUTE_RW(OutsideLineColor,		Core::ARGB);
		DECLARE_PDE_ATTRIBUTE_RW(InsideLineColor,		Core::ARGB);
		DECLARE_PDE_ATTRIBUTE_RW(OutsidePolygonColor,	Core::ARGB);
		DECLARE_PDE_ATTRIBUTE_RW(InsidePolygonColor,	Core::ARGB);

	public:
		AttributePlate();
		~AttributePlate();
		void OnPaint(PaintEventArgs& e);
		void OnInputEvent(InputEventArgs & e);
		void OnLayout(EventArgs & e);
		void AddAttribute(const Core::String& attributeName,Client::Unit::Align attributeNameAlign,const F32 attributeSize);
		void Clear();
	private:
		U32							m_Count;
		U32							m_MaxValue;
		F32							m_NameWidth;
		S32							m_PointedVertex;
		Core::ARGB					m_TipTextColor;
		Core::ARGB					m_OutsideLineColor;
		Core::ARGB					m_InsideLineColor;
		Core::ARGB					m_OutsidePolygonColor;
		Core::ARGB					m_InsidePolygonColor;
		Core::Array<S32>			m_aMultiSelectedIdx;
		Core::Array<Core::Vector2>	m_aOutsideVertexs;
		Core::Array<Core::Vector2>  m_aInsideVertexs;
		Core::Array<Attribute>		m_aAttributes;
	};
}