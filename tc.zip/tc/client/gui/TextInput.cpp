#include "pch.h"

using namespace Core;
using namespace Client;

static inline bool IsCharacter(CHAR ch)
{
	return (ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z') || (ch >= '0' && ch <= '9') || ch == '_';
}

namespace Gui
{
	TextInput::TextInput()
		: m_TextBuffer(NULL)
		, m_CursorPosition(0)
		, m_SelectionStart(0)
		, m_SelectionEnd(0)
		, m_Multiline(false)
		, m_Selecting(false)
		, m_AcceptTab(false)
		, m_AcceptReturn(false)
	{
	}

	TextInput::~TextInput()
	{
	}
}

//--------------------------------------------------------------------------------------
// Attribute
//--------------------------------------------------------------------------------------'
namespace Gui
{
	PDE_ATTRIBUTE_GETTER(TextInput, TextBuffer, Core::String *)
	{
		return m_TextBuffer;
	}

	PDE_ATTRIBUTE_SETTER(TextInput, TextBuffer, Core::String *)
	{
		m_TextBuffer = value;
		OnTextChanged(Core::EventArgs());
	}

	PDE_ATTRIBUTE_GETTER(TextInput, Multiline, bool)
	{
		return m_Multiline;
	}

	PDE_ATTRIBUTE_SETTER(TextInput, Multiline, bool)
	{
		m_Multiline = value;
	}

	PDE_ATTRIBUTE_GETTER(TextInput, Selecting, bool)
	{
		return m_Selecting;
	}

	PDE_ATTRIBUTE_GETTER(TextInput, AcceptTab, bool)
	{
		return m_AcceptTab;
	}

	PDE_ATTRIBUTE_SETTER(TextInput, AcceptTab, bool)
	{
		m_AcceptTab = value;
	}

	PDE_ATTRIBUTE_GETTER(TextInput, AcceptReturn, bool)
	{
		return m_AcceptReturn;
	}

	PDE_ATTRIBUTE_SETTER(TextInput, AcceptReturn, bool)
	{
		m_AcceptReturn = value;
	}
}

//--------------------------------------------------------------------------------------
// Event
//--------------------------------------------------------------------------------------
namespace Gui
{
	/// on key event
	bool TextInput::OnKeyEvent(InputEventArgs & input, bool readonly, tempc_ptr(Client::Font) font)
	{
		bool handled = false;

		// no text buffer
		if (m_TextBuffer == NULL)
			return handled;

		// key down
		if (input.Type == InputEventArgs::kKeyDown)
		{
			switch (input.Code)
			{
			case KC_LEFT:
				{
					const CHAR * text = m_TextBuffer->Str();
					const CHAR * start = text + GetCursorPosition() - 1;

					if (input.ControlKeyDown)
					{
						if (IsCharacter(start[0]))
						{
							while (start > text && IsCharacter(start[-1]))
								start --;
						}
					}

					if (start > text)
						SetCursorPosition(start - text, input.ShiftKeyDown);
					else
						SetCursorPosition(0, input.ShiftKeyDown);
				}

				handled = true;
				break;

			case KC_RIGHT:
				{
					const CHAR * text = m_TextBuffer->Str();
					const CHAR * end = text + GetCursorPosition();
#ifdef USE_UTF8
					S32 len = GetUTF8CharLength((U8*)end, -1);
					if (len)
					{
						end += len;
					}
#else
					if (IsDBCSLeadByteEx(936, *end))
						end += 2;
					else
						end += 1;
#endif
					if (input.ControlKeyDown)
					{
						if (IsCharacter(end[0]))
						{
							while (IsCharacter(end[1]))
								end ++;
						}
					}

					SetCursorPosition(end - text, input.ShiftKeyDown);
				}

				handled = true;
				break;


			case KC_UP:
				if (m_Multiline)
				{
					const CHAR* UpText = NULL;
					const CHAR* start = m_TextBuffer->Str();
					const CHAR* text = start + GetCursorPosition();
					const CHAR* s = start + GetCursorPosition();

					while (text > start && text[-1] != '\n')
						--text;

					if(text > start && text[-1] != NULL)
					{
						UpText = &text[-1];
						--UpText;
						while (UpText > start && UpText[-1] != '\n')
							--UpText;
					}
					else
						return false;
					
					F32 width = 0;
#ifdef USE_UTF8
					while(text < s)
					{
						U16 letter = 0;
						S32 len = GetUTF8CharLength((U8*)text, -1);
						if (len)
						{
							UTF8toUTF16((U8*)text, len, &letter, 1);
							text += len;
						}
						else
						{
							//try skip invaild utf8 char
							text++;
							continue;
						}
						const Font::CharInfo & info = font->GetCharacterInfo(letter);
						width += info.horiAdvance + font->GetCharSpace();
					}
#else
					while(text < s)
					{
						U16 letter = *text++;
						if (IsDBCSLeadByteEx(936, letter))
						{
							letter = (letter << 8) | (U8)*text++;
						}
						const Font::CharInfo & info = font->GetCharacterInfo(letter);
						width += info.horiAdvance + font->GetCharSpace();
					}
#endif
					F32 cutwidth = 0;
					s = UpText;
					while(UpText[0] != 0 && UpText[0] != '\n')
					{
#ifdef USE_UTF8
						U16 letter = 0;
						S32 len = GetUTF8CharLength((U8*)s, -1);
						if (len)
						{
							UTF8toUTF16((U8*)s, len, &letter, 1);
							s += len;
						}
						else
							break;
#else
						U16 letter = *s++;
						if (IsDBCSLeadByteEx(936, letter))
						{
							letter = (letter << 8) | (U8)*s++;
						}
#endif
						const Font::CharInfo & info = font->GetCharacterInfo(letter);
						F32 charlen = info.horiAdvance + font->GetCharSpace();
						if(cutwidth < width)
						{
							UpText = s;
						}
						else 
							break;
						cutwidth += charlen;
					}

					SetCursorPosition(UpText - start, input.ShiftKeyDown);

					handled = true;
				}
				break;

			case KC_DOWN:
				if (m_Multiline)
				{
					const CHAR* DownText = NULL;
					const CHAR* start = m_TextBuffer->Str();
					const CHAR* text = start + GetCursorPosition();
					const CHAR* s = start + GetCursorPosition();

					while (text > start && text[-1] != '\n')
						--text;

					DownText = start + GetCursorPosition();
					while (DownText[0] != 0 && DownText[0] != '\n')
						++DownText;
					if (DownText[0] == '\n')
						DownText++;
					else
						return false;


					F32 width = 0;
#ifdef USE_UTF8
					while(text < s)
					{
						U16 letter = 0;
						S32 len = GetUTF8CharLength((U8*)text, -1);
						if (len)
						{
							UTF8toUTF16((U8*)text, len, &letter, 1);
							text += len;
						}
						else
						{
							//try skip invaild utf8 char
							text++;
							continue;
						}
						const Font::CharInfo & info = font->GetCharacterInfo(letter);
						width += info.horiAdvance + font->GetCharSpace();
					}
#else
					while(text < s)
					{
						U16 letter = *text++;
						if (IsDBCSLeadByteEx(936, letter))
						{
							letter = (letter << 8) | (U8)*text++;
						}
						const Font::CharInfo & info = font->GetCharacterInfo(letter);
						width += info.horiAdvance + font->GetCharSpace();
					}
#endif
					F32 cutwidth = 0;
					s = DownText;
					while(DownText[0] != 0 && DownText[0] != '\n')
					{
#ifdef USE_UTF8
						U16 letter = 0;
						S32 len = GetUTF8CharLength((U8*)s, -1);
						if (len)
						{
							UTF8toUTF16((U8*)s, len, &letter, 1);
							s += len;
						}
						else
							break;
#else
						U16 letter = *s++;
						if (IsDBCSLeadByteEx(936, letter))
						{
							letter = (letter << 8) | (U8)*s++;
						}
#endif
						const Font::CharInfo & info = font->GetCharacterInfo(letter);
						F32 charlen = info.horiAdvance + font->GetCharSpace();
						if(cutwidth < width)
						{
							DownText = s;
						}
						else 
							break;
						cutwidth += charlen;

					}

					SetCursorPosition(DownText - start, input.ShiftKeyDown);

					handled = true;
				}
				break;

			case KC_BACK:
				if (!readonly)
				{
					DeleteVirtualEnter();
					if (HasSelection())
					{
						RemoveString(m_SelectionStart, m_SelectionEnd);
					}
					else if (m_CursorPosition > 0)
					{
						RemoveChar(GetCursorPosition() - 1);
					}
					AddVirtualEnter();
				}
				handled = true;
				break;

			case KC_DELETE:
				if (!readonly)
				{

					DeleteVirtualEnter();
					if (HasSelection())
					{
						RemoveString(m_SelectionStart, m_SelectionEnd);
					}
					else
					{
						RemoveChar(m_CursorPosition);
					}
					AddVirtualEnter();
				}

				handled = true;
				break;

			case KC_HOME:
				if (input.ControlKeyDown)
				{
					SetCursorPosition(0, input.ShiftKeyDown);
				}
				else
				{
					const CHAR * start = m_TextBuffer->Str();
					const CHAR * text = start + GetCursorPosition();

					if (text > start && text[-1] != '\t')
					{
						// to line start
						while (text > start && text[-1] != '\n')
							--text;

						while (text[0] == '\t')
							++text;
					}
					else
					{
						// to line start
						while (text > start && text[-1] != '\n' )
							--text;
					}

					SetCursorPosition(text - start, input.ShiftKeyDown);
				}

				handled = true;
				break;

			case KC_END:
				if(input.ControlKeyDown)
				{
					SetCursorPosition(-1, input.ShiftKeyDown);
				}
				else
				{
					const CHAR * start = m_TextBuffer->Str();
					const CHAR * text = start + GetCursorPosition();

					// to line end
					while (text[0] != 0 && text[0] != '\n' )
						++text;

					SetCursorPosition(text - start, input.ShiftKeyDown);
				}
				break;

			case KC_C:
				if (input.ControlKeyDown)
				{
					DeleteVirtualEnter();
					CopyText();
					AddVirtualEnter();
					handled = true;
				}
				break;


			case KC_X:
				if (input.ControlKeyDown)
				{
					if (!readonly)
					{
						DeleteVirtualEnter();
						if (HasSelection())
						{
							CopyText();
							RemoveString(m_SelectionStart, m_SelectionEnd);
						}
						AddVirtualEnter();
					}
					handled = true;
				}
				break;

			case KC_V:
				if (input.ControlKeyDown)
				{
					if (!readonly)
					{
						DeleteVirtualEnter();
						PasteText();
						AddVirtualEnter();
					}
					handled = true;
				}
				break;

			case KC_A:
				{
					if (input.ControlKeyDown)
					{
						SelectAll();
						handled = true;
					}
				}
				break;

			}
		}

		// char
		else if (input.Type == InputEventArgs::kChar)
		{
			if (!readonly)
			{
				if (((wchar_t)input.Value >= 0x20 || (m_Multiline && input.Value == '\r') || (m_AcceptTab && input.Value == '\t')))
				{
					DeleteVirtualEnter();
					// multiline indent
					if (input.Value == '\t' && HasSelection())
					{
						if (Indent(m_SelectionStart, m_SelectionEnd, input.ShiftKeyDown))
							return true;
					}

					if (HasSelection())
					{
						ResetHistory();
						SetHistoryTextOld(m_SelectionStart, m_SelectionEnd);

						m_TextBuffer->RefStr(0).remove(m_SelectionStart, m_SelectionEnd);
						SetCursorPosition(Min(m_SelectionStart, m_SelectionEnd));
					}			

					// auto indent
					if (input.Value == '\r' && m_Multiline)
					{
						NewLine();
					}
					else
					{
						InsertChar(GetCursorPosition(), input.Value == '\r' ? '\n' : input.Value);
					}

					handled = true;
					AddVirtualEnter();
				}
			}
		}

		return handled;
	}

	/// on mouse event
	bool TextInput::OnMouseEvent(InputEventArgs & input, const Vector2 & pos, tempc_ptr(Font) font)
	{
		bool handled = false;

		switch (input.Type)
		{       
		case InputEventArgs::kMouseDown :
			if (input.Code == MC_LEFT_BUTTON)
			{
				size_t cp;

				if (PositionToIndex(font, pos, cp))
				{
					SetCursorPosition(cp, input.ShiftKeyDown);

					if (!HasSelection() && input.ControlKeyDown)
					{
						SelectWord();
					}

					m_Selecting = true;
					handled = true;
				}
			}
			break;


		case InputEventArgs::kMouseUp :
			if (m_Selecting)
			{
				m_Selecting = false;
				handled = true;
			}
			break;


		case InputEventArgs::kMouseMove :
			if (m_Selecting)
			{
				size_t cp;

				if (PositionToIndex(font, pos, cp))
				{
					SetCursorPosition(cp, true);
					handled = true;
				}
				handled = true;
			}
			break;


		case InputEventArgs::kMouseDoubleClick:
			if (input.Code == MC_LEFT_BUTTON)
			{
				if (m_Multiline)
				{
					SelectWord();
				}
				else
				{
					SelectAll();
				}
				handled = true;
			}
			break;
		}

		return handled;
	}

	/// on text changed
	void TextInput::OnTextChanged(EventArgs & e)
	{
	}

	/// on cursor move
	void TextInput::OnCursorMove(EventArgs & e)
	{
	}

	/// on new history
	void TextInput::OnHistoryReset(InputHistory & e)
	{
	}

	void TextInput::DeleteVirtualEnter()
	{
	}

	void TextInput::AddVirtualEnter()
	{
	}
}

//--------------------------------------------------------------------------------------
// Method
//--------------------------------------------------------------------------------------
namespace Gui
{
	/// Set cursor position
	void TextInput::SetCursorPosition(size_t position, bool select)
	{
		if (m_TextBuffer == NULL)
			return;

		position = Clamp(position, 0, m_TextBuffer->Length());

		// gb2312 support
		const char * s = m_TextBuffer->Str();
		const char * t = s + position;
#ifdef USE_UTF8
		while (t > s && !IsUTF8LeadByte(*t))
			t--;

		for (;;)
		{
			int width = GetUTF8CharLength((U8*)t, -1);
			if (!width)
				break;

			if (t + width > s + position)
				break;

			t += width;
		}
#else
		while (t > s && IsDBCSLeadByteEx(936, *(t - 1)))
			t --;

		for (;;)
		{
			int width = IsDBCSLeadByteEx(936, *t) ? 2 : 1;

			if (t + width > s + position)
				break;

			t += width;
		}
#endif
		position = t - s;

		if (select)
		{
			if (m_SelectionStart == m_SelectionEnd)
				m_SelectionStart = m_CursorPosition;

			m_SelectionEnd = position;
		}
		else
		{
			m_SelectionStart = m_SelectionEnd = position;
		}

		m_CursorPosition = position;

		// send cursor move event
		OnCursorMove(EventArgs());
	}

	/// Set cursor position
	size_t TextInput::GetCursorPosition()
	{
		return m_CursorPosition;
	}

	/// move cursor
	void TextInput::MoveCursor(int line, int character, bool select)
	{
		if (m_TextBuffer == NULL)
			return;

		const CHAR * start = m_TextBuffer->Str();
		const CHAR * end = m_TextBuffer->Str() + m_TextBuffer->Length();
		const CHAR * text = start;

		// move to line
		for (int i = 1; i < line && text < end; i ++)
		{
			while (text < end && text[0] != '\n')
				text++;

			if (text[0] == '\n')
				text++;
		}

		// move to character
		for (int i = 1; i < character && text < end && text[0] != '\n'; i ++)
		{
			text ++;
		}

		SetCursorPosition(text - start, select);
	}


	void TextInput::SetSelection(size_t start, size_t end)
	{
		SetCursorPosition(start, false);
		SetCursorPosition(end, true);
	}

	bool TextInput::HasSelection()
	{
		return m_SelectionStart != m_SelectionEnd;
	}

	void TextInput::SelectWord()
	{
		const CHAR * text = m_TextBuffer->Str();
		const CHAR * start = text + m_CursorPosition;
		const CHAR * end = start;

		if (IsCharacter(start[0]))
		{
			while (start > text && IsCharacter(start[-1]))
				start --;

			while (IsCharacter(end[1]))
				end ++;

			SetSelection(start - text, end - text + 1);
		}
	}

	void TextInput::SelectAll()
	{
		SetSelection(0, -1);
	}


	/// copy to clipboard
	void TextInput::CopyText()
	{
		if (m_TextBuffer == NULL)
			return;

		if (HasSelection())
		{
			if (OpenClipboard(NULL))
			{
				size_t start = Clamp(m_SelectionStart, 0, m_TextBuffer->Length());
				size_t end = Clamp(m_SelectionEnd, 0, m_TextBuffer->Length());

				if (end < start)
					Swap(end, start);

				size_t size = end - start;

				if (size > 0)
				{
					EmptyClipboard();

					// Allocate a global memory object for the text. 
					HGLOBAL hglbCopy = GlobalAlloc(GMEM_MOVEABLE, (size + 1) * sizeof(CHAR));
					if (hglbCopy) 
					{ 
						CHAR* lptstrCopy = (CHAR*)GlobalLock(hglbCopy); 
						memcpy(lptstrCopy, m_TextBuffer->Str() + start, size);
						lptstrCopy[ size ] = 0;
						GlobalUnlock(hglbCopy);
						SetClipboardData(CF_TEXT, hglbCopy);
					}
				}

				CloseClipboard();
			}
		}
	}

	/// paste from clipboard
	void TextInput::PasteText()
	{
		if (m_TextBuffer == NULL)
			return;

		if (OpenClipboard(NULL))
		{
			if (IsClipboardFormatAvailable(CF_TEXT))
			{
				HGLOBAL hglb = GetClipboardData(CF_TEXT); 
				if (hglb != NULL) 
				{ 
					CHAR* lptstr = (CHAR*)GlobalLock(hglb); 
					if (lptstr != NULL) 
					{
						if (m_Multiline)
						{
							AddString(lptstr, -1);
						}
						else
						{
							CRefStr str(lptstr);
							str.replace('\n','\0');
							str.replace('\r','\0');
							AddString(str, -1);
						}
						GlobalUnlock(hglb); 
					}
				}
			}
			CloseClipboard();
		}
	}


	/// Inserts the char at specified index. If index == -1, insert to the end.
	size_t TextInput::InsertChar(size_t index, ushort character)
	{
		if (m_TextBuffer)
		{
			U32 ret = 0;
#ifdef USE_UTF8
			char out[UTF8_MAXCHAR];

			U32 bytes = UTF16toUTF8((U16*)&character, 1, (U8*)&out[0], 4);

			for (U32 i = 0; i < bytes; i++)
			{
				ret += m_TextBuffer->RefStrGrow(1, 32).insert(index, out[bytes - i - 1]);
			}
#else
			char out[2];

			U32 bytes = WideCharToMultiByte(936, 0, (wchar_t*)&character, 1, (char*)&out, 2, 0, 0);

			if (bytes > 1)
			{
				ret += m_TextBuffer->RefStrGrow(1, 32).insert(index, out[1]);
				ret += m_TextBuffer->RefStrGrow(1, 32).insert(index, out[0]);
			}
			else if (bytes > 0)
			{
				ret += m_TextBuffer->RefStrGrow(1, 32).insert(index, out[0]);
			}
#endif
			if (ret > 0)
			{
				// try to connect history
				if (m_InputHistory.Position == -1 || m_CursorPosition != m_InputHistory.Position + m_InputHistory.NewText.Length())
				{
					ResetHistory();
					SetHistoryTextOld(GetCursorPosition(), GetCursorPosition());
				}

				for (U32 i = 0; i < bytes; i++)
				{
					m_InputHistory.NewText.RefStrGrow(1, 32).insert(-1, out[i]);
				}

				// move cursor
				SetCursorPosition(GetCursorPosition() + ret);

				OnTextChanged(EventArgs());
			}

			return ret;
		}

		return 0;
	}

	/// Removes the char at specified index. If index == -1, remove the last char.
	size_t TextInput::RemoveChar(size_t index)
	{
		if (m_TextBuffer)
		{
			int len = 1;

			if (index > m_TextBuffer->RefStr().len())
				index = m_TextBuffer->RefStr().len();

			// gb2312 support
			const char * s = m_TextBuffer->Str();
			const char * t = s + index;
#ifdef USE_UTF8
			while (t > s && (!IsUTF8LeadByte(*t) || !IsUTF8LeadByte(t[-1])))
				t--;

			for (;;)
			{
				int width = GetUTF8CharLength((U8*)t, -1);
				if (!width)
					break;

				if (t + width > s + index)
					break;

				t += width;
			}

			index = t - s;
			len = GetUTF8CharLength((U8*)t, -1);
#else
			while (t > s && (IsDBCSLeadByteEx(936, *t) || IsDBCSLeadByteEx(936, t[-1])))
				t --;

			for (;;)
			{
				int width = IsDBCSLeadByteEx(936, *t) ? 2 : 1;

				if (t + width > s + index)
					break;

				t += width;
			}

			index = t - s;
			len = IsDBCSLeadByteEx(936, *t) ? 2 : 1;
#endif

			ResetHistory();
			SetHistoryTextOld(index, index + len);
			ResetHistory();

			U32 ret = m_TextBuffer->RefStr(0).remove(index, index + len);

			if (ret > 0)
			{
				SetCursorPosition(index);
				OnTextChanged(EventArgs());
			}

			return ret;
		}

		return 0;
	}

	/// Inserts the first nCount characters of the string pStr at specified index.  If count == -1, the entire string is inserted. If index == -1, insert to the end.
	size_t TextInput::InsertString(size_t index, const CHAR* str, size_t count)
	{
		if (m_TextBuffer)
		{
			ResetHistory();
			SetHistoryTextOld(GetCursorPosition(), GetCursorPosition());			

			CRefStr newstr(str);

			U32 ret = m_TextBuffer->RefStrGrow(Min(count, newstr.len()), 32).insert(index, newstr, count);

			SetCursorPosition(GetCursorPosition() + ret);

			SetHistoryTextNew(index, index + ret);
			ResetHistory();

			if (ret > 0)
				OnTextChanged(EventArgs());

			return ret;
		}
		return 0;
	}

	/// Remove string
	size_t TextInput::RemoveString(size_t startIndex, size_t endIndex)
	{
		if (m_TextBuffer)
		{
			ResetHistory();
			SetHistoryTextOld(startIndex, endIndex);
			ResetHistory();

			U32 ret = m_TextBuffer->RefStr(0).remove(startIndex, endIndex);

			SetCursorPosition(Min(startIndex, endIndex));

			if (ret > 0)
				OnTextChanged(EventArgs());

			return ret;
		}
		return 0;
	}

	/// add string to cursor position
	int TextInput::AddString(const CHAR * str, size_t count)
	{
		if (m_TextBuffer)
		{
			size_t size_removed = 0;
			size_t size_inserted = 0;

			size_t index = GetCursorPosition();

			ResetHistory();
			SetHistoryTextOld(m_SelectionStart, m_SelectionEnd);

			if (HasSelection())
			{
				size_removed = m_TextBuffer->RefStr(0).remove(m_SelectionStart, m_SelectionEnd);
				index = Min(m_SelectionStart, m_SelectionEnd);
			}

			CRefStr newstr(str);

			size_inserted = m_TextBuffer->RefStrGrow(Min(count, newstr.len()), 32).insert(index, newstr, count);
			SetCursorPosition(index + size_inserted);

			SetHistoryTextNew(index, index + size_inserted);
			ResetHistory();

			if (size_removed || size_inserted)
			{
				OnTextChanged(EventArgs());
			}

			return (int)size_inserted - (int)size_removed;
		}

		return 0;
	}

	/// draw text
	void TextInput::DrawInputText(tempc_ptr(Client::UIRender) render, const Core::Vector2 & location, const Core::Rectangle & clip, XRGB textColor, XRGB selectionTextColor, XRGB selectionBgColor, bool drawCursor, bool drawSelection, tempc_ptr(Client::Font) font, bool drawShadow, bool drawPassword)
	{
		// draw text
		if (m_TextBuffer)
		{
			F32 lineHeight = font->GetLineHeight();

			// text area
			Core::Rectangle rect(location, location);
			rect.Max.y = rect.Min.y + lineHeight;
			Core::String strBuffer;
			if(drawPassword)
			{
				strBuffer.Clear();
				S32 Len = m_TextBuffer->Length();
				strBuffer.Reserve(Len);
				for (S32 i = 0; i < Len; i++)
				{
					strBuffer.RefStr(0).insert(i, '*');
				}
			}
			else
			{
				strBuffer = *m_TextBuffer;
			}
			// text buffer
			const CHAR* start = strBuffer.RefStr().buff();
			const CHAR* text = start;
			const CHAR* lineStart = text;

			// selection
			size_t selectionStart = Min(m_SelectionStart, m_SelectionEnd);
			size_t selectionEnd = Max(m_SelectionStart, m_SelectionEnd);

			bool selected = false;

			drawSelection = drawSelection && HasSelection();

			// drawing rect
			Core::Rectangle drawRect(rect);
			drawRect.Max.y = drawRect.Min.y + lineHeight;
			drawRect.Max.x = drawRect.Min.x;

			Vector2 cursorPos = drawRect.Max;

			// draw lines
			for (;;)
			{
				bool lineEnd = false;

				// this block
				for (;;)
				{
					if (text - start == m_CursorPosition)
						cursorPos = Vector2(drawRect.Max.x, drawRect.Min.y);


					if (drawSelection)
					{
						if (!selected && text - start == selectionStart)
							break;

						if (selected && text - start == selectionEnd)
							break;

					}
					if (text[0] == '\r')
					{
						++text;
						continue;
					}


					// temp
					const char * s = text;
#ifdef USE_UTF8
					// character info
					U16 letter = 0;

					S32 len = GetUTF8CharLength((U8*)s, -1);
					if (len)
					{
						UTF8toUTF16((U8*)s, len, &letter, 1);
						s += len;
					}

					//if (letter == '\n' || letter == '\r')
					//	letter = ' ';
#else
					// character info
					U16 letter = (U8)*s++;

					// gb2312 support
					if (IsDBCSLeadByteEx(936, letter))
						letter = (letter << 8) | (U8)(*s++);

					//if (letter == '\n' || letter == '\r')
					//	letter = ' ';
#endif

					const Font::CharInfo & info = font->GetCharacterInfo(letter);
					drawRect.Max.x += info.horiAdvance + font->GetCharSpace();

					if (letter == 0 || letter == '\n')
					{
						lineEnd = true;
						break;
					}

					text = s;
				}

				if (!clip.IsOutside(drawRect))
				{
					ARGB bgColor(0,0,0,0);

					if (selected)
						bgColor = selectionBgColor;

					// draw text
					if (text != lineStart)
					{
						ARGB outColor = selected ? selectionTextColor : textColor;
						if (drawShadow)
							render->DrawStringShadow(font, outColor, ARGB(outColor.a,0,0,0), bgColor, drawRect, lineStart, Unit::kAlignLeftBottom, text-lineStart);
						else
							render->DrawString(font, outColor, bgColor, drawRect, lineStart, Unit::kAlignLeftBottom, text-lineStart);
					}
				}

				if (drawRect.Min.y > clip.Max.y)
					break;

				if (drawSelection && text - start == selectionStart)
					selected = true;

				if (drawSelection && text - start == selectionEnd)
					selected = false;

				// new line
				if (text[0] == 0)
				{
					break;
				}
				else if (lineEnd)
				{
					++text;
					drawRect.Min.x = rect.Min.x;
					drawRect.Max.x = rect.Min.x;
					drawRect.Min.y += lineHeight;
					drawRect.Max.y += lineHeight;
				}
				else
				{
					drawRect.Min.x = drawRect.Max.x;
				}

				lineStart = text;
			}

			if (drawCursor)
			{
				AlphaBlendMode blend = render->GetBlendMode();
				render->SetBlendMode(kInverseColor);
				render->SetTexture(NullPtr);
				render->DrawLine2d(cursorPos + Vector2(1, 0), cursorPos + Vector2(1, lineHeight), ARGB(255,255,255,255));
				render->SetBlendMode(blend);
			}
		}
	}

	/// convert from location to index
	bool TextInput::PositionToIndex(tempc_ptr(Font) font, const Vector2 & position, size_t & index)
	{
		if (m_TextBuffer)
		{
			if (font->XtoCP(m_TextBuffer->Str(), position, index))
			{
				return true;
			}
		}

		return false;
	}

	/// convert from index to location
	bool TextInput::IndexToPosition(tempc_ptr(Font) font, size_t index, Vector2 & position)
	{
		if (m_TextBuffer)
		{
			if (font->CPtoX(m_TextBuffer->Str(), index, position))
				return true;
		}

		return false;
	}

	/// indent
	bool TextInput::Indent(size_t start, size_t end, bool unindent)
	{
		if (start > end) Swap(start, end);

		const CHAR * text = m_TextBuffer->Str();

		bool multiline = false;
		for (const CHAR * s = text + start; s < text + end; s ++)
		{
			if (s[0] == '\n')
			{
				multiline = true;
				break;
			}
		}

		if (multiline)
		{
			// selection
			size_t & selectionStart = m_SelectionStart < m_SelectionEnd ? m_SelectionStart : m_SelectionEnd;
			size_t & selectionEnd = m_SelectionStart < m_SelectionEnd ? m_SelectionEnd : m_SelectionStart;

			while (start > 0 && text[start - 1] != '\n')
				start --;

			ResetHistory();
			SetHistoryTextOld(start, end);

			if (unindent)
			{
				for (size_t i = start; i < end; i ++)
				{
					const CHAR * text = m_TextBuffer->Str();

					if ((i == 0 || text[i - 1] == '\n'))
					{
						if (text[i] == '\t')
						{
							m_TextBuffer->RefStr(0).remove(i);
							selectionEnd --;
							end--;

							if (i < selectionStart)
								selectionStart --;

							if (i < m_CursorPosition)
								m_CursorPosition--;
						}
					}
				}
			}
			else
			{
				for (size_t i = start; i < end; i ++)
				{
					const CHAR * text = m_TextBuffer->Str();

					if (i == 0 || text[i - 1] == '\n')
					{
						m_TextBuffer->RefStrGrow(1, 32).insert(i, '\t');

						if (i < selectionStart)
							selectionStart ++;

						selectionEnd ++;
						end ++;

						if (i < m_CursorPosition)
							m_CursorPosition++;
					}
				}
			}

			SetHistoryTextNew(start, end);
			ResetHistory();

			OnTextChanged(EventArgs());

			return true;
		}

		return false;
	}

	/// new line
	void TextInput::NewLine()
	{
		size_t startPosition = GetCursorPosition();
		size_t endPosition = GetCursorPosition();

		// try to connect history
		if (m_InputHistory.Position != startPosition || m_InputHistory.NewText.Length() != 0)
		{
			ResetHistory();
			SetHistoryTextOld(startPosition, startPosition);
		}

		// new line
		endPosition += m_TextBuffer->RefStrGrow(1, 32).insert(endPosition, '\n');

		const CHAR * text = m_TextBuffer->Str();
		const CHAR * curLine = text + m_CursorPosition;
		const CHAR * prevLine = curLine - 1;

		while (prevLine > text && prevLine[-1] != '\n')
			prevLine --;

		while (prevLine[0] == '\t' && prevLine < curLine)
		{
			endPosition += m_TextBuffer->RefStrGrow(1, 32).insert(endPosition, '\t');
			prevLine++;
		}

		SetHistoryTextNew(startPosition, endPosition);
		ResetHistory();

		SetCursorPosition(endPosition);
		OnTextChanged(EventArgs());
	}


	void TextInput::ResetHistory()
	{
		// nothing
		if (m_InputHistory.OldText.Length() != 0 || m_InputHistory.NewText.Length() != 0)
		{
			OnHistoryReset(m_InputHistory);

			m_InputHistory.Position = -1;
			m_InputHistory.OldText.Clear();
			m_InputHistory.NewText.Clear();
			m_InputHistory.OldSelectionStart = m_SelectionStart;
			m_InputHistory.OldSelectionEnd = m_SelectionEnd;
		}

	}
	/// set old history text
	void TextInput::SetHistoryTextOld(size_t start, size_t end)
	{
		if (m_TextBuffer)
		{
			size_t length = m_TextBuffer->Length();

			start = Min(start, length);
			end = Min(end, length);

			if (start > end)
				Swap(start, end);

			m_InputHistory.Position = start;
			m_InputHistory.OldSelectionStart = m_SelectionStart;
			m_InputHistory.OldSelectionEnd = m_SelectionEnd;

			if (end > start)
			{				
				m_InputHistory.OldText.RefStr(end - start + 1).copy(m_TextBuffer->RefStr(), start, end - start);
			}
		}
	}

	void TextInput::SetHistoryTextNew(size_t start, size_t end)
	{
		if (m_TextBuffer)
		{
			size_t length = m_TextBuffer->Length();

			start = Min(start, length);
			end = Min(end, length);

			if (start > end)
				Swap(start, end);

			if (end > start)
			{				
				m_InputHistory.NewText.RefStr(end - start + 1).copy(m_TextBuffer->RefStr(), start, end - start);
			}
		}
	}

	void TextInput::DoHistory(const InputHistory & history, bool undo)
	{
		bool changed = false;

		if (m_TextBuffer)
		{
			size_t newLength = history.NewText.Length();
			size_t oldLength = history.OldText.Length();

			if (undo)
			{
				if (newLength)
					changed |= 0 < m_TextBuffer->RefStr(0).remove(history.Position, history.Position + newLength);

				if (oldLength)
					changed |= 0 < m_TextBuffer->RefStrGrow(oldLength, 32).insert(history.Position, history.OldText.RefStr(), oldLength);

				SetSelection(history.OldSelectionStart, history.OldSelectionEnd);
			}
			else
			{
				if (oldLength)
					changed |= 0 < m_TextBuffer->RefStr(0).remove(history.Position, history.Position + oldLength);

				if (newLength)
					changed |= 0 < m_TextBuffer->RefStrGrow(newLength, 32).insert(history.Position, history.NewText.RefStr(), newLength);

				SetCursorPosition(history.Position + newLength);
			}
		}

		if (changed)
		{
			OnTextChanged(EventArgs());
		}
	}

	void TextInput::Clear()
	{
		if (m_TextBuffer == NULL)
			return;

		m_TextBuffer->Clear();
		SetCursorPosition(0, false);
	}

	size_t TextInput::GetSelectionStart()
	{
		return m_SelectionStart;
	}

	size_t TextInput::GetSelectionEnd()
	{
		return m_SelectionEnd;
	}
}