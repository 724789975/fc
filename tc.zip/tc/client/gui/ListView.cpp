#include "pch.h"

using namespace Core;
using namespace Gui;
using namespace Client;

//--------------------------------------------------------------------------------------
// type info
//--------------------------------------------------------------------------------------
DEFINE_PDE_TYPE_CLASS(Gui::ListView)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::ScrollableControl);
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		//ADD_PDE_METHOD(GetListTreeViewRoot);
		ADD_PDE_METHOD(AddColumn);
		ADD_PDE_METHOD(AddItem);
		ADD_PDE_METHOD(AddSubItem);
		ADD_PDE_METHOD(IsSelected);


		ADD_PDE_PROPERTY_RW(SelectedIndex);
		ADD_PDE_PROPERTY_RW(MultiSelect);
		ADD_PDE_EVENT(EventDelete);
		ADD_PDE_EVENT(EventListClick);
	}
};

REGISTER_PDE_TYPE(Gui::ListView);

namespace Gui
{
	static const F32 ITEM_HEIGHT = 20;
	static const F32 BORDER_WIDTH = 1;
	static const F32 SPLIT_WIDTH = 3;
	static const F32 BUTTON_WIDTH = 50;
	static const F32 MIN_WIDTH = 10;

	ListView::ListView()
		: m_SelectedIndex(INDEX_NONE)
		, m_LastIndex(0)
		, m_BorderVisible(false)
		, m_MultiSelect(false)
		, m_Selecting(false)
	{
		//SetAutoScroll(true);
	}

	ListView::~ListView()
	{
		Clear();
	}
}


//--------------------------------------------------------------------------------------
// Attribute
//--------------------------------------------------------------------------------------
namespace Gui
{
	PDE_ATTRIBUTE_GETTER(ListView, SelectedIndex, S32)
	{
		return m_SelectedIndex;
	}


	PDE_ATTRIBUTE_SETTER(ListView, SelectedIndex, S32)
	{
		SetSelect(value, true);
	}

	PDE_ATTRIBUTE_GETTER(ListView, ItemCount, U32)
	{
		return m_Items.Size();
	}

	PDE_ATTRIBUTE_GETTER(ListView, Columns, sharedc_ptr(Header))
	{
		return m_Header;
	}

	PDE_ATTRIBUTE_GETTER(ListView, MultiSelect, bool)
	{
		return m_MultiSelect;
	}

	PDE_ATTRIBUTE_SETTER(ListView, MultiSelect, bool)
	{
		if (m_MultiSelect != value)
		{
			m_MultiSelect = value;
		}
	}

	PDE_ATTRIBUTE_GETTER(ListView, BorderVisible, bool)
	{
		return m_BorderVisible;
	}

	PDE_ATTRIBUTE_SETTER(ListView, BorderVisible, bool)
	{
		if (m_BorderVisible != value)
		{
			m_BorderVisible = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(ListView, DisplayPadding, Vector4)
	{
		if (GetBorderVisible())
		{
			return Vector4(BORDER_WIDTH, BORDER_WIDTH + ITEM_HEIGHT, BORDER_WIDTH, BORDER_WIDTH);
		}
		else
		{
			return Vector4(0, ITEM_HEIGHT, 0, 0);
		}
	}
}


//--------------------------------------------------------------------------------------
// Event
//--------------------------------------------------------------------------------------
namespace Gui
{
	void ListView::OnCreate()
	{
		Super::OnCreate();

		SetBackgroundColor(Core::ARGB(255,255,255));
		SetAutoScroll(true);

		m_Header = ptr_new Header;
		m_Header->SetParent(ptr_static_cast<Self>(this));

	}

	void ListView::OnFrameUpdate(EventArgs & e)
	{
		Super::OnFrameUpdate(e);
	}

	void ListView::OnLayout(EventArgs & e)
	{
		F32 offset = 0.f;
		F32 width = GetDisplayWidth();
		if (GetAutoScroll())
		{
			Vector2 autoSize(width, (ITEM_HEIGHT * m_Items.Size() + 1));
			SetAutoScrollMinSize(autoSize);
			m_VScrollBar->SetSmallChange(ITEM_HEIGHT);
			offset = m_HScrollBar->GetValue();
		}

		m_Header->SetSize(Vector2(Max(width, GetSize().x), ITEM_HEIGHT));
		m_Header->SetLocation(Vector2(-offset, 0));

		Super::OnLayout(e);

		Invalid();
	}
	
	void ListView::OnPaint(PaintEventArgs & e)
	{

		Super::OnPaint(e);

		F32 width = Max(GetSize().x, GetDisplayWidth());

		for (U8 i = 0; i < m_Items.Size(); ++i)
		{
			bool selected = IsSelected(i);

			if (selected)
			{
				Core::Rectangle selectRect(Vector2(0, ITEM_HEIGHT * i), Vector2(width, ITEM_HEIGHT * (i + 1)));
				XRGB selectColor = GetActive() ? XRGB(49,106,197) : XRGB(128,128,128);

				e.render->DrawRectangle(selectRect, selectRect, selectColor);
			}

			U32 count = m_Header->GetItemCount();

			for (U8 j=0; j<count; ++j)
			{
				if ( m_Header->IndexToDisplayIndex(j) < count)
				{
					Core::Rectangle textRect = Core::Rectangle::LeftTop(Vector2(m_Header->GetPos(j), ITEM_HEIGHT * i), Vector2(m_Header->GetWidth(j), ITEM_HEIGHT));
					//Core::Rectangle scissor = e.render.RenderState().GetScissorRect();
					//e.render.AddScissorRectWithWorldMatrix(textRect);
					textRect.Shrink(SPLIT_WIDTH, 0, SPLIT_WIDTH, 0);
					//skin.DrawIconText(textRect, m_Items[i]->GetIcon(j), m_Items[i]->GetText(j), m_Header->GetAlign(j), ARGB(255,255,255), selected? ARGB(255,255,255):ARGB(0, 0, 0), e.ControlEnable, e.ControlEnable);
					
					e.render->DrawString(e.render->font_normal,Core::ARGB(128,128,0,128),Core::ARGB(128,0,128,255),textRect,m_Items[i]->GetText(j),m_Header->GetAlign(j));
					//Core::String item_text = m_Items[i]->GetText(j);


					//e.render->DrawString(
					//	e.render->font_normal,
					//	Core::ARGB(255,0, 0, 0), //text color
					//	Core::ARGB(255,255,0,255),//bg
					//	textRect,
					//	item_text,
					//	m_Header->GetAlign(j));
					//
					
					//e.render.RenderState().SetScissorRect(scissor);
				}
			}
		}


	}

	void ListView::OnInputEvent(InputEventArgs & e)
	{
		if (e.IsMouseEvent())
		{
			Vector2 localPos = ScreenToClient(e.CursorPosition);

			bool pointed = GetDisplayRect().IsPointInside(localPos);

			switch(e.Type)
			{
			case InputEventArgs::kMouseDown:
			case InputEventArgs::kMouseDoubleClick:
				{
					if (e.Code == MC_LEFT_BUTTON && !m_Selecting && pointed)
					{
						SetCapture(true);

						U32 selectdIndex = localPos.y / ITEM_HEIGHT;

						if (e.ShiftKeyDown && m_MultiSelect)
						{
							U32 uMin  = Min(m_LastIndex, selectdIndex);
							U32 uMax  = Max(m_LastIndex, selectdIndex);

							if (IsSelected(m_LastIndex))
							{
								ClearSelection();
								SetSelect(m_LastIndex);
							}
							else
							{
								ClearSelection();
							}

							SetSelect(selectdIndex);

							for (U8 i = uMin+1; i < uMax; ++i)
							{
								SetSelect(i);
							}
						}
						else if (e.ControlKeyDown && m_MultiSelect)
						{
							ToggleSelect(selectdIndex);
						}
						else
						{
							if (m_MultiSelect)
							{
								ClearSelection();
							}
							else
							{
								SetSelect(m_SelectedIndex, false);
							}

							m_SelectRect.Min = m_SelectRect.Max = localPos;
							m_Selecting = true;

							ToggleSelect(selectdIndex);
						}

						Invalid();
						OnListClick(e);
						e.Handled = true;
					}
				}
				break;

			case InputEventArgs::kMouseUp:
				{
					if (e.Code == MC_LEFT_BUTTON)
					{
						SetCapture(false);
						m_Selecting = false;
						e.Handled = true;
					}
				}
				break;

			case InputEventArgs::kMouseMove:
				{
					if (m_MultiSelect && m_Selecting)
					{
						U32 item = localPos.y / ITEM_HEIGHT;

						if (0 <= item && item < GetItemCount())
						{
							ScrollToView(Core::Rectangle::LeftTop(Vector2(0, ITEM_HEIGHT * item), Vector2(GetDisplayRect().Max.x, ITEM_HEIGHT)));

							Core::Rectangle rect;
							m_SelectRect.Max = localPos;
							rect.Min = Min(m_SelectRect.Min, m_SelectRect.Max);
							rect.Max = Max(m_SelectRect.Min, m_SelectRect.Max);

							if (GetDisplayRect().IntersectWith(rect))
							{
								U32 uMin  = rect.Min.y / ITEM_HEIGHT;
								U32 uMax  = rect.Max.y / ITEM_HEIGHT;

								ClearSelection();

								for (U8 i=uMin; i<=uMax; ++i)
								{
									SetSelect(i);
								}

								m_LastIndex = m_SelectRect.Min.y / ITEM_HEIGHT;
							}

							Invalid();
						}
					}

					e.Handled = true;
				}
				break;
			}

		}


		if (!e.Handled)
			Super::OnInputEvent(e);
	}

	/// on active changed
	void ListView::OnActiveChanged(EventArgs & e)
	{
		Super::OnActiveChanged(e);
		Invalid();
	}

	/// on click
	void ListView::OnListClick(InputEventArgs & e)
	{
		EventListClick.Fire(ptr_static_cast<Self>(this), e);
		
	}

	void ListView::OnItemSelectedChanged(EventArgs & e)
	{
		EventSelectChange.Fire(ptr_static_cast<Self>(this), e);
	}

	void ListView::OnDelete(InputEventArgs & e)
	{
		EventDelete.Fire(ptr_static_cast<Self>(this), e);
	}

	void ListView::OnItemChange(EventArgs & e)
	{
		EventItemChange.Fire(ptr_static_cast<Self>(this), e);
	}

	void ListView::Header_OnItemChange(tempc_ptr(Core::Object) sender, EventArgs & e)
	{
		DirtyLayout();
	}
}

//--------------------------------------------------------------------------------------
// Method
//--------------------------------------------------------------------------------------
namespace Gui
{

	sharedc_ptr(ListItem) ListView::CreateItem()
	{
		return ptr_new ListItem;
	}

	U32 ListView::AddItem(const Core::String & string)
	{
		sharedc_ptr(ListItem) item = CreateItem();
		item->SetColumnCount(m_Header->GetItemCount());
		item->SetText(0, string);
		m_Items.PushBack(item);

		EventArgs e;
		OnItemChange(e);
		Invalid();

		return m_Items.Size() - 1;
	}

	U32 ListView::ItemToIndex(sharedc_ptr(ListItem) item)
	{
		for (U32 i = 0; i < m_Items.Size(); i ++)
			if (m_Items[i] == item)
				return i;

		return -1;
	}

	sharedc_ptr(ListItem) ListView::IndexToItem(U32 index)
	{
		if (index < m_Items.Size())
			return m_Items[index];
		return NullPtr;
	}

	void ListView::AddSubItem(U32 index, const Core::String & string)
	{
		if (index < m_Items.Size())
		{
			m_Items[index]->AddSubItem(string);
			Invalid();
		}
	}

	void ListView::ToggleSelect(U32 index)
	{
		SetSelect(index, !IsSelected(index));
		m_LastIndex = index;
	}

	bool ListView::IsSelected(U32 index)
	{
		if (index < m_Items.Size())
			return m_Items[index]->GetSelected();

		return false;
	}

	void ListView::SetSelect(U32 index, bool flag)
	{
		if (index < m_Items.Size())
		{
			m_Items[index]->SetSelected(flag);
			m_SelectedIndex = index;
		}
		else
		{
			m_SelectedIndex = INDEX_NONE;
		}

		EventArgs e;
		OnItemSelectedChanged(e);
		Invalid();
	}

	void ListView::ClearSelection()
	{
		for (U8 i = 0; i< GetItemCount(); ++i)
		{
			SetSelect(i, false);
		}
	}

	void ListView::AddColumn(const Core::String & string)
	{
		m_Header->AddItem(string);

		Invalid();
	}

	Core::String ListView::GetItemText(U32 row, U32 column)
	{
		if (row < m_Items.Size())
			return m_Items[row]->GetText(column);

		return Core::String::kEmpty;
	}

	F32 ListView::GetDisplayWidth()
	{
		F32 width = m_Header->GetAllWidth();

		if (GetBorderVisible())
		{
			width += 2 * BORDER_WIDTH;
		}

		return width;
	}


	void ListView::Clear()
	{
		m_Items.Clear();
	}

}









