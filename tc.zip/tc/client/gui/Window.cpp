#include "pch.h"

using namespace Core;
using namespace Client;
using namespace Gui;

//---------------------------------------------------------------------------------------
// typeinfo.
//---------------------------------------------------------------------------------------
DEFINE_PDE_TYPE_ENUM(Window::SurfaceType)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_ENUM_ITEM("kPlane",			Window::kPlane);
		ADD_PDE_ENUM_ITEM("kCylinder",		Window::kCylinder);
		ADD_PDE_ENUM_ITEM("kNone",			Window::kNone);

		ADD_PDE_ENUM_CONSTRUCTOR();
	}
};


DEFINE_PDE_TYPE_CLASS(Window)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Control);
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_PROPERTY_RW(ContentSize);
		ADD_PDE_PROPERTY_RW(SurfaceType);
		ADD_PDE_PROPERTY_RW(WorldLocation);
		ADD_PDE_PROPERTY_RW(WorldRotation);
		ADD_PDE_PROPERTY_RW(Moveable);
		ADD_PDE_PROPERTY_RW(Opacity);
	}
};

REGISTER_PDE_TYPE(Window);
REGISTER_PDE_TYPE(Window::SurfaceType);


//---------------------------------------------------------------------------------------
// constructor.
//---------------------------------------------------------------------------------------
namespace Gui
{
	Window::Window()
		: m_worldLocation(0, 0, 0)
		, m_worldRotation(0, 0, 0)
		, m_SurfaceType(kPlane)
		, m_MouseButton(KC_UNUSED)
		, m_Moveable(false)
		, m_Opacity(1.0f)
		, m_showGlowRay(false)
		, m_GlowOffset(0,0)
	{
		SetBackgroundColor(Core::ARGB(255,255,255,255));
	}

	Window::~Window()
	{
	}
}

//---------------------------------------------------------------------------------------
// attributes.
//---------------------------------------------------------------------------------------
namespace Gui
{
	//Override attributes
	PDE_ATTRIBUTE_GETTER(Window, Location, Vector2)
	{
		return Vector2(GetWorldLocation().x, GetWorldLocation().y);
	}
	PDE_ATTRIBUTE_SETTER(Window, Location, Vector2)
	{
		SetWorldLocation(Vector3(value.x, value.y, GetWorldLocation().z));
	}


	PDE_ATTRIBUTE_SETTER(Window, Size, Vector2)
	{
		if (m_Size != value)
		{
			ResizeEventArgs e;
			e.OldSize = m_Size;
			e.NewSize = value;

			m_Size = value;

			OnSizeChanged(e);
		}
	}

	PDE_ATTRIBUTE_GETTER(Window, ContentSize, Vector2)
	{
		Vector4 padding = GetPadding();
		return GetSize()-Vector2(padding.x+padding.z, padding.y+padding.w);
	}

	PDE_ATTRIBUTE_SETTER(Window, ContentSize, Vector2)
	{
		Vector4 padding = GetPadding();
		SetSize(value + Vector2(padding.x+padding.z, padding.y+padding.w));
	}

	PDE_ATTRIBUTE_SETTER(Window, WorldLocation, Vector3)
	{
		m_worldLocation = value;
		UpdateBalloon();
		UpdateFrame();
		UpdateNoticeBoard();
	}

	PDE_ATTRIBUTE_GETTER(Window, WorldLocation, Vector3)
	{
		return m_worldLocation;
	}

	PDE_ATTRIBUTE_SETTER(Window, WorldRotation, Vector3)
	{
		m_worldRotation= value;
	}

	PDE_ATTRIBUTE_GETTER(Window, WorldRotation, Vector3)
	{
		return m_worldRotation;
	}

	PDE_ATTRIBUTE_SETTER(Window, SurfaceType, Window::SurfaceType)
	{
		m_SurfaceType = value;
	}

	PDE_ATTRIBUTE_GETTER(Window, SurfaceType, Window::SurfaceType)
	{
		return m_SurfaceType;
	}

	PDE_ATTRIBUTE_SETTER(Window, Moveable, bool)
	{
		m_Moveable = value;
	}

	PDE_ATTRIBUTE_GETTER(Window, Moveable, bool)
	{
		return m_Moveable;
	}

	PDE_ATTRIBUTE_GETTER(Window, Opacity, F32)
	{
		return m_Opacity;
	}

	PDE_ATTRIBUTE_SETTER(Window, Opacity, F32)
	{
		if(value>1.f)
			m_Opacity = 1.f;
		else if(value<0.f)
			m_Opacity = 0.f;
		else
			m_Opacity = value;
	}

	PDE_ATTRIBUTE_SETTER(Window, Visible, bool)
	{
		Super::SetVisible(value);
		if(!value)
		{
			if(m_Texture)
			{
				m_Texture = NullPtr;
			}
		}
	}
}

//---------------------------------------------------------------------------------------
// events
//---------------------------------------------------------------------------------------
namespace Gui
{
	//Methods
	void Window::OnWindowInput(InputEventArgs & e)
	{
		OnInputEvent(e);
	}

	void Window::OnPaint(PaintEventArgs & e)
	{
		Core::Rectangle bg_rect(GetBackgroundRect());
		e.render->SetBlendMode(kBlendNone);
		tempc_ptr(ControlSkin) skin = GetSkin();
		if (skin)
		{
			Skin::DrawImage(e.render, skin->GetBackgroundImage(), bg_rect, m_BackgroundColor);
		}
		else
		{
// 			e.render->DrawRectangle(bg_rect, bg_rect, ARGB(0, 111, 122, 129));
			e.render->SetTexture(NullPtr);
			e.render->DrawRectangle(bg_rect, bg_rect, m_BackgroundColor);
		}

		e.render->SetBlendMode(kAlphaBlend);

		//Control::OnPaint(e);
		//Draw title
		if(m_Padding.y>0)
			e.render->DrawString(GetFont(), ARGB(255,255,255,255), ARGB(0, 0, 0, 0), Core::Rectangle::LeftTop(54, 0, bg_rect.Max.x-bg_rect.Min.x, m_Padding.y), m_Text, Unit::kAlignLeftMiddle);
	}


	// process input
	void Window::OnInputEvent(Client::InputEventArgs & e)
	{
		if (m_Moveable)
		{
			if (!e.Handled)
			{
				switch (e.Type)
				{
				case InputEventArgs::kMouseDown:
					if (e.Code == MC_LEFT_BUTTON || e.Code == MC_RIGHT_BUTTON)
					{
						m_MouseButton = e.Code;
						ChangeParent(GetParent(), NullPtr);
						SetCapture(true);
						e.Handled = true;
					}
					else if (e.Code == MC_MIDDLE_BUTTON)
					{
						SetWorldRotation(Vector3(0, 0, 0));
						e.Handled = true;
					}

					break;

				case InputEventArgs::kMouseMove:
					if (m_MouseButton == MC_LEFT_BUTTON)
					{
						SetWorldLocation(GetWorldLocation() + Vector3(e.CursorMove, 0));
						e.Handled = true;
					}
					else if (m_MouseButton == MC_RIGHT_BUTTON)
					{
						SetWorldRotation(GetWorldRotation() + Vector3(0, e.CursorMove.x / 400, 0));
						e.Handled = true;
					}

				case InputEventArgs::kMouseUp:
					if (e.Code != KC_UNUSED)
					{
						if (m_MouseButton != KC_UNUSED)
						{
							m_MouseButton = KC_UNUSED;
							SetCapture(false);
							e.Handled = true;
						}
					}
					break;
				}
			}
		}
		if(!e.Handled)
			Super::OnInputEvent(e);
	}


	void Window::Render(RenderEventArgs & e)
	{
		Matrix44 old_view = e.render->GetView();
		Matrix44 old_proj = e.render->GetProjection();
		Core::Rectangle old_viewport = e.render->GetVirtualViewport();
		Vector2 scale = e.render->GetRenderTargetSize() / old_viewport.GetExtent();

		Vector2 texture_size = m_Size * scale;
		texture_size.x = Ceil(texture_size.x);
		texture_size.y = Ceil(texture_size.y);

		if (static_cast<U32>(texture_size.x) > 0 && static_cast<U32>(texture_size.y) > 0)
		{
			if (!m_Texture)
			{
				//m_Texture = ptr_new Texture2D(texture_size.x, texture_size.y, 1, D3DUSAGE_RENDERTARGET, D3DFMT_A8R8G8B8, D3DPOOL_DEFAULT);
				m_Texture = ptr_new RenderTexture;
				ptr_static_cast<RenderTexture>(m_Texture)->CreateRenderTexture(texture_size.x, texture_size.y, 1, D3DUSAGE_RENDERTARGET, D3DFMT_A8R8G8B8);
			}
			else
			{
				if (m_Texture->SetSize(texture_size.x, texture_size.y))
					Invalid();
			}
		}
		else
		{
			return;
		}

		if (e.render->BeginDraw(m_Texture->GetSurface()))
		{
			Vector2 rt_size = GetSize();

			Matrix44 world, view;

			view.SetScaleXYZ(2.0f / rt_size.x, -2.0f / rt_size.y, 0);
			view.TranslateXYZ(-1, 1, 0);
			//view.TranslateLocalXYZ(-0.5f, -0.5f, 0);

			e.render->SetWorld(Matrix44::kIdentity);
			e.render->SetView(view);
			e.render->SetProjection(Matrix44::kIdentity);
			e.render->SetVirtualViewport(Core::Rectangle(0, 0, rt_size.x, rt_size.y));

#if DEBUG_INFO
			if (gGame->input->IsKeyDown(KC_F5))
			{
				for (Control * control = this; control; control = control->GetNextNode())
					control->Invalid();
			}
#endif

			e.Enable = m_Enable;
			e.Offset = Vector2::kZero;
			e.Cached = true;

			e.render->SetScissorRect(e.render->GetVirtualViewport());
			Control::Render(e);

#if DEBUG_INFO
			if (gGame->input->IsKeyPressed(KC_F6))
			{
				e.render->SetWorld(Matrix44::kIdentity);
				e.render->SetScissorRect(Core::Rectangle::kInvalid);
				e.render->SetTexture(NullPtr);
				e.render->SetBlendMode(kBlendNone);
				e.render->BeginRectangleList(1);
				e.render->VertexColor(ARGB(128, 0, 0, 0));
				e.render->Vertex2f(0, 0);
				e.render->Vertex2f(rt_size.x, rt_size.y);
				e.render->End();
				e.render->SetBlendMode(kAlphaBlend);
			}
#endif

			e.render->EndDraw();
		}

		if (e.render->BeginDraw(gGame->dx9->render_target, NULL))
		{
			Vector2 wd_size = GetSize();
			Vector3 windRotation(GetWorldRotation());

			Matrix44 matrix;
			matrix.SetIdentity();
			matrix = Quaternion(windRotation.y, windRotation.x, windRotation.z);
			matrix.Translate(GetWorldLocation());

			e.render->SetWorld(matrix);
			e.render->SetView(old_view);
			e.render->SetProjection(old_proj);
			e.render->SetVirtualViewport(old_viewport);

			e.render->SetScissorRect(Core::Rectangle::kInvalid);

			e.render->SetTexture(m_Texture);

			if(GetSurfaceType() == Window::kPlane)
			{
#if 1
				wd_size.x = m_Texture->GetWidth() / scale.x;
				wd_size.y = m_Texture->GetHeight() / scale.y;
				UIRender::ShaderMode shader = e.render->GetShaderMode();
				e.render->SetShaderMode(UIRender::kHighQulityFilter);
				e.render->DrawRectangle(Core::Rectangle(0, 0, wd_size.x, wd_size.y), Core::Rectangle(0, 0, 1, 1), Core::ARGB( (U8)(255*GetOpacity()), 255, 255, 255 ));
				e.render->SetShaderMode(shader);
#else
				Vector2 offset(GetWorldLocation().x, GetWorldLocation().y);
				Core::Rectangle rect(0, 0, wd_size.x, wd_size.y);
				rect.Move(offset);
				e.render->SetScissorRect(rect);

				e.render->SetTexture(NullPtr);
				e.Enable = m_Enable;
				e.Offset = offset;
				e.Cached = false;

				Control::Render(e);
#endif
				
				//Draw glow ray
				if(m_showGlowRay)
				{
					Core::Rectangle winRect(0,0,GetSize().x,GetSize().y/*gGame->guiSys->GetWinGlowTexture()->GetHeight()*/);
					e.render->SetScissorRectWithWorldMatrix(winRect);
					winRect.Move(m_GlowOffset);
					//Skin::DrawImage(e.render, gGame->guiSys->GetWinGlowTexture(), winRect);
					e.render->SetTexture(gGame->guiSys->GetWinGlowTexture());
					e.render->DrawRectangle(winRect, Core::Rectangle(0,0,1,1), Core::ARGB( (U8)(255*GetOpacity()), 255, 255, 255 ));
				}
			}
			else if(GetSurfaceType() == Window::kCylinder)
			{
				int k = 30;
				for (int i = 0; i < k; i ++)
				{
					e.render->BeginTriangleList(60);
					Core::Color4 color(1, 1, 1, 1);

					float x1 = i * k;
					float x2 = i * k + k;
					float y1 = 0;
					float y2 = wd_size.y;

					float u1 = i / (float)k;
					float v1 = 0;
					float u2 = (i+1) / (float)k;
					float v2 = 1;

					float z1 = -Sin(i * DEG2RAD * 6) * 100;
					float z2 = -Sin((i + 1) * DEG2RAD * 6) * 100;

					e.render->Vertex(x1, y1, z1, u1, v1, color);
					e.render->Vertex(x2, y1, z2,	u2, v1, color);
					e.render->Vertex(x1, y2, z1, u1, v2, color);

					e.render->Vertex(x2, y1, z2,	u2, v1, color);
					e.render->Vertex(x1, y2, z1, u1, v2, color);
					e.render->Vertex(x2, y2, z2, u2, v2, color);

					e.render->End();
				}
			}
			e.render->EndDraw();
		}
	}

	Core::Vector2 Window::ScreenToClient( const Core::Vector2 & pos )
	{
		return pos;
	}

	Core::Vector2 Window::ClientToScreen( const Core::Vector2 & pos )
	{
		return pos;
	}

	void Window::ChangeParent(by_ptr(Control) parent, by_ptr(Control) insertBefore, bool parentNeedRearrangeChildren)
	{
		Super::ChangeParent(parent, insertBefore, parentNeedRearrangeChildren);
		if(!parent)
		{
			if(m_Texture)
			{
				m_Texture = NullPtr;
			}
		}
	}

	bool Window::GetVisibility()
	{
		return (m_Visible && (m_Opacity>0.8) && m_Parent);
	}
}

