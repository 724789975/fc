namespace Gui
{
	class PageBarSkin: public ControlSkin
	{
	public:
		INLINE_PDE_ATTRIBUTE_RW(ButtonNormalImage, tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(ButtonHoverImage, tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(ButtonDownImage, tempc_ptr(Image));
		
	private:
		sharedc_ptr(Image) m_ButtonNormalImage;
		sharedc_ptr(Image) m_ButtonHoverImage;
		sharedc_ptr(Image) m_ButtonDownImage;
	};
}


namespace Gui
{
	class PageBar: public Control
	{
	public:
		DECLARE_PDE_OBJECT(PageBar, Control);
		DECLARE_PDE_EVENT(EventIndexChanged, Core::ValueChangeEventArgs);

		DECLARE_PDE_ATTRIBUTE_RW(Index, int);
		DECLARE_PDE_ATTRIBUTE_RW(Count, int);
		DECLARE_PDE_ATTRIBUTE_RW(ShowCount, int);
		DECLARE_PDE_ATTRIBUTE_RW(Gap,	F32);
		DECLARE_PDE_ATTRIBUTE_RW(ArrowWidth, F32);
		DECLARE_PDE_ATTRIBUTE_RW(ButtonLeftStyle, Core::String);
		DECLARE_PDE_ATTRIBUTE_RW(ButtonRightStyle, Core::String);

		PageBar();
		~PageBar();
		virtual void OnCreate();
		virtual void OnFrameUpdate(EventArgs & e);
		virtual void OnInputEvent(Client::InputEventArgs & e);
		virtual void OnPaint(PaintEventArgs & e);

		virtual void OnSizeChanged(ResizeEventArgs & e);

		virtual void OnIndexChanged(ValueChangeEventArgs & e);

	public:
		void Init();
		void ChangeIndexTo(int index, bool forceUpdate = false);

		int WhichRectContains(Core::Vector2 cursorPosi);

		F32	GetTotalWidth(int start, int end);
		int GetLeftMostIndex();

		void OnButtonLeftClick(by_ptr(void) sender, InputEventArgs &e);
		void OnButtonRightClick(by_ptr(void) sender, InputEventArgs &e);

		bool IsLeftMost();
		bool IsRightMost();

		void SetButtonLRVisibility();

	private:
		int					m_Index;
		int					m_HoverIndex;
		int					m_DownIndex;

		int					m_Count;
		int					m_ShowCount;
		F32					m_Gap;
		F32					m_ArrowWidth;

		F32					m_ScrollX;

		sharedc_ptr(Gui::Button) m_ButtonLeft;
		sharedc_ptr(Gui::Button) m_ButtonRight;

		int						m_RightMostIndex;
		F32						m_TargetScrollX;
		F32						m_ButtonLTargetPos;

		Core::Array<F32>		m_PageWidths;
		Core::Array<F32>		m_PagePositions;

		bool					m_MouseDown;
	};
}