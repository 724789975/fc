#include "pch.h"

using namespace Core;
using namespace Gui;
using namespace Client;

namespace Gui
{
	ConsoleUI::ConsoleUI()
		: m_FirstCmd(0)
		, m_HistoryCmdID(0)
		, m_CursorVisible(false)
		, m_CursorTime(0)
		, m_ScrollX(0)
	{
		SetTextBuffer(&m_Text);
	}

	ConsoleUI::~ConsoleUI()
	{
	}


	void ConsoleUI::OnCreate()
	{
		Window::OnCreate();

		SetSize(Vector2(1024, 450));
		SetTextColor(ARGB(255, 255, 255, 255));
		SetBackgroundColor(ARGB(128, 0, 0, 0));
		SetMoveable(true);
	}

	// process input
	void ConsoleUI::OnInputEvent(Client::InputEventArgs & e)
	{
		if (e.IsKeyEvent())
		{
			if (e.Type == InputEventArgs::kKeyDown)
			{
				switch (e.Code)
				{
				case KC_ESCAPE:
					break;

				case KC_UP:
				case KC_DOWN:
					if (e.ControlKeyDown)
					{
						Console.Scroll(PdeConsole::SCROLL_LINE, e.Code == KC_DOWN ? 1 : -1);
					}
					else
					{
						m_Text = GetHistoryCommand(e.Code == KC_DOWN);
						SetCursorPosition(-1);
					}
					break;

				case KC_PGUP :
				case KC_PGDOWN :
					Console.Scroll(PdeConsole::SCROLL_PAGE, e.Code == KC_PGDOWN ? 1 : -1);
					break;
				}
			}

			else if (e.Type == InputEventArgs::kChar)
			{
				if (e.Value == '\r' || e.Value == '\n')
				{
					if (m_Text.Length())
					{
						AddHistory(m_Text);
						Console.WriteLine(m_Text);
						Console.Scroll(PdeConsole::SCROLL_END, 0);

						Lua::LuaState *L = Lua::LuaState::FromThread();

						CStrBuf<1024> tempText(m_Text.Str());
						tempText = tempText.tolower();
						if( m_Text == "cls" )
						{
							Console.Clear();
						} 
						else
						{
							int status =
								L->LoadBuffer(m_Text.Str(), m_Text.Length(), "=[console]") ||
								L->DoCall(0, 0);

							if (status && !L->IsNil(-1))
							{
								Console.WriteLine(L->ToString(-1));
								L->Pop(1);
							}

							L->GC(Lua::GCCOLLECT, 0);
							
						}
						
					}else {
						// �����س�������ˢ��
						Console.WriteLine("\n");
					}

					m_Text.Clear();
					SetCursorPosition(0);

					e.Handled = true;
					return;
				}
			}

			if (!e.Handled)
			{
				if (OnKeyEvent(e, false))
				{
					e.Handled = true;
				}
			}
		}
		else if (e.IsMouseEvent())
		{
			// client cursor position
			Vector2 clientPos = ScreenToClient(e.CursorPosition);

			if (GetSelecting() || GetInputRect().IsPointInside(clientPos))
			{
 				SetCursorShape(Screen::kCursorInput);

				// to text space
				clientPos.x = clientPos.x + m_ScrollX;
				clientPos.y = clientPos.y ;

				if (OnMouseEvent(e, clientPos, GetFont()))
				{
					SetCapture(GetSelecting());
				}

				e.Handled = true;
			}
		}

		if (!e.Handled)
			Window::OnInputEvent(e);
	}


	/// Draw console output.
	void ConsoleUI::OnPaint(PaintEventArgs & e)
	{
		Window::OnPaint(e);
		
		char buff[PdeConsole::SCREEN_HEIGHT][PdeConsole::SCREEN_WIDTH];
		const int line_height = 18;

		// read console output.
		int data_size = Console.GetStream().Read(buff, sizeof(buff));

		// draw output
		for (int y = 0; y < PdeConsole::SCREEN_WIDTH; y++)
		{
			if (y * PdeConsole::SCREEN_WIDTH >= data_size)
				break;

			e.render->DrawString(GetFont(), m_TextColor, 0, Core::Rectangle(0, y * line_height, 0, 0), buff[y], 0, PdeConsole::SCREEN_WIDTH);
		}

		// control rectangle
		Core::Rectangle clientRect(GetInputRect());

		// draw input text
		clientRect.Move(Vector2(-m_ScrollX, 0));

		// padding center
		Vector2 location(clientRect.Min.x, 0);
		location.y = Floor((clientRect.Max.y + clientRect.Min.y - GetFont()->GetLineHeight()) / 2);

		DrawInputText(e.render, location, clientRect, GetTextColor(), XRGB(255,255,255), XRGB(49, 106, 197), m_CursorVisible, GetFocused(), GetFont());
	}

	// get history
	const char * ConsoleUI::GetHistoryCommand(bool prev)
	{
		U32 backup = m_HistoryCmdID;

		if (prev)
		{
			m_HistoryCmdID = m_HistoryCmdID == HISTORY_COUNT - 1 ? 0 : m_HistoryCmdID + 1;
		}
		else
		{
			m_HistoryCmdID = m_HistoryCmdID == 0 ? HISTORY_COUNT - 1 : m_HistoryCmdID - 1;
		}

		if (m_HistoryCmdID == m_FirstCmd || m_CmdHistorys[m_HistoryCmdID][0] == 0)
		{
			m_HistoryCmdID = backup;
		}

		return m_CmdHistorys[m_HistoryCmdID];
	}

	// add history
	void ConsoleUI::AddHistory(const char* cmd)
	{
		if (cmd && cmd[0])
		{
			m_CmdHistorys[m_FirstCmd] = cmd;
			m_FirstCmd = (m_FirstCmd + 1) % HISTORY_COUNT;
			m_HistoryCmdID = m_FirstCmd;
		}
	}

	
	/// on cursor move
	void ConsoleUI::OnCursorMove(Core::EventArgs & e)
	{
		// update cursor
		m_CursorTime = Core::Task::GetTotalTime();

		// update scroll
		Vector2 cursorPos;
		F32 size = GetSize().x - 1;

		if (GetFont()->CPtoX(m_Text.Str(), GetCursorPosition(), cursorPos))
		{
			if (cursorPos.x < m_ScrollX)
			{
				m_ScrollX = cursorPos.x;
			}
			else if (cursorPos.x > m_ScrollX + size)
			{
				m_ScrollX = cursorPos.x - size;

				if (m_ScrollX < 0)
					m_ScrollX = 0;
			}

			if (GetFont()->CPtoX(m_Text.Str(), m_Text.Length(), cursorPos))
			{
				if (cursorPos.x < m_ScrollX + size)
					m_ScrollX = cursorPos.x - size;

				if (m_ScrollX < 0)
					m_ScrollX = 0;
			}
		}

		InvalidRect(GetInputRect());
	}

	void ConsoleUI::OnFrameUpdate(Core::EventArgs & e)
	{
		bool showCursor = false;

		if (GetFocused())
			showCursor = ((static_cast<U32>((Core::Task::GetTotalTime() - m_CursorTime) * 2) & 1) == 0);

		if (m_CursorVisible != showCursor)
		{
			m_CursorVisible = showCursor;

			InvalidRect(GetInputRect());
		}

		m_OutputDirtyFlag.Check(Console.GetOutputDirtyFlag());
		if (m_OutputDirtyFlag.IsDirty())
		{
			Invalid();
			m_OutputDirtyFlag.Reset();
		}
	}

	Core::Rectangle ConsoleUI::GetInputRect()
	{
		const int line_height = 18;
		return Core::Rectangle(Vector2(0, 24 * line_height + 1), GetSize());
	}

	
	// clear
	void ConsoleUI::Clear()
	{
		Console.Clear();
	}
}

DEFINE_PDE_TYPE_CLASS(Gui::ConsoleUI)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::Window);
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_METHOD(Clear);
	}
};
REGISTER_PDE_TYPE(Gui::ConsoleUI);