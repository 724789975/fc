namespace Gui
{
	class Calendar: public Control
	{
		DECLARE_PDE_OBJECT(Calendar, Control);

	public:
		DECLARE_PDE_EVENT(EventButtonClick, Client::InputEventArgs);

	public:
		DECLARE_PDE_ATTRIBUTE_RW	(ButtonSpace,	Core::Vector2);
		DECLARE_PDE_ATTRIBUTE_RW	(HighSpace,		F32);
		DECLARE_PDE_ATTRIBUTE_RW	(BtnSkin,		tempc_ptr(Gui::ButtonSkin));
		DECLARE_PDE_ATTRIBUTE_RW	(BtnSkinSupply,	tempc_ptr(Gui::ButtonSkin));
		DECLARE_PDE_ATTRIBUTE_RW	(BtnSkinPrepare,tempc_ptr(Gui::ButtonSkin));
		DECLARE_PDE_ATTRIBUTE_RW	(CanSupplyNum,	int);
		DECLARE_PDE_ATTRIBUTE_RW	(CanPrepareNum,	int);
		DECLARE_PDE_ATTRIBUTE_RW	(CheckValue,	int);

	public:
		Calendar();
		~Calendar();

	void OnCreate();

	// on frame update
	virtual void OnFrameUpdate(EventArgs & e);

	// on paint
	virtual void OnPaint(PaintEventArgs & e);

	// on input event
	virtual	void OnInputEvent(Client::InputEventArgs & e);

	// set time
	void SetTime(int year, int month, int day, int week);

	// set DayActivate
	void SetDayActivate(int day);

	private:
		void _OnBtnClick(by_ptr(void) sender, InputEventArgs & e);

	protected:
		sharedc_ptr(Gui::Button)	m_itBtn;
		sharedc_ptr(Gui::ButtonSkin) m_itBtnSkin;

		sharedc_ptr(Gui::Button) m_Buttons[30];
		sharedc_ptr(Gui::ButtonSkin) m_BtnSkinSupply;
		sharedc_ptr(Gui::ButtonSkin) m_BtnSkinPrepare;

		Core::Vector2		m_ButtonSpace;
		F32					m_HighSpace;
		byte				m_Month_Day_Num[13];
		bool				m_AllDay_Signin[32];
		int					m_Year;
		int					m_Month;
		int					m_Day;
		int					m_Week;

		int					m_CanSupplyNum;
		int					m_CanPrepareNum;
		int					m_CheckValue;
	};
}

namespace Gui
{
	class CalendarSkin : public ControlSkin
	{
	public:
		INLINE_PDE_ATTRIBUTE_RW(DisabledImage,	tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(ActivateImage,	tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(InActivateImage,	tempc_ptr(Image));
	private:
		sharedc_ptr(Image) m_DisabledImage;
		sharedc_ptr(Image) m_ActivateImage;
		sharedc_ptr(Image) m_InActivateImage;
	};
}