#include "pch.h"

using namespace Core;
using namespace Gui;
using namespace Client;

#include <cstdio>

DEFINE_PDE_TYPE_CLASS(Gui::PdePropertyItem)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::ListItem);
		ADD_PDE_DEFAULT_CONSTRUCTOR();
		ADD_PDE_PROPERTY_RW(Value);
		ADD_PDE_PROPERTY_RW(Group);
		ADD_PDE_PROPERTY_RW(Readonly);
		ADD_PDE_PROPERTY_RW(IsGroup);
		ADD_PDE_PROPERTY_RW(OwnDraw);
		ADD_PDE_PROPERTY_R (Invalid);
		ADD_PDE_PROPERTY_R (PropertiesSupported);
		ADD_PDE_METHOD(VariableType);
		ADD_PDE_METHOD(GetItemString);
	}
};
REGISTER_PDE_TYPE(Gui::PdePropertyItem);

namespace Gui
{
	PdePropertyItem::PdePropertyItem()
		: m_Invalid(true)
		, m_Readonly(true)
		, m_IsGroup(true)
		, m_OwnDraw(false)
		, m_PropertyType(NullPtr)
	{
	}

	PdePropertyItem::~PdePropertyItem()
	{
	}
}

namespace Gui
{
//------------------------------------------------------------------------------------
// PdeEnumTypeInfo
//------------------------------------------------------------------------------------
	PdeEnumInfo::PdeEnumInfo(const Core::Identifier & name) {}
	PdeEnumInfo::~PdeEnumInfo() {};

	/// add item
	void PdeEnumInfo::AddItem(const Core::Identifier & name, U32 id, S32 enum_id)
	{
		m_Items.PushBack(EnumItem(name, id, enum_id));
	}

	/// to name
	const Core::Identifier & PdeEnumInfo::ToName(U32 id) const
	{
		for (U32 i = 0; i < m_Items.Size(); i ++)
		{
			if (m_Items[i].id == id)
				return m_Items[i].name;
		}

		return Core::Identifier::kNull;
	}

	/// to id
	U32 PdeEnumInfo::ToId(const Core::Identifier & name, U32 defaultValue, bool * error) const
	{
		for (U32 i = 0; i < m_Items.Size(); i ++)
		{
			if (m_Items[i].name == name)
			{
				if (error) *error = true;
				return m_Items[i].id;
			}
		}

		if (error) *error = false;
		return defaultValue;

	}
}

//--------------------------------------------------------------------------------------
// Attribute
//--------------------------------------------------------------------------------------
namespace Gui
{

	PDE_ATTRIBUTE_GETTER(PdePropertyItem, Value, tempc_ptr(void))
	{
		return m_Value;
	}


	PDE_ATTRIBUTE_SETTER(PdePropertyItem, Value, tempc_ptr(void))
	{
		if (!m_Value || !value || 0)/*!Core::PdeTypeInfo::Equals(m_Value, value))*/
		{
			m_Value = value;
			m_Invalid = true;
		}

		if (m_Invalid && GetOwner()/*.IsValid()*/)
		{
			UpdateProperties();
			GetOwner()->Invalid();
			m_Invalid = false;
		}
	}

	PDE_ATTRIBUTE_GETTER(PdePropertyItem, Group, tempc_ptr(PdePropertyItem))
	{
		return m_Group;
	}

	PDE_ATTRIBUTE_SETTER(PdePropertyItem, Group, tempc_ptr(PdePropertyItem))
	{
		if (m_Group != value && (!value/*.IsValid()*/ || value->GetIsGroup()))
		{
			m_Group = value;

			if (GetOwner()/*.IsValid()*/)
			{
				GetOwner()->Invalid();
			}
		}
	}

	PDE_ATTRIBUTE_GETTER(PdePropertyItem, PropertyType, tempc_ptr(PdeTypeInfo)/*const PdeTypeInfo **/)
	{
		return m_PropertyType;
	}

	PDE_ATTRIBUTE_SETTER(PdePropertyItem, PropertyType, tempc_ptr(PdeTypeInfo)/*const PdeTypeInfo **/)
	{
		if (m_PropertyType != value)
		{
			m_PropertyType = value;
		}
	}

	PDE_ATTRIBUTE_GETTER(PdePropertyItem, Readonly, bool)
	{
		return m_Readonly;
	}

	PDE_ATTRIBUTE_SETTER(PdePropertyItem, Readonly, bool)
	{
		if (m_Readonly != value )
		{
			m_Readonly = value;

			if (GetOwner()/*.IsValid()*/)
			{
				GetOwner()->Invalid();
			}
		}
	}

	PDE_ATTRIBUTE_GETTER(PdePropertyItem, OwnDraw, bool)
	{
		return m_OwnDraw;
	}

	PDE_ATTRIBUTE_SETTER(PdePropertyItem, OwnDraw, bool)
	{
		if (m_OwnDraw != value )
		{
			m_OwnDraw = value;

			if (GetOwner()/*.IsValid()*/)
			{
				GetOwner()->Invalid();
			}
		}
	}

	PDE_ATTRIBUTE_GETTER(PdePropertyItem, IsGroup, bool)
	{
		return m_IsGroup;
	}

	PDE_ATTRIBUTE_SETTER(PdePropertyItem, IsGroup, bool)
	{
		if (m_IsGroup != value )
		{
			m_IsGroup = value;

			if (GetOwner()/*.IsValid()*/)
			{
				GetOwner()->Invalid();
			}
		}
	}

	PDE_ATTRIBUTE_SETTER(PdePropertyItem, Invalid, bool)
	{
		if (m_Invalid != value )
		{
			m_Invalid = value;
		}
	}

	PDE_ATTRIBUTE_GETTER(PdePropertyItem, Invalid, bool)
	{
		return m_Invalid;
	}

	PDE_ATTRIBUTE_GETTER(PdePropertyItem, PropertiesSupported, bool)
	{
		const sharedc_ptr(void) value = GetValue();
			
		tempc_ptr(PdeTypeInfo) type = ptr_typeof(value);

		return value && type->GetTypeKind() == PdeTypeInfo::kClass;
	}

	PDE_ATTRIBUTE_GETTER(PdePropertyItem, StandardValuesSupported, bool)
	{
		const sharedc_ptr(void) value = GetValue();

		tempc_ptr(PdeTypeInfo) type = ptr_typeof(value);
		
		if(type)
		{
			PdeTypeInfo::Kind kind = type->GetTypeKind();

			return m_Values.Size() ||
				kind == PdeTypeInfo::kBool ||
				kind == PdeTypeInfo::kEnum;
		}
		else return false;

	}
}
//
//
//--------------------------------------------------------------------------------------
// Event
//--------------------------------------------------------------------------------------
namespace Gui
{
	void PdePropertyItem::OnCreate()
	{
		Super::OnCreate();
		SetColumnCount(2);
	}
}


//--------------------------------------------------------------------------------------
// Method
//--------------------------------------------------------------------------------------
namespace Gui
{

	PdePropertyItem::EditStyle PdePropertyItem::GetEditStyle()
	{
		const sharedc_ptr(void) value = GetValue();
		
		if (value)
		{
			tempc_ptr(PdeTypeInfo) type = ptr_typeof(value);
			
			if (type == PDE_TYPE_OF(Color3) ||
				type == PDE_TYPE_OF(Color4) ||
				type == PDE_TYPE_OF(XRGB) ||
				type == PDE_TYPE_OF(ARGB))
				return kModal;
		}
		return kNone;
	}

	///!important
	Core::Array<PdePropertyItem::PropertyItem> PdePropertyItem::GetProperties()
	{
		Core::Array<PdePropertyItem::PropertyItem> tempArray;

		const sharedc_ptr(void) value = GetValue();

		if (value)
		{
			tempc_ptr(PdeTypeInfo) type = ptr_typeof(value);

			if (type->GetTypeKind() == PdeTypeInfo::kClass)
			{
				tempc_ptr(void) ptr = value;

				if (ptr)
				{
					int member_count = type->GetMemberCount();
					for (int i = 0; i < member_count; ++i)
					{
						tempc_ptr(PdeMemberInfo) member = type->GetMemberById(i);

						if (member->GetMemberKind() == PdeMemberInfo::kField)
						{
							//<-->
							tempc_ptr(PdeFieldInfo) field_info = ptr_static_cast<PdeFieldInfo>(member);

							if (field_info)
							{
								//PdeClassPtr temp;
								sharedc_ptr(void) temp;
								bool ret = field_info->GetValue(ptr, temp);
								if (ret)
									tempArray.PushBack(PropertyItem(field_info->GetName(), temp, field_info->GetFieldType()));
							}
						}
						else if (member->GetMemberKind() == PdeMemberInfo::kProperty)
						{
							tempc_ptr(PdePropertyInfo) property_info = ptr_static_cast<PdePropertyInfo>(member);

							if (property_info)
							{
								//PdeClassPtr temp;
								sharedc_ptr(void) temp;
								bool ret = property_info->GetValue(ptr, temp);
								if (ret)
									tempArray.PushBack(PropertyItem(property_info->GetName(), temp, property_info->GetPropertyType()));
							}
						}
					}
				}
			}
		}

		return tempArray;
	}

	bool PdePropertyItem::SetProperty(sharedc_ptr(PdePropertyItem) item)
	{
		const sharedc_ptr(void) value = GetValue();

		if (!item/*.IsValid()*/)
			return false;

		if (value)
		{
			m_Invalid = ChangeItemProperty(item);

			if (m_Invalid)
			{
				UpdateProperties();
				m_Invalid = false;
				return true;
			}
		}

		return false;
	}

	bool PdePropertyItem::UpdateProperties()
	{
		if (GetFirstChild() && GetPropertiesSupported())
		{
			Core::Array<PropertyItem> temp = GetProperties();
			U32 i = 0;

			for (tempc_ptr(ListItem) pNode = GetFirstChild(); pNode; pNode = pNode->GetNext())
			{
				tempc_ptr(PdePropertyItem) p = ptr_static_cast<PdePropertyItem>(pNode);

				if (i >= temp.Size())
					break;

					if (p)
						p->SetValue(temp[i].Value);

					++i;
			}

			return true;
		}
		
		return false;
	}

	Core::Array<PdeEnumInfo::EnumItem> PdePropertyItem::GetStandardValues()
	{
		if (m_Values.Size())
			return m_Values;

		const sharedc_ptr(void) value = GetValue();
		const tempc_ptr(PdeTypeInfo) type = ptr_typeof(value);

		Core::Array<PdeEnumInfo::EnumItem> values;
		
		if (type->GetTypeKind() == PdeTypeInfo::kBool)
		{
			values.PushBack(PdeEnumInfo::EnumItem("false", -1, -1));
			values.PushBack(PdeEnumInfo::EnumItem("true", -1, -1));
		}
		else if (type->GetTypeKind() == PdeTypeInfo::kEnum)
		{
#if 1
			if(type == PDE_TYPE_OF(Control::DockKind))
			{
				values.PushBack(PdeEnumInfo::EnumItem("kDockLeft", -1, Control::kDockLeft));
				values.PushBack(PdeEnumInfo::EnumItem("kDockRight", -1, Control::kDockRight));
				values.PushBack(PdeEnumInfo::EnumItem("kDockTop", -1, Control::kDockTop));
				values.PushBack(PdeEnumInfo::EnumItem("kDockBottom", -1, Control::kDockBottom));
				values.PushBack(PdeEnumInfo::EnumItem("kDockFill", -1, Control::kDockFill));
			}
			else if(type == PDE_TYPE_OF(Window::SurfaceType))
			{
				values.PushBack(PdeEnumInfo::EnumItem("kPlane", -1, Window::kPlane));
				values.PushBack(PdeEnumInfo::EnumItem("kCylinder", -1, Window::kCylinder));
			}
			else if(type == PDE_TYPE_OF(ParticleResource::Emitter_Type))
			{
				values.PushBack(PdeEnumInfo::EnumItem("EmitterPoint", -1, ParticleResource::kEmitterPoint));
				values.PushBack(PdeEnumInfo::EnumItem("EmitterPlane", -1, ParticleResource::kEmitterPlane));	
				values.PushBack(PdeEnumInfo::EnumItem("EmitterCube", -1, ParticleResource::kEmitterCube));
			}
			else if(type == PDE_TYPE_OF(AlphaBlendMode))
			{
				values.PushBack(PdeEnumInfo::EnumItem("AlphaBase", -1, kSourceAlphaAdd));
				values.PushBack(PdeEnumInfo::EnumItem("ColorBase", -1, kAlphaBlend));	
				values.PushBack(PdeEnumInfo::EnumItem("Additive", -1, kAdditive));
				values.PushBack(PdeEnumInfo::EnumItem("AlphaClip", -1, kAlphaTest));
				values.PushBack(PdeEnumInfo::EnumItem("BlendNone", -1, kBlendNone));
			}
			else if(type == PDE_TYPE_OF(ParticleResource::Particle_Type))
			{
				values.PushBack(PdeEnumInfo::EnumItem("Camera", -1, ParticleResource::kCamera));
				values.PushBack(PdeEnumInfo::EnumItem("Horizontal", -1, ParticleResource::kHorizontal));	
				values.PushBack(PdeEnumInfo::EnumItem("VelocityImposter", -1, ParticleResource::kVelocityImposter));
				values.PushBack(PdeEnumInfo::EnumItem("FollowVelocity", -1, ParticleResource::kFollowVelocity));
			}
			else if(type == PDE_TYPE_OF(ParticleResource::Particle_Quality))
			{
				values.PushBack(PdeEnumInfo::EnumItem("Normal", -1, ParticleResource::kQualityNormal));
				values.PushBack(PdeEnumInfo::EnumItem("LowQualityNoSee", -1, ParticleResource::kLowQualityNoSee));
			}
			else if(type == PDE_TYPE_OF(ParticleResource::Coordinate_Type))
			{
				values.PushBack(PdeEnumInfo::EnumItem("Local", -1, ParticleResource::kLocal));
				values.PushBack(PdeEnumInfo::EnumItem("World", -1, ParticleResource::kWorld));
			}
			else {
				//do not support enum, so fill wrong data to avoid crash
				values.PushBack(PdeEnumInfo::EnumItem("EnumItem_None", -1, 0));
			}
#endif 

#if 0
			const tempc_ptr(PdeEnumInfo) p = ptr_static_cast<PdeEnumInfo>(type);

			if (p)
			{
				Array<PdeEnumInfo::EnumItem>* pArray = &(p->Items());

				U32 size = pArray->Size();
				for (U32 i=0; i<size; ++i)
					values.PushBack((*pArray)[i]);
			}
#endif
		}

		return values;
	}

	void PdePropertyItem::AddStandardValue(const Core::String & value, S32 id, S32 enum_id)
	{
		m_Values.PushBack(PdeEnumInfo::EnumItem(Core::Identifier(value), id, enum_id));
	}

	Core::String PdePropertyItem::GetItemString()
	{
		return ValueToString(GetValue());
	}

	void PdePropertyItem::StringToValue(const Core::String & value)
	{
#if 0
		//const PdeClassPtr & ptr = GetValue();
		const tempc_ptr(void) ptr = GetValue();

		if (ptr)
		{
			//PdeClassPtr ret = ptr->GetType()->Parse(value);
			tempc_ptr(void) ret = ptr_typeof(ptr)->Parse(value);

			if (ret)
			{
				m_Value = ret;
				m_Invalid = true;
				UpdateProperties();
			}
		}
#endif
		const tempc_ptr(void) ptr = GetValue();

		sharedc_ptr(void) ret;

		tempc_ptr(PdeTypeInfo) type = ptr_typeof(ptr);

		if (ptr)
		{
			if(type == PDE_TYPE_OF(Vector4))
			{
				F32 x,y,z,w;

				sscanf_s(value.Str(), "%f,%f,%f,%f", 
					&x, 
					&y, 
					&z, 
					&w);

				ret = ptr_new Vector4(x,y,z,w);
			}
			else if (type == PDE_TYPE_OF(Vector3))
			{
				F32 x,y,z;

				sscanf_s(value.Str(), "%f,%f,%f", 
					&x, 
					&y, 
					&z);

				ret = ptr_new Vector3(x,y,z);
			}
			else if(type == PDE_TYPE_OF(Vector2))
			{
				F32 x,y;

				sscanf_s(value.Str(), "%f,%f", 
					&x, 
					&y);

				ret = ptr_new Vector2(x,y);
			}
			else if(type == PDE_TYPE_OF(String))
			{
				ret = ptr_new String(value);
			}
			else if(type == PDE_TYPE_OF(Identifier))
			{
				ret = ptr_new Identifier(value);
			}
			else {
				PdeTypeInfo::Kind t = type->GetTypeKind();
				if(
					(t == PdeTypeInfo::kInt16)
					|| (t == PdeTypeInfo::kInt8)
					|| (t == PdeTypeInfo::kFloat)
					|| (t == PdeTypeInfo::kDouble))
				{
					ret = ptr_new float;

					sscanf_s(value.Str(), "%f", ret);
				}
				else if((t == PdeTypeInfo::kInt32))
				{
					ret = ptr_new int;

					sscanf_s(value.Str(), "%d", ret);
				}
				else if((t == PdeTypeInfo::kUInt8))
				{
					ret = ptr_new U8;

					sscanf_s(value.Str(), "%u", ret);
				}
				else if((t == PdeTypeInfo::kUInt16))
				{
					ret = ptr_new U16;

					sscanf_s(value.Str(), "%u", ret);
				}
				else if((t == PdeTypeInfo::kUInt32))
				{
					ret = ptr_new U32;

					sscanf_s(value.Str(), "%u", ret);
				}
				else if((t == PdeTypeInfo::kBool))
				{
					ret = ptr_new bool;
				
					*ptr_static_cast<bool>(ret) = (value.RefStr().icompare("false") == 0 || value.RefStr().icompare("0") == 0) ? false: true;
				}
				else if((t == PdeTypeInfo::kClass))
				{
				}
				else if((t == PdeTypeInfo::kEnum))
				{
					U32 size = GetStandardValues().Size();
					Core::Array<PdeEnumInfo::EnumItem> enum_array = GetStandardValues();
					
					ret = PdeTypeInfo::CreateInstance(type->GetName());

					for(U32 i=0; i < size; ++i)
					{
						if(value.RefStr().icompare(enum_array[i].name) == 0)
						{
							*ptr_static_cast<S32>(ret) = enum_array[i].enum_id;
							break;
						}
					}
				}
			}

			if (ret)
			{
				m_Value = ret;
				m_Invalid = true;
				UpdateProperties();
			}
		}

	}

	Core::String PdePropertyItem::ValueToString(const by_ptr(void) value)
	{
		tempc_ptr(PdeTypeInfo) type = ptr_typeof(value);

		if(!type && !value)
			return String::kEmpty;

		if(type == PDE_TYPE_OF(ARGB))
		{			
			tempc_ptr(ARGB) ptr = ptr_static_cast<ARGB>(value);
			
			return Core::String::Format("%u, %u, %u, %u",ptr->r,ptr->g,ptr->b,ptr->a);
		}
		else if(type == PDE_TYPE_OF(Vector4))
		{
			tempc_ptr(Vector4) ptr = ptr_static_cast<Vector4>(value);
			
			return Core::String::Format("%g, %g, %g, %g",ptr->x,ptr->y,ptr->z,ptr->w);
		}
		else if (type == PDE_TYPE_OF(Vector3))
		{
			tempc_ptr(Vector3) ptr = ptr_static_cast<Vector3>(value);

			return Core::String::Format("%g, %g, %g",ptr->x,ptr->y,ptr->z);
		}
		else if(type == PDE_TYPE_OF(Vector2))
		{
			tempc_ptr(Vector2) ptr = ptr_static_cast<Vector2>(value);

			return Core::String::Format("%g, %g",ptr->x,ptr->y);
		}
		else if(type == PDE_TYPE_OF(String))
		{
			tempc_ptr(String) ptr = ptr_static_cast<String>(value);

			return Core::String(ptr->Str());
		}
		else if(type == PDE_TYPE_OF(Identifier))
		{
			const char* ptr = (ptr_static_cast<Identifier>(value))->Str();

			return Core::String(ptr);
		}
		else {
			PdeTypeInfo::Kind t = type->GetTypeKind();
			if(
				(t == PdeTypeInfo::kInt16)
				|| (t == PdeTypeInfo::kInt8)
				|| (t == PdeTypeInfo::kFloat)
				|| (t == PdeTypeInfo::kDouble))
			{
				return Core::String::Format("%g",*(ptr_static_cast<float>(value)));
			}
			else if((t == PdeTypeInfo::kInt32))
			{
				return Core::String::Format("%d",*(ptr_static_cast<int>(value)));
			}
			else if((t == PdeTypeInfo::kUInt8))
			{
				return Core::String::Format("%u",*(ptr_static_cast<U8>(value)));
			}
			else if((t == PdeTypeInfo::kUInt16))
			{
				return Core::String::Format("%u",*(ptr_static_cast<U16>(value)));
			}
			else if((t == PdeTypeInfo::kUInt32))
			{
				return Core::String::Format("%u",*(ptr_static_cast<U32>(value)));
			}
			else if((t == PdeTypeInfo::kBool))
			{
				tempc_ptr(bool) ptr = ptr_static_cast<bool>(value);
				if(*ptr == true)
				{
					return "true";
				}
				else {
					return "false";
				}
			}				
			else if((t == PdeTypeInfo::kClass))
			{
				Identifier id = type->GetName();

				return Core::String::Format("%s: 0x%x", id, *(ptr_static_cast<U32>(value)));
			}
			else if((t == PdeTypeInfo::kEnum))
			{
				if (value)
				{
					U32 size = GetStandardValues().Size();
					Core::Array<PdeEnumInfo::EnumItem> enum_array = GetStandardValues();

					for(U32 i=0; i < size; ++i)
					{
						if(*ptr_static_cast<S32>(value) == enum_array[i].enum_id)
						{
							return enum_array[i].name;
						}
					}
				}
			}
		}

		return Core::String::kEmpty;
	}

	PdeTypeInfo::Kind PdePropertyItem::VariableType()
	{
		if (m_Value)
			return ptr_typeof(m_Value)->GetTypeKind();

		return PdeTypeInfo::kVoid;
	}

	bool PdePropertyItem::IsNumeric()
	{
		PdeTypeInfo::Kind t = VariableType();
		return (t == PdeTypeInfo::kInt32)
			|| (t == PdeTypeInfo::kUInt32)
			|| (t == PdeTypeInfo::kInt16)
			|| (t == PdeTypeInfo::kUInt16)
			|| (t == PdeTypeInfo::kInt8)
			|| (t == PdeTypeInfo::kUInt8)
			|| (t == PdeTypeInfo::kFloat)
			|| (t == PdeTypeInfo::kDouble);
	}

	/// item set property
	bool PdePropertyItem::ChangeItemProperty(by_ptr(PdePropertyItem) hItem)
	{
		const tempc_ptr(void) value = GetValue();

		if (!hItem/*.IsValid()*/)
			return false;

		if (value)
		{
			//const PdeTypeInfo * type = value->GetType();
			const tempc_ptr(PdeTypeInfo) type = ptr_typeof(value);

			//if (type->GetTypeKind() != PdeTypeInfo::kStruct)
			if (type->GetTypeKind() != PdeTypeInfo::kClass)
				return false;

			//void * ptr = static_cast<PdeBoxed*>(value.ToPointer())->ToPointer();
			tempc_ptr(void) ptr = value;

			if (!ptr)
				return false;

			//const PdeMemberInfo * member = type->GetMember(hItem->GetText(0));
			const tempc_ptr(PdeMemberInfo) member = type->GetMember(hItem->GetText(0));

			if (!member)
				return false;
				
			//if (member->GetMemberType() == PdeMemberInfo::kField)
			if (member->GetMemberKind() == PdeMemberInfo::kField)
			{
				//const PdeFieldInfo * p = static_cast<const PdeFieldInfo *>(member);
				const tempc_ptr(PdeFieldInfo) p = ptr_static_cast<const PdeFieldInfo>(member);

				if (!p)
					return false;

				//PdeClassPtr temp = hItem->GetValue();
				tempc_ptr(void) temp = hItem->GetValue();

				p->SetValue(ptr, temp);
				return true;
			}
			//else if (member->GetMemberType() == PdeMemberInfo::kProperty)
			else if (member->GetMemberKind() == PdeMemberInfo::kProperty)
			{
				//const PdePropertyInfo * p = static_cast<const PdePropertyInfo *>(member);
				const tempc_ptr(PdePropertyInfo) p = ptr_static_cast<const PdePropertyInfo>(member);
				
				if (!p)
					return false;

				//PdeClassPtr temp = hItem->GetValue();
				tempc_ptr(void) temp = hItem->GetValue();

				p->SetValue(ptr, temp);
				return true;
			}
		}

		return false;
	}

	/// Property type
	const Core::Identifier & PdePropertyItem::PropertyItemType(by_ptr(Core::PdeTypeInfo) typeInfo)
	{
		if (typeInfo == PDE_TYPE_OF(Quaternion))
			return PDE_TYPE_NAME(PdePropertyItemQuaternion);

		return PDE_TYPE_NAME(PdePropertyItem);
	}
}


/// PdePropertyItemQuaternion
namespace Gui
{
	PdePropertyItemQuaternion::PdePropertyItemQuaternion()
	{
	}

	PdePropertyItemQuaternion::~PdePropertyItemQuaternion()
	{
	}
}

//--------------------------------------------------------------------------------------
// Method
//--------------------------------------------------------------------------------------
namespace Gui
{
	Core::Array<PdePropertyItem::PropertyItem> PdePropertyItemQuaternion::GetProperties()
	{
		Core::Array<PropertyItem> tempArray;

		//const PdeClassPtr & value = GetValue();
		const tempc_ptr(void) value = GetValue();

		if (value)
		{
			//const PdeTypeInfo * type = value->GetType();
			const tempc_ptr(PdeTypeInfo) type = ptr_typeof(value);

			//if (type == PdeTypeTraits<Quaternion>::Type())
			if (type == PDE_TYPE_OF(Quaternion))
			{
				//Quaternion * p = PdeTypeTraits<Quaternion>::UnboxingPtr(value);
				tempc_ptr(Quaternion) p = ptr_static_cast<Quaternion>(value);

				if (p)
				{
					Vector3 v = p->GetZXY() * RAD2DEG;

					tempArray.PushBack(PropertyItem("X", ptr_new float(v.x)/*PdeTypeTraits<F32>::BoxingValue(v.x)*/, PDE_TYPE_NAME(F32)));//PdeTypeTraits<F32>::Type()));
					tempArray.PushBack(PropertyItem("Y", ptr_new float(v.y)/*PdeTypeTraits<F32>::BoxingValue(v.y)*/, PDE_TYPE_NAME(F32)));//PdeTypeTraits<F32>::Type()));
					tempArray.PushBack(PropertyItem("Z", ptr_new float(v.z)/*PdeTypeTraits<F32>::BoxingValue(v.z)*/, PDE_TYPE_NAME(F32)));//PdeTypeTraits<F32>::Type()));
				}
			}
		}

		return tempArray;
	}

	bool PdePropertyItemQuaternion::ChangeItemProperty(by_ptr(PdePropertyItem) hItem)
	{
		if (!hItem/*.IsValid()*/)
			return false;

		//const PdeClassPtr & value = GetValue();
		tempc_ptr(void) value = GetValue();

		if (value)
		{
			//const PdeTypeInfo * type = value->GetType();
			
			tempc_ptr(PdeTypeInfo) type = ptr_typeof(value);
			
			//if (type == PdeTypeTraits<Quaternion>::Type())
			if (type == PDE_TYPE_OF(Quaternion))
			{
				//Quaternion * p = PdeTypeTraits<Quaternion>::UnboxingPtr(value);

				tempc_ptr(Quaternion) p = ptr_static_cast<Quaternion>(value);

				if (!p) return false;

				Vector3 v = p->GetZXY() * RAD2DEG;

				//const PdeClassPtr & itemValue = hItem->GetValue();

				const tempc_ptr(void) itemValue = hItem->GetValue();

				if (!itemValue) return false;

				//F32 * deg = PdeTypeTraits<F32>::UnboxingPtr(itemValue);

				tempc_ptr(F32) deg = ptr_static_cast<F32>(itemValue);

				if (!deg) return false;

				switch (*hItem->GetText(0).Str())
				{
				case 'X': v.x = *deg; break;
				case 'Y': v.y = *deg; break;
				case 'Z': v.z = *deg; break;
				}

				Quaternion temp;
				temp.SetZXY(v * DEG2RAD);

				if (*p != temp)
				{
					//SetValue(PdeTypeTraits<Quaternion>::BoxingValue(temp));
					//SetValue(Boxing::ByValue(temp));
					
					SetValue(ptr_new Quaternion(temp));
					
					return true;
				}
			}
		}

		return false;
	}

}


