#include "pch.h"

using namespace Core;
using namespace Client;
using namespace Gui;

//--------------------------------------------------------------------------------------
// type info
//--------------------------------------------------------------------------------------

DEFINE_PDE_TYPE_CLASS(NoticeBoard)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Balloon);
		ADD_PDE_DEFAULT_CONSTRUCTOR();
	}
};

REGISTER_PDE_TYPE(NoticeBoard);

namespace Gui
{
	NoticeBoard::NoticeBoard()
		: m_Alpha(0.0f)
	{
		SetAutoWrap(false);
	}

	NoticeBoard::~NoticeBoard()
	{
	}

	void NoticeBoard::IncreaseAlpha()
	{
		float frameTime = Task::GetFrameTime();

		if(m_Alpha<=0.99f)
		{
			m_Alpha += frameTime/m_CONTROL_HOVER_EFFECT_DURATION;
		}
		if(m_Alpha>0.99f)
			m_Alpha = 1.f;
	}

	void NoticeBoard::DecreaseAlpha()
	{
		float frameTime = Task::GetFrameTime();

		if(m_Alpha>=0.01f)
		{
			m_Alpha -= frameTime/m_CONTROL_HOVER_EFFECT_DURATION;
		}
		if(m_Alpha<0.01f)
			m_Alpha = 0.f;
	}

	void NoticeBoard::OnFrameUpdate( EventArgs & e )
	{
		Control::OnFrameUpdate(e);
		Shine();
		if(m_Started)
		{
			F32 frameTime = Task::GetFrameTime();
			m_Timer-=frameTime;
			if(m_Showing)
			{
				IncreaseAlpha();
				if(Core::Abs(m_Alpha-1.f)<Core::EPSILON)
					m_Showing = false;
			}

			SetVisible(CheckVisibility());
		}
		if(m_Timer<0.f)
		{
			DecreaseAlpha();
			if(Core::Abs(m_Alpha)<Core::EPSILON)
			{
				if(m_Owner)
					m_Owner = NullPtr;
				m_Started = false;
				Task::Post(NewGenericTask(&NoticeBoard::Terminate, ptr_static_cast<NoticeBoard>(this)));
			}
		}

	}

	void NoticeBoard::OnPaint( PaintEventArgs & e )
	{
		tempc_ptr(BalloonSkin) skin = ptr_static_cast<BalloonSkin>(GetSkin());
		Core::Rectangle textRect = GetClientRect();
		textRect.Shrink(m_TextPadding);
		U8 uAlpha = (U8)(m_Alpha*255);
		if(skin && skin->GetArrowDownImage())
		{
			Core::Rectangle arrowRect = Core::Rectangle::LeftTop(Vector2::kZero, skin->GetArrowDownImage()->GetSize());
			if(m_AboveBase)
				arrowRect.Move(Vector2(m_ArrowCenter-arrowRect.GetExtent().x/2, GetSize().y-arrowRect.GetExtent().y-8*GetHoverPower()));								
			else
				arrowRect.Move(Vector2(m_ArrowCenter-arrowRect.GetExtent().x/2, 8*GetHoverPower()));
			Skin::DrawImage(e.render, skin->GetBackgroundImage(), GetClientRect(), ARGB(uAlpha, 255,255,255));
			if(m_AboveBase)
				Skin::DrawImage(e.render, skin->GetArrowDownImage(), arrowRect, ARGB(uAlpha, 255,255,255));
			else
				Skin::DrawImage(e.render, skin->GetArrowUpImage(), arrowRect, ARGB(uAlpha, 255,255,255));

			ARGB textColor = GetTextColor();
			ARGB textShadowColor = GetTextShadowColor();
			textColor.a = uAlpha;
			textShadowColor.a = uAlpha;
			e.render->DrawStringShadow(GetFont(), GetTextColor(), GetTextShadowColor(), ARGB(0,0,0,0), textRect, m_MultiLineStr
				, Unit::kAlignCenterMiddle, -1, GetTextLightSource());
		}
		else
		{
			e.render->DrawRectangle(GetClientRect(), Core::Rectangle(0,0,1,1));
			e.render->DrawString(GetFont(), ARGB(255,255,0,0), ARGB(0,0,0,0), textRect, m_MultiLineStr
				, Unit::kAlignCenterMiddle);		
		}
	}

	void NoticeBoard::UpdateLocation(const Core::Rectangle& globalBaseRect, bool bOnTop /* = true */)
	{
		tempc_ptr(BalloonSkin) skin = ptr_static_cast<BalloonSkin>(GetSkin());
		if(skin && skin->GetBackgroundImage())
		{
			Vector2 aSize = m_Size;
			aSize.y = skin->GetBackgroundImage()->GetSize().y;
			SetSize(aSize);
		}
		Vector2 aPos;
		F32 leftBound = m_TextPadding.x;
		F32 rightBound = m_TextPadding.z;
		F32 CenterTollerance = m_ArrowWidth/2;
		F32 ContentWidth = m_Size.x-leftBound-rightBound;
		F32 CenterLeft = leftBound+ContentWidth/2;
		F32 CenterRight = rightBound+ContentWidth/2;
		m_ArrowCenter = leftBound+ContentWidth/2;		

		Core::Vector2 screenSize = gGame->guiSys->GetSize();

		Vector2 basePointTop = globalBaseRect.GetCenter()-Vector2(0, globalBaseRect.GetExtent().y/2);
		Vector2 basePointBottom = globalBaseRect.GetCenter()+Vector2(0, globalBaseRect.GetExtent().y/2);
		m_AboveBase = bOnTop;
		if(bOnTop)
		{
			//Try to put it on top
			if(basePointTop.y-m_Size.y<0)
				m_AboveBase = false;
		}
		else
		{
			if(basePointBottom.y+m_Size.y>screenSize.y)
				m_AboveBase = true;
		}
		aPos.y = m_AboveBase?(basePointTop.y-m_Size.y):(basePointBottom.y);
		aPos.x = basePointTop.x-CenterLeft;

		//Test the right boundary
		if(basePointTop.x+CenterRight>screenSize.x)
		{
			F32 difference = basePointTop.x+CenterRight-screenSize.x;
			if(difference<CenterRight-CenterTollerance-rightBound)
			{
				aPos.x-=difference;
				m_ArrowCenter+=difference;
			}
			else
			{
				aPos.x-=CenterRight-CenterTollerance-rightBound;
				m_ArrowCenter+=CenterRight-CenterTollerance-rightBound;
			}
		}

		//Test the left boundary
		if(basePointTop.x-CenterLeft<0)
		{
			F32 difference = CenterLeft - basePointTop.x;
			if(difference<CenterLeft-CenterTollerance-leftBound)
			{
				aPos.x+=difference;  //Should be 0
				m_ArrowCenter-=difference;
			}
			else
			{
				aPos.x+=CenterLeft-CenterTollerance-leftBound;
				m_ArrowCenter-=CenterLeft-CenterTollerance-leftBound;
			}
		}
		aPos.x = Core::Floor(aPos.x+0.5f);
		aPos.y = Core::Floor(aPos.y+0.5f);
		SetLocation(aPos);
	}
}