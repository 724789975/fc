namespace Gui
{
	class HeaderSkin;

	class ListTreeViewSkin: public ScrollableControlSkin
	{
		DECLARE_PDE_OBJECT(ListTreeViewSkin, ScrollableControlSkin)
	public:
		INLINE_PDE_ATTRIBUTE_RW(ExpandedImage,	tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(CollapsedImage,	tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(VDashImage,		tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(HalfVDashImage,	tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(HalfHDashImage,	tempc_ptr(Image));

		INLINE_PDE_ATTRIBUTE_RW(GridLineColor,		Core::ARGB);

	private:

		sharedc_ptr(Image) m_ExpandedImage;
		sharedc_ptr(Image) m_CollapsedImage;
		sharedc_ptr(Image) m_VDashImage;
		sharedc_ptr(Image) m_HalfVDashImage;
		sharedc_ptr(Image) m_HalfHDashImage;

		Core::ARGB		m_GridLineColor;
	};
}

namespace Gui
{
	class Header;

	/// base class of ui elements
	class ListTreeView : public ScrollableControl
	{
		DECLARE_PDE_OBJECT(ListTreeView, ScrollableControl)
	public:
		typedef Core::IDelegate<bool (*)(by_ptr(ListItem) item1, by_ptr(ListItem) item2, S32 column, int reverse)> SortFunc;

		interface IDefaultStrCompareFunc : SortFunc
		{
			bool operator ()(by_ptr(ListItem) item1, by_ptr(ListItem) item2, S32 column, int reverse)
			{
				const Core::String & ta = item1->GetText(column);
				const Core::String & tb = item2->GetText(column);

				return ta.RefStr().icompare(tb.RefStr()) < 0;
			}
			void Invoke(Core::IArguments & args) { throw Core::ArgumentNullException(0); };
		};

	public:
		static const F32 LEVELSPACE;
		static const F32 BORDER_WIDTH;
		static const F32 SPLIT_WIDTH;
		static const F32 MIN_WIDTH;
	public:
		ListTreeView();
		~ListTreeView();

	public:
		struct SortCompare
		{
			U32 Column;

			SortCompare(U32 column)
			{
				Column = column;
			}

			virtual bool operator ()(sharedc_ptr(ListItem) a, sharedc_ptr(ListItem) b) const
			{
				const Core::String & ta = a->GetText(Column);
				const Core::String & tb = b->GetText(Column);

				return ta.RefStr().icompare(tb.RefStr()) < 0;
			}
		};

		struct FilterCompare
		{
			U32 Column;

			FilterCompare(U32 column)
			{
				Column = column;
			}

			virtual bool operator ()(sharedc_ptr(ListItem) a, const Core::String& str) const
			{
				const Core::String & ta = a->GetText(Column);

				return ta.RefStr().icompare(str.RefStr()) == 0;
			}
		};

	public:
		DECLARE_PDE_EVENT(EventDelete,				EventArgs);
		DECLARE_PDE_EVENT(EventItemChange,			EventArgs);
		DECLARE_PDE_EVENT(EventSplitDoubleClick,	HeaderEventArgs);
		DECLARE_PDE_EVENT(EventSelectItemChange,	ListItemEventArgs);
		DECLARE_PDE_EVENT(EventDoubleClick,			ListItemEventArgs);
		DECLARE_PDE_EVENT(EventClick,				InputEventArgs);
		DECLARE_PDE_EVENT(EventCheckChanged,		Core::EventArgs);
		DECLARE_PDE_EVENT(EventRightClick,			InputEventArgs);
		DECLARE_PDE_EVENT(EventExpand,				ListItemEventArgs);
		DECLARE_PDE_EVENT(EventColumnEdit,			ListItemEventArgs);
		DECLARE_PDE_EVENT(EventColumnEditEnter,		EditColumnEventArgs);
		DECLARE_PDE_EVENT(EventNodeMouseEnter,		ListItemInputEventArgs);
		DECLARE_PDE_EVENT(EventNodeMouseLeave,		ListItemInputEventArgs);
		DECLARE_PDE_EVENT(EventNodeColumnMouseEnter,ListItemInputEventArgs);
		DECLARE_PDE_EVENT(UpdateMouseMove,			Core::EventArgs);
	public:
		DECLARE_PDE_ATTRIBUTE_RW	(CheckIndex,		S32);
		DECLARE_PDE_ATTRIBUTE_R		(PointedItem,		tempc_ptr(ListItem));
		DECLARE_PDE_ATTRIBUTE_RW	(SelectedItem,		sharedc_ptr(ListItem));
		DECLARE_PDE_ATTRIBUTE_RW	(SelectingIndex,		S32);
		DECLARE_PDE_ATTRIBUTE_RW	(MultiSelect,		bool);
		DECLARE_PDE_ATTRIBUTE_RW	(TreeVisible,		bool);
		DECLARE_PDE_ATTRIBUTE_RW	(HeaderVisible,		bool);
		DECLARE_PDE_ATTRIBUTE_RW	(GridLines,			bool);
		DECLARE_PDE_ATTRIBUTE_RW	(ShowLines,			bool);
		DECLARE_PDE_ATTRIBUTE_RW	(AutoColumnSize,	bool);
		DECLARE_PDE_ATTRIBUTE_RW	(UseFistColumn,		bool);
		DECLARE_PDE_ATTRIBUTE_RW	(UseColumnNum,		F32);
		DECLARE_PDE_ATTRIBUTE_RW	(MY_SPLIT_WIDTH,	F32);
		DECLARE_PDE_ATTRIBUTE_RW	(UseColFontSize,	Core::Float);
		DECLARE_PDE_ATTRIBUTE_RW	(UseColFontCol,		Core::ARGB);

		DECLARE_PDE_ATTRIBUTE_RW	(ItemSkin,			tempc_ptr(ListItemSkin));
		DECLARE_PDE_ATTRIBUTE_RW	(HeaderSkin,		tempc_ptr(HeaderSkin));
		DECLARE_PDE_ATTRIBUTE_RW	(HeaderClickable,	bool);
		DECLARE_PDE_ATTRIBUTE_RW	(HeaderMovable,		bool);
		DECLARE_PDE_ATTRIBUTE_RW	(HeaderSizeable,	bool);
		DECLARE_PDE_ATTRIBUTE_RW	(HeaderHeight,		F32);
		DECLARE_PDE_ATTRIBUTE_RW	(ItemHeight,		F32);
		DECLARE_PDE_ATTRIBUTE_W		(HeadFontSize,		Core::Float);
		DECLARE_PDE_ATTRIBUTE_W		(HeadFontColor,		Core::ARGB);
		

		DECLARE_PDE_ATTRIBUTE_R		(MouseSelectedItem,	sharedc_ptr(ListItem));
		DECLARE_PDE_ATTRIBUTE_R		(ItemCount,			U32);
		DECLARE_PDE_ATTRIBUTE_R		(DisplayCount,		U32);
		DECLARE_PDE_ATTRIBUTE_R		(Columns,			sharedc_ptr(Header));
		DECLARE_PDE_ATTRIBUTE_R		(RootItem,			sharedc_ptr(ListItem));
		DECLARE_PDE_ATTRIBUTE_R		(DropTargetItem,	sharedc_ptr(ListItem)) { return m_DropTargetItem; };

		DECLARE_PDE_ATTRIBUTE_R		(SortColumnID,		S32);
		DECLARE_PDE_ATTRIBUTE_R		(SortReverse,		bool);
		
		SIMPLE_PDE_ATTRIBUTE_RW		(AlwaysSelect,		bool);
		SIMPLE_PDE_ATTRIBUTE_RW		(CanEditColumn,		bool);
		SIMPLE_PDE_ATTRIBUTE_RW		(CanKeySelect,		bool);

		SIMPLE_PDE_ATTRIBUTE_RW		(FindEnable,		bool);
		SIMPLE_PDE_ATTRIBUTE_RW		(FindByRegular,		bool);

		SIMPLE_PDE_ATTRIBUTE_RW		(ShowNodeToolTip,	bool);

		DECLARE_PDE_ATTRIBUTE_RW	(DrawItemBgWhenEmpty,	bool);

		DECLARE_PDE_ATTRIBUTE_RW	(ItemGap,			F32);
		DECLARE_PDE_ATTRIBUTE_R		(PopupMenu,			sharedc_ptr(Menu));
		DECLARE_PDE_ATTRIBUTE_RW	(VScrollOffset,			F32);
	public:
		virtual void OnCreate();

		virtual void OnDestroy();

		/// on frame update
		virtual void OnFrameUpdate(EventArgs & e);

		virtual void OnLayout(EventArgs & e);
#if 0
		virtual void OnPaintClient(PaintEventArgs & e);		
#endif

		virtual void OnPaint(PaintEventArgs & e);

		virtual void OnInputEvent(InputEventArgs & e);

		bool IsOnGap(Core::Vector2 localPos);

		/// on key event
		virtual void OnKeyEvent(InputEventArgs & e);

		/// on drag enter
		virtual void OnDragEnter(DragEventArgs & e);

		/// on drag over
		virtual void OnDragOver(DragEventArgs & e);

		/// on drag leave
		virtual void OnDragLeave(DragEventArgs & e);

		/// on drag drop
		virtual void OnDragDrop(DragEventArgs & e);

		/// on enter
		virtual void OnEnter(EventArgs & e);

		/// on leave
		virtual void OnLeave(EventArgs & e);

		/// on active changed event
		virtual void OnActiveChanged(EventArgs & e);

		/// on select item changed
		virtual void OnSelectItemChanged(ListItemEventArgs & e);

		/// on item delete event
		virtual void OnDelete(EventArgs & e);

		/// on item change event
		virtual void OnItemChange(EventArgs & e);

		/// on double click header split event
		virtual void OnSplitDoubleClick(HeaderEventArgs & e);

		/// on draw item event
		virtual void OnDrawItem(DrawItemEventArgs & e);

		virtual void OnDrawItemText(DrawItemEventArgs & e);

		/// on draw item backgroud event
		virtual void OnDrawItemBackgroud(DrawItemEventArgs & e);

		/// on double click item event
		virtual void OnDoubleClick(ListItemEventArgs & e);

		/// on item expand event
		virtual void OnExpand(ListItemEventArgs & e);

		/// column edit
		virtual void ColumnEdit(tempc_ptr(ListItem) hItem, U32 column);

		/// on mouse leave
		virtual void OnMouseLeave(EventArgs & e);

		/// on node mouse enter
		virtual void OnNodeMouseEnter(ListItemInputEventArgs & e);

		/// on node mouse move
		virtual void OnNodeMouseMove(ListItemInputEventArgs & e);

		/// on node mouse leave
		virtual void OnNodeMouseLeave(ListItemInputEventArgs & e);

		/// on node column mouse enter
		virtual void OnNodeColumnMouseEnter(ListItemInputEventArgs & e);

		static tempc_ptr(SortFunc) GetDefaultStrCompareFunc() { return m_DefaultStrCompare; }

	private:
		/// on column edit textbox value enter
		void TextBox_ValueEnter(tempc_ptr(Core::Object) sender, EventArgs & e);

		/// on column edit textbox focus changed
		void TextBox_OnFocusChanged(tempc_ptr(Core::Object) sender, EventArgs & e);

		/// on column edit textbox on value enter
		void TextBox_OnValueEnter(tempc_ptr(Core::Object) sender, EventArgs & e);

		/// findbox focus on changed
		void FindBox_OnFocusChanged(tempc_ptr(Core::Object) sender, EventArgs & e);

		/// findbox on value enter
		void FindBox_OnValueEnter(tempc_ptr(Core::Object) sender, EventArgs & e);

		/// findbox on key up
		void FindBox_OnKeyUp(tempc_ptr(Core::Object) sender, InputEventArgs & e);

		/// findbox on release
		void FindBox_Release(tempc_ptr(Core::Object) sender);

		/// findbox on text changed
		void FindBox_OnTextChanged(tempc_ptr(Core::Object) sender, EventArgs & e);

		void Header_OnItemChange(tempc_ptr(Core::Object) sender, EventArgs & e);

		void Header_OnSplitDoubleClick(tempc_ptr(Core::Object) sender, HeaderEventArgs & e);

		void Header_OnMouseEnter(tempc_ptr(Core::Object) sender, EventArgs & e);

	protected:
		virtual void ToggleExpand(tempc_ptr(ListItem) item);

		bool IsSelect(tempc_ptr(ListItem) item);

		bool IsExpand(tempc_ptr(ListItem) item);

		void ExpandCheck(tempc_ptr(ListItem) item);

		void ChangeSelectItem(tempc_ptr(ListItem) item);


		void DisplayNodeDashed(tempc_ptr(Client::UIRender) render, tempc_ptr(ListItem) item, U32 index);

		F32 GetAllWidth();

		F32 GetDisplayWidth(U32 column);

		/// change selected item to index
		bool ChangeSelectedToIndex(U32 index, bool shiftKeyDown = false, bool ctrlKeyDown = false);

		/// create find textBox
		bool CreateFindBox();

	public:
		/// Create item
		virtual sharedc_ptr(ListItem) CreateItem();

		/// Checks if a item can expand.
		virtual bool CanExpand(tempc_ptr(ListItem) item);

		/// Adds a new item.
		virtual sharedc_ptr(ListItem) AddItem(tempc_ptr(ListItem) parent, const Core::String & value);

		/// Adds a existing item.
		void AddExistingItem(tempc_ptr(ListItem) parent, tempc_ptr(ListItem) value);

		/// Adds subitem.
		void AddSubItem(tempc_ptr(ListItem) item, const Core::String & value);

		/// adds a column.
		void AddColumn(const Core::String & string, F32 width = 60, Client::Unit::Align columnAlign = Client::Unit::kAlignLeftMiddle);

		/// adds a column.
		void AddFilterColumn(const Core::String & string, F32 width = 60, Client::Unit::Align columnAlign = Client::Unit::kAlignLeftMiddle);

		/// delete an item
		void DeleteNode(tempc_ptr(ListItem) item);

		/// delete all items.
		void DeleteAll(bool mute = false);

		/// delete all columns
		void DeleteColumns();

		/// delete all
		void Ready();

		/// before select
		void BeforeSelect(tempc_ptr(ListItem) item);

		/// after select
		void AfterSelect(tempc_ptr(ListItem) item);

		/// clear selection
		void ClearSelection();

		/// before expand
		void BeforeExpand(tempc_ptr(ListItem) item);

		/// after expand
		void AfterExpand(tempc_ptr(ListItem) item);

		/// get item text
		Core::String GetItemText(tempc_ptr(ListItem) item, U32 column);

		/// set item text
		void SetItemText(tempc_ptr(ListItem) item, U32 column, const Core::String & text);

		/// has item
		bool HasItem(tempc_ptr(ListItem) item);

		/// auto set column size
		void AutoColumnSize(U32 column);

		/// Set all items visible
		void SetAllItemsVisible(bool bVisible);

		/// filter
		void Filter(tempc_ptr(ListItem) first, const FilterCompare & compareFunc, const Core::String& str);

		/// filter column
		void FilterColumn(S32 column, const Core::String& str);

		/// sort
		void Sort(tempc_ptr(ListItem) first, S32 column, bool reverse, bool sortChilds, by_ptr(SortFunc) func=NullPtr);

		/// sort column
		void SortColumn(S32 column, bool sortChilds, by_ptr(SortFunc) func=NullPtr);

		/// sort column extension, auto handle reverse
		void SortColumnExt(S32 column, bool sortChilds, by_ptr(SortFunc) func=NullPtr);

		/// client position to item
		sharedc_ptr(ListItem) GetItemAt(const Core::Vector2 & position);

		/// scroll to item
		void ScrollToItem(U32 index);

		/// find item by name
		void SelectItemByColumnName(const Core::String & name, U32 column = 0, bool skipSelf = true);

		/// text match with name
		bool NameMatchWithText(const Core::String & name, const Core::String & text);

		/// point to node
		sharedc_ptr(ListItem) PointToNode(const Core::Vector2 & pos);

		/// DisplayIndex to item.
		sharedc_ptr(ListItem) DisplayIndexToItem(U32 displayIndex);

		/// Item to DisplayIndex.
		U32 ItemToDisplayIndex(tempc_ptr(ListItem) item);

	protected:
		sharedc_ptr(ListItem)		m_SelectedItem;
		S32							m_CheckIndex;
		U32							m_LastIndex;
		U32							m_SelectingIndex;
		bool						m_MultiSelect		: 1;
		bool						m_Selecting			: 1;
		bool						m_TreeVisible		: 1;
		bool						m_HeaderVisible		: 1;
		bool						m_GridLines			: 1;
		bool						m_ShowLines			: 1;
		bool						m_AutoColumnSize	: 1;
		bool						m_SelectedByMouse	: 1;
		bool						m_BeforeDrag		: 1;
		bool						m_UseFistColumn;

		Core::Rectangle				m_SelectRect;
		sharedc_ptr(Header)			m_Header;
		sharedc_ptr(ListItemRoot)	m_RootItem;

		sharedc_ptr(ListItem)		m_DropTargetItem;
		sharedc_ptr(ListItem)		m_DragItem;
		U32							m_ItemDragEffert;

		sharedc_ptr(ListItem)				m_EditItem;
		U32							m_EditColumn;

		//HotkeyManager			m_Hotkey;

		sharedc_ptr(ListItem)		m_SelectingItem;

		sharedc_ptr(Textbox)			m_FindBox;

		sharedc_ptr(ListItem)		m_PointedItem;

		F64							m_Timer;

		sharedc_ptr(ListItemSkin)	m_ItemSkin;
		sharedc_ptr(ListItem)       m_MouseSelectedItem;
		F32							m_ItemGap;

		bool						m_DrawItemBgWhenEmpty;
		sharedc_ptr(Menu)			m_PopupMenu;

		F32							m_ItemHeight;

		static sharedc_ptr(IDefaultStrCompareFunc)	m_DefaultStrCompare;
		Core::Float					m_HeadFontSize;
		Core::ARGB					m_HeadFontColor;
		Core::Float					m_UseColFontSize;
		Core::ARGB					m_UseColFontCol;
		F32							m_MY_SPLIT_WIDTH;
		F32							m_UseColumnNum;
		F32                         m_VScrollOffset;

		bool						m_ismouse_here;
		float						m_tooltipStartshow;
		bool						m_isCanShow;
	};
}