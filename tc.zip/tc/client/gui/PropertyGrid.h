namespace Gui
{
	/// base class of ui elements
	class PropertyGrid : public ListTreeView
	{
		DECLARE_PDE_OBJECT(PropertyGrid, ListTreeView)

	public:
		PropertyGrid();
		~PropertyGrid();

	public:
		DECLARE_PDE_EVENT(EventItemChange,		ListItemEventArgs);
		DECLARE_PDE_EVENT(EventPropertyChanged,	ValueChangeEventArgs);
		DECLARE_PDE_EVENT(EventDropDown,		ListItemEventArgs);
		DECLARE_PDE_EVENT(EventItemOwnDraw,		DrawItemEventArgs);

	public:
		DECLARE_PDE_ATTRIBUTE_R(GroupRoot,	by_ptr(PdePropertyItem));
		INLINE_PDE_ATTRIBUTE_RW(EditorTextboxStyle, const Core::String &);
		INLINE_PDE_ATTRIBUTE_RW(EditorComboBoxStyle, const Core::String &);
		INLINE_PDE_ATTRIBUTE_RW(EditorButtonStyle, const Core::String &);

	public:
		virtual void OnCreate();

		virtual void OnDestroy();

		virtual void OnLayout(EventArgs & e);

        /// on input event
        virtual void OnInputEvent(InputEventArgs & e);

		/// on mouse event
		virtual bool OnMouseEvent(InputEventArgs & input);

		/// on enter
		virtual void OnEnter(EventArgs & e);

		/// on leave
		virtual void OnLeave(EventArgs & e);

		/// on node column mouse enter
		virtual void OnNodeColumnMouseEnter(ListItemInputEventArgs & e);
		
		virtual void OnSelectItemChanged(ListItemEventArgs & e);

		virtual void OnItemChange(ListItemEventArgs & e);

		/// on property changed
		virtual void OnPropertyChanged(ValueChangeEventArgs & e);

		virtual void OnDrawItem(DrawItemEventArgs & e);

		virtual void OnDrawItemBackgroud(DrawItemEventArgs & e);

		virtual void OnItemOwnDraw(DrawItemEventArgs & e);

		virtual void OnDropDownClick(by_ptr(void) sender, Client::InputEventArgs & e);

		virtual void Editor_ValueEnter(by_ptr(void) sender, EventArgs & e);

		/// spin box value changed end
		virtual void SpinBox_ValueChangedEnd(by_ptr(void) sender, ValueChangeEventArgs & e);

		//virtual void ComboBox_DoubleClick(by_ptr(void) sender, EventArgs & e);

	private:
		virtual void ToggleExpand(by_ptr(ListItem) item);

		bool UpdateParent(by_ptr(PdePropertyItem) item);

		void CreateEditor(by_ptr(PdePropertyItem) item);

		bool CheckSplit(const Core::Vector2 & pos);

	public:
		virtual sharedc_ptr(ListItem) CreateItem();

		/// create item
		virtual sharedc_ptr(ListItem) CreateItem(by_ptr(Core::PdeTypeInfo) typeInfo/*const PdeTypeInfo * typeInfo*/);

		virtual bool CanExpand(by_ptr(ListItem) item);

		/// add item
		sharedc_ptr(PdePropertyItem) AddItem(by_ptr(ListItem) parent, const Core::String & name, 
			by_ptr(void) value, 
			bool canExpand = false, bool readonly = false);

		/// add item with typeinfo
		sharedc_ptr(PdePropertyItem) AddItemWithType(by_ptr(ListItem) parent, const Core::String & name, 
			by_ptr(void) value,
			by_ptr(Core::PdeTypeInfo) typeInfo = NullPtr,
			bool canExpand = false, bool readonly = false);

		void ValueEnter(const Core::String & value);

		void DeleteChild(by_ptr(ListItem) item);

	protected:
		bool							m_Splitting		: 1;

		sharedc_ptr(PdePropertyItem)				m_SelectProperty;
		sharedc_ptr(PdePropertyItem)				m_GroupRoot;
		sharedc_ptr(Control)					m_Editor;
		sharedc_ptr(Button)					m_DropDownBtn;
		F32								m_SplitterPos;
		F32								m_SplitRate;

		sharedc_ptr(void)				m_OldValue;
		bool							m_OldValueSaved;

		Core::String					m_EditorTextboxStyle;
		Core::String					m_EditorComboBoxStyle;
		Core::String					m_EditorButtonStyle;
	};
}