namespace Gui
{
	class NoticeBoardSkin: public ControlSkin
	{
	public:
		INLINE_PDE_ATTRIBUTE_RW(ArrowDownImage, tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(ArrowUpImage, tempc_ptr(Image));
	private:
		sharedc_ptr(Image)	m_ArrowDownImage;
		sharedc_ptr(Image)	m_ArrowUpImage;
	};

	/// base class of ui elements
	class  NoticeBoard : public Balloon
	{
		DECLARE_PDE_OBJECT(NoticeBoard, Balloon)

	public:
		///constructor
		NoticeBoard();

		///destructor
		~NoticeBoard();

		/// on frame update
		virtual void OnFrameUpdate(EventArgs & e);
		/// on paint
		virtual void OnPaint(PaintEventArgs & e);

		virtual void UpdateLocation(const Core::Rectangle& globalBaseRect, bool bOnTop = true);

		void IncreaseAlpha();

		void DecreaseAlpha();

	protected:
		F32						m_Alpha;
	};
}