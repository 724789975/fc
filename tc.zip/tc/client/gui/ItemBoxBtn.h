namespace Gui
{
	class ItemBoxBtnSkin: public ControlSkin
	{
	public:
		INLINE_PDE_ATTRIBUTE_RW(NeutralNormalImage, tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(NeutralHoverImage, tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(NeutralSelectedImage, tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(NeutralDisabledImage, tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(NeutralHighlightImage, tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(NeutralImage, tempc_ptr(Image));

		INLINE_PDE_ATTRIBUTE_RW(RedNormalImage, tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(RedHoverImage, tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(RedSelectedImage, tempc_ptr(Image));

		INLINE_PDE_ATTRIBUTE_RW(BlueNormalImage, tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(BlueHoverImage, tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(BlueSelectedImage, tempc_ptr(Image));

		INLINE_PDE_ATTRIBUTE_RW(LockedImage, tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(PackAImage, tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(PackBImage, tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(PackCImage, tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(PackDImage, tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(PackEImage, tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(RepairImage, tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(EmptyImage, tempc_ptr(Image));

		INLINE_PDE_ATTRIBUTE_RW(NotSuitImage, tempc_ptr(Image));

		INLINE_PDE_ATTRIBUTE_RW(TuneNoImage, tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(TuneYesImage, tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(TunedImage, tempc_ptr(Image));

		INLINE_PDE_ATTRIBUTE_RW(UsingNoImage, tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(UsingYesImage, tempc_ptr(Image));

		INLINE_PDE_ATTRIBUTE_RW(SlotWeaponFirst, tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(SlotWeaponSecond, tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(SlotWeaponGrenade, tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(SlotWeaponFlash, tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(SlotWeaponSmoke, tempc_ptr(Image));

		INLINE_PDE_ATTRIBUTE_RW(SlotCharacterArmet, tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(SlotCharacterMask, tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(SlotCharacterClothes, tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(SlotCharacterGloves, tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(SlotCharacterTrou, tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(SlotCharacterShoes, tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(SlotCharacterBadge, tempc_ptr(Image));

		SIMPLE_PDE_ATTRIBUTE_RW(NameNormalColor, Core::ARGB);
		SIMPLE_PDE_ATTRIBUTE_RW(NameHighlightColor, Core::ARGB);
		SIMPLE_PDE_ATTRIBUTE_RW(LeftHighlightColor, Core::ARGB);

	private:		
		sharedc_ptr(Image) m_NeutralNormalImage;
		sharedc_ptr(Image) m_NeutralHoverImage;
		sharedc_ptr(Image) m_NeutralSelectedImage;
		sharedc_ptr(Image) m_NeutralDisabledImage;
		sharedc_ptr(Image) m_NeutralHighlightImage;
		sharedc_ptr(Image) m_NeutralImage;

		sharedc_ptr(Image) m_RedNormalImage;
		sharedc_ptr(Image) m_RedHoverImage;
		sharedc_ptr(Image) m_RedSelectedImage;

		sharedc_ptr(Image) m_BlueNormalImage;
		sharedc_ptr(Image) m_BlueHoverImage;
		sharedc_ptr(Image) m_BlueSelectedImage;

		sharedc_ptr(Image) m_LockedImage;
		sharedc_ptr(Image) m_PackAImage;
		sharedc_ptr(Image) m_PackBImage;
		sharedc_ptr(Image) m_PackCImage;
		sharedc_ptr(Image) m_PackDImage;
		sharedc_ptr(Image) m_PackEImage;
		sharedc_ptr(Image) m_RepairImage;
		sharedc_ptr(Image) m_EmptyImage;

		sharedc_ptr(Image) m_NotSuitImage;

		sharedc_ptr(Image) m_TuneNoImage;
		sharedc_ptr(Image) m_TuneYesImage;
		sharedc_ptr(Image) m_TunedImage;

		sharedc_ptr(Image) m_UsingNoImage;
		sharedc_ptr(Image) m_UsingYesImage;

		sharedc_ptr(Image) m_SlotWeaponFirst;
		sharedc_ptr(Image) m_SlotWeaponSecond;
		sharedc_ptr(Image) m_SlotWeaponGrenade;
		sharedc_ptr(Image) m_SlotWeaponFlash;
		sharedc_ptr(Image) m_SlotWeaponSmoke;

		sharedc_ptr(Image) m_SlotCharacterArmet;
		sharedc_ptr(Image) m_SlotCharacterMask;
		sharedc_ptr(Image) m_SlotCharacterClothes;
		sharedc_ptr(Image) m_SlotCharacterGloves;
		sharedc_ptr(Image) m_SlotCharacterTrou;
		sharedc_ptr(Image) m_SlotCharacterShoes;
		sharedc_ptr(Image) m_SlotCharacterBadge;
	};
}

namespace Gui
{
	class ItemBoxBtn: public Control
	{
		DECLARE_PDE_OBJECT(ItemBoxBtn, Control)
	public:
		DECLARE_PDE_EVENT(EventMouseEnter, Client::InputEventArgs);
		DECLARE_PDE_EVENT(EventMouseLeave, Client::InputEventArgs);
		DECLARE_PDE_EVENT(EventMouseDown, Client::InputEventArgs);
		DECLARE_PDE_EVENT(EventMouseRightDown, Client::InputEventArgs);
		DECLARE_PDE_EVENT(EventMouseUp, Client::InputEventArgs);
		DECLARE_PDE_EVENT(EventToolTipsShow, Core::EventArgs);
		DECLARE_PDE_EVENT(EventSelected, Core::ValueChangeEventArgs);
		DECLARE_PDE_EVENT(EventCancel, Core::ValueChangeEventArgs);
		DECLARE_PDE_EVENT(EventDoubleClick, Client::InputEventArgs);

		DECLARE_PDE_ATTRIBUTE_RW(Selected, bool);
		DECLARE_PDE_ATTRIBUTE_RW(Empty, bool);
		INLINE_PDE_ATTRIBUTE_RW(CanCancel, bool);
		DECLARE_PDE_ATTRIBUTE_RW(CanSelect, bool);
		DECLARE_PDE_ATTRIBUTE_RW(Highlight, bool);
		DECLARE_PDE_ATTRIBUTE_RW(Enough, bool);
		DECLARE_PDE_ATTRIBUTE_RW(Hovered, bool);
		
		DECLARE_PDE_ATTRIBUTE_RW(Loading, bool);
		DECLARE_PDE_ATTRIBUTE_RW(Locked, bool);

		DECLARE_PDE_ATTRIBUTE_RW(ID, int);

		DECLARE_PDE_ATTRIBUTE_RW(ItemName, Core::String);

		DECLARE_PDE_ATTRIBUTE_RW(Cost, int);
		DECLARE_PDE_ATTRIBUTE_RW(CostType, int);
		DECLARE_PDE_ATTRIBUTE_RW(Period, int);

		DECLARE_PDE_ATTRIBUTE_RW(Suit, bool);
		DECLARE_PDE_ATTRIBUTE_RW(ItemIcon, tempc_ptr(Icon));
		INLINE_PDE_ATTRIBUTE_RW(LoadingImage, tempc_ptr(AnimatedImage));

		DECLARE_PDE_ATTRIBUTE_RW(ItemIconNew, tempc_ptr(Icon));
		DECLARE_PDE_ATTRIBUTE_RW(ItemLevel, tempc_ptr(Icon));
		DECLARE_PDE_ATTRIBUTE_RW(ItemIconVIP, tempc_ptr(Icon));
		DECLARE_PDE_ATTRIBUTE_RW(ItemIconPastDue, tempc_ptr(Icon));

		//new add
		DECLARE_PDE_ATTRIBUTE_RW(PID, int);
		DECLARE_PDE_ATTRIBUTE_RW(SID, int);
		DECLARE_PDE_ATTRIBUTE_RW(Where, int);

		DECLARE_PDE_ATTRIBUTE_RW(Type, int);
		DECLARE_PDE_ATTRIBUTE_RW(SubType, int);
		DECLARE_PDE_ATTRIBUTE_RW(BagSP1, int);

		DECLARE_PDE_ATTRIBUTE_RW(Side, int);

		DECLARE_PDE_ATTRIBUTE_RW(UnitType, int);
		DECLARE_PDE_ATTRIBUTE_RW(TimeLeftType, int);
		DECLARE_PDE_ATTRIBUTE_RW(TimeLeft, int);
		DECLARE_PDE_ATTRIBUTE_RW(Quantity, int);
		DECLARE_PDE_ATTRIBUTE_RW(Durable, int);

		DECLARE_PDE_ATTRIBUTE_RW(InPack, int);
		DECLARE_PDE_ATTRIBUTE_RW(ModState, int);
		DECLARE_PDE_ATTRIBUTE_RW(UseState, int);

		DECLARE_PDE_ATTRIBUTE_RW(LastSelected,		bool);

		//button
		INLINE_PDE_ATTRIBUTE_RW (ItemBtn, tempc_ptr(Gui::Button));
		DECLARE_PDE_ATTRIBUTE_RW(BtnText, Core::String);
		DECLARE_PDE_ATTRIBUTE_RW(BtnSize, Core::Vector2);
		DECLARE_PDE_ATTRIBUTE_RW(BtnLocation, Core::Vector2);
		DECLARE_PDE_ATTRIBUTE_RW(BtnVisible, bool);
		DECLARE_PDE_ATTRIBUTE_RW(ItemBtnSkin, tempc_ptr(Gui::ButtonSkin));

		DECLARE_PDE_EVENT(EventBtnClick, Client::InputEventArgs);

		//ItemIcon
		DECLARE_PDE_ATTRIBUTE_RW(IconDisplayType, Icon::IconTextDisplay);

		//ComboBox
		INLINE_PDE_ATTRIBUTE_RW(ItemCombo,tempc_ptr(Gui::ComboBox));
		DECLARE_PDE_ATTRIBUTE_RW(ComboText,Core::String);
		DECLARE_PDE_ATTRIBUTE_RW(ComboSize,Core::Vector2);
		DECLARE_PDE_ATTRIBUTE_RW(ComboLocation,Core::Vector2);
		DECLARE_PDE_ATTRIBUTE_RW(ComboVisible,bool);
		DECLARE_PDE_ATTRIBUTE_RW(ItemComboSkin, tempc_ptr(Gui::ComboBoxSkin));
		DECLARE_PDE_ATTRIBUTE_RW(ItemComboListStyle, Core::String);

		DECLARE_PDE_EVENT(EventComboSelect,Client::InputEventArgs);

		//progress bar
		INLINE_PDE_ATTRIBUTE_RW(ItemPBBase,tempc_ptr(Gui::Control));
		INLINE_PDE_ATTRIBUTE_RW(ItemPBTop,tempc_ptr(Gui::Control));
		DECLARE_PDE_ATTRIBUTE_RW(PBBaseSize,Core::Vector2);
		DECLARE_PDE_ATTRIBUTE_RW(PBTopSize,Core::Vector2);
		DECLARE_PDE_ATTRIBUTE_RW(PBBaseLocation,Core::Vector2);
		DECLARE_PDE_ATTRIBUTE_RW(PBTopLocation,Core::Vector2);
		DECLARE_PDE_ATTRIBUTE_RW(PBBaseSkin,tempc_ptr(Gui::ControlSkin));
		DECLARE_PDE_ATTRIBUTE_RW(PBTopSkin,tempc_ptr(Gui::ControlSkin));
		DECLARE_PDE_ATTRIBUTE_RW(PBTOPBGColor, Core::ARGB);
		DECLARE_PDE_ATTRIBUTE_RW(PBVisible, bool);

		DECLARE_PDE_ATTRIBUTE_RW(GoodsID, int);

		DECLARE_PDE_ATTRIBUTE_R(ClientLocation,	Core::Vector2);
	public:
		ItemBoxBtn();
		~ItemBoxBtn();

		void OnCreate();
		void OnDestroy();

		void Clear();

		void Invalid();

		// on frame update
		virtual void OnFrameUpdate(EventArgs & e);

		virtual void OnInputEvent(Client::InputEventArgs & e);
		virtual void OnPaint(PaintEventArgs & e);
		virtual void OnMouseEnter(Client::InputEventArgs & e);
		virtual void OnMouseLeave(Client::InputEventArgs & e);
		virtual void OnMouseDown(Client::InputEventArgs & e);
		virtual void OnMouseUp(Client::InputEventArgs & e);
		virtual void OnDoubleClick(Client::InputEventArgs & e);
		virtual int CalculateStringWidth(Core::String str);

		void SetTimer(long t,long now, float alltime = 28800);
		void IsShowTimer(bool show = false);
	public:
	private:
		void OnComboBoxItemSelected(by_ptr(void) sender,EventArgs & e);
		void _OnBtnClick(by_ptr(void) sender, InputEventArgs & e);
	private:
		bool					m_Lock;//lock state
		bool                    m_Highlight;
		bool					m_Enough;
		bool					m_Selected;
		bool					m_Hovered;
		bool					m_IsEmpty;
		bool					m_IsLoading;
		bool					m_CanCancel;
		bool					m_CanSelect;
		Core::ARGB				m_SelectColor;
		Core::ARGB				m_HoverColor;
		Core::ARGB				m_NormalColor;
		Core::ARGB				m_DisableColor;

		int						m_ID;	//������������
		int						m_PID;	//new add ��ƷID
		int						m_SID;	//new add SYSTEM ID

		int						m_Type;
		int						m_SubType;
		int						m_BagSP1;	//Only in bag when empty, 1: weapon 2: character


		Core::String			m_ItemName;
		int						m_ModState;		//0(���ɸ�װ),1(�ɸ�װδ��װ),2(�Ѹ�װ)
		int						m_UseState;		//0(not Used), >0(using)

		int						m_UnitType;		// 1 Permanent, 2 Damage Based, 3 Unit Based, 4 Time Based
		int						m_TimeLeftType;	// hour/day/month
		int						m_TimeLeft;		// time left
		int						m_Quantity;
		int						m_Durable;		// health value

		int						m_CostType;		//CR or GP
		int						m_Cost;			//cost
		int						m_Period;		//Period


		int						m_InPack;		//equip info, in which pack


		bool					m_Suit:1;		//suit current gender/weapon or not
		bool					m_LastSelected:1;
		int						m_Side;			//character costume side
		int						m_Where;		// -1: bag 1:wc 2:cc 3:shop 4:depot 5:room 6:other bag

		sharedc_ptr(Icon)		m_ItemIcon;
		sharedc_ptr(AnimatedImage) m_LoadingImage;
		bool					m_StartLoading;

		sharedc_ptr(Icon)		m_ItemIconNew;
		sharedc_ptr(Icon)		m_ItemIcon_PastDue;
		sharedc_ptr(Icon)		m_ItemIconVIP;
		sharedc_ptr(Icon)		m_ItemLevel;

		Core::Vector2			m_ClientLocation;

		//button
		sharedc_ptr(Gui::Button)      m_ItemBtn;
		Core::Vector2                m_BtnSize;
		Core::Vector2                m_BtnLocation;
		Core::String			     m_BtnText;
		bool					     m_BtnVisible;
		sharedc_ptr(Gui::ButtonSkin)  m_ItemBtnSkin;

		//ItemIcon
		Icon::IconTextDisplay              m_IconDisplayType;
		
		//ComboBox
		sharedc_ptr(Gui::ComboBox) m_ItemCombo;
		Core::Vector2			  m_ComboSize;
		Core::Vector2			  m_ComboLocation;
		Core::String			  m_ComboText;
		bool					  m_ComboVisible;
		sharedc_ptr(Gui::ComboBoxSkin)  m_ItemComboSkin;
		Core::String                   m_ItemComboListStyle;

		//progress bar
		sharedc_ptr(Gui::Control)  m_ItemPBBase;
		sharedc_ptr(Gui::Control)  m_ItemPBTop;
		Core::Vector2			  m_PBBaseSize;
		Core::Vector2			  m_PBTopSize;
		Core::Vector2			  m_PBBaseLocation;
		Core::Vector2			  m_PBTopLocation;
		sharedc_ptr(Gui::ControlSkin)     m_PBBaseSkin;			
		sharedc_ptr(Gui::ControlSkin)     m_PBTopSkin;
		Core::ARGB                m_PBTOPBGColor;
		bool					  m_PBVisible;

		int                       m_GoodsID;
		bool					  m_ismouse_here;
		float					  m_tooltipStartshow;
		bool					  m_ShowTimer;
		float					  m_HaveTime;
		float					  m_UseTime;
	};
}
