#include "pch.h"

using namespace Core;
using namespace Client;
using namespace Gui;

//--------------------------------------------------------------------------------------
// type info
//--------------------------------------------------------------------------------------
DEFINE_PDE_TYPE_CLASS(CharacterPlate)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Button);
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_PROPERTY_RW(ID);
		ADD_PDE_PROPERTY_RW(Count);

		ADD_PDE_METHOD(Decrease);
		ADD_PDE_METHOD(Increase);
	}
};

DEFINE_PDE_TYPE_CLASS(CharacterSlot)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Button);
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_PROPERTY_RW(CurrentCharacter);

		ADD_PDE_METHOD(Clear);
		ADD_PDE_METHOD(Reset);
	}
};

REGISTER_PDE_TYPE(CharacterPlate);
REGISTER_PDE_TYPE(CharacterSlot);

namespace Gui
{
	CharacterPlate::CharacterPlate()
		: m_ID(0)
		, m_Count(0)
	{
		SetEnable(false);
	}

	CharacterPlate::~CharacterPlate()
	{

	}

	PDE_ATTRIBUTE_GETTER(CharacterPlate, ID, U32)
	{
		return m_ID;
	}

	PDE_ATTRIBUTE_SETTER(CharacterPlate, ID, U32)
	{
		if(m_ID!=value)
		{
			if(value>0 && value<27)
			{
				m_ID = value;
				m_IconActive = ptr_new Icon(Core::String::Format("ItemIcons/spellcharacters/skinD_spelling_%c.tga", 'A'-1+m_ID), Vector4(0,0,0,0));
				m_IconGray = ptr_new Icon(Core::String::Format("ItemIcons/spellcharacters/skinD_spelling_%c01.tga", 'A'-1+m_ID), Vector4(0,0,0,0));
				
				if(gGame && gGame->guiSys)
				{
					if(gGame->guiSys->m_CharPlatesPool.Contains(value))
					{
						gGame->guiSys->m_CharPlatesPool.Set(value, ptr_static_cast<CharacterPlate>(this));
					}
					else
					{
						gGame->guiSys->m_CharPlatesPool.Add(value, ptr_static_cast<CharacterPlate>(this));
					}
				}
			}
			else
			{
				m_ID = 0;
				m_IconActive = NullPtr;
				m_IconGray = NullPtr;
				U32 found = 0;
				if(gGame && gGame->guiSys)
				{
					HashSet<U32, sharedc_ptr(CharacterPlate)>::Enumerator it(gGame->guiSys->m_CharPlatesPool);
					while(it.MoveNext())
					{
						if(it.Value() == ptr_static_cast<CharacterPlate>(this))
						{
							found = it.Key();
							break;
						}
					}
					if(found)
					{
						gGame->guiSys->m_CharPlatesPool.Remove(found);
					}
				}
			}
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(CharacterPlate, Count, U32)
	{
		return m_Count;
	}

	PDE_ATTRIBUTE_SETTER(CharacterPlate, Count, U32)
	{
		if(m_Count!=value)
		{
			if(value>0)
			{
				m_Count = value;
				SetEnable(true);
			}
			else
			{
				m_Count = 0;
				SetEnable(false);
			}
			Invalid();
		}
	}

	void CharacterPlate::OnPaint( PaintEventArgs & e )
	{
		Super::OnPaint(e);
		Core::Rectangle iconRect = GetClientRect();
		iconRect.Shrink(Vector4(5,5,5,5));
		if(m_Count>0)
		{
			Skin::DrawImage(e.render, m_IconActive, iconRect);
		}
		else
		{
			Skin::DrawImage(e.render, m_IconGray, iconRect);
		}
		
		if(m_Count>0)
		{
			Core::Rectangle countRect = Core::Rectangle::RightBottom(m_Size.x-5,m_Size.y-5,14,14);
			e.render->DrawString(GetFont(), m_TextColor, ARGB(0,0,0,0), countRect, Core::String::Format("%d", m_Count)
				, Unit::kAlignRightBottom);
		}
	}

	void CharacterPlate::OnClick( Client::InputEventArgs & e )
	{
		if(m_Count>0)
		{
			if(gGame && gGame->guiSys)
			{
				tempc_ptr(CharacterSlot) slot = gGame->guiSys->GetActiveCharSlot();
				if(slot)
				{
					slot->SetCurrentCharacter(m_ID);
				}
			}
		}
	}

	void CharacterPlate::Decrease()
	{
		if(m_Count>0)
			m_Count--;
		Invalid();
	}

	void CharacterPlate::Increase()
	{
		m_Count++;
		Invalid();
	}
}

namespace Gui
{
	CharacterSlot::CharacterSlot()
		: m_CurrentCharacter(0)
		, m_OldCharacter(0)
		, m_TempCharacter(0)
		, m_OldTimer(-1.f)
		, m_NewTimer(-1.f)
	{

	}

	CharacterSlot::~CharacterSlot()
	{

	}

	PDE_ATTRIBUTE_GETTER(CharacterSlot, CurrentCharacter, U32)
	{
		return m_CurrentCharacter;
	}

	PDE_ATTRIBUTE_SETTER(CharacterSlot, CurrentCharacter, U32)
	{
		if(m_CurrentCharacter!=value)
		{
			gGame->guiSys->SetAllCharPlatesClickable(false);
			//Animate Old
			if(m_CurrentCharacter>0 && m_CurrentCharacter<27 && GetEnable())
			{
				m_OldCharacter = m_CurrentCharacter;
				m_OldTimer = m_CONTROL_HOVER_EFFECT_DURATION;
				m_AniCharOut->SetParent(gGame->guiSys);
				Vector2 zPoint = ClientToGlobalScreen(Vector2::kZero);
				m_AniCharOut->SetLocation(zPoint+Vector2(5,5));
				m_AniCharOut->SetIcon(ptr_new Icon(Core::String::Format("ItemIcons/spellcharacters/skinD_spelling_%c.tga", 'A'-1+m_OldCharacter), Vector4(0,0,0,0)));
			}

			m_CurrentCharacter = 0;
			m_Icon = NullPtr;

			//Animate new
			if(value>0 && value<27)
			{
				if(GetEnable())
				{
					m_TempCharacter = value;
					tempc_ptr(CharacterPlate) sourcePlate = GetCharacterPlate(value);
					if(sourcePlate && sourcePlate->GetCount()>0)
					{
						m_NewTimer = m_CONTROL_HOVER_EFFECT_DURATION;
						m_AniCharIn->SetParent(gGame->guiSys);
						Vector2 zPoint = sourcePlate->ClientToGlobalScreen(Vector2::kZero);
						m_AniCharIn->SetLocation(zPoint+Vector2(5,5));
						m_AniCharIn->SetIcon(ptr_new Icon(Core::String::Format("ItemIcons/spellcharacters/skinD_spelling_%c.tga", 'A'-1+value), Vector4(0,0,0,0)));

						sourcePlate->Decrease();
					}
					else
					{
						//InInPosition();

						//sourcePlate->Decrease();  //How to deal with this if the plate can not be found?
					}
				}
				else
				{
					m_TempCharacter = value;
					InInPosition();
				}
			}
			else
			{
				m_CurrentCharacter = 0;
				m_Icon = NullPtr;
			}
			Invalid();
		}
	}

	void CharacterSlot::OnCreate()
	{
		Super::OnCreate();
		SetCanPushDown(true);
		m_AniCharIn = ptr_new Label;
		m_AniCharIn->SetSize(Vector2(45,45));
		m_AniCharIn->SetBackgroundColor(ARGB(0,0,0,0));
		m_AniCharIn->SetTextPadding(Core::Vector4::kZero);

		m_AniCharOut = ptr_new Label;
		m_AniCharOut->SetSize(Vector2(45,45));
		m_AniCharOut->SetBackgroundColor(ARGB(0,0,0,0));
		m_AniCharOut->SetTextPadding(Core::Vector4::kZero);

// 		m_CONTROL_HOVER_EFFECT_DURATION = 1.f;
	}

	void CharacterSlot::OnFrameUpdate( EventArgs & e )
	{
		Super::OnFrameUpdate(e);
		//Out Ani
		if(m_OldTimer>=0.f)
		{
			F32 frameTime = Task::GetFrameTime();
			m_OldTimer-=frameTime;
			if(m_OldTimer<0.f)
			{
				Task::Post(NewGenericTask(&CharacterSlot::OutInPosition, ptr_static_cast<CharacterSlot>(this)));
			}
			else
			{
				Vector2 zPointStart = ClientToGlobalScreen(Vector2::kZero);
				zPointStart+=Vector2(5,5);
				tempc_ptr(CharacterPlate) targetPlate = GetCharacterPlate(m_OldCharacter);
				PDE_ASSERT(targetPlate, "targetPlate doesn't exist");
				Vector2 zPointEnd = targetPlate->ClientToGlobalScreen(Vector2::kZero);
				zPointEnd+=Vector2(5,5);
				Vector2 zPointLerp;
				Core::Lerp(zPointLerp, zPointEnd, zPointStart, m_OldTimer/m_CONTROL_HOVER_EFFECT_DURATION);
				m_AniCharOut->SetLocation(zPointLerp);
			}
		}

		//In Ani
		if(m_NewTimer>=0.f)
		{
			F32 frameTime = Task::GetFrameTime();
			m_NewTimer-=frameTime;
			if(m_NewTimer<0.f)
			{
				Task::Post(NewGenericTask(&CharacterSlot::InInPosition, ptr_static_cast<CharacterSlot>(this)));
			}
			else
			{
				Vector2 zPointEnd = ClientToGlobalScreen(Vector2::kZero);
				zPointEnd+=Vector2(5,5);
				tempc_ptr(CharacterPlate) sourcePlate = GetCharacterPlate(m_TempCharacter);
				PDE_ASSERT(sourcePlate, "sourcePlate doesn't exist");
				Vector2 zPointStart = sourcePlate->ClientToGlobalScreen(Vector2::kZero);
				zPointStart+=Vector2(5,5);
				Vector2 zPointLerp;
				Core::Lerp(zPointLerp, zPointEnd, zPointStart, m_NewTimer/m_CONTROL_HOVER_EFFECT_DURATION);
				m_AniCharIn->SetLocation(zPointLerp);
			}
		}
	}

	void CharacterSlot::OnPaint( PaintEventArgs & e )
	{
		if(e.Enable)
			Super::OnPaint(e);
		Core::Rectangle iconRect = GetClientRect();
		iconRect.Shrink(Vector4(5,5,5,5));
		Skin::DrawImage(e.render, m_Icon, iconRect);
	}

	void CharacterSlot::OnPushDownChanged()
	{
		if(gGame && gGame->guiSys)
		{
			gGame->guiSys->SetActiveCharSlot(ptr_static_cast<CharacterSlot>(this), m_PushDown);
		}
	}

	void CharacterSlot::Clear()
	{
		if(GetEnable())
			SetCurrentCharacter(0);
	}

	void CharacterSlot::Reset()
	{
		m_CurrentCharacter = 0;
		m_Icon = NullPtr;
		m_AniCharOut->SetParent(NullPtr);
		m_AniCharIn->SetParent(NullPtr);
		Invalid();
	}

	void CharacterSlot::OutInPosition()
	{
		m_AniCharOut->SetParent(NullPtr);
		m_AniCharOut->SetIcon(NullPtr);
		tempc_ptr(CharacterPlate) targetPlate = GetCharacterPlate(m_OldCharacter);
		targetPlate->Increase();
		m_OldCharacter = 0;
		Invalid();

		gGame->guiSys->SetAllCharPlatesClickable(true);
	}

	void CharacterSlot::InInPosition()
	{
		m_AniCharIn->SetParent(NullPtr);
		m_AniCharIn->SetIcon(NullPtr);
		m_CurrentCharacter = m_TempCharacter;
		m_Icon = ptr_new Icon(Core::String::Format("ItemIcons/spellcharacters/skinD_spelling_%c.tga", 'A'-1+m_TempCharacter), Vector4(0,0,0,0));
		m_TempCharacter = 0;
		Invalid();

		gGame->guiSys->SetAllCharPlatesClickable(true);
	}

	tempc_ptr(CharacterPlate) CharacterSlot::GetCharacterPlate( U32 id )
	{
		if(gGame && gGame->guiSys)
		{
			sharedc_ptr(CharacterPlate)* pPtr = gGame->guiSys->m_CharPlatesPool.Get(id);
			return pPtr?(*pPtr):NullPtr;
		}
		else
		{
			return NullPtr;
		}
	}
}

