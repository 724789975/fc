#include "pch.h"

using namespace Core;
using namespace Gui;
using namespace Client;

DEFINE_PDE_TYPE_CLASS(Gui::PropertyView)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::Control);
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_PROPERTY_RW(SelectedObject);
		ADD_PDE_PROPERTY_RW(ShowGroup);
		ADD_PDE_PROPERTY_R (PropertyGrid);
		ADD_PDE_PROPERTY_RW(ItemSkin);
		ADD_PDE_PROPERTY_RW(EditorTextboxStyle);
		ADD_PDE_PROPERTY_RW(EditorComboBoxStyle);
		ADD_PDE_PROPERTY_RW(EditorButtonStyle);

		ADD_PDE_METHOD(Refresh);
		ADD_PDE_EVENT(EventNavigate);
		ADD_PDE_EVENT(EventResourceChange);
	}
};
REGISTER_PDE_TYPE(Gui::PropertyView);

namespace Gui
{
	PropertyView::PropertyView()
		: m_TimeFlag(0)
		, m_ShowGroup(false)
		, m_Refresh(false)
	{
	}


	PropertyView::~PropertyView()
	{
	}
}

//--------------------------------------------------------------------------------------
// attributes
//--------------------------------------------------------------------------------------
namespace Gui
{
	PDE_ATTRIBUTE_GETTER(PropertyView, SelectedObject, sharedc_ptr(void))
	{
		return m_SelectedObject;
	}

	PDE_ATTRIBUTE_SETTER(PropertyView, SelectedObject, sharedc_ptr(void))
	{
		if (m_SelectedObject != value)
		{
			m_SelectedObject = value;
			Refresh();
		}
	}

	PDE_ATTRIBUTE_GETTER(PropertyView, ShowGroup, bool)
	{
		return m_ShowGroup;
	}

	PDE_ATTRIBUTE_SETTER(PropertyView, ShowGroup, bool)
	{
		if (m_ShowGroup != value)
		{
			m_ShowGroup = value;
			ShowGroup(m_ShowGroup);
		}
	}

	PDE_ATTRIBUTE_GETTER(PropertyView, Skin, tempc_ptr(Gui::ControlSkin))
	{
		if(m_Grid)
			return m_Grid->GetSkin();
		return NullPtr;
	}

	PDE_ATTRIBUTE_SETTER(PropertyView, Skin, tempc_ptr(Gui::ControlSkin))
	{
		if(m_Grid)
		{
			m_Grid->SetSkin(value);
		}
	}

	PDE_ATTRIBUTE_GETTER(PropertyView, ItemSkin, tempc_ptr(ListItemSkin))
	{
		if(m_Grid)
			return m_Grid->GetItemSkin();
		return NullPtr;
	}

	PDE_ATTRIBUTE_SETTER(PropertyView, ItemSkin, tempc_ptr(ListItemSkin))
	{
		if(m_Grid)
			m_Grid->SetItemSkin(value);
	}
	
	PDE_ATTRIBUTE_GETTER(PropertyView, EditorTextboxStyle, const Core::String&)
	{
		if(m_Grid)
			return m_Grid->GetEditorTextboxStyle();
		else
			return Core::String::kEmpty;
	}

	PDE_ATTRIBUTE_SETTER(PropertyView, EditorTextboxStyle, const Core::String&)
	{
		if(m_Grid)
			m_Grid->SetEditorTextboxStyle(value);
	}

	PDE_ATTRIBUTE_GETTER(PropertyView, EditorComboBoxStyle, const Core::String&)
	{
		if(m_Grid)
			return m_Grid->GetEditorComboBoxStyle();
		else
			return Core::String::kEmpty;
	}

	PDE_ATTRIBUTE_SETTER(PropertyView, EditorComboBoxStyle, const Core::String&)
	{
		if(m_Grid)
			m_Grid->SetEditorComboBoxStyle(value);
	}

	PDE_ATTRIBUTE_GETTER(PropertyView, EditorButtonStyle, const Core::String&)
	{
		if(m_Grid)
			return m_Grid->GetEditorButtonStyle();
		else
			return Core::String::kEmpty;
	}

	PDE_ATTRIBUTE_SETTER(PropertyView, EditorButtonStyle, const Core::String&)
	{
		if(m_Grid)
			m_Grid->SetEditorButtonStyle(value);
	}
}

//--------------------------------------------------------------------------------------
// event
//--------------------------------------------------------------------------------------
namespace Gui
{
	/// on create.
	void PropertyView::OnCreate()
	{
		Super::OnCreate();

		//m_Grid = CreateControl("EdtUIPropertyGrid");

		m_Grid = ptr_new PropertyGrid;

		m_Grid->SetParent(ptr_static_cast<Self>(this));

		m_Grid->SetMultiSelect(false);
		m_Grid->SetDock(Control::kDockFill);
		m_Grid->SetAutoScroll(true);
		m_Grid->SetShowLines(true);
		m_Grid->EventItemChange.Subscribe(NewDelegate(&Self::Grid_OnItemChange, ptr_static_cast<Self>(this)));
		m_Grid->EventDoubleClick.Subscribe(NewDelegate(&Self::Grid_OnDoubleClick, ptr_static_cast<Self>(this)));
		m_Grid->EventExpand.Subscribe(NewDelegate(&Self::Grid_OnExpand, ptr_static_cast<Self>(this)));
		m_Grid->EventSelectItemChange.Subscribe(NewDelegate(&Self::Grid_OnSelectItemChange, ptr_static_cast<Self>(this)));
	}

	void PropertyView::OnDestroy()
	{
		ClearGroup();

		Super::OnDestroy();
	}

	void PropertyView::OnFrameUpdate(EventArgs & e)
	{
		//SelectActiveControl();

        if (m_SelectedObject/*.IsValid()*/)
		{
			m_Refresh? Refresh(): UpdateProperties();
			m_Refresh = false;
		}
		else if (!m_Refresh)
		{
			InvalidProperties();

			m_Refresh = true;
		}


        Super::OnFrameUpdate(e);
	}

	void PropertyView::OnLayout(EventArgs & e)
	{
		Super::OnLayout(e);
	}

	void PropertyView::OnResourceChange(ListItemEventArgs & e)
	{
		EventResourceChange.Fire(ptr_static_cast<Self>(this)/*GetHandle()*/, e);
	}

	void PropertyView::Grid_OnItemChange(by_ptr(void) sender, ListItemEventArgs & e)
	{
		//HEdtUIPropertyItem item = handle_convert<HEdtUIPropertyItem>(e.Item);

		tempc_ptr(PdePropertyItem) item = ptr_static_cast<PdePropertyItem>(e.Item);

		if (item/*.IsValid()*/ && m_SelectedObject/*.IsValid()*/)
		{
			//PdeObject * obj = handle_cast<PdeObject>(m_SelectedObject);

			tempc_ptr(void) obj = ptr_static_cast<void>(m_SelectedObject);
			
			//PdeIdentifier name(item->GetText(0));

			Identifier name(item->GetText(0));
			
			//const PdeMemberInfo * member = obj->GetType()->GetMember(name);

			tempc_ptr(PdeTypeInfo) type = ptr_typeof(obj);

			sharedc_ptr(PdeMemberInfo) member = type->GetMember(name);

			//if (member->GetMemberType() == PdeMemberInfo::kProperty)
			if (member->GetMemberKind() == PdeMemberInfo::kProperty)
			{
				//const PdePropertyInfo * p = static_cast<const PdePropertyInfo *>(member);
				
				sharedc_ptr(PdePropertyInfo) p = ptr_static_cast<PdePropertyInfo>(member);

				if (p && p->CanWrite())
				{
					//PdeClassPtr value;

					sharedc_ptr(void) value;

					value = item->GetValue();

					p->SetValue(obj, value);
					p->GetValue(obj, value);
					item->SetValue(value);
				}
			}
		}
	}   

	void PropertyView::Grid_OnDoubleClick(by_ptr(void) sender, ListItemEventArgs & e)
	{
		//HEdtUIPropertyItem item = handle_convert<HEdtUIPropertyItem>(e.Item);
		tempc_ptr(PdePropertyItem) item = ptr_static_cast<PdePropertyItem>(e.Item);

		if (item/*.IsValid()*/ && item->GetIsGroup())
		{
			item->SetExpanded(!item->GetExpanded());
			//m_Grid->SetExpand(item, !item->GetExpanded());
			e.Handled = true;
			return;
		}

		//if (item/*.IsValid()*/ && item->GetValue()->GetType()->GetTypeKind() == PdeTypeInfo::kHandle)
		if (item/*.IsValid()*/ && item->GetValue())
		{
			//sharedc_ptr(Object) * h = PdeTypeTraits<sharedc_ptr(Object)>::UnboxingPtr(item->GetValue());
			sharedc_ptr(void) h = ptr_static_cast<void>(item->GetValue());

			if (h)// && h->IsValid())
			{
				PropertyViewNavigateEventArgs arg;
				arg.Item = e.Item;
				//arg.Value = *h;
				arg.Value = h;

				//EventNavigate.Fire(GetHandle(), arg);
				EventNavigate.Fire(ptr_static_cast<Self>(this), arg);
				e.Handled = arg.Handled;
			}
		}
	}

	void PropertyView::Grid_OnExpand(by_ptr(void) sender, ListItemEventArgs & e)
	{
		//HEdtUIPropertyItem item = handle_convert<HEdtUIPropertyItem>(e.Item);
		tempc_ptr(PdePropertyItem) item = ptr_static_cast<PdePropertyItem>(e.Item);
		if (item/*.IsValid()*/ && item->GetIsGroup())
			e.Handled = true;
	}

	void PropertyView::Grid_OnSelectItemChange(by_ptr(void) sender, ListItemEventArgs & e)
	{
		//HEdtUIPropertyItem item = handle_convert<HEdtUIPropertyItem>(e.Item);
		tempc_ptr(PdePropertyItem) item = ptr_static_cast<PdePropertyItem>(e.Item);
	}
}

//--------------------------------------------------------------------------------------
// methods
//--------------------------------------------------------------------------------------
namespace Gui
{
	void PropertyView::Refresh()
	{
		ClearGroup();
		m_Grid->DeleteAll();
		m_Properties.Clear();
		if (m_SelectedObject/*.IsValid()*/)
		{
			//PdeObject * obj = handle_cast<PdeObject>(m_SelectedObject);
			tempc_ptr(void) obj = ptr_static_cast<void>(m_SelectedObject);

			//PdeArrayRef<const PdeTypeInfo*> supers = obj->GetType()->GetInheritLine();
			sharedc_ptr(PdeTypeInfo) type = ptr_typeof(obj);

			PdeTypeNameArray supers = type->GetInheritLine();

			U32 size = supers.Size();

			for(U32 i=0; i<size; ++i)
			{
				if (supers[i])
				{
					//PdeArrayRef<PdeMemberInfo *> members = supers[i]->GetMembers();

					tempc_ptr(PdeTypeInfo) pTypeInfo = PdeTypeInfo::FromName(supers.GetAt(i));
					
					PdeMemberArray members = pTypeInfo->GetMembers();

					bool flag = false;

					for(U32 j=0; j<members.Size(); ++j)
					{
						//if (members[j]->GetMemberType() == PdeMemberInfo::kProperty)
						if (members[j]->GetMemberKind() == PdeMemberInfo::kProperty)
							flag = true;
					}

					if (flag)
					{
						//HEdtUIListItem parent = m_ShowGroup? m_Grid->GetRoot(): PdeHandle::kNull;

						sharedc_ptr(ListItem) parent = m_ShowGroup? m_Grid->GetRootItem(): NullPtr;

						//HEdtUIPropertyItem group = m_Grid->AddItem(parent, supers[i]->GetFullName().Str(), PdeClassPtr(), false, true);
						
						//HEdtUIPropertyItem group = m_Grid->CreateItem();

						sharedc_ptr(PdePropertyItem) group = ptr_static_cast<PdePropertyItem>(m_Grid->CreateItem());

						group->SetText(0, pTypeInfo->GetName());//supers[i]->GetFullName());
						//group->SetValue(PdeClassPtr());
						group->SetValue(NullPtr);
						group->SetReadonly(true);
						group->SetCanSelect(false);
						group->SetIsGroup(true);
						group->SetCanExpand(true);
						group->SetExpanded(true);
						m_Grid->AddExistingItem(parent, group);

						m_Groups.PushBack(group);


						parent = m_ShowGroup? group: ptr_static_cast<PdePropertyItem>(m_Grid->GetRootItem());


						for(U32 j=0; j<members.Size(); ++j)
						{
							//if (members[j]->GetMemberType() == PdeMemberInfo::kProperty)
							if (members[j]->GetMemberKind() == PdeMemberInfo::kProperty)
							{
								//const PdePropertyInfo * p = static_cast<const PdePropertyInfo *>(members[j]);

								tempc_ptr(PdePropertyInfo) p = ptr_static_cast<PdePropertyInfo>(members[j]);

								if (p && p->CanRead())
								{
									//PdeClassPtr value;
									sharedc_ptr(void) value;
									p->GetValue(obj, value);
									bool readonly = !p->CanWrite();
									
									//const PdeTypeInfo * propertyInfo = p->GetPropertyType();
														
									tempc_ptr(PdeTypeInfo) propertyInfo = PdeTypeInfo::FromName(p->GetPropertyType());

									//HEdtUIPropertyItem item = m_Grid->AddItemWithType(parent, p->GetName(), value, propertyInfo, false, readonly);

									sharedc_ptr(PdePropertyItem) item = m_Grid->AddItemWithType(parent, p->GetName(), value, propertyInfo, false, readonly);
									
									if (propertyInfo == PDE_TYPE_OF(ARGB) /*PdeTypeTraits<ARGB>::Type()*/ ||
										propertyInfo == PDE_TYPE_OF(XRGB)/*PdeTypeTraits<XRGB>::Type()*/ ||
										propertyInfo == PDE_TYPE_OF(Color4)/*PdeTypeTraits<Color4>::Type()*/||
										propertyInfo == PDE_TYPE_OF(Color3)/*PdeTypeTraits<Color3>::Type()*/)
										item->SetOwnDraw(true);

									if (m_ShowGroup)
										item->SetLevel(parent->GetLevel());

									m_Properties.PushBack(item);
									item->SetGroup(group);
								}
							}
						}

						if (m_ShowGroup && group->/*GetListNode().*/GetFirstChild())
							m_Grid->Sort(group->/*GetListNode().*/GetFirstChild()/*->data->GetHandle()*/, 0, false, true);
					}
				}
			}

			if (!m_ShowGroup && m_Grid->GetRootItem()->/*GetListNode().*/GetFirstChild())
				m_Grid->Sort(m_Grid->GetRootItem()->/*GetListNode().*/GetFirstChild()/*->data->GetHandle()*/, 0, false, true);
		}
		DirtyLayout();

	}

	void PropertyView::UpdateProperties()
	{
		//if (!m_Grid || !m_Grid->GetClientViewable()) return;

		//PdeObject * obj = handle_cast<PdeObject>(m_SelectedObject);

		tempc_ptr(void) obj = ptr_static_cast<void>(m_SelectedObject);

		if (!obj) return;

		for (U32 i=0; i<m_Properties.Size(); ++i)
		{
			if (m_Properties[i]/*.IsValid()*/)
			{
				//PdeIdentifier name(m_Properties[i]->GetText(0));
				
				Identifier name(m_Properties[i]->GetText(0));

				//const PdeMemberInfo * member = obj->GetType()->GetMember(name);
				tempc_ptr(PdeTypeInfo) type = ptr_typeof(obj);
				sharedc_ptr(PdeMemberInfo) member = type->GetMember(name);
				
				//if (member->GetMemberType() == PdeMemberInfo::kProperty)
				if (member->GetMemberKind() == PdeMemberInfo::kProperty)
				{
					//const PdePropertyInfo * p = static_cast<const PdePropertyInfo *>(member);
					sharedc_ptr(PdePropertyInfo) p = ptr_static_cast<PdePropertyInfo>(member);

					if (p && p->CanRead())
					{
						//PdeClassPtr value;

						sharedc_ptr(void) value;

						p->GetValue(obj, value);

						//PdeClassPtr itemValue = m_Properties[i]->GetValue();

						sharedc_ptr(void) itemValue = m_Properties[i]->GetValue();

						//bug maybe
						//if (value && !PdeTypeInfo::Equals(value, itemValue))
						if (value && !(value == itemValue))
							m_Properties[i]->SetValue(value);
					}
				}
			}
		}
	}

	void PropertyView::InvalidProperties()
	{
		for (U32 i=0; i<m_Properties.Size(); ++i)
		{
			if (m_Properties[i]/*.IsValid()*/)
			{
				m_Properties[i]->SetReadonly(true);
			}
		}

		Invalid();
	}


	void PropertyView::SelectActiveControl()
	{
		//HEdtUIControl control = GUISystem->GetFocusControl();
		tempc_ptr(Control) control = gGame->guiSys->GetFocusedControl();

		if (control/*.IsValid()*/ && control != m_SelectedObject && !control->IsChildOf(GetParent()))
		{
			//const PdeTypeInfo * info = control->GetType();
			tempc_ptr(PdeTypeInfo) info = ptr_typeof(control);

			control->IsChildOf(GetParent());

			SetSelectedObject(control);
		}
	}

	void PropertyView::ShowGroup(bool flag)
	{

		for (U32 i=0; i<m_Properties.Size(); ++i)
		{
			tempc_ptr(PdePropertyItem) group = m_Properties[i]->GetGroup();
			if (group/*.IsValid()*/)
				m_Properties[i]->SetParent(flag? group: ptr_static_cast<PdePropertyItem>(m_Grid->GetRootItem()));
		}

		for (U32 i=0; i<m_Groups.Size(); ++i)
		{
			m_Groups[i]->SetParent(flag ? m_Grid->GetRootItem(): m_Grid->GetGroupRoot());

			if (flag && m_Groups[i]->/*GetListNode().*/GetFirstChild())
				m_Grid->Sort(m_Groups[i]->/*GetListNode().*/GetFirstChild()/*->data->GetHandle()*/, 0, false, true);
		}

		if (!flag && m_Grid->GetRoot()->/*GetListNode().*/GetFirstChild())
			m_Grid->Sort(m_Grid->GetRootItem()->/*GetListNode().*/GetFirstChild()/*->data->GetHandle()*/, 0, false, true);

		m_Grid->DirtyLayout();
	}

	void PropertyView::ClearGroup()
	{
		if (m_ShowGroup)
		{
			for (U32 i=0; i<m_Properties.Size(); ++i)
			{
				tempc_ptr(PdePropertyItem) group = m_Properties[i]->GetGroup();
				if (group/*.IsValid()*/)
					//m_Properties[i]->SetParent(m_Grid->GetRoot());
					m_Properties[i]->SetParent(m_Grid->GetRootItem());
			}
		}

		for (U32 i=0; i<m_Groups.Size(); ++i)
		{
			//m_Groups[i]->Release();
		}
		m_Groups.Clear();
	}
}
