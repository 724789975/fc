#include "pch.h"

using namespace Core;
using namespace Gui;
using namespace Client;


//---------------------------------------------------------------------------------------
// type info.
//---------------------------------------------------------------------------------------
DEFINE_PDE_TYPE_CLASS(Gui::ButtonSkin)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::ControlSkin);
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_PROPERTY_RW(HoverImage);
		ADD_PDE_PROPERTY_RW(DownImage);
		ADD_PDE_PROPERTY_RW(DisabledImage);
		ADD_PDE_PROPERTY_RW(TwinkleImage);
		ADD_PDE_PROPERTY_RW(AnimkleImage);
	}
};

DEFINE_PDE_TYPE_CLASS(Gui::Button)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::Control);
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_EVENT(EventClick);
		ADD_PDE_EVENT(EventDoubleClick);
		ADD_PDE_EVENT(EventMouseEnter);
		ADD_PDE_EVENT(EventMouseLeave);
		ADD_PDE_EVENT(UpdateMouseMove);

		ADD_PDE_PROPERTY_RW(Text);
		ADD_PDE_PROPERTY_RW(TextAlign);
		ADD_PDE_PROPERTY_RW(PushDown);
		ADD_PDE_PROPERTY_RW(CanPushDown);
		ADD_PDE_PROPERTY_RW(TextShadowWhenNormal);
		ADD_PDE_PROPERTY_RW(ReceiveKey);
		ADD_PDE_PROPERTY_RW(NotChangeCol);
		ADD_PDE_PROPERTY_RW(blink);
		ADD_PDE_PROPERTY_RW(anim_blink);
		ADD_PDE_PROPERTY_RW(blink_shade);
		ADD_PDE_PROPERTY_W(anim_Nums);
		ADD_PDE_PROPERTY_RW(blinkwheelTimer);
		ADD_PDE_PROPERTY_RW(IsNeedToolTip);
		ADD_PDE_PROPERTY_RW(AutoWrap);
		ADD_PDE_PROPERTY_RW(AutoFontSize);
		ADD_PDE_PROPERTY_RW(AutoEllipsis);
		ADD_PDE_PROPERTY_RW(AutoEllipsisArea);
		ADD_PDE_PROPERTY_RW(AlwaysBlink);
	}
};

DEFINE_PDE_TYPE_CLASS(Gui::LobbyMainButton)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::Button);
		ADD_PDE_DEFAULT_CONSTRUCTOR();
		ADD_PDE_PROPERTY_RW(Notification);
		ADD_PDE_PROPERTY_RW(Notice);
		ADD_PDE_PROPERTY_RW(Clickable);
		ADD_PDE_PROPERTY_RW(NotificationIcon);
		ADD_PDE_PROPERTY_RW(NoticeIcon);
	}
};

DEFINE_PDE_TYPE_CLASS(Gui::LobbyMainButtonSkin)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::ControlSkin);
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_PROPERTY_RW(UpperImage);
		ADD_PDE_PROPERTY_RW(UpperHoverImage);
		ADD_PDE_PROPERTY_RW(BottomImage);
		ADD_PDE_PROPERTY_RW(GlowUpperImage);
		ADD_PDE_PROPERTY_RW(GlowBottomImage);
		ADD_PDE_PROPERTY_RW(ActiveUpperImage);
	}
};

DEFINE_PDE_TYPE_CLASS(Gui::TuneSwitchButton)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::Button);
		ADD_PDE_DEFAULT_CONSTRUCTOR();
	}
};

DEFINE_PDE_TYPE_CLASS(Gui::TuneSwitchButtonSkin)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::ButtonSkin);
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_PROPERTY_RW(HoldDownImage);
	}
};

REGISTER_PDE_TYPE(Gui::Button);
REGISTER_PDE_TYPE(Gui::ButtonSkin);
REGISTER_PDE_TYPE(Gui::LobbyMainButton);
REGISTER_PDE_TYPE(Gui::LobbyMainButtonSkin);
REGISTER_PDE_TYPE(Gui::TuneSwitchButton);
REGISTER_PDE_TYPE(Gui::TuneSwitchButtonSkin);


#define CLICK_EFFECT_DURATION 0.4f

//---------------------------------------------------------------------------------------
// attributes.
//---------------------------------------------------------------------------------------
namespace Gui
{
	Button::Button()
		: m_CanPushDown(false)
		, m_PushDown(false)
		, m_AlwaysBlink(false)
		, m_MouseHoldDown(false)
		, m_MousePointed(false)
		, m_BorderVisible(false)
		, m_SpaceKeyDown(false)
		, m_TextShadowWhenNormal(true)
		, m_CanReceiveKey(true)
		, m_TextAlign(Client::Unit::kAlignCenterMiddle)
		, m_Clickable(true)
		, m_NotChangeCol(false)
		, m_blink(false)
		, m_anim_blink(false)
		, m_blink_shade(true)
		, m_anim_Nums(0)
		, m_Timer(0)
		, m_blinkwheelTimer(1.0f)
		, m_AutoWrap(false)
		, m_AutoFontSize(false)
		, m_AutoEllipsis(false)
		, m_TextPadding(2, 0, 2, 0)
		, m_AutoEllipsisArea(0.0f)
		, m_ismouse_here(false)
		, m_IsNeedToolTip(false)
	{

	}

	Button::~Button()
	{

	}

	PDE_ATTRIBUTE_GETTER(Button, PushDown, bool)
	{
		return m_PushDown;
	}

	PDE_ATTRIBUTE_SETTER(Button, PushDown, bool)
	{
		if(m_PushDown != value)
		{
			m_PushDown = value;
			OnPushDownChanged();
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(Button,AlwaysBlink,bool)
	{
		return m_AlwaysBlink;
	}

	PDE_ATTRIBUTE_SETTER(Button,AlwaysBlink,bool)
	{
		if(m_AlwaysBlink!=value)
			m_AlwaysBlink=value;
	}

	PDE_ATTRIBUTE_GETTER(Button, blink, bool)
	{
		return m_blink;
	}

	PDE_ATTRIBUTE_SETTER(Button, blink, bool)
	{
		m_blink = value;

		if(m_blink)
			m_Timer = Task::GetTotalTime();
	}
	
	PDE_ATTRIBUTE_GETTER(Button, anim_blink, bool)
	{
		return m_anim_blink;
	}

	PDE_ATTRIBUTE_SETTER(Button, anim_blink, bool)
	{
		m_anim_blink = value;

		if(m_anim_blink)
			m_Timer = Task::GetTotalTime();
	}

	PDE_ATTRIBUTE_GETTER(Button, blink_shade, bool)
	{
		return m_blink_shade;
	}

	PDE_ATTRIBUTE_SETTER(Button, blink_shade, bool)
	{
		m_blink_shade = value;

		if(m_blink_shade)
			m_Timer = Task::GetTotalTime();
	}

	PDE_ATTRIBUTE_SETTER(Button, anim_Nums, int)
	{
		m_anim_Nums = value;

		if(m_anim_blink)
			m_Timer = Task::GetTotalTime();
	}

	PDE_ATTRIBUTE_GETTER(Button, blinkwheelTimer, F64)
	{
		return m_blinkwheelTimer;
	}

	PDE_ATTRIBUTE_SETTER(Button, blinkwheelTimer, F64)
	{
		m_blinkwheelTimer = value;

		if(m_blink)
			m_Timer = Task::GetTotalTime();
	}

	PDE_ATTRIBUTE_GETTER(Button,NotChangeCol,bool)
	{
		return m_NotChangeCol;
	}

	PDE_ATTRIBUTE_SETTER(Button,NotChangeCol,bool)
	{
		if(m_NotChangeCol!=value)
			m_NotChangeCol=value;
	}

	PDE_ATTRIBUTE_GETTER(Button, BorderVisible, bool)
	{
		return m_BorderVisible;
	}

	PDE_ATTRIBUTE_SETTER(Button, BorderVisible, bool)
	{
		if (m_BorderVisible != value)
		{
			m_BorderVisible = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(Button, TextAlign, Client::Unit::Align)
	{
		return m_TextAlign;
	}


	PDE_ATTRIBUTE_SETTER(Button, TextAlign, Client::Unit::Align)
	{
		if (m_TextAlign != value)
		{
			m_TextAlign = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_SETTER(Button, Shine, bool)
	{
		if ( !(value && m_PushDown) )
		{
			Super::SetShine(value);
		}
	}
	PDE_ATTRIBUTE_GETTER(Button, ReceiveKey, bool)
	{
		return m_CanReceiveKey;
	}

	PDE_ATTRIBUTE_SETTER(Button, ReceiveKey, bool)
	{
		if (m_CanReceiveKey != value)
		{
			m_CanReceiveKey = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(Button, AutoWrap, bool)
	{
		return m_AutoWrap;
	}

	PDE_ATTRIBUTE_SETTER(Button, AutoWrap, bool)
	{
		if(m_AutoWrap!=value)
		{
			m_AutoWrap = value;
			if(m_AutoWrap)
			{
				SetAutoSize(false);
				// SetTextAlign(Client::Unit::kAlignLeftTop);
				ReWrapText();
				EllipsisMyText();
			}
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(Button, AutoFontSize, bool)
	{
		return m_AutoFontSize;
	}

	PDE_ATTRIBUTE_SETTER(Button, AutoFontSize, bool)
	{
		if(m_AutoFontSize!=value)
		{
			m_AutoFontSize = value;
			if(m_AutoFontSize)
			{
				m_ResultFontSize = GetFontSize();
				SetAutoSize(false);
				CalcFontSize();
			}
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(Button, AutoEllipsis, bool)
	{
		return m_AutoEllipsis;
	}

	PDE_ATTRIBUTE_SETTER(Button, AutoEllipsis, bool)
	{
		if(m_AutoEllipsis!=value)
		{
			m_AutoEllipsis = value;
			Invalid();
		}
	}
	
	PDE_ATTRIBUTE_GETTER(Button, AutoEllipsisArea, F32)
	{
		return m_AutoEllipsisArea;
	}

	PDE_ATTRIBUTE_SETTER(Button, AutoEllipsisArea, F32)
	{
		if(m_AutoEllipsisArea!=value)
		{
			m_AutoEllipsisArea = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(Button, TextPadding, Core::Vector4)
	{
		return m_TextPadding;
	}

	PDE_ATTRIBUTE_SETTER(Button, TextPadding, Core::Vector4)
	{
		if(m_TextPadding!=value)
		{
			m_TextPadding = value;
			EllipsisMyText();
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(Button, IsNeedToolTip, bool)
	{
		return m_IsNeedToolTip;
	}

	PDE_ATTRIBUTE_SETTER(Button, IsNeedToolTip, bool)
	{
		if(m_IsNeedToolTip!=value)
		{
			m_IsNeedToolTip = value;
			Invalid();
		}
	}
}

//--------------------------------------------------------------------------------------
// events.
//--------------------------------------------------------------------------------------
namespace Gui
{
	void Button::OnFrameUpdate(EventArgs & e)
	{
		Control::OnFrameUpdate(e);

		if(m_MousePointed)
		{
			if(GetHoverPower()<0.99f)
			{
				IncreaseHoverPower();
				Invalid();
			}
		}
		else if(GetShine())
		{
			Shine();
		}
		else if(GetHoverPower()>0.01f)
		{
			DecreaseHoverPower();
			Invalid();
		}

		if (m_IsNeedToolTip && m_ismouse_here)
		{
			UpdateMouseMove.Fire(ptr_static_cast<Control>(this), e);
		}
	}

	void Button::OnPaint(PaintEventArgs & e)
	{
		Control::OnPaint(e);

		tempc_ptr(ButtonSkin) skin = ptr_static_cast<ButtonSkin>(GetSkin());
		Core::Rectangle StringRect(GetBackgroundRect().Shrink(GetPadding()));
		

		if (skin)
		{
			if(e.Enable)
			{
				if(m_blink || m_anim_blink)
				{
					BlinkButton(e);
				}
				if (m_AlwaysBlink)
				{
					return;
				}
				bool bHighlight = false;
				if ((m_MousePointed && m_MouseHoldDown) ||m_PushDown )
				{
					Skin::DrawImage(e.render, skin->GetDownImage(), GetBackgroundRect());
					bHighlight = true;
					e.render->DrawString(GetFont(), bHighlight? GetHighlightTextColor() : GetTextColor(), ARGB(0, 0, 0, 0),StringRect, m_AutoEllipsis?m_EllipsisStr:(m_AutoWrap?m_MultiLineStr:m_Text), GetTextAlign());
				}
				else
				{
					//Skin::DrawImage(e.render, skin->GetBackgroundImage(), GetBackgroundRect(), Core::ARGB(255-(U8)(GetHoverPower()*255), 255, 255, 255));
					Skin::DrawImage(e.render, skin->GetHoverImage(), GetBackgroundRect(), Core::ARGB((U8)(GetHoverPower()*255), 255, 255, 255));
					if (m_MousePointed || m_MouseHoldDown)	
						bHighlight = true;
					if(m_TextShadowWhenNormal)
						e.render->DrawString(GetFont(), bHighlight? GetHighlightTextColor() : GetTextColor(), ARGB(0, 0, 0, 0),StringRect, m_AutoEllipsis?m_EllipsisStr:(m_AutoWrap?m_MultiLineStr:m_Text), GetTextAlign());
					else
						e.render->DrawString(GetFont(), bHighlight? GetHighlightTextColor() : GetTextColor(), ARGB(0, 0, 0, 0),StringRect, m_AutoEllipsis?m_EllipsisStr:(m_AutoWrap?m_MultiLineStr:m_Text), GetTextAlign());
				}
			}
			else
			{
				Skin::DrawImage(e.render, skin->GetDisabledImage(), GetBackgroundRect());
				e.render->DrawString(GetFont(), GetDisabledTextColor(), ARGB(0, 0, 0, 0),StringRect, m_AutoEllipsis?m_EllipsisStr:(m_AutoWrap?m_MultiLineStr:m_Text), GetTextAlign());
			}
			if(m_NotChangeCol)
				e.render->DrawString(GetFont(), m_TextColor, ARGB(0, 0, 0, 0),StringRect, m_AutoEllipsis?m_EllipsisStr:(m_AutoWrap?m_MultiLineStr:m_Text), GetTextAlign());
		}
		else if(!skin)
		{
			e.render->DrawString(GetFont(), m_TextColor, m_BackgroundColor,StringRect, m_AutoEllipsis?m_EllipsisStr:(m_AutoWrap?m_MultiLineStr:m_Text), GetTextAlign());
		}
	}


	void Button::OnInputEvent( Client::InputEventArgs &e )
	{
		if (e.IsMouseEvent())
		{

			Core::Vector2 localPos = ScreenToClient(e.CursorPosition);
			m_MousePointed =  GetDisplayRect().IsPointInside(localPos);

			switch (e.Type)
			{
			case InputEventArgs::kMouseDown:
			case InputEventArgs::kMouseDoubleClick:
				{
					if(m_Clickable)
					{
						if(m_MousePointed && e.Code == MC_LEFT_BUTTON )
						{
							if (e.Type == InputEventArgs::kMouseDoubleClick)
							{
								OnDoubleClick(e);
							}
							Invalid();
							SetCapture(true);
							m_MouseHoldDown = true;
							e.Handled = true;
						}
						else if(m_MousePointed && e.Code == MC_RIGHT_BUTTON)
						{
							e.Handled = true;
							EventMouseDown.Fire(ptr_static_cast<Button>(this), e);
						}
					}
					else
					{
						e.Handled = true;
					}
				}
				break;

			case InputEventArgs::kMouseUp:
				{
					if(m_Clickable)
					{
						if(e.Code == MC_LEFT_BUTTON && m_MouseHoldDown)
						{					
							Invalid();
							m_MouseHoldDown = false;

							SetCapture(false);

							if(m_MousePointed)
							{
								if(m_CanPushDown)
									SetPushDown(!m_PushDown);
								OnClick(e);
							}
							e.Handled = true;
						}
					}
					else
					{
						e.Handled = true;
					}
				}
				break;
			case InputEventArgs::kMouseEnter:
				{
					EventMouseEnter.Fire(ptr_static_cast<Button>(this), e);
					if (m_IsNeedToolTip)
					{
						m_ismouse_here = true;
					}
				}
				break;
			case InputEventArgs::kMouseLeave:
				{
					m_MousePointed = false;
					e.Handled = false;

					EventMouseLeave.Fire(ptr_static_cast<Button>(this), e);
					if (m_IsNeedToolTip)
					{
						m_ismouse_here = false;
					}
				}
				break;
			}
		}

		if(e.IsKeyEvent() && m_Clickable)
			OnKeyEvent(e);

		if (!e.Handled)
			Control::OnInputEvent(e);
	}

	void Button::OnKeyEvent(Client::InputEventArgs &e)
	{
		//key down
		if(e.Type == InputEventArgs::kKeyDown && !(e.ShiftKeyDown || e.ControlKeyDown || e.AltKeyDown))
		{	
			switch(e.Code)
			{
			case KC_SPACE:
			case KC_RETURN:
				//m_MousePointed = true;
				//m_MouseHoldDown = true;
				//if(m_CanReceiveKey)
				//	m_SpaceKeyDown = true;
				//SetCapture(true);
				//Invalid();
				//e.Handled = true;
				break;

			default:
				break; 
			}
		}
		//key up
		if(e.Type == InputEventArgs::kKeyUp)
		{
			switch(e.Code)
			{
			case KC_SPACE:
			case KC_RETURN:
				//m_MousePointed = false;
				//m_MouseHoldDown = false;
				//if(m_SpaceKeyDown)
				//{
				//	m_SpaceKeyDown = false;
				//	OnClick(e);
				//}
				//SetCapture(false);
				//Invalid();
				//e.Handled = true;
				break;
			default:
				break;
			}
		}

	}


	void Button::OnClick(Client::InputEventArgs &e)
	{
		SetShine(false);
		EventClick.Fire(ptr_static_cast<Button>(this), e);

	}

	void Button::OnDoubleClick(Client::InputEventArgs & e)
	{
		EventDoubleClick.Fire(ptr_static_cast<Button>(this), e);
	}

	void Button::DragEnd(InputEventArgs &e)
	{
		tempc_ptr(Control) pRoot;
		tempc_ptr(Control) pCurrent = ptr_static_cast<Control>(this);
		while(pCurrent)
		{
			pRoot = pCurrent;
			pCurrent = pCurrent->GetParent();
		}
		tempc_ptr(GuiSystem) pSystem = ptr_dynamic_cast<GuiSystem>(pRoot);
		Vector2 localPos;
		tempc_ptr(Control) pResult = pSystem->GetWindowAndPos(e.CursorScreenPosition, localPos);

		if(pResult)
		{
			pResult = pResult->ControlFromLocation(localPos);
			Core::String resultType(ptr_typename(pResult));
			LogSystem.WriteLinef("Drag End at Target %s: 0x%08x", resultType, pResult.ToPointer());
		}
	}

	void Button::OnPushDownChanged()
	{

	}

	void Button::BlinkButton(PaintEventArgs & e)
	{
		F64 timer = Task::GetTotalTime() - m_Timer;
		tempc_ptr(ButtonSkin) skin = ptr_static_cast<ButtonSkin>(GetSkin());

		if((m_blink || m_anim_blink) && timer >= m_blinkwheelTimer)
		{
			m_Timer = Task::GetTotalTime();
			timer = 0;
		}
		if ((m_PushDown || GetHoverPower() == 1.0f) && !m_AlwaysBlink)
		{
			return;
		}
		if (m_blink && !m_anim_blink)
		{
			if (m_blink_shade)
			{
				if (timer > m_blinkwheelTimer / 2 )
				{
					Skin::DrawImage(e.render, skin->GetTwinkleImage(), GetBackgroundRect(),Core::ARGB((U8)((2 - 2*timer/m_blinkwheelTimer)*255), 255, 255, 255));
				} 
				else
				{
					Skin::DrawImage(e.render, skin->GetTwinkleImage(), GetBackgroundRect(),Core::ARGB((U8)(2*timer*255/m_blinkwheelTimer), 255, 255, 255));
				}
			} 
			else
			{
				if (timer > m_blinkwheelTimer / 2 )
					Skin::DrawImage(e.render, skin->GetTwinkleImage(), GetBackgroundRect(),Core::ARGB(255, 255, 255, 255));
			}
		}
		else if (m_anim_blink && !m_blink)
		{
			int	which = m_anim_Nums * timer/m_blinkwheelTimer;
			if (which >= m_anim_Nums)
			{
				which = 0;
			}
			by_ptr(Gui::Image) image = skin->GetAnimkleImage();
			image->Setuv(Core::Vector4((float)which/(float)m_anim_Nums,0,(float)(which + 1)/m_anim_Nums,1));
			Skin::DrawImage(e.render, image, GetBackgroundRect(),Core::ARGB(255, 255, 255, 255));
		}
	}

	void Button::ReWrapText()
	{
		if(m_AutoWrap)
		{
			Core::Vector4 textPadding = GetTextPadding();
			Core::Rectangle rect(Vector2(textPadding.x, textPadding.y), GetSize() - Vector2(textPadding.z, textPadding.w));
			Control::SplitString(GetText(), m_MultiLineStr, rect, GetFont());	
		}
		DirtyLayout();
	}

	void Button::CalcFontSize()
	{
		if(m_AutoFontSize && !m_AutoWrap && m_Size.x>20)
		{
			m_ResultFontSize = GetFontSize();
			Core::Rectangle tempRect = Core::Rectangle(0,0,0,0);
			Vector2 o = GetFont()->MeasureString(tempRect, m_Text, -1, Unit::kAlignCenterMiddle).GetExtent();
			while(o.x>=GetSize().x-GetTextPadding().x-GetTextPadding().z && m_ResultFontSize>=8)
			{
				m_ResultFontSize -= 2;
				tempRect = Core::Rectangle(0,0,0,0);
				o = GetAutoFont()->MeasureString(tempRect, m_Text, -1, Unit::kAlignCenterMiddle).GetExtent();
			}
		}
		Invalid();
	}

	tempc_ptr(Client::Font) Button::GetAutoFont()
	{
		tempc_ptr(Client::Font) autoFont = NullPtr;
		if (gGame)
			autoFont = gRender->font_manager->GetFont(m_FontName, m_ResultFontSize, 0);

		return autoFont;
	}


	void Button::EllipsisMyText()
	{
		if(GetAutoSize())
		{
			m_EllipsisStr = m_AutoWrap?m_MultiLineStr:m_Text;
			m_Hint = "";
			Invalid();
		}
		else
		{
			Core::Vector4 textPadding = GetTextPadding();
			Core::Rectangle rect(Vector2(textPadding.x, textPadding.y), GetSize() - Vector2(textPadding.z + m_AutoEllipsisArea, textPadding.w));
			int ePos = Control::EllipsisString(m_AutoWrap?m_MultiLineStr:m_Text, m_EllipsisStr, rect.GetExtent(), GetFont());
			//Hint ����ʾ����
// 			if(ePos>=0)
// 			{
// 				m_Hint = m_Text;
// 			}
// 			else
// 			{
// 				m_Hint = String::kEmpty;
// 			}
			Invalid();
		}
	}

	void Button::OnSizeChanged( ResizeEventArgs & e )
	{
		Super::OnSizeChanged(e);
		ReWrapText();
		EllipsisMyText();
	}

	/// on auto size
	void Button::OnAutoSize(AutoSizeEventArgs & e)
	{
		Core::Vector4 textPadding = GetTextPadding();
		//e.clientRect.Max = Skin::MeasureIconText(GetIcon(), GetFont(), GetText()) + Vector2(textPadding.x+textPadding.z, textPadding.y+textPadding.w);

		Super::OnAutoSize(e);
	}

	/// on text changed
	void Button::OnTextChanged(EventArgs & e)
	{
		ReWrapText();
		CalcFontSize();
		EllipsisMyText();
	}
}

namespace Gui
{
	LobbyMainButton::LobbyMainButton()
		: m_ClickEffect(0.0f)
		, m_Clicked(false)
		, m_Clickable(true)
		, m_Notice(false)
	{

	}

	LobbyMainButton::~LobbyMainButton()
	{

	}

	PDE_ATTRIBUTE_GETTER(LobbyMainButton, Notification, const Core::String&)
	{
		return m_Notification;
	}

	PDE_ATTRIBUTE_SETTER(LobbyMainButton, Notification, const Core::String&)
	{
		if(m_Notification!=value)
		{
			m_Notification = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(LobbyMainButton, Notice, bool)
	{
		return m_Notice;
	}

	PDE_ATTRIBUTE_SETTER(LobbyMainButton, Notice, bool)
	{
		if(m_Notice!=value)
		{
			m_Notice = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(LobbyMainButton, NotificationIcon, tempc_ptr(Icon))
	{
		return m_NotificationIcon;
	}

	PDE_ATTRIBUTE_SETTER(LobbyMainButton, NotificationIcon, tempc_ptr(Icon))
	{
		if(m_NotificationIcon!=value)
		{
			m_NotificationIcon = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(LobbyMainButton, NoticeIcon, tempc_ptr(Icon))
	{
		return m_NoticeIcon;
	}

	PDE_ATTRIBUTE_SETTER(LobbyMainButton, NoticeIcon, tempc_ptr(Icon))
	{
		if(m_NoticeIcon!=value)
		{
			m_NoticeIcon = value;
			Invalid();
		}
	}

	void LobbyMainButton::OnCreate()
	{
		Super::OnCreate();
		m_NotificationFont = gRender->font_manager->GetFont("simhei", 12, 0);
	}

	void LobbyMainButton::OnFrameUpdate(EventArgs & e)
	{
		Super::OnFrameUpdate(e);
		if(m_Clicked)
		{
			F32 frameTime = Task::GetFrameTime();
			m_ClickEffect+=frameTime/CLICK_EFFECT_DURATION;
			if(m_ClickEffect>1.0f)
			{
				m_Clicked = false;
				m_ClickEffect = 0.0f;
			}
			Invalid();
		}
	}

	void LobbyMainButton::OnInputEvent( Client::InputEventArgs & e )
	{
		if (e.IsMouseEvent())
		{

			Core::Vector2 localPos = ScreenToClient(e.CursorPosition);
			m_MousePointed =  GetDisplayRect().IsPointInside(localPos);

			switch (e.Type)
			{
			case InputEventArgs::kMouseDown:
			case InputEventArgs::kMouseDoubleClick:
				{
					if(m_Clickable)
					{
						if(m_MousePointed && e.Code == MC_LEFT_BUTTON )
						{
							if (e.Type == InputEventArgs::kMouseDoubleClick)
							{
								OnDoubleClick(e);
							}
							Invalid();
							SetCapture(true);
							m_MouseHoldDown = true;
							e.Handled = true;
						}
					}
					else
					{
						e.Handled = true;
					}
				}
				break;

			case InputEventArgs::kMouseUp:
				{
					if(m_Clickable)
					{
						if(e.Code == MC_LEFT_BUTTON && m_MouseHoldDown)
						{					
							Invalid();
							m_MouseHoldDown = false;

							SetCapture(false);

							if(m_MousePointed)
							{
								if(m_CanPushDown)
									m_PushDown = !m_PushDown;
								OnClick(e);
							}
							e.Handled = true;
						}
					}
					else
					{
						e.Handled = true;
					}
				}
				break;

			case InputEventArgs::kMouseLeave:
				{
					m_MousePointed = false;
					e.Handled = false;
				}
				break;
			}
		}

		if(e.IsKeyEvent() && m_Clickable)
			OnKeyEvent(e);

		if (!e.Handled)
			Control::OnInputEvent(e);
	}

	void LobbyMainButton::OnClick(Client::InputEventArgs &e)
	{
		Super::OnClick(e);
		m_Clicked = true;
	}

	void LobbyMainButton::OnPaint(PaintEventArgs & e)
	{
		tempc_ptr(LobbyMainButtonSkin) skin = ptr_static_cast<LobbyMainButtonSkin>(GetSkin());

		if (skin)
		{
			if(e.Enable)
			{
				F32 upperHeight = skin->GetUpperImage()->GetSize().y;
				F32 bottomHeight = 19;
				F32 lefttopY1 = 16;
				Core::Rectangle upperRect;
				Core::Rectangle bottomRect = Core::Rectangle::LeftBottom(0, GetSize().y, GetSize().x, bottomHeight);
				ARGB textColor = m_TextColor;
				textColor.a = 160;
				if(m_PushDown)
				{
					upperRect = Core::Rectangle::LeftTop(0,0,GetSize().x, upperHeight);
					textColor.a = 255;
				}
				else
				{
					upperRect = Core::Rectangle::LeftTop(0, lefttopY1*(1-GetHoverPower()), GetSize().x, upperHeight);
				}
				if(m_PushDown)
				{
					Skin::DrawImage(e.render, skin->GetActiveUpperImage(), upperRect);
				}
				else
				{
					U8 uAlpha = (U8)(GetHoverPower()*255);
					Skin::DrawImage(e.render, skin->GetUpperImage(), upperRect);
					Skin::DrawImage(e.render, skin->GetUpperHoverImage(), upperRect, ARGB(uAlpha, 255,255,255));
				}
				e.render->DrawStringShadow(GetFont(), textColor, ARGB(192,0,0,0), ARGB(0,0,0,0), bottomRect
					, GetText(), Unit::kAlignCenterMiddle);					
				if(m_Clicked)
				{
					U8 uAlpha = 0;
					F32 turnPoint = 0.4f;
					if(m_ClickEffect<=turnPoint)
					{
						uAlpha = (U8)(m_ClickEffect*1.0f/turnPoint*255);
					}
					else
					{
						uAlpha = 255-(U8)Core::Clamp((U32)((m_ClickEffect-turnPoint)/(1-turnPoint)*255), 0, 255);
					}
					Skin::DrawImage(e.render, skin->GetGlowUpperImage(), Core::Rectangle::LeftTop(0,0,GetSize().x, upperHeight), ARGB(uAlpha, 255, 255, 255));
				}

				//for painting notification
				if(m_Notification.Length()>0)
				{
					tempc_ptr(Icon) notificationImage = m_NotificationIcon;
					F32 notificationWidth = notificationImage?notificationImage->GetSize().x:25;
					F32 notificationHeight = notificationImage?notificationImage->GetSize().y:25;
					Core::Rectangle NotificationRect = Core::Rectangle::LeftBottom(upperRect.Min.x+2,upperRect.Max.y-30
						, notificationWidth, notificationHeight);
					Skin::DrawImage(e.render, notificationImage, NotificationRect);
					e.render->DrawString(m_NotificationFont, ARGB(255,255,255,255), ARGB(0,0,0,0), NotificationRect, m_Notification
						, Unit::kAlignCenterMiddle);
				}

				//for painting notice icon
				if(m_Notice)
				{
					tempc_ptr(Icon) noticeImage = GetNoticeIcon();
					F32 noticeWidth = noticeImage?noticeImage->GetSize().x:6;
					F32 noticeHeight = noticeImage?noticeImage->GetSize().y:15;
					Core::Rectangle NoticeRect = Core::Rectangle::RightBottom(upperRect.Max.x-19, upperRect.Max.y-4
						, noticeWidth, noticeHeight);
					Skin::DrawImage(e.render, noticeImage, NoticeRect);
				}

			}
			else
			{
			}
		}
		else
		{
			e.render->DrawString(GetFont(), m_TextColor, m_BackgroundColor, GetBackgroundRect().Shrink(GetPadding()), m_Text, Unit::kAlignCenterMiddle);
		}
	}
}

namespace Gui
{
	void TuneSwitchButton::OnPaint( PaintEventArgs & e )
	{
		tempc_ptr(TuneSwitchButtonSkin) skin = ptr_static_cast<TuneSwitchButtonSkin>(GetSkin());

		if (skin)
		{
			if(e.Enable)
			{
				bool bHighlight = false;
				if(m_PushDown)
				{
					Skin::DrawImage(e.render, skin->GetDownImage(), GetBackgroundRect());
					bHighlight = true;
					e.render->DrawStringShadow(GetFont(), bHighlight? GetHighlightTextColor() : GetTextColor(), GetTextShadowColor(), ARGB(0, 0, 0, 0), GetBackgroundRect().Shrink(GetPadding()), m_Text, GetTextAlign(), -1, GetTextLightSource());					
				}
				else if (m_MousePointed && m_MouseHoldDown)
				{
					Skin::DrawImage(e.render, skin->GetHoldDownImage(), GetBackgroundRect());
					bHighlight = true;
					e.render->DrawStringShadow(GetFont(), bHighlight? GetHighlightTextColor() : GetTextColor(), GetTextShadowColor(), ARGB(0, 0, 0, 0), GetBackgroundRect().Shrink(GetPadding()), m_Text, GetTextAlign(), -1, GetTextLightSource());
				}
				else
				{
					Skin::DrawImage(e.render, skin->GetBackgroundImage(), GetBackgroundRect(), Core::ARGB(255/*-(U8)(GetHoverPower()*255)*/, 255, 255, 255));
					Skin::DrawImage(e.render, skin->GetHoverImage(), GetBackgroundRect(), Core::ARGB((U8)(GetHoverPower()*255), 255, 255, 255));
					if (m_MousePointed || m_MouseHoldDown)	
						bHighlight = true;
					if(m_TextShadowWhenNormal)
						e.render->DrawStringShadow(GetFont(), bHighlight? GetHighlightTextColor() : GetTextColor(), GetTextShadowColor(), ARGB(0, 0, 0, 0), GetBackgroundRect().Shrink(GetPadding()), m_Text, GetTextAlign(), -1, GetTextLightSource());
					else
						e.render->DrawString(GetFont(), bHighlight? GetHighlightTextColor() : GetTextColor(), ARGB(0, 0, 0, 0), GetBackgroundRect().Shrink(GetPadding()), m_Text, GetTextAlign());
				}
			}
			else
			{
				Skin::DrawImage(e.render, skin->GetDisabledImage(), GetBackgroundRect());
				e.render->DrawString(GetFont(), GetDisabledTextColor(), ARGB(0, 0, 0, 0), GetBackgroundRect().Shrink(GetPadding()), m_Text, GetTextAlign());
			}
		}
		else
		{
			e.render->DrawString(GetFont(), m_TextColor, m_BackgroundColor, GetBackgroundRect().Shrink(GetPadding()), m_Text, GetTextAlign());
		}
	}
}