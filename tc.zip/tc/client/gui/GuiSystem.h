namespace Gui
{	
	class Window;
	struct PaintEventArgs;
	class CharacterSlot;
	class CharacterPlate;

	class GuiSystem : public Control
	{
		friend class Window;
		DECLARE_PDE_OBJECT(GuiSystem, Control);

	public:
		GuiSystem();
		~GuiSystem();

	public:
		enum UIAudioEnum
		{
			kUIA_lOBBY_MUSIC=0,
			kUIA_MATCH,
			kUIA_MOUSE_CLICK,
			kUIA_BUY_SUCCESS,
			kUIA_NEW_MAIL,
			kUIA_SYSTEM_MESSAGE,
			kUIA_CONFIRM_MESSAGE,
			kUIA_BALLOON,
			kUIA_WEAPON_MOD,
			kUIA_TEAM_INVITED,
			kUIA_USE_EQUIP_ITEM,
			kUIA_LEVEL_UP,
			kUIA_CHAT_MESSAGE,
			kUIA_TREASURE_BOX,
			kUIA_CONGRA_POP,
			kUIA_GAME_WIN,
			kUIA_GAME_LOSE,
			
			//timmy
			kUIA_COMPOUND_SUCCEED,	//ǿ�������ף���Ƕ�ɹ���Ч
			kUIA_COMPOUND_FAIL,		//ǿ�������ף���Ƕʧ����Ч
			kUIA_COMPOUND_SUCCEED_SWF, //ǿ��FLASH�ɹ���Ч
			kUIA_COMPOUND_FAIL_SWF,	   //ǿ��FLASHʧ����Ч
			kUIA_COMPOUND_SUCCEED_SWF_EX,	//ǿ������ߵȼ���Ч
			kUIA_COMPOUND_PUT,	   //�ŵ���λ
			kUIA_OPEN_SUCCEED,		//�򿪴���������и߼����ؽ��ң����и߼�ǩ����к�����Ч
			kUIA_LOTTERY,			//��ħ�ޣ�vip���ᣬ���˲ʺк�����Ч
			kUIA_STAGE_TURNCARD,	//���ؽ��㷭����Ч
			kUIA_LAOHUJI,
			kUIA_MVPMOVE,
			kUIA_GETITEM,
			kUIA_OPEN_CODECASE, 
			kUIA_USE_EXP,
			kUIA_USE_EXP_LEVELUP,
			kUIA_USE_ITEM,
			kUIA_EQUIPMENT,
			kUIA_GET_GOOD_REWARD,
			kUIA_GET_REWARD,
			kUIA_CLOSE_TIME,		//���ؽ��㵹����Ч
			kUIA_CLEAN_UP,	//�����ֿⰴť��Ч
			kUIA_CREATE_TEAM,	//����ս�ӳɹ���Ч
			kUIA_DISMISS_TEAM,	//����ս��ʧ����Ч
			kUIA_SEND_MAIL,		//�����ʼ��ɹ���Ч
			kUIA_COMPOUND_PUT_ITEM,		//�ϳ��ز�������Ч
			kUIA_MISSION_REWARD,		//������ȡ��ť��Ч
			kUIA_UNLOCK_MODULE,		//ģ�鿪����Ч
			kUIA_POKERCARD_TRUN,	//���ؽ��㷭����Ч
			kUIA_CLOSE_UI,			//�����л���Ч
			kUIA_CLOSE_UI2,			//���������л���Ч
			kUIA_USE_MONEY,			//ʹ��Ǯ������Ч
			kUIA_STORAGE,			//ʹ�òֿ⣬�ϳɽ��汳������

			// shooting
			kUIA_SHOOTING_ON_HIT,	//���й��ӵ���Ч

			// ������Ч
			kUIA_FUSION_START,		//������ʼ��Ч
			kUIA_FUSION_LOOK,		//�����鿴��Ч
			// ƴͼ��Ч
			kUIA_PUZZLE_COMPLETE,	//ƴͼ���ʱ������	
			kUIA_PUZZLE_MATCH,		//ƴͼ��Ƭ�ƶ���ƴͼ��ʱ������
			kUIA_PUZZLE_MOVE,		//ƴͼ��Ƭ�ƶ�ʱ������

			kUIA_MAX,
		};

		//Events
	public:
		DECLARE_PDE_EVENT(EventControlStyleChanged,		StyleChangeEventArgs);
		DECLARE_PDE_EVENT(EventShowMessage,				MessageEventArgs);
		DECLARE_PDE_EVENT(EventAvatarSwitched,			Core::EventArgs);
		DECLARE_PDE_EVENT(EventShowHelp,			Core::EventArgs);
		DECLARE_PDE_EVENT(EventSizeChangedAdd,			Core::EventArgs);
		//Attributes
	public:
		DECLARE_PDE_ATTRIBUTE_W (Location,		Core::Vector2);

		DECLARE_PDE_ATTRIBUTE_RW(FocusedControl, sharedc_ptr(Control));
		DECLARE_PDE_ATTRIBUTE_R (PointedControl, sharedc_ptr(Control));

		INLINE_PDE_ATTRIBUTE_RW(DrawDG, bool);
		INLINE_PDE_ATTRIBUTE_R(WinGlowTexture, tempc_ptr(Client::Texture2D));

		//Do not expose to lua
		INLINE_PDE_ATTRIBUTE_R(ViewMatrix, Core::Matrix44);
		INLINE_PDE_ATTRIBUTE_R(ProjMatrix, Core::Matrix44);

	public:
		void OnCreate(void);
		void OnDestroy(void);
		void OnScreenInput(Client::InputEventArgs& e);
		void OnSizeChangedAdd();

		// control style changed
		void OnControlStyleChanged(StyleChangeEventArgs & e);

		// language changed
		void OnLanguageChanged(EventArgs & e);

		void Update(void);
		void Render(by_ptr(Client::UIRender) renderer);

		// on input event as a control
		virtual void OnInputEvent(InputEventArgs & e);

		virtual bool GetVisibility();

		void OnAvatarSwitched();

		// Focus utilities
		bool ChangeFocusedControl(tempc_ptr(Control) pValue);
		bool ChangeFocusedLine(tempc_ptr(Control) pFrom, tempc_ptr(Control) pTo);
		void SetCaptureControl(tempc_ptr(Control) pControl, bool bCapture);
		tempc_ptr(Control) GetCaptureControl();
		void UpdateFocusedLine( tempc_ptr(Control) pControl );
		void OnFocusControlChanged(FocusEventArgs & e);

		void AccquireCapture();
		void ReleaseCapture();

		virtual void RearrangeChildren();

		// window from mouse position
		tempc_ptr(Control) GetWindowAndPos(const Core::Vector2 & pos, Core::Vector2 & outLocalPos, tempc_ptr(Control) lockToThisWindow = NullPtr);
		tempc_ptr(Control) GetWindowAndPosHard(const Core::Vector2 & pos, Core::Vector2 & outLocalPos, tempc_ptr(Control) lockToThisWindow = NullPtr);
		tempc_ptr(Control) GetWindowAndPosSoft(const Core::Vector2 & pos, Core::Vector2 & outLocalPos, tempc_ptr(Control) lockToThisWindow = NullPtr);

	public:
		void ShowMessage(const Core::String& errorMsg);
		void ShowIE();
		void ShowFCM();
		void ShowGW();
		void SetFaceBookData(const Core::String& mark);
	public:
		void DeviceReset();
		void DeviceCreate();
		void DeviceLost();
		void DeviceDestory();
		void UpdateVirtualSize();
		void TrySetCursorShape(Client::Screen::CursorShape shape);
		void ActuallySetCursorShape(Client::Screen::CursorShape shape);

	public:
		void PlayAudio(UIAudioEnum audio);
		const Core::String& GetAudioResourceName(UIAudioEnum audio);

	protected:
		Core::Matrix44					m_ViewMatrix;
		Core::Matrix44					m_ProjMatrix;

		Client::RenderTarget				texdata_1x1;

		bool							bDebugDrawUV;
		bool							bActive;
		

		IDirect3DVertexDeclaration9* input_layout;
		sharedc_ptr(Client::Shader)	vertex_shader;	
		sharedc_ptr(Client::Shader)	pixel_shader;	

		weakc_ptr(Control)	m_PointedControl;
		weakc_ptr(Control)	m_FocusedControl;
		weakc_ptr(Control)	m_CaptureControl;

		// dirty glass texture
		sharedc_ptr(Client::Texture2D)		m_dgTexture;
		sharedc_ptr(Client::Texture2D)		m_WinGlowTexture;
		bool					m_bWideScreen;
		bool					m_DrawDG;
		Client::Screen::CursorShape m_newCursorShape;
		Core::Array<Core::String>	m_AudioResouceNames;

		//assistant variable
		bool					m_AvatarRotating;

		F32						m_FOV;

	protected:
		//For character spelling
		sharedc_ptr(CharacterSlot)						m_ActiveCharSlot;

	public:
		tempc_ptr(CharacterSlot) GetActiveCharSlot();
		void SetActiveCharSlot(tempc_ptr(CharacterSlot) slot, bool bActive);
		Core::HashSet<U32, sharedc_ptr(CharacterPlate)>	m_CharPlatesPool;
		void SetAllCharPlatesClickable(bool bClickable);
	};
}