#include "pch.h"

using namespace Core;
using namespace Gui;
using namespace Client;

DEFINE_PDE_TYPE_CLASS(Gui::TabpadSkin)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::ControlSkin);
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_PROPERTY_RW(TabNormalImage);
		ADD_PDE_PROPERTY_RW(TabHoverImage);
		ADD_PDE_PROPERTY_RW(TabActiveImage);
		ADD_PDE_PROPERTY_RW(TabNormalDisabledImage);
		ADD_PDE_PROPERTY_RW(TabActiveDisabledImage);
		ADD_PDE_PROPERTY_RW(TabBgImage);
	}
};

DEFINE_PDE_TYPE_CLASS(Gui::Tabpad)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::Control);
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_EVENT(EventSelectedPageChanged);

		ADD_PDE_PROPERTY_RW(SelectedPage);
		ADD_PDE_PROPERTY_RW(TabDock);
		ADD_PDE_PROPERTY_RW(TabSize);
		ADD_PDE_PROPERTY_RW(TabGap);
		ADD_PDE_PROPERTY_RW(Index);
		ADD_PDE_PROPERTY_RW(TabPadding);
		ADD_PDE_PROPERTY_RW(TabLabelPadding);
		ADD_PDE_PROPERTY_RW(TabTextAlign);
		ADD_PDE_PROPERTY_RW(TabLableAutoSize);//lable width = text width
		ADD_PDE_PROPERTY_RW(TabLableAutoFill);//lables fill head.Shink(padding)
		ADD_PDE_PROPERTY_RW(ActiveTextShadow);//Active tab text casts shadow

		ADD_PDE_METHOD(SelectFirstPage);
		ADD_PDE_METHOD(SelectLastPage);
	}
};

REGISTER_PDE_TYPE(Gui::TabpadSkin);
REGISTER_PDE_TYPE(Gui::Tabpad);

namespace Gui
{
	Tabpad::Tabpad()
		:m_SelectedPage(NullPtr)
		,m_HoverPage(NullPtr)
		,m_sonCount(0)
		,m_Index(-1)
		,tabLableWidth(40.f)
		,tabLableHeight(20.f)
		,tabLableLocationOffset(0.f)
		,tabLableLocationAimOffset(0.f)
		,pre_tabLableLocationOffset(0.f)
		,m_tabDock(kDockTopCenter)//only recept kDockTop,kDockBottom,kDockLeft,kDockRight, DONT recept fill, none

		,m_ShowNextPreLableLength(20.f)
		,m_TabHeadLength(20.f)
		,m_tabGap(0.f)
		,m_TabPadding(0.f, 0.f, 20.f, 0.f)
		,m_TabTextAlign(Client::Unit::kAlignCenterMiddle)
		,m_TabLabelPadding(0,0,0,0)
		,m_TabLableAutoSize(false)
		,m_TabLableAutoFill(false)
		,m_ActiveTextShadow(true)
		,m_patch_flag_dont_fireEvent(false)
	{
		//m_Text = "new Tab Window";
		m_Size = Vector2(100,150);
	}
	Tabpad::~Tabpad()
	{

	}

	PDE_ATTRIBUTE_SETTER(Tabpad, SelectedPage, sharedc_ptr(Control))
	{
		if(m_SelectedPage == value)
			return;

		if(value && value->GetParent() != ptr_static_cast<Control>(this))
			return;

		if(m_SelectedPage)
			m_SelectedPage->SetVisible(false);

		if(value)
			value->SetVisible(true);

		Gui::TabChangedEventArgs e;
		e.OldValue = m_SelectedPage;
		e.NewValue = value;
		e.byUserOp = false;

		m_SelectedPage = value;

		OnSelectedPageChanged(e);
		Invalid();
	}
	PDE_ATTRIBUTE_GETTER(Tabpad, SelectedPage, sharedc_ptr(Control))
	{
		return m_SelectedPage;
	}
	PDE_ATTRIBUTE_GETTER(Tabpad, Index, int)
	{
		return m_Index;
	}
	PDE_ATTRIBUTE_SETTER(Tabpad, Index, int)
	{
		SelectPageByIndex(value);
	}

	PDE_ATTRIBUTE_SETTER(Tabpad, TabDock, Gui::Control::DockKind)
	{
		if(m_tabDock == value)
			return;

		m_tabDock = value;
		tabLableLocationAimOffset = 0.f;
		reCalculateTabHeadLength();
		reCalculateAllSonsPosition();
		reCalculateOffset(m_Index);
		Invalid();
	}
	PDE_ATTRIBUTE_GETTER(Tabpad, TabDock, Gui::Control::DockKind)
	{
		return m_tabDock;
	}
	PDE_ATTRIBUTE_SETTER(Tabpad, TabSize, Core::Vector2)
	{
		tabLableWidth = abs(value.x);
		tabLableHeight = abs(value.y);
		tabLableLocationAimOffset = 0.f;
		reCalculateTabHeadLength();
		reCalculateOffset(m_Index);
		reCalculateAllSonsPosition();
		Invalid();
	}
	PDE_ATTRIBUTE_GETTER(Tabpad, TabSize, Core::Vector2)
	{
		Core::Vector2 o(0.f, 0.f);
		o.x = tabLableWidth;
		o.y = tabLableHeight;
		return o;
	}

	PDE_ATTRIBUTE_SETTER(Tabpad, TabGap, float)
	{
		m_tabGap = abs(value);
		tabLableLocationAimOffset = 0.f;

		reCalculateOffset(m_Index);
		Invalid();
	}
	PDE_ATTRIBUTE_GETTER(Tabpad, TabGap, float)
	{
		return m_tabGap;
	}

	PDE_ATTRIBUTE_GETTER(Tabpad, TabPadding, Core::Vector4)
	{
		return m_TabPadding;
	}
	PDE_ATTRIBUTE_SETTER(Tabpad, TabPadding, Core::Vector4)
	{
		m_TabPadding = value;
		reCalculateTabHeadLength();
		reCalculateOffset(m_Index);
		reCalculateAllSonsPosition();
		Invalid();
	}

	PDE_ATTRIBUTE_GETTER(Tabpad, TabTextAlign, Client::Unit::Align)
	{
		return m_TabTextAlign;
	}
	PDE_ATTRIBUTE_SETTER(Tabpad, TabTextAlign, Client::Unit::Align)
	{
		m_TabTextAlign = value;
		Invalid();
	}

	PDE_ATTRIBUTE_GETTER(Tabpad, TabLabelPadding, Core::Vector4)
	{
		return m_TabLabelPadding;
	}
	PDE_ATTRIBUTE_SETTER(Tabpad, TabLabelPadding, Core::Vector4)
	{
		m_TabLabelPadding = value;
		Invalid();
	}

	PDE_ATTRIBUTE_GETTER(Tabpad, TabLableAutoSize, bool)
	{
		return m_TabLableAutoSize;
	}
	PDE_ATTRIBUTE_SETTER(Tabpad, TabLableAutoSize, bool)
	{
		m_TabLableAutoSize = value;
		tabLableLocationAimOffset = 0.f;
		if(m_TabLableAutoFill && m_TabLableAutoSize)
			m_TabLableAutoFill = false;

		if(m_tabDock == kDockTop || m_tabDock == kDockBottom)
			Invalid();
	}


	PDE_ATTRIBUTE_GETTER(Tabpad, TabLableAutoFill, bool)
	{
		return m_TabLableAutoFill;
	}
	PDE_ATTRIBUTE_SETTER(Tabpad, TabLableAutoFill, bool)
	{
		m_TabLableAutoFill = value;
		tabLableLocationAimOffset = 0.f;
		if(m_TabLableAutoFill && m_TabLableAutoSize)
			m_TabLableAutoSize = false;

		if(m_tabDock == kDockTop || m_tabDock == kDockBottom)
			Invalid();
	}

	PDE_ATTRIBUTE_GETTER(Tabpad, ActiveTextShadow, bool)
	{
		return m_ActiveTextShadow;
	}
	PDE_ATTRIBUTE_SETTER(Tabpad, ActiveTextShadow, bool)
	{
		if(m_ActiveTextShadow!=value)
		{
			m_ActiveTextShadow = value;
			Invalid();
		}
	}

	///update offset
	void Tabpad::OnFrameUpdate(EventArgs & e)
	{
		Control::OnFrameUpdate(e);
		float frameTime = Task::GetFrameTime();
		float old_tabLableLocationOffset = tabLableLocationOffset;
		tabLableLocationOffset = tabLableLocationAimOffset + Pow(0.001f, frameTime) * (tabLableLocationOffset - tabLableLocationAimOffset);

		if ((int)old_tabLableLocationOffset != (int)tabLableLocationOffset)
		{
			InvalidRect(GetTabHeadRect());
		}
		//Mouse over effect
		bool NeedUpdate = false;
		for(tempc_ptr(Control) son = GetFirstChild(); son; son = son->GetNext())
		{
			if(son == m_HoverPage)
			{
				if(son->GetHoverPower()<0.99f)
				{
					son->IncreaseHoverPower();
					NeedUpdate = true;
				}
			}
			else
			{
				if(son->GetHoverPower()>0.01f)
				{
					son->DecreaseHoverPower();
					NeedUpdate = true;
				}
			}
		}
		if(NeedUpdate)
			InvalidRect(GetTabHeadRect());
	}

	void Tabpad::OnDestroy()
	{
		m_patch_flag_dont_fireEvent = true;
		Control::OnDestroy();
	}

	/// fire event
	void Tabpad::OnSelectedPageChanged(TabChangedEventArgs & e)
	{
		int tempint = 0;
		for(Control* c = m_FirstChild; c; c = c->GetNext())
		{
			if(ptr_static_cast<Control>(c) == e.NewValue)
				break;
			tempint ++;
		}
		if(e.NewValue != NULL)
		{
			m_Index = tempint;
			reCalculateOffset(tempint);
		}
		if(!m_patch_flag_dont_fireEvent)
			EventSelectedPageChanged.Fire(ptr_static_cast<Tabpad>(this), e);
	}

	///click, hover, drag, ctrl(+shift)+tab
	void Tabpad::OnInputEvent( Client::InputEventArgs &e )
	{
		if(e.IsMouseEvent())
		{
			sharedc_ptr(Control) oldHover = m_HoverPage;

			Core::Vector2 localPos = ScreenToClient(e.CursorPosition);
			switch (e.Type)
			{
			case InputEventArgs::kMouseDown:
				if (e.Code == MC_MIDDLE_BUTTON)
				{
					SetCapture(true);
					e.Handled = true;
				}
				else
				{
					if (ClickOrHoverEffect(true, localPos))
						e.Handled = true;
				}
				break;
			case InputEventArgs::kMouseMove:
				if (ClickOrHoverEffect(false, localPos))
					e.Handled = true;

				//temp disabled, offset calculation not correct
// 				if(e.MiddleButtonDown)
// 					DragTabsEffect(e.CursorMove);
				break;

			case InputEventArgs::kMouseUp:
				if (e.Code == MC_MIDDLE_BUTTON)
				{
					SetCapture(false);
					e.Handled = true;
				}
				if (e.Code == MC_RIGHT_BUTTON)
				{
					OnTabRightClick(e);
					e.Handled = true;
				}
				break;

			case InputEventArgs::kMouseEnter:
				{
					//Tabpad doesn't pop hint of itself. It pops tab's hint instead
					e.Handled = true;
				}
				break;
			case InputEventArgs::kMouseLeave:
				if(m_HoverPage)
				{
					bool needToPaintAgain = m_HoverPage!=m_SelectedPage;
					m_HoverPage = NullPtr;
					if(needToPaintAgain)
						InvalidRect(GetTabHeadRect());
				}
				if(s_ToolTip)
					s_ToolTip->Close();
				break;
			}

			if (oldHover != m_HoverPage)
				InvalidRect(GetTabHeadRect());
		}
		if(e.IsKeyEvent())
		{
			if(e.ControlKeyDown && e.Type == InputEventArgs::kKeyDown && e.Code == KC_TAB)
			{
				/// if pressed "Ctrl+tab"
				if(!e.ShiftKeyDown)
				{
					if(m_SelectedPage && m_SelectedPage->GetNext())
						SelectPage(ptr_static_cast<Control>(m_SelectedPage->GetNext()), true);
					else
						SelectPage(ptr_static_cast<Control>(m_FirstChild), true);
				}
				/// if pressed "Ctrl+shift+tab"
				else
				{
					if(m_SelectedPage && m_SelectedPage->GetPrevious())
						SelectPage(ptr_static_cast<Control>(m_SelectedPage->GetPrevious()), true);
					else
						SelectPage(ptr_static_cast<Control>(m_LastChild), true);
				}
			}
		}

		if (!e.Handled)
			Control::OnInputEvent(e);
	}

	void Tabpad::OnPaint(PaintEventArgs & e)
	{
		Control::OnPaint(e);
		//PaintFrameHead(e);
		PaintTabLables(e);
		PaintTabBody(e);
	}
	///if add a son(select it or invisible it),else if removed current SelectePage, select another son if possible
	void Tabpad::OnChildrenChanged(ChildrenChangedEventArgs & e)
	{
		Control::OnChildrenChanged(e);
		if(!e.removed)//if add e.Control
		{
			e.Control->SetLocation(GetTabClientPosi());
			e.Control->SetSize(GetTabClientSize());

			if(ptr_static_cast<Control>(m_FirstChild) == e.Control)
				SelectPage(e.Control);
			else
				e.Control->SetVisible(false);
			Invalid();
		}
		else if(e.Control == m_SelectedPage)
		{
			if (m_SelectedPage->GetPrevious())
				SelectPage(m_SelectedPage->GetPrevious());
			else
				SelectPage(ptr_static_cast<Control>(m_FirstChild));
		}
		m_sonCount = GetSonCount();
	}
	void Tabpad::OnSizeChanged(ResizeEventArgs & e)
	{
		Control::OnSizeChanged(e);
		reCalculateAllSonsPosition();
	}


	///if(flag) clicked effect(select + aimOffset) ,else hover effect
	bool Tabpad::ClickOrHoverEffect(bool flag, Core::Vector2 localPos)
	{
		Core::Rectangle headRect = GetTabHeadRect();
		int temindex = 0;
		for(Control* son = m_FirstChild; son; son = son->GetNext())
		{
			Core::Rectangle lableRect = GetTabLableRect(temindex);
			lableRect.IntersectWith(headRect);
			if(son->GetEnable() && lableRect.IsPointInside(localPos))
			{
				if(flag)//click
					SelectPage(ptr_static_cast<Control>(son), true);
				else
					HoveredPage(ptr_static_cast<Control>(son), temindex);

				return true;
			}
			temindex++;
		}
		HoveredPage(NullPtr, -1);
		return false;
	}
	///when drag tabs, set AimOffset+=movedX(Y), and Offset follows AimOffset
	void Tabpad::DragTabsEffect(Core::Vector2 moved)
	{
		float temValue = Floor(tabLableLocationOffset);
		float temMinValue = 0.f;
		switch(m_tabDock)
		{
		case kDockLeft:
		case kDockRight:
			temValue += moved.y;
			temMinValue = Min(GetTabHeadRect().GetExtent().y - m_sonCount * tabLableHeight, 0.f);
			break;
		default://top,bottom
			temValue += moved.x;
			if(m_TabLableAutoSize)
				temMinValue = Min(GetTabHeadRect().GetExtent().x - SumStringLength(m_sonCount), 0.f);
			else
				temMinValue = Min(GetTabHeadRect().GetExtent().x - m_sonCount * tabLableWidth, 0.f);
			break;
		}
		tabLableLocationAimOffset = Clamp(temValue, temMinValue, 0.f);
		tabLableLocationOffset = tabLableLocationAimOffset;
		InvalidRect(GetTabHeadRect());
	}
	///set new selectPage visible,old one invisible.(and send a event in ATTRIBUTE_SETTER)
	void Tabpad::SelectPage(sharedc_ptr(Control) son, bool byMouse /*=false*/)
	{
		if(m_SelectedPage == son)
			return;

		if(m_SelectedPage)
			m_SelectedPage->SetVisible(false);
		if(son)
			son->SetVisible(true);//OnVisibleChanged will call invalid() and m_Parent->DirtyLayout()

		Gui::TabChangedEventArgs e;
		e.OldValue = m_SelectedPage;
		e.NewValue = son;
		e.byUserOp = byMouse;

		m_SelectedPage = son;

		OnSelectedPageChanged(e);

		tempc_ptr(Tabpage) page = ptr_dynamic_cast<Tabpage>(m_SelectedPage);

		if (page)
		{
			page->OnSelectChanged(e);
		}
	}

	void Tabpad::SelectFirstPage()
	{
		SelectPage(ptr_static_cast<Control>(m_FirstChild));
	}

	void Tabpad::SelectLastPage()
	{
		SelectPage(ptr_static_cast<Control>(m_LastChild));
	}


	int Tabpad::GetSonIndex( tempc_ptr(Control) son )
	{
		int temindex = 0;
		int resultIndex = -1;
		for(tempc_ptr(Control) child = GetFirstChild(); child; child = child->GetNext())
		{
			if(child==son)
			{
				resultIndex = temindex;
				break;
			}
			temindex++;
		}
		return resultIndex;
	}

	///set m_HoverPage=son simply
	void Tabpad::HoveredPage(sharedc_ptr(Control) son, int index)
	{
		bool HoverPageChanged = (m_HoverPage != son);//mouse still hover the same tabLable

		bool NoNeedToPaintAgain = (m_HoverPage == son);//mouse still hover the same tabLable
		NoNeedToPaintAgain = NoNeedToPaintAgain || (!m_HoverPage && m_SelectedPage == son);//another case: mouse enter SelectPage when HoverPage==null
		if(!NoNeedToPaintAgain)
		{
			if(m_HoverPage)
			{
				//Close old tab hint
				if(s_ToolTip)
					s_ToolTip->Close();
			}
			//Invalid();
			InvalidRect(GetTabHeadRect());
		}
		m_HoverPage = son;


		if(HoverPageChanged && son && index>=0 && son->GetTextEllipsis())
		{
			//Same as control::OnMouseEnter()
			if (!s_ToolTip) {
				s_ToolTip = ptr_new ToolTip;
			}

			Core::Rectangle LabRect = GetTabLableRect(index);
			LabRect.Shrink(GetTabLabelPadding());
			Vector2 origin = ClientToGlobalScreen(LabRect.Min);
			LabRect = Core::Rectangle::LeftTop(origin, LabRect.GetExtent());
			s_ToolTip->ShowStart(ptr_static_cast<Control>(gGame->guiSys), LabRect, son->GetText());
		}
	}

	///paint

	void Tabpad::PaintTabLables(PaintEventArgs & e)
	{
		//Vector2 tabLableLocation = GetFirstTabLocation();
		int temindex = 0;
		Core::Rectangle oldScissor = e.render->GetScissorRect();
		Core::Rectangle tempScissor = oldScissor;
		e.render->AddScissorRectWithWorldMatrix(GetTabHeadRect());

		tempc_ptr(TabpadSkin) skin = ptr_dynamic_cast<TabpadSkin>(GetSkin());
		if(skin)
		{
			Core::Rectangle headRect = GetTabHeadRect();
			int sonCount = GetSonCount();
			if(m_tabDock==kDockLeft || m_tabDock==kDockRight)
			{
				headRect.Max.y=headRect.Min.y + sonCount*tabLableHeight + (sonCount-1)*m_tabGap + tabLableLocationOffset;
			}
			else
			{
				headRect.Max.x=headRect.Min.x + sonCount*tabLableWidth + (sonCount-1)*m_tabGap + tabLableLocationOffset;
			}
			if(sonCount>0)
			{
				Skin::DrawImage(e.render, skin->GetTabBgImage(), headRect);
			}

			for(tempc_ptr(Control) son = GetFirstChild(); son; son = son->GetNext())
			{
				tempc_ptr(Tabpage) sonPage = ptr_dynamic_cast<Tabpage>(son);

				if(e.Enable && son->GetEnable())
				{
					bool bHighLight = false;
					if(son == m_SelectedPage)
					{
						Skin::DrawImage(e.render, skin->GetTabActiveImage(), GetTabLableRect(temindex));
						bHighLight = true;
					}
					else
					{
						Skin::DrawImage(e.render, skin->GetTabNormalImage(), GetTabLableRect(temindex));
						Skin::DrawImage(e.render, skin->GetTabHoverImage(), GetTabLableRect(temindex), Core::ARGB((U8)(son->GetHoverPower()*255), 255, 255, 255));
						if(son == m_HoverPage)
							bHighLight = true;
					}

					if(sonPage)
					{
						Core::String renderText = sonPage->GetTextEllipsis()?sonPage->GetEllipsisStr():sonPage->GetText();
						if(son == m_SelectedPage)
						{
// 							Skin::DrawIconText(e.render, sonPage->GetActiveIcon(), GetFont(), son->GetText()
// 								, GetIntRect(GetTabLableRect(temindex)).Shrink(GetTabLabelPadding()), GetTabTextAlign(), ARGB(255,255,255,255)
// 								, bHighLight? GetHighlightTextColor():GetTextColor(), true, sonPage->GetActiveIcon()?false:true );
							if(m_ActiveTextShadow)
							{
								e.render->DrawStringShadow(GetFont(), bHighLight? GetHighlightTextColor():GetTextColor()
									, GetTextShadowColor(), ARGB(0,0,0,0)
									, GetIntRect(GetTabLableRect(temindex)).Shrink(GetTabLabelPadding()), renderText, GetTabTextAlign());
							}
							else
							{
								e.render->DrawString(GetFont(), bHighLight? GetHighlightTextColor():GetTextColor()
									, ARGB(0,0,0,0), GetIntRect(GetTabLableRect(temindex)).Shrink(GetTabLabelPadding()), renderText, GetTabTextAlign());
							}
						}
						else
						{
// 							Skin::DrawIconText(e.render, sonPage->GetNormalIcon(), GetFont(), son->GetText()
// 								, GetIntRect(GetTabLableRect(temindex)).Shrink(GetTabLabelPadding()), GetTabTextAlign(), ARGB(255,255,255,255)
// 								, bHighLight? GetHighlightTextColor():GetTextColor(), true, sonPage->GetNormalIcon()?false:true );
							e.render->DrawString(GetFont(), bHighLight? GetHighlightTextColor():GetTextColor()
								, ARGB(0,0,0,0), GetIntRect(GetTabLableRect(temindex)).Shrink(GetTabLabelPadding()), renderText, GetTabTextAlign());
						}
					}
					else
					{
						if(son == m_SelectedPage)
						{
							if(m_ActiveTextShadow)
							{
								e.render->DrawStringShadow(GetFont(), bHighLight? GetHighlightTextColor():GetTextColor()
									, GetTextShadowColor(), ARGB(0,0,0,0)
									, GetIntRect(GetTabLableRect(temindex)).Shrink(GetTabLabelPadding()), son->GetText(), GetTabTextAlign());
							}
							else
							{
								e.render->DrawString(GetFont(), bHighLight? GetHighlightTextColor():GetTextColor()
									, ARGB(0,0,0,0), GetIntRect(GetTabLableRect(temindex)).Shrink(GetTabLabelPadding()), son->GetText(), GetTabTextAlign());
							}
						}
						else
						{
							e.render->DrawString(GetFont(), bHighLight? GetHighlightTextColor():GetTextColor()
								, ARGB(0,0,0,0), GetIntRect(GetTabLableRect(temindex)).Shrink(GetTabLabelPadding()), son->GetText(), GetTabTextAlign());
						}
					}
				}
				else
				{
					if(son == m_SelectedPage)
					{
						Skin::DrawImage(e.render, skin->GetTabActiveDisabledImage(), GetTabLableRect(temindex));
					}
					else
					{
						Skin::DrawImage(e.render, skin->GetTabNormalDisabledImage(), GetTabLableRect(temindex));
					}
					e.render->DrawString(GetFont(), GetDisabledTextColor(), Core::ARGB(0,255,255,255), GetIntRect(GetTabLableRect(temindex)).Shrink(GetTabLabelPadding()), son->GetText(), GetTabTextAlign());
				}
				temindex++;
			}
		}
		else
		{
			for(tempc_ptr(Control) son = GetFirstChild(); son; son = son->GetNext())
			{
				if(son == m_SelectedPage)
					e.render->DrawRectangle(GetTabLableRect(temindex), Core::Rectangle(0, 0, 1, 1), Core::ARGB(255,100,100,100));
				else if(son == m_HoverPage)
					e.render->DrawRectangle(GetTabLableRect(temindex), Core::Rectangle(0, 0, 1, 1), Core::ARGB(255,123,123,123));
				else
					e.render->DrawRectangle(GetTabLableRect(temindex), Core::Rectangle(0, 0, 1, 1), Core::ARGB(255,165,165,165));


				e.render->DrawString(GetFont(), Core::ARGB(255,0,0,0), Core::ARGB(0,255,255,255), GetIntRect(GetTabLableRect(temindex)).Shrink(GetTabLabelPadding()), son->GetText(), Unit::kAlignCenterMiddle);

				temindex++;
			}
		}
		e.render->SetScissorRect(oldScissor);
	}
	void Tabpad::PaintTabBody(PaintEventArgs & e)
	{

	}

	///get sons Count
	int Tabpad::GetSonCount()
	{
		int o = 0;
		for(Control* son = m_FirstChild; son; son = son->GetNext())
			o++;
		return o;
	}

	///when size or borderSize changed, need to reCalculate son's location
	void Tabpad::reCalculateAllSonsPosition()
	{
		for(Control* son = m_FirstChild; son; son = son->GetNext())
		{
			son->SetLocation(GetTabClientPosi());
			son->SetSize(GetTabClientSize());
		}
	}

	///reCalculate offset
	void Tabpad::reCalculateOffset(int tempint)
	{
		if(tempint < 0)
			return;

		float L_ToShowPreLableDummy = m_ShowNextPreLableLength;
		float L_ToShowNextLableDummy = m_ShowNextPreLableLength;
		if(m_SelectedPage == ptr_static_cast<Control>(m_FirstChild))
			L_ToShowPreLableDummy = 0.f;
		if(m_SelectedPage == ptr_static_cast<Control>(m_LastChild))
			L_ToShowNextLableDummy = 0.f;

		Core::Rectangle SelectLableRect = GetTabLableRect(tempint);
		Core::Rectangle HeadRect = GetTabHeadRect();

		switch(m_tabDock)
		{
		case kDockTop:
		case kDockBottom:
		case kDockTopCenter:
			if(tabLableWidth < HeadRect.GetExtent().x)
			{
				//aimOffset move towards right
				if(SelectLableRect.Min.x < HeadRect.Min.x && SelectLableRect.Max.x > HeadRect.Min.x)
					tabLableLocationAimOffset += HeadRect.Min.x - SelectLableRect.Min.x + L_ToShowPreLableDummy;
				//aimOffset move towards left
				if(SelectLableRect.Min.x < HeadRect.Max.x && SelectLableRect.Max.x > HeadRect.Max.x)
					tabLableLocationAimOffset -= SelectLableRect.Max.x - HeadRect.Max.x + L_ToShowNextLableDummy;//to show part of next_control
			}
			break;
		case kDockLeft:
		case kDockRight:
			if(tabLableHeight < HeadRect.GetExtent().y)
			{
				//aimOffset move towards down
				if(SelectLableRect.Min.y < HeadRect.Min.y && SelectLableRect.Max.y > HeadRect.Min.y)
					tabLableLocationAimOffset += HeadRect.Min.y - SelectLableRect.Min.y + L_ToShowPreLableDummy;
				//aimOffset move towards up
				if(SelectLableRect.Min.y < HeadRect.Max.y && SelectLableRect.Max.y > HeadRect.Max.y)
					tabLableLocationAimOffset -= SelectLableRect.Max.y - HeadRect.Max.y + L_ToShowNextLableDummy;//to show part of next_control			
			}
			break;
		default:break;
		}
	}
	int Tabpad::CalculateStringWidth(String str)
	{
		Core::Rectangle tempRect = Core::Rectangle(0, 0, 0, 0);
		Vector2 o = GetFont()->MeasureString(tempRect, str, -1, Unit::kAlignCenterMiddle).GetExtent();
		return (int)o.x;
	}

	void Tabpad::reCalculateTabHeadLength()
	{
		switch(m_tabDock)
		{
		case kDockLeft:
		case kDockRight:
			m_TabHeadLength = m_TabPadding.x + m_TabPadding.z + tabLableWidth;
			m_TabHeadHeight = m_TabPadding.y + m_TabPadding.w + tabLableHeight;
			break;
		default:
			m_TabHeadLength = m_TabPadding.y + m_TabPadding.w + tabLableHeight;
			m_TabHeadHeight = m_TabPadding.x + m_TabPadding.z + tabLableWidth;
			break;
		}
	}

	///sum of Text length (before index i)
	int Tabpad::SumStringLength(int i)
	{
		int tempindex = 0;
		int sum = 0;
		for(Control* son = m_FirstChild; son,tempindex < i; son = son->GetNext())
		{
			sum += CalculateStringWidth(son->GetText()) + 12;
			tempindex++;
		}
		return sum;
	}

	/// input a floatRect, return a intRect
	Core::Rectangle Tabpad::GetIntRect(Core::Rectangle fRect)
	{
		Core::Rectangle iRect = Core::Rectangle(0, 0, 0, 0);
		iRect.Min = Vector2(Floor(fRect.Min.x), Floor(fRect.Min.y));
		iRect.Max = Vector2(Floor(fRect.Max.x), Floor(fRect.Max.y));
		return iRect;
	}

	///return LableRect[i]
	Core::Rectangle Tabpad::GetTabLableRect(int i)
	{
		Core::Rectangle o;
		Core::Rectangle headRect = GetTabHeadRect();
		float tabLableLocationOffset = Floor(this->tabLableLocationOffset);

		switch (m_tabDock)
		{
		case kDockLeft:
		case kDockRight:
			o.Min = Vector2(headRect.Min.x, headRect.Min.y + i * tabLableHeight + i*m_tabGap + tabLableLocationOffset);
			o.Max = Vector2(headRect.Max.x, headRect.Min.y + (i + 1) * tabLableHeight + i*m_tabGap + tabLableLocationOffset);
			break;
		default://top bottom
			if(m_TabLableAutoSize)
			{
				o.Min = Vector2(headRect.Min.x + SumStringLength(i) + i*m_tabGap + tabLableLocationOffset, headRect.Min.y);
				o.Max = Vector2(headRect.Min.x + SumStringLength(i + 1) + i*m_tabGap + tabLableLocationOffset, headRect.Max.y);
			}
			else if(m_TabLableAutoFill)
			{
				o.Min = Vector2(headRect.Min.x + i * (headRect.GetExtent().x-m_tabGap*(GetSonCount()-1)) / GetSonCount() + i*m_tabGap + tabLableLocationOffset, headRect.Min.y);
				o.Max = Vector2(headRect.Min.x + (i+1) * (headRect.GetExtent().x-m_tabGap*(GetSonCount()-1)) / GetSonCount() + i*m_tabGap + tabLableLocationOffset, headRect.Max.y);
			}
			else
			{
				o.Min = Vector2(headRect.Min.x + i * tabLableWidth + i*m_tabGap + tabLableLocationOffset, headRect.Min.y);
				o.Max = Vector2(headRect.Min.x + (i + 1) * tabLableWidth + i*m_tabGap + tabLableLocationOffset, headRect.Max.y);
			}

			break;
		}
		return o;
	}
	///return head.Shrink(tabPadding)
	Core::Rectangle Tabpad::GetTabHeadRect()
	{
		Core::Rectangle o;
		switch(m_tabDock)
		{
		case kDockLeft:
			o = Core::Rectangle(Vector2(0.f, 0.f), Vector2(m_TabHeadLength, GetSize().y));
			break;
		case kDockTop:
			o = Core::Rectangle(Vector2(0.f, 0.f), Vector2(GetSize().x, m_TabHeadLength));
			break;
		case kDockRight:
			o = Core::Rectangle(Vector2(GetSize().x - m_TabHeadLength, 0.f), Vector2(GetSize().x, GetSize().y));
			break;
		case kDockBottom:
			o = Core::Rectangle(Vector2(0.f, GetSize().y - m_TabHeadLength), Vector2(GetSize().x, GetSize().y));
			break;
		case kDockTopCenter:
			o = Core::Rectangle(Vector2((GetSize().x - m_TabHeadHeight * GetSonCount()) / 2.0f, 0.f), Vector2((GetSize().x - m_TabHeadHeight * GetSonCount()) / 2.0f + m_TabHeadHeight * GetSonCount(), m_TabHeadLength));
			break;
		default:
			o = Core::Rectangle(Vector2(0.f, 0.f), Vector2(0.f, 0.f));
			break;
		}
		o.Shrink(m_TabPadding);
		return o;
	}
	Vector2 Tabpad::GetTabClientPosi()
	{
		switch(m_tabDock)
		{
		case kDockLeft:
			return Core::Vector2(m_TabHeadLength, 0.f);
			break;
		case kDockRight:
			return Core::Vector2(0.f, 0.f);
			break;
		case kDockBottom:
			return Core::Vector2(0.f, 0.f);
			break;
		default://top
			return Core::Vector2(0.f, m_TabHeadLength);
			break;
		}
	}
	Vector2 Tabpad::GetTabClientSize()
	{
		switch(m_tabDock)
		{
		case kDockLeft:
		case kDockRight:
			return Core::Vector2(GetClientRect().GetExtent().x - m_TabHeadLength, GetClientRect().GetExtent().y);
			break;
		default://top Bottom
			return Core::Vector2(GetClientRect().GetExtent().x, GetClientRect().GetExtent().y - m_TabHeadLength);
			break;
		}
	}

	Vector2 Tabpad::GetTabLableScreentPos(int index )
	{
		Core::Rectangle rect = GetTabLableRect(index);
		return ClientToScreen(rect.Min);
	}
	void Tabpad::OnTabRightClick( InputEventArgs & e )
	{
		Core::Rectangle headRect = GetTabHeadRect();
		int temindex = 0;
		Vector2 localPos = ScreenToClient(e.CursorPosition);
		if(!headRect.IsPointInside(localPos))
			return;
		bool bInAnyTab = false;
		for(Control* son = m_FirstChild; son; son = son->GetNext())
		{
			Core::Rectangle lableRect = GetTabLableRect(temindex);
			lableRect.IntersectWith(headRect);
			if(son->GetEnable() && lableRect.IsPointInside(localPos))
			{
				bInAnyTab = true;
				break;
			}
			temindex++;
		}
		if(bInAnyTab)
			EventRightClick.Fire(ptr_static_cast<Tabpad>(this), e);
	}

	void Tabpad::SelectPageByIndex( int index, bool byMouse /*= false*/ )
	{
		if(index>=0 && index<GetSonCount())
		{
			for(Control* son = m_FirstChild; son; son = son->GetNext())
			{
				if(index<=0)
				{
					SelectPage(ptr_static_cast<Control>(son), false);
					break;
				}
				index--;
			}
		}
	}
}

