namespace Gui
{
	class CheckBoxSkin : public ControlSkin
	{
	public:
		CheckBoxSkin()
		{}

	public:
		INLINE_PDE_ATTRIBUTE_RW(OnImage,		tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(OffImage,		tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(OnHoverImage,	tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(OffHoverImage,	tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(OnDisabledImage,	tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(OffDisabledImage,		tempc_ptr(Image));

	private:
		sharedc_ptr(Image)		m_OnImage;
		sharedc_ptr(Image)		m_OffImage;
		sharedc_ptr(Image)		m_OnHoverImage;
		sharedc_ptr(Image)		m_OffHoverImage;
		sharedc_ptr(Image)		m_OnDisabledImage;
		sharedc_ptr(Image)		m_OffDisabledImage;
	};
}

namespace Gui
{
	class CheckBox : public Control
	{
		DECLARE_PDE_OBJECT(CheckBox,Control)
	public:
		enum CheckPosition
		{
			kCheckLeft,
			kCheckRight,
		};
	public:
		DECLARE_PDE_EVENT(EventCheckChanged, Core::EventArgs);
		DECLARE_PDE_EVENT(EventCheckClickChanged, Core::EventArgs);
	public:
		DECLARE_PDE_ATTRIBUTE_RW (Check,			bool);
		DECLARE_PDE_ATTRIBUTE_RW (CheckBoxSize,		Core::Vector2);
		DECLARE_PDE_ATTRIBUTE_RW (CheckPosition,	CheckPosition);
		//Set Check without event triggered
		DECLARE_PDE_ATTRIBUTE_W  (MuteCheck,		bool);

	public:
		/// on input event
		virtual	void OnInputEvent(Client::InputEventArgs &e);

		/// on paint
		virtual void OnPaint(PaintEventArgs & e);

		/// on check changed
		virtual void OnCheckChanged(EventArgs & e);

		/// on check click changed
		virtual void OnCheckClickChanged(EventArgs & e);

	public:
		// constructor.
		CheckBox();

		// destructor.
		~CheckBox();
	private:
		bool			m_Check:1;
		CheckPosition	m_CheckPosition;
		Core::Vector2	m_CheckBoxSize;
	};
}