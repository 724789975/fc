namespace Gui
{
	/// base class of ui elements
	class  ImageBrowser : public Control
	{
		DECLARE_PDE_OBJECT(ImageBrowser, Control)
	public:
		ImageBrowser();
		~ImageBrowser();
		
		void Init();

	public:
		DECLARE_PDE_ATTRIBUTE_RW	(DisplayRowAndCol,	Core::Vector2);
		DECLARE_PDE_ATTRIBUTE_RW	(NumSkip,	U32);
		DECLARE_PDE_ATTRIBUTE_R		(LeftBtn,	sharedc_ptr(Button));
		DECLARE_PDE_ATTRIBUTE_R		(RightBtn,	sharedc_ptr(Button));
		DECLARE_PDE_ATTRIBUTE_RW	(LButtonStyle, const Core::String&);
		DECLARE_PDE_ATTRIBUTE_RW	(RButtonStyle, const Core::String&);
		DECLARE_PDE_ATTRIBUTE_RW	(PictureStyle, const Core::String&);
		DECLARE_PDE_ATTRIBUTE_RW	(Loading,	bool);
		DECLARE_PDE_ATTRIBUTE_RW	(LoadingImage, tempc_ptr(AnimatedImage));
		DECLARE_PDE_ATTRIBUTE_RW	(PWidth,F32);
		DECLARE_PDE_ATTRIBUTE_RW	(PHeight,F32);

	public:

		sharedc_ptr(ItemPicture) GetDisplayPicture(U32 row, U32 col);

		void LeftBtnClick();
		void RightBtnClick();
		void AllPictureHL(bool b);
		void AllPictureClicked(bool b);

	public:
		virtual void OnCreate();
		
		virtual void OnLayout(EventArgs & e);

		virtual void OnFrameUpdate(EventArgs & e);

		/// on paint
		virtual void OnPaint(PaintEventArgs & e);

		/// on input event
		virtual void OnInputEvent(InputEventArgs & e);

	private:
		Core::Array<sharedc_ptr(Core::Array<sharedc_ptr(ItemPicture)>)>   m_Row;
		U32                                                             m_NumSkip;//��ʱ����,Ӧ���ڰ��շ�������˷�ҳ���߼�ȥ��,UI��������ʽ�ϵķ�ҳ
		sharedc_ptr(Button)                                              m_Left,m_Right;
		U32												                m_display_row,m_display_col;
		Core::String									                m_PictureStyle;		
		bool															m_IsLoading;
		bool															m_StartLoading;
		sharedc_ptr(AnimatedImage)										m_LoadingImage;
		F32																m_PWidth;
		F32																m_PHeight;
	};
}
