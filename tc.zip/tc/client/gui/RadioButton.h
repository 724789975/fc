namespace Gui
{
	class RadioButtonSkin : public ControlSkin
	{
	public:
		RadioButtonSkin()
		{}

	public:
		INLINE_PDE_ATTRIBUTE_RW(OnImage,		tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(OffImage,		tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(OnHoverImage,	tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(OffHoverImage,	tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(OnDisabledImage,	tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(OffDisabledImage,		tempc_ptr(Image));

	private:
		sharedc_ptr(Image)		m_OnImage;
		sharedc_ptr(Image)		m_OffImage;
		sharedc_ptr(Image)		m_OnHoverImage;
		sharedc_ptr(Image)		m_OffHoverImage;
		sharedc_ptr(Image)		m_OnDisabledImage;
		sharedc_ptr(Image)		m_OffDisabledImage;
	};

}


namespace Gui
{
	class RadioButton : public Control
	{
		DECLARE_PDE_OBJECT(RadioButton,Control)

	public:
		DECLARE_PDE_EVENT(EventClick, Core::EventArgs);
		DECLARE_PDE_EVENT(EventVisibleChange, Core::EventArgs);

	public:
		DECLARE_PDE_ATTRIBUTE_RW (ID,			int);
		DECLARE_PDE_ATTRIBUTE_RW (Check,		bool);
		DECLARE_PDE_ATTRIBUTE_RW (CheckPosition,	CheckBox::CheckPosition);

	public:
		/// on input event
		virtual	void OnInputEvent(Client::InputEventArgs &e);

		/// on paint
		virtual void OnPaint(PaintEventArgs & e);

		/// on check changed
		virtual void OnClick(EventArgs & e);

		virtual void OnVisibleChanged(EventArgs & e);

	public:
		// constructor.
		RadioButton();

		// destructor.
		~RadioButton();
	private:
		int				m_ID;
		bool			m_Check:1;
		CheckBox::CheckPosition	m_CheckPosition;
	};

	class RadioGroup : public FlowLayout
	{
		DECLARE_PDE_OBJECT(RadioGroup,Control)
	public:
		DECLARE_PDE_EVENT(EventRadioChanged, Core::EventArgs);

	public:
		DECLARE_PDE_ATTRIBUTE_RW (RadioCheckID,		int);
		DECLARE_PDE_ATTRIBUTE_R	 (RadioCheckText,	const Core::String &);



	public:
		// constructor.
		RadioGroup();

		// destructor.
		~RadioGroup();

		virtual void OnFrameUpdate(EventArgs & e);

		virtual void OnChildClick(by_ptr(void) sender,EventArgs & e);
		virtual void OnChildVisibleChange(by_ptr(void) sender, EventArgs& e);
		/// on check changed
		virtual void OnRadioCheckChanged(EventArgs & e);

		void ChangeRadioCheckID(int radioCheckID, bool triggerEvent);

		void DeleteTableAll();

	protected:
		int GetMinID();
		int GetVisibleCount();

	private:
		int						m_RadioCheckID;
		Core::HashSet<sharedc_ptr(RadioButton), int>	m_table;
	};
}