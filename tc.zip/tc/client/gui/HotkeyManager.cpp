#include "pch.h"

using namespace Core;
using namespace Client;
using namespace Gui;

#if 0
//--------------------------------------------------------------------------------------
// type info
//--------------------------------------------------------------------------------------
namespace Pde
{
	using namespace Lua;

	struct EdtUIHotkeyManagerExtension : public LuaClass
	{
		static inline const PdeTypeInfo * typeinfo() { return PdeTypeTraits<HotkeyManager>::Type(); }

		static int newindex(LuaState *L)
		{
			PdeClassPtr & ptr = ToClass(L, 1, typeinfo());
			HotkeyManager * obj = NULL;

			if (ptr)
				obj = PdeTypeTraits<HotkeyManager>::UnboxingPtr(ptr);

			if (obj)
			{
				static bool eventInfoInitialized = false;
				static PdeEventInfo eventInfo("EventHotkeyPressed", NULL);

				if (!eventInfoInitialized)
				{
					eventInfoInitialized = true;
					eventInfo.Declare((const PdeEvent<InputEventArgs> *)0);
				}

				const char* name = L->ToString(2);

				PdeEvent<InputEventArgs> & eventCallback = obj->Set(Hotkey::FromName(name));

				eventCallback.Subscribe(L, 3);
			}

			return 0;
		}

		// initialize table
		static void initialize_metatable(LuaState *L)
		{
			L->PushLightUserData((void*)typeinfo());
			L->SetField(-2, "type");
		}
	};

	const PdeTypeInfo * PdeTypeTraits<Hotkey>::Type()
	{
		static struct TypeTraits : public PdeStructInfo
		{
			DEFINE_PDE_TYPETRAITS_STRUCT(Hotkey, void)
			{
				ADD_PDE_FIELD(Code);
				ADD_PDE_FIELD(Control);
				ADD_PDE_FIELD(Alt);
				ADD_PDE_FIELD(Shift);
			}
		} type;

		return &type;
	}

	const PdeTypeInfo * PdeTypeTraits<HotkeyManager>::Type()
	{
		static struct TypeTraits : public PdeStructInfo
		{
			DEFINE_PDE_TYPETRAITS_STRUCT(HotkeyManager, void)
			{
			}

			bool Initialize()
			{
				LuaClass::Register<EdtUIHotkeyManagerExtension>(Lua::LuaState::FromThread());
				return true;
			}
		} type;

		return &type;
	}
}

//--------------------------------------------------------------------------------------
// Events
//--------------------------------------------------------------------------------------
namespace Pde
{
	void HotkeyManager::OnKeyEvent(by_ptr(void) sender, InputEventArgs & e)
	{
		if (e.IsKeyEvent())
		{
			if (e.Type == InputEventArgs::kKeyDown)
			{
				PdeEvent<InputEventArgs> * callback = Get(Hotkey(e.Code, e.ControlKeyDown, e.AltKeyDown, e.ShiftKeyDown));

				if (callback)
				{
					callback->Fire(sender, e);
				}
			}
		}
	}
}


//--------------------------------------------------------------------------------------
// Methods
//--------------------------------------------------------------------------------------
namespace Pde
{
	/// set hotkey
	PdeEvent<InputEventArgs> & HotkeyManager::Set(const Hotkey & hotkey)
	{
		// default handler
		PdeEvent<InputEventArgs> defaultHandler;

		// make sure there is an event
		m_HotkeySet.Add(hotkey, defaultHandler);

		return m_HotkeySet.Get(hotkey, defaultHandler);
	}

	/// get hotkey
	PdeEvent<InputEventArgs> * HotkeyManager::Get(const Hotkey & hotkey)
	{
		return m_HotkeySet.Get(hotkey);
	}

	/// remove
	void HotkeyManager::Remove(const Hotkey & hotkey)
	{
		m_HotkeySet.Remove(hotkey);
	}

	Hotkey Hotkey::FromName(const char * name)
	{
		Hotkey hotkey;

		if (name)
		{
			CStrBuf<256> temp;

			while (name[0])
			{
				temp.clear();

				while(name[0] && name[0] != '+')
				{
					temp.contract(name[0]);
					name++;
				}

				if (strcmp(temp, "CTRL") == 0)
				{
					hotkey.Control = true;
				}
				else if (strcmp(temp, "ALT") == 0)
				{
					hotkey.Alt = true;
				}
				else if (strcmp(temp, "SHIFT") == 0)
				{
					hotkey.Shift = true;
				}
				else
				{
					hotkey.Code = GUISystem->Input->ConvertKeyCode(temp);
				}

				if (name[0])
					name ++;
			}
		}

		return hotkey;
	}
}
#endif