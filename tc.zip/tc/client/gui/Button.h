
namespace Gui
{
	class Button: public Control
	{
		DECLARE_PDE_OBJECT(Button, Control);

	public:
		DECLARE_PDE_EVENT(EventMouseEnter, Client::InputEventArgs);
		DECLARE_PDE_EVENT(EventMouseLeave, Client::InputEventArgs);
		DECLARE_PDE_EVENT(EventClick, Client::InputEventArgs);
		DECLARE_PDE_EVENT(EventDoubleClick, Client::InputEventArgs);

		DECLARE_PDE_EVENT(UpdateMouseMove, Core::EventArgs);

	public:
		DECLARE_PDE_ATTRIBUTE_RW(PushDown,		bool);
		DECLARE_PDE_ATTRIBUTE_RW(blink,        bool);
		DECLARE_PDE_ATTRIBUTE_RW(blink_shade,        bool);
		DECLARE_PDE_ATTRIBUTE_RW(anim_blink,        bool);
		DECLARE_PDE_ATTRIBUTE_W(anim_Nums,        int);
		DECLARE_PDE_ATTRIBUTE_RW(blinkwheelTimer,        F64);
		DECLARE_PDE_ATTRIBUTE_RW(NotChangeCol,	bool);
		DECLARE_PDE_ATTRIBUTE_RW(AlwaysBlink,	bool);
		INLINE_PDE_ATTRIBUTE_RW(CanPushDown,	bool);
		DECLARE_PDE_ATTRIBUTE_RW(TextAlign,		Client::Unit::Align);
		DECLARE_PDE_ATTRIBUTE_RW(BorderVisible,	bool);
		INLINE_PDE_ATTRIBUTE_RW(TextShadowWhenNormal, bool);
		OVERRIDE_PDE_ATTRIBUTE_W(Shine,			bool);
		//Careful using this property, it disables clicking without showing disabled appearance
		DECLARE_PDE_ATTRIBUTE_RW(ReceiveKey,	bool);
		SIMPLE_PDE_ATTRIBUTE_RW(Clickable, bool);

		DECLARE_PDE_ATTRIBUTE_RW	(AutoWrap,		bool);
		DECLARE_PDE_ATTRIBUTE_RW	(AutoFontSize,	bool);
		DECLARE_PDE_ATTRIBUTE_RW	(AutoEllipsis,	bool);
		DECLARE_PDE_ATTRIBUTE_RW	(IsNeedToolTip,	bool);
		DECLARE_PDE_ATTRIBUTE_RW	(AutoEllipsisArea,	F32);
		DECLARE_PDE_ATTRIBUTE_RW	(TextPadding,	Core::Vector4);

	public:\
		Button();
		~Button();

		// on frame update
		virtual void OnFrameUpdate(EventArgs & e);

		// on input event
		virtual	void OnInputEvent(Client::InputEventArgs & e);

		// on key event
		virtual void OnKeyEvent(Client::InputEventArgs & e);

		// on paint
		virtual void OnPaint(PaintEventArgs & e);

		// on click
		virtual void OnClick(Client::InputEventArgs & e);

		//on double click
		virtual void OnDoubleClick(Client::InputEventArgs & e);

		virtual void OnPushDownChanged();

		/// on autosize
		virtual void OnAutoSize(AutoSizeEventArgs & e);

		// on size changed
		virtual void OnSizeChanged(ResizeEventArgs & e);

		/// on text changed
		virtual void OnTextChanged(EventArgs & e);

	public:
		void	ReWrapText();

		void	CalcFontSize();

		void	EllipsisMyText();

		tempc_ptr(Client::Font)	GetAutoFont();

	public:

		//This is an example for dragging item to different window/control, remove it as you wish
		virtual void DragEnd(Client::InputEventArgs &e);
		virtual void BlinkButton(PaintEventArgs & e);
	protected:
		bool		m_CanPushDown	:1;
		bool		m_PushDown		:1;
		bool		m_AlwaysBlink		:1;
		bool		m_MouseHoldDown	:1;
		bool		m_MousePointed	:1;
		bool		m_BorderVisible	:1;
		bool		m_SpaceKeyDown	:1;
		bool		m_TextShadowWhenNormal :1;
		bool		m_CanReceiveKey	:1;
		bool		m_NotChangeCol;
		bool		m_blink;
		bool		m_anim_blink;
		bool		m_blink_shade;
		F64			m_Timer;
		int			m_anim_Nums;
		F64			m_blinkwheelTimer;
		Client::Unit::Align		m_TextAlign;

		bool					m_AutoWrap;
		Core::String			m_MultiLineStr;
		Core::String			m_EllipsisStr;
		bool					m_AutoFontSize;
		bool					m_AutoEllipsis;
		F32						m_ResultFontSize;
		F32                     m_AutoEllipsisArea;
		Core::Vector4			m_TextPadding;
		bool					m_IsNeedToolTip;

		bool					m_ismouse_here;
	};
}

namespace Gui
{
	class LobbyMainButton : public Button
	{
	public:
		DECLARE_PDE_OBJECT(LobbyMainButton, Button);
	public:
		DECLARE_PDE_ATTRIBUTE_RW(Notification, const Core::String&);
		DECLARE_PDE_ATTRIBUTE_RW(NotificationIcon, tempc_ptr(Icon));
		DECLARE_PDE_ATTRIBUTE_RW(Notice,		bool);
		DECLARE_PDE_ATTRIBUTE_RW(NoticeIcon, tempc_ptr(Icon));
		SIMPLE_PDE_ATTRIBUTE_RW(Clickable, bool);
		
	public:
		LobbyMainButton();
		~LobbyMainButton();
		virtual void OnCreate();
		virtual void OnInputEvent(Client::InputEventArgs & e);
		virtual void OnFrameUpdate(EventArgs & e);
		virtual void OnClick(Client::InputEventArgs &e);
		virtual void OnPaint(PaintEventArgs & e);

	protected:
		F32		m_ClickEffect;
		bool	m_Clicked;
		bool	m_Notice;
		Core::String	m_Notification;
		sharedc_ptr(Icon) m_NotificationIcon;
		sharedc_ptr(Icon) m_NoticeIcon;
		sharedc_ptr(Client::Font) m_NotificationFont;
	};

	class LobbyMainButtonSkin : public ControlSkin
	{
	public:
		INLINE_PDE_ATTRIBUTE_RW(UpperImage,		tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(UpperHoverImage,		tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(BottomImage,	tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(GlowUpperImage,	tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(GlowBottomImage,tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(ActiveUpperImage, tempc_ptr(Image));

	private:
		sharedc_ptr(Image)	m_UpperImage;
		sharedc_ptr(Image)	m_UpperHoverImage;
		sharedc_ptr(Image)	m_BottomImage;
		sharedc_ptr(Image)	m_GlowUpperImage;
		sharedc_ptr(Image)	m_GlowBottomImage;
		sharedc_ptr(Image)	m_ActiveUpperImage;
	};
}

namespace Gui
{
	class ButtonSkin : public ControlSkin
	{
	public:
		INLINE_PDE_ATTRIBUTE_RW(TwinkleImage,   tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(HoverImage,		tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(DownImage,		tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(DisabledImage,	tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(AnimkleImage,   tempc_ptr(Image));

	private:
		sharedc_ptr(Image) m_TwinkleImage;
		sharedc_ptr(Image) m_HoverImage;
		sharedc_ptr(Image) m_DownImage;
		sharedc_ptr(Image) m_DisabledImage;
		sharedc_ptr(Image) m_AnimkleImage;
	};
}

namespace Gui
{
	class TuneSwitchButton : public Button
	{
		DECLARE_PDE_OBJECT(Button, Control);

	public:
		// on paint
		virtual void OnPaint(PaintEventArgs & e);			
	};

	class TuneSwitchButtonSkin : public ButtonSkin
	{
	public:
		INLINE_PDE_ATTRIBUTE_RW(HoldDownImage, tempc_ptr(Image));

	private:
		sharedc_ptr(Image)	m_HoldDownImage;
	};
}