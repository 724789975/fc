#include "pch.h"
#include "stdio.h"
using namespace Core;
using namespace Client;
using namespace Gui;

DEFINE_PDE_TYPE_CLASS(ChatWindow)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_DEFAULT_CONSTRUCTOR();
		ADD_PDE_SUPER(Control);

		ADD_PDE_PROPERTY_R(PopupMenu);
		ADD_PDE_PROPERTY_RW(MessageDisplayLoc);
		ADD_PDE_PROPERTY_RW(MessageDisplaySize);
		ADD_PDE_PROPERTY_RW(MessageVisble);
		ADD_PDE_PROPERTY_R(SenderMessage);
		ADD_PDE_PROPERTY_R(Servertype);
		ADD_PDE_PROPERTY_RW(gap);
		ADD_PDE_PROPERTY_R(ClickedName);
		ADD_PDE_PROPERTY_R(ChatForm);
		ADD_PDE_PROPERTY_R(ChatFormColor);
		ADD_PDE_PROPERTY_R(SenderName);
		ADD_PDE_PROPERTY_R(SenderGroup);
		ADD_PDE_PROPERTY_R(SenderGroup_id);
		ADD_PDE_PROPERTY_R(Private_Chat);
		ADD_PDE_METHOD(Whisper);
		ADD_PDE_METHOD(ChannelSpeak);
		ADD_PDE_METHOD(RoomSpeak);
		ADD_PDE_METHOD(GroupSpeak);
		ADD_PDE_METHOD(TepGroupSpeak);	
		ADD_PDE_METHOD(InvitePlayer);
		ADD_PDE_METHOD(RefuseInvite);
		ADD_PDE_METHOD(Chat);
				
		ADD_PDE_EVENT(EventReceiveMessage);
	}
};
DEFINE_PDE_TYPE_CLASS(SysMessageBar)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_DEFAULT_CONSTRUCTOR();
		ADD_PDE_SUPER(Control);

		ADD_PDE_PROPERTY_R(SenderName);
		ADD_PDE_PROPERTY_R(SenderMessage);
		ADD_PDE_PROPERTY_R(Servertype);
		ADD_PDE_EVENT(EventHornMessage);
		ADD_PDE_EVENT(EventSpeakerMessage);
		ADD_PDE_EVENT(EventSeverPresent);
	}
};

REGISTER_PDE_TYPE(ChatWindow);
REGISTER_PDE_TYPE(SysMessageBar);

namespace Gui
{
	PDE_ATTRIBUTE_GETTER(ChatWindow,MessageDisplayLoc,Core::Vector2)
	{
		return m_MessageDisplayLoc;
	}

	PDE_ATTRIBUTE_SETTER(ChatWindow,MessageDisplayLoc,Core::Vector2)
	{
		if(value!=m_MessageDisplayLoc)
		{
			m_MessageDisplayLoc = value;
			m_Tabpad->SetLocation(m_MessageDisplayLoc);
		}
	}

	PDE_ATTRIBUTE_GETTER(ChatWindow,gap,float)
	{
		return m_gap;
	}

	PDE_ATTRIBUTE_SETTER(ChatWindow,gap,float)
	{
		if(value!=m_gap)
			m_gap = value;
	}

	PDE_ATTRIBUTE_GETTER(ChatWindow,MessageVisble,bool)
	{
		return m_MessageVisble;
	}

	PDE_ATTRIBUTE_SETTER(ChatWindow,MessageVisble,bool)
	{
		if(value!=m_MessageVisble)
		{	
			m_MessageVisble = value;
			m_MessagePanel->SetVisible(m_MessageVisble);
			m_Tabpad->SetVisible(m_MessageVisble);
		}
	}
	
	PDE_ATTRIBUTE_GETTER(ChatWindow,Private_Chat,bool)
	{
		return m_Private_Chat;
	}

	PDE_ATTRIBUTE_GETTER(ChatWindow,SenderMessage,Core::String)
	{
		return m_SenderMessage;
	}

	PDE_ATTRIBUTE_GETTER(ChatWindow,Servertype,uint)
	{
		return m_Servertype;
	}

	PDE_ATTRIBUTE_GETTER(ChatWindow,SenderName,Core::String)
	{
		return m_SenderName;
	}

	PDE_ATTRIBUTE_GETTER(ChatWindow,SenderGroup,Core::String)
	{
		return m_SenderGroup;
	}
	
	PDE_ATTRIBUTE_GETTER(ChatWindow,SenderGroup_id,uint)
	{
		return m_SenderGroup_id;
	}

	PDE_ATTRIBUTE_GETTER(ChatWindow,MessageDisplaySize,Core::Vector2)
	{
		return m_MessageDisplaySize;
	}

	PDE_ATTRIBUTE_SETTER(ChatWindow,MessageDisplaySize,Core::Vector2)
	{
		if(value!=m_MessageDisplaySize)
		{
			float height;
			m_MessageDisplaySize = value;
			m_Tabpad->SetSize(m_MessageDisplaySize);
			height = GetSize().y-m_Tabpad->GetSize().y-m_gap;
			
			m_Control->SetSize(Vector2(0,height));
			m_Textbox->SetSize(Vector2(GetSize().x,height));
		}
	}

	PDE_ATTRIBUTE_GETTER(ChatWindow, Textbox, tempc_ptr(Textbox))
	{
		return m_Textbox;
	}

	PDE_ATTRIBUTE_GETTER(ChatWindow, PopupMenu, sharedc_ptr(Menu))
	{
		return m_PopupMenu;
	}

	PDE_ATTRIBUTE_GETTER(ChatWindow, ClickedName, Core::String)
	{
		tempc_ptr(MessagePanel) messagePanel = ptr_dynamic_cast<MessagePanel>(m_Tabpad->GetSelectedPage());
		if(messagePanel)
			return messagePanel->GetClickedName();
		return String::kEmpty;
	}
	
	PDE_ATTRIBUTE_GETTER(ChatWindow,ChatForm,F32)
	{
		return m_ChatForm;
	}	

	PDE_ATTRIBUTE_GETTER(ChatWindow,ChatFormColor,F32)
	{
		return m_ChatFormColor;
	}

	ChatWindow::ChatWindow(void)
		: m_MaxAllLine(128)
		, m_ManuallyOn(false)
		, m_MessageVisble(true)
		,m_MessageDisplayLoc(Vector2::kZero)
		,m_MessageDisplaySize(Vector2::kZero)
		,m_ChatForm(0)
		,m_ChatFormColor(0)
		,m_SenderName("")
		,m_gap(0)
		,m_Private_Chat(false)
	{

	}

	ChatWindow::~ChatWindow(void)
	{

	}

	void ChatWindow::OnCreate()
	{
		Super::OnCreate();
		SetSize(Vector2(326,159));
		m_Tabpad = ptr_new(Tabpad);
		m_Tabpad->SetSize(Vector2(326,134));
		m_Tabpad->SetTabSize(Vector2(63,25));
		m_Tabpad->SetTabPadding(Vector4(0,0,0,2));
		m_Tabpad->SetTabGap(2);
		m_Tabpad->EventRightClick.Subscribe(NewDelegate(&ChatWindow::OnTabpadRightClick, ptr_static_cast<ChatWindow>(this)));
		m_Tabpad->EventSelectedPageChanged.Subscribe(NewDelegate(&ChatWindow::OnTabpadSelectedPageChanged, ptr_static_cast<ChatWindow>(this)));
		m_Tabpad->SetParent(ptr_static_cast<ChatWindow>(this));

		m_NewWindowButton = ptr_new(Button);
		m_NewWindowButton->SetSize(Vector2(25,25));
		m_NewWindowButton->SetLocation(Vector2(63,0));
		m_NewWindowButton->EventClick.Subscribe(NewDelegate(&ChatWindow::OnNewWindowButtonClick, ptr_static_cast<ChatWindow>(this)));
		//m_NewWindowButton->SetParent(ptr_static_cast<ChatWindow>(this));

		m_Control = ptr_new FlowLayout;
		m_Control->SetSize(Vector2(0,23));
		m_Control->SetParent(ptr_static_cast<ChatWindow>(this));
		m_Control->SetDock(kDockBottom);

		m_ComboBox = ptr_new ComboBox;
		m_ComboBox->SetSize(Vector2(23,23));
		m_ComboBox->SetDock(kDockLeft);
		m_ComboBox->SetDropDownWidth(100);
		m_ComboBox->SetReadonly(true);
		m_ComboBox->EventItemSelected.Subscribe(NewDelegate(&ChatWindow::OnComboBoxItemSelected,ptr_static_cast<ChatWindow>(this)));
		//m_ComboBox->SetParent(m_Control);

		m_Label = ptr_new Label;
		m_Label->SetSize(Vector2(1,0));
		m_Label->SetDock(kDockLeft);
		m_Label->SetMargin(Vector4(2,0,2,0));
		//m_Label->SetParent(m_Control);

		m_SendButton = ptr_new(Button);
		m_SendButton->SetSize(Vector2(50,23));
		m_SendButton->SetMargin(Vector4(2,0,0,0));
		m_SendButton->SetDock(kDockRight);
		m_SendButton->SetText(gLang->GetTextW(L"��  ��"));
		m_SendButton->EventClick.Subscribe(NewDelegate(&ChatWindow::OnSendButtonClick,ptr_static_cast<ChatWindow>(this)));
		//m_SendButton->SetParent(m_Control);

		m_Textbox = ptr_new Textbox;
		//m_Textbox->SetDock(kDockFill);
		m_Textbox->SetFontSize(20);
		m_Textbox->SetMaxLength(120);
		//m_Textbox->SetFold(true);
		m_Textbox->EventTextChanged.Subscribe(NewDelegate(&ChatWindow::OnTextboxTextChanged,ptr_static_cast<ChatWindow>(this)));
		m_Textbox->EventValueEnter.Subscribe(NewDelegate(&ChatWindow::OnTextboxValueEnter,ptr_static_cast<ChatWindow>(this)));
		m_Textbox->SetParent(m_Control);

		m_Rename = ptr_new Textbox;
		m_Rename->SetSize(Vector2(63,25));
		m_Rename->SetMaxLength(8);
		m_Rename->EventValueEnter.Subscribe(NewDelegate(&ChatWindow::OnRenameValueEnter, ptr_static_cast<ChatWindow>(this)));
		m_Rename->EventLeave.Subscribe(NewDelegate(&ChatWindow::OnRenameLeave, ptr_static_cast<ChatWindow>(this)));

		m_MessagePanel = ptr_new MessagePanel;
		m_MessagePanel->m_ChatWindow = ptr_static_cast<ChatWindow>(this);
		m_MessagePanel->SetParent(m_Tabpad);

		m_MainMenu = ptr_new Menu;
		m_MainMenu->AddItem(gLang->GetTextW(L"�½�����"));
		m_MainMenu->AddItem(gLang->GetTextW(L"�������ô���"));
		m_MainMenu->AddItem(gLang->GetTextW(L"ɾ���ô���"));
		m_MainMenu->AddItem(gLang->GetTextW(L"��ʾ����"));
		m_MainMenu->EventClick.Subscribe(NewDelegate(&ChatWindow::OnMainMenuClick,ptr_static_cast<ChatWindow>(this)));
		m_MainMenu->EventOpen.Subscribe(NewDelegate(&ChatWindow::OnMenuOpen, ptr_static_cast<ChatWindow>(this)));
		m_MainMenu->EventClose.Subscribe(NewDelegate(&ChatWindow::OnMenuClose, ptr_static_cast<ChatWindow>(this)));

		m_ShowMenu = ptr_new Menu;
		m_ShowMenu->AddItem(gLang->GetTextW(L"ս��"));
		m_ShowMenu->AddItem(gLang->GetTextW(L"���"));
		m_ShowMenu->AddItem(gLang->GetTextW(L"��ǰ"));
		m_ShowMenu->AddItem(gLang->GetTextW(L"����"));
		m_ShowMenu->SetCanCheck(0, true);
		m_ShowMenu->SetCanCheck(1, true);
		m_ShowMenu->SetCanCheck(2, true);
		m_ShowMenu->SetCanCheck(3, true);
		m_ShowMenu->EventClick.Subscribe(NewDelegate(&ChatWindow::OnShowMenuClick,ptr_static_cast<ChatWindow>(this)));

		m_MainMenu->SetSubMenu(3,m_ShowMenu);

		m_PopupMenu = ptr_new Menu;
		m_PopupMenu->EventOpen.Subscribe(NewDelegate(&ChatWindow::OnMenuOpen, ptr_static_cast<ChatWindow>(this)));
		m_PopupMenu->EventClose.Subscribe(NewDelegate(&ChatWindow::OnMenuClose, ptr_static_cast<ChatWindow>(this)));

		//Temp
		m_MessagePanelStyle = "Gui.MessagePanel";
		SetBackgroundColor(ARGB(0,0,0,0));
		m_MessagePanel->SetStyle(m_MessagePanelStyle);
		m_Control->SetStyle("Gui.ChatBarStyle");
		m_Tabpad->SetStyle("Gui.ChatTab");
		m_NewWindowButton->SetStyle("Gui.ChatAddButton");
		m_Label->SetBackgroundColor(ARGB(0,0,0,0));
		m_Textbox->SetStyle("Gui.ChatTextBoxStyle");
		m_Rename->SetStyle("Gui.ChatTextBoxStyle");
		m_ComboBox->SetStyle("Gui.ChatComboBox");
		m_SendButton->SetStyle("Gui.ChatButton");
		m_MainMenu->SetStyle("Gui.Menu");
		m_ShowMenu->SetStyle("Gui.Menu");
		m_PopupMenu->SetStyle("Gui.Menu");

		m_TextRect = m_MessagePanel->GetDisplayRect().Shrink(m_MessagePanel->GetScrollBarWidth() + m_MessagePanel->GetLeftGap(),0,0,0);
		m_CurrentLinkStart = m_MessagePanel->GetScrollBarWidth() + m_MessagePanel->GetLeftGap();
		Core::Rectangle rect(0,0,0,0);
	}

	void ChatWindow::OnInputEvent(InputEventArgs & e)
	{
		if (e.IsKeyEvent() && e.Type == InputEventArgs::kKeyUp)
		{
			//��ʱ���ε�
			//switch (e.Code)
			//{
			//case KC_F2:
			//	{
			//		SetChannel(kNoneColor,Identifier::kNull,Core::String::kEmpty);
			//		e.Handled = true;
			//	}
			//	break;
			//case KC_F3:
			//	{
			//		SetChannel(kGroupColor,Identifier("/p"),gLang->GetTextW(L"���"));
			//		e.Handled = true;
			//	}
			//	break;
			//case KC_F4:
			//	{
			//		SetChannel(kTeamColor,Identifier("/w"),gLang->GetTextW(L"ս��"));
			//		e.Handled = true;
			//	}
			//	break;
			//default:
			//	break;
			//}
		}
		if (!e.Handled)
		{
			Control::OnInputEvent(e);
		}
	}

	void ChatWindow::OnTabpadRightClick( by_ptr(void) sender, InputEventArgs & e )
	{
		tempc_ptr(MessagePanel) messagePanel = ptr_static_cast<MessagePanel>(m_Tabpad->GetSelectedPage());
		if (!messagePanel)
			return;
		U32 index = m_Tabpad->GetIndex();
		Vector2 pos = m_Tabpad->GetTabLableScreentPos(index);
		Vector2 menuPos =  ClientToGlobalScreen(ScreenToClient(e.CursorPosition));
		if ( index == 0)
		{
			m_MainMenu->SetEnable(1,false);
			m_MainMenu->SetEnable(2,false);
			m_MainMenu->SetEnable(3,false);
		}
		else
		{
			m_MainMenu->SetEnable(1,true);
			m_MainMenu->SetEnable(2,true);
			m_MainMenu->SetEnable(3,true);
			m_ShowMenu->SetCheck(0,messagePanel->m_Channel&kTeam?true:false);
			m_ShowMenu->SetCheck(1,messagePanel->m_Channel&kGroup?true:false);
			m_ShowMenu->SetCheck(3,messagePanel->m_Channel&kWhisper?true:false);
			if (gGame->global->GetClientAddress().room_id > 0)
			{
				m_ShowMenu->SetEnable(2,true);
				m_ShowMenu->SetCheck(2,messagePanel->m_Channel&kRoom?true:false);
			}
			else if (gGame->global->GetClientAddress().channel_id > 0)
			{
				m_ShowMenu->SetEnable(2,true);
				m_ShowMenu->SetCheck(2,messagePanel->m_Channel&kChannel?true:false);
			}
			else
			{
				m_ShowMenu->SetEnable(2,false);
				m_ShowMenu->SetCheck(2,true);
			}
		}

		if (m_Tabpad->GetSonCount() >= 5)
		{
			m_MainMenu->SetEnable(0,false);
		}
		else
		{
			m_MainMenu->SetEnable(0,true);
		}

		m_MainMenu->SetLocation(menuPos);
		m_MainMenu->Open();
	}

	void ChatWindow::OnTabpadSelectedPageChanged(by_ptr(void) sender, Gui::TabChangedEventArgs & e)
	{
		ptr_static_cast<MessagePanel>(m_Tabpad->GetSelectedPage())->DirtyLines(false);
	}

	void ChatWindow::OnNewWindowButtonClick(by_ptr(void) sender, InputEventArgs & e)
	{
		NewWindow();
	}

	void ChatWindow::NewWindow()
	{
		U32 count = m_Tabpad->GetSonCount();
		if (count < 5)
		{
			sharedc_ptr(MessagePanel) messagePanel = ptr_new(MessagePanel);
			messagePanel->SetStyle(m_MessagePanelStyle);
			messagePanel->SetText(gLang->GetTextW(L"�½�����"));
			messagePanel->m_ChatWindow = ptr_static_cast<ChatWindow>(this);
			messagePanel->SetParent(m_Tabpad);
			if (m_Tabpad->GetSonCount() == 5)
			{
				m_NewWindowButton->SetVisible(false);
			}
		}
		ResetNewWindowButtonLocation();
	}

	void ChatWindow::ResetNewWindowButtonLocation()
	{
		U32 count = m_Tabpad->GetSonCount();
		F32 offset = count*m_Tabpad->GetTabSize().x + m_Tabpad->GetTabGap()*(count - 1);
		m_NewWindowButton->SetLocation(Vector2(offset,0));
	}

	void ChatWindow::OnComboBoxItemSelected(by_ptr(void) sender,EventArgs & e)
	{

	}

	void ChatWindow::OnTextboxTextChanged(by_ptr(void) sender, Core::EventArgs & e)
	{

	}

	void ChatWindow::OnTextboxValueEnter(by_ptr(void) sender, Core::EventArgs & e)
	{
		m_Private_Chat = true;
		Core::String text = m_Textbox->GetText();
		CStrBuf<128> strBuff;
		Line line;
		line.Index = kInfo;
		line.Color = kInfoColor;
		SendMessage();
	}

	void ChatWindow::OnRenameValueEnter(by_ptr(void) sender, Core::EventArgs & e)
	{
		Rename();
	}

	void ChatWindow::OnRenameLeave(by_ptr(void) sender, Core::EventArgs & e )
	{
		Rename();
	}

	void ChatWindow::Rename()
	{
		Core::String text = m_Rename->GetText();
		if (text != Core::String::kEmpty)
		{
			m_Tabpad->GetSelectedPage()->SetText(text);
		}
		else
		{
			m_Tabpad->GetSelectedPage()->SetText(m_OldWindowName);
		}
		m_Rename->SetFocused(false);
		m_Rename->SetParent(NullPtr);
	}

	void ChatWindow::OnSendButtonClick(by_ptr(void) sender, Client::InputEventArgs &e)
	{
		SendMessage();
	}

	void ChatWindow::ReceiveMessage(Client::ChatMessage & message)
	{
		if(gGame->global)
		{
			gGame->global->Translate(message.msg);
			gGame->global->Translate(message.sender);
		}
		m_SenderName = message.sender;
		m_SenderMessage = message.msg;
        m_Servertype = message.server_Type;
		m_SenderGroup = message.group;
		m_SenderGroup_id = message.group_id;
		m_ChatForm = 0;
		m_ChatFormColor = 0;
		tempc_ptr(Font) font = GetFont();
		if (!font)
			return;

		//̫���ӣ�����ر�
		//if(gGame&&gGame->guiSys)
		//{
		//	bool ispass = true;
		//	for(int i = 0; i < (int)gGame->level->m_Blacklist.Size();++i)
		//	{
		//		if (m_SenderName == gGame->level->m_Blacklist[i].name)
		//		{
		//			ispass = false;
		//			break;
		//		}
		//	}
		//	if (ispass)
		//	{
		//		gGame->guiSys->PlayAudio(GuiSystem::kUIA_CHAT_MESSAGE);
		//	}
		//}

		Core::Rectangle rect(0,0,0,0);
		CStrBuf<512> strBuf;
		Line line;
		F32 linkLength = font->MeasureString(rect, message.sender, -1, Unit::kAlignLeftTop).GetExtent().x;
		/*if(message.channel == Identifier::kNull)
		{
			if (gGame->global->GetClientAddress().room_id > 0)
			{
				strBuf.format("%s��%s", message.sender, message.msg);
				line.Index = kRoom;
				line.Color = kRoomColor;
				m_ChatForm = 5;
			}
			else if (gGame->global->GetClientAddress().channel_id > 0)
			{
				strBuf.format("%s��%s", message.sender, message.msg);
				line.Index = kChannel;
				line.Color = kChannelColor;
				m_ChatForm = 4;
			}
			else
			{
				strBuf.format("%s��%s", message.sender, message.msg);
				line.Index = kNone;
				line.Color = kNoneColor;
				m_ChatForm = 4;
			}
			line.LinkStart = m_CurrentLinkStart;
			line.LinkEnd = line.LinkStart + linkLength;
			line.LinkContent = message.sender;

		}*/
		if(message.channel == Identifier::kNull)
		{
			strBuf.format("%s��%s", message.sender, message.msg);
			line.Index = kNone;
			line.Color = kNoneColor;
			m_ChatForm = 4;
			line.LinkStart = m_CurrentLinkStart;
			line.LinkEnd = line.LinkStart + linkLength;
			line.LinkContent = message.sender;
		}
		else if (message.channel == Core::Identifier("/group"))
		{
			//strBuf.format("%s��%s", message.sender, message.msg);
			char* Names;
			m_SenderGroup = strtok_s( (char* )message.msg.Str() ," ",&Names);
			m_SenderMessage = strtok_s( NULL ," ",&Names);
			line.Index = kChannel;
			line.Color = kChannelColor;
			m_ChatForm = 3;
			line.LinkStart = m_CurrentLinkStart;
			line.LinkEnd = line.LinkStart + linkLength;
			line.LinkContent = message.sender;
		}
		else if (message.channel == Core::Identifier("/banned"))
		{
			//strBuf.format("%s��%s", message.sender, message.msg);
			char* Names;
			m_SenderGroup = strtok_s( (char* )message.msg.Str() ," ",&Names);
			m_SenderMessage = strtok_s( NULL ," ",&Names);
			line.Index = kChannel;
			line.Color = kChannelColor;
			m_ChatForm = -10;
			line.LinkStart = m_CurrentLinkStart;
			line.LinkEnd = line.LinkStart + linkLength;
			line.LinkContent = message.sender;
		}
		else if(message.channel == Core::Identifier("/Channel"))
		{
			strBuf.format("%s��%s", message.sender, message.msg);
			line.Index = kChannel;
			line.Color = kChannelColor;
			m_ChatForm = 4;
			line.LinkStart = m_CurrentLinkStart;
			line.LinkEnd = line.LinkStart + linkLength;
			line.LinkContent = message.sender;
		}
		else if(message.channel == Core::Identifier("/room"))
		{
			strBuf.format("%s��%s", message.sender, message.msg);
			line.Index = kRoom;
			line.Color = kRoomColor;
			m_ChatForm = 5;
			line.LinkStart = m_CurrentLinkStart;
			line.LinkEnd = line.LinkStart + linkLength;
			line.LinkContent = message.sender;
		}
		else if(message.channel == Core::Identifier("/Group"))
		{
			strBuf.format("%s��%s", message.sender, message.msg);
			line.Index = kRoom;
			line.Color = kRoomColor;
			m_ChatForm = 3;
			line.LinkStart = m_CurrentLinkStart;
			line.LinkEnd = line.LinkStart + linkLength;
			line.LinkContent = message.sender;
		}
		else if(message.channel == Core::Identifier("/TepGroup"))
		{
			strBuf.format("%s��%s", message.sender, message.msg);
			line.Index = kRoom;
			line.Color = kRoomColor;
			m_ChatForm = 6;
			line.LinkStart = m_CurrentLinkStart;
			line.LinkEnd = line.LinkStart + linkLength;
			line.LinkContent = message.sender;
		}
		else if(gGame->lobby_connection && message.channel == Core::Identifier(gGame->lobby_connection->character_name))
		{
			strBuf.format(gLang->GetTextW(L"[����]%s��%s"), message.sender, message.msg);
			m_ReplyObject = message.sender;
			line.Index = kWhisper;
			line.Color = kWhisperColor;
			line.LinkStart = font->MeasureString(rect, gLang->GetTextW(L"[����] "), -1, Unit::kAlignLeftTop).GetExtent().x + m_CurrentLinkStart;
			line.LinkEnd = font->MeasureString(rect, gLang->GetTextW(L"[����] "), -1, Unit::kAlignLeftTop).GetExtent().x + m_CurrentLinkStart + linkLength;
			line.LinkContent = message.sender;
			m_ChatForm = 1;

		}
		else if(message.channel == Core::Identifier("/info"))
		{
			strBuf.format("%s", message.msg);
			line.Index = kInfo;
			line.Color = kInfoColor;
			m_ChatForm = 4;
		}
		else if(message.channel == Core::Identifier("/InvitePlayer"))
		{
			strBuf.format("%s��%s", message.sender, message.msg);
			line.Index = kChannel;
			line.Color = kChannelColor;
			m_ChatForm = 9;
			line.LinkStart = m_CurrentLinkStart;
			line.LinkEnd = line.LinkStart + linkLength;
			line.LinkContent = message.sender;
		}
		else if(message.channel == Core::Identifier("/online"))
		{
			strBuf.format("%s", message.msg);
			line.Index = kInfo;
			line.Color = kInfoColor;
			m_ChatForm = 4;
		}
		else if(message.channel == Core::Identifier("/sys"))
		{
			strBuf.format(gLang->GetTextW(L"[����]��%s"), message.msg);
			line.Index = kSys;
			line.Color = kSysColor;
			m_ChatForm = 4;
		}
		//else if(message.channel == Core::Identifier("/p"))
		//{
		//	strBuf.format(gLang->GetTextW(L"[���]%s��%s"),message.sender,message.msg);
		//	line.Index = kGroup;
		//	line.Color = kGroupColor;
		//	line.LinkStart = font->MeasureString(rect, gLang->GetTextW(L"[���] "), -1, Unit::kAlignLeftTop).GetExtent().x + m_CurrentLinkStart;
		//	line.LinkEnd = font->MeasureString(rect, gLang->GetTextW(L"[���] "), -1, Unit::kAlignLeftTop).GetExtent().x + m_CurrentLinkStart + font->MeasureString(rect, message.sender,-1, Unit::kAlignLeftTop).GetExtent().x;
		//	line.LinkContent = message.sender;
		//}
		//else if (message.channel == Core::Identifier("/w"))
		//{
		//	strBuf.format(gLang->GetTextW(L"[ս��]%s��%s"),message.sender,message.msg);
		//	line.Index = kTeam;
		//	line.Color = kTeamColor;
		//	line.LinkStart = font->MeasureString(rect, gLang->GetTextW(L"[ս��] "), -1, Unit::kAlignLeftTop).GetExtent().x + m_CurrentLinkStart;
		//	line.LinkEnd = font->MeasureString(rect, gLang->GetTextW(L"[ս��] "), -1, Unit::kAlignLeftTop).GetExtent().x + m_CurrentLinkStart + font->MeasureString(rect, message.sender, -1, Unit::kAlignLeftTop).GetExtent().x;
		//	line.LinkContent = message.sender;
		//}
		else if(message.channel == Core::Identifier("/offline"))
		{
			strBuf.format(gLang->GetTextW(L"���%s������"), m_To);
			line.Index = kInfo;
			line.Color = kInfoColor;
			m_ChatForm = 2;
		}
		//else if (message.channel == Core::Identifier("/no_p"))
		//{
		//	strBuf.format(gLang->GetTextW(L"��Ŀǰû����ӡ�"));
		//	line.Index = kInfo;
		//	line.Color = kInfoColor;
		//}
		//else if (message.channel == Core::Identifier("/no_w"))
		//{
		//	strBuf.format(gLang->GetTextW(L"��Ŀǰû��ս�ӡ�"));
		//	line.Index = kInfo;
		//	line.Color = kInfoColor;
		//}
		else if (message.channel == Core::Identifier("/gag"))
		{
			strBuf.format(gLang->GetTextW(L"��˵�����졣"));
			line.Index = kInfo;
			line.Color = kInfoColor;
			m_ChatForm = -1;
		}
		else if (message.channel == Core::Identifier("/dlb"))
		{
			strBuf.format("    %s��%s",message.sender,message.msg);
			line.Index = kBigSpeaker;
			line.Color = kBigSpeakerColor;
			line.LinkStart = font->MeasureString(rect, "     ", -1, Unit::kAlignLeftTop).GetExtent().x + m_CurrentLinkStart;
			line.LinkEnd = font->MeasureString(rect, "     ", -1, Unit::kAlignLeftTop).GetExtent().x + m_CurrentLinkStart + linkLength;
			line.LinkContent = message.sender;
		}
		else if(message.sender == gGame->lobby_connection->character_name && message.channel != Core::Identifier("/dlb") && message.channel != Core::Identifier("/xlb"))
		{
			strBuf.format(gLang->GetTextW(L"[����]To%s��%s"), message.channel, message.msg);
			line.LinkStart = font->MeasureString(rect, gLang->GetTextW(L"[����]To "), -1, Unit::kAlignLeftTop).GetExtent().x + m_CurrentLinkStart;
			line.LinkEnd = font->MeasureString(rect, gLang->GetTextW(L"[����]To "), -1, Unit::kAlignLeftTop).GetExtent().x + m_CurrentLinkStart + font->MeasureString(rect, message.channel, -1, Unit::kAlignLeftTop).GetExtent().x;
			line.Index = kWhisper;
			line.Color = kWhisperColor;
			line.LinkContent = message.channel;
			m_ChatForm = 1;
		}
		else
		{
			return;
		}
		line.Text = strBuf;
		if (m_AllLines.Size() > m_MaxAllLine)
		{
			m_AllLines.RemoveAt(0);
		}

		if (SplitString(line.Text,line.Text,m_TextRect,font) > 1)
		{
			Line addLine = line;
			CRefStr & refStr = line.Text.RefStr(0);
			S32 cp = refStr.find('\n');
			U32 count = 1;
			while(cp > 0)
			{
				addLine.Text.RefStr(0).copy(refStr,0,cp);
				refStr.remove(0,cp + 1);
				cp = refStr.find('\n');
				if (count > 1)
				{
					addLine.LinkStart = -1;
				}
				AddLine(addLine);
				count++;
			}
			addLine.Text = refStr;
			addLine.LinkStart = -1;
			AddLine(addLine);
		}
		else
		{
			AddLine(line);
		}

		EventReceiveMessage.Fire(ptr_static_cast<Self>(this),(Core::EventArgs &)NullPtr);
	}
	void ChatWindow::SendMessage()
	{	
		if (m_Textbox->GetText() == "")
			return;
		if (m_GroupNames.GetCount() != 0)
		{
			gGame->global->ChatGroup(m_To,m_Textbox->GetText(),m_GroupNames);
			m_Textbox->SetText("");
			return;
		}
		if (m_nTo != 0)
		{
			gGame->global->ChatTepGroup(m_nTo,m_Textbox->GetText());
			m_Textbox->SetText("");
			return;
		}
		if(!gGame->global->Chat(m_To,m_Textbox->GetText()))
		{
			Line line;
			CStrBuf<256> strBuf;
			strBuf.format("%s", gLang->GetTextW(L"�޷�������Ϣ����δ����Ƶ����"));
			line.Index = kInfo;
			line.Text = strBuf;
			line.Color = kInfoColor;
			AddLine(line);
		}
		m_Textbox->SetText("");
	}

	void ChatWindow::SetChannel(Core::ARGB channelColor, Core::Identifier to, Core::String labelText, Core::String textboxText)
	{
		m_To = to;
		m_Label->SetText(labelText);
		m_Label->SetTextColor(channelColor);
		m_Textbox->SetText(textboxText);
		m_Textbox->SetFontSize(14);
		m_Textbox->SetTextColor(channelColor);
		m_Textbox->SetFocused(true);
		Core::Rectangle rect(0,0,0,0);
		F32 width = GetFont()->MeasureString(rect, labelText, -1, Unit::kAlignLeftMiddle).GetExtent().x;
		m_Label->SetSize(Vector2(width,0));
	}

	void ChatWindow::Whisper(Core::String to)
	{
		m_GroupNames.Clear();
		m_nTo = 0;
		CStrBuf<256> buf;
		buf.format("To[%s]:",to);
		SetChannel(kChatColor,to,buf);
	}

	void ChatWindow::ChannelSpeak()
	{
		m_GroupNames.Clear();
		m_nTo = 0;
		SetChannel(kChatColor,"/Channel",Core::String::kEmpty);
	}

	void ChatWindow::RoomSpeak()
	{
		m_GroupNames.Clear();
		m_nTo = 0;
		SetChannel(kChatColor,"/room",Core::String::kEmpty);
	}

	void ChatWindow::GroupSpeak(Core::String Group ,Core::String to)
	{
		m_GroupNames.Clear();
		m_nTo = 0;
		char* Names;
		char* GroupName;
		Core::String StrName;
		GroupName = strtok_s( (char* )to.Str() ,",",&Names);
		while(GroupName)
		{
			StrName.Clear();
			StrName = GroupName;
			m_GroupNames.Add(StrName);
			GroupName = strtok_s( NULL ,",",&Names);
		}
		SetChannel(kChatColor,Group,Core::String::kEmpty);	
	}

	void ChatWindow::TepGroupSpeak(F32 to)
	{
		m_GroupNames.Clear();
		m_nTo = to;
		SetChannel(kChatColor,"/TepGroup",Core::String::kEmpty);
	}

	void ChatWindow::InvitePlayer(Core::String to)
	{
		static Core::Identifier Invite("/InvitePlayer");
		Core::Array<Core::String> TepTo;
		TepTo.Add(to.Str());
		gGame->global->ChatGroup(Invite,NULL,TepTo);
	}

	void ChatWindow::RefuseInvite(Core::String to)
	{
		static Core::Identifier Invite("/RefuseInvite");
		Core::Array<Core::String> TepTo;
		TepTo.Add(to.Str());
		gGame->global->ChatGroup(Invite,NULL,TepTo);
	}

	void ChatWindow::OnMainMenuClick(by_ptr(void) sender, InputEventArgs & e)
	{
		S32 index = m_Tabpad->GetIndex();
		switch (m_MainMenu->GetSelectedIndex())
		{
		case 0:
			{
				NewWindow();
			}
			break;
		case 1:
			{
				if (index > 0)
				{
					tempc_ptr(MessagePanel) messagePanel = ptr_static_cast<MessagePanel>(m_Tabpad->GetSelectedPage());
					m_OldWindowName = messagePanel->GetText();
					messagePanel->SetText(Core::String::kEmpty);
					m_Rename->SetParent(ptr_static_cast<ChatWindow>(this));
					Vector2 pos = m_Tabpad->GetTabLableRect(index).Min;
					m_Rename->SetLocation(pos);
					m_Rename->SetFocused(true);
					m_Rename->SetText(Core::String::kEmpty);
				}
			}
			break;
		case 2:
			{
				if (index > 0)
				{
					tempc_ptr(MessagePanel) messagePanel = ptr_static_cast<MessagePanel>(m_Tabpad->GetSelectedPage());
					messagePanel->SetParent(NullPtr);
					messagePanel = NullPtr;
					ResetNewWindowButtonLocation();
					m_NewWindowButton->SetVisible(true);
				}
			}
			break;
		default:
			break;
		}
	}

	void ChatWindow::OnShowMenuClick(by_ptr(void) sender, InputEventArgs & e)
	{
		tempc_ptr(MessagePanel) messagePanel = ptr_static_cast<MessagePanel>(m_Tabpad->GetSelectedPage());
		switch (m_ShowMenu->GetSelectedIndex())
		{
		case 0:
			{
				messagePanel->m_Channel ^= kTeam; 
			}
			break;
		case 1:
			{
				messagePanel->m_Channel ^= kGroup;
			}
			break;
		case 2:
			{
				if (gGame->global->GetClientAddress().room_id > 0)
				{
					messagePanel->m_Channel ^= kRoom;
				}
				else if (gGame->global->GetClientAddress().channel_id > 0)
				{
					messagePanel->m_Channel ^= kChannel;
				}
			}
			break;
		case 3:
			{
				messagePanel->m_Channel ^= kWhisper;
			}
			break;
		default:
			break;
		}
		ptr_static_cast<MessagePanel>(m_Tabpad->GetSelectedPage())->DirtyLines();
	}

	void ChatWindow::OnComplementaryDraw( PaintEventArgs & e, F32 opacity )
	{
		if(m_Tabpad)
		{
			tempc_ptr(MessagePanel) msgPanel = ptr_dynamic_cast<MessagePanel>(m_Tabpad->GetSelectedPage());
			if(msgPanel)
				msgPanel->OnComplementaryDraw(e, opacity);
		}
	}

	void ChatWindow::OnMenuOpen( by_ptr(void) sender, EventArgs & e )
	{
		SetManuallyOn(true);
	}

	void ChatWindow::OnMenuClose( by_ptr(void) sender, EventArgs & e )
	{
		SetManuallyOn(false);
		if(m_Textbox)
			m_Textbox->SetFocused(true);
	}

	void ChatWindow::AddLine(const Line & line)
	{
		for(Control* child = m_Tabpad->GetFirstChild();child;child = child->GetNext())
		{
			ptr_static_cast<MessagePanel>(child)->AddLine(line);
			if (ptr_static_cast<MessagePanel>(m_Tabpad->GetSelectedPage()) == child)
			{
				ptr_static_cast<MessagePanel>(child)->DirtyLines(true);
			}
		}
	}

	void ChatWindow::Chat(const Core::String &string,const Core::String &str)
	{
		m_Private_Chat = false;
		Core::Identifier to(str);
		gGame->global->Chat(to,string);
	}
}

namespace Gui
{
	SysMessageBar::SysMessageBar()
		: m_FrameTimer(0.f)
		, m_SenderName("")
		, m_SenderMessage("")
	{
		m_IconSpeaker = ptr_new Gui::Icon("InGameUI/ig_horn.dds", Core::Vector4::kZero);
		m_IconRect = Core::Rectangle::LeftTop(0,0,36,36);

		m_BigSpeakerMessage.TextColor = ChatWindow::kBigSpeakerColor;
		m_BigSpeakerMessage.Align = Unit::kAlignLeftMiddle;
		m_BigSpeakerMessage.FontSize = 16;
		Prize_Color[0] = Core::ARGB(255, 255, 255, 255);
		Prize_Color[1] = Core::ARGB(255,205,43,55);
		Prize_Color[2] = Core::ARGB(255,181,58,212);
		Prize_Color[3] = Core::ARGB(255,101,179,239);
		Prize_Color[4] = Core::ARGB(255,128,239,147);
		Prize_Color[5] = Core::ARGB(255,255,96,0);
		Prize_Color[6] = Core::ARGB(255,255,96,0);
		Prize_Color[7] = Core::ARGB(255,255,255,78);
		Prize_Color[8] = Core::ARGB(255,128,239,147);
	}

	SysMessageBar::~SysMessageBar()
	{

	}

	PDE_ATTRIBUTE_GETTER(SysMessageBar,SenderMessage,Core::String)
	{
		return m_SenderMessage;
	}
	PDE_ATTRIBUTE_GETTER(SysMessageBar,Servertype,uint)
	{
		return m_Servertype;
	}
	PDE_ATTRIBUTE_GETTER(SysMessageBar,SenderName,Core::String)
	{
		return m_SenderName;
	}

	void SysMessageBar::OnPaint(PaintEventArgs & e)
	{
		if (m_WarningMessage.Times > 0.f )
		{
			Core::Rectangle oldScissorRect = e.render->GetScissorRect();
			Core::Rectangle newScissorRect = oldScissorRect;
			newScissorRect.Min.x += 5.f;
			e.render->SetScissorRect(newScissorRect);
			if (m_WarningMessage.Text.Size() > 0)
			{
				e.render->DrawStringShadow(GetFont(),m_WarningMessage.TextColor, ARGB(m_WarningMessage.TextColor.a,0,0,0),ARGB(0,0,0,0),m_WarningMessage.PaintRect,m_WarningMessage.Text,m_WarningMessage.Align);
			} 
			else
			{
				int i_tep = 0;
				Core::Rectangle	PaintRect_tep = m_WarningMessage.PaintRect;
				Core::Rectangle rect;
				Core::String str_tep;
				Core::ARGB TextColor_tep;
				while (i_tep < m_WarningMessage.ArString.GetCount())
				{
					if (i_tep%2 == 0)
					{
						TextColor_tep = Prize_Color[atoi(m_WarningMessage.ArString.GetAt(i_tep).Str())];
					}
					else
					{
						str_tep = m_WarningMessage.ArString.GetAt(i_tep);
						rect = GetFont()->MeasureString(Core::Rectangle(0, 0, 0, 0), m_WarningMessage.ArString.GetAt(i_tep), -1, 0);
						rect.Min.y = PaintRect_tep.Min.y;
						rect.Max.y = PaintRect_tep.Max.y;
						float lon = rect.Max.x;
						e.render->DrawStringShadow(GetFont(),TextColor_tep, ARGB(TextColor_tep.a,0,0,0),ARGB(0,0,0,0),rect.Move(Core::Vector2(PaintRect_tep.Min.x,0)),str_tep,m_WarningMessage.Align);
						PaintRect_tep.Move(Core::Vector2(lon,0));
					}
					i_tep++;
				}
			}				
			e.render->SetScissorRect(oldScissorRect);

		}
		if (m_BigSpeakerMessage.Times > 0.f)
		{
			e.render->DrawStringShadow(GetFont(),m_BigSpeakerMessage.TextColor, ARGB(m_BigSpeakerMessage.TextColor.a,0,0,0),ARGB(0,0,0,0),m_BigSpeakerMessage.PaintRect,m_BigSpeakerMessage.Text,m_BigSpeakerMessage.Align);
		}
//		if (m_WarningMessage.Times > 0 || m_BigSpeakerMessage.Times > 0)
//		{
//			m_Icon->Draw(e.render,m_IconRect,ARGB(255,255,255,255));
//		}
	}

	void SysMessageBar::OnFrameUpdate( EventArgs & e )
	{
		if (m_WarningMessageArray.Empty() && m_WarningMessage.Times == 0 )
		{
			return;
		}
		if (m_WarningMessage.Times == 0 )
		{
			m_Icon = m_IconSpeaker;
			m_WarningMessage = m_WarningMessageArray.GetAt(0);
			m_WarningMessageArray.RemoveAt(0);
			if(m_WarningMessageArray.Empty())
				m_WarningMessageArray.Clear();
		}
		if (m_WarningMessage.Times > 0)
		{
			F32 frameTime = Core::Task::GetFrameTime();;
			//m_WarningMessage.Timer -= frameTime;

			if (m_WarningMessage.PaintRect.Max.x < 0.f)
			{
				m_WarningMessage.TextRect.Max.y = GetSize().y;
				m_WarningMessage.PaintRect = m_WarningMessage.TextRect;
				m_WarningMessage.PaintRect.Min.y += 15; 
				m_WarningMessage.PaintRect.Move(Vector2(GetSize().x,0));
				m_WarningMessage.Times -= 1;
			}
			//m_FrameTimer += frameTime;
			//if (m_FrameTimer > 0.1f)
			//{
				m_WarningMessage.PaintRect.Move(Vector2(-80.f*frameTime,0.f));
				//m_FrameTimer = 0.f;
				//Invalid();
			//}
			if (m_WarningMessage.Times <= 0)
			{
				m_WarningMessage.Times = 0;
				Invalid();
			}
		}

		if (m_BigSpeakerMessage.Times > 0)
		{
			//m_BigSpeakerMessage.Times -= Core::Task::GetFrameTime();
			if (m_BigSpeakerMessage.Times <= 0)
			{
				m_BigSpeakerMessage.Times = 0;
				Invalid();
			}
		} 
	}

	int	SysMessageBar::GetWarningMessageArraySize()
	{
		return m_WarningMessageArray.GetCount();
	}

	void SysMessageBar::ReceiveMessage( Client::ChatMessage & message )
	{
		CStrBuf<1024> strBuf;
		CStrBuf<1024> strBuff = message.channel;

		if(gGame->global)
			gGame->global->Translate(message.msg);
		m_SenderName = message.sender;
		m_SenderMessage = message.msg;
		
		if (message.channel == Core::Identifier("/sys") )//sys
		{
			strBuf.format(gLang->GetTextW(L"[����]��%s"),message.msg);
			SysMessage	m;
			m.Text = strBuf;
			m.Times = 1;
			m_BigSpeakerMessage.Times = 0;
			m.Align = Unit::kAlignLeftMiddle;
			m.FontSize = 16;
			SetFontSize(m.FontSize);
			Core::Rectangle rect(0,0,0,0);
			m.TextRect = GetFont()->MeasureString(rect,m.Text,-1,m.Align);
			m.TextRect.Max.y = GetSize().y;
			m.PaintRect = m.TextRect;
			m.PaintRect.Min.y += 15; 
			m.TextColor = ARGB(255, 255, 0, 0);
			m.PaintRect.Move(Vector2(GetSize().x,0));
			m_WarningMessageArray.Add(m);

			/*m_Icon = m_IconSpeaker;
			m_WarningMessage.Text = strBuf;
			m_WarningMessage.Timer = 60.f;
			m_BigSpeakerMessage.Timer = 0.f;
			SetFontSize(m_WarningMessage.FontSize);
			Core::Rectangle rect(0,0,0,0);
			m_WarningMessage.TextRect = GetFont()->MeasureString(rect,m_WarningMessage.Text,-1,m_WarningMessage.Align);
			m_WarningMessage.TextRect.Max.y = GetSize().y;
			m_WarningMessage.PaintRect = m_WarningMessage.TextRect;
			m_WarningMessage.TextColor = ARGB(255, 255, 0, 0);
			m_WarningMessage.PaintRect.Move(Vector2(GetSize().x,0));*/
			Invalid();
		}
		else if (message.channel == Core::Identifier("/notice"))//notice
		{
			strBuf.format(gLang->GetTextW(L"[֪ͨ]��%s"),message.msg);
			SysMessage	m;
			m.Text = strBuf;
			m.Times = 3;
			m_BigSpeakerMessage.Times = 0;
			m.Align = Unit::kAlignLeftMiddle;
			m.FontSize = 16;
			SetFontSize(m.FontSize);
			Core::Rectangle rect(0,0,0,0);
			m.TextRect = GetFont()->MeasureString(rect,m.Text,-1,m.Align);
			m.TextRect.Max.y = GetSize().y;
			m.PaintRect = m.TextRect;
			m.PaintRect.Min.y += 15; 
			m.TextColor =  ARGB(255, 255, 211, 78);
			m.PaintRect.Move(Vector2(GetSize().x,0));
			m_WarningMessageArray.Add(m);

			/*m_Icon = m_IconSpeaker;
			m_WarningMessage.Text = strBuf;
			m_WarningMessage.Timer = 10.f;
			m_BigSpeakerMessage.Timer = 0.f;
			SetFontSize(m_WarningMessage.FontSize);
			Core::Rectangle rect(0,0,0,0);
			m_WarningMessage.TextRect = GetFont()->MeasureString(rect,m_WarningMessage.Text,-1,m_WarningMessage.Align);
			m_WarningMessage.TextRect.Max.y = GetSize().y;
			m_WarningMessage.PaintRect = m_WarningMessage.TextRect;
			m_WarningMessage.TextColor = ARGB(255, 255, 255, 0);
			m_WarningMessage.PaintRect.Move(Vector2(GetSize().x, 0));*/
			Invalid();
		}
		else if (message.channel == Core::Identifier("/dlb") )
		{
			//strBuf.format("[%s]��%s",message.sender,message.msg);
			/*m_Icon = m_IconSpeaker;
			m_BigSpeakerMessage.Text = strBuf;
			m_BigSpeakerMessage.Timer = 5.f;
			SetFontSize(m_BigSpeakerMessage.FontSize);
			m_BigSpeakerMessage.PaintRect = GetClientRect();
			m_BigSpeakerMessage.PaintRect.Shrink(36,0,0,0);
			Invalid();*/

			EventHornMessage.Fire(ptr_static_cast<Self>(this),(Core::EventArgs &)NullPtr);
		}
		else if (message.channel == Core::Identifier("/xlb"))
		{
			//strBuf.format("[%s]��%s",message.sender,message.msg);
			EventSpeakerMessage.Fire(ptr_static_cast<Self>(this),(Core::EventArgs &)NullPtr);
		}
		else if (message.channel == Core::Identifier("/nba"))
		{
			//strBuf.format("[%s]��%s",message.sender,message.msg);
			EventSeverPresent.Fire(ptr_static_cast<Self>(this),(Core::EventArgs &)NullPtr);
		}
		else if (message.channel == Core::Identifier("/pic"))
		{
			strBuf.format("%s",m_SenderMessage);
			SysMessage	m;
			char* str;
			char* sub_str;
			Core::String Sstr;
			Core::String str_tex;
			int tep_i = 1;
			sub_str = strtok_s( strBuf.buff() ,"@!",&str);
			while(sub_str)
			{
				if (tep_i%2 == 0)
				{
					if (str_tex.Size() > 0)
					{
						str_tex = String::Format("%s%s",str_tex.Str(),sub_str);
					} 
					else
					{
						str_tex = sub_str;
					}
				}
				Sstr.Clear();
				Sstr = sub_str;
				m.ArString.Add(Sstr);
				sub_str = strtok_s( NULL ,"@!",&str);
				tep_i++;
			}
			m.Text = str_tex;
			m.Times = 1;
			m_BigSpeakerMessage.Times = 0;
			m.Align = Unit::kAlignLeftMiddle;
			m.FontSize = 16;
			SetFontSize(m.FontSize);
			Core::Rectangle rect(0,0,0,0);
			m.TextRect = GetFont()->MeasureString(rect,m.Text,-1,m.Align);
			m.TextRect.Max.y = GetSize().y;
			m.PaintRect = m.TextRect;
			m.PaintRect.Min.y += 15; 
			m.TextColor = ARGB(255, 255, 0, 0);
			m.PaintRect.Move(Vector2(GetSize().x,0));
			m.Text.Clear();
			m_WarningMessageArray.Add(m);
			Invalid();
		}
	}
}
