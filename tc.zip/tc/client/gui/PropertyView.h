namespace Gui
{
	struct PropertyViewNavigateEventArgs : public EventArgs
	{
		sharedc_ptr(ListItem)	Item;
		sharedc_ptr(void)		Value;
	};

	/// panel
	class PropertyView : public Control
	{
		DECLARE_PDE_OBJECT(PropertyView, Control)
	public:
		PropertyView();
		~PropertyView();

	public:
		DECLARE_PDE_EVENT(EventNavigate,		PropertyViewNavigateEventArgs);
		DECLARE_PDE_EVENT(EventResourceChange,	ListItemEventArgs);

	public:
		DECLARE_PDE_ATTRIBUTE_RW(ShowGroup,			bool);
		DECLARE_PDE_ATTRIBUTE_RW(SelectedObject,	sharedc_ptr(void));
		DECLARE_PDE_ATTRIBUTE_R (PropertyGrid,		sharedc_ptr(PropertyGrid)) { return m_Grid; }
		DECLARE_PDE_ATTRIBUTE_RW(ItemSkin,			tempc_ptr(ListItemSkin));
		DECLARE_PDE_ATTRIBUTE_RW(EditorTextboxStyle, const Core::String&);
		DECLARE_PDE_ATTRIBUTE_RW(EditorComboBoxStyle, const Core::String&);
		DECLARE_PDE_ATTRIBUTE_RW(EditorButtonStyle, const Core::String&);

		OVERRIDE_PDE_ATTRIBUTE_RW(Skin, tempc_ptr(ControlSkin));
		INLINE_PDE_ATTRIBUTE_R(Groups,		Core::Array<sharedc_ptr(PdePropertyItem)> &);

	public:
		virtual void OnCreate();

		virtual void OnDestroy();

		/// on update
		virtual void OnFrameUpdate(EventArgs & e);

		virtual void OnLayout(EventArgs & e);

		virtual void OnResourceChange(ListItemEventArgs & e);

		void Grid_OnItemChange(by_ptr(void) sender, ListItemEventArgs & e);

		void Grid_OnDoubleClick(by_ptr(void) sender, ListItemEventArgs & e);

		void Grid_OnExpand(by_ptr(void) sender, ListItemEventArgs & e);

		void Grid_OnSelectItemChange(by_ptr(void) sender, ListItemEventArgs & e);

	private:
		void UpdateProperties();

		void InvalidProperties();

		void SelectActiveControl();

		void ShowGroup(bool flag = true);

		void ClearGroup();

	public:
		void Refresh();

	private:
		sharedc_ptr(PropertyGrid)				m_Grid;
		sharedc_ptr(void)						m_SelectedObject;
		F64								m_TimeFlag;
		bool							m_ShowGroup		: 1;
		bool							m_Refresh		: 1;
		Core::Array<sharedc_ptr(PdePropertyItem)>	m_Properties;
		Core::Array<sharedc_ptr(PdePropertyItem)>	m_Groups;
		//HEdtUIColorSelect				m_ColorSelect;
	};
}