
namespace Gui
{
	class AnimControl;
	
	class CAnimation
	{
	public:
		class FrameImage
		{
		public:
			FrameImage() { NendStopped = false;}

			~FrameImage() {}

			sharedc_ptr(Gui::Image)				m_vFrame;

			BOOL								NendStopped;
		};

		CAnimation(const Core::String & value,float	m_fTime,int type);

		~CAnimation() 
		{ 
			m_FrameList.Clear();
		}
		
		
	    virtual void OnPaint(PaintEventArgs & e , const Core::Rectangle & rect);

		void DrawAnimation(PaintEventArgs & e , const Core::Rectangle & rect);

		void DrawZoomAnimation(PaintEventArgs & e , const Core::Rectangle & rect);

		void DrawScaleAnimation(PaintEventArgs & e , const Core::Rectangle & rect);
		
		void DrawTimerAnimation(PaintEventArgs & e , const Core::Rectangle & rect);
		
		void DrawTurnCardAnimation(PaintEventArgs & e , const Core::Rectangle & rect);
		
		void DrawTurnAround(PaintEventArgs & e , const Core::Rectangle & rect);

		void DrawFlipAnimation(PaintEventArgs & e , const Core::Rectangle & rect);

		void DrawScrollableNum(PaintEventArgs & e , const Core::Rectangle & rect);
		
		void SetScrollParam(uint score,uint bit);

		void SetFlipTimer(float accTime,float avgTime,float decTime);
		
		int ScrollAnimation(uint StopSpeed,uint framesize = 10);

		int ScrollAnimationTwo(uint StopSpeed,uint framesize = 2);

		int GetNewDsiance(int A,int MaxSpeed);

		void GetProperRect(const Core::Rectangle &rect1, const Core::Rectangle &rect2, Core::Rectangle &resultRect);

		Core::String GetAnimationName() { return m_AnimationName;}

		void SetParent(AnimControl* Parent) { m_parent = Parent;}
		
		void		SetTimer(float fTimer)		{ m_frameTime = fTimer;}

		bool		IsFinish()			{ return m_isFinish; }

		void		AddFrame(by_ptr(Image) Animframe,BOOL NeedStopped = FALSE);
		void		DeleteFrameList()	{ m_FrameList.Clear(); }
		
		void		StartDraw();

		void		ReStart();
		
		void		TurnCard();

		void		TrunCardContiue();

		sharedc_ptr(CAnimation)							next;
	
	private:
		sharedc_ptr(FrameImage)				m_frameImage;
		sharedc_ptr(FrameImage)				m_rootFrame;
		AnimControl*						m_parent;
		Core::Array<sharedc_ptr(FrameImage)>	m_FrameList;
		Core::String						m_AnimationName;
		F32									m_TimeToStopSroll;
		F32									m_TimeToStartDis[20];
		uint								m_totalstep;
		F64									m_Timer;
		F64									m_TimerScale;
		F64									m_TurnTime;
		F64									m_decelerateTime;
		F64									m_TimerAnimation;
		F64									m_accTime;
		F64									m_avgTime;
		F64									m_decTime;
		U32									m_currentFrame;
		U32									m_stoppedFrame;
		uint								m_score;
		uint								m_bit;
		float								m_frameTime;
		float								m_stopTime;
		float								m_scaleRatio;
		float								m_imageRatio;
		float								m_changeRatio;
		bool								m_needChange;
		bool								m_isFinish;
		bool								m_start;
		bool								m_turnCard;
		int									m_type;
		int									m_displacement;
		bool								m_isFirst;
		bool								m_TurnCardIsContiue;
	};
}

namespace Gui
{
	class AnimControl: public Button
	{
		DECLARE_PDE_OBJECT(AnimControl, Button)
	public:
		DECLARE_PDE_EVENT(EventClick,	Client::InputEventArgs);
		DECLARE_PDE_EVENT(EventFinish,	Client::InputEventArgs);
		DECLARE_PDE_EVENT(EventTimeHide,	Core::EventArgs);
		DECLARE_PDE_ATTRIBUTE_RW(PushDown,		bool);
	public:

		void AddAnim(const Core::String & value,float fTime,int type);

		void AddFrame(const Core::String & value, by_ptr(Image) frame,BOOL NeedStopped = FALSE);
		void DeleteFrameList(const Core::String & value);

		void SetAnimationTimer(const Core::String & value,float fTime);
		
		void DeleteAnimation(const Core::String & value);

		void StartAnimation();
		
		void ClearAll();

		void ReStart();

		bool isFinish();

		void TimeToHide();

		void TurnCard();

		void TrunCardContiue();
		
		void StopAnimation();

		void SetScrollParam(const Core::String & value,uint score,uint bit);
		
		void SetFlipTimer(const Core::String & value,float accTime,float avgTime,float decTime);

		sharedc_ptr(CAnimation) GetAnimationByName(const Core::String & value);

	public:
		AnimControl();

		~AnimControl();

		virtual void OnPaint(PaintEventArgs & e);

		virtual void OnInputEvent(Client::InputEventArgs & e);
		
		virtual void OnClick(Client::InputEventArgs &e);
	private:
		bool						m_start;
		bool						m_fired;
		U32							m_currAnim;
		U32							m_AnimationSize;

		sharedc_ptr(CAnimation)		m_Animation;
		sharedc_ptr(CAnimation)		m_RootAnimation;
		
		bool						m_usetimer;
		float						m_time;
	};
}
