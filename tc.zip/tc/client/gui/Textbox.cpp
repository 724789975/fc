#include "pch.h"

using namespace Core;
using namespace Client;

//--------------------------------------------------------------------------------------
// typeinfo
//--------------------------------------------------------------------------------------
DEFINE_PDE_TYPE_CLASS(Gui::TextboxSkin)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::ControlSkin);

		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_PROPERTY_RW(ActiveImage);
		ADD_PDE_PROPERTY_RW(DisabledImage);
		ADD_PDE_PROPERTY_RW(TextColor);
	}
};

DEFINE_PDE_TYPE_CLASS(Gui::Textbox)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::Control);

		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_PROPERTY_RW(Readonly);
		ADD_PDE_PROPERTY_RW(InputNumberOnly);
		ADD_PDE_PROPERTY_RW(InputNumberCharacterOnly);
		ADD_PDE_PROPERTY_RW(TextPadding);
		ADD_PDE_PROPERTY_RW(MaxLength);
		ADD_PDE_PROPERTY_RW(TextAutoSize);
		ADD_PDE_PROPERTY_RW(TextAutoSizeMaxWidth);
		ADD_PDE_PROPERTY_RW(SelectionColor);
		ADD_PDE_PROPERTY_RW(SelectionBgColor);
		ADD_PDE_PROPERTY_RW(TextPassword);
		ADD_PDE_PROPERTY_RW(TBSkin);
		ADD_PDE_EVENT(EventValueEnter);
		ADD_PDE_EVENT(EventValueNoNumber);
		ADD_PDE_EVENT(EventTextChanged);
		ADD_PDE_EVENT(EventLengthExceed);
	}
};

REGISTER_PDE_TYPE(Gui::Textbox);
REGISTER_PDE_TYPE(Gui::TextboxSkin);


//--------------------------------------------------------------------------------------
// constructor.
//--------------------------------------------------------------------------------------
namespace Gui
{
	Textbox::Textbox()
		: m_Readonly(false)
		, m_BorderVisible(true)
		, m_CursorVisible(false)
		, m_ScrollX(0)
		, m_MaxLength(128)
		, m_CursorTime(0)
		, m_TextAutoSize(false)
		, m_TextAutoSizeMaxWidth(100.f)
		, m_UndoHistory(true)
		, m_Password(false)
		, m_TextPadding(2,2,2,2)
		, m_InputNumberOnly(false)
		, m_InputNumberCharacterOnly(false)
	{
		SetTextBuffer( &m_Text );
		SetBackgroundColor(XRGB(255,255,255));
		SetSelectionColor(XRGB(255, 255, 255));
		SetSelectionBgColor(XRGB(49, 106, 197));
	}

	Textbox::~Textbox()
	{
	}
}

//--------------------------------------------------------------------------------------
// Attribute
//--------------------------------------------------------------------------------------
namespace Gui
{
	PDE_ATTRIBUTE_GETTER(Textbox, Readonly, bool)
	{
		return m_Readonly;
	}


	PDE_ATTRIBUTE_SETTER(Textbox, Readonly, bool)
	{
		if (m_Readonly != value)
		{
			m_Readonly = value;
			Invalid();
		}
	}
	
	PDE_ATTRIBUTE_GETTER(Textbox, InputNumberOnly, bool)
	{
		return m_InputNumberOnly;
	}


	PDE_ATTRIBUTE_SETTER(Textbox, InputNumberOnly, bool)
	{
		if (m_InputNumberOnly != value)
		{
			m_InputNumberOnly = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(Textbox, InputNumberCharacterOnly, bool)
	{
		return m_InputNumberCharacterOnly;
	}


	PDE_ATTRIBUTE_SETTER(Textbox, InputNumberCharacterOnly, bool)
	{
		if (m_InputNumberCharacterOnly != value)
		{
			m_InputNumberCharacterOnly = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(Textbox, TBSkin,tempc_ptr(Gui::TextboxSkin))
	{
		return m_TBSkin;
	}


	PDE_ATTRIBUTE_SETTER(Textbox, TBSkin, tempc_ptr(Gui::TextboxSkin))
	{
		if (m_TBSkin != value)
		{
			m_TBSkin = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(Textbox, MaxLength, U32)
	{
		return m_MaxLength;
	}


	PDE_ATTRIBUTE_SETTER(Textbox, MaxLength, U32)
	{
		if (m_MaxLength != value)
		{
			m_MaxLength = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(Textbox, TextPadding, Vector4)
	{
		return m_TextPadding;
	}

	PDE_ATTRIBUTE_SETTER(Textbox, TextPadding, Vector4)
	{
		if(m_TextPadding!=value)
		{
			m_TextPadding = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_SETTER(Textbox, Text, const String &)
	{
		m_Text = value;
		SetCursorPosition(-1, false);
		OnTextChanged(Core::EventArgs());
	}

	PDE_ATTRIBUTE_GETTER(Textbox, TextAutoSize, bool)
	{
		return m_TextAutoSize;
	}


	PDE_ATTRIBUTE_SETTER(Textbox, TextAutoSize, bool)
	{
		if (m_TextAutoSize != value)
		{
			m_TextAutoSize = value;
			OnTextAutoSize();
		}
	}

	PDE_ATTRIBUTE_GETTER(Textbox, TextAutoSizeMaxWidth, F32)
	{
		return m_TextAutoSizeMaxWidth;
	}


	PDE_ATTRIBUTE_SETTER(Textbox, TextAutoSizeMaxWidth, F32)
	{
		if (m_TextAutoSizeMaxWidth != value)
		{
			m_TextAutoSizeMaxWidth = value;
			OnTextAutoSize();
		}
	}

	PDE_ATTRIBUTE_GETTER(Textbox, SelectionColor, ARGB)
	{
		return m_SelectionColor;
	}

	PDE_ATTRIBUTE_SETTER(Textbox, SelectionColor, ARGB)
	{
		if (m_SelectionColor != value)
		{
			m_SelectionColor = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(Textbox, SelectionBgColor, ARGB)
	{
		return m_SelectionBgColor;
	}

	PDE_ATTRIBUTE_SETTER(Textbox, SelectionBgColor, ARGB)
	{
		if (m_SelectionBgColor != value)
		{
			m_SelectionBgColor = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(Textbox, TextPassword, bool)
	{
		return m_Password;
	}

	PDE_ATTRIBUTE_SETTER(Textbox, TextPassword, bool)
	{
		m_Password = value;
	}

	PDE_ATTRIBUTE_SETTER(Textbox, TabFocus, Core::Bool)
	{
		Super::SetTabFocus(value);
		if(value)
		{
			SetAcceptTab(false);
		}
	}
}

//--------------------------------------------------------------------------------------
// Event
//--------------------------------------------------------------------------------------
namespace Gui
{
	/// on frame update
	void Textbox::OnFrameUpdate(EventArgs & e)
	{
		bool showCursor = false;

		if (GetFocused())
			showCursor = GetFocused() && ((static_cast<U32>((Core::Task::GetTotalTime() - m_CursorTime) * 2) & 1) == 0);

		if (m_CursorVisible != showCursor)
		{
			m_CursorVisible = showCursor;
			Invalid();
		}
	}


	/// on paint
	void Textbox::OnPaint(PaintEventArgs & e)
	{
		Control::OnPaint(e);

		// control rectangle
		Core::Rectangle clientRect(Vector2::kZero, GetSize());

		// move client rect
		clientRect.Shrink(GetTextPadding());

		// draw input text
		clientRect.Move(Vector2(-m_ScrollX, 0));

		// padding center
		Vector2 location(clientRect.Min.x, 0);
		location.y = Floor((clientRect.Max.y + clientRect.Min.y - GetFont()->GetLineHeight()) / 2);

		tempc_ptr(TextboxSkin) skin = ptr_static_cast<TextboxSkin>(GetSkin());
		

		if (skin)
		{
			if(e.Enable)
			{
				if (GetFocused())
				{
					//Skin::DrawImage(e.render, skin->GetActiveImage(), GetBackgroundRect(), m_BackgroundColor);
				}
				DrawInputText(e.render, location, clientRect, GetTextColor(), GetSelectionColor(), GetSelectionBgColor(), m_CursorVisible, GetFocused(), GetFont(),false,m_Password);
			}
			else
			{
				//Skin::DrawImage(e.render, skin->GetDisabledImage(), GetBackgroundRect(), m_BackgroundColor);
				DrawInputText(e.render, location, clientRect, GetDisabledTextColor(), GetSelectionColor(), GetSelectionBgColor(), m_CursorVisible, GetFocused(), GetFont(),false,m_Password);
			}
		}
		else
		{
			Control::OnPaint(e);
			DrawInputText(e.render, location, clientRect, GetTextColor(), GetSelectionColor(), GetSelectionBgColor(), m_CursorVisible, GetFocused(), GetFont(),false,m_Password);
		}
	}


	/// on input event
	void Textbox::OnInputEvent(InputEventArgs& e)
	{
		if (e.IsKeyEvent())
		{
			if (e.Type == InputEventArgs::kKeyDown)
			{
				if (GetReadonly())
				{
					switch (e.Code)
					{
					case KC_RETURN:
					case KC_NUMPADENTER:
					case KC_BACK:
					case KC_DELETE:
					case KC_X:
					case KC_V:
						e.Handled = true;
						return;
					}
				}
				else
				{
					// undo / redo
					if (e.ControlKeyDown && e.Code == KC_Z)
					{
						ResetHistory();
						DoHistory(m_InputHistory, m_UndoHistory);
						m_UndoHistory = !m_UndoHistory;
						e.Handled = true;
					}
				}
			}

			if (m_InputNumberOnly)
			{
				if ((e.Value < '0' || e.Value > '9') && e.Code != KC_BACK)
				{
					OnValueNoNumber(Core::EventArgs());
					e.Handled = true;
					return;
				}
			}

			if (m_InputNumberCharacterOnly)
			{
				if ( e.Code != KC_BACK && (!((e.Value >= 'A' && e.Value <= 'Z') || (e.Value >= 'a' && e.Value <= 'z') || (e.Value >= '0' && e.Value <= '9'))) )
				{
					e.Handled = true;
					return;
				}
			}

			if (e.Type == InputEventArgs::kChar)
			{
				if (e.Value == '\r' || e.Value == '\n')
				{
					OnValueEnter(Core::EventArgs());
					e.Handled = true;
					return;
				}

				if (GetReadonly())
				{
					e.Handled = true;
					return;
				}
			}

			if (!e.Handled)
			{
				if (OnKeyEvent(e, GetReadonly()))
				{
					e.Handled = true;
				}

				if (GetTextAutoSize())
					OnTextAutoSize();
			}
		}

		if (e.IsMouseEvent())
		{
			// client pos
			Vector2 pos = ScreenToClient(e.CursorPosition);

			if (GetSelecting() || GetDisplayRect().IsPointInside(pos))
			{
 				SetCursorShape(Screen::kCursorInput);

				// to text space
				pos.x = pos.x - GetTextPadding().x + m_ScrollX;
				pos.y = pos.y - GetTextPadding().y;

				if (OnMouseEvent(e, pos, GetFont()))
				{
					e.Handled = true;
					SetCapture(GetSelecting());
				}
			}

			if (e.Type == InputEventArgs::kMouseMove && !(e.LeftButtonDown || e.MiddleButtonDown || e.RightButtonDown))
				e.Handled = true;

			if (e.Type == InputEventArgs::kMouseEnter || e.Type == InputEventArgs::kMouseLeave)
				e.Handled = false;
		}

		if (!e.Handled)
			Control::OnInputEvent(e);
	}

	/// on text changed
	void Textbox::OnTextChanged(Core::EventArgs & e)
	{
		if (m_MaxLength > 0)
		{
			if (m_Text.Length() > m_MaxLength)
			{
				CRefStr & str = m_Text.RefStr(0);
				str.setlen(m_MaxLength);
				str.validate();
				SetCursorPosition(GetCursorPosition());
				EventLengthExceed.Fire(ptr_static_cast<Textbox>(this), Core::EventArgs());
			}
		}
		
		if (GetTextAutoSize())
			OnTextAutoSize();

		EventTextChanged.Fire(ptr_static_cast<Textbox>(this), e);
		Invalid();
	}

	/// on cursor move
	void Textbox::OnCursorMove(Core::EventArgs & e)
	{
		// update cursor
		m_CursorTime = Core::Task::GetTotalTime();

		// update scroll
		Vector2 cursorPos, textLen;
		F32 size = GetDisplayRect().GetExtent().x - GetTextPadding().x - GetTextPadding().z - 1;

		if (GetFont()->CPtoX(m_Text.Str(), GetCursorPosition(), cursorPos))
		{
			if (cursorPos.x < m_ScrollX)
			{
				m_ScrollX = cursorPos.x;
			}
			else if (cursorPos.x > m_ScrollX + size)
			{
				m_ScrollX = cursorPos.x - size;

				if (m_ScrollX < 0)
					m_ScrollX = 0;
			}

			if (GetFont()->CPtoX(m_Text.Str(), m_Text.Length(), textLen))
			{
				if (textLen.x < m_ScrollX + size)
					m_ScrollX = textLen.x - size;

				if (m_ScrollX < 0)
					m_ScrollX = 0;
			}
		}

		Vector2 caret_pos = ClientToScreen(Vector2(cursorPos.x - m_ScrollX, 0));

		// HACK : window
		sharedc_ptr(Window) window = ptr_dynamic_cast<Window>(GetRoot());
		if (window)
		{
			caret_pos += window->GetWorldLocation().xy;
		}

		ImeUi_SetCaretPosition(caret_pos.x, caret_pos.y);


		Invalid();
	}

	void Textbox::OnLeave(Core::EventArgs & e)
	{
		Invalid();

		Control::OnLeave(e);

		//if (!GetReadonly())
		//{
		//	OnValueEnter(e);
		//}
	}

	void Textbox::OnValueEnter(Core::EventArgs & e)
	{
		EventValueEnter.Fire(ptr_static_cast<Textbox>(this), e);

		//SetSelection(0, -1);
	}

	void Textbox::OnValueNoNumber(Core::EventArgs & e)
	{
		EventValueNoNumber.Fire(ptr_static_cast<Textbox>(this), e);
	}

 	void Textbox::OnLayout(Core::EventArgs & e)
 	{
 		Control::OnLayout(e);
 		OnCursorMove(e);
 	}

	/// on new history
	void Textbox::OnHistoryReset(InputHistory & e)
	{
		m_InputHistory = e;
		m_UndoHistory = true;
	}	

	void Textbox::OnTextAutoSize()
	{
		tempc_ptr(Font) font = GetFont();
		PDE_ASSERT(font, "No font?");
		//Minimum size for text box
		F32 width = GetSize().y;
		const String * str = GetTextBuffer();

		if(str)
		{
			const char* text = str->RefStr();
			if (text && text[0])
			{
				//Calculate Text display size
				Vector2 size = font->MeasureString(Core::Rectangle(0,0,0,0), text).GetExtent();
				size.x += 10;
				width = Max(width, size.x);
			}
		}

		width = Min(width, GetTextAutoSizeMaxWidth());

		SetSize(Vector2(width, GetSize().y));
	}

	void Textbox::OnFocusChanged(EventArgs & e)
	{
		Control::OnFocusChanged(e);
		if (GetFocused())
		{
			ImeUi_EnableIme(true);
			SelectAll();
		}
		else
		{
			ImeUi_FinalizeString();
			ImeUi_EnableIme(false);
		}
	}
}