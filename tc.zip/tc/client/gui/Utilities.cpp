#include "pch.h"

using namespace Core;
using namespace Client;


namespace Gui
{
	MoveController::MoveController()
		: m_Offset(0, 0)
		, m_Snap(0, 0)
	{
		
	}


	void MoveController::BeginMove(by_ptr(Control) control, const Vector2 & cursorPosition)
	{
		if (m_Control == control)
			return;

		EndMove();

		m_Control = control;

		if (m_Control)
		{
			m_Control->SetCapture(true);
			m_Offset = m_Control->GetLocation() - cursorPosition;
		}
	}


	void MoveController::EndMove()
	{
		if (m_Control)
		{
			m_Control->SetCapture(false);
		}

		m_Control = NullPtr;
	}


	bool MoveController::ProcessInputEvent(InputEventArgs & e)
	{
		if (!m_Control)
			return false;

		if (e.Type == InputEventArgs::kMouseMove)
		{
			Vector2 position = m_Offset + e.CursorPosition;

			if (m_Snap.x > 0)
				if (position.x > 0)
					position.x -= Fmod(position.x + m_Snap.x / 2, m_Snap.x) - m_Snap.x / 2;
				else
					position.x -= Fmod(position.x - m_Snap.x / 2, m_Snap.x) + m_Snap.x / 2;

			if (m_Snap.y > 0)
				if (position.y > 0)
					position.y -= Fmod(position.y + m_Snap.y / 2, m_Snap.y) - m_Snap.x / 2;
				else
					position.y -= Fmod(position.y - m_Snap.y / 2, m_Snap.y) + m_Snap.x / 2;

			OnMove(position);
			e.Handled = true;
		}

		return e.Handled;
	}


	void MoveController::OnMove(const Vector2 & position)
	{
		if (m_Control)
			m_Control->SetLocation(position);
	}
}


namespace Gui
{
	SizeController::SizeController()
		: m_StartPoint(0, 0)
		, m_StartSize(0, 0)
		, m_ControlPoint(kLeftTop)
	{
	}



	// begin scale
	void SizeController::BeginScale(by_ptr(Control) control, const Vector2 & cursorPosition, ControlPoint point)
	{
		if (m_Control == control)
			return;

		EndScale();

		m_Control = control;
		m_ControlPoint = point;

		if (m_Control)
		{
			m_StartPoint = cursorPosition;
			m_StartSize = m_Control->GetSize();
			m_Control->SetCapture(true);
		}
	}


	// end scale
	void SizeController::EndScale()
	{
		if (m_Control)
		{
			m_Control->SetCapture(false);
		}

		m_Control = NullPtr;
	}


	// process event
	bool SizeController::ProcessInputEvent(InputEventArgs & e)
	{
		if (!m_Control)
			return false;

		if (e.Type == InputEventArgs::kMouseMove)
		{
			static const Vector2 limit[] = {
				Vector2(-1, -1), Vector2(0, -1), Vector2(1, -1), 
				Vector2(-1, 0), Vector2(1, 0), 
				Vector2(-1, 1), Vector2(0, 1), Vector2(1, 1),
			};

			OnScale(m_StartSize + (e.CursorPosition - m_StartPoint) * limit[m_ControlPoint]);		
			e.Handled = true;
		}

		return e.Handled;
	}


	// move control
	void SizeController::OnScale(const Vector2 & size)
	{
		if (m_Control)
		{
			Vector2 oldSize = m_Control->GetSize();
			m_Control->SetSize(size);
			Vector2 newSize = m_Control->GetSize();

			static const Vector2 move[] = {
				Vector2(1, 1), Vector2(0, 1), Vector2(0, 1), 
				Vector2(1, 0), Vector2(0, 0), 
				Vector2(1, 0), Vector2(0, 0), Vector2(0, 0),
			};

			Vector2 newPos = m_Control->GetLocation() - (newSize - oldSize) * move[m_ControlPoint];					
			m_Control->SetLocation(newPos);
		}
	}
}

DEFINE_PDE_TYPE_CLASS(Gui::StyleChangeEventArgs)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_FIELD(control);
		ADD_PDE_FIELD(style);
	}
};

DEFINE_PDE_TYPE_CLASS(Gui::ListItemEventArgs)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(EventArgs);

		ADD_PDE_FIELD(Item);
		ADD_PDE_FIELD(Column);
		ADD_PDE_FIELD(Flag);
	}
};

DEFINE_PDE_TYPE_CLASS(Gui::ListItemInputEventArgs)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(InputEventArgs);

		ADD_PDE_FIELD(Item);
		ADD_PDE_FIELD(Column);
	}
};

DEFINE_PDE_TYPE_CLASS(Gui::MsgSendEventArgs)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(EventArgs);
		ADD_PDE_FIELD(ChannelID);
		ADD_PDE_FIELD(From);
		ADD_PDE_FIELD(To);
		ADD_PDE_FIELD(Content);
	}
};

DEFINE_PDE_TYPE_CLASS(Gui::HeaderEventArgs)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(EventArgs);
		ADD_PDE_FIELD(Column);
	}
};


DEFINE_PDE_TYPE_CLASS(Gui::TabChangedEventArgs)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(ValueChangeEventArgs);

		ADD_PDE_FIELD(byUserOp);
	}
};

DEFINE_PDE_TYPE_CLASS(Gui::MessageEventArgs)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Core::EventArgs);

		ADD_PDE_FIELD(Message);
	}
};

REGISTER_PDE_TYPE(Gui::StyleChangeEventArgs);
REGISTER_PDE_TYPE(Gui::ListItemEventArgs);
REGISTER_PDE_TYPE(Gui::ListItemInputEventArgs);
REGISTER_PDE_TYPE(Gui::MsgSendEventArgs);
REGISTER_PDE_TYPE(Gui::HeaderEventArgs);
REGISTER_PDE_TYPE(Gui::TabChangedEventArgs);
REGISTER_PDE_TYPE(Gui::MessageEventArgs);