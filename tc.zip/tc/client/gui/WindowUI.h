namespace Gui
{
	class WindowUI : public Window	
	{
	public:
		friend class GuiSystem;

		DECLARE_PDE_OBJECT(WindowUI, Window);

	public:
		enum FadeState
		{
			kNormal = 0,
			kFading = 1,
			kShowing =2,
			kImpossible,
		};
	public:
		WindowUI();
		~WindowUI();

	public:
		DECLARE_PDE_EVENT(EventClose, Core::EventArgs);

		DECLARE_PDE_ATTRIBUTE_RW(ShowCloseButton, bool);
		DECLARE_PDE_ATTRIBUTE_RW(CloseButtonStyle, const Core::String &);
		DECLARE_PDE_ATTRIBUTE_R (DuringFading, bool);
		DECLARE_PDE_ATTRIBUTE_R (DuringShowing, bool);
		OVERRIDE_PDE_ATTRIBUTE_W(Size,			Core::Vector2);
		OVERRIDE_PDE_ATTRIBUTE_W(Location,		Core::Vector2);
		INLINE_PDE_ATTRIBUTE_RW(IconA,			tempc_ptr(Icon));
		INLINE_PDE_ATTRIBUTE_RW(IconB,			tempc_ptr(Icon));

	public:
		// on create
		virtual void OnCreate();

		// on frame update
		virtual void OnFrameUpdate(EventArgs & e);

		// on paint
		virtual void OnPaint(PaintEventArgs & e);

		// on close
		virtual void OnClose(Core::EventArgs& e);

		virtual void Show(U32 mode = 0);

		virtual void Hide(U32 mode = 0);

		virtual void DisconnectContent();

		virtual void SetScreenPos(U32 anchor, F32 uv_u, F32 uv_v);

		// on layout
		virtual void OnLayout(EventArgs & e);

		void OnCloseButtonClick(by_ptr(void) sender, InputEventArgs & e);

	protected:
		void RepositionCloseButton();

		Core::Vector3 GetFixedPosition(U32 anchor, F32 uv_u, F32 uv_v);

	protected:
		sharedc_ptr(Button)	m_CloseButton;
		bool				m_ShowCloseButton;

		F32					m_Fade;
		U32					m_FadeMode;
		FadeState			m_State;	//0:normal 1:fade 2:show

		U32					m_ScreenAnchor;
		F32					m_ScreenU;
		F32					m_ScreenV;

		//For trans-animation
		Core::Vector3		m_FixedPosition;
		//Not necessary, just for convenience
		Core::Vector3		m_TargetPosition;

		sharedc_ptr(Icon)	m_IconA;
		sharedc_ptr(Icon)	m_IconB;
	};
}

namespace Gui
{
	class FadingWindowUI : public WindowUI
	{
	public:
		DECLARE_PDE_OBJECT(FadingWindowUI, WindowUI);

	public:
		FadingWindowUI();
		~FadingWindowUI();

		// on frame update
		virtual void OnFrameUpdate(EventArgs & e);

		virtual void OnMouseEnter(InputEventArgs & e);

		virtual void OnMouseLeave(InputEventArgs & e);

		virtual bool IsActive();

		// render
		virtual void Render(RenderEventArgs & e);

	protected:
		bool	m_MouseIn;
	};
}

namespace Gui
{
	class TimerWindowUI : public WindowUI
	{
	public:
		DECLARE_PDE_OBJECT(TimerWindowUI, WindowUI);

		DECLARE_PDE_EVENT(EventTimeUp, Core::EventArgs);

		DECLARE_PDE_ATTRIBUTE_RW(Timer, F32);
		DECLARE_PDE_ATTRIBUTE_RW(AutoStart, bool);

	public:
		TimerWindowUI();
		~TimerWindowUI();

		// on frame update
		virtual void OnFrameUpdate(EventArgs & e);

		void	Start();

		void	Reset();

	protected:
		bool	m_Started;
		bool	m_AutoStart;
		F32		m_Timer;
		F32		m_TimeRunning;
	};
}

namespace Gui
{
	class PagedWindowUI : public WindowUI
	{
	public:
		friend class GuiSystem;

		DECLARE_PDE_OBJECT(PagedWindowUI, WindowUI);
	public:
		PagedWindowUI();
		~PagedWindowUI();

	public:
		DECLARE_PDE_ATTRIBUTE_R (Container, tempc_ptr(Tabpad));
		DECLARE_PDE_ATTRIBUTE_RW(TabStyle, const Core::String &);

	public:
		// on create
		virtual void OnCreate();

		tempc_ptr(Control)	AddPage(const Core::String& pageTitle);
		tempc_ptr(Control)	AddExistedPage(tempc_ptr(Tabpage) page);
		tempc_ptr(Control)	GetPageByIndex(U32 index);
		tempc_ptr(Control)	GetPageByTitle(const Core::String& pageTitle);
		bool				RemovePageByIndex(U32 index);
		bool				RemovePageByTitle(const Core::String& pageTitle);
		bool				SetActivePageByIndex(U32 index);
		bool				SetActivePageByTitle(const Core::String& pageTitle);
		void				SetFirstPageActive();
		void				SetLastPageActive();

	protected:
		sharedc_ptr(Tabpad)	m_Tabpad;
	};
}