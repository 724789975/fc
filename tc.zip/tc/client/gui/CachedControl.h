namespace Gui
{
	class CachedControl : public Control	
	{
		DECLARE_PDE_OBJECT(CachedControl, Control);

	public:
		// constructor.
		CachedControl();

		// destructor.
		~CachedControl();

		// on create
		void OnCreate();

		// on destroy
		void OnDestroy();

		// on paint
		void OnPaint(PaintEventArgs & e);

		// on size changed
		void OnSizeChanged(ResizeEventArgs & e);

		// render
		void Render(RenderEventArgs & e);

		//screen to local
		Core::Vector2 ScreenToClient(const Core::Vector2 & pos);

		// local to screen
		Core::Vector2 ClientToScreen(const Core::Vector2 & pos);
		
	private:
		sharedc_ptr(Client::TextureBase)	m_Texture;
	};
}