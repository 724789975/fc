namespace Gui
{
	class ComboBoxSkin : public ControlSkin
	{
	public:
		ComboBoxSkin()
		{}

	public:
		INLINE_PDE_ATTRIBUTE_RW(ButtonNormalImage,		tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(ButtonHoverImage,		tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(ButtonDownImage,		tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(ButtonDisabledImage,		tempc_ptr(Image));

		INLINE_PDE_ATTRIBUTE_RW(TextNormalImage,		tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(TextHoverImage,			tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(TextDownImage,			tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(TextDisabledImage,		tempc_ptr(Image));

	private:
		sharedc_ptr(Image) m_ButtonNormalImage;
		sharedc_ptr(Image) m_ButtonHoverImage;
		sharedc_ptr(Image) m_ButtonDownImage;
		sharedc_ptr(Image) m_ButtonDisabledImage;

		sharedc_ptr(Image) m_TextNormalImage;
		sharedc_ptr(Image) m_TextHoverImage;
		sharedc_ptr(Image) m_TextDownImage;	
		sharedc_ptr(Image) m_TextDisabledImage;
	};
}

namespace Gui
{
	/// base class of ui elements
	class  ComboBox : public Control, public TextInput
	{
		DECLARE_PDE_OBJECT(ComboBox, Control)
	public:		
		enum PopupDirection
		{
			kPopupBottom,
			kPopupTop,
			kPopupRight,
		};

	public:
		DECLARE_PDE_EVENT(EventValueChanged,		EventArgs);
		DECLARE_PDE_EVENT(EventItemSelected,		EventArgs);
		DECLARE_PDE_EVENT(EventClick,				EventArgs);
		DECLARE_PDE_EVENT(EventLengthExceed,		Core::EventArgs);

	public:
		DECLARE_PDE_ATTRIBUTE_RW(Readonly,			bool);
		DECLARE_PDE_ATTRIBUTE_RW(Popup,				PopupDirection);
		DECLARE_PDE_ATTRIBUTE_RW(SelectedIndex,		S32);
		DECLARE_PDE_ATTRIBUTE_RW(PushDown,			bool); 
		DECLARE_PDE_ATTRIBUTE_RW(LikeButton,		bool);
		DECLARE_PDE_ATTRIBUTE_R	(ItemCount,			U32);
		DECLARE_PDE_ATTRIBUTE_RW(MaxLength,			U32);

		DECLARE_PDE_ATTRIBUTE_RW(ChildComboListStyle, const Core::String &); 

		/// dropdown size
		DECLARE_PDE_ATTRIBUTE_RW(VScrollBarWidth,	F32);
		DECLARE_PDE_ATTRIBUTE_RW(HScrollBarWidth,	F32);
		//DECLARE_PDE_ATTRIBUTE_RW(HScrollBarButtonSize,	F32);
		//DECLARE_PDE_ATTRIBUTE_RW(VScrollBarButtonSize,	F32);
		DECLARE_PDE_ATTRIBUTE_RW(DropDownHeight,	U32);
		DECLARE_PDE_ATTRIBUTE_RW(DropDownWidth,		U32);
		DECLARE_PDE_ATTRIBUTE_RW(TextPadding,		Core::Vector4);
		DECLARE_PDE_ATTRIBUTE_RW(TextAlign,			Client::Unit::Align);
		DECLARE_PDE_ATTRIBUTE_R (Opened,			bool);
		DECLARE_PDE_ATTRIBUTE_RW(SelectedTextColor,	Core::ARGB);
		DECLARE_PDE_ATTRIBUTE_RW(HoverTextColor,	Core::ARGB);
		DECLARE_PDE_ATTRIBUTE_RW(WithIconOffset,	Core::Vector2);

		OVERRIDE_PDE_ATTRIBUTE_W(BackgroundColor,	Core::ARGB);
		OVERRIDE_PDE_ATTRIBUTE_W(TextColor,			Core::ARGB);
		OVERRIDE_PDE_ATTRIBUTE_R(Active,			bool);
		OVERRIDE_PDE_ATTRIBUTE_RW(Text,				const Core::String &);
		OVERRIDE_PDE_ATTRIBUTE_R(DefaultSize,		Core::Vector2) { return Core::Vector2(60, 20); }
		OVERRIDE_PDE_ATTRIBUTE_R(DisplayPadding,	Core::Vector4);

	public:
		///constructor
		ComboBox();

		///destructor
		~ComboBox();

	public:
		/// on create
		virtual void OnCreate();

		/// on layout
		virtual void OnLayout(EventArgs & e);

		/// on paint client
		virtual void OnPaint(PaintEventArgs & e);

		/// on input event
		virtual void OnInputEvent(InputEventArgs & e);

		/// on key event
		virtual void OnKeyEvent(InputEventArgs & e);

		/// on active changed
		virtual void OnActiveChanged(EventArgs & e);

		/// on value changed
		virtual void OnValueChanged(EventArgs & e);

		/// on text changed
		virtual void OnTextChanged(Core::EventArgs & e);

		///// on double click
		//virtual void OnDoubleClick(InputEventArgs & e);

		/// on item selected
		virtual void OnItemSelected(EventArgs & e);

		// frame update
		virtual void OnFrameUpdate(Core::EventArgs & e);

		/// on cursor move
		virtual void OnCursorMove(Core::EventArgs & e);

		/// on value enter
		virtual void OnValueEnter(Core::EventArgs & e);

		// on leave
		virtual void OnLeave(EventArgs & e);

		/// on focus changed
		virtual void OnFocusChanged(EventArgs & e);

	public:
		/// add item
		S32 AddItem(const Core::String & item);

		/// add item
		S32 AddItemWithIcon(const Core::String & item,int index);

		void SetItemDisable(S32 index, bool flag);

		/// insert item
		S32 InsertItem(S32 index, const Core::String & item);

		/// remove item
		void RemoveItem(S32 index);

		/// remove all
		void RemoveAll();

		/// move item
		void MoveItem(S32 index, S32 newIndex);

		/// get id
		S32 GetId(S32 index);

		/// set id
		void SetId(S32 index, S32 id);

		/// text to index
		S32 TextToIndex(const Core::String & text);

		/// get item
		const Core::String & GetItem(S32 index = Gui::ComboList::INDEX_NONE);

		/// select next
		void SelectNext(bool loop = true);

		/// select previous
		void SelectPrev(bool loop = true);

	private:
		void ComboList_OnListClick(by_ptr(void) sender,EventArgs & e);


	private:
		sharedc_ptr(Gui::ComboList)		m_ComboList;

		S32				m_SelectedIndex;
		PopupDirection	m_Popup;
		bool			m_Readonly		: 1;
		bool			m_PushDown		: 1;
		bool			m_MousePointed  : 1;
		bool			m_CursorVisible : 1;
		bool			m_LikeButton;
		float			m_CursorTime;
		U32				m_MaxLength;
		//F32				m_VScrollBarButtonSize;
		F32				m_ScrollX;
		Client::Unit::Align m_TextAlign;
		Core::ARGB     m_SelectedTextColor;
		Core::ARGB     m_HoverTextColor;
		Core::Vector4  m_TextPadding;
		Core::Vector2  m_WithIconOffset;
	};
}