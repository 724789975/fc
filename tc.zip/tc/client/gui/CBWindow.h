namespace Gui
{
	//Window with close button
	class CBWindowSkin : public ControlSkin
	{
	public:
		//close button
		INLINE_PDE_ATTRIBUTE_RW(CBNormalImage, tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(CBHoverImage, tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(CBDownImage, tempc_ptr(Image));

	private:
		//close button
		sharedc_ptr(Image) m_CBNormalImage;
		sharedc_ptr(Image) m_CBHoverImage;
		sharedc_ptr(Image) m_CBDownImage;
	};

	class CBWindow : public Control	
	{
		DECLARE_PDE_OBJECT(CBWindow, Control)

	public:
		DECLARE_PDE_EVENT(EventCBClick, InputEventArgs);

		DECLARE_PDE_ATTRIBUTE_RW(CBSize, Core::Vector2);
		DECLARE_PDE_ATTRIBUTE_RW(CBLocation, Core::Vector2);
		DECLARE_PDE_ATTRIBUTE_RW(CBVisible, bool);

	public:
		CBWindow();
		~CBWindow();

		void OnCreate();
		void OnDestroy();

		// invalid
		void Invalid();

	private:
		void _OnCBClick(by_ptr(void) sender, InputEventArgs & e);

	public:
		//close button
		sharedc_ptr(Gui::Button) m_CloseBtn;
		Core::Vector2           m_CBSize;
		Core::Vector2           m_CBLocation;
		bool					m_CBVisible;
	};
}