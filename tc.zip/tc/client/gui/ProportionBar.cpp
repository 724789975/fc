#include "pch.h"

using namespace Core;
using namespace Client;
using namespace Gui;

//--------------------------------------------------------------------------------------
// type info
//--------------------------------------------------------------------------------------
DEFINE_PDE_TYPE_CLASS(ProportionBar)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Control);
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_PROPERTY_RW(TextAlign);
		ADD_PDE_PROPERTY_RW(Icon);
		ADD_PDE_PROPERTY_RW(MaxValue);
		ADD_PDE_PROPERTY_RW(CurrentValue);
	}
};

DEFINE_PDE_TYPE_CLASS(ExperienceBar)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Control);
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_PROPERTY_RW(Icon);
		ADD_PDE_PROPERTY_RW(BaseValue);
		ADD_PDE_PROPERTY_RW(PlayerName);
		ADD_PDE_PROPERTY_RW(Mini);

		ADD_PDE_METHOD(AddLevel);
		ADD_PDE_METHOD(ClearLevels);
		ADD_PDE_METHOD(SetNewValue);
		ADD_PDE_METHOD(Ready);
		ADD_PDE_METHOD(Start);
		ADD_PDE_METHOD(ForceStopSound);
	}
};

DEFINE_PDE_TYPE_CLASS(CompareBar)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Control);
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_PROPERTY_RW(TextAlign);
		ADD_PDE_PROPERTY_RW(Icon);
		ADD_PDE_PROPERTY_RW(MaxValue);
		ADD_PDE_PROPERTY_RW(BaseValue);
		ADD_PDE_PROPERTY_RW(ComparativeValue);
		ADD_PDE_PROPERTY_RW(Speed);
		ADD_PDE_METHOD(Increase);
		ADD_PDE_METHOD(Decrease);
		ADD_PDE_METHOD(ResetBaseValue);
	}
};

REGISTER_PDE_TYPE(ProportionBar);
REGISTER_PDE_TYPE(ExperienceBar);
REGISTER_PDE_TYPE(CompareBar);

namespace Gui
{
	ProportionBar::ProportionBar()
		: m_TextAlign(Client::Unit::kAlignCenterMiddle)
		, m_CurrentValue(0.0f)
		, m_TempValue(0.0f)
		, m_MaxValue(100.0f)
	{
	}

	ProportionBar::~ProportionBar()
	{
	}
}

//--------------------------------------------------------------------------------------
// Attribute
//--------------------------------------------------------------------------------------
namespace Gui
{
	PDE_ATTRIBUTE_GETTER(ProportionBar, TextAlign, Client::Unit::Align)
	{
		return m_TextAlign;
	}

	PDE_ATTRIBUTE_SETTER(ProportionBar, TextAlign, Client::Unit::Align)
	{
		if (m_TextAlign != value)
		{
			m_TextAlign = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(ProportionBar, Icon, tempc_ptr(ProportionIcon))
	{
		return m_Icon;
	}


	PDE_ATTRIBUTE_SETTER(ProportionBar, Icon, tempc_ptr(ProportionIcon))
	{
		if (m_Icon != value)
		{
			m_Icon = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(ProportionBar, TextPadding, Core::Vector4)
	{
		return Core::Vector4(2,0,2,0);
	}

	PDE_ATTRIBUTE_GETTER(ProportionBar, MaxValue, F32)
	{
		return m_MaxValue;
	}

	PDE_ATTRIBUTE_SETTER(ProportionBar, MaxValue, F32)
	{
		if(m_MaxValue!=value)
		{
			m_MaxValue = value;
			if(m_Icon)
				m_Icon->SetProportion(m_TempValue/m_MaxValue);
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(ProportionBar, CurrentValue, F32)
	{
		return m_CurrentValue;
	}

	PDE_ATTRIBUTE_SETTER(ProportionBar, CurrentValue, F32)
	{
		value = Core::Clamp(value, 0.f, m_MaxValue);
		m_CurrentValue = value;
		Invalid();
	}
}


//--------------------------------------------------------------------------------------
// Event
//--------------------------------------------------------------------------------------
namespace Gui
{
	void ProportionBar::OnFrameUpdate(EventArgs & e)
	{
		float frameTime = Task::GetFrameTime();

		m_TempValue = m_CurrentValue + Pow(0.001f, frameTime) * (m_TempValue - m_CurrentValue);

		if(Core::Abs(m_TempValue-m_CurrentValue)>0.01)
		{
			if(m_Icon)
				m_Icon->SetProportion(m_TempValue/m_MaxValue);
			Invalid();
		}
	}

	void ProportionBar::OnPaint(PaintEventArgs & e)
	{
// 		Super::OnPaint(e);
		Core::Vector4 textPadding = GetTextPadding();
		Core::Rectangle TextRect(Vector2(textPadding.x, textPadding.y), GetSize() - Vector2(textPadding.z, textPadding.w));
		Core::String str = Core::String::Format("%d / %d", (int)Core::Floor(m_TempValue+0.5), (int)Core::Floor(m_MaxValue+0.5));
		Skin::DrawImage(e.render, GetIcon(), GetClientRect());
		//Skin::DrawIconText(e.render, NullPtr, GetFont(), str, TextRect, GetTextAlign(), ARGB(255, 255, 255, 255), GetTextColor(), false);
	}

	void ProportionBar::OnInputEvent(InputEventArgs & e)
	{
		if (e.Type == InputEventArgs::kMouseEnter || e.Type == InputEventArgs::kMouseLeave)
			e.Handled = false;

		if (!e.Handled)
			Super::OnInputEvent(e);
	}
}

//=======================================================
// ExperienceBar
//=======================================================
namespace Gui
{
	ExperienceBar::ExperienceBar()
		: m_TextAlign(Client::Unit::kAlignCenterMiddle)
		, m_BaseValue(0.0f)
		, m_TempValue(0.0f)
		, m_TextCurValue(0.0f)
		, m_TextMaxValue(0.0f)
		, m_Running(false)
		, m_Mini(false)
		, m_TextCurLevel(0)
		, m_audio_exp(NULL)
		, m_audio_levelup(NULL)
	{
	}

	ExperienceBar::~ExperienceBar()
	{
	}
}


//--------------------------------------------------------------------------------------
// Attribute
//--------------------------------------------------------------------------------------
namespace Gui
{
	PDE_ATTRIBUTE_GETTER(ExperienceBar, Icon, tempc_ptr(ProportionIcon))
	{
		return m_Icon;
	}


	PDE_ATTRIBUTE_SETTER(ExperienceBar, Icon, tempc_ptr(ProportionIcon))
	{
		if (m_Icon != value)
		{
			m_Icon = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(ExperienceBar, BaseValue, F32)
	{
		return m_BaseValue;
	}

	PDE_ATTRIBUTE_SETTER(ExperienceBar, BaseValue, F32)
	{
		value = value>0?value:0.f;
		m_BaseValue = value;
		m_TempValue = m_BaseValue;
	}

	PDE_ATTRIBUTE_GETTER(ExperienceBar, Mini, bool)
	{
		return m_Mini;
	}

	PDE_ATTRIBUTE_SETTER(ExperienceBar, Mini, bool)
	{
		if(m_Mini!=value)
		{
			m_Mini = value;
			Invalid();
		}
	}
}


//--------------------------------------------------------------------------------------
// Event
//--------------------------------------------------------------------------------------
namespace Gui
{

	void ExperienceBar::OnCreate()
	{
		Super::OnCreate();

		if(gGame && gGame->guiSys)
		{
			m_audio_levelup = FmodSystem::GetEvent(gGame->guiSys->GetAudioResourceName(GuiSystem::kUIA_LEVEL_UP));
		}
	}

	void ExperienceBar::OnFrameUpdate(EventArgs & e)
	{
		if(m_Running)
		{
			float frameTime = Task::GetFrameTime();

// 			m_TempValue = m_NewValue + Pow(0.5f, frameTime) * (m_TempValue - m_NewValue);
			m_TempValue += frameTime*100;

			if (Core::Abs(m_TempValue-m_NewValue)>0.3f && m_TempValue<m_NewValue)
			{
				if(m_Icon)
				{
					F32 minBoundary = 0.f;
					F32 maxBoundary = FLT_MAX;
					for(int i=m_Levels.Size()-1; i>=0; i--)
					{
						if(m_Levels[i]<m_TempValue)
						{
							minBoundary=m_Levels[i];
							if(i+1<(int)m_Levels.Size())
							{
								maxBoundary = m_Levels[i+1];
							}
							m_TextCurLevel = i+1;
							break;
						}
					}
					m_TextCurValue = m_TempValue-minBoundary;
					m_TextMaxValue = maxBoundary-minBoundary;
					m_Icon->SetProportion(m_TextCurValue/m_TextMaxValue);
				}
			}
			else
			{
				m_Running = false;
				m_TempValue = m_NewValue;
				if(m_audio_exp)
				{
					m_audio_exp->stop();
				}
			}
			Invalid();
		}
	}

	void ExperienceBar::OnPaint(PaintEventArgs & e)
	{
		if(m_Mini)
		{
			Super::OnPaint(e);
			Core::Rectangle levelRect(5, 6, 30, 31);
			Core::Rectangle nameRect = Core::Rectangle(levelRect.Max.x,3,GetSize().x-3,17);
			Core::Rectangle barRect = nameRect;
			barRect.Move(Vector2(0,17));
			barRect.Max.y = barRect.Min.y+11;

			if(m_TextCurLevel>=1 && m_TextCurLevel<m_RankIcons.GetCount())
				Skin::DrawImage(e.render, m_RankIcons[m_TextCurLevel-1], levelRect);
			e.render->DrawString(GetFont(), GetTextColor(), ARGB(0,0,0,0), nameRect, GetPlayerName(), 
				Client::Unit::kAlignLeftMiddle);
			Skin::DrawImage(e.render, GetIcon(), barRect);
		}
		else
		{
			Core::Rectangle LvRect = GetClientRect();
			LvRect.Max.x = LvRect.Min.x+131;
			Core::Rectangle expRect = GetClientRect();
			expRect.Min.x = expRect.Max.x-130;
			Core::Rectangle barRect = GetClientRect();
			barRect.Min.x = LvRect.Max.x+10;
			barRect.Max.x = expRect.Min.x-10;
			barRect.Min.y = (GetSize().y-22)/2;
			barRect.Max.y = barRect.Min.y+22;

			Core::String str = Core::String::Format("%d / %d", (int)Core::Floor(m_TextCurValue+0.5), (int)Core::Floor(m_TextMaxValue+0.5));
			Skin::DrawImage(e.render, GetIcon(), barRect);
			e.render->DrawString(GetFont(), GetTextColor(), ARGB(0,0,0,0), expRect, str, Client::Unit::kAlignRightMiddle);

			str = Core::String::Format("Lv.%d %s", m_TextCurLevel
				, (m_TextCurLevel>=1 && m_TextCurLevel<m_Ranks.GetCount())?m_Ranks[m_TextCurLevel-1]:"");
			e.render->DrawString(GetFont(), GetTextColor(), ARGB(0,0,0,0), LvRect, str, Client::Unit::kAlignLeftMiddle);
		}

	}

	void ExperienceBar::AddLevel(F32 fValue, const Core::String& rank, tempc_ptr(Gui::Icon) rankIcon)
	{
		m_Levels.Add(fValue);
		m_Ranks.Add(rank);
		m_RankIcons.Add(rankIcon);
	}

	void ExperienceBar::SetNewValue( F32 fValue )
	{
		m_NewValue = fValue;
	}

	void ExperienceBar::ClearLevels()
	{
		m_Levels.Clear();
		m_Ranks.Clear();
		m_RankIcons.Clear();
	}

	void ExperienceBar::Ready()
	{
		F32 minBoundary = 0.f;
		F32 maxBoundary = FLT_MAX;
		for(int i=m_Levels.Size()-1; i>=0; i--)
		{
			if(m_Levels[i]<m_TempValue)
			{
				minBoundary=m_Levels[i];
				if(i+1<(int)m_Levels.Size())
				{
					maxBoundary = m_Levels[i+1];
				}
				m_TextCurLevel = i+1;
				break;
			}
		}
		m_TextCurValue = m_TempValue-minBoundary;
		m_TextMaxValue = maxBoundary-minBoundary;
		m_Icon->SetProportion(m_TextCurValue/m_TextMaxValue);
	}

	void ExperienceBar::Start()
	{
		m_Running = true;
		if(m_audio_exp && !m_Mini)
		{
			m_audio_exp->start();
		}
	}

	void ExperienceBar::ForceStopSound()
	{
		if(m_audio_exp)
		{
			m_audio_exp->stop();
		}
	}
}

//=======================================================
// CompareBar
//=======================================================
namespace Gui
{
	CompareBar::CompareBar()
		: m_TextAlign(Client::Unit::kAlignCenterMiddle)
		, m_BaseValue(0.0f)
		, m_ComparativeValue(0.0f)
		, m_TempValue(0.0f)
		, m_MaxValue(100.0f)
		, m_Speed(1.0f)
	{
	}

	CompareBar::~CompareBar()
	{
	}
}


//--------------------------------------------------------------------------------------
// Attribute
//--------------------------------------------------------------------------------------
namespace Gui
{

	PDE_ATTRIBUTE_GETTER(CompareBar, TextAlign, Client::Unit::Align)
	{
		return m_TextAlign;
	}


	PDE_ATTRIBUTE_SETTER(CompareBar, TextAlign, Client::Unit::Align)
	{
		if (m_TextAlign != value)
		{
			m_TextAlign = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(CompareBar, Icon, tempc_ptr(CompareIcon))
	{
		return m_Icon;
	}


	PDE_ATTRIBUTE_SETTER(CompareBar, Icon, tempc_ptr(CompareIcon))
	{
		if (m_Icon != value)
		{
			m_Icon = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(CompareBar, TextPadding, Core::Vector4)
	{
		return Core::Vector4(2,0,2,0);
	}

	PDE_ATTRIBUTE_GETTER(CompareBar, MaxValue, F32)
	{
		return m_MaxValue;
	}

	PDE_ATTRIBUTE_SETTER(CompareBar, MaxValue, F32)
	{
		if(m_MaxValue!=value)
		{
			m_MaxValue = value;
			if(m_Icon)
			{
				m_Icon->SetBaseValue(m_BaseValue/m_MaxValue);
				m_Icon->SetBaseValue(m_TempValue/m_MaxValue);
			}
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(CompareBar, BaseValue, F32)
	{
		return m_BaseValue;
	}

	PDE_ATTRIBUTE_SETTER(CompareBar, BaseValue, F32)
	{
		ResetBaseValue(value);
	}

	PDE_ATTRIBUTE_GETTER(CompareBar, ComparativeValue, F32)
	{
		return m_ComparativeValue;
	}

	PDE_ATTRIBUTE_SETTER(CompareBar, ComparativeValue, F32)
	{
		value = Core::Clamp(value, 0.f, m_MaxValue);
		m_ComparativeValue = value;
		Invalid();
	}

	PDE_ATTRIBUTE_GETTER(CompareBar, Speed, F32)
	{
		return m_Speed;
	}

	PDE_ATTRIBUTE_SETTER(CompareBar, Speed, F32)
	{
		if (m_Speed != value)
		{
			m_Speed = value;
			Invalid();
		}
	}
}


//--------------------------------------------------------------------------------------
// Event and method
//--------------------------------------------------------------------------------------
namespace Gui
{
	void CompareBar::OnFrameUpdate(EventArgs & e)
	{
		float frameTime = Task::GetFrameTime();

		m_TempValue = m_ComparativeValue + Pow(0.001f, frameTime) * (m_TempValue - m_ComparativeValue)* m_Speed;

		if(Core::Abs(m_TempValue-m_ComparativeValue)>0.01)
		{
			if(m_Icon)
				m_Icon->SetComparativeValue(m_TempValue/m_MaxValue);
			Invalid();
		}
	}

	void CompareBar::OnPaint(PaintEventArgs & e)
	{
// 		Super::OnPaint(e);
		Core::Vector4 textPadding = GetTextPadding();
		Core::Rectangle TextRect(Vector2(textPadding.x, textPadding.y), GetSize() - Vector2(textPadding.z, textPadding.w));
		Core::String str = Core::String::Format("%d / %d", (int)Core::Floor(m_TempValue+0.5), (int)Core::Floor(m_MaxValue+0.5));
		Skin::DrawImage(e.render, GetIcon(), GetClientRect());
// 		Skin::DrawIconText(e.render, NullPtr, GetFont(), str, TextRect, GetTextAlign(), ARGB(255, 255, 255, 255), GetTextColor(), false);
	}

	void CompareBar::OnInputEvent(InputEventArgs & e)
	{
		if (e.Type == InputEventArgs::kMouseEnter || e.Type == InputEventArgs::kMouseLeave)
			e.Handled = false;

		if (!e.Handled)
			Super::OnInputEvent(e);
	}

	void CompareBar::Increase(F32 IncValue)
	{
		m_ComparativeValue = Core::Clamp(m_ComparativeValue+IncValue, 0.f, m_MaxValue);
		Invalid();	
	}

	void CompareBar::Decrease(F32 DecValue)
	{
		m_ComparativeValue = Core::Clamp(m_ComparativeValue-DecValue, 0.f, m_MaxValue);
		Invalid();
	}

	void CompareBar::ResetBaseValue(F32 baseValue)
	{
		m_BaseValue = Core::Clamp(baseValue, 0.f, m_MaxValue);
		//Stop animation
		m_TempValue = m_ComparativeValue = m_BaseValue;
		if(m_Icon)
		{
			m_Icon->SetBaseValue(m_BaseValue/m_MaxValue);
			m_Icon->SetComparativeValue(m_ComparativeValue/m_MaxValue);
		}
		Invalid();
	}
}
