#include "pch.h"

using namespace Core;
using namespace Client;
using namespace Gui;

//--------------------------------------------------------------------------------------
// type info
//--------------------------------------------------------------------------------------
DEFINE_PDE_TYPE_CLASS(Gui::CheckBoxSkin)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::ControlSkin);
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_PROPERTY_RW(OnImage);
		ADD_PDE_PROPERTY_RW(OffImage);
		ADD_PDE_PROPERTY_RW(OnHoverImage);
		ADD_PDE_PROPERTY_RW(OffHoverImage);
		ADD_PDE_PROPERTY_RW(OnDisabledImage);
		ADD_PDE_PROPERTY_RW(OffDisabledImage);
	}
};

DEFINE_PDE_TYPE_ENUM(CheckBox::CheckPosition)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_ENUM_ITEM("kCheckLeft",			CheckBox::kCheckLeft);
		ADD_PDE_ENUM_ITEM("kCheckRight",		CheckBox::kCheckRight);
		ADD_PDE_ENUM_CONSTRUCTOR();
	}
};

DEFINE_PDE_TYPE_CLASS(CheckBox)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Control);
		ADD_PDE_DEFAULT_CONSTRUCTOR();
		ADD_PDE_PROPERTY_RW(Check);
		ADD_PDE_PROPERTY_W (MuteCheck);
		ADD_PDE_PROPERTY_RW(CheckPosition);
		ADD_PDE_PROPERTY_RW(CheckBoxSize);
		ADD_PDE_EVENT(EventCheckChanged);
		ADD_PDE_EVENT(EventCheckClickChanged);
	}
};

REGISTER_PDE_TYPE(CheckBoxSkin)
REGISTER_PDE_TYPE(CheckBox::CheckPosition)
REGISTER_PDE_TYPE(CheckBox)


namespace Gui
{
	CheckBox::CheckBox()
		: m_Check(false)
		, m_CheckPosition(kCheckLeft)
		, m_CheckBoxSize(0,0)
	{
	}

	CheckBox::~CheckBox()
	{
	}
}

//--------------------------------------------------------------------------------------
// Attribute
//--------------------------------------------------------------------------------------
namespace Gui
{
	PDE_ATTRIBUTE_GETTER(CheckBox, Check, bool)
	{
		return m_Check;
	}

	PDE_ATTRIBUTE_SETTER(CheckBox, Check, bool)
	{
		if (m_Check != value)
		{
			m_Check = value;
			EventArgs args;
			args.Source = EventArgs::kTriggerSourceSetter;
			OnCheckChanged(args);
			Invalid();
		}
	}

	PDE_ATTRIBUTE_SETTER(CheckBox, MuteCheck, bool)
	{
		if (m_Check != value)
		{
			m_Check = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(CheckBox, CheckPosition, CheckBox::CheckPosition)
	{
		return m_CheckPosition;
	}

	PDE_ATTRIBUTE_SETTER(CheckBox, CheckPosition, CheckBox::CheckPosition)
	{
		if (m_CheckPosition != value)
		{
			m_CheckPosition = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(CheckBox,CheckBoxSize,Core::Vector2)
	{
		return m_CheckBoxSize;
	}

	PDE_ATTRIBUTE_SETTER(CheckBox,CheckBoxSize,Core::Vector2)
	{
		if(m_CheckBoxSize!=value)
		{
			m_CheckBoxSize = value;
			Invalid();
		}
	}
}


//--------------------------------------------------------------------------------------
// Event
//--------------------------------------------------------------------------------------
namespace Gui
{
	///on paint
	void CheckBox::OnPaint(PaintEventArgs & e)
	{
		Super::OnPaint(e);

		Core::Rectangle clientRect = GetClientRect();;
		Core::Rectangle checkRect;
		Core::Rectangle StringRect;

		if(m_CheckPosition == kCheckLeft)
		{
			checkRect = Rectangle::LeftTop(clientRect.Min,Vector2(GetSize().y,GetSize().y));
			StringRect = Rectangle::RightBottom(clientRect.Max, Vector2(GetSize().x-GetSize().y- 5, GetSize().y));
		}
		else	//kCheckRight
		{
			checkRect = Rectangle::RightBottom(clientRect.Max,Vector2(GetSize().y,GetSize().y));
			StringRect = Rectangle::LeftTop(clientRect.Min, Vector2(GetSize().x-GetSize().y - 5, GetSize().y));
		}		

		if(m_CheckBoxSize!=Vector2::kZero)
			checkRect = Rectangle::LeftTop(clientRect.Min,Vector2(m_CheckBoxSize.x,m_CheckBoxSize.y));


		ARGB color = e.Enable?ARGB(255, 255 ,255): ARGB(212, 208, 200);
		tempc_ptr(CheckBoxSkin) skin = ptr_dynamic_cast<CheckBoxSkin>(GetSkin());

		if(skin)
		{
			if(e.Enable)
			{
				if (GetCheck())
				{
					Skin::DrawImage(e.render, skin->GetOnImage(), checkRect);
				}
				else
				{
					Skin::DrawImage(e.render, skin->GetOffImage(), checkRect);
				}
				clientRect.Min.x = 20;
				e.render->DrawString(GetFont(),GetTextColor(),GetBackgroundColor(),StringRect,GetText(), m_CheckPosition==kCheckLeft?Unit::kAlignLeftMiddle:Unit::kAlignRightMiddle);
			}
			else
			{
				if (GetCheck())
				{
					Skin::DrawImage(e.render, skin->GetOnDisabledImage(), checkRect);
				}
				else
				{
					Skin::DrawImage(e.render, skin->GetOffDisabledImage(), checkRect);
				}
				clientRect.Min.x = 20;
				e.render->DrawString(GetFont(),GetDisabledTextColor(),GetBackgroundColor(),StringRect,GetText(), m_CheckPosition==kCheckLeft?Unit::kAlignLeftMiddle:Unit::kAlignRightMiddle);
			}
		}
		else
		{
			if(GetCheck())
			{
				e.render->DrawRectangle(checkRect,checkRect,e.Enable? ARGB(0, 0, 0): ARGB(128,128,128));
			}
			else
			{
				e.render->DrawRectangle(checkRect,checkRect,e.Enable? ARGB(128, 128, 128): ARGB(0,0,0));
			}
			clientRect.Min.x = 20;
			e.render->DrawString(GetFont(),GetTextColor(),GetBackgroundColor(),StringRect,GetText(), m_CheckPosition==kCheckLeft?Unit::kAlignLeftMiddle:Unit::kAlignRightMiddle);
		}
	}

	/// on input event
	void CheckBox::OnInputEvent( Client::InputEventArgs &e )
	{
		if (e.IsMouseEvent())
		{
			Core::Vector2 localPos = ScreenToClient(e.CursorPosition);
			Core::Rectangle clientRect = GetClientRect();
			Core::Rectangle checkRect;
			if(m_CheckPosition == kCheckLeft)
			{
				checkRect = Rectangle::LeftTop(clientRect.Min,Vector2(GetSize().y,GetSize().y));
			}
			else	//kCheckRight
			{
				checkRect = Rectangle::RightBottom(clientRect.Max,Vector2(GetSize().y,GetSize().y));
			}
			bool pointed = 	checkRect.IsPointInside(localPos);	

			switch (e.Type)
			{
			case InputEventArgs::kMouseDown:
			case InputEventArgs::kMouseDoubleClick:
				{
					//LogSystem.WriteLine("Checkbox mouse down");
				}
				e.Handled = true;
				break;

			case InputEventArgs::kMouseUp:
				{
					//LogSystem.WriteLine("Checkbox mouse up");
					if(e.Code == MC_LEFT_BUTTON && pointed)
					{					
						gGame->guiSys->PlayAudio(GuiSystem::kUIA_MOUSE_CLICK);
						m_Check = (!GetCheck());
						EventArgs args;
						args.Source = EventArgs::kTriggerSourceMouse;
						OnCheckChanged(args);
						Invalid();
						OnCheckClickChanged(EventArgs());
					}
					e.Handled = true;

				}
				break;
			}
		}

		if (!e.Handled)
			Super::OnInputEvent(e);
	}

	///on check changed
	void CheckBox::OnCheckChanged(EventArgs & e)
	{
		EventCheckChanged.Fire(ptr_static_cast<CheckBox>(this), e);
	}

	/// on check click changed
	void CheckBox::OnCheckClickChanged(EventArgs & e)
	{
		EventCheckClickChanged.Fire(ptr_static_cast<CheckBox>(this), e);
	}
}



