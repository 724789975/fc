namespace Gui
{
	class MutexControl : public Control
	{
		DECLARE_PDE_OBJECT(MutexControl,Control);
	public:
		DECLARE_PDE_EVENT(EventClick,			Client::InputEventArgs);
		DECLARE_PDE_EVENT(EventRightClick,		Client::InputEventArgs);
		DECLARE_PDE_EVENT(EventSelectedChanged,	Core::EventArgs);
	public:
		DECLARE_PDE_ATTRIBUTE_RW(Selected,		bool);
		DECLARE_PDE_ATTRIBUTE_W(PopupMenu,		sharedc_ptr(Menu));

	public:
		MutexControl(void);

		~MutexControl(void);
	public:
		virtual void OnCreate();

		virtual void OnPaint(PaintEventArgs & e);

		virtual void OnInputEvent(Client::InputEventArgs & e);

		virtual void OnClick(Client::InputEventArgs & e);

		virtual void OnRightClick(Client::InputEventArgs & e);

		virtual void OnSelectedChanged(Core::EventArgs & e);

	private:
		bool				m_Selected	:1;
		sharedc_ptr(Menu)	m_PopupMenu;
	};
}

namespace Gui
{
	class MutexControlSkin : public ControlSkin
	{
	public:
		INLINE_PDE_ATTRIBUTE_RW(SelectedImage,	tempc_ptr(Image));

	private:
		sharedc_ptr(Image)		m_SelectedImage;
	};
}