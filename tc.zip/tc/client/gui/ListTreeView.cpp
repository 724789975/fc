#include "pch.h"

using namespace Core;
using namespace Gui;
using namespace Client;

DEFINE_PDE_TYPE_CLASS(Gui::ListTreeViewSkin)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::ScrollableControlSkin);
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_PROPERTY_RW(ExpandedImage);
		ADD_PDE_PROPERTY_RW(CollapsedImage);
		ADD_PDE_PROPERTY_RW(VDashImage);
		ADD_PDE_PROPERTY_RW(HalfVDashImage);
		ADD_PDE_PROPERTY_RW(HalfHDashImage);

		ADD_PDE_PROPERTY_RW(GridLineColor);
	}
};

DEFINE_PDE_TYPE_CLASS(Gui::ListTreeView)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::ScrollableControl);
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_PROPERTY_RW(CheckIndex);
		ADD_PDE_PROPERTY_RW(SelectingIndex);
		ADD_PDE_PROPERTY_R(PointedItem);
		ADD_PDE_PROPERTY_RW(SelectedItem);
		ADD_PDE_PROPERTY_RW(MultiSelect);
		ADD_PDE_PROPERTY_RW(TreeVisible);
		ADD_PDE_PROPERTY_RW(HeaderVisible);
		ADD_PDE_PROPERTY_RW(GridLines);
		ADD_PDE_PROPERTY_RW(ShowLines);
		ADD_PDE_PROPERTY_RW(AutoColumnSize);
		ADD_PDE_PROPERTY_RW(AlwaysSelect);
		ADD_PDE_PROPERTY_RW(CanKeySelect);
		ADD_PDE_PROPERTY_R (ItemCount);
		ADD_PDE_PROPERTY_R (Columns);
		ADD_PDE_PROPERTY_R (RootItem);
		ADD_PDE_PROPERTY_R (DropTargetItem);
		ADD_PDE_PROPERTY_RW(CanEditColumn);
		ADD_PDE_PROPERTY_RW(ItemGap);
		ADD_PDE_PROPERTY_RW(HeaderHeight);
		ADD_PDE_PROPERTY_R(PopupMenu);
		ADD_PDE_PROPERTY_R(MouseSelectedItem);

		ADD_PDE_PROPERTY_RW(FindByRegular);
		ADD_PDE_PROPERTY_RW(FindEnable);
		ADD_PDE_PROPERTY_RW(ShowNodeToolTip);
		ADD_PDE_PROPERTY_RW(UseFistColumn);
		ADD_PDE_PROPERTY_RW(UseColFontSize);
		ADD_PDE_PROPERTY_RW(UseColFontCol);
		ADD_PDE_PROPERTY_RW(UseColumnNum);
		ADD_PDE_PROPERTY_RW(MY_SPLIT_WIDTH);
		ADD_PDE_PROPERTY_RW(ItemSkin);
		ADD_PDE_PROPERTY_RW(HeaderSkin);
		ADD_PDE_PROPERTY_RW(HeaderClickable);
		ADD_PDE_PROPERTY_RW(HeaderMovable);
		ADD_PDE_PROPERTY_RW(HeaderSizeable);
		ADD_PDE_PROPERTY_RW(ItemHeight)
		ADD_PDE_PROPERTY_RW(DrawItemBgWhenEmpty);
		ADD_PDE_PROPERTY_RW(VScrollOffset);
		
		ADD_PDE_PROPERTY_W(HeadFontSize);
		ADD_PDE_PROPERTY_W(HeadFontColor);

		ADD_PDE_METHOD(CreateItem);
		ADD_PDE_METHOD(AddItem);
		ADD_PDE_METHOD(AddSubItem);
		ADD_PDE_METHOD(AddExistingItem);
		ADD_PDE_METHOD(AddColumn);
		ADD_PDE_METHOD(AddFilterColumn);
		ADD_PDE_METHOD(DeleteNode);
		ADD_PDE_METHOD(DeleteAll);
		ADD_PDE_METHOD(DeleteColumns);
		ADD_PDE_METHOD(ClearSelection);
		ADD_PDE_METHOD(Ready);

		ADD_PDE_METHOD(GetItemText);
		ADD_PDE_METHOD(SetItemText);
		ADD_PDE_METHOD(HasItem);
		ADD_PDE_METHOD(AutoColumnSize);
		ADD_PDE_METHOD(SortColumn);
		ADD_PDE_METHOD(SortColumnExt);
		ADD_PDE_METHOD(GetItemAt);
		ADD_PDE_METHOD(ScrollToItem);
		ADD_PDE_METHOD(SelectItemByColumnName);
		ADD_PDE_METHOD(NameMatchWithText);
		ADD_PDE_METHOD(PointToNode);
		ADD_PDE_METHOD(DisplayIndexToItem);
		ADD_PDE_METHOD(ItemToDisplayIndex);

		ADD_PDE_EVENT(EventDelete);
		ADD_PDE_EVENT(EventItemChange);
		ADD_PDE_EVENT(EventSplitDoubleClick);
		ADD_PDE_EVENT(EventSelectItemChange);
		ADD_PDE_EVENT(EventDoubleClick);
		ADD_PDE_EVENT(EventClick);
		ADD_PDE_EVENT(EventCheckChanged);
		ADD_PDE_EVENT(EventRightClick);
		ADD_PDE_EVENT(EventExpand);
		ADD_PDE_EVENT(EventColumnEdit);
		ADD_PDE_EVENT(EventColumnEditEnter);
		ADD_PDE_EVENT(EventNodeMouseEnter);
		ADD_PDE_EVENT(EventNodeMouseLeave);
		ADD_PDE_EVENT(EventNodeColumnMouseEnter);
		ADD_PDE_EVENT(UpdateMouseMove);
	}
};

REGISTER_PDE_TYPE(Gui::ListTreeViewSkin);
REGISTER_PDE_TYPE(Gui::ListTreeView);
//REGISTER_PDE_TYPE(Gui::ListTreeView::SortFunc);

namespace Gui
{
	const F32 ListTreeView::LEVELSPACE = 20.f;
	const F32 ListTreeView::BORDER_WIDTH = 1.f;
	const F32 ListTreeView::SPLIT_WIDTH = 7.f;
	const F32 ListTreeView::MIN_WIDTH = 10.f;
	sharedc_ptr(ListTreeView::IDefaultStrCompareFunc) ListTreeView::m_DefaultStrCompare = ptr_new ListTreeView::IDefaultStrCompareFunc;

	ListTreeView::ListTreeView()
		: m_CheckIndex(-1)
		, m_LastIndex(0)
		, m_SelectingIndex(0)
		, m_MultiSelect(false)
		, m_Selecting(false)
		, m_TreeVisible(true)
		, m_HeaderVisible(true)
		, m_GridLines(false)
		, m_ShowLines(true)
		, m_AutoColumnSize(false)
		, m_AlwaysSelect(false)
		, m_CanKeySelect(true)
		, m_SelectedByMouse(false)
		, m_HeadFontSize(0.0f)
		, m_HeadFontColor(ARGB(255,255,255,255))
		, m_EditColumn(0)
		, m_CanEditColumn(false)
		, m_UseFistColumn(false)
		, m_UseColumnNum(0)
		, m_UseColFontSize(0.0)
		, m_UseColFontCol(ARGB(255,255,255,255))
		, m_BeforeDrag(false)
		, m_FindEnable(true)
		, m_FindByRegular(false)
		, m_ItemHeight(30.f)
		, m_ShowNodeToolTip(false)
		, m_MY_SPLIT_WIDTH(0)
		, m_MouseSelectedItem(NullPtr)
		, m_Timer(0.f)
		, m_ItemGap(0.f)
		, m_DrawItemBgWhenEmpty(false)
		, m_VScrollOffset(0.0f)
		, m_ismouse_here(false)
		, m_tooltipStartshow(0.f)
		, m_isCanShow(false)
	{
	}

	ListTreeView::~ListTreeView()
	{
	}
}


//--------------------------------------------------------------------------------------
// Attribute
//--------------------------------------------------------------------------------------
namespace Gui
{
	PDE_ATTRIBUTE_GETTER(ListTreeView, MouseSelectedItem, sharedc_ptr(ListItem))
	{
		return m_MouseSelectedItem;
	}

	PDE_ATTRIBUTE_GETTER(ListTreeView, CheckIndex, S32)
	{
		return m_CheckIndex;
	}

	PDE_ATTRIBUTE_SETTER(ListTreeView, CheckIndex, S32)
	{
		if (value != m_CheckIndex)
		{
			m_CheckIndex = value;
			Invalid();
		}
	}
	
	PDE_ATTRIBUTE_GETTER(ListTreeView,UseFistColumn,bool)
	{	
		return m_UseFistColumn;
	}

	PDE_ATTRIBUTE_SETTER(ListTreeView,UseFistColumn,bool)
	{
		if(value!=m_UseFistColumn)
		{

			m_UseFistColumn = value;
		}
	}

	PDE_ATTRIBUTE_GETTER(ListTreeView,UseColumnNum,F32)
	{	
		return m_UseColumnNum;
	}

	PDE_ATTRIBUTE_SETTER(ListTreeView,UseColumnNum,F32)
	{
		if(value!=m_UseColumnNum)
		{

			m_UseColumnNum = value;
		}
	}

	PDE_ATTRIBUTE_GETTER(ListTreeView,UseColFontCol,Core::ARGB)
	{	
		return m_UseColFontCol;
	}

	PDE_ATTRIBUTE_SETTER(ListTreeView,UseColFontCol,Core::ARGB)
	{
		if(value!=m_UseColFontCol)
		{

			m_UseColFontCol = value;
		}
	}

	PDE_ATTRIBUTE_GETTER(ListTreeView,UseColFontSize,Core::Float)
	{	
		return m_UseColFontSize;
	}

	PDE_ATTRIBUTE_SETTER(ListTreeView,UseColFontSize,Core::Float)
	{
		if(value!=m_UseColFontSize)
		{

			m_UseColFontSize = value;
		}
	}

	PDE_ATTRIBUTE_GETTER(ListTreeView,MY_SPLIT_WIDTH,F32)
	{	
		return m_MY_SPLIT_WIDTH;
	}

	PDE_ATTRIBUTE_SETTER(ListTreeView,MY_SPLIT_WIDTH,F32)
	{
		if(value!=m_MY_SPLIT_WIDTH)
		{

			m_MY_SPLIT_WIDTH = value;
		}
	}

	PDE_ATTRIBUTE_SETTER(ListTreeView,HeadFontColor,Core::ARGB)
	{
		if(value!=m_HeadFontColor)
		{
			m_HeadFontColor = value;
			m_Header->SetTextColor(m_HeadFontColor);
		}
	}


	PDE_ATTRIBUTE_GETTER(ListTreeView, PointedItem,tempc_ptr(ListItem))
	{
		return m_PointedItem;
	}

	PDE_ATTRIBUTE_GETTER(ListTreeView, SelectedItem, sharedc_ptr(ListItem))
	{
		return m_SelectedItem;
	}


	PDE_ATTRIBUTE_SETTER(ListTreeView, SelectedItem, sharedc_ptr(ListItem))
	{
		if (!value && value != m_SelectedItem)
		{
			ClearSelection();

			m_SelectingIndex = 0;
			m_LastIndex = 0;
			ChangeSelectItem(NullPtr);
			return;
		}

		if (value && value != m_SelectedItem && HasItem(value))
		{
			ClearSelection();

			ChangeSelectItem(value);

			U32 index = ItemToDisplayIndex(value);

			if (index < GetDisplayCount())
			{
				m_SelectingIndex = index;
				m_LastIndex = index;
				//ScrollToItem(index);
			}
		}
	}

	PDE_ATTRIBUTE_GETTER(ListTreeView, DisplayCount, U32)
	{
		bool flag =false;
		U32 index = 0;

		for (tempc_ptr(ListItem) pNode = m_RootItem->GetFirstChild(); pNode; pNode = pNode->GetNextNode(flag))
		{
			if(!pNode->GetVisible())
				continue;
			flag = !m_TreeVisible || !pNode->GetExpanded();
			++index;
		}

		return index;
	}

	PDE_ATTRIBUTE_GETTER(ListTreeView, ItemCount, U32)
	{
		U32 index = 0;
		for (tempc_ptr(ListItem) pNode = m_RootItem->GetFirstChild(); pNode; pNode = pNode->GetNextNode())
		{
			++index;
		}
		return index;
	}

	PDE_ATTRIBUTE_GETTER(ListTreeView, Columns, sharedc_ptr(Header))
	{
		return m_Header;
	}

	PDE_ATTRIBUTE_GETTER(ListTreeView, RootItem, sharedc_ptr(ListItem))
	{
		return m_RootItem;
	}

	PDE_ATTRIBUTE_GETTER(ListTreeView, MultiSelect, bool)
	{
		return m_MultiSelect;
	}

	PDE_ATTRIBUTE_SETTER(ListTreeView, MultiSelect, bool)
	{
		if (m_MultiSelect != value)
		{
			m_MultiSelect = value;
		}
	}

	PDE_ATTRIBUTE_GETTER(ListTreeView, TreeVisible, bool)
	{
		return m_TreeVisible;
	}

	PDE_ATTRIBUTE_SETTER(ListTreeView, TreeVisible, bool)
	{
		if (m_TreeVisible != value)
		{
			m_TreeVisible = value;
			DirtyLayout();
		}
	}

	PDE_ATTRIBUTE_GETTER(ListTreeView, HeaderVisible, bool)
	{
		return m_HeaderVisible;
	}

	PDE_ATTRIBUTE_SETTER(ListTreeView, HeaderVisible, bool)
	{
		if (m_HeaderVisible != value)
		{
			m_HeaderVisible = value;
			m_Header->SetVisible(m_HeaderVisible);
			DirtyLayout();
		}
	}

	PDE_ATTRIBUTE_SETTER(ListTreeView,HeadFontSize,Core::Float)
	{
		if(m_HeadFontSize!=value){
			m_HeadFontSize = value;
			m_Header->SetFontSize(m_HeadFontSize);
		}
	}


	PDE_ATTRIBUTE_GETTER(ListTreeView, GridLines, bool)
	{
		return m_GridLines;
	}

	PDE_ATTRIBUTE_SETTER(ListTreeView, GridLines, bool)
	{
		if (m_GridLines != value)
		{
			m_GridLines = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(ListTreeView, ShowLines, bool)
	{
		return m_ShowLines;
	}

	PDE_ATTRIBUTE_SETTER(ListTreeView, ShowLines, bool)
	{
		if (m_ShowLines != value)
		{
			m_ShowLines = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(ListTreeView, AutoColumnSize, bool)
	{
		return m_AutoColumnSize;
	}

	PDE_ATTRIBUTE_SETTER(ListTreeView, AutoColumnSize, bool)
	{
		if (m_AutoColumnSize != value)
		{
			m_AutoColumnSize = value;
			DirtyLayout();
		}
	}

	PDE_ATTRIBUTE_GETTER(ListTreeView, ItemSkin, tempc_ptr(ListItemSkin))
	{
		return m_ItemSkin;
	}

	PDE_ATTRIBUTE_SETTER(ListTreeView, ItemSkin, tempc_ptr(ListItemSkin))
	{
		if (m_ItemSkin != value)
		{
			m_ItemSkin = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(ListTreeView, HeaderSkin, tempc_ptr(HeaderSkin))
	{
		return ptr_dynamic_cast<HeaderSkin>(m_Header->GetSkin());
	}

	PDE_ATTRIBUTE_SETTER(ListTreeView, HeaderSkin, tempc_ptr(HeaderSkin))
	{
		m_Header->SetSkin(value);
	}

	PDE_ATTRIBUTE_GETTER(ListTreeView, HeaderClickable, bool)
	{
		return m_Header->GetClickable();
	}

	PDE_ATTRIBUTE_SETTER(ListTreeView, HeaderClickable, bool)
	{
		m_Header->SetClickable(value);
	}

	PDE_ATTRIBUTE_GETTER(ListTreeView, HeaderMovable, bool)
	{
		return m_Header->GetMovable();
	}

	PDE_ATTRIBUTE_SETTER(ListTreeView, HeaderMovable, bool)
	{
		m_Header->SetMovable(value);
	}	

	PDE_ATTRIBUTE_GETTER(ListTreeView, HeaderSizeable, bool)
	{
		return m_Header->GetSizeable();
	}

	PDE_ATTRIBUTE_SETTER(ListTreeView, HeaderSizeable, bool)
	{
		m_Header->SetSizeable(value);
	}

	PDE_ATTRIBUTE_GETTER(ListTreeView, ItemGap, F32)
	{
		return m_ItemGap;
	}

	PDE_ATTRIBUTE_SETTER(ListTreeView, ItemGap, F32)
	{
		if(m_ItemGap!=value)
		{
			m_ItemGap = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(ListTreeView,SelectingIndex,S32)
	{	
		return m_SelectingIndex;
	}

	PDE_ATTRIBUTE_SETTER(ListTreeView,SelectingIndex,S32)
	{
		if(value!=m_SelectingIndex)
		{

			m_SelectingIndex = value;
		}
	}

	PDE_ATTRIBUTE_GETTER(ListTreeView,ItemHeight,F32)
	{
		return m_ItemHeight;
	}

	PDE_ATTRIBUTE_SETTER(ListTreeView,ItemHeight,F32)
	{
		if(m_ItemHeight!=value)
		{
			m_ItemHeight = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(ListTreeView, PopupMenu, sharedc_ptr(Menu))
	{
		return m_PopupMenu;
	}
	
	PDE_ATTRIBUTE_GETTER(ListTreeView, HeaderHeight, F32)
	{
		return m_Header->GetSize().y;
	}

	PDE_ATTRIBUTE_SETTER(ListTreeView, HeaderHeight, F32)
	{
		if(m_Header->GetSize().y!=value)
		{
			m_Header->SetSize(Core::Vector2(m_Header->GetSize().x, value));
		}
	}

	PDE_ATTRIBUTE_GETTER(ListTreeView, DrawItemBgWhenEmpty, bool)
	{
		return m_DrawItemBgWhenEmpty;
	}

	PDE_ATTRIBUTE_SETTER(ListTreeView, DrawItemBgWhenEmpty, bool)
	{
		if(m_DrawItemBgWhenEmpty!=value)
		{
			m_DrawItemBgWhenEmpty = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(ListTreeView, SortColumnID, S32)
	{
		return m_Header->GetSortID();
	}

	PDE_ATTRIBUTE_GETTER(ListTreeView, SortReverse, bool)
	{
		return m_Header->GetSortReverse();
	}

	PDE_ATTRIBUTE_GETTER(ListTreeView,VScrollOffset,F32)
	{	
		return m_VScrollOffset;
	}

	PDE_ATTRIBUTE_SETTER(ListTreeView,VScrollOffset,F32)
	{
		if(value!=m_VScrollOffset)
		{

			m_VScrollOffset = value;
		}
	}
}


//--------------------------------------------------------------------------------------
// Event
//--------------------------------------------------------------------------------------
namespace Gui
{
	void ListTreeView::OnCreate()
	{
		Super::OnCreate();
		SetBackgroundColor(Core::ARGB(255,255,255));
		SetAutoScroll(true);
		m_RootItem = ptr_new ListItemRoot;

		if (m_RootItem)
		{
			m_RootItem->SetOwner(ptr_static_cast<ListTreeView>(this));
			m_RootItem->SetLevel(-1);
		}

		m_Header = ptr_new Header;
		m_Header->SetParent(ptr_static_cast<ListTreeView>(this));
		Core::Vector4 padding = GetDisplayPadding();
		m_Header->SetSize(Vector2(GetSize().x - padding.x - padding.z, m_ItemHeight));

		m_PopupMenu = ptr_new Menu;
		m_PopupMenu->SetStyle("Gui.Menu");
	}

	void ListTreeView::OnDestroy()
	{
		DeleteAll(true);

		if (m_RootItem)
		{
			m_RootItem->SetOwner(NullPtr);
			m_RootItem = NullPtr;
		}

		Super::OnDestroy();
	}

	/// on frame update
	void ListTreeView::OnFrameUpdate(EventArgs & e)
	{
		if (m_FindBox)
		{
			if (Core::Task::GetTotalTime() - m_Timer > 3)
			{
				FindBox_Release(m_FindBox);
			}
		}
		else
			m_Timer = Core::Task::GetTotalTime();

		if (m_ismouse_here)
		{
			if (m_tooltipStartshow < 0.5f)
			{
				m_tooltipStartshow += Task::GetFrameTime();
				m_isCanShow = false;
			}
			else if (!m_isCanShow)
			{
				m_isCanShow = true;
				UpdateMouseMove.Fire(ptr_static_cast<ListTreeView>(this), e);
			}
		}

		Super::OnFrameUpdate(e);
	}

	void ListTreeView::OnLayout(EventArgs & e)
	{
		if (m_AutoColumnSize)
			AutoColumnSize(0);

		F32 width = GetAllWidth();
		if (GetAutoScroll())
		{
			Core::Vector2 autoSize(width, (m_ItemHeight * GetDisplayCount() + m_ItemGap*(GetDisplayCount()+1) + 1));

			if (m_Header->GetVisible())
				autoSize.y += m_Header->GetSize().y;

			if (autoSize.y < GetSize().y)
				m_Scroll.y = 0.f;

			SetAutoScrollMinSize(autoSize);
			m_VScrollBar->SetSmallChange(m_ItemHeight + m_ItemGap);
		}

		Core::Vector4 padding = GetDisplayPadding();

		Super::OnLayout(e);

		m_Header->SetSize(Core::Vector2(Core::Max(width, GetSize().x - padding.x - padding.z), m_Header->GetSize().y));
		m_Header->SetLocation(Core::Vector2(0, m_Scroll.y));

		Invalid();
	}

	void ListTreeView::OnPaint(PaintEventArgs & e)
	{
		Super::OnPaint(e);


		tempc_ptr(ListTreeViewSkin) skin = ptr_dynamic_cast<ListTreeViewSkin>(GetSkin());

		F32 allWidth = m_Header->GetAllWidth();
		F32 xExtent = (m_VScrollBar && m_VScrollBar->GetVisible())?(GetSize().x - m_VScrollOffset/* -m_VScrollBar->GetWidth() - 5*/):(GetSize().x);
		F32 width = (m_HScrollBar && m_HScrollBar->GetVisible())?Max(xExtent, allWidth):xExtent;

		bool flag = false;

		Core::Rectangle displayRect = GetDisplayRect();
		Core::Rectangle selectRect;
		Core::Rectangle textRect;
		DrawItemEventArgs drawEvent(e);

		// to items space
		Matrix44 world_backup = e.render->GetWorld();
		Core::Rectangle scissorRect = GetDisplayRect();

		if (m_Header->GetVisible())
		{
			float header_height = m_Header->GetSize().y;

			scissorRect.Max.y -= header_height;
			world_backup.TranslateLocalXYZ(0, header_height, 0);
			e.render->SetWorld(world_backup);
		}

		e.render->AddScissorRectWithWorldMatrix(scissorRect);
		scissorRect = e.render->GetScissorRect();

		//Draw item background strips
		if(m_DrawItemBgWhenEmpty)
		{
			int totalIndices = (int)Core::Ceil((displayRect.Max.y-displayRect.Min.y)/(m_ItemHeight + m_ItemGap));
			int minIndex = (int)Core::Floor(displayRect.Min.y/(m_ItemHeight + m_ItemGap));
			for(int i=minIndex; i<minIndex+totalIndices; i++)
			{
				if ((i + 1) * (m_ItemHeight + m_ItemGap) >= displayRect.Min.y && displayRect.Max.y >= i*(m_ItemHeight + m_ItemGap)+m_ItemGap)
				{
					Core::Rectangle paintRect = Core::Rectangle(0, (m_ItemHeight + m_ItemGap)*i+m_ItemGap, width, (m_ItemHeight + m_ItemGap)*(i + 1));
					tempc_ptr(ListItemSkin) skin = m_ItemSkin;
					if(skin)
					{
						Skin::DrawImage(e.render, i%2?skin->GetBackgroundImageOp():skin->GetBackgroundImage(), paintRect);
					}
				}
			}
		}
		//End draw item background strips

		S32 index = 0;
		for (tempc_ptr(ListItem) item = m_RootItem->GetFirstChild(); item; item = item->GetNextNode(flag))
		{
			flag = !m_TreeVisible || !item->GetExpanded();
			if(!item->GetVisible())
				continue;
			if ((index + 1) * (m_ItemHeight + m_ItemGap) >= displayRect.Min.y && displayRect.Max.y >= index*(m_ItemHeight + m_ItemGap)+m_ItemGap)
			{
				selectRect = Core::Rectangle(0, (m_ItemHeight + m_ItemGap)*index+m_ItemGap, width, (m_ItemHeight + m_ItemGap)*(index + 1));

				bool selected = item->GetSelected();

				//draw gird lines
				if (m_GridLines)
					e.render->DrawLine2d(Core::Vector2(0, (m_ItemHeight + m_ItemGap) * index + 1), Core::Vector2(GetDisplayRect().Max.x, (m_ItemHeight + m_ItemGap) * index + 1), skin?skin->GetGridLineColor():XRGB(255,0,0));

				// move world matrix to selection space
				Matrix44 world = world_backup;
				world.TranslateLocal(Vector3(selectRect.Min, 0));
				e.render->SetWorld(world);

				// move selection to world space
				Core::Rectangle local_select_rect(Vector2::kZero, selectRect.GetExtent());

				if (m_GridLines)
					local_select_rect.Min.y += 1;

				// update scissor
				e.render->SetScissorRect(scissorRect);
				e.render->AddScissorRectWithWorldMatrix(local_select_rect);
				if (e.render->GetScissorRect().IsEmpty())
				{
					++index;
					continue;
				}

				// draw item background
				drawEvent.Handled = false;
				drawEvent.Item = item;
				drawEvent.ItemSkin = m_ItemSkin;
				drawEvent.Rect = local_select_rect;
				drawEvent.Selected = selected;
				drawEvent.Row = index;
				OnDrawItemBackgroud(drawEvent);
				
				U32 count = m_Header->GetItemCount();

				for (U32 j=0; j<count; ++j)
				{
					U32 columnIndex = m_Header->IndexToDisplayIndex(j);
					if (columnIndex < count)
					{
						/// draw grid lines
						if (m_GridLines)
						{
							F32 pos = m_Header->GetPos(j) + m_Header->GetWidth(j) - BORDER_WIDTH;
							F32 height =/* Min(GetDisplayRect().Max.y, GetDisplayCount() * m_ItemHeight)*/(m_ItemHeight + m_ItemGap);
							e.render->DrawLine2d(Core::Vector2(pos, 0), Core::Vector2(pos, height), skin?skin->GetGridLineColor():XRGB(255,0,0));
						}

						textRect = selectRect;
						textRect.Min.x = m_Header->GetPos(j);
						textRect.Max.x = textRect.Min.x + m_Header->GetWidth(j);
						//textRect.Shrink(SPLIT_WIDTH, 0, SPLIT_WIDTH, 0);

						Matrix44 world = world_backup;
						world.TranslateLocal(Vector3(textRect.Min, 0));
						e.render->SetWorld(world);
						textRect.Move(-textRect.Min);
						e.render->SetScissorRect(scissorRect);
						e.render->AddScissorRectWithWorldMatrix(textRect);

						if (e.render->GetScissorRect().IsEmpty())
						{
							continue;
						}

						if (m_TreeVisible && columnIndex == 0)
						{
							textRect.Shrink((1 + item->GetLevel()) * LEVELSPACE , 0, 0, 0);
							DisplayNodeDashed(e.render, item, index);
						}

						drawEvent.Handled = false;
						drawEvent.Column = j;
						drawEvent.Rect = textRect;
						drawEvent.Align = m_Header->GetAlign(j);
						drawEvent.Font = GetFont();

						if(m_UseFistColumn&&m_UseColumnNum==columnIndex)
						{	
							OnDrawItemText(drawEvent);
							continue;
						}

						OnDrawItem(drawEvent);

						
					}
				}
				//Restore scissor rect
				e.render->SetWorld(world_backup);
				e.render->SetScissorRect(scissorRect);
			}
			++index;
		}

		if (GetActive() && m_SelectingIndex < GetDisplayCount())
		{
			Core::Rectangle brokenRect(Core::Vector2(0, m_ItemHeight * m_SelectingIndex), Core::Vector2(allWidth - 1, m_ItemHeight * (m_SelectingIndex + 1) - 1));
		}
	}

	bool ListTreeView::IsOnGap(Core::Vector2 localPos)
	{
		if(m_ItemGap>Core::EPSILON)	//there are gaps
		{
			S32 index = localPos.y/(m_ItemHeight+m_ItemGap);
			if(localPos.y-index*(m_ItemHeight+m_ItemGap)<m_ItemGap)
			{
				return true;
			}
		}
		return false;
	}

	void ListTreeView::OnInputEvent(InputEventArgs & e)
	{

		if (e.IsMouseEvent())
		{
			//First let the scrollbar handle the input
			if (GetAutoScroll())
			{

				if (m_HScrollBarDisplay!=kHide && m_HScrollBar && m_HScrollBar->GetVisible())
					m_HScrollBar->OnInputEvent(ptr_static_cast<Control>(this), e);

				if (e.Handled)
				{
					m_PointedItem = NullPtr;
					Invalid();
					return;
				}

				if (m_VScrollBarDisplay!=kHide && m_VScrollBar && m_VScrollBar->GetVisible())
					m_VScrollBar->OnInputEvent(ptr_static_cast<Control>(this), e);

				if (e.Handled)
				{
					m_PointedItem = NullPtr;
					Invalid();
					return;
				}
			}

			Core::Vector2 localPos = ScreenToClient(e.CursorPosition);

			bool pointed = GetDisplayRect().IsPointInside(localPos);

			if (m_Header->GetVisible())
				localPos.y -= m_Header->GetSize().y;

			if(e.Type == InputEventArgs::kMouseLeave)
			{
				Invalid();
			}

			if (m_Selecting || pointed)
			{
				switch(e.Type)
				{
				case InputEventArgs::kMouseDoubleClick:
					{
						if (e.Code == MC_LEFT_BUTTON && pointed)
						{
							U32 index = (localPos.y-m_ItemGap) / (m_ItemHeight+m_ItemGap);
							if( localPos.y<(m_ItemGap+m_ItemHeight)*index+m_ItemGap 
								|| localPos.y>(m_ItemGap+m_ItemHeight)*(index+1) )
							{
								//clicked in the gap
								index = -1;
							}

							sharedc_ptr(ListItem) item = DisplayIndexToItem(index);

							if (item && item->GetCanSelect())
							{
								ListItemEventArgs arg;
								arg.Item = item;
								OnDoubleClick(arg);

								if (arg.Handled)
									e.Handled = true;
							}
						}

						if (e.Handled)
							break;
					}

				case InputEventArgs::kMouseDown:
					{
						if ( (e.Code == MC_LEFT_BUTTON || e.Code == MC_RIGHT_BUTTON && !m_Selecting && pointed) && !IsOnGap(localPos))
						{
							U32 index = (localPos.y-m_ItemGap) / (m_ItemHeight+m_ItemGap);
							if( localPos.y<(m_ItemGap+m_ItemHeight)*index+m_ItemGap || localPos.y>(m_ItemGap+m_ItemHeight)*(index+1) )
							{
								//clicked in the gap
								index = -1;
							}

							sharedc_ptr(ListItem) item = DisplayIndexToItem(index);

							SetCapture(true);
							m_Selecting = true;

							if (m_TreeVisible && index < GetDisplayCount() && CanExpand(item))
							{
								Core::Rectangle expandRect = Core::Rectangle::LeftTop(Core::Vector2(item->GetLevel() * LEVELSPACE, (m_ItemHeight+m_ItemGap)*index+m_ItemGap),Core::Vector2(LEVELSPACE, m_ItemHeight));

								if (localPos.x < m_Header->GetWidth(m_Header->DisplayIndexToIndex(0)) && expandRect.IsPointInside(localPos))
								{
									if (item)
										item->SetExpanded(!item->GetExpanded());

									e.Handled = true;
									break;
								}
							}

							e.Handled = true;
							Invalid();
						}
					}
					break;

				case InputEventArgs::kMouseUp:
					if ((e.Code == MC_LEFT_BUTTON || e.Code == MC_RIGHT_BUTTON)&&!IsOnGap(localPos))
					{
						bool checked = false;
						if (m_CheckIndex > -1 && m_CheckIndex < static_cast<S32>(m_Header->GetItemCount()))
						{
							U32 selectedIndex = (localPos.y-m_ItemGap) / (m_ItemHeight+m_ItemGap);
							if( localPos.y>=(m_ItemGap+m_ItemHeight)*selectedIndex+m_ItemGap 
								&& localPos.y<=(m_ItemGap+m_ItemHeight)*(selectedIndex+1) )
							{
								Core::Rectangle checkRect;
								checkRect.Min.x = m_Header->GetPos(m_CheckIndex) + SPLIT_WIDTH + m_MY_SPLIT_WIDTH;
								checkRect.Max.x = checkRect.Min.x + m_ItemHeight;
								checkRect.Min.y = (m_ItemGap+m_ItemHeight)*selectedIndex+m_ItemGap;
								checkRect.Max.y = (m_ItemGap+m_ItemHeight)*(selectedIndex+1);
								checkRect.Shrink(5);
								if (checkRect.IsPointInside(localPos))
								{
									checked = true;
									sharedc_ptr(ListItem) item = DisplayIndexToItem(selectedIndex);
									if (item && item->GetCanSelect())
									{
										item->SetCheck(!item->GetCheck());
										ChangeSelectItem(item);
										EventCheckChanged.Fire(ptr_static_cast<ListTreeView>(this), e);
									}
								}
							}
						}
						SetCapture(false);

						if (m_Selecting)
						{
							U32 index = (localPos.y-m_ItemGap) / (m_ItemHeight+m_ItemGap);
							if( localPos.y<(m_ItemGap+m_ItemHeight)*index+m_ItemGap 
								|| localPos.y>(m_ItemGap+m_ItemHeight)*(index+1) )
							{
								//clicked in the gap
								index = -1;
							}

							sharedc_ptr(ListItem) item = DisplayIndexToItem(index);
							m_MouseSelectedItem = DisplayIndexToItem(index);
							if (item && item->GetCanSelect())
							{
								m_SelectingIndex = index;
								m_LastIndex = index;
								if(e.Code == MC_LEFT_BUTTON)
								{	
									ChangeSelectItem(item);
								}
								else
								{
									//ChangeSelectItem(NullPtr);
								}
							}
						}

						if (!checked)
						{
							if (e.Code == MC_LEFT_BUTTON)
							{
								EventClick.Fire(ptr_static_cast<Self>(this), e);
							}
							if (e.Code == MC_RIGHT_BUTTON)
							{
								m_PopupMenu->SetTag(m_MouseSelectedItem);
								m_PopupMenu->SetLocation(ClientToGlobalScreen(ScreenToClient(e.CursorPosition)));
								EventRightClick.Fire(ptr_static_cast<Self>(this), e);
							}
						}
						m_Selecting = false;

						e.Handled = true;
						Invalid();
					}
					break;

				case InputEventArgs::kMouseMove:
					{
						{
							sharedc_ptr(ListItem) item = PointToNode(localPos);
							ListItemInputEventArgs tooltipEvent(e);
							tooltipEvent.Column = GetColumns()->PosToIndex(localPos.x);
							if (m_PointedItem != item)
							{
								OnNodeMouseLeave(ListItemInputEventArgs(e));

								m_PointedItem = item;
								tooltipEvent.Item = m_PointedItem;

								OnNodeMouseEnter(tooltipEvent);
								Invalid();
							}
							else if (m_PointedItem == item && m_PointedItem && item)
							{
								tooltipEvent.Item = m_PointedItem;

								OnNodeMouseMove(tooltipEvent);
								Invalid();
							}
							e.Handled = true;
						}
					}
					break;
				}
			}
			else
			{
				OnNodeMouseLeave(ListItemInputEventArgs(e));
				Invalid();
			}
		}

		if (e.Type == InputEventArgs::kMouseLeave)
			OnMouseLeave(e);

		if (e.IsKeyEvent())
			OnKeyEvent(e);

		if (!e.Handled)
			Super::OnInputEvent(e);
	}

	/// on key event
	void ListTreeView::OnKeyEvent(InputEventArgs & e)
	{
		if (e.Handled)
			return;

		// key down
		if (e.Type == InputEventArgs::kKeyDown && m_CanKeySelect)
		{
			bool selectedByKey = false;
			U32 displayCount = GetDisplayCount();

			switch (e.Code)
			{
			case KC_UP:
				if (m_SelectingIndex > 0)
				{
					U32 index = m_SelectingIndex - 1;

					selectedByKey = ChangeSelectedToIndex(index, e.ShiftKeyDown, e.ControlKeyDown);
				}
				e.Handled = true;
				break;

			case KC_DOWN:
				if (m_SelectingIndex < displayCount - 1)
				{
					U32 index = m_SelectingIndex + 1;
					selectedByKey = ChangeSelectedToIndex(index, e.ShiftKeyDown, e.ControlKeyDown);
				}
				e.Handled = true;
				break;

			case KC_LEFT:
				if (m_SelectingIndex < displayCount)
				{
					sharedc_ptr(ListItem) hItem = DisplayIndexToItem(m_SelectingIndex);

					if (hItem)
					{
						if (!GetTreeVisible())
						{
							if (!hItem->GetSelected())
								selectedByKey = ChangeSelectedToIndex(m_SelectingIndex , e.ShiftKeyDown, e.ControlKeyDown);

							e.Handled = true;
							break;
						}

						if (CanExpand(hItem) && hItem->GetExpanded())
						{
							hItem->SetExpanded(false);
						}
						else
						{
							sharedc_ptr(ListItem) hParent = hItem->GetParent();

							if (hParent)
							{
								U32 index = ItemToDisplayIndex(hParent);

								if (index < displayCount)
									selectedByKey = ChangeSelectedToIndex(index , e.ShiftKeyDown, e.ControlKeyDown);
							}
						}
					}
				}

				e.Handled = true;
				break;

			case KC_RIGHT:
				if (m_SelectingIndex < displayCount)
				{
					sharedc_ptr(ListItem) hItem = DisplayIndexToItem(m_SelectingIndex);

					if (hItem)
					{
						if (!(GetTreeVisible() && (CanExpand(hItem) || hItem->GetSelected())))
						{
							if (!hItem->GetSelected())
								selectedByKey = ChangeSelectedToIndex(m_SelectingIndex , e.ShiftKeyDown, e.ControlKeyDown);

							e.Handled = true;
							break;
						}

						if (hItem->GetExpanded())
						{
							sharedc_ptr(ListItem) hChild = hItem->GetFirstChild();
							U32 index = ItemToDisplayIndex(hChild);

							if (index < displayCount)
								selectedByKey = ChangeSelectedToIndex(index, e.ShiftKeyDown, e.ControlKeyDown);
						}
						else
							hItem->SetExpanded(true);
					}
				}
				e.Handled = true;
				break;

			case KC_PGUP:
				if (m_SelectingIndex > 0)
				{
					U32 pageItemCount = GetDisplayRect().GetExtent().y / (m_ItemHeight+m_ItemGap);
					S32 index= m_SelectingIndex - pageItemCount;
					index = index < 0? 0: index;

					selectedByKey = ChangeSelectedToIndex(index, e.ShiftKeyDown, e.ControlKeyDown);
				}
				e.Handled = true;
				break;

			case KC_PGDOWN:
				if (m_SelectingIndex < displayCount - 1)
				{
					U32 pageItemCount = GetDisplayRect().GetExtent().y / (m_ItemHeight+m_ItemGap);
					U32 index = m_SelectingIndex + pageItemCount;
					index = index > displayCount? displayCount - 1: index;

					selectedByKey = ChangeSelectedToIndex(index, e.ShiftKeyDown, e.ControlKeyDown);
				}
				e.Handled = true;
				break;

			case KC_HOME:
				if (m_SelectingIndex > 0)
				{
					U32 index= 0;
					selectedByKey = ChangeSelectedToIndex(index, e.ShiftKeyDown, e.ControlKeyDown);
				}
				e.Handled = true;
				break;

			case KC_END:
				if (m_SelectingIndex < displayCount - 1)
				{
					U32 index = displayCount - 1;
					selectedByKey = ChangeSelectedToIndex(index, e.ShiftKeyDown, e.ControlKeyDown);
				}
				e.Handled = true;
				break;

			case KC_SPACE:
				if (m_SelectingIndex < displayCount)
				{
					sharedc_ptr(ListItem) hItem = DisplayIndexToItem(m_SelectingIndex);

					if (hItem && !hItem->GetSelected())
					{
						if (!GetMultiSelect())
							ClearSelection();

						ChangeSelectItem(hItem);
						selectedByKey = true;
					}
				}
				e.Handled = true;
				break;

			default:
				break;
			}
		}
	}

	void ListTreeView::OnActiveChanged(EventArgs & e)
	{
		Super::OnActiveChanged(e);
		Invalid();
	}

	/// on drag enter
	void ListTreeView::OnDragEnter(DragEventArgs & e)
	{
	}

	/// on drag leave
	void ListTreeView::OnDragLeave(DragEventArgs & e)
	{
		m_DropTargetItem = NullPtr;
		Invalid();
	}

	/// on drag over
	void ListTreeView::OnDragOver(DragEventArgs & e)
	{
	}

	/// on drag drop
	void ListTreeView::OnDragDrop(DragEventArgs & e)
	{
	}

	/// on enter
	void ListTreeView::OnEnter(EventArgs & e)
	{
		Super::OnEnter(e);
	}

	/// on leave
	void ListTreeView::OnLeave(EventArgs & e)
	{
		Super::OnLeave(e);
	}


	void ListTreeView::OnSelectItemChanged(ListItemEventArgs & e)
	{
		EventSelectItemChange.Fire(ptr_static_cast<Self>(this), e);
	}

	void ListTreeView::OnDelete(EventArgs & e)
	{
		EventDelete.Fire(ptr_static_cast<Self>(this), e);
	}

	void ListTreeView::OnItemChange(EventArgs & e)
	{
		EventItemChange.Fire(ptr_static_cast<Self>(this), e);
	}

	void ListTreeView::OnSplitDoubleClick(HeaderEventArgs & e)
	{
		EventSplitDoubleClick.Fire(ptr_static_cast<Self>(this), e);
	}

	void ListTreeView::OnDrawItem(DrawItemEventArgs & e)
	{
		e.Item->OnDrawColumn(e,GetFontSize(),GetTextColor());
	}
	
	void ListTreeView::OnDrawItemText(DrawItemEventArgs & e)
	{		
		e.Item->OnDrawColumn(e,m_UseColFontSize,m_UseColFontCol);		
	}
  
	void ListTreeView::OnDrawItemBackgroud(DrawItemEventArgs & e)
	{
		if(!m_DrawItemBgWhenEmpty)
		{
			e.Item->OnDrawBackground(e);
		}

		if (e.Handled)
			return;

		tempc_ptr(ListItemSkin) skin = m_ItemSkin;
		
		if(e.Item->GetBGSkin())
			skin = e.Item->GetBGSkin();

		if (!e.Item->GetCanSelect())
		{
			if(skin)
			{
				Skin::DrawImage(e.render, skin->GetDisabledImage(), e.Rect);
			}
			else
			{
				XRGB grayColor = XRGB(128,128,128);
				e.render->DrawRectangle(e.Rect, e.Rect, grayColor);
			}
		}
		else if (e.Selected && e.Item->GetCanSelect())
		{
			if(skin)
			{
				Skin::DrawImage(e.render, skin->GetSelectedImage(), e.Rect);
			}
			else
			{
				XRGB selectColor = GetActive() ? XRGB(49,106,197) : XRGB(128,128,128);
				e.render->DrawRectangle(e.Rect, e.Rect, selectColor);
			}
		}
		else if(m_PointedItem && m_PointedItem == e.Item)
		{
			if(skin)
			{
				Skin::DrawImage(e.render, skin->GetHoverImage(), e.Rect);
			}
		}

		if(e.Item->GetWithFrame())
		{
			Skin::DrawImage(e.render, skin->GetFrameImage(), e.Rect);
		}

		if (m_DropTargetItem && e.Item == m_DropTargetItem)
		{
			e.render->DrawRectangle(e.Rect, e.Rect, XRGB(212, 208, 200));
			switch (m_ItemDragEffert)
			{
			case DragEventArgs::kBefore:
				{
					Core::Rectangle rect(Core::Vector2(e.Rect.Max.x, e.Rect.Min.y + 3), e.Rect.Min);
					e.render->DrawRectangle(e.Rect, e.Rect, XRGB(0, 0, 0));
				}
				break;

			case DragEventArgs::kMiddle:
				{
					Core::Rectangle rect(Core::Vector2(e.Rect.Max.x, e.Rect.Min.y + 3), e.Rect.Min);
					e.render->DrawRectangle(e.Rect, e.Rect, XRGB(0, 0, 0));

					rect = Core::Rectangle(Core::Vector2(e.Rect.Min.x, e.Rect.Max.y - 3), e.Rect.Max);
					e.render->DrawRectangle(e.Rect, e.Rect, XRGB(0, 0, 0));
				}
				break;

			case DragEventArgs::kAfter:
				{
					Core::Rectangle rect(Core::Vector2(e.Rect.Min.x, e.Rect.Max.y - 3), e.Rect.Max);
					e.render->DrawRectangle(e.Rect, e.Rect, XRGB(0, 0, 0));
				}
				break;
			}
		}

		if(e.Item->GetIsSelfItem())
		{
			if(skin)
			{
				Skin::DrawImage(e.render, skin->GetSelfImage(), e.Rect);
			}
		}
		e.Item->OnDrawLV_Background(e);
		e.Item->OnDrawInvite_Background(e);
	}

	void ListTreeView::OnDoubleClick(ListItemEventArgs & e)
	{
		EventDoubleClick.Fire(ptr_static_cast<ListTreeView>(this), e);
	}

	void ListTreeView::OnExpand(ListItemEventArgs & e)
	{
		EventExpand.Fire(ptr_static_cast<ListTreeView>(this), e);
	}

	/// on mouse leave
	void ListTreeView::OnMouseLeave(EventArgs & e)
	{
		OnNodeMouseLeave(ListItemInputEventArgs());
	}

	/// on node mouse enter
	void ListTreeView::OnNodeMouseEnter(ListItemInputEventArgs & e)
	{
		EventNodeMouseEnter.Fire(ptr_static_cast<ListTreeView>(this), ListItemInputEventArgs(e));
		if (e.Handled)
			return;

		m_ismouse_here = true;
		m_tooltipStartshow = 0.f;
	}

	/// on node mouse move
	void ListTreeView::OnNodeMouseMove(ListItemInputEventArgs & e)
	{
		//LogSystem.WriteLinef("%d",e.Column);
		OnNodeColumnMouseEnter(e);
	}

	/// on node column mouse enter
	void ListTreeView::OnNodeColumnMouseEnter(ListItemInputEventArgs & e)
	{
	}

	/// on node mouse leave
	void ListTreeView::OnNodeMouseLeave(ListItemInputEventArgs & e)
	{
		m_ismouse_here = false;
		m_tooltipStartshow = 0.5f;
		m_PointedItem = NullPtr;
		EventNodeMouseLeave.Fire(ptr_static_cast<ListTreeView>(this), e);
		if (e.Handled)
			return;
	}

	/// on column edit
	void ListTreeView::ColumnEdit(tempc_ptr(ListItem) hItem, U32 column)
	{
	}

	/// on column edit textbox value enter
	void ListTreeView::TextBox_ValueEnter(tempc_ptr(Core::Object) sender, EventArgs & e)
	{
	}

	/// on column edit textbox focus changed
	void ListTreeView::TextBox_OnFocusChanged(tempc_ptr(Core::Object) sender, EventArgs & e)
	{
		Control * p = ptr_static_cast<Control>(sender);

		e.Handled = true;
	}

	/// findbox on release
	void ListTreeView::FindBox_Release(tempc_ptr(Core::Object) sender)
	{
		if (sender)
		{
		}
	}

	/// on column edit textbox value enter
	void ListTreeView::TextBox_OnValueEnter(tempc_ptr(Core::Object) sender, EventArgs & e)
	{
		TextBox_ValueEnter(sender, e);
	}

	/// on findbox focus on changed
	void ListTreeView::FindBox_OnFocusChanged(tempc_ptr(Core::Object) sender, EventArgs & e)
	{
		Textbox * p = ptr_static_cast<Textbox>(sender);

		e.Handled = true;
	}


	/// on findbox on key up
	void ListTreeView::FindBox_OnKeyUp(tempc_ptr(Core::Object) sender, InputEventArgs & e)
	{
		if (e.Code == KC_ESCAPE)
			FindBox_Release(sender);

		e.Handled = true;
	}

	/// on findbox on value enter
	void ListTreeView::FindBox_OnValueEnter(tempc_ptr(Core::Object) sender, EventArgs & e)
	{
		Textbox * p = ptr_static_cast<Textbox>(sender);

		InputEventArgs * inputEvent = dynamic_cast<InputEventArgs *>(&e);

		if (p)
		{
			if (inputEvent->ControlKeyDown)
			{
				p->SetSelection(0, -1);
				SelectItemByColumnName(p->GetText());
			}
			else
				FindBox_Release(sender);

		}

		e.Handled = true;
	}

	/// findbox on text changed
	void ListTreeView::FindBox_OnTextChanged(tempc_ptr(Core::Object) sender, EventArgs & e)
	{
		Textbox * p = ptr_static_cast<Textbox>(sender);

		if (p)
		{
			SelectItemByColumnName(p->GetText(), 0, false);
		}
	}

	void ListTreeView::Header_OnItemChange(tempc_ptr(Core::Object) sender, EventArgs & e)
	{
		DirtyLayout();
	}

	void ListTreeView::Header_OnSplitDoubleClick(tempc_ptr(Core::Object) sender, HeaderEventArgs & e)
	{
		m_Header->SetWidth(e.Column, GetDisplayWidth(e.Column));
		OnSplitDoubleClick(e);
		DirtyLayout();
	}

	void ListTreeView::Header_OnMouseEnter(tempc_ptr(Core::Object) sender, EventArgs & e)
	{
		OnNodeMouseLeave(ListItemInputEventArgs());
	}
}

//--------------------------------------------------------------------------------------
// protected Method
//--------------------------------------------------------------------------------------
namespace Gui
{
	bool ListTreeView::CanExpand(tempc_ptr(ListItem) item)
	{
		if (item)
			return item->GetCanExpand() || item->GetFirstChild();

		return false;
	}

	void ListTreeView::ToggleExpand(tempc_ptr(ListItem) item)
	{
	}

	bool ListTreeView::IsSelect(tempc_ptr(ListItem) item)
	{
		if (item)
			return item->GetSelected();

		return false;
	}

	bool ListTreeView::IsExpand(tempc_ptr(ListItem) item)
	{
		if (item)
			return item->GetExpanded();

		return false;
	}

	void ListTreeView::ExpandCheck(tempc_ptr(ListItem) item)
	{
		if (item && item->GetExpanded())
		{
			tempc_ptr(ListItem) p = item->GetFirstChild();
			bool flag = false;

			U32 index = ItemToDisplayIndex(item);
			tempc_ptr(ListItem) hSelectigItem = DisplayIndexToItem(m_SelectingIndex);

			while(p && p->IsChildOf(item))
			{
				if (p->GetSelected())
				{
					p->SetSelected(false);
					flag = true;
				}

				if (hSelectigItem == p)
				{
					m_SelectingIndex = index;
					m_LastIndex = index;
				}

				p = p->GetNextNode();
			}

			if (item->GetSelected() || flag)
			{
				ChangeSelectItem(item);
			}
		}
	}

	void ListTreeView::ChangeSelectItem(tempc_ptr(ListItem) item)
	{
		if(m_SelectedItem!=item)
		{
			ClearSelection();
			m_SelectedItem = item;
			if(m_SelectedItem)
			{
				m_SelectedItem->SetSelected(true);
			}
			ListItemEventArgs e;
			e.Item = m_SelectedItem;
			OnSelectItemChanged(e);
			Invalid();
		}
	}

	void ListTreeView::ClearSelection()
	{
		for (tempc_ptr(ListItem) pNode = m_RootItem->GetFirstChild(); pNode; pNode = pNode->GetNextNode())
		{
			pNode->SetSelected(false);
		}
	}

	sharedc_ptr(ListItem) ListTreeView::DisplayIndexToItem(U32 displayIndex)
	{
		if(displayIndex<0)
			return NullPtr;
		bool flag = false;
		U32 index = 0;
		for (tempc_ptr(ListItem) item = m_RootItem->GetFirstChild(); item; item = item->GetNextNode(flag))
		{
			if(!item->GetVisible())
				continue;

			flag = !m_TreeVisible || !item->GetExpanded();
			if (index == displayIndex)
			{
				return item;
			}			

			++index;
		}
		return NullPtr;
	}

	U32 ListTreeView::ItemToDisplayIndex(tempc_ptr(ListItem) item)
	{
		if (!item)
			return -1;

		if(!item->GetVisible())
			return -1;
		bool flag = false;
		U32 index = 0;
		for (tempc_ptr(ListItem) node = m_RootItem->GetFirstChild(); node; node = node->GetNextNode(flag))
		{
			if(!item->GetVisible())
				continue;

			flag = !m_TreeVisible || !node->GetExpanded();

			if (item == node)
			{
				return index;
			}			

			++index;
		}
		return -1;
	}

	void ListTreeView::DisplayNodeDashed(tempc_ptr(Client::UIRender) render, tempc_ptr(ListItem) item, U32 index)
	{
		if (item)
		{
			bool expanded = IsExpand(item);
			int IconHeight = 16;
			Core::Rectangle expandRect = Core::Rectangle::LeftTop(Core::Vector2(item->GetLevel() * LEVELSPACE, 0),Core::Vector2(LEVELSPACE, m_ItemHeight));
			Core::Rectangle spaceRect = expandRect;

			sharedc_ptr(ListItem) parent = item->GetParent();

			tempc_ptr(ListTreeViewSkin) skin = ptr_dynamic_cast<ListTreeViewSkin>(GetSkin());

			/// show dash lines
			if (m_ShowLines)
			{
				for (S8 j=item->GetLevel() - 1; j>=0; ++j)
				{
					spaceRect.Move(Core::Vector2(-LEVELSPACE, 0));

					if (!parent)
					{
						break;
					}

					if (parent->GetNextNode(true) && parent->GetLevel() == parent->GetNextNode(true)->GetLevel())
					{
						if(skin)
							Skin::DrawImage(render, skin->GetVDashImage(), spaceRect);
						else
							render->DrawRectangle(spaceRect, spaceRect, ARGB(123,123,123,123));
					}
					parent = parent->GetParent();

				}

				if(skin)
					Skin::DrawImage(render, skin->GetHalfHDashImage(), expandRect);

				if (m_RootItem->GetFirstChild())
				{
					tempc_ptr(ListItem) hFirstChild = m_RootItem->GetFirstChild();
					tempc_ptr(ListItem) hLastChild = m_RootItem->GetLastChild();

					if (item == hFirstChild && item == hLastChild)
					{
					}
					else if (item == hFirstChild)
					{
						Core::Rectangle temp = expandRect;

						if(skin)
							Skin::DrawImage(render, skin->GetHalfVDashImage(), temp.Move(Core::Vector2(0,8)));
						else
							render->DrawRectangle(temp.Move(Core::Vector2(0,8)), temp.Move(Core::Vector2(0,8)), ARGB(123,123,123,123));
					}
					else if (!item->GetNextNode(true) || item->GetNextNode(true)->GetLevel() != item->GetLevel())
					{
						if(skin)
							Skin::DrawImage(render, skin->GetHalfVDashImage(), expandRect);
						else
							render->DrawRectangle(expandRect, expandRect, ARGB(123,123,123,123));
					}
					else
					{
						if(skin)
							Skin::DrawImage(render, skin->GetVDashImage(), expandRect);
						else
							render->DrawRectangle(expandRect, expandRect, ARGB(123,123,123,123));
					}
				}

			}

			if (CanExpand(item))
			{
				if(skin)
				{
					Skin::DrawImage(render, expanded?skin->GetExpandedImage():skin->GetCollapsedImage(), expandRect.Shrink(3));
				}
				else
				{
					render->DrawRectangle(expandRect, expandRect, expanded?ARGB(255,0,255,0):ARGB(255,255,0,0));
				}
			}
		}
	}

	F32 ListTreeView::GetAllWidth()
	{
		return m_Header->GetAllWidth();
	}

	F32 ListTreeView::GetDisplayWidth(U32 column)
	{
		F32 width = 0;
		bool flag = false;
		U32 displayIndex = m_Header->IndexToDisplayIndex(column);

		if (1)
		{
			sharedc_ptr(Font) font = GetFont();

			if (font)
			{
				for (tempc_ptr(ListItem) item = m_RootItem->GetFirstChild(); item; item = item->GetNextNode(flag))
				{
					flag = !m_TreeVisible || !item->GetExpanded();

					Core::Vector2 size = Skin::MeasureIconText(item->GetIcon(column), font, item->GetText(column));

					width = Max(width, size.x  + 2 * (SPLIT_WIDTH + m_MY_SPLIT_WIDTH) + (displayIndex ? 0: m_TreeVisible?(item->GetLevel() + 1) * LEVELSPACE: 0));
				}
			}
		}

		return Core::Max(width, 10.f);
	}

	bool ListTreeView::ChangeSelectedToIndex(U32 index, bool shiftKeyDown, bool ctrlKeyDown)
	{
		sharedc_ptr(ListItem) hItem = DisplayIndexToItem(index);

		if (hItem)
		{
			ChangeSelectItem(hItem);
			m_LastIndex = index;

			m_SelectingIndex = index;
			m_LastIndex = index;
			//ScrollToItem(index);
			return true;
		}

		return false;
	}

	/// create find textBox
	bool ListTreeView::CreateFindBox()
	{
		if (m_FindBox)
			return false;

		return true;
	}
}


//--------------------------------------------------------------------------------------
// Method
//--------------------------------------------------------------------------------------
namespace Gui
{
	sharedc_ptr(ListItem) ListTreeView::CreateItem()
	{
		return ptr_new ListItem;
	}

	sharedc_ptr(ListItem) ListTreeView::AddItem(tempc_ptr(ListItem) parent, const Core::String & string)
	{
		if (parent)
		{
			sharedc_ptr(ListItem) item = ptr_new ListItem;

			if (item)
			{
				item->SetColumnCount(m_Header->GetItemCount());
				item->SetText(0, string);
				item->SetParent(parent);
				item->SetLevel(parent->GetLevel() + 1);

				EventArgs e;
				OnItemChange(e);

				if (m_AutoColumnSize)
					AutoColumnSize(0);

				DirtyLayout();
			}

			return item;
		}
		return NullPtr;
	}

	/// Adds a existing item.
	void ListTreeView::AddExistingItem(tempc_ptr(ListItem) parent, tempc_ptr(ListItem) item)
	{
		if (parent && item)
		{
			item->SetColumnCount(m_Header->GetItemCount());
			item->SetParent(parent);
			item->SetLevel(parent->GetLevel() + 1);

			EventArgs e;
			OnItemChange(e);

			if (m_AutoColumnSize)
				AutoColumnSize(0);

			DirtyLayout();
		}
	}

	void ListTreeView::AddSubItem(tempc_ptr(ListItem) item, const Core::String & string)
	{
		if (item)
		{
			item->AddSubItem(string);
			Invalid();
		}
	}

	void ListTreeView::AddColumn(const Core::String & string, F32 width /* = 60 */, Client::Unit::Align columnAlign /* = Client::Unit::kAlignLeftMiddle */)
	{
		m_Header->AddItem(string, width, false, columnAlign);

		DirtyLayout();
	}

	void ListTreeView::AddFilterColumn(const Core::String & string, F32 width /* = 60 */, Client::Unit::Align columnAlign /* = Client::Unit::kAlignLeftMiddle */)
	{
		m_Header->AddItem(string, width, true, columnAlign);

		DirtyLayout();
	}

	void ListTreeView::DeleteNode(tempc_ptr(ListItem) item)
	{
		if (item)
		{
			item->SetParent(NullPtr);
			DirtyLayout();
		}
	}

	void ListTreeView::DeleteAll(bool mute /* = false */)
	{
		m_SelectingIndex = 0;
		m_LastIndex = 0;
		if(m_SelectedItem)
		{
			if(mute)
			{
				m_SelectedItem = NullPtr;
				ClearSelection();
			}
			else
				ChangeSelectItem(NullPtr);
		}

		while (m_RootItem->GetFirstChild())
			DeleteNode(m_RootItem->GetFirstChild());
	}

	void ListTreeView::DeleteColumns()
	{
		m_Header->DeleteAll();
	}

	/// before select
	void ListTreeView::BeforeSelect(tempc_ptr(ListItem) item)
	{
		if (item && item->GetCanSelect())
		{
		}
	}

	/// after select
	void ListTreeView::AfterSelect(tempc_ptr(ListItem) item)
	{
		if (item && item->GetCanSelect())
		{
		}
	}

	/// before expand
	void ListTreeView::BeforeExpand(tempc_ptr(ListItem) item)
	{
		if (item && CanExpand(item))
		{
			ExpandCheck(item);

			m_SelectingItem = DisplayIndexToItem(m_SelectingIndex);

			if (m_AutoColumnSize)
				AutoColumnSize(0);
		}
	}

	/// after expand
	void ListTreeView::AfterExpand(tempc_ptr(ListItem) item)
	{
		if (item && CanExpand(item))
		{
			if (m_AutoColumnSize)
				AutoColumnSize(0);

			ListItemEventArgs e;
			e.Item = item;
			OnExpand(e);

			if (!e.Handled)
				ToggleExpand(item);

			U32 index = ItemToDisplayIndex(m_SelectingItem);

			if (index < GetDisplayCount())
			{
				m_SelectingIndex = index;
				m_LastIndex = index;
			}

			DirtyLayout();
		}
	}

	Core::String ListTreeView::GetItemText(tempc_ptr(ListItem) item, U32 column)
	{
		if (item)
			return item->GetText(column);

		return Core::String::kEmpty;
	}

	void ListTreeView::SetItemText(tempc_ptr(ListItem) item, U32 column, const Core::String & text)
	{
		if (item)
		{
			const Core::String & value = item->GetText(column);
			if (value != text)
			{
				item->SetText(column, text);
				Invalid();
			}
		}
	}

	bool ListTreeView::HasItem(tempc_ptr(ListItem) item)
	{
		if (item)
		{
			for (tempc_ptr(ListItem) pNode = m_RootItem->GetFirstChild(); pNode; pNode = pNode->GetNextNode())
			{
				if (item == pNode)
					return true;
			}
		}

		return false;
	}

	void ListTreeView::AutoColumnSize(U32 column)
	{
		if (column < m_Header->GetItemCount())
			m_Header->SetWidth(column, GetDisplayWidth(column));
	}

	void ListTreeView::Sort(tempc_ptr(ListItem) item, S32 column, bool reverse, bool sortChilds, by_ptr(ListTreeView::SortFunc) func)
	{
		if(!func)
			func = m_DefaultStrCompare;
		try{
			tempc_ptr(ListItem) q = item;

			while (q && q->GetNext())
			{
				tempc_ptr(ListItem) min = q;
				tempc_ptr(ListItem) p = q;

				while (p = p->GetNext())
				{
					if (p->GetText(0) != "")
					{
						bool ret = (*func)(min, p, column, (int)reverse);
						if(ret)
						{
							min = p;
						}
					}
				}

				if (sortChilds)
				{
					if (tempc_ptr(ListItem) child = min->GetFirstChild())
					{
						Sort(child, column, reverse, sortChilds, func);
					}
				}

				if (min != q)
				{
					min->InsertBefore(q);
				}
				else if (min == q)
				{
					q = q->GetNext();
				}
			}
		}
		catch(...)
		{
			Console.WriteLine("Errors in SortFunc defined in lua");
		}
		Invalid();
	}

	//REGISTER_PDE_TYPE(SortFunc);
	void ListTreeView::SortColumn(S32 column, bool sortChilds, by_ptr(SortFunc) func)
	{
		m_Header->SetSortID(column);
		m_Header->SetCurrentSorter(func);

		if (column >= 0)
		{
			Sort(GetRootItem()->GetFirstChild(), column, m_Header->GetSortReverse(), sortChilds, func);
		}
	}

	void ListTreeView::SortColumnExt(S32 column, bool sortChilds, by_ptr(SortFunc) func)
	{
		if (m_Header->IndexToItem(column) && m_Header->IndexToItem(column)->Text != "")
		{
			bool reverse = false;
			if(column == m_Header->GetSortID())
			{
				reverse = !m_Header->GetSortReverse();
			}
			else
			{
				m_Header->SetSortID(column);
			}
			m_Header->SetSortReverse(reverse);
			m_Header->SetCurrentSorter(func);
		}
	}

	void ListTreeView::Filter(tempc_ptr(ListItem) item, const FilterCompare& comp, const Core::String& str)
	{
		tempc_ptr(ListItem) q = item;
		while(q)
		{
			if(!comp(q, str))
			{
				q->SetVisible(false);
				if(q->GetSelected()||GetSelectedItem()==q)
				{
					SetSelectedItem(NullPtr);
				}
			}
			q = q->GetNext();
		}
		Invalid();
	}

	void ListTreeView::FilterColumn(S32 column, const Core::String& str)
	{
		// 		m_Header->SetSortID(column);
		// 		m_Header->SetSortReverse(reverse);

		if (column >= 0)
		{
			FilterCompare comp(column);
			Filter(GetRootItem()->GetFirstChild(), comp, str);
		}
	}

	sharedc_ptr(ListItem) ListTreeView::GetItemAt(const Core::Vector2 & position)
	{
		U32 index = position.y / m_ItemHeight;
		return DisplayIndexToItem(index);
	}

	void ListTreeView::ScrollToItem(U32 index)
	{
		if (index < GetDisplayCount())
		{
			//Patch
			//(without this patch, the header will cover the first item in display area when scrolling up by pressing keyboard"up")
			F32 topY = (m_ItemHeight+m_ItemGap)*index+m_ItemGap+GetHeaderHeight();
			if(topY-GetHeaderHeight()<m_Scroll.y)
				topY-=GetHeaderHeight();
			//End patch
			ScrollToView(Core::Rectangle::LeftTop(Core::Vector2(0, topY), Core::Vector2(GetDisplayRect().Max.x, m_ItemHeight)));
			Invalid();
		}
	}

	/// find item by name
	void ListTreeView::SelectItemByColumnName(const Core::String & name, U32 column, bool skipSelf)
	{
		if (column >= GetColumns()->GetItemCount() || name == "")
			return;

		tempc_ptr(ListItem) pStart = NullPtr;

		tempc_ptr(ListItem) hSelectingItem = DisplayIndexToItem(m_SelectingIndex);

		if (hSelectingItem)
		{
			pStart = hSelectingItem;

			if (!skipSelf && NameMatchWithText(hSelectingItem->GetText(column), name))
			{
				SetSelectedItem(hSelectingItem);
				return;
			}
		}
		else
			pStart = m_RootItem;

		tempc_ptr(ListItem) pNode = pStart->GetNextNode(!pStart->GetExpanded());

		while (pNode != pStart)
		{
			if (!pNode)
			{
				pNode = m_RootItem->GetFirstChild();
				continue;
			}

			if (NameMatchWithText(pNode->GetText(column), name))
			{
				SetSelectedItem(pNode);
				return;
			}

			pNode = pNode->GetNextNode(!pNode->GetExpanded());
		}

		if (pNode && NameMatchWithText(pNode->GetText(column), name))
			SetSelectedItem(pNode);
	}

	/// text match with name
	bool ListTreeView::NameMatchWithText(const Core::String & name, const Core::String & text)
	{
		if (GetFindByRegular())
			return StrMatch(name, text);

		Core::CStrBuf<256> str1;
		Core::CStrBuf<256> str2;
		str1.copy(name.RefStr());
		str2.copy(text.RefStr());
		str1.tolower();
		str2.tolower();

		return str1.startwith(str2);
	}

	/// point to node
	sharedc_ptr(ListItem) ListTreeView::PointToNode(const Core::Vector2 & pos)
	{
		U32 index = (pos.y-m_ItemGap) / (m_ItemHeight+m_ItemGap);
		sharedc_ptr(ListItem) item = DisplayIndexToItem(index);

		if (item)
		{
			F32 space = item->GetLevel() * LEVELSPACE;
			Core::Rectangle rect = Core::Rectangle::LeftTop(Core::Vector2(space, (m_ItemHeight+m_ItemGap)*index+m_ItemGap),Core::Vector2(m_Header->GetAllWidth() - space, m_ItemHeight));

			if (rect.IsPointInside(pos))
				return item;
		}

		return NullPtr;
	}

	void ListTreeView::Ready()
	{
		m_Header->UpdateComboBoxes();
		m_Header->ReapplyAllConditions();
	}

	void ListTreeView::SetAllItemsVisible(bool bVisible)
	{
		tempc_ptr(ListItem) rootItem = GetRootItem();
		if(rootItem)
		{
			tempc_ptr(ListItem) curItem = rootItem->GetFirstChild();
			while(curItem)
			{
				curItem->SetVisible(bVisible);
				curItem = curItem->GetNext();
			}
		}
	}
}


