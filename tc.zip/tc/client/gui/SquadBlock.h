
namespace Client
{
	struct ClientAddress;
	struct TeamMember;
}

namespace Gui
{
	class SquadBlockSkin: public ControlSkin
	{
	public:
		INLINE_PDE_ATTRIBUTE_RW(LeaderImage,		tempc_ptr(Image));

	private:
		sharedc_ptr(Image) m_LeaderImage;
	};
}

namespace Gui
{
	struct SquadMemberAddress
	{
		uint server_id;
		uint channel_id;
		uint room_id;

		Core::String server_name;
		Core::String channel_name;

		SquadMemberAddress()
			: server_id(0)
			, channel_id(0)
			, room_id(0)
		{
		}

		SquadMemberAddress(uint server, uint channel, uint room)
			: server_id(server)
			, channel_id(channel)
			, room_id(room)
		{
		}

		SquadMemberAddress(const Client::ClientAddress& address);

		const SquadMemberAddress& operator=(const Client::ClientAddress& address);
		bool operator==(const Client::ClientAddress& address);

		void Clear()
		{
			server_id = 0;
			channel_id = 0;
			room_id = 0;
			server_name = "";
			channel_name = "";
		}
	};

	class SquadBlock: public Control
	{
	public:
		DECLARE_PDE_OBJECT(SquadBlock, Control);
	public:
		DECLARE_PDE_ATTRIBUTE_RW(IsLeader,	bool);
		DECLARE_PDE_ATTRIBUTE_R(HostIsLeader, bool);
		DECLARE_PDE_ATTRIBUTE_RW(IsMyself,	bool);
		DECLARE_PDE_ATTRIBUTE_RW(Name, const Core::String&);
		DECLARE_PDE_ATTRIBUTE_RW(Level, int);
		DECLARE_PDE_ATTRIBUTE_RW(Status, int);
		DECLARE_PDE_ATTRIBUTE_R (ClientAddress, const SquadMemberAddress&);
		DECLARE_PDE_ATTRIBUTE_W (ClientAddress, const Client::ClientAddress&);
		DECLARE_PDE_ATTRIBUTE_RW(Empty, bool);
		DECLARE_PDE_ATTRIBUTE_R	(Exp, F32);
		DECLARE_PDE_ATTRIBUTE_R (ExpBar, tempc_ptr(ExperienceBar));

	public:
		SquadBlock();
		~SquadBlock();

		// on create
		virtual void OnCreate();

		// on destroy
		virtual void OnDestroy();

		// on frame update
		virtual void OnFrameUpdate(EventArgs & e);

		// on event
		virtual void OnInputEvent(InputEventArgs & e);

		// on paint
		virtual void OnPaint(PaintEventArgs & e);

// 		// on Contextual Menu click
// 		void OnRMenuClick(by_ptr(void) sender, InputEventArgs &e);

		void OnButtonFollowClick(by_ptr(void) sender, InputEventArgs &e);

		void OnButtonCallClick(by_ptr(void) sender, InputEventArgs &e);

		void SetButtonVisibility(bool bFollow, bool bCall);

		//------------------------Utilities-----------------

		void	Show();

		void	Hide();

		void	MoveForward();

		void	MoveBackward();

// 		void	ReorganizeRMenu();

		tempc_ptr(SquadBlock) NextBlock();

		void	SetBaseExp(F32 baseExp);
		void	SetNewExp(F32 newExp);

	protected:
		bool				m_IsLeader;
		bool				m_IsMyself;
		Core::String		m_Name;
		int					m_Level;
		int					m_Status;	//0: lobby  none-0: game
		SquadMemberAddress  m_ClientAddress;
		bool				m_Empty;
		sharedc_ptr(Button)	m_ButtonCall;
		sharedc_ptr(Button)	m_ButtonFollow;
		F32					m_Exp;
		sharedc_ptr(ExperienceBar) m_ExpBar;
	};

	class SquadPanel: public Control
	{
	public:
		enum PanelStates
		{
			kSquadEmpty,
			kSquadNormal,
			kInvitedQuery,
			kCalledQuery,
			kSquadInvalid,
		};
	public:
		DECLARE_PDE_OBJECT(SquadPanel,	Control);
		DECLARE_PDE_ATTRIBUTE_R(HostIsLeader, bool);
		DECLARE_PDE_ATTRIBUTE_R(HostAddress, const SquadMemberAddress&);
		INLINE_PDE_ATTRIBUTE_R(ContextualMenu, tempc_ptr(Menu));
		DECLARE_PDE_ATTRIBUTE_R(IsReady,	bool);

	public:
		SquadPanel();
		~SquadPanel();

		// on create
		virtual void OnCreate();

		// on destroy
		virtual void OnDestroy();

		// on layout
		virtual void OnLayout(EventArgs & e);

		// on frame update
		virtual void OnFrameUpdate(EventArgs & e);

		// on event
		virtual void OnInputEvent(InputEventArgs & e);

		// on paint
		virtual void OnPaint(PaintEventArgs & e);

		void ChangeState(PanelStates newState);
	
		void RebuildSquadList();

		void UpdateSquadList();

		void AddLevel(F32 fValue, const Core::String& rank, tempc_ptr(Gui::Icon) rankIcon);

		void Ready();

		void Rebuild();

		void Clear();

		void OnResponseTeamInvite( const Core::String& name, int result );

		void OnResponseTeamJoin( const Core::String& name, int result );

		void OnTeamInvite(const Core::String& name, int uid);

		void OnTeamLeave();

		void OnLeaderCall(uint server_id, uint channel_id, ushort room_id, const Core::String& invite_name);

		void OnLeaderCancelCall(uint server_id, uint channel_id, ushort room_id);

		void OnButtonConfirm(by_ptr(void) sender, InputEventArgs &e);

		void OnButtonReject(by_ptr(void) sender, InputEventArgs &e);

		//void OnSquadBlockRButtonClicked(tempc_ptr(SquadBlock) trigger, Vector2 globalPosition);

		void UpdateMember(const Client::TeamMember& member);

		void NewMember(const Client::TeamMember& member);

		void RemoveMember(const Core::String& name);

		void OnLeaderChanged(const Core::String& name);

		int  GetMemberCount();

	protected:
		void					ClearBlocks();

		tempc_ptr(SquadBlock)	GetFirstBlock();

		tempc_ptr(SquadBlock)	GetFirstEmptyBlock();

		tempc_ptr(SquadBlock)	FindMember(const Core::String& name);

	protected:
		PanelStates		m_PanelState;
		sharedc_ptr(Control) m_RootNode;
		sharedc_ptr(Button)	m_ButtonConfirm;
		sharedc_ptr(Button)	m_ButtonReject;
		sharedc_ptr(Menu)	m_ContextualMenu;
		sharedc_ptr(ProportionIcon)	m_ProportionIcon;

		Core::String	m_InviterName;
		int				m_InviterUid;

		Core::String	m_CallerName;
		uint			m_CallerServer;
		uint			m_CallerChannel;
		ushort			m_CallerRoom;

		F32				m_Timer;
		bool			m_Ready;
	};
}