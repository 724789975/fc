namespace Gui
{
	class Icon : public Image
	{
	public:
		enum IconTextDisplay
		{
			kIconTextActualSize,
			kIconTextFullFill,
		};
	public:
		// default constructor
		Icon();

		// constructor
		Icon(const Core::Identifier & path, const Core::Vector4 & border,Core::Vector4 uv = Core::Vector4(0,0,1,1));
		
		// destructor
		~Icon();

	public:
		INLINE_PDE_ATTRIBUTE_RW(DisplayType, IconTextDisplay);

	protected:
		IconTextDisplay		m_DisplayType;
	};
}

namespace Gui
{
	class ProportionIcon: public Icon
	{
	public:
		DECLARE_PDE_OBJECT(ProportionIcon, Icon);

	public:
		// default constructor.
		ProportionIcon();

		// constructor.
		ProportionIcon(const Core::Identifier & bg_path, const Core::Identifier & fg_path, const Core::Vector4 & bg_border, const Core::Vector4 & fg_border);

		// destructor
		~ProportionIcon();

	public:
		DECLARE_PDE_ATTRIBUTE_RW(BgBorder,		const Core::Vector4 &);
		DECLARE_PDE_ATTRIBUTE_RW(FgBorder,		const Core::Vector4 &);
		DECLARE_PDE_ATTRIBUTE_RW(BgPath,		const Core::Identifier &);
		DECLARE_PDE_ATTRIBUTE_RW(FgPath,		const Core::Identifier &);
		DECLARE_PDE_ATTRIBUTE_RW(Proportion,	F32);	//0.f-1.f
		DECLARE_PDE_ATTRIBUTE_RW(BarPadding,	const Core::Vector4 &);

	public:
		virtual bool IsReady() { return Super::IsReady() && m_FgTexture && m_FgTexture->IsReady(); }

	public:
		// draw
		virtual void Draw(by_ptr(Client::UIRender) render, const Core::Rectangle & rect, Core::ARGB color);

	protected:
		F32			  m_Propotion;
		Core::Vector4 m_FgBorder;
		Core::Vector4 m_BarPadding;
		sharedc_ptr(Client::Texture2D) m_FgTexture;
	};

	class CompareIcon: public Icon
	{
	public:
		DECLARE_PDE_OBJECT(CompareIcon, Icon);

	public:
		// default constructor.
		CompareIcon();

		// constructor.
		CompareIcon(const Core::Identifier & bg_path, const Core::Identifier & fg_path, const Core::Identifier & fg_plus_path, const Core::Identifier & fg_minus_path
			, const Core::Vector4 & bg_border, const Core::Vector4 & fg_border);

		// destructor
		~CompareIcon();

	public:
		DECLARE_PDE_ATTRIBUTE_RW(BgBorder,		const Core::Vector4 &);
		DECLARE_PDE_ATTRIBUTE_RW(FgBorder,		const Core::Vector4 &);
		DECLARE_PDE_ATTRIBUTE_RW(BgPath,		const Core::Identifier &);
		DECLARE_PDE_ATTRIBUTE_RW(FgPath,		const Core::Identifier &);
		DECLARE_PDE_ATTRIBUTE_RW(FgPlusPath,	const Core::Identifier &);
		DECLARE_PDE_ATTRIBUTE_RW(FgMinusPath,	const Core::Identifier &);
		DECLARE_PDE_ATTRIBUTE_RW(BaseValue,		F32);	//0.f-1.f
		DECLARE_PDE_ATTRIBUTE_RW(ComparativeValue,	F32);
		DECLARE_PDE_ATTRIBUTE_RW(BarPadding,	const Core::Vector4 &);

	public:
		virtual bool IsReady() { return Super::IsReady() && m_FgTexture && m_FgTexture->IsReady() && m_FgPlusTexture->IsReady() && m_FgMinusTexture->IsReady(); }

	public:
		// draw
		virtual void Draw(by_ptr(Client::UIRender) render, const Core::Rectangle & rect, Core::ARGB color);

	protected:
		F32			  m_BaseValue;
		F32			  m_ComparativeValue;
		Core::Vector4 m_FgBorder;
		Core::Vector4 m_BarPadding;
		sharedc_ptr(Client::Texture2D) m_FgTexture;
		sharedc_ptr(Client::Texture2D) m_FgPlusTexture;
		sharedc_ptr(Client::Texture2D) m_FgMinusTexture;
	};
}