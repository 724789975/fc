#include "pch.h"

using namespace Core;
using namespace Client;
using namespace Gui;

//--------------------------------------------------------------------------------------
// type info
//--------------------------------------------------------------------------------------
DEFINE_PDE_TYPE_CLASS(DragLabel)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Control);
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_PROPERTY_RW(TextPadding);
		ADD_PDE_PROPERTY_RW(TextAlign);
		ADD_PDE_PROPERTY_RW(Icon);
		ADD_PDE_PROPERTY_RW(AutoWrap);
		ADD_PDE_PROPERTY_RW(AutoFontSize);
		ADD_PDE_PROPERTY_RW(AutoEllipsis);
		ADD_PDE_PROPERTY_RW(UseTimer);
		ADD_PDE_PROPERTY_RW(DisplayTime);
		ADD_PDE_PROPERTY_RW(Iimit);
		ADD_PDE_METHOD(Show);
	}
};

REGISTER_PDE_TYPE(DragLabel);

namespace Gui
{
	DragLabel::DragLabel()
		: m_TextAlign(Client::Unit::kAlignLeftMiddle)
		, m_AutoWrap(false)
		, m_UseTimer(false)
		, m_AutoFontSize(false)
		, m_AutoEllipsis(false)
		, m_TextPadding(2,0,2,0)
		, m_Timer(0)
		, m_DisplayTime(10)
		, m_IsInArea(false)
		, m_IsStartDrag(false)
		, m_Iimit(0,0,1600,900)
	{

	}

	DragLabel::~DragLabel()
	{
	}
}


//--------------------------------------------------------------------------------------
// Attribute
//--------------------------------------------------------------------------------------
namespace Gui
{
	PDE_ATTRIBUTE_GETTER(DragLabel, DisplayTime,F32)
	{
		return m_DisplayTime;
	}


	PDE_ATTRIBUTE_SETTER(DragLabel, DisplayTime,F32)
	{
		if (m_DisplayTime != value)
			m_DisplayTime = value;
	}


	PDE_ATTRIBUTE_GETTER(DragLabel, TextAlign, Client::Unit::Align)
	{
		return m_TextAlign;
	}


	PDE_ATTRIBUTE_SETTER(DragLabel, TextAlign, Client::Unit::Align)
	{
		if (m_TextAlign != value)
		{
			m_TextAlign = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(DragLabel, Icon, tempc_ptr(Icon))
	{
		return m_Icon;
	}


	PDE_ATTRIBUTE_SETTER(DragLabel, Icon, tempc_ptr(Icon))
	{
		if (m_Icon != value)
		{
			m_Icon = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(DragLabel, TextPadding, Core::Vector4)
	{
		return m_TextPadding;
	}

	PDE_ATTRIBUTE_GETTER(DragLabel, Iimit, Core::Vector4)
	{
		return m_Iimit;
	}

	PDE_ATTRIBUTE_SETTER(DragLabel, Iimit, Core::Vector4)
	{
		if(m_Iimit!=value)
		{
			m_Iimit = value;
		}
	}

	PDE_ATTRIBUTE_SETTER(DragLabel, TextPadding, Core::Vector4)
	{
		if(m_TextPadding!=value)
		{
			m_TextPadding = value;
			EllipsisMyText();
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(DragLabel, AutoWrap, bool)
	{
		return m_AutoWrap;
	}

	PDE_ATTRIBUTE_SETTER(DragLabel, AutoWrap, bool)
	{
		if(m_AutoWrap!=value)
		{
			m_AutoWrap = value;
			if(m_AutoWrap)
			{
				SetAutoSize(false);
// 				SetTextAlign(Client::Unit::kAlignLeftTop);
				ReWrapText();
				EllipsisMyText();
			}
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(DragLabel, AutoFontSize, bool)
	{
		return m_AutoFontSize;
	}

	PDE_ATTRIBUTE_SETTER(DragLabel, AutoFontSize, bool)
	{
		if(m_AutoFontSize!=value)
		{
			m_AutoFontSize = value;
			if(m_AutoFontSize)
			{
				m_ResultFontSize = GetFontSize();
				SetAutoSize(false);
				CalcFontSize();
			}
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(DragLabel, AutoEllipsis, bool)
	{
		return m_AutoEllipsis;
	}

	PDE_ATTRIBUTE_SETTER(DragLabel, AutoEllipsis, bool)
	{
		if(m_AutoEllipsis!=value)
		{
			m_AutoEllipsis = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(DragLabel, UseTimer, bool)
	{
		return m_UseTimer;
	}

	PDE_ATTRIBUTE_SETTER(DragLabel, UseTimer, bool)
	{
		if(m_UseTimer!=value)
		{
			m_UseTimer = value;
			Invalid();
		}
	}
}


//--------------------------------------------------------------------------------------
// Event
//--------------------------------------------------------------------------------------
namespace Gui
{
	/// on auto size
	void DragLabel::OnAutoSize(AutoSizeEventArgs & e)
	{
		Core::Vector4 textPadding = GetTextPadding();
		e.clientRect.Max = Skin::MeasureIconText(GetIcon(), GetFont(), GetText()) + Vector2(textPadding.x+textPadding.z, textPadding.y+textPadding.w);

 		Super::OnAutoSize(e);
	}
	
	/// on text changed
	void DragLabel::OnTextChanged(EventArgs & e)
	{
		ReWrapText();
		CalcFontSize();
		EllipsisMyText();
	}

	void DragLabel::OnPaint(PaintEventArgs & e)
	{
		
		F64 timer = Task::GetTotalTime() - m_Timer;

		if(m_UseTimer && m_Timer!=0 && timer >m_DisplayTime)
		{
			Close();
		}

		Super::OnPaint(e);
		Core::Vector4 textPadding = GetTextPadding();
		Core::Rectangle rect(Vector2(textPadding.x, textPadding.y), GetSize() - Vector2(textPadding.z, textPadding.w));

		if(m_AutoFontSize)
			Skin::DrawIconText(e.render, GetIcon(), GetAutoFont(), GetText(), rect, GetTextAlign(), ARGB(255, 255, 255, 255), GetTextColor());
		else
			Skin::DrawIconText(e.render, GetIcon(), GetFont(), m_AutoEllipsis?m_EllipsisStr:(m_AutoWrap?m_MultiLineStr:m_Text), rect, GetTextAlign(), ARGB(255, 255, 255, 255), GetTextColor());
	}

	void DragLabel::OnInputEvent(InputEventArgs & e)
	{
		if (e.Type == InputEventArgs::kMouseEnter)
		{
			e.Handled = false;
			m_IsInArea = true;
		}
		else if(e.Type == InputEventArgs::kMouseLeave)
		{
			e.Handled = false;
			m_IsInArea = false;
		}
		
		if(m_IsInArea && (e.LeftButtonDown || e.RightButtonDown))
		{
			if(!m_IsStartDrag)
			{
				m_DragLastPosition = gGame->input->GetCursorPosition();
				m_IsStartDrag = true;
			}
			SetCapture(true);
		}
		else if(!e.LeftButtonDown && !e.RightButtonDown)
		{
			m_IsStartDrag = false;
			SetCapture(false);
		}

		if(m_IsStartDrag && m_Parent)
		{
			F32 screenSizeX = gGame->screen->GetSize().x;
			F32 screenSizeY = gGame->screen->GetSize().y;

			if (gGame->config->GetUIVirtualSize() > 0)
			{
				screenSizeX = gGame->config->GetUIVirtualSize() * screenSizeX / screenSizeY;
				screenSizeY = gGame->config->GetUIVirtualSize();
			}

			Vector2 c = gGame->input->GetCursorPosition();
			Vector2 p = m_Parent->GetLocation();
			Vector2 temp = c - m_DragLastPosition;

			F32 screenSizeX1 = gGame->screen->GetSize().x;
			F32 screenSizeY1 = gGame->screen->GetSize().y;

			temp.x = temp.x * screenSizeX/screenSizeX1;
			temp.y = temp.y * screenSizeY/screenSizeY1;
			p = p + temp;
			m_Parent->SetLocation(p);
			if(m_Parent->GetLocation().x < m_Iimit.x)
			{
				p.x = m_Iimit.x;
				m_Parent->SetLocation(p);
			}
			if(m_Parent->GetLocation().y < m_Iimit.y)
			{
				p.y = m_Iimit.y;
				m_Parent->SetLocation(p);
			}
			if(m_Parent->GetLocation().x > m_Iimit.z)
			{
				p.x = m_Iimit.z;
				m_Parent->SetLocation(p);
			}
			if(m_Parent->GetLocation().y > m_Iimit.w)
			{
				p.y = m_Iimit.w;
				m_Parent->SetLocation(p);
			}
			m_DragLastPosition = c;
		}

		e.Handled = false;
		if (!e.Handled)
			Super::OnInputEvent(e);
	}

	void DragLabel::OnSizeChanged( ResizeEventArgs & e )
	{
		Super::OnSizeChanged(e);
		ReWrapText();
		EllipsisMyText();
	}

	void DragLabel::ReWrapText()
	{
		if(m_AutoWrap)
		{
			Core::Vector4 textPadding = GetTextPadding();
			Core::Rectangle rect(Vector2(textPadding.x, textPadding.y), GetSize() - Vector2(textPadding.z, textPadding.w));
			Control::SplitString(GetText(), m_MultiLineStr, rect, GetFont());	
		}
		DirtyLayout();
	}

	void DragLabel::CalcFontSize()
	{
		if(m_AutoFontSize && !m_AutoWrap && m_Size.x>20)
		{
			m_ResultFontSize = GetFontSize();
			Core::Rectangle tempRect = Core::Rectangle(0,0,0,0);
			Vector2 o = GetFont()->MeasureString(tempRect, m_Text, -1, Unit::kAlignCenterMiddle).GetExtent();
			while(o.x>=GetSize().x-GetTextPadding().x-GetTextPadding().z && m_ResultFontSize>=8)
			{
				m_ResultFontSize -= 2;
				tempRect = Core::Rectangle(0,0,0,0);
				o = GetAutoFont()->MeasureString(tempRect, m_Text, -1, Unit::kAlignCenterMiddle).GetExtent();
			}
		}
		Invalid();
	}

	tempc_ptr(Client::Font) DragLabel::GetAutoFont()
	{
		tempc_ptr(Client::Font) autoFont = NullPtr;
		if (gGame)
			autoFont = gRender->font_manager->GetFont(m_FontName, m_ResultFontSize, 0);

		return autoFont;
	}


	void DragLabel::EllipsisMyText()
	{
		if(GetAutoSize())
		{
			m_EllipsisStr = m_AutoWrap?m_MultiLineStr:m_Text;
			m_Hint = "";
			Invalid();
		}
		else
		{
			Core::Vector4 textPadding = GetTextPadding();
			Core::Rectangle rect(Vector2(textPadding.x, textPadding.y), GetSize() - Vector2(textPadding.z, textPadding.w));
			int ePos = Control::EllipsisString(m_AutoWrap?m_MultiLineStr:m_Text, m_EllipsisStr, rect.GetExtent(), GetFont());
			if(ePos>=0)
			{
				m_Hint = m_Text;
			}
			else
			{
				m_Hint = String::kEmpty;
			}
			Invalid();
		}
	}

	void DragLabel::Show()
	{
		SetVisible(true);

		m_Timer = Task::GetTotalTime();
	}

	void DragLabel::Close()
	{
		SetVisible(false);
		m_Timer = 0;
	}
}

