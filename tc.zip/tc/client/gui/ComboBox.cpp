#include "pch.h"

using namespace Core;
using namespace Client;
using namespace Gui;

//--------------------------------------------------------------------------------------
// type info
//--------------------------------------------------------------------------------------
DEFINE_PDE_TYPE_CLASS(Gui::ComboBoxSkin)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::ControlSkin);
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_PROPERTY_RW(ButtonNormalImage);
		ADD_PDE_PROPERTY_RW(ButtonHoverImage);	
		ADD_PDE_PROPERTY_RW(ButtonDownImage);	
		ADD_PDE_PROPERTY_RW(ButtonDisabledImage);	

		ADD_PDE_PROPERTY_RW(TextNormalImage);
		ADD_PDE_PROPERTY_RW(TextHoverImage);
		ADD_PDE_PROPERTY_RW(TextDownImage);
		ADD_PDE_PROPERTY_RW(TextDisabledImage);
	}
};

DEFINE_PDE_TYPE_ENUM(ComboBox::PopupDirection)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_ENUM_ITEM("kPoupBottom",		ComboBox::kPopupBottom);
		ADD_PDE_ENUM_ITEM("kPopupTop",			ComboBox::kPopupTop);
		ADD_PDE_ENUM_ITEM("kPopupRight",		ComboBox::kPopupRight);

		ADD_PDE_ENUM_CONSTRUCTOR();
	}
};

DEFINE_PDE_TYPE_CLASS(Gui::ComboBox)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::Control);

		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_PROPERTY_RW(Readonly);
		ADD_PDE_PROPERTY_RW(Popup);
		ADD_PDE_PROPERTY_RW(SelectedIndex);
		ADD_PDE_PROPERTY_RW(VScrollBarWidth);
		ADD_PDE_PROPERTY_RW(HScrollBarWidth);
		//ADD_PDE_PROPERTY_RW(VScrollBarButtonSize);
		//ADD_PDE_PROPERTY_RW(HScrollBarButtonSize);
		ADD_PDE_PROPERTY_RW(DropDownHeight);
		ADD_PDE_PROPERTY_RW(DropDownWidth);
		ADD_PDE_PROPERTY_R (ItemCount);
		ADD_PDE_PROPERTY_RW(ChildComboListStyle);
		ADD_PDE_PROPERTY_RW(TextAlign);
		ADD_PDE_PROPERTY_RW(LikeButton);
		ADD_PDE_PROPERTY_RW(PushDown);
		ADD_PDE_PROPERTY_RW(SelectedTextColor);
		ADD_PDE_PROPERTY_RW(HoverTextColor);
		ADD_PDE_PROPERTY_RW(MaxLength);
		ADD_PDE_PROPERTY_RW(TextPadding);
		ADD_PDE_PROPERTY_RW(WithIconOffset);
		
		ADD_PDE_METHOD(AddItem);
		ADD_PDE_METHOD(AddItemWithIcon);
		ADD_PDE_METHOD(SetItemDisable);
		ADD_PDE_METHOD(InsertItem);
		ADD_PDE_METHOD(RemoveItem);
		ADD_PDE_METHOD(RemoveAll);
		ADD_PDE_METHOD(MoveItem);
		ADD_PDE_METHOD(GetId);
		ADD_PDE_METHOD(SetId);
		ADD_PDE_METHOD(GetItem);
		ADD_PDE_METHOD(TextToIndex);
		ADD_PDE_METHOD(SelectNext);
		ADD_PDE_METHOD(SelectPrev);

		ADD_PDE_EVENT(EventValueChanged);
		ADD_PDE_EVENT(EventItemSelected);
		ADD_PDE_EVENT(EventClick);
		ADD_PDE_EVENT(EventLengthExceed);
	}
};

REGISTER_PDE_TYPE(Gui::ComboBoxSkin);
REGISTER_PDE_TYPE(ComboBox::PopupDirection);
REGISTER_PDE_TYPE(Gui::ComboBox);

namespace Gui
{
	static const F32 BORDER_WIDTH = 1;

	ComboBox::ComboBox()
		: m_Readonly(false)
		, m_Popup(kPopupBottom)
		, m_PushDown(false)
		, m_SelectedIndex(ComboList::INDEX_NONE)
		, m_MousePointed(false)
		, m_CursorVisible(false)
		, m_CursorTime(0)
		, m_ScrollX(0)
		//, m_VScrollBarButtonSize(25)
		, m_LikeButton(false)
		, m_MaxLength(0)
		, m_SelectedTextColor(Core::ARGB(255, 255, 255, 255))
		, m_HoverTextColor(Core::ARGB(255, 255, 255, 255))
		, m_TextPadding(Core::Vector4(2, 2, 2, 2))
		, m_WithIconOffset(Vector2::kZero)
	{
		SetTextBuffer(&m_Text);
	}

	ComboBox::~ComboBox()
	{
	}
}


//--------------------------------------------------------------------------------------
// Attribute
//--------------------------------------------------------------------------------------
namespace Gui
{
	PDE_ATTRIBUTE_GETTER(ComboBox, PushDown, bool)
	{
		return m_PushDown;
	}

	PDE_ATTRIBUTE_SETTER(ComboBox, PushDown, bool)
	{
		if (m_PushDown != value)
		{
			m_PushDown = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(ComboBox, LikeButton, bool)
	{
		return m_LikeButton;
	}

	PDE_ATTRIBUTE_SETTER(ComboBox, LikeButton, bool)
	{
		if (m_LikeButton != value)
			m_LikeButton = value;
	}

	PDE_ATTRIBUTE_GETTER(ComboBox, Opened, bool)
	{
		return m_ComboList->GetVisible();
	}

	PDE_ATTRIBUTE_GETTER(ComboBox, Popup, ComboBox::PopupDirection)
	{
		return m_Popup;
	}

	PDE_ATTRIBUTE_SETTER(ComboBox, Popup, ComboBox::PopupDirection)
	{
		if (value != m_Popup)
		{
			m_Popup = value;
		}
	}

	PDE_ATTRIBUTE_GETTER(ComboBox, Readonly, bool)
	{
		return m_Readonly;
	}


	PDE_ATTRIBUTE_SETTER(ComboBox, Readonly, bool)
	{
		if (m_Readonly != value)
		{
			m_Readonly = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(ComboBox, SelectedIndex, S32)
	{
		return m_SelectedIndex;
	}


	PDE_ATTRIBUTE_SETTER(ComboBox, SelectedIndex, S32)
	{
		if (m_SelectedIndex != value)
		{
			m_ComboList->SetSelectedIndex(value);
			m_ComboList->SetActiveIndex(value);
			m_SelectedIndex = m_ComboList->GetSelectedIndex();
			Super::SetText(GetItem());
			SetSelection(0, 0);

			OnValueChanged(EventArgs());
		}
	}

	PDE_ATTRIBUTE_GETTER(ComboBox, HScrollBarWidth, F32)
	{
		return m_ComboList->GetHScrollBarWidth();
	}


	PDE_ATTRIBUTE_SETTER(ComboBox, HScrollBarWidth, F32)
	{
		m_ComboList->SetHScrollBarWidth(value);
	}

	PDE_ATTRIBUTE_GETTER(ComboBox, VScrollBarWidth, F32)
	{
		return m_ComboList->GetVScrollBarWidth();
	}


	PDE_ATTRIBUTE_SETTER(ComboBox, VScrollBarWidth, F32)
	{
		m_ComboList->SetVScrollBarWidth(value);
	}

	/*PDE_ATTRIBUTE_GETTER(ComboBox, VScrollBarButtonSize, F32)
	{
		return m_ComboList->GetVScrollBarButtonSize();
	}


	PDE_ATTRIBUTE_SETTER(ComboBox, VScrollBarButtonSize, F32)
	{
		m_ComboList->SetVScrollBarButtonSize(value);
	}

	
	/*PDE_ATTRIBUTE_GETTER(ComboBox, HScrollBarButtonSize, F32)
	{
		return m_ComboList->GetHScrollBarButtonSize();
	}


	PDE_ATTRIBUTE_SETTER(ComboBox, HScrollBarButtonSize, F32)
	{
		m_ComboList->SetHScrollBarButtonSize(value);
	}*/

	PDE_ATTRIBUTE_GETTER(ComboBox, DropDownHeight, U32)
	{
		return m_ComboList->GetDropDownHeight();
	}


	PDE_ATTRIBUTE_SETTER(ComboBox, DropDownHeight, U32)
	{
		m_ComboList->SetDropDownHeight(value);
	}

	PDE_ATTRIBUTE_GETTER(ComboBox, DropDownWidth, U32)
	{
		return m_ComboList->GetDropDownWidth();
	}


	PDE_ATTRIBUTE_SETTER(ComboBox, DropDownWidth, U32)
	{
		m_ComboList->SetDropDownWidth(value);
	}

	PDE_ATTRIBUTE_GETTER(ComboBox, TextPadding, Vector4)
	{
		return m_TextPadding;
	}

	PDE_ATTRIBUTE_SETTER(ComboBox, TextPadding, Vector4)
	{
		if(m_TextPadding!=value)
		{
			m_TextPadding = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(ComboBox, TextAlign, Unit::Align)
	{
		return m_TextAlign;
	}

	PDE_ATTRIBUTE_SETTER(ComboBox, TextAlign, Unit::Align)
	{
		if(m_TextAlign!=value)
		{
			m_TextAlign = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(ComboBox, ItemCount, U32)
	{
		return m_ComboList->GetItemCount();
	}

	PDE_ATTRIBUTE_GETTER(ComboBox, Text, const String &)
	{
		return Super::GetText();
	}

	PDE_ATTRIBUTE_GETTER(ComboBox, Active, bool)
	{
		bool c = m_ComboList->GetActive();
		bool s = Super::GetActive();
		bool b = m_ComboList->GetActive()? false: Super::GetActive();
		return m_ComboList->GetFocused()? false: Super::GetActive();
	}

	PDE_ATTRIBUTE_GETTER(ComboBox, HoverTextColor, Core::ARGB)
	{
		return m_HoverTextColor;
	}

	PDE_ATTRIBUTE_SETTER(ComboBox, HoverTextColor, Core::ARGB)
	{
		if(m_HoverTextColor!=value)
		{
			m_HoverTextColor = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(ComboBox, MaxLength, U32)
	{
		return m_MaxLength;
	}


	PDE_ATTRIBUTE_SETTER(ComboBox, MaxLength, U32)
	{
		if (m_MaxLength != value)
		{
			m_MaxLength = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(ComboBox, WithIconOffset, Core::Vector2)
	{
		return m_WithIconOffset;
	}

	PDE_ATTRIBUTE_SETTER(ComboBox, WithIconOffset, Core::Vector2)
	{
		if(m_WithIconOffset!=value)
		{
			m_WithIconOffset = value;
			Invalid();
		}
	}


	PDE_ATTRIBUTE_GETTER(ComboBox, SelectedTextColor, Core::ARGB)
	{
		return m_SelectedTextColor;
	}

	PDE_ATTRIBUTE_SETTER(ComboBox, SelectedTextColor, Core::ARGB)
	{
		if(m_SelectedTextColor!=value)
		{
			m_SelectedTextColor = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_SETTER(ComboBox, BackgroundColor, ARGB)
	{
		if (GetBackgroundColor() != value)
		{
			Super::SetBackgroundColor(value);
			m_ComboList->SetBackgroundColor(value);
		}
	}

	PDE_ATTRIBUTE_SETTER(ComboBox, TextColor, ARGB)
	{
		if (GetTextColor() != value)
		{
			Super::SetTextColor(value);
			m_ComboList->SetTextColor(value);
		}
	}

	PDE_ATTRIBUTE_SETTER(ComboBox, Text, const String &)
	{
		S32 index = m_ComboList->TextToIndex(value);

		if (index != ComboList::INDEX_NONE)
		{
			SetSelectedIndex(index);
			Super::SetText(value);
		}
		else
		{
			Super::SetText(value);
			m_SelectedIndex = index;
			OnValueChanged(EventArgs());
		}
		OnTextChanged(Core::EventArgs());
	}

	PDE_ATTRIBUTE_GETTER(ComboBox, DisplayPadding, Vector4)
	{
		return Vector4(0, 0, GetClientRect().GetExtent().y, 0);
	}

	PDE_ATTRIBUTE_GETTER(ComboBox, ChildComboListStyle, const Core::String&)
	{
		return m_ComboList->GetStyle();
	}

	PDE_ATTRIBUTE_SETTER(ComboBox, ChildComboListStyle, const Core::String&)
	{
		m_ComboList->SetStyle(value);
	}
}


//--------------------------------------------------------------------------------------
// Event
//--------------------------------------------------------------------------------------
namespace Gui
{
	/// on create
	void ComboBox::OnCreate()
	{
		Super::OnCreate();
		m_ComboList = ptr_new ComboList;
		m_ComboList->EventListClick.Subscribe(NewDelegate(&Self::ComboList_OnListClick, ptr_static_cast<Self>(this)));
		m_ComboList->m_ComboBox = ptr_static_cast<Self>(this);
		m_ComboList->Close();
	}

	/// on paint client
	void ComboBox::OnPaint(PaintEventArgs & e)
	{
		Super::OnPaint(e);

		Core::Rectangle clientRect = GetClientRect();

		tempc_ptr(ComboBoxSkin) skin = ptr_dynamic_cast<ComboBoxSkin>(GetSkin());

		XRGB textColor = GetActive()? XRGB(255,255,255): GetTextColor();
		Core::Rectangle leftRect = GetDisplayRect();

		Core::Rectangle buttonRect(Vector2(clientRect.Max.x - clientRect.GetExtent().y,clientRect.Min.y), clientRect.Max);
		Core::Rectangle textScrollRect = leftRect;
		textScrollRect.Shrink(GetTextPadding());
		textScrollRect.Move(Vector2(-m_ScrollX, 0));

		// padding center
		Vector2 textLocation(textScrollRect.Min.x, 0);
		textLocation.y = Floor((textScrollRect.Max.y + textScrollRect.Min.y - GetFont()->GetLineHeight()) / 2);

		if(skin)
		{
			if(e.Enable)
			{

				if (m_PushDown)
				{
					Skin::DrawImage(e.render, skin->GetTextDownImage(), leftRect);
					Skin::DrawImage(e.render, skin->GetButtonDownImage(), buttonRect);
				}
				else if(m_MousePointed)
				{
					Skin::DrawImage(e.render, skin->GetTextHoverImage(), leftRect);
					Skin::DrawImage(e.render, skin->GetButtonHoverImage(), buttonRect);
				}
				else
				{
					Skin::DrawImage(e.render, skin->GetTextNormalImage(), leftRect);
					Skin::DrawImage(e.render, skin->GetButtonNormalImage(), buttonRect);
				}
			}
			else
			{
				Skin::DrawImage(e.render, skin->GetTextDisabledImage(), leftRect);
				Skin::DrawImage(e.render, skin->GetButtonDisabledImage(), buttonRect);
			}

			Core::Rectangle oldScissor = e.render->GetScissorRect();
			Core::Rectangle newScissor(GetDisplayRect());
			newScissor.Shrink(GetTextPadding());
			//When the dirty region is only part of this combobox, the result new scissor may be a degenerate rectangle
			if(!newScissor.IsEmpty())
			{
				e.render->AddScissorRectWithWorldMatrix(newScissor);
				ARGB textColor;
				if (e.Enable)
				{
					if (Core::ARGB(255, 255, 255, 255) != GetSelectedTextColor())
					{
						if (m_MousePointed)
						{
							textColor = GetHoverTextColor();
						}
						else if (m_PushDown)
						{
							textColor = GetSelectedTextColor();
						}
						else
						{
							textColor = GetTextColor();
						}						
					}
					else
					{
						textColor = GetTextColor();
					}
				}
				else
				{
					textColor = GetDisabledTextColor();
				}

				if(textColor.a)
				{
					if(m_Readonly)
					{
						if(m_LikeButton)
						{
							clientRect.Max = leftRect.Max;
							clientRect.Min.y = clientRect.Min.y + (m_TextPadding.y - m_TextPadding.w);
							clientRect.Min.x = clientRect.Min.x - (m_TextPadding.z - m_TextPadding.x);
						}
							
						e.render->DrawString(GetFont(), e.Enable?textColor:GetDisabledTextColor()
							, ARGB(0,0,0,0), clientRect.Shrink(GetTextPadding()), m_Text, m_TextAlign);
					}
					else
					{
						DrawInputText(e.render, textLocation, textScrollRect
							, e.Enable?GetTextColor():GetDisabledTextColor()
							, Core::XRGB(255,255,255), XRGB(49, 106, 197)
							, e.Enable?(GetReadonly()?false:m_CursorVisible):false, e.Enable?GetFocused():false
							, GetFont());
					}
				}
				e.render->SetScissorRect(oldScissor);
			}
		}
		else
		{
			if (e.Enable && !m_Readonly)
			{
				e.render->DrawRectangle(leftRect, Core::Rectangle(0, 0, 1, 1), XRGB(49,106,197));
			}
			else
			{
				e.render->DrawRectangle(leftRect, Core::Rectangle(0, 0, 1, 1), XRGB(212,208,200));
			}
			DrawInputText(e.render, leftRect.Min, leftRect, GetTextColor(), Core::XRGB(255,255,255), XRGB(49, 106, 197), true, true, GetFont());

			Core::Rectangle rect(Vector2(clientRect.Max.x - clientRect.GetExtent().y,clientRect.Min.y), clientRect.Max);
			e.render->DrawRectangle(rect,rect, XRGB(255,0,0));

			if (m_PushDown)
			{
				e.render->DrawRectangle( Core::Rectangle(rect).Move(Vector2::kOne), Core::Rectangle(rect).Move(Vector2::kOne),e.Enable? ARGB(0,255,255): ARGB(0,0,255));
			}
			else
			{
				e.render->DrawRectangle(rect,rect,e.Enable? ARGB(255,255,0): ARGB(0,255,0));
			}
		}
	}

	/// on input event
	void ComboBox::OnInputEvent(InputEventArgs & e)
	{
		if (e.IsMouseEvent())
		{	
			Vector2 localPos = ScreenToClient(e.CursorPosition);
			Core::Rectangle clientRect = GetClientRect();
			Core::Rectangle textRect(clientRect.Min, Vector2(clientRect.Max.x - clientRect.GetExtent().y, clientRect.Max.y));
			Core::Rectangle buttonRect = Core::Rectangle::RightBottom(clientRect.Max, Vector2(clientRect.GetExtent().y, clientRect.GetExtent().y));
			bool inButtonArea = m_Readonly? GetDisplayRect().IsPointInside(localPos): buttonRect.IsPointInside(localPos);
			bool inTextRect = m_Readonly? false: textRect.IsPointInside(localPos);

			if(inTextRect || GetSelecting())
			{
				switch (e.Type)
				{
				case InputEventArgs::kMouseEnter:
					m_MousePointed = true;
					Invalid();
					e.Handled = true;
					break;

				case InputEventArgs::kMouseLeave:
					m_MousePointed = false;
					Invalid();
					e.Handled = true;
					break;
				default:
					break;
				}
				if(!e.Handled)
				{
					// client pos
					Vector2 pos = localPos;
					// to text space
					pos.x = pos.x - GetTextPadding().x + m_ScrollX;
					pos.y = pos.y - GetTextPadding().y;

					if (OnMouseEvent(e, pos, GetFont()))
					{
						e.Handled = true;
						SetCapture(GetSelecting());
					}

					if (e.Type == InputEventArgs::kMouseMove && !(e.LeftButtonDown || e.MiddleButtonDown || e.RightButtonDown))
						e.Handled = true;
				}
			}
			else //in button area or outside combobox
			{
				switch (e.Type)
				{
				case InputEventArgs::kMouseEnter:
					m_MousePointed = true;
					Invalid();
					break;

				case InputEventArgs::kMouseLeave:
					m_MousePointed = false;
					Invalid();
					break;

				case InputEventArgs::kMouseDoubleClick:
				case InputEventArgs::kMouseDown:
					if (e.Code == MC_LEFT_BUTTON)
					{
						m_ComboList->SetSize(Vector2(GetSize().x, m_ComboList->GetSize().y));

						m_PushDown = true;
						if (m_ComboList->GetVisible())
						{
							m_PushDown = false;
							m_ComboList->Close();

						} 
						else
						{
							m_ComboList->Show();
							m_ComboList->SetFocused(true);
						}
						m_ComboList->SetSelectedIndex(GetSelectedIndex());

						Invalid();
					}

					e.Handled = true;
					EventClick.Fire(ptr_static_cast<ComboBox>(this), e);
					break;

				case InputEventArgs::kMouseUp:
					if (e.Code == MC_LEFT_BUTTON)
					{
						Invalid();

						e.Handled = true;
					}
					break;

				case InputEventArgs::kMouseWheel:
					if (GetActive())
					{
						e.Value > 0? SelectPrev(false): SelectNext(false);

						OnItemSelected(e);

						e.Handled = true;
					}
					break;

				default:
					break;
				}
			}
		}

		if (e.IsKeyEvent())
			OnKeyEvent(e);

		if (!e.Handled)
			Super::OnInputEvent(e);
	}

	/// on key event
	void ComboBox::OnKeyEvent(InputEventArgs & e)
	{
		// key down
		if (e.Type == InputEventArgs::kKeyDown && !(e.ShiftKeyDown || e.ControlKeyDown || e.AltKeyDown))
		{
			switch (e.Code)
			{
			case KC_UP:
				SelectPrev(false);
				e.Handled = true;
				break;

			case KC_DOWN:
				SelectNext(false);
				e.Handled = true;
				break;

			case KC_PGUP:
				SetSelectedIndex(0);
				e.Handled = true;
				break;

			case KC_PGDOWN:
				SetSelectedIndex(GetItemCount() - 1);
				e.Handled = true;
				break;

			default:
				break;
			}
		}
		if(!e.Handled && !GetReadonly())
		{
			if (e.Type == InputEventArgs::kChar)
			{
				if (e.Value == '\r' || e.Value == '\n')
				{
					OnValueEnter(Core::EventArgs());
					e.Handled = true;
					return;
				}
			}

			if (!e.Handled)
			{
				if (TextInput::OnKeyEvent(e, GetReadonly()))
				{
					e.Handled = true;
				}
			}
		}
	}

	void ComboBox::OnCursorMove(Core::EventArgs & e)
	{
		// update cursor
		m_CursorTime = Core::Task::GetTotalTime();

		// update scroll
		Vector2 cursorPos;
		F32 size = GetDisplayRect().GetExtent().x - GetTextPadding().x - GetTextPadding().z - 1;

		if (GetFont()->CPtoX(m_Text.Str(), GetCursorPosition(), cursorPos))
		{
			if (cursorPos.x < m_ScrollX)
			{
				m_ScrollX = cursorPos.x;
			}
			else if (cursorPos.x > m_ScrollX + size)
			{
				m_ScrollX = cursorPos.x - size;

				if (m_ScrollX < 0)
					m_ScrollX = 0;
			}

			if (GetFont()->CPtoX(m_Text.Str(), m_Text.Length(), cursorPos))
			{
				if (cursorPos.x < m_ScrollX + size)
					m_ScrollX = cursorPos.x - size;

				if (m_ScrollX < 0)
					m_ScrollX = 0;
			}
		}

		Vector2 caret_pos = ClientToScreen(Vector2(cursorPos.x - m_ScrollX, 0));

		// HACK : window
		sharedc_ptr(Window) window = ptr_dynamic_cast<Window>(GetRoot());
		if (window)
		{
			caret_pos += window->GetWorldLocation().xy;
		}

		ImeUi_SetCaretPosition(caret_pos.x, caret_pos.y);

		Invalid();
	}

	/// on frame update
	void ComboBox::OnFrameUpdate(EventArgs & e)
	{
		bool showCursor = false;

		if (GetFocused())
			showCursor = GetFocused() && ((static_cast<U32>((Core::Task::GetTotalTime() - m_CursorTime) * 2) & 1) == 0);

		if (m_CursorVisible != showCursor)
		{
			m_CursorVisible = showCursor;
			Invalid();
		}
	}

	/// on layout
	void ComboBox::OnLayout(EventArgs & e)
	{
		Super::OnLayout(e);

		Core::Rectangle clientRect(GetClientRect());

		Vector2 pos = GetLocation();
		Vector2 size = GetSize();

		m_ComboList->UpdateScreenPosition();	//If parent is a scrollable, combolist need to update its position
		m_ComboList->DirtyLayout();
	}

	/// on active changed
	void ComboBox::OnActiveChanged(EventArgs & e)
	{
		Invalid();
		Super::OnActiveChanged(e);
	}

	/// on text changed
	void ComboBox::OnTextChanged(Core::EventArgs & e)
	{
		if (m_MaxLength > 0)
		{
			if (m_Text.Length() > m_MaxLength)
			{
				CRefStr & str = m_Text.RefStr(0);
				str.setlen(m_MaxLength);
				str.validate();
				SetCursorPosition(GetCursorPosition());
				EventLengthExceed.Fire(ptr_static_cast<ComboBox>(this), Core::EventArgs());
			}
		}

		EventTextChanged.Fire(ptr_static_cast<ComboBox>(this), e);
		Invalid();
	}

	/// on value changed
	void ComboBox::OnValueChanged(EventArgs & e)
	{
		EventValueChanged.Fire(ptr_static_cast<ComboBox>(this), e);
	}

	/// on item selected
	void ComboBox::OnItemSelected(EventArgs & e)
	{
		EventItemSelected.Fire(ptr_static_cast<ComboBox>(this), e);
	}

	void ComboBox::ComboList_OnListClick(by_ptr(void), EventArgs & e)
	{
		SetText(m_ComboList->IndexToText());
		if(m_PushDown)
			m_PushDown = false;
		SetFocused(true);
		OnItemSelected(e);
	}

	/// on value enter
	void ComboBox::OnValueEnter(Core::EventArgs & e)
	{
		// item selected
		S32 sIndex = TextToIndex(GetText());
		if ( sIndex != ComboList::INDEX_NONE)
		{
			m_ComboList->SetSelectedIndex(sIndex);
			m_ComboList->SetActiveIndex(sIndex);
			OnItemSelected(e);
		}
		else
		{
			m_ComboList->SetSelectedIndex(0);
			m_ComboList->SetActiveIndex(0);
			SetText(m_ComboList->GetText());
			OnItemSelected(e);
		}
	}

	// on leave
	void ComboBox::OnLeave(EventArgs & e)
	{
		if(m_ComboList)
		{
			if(gGame->guiSys->GetFocusedControl() == m_ComboList)
				return;

			Super::OnLeave(e);
			if(m_ComboList->GetVisible())
			{
				m_PushDown = false;
				m_ComboList->Close();
			}
		}
	}

}

//--------------------------------------------------------------------------------------
// Method
//--------------------------------------------------------------------------------------
namespace Gui
{
	/// add item
	S32 ComboBox::AddItem(const String & item)
	{
		return m_ComboList->AddItem(item);
	}

	S32 ComboBox::AddItemWithIcon(const String & item,int index)
	{
		return m_ComboList->AddItem(item, true,index);
	}

	void ComboBox::SetItemDisable(S32 index, bool flag)
	{
		m_ComboList->SetItemDisable(index, flag);
	}

	/// insert item
	S32 ComboBox::InsertItem(S32 index, const String & item)
	{
		return m_ComboList->InsertItem(index, item);
	}

	/// remove item
	void ComboBox::RemoveItem(S32 index)
	{
		m_ComboList->RemoveItem(index);
		if (index == m_SelectedIndex)
		{
			m_SelectedIndex = ComboList::INDEX_NONE;
			Super::SetText(Core::String::kEmpty);
		}
	}

	/// remove all
	void ComboBox::RemoveAll()
	{
		m_SelectedIndex = ComboList::INDEX_NONE;
		if(m_ComboList)
		{
			m_ComboList->SetSelectedIndex(ComboList::INDEX_NONE);
			m_ComboList->SetActiveIndex(ComboList::INDEX_NONE);
		}

		for(S32 i = GetItemCount() - 1; i > -1; --i)
			RemoveItem(i);

		Super::SetText(Core::String::kEmpty);
	}

	/// move item
	void ComboBox::MoveItem(S32 index, S32 newIndex)
	{
		m_ComboList->MoveItem(index, newIndex);
	}

	/// get item
	const String & ComboBox::GetItem(S32 index)
	{
		if (index == ComboList::INDEX_NONE)
		{
			if (m_SelectedIndex != ComboList::INDEX_NONE)
				return m_ComboList->IndexToText(m_SelectedIndex);
			else
				return String::kEmpty;
		}

		return m_ComboList->IndexToText(index);
	}

	/// get id
	S32 ComboBox::GetId(S32 index)
	{
		return m_ComboList->GetId(index);
	}

	/// set id
	void ComboBox::SetId(S32 index, S32 id)
	{
		m_ComboList->SetId(index, id);
	}

	/// text to index
	S32 ComboBox::TextToIndex(const String & text)
	{
		return m_ComboList->TextToIndex(text);
	}

	/// select next
	void ComboBox::SelectNext(bool loop)
	{
		S32 index = GetSelectedIndex() + 1;
		S32 maxIndex = GetItemCount() - 1;

		index = index > maxIndex? loop? 0: maxIndex: index;

		SetSelectedIndex(index);
	}

	/// select previous
	void ComboBox::SelectPrev(bool loop)
	{
		S32 index = GetSelectedIndex() - 1;

		index = index < 0? loop? GetItemCount() - 1: 0: index;

		SetSelectedIndex(index);
	}

	void ComboBox::OnFocusChanged(EventArgs & e)
	{
		Control::OnFocusChanged(e);
		if (GetFocused())
		{
			ImeUi_EnableIme(true);
			SelectAll();
		}
		else
		{
			ImeUi_FinalizeString();
			ImeUi_EnableIme(false);
		}
	}
}




