namespace Gui
{
	class ShaderSkin : public ControlSkin
	{
	public:
		INLINE_PDE_ATTRIBUTE_RW(ResImage1,	tempc_ptr(Image)); 
		INLINE_PDE_ATTRIBUTE_RW(ResImage2,	tempc_ptr(Image)); 
		INLINE_PDE_ATTRIBUTE_RW(ResImage3,	tempc_ptr(Image)); 
	private:
		sharedc_ptr(Image)	m_ResImage1;
		sharedc_ptr(Image)	m_ResImage2;
		sharedc_ptr(Image)	m_ResImage3;
	};

	class ShaderControl: public Control
	{
		DECLARE_PDE_OBJECT(ShaderControl, Control);

	public:
		ShaderControl();
		~ShaderControl();

		void OnPaint(PaintEventArgs & e);

		DECLARE_PDE_ATTRIBUTE_RW(ShaderPS,				const Core::String &);
		DECLARE_PDE_ATTRIBUTE_RW(ShaderVS,				const Core::String &);

	private:
		void BlurEffect(PaintEventArgs & e);

	private:
		Core::String	m_ShaderVS;
		Core::String	m_ShaderPS;
	};
}