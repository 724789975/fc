#include "pch.h"

using namespace Core;
using namespace Client;
using namespace Gui;

DEFINE_PDE_TYPE_CLASS(ScrollNumberButton)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Control);

		ADD_PDE_PROPERTY_RW(BackGroundImage);
		ADD_PDE_PROPERTY_RW(NumberGroundImage);
		ADD_PDE_PROPERTY_RW(ItemName);
		ADD_PDE_PROPERTY_RW(ItemType);
		ADD_PDE_PROPERTY_RW(ScrollNumRange);
		ADD_PDE_PROPERTY_RW(Level);
		ADD_PDE_PROPERTY_RW(LevelRatio);
		ADD_PDE_PROPERTY_RW(ItemVSpace);
		ADD_PDE_PROPERTY_RW(ScrollTime);
		ADD_PDE_PROPERTY_RW(ItemSpace);
		ADD_PDE_PROPERTY_RW(ScrollTipNum);
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_METHOD(Reset);
		ADD_PDE_EVENT(OnComplete);
	}
};

REGISTER_PDE_TYPE(ScrollNumberButton);

namespace Gui
{
	
	PDE_ATTRIBUTE_GETTER(ScrollNumberButton,ScrollTipNum, int)
	{
		return m_ScrollTipNum;
	}
	PDE_ATTRIBUTE_SETTER(ScrollNumberButton, ScrollTipNum , int)
	{
		m_ScrollTipNum = value;
	}
	PDE_ATTRIBUTE_GETTER(ScrollNumberButton,ItemSpace, int)
	{
		return m_ItemSpace;
	}
	PDE_ATTRIBUTE_SETTER(ScrollNumberButton, ItemSpace , int)
	{
		m_ItemSpace = value;
	}
	PDE_ATTRIBUTE_GETTER(ScrollNumberButton,ScrollTime, float)
	{
		return m_all_scroll_time;
	}
	PDE_ATTRIBUTE_SETTER(ScrollNumberButton, ScrollTime , float)
	{
		m_all_scroll_time = value;
	}
	PDE_ATTRIBUTE_GETTER(ScrollNumberButton,ItemType, const Core::String &)
	{
		return m_ItemType;
	}
	PDE_ATTRIBUTE_SETTER(ScrollNumberButton, ItemType , const Core::String &)
	{
		m_ItemType = value;
	}
	PDE_ATTRIBUTE_GETTER(ScrollNumberButton,ScrollNumRange, const Core::String &)
	{
		return m_ItemNumberRange;
	}
	PDE_ATTRIBUTE_SETTER(ScrollNumberButton, ScrollNumRange , const Core::String &)
	{
		m_ItemNumberRange = value;
	}
	PDE_ATTRIBUTE_GETTER(ScrollNumberButton,Level, const Core::Vector2 &)
	{
		return m_Level;
	}
	PDE_ATTRIBUTE_SETTER(ScrollNumberButton, Level, const Core::Vector2 &)
	{
		m_Level = value;
	}
	PDE_ATTRIBUTE_GETTER(ScrollNumberButton,LevelRatio, const Core::Vector2 &)
	{
		return m_LevelRatio;
	}
	PDE_ATTRIBUTE_SETTER(ScrollNumberButton, LevelRatio, const Core::Vector2 &)
	{
		m_LevelRatio = value;
	}
	PDE_ATTRIBUTE_GETTER(ScrollNumberButton,ItemVSpace, const Core::String &)
	{
		return m_ItemVSpace;
	}
	PDE_ATTRIBUTE_SETTER(ScrollNumberButton, ItemVSpace , const Core::String &)
	{
		m_ItemVSpace = value;
	}
	PDE_ATTRIBUTE_GETTER(ScrollNumberButton, ItemName , const Core::String &)
	{
		return m_ItemName;
	}
	PDE_ATTRIBUTE_SETTER(ScrollNumberButton, ItemName , const Core::String &)
	{
		m_ItemName = value;
	}
	PDE_ATTRIBUTE_GETTER(ScrollNumberButton, BackGroundImage , tempc_ptr(Image))
	{
		return m_BackGroundImage;
	}
	PDE_ATTRIBUTE_SETTER(ScrollNumberButton, BackGroundImage , tempc_ptr(Image))
	{
		if (m_BackGroundImage != value)
		{
			m_BackGroundImage = value;
			Invalid();
		}
	}
	PDE_ATTRIBUTE_GETTER(ScrollNumberButton, NumberGroundImage , tempc_ptr(Image))
	{
		return m_NumberGroundImage;
	}
	PDE_ATTRIBUTE_SETTER(ScrollNumberButton, NumberGroundImage , tempc_ptr(Image))
	{
		if (m_NumberGroundImage != value)
		{
			m_NumberGroundImage = value;
			Invalid();
		}
	}
	ScrollNumberButton::ScrollNumberButton():
		m_BackGroundImage(NullPtr)
	{

		m_isRun = false;

		font_1 = gRender->font_manager->GetFont("simhei", 20, 0);
		font_2 = gRender->font_manager->GetFont("simhei", 13, 0);

		m_Number_Image[0] = RESOURCE_LOAD_NEW("InGameUI/lb_summary_number_l_1.dds", true, Texture2D);
		m_Number_Image[1] = RESOURCE_LOAD_NEW("InGameUI/lb_summary_number_l_2.dds", true, Texture2D);
		m_Number_Image[2] = RESOURCE_LOAD_NEW("InGameUI/lb_summary_number_r_1.dds", true, Texture2D);
		m_Number_Image[3] = RESOURCE_LOAD_NEW("InGameUI/lb_summary_number_r_2.dds", true, Texture2D);
		m_Number_Image[4] = RESOURCE_LOAD_NEW("InGameUI/lb_summary_number_r_3.dds", true, Texture2D);
		m_Number_Image[5] = RESOURCE_LOAD_NEW("InGameUI/lb_summary_number_r_4.dds", true, Texture2D);
		m_Number_Image[6] = RESOURCE_LOAD_NEW("InGameUI/lb_summary_number_6.dds", true, Texture2D);
		m_Number_Image[7] = RESOURCE_LOAD_NEW("InGameUI/lb_summary_number_7.dds", true, Texture2D);
		m_Number_Image[8] = RESOURCE_LOAD_NEW("InGameUI/lb_summary_number_5.dds", true, Texture2D);
		m_Number_Image[9] = RESOURCE_LOAD_NEW("InGameUI/lb_summary_shengji.dds", true, Texture2D);

		m_start_num = 0;
		m_end_num = 10000;

		m_ScrollTipNum = 0;
		m_all_scroll_time = 0;
		m_per_num = 4;
		m_per_time = 0.05f;

		m_per_time1 = m_per_time / m_per_num;
		m_scroll_time = 0.0f;
		m_scroll_time1 = 0.0f;
		m_scroll_ratio = 0;
		m_scroll_index = 0;

		m_up_pertime = 2.0f;
		m_up_time = 0.0f;
		m_up_ratio = 0.0f;

		m_movetext_flag = false;
		m_movetext_time = 0.0f;
		m_movetext_max_time = 0.5f;
		m_movetext_offset = 80;
		m_ItemSpace = 0;

	}
	ScrollNumberButton::~ScrollNumberButton()
	{

	}
	/// on auto size
	void ScrollNumberButton::Reset()
	{
		m_start_num = 0;
		m_end_num = 10000;


		//m_all_scroll_time = 0;
		//m_per_num = 4;
		m_per_time = 0.05f;

		m_per_time1 = m_per_time / m_per_num;
		m_scroll_time = 0.0f;
		m_scroll_time1 = 0.0f;
		m_scroll_ratio = 0;
		m_scroll_index = 0;

		m_up_pertime = 2.0f;
		m_up_time = 0.0f;
		m_up_ratio = 0.0f;

		m_movetext_flag = false;
		m_movetext_time = 0.0f;
		m_movetext_max_time = 0.5f;
		m_movetext_offset = 80;

		m_NumRange.Clear();
		m_ItemList.Clear();

		m_isRun = false;
	}
	void ScrollNumberButton::OnAutoSize(AutoSizeEventArgs & e)
	{
	}

	void ScrollNumberButton::PaintBackground( PaintEventArgs & e )
	{
		Core::Rectangle &client_size = GetClientRect();

		if(m_BackGroundImage)
		{
			e.render->SetTexture(m_BackGroundImage->GetTexture());
			e.render->DrawWindow(client_size,Core::Rectangle(40,40,40,40),Core::Rectangle(40 / 128.0f,40/128.0f,40/128.0f,40/128.0f));
		}
		/////get item name
		if(m_ItemList.Size() == 0)
		{
			Core::Array<Core::String> name;
			Core::Array<float> vspace;
			Core::Array<Core::String> type;
			Core::Array<Core::String> scroll_range;

			int index = 0;
			CStrBuf<256> str;

			/////////name
			char *str_p = (char *)m_ItemName.RefStr().buff();
			int len = m_ItemName.Length();
			char *str_end_p = str_p + len;

			while(str_p != str_end_p)
			{
				index = 0;
				str.clear();
				while(*str_p != '#' && *str_p != '\0')
				{
					str.insert(index,*str_p);
					str_p++;
					index++;
				}

				if(str_p != str_end_p)
					str_p++;
				
				name.PushBack(str);
			}
			/////////NumRange
			str_p = (char *)m_ItemNumberRange.RefStr().buff();
			len = m_ItemNumberRange.Length();
			str_end_p = str_p + len;

			while(str_p != str_end_p)
			{
				index = 0;
				str.clear();
				while(*str_p != '@' && *str_p != '\0')
				{
					str.insert(index,*str_p);
					str_p++;
					index++;
				}

				if(str_p != str_end_p)
					str_p++;

				scroll_range.PushBack(str);
			}

			int max_num = 0;

			for(int i = 0 ; i < (int)scroll_range.Size();i++)
			{
				str_p = (char *)scroll_range[i].Str();
				len = scroll_range[i].Length();
				str_end_p = str_p + len;

				float data[2];
				int data_num = 0;

				while(str_p != str_end_p)
				{
					index = 0;
					str.clear();
					while(*str_p != ',' && *str_p != '\0')
					{
						str.insert(index,*str_p);
						str_p++;
						index++;
					}

					if(str_p != str_end_p)
						str_p++;

					data_num++;
					data[data_num - 1] = atoi(str);

					if(data_num == 2)
					{
						if(max_num < data[1])
							max_num = data[1];

						m_NumRange.PushBack(Vector2(data[0],data[1]));
						data_num = 0;
					}
				}
			}
			
			m_per_num = m_per_time / m_all_scroll_time * max_num;
			if(m_per_num < 1)
				m_per_num = 4;
			m_per_time1 = m_per_time / m_per_num;

			/////////type
			str_p = (char *)m_ItemType.RefStr().buff();
			len = m_ItemType.Length();
			str_end_p = str_p + len;

			while(str_p != str_end_p)
			{
				index = 0;
				str.clear();
				while(*str_p != '#' && *str_p != '\0')
				{
					str.insert(index,*str_p);
					str_p++;
					index++;
				}

				if(str_p != str_end_p)
					str_p++;

				type.PushBack(str);
			}
			////////VSpace
			str_p = (char *)m_ItemVSpace.RefStr().buff();
			len = m_ItemVSpace.Length();
			str_end_p = str_p + len;

			while(str_p != str_end_p)
			{
				index = 0;
				str.clear();
				while(*str_p != ',' && *str_p != '\0')
				{
					str.insert(index,*str_p);
					str_p++;
					index++;
				}

				if(str_p != str_end_p)
					str_p++;

				vspace.PushBack(atoi(str));
			}

			for(int i = 0 ; i < (int)type.Size();i++)
			{
				ItemInfo item;

				item.type = type[i];;
				item.name = name[i];

				if( i + 1 != (int)type.Size() )
					item.vspace = vspace[i];

				m_ItemList.PushBack(item);
			}
		}
		
		Core::Rectangle draw_rect = client_size;

		int top_index = 80;

		int height;
		
		if(m_ItemSpace!=0)
			top_index = m_ItemSpace;
		//draw number
		
		CStrBuf<256> num_str,num_str1,num_width_str;
		int num_len,num_width_len;
		int level_num = 0;
		int range_num = 0;

		for(int i = 0 ; i < (int)m_ItemList.Size() ; i++)
		{
			ItemInfo &item = m_ItemList[i];

			if(item.type == "numstyle1" || item.type == "numstyle2" || item.type == "numstyle3")
			{
				height = 50;

				if (m_NumRange.Size() <= (uint)range_num)
				{
					continue;
				}

				int num = (int)m_NumRange[range_num].x;

				num_str.format("%d",num);

				num_width_str.format("%d",(int)m_NumRange[range_num].y);

				if(m_NumRange[range_num].x != m_NumRange[range_num].y)
				{
					num_str1.format("%d",num + m_per_num);
				}
				else
				{
					num_str1.format("%d",num);
				}

				range_num++;

				num_len = num_str.len();
				num_width_len = num_width_str.len();

				if(item.type != "numstyle3")
				{
					e.render->SetTexture(m_NumberGroundImage->GetTexture());
					e.render->DrawWindow(Core::Rectangle(draw_rect.Min.x + 50,top_index,draw_rect.Max.x - 50,top_index + height),Core::Rectangle(10,10,10,10),Core::Rectangle(10 / 28.f,10 / 48.f,10/28.f,10/48.f));
					Core::Rectangle font_size;

					e.render->DrawString(font_1,Core::ARGB(255,218,182,69),Core::ARGB(0,0,0,0),Core::Rectangle(draw_rect.Min.x + 50 + 5,top_index - 10 ,0,top_index + height - 2 - 10),item.name.Str(),Unit::kAlignLeftBottom);

					CStrBuf<256> value_name = gLang->GetTextW(L"");

					if(item.type == "numstyle1")
						value_name = "";
					e.render->DrawString(font_1,Core::ARGB(255,218,182,69),Core::ARGB(0,0,0,0),Core::Rectangle(0,top_index - 10,draw_rect.Max.x - 50 - 5,top_index + height - 2 - 10),value_name,Unit::kAlignRightBottom);
				}

				int text_x, text_y;

				tempc_ptr(Texture2D) tex_style1,tex_style2;

				if(item.type == "numstyle1" || item.type == "numstyle2")
				{
					tex_style1 = m_Number_Image[0];
					tex_style2 = m_Number_Image[1];
				}
				else if(item.type == "numstyle3")
				{
					tex_style1 = m_Number_Image[2];
					tex_style2 = m_Number_Image[3];
				}
				else if(item.type == "numstyle4")
				{
					tex_style1 = m_Number_Image[4];
					tex_style2 = m_Number_Image[5];
				}

				if(item.type == "numstyle3")
					text_x = draw_rect.Max.x - tex_style1->GetWidth() / 10, text_y = top_index;
				else
					text_x = draw_rect.Max.x - 130, text_y = top_index + height / 2.0f - 22;


				for(int i = 0 ; i < num_width_len; i++)
				{
					int offset,offset1;

					if( i < num_len )
					{
						offset = num_str[num_len - 1 - i] - '0';
					   offset1 = num_str1[num_len - 1 - i] - '0';
					}
					else
					{
						offset = 0;
						offset1 = 0;
					}

					float ratio = 1.0f;

					int ccx1 = tex_style1->GetWidth() / 10, ccy1 = tex_style1->GetHeight();
					int ccx2 = tex_style2->GetWidth() / 10, ccy2 = tex_style2->GetHeight();

					if(offset != offset1)
					{
						if(m_scroll_index == 0)
						{
							e.render->SetTexture(tex_style1);
							e.render->DrawRectangle(Core::Rectangle(text_x,text_y,text_x + ccx1,text_y + ccy1),Core::Rectangle(offset * 0.1f,0,offset * 0.1f + 0.1f,1));
						}
						if(m_scroll_index == 1)
						{
							e.render->SetTexture(tex_style1);
							e.render->DrawRectangle(Core::Rectangle(text_x,text_y + ccy1 / 2,text_x + ccx1,text_y + ccy1),Core::Rectangle(offset * 0.1f,0.5f,offset * 0.1f + 0.1f,1));

							e.render->SetTexture(tex_style2);
							e.render->DrawRectangle(Core::Rectangle(text_x,text_y,text_x + ccx2,text_y + ccy2 / 2),Core::Rectangle(offset * 0.1f,0,offset * 0.1f + 0.1f,0.5f));
						}
						if(m_scroll_index == 2)
						{
							e.render->SetTexture(tex_style2);
							e.render->DrawRectangle(Core::Rectangle(text_x,text_y + ccy2 / 2,text_x + ccx2,text_y + ccy2),Core::Rectangle(offset * 0.1f,0.5f,offset * 0.1f + 0.1f,1));

							e.render->SetTexture(tex_style1);
							e.render->DrawRectangle(Core::Rectangle(text_x,text_y,text_x + ccx1,text_y + ccy1 / 2),Core::Rectangle(offset1 * 0.1f,0,offset1 * 0.1f + 0.1f,0.5f));
						}
						if(m_scroll_index == 3)
						{
							e.render->SetTexture(tex_style1);
							e.render->DrawRectangle(Core::Rectangle(text_x,text_y,text_x + ccx1,text_y + ccy1),Core::Rectangle(offset * 0.1f,0,offset * 0.1f + 0.1f,1));
						}
					}
					else
					{
						e.render->SetTexture(tex_style1);
						e.render->DrawRectangle(Core::Rectangle(text_x,text_y,text_x + ccx1,text_y + ccy1),Core::Rectangle(offset * 0.1f,0,offset * 0.1f + 0.1f,1));
					}

					text_x -= ccx1 + 3;
				}
			}
			if(item.type == "levelstyle")
			{ 
				num_str.format("%d",(int)m_Level.x);
				num_len = num_str.len();

				int cx,cy;

				int tex_cx = m_Number_Image[7]->GetWidth() / 10.0f , tex_cy = m_Number_Image[7]->GetHeight();

				cx = draw_rect.Min.x + draw_rect.Max.x / 2.0f;
				cy = top_index + tex_cy;

				height = tex_cy;

				int text_x = num_len * tex_cx - (num_len - 1) * 30;

				cx += text_x / 2;


				for(int i = 0 ; i < num_len; i++)
				{
					int offset = num_str[num_len - 1 - i] - '0';

					e.render->SetTexture(m_Number_Image[6]);
					e.render->DrawRectangle(Core::Rectangle(cx - tex_cx,cy - tex_cy / 2,cx,cy + tex_cy / 2),Core::Rectangle(offset * 0.1f,0,offset * 0.1f + 0.1f,1.0f));

					e.render->SetTexture(m_Number_Image[7]);
					e.render->DrawRectangle(Core::Rectangle(cx - tex_cx,cy - tex_cy / 2 + (1.0f - m_up_ratio) * tex_cy,cx,cy + tex_cy / 2),Core::Rectangle(offset * 0.1f,(1.0f - m_up_ratio),offset * 0.1f + 0.1f,1.0f));

					cx -= tex_cx - 30;
				}

				if(m_movetext_flag == 1)
				{
					float ratio = m_movetext_time / m_movetext_max_time;
					if(ratio > 1.0f)
						ratio = 1.0f;

					tex_cx = m_Number_Image[9]->GetWidth() / 8 / 2, tex_cy = m_Number_Image[9]->GetHeight();

					cx = draw_rect.Min.x + draw_rect.Max.x / 2.0f;
				
					int tex_id = (int)(ratio * 7);

					e.render->SetTexture(m_Number_Image[9]);
					e.render->DrawRectangle(Core::Rectangle(cx - tex_cx,cy - tex_cy / 2 - m_movetext_offset * ratio,cx + tex_cx,cy + tex_cy / 2 - m_movetext_offset * ratio),Core::Rectangle(tex_id * 0.125f,0,tex_id * 0.125f + 0.125f,1.0f));
				}
				if(m_movetext_flag == 2)
				{
					int offset;

					float ratio = m_movetext_time / m_movetext_max_time;
					if(ratio > 1.0f)
						ratio = 1.0f;


					num_str.format("+%d",m_ScrollTipNum);
					num_len = num_str.len();


					tex_cx = m_Number_Image[8]->GetWidth() / 8, tex_cy = m_Number_Image[8]->GetHeight() / 11;

					cx = draw_rect.Min.x + draw_rect.Max.x / 2.0f;

					int text_x = num_len * tex_cx;

					cx += text_x / 2;

					
					int tex_id = (int)(ratio * 7);

					for(int i = 0 ; i < num_len; i++)
					{
						if(num_str[num_len - 1 - i] == '+')
							offset = 10;
						else
							offset = num_str[num_len - 1 - i] - '0';
						
						//offset = 1;
						e.render->SetTexture(m_Number_Image[8]);
						e.render->DrawRectangle(Core::Rectangle(cx - tex_cx,cy - tex_cy / 2 - m_movetext_offset * ratio,cx,cy + tex_cy / 2 - m_movetext_offset * ratio),Core::Rectangle(tex_id * 0.125f,offset * (1 / 11.f),tex_id * 0.125f + 0.125f,offset * (1 / 11.f) + 1 / 11.f));

						cx -= tex_cx;
					}
				}
			}

			if(i + 1 != (int)m_ItemList.Size())
				top_index += height + item.vspace;
		}

	}
	// frame update
	void ScrollNumberButton::OnFrameUpdate(Core::EventArgs & e)
	{
		float time = Core::Task::GetFrameTime();

		bool flag = false;

		m_scroll_time += time;
		m_scroll_time1 += time;

		m_scroll_ratio = m_scroll_time / m_per_time;

		if(m_scroll_ratio >= 1.0f)
		{
			m_scroll_ratio = 1.0f;
			m_scroll_index = 3;
			m_scroll_time1 = 0;
		}
		else
		{
			if(m_scroll_time1 > m_per_time1)
			{
				m_scroll_time1 = 0;
				m_scroll_index++;
				if(m_scroll_index > 3)
					m_scroll_index = 0;
			}
		}

		int start_num;
		int end_num;

		for(int i = 0 ; i < (int)m_NumRange.Size();i++)
		{
			start_num = (int)(m_NumRange[i].x);
			end_num = (int)(m_NumRange[i].y);

			if(start_num != end_num)
				flag = true;

			if(m_scroll_time >= m_per_time && start_num < end_num)
			{
				if( i + 1 == (int)m_NumRange.Size())
				{
					m_scroll_time = 0;
					m_scroll_ratio = 0;
				}
				start_num += m_per_num;
			}

			if(start_num > end_num)
				m_NumRange[i].x = m_NumRange[i].y;
			else
				m_NumRange[i].x = start_num;
		}


		if( fabs(m_Level.x - m_Level.y) > Core::EPSILON || fabs(m_up_ratio - m_LevelRatio.y) > Core::EPSILON )
		{
			m_LevelRatio.x += time;
			m_up_ratio = m_LevelRatio.x / m_up_pertime;

			flag = true;

			if(m_LevelRatio.x > m_up_pertime || (fabs(m_Level.x - m_Level.y) <= Core::EPSILON && m_up_ratio >= m_LevelRatio.y))
			{
				if((fabs(m_Level.x - m_Level.y) <= Core::EPSILON && m_up_ratio >= m_LevelRatio.y))
				{
					m_up_ratio = m_LevelRatio.y;
					m_movetext_flag = 2;
					m_movetext_time = 0.0f;
				}
				else
				{
					m_Level.x++;

					m_movetext_flag = 1;
					m_up_ratio = 1.0f;
					m_LevelRatio.x = 0;
				}
			}
		}

		if(m_movetext_flag >= 1)
		{
			flag = true;

			m_movetext_time += time;
			if(m_movetext_time >=m_movetext_max_time)
			{
				m_movetext_time = 0.0f;

				if(m_movetext_flag == 1)
					m_movetext_flag = 0;
				else if(m_movetext_flag == 2)
					m_movetext_flag = 0;
			}
		}

		if(!flag && m_isRun == false)
		{
			OnComplete.Fire(ptr_static_cast<ScrollNumberButton>(this),Core::EventArgs());
			m_isRun = true;
		}
	}
	void ScrollNumberButton::OnPaint(PaintEventArgs & e)
	{
		PaintBackground(e);
	}

	void ScrollNumberButton::OnInputEvent(InputEventArgs & e)
	{
		//if(m_IsStatic)
		//{
		//	return;
		//}

		//if (e.IsMouseEvent())
		//{

		//	Core::Vector2 localPos = ScreenToClient(e.CursorPosition);
		//	bool prevMousePointed = m_MousePointed;
		//	bool prevMouseDown = m_MouseHoldDown;

		//	m_MousePointed = GetBackgroundRect().IsPointInside(localPos);

		//	switch (e.Type)
		//	{
		//	case InputEventArgs::kMouseDown:
		//	case InputEventArgs::kMouseDoubleClick:
		//		{
		//			if(e.Code == MC_LEFT_BUTTON && m_MousePointed)
		//			{
		//				Invalid();
		//				SetCapture(true);
		//				m_MousePointed = true;
		//				m_MouseHoldDown = true;
		//				e.Handled = true;
		//			}
		//		}
		//		break;

		//	case InputEventArgs::kMouseUp:
		//		{
		//			if(e.Code == MC_LEFT_BUTTON && m_MouseHoldDown)
		//			{					
		//				Invalid();
		//				m_MouseHoldDown = false;

		//				SetCapture(false);

		//				if(m_MousePointed)
		//				{
		//					Click();
		//				}

		//				e.Handled = true;
		//			}
		//		}
		//		break;

		//	case InputEventArgs::kMouseMove:
		//		{
		//			e.Handled = true;
		//		}
		//		break;

		//	case InputEventArgs::kMouseEnter:
		//		{
		//			m_MousePointed = true;
		//			e.Handled = true;
		//		}
		//		break;
		//	case InputEventArgs::kMouseLeave:
		//		{
		//			m_MousePointed = false;
		//			e.Handled = true;
		//		}
		//		break;
		//	}

		//	if (prevMouseDown != m_MouseHoldDown || prevMousePointed != m_MousePointed)
		//	{
		//		Invalid();
		//	}
		//}

		////if(e.IsKeyEvent())
		////	OnKeyEvent(e);

		//if (!e.Handled)
		//	Control::OnInputEvent(e);

	}

	void ScrollNumberButton::OnClick(Client::InputEventArgs &e)
	{
		//EventClick.Fire(ptr_static_cast<Self>(this), e);
	}
}