namespace Gui
{
	class TextAreaSkin : public ScrollableControlSkin
	{
	public:
		TextAreaSkin()
		{}

	public:


	private:


	};

}
namespace Gui
{

	class TextArea: public ScrollableControl, public TextInput
	{
	public:
		TextArea();
		~TextArea();

	public:
		DECLARE_PDE_EVENT(EventTextChanged,			Core::EventArgs);
		DECLARE_PDE_EVENT(EventLengthExceed, Core::EventArgs);

	public:
		DECLARE_PDE_OBJECT(TextArea, ScrollableControl);
		DECLARE_PDE_ATTRIBUTE_RW(MaxLength,			U32);
		DECLARE_PDE_ATTRIBUTE_RW(Count_n,			int);
		DECLARE_PDE_ATTRIBUTE_RW(Readonly,			bool);
		DECLARE_PDE_ATTRIBUTE_RW(TextPadding,		Core::Vector4);
		//DECLARE_PDE_ATTRIBUTE_R (Hotkey,			EdtUIHotkeyManager *);
		DECLARE_PDE_ATTRIBUTE_RW(Fold,				bool);
		OVERRIDE_PDE_ATTRIBUTE_RW(Text,				const Core::String &);
		DECLARE_PDE_ATTRIBUTE_RW(AllowEnter,		bool);
		OVERRIDE_PDE_ATTRIBUTE_W(TabFocus,			Core::Bool);

		DECLARE_PDE_ATTRIBUTE_RW(SelectionColor,		Core::ARGB);
		DECLARE_PDE_ATTRIBUTE_RW(SelectionBgColor,			Core::ARGB);

		
// 		//Scrollbar display should not be disabled
// 		OVERRIDE_PDE_ATTRIBUTE_W(HScrollBarDisplay,		ScrollableControl::ScrollbarDisplay);
// 		OVERRIDE_PDE_ATTRIBUTE_W(VScrollBarDisplay,		ScrollableControl::ScrollbarDisplay);

	public:
		/// on create
		virtual void OnCreate();

		/// on frame update
		virtual void OnFrameUpdate(Core::EventArgs & e);

		/// on paint
		virtual void OnPaint(Gui::PaintEventArgs & e);

        /// on input event
		virtual void OnInputEvent(Client::InputEventArgs & e);

		/// on leave
		virtual void OnLeave(Core::EventArgs & e);

		/// on text changed
		virtual void OnTextChanged(Core::EventArgs & e);

		// on size changed
		virtual void OnSizeChanged(ResizeEventArgs & e);

		/// on cursor move
		virtual void OnCursorMove(Core::EventArgs & e);

		/// on font changed
		virtual void OnFontChanged(Core::EventArgs & e);

		/// on new history
		virtual void OnHistoryReset(InputHistory & e);

		/// on focus changed
		virtual void OnFocusChanged(EventArgs & e);

		/// delete virtual enter
		virtual void DeleteVirtualEnter();

		/// add virtual enter
		virtual void AddVirtualEnter();

		const Core::String& GetRealText();

		virtual void AddText(Core::String & string);

		virtual void ScrollToEnd();

	private:
		void UpdateText();

	private:
        F64				m_CursorTime;        
		U32				m_MaxLength;
		int				m_Count_n;
		//PdeDirtyFlag	m_FontDirty;
		Core::Vector4	m_TextPadding;

		Core::ARGB		m_SelectionColor;
		Core::ARGB		m_SelectionBgColor;

		bool			m_CursorVisible	: 1;
		bool			m_Readonly		: 1;
		bool			m_Fold			: 1;		

		Core::Array<size_t>	m_VirtualEnterPos;

// 		EdtUIHotkeyManager m_Hotkey;
		sharedc_ptr(CommandQueue) m_CommandQueue;

		Core::String		m_RealText;
	};
}