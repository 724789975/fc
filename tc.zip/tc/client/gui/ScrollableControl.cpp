#include "pch.h"

using namespace Core;
using namespace Client;
using namespace Gui;


//--------------------------------------------------------------------------------------
// type info
//--------------------------------------------------------------------------------------

DEFINE_PDE_TYPE_CLASS(Gui::ScrollableControlSkin)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::ControlSkin);
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_PROPERTY_RW(ActiveBgImage);

		ADD_PDE_PROPERTY_RW(UpButtonNormalImage	);
		ADD_PDE_PROPERTY_RW(UpButtonHoverImage	);
		ADD_PDE_PROPERTY_RW(UpButtonDownImage	);
		ADD_PDE_PROPERTY_RW(UpButtonDisabledImage);

		ADD_PDE_PROPERTY_RW(DownButtonNormalImage	);
		ADD_PDE_PROPERTY_RW(DownButtonHoverImage	);
		ADD_PDE_PROPERTY_RW(DownButtonDownImage	);
		ADD_PDE_PROPERTY_RW(DownButtonDisabledImage);

		ADD_PDE_PROPERTY_RW(LeftButtonNormalImage	);
		ADD_PDE_PROPERTY_RW(LeftButtonHoverImage	);
		ADD_PDE_PROPERTY_RW(LeftButtonDownImage	);
		ADD_PDE_PROPERTY_RW(LeftButtonDisabledImage);

		ADD_PDE_PROPERTY_RW(RightButtonNormalImage	);
		ADD_PDE_PROPERTY_RW(RightButtonHoverImage	);
		ADD_PDE_PROPERTY_RW(RightButtonDownImage	);
		ADD_PDE_PROPERTY_RW(RightButtonDisabledImage);

		ADD_PDE_PROPERTY_RW(VSliderNormalImage	);
		ADD_PDE_PROPERTY_RW(VSliderHoverImage	);
		ADD_PDE_PROPERTY_RW(VSliderDownImage		);
		ADD_PDE_PROPERTY_RW(VSliderDisabledImage	);

		ADD_PDE_PROPERTY_RW(HSliderNormalImage	);
		ADD_PDE_PROPERTY_RW(HSliderHoverImage	);
		ADD_PDE_PROPERTY_RW(HSliderDownImage		);
		ADD_PDE_PROPERTY_RW(HSliderDisabledImage	);

		ADD_PDE_PROPERTY_RW(VBarBackgroundImage				);
		ADD_PDE_PROPERTY_RW(VBarDisabledBackgroundImage		);
		
		ADD_PDE_PROPERTY_RW(HBarBackgroundImage		);

		ADD_PDE_PROPERTY_RW(BarCornerImage			);
	}
};


DEFINE_PDE_TYPE_ENUM(ScrollableControl::ScrollbarDisplay)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_ENUM_ITEM("kAuto",			ScrollableControl::kAuto);
		ADD_PDE_ENUM_ITEM("kVisible",		ScrollableControl::kVisible);
		ADD_PDE_ENUM_ITEM("kHide",			ScrollableControl::kHide);

		ADD_PDE_ENUM_CONSTRUCTOR();
	}
};

DEFINE_PDE_TYPE_CLASS(ScrollableControl)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Control);
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_PROPERTY_RW(AutoScroll);
		ADD_PDE_PROPERTY_RW(HScrollBarMove);
		ADD_PDE_PROPERTY_RW(AutoScrollPosition);
		ADD_PDE_PROPERTY_RW(AutoScrollMinSize);

		ADD_PDE_PROPERTY_RW(Border);

		ADD_PDE_PROPERTY_RW(HScrollBarDisplay);
		ADD_PDE_PROPERTY_RW(VScrollBarDisplay);
		
		ADD_PDE_PROPERTY_RW(VScrollBarHeight);
		ADD_PDE_PROPERTY_RW(HScrollBarWidth);
		ADD_PDE_PROPERTY_RW(VScrollBarWidth);
		ADD_PDE_PROPERTY_RW(HScrollBarButtonSize);
		ADD_PDE_PROPERTY_RW(VScrollBarButtonSize);
		ADD_PDE_PROPERTY_RW(Default_Size);
		ADD_PDE_PROPERTY_RW(Default_Width);
		ADD_PDE_PROPERTY_RW(VScrollBarPos);
		ADD_PDE_PROPERTY_R (VscrollBarValue);

		ADD_PDE_METHOD(ScrollToView);
	}
};

REGISTER_PDE_TYPE(ScrollableControlSkin);
REGISTER_PDE_TYPE(ScrollableControl);
REGISTER_PDE_TYPE(ScrollableControl::ScrollbarDisplay);

namespace Gui
{
	ScrollableControl::ScrollableControl()
		: m_AutoScroll(false)
		, m_AutoScrollMinSize(0, 0)
		, m_ClientSize(Vector2::kZero)
		, m_VScrollBarPos(Vector2::kZero)
		, m_Default_Size(25)
		, m_Default_Width(25)
		, m_MiddleMouseDrag(false)
		, m_HScrollBarMove(false)
		, m_HScrollBarDisplay(kAuto)
		, m_VScrollBarDisplay(kAuto)
		, m_VScrollBarHeight(0)
		, m_Border(0,0,0,0)
		, m_VscrollBarValue(0.0f)
		, m_VScrollBarWith(0.f)
	{
	}

	ScrollableControl::~ScrollableControl()
	{
	}
}


//--------------------------------------------------------------------------------------
// Attribute
//--------------------------------------------------------------------------------------
namespace Gui	
{
	PDE_ATTRIBUTE_GETTER(ScrollableControl, AutoScroll, bool)
	{
		return m_AutoScroll;
	}


	PDE_ATTRIBUTE_SETTER(ScrollableControl, AutoScroll, bool)
	{
		if (m_AutoScroll != value)
		{
			m_AutoScroll = value;
			Invalid();

			if (m_AutoScroll)
			{
				m_HScrollBar = ptr_new ScrollBar;
				m_VScrollBar = ptr_new ScrollBar;

				m_HScrollBar->SetHorizontal(true);
				m_VScrollBar->SetHorizontal(false);
				m_VScrollBar->SetWidth(m_Default_Width);
				m_HScrollBar->SetWidth(20);
				m_HScrollBar->SetButtonSize(25); //Default size
				m_VScrollBar->SetButtonSize(m_Default_Size); //Default size

				m_HScrollBar->EventValueChanged.Subscribe(NewDelegate(&ScrollableControl::ScrollBar_OnValueChanged, ptr_static_cast<ScrollableControl>(this)));
				m_VScrollBar->EventValueChanged.Subscribe(NewDelegate(&ScrollableControl::ScrollBar_OnValueChanged, ptr_static_cast<ScrollableControl>(this)));

				m_HScrollBar->SetSmallChange(10);
				m_VScrollBar->SetSmallChange(10);

				m_HScrollBar->SetVisible(false);
				m_VScrollBar->SetVisible(false);
			}
			else
			{
				m_HScrollBar = NullPtr;
				m_VScrollBar = NullPtr;

				SetAutoScrollPosition(Vector2::kZero);
			}
		}

		DirtyLayout();
	}

	PDE_ATTRIBUTE_GETTER(ScrollableControl, HScrollBarMove, bool)
	{
		return m_HScrollBarMove;
	}


	PDE_ATTRIBUTE_SETTER(ScrollableControl, HScrollBarMove, bool)
	{
		if (m_HScrollBarMove != value)
		{
			m_HScrollBarMove = value;
		}
	}

	PDE_ATTRIBUTE_GETTER(ScrollableControl, VScrollBarHeight, F32)
	{
		return m_VScrollBarHeight;
	}


	PDE_ATTRIBUTE_SETTER(ScrollableControl, VScrollBarHeight, F32)
	{
		if (m_VScrollBarHeight != value)
		{
			m_VScrollBarHeight = value;
			Invalid();
			DirtyLayout(true);
		}
	}

	PDE_ATTRIBUTE_GETTER(ScrollableControl, AutoScrollPosition, const Vector2 &)
	{
		return m_Scroll;
	}


	PDE_ATTRIBUTE_SETTER(ScrollableControl, AutoScrollPosition, const Vector2 &)
	{
		if (m_Scroll != value)
		{
			m_Scroll = value;
			if (GetAutoScroll())
			{
				m_HScrollBar->SetValue(value.x);
				m_VScrollBar->SetValue(value.y);
			}
			Invalid();
			DirtyLayout(true);
		}
	}

	PDE_ATTRIBUTE_GETTER(ScrollableControl, AutoScrollMinSize, const Vector2 &)
	{
		return m_AutoScrollMinSize;
	}


	PDE_ATTRIBUTE_SETTER(ScrollableControl, AutoScrollMinSize, const Vector2 &)
	{
		if (m_AutoScrollMinSize != value)
		{
			m_AutoScrollMinSize = value;
			DirtyLayout();
		}
	}

	PDE_ATTRIBUTE_GETTER(ScrollableControl, HScrollBarDisplay, ScrollableControl::ScrollbarDisplay)
	{
		return m_HScrollBarDisplay;
	}

	PDE_ATTRIBUTE_SETTER(ScrollableControl, HScrollBarDisplay, ScrollableControl::ScrollbarDisplay)
	{
		if (m_HScrollBarDisplay != value)
		{
			m_HScrollBarDisplay = value;
			DirtyLayout();
			Invalid();
		}
	}


	PDE_ATTRIBUTE_GETTER(ScrollableControl, VScrollBarDisplay, ScrollableControl::ScrollbarDisplay)
	{
		return m_VScrollBarDisplay;
	}

	PDE_ATTRIBUTE_SETTER(ScrollableControl, VScrollBarDisplay, ScrollableControl::ScrollbarDisplay)
	{
		if (m_VScrollBarDisplay != value)
		{
			m_VScrollBarDisplay = value;
			DirtyLayout();
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(ScrollableControl, VScrollBarWidth, F32)
	{
		return m_VScrollBarWith;
	}

	PDE_ATTRIBUTE_SETTER(ScrollableControl, VScrollBarWidth, F32)
	{
		if (m_VScrollBarWith != value)
		{
			m_VScrollBarWith = value;
			if(m_VScrollBar)
				m_VScrollBar->SetWidth(value);
			DirtyLayout();
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(ScrollableControl, VScrollBarPos, Core::Vector2)
	{
		return m_VScrollBarPos;
	}

	PDE_ATTRIBUTE_SETTER(ScrollableControl, VScrollBarPos, Core::Vector2)
	{
		if (m_VScrollBarPos != value)
		{
			m_VScrollBarPos = value;
		}
	}
	
	PDE_ATTRIBUTE_GETTER(ScrollableControl, VscrollBarValue, F32)
	{
		return m_VscrollBarValue;
	}

	PDE_ATTRIBUTE_GETTER(ScrollableControl, Default_Size, F32)
	{
		return m_Default_Size;
	}

	PDE_ATTRIBUTE_SETTER(ScrollableControl, Default_Size,F32)
	{
		if (m_Default_Size != value)
		{
			m_Default_Size = value;
		}
	}

	PDE_ATTRIBUTE_GETTER(ScrollableControl, Default_Width, F32)
	{
		return m_Default_Width;
	}

	PDE_ATTRIBUTE_SETTER(ScrollableControl, Default_Width,F32)
	{
		if (m_Default_Width != value)
		{
			m_Default_Width = value;
		}
	}

	PDE_ATTRIBUTE_GETTER(ScrollableControl, HScrollBarWidth, F32)
	{
		return m_HScrollBarWith;
	}

	PDE_ATTRIBUTE_SETTER(ScrollableControl, HScrollBarWidth, F32)
	{
		if (m_HScrollBarWith != value)
		{
			m_HScrollBarWith = value;
			if(m_HScrollBar)
				m_HScrollBar->SetWidth(value);
			DirtyLayout();
			Invalid();
		}
	}
	
	PDE_ATTRIBUTE_GETTER(ScrollableControl, HScrollBarButtonSize, F32)
	{
		return m_HScrollBar->GetButtonSize();
	}

	PDE_ATTRIBUTE_SETTER(ScrollableControl, HScrollBarButtonSize, F32)
	{
		if (m_HScrollButtonSize != value)
		{
			m_HScrollButtonSize = value;
			if(m_HScrollBar)
				m_HScrollBar->SetButtonSize(value);
			InvalidHScrollBar();
		}
	}

	PDE_ATTRIBUTE_GETTER(ScrollableControl, VScrollBarButtonSize, F32)
	{
		return m_VScrollBar->GetButtonSize();
	}

	PDE_ATTRIBUTE_SETTER(ScrollableControl, VScrollBarButtonSize, F32)
	{
		if (m_VScrollButtonSize != value)
		{
			m_VScrollButtonSize = value;
			if(m_VScrollBar)
				m_VScrollBar->SetButtonSize(value);
			InvalidVScrollBar();
		}
	}


	PDE_ATTRIBUTE_GETTER(ScrollableControl, ClientRect, Core::Rectangle)
	{
		return Core::Rectangle::LeftTop(Vector2::kZero, m_AutoScrollMinSize);
	}

	PDE_ATTRIBUTE_GETTER(ScrollableControl, Border, Core::Vector4)
	{
		return m_Border;
	}

	PDE_ATTRIBUTE_SETTER(ScrollableControl, Border, Core::Vector4)
	{
		if(m_Border!=value)
		{
			m_Border = value;
			UpdateLayout();
		}
	}


	PDE_ATTRIBUTE_GETTER(ScrollableControl, DisplayPadding, Vector4)
	{
		Vector4 dispPadding = Super::GetDisplayPadding();
		dispPadding += GetBorder();
		if( (GetAutoScroll()||GetVScrollBarDisplay()!=kHide) && m_VScrollBar)
		{
			dispPadding += Vector4(0, 0, m_VScrollBar->GetVisible()? m_VScrollBar->GetSize().x: 0, 0);
		}
		if( (GetAutoScroll()||GetHScrollBarDisplay()!=kHide) && m_HScrollBar)
		{
			dispPadding += Vector4(0, 0, 0, m_HScrollBar->GetVisible()? m_HScrollBar->GetSize().y: 0);
		}

		return dispPadding;
	}
}


//--------------------------------------------------------------------------------------
// Event
//--------------------------------------------------------------------------------------
namespace Gui
{
	void ScrollableControl::OnPaint(PaintEventArgs & e)
	{
		Control::OnPaint(e);
		
		tempc_ptr(ScrollableControlSkin) skin = ptr_dynamic_cast<ScrollableControlSkin>(GetSkin());
		if (GetFocused() && skin)
		{
			Skin::DrawImage(e.render, skin->GetActiveBgImage(), GetBackgroundRect(), m_BackgroundColor);
		}

		if (GetAutoScroll())
		{
			ScrollBar *hs = m_HScrollBar;
			ScrollBar *vs = m_VScrollBar;

			if (skin)
			{
				if (hs->GetVisible() && vs->GetVisible())
				{
					Core::Rectangle rect;
					rect.Min = Vector2(vs->GetLocation().x, hs->GetLocation().y);
					rect.Max = rect.Min + Vector2(vs->GetSize().x, hs->GetSize().y);

					Skin::DrawImage(e.render, skin->GetBarCornerImage(), rect);
				}

				RenderEventArgs args(e);

				if (hs->GetVisible())
				{
					hs->OnPaint(args, skin);
				}

				if (vs->GetVisible())
				{
					vs->OnPaint(args, skin);
				}
			}
			else
			{
				if (hs->GetVisible() && vs->GetVisible())
				{
					Core::Rectangle rect;
					rect.Min = Vector2(vs->GetLocation().x, hs->GetLocation().y);
					rect.Max = rect.Min + Vector2(vs->GetSize().x, hs->GetSize().y);

					e.render->SetTexture(NullPtr);
					e.render->DrawRectangle(rect, rect, XRGB(197,197,197));
				}

				RenderEventArgs args(e);

				if (hs->GetVisible())
				{
					hs->OnPaint(args, NullPtr);
				}

				if (vs->GetVisible())
				{
					vs->OnPaint(args, NullPtr);
				}
			}
		}
	}

	/// on autosize
	void ScrollableControl::OnAutoSize(AutoSizeEventArgs & e)
	{
		if (GetAutoScroll())
		{
			for (tempc_ptr(Control) control = GetFirstChild(); control; control = control->GetNext())
			{
				if (control->GetVisible())
				{
					const Vector2& ctrlLocation = control->GetLocation();
					const Vector2& ctrlSize = control->GetSize();
					const Vector4& ctrlMargin = control->GetMargin();

					switch(control->GetDock())
					{
					case kDockNone:
						e.clientRect.UnionWith(Core::Rectangle(ctrlLocation-Vector2(ctrlMargin.x, ctrlMargin.y), ctrlLocation+ctrlSize+Vector2(ctrlMargin.z, ctrlMargin.w)));
						break;

					case kDockLeft:
						e.dockRect.Min.x -= ctrlSize.x + ctrlMargin.x + ctrlMargin.z;
						break;

					case kDockRight:
						e.dockRect.Max.x += ctrlSize.x + ctrlMargin.x + ctrlMargin.z;
						break;

					case kDockTop:
						e.dockRect.Min.y -= ctrlSize.y + ctrlMargin.y + ctrlMargin.w;
						break;

					case kDockBottom:
						e.dockRect.Max.y += ctrlSize.y + ctrlMargin.y + ctrlMargin.w;
						break;
					}
				}
			}

			SetAutoScrollMinSize(e.GetSize());
		}
		else
		{
			Control::OnAutoSize(e);
		}
	}

	void ScrollableControl::OnLayout(EventArgs & e)
	{
		Vector2 size = GetSize();

		if (GetAutoScroll())
		{
			
			if(m_VScrollBarDisplay&&m_VScrollBarHeight!=0)
			{
				m_VScrollBar->SetSize(Vector2(m_VScrollBar->GetWidth(),m_VScrollBarHeight));
			}

			Vector2 minimum = GetAutoScrollMinSize();
			Vector2 scrollSize(m_VScrollBar->GetSize().x, m_HScrollBar->GetSize().y);

			ScrollBar *hs = m_HScrollBar;
			ScrollBar *vs = m_VScrollBar;

			// initialize size
			bool hs_can_visible = m_HScrollBarDisplay != kHide && size.x >= hs->GetMinimumSize().x && size.y >= hs->GetMinimumSize().y;
			bool vs_can_visible = m_VScrollBarDisplay != kHide && size.x >= vs->GetMinimumSize().x && size.y >= vs->GetMinimumSize().x;
			bool hs_visible = m_HScrollBarDisplay == kVisible;
			bool vs_visible = m_VScrollBarDisplay == kVisible;

			// force both scrollbar visible
			if (m_HScrollBarDisplay == kAuto && m_VScrollBarDisplay == kAuto && (
				(minimum.x > size.x && size.y < minimum.y + scrollSize.y) ||
				(minimum.y > size.y && size.x < minimum.x + scrollSize.x)))
			{
				hs_visible = hs_can_visible;
				vs_visible = vs_can_visible;
			}
			else
			{
				// show hscrollbar
				if (!hs_visible && hs_can_visible)
				{
					hs_visible = minimum.x > size.x - (m_VScrollBarDisplay == kVisible ? scrollSize.x : 0);
				}
				// show vscrollbar
				if (!vs_visible && vs_can_visible)
				{
					vs_visible = minimum.y > size.y - (m_HScrollBarDisplay == kVisible ? scrollSize.y : 0);
				}
			}

			bool oldVbarVisible = vs->GetVisible();
			if(oldVbarVisible!=vs_visible)
			{
				vs->SetVisible(vs_visible);
				ResizeEventArgs args;
				args.OldSize = GetSize();
				args.NewSize = GetSize();
				OnSizeChanged(args);
			}
			bool oldHbarVisible = hs->GetVisible();
			if(oldHbarVisible!=hs_visible)
			{
				hs->SetVisible(hs_visible);
				ResizeEventArgs args;
				args.OldSize = GetSize();
				args.NewSize = GetSize();
				OnSizeChanged(args);
			}

			// padding change with scroll visible change 
			size = GetSize();

			m_ClientSize.x = Max(minimum.x, size.x);
			m_ClientSize.y = Max(minimum.y, size.y);

			// set scrollbar's attributes
			Core::Rectangle toalScrollRect = GetClientRect().Shrink(GetBorder());
			Core::Rectangle rect = GetDisplayRect();
			Vector2 displaySize = rect.GetExtent();
			
			vs->SetMinimum(0);
			vs->SetMaximum(Max(toalScrollRect.GetExtent().y - displaySize.y, 0.f));
			vs->SetLargeChange(displaySize.y);

			hs->SetMinimum(0);
			hs->SetMaximum(Max(toalScrollRect.GetExtent().x - displaySize.x , 0.f));
			hs->SetLargeChange(displaySize.x);

			//scrollbar location and size depend on display rect which depends on scrollbar min/max/value ...
			rect = GetDisplayRect();
			displaySize = rect.GetExtent();

			vs->SetLocation(Vector2(rect.Max.x, rect.Min.y));
			vs->SetSize(Vector2(scrollSize.x, displaySize.y));
			if (m_VScrollBarHeight > 0)
				vs->SetSize(Vector2(scrollSize.x, m_VScrollBarHeight));

			hs->SetLocation(Vector2(rect.Min.x, rect.Max.y));
			hs->SetSize(Vector2(displaySize.x, scrollSize.y));

			// reset auto scroll position
			Vector2 scroll = GetAutoScrollPosition();
			scroll.x = Clamp(scroll.x, hs->GetMinimum(), hs->GetMaximum());
			scroll.y = Clamp(scroll.y, vs->GetMinimum(), vs->GetMaximum());

			SetAutoScrollPosition(scroll);

			if(m_VScrollBarPos != Vector2::kZero)
			{
				Core::Vector2 VsLocation = m_VScrollBar->GetLocation();
				VsLocation = VsLocation + m_VScrollBarPos;
				m_VScrollBar->SetLocation(VsLocation);
			}
		}
		else
		{
			m_ClientSize = size;
		}

		Control::OnLayout(e);
	}


	/// on input event
	void ScrollableControl::OnInputEvent(InputEventArgs & e)
	{
		static Vector2 dragOffset;

		// send mouse wheel to v scrollbar
		if (GetAutoScroll())
		{
			if (m_HScrollBar)
				m_HScrollBar->OnInputEvent(ptr_static_cast<Control>(this), e);

			if (e.Handled)
				return;

			if (m_VScrollBar)
			{
				m_VScrollBar->OnInputEvent(ptr_static_cast<Control>(this), e);
			}
			if (e.Handled)
				return;

			switch (e.Type)
			{
			case InputEventArgs::kMouseWheel:
				{
					F32 value = m_VScrollBar->GetValue() - m_VScrollBar->GetSmallChange() * e.Value;

					// clamp value
					value = Clamp(value, m_VScrollBar->GetMinimum(), m_VScrollBar->GetMaximum());

					m_VScrollBar->SetValue(value);
					
					e.Handled = true;
				}
				break;

			case InputEventArgs::kMouseDown:
				if (e.Code == MC_MIDDLE_BUTTON)
				{
					dragOffset = e.CursorPosition + GetAutoScrollPosition();
					m_MiddleMouseDrag = true;
					SetCapture(true);
					e.Handled = true;
					SetCursorShape(Screen::kCursorHand);
				}
				break;

			case InputEventArgs::kMouseMove:
				if (m_MiddleMouseDrag)
				{
					ScrollBar *hs = m_HScrollBar;
					ScrollBar *vs = m_VScrollBar;

					Vector2 scroll = dragOffset - e.CursorPosition;
					
					if (m_HScrollBarMove)
					{
						scroll.x = Clamp(scroll.x, hs->GetMinimum(), hs->GetMaximum());
					}
					else
					{
						scroll.x = hs->GetMinimum();
					}
					scroll.y = Clamp(scroll.y, vs->GetMinimum(), vs->GetMaximum());

					SetAutoScrollPosition(scroll);
					SetCursorShape(Screen::kCursorHand);
					e.Handled = true;
				}
				break;

			case InputEventArgs::kMouseUp:
				if (m_MiddleMouseDrag && e.Code == MC_MIDDLE_BUTTON)
				{
					SetCapture(false);
					m_MiddleMouseDrag = false;
					e.Handled = true;
				}
				break;
			}

		}
		if (m_VScrollBar)
			m_VscrollBarValue = m_VScrollBar->GetValue();

		if (!e.Handled)
			Control::OnInputEvent(e);
	}


	void ScrollableControl::OnFrameUpdate(EventArgs & e)
	{
		if (m_HScrollBar)
			m_HScrollBar->OnFrameUpdate(e);

		if (m_VScrollBar)
			m_VScrollBar->OnFrameUpdate(e);

		Control::OnFrameUpdate(e);
	}


	void ScrollableControl::ScrollBar_OnValueChanged(by_ptr(void) sender, EventArgs & e)
	{
		m_Scroll.x = m_HScrollBar->GetValue();
		m_Scroll.y = m_VScrollBar->GetValue();
		//Update scrollbar location after scroll bar value changed
		ScrollBar *hs = m_HScrollBar;
		ScrollBar *vs = m_VScrollBar;
		Core::Rectangle displayRect = GetDisplayRect();
		if(vs && vs->GetVisible())
			vs->SetLocation(Vector2(displayRect.Max.x, displayRect.Min.y));
		if(hs && hs->GetVisible())
			hs->SetLocation(Vector2(displayRect.Min.x, displayRect.Max.y));
		Invalid();
		DirtyLayout(true);
	}
}

//--------------------------------------------------------------------------------------
// Method
//--------------------------------------------------------------------------------------
namespace Gui
{
	/// scroll to view
	void ScrollableControl::ScrollToView(const Core::Rectangle & rect)
	{
		Core::Rectangle displayRect = GetDisplayRect();

		Vector2 pos = GetAutoScrollPosition();

		if (rect.Max.x > displayRect.Max.x)		pos.x = rect.Max.x - displayRect.Max.x + displayRect.Min.x;
		if (rect.Max.y > displayRect.Max.y)		pos.y = rect.Max.y - displayRect.Max.y + displayRect.Min.y;
		if (rect.Min.x < displayRect.Min.x)		pos.x = rect.Min.x;
		if (rect.Min.y < displayRect.Min.y)		pos.y = rect.Min.y;

		SetAutoScrollPosition(pos);
	}


	void ScrollableControl::InvalidVScrollBar( void )
	{
		InvalidRect(Core::Rectangle::LeftTop(m_VScrollBar->GetLocation(), m_VScrollBar->GetSize()));
	}

	void ScrollableControl::InvalidHScrollBar( void )
	{
		InvalidRect(Core::Rectangle::LeftTop(m_HScrollBar->GetLocation(), m_HScrollBar->GetSize()));
	}
}
