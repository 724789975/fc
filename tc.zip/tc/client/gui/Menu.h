namespace Gui
{
	class Menu : public Control
	{
		struct MenuItem 
		{	
			Core::String					Text;
			bool							IsSeparator;
			bool							Enable;
			bool							Check;
			bool							CanCheck;
			bool							Radio;
			tempc_ptr(Menu)					SubMenu;
			Core::Rectangle					ItemRect;
			Core::Rectangle					IconRect;
			Core::Rectangle					TextRect;
			Core::Rectangle					SubMenuRect;

			MenuItem()
				: Text(Core::String::kEmpty)
				, IsSeparator(false)
				, Enable(true)
				, Check(false)
				, CanCheck(false)
				, Radio(false)
			{

			}
		};

	public:
		DECLARE_PDE_EVENT(EventClick,				InputEventArgs);
		DECLARE_PDE_EVENT(EventOpen,				EventArgs);
		DECLARE_PDE_EVENT(EventClose,				EventArgs);
		DECLARE_PDE_ATTRIBUTE_RW(ItemWidth,			U32);
		DECLARE_PDE_ATTRIBUTE_RW(ItemHeight,		U32);
		DECLARE_PDE_ATTRIBUTE_RW(ItemText_LeftSpace,		U32);
		DECLARE_PDE_ATTRIBUTE_RW(TextAlign,			Client::Unit::Align);
		DECLARE_PDE_ATTRIBUTE_RW(SeparatorHeight,	U32);
		DECLARE_PDE_ATTRIBUTE_RW(Border,			Core::Vector4);
		DECLARE_PDE_ATTRIBUTE_R(SelectedIndex,		S32);
		DECLARE_PDE_ATTRIBUTE_R(ItemCount,			U32);
		DECLARE_PDE_ATTRIBUTE_RW(Owner,				tempc_ptr(Menu));
		DECLARE_PDE_ATTRIBUTE_RW(OpenedSubMenu,		tempc_ptr(Menu));

	public:
		Menu(void);

		virtual ~Menu(void);

		void OnPaint(PaintEventArgs & e);

		void OnInputEvent(InputEventArgs & e);

		void OnMouseEnter(InputEventArgs & e);

		void OnLeave(EventArgs & e);

		void OnClick(InputEventArgs & e);

	public:
		void ResetSize();

		void AddItem(const Core::String & text);

		void AddSeparator();

		void RemoveAll();

		Menu::MenuItem GetItem(U32 index);

		void SetSubMenu(U32 index,tempc_ptr(Menu) subMenu);

		bool GetEnable(U32 index);

		void SetEnable(U32 index, bool enable);

		bool GetCanCheck(U32 index);

		void SetCanCheck(U32 index, bool value);

		bool GetCheck(U32 index);

		void SetCheck(U32 index, bool value);

		void SetRadio(U32 index);

		void Open();

		void Close();

	private:
		tempc_ptr(Menu) GetRootMenu();

		bool LeaveAllMenu();

	private:
		U32							m_ItemWidth;
		U32							m_ItemHeight;
		U32							m_ItemText_LeftSpace;
		Client::Unit::Align			m_TextAlign;
		U32							m_SeparatorHeight;
		Core::Vector4				m_Border;

		S32							m_SelectedIndex;
		U32							m_ItemCount;
		Core::Array<MenuItem>		m_aItem;
		sharedc_ptr(Menu)			m_Owner;
		sharedc_ptr(Menu)			m_OpenedSubMenu;
	};
}

namespace Gui
{
	class MenuSkin : public ControlSkin
	{
	public:
		INLINE_PDE_ATTRIBUTE_RW(ItemHoverImage,		tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(ItemRadioImage,		tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(ItemCheckedImage,	tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(ItemUncheckImage,	tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(ItemHasSubMenuImage,tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(SeparatorImage,		tempc_ptr(Image));

	private:
		sharedc_ptr(Image)			m_ItemHoverImage;
		sharedc_ptr(Image)			m_ItemRadioImage;
		sharedc_ptr(Image)			m_ItemCheckedImage;
		sharedc_ptr(Image)			m_ItemUncheckImage;
		sharedc_ptr(Image)			m_ItemHasSubMenuImage;
		sharedc_ptr(Image)			m_SeparatorImage;
	};
}
