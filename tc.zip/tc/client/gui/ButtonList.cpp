#include "pch.h"

DEFINE_PDE_TYPE_CLASS(Gui::ButtonList)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::Control);
		ADD_PDE_DEFAULT_CONSTRUCTOR();
		ADD_PDE_METHOD(AddButton);
		ADD_PDE_METHOD(AddButtonWithLogo);
		ADD_PDE_METHOD(ClearList);
		ADD_PDE_PROPERTY_RW(MaxCount);
		ADD_PDE_PROPERTY_RW(Space);
		ADD_PDE_PROPERTY_RW(Yoffset);
		ADD_PDE_PROPERTY_RW(ButtonSize);
		ADD_PDE_PROPERTY_RW(ArrowSize);
		ADD_PDE_PROPERTY_RW(LeftArrowSkin);
		ADD_PDE_PROPERTY_RW(RightArrowSkin);
	}
};

REGISTER_PDE_TYPE(Gui::ButtonList);

using namespace Core;

namespace Gui
{
	ButtonList::ButtonList():
				m_MaxCount(0)
			   ,m_Yoffset(0)
			   ,m_pos(0)
			   ,m_Space(5)
			   ,m_LeftButton(NullPtr)
			   ,m_RightButton(NullPtr)
			   ,m_ButtonSize(Vector2::kZero)
			   ,m_LeftArrowSkin(NullPtr)
			   ,m_RightArrowSkin(NullPtr)
	{

	}

	ButtonList::~ButtonList()
	{
		m_ButtonList.Clear();
	}
	
	PDE_ATTRIBUTE_GETTER(ButtonList,LeftArrowSkin,tempc_ptr(ButtonSkin))
	{
		return m_LeftArrowSkin;
	}

	PDE_ATTRIBUTE_SETTER(ButtonList,LeftArrowSkin,tempc_ptr(ButtonSkin))
	{
		if(m_LeftButton)
		{
			m_LeftButton->SetSkin(value);
		}
	}

	PDE_ATTRIBUTE_GETTER(ButtonList,RightArrowSkin,tempc_ptr(ButtonSkin))
	{
		return m_RightArrowSkin;
	}

	PDE_ATTRIBUTE_SETTER(ButtonList,RightArrowSkin,tempc_ptr(ButtonSkin))
	{
		if(m_RightButton)
		{
			m_RightButton->SetSkin(value);
		}
	}

	void ButtonList::OnClick(Client::InputEventArgs & e)
	{

	}

	void ButtonList::OnCreate()
	{
		Super::OnCreate();

		m_ButtonList.Clear();
		m_LeftButton = ptr_new Button;
		m_RightButton = ptr_new Button;

		m_LeftButton->SetParent(ptr_static_cast<ButtonList>(this));
		m_RightButton->SetParent(ptr_static_cast<ButtonList>(this));

		m_LeftButton->EventClick.Subscribe(NewDelegate(&ButtonList::MoveLeft,ptr_static_cast<ButtonList>(this)));
		m_RightButton->EventClick.Subscribe(NewDelegate(&ButtonList::MoveRight,ptr_static_cast<ButtonList>(this)));
	}

	void ButtonList::AddButton(const by_ptr(Button) button)
	{
		if(button)
		{
			button->SetParent(ptr_static_cast<ButtonList>(this));
			
			sharedc_ptr(Button_List_Data) data = ptr_new Button_List_Data;

			data->button = button;

			m_ButtonList.PushBack(data);
		}
	}
	
	void ButtonList::AddButtonWithLogo(const by_ptr(Button) button, const by_ptr(Control) c, const Vector2 offset)
	{
		if(button)
		{
			button->SetParent(ptr_static_cast<ButtonList>(this));
			if(m_Parent)
			{
				c->SetParent(ptr_static_cast<ButtonList>(m_Parent));
			}
			else
			{
				c->SetParent(ptr_static_cast<ButtonList>(this));
			}

			sharedc_ptr(Button_List_Data) data = ptr_new Button_List_Data;

			data->button = button;
			data->control = c;
			data->offset = offset;

			m_ButtonList.PushBack(data);
		}
	}

	void ButtonList::ClearList()
	{
		m_ButtonList.Clear();
	}

	void ButtonList::OnFrameUpdate(EventArgs & e)
	{
		Control::OnFrameUpdate(e);
		
		m_LeftButton->SetEnable(true);
		m_RightButton->SetEnable(true);

		if(m_pos <= 0)
		{
			m_LeftButton->SetEnable(false);
		}
		
		uint buttonSize = m_ButtonList.Size();
		uint maxleft = buttonSize - m_MaxCount;

		if(m_pos >= maxleft)
		{
			m_RightButton->SetEnable(false);
		}

		for(uint i = 0;i< m_ButtonList.Size(); i++)
		{
			tempc_ptr(Button_List_Data) data = m_ButtonList[i];
			if(data)
			{
				if(data->control)
					data->control->SetVisible(false);
				if(data->button)
					data->button->SetVisible(false);
			}
		}
		
	}

	void ButtonList::OnPaint(PaintEventArgs & e)
	{	
		uint realcount = m_ButtonList.Size();
		Vector2 loc = Vector2::kZero;
	
		m_LeftButton->SetSize(m_ArrowSize);
		m_RightButton->SetSize(m_ArrowSize);
		
		for(uint i = m_pos;i< m_ButtonList.Size(); i++)
		{
			tempc_ptr(Button_List_Data) data = m_ButtonList[i];
			if( data&& data->button)
				data->button->SetVisible(false);
		}

		if(realcount <= m_MaxCount)
		{
			m_LeftButton->SetVisible(false);
			m_RightButton->SetVisible(false);

			for(uint i = m_pos;i< m_ButtonList.Size(); i++)
			{
				tempc_ptr(Button_List_Data) data = m_ButtonList[i];
				if( data)
				{
					if(data->button)
					{
						data->button->SetVisible(true);
						data->button->SetSize(m_ButtonSize);
						data->button->SetLocation(loc);
						
					}
					if(data->control)
					{
						data->control->SetVisible(true);
						if(m_Parent)
						{
							data->control->SetLocation(GetLocation() + loc + data->offset);
						}
						else
							data->control->SetLocation(loc + data->offset);
					}

					loc.x = loc.x + m_Space + m_ButtonSize.x;
				}
			}
		}
		else
		{
			uint distance;
			Vector2 locRight;

			distance = m_ArrowSize.x + m_MaxCount * m_ButtonSize.x + (m_MaxCount + 1) * m_Space;

			locRight = Vector2(distance,loc.y + m_Yoffset);
			
			m_LeftButton->SetLocation(Vector2(loc.x, loc.y + m_Yoffset));
			m_RightButton->SetLocation(locRight);
			m_LeftButton->SetVisible(true);
			m_RightButton->SetVisible(true);

			loc.x = loc.x + m_Space + m_ArrowSize.x;
			for(uint i = m_pos;i< m_pos + m_MaxCount; i++)
			{
				
				tempc_ptr(Button_List_Data) data = m_ButtonList[i];
				if( data)
				{
					if(data->button)
					{
						data->button->SetVisible(true);
						data->button->SetSize(m_ButtonSize);
						data->button->SetLocation(loc);
						
					}

					if(data->control)
					{
						data->control->SetVisible(true);
						if(m_Parent)
						{
							data->control->SetLocation(GetLocation() + loc + data->offset);
						}
						else
							data->control->SetLocation(loc + data->offset);
					}
					
					loc.x = loc.x + m_Space + m_ButtonSize.x;
				}
			}
		}
	}

	void ButtonList::MoveLeft(by_ptr(void) sender, InputEventArgs & e)
	{

		if(m_pos > 0)
		{
			m_pos -= 1;
			m_LeftButton->SetEnable(true);
		}
	}

	void ButtonList::MoveRight(by_ptr(void) sender, InputEventArgs & e)
	{
		m_pos += 1;

		uint buttonSize = m_ButtonList.Size();
		uint maxleft = buttonSize - m_MaxCount;

		if(m_pos >= maxleft)
		{
			m_pos = maxleft;
		}
	}
}