namespace Gui
{
	class BalloonSkin: public ControlSkin
	{
	public:
		INLINE_PDE_ATTRIBUTE_RW(ArrowDownImage, tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(ArrowUpImage, tempc_ptr(Image));
	private:
		sharedc_ptr(Image)	m_ArrowDownImage;
		sharedc_ptr(Image)	m_ArrowUpImage;
	};

	/// base class of ui elements
	class  Balloon : public Control
	{
		DECLARE_PDE_OBJECT(Balloon, Control)

	public:
		DECLARE_PDE_EVENT(EventClick, InputEventArgs);

	public:
		INLINE_PDE_ATTRIBUTE_RW (TextPadding,		Core::Vector4);
		INLINE_PDE_ATTRIBUTE_RW (MaxWidth,			F32);
		INLINE_PDE_ATTRIBUTE_RW (ArrowWidth,		F32);
		INLINE_PDE_ATTRIBUTE_RW (Owner,				tempc_ptr(Control));
		INLINE_PDE_ATTRIBUTE_RW (AutoWrap,			bool);

	public:
		///constructor
		Balloon();

		///destructor
		~Balloon();

		/// on frame update
		void OnFrameUpdate(EventArgs & e);
		/// on paint
		void OnPaint(PaintEventArgs & e);

		/// on input event
		void OnInputEvent(InputEventArgs & e);

		// on text changed
		void OnTextChanged(EventArgs & e);

		void Show(const Core::Rectangle& globalBaseRect, F32 timer, bool bOnTop = true);

		void Cancel();

		virtual void UpdateLocation(const Core::Rectangle& globalBaseRect, bool bOnTop = true);

		bool CheckVisibility();

		void Terminate();
		
	protected:
		//Properties
		Core::Vector4			m_TextPadding;
		Core::String			m_MultiLineStr;
		F32						m_MaxWidth;
		F32						m_ArrowWidth;

		//Variables
		F32						m_Timer;
		F32						m_ArrowCenter;
		bool					m_Started;
		bool					m_AboveBase;

		bool					m_AutoWrap;

		bool					m_Showing;

		sharedc_ptr(Control)		m_Owner;
	};
}