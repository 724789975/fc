namespace Gui
{
	class SplineView : public Control
	{
		DECLARE_PDE_OBJECT(SplineView, Control)

	public:
		enum ScaleKind
		{
			ScaleLife,
			ScaleValue,
			ScaleBoth,
		};

	public:
		DECLARE_PDE_EVENT(EventValueChange,			EventArgs);

	public:
		DECLARE_PDE_ATTRIBUTE_RW(GridVisible,		bool);
		DECLARE_PDE_ATTRIBUTE_RW(GridColor,			Core::ARGB);
		DECLARE_PDE_ATTRIBUTE_RW(LineColor,			Core::ARGB);
		DECLARE_PDE_ATTRIBUTE_RW(MinValue,			F32);
		DECLARE_PDE_ATTRIBUTE_RW(MaxValue,			F32);
		DECLARE_PDE_ATTRIBUTE_RW(MinLife,			F32);
		DECLARE_PDE_ATTRIBUTE_RW(MaxLife,			F32);
		DECLARE_PDE_ATTRIBUTE_RW(Spline,			sharedc_ptr(Core::PdeSplineF32));
		DECLARE_PDE_ATTRIBUTE_RW(WorkRect,			Core::Rectangle);
		DECLARE_PDE_ATTRIBUTE_R	(ControlPointCount,	S32);

		OVERRIDE_PDE_ATTRIBUTE_R(DefaultSize,	Core::Vector2) { return Core::Vector2(600, 200); }
	public:
		///constructor
		SplineView();

		///destructor
		~SplineView();

		/// on create
		virtual void OnCreate();

		/// on paint
		virtual void OnPaint(PaintEventArgs & e);

		/// on input event
		virtual void OnInputEvent(InputEventArgs & e);

		/// on layout
		virtual void OnLayout(EventArgs & e);

		/// on value change
		virtual void OnValueChange(EventArgs & e);

		F32 LifeToValue(F32 life);

	private:

		S32 AddSplineNode(const Core::Vector2 & pos);

		Core::Vector2 NodeToPos(F32 t, F32 v);

		F32 XToLife(F32 x);
		
		F32 YToValue(F32 y);

		Core::Vector2 IndexToPos(S32 idx);

		S32 PosToIndex(const Core::Vector2 & pos);

		void SwitchScaleKind();

		void SwitchCurvature(S32 idx);



		bool IsPointedOnLine(const Core::Vector2 & pos);

		void InitBothtArm();

		void MoveLeftArm(Core::Vector2 cursorPos,Core::Vector2 selectedPos);

		void MoveRightArm(Core::Vector2 cursorPos,Core::Vector2 selectedPos);

		void MoveControlPoint(Core::Vector2 cursorPos,S32& Idx);

		void MoveMultiControlPoint(Core::Vector2 cursorMove,S32& Idx);

		void SelectMultiControlPoint();

		void ScaleWorkRect(F32 scale);

	private:
		Core::Rectangle			m_WorkRect;
		bool					m_WorkRectMoving	:1;

		ScaleKind				m_ScaleKind;
		F32						m_VisibleLife;
		F32						m_VisibleValue;
		bool					m_GridVisible	: 1;
		bool					m_ControlPointMoving: 1;

		const S32				m_ArmLength			;
		bool					m_BothArmMoving		: 1;
		bool					m_LeftArmMoving		: 1;
		bool					m_RightArmMoving	: 1;
		bool					m_ArmVisible		: 1;
		Core::Vector2			m_LeftArmPos;
		Core::Vector2			m_RightArmPos;
		F32						m_MinValue;
		F32						m_MaxValue;
		F32						m_MinLife;
		F32						m_MaxLife;
		F32						m_LifeStep;
		F32						m_ValueStep;
		S32						m_SelectedIdx;
		Core::Array<S32>		m_aMultiSelectedIdx;
		bool					m_SingleSelecting;
		bool					m_MultiSelecting;
		Core::Rectangle			m_MultiSelectedRect;
		S32						m_PointedIdx;
		Core::ARGB				m_GridColor;
		Core::ARGB				m_LineColor;

		sharedc_ptr(Core::PdeSplineF32)		m_Spline;
	};
}