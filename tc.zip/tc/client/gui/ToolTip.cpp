#include "pch.h"

using namespace Core;
using namespace Gui;
using namespace Client;

DEFINE_PDE_TYPE_CLASS(Gui::TooltipSkin)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::ControlSkin);
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_PROPERTY_RW(ArrowDownImage);
		ADD_PDE_PROPERTY_RW(ArrowUpImage);
	}
};

DEFINE_PDE_TYPE_CLASS(Gui::ToolTip)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::ScrollableControl);
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_PROPERTY_RW(TextPadding);
		ADD_PDE_PROPERTY_RW(MaxWidth);
		ADD_PDE_PROPERTY_RW(ArrowWidth);
	}
};

REGISTER_PDE_TYPE(Gui::TooltipSkin);
REGISTER_PDE_TYPE(Gui::ToolTip);

namespace Gui
{
	ToolTip::ToolTip()
	{		
		m_Timer = 0;
		m_TimerStart = false;

		m_AutomaticDelay = 500;
		m_AutoPopDelay = 2000;
		m_ReshowDelay = 1000;
		m_Reshow = false;
	}

	ToolTip::~ToolTip()
	{
	}
}

//--------------------------------------------------------------------------------------
// Event
//--------------------------------------------------------------------------------------
namespace Gui
{
	/// on create
	void ToolTip::OnCreate()
	{
		Super::OnCreate();
		SetVisible(false);
	}

	/// on frame update
	void ToolTip::OnFrameUpdate(EventArgs & e)
	{
		F64 timer = Task::GetTotalTime() - m_Timer;
		if (m_TimerStart && !GetVisible() && ((m_Reshow && timer > m_ReshowDelay / 1000.f) || (timer > m_AutomaticDelay / 1000.f)))
		{
			Show();
			m_Timer = Task::GetTotalTime();
		}
		else if (m_TimerStart && m_AutoPopDelay != 0 && (timer > m_AutoPopDelay / 1000.f))
		{
			Close();
			m_Timer = Task::GetTotalTime();
		}
		else if (!m_TimerStart)
		{
			m_Reshow = false;
			m_Timer = Task::GetTotalTime();
		}

		Super::OnFrameUpdate(e);
	}

	/// on paint
	void ToolTip::OnPaint(PaintEventArgs & e)
	{
		//Super::OnPaint(e);
		tempc_ptr(TooltipSkin) skin = ptr_static_cast<TooltipSkin>(GetSkin());
		Core::Rectangle textRect = GetClientRect();
		textRect.Shrink(m_TextPadding);
		if(skin)
		{
			Core::Rectangle arrowRect = GetClientRect();
			arrowRect.Min.x = -m_ArrowWidth/2;
			arrowRect.Max.x = m_ArrowWidth/2;
			arrowRect.Move(Vector2(m_ArrowCenter, 0));
			Skin::DrawImage(e.render, skin->GetBackgroundImage(), GetClientRect());
			if(m_AboveBase)
				Skin::DrawImage(e.render, skin->GetArrowDownImage(), arrowRect);
			else
				Skin::DrawImage(e.render, skin->GetArrowUpImage(), arrowRect);

			e.render->DrawStringShadow(GetFont(), GetTextColor(), GetTextShadowColor(), ARGB(0,0,0,0), textRect, m_MultiLineStr
				, Unit::kAlignCenterMiddle, -1, GetTextLightSource());
		}
		else
		{
			e.render->DrawRectangle(GetClientRect(), Core::Rectangle(0,0,1,1));
			e.render->DrawString(GetFont(), ARGB(255,255,0,0), ARGB(0,0,0,0), textRect, m_MultiLineStr
				, Unit::kAlignCenterMiddle);		
		}		
	}

	/// on input
	void ToolTip::OnInputEvent(InputEventArgs & e)
	{
		if (e.Type == InputEventArgs::kMouseEnter || e.Type == InputEventArgs::kMouseLeave)
			e.Handled = true;

		if (!e.Handled)
			Super::OnInputEvent(e);
	}
}

//--------------------------------------------------------------------------------------
// Method
//--------------------------------------------------------------------------------------
namespace Gui
{
	/// begin to show
	void ToolTip::ShowStart(by_ptr(Control) hOwner, const Core::Rectangle& globalBaseRect, const Core::String & text)
	{
		if (m_TimerStart)
			return;

		if (text == String::kEmpty || text == "")
			return;

		SetStyle("Gui.Tooltip");

		SetText(text);
		Control::SplitString(text, m_MultiLineStr, m_MaxWidth-m_TextPadding.x-m_TextPadding.z, GetFont());

		//Calculate actual size
		Core::Rectangle tempRect = Core::Rectangle(0,0,0,0);
		Core::Rectangle textRect = GetFont()->MeasureString(tempRect, m_MultiLineStr, -1, Unit::kAlignLeftTop);
		textRect.Shrink(-m_TextPadding);
		Vector2 aSize = textRect.GetExtent();
		aSize.x = Core::Ceil(aSize.x);
		aSize.y = Core::Ceil(aSize.y);
		Vector2 aPos;
		SetSize(aSize);
		F32 leftBound = m_TextPadding.x;
		F32 rightBound = m_TextPadding.z;
		F32 CenterTollerance = m_ArrowWidth/2;
		m_ArrowCenter = aSize.x/2;

		Core::Vector2 screenSize = gGame->guiSys->GetSize();

		Vector2 basePointTop = globalBaseRect.GetCenter()-Vector2(0, globalBaseRect.GetExtent().y/2);
		Vector2 basePointBottom = globalBaseRect.GetCenter()+Vector2(0, globalBaseRect.GetExtent().y/2);

		//Try to put it on top
		if(basePointTop.y-aSize.y<0)
		{
			m_AboveBase = false;
		}
		else
		{
			m_AboveBase = true;
		}

		aPos.y = m_AboveBase?(basePointTop.y-aSize.y):(basePointBottom.y);
		aPos.x = basePointTop.x-aSize.x/2;

		//Test the right boundary
		if(basePointTop.x+aSize.x/2>screenSize.x)
		{
			F32 difference = basePointTop.x+aSize.x/2-screenSize.x;
			if(difference<aSize.x/2-CenterTollerance-rightBound)
			{
				aPos.x-=difference;
				m_ArrowCenter+=difference;
			}
			else
			{
				aPos.x-=aSize.x/2-CenterTollerance-rightBound;
				m_ArrowCenter+=aSize.x/2-CenterTollerance-rightBound;
			}
		}

		//Test the left boundary
		if(basePointTop.x-aSize.x/2<0)
		{
			F32 difference = aSize.x/2 - basePointTop.x;
			if(difference<aSize.x/2-CenterTollerance-leftBound)
			{
				aPos.x+=difference;  //Should be 0
				m_ArrowCenter-=difference;
			}
			else
			{
				aPos.x+=aSize.x/2-CenterTollerance-rightBound;
				m_ArrowCenter-=aSize.x/2-CenterTollerance-rightBound;
			}
		}
		aPos.x = Core::Floor(aPos.x+0.5f);
		aPos.y = Core::Floor(aPos.y+0.5f);

		// timer start
		m_TimerStart = true;

		if(hOwner) {
			SetParent(hOwner);					
			SetLocation(aPos);
			SetParent(gGame->guiSys);
		}
	}

	/// show
	void ToolTip::Show()
	{
		if (!GetParent() || GetVisible())
			return;

		SetVisible(true);

		m_Reshow = true;
	}

	/// close
	void ToolTip::Close()
	{
		SetVisible(false);

		SetText("");

		m_TimerStart = false;

		SetParent(NullPtr);

		m_Timer = Task::GetTotalTime();
	}
}
