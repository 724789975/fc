namespace Gui
{
	class KeyBox : public Control
	{
		DECLARE_PDE_OBJECT(KeyBox,Control);

	public:
		DECLARE_PDE_EVENT(EventKeyNameChanged,		EventArgs);
		DECLARE_PDE_EVENT(EventKeyConflict,			EventArgs);
		DECLARE_PDE_EVENT(EventKeyForbidden,		EventArgs);
		DECLARE_PDE_ATTRIBUTE_RW(KeyName,			Core::String);

	public:
		KeyBox();

		~KeyBox();

		virtual void OnPaint(PaintEventArgs & e);

		virtual void OnInputEvent(InputEventArgs & e);

		virtual void OnFrameUpdate(EventArgs & e);

		virtual void OnLeave(EventArgs & e);

		void OnKeyNameChanged();

		void OnKeyConflict();

		void OnKeyForbidden();

		void Empty();

	private:
		bool				m_CursorVisible;
		bool				m_Setting;
		Core::String		m_KeyName;
		Core::String		m_KeyText;
	};
}