namespace Gui
{
	// Image base class.
	class Image : public Core::Object
	{
	public:
		// default constructor.
		Image();

		// constructor.
		Image(const Core::Identifier & path, const Core::Vector4 & border,Core::Vector4 uv = Core::Vector4(0,0,1,1));

		// destructor
		~Image();

	public:
		DECLARE_PDE_ATTRIBUTE_RW(Rotate,		Client::Unit::Rotate);
		DECLARE_PDE_ATTRIBUTE_RW(Border,		const Core::Vector4 &);
		DECLARE_PDE_ATTRIBUTE_RW(Path,			const Core::Identifier &);
		DECLARE_PDE_ATTRIBUTE_RW(uv,			Core::Vector4);
		DECLARE_PDE_ATTRIBUTE_R (Size,			Core::Vector2);
		DECLARE_PDE_ATTRIBUTE_RW (alpha,			int);


	public:
		virtual bool IsReady() { return m_Texture && m_Texture->IsReady(); }
		sharedc_ptr(Client::Texture2D) GetTexture() { return m_Texture;}
	public:
		// draw
		virtual void Draw(by_ptr(Client::UIRender) render, const Core::Rectangle & rect, Core::ARGB color);
		
		virtual void DrawRotation(by_ptr(Client::UIRender) render, Core::Vector3 Min, Core::Vector3 Max, Core::ARGB color);
		
		virtual void DrawRotation(by_ptr(Client::UIRender) render, Core::Vector3 Min, Core::Vector3 Max,Core::Vector3 TopRight,Core::Vector3 BottomLeft, Core::ARGB color);

	protected:
		Core::Vector4 m_Border;
		Client::Unit::Rotate  m_rotate;
		sharedc_ptr(Client::Texture2D) m_Texture;
		Core::Vector4     m_uv;
		int				  m_alpha;
	};
}

namespace Gui
{
	class AnimatedImage: public Image
	{
	public:
		// default constructor.
		AnimatedImage();

		// constructor.
		AnimatedImage(const Core::Identifier & path, int numX, int numY, int frameCount);

		// destructor
		~AnimatedImage();

	public:
		INLINE_PDE_ATTRIBUTE_R(NumX, int);
		INLINE_PDE_ATTRIBUTE_R(NumY, int);
		INLINE_PDE_ATTRIBUTE_R(CurrentFrame, int);
		DECLARE_PDE_ATTRIBUTE_RW(FrameTime, F32);
		DECLARE_PDE_ATTRIBUTE_RW(FrameCount, int);

	public:
		// draw
		virtual void Draw(by_ptr(Client::UIRender) render, const Core::Rectangle & rect, Core::ARGB color);

	public:
		int		Update(F32 updateTime);
		void	Reset();

	protected:
		int		m_NumX;
		int		m_NumY;
		int		m_CurrentFrame;
		F32		m_FrameTime;
		F32		m_Accumulator;
		int		m_FrameCount;
	};
}

namespace Gui
{
	class ComplexImage: public Image
	{
	public:
		// default constructor.
		ComplexImage();

		// constructor.
		ComplexImage(const Core::Identifier & path, const Core::Vector4 & border, const Core::Vector2 & center);

		// destructor
		~ComplexImage();

	public:
		DECLARE_PDE_ATTRIBUTE_RW(Center,		const Core::Vector2 &);

	public:
		// draw
		virtual void Draw(by_ptr(Client::UIRender) render, const Core::Rectangle & rect, Core::ARGB color);

	protected:
		Core::Vector2 m_Center;
	};
}