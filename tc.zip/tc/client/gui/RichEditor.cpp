#include "pch.h"

using namespace Core;
using namespace Gui;
using namespace Client;


DEFINE_PDE_TYPE_CLASS(Gui::RichEdit)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::ScrollableControl);
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_PROPERTY_RW(MaxLine);
		ADD_PDE_PROPERTY_R (Click_Name);
		ADD_PDE_PROPERTY_W (Line_Space);
		ADD_PDE_PROPERTY_RW(Text_Shadow);

		ADD_PDE_METHOD(AddMsg);
		ADD_PDE_METHOD(CleanAll);

		ADD_PDE_EVENT(EventClick_Name);
	}
};

REGISTER_PDE_TYPE(Gui::RichEdit)

namespace Gui
{
	RichEdit::RichEdit()
		: mMaxLine(15)
		, m_Click_Name(NULL)
		, m_Line_Space(0.0f)
		, m_Text_Shadow(false)
	{
		CleanAll();
	}

	PDE_ATTRIBUTE_GETTER(RichEdit, MaxLine, int)
	{
		return mMaxLine;
	}

	PDE_ATTRIBUTE_SETTER(RichEdit, MaxLine, int)
	{
		if(mMaxLine != value)
			mMaxLine = value;
	}
	
	PDE_ATTRIBUTE_GETTER(RichEdit, Text_Shadow, bool)
	{
		return m_Text_Shadow;
	}

	PDE_ATTRIBUTE_SETTER(RichEdit, Text_Shadow, bool)
	{
		if(m_Text_Shadow != value)
			m_Text_Shadow = value;
	}

	PDE_ATTRIBUTE_GETTER(RichEdit, Click_Name, Core::String)
	{
		return m_Click_Name;
	}
	
	PDE_ATTRIBUTE_SETTER(RichEdit, Line_Space, float)
	{
		if(m_Line_Space != value)
			m_Line_Space = value;
	}

	RichEdit::~RichEdit()
	{
		
	}

	void RichEdit::OnCreate()
	{
		Super::OnCreate();
	}

	void RichEdit::CleanAll()
	{
		int i = 0;
		while (i < all_msg.GetCount())
		{
			if (all_msg[i].m_Button)
			{
				all_msg[i].m_Button->SetParent(NullPtr);
			}
			if (all_msg[i].m_MouseCtr)
			{
				all_msg[i].m_MouseCtr->SetParent(NullPtr);
			}
			i++;
		}
		i = 0;
		while (i < all_richmsg.GetCount())
		{
			if (all_richmsg[i].m_Button)
			{
				all_richmsg[i].m_Button->SetParent(NullPtr);
			}
			if (all_richmsg[i].m_MouseCtr)
			{
				all_richmsg[i].m_MouseCtr->SetParent(NullPtr);
			}
			i++;
		}
		all_msg.Clear();
		all_richmsg.Clear();
		mLineNum = 0;
		pos_x = 0;
	}

	void RichEdit::CheckMaxLine()
	{
		if (mLineNum > mMaxLine)
		{
			for(int i = 0; i < (int)all_richmsg.Size(); ++i)
			{
				all_richmsg[i].line -= (mLineNum-mMaxLine);
			}
			for(int i = 0; i < (int)all_richmsg.Size(); ++i)
			{
				if (all_richmsg[i].line <= 0)
				{
					if (all_richmsg[i].m_Button)
					{
						all_richmsg[i].m_Button->SetParent(NullPtr);
						all_richmsg[i].m_Button = NullPtr;
					}
					if (all_richmsg[i].m_MouseCtr)
					{
						all_richmsg[i].m_MouseCtr->SetParent(NullPtr);
						all_richmsg[i].m_MouseCtr = NullPtr;
					}
					all_richmsg.RemoveAt(i);
					i--;
				}
			}
			if (all_msg.Size() > 0)
			{
				all_msg.RemoveAt(0);
			}
			mLineNum -= (mLineNum-mMaxLine);
		}
	}

	void RichEdit::AddMsg(Core::String & msg, Core::ARGB color, bool isnew, bool is_btn)
	{
		if (gGame->screen->GetMinimized())
		{
			return;
		}
		UsualMsg umsg;
		umsg.msg = msg;
		umsg.color = color;
		umsg.isnew = isnew;
		sharedc_ptr(Button) Btn = NullPtr;
		sharedc_ptr(MouseControl) MouseCtr = NullPtr;
		if (is_btn)
		{
			Btn = ptr_new(Button);
			MouseCtr = ptr_new(MouseControl);
			MouseCtr->SetParent(ptr_static_cast<RichEdit>(this));
			Btn->SetParent(MouseCtr);
			Core::String str = msg;
			Core::Rectangle tempRect = Core::Rectangle(0,0,0,0);
			Core::Vector2 o = GetFont()->MeasureString(tempRect, str, -1, Unit::kAlignLeftMiddle).GetExtent();
			Btn->SetSize(Core::Vector2(o.x,GetFont()->GetLineHeight()));
			MouseCtr->SetSize(Core::Vector2(o.x,GetFont()->GetLineHeight()));
			Btn->SetText(str.Str());
			Btn->SetBackgroundColor(Core::ARGB(0,255,255,255));
			MouseCtr->SetBackgroundColor(Core::ARGB(0,255,255,255));
			Btn->SetTextColor(Core::ARGB(0,255,255,255));
			Btn->SetHighlightTextColor(Core::ARGB(0,255,255,255));
			Btn->EventClick.Subscribe(NewDelegate(&RichEdit::On_ButtonClick,ptr_static_cast<RichEdit>(this)));
			MouseCtr->SetMouseType(1);
		}
		all_msg.PushBack(umsg);
		CheckMsg(msg,color,isnew,Btn,MouseCtr);
		if (isnew)
		{
			CheckMaxLine();
		}
	}

	void RichEdit::CheckMsg(Core::String & msg, Core::ARGB color, bool isnew,sharedc_ptr(Button) btn,sharedc_ptr(MouseControl) MouseCtr)
	{
		if (isnew)
		{
			mLineNum++;
			pos_x = 0;
		}
		Core::Rectangle rect = GetFont()->MeasureString(Core::Rectangle(0, 0, 0, 0), msg, -1, 0);
		rect.Max.x += pos_x;
		rect.Min.x += pos_x;
		float length = rect.Max.x - rect.Min.x;
		Core::Vector2 controlsize = GetSize();

		//����BUTTON����
		if (btn && rect.Max.x > controlsize.x-GetVScrollBarWidth())
		{
			mLineNum++;
			pos_x = 0;
			rect = GetFont()->MeasureString(Core::Rectangle(0, 0, 0, 0), msg, -1, 0);
			length = rect.Max.x - rect.Min.x;
		}

		if (rect.Max.x <= controlsize.x-GetVScrollBarWidth())
		{
			RichMsg newmsg;
			newmsg.msg = msg;
			newmsg.color = color;
			newmsg.rect = rect;
			newmsg.line = mLineNum;
			newmsg.m_Button = btn;
			newmsg.m_MouseCtr = MouseCtr;
			if (MouseCtr)
			{
				MouseCtr->SetLocation(Core::Vector2(pos_x,(mLineNum-1) * GetFont()->GetLineHeight()));
			}
			pos_x = rect.Max.x + 2;
			all_richmsg.PushBack(newmsg);
		}
		else
		{
			CStrBuf<256> type_msg = msg.Str();
			const CHAR* start = msg.Str();
			F32 letterW = 0;
			for (size_t i = 0;;)
			{
#ifdef USE_UTF8
				U16 letter = 0;

				S32 len = GetUTF8CharLength((U8*)&start[i], -1);
				if (len)
				{
					UTF8toUTF16((U8*)&start[i], len, &letter, 1);
					i += len;
				}
#else
				U16 letter = start[i++];

				if (IsDBCSLeadByteEx(936, letter))
				{
					letter = (letter << 8) | (U8)start[i++];
				}
#endif
				// string end
				if (letter == 0)
					break;

				// character info
				const Font::CharInfo & info = GetFont()->GetCharacterInfo(letter);
				letterW += info.horiAdvance + GetFont()->GetCharSpace();

				if (pos_x + letterW + GetFontSize()*2 >= controlsize.x-GetVScrollBarWidth())
				{
					CStrBuf<256> currentlineRefStr = type_msg;
					rect = GetFont()->MeasureString(Core::Rectangle(0, 0, 0, 0), String(type_msg), i, 0);
					rect.Max.x += pos_x;
					rect.Min.x += pos_x;
					if (rect.Max.x > controlsize.x-GetVScrollBarWidth())
					{
						mLineNum++;
						pos_x = 0;
						i = 0;
						continue;
					}
					RichMsg newmsg;
					currentlineRefStr.copy(type_msg,0,i);
					newmsg.msg = Core::String(currentlineRefStr);
					newmsg.color = color;
					newmsg.rect = rect;
					newmsg.line = mLineNum;
					mLineNum++;
					type_msg = type_msg + i;
					start = type_msg;
					i = 0;
					pos_x = 0;
					letterW = 0;
					all_richmsg.PushBack(newmsg);
				}
			}

			rect = GetFont()->MeasureString(Core::Rectangle(0, 0, 0, 0), String(type_msg), -1, 0);
			rect.Max.x += pos_x;
			rect.Min.x += pos_x;
			length = rect.Max.x - rect.Min.x;
			RichMsg newmsg;
			newmsg.msg = Core::String(type_msg);
			newmsg.color = color;
			newmsg.rect = rect;
			newmsg.line = mLineNum;
			pos_x = rect.Max.x + 2;
			all_richmsg.PushBack(newmsg);
		}

		int line_height = mLineNum * GetFont()->GetLineHeight();
		int temp_y = line_height < GetSize().y ?  GetSize().y : line_height;
		Super::SetAutoScrollMinSize(Core::Vector2(m_AutoScrollMinSize.x,temp_y));
	}

	void RichEdit::OnPaint(PaintEventArgs & e)
 	{
		Super::OnPaint(e);

		if (all_richmsg.Size() > 0)
		{
			for (int i = 0; i < (int)all_richmsg.Size(); ++i)
			{
				Core::Rectangle rect = all_richmsg[i].rect;
				rect.Min.y = (all_richmsg[i].line-1) * (GetFont()->GetLineHeight() + m_Line_Space);
				rect.Max.y = all_richmsg[i].line * (GetFont()->GetLineHeight() + m_Line_Space);
				if (all_richmsg[i].m_MouseCtr)
				{
					all_richmsg[i].m_MouseCtr->SetLocation(Core::Vector2(all_richmsg[i].m_MouseCtr->GetLocation().x,rect.Min.y));
				}
				if (m_Text_Shadow)
				{
					e.render->DrawStringShadow(GetFont(),all_richmsg[i].color, ARGB(75,0,0,0), ARGB(0,0,0,0), rect, all_richmsg[i].msg, Unit::kAlignLeftBottom, -1);
				} 
				else
				{
					e.render->DrawString(GetFont(), all_richmsg[i].color,ARGB(1,1,1,1), rect, all_richmsg[i].msg, Unit::kAlignLeftBottom);
				}
			}
		}
	}

	void RichEdit::On_ButtonClick(by_ptr(void) sender, InputEventArgs & e)
	{
		tempc_ptr(Button) res = ptr_static_cast<Button>(sender);
		m_Click_Name = res->GetText();
		EventClick_Name.Fire(ptr_static_cast<Self>(this),(Core::EventArgs &)NullPtr);
	}
}