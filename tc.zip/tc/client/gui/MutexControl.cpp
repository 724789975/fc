#include "pch.h"

using namespace Core;
using namespace Client;
using namespace Gui;

DEFINE_PDE_TYPE_CLASS(Gui::MutexControl)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::Control);
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_EVENT(EventClick);
		ADD_PDE_EVENT(EventRightClick);
		ADD_PDE_EVENT(EventSelectedChanged);

		ADD_PDE_PROPERTY_RW(Selected);
		ADD_PDE_PROPERTY_W(PopupMenu);
	}
};
REGISTER_PDE_TYPE(Gui::MutexControl);

DEFINE_PDE_TYPE_CLASS(Gui::MutexControlSkin)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::ControlSkin);
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_PROPERTY_RW(SelectedImage);
	}
};

REGISTER_PDE_TYPE(Gui::MutexControlSkin);

namespace Gui
{
	MutexControl::MutexControl(void)
		: m_Selected(false)
	{

	}

	MutexControl::~MutexControl(void)
	{

	}

	PDE_ATTRIBUTE_GETTER(MutexControl,Selected,bool)
	{
		return m_Selected;
	}

	PDE_ATTRIBUTE_SETTER(MutexControl,Selected,bool)
	{
		if (value != m_Selected)
		{
			m_Selected = value;
			OnSelectedChanged(EventArgs());
			if (value)
			{
				tempc_ptr(Control) parent = GetParent();
				tempc_ptr(MutexControl) mutexControl;
				if (parent)
				{
					Control* child = parent->GetFirstChild();
					while(child)
					{
						mutexControl = ptr_dynamic_cast<MutexControl>(child);
						if (mutexControl && mutexControl != ptr_dynamic_cast<MutexControl>(this))
						{
							mutexControl->SetSelected(false);
						}

						child = child->GetNext();
					}
				}
			}
			Invalid();
		}
	}

	PDE_ATTRIBUTE_SETTER(MutexControl,PopupMenu,sharedc_ptr(Menu))
	{
		if (value != m_PopupMenu)
		{
			m_PopupMenu = value;
		}
	}

	void MutexControl::OnCreate()
	{
		Super::OnCreate();
	}

	void MutexControl::OnPaint(PaintEventArgs & e)
	{
		Core::Rectangle rect = GetDisplayRect();
		tempc_ptr(MutexControlSkin) skin = ptr_static_cast<MutexControlSkin>(GetSkin());
		if (skin)
		{
			if (m_Selected)
			{
				Skin::DrawImage(e.render,skin->GetSelectedImage(),GetBackgroundRect());
			} 
			else
			{
				Control::OnPaint(e);
			}
		} 
		else
		{
			if (m_Selected)
			{
				e.render->DrawRectangle(rect,rect,ARGB(255,255,255,0));
			}
			else
			{
				e.render->DrawRectangle(rect,rect,ARGB(255,0,255,0));
			}
		}
	}

	void MutexControl::OnInputEvent(InputEventArgs & e)
	{
		if (e.IsMouseEvent())
		{
			switch (e.Type)
			{
			case InputEventArgs::kMouseUp:
				{
					SetSelected(true);

					if (e.Code == MC_LEFT_BUTTON)
					{
						OnClick(e);
					}

					else if (e.Code == MC_RIGHT_BUTTON)
					{
						if (m_PopupMenu)
						{
							m_PopupMenu->SetTag(ptr_static_cast<MutexControl>(this));
							m_PopupMenu->SetLocation(ClientToGlobalScreen(ScreenToClient(e.CursorPosition)));
						}
						OnRightClick(e);
					}
					e.Handled = true;
				}
				break;
			}
		}
		if (!e.Handled)
		{
			Super::OnInputEvent(e);
		}
	}

	void MutexControl::OnClick(Client::InputEventArgs & e)
	{
		EventClick.Fire(ptr_static_cast<MutexControl>(this),e);
	}

	void MutexControl::OnRightClick(Client::InputEventArgs & e)
	{
		EventRightClick.Fire(ptr_static_cast<MutexControl>(this),e);
	}

	void MutexControl::OnSelectedChanged(Core::EventArgs & e)
	{
		EventSelectedChanged.Fire(ptr_static_cast<MutexControl>(this),e);
	}
}
