#include "pch.h"

using namespace Core;
using namespace Gui;
using namespace Client;

DEFINE_PDE_TYPE_CLASS(Gui::InGameMainButton)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::Button);
		ADD_PDE_DEFAULT_CONSTRUCTOR();
	}
};

DEFINE_PDE_TYPE_CLASS(Gui::InGameMainButtonSkin)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::ControlSkin);
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_PROPERTY_RW(GameUpperImage);
		ADD_PDE_PROPERTY_RW(GameUpperHoverImage);
		ADD_PDE_PROPERTY_RW(GameGlowUpperImage);
		ADD_PDE_PROPERTY_RW(GameActiveUpperImage);
	}
};

REGISTER_PDE_TYPE(Gui::InGameMainButton);
REGISTER_PDE_TYPE(Gui::InGameMainButtonSkin);

#define CLICK_EFFECT_DURATION 0.4f

namespace Gui
{
	InGameMainButton::InGameMainButton()
		: m_Clickable(true)
	{

	}

	InGameMainButton::~InGameMainButton()
	{

	}

	void InGameMainButton::OnCreate()
	{
		Super::OnCreate();
		m_NotificationFont = gRender->font_manager->GetFont("simhei", 24, 0);
	}

	void InGameMainButton::OnFrameUpdate(EventArgs & e)
	{
		Super::OnFrameUpdate(e);
	}

	void InGameMainButton::OnInputEvent( Client::InputEventArgs & e )
	{
		if (e.IsMouseEvent())
		{
			Core::Vector2 localPos = ScreenToClient(e.CursorPosition);
			m_MousePointed =  GetDisplayRect().IsPointInside(localPos);

			switch (e.Type)
			{
			case InputEventArgs::kMouseDown:
			case InputEventArgs::kMouseDoubleClick:
				{
					if(m_Clickable)
					{
						if(m_MousePointed && e.Code == MC_LEFT_BUTTON )
						{
							if (e.Type == InputEventArgs::kMouseDoubleClick)
							{
								OnDoubleClick(e);
							}
							Invalid();
							SetCapture(true);
							m_MouseHoldDown = true;
							e.Handled = true;
						}
					}
					else
					{
						e.Handled = true;
					}
				}
				break;

			case InputEventArgs::kMouseUp:
				{
					if(m_Clickable)
					{
						if(e.Code == MC_LEFT_BUTTON && m_MouseHoldDown)
						{					
							Invalid();
							m_MouseHoldDown = false;

							SetCapture(false);

							if(m_MousePointed)
							{
								if(m_CanPushDown)
									m_PushDown = !m_PushDown;
								OnClick(e);
							}
							e.Handled = true;
						}
					}
					else
					{
						e.Handled = true;
					}
				}
				break;

			case InputEventArgs::kMouseLeave:
				{
					m_MousePointed = false;
					e.Handled = false;
				}
				break;
			}
		}

		if(e.IsKeyEvent() && m_Clickable)
			OnKeyEvent(e);

		if (!e.Handled)
			Control::OnInputEvent(e);
	}

	void InGameMainButton::OnClick(Client::InputEventArgs &e)
	{
		Super::OnClick(e);
	}

	void InGameMainButton::OnPaint(PaintEventArgs & e)
	{
		tempc_ptr(InGameMainButtonSkin) skin = ptr_static_cast<InGameMainButtonSkin>(GetSkin());

		if (skin)
		{
			if(e.Enable)
			{
				F32 upperW = skin->GetGameUpperImage()->GetSize().x;
				F32 upperH = skin->GetGameUpperImage()->GetSize().y;
				F32 bottomHeight = 29;
				Core::Rectangle upperRect;
				Core::Rectangle bottomRect = Core::Rectangle::LeftBottom(0, GetSize().y, GetSize().x, bottomHeight);
				ARGB textColor = m_TextColor;
				textColor.a = 160;
				if(m_PushDown)
				{
					upperRect = Core::Rectangle::LeftTop(0, 0, upperW, upperH);
					textColor.a = 255;
				}
				else
				{
					upperRect = Core::Rectangle::LeftTop(0, 0, upperW, upperH);
					Core::Vector2 center;
					center.x = upperRect.Min.x + upperW / 2;
					center.y = upperRect.Min.y + upperH / 2;
					F32 tempW = upperW - 0.197f * upperW * (1-GetHoverPower());
					F32 tempH = upperH - 0.197f * upperH * (1-GetHoverPower());
					upperRect = Core::Rectangle::LeftTop((upperW-tempW)/2, (upperH-tempH)/2, tempW, tempH);
				}
				if(m_PushDown)
				{
					Skin::DrawImage(e.render, skin->GetGameActiveUpperImage(), upperRect);
				}
				else
				{
					U8 uAlpha = (U8)(GetHoverPower()*255);
					Skin::DrawImage(e.render, skin->GetGameUpperImage(), upperRect);
					Skin::DrawImage(e.render, skin->GetGameUpperHoverImage(), upperRect, ARGB(uAlpha, 255,255,255));
				}
				e.render->DrawStringShadow(m_NotificationFont, textColor, ARGB(192,0,0,0), ARGB(0,0,0,0), bottomRect
					, GetText(), Unit::kAlignCenterMiddle);	
			}
			else
			{
				Core::Rectangle upperRect;
				F32 upperW = skin->GetGameUpperImage()->GetSize().x;
				F32 upperH = skin->GetGameUpperImage()->GetSize().y;
				upperRect = Core::Rectangle::LeftTop(0, 0, upperW, upperH);
				Skin::DrawImage(e.render, skin->GetGameUpperImage(), upperRect);
			}
		}
		else
		{
			e.render->DrawString(GetFont(), m_TextColor, m_BackgroundColor, GetBackgroundRect().Shrink(GetPadding()), m_Text, Unit::kAlignCenterMiddle);
		}
	}
}