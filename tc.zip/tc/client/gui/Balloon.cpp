#include "pch.h"

using namespace Core;
using namespace Client;
using namespace Gui;

//--------------------------------------------------------------------------------------
// type info
//--------------------------------------------------------------------------------------
DEFINE_PDE_TYPE_CLASS(BalloonSkin)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(ControlSkin);
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_PROPERTY_RW(ArrowDownImage);
		ADD_PDE_PROPERTY_RW(ArrowUpImage);
	}
};

DEFINE_PDE_TYPE_CLASS(Balloon)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Control);
		ADD_PDE_DEFAULT_CONSTRUCTOR();
		ADD_PDE_PROPERTY_RW(TextPadding);
		ADD_PDE_PROPERTY_RW(MaxWidth);
		ADD_PDE_PROPERTY_RW(ArrowWidth);
	}
};

REGISTER_PDE_TYPE(BalloonSkin);
REGISTER_PDE_TYPE(Balloon);

namespace Gui
{
	Balloon::Balloon()
		: m_MaxWidth(240.f)
		, m_ArrowWidth(32.f)
		, m_Timer(FLT_MAX)
		, m_Started(false)
		, m_AboveBase(true)
		, m_ArrowCenter(-1.f)
		, m_Showing(false)
		, m_AutoWrap(true)
	{
	}

	Balloon::~Balloon()
	{
	}

	void Balloon::OnFrameUpdate( EventArgs & e )
	{
		Super::OnFrameUpdate(e);
		if(m_Started)
		{
			F32 frameTime = Task::GetFrameTime();
			m_Timer-=frameTime;
			if(m_Showing)
			{
				IncreaseHoverPower();
				if(Core::Abs(m_HoverPower-1.f)<Core::EPSILON)
					m_Showing = false;
			}
			
			SetVisible(CheckVisibility());
		}
		if(m_Timer<0.f)
		{
			DecreaseHoverPower();
			if(Core::Abs(m_HoverPower)<Core::EPSILON)
			{
				if(m_Owner)
					m_Owner = NullPtr;
				m_Started = false;
				Task::Post(NewGenericTask(&Balloon::Terminate, ptr_static_cast<Balloon>(this)));
			}
		}
	}

	void Balloon::OnPaint( PaintEventArgs & e )
	{
		tempc_ptr(BalloonSkin) skin = ptr_static_cast<BalloonSkin>(GetSkin());
		Core::Rectangle textRect = GetClientRect();
		textRect.Shrink(m_TextPadding);
		U8 uAlpha = (U8)(GetHoverPower()*255);
		if(skin)
		{
			Core::Rectangle arrowRect = GetClientRect();
			arrowRect.Min.x = -m_ArrowWidth/2;
			arrowRect.Max.x = m_ArrowWidth/2;
			arrowRect.Move(Vector2(m_ArrowCenter, 0));
			Skin::DrawImage(e.render, skin->GetBackgroundImage(), GetClientRect(), ARGB(uAlpha, 255,255,255));
			if(m_AboveBase)
				Skin::DrawImage(e.render, skin->GetArrowDownImage(), arrowRect, ARGB(uAlpha, 255,255,255));
			else
				Skin::DrawImage(e.render, skin->GetArrowUpImage(), arrowRect, ARGB(uAlpha, 255,255,255));

			ARGB textColor = GetTextColor();
			ARGB textShadowColor = GetTextShadowColor();
			textColor.a = uAlpha;
			textShadowColor.a = uAlpha;
			e.render->DrawStringShadow(GetFont(), GetTextColor(), GetTextShadowColor(), ARGB(0,0,0,0), textRect, m_MultiLineStr
				, Unit::kAlignCenterMiddle, -1, GetTextLightSource());
		}
		else
		{
			e.render->DrawRectangle(GetClientRect(), Core::Rectangle(0,0,1,1));
			e.render->DrawString(GetFont(), ARGB(255,255,0,0), ARGB(0,0,0,0), textRect, m_MultiLineStr
				, Unit::kAlignCenterMiddle);		
		}
	}

	void Balloon::OnInputEvent( InputEventArgs & e )
	{
		Super::OnInputEvent(e);
	}

	void Balloon::OnTextChanged( EventArgs & e )
	{
		Super::OnTextChanged(e);
		if(m_AutoWrap)
			Control::SplitString(m_Text, m_MultiLineStr, m_MaxWidth-m_TextPadding.x-m_TextPadding.z, GetFont());
		else
			m_MultiLineStr = m_Text;
	}

	void Balloon::Show( const Core::Rectangle& globalBaseRect, F32 timer, bool bOnTop /*= true*/ )
	{
		//Calculate actual size
		Core::Rectangle tempRect = Core::Rectangle(0,0,0,0);
		Core::Rectangle textRect = GetFont()->MeasureString(tempRect, m_MultiLineStr, -1, Unit::kAlignLeftTop);
		textRect.Shrink(-m_TextPadding);
		Vector2 aSize = textRect.GetExtent();
		aSize.x = Core::Ceil(aSize.x);
		aSize.y = Core::Ceil(aSize.y);
		SetSize(aSize);

		UpdateLocation(globalBaseRect, bOnTop);
		
// 		if(!m_Started)
// 		{
			SetParent(gGame->guiSys);
			m_Timer = timer;
			m_Started = true;
			m_Showing = true;
			m_HoverPower = 0.f;
			
			if(gGame)
			{
				if(gGame->guiSys)
				{
					gGame->guiSys->PlayAudio(GuiSystem::kUIA_BALLOON);
				}
			}
// 		}
	}

	void Balloon::Cancel()
	{
		m_Timer = 0.0f;
	}

	void Balloon::Terminate()
	{
		SetParent(NullPtr);
		m_Owner = NullPtr;
	}

	void Balloon::UpdateLocation(const Core::Rectangle& globalBaseRect, bool bOnTop /* = true */)
	{
		Vector2 aPos;
		F32 leftBound = m_TextPadding.x;
		F32 rightBound = m_TextPadding.z;
		F32 CenterTollerance = m_ArrowWidth/2;
		m_ArrowCenter = m_Size.x/2;

		Core::Vector2 screenSize = gGame->guiSys->GetSize();

		Vector2 basePointTop = globalBaseRect.GetCenter()-Vector2(0, globalBaseRect.GetExtent().y/2);
		Vector2 basePointBottom = globalBaseRect.GetCenter()+Vector2(0, globalBaseRect.GetExtent().y/2);
		m_AboveBase = bOnTop;
		if(bOnTop)
		{
			//Try to put it on top
			if(basePointTop.y-m_Size.y<0)
				m_AboveBase = false;
		}
		else
		{
			if(basePointBottom.y+m_Size.y>screenSize.y)
				m_AboveBase = true;
		}
		aPos.y = m_AboveBase?(basePointTop.y-m_Size.y):(basePointBottom.y);
		aPos.x = basePointTop.x-m_Size.x/2;

		//Test the right boundary
		if(basePointTop.x+m_Size.x/2>screenSize.x)
		{
			F32 difference = basePointTop.x+m_Size.x/2-screenSize.x;
			if(difference<m_Size.x/2-CenterTollerance-rightBound)
			{
				aPos.x-=difference;
				m_ArrowCenter+=difference;
			}
			else
			{
				aPos.x-=m_Size.x/2-CenterTollerance-rightBound;
				m_ArrowCenter+=m_Size.x/2-CenterTollerance-rightBound;
			}
		}

		//Test the left boundary
		if(basePointTop.x-m_Size.x/2<0)
		{
			F32 difference = m_Size.x/2 - basePointTop.x;
			if(difference<m_Size.x/2-CenterTollerance-leftBound)
			{
				aPos.x+=difference;  //Should be 0
				m_ArrowCenter-=difference;
			}
			else
			{
				aPos.x+=m_Size.x/2-CenterTollerance-rightBound;
				m_ArrowCenter-=m_Size.x/2-CenterTollerance-rightBound;
			}
		}
		aPos.x = Core::Floor(aPos.x+0.5f);
		aPos.y = Core::Floor(aPos.y+0.5f);
		SetLocation(aPos);
	}

	bool Balloon::CheckVisibility()
	{
		if(m_Owner)
			return m_Owner->GetVisibility();
		else
			return false;
	}
}