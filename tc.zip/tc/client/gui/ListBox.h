namespace Gui
{
	/// base class of ui elements
	class ListBox : public ScrollableControl
	{
		DECLARE_PDE_OBJECT(ListBox, ScrollableControl)

	public:
		ListBox();
		~ListBox();

	public:
		static const S32 INDEX_NONE = -1;

		struct ListItem
		{
			ListItem()
				: Name()
				, IsSelect(false)
			{
			}

			ListItem(const Core::String & name)
				: Name(name)
				, IsSelect(false)
			{
			}

			friend bool operator == (const ListItem & l, const ListItem & r)
			{
				return l.Name == r.Name;
			}

			Core::String	Name;
			bool		IsSelect: 1;
		};
	public:
		DECLARE_PDE_EVENT(EventListClick,		Client::InputEventArgs);
		DECLARE_PDE_EVENT(EventSelectChange,	EventArgs);
		DECLARE_PDE_EVENT(EventDelete,			Client::InputEventArgs);
		DECLARE_PDE_EVENT(EventItemChange,		EventArgs);

	public:
		DECLARE_PDE_ATTRIBUTE_RW	(SelectIndex,		S32);
		DECLARE_PDE_ATTRIBUTE_RW	(BorderVisible,		bool);

		DECLARE_PDE_ATTRIBUTE_R		(ItemCount,			U32);

		OVERRIDE_PDE_ATTRIBUTE_R	(DisplayPadding,	Vector4);

	public:
		virtual void OnCreate();

		virtual void OnFrameUpdate(EventArgs & e);

		virtual void OnLayout(EventArgs & e);

		virtual void OnPaint(PaintEventArgs & e);

        virtual void OnInputEvent(Client::InputEventArgs & e);

		virtual void OnListClick(Client::InputEventArgs & e);

		virtual void OnItemSelectedChanged(EventArgs & e);

		virtual void OnDelete(Client::InputEventArgs & e);

		virtual void OnItemChange(EventArgs & e);

	public:
		void ItemChange();

		void ToggleSelect(U32 index);

		bool IsSelect(U32 index);

		void SetSelect(U32 index, bool flag = true);

		void ReleaseAllSelect();

        void AddItem(const Core::String & item);

		void DeleteItem(U32 index);

		void DeleteAll();

		void DeleteSelectItem();

		Core::String GetItemText(U32 index);

		void SetItemText(U32 index, const Core::String & text);

		F32 GetDisplayWidth();

		F32 GetStringWidth(const Core::String & text);

	private:
		S32						m_SelectIndex;
		U32						m_ItemCount;
		U32						m_LastIndex;
		bool					m_BorderVisible	: 1;
		bool					m_MultiSelect	: 1;
		bool					m_Selecting		: 1;
		Core::Rectangle			m_SelectRect;

		Core::Array<ListItem>		m_aItems;
	};
}

namespace Gui
{
	class ListBoxSkin : public ScrollableControlSkin
	{
	public:
		ListBoxSkin()
		{}

	public:

	private:
	};
}