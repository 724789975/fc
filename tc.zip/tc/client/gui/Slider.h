namespace Gui
{
	class SliderSkin : public ControlSkin
	{
	public:
		SliderSkin()
		{}

	public:
		INLINE_PDE_ATTRIBUTE_RW(ThumbNormalImage,		tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(ThumbHoverImage,		tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(ThumbDownImage,			tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(ThumbDisabledImage,		tempc_ptr(Image));

	private:
		sharedc_ptr(Image) m_ThumbNormalImage;
		sharedc_ptr(Image) m_ThumbHoverImage;
		sharedc_ptr(Image) m_ThumbDownImage;
		sharedc_ptr(Image) m_ThumbDisabledImage;
	};
}

namespace Gui
{
	class Slider : public Control
	{
		DECLARE_PDE_OBJECT(Slider,Control)

	public:
		enum SliderType
		{
			kNormal = 0,
			kRGB	= 1,
			kHSV	= 2,
		};

		enum Direction
		{
			kHorizontal,
			kVertical,
		};

	public:
		DECLARE_PDE_EVENT(EventValueChange,			Core::EventArgs);
		DECLARE_PDE_EVENT(EventValueChangedEnd,		Core::ValueChangeEventArgs);

	public:
		DECLARE_PDE_ATTRIBUTE_R	(ThumbPos,			F32);
		DECLARE_PDE_ATTRIBUTE_RW(Type,				SliderType);
		DECLARE_PDE_ATTRIBUTE_RW(Shape,				Direction);
		DECLARE_PDE_ATTRIBUTE_RW(Index,				U32);
		DECLARE_PDE_ATTRIBUTE_RW(Value,				Core::Vector4);
		DECLARE_PDE_ATTRIBUTE_RW(ThumbSize,			Core::Vector2);
		DECLARE_PDE_ATTRIBUTE_RW(CurValue,			F32);
		DECLARE_PDE_ATTRIBUTE_RW(MinValue,			F32);
		DECLARE_PDE_ATTRIBUTE_RW(MaxValue,			F32);
		DECLARE_PDE_ATTRIBUTE_RW(Minimum,			U32);
		DECLARE_PDE_ATTRIBUTE_RW(Maximum,			U32);
		DECLARE_PDE_ATTRIBUTE_RW(LargeChange,		U32);
		DECLARE_PDE_ATTRIBUTE_RW(IsInt,				bool);
		DECLARE_PDE_ATTRIBUTE_R (StepValue,			F32);

		OVERRIDE_PDE_ATTRIBUTE_R(DefaultSize,		Core::Vector2) { return Core::Vector2(120, 20); }

	public:
		// constructor.
		Slider();

		// destructor.
		~Slider();

		/// on paint
		virtual void OnPaint(PaintEventArgs & e);

		/// on input event
		virtual	void OnInputEvent(Client::InputEventArgs &e);

		/// on key event
		virtual void OnKeyEvent(Client::InputEventArgs &e);

		/// on layout
		virtual void OnLayout(Core::EventArgs & e);

		/// on value change
		virtual void OnValueChange(Core::EventArgs & e);

		/// on value changed end
		virtual void OnValueChangedEnd(Core::ValueChangeEventArgs & e);

	private:
		/// change cur value
		void ChangeCurValue(F32 value);

		/// change value
		void ChangeValueByMouse(Core::Vector2 pos);

		/// changed to mark index
		bool ChangeToMarkIndex(U32 markIndex);

		/// get current mark index
		U32 CurMarkIndex();

	private:
		Core::ARGB		m_BackColor;

		F32				m_ThumbPos;
		Core::Vector2	m_ThumbSize;

		F32             m_CurValue;
		F32             m_MinValue;
		F32             m_MaxValue;

		U32				m_Minimum;
		U32				m_Maximum;
		U32				m_LargeChange;

		bool			m_Moving : 1;
		bool			m_IsInt : 1;
		bool			m_ThumbPointed : 1;

		SliderType		m_Type;
		Direction		m_Shape;
		U32				m_Index;
		Core::Vector4	m_Value;

		F32				m_OldValue;
	};
}