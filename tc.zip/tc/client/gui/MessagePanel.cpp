#include "pch.h"

using namespace Core;
using namespace Client;
using namespace Gui;

DEFINE_PDE_TYPE_CLASS(MessagePanel)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Control);
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_METHOD(AddLineNew);
		ADD_PDE_METHOD(ClearLines);
		ADD_PDE_METHOD(DirtyLines);
		ADD_PDE_METHOD(ScrollToEnd);
		ADD_PDE_METHOD(EventSizeChanged);

		ADD_PDE_PROPERTY_RW(CursorVisible);
		ADD_PDE_PROPERTY_RW(ButtonHeight);
		ADD_PDE_PROPERTY_RW(ButHeight);
		ADD_PDE_PROPERTY_RW(VisibleLine);
		ADD_PDE_PROPERTY_RW(ScrollBarWidth);
		ADD_PDE_PROPERTY_RW(MaxAllLine);
		ADD_PDE_PROPERTY_R (Click_Name);

		ADD_PDE_EVENT(EventClick_Name);
	}
};

REGISTER_PDE_TYPE(MessagePanel);

namespace Gui
{

	PDE_ATTRIBUTE_GETTER(MessagePanel, ScrollBarWidth, U32)
	{
		return m_ScrollBarWidth;
	}

	PDE_ATTRIBUTE_SETTER(MessagePanel, ScrollBarWidth, U32)
	{
		if (m_ScrollBarWidth != value)
		{
			m_ScrollBarWidth = value;
		}
	}
	
	PDE_ATTRIBUTE_GETTER(MessagePanel, MaxAllLine, U32)
	{
		return m_MaxAllLine;
	}

	PDE_ATTRIBUTE_SETTER(MessagePanel, MaxAllLine, U32)
	{
		if (m_MaxAllLine != value)
		{
			m_MaxAllLine = value;
		}
	}

	PDE_ATTRIBUTE_GETTER(MessagePanel, LeftGap, const U32)
	{
		return m_LeftGap;
	}

	PDE_ATTRIBUTE_GETTER(MessagePanel, VisibleLine,U32)
	{
		return m_VisibleLine;
	}

	PDE_ATTRIBUTE_SETTER(MessagePanel, VisibleLine, U32)
	{
		if (m_VisibleLine != value)
		{
			m_VisibleLine = value;
			Invalid();
		}
	}
	
	PDE_ATTRIBUTE_GETTER(MessagePanel, CursorVisible,bool)
	{
		return m_CursorVisible;
	}

	PDE_ATTRIBUTE_SETTER(MessagePanel, CursorVisible, bool)
	{
		if (m_CursorVisible != value)
		{
			m_CursorVisible = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(MessagePanel, ButtonHeight, U32)
	{
		return m_ButtonHeight;
	}

	PDE_ATTRIBUTE_SETTER(MessagePanel, ButtonHeight, U32)
	{
		if (m_ButtonHeight != value)
		{
			m_ButtonHeight = value;
			if(m_ScrollBar)
				m_ScrollBar->SetButtonSize(value);
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(MessagePanel, ButHeight, U32)
	{
		return m_ButHeight;
	}

	PDE_ATTRIBUTE_SETTER(MessagePanel, ButHeight, U32)
	{
		if (m_ButHeight != value)
		{
			m_ButHeight = value;
			if(m_Button_down)
			{
				m_Button_down->SetSize(Vector2(m_Button_down->GetSize().x,value));
			}
			if(m_Button_up)
			{			
				m_Button_up->SetSize(Vector2(m_Button_up->GetSize().x,value));
			}
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(MessagePanel, ClickedName, Core::String)
	{
		return m_ClickedName;
	}
	
	PDE_ATTRIBUTE_GETTER(MessagePanel, Click_Name, Core::String)
	{
		return m_Click_Name;
	}

	PDE_ATTRIBUTE_SETTER(MessagePanel, ChatWindow, weakc_ptr(ChatWindow))
	{
		m_ChatWindow = value;
	}

	MessagePanel::MessagePanel(void)
		: m_ScrollBarWidth(14)
		, m_LeftGap(5)
		, m_ButtonHeight(16)
		, m_LineHeight(0)
		, m_VisibleLine(5)
		, m_PointedLine(0)
		, m_CursorVisible(false)
		, m_CursorTime(0)
		, m_Selecting(false)
		, m_SelectedLine(-1)
		, m_SelectedStart(0)
		, m_SelectedEnd(0)
		, m_Channel(ChatWindow::kAll)
		, m_AllLinesCount(0)
		, m_MaxAllLine(512)
		, m_ReSet(false)
	{

	}

	MessagePanel::~MessagePanel(void)
	{

	}

	void MessagePanel::OnCreate()
	{
		Super::OnCreate();
		SetBackgroundColor(ARGB(0,0,0,0));
		m_ScrollBar = ptr_new ScrollBar;
		m_ScrollBar->SetLocation(Vector2(2 ,2));
		m_ScrollBar->SetMinimum(0);
		m_ScrollBar->SetSmallChange(1);
		m_ScrollBar->SetLargeChange(3);

		m_Button_down = ptr_new Button;
		m_Button_down->SetVisible(false);
		m_Button_down->SetParent(ptr_static_cast<MessagePanel>(this));
		m_Button_down->EventClick.Subscribe(NewDelegate(&MessagePanel::OnButtonClick_down,ptr_static_cast<MessagePanel>(this)));
		m_Button_down->SetStyle("Gui.ChatToBottom_down");
		
		m_Button_up = ptr_new Button;
		m_Button_up->SetVisible(false);
		m_Button_up->SetParent(ptr_static_cast<MessagePanel>(this));
		m_Button_up->EventClick.Subscribe(NewDelegate(&MessagePanel::OnButtonClick_up,ptr_static_cast<MessagePanel>(this)));
		m_Button_up->SetStyle("Gui.ChatToBottom_up");

		m_Icon = ptr_new Gui::Icon("skinD/skinD_lobby_icon01_bigSpeaker.tga", Core::Vector4::kZero);
	}

	void MessagePanel::OnLayout(EventArgs & e)
	{
		m_LineHeight = static_cast<U32>(m_Size.y/m_VisibleLine);
		m_ScrollBar->SetSize(Vector2(m_ScrollBarWidth,m_Size.y - 2*m_ButHeight - 6));
		m_ScrollBar->SetLocation(Vector2(m_Size.x - m_ScrollBar->GetSize().x - 2 ,5 + m_ButHeight));
		m_Button_down->SetSize(Vector2(m_ScrollBarWidth,m_ButHeight));
		m_Button_down->SetLocation(Vector2(m_Size.x - m_ScrollBar->GetSize().x - 2,m_Size.y - m_ButHeight));
		m_Button_up->SetSize(Vector2(m_ScrollBarWidth,m_ButHeight));
		m_Button_up->SetLocation(Vector2(m_Size.x - m_ScrollBar->GetSize().x - 2 ,5));
	}

	void MessagePanel::OnPaint(PaintEventArgs & e)
	{
		Control::OnPaint(e);
		if (m_ReSet)
		{
			Reset();
			m_SelectedEnd = m_SelectedStart;
			m_CursorVisible = false;
		}
		U32 count = m_ShowLines.Size();
		Core::Rectangle textRect;
		U32 line = 0;
		U32 firstLine = m_ScrollBar->GetValue();
		int i = 0;
		while (i < m_AllLines.GetCount())
		{
			if (m_AllLines[i].m_MouseCtr)
			{
				m_AllLines[i].m_MouseCtr->SetLocation(Core::Vector2(-100,-100));
			}
			i++;
		}
		for (U32 i = firstLine;i < firstLine + m_VisibleLine && i < count;i++)
		{
			textRect = Core::Rectangle::LeftTop(m_LeftGap + 2,line*m_LineHeight,m_Size.x - m_ScrollBarWidth,m_LineHeight);
			e.render->DrawString(GetFont(),m_ShowLines[i].Color,m_BackgroundColor,textRect,m_ShowLines[i].Text, Unit::kAlignLeftMiddle);
			if (m_ShowLines[i].m_MouseCtr)
			{
				DrawBtn(textRect,i);
			}
			if (m_SelectedLine == i)
			{
				m_SelectedLeftTop.y = line*m_LineHeight + 1;
				m_SelectedRightBottom.y = (line + 1)*m_LineHeight + 1;
				AlphaBlendMode blend = e.render->GetBlendMode();
				e.render->SetBlendMode(kInverseColor);
				if (m_CursorVisible)
				{
					e.render->SetTexture(NullPtr);
					Core::Rectangle cursorRect;
					if (m_SelectedStart <= m_SelectedEnd)
					{
						cursorRect = Core::Rectangle::RightBottom(m_SelectedRightBottom,Vector2(1,m_LineHeight));
					}
					else
					{
						cursorRect = Core::Rectangle::LeftTop(m_SelectedLeftTop,Vector2(1,m_LineHeight));
					}
					e.render->DrawRectangle(cursorRect, Core::Rectangle(0, 0, 1, 1), ARGB(255, 255, 255));
				}
				if (m_SelectedStart != m_SelectedEnd)
				{
					Core::Rectangle selectedRect(m_SelectedLeftTop,m_SelectedRightBottom);
					e.render->DrawRectangle(selectedRect,selectedRect,ARGB(255,255,255));
				}
				e.render->SetBlendMode(blend);
			}
			if (m_ShowLines[i].LinkStart > 0)
			{
				e.render->DrawLine2d(Vector2(m_ShowLines[i].LinkStart,(line + 1)*m_LineHeight),Vector2(m_ShowLines[i].LinkEnd,(line + 1)*m_LineHeight),m_ShowLines[i].Color);
				if (m_ShowLines[i].Index == ChatWindow::kBigSpeaker)
				{
					m_IconRect = Core::Rectangle::LeftTop(m_ScrollBarWidth + m_LeftGap,line*m_LineHeight - 4.f,m_LineHeight,m_LineHeight*1.4);
					m_Icon->Draw(e.render,m_IconRect,ARGB(255,255,255,255));
				}
			}

			line++;
		}

		RenderEventArgs args(e);

		if (count > m_VisibleLine)
		{
			m_ScrollBar->OnPaint(args, ptr_dynamic_cast<ScrollableControlSkin>(GetSkin()));
		}
	}

	void MessagePanel::OnComplementaryDraw(PaintEventArgs & e, F32 opacity)
	{
		U32 count = m_ShowLines.Size();
		Core::Rectangle textRect;
		U32 line = 0;

		//Change render target
		Matrix44 orgWorld = e.render->GetWorld();
		Matrix44 orgView = e.render->GetView();
		Matrix44 orgProj = e.render->GetProjection();
		Core::Rectangle orgScissor = e.render->GetScissorRect();
		IDirect3DSurface9* pOrgTarget = NULL;
		gDx9Device->GetRenderTarget(0, &pOrgTarget);

		if (e.render->BeginDraw(gGame->dx9->render_target, NULL))
		{
			Core::Vector2 screenPos = ClientToGlobalScreen(Core::Vector2::kZero);
			Core::Matrix44 worldMat;
			worldMat.SetIdentity();
			worldMat.Translate(screenPos);
			e.render->SetWorld(worldMat);
			e.render->SetView(gGame->guiSys->GetViewMatrix());
			e.render->SetProjection(gGame->guiSys->GetProjMatrix());
			Core::Rectangle newScissor(Vector2::kZero, GetSize());
			e.render->SetScissorRectWithWorldMatrix(newScissor);

			U32 firstLine = m_ScrollBar->GetValue();
			for (U32 i = firstLine;i < firstLine + m_VisibleLine && i < count;i++)
			{
				textRect = Core::Rectangle::LeftTop(m_ScrollBarWidth + m_LeftGap,line*m_LineHeight,m_Size.x,m_LineHeight);
				ARGB lineColor = m_ShowLines[i].Color;
				lineColor.a = lineColor.a - (U8)(lineColor.a*Core::Clamp(opacity, 0.f, 1.f));
				e.render->DrawStringShadow(GetFont(),lineColor, ARGB(lineColor.a,0,0,0),m_BackgroundColor,textRect,m_ShowLines[i].Text, Unit::kAlignLeftMiddle);
				if (m_ShowLines[i].LinkStart > 0)
				{
					e.render->DrawLine2d(Vector2(m_ShowLines[i].LinkStart,(line + 1)*m_LineHeight),Vector2(m_ShowLines[i].LinkEnd,(line + 1)*m_LineHeight),lineColor);
				}

				line++;
			}

			e.render->EndDraw();
		}

		//Restore render target
		e.render->SetWorld(orgWorld);
		e.render->SetView(orgView);
		e.render->SetProjection(orgProj);
		e.render->SetScissorRect(orgScissor);
		gDx9Device->SetRenderTarget(0, pOrgTarget);
		pOrgTarget->Release();
		//End
	}

	void MessagePanel::OnInputEvent(InputEventArgs & e)
	{
		m_ScrollBar->OnInputEvent(ptr_static_cast<Control>(this), e);
		if (e.IsMouseEvent())
		{
			tempc_ptr(Font) font = GetFont();
			Vector2 localPos = ScreenToClient(e.CursorPosition);
			U32 currentLine = localPos.y/m_LineHeight;
			U32 firstLine = m_ScrollBar->GetValue();
			m_PointedLine = firstLine + currentLine;

			switch (e.Type)
			{
			case InputEventArgs::kMouseDown:
				{
					SetCapture(true);
					Core::Rectangle selectedRect = GetDisplayRect().Shrink(m_ScrollBarWidth,0,0,0);
					if (selectedRect.IsPointInside(localPos) && m_PointedLine < m_ShowLines.Size())
					{
						m_Selecting = true;
						m_SelectedLine = m_PointedLine;
						GetFont()->XtoCP(m_ShowLines[m_PointedLine].Text,Vector2(localPos.x - m_LeftGap,0),m_SelectedStart);
#ifdef USE_UTF8
						while (!IsUTF8LeadByte(m_ShowLines[m_SelectedLine].Text[m_SelectedStart]))
						{
							m_SelectedStart--;
						}
#else
						if (IsDBCSLeadByteEx(936,m_ShowLines[m_SelectedLine].Text[m_SelectedStart]))
						{
							m_SelectedStart--;
						}
#endif
						m_SelectedEnd = m_SelectedStart;
						font->CPtoX(m_ShowLines[m_SelectedLine].Text,m_SelectedStart,m_SelectedLeftTop);
						font->CPtoX(m_ShowLines[m_SelectedLine].Text,m_SelectedEnd,m_SelectedRightBottom);
						m_SelectedLeftTop.x += m_LeftGap ;
						m_SelectedRightBottom.x += m_LeftGap + 2;
						Invalid();
					}
					e.Handled = true;
				}
				break;
			case InputEventArgs::kMouseWheel:
				{
					F32 value = m_ScrollBar->GetValue() - m_ScrollBar->GetSmallChange() * e.Value;
					value = Clamp(value, m_ScrollBar->GetMinimum(), m_ScrollBar->GetMaximum());
					m_ScrollBar->SetValue(value);
					Invalid();
					e.Handled = true;
				}
				break;
			case InputEventArgs::kMouseMove:
				{
					m_CursorTime = Core::Task::GetTotalTime();
					if (m_Selecting && m_SelectedLine > -1)
					{
						font->XtoCP(m_ShowLines[m_SelectedLine].Text,Vector2(localPos.x - m_ScrollBarWidth - m_LeftGap,0),m_SelectedEnd);
#ifdef USE_UTF8
						while (!IsUTF8LeadByte(m_ShowLines[m_SelectedLine].Text[m_SelectedEnd]))
						{
							m_SelectedEnd--;
						}
#else
						if (IsDBCSLeadByteEx(936,m_ShowLines[m_SelectedLine].Text[m_SelectedEnd]))
						{
							m_SelectedEnd--;
						}
#endif
						if (m_SelectedStart <= m_SelectedEnd)
						{
							font->CPtoX(m_ShowLines[m_SelectedLine].Text,m_SelectedStart,m_SelectedLeftTop);
							font->CPtoX(m_ShowLines[m_SelectedLine].Text,m_SelectedEnd,m_SelectedRightBottom);
						}
						else
						{
							font->CPtoX(m_ShowLines[m_SelectedLine].Text,m_SelectedEnd,m_SelectedLeftTop);
							font->CPtoX(m_ShowLines[m_SelectedLine].Text,m_SelectedStart,m_SelectedRightBottom);
						}
						m_SelectedLeftTop.x += 2 + m_LeftGap;
						m_SelectedRightBottom.x += 2 + m_LeftGap;

					}
					if (m_PointedLine < m_ShowLines.Size())
					{
						if (m_ShowLines[m_PointedLine].LinkStart > 0 && localPos.x > m_ShowLines[m_PointedLine].LinkStart && localPos.x < m_ShowLines[m_PointedLine].LinkEnd)
						{
							SetCursorShape(Screen::kCursorHand);
						}
					}
					Invalid();
					e.Handled = true;
				}
				break;
			case InputEventArgs::kMouseUp:
				{
					SetCapture(false);

					m_Selecting = false;

					if (m_PointedLine < m_ShowLines.Size())
					{
						if (m_ShowLines[m_PointedLine].LinkStart > 0 && localPos.x > m_ShowLines[m_PointedLine].LinkStart && localPos.x < m_ShowLines[m_PointedLine].LinkEnd)
						{

							m_ClickedName = m_ShowLines[firstLine + currentLine].LinkContent;
							if (MC_LEFT_BUTTON == e.Code)
							{
								OnLinkClick(e);
							}
							if(MC_RIGHT_BUTTON == e.Code)
							{
								OnLinkRightClick(e);
							}

						}
					}
					e.Handled = true;
				}
				break;
			}
		}
		if (e.IsKeyEvent())
		{
			OnKeyEvent(e);
		}

		if (!e.Handled)
		{
			Control::OnInputEvent(e);
		}
	}

	void MessagePanel::OnKeyEvent(InputEventArgs & e)
	{
		if (e.Type == InputEventArgs::kKeyDown)
		{
			switch (e.Code)
			{
			case KC_C:
				{
					if (e.ControlKeyDown)
					{
						CopyText();
					}
				}
				e.Handled = true;
			default:
				break;
			}
		}
	}

	void MessagePanel::OnLinkClick(Client::InputEventArgs &e)
	{
		sharedc_ptr(ChatWindow) owner = m_ChatWindow;
		if (owner)
		{
			CStrBuf<256> buf;
			buf.format("To[%s]:",m_ClickedName);
			owner->SetChannel(ChatWindow::kWhisperColor,m_ClickedName,buf);
		}
	}

	void MessagePanel::OnLinkRightClick(Client::InputEventArgs &e)
	{
		sharedc_ptr(ChatWindow) owner = m_ChatWindow;
		if (owner)
		{
			Vector2 menuPos = ClientToGlobalScreen(ScreenToClient(e.CursorPosition));
			owner->m_PopupMenu->SetLocation(menuPos);
			owner->m_PopupMenu->Open();
		}
	}

	void MessagePanel::OnFrameUpdate(EventArgs & e)
	{
		m_ScrollBar->OnFrameUpdate(e);
		bool showCursor = false;

		if (GetFocused())
			showCursor = GetFocused() && ((static_cast<U32>((Core::Task::GetTotalTime() - m_CursorTime) * 2) & 1) == 0);

		if (m_CursorVisible != showCursor)
		{
			m_CursorVisible = showCursor;
			Invalid();
		}
	}

	void MessagePanel::OnMouseLeave(InputEventArgs & e)
	{
		m_Selecting = false;
	}

	void MessagePanel::AddLine(const ChatWindow::Line & line)
	{
		m_AllLines.PushBack(line);
		m_AllLinesCount++;
		if (m_AllLinesCount > m_MaxAllLine)
		{
			if (m_AllLines[0].m_Button)
				m_AllLines[0].m_Button->SetParent(NullPtr);
			if (m_AllLines[0].m_MouseCtr)
				m_AllLines[0].m_MouseCtr->SetParent(NullPtr);
			m_AllLines.RemoveAt(0);
			m_AllLinesCount--;
		}
	}

	void MessagePanel::AddLineParent(const ChatWindow::Line & line)
	{
		m_AllLines_Parent.PushBack(line);
		if (m_AllLinesCount > m_MaxAllLine - 1)
		{
			m_AllLines_Parent.RemoveAt(0);
		}
	}

	void MessagePanel::AddLineNew(const Core::String &string,uint type)
	{
		ChatWindow::Line line;
		line.Text = string;
		line.type = type;
		switch (type)
		{
		case Sever:
			{
				line.Color = ChatWindow::kSysColor;
				line.Index = ChatWindow::kChannel;
			}
			break;
		case Whisper:
			{
				line.Color = ChatWindow::kWhisperColor;
				line.Index = ChatWindow::kChannel;
			}
			break;
		default:
			break;
		}
		AddLineParent(line);
		LinePart(line);
	}

	void MessagePanel::LinePart(ChatWindow::Line & line)
	{
		if (SplitString(line.Text,line.Text,(m_Size.x - m_ScrollBarWidth - 10),GetFont()) > 1)
		{
			ChatWindow::Line addLine = line;
			CRefStr & refStr = line.Text.RefStr(0);
			S32 cp = refStr.find('\n');
			U32 count = 1;
			if (line.type == Whisper)
			{
				sharedc_ptr(MouseControl) MouseCtr = NullPtr;
				sharedc_ptr(Button) Btn = NullPtr;
				MouseCtr = ptr_new(MouseControl);
				MouseCtr->SetParent(ptr_static_cast<MessagePanel>(this));
				MouseCtr->SetMouseType(1);
				Btn = ptr_new(Button);
				Btn->SetParent(MouseCtr);
				Btn->EventClick.Subscribe(NewDelegate(&MessagePanel::OnWhisper_ButtonClick,ptr_static_cast<MessagePanel>(this)));
				Btn->SetBackgroundColor(Core::ARGB(0,255,255,255));
				Btn->SetTextColor(Core::ARGB(0,255,255,255));
				Btn->SetHighlightTextColor(Core::ARGB(0,255,255,255));
				MouseCtr->SetBackgroundColor(Core::ARGB(0,255,255,255));
				addLine.m_Button = Btn;
				addLine.m_MouseCtr = MouseCtr;
			}
			while(cp > 0)
			{
				addLine.Text.RefStr(0).copy(refStr,0,cp);
				refStr.remove(0,cp + 1);
				cp = refStr.find('\n');
				if (count > 1)
				{
					addLine.LinkStart = -1;
					AddLine(addLine);
				}
				else
				{
					AddLine(addLine);

				}
				addLine.m_Button = NullPtr;
				addLine.m_MouseCtr = NullPtr;
				count++;
			}
			addLine.Text = refStr;
			addLine.LinkStart = -1;
			AddLine(addLine);
		}
		else
		{
			if (line.type == Whisper)
			{
				sharedc_ptr(MouseControl) MouseCtr = NullPtr;
				sharedc_ptr(Button) Btn = NullPtr;
				MouseCtr = ptr_new(MouseControl);
				MouseCtr->SetParent(ptr_static_cast<MessagePanel>(this));
				MouseCtr->SetMouseType(1);
				Btn = ptr_new(Button);
				Btn->SetParent(MouseCtr);
				Btn->EventClick.Subscribe(NewDelegate(&MessagePanel::OnWhisper_ButtonClick,ptr_static_cast<MessagePanel>(this)));
				Btn->SetBackgroundColor(Core::ARGB(0,255,255,255));
				Btn->SetTextColor(Core::ARGB(0,255,255,255));
				Btn->SetHighlightTextColor(Core::ARGB(0,255,255,255));
				MouseCtr->SetBackgroundColor(Core::ARGB(0,255,255,255));
				line.m_Button = Btn;
				line.m_MouseCtr = MouseCtr;
			}
			AddLine(line);
		}
	}
	void MessagePanel::ClearLines()
	{
		int i =0;
		while (i < m_AllLines.GetCount())
		{
			if (m_AllLines[i].m_Button)
			{
				m_AllLines[i].m_Button->SetParent(NullPtr);
			}
			if (m_AllLines[i].m_MouseCtr)
			{
				m_AllLines[i].m_MouseCtr->SetParent(NullPtr);
			}
			i++;
		}
		m_AllLines.Clear();
		m_ShowLines.Clear();
		m_AllLines_Parent.Clear();
		m_AllLinesCount = 0;
		m_SelectedStart = m_SelectedEnd = 0;
		Invalid();
		m_Button_down->SetVisible(false);
		m_Button_up->SetVisible(false);
	}

	void MessagePanel::DirtyLines(bool scrollToBottom)
	{
		F32 oldValue = m_ScrollBar->GetValue();
		m_ShowLines.Clear();
		for (U32 i = 0;i < m_AllLinesCount;i++)
		{
			if (m_AllLines[i].Index&m_Channel)
			{
				m_ShowLines.PushBack(m_AllLines[i]);
			}
		}
		U32 count = m_ShowLines.Size();

		if (count > m_VisibleLine)
		{
			m_Button_down->SetVisible(true);
			m_Button_up->SetVisible(true);
			m_ScrollBar->SetMaximum(count - m_VisibleLine);
		}
		else
		{
			m_Button_down->SetVisible(false);
			m_Button_up->SetVisible(false);
			m_ScrollBar->SetMaximum(0);
		}
		if (scrollToBottom)
		{
			m_ScrollBar->SetValue(m_ScrollBar->GetMaximum());
		}
		else
		{
			m_ScrollBar->SetValue(oldValue);
		}
		Invalid();
	}

	void MessagePanel::OnButtonClick_down(by_ptr(void) sender, InputEventArgs & e)
	{
		m_ScrollBar->SetValue(m_ScrollBar->GetMaximum());
	}
	
	void MessagePanel::OnButtonClick_up(by_ptr(void) sender, InputEventArgs & e)
	{
		m_ScrollBar->SetValue(0);
	}

	void MessagePanel::OnWhisper_ButtonClick(by_ptr(void) sender, InputEventArgs & e)
	{
		tempc_ptr(Button) res = ptr_static_cast<Button>(sender);
		m_Click_Name = res->GetText();
		EventClick_Name.Fire(ptr_static_cast<Self>(this),(Core::EventArgs &)NullPtr);
	}

	void MessagePanel::CopyText()
	{
		if (m_SelectedLine > -1)
		{
			if (OpenClipboard(NULL))
			{
				size_t start = Clamp(m_SelectedStart,0,m_ShowLines[m_SelectedLine].Text.Length());
				size_t end = Clamp(m_SelectedEnd,0,m_ShowLines[m_SelectedLine].Text.Length());
				if (end < start)
				{
					Swap(start,end);
				}
				size_t size = end - start;

				if(size > 0)
				{
					EmptyClipboard();

					// Allocate a global memory object for the text. 
					HGLOBAL hglbCopy = GlobalAlloc(GMEM_MOVEABLE, (size + 1) * sizeof(CHAR));
					if (hglbCopy) 
					{ 
						CHAR* lptstrCopy = (CHAR*)GlobalLock(hglbCopy); 
						memcpy(lptstrCopy, m_ShowLines[m_SelectedLine].Text.Str() + start, size);
						lptstrCopy[ size ] = 0;
						GlobalUnlock(hglbCopy);
						SetClipboardData(CF_TEXT, hglbCopy);
					}
				}
				CloseClipboard();
			}
		}
	}

	void MessagePanel::DrawBtn(Core::Rectangle rect,int i)
	{
		CRefStr & refStr = m_ShowLines[i].Text.RefStr(0);
		S32 c = refStr.find(']');
		Core::String str = m_ShowLines[i].Text;
		str.RefStr(0).copy(refStr,0,c + 1);
		Core::Rectangle tempRect = Core::Rectangle(0,0,0,0);
		Core::Vector2 o = GetFont()->MeasureString(tempRect, str, -1, Unit::kAlignLeftMiddle).GetExtent();
		str.RefStr(0).copy(refStr,1,c - 1);
		m_ShowLines[i].m_Button->SetSize(o);
		m_ShowLines[i].m_Button->SetText(str.Str());
		m_ShowLines[i].m_MouseCtr->SetLocation(rect.Min + Core::Vector2(0,2));
		m_ShowLines[i].m_MouseCtr->SetSize(o);
	}

	void MessagePanel::ScrollToEnd()
	{
		m_ScrollBar->SetValue(m_ScrollBar->GetMaximum());
	}

	void MessagePanel::EventSizeChanged()
	{
		m_ReSet = true;
	}

	void MessagePanel::Reset()
	{
		uint n = m_AllLines_Parent.GetCount();
		int i =0;
		while (i < m_AllLines.GetCount())
		{
			if (m_AllLines[i].m_Button)
			{
				m_AllLines[i].m_Button->SetParent(NullPtr);
			}
			if (m_AllLines[i].m_MouseCtr)
			{
				m_AllLines[i].m_MouseCtr->SetParent(NullPtr);
			}
			i++;
		}
		m_AllLines.Clear();
		m_AllLinesCount = 0;
		ChatWindow::Line line;
		for (uint i = 0 ;i < n ; i++)
		{
			line = m_AllLines_Parent.GetAt(i);
			LinePart(line);
		}
		DirtyLines();
		m_ReSet = false;
	}
}

