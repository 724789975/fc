#include "pch.h"

using namespace Core;
using namespace Client;
using namespace Gui;

//--------------------------------------------------------------------------------------
// type info
//--------------------------------------------------------------------------------------
DEFINE_PDE_TYPE_CLASS(Label)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Control);
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_EVENT(EventClose);

		ADD_PDE_PROPERTY_RW(TextPadding);
		ADD_PDE_PROPERTY_RW(MoveLocation);
		ADD_PDE_PROPERTY_RW(NormLocation);
		ADD_PDE_PROPERTY_RW(TextAlign);
		ADD_PDE_PROPERTY_RW(Icon);
		ADD_PDE_PROPERTY_RW(AutoWrap);
		ADD_PDE_PROPERTY_RW(AutoFontSize);
		ADD_PDE_PROPERTY_RW(AutoEllipsis);
		ADD_PDE_PROPERTY_RW(UseTimer);
		ADD_PDE_PROPERTY_RW(MoveWheelTime);
		ADD_PDE_PROPERTY_RW(DisplayTime);
		ADD_PDE_METHOD(Show);
	}
};

REGISTER_PDE_TYPE(Label);

namespace Gui
{
	Label::Label()
		: m_TextAlign(Client::Unit::kAlignLeftMiddle)
		, m_AutoWrap(false)
		, m_UseTimer(false)
		, m_AutoFontSize(false)
		, m_AutoEllipsis(false)
		, m_TextPadding(2,0,2,0)
		, m_Timer(0)
		, m_DisplayTime(10)
		, m_MoveLocation(Core::Vector2(0,0))
		, m_MoveWheelTime(0.0f)
		, m_MoveTimer(0.0f)
		, m_NormLocation(Core::Vector2(0,0))
	{
	}

	Label::~Label()
	{
	}
}


//--------------------------------------------------------------------------------------
// Attribute
//--------------------------------------------------------------------------------------
namespace Gui
{
	PDE_ATTRIBUTE_GETTER(Label, DisplayTime,F32)
	{
		return m_DisplayTime;
	}


	PDE_ATTRIBUTE_SETTER(Label, DisplayTime,F32)
	{
		if (m_DisplayTime != value)
			m_DisplayTime = value;
	}
	
	PDE_ATTRIBUTE_GETTER(Label, MoveWheelTime,F64)
	{
		return m_MoveWheelTime;
	}


	PDE_ATTRIBUTE_SETTER(Label, MoveWheelTime,F64)
	{
		if (m_MoveWheelTime != value)
			m_MoveWheelTime = value;
	}

	PDE_ATTRIBUTE_GETTER(Label, TextAlign, Client::Unit::Align)
	{
		return m_TextAlign;
	}


	PDE_ATTRIBUTE_SETTER(Label, TextAlign, Client::Unit::Align)
	{
		if (m_TextAlign != value)
		{
			m_TextAlign = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(Label, Icon, tempc_ptr(Icon))
	{
		return m_Icon;
	}


	PDE_ATTRIBUTE_SETTER(Label, Icon, tempc_ptr(Icon))
	{
		if (m_Icon != value)
		{
			m_Icon = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(Label, TextPadding, Core::Vector4)
	{
		return m_TextPadding;
	}

	PDE_ATTRIBUTE_SETTER(Label, TextPadding, Core::Vector4)
	{
		if(m_TextPadding!=value)
		{
			m_TextPadding = value;
			EllipsisMyText();
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(Label, MoveLocation, Core::Vector2)
	{
		return m_MoveLocation;
	}

	PDE_ATTRIBUTE_SETTER(Label, MoveLocation, Core::Vector2)
	{
		if(m_MoveLocation!=value)
		{
			m_MoveLocation = value;
			Invalid();
		}
	}
	
	PDE_ATTRIBUTE_GETTER(Label, NormLocation, Core::Vector2)
	{
		return m_NormLocation;
	}

	PDE_ATTRIBUTE_SETTER(Label, NormLocation, Core::Vector2)
	{
		if(m_NormLocation!=value)
		{
			m_NormLocation = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(Label, AutoWrap, bool)
	{
		return m_AutoWrap;
	}

	PDE_ATTRIBUTE_SETTER(Label, AutoWrap, bool)
	{
		if(m_AutoWrap!=value)
		{
			m_AutoWrap = value;
			if(m_AutoWrap)
			{
				SetAutoSize(false);
// 				SetTextAlign(Client::Unit::kAlignLeftTop);
				ReWrapText();
				EllipsisMyText();
			}
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(Label, AutoFontSize, bool)
	{
		return m_AutoFontSize;
	}

	PDE_ATTRIBUTE_SETTER(Label, AutoFontSize, bool)
	{
		if(m_AutoFontSize!=value)
		{
			m_AutoFontSize = value;
			if(m_AutoFontSize)
			{
				m_ResultFontSize = GetFontSize();
				SetAutoSize(false);
				CalcFontSize();
			}
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(Label, AutoEllipsis, bool)
	{
		return m_AutoEllipsis;
	}

	PDE_ATTRIBUTE_SETTER(Label, AutoEllipsis, bool)
	{
		if(m_AutoEllipsis!=value)
		{
			m_AutoEllipsis = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(Label, UseTimer, bool)
	{
		return m_UseTimer;
	}

	PDE_ATTRIBUTE_SETTER(Label, UseTimer, bool)
	{
		if(m_UseTimer!=value)
		{
			m_UseTimer = value;
			Invalid();
		}
	}
}


//--------------------------------------------------------------------------------------
// Event
//--------------------------------------------------------------------------------------
namespace Gui
{
	/// on auto size
	void Label::OnAutoSize(AutoSizeEventArgs & e)
	{
		Core::Vector4 textPadding = GetTextPadding();
		e.clientRect.Max = Skin::MeasureIconText(GetIcon(), GetFont(), GetText()) + Vector2(textPadding.x+textPadding.z, textPadding.y+textPadding.w);

 		Super::OnAutoSize(e);
	}
	
	/// on text changed
	void Label::OnTextChanged(EventArgs & e)
	{
		ReWrapText();
		CalcFontSize();
		EllipsisMyText();
	}

	void Label::OnPaint(PaintEventArgs & e)
	{
		F64 timer = Task::GetTotalTime() - m_Timer;

		if(m_UseTimer && timer >m_DisplayTime)
		{
			Close();
		}
		if (m_MoveLocation.x != 0 || m_MoveLocation.y != 0)
		{
			m_MoveTimer += Task::GetFrameTime();
			if (m_MoveTimer > m_MoveWheelTime)
			{
				m_MoveTimer = 0.0f;
			}
		}
		if (m_MoveLocation.x != 0 && m_MoveWheelTime != 0 && m_MoveLocation.y == 0)
		{
			if (m_MoveTimer > m_MoveWheelTime/2 )
			{
				SetLocation(Core::Vector2(m_NormLocation.x + m_MoveLocation.x * (2 - 2*m_MoveTimer/m_MoveWheelTime) ,m_NormLocation.y));
			} 
			else
			{
				SetLocation(Core::Vector2(m_NormLocation.x + m_MoveLocation.x * (2*m_MoveTimer/m_MoveWheelTime) ,m_NormLocation.y));
			}
		}
		else if (m_MoveLocation.y != 0 && m_MoveWheelTime != 0 && m_MoveLocation.x == 0)
		{
			if (m_MoveTimer > m_MoveWheelTime/2 )
			{
				SetLocation(Core::Vector2(m_NormLocation.x ,m_NormLocation.y - m_MoveLocation.y * (2 - 2*m_MoveTimer/m_MoveWheelTime)));
			} 
			else
			{
				SetLocation(Core::Vector2(m_NormLocation.x ,m_NormLocation.y - m_MoveLocation.y * (2*m_MoveTimer/m_MoveWheelTime)));
			}
		}
		else if (m_MoveLocation.y != 0 && m_MoveWheelTime != 0 && m_MoveLocation.x != 0)
		{
			if (m_MoveTimer > m_MoveWheelTime/2 )
			{
				SetLocation(Core::Vector2(m_NormLocation.x + m_MoveLocation.x * (2 - 2*m_MoveTimer/m_MoveWheelTime) ,m_NormLocation.y - m_MoveLocation.y * (2 - 2*m_MoveTimer/m_MoveWheelTime)));
			} 
			else
			{
				SetLocation(Core::Vector2(m_NormLocation.x + m_MoveLocation.x * (2*m_MoveTimer/m_MoveWheelTime) ,m_NormLocation.y - m_MoveLocation.y * (2*m_MoveTimer/m_MoveWheelTime)));
			}
		}
		Super::OnPaint(e);
		Core::Vector4 textPadding = GetTextPadding();
		Core::Rectangle rect(Vector2(textPadding.x, textPadding.y), GetSize() - Vector2(textPadding.z, textPadding.w));

		if(m_AutoFontSize)
			Skin::DrawIconText(e.render, GetIcon(), GetAutoFont(), GetText(), rect, GetTextAlign(), ARGB(255, 255, 255, 255), GetTextColor());
		else
			Skin::DrawIconText(e.render, GetIcon(), GetFont(), m_AutoEllipsis?m_EllipsisStr:(m_AutoWrap?m_MultiLineStr:m_Text), rect, GetTextAlign(), ARGB(255, 255, 255, 255), GetTextColor());
	}

	void Label::OnInputEvent(InputEventArgs & e)
	{
		if (e.Type == InputEventArgs::kMouseEnter || e.Type == InputEventArgs::kMouseLeave)
			e.Handled = false;

		if (!e.Handled)
			Super::OnInputEvent(e);
	}

	void Label::OnSizeChanged( ResizeEventArgs & e )
	{
		Super::OnSizeChanged(e);
		ReWrapText();
		EllipsisMyText();
	}

	void Label::ReWrapText()
	{
		if(m_AutoWrap)
		{
			Core::Vector4 textPadding = GetTextPadding();
			Core::Rectangle rect(Vector2(textPadding.x, textPadding.y), GetSize() - Vector2(textPadding.z, textPadding.w));
			Control::SplitString(GetText(), m_MultiLineStr, rect, GetFont());	
		}
		DirtyLayout();
	}

	void Label::CalcFontSize()
	{
		if(m_AutoFontSize && !m_AutoWrap && m_Size.x>20)
		{
			m_ResultFontSize = GetFontSize();
			Core::Rectangle tempRect = Core::Rectangle(0,0,0,0);
			Vector2 o = GetFont()->MeasureString(tempRect, m_Text, -1, Unit::kAlignCenterMiddle).GetExtent();
			while(o.x>=GetSize().x-GetTextPadding().x-GetTextPadding().z && m_ResultFontSize>=8)
			{
				m_ResultFontSize -= 2;
				tempRect = Core::Rectangle(0,0,0,0);
				o = GetAutoFont()->MeasureString(tempRect, m_Text, -1, Unit::kAlignCenterMiddle).GetExtent();
			}
		}
		Invalid();
	}

	tempc_ptr(Client::Font) Label::GetAutoFont()
	{
		tempc_ptr(Client::Font) autoFont = NullPtr;
		if (gGame)
			autoFont = gRender->font_manager->GetFont(m_FontName, m_ResultFontSize, 0);

		return autoFont;
	}


	void Label::EllipsisMyText()
	{
		if(m_Hint.Length() != 0)
		{
			if(GetAutoSize())
			{
				m_EllipsisStr = m_AutoWrap?m_MultiLineStr:m_Text;
				m_Hint = "";
				Invalid();
			}
			else
			{
				Core::Vector4 textPadding = GetTextPadding();
				Core::Rectangle rect(Vector2(textPadding.x, textPadding.y), GetSize() - Vector2(textPadding.z, textPadding.w));
				int ePos = Control::EllipsisString(m_AutoWrap?m_MultiLineStr:m_Text, m_EllipsisStr, rect.GetExtent(), GetFont());
				if(ePos>=0)
				{
					m_Hint = m_Text;
				}
				else
				{
					m_Hint = String::kEmpty;
				}
				Invalid();
			}
		}
	}

	void Label::Show()
	{
		SetVisible(true);
		
		m_NormLocation = m_Location;
		m_MoveTimer = 0;
		m_Timer = Task::GetTotalTime();
	}

	void Label::Close()
	{
		SetVisible(false);
		m_Timer = 0;
		m_MoveTimer = 0;
		EventClose.Fire(ptr_static_cast<Label>(this),(Client::InputEventArgs &)NullPtr);
	}
}

