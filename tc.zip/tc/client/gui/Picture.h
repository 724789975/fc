namespace Gui
{
	class PictureSkin : public ControlSkin
	{
	public:
		INLINE_PDE_ATTRIBUTE_RW(HighlightFrame, tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(HoverFrame, tempc_ptr(Image));

	private:
		sharedc_ptr(Image)		m_HighlightFrame;
		sharedc_ptr(Image)		m_HoverFrame;
	};

	class ItemPictureSkin : public PictureSkin
	{
	public:
		INLINE_PDE_ATTRIBUTE_RW(EmptyFrame, tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(LockedImage, tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(PackAImage, tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(PackBImage, tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(PackCImage, tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(PackDImage, tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(PackEImage, tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(RepairImage, tempc_ptr(Image));

		INLINE_PDE_ATTRIBUTE_RW(TuneNoImage, tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(TuneYesImage, tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(TunedImage, tempc_ptr(Image));

		SIMPLE_PDE_ATTRIBUTE_RW(NameNormalColor, Core::ARGB);
		SIMPLE_PDE_ATTRIBUTE_RW(NameHighlightColor, Core::ARGB);
		SIMPLE_PDE_ATTRIBUTE_RW(LeftHighlightColor, Core::ARGB);
	private:
		sharedc_ptr(Image) m_EmptyFrame;

		sharedc_ptr(Image) m_LockedImage;
		sharedc_ptr(Image) m_PackAImage;
		sharedc_ptr(Image) m_PackBImage;
		sharedc_ptr(Image) m_PackCImage;
		sharedc_ptr(Image) m_PackDImage;
		sharedc_ptr(Image) m_PackEImage;
		sharedc_ptr(Image) m_RepairImage;

		sharedc_ptr(Image) m_TuneNoImage;
		sharedc_ptr(Image) m_TuneYesImage;
		sharedc_ptr(Image) m_TunedImage;
	};
}

namespace Gui
{
	/// base class of ui elements
	class  Picture : public Control
	{
		DECLARE_PDE_OBJECT(Picture, Control)

	public:
		DECLARE_PDE_EVENT(EventClick, InputEventArgs);

	public:				
		DECLARE_PDE_ATTRIBUTE_RW(VIPImage, tempc_ptr(Image));
		DECLARE_PDE_ATTRIBUTE_RW(ForeGroundImage, tempc_ptr(Image));
		DECLARE_PDE_ATTRIBUTE_RW(FrontImage, tempc_ptr(Image));
		DECLARE_PDE_ATTRIBUTE_RW(IsNewImage, tempc_ptr(Image));
		DECLARE_PDE_ATTRIBUTE_RW(KeepAspect, bool);
		DECLARE_PDE_ATTRIBUTE_RW(Expand, bool);
		DECLARE_PDE_ATTRIBUTE_R (DefaultSize,	Core::Vector2) { return Core::Vector2(20, 20); }
		DECLARE_PDE_ATTRIBUTE_RW(BeStatic, bool);
		DECLARE_PDE_ATTRIBUTE_RW(Highlighted, bool);
		DECLARE_PDE_ATTRIBUTE_RW(OriginalSize,bool);
	public:
		///constructor
		Picture();

		///destructor
		~Picture();

		/// on autosize
		virtual void OnAutoSize(AutoSizeEventArgs & e);

		/// on paint
		virtual void OnPaint(PaintEventArgs & e);

		/// on input event
		virtual void OnInputEvent(InputEventArgs & e);			
		
		// on click
		virtual void OnClick(Client::InputEventArgs &e);

		///new virtual functions
		virtual void PaintBackground(PaintEventArgs & e);
	
	public:
		virtual void Click();

	protected:
		bool				m_KeepAspect;
		bool				m_Expand;
		sharedc_ptr(Image)	m_ForeGroundImage;
		sharedc_ptr(Image)	m_FrontImage;
		sharedc_ptr(Image)	m_VIPImage;
		sharedc_ptr(Image)	m_IsNewImage;

		
		bool		m_MouseHoldDown	:1;
		bool		m_MousePointed	:1;		
		bool		m_Highlighted	:1;
		bool		m_IsStatic		:1;
		bool		m_OriginalSize	:1;
	};
}

namespace Gui
{
	/// base class of ui elements
	class  ItemPicture : public Picture
	{
		DECLARE_PDE_OBJECT(ItemPicture, Picture);
	public:
		DECLARE_PDE_ATTRIBUTE_RW(ID, int);
		DECLARE_PDE_ATTRIBUTE_RW(PID, int);
		DECLARE_PDE_ATTRIBUTE_RW(PPID, int);
		DECLARE_PDE_ATTRIBUTE_RW(SubType, int);
		DECLARE_PDE_ATTRIBUTE_RW(Clicked, bool);
		DECLARE_PDE_ATTRIBUTE_RW(ItemName, Core::String);
		DECLARE_PDE_ATTRIBUTE_RW(ItemNameLocation, Core::Vector2);
		DECLARE_PDE_ATTRIBUTE_RW(Loading, bool);
		INLINE_PDE_ATTRIBUTE_RW(LoadingImage, tempc_ptr(AnimatedImage));

		DECLARE_PDE_ATTRIBUTE_RW(Where, int);

		DECLARE_PDE_ATTRIBUTE_RW(UnitType, int);

		DECLARE_PDE_ATTRIBUTE_RW(TimeLeftType, int);
		DECLARE_PDE_ATTRIBUTE_RW(TimeLeft, int);
		DECLARE_PDE_ATTRIBUTE_RW(Durable, int);

		DECLARE_PDE_ATTRIBUTE_RW(InPack, int);
		DECLARE_PDE_ATTRIBUTE_RW(ModState, int);

		DECLARE_PDE_ATTRIBUTE_RW(Cost, int);
		DECLARE_PDE_ATTRIBUTE_RW(CostType, int);
		DECLARE_PDE_ATTRIBUTE_RW(Period, int);
		DECLARE_PDE_ATTRIBUTE_RW(Locked, bool);



	public:
		ItemPicture();
		~ItemPicture();

		void Clear();

		/// on paint
		virtual void OnPaint(PaintEventArgs & e);

		virtual void PaintBackground(PaintEventArgs & e);

	protected:
		int							m_ID;
		int							m_PID;
		int							m_PPID;
		int							m_SubType;
		bool						m_Clicked;
		Core::String				m_ItemName;
		Core::Vector2				m_ItemNameLocation;
		bool						m_IsLoading;
		bool						m_IsEmpty;
		sharedc_ptr(AnimatedImage)	m_LoadingImage;

		int						m_Where;		// -1: bag 1:wc 2:cc 3:shop 4:depot 5:room 6:other bag

		int						m_UnitType; // 1 Permanent, 2 Damage Based, 3 Unit Based, 4 Time Based

		int						m_TimeLeftType;	// hour/day/month
		int						m_TimeLeft;		// time left
		int						m_Durable;		// health value

		int						m_CostType;		//CR or GP
		int						m_Cost;			//cost
		int						m_Period;		//Period

		int						m_InPack;		//equip info, in which pack
		int						m_ModState;

		bool					m_Locked;
	};
}

namespace Gui
{
	class OtherPortrait: public Control
	{
	public:
		DECLARE_PDE_OBJECT(OtherPortrait, Control);

	public:
		virtual void OnCreate();
		virtual void OnDestroy();
		virtual void OnFrameUpdate(Core::EventArgs & e);
		virtual void OnPaint(PaintEventArgs & e);
	};
}