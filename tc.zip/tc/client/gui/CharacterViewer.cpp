#include "pch.h"

using namespace Core;
using namespace Client;
using namespace Gui;


DEFINE_PDE_TYPE_CLASS(Gui::CharacterViewer)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::Control);
		ADD_PDE_DEFAULT_CONSTRUCTOR();
	}
};
REGISTER_PDE_TYPE(Gui::CharacterViewer);
namespace Gui
{


	CharacterViewer::CharacterViewer(  ):aspect(0.f)
	{

	}

	CharacterViewer::~CharacterViewer(  )
	{

	}

	void CharacterViewer::OnInputEvent( InputEventArgs & e )
	{

		if(e.IsMouseEvent())
		{
			const Vector2& ctrlSize = GetSize();
			switch(e.Type)
			{
			case InputEventArgs::kMouseDown:
				{	
					if(gGame)
					{
						if(gGame->render)
						{
							if(gGame->render->GetLobby())
							{
								gGame->render->GetLobby()->action_state = LobbyPipeline::kRotCharacterA;					
								gGame->render->GetLobby()->BeginUpdateCursor();						
								SetCursorShape(Screen::kCursorRotate);
							}
						}
					}
					/*if(gGame)
					{
						Vector2 clientPos = gGame->screen->ScreenToClient(e.CursorScreenPosition);
						if(gGame->render)
							if(gGame->render->GetLobby())
							{
								LobbyPipeline::PickType resultType = LobbyPipeline::kPickNone;
								resultType = gGame->render->GetLobby()->Pick(ctrlSize,clientPos, InputEventArgs::kMouseDown);

								if(resultType == LobbyPipeline::kPickCharRot)
								{
									m_AvatarRotating = true;
									SetCursorShape(Screen::kCursorRotate);
								}
								else if(resultType == LobbyPipeline::kPickModifyWeapon)
								{
									m_AvatarRotating = true;
									SetCursorShape(Screen::kCursorRotate);
								}
							}
					}*/
					SetCapture(true);
					e.Handled = true;
				}
				break;
			case InputEventArgs::kMouseUp:
				{
					if(gGame)
					{
						if(gGame->render)
							if(gGame->render->GetLobby())
							{
								//gGame->render->GetLobby()->Pick(ctrlSize, clientPos, InputEventArgs::kMouseUp);*/
								gGame->render->GetLobby()->action_state = LobbyPipeline::kActionNone;
								SetCursorShape(Screen::kCursorRotate);
								SetCapture(false);
								e.Handled = true;
							}
							
					}
				
				}
				break;
			case InputEventArgs::kMouseMove:
				{
					SetCursorShape(Screen::kCursorRotate);
					if(gGame)
					{
						Vector2 clientPos = gGame->screen->ScreenToClient(e.CursorScreenPosition);
						if(gGame->render)
							if(gGame->render->lobby_pipeline)
							{
								/*LobbyPipeline::PickType resultType = LobbyPipeline::kPickNone;
								resultType = gGame->render->GetLobby()->Pick(ctrlSize, clientPos, InputEventArgs::kMouseMove);*/
								if(gGame->render->GetLobby()->action_state == LobbyPipeline::kRotCharacterA	)
								{
									gGame->render->lobby_pipeline->UpdateCursor(clientPos);
								}

								//if(GetCapture() && m_AvatarRotating)
								//{
								//	SetCursorShape(Screen::kCursorRotate);
								//}
								//else
								//{
								//	switch(resultType)
								//	{
								//	//case LobbyPipeline::kPickCharChg:
								//	//	SetCursorShape(Screen::kCursorSwitch);
								//	//	break;
								//	case LobbyPipeline::kPickCharRot:
								//		SetCursorShape(Screen::kCursorRotate);
								//		break;
								//	//case LobbyPipeline::kPickModifyWeapon:
								//	//	SetCursorShape(Screen::kCursorRotate);
								//	//	break;
								//	//case LobbyPipeline::kPickNone:
								//	//	SetCursorShape(Screen::kCursorArrow);
								//	//	break;
								//	}
								//}
							}
					}
					e.Handled = true;
				}
				break;
			case InputEventArgs::kMouseEnter:
				{
					SetCursorShape(Screen::kCursorRotate);
					e.Handled = true;
				}
			default:
				break;
			}
		}

		if (!e.Handled)
			Control::OnInputEvent(e);

	}

	void CharacterViewer::OnPaint( PaintEventArgs & e )
	{
		Control::OnPaint(e);
		Core::Rectangle bg_rect = GetBackgroundRect();


		if(gGame)
		{
			if(gGame->render)
			{
				tempc_ptr(LobbyPipeline) lob = gGame->render->GetLobby();

				if(lob && lob->GetInitialized())
				{
					const Vector2& ctrlLocation = GetLocation();
					const Vector2& ctrlSize = GetSize();
					if (render_texture->GetHeight() != ctrlSize.y)
					{
						Vector2 screensize = gGame->screen->GetSize();	
						aspect = 0.75	;						
						float wsize = ctrlSize.y / aspect   ;
						render_texture->CreateRenderTexture(wsize, ctrlSize.y, 1, D3DUSAGE_RENDERTARGET, D3DFMT_A8R8G8B8, 0);
						render_texture->CreateDepthStencil(D3DFMT_D24S8, true);
						if(wsize == 765)
						{
							Core::LogSystem.WriteLine("screen size get erro");
						}
					}

					lob->DrawCharacter(0,render_texture);
					gGame->render->ui_render->BeginDraw(gGame->dx9->render_target, gGame->dx9->depth_stencil);
					float xoffset = 0.f;
					if(ctrlSize.x < render_texture->GetWidth())
					{
						xoffset = (render_texture->GetWidth() - ctrlSize.x)/2;
						xoffset = xoffset / render_texture->GetWidth() ;
					}		
					e.render->DrawTextureWindow(ctrlLocation, ctrlSize.x, ctrlSize.y, render_texture,Core::Rectangle(xoffset,0,1 - xoffset,1));
				}
			}
		}
	}

	void CharacterViewer::OnCreate()
	{
		Control::OnCreate();
		render_texture = ptr_new RenderTexture;	 

	}

}