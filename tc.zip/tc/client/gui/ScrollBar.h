namespace Gui
{
	class ScrollBar : public Core::Object
	{
	public:
		DECLARE_PDE_EVENT(EventValueChanged,	EventArgs);

	public:
		DECLARE_PDE_ATTRIBUTE_RW(Location,		Core::Vector2);
		DECLARE_PDE_ATTRIBUTE_RW(Size,			Core::Vector2);
		DECLARE_PDE_ATTRIBUTE_RW(Minimum,		F32);
		DECLARE_PDE_ATTRIBUTE_RW(Maximum,		F32);
		DECLARE_PDE_ATTRIBUTE_RW(SmallChange,	F32);
		DECLARE_PDE_ATTRIBUTE_RW(LargeChange,	F32);
		DECLARE_PDE_ATTRIBUTE_RW(Value,			F32);
		DECLARE_PDE_ATTRIBUTE_RW(Horizontal,	bool);
		DECLARE_PDE_ATTRIBUTE_R (Valid,			bool);
		DECLARE_PDE_ATTRIBUTE_RW(Visible,		bool);
		DECLARE_PDE_ATTRIBUTE_RW(Width,			F32);
		DECLARE_PDE_ATTRIBUTE_RW(ButtonSize,	F32);

		OVERRIDE_PDE_ATTRIBUTE_R(MinimumSize,	Core::Vector2) { return Core::Vector2(Core::Min(m_Size.x, m_Size.y), Core::Min(m_Size.x, m_Size.y)); }
		
	public:
		///constructor
		ScrollBar();

		///destructor
		~ScrollBar();

		/// on paint
		void OnPaint(PaintEventArgs & e, tempc_ptr(ScrollableControlSkin) skin);

		/// on input event
		void OnInputEvent(by_ptr(Control) control, InputEventArgs & e);

		/// on update
		void OnFrameUpdate(EventArgs & e);

		/// on value changed
		void OnValueChanged(EventArgs & e);

		/// on mouse enter
		void OnMouseEnter(InputEventArgs & e);

		/// on mouse leave
		void OnMouseLeave(InputEventArgs & e);


	protected:
		virtual void GetControlOffset(F32 offset[6]);
		virtual Core::Rectangle GetControlRect(F32 offset[6], U32 id);

	private:
		F32		m_Minimum;
		F32		m_Maximum;
		F32		m_SmallChange;
		F32		m_LargeChange;
		F32		m_Value;

		U32		m_ActiveButton;
		U32		m_HoverButton;
		F32		m_ScrollOffset;
		F64		m_Timer;

		Core::Vector2	m_Location;
		Core::Vector2	m_Size;
		F32				m_ButtonSize;

		bool	m_Horizontal;
		bool	m_HVFixed;
		bool	m_Visible;
	};
}