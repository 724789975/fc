#include "pch.h"

using namespace Core;
using namespace Client;
using namespace Gui;

//--------------------------------------------------------------------------------------
// type info
//--------------------------------------------------------------------------------------
DEFINE_PDE_TYPE_CLASS(Gui::PopupFrameSkin)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::ControlSkin);
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_PROPERTY_RW(HighlightImage);
	}
};

DEFINE_PDE_TYPE_CLASS(PopupFrame)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Control);
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_PROPERTY_RW(OutwardBoundary);
	}
};

REGISTER_PDE_TYPE(PopupFrameSkin)
REGISTER_PDE_TYPE(PopupFrame)


namespace Gui
{
	PopupFrame::PopupFrame()
		: m_Timer(FLT_MAX)
		, m_Started(false)
		, m_Showing(false)
		, m_Alpha(0.0f)
	{
		SetEnable(false);
	}

	PopupFrame::~PopupFrame()
	{
	}

	void PopupFrame::IncreaseAlpha()
	{
		float frameTime = Task::GetFrameTime();

		if(m_Alpha<=0.99f)
		{
			m_Alpha += frameTime/m_CONTROL_HOVER_EFFECT_DURATION;
		}
		if(m_Alpha>0.99f)
			m_Alpha = 1.f;
	}

	void PopupFrame::DecreaseAlpha()
	{
		float frameTime = Task::GetFrameTime();

		if(m_Alpha>=0.01f)
		{
			m_Alpha -= frameTime/m_CONTROL_HOVER_EFFECT_DURATION;
		}
		if(m_Alpha<0.01f)
			m_Alpha = 0.f;
	}

	void PopupFrame::OnFrameUpdate( EventArgs & e )
	{
		Super::OnFrameUpdate(e);
		Shine();
		if(m_Started)
		{
			F32 frameTime = Task::GetFrameTime();
			m_Timer-=frameTime;
			if(m_Showing)
			{
				IncreaseAlpha();
				if(Core::Abs(m_Alpha-1.f)<Core::EPSILON)
					m_Showing = false;
			}

			SetVisible(CheckVisibility());
		}
		if(m_Timer<0.f)
		{
			DecreaseAlpha();
			if(Core::Abs(m_Alpha)<Core::EPSILON)
			{
				if(m_Owner)
					m_Owner = NullPtr;
				m_Started = false;
				Task::Post(NewGenericTask(&PopupFrame::Terminate, ptr_static_cast<PopupFrame>(this)));
			}
		}
	}

	void PopupFrame::OnPaint( PaintEventArgs & e )
	{
		tempc_ptr(PopupFrameSkin) skin = ptr_static_cast<PopupFrameSkin>(GetSkin());
		U8 uAlpha = (U8)(m_Alpha*255);
		if(skin)
		{
			U8 uHLAlpha = (U8)(m_Alpha*m_HoverPower*255);
			Skin::DrawImage(e.render, skin->GetBackgroundImage(), GetClientRect(), ARGB(uAlpha, 255,255,255));
 			Skin::DrawImage(e.render, skin->GetHighlightImage(), GetClientRect(), ARGB(uHLAlpha, 255,255,255));
		}
		else
		{
			e.render->DrawRectangle(GetClientRect(), Core::Rectangle(0,0,1,1), ARGB(128, 0, 0, 255));
		}
	}

	void PopupFrame::OnInputEvent( InputEventArgs & e )
	{
		Super::OnInputEvent(e);
	}

	void PopupFrame::Show( const Core::Rectangle& globalBaseRect, F32 timer)
	{
// 		if(!m_Started)	//Allow user to show the same frame again because they use the same control parenting different root to fake different controls sometimes...
// 		{
			UpdateLocation(globalBaseRect);

			SetParent(gGame->guiSys);
			m_Timer = timer;
			m_Started = true;
			m_Showing = true;
			m_HoverPower = 0.f;
			m_Alpha = 0.f;
// 		}
	}

	void PopupFrame::Cancel()
	{
		m_Timer = 0.0f;
	}

	void PopupFrame::Terminate()
	{
		SetParent(NullPtr);
		m_Owner = NullPtr;
	}

	void PopupFrame::UpdateLocation(const Core::Rectangle& globalBaseRect)
	{
		//Calculate actual size
		Core::Rectangle realRect = globalBaseRect;
		SetSize(realRect.Shrink(-m_OutwardBoundary).GetExtent());

		Core::Vector2 aPos;
		aPos.x = Core::Floor(globalBaseRect.Min.x-m_OutwardBoundary.x+0.5f);
		aPos.y = Core::Floor(globalBaseRect.Min.y-m_OutwardBoundary.y+0.5f);
		SetLocation(aPos);
	}

	bool PopupFrame::CheckVisibility()
	{
		if(m_Owner)
			return m_Owner->GetVisibility();
		else
			return false;
	}
}



