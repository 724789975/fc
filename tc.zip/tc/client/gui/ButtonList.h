namespace Gui
{
	struct Button_List_Data : public Core::Object
	{
		sharedc_ptr(Control)	control;
		sharedc_ptr(Button)		button;
		Core::Vector2			offset;
		
		Button_List_Data()
		{

		}

		~Button_List_Data()
		{
			control = NullPtr;
			button = NullPtr;
		}
	};

	class ButtonList:public Control
	{
		DECLARE_PDE_OBJECT(ButtonList, Control);
	public:
		ButtonList();

		~ButtonList();

		virtual void OnCreate();

		virtual void OnPaint(PaintEventArgs & e);
		
		virtual void OnClick(Client::InputEventArgs & e);

		virtual void OnFrameUpdate(EventArgs & e);

		void AddButton(const by_ptr(Button) button);

		void AddButtonWithLogo(const by_ptr(Button) button, const by_ptr(Control) c, const Core::Vector2 offset);

		void MoveLeft(by_ptr(void) sender, InputEventArgs & e);

		void MoveRight(by_ptr(void) sender, InputEventArgs & e);

		void ClearList();

	public:
		INLINE_PDE_ATTRIBUTE_RW(MaxCount,	   uint);
		INLINE_PDE_ATTRIBUTE_RW(Space,		   uint);
		INLINE_PDE_ATTRIBUTE_RW(Yoffset,	   uint);
		INLINE_PDE_ATTRIBUTE_RW(ButtonSize,	   Core::Vector2);
		INLINE_PDE_ATTRIBUTE_RW(ArrowSize,	   Core::Vector2);
		DECLARE_PDE_ATTRIBUTE_RW(LeftArrowSkin, tempc_ptr(ButtonSkin));
		DECLARE_PDE_ATTRIBUTE_RW(RightArrowSkin,tempc_ptr(ButtonSkin));
	private:
		uint								 m_MaxCount;
		uint								 m_Yoffset;
		uint								 m_pos;
		uint								 m_Space;
		Core::Vector2						 m_ButtonSize;
		Core::Vector2						 m_ArrowSize;
		sharedc_ptr(Button)					 m_LeftButton;
		sharedc_ptr(Button)					 m_RightButton;
		sharedc_ptr(ButtonSkin)				 m_LeftArrowSkin;
		sharedc_ptr(ButtonSkin)				 m_RightArrowSkin;
		Core::Array<sharedc_ptr(Button_List_Data)>	 m_ButtonList;
	};
}