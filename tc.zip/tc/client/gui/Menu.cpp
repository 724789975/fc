#include "pch.h"
using namespace Core;
using namespace Client;
using namespace Gui;

DEFINE_PDE_TYPE_CLASS(Menu)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Control);
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_PROPERTY_RW(ItemWidth);
		ADD_PDE_PROPERTY_RW(ItemHeight);
		ADD_PDE_PROPERTY_RW(ItemText_LeftSpace);
		ADD_PDE_PROPERTY_RW(TextAlign);
		ADD_PDE_PROPERTY_RW(SeparatorHeight);
		ADD_PDE_PROPERTY_RW(Border);
		ADD_PDE_PROPERTY_R(SelectedIndex);
		ADD_PDE_PROPERTY_R(ItemCount);

		ADD_PDE_EVENT(EventClick);
		ADD_PDE_METHOD(AddItem);
		ADD_PDE_METHOD(AddSeparator);
		ADD_PDE_METHOD(RemoveAll);
		ADD_PDE_METHOD(SetSubMenu);
		ADD_PDE_METHOD(GetEnable);
		ADD_PDE_METHOD(SetEnable);
		ADD_PDE_METHOD(GetCanCheck);
		ADD_PDE_METHOD(SetCanCheck);
		ADD_PDE_METHOD(GetCheck);
		ADD_PDE_METHOD(SetCheck);
		ADD_PDE_METHOD(SetRadio);
		ADD_PDE_METHOD(Open);
		ADD_PDE_METHOD(Close);
	}

};

DEFINE_PDE_TYPE_CLASS(MenuSkin)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::ControlSkin);
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_PROPERTY_RW(ItemHoverImage);
		ADD_PDE_PROPERTY_RW(ItemRadioImage);
		ADD_PDE_PROPERTY_RW(ItemCheckedImage);
		ADD_PDE_PROPERTY_RW(ItemUncheckImage);
		ADD_PDE_PROPERTY_RW(ItemHasSubMenuImage);
		ADD_PDE_PROPERTY_RW(SeparatorImage);
	}
};

REGISTER_PDE_TYPE(Menu);
REGISTER_PDE_TYPE(MenuSkin);

namespace Gui
{
	Menu::Menu(void)
		: m_ItemWidth(120)
		, m_ItemHeight(25)
		, m_ItemText_LeftSpace(25)
		, m_TextAlign(Unit::kAlignLeftMiddle)
		, m_SeparatorHeight(2)
		, m_Border(2,2,2,2)
		, m_SelectedIndex(-1)
		, m_ItemCount(0)
		, m_Owner(NullPtr)
		, m_OpenedSubMenu(NullPtr)
	{

	}

	Menu::~Menu(void)
	{
		m_aItem.Clear();
	}

	PDE_ATTRIBUTE_GETTER(Menu, ItemWidth, U32)
	{
		return m_ItemWidth;
	}

	PDE_ATTRIBUTE_SETTER(Menu, ItemWidth, U32)
	{
		if (value != m_ItemWidth)
		{
			m_ItemWidth = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(Menu, ItemHeight, U32)
	{
		return m_ItemHeight;
	}

	PDE_ATTRIBUTE_SETTER(Menu, ItemHeight, U32)
	{
		if (value != m_ItemHeight)
		{
			m_ItemHeight = value;
			Invalid();
		}
	}
	
	PDE_ATTRIBUTE_GETTER(Menu, ItemText_LeftSpace, U32)
	{
		return m_ItemText_LeftSpace;
	}

	PDE_ATTRIBUTE_SETTER(Menu, ItemText_LeftSpace, U32)
	{
		if (value != m_ItemText_LeftSpace)
		{
			m_ItemText_LeftSpace = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(Menu, TextAlign, Unit::Align)
	{
		return m_TextAlign;
	}

	PDE_ATTRIBUTE_SETTER(Menu, TextAlign, Unit::Align)
	{
		if (value != m_TextAlign)
		{
			m_TextAlign = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(Menu, SeparatorHeight, U32)
	{
		return m_SeparatorHeight;
	}

	PDE_ATTRIBUTE_SETTER(Menu, SeparatorHeight, U32)
	{
		if (value != m_SeparatorHeight)
		{
			m_SeparatorHeight = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(Menu, Border, Vector4)
	{
		return m_Border;
	}

	PDE_ATTRIBUTE_SETTER(Menu, Border, Vector4)
	{
		if (value != m_Border)
		{
			m_Border = value;
			ResetSize();
		}
	}

	PDE_ATTRIBUTE_GETTER(Menu, SelectedIndex, S32)
	{
		return m_SelectedIndex;
	}

	PDE_ATTRIBUTE_GETTER(Menu, ItemCount, U32)
	{
		return m_ItemCount;
	}

	PDE_ATTRIBUTE_GETTER(Menu, Owner, tempc_ptr(Menu))
	{
		return m_Owner;
	}

	PDE_ATTRIBUTE_SETTER(Menu, Owner, tempc_ptr(Menu))
	{
		if (value != m_Owner)
		{
			m_Owner = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(Menu, OpenedSubMenu, tempc_ptr(Menu))
	{
		return m_OpenedSubMenu;
	}

	PDE_ATTRIBUTE_SETTER(Menu, OpenedSubMenu, tempc_ptr(Menu))
	{
		if (value != m_OpenedSubMenu)
		{
			m_OpenedSubMenu = value;
			Invalid();
		}
	}

	void Menu::OnPaint(PaintEventArgs & e)
	{
		Control::OnPaint(e);

		tempc_ptr(MenuSkin) skin = ptr_dynamic_cast<MenuSkin>(GetSkin());
		if (skin)
		{
			for (U32 i = 0;i < m_ItemCount;i++)
			{

				if (m_aItem[i].IsSeparator)
				{
					Skin::DrawImage(e.render, skin->GetSeparatorImage(),m_aItem[i].ItemRect);
				}
				else
				{

					if(m_SelectedIndex == i)
						Skin::DrawImage(e.render, skin->GetItemHoverImage(), m_aItem[i].ItemRect);
					if (m_aItem[i].CanCheck)
					{
						if(m_aItem[i].Check)
							Skin::DrawImage(e.render, skin->GetItemCheckedImage(), m_aItem[i].IconRect);
						else
							Skin::DrawImage(e.render, skin->GetItemUncheckImage(), m_aItem[i].IconRect);
					}

					if (m_aItem[i].Radio)
					{
						Skin::DrawImage(e.render, skin->GetItemRadioImage(), m_aItem[i].IconRect);
					}

					if (m_aItem[i].SubMenu)
					{
						Skin::DrawImage(e.render, skin->GetItemHasSubMenuImage(), m_aItem[i].SubMenuRect);
					}
					e.render->DrawString(GetFont(),m_aItem[i].Enable?m_TextColor:ARGB(255,128,128,128), ARGB(0,0,0,0), m_aItem[i].TextRect, m_aItem[i].Text, m_TextAlign);
				}

			}
		}
		else
		{
			for (U32 i = 0;i < m_ItemCount;i++)
			{
				if (m_aItem[i].IsSeparator)
				{
					e.render->DrawRectangle(m_aItem[i].ItemRect,m_aItem[i].ItemRect,ARGB(128,128,128,128));
				}
				else
				{
					if (m_aItem[i].CanCheck)
					{
						e.render->DrawRectangle(m_aItem[i].IconRect,m_aItem[i].IconRect,m_aItem[i].Check?ARGB(128,0,128,0):ARGB(128,128,128,0));
					}
					if (m_aItem[i].SubMenu)
					{
						e.render->DrawRectangle(m_aItem[i].SubMenuRect,m_aItem[i].SubMenuRect,ARGB(128,0,128,0));
					}
					e.render->DrawString(GetFont(),m_aItem[i].Enable?m_TextColor:ARGB(255,128,128,128),m_SelectedIndex == i?ARGB(128,0,128,0):m_BackgroundColor,m_aItem[i].TextRect,m_aItem[i].Text,m_TextAlign);

				}
			}
		}
	}

	void Menu::OnInputEvent(InputEventArgs & e)
	{
		if (e.IsMouseEvent())
		{
			Vector2 localPos = ScreenToClient(e.CursorPosition);
			switch (e.Type)
			{
			case InputEventArgs::kMouseDown:
				{
					e.Handled = true;
				}

				break;
			case InputEventArgs::kMouseUp:
				{
					if (m_SelectedIndex > -1 && !m_aItem[m_SelectedIndex].IsSeparator)
					{
						if(e.Code == MC_LEFT_BUTTON)
							OnClick(e);
					}
					e.Handled = true;
				}
				break;

			case InputEventArgs::kMouseMove:
				{
					for (U32 i = 0;i < m_ItemCount;i++)
					{
						if(m_aItem[i].ItemRect.IsPointInside(localPos))
						{
							m_SelectedIndex = i;
							if (m_OpenedSubMenu)
							{
								if (m_OpenedSubMenu != m_aItem[m_SelectedIndex].SubMenu)
								{
									m_OpenedSubMenu->Close();
								}
							}
							else
							{
								if (m_aItem[m_SelectedIndex].SubMenu && m_aItem[m_SelectedIndex].Enable)
								{
									m_aItem[m_SelectedIndex].SubMenu->Open();
								}
							}
						}
					}
					e.Handled = true;
				}
				break;
			}
		}
		if (!e.Handled)
		{
			Control::OnInputEvent(e);
		}
	}

	void Menu::OnMouseEnter(InputEventArgs & e)
	{
		SetFocused(true);
	}

	void Menu::OnLeave(EventArgs & e)
	{
		if (LeaveAllMenu())
		{
			GetRootMenu()->Close();
		}
	}

	void Menu::OnClick(InputEventArgs & e)
	{
		if (!m_aItem[m_SelectedIndex].SubMenu && m_aItem[m_SelectedIndex].Enable)
		{
			if (m_aItem[m_SelectedIndex].CanCheck)
			{
				m_aItem[m_SelectedIndex].Check = !m_aItem[m_SelectedIndex].Check;
			}
			if(!m_aItem[m_SelectedIndex].CanCheck)
				GetRootMenu()->Close();
			EventClick.Fire(ptr_static_cast<Menu>(this), e);
		}
	}

	void Menu::ResetSize()
	{
		Vector4 border = GetBorder();
		F32 x = border.x;
		F32 y = border.y;
		F32 z = border.z;
		F32 w = border.w;
		U32 height = y;
		for (U32 i = 0;i < m_ItemCount;i++)
		{
			if (m_aItem[i].IsSeparator)
			{
				height += m_SeparatorHeight;
				m_aItem[i].ItemRect = Core::Rectangle::RightBottom(m_ItemWidth,height,m_ItemWidth,m_SeparatorHeight);
			}
			else
			{
				height += m_ItemHeight;
				m_aItem[i].ItemRect = Core::Rectangle::RightBottom(m_ItemWidth,height,m_ItemWidth,m_ItemHeight);
				m_aItem[i].IconRect = Core::Rectangle::RightBottom(m_ItemHeight + x,height,m_ItemHeight,m_ItemHeight);
				m_aItem[i].SubMenuRect = Core::Rectangle::RightBottom(m_ItemWidth - z,height,m_ItemHeight,m_ItemHeight);
				m_aItem[i].TextRect = Core::Rectangle::RightBottom(m_ItemWidth - z,height,m_ItemWidth - x - z - m_ItemText_LeftSpace,m_ItemHeight);
			}
		}
		SetSize(Vector2(m_ItemWidth,height + w));
	}

	void Menu::AddItem(const Core::String & text)
	{
		MenuItem item;
		item.Text = text;
		m_aItem.PushBack(item);
		m_ItemCount++;
		ResetSize();
	}

	void Menu::AddSeparator()
	{
		MenuItem item;
		item.IsSeparator = true;
		m_aItem.PushBack(item);
		m_ItemCount++;
		ResetSize();
	}

	void Menu::RemoveAll()
	{
		m_aItem.Clear();
		m_SelectedIndex = -1;
		m_ItemCount = 0;
		ResetSize();
	}

	Menu::MenuItem Menu::GetItem(U32 index)
	{
		return m_aItem[index];
	}

	void Menu::SetSubMenu(U32 index,tempc_ptr(Menu) subMenu)
	{
		PDE_ASSERT(!m_aItem[index].IsSeparator,"It's a Separator");
		m_aItem[index].SubMenu = subMenu;
		m_aItem[index].SubMenu->m_Owner = (ptr_static_cast<Menu>(this));
	}

	bool Menu::GetEnable(U32 index)
	{
		PDE_ASSERT(!m_aItem[index].IsSeparator,"It's a Separator");
		return m_aItem[index].Enable;
	}

	void Menu::SetEnable(U32 index, bool enable)
	{
		PDE_ASSERT(!m_aItem[index].IsSeparator,"It's a Separator");
		m_aItem[index].Enable = enable;
	}

	bool Menu::GetCanCheck(U32 index)
	{
		PDE_ASSERT(!m_aItem[index].IsSeparator,"It's a Separator");
		return m_aItem[index].CanCheck;
	}

	void Menu::SetCanCheck(U32 index, bool value)
	{
		PDE_ASSERT(!m_aItem[index].IsSeparator,"It's a Separator");
		m_aItem[index].CanCheck = value;
	}

	bool Menu::GetCheck(U32 index)
	{
		PDE_ASSERT(m_aItem[index].CanCheck,"Can not Check");
		return m_aItem[index].Check;
	}

	void Menu::SetCheck(U32 index, bool value)
	{
		PDE_ASSERT(m_aItem[index].CanCheck,"Can not Check");
		m_aItem[index].Check = value;
	}

	void Menu::SetRadio(U32 index)
	{
		PDE_ASSERT(!m_aItem[index].CanCheck,"It's a CanCheck Item");
		m_aItem[index].Radio = true;

		for (S32 i = index - 1;i > -1;i--)
		{
			PDE_ASSERT(!m_aItem[i].CanCheck,"It's a CanCheck Item");
			if (m_aItem[i].IsSeparator)
				break;
			m_aItem[i].Radio = false;
		}

		for (U32 i = index + 1;i < m_ItemCount;i++)
		{
			PDE_ASSERT(!m_aItem[i].CanCheck,"It's a CanCheck Item");
			if (m_aItem[i].IsSeparator)
				break;
			m_aItem[i].Radio = false;
		}
	}

	void Menu::Open()
	{
		m_SelectedIndex = -1;
		SetParent(gGame->guiSys);
		Vector2 size = GetSize();
		Vector2 pos = GetLocation();
		Core::Rectangle rect(gGame->guiSys->GetDisplayRect());
		if (pos.y + size.y > rect.Max.y)
		{
			pos -= Vector2(0,size.y);
		}
		if (pos.x + size.x > rect.Max.x)
		{
			pos -= Vector2(size.x,0);
		}
		SetLocation(pos);

		if (m_Owner)
		{
			SetLocation(m_Owner->GetLocation() + m_Owner->GetItem(m_Owner->GetSelectedIndex()).ItemRect.Max - Vector2(0,m_Owner->GetItemHeight()));
			m_Owner->SetOpenedSubMenu(ptr_static_cast<Menu>(this));
			pos = GetLocation();
			S32 offsetY = 0;
			U32 index = 0;
			while (pos.y + size.y > rect.Max.y)
			{
				S32 offsetY = m_Owner->GetItem(index).ItemRect.GetExtent().y;
				pos -= Vector2(0,offsetY);
				index++;
			}
			if (pos.x + size.x > rect.Max.x)
			{
				pos -= Vector2(m_Owner->GetSize().x + GetSize().x,0);
			}
			pos.y -= GetBorder().y;
			SetLocation(pos);
		}

		SetVisible(true);
		if (GetRootMenu() == ptr_static_cast<Menu>(this))
		{
			SetFocused(true);
		}

		EventOpen.Fire(ptr_static_cast<Menu>(this), EventArgs());
	}

	void Menu::Close()
	{
		SetVisible(false);
		SetParent(NullPtr);
		tempc_ptr(Menu) owner = GetOwner();
		if (owner)
		{
			owner->SetOpenedSubMenu(NullPtr);
		}

		tempc_ptr(Menu) openedSubMenu = GetOpenedSubMenu();
		while(openedSubMenu)
		{
			openedSubMenu->Close();
			openedSubMenu = openedSubMenu->GetOpenedSubMenu();
		}

		EventClose.Fire(ptr_static_cast<Menu>(this), EventArgs());
	}

	tempc_ptr(Menu) Menu::GetRootMenu()
	{
		tempc_ptr(Menu) owner = ptr_static_cast<Menu>(this);
		while(owner->GetOwner())
		{
			owner = owner->GetOwner();
		}
		return owner;
	}

	bool Menu::LeaveAllMenu()
	{
		tempc_ptr(Menu) openedMenu = GetRootMenu();
		while(openedMenu)
		{
			if (openedMenu->GetFocused())
				return false;
			openedMenu = openedMenu->GetOpenedSubMenu();
		}
		return true;
	}
}
