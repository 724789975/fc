#include "pch.h"

using namespace Core;
using namespace Client;
using namespace Gui;

//--------------------------------------------------------------------------------------
// type info
//--------------------------------------------------------------------------------------
DEFINE_PDE_TYPE_CLASS(PictureSkin)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(ControlSkin);
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_PROPERTY_RW(HighlightFrame);
		ADD_PDE_PROPERTY_RW(HoverFrame);
	}
};
DEFINE_PDE_TYPE_CLASS(ItemPictureSkin)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(PictureSkin);
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_PROPERTY_RW(EmptyFrame);

		ADD_PDE_PROPERTY_RW(LockedImage);
		ADD_PDE_PROPERTY_RW(PackAImage);
		ADD_PDE_PROPERTY_RW(PackBImage);
		ADD_PDE_PROPERTY_RW(PackCImage);
		ADD_PDE_PROPERTY_RW(PackDImage);
		ADD_PDE_PROPERTY_RW(PackEImage);
		ADD_PDE_PROPERTY_RW(RepairImage);

		ADD_PDE_PROPERTY_RW(TuneNoImage);
		ADD_PDE_PROPERTY_RW(TuneYesImage);
		ADD_PDE_PROPERTY_RW(TunedImage);

		ADD_PDE_PROPERTY_RW(NameNormalColor);
		ADD_PDE_PROPERTY_RW(NameHighlightColor);
		ADD_PDE_PROPERTY_RW(LeftHighlightColor);
	}
};
DEFINE_PDE_TYPE_CLASS(Picture)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Control);
		ADD_PDE_DEFAULT_CONSTRUCTOR();
		
		ADD_PDE_EVENT(EventClick);

		ADD_PDE_PROPERTY_RW(VIPImage);
		ADD_PDE_PROPERTY_RW(ForeGroundImage);
		ADD_PDE_PROPERTY_RW(FrontImage);
		ADD_PDE_PROPERTY_RW(IsNewImage);
		ADD_PDE_PROPERTY_RW(KeepAspect);
		ADD_PDE_PROPERTY_RW(Expand);
		ADD_PDE_PROPERTY_RW(BeStatic);
		ADD_PDE_PROPERTY_RW(Highlighted);
		ADD_PDE_PROPERTY_RW(OriginalSize);
	}
};
DEFINE_PDE_TYPE_CLASS(ItemPicture)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Picture);
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_PROPERTY_RW(ID);
		ADD_PDE_PROPERTY_RW(PID);
		ADD_PDE_PROPERTY_RW(PPID);
		ADD_PDE_PROPERTY_RW(SubType);
		ADD_PDE_PROPERTY_RW(Clicked);
		ADD_PDE_PROPERTY_RW(ItemName);
		ADD_PDE_PROPERTY_RW(ItemNameLocation);
		ADD_PDE_PROPERTY_RW(LoadingImage);
		ADD_PDE_PROPERTY_RW(Loading);
// 		ADD_PDE_PROPERTY_RW(Empty);

		ADD_PDE_PROPERTY_RW(Where);

		ADD_PDE_PROPERTY_RW(UnitType);

		ADD_PDE_PROPERTY_RW(TimeLeftType);
		ADD_PDE_PROPERTY_RW(TimeLeft);
		ADD_PDE_PROPERTY_RW(Durable);

		ADD_PDE_PROPERTY_RW(InPack);
		ADD_PDE_PROPERTY_RW(ModState);

		ADD_PDE_PROPERTY_RW(Cost);
		ADD_PDE_PROPERTY_RW(CostType);
		ADD_PDE_PROPERTY_RW(Period);
		ADD_PDE_PROPERTY_RW(Locked);

		ADD_PDE_METHOD(Clear);
	}
};

DEFINE_PDE_TYPE_CLASS(OtherPortrait)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Control);
		ADD_PDE_DEFAULT_CONSTRUCTOR();
	}
};


REGISTER_PDE_TYPE(PictureSkin);
REGISTER_PDE_TYPE(ItemPictureSkin);
REGISTER_PDE_TYPE(Picture);
REGISTER_PDE_TYPE(ItemPicture);
REGISTER_PDE_TYPE(OtherPortrait);

namespace Gui
{
	Picture::Picture()
		: m_KeepAspect(true)
		, m_Expand(false)
		, m_ForeGroundImage(NullPtr)
		, m_FrontImage(NullPtr)
		, m_VIPImage(NullPtr)
		, m_MouseHoldDown(false)
		, m_IsNewImage(NullPtr)
		, m_MousePointed(false)		
		, m_Highlighted(false)
		, m_IsStatic(true)
		, m_OriginalSize(false)
	{
	}

	Picture::~Picture()
	{
	}
}


//--------------------------------------------------------------------------------------
// Attribute
//--------------------------------------------------------------------------------------
namespace Gui
{
	PDE_ATTRIBUTE_GETTER(Picture, VIPImage , tempc_ptr(Image))
	{
		return m_VIPImage;
	}


	PDE_ATTRIBUTE_SETTER(Picture, VIPImage , tempc_ptr(Image))
	{
		if (m_VIPImage != value)
		{
			m_VIPImage = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(Picture, ForeGroundImage , tempc_ptr(Image))
	{
		return m_ForeGroundImage;
	}


	PDE_ATTRIBUTE_SETTER(Picture, ForeGroundImage , tempc_ptr(Image))
	{
		if (m_ForeGroundImage != value)
		{
			m_ForeGroundImage = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(Picture, FrontImage , tempc_ptr(Image))
	{
		return m_FrontImage;
	}


	PDE_ATTRIBUTE_SETTER(Picture, FrontImage , tempc_ptr(Image))
	{
		if (m_FrontImage != value)
		{
			m_FrontImage = value;
			Invalid();
		}
	}


	PDE_ATTRIBUTE_GETTER(Picture, IsNewImage , tempc_ptr(Image))
	{
		return m_IsNewImage;
	}


	PDE_ATTRIBUTE_SETTER(Picture, IsNewImage , tempc_ptr(Image))
	{
		if (m_IsNewImage != value)
		{
			m_IsNewImage = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(Picture, KeepAspect, bool)
	{
		return m_KeepAspect;
	}


	PDE_ATTRIBUTE_SETTER(Picture, KeepAspect, bool)
	{
		if (m_KeepAspect!=value)
		{
			m_KeepAspect = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(Picture, OriginalSize, bool)
	{
		return m_OriginalSize;
	}


	PDE_ATTRIBUTE_SETTER(Picture, OriginalSize, bool)
	{
		if (m_OriginalSize!=value)
		{
			m_OriginalSize = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(Picture, Expand, bool)
	{
		return m_Expand;
	}


	PDE_ATTRIBUTE_SETTER(Picture, Expand, bool)
	{
		if (m_Expand!=value)
		{
			m_Expand = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(Picture, BeStatic, bool)
	{
		return m_IsStatic;
	}

	PDE_ATTRIBUTE_SETTER(Picture, BeStatic, bool)
	{
		if(m_IsStatic != value)
		{
			m_IsStatic = value;
			m_MousePointed = false;
			m_MouseHoldDown = false;
			m_Highlighted = false;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(Picture, Highlighted, bool)
	{
		return m_Highlighted;
	}

	PDE_ATTRIBUTE_SETTER(Picture, Highlighted, bool)
	{
		if(m_Highlighted != value)
		{
			m_Highlighted = value;
			Invalid();
		}
	}
}


//--------------------------------------------------------------------------------------
// Event
//--------------------------------------------------------------------------------------
namespace Gui
{
	/// on auto size
	void Picture::OnAutoSize(AutoSizeEventArgs & e)
	{
		Core::Rectangle rect(Vector2(0, 0), m_ForeGroundImage ->GetSize());

 		Super::OnAutoSize(e);
	}

	void Picture::PaintBackground( PaintEventArgs & e )
	{
		tempc_ptr(PictureSkin) skin = ptr_dynamic_cast<PictureSkin>(GetSkin());

		if(!m_IsStatic)
		{
			if(skin)
			{
				if(m_Highlighted)
					Skin::DrawImage(e.render, skin->GetHighlightFrame(), GetClientRect());
				else if(m_MousePointed)
					Skin::DrawImage(e.render, skin->GetHoverFrame(), GetClientRect());
				else
					Skin::DrawImage(e.render, skin->GetBackgroundImage(), GetClientRect());
			}
			else
			{
				
			}
		}
		else
		{
			if(skin)
			{
				Skin::DrawImage(e.render, skin->GetBackgroundImage(), GetClientRect());
			}
			else
			{
				e.render->DrawRectangle(GetClientRect(), Core::Rectangle(0,0,1,1), GetBackgroundColor());
			}
		}
	}

	void Picture::OnPaint(PaintEventArgs & e)
	{
		//PaintBackground(e);
		Core::Rectangle rect(Vector2(0, 0), GetSize());
		Core::Rectangle ORect(Vector2(0, 0), GetSize());
		//rect.Shrink(GetPadding());
		Vector2 currentSize = rect.GetExtent();

		if(m_ForeGroundImage)
		{
			Core::Rectangle orgScissor = e.render->GetScissorRect();
			Core::Rectangle orgRect(rect);
			if(m_Expand)
			{
				F32 imageAspect = m_ForeGroundImage->GetSize().x/m_ForeGroundImage->GetSize().y;
				F32 controlAspect = currentSize.x/currentSize.y;
				if(controlAspect>imageAspect)
				{
					rect.Min.y -= floor((currentSize.x/imageAspect - currentSize.y)/2 + 0.5f);
					rect.Max.y = floor(rect.Min.y + currentSize.x/imageAspect+0.5f);
				}
				else
				{
					rect.Min.x -= floor((currentSize.y * imageAspect - currentSize.x)/2 + 0.5);
					rect.Max.x = floor(rect.Min.x + currentSize.y * imageAspect+0.5f);
				}
				e.render->SetScissorRectWithWorldMatrix(orgRect);
			}
			else if(m_KeepAspect)
			{
				F32 imageAspect = m_ForeGroundImage->GetSize().x/m_ForeGroundImage->GetSize().y;
				F32 controlAspect = currentSize.x/currentSize.y;
				if(controlAspect>imageAspect)
				{
					rect.Min.x += floor((currentSize.x - currentSize.y * imageAspect)/2 + 0.5f);
					rect.Max.x = floor(rect.Min.x + currentSize.y * imageAspect+0.5f);
				}
				else
				{
					rect.Min.y += floor((currentSize.y - currentSize.x/imageAspect)/2 + 0.5f);
					rect.Max.y = floor(rect.Min.y + currentSize.x/imageAspect+0.5f);
				}
			}

			if(m_OriginalSize)
				rect=ORect;

			Skin::DrawImage(e.render, m_ForeGroundImage, rect);
			Skin::DrawImage(e.render, m_VIPImage, Core::Rectangle(rect.Min.x, rect.Min.y, rect.Min.x + 60, rect.Min.y + 60));

			if(m_FrontImage)
			{
				m_FrontImage->Setalpha(255);

				if(m_Highlighted)
					m_FrontImage->Setalpha(0);
				else if(m_MousePointed)
					m_FrontImage->Setalpha(255 * 2/3);

				Skin::DrawImage(e.render, m_FrontImage, rect);
			}

			if (m_IsNewImage)
			{
				m_IsNewImage->Setalpha(255);

				if(m_MousePointed)
					m_IsNewImage->Setalpha(255 * 2/3);

				Skin::DrawImage(e.render, m_IsNewImage, rect);
			}

			tempc_ptr(PictureSkin) skin = ptr_dynamic_cast<PictureSkin>(GetSkin());

			if(m_Highlighted)
				Skin::DrawImage(e.render, skin->GetHighlightFrame(), GetClientRect());
			else if(m_MousePointed)
				Skin::DrawImage(e.render, skin->GetHoverFrame(), GetClientRect());
		}
	}

	void Picture::OnInputEvent(InputEventArgs & e)
	{
		if(m_IsStatic)
		{
			return;
		}

		if (e.IsMouseEvent())
		{

			Core::Vector2 localPos = ScreenToClient(e.CursorPosition);
			bool prevMousePointed = m_MousePointed;
			bool prevMouseDown = m_MouseHoldDown;
			
			m_MousePointed = GetBackgroundRect().IsPointInside(localPos);
			
			switch (e.Type)
			{
			case InputEventArgs::kMouseDown:
			case InputEventArgs::kMouseDoubleClick:
				{
					if(e.Code == MC_LEFT_BUTTON && m_MousePointed)
					{
						Invalid();
						SetCapture(true);
						m_MousePointed = true;
						m_MouseHoldDown = true;
						e.Handled = true;
					}
				}
				break;

			case InputEventArgs::kMouseUp:
				{
					if(e.Code == MC_LEFT_BUTTON && m_MouseHoldDown)
					{					
						Invalid();
						m_MouseHoldDown = false;

						SetCapture(false);

						if(m_MousePointed)
						{
							Click();
						}

						e.Handled = true;
					}
				}
				break;

			case InputEventArgs::kMouseMove:
				{
					e.Handled = true;
				}
				break;

			case InputEventArgs::kMouseEnter:
				{
					m_MousePointed = true;
					e.Handled = true;
				}
				break;
			case InputEventArgs::kMouseLeave:
				{
					m_MousePointed = false;
					e.Handled = true;
				}
				break;
			}

			if (prevMouseDown != m_MouseHoldDown || prevMousePointed != m_MousePointed)
			{
				Invalid();
			}
		}

		if (!e.Handled)
			Control::OnInputEvent(e);

	}

	void Picture::OnClick(Client::InputEventArgs &e)
	{
		EventClick.Fire(ptr_static_cast<Self>(this), e);

	}
}

namespace Gui
{
	void Picture::Click()
	{
		if(!m_IsStatic)
			SetHighlighted(!GetHighlighted());

		OnClick(InputEventArgs());
	}
}

namespace Gui
{
	ItemPicture::ItemPicture()
		: m_ID(-1)
		, m_PID(-1)
		, m_PPID(-1)
		, m_SubType(0)
		, m_Clicked(false)
		, m_ItemNameLocation(Vector2(4, 2))
		, m_IsLoading(false)
		, m_Where(-2)		// -1: bag 1:wc 2:cc 3:shop 4:depot 5:room 6:other bag
		, m_TimeLeftType(-1)	// hour/day/month
		, m_TimeLeft(-1)		// time left
		, m_Durable(-1)		// health value
		, m_CostType(-1)		//CR or GP
		, m_Cost(-1)			//cost
		, m_Period(-1)		//Period
		, m_InPack(-1)		//equip info, in which pack
		, m_ModState(-1)
		, m_Locked(false)
	{
	}

	ItemPicture::~ItemPicture()
	{
	}
	PDE_ATTRIBUTE_GETTER(ItemPicture, ID, int)
	{
		return m_ID;
	}

	PDE_ATTRIBUTE_SETTER(ItemPicture, ID, int)
	{
		m_ID = value;
	}	

	PDE_ATTRIBUTE_GETTER(ItemPicture, PID, int)
	{
		return m_PID;
	}

	PDE_ATTRIBUTE_SETTER(ItemPicture, PID, int)
	{
		m_PID = value;
	}	

	PDE_ATTRIBUTE_GETTER(ItemPicture, PPID, int)
	{
		return m_PPID;
	}

	PDE_ATTRIBUTE_SETTER(ItemPicture, PPID, int)
	{
		m_PPID = value;
	}	

	PDE_ATTRIBUTE_GETTER(ItemPicture, SubType, int)
	{
		return m_SubType;
	}

	PDE_ATTRIBUTE_SETTER(ItemPicture, SubType, int)
	{
		m_SubType = value;
	}	

	PDE_ATTRIBUTE_GETTER(ItemPicture, Clicked, bool)
	{
		return m_Clicked;
	}

	PDE_ATTRIBUTE_SETTER(ItemPicture, Clicked, bool)
	{
		m_Clicked = value;
	}

	PDE_ATTRIBUTE_GETTER(ItemPicture, ItemName, String)
	{
		return m_ItemName;
	}

	PDE_ATTRIBUTE_SETTER(ItemPicture, ItemName, String)
	{
		if(m_ItemName == value)
			return;

		m_ItemName = value;
		Invalid();
	}

	PDE_ATTRIBUTE_GETTER(ItemPicture, ItemNameLocation, Vector2)
	{
		return m_ItemNameLocation;
	}

	PDE_ATTRIBUTE_SETTER(ItemPicture, ItemNameLocation, Vector2)
	{
		if(m_ItemNameLocation!=value)
			return;

		m_ItemNameLocation = value;
		Invalid();
	}

	PDE_ATTRIBUTE_GETTER(ItemPicture, Loading, bool)
	{
		return m_IsLoading;
	}

	PDE_ATTRIBUTE_SETTER(ItemPicture, Loading, bool)
	{
		if(m_IsLoading == value)
			return;

		m_IsLoading = value;

		Invalid();
	}

	PDE_ATTRIBUTE_GETTER(ItemPicture, Locked, bool)
	{
		return m_Locked;
	}
	PDE_ATTRIBUTE_SETTER(ItemPicture, Locked, bool)
	{
		if(m_Locked == value)
			return;

		m_Locked = value;
		Invalid();
	}

	PDE_ATTRIBUTE_GETTER(ItemPicture, CostType, int)
	{
		return m_CostType;
	}
	PDE_ATTRIBUTE_SETTER(ItemPicture, CostType, int)
	{
		if(m_CostType == value)
			return;

		m_CostType = value;
		Invalid();
	}

	PDE_ATTRIBUTE_GETTER(ItemPicture, Cost, int)
	{
		return m_Cost;
	}
	PDE_ATTRIBUTE_SETTER(ItemPicture, Cost, int)
	{
		if(m_Cost == value)
			return;

		m_Cost = value;
		Invalid();
	}

	PDE_ATTRIBUTE_GETTER(ItemPicture, Period, int)
	{
		return m_Period;
	}
	PDE_ATTRIBUTE_SETTER(ItemPicture, Period, int)
	{
		if(m_Period == value)
			return;

		m_Period = value;
		Invalid();
	}

	PDE_ATTRIBUTE_GETTER(ItemPicture, TimeLeftType, int)
	{
		return m_TimeLeftType;
	}
	PDE_ATTRIBUTE_SETTER(ItemPicture, TimeLeftType, int)
	{
		if(m_TimeLeftType!=value)
		{
			m_TimeLeftType = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(ItemPicture, TimeLeft, int)
	{
		return m_TimeLeft;
	}
	PDE_ATTRIBUTE_SETTER(ItemPicture, TimeLeft, int)
	{
		if(m_TimeLeft!=value)
		{
			m_TimeLeft = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(ItemPicture, InPack, int)
	{
		return m_InPack;
	}
	PDE_ATTRIBUTE_SETTER(ItemPicture, InPack, int)
	{
		if(m_InPack!=value)
		{
			m_InPack = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(ItemPicture, Where, int)
	{
		return m_Where;
	}
	PDE_ATTRIBUTE_SETTER(ItemPicture, Where, int)
	{
		if(m_Where != value)
		{
			m_Where = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(ItemPicture, ModState, int)
	{
		return m_ModState;
	}
	PDE_ATTRIBUTE_SETTER(ItemPicture, ModState, int)
	{
		if(m_ModState != value)
		{
			m_ModState = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(ItemPicture, UnitType, int)
	{
		return m_UnitType;
	}
	PDE_ATTRIBUTE_SETTER(ItemPicture, UnitType, int)
	{
		if(m_UnitType != value)
		{
			m_UnitType = value;
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(ItemPicture, Durable, int)
	{
		return m_Durable;
	}
	PDE_ATTRIBUTE_SETTER(ItemPicture, Durable, int)
	{
		if(m_Durable != value)
		{
			m_Durable = value;
			Invalid();
		}
	}
}

namespace Gui
{

	void ItemPicture::PaintBackground( PaintEventArgs & e )
	{
		tempc_ptr(ItemPictureSkin) skin = ptr_dynamic_cast<ItemPictureSkin>(GetSkin());

		if(skin)
		{
			if(m_IsStatic)
			{
				Skin::DrawImage(e.render, skin->GetEmptyFrame(), GetClientRect());
			}
			else if(m_IsLoading)
			{
				Skin::DrawImage(e.render, skin->GetEmptyFrame(), GetClientRect());
				Skin::DrawImage(e.render, m_LoadingImage, GetClientRect());
			}
			else
			{
				if(m_Highlighted)
					Skin::DrawImage(e.render, skin->GetHighlightFrame(), GetClientRect());
				else if(m_MousePointed)
					Skin::DrawImage(e.render, skin->GetHoverFrame(), GetClientRect());
				else
					Skin::DrawImage(e.render, skin->GetBackgroundImage(), GetClientRect());
			}
		}
	}

	void ItemPicture::OnPaint( PaintEventArgs & e )
	{
			Super::OnPaint(e);

			Core::Vector2 meSize = GetSize();
			Core::Rectangle uvrect = Core::Rectangle(0, 0, 1, 1);

			tempc_ptr(ItemPictureSkin) skin = ptr_dynamic_cast<ItemPictureSkin>(GetSkin());

			if(m_ItemName.Length()>0)
			{
				Core::String itemName = m_ItemName;
				if(m_ModState==2 && m_Where==1)
					itemName = Core::String::Format(gLang->GetTextW(L"%s(��)"), m_ItemName);
				Core::Rectangle nameRect = Core::Rectangle::LeftTop(8, 6, 180, 20);
				if(skin)
					e.render->DrawString(GetFont(), m_Highlighted?skin->GetNameHighlightColor():skin->GetNameNormalColor(), Core::ARGB(0,0,0,0), nameRect, itemName, Unit::kAlignLeftMiddle);
				else
					e.render->DrawString(GetFont(), Core::ARGB(255, 255, 255, 255), Core::ARGB(0,0,0,0), nameRect, m_ItemName, Unit::kAlignLeftMiddle);
			}

			if(m_InPack>0)
			{
				Core::Rectangle packRect = Core::Rectangle::LeftBottom(7, meSize.y-7, 60, 20);
				if(skin)
				{
					tempc_ptr(Image) packImage;
					switch(m_InPack)
					{
					case 1:
						packImage = skin->GetPackAImage();
						break;
					case 2:
						packImage = skin->GetPackBImage();
						break;
					case 3:
						packImage = skin->GetPackCImage();
						break;
					case 4:
						packImage = skin->GetPackDImage();
						break;
					case 5:
						packImage = skin->GetPackEImage();
						break;
					}
					Skin::DrawImage(e.render, packImage, packRect);
				}
				else
					e.render->DrawRectangle(packRect, uvrect, ARGB(25, 0, 255, 0));
			}
			if(skin)
			{
				Core::Rectangle tuneRect = Core::Rectangle::RightTop(meSize.x-8, 6, 47, 18);
				if( (m_ModState == 1 || m_ModState == 2) && m_Where==1)
				{
					Skin::DrawImage(e.render, skin->GetTuneYesImage(), tuneRect);
				}
			}
			if(m_Where == 3) //In shop
			{
				sharedc_ptr(Client::Font) font2 = gRender->font_manager->GetFont("simhei", 12, 0);
				if(!font2)
					font2 = GetFont();

				CStrBuf<256> buff;
				CStrBuf<256> GP_CR;

				if(m_CostType == 0)
					GP_CR.format(gLang->GetTextW(L"G��"));
				else
					GP_CR.format(gLang->GetTextW(L"��ȯ"));
				if(m_UnitType == 3)
				{
					buff.format(gLang->GetTextW(L"%s / %d��"), GP_CR.buff(), m_Period);
				}
				else
				{
					if(m_Period>0)
						buff.format(gLang->GetTextW(L"%s / %d��"), GP_CR.buff(), m_Period);
					else
						buff.format(gLang->GetTextW(L"%s / ����"), GP_CR.buff());
				}

				Core::Rectangle tempRect = Core::Rectangle(0,0,0,0);
				F32 width = GetFont()->MeasureString(tempRect, buff, -1, Unit::kAlignCenterMiddle).GetExtent().x;
//				width+=6;

				Vector2 clientSize = GetSize();
				Core::Rectangle CostRect = Core::Rectangle(clientSize.x-80-width-8, clientSize.y-26, clientSize.x-width-8, clientSize.y-6);
				Core::Rectangle UnitRect = Core::Rectangle(clientSize.x-width-8, clientSize.y-26, clientSize.x-8, clientSize.y-6);

				e.render->DrawString(font2, Core::ARGB(255, 255, 255, 255), Core::ARGB(0,0,0,0)
					, UnitRect, buff, Unit::kAlignRightBottom);

				buff.format("%d", GetCost());
				e.render->DrawString(GetFont(), Core::ARGB(255, 255, 255, 255), Core::ARGB(0,0,0,0)
					, CostRect, buff, Unit::kAlignRightBottom);
			}
			else
			{
				Vector2 clientSize = GetSize();
				Core::Rectangle TimeRect = Core::Rectangle(clientSize.x-80-55-8, clientSize.y-26, clientSize.x-8, clientSize.y-6);
				CStrBuf<256> buff;
				if(m_UnitType == 4)  //time based
				{
					switch(m_TimeLeftType)
					{
					case 1:
						buff.format(gLang->GetTextW(L"ʣ��%d����"), m_TimeLeft);
						break;
					case 2:
						buff.format(gLang->GetTextW(L"ʣ��%dСʱ"), m_TimeLeft);
						break;
					case 3:
						buff.format(gLang->GetTextW(L"ʣ��%d��"), m_TimeLeft);
						break;
					default:
						buff.format(gLang->GetTextW(L"������Ч"));
						break;
					}
					if(skin)
					{
						e.render->DrawString(GetFont(), m_Highlighted?skin->GetLeftHighlightColor():skin->GetNameNormalColor(), Core::ARGB(0,0,0,0)
							, TimeRect, buff, Unit::kAlignRightBottom);
					}
					else
					{
						e.render->DrawString(GetFont(), Core::ARGB(255, 255, 255, 255), Core::ARGB(0,0,0,0)
							, TimeRect, buff, Unit::kAlignRightBottom);
					}
				}
				else if(m_UnitType == 2)  //Damage based
				{
					if(m_Durable>=0 && m_Durable<=20)
					{
						Core::Rectangle repairRect = Core::Rectangle::LeftBottom(7, meSize.y-30, 18, 18);
						if(skin)
							Skin::DrawImage(e.render, skin->GetRepairImage(), repairRect);
						else
							e.render->DrawRectangle(repairRect, uvrect, ARGB(64, 255, 0, 0));
					}
				}
			}

			if(m_Locked)
			{
				Core::Rectangle lockRect = Core::Rectangle::LeftBottom(9, meSize.y-10, 44, 44);
				if(skin)
					Skin::DrawImage(e.render, skin->GetLockedImage(), lockRect);
				else
					e.render->DrawRectangle(lockRect, uvrect, ARGB(128, 0, 0, 0));
			}
	}

	void ItemPicture::Clear()
	{
		m_ItemName = "";
		m_CostType = -1;
		m_Cost = -1;
		m_InPack = -1;
		m_Where = -2;
		m_ModState = -1;
		m_Durable = -1;
		m_SubType = -1;
		m_UnitType = -1;
		m_TimeLeftType = -1;
		m_TimeLeft = -1;
		m_Durable = -1;
		m_CostType = -1;		//CR or GP
		m_Cost = -1;			//cost
		m_Period = -1;
		m_InPack = -1;
		m_ModState = -1;
		m_Locked = false;

		Invalid();		
	}
}

namespace Gui
{
	void OtherPortrait::OnCreate()
	{
		Control::OnCreate();
	}

	void OtherPortrait::OnDestroy()
	{
		Control::OnDestroy();
	}

	void OtherPortrait::OnPaint( PaintEventArgs & e )
	{
		if(gGame && gGame->render && gGame->render->GetLobby())
		{
			e.render->SetTexture(gGame->render->GetLobby()->GetOtherEquipMap());
			e.render->DrawRectangle(GetClientRect(), Core::Rectangle(0,0,1,1));
		}
	}

	void OtherPortrait::OnFrameUpdate(Core::EventArgs & e)
	{
		Super::OnFrameUpdate(e);
		Invalid();
	}
}