namespace Gui
{
	/// base class of ui elements
	class LobbyPList: public Control
	{
		DECLARE_PDE_OBJECT(LobbyPList, Control)

	public:
		INLINE_PDE_ATTRIBUTE_R (ChannelPlayerList,	tempc_ptr(Gui::ListTreeView));
		INLINE_PDE_ATTRIBUTE_R (FriendsPlayerList,	tempc_ptr(Gui::ListTreeView));
		INLINE_PDE_ATTRIBUTE_R (ButtonInvite,		tempc_ptr(Gui::Button));
		INLINE_PDE_ATTRIBUTE_R (ButtonJoin,			tempc_ptr(Gui::Button));
		INLINE_PDE_ATTRIBUTE_RW(Duration,			F32);
		DECLARE_PDE_ATTRIBUTE_R(SelectedPlayer,		const Core::String&);

	public:
		LobbyPList();
		~LobbyPList();
		void OnCreate();
		void OnDestroy();
		void OnPaint(PaintEventArgs & e);
		void OnFrameUpdate(EventArgs & e);
		
		void OnExpandButtonChClick(by_ptr(void) sender, InputEventArgs &e);
		void OnExpandButtonFrClick(by_ptr(void) sender, InputEventArgs &e);
// 		void OnButtonInviteClick(by_ptr(void) sender, InputEventArgs &e);
// 		void OnButtonJoinClick(by_ptr(void) sender, InputEventArgs &e);

		void ClearChannelPlayerList();
		void ClearFriendsPlayerList();

	protected:
		void ChPlayerListOnOff(bool bOn);
		void FrPlayerListOnOff(bool bOn);

	protected:
		sharedc_ptr(ListTreeView)		m_ChannelPlayerList;
		sharedc_ptr(ListTreeView)		m_FriendsPlayerList;
		sharedc_ptr(Button)				m_ButtonInvite;
		sharedc_ptr(Button)				m_ButtonJoin;
		sharedc_ptr(Label)				m_ChEmptyLabel;
		sharedc_ptr(Label)				m_FrEmptyLabel;
		
		sharedc_ptr(Control)				m_PanelCh;
		sharedc_ptr(Control)				m_PanelFr;
		sharedc_ptr(Button)				m_TitleCh;
		sharedc_ptr(Button)				m_TitleFr;
		sharedc_ptr(Label)				m_ExpandCh;
		sharedc_ptr(Label)				m_ExpandFr;
		sharedc_ptr(Icon)				m_IconPlus;
		sharedc_ptr(Icon)				m_IconMinus;

		bool							m_ChannelPCollapsed;
		bool							m_FriendsPCollapsed;

		static F32						m_Duration;
	};
}