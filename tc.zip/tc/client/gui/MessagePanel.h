namespace Client
{
	struct ChatMessage;
}

namespace Gui
{
	class MessagePanel : public Control
	{
		friend class ChatWindow;

		enum Type
		{
			Sever,
			Whisper,
		};
	public:
		DECLARE_PDE_OBJECT			(MessagePanel,		Control);
		DECLARE_PDE_ATTRIBUTE_RW	(ScrollBarWidth,	U32);
		DECLARE_PDE_ATTRIBUTE_R		(LeftGap,			const U32);
		DECLARE_PDE_ATTRIBUTE_RW	(VisibleLine,		U32);
		DECLARE_PDE_ATTRIBUTE_RW	(CursorVisible,		bool);
		DECLARE_PDE_ATTRIBUTE_RW	(MaxAllLine,		U32);
		DECLARE_PDE_ATTRIBUTE_RW	(ButtonHeight,		U32);
		DECLARE_PDE_ATTRIBUTE_RW	(ButHeight,			U32);
		DECLARE_PDE_ATTRIBUTE_R		(ClickedName,		Core::String);
		DECLARE_PDE_ATTRIBUTE_R		(Click_Name,		Core::String);
		DECLARE_PDE_ATTRIBUTE_W		(ChatWindow,		weakc_ptr(ChatWindow));

		DECLARE_PDE_EVENT(EventClick_Name,		EventArgs);

	public:
		MessagePanel(void);

		virtual ~MessagePanel(void);

		void OnCreate();

		void OnLayout(EventArgs & e);

		void OnPaint(PaintEventArgs & e);

		void OnComplementaryDraw(PaintEventArgs & e, F32 opacity);

		void OnInputEvent(InputEventArgs & e);

		void OnKeyEvent(InputEventArgs & e);

		void OnFrameUpdate(EventArgs & e);

		void OnMouseLeave(InputEventArgs & e);

	public:
		void OnLinkClick(Client::InputEventArgs &e);

		void OnLinkRightClick(Client::InputEventArgs &e);

	public:
		void AddLineNew(const Core::String &string,uint type);

		void AddLine(const ChatWindow::Line & line);

		void AddLineParent(const ChatWindow::Line & line);

		void LinePart(ChatWindow::Line & line);

		void ClearLines();

		void DirtyLines(bool scrollToBottom = true);

		void ScrollToEnd();

		void EventSizeChanged();

		void Reset();

	private:
		void OnButtonClick_down(by_ptr(void) sender, InputEventArgs & e);
		void OnButtonClick_up(by_ptr(void) sender, InputEventArgs & e);
		void OnWhisper_ButtonClick(by_ptr(void) sender, InputEventArgs & e);
		void CopyText();
		void DrawBtn(Core::Rectangle rect,int i);

	private:
		U32										m_ScrollBarWidth;
		const U32								m_LeftGap;
		U32										m_ButtonHeight;
		U32										m_ButHeight;
		U32										m_VisibleLine;
		U32										m_LineHeight;
		Core::String							m_ClickedName;
		Core::String							m_Click_Name;
		U32										m_PointedLine;
		bool									m_CursorVisible;
		F64										m_CursorTime;
		bool									m_Selecting	:1;
		S32										m_SelectedLine;
		size_t									m_SelectedStart;
		size_t									m_SelectedEnd;
		Core::Vector2							m_SelectedLeftTop;
		Core::Vector2							m_SelectedRightBottom;
		Core::Rectangle							m_IconRect;
		U32										m_MaxAllLine;
		bool									m_ReSet;

		U32										m_Channel;
		U32										m_AllLinesCount;
		Core::Array<ChatWindow::Line>			m_AllLines_Parent;
		Core::Array<ChatWindow::Line>			m_AllLines;
		Core::Array<ChatWindow::Line>			m_ShowLines;

		sharedc_ptr(ScrollBar)					m_ScrollBar;
		sharedc_ptr(Button)						m_Button_down;
		sharedc_ptr(Button)						m_Button_up;
		sharedc_ptr(Icon)						m_Icon;
		weakc_ptr(ChatWindow)					m_ChatWindow;
	};
}