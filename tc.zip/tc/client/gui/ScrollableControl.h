namespace Gui
{
	class ScrollBar;

	/// Defines a base class for controls that support auto-scrolling behavior.
	class ScrollableControl : public Control
	{
	public:
		/// scrollbar display
		enum ScrollbarDisplay
		{
			kAuto,
			kVisible,
			kHide,
		};

	public:
		// constructor.
		ScrollableControl();

		// destructor.
		~ScrollableControl();

	public:
		DECLARE_PDE_OBJECT(ScrollableControl, Control);
		DECLARE_PDE_ATTRIBUTE_RW(AutoScroll,			bool);
		DECLARE_PDE_ATTRIBUTE_RW(HScrollBarMove,			bool);
		DECLARE_PDE_ATTRIBUTE_RW(AutoScrollPosition,	const Core::Vector2 &);
		DECLARE_PDE_ATTRIBUTE_RW(AutoScrollMinSize,		const Core::Vector2 &);

		DECLARE_PDE_ATTRIBUTE_RW(HScrollBarDisplay,		ScrollbarDisplay);
		DECLARE_PDE_ATTRIBUTE_RW(VScrollBarDisplay,		ScrollbarDisplay);
		
		DECLARE_PDE_ATTRIBUTE_RW(VScrollBarHeight,		F32);
		DECLARE_PDE_ATTRIBUTE_RW(VScrollBarWidth,		F32);
		DECLARE_PDE_ATTRIBUTE_RW(HScrollBarWidth,		F32);
		DECLARE_PDE_ATTRIBUTE_RW(VScrollBarButtonSize,	F32);
		DECLARE_PDE_ATTRIBUTE_RW(HScrollBarButtonSize,	F32);
		DECLARE_PDE_ATTRIBUTE_RW(Default_Size,	F32);
		DECLARE_PDE_ATTRIBUTE_RW(Default_Width,	F32);
		DECLARE_PDE_ATTRIBUTE_RW(VScrollBarPos,			Core::Vector2);
		DECLARE_PDE_ATTRIBUTE_R (VscrollBarValue,		F32);

		DECLARE_PDE_ATTRIBUTE_RW (Border,				Core::Vector4);
		OVERRIDE_PDE_ATTRIBUTE_R (DisplayPadding,		Core::Vector4);
		OVERRIDE_PDE_ATTRIBUTE_R (ClientRect,			Core::Rectangle);

	public:
		/// on autosize
		virtual void OnAutoSize(AutoSizeEventArgs & e);

		/// layout event
		virtual void OnLayout(EventArgs & e);

        /// on input event
        virtual void OnInputEvent(InputEventArgs & e);

		/// on paint background
		virtual void OnPaint(PaintEventArgs & e);

		/// on frame update
		virtual void ScrollableControl::OnFrameUpdate(EventArgs & e);

	private:
		void ScrollBar_OnValueChanged(by_ptr(void) sender, EventArgs & e);
		void InvalidVScrollBar(void);
		void InvalidHScrollBar(void);

	public:
		/// scroll to view
		void ScrollToView(const Core::Rectangle & rect);



	protected:
		Core::Vector2	m_AutoScrollMinSize;
		Core::Vector2	m_ClientSize;

		bool	m_AutoScroll			: 1;
		bool	m_MiddleMouseDrag		: 1;
		bool	m_HScrollBarMove;
		
		F32				m_VScrollBarHeight;
		F32				m_VScrollBarWith;
		F32				m_HScrollBarWith;
		F32				m_VScrollButtonSize;
		F32				m_HScrollButtonSize;
		F32				m_Default_Size;
		F32				m_Default_Width;
		ScrollbarDisplay m_HScrollBarDisplay;
		ScrollbarDisplay m_VScrollBarDisplay;

		F32				m_VscrollBarValue;

		sharedc_ptr(ScrollBar)	m_HScrollBar;
		sharedc_ptr(ScrollBar)	m_VScrollBar;
		Core::Vector2			m_VScrollBarPos;
		Core::Vector4			m_Border;
	};
}


namespace Gui
{
	class ScrollableControlSkin : public ControlSkin
	{
	public:
		ScrollableControlSkin()
		{}

	public:
		INLINE_PDE_ATTRIBUTE_RW(ActiveBgImage,			tempc_ptr(Image));

		INLINE_PDE_ATTRIBUTE_RW(UpButtonNormalImage,	tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(UpButtonHoverImage,		tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(UpButtonDownImage,		tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(UpButtonDisabledImage,	tempc_ptr(Image));

		INLINE_PDE_ATTRIBUTE_RW(DownButtonNormalImage,		tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(DownButtonHoverImage,		tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(DownButtonDownImage,		tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(DownButtonDisabledImage,	tempc_ptr(Image));

		INLINE_PDE_ATTRIBUTE_RW(LeftButtonNormalImage,		tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(LeftButtonHoverImage,		tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(LeftButtonDownImage,		tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(LeftButtonDisabledImage,	tempc_ptr(Image));

		INLINE_PDE_ATTRIBUTE_RW(RightButtonNormalImage,		tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(RightButtonHoverImage,		tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(RightButtonDownImage,		tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(RightButtonDisabledImage,	tempc_ptr(Image));

		INLINE_PDE_ATTRIBUTE_RW(VSliderNormalImage,		tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(VSliderHoverImage,		tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(VSliderDownImage,		tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(VSliderDisabledImage,	tempc_ptr(Image));

		INLINE_PDE_ATTRIBUTE_RW(HSliderNormalImage,		tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(HSliderHoverImage,		tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(HSliderDownImage,		tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(HSliderDisabledImage,	tempc_ptr(Image));

		INLINE_PDE_ATTRIBUTE_RW(VBarBackgroundImage,			tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(VBarDisabledBackgroundImage,	tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(HBarBackgroundImage,			tempc_ptr(Image));

		INLINE_PDE_ATTRIBUTE_RW(BarCornerImage,			tempc_ptr(Image));

	private:
		sharedc_ptr(Image) m_ActiveBgImage;

		sharedc_ptr(Image) m_UpButtonNormalImage;
		sharedc_ptr(Image) m_UpButtonHoverImage;
		sharedc_ptr(Image) m_UpButtonDownImage;	
		sharedc_ptr(Image) m_UpButtonDisabledImage;

		sharedc_ptr(Image) m_DownButtonNormalImage;
		sharedc_ptr(Image) m_DownButtonHoverImage;
		sharedc_ptr(Image) m_DownButtonDownImage;	
		sharedc_ptr(Image) m_DownButtonDisabledImage;

		sharedc_ptr(Image) m_LeftButtonNormalImage;
		sharedc_ptr(Image) m_LeftButtonHoverImage;
		sharedc_ptr(Image) m_LeftButtonDownImage;	
		sharedc_ptr(Image) m_LeftButtonDisabledImage;

		sharedc_ptr(Image) m_RightButtonNormalImage;
		sharedc_ptr(Image) m_RightButtonHoverImage;
		sharedc_ptr(Image) m_RightButtonDownImage;	
		sharedc_ptr(Image) m_RightButtonDisabledImage;

		sharedc_ptr(Image) m_VSliderNormalImage;
		sharedc_ptr(Image) m_VSliderHoverImage;
		sharedc_ptr(Image) m_VSliderDownImage;	
		sharedc_ptr(Image) m_VSliderDisabledImage;
	
		sharedc_ptr(Image) m_HSliderNormalImage;
		sharedc_ptr(Image) m_HSliderHoverImage;
		sharedc_ptr(Image) m_HSliderDownImage;	
		sharedc_ptr(Image) m_HSliderDisabledImage;

		sharedc_ptr(Image) m_VBarBackgroundImage;
		sharedc_ptr(Image) m_VBarDisabledBackgroundImage;
		sharedc_ptr(Image) m_HBarBackgroundImage;
		sharedc_ptr(Image) m_BarCornerImage;
	};
}