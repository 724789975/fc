namespace Gui
{
	/// base class of ui elements
	class  ProportionBar : public Control
	{
		DECLARE_PDE_OBJECT(ProportionBar, Control)

	public:
		DECLARE_PDE_ATTRIBUTE_RW	(Icon,			tempc_ptr(ProportionIcon));
		DECLARE_PDE_ATTRIBUTE_RW	(TextAlign,		Client::Unit::Align);
		DECLARE_PDE_ATTRIBUTE_RW	(MaxValue,		F32);
		DECLARE_PDE_ATTRIBUTE_RW	(CurrentValue,	F32);
		DECLARE_PDE_ATTRIBUTE_R		(TextPadding,		Core::Vector4);

	public:
		///constructor
		ProportionBar();

		///destructor
		~ProportionBar();

		/// on paint
		virtual void OnPaint(PaintEventArgs & e);

		/// on input event
		virtual void OnInputEvent(InputEventArgs & e);

		// on frame update
		virtual void OnFrameUpdate(EventArgs & e);

		
	private:
		Client::Unit::Align		m_TextAlign;
		sharedc_ptr(ProportionIcon)		m_Icon;
		F32						m_CurrentValue;
		F32						m_TempValue;
		F32						m_MaxValue;
	};
}

namespace Gui
{
	class ExperienceBar : public Control
	{
		DECLARE_PDE_OBJECT(ExperienceBar, Control)
	public:
		DECLARE_PDE_ATTRIBUTE_RW	(Icon,			tempc_ptr(ProportionIcon));
		DECLARE_PDE_ATTRIBUTE_RW	(BaseValue,		F32);
		INLINE_PDE_ATTRIBUTE_RW		(PlayerName,	const Core::String &);
		DECLARE_PDE_ATTRIBUTE_RW	(Mini,			bool);

	public:
		///constructor
		ExperienceBar();

		///destructor
		~ExperienceBar();

		virtual void OnCreate();

		/// on paint
		virtual void OnPaint(PaintEventArgs & e);

		// on frame update
		virtual void OnFrameUpdate(EventArgs & e);

		void	AddLevel(F32 fValue, const Core::String& rank, tempc_ptr(Gui::Icon) rankIcon);

		void	SetNewValue(F32 fValue);

		void	ClearLevels();

		void	Ready();

		void	Start();

		void	ForceStopSound();
	private:
		Client::Unit::Align		m_TextAlign;
		sharedc_ptr(ProportionIcon)		m_Icon;
		F32						m_BaseValue;
		F32						m_NewValue;
		F32						m_TempValue;
		F32						m_TextCurValue;
		F32						m_TextMaxValue;
		int						m_TextCurLevel;
		Core::String			m_PlayerName;
		Core::Array<F32>		m_Levels;
		Core::Array<Core::String> m_Ranks;
		Core::Array<sharedc_ptr(Gui::Icon)> m_RankIcons;
		bool					m_Running;
		bool					m_Mini;

		FMOD::Event* m_audio_exp;
		FMOD::Event* m_audio_levelup;
	};
}

namespace Gui
{
	/// base class of ui elements
	class  CompareBar : public Control
	{
		DECLARE_PDE_OBJECT(CompareBar, Control)

	public:
		DECLARE_PDE_ATTRIBUTE_RW	(Icon,			tempc_ptr(CompareIcon));
		DECLARE_PDE_ATTRIBUTE_RW	(TextAlign,		Client::Unit::Align);
		DECLARE_PDE_ATTRIBUTE_RW	(MaxValue,		F32);
		DECLARE_PDE_ATTRIBUTE_RW	(BaseValue,		F32);
		DECLARE_PDE_ATTRIBUTE_RW	(ComparativeValue, F32);
		DECLARE_PDE_ATTRIBUTE_RW	(Speed, F32);
		DECLARE_PDE_ATTRIBUTE_R		(TextPadding,		Core::Vector4);

	public:
		///constructor
		CompareBar();

		///destructor
		~CompareBar();

		/// on paint
		virtual void OnPaint(PaintEventArgs & e);

		/// on input event
		virtual void OnInputEvent(InputEventArgs & e);

		// on frame update
		virtual void OnFrameUpdate(EventArgs & e);

	public:
		void	Increase(F32 IncValue);
		void	Decrease(F32 DecValue);
		void	ResetBaseValue(F32 baseValue);

	private:
		Client::Unit::Align		m_TextAlign;
		sharedc_ptr(CompareIcon)		m_Icon;
		F32						m_BaseValue;
		F32						m_TempValue;
		F32						m_ComparativeValue;
		F32						m_Speed;
		F32						m_MaxValue;
	};
}