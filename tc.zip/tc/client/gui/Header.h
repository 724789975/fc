namespace Gui
{
	class HeaderSkin : public ControlSkin
	{
	public:
		INLINE_PDE_ATTRIBUTE_RW(NormalImage,	tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(HoverImage,		tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(DownImage,		tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(DisabledImage,	tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(SortNormalImage,	tempc_ptr(Image));
		INLINE_PDE_ATTRIBUTE_RW(SortReverseImage,	tempc_ptr(Image));

	private:
		sharedc_ptr(Image) m_NormalImage;
		sharedc_ptr(Image) m_HoverImage;
		sharedc_ptr(Image) m_DownImage;
		sharedc_ptr(Image) m_DisabledImage;
		sharedc_ptr(Image) m_SortNormalImage;
		sharedc_ptr(Image) m_SortReverseImage;
	};
}

namespace Gui
{
	/// base class of ui elements
	class Header : public Control
	{
		DECLARE_PDE_OBJECT(Header, Control)

	public:
		struct HeaderItem
		{
			Core::String	Text;
			U32				DisplayIndex;
			F32				Width;
			F32				Pos;
			bool			PushDown;
			bool			Hover;
			Client::Unit::Align	Align;
			sharedc_ptr(ComboBox)	m_comboBox;
		};

	public:
		Header();
		~Header();

	public:
		DECLARE_PDE_EVENT(EventItemChange,			EventArgs);
		DECLARE_PDE_EVENT(EventSplitDoubleClick,	HeaderEventArgs);
		DECLARE_PDE_EVENT(EventItemClick,			HeaderEventArgs);

	public:
		DECLARE_PDE_ATTRIBUTE_RW	(Clickable,		bool);
		DECLARE_PDE_ATTRIBUTE_RW	(Movable,		bool);
		DECLARE_PDE_ATTRIBUTE_RW	(Sizeable,		bool);
		DECLARE_PDE_ATTRIBUTE_R		(ItemCount,		U32);
		DECLARE_PDE_ATTRIBUTE_R		(AllWidth,		F32);
		DECLARE_PDE_ATTRIBUTE_RW	(SortID,		S32);
		DECLARE_PDE_ATTRIBUTE_RW	(SortReverse,	bool);
		DECLARE_PDE_ATTRIBUTE_RW	(CurrentSorter, tempc_ptr(ListTreeView::SortFunc));
		DECLARE_PDE_ATTRIBUTE_R		(Items,			const Core::Array<HeaderItem> &);
		DECLARE_PDE_ATTRIBUTE_R		(DefaultSize,	Core::Vector2) { return Core::Vector2(100, 19); }

	public:
		/// on layout event
		virtual void OnLayout(EventArgs & e);

		/// on paint
		virtual void OnPaint(PaintEventArgs & e);

        /// on input event
        virtual void OnInputEvent(InputEventArgs & e);

		/// on item change
		virtual void OnItemChange(EventArgs & e);

		/// on split doubleclick event
		virtual void OnSplitDoubleClick(HeaderEventArgs & e);

		/// on click item event
		virtual void OnItemClick(HeaderEventArgs & e);

		virtual void OnComboBoxValueChanged(by_ptr(void) sender, EventArgs & e);

		void		 UpdateComboBoxes();

		void		 ReapplyAllConditions();

	private:
		HeaderItem * DisplayIndexToItem(U32 displayIndex);

		U32 GetSplitItem(F32 pos);

		U32 GetPointItem(const Core::Vector2 & pos);

		void ResetPos();

		bool IsMove(U32 des, U32 src, const Core::Vector2 & pos);

	public:
		U32 AddItem(const Core::String & text, F32 width = 60.f, bool bFilter = false, Client::Unit::Align itemAlign = Client::Unit::kAlignLeftMiddle);
		
		void DeleteAll();

		F32 GetPos(U32 index);

		F32 GetWidth(U32 index);

		Client::Unit::Align GetAlign(U32 index);

		U32 DisplayIndexToIndex(U32 index);

		U32 IndexToDisplayIndex(U32 displayIndex);

		const Core::String & GetText(U32 index);

		void SetWidth(U32 index, F32 width);

		void SetText(U32 index, const Core::String & text);

		void SetAlign(U32 index, Client::Unit::Align align);

		void SetDisplayIndex(U32 index, U32 displayIndex);

		HeaderItem * IndexToItem(U32 index);

		/// pos to Index
		U32 PosToIndex(F32 pos);

	private:
		Core::Array<HeaderItem>	m_Items;
		Core::Array<HeaderItem*> m_Filters;
		U32						m_SplitID;
		U32						m_MoveID;
		S32						m_SortID;
		bool					m_SortReverse	: 1;
		bool					m_PushDown	: 1;
		bool					m_Clickable	: 1;
		bool					m_Movable	: 1;
		bool					m_Moved		: 1;
		bool					m_Sizeable	: 1;
		sharedc_ptr(ListTreeView::SortFunc)	m_CurrentSorter;
	};
}