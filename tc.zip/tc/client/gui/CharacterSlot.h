namespace Gui
{
	/// base class of ui elements
	class  CharacterPlate : public Button
	{
		DECLARE_PDE_OBJECT(CharacterPlate, Button)

	public:
		DECLARE_PDE_ATTRIBUTE_RW(ID,			U32);
		DECLARE_PDE_ATTRIBUTE_RW(Count,		U32);

	public:
		CharacterPlate();
		~CharacterPlate();

		// on paint
		virtual void OnPaint(PaintEventArgs & e);

		// on click
		virtual void OnClick(Client::InputEventArgs & e);

		void Decrease();
		void Increase();


	protected:
		sharedc_ptr(Icon)		m_IconActive;
		sharedc_ptr(Icon)		m_IconGray;

		U32						m_ID;
		U32						m_Count;
	};

	class CharacterSlot: public Button
	{
	public:
		DECLARE_PDE_OBJECT(CharacterSlot, Button);

	public:
		DECLARE_PDE_ATTRIBUTE_RW(CurrentCharacter, U32);

	public:
		CharacterSlot();
		~CharacterSlot();

		// on create
		virtual void OnCreate();

		// on frame update
		virtual void OnFrameUpdate(EventArgs & e);

		// on paint
		virtual void OnPaint(PaintEventArgs & e);

		virtual void OnPushDownChanged();

		void	Clear();

		void	Reset();

		void	OutInPosition();
		void	InInPosition();

		tempc_ptr(CharacterPlate) GetCharacterPlate(U32 id);

	protected:
		sharedc_ptr(Icon)	m_Icon;
		U32					m_CurrentCharacter;

		sharedc_ptr(Label)	m_AniCharOut;
		sharedc_ptr(Label)	m_AniCharIn;
		U32					m_OldCharacter;
		U32					m_TempCharacter;
		F32					m_OldTimer;
		F32					m_NewTimer;
	};
}