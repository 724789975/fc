#include "pch.h"

using namespace Core;
using namespace Gui;
using namespace Client;

DEFINE_PDE_TYPE_ENUM(FlowLayout::Direction)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_ENUM_ITEM("kHorizontal",		FlowLayout::kHorizontal);
		ADD_PDE_ENUM_ITEM("kVertical",			FlowLayout::kVertical);

		ADD_PDE_ENUM_CONSTRUCTOR();
	}
};




DEFINE_PDE_TYPE_CLASS(Gui::FlowLayout)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::Control);

		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_PROPERTY_RW(Direction);
		ADD_PDE_PROPERTY_RW(ControlSpace);
		ADD_PDE_PROPERTY_RW(LineSpace);
		ADD_PDE_PROPERTY_RW(ControlAlign);
		ADD_PDE_PROPERTY_RW(Align);
	}


};

REGISTER_PDE_TYPE(Gui::FlowLayout)
REGISTER_PDE_TYPE(Gui::FlowLayout::Direction);

namespace Gui
{
	FlowLayout::FlowLayout()
		: m_Direction(kHorizontal)
		, m_ControlSpace(0)
		, m_LineSpace(0)
		, m_ControlAlign(Client::Unit::kAlignTop)
		, m_Align(Client::Unit::kAlignLeftTop)
	{

	}

	FlowLayout::~FlowLayout()
	{

	}
}

//--------------------------------------------------------------------------------------
// Attribute
//--------------------------------------------------------------------------------------
namespace Gui
{
	PDE_ATTRIBUTE_GETTER(FlowLayout, Direction, FlowLayout::Direction)
	{
		return m_Direction;
	}


	PDE_ATTRIBUTE_SETTER(FlowLayout, Direction, FlowLayout::Direction)
	{
		if (m_Direction != value)
		{
			m_Direction = value;
			DirtyLayout();
		}
	}

	PDE_ATTRIBUTE_GETTER(FlowLayout, ControlSpace, F32)
	{
		return m_ControlSpace;
	}

	PDE_ATTRIBUTE_SETTER(FlowLayout, ControlSpace, F32)
	{
		if (m_ControlSpace != value)
		{
			m_ControlSpace = value;
			DirtyLayout();
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(FlowLayout, LineSpace, F32)
	{
		return m_LineSpace;
	}

	PDE_ATTRIBUTE_SETTER(FlowLayout, LineSpace, F32)
	{
		if (m_LineSpace != value)
		{
			m_LineSpace = value;
			DirtyLayout();
			Invalid();
		}
	}

	PDE_ATTRIBUTE_GETTER(FlowLayout,ControlAlign, Client::Unit::Align)
	{
		return m_ControlAlign;
	}


	PDE_ATTRIBUTE_SETTER(FlowLayout, ControlAlign, Client::Unit::Align)
	{
		if (m_ControlAlign != value)
		{
			m_ControlAlign = value;
			DirtyLayout();
		}
	}

	PDE_ATTRIBUTE_GETTER(FlowLayout, Align, Client::Unit::Align)
	{
		return m_Align;
	}


	PDE_ATTRIBUTE_SETTER(FlowLayout, Align, Client::Unit::Align)
	{
		if (m_Align != value)
		{
			m_Align = value;
			DirtyLayout();
		}
	}
}

namespace Gui
{
	void FlowLayout::OnLayout(EventArgs & e)
	{
		Control::OnLayout(e);

		Core::Rectangle clientRect = m_DockClient;
		Vector2	cursor = clientRect.Min;
		Control * pAdjustNode = GetFirstChild();

		for (Control * pNode = GetFirstChild(); pNode; pNode = pNode->GetNext())
		{
			Vector4 margin = pNode->GetMargin();
			Vector2 size = pNode->GetSize() + Vector2(margin.x + margin.z, margin.y + margin.w);

			if (!pNode->GetVisible() || pNode->GetDock() != kDockNone)
				continue;

			Vector2 location = cursor;

			switch (m_Direction)
			{
			case kHorizontal:
				{
					if ((location.x + size.x) > clientRect.Max.x)
					{
						location = clientRect.Min;

						while (pAdjustNode != pNode)
						{
							if (pAdjustNode->GetVisible() && pAdjustNode->GetDock() == kDockNone)
							{
								S32 offsetX = (m_Align & Client::Unit::kAlignHorizontalMask) * (clientRect.Max.x - cursor.x + m_ControlSpace) / 2;
								S32 offsetY = ((m_ControlAlign & Client::Unit::kAlignVerticalMask)>>4)  * (clientRect.Min.y - cursor.y - m_LineSpace - pAdjustNode->GetSize().y - pAdjustNode->GetMargin().y - pAdjustNode->GetMargin().w) / 2;

								pAdjustNode->SetLocation(pAdjustNode->GetLocation() + Vector2(offsetX, offsetY));
							}
							pAdjustNode = pAdjustNode->GetNext();
						}
					}

					cursor.x = location.x + size.x + m_ControlSpace;
					cursor.y = location.y;

					clientRect.Min.y = Max((cursor.y + size.y + m_LineSpace), clientRect.Min.y);
				}
				break;

			case kVertical:
				{
					if ((location.y + size.y) > clientRect.Max.y)
					{
						location = clientRect.Min;

						while (pAdjustNode != pNode)
						{
							if (pAdjustNode->GetVisible() && pAdjustNode->GetDock() == kDockNone)
							{
								S32 offsetX = (m_ControlAlign & Client::Unit::kAlignHorizontalMask) * (clientRect.Min.x - cursor.x - m_LineSpace - pAdjustNode->GetSize().x - pAdjustNode->GetMargin().x - pAdjustNode->GetMargin().z) / 2;
								S32 offsetY = ((m_Align & Client::Unit::kAlignVerticalMask) >> 4) * (clientRect.Max.y - cursor.y + m_ControlSpace) / 2;

								pAdjustNode->SetLocation(pAdjustNode->GetLocation() + Vector2(offsetX, offsetY));
							}

							pAdjustNode = pAdjustNode->GetNext();
						}
					}

					cursor.x = location.x;
					cursor.y = location.y + size.y + m_ControlSpace;

					clientRect.Min.x = Max((cursor.x + size.x + m_LineSpace), clientRect.Min.x);
				}
				break;
			}

			pNode->SetLocation(location +Vector2(margin.x, margin.y));
		}

		if (kHorizontal == m_Direction)
		{
			for(;pAdjustNode != NULL; pAdjustNode = pAdjustNode->GetNext())
			{
				if (pAdjustNode->GetVisible() && pAdjustNode->GetDock() == kDockNone)
				{
					S32 offsetX = (m_Align & Client::Unit::kAlignHorizontalMask) * (clientRect.Max.x - cursor.x + m_ControlSpace) / 2;
					S32 offsetY = ((m_ControlAlign & Client::Unit::kAlignVerticalMask)>>4) * (clientRect.Min.y - cursor.y - m_LineSpace - pAdjustNode->GetSize().y - pAdjustNode->GetMargin().y - pAdjustNode->GetMargin().w) / 2;

					pAdjustNode->SetLocation(pAdjustNode->GetLocation() + Vector2(offsetX, offsetY));
				}
			}

			for (Control* pNode = GetFirstChild(); pNode; pNode = pNode->GetNext())
			{
				if (pNode->GetVisible() && pNode->GetDock() == kDockNone)
				{
					S32 offsetY = ((m_Align & Client::Unit::kAlignVerticalMask) >> 4) * (clientRect.GetExtent().y + m_LineSpace) / 2;
					pNode->SetLocation(pNode->GetLocation() + Vector2(0,offsetY));
				}
			}
		}

		if (kVertical == m_Direction)
		{
			for(;pAdjustNode != NULL; pAdjustNode = pAdjustNode->GetNext())
			{
				if (pAdjustNode->GetVisible() && pAdjustNode->GetDock() == kDockNone)
				{
					S32 offsetX = (m_ControlAlign & Client::Unit::kAlignHorizontalMask) * (clientRect.Min.x - cursor.x - m_LineSpace - pAdjustNode->GetSize().x - pAdjustNode->GetMargin().x - pAdjustNode->GetMargin().z) / 2;
					S32 offsetY = ((m_Align & Client::Unit::kAlignVerticalMask) >> 4) * (clientRect.Max.y - cursor.y + m_ControlSpace) / 2;

					pAdjustNode->SetLocation(pAdjustNode->GetLocation() + Vector2(offsetX, offsetY));
				}
			}
			for (Control* pNode = GetFirstChild(); pNode; pNode = pNode->GetNext())
			{
				if (pNode->GetVisible() && pNode->GetDock() == kDockNone)
				{
					S32 offsetX = (m_Align & Client::Unit::kAlignHorizontalMask) * (clientRect.GetExtent().x + m_LineSpace) / 2;
					pNode->SetLocation(pNode->GetLocation() + Vector2(offsetX,0));
				}
			}

		}

		/*	UpdateAutoSize(false);*/
	}


	void FlowLayout::OnMouseEnter(InputEventArgs & e)
	{
		e.Handled = false;
	}

	void FlowLayout::OnMouseLeave(InputEventArgs & e)
	{
		e.Handled = false;
	}
}

