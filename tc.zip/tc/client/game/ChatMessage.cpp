#include "pch.h"

using namespace Core;
using namespace Client;

DEFINE_PDE_TYPE_CLASS(ChatMessage)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_FIELD(channel);
		ADD_PDE_FIELD(group);
		ADD_PDE_FIELD(sender);
		ADD_PDE_FIELD(msg);
		ADD_PDE_FIELD(group_id);
	}
};

REGISTER_PDE_TYPE(ChatMessage);