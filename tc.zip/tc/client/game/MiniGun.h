namespace Client
{
	struct MiniGunInfo : public RifleInfo
	{
		float fire_max_speed;
		float fire_start_speed;
		float fire_aceleration;
		float fire_resistance;

		MiniGunInfo()
		{
			weapon_type = kWeaponTypeMiniGun;
		}
	};

	class MiniGun : public GunBase
	{
	public:
		MiniGun(by_ptr(MiniGunInfo) info);

	public:
		DECLARE_PDE_ATTRIBUTE_R(weapon_info, tempc_ptr(MiniGunInfo))
		{
			return mini_info;
		}

	public:
		/// update
		virtual void Update(float time);

		/// update animation
		virtual void UpdateAnimation(float time);

		/// update mesh
		virtual void UpdateMesh();

		/// get pose
		virtual tempc_ptr(Pose) GetPose();

		/// initialize
		virtual void Initialize();

		/// can active
		virtual bool CanActive();

		/// active
		virtual void Active();

		/// inactive
		virtual void Inactive();

		/// get weapon type
		virtual uint GetWeaponType();
	public:
		/// fire
		virtual bool Fire();
	public:
		sharedc_ptr(MiniGunInfo)	mini_info;
		sharedc_ptr(AnimationNodeCustom) animation_gun;
		sharedc_ptr(AnimationNodeBlend) animation_blend;

		bool  IsCanFire;
		bool  IsCanRun;

		float current_speed;
		float ratio_speed;
		
	};

}