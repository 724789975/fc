namespace Client
{
	struct CureGunInfo : GunInfo
	{
		float maxdistance;
		int addblood;

		CureGunInfo()
		{
			weapon_type = kWeaponTypeCureGun;
		}
	};

	class CureGun : public GunBase, public ChangeNodeEventBase
	{
	public:
		/// constrcutor
		CureGun(by_ptr(CureGunInfo) info);
		~CureGun();

		DECLARE_PDE_ATTRIBUTE_R(weapon_info, tempc_ptr(CureGunInfo))
		{
			return CureGun_info;
		}

	public:
		/// initialize
		virtual void Initialize();

		/// get weapon type
		virtual uint GetWeaponType();

		/// udpate effect
		virtual void UpdateEffect(float time);

		///update
		virtual void Update(float time);

		//active
		virtual void Active();

		/// inactive
		virtual void Inactive();

		/// can active
		virtual bool CanActive();

		/// fire
		virtual bool Fire();

		/// fire
		virtual bool FireBase(float spread);

		/// Special abilities
		virtual void SpecialAbilities(bool keydown = false);

		/// stop fire effect
		void StopFireEffect();

		virtual void OnAnimationStartFPEvent(const Core::Identifier & groupname, int & index);
		virtual void OnAnimationStartTPEvent(const Core::Identifier & groupname, int & index);
		virtual void OnAnimationEndFPEvent(const Core::Identifier & groupname, int & index);	
		virtual void OnAnimationEndTPEvent(const Core::Identifier & groupname, int & index);

		virtual void UpdateViewerAnimation(float time);

	private:
		void DoCure();
		bool FireCheck();

	public:
		byte					cure_uid;
		byte					last_cure_uid;
		sharedc_ptr(CureGunInfo)	CureGun_info;
		FMOD::Event*			my_audio_event;
		bool					can_Special;

	private:
		sharedc_ptr(PlayerSkill)	skill;
		byte					firestate;
		bool					canfire_for_ani;
	};
}