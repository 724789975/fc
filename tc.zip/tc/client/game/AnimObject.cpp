#include "pch.h"
using namespace Core;
using namespace Client;


DEFINE_PDE_TYPE_CLASS(Client::AnimObjectInfo)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_DEFAULT_CONSTRUCTOR();
		ADD_PDE_METHOD(SetMesh);
		ADD_PDE_METHOD(BandAnimation);

		ADD_PDE_FIELD(prop_skeleton);
		ADD_PDE_FIELD(prop_animationset);
		ADD_PDE_FIELD(boxsize_x);
		ADD_PDE_FIELD(boxsize_y);
		ADD_PDE_FIELD(boxsize_z);
		ADD_PDE_FIELD(usebox);
		ADD_PDE_FIELD(band_jointname);
		ADD_PDE_FIELD(sound_name);
		ADD_PDE_FIELD(sound_play_time);
	}
};

REGISTER_PDE_TYPE(Client::AnimObjectInfo);


namespace Client
{
	// constructor
	AnimObjectInfo::AnimObjectInfo():sound_play_time(-1.f)
	{
	}

	void AnimObjectInfo::SetMesh(const Identifier & key, const Identifier & value, const U32 lod_level)
	{
		Identifier * name = mesh_set.Get(key);
		if (name && *name == value)
			return;
		mesh_set.Set(key, value);
		meshset_lod.Set(key,lod_level);
	}
	
	void AnimObjectInfo::BandAnimation(int index,const Core::Identifier & animation_name, const Core::Vector3& pos)
	{
		animation_indexs.Set(index,animation_name);
		position_indexs.Set(index,pos);
	}
}

namespace Client
{
	/// constructor
	AnimObject::AnimObject(by_ptr(AnimObjectInfo) info):play_timer(0.f)
													   ,sound_Event(NULL)
													   ,now_index(-1)
													   ,actor(NULL)
	{
		animobject_info = info;
		if (animobject_info->usebox)
		{		
			actor = PhysxSystem::CreateBox(Vector3(0,-10000,0), Vector3(animobject_info->boxsize_x, animobject_info->boxsize_y, animobject_info->boxsize_z), PhysxSystem::kStatic);
			actor->raiseBodyFlag(NX_BF_KINEMATIC);
		}
	}

	AnimObject::~AnimObject()
	{
		if (actor)
		{
			PhysxSystem::ReleaseActor(*actor);
			actor = NULL;
		}
		if(sound_Event)
		{
			sound_Event->stop();
			sound_Event->release();
		}
	}	

	void AnimObject::Update( float frame_time )
	{
		if (animation)
		{
			animation->Update(frame_time);
			if (mesh)
			{
				mesh->pose = animation->GetPose();
				mesh->Update();
			}
		}
		if (actor && animation && now_index >= 0) 
		{
			int joint_id = skeleton->GetJointId(animobject_info->band_jointname);
			Vector3 position;
			if (joint_id >= 0)
			{
				Core::Vector3 pos;
				pos = animobject_info->position_indexs.Get(now_index,pos);

				const Transform & transform = animation->GetPose()->GetJointModelPose(joint_id);
				position = transform.position + pos;
				actor->setGlobalPosition((NxVec3&)position);
				
				play_timer += frame_time;
				if (sound_Event)
				{
					if(play_timer < animobject_info->sound_play_time || animobject_info->sound_play_time < 0.f)
					{
						FMOD_VECTOR vel = {0, 0, 0};
						FmodSystem::Update3DEventPosition(sound_Event,(const FMOD_VECTOR &)position, vel);
						FMOD_EVENT_STATE audio_state = FMOD_EVENT_DEFAULT;
						sound_Event->getState(&audio_state);
						if ((audio_state & FMOD_EVENT_STATE_PLAYING) == 0)
						{
							sound_Event->start();
						}
					}
					else
					{
						sound_Event->stop();
					}
				}
			}
		}
		else
		{
			if (sound_Event)
				sound_Event->stop();
		}
	}

	void AnimObject::InitializeMesh()
	{
		mesh = ptr_new SkinMesh(MESH_KEY_SCENEPROP);
	
		if (animobject_info && mesh)
		{
			AnimObjectInfo::MeshSet::Enumerator it(animobject_info->mesh_set);
			Core::HashSet<Core::Identifier, U32>::Enumerator lod(animobject_info->meshset_lod);
			while (it.MoveNext() && lod.MoveNext())
			{
				mesh->AddPrimitive(it.Key(), it.Value(), lod.Value());
			}
		}
	}

	void AnimObject::Reset()
	{
		if (mesh)
			mesh->SetPosition(Vector3(0,-10000,0));
		if (actor)
			actor->setGlobalPosition((NxVec3&)Vector3(0,-10000,0));
		if (animation)
			animation->StopAction(true);
		now_index = -1;
		play_timer = 0.f;
		if (sound_Event)
			sound_Event->stop();
	}

	void AnimObject::Initialize()
	{
		skeleton = RESOURCE_LOAD(animobject_info->prop_skeleton, false, Skeleton);
		if (skeleton)
			animation = ptr_new AnimationNodeCustom(skeleton);
		
		SetAnimationSet(animobject_info->prop_animationset);

		InitializeMesh();
		mesh->SetPosition(Vector3(0,-10000,0));

		if(animobject_info->sound_name.Length() != 0)
		{
			sound_Event = FmodSystem::GetEvent(animobject_info->sound_name);
		}
		now_index = -1;
	}

	void AnimObject::Draw( Primitive::DrawType drawtype, bool immediate)
	{
		if (mesh)
			mesh->Draw(drawtype, immediate);
	}
	
	/// play action
	void AnimObject::PlayAction(const Core::Identifier & key)
	{
		if (animation)
			animation->PlayAction(key,0.f);
	}

	void  AnimObject::PlayActionByIndex(int index)
	{
		if (animation)
		{
			Identifier key;
			now_index = index;

			Core::Vector3 pos = animobject_info->position_indexs.Get(now_index,pos);
			mesh->SetPosition(pos);

			key = animobject_info->animation_indexs.Get(index,"");
			if (key.Length() == 0)
				LogSystem.WriteLinef("AnimObject::PlayActionByIndex(%d) error",index);
			else
				PlayAction(key);
		}
	}

	/// stop action
	void AnimObject::StopAction()
	{
		if (animation)
			animation->StopAction(true);
	}

	/// set animation set
	void AnimObject::SetAnimationSet(const char * key)
	{
		if (animation)
		{
			sharedc_ptr(AnimationSetRes) res = RESOURCE_GET_BYTYPE(RESOURCE_NAME(ANIMATION_KEY_ANIMPROPSET, key), ANIMATIONSET_TYPE, AnimationSetRes);
			if (res)
			{
				res->Load(false);
				sharedc_ptr(AnimationSet) animset = res->GetAnimationSet();
				if (gLevel->animation_manager)
					gLevel->animation_manager->AddAnimationSetRes(res->GetKey(), res);

				Array<Core::Identifier> animation_keylist = animset->GetAnimationSetKeyList();
				sharedc_ptr(AnimationNodeList) node_list = ptr_new AnimationNodeList();
				for(uint i = 0; i < animation_keylist.Size(); i++)
				{
					sharedc_ptr(AnimationNodePose) node_pose = ptr_new AnimationNodePose(skeleton);
					node_pose->SetAnimation(animation_keylist[i], animset);
					node_list->AddNode(animation_keylist[i], node_pose);
				}
				animation->SetAnimationSet(animset);
				animation->SetAnimationNode(node_list);
				StopAction();
			}
		}
	}
}