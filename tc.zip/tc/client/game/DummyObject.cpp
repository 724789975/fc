#include "pch.h"

const int EXCAVATOR_SUBTYPE = 4;
DEFINE_PDE_TYPE_CLASS(Client::DummyObjectInfo)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_METHOD(SetDummyMesh);
		ADD_PDE_METHOD(SetTurretMesh);
		ADD_PDE_METHOD(SetDummyParticle);
		ADD_PDE_METHOD(SetDummyParticleMedical);
		ADD_PDE_METHOD(SetCollBoxSize);
		ADD_PDE_METHOD(SetStartAnimation);
		ADD_PDE_METHOD(SetDummyParalysisParticle);
		ADD_PDE_METHOD(SetDummyRebornParticle);
		ADD_PDE_FIELD(dummy_skeleton);
		ADD_PDE_FIELD(dummy_animationset);
		ADD_PDE_FIELD(turret_skeleton);
		ADD_PDE_FIELD(turret_animationset);
		ADD_PDE_FIELD(dummy_die_particle);
		ADD_PDE_FIELD(turret_fire_particle);
		ADD_PDE_FIELD(build_particle);
		ADD_PDE_FIELD(start_animation);
		ADD_PDE_FIELD(start_animation_playtime);
		ADD_PDE_FIELD(destory_distance);
		ADD_PDE_FIELD(outer_width);
		ADD_PDE_FIELD(outer_height);
		ADD_PDE_FIELD(HasProtectorBox);
		ADD_PDE_FIELD(coll_box_type);
		ADD_PDE_FIELD(dummy_sound_key);
		ADD_PDE_METHOD(SetProtectorBoxSize);
		ADD_PDE_METHOD(SetProtectorBoxPosition);
		ADD_PDE_METHOD(SetDummyHPOffset);
		ADD_PDE_DEFAULT_CONSTRUCTOR();
	}
};

REGISTER_PDE_TYPE(Client::DummyObjectInfo);

namespace Client
{
	static int lua_load_resource(Lua::LuaState *L)
	{
		sharedc_ptr(Resource) resource;
		const char * key = L->ToString(1);

		if (key)
		{
			resource = Resource::Load(key, true);
		}

		L->PushPtr(resource);
		return 1;
	}

	void WriteVector3FP(short positionfp[3], const Vector3 & position)
	{
		positionfp[0] = (short)Clamp(position.x * 128.f, -32767.f, 32767.f);
		positionfp[1] = (short)Clamp(position.y * 128.f, -32767.f, 32767.f);
		positionfp[2] = (short)Clamp(position.z * 128.f, -32767.f, 32767.f);
	}

	void ReadVector3FP(short positionfp[3], Vector3 & position)
	{
		position.x = (float)positionfp[0] / 128.f;
		position.y = (float)positionfp[1] / 128.f;
		position.z = (float)positionfp[2] / 128.f;
	}

	void WriteRotationFP(short rotationfp[3], const Quaternion & rotation)
	{
		Vector3 r = rotation.GetZXY();
		rotationfp[0] = ((short)(r.x * 8192.f));
		rotationfp[1] = ((short)(r.y * 8192.f));
		rotationfp[2] = ((short)(r.z * 8192.f));
	}

	void ReadRotationFP(short rotationfp[3], Quaternion & rotation)
	{
		rotation.SetZXY(Vector3((float)rotationfp[0] / 8192.f, (float)rotationfp[1] / 8192.f, (float)rotationfp[2] / 8192.f));
	}


	void DummyObjectInfo::LoadConfig(Core::String key)
	{
		if (!gLevel)
			return;

		if (!gLevel->lua_state)
			return;

		CStrBuf<256> path;
		path.format("/weapon/dummy/%s.lua", key.Str());
		sharedc_ptr(ScriptLua) lua = RESOURCE_LOAD(path, false, ScriptLua);

		if (lua)
		{
			Lua::LuaState *L = Lua::LuaState::NewState();
			if (L->LoadBuffer(lua->GetBuffer(), lua->GetSize(), path) == 0)
			{
				L->NewTable();
				L->PushPtr(ptr_static_cast<DummyObjectInfo>(this));
				L->SetField(-2, "dummy");

				const static Identifier type_Vector3_name = "Core.Vector3";
				tempc_ptr(PdeTypeInfo) type_info = PdeTypeInfo::FromName(type_Vector3_name);

				if (type_info)
				{
					L->PushPtr(type_info->GetConstructor());
					L->SetField(-2, "Vector3");
				}

				const static Identifier type_Quaternion_name = "Core.Quaternion";
				type_info = PdeTypeInfo::FromName(type_Quaternion_name);

				if (type_info)
				{
					L->PushPtr(type_info->GetConstructor());
					L->SetField(-2, "Quaternion");
				}

				L->PushCFunction(lua_load_resource);
				L->SetField(-2, "texture");

				L->SetFenv(-2);

				if (L->DoCall(0, 0))
				{
					const char *msg = L->ToString(-1);
					if (msg) Console.WriteLine(msg);
					L->Pop(1);
				}

			}
			else
			{
				const char *msg = L->ToString(-1);
				if (msg) Console.WriteLine(msg);
				L->Pop(1);
			}
			L->Close();
		}
	}




	DummyObjectInfo::DummyObjectInfo()
	{
		coll_box_size = Vector3(1,1,1);
		coll_box_type = 0;
		destory_distance = 100.f;
		outer_width =2;
		outer_height =2;
		HasProtectorBox =false;
		dummy_hp_offset = Vector3(0.f, 1.f, 0.f);

	}

	void DummyObjectInfo::SetCollBoxSize(float x, float y, float z)
	{
		coll_box_size = Vector3(x, y, z);
	}
	void DummyObjectInfo::SetProtectorBoxSize(float x, float y, float z)
	{
		protector_box_size = Vector3(x, y, z);
		HasProtectorBox =true;
	}
	void DummyObjectInfo::SetProtectorBoxPosition(float x, float y, float z)
	{
		protector_box_pos =Vector3(x, y, z);
		HasProtectorBox =true;
	}
	void DummyObjectInfo::SetDummyMesh(const Identifier & key, const Identifier & value, const U32 lod_level, int _level)
	{
		if(_level != 0 && _level != level)
			return;

		if (!gRender->lod_control->HasLod() && lod_level > 0)
			return;

		Identifier * name = dummy_mesh_set[lod_level].Get(key);
		if (name && *name == value)
			return;

		dummy_mesh_set[lod_level].Set(key, value);
	}

	void DummyObjectInfo::SetDummyHPOffset(float x, float y, float z)
	{
		dummy_hp_offset.x = x;
		dummy_hp_offset.y = y;
		dummy_hp_offset.z = z;
	}

	void DummyObjectInfo::SetTurretMesh(const Core::Identifier & key, const Core::Identifier & value, const U32 lod_level, int _level)
	{
		if(_level != 0 && _level != level)
			return;

		if (!gRender->lod_control->HasLod() && lod_level > 0)
			return;

		Identifier * name = turret_mesh_set[lod_level].Get(key);
		if (name && *name == value)
			return;

		turret_mesh_set[lod_level].Set(key, value);
	}

	void DummyObjectInfo::SetDummyParticle(const Core::Identifier & value, const int _level, const Core::Identifier & value2)
	{	
		if(_level != 0 && _level != level)
			return;

		dummy_particle_name = value;
		dummy_particle_bone = value2;

	}

	void DummyObjectInfo::SetDummyParalysisParticle(const Core::Identifier & value, const int _level, const Core::Identifier & value2)
	{
		if(_level != 0 && _level != level)
			return;

		dummy_paralysis_name = value;
		dummy_paralysis_bone = value2;
	}

	void DummyObjectInfo::SetDummyRebornParticle(const Core::Identifier & value, const int _level, const Core::Identifier & value2)
	{
		if(_level != 0 && _level != level)
			return;

		dummy_reborn_name = value;
		dummy_reborn_bone = value2;
	}

	void DummyObjectInfo::SetDummyParticleMedical(const Core::Identifier & value, const int _level)
	{	
		if(_level != 0 && _level != level)
			return;

		dummy_particle_medical_name = value;
	}

	void DummyObjectInfo::SetStartAnimation(const Core::Identifier & value, float time)
	{
		start_animation = value;
		start_animation_playtime = time;
	}

	tempc_ptr(DummyObject) DummyObject::FromNxActor(NxActor & actor)
	{
		if(actor.userData)
		{
			//temp hack
			Object * obj = (Object*)actor.userData;

			if (obj)
			{
				return ptr_dynamic_cast<DummyObject>(obj);
			}

		}

		return NullPtr;
	}


	DummyObject::DummyObject():visible(true)
							  ,need_update(true)
							  ,sync_master(false)
							  ,sync_dirty(false)
							  ,sync_time(0)
							  ,sync_data_length(0)
							  ,isdead(false)
							  ,owner_id(0)
							  ,dummy_actor(NULL)
							  ,protector_actor(NULL)
							  ,life_time(100000)
							  ,type(DUMMY_BASE)
							  ,sub_type(0)
							  ,hp(0)
							  ,is_on_moving(false)
							  ,need_stepfather(false)
							  ,owner_team(0)
							  ,can_hurt(false)
							  ,freeze_count(0)
							  ,freeze(false)
							  ,freeze_timer(0.f)
							  ,respawn_time(0.f)
							  ,idle_sound(NULL)
	{
	}

	/// destructor
	DummyObject::~DummyObject()
	{
		ReleasePhysx();
		if (idle_sound)
		{
			idle_sound->stop(true);
		}
	}

	bool DummyObject::Create(by_ptr(DummyObjectInfo) info, const DummyBaseCreateInfo& create_info)
	{
		dummyobjectinfo = info;
		owner_id = info->owner_id;

		freeze_count = create_info.freeze_count;
		respawn_time = create_info.respawn_time;

		type = DUMMY_BASE;
		m_szResKey =create_info.tower_key;
		return true;
	}

	bool DummyObject::CreateServer(by_ptr(DummyObjectInfo) info, const ServerDummyCreateInfo& create_info)
	{
		dummyobjectinfo = info;
		owner_id = info->owner_id;
		type = DUMMY_SERVER_NO_OWNER;
		m_szResKey =create_info.res_key;
		return true;
	}

	void DummyObject::CreatePhysx()
	{
		if(dummyobjectinfo->coll_box_type == 0)
		{
			dummy_actor = PhysxSystem::CreateCapsuleCCD(Vector3(0.f, -10000.f, 0.f), dummyobjectinfo->coll_box_size.y, dummyobjectinfo->coll_box_size.x, PhysxSystem::kStatic);
		}
		else
		{
			dummy_actor = PhysxSystem::CreateBoxCCD(Vector3(0.f, -10000.f, 0.f), dummyobjectinfo->coll_box_size, PhysxSystem::kStatic);
		}

		if(dummy_actor)
		{
			dummy_actor->raiseBodyFlag(NX_BF_KINEMATIC);
			dummy_actor->userData = this;
		}

		if(dummyobjectinfo->HasProtectorBox)
		{
			//dummyobjectinfo->protector_box_size =Vector3(4,1.5f, 0.1f);
			protector_actor = PhysxSystem::CreateBoxCCD(Vector3(0.f, -10000.f, 0.f), dummyobjectinfo->protector_box_size * 0.5f, PhysxSystem::kStatic);
			if(protector_actor)
			{
				protector_actor->raiseBodyFlag(NX_BF_KINEMATIC);
				protector_actor->userData = this;
			}
		}
	}

	void DummyObject::ReleasePhysx()
	{
		if(dummy_actor)
		{
			PhysxSystem::ReleaseActor(*dummy_actor);
			dummy_actor = NULL;
		}
		if(protector_actor)
		{
			PhysxSystem::ReleaseActor(*protector_actor);
			protector_actor = NULL;
		}
	}	

	void DummyObject::Initialize()
	{
		if(!gLevel)
			return;
		SetAnimationSet();

		InitializeMesh();

		CreatePhysx();

		hp = dummyobjectinfo->hp;

		sync_data.Clear();

		DummySyncData & sync = sync_data.PushBack();

		sync.time = 0;
		WriteVector3FP(sync.position, Vector3(0, -10000, 0));
		WriteRotationFP(sync.rotation, Quaternion::kIdentity);
		WriteVector3FP(sync.base_position, Vector3(0, -10000, 0));
		
		sync.hp = hp;

		SetRotation(Quaternion::kIdentity);
		SetPosition(Vector3(0, -10000, 0));
		
		tempc_ptr(Character) c = gLevel->GetCharacter(owner_id);
		if (c)
		{
			static const char szTeam[2] = {'r', 'b'};

			if (dummyobjectinfo->dummy_particle_name.Length() > 0 && c)
			{
				if (gLevel->GetPlayer() == c)
				{
					Core::String name = Core::String::Format("%s_%c", dummyobjectinfo->dummy_particle_name, szTeam[gLevel->GetCharacter(owner_id)->GetTeam() & 1]);
					dummy_particle = ptr_new ParticleSystem(name, false);
					dummy_particle->SetEnable(true);
				}	
			}

			if (dummyobjectinfo->dummy_particle_medical_name.Length() > 0)
			{
				Core::String name = Core::String::Format("%s_%c", dummyobjectinfo->dummy_particle_medical_name, szTeam[gLevel->GetCharacter(owner_id)->GetTeam() & 1]);
				dummy_medical_particle = ptr_new ParticleSystem(name, false);
				dummy_medical_particle->SetEnable(true);
			}

			damage_particle = ptr_new ParticleSystem("num");

			boostdamage_particle = ptr_new ParticleSystem("num_crit");
		}
		else
		{
			if (dummyobjectinfo->dummy_particle_name.Length() > 0)
			{
				dummy_particle = ptr_new ParticleSystem(dummyobjectinfo->dummy_particle_name, false);
				dummy_particle->SetEnable(true);
			}

			if (dummyobjectinfo->dummy_particle_medical_name.Length() > 0)
			{
				dummy_medical_particle = ptr_new ParticleSystem(dummyobjectinfo->dummy_particle_medical_name, false);
				dummy_medical_particle->SetEnable(true);
			}

			damage_particle = ptr_new ParticleSystem("num");

			boostdamage_particle = ptr_new ParticleSystem("num_crit");
		}

		if (dummyobjectinfo->dummy_paralysis_name.Length() > 0)
		{
			dummy_paralysis_particle = ptr_new ParticleSystem(dummyobjectinfo->dummy_paralysis_name, false);
		}
		if (dummyobjectinfo->dummy_reborn_name.Length() > 0)
		{
			dummy_reborn_particle = ptr_new ParticleSystem(dummyobjectinfo->dummy_reborn_name, false);
		}

		if (dummyobjectinfo->dummy_sound_key.Length() > 0)
		{
			idle_sound = FmodSystem::GetEvent(String::Format("bj/weapon/3d/%s/idle", dummyobjectinfo->dummy_sound_key.Str() ) );
		}
		
	}

	bool DummyObject::CheckGrenade(const Core::Vector3 & pos, float & distance)
	{
		NxRaycastHit hit;

		if (dummy_actor)
		{
			NxRay ray;
			ray.orig = (const NxVec3 &)pos;
			ray.dir = dummy_actor->getGlobalPosition() - (const NxVec3 &)pos;
			ray.dir.normalize();

			uint group_id = 0;
			group_id |= 1 << PhysxSystem::kStatic;
			group_id |= 1 << PhysxSystem::kPlayer;
			group_id |= 1 << PhysxSystem::kStaticRaycast;
			group_id |= 1 << PhysxSystem::kGroupVehicle;
			NxShape* shape = gPhysxScene->raycastClosestShape(ray, NX_ALL_SHAPES, hit, group_id);

			if (shape)
			{
				NxActor& raycast_actor = shape->getActor();
				if (raycast_actor.userData == dummy_actor->userData)
				{
					distance = hit.distance;
					return true;
				}
					
			}
		}

		return false;
	}

	void DummyObject::UpdateAnimation(float frame_time)
	{
		if (dummy_animation)
		{
			dummy_animation->Update(frame_time);
			if (dummy_mesh)
			{
				dummy_mesh->pose = dummy_animation->GetPose();
				dummy_mesh->Update();
			}
		}
	}

	void DummyObject::SetLifeTime(float t)
	{
		life_time = t;
	}

	void DummyObject::TakeDamage(int damage, bool isboost)
	{
		if(freeze)
			return;

		hp -= damage;
		if(hp < 0)
		{
			hp = 0;
		}

		if(hp == 0 && freeze_count > 0)
		{
			hp = 1;
			freeze = true;
			freeze_timer = respawn_time;
			freeze_count -= 1;

			if (dummyobjectinfo->dummy_sound_key.Length() > 0)
			{
				FMOD_VECTOR vel = {0, 0, 0};
				FmodSystem::Play3DEvent(String::Format("bj/weapon/3d/%s/down", dummyobjectinfo->dummy_sound_key.Str() ),
				(const FMOD_VECTOR &)GetPosition(), vel);
			}

			if (dummy_paralysis_particle)
			{
				dummy_paralysis_particle->SetEnable(true);
				dummy_paralysis_particle->Reset();
			}
		}
		else
		{
			if (dummyobjectinfo->dummy_sound_key.Length() > 0)
			{
				FMOD_VECTOR vel = {0, 0, 0};
				FmodSystem::Play3DEvent(String::Format("bj/weapon/3d/%s/hit", dummyobjectinfo->dummy_sound_key.Str() ), 
				(const FMOD_VECTOR &)GetPosition(), vel);
			}
		}
		//LogSystem.WriteLinef("ParseGunTowerHurt() : %d               %d", damage, hp);
		
		if(!isboost)
		{
			if (damage_particle)
			{
				if (damage > 0)
				{
					damage_particle->SetPosition(GetPosition() + dummyobjectinfo->dummy_hp_offset);
					damage_particle->SpawnNumber(damage);
					damage_particle->SetEnable(true);
					damage_particle->Reset();
				}
			}
		}
		else
		{
			if (boostdamage_particle)
			{
				if (damage > 0)
				{
					boostdamage_particle->SetPosition(GetPosition() + dummyobjectinfo->dummy_hp_offset);
					boostdamage_particle->SpawnNumber(damage);
					boostdamage_particle->SetEnable(true);
					boostdamage_particle->Reset();
				}
			}
		}

		if(hp == 0 && gLevel && gLevel->GetPlayer())
		{
			if(owner_id == gLevel->GetPlayer()->uid)
			{
				gGame->channel_connection->RequestDummyObjectDestory(dummyobjectinfo->dummy_id);
			}
		}


	}

	void DummyObject::SetAnimationSet()
	{
		dummy_skeleton = RESOURCE_LOAD(dummyobjectinfo->dummy_skeleton, false, Skeleton);
		if (dummy_skeleton)
			dummy_animation = ptr_new AnimationNodeCustom(dummy_skeleton);



		if (dummy_animation)
		{
			sharedc_ptr(AnimationSetRes) res = RESOURCE_GET_BYTYPE(RESOURCE_NAME(ANIMATION_KEY_PROP_CHARACTER, dummyobjectinfo->dummy_animationset), ANIMATIONSET_TYPE, AnimationSetRes);
			if (res)
			{
				res->Load(false);
				sharedc_ptr(AnimationSet) animset = res->GetAnimationSet();
				if (gLevel->animation_manager)
					gLevel->animation_manager->AddAnimationSetRes(res->GetKey(), res);

				Array<Core::Identifier> animation_keylist = animset->GetAnimationSetKeyList();
				sharedc_ptr(AnimationNodeList) node_list = ptr_new AnimationNodeList();
				for(uint i = 0; i < animation_keylist.Size(); i++)
				{
					sharedc_ptr(AnimationNodePose) node_pose = ptr_new AnimationNodePose(dummy_skeleton);
					node_pose->SetAnimation(animation_keylist[i], animset);
					node_list->AddNode(animation_keylist[i], node_pose);
					pose = ptr_new Pose(dummy_skeleton);
				}
				dummy_animation->SetAnimationSet(animset);
				dummy_animation->SetAnimationNode(node_list);
				StopAction();
			}
		}
	}

	void DummyObject::InitializeMesh()
	{
		bool hasMesh = false;
		dummy_mesh = ptr_new CharacterMesh(MESH_KEY_WEAPON);
		if (dummyobjectinfo && dummy_mesh)
		{
			for (U32 i = 0; i < MESH_LOD_LEVEL; i++)
			{
				CharacterInfo::MeshSet::Enumerator it(dummyobjectinfo->dummy_mesh_set[i]);

				while (it.MoveNext())
				{
					dummy_mesh->AddPrimitive(it.Key(), it.Value(), i);
					hasMesh = true;
				}
			}
		}
		if (!hasMesh)
		{
			dummy_mesh = NullPtr;
		}

		if(gLevel->game_type == RoomOption::kEditMode)
		{
			//droped mesh
			const char* szStr =m_szResKey.Str();
			if(szStr == strstr(szStr, "guard_"))
			{
				droped_box_mesh = ptr_new StaticMesh("/mesh/dummy/");
				droped_box_mesh->AddPrimitive("guard_Y.mesh", 0);
			}
			else if(szStr == strstr(szStr, "resource_"))
			{
				droped_box_mesh = ptr_new StaticMesh("/mesh/dummy/");
				droped_box_mesh->AddPrimitive("resource_Y.mesh", 0);
			}
			else if(szStr == strstr(szStr, "wall_"))
			{
				droped_box_mesh = ptr_new StaticMesh("/mesh/dummy/");
				droped_box_mesh->AddPrimitive("wall_Y.mesh", 0);
			}
			else
			{
				droped_box_mesh = ptr_new StaticMesh("/mesh/dummy/");
				droped_box_mesh->AddPrimitive("guard_Y.mesh", 0);
			}
		}

	}

	void DummyObject::Draw(Primitive::DrawType drawtype, bool immediate)
	{
		if(droped_box_mesh)
		{
			droped_box_mesh->SetPosition(position);
			droped_box_mesh->SetRotation(rotation);
			droped_box_mesh->Draw(drawtype, immediate);
		}

		if (dummy_mesh)
		{
			dummy_mesh->SetPosition(position);
			dummy_mesh->SetRotation(rotation);
			dummy_mesh->Draw(drawtype, immediate);
		}

		if(dummy_particle)
		{
			dummy_particle->Draw();
		}

		if (dummy_medical_particle)
		{
			dummy_medical_particle->Draw();
		}

		if (damage_particle)
		{
			damage_particle->Draw();
		}

		if (boostdamage_particle)
		{
			boostdamage_particle->Draw();
		}

		if (dummy_reborn_particle)
		{
			dummy_reborn_particle->Draw();
		}

		if (dummy_paralysis_particle)
		{
			dummy_paralysis_particle->Draw();
		}
	}

	/// get position
	const Core::Vector3 & DummyObject::GetPosition()
	{
		return position;
	}

	/// get rotation
	const Core::Quaternion & DummyObject::GetRotation()
	{
		return rotation;
	}

	void DummyObject::SetPosition(const Vector3 & pos)
	{
		if (position != pos)
		{
			position = pos;
			if(dummy_actor)
				dummy_actor->setGlobalPosition((const NxVec3 &) (pos + Vector3(0.f, dummyobjectinfo->coll_box_size.z, 0.f)));
		
			//if(protector_actor)
			//{
			//	//dummyobjectinfo->protector_box_pos =Vector3(0, 0, -1);
			//	Vector3 offset_pos =dummyobjectinfo->protector_box_pos * rotation;
			//	protector_actor->setGlobalPosition((const NxVec3 &) (pos + offset_pos));
			//}
		}
	}

	void DummyObject::SetRotation(const Quaternion & rot)
	{
		if (rotation != rot)
		{
			rotation = rot;
			if (dummy_mesh)
				dummy_mesh->SetRotation(rotation);

			//if(protector_actor)
			//{
			//	protector_actor->setGlobalOrientationQuat((const NxQuat&)rot);
			//}
		}
	}

	tempc_ptr(Pose) DummyObject::GetPose()
	{
		if(dummy_animation)
		{
			tempc_ptr(Pose) animation_pose = dummy_animation->GetPose();
			if (animation_pose)
				return animation_pose;
		}

		return pose;
	}

	bool DummyObject::GetDummyJointInfo(const Core::Identifier & joint_name, Vector3 * position, Quaternion * rotation)
	{
		if (dummy_skeleton)
		{
			int joint_id = dummy_skeleton->GetJointId(joint_name);

			if (joint_id >= 0)
			{
				const Transform & transform = GetPose()->GetJointModelPose(joint_id);
				if (position)
					*position = GetPosition() + transform.position * GetRotation();

				if (rotation)
					*rotation = transform.rotation * GetRotation();

				return true;
			}
		}

		return false;
	}

	void DummyObject::SetVisible(bool flag)
	{
		visible = flag;
	}

	bool DummyObject::GetVisible()
	{
		return visible;
	}

	void DummyObject::SetUpdate(bool flag)
	{
		need_update = flag;
	}
	
	bool DummyObject::GetUpdate()
	{
		return need_update;
	}

	void DummyObject::SetSyncMaster(bool flag)
	{
		sync_master = flag;
	}

	void DummyObject::SetSyncDirty(bool flag)
	{
		sync_dirty = flag;
	}

	bool DummyObject::IsSyncMaster()
	{
		return sync_master;
	}

	bool DummyObject::NeedSyncUpdate()
	{
		return sync_dirty && sync_master;
	}

	bool DummyObject::IsDead()
	{
		return isdead;
	}

	const char* DummyObject::GetSyncData(int& length)
	{
		length = sync_data_length;
		return sync_buffer;
	}

	void DummyObject::PlayAction(const Core::Identifier & key, float blend_time, bool loop)
	{
		if (dummy_animation)
		{
			dummy_animation->PlayAction(key, blend_time, loop);
		}
	}

	/// stop action
	void DummyObject::StopAction()
	{
		if (dummy_animation)
			dummy_animation->StopAction(true);
	}

	bool DummyObject::GetJointInfo(const Core::Identifier & joint_name, Vector3 * position, Quaternion * rotation)
	{
		if (dummy_skeleton)
		{
			int joint_id = dummy_skeleton->GetJointId(joint_name);

			if (joint_id >= 0)
			{
				const Transform & transform = GetPose()->GetJointModelPose(joint_id);
				if (position)
					*position = GetPosition() + transform.position * GetRotation();

				if (rotation)
					*rotation = transform.rotation * GetRotation();

				return true;
			}
		}

		return false;
	}

	void DummyObject::Update(float frame_time)
	{
		if(sync_master)
		{
			life_time -= frame_time;
			if(life_time < 0.f && gGame->channel_connection)
			{
				gGame->channel_connection->RequestDummyObjectDestory(dummyobjectinfo->dummy_id);
				life_time = 10000.f;
			}
			
			UpdateLogic(frame_time);
		}

		UpdateFreeze(frame_time);
		
		UpdateSound();
		
		if(dummy_particle)
		{
			if(dummyobjectinfo->dummy_particle_bone.Length() == 0)
			{
				dummy_particle->SetPosition(position);
				dummy_particle->SetRotation(rotation);
			}
			else
			{
				Core::Vector3		pos;
				Core::Quaternion	rot;
				bool flag = GetJointInfo(dummyobjectinfo->dummy_particle_bone, &pos, &rot);
				if(flag)
				{
					dummy_particle->SetPosition(pos);
					dummy_particle->SetRotation(rot);
				}
				else
				{
					dummy_particle->SetPosition(position);
					dummy_particle->SetRotation(rotation);
				}
				
			}

			dummy_particle->Update(frame_time);
		}

		if(dummy_medical_particle)
		{
			dummy_medical_particle->SetPosition(position);
			dummy_medical_particle->SetRotation(rotation);
			dummy_medical_particle->Update(frame_time);
		}

		if(need_update)
		{
			UpdateAnimation(frame_time);
		}

		if(!sync_master)
		{
			UpdateSyncData(frame_time);
		}
		else
		{
			BuildSyncString();
		}

		if (damage_particle)
			damage_particle->Update(frame_time);

		if (boostdamage_particle)
			boostdamage_particle->Update(frame_time);

		if (dummy_reborn_particle)
		{
			Core::Vector3		pos = position;
			Core::Quaternion	rot = rotation;
			GetJointInfo(dummyobjectinfo->dummy_reborn_bone, &pos, &rot);
			dummy_reborn_particle->SetPosition(pos);
			dummy_reborn_particle->SetRotation(rot);
			dummy_reborn_particle->Update(frame_time);
		}

		if (dummy_paralysis_particle)
		{
			Core::Vector3		pos = position;
			Core::Quaternion	rot = rotation;
			GetJointInfo(dummyobjectinfo->dummy_reborn_bone, &pos, &rot);
			dummy_paralysis_particle->SetPosition(pos);
			dummy_paralysis_particle->SetRotation(rot);
			dummy_paralysis_particle->Update(frame_time);
		}

		if (dummy_actor)
			dummy_actor->setGlobalOrientation((const NxQuat &)GetRotation());
	}

	void DummyObject::UpdateLogic(float frame_time)
	{
		if(!dummy_animation->IsActionPlaying())
		{
			PlayAction("idle", 0.1f, true);	
		}
	}

	void DummyObject::UpdateSyncData(float frame_time)
	{
		if (owner_id == 0 || type == DUMMY_SERVER_NO_OWNER)
			return;

		if (sync_data.Empty())
			return;

		Vector3	vel;

		while (sync_data.Size() > 1 && sync_data[1].time <= sync_time)
			sync_data.PopFront();

		Vector3 data_position;
		Quaternion data_rotation;


		if (sync_data.Size() > 1)
		{
			DummySyncData & data1 = sync_data[0];
			DummySyncData & data2 = sync_data[1];

			float s = Clamp((sync_time - data1.time) / (data2.time - data1.time), 0, 1);
			
			Vector3 data1_position, data2_position;
			Quaternion data1_rotation, data2_rotation;
			
			ReadVector3FP(data1.position, data1_position);
			ReadVector3FP(data2.position, data2_position);

			ReadRotationFP(data1.rotation, data1_rotation);
			ReadRotationFP(data2.rotation, data2_rotation);




			Lerp(data_position, data1_position, data2_position, s);
			Core::Slerp(data_rotation, data1_rotation, data2_rotation, s);

			// calculate velocity
			vel = (data_position - GetPosition()) / frame_time;

			// update time
			float delay_time = sync_data.Back().time - sync_time;

			if (delay_time > 0.1f)
				frame_time *= 1 + (delay_time - 0.1f);
			
			//hack
			if(Length(data1_position - data2_position) > 500)
			{
				data_position = data1_position;
			}

			sync_time += frame_time;

		}
		else
		{
			ReadVector3FP(sync_data[0].position, data_position);
			ReadRotationFP(sync_data[0].rotation, data_rotation);
			vel = Vector3::kZero;
			sync_time = sync_data[0].time;
		}

		SetRotation(data_rotation);
		SetPosition(data_position);
	}

	void DummyObject::AddSyncData(byte time, const char* buffer, int size)
	{
		if (owner_id == 0)
		{
			ServerDummySyncData sync;
			readUserData(buffer, size, 0, sync);

			hp = sync.hp;
		}
		else
		{
			float t = sync_data.Back().time;
			DummySyncData sync;
			readUserData(buffer, size, 0, sync);
			sync.time = t + (float)time / 255.f;

			sync_data.PushBack(sync);
		}
	}

	void DummyObject::BuildSyncString()
	{
		DummySyncData sync;
		sync.time = 0.f;
		WriteVector3FP(sync.position, GetPosition());
		WriteRotationFP(sync.rotation, GetRotation());
		sync_data_length = writeUserData(sync_buffer, SYNC_BUFFER_SIZE, sync);

		sync_dirty = true;
	}

	void DummyObject::Die()
	{
 		isdead = true;
		
		if(dummy_particle)
		{
			dummy_particle->Reset();
			dummy_particle->SetDead();
			dummy_particle = NullPtr;
		}

		if (dummy_medical_particle)
		{
			dummy_medical_particle->Reset();
			dummy_medical_particle->SetDead();
			dummy_medical_particle = NullPtr;
		}

		if(dummyobjectinfo->dummy_die_particle.Length() != 0)
		{
			gLevel->AddParticle(dummyobjectinfo->dummy_die_particle, position, rotation);
		}
		if (dummyobjectinfo->dummy_sound_key.Length() > 0)
		{
			FMOD_VECTOR vel = {0, 0, 0};
			FmodSystem::Play3DEvent(String::Format("bj/weapon/3d/%s/explode", dummyobjectinfo->dummy_sound_key.Str() ),
				(const FMOD_VECTOR &)GetPosition(), vel);
		}

		ReleasePhysx();
	}

	void DummyObject::UpdateBaseRotation()
	{
		
	}

	void DummyObject::UpdateSound()
	{
		if (idle_sound && !IsDead() && !freeze)
		{
			FMOD_EVENT_STATE audio_state = FMOD_EVENT_DEFAULT;
			idle_sound->getState(&audio_state);
			if ((audio_state & FMOD_EVENT_STATE_PLAYING) == 0)
			{
				FMOD_VECTOR vel = {0, 0, 0};
				idle_sound->set3DAttributes(&(const FMOD_VECTOR &)GetPosition(), &vel);
				idle_sound->start();
			}
		}
		else
		{
			idle_sound->stop();
		}
	}

	void DummyObject::UpdateFreeze(float frame_time)
	{
		if(IsSyncMaster())
		{
			if(freeze)
			{
				freeze_timer -= frame_time;
				if(freeze_timer < 0.f)
				{
					freeze = false;
					PlayAction("idle", 2.0f,true);
				}	
			}
		}
		else
		{
			if(dummy_animation->node_action)
			{
				if(!freeze && strcmp(dummy_animation->node_action->GetAnimationKey() ,"die") == 0)
				{
					PlayAction("idle", 0.1f, true);
				}
				else if(freeze && strcmp(dummy_animation->node_action->GetAnimationKey() ,"die") != 0)
				{
					dummy_animation->PlayAction("die", 0.1f, false, 0, true);
				}
			}

		}
	}
}