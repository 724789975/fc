#include "pch.h"

using namespace Core;
using namespace Client;

DEFINE_PDE_TYPE_CLASS(Client::DrumInfo)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Client::GunInfo);
		ADD_PDE_DEFAULT_CONSTRUCTOR();
	}
};


DEFINE_PDE_TYPE_CLASS(Client::Drum)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Client::GunBase);

		ADD_PDE_PROPERTY_R(weapon_info);
	}
};

REGISTER_PDE_TYPE(Client::DrumInfo);
REGISTER_PDE_TYPE(Client::Drum);

namespace Client
{
	Drum::Drum(by_ptr(DrumInfo) info)
	{
		weapon_info = gun_info = drum_info = info;
		has_trajectory = true;
		drum_timer = 0.f;
	}

	void Drum::Initialize()
	{		
		GunBase::Initialize();
	}

	/// can active
	bool Drum::CanActive()
	{
		return GunBase::CanActive();
	}

	/// active
	void Drum::Active()
	{
		GunBase::Active();
	}

	/// inactive
	void Drum::Inactive()
	{
		tempc_ptr(Character) player = GetOwner();
		player->UnLockStateByType(kLSSelectWeapon);
		GunBase::Inactive();
	}

	/// update
	void Drum::Update(float frame_time)
	{
		//GunBase::Update(frame_time);
		tempc_ptr(Character) player = GetOwner();
		if (!player)
			return;
		if (!gun_info)
			return;

		next_fire_time -= frame_time;
		
		if(drum_timer > 0.f)
		{
			drum_timer -= frame_time;
			if(drum_timer <= 0.f)
			{
				gGame->channel_connection->DrumCheck();
				player->UnLockStateByType(kLSSelectWeapon);
				player->first_action_on = false;
			}
		}
		if (player->first_action_on)
		{
			
			if (idle_time <= 0 && next_fire_time <= 0 && (gun_info->auto_fire || delay_fire == false))
			{
				if (player->CanFire() && Fire())
				{
					next_fire_time = gun_info->fire_time;
					drum_timer = gun_info->fire_time;
					player->LockStateByType(kLSSelectWeapon);
				}
				else
					player->StopShoot();
				idle_time =  weapon_info->time_to_idle ;
			}
		}
		else
		{
			player->StopShoot();
		}

		UpdateEffect(frame_time);
	}

	/// get weapon type
	uint Drum::GetWeaponType()
	{
		return kWeaponTypeDrum;
	}
	/// fire
	bool Drum::Fire()
	{
		tempc_ptr(Character) player = GetOwner();

		if (!player)
			return false;


		if(!FireBase(0))
		{
			return false;
		}
		empty = false;
		player->accumulate_damage = 0;
		return true;
	}
	
	bool Drum::CanFire( bool check_only )
	{
		tempc_ptr(Character) player = GetOwner();
		if(!drum_info)
		{
			return false;
		}
		if(drum_info)
		{
			if(drum_info->damage <= player->accumulate_damage)
			{
				return true;
			}
		}
		return false;
	}

	void Drum::FireCheck( const Core::Vector3 & position, const Core::Quaternion & rotation, float spread, bool do_effect /*= true*/ )
	{
		//ENCODE_START

		tempc_ptr(Character) player = GetOwner();

		Vector3 dir = Vector3(0, 0, -1) * rotation;
		if (!player || !gun_info || !gPhysxScene)
			return;
		Core::Array<HitMessage> hit_message;
		gGame->channel_connection->Shoot(position,rotation,hit_message,true, 0.f);		
		
		player->Shoot(dir, do_effect);

		//ENCODE_END
	}
}