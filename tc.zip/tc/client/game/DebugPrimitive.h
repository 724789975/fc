namespace Client
{
	class DebugPrimitive : public Core::Object
	{
	public:
		// constructor
		DebugPrimitive(by_ptr(DirectX9) dx9, by_ptr(Mesh) mesh);

		// destructor
		~DebugPrimitive();

	public:
		IDirect3DIndexBuffer9* index_buffer;
		IDirect3DVertexBuffer9* vertex_buffer;
		uint vertex_count;
		uint primitive_count;
	};
#if DEBUG_INFO

	class DebugPrimitiveRect : public Core::Object
	{
	public:


		DebugPrimitiveRect();

		~DebugPrimitiveRect();

		void CreateVertice(Core::Vector3* vec,uint length);

		void Draw();

	public:
		Core::Array<Core::Vector3>	vertices;

	};
#endif
}