namespace Client
{
	struct PistolInfo : public GunInfo
	{
		float up_modifier;
		float accuracy_time;
		float accuracy_time_modifier;
		float max_accuracy;
		float min_accuracy;
		
		float normal_up_base;
		float normal_lateral_base;
		float normal_up_modifier;
		float normal_lateral_modifier;
		float normal_up_max;
		float normal_lateral_max;
		float normal_dir_change;

		float move_up_base;
		float move_lateral_base;
		float move_up_modifier;
		float move_lateral_modifier;
		float move_up_max;
		float move_lateral_max;
		float move_dir_change;

		float onair_up_base;
		float onair_lateral_base;
		float onair_up_modifier;
		float onair_lateral_modifier;
		float onair_up_max;
		float onair_lateral_max;
		float onair_dir_change;

		float crouch_up_base;
		float crouch_lateral_base;
		float crouch_up_modifier;
		float crouch_lateral_modifier;
		float crouch_up_max;
		float crouch_lateral_max;
		float crouch_dir_change;


		PistolInfo()
			: accuracy_time(0.3f)
			, accuracy_time_modifier(0.275f)
			, max_accuracy(0.92f)
			, min_accuracy(0.6f)
		{
			weapon_type = kWeaponTypePistol;
		}
	};

	class Pistol : public GunBase
	{
	public:
		/// constrcutor
		Pistol(by_ptr(PistolInfo) info);

		/// destructor
		virtual ~Pistol();

	public:
		DECLARE_PDE_ATTRIBUTE_R(weapon_info, tempc_ptr(PistolInfo))
		{
			return pistol_info;
		}

	public:
		/// initialize
		virtual void Initialize();
		
		/// active
		virtual void Active();

		/// inactive
		virtual void Inactive();

		/// get weapon type
		virtual uint GetWeaponType();

	public:
		/// fire
		virtual bool Fire();

	private:
		sharedc_ptr(PistolInfo) pistol_info;
	};
}