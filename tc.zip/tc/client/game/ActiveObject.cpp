#include "pch.h"

using namespace Core;
using namespace Client;


namespace Client
{
	/// constructor
	ActiveObject::ActiveObject(by_ptr(ActiveObjInfo) info):rot_addup_time(0.f)
	{
		active_object_info = info;
	}

	/// destructor
	ActiveObject::~ActiveObject()
	{
		active_object_info = NullPtr;
		active_object_mesh = NullPtr;
	}

	/// initialize
	void ActiveObject::Initialize()
	{
		CreateMesh();

		active_object_mesh->SetPosition(active_object_info->position);
		active_object_mesh->SetRotation(active_object_info->rotation);
	}

	/// update
	void ActiveObject::Update(float frame_time)
	{
		rot_addup_time += frame_time;

		if (active_object_info->rot_360_time != 0)
		{
			 float p = Ceil(rot_addup_time/active_object_info->rot_360_time);
			 float rot_percent = (rot_addup_time - p * active_object_info->rot_360_time) / active_object_info->rot_360_time;
			 Quaternion q(active_object_info->rot_normal, rot_percent * 2 * PI);
			 active_object_mesh->SetRotation(q * active_object_info->rotation);
		}

		float pos_y_percent = Sin(rot_addup_time * active_object_info->updown_speed) * active_object_info->updown_distance;
		
		//float new_pos_y = active_object_mesh->GetPosition().y + pos_y_percent;
		//float abs_distance = abs(active_object_info->updown_distance);
		//new_pos_y = Clamp(new_pos_y, active_object_info->position.y - abs_distance, active_object_info->position.y + abs_distance);

		active_object_mesh->SetPosition(Core::Vector3(active_object_info->position.x, active_object_info->position.y + pos_y_percent, active_object_info->position.z));
	}

	/// draw
	void ActiveObject::Draw(Primitive::DrawType drawtype, bool immediate)
	{
		active_object_mesh->Draw(drawtype,immediate);
	}

	void ActiveObject::CreateMesh()
	{
		active_object_mesh = ptr_new StaticMesh(MESH_KEY_PROP);

		active_object_mesh->AddPrimitive(active_object_info->filename,0);
	}


}