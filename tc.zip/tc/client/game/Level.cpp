#include "pch.h"
#include "LuaLoadingFunc.h"

using namespace Core;

const float CHECK_DEAD_ZONE_INTERVAL = 2.f;
bool f = true; 
namespace Client
{
	Level* gLevel = NULL;
}

namespace Client
{
	class LevelLoader
	{
	public:
		LevelLoader(Level * level) : level(level)
		{
		}

		void AddMesh(const Identifier & key, U32 lod = 0)
		{
			AddSubMesh(0, key, Vector3::kMinimal, Vector3::kMaximal, lod);
		}

		void AddGoldParticleVector3(const Vector3& position)
		{
			gLevel->gold_vectors.Clear();
			gLevel->gold_particles.Clear();
			gLevel->gold_pos_num = 0;
			for (int i = -3; i < 4; ++i)
			{
				for (int j = -3; j < 4; ++j)
				{
					Vector3 pos = Vector3(position.x + 1 * i, position.y, position.z + 1 * j);
					gLevel->gold_vectors.PushBack(pos);
					gLevel->gold_pos_num = gLevel->gold_vectors.Size();
				}
			}
		}

	 
         void AddfireworksParticleVector3( const Vector3&  position )
	    {
			
				Vector3 pos = Vector3(position.x ,position.y, position.z );
			    gLevel->firework_vectors.PushBack(pos);
	    }
       
		void AddSubMesh(int id, const Identifier & key, const Vector3& min, const Vector3& max, U32 lod = 0)
		{
			AxisAlignedBox aabb(min, max);
			Level::LevelMesh *pLevelMesh = level->map_meshs.Get(id);
			if (pLevelMesh)
			{
				pLevelMesh->mesh->AddPrimitive(key, lod);
				pLevelMesh->aabb.UnionWithAABB(aabb);
			}
			else
			{
				Level::LevelMesh level_mesh;

				level_mesh.mesh = ptr_new StaticMesh(MESH_KEY_MAP);
				level_mesh.mesh->AddPrimitive(key, lod);
				level_mesh.aabb = aabb;

				level->map_meshs.Add(id, level_mesh);

				//temp fix
				level->visible_meshs.Add(level_mesh.mesh);
			}
		}

		void AddMoveArea(Vector3& min, Vector3& max)
		{
			level->map_movearea.Min = min;
			level->map_movearea.Max = max;
		}

		void AddOccluders(const String & path)
		{
			CStrBuf<256> full_path;
			full_path.format("/mesh/scene/%s", path.Str());

			Lua::LuaState *L = Lua::LuaState::NewState();

			if (L->DoFile(full_path) == 0)
			{
				Array<float> data;

				L->GetGlobal("occluders");
				lua_LoadArray(L, -1, data);

				for (uint i = 0; i < data.Size(); i ++)
					data[i] *= 0.01f;

				for (uint i = 0; i < data.Size() / 12; i ++)
				{
					Vector3 * points = (Vector3*)&data.GetAt(i * 12);

					Core::OccluderPlane plane;
					plane.Init(points);
					level->occluderplanes.Add(plane);

#if DEBUG_INFO
					DebugPrimitiveRect rect;
					rect.CreateVertice(points,4);
					level->debug_occluedr_rect.Add(rect);
#endif
				}
			}

			L->Close();
		}

		void AddMachineGunTurretArea(const String & path)
		{
			CStrBuf<256> full_path;
			full_path.format("/mesh/scene/%s", path.Str());

			Lua::LuaState *L = Lua::LuaState::NewState();

			if (L->DoFile(full_path) == 0)
			{
				Array<float> data;

				L->GetGlobal("MachineGunTurretArea");
				lua_LoadArray(L, -1, data);

				for (uint i = 0; i < data.Size() / 6; i ++)
				{
					AxisAlignedBox aabb;
					Vector3 * min = (Vector3*)&data.GetAt(i * 6);
					Vector3 * max = (Vector3*)&data.GetAt(i * 6 + 3);
					aabb = Core::AxisAlignedBox(*min, *max);
					level->machinegunturretarea.Add(aabb);
				}

				L->GetGlobal("NoMachineGunTurretArea");
				lua_LoadArray(L, -1, data);

				for (uint i = 0; i < data.Size() / 6; i ++)
				{
					AxisAlignedBox aabb;
					Vector3 * min = (Vector3*)&data.GetAt(i * 6);
					Vector3 * max = (Vector3*)&data.GetAt(i * 6 + 3);
					aabb = Core::AxisAlignedBox(*min, *max);
					level->nomachinegunturretarea.Add(aabb);
				}
			}

			L->Close();
		}

		void AddPhysx(const String & path)
		{
			if (level->physx_manager)
			{
				CStrBuf<256> filename;
				filename.format("%s%s", MESH_KEY_MAP, path.Str());
				level->physx_manager->Load(filename);
			}
		}

		void AddSceneSound(const String & path)
		{
			level->scenesound_event = FmodSystem::GetEvent(path);
		}

		void AddScene3DSound(const String & path,const Vector3& pos)
		{
			level->scene3dsound_event = FmodSystem::GetEvent(path);
			level->sound3d_pos.x = pos.x;
			level->sound3d_pos.y = pos.y;
			level->sound3d_pos.z = pos.z;
		}

		void SetSetActiveGateTime(float time)
		{
			gLevel->activeGateTime = time;
		}
		void AddGate(int id,int team,const String& mesh_path, const Vector3& position, const Vector3& target_position, float rotY, Vector3& dim,Vector3& collision_dim)
		{
			ServerInfo* pInfo = NULL;
			for (int i = 0; i < gGame->lobby_connection->server_list.GetCount(); ++i)
			{
				if (gGame->lobby_connection->server_list[i].id == gGame->address.server_id)
				{
					pInfo = &gGame->lobby_connection->server_list[i]; 
				}
			}
			if (pInfo)
			{
				if (pInfo->servertype != SvrType_Match  || pInfo->servertype == SvrType_MatchFighting )// SvrType_Match
				{
				
					level->SummonGate(position, rotY, id, team, target_position,dim, collision_dim, mesh_path);
				}
			}
		}
		void AddActiveGate(bool isactive, int team, const String& mesh_path, const Vector3& position, const Vector3& target_position, float rotY, Vector3& dim,Vector3& collision_dim)
		{
			level->SummonActiveGate(position, rotY, isactive, team, target_position,dim, collision_dim, mesh_path);
		}

		void AddDeadAABB(const Vector3& min, const Vector3& max)
		{
			level->AddDeadAABB(min, max);
		}

		void AddNoviceGunTarget(int id, int uid, const String& mesh_path, float rotY, const Vector3& position, const Vector3& end_position, Vector3& collision_dim, int type)
		{
			level->AddGunTarget(position, end_position, rotY, id, uid, collision_dim, mesh_path, type);
		}

		void SetZombieStepTwoSoundInfo(float delay_time, const String& zombie_sound, const String& human_sound)
		{
			level->SetZombieStepTwoSoundInfo(delay_time, zombie_sound, human_sound);
		}

		//void AddActiveObject(const Vector3& position, float deg, const String& filename, const Vector3& rot_normal, float rot_360_time)
		//{

		//	Vector3 rot;
		//	//degree
		//	rot.x = 0;
		//	rot.y = deg * DEG2RAD;
		//	rot.z = 0;
		//	Quaternion q;
		//	q.SetZXY(rot);

		//	level->AddActiveObject(position, q, filename, rot_normal, rot_360_time);
		//}

		void AddActiveObject(const Vector3& position, float deg, const String& filename, const Vector3& rot_normal, float rot_360_time, float updown_distance, float updown_speed)
		{

			Vector3 rot;
			//degree
			rot.x = 0;
			rot.y = deg * DEG2RAD;
			rot.z = 0;
			Quaternion q;
			q.SetZXY(rot);

			level->AddActiveObject(position, q, filename, rot_normal, rot_360_time, updown_distance, updown_speed);
		}

		void AddAnimObject(float deg, const Core::String& filename)
		{
			Vector3 rot;
			//degree
			rot.x = 0;
			rot.y = deg * DEG2RAD;
			rot.z = 0;
			Quaternion q;
			q.SetZXY(rot);

			level->AddAnimObject(q, filename);
		}

		void AddManualBound(const Vector3& offset, const Vector3& dim, int type)
		{
			level->AddManualBound(offset, dim, type);
		}

		void AddMapName(const String & mapname)
		{
			level->name2 = String::Format("%s", gLang->GetText(mapname));
		}

		void SetMapInfo(float x1, float y1, float x2, float y2)
		{
			level->map_center = Vector2(x1, y1);
			level->map_size = Vector2(x2, y2);
		}

		void SetMapVisibleTree(const String & path)
		{
			CStrBuf<256> filename;
			filename.format("%s%s", MESH_KEY_MAP, path.Str());
			sharedc_ptr(MapVisibleTree) map_visible_tree = RESOURCE_LOAD(filename, false, MapVisibleTree);
			if (map_visible_tree)
			{
				level->map_visible_tree = map_visible_tree;
			}
		}

		void SetSunDirection(F32 x, F32 y, F32 z)
		{
			if (gRender && gRender->render_pipeline)
				gRender->render_pipeline->SetSunDirection(x, y, z);
		}

		void SetAmbientIntensity(F32 v)
		{
			if (gRender && gRender->render_pipeline)
				gRender->render_pipeline->SetAmbientIntensity(v);
		}

		void SetShadowDirection(F32 x, F32 y, F32 z)
		{
			if (gRender && gRender->render_pipeline)
				gRender->render_pipeline->SetShadowDirection(x, y, z);
		}

		void SetShadowDistance(F32 x)
		{
			if (gRender && gRender->render_pipeline)
				gRender->render_pipeline->SetShadowDistance(x);
		}

		void SetShadowMapSize(F32 x, F32 y)
		{
			if (gRender && gRender->render_pipeline)
				gRender->render_pipeline->SetShadowMapSize(x, y);
		}

		void SetFog(F32 i, F32 mind, F32 maxd, F32 r, F32 g, F32 b)
		{
			if (gRender && gRender->render_pipeline)
				gRender->render_pipeline->SetFog(i, mind, maxd, r, g, b);
		}

		void SetYFog(F32 i, F32 mind, F32 maxd, F32 r, F32 g, F32 b)
		{
			if (gRender && gRender->render_pipeline)
				gRender->render_pipeline->SetYFog(i, mind, maxd, r, g, b);
		}

		void SetFogClamper(F32 factor)
		{

			if(gRender && gRender->render_pipeline)
			{
				gRender->render_pipeline->SetFogClamper(factor);
			}
		}

		void SetLightmapIntensity(F32 i)
		{
			if (gRender && gRender->render_pipeline)
				gRender->render_pipeline->SetLightmapIntensity(i);
		}

		void SetCharacterIntensity(F32 i)
		{
			if (gRender && gRender->render_pipeline)
				gRender->render_pipeline->SetCharacterIntensity(i);
		}

		void SetShadowIntensity(F32 f)
		{
			if (gRender && gRender->render_pipeline)
			{
				gRender->render_pipeline->SetShadowIntensity(f);
			}
		}

		void SetFar(F32 v)
		{
			if (gGame && gGame->camera)
				gGame->camera->SetFar(v);
		}

		void SetNear(F32 v)
		{
			if (gGame && gGame->camera)
				gGame->camera->SetNear(v);
		}

		void SetCameraPosition(float x, float y, float z)
		{
			if (gGame && gGame->camera && level)
			gGame->camera->position.x = x;
			gGame->camera->position.y = y;
			gGame->camera->position.z = z;

			level->camera_position = gGame->camera->position;
		}

		void SetCameraRotation(float x, float y, float z, float w)
		{
			gGame->camera->rotation.x = x;
			gGame->camera->rotation.y = y;
			gGame->camera->rotation.z = z;
			gGame->camera->rotation.w = w;
			gGame->camera->rotation.Normalize();

			level->camera_rotation = gGame->camera->rotation;
		}

		void SetCameraAngle(float angle)
		{
			level->camera_rotation = Core::Quaternion(Vector3(0, 1, 0), angle);
		}

		void SetCharacterLight(Vector4& a, Vector4& b, Vector4& c, Vector4& d)
		{
			if (gRender && gRender->render_pipeline)
				gRender->render_pipeline->SetCharacterLight(a, b, c, d);
		}

		void SetPostProcessBloom(bool value)
		{
			if (gRender && gRender->render_pipeline)
				gRender->render_pipeline->SetPPBloom(value);
		}

		void SetLightMap(const Core::Identifier & key)
		{
			CStrBuf<256> full_path;
			full_path.format("%s%s", MESH_KEY_MAP, key.Str());

			level->map_lightmap = RESOURCE_LOAD(full_path, false, Texture2D);
		}

		void AddParticle(const Core::Identifier & key, const Core::Vector3 & position, const Core::Vector3 & normal)
		{
			if (key.Length() > 0)
				level->AddLevelParticle(key, position, normal);
		}

		void AddParticleQuaternion(const Core::Identifier & key, const Core::Vector3 & position, const Core::Quaternion & q)
		{
			if (key.Length() > 0)
				level->AddLevelParticle(key, position, q);
		}

		void SetHoldPointMesh(const Identifier & key, float rot_speed, U32 lod = 0)
		{
			if (level->holdpoint_mesh)
				level->holdpoint_mesh->AddPrimitive(key, lod);

			level->holdpoint_rotspeed = rot_speed;
		}

		void SetBombPointMesh(const Identifier & key, const Core::Vector3 & position, float rot_speed, U32 lod = 0)
		{
			sharedc_ptr(BombPositionData) data = ptr_new BombPositionData();
			data->mesh = ptr_new StaticMesh(MESH_KEY_PROP);
			data->mesh->AddPrimitive(key, lod);
			data->position = position;

			level->bomb_plant_position_array.Add(data);
		}

		void AddLittleMap(const Identifier & key)
		{
			level->map_texture = ptr_static_cast<Texture2D>(Resource::Load(key, false));
		}

		void SetSceneReverb(const Core::String & key)
		{
			FMOD_REVERB_PROPERTIES reverb = FMOD_PRESET_OFF; FmodSystem::SetSceneReverb(&reverb);
			return;
			if (key == "off")					{ FMOD_REVERB_PROPERTIES reverb = FMOD_PRESET_OFF; FmodSystem::SetSceneReverb(&reverb); }
			else if (key == "paddedcell")		{ FMOD_REVERB_PROPERTIES reverb = FMOD_PRESET_PADDEDCELL; FmodSystem::SetSceneReverb(&reverb); }
			else if (key == "room")				{ FMOD_REVERB_PROPERTIES reverb = FMOD_PRESET_ROOM; FmodSystem::SetSceneReverb(&reverb); }
			else if (key == "bathroom")			{ FMOD_REVERB_PROPERTIES reverb = FMOD_PRESET_BATHROOM; FmodSystem::SetSceneReverb(&reverb); }
			else if (key == "livingroom")		{ FMOD_REVERB_PROPERTIES reverb = FMOD_PRESET_LIVINGROOM; FmodSystem::SetSceneReverb(&reverb); }
			else if (key == "stoneroom")		{ FMOD_REVERB_PROPERTIES reverb = FMOD_PRESET_STONEROOM; FmodSystem::SetSceneReverb(&reverb); }
			else if (key == "auditorium")		{ FMOD_REVERB_PROPERTIES reverb = FMOD_PRESET_AUDITORIUM; FmodSystem::SetSceneReverb(&reverb); }
			else if (key == "concerthall")		{ FMOD_REVERB_PROPERTIES reverb = FMOD_PRESET_CONCERTHALL; FmodSystem::SetSceneReverb(&reverb); }
			else if (key == "cave")				{ FMOD_REVERB_PROPERTIES reverb = FMOD_PRESET_CAVE; FmodSystem::SetSceneReverb(&reverb); }
			else if (key == "arena")			{ FMOD_REVERB_PROPERTIES reverb = FMOD_PRESET_ARENA; FmodSystem::SetSceneReverb(&reverb); }
			else if (key == "hangar")			{ FMOD_REVERB_PROPERTIES reverb = FMOD_PRESET_HANGAR; FmodSystem::SetSceneReverb(&reverb); }
			else if (key == "carpettedhallway")	{ FMOD_REVERB_PROPERTIES reverb = FMOD_PRESET_CARPETTEDHALLWAY; FmodSystem::SetSceneReverb(&reverb); }
			else if (key == "hallway")			{ FMOD_REVERB_PROPERTIES reverb = FMOD_PRESET_HALLWAY; FmodSystem::SetSceneReverb(&reverb); }
			else if (key == "stonecorridor")	{ FMOD_REVERB_PROPERTIES reverb = FMOD_PRESET_STONECORRIDOR; FmodSystem::SetSceneReverb(&reverb); }
			else if (key == "city")				{ FMOD_REVERB_PROPERTIES reverb = FMOD_PRESET_CITY; FmodSystem::SetSceneReverb(&reverb); }
			else if (key == "alley")			{ FMOD_REVERB_PROPERTIES reverb = FMOD_PRESET_ALLEY; FmodSystem::SetSceneReverb(&reverb); }
			else if (key == "forest")			{ FMOD_REVERB_PROPERTIES reverb = FMOD_PRESET_FOREST; FmodSystem::SetSceneReverb(&reverb); }
			else if (key == "mountains")		{ FMOD_REVERB_PROPERTIES reverb = FMOD_PRESET_MOUNTAINS; FmodSystem::SetSceneReverb(&reverb); }
			else if (key == "quarry")			{ FMOD_REVERB_PROPERTIES reverb = FMOD_PRESET_QUARRY; FmodSystem::SetSceneReverb(&reverb); }
			else if (key == "plain")			{ FMOD_REVERB_PROPERTIES reverb = FMOD_PRESET_PLAIN; FmodSystem::SetSceneReverb(&reverb); }
			else if (key == "parkinglot")		{ FMOD_REVERB_PROPERTIES reverb = FMOD_PRESET_PARKINGLOT; FmodSystem::SetSceneReverb(&reverb); }
			else if (key == "sewerpipe")		{ FMOD_REVERB_PROPERTIES reverb = FMOD_PRESET_SEWERPIPE; FmodSystem::SetSceneReverb(&reverb); }
			else								{ FMOD_REVERB_PROPERTIES reverb = FMOD_PRESET_GENERIC; FmodSystem::SetSceneReverb(&reverb); }
		}

		void SetEditMapSize(float w, float h)
		{
			level->SetEditMapSize(w, h);
		}
		void SetEditMapItemSize(float s)
		{
			level->SetEditMapItemSize(s);
		}

		void LoadEventScript(const Core::String & file)
		{
			level->level_eventmgr->LoadEventScript(file);
		}

	private:
		Level * level;
	};
}

DEFINE_PDE_TYPE_CLASS(Client::LevelLoader)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_METHOD(AddMesh);
		ADD_PDE_METHOD(AddSubMesh);
		ADD_PDE_METHOD(AddGoldParticleVector3);

		ADD_PDE_METHOD(AddfireworksParticleVector3);

		ADD_PDE_METHOD(AddMoveArea);
		ADD_PDE_METHOD(AddPhysx);
		ADD_PDE_METHOD(AddOccluders);
		ADD_PDE_METHOD(AddMachineGunTurretArea);
		ADD_PDE_METHOD(AddParticle);
		ADD_PDE_METHOD(AddParticleQuaternion);
		ADD_PDE_METHOD(AddSceneSound);
		ADD_PDE_METHOD(AddScene3DSound);
		ADD_PDE_METHOD(SetHoldPointMesh);
		ADD_PDE_METHOD(SetBombPointMesh);

		ADD_PDE_METHOD(SetMapInfo);
		ADD_PDE_METHOD(SetMapVisibleTree);

		ADD_PDE_METHOD(SetSunDirection);
		ADD_PDE_METHOD(SetAmbientIntensity);
		ADD_PDE_METHOD(SetShadowDirection);
		ADD_PDE_METHOD(SetShadowDistance);
		ADD_PDE_METHOD(SetShadowMapSize);
		ADD_PDE_METHOD(SetFog);
		ADD_PDE_METHOD(SetYFog);
		ADD_PDE_METHOD(SetLightmapIntensity);
		ADD_PDE_METHOD(SetCharacterIntensity);
		ADD_PDE_METHOD(SetFar);
		ADD_PDE_METHOD(SetNear);
		ADD_PDE_METHOD(SetCameraPosition);
		ADD_PDE_METHOD(SetCameraRotation);
		ADD_PDE_METHOD(SetCameraAngle);

		ADD_PDE_METHOD(SetCharacterLight);
		ADD_PDE_METHOD(SetPostProcessBloom);
		ADD_PDE_METHOD(SetLightMap);
		ADD_PDE_METHOD(AddGate);
		ADD_PDE_METHOD(AddActiveGate);
		ADD_PDE_METHOD(AddNoviceGunTarget);
		ADD_PDE_METHOD(AddActiveObject);
		ADD_PDE_METHOD(AddLittleMap);
		ADD_PDE_METHOD(AddManualBound);
		ADD_PDE_METHOD(AddMapName);
		ADD_PDE_METHOD(AddAnimObject);
		ADD_PDE_METHOD(AddDeadAABB);
		ADD_PDE_METHOD(SetSceneReverb);
		ADD_PDE_METHOD(LoadEventScript);
		ADD_PDE_METHOD(SetZombieStepTwoSoundInfo);
		ADD_PDE_METHOD(SetFogClamper);
		ADD_PDE_METHOD(SetSetActiveGateTime);
		ADD_PDE_METHOD(SetShadowIntensity);
		ADD_PDE_METHOD(SetEditMapSize);
		ADD_PDE_METHOD(SetEditMapItemSize);
	}
};

REGISTER_PDE_TYPE(Client::LevelLoader);

namespace Client
{
	/// constructor
	MeshBase::MeshBase(const Core::Identifier & n)
		: name(n)
		, position(Vector3::kZero)
		, scale(Vector3::kOne)
		, rotation(Quaternion::kIdentity)
		, visible(true)
		, transform_dirty(true)
		, mesh_lod_level(0)
		, mesh_base_lod_level(0)
		, shader_lod_level(-1)
	{
	}

	/// draw
	void MeshBase::Draw(Primitive::DrawType type, bool immediate)
	{
		if (GetVisible() && IsReady())
		{
			//LogSystem.WriteLinef("MeshBase::Draw() Start");

			for (U32 i = 0; i < primitive_array[mesh_lod_level].Size(); i++)
			{
				tempc_ptr(GsPrimitive) p = primitive_array[mesh_lod_level][i];
				if (p && p->GetVisible())
				{
					if (transform_dirty)
					{
						p->m_WorldMatrix.SetTransformation(GetPosition(), GetRotation(), GetScale());
					}
					p->Draw(type, immediate, shader_lod_level);
				}

				//LogSystem.WriteLinef("MeshBase::Draw() %s", it.Key());
			}

			transform_dirty = false;

			//LogSystem.WriteLinef("MeshBase::Draw() End");
		}
	}

	/// create primitve
	sharedc_ptr(GsPrimitive) MeshBase::CreatePrimitive(const Core::Identifier & key, bool blink, bool async)
	{
		CStrBuf<256> str(name.Str());
		if (!str.endwith('/'))
			str.contract('/');
		str.contract(key.Str());

		sharedc_ptr(MeshResource) mesh_res = RESOURCE_GET(str, MeshResource);
		if (mesh_res)
		{
			mesh_res->Load(async);
		}

		sharedc_ptr(GsPrimitive) primitive = NullPtr;

		if (mesh_res)
		{
			primitive = ptr_new StaticPrimitive(mesh_res);
		}

		primitive->blink = blink;

		return primitive;
	}
	
	/// add primitive
	sharedc_ptr(GsPrimitive) MeshBase::AddPrimitive(const Core::Identifier & key, U32 lod, bool async)
	{
		return AddPrimitive(key, key, lod, async);
	}

	/// add primitive
	sharedc_ptr(GsPrimitive) MeshBase::AddPrimitive(const Core::Identifier & key, const Core::Identifier & value, U32 lod, bool async)
	{
		sharedc_ptr(GsPrimitive) p = CreatePrimitive(value, false, async);

		if (p)
			SetPrimitive(key, p, lod);

		return p;
	}

	/// get primitive
	sharedc_ptr(GsPrimitive) MeshBase::GetPrimitive(const Core::Identifier & key)
	{
		S32 index = primitive_set[mesh_lod_level].Get(key, -1);
		if (index < 0)
			return NullPtr;
		return primitive_array[mesh_lod_level][index];
	}

	/// set primitive
	void MeshBase::SetPrimitive(const Core::Identifier & key, by_ptr(GsPrimitive) p, U32 lod)
	{
		if (p)
		{
			if (lod >= MESH_LOD_LEVEL)
			{
				LogSystem.WriteLinef("%s, lod too large , lod = %d", key, lod);
				return;
			}

			S32 index = primitive_set[lod].Get(key, -1);
			if (index >= 0)
			{
				primitive_array[lod][index] = p;
			}
			else
			{
				primitive_array[lod].PushBack(p);
				primitive_set[lod].Set(key, primitive_array[lod].Size() - 1);
			}

			//LogSystem.WriteLinef("MeshBase::SetPrimitive() key : %s lod%d index%d", key, lod, primitive_set[lod].Get(key, -1));
		}
	}

	/// remove primitive
	void MeshBase::RemovePrimitive(const Core::Identifier & key)
	{
		for (U32 i = 0; i < MESH_LOD_LEVEL ; i++)
		{
			S32 index = primitive_set[i].Get(key, -1);
			if (index >= 0)
			{
				primitive_array[i][index] = NullPtr;
				primitive_set[i].Remove(key);
			}
		}
	}

	void MeshBase::SetPartVisible(int lod, const Core::Identifier & key, bool flag)
	{
		S32 s = primitive_set[lod].Get(key, -1);
		if( s != -1)
		{
			primitive_array[lod][s]->SetVisible(flag);
		}
	}

	/// get position
	const Vector3 & MeshBase::GetPosition()
	{
		return position;
	}

	/// set position
	void MeshBase::SetPosition(const Vector3 & pos)
	{
		if (position != pos)
		{
			position = pos;
			transform_dirty = true;
		}
	}

	/// get rotation
	const Quaternion & MeshBase::GetRotation()
	{
		return rotation;
	}

	/// set rotation
	void MeshBase::SetRotation(const Quaternion & rot)
	{
		if (rotation != rot)
		{
			rotation = rot;
			transform_dirty = true;
		}
	}

	/// get scale
	const Vector3 & MeshBase::GetScale()
	{
		return scale;
	}

	/// set scale
	void MeshBase::SetScale(const Vector3 & s)
	{
		if (scale != s)
		{
			scale = s;
			transform_dirty = true;
		}
	}

	/// get visible
	bool MeshBase::GetVisible()
	{
		return visible;
	}

	/// set visible
	void MeshBase::SetVisible(bool flag)
	{
		if (visible != flag)
			visible = flag;
	}

	/// is ready
	bool MeshBase::IsReady()
	{
		HashSet<Identifier, S32>::Enumerator it(primitive_set[mesh_lod_level]);

		while (it.MoveNext())
		{
			tempc_ptr(GsPrimitive) primitive = primitive_array[mesh_lod_level][it.Value()];

			if (primitive && !primitive->IsReady())
				return false;
			else if(primitive && primitive->m_MeshData)
			{
				U32 count = primitive->m_MeshData->primitives.Size();
				for(U32 i = 0 ; i < count ; i++)
				{
					Primitive &item = primitive->m_MeshData->primitives[i];
					if(item.material)
					{
						U32 tex_count = item.material->texture_uniform.Size();
						for(U32 j = 0 ; j < tex_count; j++)
						{
							U32 tex_count_k = item.material->texture_uniform[j].Size();
							for(U32 k = 0 ; k < tex_count_k ; k++)
							{
								TextureUniformImpl &tex_item = item.material->texture_uniform[j][k];
								if(tex_item.value && tex_item.value->IsReady() == false)
								{
									return false;
								}
							}
						}
					}
				}
			}
		}

		return true;
	}

	void MeshBase::UpdateLod()
	{
		mesh_lod_level = 0;
	}

	void MeshBase::SetBaseLodLevel(S32 level)
	{
		if (level < 0)
			level = 0;

		mesh_base_lod_level = level;
	}

	S32 MeshBase::GetShaderLod()
	{
		if (shader_lod_level < 0 || shader_lod_level >= MESH_LOD_LEVEL)
		{
			if (gRender && gRender->lod_control)
				return gRender->lod_control->GetShaderLod();
			else
				return 0;
		}

		return shader_lod_level;
	}

	void MeshBase::UpdateBoundingBox()
	{
		HashSet<Identifier, S32>::Enumerator it(primitive_set[mesh_lod_level]);

		aabb.Min = Vector3(F32_MAX, F32_MAX, F32_MAX);
		aabb.Max = Vector3(-F32_MAX, -F32_MAX, -F32_MAX);

		while (it.MoveNext())
		{
			tempc_ptr(GsPrimitive) primitive = primitive_array[mesh_lod_level][it.Value()];
			if (primitive && primitive->IsReady())
			{
				primitive->Update();
				if (primitive->GetAABB().Max >= primitive->GetAABB().Min)
					aabb.UnionWithAABB(primitive->GetAABB());
			}
		}
	}

	void MeshBase::Update()
	{	
		UpdateLod();
	}

	AxisAlignedBox& MeshBase::GetAABB()
	{
		return aabb;
	}

	const U32 MeshBase::GetPrimitiveCount()
	{
		return primitive_set[mesh_lod_level].Size();
	}

	/// constructor
	StaticMesh::StaticMesh(const Core::Identifier & n)
		: MeshBase(n)
	{
	}

	/// constructor
	SkinMesh::SkinMesh(const Core::Identifier & n)
		: MeshBase(n)
	{
	}

	/// create primitve
	sharedc_ptr(GsPrimitive) SkinMesh::CreatePrimitive(const Core::Identifier & key, bool blink, bool async)
	{
		if (key.Length() <= 0)
			return NullPtr;

		CStrBuf<256> str(name.Str());
		if (!str.endwith('/'))
			str.contract('/');
		str.contract(key.Str());


		sharedc_ptr(MeshResource) mesh_res = RESOURCE_GET(str, MeshResource);

		if (mesh_res)
		{
			mesh_res->Load(async);
		}

		sharedc_ptr(SkinedPrimitive) primitive;

		if (mesh_res)
		{
			primitive = ptr_new SkinedPrimitive(mesh_res);
		}

		primitive->blink = blink;

		return primitive;
	}

	void SkinMesh::UpdateLod()
	{
		U32 base = 0, top = 0;

		if (gRender->lod_control->IsLodOn())
		{
			base = mesh_base_lod_level;
			top = MESH_LOD_LEVEL;
		}
		else
		{
			base = 0;
			top = 1;
		}

		//check is primitive ready
		for (U32 i = base; i < top; i++)
		{
			primitive_set_ready[i] = true;

			if (!primitive_set[i].Size())
			{
				primitive_set_ready[i] = false;
				continue;
			}

			HashSet<Identifier, S32>::Enumerator it(primitive_set[i]);
			while (it.MoveNext())
			{
				tempc_ptr(GsPrimitive) primitive = primitive_array[i][it.Value()];
				if (!primitive || !primitive->IsReady())
				{
					primitive_set_ready[i] = false;
					break;
				}
			}
		}

		uint current_mesh_lod = gRender->lod_control->GetMeshLod(GetPosition());

		if (!gRender->lod_control->IsLodOn())
		{
			if (current_mesh_lod != mesh_lod_level)
				transform_dirty = true;

			mesh_lod_level = current_mesh_lod;

			return;
		}

		for (S32 i = current_mesh_lod; i < MESH_LOD_LEVEL; i++)
		{
			if (primitive_set_ready[i])
			{
				current_mesh_lod = i;
				break;
			}
		}

		if (!primitive_set_ready[current_mesh_lod])
		{
			for (S32 i = current_mesh_lod; i >= mesh_base_lod_level; i--)
			{
				if (primitive_set_ready[i])
				{
					current_mesh_lod = i;
					break;
				}
			}
		}

		if (current_mesh_lod != mesh_lod_level)
		{
			mesh_lod_level = current_mesh_lod;
			transform_dirty = true;
		}

		// shader lod
		if (gGame->config->GetDynShaderLod())
			shader_lod_level = gRender->lod_control->GetShaderLod(GetPosition());
		else
			shader_lod_level = gRender->lod_control->GetShaderLod();
	}

	/// update
	void SkinMesh::Update()
	{
		UpdateLod();
		if (primitive_set_ready)
		{
			HashSet<Identifier, S32>::Enumerator it(primitive_set[mesh_lod_level]);

			while (it.MoveNext())
			{
				tempc_ptr(GsPrimitive) primitive = primitive_array[mesh_lod_level][it.Value()];
				if (primitive && primitive->IsReady())
				{
					primitive->SetPose(pose);
				}
			}
		}

		UpdateBoundingBox();
	}



	/// draw
	void SkinMesh::Draw(Primitive::DrawType type, bool immediate)
	{
		if (GetVisible() && pose)
		{
			if (!primitive_set_ready[mesh_lod_level])
				return;
		}

		MeshBase::Draw(type, immediate);
	}
}

DEFINE_PDE_TYPE_CLASS(Client::CharacterMesh)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_METHOD(SetMesh);
	}
};

REGISTER_PDE_TYPE(Client::CharacterMesh);

namespace Client
{
	/// constructor
	CharacterMesh::CharacterMesh(const Core::Identifier & n)
		: SkinMesh(n)
	{
	}

	
	/// set mesh
	static int setter_nil(Lua::LuaState *L)
	{
		return 0;
	}

	/// load mesh
	void CharacterMesh::LoadMesh(String path)
	{
		sharedc_ptr(ScriptLua) lua = RESOURCE_LOAD(path, false, ScriptLua);

		if (lua)
		{
			lua_set.Set(lua->GetKey(), lua);
			Lua::LuaState *L = Lua::LuaState::NewState();
			if (L->LoadBuffer(lua->GetBuffer(), lua->GetSize(), path) == 0)
			{
				L->NewTable();
				L->PushPtr(ptr_static_cast<CharacterMesh>(this));
				L->GetMetatable(-1);
				L->PushCFunction(&setter_nil);
				L->SetField(-2, "__newindex"); 
				L->Pop(1);
				L->SetField(-2, "character");

				L->SetFenv(-2);
				if (L->DoCall(0, 0))
				{
					const char *msg = L->ToString(-1);
					if (msg) Console.WriteLine(msg);
					L->Pop(1);
				}
			}
			else
			{
				const char *msg = L->ToString(-1);
				if (msg) Console.WriteLine(msg);
				L->Pop(1);
			}
			L->Close();
		}
	}

	/// set mesh
	void CharacterMesh::SetMesh(const Core::String & key, const Core::String & value, bool is_first_person, int mesh_lod_level)
	{
		if (name !=MESH_KEY_PLAYER || is_first_person)
			AddPrimitive(key, value, mesh_lod_level);
	}

	/// add part set
	void CharacterMesh::AddPartSet(String path, const Core::Array<Core::String> & p)
	{
		parts.Clear();

		for (uint i = 0; i < p.Size(); i++)
			AddPartKey(path, p[i]);

		LoadPart();
	}

	/// add part
	void CharacterMesh::AddPart(String path, String part)
	{
		CStrBuf<256> str(path);
		str.contractf("%s.lua", part.RefStr());
		parts.PushBack(str);
		LoadMesh(str);
	}

	/// add part key
	void CharacterMesh::AddPartKey(Core::String path, Core::String part)
	{
		CStrBuf<256> str(path);
		str.contractf("%s.lua", part.RefStr());
		parts.PushBack(str);
	}

	/// load part
	void CharacterMesh::LoadPart()
	{
		uint size = parts.Size();
		if (size == 0)
			return;

		if (!gLevel)
			return;

		Lua::LuaState *L = gLevel->lua_state;
		int top = L->GetTop();
		L->NewTable();
		L->NewTable();
		L->PushPtr(PDE_TYPE_OF(Vector3)->GetConstructor());
		L->SetField(-2, "Vector3");
		L->PushPtr(PDE_TYPE_OF(DetachablePartInfo)->GetConstructor());
		L->SetField(-2, "DetachablePartInfo");
		L->PushPtr(ptr_static_cast<CharacterMesh>(this));
		L->GetMetatable(-1);
		L->PushCFunction(&setter_nil);
		L->SetField(-2, "__newindex"); 
		L->Pop(1);
		L->SetField(-2, "character");

		for (uint i = 0; i < size; i++)
		{
			sharedc_ptr(ScriptLua) lua = RESOURCE_LOAD(parts[i], false, ScriptLua);
			if (lua)
			{
				lua_set.Set(lua->GetKey(), lua);
				if (L->LoadBuffer(lua->GetBuffer(), lua->GetSize(), parts[i]) == 0)
				{
					L->PushValue(top + 1);
					L->SetFenv(-2);
					if (L->DoCall(0, 0))
					{
						const char *msg = L->ToString(-1);
						if (msg) Console.WriteLine(msg);
						L->Pop(1);
					}
				}
				else
				{
					const char *msg = L->ToString(-1);
					if (msg) Console.WriteLine(msg);
					L->Pop(1);
				}
			}
		}

		L->SetTop(top);
	}
}



DEFINE_PDE_TYPE_CLASS(Client::AnimObjectMesh)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_METHOD(SetMesh);
	}
};

REGISTER_PDE_TYPE(Client::AnimObjectMesh);

namespace Client
{
	/// constructor
	AnimObjectMesh::AnimObjectMesh(const Core::Identifier & n)
		: SkinMesh(n)
	{
	}

	/// load mesh
	void AnimObjectMesh::LoadMesh(String path)
	{
		sharedc_ptr(ScriptLua) lua = RESOURCE_LOAD(path, false, ScriptLua);

		if (lua)
		{
			lua_set.Set(lua->GetKey(), lua);
			Lua::LuaState *L = Lua::LuaState::NewState();
			if (L->LoadBuffer(lua->GetBuffer(), lua->GetSize(), path) == 0)
			{
				L->NewTable();
				L->PushPtr(ptr_static_cast<AnimObjectMesh>(this));
				L->GetMetatable(-1);
				L->PushCFunction(&setter_nil);
				L->SetField(-2, "__newindex"); 
				L->Pop(1);
				L->SetField(-2, "character");

				L->SetFenv(-2);
				if (L->DoCall(0, 0))
				{
					const char *msg = L->ToString(-1);
					if (msg) Console.WriteLine(msg);
					L->Pop(1);
				}
			}
			else
			{
				const char *msg = L->ToString(-1);
				if (msg) Console.WriteLine(msg);
				L->Pop(1);
			}
			L->Close();
		}
	}

	/// set mesh
	void AnimObjectMesh::SetMesh(const Core::String & key, const Core::String & value, bool is_first_person, int mesh_lod_level)
	{
		if (name !=MESH_KEY_PLAYER || is_first_person)
			AddPrimitive(key, value, mesh_lod_level);
	}

	/// add part set
	void AnimObjectMesh::AddPartSet(String path, const Core::Array<Core::String> & p)
	{
		parts.Clear();

		for (uint i = 0; i < p.Size(); i++)
			AddPartKey(path, p[i]);

		LoadPart();
	}

	/// add part
	void AnimObjectMesh::AddPart(String path, String part)
	{
		CStrBuf<256> str(path);
		str.contractf("%s.lua", part.RefStr());
		parts.PushBack(str);
		LoadMesh(str);
	}

	/// add part key
	void AnimObjectMesh::AddPartKey(Core::String path, Core::String part)
	{
		CStrBuf<256> str(path);
		str.contractf("%s.lua", part.RefStr());
		parts.PushBack(str);
	}

	/// load part
	void AnimObjectMesh::LoadPart()
	{
		uint size = parts.Size();
		if (size == 0)
			return;

		if (!gLevel)
			return;

		Lua::LuaState *L = gLevel->lua_state;
		int top = L->GetTop();
		L->NewTable();
		L->NewTable();
		L->PushPtr(PDE_TYPE_OF(Vector3)->GetConstructor());
		L->SetField(-2, "Vector3");
		L->PushPtr(PDE_TYPE_OF(DetachablePartInfo)->GetConstructor());
		L->SetField(-2, "DetachablePartInfo");
		L->PushPtr(ptr_static_cast<AnimObjectMesh>(this));
		L->GetMetatable(-1);
		L->PushCFunction(&setter_nil);
		L->SetField(-2, "__newindex"); 
		L->Pop(1);
		L->SetField(-2, "character");

		for (uint i = 0; i < size; i++)
		{
			sharedc_ptr(ScriptLua) lua = RESOURCE_LOAD(parts[i], false, ScriptLua);
			if (lua)
			{
				lua_set.Set(lua->GetKey(), lua);
				if (L->LoadBuffer(lua->GetBuffer(), lua->GetSize(), parts[i]) == 0)
				{
					L->PushValue(top + 1);
					L->SetFenv(-2);
					if (L->DoCall(0, 0))
					{
						const char *msg = L->ToString(-1);
						if (msg) Console.WriteLine(msg);
						L->Pop(1);
					}
				}
				else
				{
					const char *msg = L->ToString(-1);
					if (msg) Console.WriteLine(msg);
					L->Pop(1);
				}
			}
		}

		L->SetTop(top);
	}
}



namespace Client
{
	/// constructor
	DynamicStuff::DynamicStuff(by_ptr(Skeleton) skeleton)
	{
		if (skeleton)
			animation = ptr_new AnimationNodeCustom(skeleton);
	}

	/// update
	void DynamicStuff::Update(float frame_time)
	{
		if (animation)
		{
			animation->Update(frame_time);

			if (mesh)
			{
				mesh->pose = animation->GetPose();
				mesh->Update();
			}
		}
	}

	/// draw
	void DynamicStuff::Draw(Primitive::DrawType drawtype, bool immediate)
	{
		if (mesh)
			mesh->Draw(drawtype, immediate);
	}

	/// set animation set
	void DynamicStuff::SetAnimationSet(const char * key)
	{
		if (animation)
		{
			sharedc_ptr(AnimationSet) animation_set = ptr_new AnimationSet;
			sharedc_ptr(AnimationSetRes) res = RESOURCE_GET_BYTYPE(key, ANIMATIONSET_TYPE, AnimationSetRes);
			if (gLevel->animation_manager)
				gLevel->animation_manager->AddAnimationSetRes(res->GetKey(), res);

			animation_set->SetAnimationSet(key, res);
			animation->SetAnimationSet(animation_set);
		}
	}
}


namespace Client
{
	/// constructor
	CharacterManager::CharacterManager(by_ptr(Level) l)
		: level(l)
		, state(kNone)
	{
		LoadLuaScrips();
	}

	/// destructor
	CharacterManager::~CharacterManager()
	{
		lua_set.Clear();
		character_set.Clear();
	}

	/// initialize
	bool CharacterManager::Initialize()
	{
		state = kReady;

		preload_firstperson_mesh = ptr_new SkinMesh(MESH_KEY_PLAYER);
		preload_thirdperson_mesh = ptr_new SkinMesh(MESH_KEY_CHARACTER);

		preload_weapon_mesh = ptr_new SkinMesh(MESH_KEY_WEAPON);

		return true;
	}

	/// terminate
	void CharacterManager::Terminate()
	{
		character_set.Clear();

		state = kNone;

		preload_firstperson_mesh = NullPtr;
		preload_thirdperson_mesh = NullPtr;

		preload_weapon_mesh = NullPtr;
	}

	void CharacterManager::AddPreloadMesh(tempc_ptr(CharacterInfo)& info)
	{
		for (U32 i = 0; i < MESH_LOD_LEVEL; i++)
		{
			if (info)
			{
				//preload firstperson
				{
					CharacterInfo::MeshSet::Enumerator it(info->mesh_set_first_person[i]);
					while (it.MoveNext())
					{
						if (!preload_firstperson_mesh->GetPrimitive(it.Value()))
						{
							preload_firstperson_mesh->AddPrimitive(it.Value(), i);
						}
					}
				}
				
				//preload thirdperson
				{
					CharacterInfo::MeshSet::Enumerator it(info->mesh_set_third_person[i]);
					while (it.MoveNext())
					{
						if (!preload_thirdperson_mesh->GetPrimitive(it.Value()))
						{
							preload_thirdperson_mesh->AddPrimitive(it.Value(), i);
						}
					}
				}			
			}
		}
	}

	void CharacterManager::AddPreloadWeapon(tempc_ptr(WeaponInfo)& weapon_info)
	{
		for (U32 i = 0; i < MESH_LOD_LEVEL; i++)
		{
			if (preload_weapon_mesh && weapon_info)
			{
				WeaponInfo::MeshSet::Enumerator it(weapon_info->mesh[i]);

				while (it.MoveNext())
				{
					for (U32 j = 0; j < it.Value().parts.Size(); j++)
					{
						if (!preload_weapon_mesh->GetPrimitive(it.Value().parts[j]))
						{
							preload_weapon_mesh->AddPrimitive(it.Value().parts[j], i);
						}
					}
				}
			}
		}
	}

	/// update
	void CharacterManager::Update(float frame_time)
	{
		if (state != kReady)
			return;

		for (uint i = 0; i < character_set.Size(); ++i)
		{
			tempc_ptr(Character) ch = character_set[i];

			if (ch)
			{
				if (gLevel->player_manager)
				{
					if (ch->uid == gLevel->player_manager->viewer_id)
					{
						Character::ViewMode view_mode = ch->camera_distance > 0.5f ? Character::kThirdPerson : Character::kFirstPerson;

						if (ch->IsDied())
							view_mode = Character::kThirdPerson;

						ch->SetViewMode(view_mode);
					}
					else
						ch->SetViewMode(Character::kThirdPerson);
				}

				ch->Update(frame_time);
				ch->UpdateOccludee();
			}
		}
	}

	/// timestepupdate
	void CharacterManager::TimeStepUpdate(float frame_time)
	{
		if (state != kReady)
			return;

		if (gGame->channel_connection)
			gGame->channel_connection->SyncPlayerData();

		for (uint i = 0; i < character_set.Size(); ++i)
		{
			tempc_ptr(Character) ch = character_set[i];

			if (ch)
			{
				if (!ch->CanControl())
					ch->UpdateSyncData(frame_time);
				ch->TimeStepUpdate(frame_time);
			}
		}
	}

	/// on render
	void CharacterManager::OnRender(float frame_time)
	{
		if (state != kReady)
			return;

		for (uint i = 0; i < character_set.Size(); ++i)
		{
			tempc_ptr(Character) ch = character_set[i];
			if (ch)
				ch->OnRender(frame_time);
		}
	}

	/// add character
	void CharacterManager::AddCharacter(by_ptr(Character) c)
	{
		if (c)
		{
			character_set.PushBack(c);
		}
	}

	/// remove character
	void CharacterManager::RemoveCharacter(uint id)
	{
		for (int i = character_set.Size() - 1; i >= 0; --i)
		{
			if (character_set[i] && character_set[i]->uid == id)
			{
				character_set.RemoveAt(i);
			}
		}
	}
	/// get Character
	tempc_ptr(Character) CharacterManager::GetCharacter(uint id)
	{
		for (uint i = 0; i < character_set.Size(); ++i)
		{
			if (character_set[i] && character_set[i]->uid == id)
				return character_set[i];
		}

		return NullPtr;
	}

	/// get next character
	tempc_ptr(Character) CharacterManager::GetCharacterNext(uint id, byte team_mask, bool reverse)
	{
		int current_index = -1;
		int size = character_set.Size();

		if (id != 0)
		{
			for (int i = 0; i < size; ++i)
			{
				if (character_set[i] && character_set[i]->uid == id)
				{
					current_index = i;
					break;
				}
			}
		}

		if (reverse)
		{
			if (current_index >= 0 && current_index < size)
			{
				for (int i = current_index - 1; i >= 0; --i)
				{
					if (character_set[i] 
						&& !character_set[i]->IsDied() 
						&& ((1<<character_set[i]->GetTeam()) & team_mask))
						return character_set[i];
				}
			}

			for (int i = size - 1; i > current_index; --i)
			{
				if (character_set[i] 
					&& !character_set[i]->IsDied()
					&& ((1<<character_set[i]->GetTeam()) & team_mask))
					return character_set[i];
			}
		}
		else
		{
			for (int i = current_index + 1; i >= 0 && i < size; ++i)
			{
				if (character_set[i] 
					&& !character_set[i]->IsDied()
					&& ((1<<character_set[i]->GetTeam()) & team_mask))
					return character_set[i];
			}

			if (current_index >= 0 && current_index < size)
			{
				for (int i = 0; i < current_index; ++i)
				{
					if (character_set[i] 
						&& !character_set[i]->IsDied()
						&& ((1<<character_set[i]->GetTeam()) & team_mask))
						return character_set[i];
				}
			}
		}

		return NullPtr;
	}

	/// get characters
	const Array<sharedc_ptr(Character)> & CharacterManager::GetCharacters()
	{
		return character_set;
	}

	static void LoadLua(const String & path, Core::HashSet<Core::Identifier, sharedc_ptr(ScriptLua)> & lua_set)
	{
		if (Path::IsDirectory(path))
		{
			PdeItPath it;
			it.Reset(path, false);

			while(it.MoveNext())
			{
				CStrBuf<MAX_PATH> str(path);
				str.contractf("/%s", it.Name().buff());

				if (it.IsDirectory())
					LoadLua(str, lua_set);
				else
				{
					sharedc_ptr(ScriptLua) script = RESOURCE_LOAD(str, false, ScriptLua);
					if (script)
						lua_set.Add(str, script);
				}
			}
		}
	}

	/// load lua scrips
	void CharacterManager::LoadLuaScrips()
	{
		LoadLua("/character", lua_set);
		LoadLua("/weapon", lua_set);
	}
}

namespace Client
{
	/// constructor
	PlayerManager::PlayerManager(by_ptr(Level) l)
		: level(l)
		, state(kNone)
		, viewer_id(0)
		, view_mode(Character::kFirstPerson)
		, view_distance(0)
		, viewer_state(0)
		, need_gun_tower_ammo(false)
	{
	}

	/// update control
	void PlayerManager::UpdateControl(by_ptr(Input) input, float time)
	{
		if (state != kReady)
			return;

		float frame_time = time;

		if (frame_time <= 0)
			frame_time = Task::GetFrameTime();

		Vector3 control_rotate(0, 0, 0);
		Vector3 control_move(0, 0, 0);

		float mouse_sensitivity_value = gGame->config->GetSensitivity();

		if(player)
		{
			tempc_ptr(GunBase) gun = ptr_dynamic_cast<GunBase>(player->GetWeapon());

			if (gun)
			{
				if (gun->sight_current != 0)
					mouse_sensitivity_value = gGame->config->GetSensitivitySniper();
			}
		}

		// adjust sensitivity value
		mouse_sensitivity_value = Lerp(0.01f, 4.0f, (mouse_sensitivity_value - 1.f) / 19.f);

		if(gGame->channel_connection->GetState() == ChannelConnection::kInReplay)
		{
			control_move = Vector3(0,0,0);
			control_rotate = Vector3(0,0,0);
		}
		else
		{
			control_rotate = gGame->input->GetMouseMove() * mouseSensitivity * mouse_sensitivity_value;
			control_rotate.x += gGame->input->GetPadStick(0, 2) * frame_time * 2;
			control_rotate.y -= gGame->input->GetPadStick(0, 3) * frame_time * 2;

			if (gGame->config->IsActionDown(kActionTurnLeft)) control_rotate.x -= 2 * frame_time;
			if (gGame->config->IsActionDown(kActionTurnRight)) control_rotate.x += 2 * frame_time;
			if (gGame->config->IsActionDown(kActionTurnUp)) control_rotate.y -= 2 * frame_time;
			if (gGame->config->IsActionDown(kActionTurnDown)) control_rotate.y += 2 * frame_time;

			if (gGame->config->GetInverseMouse())
				control_rotate.y = -control_rotate.y;

			bool ischargecontrol = false;
			if(player)
			{
				if (player->GetWeapon() && player->GetWeapon()->GetWeaponType() == kWeaponTypeZombieCharge)
				{
					tempc_ptr(ZombieCharge) zc = ptr_dynamic_cast<ZombieCharge>(player->GetWeapon());
					if (zc && zc->isCharge)
						ischargecontrol = true;
				}
				else if (player->GetWeapon() && player->GetWeapon()->GetWeaponType() == kWeaponTypeZombieGun)
				{
					tempc_ptr(ZombieGun) zc = ptr_dynamic_cast<ZombieGun>(player->GetWeapon());
					if (zc && zc->isCharge)
						ischargecontrol = true;
				}
			}
			
			if (ischargecontrol)
			{
				control_move.x = 0;
				control_move.y = 0;
				control_move.z = 1;
			}
			else
			{
				control_move.x = gGame->config->IsActionDown(kActionMoveLeft) - gGame->config->IsActionDown(kActionMoveRight) - gGame->input->GetPadStick(0, 0);
				control_move.y = gGame->input->GetPadStick(0, 4) - gGame->input->GetPadStick(0, 5);
				control_move.z = gGame->config->IsActionDown(kActionMoveForward) - gGame->config->IsActionDown(kActionMoveBackward) + gGame->input->GetPadStick(0, 1);
			}
		}

#if DEBUG_CAMERA	// debug camera
		// change viewmode
		if (gGame->input->IsKeyPressed(KC_C))
		{
			SetCameraMode((Camera::ControlMode)((gGame->camera->control_mode + 1) % Camera::kControlModeCount));
		}
		//if (gGame->input->IsKeyPressed(KC_P))
		//{
		//	gLevel->isneedparticle = true;
		//}
#endif	// debug camera

		// change viewmode
		//if ((!player || player->IsDied()) && gGame->input->IsKeyPressed(KC_V))
		//{
		//	if (gGame->camera->control_mode != Camera::kDiedMode)
		//	{
		//		gGame->camera->control_mode = (Camera::ControlMode)(gGame->camera->control_mode + 1);
		//		if (gGame->camera->control_mode < Camera::kFreeMove)
		//			gGame->camera->control_mode = Camera::kViewMode;
		//		else if (gGame->camera->control_mode > Camera::kViewMode)
		//			gGame->camera->control_mode = Camera::kFreeMove;

		//		SetCameraMode(gGame->camera->control_mode);
		//	}
		//}

		// select kick
		if(gLevel->kick_select_open && gLevel->kick_select_id == 0)
		{
			if(gGame->config->IsActionPressed(kActionKickYes))
			{
				gLevel->kick_select_id = 1;
				if(gGame->channel_connection)
					gGame->channel_connection->KickClientVote(1);
			}
			if(gGame->config->IsActionPressed(kActionKickNo))
			{
				gLevel->kick_select_id = 2;
				if(gGame->channel_connection)
					gGame->channel_connection->KickClientVote(0);
			}
		}

		if(gGame->config->IsActionPressed(kTakePicture))
		{
			gGame->bSavePhoto = true;
		}

		if (gGame->config->IsActionPressed(kActionUseSkill))
		{
			if (player && player->can_Invincible == true && gLevel->game_type == RoomOption::kCommonZombieMode)
			{
				sharedc_ptr(PlayerSkill) skill = ptr_new(PlayerSkill);
				skill->type = kSkillInvincible;
				skill->effect_time = 5.0f;
				gGame->channel_connection->UseSkill(skill);
				gLevel->GetCharacter(viewer_id)->can_Invincible = false;
			}

			if (player && !player->IsDied() && gLevel->game_type == RoomOption::kBossMode2)
			{
				sharedc_ptr(PlayerSkill) skill = ptr_new(PlayerSkill);
				skill->type = kSkillBoss2_S2;
				gGame->channel_connection->UseSkill(skill);
			}
		}

		if(gLevel->game_type == RoomOption::kEditMode && gGame->config->IsActionPressed(kActionDestroyTowerGun))
		{
			tempc_ptr(Character) c = gLevel->GetPlayer();

			float distance = 2.f;
			NxRay ray;
			ray.orig = (const NxVec3 &)c->GetCameraPosition();
			ray.dir = (const NxVec3 &)(Vector3(0, 0, -1) * c ->GetCameraRotation());

			NxRaycastHit hit;

			uint group_id = 0;
			group_id |= 1 << PhysxSystem::kStatic;

			NxShape* shape = gPhysxScene->raycastClosestShape(ray, NX_ALL_SHAPES, hit, group_id, distance);

			if (shape)
			{
				NxActor& actor = shape->getActor();
				tempc_ptr(DummyObject) p = DummyObject::FromNxActor(actor);
				tempc_ptr(GunTowerBuilderPlus) w = ptr_dynamic_cast<GunTowerBuilderPlus>(c->GetWeapon());
				if (w && p && p->sub_type != 4)
				{
					w->DestroyTower(p);
					FmodSystem::PlayEvent("bj/event/wall_cancel");
				}
			}
		}

		if (gGame->config->IsActionPressed(kActionUseSkill2))
		{
			if (gLevel->game_type == RoomOption::kCommonZombieMode && player->GetTeam() == 0 && player->cd_time == 0.0f)
			{
				gGame->channel_connection->UseSkillSuperMan(player->uid);
			}

			if (player && !player->IsDied() && gLevel->game_type == RoomOption::kBossMode2)
			{
				sharedc_ptr(PlayerSkill) skill = ptr_new(PlayerSkill);
				skill->type = kSkillBoss2_S1;
				gGame->channel_connection->UseSkill(skill);

				tempc_ptr(StateMainGame) state_main = ptr_dynamic_cast<StateMainGame>(gGame->machine.CurrentState());
				if (state_main && player->boss2_initiative_type > 0 && player->boss2_initiative_type != 2)
				{
					F32 _time;
					byte _type;
					if (player->boss2_initiative_type == 1)
					{
						_time = 6.0f;
						_type = 8;
					} 
					else if (player->boss2_initiative_type == 3)
					{
						_time = 10.0f;
						_type = 9;
					} 
					else if (player->boss2_initiative_type == 4)
					{
						_time = 10.0f;
						_type = 10;
					}
					state_main->ui->OnAddSkillBuff_Item(_type,_time);
				}
			}

			if (player && !player->IsDied() && gLevel->game_type == RoomOption::kItemMode)
			{
				Core::Array<byte> uids;

				if (player->itemmode_item_slot != -1)
				{
					if (player->itemmode_item_slot == 6 || 
						player->itemmode_item_slot == 7 || 
						player->itemmode_item_slot == 8 || 
						player->itemmode_item_slot == 9 || 
						player->itemmode_item_slot == 11 || 
						player->itemmode_item_slot == 12)
					{
						float distance = 0;
						const Array<sharedc_ptr(Character)> & characters = gLevel->GetCharacters();

						for (U32 i = 0; i < characters.Size(); i++)
						{
							if (characters[i]->GetTeam() < 2 && characters[i]->GetTeam() != player->GetTeam() &&
								characters[i]->CheckGrenade2(player->GetPosition() + Vector3(0,player->GetHeight()/2,0), distance))
							{
								if (distance <= 15.f)
									uids.PushBack(characters[i]->uid);
							}
						}
					}
					else if (player->itemmode_item_slot == 4)
					{
						player->itemmode_zibao_timer = 3.f;
						player->itemmode_zibao = true;
					}
					else if (player->itemmode_item_slot == 14)
					{
						player->itemmode_flag1_timer = 30.f;
						player->itemmode_flag1 = true;
					}

					gGame->channel_connection->UseItem_ItemMode(uids);

					player->itemmode_item_slot = -1;
				}
			}
			if (player && !player->IsDied() && gLevel->game_type == RoomOption::KMoonMode && player->isMoonBoss == false)
			{
				player->isMoonBoss = true;
				gGame->channel_connection->MoonBoss();
				player->itemmode_flag1_timer = 20.f;
				tempc_ptr(StateMainGame) state_main = ptr_dynamic_cast<StateMainGame>(gGame->machine.CurrentState());
				state_main->ui->m_Showmiddle_str_time = 4.0f;
				state_main->ui->m_Middle_str = gLang->GetTextW(L"������һ�����ص�����������Ϊɱ¾���ģ�\nɱ¾������2��ǿ������������2��[�ո�]����2����");
			}
		}

		if( player && player->radio_state == 0)
		{
			
			if (gGame->config->IsActionPressed(kActionUseSkillSurvival_1))
			{
				if (gLevel->game_type == RoomOption::kSurvivalMode)
				{
					if (player->isghost == true && player->ghostfirecount >= 15)
					{
						gGame->channel_connection->UseItemSurvivalByGhost(1);
						FmodSystem::PlayEvent("bj/fx/2d/survival_ghost_set_trap");
						tempc_ptr(StateMainGame) state_main = ptr_dynamic_cast<StateMainGame>(gGame->machine.CurrentState());
						state_main->ui->m_Showmiddle_str_time = 3.0f;
						state_main->ui->m_Middle_str = gLang->GetTextW(L"��ʹ����15������֮�𣬷�����һ���ӵ�͵������");
					}
					else if (player->basecharacter_info->survivalbag.Size() > 0)
					{
						gGame->channel_connection->UseItemSurvival(1);						
					}
				}
			}
           
			if (gGame->config->IsActionPressed(kActionUseSkillSurvival_2))
			{
				if (gLevel->game_type == RoomOption::kSurvivalMode)
				{
					if (player->isghost == true && player->ghostfirecount >= 20)
					{
						gGame->channel_connection->UseItemSurvivalByGhost(2);
						FmodSystem::PlayEvent("bj/fx/2d/survival_ghost_set_trap");
						tempc_ptr(StateMainGame) state_main = ptr_dynamic_cast<StateMainGame>(gGame->machine.CurrentState());
						state_main->ui->m_Showmiddle_str_time = 3.0f;
						state_main->ui->m_Middle_str = gLang->GetTextW(L"��ʹ����20������֮�𣬷�����һ������͵ȡ����");
					}
					else if (player->basecharacter_info->survivalbag.Size() > 1)
					{
						gGame->channel_connection->UseItemSurvival(2);						
					}
				}
			}
			if (gGame->config->IsActionPressed(kActionUseSkillSurvival_3))
			{
				if (gLevel->game_type == RoomOption::kSurvivalMode)
				{
					if ( player->isghost == true  && player->ghostfirecount >= 20)
					{
						gGame->channel_connection->UseItemSurvivalByGhost(3);
						FmodSystem::PlayEvent("bj/fx/2d/survival_ghost_set_trap");
						tempc_ptr(StateMainGame) state_main = ptr_dynamic_cast<StateMainGame>(gGame->machine.CurrentState());
						state_main->ui->m_Showmiddle_str_time = 3.0f;
						state_main->ui->m_Middle_str = gLang->GetTextW(L"��ʹ����20������֮�𣬷�����һ���˺��ӱ�����");
					}
					else if (player->basecharacter_info->survivalbag.Size() > 2)
					{
						gGame->channel_connection->UseItemSurvival(3);						
					}
				}
			}
			if (gGame->config->IsActionPressed(kActionUseSkillSurvival_4))
			{
				if (gLevel->game_type == RoomOption::kSurvivalMode)
				{
					if (player->basecharacter_info->survivalbag.Size() > 3)
					{
						gGame->channel_connection->UseItemSurvival(4);					
					}
				}
			}
			if (gGame->config->IsActionPressed(kActionUseSkillSurvival_5))
			{
				if (gLevel->game_type == RoomOption::kSurvivalMode)
				{
					if (player->basecharacter_info->survivalbag.Size() > 4)
					{
						gGame->channel_connection->UseItemSurvival(5);
					}
				}
			}
		}

		//if(gGame->config->IsActionPressed(kActionUseSkill2))
		//{
		//	if(player)
		//	{
		//		HashSet<uint, sharedc_ptr(DummyObject)>::Enumerator it(gLevel->dummy_object_set);
		//		while (it.MoveNext())
		//		{
		//			if(it.Value()->owner_id == player->uid)
		//			{
		//				tempc_ptr(MachineGunTurret) t  =  ptr_dynamic_cast<MachineGunTurret>(it.Value());
		//				if(t)
		//				{
		//					t->MoveCommand(0);
		//				}
		//			}
		//		}
		//	}
		//}
		// test start
		//if(gGame->config->IsActionPressed(kActionUseSkill2))
		//{
		//	if(player)
		//	{
		//		DummyBaseCreateInfo info;
		//		info.position = player->GetPosition() + Vector3(0,0,-1) * player->GetRotation() + Vector3(0,1,0);
		//		info.rotation = player->GetRotation();
		//		info.recover_check_interval = 5.f;
		//		info.recover_per_count_life = 10;
		//		info.recover_range = 10.f;
		//		info.recover_per_percent_ammo = 10;
		//		strcpy_s(info.key, "engineer01001_0/rv1");
		//		char buffer[SYNC_BUFFER_SIZE];
		//		int length = writeUserData(buffer,SYNC_BUFFER_SIZE,info);
		//		gGame->channel_connection->RequestDummyObjectCreate(DummyObject::DUMMY_MEDICAL, buffer, length);
		//	}
		//}
		//if(gGame->config->IsActionPressed(kActionUseSkill))
		//{
		//	if(player)
		//	{
		//		DummyBaseCreateInfo info;
		//		info.position = player->GetPosition() + Vector3(0,0,-1) * player->GetRotation() + Vector3(0,1,0);
		//		info.rotation = player->GetRotation();
		//		
		//		info.damage_modifier = 5;
		//		info.range_start = 1.f;
		//		info.range_end = 50.f;
		//		info.range_modifier = 2.f;
		//		info.base_damage = 5;
		//		
		//		info.angle_speed = PI/8;
		//		info.check_range = 20;
		//		info.fire_interval = 0.5f;
		//		info.check_angle = PI;

		//		info.level = 1;

		//		info.life_time = 20.f;
		//		info.max_ammo_count = 20;

		//		strcpy_s(info.key, "guntower_test/rv1");
		//		char buffer[SYNC_BUFFER_SIZE];
		//		int length = writeUserData(buffer,SYNC_BUFFER_SIZE,info);
		//		gGame->channel_connection->RequestDummyObjectCreate(DummyObject::DUMMY_MACHINE_TURRENT, buffer, length);
		//	}
		//}
		//test end

		if (gGame->camera->control_mode == Camera::kFreeMove)
		{
			gGame->camera->FreeMove(control_move * 5 * frame_time, control_rotate);
			if (gGame->config->IsActionPressed(kActionJump) && player && !player->IsLockStateByType(kLSSelectWeapon))
			{
				viewer_state = kFirst;
				SetCameraMode(Camera::kViewMode);
				tempc_ptr(Character) view_character = gLevel->GetCharacter(viewer_id);
				if(view_character)
					UpdateViewerCameraMode(view_character);		
			}
		}
		else if (gGame->camera->control_mode == Camera::kViewMode)
		{
			if(gGame->config->IsActionPressed(kActionFire) && !player->IsLockStateByType(kLSSelectWeapon))
				ViewModeToNext();

			if (gGame->config->IsActionPressed(kActionSecondFire) && !player->IsLockStateByType(kLSSelectWeapon))
				ViewModeToNext(true);

			tempc_ptr(Character) view_character = gLevel->GetCharacter(viewer_id);

			if (view_character)
			{
				if (gGame->config->IsActionPressed(kActionJump) && !player->IsLockStateByType(kLSSelectWeapon))
				{
					viewer_state++;
					UpdateViewerCameraMode(view_character);				
				}

				view_distance = view_character->camera_distance;
#if DEBUG_CAMERA	// debug camera
				view_distance = view_character->PoolBack(-control_rotate.z);
#endif	// debug camera

				view_mode = view_distance > 0.5f? Character::kThirdPerson: Character::kFirstPerson;

				if (view_character->IsDied())
					view_character->SetViewMode(Character::kThirdPerson);
				else
					view_character->SetViewMode(view_mode);

				view_character->MoveCamera(-control_rotate.x, -control_rotate.y);
			}
		}
		else if (gGame->camera->control_mode == Camera::kCharacterControl)
		{				
			if (player)
			{
				// move
				if (!player->IsDied() && gGame->channel_connection->GetState() != ChannelConnection::kInReplay)
				{
#if DEBUG_CAMERA	// debug camera
					// pool gGame->camera
					player->PoolBack(-control_rotate.z);
#endif	// debug camera

					//debug
					if(gGame->input->IsKeyPressed(KC_0))
					{
						gGame->channel_connection->SaveMap();
					}
// 					if(gGame->input->IsKeyPressed(KC_9))
// 					{
// 						gLevel->GetPlayer()->SetDieBuffer(true);
// 					}

					////end debug

					// player control
					if(player->IsLockStateByType(kLSCamera))
					{
						player->MoveLook(0, 0);
					}
					else
					{
						if (player->control_reverse_timer > 0)
							player->MoveLook(control_rotate.x, control_rotate.y);
						else
							player->MoveLook(-control_rotate.x, -control_rotate.y);
					}


					if (gLevel->round_start_waiting || player->IsLockStateByType(kLSMove) || player->GetKickOnHitTimer() > 0.f 
						|| (gLevel->game_type == RoomOption::kBossMode2 && player->is_boss && player->boss2_head_damage_timer > 0.001f))
					{
						player->SetMove(0, 0);
					}
					else
					{
						if (player->IsAttributeExist(kEffect_Special_ReversalKeyBoard))
							player->SetMove(-control_move.z, -control_move.x);
						else
							player->SetMove(control_move.z, control_move.x);
					}
						
					// jump
					if (gGame->config->IsActionPressed(kActionJump) && !player->IsLockStateByType(kLSJump) && !player->zombie_dying_flag && 
						!((gLevel->game_type == RoomOption::kBossMode2 && player->is_boss && player->boss2_head_damage_timer > 0.001f)))
						player->SetJump(true);

					// fly
					if (gGame->config->IsActionPressed(kActionJump) && !player->IsLockStateByType(kLSJump) && !player->zombie_dying_flag && 
						!((gLevel->game_type == RoomOption::kBossMode2 && player->is_boss && player->boss2_head_damage_timer > 0.001f)))
						if (player->is_boss && gLevel->game_type == RoomOption::kBossMode2 && player->boss2_move_energy > 200)
							player->SetFly(true);

					// boost
					//if ((gGame->config->IsActionDown(kActionMoveForward)||gGame->config->IsActionDown(kActionMoveBackward)||gGame->config->IsActionDown(kActionMoveLeft)||gGame->config->IsActionDown(kActionMoveRight)) && gGame->input->IsKeyDown(KC_LSHIFT) && !gGame->config->IsActionDown(kActionJump) && !player->zombie_dying_flag)
					//	if (player->is_boss && gLevel->game_type == RoomOption::kBossMode2 && player->boss2_move_energy > 0)
					//		player->SetBoost(true);

					if (gGame->config->IsActionDown(kActionMoveForward)&& gGame->input->IsKeyDown(KC_LSHIFT) && !gGame->config->IsActionDown(kActionJump) && !player->zombie_dying_flag && player->is_boss && gLevel->game_type == RoomOption::kBossMode2 && player->boss2_move_energy > 100) player->SetBoost(true,1);
					if (gGame->config->IsActionDown(kActionMoveBackward)&& gGame->input->IsKeyDown(KC_LSHIFT) && !gGame->config->IsActionDown(kActionJump) && !player->zombie_dying_flag && player->is_boss && gLevel->game_type == RoomOption::kBossMode2 && player->boss2_move_energy > 100) player->SetBoost(true,2);
					if (gGame->config->IsActionDown(kActionMoveLeft)&& gGame->input->IsKeyDown(KC_LSHIFT) && !gGame->config->IsActionDown(kActionJump) && !player->zombie_dying_flag && player->is_boss && gLevel->game_type == RoomOption::kBossMode2 && player->boss2_move_energy > 100) player->SetBoost(true,3);
					if (gGame->config->IsActionDown(kActionMoveRight)&& gGame->input->IsKeyDown(KC_LSHIFT) && !gGame->config->IsActionDown(kActionJump) && !player->zombie_dying_flag && player->is_boss && gLevel->game_type == RoomOption::kBossMode2 && player->boss2_move_energy > 100) player->SetBoost(true,4);

					if(!gGame->input->IsKeyDown(KC_LSHIFT))
						player->SetBoost(false,0);
					//// press g
					if (gGame->config->IsActionPressed(kActionDropWeapon) && !(player->first_action_on || gGame->input->IsKeyDown(KC_E)))
					{
						if(player->weapon_id == BOMB_SLOT)
							player->DropBomb();
					}

					if(player->IsLockStateByType(kLSCrouch))
					{
						player->SetCrouch(false);
					}
					else if(player->zombie_dying_flag)
					{
						player->SetCrouch(true);
					}
					else
					{
						player->SetCrouch(gGame->config->IsActionDown(kActionCrouch));
					}
//#if DEBUG_CMD
//					player->SetWalk(gGame->config->IsActionDown(kActionWalk) && gLevel->enable_walk);
//#else
//					player->SetWalk(gGame->config->IsActionDown(kActionWalk));
//#endif

					if (gGame->config->IsActionDown(kActionSecondFire))
					{
						player->second_action_on = true;
					}
					else
					{
						player->second_action_on = false;
					}

					// shoot
					if (gGame->config->IsActionDown(kActionFire))
					{
						player->first_action_on = true;
					}
					else
						player->first_action_on = false;

					if(gGame->input->IsKeyDown(MC_RIGHT_BUTTON))
					{
						tempc_ptr(GunBase) currentGun = ptr_dynamic_cast<GunBase>(player->GetWeapon());

						if (currentGun)
							currentGun->SpecialAbilities(true);

					}
					if(gGame->input->IsKeyPressed(MC_RIGHT_BUTTON))
					{
						tempc_ptr(GunBase) currentGun = ptr_dynamic_cast<GunBase>(player->GetWeapon());

						if (currentGun)
							currentGun->SpecialAbilities(false);
					}
					if(gGame->input->IsKeyDown(MC_LEFT_BUTTON))
					{
						tempc_ptr(GunBase) currentGun = ptr_dynamic_cast<GunBase>(player->GetWeapon());
		
						if (currentGun)
						{
							bool issuccess = currentGun->ChargeAbilities();
							if(issuccess)
							{
								player->GetFirstPerson().StartCharge();
							}
						}	
					}
					if(gGame->input->IsKeyReleased(MC_LEFT_BUTTON))
					{
						tempc_ptr(Luncher) luncher = ptr_dynamic_cast<Luncher>(player->GetWeapon());

						if (luncher)
						{
							luncher->TryFire();
						}
					}
					
					if (gGame->config->IsActionDown(kActionCallMedic))
					{
						if (player->GetCurCharinfo()->career_id < 20)
							player->CallMedic();
						//gLevel->use_octee_deadzoon = !gLevel->use_octee_deadzoon;
					}

					if (gGame->config->IsActionPressed(kActionUseItem) && player->first_action_on == false)
					{
						if(gLevel->game_type == RoomOption::kBombMode)
							gLevel->BombMode_DefuseBomb();
						else if(gLevel->game_type == RoomOption::kZombieMode)
							gLevel->ZombieMode_SaveDying();
					}
					
					if (gGame->config->IsActionReleased(kActionUseItem) || player->first_action_on == true)
					{
						if(gLevel->game_type == RoomOption::kBombMode)
							gLevel->BombMode_CancelDefuseBomb();
						else if(gLevel->game_type == RoomOption::kZombieMode)
							gLevel->ZombieMode_CancelSaveDying();
					}



					//if (!player->IsDied() && 
					//	gGame->input->IsKeyPressed( KC_I ))
					//{
					//	gLevel->TestSummonGate();
					//}
					
					// reload
					if (gGame->config->IsActionDown(kActionReload))
						player->Reload();

					// select weapon
					//else 
					if(player && player->is_bag_open)
					{
						if(gGame->config->IsActionDown(kActionMenu1))
							player->current_bag_id = 1;
						if(gGame->config->IsActionDown(kActionMenu2))
							player->current_bag_id = 2;
						if(gGame->config->IsActionDown(kActionMenu3))
							player->current_bag_id = 3;
						if(gGame->config->IsActionDown(kActionMenu4))
							player->current_bag_id = 4;
						if(gGame->config->IsActionDown(kActionMenu5))
							player->current_bag_id = 5;

						int count = (int)player->GetCurCharinfo()->pack_set.Size();
						int is_in = false;

						for(int i = 0 ; i < count; i++)
						{
							if(player->GetCurCharinfo()->pack_set[i].id == player->current_bag_id)
							{
								is_in = true;
								break;
							}
						}
						if(is_in && player->current_bag_id != player->prev_bag_id && !player->is_ready_bag_close)
						{
							player->prev_bag_id = player->current_bag_id;
							player->bag_dialog_wait_time = 1.0f;

							if (gGame->channel_connection)
								gGame->channel_connection->ChangePack(player->current_bag_id);

							player->is_ready_bag_close = true;
						}
						else
						{
							player->current_bag_id = player->prev_bag_id;
						}
					}
					else if(player->radio_state == 0 && player->radio_id)
					{
						if (gGame->config->IsActionPressed(kActionMenu1))
							player->SelectWeapon(0);
						else if (gGame->config->IsActionPressed(kActionMenu2))
						{
							tempc_ptr(WeaponBase) weapon = player->GetWeaponById(1);
							if (weapon)
							{
								tempc_ptr(Grenade) grenade = ptr_dynamic_cast<Grenade>(weapon);
								if(grenade)
								{
									if(player->grenade_cd_time < 0)
									{
										player->SelectWeapon(1);
									}
								}
								else
								{
									player->SelectWeapon(1);
								}
							}
						}
						else if (gGame->config->IsActionPressed(kActionMenu3))
							player->SelectWeapon(2);
						else if (gGame->config->IsActionPressed(kActionMenu4))
						{
							tempc_ptr(WeaponBase) weapon = player->GetWeaponById(3);
							
							if (weapon)
							{
								tempc_ptr(Grenade) grenade = ptr_dynamic_cast<Grenade>(weapon);
								if(grenade)
								{
									if(player->grenade_cd_time < 0)
									{
										player->SelectWeapon(3);
									}
								}
								else
								{
									player->SelectWeapon(3);
								}
							}
						}
						else if(gGame->config->IsActionPressed(kActionMenu5))
							player->SelectWeapon(BOMB_SLOT);
						// change weapon
						if (gGame->config->IsActionPressed(kActionChangeWeapon))
						{
							player->ChangeWeapon();
						}

						if (gGame->config->IsActionPressed(kActionWeaponDown))
						{
							for (int i = player->weapon_id + 1; i < 7; ++i)
							{
								tempc_ptr(WeaponBase) weapon = player->GetWeaponById(i);

								if (weapon && weapon->CanActive())
								{
									if((weapon->GetWeaponType() == kWeaponTypeGrenade || weapon->GetWeaponType() == kWeaponTypeFlash || weapon->GetWeaponType() == kWeaponTypeSpecial)&&  player->grenade_cd_time > 0.f )
									{
										continue;
									}
									player->SelectWeapon(i);
									break;
								}
							}
						}

						if (gGame->config->IsActionPressed(kActionWeaponUp))
						{
							for (int i = player->weapon_id - 1; i >= 0; --i)
							{
								tempc_ptr(WeaponBase) weapon = player->GetWeaponById(i);

								if (weapon && weapon->CanActive())
								{
									if((weapon->GetWeaponType() == kWeaponTypeGrenade || weapon->GetWeaponType() == kWeaponTypeFlash || weapon->GetWeaponType() == kWeaponTypeSpecial)&&  player->grenade_cd_time > 0.f )
									{
										continue;
									}
									player->SelectWeapon(i);
									break;
								}
							}
						}
					}

					// spray
					if (gGame->config->IsActionPressed(kActionSpray))
					{
						// ray cast
						NxRay ray;
						ray.orig = (const NxVec3 &)player->GetCameraPosition();
						ray.dir = (const NxVec3 &)(Vector3(0, 0, -1) * player->GetCameraRotation());

						NxRaycastHit hit;
						uint group_id = 0;
						group_id |= 1 << PhysxSystem::kStatic;

						NxShape* shape = gPhysxScene->raycastClosestShape(ray, NX_STATIC_SHAPES, hit, group_id, 3);

						if (shape)
						{
							if (gGame->channel_connection)
								gGame->channel_connection->Spray((const Vector3 &)hit.worldImpact, (const Vector3 &)hit.worldNormal);
						}
					}

					//if(player && gGame->config->IsActionDown(kActionTeamYes) && player->team_request_waittime > 0.0f)
					//{
					//	if(gGame->lobby_connection)
					//	{
					//		gGame->lobby_connection->RequestTeamJoin(player->team_request_username,player->team_request_uid);

					//		player->team_request_waittime = 0.0f;
					//	}
					//}
					//if(player && gGame->config->IsActionDown(kActionTeamNo) && player->team_request_waittime > 0.0f)
					//{
					//	if(gGame->lobby_connection)
					//	{
					//		gGame->lobby_connection->RequestTeamRefuse(player->team_request_username,player->team_request_uid);

					//		player->team_request_waittime = 0.0f;
					//		player->team_refuse_time = 3.0f;
					//	}
					//}

					//if(player && gGame->config->IsActionPressed(kActionUIPack) && player->bag_flag && gLevel->use_self_weapon && player->infect_level == 0)
					//{
					//	if( (gLevel->game_type == RoomOption::kExplode && player->is_range_bag_flag == false) || gLevel->game_type != RoomOption::kExplode )
					//		player->is_bag_open = !player->is_bag_open;
					//}

					if (player && gGame->config->IsActionPressed(kActionShowName))
					{
						player->is_display_friend_name = ! player->is_display_friend_name;
					}
					if (gGame->config->IsActionDown(kActionSensitivityUp))
					{
						if (gLevel->sensitivity_timer <= 4.5f)
						{
							if (!gLevel->isGunSensitivity)
							{
								float value = gGame->config->GetSensitivity();

								value+=0.1f;
								gLevel->sensitivity_timer = 5.f;
								if(value > 20.f)
								{
									value = 20.f;
								}
								gGame->config->SetSensitivity(value);
							}
							else
							{
								float value = gGame->config->GetSensitivitySniper();

								value+=0.1f;
								gLevel->sensitivity_timer = 5.f;
								if(value > 20.f)
								{
									value = 20.f;
								}
								gGame->config->SetSensitivitySniper(value);
							}
						}
					}
					if (gGame->config->IsActionDown(kActionSensitivityDown))
					{
						if (gLevel->sensitivity_timer <= 4.5f)
						{
							if (!gLevel->isGunSensitivity)
							{
								float value = gGame->config->GetSensitivity();

								value-=0.1f;
								gLevel->sensitivity_timer = 5.f;
								if(value < 1.f)
								{
									value = 1.f;
								}
								gGame->config->SetSensitivity(value);
							}
							else
							{
								float value = gGame->config->GetSensitivitySniper();

								value-=0.1f;
								gLevel->sensitivity_timer = 5.f;
								if(value < 1.f)
								{
									value = 1.f;
								}
								gGame->config->SetSensitivitySniper(value);
							}
						}
					}
//
#if 0
					// toolsbox for fireball
					if (gGame->level->GetPlayer()->toolsbox && gGame->level->GetPlayer()->toolsbox->isDraw)
					{

						if (!gGame->level->GetPlayer()->toolsbox->isRot && gGame->input->IsKeyDown(MC_RIGHT_BUTTON))
						{
							gGame->level->GetPlayer()->toolsbox->isRot = true;
						}
						else if (!gGame->level->GetPlayer()->toolsbox->isRot && gGame->input->IsKeyDown(MC_LEFT_BUTTON))
						{
							gGame->level->GetPlayer()->toolsbox->isDraw = false;
							gGame->level->GetPlayer()->toolsbox->isRot = true;
							Quaternion allrot = Quaternion(Vector3(0,1,0),180*DEG2RAD) * gGame->level->GetPlayer()->toolsbox->finalrotation * gGame->level->GetPlayer()->toolsbox->GetRotation();
							//gLevel->pickup_manager->AddMachine(machine_id++, kWeaponTypeAutoMachineGun, gGame->level->toolsbox->position, allrot, gLevel->GetPlayer());
							//gGame->channel_connection->AddAutoMachineGun(gGame->level->toolsbox->position, allrot);
						}
					}
					if (gGame->level->GetPlayer()->toolsbox && !gGame->level->GetPlayer()->toolsbox->isDraw && gGame->input->IsKeyDown(KC_8))
					{
						gGame->level->GetPlayer()->toolsbox->InitToolsBox();
						gGame->level->GetPlayer()->toolsbox->isDraw = true;
					}
#endif


#if DEBUG_INFO
					// suicide
					if (gGame->config->IsActionPressed(kActionSuicide))
					{
						if (gGame->channel_connection)
							gGame->channel_connection->Suicide();
					}
#endif				

					if(gLevel->game_type != RoomOption::kZombieMode || player->GetTeam() != 1)
						player->RadioAction();
				}
				else
				{

					player->SetMove(0, 0);
					player->first_action_on = false;
					player->MoveCamera(-control_rotate.x, -control_rotate.y);
				}
				
			}
		}
		//else if(gGame->camera->control_mode == Camera::kRojectControl)
		//{
		//	if(player)
		//	{
		//		if(gGame->input->IsKeyUp(MC_RIGHT_BUTTON))
		//		{
		//			tempc_ptr(GunBase) currentGun = ptr_dynamic_cast<GunBase>(player->GetWeapon());

		//			if (currentGun)
		//				currentGun->SpecialAbilities(false);
		//		}
		//		else
		//		{
		//			tempc_ptr(Luncher) luncher = ptr_dynamic_cast<Luncher>(player->GetWeapon());
		//			if(luncher)
		//			{
		//				if(!currentAmmo)
		//				{
		//					luncher->SpecialAbilities(false);
		//				}
		//				else
		//				{
		//					if(currentAmmo->is_dead)
		//					{
		//						currentAmmo = NullPtr;
		//						luncher->SpecialAbilities(false);
		//					}
		//					else if(gGame->input->IsKeyPressed(MC_LEFT_BUTTON))
		//					{
		//						currentAmmo->is_dead = true;
		//					}
		//					else
		//					{
		//						Vector3 dir;
		//						currentAmmo->GetVelocity(dir);
		//						dir = dir.Normalize();
		//						gGame->camera->position = currentAmmo->GetPosition() - dir * gGame->camera->distance;
		//						float upangle = (control_move.x - control_rotate.x * 10) * PI * 0.03f;
		//						float rightangle = (control_move.z - control_rotate.y * 10) * PI * 0.03f;
		//						currentAmmo->AddForceFromUpRight(upangle,rightangle);
		//					}
		//				}
		//			}
		//		}
		//	}
		//}
	}

	/// update
	void PlayerManager::Update(float frame_time)
	{
		if (state != kReady)
			return;

		if (!player)
			return;

		player->UpdateMoveInfo();
		player->Update(frame_time);

		gGame->camera->UpdateAspect(gGame->screen->GetSize());

		tempc_ptr(Character) view_character = gLevel->GetCharacter(viewer_id);

		if(view_character)
		{
			if(view_character->zombie_dying_flag)
			{
				const float time_interval = 0.5f;
				
				gGame->camera->direction_rotation = Min(view_character->zombie_dying_timer / time_interval, 1.0f) * 17.f;
			}
			else
			{
				gGame->camera->direction_rotation = 0.f;
			}
		}

		gGame->camera->FrameUpdate(view_character, frame_time);

		player->UpdateOccludee();

		if(gGame->channel_connection->GetState() == ChannelConnection::kInReplay)
		{
			player->UpdateSyncData(frame_time);
			player->TimeStepUpdate(frame_time);
		}
	}

	void PlayerManager::UpdateViewerCameraMode(const tempc_ptr(Character)& view_character)
	{
		if(viewer_state < kFree)
		{
			if (viewer_state == kThird)
				view_character->camera_distance = 4.f;
			else
				view_character->camera_distance =0.f;
		}
		else
		{
			if(player && player->GetTeam() == 2)
			{
				SetCameraMode(Camera::kFreeMove);
			}
			else
			{
				viewer_state = kFirst;
				view_character->camera_distance =0.f;
			}
			
		}
	}

	/// timestepupdate
	void PlayerManager::TimeStepUpdate(float frame_time)
	{
		if (state != kReady)
			return;

		if (!player || !gLevel)
			return;

		Character::ViewMode mode = Character::kFirstPerson;
		if (player->camera_distance >= 0.5f || player->IsDied())
			mode = Character::kThirdPerson;

		if (gGame->camera->control_mode != Camera::kCharacterControl)
			mode = Character::kThirdPerson;

		player->SetViewMode(mode);

		player->TimeStepUpdate(frame_time);

		SetMouseSensitivity(player->mouse_sensitivity);

		if (gGame->channel_connection)
			gGame->channel_connection->ProjectedAmmoUpdate(gLevel->character_ammoset.Get(player->uid, NullPtr));

		// died
		if (player->IsDied())
		{
		}
	}

	/// on render
	void PlayerManager::OnRender(float frame_time)
	{
		if (state != kReady)
			return;

		if (!player)
			return;

		player->OnRender(frame_time);
	}

	/// initialize
	bool PlayerManager::Initialize()
	{
		if (!level)
			return false;

		player = ptr_new Character;
		player->died = true;
		player->ready = false;

		player->SetActionController(ptr_new PlayerAction);
		player->SetMoveController(ptr_new SimulateMove);

		if (player->effect_collider == NULL)
		{
			player->effect_collider = PhysxSystem::CreateBox(player->GetPosition(), Vector3(2.f,2.f,1.5f), PhysxSystem::kGroupSoundEffect);
			player->effect_collider->userData = player;
			player->effect_collider->setLinearVelocity(NxVec3(0.f, 0.f, 0.f));
			player->effect_collider->setAngularVelocity(NxVec3(0.f, 0.f, 0.f));
			player->effect_collider->raiseBodyFlag(NX_BF_KINEMATIC);
		}
		
		//if (!player->toolsbox)
		//{
		//	player->toolsbox = ptr_new ToolsBox();
		//	player->toolsbox->AddMesh("sphere/sphere_bottom.mesh");
		//	player->toolsbox->AddMesh("sphere/sphere.mesh");
		//	player->toolsbox->AddMesh("boxline/boxline.mesh");
		//}

		///// temp for mesh load
		state = kReady;
		mouseSensitivityBase = 0.002f;
		mouseSensitivityZoomFactor = 1.0f;
		mouseSensitivity = mouseSensitivityZoomFactor * mouseSensitivityBase;

		return true;
	}

	/// terminate
	void PlayerManager::Terminate()
	{
		player = NullPtr;
		state = kNone;
		currentAmmo = NullPtr;
	}

	///set sensitivity
	void PlayerManager::SetMouseSensitivity(float fZoomFactor)
	{
		mouseSensitivityZoomFactor = fZoomFactor;
		mouseSensitivity = mouseSensitivityZoomFactor * mouseSensitivityBase;
	}
	
	void PlayerManager::SetMouseSensitivityBase(float fBase)
	{
		mouseSensitivityBase = fBase;
		mouseSensitivity = mouseSensitivityZoomFactor * mouseSensitivityBase;
	}

	/// set camera mode
	void PlayerManager::SetCameraMode(Camera::ControlMode mode)
	{
		if (gGame->camera->control_mode == Camera::kViewMode)
		{
			tempc_ptr(Character) view_character = gLevel->GetCharacter(viewer_id);
			if (view_character)
			{
				view_character->SetViewMode(Character::kThirdPerson);
				view_character->camera_rotation_offset = Quaternion::kIdentity;
			}
			if (gGame->render && gGame->render->render_pipeline)
			{
				gGame->render->render_pipeline->m_bUseSavedScreen = false;
			}
		}

		if (gGame->camera->control_mode != mode)
		{
			if (gLevel->GetViewer())
			{
				for(int i = 0; i < 7; ++i)
				{
					tempc_ptr(GunBase) gun = ptr_dynamic_cast<GunBase>(gLevel->GetViewer()->GetWeaponById(i));
					if (gun && gun->GetWeaponType() == kWeaponTypeMiniMachineGun)
					{
						tempc_ptr(MiniMachineGun) mini = ptr_dynamic_cast<MiniMachineGun>(gun);
						if (mini)
						{
							if (mini->mini_gun_audio_spin_fire)
								mini->mini_gun_audio_spin_fire->stop();
							if (mini->mini_gun_audio_spin_fire_3d)
								mini->mini_gun_audio_spin_fire_3d->stop();
							break;
						}
					}
				}
			}
			gGame->camera->control_mode = mode;
		}

		ViewModeToNext();
	}

	/// view mode to next
	void PlayerManager::ViewModeToNext(bool reverse)
	{
		uint temp_viewer_id = 0;
		if (gGame->camera->control_mode == Camera::kViewMode)
		{
			byte team_mask = 1<<0 | 1<<1;
			if (player->GetTeam() < 2)
			{
				switch (gLevel->game_type)
				{
				case RoomOption::kHoldPoint:
				case RoomOption::kPushVehicle:
				case RoomOption::kNovice:
				case RoomOption::kTeam:
				case RoomOption::kKnifeMode:
				case RoomOption::kTeamDeathMatch:
				case RoomOption::kBombMode:
				case RoomOption::kBoss:
				case RoomOption::kStreetBoyMode:
				case RoomOption::kZombieMode:
				case RoomOption::kBossPVE:
				case RoomOption:: kCommonZombieMode:
				case RoomOption:: kBossMode2:
				case RoomOption:: kItemMode:
				case RoomOption::kEditMode:
				case RoomOption::kTDMode:
				case RoomOption::KMoonMode:
				case RoomOption::kAdvenceMode:
				case RoomOption::kSurvivalMode:
			
					{
						if (player)
							team_mask = 1<<player->GetTeam();
					}
					break;
				}
			}
			temp_viewer_id = viewer_id;
			tempc_ptr(Character) view_character = gLevel->GetCharacterNext(viewer_id, team_mask, reverse);
			if (view_character)
			{
				viewer_id = view_character->uid;
				view_character->SetViewMode(view_mode);
				view_character->camera_distance = view_distance;
				view_character->camera_rotation_offset = Quaternion::kIdentity;
			}
		}	
		if(viewer_id != temp_viewer_id)
		{
			tempc_ptr(Character) character = gLevel->GetViewer();
			if (character)
			{
				character->keep_Shoot = false;
				tempc_ptr(WeaponBase) weapon = character->GetWeapon();
				if (weapon && weapon->GetWeaponType() == kWeaponTypeCureGun)
				{		
					tempc_ptr(CureGun) gun = ptr_dynamic_cast<CureGun>(weapon);
					if (gun->my_audio_event && gLevel->GetViewer() != gLevel->GetPlayer())
						gun->my_audio_event->stop();
				}
			}
		}
	}
}

namespace Client
{
	/// on create
	void AnimationManager::OnCreate()
	{
		Object::OnCreate();
		LoadSkeleton();
	}

	/// on destroy
	void AnimationManager::OnDestroy()
	{
		skeleton_set.Clear();
		animation_set.Clear();
		Object::OnDestroy();
	}

	/// update
	void AnimationManager::Update(float frame_time)
	{
	}

	/// load
	bool AnimationManager::Load()
	{
		return true;
	}

	/// unload
	void AnimationManager::Unload()
	{
		animation_set.Clear();
		
	}

	/// load skeleton
	bool AnimationManager::LoadSkeleton()
	{
		CStrBuf<MAX_PATH> path("/skeleton");
		if (Path::IsDirectory(path))
		{
			Lua::LuaState * LuaState = Lua::LuaState::NewState();
			PdeItPath it;
			it.Reset(path, false);

			while(it.MoveNext())
			{
				if (it.IsDirectory())
					continue;

				CStrBuf<MAX_PATH> str(path.buff());
				str.contractf("/%s", it.Name().buff());
				str.remove_back(".cache");

				sharedc_ptr(Skeleton) skeleton = RESOURCE_LOAD(str, false, Skeleton);
				if (skeleton)
					skeleton_set.Add(str, skeleton);
			}
			LuaState->Close();
		}
		return true;
	}

	/// add animationset res
	void AnimationManager::AddAnimationSetRes(const Identifier & key, by_ptr(AnimationSetRes) res)
	{
		if (res)
			animation_set.Set(key, res);
	}
}

namespace Client
{

	static bool lua_LoadPhysxMesh(const Core::Identifier& path, by_ptr(Mesh) mesh)
	{
		bool ret = false;

		Lua::LuaState *L = Lua::LuaState::NewState();

		int top = L->GetTop();
		L->NewTable();

		if (mesh)
			mesh->res_path = path;

		if (L->LoadFile(path, true) == 0)
		{
			L->PushValue(top + 1);
			L->SetFenv(-2);

			if (L->DoCall(0, 0))
			{
				const char *msg = L->ToString(-1);
				if (msg) Core::Console.WriteLine(msg);
				L->Pop(1);
			}
			else
			{
				L->GetField(top + 1, "Joints");
				Core::Array<Core::Identifier> joints;
				lua_LoadArray(L, -1, joints);
				L->Pop(1);

				L->GetField(top + 1, "Mesh");

				L->GetField(-1, "Points");
				Core::Array<float> points;
				lua_LoadArray(L, -1, points);
				L->Pop(1);

				L->GetField(-1, "FaceVertexCount");
				Core::Array<int> face_vertex_count;
				lua_LoadArray(L, -1, face_vertex_count);
				L->Pop(1);

				L->GetField(-1, "FaceVertices");
				Core::Array<int> face_vertices;
				lua_LoadArray(L, -1, face_vertices);
				L->Pop(1);

				mesh->Create(points.Size() / 3, face_vertex_count.Size(), (const Core::Vector3*)points.GetData(), face_vertex_count.GetData(), face_vertices.GetData());

				L->GetField(-1, "FaceTriangleCount");
				Core::Array<int> face_triangle_count;
				lua_LoadArray(L, -1, face_triangle_count);
				L->Pop(1);

				L->GetField(-1, "FaceTriangles");
				Core::Array<int> face_triangles;
				lua_LoadArray(L, -1, face_triangles);
				L->Pop(1);

				mesh->Triangulate(face_triangle_count.GetData(), face_triangles.GetData());

				L->GetField(-1, "Normals");
				Core::Array<float> normals;
				lua_LoadArray(L, -1, normals);
				L->Pop(1);

				L->GetField(-1, "FaceVertexNormals");
				Core::Array<int> face_vertex_normals;
				lua_LoadArray(L, -1, face_vertex_normals);
				L->Pop(1);

				mesh->SetNormals(normals.Size() / 3, (const Core::Vector3*)normals.GetData(), face_vertex_normals.GetData());

				L->GetField(-1, "BlendIndices");
				Core::Array<int> indices;
				lua_LoadArray(L, -1, indices);
				L->Pop(1);

				L->GetField(-1, "BlendWeights");
				Core::Array<float> weights;
				lua_LoadArray(L, -1, weights);
				L->Pop(1);

				L->GetField(-1, "BlendCounts");
				Core::Array<int> counts;
				lua_LoadArray(L, -1, counts);
				L->Pop(1);

				mesh->CreateSkinCluster(joints.Size(), joints.GetData(), NULL, NULL, NULL, counts.Size(), counts.GetData(), indices.GetData(), weights.GetData());

				L->GetField(-1, "UVSets");
				int uvset_count = L->ObjLen(-1);
				for (int i = 0; i < uvset_count; ++ i)
				{
					L->PushInteger(i + 1);
					L->GetTable(-2);

					L->GetField(-1, "Name");
					const char* name = L->ToString(-1);
					L->Pop(1);

					L->GetField(-1, "Tangents");
					Core::Array<float> tangents;
					lua_LoadArray(L, -1, tangents);
					L->Pop(1);

					L->GetField(-1, "Binormals");
					Core::Array<float> binormals;
					lua_LoadArray(L, -1, binormals);
					L->Pop(1);

					L->GetField(-1, "UVs");
					Core::Array<float> uvs;
					lua_LoadArray(L, -1, uvs);
					L->Pop(1);

					L->GetField(-1, "FaceVertexUVIndices");
					Core::Array<int> face_vertex_uvs;
					lua_LoadArray(L, -1, face_vertex_uvs);
					L->Pop(1);

					L->GetField(-1, "FaceVertexTangentIndices");
					Core::Array<int> face_tb_index;
					lua_LoadArray(L, -1, face_tb_index);
					L->Pop(1);

					if (tangents.Size() > 0 && binormals.Size() && i == 0)
						mesh->CreateUVSet(name, uvs.Size() / 2, tangents.Size() / 3, face_tb_index.GetData(), (const Core::Vector2*)uvs.GetData(), (const Core::Vector3*)tangents.GetData(), (const Core::Vector3*)binormals.GetData(), face_vertex_uvs.GetData(), face_vertex_uvs.Size());
					else
						mesh->CreateUVSet(name, uvs.Size() / 2, 0, 0, (const Core::Vector2*)uvs.GetData(), NULL, NULL, face_vertex_uvs.GetData(), face_vertex_uvs.Size());
					L->Pop(1);
				}
				L->Pop(1);

				L->GetField(-1, "Colors");
				Core::Array<float> colors;
				lua_LoadArray(L, -1, colors);
				L->Pop(1);

				L->GetField(-1, "FaceVertexColors");
				Core::Array<int> face_vertex_colors;
				lua_LoadArray(L, -1, face_vertex_colors);
				L->Pop(1);

				mesh->CreateColorSet("default", colors.Size() / 4, (const Core::Color4*)colors.GetData(), face_vertex_colors.GetData(), face_vertex_colors.Size());

				L->GetField(-1, "FaceMaterials");
				Core::Array<int> face_materials;
				lua_LoadArray(L, -1, face_materials);
				L->Pop(1);

				mesh->CreateShadingGroup("material", 0, NULL, face_materials.GetData());

				L->Pop(1);

				L->GetField(top + 1, "Materials");
				int material_count = L->ObjLen(-1);

				for (int p = 0; p < material_count; ++ p)
				{
					L->PushInteger(p + 1);
					L->GetTable(-2);

					L->GetField(-1, "PhysicsMaterial");
					int physx_material = L->ToInteger(-1);
					L->Pop(1);
					mesh->physx_material.PushBack(physx_material);

					L->GetField(-1, "CollisionMode");
					int collision_mode = 0;
					if (L->IsNil(-1))
						collision_mode = 1;
					else
						collision_mode = L->ToInteger(-1);

					L->Pop(1);
					mesh->collision_mode.PushBack(collision_mode);

					L->Pop(1);
				}

				L->Pop(1);
				ret = true;
			}
		}
		else
		{
			const char *msg = L->ToString(-1);
			if (msg) Core::Console.WriteLine(msg);
			L->Pop(1);
		}
		L->SetTop(top);
		L->Close();
		return ret;
	}

	/// constructor
	PhysxResource::PhysxResource()
	{
	}
	
	/// get version
	short PhysxResource::GetVersion()
	{
		return 5;
	}

	/// save data
	bool PhysxResource::SaveData(Stream & stream)
	{
#ifndef MASTER
		Resource::SaveData(stream);

		int size = actor_set.Size();
		stream.Write(&size, sizeof(int));

		for (int i = 0; i < size; ++i)
		{
			if (actor_set[i] && actor_set[i]->buffer)
			{
				stream.Write(&actor_set[i]->buffer->currentSize, sizeof(NxU32));
				stream.Write(actor_set[i]->buffer->data, sizeof(NxU8) * actor_set[i]->buffer->currentSize);
				stream.Write(&actor_set[i]->collision_mode, sizeof(int));

				uint attr_buffer_size = actor_set[i]->attr_buffer.Size();
				stream.Write(&attr_buffer_size, sizeof(int));
				stream.Write(actor_set[i]->attr_buffer.GetData(), sizeof(TriangleAttribute) * attr_buffer_size);
			}
			else
			{
				int data = 0;
				stream.Write(&data, sizeof(int));
				stream.Write(&data, sizeof(int));
				stream.Write(&data, sizeof(int));
			}
		}

		return true;
#else
		return false;
#endif
	}

	/// load data
	sharedc_ptr(Object) PhysxResource::LoadData(Stream & stream)
	{
		if (!Resource::LoadData(stream))
			return NullPtr;

		int set_size = 0;
		stream.Read(&set_size, sizeof(int));

		sharedc_ptr(PhysxResource) res = ptr_new PhysxResource;
		for (int i = 0; i < set_size; ++i)
		{
			uint size = 0;
			stream.Read(&size, sizeof(uint));
			Buffer* buffer = Buffer::Create(sizeof(NxU8) * size);
			stream.Read(buffer->GetBufferPointer(), buffer->GetBufferSize());

			sharedc_ptr(PhysxActor) actor = ptr_new PhysxActor;
			sharedc_ptr(MemoryWriteBuffer) data = ptr_new MemoryWriteBuffer;
			data->storeBuffer(buffer->GetBufferPointer(), size);
			buffer->Release();
			buffer = NULL;
			actor->buffer = data;
			stream.Read(&actor->collision_mode, sizeof(int));
			
			uint attr_size;
			stream.Read(&attr_size, sizeof(attr_size));

			if (attr_size > 0)
			{
				actor->attr_buffer.Resize(attr_size);
				stream.Read(actor->attr_buffer.GetData(), sizeof(TriangleAttribute) * attr_size);
			}

			res->actor_set.PushBack(actor);
		}

		return res;
	}
	/// load data
	sharedc_ptr(Object) PhysxResource::BuildData()
	{
#ifndef MASTER
		sharedc_ptr(Mesh) mesh = ptr_new Mesh;

		if (!lua_LoadPhysxMesh(GetPath(), mesh))
			return NullPtr;

		int uvset_id = 1;
		uint size = mesh->NumVertices();
		Vector3* point_data = mesh->GetPoints();
		Vector2* uvset_data = mesh->GetUVs(uvset_id);
		const int* meterialsIndex = mesh->GetShadingGroupData(0);

		Core::Array<int> triangles[6];
		Core::Array<int> materials[6];
		Core::Array<int> faceVertices;
		Core::Array<int> faceVertexUVs;
		Core::Array<int> uvs[6];

		int triangles_num[6];
		memset(triangles_num, 0, sizeof(int) * 6);

		for (uint i = 0; i < size; ++i)
		{
			point_data[i].x /= 100.f;
			point_data[i].y /= 100.f;
			point_data[i].z /= 100.f;
		}

		for (int i = 0; i < mesh->NumFaces(); i++)
		{
			int collision_mode = mesh->GetCollisionMode(*(meterialsIndex + i));
			int physx_meterial = mesh->GetPhysxMaterial(*(meterialsIndex + i));

			if (!mesh->GetFaceVertices(i, faceVertices))
				return NullPtr;

			if (!mesh->GetFaceVertexUVs(i, uvset_id, faceVertexUVs))
				uvset_data = NULL;

			switch (collision_mode)
			{
			case 1:
			case 2:
			case 3:
			case 4:
			case 5:
			case 6:
				for (int j = 0; j < mesh->NumFaceTriangles(i); j++)
				{
					int faceTriangle[3];
					if (!mesh->GetFaceTriangle(i, j, faceTriangle))
						return NullPtr;

					int index = collision_mode - 1;

					triangles[index].PushBack(faceVertices[faceTriangle[0]]);
					triangles[index].PushBack(faceVertices[faceTriangle[1]]);
					triangles[index].PushBack(faceVertices[faceTriangle[2]]);

					if (uvset_data)
					{
						uvs[index].PushBack(faceVertexUVs[faceTriangle[0]]);
						uvs[index].PushBack(faceVertexUVs[faceTriangle[1]]);
						uvs[index].PushBack(faceVertexUVs[faceTriangle[2]]);
					}

					materials[index].PushBack(physx_meterial);

					triangles_num[index]++;
				}
				break;
			}
		}

		sharedc_ptr(PhysxResource) res = ptr_new PhysxResource;

		for (int n = 0; n < 1; n++)
		{
			for (int i = 0; i < 6; ++i)
			{
				if (triangles_num[i] > 0)
				{
					// Build physical model
					NxTriangleMeshDesc meshDesc;
					meshDesc.numVertices				= mesh->NumVertices();
					meshDesc.numTriangles				= triangles_num[i];
					meshDesc.materialIndexStride		= sizeof(int);
					meshDesc.pointStrideBytes			= sizeof(Vector3);
					meshDesc.triangleStrideBytes		= 3 * sizeof(int);
					meshDesc.points						= point_data;
					meshDesc.triangles					= triangles[i].GetData();
					meshDesc.materialIndices			= materials[i].GetData();
					if (n == 0)
						meshDesc.flags					= 0;
					else
						meshDesc.flags					= NX_MF_FLIPNORMALS;

					sharedc_ptr(MemoryWriteBuffer) data = ptr_new MemoryWriteBuffer;
					bool status = NxCookTriangleMesh(meshDesc, *data);

					if (!status)
					{
						Core::LogSystem.WriteLinef("Physx error : Unable to cook a triangle mesh.");
						return NullPtr;
					}

					sharedc_ptr(PhysxActor) actor = ptr_new PhysxActor;
					actor->collision_mode = i + 1;
					actor->buffer = data;
				
					if (uvset_data)
					{
						MemoryReadBuffer read_buffer(actor->buffer->data);
						NxTriangleMesh & triangle_mesh = *PhysxSystem::CreateTriangleMesh(read_buffer);

						byte * remap_data = (byte*)triangle_mesh.getBase(0, NX_ARRAY_TRIANGLES_REMAP);
						uint   remap_stride = triangle_mesh.getStride(0, NX_ARRAY_TRIANGLES_REMAP);
						uint   remap_count = triangle_mesh.getCount(0, NX_ARRAY_TRIANGLES_REMAP);

						actor->attr_buffer.Resize(remap_count);

						switch (triangle_mesh.getFormat(0, NX_ARRAY_TRIANGLES_REMAP))
						{
						case NX_FORMAT_SHORT:
							for (uint j = 0; j < remap_count; j ++)
							{
								uint id = j;

								if (remap_data)
									id = *reinterpret_cast<ushort*>(remap_data + remap_stride * j);

								Vector2 & uv0 = uvset_data[uvs[i][id * 3 + 0]];
								Vector2 & uv1 = uvset_data[uvs[i][id * 3 + 1]];
								Vector2 & uv2 = uvset_data[uvs[i][id * 3 + 2]];

								D3DXVECTOR2_16F * uv = actor->attr_buffer[j].uv1;
								uv[0] = D3DXVECTOR2_16F(uv0.x, 1 - uv0.y);
								uv[1] = D3DXVECTOR2_16F(uv1.x, 1 - uv1.y);
								uv[2] = D3DXVECTOR2_16F(uv2.x, 1 - uv2.y);

							}
							break;

						case NX_FORMAT_INT:
							for (uint j = 0; j < remap_count; j ++)
							{
								uint id = j;

								if (remap_data)
									id = *reinterpret_cast<uint*>(remap_data + remap_stride * j);

								Vector2 & uv0 = uvset_data[uvs[i][id * 3 + 0]];
								Vector2 & uv1 = uvset_data[uvs[i][id * 3 + 1]];
								Vector2 & uv2 = uvset_data[uvs[i][id * 3 + 2]];

								D3DXVECTOR2_16F * uv = actor->attr_buffer[j].uv1;
								uv[0] = D3DXVECTOR2_16F(uv0.x, 1 - uv0.y);
								uv[1] = D3DXVECTOR2_16F(uv1.x, 1 - uv1.y);
								uv[2] = D3DXVECTOR2_16F(uv2.x, 1 - uv2.y);
							}
							break;
						}

						PhysxSystem::ReleaseTriangleMesh(triangle_mesh);
					}

					res->actor_set.PushBack(actor);
				}
			}
		}
		AddDependenceFilePath(GetPath());
		return res;
#else
		return NullPtr;
#endif
	}

	/// unload data
	void PhysxResource::UnloadData()
	{
		for (uint i = 0; i < actor_set.Size(); ++i)
		{
			if (actor_set[i])
			{
				if (actor_set[i]->actor)
				{
					PhysxSystem::ReleaseActor(*actor_set[i]->actor);
					actor_set[i]->actor = NULL;
					actor_set[i]->collision_mode = 0;
				}

				actor_set[i]->buffer = NullPtr;
			}
		}
		actor_set.Clear();
	}

	/// on load data
	bool PhysxResource::OnLoadData(by_ptr(Object) obj)
	{
		tempc_ptr(PhysxResource) data = ptr_static_cast<PhysxResource>(obj);
		if (data)
		{
			for (uint i = 0; i < data->actor_set.Size(); ++i)
			{
				if (data->actor_set[i] && data->actor_set[i]->buffer && data->actor_set[i]->buffer->data)
				{
					sharedc_ptr(PhysxActor) actor = ptr_new PhysxActor;

					MemoryReadBuffer read_buffer(data->actor_set[i]->buffer->data);
					actor->collision_mode = data->actor_set[i]->collision_mode;
					actor->actor = PhysxSystem::BuildActor(&read_buffer, actor->collision_mode);
					actor->actor->userData = actor.GetPtr();
					actor->buffer = data->actor_set[i]->buffer;
					actor->attr_buffer.Swap(data->actor_set[i]->attr_buffer);

					actor_set.PushBack(actor);
				}
			}
			return true;
		}
		return false;
	}
}

namespace Client
{
	/// constructor
	PhysxManager::PhysxManager(by_ptr(Level) l)
		: level(l)
	{
	}
	/// update
	void PhysxManager::Update(float frame_time)
	{
	}

	/// load
	bool PhysxManager::Load(const Identifier & name)
	{
		//sharedc_ptr(PhysxResource) res = RESOURCE_LOAD_BYTYPE(name, PHYSX_TYPE, true, PhysxResource);
		sharedc_ptr(PhysxResource) res = RESOURCE_LOAD_BYTYPE(name, PHYSX_TYPE, false, PhysxResource);
		if (res)
		{
			res_set.PushBack(res);
		}

		return true;
	}

	/// unload
	void PhysxManager::Unload()
	{
		// TODO: verify if we can leave this unhandled.
		for (uint i = 0; i < res_set.Size(); ++i)
		{
			if (res_set[i])
				res_set[i]->Unload();
		}
		res_set.Clear();
	}
}

namespace Client
{
	tempc_ptr(PickUpManager::PickUpObject) PickUpManager::PickUpObject::FromNxActor(NxActor & actor)
	{
		Object * obj = (Object*)actor.userData;

		if (obj)
		{
			return ptr_dynamic_cast<PickUpManager::PickUpObject>(obj);
		}

		return NullPtr;
	}

	/// constructor
	PickUpManager::PickUpManager(by_ptr(Level) l)
		: pickup_delay(0.2f)
		, pickup_delay_timer(0)
		, supply_rot(0.0f)
	{
	}

	///Initialize,smshihouchansheng?
	void PickUpManager::Initialize()
	{
		pickup_delay_timer = 0;
	}

	void PickUpManager::Terminate()
	{
		for(int i = 0; i < (int)pick_up_set.Size(); i++)
		{
			if (pick_up_set[i])
			{
				if (pick_up_set[i]->collider)
				{
					pick_up_set[i]->collider->userData = (void *)NULL;
					PhysxSystem::ReleaseActor(*pick_up_set[i]->collider);
					pick_up_set[i]->collider = NULL;
				}

				if (pick_up_set[i]->trigger)
				{
					pick_up_set[i]->trigger->userData = (void *)NULL;
					PhysxSystem::ReleaseActor(*pick_up_set[i]->trigger);
					pick_up_set[i]->trigger	= NULL;
				}
				
				if (pick_up_set[i]->particle)
				{
					if(gLevel)
					{
						gLevel->RemoveParticle(pick_up_set[i]->particle);
					}
				}
			}
		}

		pick_up_set.Clear();
		pickup_delay_timer = 0;
	}

	/// update
	void PickUpManager::Update(float frame_time)
	{
		supply_rot += Core::HALFPI * frame_time * 0.4f;
		if(supply_rot >= Core::TWOPI)
			supply_rot -= Core::TWOPI;

		for(int i = pick_up_set.Size() - 1; i >= 0; --i)
		{
			if (pick_up_set[i])
			{
				// remove unused pick up
				if (pick_up_set[i]->removed)
				{
					if (pick_up_set[i]->collider)
					{
						PhysxSystem::ReleaseActor(*pick_up_set[i]->collider);
						pick_up_set[i]->collider		= NULL;
					}

					if (pick_up_set[i]->trigger)
					{
						PhysxSystem::ReleaseActor(*pick_up_set[i]->trigger);
						pick_up_set[i]->trigger			= NULL;
					}
					if (pick_up_set[i]->particle)
					{
						if(gLevel)
						{
							gLevel->RemoveParticle(pick_up_set[i]->particle);
						}
					}
					pick_up_set.RemoveAt(i);

					for(U32 j = i; j < pick_up_set.Size(); j++)
					{
// 						if (pick_up_set[j]->collider)
// 							pick_up_set[j]->collider->userData = (void *)j;
// 
// 						if (pick_up_set[j]->trigger)
// 							pick_up_set[j]->trigger->userData = (void *)j;
						if (pick_up_set[j]->collider)
							pick_up_set[j]->collider->userData = (void*)pick_up_set[j];

						if (pick_up_set[j]->trigger)
							pick_up_set[j]->trigger->userData = (void*)pick_up_set[j];
					}

					continue;
				}

				pick_up_set[i]->create_Trigger_Time -= frame_time;

				if (pick_up_set[i]->collider)
				{
					NxVec3 colliderPos = pick_up_set[i]->collider->getGlobalPosition();
					NxQuat colliderRot = pick_up_set[i]->collider->getGlobalOrientationQuat();
					if (pick_up_set[i]->particle)
					{
						pick_up_set[i]->particle->SetPosition(( Vector3&)colliderPos);
						//pick_up_set[i]->particle->SetRotation(( Quaternion&)colliderRot);
					}
					if(pick_up_set[i]->trigger)
					{
						pick_up_set[i]->trigger->setGlobalPosition(colliderPos + (const NxVec3 &)(Vector3(0.f, 0.5f, 0.f) * (const Quaternion&)colliderRot));
						pick_up_set[i]->trigger->setGlobalOrientationQuat(colliderRot);
					}
					else if(pick_up_set[i]->create_Trigger_Time < 0.f)
					{
						tempc_ptr(PickUpManager::PickUpObject) pPickUp = PickUpManager::PickUpObject::FromNxActor(*pick_up_set[i]->collider);
						if(pPickUp)
							CreateTrigger(pPickUp, (const Vector3&)colliderPos + Vector3(0.f, 0.5f, 0.f) * (const Quaternion&)colliderRot);
					}

					if (pick_up_set[i]->type == kPickUpWeapon)
					{
						tempc_ptr(WeaponObject) weapon = ptr_static_cast<WeaponObject>(pick_up_set[i]);

						if (weapon)
						{
							weapon->weapon->SetPosition((const Vector3&)colliderPos + Vector3(0.f, 0.05f, 0.f) * (const Quaternion&)colliderRot);

							if (weapon->weapon->GetWeaponType() != kWeaponTypeBomb)
								weapon->weapon->SetRotation((const Quaternion&)colliderRot * Quaternion(Vector3(0.f, 0.f, 1.f) * (const Quaternion&)colliderRot, HALFPI) * Quaternion(Vector3(0.f, -1.f, 0.f) * (const Quaternion&)colliderRot, HALFPI));
						}
					}

					if (pick_up_set[i]->type == kPickUpMachine)
					{
						tempc_ptr(WeaponObject) weapon = ptr_static_cast<WeaponObject>(pick_up_set[i]);

						if (weapon)
						{
							weapon->weapon->SetPosition((const Vector3&)colliderPos + Vector3(0.f, 0.1f, 0.f) * (const Quaternion&)colliderRot);

							if (weapon->weapon->GetWeaponType() != kWeaponTypeBomb)
								weapon->weapon->SetRotation((const Quaternion&)colliderRot * Quaternion(Vector3(0.f, 0.f, 1.f) * (const Quaternion&)colliderRot, HALFPI) * Quaternion(Vector3(0.f, -1.f, 0.f) * (const Quaternion&)colliderRot, HALFPI));
						}
					}
				}
			}
		}

		// update mesh
		for(uint i = 0; i < pick_up_set.Size(); i++)
		{
			if (pick_up_set[i])
			{
				switch (pick_up_set[i]->type)
				{
				case kPickUpWeapon:
					{
						tempc_ptr(WeaponObject) weapon = ptr_static_cast<WeaponObject>(pick_up_set[i]);
						if (weapon && weapon->weapon)
							weapon->weapon->UpdateMesh();
					}
					break;
				case kPickUpSupply:
					{
						if(pick_up_set[i]->SType == kSupplyGoldWithForce)
						{
							tempc_ptr(PickUpObject) pObj = pick_up_set[i];
							if(pObj)
								pObj->collider->addForce(NxVec3(0, -20.f, 0), NX_ACCELERATION);
						}
					}
					break;
				}
			}
			
		}

		// update pickup delay
		if (pickup_delay_timer > 0)
			pickup_delay_timer -= frame_time;
	}

	/// drop weapon
	void PickUpManager::DropWeapon(tempc_ptr(Character) chara, uint uid, byte weapon_id, tempc_ptr(WeaponInfo) info)
	{
		if (chara)
		{
			const Vector3 & pos = chara->GetPosition();
			const Quaternion & rot = chara->GetRotation();
			Vector3 dir = Vector3(0.f, 0.f, -1.f) * rot;
			if(weapon_id != BOMB_SLOT)
			{
				tempc_ptr(WeaponObject) pu = AddWeapon(uid, info, pos + Vector3(0.f, 1.0f, -0.0f) * rot, rot);

				if (pu && pu->collider)
					pu->collider->setLinearVelocity(7.f * (const NxVec3 &)dir + NxVec3(0.f, 0.8f, 0.f));
			}
			else
			{
				
			
				tempc_ptr(WeaponObject) pu = AddWeapon(uid, info, pos + Vector3(0.f, 1.0f, -0.0f) * rot, rot );

				Quaternion q = Quaternion::kIdentity;
				q.SetAxisAngle(Vector3(1, 0, 0), HALFPI);
				pu->weapon->SetRotation(q);


				if (pu && pu->collider)
					pu->collider->setLinearVelocity(7.f * (const NxVec3 &)dir + NxVec3(0.f, 0.8f, 0.f));
			}

		}
	}

	/// add pick up
	void PickUpManager::AddPickUp(tempc_ptr(PickUpObject) object, const Core::Vector3 & position, const Core::Quaternion & rotation)
	{
		if (object)
		{
			//generate a collider
			object->collider = PhysxSystem::CreateBoxCCD(Vector3(0.f,1.f,0.f), Vector3(0.3f, 0.1f, 0.3f), PhysxSystem::kDynamic);
			//when collider touches sth, it will send a report to create a trigger.Obsoleted! try to stop instead.
			object->collider->setContactReportFlags(NX_NOTIFY_ON_START_TOUCH);
			object->collider->setAngularDamping(10);
			object->collider->setMaxAngularVelocity(0);
			//object->collider->userData = (void *)pick_up_set[pick_up_set.Size() - 1];
			object->trigger = NULL;

			object->collider->setLinearVelocity(NxVec3(0.f, 0.f, 0.f));
			object->collider->setAngularVelocity(NxVec3(0.f, 0.f, 0.f));//just in case :)
			object->collider->setGlobalPosition((const NxVec3 &)position + NxVec3(0, 0.05f, 0));
			object->collider->setGlobalOrientationQuat((const NxQuat &) rotation);

			pick_up_set.Add(object);
			if(object->particle && gLevel)
			{
				object->particle->SetPosition(position);
				object->particle->SetRotation(rotation);

				gLevel->AddParticle(object->particle);
			}
			object->collider->userData = pick_up_set[pick_up_set.Size() - 1];
		}
	}

	bool PickUpManager::GetPickUpPosition(uint uid, PickUpType type, Core::Vector3& pos)
	{
		for(uint i = 0 ; i < pick_up_set.Size(); i ++)
		{
			sharedc_ptr(PickUpManager::PickUpObject) Object = pick_up_set[i];
			if(!Object)
				continue;

			if(!Object->collider || Object->uid != uid || type != Object->type)
				continue;
			
			pos = (const Vector3&)Object->collider->getGlobalPosition();
			return true;
		}

		return false;
	}

	void PickUpManager::AddPickUpWithForce(tempc_ptr(PickUpObject) object, const Core::Vector3 & position, const Core::Quaternion & rotation,const Core::Vector3 & force)
	{
		if (object)
		{
			//generate a collider
			object->collider = PhysxSystem::CreateBoxCCD(Vector3(0.f,1.f,0.f), Vector3(0.3f, 0.1f, 0.3f), PhysxSystem::kDynamic);
			//when collider touches sth, it will send a report to create a trigger.Obsoleted! try to stop instead.
			object->collider->setContactReportFlags(NX_NOTIFY_ON_START_TOUCH);
			object->collider->setAngularDamping(10);
			object->collider->setMaxAngularVelocity(0);
			//object->collider->userData = (void *)pick_up_set[pick_up_set.Size() - 1];
			object->trigger = NULL;
    
			object->collider->setLinearVelocity((NxVec3&)force);
			object->collider->setAngularVelocity(NxVec3(0.f, 0.f, 0.f));//just in case :)
			object->collider->setGlobalPosition((const NxVec3 &)position + NxVec3(0, 0.05f, 0));
			object->collider->setGlobalOrientationQuat((const NxQuat &) rotation);
			//object->collider->addForce(NxVec3(force.x * 300.f, 900.f, force.z * 300.f),NX_ACCELERATION);

			pick_up_set.Add(object);
			if(object->particle && gLevel)
			{
				object->particle->SetPosition(position);
				object->particle->SetRotation(rotation);

				gLevel->AddParticle(object->particle);
			}
			object->collider->userData = pick_up_set[pick_up_set.Size() - 1];
		}
	}

	// add supply
	tempc_ptr(PickUpManager::SupplyObject) PickUpManager::AddSupplyNew(uint uid, const Core::Vector3 & position, const Core::Quaternion & rotation,SupplyType type,int value)
	{
		sharedc_ptr(SupplyObject) pu = ptr_new SupplyObject;
		pu->create_Trigger_Time = 0.f;
		pu->type= kPickUpSupplyNew;
		pu->SType = type;
		pu->uid = uid;
		pu->removed = false;
		pu->value = value;
		CStrBuf<256> key;
		switch(type)
		{
		case kSupplyGoldWithForce:
		case kSupplyZombieGold:
			{
				key.format("boss_coin_fall");
			}
			break;	
		default:
			{
				key.format("scene_proppos");
			}
			break;
		}
		pu->particle = ptr_new ParticleSystem(key,false);

		AddPickUp(pu, position, rotation);

		return pu;
	}
	/// add gun
	tempc_ptr(PickUpManager::WeaponObject) PickUpManager::AddWeapon(uint uid, tempc_ptr(WeaponInfo) info, const Vector3 & position, const Quaternion & rotation)
	{
		sharedc_ptr(WeaponObject) pu = ptr_new WeaponObject;
		pu->create_Trigger_Time = 0.5f;
		pu->weapon = Character::CreateWeapon(info);
		pu->type = kPickUpWeapon;
		pu->uid = uid;
		pu->removed = false;
		/*CStrBuf<256> key;
		key.format("firegun_defmf_%s","3rd");
		pu->particle = ptr_new ParticleSystem(key,false);
		*/
		// add pick up
		AddPickUp(pu, position, rotation);

		if (pu->weapon)
		{
			pu->weapon->Initialize();
			pu->weapon->Inactive();//set gun'reloading = false
			pu->weapon->SetVisible(true);
			pu->weapon->SetOwner(NullPtr);
			pu->weapon->UpdateAnimation(0);
			pu->weapon->UpdateMesh();
		}

		return pu;
	}

	/// add supply object
	tempc_ptr(PickUpManager::PickUpObject) PickUpManager::AddSupply(uint uid, const Core::Vector3 & position, const Core::Quaternion & rotation,SupplyType type, const Core::Vector3 & force, int team)
	{
		sharedc_ptr(PickUpObject) pu = ptr_new PickUpObject;
		pu->create_Trigger_Time = 0.f;
		pu->type= kPickUpSupply;
		pu->SType = type;
		pu->uid = uid;
		pu->removed = false;
		pu->team = team;
		CStrBuf<256> key;
		switch(type)
		{
			case kSupplyGoldWithForce:
			case kSupplyZombieGold:
				{
					key.format("boss_coin_fall");
				}
				break;	
			case kSupplyCommonZombie:
			case kSupplyCommonZombie2:
				{
					key.format("supplybox");
				}
				break;
			case kSupplySurvivalItemGhostFire:
				{
					key.format("scene56_fire01");
				}
				break;
			default:
				{
					key.format("scene_proppos");
				}
				break;
		}

		if (type == kSupplyCommonZombie2)
		{
			Core::String str = Core::String::Format(gLang->GetTextW(L"ɱ¾���ĵ��߳��֣���ȥ����ɣ�"));
			gLevel->AddHorn(str);
		}
		pu->particle = ptr_new ParticleSystem(key,false);

		// add pick up
		if(type == kSupplyGoldWithForce || type == kSupplyZombieGold)
		{
			AddPickUpWithForce(pu, position, rotation, force);
		}
		else
		{
			AddPickUp(pu, position, rotation);
		}
		return pu;
	}

	void PickUpManager::CreateTrigger(tempc_ptr(PickUpObject) pickup, const Core::Vector3 & position)
	{
		if (!pickup)
			return;

		if(pickup->trigger)
			return;

		NxBodyDesc body_desc;
		body_desc.linearDamping = 10000.f;
		body_desc.flags |= NX_BF_DISABLE_GRAVITY | NX_BF_KINEMATIC;
		NxBoxShapeDesc TempBoxDesc;
		TempBoxDesc.dimensions = NxVec3(0.5f, 0.5f, 0.5f);    
		TempBoxDesc.shapeFlags |= NX_TRIGGER_ENABLE;
		TempBoxDesc.group = PhysxSystem::kTrigger;
		NxBoxShapeDesc dummy_shape;
		dummy_shape.dimensions = NxVec3(0.5f, 0.5f, 0.5f);
		dummy_shape.group = PhysxSystem::kNone;
		NxActorDesc actor_desc;
		actor_desc.body		= &body_desc;
		actor_desc.density = 100.f;
		actor_desc.globalPose.t  = (const NxVec3 &)position;
		actor_desc.shapes.push_back(&TempBoxDesc);
		actor_desc.shapes.push_back(&dummy_shape);
		actor_desc.userData = (void *)pickup;//////////////////////////
		pickup->trigger = PhysxSystem::CreateActor(actor_desc);
	}

	/// create trigger
	void PickUpManager::CreateTrigger(U32 id, const Vector3 & position)
	{
		U32 iCount = -1;
		bool bFind = false;
		for (U32 nCount = 0; nCount < pick_up_set.Size() && !bFind; ++nCount)
		{
			if (id == pick_up_set[nCount]->uid)
			{
				iCount = nCount;
				bFind = true;
			}
		}

		if(iCount >= pick_up_set.Size())
			return;

		if (!pick_up_set[iCount])
			return;

		if(pick_up_set[iCount]->trigger)
			return;

		NxBodyDesc body_desc;
		body_desc.linearDamping = 10000.f;
		body_desc.flags |= NX_BF_DISABLE_GRAVITY | NX_BF_KINEMATIC;
		NxBoxShapeDesc TempBoxDesc;
		TempBoxDesc.dimensions = NxVec3(0.5f, 0.5f, 0.5f);    
		TempBoxDesc.shapeFlags |= NX_TRIGGER_ENABLE;
		TempBoxDesc.group = PhysxSystem::kTrigger;
		NxBoxShapeDesc dummy_shape;
		dummy_shape.dimensions = NxVec3(0.5f, 0.5f, 0.5f);
		dummy_shape.group = PhysxSystem::kNone;
		NxActorDesc actor_desc;
		actor_desc.body		= &body_desc;
		actor_desc.density = 100.f;
		actor_desc.globalPose.t  = (const NxVec3 &)position;
		actor_desc.shapes.push_back(&TempBoxDesc);
		actor_desc.shapes.push_back(&dummy_shape);
		actor_desc.userData = (void *)pick_up_set[iCount];//////////////////////////
		pick_up_set[iCount]->trigger = PhysxSystem::CreateActor(actor_desc);

	}
	/// pick up
	void PickUpManager::PickUp(tempc_ptr(Character) player, tempc_ptr(PickUpObject) pickup)
	{
		if (pickup_delay_timer > 0)
			return;

		if (!player)
			return;

		if (player->IsDied())
			return;
		
		if (player->zombie_dying_flag)
			return;

		if (!pickup)
			return;

		if (pickup->removed)
			return;

		switch (pickup->type)
		{
		case kPickUpWeapon:
			PickUpWeapon(player, pickup);
			break;

		case kPickUpSupply:
			PickUpSupply(player, pickup);
			break;
		case kPickUpSupplyNew:
			if (player->GetTeam() == 0)
			{
				PickUpSupplyNew(player, pickup);
			}
			break;
		}
	}

	/// pick up
	void PickUpManager::PickUp(tempc_ptr(Character) player, uint id)
	{
		if (pickup_delay_timer > 0)
			return;

		if (!player)
			return;

		if (player->IsDied())
			return;

		U32 iCount = -1;
		bool bFind = false;
		for (U32 nCount = 0; nCount < pick_up_set.Size() && !bFind; ++nCount)
		{
			if (id == pick_up_set[nCount]->uid)
			{
				iCount = nCount;
				bFind = true;
			}
		}

		if (iCount >= pick_up_set.Size())
			return;

		if (!pick_up_set[iCount])
			return;

		if (pick_up_set[iCount]->removed)
			return;

		switch (pick_up_set[iCount]->type)
		{
		case kPickUpWeapon:
			PickUpWeapon(player, iCount);
			break;

		case kPickUpSupply:
			PickUpSupply(player, iCount);
			break;
		case kPickUpSupplyNew:
			if (player->GetTeam() == 0)
			{
				PickUpSupplyNew(player, iCount);
			}
			break;
		}
	}


	/// pick up weapon
	void PickUpManager::PickUpWeapon(tempc_ptr(Character) player, tempc_ptr(PickUpObject) pickup)
	{
		if (!player)
			return;
	
		if (!pickup)
			return;

		if (pickup->removed)
			return;

		tempc_ptr(WeaponObject) weapon = ptr_static_cast<WeaponObject>(pickup);

		if (!weapon || !weapon->weapon)
			return;

		if(weapon->weapon->weapon_info->weapon_type == kWeaponTypeBomb && player->GetTeam() != 1)
			return;
		
		if(weapon->weapon->weapon_info->weapon_type != kWeaponTypeBomb)
		{
			int count=0;
			for (int i = 0; i < 2;++i)
			{
				GunBase* gun = ptr_dynamic_cast<GunBase>(player->GetWeaponById(i));
				if(gun)
				{
					int ammo_count = gun->gun_info->ammo_count;	
					int ammo_one_clip = gun->gun_info->ammo_one_clip;
					if (ammo_count > 0)
					{
						int max_ammo = gun->gun_info->ammo_count;	
						if(max_ammo - gun->ammo_count <= 0)
							count++;
					}
					else if (ammo_one_clip > 0)
					{
						int max_ammo = gun->gun_info->ammo_one_clip;
						if (max_ammo - gun->ammo_in_clip <= 0)
							count++;
					}
					else if (ammo_count == 0 && ammo_one_clip == 0)
					{
						count++;
					}
				}
			}
			if (count == 2 && !gLevel->player_manager->need_gun_tower_ammo)
				return;
		}
		
		gGame->channel_connection->PickUpWeapon(weapon->uid);
		

		/*byte weapon_id = -1;
		switch (weapon->weapon->GetWeaponType())
		{
		case kWeaponTypeRifle:
		case kWeaponTypeSubMachineGun:
		case kWeaponTypeSniperGun:
		case kWeaponTypeShotGun:
		case kWeaponTypeMiniGun:
		case kWeaponTypeDualPistol:
			weapon_id = 0;
			break;

		case kWeaponTypePistol:
			weapon_id = 1;
			break;

		case kWeaponTypeGrenade:
			weapon_id = 3;
			break;

		case kWeaponTypeFlash:
		case kWeaponTypeSmoke:
			weapon_id = 4;
			break;

		case kWeaponTypeBomb:
			weapon_id = 6;
			break;

		default:
			break;
		}*/

		//if (weapon_id < 7)
		//{
		//	if (player->GetWeaponById(weapon_id))
		//		return;

		//	if (player->GetTeam() == 1 && weapon->weapon->GetWeaponType() == kWeaponTypeBomb)
		//		return;

		//	gGame->channel_connection->PickUpWeapon(weapon->uid, weapon_id,weapon->weapon->GetWeaponType());

		//	pickup_delay_timer = pickup_delay;							
		//}
	}

	/// pick up weapon
	void PickUpManager::PickUpWeapon(tempc_ptr(Character) player, uint id)
	{
		if (!player)
			return;

		if (id >= pick_up_set.Size())
			return;

		if (!pick_up_set[id])
			return;

		if (pick_up_set[id]->removed)
			return;

		

		tempc_ptr(WeaponObject) weapon = ptr_static_cast<WeaponObject>(pick_up_set[id]);

		

		if (!weapon || !weapon->weapon)
			return;

		if(weapon->type == kWeaponTypeBomb && player->GetTeam() > 0)
			return;

		if(weapon->type != kWeaponTypeBomb)
		{
			int count=0;
			for (int i = 0; i < 2;++i)
			{
				GunBase* gun = ptr_dynamic_cast<GunBase>(player->GetWeaponById(i));
				if(gun)
				{
					int ammo_count = gun->gun_info->ammo_count;	
					int ammo_one_clip = gun->gun_info->ammo_one_clip;
					if (ammo_count > 0)
					{
						int max_ammo = gun->gun_info->ammo_count;	
						if(max_ammo - gun->ammo_count <= 0)
							count++;
					}
					else if (ammo_one_clip > 0)
					{
						int max_ammo = gun->gun_info->ammo_one_clip;
						if (max_ammo - gun->ammo_in_clip <= 0)
							count++;
					}
					else if (ammo_count == 0 && ammo_one_clip == 0)
					{
						count++;
					}
				}
			}
			if (count == 2 && !gLevel->player_manager->need_gun_tower_ammo)
				return;
		}

		gGame->channel_connection->PickUpWeapon(weapon->uid);

		//byte weapon_id = -1;
		//switch (weapon->weapon->GetWeaponType())
		//{
		//case kWeaponTypeRifle:
		//case kWeaponTypeSubMachineGun:
		//case kWeaponTypeSniperGun:
		//case kWeaponTypeShotGun:
		//case kWeaponTypeMiniGun:
		//case kWeaponTypeDualPistol:
		//	weapon_id = 0;
		//	break;

		//case kWeaponTypePistol:
		//	weapon_id = 1;
		//	break;

		//case kWeaponTypeGrenade:
		//	weapon_id = 3;
		//	break;

		//case kWeaponTypeBomb:
		//	weapon_id = 6;
		//	break;
		//	
		//default:
		//	break;
		//}

		//if (weapon_id < 7)
		//{
		//	if (player->GetWeaponById(weapon_id))
		//		return;

		//	if (player->GetTeam() == 1 && weapon->weapon->GetWeaponType() == kWeaponTypeBomb)
		//		return;

		//	gGame->channel_connection->PickUpWeapon(weapon->uid, weapon_id,weapon->weapon->GetWeaponType());
		//													
		//	pickup_delay_timer = pickup_delay;							
		//}
	}

	// pick up supply new
	void PickUpManager::PickUpSupplyNew(tempc_ptr(Character) player, tempc_ptr(PickUpObject) pickup)
	{
		if (!player)
			return;

		if (!pickup)
			return;

		tempc_ptr(SupplyObject) supply = ptr_static_cast<SupplyObject>(pickup);

		if (!supply || supply->type == kSupplyNone)
		{
			return;
		}

		if (supply->removed)
			return;

		switch(supply->SType)
		{
		case kSupplyHp:
			{
				int max_hp = player->max_hp;
				ushort hp = player->hp;

				if (hp >= max_hp)
					return;
			}
			break;
		case kSupplyAmmo:
		case kSupplyMedkit:
			{
				int count=0;
				for (int i = 0; i < 2;++i)
				{
					GunBase* gun = ptr_dynamic_cast<GunBase>(player->GetWeaponById(i));
					if(gun)
					{
						int ammo_count = gun->gun_info->ammo_count;	
						int ammo_one_clip = gun->gun_info->ammo_one_clip;
						if (ammo_count > 0)
						{
							int max_ammo = gun->gun_info->ammo_count;	
							if(max_ammo - gun->ammo_count <= 0)
								count++;
						}
						else if (ammo_one_clip > 0)
						{
							int max_ammo = gun->gun_info->ammo_one_clip;
							if (max_ammo - gun->ammo_in_clip <= 0)
								count++;
						}
						else if (ammo_count == 0 && ammo_one_clip == 0)
						{
							count++;
						}
					}
					else
					{
						count++;
					}
				}
				if (count == 2 && !gLevel->player_manager->need_gun_tower_ammo)
					return;
			}
			break;
		case kSupplyAllTools:
			{		
				GunBase* nowgun = ptr_dynamic_cast<GunBase>(player->GetWeapon());
				int count = 0;
				for (int i = 0; i < 2;++i)
				{
					GunBase* gun = ptr_dynamic_cast<GunBase>(player->GetWeaponById(i));
					if(gun)
					{
						int ammo_count = gun->gun_info->ammo_count;	
						int ammo_one_clip = gun->gun_info->ammo_one_clip;
						if (ammo_count > 0)
						{
							int max_ammo = gun->gun_info->ammo_count;	
							if(max_ammo - gun->ammo_count <= 0)
								count++;
						}
						else if (ammo_one_clip > 0)
						{
							int max_ammo = gun->gun_info->ammo_one_clip;
							if (max_ammo - gun->ammo_in_clip <= 0)
								count++;
						}
						else if (ammo_count == 0 && ammo_one_clip == 0)
						{
							count++;
						}
					}
					else
					{
						count++;
					}
				}

				{
					int max_hp = player->max_hp;
					ushort hp = player->hp;

					if (hp >= max_hp)
						count++;
				}
				if (count == 3 && !gLevel->player_manager->need_gun_tower_ammo)
					return;					
			}
			break;
		case kSupplyGold:
			if (gGame->channel_connection)
			{
				if (player && player->GetTeam() != gGame->channel_connection->round_win_team)
					return;
			}
			break;
		case kSupplyGoldWithForce:
			{
				if(gGame->channel_connection)
				{
					if(pickup->team >= 0)
					{
						if(player && player->GetTeam() != pickup->team)
						{
							return;
						}
					}
				}
			}
			break;
		case kSupplyZombieGold:
			{
				if(gGame->channel_connection)
				{
					if(player && player->GetTeam() == 0)
					{
						return;
					}
				}
			}
			break;
		}

		gGame->channel_connection->PickUpSupplyObjectNew(supply->uid);
		//pickup_delay_timer = pickup_delay;
	}


	void PickUpManager::PickUpSupplyNew(tempc_ptr(Character) player, uint id)
	{
		if (!player)
			return;

		if (id >= pick_up_set.Size())
			return;

		if (!pick_up_set[id])
			return;

		if (pick_up_set[id]->removed)
			return;

		switch(pick_up_set[id]->SType)
		{
		case kSupplyHp:
			{
				int max_hp = player->max_hp;
				ushort hp = player->hp;

				if (hp >= max_hp)
					return;
			}
			break;
		case kSupplyAmmo:
		case kSupplyMedkit:
			{
				int count=0;
				for (int i = 0; i < 2;++i)
				{
					GunBase* gun = ptr_dynamic_cast<GunBase>(player->GetWeaponById(i));
					if(gun)
					{
						int ammo_count = gun->gun_info->ammo_count;	
						int ammo_one_clip = gun->gun_info->ammo_one_clip;
						if (ammo_count > 0)
						{
							int max_ammo = gun->gun_info->ammo_count;	
							if(max_ammo - gun->ammo_count <= 0)
								count++;
						}
						else if (ammo_one_clip > 0)
						{
							int max_ammo = gun->gun_info->ammo_one_clip;
							if (max_ammo - gun->ammo_in_clip <= 0)
								count++;
						}
						else if (ammo_count == 0 && ammo_one_clip == 0)
						{
							count++;
						}
					}
				}
				if (count == 2 && !gLevel->player_manager->need_gun_tower_ammo)
					return;
			}
			break;
		case kSupplyAllTools:
			{		
				GunBase* nowgun = ptr_dynamic_cast<GunBase>(player->GetWeapon());
				int count = 0;
				for (int i = 0; i < 2;++i)
				{
					GunBase* gun = ptr_dynamic_cast<GunBase>(player->GetWeaponById(i));
					if(gun)
					{
						int ammo_count = gun->gun_info->ammo_count;	
						int ammo_one_clip = gun->gun_info->ammo_one_clip;
						if (ammo_count > 0)
						{
							int max_ammo = gun->gun_info->ammo_count;	
							if(max_ammo - gun->ammo_count <= 0)
								count++;
						}
						else if (ammo_one_clip > 0)
						{
							int max_ammo = gun->gun_info->ammo_one_clip;
							if (max_ammo - gun->ammo_in_clip <= 0)
								count++;
						}
						else if (ammo_count == 0 && ammo_one_clip == 0)
						{
							count++;
						}
					}
				}

				{
					int max_hp = player->max_hp;
					ushort hp = player->hp;

					if (hp >= max_hp)
						count++;
				}
				if (count == 3 && !gLevel->player_manager->need_gun_tower_ammo)
					return;					
			}
			break;
		}

		gGame->channel_connection->PickUpSupplyObjectNew(pick_up_set[id]->uid);
		//pickup_delay_timer = pickup_delay;
	}

	void PickUpManager::PickUpSupply(tempc_ptr(Character) player, tempc_ptr(PickUpObject) pickup)
	{
		if (!gLevel)
			return;

		if (!player)
			return;
	
		if (!pickup)
			return;

		if (pickup->removed)
			return;

		if (gLevel->game_type == RoomOption::kSurvivalMode && player->IsAttributeExist(kEffect_Survival_Ghost) && pickup->SType != kSupplySurvivalItemGhostFire)
			return;

		switch(pickup->SType)
		{
		case kSupplyHp:
			{
				int max_hp = player->max_hp;
				ushort hp = player->hp;

				if (hp >= max_hp)
					return;
			}
			break;
		case kSupplyAmmo:
		case kSupplyMedkit:
			{
				int count=0;
				for (int i = 0; i < 2;++i)
				{
					GunBase* gun = ptr_dynamic_cast<GunBase>(player->GetWeaponById(i));
					if(gun)
					{
						int ammo_count = gun->gun_info->ammo_count;	
						int ammo_one_clip = gun->gun_info->ammo_one_clip;
						if (ammo_count > 0)
						{
							//float p = player->GetTotalAttributeByType(kEffect_Infect_AmmoCount);
							int max_ammo = gun->gun_info->ammo_count;// * p;	
							if(max_ammo - gun->ammo_count <= 0)
								count++;
						}
						else if (ammo_one_clip > 0)
						{
							int max_ammo = gun->gun_info->ammo_one_clip;
							if (max_ammo - gun->ammo_in_clip <= 0)
								count++;
						}
						else if (ammo_count == 0 && ammo_one_clip == 0)
						{
							count++;
						}
					}
					else
					{
						count++;
					}
				}
				bool has_gun_tower = false;

				if (count == 2 && !gLevel->player_manager->need_gun_tower_ammo)
					return;
			}
			break;
		case kSupplyAllTools:
			{		
				GunBase* nowgun = ptr_dynamic_cast<GunBase>(player->GetWeapon());
				int count = 0;
				for (int i = 0; i < 2;++i)
				{
					GunBase* gun = ptr_dynamic_cast<GunBase>(player->GetWeaponById(i));
					if(gun)
					{
						int ammo_count = gun->gun_info->ammo_count;	
						int ammo_one_clip = gun->gun_info->ammo_one_clip;
						if (ammo_count > 0)
						{
							//float p = player->GetTotalAttributeByType(kEffect_Infect_AmmoCount);
							int max_ammo = gun->gun_info->ammo_count;// * p;	
							if(max_ammo - gun->ammo_count <= 0)
								count++;
						}
						else if (ammo_one_clip > 0)
						{
							int max_ammo = gun->gun_info->ammo_one_clip;
							if (max_ammo - gun->ammo_in_clip <= 0)
								count++;
						}
						else if (ammo_count == 0 && ammo_one_clip == 0)
						{
							count++;
						}
					}
					else
					{
						count++;
					}
				}

				{
					int max_hp = player->max_hp;
					ushort hp = player->hp;

					if (hp >= max_hp)
						count++;
				}
				if (count == 3 && !gLevel->player_manager->need_gun_tower_ammo)
					return;					
			}
			break;
		case kSupplyGold:
			if (gGame->channel_connection)
			{
				if (player && player->GetTeam() != gGame->channel_connection->round_win_team && gLevel->game_type != RoomOption::KMoonMode)
					return;
			}
			break;
		case kSupplyGoldWithForce:
			{
				if(gGame->channel_connection)
				{
					if(pickup->team >= 0)
					{
						if(player && player->GetTeam() != pickup->team)
						{
							return;
						}
					}
				}
			}
			break;
		case kSupplyZombieGold:
			{
				if(gGame->channel_connection)
				{
					if(player && player->GetTeam() == 0)
					{
						return;
					}
				}
			}
			break;
		case kSupplyCommonZombie:
			{
				if(gLevel && gLevel->game_type == RoomOption::kBossMode2)
				{
					if(player)
					{
						tempc_ptr(CharacterInfo) info = player->GetCurCharinfo();
						if (player->GetTeam() == 1)
						{
							return;
						}
						else if (player->GetTeam() == 0 && info && 
								(info->career_id == gLevel->boss2_sp_career_id[0] || 
								info->career_id == gLevel->boss2_sp_career_id[1] || 
								info->career_id == gLevel->boss2_sp_career_id[2] || 
								info->career_id == gLevel->boss2_sp_career_id[3]))
						{
							return;
						}
					}
				}

				if(gLevel && gLevel->game_type == RoomOption::kItemMode)
				{
					if(player)
					{
						tempc_ptr(CharacterInfo) info = player->GetCurCharinfo();
						if (info && info->career_id == gLevel->item_career_id)
						{
							return;
						}
					}
				}
			}
			break;
		case kSupplyCommonZombie2:
			{
				if(gLevel && gLevel->game_type == RoomOption::kItemMode)
				{
					if(player)
					{
						tempc_ptr(CharacterInfo) info = player->GetCurCharinfo();
						if (info && info->career_id == gLevel->item_career_id)
						{
							return;
						}
					}
				}
			}
			break;
		case kSupplySurvivalItemHp:
		case kSupplySurvivalItemAmmo:
		case kSupplySurvivalItemTrapAmmo:
		case kSupplySurvivalItemTrapHP:
		case kSupplySurvivalItemTrapExpose:
		case kSupplySurvivalItemTrapBomb:
		case kSupplySurvivalItemTrapDebuff:
		case kSupplySurvivalItemRandom:
		case kSupplySurvivalIteminitiative:
			{
				if (player->IsAttributeExist(kEffect_Survival_Ghost))
					return;
			}
			break;
		case kSupplySurvivalItemGhostFire:
			{
				if (!player->IsAttributeExist(kEffect_Survival_Ghost))
					return;
			}
			break;
		}

		gGame->channel_connection->PickUpSupplyObject(pickup->uid);
		pickup_delay_timer = pickup_delay;
	}

	/// pick up supply
	void PickUpManager::PickUpSupply(tempc_ptr(Character) player, uint id)
	{
		if (!gLevel)
			return;
		if (!player)
			return;

		if (id >= pick_up_set.Size())
			return;

		if (!pick_up_set[id])
			return;

		if (pick_up_set[id]->removed)
			return;

		switch(pick_up_set[id]->SType)
		{
		case kSupplyHp:
			{
				int max_hp = player->max_hp;
				ushort hp = player->hp;

				if (hp >= max_hp)
					return;
			}
			break;
		case kSupplyAmmo:
		case kSupplyMedkit:
			{
				int count=0;
				for (int i = 0; i < 2;++i)
				{
					GunBase* gun = ptr_dynamic_cast<GunBase>(player->GetWeaponById(i));
					if(gun)
					{
						int ammo_count = gun->gun_info->ammo_count;	
						int ammo_one_clip = gun->gun_info->ammo_one_clip;
						if (ammo_count > 0)
						{
							int max_ammo = gun->gun_info->ammo_count;	
							if(max_ammo - gun->ammo_count <= 0)
								count++;
						}
						else if (ammo_one_clip > 0)
						{
							int max_ammo = gun->gun_info->ammo_one_clip;
							if (max_ammo - gun->ammo_in_clip <= 0)
								count++;
						}
						else if (ammo_count == 0 && ammo_one_clip == 0)
						{
							count++;
						}
					}
				}
				if (count == 2 && !gLevel->player_manager->need_gun_tower_ammo)
					return;
			}
			break;
		case kSupplyAllTools:
			{		
				GunBase* nowgun = ptr_dynamic_cast<GunBase>(player->GetWeapon());
				int count = 0;
				for (int i = 0; i < 2;++i)
				{
					GunBase* gun = ptr_dynamic_cast<GunBase>(player->GetWeaponById(i));
					if(gun)
					{
						int ammo_count = gun->gun_info->ammo_count;	
						int ammo_one_clip = gun->gun_info->ammo_one_clip;
						if (ammo_count > 0)
						{
							int max_ammo = gun->gun_info->ammo_count;	
							if(max_ammo - gun->ammo_count <= 0)
								count++;
						}
						else if (ammo_one_clip > 0)
						{
							int max_ammo = gun->gun_info->ammo_one_clip;
							if (max_ammo - gun->ammo_in_clip <= 0)
								count++;
						}
						else if (ammo_count == 0 && ammo_one_clip == 0)
						{
							count++;
						}
					}
				}

				{
					int max_hp = player->max_hp;
					ushort hp = player->hp;

					if (hp >= max_hp)
						count++;
				}
				if (count == 3 && !gLevel->player_manager->need_gun_tower_ammo)
					return;					
			}
			break;
		}

		gGame->channel_connection->PickUpSupplyObject(pick_up_set[id]->uid);
		pickup_delay_timer = pickup_delay;
	}

	/// remove pick up 
	void PickUpManager::RemovePickUpWeapon(uint id)
	{
		for(U32 i = 0; i < pick_up_set.Size(); i++)
		{
			if (pick_up_set[i] && pick_up_set[i]->type == kPickUpWeapon && pick_up_set[i]->uid == id)
			{
				pick_up_set[i]->removed = true;

				tempc_ptr(WeaponObject) weapon = ptr_static_cast<WeaponObject>(pick_up_set[i]);
				if (weapon && weapon->weapon)
				{
					weapon->weapon = NullPtr;
				}

				break;
			}
		}
	}

	/// remove pick up 
	void PickUpManager::RemovePickUpSupply(uint id)
	{
		for(U32 i = 0; i < pick_up_set.Size(); i++)
		{
			if (pick_up_set[i] && pick_up_set[i]->type == kPickUpSupply && pick_up_set[i]->uid == id)
			{
				pick_up_set[i]->removed = true;

				break;
			}
		}
	}
	
	/// remove pick up new
	void PickUpManager::RemovePickUpSupplyNew(uint id)
	{
		for(U32 i = 0; i < pick_up_set.Size(); i++)
		{
			if (pick_up_set[i] && pick_up_set[i]->type == kPickUpSupplyNew && pick_up_set[i]->uid == id)
			{
				pick_up_set[i]->removed = true;

				tempc_ptr(SupplyObject) supply = ptr_static_cast<SupplyObject>(pick_up_set[i]);
				if (supply && supply->SType)
				{
					supply->SType = kSupplyNone;
				}

				break;
			}
		}
	}

	void PickUpManager::RemoeAllSupply()
	{
		for(uint i = 0; i < pick_up_set.Size(); i++)
		{
			if (pick_up_set[i])
			{
				if(pick_up_set[i]->type == kPickUpSupply || 
					pick_up_set[i]->type == kPickUpSupplyNew)
				{
					pick_up_set[i]->removed = true;
				}
			}
		}
	}

	void PickUpManager::Draw(Primitive::DrawType type, bool immediate)
	{
		for(uint i = 0; i < pick_up_set.Size(); i++)
		{
			if (pick_up_set[i])
			{
				switch (pick_up_set[i]->type)
				{
				case kPickUpWeapon:
					{
						//zheng shuai
						IDirect3DPixelShader9* ps;
						gDx9Device->GetPixelShader(&ps);
						gGame->render->render_pipeline->drop_weapon_ps->SetShader();
						
						tempc_ptr(WeaponObject) weapon = ptr_static_cast<WeaponObject>(pick_up_set[i]);
						if (weapon && weapon->weapon)
							weapon->weapon->Draw(Primitive::kSceneTransparency, immediate);

						gDx9Device->SetPixelShader(ps);
						
					}
					break;

				case kPickUpSupply:
					{
						tempc_ptr(StaticMesh) supply_mesh;

						switch(pick_up_set[i]->SType)
						{
						case kSupplyHp:
						case kSupplySurvivalItemHp:
							supply_mesh = gLevel->hp_supply;
							break;
						case kSupplyAmmo:
						case kSupplySurvivalItemAmmo:
							supply_mesh = gLevel->Ammo_supply;
							break;
						case kSupplyMedkit:
							supply_mesh = gLevel->bigammo_supply;
							break;
						case kSupplyAllTools:
							supply_mesh = gLevel->bighp_supply;
							break;
						case kSupplyNone:
							break;
						case kSupplyGold:
						case kSupplyGoldWithForce:
						case kSupplyZombieGold:
							supply_mesh = gLevel->gold_supply;
							break;
						case kSupplyDropItem:
							supply_mesh = gLevel->dropitem_supply;
							break;
						case kSupplyCommonZombie:
							if (gLevel->game_type == RoomOption::kItemMode)
							{
								supply_mesh = gLevel->item_normal_supply;
							}
							else
							{
								supply_mesh = gLevel->commonzombie_supply;
							}
							break;
						case kSupplyCommonZombie2:
							supply_mesh = gLevel->item_special_supply;
							break;
						case kSupplyMoonModeWin:
							supply_mesh = gLevel->moon_win_supply;
							break;
						case kSupplyCCoin:
							supply_mesh = gLevel->CCoin_supply;
							break;
						case kSupplyMedal:
							supply_mesh = gLevel->Medal_supply;
							break;
						case kSupplyWrench:
							supply_mesh = gLevel->Wrench_supply;
							break;
						case kSupplyRandomBox1:
						case kSupplyRandomBox2:
						case kSupplyRandomBox3:
						case kSupplyRandomBox4:
						case kSupplySurvivalItemRandom:
						case kSupplySurvivalIteminitiative:
							supply_mesh = gLevel->RandomBox_supply;
							break;
						case kSupplySurvivalItemTrapAmmo:
						case kSupplySurvivalItemTrapHP:
						case kSupplySurvivalItemTrapExpose:
						case kSupplySurvivalItemTrapBomb:
						case kSupplySurvivalItemTrapDebuff:
							{
								supply_mesh = gLevel->Trap_supply;
							}
							break;
						default:
							break;
						}

						if (supply_mesh)
						{
							if (pick_up_set[i]->collider)
							{
								supply_mesh->SetPosition((const Vector3&)pick_up_set[i]->collider->getGlobalPosition());
								Quaternion rot = Quaternion(Vector3(0, 1, 0), supply_rot);
								supply_mesh->SetRotation(rot);
								supply_mesh->Draw(type, immediate);
								//tempc_ptr(StateMainGame) state_main = ptr_dynamic_cast<StateMainGame>(gGame->machine.CurrentState());
								//state_main->ui->Draw2DOjbect(gGame->render->ui_render, RESOURCE_LOAD_NEW("InGameUI/ig_common_hero_mark_blue.dds", true, Texture2D), supply_mesh->GetPosition());
								
							}
						}
					}
					break;
				case kPickUpSupplyNew:
					{
						tempc_ptr(StaticMesh) supply_mesh;

						switch(pick_up_set[i]->SType)
						{
						case kSupplyHp:
							supply_mesh = gLevel->zombie_hp;
							break;
						case kSupplyAmmo:
							supply_mesh = gLevel->zombie_ammo;
							break;
						case kSupplyMedkit:
							supply_mesh = gLevel->bigammo_supply;
							break;
						case kSupplyAllTools:
							supply_mesh = gLevel->bighp_supply;
							break;
						case kSupplyNone:
							break;
						case kSupplyGold:
						case kSupplyGoldWithForce:
						case kSupplyZombieGold:
							supply_mesh = gLevel->gold_supply;
							break;
						default:
							break;
						}

						if (supply_mesh)
						{
							if (pick_up_set[i]->collider)
							{
								supply_mesh->SetPosition((const Vector3&)pick_up_set[i]->collider->getGlobalPosition());
								Quaternion rot = Quaternion(Vector3(0, 1, 0), supply_rot);
								supply_mesh->SetRotation(rot);
								supply_mesh->Draw(type, immediate);
							}
						}
					}
					break;
				}
			}
		}
	}
}

DEFINE_PDE_TYPE_CLASS(Client::Level)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_METHOD(GetPveClientByName);
		ADD_PDE_METHOD(GetCharacter);
	}
};

REGISTER_PDE_TYPE(Client::Level);

namespace Client
{
	/// constructor
	Level::Level()
		: state(0)
		, use_self_weapon(1)
		, flash_bright(0.f)
		, flash_light(0.f)
		, light_position(Vector3::kZero)

		, camera_position(Vector3::kZero)
		, camera_rotation(Quaternion::kIdentity)

		, force_draw_all_visible(false)
		
		, team_hurt(false)

		, game_type(RoomOption::kTeam)
		, rule_value(100)

		, holdpoint_rotspeed(0.f)
		, holdpoint_rot(Quaternion::kIdentity)

		, round_start_waiting(false)
		, bomb_defusing(false)
		, bomb_defuse_timer(-1.f)
		, bomb_defuse_total(-1.f)
		, bomb_exploded(false)
		, zombie_saving_dying(false)
		, round_start_wait_time(0)
		, round_end_wait_time(0.0f)
		, round_total_time(0.0f)

		, activeOC(true)
		, hold_point_fPersert_red(0.f)
		, speed_red(0.f)
		, hold_point_fPersert_blue(0.f)
		, speed_blue(0.f)

		, old_vehice_length_red(0.f)
		, old_vehice_length_blue(0.f)
		, vehice_fPersert_red(0.f)
		, vehice_fPersert_blue(0.f)
		, showhorn(false)
		, horntime(10.0f)
		, start_chooseperson_time(0.f)
		, holdpoint_sound(NULL)
		, spiriteball_fly_sound(NULL)
		, mvp_sound(NULL)
		, isselectperson(false)
		, novice_index(0)
		, novice_timer(0.f)
		, novice_shoot_num(0)
		, novice_need_timer(false)
		, sponsor_uid(-1)
		, kicked_uid(-1)
		, kicked_reason(-1)
		, kick_select_open(false)
		, kick_wait_time(0)
		, kick_agree_num(0)
		, kick_against_num(0)
		, kick_select_id(0)
		, kick_count(0)
		, novice_isdraw(false)
		, novice_index_pos(Vector3::kZero)
		, boss_starttimeer(-1)
		, check_dead_timer(-1.f)
		, render_dead_aabb(false)
		, render_debug_aabb(false)
		, boss_mode_left_count(0)
		, sensitivity_timer(0)
		, first_leaf(NullPtr)
		, max_leaf_size(0)
		, fuhuo_cion(0)
		, isuse(false)
		, use_coin_num(0)
		, use_octee_deadzoon(false)
		, zombie_state_two_flag(false)
		, zombie_human_down_sound(false)
		, bomb_explode_timer(-1.f)
		, scenesound_event(NULL)
		, scene3dsound_event(NULL)
		, audio_background(NULL)
		,audio_Survival_background(NULL)
		,audio_Survival1_background(NULL)
		, audio_killing_background(NULL)
		, audio_chrismas_background(NULL)
		, audio_bossmode2_background(NULL)
		, audio_bomb_2d_Plant(NULL)
		, audio_bomb_3d_Plant(NULL)
		, audio_bomb_2d_Defuse(NULL)
		, audio_bomb_3d_Defuse(NULL)
		, audio_bomb_Planting_Defusing(NULL)
		, isGunSensitivity(false)
#if DEBUG_INFO
		, renderOC(false)
		, show_visible_info(false)
		, render_holdpoints(false)
		, render_vehicles(false)
#endif
#if DEBUG_CMD
		, disable_static_collision(false)
		, focus_hurtrate(false)
		, noclip_mode(false)
		, enable_walk(false)
		, pjtammo_cntrol(false)
		, hurtrate(0.f)
		, noclip_speed(0.f)
		, ammo_locked_uid(-1)
		, ammoid_builder(0)
#endif
		, novice_particle(NullPtr)
		, bomb_explode_particle(NullPtr)
		, bomb_on_ground_particle(NullPtr)
		, bomb_droped_id(0)
		, bomb_droped(false)
		, bomb_on_ground(false)
		, step_two_sound_timer(-1.f)
		, step_two_sound_default_timer(-1.f)
		, zombie_state_two_muisc(NULL)
		, boss_mode2_armor_warning(NULL)
		, activeGateTime(0.f)
		, activeHaveTime(-10.f)
		, isCanActiveGate(false)
		, isZombieText_show(true)
		, commonzombie_king_isShow(false)
		, GunTower_Move_CD(0.0f)
		, pveboss_uid(-1)
	{
		gLevel = this;

		map_movearea = AxisAlignedBox::kInvalid;

		team_timer[0] = team_timer[1] = 0.0f;

		team_timer_warning[0] = team_timer_warning[1] = false;

		vehicle_started[0] = vehicle_started[1] = false;

		vehicle_half[0] = vehicle_half[1] = false;

		vehicle_almost_end[0] = vehicle_almost_end[1] = false;

		cur_holdpoint_diffnum = 0;

		skill_img.Clear();
		vehicle_sound[0] = NULL;
		vehicle_sound[1] = NULL;
		for(int i = 1 ; i <= 13 ; i++)
		{
			CStrBuf<256> buf;
			buf.format("ingame/skill_icon/ingame_icon%0.2d.tga",i);
			skill_img.PushBack(RESOURCE_LOAD_NEW(buf.buff(), true, Texture2D));
		}

		current_street_king_uid[0] = 0;
		current_street_king_uid[1] = 0;
		b_Scale_Cd[0]  = false;
		b_Scale_Cd[1]  = false;
		b_Scale_Cd[2]  = false;
		b_Scale_Cd[3]  = false;
		audio_bomb_3d_Plant_Timer[0] = NULL;
		audio_bomb_3d_Plant_Timer[1] = NULL;
		audio_bomb_3d_Plant_Timer[2] = NULL;
		audio_bomb_3d_Plant_Timer[3] = NULL;
		audio_bomb_3d_Plant_Timer[4] = NULL;

		m_fEditMapWidth =30.f;
		m_fEditMapHeight =30.f;
		m_fEditMapItemSize =1.f;
	}

	Level::~Level()
	{
		if (audio_background)
		{
			audio_background->stop(true);
			audio_background = NULL;
		}
		if (audio_Survival_background)
		{
			audio_Survival_background->stop(true);
			audio_Survival_background = NULL;
		}
		if (audio_Survival1_background)
		{
			audio_Survival1_background->stop(true);
			audio_Survival1_background = NULL;
		}
		if (audio_killing_background)
		{
			audio_killing_background->stop(true);
			audio_killing_background = NULL;
		}
		if (audio_chrismas_background)
		{
			audio_chrismas_background->stop(true);
			audio_chrismas_background = NULL;
		}
		if (audio_bossmode2_background)
		{
			audio_bossmode2_background->stop(true);
			audio_bossmode2_background = NULL;
		}
		if (audio_bomb_Planting_Defusing)
		{
			audio_bomb_Planting_Defusing->stop();
			audio_bomb_Planting_Defusing = NULL;
		}
		for (int i = 0;i < 5;i++)
		{
			if (audio_bomb_3d_Plant_Timer[i])
			{
				audio_bomb_3d_Plant_Timer[i]->stop();
				audio_bomb_3d_Plant_Timer[i] = NULL;
			}
		}
		if (zombie_state_two_muisc)
		{
			zombie_state_two_muisc->stop();
			zombie_state_two_muisc = NULL;
		}
		if (boss_mode2_armor_warning)
		{
			boss_mode2_armor_warning->stop();
			boss_mode2_armor_warning = NULL;
		}
		gLevel = NULL;
	}

	/// on create
	void Level::OnCreate()
	{
		Object::OnCreate();

		sharedc_ptr(Level) self = ptr_static_cast<Level>(this);

		lua_state			= Lua::LuaState::NewState();
		lua_state->OpenLibs();

		animation_manager	= ptr_new AnimationManager;
		character_manager	= ptr_new CharacterManager(self);
		player_manager		= ptr_new PlayerManager(self);
		physx_manager		= ptr_new PhysxManager(self);
		bullet_manager		= ptr_new BulletManager();
		decal_manager		= ptr_new DecalManager();
		pickup_manager		= ptr_new PickUpManager(self);
		light_manager		= ptr_new LightManager;
		particle_manager	= ptr_new ParticleManager;
		//anim_object		= ptr_new AnimObject();
		//anim_object->Initialize();
		level_eventmgr			= ptr_new LevelEventMgr;
	}

	/// on destroy
	void Level::OnDestroy()
	{
		Unload();
		if (lua_state)
		{
			lua_state->Close();
			lua_state = NULL;
		}
		Object::OnDestroy();
	}
	
	void Level::CreateBombGroundParticle()
	{
		if(!bomb_on_ground_particle)
		{
			bomb_on_ground_particle = ptr_new ParticleSystem("c4_watch01", false);
			bomb_on_ground_particle->SetEnable(true);
		}
	}

	void Level::UpdateOccluderPlane()
	{
		Matrix44 view,proj,viewproj;

		PROFILE("Level::UpdateOccluderPlane");

		for ( uint i = 0; i < occluderplanes.Size(); i++ )
		{
			occluderplanes[i].UpdateTransform(gGame->camera->viewprojMatrix, gGame->camera->frustum.GetFrustumPlane(FRUSTUM_PLANE_NEAR), false);
		}
	}

	void Level::UpdateDeadZone()
	{
		Vector3 pos = player_manager->player->GetPosition();
		/*PROFILE("Level::UpdateDeadZone");
		{
			if(!use_octee_deadzoon)
			{	
				for (uint i = 0; i < check_dead_zone.Size(); i++)
				{
					const AxisAlignedBox& aabb = check_dead_zone.GetAt(i);
					if(aabb.IsPointInside(pos))
					{
						if (gGame->channel_connection)
							gGame->channel_connection->Suicide();
						return;
					}
				}
			}
			else
			{
				is_in_DeadZoon = false;
				RecursiveSceneCheck(first_leaf,pos);

				if (is_in_DeadZoon && gGame->channel_connection)
					gGame->channel_connection->Suicide();
			}
		}*/
		
		if(check_dead_zone.Size())
		{	
			is_in_DeadZoon = false;
			RecursiveSceneCheck(first_leaf,pos);

			if (is_in_DeadZoon && gGame->channel_connection)
				gGame->channel_connection->Suicide();
		}
	}

	void Level::UpdateVisibleArea()
	{
		PROFILE("Level::UpdateVisibleArea");

		visible_meshs.Clear();

		if (!force_draw_all_visible)
		{
			const Core::Array<int>* visible_list;
			if (map_visible_tree->GetVisibleListByPosition(gGame->camera->position, visible_list))
			{
				uint size = visible_list->Size();
				for (uint i = 0; i < size; i++)
				{
					int mesh_id = (*visible_list)[i];
					LevelMesh *pMesh = map_meshs.Get(mesh_id);
					if (pMesh)
					{
						bool visible = true;

						// frustum culling
						visible = !AABB_IS_OUTSIDE(pMesh->aabb.TestIntersection(&gGame->camera->frustum, 0));

						if (visible)
						{
							if (!visible_meshs.Contains(pMesh->mesh))
								visible_meshs.Add(pMesh->mesh);
						}
					}
				}
				
			}
		}

		//fix for all mesh is invisible
		if (force_draw_all_visible || (visible_meshs.Size() == 0 && map_meshs.Size() > 0))
		{
			LevelMeshSet::Enumerator it(map_meshs);
			while (it.MoveNext())
			{
				if (!AABB_IS_OUTSIDE(it.Value().aabb.TestIntersection(&gGame->camera->frustum, 0)))
				{
					visible_meshs.Add(it.Value().mesh);
				}
			}
#ifdef _DEBUG
			//if (!force_draw_all_visible)
			//	LogSystem.WriteLinef("all map_mesh is invisible!!!");
#endif
		}

#if DEBUG_INFO
		if (show_visible_info)
		{
			LogSystem.WriteLinef("visible map_mesh : %f%%", (float)visible_meshs.Size() / (float)map_meshs.Size() * 100);

			//LogSystem.WriteLinef("visible_meshs.Size() : %d", visible_meshs.Size());
			//for (uint i = 0; i < visible_meshs.Size(); i++)
			//{
			//	LogSystem.WriteLinef("\tmesh_visible_area_array[%d] : %d", i, visible_meshs[i]);
			//}
		}
#endif
	}
	
	/// udpate
	void Level::Update(float frame_time)
	{
		PROFILE("Level::Update");

		////ENCODE_START
		if (!holdpoint_sound)
			holdpoint_sound = FmodSystem::GetEvent("bj/event/occupying");
		if (!vehicle_sound[0])
			vehicle_sound[0] = FmodSystem::GetEvent("bj/ambience/vehicle_move_red");
		if (!vehicle_sound[1])
			vehicle_sound[1] = FmodSystem::GetEvent("bj/ambience/vehicle_move_blue");
		if (!audio_bomb_Planting_Defusing)
			audio_bomb_Planting_Defusing = FmodSystem::GetEvent("bj/event/c4_progress");
		if (!mvp_sound)
			mvp_sound = FmodSystem::GetEvent("bj/event/be_mvp");
		if (!audio_bomb_2d_Plant)
		{
			audio_bomb_2d_Plant = FmodSystem::GetEvent("bj/weapon/2d/c4/plant_c4");
		}
		if (!zombie_state_two_muisc)
		{
			zombie_state_two_muisc = FmodSystem::GetEvent("bj/music/bio_bgm");
		}
		if (!boss_mode2_armor_warning)
		{
			boss_mode2_armor_warning = FmodSystem::GetEvent("bj/player/2d/armor_robot/armor_warning");
		}
		for (int i = 0;i<5;i++)
		{
			if (!audio_bomb_3d_Plant_Timer[i])
			{
				FMOD_VECTOR vel = {0, 0, 0};
				String str = String::Format("bj/ambience/c4_beep_0%d",i + 1);
				audio_bomb_3d_Plant_Timer[i] = FmodSystem::Play3DEvent(str.Str(),(const FMOD_VECTOR &)Vector3(0,0,0),vel);
				audio_bomb_3d_Plant_Timer[i]->stop();
			}
			else
			{
				break;
			}
		}
		if (state == kReady)
		{
			if(activeOC)
			{
				UpdateOccluderPlane();
			}

			//updata mesh_visible_array
			UpdateVisibleArea();

			if (!player_manager)
				return;

			gGame->render->render_pipeline->m_bIsGrayScreen = false;

			// update viewer id
			switch (gGame->camera->control_mode)
			{
			case Camera::kCharacterControl:
				{
					tempc_ptr(Character) player = GetPlayer();
					if (player)
					{
						if (player->uid != player_manager->viewer_id)
						{
							tempc_ptr(Character) character = GetCharacter(player_manager->viewer_id);

							if (character)
								character->SetViewMode(Character::kThirdPerson);

							player_manager->viewer_id = player->uid;
						}
					}
					else
						player_manager->viewer_id = 0;
				}
				break;

			case Camera::kViewMode:
				if (player_manager->viewer_id == 0)
					player_manager->ViewModeToNext();
				break;

			default:
				player_manager->viewer_id = 0;
				break;
			}

			switch(game_type)
			{
			case RoomOption::kBombMode:
				{
					if(bomb_on_ground)
					{
						if(!bomb_on_ground_particle)
						{
							CreateBombGroundParticle();
						}
						if(bomb_on_ground_particle)
						{
							bomb_on_ground_particle->SetPosition(bomb_on_ground_position);
							bomb_on_ground_particle->SetRotation(bomb_on_ground_rotation);
							bomb_on_ground_particle->Update(frame_time);

						}

						if(bomb_special_mesh)
						{
							bomb_special_mesh->SetPosition(bomb_on_ground_position);
							bomb_special_mesh->SetRotation(bomb_on_ground_rotation);
						}

						bomb_explode_timer -= frame_time;

					}


					if( !bomb_exploded && bomb_defuse_timer > 0.f && bomb_defusing)
					{
						bomb_defuse_timer -= frame_time;
					}

					{
						tempc_ptr(Character) viewer = GetViewer();
						if(viewer)
						{
							if(viewer->GetBomb(true))
							{
								bool bomb_planting = viewer->GetBomb(true)->bomb_planting;
								if( bomb_planting && viewer->bomb_plant_timer > 0.f)
									viewer->bomb_plant_timer -= frame_time;
							}

						}
					}
				}
				break;
			case RoomOption::kZombieMode:
				{
					if (activeHaveTime > 0)
					{
						activeHaveTime -= frame_time;
					}
					else if (activeHaveTime > -1)
					{
						isCanActiveGate = true;
					}
					

					if(zombie_state_two_flag && step_two_sound_timer > 0.f)
					{
						step_two_sound_timer -= frame_time;
						if(step_two_sound_timer <= 0.f)
						{
							FMOD::Event* audio_event = NULL;
							Identifier key;
							
							tempc_ptr(Character) c = GetPlayer();

							if(c)
							{
								key = c->GetTeam() == 0 ? step_two_human_sound : step_two_zombie_sound;
								
								if(key.Length() != 0)
								{
									audio_event = FmodSystem::GetEvent(key);

									if (audio_event)
									{
										audio_event->start();
									}
								}
							}
							
						}
					}
				}
				break;
			case RoomOption::kSurvivalMode:
				{
					for(uint i = 0 ; i < gLevel->pickup_manager->pick_up_set.Size(); i ++)
					{
						sharedc_ptr(PickUpManager::PickUpObject) Object = gLevel->pickup_manager->pick_up_set[i];
						if (Object->SType == PickUpManager::kSupplySurvivalItemGhostFire)
						{
							tempc_ptr(Character) c = GetPlayer();
							if(c->isghost)
							{
								Object->particle->SetEnable(true);
							}
							else
							{
								Object->particle->SetEnable(false);
							}
						}
					}
				}
				break;
			}

			// update character
			if (character_manager)
				character_manager->Update(frame_time);

			// update player
			player_manager->Update(frame_time);

			//update pickup manager
			pickup_manager->Update(frame_time);

			if( player_manager->player && !player_manager->player->IsDied())
			{
				check_dead_timer -= frame_time;

				if( check_dead_timer < 0.f )
				{
					UpdateDeadZone();	
					check_dead_timer = CHECK_DEAD_ZONE_INTERVAL;
				}
			}

			//update viewer for first person
			tempc_ptr(Character) viewer = GetViewer();
			if (viewer)
			{
				tempc_ptr(WeaponBase) weapon = viewer->GetWeapon();
				if(viewer != GetPlayer())
				{
					if (weapon && weapon->GetWeaponType() == kWeaponTypeCureGun)
					{
						weapon->UpdateViewerAnimation(frame_time);
					}
				}
				if (weapon && weapon->GetWeaponType() == kWeaponTypeMiniMachineGun)
				{
					weapon->UpdateViewerAnimation(frame_time);
				}
			}
			
			// update Ammo
			Core::Array<U16> dead_arry;
			Core::HashSet<U8, sharedc_ptr(AmmoSet)>::Enumerator itor(character_ammoset);
			while(itor.MoveNext())
			{
				dead_arry.Clear();

				AmmoSet::Enumerator ammoitor(*itor.Value());
				while (ammoitor.MoveNext())
				{
					tempc_ptr(AmmoBase) ammo = ammoitor.Value();
					if(ammo)
					{
						ammo->UpdatePhysx(frame_time);
						ammo->Update(frame_time);
						if (ammo->is_dead && !ammo->HasSyncData())
						{
							AmmoOnDead(ammo,ammoitor.Key());
							dead_arry.Add(ammoitor.Key());
						}
						else
						{
							ammo->UpdateMesh();
						}
					}
				}

				sharedc_ptr(AmmoSet) ammo_set = itor.Value();
				for (U32 index = 0; index < dead_arry.Size(); index++)
				{
					ammo_set->Remove(dead_arry[index]);
				}
			}

			if(player_manager->currentAmmo && player_manager->currentAmmo->is_dead && player_manager->currentAmmo->type == kWeaponTypeAmmoRocket)
			{
				player_manager->currentAmmo = NullPtr;
			}
			
			// 
			tempc_ptr(Character) c = gLevel->GetPlayer();

			if (game_type != RoomOption::kNovice)
			{
				// update Gate
				for (uint i = 0; i < gate_array.Size(); ++i)
				{
					gate_array[i]->Update(frame_time);
				}
			}
			else
			{
				if (novice_index >= 6)
				{
					for (uint i = 0; i < gate_array.Size(); ++i)
					{
						if (gate_array[i]->gate_info->id == 0 || gate_array[i]->gate_info->id == 1)
						{
							gate_array[i]->Update(frame_time);
						}
					}
				}
				
				tempc_ptr(Character) tempplayer = GetPlayer();
				if (tempplayer && tempplayer->GetCurCharinfo())
				{
					for (uint i = 0; i < novice_guntarget_array.Size();++i)
					{
						if (novice_index < 20 && novice_guntarget_array[i]->guntarget_info->uid == tempplayer->character_info->career_id)
						{
							if ((novice_index == 10 || novice_index == 11) && novice_guntarget_array[i]->GetID() == 0)
							{
								novice_guntarget_array[i]->Update(frame_time);
							}
							else if ((novice_index == 13 || novice_index == 14) && novice_guntarget_array[i]->GetID() == 1)
							{
								novice_guntarget_array[i]->Update(frame_time);
							}
							else if ((novice_index == 15 || novice_index == 16) && novice_guntarget_array[i]->GetID() == 2)
							{
								novice_guntarget_array[i]->Update(frame_time);
							}
							else if ((novice_index == 17 || novice_index == 18) && novice_guntarget_array[i]->GetID() == 3)
							{
								novice_guntarget_array[i]->Update(frame_time);
							}
						}
						else
						{
							if ((novice_index == 20 ||novice_index == 21) && novice_guntarget_array[i]->GetID() == 100)
							{
								novice_guntarget_array[i]->Update(frame_time);
							}
							else if ((novice_index == 22 ||novice_index == 23) && novice_guntarget_array[i]->GetID() == 200)
							{
								novice_guntarget_array[i]->Update(frame_time);
							}
						}
					}
				}
			}

			for (uint i = 0; i < active_object_array.Size(); ++i)
			{
				active_object_array[i]->Update(frame_time);
			}
			
			for (uint i = 0; i < detachablepart_array.Size(); ++i)
			{
				detachablepart_array[i]->Update(frame_time);
				if (detachablepart_array[i]->IsDied())
				{
					detachablepart_array.RemoveAt(i);
					--i;
				}
			}

			for (uint i = 0; i < anim_object_array.Size(); ++i)
			{
				anim_object_array[i]->Update(frame_time);
			}

			player_manager->need_gun_tower_ammo = false;
			HashSet<uint, sharedc_ptr(DummyObject)>::Enumerator it(dummy_object_set);
			Array<uint> dead_array;
			while (it.MoveNext())
			{
				tempc_ptr(DummyObject) dummy_obj = it.Value();
				dummy_obj->Update(frame_time);
				
				if(dummy_obj->type == DummyObject::DUMMY_MACHINE_TURRENT)
				{
					tempc_ptr(MachineGunTurret) t = ptr_dynamic_cast<MachineGunTurret>(dummy_obj);
					tempc_ptr(Character) c = GetCharacter(dummy_obj->owner_id);
					if(t && c)
					{
						c->tower_gun_percent = (float)t->GetAmmoCount() / (float)t->turret_info.max_ammo_count;
						if(!t->AmmoIsFull() && c->uid == player_manager->player->uid)
						{
							player_manager->need_gun_tower_ammo = true;
						}
					}
				}

				if(dummy_obj->IsDead())
				{
					dead_array.Add(it.Key());
				}
			}
			if (player_manager->player)
			{
				tempc_ptr(GunTowerBuilder) w = ptr_dynamic_cast<GunTowerBuilder> (player_manager->player->GetWeaponById(0));
				if (w && w->GetAmmoCount() != -1)
				{	
					if (w->GetAmmoCount() < w->GetMaxAmmoCount())
						player_manager->need_gun_tower_ammo = true;
					
					if (!(player_manager->player->tower_gun_count) && w->GetMaxAmmoCount() != 0)
					{
						player_manager->player->tower_gun_percent = (float)w->GetAmmoCount() / (float)w->GetMaxAmmoCount();
					}
				}
			}

			for (uint i = 0; i < dead_array.Size();i++)
			{
				dummy_object_set.Remove(dead_array[i]);
			}

			if (gGame->channel_connection)
				gGame->channel_connection->DummyObjectSyncUpdate();
	
			// update bullets
			if (bullet_manager)
				bullet_manager->Update(frame_time);

			// update particle
			UpdateParticle(frame_time);

			if (somg_particle_set.Size() > 0)
			{
				HashSet<uint, sharedc_ptr(ParticleSystem)>::Enumerator itr(somg_particle_set);
				while (itr.MoveNext())
				{
					tempc_ptr(ParticleSystem) particle = itr.Value();
					if (particle)
					{
						particle->Update(frame_time); 
					}
				}
			}

			for (uint i = 0; i < gLevel->trap_info.Size(); i++)
			{
				if (gLevel->trap_info[i].time > 0)
				{
					gLevel->trap_info[i].time -= frame_time;
					if (gLevel->trap_info[i].time > 0)
					{
						if (gLevel->trap_info[i].ps)
						{
							gLevel->trap_info[i].ps->Update(frame_time);
							gLevel->trap_info[i].ps->SetEnable(true);
						}
					}
					else
					{
						gLevel->trap_info[i].ps->SetEnable(false);
					}
				}

			}
			

			// update light
			light_manager->Update(frame_time);

			// update holdpoint_rot
			Quaternion rot(Vector3(0, 1, 0), holdpoint_rotspeed * frame_time);
			holdpoint_rot *= rot;

			// spirit ball
			for (uint i = 0; i < spiritball_array.Size(); ++i)
			{
				tempc_ptr(SpiritBall) spiritball = spiritball_array[i];

				spiritball->Update(frame_time);
				if (spiritball->GetDead())
				{
					spiritball_array.RemoveAt(i);
					--i;
				}
			}
			
			if (spiritball_array.Size() > 0 && GetPlayer())
			{
				if (Core::Length(spiritball_array[0]->GetPosition() - GetPlayer()->GetPosition()) < 20.f)
				{
					if (spiriteball_fly_sound)
					{
						FMOD_EVENT_STATE audio_state = FMOD_EVENT_DEFAULT;
						spiriteball_fly_sound->getState(&audio_state);
						if ((audio_state & FMOD_EVENT_STATE_PLAYING) == 0)
						{
							FMOD_VECTOR vel = {0, 0, 0};
							spiriteball_fly_sound->set3DAttributes(&(const FMOD_VECTOR &)spiritball_array[0]->GetPosition(), &vel);
							spiriteball_fly_sound->start();
						}
						else
						{
							FMOD_VECTOR vel = {0, 0, 0};
							FmodSystem::Update3DEventPosition(spiriteball_fly_sound, (const FMOD_VECTOR &)spiritball_array[0]->GetPosition(), vel);
						}
					}
					else
					{
						spiriteball_fly_sound = FmodSystem::GetEvent("bj/fx/3d/energyball_fly");
					}
				}
				else
				{
					if (spiriteball_fly_sound)
						spiriteball_fly_sound->stop();
				}
			}
			else
			{
				if (spiriteball_fly_sound)
					spiriteball_fly_sound->stop();
			}

		

			// update mesh
			for (U32 i = 0; i < grenade_array.Size(); i++)
			{
				if (grenade_array[i] && grenade_array[i])
					grenade_array[i]->UpdateMesh();
			}

			if (gLevel->round_end_wait_time > 0)
			{
				gLevel->round_end_wait_time -= frame_time;
				if(gLevel->round_end_wait_time < 0.0f)
					gLevel->round_end_wait_time = 0.0f;
			}

			if (round_start_wait_time > 0)
			{
				round_start_wait_time -= frame_time;
				if(round_start_wait_time < 0.0f)
				{	
					round_start_wait_time = 0.0f;
				}
			}
			
			if (game_type == RoomOption::kZombieMode && gGame->round_time <= 30 && zombie_human_down_sound)
			{
				if (GetPlayer()->GetTeam() == 0)
				{
					FmodSystem::PlayEvent("bj/event/bio/bio_lastchance");
				}
				zombie_human_down_sound = false;
			}
		}
		// update particle
		particle_manager->Update(frame_time);

		// update decal
		decal_manager->Update(frame_time);

		if(vehicle[0] && vehicle[1])
		{
			vehicle[0]->Update(frame_time);
			vehicle[1]->Update(frame_time);
		}

		if (showhorn)
		{
			if(horntime > 0.001f)
			{
				horntime -= frame_time;
			}
			else
			{
				showhorn = false;
				horntime = 10.0f;
			}
		}
  
		if (kick_select_open)
		{
			kick_wait_time -= frame_time;
			if(kick_wait_time <= 0.0f)
			{
				kick_wait_time = 0.0f;
				kick_select_open = false;
			}
		}

		tempc_ptr(Character) player = GetPlayer();
		if (player)
		{

			/*InGameInfoCollection& collection = g_InGameInfo_collection;
			collection.ping_timer += frame_time;

			if(collection.ping_timer >= 5.f)
			{
				ushort ping = player->ping;
				collection.ping_timer = 0.f;
				collection.average_ping_array.PushBack(player->ping);

				if(ping < collection.low_ping)
				{
					collection.low_ping = ping;
				}

				if(ping > collection.high_ping )
				{
					collection.high_ping = ping;
				}
			}*/

			if(player->zombie_dying_flag && game_type == RoomOption::kZombieMode)
			{
				gGame->render->render_pipeline->m_bIsGrayScreen = true;
			}
			
			for (int i = 0; i < 9;++i)
			{
				WeaponBase* weapon = ptr_dynamic_cast<WeaponBase>(player->GetWeaponById(i));
				if(weapon)
				{
					if(weapon->idle_time > 0)
					{
						weapon->idle_time -= frame_time;
						weapon->cdscale = weapon->idle_time/weapon->weapon_info->time_to_idle;
						weapon->cdscale = Clamp(weapon->cdscale,0.f,1.f);
					}
					if(weapon->weapon_info->weapon_type == kWeaponTypeGrenade || weapon->weapon_info->weapon_type == kWeaponTypeFlash || weapon->GetWeaponType() == kWeaponTypeSpecial)
					{
						tempc_ptr(Grenade) grenade = ptr_dynamic_cast<Grenade>(weapon);
						weapon->cdscale = (player->grenade_cd_time) / grenade->grenade_info->time_to_idle;
						weapon->cdscale = Clamp(weapon->cdscale,0.f,1.f);
					}
					else if(weapon->GetWeaponType() == kWeaponTypeDrum)
					{
						tempc_ptr(Drum) drum = ptr_dynamic_cast<Drum>(weapon);

						weapon->cdscale = Clamp((drum->drum_info->damage-player->accumulate_damage)/(float)drum->drum_info->damage, 0.f, 1.f) ;
					}
					else if (weapon->GetWeaponType() == kWeaponTypeZombieGun)
					{
						tempc_ptr(ZombieGun) zb_gun = ptr_dynamic_cast<ZombieGun>(weapon);
						weapon->cdscale = 1 - (player->zombiegun_cd_time / zb_gun->knife_info->skill_cooldown);
						weapon->cdscale = Clamp(weapon->cdscale,0.f,1.f);
					}
					else if (weapon->GetWeaponType() == kWeaponTypeZombieCharge)
					{
						tempc_ptr(ZombieCharge) zbc_gun = ptr_dynamic_cast<ZombieCharge>(weapon);
						weapon->cdscale = player->zombiecharge_cd_time / zbc_gun->charge_info->skill_cooldown;
						weapon->cdscale = Clamp(weapon->cdscale,0.f,1.f);
					}
				}
			}
		}

		if (novice_isdraw)
		{
			if (novice_particle && !novice_particle->m_LinkNode.GetList())
				particle_manager->AddParticle(novice_particle);
			if (novice_particle)
			{
				novice_particle->SetPosition(novice_index_pos);
				novice_particle->SetEnable(true);
			}
		}
		else
		{
			if (novice_particle)
				novice_particle->SetEnable(false);
		}

       

		

		if ( isneedparticle && gold_pos_num > 0 && gold_pos_num == gold_vectors.Size())
		{
			if (launch_time > 0)
			{
				launch_time -= frame_time;
			}
			else
			{
				sharedc_ptr(GoldParticle) gold = ptr_new GoldParticle;
				Core::String name = Core::String::Format("fireworks_02");
				gold->particle_trail = ptr_new ParticleSystem(name);
				gold->particle_trail->SetEnable(false);
				int temp = rand()%3+1;
				name = Core::String::Format("fireworks_kind0%d",temp);
				
				
				gold->particle_kind = ptr_new ParticleSystem(name);
				gold->particle_kind->SetEnable(false);

				int r = rand()%gold_pos_num;
				gold->downPos = Vector3(gold_vectors[r].x,gold_vectors[r].y,gold_vectors[r].z);
				float pos_y = gold_vectors[r].y+(11+rand()%10);
				gold->upPos = Vector3(gold_vectors[r].x,pos_y,gold_vectors[r].z);

				gold->particle_kind->SetPosition(gold->upPos);
				particle_manager->AddParticle(gold->particle_trail);
				particle_manager->AddParticle(gold->particle_kind);
				gold->firework = FmodSystem::GetEvent("bj/fx/3d/firework");
				if (gold->firework)
				{
					FMOD_VECTOR vel = {0, 0, 0};
					gold->firework->set3DAttributes(&(const FMOD_VECTOR &)gold->downPos, &vel);
					gold->firework->start();
				}
				gold_particles.PushBack(gold);
				launch_time = 3.0f;
			}
            

			fly_time += frame_time*5;
			fly_time = fly_time > 3600 ? 0 : fly_time;
			for (int i = 0; i < (int)gold_particles.Size(); ++i)
			{
				if (gold_particles[i] && gold_particles[i]->particle_trail && gold_particles[i]->particle_kind)
				{
					if (gold_particles[i]->downPos.y < gold_particles[i]->upPos.y)
					{
						gold_particles[i]->particle_kind->SetEnable(false);
						gold_particles[i]->particle_trail->SetEnable(true);
						float x = gold_particles[i]->downPos.x + 0.15*Core::Sin(fly_time);
						float z = gold_particles[i]->downPos.z - 0.15*Core::Sin(fly_time);
						gold_particles[i]->downPos.y += 10 * frame_time;
						gold_particles[i]->particle_trail->SetPosition(Vector3(x,gold_particles[i]->downPos.y,z));
						if (gold_particles[i]->firework)
						{
							FMOD_VECTOR vel = {0, 0, 0};
							FmodSystem::Update3DEventPosition(gold_particles[i]->firework, (const FMOD_VECTOR &)gold_particles[i]->downPos, vel);
						}
					}
					else
					{
						if (gold_particles[i]->show_time > 0)
						{
							gold_particles[i]->particle_trail->SetEnable(false);
							gold_particles[i]->particle_kind->SetEnable(true);
							gold_particles[i]->show_time -= frame_time;
						}
						else
						{
							gold_particles[i]->particle_trail->SetEnable(false);
							gold_particles[i]->particle_kind->SetEnable(false);
							particle_manager->RemoveParticle(gold_particles[i]->particle_trail);
							particle_manager->RemoveParticle(gold_particles[i]->particle_kind);
						}
					}
				}
			}
		}


		if (  game_type == RoomOption::kAdvenceMode )
		{
			if (launch_Time > 0)
			{
				launch_Time -= frame_time; 
			}
			if ( Launch_Time > 0 )
			{
				Launch_Time -= frame_time ; 
			}
			if ( f == true )
			{
				gLevel->firework_vectors.Clear();
				gLevel->firework_particles.Clear();
				f = false;
			}
			sharedc_ptr(Fireworks) fireworks = ptr_new Fireworks;
			Core::String name1 = Core::String::Format("fireworks_trail");
			fireworks->particle_Trail = ptr_new ParticleSystem(name1);
			fireworks->particle_Trail->SetEnable(false);
			int temp1 =rand()%1+4;
			name1 = Core::String::Format("fireworks_kind0%d",temp1);
			fireworks->particle_Kind = ptr_new ParticleSystem(name1);
			fireworks->particle_Kind->SetEnable(false);
			if ( launch_Time <= 0 )
			{
				int ra = rand()%11; 
				fireworks->DownPos = Vector3(firework_vectors[ra].x,firework_vectors[ra].y,firework_vectors[ra].z);
				float pos_y1 = firework_vectors[ra].y+(60+rand()%10);
				fireworks->UpPos = Vector3(firework_vectors[ra].x,pos_y1,firework_vectors[ra].z);
				fireworks->particle_Kind->SetPosition(fireworks->UpPos);
				particle_manager->AddParticle(fireworks->particle_Trail);
				particle_manager->AddParticle(fireworks->particle_Kind);
				fireworks->Firework = FmodSystem::GetEvent("bj/fx/3d/fireworks");
				if ( Launch_Time <= 0 )
				{
					if ( fireworks->Firework )
					{
						FMOD_VECTOR vel = {0, 0, 0};
						fireworks->Firework->set3DAttributes(&(const FMOD_VECTOR &)fireworks->DownPos, &vel);
						fireworks->Firework->start();
					}
					float a = rand()%3+4; 
					Launch_Time = a;
				}
				firework_particles.PushBack(fireworks);
				launch_Time = 1.0f;
			}
		}
		fly_Time += fly_Time*5;
		fly_Time = fly_Time > 3600 ? 0 : fly_Time;
		for (uint i = 0; i < firework_particles.Size(); ++i)
		{
 			if (firework_particles[i] && firework_particles[i]->particle_Trail && firework_particles[i]->particle_Kind)
 			{
 				if(firework_particles[i]->DownPos.y < firework_particles[i]->UpPos.y)
				{
				    firework_particles[i]->particle_Kind->SetEnable(false);
					firework_particles[i]->particle_Trail->SetEnable(true);
					float x = firework_particles[i]->DownPos.x + 0.15*Core::Sin(fly_Time);
					float z = firework_particles[i]->DownPos.z - 0.15*Core::Sin(fly_Time);
					firework_particles[i]->DownPos.y += 65 * frame_time;
				    firework_particles[i]->particle_Trail->SetPosition(Vector3(x,firework_particles[i]->DownPos.y,z));
					if (firework_particles[i]->Firework)
					{
						FMOD_VECTOR vel = {0, 0, 0};
						FmodSystem::Update3DEventPosition(firework_particles[i]->Firework, (const FMOD_VECTOR &)firework_particles[i]->DownPos, vel);
					}
				}
				else
 				{
					if (firework_particles[i]->show_Time > 0)
					{
						firework_particles[i]->particle_Trail->SetEnable(false);
						firework_particles[i]->particle_Kind->SetEnable(true);
						firework_particles[i]->show_Time -= frame_time;
					}
					else
					{
						firework_particles[i]->particle_Trail->SetEnable(false);
						firework_particles[i]->particle_Kind->SetEnable(false);
						particle_manager->RemoveParticle(firework_particles[i]->particle_Trail);
						particle_manager->RemoveParticle(firework_particles[i]->particle_Kind);
					}
				}
			}
		}

		tmpplayer = NullPtr;

		if (game_type == RoomOption::kNovice)
		{
			if (novice_timer > 0.f)
			{
				novice_timer -= frame_time;
			}
			else
			{
				if (novice_need_timer)
				{
					novice_index++;
					novice_timer = 8.f;
					novice_need_timer = false;

					switch(novice_index)
					{
					case 2:		//�ƶ������ʾ
						{
							novice_timer = 5.f;
							novice_need_timer = true;
						}
						break;
					case 3:		//WASD��ʾ
					case 9:		//1234�͹���
						{
							tempc_ptr(StateMainGame) state_main = ptr_dynamic_cast<StateMainGame>(gGame->machine.CurrentState());
							if (state_main)
							{
								state_main->ui->input_timer = Task::GetTotalTime();
							}
							
							novice_timer = 0.f;
							novice_need_timer = false;
						}
						break;
					case 12:
						{
							novice_timer = 5.f;
							novice_need_timer = true;
						}
						break;
					case 13:	//�ƶ���ѵ��
						{
							novice_timer = 0.f;
							novice_need_timer = false;
							novice_shoot_num = 1;
						}
						break;
					case 15:	//���������
						{
							novice_timer = 0.f;
							novice_need_timer = false;
							novice_shoot_num = 3;
						}
						break;
					case 17:	//��ս����
						{
							novice_timer = 0.f;
							novice_need_timer = false;
							novice_shoot_num = 1;
						}
						break;
					case 24:
						{
							if (gGame->channel_connection)
							{
								gGame->channel_connection->NoviceOperation(24);
								gGame->channel_connection->LeaveGame(ChannelConnection::kLeaveGameReasonSuccessNovice);
							}
							novice_index++;
							novice_timer = 0.f;
							novice_need_timer = false;
						}
						break;
					default:
						break;
					}
				}
			}
		}

		if(gGame->channel_connection && gGame->channel_connection->GetState() == ChannelConnection::kInReplay)
		{
			UpdateReplayUI();
		}
	}

	void Level::AddHorn(const Core::String& str)
	{
		showhorn = true;
		horntime = 10.f;
		if(horn_array.Size() < 4)
		{
			horn_array.PushBack(str);
		}
		else
		{
			horn_array.PopFront();
			horn_array.PushBack(str);
		}
	}

	// blacklist add
	void  Level::BlacklistAdd(uint uid,const Core::String& str)
	{
		Blacklist m;
		m.Id = uid;
		m.name = str;
		m_Blacklist.Add(m);
	}

	// blacklist clear
	void  Level::BlacklistClear()
	{
		m_Blacklist.Clear();
	}

	/// on timestepupdate
	void Level::TimeStepUpdate(float frame_time)
	{
		PROFILE("Level::TimeStepUpdate");

		////ENCODE_START

		if (state == kReady)
		{
			if (!player_manager)
				return;

			// update character
			if (character_manager)
				character_manager->TimeStepUpdate(frame_time);

			// update player
			player_manager->TimeStepUpdate(frame_time);

			if (level_eventmgr)
				level_eventmgr->TimeStepUpdate(frame_time);

			// update grenade
			{
				for (uint i = 0; i < grenade_array.Size(); ++i)
				{
					tempc_ptr(Grenade) grenade = grenade_array[i];
					if (grenade->grenade_trail_particle)
						grenade->grenade_trail_particle->SetPosition(grenade->GetPosition());
					tempc_ptr(Character) player = GetPlayer();

					if (grenade && player)
					{
						grenade->UpdatePhysx(frame_time);
						grenade->timer -= frame_time;

						if (grenade->timer < 0 || grenade->canOperation)
						{
							gLevel->GrenadeExplode(grenade);

							switch (grenade->type)
							{
							case kWeaponTypeGrenade:
								{
									if (player_manager && player)
									{
										float distance = Length(grenade->GetPosition() - player->GetPosition());
										// remove check grende, explode will through wall.
										tempc_ptr(GrenadeInfo) grenade_info = ptr_dynamic_cast<GrenadeInfo>(grenade->grenade_info);
										if (grenade_info && distance <= grenade_info->range)
											gGame->channel_connection->GrenadeHurt(grenade->uid, grenade);

										if (Length(grenade->GetPosition() - player->GetPosition()) < 15.f)
											player->OnGrenadeExplode();

										HashSet<uint, sharedc_ptr(DummyObject)>::Enumerator it(gLevel->dummy_object_set);

										while (it.MoveNext())
										{
											tempc_ptr(DummyObject) t = it.Value();
											{
												if(t->owner_id == player->uid)
												{
													float dummy_distance = Length(grenade->GetPosition() - t->GetPosition());
													if (grenade_info && dummy_distance <= grenade_info->range)
													{
														gGame->channel_connection->GrenadeHurtDummy(t->dummyobjectinfo->dummy_id, t->GetPosition(), grenade);
													}
												}
											}
										}

									}

									
								}
								break;

							case kWeaponTypeSpecial:
								{
									if (player_manager && player)
									{
										tempc_ptr(Character) owner = grenade->GetOwner();
										float distance = Length(grenade->GetPosition() - player->GetPosition());
										tempc_ptr(SpecialGrenadeInfo) grenade_info = ptr_dynamic_cast<SpecialGrenadeInfo>(grenade->grenade_info);
										if (grenade_info && distance <= grenade_info->range && player->GetTeam() != grenade->team)
											gGame->channel_connection->GrenadeHurt(grenade->uid, grenade);

										HashSet<uint, sharedc_ptr(DummyObject)>::Enumerator it(gLevel->dummy_object_set);

										while (it.MoveNext())
										{
											tempc_ptr(DummyObject) t = it.Value();
											{
												if(t->owner_id == player->uid)
												{
													float dummy_distance = Length(grenade->GetPosition() - t->GetPosition());
													if (grenade_info && dummy_distance <= grenade_info->range)
													{
														gGame->channel_connection->GrenadeHurtDummy(t->dummyobjectinfo->dummy_id, t->GetPosition(), grenade);
													}
												}
											}
										}
									}
								}
								break;

							case kWeaponTypeFlash:
								{
									float distance = 0.f;
									bool back_bright = false;

									if (player_manager && player && player->CheckFlash(grenade->GetPosition(), distance, back_bright))
									{
										tempc_ptr(FlashInfo) flash_info = ptr_static_cast<FlashInfo>(grenade->grenade_info);

										if (flash_info)
										{
											flash_info->time_max = 4.f;
											flash_info->range_end = 18.f;
											flash_info->range_start = 5.f;

											// calculate flash time
											float s = Max(Min((distance - flash_info->range_start) / (flash_info->range_end - flash_info->range_start), 1.f), 0.f);
											float s2 = s * s;
											float s3 = s2 * s;
											float h00 =  2 * s3 - 3 * s2 + 1;

											float time = flash_info->time_max * h00;

											if (back_bright)
												time *= flash_info->back_factor;

											if (time > 0)
												gGame->channel_connection->FlashBright(time, flash_info->time_fade);
										}
									}

									flash_light = 10.f;
									light_position = grenade->GetPosition();
								}
								break;

							default:
								break;
							}

							grenade_array.RemoveAt(i);
							--i;
						}
					}
				}

				tempc_ptr(Character) viewer = GetViewer();
				if (viewer)
				{
					flash_bright = viewer->flash_bright_time / (viewer->flash_fade_time > 0? viewer->flash_fade_time: 2.f);

					gRender->render_pipeline->SetBright(flash_bright);
				}

				gRender->render_pipeline->SetLight(light_position, Color3::kWhite * flash_light);

				if (flash_light > 0)
					flash_light -= frame_time * 10.f * 60;

				if (flash_light < 0)
					flash_light = 0.f;
			}

			//update ammo
			{
				tempc_ptr(Character) player = GetPlayer();

				Core::HashSet<U8, sharedc_ptr(AmmoSet)>::Enumerator itor(character_ammoset);
				while(itor.MoveNext())
				{
					if (!player || player->uid != itor.Key())
					{
						AmmoSet::Enumerator ammoitor(*itor.Value());
						while (ammoitor.MoveNext())
						{
							tempc_ptr(AmmoBase) ammo = ammoitor.Value();
							if (ammo)
							{
								ammo->UpdateSyncData(frame_time);
								ammo->TimeStepUpdate(frame_time);
							}
						}
					}
					else
					{
						AmmoSet::Enumerator ammoitor(*itor.Value());
						while (ammoitor.MoveNext())
						{
							tempc_ptr(AmmoBase) ammo = ammoitor.Value();
							if (ammo)
							{
								ammo->TimeStepUpdate(frame_time);
							}
						}
					}
				}
			}
		}

		////ENCODE_END
	}

	/// on render
	void Level::OnRender(float frame_time)
	{
		if (player_manager)
			player_manager->OnRender(frame_time);

		if (character_manager)
			character_manager->OnRender(frame_time);

		Core::HashSet<U8, sharedc_ptr(AmmoSet)>::Enumerator itor(character_ammoset);
		while(itor.MoveNext())
		{
			AmmoSet::Enumerator ammoitor(*itor.Value());
			while (ammoitor.MoveNext())
			{
				tempc_ptr(AmmoBase) ammo = ammoitor.Value();
				if(ammo)
				{
					ammo->OnRender(frame_time);
				}
			}
		}
	}

	/// initialize
	bool Level::Initialize()
	{
		/// load animation
		if (!animation_manager || !animation_manager->Load())
			return false;

		/// load particle
		//LoadParticle();

		/// load physx
		if (!physx_manager)
			return false;

		// player initialize
		if (!player_manager)
			return false;

		player_manager->Initialize();

		// character initialize
		if (!character_manager)
			return false;

		character_manager->Initialize();

		// initialzie bullet manager
		bullet_manager->Initialize();

		// initialzie bullet manager
		pickup_manager->Initialize();

		// initialzie level_eventmgr
		level_eventmgr->Initialize();

		CreateBombGroundParticle();

		if(gRender && gRender->render_pipeline)
		{
			gRender->render_pipeline->SetFogClamper(0.f);
		}

		return true;
	}

	/// reset
	void Level::Reset()
	{
		vehicle_started[0] = vehicle_started[1] = false;
		vehicle_half[0] = vehicle_half[1] = false;
		vehicle_almost_end[0] = vehicle_almost_end[1] = false;
	}

	/// load
	bool Level::Load()
	{
		state = kLoading;

		LoadSound();

		Resource::LoadAllRes(true);

		state = kReady;
		return true;
	}

	/// load sound
	bool Level::LoadSound()
	{
		if (!gGame)
			return false;

		return true;
	}

	/// load particle
	bool Level::LoadParticle(bool reload)
	{
		return true;
	}

	/// GC
	void Level::GC()
	{
		// resource gc 
		Resource::GC();
	}

	/// unload
	void Level::Unload()
	{
		anim_object_array.Clear();

		dummy_object_set.Clear();

		vehicle[0] = NullPtr;
		vehicle[1] = NullPtr;

		spray_set.Clear();

		// pick up terminate
		if (pickup_manager)
			pickup_manager->Terminate();

		// bullet terminate
		if (bullet_manager)
			bullet_manager->Terminate();

		// player terminate
		if (player_manager)
			player_manager->Terminate();

		// character terminate
		if (character_manager)
			character_manager->Terminate();

		if (zombie_state_two_muisc)
		{
			zombie_state_two_muisc->stop();
			zombie_state_two_muisc = NULL;
		}

		if (boss_mode2_armor_warning)
		{
			boss_mode2_armor_warning->stop();
			boss_mode2_armor_warning = NULL;
		}

		if (audio_bossmode2_background)
		{
			audio_bossmode2_background->stop(true);
			audio_bossmode2_background = NULL;
		}
		// remove all particle
		if (particle_manager)
			particle_manager->Clear();

		if (level_eventmgr)
			level_eventmgr->Terminate();

		// script
		script_set.Clear();

		spray_set.Clear();

		// grenade
		grenade_array.Clear();

		character_ammoset.Clear();
		
		const Core::Array<sharedc_ptr(Character)>& characters = gLevel->GetCharacters();

		occluderplanes.Clear();
		horn_array.Clear();
		machinegunturretarea.Clear();
		nomachinegunturretarea.Clear();
		showhorn = false;
		team_hurt = false;

		team_timer[0] = team_timer[1] = 0.f;
		cur_holdpoint_diffnum = 0;

		team_timer_warning[0] = team_timer_warning[1] = false;

		vehicle_started[0] = vehicle_started[1] = false;

		vehicle_half[0] = vehicle_half[1] = false;

		vehicle_almost_end[0] = vehicle_almost_end[1] = false;

		round_start_wait_time = 0;

		round_start_waiting = false;

		bomb_on_ground = false;

		// flash
		flash_bright = 0.f;
		flash_light = 0.f;

		level_weapon_set.Clear();
		level_weapon.Clear();

		disguise_info.part_set[0].Clear();
		disguise_info.part_set[1].Clear();
		disguise_info.mesh_set.Clear();

		/// unload animation
		if (animation_manager)
			animation_manager->Unload();

		UnloadMap();

		if (lua_state)
			lua_state->GC(Lua::GCCOLLECT, 0);

#if DEBUG_TOOLS
		debug_character = NullPtr;
#endif
	}

	/// load ma
	bool Level::LoadMap(const Identifier & n)
	{
		g_InGameInfo_collection.high_ping = 0;
		g_InGameInfo_collection.low_ping = 10000;
		g_InGameInfo_collection.average_ping_array.Clear();
		g_InGameInfo_collection.ping_timer = 0.f;

		check_dead_timer = CHECK_DEAD_ZONE_INTERVAL;

		bool result = false;

		gGame->global->SetGameRate(1.0f);
		gGame->global->SetGameStop(false);

		name = n;
		name1 = n;
		map_center = Vector2::kZero;
		map_size = Vector2(50, 50);

		ammoid_builder = 0;

		// initialize map
		map_visible_tree = ptr_new MapVisibleTree();

		holdpoint_mesh = ptr_new StaticMesh(MESH_KEY_PROP);

		bomb_special_mesh = ptr_new StaticMesh(MESH_KEY_PROP);

		bomb_special_mesh->AddPrimitive("weapon/c4/rv1_n_lod0.mesh",0);

		// clear occluders
		occluderplanes.Clear();
		machinegunturretarea.Clear();
		nomachinegunturretarea.Clear();
		particle_manager->Clear();
		level_particle_info.Clear();

		gGame->config->m_SensitivityRatio = "0.2,0.4,0.6,0.8,1,1.2,1.4,1.6,1.8,2,2.2,2.4,2.6,2.8,3,3.2,3.4,3.6,3.8,4";
		gGame->config->m_SensitivityRatio_Sniper = "0.2,0.4,0.6,0.8,1,1.2,1.4,1.6,1.8,2,2.2,2.4,2.6,2.8,3,3.2,3.4,3.6,3.8,4";

#if DEBUG_INFO
		debug_occluedr_rect.Clear();
		debug_dead_zone_rect.Clear();
		
#endif

		// do level scripts
		{
			CStrBuf<256> filename;
			filename.format("/level/%s_script.lua", n.Str());

			sharedc_ptr(ScriptLua) lua = RESOURCE_LOAD(filename, false, ScriptLua);

			if (lua)
			{
				Lua::LuaState *L = Lua::LuaState::NewState();
				if (L->LoadBuffer(lua->GetBuffer(), lua->GetSize(), filename) == 0)
				{
					L->NewTable();
					L->PushPtr(ptr_new LevelLoader(this));
					L->SetField(-2, "level");

					L->PushPtr(PDE_TYPE_OF(Vector3)->GetConstructor());
					L->SetField(-2, "Vector3");
					L->PushPtr(PDE_TYPE_OF(Vector4)->GetConstructor());
					L->SetField(-2, "Vector4");
					L->SetFenv(-2);
					if (L->DoCall(0, 0))
					{
						const char *msg = L->ToString(-1);
						if (msg) Console.WriteLine(msg);
						L->Pop(1);
					}
					else
					{
						result = true;
					}

				}
				else
				{
					const char *msg = L->ToString(-1);
					if (msg) Console.WriteLine(msg);
					L->Pop(1);
				}
				L->Close();
			}

			BuildDeadZoneOctree();
		}

		//load supply mesh
		{
			hp_supply = ptr_new StaticMesh(MESH_KEY_PROP);
			hp_supply->AddPrimitive("medkit/Medkit.mesh", 0);
			bighp_supply = ptr_new StaticMesh(MESH_KEY_PROP);
			bighp_supply->AddPrimitive("bigmedkit/bigmedkit.mesh", 0);

			Ammo_supply = ptr_new StaticMesh(MESH_KEY_PROP);
			Ammo_supply->AddPrimitive("Ammopack/Ammopack.mesh", 0);
			bigammo_supply = ptr_new StaticMesh(MESH_KEY_PROP);
			bigammo_supply->AddPrimitive("bigammopack/bigammopack.mesh", 0);
   
			gold_supply = ptr_new StaticMesh(MESH_KEY_PROP);
			gold_supply->AddPrimitive("goldcoin/goldcoin.mesh", 0);

			zombie_hp = ptr_new StaticMesh(MESH_KEY_PROP);
			zombie_hp->AddPrimitive("medkitsmall/medkitsmall.mesh", 0);

			zombie_ammo = ptr_new StaticMesh(MESH_KEY_PROP);
			zombie_ammo->AddPrimitive("ammopacksmall/ammopacksmall.mesh",0);

			dropitem_supply = ptr_new StaticMesh(MESH_KEY_PROP);
			dropitem_supply->AddPrimitive("gunshipbox/gunshipbox.mesh", 0);

			commonzombie_supply = ptr_new StaticMesh(MESH_KEY_PROP);
			commonzombie_supply->AddPrimitive("supplybox/supplybox.mesh", 0);

			item_normal_supply = ptr_new StaticMesh(MESH_KEY_PROP);
			item_normal_supply->AddPrimitive("propbox/propbox02.mesh", 0);

			item_special_supply = ptr_new StaticMesh(MESH_KEY_PROP);
			item_special_supply->AddPrimitive("propbox/propbox01.mesh", 0);

			moon_win_supply = ptr_new StaticMesh(MESH_KEY_PROP);
			moon_win_supply->AddPrimitive("propbox/propbox01.mesh", 0);

			CCoin_supply = ptr_new StaticMesh(MESH_KEY_PROP);
			CCoin_supply->AddPrimitive("propbox/fc_money.mesh", 0);

			Medal_supply = ptr_new StaticMesh(MESH_KEY_PROP);
			Medal_supply->AddPrimitive("propbox/fc_medal.mesh", 0);

			Wrench_supply = ptr_new StaticMesh(MESH_KEY_PROP);
			Wrench_supply->AddPrimitive("propbox/fc_wrench.mesh", 0);

			RandomBox_supply = ptr_new StaticMesh(MESH_KEY_PROP);
			RandomBox_supply->AddPrimitive("propbox/propbox02.mesh", 0);

			Trap_supply = ptr_new StaticMesh(MESH_KEY_PROP);
			Trap_supply->AddPrimitive("trap/trap.mesh", 0);
		}

		for (int i = 0; i < (int)level_weapon_set.Size(); i++)
		{
			sharedc_ptr(WeaponBase) weapon = Character::CreateWeapon(level_weapon_set[i]);
			if (weapon)
			{
				weapon->is_for_player = false;
				weapon->Initialize();
				weapon->PreloadAnimation();
				level_weapon.PushBack(weapon);
			}

			weapon = Character::CreateWeapon(level_weapon_set[i]);
			if (weapon)
			{
				weapon->is_for_player = true;
				weapon->Initialize();
				weapon->PreloadAnimation();
				level_weapon.PushBack(weapon);
			}
		}

		// load die script
		CStrBuf<MAX_PATH> path("/character/die_effect");
		if (Path::IsDirectory(path))
		{
			Lua::LuaState * LuaState = Lua::LuaState::NewState();
			PdeItPath it;
			it.Reset(path, false);

			while(it.MoveNext())
			{
				if (it.IsDirectory())
					continue;

				CStrBuf<MAX_PATH> str(path.buff());
				str.contractf("/%s", it.Name().buff());
				str.remove_back(".cache");

				sharedc_ptr(ScriptLua) script = RESOURCE_LOAD(str, true, ScriptLua);
				if (script)
					script_set.Add(str, script);
			}
			LuaState->Close();
		}

		gGame->camera->FrameUpdate(NullPtr, 0.f);

		return result;
	}

	/// unload map
	void Level::UnloadMap()
	{
		/// unload physx
		if (physx_manager)
			physx_manager->Unload();

		grenade_array.Clear();
		character_ammoset.Clear();
		gate_array.Clear();
		active_object_array.Clear();
		spiritball_array.Clear();
		detachablepart_array.Clear();
		novice_guntarget_array.Clear();
		
		// terminate map
		map_meshs.Clear();
		visible_meshs.Clear();
		holdpoint_mesh = NullPtr;
		bomb_special_mesh = NullPtr;
	
		level_weapon.Clear();

		hold_point_fPersert_red = 0.f;
		hold_point_fPersert_blue = 0.f;

		mesh_manual_info_array.Clear();

		check_dead_zone.Clear();

		bomb_plant_aabb.Clear();

		bomb_plant_position_array.Clear();

		check_dead_timer = -1.f;

		bomb_on_ground_particle = NullPtr;

		bomb_on_ground = false;
#if DEBUG_INFO
	debug_check_zone_rect.Clear();
#endif
	}
}

namespace Client
{
	/// add character
	void Level::AddCharacter(by_ptr(Character) c)
	{
		if (character_manager)
			character_manager->AddCharacter(c);
	}

	/// remove character
	void Level::RemoveCharacter(uint id)
	{
		if (character_manager)
			character_manager->RemoveCharacter(id);

		RemoveAllAmmoByUser(id, kWeaponTypeNone);
	}

	/// get character
	tempc_ptr(Character) Level::GetCharacter(uint id)
	{
		tempc_ptr(Character) player = GetPlayer();

		if (player && id == player->uid)
			return player;

		if (character_manager)
			return character_manager->GetCharacter(id);

		return NullPtr;
	}

	/// get character next
	tempc_ptr(Character) Level::GetCharacterNext(uint id, byte team_mask, bool reverse)
	{
		if (character_manager)
			return character_manager->GetCharacterNext(id, team_mask, reverse);

		return NullPtr;
	}

	/// get characters
	const Core::Array<sharedc_ptr(Character)> & Level::GetCharacters()
	{
		PDE_ASSERT(character_manager, "character_manager error!");
		return character_manager->GetCharacters();
	}

	/// get player
	tempc_ptr(Character) Level::GetPlayer()
	{
		if (player_manager)
			return player_manager->player;

		return NullPtr;
	}

	/// get viewer
	tempc_ptr(Character) Level::GetViewer()
	{
		if (player_manager)
			return GetCharacter(player_manager->viewer_id);

		return NullPtr;
	}

	/// add particle
	tempc_ptr(ParticleSystem) Level::AddParticle(const Core::Identifier & key, const Core::Vector3 & position, const Vector3 & normal)
	{
		return particle_manager->AddParticle(key, position, normal);
	}

	tempc_ptr(ParticleSystem) Level::AddParticle(const Core::Identifier & key, const Core::Vector3 & position, const Quaternion & q)
	{
		return particle_manager->AddParticle(key, position, q);
	}

	tempc_ptr(ParticleSystem) Level::AddParticle(by_ptr(ParticleSystem) particle)
	{
		return particle_manager->AddParticle(particle);
	}

	void Level::AddLevelParticle(const Core::Identifier & key, const Core::Vector3 & position, const Vector3 & normal)
	{
		LevelParticleInfo& info = level_particle_info.PushBack();
		info.pos = position;
		info.key = key;
		info.nor = normal;
		AddParticle(key, position, normal);
	}

	void Level::AddLevelParticle(const Core::Identifier & key, const Core::Vector3 & position, const Quaternion & q)
	{
		LevelParticleInfo& info = level_particle_info.PushBack();
		info.pos = position;
		info.key = key;
		info.nor = q.GetZXY();
		AddParticle(key, position, q);
	}

	/// remove particle
	void Level::RemoveParticle(by_ptr(ParticleSystem) particle)
	{
		if (particle_manager)
			particle_manager->RemoveParticle(particle);
	}

	/// update particle
	void Level::UpdateParticle(float frame_time)
	{
	}

	/// add bullet impact
	void Level::AddBulletImpact(const Core::Vector3 & position, const Core::Vector3 & normal, int material_index)
	{
		CStrBuf<256> key("bj/material/3d/bullet/");

		switch (material_index)
		{
		case PhysxSystem::kConcrete:
			AddParticle("bullet_concrete", position, normal);
			AddDecal("stone", position, normal, Vector3::kOne);
			key.contract("concrete");
			break;

		case PhysxSystem::kWood:
			AddParticle("bullet_wood", position, normal);
			AddDecal("wood", position, normal, Vector3::kOne);
			key.contract("wood");
			break;

		case PhysxSystem::kMetal:
			AddParticle("bullet_metal", position, normal);
			AddDecal("metal", position, normal, Vector3::kOne);
			key.contract("metal");
			break;

		default:
			break;
		}

		FMOD::Event* audio_event = NULL;
		audio_event = FmodSystem::GetEvent(key);
		FMOD_VECTOR pos = (const FMOD_VECTOR &)position;
		FMOD_VECTOR vel = {0, 0, 0};
		audio_event->set3DAttributes(&pos, &vel);
		if (audio_event)
			audio_event->start();
	}

	/// gen ammoid
	U16 Level::GenAmmoId()
	{
		return ammoid_builder++;
	}
}

namespace Client
{
	/// on game start
	void Level::OnGameStart()
	{
		sponsor_uid = -1;
		kicked_uid = -1;
		kicked_reason = -1;
		kick_wait_time = 0;
		kick_select_id = 0;
		kick_agree_num = 0;
		kick_against_num = 0;
		kick_select_open = false;
		boss_starttimeer = -1;
		start_chooseperson_time = 15.f;
		isneedparticle = false;
		isCanActiveGate = false;
		isZombieText_show = true;
		activeHaveTime = -10.f;
		fly_time = 0;

		fly_Time = 0;
		gold_particles.Clear();
		launch_time = 0.f;
		Launch_Time = 0.f;
        firework_particles.Clear();
		launch_Time = 0.f;
		current_street_king_uid[0] = 0;
		current_street_king_uid[1] = 0;
		if (!audio_background)
		{
			audio_background = FmodSystem::GetEvent("bj/music/ingame_bgm");
			audio_background->stop(true);
		}
		if (!audio_Survival_background )
		{
			audio_Survival_background = FmodSystem::GetEvent("bj/music/survival_bgm");
			audio_Survival_background->stop(true);
		}
		if (!audio_Survival1_background )
		{
			audio_Survival1_background = FmodSystem::GetEvent("bj/fx/2d/survival_weakness_trap");
			audio_Survival1_background->stop(true);
		}
		if (!audio_bossmode2_background)
		{
			audio_bossmode2_background = FmodSystem::GetEvent("bj/music/boss02");
			audio_bossmode2_background->stop(true);
		}
		if (!audio_killing_background)
		{
			audio_killing_background = FmodSystem::GetEvent("bj/music/killing_time_bgm");
			audio_killing_background->stop(true);
		}
		if (!audio_chrismas_background)
		{
			audio_chrismas_background = FmodSystem::GetEvent("bj/music/chinesenewyear_bgm");
			audio_chrismas_background->stop(true);
		}
      
		b_Scale_Cd[0]  = false;
		b_Scale_Cd[1]  = false;
		b_Scale_Cd[2]  = false;
		b_Scale_Cd[3]  = false;
	}

	void Level::ThrowGrenade(uint id, by_ptr(ThrowableInfo) info, const Core::Vector3& position, const Core::Vector3& velocity, int team)
	{
		// client only
		sharedc_ptr(Grenade) grenade = ptr_new Grenade(info);
		grenade->Initialize();
		if (grenade->grenade_trail_particle)
		{
			grenade->grenade_trail_particle->Reset();
			grenade->grenade_trail_particle->SetPosition(position);
			AddParticle(grenade->grenade_trail_particle);
		}
		grenade->team = team;
		grenade->CreatePhysx();
		grenade->uid = id;
		grenade->SetPosition(position);
		grenade->ThrowOut(velocity);
		grenade_array.PushBack(grenade);
	}

	bool Level::LaunchAmmo(byte uid, uint team, by_ptr(AmmoInfo) info, const Core::Vector3& position, const Core::Vector3& velocity, U16 ammoindex, by_ptr(Character) target,bool isboost)
	{
		//LogSystem.WriteLinef("LaunchAmmo(uid[%d], ammoindex[%d])", (int)uid, (int)ammoindex);

		// client only
		sharedc_ptr(AmmoBase) ammo = AmmoFactory::CreateAmmo(info);
		if (!ammo)
		{
			return false;
		}

		ammo->Initialize(team, isboost);

		ammo->uid = uid;
		tempc_ptr(Character) cfrom = GetCharacter(uid);
		ammo->SetOwner(cfrom);
		
		Quaternion rot(Vector3(0, 1, 0), velocity);
		
		ammo->CreatePhysx();

		ammo->SetPosition(position);
		ammo->SetRotation(rot);
		
		ammo->LaunchOut(velocity, target);

		if (GetPlayer()->uid == uid && ammo->type == kWeaponTypeAmmoRocket)
		{
			player_manager->currentAmmo = ammo;
		}

		sharedc_ptr(AmmoSet) ammo_set = character_ammoset.Get(uid, NullPtr);
		if (!ammo_set)
		{
			ammo_set = ptr_new AmmoSet();

			character_ammoset.Add(uid, ammo_set);
		}

		if(ammo->type == kWeaponTypeAmmoStick && GetPlayer()->uid == uid && ammo_set->Size() >= (DWORD)info->max_stick_ammo_count)
		{
			tempc_ptr(AmmoBase) fristammo = NullPtr;

			int stickcnt = 0;

			AmmoSet::Enumerator itor(*ammo_set);
			while (itor.MoveNext())
			{
				tempc_ptr(AmmoBase) tmpammo = itor.Value();
				if (tmpammo->type == kWeaponTypeAmmoStick)
				{
					if (!fristammo)
					{
						fristammo = tmpammo;
					}
					stickcnt++;
				}
			}

			if (fristammo && stickcnt >= info->max_stick_ammo_count)
			{
				fristammo->is_dead = true;

				tempc_ptr(Character) c = GetCharacter(uid);
				if(c)
				{
					c->stick_ammo_explode_timer = 0.5f;
				}
				
			}
		}
		ammo->ammoindex = ammoindex;
		return ammo_set->Add(ammoindex, ammo);
	}

	/// ProjectedAmmo explode
	void Level::AmmoExplode(by_ptr(AmmoBase) rocket)
	{
		if(rocket)
		{
			tempc_ptr(AmmoInfo) ammo_info = ptr_static_cast<AmmoInfo>(rocket->weapon_info);

			if (ammo_info)
			{
				FMOD_VECTOR vel = {0, 0, 0};
				FmodSystem::Play3DEvent(ammo_info->explode_sound,(const FMOD_VECTOR &)rocket->GetPosition(),vel);

				if (rocket->is_impact && !rocket->is_impact_character && rocket->type != kWeaponTypeAmmoStick)
					AddDecal(ammo_info->explode_decal, rocket->impact_pos, rocket->impact_normal, Vector3::kOne);

				if(rocket->is_boost)
				{
					static const char szTeam[2] = {'r', 'b'};

					String explode_particle_boost = Core::String::Format("%s_b%c", ammo_info->explode_particle.Str(),  szTeam[rocket->team & 1]);

					AddParticle(explode_particle_boost, rocket->GetPosition(), rocket->impact_normal);
				}
				else
					AddParticle(ammo_info->explode_particle, rocket->GetPosition(), rocket->impact_normal);
			}
		}
	}

	void Level::AmmoOnDead(const by_ptr(AmmoBase) ammo, U16 ammoindex)
	{
		bool teamhurt = (player_manager->player->GetTeam() != ammo->team);
		switch (ammo->type)
		{
		case kWeaponTypeAmmoRocket:
		case kWeaponTypeAmmoStick:
		case kWeaponTypeAmmoGrenade:
		case kWeaponTypeAmmoProd:
			{
				if (ammo->GetVisible())
				{
					gLevel->AmmoExplode(ammo);
				}
				if (player_manager && player_manager->player && (player_manager->player->uid == ammo->uid))
				{
					float distance = 0;
					const Array<sharedc_ptr(Character)> & characters = GetCharacters();
					//if(ammo->ammo_enable)
					{
						for (U32 i = 0; i < characters.Size(); i++)
						{
							if (characters[i])
							{
								tempc_ptr(AmmoInfo) ammo_info = ptr_static_cast<AmmoInfo>(ammo->weapon_info);
								
								if(ammo->type == kWeaponTypeAmmoStick)
								{
									if(!ammo_info->ignorewall)
									{
										if (characters[i]->CheckGrenade(ammo->GetPosition(), distance))
											gGame->channel_connection->ExplodeAmmoHurt(ammoindex, characters[i]->uid, ammo_info, distance, ammo->impact_flyscale, ammo->GetPosition(),teamhurt, kCharacterPartTorso, 1.f);
									}
									else
									{
										Vector3 vctdistance = ammo->GetPosition() - characters[i]->GetPosition();
										distance =vctdistance.Length();
										gGame->channel_connection->ExplodeAmmoHurt(ammoindex, characters[i]->uid, ammo_info, distance, ammo->impact_flyscale, ammo->GetPosition(),teamhurt, kCharacterPartTorso, 1.f);
									}
								}
								else
								{
									if(!ammo_info->ignorewall)
									{
										if (characters[i]->CheckGrenade(ammo->GetPosition(), distance))
											gGame->channel_connection->ExplodeAmmoHurt(ammoindex, characters[i]->uid, ammo_info, distance, ammo->impact_flyscale, ammo->GetPosition(),teamhurt, kCharacterPartTorso, ammo_info->hurt_rate);
									}
									else
									{
										Vector3 vctdistance = ammo->GetPosition() - characters[i]->GetPosition();
										distance =vctdistance.Length();
										gGame->channel_connection->ExplodeAmmoHurt(ammoindex, characters[i]->uid, ammo_info, distance, ammo->impact_flyscale, ammo->GetPosition(),teamhurt, kCharacterPartTorso, ammo_info->hurt_rate);
									}
								}
							}
						}

						HashSet<uint, sharedc_ptr(DummyObject)>::Enumerator it(gLevel->dummy_object_set);
						while (it.MoveNext())
						{
							tempc_ptr(DummyObject) dummy_obj = it.Value();
							if(dummy_obj)
							{
								tempc_ptr(AmmoInfo) ammo_info = ptr_static_cast<AmmoInfo>(ammo->weapon_info);

								if(ammo->type == kWeaponTypeAmmoStick)
								{
									if(!ammo_info->ignorewall)
									{
										if (dummy_obj->CheckGrenade(ammo->GetPosition(), distance))
											gGame->channel_connection->ExplodeAmmoHurtDummy(ammoindex, dummy_obj->dummyobjectinfo->dummy_id, ammo_info, distance, ammo->impact_flyscale, ammo->GetPosition(),teamhurt, 1.f);
									}
									else
									{
										Vector3 vctdistance = ammo->GetPosition() - dummy_obj->GetPosition();
										distance =vctdistance.Length();
										gGame->channel_connection->ExplodeAmmoHurtDummy(ammoindex, dummy_obj->dummyobjectinfo->dummy_id, ammo_info, distance, ammo->impact_flyscale, ammo->GetPosition(),teamhurt, 1.f);
									}
								}
								else
								{
									if(!ammo_info->ignorewall)
									{
										if (dummy_obj->CheckGrenade(ammo->GetPosition(), distance))
											gGame->channel_connection->ExplodeAmmoHurtDummy(ammoindex, dummy_obj->dummyobjectinfo->dummy_id, ammo_info, distance, ammo->impact_flyscale, ammo->GetPosition(),teamhurt, ammo_info->hurt_rate);
									}
									else
									{
										Vector3 vctdistance = ammo->GetPosition() - dummy_obj->GetPosition();
										distance =vctdistance.Length();
										gGame->channel_connection->ExplodeAmmoHurtDummy(ammoindex, dummy_obj->dummyobjectinfo->dummy_id, ammo_info, distance, ammo->impact_flyscale, ammo->GetPosition(),teamhurt, ammo_info->hurt_rate);
									}
								}
							}


						}
		

						if (game_type == RoomOption::kNovice)
						{
							int tempid = -1;
							int gun_index = -1;
							if (novice_index == 10)
							{
								tempid = 0;
								gun_index = 0;
							}
							else if (novice_index == 13)
							{
								tempid = 1;
								gun_index = 0;
							}
							if (novice_index < 20)
							{
								tempc_ptr(Character) tempplayer = GetPlayer();
								if (tempplayer && tempplayer->character_info && tempplayer->GetFirstPerson().GetWeapon(gun_index) == tempplayer->GetWeapon())
								{
									for (uint i = 0; i < novice_guntarget_array.Size();++i)
									{
										if (novice_guntarget_array[i]->guntarget_info->uid == tempplayer->character_info->career_id && novice_guntarget_array[i]->GetID() == tempid)
										{
											if (novice_guntarget_array[i]->CheckFire(ammo->GetPosition(), distance) && distance < 3.f && novice_guntarget_array[i]->status == GUNTARGET_UP)
											{
												novice_guntarget_array[i]->status = GUNTARGET_DOWN;
												novice_shoot_num--;
											}
										}
									}
								}
							}
							else
							{
								tempc_ptr(Character) tempplayer = GetPlayer();
								if (tempplayer && tempplayer->character_info)
								{
									for (uint i = 0; i < novice_guntarget_array.Size();++i)
									{
										if (novice_guntarget_array[i]->CheckFire(ammo->GetPosition(), distance) && distance < 3.f && novice_guntarget_array[i]->status == GUNTARGET_UP)
										{
											novice_guntarget_array[i]->status = GUNTARGET_DOWN;
										}
									}
								}
							}
						}
					}
					
					tempc_ptr(AmmoInfo) ammo_info = ptr_static_cast<AmmoInfo>(ammo->weapon_info);

					if(ammo_info->hurtself)
					{
						if (player_manager->player->CheckGrenade(ammo->GetPosition(), distance))
						{
							if(ammo->type == kWeaponTypeAmmoStick)
							{
								gGame->channel_connection->ExplodeAmmoHurt(ammoindex, player_manager->player->uid, ammo_info, distance, ammo->impact_flyscale, ammo->GetPosition(),teamhurt, kCharacterPartTorso, 1.f);

							}
							else
							{
								gGame->channel_connection->ExplodeAmmoHurt(ammoindex, player_manager->player->uid, ammo_info, distance, ammo->impact_flyscale, ammo->GetPosition(),teamhurt, kCharacterPartTorso, ammo_info->hurt_rate);

							}
						}
					}


					if (Length(ammo->GetPosition() - player_manager->player->GetPosition()) < 15.f)
					{
						player_manager->player->OnGrenadeExplode();
					}
				}
			}
			break;
		case kWeaponTypeAmmoMeditNeedle:
			break;
		case kWeaponTypeAmmoArrow:
			break;
		case kWeaponTypeAmmoBloodDisk:
			{

			}
			break;
		default:
			break;
		}

		if (player_manager && player_manager->player && (player_manager->player->uid == ammo->uid))
		{
			gGame->channel_connection->ProjectedAmmoDestroy(ammo, ammoindex);
		}

		ammo->StopEffect();
	}

	/// greande explode
	void Level::GrenadeExplode(by_ptr(Grenade) grenade)
	{
		if (grenade && grenade->grenade_info)
		{
			AddParticle(grenade->grenade_info->explode_particle, grenade->GetPosition(), Vector3(0, 1, 0));

			FMOD::Event* audio_event = FmodSystem::GetEvent(grenade->grenade_info->explode_sound);
			if (audio_event)
			{
				FMOD_VECTOR pos = (const FMOD_VECTOR &)grenade->GetPosition();
				FMOD_VECTOR vel = {0, 0, 0};
				audio_event->set3DAttributes(&pos, &vel);
				audio_event->start();
			}
		}

		if (grenade->grenade_info->weapon_type == kWeaponTypeGrenade || grenade->grenade_info->weapon_type == kWeaponTypeSpecial)
		{
			Vector3 pos = grenade->GetPosition();
			Vector3 dir = Vector3(0, -1, 0);
			NxRay ray;
			ray.orig = (const NxVec3 &)pos;
			ray.dir = (const NxVec3 &)dir;

			NxRaycastHit hit;
			uint group_id = 0;
			group_id |= 1 << PhysxSystem::kStatic;
			group_id |= 1 << PhysxSystem::kStaticRaycast;
			group_id |= 1 << PhysxSystem::kGroupVehicle;
			NxShape* shape = gPhysxScene->raycastClosestShape(ray, NX_ALL_SHAPES, hit, group_id, 1);

			pos.x = hit.worldImpact.x;
			pos.y = hit.worldImpact.y;
			pos.z = hit.worldImpact.z;

			dir.x = hit.worldNormal.x;
			dir.y = hit.worldNormal.y;
			dir.z = hit.worldNormal.z;

			if (shape)
				AddDecal("grenade_explode", pos, Vector3(0, 1, 0), Vector3(1.f, 1.f, 1.f));
			if (grenade->grenade_trail_particle)
				grenade->grenade_trail_particle->SetDead();
		}
		
	}

	/// round start
	void Level::RoundStart()
	{
		isneedparticle = false;
		fly_time = 0;
		fly_Time = 0 ; 
		gold_particles.Clear();
		launch_time = 0.f;

		firework_particles.Clear();
		launch_Time = 0.f;
		Launch_Time =  0.f;
		round_end_wait_time = 0.0f;
		bomb_exploded = false;
		bomb_explode_timer = -1.f;
		bomb_droped_id = 0;
		bomb_droped = false;
		isCanActiveGate = false;
		isZombieText_show = true;
		activeHaveTime = -10.f;
		is_round_end = false;
		commonzombie_king_isShow = false;
		
		round_start_waiting = true;
		zombie_saving_dying = false;
		zombie_state_two_flag = false;
		zombie_human_down_sound = true;
		step_two_sound_timer = step_two_sound_default_timer;
		use_coin_num = 0;
		GetPlayer()->isMoonBoss = false;
		GetPlayer()->advBoxNum[0] = 0;
		GetPlayer()->advBoxNum[1] = 0;
		GetPlayer()->advBoxNum[2] = 0;
		GetPlayer()->advBoxNum[3] = 0;
		for (U32 i = 0; i < anim_object_array.Size(); i++)
		{
			anim_object_array[i]->Reset();
		}

		dummy_object_set.Clear();

		for (U32 i = 0; i < gate_array.Size(); i++)
		{
			gate_array[i]->ResetActiveState();
		}

		tempc_ptr(Character) viewer = gLevel->GetViewer();

		if (particle_manager)
			particle_manager->Clear();

		for (U32 i = 0; i < level_particle_info.Size(); i++)
			AddParticle(level_particle_info[i].key, level_particle_info[i].pos, level_particle_info[i].nor);

		horn_array.Clear();
		pickup_manager->RemoeAllSupply();

		showhorn = false;
		if (!audio_background)
		{
			audio_background = FmodSystem::GetEvent("bj/music/ingame_bgm");
		}
		audio_background->stop(true);
		if (!audio_Survival_background)
		{
			audio_Survival_background = FmodSystem::GetEvent("bj/music/survival_bgm");
		}
		audio_Survival_background->stop(true);

		if (!audio_Survival1_background )
		{
			audio_Survival1_background = FmodSystem::GetEvent("bj/fx/2d/survival_weakness_trap");
		}
		audio_Survival1_background->stop(true);
		if (!audio_bossmode2_background)
		{
			audio_bossmode2_background = FmodSystem::GetEvent("bj/music/boss02");
		}
		audio_bossmode2_background->stop(true);
		if (!audio_killing_background)
		{
			audio_killing_background = FmodSystem::GetEvent("bj/music/killing_time_bgm");
		}
		audio_killing_background->stop(true);

		if (!audio_chrismas_background)
		{
			audio_chrismas_background = FmodSystem::GetEvent("bj/music/chinesenewyear_bgm");
		}
		audio_chrismas_background->stop(true);

		if (GetPlayer()->boss_2D_fly)
		{
			GetPlayer()->boss_2D_fly->stop();
			GetPlayer()->boss_2D_fly = NULL;
		}
		
		current_street_king_uid[0] = 0;
		current_street_king_uid[1] = 0;

		moon_mode_win_list.Clear();

		trap_info.Clear();
	}

	/// round end
	void Level::RoundEnd()
	{
		round_start_wait_time = 0.0f;
		is_round_end = true;
		is_self_plant_bomb = false;
		zombie_state_two_flag = false;

		//horn_array.Clear();
		pickup_manager->RemoeAllSupply();
		if (audio_background)
		{
			audio_background->stop(true);
			audio_background = NULL;
		}
		if (audio_Survival_background)
		{
			audio_Survival_background->stop(true);
			audio_Survival_background = NULL;
		}
		if (audio_Survival_background)
		{
			audio_Survival1_background->stop(true);
			audio_Survival1_background = NULL;
		}

		if (audio_bossmode2_background)
		{
			audio_bossmode2_background->stop(true);
			audio_bossmode2_background = NULL;
		}
		if (audio_killing_background)
		{
			audio_killing_background->stop(true);
			audio_killing_background = NULL;
		}
		if (audio_chrismas_background)
		{
			audio_chrismas_background->stop(true);
			audio_chrismas_background = NULL;
		}
		if (audio_bomb_Planting_Defusing)
		{
			audio_bomb_Planting_Defusing->stop();
			audio_bomb_Planting_Defusing = NULL;
		}
		if (zombie_state_two_muisc)
		{
			zombie_state_two_muisc->stop();
			zombie_state_two_muisc = NULL;
		}
		if (boss_mode2_armor_warning)
		{
			boss_mode2_armor_warning->stop();
			boss_mode2_armor_warning = NULL;
		}
		bomb_on_ground_particle = NullPtr;
	}

	/// add decal
	void Level::AddDecal(const String key, const Core::Vector3 & target, const Core::Vector3 & normal, const Vector3 & size, const F32 duration)
	{
		decal_manager->AddDecal(key, target, normal, size, duration);
	}

	void Level::Shoot(const Vector3& target, const Vector3& normal)
	{
	}

	void Level::ExplodeGrenade(uint id, float distance)
	{
	}

	void Level::Hit(Character* c, const Core::Vector3& target, int part)
	{
	}

	/// set camera mode
	void Level::SetCameraMode(Camera::ControlMode mode)
	{
		if (player_manager)
			player_manager->SetCameraMode(mode);
	}

	/// get visible
	bool Level::GetVisible(const AxisAlignedBox& aabb)
	{
#ifndef MASTER
		return true;
#endif
		if (!gGame)
			return false;

		if (!gGame->camera)
			return false;

		if (AABB_IS_OUTSIDE(aabb.TestIntersection(&gGame->camera->frustum, 0)))
			return false;
		
		occludee.InitAABB(aabb, gGame->camera->viewprojMatrix, true);

		for (U32 i = 0; i < occluderplanes.Size(); i++ )
		{
			if(occluderplanes[i].IsVisible())
				if(occluderplanes[i].Occlude2D(occludee) == kBackSide)
					return false;
		}
		return true;
	}

	bool Level::GetVisible(const OrientBox& obb)
	{
		AxisAlignedBox aabb(obb);
		return GetVisible(aabb);
	}

	void Level::TestSummonGate()
	{
		Vector3 vec,vec1;
		
		if(!GetPlayer())
		{
			return;
		}
		vec=GetPlayer()->GetSkeletonPosition();
		vec1=vec+Vector3(0.0f,0.0f,3.0f)*GetPlayer()->GetSkeletonRotation();
			
		Quaternion q;
		q.SetZXY(vec1);

		vec1 += Vector3(4,0,0);
	}

	//for TA
	void Level::SummonGate(const Vector3& vec, float deg, int id, int team, const Vector3& target_vec, const Vector3& dim, const Core::Vector3& collision_dim, const String& mesh_path)
	{
		Vector3 rot;
		rot.x = 0;
		rot.y = deg * DEG2RAD;
		rot.z = 0;
		Quaternion q;
		q.SetZXY(rot);

		sharedc_ptr(GateInfo) info = ptr_new GateInfo();
		info->gate_type = SINGLE_GATE;
		info->position = vec;
		info->active_state_default = true;
		info->rotation = q;
		info->id = id;
		info->team = team;
		info->target_position = target_vec;
		info->check_dim = dim;
		info->gate_collision_box_dim = collision_dim;
		info->gate_mesh_name = mesh_path;

		sharedc_ptr(GateBase) gate = ptr_new GateBase(info);
		gate->Initialize();
		gate_array.Add(gate);
		info->position.y = 0;
	}
	
	void Level::SummonActiveGate(const Vector3& vec, float deg, bool isactive, int team, const Vector3& target_vec, const Vector3& dim, const Core::Vector3& collision_dim, const String& mesh_path)
	{
		Vector3 rot;
		rot.x = 0;
		rot.y = deg * DEG2RAD;
		rot.z = 0;
		Quaternion q;
		q.SetZXY(rot);

		sharedc_ptr(GateInfo) info = ptr_new GateInfo();
		info->gate_type = SINGLE_GATE;
		info->position = vec;
		info->rotation = q;
		info->id = 10000;
		info->team = team;
		info->active_state_default = isactive;
		info->target_position = target_vec;
		info->check_dim = dim;
		info->gate_collision_box_dim = collision_dim;
		info->gate_mesh_name = mesh_path;

		sharedc_ptr(GateBase) gate = ptr_new GateBase(info);
		gate->Initialize();
		gate_array.Add(gate);
		info->position.y = 0;
	}

	void Level::AddDeadAABB(const Vector3& min, const Vector3& max)
	{
		AxisAlignedBox& box = AxisAlignedBox(min,max);
		check_dead_zone.Add(box);

#if DEBUG_INFO
		Vector3 points[4];
		int array[24] = 
		{
			0,1,3,2,
			0,4,6,2,
			4,5,7,6,
			1,5,7,3,
			0,1,5,4,
			2,3,7,6
		};

		for (uint i = 0;i < 6; i++)
		{
			for (uint j = 0; j < 4; j++)
			{
				AxisAlignedBox::Corner c = AxisAlignedBox::Corner(array[i * 4 + j]);
				points[j] = box.GetCornerPos(c);
			}
			DebugPrimitiveRect rect;
			rect.CreateVertice(points,4);
			
			debug_dead_zone_rect.Add(rect);
		}
#endif
	}

	void Level::BuildDeadZoneOctree()
	{
		uint RecursiveLevel = 5;
		
		if(check_dead_zone.Size())
		{		
			const AxisAlignedBox& FirstAabb = check_dead_zone.GetAt(0);
			
			F32 MinX = FirstAabb.Min.x;
			F32 MinY = FirstAabb.Min.y;
			F32 MinZ = FirstAabb.Min.z;

			F32 MaxX = FirstAabb.Max.x;
			F32 MaxY = FirstAabb.Max.y;
			F32 MaxZ = FirstAabb.Max.z;

			for (uint i = 1; i < check_dead_zone.Size(); i++)
			{
				const AxisAlignedBox& aabb = check_dead_zone.GetAt(i);

				if( MinX > aabb.Min.x)
					MinX = aabb.Min.x;

				if( MinY > aabb.Min.y)
					MinY = aabb.Min.y;

				if( MinZ > aabb.Min.z)
					MinZ = aabb.Min.z;

				if( MaxX < aabb.Max.x)
					MaxX = aabb.Max.x;

				if( MaxY < aabb.Max.y)
					MaxY = aabb.Max.y;

				if( MaxZ < aabb.Max.z)
					MaxZ = aabb.Max.z;		
			}

			AxisAlignedBox newaabb(Vector3(MinX,MinY,MinZ),Vector3(MaxX,MaxY,MaxZ));
			Vector3 center = newaabb.GetCenter();
			float half_size = newaabb.GetRaidus();
			max_leaf_size = half_size;

			first_leaf = ptr_new SceneLeaf();	
			
			for(uint i = 0;i < RecursiveLevel ; i++)
				max_leaf_size = max_leaf_size / 2;

			RecursiveSceneBuild(first_leaf,center,half_size,newaabb);
		}
	}

	void Level::RecursiveSceneBuild(const by_ptr(SceneLeaf) leaf,const Core::Vector3 &translation,float halfsize,const AxisAlignedBox & aabb)
	{
		leaf->aabb = ptr_new AxisAlignedBox(aabb.Min,aabb.Max);
		leaf->position = translation;
		leaf->halfSize = halfsize;

		bool isInbox = false;

		for (uint i = 0; i < check_dead_zone.Size(); i++)
		{
			const AxisAlignedBox& Aabb = check_dead_zone.GetAt(i);
			
			if(leaf->aabb->IsIntersectWithAABB(Aabb))
			{
				isInbox = true;
				break;
			}

		}

		if(isInbox && halfsize > max_leaf_size)
		{
			
			for(uint i = 0;i < 8; i++ )
			{
				Vector3 newTranslation,newMin,newMax;

				float newHalfSize = halfsize / 2.0f;
				float mod;

				mod = 1.0f;
				if( i % 2 < 1 )
					mod = -1.0f;
				newTranslation.x = translation.x + newHalfSize * mod;

				mod = 1.0f;
				if( i % 4 < 2 )
					mod = -1.0f;
				newTranslation.y = translation.y + newHalfSize * mod;

				mod = 1.0f;
				if( i % 8 < 4 )
					mod = -1.0f;
				newTranslation.z = translation.z + newHalfSize * mod;

				newMin = Vector3( newTranslation.x - newHalfSize, newTranslation.y - newHalfSize, newTranslation.z - newHalfSize );
				newMax = Vector3( newTranslation.x + newHalfSize, newTranslation.y + newHalfSize, newTranslation.z + newHalfSize );

				const AxisAlignedBox newaabb(newMin,newMax);
				Core::Array< Core::AxisAlignedBox > objectAabb;
				bool isInaabb = false;
				
				objectAabb.Clear();

				for (uint j = 0; j < check_dead_zone.Size(); j++)
				{
					const AxisAlignedBox& Aabb = check_dead_zone.GetAt(j);
					
					if(newaabb.IsIntersectWithAABB(Aabb))
					{
						isInaabb = true;
						objectAabb.Add(Aabb);
					}
					
				}

				if(isInaabb)
				{
					leaf->children[i] = ptr_new SceneLeaf();
					leaf->children[i]->target = objectAabb;
					Vector3 center = newaabb.GetCenter();
					leaf->childcount++;
					RecursiveSceneBuild(leaf->children[i],center,newHalfSize,newaabb);
				}
			}
			
		}

		
		return;
	}

	void Level::RecursiveSceneCheck(const by_ptr(SceneLeaf) leaf,const Core::Vector3 &translation)
	{
		if(leaf->halfSize/2 < max_leaf_size && leaf->halfSize >= max_leaf_size) 
		{
			if(leaf->aabb->IsPointInside(translation))
			{
			
				for(uint i = 0; i < leaf->target.Size(); i++)
				{
					const AxisAlignedBox& Aabb = leaf->target.GetAt(i);

					if(Aabb.IsPointInside(translation))
					{
						is_in_DeadZoon = true;
						return;
					}
				}
								
			}
		}
		
	
		for(uint i = 0;i < 8;i++)
		{
			if(leaf->children[i] && leaf->children[i]->aabb->IsPointInside(translation))
				 RecursiveSceneCheck(leaf->children[i],translation);

		}
		

		return;
	}

	void Level::AddGunTarget(const Core::Vector3& pos, const Core::Vector3& end_pos, float deg,int id, int uid, const Core::Vector3& collision_dim, const Core::String& mesh_path, int type)
	{
		Vector3 rot;
		//degree
		rot.x = 0;
		rot.y = deg * DEG2RAD;
		rot.z = 0;
		Quaternion q;
		q.SetZXY(rot);

		sharedc_ptr(GunTargetInfo) info = ptr_new GunTargetInfo();
		info->position = pos;
		info->end_position = end_pos;
		info->rotation = q;
		info->id = id;
		info->uid = uid;
		info->collision_box_dim = collision_dim;
		info->guntarget_type = type;
		info->target_mesh_name = mesh_path;

		sharedc_ptr(GunTarget) target = ptr_new GunTarget(info);
		target->Initialize();
		novice_guntarget_array.Add(target);
	}
	
	void Level::SetZombieStepTwoSoundInfo(float delay_time, const String& zombie_sound, const String& human_sound)
	{
		step_two_sound_default_timer = delay_time;
		step_two_zombie_sound = zombie_sound;
		step_two_human_sound = human_sound;
	}

	void Level::AddActiveObject(const Vector3& position,const Quaternion& qRot, const String& filename, const Vector3& rot_normal, float rot_360_time, float updown_distance, float updown_speed)
	{
		sharedc_ptr(ActiveObjInfo) info = ptr_new ActiveObjInfo();
		info->filename = filename;
		info->position = position;
		info->rotation = qRot;
		info->rot_normal = rot_normal;
		info->rot_360_time = rot_360_time;
		info->updown_distance = updown_distance;
		info->updown_speed = updown_speed;

		sharedc_ptr(ActiveObject) a = ptr_new ActiveObject(info);
		a->Initialize();

		active_object_array.Add(a);
	}

	void Level::AddAnimObject(const Core:: Quaternion& qRot, const Core::String& filename) 
	{
		sharedc_ptr(AnimObjectInfo) info = ptr_new AnimObjectInfo();
		info->rotation = qRot;

		//read lua...
		CStrBuf<256> path;
		path.format("%s%s",MESH_KEY_SCENEPROP, filename.Str());

		sharedc_ptr(ScriptLua) lua = RESOURCE_LOAD(path, false, ScriptLua);

		if (lua)
		{
			Lua::LuaState *L = Lua::LuaState::NewState();
			L->OpenLibs();
			if (L->LoadBuffer(lua->GetBuffer(), lua->GetSize(), path) == 0)
			{
				L->NewTable();
				L->PushPtr(ptr_static_cast<AnimObjectInfo>(info));
				L->SetField(-2, "animobject_info");
				L->PushPtr(PDE_TYPE_OF(Vector3)->GetConstructor());
				L->SetField(-2, "Vector3");
				L->SetFenv(-2);

				if (L->DoCall(0, 0))
				{
					const char *msg = L->ToString(-1);
					if (msg) Console.WriteLine(msg);
					L->Pop(1);
				}
			}
			else
			{
				const char *msg = L->ToString(-1);
				if (msg) Console.WriteLine(msg);
				L->Pop(1);
			}
			L->Close();
		}

		sharedc_ptr(AnimObject) a = ptr_new AnimObject(info);
		a->Initialize();

		anim_object_array.Add(a);
	}

	void Level::AddManualBound(const Vector3& offset, const Vector3& dim,int type)
	{
		MeshPhysXData& data = mesh_manual_info_array.PushBack();
		data.center_offset = offset;
		data.dim = dim;
		data.type = type;
	}

	bool Level::SetAllAmmoDeadByUser(const byte uid ,WeaponType wtype)
	{
		sharedc_ptr(AmmoSet) ammo_hash = gLevel->character_ammoset.Get(uid, NullPtr);
		if (ammo_hash)
		{
			AmmoSet::Enumerator it(*ammo_hash);
			while (it.MoveNext())
			{
				tempc_ptr(AmmoBase) tmpAmmo = it.Value();
				if (tmpAmmo->type == wtype || wtype == kWeaponTypeNone)
				{
					tmpAmmo->is_dead = true;
				}
			}
		}
		else
		{
			return false;
		}

		return true;
	}

	bool Level::RemoveAllAmmoByUser( const byte uid, WeaponType wtype)
	{
		sharedc_ptr(AmmoSet) ammo_hash = gLevel->character_ammoset.Get(uid, NullPtr);
		if (ammo_hash)
		{
			Core::Array<Short> dead_arry;

			AmmoSet::Enumerator ammoitor(*ammo_hash);
			while (ammoitor.MoveNext())
			{
				tempc_ptr(AmmoBase) ammo = ammoitor.Value();
				if (ammo)
				{
					if (ammo->type == wtype || wtype == kWeaponTypeNone)
					{
						dead_arry.Add(ammoitor.Key());
						AmmoOnDead(ammoitor.Value(),ammoitor.Key());
					}
				}
				else
				{
					return false;
				}
			}
			
			
			for (U32 index = 0; index < dead_arry.Size(); index++)
			{
				ammo_hash->Remove(dead_arry[index]);
			}
		}
		else
		{
			return false;
		}

		return true;
	}

	void Level::BombMode_DefuseBomb()
	{
		tempc_ptr(Character) player = GetPlayer();

		if(!player || player->GetTeam() != 0 || game_type != RoomOption::kBombMode)
			return;

		if(!bomb_on_ground)
			return;

		if(player->IsReady() && !player->IsDied())
		{
			Vector3 pos = player->GetCameraPosition();
			Vector3 dir = Vector3(0, 0, -1) * player->GetLookDir();

			NxRay ray;
			ray.orig = (const NxVec3 &)pos;
			ray.dir = (const NxVec3 &)dir.Normalize();

			NxRaycastHit hit;

			uint group_id = 0;
			group_id |= 1 << PhysxSystem::kGroupBomb;
			group_id |= 1 << PhysxSystem::kStatic;

			NxShape* shape = gPhysxScene->raycastClosestShape(ray, NX_ALL_SHAPES, hit, group_id, 2000);
			Vector3 play_pos;
			if (shape && shape->getGroup() == PhysxSystem::kGroupBomb)
			{
				if(hit.distance < 5)
				{
					gGame->channel_connection->StartDefuseBomb();
					player->LockStateByType(kLSMove);
					bomb_defusing = true;
				}
			}
		}	
	}

	int Level::GetDummyObjectCount(int type, const String& szRes)
	{
		int iCount =0;
		HashSet<uint, sharedc_ptr(DummyObject)>::Enumerator it(dummy_object_set);
		while (it.MoveNext())
		{
			tempc_ptr(DummyObject) dummy_obj = it.Value();
			if(dummy_obj && (dummy_obj->type == type) && (dummy_obj->m_szResKey == szRes))
			{
				iCount +=1;
			}
		}
		return iCount;
	}
	int Level::GetDummyObjectCountBySubType(int sub_type)
	{
		int iCount =0;
		HashSet<uint, sharedc_ptr(DummyObject)>::Enumerator it(dummy_object_set);
		while (it.MoveNext())
		{
			tempc_ptr(DummyObject) dummy_obj = it.Value();
			if(dummy_obj && dummy_obj->sub_type == sub_type)
			{
				iCount +=1;
			}
		}
		return iCount;
	}
	void Level::AddDummyObject(byte owner_id,uint uid, byte type, byte sub_type, byte need_stepfather, byte team, byte can_hurt, const char* pbuffer, int length)
	{
		if (owner_id == 0)
		{
			sharedc_ptr(DummyObject) dummy = NullPtr;

			sharedc_ptr(DummyObjectInfo) info = ptr_new DummyObjectInfo();

			ServerDummyCreateInfo create_info;
			readUserData(pbuffer, length, 0, create_info);

			info->dummy_id = uid;
			info->owner_id = owner_id;
			info->level = 0;
			info->hp = create_info.maxhp;
			info->move_keep_time = 0;
			info->move_speed = 0;
			info->tower_key = "";

			info->LoadConfig(create_info.res_key);

			switch (type)
			{
				case DummyObject::DUMMY_SERVER_NO_OWNER:
					{
						dummy = ptr_new DummyObject();

						dummy->CreateServer(info, create_info);

						dummy->SetSyncMaster(false);

						dummy->Initialize();

						dummy->SetPosition(create_info.position);
						dummy->SetRotation(create_info.rotation);
					}
					break;
			}

			if (dummy)
			{
				dummy->sub_type = sub_type;
				dummy_object_set.Add(uid, dummy);
			}
		}
		else
		{
			sharedc_ptr(DummyObject) dummy = NullPtr;
			DummyBaseCreateInfo create_info;
			if(need_stepfather != 0)
			{
				ServerDummyCreateWithStepFatherInfo stepfather_info;
				readUserData(pbuffer, length, 0, stepfather_info);
				create_info = stepfather_info.dummy_base_info;
			}
			else
			{
				readUserData(pbuffer, length, 0, create_info);
			}

			sharedc_ptr(DummyObjectInfo) info = ptr_new DummyObjectInfo();
			info->dummy_id = uid;
			info->owner_id = owner_id;
			info->level = create_info.level;
			info->hp = create_info.max_hp;
			info->move_keep_time = create_info.move_keep_time;
			info->move_speed = create_info.move_speed;
			info->tower_key = create_info.tower_key;
			info->sub_type = sub_type;

			info->LoadConfig(create_info.key);

			switch (type)
			{
			case DummyObject::DUMMY_BASE:
				{
					dummy = ptr_new DummyObject();

					dummy->Create(info, create_info);
					dummy->owner_team = team;
					dummy->need_stepfather = need_stepfather  == 1;
					dummy->can_hurt = can_hurt  == 1;

					if(GetPlayer() && GetPlayer()->uid == owner_id)
					{
						dummy->SetSyncMaster(true);
					}
					else
					{
						dummy->SetSyncMaster(false);
					}

					dummy->Initialize();

					//if(dummy->IsSyncMaster())
					{
						dummy->SetRotation(create_info.rotation);
						dummy->SetPosition(create_info.position);
					}
				}
				break;
			case DummyObject::DUMMY_MACHINE_TURRENT:
				{
					dummy = ptr_new MachineGunTurret();
				
					dummy->Create(info, create_info);
					dummy->owner_team = team;
					dummy->need_stepfather = need_stepfather == 1;
					dummy->can_hurt = can_hurt  == 1;

					dummy->SetLifeTime(create_info.life_time);

					if(GetPlayer() && GetPlayer()->uid == owner_id)
					{
						dummy->SetSyncMaster(true);
					}
					else
					{
						dummy->SetSyncMaster(false);
					}

					dummy->Initialize();


					{
						dummy->SetRotation(create_info.rotation);
						dummy->SetPosition(create_info.position);
					}
					dummy->UpdateBaseRotation();

					tempc_ptr(MachineGunTurret) t = ptr_dynamic_cast<MachineGunTurret>(dummy);
					t->SetAmmoCount(create_info.current_ammo_count);

					if (RoomOption::kEditMode != gLevel->game_type)
					{
						FMOD_VECTOR vel = {0, 0, 0};
						String str = String::Format("bj/weapon/3d/machinegun/machinegun_setting");
						FmodSystem::Play3DEvent(str.Str(),(const FMOD_VECTOR &)dummy->GetPosition(),vel);
					}
				}
				break;
			//case DummyObject::DUMMY_MEDICAL:
			//	{
			//		dummy = ptr_new MedicalDummy();

			//		dummy->Create(info, create_info);

			//		if(GetPlayer() && GetPlayer()->uid == owner_id)
			//		{
			//			dummy->SetSyncMaster(true);
			//		}
			//		else
			//		{
			//			dummy->SetSyncMaster(false);
			//		}

			//		dummy->Initialize();


			//		//if(dummy->IsSyncMaster())
			//		{
			//			dummy->SetPosition(create_info.position);
			//			dummy->SetRotation(create_info.rotation);
			//		}
			//	}
			//	break;
			}

			if(dummy)
			{
				dummy->sub_type = sub_type;
				dummy_object_set.Add(uid, dummy);
				tempc_ptr(Character) player = GetCharacter(owner_id);
				if (player && !dummy->need_stepfather)
				{
					player->tower_gun_count +=1;
					tempc_ptr(WeaponBase) weapon;
					weapon = player->GetWeaponById(0);
					if(tempc_ptr(GunTowerBuilder) oGunTowerBuilder = ptr_dynamic_cast<GunTowerBuilder>(weapon))
					{
						oGunTowerBuilder->on_request_planting = false;
					}
					if(tempc_ptr(GunTowerBuilderPlus) oGunTowerBuilder = ptr_dynamic_cast<GunTowerBuilderPlus>(weapon))
					{
						oGunTowerBuilder->EndPlant();
					}
				}
			}
		}
	}

	bool Level::RemoveDummyObject(uint uid)
	{
		return dummy_object_set.Remove(uid);
	}

	bool Level::IsMachineGunTurretAreaInside(const Core::Vector3 &pos, const float w, const float h)
	{
		//Vector3 pt[4];
		//pt[0] =Vector3(pos.x-w/2.f, pos.y, pos.z-h/2.f);
		//pt[1] =Vector3(pos.x-w/2.f, pos.y, pos.z+h/2.f);
		//pt[2] =Vector3(pos.x+w/2.f, pos.y, pos.z-h/2.f);
		//pt[3] =Vector3(pos.x+w/2.f, pos.y, pos.z+h/2.f);

		//for (uint i = 0; i < gLevel->machinegunturretarea.Size(); ++i)
		//{
		//	AxisAlignedBox aabb = gLevel->machinegunturretarea.GetAt(i);

		//	if(aabb.IsPointInside(pt[0]) && aabb.IsPointInside(pt[1]) && aabb.IsPointInside(pt[2]) && aabb.IsPointInside(pt[3]))
		//	{
		//		for (uint i = 0; i < gLevel->nomachinegunturretarea.Size(); ++i)
		//		{
		//			AxisAlignedBox aabb1 = gLevel->nomachinegunturretarea.GetAt(i);
		//			if (aabb1.IsPointInside(pt[0]) || aabb1.IsPointInside(pt[1]) || aabb1.IsPointInside(pt[2]) || aabb1.IsPointInside(pt[3]))
		//				return false;
		//			aabb1.IsIntersectWithAABB()
		//		}
		//		return true;
		//	}
		//}
		AxisAlignedBox aabb_drop(Vector3(pos.x-w/2.f, pos.y, pos.z-h/2.f), Vector3(pos.x+w/2.f, pos.y, pos.z+h/2.f));

		for (uint i = 0; i < gLevel->machinegunturretarea.Size(); ++i)
		{
			AxisAlignedBox aabb = gLevel->machinegunturretarea.GetAt(i);

			if(aabb.IsIncludeAABB(aabb_drop))
			{
				for (uint i = 0; i < gLevel->nomachinegunturretarea.Size(); ++i)
				{
					AxisAlignedBox aabb1 = gLevel->nomachinegunturretarea.GetAt(i);
					if(aabb1.IsIntersectWithAABB(aabb_drop))
					{
						//Console.WriteLinef("(2)in bad area");
						return false;
					}
				}
				//Console.WriteLinef("(2)in good area");
				return true;
			}
		}
		//Console.WriteLinef("(2)not in ok area");
		return false;
	}
	bool Level::IsMachineGunTurretArea(const Core::Vector3 &pos)
	{
		for (uint i = 0; i < gLevel->machinegunturretarea.Size(); ++i)
		{
			AxisAlignedBox aabb = gLevel->machinegunturretarea.GetAt(i);

			if(aabb.IsPointInside(pos))
			{
				for (uint i = 0; i < gLevel->nomachinegunturretarea.Size(); ++i)
				{
					AxisAlignedBox aabb1 = gLevel->nomachinegunturretarea.GetAt(i);
					if (aabb1.IsPointInside(pos))
					{
						//Console.WriteLinef("(1)in bad area");
						return false;
					}
				}
				//Console.WriteLinef("(1)in good area");
				return true;
			}
		}
		//Console.WriteLinef("(1)not in ok area");
		return false;
	}

	void Level::SetEditMapSize(float w, float h)
	{
		m_fEditMapWidth =w;
		m_fEditMapHeight =h;
	}
	float Level::GetEditMapWidth()
	{
		return m_fEditMapWidth;
	}
	float Level::GetEditMapHeight()
	{
		return m_fEditMapHeight;
	}


	void Level::SetEditMapItemSize(float s)
	{
		m_fEditMapItemSize =s;
	}
	float Level::GetEditMapItemSize()
	{
		return m_fEditMapItemSize;
	}

	void Level::BombMode_CancelDefuseBomb()
	{
		tempc_ptr(Character) player = GetPlayer();

		if(!player || player->GetTeam() != 0 || game_type != RoomOption::kBombMode)
			return;

		if(!bomb_on_ground)
			return;

		if(player->IsLockStateByType(kLSMove) && bomb_defusing)
		{
			gGame->channel_connection->CancelDefuseBomb();
			player->UnLockStateByType(kLSMove);
			bomb_defusing = false;
		}
	}

	void Level::ZombieMode_SaveDying()
	{
		tempc_ptr(Character) player = GetPlayer();

		if(!player || player->GetTeam() != 0 || game_type != RoomOption::kZombieMode || zombie_saving_dying)
			return;

		if(player->IsReady() && !player->IsDied() && !player->zombie_dying_flag)
		{
			Vector3 pos = player->GetCameraPosition();
			Vector3 dir = Vector3(0, 0, -1) * player->GetLookDir();

			NxRay ray;
			ray.orig = (const NxVec3 &)pos;
			ray.dir = (const NxVec3 &)dir.Normalize();

			NxRaycastHit hit;

			uint group_id = 0;
			group_id |= 1 << PhysxSystem::kGroupStart;

			NxShape* shape = gPhysxScene->raycastClosestShape(ray, NX_ALL_SHAPES, hit, group_id, 2000);
			Vector3 play_pos;
			if (shape)
			{
				if(hit.distance < 5)
				{
					NxActor& actor = shape->getActor();
					tempc_ptr(Character) p = Character::FromNxActor(actor);
					if(p && p->uid != player->uid)
					{
						gGame->channel_connection->StartSaveDying(p->uid);
						zombie_saving_dying = true;
						player->LockStateByType(kLSMove);
					}
				}
			}
		}

	}

	void Level::ZombieMode_CancelSaveDying()
	{
		tempc_ptr(Character) player = GetPlayer();

		if(!player)
			return;
		
		if(player->GetTeam() != 0 || game_type != RoomOption::kZombieMode)
			return;

		if(!zombie_saving_dying)
			return;
		
		gGame->channel_connection->CancelSaveDying();

		zombie_saving_dying = false;
		player->UnLockStateByType(kLSMove);

	}

	bool Level::SetAmmoDead( const byte uid, U16 index)
	{
		sharedc_ptr(AmmoSet) ammo_hash = gLevel->character_ammoset.Get(uid, NullPtr);
		if (ammo_hash)
		{
			sharedc_ptr(AmmoBase) ammo = ammo_hash->Get(index, NullPtr);
			if(ammo)
			{
				ammo->is_dead = true;
			}
			else
			{
				return false;
			}
		}
		else
		{
			return false;
		}

		return true;
	}
	
	void Level::InitializeVehicleInfo(const PushVehicleInfo& info_red, const PushVehicleInfo& info_blue)
	{
		if(!vehicle[0] && !vehicle[1])
		{
			vehicle[0] = ptr_new Vehicle(info_red);
			vehicle[1] = ptr_new Vehicle(info_blue);

			vehicle[0]->Initialize();
			vehicle[1]->Initialize();

			old_vehice_length_red = 0.f;
			old_vehice_length_blue = 0.f;
			vehice_fPersert_red = 0.f;
			vehice_fPersert_blue = 0.f;
			vehice_timer_red = 0.f;  
			vehice_timer_blue = 0.f;
		}
		vehice_fPersert_red = 0.f;
		vehice_fPersert_blue = 0.f;
		old_vehice_length_red = vehicle[0]->current_vehicle_info.current_length;
		old_vehice_length_blue = vehicle[1]->current_vehicle_info.current_length;
		vehicle[0]->InitializeVehicleInfo(info_red);
		vehicle[1]->InitializeVehicleInfo(info_blue);
		if (vehicle[0]->current_vehicle_info.current_length - old_vehice_length_red > 0.01f)
			vehice_timer_red = 0.5f;	//���ʱ��Ҫ�ͷ�����һ��
		if (vehicle[1]->current_vehicle_info.current_length - old_vehice_length_blue > 0.01f)
			vehice_timer_blue = 0.5f;	//���ʱ��Ҫ�ͷ�����һ��
	}

	void Level::UpdateVehicleInfo(const PushVehicleInfo& info_red, const PushVehicleInfo& info_blue)
	{
		old_vehice_length_red = vehicle[0]->current_vehicle_info.current_length;
		old_vehice_length_blue = vehicle[1]->current_vehicle_info.current_length;
		vehicle[0]->UpdateVehicleInfo(info_red);
		vehicle[1]->UpdateVehicleInfo(info_blue);
		if (vehicle[0]->current_vehicle_info.current_length - old_vehice_length_red < 0)
			vehice_timer_red = 0.5f;
		if (Core::Abs(vehicle[0]->current_vehicle_info.current_length - old_vehice_length_red) > 0.01f)
			vehice_timer_red = 0.5f;	//���ʱ��Ҫ�ͷ�����һ��
		if (Core::Abs(vehicle[1]->current_vehicle_info.current_length - old_vehice_length_blue) > 0.01f)
			vehice_timer_blue = 0.5f;	//���ʱ��Ҫ�ͷ�����һ��
		//LogSystem.WriteLinef("vehicle[1]->current_vehicle_info.current_length = %f",vehicle[1]->current_vehicle_info.current_length);
	}

	void Level::ClearDefuseBombState()
	{
		bomb_defuse_timer = -1.f;
		bomb_defuse_total = -1.f;
		bomb_defusing = false;
		if (gLevel->audio_bomb_2d_Defuse)
			gLevel->audio_bomb_2d_Defuse->stop();
		if (gLevel->audio_bomb_3d_Defuse)
			gLevel->audio_bomb_3d_Defuse->stop();
		if (gLevel->audio_bomb_Planting_Defusing)
			gLevel->audio_bomb_Planting_Defusing->stop();
	}

	void Level::StartDefuseBombState(float t)
	{
		bomb_defuse_timer = t;
		bomb_defuse_total = t;
		bomb_defusing = true;
	}

	float Level::GetBombDefusingState()
	{
		tempc_ptr(Character) viewer = gLevel->GetViewer();
		if(viewer && viewer->IsReady() && !viewer->IsDied())
		{
			if(bomb_defusing && bomb_defuse_timer > 0.f && bomb_defuse_total > EPSILON)
			{
				return bomb_defuse_timer/bomb_defuse_total; 
			}
		}
		
		return -1;
	}

	float Level::GetBombPlantingState()
	{
		tempc_ptr(Character) viewer = gLevel->GetViewer();
		if(viewer)
		{
			tempc_ptr(Bomb) bomb = viewer->GetBomb(true);
			if(bomb && bomb->bomb_planting && bomb->bomb_info->plant_time > EPSILON && viewer->bomb_plant_timer >= 0.f)
			{
				float percent = viewer->bomb_plant_timer/bomb->bomb_info->plant_time;
				return percent;
			}
		}
		return -1.f;
	}

	float Level::GetBombPlantedTimer()
	{
		if(bomb_on_ground && bomb_explode_timer > 0.f)
		{
			return bomb_explode_timer;
		}
		return -1.f;
	}

	bool Level::IsCanPlantBomb()
	{
		tempc_ptr(Character) viewer = gLevel->GetViewer();
		if(!viewer)
			return false;
		Vector3 position = viewer->GetPosition();
		for (uint i = 0; i < bomb_plant_aabb.Size(); i++)
		{
			const AxisAlignedBox& aabb = bomb_plant_aabb[i];
			if(aabb.IsPointInside(position))
				return true;
		}
		return false;
	}
	void Level::UpdateReplayUI()
	{
		tempc_ptr(StateMainGame) state_main = ptr_dynamic_cast<StateMainGame>(gGame->machine.CurrentState());
		if(state_main && state_main->ui)
		{
			InGameUINew::ButtonInfo *button = &state_main->ui->button[0];
			Core::Array<byte> &button_content = state_main->ui->button_content;

			Vector3 rt_size = gGame->guiSys->GetSize();
			Vector2 screen_size = gGame->screen->GetSize();

			int _x = -20-44 * 7 / 2;
			for(int i = 1; i <= 7 ; i++)
			{
				int id = button_content[i - 1];

				if(id == InGameUINew::CHANGECAMERA)
					continue;

				Vector2 pos = gGame->input->GetCursorPosition();
				pos = gGame->screen->ScreenToClient(pos);

				float ratio_x = screen_size.x / rt_size.x;
				float ratio_y = screen_size.y / rt_size.y;

				Core::Rectangle rect = button[i - 1].rect, rect1;

				rect.Min.x = (rect.Min.x + rt_size.x / 2 + _x);
				rect.Max.x = (rect.Min.x + 44);

				rect.Min.y = (rect.Min.y + rt_size.y - 42);
				rect.Max.y = (rect.Min.y + 44);

				rect1.Min.x = rect.Min.x * ratio_x;
				rect1.Max.x = rect.Max.x * ratio_x;
				rect1.Min.y = rect.Min.y * ratio_y;
				rect1.Max.y = rect.Max.y * ratio_y;

				if(rect1.IsPointInside(pos))
				{
					if(gGame->input->IsKeyDown(MC_LEFT_BUTTON))
					{
						if(id != 8)
							button[i - 1].state = 2;
					}
					else if(gGame->input->IsKeyReleased(MC_LEFT_BUTTON))
					{
						switch(id)
						{
						case Client::InGameUINew::STOP:
							{
								if(gGame->channel_connection)
								{
									tempc_ptr(StateMainGame) state_main = ptr_dynamic_cast<StateMainGame>(gGame->machine.CurrentState());
									if (state_main)
									{
										state_main->quit_game = true;
									}
									return;
								}
							}
							break;
						case Client::InGameUINew::PRINTSCREEN:
							{
								gGame->bSavePhoto = true;
							}
							break;
						case Client::InGameUINew::PAUSE:
							{
								button_content[i - 1] = Client::InGameUINew::PLAY;
								gGame->global->SetGameStop(false);
							}
							break;
						case Client::InGameUINew::PLAY:
							{
								button_content[i - 1] = Client::InGameUINew::PAUSE;
								gGame->global->SetGameStop(true);
							}
							break;
						case Client::InGameUINew::SLOWPLAY:
							{
								if(button[i - 1].sub_state == false)
									gGame->global->SetGameRate(0.5f);
								else
									gGame->global->SetGameRate(1.0f);

								button[i - 1].sub_state = !button[i - 1].sub_state;
							}
							break;
						case Client::InGameUINew::QUICKPLAY:
							{
								if(button[i - 1].sub_state == false)
									gGame->global->SetGameRate(1.5f);
								else
									gGame->global->SetGameRate(1.0f);

								button[i - 1].sub_state = !button[i - 1].sub_state;
							}
							break;
						case Client::InGameUINew::CHANGECAMERA:
							{
								tempc_ptr(Character) view_character = gLevel->GetViewer();
								if(view_character)
								{
									Character::ViewMode view_mode = view_character->GetViewMode();

									if (view_character->camera_distance < 0.5f)
									{
										view_character->camera_distance = 4.f;
										view_character->camera_rotation_offset = Quaternion::kIdentity;
									}
									else
									{
										view_character->camera_distance = 0;
										view_character->camera_rotation_offset = Quaternion::kIdentity;
									}
								}
							}
							break;
						}	

						button[i - 1].state = 1;
					}
					else
					{
						if(id != 8)
							button[i - 1].state = 1;
						else
							button[i - 1].state = 2;
					}
				}
				else
					button[i - 1].state = 0;
			}
		}
	}

	tempc_ptr(Character) Level::GetPveClientByName(const Core::String &name)
	{

		const Array<sharedc_ptr(Character)> &array_boss = GetCharacters();
		for (U32 i = 0; i < array_boss.Size(); i++)
		{
			if (array_boss[i]->GetName() == name)
				return array_boss[i];
		}

		tempc_ptr(Character) player = GetPlayer();
		if (player && player->GetName() == name)
			return player;

		return NullPtr;
	}

	void Level::GetLeastBloodCharacter(int team)
	{
		tempc_ptr(Character) least = GetPlayer();
		int blood = least->hp;
		const Core::Array<sharedc_ptr(Character)> & characters = GetCharacters();
		for (uint i = 0; i < characters.Size(); i++)
		{
			tempc_ptr(Character) c = characters[i];
			if (c && c->GetTeam() == team)
			{
				if (blood > c->hp || blood == 0)
				{
					blood = c->hp;
					least = c;
				}
				else if (blood == c->hp)
				{
					if (c->uid < least->uid)
					{
						blood = c->hp;
						least = c;
					}
				}
			}
		}
		if (least)
			level_eventmgr->SetClientScriptNumberValue("BOSSPVE_LEAST_BLOOD", least->uid);
	}

	void Level::GetMaximumBloodCharacter(int team)
	{
		tempc_ptr(Character) max = GetPlayer();
		int blood = max->hp;
		const Core::Array<sharedc_ptr(Character)> & characters = GetCharacters();
		for (uint i = 0; i < characters.Size(); i++)
		{
			tempc_ptr(Character) c = characters[i];
			if (c && c->GetTeam() == team)
			{
				if (blood < c->hp || blood == 0)
				{
					blood = c->hp;
					max = c;
				}
				else if (blood == c->hp)
				{
					if (c->uid < max->uid)
					{
						blood = c->hp;
						max = c;
					}
				}
			}
		}
		if (max)
			level_eventmgr->SetClientScriptNumberValue("BOSSPVE_MAXIMUM_BLOOD", max->uid);
	}

	void Level::SetCharactersByBlood(int team)
	{
		Core::Array<uint> temp_characters_uid;
		Core::Array<int> temp_characters_hp;
		tempc_ptr(Character) max = GetPlayer();
		if (max)
		{
			temp_characters_uid.PushBack(max->uid);
			temp_characters_hp.PushBack(max->hp);
		}
		const Core::Array<sharedc_ptr(Character)> & characters = GetCharacters();
		for (uint i = 0; i < characters.Size(); i++)
		{
			tempc_ptr(Character) c = characters[i];
			if (c && c->GetTeam() == team && !c->IsDied())
			{
				temp_characters_uid.PushBack(c->uid);
				temp_characters_hp.PushBack(c->hp);
			}
		}
		for (int i = 0; i < (int)temp_characters_hp.Size();++i)
		{
			for (int j = i + 1; j < (int)temp_characters_hp.Size();++j)
			{
				if (temp_characters_hp[i] < temp_characters_hp[j])
				{
					int hp = temp_characters_hp[i];
					temp_characters_hp[i] = temp_characters_hp[j];
					temp_characters_hp[j] =  hp;
					int uid = temp_characters_uid[i];
					temp_characters_uid[i] = temp_characters_uid[j];
					temp_characters_uid[j] = uid;
				}
				else if (temp_characters_hp[i] == temp_characters_hp[j])
				{
					if (temp_characters_uid[i] < temp_characters_uid[j])
					{
						int hp = temp_characters_hp[i];
						temp_characters_hp[i] = temp_characters_hp[j];
						temp_characters_hp[j] = hp;
						int uid = temp_characters_uid[i];
						temp_characters_uid[i] = temp_characters_uid[j];
						temp_characters_uid[j] = uid;
					}
				}
			}
		}
		if (temp_characters_uid.Size() > 0 && temp_characters_uid.Size() == temp_characters_hp.Size())
		{
			for (int i = 0; i < 10;i++)
			{
				Core::String str = Core::String::Format("BOSSPVE_BLOOD_%d",i);
				level_eventmgr->SetClientScriptNumberValue(str.Str(), -1);
			}
			for (int i = 0; i < (int)temp_characters_uid.Size();i++)
			{
				Core::String str = Core::String::Format("BOSSPVE_BLOOD_%d",i);
				level_eventmgr->SetClientScriptNumberValue(str.Str(), temp_characters_uid[i]);
				//LogSystem.WriteLinef("%d   %d", i, temp_characters_uid[i]);
			}
		}
	}
}