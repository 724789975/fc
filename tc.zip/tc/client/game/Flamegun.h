namespace Client
{
	struct FlameGunInfo : public GunInfo
	{
		FlameGunInfo()
		{
			weapon_type = kWeaponTypeFlameGun;
		}


		float special_distance;	//���⼼�����þ���
		float special_range;		//���⼼�����÷�Χ
		float special_lasttime;	//���⼼�ܳ���ʱ��

		float particlenum;
		float show_speed;
		float hurtrange;




		Core::Identifier	flame_particle;		//������Ч
	};

	class FlameGun : public GunBase
	{
	public:
		FlameGun(by_ptr(FlameGunInfo) info);
		~FlameGun();
	public:
		DECLARE_PDE_ATTRIBUTE_R(weapon_info, tempc_ptr(FlameGunInfo))
		{
			return flamegun_info;
		}

	public:

		/// updateeffect
		virtual void UpdateEffect(float time);
		
		/// update
		virtual void Update(float time);
		
		//FireEffect
		virtual void FireEffect(bool isboost = false);

		//FireCheck
		virtual void FireCheck(const Core::Vector3 & position, const Core::Quaternion & rotation, float spread, bool do_effect  = true);

		/// initialize
		virtual void Initialize();

		/// can active
		virtual bool CanActive();

		/// active
		virtual void Active();

		/// inactive
		virtual	void Inactive();
		/// get weapon type
		virtual uint GetWeaponType();
		/// Special abilities
		virtual void SpecialAbilities(bool keydown = false);

	public:
		/// fire
		virtual bool Fire();
		bool bSpecialing;
		U32 CheckWindReverse();
		void EndCheckWindReverse();
		const Core::Vector3 GetFirePos();
	private:
		sharedc_ptr(PlayerSkill)		skill;
		struct FlameParticle
		{
			sharedc_ptr(Client::ParticleSystem) particle;
			Core::Vector3 direction1;
			Core::Vector3 direction2;
			Core::Vector3 curpos;
			F32 distance1;
			F32 distance2;
			F32 speed;
			F32 nowdistance1;
			F32 nowdistance2;
			bool havedct2;
			FlameParticle():
			direction1(Core::Vector3::kZero)
				,direction2(Core::Vector3::kZero)
				,curpos(Core::Vector3::kZero)
				,distance1(0.f)
				,distance2(0.f)
				,speed(0.f)
				,nowdistance1(0.f)
				,nowdistance2(0.f)
				,havedct2(false)
			{

			}
		};

		Core::Deque<sharedc_ptr(FlameParticle)> dequeFlame;
		Core::Array<tempc_ptr(Character)> arry_character;
		sharedc_ptr(Client::ParticleSystem) idleparticle;
		sharedc_ptr(Client::ParticleSystem) windparticle;
		Core::Array<tempc_ptr(AmmoBase)> arry_windprojected;
		Core::Array<tempc_ptr(Character)> arry_windcharacter;
	public:
		sharedc_ptr(FlameGunInfo)	flamegun_info;
		
	};

}