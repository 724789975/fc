#include "pch.h"

using namespace Core;

DEFINE_PDE_TYPE_CLASS(Client::LevelEvent)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_PROPERTY_RW(Name);
		ADD_PDE_EVENT(EventOperate);
	}
};

REGISTER_PDE_TYPE(Client::LevelEvent);

DEFINE_PDE_TYPE_CLASS(Client::LevelEventMgr)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_METHOD(LoadEventScript);
		ADD_PDE_METHOD(AddFrameEvent);
		ADD_PDE_METHOD(DebugOutput);

		ADD_PDE_METHOD(SetClientScriptStringValue);
		ADD_PDE_METHOD(GetClientScriptStringValue);
		ADD_PDE_METHOD(HasClientScriptStringValue);
		ADD_PDE_METHOD(SetClientScriptNumberValue);
		ADD_PDE_METHOD(GetClientScriptNumberValue);
		ADD_PDE_METHOD(HasClientScriptNumberValue);

		//ADD_PDE_METHOD(SetServerScriptStringValue);
		ADD_PDE_METHOD(GetServerScriptStringValue);
		ADD_PDE_METHOD(HasServerScriptStringValue);
		//ADD_PDE_METHOD(SetServerScriptNumberValue);
		ADD_PDE_METHOD(GetServerScriptNumberValue);
		ADD_PDE_METHOD(HasServerScriptNumberValue);
	}
};

REGISTER_PDE_TYPE(Client::LevelEventMgr);

static const String SYS_FRAMETIME_KEY = "SYS_FRAMETIME";

namespace Client
{
//////////////////////////////////////////////////////////////////////////////////////////////
	LevelEvent::LevelEvent()
	{
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	LevelEventMgr::LevelEventMgr()
		: m_LuaState(NULL)
	{
	}

	LevelEventMgr::~LevelEventMgr()
	{
		Terminate();
	}

	void LevelEventMgr::Initialize()
	{
		Terminate();

		m_LuaState = Lua::LuaState::NewState();
		m_LuaState->SetDelegateAll();
		m_LuaState->OpenLibs();
		
		m_LuaState->PushPtr(gGame->langs);
		m_LuaState->SetGlobal("lang");

		m_LuaState->PushPtr(ptr_static_cast<LevelEventMgr>(this));
		m_LuaState->SetGlobal("eventmgr");

		m_LuaState->PushPtr(ptr_static_cast<Level>(gLevel));
		m_LuaState->SetGlobal("level");

		m_LuaState->PushPtr(PDE_TYPE_OF(Vector3)->GetConstructor());
		m_LuaState->SetGlobal("Vector3");

		m_LuaState->PushPtr(PDE_TYPE_OF(Vector4)->GetConstructor());
		m_LuaState->SetGlobal("Vector4");

		m_LuaState->PushPtr(PDE_TYPE_OF(Quaternion)->GetConstructor());
		m_LuaState->SetGlobal("Quaternion");
		m_timer = 0.f;
	}

	void LevelEventMgr::Terminate()
	{
		ClearClientScriptValue();

		ClearServerScriptValue();

		m_FrameEventMap.Clear();

		if (m_LuaState)
		{
			m_LuaState->Close();
			m_LuaState = NULL;
		}
	}

	void LevelEventMgr::Reset()
	{
		ClearClientScriptValue();

		ClearServerScriptValue();

		m_FrameEventMap.Clear();

		if (m_LuaState)
			m_LuaState->GC(Lua::GCCOLLECT, 0);
	}

	void LevelEventMgr::TimeStepUpdate(float frame_time)
	{
		PROFILE("LevelEventMgr::TimeStepUpdate");

		SetClientScriptNumberValue(SYS_FRAMETIME_KEY, frame_time);
		
		tempc_ptr(Character) c = gLevel->GetCharacter(gLevel->pveboss_uid);
		if (c && c->IsDied())
		{
			return;
		}

		HashSet<String, sharedc_ptr(LevelEvent)>::Enumerator it(m_FrameEventMap);
		while (it.MoveNext())
		{
			tempc_ptr(LevelEvent) level_event = it.Value();
			if (level_event)
				level_event->EventOperate.Fire(ptr_static_cast<LevelEventMgr>(this), EventArgs());

		}
		
		m_timer += frame_time;
		if (m_timer >= 1.f)
		{
			m_timer = 0.f;
			m_LuaState->GC(Lua::GCCOLLECT, 0);
		}
		//int num = m_LuaState->GC(Lua::GCCOUNT, 0);
		//LogSystem.WriteLinef("%d",num);
		//LogSystem.WriteLinef("m_ClientScriptStringValue.Size() = %d",m_ClientScriptStringValue.Size());
		//LogSystem.WriteLinef("m_ServerScriptStringValue.Size() = %d",m_ServerScriptStringValue.Size());
		//LogSystem.WriteLinef("m_ClientScriptNumberValue.Size() = %d",m_ClientScriptNumberValue.Size());
		//LogSystem.WriteLinef("m_ServerScriptNumberValue.Size() = %d",m_ServerScriptNumberValue.Size());
	}

	bool LevelEventMgr::LoadEventScript(const String &file_name)
	{
		bool result = false;

		CStrBuf<256> path;
		path.format("/level/%s", file_name.Str());

		sharedc_ptr(ScriptLua) lua = RESOURCE_LOAD(path, false, ScriptLua);
		if (lua)
		{
			if (m_LuaState->LoadBuffer(lua->GetBuffer(), lua->GetSize(), path) == 0)
			{
				if (m_LuaState->DoCall(0, 0))
				{
					const char *msg = m_LuaState->ToString(-1);
					if (msg) Console.WriteLine(msg);
					m_LuaState->Pop(1);
				}
				else
				{
					result = true;
				}

			}
			else
			{
				const char *msg = m_LuaState->ToString(-1);
				if (msg) Console.WriteLine(msg);
				m_LuaState->Pop(1);
			}
		}

		return result;
	}

	bool LevelEventMgr::AddFrameEvent(by_ptr(LevelEvent) frame_event)
	{
		if (frame_event && !m_FrameEventMap.Contains(frame_event->GetName()))
		{
			m_FrameEventMap.Set(frame_event->GetName(), frame_event);

			return true;
		}

		LogSystem.WriteLinef("AddFrameEvent failed, name : %s", frame_event ? frame_event->GetName() : "null");

		return false;
	}

	void LevelEventMgr::DebugOutput(const Core::String &text)
	{
		Console.WriteLine(text);
	}

	void LevelEventMgr::SetClientScriptStringValue(const String &key, const String &value)
	{
		m_ClientScriptStringValue.Set(key, value);
	}

	String LevelEventMgr::GetClientScriptStringValue(const String &key)
	{
		return m_ClientScriptStringValue.Get(key, String::kEmpty);
	}

	bool LevelEventMgr::HasClientScriptStringValue(const Core::String &key)
	{
		return m_ClientScriptStringValue.Contains(key);
	}

	void LevelEventMgr::SetClientScriptNumberValue(const String &key, float value)
	{
		m_ClientScriptNumberValue.Set(key, value);
	}

	float LevelEventMgr::GetClientScriptNumberValue(const String &key)
	{
		return m_ClientScriptNumberValue.Get(key, 0);
	}

	bool LevelEventMgr::HasClientScriptNumberValue(const Core::String &key)
	{
		return m_ClientScriptNumberValue.Contains(key);
	}

	void LevelEventMgr::ClearClientScriptValue()
	{
		m_ClientScriptStringValue.Clear();
		m_ClientScriptNumberValue.Clear();
	}

	void LevelEventMgr::SetServerScriptStringValue(const String &key, const String &value)
	{
		m_ServerScriptStringValue.Set(key, value);
	}

	String LevelEventMgr::GetServerScriptStringValue(const String &key)
	{
		return m_ServerScriptStringValue.Get(key, String::kEmpty);
	}

	bool LevelEventMgr::HasServerScriptStringValue(const Core::String &key)
	{
		return m_ServerScriptStringValue.Contains(key);
	}

	void LevelEventMgr::SetServerScriptNumberValue(const String &key, float value)
	{
		m_ServerScriptNumberValue.Set(key, value);
	}

	float LevelEventMgr::GetServerScriptNumberValue(const String &key)
	{
		return m_ServerScriptNumberValue.Get(key, 0);
	}

	bool LevelEventMgr::HasServerScriptNumberValue(const Core::String &key)
	{
		return m_ServerScriptNumberValue.Contains(key);
	}

	void LevelEventMgr::ClearServerScriptValue()
	{
		m_ServerScriptStringValue.Clear();
		m_ServerScriptNumberValue.Clear();
	}
}
