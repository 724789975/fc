namespace Client
{
	struct IkJoint
	{
		/// constructor
		IkJoint()
			: joint_index(-1)
			, weight(1)
			, hinge_axis(0, 0, -1)
			, hinge_base(0, 1, 0)
			, lock(false)
		{
		}

		bool GetJointRotation(const Core::Vector3 & to_effector, const Core::Vector3 & to_target, const Core::Quaternion & current_rot, bool is_root, Core::Quaternion & rot) const;

		int				joint_index;
		float			weight;
		Core::Vector3	hinge_axis;		// hinge axis
		Core::Vector3	hinge_base;		// hinge base
		Transform		transform;
		bool			lock;
	};

	static void GetVertical(const Core::Vector3 & v0, Core::Vector3 & v1)
	{
		if (Core::Abs(v0.x) > Core::EPSILON || Core::Abs(v0.y) > Core::EPSILON)
		{
			v1.x = v0.y;
			v1.y = -v0.x;
			v1.z = 0.f;
			v1.Normalize();
		}
		else
		{
			v1.x = 1.f;
			v1.y = 0.f;
			v1.z = 0.f;
		}
	}

	class IkSolver
	{
	private:
		static void RotateToPlane(Core::Array<sharedc_ptr(IkJoint)> & joints, const Core::Vector3 & target)
		{
			int size = joints.Size();

			if (size < 1)
				return;

			tempc_ptr(IkJoint) root = joints[0];

			if (!root)
				return;

			tempc_ptr(IkJoint) effector = joints[size - 1];

			if (!effector)
				return;
			
			Core::Vector3 to_target = target - root->transform.position;
			Core::Vector3 to_effector = effector->transform.position - root->transform.position;
			Core::Quaternion root_rot;
			root_rot.SetFromTo(to_effector, to_target);

			for(uint i = 0; i < joints.Size(); ++i)
			{
				tempc_ptr(IkJoint) joint = joints[i];
				if (joint)
				{
					joint->transform.position = (joint->transform.position - root->transform.position) * root_rot + root->transform.position;
					joint->transform.rotation = root_rot * joint->transform.rotation;
				}
			}
		}

	public:
		static void Solver(Core::Array<sharedc_ptr(IkJoint)> & joints, const Transform & target, float iteration = 10, float lerance = 0.01f);
	};
}