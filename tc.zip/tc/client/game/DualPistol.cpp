#include "pch.h"

using namespace Client;
using namespace Core;

DEFINE_PDE_TYPE_CLASS(Client::DualPistolInfo)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Client::PistolInfo);

		ADD_PDE_DEFAULT_CONSTRUCTOR();
	}
};

DEFINE_PDE_TYPE_CLASS(Client::DualPistol)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Client::Pistol);
	}
};

REGISTER_PDE_TYPE(Client::DualPistolInfo);
REGISTER_PDE_TYPE(Client::DualPistol);

DualPistol::DualPistol(by_ptr(DualPistolInfo) info):Pistol(info)
{
}
bool DualPistol::Fire()
{
	return Pistol::Fire();
}

uint DualPistol::GetWeaponType()
{
	return kWeaponTypeDualPistol;
}

/// initialize
void DualPistol::Initialize()
{
	Pistol::Initialize();

	if (skeleton && animation_list && animation_set)
	{
		sharedc_ptr(AnimationNodePose) node = ptr_new AnimationNodePose(skeleton);
		node->SetAnimation("idle_drop", animation_set);
		animation_list->AddNode("idle_drop", node);

		node = ptr_new AnimationNodePose(skeleton);
		node->SetAnimation("idle_lobby", animation_set);
		animation_list->AddNode("idle_lobby", node);
	}
}

/// update animation
void DualPistol::UpdateAnimation(float time)
{
	if (!GetOwner())
	{
		if (animation_list)
			animation_list->SetActiveNode("idle_drop");
	}


	int state = 0;

	if (gRender && gRender->lobby_pipeline)
		state = gRender->lobby_pipeline->lobby_state;

	if (state == LobbyPipeline::kWeaponPreview || state == LobbyPipeline::kWeaponModify)
	{
		if (animation_list)
			animation_list->SetActiveNode("idle_lobby");
	}

	WeaponBase::UpdateAnimation(time);
}

/// set left weapon transform
void DualPistol::SetLeftWeaponTransform(const Client::Transform & transform)
{
	uint joint_id = skeleton->GetJointId("prop_L");
	pose->SetJointLockPose(joint_id, true);
	pose->SetJointModelPose(joint_id, transform);
}

/// set right weapon transform
void DualPistol::SetRightWeaponTransform(const Client::Transform & transform)
{
	uint joint_id = skeleton->GetJointId("prop_R");
	pose->SetJointLockPose(joint_id, true);
	pose->SetJointModelPose(joint_id, transform);
}

tempc_ptr(Pose) DualPistol::GetPose()
{
	if (animation)
	{
		tempc_ptr(Pose) animation_pose = animation->GetPose();

		if (animation_pose)
			pose->Blend(animation_pose, NullPtr, 0);
	}

	return pose;
}