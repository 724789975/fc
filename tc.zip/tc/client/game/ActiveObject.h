namespace Client
{ 
	struct ActiveObjInfo :Core::Object
	{
		ActiveObjInfo()
		{
			
		}
		Core::String	 filename;
		Core::Vector3	 position;
		Core::Quaternion rotation;
		
		float rot_360_time;
		Core::Vector3	 rot_normal;
		float updown_distance;
		float updown_speed;
	};


	class ActiveObject : public Core::Object
	{
	public:
		/// constructor
		ActiveObject(by_ptr(ActiveObjInfo) info);
		/// destructor
		virtual ~ActiveObject();

	public:
		/// draw
		virtual void Draw(Primitive::DrawType drawtype, bool immediate = false);

		/// initialize
		virtual void Initialize();

		/// update
		void Update(float frame_time);

	protected:
		virtual void CreateMesh();
	
	public:
		
		sharedc_ptr(ActiveObjInfo) active_object_info;

		sharedc_ptr(StaticMesh)	  active_object_mesh;

		float rot_addup_time;
	};
}