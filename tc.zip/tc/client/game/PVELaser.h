namespace Client
{
	struct PVELaserInfo : public PVEWeaponInfo
	{
		sharedc_ptr(PVEAmmoLaserInfo) ammolaser_info;

		PVELaserInfo()
		{
			weapon_type = kPVEWeaponTypeLaser;
		}
	};

	class PVELaser : public PVEWeaponBase
	{
	public:
		PVELaser();

		~PVELaser();

	public:
		bool Initialize(const Core::String &name, by_ptr(Character) c, by_ptr(PVEWeaponInfo) info);

		void Update(float time);

		void Fire(const Core::Vector3 &fire_pos, const Core::Quaternion &fire_rot, int index, by_ptr(Character) target);

		void Fire(const Core::Vector3 &fire_pos, const Core::Vector3 &target);

		void Fire(const Core::Vector3 &fire_pos, by_ptr(Character) target);

		PVEWeaponType GetWeaponType();

		void Reset();

	private:
		sharedc_ptr(PVELaserInfo)	laser_info;
		Core::Array<sharedc_ptr(PVEAmmoLaser)> pve_ammolasers;
	};
}