namespace Client
{ 
	struct BulletSmokeObject  :Core::Object
	{
		sharedc_ptr(StaticMesh)	  smoke_object_mesh;
		float					  smoke_show_timer;
		
		BulletSmokeObject();

		~BulletSmokeObject();
	};



static const int MAX_SMOKE_COUNT = 9;
static const float SINGLE_SMOKE_LENGTH = 7.f;
static const float BULLET_SMOKE_OFFSET = 0.3f;

	class BulletSmoke : public Core::Object
	{
	public:
		/// constructor
		BulletSmoke();
		/// destructor
		virtual ~BulletSmoke();

	public:
		/// draw
		virtual void Draw(Primitive::DrawType drawtype, bool immediate = false);

		/// initialize
		virtual void Initialize();

		bool AddBulletSmoke(const Core::Vector3 & from, const Core::Quaternion & dir, int count);

		/// update
		void Update(float frame_time);

	protected:
		virtual void CreateMesh();
	
	public:
		sharedc_ptr(BulletSmokeObject)	  bullet_smoke_obj[MAX_SMOKE_COUNT];

		int alive_count;

	};
}