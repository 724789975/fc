#include "pch.h"

using namespace Core;
using namespace Client;

DEFINE_PDE_TYPE_CLASS(Client::KnifeInfo)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Client::WeaponInfo);

		ADD_PDE_FIELD(stab_time);
		ADD_PDE_FIELD(stab_light_time);

		ADD_PDE_FIELD(stab_distance);
		ADD_PDE_FIELD(stab_light_distance);
		ADD_PDE_FIELD(stab_width);

		ADD_PDE_FIELD(back_factor);

		ADD_PDE_FIELD(hit_none_2d);
		ADD_PDE_FIELD(hit_none_3d);
		ADD_PDE_FIELD(hit_wall_2d);
		ADD_PDE_FIELD(hit_wall_3d);
		ADD_PDE_FIELD(hit_body_2d);
		ADD_PDE_FIELD(hit_body_3d);

		ADD_PDE_FIELD(hit_none_light_2d);
		ADD_PDE_FIELD(hit_none_light_3d);
		ADD_PDE_FIELD(hit_wall_light_2d);
		ADD_PDE_FIELD(hit_wall_light_3d);
		ADD_PDE_FIELD(hit_body_light_2d);
		ADD_PDE_FIELD(hit_body_light_3d);

		ADD_PDE_FIELD(hit_wall_decal_easy);
		ADD_PDE_FIELD(hit_wall_decal_heavy);
		ADD_PDE_FIELD(hit_wall_decal_easy_reverse);

		ADD_PDE_DEFAULT_CONSTRUCTOR();
	}
};

REGISTER_PDE_TYPE(Client::KnifeInfo);

/// constructor
Knife::Knife(by_ptr(KnifeInfo) info)
	: stabing(false)
	, stab_light(false)
	, stab_time(0)
	, stab_hurt_time(0)
	, direction(1)
{
	weapon_info = knife_info = info;
}

/// initialize
void Knife::Initialize()
{
	WeaponBase::Initialize();
}

/// udpate
void Knife::Update(float frame_time)
{
	WeaponBase::Update(frame_time);

	tempc_ptr(Character) player = GetOwner();

	if (!player)
		return;

	if (stabing)
	{
		stab_time -= frame_time;

		if (stab_hurt_time > 0)
		{
			stab_hurt_time -= frame_time;

			if (stab_hurt_time <= 0)
			{
				StabCheck();

				if (gLevel->game_type == RoomOption::kNovice)
				{
					int tempid = -1;
					int gun_index = -1;
					if(gLevel->novice_index == 17)
					{
						tempid = 3;
						gun_index = 2;

						tempc_ptr(Character) tempplayer = gLevel->GetPlayer();
						if (tempplayer && tempplayer->GetCurCharinfo() && tempplayer->GetFirstPerson().GetWeapon(gun_index) == tempplayer->GetWeapon())
						{
							for (uint i = 0; i < gLevel->novice_guntarget_array.Size();++i)
							{
								if (gLevel->novice_guntarget_array[i]->guntarget_info->uid == tempplayer->GetCurCharinfo()->career_id && gLevel->novice_guntarget_array[i]->GetID() == tempid)
								{
									if (gLevel->novice_guntarget_array[i]->CheckStab(knife_info))
									{
										gLevel->novice_guntarget_array[i]->status = GUNTARGET_DOWN;
										gLevel->novice_shoot_num--;
									}
								}
							}
						}
					}
					else if (gLevel->novice_index >= 20)
					{
						tempc_ptr(Character) tempplayer = gLevel->GetPlayer();
						if (tempplayer && tempplayer->GetCurCharinfo())
						{
							for (uint i = 0; i < gLevel->novice_guntarget_array.Size();++i)
							{
								if (gLevel->novice_guntarget_array[i]->CheckStab(knife_info))
								{
									gLevel->novice_guntarget_array[i]->status = GUNTARGET_DOWN;
								}
							}
						}
					}
				}
			}
		}

		if (stab_time < 0)
		{
			stab_time = 0;
			stabing = false;
			player->StopStab();
		}
	}
	else if (player->CanStab())
	{
		if (player->first_action_on)
		{
			player->Stab(Stab(true));
		}
		else if (player->second_action_on)
		{
			player->Stab(Stab(false));
		}
		else
			player->stabing = false;
	}
	else
	{
		player->stabing = false;
	}
}

void Knife::DrawUI(by_ptr(UIRender) ui_render)
{
	WeaponBase::DrawUI(ui_render);

	CStrBuf<256> buff;
	buff.format(weapon_info->name);
	buff.toupper();

	ui_render->DrawStringShadow(ui_render->font_simhei_24, ARGB(255, 241, 211), ARGB(0,0,0), ARGB(0, 0, 0, 0), Core::Rectangle(-195, 0, 0, 1), "1/1", Unit::kAlignLeftBottom);

	ui_render->DrawStringShadow(ui_render->font_simhei_14, ARGB(255, 241, 211), ARGB(0,0,0), ARGB(0, 0, 0, 0), Core::Rectangle(-100, -20, 0, -7), buff, Unit::kAlignCenterBottom);
}

/// can active
bool Knife::CanActive()
{
	return WeaponBase::CanActive();
}

/// active
void Knife::Active()
{
	WeaponBase::Active();
}

/// inactive
void Knife::Inactive()
{
	WeaponBase::Inactive();

	stabing = false;
	stab_light = false;
	stab_time = 0;
	stab_hurt_time = 0;

	tempc_ptr(Character) player = GetOwner();
	if (player)
		player->StopStab();
}

/// stab
byte Knife::Stab(bool light)
{
	byte type = kNone;

	if (!knife_info)
		return type;

	if (!stabing)
	{
		stabing = true;
		stab_light = light;

		if (light)
		{
			stab_time = knife_info->stab_light_time;
		}
		else
		{
			stab_time = knife_info->stab_time;
		}

		stab_hurt_time = stab_time * 0.3f;

		type = kHitNone;

		tempc_ptr(Character) player = GetOwner();
		
		if (!player)
			return type;

		byte part = 0;

		uint group_id = 0;
		group_id |= 1 << PhysxSystem::kStatic;
		group_id |= 1 << PhysxSystem::kStaticRaycast;
		for (uint i = PhysxSystem::kGroupStart; i <= PhysxSystem::kGroupEnd; ++i)
		{
			if (!gLevel->team_hurt && 
				(i == player->GetTeam() + PhysxSystem::kGroupStart))
				continue;

			group_id |= 1 << i;
		}
		group_id |= 1 << PhysxSystem::kGroupVehicle;

		Vector3 position = player->GetCameraPosition();
		Vector3 direction = Normalize(Vector3(0, 0, -1) * player->GetCameraRotation());
		Vector3 right = Normalize(Vector3(1, 0, 0) * player->GetCameraRotation());

		NxCapsule capsule;
		capsule.p0 = binary_cast<NxVec3>(position - right * knife_info->stab_width);
		capsule.p1 = binary_cast<NxVec3>(position + right * knife_info->stab_width);
		capsule.radius = 0.1f;

		NxSweepQueryHit hit;

		if (gPhysxScene->linearCapsuleSweep(capsule, binary_cast<NxVec3>(direction * (light ? knife_info->stab_light_distance : knife_info->stab_distance)), NX_SF_STATICS | NX_SF_DYNAMICS, NULL, 1, &hit, NULL, group_id, NULL))
		{
			if (hit.hitShape)
			{
				NxActor& actor = hit.hitShape->getActor();
				tempc_ptr(Character) p = Character::FromNxActor(actor);

				if (p)
					type = kHitBody;
				else
					type = kHitWall;
			}
		}
				
			
		type += stab_light;
		gGame->channel_connection->Poke(type);
	}
	return type;
}

/// stab check
void Knife::StabCheck()
{
	tempc_ptr(Character) player = GetOwner();

	if (!player)
		return;

	byte uid = 0;
	byte part = 0;

	uint group_id = 0;
	group_id |= 1 << PhysxSystem::kStatic;
	group_id |= 1 << PhysxSystem::kStaticRaycast;
	for (uint i = PhysxSystem::kGroupStart; i <= PhysxSystem::kGroupEnd; ++i)
	{
		if (!gLevel->team_hurt && 
			(i == player->GetTeam() + PhysxSystem::kGroupStart))
			continue;

		group_id |= 1 << i;
	}
	group_id |= 1 << PhysxSystem::kGroupVehicle;

	Vector3 position = player->GetCameraPosition();
	Vector3 direction = Normalize(Vector3(0, 0, -1) * player->GetCameraRotation());
	Vector3 right = Normalize(Vector3(1, 0, 0) * player->GetCameraRotation());

	NxCapsule capsule;
	capsule.p0 = binary_cast<NxVec3>(position - right * knife_info->stab_width);
	capsule.p1 = binary_cast<NxVec3>(position + right * knife_info->stab_width);
	capsule.radius = 0.1f;

	NxSweepQueryHit hit;
	
	if (gPhysxScene->linearCapsuleSweep(capsule, binary_cast<NxVec3>(direction * (stab_light ? knife_info->stab_light_distance : knife_info->stab_distance)), NX_SF_STATICS | NX_SF_DYNAMICS, NULL, 1, &hit, NULL, group_id, NULL))
	{
		if (hit.hitShape)
		{
			KickBack(3, 2, 10, 10, 3);

			NxActor& actor = hit.hitShape->getActor();
			tempc_ptr(Character) p = Character::FromNxActor(actor);
			tempc_ptr(DummyObject) dummy = DummyObject::FromNxActor(actor);
			if (p)
			{
				uid = p->uid;
				part = p->GetActorId(&actor);

				Vector3 target(hit.point.x, hit.point.y, hit.point.z);
				Vector3 normal(hit.normal.x, hit.normal.y, hit.normal.z);
				p->ResponseHit(position, target, normal, part, kWeaponTypeKnife);
				if (player && player->GetViewMode() == Character::kFirstPerson)
				{
					// camera animation
					if (!player->IsDied())
						player->GetFirstPerson().animation_camera->PlayAction("camhit", 0.f);
				}
				bool is_boost(false);

				if (gGame->channel_connection)
				{
					if( GetGaiLv(player->rand_fun.Rand(),player->rand_fun.GetRandMax()) * 10000 < weapon_info->hit_crit)
						is_boost = true;
				
				
					bool back = false;
					Vector3 front_dir = Vector3(0, 0, -1) * player->GetRotation();
					Vector3 dir = Vector3(0, 0, -1) * p->GetRotation();
					back = Dot(front_dir, dir) > 0;
					
					gGame->channel_connection->PokeHurt(stab_light, uid, part, back);
				}
			}
			else if(dummy)
			{
				bool is_boost(false);
				if (gGame->channel_connection)
				{
					if( GetGaiLv(player->rand_fun.Rand(),player->rand_fun.GetRandMax()) * 10000 < weapon_info->hit_crit)
						is_boost = true;


					bool back = false;
					Vector3 front_dir = Vector3(0, 0, -1) * player->GetRotation();
					Vector3 dir = Vector3(0, 0, -1) * dummy->GetRotation();
					back = Dot(front_dir, dir) > 0;
	
					gGame->channel_connection->PokeHurtDummy(stab_light, dummy->dummyobjectinfo->dummy_id, back);
				}
			}
			else
			{
				if (gGame)
				{
					sharedc_ptr(Character) player = gLevel->GetPlayer();
					if (player)
					{
						Vector3 pos = player->GetCameraPosition();
						Vector3 dir = Vector3(0, 0, -1) * player->GetLookDir();

						NxRay ray;
						ray.orig = (const NxVec3 &)pos;
						ray.dir = (const NxVec3 &)dir.Normalize();

						NxRaycastHit hit;
						uint group_id = 0;
						group_id |= 1 << PhysxSystem::kStatic;
						group_id |= 1 << PhysxSystem::kStaticRaycast;

						NxShape* shape = gPhysxScene->raycastClosestShape(ray, NX_ALL_SHAPES, hit, group_id, stab_light ? knife_info->stab_light_distance: knife_info->stab_distance);

						pos.x = hit.worldImpact.x;
						pos.y = hit.worldImpact.y;
						pos.z = hit.worldImpact.z;

						dir.x = hit.worldNormal.x;
						dir.y = hit.worldNormal.y;
						dir.z = hit.worldNormal.z;
						//LogSystem.WriteLinef("StabCheck() dir : %f %f %f", dir.x, dir.y, dir.z);
						if (stab_light)
						{
							if (gGame && gGame->config && gGame->config->GetLeftHand())
								gLevel->AddDecal(knife_info->hit_wall_decal_easy_reverse, pos, dir, Vector3::kOne);
							else
								gLevel->AddDecal(knife_info->hit_wall_decal_easy, pos, dir, Vector3::kOne);
						}
						else
							gLevel->AddDecal(knife_info->hit_wall_decal_heavy, pos, dir, Vector3::kOne);
					}
				}
			}
		}
	}
}

void Knife::StabSound(byte type, bool stereo)
{		
	tempc_ptr(Character) viewer = gLevel->GetViewer();
	if(!viewer)
		return;

	if (!knife_info)
		return;

	FMOD::Event* audio_event = NULL;
	Identifier key;

	if (stereo)
	{
		switch (type)
		{
		case kHitNone:
			key = knife_info->hit_none_3d;
			break;

		case kHitNoneLight:
			key = knife_info->hit_none_light_3d;
			break;

		case kHitWall:
			key = knife_info->hit_wall_3d;
			break;

		case kHitWallLight:
			key = knife_info->hit_wall_light_3d;
			break;

		case kHitBody:
			key = knife_info->hit_body_3d;
			break;

		case kHitBodyLight:
			key = knife_info->hit_body_light_3d;
			break;

		default:
			key = knife_info->hit_none_light_3d;
			break;
		}
	}
	else
	{
		switch (type)
		{
		case kHitNone:
			key = knife_info->hit_none_2d;
			break;

		case kHitNoneLight:
			key = knife_info->hit_none_light_2d;
			break;

		case kHitWall:
			key = knife_info->hit_wall_2d;
			break;

		case kHitWallLight:
			key = knife_info->hit_wall_light_2d;
			break;

		case kHitBody:
			key = knife_info->hit_body_2d;
			break;

		case kHitBodyLight:
			key = knife_info->hit_body_light_2d;
			break;

		default:
			key = knife_info->hit_none_light_2d;
			break;
		}
	}

	audio_event = FmodSystem::GetEvent(key);

	if (audio_event)
	{
		if (stereo)
		{
			FMOD_VECTOR pos = (const FMOD_VECTOR &)GetPosition();
			FMOD_VECTOR vel = {0, 0, 0};
			audio_event->set3DAttributes(&pos, &vel);
		}

		audio_event->start();
	}
}

/// random int
static int RandomInt(int x, int y)
{
	return x + (int)(rand()%(y-x));
}

/// kick back
void Knife::KickBack(float up_base, float lateral_base, float up_max, float lateral_max, int direction_change)
{
	tempc_ptr(Character) player = GetOwner();

	if (!player)
		return;

	float kick_up = up_base;
	float kick_lateral = lateral_base;

	Vector3 angle = player->punch_angle * RAD2DEG;

	angle.x += kick_up;
	if (angle.x > up_max)
		angle.x = up_max;
		
	if (direction == 1)
	{
		angle.y += kick_lateral;
		if (angle.y > lateral_max)
		{
			angle.y = lateral_max;
		}
	}
	else
	{
		angle.y -= kick_lateral;
		if (angle.y < -lateral_max)
		{
			angle.y = -lateral_max;
		}
	}

	angle *= DEG2RAD;
	player->punch_angle = angle;

	if (direction_change && !RandomInt(0, direction_change))
		direction = 1 - direction;

	if (gGame->channel_connection)
		gGame->channel_connection->KickBack(angle);
}