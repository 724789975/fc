namespace Client
{
	struct PushVehicleInfo
	{
		Core::Vector3 last_position;
		Core::Vector3 position;
		Core::Vector3 dir;
		Core::Vector3 last_dir;
		Core::AxisAlignedBox aabb;
		Core::AxisAlignedBox aabb_kick;
		int team;
		float time_interval;
		Core::Vector3 velocity;
		float total_length;
		float current_length;
		int sliding;
		int player_count;
		PushVehicleInfo()
		{
			sliding = 0;
			player_count = 0;
			aabb = Core::AxisAlignedBox(Core::Vector3(0,0,0),Core::Vector3(0,0,0));
		}
	};

	struct MeshPhysXData
	{
		enum MeshType
		{
			VEHICLE_MESH = 0,

		};
		int type;
		Core::Vector3 center_offset;
		Core::Vector3 dim;
		Core::Quaternion rot;
		NxActor* actor;
		
		MeshPhysXData()
		{
			type = VEHICLE_MESH;
			actor = NULL;
		}

		MeshPhysXData& operator = (const MeshPhysXData& d)
		{
			type = d.type;
			center_offset = d.center_offset;
			dim = d.dim;
			rot = d.rot;
			actor = d.actor;
			return *this;
		}

		MeshPhysXData(const MeshPhysXData& d)
		{
			type = d.type;
			center_offset = d.center_offset;
			dim = d.dim;
			rot = d.rot;
			actor = d.actor;
		}

	};

	class Vehicle : public DrawableObj
	{
	public:
		/// constructor
		Vehicle(const PushVehicleInfo& info);

		/// destructor
		~Vehicle();

	public:
		/// initialize
		virtual void Initialize();

		/// stopeffect
		virtual void StopEffect();

		/// update physx
		virtual void UpdatePhysx(float frame_time);

		/// update
		virtual void Update(float time);

		virtual void Draw(Primitive::DrawType type, bool immediate = false);

		void DrawParticle();

	public:
		/// get position
		virtual const Core::Vector3 & GetPosition();

		/// set position
		virtual void SetPosition(const Core::Vector3 & pos);

		/// get rotation
		virtual const Core::Quaternion & GetRotation();

		/// set rotation
		virtual void SetRotation(const Core::Quaternion & rot);

		/// Get Mesh
		sharedc_ptr(StaticMesh) GetMesh();

		/// create physx
		void CreatePhysx();

		void SetStartPosition(const Core::Vector3 & pos);

		void SetStartDir(const Core::Vector3 & dir);

		/// from nx actor
		static tempc_ptr(Vehicle) FromNxActor(NxActor & actor);

		void UpdateVehicleInfo(const PushVehicleInfo& info);

		void InitializeVehicleInfo(const PushVehicleInfo& info);

		void AddSmokeEffect();
	private:
		void ReleasePhysx();

	private:
		Core::Array<MeshPhysXData> kinematic_actor_array;
		sharedc_ptr(ParticleSystem) lightparticle;
		
		sharedc_ptr(StaticMesh) vehicle_mesh;
	public:
		float		timer;
		float		maxfly_time;
		byte		uid;
		uint		team;
		int			current_flag;
		
		Core::Array<sharedc_ptr(PushVehicleInfo)> check_point_array;
		
		PushVehicleInfo current_vehicle_info;

		Core::Vector3 start_pos;
		Core::Vector3 start_dir;
		Core::Vector3 position;
		Core::Quaternion rotation;

		Core::Vector3	init_velocity;

		float add_up_time;

		bool need_update;

		bool need_draw_smoke;


		Core::Array<sharedc_ptr(ParticleSystem)> vehicle_smoke_particle_array;
	};
}