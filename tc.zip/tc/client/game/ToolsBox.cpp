#include "pch.h"

using namespace Core;
using namespace Client;

#define BOXEXTENT 0.4f
#define BOXEXTENTCHANGE 0.1f

namespace Client
{
	ToolsBox::ToolsBox(void)
		: position(Vector3::kZero)
		, rotation(Quaternion::kIdentity)
		, height(0.f)
		, isDraw(false)
		, actor(NULL)
	{
		actor = PhysxSystem::CreateBox(position, Vector3(BOXEXTENT, BOXEXTENT, 0.0001f), PhysxSystem::kNone);
		actor->raiseBodyFlag(NX_BF_KINEMATIC);
		InitToolsBox();

		for (int i = 0; i < 4; ++i)
		{
			ray[i].dir = NxVec3(0, -1, 0);
		}
	}

	ToolsBox::~ToolsBox(void)
	{
		if (actor)
		{
			PhysxSystem::ReleaseActor(*actor);
			actor = NULL;
		}
	}

	void ToolsBox::InitToolsBox()
	{
		isRot = false;
		rotindex = 0;
		angle = 0.f;
		finalrotation = Quaternion::kIdentity;
	}

	void ToolsBox::AddMesh(const Core::Identifier & key)
	{
		sharedc_ptr(StaticMesh) mesh = ptr_new StaticMesh(MESH_KEY_PROP);
		mesh->AddPrimitive(key,0);
		mesh_array.Add(mesh);
	}

	void ToolsBox::ClearMesh()
	{
		mesh_array.Clear();
	}

	void ToolsBox::Draw(Primitive::DrawType drawtype, bool immediate)
	{
		if(!isDraw)
			return;
#if 0
		DrawAABB();
#endif
		for (uint i = 0; i < mesh_array.Size(); i++)
		{
			tempc_ptr(StaticMesh) p = mesh_array[i];
			p->Draw(drawtype,immediate);
		}
	}

	void ToolsBox::DrawAABB()
	{
		struct Vtx
		{
			Vector3 pos;
			ARGB color;
		} Vtxs[24 + 2];
		sharedc_ptr(Shader) physic_vs;
		sharedc_ptr(Shader) physic_ps;
		physic_vs = RESOURCE_LOAD("/shader/physic_vs.vd9", true, VertexShaderDx9);
		physic_ps = RESOURCE_LOAD("/shader/physic_ps.pd9", true, PixelShaderDx9);
		
		tempc_ptr(Character) viewer = gGame->level->GetPlayer();
		if (!viewer)
			return;
		Vector3 pos = Vector3(position);
		Vector3 vec[24] = 
		{
			Vector3(-BOXEXTENT, BOXEXTENT, -BOXEXTENT) * rotation + pos,					Vector3(-BOXEXTENT, BOXEXTENT, BOXEXTENT) * rotation + pos,
			Vector3(-BOXEXTENT, BOXEXTENT, BOXEXTENT) * rotation + pos,						Vector3(-BOXEXTENT, -BOXEXTENT - BOXEXTENTCHANGE, BOXEXTENT) * rotation + pos,
			Vector3(-BOXEXTENT, -BOXEXTENT - BOXEXTENTCHANGE, BOXEXTENT) * rotation + pos,	Vector3(-BOXEXTENT, -BOXEXTENT - BOXEXTENTCHANGE, -BOXEXTENT) * rotation + pos,
			Vector3(-BOXEXTENT, -BOXEXTENT - BOXEXTENTCHANGE, -BOXEXTENT) * rotation + pos,	Vector3(-BOXEXTENT, BOXEXTENT, -BOXEXTENT) * rotation + pos,

			Vector3(BOXEXTENT, BOXEXTENT, -BOXEXTENT) * rotation + pos,						Vector3(BOXEXTENT, BOXEXTENT, BOXEXTENT) * rotation + pos,
			Vector3(BOXEXTENT, BOXEXTENT, BOXEXTENT) * rotation + pos,						Vector3(BOXEXTENT, -BOXEXTENT - BOXEXTENTCHANGE, BOXEXTENT) * rotation + pos,
			Vector3(BOXEXTENT, -BOXEXTENT - BOXEXTENTCHANGE, BOXEXTENT) * rotation + pos,	Vector3(BOXEXTENT, -BOXEXTENT - BOXEXTENTCHANGE, -BOXEXTENT) * rotation + pos,
			Vector3(BOXEXTENT, -BOXEXTENT - BOXEXTENTCHANGE, -BOXEXTENT) * rotation + pos,	Vector3(BOXEXTENT, BOXEXTENT, -BOXEXTENT) * rotation + pos,

			Vector3(-BOXEXTENT, BOXEXTENT, BOXEXTENT) * rotation + pos,						Vector3(BOXEXTENT, BOXEXTENT, BOXEXTENT) * rotation + pos,
			Vector3(-BOXEXTENT, BOXEXTENT, -BOXEXTENT) * rotation + pos,					Vector3(BOXEXTENT, BOXEXTENT, -BOXEXTENT) * rotation + pos,
			Vector3(-BOXEXTENT, -BOXEXTENT - BOXEXTENTCHANGE, BOXEXTENT) * rotation + pos,	Vector3(BOXEXTENT, -BOXEXTENT - BOXEXTENTCHANGE, BOXEXTENT) * rotation + pos,
			Vector3(-BOXEXTENT, -BOXEXTENT - BOXEXTENTCHANGE, -BOXEXTENT) * rotation + pos,	Vector3(BOXEXTENT, -BOXEXTENT - BOXEXTENTCHANGE, -BOXEXTENT) * rotation + pos,
		};

		for (U32 i = 0; i < 24; i++)
		{
			Vtxs[i].pos = vec[i];
			Vtxs[i].color = ARGB(255, 101, 74);
		}

		float Height = gGame->level->GetPlayer()->GetHeight() * 2;
		Vtxs[24].color = Vtxs[25].color = ARGB(255, 101, 74);
		Vtxs[24].pos = Vtxs[25].pos = pos;
		Vtxs[24].pos.y = gGame->level->GetPlayer()->GetPosition().y + Height;
		Height += 1.2f;
		Vtxs[25].pos.y = Vtxs[24].pos.y - Height;

		physic_vs->SetShader();
		physic_ps->SetShader();
		GsPrimitive::SetVertexDeclaration("Phyical");
		gDx9Device->DrawPrimitiveUP(D3DPT_LINELIST, 12 + 1, Vtxs, sizeof(Vtx));
	}

	void ToolsBox::SetPosition(const Core::Vector3& pos)
	{
		position = pos;
	}

	void ToolsBox::SetRotation(const Core::Quaternion& rot)
	{
		rotation = rot;
	}

	Core::Quaternion ToolsBox::GetRotation()
	{
		return rotation;
	}

	void ToolsBox::SetHeight(const float& height)
	{
		this->height = height;
	}

	/// update
	void ToolsBox::Update(float frame_time)
	{
		if (!isDraw)
		{
			if (actor)
				actor->setGlobalPosition(NxVec3(0,-20,0));
			return;
		}

		bool isOk = true;
		float max_y = -F32_MAX, min_y = F32_MAX;
		Vector3 pos = Vector3(position);

		float Height = gGame->level->GetPlayer()->GetHeight() * 2;
		pos.y = position.y + Height;
		Height += 1.2f;

		NxRay ray_cent;

		ray_cent.dir = NxVec3(0, -1, 0);
		ray_cent.orig = (NxVec3&)pos;

		NxRaycastHit hit;
		uint group_id = 0;
		group_id |= 1 << PhysxSystem::kStatic;

		NxShape* shape = gPhysxScene->raycastClosestShape(ray_cent, NX_STATIC_SHAPES, hit, group_id, Height);
		if (shape)
		{
			pos.y = hit.worldImpact.y;

			Vector3 vec[8] =
			{
				Vector3(BOXEXTENT, BOXEXTENT, BOXEXTENT) * rotation + pos,
				Vector3(BOXEXTENT, BOXEXTENT, -BOXEXTENT) * rotation + pos,
				Vector3(-BOXEXTENT, BOXEXTENT, BOXEXTENT) * rotation + pos,
				Vector3(-BOXEXTENT, BOXEXTENT, -BOXEXTENT) * rotation + pos,
			};
			
			ray[0].orig = NxVec3(vec[0].x, vec[0].y, vec[0].z);
			ray[1].orig = NxVec3(vec[1].x, vec[1].y, vec[1].z);
			ray[2].orig = NxVec3(vec[2].x, vec[2].y, vec[2].z);
			ray[3].orig = NxVec3(vec[3].x, vec[3].y, vec[3].z);

			for (int i = 0; i < 4; ++i)
			{
				NxShape* shape = gPhysxScene->raycastClosestShape(ray[i], NX_STATIC_SHAPES, hit, group_id, BOXEXTENT * 2 + BOXEXTENTCHANGE);
				if (shape)
				{
					float temp_y = hit.worldImpact.y;
					if (temp_y < pos.y - BOXEXTENT - BOXEXTENTCHANGE || temp_y > pos.y + BOXEXTENT)
					{
						isOk = false;
						break;
					}
					max_y = max_y > temp_y ? max_y : temp_y;
					min_y = min_y < temp_y ? min_y : temp_y;
				}
				else
				{
					isOk = false;
					break;
				}
			}
			if (max_y - min_y > BOXEXTENT * 2 + BOXEXTENTCHANGE)
			{
				isOk = false;
			}
		}
		else
		{
			isOk = false;
		}

		Vector3 vec = Vector3(0, 0, 1) * rotation;
		
		Vector3 actor_pos = position - vec * (BOXEXTENT * 0.5);
		actor_pos.y = max_y + 0.25f;

		actor->setGlobalPosition((const NxVec3 &)actor_pos);
		actor->setGlobalOrientationQuat((const NxQuat &)rotation);
		if (isOk)
		{
			NxSweepQueryHit hit;
			vec *= BOXEXTENT;

			actor->setGroup(PhysxSystem::kStatic);
			NxU32 num = actor->linearSweep((const NxVec3 &)vec, NX_SF_STATICS/* | NX_SF_DYNAMICS*/, NULL, 1, &hit, NULL);
			actor->setGroup(PhysxSystem::kNone);
			if (num)
			{
				isOk = false;
			}
		}
		
		position.y = isOk ? max_y : -100;

		float rotangle[4] = {PI/2, PI, PI*3/2, 2*PI};
		if(isRot)
		{
			angle += 135 * DEG2RAD * frame_time;
			if(angle > rotangle[rotindex])
			{
				if (rotindex == 3)
				{
					angle = 0;
					rotindex = 0;
				}
				else
				{
					angle = rotangle[rotindex];
					rotindex = (rotindex+1)%4;
				}
				isRot = false;
			}
			else
			{
				finalrotation =  Quaternion(Vector3(0,1,0), angle);
			}
		}

		for (uint i = 0; i < mesh_array.Size(); i++)
		{
			tempc_ptr(StaticMesh) p = mesh_array[i];

			if (i == 0)
				position.y += 0.2f;

			p->SetPosition(position);
			p->SetRotation(finalrotation * rotation);
			p->Update();
		}
	}
}