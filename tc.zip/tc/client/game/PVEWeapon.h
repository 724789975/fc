namespace Client
{
	struct PhysxDesc
	{
		Core::Vector3 position;
		Core::Quaternion rotation;
		bool can_hitstatic;

		PhysxDesc()
		{
			position = Core::Vector3::kZero;
			rotation = Core::Quaternion::kIdentity;
			can_hitstatic = true;
		}
	};

	struct BoxDesc : public PhysxDesc
	{
		Core::Vector3 dimensions;

		BoxDesc()
		{
			dimensions = Core::Vector3::kZero;
		}
	};

	struct CapsuleDesc : public PhysxDesc
	{
		float radius;
		float height;

		CapsuleDesc()
			: radius(0)
			, height(0)
		{
		}
	};

	enum PVEWeaponType
	{
		kPVEWeaponTypeNone,
		kPVEWeaponTypeLuncher,
		kPVEWeaponTypeLaser,

		kPVEWeaponTypeCount,
	};

	struct PVEWeaponInfo : public Core::Object
	{
		// constructor
		PVEWeaponInfo();

		PVEWeaponType weapon_type;

		float fire_interval;
		float first_fire_time;
	};

	class PVEWeaponBase : public Core::Object
	{
	public:
		/// constructor
		PVEWeaponBase();

		/// destructor
		virtual ~PVEWeaponBase();

	public:
		/// initialize
		virtual bool Initialize(const Core::String &name, by_ptr(Character) c, by_ptr(PVEWeaponInfo) info);

		/// update
		virtual void Update(float time);

		/// timestepupdate
		virtual void TimeStepUpdate(float time);

		/// draw
		virtual void Draw(Primitive::DrawType drawtype, bool immediate = false);

		/// canfire
		virtual bool CanFire();

		/// firestart
		virtual void FireStart();

		/// firedone
		virtual void FireDone();

		/// reset
		virtual void Reset();

		/// fire
		virtual void Fire(const Core::Vector3 &fire_pos, const Core::Quaternion &fire_rot, int index = 0, by_ptr(Character) target = NullPtr) = 0;

		/// fire
		virtual void Fire(const Core::Vector3 &fire_pos, const Core::Vector3 &target) = 0;

		/// fire
		virtual void Fire(const Core::Vector3 &fire_pos, by_ptr(Character) target) = 0;

		/// get weapon type
		virtual PVEWeaponType GetWeaponType() = 0;

	public:
		/// get owner
		tempc_ptr(Character) GetOwner();

		/// get weapon info
		tempc_ptr(PVEWeaponInfo) GetWeaponInfo();

		/// get uid
		uint GetUid();

	protected:
		void GetFireIntervalKey(Core::String &value);

	private:
		uint m_Uid;
		Core::String m_Name;
		tempc_ptr(Character) m_Owner;
		sharedc_ptr(PVEWeaponInfo) m_WeaponInfo;
	};

	//////////////////////////////////////////////////////////////////////
	sharedc_ptr(PVEWeaponBase) CreatePVEWeapon(PVEWeaponType type);
};