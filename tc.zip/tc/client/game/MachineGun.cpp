#include "pch.h"

using namespace Client;
using namespace Core;

DEFINE_PDE_TYPE_CLASS(Client::MachineGunInfo)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Client::RifleInfo);

		ADD_PDE_DEFAULT_CONSTRUCTOR();
	}
};

DEFINE_PDE_TYPE_CLASS(Client::MachineGun)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Client::RifleGun);
	}
};

REGISTER_PDE_TYPE(Client::MachineGunInfo);
REGISTER_PDE_TYPE(Client::MachineGun);

MachineGun::MachineGun(by_ptr(MachineGunInfo) info)
: RifleGun(info)
{
}

/// get weapon type
uint MachineGun::GetWeaponType()
{
	return 0;
}