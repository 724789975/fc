#include "pch.h"

using namespace Core;
using namespace Client;

DEFINE_PDE_TYPE_CLASS(Client::PVELaserInfo)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Client::PVEWeaponInfo);

		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_FIELD(ammolaser_info);
	}
};

DEFINE_PDE_TYPE_CLASS(Client::PVELaser)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Client::PVEWeaponBase);
	}
};

REGISTER_PDE_TYPE(Client::PVELaserInfo);
REGISTER_PDE_TYPE(Client::PVELaser);

/// random float
static float RandomFloat(F32 x, F32 y)
{
	float r = (F32)rand() / (RAND_MAX + 1);
	float num = x + (y - x) * r;
	return num; 
}

namespace Client
{
	PVELaser::PVELaser()
	{
	}

	PVELaser::~PVELaser()
	{
		pve_ammolasers.Clear();
	}

	bool PVELaser::Initialize(const Core::String &name, by_ptr(Character) c, by_ptr(PVEWeaponInfo) info)
	{
		laser_info = ptr_dynamic_cast<PVELaserInfo>(info);
		if (!laser_info)
			return false;

		if (!PVEWeaponBase::Initialize(name, c, info))
			return false;

		return true;
	}

	void PVELaser::Update(float time)
	{
		PVEWeaponBase::Update(time);
	}

	void PVELaser::Fire(const Core::Vector3 &fire_pos, const Core::Quaternion &fire_rot, int index, by_ptr(Character) target)
	{
		if (!laser_info)
			return;

		if (index == (int)pve_ammolasers.Size())
		{
			sharedc_ptr(PVEAmmoLaser) pve_ammolaser = ptr_new PVEAmmoLaser();
			if (pve_ammolaser->Initialize(GetOwner()->GenPVEAmmoId(),laser_info->ammolaser_info,GetOwner()))
			{
				GetOwner()->AddPVEAmmoLaser(pve_ammolaser);
				pve_ammolasers.PushBack(pve_ammolaser);
			}
			pve_ammolasers[index]->SetPosition(fire_pos);
			pve_ammolasers[index]->SetRotation(fire_rot);
			pve_ammolasers[index]->Fire();
		}
		else if (index < (int)pve_ammolasers.Size())
		{
			pve_ammolasers[index]->SetPosition(fire_pos);
			pve_ammolasers[index]->SetRotation(fire_rot);
			pve_ammolasers[index]->Fire();
		}
	}

	void PVELaser::Fire(const Core::Vector3 &fire_pos, const Core::Vector3 &target)
	{
	}

	void PVELaser::Fire(const Core::Vector3 &fire_pos, by_ptr(Character) target)
	{
	}

	void PVELaser::Reset()
	{
		for (int i = 0; i < (int)pve_ammolasers.Size(); ++i)
		{
			pve_ammolasers[i]->Reset();
		}
	}

	PVEWeaponType PVELaser::GetWeaponType()
	{
		return kPVEWeaponTypeLaser;
	}
}
