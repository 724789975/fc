#include "pch.h"

using namespace Core;
using namespace Client;

#include <curl/curl.h>
#pragma comment(lib, "wldap32.lib" )


//---------------------------------------------------------------------------------------
// type info.
//---------------------------------------------------------------------------------------
DEFINE_PDE_TYPE_CLASS(Client::GameGlobal)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_METHOD(LogoutAccount);
		ADD_PDE_METHOD(LogoutCharacter);
		ADD_PDE_METHOD(Exit);
		ADD_PDE_METHOD(Chat);
		ADD_PDE_METHOD(ChatGroup);
		ADD_PDE_METHOD(ChatTepGroup);
		ADD_PDE_METHOD(SystemMessage);
		ADD_PDE_METHOD(CategorySetVolume);
		ADD_PDE_METHOD(CategoryGetVolume);
		ADD_PDE_METHOD(CategorySetMute);
		ADD_PDE_METHOD(CategoryGetMute);
		ADD_PDE_METHOD(CategorySetPause);
		ADD_PDE_METHOD(AutoUpdate);
		ADD_PDE_METHOD(RpcCall);
		ADD_PDE_METHOD(TextLenght);
		ADD_PDE_METHOD(StrCut);

		ADD_PDE_PROPERTY_R(CurrentState);
		ADD_PDE_PROPERTY_R(ClientAddress);
		ADD_PDE_PROPERTY_R(Player);
		ADD_PDE_PROPERTY_R(Version);
		ADD_PDE_PROPERTY_R(BuildLog);
		ADD_PDE_PROPERTY_R(MasterBuild);
		ADD_PDE_PROPERTY_RW(ErrorMessage);
		ADD_PDE_PROPERTY_W(ProfilerParse);
		ADD_PDE_PROPERTY_W(ProfilerLimit);
		ADD_PDE_PROPERTY_R(CharacterProfile);
		ADD_PDE_PROPERTY_RW(FightQuit);
#if DEBUG_TOOLS
		ADD_PDE_METHOD(ModelViewer);
		ADD_PDE_METHOD(SceneViewer);
#endif

	}
};

REGISTER_PDE_TYPE(Client::GameGlobal);


//---------------------------------------------------------------------------------------
// properties
//---------------------------------------------------------------------------------------
namespace Client
{
	PDE_ATTRIBUTE_GETTER(GameGlobal, CurrentState, tempc_ptr(GameState))
	{
		if (gGame)
			return gGame->machine.CurrentState();
		else
			return NullPtr;
	}

	PDE_ATTRIBUTE_GETTER(GameGlobal, ClientAddress, ClientAddress)
	{
		if (gGame)
			return gGame->address;
		else
			return ClientAddress();
	}

	PDE_ATTRIBUTE_GETTER(GameGlobal, Player, tempc_ptr(Character))
	{
		if (gGame && gLevel)
		{
			return gLevel->GetPlayer();
		}

		return NullPtr;
	}

	PDE_ATTRIBUTE_GETTER(GameGlobal, Version, Core::String)
	{
		if (gGame)
		{
			return gGame->version;
		}
		else
		{
			return Core::String::kEmpty;
		}
	}

	
	PDE_ATTRIBUTE_GETTER(GameGlobal, BuildLog, Core::String)
	{
		if (gGame)
		{
			return gGame->buildlog;
		}
		else
		{
			return Core::String::kEmpty;
		}
	}

	PDE_ATTRIBUTE_GETTER(GameGlobal, MasterBuild, bool)
	{
#ifndef MASTER
		return false;
#else
		return true;
#endif
	}

	PDE_ATTRIBUTE_GETTER(GameGlobal, ErrorMessage, String)
	{
		if (gGame)
		{
			return gGame->error_message;
		}
		return String::kEmpty;
	}

	PDE_ATTRIBUTE_SETTER(GameGlobal, ErrorMessage, String)
	{
		if (gGame)
		{
			gGame->error_message = value;
		}
	}

	PDE_ATTRIBUTE_GETTER(GameGlobal, FightQuit, bool)
	{
		return m_FightQuit;
	}

	PDE_ATTRIBUTE_SETTER(GameGlobal, FightQuit, bool)
	{
		m_FightQuit = value;
	}

	PDE_ATTRIBUTE_GETTER(GameGlobal, GameRate, float)
	{
		return m_GameRate;
	}

	PDE_ATTRIBUTE_SETTER(GameGlobal, GameRate, float)
	{
		m_GameRate = value;
	}

	PDE_ATTRIBUTE_GETTER(GameGlobal, GameStop, bool)
	{
		return m_GameStop;
	}

	PDE_ATTRIBUTE_SETTER(GameGlobal, GameStop, bool)
	{
		m_GameStop = value;
	}

	PDE_ATTRIBUTE_GETTER(GameGlobal, ProfilerLimit, float)
	{
		if (gGame)
		{
			return gGame->fps_limit;
		}

		return 0.f;
	}

	PDE_ATTRIBUTE_SETTER(GameGlobal, ProfilerLimit, float)
	{
		if (gGame)
		{
			gGame->fps_limit = value;
		}
	}

	PDE_ATTRIBUTE_GETTER(GameGlobal, CharacterProfile, tempc_ptr(Client::CharacterProfile))
	{
		if(gGame && gGame->lobby_connection)
		{
			return gGame->lobby_connection->m_CharacterProfile;
		}
		else
		{
			return NullPtr;
		}
	}

	PDE_ATTRIBUTE_GETTER(GameGlobal, ProfilerParse, bool)
	{
		if (gGame)
		{
			return gGame->fps_flag;
		}

		return false;
	}

	PDE_ATTRIBUTE_SETTER(GameGlobal, ProfilerParse, bool)
	{
		if (gGame)
		{
			gGame->fps_flag = value;
		}
	}
}


//---------------------------------------------------------------------------------------
// methods
//---------------------------------------------------------------------------------------
namespace Client
{
	Core::String TextCopy(Core::String str, int index,int count)
	{
		CStrBuf<40960> tstr, tstr1;
		Core::String ret = "";

		int len = str.Length(), i = 0;
		bool is_input = false;

		tstr.copy(str.RefStr(),0,len);

		char *p = tstr.buff();

		if(index > len - 1)
			return ret;

		while(*p != '\0')
		{
			if(i == index)
				is_input = true;
#ifdef USE_UTF8
			S32 len = GetUTF8CharLength((U8*)p, -1) - 1;
			while (len > 0)
			{
				if (is_input)
					tstr1.insert(tstr1.len(), *p);
				p++;
				len--;
			}
#else
			if(IsDBCSLeadByteEx(936,*p))
			{
				if(is_input)
					tstr1.insert(tstr1.len(), *p);
				p++;
			}
#endif
			if(is_input)
			{
				tstr1.insert(tstr1.len(),*p);
				count--;
				if(count == 0)
					break;
			}
			p++;

			i++;
		}
		ret = tstr1;
		return ret;
	}

	void GameGlobal::LogoutAccount(bool error)
	{
		if (gGame)
		{
			if (gGame->channel_connection)
			{
				gGame->channel_connection->Disconnect();
			}

			if (gGame->lobby_connection)
			{
				gGame->lobby_connection->Disconnect();
			}

			if (!error)
				gGame->error_message = String::kEmpty;
		}
	}

	void GameGlobal::LogoutCharacter()
	{
		if (gGame)
		{
			if (gGame->channel_connection)
			{
				gGame->channel_connection->Disconnect();
			}

			if (gGame->lobby_connection->IsConnected())
			{
				gGame->lobby_connection->RequestLeaveLobby();
				//gGame->machine.ChangeState(ptr_new StateLogin);
			}
		}
	}

	void GameGlobal::Exit()
	{
		Thread::Quit();
	}

	void GameGlobal::AutoUpdate()
	{

		PROCESS_INFORMATION processInfo;
		STARTUPINFOA startupInfo;
		ZeroMemory(&startupInfo, sizeof(startupInfo));
		startupInfo.cb = sizeof(startupInfo);

		CStrBuf<256> temp;
		GetModuleFileNameA(NULL, temp.buff(), temp.size32());
		Path::ContractPath(temp, temp.buff(), "AutoPatch.exe");

		CreateProcessA(temp, NULL, NULL, NULL, false, 0, NULL, NULL, &startupInfo, &processInfo);

		Thread::Quit();
	}

	bool GameGlobal::Chat(const Core::Identifier & to, const Core::String & msg)
	{
		if (gGame)
		{
			static Core::Identifier chat("/x");
			static Core::Identifier channel("/Channel");
			static Core::Identifier room("/room");
			static Core::Identifier chatgroup("/t");
			if(to == Identifier::kNull || to == chat || to == channel || to == room || to == chatgroup)
			{
				if (gGame->channel_connection)
				{
					gGame->channel_connection->RequestChat(to, msg);
					return true;
				}
			}
			else
			{
				if (gGame->lobby_connection)
				{
					gGame->lobby_connection->RequestChat(to, msg);
					return true;
				}
			}
		}

		return false;
	}

	void GameGlobal::ChatGroup(const Core::Identifier & to, const Core::String & msg, const Core::Array<Core::String>& Name)
	{
		if (gGame->lobby_connection)
		{
			gGame->lobby_connection->NotifyMultiChat(to, msg, Name);
		}
	}

	void GameGlobal::ChatTepGroup( uint to, const Core::String & msg)
	{
		if (gGame->lobby_connection)
		{
			gGame->lobby_connection->RequestChatGroupCall(to, msg);
		}
	} 

	// add system message
	bool GameGlobal::SystemMessage(const Core::String & msg, const Core::Identifier & type)
	{
		if (gGame)
		{
			ChatMessage m;
			m.channel = type;
			m.msg = msg;
			gGame->machine.OnChat(m);
		}

		return false;
	}

	// set category volume
	void GameGlobal::CategorySetVolume(const Core::String & key, int volume)
	{
		FMOD::EventCategory* category = FmodSystem::GetCategory(key);
		if (category)
		{
			float v = Clamp(volume / 100.f, 0.f, 1.f);
			category->setVolume(v);
		}
	}

	// get category volume
	int GameGlobal::CategoryGetVolume(const Core::String & key)
	{
		FMOD::EventCategory* category = FmodSystem::GetCategory(key);
		if (category)
		{
			float v;
			category->getVolume(&v);
			v = Clamp(v * 100.f, 0.f, 100.f);

			return (int)v;
		}

		return 0;
	}

	// set category mute
	void GameGlobal::CategorySetMute(const Core::String & key, bool mute)
	{
		FMOD::EventCategory* category = FmodSystem::GetCategory(key);
		if (category)
			category->setMute(mute);
	}

	// get category mute
	bool GameGlobal::CategoryGetMute(const Core::String & key)
	{
		FMOD::EventCategory* category = FmodSystem::GetCategory(key);
		if (category)
		{
			bool mute;
			category->getMute(&mute);

			return mute;
		}

		return true;
	}

	// set category pause
	void GameGlobal::CategorySetPause(const Core::String & key, bool pause)
	{
		FMOD::EventCategory* category = FmodSystem::GetCategory(key);
		if (category)
			category->setMute(pause);
	}

	// category stop
	void GameGlobal::CategoryStop(const Core::String & key)
	{
		FMOD::EventCategory* category = FmodSystem::GetCategory(key);
		if (category)
			category->stopAllEvents();
	}

	// test lua
	bool GameGlobal::RpcCall(Lua::LuaState *L)
	{
		if (gGame->lobby_connection && gGame->lobby_connection->IsConnected())
		{
			const char * func_name = L->ToString(2);

			if (func_name && func_name[0])
			{
				if (gGame->lobby_connection->BeginTextRpc(func_name, Lua::ToPtr<LobbyConnection::RpcCallback>(L, 4)))
				{
					
					if (L->IsTable(3))
					{
						L->PushNil();
						while (L->Next(3))
						{
							const char * key = L->ToString(-2);
							const char * value = L->ToString(-1);

							if (key)
							{
								gGame->lobby_connection->TextRpcArgument(key, value);
							}

							L->Pop(1);
						}
					}
					tempc_ptr(StateLobby) lobby = ptr_dynamic_cast<StateLobby>(gGame->machine.CurrentState());


					//���ӷ�����ʱ�� 
					if(lobby)
					{
						const char * key = "fcm_online_time";
						char fcm_online_time[60] = {0};
						sprintf_s(fcm_online_time, sizeof(fcm_online_time), "%d", lobby->m_fcm_online_time);
						gGame->lobby_connection->TextRpcArgument(key, fcm_online_time);
					}

					gGame->lobby_connection->EndTextRpc();
					return true;
				}
			}
		}

		return false;
	}

	void GameGlobal::GetRealResult(const char * result, Core::String & str)
	{
		RealResult = result;
		//LogSystem.WriteLinef("%s", RealResult);
		int start = RealResult.contain("<",1);
		int end = RealResult.contain(">",1);
		while(start != -1 && end != -1)
		{
			int temp = RealResult.contain("<", 1,start + 1);
			if (temp != -1 && temp < end)
				start = temp;
			else if(temp != -1 && temp >= end)
				break;
			else if(temp == -1)
				break;
		}

		if(start != -1 && end != -1)
		{
			while ( start != -1 && end != -1 )
			{
				Realbuf.copy(RealResult, start, end - start + 1);
				RealResult.remove(start, end + 1);
				Translate(Realbuf);
				RealResult.insert(start, Realbuf.buff());
				start = RealResult.contain("<", 1);
				end = RealResult.contain(">", 1);
				while(start != -1 && end != -1)
				{
					int temp = RealResult.contain("<", 1,start + 1);
					if (temp != -1 && temp < end)
						start = temp;
					else if(temp != -1 && temp >= end)
						break;
					else if(temp == -1)
						break;
				}
			}
		}
		str = RealResult;
	}

	void GameGlobal::Translate(CRefStr & str)
	{
		int start = str.find('<');
		int end = str.find('>');
		while(start != -1 && end != -1)
		{
			int temp = str.find('<', start + 1);
			if (temp != -1 && temp < end)
				start = temp;
			else if(temp != -1 && temp >= end)
				break;
			else if(temp == -1)
				break;
		}
		if(start != -1 && end != -1)
		{
			if (start > end)
			{
				if (gGame)
					gGame->ReportError(Core::String::Format("RPC DATE ERROR"));
				return;
			}
			CStrBuf<4096> buf;
			buf.copy(str, start + 1, end - start - 1);
			Translate(buf);
			str.remove(start, end + 1);
			str.insert(start, buf.buff());
			Translate(str);
		}
		else
		{
			CStrBuf<4096> key;
			CStrBuf<32> buff;
			int begin = 0;
			int pos = str.find('^');
			if(pos != -1)
			{
				key.copy(str, begin, pos);
				key.format("%s", gLang->GetText(key));
				int pos_new = str.find('^', pos + 1);
				if ( pos_new != -1)
				{
					buff.copy(str,pos + 1,pos_new - pos - 1);
					for (int i = 0; i < atoi(buff); ++i)
					{
						int start = key.find('|');
						if (start != -1)
						{
							CStrBuf<4096> buf;
							CStrBuf<4096> bufs;
							CStrBuf<4096> bufe;
							begin = pos_new;
							pos_new = str.find('^',begin + 1);
							if (pos_new != 1)
								buf.copy(str, begin + 1, pos_new - begin - 1);
							else
								buf.copy(str, begin + 1, str.len() - begin - 1);
							int start = key.find('|');

							bufs.copy(key, 0, start);
							bufe.copy(key, start + 1, key.len() - start - 1);
							key.format("%s%s%s", bufs.buff(), buf.buff(), bufe.buff());
						}
					}	
				}
				str.format("%s", key.buff());
			}
		}
	}

	void GameGlobal::Translate(Core::String & str)
	{
		Core::CStrBuf<4096> buf = str;
		Translate(buf);
		str = buf;
	}

	int GameGlobal::TextLenght(Core::String str)
	{
		char *p = (char *)str.Str();
		int count = 0;

		while(*p != '\0')
		{
	#ifdef USE_UTF8
			S32 len = GetUTF8CharLength((U8*)p, -1);
			if (len)
			{
				p += len;
			}
			else
			{
				return count;
			}
	#else
			if(IsDBCSLeadByteEx(936,*p))
			{
				p++;
			}
			p++;
	#endif
			count++;
		}

		return count;
	}

	Core::String GameGlobal::StrCut(Core::String str,int cut_num)
	{
		if (TextLenght(str) > cut_num  && str.Length() > (size_t)2*cut_num)
		{
			str = Core::String::Format("%s...",TextCopy(str, 0,cut_num));
		}
		return str;
	}

	Core::String GameGlobal::ReadINIString( const Core::String &sectionName, const Core::String &keyName )
	{
		Core::String fileName = GetINIFileName();
		CStrBuf<256> resultStr;
		GetPrivateProfileStringA(sectionName, keyName, Core::String::kEmpty, resultStr.buff(), resultStr.size32(), fileName);
		return Core::String::Format("%s", resultStr);
	}

	bool GameGlobal::WriteINIString( const Core::String &sectionName, const Core::String &keyName, const Core::String &keyValue )
	{
		Core::String fileName = GetINIFileName();
		return (WritePrivateProfileStringA(sectionName, keyName, keyValue, fileName)==TRUE);
	}

	int GameGlobal::ReadINIInt( const Core::String &sectionName, const Core::String &keyName )
	{
		Core::String fileName = GetINIFileName();
		U32 resultInt = GetPrivateProfileIntA(sectionName, keyName, 0, fileName);
		return resultInt;
	}

	bool GameGlobal::WriteINIInt( const Core::String &sectionName, const Core::String &keyName, int keyValue )
	{
		Core::String fileName = GetINIFileName();
		return (WritePrivateProfileStringA(sectionName, keyName, Core::String::Format("%d", keyValue), fileName)==TRUE);
	}

	Core::String GameGlobal::GetINIFileName()
	{
		CStrBuf<256> temp;
		GetModuleFileNameA(NULL, temp.buff(), temp.size32());
		Path::ContractPath(temp, temp.buff(), "fc.ini");
		return Core::String(temp);
	}

#if DEBUG_TOOLS
	void GameGlobal::ModelViewer()
	{
		gGame->machine.ChangeState(ptr_new StateDebugAnim);
	}

	void GameGlobal::SceneViewer()
	{
		gGame->machine.ChangeState(ptr_new StateDebugScene);
	}
#endif
}
