namespace Client
{
	static const int OctNodeNum = 8;

	class OctTreeNode 
	{
	public:
		// constructor
		OctTreeNode();

		// destructor
		~OctTreeNode();

		// build child
		void BuildChild(const Core::AxisAlignedBox& box, const Core::Vector3& threshold, int level = 0);

		void BuildChild(Core::Stream& stream);

		void BuildChild(const OctTreeNode* node);

		// save to stream
		void SaveToStream(Core::Stream& stream);

	public:
		//get node by position
		OctTreeNode* GetNodeByPosition(const Core::Vector3& pos);

		//get leaf node
		void GetLeaf(Core::Deque<OctTreeNode*>& list);

	public:
		bool IsLeaf() const
		{
			return m_child.Size() == 0;
		}

		const Core::AxisAlignedBox& GetAABB() const
		{
			return m_aabb;
		}

		const Core::Array<int>& GetVisibleList() const
		{
			return m_visible_id_list;
		}

		Core::Array<int>& GetVisibleListW()
		{
			return m_visible_id_list;
		}

		int GetLevel() const
		{
			return m_level;
		}

		int GetId() const
		{
			return m_id;
		}

		const Core::StaticArray<OctTreeNode*, OctNodeNum>& GetChilds() const
		{
			return m_child;
		}

	private:
		void UnLoadData();

	private:
		Core::AxisAlignedBox	m_aabb;
		Core::Array<int>		m_visible_id_list;

		int						m_level;
		int						m_id;
		Core::StaticArray<OctTreeNode*, OctNodeNum>	m_child;
	};

	class MapVisibleTree : public Resource
	{
	public:
		// constructor
		MapVisibleTree();

		// destructor
		~MapVisibleTree();

		// build tree
		void BuildTree(const Core::AxisAlignedBox& aabb, const Core::Vector3& threshold);

		bool BuildTree(Core::Stream& stream);

		bool SaveTree(Core::Stream& stream);

		//get visible list by position
		bool GetVisibleListByPosition(const Core::Vector3& pos, const Core::Array<int>*& pVisibleList);

		//get leaf list
		void GetAllLeaf(Core::Deque<OctTreeNode*>& list) const;

		//get root
		OctTreeNode* GetRoot() const;

	public:
		/// save data
		virtual bool SaveData(Core::Stream& stream);

		/// load data
		virtual sharedc_ptr(Object) LoadData(Core::Stream& stream);

		/// load data
		virtual sharedc_ptr(Object) BuildData();

		/// unload data
		virtual void UnloadData();

		/// on load data
		virtual bool OnLoadData(by_ptr(Object) obj);

		// get version
		virtual short GetVersion();

	private:
		// root
		OctTreeNode*	root;

		// threshold
		Core::Vector3	threshold;
	};

	void PrintMapVisibleTree(const MapVisibleTree& tree, Core::TextStreamWriter& writer);
}
