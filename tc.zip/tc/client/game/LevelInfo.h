namespace Client
{

	enum SupplyType
	{
		kSupplyNone = 0,
		kSupplyWeapon = 1,
		kSupplyItemHealth = 10,
		kSupplyItemArmor = 11,
		kSupplyItemAmmo = 12,
		kSupplyItemLevelUp = 13,
		kSupplyItemPowerUp = 14,

		kSupplySkillSpeedUp = 20,
		kSupplyControlReverse,
		kSupplyInvincible,
		kSupplyRadar,
		kSupplyTeleport,
	};

	enum ItemEffectType
	{
		kItemEffectNone = 0,
		kItemEffectPowerUp = kSupplyItemPowerUp,
	};

	enum SkillType
	{
		kSkillNone = 0,
		kSkillSpeedUp = 1,
		kSkillControlReverse,
		kSkillCureGun,
		kSkillInvincible,
		kSkillRadar,
		kSkillTeleport,
		kSkillControlStickBomb,
		kSkillWindReverse,
		kSkillZombie,
		kSkillZombieCharge,
		kSkillHunterCharge,
		kSkillActiveSlot1,
		kSkillBoss2_S1,
		kSkillBoss2_S2,
		kSillCharacter_KC6,
	};

	enum SustainHurtType
	{
		kSustainNone 				= 0,
		kSustainFlameHurt			= 1,
		kSustainHurtCutHurt			= 2,
		kSustainHurtPoison			= 3,
		kSustainHurtFrost			= 4,
		kSustainSurvivalMode		= 5,
		kSustainHurtcount ,
	};

	struct PlayerSkill
	{
		PlayerSkill()
			:type(kSkillNone)
			, uid(0)
			, effect_value(0)
			, effect_time(0)
		{
		}

		SkillType	type;
		byte		uid;
		float		effect_value;
		float		effect_time;
	};
}