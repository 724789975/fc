namespace Client
{
	enum GunTargetState
	{
		GUNTARGET_DOWN = 0,
		GUNTARGET_UP,
	};

	enum GunTargetType 
	{
		STATIC = 0,
		MOVEABLE,
		GUNTARGET_TYPE_COUNT,
	};

	struct GunTargetInfo :Core::Object
	{
		GunTargetInfo()
		{
			guntarget_type = 0;
			id = -1;
		}

		byte				guntarget_type;
		int					id;
		int					uid;
		Core::Vector3		position;
		Core::Vector3		end_position;
		Core::Quaternion	rotation;
		Core::Vector3       collision_box_dim;
		Core::String		target_mesh_name;
	};

	class GunTarget : public Core::Object
	{
	public:
		/// constructor
		GunTarget(by_ptr(GunTargetInfo) info);
		/// destructor
		virtual ~GunTarget();

	public:
		void Initialize();

		void Draw(Primitive::DrawType drawtype, bool immediate = false);

		void SetPosition(Core::Vector3& pos);

		void SetRotation(Core::Quaternion& rot);

		void ReleasePhysX();

		int GetID();

		void Update(float frame_time);

		bool CheckFire(const Core::Vector3 & pos, float & distance);										// luncher

		bool CheckFire(const Core::Vector3 & position, const Core::Quaternion & rotation, float spread);	// gun

		bool CheckFire(const Core::Vector3 & position, const Core::Quaternion & rotation, float spread, int userdata, int userdata2); //flamegun

		bool CheckStab(const tempc_ptr(KnifeInfo) knife_info); //knife

		static tempc_ptr(GunTarget) FromNxActor(NxActor & actor);

	protected:
		void UpdatePhysX();

	public:
		sharedc_ptr(GunTargetInfo) guntarget_info;
		int	status;

	protected:
		sharedc_ptr(StaticMesh)	mesh_guntarget;
		Core::Vector3			position;
		Core::Quaternion		rotation;
		
		NxActor*				collider;
		Core::AxisAlignedBox	gate_aabb;

		float					pos_y;
		bool					is_starttoend;
		float					move_time;
	};
}