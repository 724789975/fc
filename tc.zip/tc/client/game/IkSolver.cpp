#include "pch.h"

using namespace Core;
using namespace Client;

bool IkJoint::GetJointRotation(const Vector3 & to_effector, const Vector3 & to_target, const Quaternion & current_rot, bool is_root, Quaternion & rot) const
{
	if (1 || is_root)
	{
		rot.SetFromTo(to_effector, to_target);
		return true;
	}
	else
	{
		Vector3 axis_x(hinge_base * current_rot);
		Vector3 axis_z(hinge_axis * current_rot);
		Vector3 axis_y = Cross(axis_z, axis_x);

		float x, y;
		x =  Dot(to_target, axis_x);
		y =  Dot(to_target, axis_y);
		if (sqrtf(x * x + y * y) < EPSILON)
			return false;

		float angle_target = Atan2(y, x);

		x = Dot(to_effector, axis_x);
		y = Dot(to_effector, axis_y);
		if (sqrtf(x * x + y * y) < EPSILON) 
			return false; 

		float angle_effector = Atan2(y, x);

		rot.SetAxisAngle(axis_z, angle_target - angle_effector);
		rot.Normalize();
		return true;
	}
}

void IkSolver::Solver(Array<sharedc_ptr(IkJoint)> & joints, const Client::Transform & target, float iteration, float lerance)
{
	int size = joints.Size();

	if (size < 1)
		return;

	tempc_ptr(IkJoint) effector = joints[size - 1];

	if (!effector)
		return;

	Transform & transform_effector = effector->transform;

	for (int iter = 0; iter < iteration; ++iter)
	{
		if (Length(target.position - transform_effector.position) < lerance)
			break;
	
		for (int i = 0; i < size - 1; ++i)
		{
			tempc_ptr(IkJoint) joint = joints[i];

			if (!joint)
				continue;

			float weight;
			if ((weight = joint->weight) == 0.0f)
				continue;
			
			Transform & transform_cur = joint->transform;
	
			Vector3 to_effector(transform_effector.position - transform_cur.position);	
			Vector3 to_target(target.position - transform_cur.position);
			Quaternion rot_all;

			if (joint->lock || !joint->GetJointRotation(to_effector, to_target, transform_cur.rotation, (i == 0), rot_all))
				continue;
			
			Quaternion rot(0.0f, 0.0f, 0.0f, 1.0f);

			if (weight == 1.0f)
				rot = rot_all;
			else
			{
				Lerp(rot, rot, rot_all, weight);
			}

			for (int j = i; j < size; ++j)
			{
				tempc_ptr(IkJoint) joint_child = joints[j];

				if (!joint_child)
					continue;

				Transform & transform =joint_child->transform;
				transform.rotation = transform.rotation * rot;
				transform.rotation.Normalize();
				transform.position = (transform.position - transform_cur.position) * rot + transform_cur.position;
			}
		}
	}

	transform_effector.rotation = target.rotation;
}