namespace Client
{
	struct DualPistolInfo : public PistolInfo
	{
		DualPistolInfo()
		{
			weapon_type = kWeaponTypeDualPistol;
		}
	};

	class DualPistol : public Pistol
	{
	public:
		/// constructor
		DualPistol(by_ptr(DualPistolInfo) info);

		bool Fire();

	public:
		/// initialize
		virtual void Initialize();

		/// update animation
		virtual void UpdateAnimation(float time);

		/// get weapon type
		virtual uint GetWeaponType();

		virtual tempc_ptr(Pose) GetPose();

	public:
		/// set left weapon transform
		void SetLeftWeaponTransform(const Transform & transform);

		/// set right weapon transform
		void SetRightWeaponTransform(const Transform & transform);
	};
}