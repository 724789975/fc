#include "pch.h"

using namespace Core;

namespace Client
{
	struct SkeletonData : public Object
	{
		Core::Identifier		name;
		Core::Array<Joint>		joints;
		Core::Array<Transform>	transforms;
	};

	/// transform knull
	const Transform Transform::kNull(Vector3(0,0,0), Quaternion(0,0,0,1));

	/// joint knull
	const Joint Joint::kNull;

	/// get joint
	const Joint & Skeleton::GetJoint(uint id)
	{
		if (id < joints.Size())
			return joints[id];
		return Joint::kNull;
	}

	/// get joint set
	const Core::Array<Joint> & Skeleton::GetJointSet()
	{
		return joints;
	}

	/// set joint blend skip
	void Skeleton::SetJointBlendSkip(const Core::Identifier & name, bool blend_skip)
	{
		int id = GetJointId(name);

		if (id > -1 && id < (int)joints.Size())
			joints[id].blend_skip = blend_skip;
	}

	/// constructor
	Skeleton::Skeleton()
	{
		pose = ptr_new Pose(NullPtr);
	}

	/// get version
	short Skeleton::GetVersion()
	{
		return 3;
	}

	/// save data
	bool Skeleton::SaveData(Stream & stream)
	{
#ifndef MASTER
		Resource::SaveData(stream);

		uint size = name.Length() * sizeof(char);
		size = joints.Size();
		stream.Write(&size, sizeof(uint));
		for (uint i = 0; i < size; ++i)
		{
			stream.Write(&joints[i].parent_id, sizeof(int));
			uint len = joints[i].name.Length();
			stream.Write(&len, sizeof(uint));
			stream.Write(joints[i].name.Str(), sizeof(char) * len);
		}

		Array<Transform> & transforms = pose->GetLocalPose();
		size = transforms.Size();
		stream.Write(&size, sizeof(uint));
		stream.Write(transforms.GetData(), sizeof(Transform) * size);
		return true;
#else
		return false;
#endif
	}

	/// load data
	sharedc_ptr(Object) Skeleton::LoadData(Stream & stream)
	{
		if (!Resource::LoadData(stream))
			return NullPtr;
		
		sharedc_ptr(SkeletonData) data = ptr_new SkeletonData;
		uint size; 
		stream.Read(&size, sizeof(uint));
		data->joints.Resize(size);
		for(uint i = 0; i < size; ++i)
		{
			int id = -1;
			stream.Read(&data->joints[i].parent_id, sizeof(id));
			uint len = 0;
			stream.Read(&len, sizeof(uint));
			CStrBuf<256> str;
			str.setlen(len);
			stream.Read(str.buff(), sizeof(char) * len);
			data->joints[i].name = str.buff();
		}
		stream.Read(&size, sizeof(uint));
		data->transforms.Resize(size);
		stream.Read(data->transforms.GetData(), sizeof(Transform) * size);
		return data;
	}

	/// load data
	sharedc_ptr(Object) Skeleton::BuildData()
	{
#ifndef MASTER
		sharedc_ptr(SkeletonData) data = ptr_new SkeletonData;
		data->name = "test";
		Lua::LuaState *L = Lua::LuaState::NewState();

		int top = L->GetTop();
		L->NewTable();
		if (L->LoadFile(GetPath(), true) == 0)
		{
			L->PushValue(top + 1);
			L->SetFenv(-2);

			if (L->DoCall(0, 0))
			{
				const char *msg = L->ToString(-1);
				if (msg) Console.WriteLine(msg);
				L->Pop(1);

				data = NullPtr;
			}
			else
			{
				if (data)
				{
					L->GetField(top + 1, "Joints");
					int array_size = L->ObjLen(-1);
					Core::Array<Joint>&	joints = data->joints;
					Core::Array<Transform>&	pose = data->transforms;
					joints.Clear();
					pose.Clear();

					joints.Resize(array_size + 1);
					pose.Resize(array_size + 1);

					joints[0].parent_id = -1;
					pose[0].position = Vector3::kZero;
					pose[0].rotation = Quaternion::kIdentity;

					for (int i = 0; i < array_size; i++)
					{
						Joint & joint = joints[i + 1];
						Transform & transform = pose[i + 1];

						L->PushInteger(i + 1);
						L->GetTable(-2);

						L->PushInteger(1);
						L->GetTable(-2);
						joint.name = L->ToString(-1);
						L->Pop(1);

						L->PushInteger(2);
						L->GetTable(-2);
						joint.parent_id = L->ToInteger(-1) + 1;
						L->Pop(1);

						L->PushInteger(3);
						L->GetTable(-2);
						transform.position.x = L->ToNumber(-1) / 100;
						L->Pop(1);

						L->PushInteger(4);
						L->GetTable(-2);
						transform.position.y = L->ToNumber(-1) / 100;
						L->Pop(1);

						L->PushInteger(5);
						L->GetTable(-2);
						transform.position.z = L->ToNumber(-1) / 100;
						L->Pop(1);

						L->PushInteger(6);
						L->GetTable(-2);
						transform.rotation.x = L->ToNumber(-1);
						L->Pop(1);

						L->PushInteger(7);
						L->GetTable(-2);
						transform.rotation.y = L->ToNumber(-1);
						L->Pop(1);

						L->PushInteger(8);
						L->GetTable(-2);
						transform.rotation.z = L->ToNumber(-1);
						L->Pop(1);

						L->PushInteger(9);
						L->GetTable(-2);
						transform.rotation.w = L->ToNumber(-1);
						L->Pop(1);

						L->Pop(1);
					}
				}
			}
		}
		else
		{
			const char *msg = L->ToString(-1);
			if (msg) Console.WriteLine(msg);
			L->Pop(1);
			
			data = NullPtr;
		}

		L->SetTop(top);
		L->Close();

		AddDependenceFilePath(GetPath());
		return data;
#else
		return NullPtr;
#endif
	}

	/// unload data
	void Skeleton::UnloadData()
	{
		joints.Clear();
		pose = NullPtr;
	}

	/// on load data
	bool Skeleton::OnLoadData(by_ptr(Object) obj)
	{
		tempc_ptr(SkeletonData) data = ptr_static_cast<SkeletonData>(obj);
		if (data)
		{
			joints = data->joints;

			for (uint i = 0; i < joints.Size(); ++i)
			{
				if (joints[i].name.Length() > 0)
					name_to_id.Add(joints[i].name, i);
			}

			pose->SetSkeleton(ptr_new_reference(this));
			pose->SetLocalPose(data->transforms);
			return true;
		}
		return false;
	}
	
	/// get jonit id
	int Skeleton::GetJointId(const Identifier & name)
	{
		return name_to_id.Get(name, -1);
	}

	/// get T-pose
	const Core::Array<Transform> & Skeleton::GetLocalPose()
	{
		PDE_ASSERT(pose, "skeleton pose error!");
		return pose->GetLocalPose();
	}

	/// get model pose
	const Core::Array<Transform> & Skeleton::GetModelPose()
	{
		PDE_ASSERT(pose, "skeleton pose error!");
		return pose->GetModelPose();
	}

	/// get joint name
	const Identifier & Skeleton::GetJointName(uint id)
	{
		if (id < joints.Size())
		{
			return joints[id].name;
		}

		return Identifier::kNull;
	}

	/// get joint parent id
	int Skeleton::GetJointParentId(uint id)
	{
		if (id < joints.Size())
		{
			return joints[id].parent_id;
		}

		return -1;
	}

	/// get joint count
	uint Skeleton::GetJointCount()
	{
		return joints.Size();
	}

	/// joint is child of
	bool Skeleton::JointIsChildOf(uint child_id, uint parent_id)
	{
		if (child_id >= joints.Size())
			return false;

		if (parent_id >= joints.Size())
			return false;

		const Joint & child = joints[child_id];

		if (child.parent_id == parent_id)
			return true;

		return JointIsChildOf(child.parent_id, parent_id);
	}

	/// get joint local T-pose
	const Transform & Skeleton::GetJointLocalPose(uint id)
	{
		if (pose)
			return pose->GetJointLocalPose(id);

		return Transform::kNull;
	}

	/// get joint model T-pose
	const Transform & Skeleton::GetJonitModelPose(uint id)
	{
		if (pose)
			return pose->GetJointModelPose(id);

		return Transform::kNull;
	}

	/// get name
	const Identifier & Skeleton::GetName()
	{
		return name; 
	}

	/// constructor
	SkeletonMap::SkeletonMap(by_ptr(Skeleton) s)
		: skeleton(s)
	{
		if (skeleton)
		{
			map.Resize(skeleton->GetJointCount(), 0);
		}
	}

	/// add joint
	bool SkeletonMap::AddJoint(const Identifier & name, bool skip_child, byte type)
	{
		bool ret = false;

		if (skeleton)
		{
			int joint_id = -1;
			for (uint i = 0; i < skeleton->GetJointCount(); ++i)
			{
				if (name == skeleton->GetJointName(i))
				{
					joint_id = i;
					if (map[i] != type)
					{
						map[i] = type;
						ret = true;
					}

					if (skip_child)
						break;
				}

				if (!skip_child && joint_id != -1 && skeleton->JointIsChildOf(i, joint_id))
					map[i] = type;
			}
		}

		return ret;
	}

	/// add joint from to
	bool SkeletonMap::AddJointFromTo(const Identifier & from, const Identifier & to, byte type)
	{
		bool ret = false;

		if (skeleton)
		{
			int joint_from = -1;
			for (uint i = 0; i < skeleton->GetJointCount(); ++i)
			{
				if (from == skeleton->GetJointName(i))
				{
					joint_from = i;

					if (map[i] != type)
					{
						map[i] = type;
						ret = true;
					}
				}

				if (joint_from != -1)
				{
					if (map[i] != type)
					{
						map[i] = type;
						ret = true;
					}

					if (to == skeleton->GetJointName(i))
						break;
				}
			}
		}

		return ret;
	}

	void ChangeNodeEventBase::OnAnimationStartFPEvent( const Core::Identifier & groupname, int & index )
	{

	}

	void ChangeNodeEventBase::OnAnimationStartTPEvent( const Core::Identifier & groupname, int & index )
	{

	}

	void ChangeNodeEventBase::OnAnimationEndFPEvent( const Core::Identifier & groupname, int & index )
	{

	}

	void ChangeNodeEventBase::OnAnimationEndTPEvent( const Core::Identifier & groupname, int & index )
	{

	}

}

namespace Client
{
	/// constructor
	AnimationSetRes::AnimationSetRes()
	{
	}
	
	/// get version
	short AnimationSetRes::GetVersion()
	{
		return 1;
	}

	/// load data
	sharedc_ptr(Object) AnimationSetRes::BuildData()
	{
		sharedc_ptr(AnimationSet) data;

		CStrBuf<MAX_PATH> path(GetPath().Str());
		if (Path::IsDirectory(path))
		{
			data = ptr_new AnimationSet;
			Lua::LuaState * LuaState = Lua::LuaState::NewState();
			PdeItPath it;
			it.Reset(path, false);

			while(it.MoveNext())
			{
				if (it.IsDirectory())
					continue;

				CStrBuf<MAX_PATH> str;
				str.format("%s/%s", GetPath().Str(), it.Name().buff());
				str.remove_back(".cache");

				sharedc_ptr(Animation) animation = RESOURCE_GET(str, Animation);
				if (animation)
				{
					AddDependenceFilePath(str);
					animation->Load(false);
					Path::GetFileNameWithoutExtension(str, str);
					data->AddAnimation(str, animation);
				}
			}
			LuaState->Close();
		}

		return data;
	}

	/// load data
	sharedc_ptr(Object) AnimationSetRes::LoadData(Core::Stream & stream)
	{
		// no load from cache
		return NullPtr;
	}

	/// load data
	bool AnimationSetRes::SaveData(Core::Stream & stream)
	{
		// don't save animation set
		return false;
	}

	/// unload data
	void AnimationSetRes::UnloadData()
	{
		animation_set = NullPtr;
	}

	/// on load data
	bool AnimationSetRes::OnLoadData(by_ptr(Object) obj)
	{
		tempc_ptr(AnimationSet) data = ptr_static_cast<AnimationSet>(obj);
		
		if (data)
		{
			animation_set = data;
			return true;
		}
		return false;
	}

	/// get animation
	tempc_ptr(Animation) AnimationSetRes::GetAnimation(const Core::Identifier & key)
	{
		if (animation_set)
			return animation_set->GetAnimation(key);
		return NullPtr;
	}

	/// get animation set
	tempc_ptr(AnimationSet) AnimationSetRes::GetAnimationSet()
	{
		return animation_set;
	}
}

namespace Client
{
	/// constructor
	Animation::Animation()
	{
	}
	
	/// get version
	short Animation::GetVersion()
	{
		return 3;
	}

	/// load data
	sharedc_ptr(Object) Animation::BuildData()
	{
#ifndef MASTER
		sharedc_ptr(AnimationTrack) data = ptr_new AnimationTrack;

		if (data->Load(GetPath()))
		{
			AddDependenceFilePath(GetPath());
			return data;
		}
#endif

		return NullPtr;
	}

	/// unload data
	void Animation::UnloadData()
	{
		track = NullPtr;
	}

	/// save data
	bool Animation::SaveData(Stream & stream)
	{
#ifndef MASTER
		Resource::SaveData(stream);
		track->Save(stream);
		return true;
#else
		return false;
#endif
	}

	/// load data
	sharedc_ptr(Object) Animation::LoadData(Stream & stream)
	{
		if (!Resource::LoadData(stream))
			return NullPtr;

		sharedc_ptr(AnimationTrack) data = ptr_new AnimationTrack;
		data->Load(stream);
		return data;
	}

	/// on load data
	bool Animation::OnLoadData(by_ptr(Object) obj)
	{
		sharedc_ptr(AnimationTrack) data = ptr_static_cast<AnimationTrack>(obj);
		if (data)
		{
			track = data;
			return true;
		}

		return false;
	}

	/// rebuild
	void Animation::Rebuild(by_ptr(AnimationTrack) t, Array<int> & bone_to_id)
	{
	}

	/// sample track
	bool Animation::SampleTrack(float time, tempc_ptr(Skeleton) skeleton, Array<Transform> & out, bool auto_circle)
	{
		if (track && skeleton)
		{
			if (time > GetAnimationTime())
				return false;

			uint joint_count = skeleton->GetJointCount();

			if (out.Size() != joint_count)
				out.Resize(joint_count);

			for (uint i = 0; i < out.Size(); i ++)
			{
				Transform & transform = out[i];

				const Joint & joint = skeleton->GetJoint(i);

				if (!track->HasJoint(joint.name))
				{
					transform = Transform::kNull;
					continue;
				}

				track->GetTransform(joint.name, time, transform);
			}

			return true;
		}

		return false;
	}

	/// sample track
	bool Animation::SampleTrack(float time, Array<int> & joints, Array<Transform> & out, bool auto_circle)
	{
		PROFILE("Animation::SampleTrack");
		if (track)
		{
			if (time > GetAnimationTime())
				return false;

			uint joint_count = joints.Size();

			if (out.Size() != joint_count)
				out.Resize(joint_count);

			int frame_count = track->GetFrameCount();
			float frame_rate = track->GetFrameRate();
			float length = (frame_count - 1) / frame_rate;

			if (length == 0)
				time = 0;
			else if (time > length || time < -length)
				time = Fmod(time, length);

			int frame = time * frame_rate;
			//float lerp = time * frame_rate - frame;
			tempc_ptr(AnimationTrack::JointData) joint_data;
			const Array<sharedc_ptr(AnimationTrack::JointData)> & joint_array = track->joint_array;

			for (uint i = 0; i < out.Size(); i ++)
			{
				Transform & transform = out[i];

				int joint_id = joints[i];
				if (joint_array.IsValidIndex(joint_id))
				{
					joint_data = joint_array[joint_id];

					PDE_ASSERT(joint_data, "joint data error!");
					PDE_ASSERT(joint_data->data.Size() / frame_count == 7, "data1 size error!");
					PDE_ASSERT(joint_data->data.Size() > (uint)(frame * 7 + 6), "data2 size error!");

					const float* p = joint_data->data.GetData();
					p += frame * 7;

					memcpy(&transform, p, sizeof(float) * 7);
				}
				else
					transform = Transform::kNull;
			}

			return true;
		}

		return false;
	}

	/// get animation time
	float Animation::GetAnimationTime()
	{
		if (track)
			return track->GetAnimationTime();

		return 0.f;
	}

	/// build animation joint map
	void Animation::BuildJointMap(by_ptr(Skeleton) skeleton, Core::Array<int> & joint_map)
	{
		if (skeleton && track)
		{
			joint_map.Resize(skeleton->GetJointCount());
			for (uint i = 0; i < skeleton->GetJointCount(); i ++)
				joint_map[i] = GetAnimationTrack()->GetJointId(skeleton->GetJointName(i));
		}
	}

	/// constructor
	AnimationSet::AnimationSet()
	{
	}

	/// destructor
	AnimationSet::~AnimationSet()
	{
		animation_set.Clear();
		res_set.Clear();
	}

	/// add animation
	void AnimationSet::AddAnimation(const Identifier & key, by_ptr(Animation) animation)
	{
		animation_set.Add(key, animation);
	}

	// remove animation
	void AnimationSet::RemoevAnimation(const Identifier & key)
	{
		animation_set.Remove(key);
	}

	/// get animation
	tempc_ptr(Animation) AnimationSet::GetAnimation(const Identifier & key)
	{
		return animation_set.Get(key, NullPtr);
	}

	/// set animation
	void AnimationSet::SetAnimation(const Identifier & key, by_ptr(Animation) animation)
	{
		animation_set.Set(key, animation);
	}

	/// on animation set res dirty
	void AnimationSet::OnAnimationDirty(by_ptr(void) sender, uint & args)
	{
		tempc_ptr(AnimationSetRes) res = ptr_static_cast<AnimationSetRes>(sender);

		if (res && res->GetState() == Resource::kLoaded && res->animation_set)
		{
			HashSet<Identifier, sharedc_ptr(Animation)>::Enumerator it(res->animation_set->animation_set);

			while (it.MoveNext())
			{
				SetAnimation(it.Key(), it.Value());
			}
		}
	}

	/// set animation set
	void AnimationSet::SetAnimationSet(const Identifier & key, by_ptr(AnimationSetRes) set)
	{
		tempc_ptr(AnimationSetRes) res = res_set.Get(key, NullPtr);
		{
			if (res)
			{
				tempc_ptr(EventHandler) h = handler_set.Get(key, NullPtr);
				if (h)
				{
					res->event_dirty.Remove(h);
					handler_set.Set(key, NullPtr);
				}
			}

			res_set.Set(key, set);
			if (set)
			{
				sharedc_ptr(EventHandler) handler = NewDelegate(&AnimationSet::OnAnimationDirty, ptr_static_cast<AnimationSet>(this));
				set->event_dirty.Subscribe(handler);
				handler_set.Set(key, handler);
				uint args = 0;
				OnAnimationDirty(set, args);
			}
		}
	}

	/// is ready
	bool AnimationSet::IsReady()
	{
		HashSet<Identifier, sharedc_ptr(AnimationSetRes)>::Enumerator it(res_set);

		while (it.MoveNext())
		{
			if (it.Value() && !it.Value()->IsReady())
				return false;
		}
		return true;	
	}

	/// get animationset's key list
	Core::Array<Core::Identifier> AnimationSet::GetAnimationSetKeyList()
	{
		Core::Array<Core::Identifier> keylist;
		HashSet<Identifier, sharedc_ptr(Animation)>::Enumerator it(animation_set);

		while (it.MoveNext())
		{
			if (it.Value() && it.Value()->IsReady())
				keylist.Add(it.Key());
		}
		return keylist;

	}

	/// constructor
	Pose::Pose(by_ptr(Skeleton) s)
		: pose_dirty(true)
	{
		SetSkeleton(s);
	}

	/// update model pose
	void Pose::UpdateModelPose(bool skip_lock_pose)
	{
		if (pose_dirty)
		{
			if (skeleton && model_pose.Size() > 0)
			{
				model_pose[0] = local_pose[0];
				uint count = model_pose.Size();
				Transform * transform = model_pose.GetData() + 1;
				Transform * local = local_pose.GetData() + 1;
				bool * lock = lock_pose.GetData() + 1;

				for (uint i = 1; i < count; i ++)
				{
					if (skip_lock_pose || !*lock)
					{
						const Joint & joint = skeleton->GetJoint(i);
						int parent_id = joint.parent_id;

						if (parent_id >= 0 && parent_id < (int)count)
						{
							Transform * model = &model_pose[parent_id];
							transform->rotation = local->rotation * model->rotation;
							transform->position = model->position + local->position * model->rotation;
						}
					}

					transform++;
					lock++;
					local++;
				}
			}

			pose_dirty = false;
		}
	}

	/// set local pose
	void Pose::SetLocalPose(const Core::Array<Transform> & transform)
	{
		uint joint_count = transform.Size();
		local_pose.Resize(joint_count);
		model_pose.Resize(joint_count);

		lock_pose.Resize(joint_count, false);

		CopyLocalPose(transform);
	}

	/// initialize skeleton 
	void Pose::InitializeSkeleton()
	{
		if (skeleton->IsReady() && &local_pose != &skeleton->GetLocalPose())
		{
			uint joint_count = skeleton->GetJointCount();
			local_pose.Resize(joint_count);
			model_pose.Resize(joint_count);
			CopyLocalPose(skeleton->GetLocalPose());

			lock_pose.Resize(joint_count, false);

		}
	}

	/// set skeleton
	void Pose::SetSkeleton(by_ptr(Skeleton) s)
	{
		if (s && (s != skeleton))
		{
			skeleton = s;
			InitializeSkeleton();
		}
	}

	/// copy local pose
	void Pose::CopyLocalPose(const Core::Array<Transform> & transforms)
	{
		uint joint_count = local_pose.Size();

		if (joint_count > 0 && joint_count == transforms.Size())
		{
			memcpy(local_pose.GetData(), transforms.GetData(), sizeof(Transform) * joint_count);
			pose_dirty = true;
		}
	}

	/// set local pose zero
	void Pose::SetLocalPoseZero()
	{
		for (uint i = 0; i < local_pose.Size(); ++i)
		{
			local_pose[i] = Transform::kNull;
		}
	}

	/// get joint count
	uint Pose::GetJointCount()
	{
		if (skeleton)
			return skeleton->GetJointCount();
		return 0;
	}

	/// get joint parent id
	int Pose::GetJointParentId(uint id)
	{
		if (skeleton)
			return skeleton->GetJointParentId(id);

		return -1;
	}

	/// set joint local pose
	void Pose::SetJointLocalPose(uint id, const Transform & transform)
	{
		if (id < local_pose.Size())
		{
			local_pose[id] = transform;
			pose_dirty = true;
		}
	}

	/// set joint local pose position
	void Pose::SetJointLocalPosePosition(uint id, const Core::Vector3 & position)
	{
		if (id < local_pose.Size())
		{
			local_pose[id].position = position;
			pose_dirty = true;
		}
	}

	/// set joint local pose rotation
	void Pose::SetJointLocalPoseRotation(uint id, const Core::Quaternion & rotation)
	{
		if (id < local_pose.Size())
		{
			local_pose[id].rotation = rotation;
			pose_dirty = true;
		}
	}

	/// set joint model pose
	void Pose::SetJointModelPose(uint id, const Transform & transform, bool dirty)
	{
		if (id < model_pose.Size() && lock_pose[id])
		{
			model_pose[id] = transform;
			pose_dirty = dirty;
		}
	}

	/// set joint model pose position
	void Pose::SetJointModelPosePosition(uint id, const Core::Vector3 & position, bool dirty)
	{
		if (id < model_pose.Size() && lock_pose[id])
		{
			model_pose[id].position = position;
			pose_dirty = dirty;
		}
	}

	/// set joint model pose rotation
	void Pose::SetJointModelPoseRotation(uint id, const Core::Quaternion & rotation, bool dirty)
	{
		if (id < model_pose.Size() && lock_pose[id])
		{
			model_pose[id].rotation = rotation;
			pose_dirty = dirty;
		}
	}

	/// set joint lock pose
	void Pose::SetJointLockPose(uint id, bool flag)
	{
		if (id < lock_pose.Size())
			lock_pose[id] = flag;
	}

	/// get joint lock pose
	bool Pose::GetJointLockPose(uint id)
	{
		if (id < lock_pose.Size())
			return lock_pose[id];

		return false;
	}

	/// get joint model pose
	const Transform & Pose::GetJointModelPose(uint id)
	{
		if (id < model_pose.Size())
		{
			UpdateModelPose();
			return model_pose[id];
		}

		return Transform::kNull;
	}

	/// get joint local pose
	const Transform & Pose::GetJointLocalPose(uint id)
	{
		if (id < local_pose.Size())
			return local_pose[id];

		return Transform::kNull;
	}

	/// get local pose
	Core::Array<Transform> & Pose::GetLocalPose()
	{
		pose_dirty = true;
		return local_pose;
	}

	/// get local pose
	const Core::Array<Transform> & Pose::GetLocalPoseConst()
	{
		return local_pose;
	}

	/// get model pose
	const Core::Array<Transform> & Pose::GetModelPose()
	{
		UpdateModelPose();
		return model_pose;
	}

	/// blend
	void Pose::Blend(by_ptr(Pose) pose1, by_ptr(Pose) pose2, float weight)
	{
		PROFILE("Pose::Blend");

		if (!skeleton)
			return;

		if (!pose1 && !pose2)
			return;

		if (!pose1) weight = 1;
		if (!pose2) weight = 0;

		if (weight >= 1 || weight <= 0 )
		{
			tempc_ptr(Pose) pose = weight >= 1 ? pose2 : pose1;

			uint joint_count = local_pose.Size();
			uint joint_count1 = pose->local_pose.Size();

			if (joint_count == joint_count1)
			{
				Transform * dst = local_pose.GetData();
				Transform * src = pose->local_pose.GetData();

				memcpy(dst, src, sizeof(Transform) * joint_count);

				pose_dirty = true;
			}
		}
		else
		{
			uint joint_count = local_pose.Size();
			uint joint_count1 = pose1->local_pose.Size();
			uint joint_count2 = pose2->local_pose.Size();

			if (joint_count <= joint_count1 && joint_count <= joint_count2)
			{
				Transform * dst = local_pose.GetData();
				Transform * src1 = pose1->local_pose.GetData();
				Transform * src2 = pose2->local_pose.GetData();
				const Joint * joint = skeleton->GetJointSet().GetData();

				for (uint i = 0; i < joint_count; i ++)
				{
					if (joint->blend_skip == false)
					{
						Core::Lerp(dst->position, src1->position, src2->position, weight);
						Core::Lerp(dst->rotation, src1->rotation, src2->rotation, weight);
					}
					else
					{
						memcpy(dst, src2, sizeof(Transform));
					}
					joint++;
					dst ++;
					src1 ++;
					src2 ++;
				}

				pose_dirty = true;
			}
		}
	}
}

namespace Client
{
	static void lua_LoadArray(Lua::LuaState *L, int id, Array<float>& o)
	{
		int array_size = L->ObjLen(id);
		o.Clear();
		o.Reserve(array_size);
		for (int i = 0; i < array_size; i++)
		{
			L->PushInteger(i + 1);
			L->GetTable(-2);
			o.PushBack(L->ToNumber(-1));
			L->Pop(1);
		}
	}

	/// load 
	void AnimationTrack::Load(Core::Stream & stream)
	{
		uint size = 0;
		CStrBuf<256> str;
		stream.Read(&size, sizeof(uint));

		sharedc_ptr(JointData) joint_data;
		
		for (uint i = 0; i < size; ++i)
		{
			uint len = 0;
			stream.Read(&len, sizeof(uint));
			str.setlen(len);
			stream.Read(str.buff(), len);

			joint_data = ptr_new JointData;
			joint_data->name = str;

			if (joint_data)
			{
				joint_index.Add(str.buff(), joint_array.Size());
				joint_array.PushBack(joint_data);

				stream.Read(&joint_data->frame_count, sizeof(uint));

				if (frame_count < 0)
					frame_count = joint_data->frame_count;

				uint len = 0;
				stream.Read(&len, sizeof(uint));
				joint_data->data.Resize(len);
				stream.Read(joint_data->data.GetData(), sizeof(float) * len);
			}
		}
	}

	/// save
	void AnimationTrack::Save(Core::Stream & stream)
	{
		BinaryStreamWriter writer(stream);

		writer.WriteUInt32(joint_array.Size());

		for (uint i = 0; i < joint_array.Size(); i ++)
		{
			tempc_ptr(JointData) joint_data = joint_array[i];

			if (joint_data)
			{
				writer.WriteString(joint_data->name);
				writer.WriteUInt32(joint_data->frame_count);
				writer.WriteUInt32(joint_data->data.Size());
				writer.Write(joint_data->data.GetData(), sizeof(float) * joint_data->data.Size());
			}
		}
	}

	bool AnimationTrack::Load(const Identifier & path)
	{
		bool success = false;

		Lua::LuaState *L = Lua::LuaState::NewState();
		int top = L->GetTop();
		L->NewTable();

		if (L->LoadFile(path, true) == 0)
		{
			L->PushValue(top + 1);
			L->SetFenv(-2);

			if (L->DoCall(0, 0))
			{
				const char *msg = L->ToString(-1);
				if (msg) Console.WriteLine(msg);
				L->Pop(1);
			}
			else
			{
				L->GetField(top + 1, "Tracks");
				int size = L->ObjLen(-1);
				for (int i = 0; i < size; i++)
				{
					L->PushInteger(i + 1);
					L->GetTable(-2);

					L->GetField(-1, "Node");
					Identifier name = L->ToString(-1);
					L->Pop(1);

					sharedc_ptr(JointData) joint_data; 
					int index = joint_index.Get(name, -1);

					if (joint_array.IsValidIndex(index))
					{
						joint_data = joint_array[index];
					}
					else
					{
						joint_data = ptr_new JointData;
						joint_data->name = name;
						joint_index.Add(name, joint_array.Size());
						joint_array.PushBack(joint_data);
					}

					if (joint_data)
					{
						L->GetField(-1, "Property");
						Identifier property_name = L->ToString(-1);
						L->Pop(1);

						L->GetField(-1, "FrameCount");
						joint_data->frame_count = L->ToNumber(-1);
						int data_size = joint_data->frame_count * 7;
						if ((int)joint_data->data.Size() < data_size)
							joint_data->data.Resize(data_size);
						L->Pop(1);

						if (frame_count < 0)
							frame_count = joint_data->frame_count;

						static Core::Identifier translate("translate");
						static Core::Identifier rotateQuaternion("rotateQuaternion");

						Array<float> data_array;

						L->GetField(-1, "FrameData");
						lua_LoadArray(L, -1, data_array);
						L->Pop(1);

						if (property_name == translate)
						{
							if ((data_array.Size() / 3) <= (joint_data->data.Size() / 7))
							{
								for (uint i = 0; i < data_array.Size(); i++)
								{
									data_array[i] /= 100.f;
									int index = i / 3;
									index = index * 7 + i % 3;
									joint_data->data[index] = data_array[i];
								}
							}
						}
						else if (property_name == rotateQuaternion)
						{
							if ((data_array.Size() / 4) <= (joint_data->data.Size() / 7))
							{
								for (uint i = 0; i < data_array.Size(); i++)
								{
									int index = i / 4;
									index = index * 7 + i % 4 + 3;
									joint_data->data[index] = data_array[i];
								}
							}
						}
					}

					L->Pop(1);
				}

				success = true;
			}
		}
		else
		{
			const char *msg = L->ToString(-1);
			if (msg) Console.WriteLine(msg);
			L->Pop(1);
		}
		L->SetTop(top);
		L->Close();

		return success;
	}

	uint AnimationTrack::GetJointCount()
	{
		return joint_array.Size();
	}

	int AnimationTrack::GetJointId(const Core::Identifier & key)
	{
		return joint_index.Get(key, -1);
	}

	int AnimationTrack::GetFrameCount()
	{
		return frame_count;
	}

	float AnimationTrack::GetFrameRate()
	{
		return 96.f;
	}

	float AnimationTrack::GetAnimationTime()
	{
		int frame_count = GetFrameCount();

		if (frame_count > 0)
			return (frame_count - 1) / GetFrameRate();

		return -1.f;
	}

	/// get transform
	bool AnimationTrack::GetTransform(int joint_id, float time, Transform & transform)
	{
		int frame_count = GetFrameCount();
		float frame_rate = GetFrameRate();

		int frame = time * frame_rate;
		float lerp = time * frame_rate - frame;

		if (!joint_array.IsValidIndex(joint_id))
			return false;

		tempc_ptr(JointData) joint_data = joint_array[joint_id];

		PDE_ASSERT(joint_data, "joint data error!");
		PDE_ASSERT(joint_data->data.Size() / frame_count == 7, "data size error!");
		PDE_ASSERT(joint_data->data.Size() > (uint)(frame * 3 + 6), "data size error!");

		const float* p = joint_data->data.GetData();
		p += frame * 7;
		transform.position.x = *p++;
		transform.position.y = *p++;
		transform.position.z = *p++;
		transform.rotation.x = *p++;
		transform.rotation.y = *p++;
		transform.rotation.z = *p++;
		transform.rotation.w = *p++;

		if (lerp > EPSILON && (frame < frame_count - 1))
		{
			PDE_ASSERT(joint_data->data.Size() > (uint)((frame + 1) * 7 + 2), "data size error!");
			Transform next_frame_transform;

			next_frame_transform.position.x = *p++;
			next_frame_transform.position.y = *p++;
			next_frame_transform.position.z = *p;
			next_frame_transform.rotation.x = *p++;
			next_frame_transform.rotation.y = *p++;
			next_frame_transform.rotation.z = *p++;
			next_frame_transform.rotation.w = *p;

			Core::Lerp(transform.position, transform.position, next_frame_transform.position, lerp);
			Core::Lerp(transform.rotation, transform.rotation, next_frame_transform.rotation, lerp);
		}

		return true;
	}

	/// get transform
	bool AnimationTrack::GetTransform(const Core::Identifier & key, float time, Transform & transform)
	{
		int joint_id = joint_index.Get(key, -1);

		if (!joint_array.IsValidIndex(joint_id))
			return false;

		return GetTransform(joint_id, time, transform);
	}

	bool AnimationTrack::GetPosition(const Identifier & key, uint frame, Vector3 & pos)
	{
		int joint_id = joint_index.Get(key, -1);

		if (!joint_array.IsValidIndex(joint_id))
			return false;

		return GetPosition(joint_id, frame, pos);
	}

	bool AnimationTrack::GetPosition(int joint_id, uint frame, Vector3 & pos)
	{
		if (joint_array.IsValidIndex(joint_id))
		{
			tempc_ptr(JointData) joint_data = joint_array[joint_id];
			PDE_ASSERT(joint_data, "joint data error!");

			if ((int)frame < frame_count)
			{
				const Array<float> & data_array = joint_data->data;

				uint size = data_array.Size() / frame_count;
				if (size == 7)
				{
					pos.x = data_array[frame * size + 0];
					pos.y = data_array[frame * size + 1];
					pos.z = data_array[frame * size + 2];
					return true;
				}
			}
		}
		return false;
	}

	bool AnimationTrack::GetRotation(const Identifier & key, uint frame, Quaternion & rot)
	{
		int joint_id = joint_index.Get(key, -1);

		if (!joint_array.IsValidIndex(joint_id))
			return false;

		return GetRotation(joint_id, frame, rot);
	}

	bool AnimationTrack::GetRotation(int joint_id, uint frame, Quaternion & rot)
	{
		if (joint_array.IsValidIndex(joint_id))
		{
			tempc_ptr(JointData) joint_data = joint_array[joint_id];
			PDE_ASSERT(joint_data, "joint data error!");

			if ((int)frame < frame_count)
			{
				const Array<float> & data_array = joint_data->data;

				uint size = data_array.Size() / frame_count;

				if (size == 7)
				{
					rot.x = data_array[frame * size + 3];
					rot.y = data_array[frame * size + 4];
					rot.z = data_array[frame * size + 5];
					rot.w = data_array[frame * size + 6];
					return true;
				}
			}
		}
		return false;
	}

	/// has joint
	bool AnimationTrack::HasJoint(const Core::Identifier & key)
	{
		return joint_index.Get(key, -1) != -1;
	}
}

namespace Client
{
	/// constructor
	AnimationNodePose::AnimationNodePose(by_ptr(Skeleton) s)
		: play_time(0.f)
		, total_time(0.f)
		, start_time(0.f)
		, end_time(0.f)
		, play_rate(1.f)
		, pause(false)
		, circle(true)
		, skeleton(s)
		, addtive_pose_dirty(true)
		, pose_dirty(true)
	{
	}

	/// update
	void AnimationNodePose::Update(F32 time)
	{
		if (animation_set)
		{
			tempc_ptr(Animation) anim = animation_set->GetAnimation(animation_key);
			//LogSystem.WriteLinef("%s",animation_key);
			if (animation != anim)
			{
				animation = anim;
				pose = ptr_new Pose(skeleton);
				addtive_pose = ptr_new Pose(skeleton);
				addtive_pose->SetLocalPoseZero();

				animation->BuildJointMap(skeleton, joint_map);
				addtive_base = ptr_new Pose(skeleton);
				animation->SampleTrack(0, joint_map, addtive_base->GetLocalPose());
			}

			tempc_ptr(Animation) addtive_base_animation = animation_set->GetAnimation(addtive_base_key);
			if (!addtive_base_animation)
				addtive_base_animation = anim;

			if (addtive_base_animation != animation_addtive)
			{
				animation_addtive = addtive_base_animation;
				addtive_pose = ptr_new Pose(skeleton);
				addtive_pose->SetLocalPoseZero();

				animation_addtive->BuildJointMap(skeleton, joint_map_addtive);
				addtive_base = ptr_new Pose(skeleton);
				animation_addtive->SampleTrack(0, joint_map_addtive, addtive_base->GetLocalPose());
			}
		}

		if (animation)
		{
			total_time = animation->GetAnimationTime();

			if (total_time > 0)
			{
				float end_pos = total_time;
				float start_pos = 0;

				if (start_time > 0 && start_time < total_time)
					start_pos = start_time;

				if (end_time > start_pos && end_time < total_time)
					end_pos = end_time;

				total_time = end_pos - start_pos;

				if (!pause)
					play_time += time * play_rate;
			}
		}

		pose_dirty = true;
		addtive_pose_dirty = true;
	}

	/// update pose offset
	void AnimationNodePose::UpdatePoseOffset()
	{
		HashSet<uint, Transform>::Enumerator it(pose_offset);
		while (it.MoveNext())
		{
			uint joint_id = it.Key();
			if (joint_id < pose->GetJointCount())
			{
				const Transform & transform = pose->GetJointLocalPose(it.Key());
				const Transform & offset = it.Value();
				Transform result;
				result.position = transform.position + offset.position;
				result.rotation = transform.rotation * offset.rotation;
				result.rotation.Normalize();
				pose->SetJointLocalPose(joint_id, result);
			}
		}
	}

	/// get addtive pose
	tempc_ptr(Pose) AnimationNodePose::GetAddtivePose()
	{
		if (addtive_pose_dirty)
		{			
			if (pose && addtive_pose)
			{
				addtive_pose->Blend(addtive_base, NullPtr, 0);
				Array<Transform> & source_transform = addtive_pose->GetLocalPose();
				const Array<Transform> & target_transform = pose->GetLocalPose();
				PDE_ASSERT(source_transform.Size() == target_transform.Size(), "array size error!");
				for (uint i = 0; i < source_transform.Size(); ++i)
				{
					source_transform[i].position = target_transform[i].position - source_transform[i].position;
					source_transform[i].rotation.Inverse();
					source_transform[i].rotation = target_transform[i].rotation * source_transform[i].rotation;
				}
			}

			addtive_pose_dirty = false;
		}

		return addtive_pose;
	}

	/// get Pose
	tempc_ptr(Pose) AnimationNodePose::GetPose()
	{
		if (pose_dirty && pose && animation)
		{
			total_time = animation->GetAnimationTime();

			if (total_time > 0)
			{
				float start_pos = 0;

				if (start_time > 0 && start_time < total_time)
					start_pos = start_time;

				if (total_time > 0)
				{
					float animation_time = play_time;
					if (animation_time > total_time || animation_time < -total_time)
					{
						if (circle)
							animation_time = Fmod(animation_time, total_time);
						else
							animation_time = (animation_time > 0)? total_time: -total_time;
					}

					if (animation_time < 0)
						animation_time = total_time + animation_time;

					// sample track
					animation->SampleTrack(start_pos + animation_time, joint_map, pose->GetLocalPose());
					UpdatePoseOffset();
				}
			}
			else if (total_time == 0)
			{	
				animation->SampleTrack(0, joint_map, pose->GetLocalPose());
				UpdatePoseOffset();
			}

			pose_dirty = false;
		}

		return pose;
	}

	/// on active
	void AnimationNodePose::OnActive()
	{
		play_time = 0.f;
		play_rate = 1.f;
		pause = false;
	}

	/// on valid
	void AnimationNodePose::OnValid(bool valid)
	{
	}

	/// set animation
	void AnimationNodePose::SetAnimation(const Identifier & key, by_ptr(AnimationSet) set)
	{
		animation_key = key;
		animation_set = set;
		SetTime(play_time);
	}

	/// set addtive base
	void AnimationNodePose::SetAddtiveBase(const Identifier & key)
	{
		addtive_base_key = key;
	}

	float AnimationNodePose::GetTotalTime()
	{
		return total_time;
	}

	void AnimationNodePose::SetTime(float time)
	{
		play_time = time;
		Update(0);
	}

	/// get time
	float AnimationNodePose::GetTime()
	{
		return play_time;
	}

	/// get play rate
	float AnimationNodePose::GetPlayRate()
	{
		return play_rate;
	}

	/// set play rate
	void AnimationNodePose::SetPlayRate(float rate)
	{
		play_rate = rate;
	}

	/// get animation rate
	float AnimationNodePose::GetAnimationRate()
	{
		return 0.f;
	}

	/// set animation rate
	void AnimationNodePose::SetAnimationRate(float rate)
	{
		play_time = total_time * 0.f;
	}

	/// get animation key
	const Identifier & AnimationNodePose::GetAnimationKey()
	{
		return animation_key;
	}


	/// set pose offset
	void AnimationNodePose::SetPoseOffset(uint joint_id, const Transform & transform)
	{
		pose_offset.Set(joint_id, transform);
	}

	void AnimationNodePose::SetCircle(bool is_circle)
	{
		circle = is_circle;
	}
}

namespace Client
{
	/// add node
	bool AnimationNodeList::AddNode(const Identifier & key, by_ptr(AnimationNode) node)
	{
		return node_list.Add(key, node);
	}

	/// set active node
	void AnimationNodeList::SetActiveNode(const Identifier & key)
	{
		tempc_ptr(AnimationNode) node = node_list.Get(key, NullPtr);

		if (active_node != node)
		{
			active_node = node;
			active_key = key;

			if (active_node)
				active_node->OnActive();
		}
	}

	/// update
	void AnimationNodeList::Update(F32 time)
	{
		if (active_node)
			active_node->Update(time);
	}

	/// get addtive pose
	tempc_ptr(Pose) AnimationNodeList::GetAddtivePose()
	{
		if (active_node)
			return active_node->GetAddtivePose();

		return NullPtr;
	}

	/// get pose
	tempc_ptr(Pose) AnimationNodeList::GetPose()
	{
		if (active_node)
			return active_node->GetPose();

		return NullPtr;
	}

	/// on active
	void AnimationNodeList::OnActive()
	{
		if (active_node)
			active_node->OnActive();
	}

	/// on valid
	void AnimationNodeList::OnValid(bool valid)
	{
		if (active_node)
			active_node->OnValid(valid);
	}
}

namespace Client
{
	/// constructor
	AnimationNodeRandom::AnimationNodeRandom()
		: active_index(-1)
		, replay_count(0)
		, active_node_begin(false)
	{
	}

	/// add node
	bool AnimationNodeRandom::AddNode(by_ptr(AnimationNodePose) node, byte weight, short replay_count)
	{
		if (node)
		{
			node_list.PushBack(node);
			int result = weight | (replay_count << 8);
			weight_list.PushBack(result);
			return true;
		}

		return false;
	}

	static float RandomAnimation(float a, float b)		
	{
		const float r = (float)::rand() / ((float)RAND_MAX + 1);
		return r * (b - a) + a;
	}

	/// update
	void AnimationNodeRandom::Update(F32 time)
	{
		active_node_begin = false;
		
		if (active_node)
		{
			if (active_node->GetTotalTime() > 0)
			{
				float play_time = Abs(active_node->GetTime() + time * active_node->GetPlayRate());
				if (play_time < active_node->GetTotalTime())
					active_node->Update(time);
				else
				{
					active_node->SetTime(0);
					replay_count--;
					if (replay_count > 0)
						active_node_begin = true;
				}
			}
			else
			{
				active_node->Update(0);
				replay_count--;
				if (replay_count > 0)
					active_node_begin = true;
			}

			if (replay_count <= 0)
			{
				active_node = NullPtr;
				replay_count = 0;
			}
		}

		if (!active_node)
		{
			int total_weight = 0;
			int base_weight = 0;
			uint node_count = node_list.Size();

			if (node_count > 0)
			{
				for (uint i = 0; i < weight_list.Size(); ++i)
					total_weight += weight_list[i] & 0xff;

				if (total_weight > 0)
				{
					int random = RandomAnimation(0, 1.f) * total_weight;

					for (uint i = 0; i < weight_list.Size(); ++i)
					{
						base_weight += weight_list[i] & 0xff;
						if ((random <= base_weight) && (i < node_count))
						{
							active_index = i;
							active_node = node_list[i];
							replay_count = weight_list[i] >> 8;
							break;
						}
					}
				}
				else
				{
					active_index = Fmod(active_index + 1, node_count);
					active_node = node_list[active_index];
					replay_count = weight_list[active_index] >> 8;
				}

				if (active_node)
				{
					active_node->OnActive();
					active_node->Update(0);
					active_node_begin = true;
				}
			}
		}
	}

	/// get addtive pose
	tempc_ptr(Pose) AnimationNodeRandom::GetAddtivePose()
	{
		if (active_node)
			return active_node->GetAddtivePose();

		return NullPtr;
	}

	/// get pose
	tempc_ptr(Pose) AnimationNodeRandom::GetPose()
	{
		if (active_node)
			return active_node->GetPose();

		return NullPtr;
	}

	/// on active
	void AnimationNodeRandom::OnActive()
	{
		active_index = -1;
		active_node = NullPtr;
		replay_count = 0;
		active_node_begin = false;
	}

	/// on valid
	void AnimationNodeRandom::OnValid(bool valid)
	{
	}

	/// active node begin
	bool AnimationNodeRandom::ActiveNodeBegin()
	{
		return active_node_begin;
	}

}

namespace Client
{
	/// constructor
	AnimationNodeBlend::AnimationNodeBlend(by_ptr(Skeleton) s)
		: pose_dirty(true)
	{
		pose = ptr_new Pose(s);
		skeleton = s;
	}

	/// update
	void AnimationNodeBlend::Update(float time)
	{
		for (uint i = 0; i < nodes.Size(); ++i)
		{
			tempc_ptr(BlendInfo) info = nodes[i];

			if (info && info->node)
				info->node->Update(time);
		}

		pose_dirty = true;
	}

	/// blend node
	void AnimationNodeBlend::BlendNode()
	{
		if (!skeleton)
			return;

		pose->CopyLocalPose(skeleton->GetLocalPose());

		for (uint i = 0; i < skeleton->GetJointCount(); ++i)
		{
			for (uint j = 0; j < nodes.Size(); ++j)
			{
				tempc_ptr(BlendInfo) info = nodes[j];

				if (!info || !info->node)
					continue;

				tempc_ptr(Pose) node_pose = info->node->GetPose();

				if (!node_pose)
					continue;

				Array<Transform> & p = pose->GetLocalPose();
				Array<Transform> & pose_source = node_pose->GetLocalPose();

				if (p.Size() > pose_source.Size())
					continue;

				byte blend = 0;

				if (info->map)
				{
					const Array<byte> & map = info->map->GetMap();
					blend = map[i];
				}

				if (blend == SkeletonMap::kReplace)
				{
					p[i] = pose_source[i];
				}	
			}

			for (uint j = 0; j < nodes.Size(); ++j)
			{
				tempc_ptr(BlendInfo) info = nodes[j];

				if (!info || !info->node)
					continue;

				byte blend = 0;
				if (info->map)
				{
					const Array<byte> & map = info->map->GetMap();
					blend = map[i];
				}

				if (blend == SkeletonMap::kAddtive)
				{
					tempc_ptr(Pose) addtive_pose = info->node->GetAddtivePose();

					if (!addtive_pose)
						continue;

					Array<Transform> & p = pose->GetLocalPose();
					Array<Transform> & addtive_p = addtive_pose->GetLocalPose();

					if (p.Size() > addtive_p.Size())
						continue;
					
					p[i].position += addtive_p[i].position;
					Multiply(p[i].rotation, addtive_p[i].rotation, p[i].rotation);
				}
			}
		}
	}

	/// get addtive pose
	tempc_ptr(Pose) AnimationNodeBlend::GetAddtivePose()
	{
		return NullPtr;
	}

	/// get pose
	tempc_ptr(Pose) AnimationNodeBlend::GetPose()
	{
		if (pose_dirty)
		{
			BlendNode();
			pose_dirty = false;
		}

		return pose;
	}

	/// add node
	void AnimationNodeBlend::AddNode(by_ptr(AnimationNode) node)
	{
		if (node)
		{
			sharedc_ptr(BlendInfo) info = ptr_new BlendInfo();
			nodes.PushBack(info);
			info->node = node;
		}
	}

	/// add nod by info
	void AnimationNodeBlend::AddNodeByInfo(by_ptr(BlendInfo) info)
	{
		if (info && info->node)
			nodes.PushBack(info);
	}

	/// on valid
	void AnimationNodeBlend::OnValid(bool valid)
	{
		for (uint i = 0; i < nodes.Size(); ++i)
		{
			tempc_ptr(BlendInfo) info = nodes[i];

			if (info && info->node)
				info->node->OnValid(valid);
		}
	}
}

namespace Client
{
	/// constructor
	AnimationNodeSync::AnimationNodeSync(by_ptr(Skeleton) s)
		: sync_time(0)
		, sync_total_time(0.00f)
	{
		pose = ptr_new Pose(s);
	}

	tempc_ptr(AnimationNodeBase) AnimationNodeSync::GetActiveNode()
	{
		return active_node;
	}

	/// add node
	bool AnimationNodeSync::AddNode(const Identifier & key, by_ptr(AnimationNodeBase) node)
	{
		return node_list.Add(key, node);
	}

	/// set active node
	void AnimationNodeSync::SetActiveNode(const Identifier & key, bool is_circle)
	{
		tempc_ptr(AnimationNodeBase) node = node_list.Get(key, NullPtr);

		if (active_node != node)
		{
			sync_node = active_node;
			active_node = node;
			sync_time = sync_total_time;

			if (active_node)
			{
				active_node->OnActive();
				active_node->SetCircle(is_circle);
				if (sync_node)
					active_node->SetAnimationRate(sync_node->GetAnimationRate());
			}
		}
	}

	/// update
	void AnimationNodeSync::Update(F32 time)
	{
		if (active_node)
			active_node->Update(time);

		if (sync_node)
		{
			if (sync_time > 0)
			{
				sync_time -= time;

				float total_time = sync_node->GetTotalTime();

				if (total_time > 0)
				{
					if (active_node)
						sync_node->SetAnimationRate(active_node->GetAnimationRate());
				}
				else
				{
					sync_time = 0;
					sync_node = NullPtr;
				}
			}
			else
			{
				sync_time = 0;
				sync_node = NullPtr;
			}
		}
	}

	/// get addtive pose
	tempc_ptr(Pose) AnimationNodeSync::GetAddtivePose()
	{
		if (active_node)
		{
			return active_node->GetAddtivePose();
		}

		return NullPtr;
	}

	/// get pose
	tempc_ptr(Pose) AnimationNodeSync::GetPose()
	{
		if (sync_time > 0 && sync_node)
		{
			pose->Blend(sync_node->GetPose(), active_node->GetPose(), (1 - sync_time/ sync_total_time));
			return pose;
		}
		else
		{
			if (active_node)
				return active_node->GetPose();
		}

		return NullPtr;
	}

	/// on active
	void AnimationNodeSync::OnActive()
	{
		sync_time = 0;

		if (active_node)
			active_node->OnActive();
	}

	/// on valid
	void AnimationNodeSync::OnValid(bool valid)
	{
		if (active_node)
			active_node->OnValid(valid);
	}
}


namespace Client
{
	/// constructor
	AnimationNodeData::AnimationNodeData(by_ptr(Skeleton) s)
		: blend_time(0.f)
		, blend_total_time(0.2f)
		, pose_dirty(true)
		, addtive_pose_dirty(true)
		, is_valid(true)
	{
		pose = ptr_new Pose(s);
		blend_pose = ptr_new Pose(s);
		addtive_pose = ptr_new Pose(s);
		addtive_pose->SetLocalPoseZero();
		addtive_blend_pose = ptr_new Pose(s);
		addtive_blend_pose->SetLocalPoseZero();
	}

	/// update
	void AnimationNodeData::Update(F32 time)
	{
		if (source_node)
		{
			source_node->Update(time);

			if (blend_time > 0)
				blend_time = blend_time - time;

			pose_dirty = true;
			addtive_pose_dirty = true;
		}
		else
		{
			source_pose = NullPtr;
			addtive_source_pose = NullPtr;
		}
	}

	/// get addtive pose
	tempc_ptr(Pose) AnimationNodeData::GetAddtivePose()
	{
		if (source_node && addtive_pose)
		{
			if (addtive_pose_dirty)
			{
				tempc_ptr(Pose) target_pose;

				if (source_node)
					target_pose = source_node->GetAddtivePose();

				if (addtive_source_pose != target_pose)
				{
					if (addtive_source_pose)
					{
						if (addtive_blend_pose)
							addtive_blend_pose->Blend(addtive_pose, NullPtr, 0);

						blend_time = blend_total_time;
					}

					addtive_source_pose = source_node->GetAddtivePose();
				}

				if (blend_time > 0)
				{
					float blend = 1.0 - (blend_time / blend_total_time);
					addtive_pose->Blend(addtive_blend_pose, addtive_source_pose, blend);
				}
				else
					addtive_pose->Blend(addtive_source_pose, NullPtr, 0);

				addtive_pose_dirty = false;
			}

			return addtive_pose;
		}
		else
		{
			addtive_source_pose = NullPtr;
		}

		return NullPtr;
	}

	/// get pose
	tempc_ptr(Pose) AnimationNodeData::GetPose()
	{
		if (source_node && pose)
		{
			if (pose_dirty)
			{
				tempc_ptr(Pose) target_pose;

				if (source_node)
					target_pose = source_node->GetPose();

				if (source_pose != target_pose)
				{
					if (source_pose)
					{
						if (blend_pose)
							blend_pose->Blend(pose, NullPtr, 0);

						blend_time = blend_total_time;
						if (blend_time > EPSILON)
							blend_time -= EPSILON;	// not use blend pose at all
					}

					source_pose = target_pose;
				}

				if (blend_time > 0)
				{
					float blend = 1.0 - (blend_time / blend_total_time);
					pose->Blend(blend_pose, source_pose, blend);
				}
				else
					pose->Blend(source_pose, NullPtr, 0);

				pose_dirty = false;
			}

			return pose;
		}
		else
		{
			source_pose = NullPtr;
		}

		return NullPtr;
	}

	///set source node
	void AnimationNodeData::SetSourceNode(by_ptr(AnimationNode) node)
	{
		if (source_node != node)
		{
			source_node = node;

			if (source_node)
				source_node->OnActive();
		}
	}

	/// on active
	void AnimationNodeData::OnActive()
	{
		if (source_node)
			source_node->OnActive();
	}

	/// on valid
	void AnimationNodeData::OnValid(bool valid)
	{
		if (valid != is_valid)
		{
			is_valid = valid;

			if (valid)
			{
				if (source_node)
					source_pose = source_node->GetPose();

				if (source_node)
					addtive_source_pose = source_node->GetAddtivePose();
			}
		}

		if (source_node)
			source_node->OnValid(valid);
	}

	/// is blending
	bool AnimationNodeData::IsBlending()
	{
		return blend_time > 0;
	}

	// force blend
	void AnimationNodeData::ForceBlend()
	{
		if (blend_pose)
			blend_pose->Blend(pose, NullPtr, 0);

		if (addtive_blend_pose)
			addtive_blend_pose->Blend(addtive_pose, NullPtr, 0);

		blend_time = blend_total_time;
	}

}

namespace Client
{
	AnimationNodeOffset::AnimationNodeOffset(by_ptr(Skeleton) s)
		: direction(Vector2::kZero)
		, angle_speed(PI)
		, angle_h(0)
		, angle_v(0)
		, angle_target_h(0)
		, angle_target_v(0)
		, angle_h_left_max(45 * DEG2RAD)
		, angle_h_right_max(45 * DEG2RAD)
		, angle_v_up_max(70 * DEG2RAD)
		, angle_v_down_max(70 * DEG2RAD)
		, has_pose_center_up_half(false)
		, has_pose_center_down_half(false)

		, pose_dirty(true)
		, addtive_pose_dirty(true)

	{
		skeleton = s;
		pose_v = ptr_new Pose(s);
		pose_h = ptr_new Pose(s);

		pose_center = ptr_new Pose(s);
		pose_center_up_half = ptr_new Pose(s);
		pose_center_up = ptr_new Pose(s);
		pose_center_down_half = ptr_new Pose(s);
		pose_center_down = ptr_new Pose(s);
		pose_left = ptr_new Pose(s);
		pose_left_up = ptr_new Pose(s);
		pose_left_down = ptr_new Pose(s);
		pose_right = ptr_new Pose(s);
		pose_right_up = ptr_new Pose(s);
		pose_right_down = ptr_new Pose(s);
	}

	static float AngleClamp(float angle)
	{
		if (angle > PI)
			angle -= PI * 2.f;
		else if (angle < -PI)
			angle += PI * 2.f;
		return angle;
	}

	/// update
	void AnimationNodeOffset::Update(float frame_time)
	{
		if (!skeleton)
			return;

		if (!animation_set)
			return;

		PDE_ASSERT(angle_v_up_max > 0, "angle v error");
		PDE_ASSERT(angle_v_down_max > 0, "angle v error");
		PDE_ASSERT(angle_h_left_max > 0, "angle h error");
		PDE_ASSERT(angle_h_right_max > 0, "angle h error");

		angle_target_v = Clamp(angle_target_v, PI * 0.5f - angle_v_up_max, PI * 0.5f + angle_v_down_max);
		angle_target_h = Clamp(angle_target_h, - angle_h_left_max, angle_h_right_max);

		float delta_v = angle_target_v - angle_v;
		float delta_h = angle_target_h - angle_h;

		delta_v = AngleClamp(delta_v);
		delta_h = AngleClamp(delta_h);

		float delta_max = frame_time * angle_speed * 2;
		delta_v = Clamp(delta_v, -delta_max, delta_max);
		delta_h = Clamp(delta_h, -delta_max, delta_max);
		angle_v += delta_v;
		angle_h += delta_h;
		angle_v = AngleClamp(angle_v);
		angle_h = AngleClamp(angle_h);

		float v = PI * 0.5f - angle_v;
		direction.y = v > 0? (v / angle_v_up_max): (v / angle_v_down_max);
		direction.y = Clamp(direction.y, -1, 1);

		direction.x = angle_h > 0? (angle_h / angle_h_right_max): (angle_h / angle_h_left_max);
		direction.x = Clamp(direction.x, -1, 1);

		tempc_ptr(Animation) animation_now = animation_set->GetAnimation(animation_key);

		if (animation_now)
		{
			if (animation_now->IsReady() && animation != animation_now)
			{
				animation = animation_now;

				Core::Array<int> joint_map;
				animation->BuildJointMap(skeleton, joint_map);

				/// get animation time
				animation->SampleTrack(0, joint_map, pose_center->GetLocalPose());

				has_pose_center_up_half = animation->SampleTrack(9.f / 24.f, joint_map, pose_center_up_half->GetLocalPose());
				animation->SampleTrack(2.f / 24.f, joint_map, pose_center_up->GetLocalPose());
				has_pose_center_down_half = animation->SampleTrack(10.f / 24.f, joint_map, pose_center_down_half->GetLocalPose());
				animation->SampleTrack(7.f / 24.f, joint_map, pose_center_down->GetLocalPose());
				animation->SampleTrack(5.f / 24.f, joint_map, pose_left->GetLocalPose());
				animation->SampleTrack(3.f / 24.f, joint_map, pose_left_up->GetLocalPose());
				animation->SampleTrack(8.f / 24.f, joint_map, pose_left_down->GetLocalPose());
				animation->SampleTrack(4.f / 24.f, joint_map, pose_right->GetLocalPose());
				animation->SampleTrack(1.f / 24.f, joint_map, pose_right_up->GetLocalPose());
				animation->SampleTrack(6.f / 24.f, joint_map, pose_right_down->GetLocalPose());

				pose = ptr_new Pose(skeleton);
				addtive_pose = ptr_new Pose(skeleton);
				addtive_pose->SetLocalPoseZero();
			}
		}

		pose_dirty = true;
		addtive_pose_dirty = true;
	}

	/// get addtive pose
	tempc_ptr(Pose) AnimationNodeOffset::GetAddtivePose()
	{
		if (addtive_pose_dirty)
		{			
			tempc_ptr(Pose) current_pose = GetPose();
			if (current_pose && addtive_pose)
			{
				Array<Transform> & source_transform = pose_center->GetLocalPose();
				Array<Transform> & addtive_transform = addtive_pose->GetLocalPose();
				const Array<Transform> & target_transform = current_pose->GetLocalPose();
				PDE_ASSERT(source_transform.Size() == target_transform.Size() && source_transform.Size() == addtive_transform.Size(), "array size error!");

				Quaternion rot;
				for (uint i = 0; i < addtive_transform.Size(); ++i)
				{
					addtive_transform[i].position = target_transform[i].position - source_transform[i].position;
					rot = source_transform[i].rotation;
					rot.Inverse();
					addtive_transform[i].rotation = target_transform[i].rotation * rot;
				}
			}

			addtive_pose_dirty = false;
		}

		return addtive_pose;
	}

	/// get pose
	tempc_ptr(Pose) AnimationNodeOffset::GetPose()
	{
		if (pose_dirty && pose)
		{
			if (direction.y >= 0)
			{
				if (has_pose_center_up_half)
				{
					if (direction.y > 0.5f)
						pose_v->Blend(pose_center_up_half, pose_center_up, Abs((direction.y - 0.5f) / 0.5f));
					else
						pose_v->Blend(pose_center, pose_center_up_half, Abs(direction.y / 0.5f));
				}
				else
					pose_v->Blend(pose_center, pose_center_up, Abs(direction.y));
			}
			else if (direction.y < 0)
			{
				if (has_pose_center_down_half)
				{
					if (direction.y < -0.5f)
						pose_v->Blend(pose_center_down_half, pose_center_down, Abs((direction.y + 0.5f) / 0.5f));
					else
						pose_v->Blend(pose_center, pose_center_down_half, Abs(direction.y / 0.5f));
				}
				else
					pose_v->Blend(pose_center, pose_center_down, Abs(direction.y));
			}

			if (direction.x >= 0)
			{
				if (direction.y >= 0)
					pose_h->Blend(pose_right, pose_right_up, Abs(direction.y));
				else if (direction.y < 0)
					pose_h->Blend(pose_right, pose_right_down, Abs(direction.y));
			}
			else
			{
				if (direction.y >= 0)
					pose_h->Blend(pose_left, pose_left_up, Abs(direction.y));
				else if (direction.y < 0)
					pose_h->Blend(pose_left, pose_left_down, Abs(direction.y));
			}

			pose->Blend(pose_v, pose_h, Abs(direction.x));

			pose_dirty = false;
		}

		return pose;
	}

	/// on active
	void AnimationNodeOffset::OnActive()
	{
	}

	/// on valid
	void AnimationNodeOffset::OnValid(bool valid)
	{
	}

	/// set animation
	void AnimationNodeOffset::SetAnimation(const Core::Identifier & key, by_ptr(AnimationSet) set)
	{
		animation_key = key;
		animation_set = set;
	}
}

namespace Client
{
	AnimationNodeDirection::AnimationNodeDirection(by_ptr(Skeleton) s)
		: angle_speed(PI)
		, angle(0)
		, angle_target(0)
		, play_rate(1.f)
		, play_time(0)

		, pose_dirty(true)
		, addtive_pose_dirty(true)
	{
		skeleton = s;
		pose_1 = ptr_new Pose(s);
		pose_2 = ptr_new Pose(s);
		pose = pose_1;
	}

	/// update
	void AnimationNodeDirection::Update(float frame_time)
	{
		play_time += play_rate * frame_time;

		float delta = angle_target - angle;
		delta = AngleClamp(delta);

		if (Abs(delta) > PI * 0.5f)
		{
			float rate = GetAnimationRate();
			angle = angle_target;
			pose = (pose == pose_1)? pose_2: pose_1;

			SetAnimationRate(rate);
		}
		else
		{
			float delta_max = frame_time * angle_speed * 2;
			delta = Clamp(delta, -delta_max, delta_max);
			angle += delta;
			angle = AngleClamp(angle);
		}

		pose_dirty = true;
		addtive_pose_dirty = true;
	}

	/// get addtive pose
	tempc_ptr(Pose) AnimationNodeDirection::GetAddtivePose()
	{
		if (!animation_forward)
			return NullPtr;
		
		if (!animation_back)
			return NullPtr;
		
		if (!animation_left)
			return NullPtr;
		
		if (!animation_right)
			return NullPtr;

		if (!addtive_pose)
		{
			addtive_pose = ptr_new Pose(skeleton);
			addtive_pose->SetLocalPoseZero();
		}

		if (addtive_pose_dirty && addtive_pose)
		{			
			if(angle < -PI * 0.5f) // Back and left
			{
				if (animation_back_left)
				{
					if (angle < - 0.75f * PI)
						addtive_pose->Blend(animation_back->GetAddtivePose(), animation_back_left->GetAddtivePose(), angle / (0.25f * PI) + 4);
					else
						addtive_pose->Blend(animation_back_left->GetAddtivePose(), animation_left->GetAddtivePose(), angle / (0.25f * PI) + 3);
				}
				else
					addtive_pose->Blend(animation_back->GetAddtivePose(), animation_left->GetAddtivePose(), angle / (0.5f * PI) + 2.f);
			}
			else if(angle < 0.f) // Forward and left
			{
				if (animation_forward_left)
				{
					if (angle > - 0.25f * PI)
						addtive_pose->Blend(animation_forward->GetAddtivePose(), animation_forward_left->GetAddtivePose(), -angle / (0.25f * PI));
					else
						addtive_pose->Blend(animation_forward_left->GetAddtivePose(), animation_left->GetAddtivePose(),  -angle / (0.25f * PI) - 1);
				}
				else
					addtive_pose->Blend(animation_forward->GetAddtivePose(), animation_left->GetAddtivePose(), -angle / (0.5f * PI));
			}
			else if(angle < 0.5f * PI) // Forward and right
			{
				if (animation_forward_right)
				{
					if (angle < 0.25f * PI)
						addtive_pose->Blend(animation_forward->GetAddtivePose(), animation_forward_right->GetAddtivePose(), angle / (0.25f * PI));
					else
						addtive_pose->Blend(animation_forward_right->GetAddtivePose(), animation_right->GetAddtivePose(), angle / (0.25f * PI) - 1);
				}
				else
					addtive_pose->Blend(animation_forward->GetAddtivePose(), animation_right->GetAddtivePose(), angle / (0.5f * PI));
			}
			else // Back and right
			{
				if (animation_back_right)
				{
					if (angle > 0.75f * PI)
						addtive_pose->Blend(animation_back->GetAddtivePose(), animation_back_right->GetAddtivePose(), -angle / (0.25f * PI) + 4);
					else
						addtive_pose->Blend(animation_back_right->GetAddtivePose(), animation_right->GetAddtivePose(), -angle / (0.25f * PI) + 3);
				}
				else
					addtive_pose->Blend(animation_back->GetAddtivePose(), animation_right->GetAddtivePose(), (-angle / (0.5f * PI)) + 2.f);
			}

			addtive_pose_dirty = false;
		}

		return addtive_pose;
	}

	/// get pose
	tempc_ptr(Pose) AnimationNodeDirection::GetPose()
	{
		if (!animation_forward)
			return NullPtr;

		if (!animation_back)
			return NullPtr;

		if (!animation_left)
			return NullPtr;

		if (!animation_right)
			return NullPtr;

		if (pose_dirty && pose)
		{
			if(angle < -PI * 0.5f) // Back and left
			{
				if (animation_back_left)
				{
					animation_back_left->SetTime(play_time);
					if (angle < - 0.75f * PI)
					{
						animation_back->SetTime(play_time);
						pose->Blend(animation_back->GetPose(), animation_back_left->GetPose(), angle / (0.25f * PI) + 4);
					}
					else
					{
						animation_left->SetTime(play_time);
						pose->Blend(animation_back_left->GetPose(), animation_left->GetPose(), angle / (0.25f * PI) + 3);
					}
				}
				else
				{
					animation_back->SetTime(play_time);
					animation_left->SetTime(play_time);
					pose->Blend(animation_back->GetPose(), animation_left->GetPose(), angle / (0.5f * PI) + 2.f);
				}
			}
			else if(angle < 0.f) // Forward and left
			{
				if (animation_forward_left)
				{
					animation_forward_left->SetTime(play_time);
					if (angle > - 0.25f * PI)
					{
						animation_forward->SetTime(play_time);
						pose->Blend(animation_forward->GetPose(), animation_forward_left->GetPose(), -angle / (0.25f * PI));
					}
					else
					{
						animation_left->SetTime(play_time);
						pose->Blend(animation_forward_left->GetPose(), animation_left->GetPose(),  -angle / (0.25f * PI) - 1);
					}
				}
				else
				{
					animation_forward->SetTime(play_time);
					animation_left->SetTime(play_time);
					pose->Blend(animation_forward->GetPose(), animation_left->GetPose(), -angle / (0.5f * PI));
				}
			}
			else if(angle < 0.5f * PI) // Forward and right
			{
				if (animation_forward_right)
				{
					animation_forward_right->SetTime(play_time);
					if (angle < 0.25f * PI)
					{
						animation_forward->SetTime(play_time);
						pose->Blend(animation_forward->GetPose(), animation_forward_right->GetPose(), angle / (0.25f * PI));
					}
					else
					{
						animation_right->SetTime(play_time);
						pose->Blend(animation_forward_right->GetPose(), animation_right->GetPose(), angle / (0.25f * PI) - 1);
					}
				}
				else
				{
					animation_forward->SetTime(play_time);
					animation_right->SetTime(play_time);
					pose->Blend(animation_forward->GetPose(), animation_right->GetPose(), angle / (0.5f * PI));
				}
			}
			else // Back and right
			{
				if (animation_back_right)
				{
					animation_back_right->SetTime(play_time);
					if (angle > 0.75f * PI)
					{
						animation_back->SetTime(play_time);
						pose->Blend(animation_back->GetPose(), animation_back_right->GetPose(), -angle / (0.25f * PI) + 4);
					}
					else
					{
						animation_right->SetTime(play_time);
						pose->Blend(animation_back_right->GetPose(), animation_right->GetPose(), -angle / (0.25f * PI) + 3);
					}
				}
				else
				{
					animation_back->SetTime(play_time);
					animation_right->SetTime(play_time);
					pose->Blend(animation_back->GetPose(), animation_right->GetPose(), (-angle / (0.5f * PI)) + 2.f);
				}
			}

			pose_dirty = false;
		}

		return pose;
	}

	/// on active
	void AnimationNodeDirection::OnActive()
	{

		angle = 0;
		play_rate = 1.f;
		play_time = 0;
		if (animation_forward)
			animation_forward->OnActive();
		
		if (animation_forward_left)
			animation_forward_left->OnActive();
		
		if (animation_forward_right)
			animation_forward_right->OnActive();
		
		if (animation_back)
			animation_back->OnActive();
		
		if (animation_back_left)
			animation_back_left->OnActive();
		
		if (animation_back_right)
			animation_back_right->OnActive();
		
		if (animation_left)
			animation_left->OnActive();
		
		if (animation_right)
			animation_right->OnActive();
	}

	/// on valid
	void AnimationNodeDirection::OnValid(bool valid)
	{
	}

	/// get animation rate
	float AnimationNodeDirection::GetAnimationRate()
	{
		float rate = 0;
		if (animation_forward && animation_forward->GetTotalTime() > 0)
			rate = Fmod(play_time, animation_forward->GetTotalTime()) / animation_forward->GetTotalTime();

		if (angle < - 0.75f * PI || angle >= 0.25f * PI)
			rate = 1 - rate;

		return rate;
	}

	/// set animation rate
	void AnimationNodeDirection::SetAnimationRate(float rate)
	{
		if (!animation_forward)
			return;

		if (angle < - 0.75f * PI || angle >= 0.25f * PI)
			rate = 1 - rate;

		play_time = animation_forward->GetTotalTime() * rate;
	}

	/// set time
	void AnimationNodeDirection::SetTime(float time)
	{
		play_time = time;
		Update(0);
	}

	/// get time
	float AnimationNodeDirection::GetTime()
	{
		return play_time;
	}

	/// set play rate
	void AnimationNodeDirection::SetPlayRate(float rate)
	{
		play_rate = rate;
	}

	/// get play rate
	float AnimationNodeDirection::GetPlayRate()
	{
		return play_rate;
	}

	/// get total time
	float AnimationNodeDirection::GetTotalTime()
	{
		if (animation_forward)
			return animation_forward->GetTotalTime();

		return 0;
	}

	/// set angle
	void AnimationNodeDirection::SetAngle(float a)
	{
		float rate = GetAnimationRate();
		angle = a;
		SetAnimationRate(rate);
	}
}


namespace Client
{
	/// constructor
	AnimationNodeCustom::AnimationNodeCustom(by_ptr(Skeleton) s)
		: skeleton(s)
		, action_cycle(false)
		, action_playing(false)
		, blend_time_last(0.0f)
		, blend_out(false)
		, blend_in_time(0.f)
		, blend_out_time(0.f)
	{
		node_data = ptr_new AnimationNodeData(s);
	}

	/// update
	void AnimationNodeCustom::Update(F32 time)
	{
		if (node_data)
		{
			if (action_playing)
			{
				if (node_action)
				{
					float play_time_last = node_action->GetTime();
					float play_time = node_action->GetTime() + time * node_action->GetPlayRate();
					if (!action_cycle && (Abs(play_time) > node_action->GetTotalTime()
						|| (play_time_last > 0 && play_time <= 0)
						|| (play_time_last < 0 && play_time >= 0)))
					{
						if (action_wait_stop == false)
							StopAction();

						node_data->Update(0);
					}
					else
						node_data->Update(time);
				}
			}
			else
			{
				node_data->Update(time);

				if (blend_out && !node_data->IsBlending())
				{
					blend_out = false;
					node_data->blend_total_time = blend_time_last;
				}
			}
		}
	}

	/// get addtive pose
	tempc_ptr(Pose) AnimationNodeCustom::GetAddtivePose()
	{
		if (node_data)
			return node_data->GetAddtivePose();

		return NullPtr;
	}

	/// get pose
	tempc_ptr(Pose) AnimationNodeCustom::GetPose()
	{
		if (node_data)
			return node_data->GetPose();

		return NullPtr;
	}

	/// on active
	void AnimationNodeCustom::OnActive()
	{
		if (node_data)
			node_data->OnActive();
	}

	/// on valid
	void AnimationNodeCustom::OnValid(bool valid)
	{
		if (node_data)
			node_data->OnValid(valid);
	}

	/// set animation set
	void AnimationNodeCustom::SetAnimationSet(by_ptr(AnimationSet) set)
	{
		animation_set = set;
	}

	/// set animation node
	void AnimationNodeCustom::SetAnimationNode(by_ptr(AnimationNode) n)
	{
		node = n;

		if (!action_playing && node_data)
			node_data->SetSourceNode(node);
	}

	/// get animation node
	tempc_ptr(AnimationNode) AnimationNodeCustom::GetAnimationNode()
	{
		return node;
	}

	/// play action
	tempc_ptr(AnimationNodePose) AnimationNodeCustom::PlayAction(const Core::Identifier & key, float blend_time, bool cycle, float play_time, bool wait_stop)
	{
		return PlayAction(key, blend_time, blend_time, cycle, play_time, wait_stop);
	}

	/// play action
	tempc_ptr(AnimationNodePose) AnimationNodeCustom::PlayAction(const Identifier & key, float in_time, float out_time, bool cycle, float play_time, bool wait_stop)
	{
		if (action_playing)
			StopAction();

		if (node_action)
			node_action_last = node_action;

		node_action = ptr_new AnimationNodePose(skeleton);
		node_action->SetAnimation(key, animation_set);
		action_cycle = cycle;
		action_playing = true;
		action_wait_stop = wait_stop;
		blend_in_time = in_time;
		blend_out_time = out_time;

		if (node_data)
		{
			node_data->SetSourceNode(node_action);

			if (play_time > 0 && node_action->GetTotalTime() > 0)
				node_action->SetPlayRate(node_action->GetTotalTime() / play_time);

			if (blend_out)
				blend_out = false;
			else
				blend_time_last = node_data->blend_total_time;

			node_data->blend_total_time = blend_in_time;
		}

		return node_action;
	}

	/// pause action
	void AnimationNodeCustom::PauseAction(bool pause)
	{
		if (action_playing && node_action)
			node_action->pause = pause;
	}

	/// stop action
	void AnimationNodeCustom::StopAction(bool immediate)
	{
		if (action_playing)
		{
			if (immediate)
			{
				if (node_data)
				{
					node_data->SetSourceNode(node);
					node_data->blend_total_time = blend_out_time;
				}

				action_playing = false;
				blend_out = true;
			}

			action_wait_stop = false;
			action_cycle = false;
		}
	}

	/// is action playing
	bool AnimationNodeCustom::IsActionPlaying()
	{
		return action_playing;
	}

	/// force blend
	void AnimationNodeCustom::ForceBlend()
	{
		if (node_data)
			node_data->ForceBlend();
	}
}


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
namespace Client
{
	/// constructor
	AnimationNodeGroup::AnimationNodeGroup(by_ptr(Skeleton) s)
		: skeleton(s)
		, time(0.f)
		, showend(false)
		, groupnodeindex(-1)
		, isfirstperson(true)
		, now_node(NullPtr)
		, Anim_Play_Totaltime(0.0005f)
		, Anim_Play_time(0.0f)
	{
		node_action = ptr_new AnimationNodeCustom(s);
	}

	/// add node
	sharedc_ptr(AnimationNodeGroup::GroupNode) AnimationNodeGroup::AddNode(const Core::Identifier & nodekey, bool continuity)
	{
		sharedc_ptr(GroupNode) groupnode = ptr_new GroupNode();
		groupnode->nodekey = nodekey;
		groupnode->array_attribute.Clear();
		groupnode->index = -1;
		groupnode->iscontinuity = continuity;
		//now_node = groupnode;
		groupnodeindex++;
		array_node.PushBack(groupnode);

		return groupnode;
		
	}

	/// add attribute
	void AnimationNodeGroup::AddNodeAttribute(tempc_ptr(GroupNode) node, const Core::Identifier & name,const Core::Identifier & addtivebase, float blend_time, bool cycle, float play_time, bool wait_stop)
	{
		PDE_ASSERT(node, "animation node error");

		sharedc_ptr(NodeAttribute) attribute = ptr_new NodeAttribute();
		attribute->keyname = name;
		if (addtivebase.Length() > 0)
			attribute->addtivebase = addtivebase;
		else
			attribute->addtivebase = Core::Identifier::kNull;
		attribute->blend_time	= blend_time;
		attribute->loop			= cycle;
		attribute->play_time	= play_time;
		attribute->waitstop		= wait_stop;
		node->array_attribute.PushBack(attribute);
	}

	/// set animation set
	void AnimationNodeGroup::SetAnimationSet(by_ptr(AnimationSet) set)
	{
		node_action->SetAnimationSet(set);
	}

	/// set animation node
	void AnimationNodeGroup::SetAnimationNode(by_ptr(AnimationNode) n)
	{
		node_action->SetAnimationNode(n);
	}

	/// get animation node
	tempc_ptr(AnimationNode) AnimationNodeGroup::GetAnimationNode()
	{
		return node_action->node;
	}

	bool AnimationNodeGroup::IsNowNode(const Core::Identifier & nodekey)
	{
		if (now_node)
			return now_node->nodekey == nodekey;

		return false;
	}

	/// play action
	tempc_ptr(AnimationNodePose) AnimationNodeGroup::PlayAction(const Core::Identifier & nodekey, const Core::Identifier & nodename, float playtime)
	{
		int id_group = FindIndexFromKey(nodekey, true);
		if (id_group == -1)
			return NullPtr;
		groupnodeindex = id_group;
		now_node = array_node[id_group];
		int id_attribute = FindIndexFromKey(nodename, false);
		if(id_attribute == -1)
			return NullPtr;
		now_node->index = id_attribute;
		time = now_node->array_attribute[id_attribute]->play_time;

		sharedc_ptr(NodeAttribute) node = now_node->array_attribute[id_attribute];

		if(nodeevent)
		{
			if (isfirstperson)
				nodeevent->OnAnimationStartFPEvent(now_node->nodekey, now_node->index);
			else
				nodeevent->OnAnimationStartTPEvent(now_node->nodekey, now_node->index);
		}
		if (playtime > EPSILON)
			node->play_time = playtime;
		//Anim_Play_Totaltime = node->play_time;
		//Anim_Play_time = 0.0f;
		//LogSystem.WriteLinef("%s node->playtime = %f",nodekey,node->play_time);
		//LogSystem.WriteLinef("%s node->blend_time = %f",nodekey,node->blend_time);
		tempc_ptr(AnimationNodePose) act = node_action->PlayAction(node->keyname, node->blend_time, node->blend_time, node->loop, node->play_time, node->waitstop);
		if (node->addtivebase.Length() > 0)
			act->SetAddtiveBase(node->addtivebase);
		
		showend = true;
		return act;
	}

	/// get addtive pose
	tempc_ptr(Pose) AnimationNodeGroup::GetAddtivePose()
	{
		if (now_node && now_node->index >= 0)
			return node_action->GetAddtivePose();

		return NullPtr;
	}

	/// get pose
	tempc_ptr(Pose) AnimationNodeGroup::GetPose()
	{
		if (now_node && now_node->index >= 0)
			return node_action->GetPose();

		return NullPtr;
	}

	/// on active
	void AnimationNodeGroup::OnActive()
	{
		if (now_node && now_node->index >= 0)
			node_action->OnActive();
	}

	/// on valid
	void AnimationNodeGroup::OnValid(bool valid)
	{
		if (now_node && now_node->index >= 0)
			node_action->OnValid(valid);
	}

	/// update
	void AnimationNodeGroup::Update(F32 frame_time)
	{
		if (Anim_Play_time < Anim_Play_Totaltime)
		{
			Anim_Play_time += frame_time;
		}
		if (now_node)
		{
			if(now_node->Size() == 1 || !now_node->iscontinuity)
				return;

			if (time > frame_time)
			{
				time -= frame_time;
			}
			else
			{
				if (now_node->index >= 0 && !now_node->array_attribute[now_node->index]->loop)
				{
					if (now_node->index < now_node->Size() - 1)
					{
						if (nodeevent)
						{
							if (isfirstperson)
								nodeevent->OnAnimationEndFPEvent(now_node->nodekey, now_node->index);
							else
								nodeevent->OnAnimationEndTPEvent(now_node->nodekey, now_node->index);
						}
						now_node->index++;

						if (nodeevent)
						{
							if (isfirstperson)
								nodeevent->OnAnimationStartFPEvent(now_node->nodekey, now_node->index);
							else
								nodeevent->OnAnimationStartTPEvent(now_node->nodekey, now_node->index);
						}
						time = now_node->array_attribute[now_node->index]->play_time;
						sharedc_ptr(NodeAttribute) node = now_node->array_attribute[now_node->index];
						Anim_Play_Totaltime = node->play_time;
						Anim_Play_time = 0.0f;
						//LogSystem.WriteLinef("node->playtime = %f",node->play_time);
						tempc_ptr(AnimationNodePose) act = node_action->PlayAction(node->keyname, node->blend_time, node->blend_time, node->loop, node->play_time, node->waitstop);
						if (node->addtivebase.Length() > 0)
							act->SetAddtiveBase(node->addtivebase);
					}
					else
					{
						if (!now_node->array_attribute[now_node->index]->waitstop)
							StopAction();
					}
				}
			}
		}
	}

	/// pause action
	void AnimationNodeGroup::PauseAction(bool pause)
	{
		if (now_node && now_node->index >= 0)
			node_action->PauseAction(pause);
	}

	/// stop action
	void AnimationNodeGroup::StopAction(bool immediate)
	{
		if(now_node && now_node->index < now_node->Size() - 1 && showend && now_node->iscontinuity)
		{
			showend = false;
			if (nodeevent)
			{
				if (isfirstperson)
					nodeevent->OnAnimationEndFPEvent(now_node->nodekey, now_node->index);
				else
					nodeevent->OnAnimationEndTPEvent(now_node->nodekey, now_node->index);
			}
			now_node->index = now_node->Size() - 1;

			if (nodeevent)
			{
				if (isfirstperson)
					nodeevent->OnAnimationStartFPEvent(now_node->nodekey, now_node->index);
				else
					nodeevent->OnAnimationStartTPEvent(now_node->nodekey, now_node->index);
			}

			time = now_node->array_attribute[now_node->index]->play_time;
			sharedc_ptr(NodeAttribute) node = now_node->array_attribute[now_node->index];
			tempc_ptr(AnimationNodePose) act = node_action->PlayAction(node->keyname, node->blend_time, node->blend_time, node->loop, node->play_time, node->waitstop);
			if (node->addtivebase.Length() > 0)
				act->SetAddtiveBase(node->addtivebase);
		}
		else
		{
			node_action->StopAction(immediate);
			if (now_node && nodeevent)
			{
				if (isfirstperson)
					nodeevent->OnAnimationEndFPEvent(now_node->nodekey, now_node->index);
				else
					nodeevent->OnAnimationEndTPEvent(now_node->nodekey, now_node->index);
			}
			if (now_node)
				now_node->index = -1;
			time = 0.f;
		}

	}

	/// is action playing
	bool AnimationNodeGroup::IsActionPlaying()
	{
		if (now_node && now_node->index >= 0)
			return node_action->IsActionPlaying();
		else
			return false;
	}

	/// force blend
	void AnimationNodeGroup::ForceBlend()
	{
		if (now_node && now_node->index >= 0)
			node_action->ForceBlend();
	}

	/// RegisterEvent
	void AnimationNodeGroup::RegisterEvent(by_ptr(ChangeNodeEventBase) event)
	{
		nodeevent = event;
	}

	/// find index
	int AnimationNodeGroup::FindIndexFromKey(const Core::Identifier & nodekey, bool isnode)
	{
		if (isnode)
		{
			int size = array_node.Size();
			for (int i = 0; i < size; ++i)
			{
				if (array_node[i]->nodekey == nodekey)
					return i;
			}
		}
		else
		{
			if (now_node)
			{
				for (int i = 0; i < now_node->Size(); ++i)
				{
					if (now_node->array_attribute[i]->keyname == nodekey)
						return i;
				}
			}
		}
		return -1;
	}

	void AnimationNodeGroup::SetFirstPerson()
	{
		isfirstperson = true;
	}

	void AnimationNodeGroup::SetThirdPerson()
	{
		isfirstperson = false;
	}

	void AnimationNodeGroup::LoadGroupNode(const Core::Identifier & nodekey)
	{
		CStrBuf<256> filename;
		if(isfirstperson)
			filename.format("/character/%s_fp.lua",nodekey);
		else
			filename.format("/character/%s_tp.lua",nodekey);

		sharedc_ptr(ScriptLua) lua = RESOURCE_LOAD(filename.buff(), false, ScriptLua);
		if (lua)
		{
			Lua::LuaState *L = Lua::LuaState::NewState();
			int top = L->GetTop();
			L->NewTable();
			if (L->LoadBuffer(lua->GetBuffer(), lua->GetSize(), filename.buff()) == 0)
			{
				L->PushValue(top + 1);
				L->SetFenv(-2);

				if (L->DoCall(0, 0))
				{
					const char *msg = L->ToString(-1);
					if (msg) Console.WriteLine(msg);
					L->Pop(1);
				}
				else
				{
					L->GetField(-1, "group");
					int group_size = L->ObjLen(-1);
					L->Pop(1);
					int index = 1;
					int array_size = 0;
					while(group_size > 0)
					{
						L->GetField(-1, "group");
						group_size--;

						L->PushInteger(index);
						L->GetTable(-2);
						index++;

						L->PushInteger(1);
						L->GetTable(-2);
						String key = L->ToString(-1);
						L->Pop(1);

						L->PushInteger(2);
						L->GetTable(-2);
						bool isgroup = L->ToBoolean(-1);
						L->Pop(1);
	
						sharedc_ptr(GroupNode) node = AddNode(key,isgroup);

						L->Pop(1);
						L->Pop(1);

						L->GetField(-1, key);
						array_size = L->ObjLen(-1);
						
						for(int i = 1; i <= array_size; i++)
						{
							L->PushInteger(i);
							L->GetTable(-2);

							L->PushInteger(1);
							L->GetTable(-2);
							String ani_name = L->ToString(-1);
							L->Pop(1);

							L->PushInteger(2);
							L->GetTable(-2);
							String addtivebase = L->ToString(-1);
							L->Pop(1);

							L->PushInteger(3);
							L->GetTable(-2);
							float blend_time = L->ToNumber(-1);
							L->Pop(1);

							L->PushInteger(4);
							L->GetTable(-2);
							bool cycle = L->ToBoolean(-1);
							L->Pop(1);

							L->PushInteger(5);
							L->GetTable(-2);
							float play_time = L->ToNumber(-1);
							L->Pop(1);

							L->PushInteger(6);
							L->GetTable(-2);
							bool wait_stop = L->ToBoolean(-1);
							L->Pop(1);
							
							AddNodeAttribute(node, ani_name,addtivebase,blend_time,cycle,play_time,wait_stop);

							L->Pop(1);
						}

						L->Pop(1);
					}
					L->Pop(1);
				}
			}
			else
			{
				const char *msg = L->ToString(-1);
				if (msg) Console.WriteLine(msg);
				L->Pop(1);
			}

			L->Close();
		}
	}

	bool AnimationNodeGroup::IsGroupLoop(const Core::Identifier & nodekey)
	{
		int size = array_node.Size();
		for (int i = 0; i < size; ++i)
		{
			if (array_node[i]->nodekey == nodekey)
				return array_node[i]->iscontinuity;
		}
		return false;
	}
}