#include "pch.h"
#include <time.h>
using namespace Core;
using namespace Client;

const int Bomb_Totle_Timer = 45;  // �װ���ը��ʱ��
const int Bomb_Pack_Timer = Bomb_Totle_Timer/5;  // �װ�ÿ����Ч���ŵ�ʱ��
const int CommonZombie_People_energy = 1000;  //��ʬ��Ⱦģʽ����������ֵ
const float CommonZombie_energy_totle_time = 10.0f;  //��ʬ��Ⱦģʽ�˱�����������ʱ��
const float CommonPeople_Skill_MaxTime = 30.f;
static bool	boss_mode2_minute_sound = false;
const float die_buff_stay_time =1.f;//����buff�����ͣ��ʱ��
const float ICON_MOVE_TIME = 1.24f;
const int MOONSCORE[8] = {3400,2720,2040,1700,1360,510,340,170};

InGameUINew::InGameUINew()
: zd_time(0.f)
, b_time(0.f)
, isshowblood(true)
, show_snipertarget_time(0.f)
, input_index(-1)
, input_timer(0.f)
, info_time(0)
, cooldown_time(4.f)
, is_novice_holdpoint_ok(false)
, is_Mvp(false)
, m_bomb_ico_time(0.0f)
, show_tips_bomb_time(0.0f)
,laoda1Fiveflag(true)
,laoda1Twoflag(true)
,laoda2Fiveflag(true)
,laoda2Twoflag(true)
,laoda1win(true)
,laoda2win(true)
, bomb_plantedtimer_part(0.0f)
, ui_score_line(0)
, Card_Play(false)
, player_die_time(25.0f)
, fu_huo_bi_use_count(0)
, m_Commonzombie_energy_time(0.0f)
, m_Showmiddle_str_time(0.0f)
, m_Showmiddleup_str_time(0.0f)

, m_boss_mode2_shine_time(0.0f)
, m_boss_mode2_shine_time_space(0.0f)
, m_boss_mode2_boss_twoweapon_tips_time(0.0f)
, m_boss_mode2_hit_total(0)
, m_MiniMachine_gun_show_time(0.01f)
, m_isCarriering(false)
, m_CarrierTime(0.0f)
, m_cur_reshp(0)
, m_max_reshp(0)
, m_rightScaleTime(0.0f)
, m_leftScaleTime(0.0f)
, m_KeyGScaleTime(0.0f)
, m_KeyHScaleTime(0.0f)
, m_SelectLeftTime(0.0f)
, m_SelectRightTime(0.0f)
, m_ResTime(0.0f)
{
	m_commonzombie_level_isup_time[0] = 1.0f;
	m_commonzombie_level_isup_time[1] = 1.0f;
	m_boss_mode2_human_skill_level_up_time[0] = 0.0f;
	m_boss_mode2_human_skill_level_up_time[1] = 0.0f;
	m_boss_mode2_human_skill_level_up_time[2] = 0.0f;
	m_boss_mode2_human_skill_level_up_time[3] = 0.0f;
	m_boss_mode2_human_skill_level_up_time_two[0] = 0.0f;
	m_boss_mode2_human_skill_level_up_time_two[1] = 0.0f;
	m_boss_mode2_human_skill_level_up_time_two[2] = 0.0f;
	m_boss_mode2_human_skill_level_up_time_two[3] = 0.0f;
	m_ShowBottom_str_time[0] = 0.0f;
	m_ShowBottom_str_time[1] = 0.0f;
	memset(m_DisplayItem, 0, sizeof(m_DisplayItem) );
	m_skill = ptr_new(PlayerSkill);
}	

InGameUINew::~InGameUINew()
{
	if (gLevel && gLevel->audio_background)
	{
		gLevel->audio_background->stop(true);
		gLevel->audio_background = NULL;
	}
	if (gLevel &&gLevel->audio_Survival_background )
	{
		gLevel->audio_Survival_background->stop(true);
		gLevel->audio_Survival_background = NULL;
	}
	if (gLevel &&gLevel->audio_Survival1_background )
	{
		gLevel->audio_Survival1_background->stop(true);
		gLevel->audio_Survival1_background = NULL;
	}
	if (gLevel&&gLevel->GetPlayer() &&gLevel->GetPlayer()->boss_2D_survival )
	{
		gLevel->GetPlayer()->boss_2D_survival->stop(true);
		gLevel->GetPlayer()->boss_2D_survival = NULL;
	}

	if (gLevel && gLevel->audio_killing_background)
	{
		gLevel->audio_killing_background->stop(true);
		gLevel->audio_killing_background = NULL;
	}
	if (gLevel && gLevel->audio_chrismas_background)
	{
		gLevel->audio_chrismas_background->stop(true);
		gLevel->audio_chrismas_background = NULL;
	}
	if (m_skill)
	{
		m_skill = NullPtr;
	}
	_Play_PlantedTimer_sound_stop();
}

Core::String TextCopy(Core::String str, int index,int count)
{
	CStrBuf<40960> tstr, tstr1;
	Core::String ret = "";

	int len = str.Length(), i = 0;
	bool is_input = false;

	tstr.copy(str.RefStr(),0,len);

	char *p = tstr.buff();

	if(index > len - 1)
		return ret;

	while(*p != '\0')
	{
		if(i == index)
			is_input = true;
#ifdef USE_UTF8
		S32 len = GetUTF8CharLength((U8*)p, -1) - 1;
		while (len > 0)
		{
			if (is_input)
				tstr1.insert(tstr1.len(), *p);
			p++;
			len--;
		}
#else
		if(IsDBCSLeadByteEx(936,*p))
		{
			if(is_input)
				tstr1.insert(tstr1.len(), *p);
			p++;
		}
#endif
		if(is_input)
		{
			tstr1.insert(tstr1.len(),*p);
			count--;
			if(count == 0)
				break;
		}
		p++;

		i++;
	}
	ret = tstr1;
	return ret;
}

int TextLenght(Core::String str)
{
	const char *p = str.Str();
	int count = 0;

	while(*p != '\0')
	{
#ifdef USE_UTF8
		S32 len = GetUTF8CharLength((U8*)p, -1);
		if (len)
		{
			p += len;
		}
		else
		{
			return count;
		}
#else
		if(IsDBCSLeadByteEx(936,*p))
		{
			p++;
		}
		p++;
#endif
		count++;
	}

	return count;
}

void GetNum_alone(int _num,int T_num[],const int n)
{
	int _index = 0;
	do
	{
		T_num[_index] = _num%10;
		_num = _num/10;
		_index++;
		if (_index >= n)
		{
			break;
		}
	} while (_num>0);
}

void InGameUINew::OnDestroy()
{
	normal_command_radio.Clear();
	team_command_radio.Clear();
	reply_command_radio.Clear();
	dummy_radio.Clear();

	array_addbloodeffect_info.Clear();
	ui_bottom_info_headhui_icon.Clear();
	ui_bottom_info_headbinsi_icon.Clear();
	ui_common_hp_headicon.Clear();
	
	m_current_pveboss = NullPtr;

	Object::OnDestroy();
}

// on create
void InGameUINew::OnCreate()
{
	Object::OnCreate();

	_InitHeadInfo();
	_InitHeadIcon();
	_InitBGImage();
	_InitBottomInfo();
	_InitSmallMapTextures();
	_InitHitsImage();
	_InitKillTextures();
	_InitAnimSprite();
	_InitGameTypeInfoTextures();
	_InitTabShow();
	_InitNovice();
	_InitBombInfo();
	_InitZombieInfo();
	_InitBoss2Info();
	_InitCommonZombieInfo();
	_InitBossmode2Info();
	_InitItemModeInfo();
	_InitMoonMode();



	tip_effect_list.Clear();

	char_mode = 0;
	char_mode_Tab = 0;

	for(int i = 0 ; i < 5; i++)
		speaker_list.Add(i);
	speaker_current_list.Clear();

	showhornscale = 0.0f;

	speaker_msg_flag = false;
	speaker_msg_time = 0.0f;

	warn_msg_flag = false;
	warn_msg_time = 0.0f;
	zd_fPersert_red = 0.0f;

	warn_msg.clear();
	m_current_pveboss = NullPtr;

	team_request_bg_texture = RESOURCE_LOAD_NEW("InGameUI/ingame_bar01_team_BG.tga", true, Texture2D);
	team_request_bar_Texture = RESOURCE_LOAD_NEW("InGameUI/ingame_bar01_team_content.tga", true, Texture2D);
	team_request_dialog_texture = RESOURCE_LOAD_NEW("InGameUI/ingame_squad_team_BG01.tga", true, Texture2D);

	show_game_scores = false;
	show_scores = false;
	show_map = false;
	ui_rotate = 0.f;
	zd_novice_time = 0.f;
	win_time = 0.f;
	win_team = -1;
	zd_red_showtime = 1.f;
	zd_blue_showtime = 1.f;
	text_input_color = ARGB(251, 245, 231);

	blast_icon = RESOURCE_LOAD_NEW("weapon/rocketlauncher_zhongjie.dds", true, Texture2D);
	fire_icon = RESOURCE_LOAD_NEW("weapon/flame_fire.dds", true, Texture2D);
	kill_died = RESOURCE_LOAD_NEW("weapon/rocketlauncher_zhongjie.dds", true, Texture2D);
	kill_headshot = RESOURCE_LOAD_NEW("weapon/kill_headshot.dds", true, Texture2D);
	process_bar = RESOURCE_LOAD_NEW("InGameUI/ingame_Schedule01.tga", true, Texture2D);
	bomb_kill = RESOURCE_LOAD_NEW("InGameUI/bomb/bomb.dds", true, Texture2D);
	king_kill = RESOURCE_LOAD_NEW("weapon/ig_common_tubiao_kingover.dds", true, Texture2D);

	ui_textures[0] = RESOURCE_LOAD_NEW("InGameUI/blood_screen.dds", true, Texture2D);
	ui_textures[1] = RESOURCE_LOAD_NEW("InGameUI/ig_map_cursor04.tga", true, Texture2D);
	ui_textures[2] = RESOURCE_LOAD_NEW("InGameUI/ig_map_cursor03.dds", true, Texture2D);
	ui_textures[3] = RESOURCE_LOAD_NEW("InGameUI/ig_map_cursor02.dds", true, Texture2D);
	ui_textures[4] = RESOURCE_LOAD_NEW("InGameUI/ig_map_cursor01.dds", true, Texture2D);
	ui_textures[5] = RESOURCE_LOAD_NEW("InGameUI/burning_screen.dds", true, Texture2D);
	ui_textures[6] = RESOURCE_LOAD_NEW("InGameUI/map_addhp.dds", true, Texture2D);
	ui_textures[7] = RESOURCE_LOAD_NEW("InGameUI/ig_common_tubiao_map_king_mark.dds", true, Texture2D);
	ui_textures[8] = RESOURCE_LOAD_NEW("InGameUI/bomb/map_bomb_ico.dds", true, Texture2D);
	ui_textures[9] = RESOURCE_LOAD_NEW("InGameUI/burning_screen01.dds", true, Texture2D);
	ui_textures[10] = RESOURCE_LOAD_NEW("InGameUI/gatherway_screen.dds", true, Texture2D);
	ui_textures[11] = RESOURCE_LOAD_NEW("InGameUI/slow_screen.dds", true, Texture2D);
	ui_textures[12] = RESOURCE_LOAD_NEW("InGameUI/reverse_screen.dds", true, Texture2D);
	ui_textures[13] = RESOURCE_LOAD_NEW("InGameUI/burning_screen02.dds", true, Texture2D);

	ui_control_tip = RESOURCE_LOAD_NEW("InGameUI/ig_common_tubiao_kongzhi.dds", true, Texture2D);

	win_red_icon = RESOURCE_LOAD_NEW("InGameUI/ig_common_win_red.dds", true, Texture2D);
	win_blue_icon = RESOURCE_LOAD_NEW("InGameUI/ig_common_win_blue.dds", true, Texture2D);
	win_boss_icon = RESOURCE_LOAD_NEW("InGameUI/ig_common_win_boss.dds", true, Texture2D);
	win_human_icon = RESOURCE_LOAD_NEW("InGameUI/ig_common_win_human.dds", true, Texture2D);
	win_zombie_icon = RESOURCE_LOAD_NEW("InGameUI/ig_common_win_re.dds", true, Texture2D);

	speaker_texture = RESOURCE_LOAD_NEW("InGameUI/ig_horn.dds", true, Texture2D);
	speaker_texture_background = RESOURCE_LOAD_NEW("InGameUI/ig_common_dalaba_bg.dds", true, Texture2D);

	ui_boss_num = RESOURCE_LOAD_NEW("InGameUI/countdown_number.dds", true, Texture2D);
	ui_power_num = RESOURCE_LOAD_NEW("LobbyUI/lb_bg_win01_4_number.dds", true, Texture2D);
	ui_win = RESOURCE_LOAD_NEW("InGameUI/tab/win.dds", true, Texture2D);
	ui_Fail = RESOURCE_LOAD_NEW("LobbyUI/GameBalance/summary_lose_logo.dds", true, Texture2D);
	ui_power_wenhao = RESOURCE_LOAD_NEW("InGameUI/lb_bg_win01_4_number_wenhao.dds", true, Texture2D);

	ui_sensitivity_box = RESOURCE_LOAD_NEW("InGameUI/ig_sensitivity_box.dds", true, Texture2D);
	ui_sensitivity_box2 = RESOURCE_LOAD_NEW("InGameUI/ig_sensitivity_box_2.dds", true, Texture2D); 
	ui_sensitivity_scrollbar_bg = RESOURCE_LOAD_NEW("InGameUI/ig_sensitivity_scrollbar_bg.dds", true, Texture2D);  
	ui_sensitivity_scrollbar_slider = RESOURCE_LOAD_NEW("InGameUI/ig_sensitivity_scrollbar_slider_normal.dds", true, Texture2D); 
	ui_AmmoStick = RESOURCE_LOAD_NEW("InGameUI/rocket05001ico.dds", true, Texture2D);  



  //����
	ui_survival[0] = RESOURCE_LOAD_NEW("InGameUI/survival/icon/ig_itemmode_skill_ico_35.DDS", true, Texture2D);
	ui_survival[1] = RESOURCE_LOAD_NEW("InGameUI/survival/icon/ig_itemmode_skill_ico_29.dds", true, Texture2D);
	ui_survival[2] = RESOURCE_LOAD_NEW("InGameUI/survival/icon/ig_itemmode_skill_ico_33.DDS", true, Texture2D);
	ui_survival[3] = RESOURCE_LOAD_NEW("InGameUI/survival/icon/ig_itemmode_skill_ico_34.DDS", true, Texture2D);
    ui_survival[4] = RESOURCE_LOAD_NEW ("InGameUI/survival/icon/ig_itemmode_skill_dbuf_bg.DDS", true, Texture2D);
    ui_survival1 = RESOURCE_LOAD_NEW("InGameUI/survival/icon/ig_itemmode_skill_ico_bg_02.DDS",true , Texture2D);
    ui_survival2 = RESOURCE_LOAD_NEW ("InGameUI/survival/icon/ig_useitem_ico_border.DDS",true , Texture2D);
	ui_survival4 = RESOURCE_LOAD_NEW ("InGameUI/survival/icon/surplusnum.dds",true , Texture2D);
	ui_survival5 = RESOURCE_LOAD_NEW ("InGameUI/survival/icon/revive.dds",true , Texture2D);

	ui_survival6 = RESOURCE_LOAD_NEW ("InGameUI/survival/icon/surplus.dds",true , Texture2D);
	ui_survival7 = RESOURCE_LOAD_NEW ("InGameUI/survival/icon/surplus2.DDS",true , Texture2D);
	ui_survival8 = RESOURCE_LOAD_NEW ("InGameUI/survival/icon/surplus1.DDS",true , Texture2D);
	ui_survival13 = RESOURCE_LOAD_NEW ("InGameUI/survival/icon/ig_itemmode_skill_ico_32_1.dds",true , Texture2D);
              

    ui_Keying[0] = RESOURCE_LOAD_NEW ("InGameUI/survival/icon/ui_Survival_Keying_01.dds",true , Texture2D);
	ui_Keying[1] = RESOURCE_LOAD_NEW ("InGameUI/survival/icon/ui_Survival_Keying_02.dds",true , Texture2D);
	ui_Keying[2] = RESOURCE_LOAD_NEW ("InGameUI/survival/icon/ui_Survival_Keying_03.dds",true , Texture2D);
	ui_Keying[3] = RESOURCE_LOAD_NEW ("InGameUI/survival/icon/ui_Survival_Keying_04.dds",true , Texture2D);
	ui_Keying[4] = RESOURCE_LOAD_NEW ("InGameUI/survival/icon/ui_Survival_Keying_05.dds",true , Texture2D);

	ui_survival3 = RESOURCE_LOAD_NEW ("InGameUI/survival/icon/ig_itemmode_skill_ico_28.dds",true , Texture2D);
	ui_survival9 = RESOURCE_LOAD_NEW ("InGameUI/survival/icon/harm.dds",true , Texture2D);
	ui_survival10 = RESOURCE_LOAD_NEW ("InGameUI/survival/icon/snare.DDS",true , Texture2D);

	ui_survival11 = RESOURCE_LOAD_NEW ("InGameUI/survival/icon/Survival_prompting.DDS",true , Texture2D);
	ui_survival12 = RESOURCE_LOAD_NEW ("InGameUI/survival/icon/Ghost_prompting.DDS",true , Texture2D);

	for(int i = 0 ; i < 5; i ++)
	{
		speaker_anim[i].texture = speaker_texture;
		speaker_anim[i].scale_spline.AddPoint(0.01f, 0, 0, 0, 2);
		speaker_anim[i].scale_spline.AddPoint(0.155f, 2.0f, 0, 0, 2);
		speaker_anim[i].scale_spline.AddPoint(0.19f, 1.5f, 0, 0 , 2);
		speaker_anim[i].scale_spline.AddPoint(0.23f, 1.0f, 0, 0 , 2);
	}

	ui_cooldown_circle = RESOURCE_LOAD_NEW("InGameUI/cooldown/cooldown_circle.tga", true, Texture2D);
	ui_cooldown_circle_bg = RESOURCE_LOAD_NEW("InGameUI/cooldown/cooldown_circle_bg.tga", true, Texture2D);
	ui_quick_move = RESOURCE_LOAD_NEW("InGameUI/cooldown/ig_item_mode_boss_skill_ico.dds", true, Texture2D);

	ui_ingam_cancel_tower_gun = RESOURCE_LOAD_NEW("InGameUI/TD_mode/ig_bg02.dds", true, Texture2D);

	fFadeTime = 8.0f;
	fFadeCoolDown = 8.0f;
	bFoused = false;
	currentLine = "";
	inGameUI_textInput = ptr_new Gui::Textbox();
	inGameUI_textInput->SetText(currentLine);
	inGameUI_textInput->SetMaxLength(120);
	inGameUI_textInput->SetMultiline(false);
	inGameUI_textInput->SetTextColor(Core::ARGB(255,0,0));
	inGameUI_textInput->SetDisabledTextColor(Core::ARGB(255,0,0));
	small_map = ptr_new RenderTexture;
	ptr_static_cast<RenderTexture>(small_map)->CreateRenderTexture(230, 199, 1, D3DUSAGE_RENDERTARGET, D3DFMT_A8R8G8B8);

	normal_command_radio.PushBack(gLang->GetTextW(L"�õģ��յ���"));
	normal_command_radio.PushBack(gLang->GetTextW(L"ǰ�����ֵ��ˣ�"));
	normal_command_radio.PushBack(gLang->GetTextW(L"����Ҫ�ڻ���"));
	normal_command_radio.PushBack(gLang->GetTextW(L"ǰ����ȫ��"));
	normal_command_radio.PushBack(gLang->GetTextW(L"��������"));

	team_command_radio.PushBack(gLang->GetTextW(L"С�Ļ����͵Ϯ��"));
	team_command_radio.PushBack(gLang->GetTextW(L"С�ĵ��˾ѻ��֣�"));
	team_command_radio.PushBack(gLang->GetTextW(L"������Ҫ�ػ�ǹ�֣�"));
	team_command_radio.PushBack(gLang->GetTextW(L"����Ư����"));
	team_command_radio.PushBack(gLang->GetTextW(L"������أ�"));

	reply_command_radio.PushBack(gLang->GetTextW(L"��ҿ�ȥռ�㣡"));
	reply_command_radio.PushBack(gLang->GetTextW(L"��ҿ�ȥ�Ƴ���"));
	reply_command_radio.PushBack(gLang->GetTextW(L"�壡�壡�壡"));
	reply_command_radio.PushBack(gLang->GetTextW(L"��ҷ�ɢ����"));
	reply_command_radio.PushBack(gLang->GetTextW(L"����һ�£�"));

	dummy_radio.PushBack(gLang->GetTextW(L"��ǰ�ƶ�"));
	dummy_radio.PushBack(gLang->GetTextW(L"�����ƶ�"));
	dummy_radio.PushBack(gLang->GetTextW(L"�����ƶ�"));
	dummy_radio.PushBack(gLang->GetTextW(L"����ƶ�"));

	anim_picture_Mvp = RESOURCE_LOAD_NEW("InGameUI/headinfo/ig_common_mvp.dds", true, Texture2D);
	anim_pictureIn = ptr_new AnimPicture;
	anim_pictureIn->Create("InGameUI/headinfo/ig_mvp_star.dds",Vector2(100,-140),Vector2(50,50),Vector2(0.5,0.5),-1);
	anim_pictureOut = ptr_new AnimPicture;
	anim_pictureOut->Create("InGameUI/headinfo/ig_mvp_star.dds",Vector2(100,-140),Vector2(50,50),Vector2(0.5,0.5));
	anim_pictureOut->SetMaxzoom(10.0f);	
	anim_pictureOut->Settimespeed(0.017f);
	anim_picture_Mvp_In = ptr_new AnimPicture;
	anim_picture_Mvp_In->Create("InGameUI/headinfo/ig_mvp_text.dds",Vector2(100,-140),Vector2(80,32),Vector2(0.5,0.5));
	anim_picture_Mvp_In->SetSums(1);
	anim_picture_Mvp_In->SetMaxzoom(4);
	anim_picture_Mvp_In->Setretaintime(0.7f);
	anim_picture_Mvp_In->EventPlaystop.Subscribe(NewDelegate(&InGameUINew::OnPlayStop,ptr_static_cast<InGameUINew>(this)));
	anim_picture_Mvp_Out = ptr_new AnimPicture;
	anim_picture_Mvp_Out->Create("InGameUI/headinfo/ig_mvp_text.dds",Vector2(100,-140),Vector2(80,32),Vector2(0.5,0.5));
	anim_picture_Mvp_Out->SetSums(1);
	anim_picture_Mvp_Out->SetMaxtime(1.5f);
	anim_picture_Mvp_Out->SetBegintimes(0.0f);
	anim_picture_Mvp_Out->SetEndtimes(1.5f);
	anim_picture_Mvp_Out->SetMaxzoom(15);
	anim_picture_Mvp_Out->Setretaintime(1.5f);
	
	anim_picture_Card_Out = ptr_new AnimPicture;
	anim_picture_Card_Out->Create("InGameUI/bottom_info/ig_common_fanpai_card_flash.dds",Vector2(220,-39),Vector2(16,18),Vector2(0.5,0.5));
	anim_picture_Card_Out->SetSums(1);
	anim_picture_Card_Out->SetMaxtime(1.0f);
	anim_picture_Card_Out->Settotletimes(1.0f);
	anim_picture_Card_Out->SetEndtimes(0.5f);
	anim_picture_Card_Out->SetMaxzoom(10);
	anim_picture_Card_Out->Setretaintime(1.0f);

	anim_picture_bigCard_Out = ptr_new AnimPicture;
	anim_picture_bigCard_Out->Create("InGameUI/bottom_info/ig_common_fanpai_card_1.dds",Vector2(230,-39),Vector2(16,18),Vector2(0.5,0.5));
	anim_picture_bigCard_Out->SetSums(1);
	anim_picture_bigCard_Out->SetMaxtime(0.35f);
	anim_picture_bigCard_Out->Setretaintime(0.35f);
	anim_picture_bigCard_Out->Settotletimes(0.7f);
	anim_picture_bigCard_Out->SetMinzoom(1.0f);
	anim_picture_bigCard_Out->SetBegintimes(0.0f);
	anim_picture_bigCard_Out->SetEndtimes(0.0f);
	anim_picture_bigCard_Out->SetMaxzoom(2.25);
	anim_picture_bigCard_Out->EventPlaystop.Subscribe(NewDelegate(&InGameUINew::OnPlayBigcardStop,ptr_static_cast<InGameUINew>(this)));

	anim_picture_bigCard_Out_next =  ptr_new AnimPicture;
	anim_picture_bigCard_Out_next->Create("InGameUI/bottom_info/ig_common_fanpai_card_1.dds",Vector2(230,-39),Vector2(16,18),Vector2(0.5,0.5));
	anim_picture_bigCard_Out_next->SetSums(1);
	anim_picture_bigCard_Out_next->SetMaxtime(0.15f);
	anim_picture_bigCard_Out_next->Setretaintime(0.3f);
	anim_picture_bigCard_Out_next->Settotletimes(0.3f);
	anim_picture_bigCard_Out_next->SetMinzoom(1.0f);
	anim_picture_bigCard_Out_next->SetBegintimes(0.0f);
	anim_picture_bigCard_Out_next->SetEndtimes(0.0f);
	anim_picture_bigCard_Out_next->SetMaxzoom(2.25);
	anim_picture_bigCard_Out_next->EventPlaystop.Subscribe(NewDelegate(&InGameUINew::OnPlaycardStop,ptr_static_cast<InGameUINew>(this)));

	CreateVideoButton();
}

// update
void InGameUINew::Update(float frameTime)
{	

	tempc_ptr(Character) player = gLevel->GetViewer();

	fFadeTime -= frameTime;
	if(fFadeTime < 0.0f)
	{
		fFadeTime = fFadeCoolDown;
		if(fiveMsgs.GetCount() > 0)
		{
			fiveMsgs.RemoveAt(0);
			Msgs_Color.RemoveAt(0);
		}
		if(speaker_current_list.GetCount() > 0)
		{
			speaker_list.PushBack(speaker_current_list.GetAt(0));
			speaker_current_list.RemoveAt(0);
		}
	}

	if (info_tip.Size() > 0)
	{
		info_time += frameTime;
		if (info_time > 6.0f)
		{
			info_time = 0.f;
			info_tip.RemoveAt(0);
		}
	}

	if(player)
	{
		if(player->hits_score_alpha > 0.0f)
		{
			player->hits_score_wait_time += frameTime;
			if(player->hits_score_wait_time >= 2.0f)
			{
				player->hits_score_alpha -= frameTime;

				if(player->hits_score_alpha < 0.0f)
					player->hits_score_alpha = 0.0f;
			}
		}

		//pickup object effect update
		Vector3 rt_size = gGame->guiSys->GetSize();

		for(int i = tip_effect_list.Size() - 1; i >=0  ; i--)
		{
			DigitalSprite &sprite = tip_effect_list[i];

			if(sprite.anim_time <= 0.0f && sprite.alpha_time <= 0.0f)
			{
				if(sprite.texture == gLevel->skill_img[10])
					player->is_display_c4_tip = true;
				else if(sprite.texture)
					player->is_display_weapon_list = true;
				else
				{
					player->is_display_weapon_list = true;
				}

				tip_effect_list.RemoveAt(i);
			}
			else
			{
				sprite.anim_time -= frameTime * 3;

				if(sprite.anim_time <= 0.0f)
				{
					sprite.pos.x = sprite.end_pos.x;
					sprite.pos.y = sprite.end_pos.y;

					sprite.alpha_time -= frameTime;
				}
				else
				{
					sprite.pos.x = sprite.start_pos.x * (sprite.anim_time / 1.5f) + sprite.end_pos.x * (1.0f - sprite.anim_time / 1.5f);
					sprite.pos.y = sprite.start_pos.y * (sprite.anim_time / 1.5f) + sprite.end_pos.y * (1.0f - sprite.anim_time / 1.5f);
				}
			}
		}

		int len = player->current_pickup_object_list.Size();

		for(int i = 0 ; i < len; i++)
		{
			DigitalSprite teffect;

			teffect.alpha_time = 1.0f;
			teffect.anim_time = 1.8f;
			teffect.start_pos.x = rt_size.x / 2.0f;
			teffect.start_pos.y = rt_size.y - 100;

			teffect.pos.x = teffect.start_pos.x;
			teffect.pos.y = teffect.start_pos.y;

			teffect.end_pos.x = rt_size.x - 120;
			teffect.end_pos.y = rt_size.y - 75;

			switch(player->current_pickup_object_type_list[0])
			{
			case 0:
				teffect.texture = player->current_pickup_object_list[0];
				teffect.type = 0;
				break;
			case 1:
				teffect.texture = player->current_pickup_object_list[0];

				teffect.start_pos.x = rt_size.x/2;
				teffect.start_pos.y = rt_size.y/2 + 250;

				teffect.end_pos.x = 45 + 20;
				teffect.end_pos.y = rt_size.y / 2 + 312 + 30;

				teffect.type = 1;
				break;
			case 2:
			case 3:
				teffect.texture = player->current_pickup_object_list[0];

				teffect.start_pos.x = rt_size.x / 2;
				teffect.start_pos.y = rt_size.y / 2;

				teffect.end_pos.x = 42;
				teffect.end_pos.y = rt_size.y - 380;

				teffect.type = 2;
				break;
			case 4:
				teffect.texture = player->current_pickup_object_list[0];

				teffect.start_pos.x = rt_size.x / 2;
				teffect.start_pos.y = rt_size.y / 2 + 100;

				teffect.end_pos.x = teffect.start_pos.x;
				teffect.end_pos.y = teffect.start_pos.y;

				teffect.type = 3;
				break;
			case 5:
				teffect.texture = player->current_pickup_object_list[0];

				teffect.start_pos.x = rt_size.x / 2;
				teffect.start_pos.y = rt_size.y / 2 + 100;

				teffect.end_pos.x = teffect.start_pos.x;
				teffect.end_pos.y = teffect.start_pos.y;

				teffect.name = player->current_pickup_object_name[0];

				teffect.type = 4;
				player->current_pickup_object_name.RemoveAt(0);
				break;
			case 6:
				teffect.texture = player->current_pickup_object_list[0];

				teffect.start_pos.x = rt_size.x / 2;
				teffect.start_pos.y = rt_size.y / 2 + 100;

				teffect.end_pos.x = teffect.start_pos.x;
				teffect.end_pos.y = teffect.start_pos.y;

				teffect.name = player->current_pickup_object_name[0];

				teffect.type = 5;
				player->current_pickup_object_name.RemoveAt(0);
				break;
			}

			player->current_pickup_object_list.RemoveAt(0);
			player->current_pickup_object_type_list.RemoveAt(0);

			tip_effect_list.PushBack(teffect);
		}
		//////////
	}

	if(warn_msg_flag)
	{
		warn_msg_time += frameTime;
		if(warn_msg_time > 60.0f)
			warn_msg_flag = false;
	}

	if(speaker_msg_flag)
	{
		speaker_msg_time += frameTime;
		if(speaker_msg_time > 10.0f)
			speaker_msg_flag = false;
	}

	//weapon list icon
	if(gGame)
	{
		if(player)
		{
			if( player->weapon_list_icon_flag == 1)
			{
				player->weapon_list_icon_movetime -= frameTime * 5.0f;
				if(player->weapon_list_icon_movetime <=0.0f)
				{
					player->weapon_list_icon_movetime = 1.0f;
					player->weapon_current_icon_alpha = 1.0f;
					player->weapon_list_icon_flag = 2;
				}
			}
			else if(player->weapon_list_icon_flag ==2)
			{
				player->weapon_list_icon_waittime -= frameTime;
				if(player->weapon_list_icon_waittime<=0.0f)
				{
					player->weapon_list_icon_waittime = 0.0f;
					player->weapon_list_icon_alpha -= frameTime * 2;
					if(player->weapon_list_icon_alpha<0.0f)
					{
						player->weapon_list_icon_alpha = 0.0f;
						player->weapon_list_icon_flag = 0;
						player->weapon_current_icon_alpha = 1.0f;
					}
				}
			}
		}
	}

	//hits 
	if(player && player->hit_current_score < player->all_score)
	{
		player->hit_scroll_time += frameTime;

		int tratio = abs(player->all_score - player->hit_current_score);
		if(tratio > 5)
		{
			player->hit_current_score += tratio / 3;
		}
		else
		{
			player->hit_current_score++;
		}

		if(player->hit_current_score > player->all_score)
			player->hit_current_score = player->all_score;
	}

	//add blood effect
	for(int i = 0; i < array_addbloodeffect_info.GetCount(); ++i)
	{
		if(array_addbloodeffect_info[i].time > 0)
		{
			array_addbloodeffect_info[i].position.y -= 130.0f / 1.0f * frameTime;
			array_addbloodeffect_info[i].time -= frameTime;
		}
		else
		{
			array_addbloodeffect_info.RemoveAt(i);
			i--;
		}
	}

	//for cure_ui
	if(player && player->state_addblood)
	{
		player->state_addblood_time -= frameTime;
		if(player->state_addblood_time  < 0.0f)
		{
			player->state_addblood = false; 
			player->state_invincible = 0.0f;
			player->from_cure_id = 0;
		}
	}
	if(player && player->state_addbloodtip)
	{
		player->state_addbloodtip_time -= frameTime;
		if(player->state_addbloodtip_time  < 0.0f)
		{
			player->state_addbloodtip = false;
		}
	}

	if(gLevel->showhorn && gLevel->horntime > 0.001)
	{
		showhornscale += 0.1f;
	}
	else
	{
		showhornscale = 0;
	}

	UpdataMvp();
	UpdataCard();
	OnPlaySoundBackground();
	player = gLevel->GetPlayer();
	if (player && player->IsDied() && player_die_time >= 0.0f)
	{
		player_die_time -= frameTime;
	}
	else if (player_die_time != 25.0f && player && !player->IsDied())
	{
		player_die_time = 25.0f;
	}

	OnUpdate_SkillItem(frameTime);

	// boss mode2 BOSS two weapon tips
	if (player && gLevel->game_type == RoomOption::kBossMode2 && !player->IsDied() && player->first_action_on && player->GetWeapon() ==  player->GetWeaponById(1) &&  player->GetTeam() == 1)
	{
		m_boss_mode2_boss_twoweapon_tips_time = 2.0f;
	}
	if (m_boss_mode2_boss_twoweapon_tips_time > 0.0f)
	{
		m_boss_mode2_boss_twoweapon_tips_time -= frameTime;
	}
	for (int i = 0 ; i < 2 ; i++)
	{
		if (m_commonzombie_level_isup_time[i] < 1.0f)
		{
			m_commonzombie_level_isup_time[i] += frameTime;
		}
	}

	for (int i = 0 ; i < 4 ; i++)
	{
		if (m_boss_mode2_human_skill_level_up_time_two[i] > 0.0f)
		{
			m_boss_mode2_human_skill_level_up_time_two[i] -= frameTime;
			if (m_boss_mode2_human_skill_level_up_time_two[i] < 0.0f)
			{
				m_boss_mode2_human_skill_level_up_time_two[i] = 0.0f;
			}
		}
	}

	for (int i = 0 ; i < 4 ; i++)
	{
		if (m_boss_mode2_human_skill_level_up_time[i] > 0.0f)
		{
			m_boss_mode2_human_skill_level_up_time[i] -= frameTime;
			if (m_boss_mode2_human_skill_level_up_time[i] < 0.0f)
			{
				m_boss_mode2_human_skill_level_up_time[i] = 0.0f;
				m_boss_mode2_human_skill_level_up_time_two[i] = 1.0f;
			}
		}
	}
		
	if (m_boss_mode2_shine_time > 0)
	{
		m_boss_mode2_shine_time -= frameTime;
		if (m_boss_mode2_shine_time <= 0)
		{
			m_commonzombie_level_isup_time[1] = 0.0f;
		}
	}

	tempc_ptr(Character) My_player = gLevel->GetPlayer();
	if (gLevel->game_type == RoomOption::kBossMode2 && My_player && !My_player->is_boss && !My_player->IsDied())
	{
		int hit_total = My_player->accumulate_damage/1000;
		if (m_boss_mode2_hit_total < hit_total)
		{
			My_player->kills_kind.PushBack(kBossmode2_Boss_hit);
		}
		m_boss_mode2_hit_total = hit_total;
	}
}


void InGameUINew::OnUpdate_SkillItem(float frameTime)
{
	for (int i = 0 ; i < commonzombie_skill.GetCount() ; i++)
	{
		SkillItem item = commonzombie_skill.GetAt(i);
		item.time -= frameTime;
		if (item.time > 0.0f)
		{
			commonzombie_skill.SetAt(i,item);
		} 
		else
		{
			commonzombie_skill.RemoveAt(i);
			i--;
		}
	}
	
}

int InGameUINew::SplitString( const Core::String& source, Core::String& target, const Core::Rectangle& rect, tempc_ptr(Client::Font) font )
{
	if(!font)
		return 0;
	if(!rect.IsValid())
		return 0;
	int maxWidth = rect.GetExtent().x;
	int lineNum = source.Length()?1:0;
	target = source;
	while(true)
	{
		Core::Rectangle tempRect = Core::Rectangle(0,0,0,0);
		Vector2 o = font->MeasureString(tempRect, target, -1, Unit::kAlignCenterMiddle).GetExtent();

		if(o.x<maxWidth)
			break;

		lineNum++;

		size_t pt = target.Length();
		do{
			pt--;
			o = font->MeasureString(tempRect, target, pt, Unit::kAlignCenterMiddle).GetExtent();				
		}while(o.x>=maxWidth);
#ifdef USE_UTF8
		while (!IsUTF8LeadByte(target[pt]))
		{
			pt--;
		}
#else
		if (!IsASCIIByte(target[pt]) && IsDBCSLeadByteEx(936, target[pt-1]))
		{
			pt--;
		}
#endif
		CRefStr &str = target.RefStr(target.Length()+2);
		str.insert(pt, '\n');

		if(lineNum>40)
			break;
	}
	return lineNum;
}

void InGameUINew::_DrawAddBloodTip(by_ptr(UIRender) ui_render)
{
	tempc_ptr(Character) viewer = gLevel->GetViewer();
	if(!viewer)
		return;
	tempc_ptr(WeaponBase) weapon = viewer->GetWeapon();
	if(!weapon)
		return;

	ui_render->BeginInGameUI();

	if(weapon->GetWeaponType() == kWeaponTypeCureGun && viewer->first_action_on)
	{
		tempc_ptr(CureGun) gun = ptr_dynamic_cast<CureGun>(weapon);
		if(!gun)
			return;
		tempc_ptr(Character) to_c = gLevel->GetCharacter(gun->cure_uid);
		if(to_c && viewer->state_addbloodtip)
		{
			Vector3 rt_size = gGame->guiSys->GetSize();
			Matrix44 oldworld = ui_render->GetWorld();
			Matrix44 world;
			world.SetTranslationXYZ(rt_size.x/2,rt_size.y-316,0);
			ui_render->SetWorld(world);

			ui_render->SetTexture(all_tipBg[viewer->GetTeam()]);
			ui_render->DrawWindow(Core::Rectangle(-190,0,190,65),Core::Rectangle(12,12,13,15),Core::Rectangle(12.0f / 51.f, 12.0f / 51.f, 13.0f / 51.f, 15.0f / 51.f));

			ui_render->DrawTextureWindow(Core::Vector2(-178, 2), 52, 60, ui_cure_icon[1]);

			CStrBuf<256> buff;
			buff.format(gLang->GetTextW(L"��������"));
			ui_render->DrawString(ui_render->font_simhei_22,ARGB(255,240,206),ARGB(1,1,1,1),Core::Rectangle(-85,2,5,30),buff,Unit::kAlignCenterMiddle);
			buff.format("%s",to_c->GetName());
			ui_render->DrawString(ui_render->font_simhei_20,ARGB(255,240,206),ARGB(1,1,1,1),Core::Rectangle(0,30,130,30+25),buff,Unit::kAlignCenterMiddle);
			int temp_hp = to_c->hp;
			temp_hp = temp_hp > 9999 ? 9999 : temp_hp;
			buff.format("hp:%d", temp_hp);
			ui_render->DrawString(ui_render->font_simhei_20,ARGB(255,240,206),ARGB(1,1,1,1),Core::Rectangle(-125,36,-75,36+15),buff,Unit::kAlignCenterMiddle);
			
			ui_render->SetWorld(oldworld);
		}
	}
	else
	{
		if(viewer->state_addbloodtip && viewer->from_cure_id > 0)
		{
			tempc_ptr(Character) from_c = gLevel->GetCharacter(viewer->from_cure_id);

			if(from_c && viewer->state_addbloodtip && viewer->from_cure_id > 0)
			{
				tempc_ptr(WeaponBase) from_c_weapon = from_c->GetWeapon();
				if (!from_c_weapon || from_c_weapon->GetWeaponType() != kWeaponTypeCureGun)
					return;
				tempc_ptr(GunBase) gun = ptr_dynamic_cast<GunBase>(from_c_weapon);
				if (!gun)
					return;

				Vector3 rt_size = gGame->guiSys->GetSize();
				Matrix44 oldworld = ui_render->GetWorld();
				Matrix44 world;
				world.SetTranslationXYZ(rt_size.x/2,rt_size.y-200,0);
				ui_render->SetWorld(world);

				ui_render->SetTexture(all_tipBg[viewer->GetTeam()]);
				ui_render->DrawWindow(Core::Rectangle(-190,0,190,65),Core::Rectangle(12,12,13,15),Core::Rectangle(12.0f / 51.f, 12.0f / 51.f, 13.0f / 51.f, 15.0f / 51.f));

				ui_render->DrawTextureWindow(Core::Vector2(-178, -8), 116, 84, ui_cure_icon[0]);

				CStrBuf<256> buff;
				buff.format("%s",from_c->GetName());
				ui_render->DrawString(ui_render->font_simhei_20,ARGB(255,240,206),ARGB(1,1,1,1),Core::Rectangle(-37,5,-37+182,5+25),buff,Unit::kAlignCenterMiddle);

				buff.format(gLang->GetTextW(L"��������"));
				ui_render->DrawString(ui_render->font_simhei_22,ARGB(255,240,206),ARGB(1,1,1,1),Core::Rectangle(40,30,40+70,30+25),buff,Unit::kAlignCenterMiddle);

				buff.format("%d %%",(int)gun->power);
				ui_render->DrawString(ui_render->font_simhei_22,ARGB(255,240,206),ARGB(1,1,1,1),Core::Rectangle(-78,36,-78+50,36+16),buff,Unit::kAlignCenterMiddle);

				ui_render->SetWorld(oldworld);
			}
		}
	}
}

bool InGameUINew::IsCharacterVisible(by_ptr(Character) c,int &x, int &y)
{
	Matrix44 View,Proj,ViewProj;

	by_ptr(Pose) pose = c->GetPose();

	if(!pose)
		return false;
	by_ptr(Skeleton) skel = pose->GetSkeleton();

	if(!skel)
		return false;

	int bond_id = skel->GetJointId("ui");
	Vector3 c_pos;

	if(bond_id > 0)
	{
		c_pos = c->GetPosition() + c->GetPose()->GetJointModelPose(bond_id).position * c->GetRotation() * Quaternion(Vector3(0, 1, 0), PI);
	}
	else
		return false;

	Vector3 rt_size = gGame->guiSys->GetSize();
	Vector3 pos = c_pos;

	Vector3 position = gGame->camera->position;

	Vector3 direction = Normalize(pos - position);

	gGame->camera->CalculateViewProjectionMatrix(View, Proj);
	ViewProj = View * Proj;

	TransformCoord(pos, pos, ViewProj); 

	x = rt_size.x / 2.0f + rt_size.x / 2.0f * pos.x;
	y = rt_size.y / 2.0f - rt_size.y / 2.0f * pos.y;

	if( pos.z > 1.0f || x < 0 || y < 0 || x > rt_size.x || y > rt_size.y )
		return false;

	if (!isshowblood)
	{
		NxRay ray;
		ray.orig = (const NxVec3 &)position;
		ray.dir = (const NxVec3 &)direction;

		NxRaycastHit hit;
		uint group_id = 0;
		group_id |= 1 << PhysxSystem::kStatic;
		group_id |= 1 << PhysxSystem::kStaticRaycast;
		group_id |= 1 << PhysxSystem::kGroupVehicle;
		for (uint i = 0; i < 2; ++i)
			group_id |= 1 << (PhysxSystem::kGroupStart + i);

		NxShape* shape = gPhysxScene->raycastClosestShape(ray, NX_ALL_SHAPES, hit, group_id, 500);
		if (shape)
		{
			NxActor& actor = shape->getActor();
			tempc_ptr(Character) p = Character::FromNxActor(actor);
			if (p && p == c)
				return true;
		}
	}
	else
		return true;
	return false;
}

bool InGameUINew::IsGunTower_DummyVisible(by_ptr(DummyObject) tower, int &x, int &y)
{
	Matrix44 View,Proj,ViewProj;
	Vector3 c_pos;
	
	tower->GetDummyJointInfo("Gun_RV", &c_pos, NULL);

	Vector3 rt_size = gGame->guiSys->GetSize();
	Vector3 pos = c_pos + Vector3(0.f, 0.3f, 0.f);
	
	Vector3 position = gGame->camera->position;

	Vector3 direction = Normalize(pos - position);

	gGame->camera->CalculateViewProjectionMatrix(View, Proj);
	ViewProj = View * Proj;

	TransformCoord(pos, pos, ViewProj); 
	x = rt_size.x / 2.0f + rt_size.x / 2.0f * pos.x;
	y = rt_size.y / 2.0f - rt_size.y / 2.0f * pos.y;

	if( pos.z > 1.0f || x < 0 || y < 0 || x > rt_size.x || y > rt_size.y )
		return false;

	NxRay ray;
	ray.orig = (const NxVec3 &)position;
	ray.dir = (const NxVec3 &)direction;

	NxRaycastHit hit;
	uint group_id = 0;
	group_id |= 1 << PhysxSystem::kStatic;
	group_id |= 1 << PhysxSystem::kStaticRaycast;
	group_id |= 1 << PhysxSystem::kGroupVehicle;
	for (uint i = 0; i < 2; ++i)
		group_id |= 1 << (PhysxSystem::kGroupStart + i);

	NxShape* shape = gPhysxScene->raycastClosestShape(ray, NX_ALL_SHAPES, hit, group_id, 500);
	if (shape)
	{
		NxActor& actor = shape->getActor();
		tempc_ptr(DummyObject) p = DummyObject::FromNxActor(actor);
		if (p && p == tower)
			return true;
	}
	return false;
}

bool InGameUINew::GetGunTower_Dummy_Hp_Position(by_ptr(DummyObject) tower, int &x, int &y)
{
	Matrix44 View,Proj,ViewProj;
	Vector3 c_pos;

	tower->GetDummyJointInfo("Gun_XT", &c_pos, NULL);

	Vector3 rt_size = gGame->guiSys->GetSize();
	Vector3 pos = c_pos;// + Vector3(0.f, 1.5, 0.f);

	gGame->camera->CalculateViewProjectionMatrix(View, Proj);
	ViewProj = View * Proj;

	TransformCoord(pos, pos, ViewProj); 
	x = rt_size.x / 2.0f + rt_size.x / 2.0f * pos.x;
	y = rt_size.y / 2.0f - rt_size.y / 2.0f * pos.y;

	if( pos.z > 1.0f || x < 0 || y < 0 || x > rt_size.x || y > rt_size.y )
		return false;

	return true;
}

bool InGameUINew::IsCharacterVisibleBySniper(by_ptr(Character) c,int &x, int &y, bool &isAim)
{
	Matrix44 View,Proj,ViewProj;

	by_ptr(Pose) pose = c->GetPose();

	if(!pose)
		return false;
	by_ptr(Skeleton) skel = pose->GetSkeleton();

	if(!skel)
		return false;

	int bond_id = skel->GetJointId("torso");
	Vector3 c_pos;

	if(bond_id > 0)
	{
		c_pos = c->GetPosition() + c->GetPose()->GetJointModelPose(bond_id).position * c->GetRotation() * Quaternion(Vector3(0, 1, 0), PI);
	}
	else
		return false;

	Vector3 rt_size = gGame->guiSys->GetSize();
	Vector3 pos = c_pos;

	Vector3 position = gGame->camera->position;

	Vector3 direction = Normalize(pos - position);

	gGame->camera->CalculateViewProjectionMatrix(View, Proj);
	ViewProj = View * Proj;

	TransformCoord(pos, pos, ViewProj); 
	
	float aspect = rt_size.x / rt_size.y;
	
	pos.y /= aspect;

	x = rt_size.x / 2.0f + rt_size.x / 2.0f * pos.x;
	y = rt_size.y / 2.0f - rt_size.y / 2.0f * pos.y;

	if( pos.z > 1.0f || x < 0 || y < 0 || x > rt_size.x || y > rt_size.y )
		return false;

	bool isShow = false;
	NxRay ray;
	ray.orig = (const NxVec3 &)position;
	ray.dir = (const NxVec3 &)direction;

	NxRaycastHit hit;
	uint group_id = 0;
	group_id |= 1 << PhysxSystem::kStatic;
	group_id |= 1 << PhysxSystem::kStaticRaycast;
	group_id |= 1 << PhysxSystem::kGroupVehicle;
	for (uint i = 0; i < 2; ++i)
		group_id |= 1 << (PhysxSystem::kGroupStart + i);

	NxShape* shape = gPhysxScene->raycastClosestShape(ray, NX_ALL_SHAPES, hit, group_id, 500);
	if (shape)
	{
		NxActor& actor = shape->getActor();
		tempc_ptr(Character) p = Character::FromNxActor(actor);
		if (p && p == c)
			isShow = true;
	}

	if(!isShow)
		return false;
	else
	{
		NxRay ray;
		
		ray.dir = (const NxVec3 &)Core::Normalize(Core::Vector3(0, 0, -1) * gGame->camera->rotation);
		ray.orig = (const NxVec3 &)(gGame->camera->position);

		NxRaycastHit hit;
		uint group_id = 0;
		uint group_offset = c->GetTeam() == 0 ? 0 : 1;
		
		group_id |= 1 << (PhysxSystem::kGroupStart + group_offset);

		NxShape* shape = gPhysxScene->raycastClosestShape(ray, NX_ALL_SHAPES, hit, group_id, 1000);
		if (shape)
		{
			NxActor& actor = shape->getActor();
			tempc_ptr(Character) p = Character::FromNxActor(actor);
			if (p && p == c)
			{
				isAim = true;
				return true;
			}
		}
		isAim = false;
		return true;
	}

	return false;
}

void InGameUINew::AddBloodEffectData(float time, int type, Core::Vector2 pos, int adddata)
{
	if (adddata != 0)
	{
		AddBloodEffectInfo datainfo;
		datainfo.data = adddata;
		datainfo.position = pos;
		datainfo.time = time;
		datainfo.type = type;
		array_addbloodeffect_info.PushBack(datainfo);
	}
}

void InGameUINew::CloseChat()
{
	inGameUI_textInput->Clear();
	SetInputFocus(false);
	gLevel->isselectperson = false;
}

void InGameUINew::_DrawAllTeamMemberName(by_ptr(UIRender) ui_render)
{
	tempc_ptr(Character) viewer = gLevel->GetViewer();
	Matrix44 old_world,world;
	if(!viewer)
		return;
	ui_render->BeginInGameUI();
	const Core::Array<sharedc_ptr(Character)>& characters = gLevel->GetCharacters();

	int x, y;

	world = ui_render->GetWorld();
	old_world = world;

	for(uint i = 0 ; i < characters.Size() ; i++)
	{
		if(characters[i] && characters[i] != viewer)
		{
			if(characters[i]->GetTeam() == viewer->GetTeam())// || characters[i]->is_display_damage_hp)
			{
				if(IsCharacterVisible(characters[i],x,y))
				{
					world.SetTranslationXYZ(x,y,0);
					ui_render->SetWorld(world);

					if(viewer->is_display_friend_name)
					{
						F32 len = Length(gGame->camera->position - CalcNewPosition(gGame->camera->position, characters[i]->GetTorsoPosition()));

						F32 v = gDx9Device->convergence > 0 ? gDx9Device->convergence : 1;
						if (gDx9Device->GetStereoEnable() &&  len> 0)
							v = len;

						gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_CONVERGENCE, &v, 1);

						//draw progress
						if (characters[i]->hp > 0)
						{
							int blood_x = -92;
							int blood_y = -48;
							
							ui_render->DrawString(ui_render->font_simhei_16,ARGB(15,230,15),ARGB(1,1,1,1),Core::Rectangle(blood_x,blood_y-10,blood_x+180,blood_y+10),characters[i]->GetName(),Unit::kAlignCenterBottom);

							if (viewer->GetWeapon() && viewer->GetWeapon()->GetWeaponType() == kWeaponTypeCureGun)
							{
								int temp_hp = (int)characters[i]->hp;
								temp_hp = temp_hp > 9999 ? 9999 : temp_hp;
								Core::String str_hp = Core::String::Format("hp:%d",temp_hp);
								ui_render->DrawString(ui_render->font_simhei_16,ARGB(15,230,15),ARGB(1,1,1,1),Core::Rectangle(blood_x,blood_y-30,blood_x+180,blood_y-10),str_hp,Unit::kAlignCenterBottom);
							}

							float progress = Core::Clamp((float)characters[i]->hp / (float)characters[i]->max_hp, 0, 1);
							ui_render->DrawTextureWindow(Core::Vector2(blood_x, blood_y), 200, 54, ui_common_hp_friend_bg,Core::Rectangle(0,0,1,1),Core::ARGB(255,255,255,255));

							uint career_id = characters[i]->GetCurCharinfo()->career_id;
							tempc_ptr(Texture2D) head_texture = ui_common_hp_headicon.Get(career_id, NullPtr);
							ui_render->DrawTextureWindow(Core::Vector2(blood_x+6, blood_y+4), 44, 44, head_texture,Core::Rectangle(0,0,1,1),Core::ARGB(255,255,255,255));
							String file_name;
							if(characters[i]->is_vip == 7)
							{
								file_name = String::Format("IngameUI/vip7_crown.dds");
								sharedc_ptr(Texture2D) texture = RESOURCE_LOAD_NEW(file_name.Str(), true, Texture2D);
								ui_render->DrawTextureWindow(Core::Vector2(blood_x+6-25,blood_y+4), 44, 44, texture,Core::Rectangle(0,0,1,1),Core::ARGB(255,255,255,255));
							}
							else if(characters[i]->is_vip >= 8)
							{
								file_name = String::Format("IngameUI/vip8_crown.dds");
								sharedc_ptr(Texture2D) texture = RESOURCE_LOAD_NEW(file_name.Str(), true, Texture2D);
								ui_render->DrawTextureWindow(Core::Vector2(blood_x+6-25,blood_y+4), 44, 44, texture,Core::Rectangle(0,0,1,1),Core::ARGB(255,255,255,255));
							}

							if (progress > 0.6f)
							{
								ui_render->SetTexture(ui_common_hp[0]);
							}
							else if (progress > 0.3f)
							{
								ui_render->SetTexture(ui_common_hp[1]);
							}
							else
							{
								ui_render->SetTexture(ui_common_hp[2]);
							}
							ui_render->DrawWindow(Core::Rectangle(blood_x+43, blood_y+21, blood_x+51+96*progress, blood_y+21+14), Core::Rectangle(3,5,3,6),Core::Rectangle(3.0f / 32.f, 5.f / 16.f, 3.0f / 32.f, 6.f / 16.f));
						}

						if (gDx9Device->GetStereoEnable())
							v = gDx9Device->convergence > 0 ? gDx9Device->convergence : 1;

						gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_CONVERGENCE, &v, 1);
					}
				}
			}
		}
	}
	ui_render->SetWorld(old_world);
}

Core::Vector2 InGameUINew::GetTextSize(tempc_ptr(Font) font, Core::String str)
{
	Core::Vector2 xy;
	Core::Rectangle &rect = (Core::Rectangle &)font->MeasureString(Core::Rectangle(0,0,0,0),str);

	xy.x = rect.Max.x;
	xy.y = rect.Max.y;

	return xy;
}
// draw player hit
void InGameUINew::Draw(by_ptr(UIRender) ui_render)
{
	Vector2 rt_size2 = ui_render->GetVirtualViewport().GetExtent();
	PROFILE("InGameUI::Draw");
	Core::Vector3 rt_size = gGame->guiSys->GetSize();
	current_screen_width_level = rt_size.x / 1600.0f;
	current_screen_height_level = rt_size.y / 1200.0f;

	
	{
		tempc_ptr(Character) viewer = gGame->level->GetViewer();
		if(viewer && viewer->GetViewMode() == Character::kFirstPerson)
		{
			_DrawCrossHair(ui_render);
		}

	}
	

	if (gLevel->game_type != RoomOption::kNovice)
	{
		//��ǹ��UI
		_DrawGunTower_Dummy(ui_render);
		//��׼����ת �̶ȶ�̬�仯
		_Draw_Picture_Move_uv(ui_render);

		_DrawHeadInfo(ui_render);

		if (gLevel->game_type != RoomOption::kTDMode && gLevel->game_type != RoomOption::kEditMode)
			_DrawKillList(ui_render);
		
		
		_DrawSmallMapBG(ui_render);
		_DrawControlTip(ui_render);

		Matrix44 world;
		world.SetTranslationXYZ(-(rt_size.x/2),-(rt_size.y/2),0);
		ui_render->SetWorld(world);
		_DrawWeaponTip(ui_render, gLevel->GetViewer());
	}

	//////////////////////////////////////////////////////////////////////////////////////////

	Matrix44 view;
	Matrix44 world;
	rt_size = gGame->guiSys->GetSize();
	view.SetScaleXYZ(2.0f / rt_size.x, -2.0f / rt_size.y, 0.0f);
	view.TranslateXYZ(-1.0f, 1.0f, 0.0f);
	view.TranslateLocalXYZ(-0.5f, -0.5f, 0.0f);
	ui_render->SetWorld(Core::Matrix44::kIdentity);
	ui_render->SetView(view);

	Game * game = gGame;
	tempc_ptr(Character) viewer = game->level->GetViewer();
	by_ptr(Character) player = gLevel->GetPlayer();
	tempc_ptr(Character) inVisible_player;
	tempc_ptr(Character) zibao_player;
	if(player->invisible_uid != 0)
	{
		inVisible_player = gLevel->GetCharacter(player->invisible_uid);
	}
	if(player->zibao_uid != 0)
	{
		zibao_player = gLevel->GetCharacter(player->zibao_uid);
	}
	

	_DrawHorn(ui_render);

	if (gLevel->game_type == RoomOption::kHoldPoint)
	{
		_DrawHoldPostionInfo(ui_render);
	}
	else if (gLevel->game_type == RoomOption::kPushVehicle)
	{
		_DrawVehicleInfo(ui_render);
	}
	else if (gLevel->game_type == RoomOption::kNovice && gLevel->novice_index == 20)
	{
		_DrawVehicleInfo(ui_render);
	}
	else if (gLevel->game_type == RoomOption::kBombMode)
	{
		_DrawBombBottomInfo(ui_render);
		_DrawbombMap(ui_render);
		_DrawBomb_count_down(ui_render);
		_DrawBomb_Tips(ui_render);
		_Play_PlantedTimer_sound();
	}
	else if (gLevel->game_type == RoomOption::kZombieMode)
	{
		_DrawZombieInfo(ui_render);
	}
	else if (gLevel->game_type == RoomOption::kBossPVE)
	{
		_DrawBOSS2BottomInfo(ui_render);
	}
	else if (gLevel->game_type == RoomOption::kCommonZombieMode)
	{
		_DrawCommonZombieBottomInfo(ui_render);
		_DrawCommonZombieSkill(ui_render);
	}
	else if (gLevel->game_type == RoomOption::kBossMode2)
	{
		if (player && player->GetTeam() == 1)
		{
			_DrawBossMode2_BottomInfo(ui_render);
		}
		else
		{
			_DrawBossMode2_Bottom_Person_Info(ui_render);
			_DrawBottom_String(ui_render);
		}
	}
	else if (gLevel->game_type == RoomOption::kItemMode)
	{
		_DrawItemModeBottomInfo(ui_render);
		DrawItemModeZiBao(ui_render);
		if (inVisible_player)
		{
			if (inVisible_player->IsAttributeExist(kEffect_Special_Invisible))
			{
				inVisible_player->is_invisible = true;
			}
			if (!inVisible_player->IsAttributeExist(kEffect_Special_Invisible) && inVisible_player->is_invisible == true)
			{
				inVisible_player->is_invisible = false;
				player->invisible_uid = 0;	
				inVisible_player->PlayItemModeParticle("cell03_disappear",10.f);
				inVisible_player = NullPtr;
				Core::String str = Core::String::Format("bj/player/2d/bio/bioshadow_cloakoff");
				FmodSystem::PlayEvent(str.Str());
			}
		}

		if (zibao_player)
		{
			if (!zibao_player->itemmode_zibao)
			{
				player->zibao_uid = 0;
			}
			else
			{
				if ((int)(zibao_player->itemmode_zibao_timer*4)%2 == 1)
				{
					String file_name = String::Format("UI_Item_Skill/ig_itemmode_skill_ico_4.mesh");
					LogSystem.WriteLinef("%s", file_name.Str());
					zibao_player->GetThirdPerson().item_mode_head = ptr_new StaticMesh(MESH_KEY_PROP);
					zibao_player->GetThirdPerson().item_mode_head->AddPrimitive(file_name,0);
					zibao_player->ShowItemModeHead(0.1f);
				}
			}
		}
	}
	
	else if(gLevel->game_type == RoomOption::KMoonMode)
	{
		_DrawMoonModeBottomInfo(ui_render);
	}
	else if(gLevel->game_type == RoomOption::kAdvenceMode)
	{
		_DrawAdvenceModeBottomInfo(ui_render);
	}	
	else if (gLevel->game_type == RoomOption::kSurvivalMode)
	{
		if ( player->isghost == true )
		{
			_DrawGhostModBottomInfo(ui_render);
			_DrawGhostQuantityBottmInfo(ui_render);
			_DrawLivePromptBottmInfo(ui_render);
			_DrawSurvivalQuantityBottmInfo(ui_render);
			_DrawTrapQuantityBottmInfo(ui_render);
			gLevel->audio_Survival1_background->stop(true);
			gLevel->GetPlayer()->boss_2D_survival->stop();
			
			
		}
        else
		{
			_DrawSurvivalModBottomInfo(ui_render);
			_DrawQuantityBottmInfo(ui_render);
			_InitInvincible(ui_render);
			_DrawLivePromptBottmInfo(ui_render);
			_InitInvincible(ui_render);
			_InitHarmBottmInfo(ui_render);
			_DrawTrapQuantityBottmInfo(ui_render);
			_DrawSurvivalQuantityBottmInfo(ui_render);
		}
	}

	

	_DrawBottomInfo(ui_render);
	_DrawTDmode(ui_render);
	_DrawEditMode(ui_render);
	_DrawKillIcon(ui_render);
	_DrawDeadUi(ui_render);
	_DrawScoreAnimation(ui_render);
	_DrawWeaponList(ui_render);
	_DrawTargetEnemy(ui_render);
	
	_DrawAddBloodEffect(ui_render);
	_DrawAddBloodTip(ui_render);
	// draw radio
	DrawRadio(ui_render,world);

	_DrawMiddle_String(ui_render);
	_DrawMiddleUP_String(ui_render);

	if(gGame->channel_connection && gGame->channel_connection->GetState() == ChannelConnection::kInReplay)
	{
		_DrawPlayRecordUI(ui_render);
	}
	view.SetScaleXYZ(2.0f / rt_size.x, -2.0f / rt_size.y, 0);
	view.TranslateXYZ(-1, 1, 0);
	view.TranslateLocalXYZ(-0.5f, -0.5f, 0);

	ui_render->SetWorld(Matrix44::kIdentity);
	ui_render->SetView(view);
	ui_render->SetProjection(Matrix44::kIdentity);

	tempc_ptr(WeaponBase) weapon;
	if (viewer)
		weapon = viewer->GetWeapon();

	if (isshowblood)
	{
		_DrawAllTeamMemberName(ui_render);
	}

	if (Special_time >= 0)
		Special_time -= Task::GetFrameTime();

	if(gLevel->game_type == RoomOption::kStreetBoyMode && viewer)
	{
		{
			byte id = gLevel->current_street_king_uid[0];
			Vector3 head_pos;
			Quaternion head_rot;

			if(id != 0)
			{
				tempc_ptr(Character) c =  gLevel->GetCharacter(id);
				if(c && c != viewer)
				{
					c->GetThirdPerson().GetJointInfo("hat", head_pos, head_rot);
					Draw2DOjbect(ui_render, ui_king_king_r, head_pos);
				}
			}
		}

		{
			byte id = gLevel->current_street_king_uid[1];
			Vector3 head_pos;
			Quaternion head_rot;

			if(id != 0)
			{
				tempc_ptr(Character) c =  gLevel->GetCharacter(id);
				if(c && c != viewer)
				{
					c->GetThirdPerson().GetJointInfo("hat", head_pos, head_rot);
					Draw2DOjbect(ui_render, ui_king_king_b, head_pos);
				}
			}
		}

	}
	else if(gLevel->game_type == RoomOption::kBombMode)
	{
		if(viewer && viewer->GetTeam() == 1)
		{
			if(gLevel->bomb_on_ground)
			{
				Draw2DOjbect(ui_render, ui_bomb_length, gLevel->bomb_on_ground_position);
			}
			else if(gLevel->bomb_droped)
			{
				Vector3 p;
				if(gLevel->pickup_manager->GetPickUpPosition(gLevel->bomb_droped_id,PickUpManager::kPickUpWeapon, p))
				{
					Draw2DOjbect(ui_render, ui_bomb_length, p);
				}
			}
			else
			{
				const Core::Array<sharedc_ptr(Character)>& characters = gLevel->GetCharacters();

				for (uint i = 0; i < characters.Size(); i++)
				{
					tempc_ptr(Character) c = characters[i];
					if (c && !c->IsDied())
					{
						if (c->GetTeam() == 1 && c->HasBomb() && viewer && c->GetTeam() == viewer->GetTeam())
						{
							Vector3 head_pos;
							Quaternion head_rot;
							c->GetThirdPerson().GetJointInfo("hat", head_pos, head_rot);
							Draw2DOjbect(ui_render, ui_bomb_length, head_pos);
							break;
						}
					}
				}
			}
		}
	}
	else if (gLevel->game_type == RoomOption::kZombieMode)
	{
		const Core::Array<sharedc_ptr(Character)>& characters = gLevel->GetCharacters();
		for (uint i = 0; i < characters.Size(); i++)
		{
			tempc_ptr(Character) c = characters[i];
			Vector3 head_pos;
			Quaternion head_rot;
			if (c && !c->IsDied() && c != viewer)
			{
				if(c->GetTeam() == 0)
				{
					c->GetThirdPerson().GetJointInfo("hat", head_pos, head_rot);
					Draw2DOjbect(ui_render, ui_king_king_r, head_pos);
				}
			}		
		}
		
	}
	else if (gLevel->game_type == RoomOption::kCommonZombieMode)
	{
		for (uint rank = 0; rank < game->scores->teams[1].Size(); rank ++)
		{
			Character * c = game->scores->teams[1][rank];
			if (c && viewer != c && c->character_info && c->character_info->career_id == DEFAULT_COMMONZOMBIE_KING && c->common_zombie_dying_flag)
			{				
				if (c->commonzombie_dying_totletime > 0)
				{
					float bomb_time = c->commonzombie_dying_time/c->commonzombie_dying_totletime;
					Draw2DCommonzombie_Ojbect(ui_render, c->GetPosition(),Core::Rectangle(0,0,bomb_time,1));
				}
			}
		}
	}
	else if (gLevel->game_type == RoomOption::kBossMode2)
	{
		for (uint rank = 0; rank < game->scores->teams[1].Size(); rank ++)
		{
			Character * c = game->scores->teams[1][rank];
			Vector3 head_pos;
			Quaternion head_rot;

			if(c && !c->IsDied() && c != viewer)
			{
				c->GetThirdPerson().GetJointInfo("hat", head_pos, head_rot);
				Draw2DOjbect(ui_render, ui_king_king_b, head_pos);
			}
		}
	}
	//else if (gLevel->game_type == RoomOption::kItemMode && viewer)
	//{
	//	Vector3 head_pos;
	//	Quaternion head_rot;
	//	const Core::Array<sharedc_ptr(Character)>& characters = gLevel->GetCharacters();

	//	for (uint i = 0; i < characters.Size(); i++)
	//	{
	//		tempc_ptr(Character) c = characters[i];
	//		if (c && !c->IsDied())
	//		{
	//			if (c->itemmode_item_slot>=0)
	//			{
	//				Vector3 head_pos;
	//				Quaternion head_rot;
	//				c->GetThirdPerson().GetJointInfo("hat", head_pos, head_rot);
	//				Draw2DOjbect(ui_render, ui_itemmode_Skill_head[c->itemmode_item_slot], head_pos);
	//			}
	//		}
	//	}
	//}
	

	_DrawSniperTargetHelper(ui_render);

	ARGB font_color = ARGB(251, 245, 231);
	ARGB bg_color = ARGB(0, 0, 0, 0);
	ARGB name_colors[] = { ARGB(255, 101, 74),ARGB(128, 215, 255) , ARGB(255,128,128,128)};

	Core::CStrBuf<256> buff;

	// draw kill icon queue
	Core::Matrix44 oldworld;
	oldworld = ui_render->GetWorld();

	world.SetTranslationXYZ(rt_size.x / 2.0f, 0, 0);
	ui_render->SetWorld(world);

	//��Ϸ�Ϸ���������ʾ
	//if(speaker_msg_flag)
	//{
	//	CStrBuf<256> speaker_tip;

	//	speaker_tip.format("%s",current_speaker_info.Str() + 10 );

	//	ui_render->SetTexture(speaker_texture_background);

	//	ui_render->DrawRectangle(Core::Rectangle(-230,40+90,230,160+90),Core::Rectangle(0,0,1,1));

	//	ui_render->SetTexture(speaker_texture);
	//	ui_render->DrawRectangle(Core::Rectangle(-210,40+90,-210 + 36, 40 + 36+90),Core::Rectangle(0,0,1,1));

	//	String temp_str = speaker_tip;

	//	SplitString(temp_str,temp_str,Core::Rectangle(0,0+90,380,100+90), ui_render->font_simhei_16);
	//	ui_render->DrawString(ui_render->font_simhei_16,Core::ARGB(255, 252, 239, 3),bg_color,Core::Rectangle(-170,50+90,210,150+90),temp_str,Unit::kAlignLeftTop);		
	//}

	ui_render->SetWorld(oldworld);

	// draw team hurt ui
	if(gLevel->team_hurt)
	{
		Matrix44 old_world = ui_render->GetWorld();
		world.SetTranslationXYZ(rt_size.x / 2.0f, rt_size.y / 2.0f - 100, 0);

		ui_render->SetTexture(NullPtr);

		Core::Rectangle rect;

		if(viewer && viewer->is_team_hurt_part)
		{
			float tratio = viewer->team_hurt_part_time / 0.5f;

			float tsize = 0.5f * tratio;

			rect = ui_render->font_simhei_28->MeasureString(Core::Rectangle(0,0,0,0),gLang->GetTextW(L"�����ڹ������ѣ�"));

			world._11 = 0.5f * tratio + 1.0f;
			world._22 = 0.5f * tratio + 1.0f;

			ui_render->SetWorld(world);				

			ui_render->DrawStringShadow(ui_render->font_simhei_28,ARGB(197,78,22),Core::ARGB(255,0,0,0),Core::ARGB(0,0,0,0),Core::Rectangle(-rect.Max.x / 2 - tsize,-rect.Max.y / 2 - tsize,rect.Max.x / 2 + tsize,rect.Max.y / 2 + tsize),gLang->GetTextW(L"�����ڹ������ѣ�"),Unit::kAlignCenterMiddle);
		}
		if(viewer && viewer->is_team_hurt_dead)
		{
			float tratio = viewer->team_hurt_dead_time / 0.5f;

			float tsize = 0.5f * tratio;

			rect = ui_render->font_simhei_28->MeasureString(Core::Rectangle(0,0,0,0),gLang->GetTextW(L"��ɱ���˶��ѣ�"));

			world._11 = 0.5f * tratio + 1.0f;
			world._22 = 0.5f * tratio + 1.0f;

			ui_render->SetWorld(world);

			ui_render->DrawStringShadow(ui_render->font_simhei_28,ARGB(197,78,22),Core::ARGB(255,0,0,0),Core::ARGB(0,0,0,0),Core::Rectangle(-rect.Max.x / 2 - tsize,-rect.Max.y / 2 - tsize,rect.Max.x / 2 + tsize,rect.Max.y / 2 + tsize),gLang->GetTextW(L"��ɱ���˶��ѣ�"),Unit::kAlignCenterMiddle);
		}

		world = old_world;
		ui_render->SetWorld(world);
	}

	// draw team request ui
	if(viewer && (viewer->team_request_waittime > 0.0f || viewer->team_success_join_time > 0.0f || viewer->team_refuse_time > 0.0f))
	{
		Matrix44 old_world = ui_render->GetWorld();
		world.SetTranslationXYZ(rt_size.x / 2.0f, rt_size.y - 150, 0);

		ui_render->SetWorld(world);

		ui_render->SetTexture(team_request_dialog_texture);
		ui_render->DrawWindow(Core::Rectangle(-150,0,150,90),Core::Rectangle(10,10,20,15),Core::Rectangle(0.3125f,0.1086f,0.625f,0.163f));

		if(viewer->team_request_waittime > 0.0f)
		{
			ui_render->SetTexture(team_request_bg_texture);
			ui_render->DrawWindow(Core::Rectangle(-100,40,100, 40 + 5),Core::Rectangle(2,2,2,2),Core::Rectangle(0.0625f,0.4f,0.0625f,0.4f));

			ui_render->SetTexture(team_request_bar_Texture);
			ui_render->DrawWindow(Core::Rectangle(-100,40,-100 + 200 * ( (10.0f - viewer->team_request_waittime) / 10.0f),40 + 5),Core::Rectangle(2,2,2,2),Core::Rectangle(0.0625f,0.4f,0.0625f,0.4f));	

			CStrBuf<256> str;

			str.format(gLang->GetTextW(L"%s����������������"),viewer->team_request_username);
			ui_render->DrawStringShadow(ui_render->font_simhei_16,Core::ARGB(255,255,255,255),Core::ARGB(255,0,0,0),Core::ARGB(0,0,0,0),Core::Rectangle(-200,10,200,30),str.buff(),Unit::kAlignCenterTop);
			ui_render->DrawStringShadow(ui_render->font_simhei_16,Core::ARGB(255,255,255,255),Core::ARGB(255,0,0,0),Core::ARGB(0,0,0,0),Core::Rectangle(-200,58,200,30),gLang->GetTextW(L"[F9]����      [F10]�ܾ�"),Unit::kAlignCenterTop);
		}
		if(viewer->team_refuse_time > 0.0f)
		{
			CStrBuf<256> str;

			str.format(gLang->GetTextW(L"���ܾ���%s����ӵ�����!"),viewer->team_request_username);
			ui_render->DrawStringShadow(ui_render->font_simhei_16,Core::ARGB(255,255,255,255),Core::ARGB(255,0,0,0),Core::ARGB(0,0,0,0),Core::Rectangle(-200,30,200,30),str.buff(),Unit::kAlignCenterTop);
		}
		if(viewer->team_success_join_time > 0.0f)
		{
			CStrBuf<256> str;

			str.format(gLang->GetTextW(L"���ѳɹ�����%s��С��!"),viewer->team_request_username);
			ui_render->DrawStringShadow(ui_render->font_simhei_16,Core::ARGB(255,255,255,255),Core::ARGB(255,0,0,0),Core::ARGB(0,0,0,0),Core::Rectangle(-200,30,200,30),str.buff(),Unit::kAlignCenterTop);
		}

		world = old_world;
		ui_render->SetWorld(world);
	}

	//draw chat
	if (1)
	{
		world.SetTranslationXYZ(6, rt_size.y - 300, 0);
		ui_render->SetWorld(world);

		int msgcount = fiveMsgs.GetCount();
		for(int i = 0; i < msgcount; i ++)
		{
			buff.format("%s", fiveMsgs[i]);
			LogSystem.Writef("buff = %s", buff);
			if( ((Core::String)fiveMsgs[i]).RefStr().startwith(gLang->GetTextW(L"�����").Str()))
				ui_render->DrawStringShadow(ui_render->font_simhei_16, Msgs_Color[i], ARGB(0,0,0), bg_color, Core::Rectangle(0, 0, 0, 60 - 25 * (msgcount - i)), buff, Unit::kAlignLeftBottom);
			else if(((Core::String)fiveMsgs[i]).RefStr().startwith(gLang->GetTextW(L"��ϵͳ��").Str()))
				ui_render->DrawStringShadow(ui_render->font_simhei_16, ARGB(255, 218, 0, 6), ARGB(0,0,0), bg_color, Core::Rectangle(0, 0, 0, 60 - 25 * (msgcount - i)), buff, Unit::kAlignLeftBottom);
			else if(((Core::String)fiveMsgs[i]).RefStr().startwith(gLang->GetTextW(L"����Ϣ��").Str()))
				ui_render->DrawStringShadow(ui_render->font_simhei_16, ARGB(255, 183, 171, 165), ARGB(0,0,0), bg_color, Core::Rectangle(0, 0, 0, 60 - 25 * (msgcount - i)), buff, Unit::kAlignLeftBottom);
			else if(((Core::String)fiveMsgs[i]).RefStr().startwith(gLang->GetTextW(L"����ӡ�").Str()))
				ui_render->DrawStringShadow(ui_render->font_simhei_16, 0xFFFBA176, ARGB(0,0,0), bg_color, Core::Rectangle(0, 0, 0, 60 - 25 * (msgcount - i)), buff, Unit::kAlignLeftBottom);
			else if(((Core::String)fiveMsgs[i]).RefStr().startwith(gLang->GetTextW(L"��ս�ӡ�").Str()))
				ui_render->DrawStringShadow(ui_render->font_simhei_16, 0xFF829BAD, ARGB(0,0,0), bg_color, Core::Rectangle(0, 0, 0, 60 - 25 * (msgcount - i)), buff, Unit::kAlignLeftBottom);
			else if(((Core::String)fiveMsgs[i]).RefStr().startwith(gLang->GetTextW(L"�����ȡ�").Str()) && viewer)
			{
				ui_render->SetTexture(speaker_anim[speaker_current_list[i]].texture);
				float offsety = 60 - 25 * (msgcount - i);

				float scale;
				speaker_anim[speaker_current_list[i]].scale_spline.Interpolation(viewer->speaker_tip_time[speaker_current_list[i]], scale);

				scale = -5 * (scale - 1.0f);

				buff.format("%s", fiveMsgs[i].Str() + 10);
				ui_render->DrawStringShadow(ui_render->font_simhei_16, ARGB(255, 252, 239, 3), ARGB(0,0,0), bg_color, Core::Rectangle(50, 0, 0, 60 - 25 * (msgcount - i)), buff, Unit::kAlignLeftBottom);
				ui_render->DrawRectangle(Core::Rectangle(0 - scale, offsety - 26 - scale, 26 + scale,offsety + scale), Core::Rectangle(0,0,1,1));

			}
			else
			{
				//if(Msgs_Color[i] == ARGB(255, 252, 239, 3))
				ui_render->DrawStringShadow(ui_render->font_simhei_16, Msgs_Color[i],ARGB(0,0,0) , bg_color, Core::Rectangle(0, 0, 0, 60 - 25 * (msgcount - i)), buff, Unit::kAlignLeftBottom);
				//else
				//	ui_render->DrawStringShadow(font_normal, font_color,ARGB(0,0,0) , bg_color, Core::Rectangle(0, 0, 0, 100 - 25 * (msgcount - i)), buff, Unit::kAlignLeftBottom);
			}
		}

		if (info_tip.Size() > 0)
		{
			Core::String tip_str = info_tip.Front();
			Core::Rectangle rect = ui_render->font_simhei_16->MeasureString(Core::Rectangle(0, 0, 0, 0), tip_str, -1, 0);
			int length = rect.Max.x - rect.Min.x;
			length += 15;
			float p = 0;
			if (info_time < 0.5)
				p = info_time * 2;
			else if (info_time > 5.5)
				p = (6-info_time) * 2;
			else
				p = 1;

			ui_render->SetTexture(ui_window);
			ui_render->DrawRectangle(Core::Rectangle(-length + length*p, 125, 0 + length*p, 155), Core::Rectangle(0, 0, 1, 1));
			ui_render->DrawStringShadow(ui_render->font_simhei_16, ARGB(255, 254, 238, 205), ARGB(0,0,0) , bg_color, Core::Rectangle(-length + length*p, 125, 0 + length*p, 150), tip_str, Unit::kAlignLeftBottom);
		}
		else
			info_time = 0;

		if(bFoused)
		{
			ui_render->DrawFontWindow(Core::Vector2(0, 55), 49, 20, ui_render->font_simhei_14, Core::ARGB(255,255, 255, 255), ARGB(0, 0, 0, 0), gLang->GetTextW(L"����ǰ�� /c ��������"), Unit::kAlignLeftTop);
			ui_render->DrawFontWindow(Core::Vector2(180, 55), 49, 20, ui_render->font_simhei_14, Core::ARGB(255,55, 200, 255), ARGB(0, 0, 0, 0), gLang->GetTextW(L"�����ѡ� /t ��������"), Unit::kAlignLeftTop);
			ui_render->DrawFontWindow(Core::Vector2(360,55), 49, 20, ui_render->font_simhei_14, 0xFFF289E9, ARGB(0, 0, 0, 0), gLang->GetTextW(L"����� /s ����� ��������"), Unit::kAlignLeftTop);
			//ui_render->DrawFontWindow(Core::Vector2(595, 55), 49, 20, ui_render->font_simhei_14, 0xFFF289E9, ARGB(0, 0, 0, 0), gLang->GetTextW(L"����� /r ��������"), Unit::kAlignLeftTop);
			//ui_render->DrawFontWindow(Core::Vector2(275, 55), 49, 20, ui_render->font_simhei_14, Core::ARGB(255,255, 255, 0), ARGB(0, 0, 0, 0), gLang->GetTextW(L"/X С����"), Unit::kAlignLeftTop);
			//ui_render->DrawFontWindow(Core::Vector2(355, 55), 49, 20, ui_render->font_simhei_14, Core::ARGB(255,137, 137, 137), ARGB(0, 0, 0, 0), gLang->GetTextW(L"/D ������"), Unit::kAlignLeftTop);
			bool draw_cursor = (int)(Task::GetTotalTime() * 2) & 1;

			ui_render->SetTexture(NullPtr);
			ui_render->DrawRectangle(Core::Rectangle(-10, 80, rt_size.x, 120),Core::Rectangle(0,0,1,1),Core::ARGB(128,0,0,0));
			int offset = 0;
			switch (char_mode)
			{
			case 0:
				{
					Core::String str = Core::String::Format(gLang->GetTextW(L"[��ǰ] : "),m_chattoname);
					Core::Rectangle rect = ui_render->font_simhei_16->MeasureString(Core::Rectangle(0, 0, 0, 0), str, -1, 0);
					offset = rect.Max.x - rect.Min.x;
					ui_render->DrawString(ui_render->font_simhei_16,text_input_color,Core::ARGB(0,0,0,0),Core::Rectangle(8, 80, offset, 120),str,Unit::kAlignLeftMiddle);
				}
				break;
			case 3:
				{
					Core::String str = Core::String::Format(gLang->GetTextW(L"[����] : "),m_chattoname);
					Core::Rectangle rect = ui_render->font_simhei_16->MeasureString(Core::Rectangle(0, 0, 0, 0), str, -1, 0);
					offset = rect.Max.x - rect.Min.x;
					ui_render->DrawString(ui_render->font_simhei_16,text_input_color,Core::ARGB(0,0,0,0),Core::Rectangle(8, 80, offset, 120),str,Unit::kAlignLeftMiddle);
				}
				break;
			case 2:
				{
					Core::String str = Core::String::Format(gLang->GetTextW(L"[ս��] : "),m_chattoname);
					Core::Rectangle rect = ui_render->font_simhei_16->MeasureString(Core::Rectangle(0, 0, 0, 0), str, -1, 0);
					offset = rect.Max.x - rect.Min.x;
					ui_render->DrawString(ui_render->font_simhei_16,text_input_color,Core::ARGB(0,0,0,0),Core::Rectangle(8, 80, offset, 120),str,Unit::kAlignLeftMiddle);
				}
				break;
			case 4:
				{
					Core::String str = Core::String::Format(gLang->GetTextW(L"[���] %s :"),m_chattoname);
					Core::Rectangle rect = ui_render->font_simhei_16->MeasureString(Core::Rectangle(0, 0, 0, 0), str, -1, 0);
					offset = rect.Max.x - rect.Min.x;
					ui_render->DrawString(ui_render->font_simhei_16,text_input_color,Core::ARGB(0,0,0,0),Core::Rectangle(8, 80, offset, 120),str,Unit::kAlignLeftMiddle);
				}
				break;
			default:
				{
					Core::String str = Core::String::Format(gLang->GetTextW(L"[��ǰ] :"),m_chattoname);
					Core::Rectangle rect = ui_render->font_simhei_16->MeasureString(Core::Rectangle(0, 0, 0, 0), str, -1, 0);
					offset = rect.Max.x - rect.Min.x;
					ui_render->DrawString(ui_render->font_simhei_16,text_input_color,Core::ARGB(0,0,0,0),Core::Rectangle(8, 80, offset, 120),str,Unit::kAlignLeftMiddle);
				}
				break;
			}
			inGameUI_textInput->DrawInputText(ui_render, Core::Vector2(8+offset+6, 90), Core::Rectangle(10, 90, 100, 100), text_input_color, ARGB(255, 255, 255, 255), ARGB(128,0, 0, 255), draw_cursor, true, ui_render->font_simhei_16);
			Vector2 cursorPos;
			size_t strSize = inGameUI_textInput->GetCursorPosition();
			if (ui_render->font_simhei_16->CPtoX(inGameUI_textInput->GetTextBuffer()->Str(), strSize, cursorPos))
			{
				float fSreenY = ui_render->GetVirtualViewport().Max.y;
				ImeUi_SetCaretPosition(16 + cursorPos.x, fSreenY - 220);
			}
		}
	}

	// draw hit ui
	if (viewer)
	{
		Matrix44 old_world = ui_render->GetWorld();

		float totaltime = 0;
		ui_render->SetTexture(ui_hit_portrait);
		

		for (uint i = 0; i < viewer->hit_ui.Size(); i ++)
		{
			HitInfo & hit = viewer->hit_ui[i];

			if (hit.time > 0 )
			{
				Quaternion fix(Vector3(1, 0, 0), HALFPI);
				
				world.SetRotationQuaternion(fix * hit.dir * viewer->GetRotation().Conjugate() * fix.Conjugate() * Quaternion(Vector3(0, 0, 1), PI));
				world.TranslateXYZ(rt_size.x / 2, rt_size.y / 2, 0);

				ui_render->SetWorld(world);
		
				ui_render->DrawRectangle(Core::Rectangle(-80, -140, 80, -100), Core::Rectangle(0, 0, 1, 1), Core::Color4(1, 1, 1, hit.time));

				totaltime += hit.time;
			}
		}

		if (totaltime > 0)
		{
			ARGB color(totaltime * 128, 255, 255, 255);

			float t_speed = viewer->GetAcquiredAttributeByType(kEffect_Infect_MoveSpeed, true);

			world.SetIdentity();
			ui_render->SetWorld(world);
			if(viewer->sustainflame_time > 0) // ȼ��
			{
				ui_render->SetTexture(ui_textures[5]);
			}
			else if(viewer->poison_time > 0) // �ж�
			{
				ui_render->SetTexture(ui_textures[9]);
			}
			else if(t_speed > 0.1f && t_speed < 1.f) // ����
			{
				ui_render->SetTexture(ui_textures[11]);
			}
			else if(viewer->control_reverse_timer > 0.f) //��ת
			{
				ui_render->SetTexture(ui_textures[12]);
			}
			else
			{
				ui_render->SetTexture(ui_textures[0]);
			}
			ui_render->DrawWindow(Core::Rectangle(0, 0, rt_size.x, rt_size.y), Core::Rectangle(250, 250, 250, 250), Core::Rectangle(0.5f, 0.5f, 0.5f, 0.5f), color, color);
		}

		if (viewer->itemmode_zibao && viewer->itemmode_zibao_timer>0 && !viewer->is_item_boss)
		{
			ARGB color(viewer->itemmode_zibao_timer * 128, 255, 255, 255);
			world.SetIdentity();
			ui_render->SetWorld(world);
			ui_render->SetTexture(ui_textures[13]);
			ui_render->DrawWindow(Core::Rectangle(0, 0, rt_size.x, rt_size.y), Core::Rectangle(250, 250, 250, 250), Core::Rectangle(0.5f, 0.5f, 0.5f, 0.5f), color, color);
		}

		if (viewer && viewer->GetAcquiredAttributeByType(kEffect_Infect_MoveSpeed, true) > 1.f && !viewer->IsDied())
		{
			world.SetIdentity();
			ui_render->SetWorld(world);
			float theta = Core::Sin(Task::GetTotalTime()*8);
			theta = 0.75 + 0.25*theta;
			ui_render->SetTexture(ui_textures[10]);
			ui_render->DrawWindow(Core::Rectangle(0, 0, rt_size.x, rt_size.y), Core::Rectangle(0, 250, 0, 250), Core::Rectangle(0.f, 0.5f, 0.f, 0.5f),  Core::ARGB(255*theta,255, 255, 255),  Core::ARGB(255*theta, 255, 255, 255));
		}

		ui_render->SetWorld(old_world);
	}

	if(viewer)
	{
		//draw round wait time progress bar
		if(gLevel->round_start_wait_time > 0.0f && gLevel->game_type != RoomOption::kNovice)
		{
			float progress = Clamp(gLevel->round_start_wait_time / gLevel->round_total_time, 0, 1);
			world.SetTranslationXYZ(rt_size.x / 2, 15, 0);
			ui_render->SetWorld(world);

			ui_render->SetTexture(process_bar);
			ui_render->DrawRectangle(Core::Rectangle(-198,-22 + 98,198,23 + 98),Core::Rectangle(0,0,1,1));

			ui_render->DrawStringShadow(ui_render->font_simhei_16,font_color, ARGB(font_color.a,0,0,0),bg_color,Core::Rectangle(-100,130 - 45,100,150 - 45),gLang->GetTextW(L"�ȴ��غϿ�ʼ"),Unit::kAlignCenterMiddle);

			ui_render->SetTexture(NullPtr);
			ui_render->DrawRectangle(Core::Rectangle(-164, 153 - 45 + 2, -164 + 355 * progress, 167 - 50 - 2),Core::Rectangle(0,0,1.0f,1.0f), Core::ARGB(255,255,247,206));
		}
	}

	// draw win
	if (gGame->channel_connection && gGame->channel_connection->round_win_team != -1 && fabs(gLevel->round_end_wait_time) <= Core::EPSILON && gLevel->game_type != RoomOption::kBossPVE)
	{
		world.SetTranslationXYZ(rt_size.x / 2, rt_size.y / 2, 0);
		ui_render->SetWorld(world);

		int cx,cy;

		if (player)
		{
			if (gGame->channel_connection->round_win_team == 0)
			{
				switch(gLevel->game_type)
				{
				case RoomOption::kBoss:
				case RoomOption::kZombieMode:
				case RoomOption::kCommonZombieMode:
				case RoomOption::kBossMode2:
					ui_render->SetTexture(win_human_icon);
					cx = win_human_icon->GetWidth(), cy = win_human_icon->GetHeight();
					break;
				default:
					ui_render->SetTexture(win_red_icon);
					cx = win_red_icon->GetWidth(), cy = win_red_icon->GetHeight();
					break;
				}				
			}
			else if(gGame->channel_connection->round_win_team == 1)
			{
				switch(gLevel->game_type)
				{
				case RoomOption::kBoss:
				case RoomOption::kBossMode2:	
					ui_render->SetTexture(win_boss_icon);
					cx = win_boss_icon->GetWidth(), cy = win_boss_icon->GetHeight();
					break;
				case RoomOption::kZombieMode:
				case RoomOption::kCommonZombieMode:
					ui_render->SetTexture(win_zombie_icon);
					cx = win_zombie_icon->GetWidth(), cy = win_zombie_icon->GetHeight();
					break;
				default:
					ui_render->SetTexture(win_blue_icon);
					cx = win_blue_icon->GetWidth(), cy = win_blue_icon->GetHeight();
					break;
				}
			}
		}
		tempc_ptr(Character) laoda_1 = gLevel->GetCharacter(gLevel->current_street_king_uid[0]);
		tempc_ptr(Character) laoda_2 = gLevel->GetCharacter(gLevel->current_street_king_uid[1]);
		if(laoda_1&& laoda_1->GetCurCharinfo() && laoda_2 && laoda_2->GetCurCharinfo())
		{
			float fSc_1 = (float)laoda_1->hp / laoda_1->max_hp;
			fSc_1 = fSc_1<0?0:fSc_1;
			float fSc_2 = (float)laoda_2->hp / laoda_2->max_hp;
			fSc_2 = fSc_2<0?0:fSc_2;
			if(fSc_1>0 && fSc_2>0 && fSc_1>fSc_2 && laoda1win)
			{
				if(laoda_1->GetTeam() == 0)
				{
					Core::String str = Core::String::Format(gLang->GetTextW(L"�췽�ϴ�ʣ��Ѫ��%d%%��ʤ����"),(int)(fSc_1*100));
					gLevel->AddHorn(str);
				}
				else
				{
					Core::String str = Core::String::Format(gLang->GetTextW(L"�����ϴ�ʣ��Ѫ��%d%%��ʤ����"),(int)(fSc_1*100));
					gLevel->AddHorn(str);
				}
				laoda1win = false;
			}
			else if(fSc_1>0 && fSc_2>0 && fSc_2>fSc_1 && laoda2win)
			{
				if(laoda_2->GetTeam() == 0)
				{
					Core::String str = Core::String::Format(gLang->GetTextW(L"�췽�ϴ�ʣ��Ѫ��%d%%��ʤ����"),(int)(fSc_2*100));
					gLevel->AddHorn(str);
				}
				else
				{
					Core::String str = Core::String::Format(gLang->GetTextW(L"�����ϴ�ʣ��Ѫ��%d%%��ʤ����"),(int)(fSc_2*100));
					gLevel->AddHorn(str);
				}
				laoda2win = false;
			}
		}
		else
		{

		}

		ui_render->DrawRectangle(Core::Rectangle(-cx / 2, -cy / 2, cx / 2, cy / 2), Core::Rectangle(0, 0, 1, 1));
	}
	
	//draw kick
	if (gLevel->kick_select_open)
	{
		world.SetTranslationXYZ(rt_size.x, rt_size.y / 2, 0);
		ui_render->SetWorld(world);
		ui_render->SetTexture(ui_textures_kick_bg);
		ui_render->DrawWindow(Core::Rectangle(-476,-181,-476+460,-181+135),Core::Rectangle(25,25,25,25),Core::Rectangle(25.0f / 72.f, 25.0f / 72.f, 25.0f / 72.f, 25.0f / 72.f));
		Core::String str_reason;
		switch((int)gLevel->kicked_reason)
		{
		case 1:
			{
				str_reason = Core::String::Format(gLang->GetTextW(L"����ʹ��BUG"));
			}
			break;
		case 2:
			{
				str_reason = Core::String::Format(gLang->GetTextW(L"��ʱ��һ�"));
			}
			break;
		case 3:
			{
				str_reason = Core::String::Format(gLang->GetTextW(L"������á��"));
			}
			break;
		case 4:
			{
				str_reason = Core::String::Format(gLang->GetTextW(L"��һ�Ƿ�����"));
			}
			break;
		default:
			{
				str_reason = Core::String::Format(gLang->GetTextW(L"����"));
			}
			break;
		}
		switch(gLevel->kick_select_id)
		{
		case 0:
			{
				tempc_ptr(Character) sponsor = gLevel->GetCharacter(gLevel->sponsor_uid);
				tempc_ptr(Character) kicked = gLevel->GetCharacter(gLevel->kicked_uid);
				if(sponsor && kicked)
				{
					tempc_ptr(Character) sponsor = gLevel->GetCharacter(gLevel->sponsor_uid);
					tempc_ptr(Character) kicked = gLevel->GetCharacter(gLevel->kicked_uid);
					if(sponsor && kicked)
					{
						CStrBuf<256> kick_str;
						kick_str.format(gLang->GetTextW(L"%s �����߳� %s"),sponsor->GetName(),kicked->GetName());
						ui_render->DrawString(ui_render->font_simhei_16,Core::ARGB(255,0,0,0),Core::ARGB(0,0,0,0),Core::Rectangle(-476,-181+15,-476+460,-181+40),kick_str.buff(),Unit::kAlignCenterMiddle);
						kick_str.format(gLang->GetTextW(L"������ %s"),str_reason);
						ui_render->DrawString(ui_render->font_simhei_16,Core::ARGB(255,0,0,0),Core::ARGB(0,0,0,0),Core::Rectangle(-476,-181+50,-476+460,-181+75),kick_str.buff(),Unit::kAlignCenterMiddle);
						kick_str.format(gLang->GetTextW(L"�޳ɰ�[F11]"));
						ui_render->DrawString(ui_render->font_simhei_22,Core::ARGB(255,0,0,0),Core::ARGB(0,0,0,0),Core::Rectangle(-476+30,-181+90,-476+230,-181+120),kick_str.buff(),Unit::kAlignCenterMiddle);
						kick_str.format(gLang->GetTextW(L"���԰�[F12]"));
						ui_render->DrawString(ui_render->font_simhei_22,Core::ARGB(255,0,0,0),Core::ARGB(0,0,0,0),Core::Rectangle(-476+230,-181+90,-476+460-30,-181+120),kick_str.buff(),Unit::kAlignCenterMiddle);
					}
				}
			}
			break;
		case 1:
			{
				CStrBuf<256> kick_str;
				ui_render->SetTexture(ui_textures_kick_title);
				ui_render->DrawWindow(Core::Rectangle(-476+12,-160,-476-12+460,-160+26),Core::Rectangle(25,25,25,25),Core::Rectangle(25.0f / 72.f, 25.0f / 72.f, 25.0f / 72.f, 25.0f / 72.f));
				kick_str.format(gLang->GetTextW(L"��ͬ����"));
				ui_render->DrawString(ui_render->font_simhei_24,Core::ARGB(255,0,0,0),Core::ARGB(0,0,0,0),Core::Rectangle(-476+12,-160,-476-12+460,-160+26),kick_str.buff(),Unit::kAlignCenterMiddle);
				kick_str.format(gLang->GetTextW(L"ͬ��[%d]"),gLevel->kick_agree_num);
				ui_render->DrawString(ui_render->font_simhei_28,Core::ARGB(255,0,0,0),Core::ARGB(0,0,0,0),Core::Rectangle(-476+50,-115,-476+230,-115+40),kick_str.buff(),Unit::kAlignCenterMiddle);
				kick_str.format(gLang->GetTextW(L"����[%d]"),gLevel->kick_against_num);
				ui_render->DrawString(ui_render->font_simhei_28,Core::ARGB(255,0,0,0),Core::ARGB(0,0,0,0),Core::Rectangle(-476+230,-115,-476+460-50,-115+40),kick_str.buff(),Unit::kAlignCenterMiddle);
			}
			break;
		case 2:
			{
				CStrBuf<256> kick_str;
				ui_render->SetTexture(ui_textures_kick_title);
				ui_render->DrawWindow(Core::Rectangle(-476+12,-160,-476-12+460,-160+26),Core::Rectangle(25,25,25,25),Core::Rectangle(25.0f / 72.f, 25.0f / 72.f, 25.0f / 72.f, 25.0f / 72.f));
				kick_str.format(gLang->GetTextW(L"�㷴����"));
				ui_render->DrawString(ui_render->font_simhei_24,Core::ARGB(255,0,0,0),Core::ARGB(0,0,0,0),Core::Rectangle(-476+12,-160,-476-12+460,-160+26),kick_str.buff(),Unit::kAlignCenterMiddle);
				kick_str.format(gLang->GetTextW(L"ͬ��[%d]"),gLevel->kick_agree_num);
				ui_render->DrawString(ui_render->font_simhei_28,Core::ARGB(255,0,0,0),Core::ARGB(0,0,0,0),Core::Rectangle(-476+50,-115,-476+230,-115+40),kick_str.buff(),Unit::kAlignCenterMiddle);
				kick_str.format(gLang->GetTextW(L"����[%d]"),gLevel->kick_against_num);
				ui_render->DrawString(ui_render->font_simhei_28,Core::ARGB(255,0,0,0),Core::ARGB(0,0,0,0),Core::Rectangle(-476+230,-115,-476+460-50,-115+40),kick_str.buff(),Unit::kAlignCenterMiddle);
			}
			break;
		default:
			{
				tempc_ptr(Character) sponsor = gLevel->GetCharacter(gLevel->sponsor_uid);
				tempc_ptr(Character) kicked = gLevel->GetCharacter(gLevel->kicked_uid);
				if(sponsor && kicked)
				{
					CStrBuf<256> kick_str;
					kick_str.format(gLang->GetTextW(L"%s �����߳� %s"),sponsor->GetName(),kicked->GetName());
					ui_render->DrawString(ui_render->font_simhei_24,Core::ARGB(255,84,82,77),Core::ARGB(0,0,0,0),Core::Rectangle(-476,-181+135-110,-476+460,-181+135-80),kick_str.buff(),Unit::kAlignCenterMiddle);
					kick_str.format(gLang->GetTextW(L"������ %s"),str_reason);
					ui_render->DrawString(ui_render->font_simhei_24,Core::ARGB(255,84,82,77),Core::ARGB(0,0,0,0),Core::Rectangle(-476,-181+135-60,-476+460,-181+135-30),kick_str.buff(),Unit::kAlignCenterMiddle);
				}
			}
			break;
		}
	}

	if (gLevel->sensitivity_timer > 0)
	{
		String name;
		float value;
		if (!gLevel->isGunSensitivity)
		{
			value = gGame->config->GetSensitivity();
			name = gLang->GetTextW(L"���������");
		}
		else
		{
			value = gGame->config->GetSensitivitySniper();
			name = gLang->GetTextW(L"����������");
		}

		world.SetTranslationXYZ(rt_size.x / 2, 0, 0);
		ui_render->SetWorld(world);
		int sensitivity_x = -233/2;
		int sensitivity_y = 100;
		ui_render->SetTexture(ui_sensitivity_box);
		ui_render->DrawWindow(Core::Rectangle(sensitivity_x,sensitivity_y,sensitivity_x+233,sensitivity_y+74),Core::Rectangle(15, 15, 15, 15),Core::Rectangle(15.f/96.f, 15.f/52.f, 15.f/96.f, 15.f/52.f));
		ui_render->DrawString(ui_render->font_simhei_14, Core::ARGB(255,239,206), Core::ARGB(0,255,255,255), Core::Rectangle(sensitivity_x, sensitivity_y+10, sensitivity_x+233, sensitivity_y+30), name, Unit::kAlignCenterMiddle);
		ui_render->DrawString(ui_render->font_simhei_14, Core::ARGB(255,239,206), Core::ARGB(0,255,255,255), Core::Rectangle(sensitivity_x, sensitivity_y+40, sensitivity_x+50, sensitivity_y+70), "1.0", Unit::kAlignCenterMiddle);
		ui_render->DrawString(ui_render->font_simhei_14, Core::ARGB(255,239,206), Core::ARGB(0,255,255,255), Core::Rectangle(sensitivity_x+140, sensitivity_y+40, sensitivity_x+190, sensitivity_y+70), "20.0", Unit::kAlignCenterMiddle);
		ui_render->SetTexture(ui_sensitivity_box2);
		ui_render->DrawWindow(Core::Rectangle(sensitivity_x+185,sensitivity_y+46,sensitivity_x+220,sensitivity_y+66),Core::Rectangle(9, 9, 9, 9),Core::Rectangle(9.f/20.f, 9.f/20.f, 9.f/20.f, 9.f/20.f));

		Core::String str = Core::String::Format("%.01f",value);
		ui_render->DrawString(ui_render->font_simhei_14, Core::ARGB(255,239,206), Core::ARGB(0,255,255,255), Core::Rectangle(sensitivity_x+185,sensitivity_y+46,sensitivity_x+220,sensitivity_y+66), str.Str(), Unit::kAlignCenterMiddle);
		ui_render->SetTexture(ui_sensitivity_scrollbar_bg);
		ui_render->DrawWindow(Core::Rectangle(sensitivity_x+42,sensitivity_y+48,sensitivity_x+148,sensitivity_y+64),Core::Rectangle(7, 0, 7, 0),Core::Rectangle(7.f/32.f, 0, 7.f/32.f, 0));
		ui_render->SetTexture(ui_sensitivity_scrollbar_slider);
		int temp_x = 96 * value / 20.f;
		ui_render->DrawWindow(Core::Rectangle(sensitivity_x+36+temp_x,sensitivity_y+48,sensitivity_x+36+temp_x+16,sensitivity_y+64),Core::Rectangle(0, 0, 0, 0),Core::Rectangle(0, 0, 0, 0));
		gLevel->sensitivity_timer -= Task::GetFrameTime();
	}
	
	if (gLevel->game_type != RoomOption::kNovice)
	{
		Core::Vector3 rt_size = gGame->guiSys->GetSize();

		view.SetScaleXYZ(2.0f/rt_size.x, -2.0f/rt_size.y, 0);
		ui_render->SetView(view);
		_DarwBigMap(ui_render);
		if (gLevel->game_type == RoomOption::kBoss || gLevel->game_type == RoomOption::kBossMode2)
		{			
			_DrawBossTab(ui_render);
		}
		else if (gLevel->game_type == RoomOption::kZombieMode)
		{
			if (gLevel->boss_starttimeer <= 0)
			{
				_DrawZombieTab(ui_render);
			}
			else
				_DrawStartZombieTab(ui_render);			
		}
		else if (gLevel->game_type == RoomOption::kBossPVE)
		{
			_DrawBossPveTab(ui_render);
		}
		else if (gLevel->game_type == RoomOption::kCommonZombieMode)
		{
			_DrawCommonZombieTab(ui_render);
		}
		else if (gLevel->game_type != RoomOption::kEditMode)
		{
			_DrawTab(ui_render);
		}
	}
	else
	{
		view.SetScaleXYZ(2.0f/rt_size.x, -2.0f/rt_size.y, 0);
		ui_render->SetView(view);
		_DarwBigMap(ui_render);

		view.SetScaleXYZ(2.0f / rt_size.x, -2.0f / rt_size.y, 0);
		view.TranslateXYZ(-1, 1, 0);
		view.TranslateLocalXYZ(-0.5f, -0.5f, 0);
		ui_render->SetWorld(Matrix44::kIdentity);
		ui_render->SetView(view);
		ui_render->SetProjection(Matrix44::kIdentity);
		_DrawNovice(ui_render);
	}
	if (anim_pictureIn)
	{
		anim_pictureIn->render(ui_render);
	}
	if (anim_pictureOut)
	{
		anim_pictureOut->render(ui_render);
	}
	if (anim_picture_Mvp_In)
	{
		anim_picture_Mvp_In->render(ui_render);
	}
	if (anim_picture_Mvp_Out)
	{
		anim_picture_Mvp_Out->render(ui_render);
	}
	if (anim_picture_Card_Out)
	{
		anim_picture_Card_Out->render(ui_render);
	}
	if (anim_picture_bigCard_Out)
	{
		anim_picture_bigCard_Out->render(ui_render);
	}
	if (anim_picture_bigCard_Out_next)
	{
		anim_picture_bigCard_Out_next->render(ui_render);
	}
	//tempc_ptr(Character) play = gLevel->GetPlayer();
	if (is_Mvp && !player->IsDied())
	{
		Matrix44 oldworld;
		Matrix44 world;
		Matrix44 oldview;
		Matrix44 view;
		tempc_ptr(Character) viewer = gLevel->GetViewer();
		if (viewer)
		{
			Core::Vector3 rt_size = gGame->guiSys->GetSize();
			world = Core::Matrix44::kIdentity;
			oldworld = ui_render->GetWorld();
			oldview  = ui_render->GetView();
			
			view.SetScaleXYZ(2.0f/rt_size.x, -2.0f/rt_size.y, 0);
			ui_render->SetView(view);
			world.SetTranslationXYZ(-(rt_size.x/2), rt_size.y/2, 0);
			ui_render->SetWorld(world);
			ui_render->DrawTextureWindow(Core::Vector2( 110 , -140 ), 53 , 50 , anim_picture_Mvp);

			ui_render->SetWorld(oldworld);
			ui_render->SetView(oldview);
		}
	}
	// flash play
	Flash_Play(ui_render);

	if (gLevel->game_type == RoomOption::kBossPVE)
	{
		// draw win
		if (gGame->channel_connection && gGame->channel_connection->round_win_team != -1 && fabs(gLevel->round_end_wait_time) <= Core::EPSILON)
		{
			if (player)
			{
				Core::Vector3 rt_size = gGame->guiSys->GetSize();
				if (gGame->channel_connection->round_win_team == 0 && !FlashIsPlaying(Core::String::Format("BOSSPVE_WIN") ) )
					Initialize_Flash(Core::String::Format("BOSSPVE_WIN"),10.0f, Core::Vector2(1280, 800), Core::Rectangle(-rt_size.x/2, -rt_size.y/2, -rt_size.x/2+rt_size.x, -rt_size.y/2+rt_size.y) );
				else if(gGame->channel_connection->round_win_team == 1 && !FlashIsPlaying(Core::String::Format("BOSSPVE_DEFEAT") ) )
					Initialize_Flash(Core::String::Format("BOSSPVE_DEFEAT"),10.0f, Core::Vector2(1280, 800), Core::Rectangle(-rt_size.x/2, -rt_size.y/2, -rt_size.x/2+rt_size.x, -rt_size.y/2+rt_size.y) );
			}
		}

		// draw boss pve round start flash
		if (gLevel->boss_starttimeer > 0 && !FlashIsPlaying(Core::String::Format("BOSSPVE_ROUND_START") ) )
		{
			Core::Vector3 rt_size = gGame->guiSys->GetSize();
			Initialize_Flash(Core::String::Format("BOSSPVE_ROUND_START"),15.0f, Core::Vector2(1280, 800), Core::Rectangle(-rt_size.x/2, -rt_size.y/2, -rt_size.x/2+rt_size.x, -rt_size.y/2+rt_size.y) );
		}
	}

	_Draw_Die_Buff_Rand(ui_render);
}

void InGameUINew::Initialize_Flash(Core::String swfName, float swfTime, Core::Vector2 swfSize, Core::Rectangle drawRect)
{
	SFlashInfo t_flash;
	t_flash.flash_player = ptr_new FlashPlayer;
	Core::String str = Core::String::Format("flash/%s.swf",swfName.Str());
	t_flash.flash_player->Initialize(swfSize.x, swfSize.y, str.Str(),false);
	t_flash.duration_timer = swfTime;
	t_flash.player_rect = drawRect;
	t_flash.name = swfName;

	m_flash.PushBack(t_flash);
}

bool InGameUINew::FlashIsPlaying(Core::String swfName)
{
	Core::LinkNode<SFlashInfo>* node = m_flash.Front();
	while(node)
	{
		if (node->data.name == swfName)
			return true;
		node = node->GetNext();
	}

	return false;
}

void InGameUINew::Flash_Play(by_ptr(UIRender) ui_render)
{
	Core::LinkNode<SFlashInfo>* node = m_flash.Front();
	while(node)
	{
		Core::LinkNode<SFlashInfo>* next_node = node->GetNext();
		if (node->data.flash_player && node->data.duration_timer>0)
		{
			float frame_time = Task::GetFrameTime();
			node->data.duration_timer -= frame_time;
			node->data.flash_player->OnRender();
			Matrix44 oldworld;
			Matrix44 world;
			Matrix44 oldview;
			Matrix44 view;
			tempc_ptr(Character) viewer = gLevel->GetViewer();
			if (viewer && node->data.flash_player->texture_flash)
			{
				Core::Vector3 rt_size = gGame->guiSys->GetSize();
				world = Core::Matrix44::kIdentity;
				oldworld = ui_render->GetWorld();
				oldview  = ui_render->GetView();

				view.SetScaleXYZ(2.0f/rt_size.x, -2.0f/rt_size.y, 0);
				ui_render->SetView(view);
				world.SetTranslationXYZ(0, 0, 0);
				ui_render->SetWorld(world);
				ui_render->DrawTextureWindow(Core::Vector2(node->data.player_rect.Min.x, node->data.player_rect.Min.y), 
					node->data.player_rect.GetExtent().x, node->data.player_rect.GetExtent().y, node->data.flash_player->texture_flash);

				ui_render->SetWorld(oldworld);
				ui_render->SetView(oldview);
			}
		}
		else{
			m_flash.Remove(node);
		}
		node = next_node;
	}
}

void InGameUINew::Delete_Flash()
{
}

void InGameUINew::_DarwBigMap(by_ptr(UIRender) ui_render)
{
	Matrix44 world;
	Core::Vector3 rt_size = gGame->guiSys->GetSize();
	tempc_ptr(Character) player = gLevel->GetPlayer();
	tempc_ptr(Character) viewer = gLevel->GetViewer();
	if (!player || RoomOption::kTDMode == gLevel->game_type)
		return;
	ARGB name_colors[] = { ARGB(255, 101, 74),ARGB(128, 215, 255) , ARGB(255,128,128,128)};
	if (show_map)
	{
		float radio_x = 1024.0f / gGame->screen->GetSize().x;
		float radio_y = 768.0f / gGame->screen->GetSize().y;
		int width = gGame->screen->GetSize().x, height = gGame->screen->GetSize().y;

		if(abs(width - height) >300)
		{
			if(radio_x < radio_y)
				radio_x = radio_y;
			else
				radio_y = radio_x;
		}
		world.SetTranslationXYZ(0, 0, 0);
		ui_render->SetWorld(world);

		//ui_render->SetTexture(ui_window);
		//ui_render->DrawRectangle(Core::Rectangle(-465 * radio_x, -322 * radio_y, 465 * radio_x, 322 * radio_y), Core::Rectangle(0, 0, 1, 1));

#ifndef MASTER
		if (1)
		{
			ARGB font_color = ARGB(255, 241, 211);
			ARGB bg_color = ARGB(0, 0, 0, 0);
			Core::Vector2 move;
			move.y = gGame->input->IsKeyRepeated(KC_NUMPAD8) - gGame->input->IsKeyRepeated(KC_NUMPAD2);
			move.x = gGame->input->IsKeyRepeated(KC_NUMPAD6) - gGame->input->IsKeyRepeated(KC_NUMPAD4);

			if (gGame->input->IsKeyDown(KC_LSHIFT))
			{
				gGame->level->map_center += move * 0.1f;
			}
			else
			{
				gGame->level->map_size += move * 0.1f;
			}

			if (gGame->input->IsKeyDown(KC_NUMPAD5))
			{
				CStrBuf<256> buff;
				buff.format(gLang->GetTextW(L"��ͼ��Ϣ��%g, %g, %g, %g"), gGame->level->map_center.x, gGame->level->map_center.y, gGame->level->map_size.x, gGame->level->map_size.y);
				ui_render->DrawString(ui_render->font_simhei_16, font_color, bg_color, Core::Rectangle(-435, -285, 0, 0), buff, Unit::kAlignLeftTop);
			}
		}
#endif
		Vector2 draw_size(400 * radio_x, 300 * radio_y);
		Vector2 map_size(gGame->level->map_size.x,gGame->level->map_size.y);
		Vector2 map_center = gGame->level->map_center;
		Vector2 map_scale = draw_size * 2 / map_size;
		float scale_x = 1.f,scale_y = 1.f;
		float scale = Min(map_scale.y, map_scale.x) / 2;

		Matrix44 map_rot;
		map_rot = Matrix44::kIdentity;
		if (player->GetTeam() == 1 || gLevel->game_type == RoomOption::kNovice)
			map_rot.SetRotationQuaternion(Quaternion(Vector3(0, 0, -1),PI));
		ui_render->SetWorld(map_rot * world);

		if (gLevel->map_texture)
		{
			ui_render->SetTexture(gLevel->map_texture);

			Core::Rectangle rect;

			if (Abs(map_scale.y) > Abs(map_scale.x))
			{
				rect.Max.x = draw_size.x;
				rect.Max.y = draw_size.x / map_size.x * map_size.y;
			}
			else
			{
				rect.Max.y = draw_size.y;
				rect.Max.x = draw_size.y / map_size.y * map_size.x;
			}

			rect.Min = -rect.Max;

			ui_render->DrawRectangle(rect, Core::Rectangle(0, 0, 1, 1));
		}
		if (gLevel->bomb_on_ground && player->GetTeam() == 1)
		{
			Vector3 pos = (const Vector3&)gLevel->bomb_on_ground_position;
			Vector2 cpos;

			cpos.x = pos.x;
			cpos.y = pos.z;

			cpos = (map_center - cpos) * Vector2(scale,scale);

			Matrix44 trans;

			trans.SetTranslationXYZ(cpos.x, cpos.y, 0);

			ui_render->SetWorld(trans * world * map_rot);
			ui_render->SetTexture(ui_textures[8]);
			ui_render->DrawRectangle(Core::Rectangle(-10, -10, 10, 10), Core::Rectangle(0, 0, 1, 1));
		}

		for (U32 i = 0; i < gLevel->bomb_plant_position_array.Size(); i++)
		{
			tempc_ptr(BombPositionData) data = gLevel->bomb_plant_position_array[i];

			Vector3 pos = (const Vector3&)data->mesh->GetPosition();
			Vector2 cpos;

			cpos.x = pos.x;
			cpos.y = pos.z;

			cpos = (map_center - cpos) * Vector2(scale,scale);	

			Matrix44 trans;

			trans.SetTranslationXYZ(cpos.x, cpos.y, 0);
			//ui_render->SetWorld(trans * world * map_rot);
			if (player->GetTeam()==1)
			{
				//rot.SetRotationQuaternion(Quaternion(Vector3(1, 0, 0), HALFPI) * PI * Quaternion(Vector3(-1, 0, 0), HALFPI) * Quaternion(Vector3(0, 0, 1), PI));
				ui_render->SetWorld(trans * world * map_rot);
				switch (i)
				{
				case 0:
					ui_render->SetTexture(ui_smallmap_bomb_arrayA);
					ui_render->DrawRectangle(Core::Rectangle(-10, -10, 10, 10), Core::Rectangle(1, 1, 0, 0));
					break;
				case 1:
					ui_render->SetTexture(ui_smallmap_bomb_arrayB);
					ui_render->DrawRectangle(Core::Rectangle(-10, -10, 10, 10), Core::Rectangle(1, 1, 0, 0));
					break;
				default:
					break;
				}
			}
			else
			{
				ui_render->SetWorld(trans * world * map_rot);
				switch (i)
				{
				case 0:
					ui_render->SetTexture(ui_smallmap_bomb_arrayA);
					ui_render->DrawRectangle(Core::Rectangle(-10, -10, 10, 10), Core::Rectangle(0, 0, 1, 1));
					break;
				case 1:
					ui_render->SetTexture(ui_smallmap_bomb_arrayB);
					ui_render->DrawRectangle(Core::Rectangle(-10, -10, 10, 10), Core::Rectangle(0, 0, 1, 1));
					break;
				default:
					break;
				}
			}
		}
		// draw supply box


		for(uint i = 0 ; i < gLevel->pickup_manager->pick_up_set.Size(); i ++)
		{
			sharedc_ptr(PickUpManager::PickUpObject) Object = gLevel->pickup_manager->pick_up_set[i];
			if(!Object || Object->type != PickUpManager::kPickUpSupply)
				continue;

			if(!Object->collider)
				continue;

			Vector3 pos = (const Vector3&)Object->collider->getGlobalPosition();
			Vector2 cpos;
			Core::Rectangle temp;
			cpos.x = pos.x;
			cpos.y = pos.z;

			if (player->GetTeam() == 1 || gLevel->game_type == RoomOption::kNovice)
			{
				cpos = -(map_center - cpos) * Vector2(scale * scale_x,scale * scale_y);
				temp = Core::Rectangle(1, 1, 0, 0);
			}
			else
			{
				cpos = (map_center - cpos) * Vector2(scale * scale_x,scale * scale_y);
				temp = Core::Rectangle(0, 0, 1, 1);
			}

			Matrix44 trans;

			trans.SetTranslationXYZ(cpos.x, cpos.y, 0);

			ui_render->SetWorld(map_rot * trans * world);

			switch(Object->SType)
			{
			case PickUpManager::kSupplyHp:
			case PickUpManager::kSupplySurvivalItemHp:
				{
					ui_render->SetTexture(ui_smallmap_supply_hp);
					ui_render->DrawRectangle(Core::Rectangle(-10, -10, 10, 10), temp);
				}
				break;
			case PickUpManager::kSupplyAmmo:
			case PickUpManager::kSupplySurvivalItemAmmo:
				{
					ui_render->SetTexture(ui_smallmap_supply_bullet);
					ui_render->DrawRectangle(Core::Rectangle(-10, -10, 10, 10), temp);
				}
				break;
			case PickUpManager::kSupplyMedkit:
				{
					ui_render->SetTexture(ui_smallmap_supply_medkit);
					ui_render->DrawRectangle(Core::Rectangle(-10, -10, 10, 10), temp);
				}
				break;
			case PickUpManager::kSupplyAllTools:
				{
					ui_render->SetTexture(ui_smallmap_supply_tools);
					ui_render->DrawRectangle(Core::Rectangle(-10, -10, 10, 10), temp);
				}
				break;
			case PickUpManager::kSupplyCommonZombie:
			case PickUpManager::kSupplySurvivalItemRandom:
				{
					ui_render->SetTexture(ui_smallmap_supply_commonzombie);
					ui_render->DrawRectangle(Core::Rectangle(-10, -10, 10, 10), temp);
				}	
				break;
			case PickUpManager::kSupplyCommonZombie2:
				{
					ui_render->SetTexture(ui_smallmap_supply_item_special);
					ui_render->DrawRectangle(Core::Rectangle(-10, -10, 10, 10), temp);
				}	
				break;
			case PickUpManager::kSupplySurvivalItemTrapAmmo:
			case PickUpManager::kSupplySurvivalItemTrapHP:
			case PickUpManager::kSupplySurvivalItemTrapExpose:
			case PickUpManager::kSupplySurvivalItemTrapBomb:
			case PickUpManager::kSupplySurvivalItemTrapDebuff:
				{
					ui_render->SetTexture(ui_smallmap_supply_item_snare);
					ui_render->DrawRectangle(Core::Rectangle(-10, -10, 10, 10), temp);
				}
				break;
			}
			if ( player->isghost && Object->SType == PickUpManager::kSupplySurvivalItemGhostFire )
			{
				ui_render->SetTexture(ui_smallmap_supply_item_ghost);
				ui_render->DrawRectangle(Core::Rectangle(-10, -10, 10, 10), temp);
			}
		}

		for (uint team = 0; team < 2; team ++)
		{
			for (uint rank = 0; rank < gGame->scores->teams[team].Size(); rank ++)
			{
				Character * c = gGame->scores->teams[team][rank];
				if (c && c->playing && c->GetTeam() < 2)
				{
					ARGB color = name_colors[c->GetTeam() & 1];
					if (c == player)
						color = ARGB(0, 255, 0);

					Vector2 cpos;
					cpos.x = c->GetPosition().x;
					cpos.y = c->GetPosition().z;

					Matrix44 rot, trans;
					Core::Rectangle uv;
					Vector2 pos; 
					if (player->GetTeam() == 1 || gLevel->game_type == RoomOption::kNovice)
						pos = -(map_center - cpos) * Vector2(scale * scale_x, scale * scale_y);
					else
						pos = (map_center - cpos) * Vector2(scale * scale_x, scale * scale_y);
					trans.SetTranslationXYZ(pos.x, pos.y, 0);
					trans = map_rot * trans;

					if (c->IsDied())
					{
						Matrix44 transpos;
						transpos.SetTranslationXYZ(0, 0, 0);
						ui_render->SetWorld(transpos);
						ui_render->DrawStringShadow(ui_render->font_simhei_16, color, ARGB(color.a,0,0,0), ARGB(0, 0, 0, 0), Core::Rectangle(pos.x+14, pos.y, pos.x+60, pos.y+10), c->GetName(), Unit::kAlignLeftBottom);

						ui_render->SetWorld(trans * world);
						ui_render->SetTexture(ui_textures[1]);
						ui_render->DrawRectangle(Core::Rectangle(-8 * radio_x, -8 * radio_y, 8 * radio_x, 8 * radio_y), Core::Rectangle(0.0f, 0, 1.0f, 1.0f), ARGB(255, 255, 255));
					}
					else
					{
						if(player->GetTeam() == 2 && c)
						{
							Matrix44 transpos;
							transpos.SetTranslationXYZ(0, 0, 0);
							ui_render->SetWorld(transpos);
							ui_render->DrawStringShadow(ui_render->font_simhei_16, color, ARGB(color.a,0,0,0), ARGB(0, 0, 0, 0), Core::Rectangle(pos.x+14, pos.y, pos.x+60, pos.y+10), c->GetName(), Unit::kAlignLeftBottom);

							rot.SetRotationQuaternion(Quaternion(Vector3(1, 0, 0), HALFPI) * c->GetRotation() * Quaternion(Vector3(-1, 0, 0), HALFPI) * Quaternion(Vector3(0, 0, 1), PI));
							ui_render->SetWorld(rot * trans * world);

							if (c->IsShooting())
							{
								ui_render->SetTexture(ui_textures[2]);
								ui_render->DrawRectangle(Core::Rectangle(-10,-10,10,10), Core::Rectangle(0,0,1.0f,1.0f));
							}
							else if (c->show_shoot_time > 0)
							{
								ui_render->SetTexture(ui_textures[2]);
								ui_render->DrawRectangle(Core::Rectangle(-10,-10,10,10), Core::Rectangle(0,0,1.0f,1.0f));
							}
							else
							{
								ui_render->SetTexture(ui_textures[3]);
								ui_render->DrawRectangle(Core::Rectangle(-10 * radio_x,-10 * radio_y,10 * radio_x,10 * radio_y), Core::Rectangle(0,0,1.0f,1.0f));
							}
							
							/*if(player->IsDied())
							{
								ui_render->SetTexture(ui_textures[1]);
								ui_render->DrawRectangle(Core::Rectangle(-10 * radio_x,-10 * radio_y,10 * radio_x,10 * radio_y), Core::Rectangle(0,0,1.0f,1.0f));
							}*/
						}
						else if(viewer && player->GetTeam() == team)
						{
							Matrix44 transpos;
							transpos.SetTranslationXYZ(0, 0, 0);
							ui_render->SetWorld(transpos);
							ui_render->DrawStringShadow(ui_render->font_simhei_16, color, ARGB(color.a,0,0,0), ARGB(0, 0, 0, 0), Core::Rectangle(pos.x+14, pos.y, pos.x+60, pos.y+10), c->GetName(), Unit::kAlignLeftBottom);

							rot.SetRotationQuaternion(Quaternion(Vector3(1, 0, 0), HALFPI) * c->GetRotation() * Quaternion(Vector3(-1, 0, 0), HALFPI) * Quaternion(Vector3(0, 0, 1), PI));
							ui_render->SetWorld(rot * trans * world);
							
							if(c->GetThirdPerson().billboard_timer)
							{
								ui_render->SetTexture(ui_textures[6]);	
								ui_render->DrawRectangle(Core::Rectangle(-10 * radio_x, -10 * radio_y, 10 * radio_x, 10 * radio_y), Core::Rectangle(0,0,1.0f,1.0f));
							}
							else if(viewer == c)
							{
								ui_render->SetTexture(ui_textures[4]);	
								ui_render->DrawRectangle(Core::Rectangle(-64 * radio_x, -64 * radio_y, 64 * radio_x, 64 * radio_y), Core::Rectangle(0,0,1.0f,1.0f));
								if (c->HasBomb())
								{
									ui_render->SetTexture(ui_textures[8]);	
									ui_render->DrawRectangle(Core::Rectangle(-12,-12,12,12), Core::Rectangle(0,0,1.0f,1.0f));
								}
								else if(gLevel->bomb_droped == true)
								{
									Vector3 pos;
									gLevel->pickup_manager->GetPickUpPosition(gLevel->bomb_droped_id,PickUpManager::kPickUpWeapon, pos);
									Vector2 cpos;

									cpos.x = pos.x;
									cpos.y = pos.z;

									cpos = (map_center - cpos) * Vector2(scale,scale);

									Matrix44 trans;

									trans.SetTranslationXYZ(cpos.x, cpos.y, 0);

									ui_render->SetWorld(trans * world * map_rot);
									ui_render->SetTexture(ui_textures[8]);
									ui_render->DrawRectangle(Core::Rectangle(-10, -10, 10, 10), Core::Rectangle(0, 0, 1, 1));

								}
							}
							else if(viewer->GetTeam() == c->GetTeam())
							{
								if (c->IsShooting())
								{
									ui_render->SetTexture(ui_textures[2]);
									ui_render->DrawRectangle(Core::Rectangle(-10,-10,10,10), Core::Rectangle(0,0,1.0f,1.0f));
								}
								else if (c->show_shoot_time > 0)
								{
									ui_render->SetTexture(ui_textures[2]);
									ui_render->DrawRectangle(Core::Rectangle(-10,-10,10,10), Core::Rectangle(0,0,1.0f,1.0f));
								}
								else
								{
									ui_render->SetTexture(ui_textures[3]);
									ui_render->DrawRectangle(Core::Rectangle(-10 * radio_x,-10 * radio_y,10 * radio_x,10 * radio_y), Core::Rectangle(0,0,1.0f,1.0f));
								}
								
								if (c->HasBomb())
								{
									ui_render->SetTexture(ui_textures[8]);	
									ui_render->DrawRectangle(Core::Rectangle(-12,-12,12,12), Core::Rectangle(0,0,1.0f,1.0f));
								}
								else if(gLevel->bomb_droped == true)
								{
									Vector3 pos;
									gLevel->pickup_manager->GetPickUpPosition(gLevel->bomb_droped_id,PickUpManager::kPickUpWeapon, pos);
									Vector2 cpos;

									cpos.x = pos.x;
									cpos.y = pos.z;

									cpos = (map_center - cpos) * Vector2(scale,scale);

									Matrix44 trans;

									trans.SetTranslationXYZ(cpos.x, cpos.y, 0);

									ui_render->SetWorld(trans * world * map_rot);
									ui_render->SetTexture(ui_textures[8]);
									ui_render->DrawRectangle(Core::Rectangle(-10, -10, 10, 10), Core::Rectangle(0, 0, 1, 1));

								}
							}
						}
					}
				}
			}
		}
	}
}

void InGameUINew::_DrawbombMap(by_ptr(UIRender) ui_render)
{
	tempc_ptr(Character) play = gLevel->GetPlayer();
	if (!play || !play->HasBomb())
	{
		return;
	}
	Matrix44 oldworld;
	Matrix44 world;
	Matrix44 oldview;
	Matrix44 view;
	float Tep_ftime;
	m_bomb_ico_time += Task::GetFrameTime();
	if (m_bomb_ico_time >1.0f)
	{
		m_bomb_ico_time = 0.0f;
	}
	if (m_bomb_ico_time >0.5f)
	{
		Tep_ftime = 1 - m_bomb_ico_time;
	}
	else
	{
		Tep_ftime = m_bomb_ico_time;
	}
	tempc_ptr(Character) viewer = gLevel->GetViewer();
	if (viewer)
	{
		Core::Vector3 rt_size = gGame->guiSys->GetSize();
		world = Core::Matrix44::kIdentity;
		oldworld = ui_render->GetWorld();
		oldview  = ui_render->GetView();
		view.SetScaleXYZ(2.0f/rt_size.x, -2.0f/rt_size.y, 0);
		ui_render->SetView(view);
		world.SetTranslationXYZ( -rt_size.x/2, rt_size.y/2, 0);
		ui_render->SetWorld(world);
		ui_render->DrawTextureWindow(Core::Vector2(206,-116 + Tep_ftime*15),71,51,ui_bomb_ico);
		if (gLevel->IsCanPlantBomb())
		{
			ui_render->DrawTextureWindow(Core::Vector2(206,-116 + Tep_ftime*15),71,51,ui_bomb_ico_flash,Core::Rectangle(0,0,1,1),Core::ARGB(255*Tep_ftime/0.5,255,255,255));
		}
		ui_render->SetWorld(oldworld);
		ui_render->SetView(oldview);
	}
}

void InGameUINew::_DrawBombBottomInfo(by_ptr(UIRender) ui_render)
{
	float bomb_time = 1.f;
	if (gLevel->GetBombDefusingState() >= 0)
	{
		bomb_time -= gLevel->GetBombDefusingState();
	}
	else if (gLevel->GetBombPlantingState() >= 0)
	{
		bomb_time -= gLevel->GetBombPlantingState();
	} 
	else
	{
		return;
	}
	Matrix44 oldworld;
	Matrix44 world;
	Matrix44 oldview;
	Matrix44 view;	
	tempc_ptr(Character) viewer = gLevel->GetViewer();
	if (viewer)
	{
		Core::Vector3 rt_size = gGame->guiSys->GetSize();
		world = Core::Matrix44::kIdentity;
		oldworld = ui_render->GetWorld();
		oldview  = ui_render->GetView();

		view.SetScaleXYZ(2.0f/rt_size.x, -2.0f/rt_size.y, 0);
		ui_render->SetView(view);
		world.SetTranslationXYZ(0, rt_size.y/2, 0);
		ui_render->SetWorld(world);
		ui_render->SetTexture(ui_bomb_defuse_course);
		ui_render->DrawWindow(Core::Rectangle(-143,-86,143,-22),Core::Rectangle(26,0,26,0),Core::Rectangle(26.f/92.f,0.f/64.f,26.f/92.f,0.f/64.f));
		ui_render->DrawTextureWindow(Core::Vector2(-130,-68),20.f + 235.f*bomb_time,28,ui_bomb_defuse_course_In,Core::Rectangle(0,0,(20.f + bomb_time*235.f)/255.f,1));
		ui_render->DrawTextureWindow(Core::Vector2(-132 + bomb_time*224,-75),40,41,ui_bomb_defuse_course_Point);
		if (gLevel->GetBombDefusingState() >= 0)
		{
			ui_render->DrawTextureWindow(Core::Vector2(-55,-111),110,25,ui_bomb_Text_Defusing);
		}
		else if (gLevel->GetBombPlantingState() >= 0)
		{
			ui_render->DrawTextureWindow(Core::Vector2(-55,-111),110,25,ui_bomb_Text_Planting);
		} 

		ui_render->SetWorld(oldworld);
		ui_render->SetView(oldview);
	}
}

void InGameUINew::_DrawBomb_count_down(by_ptr(UIRender) ui_render)
{
	if (gLevel->GetBombPlantedTimer() < 0)
	{
		return;
	}
	tempc_ptr(Character) viewer = gLevel->GetViewer();

	if (viewer)
	{
		Matrix44 oldworld;
		Matrix44 world;
		Matrix44 oldview;
		Matrix44 view;	
		Core::Vector3 rt_size = gGame->guiSys->GetSize();
		oldworld = ui_render->GetWorld();
		oldview  = ui_render->GetView();

		view.SetScaleXYZ(2.0f/rt_size.x, -2.0f/rt_size.y, 0);
		world.SetTranslationXYZ(0, 0, 0);
		ui_render->SetView(view);
		ui_render->SetWorld(world);
		
		if (gLevel->GetBombPlantedTimer() <= 10)
		{
			if (gLevel->GetBombPlantedTimer() >= 9)
			{
				_DrawNumberTextureWindow(ui_render, ui_boss_num, Core::Vector2(-116, -368), 116, 136, 1, 0.1f);
				_DrawNumberTextureWindow(ui_render, ui_boss_num, Core::Vector2(0, -368), 116, 136, 0, 0.1f);
			}
			else
			{
				_DrawNumberTextureWindow(ui_render, ui_boss_num, Core::Vector2(-58, -368), 116, 136, gLevel->GetBombPlantedTimer() + 1, 0.1f);
			}
		}

		ui_render->SetWorld(oldworld);
		ui_render->SetView(oldview);
	}
}
void InGameUINew::_Play_PlantedTimer_sound()
{
	if (gLevel->GetBombPlantedTimer() < 0)
	{
		_Play_PlantedTimer_sound_stop();
		return;
	}
	bomb_plantedtimer_part += Task::GetFrameTime();
	if (bomb_plantedtimer_part >= Bomb_Pack_Timer)
	{
		_Play_PlantedTimer_sound_stop();
		FMOD_VECTOR vel = {0, 0, 0};
		int i = (int)(Bomb_Totle_Timer - gLevel->GetBombPlantedTimer())/Bomb_Pack_Timer;
		FmodSystem::Update3DEventPosition(gLevel->audio_bomb_3d_Plant_Timer[i],(const FMOD_VECTOR &)gLevel->bomb_on_ground_position,vel);
		gLevel->audio_bomb_3d_Plant_Timer[i]->start();
	}
}

void InGameUINew::_Play_PlantedTimer_sound_stop()
{
	if (gLevel)
	{
		for (int i = 0;i < 5;i++)
		{
			gLevel->audio_bomb_3d_Plant_Timer[i]->stop();
		}
		bomb_plantedtimer_part = 0.0f;
	}
}

void InGameUINew::_DrawBomb_Tips(by_ptr(UIRender) ui_render)
{
	tempc_ptr(Character) viewer = gLevel->GetViewer();
	Core::String str_reason;

	tempc_ptr(Character) play = gLevel->GetPlayer();
	if (play && play->HasBomb() && gLevel->IsCanPlantBomb() && gLevel->GetBombPlantingState() < 0)
	{
		str_reason = Core::String::Format(gLang->GetTextW(L"�밴5�л����װ����ٰ�ס��������E������!"));
		show_tips_bomb_time = 0.0f;
	}
	else if (show_tips_bomb_time > 0)
	{
		show_tips_bomb_time -= Task::GetFrameTime();
		str_reason = Core::String::Format(gLang->GetTextW(L"�뵽������������!"));
	}
	else if (GetbombTipsShow() && gLevel->GetBombDefusingState() < 0)
	{
		str_reason = Core::String::Format(gLang->GetTextW(L"��׼�װ�����E������!"));
	}
	else
	{
		return;
	}

	if (viewer)
	{
		Matrix44 oldworld;
		Matrix44 world;
		Matrix44 oldview;
		Matrix44 view;	
		Core::Vector3 rt_size = gGame->guiSys->GetSize();
		oldworld = ui_render->GetWorld();
		oldview  = ui_render->GetView();

		view.SetScaleXYZ(2.0f/rt_size.x, -2.0f/rt_size.y, 0);
		world.SetTranslationXYZ(0, 0, 0);
		ui_render->SetView(view);
		ui_render->SetWorld(world);
		ui_render->DrawString(ui_render->font_simhei_24,Core::ARGB(255,255,178,0),Core::ARGB(0,0,0,0),Core::Rectangle(-100,-200,100,-170),str_reason.Str(),Unit::kAlignCenterMiddle);
		
		ui_render->SetWorld(oldworld);
		ui_render->SetView(oldview);
	}
}

bool InGameUINew::GetbombTipsShow()
{
	tempc_ptr(Character) play = gLevel->GetPlayer();
	if (!play || play->GetTeam() == 1 || !gLevel->bomb_on_ground)
	{
		return false;
	}
	Core::Vector3 position = gLevel->bomb_on_ground_position - play->GetPosition();
	if (position.Length() > 5)
	{
		return false;
	} 
	else
	{
		return true;
	}
}

void InGameUINew::_DrawBOSS2BottomInfo(by_ptr(UIRender) ui_render)
{
	Matrix44 oldworld;
	Matrix44 world;
	Matrix44 oldview;
	Matrix44 view;	
	tempc_ptr(Character) viewer = gLevel->GetViewer();
	if (viewer)
	{
		Core::Vector3 rt_size = gGame->guiSys->GetSize();
		world = Core::Matrix44::kIdentity;
		oldworld = ui_render->GetWorld();
		oldview  = ui_render->GetView();

		view.SetScaleXYZ(2.0f/rt_size.x, -2.0f/rt_size.y, 0);
		ui_render->SetView(view);
		world.SetTranslationXYZ(0, rt_size.y/2, 0);
		ui_render->SetWorld(world);
		//ui_render->SetTexture(ui_bomb_defuse_course);
		//ui_render->DrawWindow(Core::Rectangle(-143,-86,143,-22),Core::Rectangle(26,0,26,0),Core::Rectangle(26.f/92.f,0.f/64.f,26.f/92.f,0.f/64.f));
		//ui_render->DrawTextureWindow(Core::Vector2(-130,-68),20.f + 235.f*bomb_time,28,ui_bomb_defuse_course_In,Core::Rectangle(0,0,(20.f + bomb_time*235.f)/255.f,1));
		//ui_render->DrawTextureWindow(Core::Vector2(-132 + bomb_time*224,-75),40,41,ui_bomb_defuse_course_Point); 
		Game * game = gGame;
		int Tep_num = 0;
		tempc_ptr(Character) player = gLevel->GetPlayer();
		for (uint rank = 0; rank < game->scores->teams[0].Size(); rank ++)
		{
			tempc_ptr(Character) c = game->scores->teams[0][rank];
			if (c && c != player && c->GetCurCharinfo())
			{
				_DrawBOSS2BottomInfoSingle(ui_render,Core::Vector2(-251 + Tep_num*55,-100),c);
				Tep_num++;
			}
		}
		//for (int i = 0 ;i < 9 ;i++)
		//{
		//	_DrawBOSS2BottomInfoSingle(ui_render,Core::Vector2(-251 + Tep_num*55,-100),player);
		//	Tep_num++;
		//}
		ui_render->SetWorld(oldworld);
		ui_render->SetView(oldview);
	}
}

Core::String InGameUINew::PeopleName_cut(Core::String name,int cut_num)
{
	if (TextLenght(name) > cut_num  && name.Length() > (size_t)2*cut_num)
	{
		name = Core::String::Format("%s...",TextCopy(name, 0,cut_num));
	}
	return name;
}

void InGameUINew::_DrawBOSS2BottomInfoSingle(by_ptr(UIRender) ui_render,Core::Vector2 pos,tempc_ptr(Character) c)
{
	if (!c && !c->GetCurCharinfo())
	{
		return;
	}
	ui_render->DrawFontWindow(pos, 60, 15, ui_render->font_simhei_12, Core::ARGB(255, 216, 216, 216),  Core::ARGB(0, 0, 0, 0),PeopleName_cut(c->GetName(),4), Unit::kAlignCenterMiddle);
	ui_render->DrawTextureWindow(Core::Vector2(pos.x,pos.y + 15),61,65,ui_Boss2_Back);
	if (c->IsDied())
	{
		uint career_id = c->GetCurCharinfo()->career_id;
		tempc_ptr(Texture2D) headhui_texture = ui_bottom_info_headhui_icon.Get(career_id, NullPtr);
		if (headhui_texture)
		{
			ui_render->DrawTextureWindow(Core::Vector2(pos.x + 15,pos.y + 15 + 10),34,47,headhui_texture);
		}
		ui_render->DrawTextureWindow(Core::Vector2(pos.x,pos.y + 15),61,65,ui_Boss2_die);
	}
	else
		ui_render->DrawTextureWindow(Core::Vector2(pos.x + 15,pos.y + 15 + 10),34,47,c->ui_head_icon);
	//int tep_In = rand()%100;
	float f_hp = Core::Clamp((float)c->hp / c->max_hp,0,1.0f);
	ui_render->SetTexture(ui_tab_zombie_hp_bg);
	ui_render->DrawWindow(Core::Rectangle(pos.x + 6,pos.y + 83,pos.x + 57,pos.y + 94),Core::Rectangle(5,3,5,3),Core::Rectangle(5 / 12.f, 3.f / 11.f, 5 / 12.f, 3.f / 11.f));
	if (f_hp > 0)
	{
		if (f_hp > 0.6)
			ui_render->SetTexture(ui_common_hp[0]);
		else if (f_hp > 0.3)
			ui_render->SetTexture(ui_common_hp[1]); 
		else
			ui_render->SetTexture(ui_common_hp[2]);
		if (f_hp < 0.2)
			ui_render->DrawWindow(Core::Rectangle(pos.x + 6,pos.y + 82,pos.x + f_hp*51 + 6,pos.y + 95),Core::Rectangle(0,3,0,3),Core::Rectangle(0 / 32.f, 3.f / 16.f, 0 / 32.f, 3.f / 16.f));
		else
			ui_render->DrawWindow(Core::Rectangle(pos.x + 6,pos.y + 82,pos.x + f_hp*51 + 6,pos.y + 95),Core::Rectangle(5,3,5,3),Core::Rectangle(5 / 32.f, 3.f / 16.f, 5 / 32.f, 3.f / 16.f));
	}
}

void InGameUINew::_DrawCommonZombieSkill(by_ptr(UIRender) ui_render)
{
	tempc_ptr(Character) play = gLevel->GetPlayer();
	int dt_x = 0;
	if (play && !play->IsDied())
	{
		Matrix44 oldworld;
		Matrix44 world;
		Matrix44 oldview;
		Matrix44 view;
		tempc_ptr(Character) viewer = gLevel->GetViewer();
		if (viewer)
		{
			Core::Vector3 rt_size = gGame->guiSys->GetSize();
			world = Core::Matrix44::kIdentity;
			oldworld = ui_render->GetWorld();
			oldview  = ui_render->GetView();

			view.SetScaleXYZ(2.0f/rt_size.x, -2.0f/rt_size.y, 0);
			ui_render->SetView(view);
			world.SetTranslationXYZ(-(rt_size.x/2), rt_size.y/2, 0);
			ui_render->SetWorld(world);
			if (play->GetTeam() == 0 && play->can_Invincible)
			{
				_DrawInitiativeSkill(ui_render,Core::Vector2( 215 , -115 ),ui_commonzombie_Key_G,ui_commonzombie_Skill_ico[8],ui_commonzombie_Skill_Shine,ui_commonzombie_Skill_bg,ui_commonzombie_Skill_bf);
				dt_x = 60;
			}
			if (play->GetTeam() == 0 && play->is_human_super)
			{
				F32 f_precent = (CommonPeople_Skill_MaxTime - play->cd_time)/CommonPeople_Skill_MaxTime;
				_DrawInitiativeSkill(ui_render,Core::Vector2( 220 + dt_x, -115 ),ui_commonzombie_Key_E,ui_commonzombie_Skill_ico[0],ui_commonzombie_Skill_Shine,ui_commonzombie_Skill_bg,ui_commonzombie_Skill_bf,f_precent);
			}				

			for (int i = 0 ; i < commonzombie_skill.GetCount() ; i++)
			{
				SkillItem item = commonzombie_skill.GetAt(i);
				ui_render->DrawStringShadow(ui_render->font_simhei_16, Core::ARGB(255,255,128,4), ARGB(255,0,0,0), Core::ARGB(0,0,0,0), Core::Rectangle(30 + i*52 , -210,30 + i*52 + 52 , -190),Core::String::Format("%d",(int)item.time) , Unit::kAlignCenterMiddle);
				ui_render->DrawTextureWindow(Core::Vector2( 30 + i*52 , -190 ), 52 , 52 , ui_commonzombie_Skill_ico[item.type]);
			}
			ui_render->SetWorld(oldworld);
			ui_render->SetView(oldview);
		}
	}
}

void InGameUINew::_DrawInitiativeSkill(by_ptr(UIRender) ui_render,Core::Vector2 pos,by_ptr(Texture2D) texture_button,by_ptr(Texture2D) texture_Skill,by_ptr(Texture2D) texture_Skill_shine,by_ptr(Texture2D) texture_Skill_bg,by_ptr(Texture2D) texture_Skill_bf,F32 f_v,F32 f_time)
{
	if (f_time<0.1f)
	{
		ui_render->DrawTextureWindow(pos, 52 , 52, texture_Skill_bg);
	}
	else
	{
		ui_render->DrawTextureWindow(Core::Vector2(pos.x-26*(1.f-f_time),pos.y-26*(1.f-f_time)), 52*(2.f-f_time) , 52*(2.f-f_time), texture_Skill_bg, Core::Rectangle(0,0,1,1),Core::ARGB(255*f_time,255,255,255));
	}
	
	ui_render->DrawTextureWindow(pos, 52 , 52 , texture_Skill);
	ui_render->DrawTextureWindow(Core::Vector2(pos.x,pos.y + 52*f_v ), 52 , 52*(1 - f_v) , texture_Skill_bf,Core::Rectangle(0,(1 - f_v),1,1));
	ui_render->DrawTextureWindow(Core::Vector2( pos.x - 12 ,pos.y - 14 ), 28 , 36 , texture_button);
	if (f_v > 0 && f_v < 1)
	{
		ui_render->DrawTextureWindow(Core::Vector2(pos.x, pos.y + 52*f_v - 8 ), 52 , 15 , texture_Skill_shine);
	}
}

void InGameUINew::_DrawItemModeBottomInfo(by_ptr(UIRender) ui_render)
{
	Matrix44 oldworld;
	Matrix44 world;
	Matrix44 oldview;
	Matrix44 view;	
	tempc_ptr(Character) viewer = gLevel->GetViewer();
	tempc_ptr(Character) play = gLevel->GetPlayer();
	Vector3 head_pos;
	Quaternion head_rot;
	CStrBuf<256> buff;
	if (viewer && play)
	{
		Core::Vector3 rt_size = gGame->guiSys->GetSize();
		world = Core::Matrix44::kIdentity;
		oldworld = ui_render->GetWorld();
		oldview  = ui_render->GetView();

		view.SetScaleXYZ(2.0f/rt_size.x, -2.0f/rt_size.y, 0);
		ui_render->SetView(view);
		world.SetTranslationXYZ(0, rt_size.y/2, 0);
		ui_render->SetWorld(world);

		tempc_ptr(Character) play = gLevel->GetPlayer();
		if (play->IsDied())
		{
			return;
		}
		if (play->is_item_boss)
		{
			int right_x = 376;
			int right_y = -64;
			_DrawCoolDown(right_x-52, right_y, 48, 48, ui_quick_move, ui_cooldown_circle_bg, ui_cooldown_circle, play->quickmovecd/5, ui_render, 0);
			if ((int)(play->quickmovecd) > 0)
			{
				buff.format("%d",(int)(play->quickmovecd));
				ui_render->DrawString(ui_render->font_simhei_20,ARGB(255,238,208),ARGB(1,1,1,1),Core::Rectangle(right_x-10, right_y+20, right_x-10+48, right_y+20+48),buff,Unit::kAlignCenterMiddle);
			}
			if ( play->quickmovecd < 1.f && play->quickmovecd > 0.1f)
			{
				Core::ARGB bg_color = ARGB(play->quickmovecd*255,255,255,255);
				ui_render->SetTexture(ui_quick_move);
				ui_render->DrawRectangle(Core::Rectangle((right_x-52)-24*(1-play->quickmovecd), right_y-12-24*(1-play->quickmovecd), (right_x-52)+48+24*(1-play->quickmovecd), right_y-12+48+24*(1-play->quickmovecd)),Core::Rectangle(0, 0, 1, 1),bg_color);
				FmodSystem::PlayEvent("bj/ui/proprole01_cooldown");
			}

			return;
		}
		int t_x = -250;
		int t_y = -85;
		float energy_f = play->itemmode_energy/play->itemmode_energy_max;
		ui_render->DrawTextureWindow(Core::Vector2(t_x-10 , t_y),479,80,ui_itemmode_People_bottom_bg);
		ui_render->DrawTextureWindow(Core::Vector2(t_x-10 + 115, t_y + 34), 398*energy_f, 26, ui_itemmode_People_bottom_energy_f,Core::Rectangle(0,0,energy_f,1));
		ui_render->SetTexture(ui_head_info_bg_Bos_hp_bg);
		ui_render->DrawWindow(Core::Rectangle(t_x + 102,t_y + 34,t_x + 102 + 404,t_y + 34 + 26),Core::Rectangle(132, 0, 143, 0),Core::Rectangle(132.f/493.f, 0.f/26.f, 143.f/493.f, 0.f/26.f));
		ui_render->DrawStringShadow(ui_render->font_simhei_16, ARGB(255,229,51), ARGB(0,0,0), ARGB(0, 0, 0, 0), Core::Rectangle(t_x-130 , t_y-200 , 100, 20), gLang->GetTextW(L"��[E]ʹ�õ���"), Unit::kAlignLeftMiddle);
		if (play->itemmode_item_slot>=0)
		{
			_DrawInitiativeSkill(ui_render,Core::Vector2(t_x-100 , t_y-30),ui_commonzombie_Key_E,ui_itemmode_Skill_ico[play->itemmode_item_slot],ui_commonzombie_Skill_Shine,ui_commonzombie_Skill_bg,ui_commonzombie_Skill_bf);
		}
		else
		{
			_DrawInitiativeSkill(ui_render,Core::Vector2(t_x-100 , t_y-30),ui_commonzombie_Key_E,ui_itemmode_Skill_bg,ui_commonzombie_Skill_Shine,ui_commonzombie_Skill_bg,ui_commonzombie_Skill_bf,1.0,play->item_box_time);
		}
		CStrBuf<256> buff;
		for(int i = 0; i < (int)play->item_mode_debuff_time.Size();++i)
		{
			buff.format("%d��",(int)play->item_mode_debuff_time[i]->totle_time);
			ui_render->DrawTextureWindow(Core::Vector2(t_x-10 + 115 + 52*i , t_y-60),52,52,ui_itemmode_Skill_ico[play->item_mode_debuff_time[i]->slot]);
			ui_render->DrawStringShadow(ui_render->font_simhei_16, ARGB(255,229,51), ARGB(0,0,0), ARGB(0, 0, 0, 0), Core::Rectangle(t_x-10 + 115 + 52*i , t_y - 12 , t_x-10 + 115 + 52*i+52, t_y - 12+20),buff, Unit::kAlignCenterMiddle);
		}
		for(int i = 0; i < (int)play->item_mode_buff_time.Size();++i)
		{
			buff.format("%d��",(int)play->item_mode_buff_time[i]->totle_time);
			ui_render->DrawTextureWindow(Core::Vector2(t_x-10 + 115 + 52*i , t_y-130),52,52,ui_itemmode_Skill_ico[play->item_mode_buff_time[i]->slot]);
			ui_render->DrawStringShadow(ui_render->font_simhei_16, ARGB(255,229,51), ARGB(0,0,0), ARGB(0, 0, 0, 0), Core::Rectangle(t_x-10 + 115 + 52*i , t_y - 82 , t_x-10 + 115 + 52*i+52, t_y - 82+20),buff, Unit::kAlignCenterMiddle);
		}
		ui_render->SetWorld(oldworld);
		ui_render->SetView(oldview);
	}
}

//����
void InGameUINew::_DrawSurvivalModBottomInfo(by_ptr(UIRender) ui_render)
{
	Matrix44 oldworld;
	Matrix44 world;
	Matrix44 oldview;
	Matrix44 view;	
	tempc_ptr(Character) viewer = gLevel->GetViewer();
	tempc_ptr(Character) play = gLevel->GetPlayer();
	Vector3 head_pos;
	Quaternion head_rot;
	CStrBuf<256> buff;
	int t_x = -250;
	int t_y = -85;
	if (viewer && play)
	{
		Core::Vector3 rt_size = gGame->guiSys->GetSize();
		world = Core::Matrix44::kIdentity;
		oldworld = ui_render->GetWorld();
		oldview  = ui_render->GetView();
		view.SetScaleXYZ(2.0f/rt_size.x, -2.0f/rt_size.y, 0);
		ui_render->SetView(view);
		world.SetTranslationXYZ(0, rt_size.y/2, 0);
		ui_render->SetWorld(world);
		tempc_ptr(Character) play = gLevel->GetPlayer();
		tempc_ptr (Character) c = gLevel->GetPlayer();
        Core::LinkNode<SurvivalModeItemInfo>* node = c->basecharacter_info->survivalbag.Front();
        ui_render->DrawTextureWindow(Core::Vector2(t_x+34, t_y+10),433,88,ui_survival1,Core::Rectangle(0, 0, 1, 1),ARGB(255,255,255,255));

		for ( int i = 0; i < 5; i++ )
		{
            ui_render->DrawTextureWindow(Core::Vector2(t_x+65+75*i, t_y+13), 68 , 71, ui_survival2,Core::Rectangle(0, 0, 1, 1),ARGB(255,255,255,255));   
		}
		int i = 0;
		while(node)
		{
			ui_render->DrawTextureWindow(Core::Vector2((t_x+65+75*i)+5 , t_y+25 ), 52 , 52,RESOURCE_LOAD_NEW(String::Format("InGameUI/survival/icon/%s.dds", node->data.name), true, Texture2D),Core::Rectangle(0, 0, 1, 1),ARGB(255,255,255,255));
			node = node->GetNext();
			i++;
		}
        ui_render->DrawStringShadow(ui_render->font_simhei_16, ARGB(255,229,51), ARGB(0,0,0), ARGB(0, 0, 0, 0), Core::Rectangle(-250+65 , t_y-115 , 100, 20), gLang->GetTextW(L"����Ӧ����ʹ�õ���"), Unit::kAlignLeftMiddle);
		for ( int i = 0; i < 5; i++ )
		{
			ui_render->DrawTextureWindow(Core::Vector2((t_x+68+75*i)+5, t_y+18),20,20,ui_Keying[i],Core::Rectangle(0, 0, 1, 1),ARGB(255,255,255,255));
		}
		ui_render->DrawTextureWindow(Core::Vector2((t_x+185), t_y-750),130,28,ui_survival4,Core::Rectangle(0, 0, 1, 1),ARGB(255,255,255,255));

		CStrBuf<256> buff2;
		buff2.format("%d",(int)play->SurvivalExpose);
		if ( play->SurvivalExpose > 0.0 )
		{
			ui_render->DrawStringShadow(ui_render->font_simhei_16, ARGB(255,229,51), ARGB(0,0,0), ARGB(0, 0, 0, 0), Core::Rectangle(t_x-300, t_y-180, 100, 20),buff2, Unit::kAlignCenterMiddle);
			ui_render->DrawTextureWindow(Core::Vector2((t_x), t_y-100),52,52,ui_survival13,Core::Rectangle(0, 0, 1, 1),ARGB(255,255,255,255));
		}
	} 
}

void InGameUINew::_InitInvincible(by_ptr(UIRender) ui_render)
{	
	Matrix44 oldworld;
	Matrix44 world;
	Matrix44 oldview;
	Matrix44 view;	
	tempc_ptr(Character) viewer = gLevel->GetViewer();
	tempc_ptr(Character) play = gLevel->GetPlayer();
	Vector3 head_pos;
	Quaternion head_rot;
	CStrBuf<256> buff;
	int t_x = -250;
	int t_y = -85;
	if (viewer && play)
	{
		Core::Vector3 rt_size = gGame->guiSys->GetSize();
		world = Core::Matrix44::kIdentity;
		oldworld = ui_render->GetWorld();
		oldview  = ui_render->GetView();
		CStrBuf<256> buff2;
        buff2.format("%d",(int)play->spawntimebySurvival1);
		if ( play->spawntimebySurvival1 > 0.0 )
		{
			ui_render->DrawStringShadow(ui_render->font_simhei_16, ARGB(255,229,51), ARGB(0,0,0), ARGB(0, 0, 0, 0), Core::Rectangle(t_x-180, t_y-180, 100, 20),buff2, Unit::kAlignCenterMiddle);
			ui_render->DrawTextureWindow(Core::Vector2((t_x+60), t_y-100),52,52,ui_survival3,Core::Rectangle(0, 0, 1, 1),ARGB(255,255,255,255));
		}
	}	
}
void InGameUINew::_InitHarmBottmInfo(by_ptr(UIRender) ui_render)
{	
	Matrix44 oldworld;
	Matrix44 world;
	Matrix44 oldview;
	Matrix44 view;	
	tempc_ptr(Character) viewer = gLevel->GetViewer();
	tempc_ptr(Character) play = gLevel->GetPlayer();
	Vector3 head_pos;
	Quaternion head_rot;
	CStrBuf<256> buff;
	int t_x = -250;
	int t_y = -85;
	if (viewer && play)
	{
		Core::Vector3 rt_size = gGame->guiSys->GetSize();
		world = Core::Matrix44::kIdentity;
		oldworld = ui_render->GetWorld();
		oldview  = ui_render->GetView();
		CStrBuf<256> buff2;
		buff2.format("%d",(int)play->spawntimebySurvival2);
		if ( play->spawntimebySurvival2 > 0.0)
		{
			ui_render->DrawStringShadow(ui_render->font_simhei_16, ARGB(255,229,51), ARGB(0,0,0), ARGB(0, 0, 0, 0), Core::Rectangle(t_x-180, t_y-180, 100, 20),buff2, Unit::kAlignCenterMiddle);
			ui_render->DrawTextureWindow(Core::Vector2((t_x+60), t_y-100),52,52,ui_survival9,Core::Rectangle(0, 0, 1, 1),ARGB(255,255,255,255));
		}
		if ( play->spawntimebySurvival2 <= 0  )
		{
			gLevel->audio_Survival1_background->stop(true);
		}
	}	
}
//����
void InGameUINew::_DrawGhostModBottomInfo( by_ptr(UIRender) ui_render )
{
	Matrix44 oldworld;
	Matrix44 world;
	Matrix44 oldview;
	Matrix44 view;	
	tempc_ptr(Character) viewer = gLevel->GetViewer();
	tempc_ptr(Character) play = gLevel->GetPlayer();
	Vector3 head_pos;
	Quaternion head_rot;
	CStrBuf<256> buff;
	int t_x = -250;
	int t_y = -85;
	if (viewer && play)
	{
		Core::Vector3 rt_size = gGame->guiSys->GetSize();
		world = Core::Matrix44::kIdentity;
		oldworld = ui_render->GetWorld();
		oldview  = ui_render->GetView();
		view.SetScaleXYZ(2.0f/rt_size.x, -2.0f/rt_size.y, 0);
		ui_render->SetView(view);
		world.SetTranslationXYZ(0, rt_size.y/2, 0);
		ui_render->SetWorld(world);
		tempc_ptr(Character) play = gLevel->GetPlayer();
		ui_render->DrawTextureWindow(Core::Vector2(t_x-122, t_y-12), 54 , 52,ui_survival[4],Core::Rectangle(0, 0, 1, 1),ARGB(255,255,255,255));
        ui_render->DrawTextureWindow(Core::Vector2(t_x-115, t_y-5), 40 , 40,ui_survival[0],Core::Rectangle(0, 0, 1, 1),ARGB(255,255,255,255));
        //ghostfirecount 
		CStrBuf<256> buff;
		buff.format("%d",(int)play->ghostfirecount);
	    ui_render->DrawStringShadow(ui_render->font_simhei_16, ARGB(255,229,51), ARGB(0,0,0), ARGB(0, 0, 0, 0), Core::Rectangle(-763,   t_y-50, 100, 20),buff, Unit::kAlignCenterMiddle);

        ui_render->DrawTextureWindow(Core::Vector2(t_x+15, t_y-10),260,88,ui_survival1,Core::Rectangle(0, 0, 1, 1),ARGB(255,255,255,255));
		for ( int i = 0; i < 3; i++ )
		{
			ui_render->DrawTextureWindow(Core::Vector2(t_x+35+75*i, t_y-5), 68 , 71, ui_survival2,Core::Rectangle(0, 0, 1, 1),ARGB(255,255,255,255));
			ui_render->DrawTextureWindow(Core::Vector2((t_x+35+75*i)+5, t_y+7),55,55,ui_survival[i+1],Core::Rectangle(0, 0, 1, 1),ARGB(255,128,128,128));
		}
		if( play->ghostfirecount == 15 )
		{
			ui_render->DrawTextureWindow(Core::Vector2((t_x+35+75*0)+5, t_y+7),55,55,ui_survival[1],Core::Rectangle(0, 0, 1, 1),ARGB(255,255,255,255));
		}
		if ( play->ghostfirecount >= 20 )
		{
			ui_render->DrawTextureWindow(Core::Vector2((t_x+35+75*0)+5, t_y+7),55,55,ui_survival[1],Core::Rectangle(0, 0, 1, 1),ARGB(255,255,255,255));
			ui_render->DrawTextureWindow(Core::Vector2((t_x+35+75*1)+5, t_y+7),55,55,ui_survival[2],Core::Rectangle(0, 0, 1, 1),ARGB(255,255,255,255));
			ui_render->DrawTextureWindow(Core::Vector2((t_x+35+75*2)+5, t_y+7),55,55,ui_survival[3],Core::Rectangle(0, 0, 1, 1),ARGB(255,255,255,255));
		}
		ui_render->DrawStringShadow(ui_render->font_simhei_16, ARGB(255,229,51), ARGB(0,0,0), ARGB(0, 0, 0, 0), Core::Rectangle(-250+35,  t_y-140, 100, 20), gLang->GetTextW(L"����Ӧ����ʹ�ü���"), Unit::kAlignLeftMiddle);

		for ( int i = 0; i < 3; i++ )
		{
			ui_render->DrawTextureWindow(Core::Vector2((t_x+40+75*i)+5, t_y),20,20,ui_Keying[i],Core::Rectangle(0, 0, 1, 1),ARGB(255,255,255,255));
		}
        ui_render->DrawStringShadow(ui_render->font_simhei_16, ARGB(255,229,51), ARGB(0,0,0), ARGB(0, 0, 0, 0), Core::Rectangle(-525+35,  t_y+10, 100, 20),buff, Unit::kAlignCenterMiddle);
		ui_render->DrawStringShadow(ui_render->font_simhei_16, ARGB(255,229,51), ARGB(0,0,0), ARGB(0, 0, 0, 0), Core::Rectangle(-375+35,  t_y+10, 100, 20),buff, Unit::kAlignCenterMiddle);
		ui_render->DrawStringShadow(ui_render->font_simhei_16, ARGB(255,229,51), ARGB(0,0,0), ARGB(0, 0, 0, 0), Core::Rectangle(-225+35,   t_y+10, 100, 20),buff, Unit::kAlignCenterMiddle);

		ui_render->DrawStringShadow(ui_render->font_simhei_16, ARGB(255,229,51), ARGB(0,0,0), ARGB(0, 0, 0, 0), Core::Rectangle(-220+35,  t_y+10, 100, 20), gLang->GetTextW(L"/15"), Unit::kAlignLeftMiddle);
		ui_render->DrawStringShadow(ui_render->font_simhei_16, ARGB(255,229,51), ARGB(0,0,0), ARGB(0, 0, 0, 0), Core::Rectangle(-145+35,  t_y+10, 100, 20), gLang->GetTextW(L"/20"), Unit::kAlignLeftMiddle);
		ui_render->DrawStringShadow(ui_render->font_simhei_16, ARGB(255,229,51), ARGB(0,0,0), ARGB(0, 0, 0, 0), Core::Rectangle(-70+35,   t_y+10, 100, 20), gLang->GetTextW(L"/20"), Unit::kAlignLeftMiddle);

		ui_render->DrawStringShadow(ui_render->font_simhei_16, ARGB(255,229,51), ARGB(0,0,0), ARGB(0, 0, 0, 0), Core::Rectangle(70,  t_y-150, 100, 20), gLang->GetTextW(L"����"), Unit::kAlignLeftMiddle);
		ui_render->DrawTextureWindow(Core::Vector2((t_x+310), t_y),55,55,ui_survival5,Core::Rectangle(0, 0, 1, 1),ARGB(255,255,255,255));
		ui_render->DrawTextureWindow(Core::Vector2((t_x+300), t_y-5),68,71,ui_survival2,Core::Rectangle(0, 0, 1, 1),ARGB(255,255,255,255));

		CStrBuf<256> buff2;
		buff2.format("%d",(int)play->spawntimebySurvival);
		ui_render->DrawStringShadow(ui_render->font_simhei_38, ARGB(255,229,51), ARGB(0,0,0), ARGB(0, 0, 0, 0), Core::Rectangle(t_x+320, t_y-50, 100, 20),buff2, Unit::kAlignCenterMiddle);

		ui_render->DrawTextureWindow(Core::Vector2((t_x+185), t_y-750),130,28,ui_survival4,Core::Rectangle(0, 0, 1, 1),ARGB(255,255,255,255));
		play->SurvivalExpose = 0;
	}
}
void InGameUINew::_DrawTrapQuantityBottmInfo(by_ptr(UIRender) ui_render)
{
	Matrix44 oldworld;
	Matrix44 world;
	Matrix44 oldview;
	Matrix44 view;

	tempc_ptr(Character) viewer = gLevel->GetViewer();
	tempc_ptr(Character) play = gLevel->GetPlayer();
	Vector3 head_pos;
	Quaternion head_rot;
	int t_x = -250;
	int t_y = -85;
	int trapQuantity = 0;
	if (viewer && play)
	{
		Core::Vector3 rt_size = gGame->guiSys->GetSize();
		world = Core::Matrix44::kIdentity;
		oldworld = ui_render->GetWorld();
		oldview  = ui_render->GetView();
		view.SetScaleXYZ(2.0f/rt_size.x, -2.0f/rt_size.y, 0);
		ui_render->SetView(view);
		world.SetTranslationXYZ(0, rt_size.y/2, 0);
		ui_render->SetWorld(world);
		tempc_ptr(Character) play = gLevel->GetPlayer();
		CStrBuf<256> buff;
		for (uint i = 0; i < gLevel->trap_info.Size(); i++)
		{
			tempc_ptr(Character) c = gLevel->GetCharacter(gLevel->trap_info[i].uid);
           if ( play == c && gLevel->trap_info[i].time > 0 )
           {
              trapQuantity++;
           }
		}
		buff.format("%d",trapQuantity);
		ui_render->DrawStringShadow(ui_render->font_SHOWG_24, ARGB(255,244,223), ARGB(0,0,0), ARGB(0, 0, 0, 0), Core::Rectangle(-600 ,  t_y-55 ,100, 20),buff, Unit::kAlignCenterMiddle);
		ui_render->DrawTextureWindow(Core::Vector2((t_x-60), t_y-10),52,52,ui_survival10,Core::Rectangle(0, 0, 1, 1),ARGB(255,255,255,255));
	}	
}
void InGameUINew::_DrawSurvivalQuantityBottmInfo( by_ptr(UIRender) ui_render)
{
	Matrix44 oldworld;
	Matrix44 world;
	Matrix44 oldview;
	Matrix44 view;	
	tempc_ptr(Character) viewer = gLevel->GetViewer();
	tempc_ptr(Character) play = gLevel->GetPlayer();
	Vector3 head_pos;
	Quaternion head_rot;
	int t_x = -250;
	int t_y = -85;
	int AmountHp = 0;
	int AmountAmmo = 0;
	if (viewer && play)
	{
		Core::Vector3 rt_size = gGame->guiSys->GetSize();
		world = Core::Matrix44::kIdentity;
		oldworld = ui_render->GetWorld();
		oldview  = ui_render->GetView();
		view.SetScaleXYZ(2.0f/rt_size.x, -2.0f/rt_size.y, 0);
		ui_render->SetView(view);
		world.SetTranslationXYZ(0, rt_size.y/2, 0);
		ui_render->SetWorld(world);
		tempc_ptr(Character) play = gLevel->GetPlayer();
	
		if ( play->Survivalprompting1> 0.f  )
		{
			ui_render->DrawTextureWindow(Core::Vector2((t_x-100), t_y-690),800,232,ui_survival11,Core::Rectangle(0, 0, 1, 1),ARGB(180,255,255,255));
		}
		if( play->Survivalprompting > 0.f )
		{
		   ui_render->DrawTextureWindow(Core::Vector2((t_x-100), t_y-670),800,232,ui_survival12,Core::Rectangle(0, 0, 1, 1),ARGB(150,255,255,255));
		}
	}
}

void InGameUINew::_DrawQuantityBottmInfo( by_ptr(UIRender) ui_render)
{
	Matrix44 oldworld;
	Matrix44 world;
	Matrix44 oldview;
	Matrix44 view;	
	tempc_ptr(Character) viewer = gLevel->GetViewer();
	tempc_ptr(Character) play = gLevel->GetPlayer();
	Vector3 head_pos;
	Quaternion head_rot;
	int t_x = -250;
	int t_y = -85;
	int AmountHp = 0;
	int AmountAmmo = 0;
	if (viewer && play)
	{
		Core::Vector3 rt_size = gGame->guiSys->GetSize();
		world = Core::Matrix44::kIdentity;
		oldworld = ui_render->GetWorld();
		oldview  = ui_render->GetView();
		view.SetScaleXYZ(2.0f/rt_size.x, -2.0f/rt_size.y, 0);
		ui_render->SetView(view);
		world.SetTranslationXYZ(0, rt_size.y/2, 0);
		ui_render->SetWorld(world);
		tempc_ptr(Character) play = gLevel->GetPlayer();
		tempc_ptr (Character) c = gLevel->GetPlayer();
		CStrBuf<256> buff;
		CStrBuf<256> buff1;
		for(uint i = 0 ; i < gLevel->pickup_manager->pick_up_set.Size(); i ++)
		{
			sharedc_ptr(PickUpManager::PickUpObject) Object = gLevel->pickup_manager->pick_up_set[i];

			if ( Object->SType == PickUpManager::kSupplySurvivalItemHp)
			{
				AmountHp++;
			}
			if (Object->SType == PickUpManager::kSupplySurvivalItemAmmo )
			{
				AmountAmmo++;
			}
		}
		buff.format("%d",AmountHp);
        buff1.format("%d",AmountAmmo);

		ui_render->DrawTextureWindow(Core::Vector2(100+350 ,t_y-80),130,48,ui_survival6,Core::Rectangle(0, 0, 1, 1),ARGB(255,255,255,255));
		ui_render->DrawTextureWindow(Core::Vector2(100+350 ,t_y-40),130,48,ui_survival7,Core::Rectangle(0, 0, 1, 1),ARGB(255,255,255,255));

		ui_render->DrawStringShadow(ui_render->font_simhei_20, ARGB(255,244,223), ARGB(0,0,0), ARGB(0, 0, 0, 0), Core::Rectangle(100+390 ,  t_y-218 ,100, 20), gLang->GetTextW(L"ʣ�ࣺ"), Unit::kAlignLeftMiddle);
		ui_render->DrawStringShadow(ui_render->font_simhei_20, ARGB(255,244,223), ARGB(0,0,0), ARGB(0, 0, 0, 0), Core::Rectangle(100+390 ,  t_y-139 , 100, 20), gLang->GetTextW(L"ʣ�ࣺ"), Unit::kAlignLeftMiddle);
		ui_render->DrawStringShadow(ui_render->font_SHOWG_24, ARGB(255,244,223), ARGB(0,0,0), ARGB(0, 0, 0, 0), Core::Rectangle(100+900 ,  t_y-215 ,100, 20),buff, Unit::kAlignCenterMiddle);
		ui_render->DrawStringShadow(ui_render->font_SHOWG_24, ARGB(255,244,223), ARGB(0,0,0), ARGB(0, 0, 0, 0), Core::Rectangle(100+900 ,  t_y-136 , 100, 20),buff1, Unit::kAlignCenterMiddle);
	}	
}
void InGameUINew::_DrawGhostQuantityBottmInfo( by_ptr(UIRender) ui_render)
{
	Matrix44 oldworld;
	Matrix44 world;
	Matrix44 oldview;
	Matrix44 view;	
	tempc_ptr(Character) viewer = gLevel->GetViewer();
	tempc_ptr(Character) play = gLevel->GetPlayer();
	Vector3 head_pos;
	Quaternion head_rot;
	int t_x = -250;
	int t_y = -85;
	int GhostFire = 0;
	
	if (viewer && play)
	{
		Core::Vector3 rt_size = gGame->guiSys->GetSize();
		world = Core::Matrix44::kIdentity;
		oldworld = ui_render->GetWorld();
		oldview  = ui_render->GetView();
		view.SetScaleXYZ(2.0f/rt_size.x, -2.0f/rt_size.y, 0);
		ui_render->SetView(view);
		world.SetTranslationXYZ(0, rt_size.y/2, 0);
		ui_render->SetWorld(world);
		tempc_ptr(Character) play = gLevel->GetPlayer();
		tempc_ptr (Character) c = gLevel->GetPlayer();
		CStrBuf<256> buff;
		for(uint i = 0 ; i < gLevel->pickup_manager->pick_up_set.Size(); i ++)
		{
			sharedc_ptr(PickUpManager::PickUpObject) Object = gLevel->pickup_manager->pick_up_set[i];

			if ( Object->SType == PickUpManager::kSupplySurvivalItemGhostFire)
			{
				GhostFire++;
			}
		}
		buff.format("%d",GhostFire);
		ui_render->DrawTextureWindow(Core::Vector2(100+350 ,t_y-40),130,48,ui_survival8,Core::Rectangle(0, 0, 1, 1),ARGB(255,255,255,255));
		ui_render->DrawStringShadow(ui_render-> font_simhei_20, ARGB(255,244,223), ARGB(0,0,0), ARGB(0, 0, 0, 0), Core::Rectangle(100+390 ,  t_y-128 ,100, 20), gLang->GetTextW(L"ʣ�ࣺ"), Unit::kAlignLeftMiddle);
		ui_render->DrawStringShadow(ui_render->font_SHOWG_24, ARGB(255,244,223), ARGB(0,0,0), ARGB(0, 0, 0, 0), Core::Rectangle(100+900 ,  t_y-128 , 100, 20),buff, Unit::kAlignCenterMiddle);
	} 
}


void InGameUINew::_DrawLivePromptBottmInfo( by_ptr(UIRender) ui_render)
{
	Matrix44 oldworld;
	Matrix44 world;
	Matrix44 oldview;
	Matrix44 view; 


	Core::Vector3 rt_size = gGame->guiSys->GetSize();
	Game * game = gGame;


	tempc_ptr(Character) viewer = gLevel->GetViewer();
	tempc_ptr(Character) play = gLevel->GetPlayer();
	Vector3 head_pos;
	Quaternion head_rot;
	int t_x = -250;
	int t_y = -85;
	int team = play->GetTeam();
	int RelLive = 0;
	int Bluelive = 0;
	if (viewer && play)
	{
		Core::Vector3 rt_size = gGame->guiSys->GetSize();
		world = Core::Matrix44::kIdentity;
		oldworld = ui_render->GetWorld();
		oldview  = ui_render->GetView();
		view.SetScaleXYZ(2.0f/rt_size.x, -2.0f/rt_size.y, 0);
		ui_render->SetView(view);
		world.SetTranslationXYZ(0, rt_size.y/2, 0);
		ui_render->SetWorld(world);
		tempc_ptr(Character) play = gLevel->GetPlayer();
		tempc_ptr (Character) c = gLevel->GetPlayer();
		CStrBuf<256> buff;
		CStrBuf<256> buff1;

		for (uint rank = 0; rank < game->scores->teams[0].Size(); rank ++)
		{
			Character * c = game->scores->teams[0][rank];
			if ( !c->IsDied() && c->isghost == false||c->spawntimebySurvival< 0 )
			{
				RelLive++;
			}
		}
		for (uint rank = 0; rank < game->scores->teams[1].Size(); rank ++)
		{
			Character * c = game->scores->teams[1][rank];
			if ( !c->IsDied() && c->isghost == false||c->spawntimebySurvival< 0 )
			{
				Bluelive++;
			}
		}
		buff.format("%d",RelLive);
		buff1.format("%d",Bluelive);	
		ui_render->DrawStringShadow(ui_render->font_simhei_16, ARGB(255,244,223), ARGB(0,0,0), ARGB(0, 0, 0, 0), Core::Rectangle((t_x+70), t_y-1575, 100, 20),buff, Unit::kAlignCenterMiddle);
		ui_render->DrawStringShadow(ui_render->font_simhei_16, ARGB(255,244,223), ARGB(0,0,0), ARGB(0, 0, 0, 0), Core::Rectangle((t_x+240), t_y-1575 , 100, 20),buff1, Unit::kAlignCenterMiddle);
	} 
}


void InGameUINew::_DrawAdvenceModeBottomInfo(by_ptr(UIRender) ui_render)
{
	Matrix44 oldworld;
	Matrix44 world;
	Matrix44 oldview;
	Matrix44 view;	
	tempc_ptr(Character) viewer = gLevel->GetViewer();
	tempc_ptr(Character) play = gLevel->GetPlayer();
	Vector3 head_pos;
	Quaternion head_rot;
	CStrBuf<256> buff;
	int t_x = -250;
	int t_y = -85;
	if (viewer && play)
	{
		Core::Vector3 rt_size = gGame->guiSys->GetSize();
		world = Core::Matrix44::kIdentity;
		oldworld = ui_render->GetWorld();
		oldview  = ui_render->GetView();
		view.SetScaleXYZ(2.0f/rt_size.x, -2.0f/rt_size.y, 0);
		ui_render->SetView(view);
		world.SetTranslationXYZ(0, rt_size.y/2, 0);
		ui_render->SetWorld(world);
		tempc_ptr(Character) play = gLevel->GetPlayer();
		
		for(int i = 0 ; i < 4 ; i++)
		{
			int offset = 0;
			if (play->advBoxTime[i] < 0.5f)
			{
				if (play->advBoxTime[i] > 0.f)
				{
					if (play->advBoxTime[i] > 0.25f)
					{
						offset = (int)((0.5f - play->advBoxTime[i])*30 * 8);
					}
					else
					{
						offset = (int)(play->advBoxTime[i]*30 * 8);
					}
				}
			}
			ui_render->DrawTextureWindow(Core::Vector2(t_x+40+130*i - offset / 4, t_y+30 - offset / 4), 50 + offset / 2, 50 + offset / 2,ui_moon_score[i],Core::Rectangle(0, 0, 1, 1),ARGB(255,255,255,255));
			if (i == 0)
			{
				buff.format("%d",play->advBoxNum[i] * 3000);
			}
			else
			{
				buff.format("%d",play->advBoxNum[i]);
			}
			ui_render->DrawFontWindow(Core::Vector2(t_x+100+130*i , t_y+40), 109, 30, ui_render->font_simhei_20, ARGB(255,255,255), ARGB(0, 0, 0, 0), buff, Unit::kAlignLeftMiddle);
		}
	}
}

void InGameUINew::_DrawMoonModeBottomInfo(by_ptr(UIRender) ui_render)
{
	Matrix44 oldworld;
	Matrix44 world;
	Matrix44 oldview;
	Matrix44 view;	
	tempc_ptr(Character) viewer = gLevel->GetViewer();
	tempc_ptr(Character) play = gLevel->GetPlayer();
	Vector3 head_pos;
	Quaternion head_rot;
	CStrBuf<256> buff;
	int t_x = -250;
	int t_y = -85;
	if (viewer && play)
	{
		Core::Vector3 rt_size = gGame->guiSys->GetSize();
		world = Core::Matrix44::kIdentity;
		oldworld = ui_render->GetWorld();
		oldview  = ui_render->GetView();

		view.SetScaleXYZ(2.0f/rt_size.x, -2.0f/rt_size.y, 0);
		ui_render->SetView(view);
		world.SetTranslationXYZ(0, rt_size.y/2, 0);
		ui_render->SetWorld(world);

		tempc_ptr(Character) play = gLevel->GetPlayer();

		for(int i = 0 ; i < 5 ; i++)
		{
			ui_render->DrawTextureWindow(Core::Vector2(t_x+40+130*i , t_y+30),50,50,ui_moon_score[i]);
			buff.format("%d",MOONSCORE[i]);
			ui_render->DrawFontWindow(Core::Vector2(t_x+100+130*i , t_y+40), 109, 30, ui_render->font_simhei_20, ARGB(255,255,255), ARGB(0, 0, 0, 0), buff, Unit::kAlignLeftMiddle);
		}

		for(int i = 0 ; i < (int)gLevel->moon_mode_win_list.Size() ; i++)
		{
			ui_render->DrawFontWindow(Core::Vector2(t_x+13+130*i , t_y), 109, 30, ui_render->font_simhei_20, ARGB(255,229,51), ARGB(0, 0, 0, 0), PeopleName_cut(gLevel->moon_mode_win_list[i],4), Unit::kAlignCenterMiddle);
		}

		if (play->IsDied())
		{
			return;
		}
		if (play->is_item_boss)
		{
			return;
		}

		if(play->isMoonBoss == false)
		{
			ui_render->DrawStringShadow(ui_render->font_simhei_16, ARGB(255,229,51), ARGB(0,0,0), ARGB(0, 0, 0, 0), Core::Rectangle(t_x-130 , t_y-200 , 100, 20), gLang->GetTextW(L"��[E]ʹ�õ���"), Unit::kAlignLeftMiddle);
			_DrawInitiativeSkill(ui_render,Core::Vector2(t_x-100 , t_y-30),ui_commonzombie_Key_E,ui_itemmode_Skill_ico[14],ui_commonzombie_Skill_Shine,ui_commonzombie_Skill_bg,ui_commonzombie_Skill_bf);
		}
	}
}

void InGameUINew::_DrawCommonZombieBottomInfo(by_ptr(UIRender) ui_render)
{
	Matrix44 oldworld;
	Matrix44 world;
	Matrix44 oldview;
	Matrix44 view;	
	tempc_ptr(Character) viewer = gLevel->GetViewer();
	tempc_ptr(Character) play = gLevel->GetPlayer();
	if (viewer && play)
	{
		Core::Vector3 rt_size = gGame->guiSys->GetSize();
		world = Core::Matrix44::kIdentity;
		oldworld = ui_render->GetWorld();
		oldview  = ui_render->GetView();

		view.SetScaleXYZ(2.0f/rt_size.x, -2.0f/rt_size.y, 0);
		ui_render->SetView(view);
		world.SetTranslationXYZ(0, rt_size.y/2, 0);
		ui_render->SetWorld(world);
		if (play->character_info && play->character_info->career_id == DEFAULT_COMMONZOMBIE_KING)
		{
			_DrawCommonZombieBottomMaps(ui_render,ui_commonzombie_Corpse_Mum,ui_commonzombie_Corpse_Mum_Disable,1);
		}
		else if (play->character_info && play->character_info->career_id == DEFAULT_COMMONZOMBIE_COM)
		{
			_DrawCommonZombieBottomMaps(ui_render,ui_commonzombie_Corpse_Child,ui_commonzombie_Corpse_Child_Disable);
		}
		if (play->character_info && play->character_info->career_id == DEFAULT_COMMONZOMBIE_KING && play->common_zombie_dying_flag)
		{
			_DrawCommonZombieBottomdying(ui_render);
		}
		if (play->GetTeam() == 0 && !play->IsDied() && !play->is_human_super)
		{
			_DrawCommonZombieBottom_PeopleImage(ui_render);
		}
		_DrawCommonZombie_Level_up(ui_render,Core::Vector2(-185 + 134*play->common_zombie_level,-123),Core::Vector2(150,146),200,m_commonzombie_level_isup_time[0]);
		
		ui_render->SetWorld(oldworld);
		ui_render->SetView(oldview);
	}
}

void InGameUINew::_DrawCommonZombieBottomMaps(by_ptr(UIRender) ui_render,sharedc_ptr(Texture2D)* Maps,sharedc_ptr(Texture2D)* Maps_Disable,int index)
{
	tempc_ptr(Character) play = gLevel->GetPlayer();
	if (play->IsDied())
	{
		return;
	}
	int t_x = -150;
	int t_y = -90;
	int size_min_w = 20;
	int size_min_h = 20;
	int size_max_w = 200;
	int size_max_h = 200;
	float point_time = 0.5f;
	float tiem_perent = m_commonzombie_level_isup_time[0]/point_time;
	int size_x = size_min_w + (80 - size_min_w)*tiem_perent;
	int size_y = size_min_h + (80 - size_min_h)*tiem_perent;
	if (m_commonzombie_level_isup_time[0] > point_time)
	{
		tiem_perent = (m_commonzombie_level_isup_time[0] - point_time)/(1.0f - point_time);
		size_x = 80 + (size_max_w - 80)*tiem_perent;
		size_y = 80 + (size_max_h - 80)*tiem_perent;
	} 
	else
	{
		tiem_perent = m_commonzombie_level_isup_time[0]/point_time;
		size_x = size_min_w + (80 - size_min_w)*tiem_perent;
		size_y = size_min_h + (80 - size_min_h)*tiem_perent;
	}
	float f_u = play->common_zombie_energy_percent;
	int t_lev = play->common_zombie_level;
	ui_render->DrawTextureWindow(Core::Vector2(t_x + 50,t_y + 22),108,44,ui_commonzombie_bottom_bg);
	if (t_lev < 1 && f_u > 0.0f)
		ui_render->DrawTextureWindow(Core::Vector2(t_x + 50,t_y + 22),108*f_u,44,ui_commonzombie_bottom_bf[index],Core::Rectangle(0,0,f_u,1));
	else if (t_lev >= 1)
		ui_render->DrawTextureWindow(Core::Vector2(t_x + 50,t_y + 22),108,44,ui_commonzombie_bottom_bf[index]);
	ui_render->DrawTextureWindow(Core::Vector2(t_x + 184,t_y + 22),108,44,ui_commonzombie_bottom_bg);
	if (t_lev >= 1 && f_u > 0.0f)
		ui_render->DrawTextureWindow(Core::Vector2(t_x + 184,t_y + 22),108*f_u,44,ui_commonzombie_bottom_bf[index],Core::Rectangle(0,0,f_u,1));
	else if (t_lev == 2)
		ui_render->DrawTextureWindow(Core::Vector2(t_x + 184,t_y + 22),108,44,ui_commonzombie_bottom_bf[index]);
	if (t_lev < 1 && f_u > 0.0f)
		ui_render->DrawTextureWindow(Core::Vector2(t_x + 50 + 108*f_u - 8,t_y + 20),16,48,ui_commonzombie_Shine[index]);
	else if (t_lev < 2 && f_u > 0.0f)
		ui_render->DrawTextureWindow(Core::Vector2(t_x + 184 + 108*f_u - 8,t_y + 20),16,48,ui_commonzombie_Shine[index]);
	ui_render->DrawTextureWindow(Core::Vector2(t_x,t_y),80,80,Maps_Disable[0]);
	if (t_lev >= 0)
		ui_render->DrawTextureWindow(Core::Vector2(t_x,t_y),80,80,Maps[0]);		
	ui_render->DrawTextureWindow(Core::Vector2(t_x + 134,t_y),80,80,Maps_Disable[1]);
	if (t_lev >= 1)
	{
		if (t_lev == 1 && m_commonzombie_level_isup_time[0] < 1.0f && m_commonzombie_level_isup_time[0] > point_time)
		{
			ui_render->DrawTextureWindow(Core::Vector2(t_x + 134 + (80 - size_x)/2,t_y + (80 - size_y)/2),size_x,size_y,Maps[1],Core::Rectangle(0,0,1,1),Core::ARGB(100*(1- (m_commonzombie_level_isup_time[0] - point_time)/(1.0 - point_time)),255,255,255));
		}
		if (t_lev == 1 && m_commonzombie_level_isup_time[0] <= point_time)
		{
			ui_render->DrawTextureWindow(Core::Vector2(t_x + 134 + (80 - size_x)/2,t_y + (80 - size_y)/2),size_x,size_y,Maps[1]);
		}
		else
		{
			ui_render->DrawTextureWindow(Core::Vector2(t_x + 134,t_y),80,80,Maps[1]);
		}
	}
	ui_render->DrawTextureWindow(Core::Vector2(t_x + 268,t_y),80,80,Maps_Disable[2]);	
	if (t_lev >= 2)
	{
		if (t_lev == 2 && m_commonzombie_level_isup_time[0] < 1.0f && m_commonzombie_level_isup_time[0] > point_time)
		{
			ui_render->DrawTextureWindow(Core::Vector2(t_x + 268 + (80 - size_x)/2,t_y + (80 - size_y)/2),size_x,size_y,Maps[2],Core::Rectangle(0,0,1,1),Core::ARGB(100*(1- (m_commonzombie_level_isup_time[0] - point_time)/(1.0 - point_time)),255,255,255));
		}
		if (t_lev == 2 && m_commonzombie_level_isup_time[0] <= point_time)
		{
			ui_render->DrawTextureWindow(Core::Vector2(t_x + 268 + (80 - size_x)/2,t_y + (80 - size_y)/2),size_x,size_y,Maps[2]);
		}
		else
		{
			ui_render->DrawTextureWindow(Core::Vector2(t_x + 268,t_y),80,80,Maps[2]);
		}
	}	
}
void InGameUINew::_Draw_Die_Buff_Rand(by_ptr(UIRender) ui_render)
{
	tempc_ptr(Character) player = gLevel->GetPlayer();
	if(!player || player->IsDied() ) return;

	Core::Vector3 rt_size = gGame->guiSys->GetSize();
	Matrix44 oldworld = ui_render->GetWorld();
	Matrix44 world = Core::Matrix44::kIdentity;
	world.SetTranslationXYZ(0, 0, 0);
	ui_render->SetWorld(world);

	const float w =112;
	const float h =115;
	const int iRanding =player->GetRandingDieBuff();
	if(iRanding != -1 && iRanding<(int)DieBuff.Size())
	{
		const float fOffectFactor =(1.f - player->GetDieBuffGapTimer() / DIE_BUFF_RAND_GAP_TIME);
		const int N =5;
		if(0 == fOffectFactor)
		{
			float fX =-N / 2.f * w;
			float fY =-h / 2.f;
			for(int i=0; i< N; ++i)
			{
				const int iIdx =(iRanding+i)%player->GetDieBuffTotalCount();
				const int iAlpha =255 - abs(i - (N/2)) * 100;
				ui_render->DrawTextureWindow(Core::Vector2(fX,fY),w,h,DieBuff[iIdx], Core::Rectangle(0,0,1,1), ARGB(iAlpha, 255,255,255));
				fX += w;
			}
		}
		else
		{
			float fU =0;
			float fV =0;
			float fX =-N / 2.f * w - fOffectFactor*w;
			float fY =-h / 2.f;
			for(int i=0; i<= N; ++i)
			{
				//rect
				Vector2 pos(fX, fY), size(w, h);

				if(0 == i){
					pos.x =pos.x + fOffectFactor*w;
					size.x =(1.f-fOffectFactor)*w;
				}
				else if(N == i)
				{
					size.x =fOffectFactor*w;
				}

				//uv
				Core::Rectangle uv(0,0,1,1);
				if(0 == i){
					uv =Core::Rectangle(fOffectFactor,0,1,1);
				}
				else if(N == i)
				{
					uv =Core::Rectangle(0,0,fOffectFactor,1);
				}

				//index
				const int iIdx =(iRanding+i)%player->GetDieBuffTotalCount();
				
				//alpha
				const int iAlpha =255;// - abs(i - (N/2)) * 100;

				//draw
				ui_render->DrawTextureWindow(pos, size.x, size.y, DieBuff[iIdx], uv, ARGB(iAlpha, 255,255,255));
				
				//forward
				fX += w;
			}
		}

	}

	const int iStaying =player->GetStayDieBuff();
	if(iStaying != -1 && iStaying<(int)DieBuffDesc.Size())
	{
		//rect
		const float fStayTimerFactor =(1 - player->GetDieBuffStayTimer()/DIE_BUFF_STAY_TIME);
		const float fW =w * (fStayTimerFactor<=0.5f ? (1+fStayTimerFactor) : (2-fStayTimerFactor));
		const float fH =h * (fStayTimerFactor<=0.5f ? (1+fStayTimerFactor) : (2-fStayTimerFactor));

		//desc
		String szDesc;
		DieBuffDescString& oDesc =DieBuffDesc[iStaying];
		const float fVal =gLevel->die_buff_data[iStaying].value;
		if(oDesc.Desc[0] == L'$')
		{
			DieBuffDescString oTmp;
			wcscpy_s(oTmp.Desc, oDesc.Desc+1);
			szDesc =String::Format(gLang->GetTextW(oTmp.Desc), (int)(fVal*(player->GetDieBuffCounter() * 0.1f + 1.f)));
		}
		else
		{
			szDesc =gLang->GetTextW(oDesc.Desc);
		}

		//draw
		ui_render->DrawTextureWindow(Core::Vector2(-fW / 2.f,-fH / 2.f),fW,fH,DieBuff[iStaying]);
		ui_render->DrawStringShadow(ui_render->font_simhei_24, Core::ARGB(255,0,255,255), ARGB(255,0,0,0), Core::ARGB(0,0,0,0), Core::Rectangle(-fW / 2.f,fH / 2.f, fW / 2.f, fH), szDesc, Unit::kAlignCenterMiddle);
	}

	if(player->IsDieBuffAffecting())
	{
		Vector3 scr_size =gGame->guiSys->GetSize();
		const int iTimer =(int)player->GetDieBuffAffectTimer();
		const int iAffect =player->GetDieBuffAffect();
		ui_render->DrawTextureWindow(Core::Vector2(-w/2,-scr_size.y/2.f+100.f),w,h,DieBuff[iAffect]);
		ui_render->DrawStringShadow(ui_render->font_simhei_24, Core::ARGB(255,0,255,255), ARGB(255,0,0,0), Core::ARGB(0,0,0,0), Core::Rectangle(-w/2, -scr_size.y/2.f+h+105.f, w/2, -scr_size.y/2.f+h+129.f), String::Format("%d", iTimer), Unit::kAlignCenterMiddle);
	}
	ui_render->SetWorld(oldworld);
}

void InGameUINew::_DrawCommonZombieBottomdying(by_ptr(UIRender) ui_render)
{
	tempc_ptr(Character) player = gLevel->GetPlayer();
	float bomb_time;
	if (player->commonzombie_dying_totletime > 0)
	{
		bomb_time = player->commonzombie_dying_time/player->commonzombie_dying_totletime;
	}
	else
	{
		return;
	}
	if (bomb_time > 1.0f)
	{
		bomb_time = 1.0f;
	}
	int t_x = -143;
	int t_y = -300;
	ui_render->SetTexture(ui_bomb_defuse_course);
	ui_render->DrawWindow(Core::Rectangle(t_x,t_y,-t_x,t_y + 64),Core::Rectangle(26,0,26,0),Core::Rectangle(26.f/92.f,0.f/64.f,26.f/92.f,0.f/64.f));
	ui_render->DrawTextureWindow(Core::Vector2(t_x + 13,t_y + 17),20.f + 235.f*bomb_time,28,ui_zombie_poeple_hp_bar,Core::Rectangle(0,0,(20.f + bomb_time*235.f)/255.f,1));
	ui_render->DrawTextureWindow(Core::Vector2(t_x + 11 + bomb_time*224 - 6,t_y + 11 - 6),52,52,ui_zombie_poeple_bar_icon);
	ui_render->DrawStringShadow(ui_render->font_simhei_24, Core::ARGB(255,255,128,4), ARGB(255,0,0,0), Core::ARGB(0,0,0,0), Core::Rectangle(t_x,t_y + 70,-t_x,t_y + 100), gLang->GetTextW(L"������..."), Unit::kAlignCenterMiddle);
	ui_render->DrawStringShadow(ui_render->font_simhei_20, Core::ARGB(255,255,187,4), ARGB(255,0,0,0), Core::ARGB(0,0,0,0), Core::Rectangle(t_x - 100,t_y + 110,-t_x + 100,t_y + 135), gLang->GetTextW(L"�㴦�ڱ���״̬����ȴ������ۻظ�"), Unit::kAlignCenterMiddle);
	ui_render->DrawStringShadow(ui_render->font_simhei_20, Core::ARGB(255,255,2,2), ARGB(255,0,0,0), Core::ARGB(0,0,0,0), Core::Rectangle(t_x - 20,t_y + 145,-t_x + 100,t_y + 170), gLang->GetTextW(L"��ע�⣺����ʱ����ֵ����0��ʱ�򽫻�����"), Unit::kAlignLeftMiddle);
	ui_render->DrawTextureWindow(Core::Vector2(t_x - 55,t_y + 143),33,28,ui_commonzombie_bottom_warning);
}


void InGameUINew::_DrawCommonZombieBottom_PeopleImage(by_ptr(UIRender) ui_render)
{
	tempc_ptr(Character) play = gLevel->GetPlayer();
	if (play->IsDied())
	{
		return;
	}
	int t_x = -250;
	int t_y = -85;
	float energy_f;
	ui_render->DrawTextureWindow(Core::Vector2(t_x , t_y),479,80,ui_commonzombie_People_bottom_bg);
	if (play->human_energy >= CommonZombie_People_energy && m_Commonzombie_energy_time > 0.0f)
	{
		if (m_Commonzombie_energy_time == CommonZombie_energy_totle_time)
		{
			m_Showmiddle_str_time = 3.0f;
			m_Middle_str = gLang->GetTextW(L"������˿���״̬��");
		}
		energy_f = (float)m_Commonzombie_energy_time/CommonZombie_energy_totle_time;
		m_Commonzombie_energy_time -= Task::GetFrameTime();
	} 
	else
	{
		if (m_Commonzombie_energy_time <= 0.0f)
		{
			play->human_energy = 0;
		}
		if (m_Commonzombie_energy_time != CommonZombie_energy_totle_time)
			m_Commonzombie_energy_time = CommonZombie_energy_totle_time;
		energy_f = (float)play->human_energy/CommonZombie_People_energy;		
	}
	ui_render->DrawTextureWindow(Core::Vector2(t_x + 115, t_y + 34), 398*energy_f, 26, ui_commonzombie_People_bottom_energy_f,Core::Rectangle(0,0,energy_f,1));
	ui_render->SetTexture(ui_head_info_bg_Bos_hp_bg);
	ui_render->DrawWindow(Core::Rectangle(t_x + 112,t_y + 34,t_x + 112 + 404,t_y + 34 + 26),Core::Rectangle(132, 0, 143, 0),Core::Rectangle(132.f/493.f, 0.f/26.f, 143.f/493.f, 0.f/26.f));
	if (m_Commonzombie_energy_time > 0.0f && m_Commonzombie_energy_time < 10.0f)
	{
		float f_Frame = 1.0f;
		float bg_af = m_Commonzombie_energy_time*(1.0f/f_Frame) - (int)(m_Commonzombie_energy_time*(1.0f/f_Frame));
		if (bg_af/f_Frame > 0.5f)
			bg_af = 2.0f*(f_Frame - bg_af);
		else
			bg_af = 2.0f*bg_af;
		ui_render->DrawTextureWindow(Core::Vector2(t_x + 115, t_y + 34), 398, 26, ui_commonzombie_People_bottom_energy_shine,Core::Rectangle(0,0,1,1),Core::ARGB(255*bg_af,255,255,255));
	}
}

void InGameUINew::_DrawCommonZombie_Level_up(by_ptr(UIRender) ui_render,Core::Vector2 pos,Core::Vector2 _size,int _len,F32& _time)
{
	bool flag = false;
	tempc_ptr(Character) play = gLevel->GetPlayer();
	for (uint i = 0; i < play->basecharacter_info->item_set.Size(); ++i)
	{
		if (play->basecharacter_info->item_set[i].type == 51)
		{
			flag = true;
		}
	}
	if(flag)
	{
		return;
	}

	if (_time >= 1.0f)
	{
		_time = 1.0f;
		return;
	}
	float f_af = Core::Clamp(_time, 0, 1);
	if (play && !play->IsDied())
	{
		ui_render->DrawTextureWindow(Core::Vector2(pos.x,pos.y - _len*_time),_size.x,_size.y,ui_commonzombie_Level_up,Core::Rectangle(0,0,1,1),Core::ARGB(255*f_af,255,255,255));
	}
}

void InGameUINew::_DrawBossMode2_Picture_Shine(by_ptr(UIRender) ui_render,Core::Vector2 pos,Core::Vector2 _size,by_ptr(Texture2D) texture_ui)
{
	if(m_boss_mode2_shine_time == 0.0f || m_boss_mode2_shine_time_space == 0.0f)
	{
		return;
	}
	if (m_boss_mode2_shine_time < 0.0f)
	{
		m_boss_mode2_shine_time = 0.0f;
		m_boss_mode2_shine_time_space = 0.0f; 
		return;
	}
	int time_space = 100*m_boss_mode2_shine_time_space;
	F32 tiem_middle = time_space/2;
	int time_data = int(m_boss_mode2_shine_time*100) % time_space;
	F32 a_f = 0.0f;
	if (time_data > tiem_middle)
	{
		a_f = (float)(time_data -tiem_middle) / tiem_middle;
	} 
	else
	{
		a_f = (float)time_data / tiem_middle;
	}
	ui_render->DrawTextureWindow(Core::Vector2(pos.x,pos.y),_size.x,_size.y,texture_ui,Core::Rectangle(0,0,1,1),Core::ARGB(255*a_f,255,255,255));
}

void InGameUINew::_DrawBossMode2_humanSkill_rise(by_ptr(UIRender) ui_render,Core::Vector2 pos,Core::Vector2 _size,Core::Vector2 big_size,by_ptr(Texture2D) texture_ui,F32 totle_time,F32 _time)
{
	if (_time <= 0.0f)
	{
		return;
	}
	if (_time > totle_time)
	{
		_time = totle_time;
	}
	Core::Vector2 data_size = big_size - _size;
	F32 F_a = _time / totle_time;
	F32 F_data = 1 -F_a;
	int data_x = F_data*data_size.x/2;
	int data_y = F_data*data_size.y/2;
	ui_render->DrawTextureWindow(Core::Vector2(pos.x - data_x,pos.y - data_y),_size.x + 2*data_x,_size.y + 2*data_y,texture_ui,Core::Rectangle(0,0,1,1),Core::ARGB(150*F_a,255,255,255));
}

void InGameUINew::_DrawBossMode2_humanSkill_rise_up(by_ptr(UIRender) ui_render,Core::Vector2 pos,Core::Vector2 _size,Core::Vector2 big_size,by_ptr(Texture2D) texture_ui,F32 totle_time,F32 _time,F32 static_time)
{
	if (_time <= 0.0f)
	{
		return;
	}
	if (_time > totle_time)
	{
		_time = totle_time;
	}
	Core::Vector2 data_size = big_size - _size;
	Core::Vector2 confirm_size;
	F32 F_data;
	F32 middle_tiem[2];
	middle_tiem[0] =  (totle_time - static_time) / 2;
	middle_tiem[1] =  (totle_time + static_time) / 2;
	if (_time > middle_tiem[1])
	{
		F_data = (totle_time - _time) / middle_tiem[0];
	} 
	else if (_time <= middle_tiem[1] && _time >= middle_tiem[0])
	{
		F_data = 1.0f;
	} 
	else if (_time < middle_tiem[0] && _time > 0.0f)
	{
		F_data = _time / middle_tiem[0];
	}
	int data_x = F_data*data_size.x/2;
	int data_y = F_data*data_size.y;
	ui_render->DrawTextureWindow(Core::Vector2(pos.x - data_x,pos.y - data_y),_size.x + 2*data_x,_size.y + data_y,texture_ui);
}

void InGameUINew::_DrawBossMode2_BottomInfo(by_ptr(UIRender) ui_render)
{
	tempc_ptr(Character) player = gLevel->GetPlayer();
	if (player && player->IsDied())
	{
		return;
	}
	Matrix44 oldworld;
	Matrix44 world;
	Matrix44 oldview;
	Matrix44 view;
	int t_x = 20;
	int t_y = -100;
	F32 f_v = 0.0f;
	F32 f_u = 0.0f;
	Core::Vector2 radion_point = Core::Vector2(t_x,t_y);
	F32 radian = (10.0f/180)*Core::PI;
	if (player)
	{
		Core::Vector3 rt_size = gGame->guiSys->GetSize();
		world = Core::Matrix44::kIdentity;
		oldworld = ui_render->GetWorld();
		oldview  = ui_render->GetView();

		view.SetScaleXYZ(2.0f/rt_size.x, -2.0f/rt_size.y, 0);
		ui_render->SetView(view);
		world.SetTranslationXYZ(-(rt_size.x/2), rt_size.y/2, 0);
		ui_render->SetWorld(world);
		ui_render->SetTexture(ui_Boss_mode2_HP_up_bg);
		ui_render->DrawRectangleRadian(Core::Rectangle(t_x,t_y,t_x + 141,t_y + 29),radion_point,Core::Rectangle(0,0,1,1),radian);
		ui_render->SetTexture(ui_Boss_mode2_HP_bg);
		ui_render->DrawRectangleRadian(Core::Rectangle(t_x,t_y + 25 ,t_x + 227,t_y + 25 + 38),radion_point,Core::Rectangle(0,0,1,1),radian);
		f_u = (float)player->hp / player->max_hp;
		if (f_u < 0.3f)
		{
			ui_render->SetTexture(ui_Boss_mode2_HP_bf_r);
		} 
		else
		{
			ui_render->SetTexture(ui_Boss_mode2_HP_bf);
		}
		ui_render->DrawRectangleRadian(Core::Rectangle(t_x,t_y + 25,t_x + 227*f_u,t_y + 25 + 38),radion_point,Core::Rectangle(0,0,f_u,1),radian);
		ui_render->SetTexture(ui_Boss_mode2_HP_text);
		ui_render->DrawRectangleRadian(Core::Rectangle(t_x + 5,t_y + 8,t_x + 53,t_y + 20),radion_point,Core::Rectangle(0,0,1,1),radian);
		ui_render->SetTexture(ui_Boss_mode2_HP_num);
		int T_num[6] = {-1,-1,-1,-1,-1,-1};
		GetNum_alone(player->hp,T_num,6);
		int _index = 0;
		for (int i = 5 ; i >= 0 ; i--)
		{
			if (T_num[i] >= 0)
			{
				ui_render->DrawRectangleRadian(Core::Rectangle(t_x + 59 + _index*8,t_y + 7,t_x + 67 + _index*8,t_y + 23),radion_point,Core::Rectangle(T_num[i]*0.1,0,(T_num[i]+1)*0.1,1),radian);
				_index++;
			}
		}
		world = Core::Matrix44::kIdentity;
		world.SetTranslationXYZ(rt_size.x/2, rt_size.y/2, 0);
		ui_render->SetWorld(world);
		t_x = -250;
		t_y = -260;
		radian = -radian;
		radion_point = Core::Vector2(t_x + 230 , t_y);
		ui_render->SetTexture(ui_Boss_mode2_boss_weapon_bg);
		ui_render->DrawRectangleRadian(Core::Rectangle(t_x,t_y,t_x + 230,t_y + 123),radion_point,Core::Rectangle(0,0,1,1),radian);
		ui_render->SetTexture(ui_Boss_mode2_boss_weapon1);
		ui_render->DrawRectangleRadian(Core::Rectangle(t_x + 37,t_y + 33 ,t_x + 37 + 156 ,t_y + 33 + 68),radion_point,Core::Rectangle(0,0,1,1),radian);
		ui_render->SetTexture(ui_Boss_mode2_boss_ammo_icon);
		ui_render->DrawRectangleRadian(Core::Rectangle(t_x + 145,t_y + 84 ,t_x + 177 ,t_y + 108),radion_point,Core::Rectangle(0,0,1,1),radian);
		int T_num_ammon[6] = {-1,-1,-1,-1,-1,-1};
		tempc_ptr(WeaponBase) weapon = player->GetWeaponById(0);
		int ammo_num;
		if (weapon && ptr_dynamic_cast<GunBase>(weapon))
		{
			ammo_num = ptr_dynamic_cast<GunBase>(weapon)->ammo_in_clip;
		} 
		else
		{
			ammo_num = 0;
		}
		GetNum_alone(ammo_num,T_num_ammon,6);
		_index = 0;
		ui_render->SetTexture(ui_Boss_mode2_HP_num);
		for (int i = 5 ; i >= 0 ; i--)
		{
			if (T_num_ammon[i] >= 0)
			{
				ui_render->DrawRectangleRadian(Core::Rectangle(t_x + 177 + _index*8,t_y + 92,t_x + 185 + _index*8,t_y + 108),radion_point,Core::Rectangle(T_num_ammon[i]*0.1,0,(T_num_ammon[i]+1)*0.1,1),radian);
				_index++;
			}
		}
		ui_render->SetTexture(ui_Boss_mode2_boss_weapon_bg);
		ui_render->DrawRectangleRadian(Core::Rectangle(t_x,t_y + 125,t_x + 230,t_y + 123 + 125),radion_point,Core::Rectangle(0,0,1,1),radian);
		ui_render->SetTexture(ui_Boss_mode2_boss_weapon2);
		ui_render->DrawRectangleRadian(Core::Rectangle(t_x + 37,t_y + 33 + 120,t_x + 37 + 156 ,t_y + 33 + 68 + 120),radion_point,Core::Rectangle(0,0,1,1),radian);
		ui_render->SetTexture(ui_Boss_mode2_boss_Gun_text);
		ui_render->DrawRectangleRadian(Core::Rectangle(t_x + 92,t_y + 213 ,t_x + 112 ,t_y + 233),radion_point,Core::Rectangle(0,0,1,1),radian);
		if (player->boss2_special_weapon_energy >= 500)
		{
			int Int_a = Task::GetTotalTime()*100;
			Int_a = Int_a%120;
			if (Int_a > 60)
			{
				ui_render->SetTexture(ui_Boss_mode2_boss_Gun_text_shine);
				ui_render->DrawRectangleRadian(Core::Rectangle(t_x + 92,t_y + 213 ,t_x + 112 ,t_y + 233),radion_point,Core::Rectangle(0,0,1,1),radian,Core::ARGB(255,255,255,255));
			}
		}
		ui_render->SetTexture(ui_Boss_mode2_HP_small_bg);
		ui_render->DrawRectangleRadian(Core::Rectangle(t_x + 115,t_y + 215 ,t_x + 115 + 97 ,t_y + 231),radion_point,Core::Rectangle(0,0,1,1),radian);
		if (player->boss2_special_weapon_energy < 500)
		{
			ui_render->SetTexture(ui_Boss_mode2_HP_small_bf_r);
		} 
		else
		{
			ui_render->SetTexture(ui_Boss_mode2_HP_small_bf);
		}
		f_u = player->boss2_special_weapon_energy / player->boss2_special_weapon_energy_max;
		ui_render->DrawRectangleRadian(Core::Rectangle(t_x + 115,t_y + 215 ,t_x + 115 + 97*f_u ,t_y + 231),radion_point,Core::Rectangle(0,0,f_u,1),radian);
		if (player->boss2_special_weapon_energy < 500)
		{
			ui_render->SetTexture(ui_Boss_mode2_boss_weapon_disable_bg);
			ui_render->DrawRectangleRadian(Core::Rectangle(t_x + 75,t_y + 30 + 125,t_x + 154,t_y + 99 + 125),radion_point,Core::Rectangle(0,0,1,1),radian);
		}
		ui_render->SetTexture(ui_Boss_mode2_boss_weapon_bg_down);
		if (player->GetWeapon() == player->GetWeaponById(0))
		{
			ui_render->DrawRectangleRadian(Core::Rectangle(t_x,t_y,t_x + 230,t_y + 123),radion_point,Core::Rectangle(0,0,1,1),radian);			
		} 
		else
		{
			ui_render->DrawRectangleRadian(Core::Rectangle(t_x,t_y + 125,t_x + 230,t_y + 123 + 125),radion_point,Core::Rectangle(0,0,1,1),radian);
		}

		t_y = 120;
		world = Core::Matrix44::kIdentity;
		world.SetTranslationXYZ(0, rt_size.y/2, 0);
		ui_render->SetWorld(world);		
		ui_render->DrawTextureWindow(Core::Vector2(-180,-239 + t_y),360,28,ui_Boss_mode2_boss_defense_bg);
		f_u = player->boss2_defence_energy / player->boss2_defence_energy_max;
		ui_render->DrawTextureWindow(Core::Vector2(-180,-239 + t_y),360*f_u,28,ui_Boss_mode2_boss_defense,Core::Rectangle(0,0,f_u,1));
		ui_render->DrawStringShadow(ui_render->font_simhei_20, ARGB(255,58,167,254), ARGB(255,0,0,0), ARGB(0,0,0,0), Core::Rectangle(40,-255 + t_y,40,-255 + t_y), gLang->GetTextW(L"��ǰ���Եȼ���"), Unit::kAlignRightMiddle);
		_DrawNumberTextureWindow(ui_render, ui_head_info_round_boss_number, Core::Vector2(45, -270 + t_y), 26, 33, player->boss2_defence_energy_level,0.1f);
		
		t_y = 50;
		world = Core::Matrix44::kIdentity;
		world.SetTranslationXYZ(0, 0, 0);
		ui_render->SetWorld(world);	
		if (m_boss_mode2_boss_twoweapon_tips_time > 0.0f)
		{
			int a_num = 255*Core::Clamp(m_boss_mode2_boss_twoweapon_tips_time,0.0f,1.0f);
			ui_render->DrawStringShadow(ui_render->font_simhei_20, ARGB(a_num,239,20,20), ARGB(a_num,0,0,0), ARGB(0,0,0,0), Core::Rectangle(0,t_y,0,t_y), gLang->GetTextW(L"���������������㣬��������������ø���������"), Unit::kAlignCenterMiddle);
		}

		t_y = 230;
		t_x = -270;
		ui_render->DrawStringShadow(ui_render->font_simhei_20, ARGB(255,58,167,254), ARGB(255,0,0,0), ARGB(0,0,0,0), Core::Rectangle(t_x + 48,t_y - 12,-196,t_y - 12), gLang->GetTextW(L"ȼ��"), Unit::kAlignCenterMiddle);
		ui_render->DrawTextureWindow(Core::Vector2(t_x,t_y),108,48,ui_Boss_mode2_boss_fuel_bg);
		if (player->boss2_move_energy > 0)
		{
			f_v = (float)player->boss2_move_energy / player->boss2_move_energy_max;
			int n_y = 42*(1 - f_v) + 3;
			ui_render->DrawTextureWindow(Core::Vector2(t_x,t_y + n_y),108,48 - n_y,ui_Boss_mode2_boss_fuel,Core::Rectangle(0,n_y/48.0f,1,1));
		}

		//Bossѣ��
		int time = player->boss2_head_damage_timer;
		if (player->boss2_head_damage_timer > 1.5)
		{
			ui_render->DrawTextureWindow(Core::Vector2(-223,-109),446,218,ui_Boss_mode2_yun_r);
			ui_render->DrawStringShadow(ui_render->font_simhei_34, ARGB(255,255,0,0), ARGB(255,0,0,0), ARGB(0,0,0,0), Core::Rectangle(-223,-60,223,-30), gLang->GetTextW(L"ϵͳ̱��"), Unit::kAlignCenterMiddle);
			Core::String str = Core::String::Format(gLang->GetTextW(L"ϵͳ����%d�������"),time);
			ui_render->DrawStringShadow(ui_render->font_simhei_24, ARGB(255,255,0,0), ARGB(255,0,0,0), ARGB(0,0,0,0), Core::Rectangle(-223,0,223,30), str, Unit::kAlignCenterMiddle);
		}
		else if (player->boss2_head_damage_timer > 0)
		{
			ui_render->DrawTextureWindow(Core::Vector2(-223,-109),446,218,ui_Boss_mode2_yun);
			ui_render->DrawStringShadow(ui_render->font_simhei_34, ARGB(255,0,227,255), ARGB(255,0,0,0), ARGB(0,0,0,0), Core::Rectangle(-223,-109,223,100), gLang->GetTextW(L"ϵͳ����"), Unit::kAlignCenterMiddle);
		}
		ui_render->SetWorld(oldworld);
		ui_render->SetView(oldview);
	}
}

void InGameUINew::_DrawBossMode2_Bottom_Person_Info(by_ptr(UIRender) ui_render)
{
	tempc_ptr(Character) player = gLevel->GetPlayer();
	if (player && player->IsDied())
	{
		return;
	}
	Matrix44 oldworld;
	Matrix44 world;
	Matrix44 oldview;
	Matrix44 view;
	int t_x = -240;
	int t_y = -50;
	F32 f_u = 0.0f;
	int _index = 0;
	if (player)
	{
		Core::Vector3 rt_size = gGame->guiSys->GetSize();
		world = Core::Matrix44::kIdentity;
		oldworld = ui_render->GetWorld();
		oldview  = ui_render->GetView();

		view.SetScaleXYZ(2.0f/rt_size.x, -2.0f/rt_size.y, 0);
		ui_render->SetView(view);
		world.SetTranslationXYZ(0, rt_size.y/2, 0);
		ui_render->SetWorld(world);

		ui_render->DrawTextureWindow(Core::Vector2(t_x,t_y),556,37,ui_Boss_mode2_person_energy_Lv,Core::Rectangle(0,0,1,1));
		ui_render->DrawTextureWindow(Core::Vector2(t_x + 120,t_y + 3),366,31,ui_Boss_mode2_person_energy_bg,Core::Rectangle(0,0,1,1));
		if (m_boss_mode2_shine_time > 0)
		{
			f_u = 1.0f;
		} 
		else
		{
			f_u = player->boss2_human_energy / player->boss2_human_energy_max;
		}
		ui_render->DrawTextureWindow(Core::Vector2(t_x + 120,t_y + 3),366*f_u,31,ui_Boss_mode2_person_energy,Core::Rectangle(0,0,f_u,1));

		_DrawNumberTextureWindow(ui_render, ui_zombie_time_number, Core::Vector2(t_x+85, t_y + 6), 18, 26, player->boss2_human_energy_level / 10,0.1f);
		_DrawNumberTextureWindow(ui_render, ui_zombie_time_number, Core::Vector2(t_x+100, t_y + 6), 18, 26, player->boss2_human_energy_level % 10,0.1f);

		int skill_present[4] = {15,25,5,10};
		for (int i = 0 ; i < 4 ; i++)
		{
			if (player->boss2_passiveskill_level[i] >= 0)
			{
				ui_render->DrawTextureWindow(Core::Vector2(t_x + 450 - _index * 50,t_y - 50),52,52,ui_Boss_mode2_person_passiveskill[i],Core::Rectangle(0,0,1,1));
				_DrawBossMode2_humanSkill_rise(ui_render,Core::Vector2(t_x + 450 - _index * 50,t_y - 50),Core::Vector2(52,52),Core::Vector2(104,104),ui_Boss_mode2_person_passiveskill[i],0.5f,m_boss_mode2_human_skill_level_up_time[i]);
				_DrawBossMode2_humanSkill_rise_up(ui_render,Core::Vector2(t_x + 450 - _index * 50 + 25,t_y - 50 - 15),Core::Vector2(2,2),Core::Vector2(68,20),ui_Boss_mode2_person_skill_level_up,1.0f,m_boss_mode2_human_skill_level_up_time_two[i],0.5f);
				CStrBuf<256> buff;
				buff.format("+%d%%",skill_present[i]*player->boss2_passiveskill_level[i]);
				ui_render->DrawStringShadow(ui_render->font_simhei_12,Core::ARGB(255,239,239,239), ARGB(255,0,0,0), ARGB(0,0,0,0), Core::Rectangle(t_x +495 - _index * 50,t_y - 45,t_x + 495 - _index * 50,t_y - 45),buff.buff() , Unit::kAlignCenterMiddle);
				Core::ARGB tex_color;
				if (player->boss2_passiveskill_level[i] >= 9 )
				{
					buff.format("MAX");
					tex_color = Core::ARGB(255,239,239,48);
				}
				else
				{
					buff.format("lv.%d",(player->boss2_passiveskill_level[i] + 1));
					tex_color = Core::ARGB(255,239,239,239);
				}
				ui_render->DrawStringShadow(ui_render->font_simhei_14,tex_color, ARGB(255,0,0,0), ARGB(0,0,0,0), Core::Rectangle(t_x + 475 - _index * 50 ,t_y,t_x + 475 - _index * 50,t_y + 10),buff.buff() , Unit::kAlignCenterMiddle);
				_index++;
			}
		}
		_DrawBossMode2_Picture_Shine(ui_render,Core::Vector2(t_x + 120,t_y + 3),Core::Vector2(366,31),ui_Boss_mode2_person_energy_shine);
		_DrawCommonZombie_Level_up(ui_render,Core::Vector2(t_x + 170,-123),Core::Vector2(150,146),150,m_commonzombie_level_isup_time[1]);

		world = Core::Matrix44::kIdentity;
		world.SetTranslationXYZ(-rt_size.x/2, rt_size.y/2, 0);
		ui_render->SetWorld(world);
		int pos_x = 0;
		if (player->boss2_initiative_type > 0)
		{
			//const Core::String skill_str[4] = {gLang->GetTextW(L"�޵�"),gLang->GetTextW(L"�ظ�"),gLang->GetTextW(L"��������"),gLang->GetTextW(L"����&װ���ٶ�")};
			_DrawInitiativeSkill(ui_render,Core::Vector2( 215 , -115 ),ui_commonzombie_Key_E,ui_Boss_mode2_person_initiativ_skill[player->boss2_initiative_type -1],ui_commonzombie_Skill_Shine,ui_commonzombie_Skill_bg,ui_commonzombie_Skill_bf);
			pos_x = 60;
		}
		if (player->boss2_strange_spawn >= 0)
		{
			//const Core::String skill_str[4] = {gLang->GetTextW(L"�̶������"),gLang->GetTextW(L"�̶�����"),gLang->GetTextW(L":����UAV"),gLang->GetTextW(L"��ǹUAV")};
			_DrawInitiativeSkill(ui_render,Core::Vector2( 215 + pos_x, -115 ),ui_commonzombie_Key_G,ui_Boss_mode2_person_strange_spawn_skill[player->boss2_strange_spawn],ui_commonzombie_Skill_Shine,ui_commonzombie_Skill_bg,ui_commonzombie_Skill_bf);
		}

		for (int i = 0 ; i < commonzombie_skill.GetCount() ; i++)
		{
			SkillItem item = commonzombie_skill.GetAt(i);
			ui_render->DrawStringShadow(ui_render->font_simhei_16, Core::ARGB(255,255,128,4), ARGB(255,0,0,0), Core::ARGB(0,0,0,0), Core::Rectangle(30 + i*52 , -210,30 + i*52 + 52 , -190),Core::String::Format("%d",(int)item.time) , Unit::kAlignCenterMiddle);
			ui_render->DrawTextureWindow(Core::Vector2( 30 + i*52 , -190 ), 52 , 52 , ui_commonzombie_Skill_ico[item.type]);
		}

		ui_render->SetWorld(oldworld);
		ui_render->SetView(oldview);
	}
}

void InGameUINew::_DrawGunTower_Dummy(by_ptr(UIRender) ui_render)
{
	sharedc_ptr(Character) viewer = gLevel->GetViewer();
	if(!viewer)
		return;
	Matrix44 oldworld;
	Matrix44 world;
	Matrix44 oldview;
	Matrix44 view;
	int x, y;
	Core::Vector3 rt_size = gGame->guiSys->GetSize();
	
	oldworld = ui_render->GetWorld();
	oldview  = ui_render->GetView();
	world = Core::Matrix44::kIdentity;
	view.SetScaleXYZ(2.0f/rt_size.x, -2.0f/rt_size.y, 0);
	view.TranslateXYZ(-1.0f, 1.0f, 0.0f);
	view.TranslateLocalXYZ(-0.5f, -0.5f, 0.0f);
	ui_render->SetWorld(Core::Matrix44::kIdentity);
	ui_render->SetView(view);

	HashSet<uint, sharedc_ptr(DummyObject)>::Enumerator it(gLevel->dummy_object_set);
	while (it.MoveNext())
	{
		tempc_ptr(DummyObject) dummy_obj = it.Value();

		if (IsGunTower_DummyVisible(dummy_obj,x,y))
		{
			world.SetTranslationXYZ(x,y,0);
			ui_render->SetWorld(world);
			
			if(viewer->is_display_friend_name)
			{
				F32 len = Length(gGame->camera->position - CalcNewPosition(gGame->camera->position, dummy_obj->GetPosition()));

				F32 v = gDx9Device->convergence > 0 ? gDx9Device->convergence : 1;
				if (gDx9Device->GetStereoEnable() &&  len> 0)
					v = len;

				gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_CONVERGENCE, &v, 1);

				sharedc_ptr(Character) c = gLevel->GetCharacter(dummy_obj->owner_id);
				sharedc_ptr(Character) player = gLevel->GetPlayer();
				if (player && c)
				{			
					int t_x = -60;
					int t_y = -65;
					if(!dummy_obj->need_stepfather && gLevel->game_type != RoomOption::kEditMode)
					{
						if (player->GetTeam() == c->GetTeam() || player->GetTeam() == 2)
						{
							ui_render->DrawString(ui_render->font_simhei_16,ARGB(15,230,15),ARGB(1,1,1,1),Core::Rectangle(0,t_y,0,t_y+20),c->GetName(),Unit::kAlignCenterMiddle);
						} 
						else
						{
							ui_render->DrawString(ui_render->font_simhei_16,ARGB(239,39,39),ARGB(1,1,1,1),Core::Rectangle(0,t_y,0,t_y+20),c->GetName(),Unit::kAlignCenterMiddle);
						}
						ui_render->DrawTextureWindow(Core::Vector2(t_x, t_y + 15), 35*28/37, 28, ui_bottom_info_GunTower_ammo);
						ui_render->DrawTextureWindow(Core::Vector2(t_x + 28, t_y + 20), 85, 22, ui_bottom_info_GunTower_energy_bg);
						ui_render->DrawTextureWindow(Core::Vector2(t_x + 28, t_y + 20), 85*c->tower_gun_percent, 22, ui_bottom_info_GunTower_energy, Core::Rectangle(0,0,c->tower_gun_percent,1));
					}
				
					if(dummy_obj->need_stepfather && GetGunTower_Dummy_Hp_Position(dummy_obj, x, y))
					{
						world.SetTranslationXYZ(x,y,0);
						ui_render->SetWorld(world);
						int t_x = -60;
						int t_y = 0;
						//t_y = t_y + 15;
						float f_hp = Core::Clamp((float)dummy_obj->hp / dummy_obj->dummyobjectinfo->hp,0,1.0f);
						ui_render->SetTexture(ui_tab_zombie_hp_bg);
						ui_render->DrawWindow(Core::Rectangle(t_x,t_y,-t_x,t_y + 12),Core::Rectangle(5,3,5,3),Core::Rectangle(5 / 12.f, 3.f / 11.f, 5 / 12.f, 3.f / 11.f));
						if (f_hp > 0)
						{
							if (f_hp > 0.6)
								ui_render->SetTexture(ui_common_hp[0]);
							else if (f_hp > 0.3)
								ui_render->SetTexture(ui_common_hp[1]); 
							else
								ui_render->SetTexture(ui_common_hp[2]);
							if (f_hp < 0.2)
								ui_render->DrawWindow(Core::Rectangle(t_x + 1,t_y + 1,t_x - 2*(t_x + 1)*f_hp,t_y + 11),Core::Rectangle(0,3,0,3),Core::Rectangle(0 / 32.f, 3.f / 16.f, 0 / 32.f, 3.f / 16.f));
							else
								ui_render->DrawWindow(Core::Rectangle(t_x + 1,t_y + 1,t_x - 2*(t_x + 1)*f_hp,t_y + 11),Core::Rectangle(5,3,5,3),Core::Rectangle(5 / 32.f, 3.f / 16.f, 5 / 32.f, 3.f / 16.f));
						}
					}
				}
				
				if (gDx9Device->GetStereoEnable())
					v = gDx9Device->convergence > 0 ? gDx9Device->convergence : 1;

				gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_CONVERGENCE, &v, 1);
			}			
		}
	}
	ui_render->SetWorld(oldworld);
	ui_render->SetView(oldview);
}

void InGameUINew::_DrawTDmode(by_ptr(UIRender) ui_render)
{
	if (RoomOption::kTDMode != gLevel->game_type)
		return;

	if (gLevel->GetPlayer()->IsDied())
		return;

	tempc_ptr(Character) player = gLevel->GetPlayer();
	if (player)
	{
		Matrix44 view;	
		Core::Vector3 rt_size = gGame->guiSys->GetSize();
		Matrix44 world = Core::Matrix44::kIdentity;
		Matrix44 oldworld = ui_render->GetWorld();
		Matrix44 oldview  = ui_render->GetView();

		//view.SetScaleXYZ(2.0f/rt_size.x, -2.0f/rt_size.y, 0);
		//ui_render->SetView(view);

		//bottom center
		world.SetTranslationXYZ(rt_size.x/2, rt_size.y, 0);
		ui_render->SetWorld(world);

		ARGB white(255, 255, 255);
		ARGB red(255, 0, 0);
		ARGB black(0,0,0);
		Core::CStrBuf<256> buff;
		int x = -200;
		int xx = x;
		int wight1 = 50;
		int wight2 = 70;
		int offset = 0;
		float scale_size = 0;
		double now_time = time(NULL);

		// ����ͼƬ
		ui_render->SetTexture(ui_ingame_item_mask[7]);
		ui_render->DrawWindow(Core::Rectangle(-263, -50, 263, 10), Core::Rectangle(60, 0, 60, 0), Core::Rectangle(60.0f/124.0f, 0 ,60.0f/124.0f, 0) );

		if (m_SelectLeftTime>0)
		{
			m_SelectLeftTime -= Task::GetFrameTime()*5;
			if (m_SelectLeftTime<=0)
			{
				SelectLeftItem();
				m_SelectLeftTime = 0;
			}
			scale_size = (1-m_SelectLeftTime/ICON_MOVE_TIME)*(wight2-wight1);
		}
		else if (m_SelectRightTime>0)
		{
			m_SelectRightTime -= Task::GetFrameTime()*5;
			if (m_SelectRightTime<=0)
			{
				SelectRightItem();
				m_SelectRightTime = 0;
			}
			scale_size = (1-m_SelectRightTime/ICON_MOVE_TIME)*(wight2-wight1);
		}
		for(int i = 0; i < ITEM_ICON_NUM; ++i)
		{
			offset = 0;
			xx = x;
			int wight = wight1;
			int y = -70;
			if (2==i || 5 == i)
			{
				wight = wight2;
				y = -90;
			}

			// ����ͼ��
			if (5==i || (m_SelectRightTime<=0 && m_SelectLeftTime <= 0) )
				ui_render->DrawTextureWindow(Vector2(x,y),wight+3,wight+3,ui_ingame_item_bg[i]);
			if (0==i)
			{
				if (m_leftScaleTime > 0)
				{
					offset = (ScaleTime - m_leftScaleTime)*10;
					m_leftScaleTime -= Task::GetFrameTime()*6;
				}
				ui_render->DrawTextureWindow(Vector2(x - 30+offset/2 ,y + 13+offset/2), 25-offset, 25-offset,ui_ingame_item_mask[3]);
			}
			else if (2==i)
			{
				if (m_KeyHScaleTime > 0)
				{
					offset = (ScaleTime - m_KeyHScaleTime)*10;
					m_KeyHScaleTime -= Task::GetFrameTime()*6;
				}
				ui_render->DrawTextureWindow(Vector2(x+wight/2-10+offset/2,y-30+offset/2),20-offset,20-offset,ui_ingame_item_mask[4]);
			}
			else if (4==i)
			{
				if (m_rightScaleTime > 0)
				{
					offset = (ScaleTime - m_rightScaleTime)*10;
					m_rightScaleTime -= Task::GetFrameTime()*6;
				}
				ui_render->DrawTextureWindow(Vector2(x+wight +5+offset/2, y + 13+offset/2),25-offset,25-offset,ui_ingame_item_mask[5]);
			}
			else if(5==i)
			{
				if (m_KeyGScaleTime > 0)
				{
					offset = (ScaleTime - m_KeyGScaleTime)*10;
					m_KeyGScaleTime -= Task::GetFrameTime()*6;
				}
				ui_render->DrawTextureWindow(Vector2(x+wight/2-10+offset/2,y-30+offset/2),20-offset,20-offset,ui_ingame_item_mask[6]);
			}
			// ͼ��
			if (m_DisplayItem[i])
			{
				// ѡ�������ߣ�ͼ����������
				if (m_SelectLeftTime>0 && i < 5)
				{
					xx += (ICON_MOVE_TIME-m_SelectLeftTime)*wight1;

					if (2 == i)
						ui_render->DrawTextureWindow(Vector2(xx+1+scale_size,y+1+scale_size),wight+1-scale_size,wight+1-scale_size,ui_ingame_item_icon[i]);
					else if (1 == i)
						ui_render->DrawTextureWindow(Vector2(xx+1,y+1-scale_size),wight+1+scale_size,wight+1+scale_size,ui_ingame_item_icon[i]);
					else
						ui_render->DrawTextureWindow(Vector2(xx+1,y+1),wight+1,wight+1,ui_ingame_item_icon[i]);
				}
				// ѡ���Ҳ���ߣ�ͼ����������
				else if (m_SelectRightTime>0 && i < 5)
				{
					xx -= (ICON_MOVE_TIME-m_SelectRightTime)*wight1;

					if (2 == i)
						ui_render->DrawTextureWindow(Vector2(xx+1,y+1+scale_size),wight+1-scale_size,wight+1-scale_size,ui_ingame_item_icon[i]);
					else if (3 == i)
						ui_render->DrawTextureWindow(Vector2(xx+1-scale_size,y+1-scale_size),wight+1+scale_size,wight+1+scale_size,ui_ingame_item_icon[i]);
					else
						ui_render->DrawTextureWindow(Vector2(xx+1,y+1),wight+1,wight+1,ui_ingame_item_icon[i]);
				}
 				else
					ui_render->DrawTextureWindow(Vector2(xx+1,y+1),wight+1,wight+1,ui_ingame_item_icon[i]);
			}
			else
				ui_render->DrawTextureWindow(Vector2(x+7,y+7),wight-10,wight-10,ui_ingame_item_mask[2]);
			// ����ʹ��ʱͼ��
			if (player->IsDied() || (m_DisplayItem[i] && 0==m_DisplayItem[i]->count) )
			{
				ui_render->DrawTextureWindow(Vector2(x+7,y+7),wight-10,wight-10,ui_ingame_item_mask[0]);
			}
			else if (m_DisplayItem[i] && player->ItemIsCDTime(m_DisplayItem[i], now_time) )
			{
				ui_render->DrawTextureWindow(Vector2(x+1,y+1),wight,wight,ui_ingame_item_mask[1]);
				buff.format("%.0fs", m_DisplayItem[i]->CDTime-(now_time-m_DisplayItem[i]->interval_timer) );
				ui_render->DrawString(ui_render->font_simhei_20,black,ARGB(1,1,1,1),
					Core::Rectangle(x+wight/2-10,y+wight/2-10,x+wight/2+10,y+wight/2+10),buff,Unit::kAlignCenterMiddle);
			}
			else if (player->IsCarrierMode() )
			{
				ui_render->DrawTextureWindow(Vector2(x+7,y+7),wight-10,wight-10,ui_ingame_item_mask[0]);
			}

			// ����
			if (m_DisplayItem[i])
			{
				buff.format("X%d", m_DisplayItem[i]->count);
				ui_render->DrawString(ui_render->font_simhei_16,m_DisplayItem[i]->count>0?black:red,ARGB(1,1,1,1),
					Core::Rectangle(x+wight/2-10, y+wight-7, x+wight/2+10, y+wight+22),buff,Unit::kAlignCenterMiddle);
			}
			x+=wight;
			if (i == 4)
				x+=35;
			else
				x+=12;
		}

		// top center
		// �ؾ߽���
		world = Core::Matrix44::kIdentity;
		world.SetTranslationXYZ(rt_size.x/2, 0, 0);
		ui_render->SetWorld(world);
			
		if (m_isCarriering && m_CarrierTime < CARRIRE_TIME)
		{
			buff.format(gLang->GetTextW(L"�ȴ��ؾ�����") );
			ui_render->DrawString(ui_render->font_simhei_20,white,ARGB(1,1,1,1),Core::Rectangle(-150,rt_size.y/2,150,rt_size.y/2+15),buff,Unit::kAlignCenterMiddle);

			float progress = Clamp((m_CarrierTime+=Core::Task::GetFrameTime()) / CARRIRE_TIME, 0, 1);
 			ui_render->SetTexture(ui_progress_bar_border);
 			ui_render->DrawWindow(Core::Rectangle(-150, rt_size.y/2+25, 150, rt_size.y/2+40), Core::Rectangle(5, 6, 7, 7), Core::Rectangle(5.0f / 15.f, 6.0f / 15.f, 7.0f / 15.f, 7.0f / 15.f));
 			ui_render->SetTexture(ui_progress_bar_body);
 			ui_render->DrawWindow(Core::Rectangle(-150, rt_size.y/2+25, 300 * progress-150, rt_size.y/2+40), Core::Rectangle(5, 5, 6, 6), Core::Rectangle(5.0f / 15.f, 5.0f / 15.f, 6.0f / 15.f, 6.0f / 15.f));
		}
		else if (m_isCarriering && m_CarrierTime > CARRIRE_TIME && m_DisplayItem[ITEM_ICON_NUM-1])
		{
			m_isCarriering = false;
			m_CarrierTime = 0.0f;

			InGameItemInfo* item = m_DisplayItem[ITEM_ICON_NUM-1];
			if (item && item->count>0 && !player->ItemIsCDTime(item, now_time) )
			{
				gGame->channel_connection->UseItem(item->sid);
			}
		}
		if (m_isCarriering && (player->IsMoving() || player->IsShooting() || 
			player->IsDied() || player->IsJumping() ) )
		{
			m_isCarriering = false;
			m_CarrierTime = 0.0f;
		}

		float progress = Clamp((float)m_cur_reshp/(float)m_max_reshp, 0, 1);
		ui_render->DrawTextureWindow(Vector2(-245,38), 154 * (1-progress), 17, ui_ingame_score_bg[0]);
		ui_render->DrawTextureWindow(Vector2(255-Floor(155 * progress),38), Floor(155 * progress), 16, ui_ingame_score_bg[1]);
		if (m_ResTime>0)
		{
			offset = (ScaleTime - m_ResTime)*40;
			ui_render->DrawTextureWindow(Vector2(-245-(offset/2)* (1-progress), 38-offset/2), 154 * (1-progress)+offset* (1-progress), 17+offset, 
				ui_ingame_score_bg[0], Core::Rectangle(1,0,0,1),Core::ARGB(255*m_ResTime/ScaleTime,255,255,255));

			ui_render->DrawTextureWindow(Vector2(255-Floor(155 * progress)-offset/2*progress, 38-offset/2), Floor(155 * progress)+offset*progress, 
				16+offset, ui_ingame_score_bg[1], Core::Rectangle(1,0,0,1),Core::ARGB(255*m_ResTime/ScaleTime,255,255,255));

			m_ResTime -= Task::GetFrameTime()*3;
		}
		buff.format(gLang->GetTextW(L"���������") );
		ui_render->DrawString(ui_render->font_simhei_20,ARGB(255,239,206),ARGB(1,1,1,1),Core::Rectangle(-245, 14, -90, 34),buff,Unit::kAlignCenterMiddle);
		buff.format("%d", (int)((1-progress)*gLevel->room_option.rule_value) );
		ui_render->DrawString(ui_render->font_simhei_20,ARGB(255,239,206),ARGB(1,1,1,1),Core::Rectangle(-245, 34, -90, 54),buff,Unit::kAlignCenterMiddle);
		buff.format(gLang->GetTextW(L"���ط�ʣ��") );
		ui_render->DrawString(ui_render->font_simhei_20,ARGB(255,239,206),ARGB(1,1,1,1),Core::Rectangle(100, 14, 255, 34),buff,Unit::kAlignCenterMiddle);
		buff.format("%d", (int)(progress*gLevel->room_option.rule_value) );
		ui_render->DrawString(ui_render->font_simhei_20,ARGB(255,239,206),ARGB(1,1,1,1),Core::Rectangle(100, 34, 255, 54),buff,Unit::kAlignCenterMiddle);

		// ��������ʱ60��
		if (gGame->round_time < 61 && gGame->round_time > 57)
		{
			buff.format(gLang->GetTextW(L"������Ϸ��������%d��"), gGame->round_time);
			ui_render->DrawString(ui_render->font_simhei_20,ARGB(255,0,0),ARGB(1,1,1,1),Core::Rectangle(-75, 100, 75, 120),buff,Unit::kAlignCenterMiddle);
		}


		// left center
		// ����buffͼ�� 
		world = Core::Matrix44::kIdentity;
		view.SetScaleXYZ(2.0f/rt_size.x, -2.0f/rt_size.y, 0);
		ui_render->SetView(view);
		world.SetTranslationXYZ(0, rt_size.y/2, 0);
		ui_render->SetWorld(world);
		int t_x = -250;
		int t_y = -85;
		for(int i = 0; i < (int)player->item_mode_buff_time.Size();++i)
		{
			buff.format("%d��",(int)player->item_mode_buff_time[i]->totle_time);
			ui_render->DrawTextureWindow(Core::Vector2(t_x-10 + 115 + 52*i , t_y-130),50,50,ui_itemmode_Skill_ico[player->item_mode_buff_time[i]->slot]);
			ui_render->DrawStringShadow(ui_render->font_simhei_16, ARGB(255,229,51), ARGB(0,0,0), ARGB(0, 0, 0, 0), Core::Rectangle(t_x-10 + 115 + 52*i , t_y - 82 , t_x-10 + 115 + 52*i+52, t_y - 82+20),buff, Unit::kAlignCenterMiddle);
		}

		ui_render->SetWorld(oldworld);
		ui_render->SetView(oldview);
	}
}

void InGameUINew::_DrawEditMode(by_ptr(UIRender) ui_render)
{
	if (RoomOption::kEditMode != gLevel->game_type)
		return;

	if (gLevel->GetPlayer()->IsDied())
		return;

	tempc_ptr(Character) player = gLevel->GetPlayer();
	if (player)
	{
		Matrix44 view;	
		Core::CStrBuf<256> buff;
		Core::Vector3 rt_size = gGame->guiSys->GetSize();
		Matrix44 world = Core::Matrix44::kIdentity;
		Matrix44 oldworld = ui_render->GetWorld();
		Matrix44 oldview  = ui_render->GetView();

		// right top
		world = Core::Matrix44::kIdentity;
		world.SetTranslationXYZ(rt_size.x, 0, 0);
		ui_render->SetWorld(world);
		ui_render->DrawTextureWindow(Vector2(-360, 10), 360 , 241, ui_ingame_help);


		// left top
		world = Core::Matrix44::kIdentity;
		world.SetTranslationXYZ(0, 0, 0);
		ui_render->SetWorld(world);
		ui_render->DrawTextureWindow(Vector2(0, 10), 373 , 442, ui_ingame_info);
		tempc_ptr(GunTowerBuilderPlus) w_edit = ptr_dynamic_cast<GunTowerBuilderPlus>(player->GetWeapon());
		if (w_edit)
		{
			int num = w_edit->GetTowerTypeCount();
			GunTowerTypeInfo tower_info;
			int WallCount = 0;
			int GuardCount = 0;
			for (int i =0; i < num ; ++i)
			{
				tower_info = w_edit->GetTowerType(i);
				if (GuardCount < 3 && DummyObject::SUBTYPE_GUARD == tower_info.DummyObjectSubType)
				{
					sharedc_ptr(Texture2D) texture = RESOURCE_LOAD_NEW(buff.format("LobbyUI/ibt_icon/%s.tga", tower_info.ResKey.Str() ), true, Texture2D);
					ui_render->DrawTextureWindow(Vector2(30, 86+GuardCount*50+GuardCount*20), 50 , 50, texture);
					int count = gLevel->GetDummyObjectCount(tower_info.DummyObjectType, tower_info.ResKey);
					buff.format("%d/%d", tower_info.MaxCount-count, tower_info.MaxCount );
					ui_render->DrawString(ui_render->font_simhei_16,ARGB(255,239,206),ARGB(1,1,1,1),
						Core::Rectangle(180, 102+GuardCount*70, 240, 116+GuardCount*70),buff,Unit::kAlignCenterMiddle);
					GuardCount++;
				}
				else if (WallCount < 1 && DummyObject::SUBTYPE_WALL == tower_info.DummyObjectSubType)
				{
					sharedc_ptr(Texture2D) texture = RESOURCE_LOAD_NEW(buff.format("LobbyUI/ibt_icon/%s.tga", tower_info.ResKey.Str() ) , true, Texture2D);
					ui_render->DrawTextureWindow(Vector2(30, 383), 50 , 50, texture);
					int count = gLevel->GetDummyObjectCount(tower_info.DummyObjectType, tower_info.ResKey);
					buff.format("%d/%d", tower_info.MaxCount-count, tower_info.MaxCount );
					ui_render->DrawString(ui_render->font_simhei_16,ARGB(255,239,206),ARGB(1,1,1,1),Core::Rectangle(180, 402, 240, 416),buff,Unit::kAlignCenterMiddle);
					WallCount++;
				}
			}
			buff.format(gLang->GetTextW(L"��ʩ��𣺻�е����") );
			ui_render->DrawString(ui_render->font_simhei_16,ARGB(255,239,206),ARGB(1,1,1,1),Core::Rectangle(25, 26, 125, 40),buff,Unit::kAlignLeftBottom);
			buff.format(gLang->GetTextW(L"�ɰ������ޣ�") );
			ui_render->DrawString(ui_render->font_simhei_16,ARGB(255,239,206),ARGB(1,1,1,1),Core::Rectangle(25, 54, 105, 68),buff,Unit::kAlignLeftBottom);
			buff.format("%d", w_edit->tower_info->m_iMaxGuardCount);
			ui_render->DrawString(ui_render->font_simhei_16,ARGB(0,255,0),ARGB(1,1,1,1),Core::Rectangle(115, 54, 135, 68),buff,Unit::kAlignLeftBottom);
			buff.format(gLang->GetTextW(L"ʣ�ల������") );
			ui_render->DrawString(ui_render->font_simhei_16,ARGB(255,239,206),ARGB(1,1,1,1),Core::Rectangle(240, 54, 320, 68),buff,Unit::kAlignLeftBottom);
			buff.format("%d", w_edit->tower_info->m_iMaxGuardCount - gLevel->GetDummyObjectCountBySubType(DummyObject::SUBTYPE_GUARD)  );
			ui_render->DrawString(ui_render->font_simhei_16,ARGB(255,0,0),ARGB(1,1,1,1),Core::Rectangle(330, 55, 350, 69),buff,Unit::kAlignLeftBottom);

			buff.format(gLang->GetTextW(L"��ʩ��𣺷���ǽ") );
			ui_render->DrawString(ui_render->font_simhei_16,ARGB(255,239,206),ARGB(1,1,1,1),Core::Rectangle(25, 316, 125, 340),buff,Unit::kAlignLeftBottom);
			buff.format(gLang->GetTextW(L"�ɰ������ޣ�") );
			ui_render->DrawString(ui_render->font_simhei_16,ARGB(255,239,206),ARGB(1,1,1,1),Core::Rectangle(25, 344, 105, 358),buff,Unit::kAlignLeftBottom);
			buff.format("%d", w_edit->tower_info->m_iMaxWallCount );
			ui_render->DrawString(ui_render->font_simhei_16,ARGB(0,255,0),ARGB(1,1,1,1),Core::Rectangle(115, 346, 130, 360),buff,Unit::kAlignLeftBottom);
			buff.format(gLang->GetTextW(L"ʣ�ల������") );
			ui_render->DrawString(ui_render->font_simhei_16,ARGB(255,239,206),ARGB(1,1,1,1),Core::Rectangle(240, 344, 320, 358),buff,Unit::kAlignLeftBottom);
			buff.format("%d", w_edit->tower_info->m_iMaxWallCount - gLevel->GetDummyObjectCountBySubType(DummyObject::SUBTYPE_WALL)  );
			ui_render->DrawString(ui_render->font_simhei_16,ARGB(255,0,0),ARGB(1,1,1,1),Core::Rectangle(330, 346, 350, 360),buff,Unit::kAlignLeftBottom);
		}

		ui_render->SetWorld(oldworld);
	}
}

void InGameUINew::_DrawCancelTowerGun(by_ptr(UIRender) ui_render)
{
	Core::Vector3 rt_size = gGame->guiSys->GetSize();

	ui_render->SetTexture(ui_ingam_cancel_tower_gun);
	ui_render->DrawWindow(Core::Rectangle(rt_size.x * 1118 / 1600, -338 * rt_size.y / 900, (1118 + 352) * rt_size.x / 1600, (-338 + 138) * rt_size.y / 900),Core::Rectangle(20,20,20,20),Core::Rectangle(20.0f / 58.f, 20.0f / 58.f, 20.0f / 58.f, 20.0f / 58.f));
	ui_render->DrawString(ui_render->font_simhei_28, ARGB(255, 240, 180, 48), ARGB(1,1,1,1), Core::Rectangle(rt_size.x * 1118 / 1600, -338 * rt_size.y / 900, (1118 + 352) * rt_size.x / 1600, (-338 + 138) * rt_size.y / 900), gLang->GetTextW(L"����I��ȡ�������"), Unit::kAlignCenterMiddle);
}

void InGameUINew::_DrawZombieTab(by_ptr(UIRender) ui_render)
{
	tempc_ptr(Character) viewer = gLevel->GetViewer();
	Matrix44 world;
	Core::Vector3 rt_size = gGame->guiSys->GetSize();
	Game * game = gGame;

	if (gLevel->game_type == RoomOption::kNovice)
		return;

	// draw tab
	if(!viewer)
	{
		tempc_ptr(Character) player = gLevel->GetPlayer();
		if(player)
			viewer = player;
	}

	if ((show_game_scores || show_scores) && viewer && viewer->GetTeam() <= 2)
	{
		world.SetTranslationXYZ(0, 0, 0);
		ui_render->SetWorld(world);
		ARGB name_color = ARGB(255,244,220);
		ARGB bg_color = ARGB(0,0,0,0);
		ARGB font_color = ARGB(150,215,232,227);

		bool havewatch = false;
		for (uint rank = 0; rank < game->scores->teams[2].Size(); rank ++)
		{
			Character * c = game->scores->teams[2][rank];
			if (c)
			{
				havewatch = true;
			}
		}

		int tx = -388;
		int ty = -364;
		if (havewatch)
		{
			tx -=(178/2);
		}
		ui_render->SetTexture(ui_tab_red);
		ui_render->DrawWindow(Core::Rectangle(tx,ty,tx+804,ty+200),Core::Rectangle(15, 15, 15, 15),Core::Rectangle(15.f/96.f, 15.f/52.f, 15.f/96.f, 15.f/52.f));

		ui_render->DrawTextureWindow(Vector2(tx,ty+200),804,172,ui_tab_center_zombie);

		ui_render->SetTexture(ui_tab_gray_zombie);
		ui_render->DrawWindow(Core::Rectangle(tx,ty+372,tx+804,ty+372+337),Core::Rectangle(15, 15, 15, 15),Core::Rectangle(15.f/96.f, 15.f/52.f, 15.f/96.f, 15.f/52.f));

		ui_render->SetTexture(ui_tab_bottom);
		ui_render->DrawWindow(Core::Rectangle(tx,ty+372+337,tx+804,ty+372+337+96),Core::Rectangle(15, 15, 15, 15),Core::Rectangle(15.f/60.f, 15.f/44.f, 15.f/60.f, 15.f/44.f));

		ui_render->SetTexture(ig_tab_bg2);
		ui_render->DrawWindow(Core::Rectangle(tx+15,ty+357+13,tx+15+776,ty+357+13+33),Core::Rectangle(0, 0, 0, 0),Core::Rectangle(1.f/32.f, 1.f/32.f, 1.f/32.f, 1.f/32.f));

		if (havewatch)
		{
			ui_render->SetTexture(ui_tab_watch);
			ui_render->DrawWindow(Core::Rectangle(tx+804,ty,tx+804+178,ty+248+172+245+96),Core::Rectangle(28, 61, 28, 20),Core::Rectangle(28.f/120.f, 61.f/120.f, 28.f/120.f, 20.f/120.f));
			Core::Rectangle rect(tx+804, ty+15, tx+804+178, ty+15+33);
			ui_render->DrawStringShadow(ui_render->font_simhei_16, font_color, ARGB(font_color.a,0,0,0), bg_color, rect, gLang->GetTextW(L"�۲���"), Unit::kAlignCenterMiddle);
			for (int rank = 0; rank < (int)game->scores->teams[2].Size(); rank ++)
			{
				Character * c = game->scores->teams[2][rank];
				if (c)
				{
					//vip

					ServerInfo* pInfo = NULL;
					for (int i = 0; i < gGame->lobby_connection->server_list.GetCount(); ++i)
					{
						if (gGame->lobby_connection->server_list[i].id == gGame->address.server_id)
						{
							pInfo = &gGame->lobby_connection->server_list[i];
							break;
						}
					}

					if (pInfo && pInfo->servertype == SvrType_Match )// SvrType_Match
					{
						LogSystem.WriteLinef("c->basecharacter_info->dan_gradingc->basecharacter_info->dan_grading = %d",c->basecharacter_info->dan_grading);
						if (c->basecharacter_info->dan_grading == 0 )
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),90,28,ig_tab_match[0]);
						}
						else if (c->basecharacter_info->dan_grading == 1 )
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),90,28,ig_tab_match[1]);
						}
						else if (c->basecharacter_info->dan_grading == 2 )
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),90,28,ig_tab_match[2]);
						}
						else if (c->basecharacter_info->dan_grading == 3 )
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),90,28,ig_tab_match[3]);
						}
						else if (c->basecharacter_info->dan_grading == 4 )
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),90,28,ig_tab_match[4]);
						}
						else if (c->basecharacter_info->dan_grading == 5 )
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),90,28,ig_tab_match[5]);
						}
						else if (c->basecharacter_info->dan_grading == 6 )
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),90,28,ig_tab_match[6]);
						}
						else if (c->basecharacter_info->dan_grading == 7 )
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),90,28,ig_tab_match[7]);
						}
						else if (c->basecharacter_info->dan_grading == 8 )
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),90,28,ig_tab_match[8]);
						}
						else if (c->basecharacter_info->dan_grading == 9 )
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),90,28,ig_tab_match[9]);
						}
						else if (c->basecharacter_info->dan_grading == 10 )
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),90,28,ig_tab_match[10]);
						}
						else if (c->basecharacter_info->dan_grading == 11 )
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),90,28,ig_tab_match[11]);
						}
						else if (c->basecharacter_info->dan_grading == 12 )
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),90,28,ig_tab_match[12]);
						}
						else if (c->basecharacter_info->dan_grading == 13 )
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),90,28,ig_tab_match[13]);
						}
					}
					else
					{
						if (c->is_vip > 0)
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),40,28,ig_tab_vip[c->is_vip-1]);
						}

					}
				/*	if (c->is_vip > 0)
					{
						ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),40,28,ig_tab_vip[c->is_vip-1]);
					}*/
					//else if (c->is_vip == 2)
					//{
					//	ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+33+5+24*rank),24,16,ig_tab_xunleivip);
					//}
					if (c->HasBomb())
					{
						ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),28,28,ui_textures[8]);
					}
					rect = Core::Rectangle(tx+850, ty+15+33+5+24*rank, tx+860+130, ty+15+33+5+24*(rank+1));
					ui_render->DrawStringShadow(ui_render->font_simhei_14, name_color, ARGB(font_color.a,0,0,0), bg_color, rect, PeopleName_cut(c->GetName(),5), Unit::kAlignLeftMiddle);
				}
			}
		}

		//����
		int member_pos = 0;
		for (uint rank = 0; rank < game->scores->teams[viewer->GetTeam()].Size(); rank ++)
		{
			Character * c = game->scores->teams[viewer->GetTeam()][rank];
			if(c==viewer)
			{
				member_pos = rank;
				break;
			}
		}
		member_pos++;

		float cursor_y = ty+13;
		float cursor_x = tx+15;
		for (int team = 0 ; team < 2; ++team)
		{
			if (team == 0)
			{
				int people_num = gGame->scores->teams[0].Size();
				float cursor_y = ty;
				float cursor_x = tx;
				int	  residue_num = 0;
				for (int rank = 0;rank < people_num; rank++)
				{
					if (rank > 1)
					{
						cursor_y = ty + 90;
					}
					residue_num = rank%2;
					Character * c = game->scores->teams[0][rank];
					if (c  && !c->IsDied())
					{
						ui_render->SetTexture(ui_tab_zombie_watch);
						ui_render->DrawWindow(Core::Rectangle((cursor_x+61)+450*residue_num,cursor_y+24,(cursor_x+61+66)+450*residue_num,cursor_y+24+77),Core::Rectangle(5, 6, 5, 6),Core::Rectangle(5.f/66.f, 6.f/77.f, 5.f/66.f, 6.f/77.f));
						name_color = ARGB(255,255,244,220);
						if (c->IsDied())
							name_color = ARGB(255,128,128,128);
						else if (!c->connected)
							name_color = ARGB(128,255,255,0);

						//ѡ���Լ��Ŀ�
						/*if (c == game->level->GetPlayer())
						{
							ui_render->SetTexture(ig_tab_line);
							ui_render->DrawWindow(Core::Rectangle(cursor_x ,cursor_y+33+24*rank,tx+791,cursor_y+33+24*(rank+1)),Core::Rectangle(4, 4, 4, 4),Core::Rectangle(4.f/24.f, 4.f/24.f, 4.f/24.f, 4.f/24.f));						
						}*/
						/*Core::Rectangle rect2(cursor_x, cursor_y+33+24*rank, cursor_x+95, cursor_y+33+24*(rank+1));
						str.format("%d", rank + 1);
						ui_render->DrawStringShadow(ui_render->font_simhei_14, name_color, ARGB(font_color.a,0,0,0), bg_color, rect2, str, Unit::kAlignCenterMiddle);*/
	
						// draw ��������
						ui_render->DrawFontWindow(Core::Vector2((cursor_x+61+66)+450*residue_num,cursor_y+24), 100, 20, ui_render->font_simhei_16, name_color,  Core::ARGB(0, 0, 0, 0), PeopleName_cut(c->GetName(),4), Unit::kAlignCenterMiddle);

						if (c->GetCurCharinfo())
						{
							//draw ����ͷ��
							tempc_ptr(Texture2D) head_texture = c->ui_head_icon;
							if (head_texture)
								ui_render->DrawTextureWindow(Core::Vector2((cursor_x+71)+450*residue_num,cursor_y+31), 46, 64, head_texture);
						}

						//vip

						ServerInfo* pInfo = NULL;
						for (int i = 0; i < gGame->lobby_connection->server_list.GetCount(); ++i)
						{
							if (gGame->lobby_connection->server_list[i].id == gGame->address.server_id)
							{
								pInfo = &gGame->lobby_connection->server_list[i];
								break;
							}
						}

						if (pInfo && pInfo->servertype == SvrType_Match )// SvrType_Match
						{
							LogSystem.WriteLinef("c->basecharacter_info->dan_gradingc->basecharacter_info->dan_grading = %d",c->basecharacter_info->dan_grading);
							if (c->basecharacter_info->dan_grading == 0)
							{
								ui_render->DrawTextureWindow(Vector2((cursor_x+58)+450*residue_num,cursor_y+23),90,28,ig_tab_match[0]);
							}
							else if (c->basecharacter_info->dan_grading == 1 )
							{
								ui_render->DrawTextureWindow(Vector2((cursor_x+58)+450*residue_num,cursor_y+23),90,28,ig_tab_match[1]);
							}
							else if (c->basecharacter_info->dan_grading == 2 )
							{
								ui_render->DrawTextureWindow(Vector2((cursor_x+58)+450*residue_num,cursor_y+23),90,28,ig_tab_match[2]);
							}
							else if (c->basecharacter_info->dan_grading == 3 )
							{
								ui_render->DrawTextureWindow(Vector2((cursor_x+58)+450*residue_num,cursor_y+23),90,28,ig_tab_match[3]);
							}
							else if (c->basecharacter_info->dan_grading == 4 )
							{
								ui_render->DrawTextureWindow(Vector2((cursor_x+58)+450*residue_num,cursor_y+23),90,28,ig_tab_match[4]);
							}
							else if (c->basecharacter_info->dan_grading == 5 )
							{
								ui_render->DrawTextureWindow(Vector2((cursor_x+58)+450*residue_num,cursor_y+23),90,28,ig_tab_match[5]);
							}
							else if (c->basecharacter_info->dan_grading == 6 )
							{
								ui_render->DrawTextureWindow(Vector2((cursor_x+58)+450*residue_num,cursor_y+23),90,28,ig_tab_match[6]);
							}
							else if (c->basecharacter_info->dan_grading == 7 )
							{
								ui_render->DrawTextureWindow(Vector2((cursor_x+58)+450*residue_num,cursor_y+23),90,28,ig_tab_match[7]);
							}
							else if (c->basecharacter_info->dan_grading == 8 )
							{
								ui_render->DrawTextureWindow(Vector2((cursor_x+58)+450*residue_num,cursor_y+23),90,28,ig_tab_match[8]);
							}
							else if (c->basecharacter_info->dan_grading == 9 )
							{
								ui_render->DrawTextureWindow(Vector2((cursor_x+58)+450*residue_num,cursor_y+23),90,28,ig_tab_match[9]);
							}
							else if (c->basecharacter_info->dan_grading == 10 )
							{
								ui_render->DrawTextureWindow(Vector2((cursor_x+58)+450*residue_num,cursor_y+23),90,28,ig_tab_match[10]);
							}
							else if (c->basecharacter_info->dan_grading == 11 )
							{
								ui_render->DrawTextureWindow(Vector2((cursor_x+58)+450*residue_num,cursor_y+23),90,28,ig_tab_match[11]);
							}
							else if (c->basecharacter_info->dan_grading == 12 )
							{
								ui_render->DrawTextureWindow(Vector2((cursor_x+58)+450*residue_num,cursor_y+23),90,28,ig_tab_match[12]);
							}
							else if (c->basecharacter_info->dan_grading == 13 )
							{
								ui_render->DrawTextureWindow(Vector2((cursor_x+58)+450*residue_num,cursor_y+23),90,28,ig_tab_match[13]);
							}
						}
						else
						{
							if (c->is_vip > 0)
							{
								ui_render->DrawTextureWindow(Vector2((cursor_x+58)+450*residue_num,cursor_y+23),70,28,ig_tab_vip[c->is_vip-1]);
							}

						}

						//if (c->is_vip > 0)
						//{
						//	ui_render->DrawTextureWindow(Vector2((cursor_x+58)+450*residue_num,cursor_y+23),40,28,ig_tab_vip[c->is_vip-1]);
						//}
						//else if (c->is_vip == 2)
						//{
						//	ui_render->DrawTextureWindow(Vector2((cursor_x+58)+450*residue_num,cursor_y+23),24,16,ig_tab_xunleivip);
						//}

						float progress = Core::Clamp((float)c->hp / (float)c->max_hp, 0, 1);
						float dying_progress = 1;
						for (int i = 0;i < 2;i++)
						{
							ui_render->SetTexture(ui_tab_zombie_hp_bg);
							ui_render->DrawWindow(Core::Rectangle((cursor_x+61+66)+450*residue_num,(cursor_y+24+20)+16*i,(cursor_x+61+70+98)+450*residue_num,(cursor_y+24+20+11)+16*i),
								Core::Rectangle(5,3,5,3),Core::Rectangle(5 / 12.f, 3.f / 11.f, 5 / 12.f, 3.f / 11.f));
						}
						
						//draw ���ѱ�����Ѫ��
						if(c->zombie_dying_flag == 1)
						{						
							if (progress <= 0)
							{
								progress = 0;
							}
							ui_render->SetTexture(ui_common_hp[2]);
							ui_render->DrawWindow(Core::Rectangle((cursor_x+61+66)+450*residue_num,cursor_y+22+36,(cursor_x+61+70+98*progress)+450*residue_num,cursor_y+22+36+15),
								Core::Rectangle(5,3,5,3),Core::Rectangle(5 / 32.f, 3.f / 16.f, 5 / 32.f, 3.f / 16.f));
							dying_progress = progress;
						}
						else
						{
							//draw ����Ѫ��
							if (progress <= 0)
							{
								progress = 0;
							}
							if (progress > 0.6f)
								ui_render->SetTexture(ui_common_hp[0]);
							else if (progress > 0.3f)
								ui_render->SetTexture(ui_common_hp[1]);
							else
								ui_render->SetTexture(ui_common_hp[2]);

							if(c->hp != 0)
								ui_render->DrawWindow(Core::Rectangle((cursor_x+61+66)+450*residue_num,cursor_y+22+20,(cursor_x+61+70+98*progress)+450*residue_num,cursor_y+22+20+15),
								Core::Rectangle(5,3,5,3),Core::Rectangle(5 / 32.f, 3.f / 16.f, 5 / 32.f, 3.f / 16.f));
							ui_render->SetTexture(ui_common_hp[2]);
							ui_render->DrawWindow(Core::Rectangle((cursor_x+61+66)+450*residue_num,cursor_y+22+36,(cursor_x+61+70+98*dying_progress)+450*residue_num,cursor_y+22+36+15),
								Core::Rectangle(5,3,5,3),Core::Rectangle(5 / 32.f, 3.f / 16.f, 5 / 32.f, 3.f / 16.f));
						}
						CStrBuf<256> str;
						str.format("%d", c->num_killed);
						ui_render->DrawFontWindow(Core::Vector2((cursor_x+61+66)+450*residue_num,cursor_y+75), 70, 20, ui_render->font_simhei_12, name_color,  Core::ARGB(0, 0, 0, 0), gLang->GetTextW(L"��ɱ����"), Unit::kAlignLeftTop);
						ui_render->DrawFontWindow(Core::Vector2((cursor_x+61+66+38)+450*residue_num,cursor_y+74), 30, 20, ui_render->font_simhei_12, name_color,  Core::ARGB(0, 0, 0, 0), str, Unit::kAlignCenterMiddle);

						str.format("%d", (int)c->all_score);
						ui_render->DrawFontWindow(Core::Vector2((cursor_x+61+66+118)+450*residue_num,cursor_y+75), 70, 20, ui_render->font_simhei_12,name_color,  Core::ARGB(0, 0, 0, 0), gLang->GetTextW(L"���֣�"), Unit::kAlignLeftTop);
						ui_render->DrawFontWindow(Core::Vector2((cursor_x+61+66+156)+450*residue_num,cursor_y+74), 30, 20, ui_render->font_simhei_12, name_color,  Core::ARGB(0, 0, 0, 0), str, Unit::kAlignCenterMiddle);

						str.format("%d", c->num_assist);
						ui_render->DrawFontWindow(Core::Vector2((cursor_x+61+66)+450*residue_num,cursor_y+87), 70, 20, ui_render->font_simhei_12, name_color,  Core::ARGB(0, 0, 0, 0), gLang->GetTextW(L"��������"), Unit::kAlignLeftTop);
						ui_render->DrawFontWindow(Core::Vector2((cursor_x+61+66+38)+450*residue_num,cursor_y+86), 30, 20, ui_render->font_simhei_12, name_color,  Core::ARGB(0, 0, 0, 0),str, Unit::kAlignCenterMiddle);

						ARGB pin_color = ARGB(255, 255, 238, 206); 
						if (c->ping > 1500 && !c->IsDied())
						{
							pin_color = ARGB(255, 231, 82, 41);
						}
						if (c->IsDied()|| c->isghost == true)
							pin_color = ARGB(255,128,128,128);
						str.format("%d",  c->ping);
						ui_render->DrawFontWindow(Core::Vector2((cursor_x+61+66+118)+450*residue_num,cursor_y+87), 70, 20, ui_render->font_simhei_12, name_color,  Core::ARGB(0, 0, 0, 0), gLang->GetTextW(L"�ӳ٣�"), Unit::kAlignLeftTop);
						ui_render->DrawFontWindow(Core::Vector2((cursor_x+61+66+156)+450*residue_num,cursor_y+86), 30, 20, ui_render->font_simhei_12,pin_color,  Core::ARGB(0, 0, 0, 0),str , Unit::kAlignCenterMiddle);

					}
				}
			}
			if (team == 1)
			{
				cursor_y = cursor_y+200+172-13;
			
				Core::Rectangle rect(cursor_x, cursor_y, cursor_x+95, cursor_y+33);
				ui_render->DrawStringShadow(ui_render->font_simhei_16, font_color, ARGB(font_color.a,0,0,0), bg_color, rect, gLang->GetTextW(L"����"), Unit::kAlignCenterMiddle);
				rect = Core::Rectangle(cursor_x+95, cursor_y, cursor_x+95+55, cursor_y+33);
				ui_render->DrawStringShadow(ui_render->font_simhei_16, font_color, ARGB(font_color.a,0,0,0), bg_color, rect, "", Unit::kAlignCenterMiddle);
				rect = Core::Rectangle(cursor_x+95+55, cursor_y, cursor_x+95+55+172, cursor_y+33);
				ui_render->DrawStringShadow(ui_render->font_simhei_16, font_color, ARGB(font_color.a,0,0,0), bg_color, rect, gLang->GetTextW(L"���"), Unit::kAlignCenterMiddle);
				rect = Core::Rectangle(cursor_x+95+55+172, cursor_y, cursor_x+95+55+172+78, cursor_y+33);
				ui_render->DrawStringShadow(ui_render->font_simhei_16, font_color, ARGB(font_color.a,0,0,0), bg_color, rect, gLang->GetTextW(L"ְҵ"), Unit::kAlignCenterMiddle);
				rect = Core::Rectangle(cursor_x+95+55+172+78, cursor_y, cursor_x+95+55+172+78+100, cursor_y+33);
				ui_render->DrawStringShadow(ui_render->font_simhei_16, font_color, ARGB(font_color.a,0,0,0), bg_color, rect, gLang->GetTextW(L"����"), Unit::kAlignCenterMiddle);
				rect = Core::Rectangle(cursor_x+95+55+172+78+100, cursor_y, cursor_x+95+55+172+78+100+108, cursor_y+33);
				ui_render->DrawStringShadow(ui_render->font_simhei_16, font_color, ARGB(font_color.a,0,0,0), bg_color, rect, gLang->GetTextW(L"��ɱ/����"), Unit::kAlignCenterMiddle);
				rect = Core::Rectangle(cursor_x+95+55+172+78+100+108, cursor_y, cursor_x+95+55+172+78+100+108+79, cursor_y+33);
				ui_render->DrawStringShadow(ui_render->font_simhei_16, font_color, ARGB(font_color.a,0,0,0), bg_color, rect, gLang->GetTextW(L"����"), Unit::kAlignCenterMiddle);
				rect = Core::Rectangle(cursor_x+95+55+172+78+100+108+79, cursor_y, cursor_x+95+55+172+78+100+108+79+89, cursor_y+33);
				ui_render->DrawStringShadow(ui_render->font_simhei_16, font_color, ARGB(font_color.a,0,0,0), bg_color, rect, gLang->GetTextW(L"��ʱ"), Unit::kAlignCenterMiddle);
				CStrBuf<256> str;
				for (uint rank = 0; rank < game->scores->teams[1].Size(); rank ++)
				{
					Character * c = game->scores->teams[1][rank];
					if (c)
					{
						name_color = ARGB(255,255,244,220);
						if (c->IsDied()||c->isghost == true)
							name_color = ARGB(255,128,128,128);

						else if (!c->connected)
							name_color = ARGB(128,255,255,0);
						int card_num = (int)c->business_card;
						if (c->is_vip > 0)
						{
							ui_render->SetTexture(ui_common_tab_vip_name_card[c->is_vip]);
							ui_render->DrawWindow(Core::Rectangle(cursor_x ,cursor_y+33+24*rank,tx+216,cursor_y+33+24*(rank+1)),
								Core::Rectangle(4, 4, 4, 4),Core::Rectangle(4.f/24.f, 4.f/24.f, 4.f/24.f, 4.f/24.f),Core::ARGB(255,255,255,255),Core::ARGB(255,255,255,255));
						}
						if (card_num > 0 && card_num < 18)
						{
							ui_render->SetTexture(ui_common_tab_name_cards[card_num-1]);
							ui_render->DrawWindow(Core::Rectangle(cursor_x,cursor_y+33+24*rank,tx+216,cursor_y+33+24*(rank+1)),
								Core::Rectangle(0, 0, 0, 0),Core::Rectangle(0.f/1.f, 0.f/1.f, 0.f/1.f,0.f/1.f),Core::ARGB(255,255,255,255),Core::ARGB(255,255,255,255));
						}
						if (c == game->level->GetPlayer())
						{
							ui_render->SetTexture(ig_tab_line);
							ui_render->DrawWindow(Core::Rectangle(cursor_x ,cursor_y+33+24*rank,tx+791,cursor_y+33+24*(rank+1)),Core::Rectangle(4, 4, 4, 4),Core::Rectangle(4.f/24.f, 4.f/24.f, 4.f/24.f, 4.f/24.f));						
						}
						Core::Rectangle rect2(cursor_x, cursor_y+33+24*rank, cursor_x+95, cursor_y+33+24*(rank+1));
						str.format("%d", rank + 1);
						ui_render->DrawStringShadow(ui_render->font_simhei_14, name_color, ARGB(font_color.a,0,0,0), bg_color, rect2, str, Unit::kAlignCenterMiddle);

						//vip
						ServerInfo* pInfo = NULL;
						for (int i = 0; i < gGame->lobby_connection->server_list.GetCount(); ++i)
						{
							if (gGame->lobby_connection->server_list[i].id == gGame->address.server_id)
							{
								pInfo = &gGame->lobby_connection->server_list[i];
								break;
							}
						}
						
						if (pInfo && pInfo->servertype == SvrType_Match )// SvrType_Match
						{
							LogSystem.WriteLinef("c->basecharacter_info->dan_gradingc->basecharacter_info->dan_grading = %d",c->basecharacter_info->dan_grading);
							if (c->basecharacter_info->dan_grading == 0)
							{
								ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),90,28,ig_tab_match[0]);
							}
							else if (c->basecharacter_info->dan_grading == 1 )
							{
								ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),90,28,ig_tab_match[1]);
							}
							else if (c->basecharacter_info->dan_grading == 2 )
							{
								ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),90,28,ig_tab_match[2]);
							}
							else if (c->basecharacter_info->dan_grading == 3 )
							{
								ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),90,28,ig_tab_match[3]);
							}
							else if (c->basecharacter_info->dan_grading == 4 )
							{
								ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),90,28,ig_tab_match[4]);
							}
							else if (c->basecharacter_info->dan_grading == 5 )
							{
								ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),90,28,ig_tab_match[5]);
							}
							else if (c->basecharacter_info->dan_grading == 6 )
							{
								ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),90,28,ig_tab_match[6]);
							}
							else if (c->basecharacter_info->dan_grading == 7 )
							{
								ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),90,28,ig_tab_match[7]);
							}
							else if (c->basecharacter_info->dan_grading == 8 )
							{
								ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),90,28,ig_tab_match[8]);
							}
							else if (c->basecharacter_info->dan_grading == 9 )
							{
								ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),90,28,ig_tab_match[9]);
							}
							else if (c->basecharacter_info->dan_grading == 10 )
							{
								ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),90,28,ig_tab_match[10]);
							}
							else if (c->basecharacter_info->dan_grading == 11 )
							{
								ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),90,28,ig_tab_match[11]);
							}
							else if (c->basecharacter_info->dan_grading == 12 )
							{
								ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),90,28,ig_tab_match[12]);
							}
							else if (c->basecharacter_info->dan_grading == 13 )
							{
								ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),90,28,ig_tab_match[13]);
							}
						}
						else
						{
							if (c->is_vip > 0)
							{
								ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),40,28,ig_tab_vip[c->is_vip-1]);
							}

						}

						rect2 = Core::Rectangle(cursor_x+95+55, cursor_y+33+24*rank, cursor_x+95+55+172, cursor_y+33+24*(rank+1));
						ui_render->DrawStringShadow(ui_render->font_simhei_14, name_color, ARGB(font_color.a,0,0,0), bg_color, rect2, c->GetName(), Unit::kAlignCenterMiddle);

						rect2 = Core::Rectangle(cursor_x+95+55+172, cursor_y+33+24*rank, cursor_x+95+55+172+78, cursor_y+33+24*(rank+1));
						str.format("%s", gLang->GetTextW(L"δѡ��"));
						if (c->GetCurCharinfo())
						{
							str.format("%s", c->GetCurCharinfo()->career_name.Str());
						}
						ui_render->DrawStringShadow(ui_render->font_simhei_14, name_color, ARGB(font_color.a,0,0,0), bg_color, rect2, str, Unit::kAlignCenterMiddle);

						rect2 = Core::Rectangle(cursor_x+95+55+172+78, cursor_y+33+24*rank, cursor_x+95+55+172+78+100, cursor_y+33+24*(rank+1));
						str.format("%d", (int)c->all_score);
						ui_render->DrawStringShadow(ui_render->font_simhei_14, name_color, ARGB(font_color.a,0,0,0), bg_color, rect2, str, Unit::kAlignCenterMiddle);

						rect2 = Core::Rectangle(cursor_x+95+55+172+78+100, cursor_y+33+24*rank, cursor_x+95+55+172+78+100+108, cursor_y+33+24*(rank+1));
						str.format("%d/%d", c->num_killed, c->num_died);
						ui_render->DrawStringShadow(ui_render->font_simhei_14, name_color, ARGB(font_color.a,0,0,0), bg_color, rect2, str, Unit::kAlignCenterMiddle);

						rect2 = Core::Rectangle(cursor_x+95+55+172+78+100+108, cursor_y+33+24*rank, cursor_x+95+55+172+78+100+108+79, cursor_y+33+24*(rank+1));
						str.format("%d", c->num_assist);
						ui_render->DrawStringShadow(ui_render->font_simhei_14, name_color, ARGB(font_color.a,0,0,0), bg_color, rect2, str, Unit::kAlignCenterMiddle);

						rect2 = Core::Rectangle(cursor_x+95+55+172+78+100+108+79, cursor_y+33+24*rank, cursor_x+95+55+172+78+100+108+79+89, cursor_y+33+24*(rank+1));
						str.format("%d", c->ping);
						ARGB pin_color = name_color;
						if (c->ping > 1500)
						{
							pin_color = ARGB(231, 82, 41);
						}
						ui_render->DrawStringShadow(ui_render->font_simhei_14, pin_color, ARGB(font_color.a,0,0,0), bg_color, rect2, str, Unit::kAlignCenterMiddle);
					}
				}
			}

			{
				tempc_ptr(Texture2D) tex1;
				tempc_ptr(Texture2D) tex2;
				if (gGame->scores->team_round[0] > gGame->scores->team_round[1])
				{
					tex1 = ig_tab_win_num;
					tex2 = ig_tab_lose_num;
				}	
				else if (gGame->scores->team_round[0] == gGame->scores->team_round[1])
				{
					tex1 = ig_tab_lose_num;
					tex2 = ig_tab_lose_num;
				}
				else
				{
					tex1 = ig_tab_lose_num;
					tex2 = ig_tab_win_num;
				}
				_DrawNumberTextureWindow(ui_render, tex1, Core::Vector2(tx+137, ty+233), 80, 108, gGame->scores->team_round[0]/100,0.1f);
				_DrawNumberTextureWindow(ui_render, tex1, Core::Vector2(tx+137+80, ty+233), 80, 108, (gGame->scores->team_round[0]%100)/10,0.1f);
				_DrawNumberTextureWindow(ui_render, tex1, Core::Vector2(tx+137+160, ty+233), 80, 108, gGame->scores->team_round[0]%10,0.1f);

				_DrawNumberTextureWindow(ui_render, tex2, Core::Vector2(tx+430, ty+233), 80, 108, gGame->scores->team_round[1]/100,0.1f);
				_DrawNumberTextureWindow(ui_render, tex2, Core::Vector2(tx+430+80, ty+233), 80, 108, (gGame->scores->team_round[1]%100)/10,0.1f);
				_DrawNumberTextureWindow(ui_render, tex2, Core::Vector2(tx+430+160, ty+233), 80, 108, gGame->scores->team_round[1]%10,0.1f);
			}
		}

		CStrBuf<256> str;
		name_color = ARGB(214,214,214);
		Core::Rectangle rect3;
		str.format(gLang->GetTextW(L"ģʽ : ����ģʽ"));

		rect3 = Core::Rectangle(tx+20,ty+248+172+245+50,tx+50+95,ty+248+172+245+65);
		ui_render->DrawStringShadow(ui_render->font_simhei_14, name_color, ARGB(font_color.a,0,0,0), bg_color, rect3, str, Unit::kAlignLeftMiddle);

		rect3 = Core::Rectangle(tx+50+200,ty+248+172+245+50,tx+50+200+95,ty+248+172+245+65);
		str.format(gLang->GetTextW(L"��ͼ�� : %s"),gLevel->name2);
		ui_render->DrawStringShadow(ui_render->font_simhei_14, name_color, ARGB(font_color.a,0,0,0), bg_color, rect3, str, Unit::kAlignLeftMiddle);

		rect3 = Core::Rectangle(tx+50+400,ty+248+172+245+50,tx+50+95+400,ty+248+172+245+65);

		{
			if(gLevel->GetPlayer()->GetTeam() == 0)
			{
				str.format(gLang->GetTextW(L"��ϷĿ�� : ����,�ɹ�%d�غ�ʤ��"), gLevel->rule_value);
			}
			else
			{
				str.format(gLang->GetTextW(L"��ϷĿ�� : ��ɱ�������࣬�ɹ�%d�غ�ʤ��"), gLevel->rule_value);
			}
		}

		ui_render->DrawStringShadow(ui_render->font_simhei_14, name_color, ARGB(font_color.a,255, 195, 1), bg_color, rect3, str, Unit::kAlignLeftMiddle);

		if(gGame->channel_connection && gGame->channel_connection->GetState() != ChannelConnection::kInReplay)
		{
			rect3 = Core::Rectangle(tx+20,ty+248+172+245+85,tx+50+95,ty+248+172+245+100);
			str.format(gLang->GetTextW(L"������ : %s"),gLang->GetText(gGame->address.server_name));
			ui_render->DrawStringShadow(ui_render->font_simhei_14, name_color, ARGB(font_color.a,0,0,0), bg_color, rect3, str, Unit::kAlignLeftMiddle);

			rect3 = Core::Rectangle(tx+50+200,ty+248+172+245+85,tx+50+95+200,ty+248+172+245+100);
			str.format(gLang->GetTextW(L"Ƶ�� : %s"), gLang->GetText(gGame->address.channel_name));
			ui_render->DrawStringShadow(ui_render->font_simhei_14, name_color, ARGB(font_color.a,0,0,0), bg_color, rect3, str, Unit::kAlignLeftMiddle);

			rect3 = Core::Rectangle(tx+50+400,ty+248+172+245+85,tx+50+95+400,ty+248+172+245+100);
			if (gGame->channel_connection->room_info.option.name)
			{
				str.format(gLang->GetTextW(L"���� : %s"),gGame->channel_connection->room_info.option.name);
				ui_render->DrawStringShadow(ui_render->font_simhei_14, name_color, ARGB(font_color.a,0,0,0), bg_color, rect3, str, Unit::kAlignLeftMiddle);
			}			
		}

		if (show_game_scores)
		{
			Matrix44 view, oldview, oldworld;
			oldworld = world;

			float scale = 1;
			win_time += Core::Task::GetFrameTime();
			win_anim.scale_spline.Interpolation(win_time, scale);

			world.ScaleXYZ(scale, scale, 1);
			world.Translate(Vector3(0, 0, 0));
			int win_x = 0;
			if (win_team == 0)
			{
				win_x = havewatch ? -509 : -420;
				world.TranslateXYZ(win_x, -30, 0);
			}
			else if (win_team == 1)
			{
				win_x = havewatch ? 231: 320;
				world.TranslateXYZ(win_x, -20, 0);
			}
			else
				return;
			ui_render->SetWorld(world);

			ui_render->DrawTextureWindow(Core::Vector2(-50, -100), 220, 212, ui_win, Core::Rectangle(0,0,1,1),Core::ARGB(255,255,255,255));

			ui_render->SetView(oldview);
			ui_render->SetWorld(oldworld);
		}
		else
		{
			win_time = 0;
		}
	}
}

void InGameUINew::_DrawStartZombieTab(by_ptr(UIRender) ui_render)
{
	tempc_ptr(Character) viewer = gLevel->GetViewer();
	Matrix44 world;
	Core::Vector3 rt_size = gGame->guiSys->GetSize();
	Game * game = gGame;

	if (gLevel->game_type == RoomOption::kNovice)
		return;

	// draw tab
	if(!viewer)
	{
		tempc_ptr(Character) player = gLevel->GetPlayer();
		if(player)
			viewer = player;
	}

	if ((show_game_scores || show_scores) && viewer && viewer->GetTeam() <= 2)
	{
		world.SetTranslationXYZ(0, 0, 0);
		ui_render->SetWorld(world);
		ARGB name_color = ARGB(255,244,220);
		ARGB bg_color = ARGB(0,0,0,0);
		ARGB font_color = ARGB(150,215,232,227);

		bool havewatch = false;
		for (uint rank = 0; rank < game->scores->teams[2].Size(); rank ++)
		{
			Character * c = game->scores->teams[2][rank];
			if (c)
			{
				havewatch = true;
			}
		}

		int tx = -388;
		int ty = -364;
		if (havewatch)
		{
			tx -=(178/2);
		}
		ui_render->SetTexture(ui_tab_red);
		ui_render->DrawWindow(Core::Rectangle(tx,ty,tx+804,ty+248+172+245),Core::Rectangle(15, 15, 15, 15),Core::Rectangle(15.f/96.f, 15.f/52.f, 15.f/96.f, 15.f/52.f));

		ui_render->SetTexture(ui_tab_bottom);
		ui_render->DrawWindow(Core::Rectangle(tx,ty+248+172+245,tx+804,ty+248+172+245+96),Core::Rectangle(15, 15, 15, 15),Core::Rectangle(15.f/60.f, 15.f/44.f, 15.f/60.f, 15.f/44.f));

		ui_render->SetTexture(ig_tab_bg2);
		ui_render->DrawWindow(Core::Rectangle(tx+15,ty+13,tx+15+776,ty+13+33),Core::Rectangle(0, 0, 0, 0),Core::Rectangle(1.f/32.f, 1.f/32.f, 1.f/32.f, 1.f/32.f));

		if (havewatch)
		{
			ui_render->SetTexture(ui_tab_watch);
			ui_render->DrawWindow(Core::Rectangle(tx+804,ty,tx+804+178,ty+248+172+245+96),Core::Rectangle(28, 61, 28, 20),Core::Rectangle(28.f/120.f, 61.f/120.f, 28.f/120.f, 20.f/120.f));
			Core::Rectangle rect(tx+804, ty+15, tx+804+178, ty+15+33);
			ui_render->DrawStringShadow(ui_render->font_simhei_16, font_color, ARGB(font_color.a,0,0,0), bg_color, rect, gLang->GetTextW(L"�۲���"), Unit::kAlignCenterMiddle);
			for (int rank = 0; rank < (int)game->scores->teams[2].Size(); rank ++)
			{
				Character * c = game->scores->teams[2][rank];
				if (c)
				{
					//vip

					ServerInfo* pInfo = NULL;
					for (int i = 0; i < gGame->lobby_connection->server_list.GetCount(); ++i)
					{
						if (gGame->lobby_connection->server_list[i].id == gGame->address.server_id)
						{
							pInfo = &gGame->lobby_connection->server_list[i];
							break;
						}
					}

					if (pInfo && pInfo->servertype == SvrType_Match )// SvrType_Match
					{
						LogSystem.WriteLinef("c->basecharacter_info->dan_gradingc->basecharacter_info->dan_grading = %d",c->basecharacter_info->dan_grading);
						if (c->basecharacter_info->dan_grading == 0)
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),90,28,ig_tab_match[0]);
						}
						else if (c->basecharacter_info->dan_grading == 1 )
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),90,28,ig_tab_match[1]);
						}
						else if (c->basecharacter_info->dan_grading == 2 )
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),90,28,ig_tab_match[2]);
						}
						else if (c->basecharacter_info->dan_grading == 3 )
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),90,28,ig_tab_match[3]);
						}
						else if (c->basecharacter_info->dan_grading == 4 )
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),90,28,ig_tab_match[4]);
						}
						else if (c->basecharacter_info->dan_grading == 5 )
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),90,28,ig_tab_match[5]);
						}
						else if (c->basecharacter_info->dan_grading == 6 )
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),90,28,ig_tab_match[6]);
						}
						else if (c->basecharacter_info->dan_grading == 7 )
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),90,28,ig_tab_match[7]);
						}
						else if (c->basecharacter_info->dan_grading == 8 )
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),90,28,ig_tab_match[8]);
						}
						else if (c->basecharacter_info->dan_grading == 9 )
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),90,28,ig_tab_match[9]);
						}
						else if (c->basecharacter_info->dan_grading == 10 )
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),90,28,ig_tab_match[10]);
						}
						else if (c->basecharacter_info->dan_grading == 11 )
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),90,28,ig_tab_match[11]);
						}
						else if (c->basecharacter_info->dan_grading == 12 )
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),90,28,ig_tab_match[12]);
						}
						else if (c->basecharacter_info->dan_grading == 13 )
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),90,28,ig_tab_match[13]);
						}
					}
					else
					{
						if (c->is_vip > 0)
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),40,28,ig_tab_vip[c->is_vip-1]);
						}

					}

					/*if (c->is_vip > 0)
					{
						ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),40,28,ig_tab_vip[c->is_vip-1]);
					}*/
					//else if (c->is_vip == 2)
					//{
					//	ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+33+5+24*rank),24,16,ig_tab_xunleivip);
					//}
					if (c->HasBomb())
					{
						ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),28,28,ui_textures[8]);
					}
					rect = Core::Rectangle(tx+850, ty+15+33+5+24*rank, tx+860+130, ty+15+33+5+24*(rank+1));
					ui_render->DrawStringShadow(ui_render->font_simhei_14, name_color, ARGB(font_color.a,0,0,0), bg_color, rect, PeopleName_cut(c->GetName(),5), Unit::kAlignLeftMiddle);
				}
			}
		}

		//����
		int member_pos = 0;
		for (uint rank = 0; rank < game->scores->teams[viewer->GetTeam()].Size(); rank ++)
		{
			Character * c = game->scores->teams[viewer->GetTeam()][rank];
			if(c==viewer)
			{
				member_pos = rank;
				break;
			}
		}
		member_pos++;

		float cursor_y = ty+13;
		float cursor_x = tx+15;
		//for (int team = 0 ; team < 1; ++team)
		//{
			Core::Rectangle rect(cursor_x, cursor_y, cursor_x+95, cursor_y+33);
			ui_render->DrawStringShadow(ui_render->font_simhei_16, font_color, ARGB(font_color.a,0,0,0), bg_color, rect, gLang->GetTextW(L"����"), Unit::kAlignCenterMiddle);
			rect = Core::Rectangle(cursor_x+95, cursor_y, cursor_x+95+55, cursor_y+33);
			ui_render->DrawStringShadow(ui_render->font_simhei_16, font_color, ARGB(font_color.a,0,0,0), bg_color, rect, "", Unit::kAlignCenterMiddle);
			rect = Core::Rectangle(cursor_x+95+55, cursor_y, cursor_x+95+55+172, cursor_y+33);
			ui_render->DrawStringShadow(ui_render->font_simhei_16, font_color, ARGB(font_color.a,0,0,0), bg_color, rect, gLang->GetTextW(L"���"), Unit::kAlignCenterMiddle);
			rect = Core::Rectangle(cursor_x+95+55+172, cursor_y, cursor_x+95+55+172+78, cursor_y+33);
			ui_render->DrawStringShadow(ui_render->font_simhei_16, font_color, ARGB(font_color.a,0,0,0), bg_color, rect, gLang->GetTextW(L"ְҵ"), Unit::kAlignCenterMiddle);
			rect = Core::Rectangle(cursor_x+95+55+172+78, cursor_y, cursor_x+95+55+172+78+100, cursor_y+33);
			ui_render->DrawStringShadow(ui_render->font_simhei_16, font_color, ARGB(font_color.a,0,0,0), bg_color, rect, gLang->GetTextW(L"����"), Unit::kAlignCenterMiddle);
			rect = Core::Rectangle(cursor_x+95+55+172+78+100, cursor_y, cursor_x+95+55+172+78+100+108, cursor_y+33);
			ui_render->DrawStringShadow(ui_render->font_simhei_16, font_color, ARGB(font_color.a,0,0,0), bg_color, rect, gLang->GetTextW(L"��ɱ/����"), Unit::kAlignCenterMiddle);
			rect = Core::Rectangle(cursor_x+95+55+172+78+100+108, cursor_y, cursor_x+95+55+172+78+100+108+79, cursor_y+33);
			ui_render->DrawStringShadow(ui_render->font_simhei_16, font_color, ARGB(font_color.a,0,0,0), bg_color, rect, gLang->GetTextW(L"����"), Unit::kAlignCenterMiddle);
			rect = Core::Rectangle(cursor_x+95+55+172+78+100+108+79, cursor_y, cursor_x+95+55+172+78+100+108+79+89, cursor_y+33);
			ui_render->DrawStringShadow(ui_render->font_simhei_16, font_color, ARGB(font_color.a,0,0,0), bg_color, rect, gLang->GetTextW(L"��ʱ"), Unit::kAlignCenterMiddle);
			CStrBuf<256> str;
			for (uint rank = 0; rank < game->scores->teams[0].Size(); rank ++)
			{
				Character * c = game->scores->teams[0][rank];
				if (c)
				{
					name_color = ARGB(255,255,244,220);
					if (c->IsDied()||c->isghost == true)
						name_color = ARGB(255,128,128,128);
					else if (!c->connected)
						name_color = ARGB(128,255,255,0);

					int card_num = (int)c->business_card;
					if (c->is_vip > 0)
					{
						ui_render->SetTexture(ui_common_tab_vip_name_card[c->is_vip]);
						ui_render->DrawWindow(Core::Rectangle(cursor_x ,cursor_y+33+24*rank,tx+216,cursor_y+33+24*(rank+1)),
							Core::Rectangle(4, 4, 4, 4),Core::Rectangle(4.f/24.f, 4.f/24.f, 4.f/24.f, 4.f/24.f),Core::ARGB(255,255,255,255),Core::ARGB(255,255,255,255));
					}
					if (card_num > 0 && card_num < 18)
					{
						ui_render->SetTexture(ui_common_tab_name_cards[card_num-1]);
						ui_render->DrawWindow(Core::Rectangle(cursor_x,cursor_y+33+24*rank,tx+216,cursor_y+33+24*(rank+1)),
							Core::Rectangle(0, 0, 0, 0),Core::Rectangle(0.f/1.f, 0.f/1.f, 0.f/1.f,0.f/1.f),Core::ARGB(255,255,255,255),Core::ARGB(255,255,255,255));
					}
					if (c == game->level->GetPlayer())
					{
						ui_render->SetTexture(ig_tab_line);
						ui_render->DrawWindow(Core::Rectangle(cursor_x ,cursor_y+33+24*rank,tx+791,cursor_y+33+24*(rank+1)),Core::Rectangle(4, 4, 4, 4),Core::Rectangle(4.f/24.f, 4.f/24.f, 4.f/24.f, 4.f/24.f));						
					}
					Core::Rectangle rect2(cursor_x, cursor_y+33+24*rank, cursor_x+95, cursor_y+33+24*(rank+1));
					str.format("%d", rank + 1);
					ui_render->DrawStringShadow(ui_render->font_simhei_14, name_color, ARGB(font_color.a,0,0,0), bg_color, rect2, str, Unit::kAlignCenterMiddle);

					//vip
					ServerInfo* pInfo = NULL;
					for (int i = 0; i < gGame->lobby_connection->server_list.GetCount(); ++i)
					{
						if (gGame->lobby_connection->server_list[i].id == gGame->address.server_id)
						{
							pInfo = &gGame->lobby_connection->server_list[i];
							break;
						}
					}

					if (pInfo && pInfo->servertype == SvrType_Match )// SvrType_Match
					{LogSystem.WriteLinef("c->basecharacter_info->dan_gradingc->basecharacter_info->dan_grading = %d",c->basecharacter_info->dan_grading);
						
						if (c->basecharacter_info->dan_grading == 0)
						{
							ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),90,28,ig_tab_match[0]);
						}
						else if (c->basecharacter_info->dan_grading == 1 )
						{
							ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),90,28,ig_tab_match[1]);
						}
						else if (c->basecharacter_info->dan_grading == 2 )
						{
							ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),90,28,ig_tab_match[2]);
						}
						else if (c->basecharacter_info->dan_grading == 3 )
						{
							ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),90,28,ig_tab_match[3]);
						}
						else if (c->basecharacter_info->dan_grading == 4 )
						{
							ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),90,28,ig_tab_match[4]);
						}
						else if (c->basecharacter_info->dan_grading == 5 )
						{
							ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),90,28,ig_tab_match[5]);
						}
						else if (c->basecharacter_info->dan_grading == 6 )
						{
							ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),90,28,ig_tab_match[6]);
						}
						else if (c->basecharacter_info->dan_grading == 7 )
						{
							ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),90,28,ig_tab_match[7]);
						}
						else if (c->basecharacter_info->dan_grading == 8 )
						{
							ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),90,28,ig_tab_match[8]);
						}
						else if (c->basecharacter_info->dan_grading == 9 )
						{
							ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),90,28,ig_tab_match[9]);
						}
						else if (c->basecharacter_info->dan_grading == 10 )
						{
							ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),90,28,ig_tab_match[10]);
						}
						else if (c->basecharacter_info->dan_grading == 11 )
						{
							ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),90,28,ig_tab_match[11]);
						}
						else if (c->basecharacter_info->dan_grading == 12 )
						{
							ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),90,28,ig_tab_match[12]);
						}
						else if (c->basecharacter_info->dan_grading == 13 )
						{
							ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),90,28,ig_tab_match[13]);
						}
					}
					else
					{
						if (c->is_vip > 0)
						{
							ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),40,28,ig_tab_vip[c->is_vip-1]);
						}

					}

				/*	if (c->is_vip > 0)
					{
						ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),40,28,ig_tab_vip[c->is_vip-1]);
					}*/
					//else if (c->is_vip == 2)
					//{
					//	ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+38+24*rank),24,16,ig_tab_xunleivip);
					//}

					rect2 = Core::Rectangle(cursor_x+95+55, cursor_y+33+24*rank, cursor_x+95+55+172, cursor_y+33+24*(rank+1));
					ui_render->DrawStringShadow(ui_render->font_simhei_14, name_color, ARGB(font_color.a,0,0,0), bg_color, rect2, c->GetName(), Unit::kAlignCenterMiddle);

					rect2 = Core::Rectangle(cursor_x+95+55+172, cursor_y+33+24*rank, cursor_x+95+55+172+78, cursor_y+33+24*(rank+1));
					str.format("%s", gLang->GetTextW(L"δѡ��"));
					if (c->GetCurCharinfo())
					{
						str.format("%s", c->GetCurCharinfo()->career_name.Str());
					}
					ui_render->DrawStringShadow(ui_render->font_simhei_14, name_color, ARGB(font_color.a,0,0,0), bg_color, rect2, str, Unit::kAlignCenterMiddle);

					rect2 = Core::Rectangle(cursor_x+95+55+172+78, cursor_y+33+24*rank, cursor_x+95+55+172+78+100, cursor_y+33+24*(rank+1));
					str.format("%d", (int)c->all_score);
					ui_render->DrawStringShadow(ui_render->font_simhei_14, name_color, ARGB(font_color.a,0,0,0), bg_color, rect2, str, Unit::kAlignCenterMiddle);

					rect2 = Core::Rectangle(cursor_x+95+55+172+78+100, cursor_y+33+24*rank, cursor_x+95+55+172+78+100+108, cursor_y+33+24*(rank+1));
					str.format("%d/%d", c->num_killed, c->num_died);
					ui_render->DrawStringShadow(ui_render->font_simhei_14, name_color, ARGB(font_color.a,0,0,0), bg_color, rect2, str, Unit::kAlignCenterMiddle);

					rect2 = Core::Rectangle(cursor_x+95+55+172+78+100+108, cursor_y+33+24*rank, cursor_x+95+55+172+78+100+108+79, cursor_y+33+24*(rank+1));
					str.format("%d", c->num_assist);
					ui_render->DrawStringShadow(ui_render->font_simhei_14, name_color, ARGB(font_color.a,0,0,0), bg_color, rect2, str, Unit::kAlignCenterMiddle);

					rect2 = Core::Rectangle(cursor_x+95+55+172+78+100+108+79, cursor_y+33+24*rank, cursor_x+95+55+172+78+100+108+79+89, cursor_y+33+24*(rank+1));
					str.format("%d", c->ping);
					ARGB pin_color = name_color;
					if (c->ping > 1500)
					{
						pin_color = ARGB(231, 82, 41);
					}
					ui_render->DrawStringShadow(ui_render->font_simhei_14, pin_color, ARGB(font_color.a,0,0,0), bg_color, rect2, str, Unit::kAlignCenterMiddle);
				}
			}
		//}

		//CStrBuf<256> str;
		name_color = ARGB(214,214,214);
		Core::Rectangle rect3;
		str.format(gLang->GetTextW(L"ģʽ : ����ģʽ"));

		rect3 = Core::Rectangle(tx+20,ty+248+172+245+15,tx+50+95,ty+248+172+245+30);
		ui_render->DrawStringShadow(ui_render->font_simhei_14, name_color, ARGB(font_color.a,0,0,0), bg_color, rect3, str, Unit::kAlignLeftMiddle);

		rect3 = Core::Rectangle(tx+50+200,ty+248+172+245+15,tx+50+200+95,ty+248+172+245+30);
		str.format(gLang->GetTextW(L"��ͼ�� : %s"),gLevel->name2);
		ui_render->DrawStringShadow(ui_render->font_simhei_14, name_color, ARGB(font_color.a,0,0,0), bg_color, rect3, str, Unit::kAlignLeftMiddle);

		rect3 = Core::Rectangle(tx+50+400,ty+248+172+245+15,tx+50+95+400,ty+248+172+245+30);
		{
			if(gLevel->GetPlayer()->GetTeam() == 0)
			{
				str.format(gLang->GetTextW(L"��ϷĿ�� : ����,�ɹ�%d�غ�ʤ��"), gLevel->rule_value);
			}
			else
			{
				str.format(gLang->GetTextW(L"��ϷĿ�� : ��ɱ�������࣬�ɹ�%d�غ�ʤ��"), gLevel->rule_value);
			}
		}

		ui_render->DrawStringShadow(ui_render->font_simhei_14, name_color, ARGB(font_color.a,255, 195, 1), bg_color, rect3, str, Unit::kAlignLeftMiddle);

		if(gGame->channel_connection && gGame->channel_connection->GetState() != ChannelConnection::kInReplay)
		{
			rect3 = Core::Rectangle(tx+20,ty+248+172+245+50,tx+50+95,ty+248+172+245+65);
			str.format(gLang->GetTextW(L"������ : %s"),gLang->GetText(gGame->address.server_name));
			ui_render->DrawStringShadow(ui_render->font_simhei_14, name_color, ARGB(font_color.a,0,0,0), bg_color, rect3, str, Unit::kAlignLeftMiddle);

			rect3 = Core::Rectangle(tx+50+200,ty+248+172+245+50,tx+50+95+200,ty+248+172+245+65);
			str.format(gLang->GetTextW(L"Ƶ�� : %s"),gLang->GetText(gGame->address.channel_name));
			ui_render->DrawStringShadow(ui_render->font_simhei_14, name_color, ARGB(font_color.a,0,0,0), bg_color, rect3, str, Unit::kAlignLeftMiddle);

			rect3 = Core::Rectangle(tx+50+400,ty+248+172+245+50,tx+50+95+400,ty+248+172+245+65);
			if (gGame->channel_connection->room_info.option.name)
			{
				str.format(gLang->GetTextW(L"���� : %s"),gGame->channel_connection->room_info.option.name);
				ui_render->DrawStringShadow(ui_render->font_simhei_14, name_color, ARGB(font_color.a,0,0,0), bg_color, rect3, str, Unit::kAlignLeftMiddle);
			}			
		}

		if (show_game_scores)
		{
			Matrix44 view, oldview, oldworld;
			oldworld = world;

			float scale = 1;
			win_time += Core::Task::GetFrameTime();
			win_anim.scale_spline.Interpolation(win_time, scale);

			world.ScaleXYZ(scale, scale, 1);
			world.Translate(Vector3(0, 0, 0));
			int win_x = 0;
			if (win_team == 0)
			{
				win_x = havewatch ? -509 : -420;
				world.TranslateXYZ(win_x, -30, 0);
			}
			else if (win_team == 1)
			{
				win_x = havewatch ? 231: 320;
				world.TranslateXYZ(win_x, -20, 0);
			}
			else
				return;
			ui_render->SetWorld(world);

			ui_render->DrawTextureWindow(Core::Vector2(-50, -100), 220, 212, ui_win, Core::Rectangle(0,0,1,1),Core::ARGB(255,255,255,255));

			ui_render->SetView(oldview);
			ui_render->SetWorld(oldworld);
		}
		else
		{
			win_time = 0;
		}
	}	
}

bool InGameUINew::_GetDrawHelpPeopleUI()
{
	tempc_ptr(Character) player = gLevel->GetPlayer();
	Game * game = gGame;
	Core::Vector3 pos;
	for (uint rank = 0; rank < game->scores->teams[0].Size(); rank ++)
	{
		Character * c = game->scores->teams[0][rank];
		if (c != player && c->zombie_dying_flag)
		{
			pos = player->GetPosition() - c->GetPosition();
			if (pos.Length() < 5)
			{
				return true;
			}
		}
	}
	return false;
}

void InGameUINew::_DrawBossTab(by_ptr(UIRender) ui_render)
{
	tempc_ptr(Character) viewer = gLevel->GetViewer();
	Matrix44 world;
	Core::Vector3 rt_size = gGame->guiSys->GetSize();
	Game * game = gGame;

	if (gLevel->game_type == RoomOption::kNovice)
		return;

	// draw tab
	if(!viewer)
	{
		tempc_ptr(Character) player = gLevel->GetPlayer();
		if(player)
			viewer = player;
	}

	if ((show_game_scores || show_scores) && viewer && viewer->GetTeam() <= 2)
	{
		world.SetTranslationXYZ(0, 0, 0);
		ui_render->SetWorld(world);
		ARGB name_color = ARGB(255,244,220);
		ARGB bg_color = ARGB(0,0,0,0);
		ARGB font_color = ARGB(150,215,232,227);

		bool havewatch = false;
		for (uint rank = 0; rank < game->scores->teams[2].Size(); rank ++)
		{
			Character * c = game->scores->teams[2][rank];
			if (c)
			{
				havewatch = true;
			}
		}

		int tx = -388;
		int ty = -364;
		int t_boss_mode2_y = 0;
		if (havewatch)
		{
			tx -=(178/2);
		}
		if (gLevel->game_type == RoomOption::kBossMode2)
		{
			t_boss_mode2_y = 24*(game->scores->teams[1].Size() - 2);
		}
		ui_render->SetTexture(ui_tab_gray_boss);
		ui_render->DrawWindow(Core::Rectangle(tx,ty,tx+804,ty+92 + t_boss_mode2_y),Core::Rectangle(15, 15, 15, 15),Core::Rectangle(15.f/96.f, 15.f/52.f, 15.f/96.f, 15.f/52.f));

		ui_render->DrawTextureWindow(Vector2(tx,ty+92 + t_boss_mode2_y),804,172,ui_tab_center_boss);

		ui_render->SetTexture(ui_tab_red_boss);
		ui_render->DrawWindow(Core::Rectangle(tx,ty+92+172 + t_boss_mode2_y,tx+804,ty+92+172+451),Core::Rectangle(15, 15, 15, 15),Core::Rectangle(15.f/96.f, 15.f/52.f, 15.f/96.f, 15.f/52.f));

		ui_render->SetTexture(ui_tab_bottom);
		ui_render->DrawWindow(Core::Rectangle(tx,ty+92+172+451,tx+804,ty+92+172+451+96),Core::Rectangle(15, 15, 15, 15),Core::Rectangle(15.f/60.f, 15.f/44.f, 15.f/60.f, 15.f/44.f));

		ui_render->SetTexture(ig_tab_bg2);
		ui_render->DrawWindow(Core::Rectangle(tx+15,ty+13,tx+15+776,ty+13+33),Core::Rectangle(0, 0, 0, 0),Core::Rectangle(1.f/32.f, 1.f/32.f, 1.f/32.f, 1.f/32.f));
		ui_render->DrawWindow(Core::Rectangle(tx+15,ty+92+172+t_boss_mode2_y,tx+15+776,ty+92+172+33+t_boss_mode2_y),Core::Rectangle(0, 0, 0, 0),Core::Rectangle(1.f/32.f, 1.f/32.f, 1.f/32.f, 1.f/32.f));

		if (havewatch)
		{
			ui_render->SetTexture(ui_tab_watch);
			ui_render->DrawWindow(Core::Rectangle(tx+804,ty,tx+804+178,ty+92+172+451+96),Core::Rectangle(28, 61, 28, 20),Core::Rectangle(28.f/120.f, 61.f/120.f, 28.f/120.f, 20.f/120.f));
			Core::Rectangle rect(tx+804, ty+15, tx+804+178, ty+15+33);
			ui_render->DrawStringShadow(ui_render->font_simhei_16, font_color, ARGB(font_color.a,0,0,0), bg_color, rect, gLang->GetTextW(L"�۲���"), Unit::kAlignCenterMiddle);
			for (int rank = 0; rank < (int)game->scores->teams[2].Size(); rank ++)
			{
				Character * c = game->scores->teams[2][rank];
				if (c)
				{
					//vip

					ServerInfo* pInfo = NULL;
					for (int i = 0; i < gGame->lobby_connection->server_list.GetCount(); ++i)
					{
						if (gGame->lobby_connection->server_list[i].id == gGame->address.server_id)
						{
							pInfo = &gGame->lobby_connection->server_list[i];
							break;
						}
					}

					if (pInfo && pInfo->servertype == SvrType_Match )// SvrType_Match
					{
						LogSystem.WriteLinef("c->basecharacter_info->dan_gradingc->basecharacter_info->dan_grading = %d",c->basecharacter_info->dan_grading);
						if (c->basecharacter_info->dan_grading == 0)
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),90,28,ig_tab_match[0]);
						}
						else if (c->basecharacter_info->dan_grading == 1 )
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),90,28,ig_tab_match[1]);
						}
						else if (c->basecharacter_info->dan_grading == 2 )
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),90,28,ig_tab_match[2]);
						}
						else if (c->basecharacter_info->dan_grading == 3 )
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),90,28,ig_tab_match[3]);
						}
						else if (c->basecharacter_info->dan_grading == 4 )
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),90,28,ig_tab_match[4]);
						}
						else if (c->basecharacter_info->dan_grading == 5 )
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),90,28,ig_tab_match[5]);
						}
						else if (c->basecharacter_info->dan_grading == 6 )
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),90,28,ig_tab_match[6]);
						}
						else if (c->basecharacter_info->dan_grading == 7 )
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),90,28,ig_tab_match[7]);
						}
						else if (c->basecharacter_info->dan_grading == 8 )
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),90,28,ig_tab_match[8]);
						}
						else if (c->basecharacter_info->dan_grading == 9 )
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),90,28,ig_tab_match[9]);
						}
						else if (c->basecharacter_info->dan_grading == 10 )
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),90,28,ig_tab_match[10]);
						}
						else if (c->basecharacter_info->dan_grading == 11 )
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),90,28,ig_tab_match[11]);
						}
						else if (c->basecharacter_info->dan_grading == 12 )
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),90,28,ig_tab_match[12]);
						}
						else if (c->basecharacter_info->dan_grading == 13 )
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),90,28,ig_tab_match[13]);
						}
					}
					else
					{
						if (c->is_vip > 0)
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),40,28,ig_tab_vip[c->is_vip-1]);
						}

					}

					//if (c->is_vip >0)
					//{
					//	ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),40,28,ig_tab_vip[c->is_vip-1]);
					//}
					//else if (c->is_vip == 2)
					//{
					//	ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+33+5+24*rank),24,16,ig_tab_xunleivip);
					//}
					rect = Core::Rectangle(tx+850, ty+15+33+5+24*rank, tx+860+130, ty+15+33+5+24*(rank+1));
					ui_render->DrawStringShadow(ui_render->font_simhei_14, name_color, ARGB(font_color.a,0,0,0), bg_color, rect, PeopleName_cut(c->GetName(),5), Unit::kAlignLeftMiddle);
				}
			}
		}

		//����
		int member_pos = 0;
		for (uint rank = 0; rank < game->scores->teams[viewer->GetTeam()].Size(); rank ++)
		{
			Character * c = game->scores->teams[viewer->GetTeam()][rank];
			if(c==viewer)
			{
				member_pos = rank;
				break;
			}
		}
		member_pos++;

		float cursor_y = ty+13;
		float cursor_x = tx+15;
		for (int team = 0 ; team < 2; ++team)
		{
			if (team == 0)
				cursor_y = ty+13+92+172-13+t_boss_mode2_y;
			else if (team == 1)
				cursor_y = ty+13;
			Core::Rectangle rect(cursor_x, cursor_y, cursor_x+95, cursor_y+33);
			if (team == 0)
				ui_render->DrawStringShadow(ui_render->font_simhei_16, font_color, ARGB(font_color.a,0,0,0), bg_color, rect, gLang->GetTextW(L"����"), Unit::kAlignCenterMiddle);
			else if (team == 1)
				ui_render->DrawStringShadow(ui_render->font_simhei_16, font_color, ARGB(font_color.a,0,0,0), bg_color, rect, "BOSS", Unit::kAlignCenterMiddle);
			rect = Core::Rectangle(cursor_x+95, cursor_y, cursor_x+95+55, cursor_y+33);
			ui_render->DrawStringShadow(ui_render->font_simhei_16, font_color, ARGB(font_color.a,0,0,0), bg_color, rect, "", Unit::kAlignCenterMiddle);
			rect = Core::Rectangle(cursor_x+95+55, cursor_y, cursor_x+95+55+172, cursor_y+33);
			ui_render->DrawStringShadow(ui_render->font_simhei_16, font_color, ARGB(font_color.a,0,0,0), bg_color, rect, gLang->GetTextW(L"���"), Unit::kAlignCenterMiddle);
			rect = Core::Rectangle(cursor_x+95+55+172, cursor_y, cursor_x+95+55+172+78, cursor_y+33);
			ui_render->DrawStringShadow(ui_render->font_simhei_16, font_color, ARGB(font_color.a,0,0,0), bg_color, rect, gLang->GetTextW(L"ְҵ"), Unit::kAlignCenterMiddle);
			rect = Core::Rectangle(cursor_x+95+55+172+78, cursor_y, cursor_x+95+55+172+78+100, cursor_y+33);
			ui_render->DrawStringShadow(ui_render->font_simhei_16, font_color, ARGB(font_color.a,0,0,0), bg_color, rect, gLang->GetTextW(L"����"), Unit::kAlignCenterMiddle);
			rect = Core::Rectangle(cursor_x+95+55+172+78+100, cursor_y, cursor_x+95+55+172+78+100+108, cursor_y+33);
			ui_render->DrawStringShadow(ui_render->font_simhei_16, font_color, ARGB(font_color.a,0,0,0), bg_color, rect, gLang->GetTextW(L"��ɱ/����"), Unit::kAlignCenterMiddle);
			rect = Core::Rectangle(cursor_x+95+55+172+78+100+108, cursor_y, cursor_x+95+55+172+78+100+108+79, cursor_y+33);
			if (team == 0)
				ui_render->DrawStringShadow(ui_render->font_simhei_16, font_color, ARGB(font_color.a,0,0,0), bg_color, rect, gLang->GetTextW(L"����"), Unit::kAlignCenterMiddle);
			else if (team == 1)
				ui_render->DrawStringShadow(ui_render->font_simhei_16, font_color, ARGB(font_color.a,0,0,0), bg_color, rect, "", Unit::kAlignCenterMiddle);
			rect = Core::Rectangle(cursor_x+95+55+172+78+100+108+79, cursor_y, cursor_x+95+55+172+78+100+108+79+89, cursor_y+33);
			ui_render->DrawStringShadow(ui_render->font_simhei_16, font_color, ARGB(font_color.a,0,0,0), bg_color, rect, gLang->GetTextW(L"��ʱ"), Unit::kAlignCenterMiddle);
			CStrBuf<256> str;
			for (uint rank = 0; rank < game->scores->teams[team].Size(); rank ++)
			{
				Character * c = game->scores->teams[team][rank];
				if (c)
				{
					name_color = ARGB(255,255,244,220);
					if (c->IsDied()||c->isghost == true)
						name_color = ARGB(255,128,128,128);
					else if (!c->connected)
						name_color = ARGB(128,255,255,0);
				
					if (c == game->level->GetPlayer())
					{
						ui_render->SetTexture(ig_tab_line);
						ui_render->DrawWindow(Core::Rectangle(cursor_x ,cursor_y+33+24*rank,tx+791,cursor_y+33+24*(rank+1)),Core::Rectangle(4, 4, 4, 4),Core::Rectangle(4.f/24.f, 4.f/24.f, 4.f/24.f, 4.f/24.f));
					}
					Core::Rectangle rect2(cursor_x, cursor_y+33+24*rank, cursor_x+95, cursor_y+33+24*(rank+1));
					str.format("%d", rank + 1);
					ui_render->DrawStringShadow(ui_render->font_simhei_14, name_color, ARGB(font_color.a,0,0,0), bg_color, rect2, str, Unit::kAlignCenterMiddle);

					int card_num = (int)c->business_card;
					if (card_num > 0 && card_num < 18)
					{
						ui_render->SetTexture(ui_common_tab_name_cards[card_num-1]);
						ui_render->DrawWindow(Core::Rectangle(cursor_x,cursor_y+33+24*rank,tx+216,cursor_y+33+24*(rank+1)),
							Core::Rectangle(0, 0, 0, 0),Core::Rectangle(0.f/1.f, 0.f/1.f, 0.f/1.f,0.f/1.f),Core::ARGB(255,255,255,255),Core::ARGB(255,255,255,255));
					}


					ServerInfo* pInfo = NULL;
					for (int i = 0; i < gGame->lobby_connection->server_list.GetCount(); ++i)
					{
						if (gGame->lobby_connection->server_list[i].id == gGame->address.server_id)
						{
							pInfo = &gGame->lobby_connection->server_list[i];
							break;
						}
					}

					if (pInfo && pInfo->servertype == SvrType_Match )// SvrType_Match
					{
						LogSystem.WriteLinef("c->basecharacter_info->dan_gradingc->basecharacter_info->dan_grading = %d",c->basecharacter_info->dan_grading);
						if (c->basecharacter_info->dan_grading == 0)
						{
							ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),90,28,ig_tab_match[0]);
						}
						else if (c->basecharacter_info->dan_grading == 1 )
						{
							ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),90,28,ig_tab_match[1]);
						}
						else if (c->basecharacter_info->dan_grading == 2 )
						{
							ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),90,28,ig_tab_match[2]);
						}
						else if (c->basecharacter_info->dan_grading == 3 )
						{
							ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),90,28,ig_tab_match[3]);
						}
						else if (c->basecharacter_info->dan_grading == 4 )
						{
							ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),90,28,ig_tab_match[4]);
						}
						else if (c->basecharacter_info->dan_grading == 5 )
						{
							ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),90,28,ig_tab_match[5]);
						}
						else if (c->basecharacter_info->dan_grading == 6 )
						{
							ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),90,28,ig_tab_match[6]);
						}
						else if (c->basecharacter_info->dan_grading == 7 )
						{
							ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),90,28,ig_tab_match[7]);
						}
						else if (c->basecharacter_info->dan_grading == 8 )
						{
							ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),90,28,ig_tab_match[8]);
						}
						else if (c->basecharacter_info->dan_grading == 9 )
						{
							ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),90,28,ig_tab_match[9]);
						}
						else if (c->basecharacter_info->dan_grading == 10 )
						{
							ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),90,28,ig_tab_match[10]);
						}
						else if (c->basecharacter_info->dan_grading == 11 )
						{
							ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),90,28,ig_tab_match[11]);
						}
						else if (c->basecharacter_info->dan_grading == 12 )
						{
							ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),90,28,ig_tab_match[12]);
						}
						else if (c->basecharacter_info->dan_grading == 13 )
						{
							ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),90,28,ig_tab_match[13]);
						}
					}
					else
					{
						if (c->is_vip > 0)
						{
							ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),40,28,ig_tab_vip[c->is_vip-1]);
						}

					}

				/*	if (c->is_vip > 0)
					{
						ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),40,28,ig_tab_vip[c->is_vip-1]);
					}*/
					//else if (c->is_vip == 2)
					//{
					//	ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+38+24*rank),24,16,ig_tab_xunleivip);
					//}

					rect2 = Core::Rectangle(cursor_x+95+55, cursor_y+33+24*rank, cursor_x+95+55+172, cursor_y+33+24*(rank+1));
					ui_render->DrawStringShadow(ui_render->font_simhei_14, name_color, ARGB(font_color.a,0,0,0), bg_color, rect2, c->GetName(), Unit::kAlignCenterMiddle);

					rect2 = Core::Rectangle(cursor_x+95+55+172, cursor_y+33+24*rank, cursor_x+95+55+172+78, cursor_y+33+24*(rank+1));
					str.format("%s", gLang->GetTextW(L"δѡ��"));
					if (c->GetCurCharinfo())
					{
						str.format("%s", c->GetCurCharinfo()->career_name.Str());
					}
					ui_render->DrawStringShadow(ui_render->font_simhei_14, name_color, ARGB(font_color.a,0,0,0), bg_color, rect2, str, Unit::kAlignCenterMiddle);

					rect2 = Core::Rectangle(cursor_x+95+55+172+78, cursor_y+33+24*rank, cursor_x+95+55+172+78+100, cursor_y+33+24*(rank+1));
					str.format("%d", (int)c->all_score);
					ui_render->DrawStringShadow(ui_render->font_simhei_14, name_color, ARGB(font_color.a,0,0,0), bg_color, rect2, str, Unit::kAlignCenterMiddle);

					rect2 = Core::Rectangle(cursor_x+95+55+172+78+100, cursor_y+33+24*rank, cursor_x+95+55+172+78+100+108, cursor_y+33+24*(rank+1));
					str.format("%d/%d", c->num_killed, c->num_died);
					ui_render->DrawStringShadow(ui_render->font_simhei_14, name_color, ARGB(font_color.a,0,0,0), bg_color, rect2, str, Unit::kAlignCenterMiddle);

					rect2 = Core::Rectangle(cursor_x+95+55+172+78+100+108, cursor_y+33+24*rank, cursor_x+95+55+172+78+100+108+79, cursor_y+33+24*(rank+1));
					if (!c->is_boss)
					{
						str.format("%d", c->num_assist);
						ui_render->DrawStringShadow(ui_render->font_simhei_14, name_color, ARGB(font_color.a,0,0,0), bg_color, rect2, str, Unit::kAlignCenterMiddle);
					}

					rect2 = Core::Rectangle(cursor_x+95+55+172+78+100+108+79, cursor_y+33+24*rank, cursor_x+95+55+172+78+100+108+79+89, cursor_y+33+24*(rank+1));
					str.format("%d", c->ping);
					ARGB pin_color = name_color;
					if (c->ping > 1500)
					{
						pin_color = ARGB(231, 82, 41);
					}
					ui_render->DrawStringShadow(ui_render->font_simhei_14, pin_color, ARGB(font_color.a,0,0,0), bg_color, rect2, str, Unit::kAlignCenterMiddle);
				}
			}

			{
				tempc_ptr(Texture2D) tex1;
				tempc_ptr(Texture2D) tex2;
				if (gGame->scores->team_round[1] > gGame->scores->team_round[0])
				{
					tex1 = ig_tab_win_num;
					tex2 = ig_tab_lose_num;
				}	
				else if (gGame->scores->team_round[1] == gGame->scores->team_round[0])
				{
					tex1 = ig_tab_lose_num;
					tex2 = ig_tab_lose_num;
				}
				else
				{
					tex1 = ig_tab_lose_num;
					tex2 = ig_tab_win_num;
				}
				_DrawNumberTextureWindow(ui_render, tex1, Core::Vector2(tx+137, ty+127+t_boss_mode2_y), 80, 108, (gGame->scores->team_round[1]%100)/10,0.1f);
				_DrawNumberTextureWindow(ui_render, tex1, Core::Vector2(tx+137+80, ty+127+t_boss_mode2_y), 80, 108, gGame->scores->team_round[1]%10,0.1f);

				_DrawNumberTextureWindow(ui_render, tex2, Core::Vector2(tx+430+80, ty+127+t_boss_mode2_y), 80, 108, (gGame->scores->team_round[0]%100)/10,0.1f);
				_DrawNumberTextureWindow(ui_render, tex2, Core::Vector2(tx+430+160, ty+127+t_boss_mode2_y), 80, 108, gGame->scores->team_round[0]%10,0.1f);
			}
		}

		CStrBuf<256> str;
		name_color = ARGB(214,214,214);
		Core::Rectangle rect3;
		if (gLevel->game_type == RoomOption::kBossMode2)
		{
			str.format(gLang->GetTextW(L"ģʽ : BOSSĩ�ս���"));
		} 
		else
		{
			str.format(gLang->GetTextW(L"ģʽ : BOSSģʽ"));
		}
		rect3 = Core::Rectangle(tx+20,ty+248+172+245+65,tx+50+95,ty+248+172+245+80);
		ui_render->DrawStringShadow(ui_render->font_simhei_14, name_color, ARGB(font_color.a,0,0,0), bg_color, rect3, str, Unit::kAlignLeftMiddle);

		rect3 = Core::Rectangle(tx+50+200,ty+248+172+245+65,tx+50+200+95,ty+248+172+245+80);
		str.format(gLang->GetTextW(L"��ͼ�� : %s"),gLevel->name2);
		ui_render->DrawStringShadow(ui_render->font_simhei_14, name_color, ARGB(font_color.a,0,0,0), bg_color, rect3, str, Unit::kAlignLeftMiddle);

		rect3 = Core::Rectangle(tx+50+400,ty+248+172+245+65,tx+50+95+400,ty+248+172+245+80);

		if (gLevel->GetPlayer()->is_boss)
		{
			str.format(gLang->GetTextW(L"��ϷĿ�� : ������������ %d�غ�ʤ��"), gLevel->rule_value);
		}
		else
		{
			if (gLevel->game_type == RoomOption::kBossMode2)
			{
				str.format(gLang->GetTextW(L"��ϷĿ�� : ����BOSS���� %d�غ�ʤ��"), gLevel->rule_value);
			} 
			else
			{
				str.format(gLang->GetTextW(L"��ϷĿ�� : ����BOSS %d�غ�ʤ��"), gLevel->rule_value);
			}
		}
		ui_render->DrawStringShadow(ui_render->font_simhei_14, name_color, ARGB(font_color.a,0,0,0), bg_color, rect3, str, Unit::kAlignLeftMiddle);

		if(gGame->channel_connection)
		{
			rect3 = Core::Rectangle(tx+20,ty+248+172+245+100,tx+50+95,ty+248+172+245+115);
			str.format(gLang->GetTextW(L"������ : %s"),gLang->GetText(gGame->address.server_name));
			ui_render->DrawStringShadow(ui_render->font_simhei_14, name_color, ARGB(font_color.a,0,0,0), bg_color, rect3, str, Unit::kAlignLeftMiddle);

			rect3 = Core::Rectangle(tx+50+200,ty+248+172+245+100,tx+50+95+200,ty+248+172+245+115);
			str.format(gLang->GetTextW(L"Ƶ�� : %s"),gLang->GetText(gGame->address.channel_name));
			ui_render->DrawStringShadow(ui_render->font_simhei_14, name_color, ARGB(font_color.a,0,0,0), bg_color, rect3, str, Unit::kAlignLeftMiddle);

			rect3 = Core::Rectangle(tx+50+400,ty+248+172+245+100,tx+80+95+400,ty+248+172+245+115);
			if (strcmp(gGame->channel_connection->room_info.option.name, "(null)") > 0)
			{
				str.format(gLang->GetTextW(L"���� : %s"),gGame->channel_connection->room_info.option.name);
				ui_render->DrawStringShadow(ui_render->font_simhei_14, name_color, ARGB(font_color.a,0,0,0), bg_color, rect3, str, Unit::kAlignLeftMiddle);
			}			
		}
	}
}

void InGameUINew::_DrawBossPveTab(by_ptr(UIRender) ui_render)
{
	tempc_ptr(Character) viewer = gLevel->GetViewer();
	Matrix44 world;
	Core::Vector3 rt_size = gGame->guiSys->GetSize();
	Game * game = gGame;

	if (gLevel->game_type == RoomOption::kNovice)
		return;

	// draw tab
	if(!viewer)
	{
		tempc_ptr(Character) player = gLevel->GetPlayer();
		if(player)
			viewer = player;
	}

	if ((show_game_scores || show_scores) && viewer && viewer->GetTeam() <= 2)
	{
		world.SetTranslationXYZ(0, 0, 0);
		ui_render->SetWorld(world);
		ARGB name_color = ARGB(255,244,220);
		ARGB bg_color = ARGB(0,0,0,0);
		ARGB font_color = ARGB(150,215,232,227);

		bool havewatch = false;
		for (uint rank = 0; rank < game->scores->teams[2].Size(); rank ++)
		{
			Character * c = game->scores->teams[2][rank];
			if (c)
			{
				havewatch = true;
			}
		}

		int tx = -388;
		int ty = -364 + 154;
		if (havewatch)
		{
			tx -=(178/2);
		}
		ui_render->SetTexture(ui_tab_BossPVE_bg);
		ui_render->DrawWindow(Core::Rectangle(tx,ty,tx+804,ty+357),Core::Rectangle(15, 15, 15, 15),Core::Rectangle(15.f/96.f, 15.f/52.f, 15.f/96.f, 15.f/52.f));

		ui_render->SetTexture(ui_tab_bottom);
		ui_render->DrawWindow(Core::Rectangle(tx,ty+357,tx+804,ty+357+96),Core::Rectangle(15, 15, 15, 15),Core::Rectangle(15.f/60.f, 15.f/44.f, 15.f/60.f, 15.f/44.f));

		ui_render->SetTexture(ig_tab_bg2);
		ui_render->DrawWindow(Core::Rectangle(tx+15,ty+13,tx+15+776,ty+13+33),Core::Rectangle(0, 0, 0, 0),Core::Rectangle(1.f/32.f, 1.f/32.f, 1.f/32.f, 1.f/32.f));
		if (havewatch)
		{
			ui_render->SetTexture(ui_tab_watch);
			ui_render->DrawWindow(Core::Rectangle(tx+804,ty,tx+804+178,ty+248+172+245+96),Core::Rectangle(28, 61, 28, 20),Core::Rectangle(28.f/120.f, 61.f/120.f, 28.f/120.f, 20.f/120.f));
			Core::Rectangle rect(tx+804, ty+15, tx+804+178, ty+15+33);
			ui_render->DrawStringShadow(ui_render->font_simhei_16, font_color, ARGB(font_color.a,0,0,0), bg_color, rect, gLang->GetTextW(L"�۲���"), Unit::kAlignCenterMiddle);
			for (int rank = 0; rank < (int)game->scores->teams[2].Size(); rank ++)
			{
				Character * c = game->scores->teams[2][rank];
				if (c)
				{
					//vip


					ServerInfo* pInfo = NULL;
					for (int i = 0; i < gGame->lobby_connection->server_list.GetCount(); ++i)
					{
						if (gGame->lobby_connection->server_list[i].id == gGame->address.server_id)
						{
							pInfo = &gGame->lobby_connection->server_list[i];
							break;
						}
					}

					if (pInfo && pInfo->servertype == SvrType_Match )// SvrType_Match
					{
						LogSystem.WriteLinef("c->basecharacter_info->dan_gradingc->basecharacter_info->dan_grading = %d",c->basecharacter_info->dan_grading);
						if (c->basecharacter_info->dan_grading == 0)
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),90,28,ig_tab_match[0]);
						}
						else if (c->basecharacter_info->dan_grading == 1 )
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),90,28,ig_tab_match[1]);
						}
						else if (c->basecharacter_info->dan_grading == 2 )
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),90,28,ig_tab_match[2]);
						}
						else if (c->basecharacter_info->dan_grading == 3 )
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),90,28,ig_tab_match[3]);
						}
						else if (c->basecharacter_info->dan_grading == 4 )
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),90,28,ig_tab_match[4]);
						}
						else if (c->basecharacter_info->dan_grading == 5 )
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),90,28,ig_tab_match[5]);
						}
						else if (c->basecharacter_info->dan_grading == 6 )
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),90,28,ig_tab_match[6]);
						}
						else if (c->basecharacter_info->dan_grading == 7 )
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),90,28,ig_tab_match[7]);
						}
						else if (c->basecharacter_info->dan_grading == 8 )
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),90,28,ig_tab_match[8]);
						}
						else if (c->basecharacter_info->dan_grading == 9 )
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),90,28,ig_tab_match[9]);
						}
						else if (c->basecharacter_info->dan_grading == 10 )
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),90,28,ig_tab_match[10]);
						}
						else if (c->basecharacter_info->dan_grading == 11 )
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),90,28,ig_tab_match[11]);
						}
						else if (c->basecharacter_info->dan_grading == 12 )
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),90,28,ig_tab_match[12]);
						}
						else if (c->basecharacter_info->dan_grading == 13 )
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),90,28,ig_tab_match[13]);
						}
					}
					else
					{
						if (c->is_vip > 0)
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),40,28,ig_tab_vip[c->is_vip-1]);
						}

					}
				/*	if (c->is_vip > 0)
					{
						ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),40,28,ig_tab_vip[c->is_vip-1]);
					}*/
					//else if (c->is_vip == 2)
					//{
					//	ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+33+5+24*rank),24,16,ig_tab_xunleivip);
					//}
					if (c->HasBomb())
					{
						ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),28,28,ui_textures[8]);
					}
					rect = Core::Rectangle(tx+850, ty+15+33+5+24*rank, tx+860+130, ty+15+33+5+24*(rank+1));
					ui_render->DrawStringShadow(ui_render->font_simhei_14, name_color, ARGB(font_color.a,0,0,0), bg_color, rect, PeopleName_cut(c->GetName(),5), Unit::kAlignLeftMiddle);
				}
			}
		}

		//����
		int member_pos = 0;
		for (uint rank = 0; rank < game->scores->teams[viewer->GetTeam()].Size(); rank ++)
		{
			Character * c = game->scores->teams[viewer->GetTeam()][rank];
			if(c==viewer)
			{
				member_pos = rank;
				break;
			}
		}
		member_pos++;

		float cursor_y = ty+13;
		float cursor_x = tx+15;
		for (int team = 0 ; team < 1; ++team)
		{
			Core::Rectangle rect(cursor_x, cursor_y, cursor_x+95, cursor_y+33);
			ui_render->DrawStringShadow(ui_render->font_simhei_16, font_color, ARGB(font_color.a,0,0,0), bg_color, rect, gLang->GetTextW(L"����"), Unit::kAlignCenterMiddle);
			rect = Core::Rectangle(cursor_x+95, cursor_y, cursor_x+95+55, cursor_y+33);
			ui_render->DrawStringShadow(ui_render->font_simhei_16, font_color, ARGB(font_color.a,0,0,0), bg_color, rect, "", Unit::kAlignCenterMiddle);
			rect = Core::Rectangle(cursor_x+95+55, cursor_y, cursor_x+95+55+172, cursor_y+33);
			ui_render->DrawStringShadow(ui_render->font_simhei_16, font_color, ARGB(font_color.a,0,0,0), bg_color, rect, gLang->GetTextW(L"���"), Unit::kAlignCenterMiddle);
			rect = Core::Rectangle(cursor_x+95+55+172, cursor_y, cursor_x+95+55+172+78, cursor_y+33);
			ui_render->DrawStringShadow(ui_render->font_simhei_16, font_color, ARGB(font_color.a,0,0,0), bg_color, rect, gLang->GetTextW(L"ְҵ"), Unit::kAlignCenterMiddle);
			rect = Core::Rectangle(cursor_x+95+55+172+78, cursor_y, cursor_x+95+55+172+78+100, cursor_y+33);
			ui_render->DrawStringShadow(ui_render->font_simhei_16, font_color, ARGB(font_color.a,0,0,0), bg_color, rect, gLang->GetTextW(L"����"), Unit::kAlignCenterMiddle);
			rect = Core::Rectangle(cursor_x+95+55+172+78+100, cursor_y, cursor_x+95+55+172+78+100+108, cursor_y+33);
			ui_render->DrawStringShadow(ui_render->font_simhei_16, font_color, ARGB(font_color.a,0,0,0), bg_color, rect, gLang->GetTextW(L"��ɱ/����"), Unit::kAlignCenterMiddle);
			rect = Core::Rectangle(cursor_x+95+55+172+78+100+108, cursor_y, cursor_x+95+55+172+78+100+108+79, cursor_y+33);
			ui_render->DrawStringShadow(ui_render->font_simhei_16, font_color, ARGB(font_color.a,0,0,0), bg_color, rect, gLang->GetTextW(L"����"), Unit::kAlignCenterMiddle);
			rect = Core::Rectangle(cursor_x+95+55+172+78+100+108+79, cursor_y, cursor_x+95+55+172+78+100+108+79+89, cursor_y+33);
			ui_render->DrawStringShadow(ui_render->font_simhei_16, font_color, ARGB(font_color.a,0,0,0), bg_color, rect, gLang->GetTextW(L"��ʱ"), Unit::kAlignCenterMiddle);
			CStrBuf<256> str;
			for (uint rank = 0; rank < game->scores->teams[team].Size(); rank ++)
			{
				Character * c = game->scores->teams[team][rank];
				if (c)
				{
					name_color = ARGB(255,255,244,220);
					if (c->IsDied()||c->isghost == true)
						name_color = ARGB(255,128,128,128);
					else if (!c->connected)
						name_color = ARGB(128,255,255,0);

					int card_num = (int)c->business_card;
					if (c->is_vip > 0)
					{
						ui_render->SetTexture(ui_common_tab_vip_name_card[c->is_vip]);
						ui_render->DrawWindow(Core::Rectangle(cursor_x ,cursor_y+33+24*rank,tx+216,cursor_y+33+24*(rank+1)),
							Core::Rectangle(4, 4, 4, 4),Core::Rectangle(4.f/24.f, 4.f/24.f, 4.f/24.f, 4.f/24.f),Core::ARGB(255,255,255,255),Core::ARGB(255,255,255,255));
					}
					if (card_num > 0 && card_num < 18)
					{
						ui_render->SetTexture(ui_common_tab_name_cards[card_num-1]);
						ui_render->DrawWindow(Core::Rectangle(cursor_x,cursor_y+33+24*rank,tx+216,cursor_y+33+24*(rank+1)),
							Core::Rectangle(0, 0, 0, 0),Core::Rectangle(0.f/1.f, 0.f/1.f, 0.f/1.f,0.f/1.f),Core::ARGB(255,255,255,255),Core::ARGB(255,255,255,255));
					}
					if (c == game->level->GetPlayer())
					{
						ui_render->SetTexture(ig_tab_line);
						ui_render->DrawWindow(Core::Rectangle(cursor_x ,cursor_y+33+24*rank,tx+791,cursor_y+33+24*(rank+1)),Core::Rectangle(4, 4, 4, 4),Core::Rectangle(4.f/24.f, 4.f/24.f, 4.f/24.f, 4.f/24.f));						
					}
					Core::Rectangle rect2(cursor_x, cursor_y+33+24*rank, cursor_x+95, cursor_y+33+24*(rank+1));
					str.format("%d", rank + 1);
					ui_render->DrawStringShadow(ui_render->font_simhei_14, name_color, ARGB(font_color.a,0,0,0), bg_color, rect2, str, Unit::kAlignCenterMiddle);

					//vip
					ServerInfo* pInfo = NULL;
					for (int i = 0; i < gGame->lobby_connection->server_list.GetCount(); ++i)
					{
						if (gGame->lobby_connection->server_list[i].id == gGame->address.server_id)
						{
							pInfo = &gGame->lobby_connection->server_list[i];
							break;
						}
					}

					if (pInfo && pInfo->servertype == SvrType_Match )// SvrType_Match
					{
						LogSystem.WriteLinef("c->basecharacter_info->dan_gradingc->basecharacter_info->dan_grading = %d",c->basecharacter_info->dan_grading);
						if (c->basecharacter_info->dan_grading == 0)
						{
							ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),90,28,ig_tab_match[0]);
						}
						else if (c->basecharacter_info->dan_grading == 1 )
						{
							ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),90,28,ig_tab_match[1]);
						}
						else if (c->basecharacter_info->dan_grading == 2 )
						{
							ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),90,28,ig_tab_match[2]);
						}
						else if (c->basecharacter_info->dan_grading == 3 )
						{
							ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),90,28,ig_tab_match[3]);
						}
						else if (c->basecharacter_info->dan_grading == 4 )
						{
							ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),90,28,ig_tab_match[4]);
						}
						else if (c->basecharacter_info->dan_grading == 5 )
						{
							ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),90,28,ig_tab_match[5]);
						}
						else if (c->basecharacter_info->dan_grading == 6 )
						{
							ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),90,28,ig_tab_match[6]);
						}
						else if (c->basecharacter_info->dan_grading == 7 )
						{
							ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),90,28,ig_tab_match[7]);
						}
						else if (c->basecharacter_info->dan_grading == 8 )
						{
							ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),90,28,ig_tab_match[8]);
						}
						else if (c->basecharacter_info->dan_grading == 9 )
						{
							ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),90,28,ig_tab_match[9]);
						}
						else if (c->basecharacter_info->dan_grading == 10 )
						{
							ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),90,28,ig_tab_match[10]);
						}
						else if (c->basecharacter_info->dan_grading == 11 )
						{
							ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),90,28,ig_tab_match[11]);
						}
						else if (c->basecharacter_info->dan_grading == 12 )
						{
							ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),90,28,ig_tab_match[12]);
						}
						else if (c->basecharacter_info->dan_grading == 13 )
						{
							ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),90,28,ig_tab_match[13]);
						}
					}
					else
					{
						if (c->is_vip > 0)
						{
							ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),40,28,ig_tab_vip[c->is_vip-1]);
						}

					}
					/*if (c->is_vip > 0)
					{
						ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),40,28,ig_tab_vip[c->is_vip-1]);
					}*/
					//else if (c->is_vip == 2)
					//{
					//	ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+38+24*rank),24,16,ig_tab_xunleivip);
					//}
					if (c->HasBomb())
					{
						ui_render->DrawTextureWindow(Vector2(cursor_x+95+40,cursor_y+31+24*rank),28,28,ui_textures[8]);
					}

					rect2 = Core::Rectangle(cursor_x+95+55, cursor_y+33+24*rank, cursor_x+95+55+172, cursor_y+33+24*(rank+1));
					ui_render->DrawStringShadow(ui_render->font_simhei_14, name_color, ARGB(font_color.a,0,0,0), bg_color, rect2, c->GetName(), Unit::kAlignCenterMiddle);

					rect2 = Core::Rectangle(cursor_x+95+55+172, cursor_y+33+24*rank, cursor_x+95+55+172+78, cursor_y+33+24*(rank+1));
					str.format("%s", gLang->GetTextW(L"δѡ��"));
					if (c->GetCurCharinfo())
					{
						str.format("%s", c->GetCurCharinfo()->career_name.Str());
					}
					ui_render->DrawStringShadow(ui_render->font_simhei_14, name_color, ARGB(font_color.a,0,0,0), bg_color, rect2, str, Unit::kAlignCenterMiddle);

					rect2 = Core::Rectangle(cursor_x+95+55+172+78, cursor_y+33+24*rank, cursor_x+95+55+172+78+100, cursor_y+33+24*(rank+1));
					str.format("%d", (int)c->all_score);
					ui_render->DrawStringShadow(ui_render->font_simhei_14, name_color, ARGB(font_color.a,0,0,0), bg_color, rect2, str, Unit::kAlignCenterMiddle);

					rect2 = Core::Rectangle(cursor_x+95+55+172+78+100, cursor_y+33+24*rank, cursor_x+95+55+172+78+100+108, cursor_y+33+24*(rank+1));
					str.format("%d/%d", c->num_killed, c->num_died);
					ui_render->DrawStringShadow(ui_render->font_simhei_14, name_color, ARGB(font_color.a,0,0,0), bg_color, rect2, str, Unit::kAlignCenterMiddle);

					rect2 = Core::Rectangle(cursor_x+95+55+172+78+100+108, cursor_y+33+24*rank, cursor_x+95+55+172+78+100+108+79, cursor_y+33+24*(rank+1));
					str.format("%d", c->num_assist);
					ui_render->DrawStringShadow(ui_render->font_simhei_14, name_color, ARGB(font_color.a,0,0,0), bg_color, rect2, str, Unit::kAlignCenterMiddle);

					rect2 = Core::Rectangle(cursor_x+95+55+172+78+100+108+79, cursor_y+33+24*rank, cursor_x+95+55+172+78+100+108+79+89, cursor_y+33+24*(rank+1));
					str.format("%d", c->ping);
					ARGB pin_color = name_color;
					if (c->ping > 1500)
					{
						pin_color = ARGB(231, 82, 41);
					}
					ui_render->DrawStringShadow(ui_render->font_simhei_14, pin_color, ARGB(font_color.a,0,0,0), bg_color, rect2, str, Unit::kAlignCenterMiddle);
				}
			}
		}

		CStrBuf<256> str;
		name_color = ARGB(214,214,214);
		Core::Rectangle rect3;
		str.format(gLang->GetTextW(L"ģʽ : ����ģʽ"));

		rect3 = Core::Rectangle(tx+20,ty+357+15,tx+50+95,ty+357+30);
		ui_render->DrawStringShadow(ui_render->font_simhei_14, name_color, ARGB(font_color.a,0,0,0), bg_color, rect3, str, Unit::kAlignLeftMiddle);

		rect3 = Core::Rectangle(tx+50+200,ty+357+15,tx+50+200+95,ty+357+30);
		str.format(gLang->GetTextW(L"��ͼ�� : %s"),gLevel->name2);
		ui_render->DrawStringShadow(ui_render->font_simhei_14, name_color, ARGB(font_color.a,0,0,0), bg_color, rect3, str, Unit::kAlignLeftMiddle);

		rect3 = Core::Rectangle(tx+50+400,ty+357+15,tx+50+95+400,ty+357+30);
		str.format(gLang->GetTextW(L"��ϷĿ�� : �������г���ս������ȡʤ��"));

		ui_render->DrawStringShadow(ui_render->font_simhei_14, name_color, ARGB(font_color.a,255, 195, 1), bg_color, rect3, str, Unit::kAlignLeftMiddle);

		if(gGame->channel_connection && gGame->channel_connection->GetState() != ChannelConnection::kInReplay)
		{
			rect3 = Core::Rectangle(tx+20,ty+357+50,tx+50+95,ty+357+65);
			str.format(gLang->GetTextW(L"������ : %s"),gLang->GetText(gGame->address.server_name));
			ui_render->DrawStringShadow(ui_render->font_simhei_14, name_color, ARGB(font_color.a,0,0,0), bg_color, rect3, str, Unit::kAlignLeftMiddle);

			rect3 = Core::Rectangle(tx+50+200,ty+357+50,tx+50+95+200,ty+357+65);
			str.format(gLang->GetTextW(L"Ƶ�� : %s"),gLang->GetText(gGame->address.channel_name));
			ui_render->DrawStringShadow(ui_render->font_simhei_14, name_color, ARGB(font_color.a,0,0,0), bg_color, rect3, str, Unit::kAlignLeftMiddle);

			rect3 = Core::Rectangle(tx+50+400,ty+357+50,tx+50+95+400,ty+357+65);
			if (gGame->channel_connection->room_info.option.name)
			{
				str.format(gLang->GetTextW(L"���� : %s"),gGame->channel_connection->room_info.option.name);
				ui_render->DrawStringShadow(ui_render->font_simhei_14, name_color, ARGB(font_color.a,0,0,0), bg_color, rect3, str, Unit::kAlignLeftMiddle);
			}

		}
		win_time = 0;
	}
}
void InGameUINew::_DrawCommonZombieTab(by_ptr(UIRender) ui_render)
{
	tempc_ptr(Character) viewer = gLevel->GetViewer();
	Matrix44 world;
	Core::Vector3 rt_size = gGame->guiSys->GetSize();
	Game * game = gGame;

	if (gLevel->game_type == RoomOption::kNovice)
		return;

	// draw tab
	if(!viewer)
	{
		tempc_ptr(Character) player = gLevel->GetPlayer();
		if(player)
			viewer = player;
	}

	if ((show_game_scores || show_scores) && viewer && viewer->GetTeam() <= 2)
	{
		world.SetTranslationXYZ(0, 0, 0);
		ui_render->SetWorld(world);
		ARGB name_color = ARGB(255,244,220);
		ARGB bg_color = ARGB(0,0,0,0);
		ARGB font_color = ARGB(150,215,232,227);

		bool havewatch = false;
		for (uint rank = 0; rank < game->scores->teams[2].Size(); rank ++)
		{
			Character * c = game->scores->teams[2][rank];
			if (c)
			{
				havewatch = true;
			}
		}

		int tx = -388;
		int ty = -364 + 154 -43;
		if (havewatch)
		{
			tx -=(178/2);
		}
		ui_render->SetTexture(ui_tab_BossPVE_bg);
		ui_render->DrawWindow(Core::Rectangle(tx,ty,tx+804,ty+444),Core::Rectangle(15, 15, 15, 15),Core::Rectangle(15.f/96.f, 15.f/52.f, 15.f/96.f, 15.f/52.f));

		ui_render->SetTexture(ui_tab_bottom);
		ui_render->DrawWindow(Core::Rectangle(tx,ty+444,tx+804,ty+444+96),Core::Rectangle(15, 15, 15, 15),Core::Rectangle(15.f/60.f, 15.f/44.f, 15.f/60.f, 15.f/44.f));

		ui_render->SetTexture(ig_tab_bg2);
		ui_render->DrawWindow(Core::Rectangle(tx+15,ty+13,tx+15+776,ty+13+33),Core::Rectangle(0, 0, 0, 0),Core::Rectangle(1.f/32.f, 1.f/32.f, 1.f/32.f, 1.f/32.f));
		if (havewatch)
		{
			ui_render->SetTexture(ui_tab_watch);
			ui_render->DrawWindow(Core::Rectangle(tx+804,ty,tx+804+178,ty+248+172+245+96),Core::Rectangle(28, 61, 28, 20),Core::Rectangle(28.f/120.f, 61.f/120.f, 28.f/120.f, 20.f/120.f));
			Core::Rectangle rect(tx+804, ty+15, tx+804+178, ty+15+33);
			ui_render->DrawStringShadow(ui_render->font_simhei_16, font_color, ARGB(font_color.a,0,0,0), bg_color, rect, gLang->GetTextW(L"�۲���"), Unit::kAlignCenterMiddle);
			for (int rank = 0; rank < (int)game->scores->teams[2].Size(); rank ++)
			{
				Character * c = game->scores->teams[2][rank];
				if (c)
				{
					//vip
					ServerInfo* pInfo = NULL;
					for (int i = 0; i < gGame->lobby_connection->server_list.GetCount(); ++i)
					{
						if (gGame->lobby_connection->server_list[i].id == gGame->address.server_id)
						{
							pInfo = &gGame->lobby_connection->server_list[i];
							break;
						}
					}

					if (pInfo && pInfo->servertype == SvrType_Match )// SvrType_Match
					{
						LogSystem.WriteLinef("c->basecharacter_info->dan_gradingc->basecharacter_info->dan_grading = %d",c->basecharacter_info->dan_grading);
						if (c->basecharacter_info->dan_grading == 0)
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),90,28,ig_tab_match[0]);
						}
						else if (c->basecharacter_info->dan_grading == 1 )
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),90,28,ig_tab_match[1]);
						}
						else if (c->basecharacter_info->dan_grading == 2 )
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),90,28,ig_tab_match[2]);
						}
						else if (c->basecharacter_info->dan_grading == 3 )
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),90,28,ig_tab_match[3]);
						}
						else if (c->basecharacter_info->dan_grading == 4 )
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),90,28,ig_tab_match[4]);
						}
						else if (c->basecharacter_info->dan_grading == 5 )
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),90,28,ig_tab_match[5]);
						}
						else if (c->basecharacter_info->dan_grading == 6 )
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),90,28,ig_tab_match[6]);
						}
						else if (c->basecharacter_info->dan_grading == 7 )
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),90,28,ig_tab_match[7]);
						}
						else if (c->basecharacter_info->dan_grading == 8 )
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),90,28,ig_tab_match[8]);
						}
						else if (c->basecharacter_info->dan_grading == 9 )
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),90,28,ig_tab_match[9]);
						}
						else if (c->basecharacter_info->dan_grading == 10 )
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),90,28,ig_tab_match[10]);
						}
						else if (c->basecharacter_info->dan_grading == 11 )
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),90,28,ig_tab_match[11]);
						}
						else if (c->basecharacter_info->dan_grading == 12 )
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),90,28,ig_tab_match[12]);
						}
						else if (c->basecharacter_info->dan_grading == 13 )
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),90,28,ig_tab_match[13]);
						}
					}
					else
					{
						if (c->is_vip > 0)
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),40,28,ig_tab_vip[c->is_vip-1]);
						}

					}
				/*	if (c->is_vip > 0)
					{
						ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),40,28,ig_tab_vip[c->is_vip-1]);
					}*/
					//else if (c->is_vip == 2)
					//{
					//	ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+33+5+24*rank),24,16,ig_tab_xunleivip);
					//}
					if (c->HasBomb())
					{
						ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),28,28,ui_textures[8]);
					}
					rect = Core::Rectangle(tx+850, ty+15+33+5+24*rank, tx+860+130, ty+15+33+5+24*(rank+1));
					ui_render->DrawStringShadow(ui_render->font_simhei_14, name_color, ARGB(font_color.a,0,0,0), bg_color, rect, PeopleName_cut(c->GetName(),5), Unit::kAlignLeftMiddle);
				}
			}
		}

		//����
		int member_pos = 0;
		for (uint rank = 0; rank < game->scores->teams[viewer->GetTeam()].Size(); rank ++)
		{
			Character * c = game->scores->teams[viewer->GetTeam()][rank];
			if(c==viewer)
			{
				member_pos = rank;
				break;
			}
		}
		member_pos++;

		float cursor_y = ty+13;
		float cursor_x = tx+15;
		int   People_num = 0;
		Core::Rectangle rect(cursor_x, cursor_y, cursor_x+95, cursor_y+33);
		ui_render->DrawStringShadow(ui_render->font_simhei_16, font_color, ARGB(font_color.a,0,0,0), bg_color, rect, gLang->GetTextW(L"����"), Unit::kAlignCenterMiddle);
		rect = Core::Rectangle(cursor_x+95, cursor_y, cursor_x+95+55, cursor_y+33);
		ui_render->DrawStringShadow(ui_render->font_simhei_16, font_color, ARGB(font_color.a,0,0,0), bg_color, rect, "", Unit::kAlignCenterMiddle);
		rect = Core::Rectangle(cursor_x+95+55, cursor_y, cursor_x+95+55+172, cursor_y+33);
		ui_render->DrawStringShadow(ui_render->font_simhei_16, font_color, ARGB(font_color.a,0,0,0), bg_color, rect, gLang->GetTextW(L"���"), Unit::kAlignCenterMiddle);
		rect = Core::Rectangle(cursor_x+95+55+172, cursor_y, cursor_x+95+55+172+78, cursor_y+33);
		ui_render->DrawStringShadow(ui_render->font_simhei_16, font_color, ARGB(font_color.a,0,0,0), bg_color, rect, gLang->GetTextW(L"ְҵ"), Unit::kAlignCenterMiddle);
		rect = Core::Rectangle(cursor_x+95+55+172+78, cursor_y, cursor_x+95+55+172+78+100, cursor_y+33);
		ui_render->DrawStringShadow(ui_render->font_simhei_16, font_color, ARGB(font_color.a,0,0,0), bg_color, rect, gLang->GetTextW(L"����"), Unit::kAlignCenterMiddle);
		rect = Core::Rectangle(cursor_x+95+55+172+78+100, cursor_y, cursor_x+95+55+172+78+100+108, cursor_y+33);
		ui_render->DrawStringShadow(ui_render->font_simhei_16, font_color, ARGB(font_color.a,0,0,0), bg_color, rect, gLang->GetTextW(L"��ɱ/����"), Unit::kAlignCenterMiddle);
		rect = Core::Rectangle(cursor_x+95+55+172+78+100+108, cursor_y, cursor_x+95+55+172+78+100+108+79, cursor_y+33);
		ui_render->DrawStringShadow(ui_render->font_simhei_16, font_color, ARGB(font_color.a,0,0,0), bg_color, rect, gLang->GetTextW(L"����"), Unit::kAlignCenterMiddle);
		rect = Core::Rectangle(cursor_x+95+55+172+78+100+108+79, cursor_y, cursor_x+95+55+172+78+100+108+79+89, cursor_y+33);
		ui_render->DrawStringShadow(ui_render->font_simhei_16, font_color, ARGB(font_color.a,0,0,0), bg_color, rect, gLang->GetTextW(L"��ʱ"), Unit::kAlignCenterMiddle);
		for (int team = 1 ; team >= 0; team--)
		{
			Core::Rectangle rect(cursor_x, cursor_y, cursor_x+95, cursor_y+33);
			CStrBuf<256> str;
			for (uint rank = 0; rank < game->scores->teams[team].Size(); rank ++)
			{
				Character * c = game->scores->teams[team][rank];
				if (c)
				{
					int Tep_int = rank;
					rank = People_num;
					name_color = ARGB(255,255,244,220);
					if (c->IsDied()||c->isghost == true)
						name_color = ARGB(255,128,128,128);
					else if (!c->connected)
					{
						name_color = ARGB(128,255,255,0);
					}

					Core::Rectangle rect2(cursor_x+95+55+172+78+100+108+79, cursor_y+33+24*rank, cursor_x+95+55+172+78+100+108+79+89, cursor_y+33+24*(rank+1));
					str.format("%d", c->ping);
					ARGB pin_color = name_color;
					if (c->ping > 1500)
					{
						pin_color = ARGB(231, 82, 41);
					}
					else
						ui_render->DrawStringShadow(ui_render->font_simhei_14, pin_color, ARGB(font_color.a,0,0,0), bg_color, rect2, str, Unit::kAlignCenterMiddle);

					rect2 = Core::Rectangle(cursor_x, cursor_y+33+24*rank, cursor_x+95, cursor_y+33+24*(rank+1));
					str.format("%d", rank + 1);
					ui_render->DrawStringShadow(ui_render->font_simhei_14, name_color, ARGB(font_color.a,0,0,0), bg_color, rect2, str, Unit::kAlignCenterMiddle);

					if (team == 1 && !c->IsDied())
						name_color = ARGB(128,0,233,110);
					int card_num = (int)c->business_card;
					if (c->is_vip > 0)
					{
						ui_render->SetTexture(ui_common_tab_vip_name_card[c->is_vip]);
						ui_render->DrawWindow(Core::Rectangle(cursor_x ,cursor_y+33+24*rank,tx+216,cursor_y+33+24*(rank+1)),
							Core::Rectangle(4, 4, 4, 4),Core::Rectangle(4.f/24.f, 4.f/24.f, 4.f/24.f, 4.f/24.f),Core::ARGB(255,255,255,255),Core::ARGB(255,255,255,255));
					}
					if (card_num > 0 && card_num < 18)
					{
						ui_render->SetTexture(ui_common_tab_name_cards[card_num-1]);
						ui_render->DrawWindow(Core::Rectangle(cursor_x,cursor_y+33+24*rank,tx+216,cursor_y+33+24*(rank+1)),
							Core::Rectangle(0, 0, 0, 0),Core::Rectangle(0.f/1.f, 0.f/1.f, 0.f/1.f,0.f/1.f),Core::ARGB(255,255,255,255),Core::ARGB(255,255,255,255));
					}
					if (c == game->level->GetPlayer())
					{
						ui_render->SetTexture(ig_tab_line);
						ui_render->DrawWindow(Core::Rectangle(cursor_x ,cursor_y+33+24*rank,tx+791,cursor_y+33+24*(rank+1)),Core::Rectangle(4, 4, 4, 4),Core::Rectangle(4.f/24.f, 4.f/24.f, 4.f/24.f, 4.f/24.f));						
					}

					//vip
					ServerInfo* pInfo = NULL;
					for (int i = 0; i < gGame->lobby_connection->server_list.GetCount(); ++i)
					{
						if (gGame->lobby_connection->server_list[i].id == gGame->address.server_id)
						{
							pInfo = &gGame->lobby_connection->server_list[i];
							break;
						}
					}

					if (pInfo && pInfo->servertype == SvrType_Match )// SvrType_Match
					{
						LogSystem.WriteLinef("c->basecharacter_info->dan_gradingc->basecharacter_info->dan_grading = %d",c->basecharacter_info->dan_grading);
						if (c->basecharacter_info->dan_grading == 0)
						{
							ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),90,28,ig_tab_match[0]);
						}
						else if (c->basecharacter_info->dan_grading == 1 )
						{
							ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),90,28,ig_tab_match[1]);
						}
						else if (c->basecharacter_info->dan_grading == 2 )
						{
							ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),90,28,ig_tab_match[2]);
						}
						else if (c->basecharacter_info->dan_grading == 3 )
						{
							ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),90,28,ig_tab_match[3]);
						}
						else if (c->basecharacter_info->dan_grading == 4 )
						{
							ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),90,28,ig_tab_match[4]);
						}
						else if (c->basecharacter_info->dan_grading == 5 )
						{
							ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),90,28,ig_tab_match[5]);
						}
						else if (c->basecharacter_info->dan_grading == 6 )
						{
							ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),90,28,ig_tab_match[6]);
						}
						else if (c->basecharacter_info->dan_grading == 7 )
						{
							ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),90,28,ig_tab_match[7]);
						}
						else if (c->basecharacter_info->dan_grading == 8 )
						{
							ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),90,28,ig_tab_match[8]);
						}
						else if (c->basecharacter_info->dan_grading == 9 )
						{
							ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),90,28,ig_tab_match[9]);
						}
						else if (c->basecharacter_info->dan_grading == 10 )
						{
							ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),90,28,ig_tab_match[10]);
						}
						else if (c->basecharacter_info->dan_grading == 11 )
						{
							ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),90,28,ig_tab_match[11]);
						}
						else if (c->basecharacter_info->dan_grading == 12 )
						{
							ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),90,28,ig_tab_match[12]);
						}
						else if (c->basecharacter_info->dan_grading == 13 )
						{
							ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),90,28,ig_tab_match[13]);
						}
					}
					else
					{
						if (c->is_vip > 0)
						{
							ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),40,28,ig_tab_vip[c->is_vip-1]);
						}

					}


				/*	if (c->is_vip > 0)
					{
						ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),40,28,ig_tab_vip[c->is_vip-1]);
					}*/
					//else if (c->is_vip == 2)
					//{
					//	ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+38+24*rank),24,16,ig_tab_xunleivip);
					//}
					if (c->HasBomb())
					{
						ui_render->DrawTextureWindow(Vector2(cursor_x+95+40,cursor_y+31+24*rank),28,28,ui_textures[8]);
					}

					rect2 = Core::Rectangle(cursor_x+95+55, cursor_y+33+24*rank, cursor_x+95+55+172, cursor_y+33+24*(rank+1));
					ui_render->DrawStringShadow(ui_render->font_simhei_14, name_color, ARGB(font_color.a,0,0,0), bg_color, rect2, c->GetName(), Unit::kAlignCenterMiddle);

					rect2 = Core::Rectangle(cursor_x+95+55+172, cursor_y+33+24*rank, cursor_x+95+55+172+78, cursor_y+33+24*(rank+1));
					str.format("%s", gLang->GetTextW(L"δѡ��"));
					if (c->GetCurCharinfo())
					{
						str.format("%s", c->GetCurCharinfo()->career_name.Str());
					}
					ui_render->DrawStringShadow(ui_render->font_simhei_14, name_color, ARGB(font_color.a,0,0,0), bg_color, rect2, str, Unit::kAlignCenterMiddle);

					rect2 = Core::Rectangle(cursor_x+95+55+172+78, cursor_y+33+24*rank, cursor_x+95+55+172+78+100, cursor_y+33+24*(rank+1));
					str.format("%d", (int)c->all_score);
					ui_render->DrawStringShadow(ui_render->font_simhei_14, name_color, ARGB(font_color.a,0,0,0), bg_color, rect2, str, Unit::kAlignCenterMiddle);

					rect2 = Core::Rectangle(cursor_x+95+55+172+78+100, cursor_y+33+24*rank, cursor_x+95+55+172+78+100+108, cursor_y+33+24*(rank+1));
					str.format("%d/%d", c->num_killed, c->num_died);
					ui_render->DrawStringShadow(ui_render->font_simhei_14, name_color, ARGB(font_color.a,0,0,0), bg_color, rect2, str, Unit::kAlignCenterMiddle);

					rect2 = Core::Rectangle(cursor_x+95+55+172+78+100+108, cursor_y+33+24*rank, cursor_x+95+55+172+78+100+108+79, cursor_y+33+24*(rank+1));
					str.format("%d", c->num_assist);
					ui_render->DrawStringShadow(ui_render->font_simhei_14, name_color, ARGB(font_color.a,0,0,0), bg_color, rect2, str, Unit::kAlignCenterMiddle);
					People_num++;
					rank = Tep_int;
				}
			}
		}

		ty += 87;
		CStrBuf<256> str;
		name_color = ARGB(214,214,214);
		Core::Rectangle rect3;
		str.format(gLang->GetTextW(L"ģʽ : ������Ⱦģʽ"));

		rect3 = Core::Rectangle(tx+20,ty+357+15,tx+50+95,ty+357+30);
		ui_render->DrawStringShadow(ui_render->font_simhei_14, name_color, ARGB(font_color.a,0,0,0), bg_color, rect3, str, Unit::kAlignLeftMiddle);

		rect3 = Core::Rectangle(tx+50+200,ty+357+15,tx+50+200+95,ty+357+30);
		str.format(gLang->GetTextW(L"��ͼ�� : %s"),gLevel->name2);
		ui_render->DrawStringShadow(ui_render->font_simhei_14, name_color, ARGB(font_color.a,0,0,0), bg_color, rect3, str, Unit::kAlignLeftMiddle);

		rect3 = Core::Rectangle(tx+50+400,ty+357+15,tx+50+95+400,ty+357+30);
		str.format(gLang->GetTextW(L"��ϷĿ�� : ��������Ⱦģʽ������%d�غ�"),gLevel->rule_value);

		ui_render->DrawStringShadow(ui_render->font_simhei_14, name_color, ARGB(font_color.a,255, 195, 1), bg_color, rect3, str, Unit::kAlignLeftMiddle);

		if(gGame->channel_connection && gGame->channel_connection->GetState() != ChannelConnection::kInReplay)
		{
			rect3 = Core::Rectangle(tx+20,ty+357+50,tx+50+95,ty+357+65);
			str.format(gLang->GetTextW(L"������ : %s"),gLang->GetText(gGame->address.server_name));
			ui_render->DrawStringShadow(ui_render->font_simhei_14, name_color, ARGB(font_color.a,0,0,0), bg_color, rect3, str, Unit::kAlignLeftMiddle);

			rect3 = Core::Rectangle(tx+50+200,ty+357+50,tx+50+95+200,ty+357+65);
			str.format(gLang->GetTextW(L"Ƶ�� : %s"),gLang->GetText(gGame->address.channel_name));
			ui_render->DrawStringShadow(ui_render->font_simhei_14, name_color, ARGB(font_color.a,0,0,0), bg_color, rect3, str, Unit::kAlignLeftMiddle);

			rect3 = Core::Rectangle(tx+50+400,ty+357+50,tx+50+95+400,ty+357+65);
			if (gGame->channel_connection->room_info.option.name)
			{
				str.format(gLang->GetTextW(L"���� : %s"),gGame->channel_connection->room_info.option.name);
				ui_render->DrawStringShadow(ui_render->font_simhei_14, name_color, ARGB(font_color.a,0,0,0), bg_color, rect3, str, Unit::kAlignLeftMiddle);
			}

		}
		if (show_game_scores)
		{
			//Matrix44 view, oldview, oldworld;
			//oldworld = world;

			//float scale = 1;
			//win_time += Core::Task::GetFrameTime();
			//win_anim.scale_spline.Interpolation(win_time, scale);

			//world.ScaleXYZ(scale, scale, 1);
			//world.Translate(Vector3(0, 0, 0));
			//int win_x = 0;
			//if (win_team == 0)
			//{
			//	win_x = havewatch ? -509 : -420;
			//	world.TranslateXYZ(win_x, -30, 0);
			//}
			//else if (win_team == 1)
			//{
			//	win_x = havewatch ? 231: 320;
			//	world.TranslateXYZ(win_x, -20, 0);
			//}
			//else
			//	return;
			//ui_render->SetWorld(world);

			//ui_render->DrawTextureWindow(Core::Vector2(-50, -100), 220, 212, ui_win, Core::Rectangle(0,0,1,1),Core::ARGB(255,255,255,255));

			//ui_render->SetView(oldview);
			//ui_render->SetWorld(oldworld);
		}
		else
		{
			win_time = 0;
		}
	}
}
void InGameUINew::_DrawTab(by_ptr(UIRender) ui_render)
{
	tempc_ptr(Character) viewer = gLevel->GetViewer();
	Matrix44 world;
	Core::Vector3 rt_size = gGame->guiSys->GetSize();
	Game * game = gGame;

	if (gLevel->game_type == RoomOption::kNovice)
		return;

	bool isTDmode = gLevel->game_type == RoomOption::kTDMode;

	// draw tab
	if(!viewer)
	{
		tempc_ptr(Character) player = gLevel->GetPlayer();
		if(player)
			viewer = player;
	}

	if ((show_game_scores || show_scores) && viewer && viewer->GetTeam() <= 2)
	{
		world.SetTranslationXYZ(0, 0, 0);
		ui_render->SetWorld(world);
		ARGB name_color = ARGB(255,244,220);
		ARGB bg_color = ARGB(0,0,0,0);
		ARGB font_color = ARGB(150,215,232,227);

		bool havewatch = false;
		for (uint rank = 0; rank < game->scores->teams[2].Size(); rank ++)
		{
			Character * c = game->scores->teams[2][rank];
			if (c)
			{
				havewatch = true;
			}
		}

		int tx = -388;
		int ty = -364;
		if (havewatch)
		{
			tx -=(178/2);
		}
		ui_render->SetTexture(ui_tab_red);
		ui_render->DrawWindow(Core::Rectangle(tx,ty,tx+804,ty+248),Core::Rectangle(15, 15, 15, 15),Core::Rectangle(15.f/96.f, 15.f/52.f, 15.f/96.f, 15.f/52.f));

		ui_render->DrawTextureWindow(Vector2(tx,ty+248),804,172,ui_tab_center);

		ui_render->SetTexture(ui_tab_blue);
		ui_render->DrawWindow(Core::Rectangle(tx,ty+248+172,tx+804,ty+248+172+245),Core::Rectangle(15, 15, 15, 15),Core::Rectangle(15.f/96.f, 15.f/52.f, 15.f/96.f, 15.f/52.f));

		ui_render->SetTexture(ui_tab_bottom);
		ui_render->DrawWindow(Core::Rectangle(tx,ty+248+172+245,tx+804,ty+248+172+245+96),Core::Rectangle(15, 15, 15, 15),Core::Rectangle(15.f/60.f, 15.f/44.f, 15.f/60.f, 15.f/44.f));

		ui_render->SetTexture(ig_tab_bg2);
		ui_render->DrawWindow(Core::Rectangle(tx+15,ty+13,tx+15+776,ty+13+33),Core::Rectangle(0, 0, 0, 0),Core::Rectangle(1.f/32.f, 1.f/32.f, 1.f/32.f, 1.f/32.f));
		ui_render->DrawWindow(Core::Rectangle(tx+15,ty+248+172,tx+15+776,ty+248+172+33),Core::Rectangle(0, 0, 0, 0),Core::Rectangle(1.f/32.f, 1.f/32.f, 1.f/32.f, 1.f/32.f));
	
		if (havewatch)
		{
			ui_render->SetTexture(ui_tab_watch);
			ui_render->DrawWindow(Core::Rectangle(tx+804,ty,tx+804+178,ty+248+172+245+96),Core::Rectangle(28, 61, 28, 20),Core::Rectangle(28.f/120.f, 61.f/120.f, 28.f/120.f, 20.f/120.f));
			Core::Rectangle rect(tx+804, ty+15, tx+804+178, ty+15+33);
			ui_render->DrawStringShadow(ui_render->font_simhei_16, font_color, ARGB(font_color.a,0,0,0), bg_color, rect, gLang->GetTextW(L"�۲���"), Unit::kAlignCenterMiddle);
			for (int rank = 0; rank < (int)game->scores->teams[2].Size(); rank ++)
			{
				Character * c = game->scores->teams[2][rank];
				if (c)
				{
					//vip
					ServerInfo* pInfo = NULL;
					for (int i = 0; i < gGame->lobby_connection->server_list.GetCount(); ++i)
					{
						if (gGame->lobby_connection->server_list[i].id == gGame->address.server_id)
						{
							pInfo = &gGame->lobby_connection->server_list[i];
							break;
						}
					}

					if (pInfo && pInfo->servertype == SvrType_Match )// SvrType_Match
					{
						LogSystem.WriteLinef("c->basecharacter_info->dan_gradingc->basecharacter_info->dan_grading = %d",c->basecharacter_info->dan_grading);
						if (c->basecharacter_info->dan_grading == 0)
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),90,28,ig_tab_match[0]);
						}
						else if (c->basecharacter_info->dan_grading == 1 )
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),90,28,ig_tab_match[1]);
						}
						else if (c->basecharacter_info->dan_grading == 2 )
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),90,28,ig_tab_match[2]);
						}
						else if (c->basecharacter_info->dan_grading == 3 )
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),90,28,ig_tab_match[3]);
						}
						else if (c->basecharacter_info->dan_grading == 4 )
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),90,28,ig_tab_match[4]);
						}
						else if (c->basecharacter_info->dan_grading == 5 )
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),90,28,ig_tab_match[5]);
						}
						else if (c->basecharacter_info->dan_grading == 6 )
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),90,28,ig_tab_match[6]);
						}
						else if (c->basecharacter_info->dan_grading == 7 )
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),90,28,ig_tab_match[7]);
						}
						else if (c->basecharacter_info->dan_grading == 8 )
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),90,28,ig_tab_match[8]);
						}
						else if (c->basecharacter_info->dan_grading == 9 )
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),90,28,ig_tab_match[9]);
						}
						else if (c->basecharacter_info->dan_grading == 10 )
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),90,28,ig_tab_match[10]);
						}
						else if (c->basecharacter_info->dan_grading == 11 )
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),90,28,ig_tab_match[11]);
						}
						else if (c->basecharacter_info->dan_grading == 12 )
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),90,28,ig_tab_match[12]);
						}
						else if (c->basecharacter_info->dan_grading == 13 )
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),90,28,ig_tab_match[13]);
						}
					}
					else
					{
						if (c->is_vip > 0)
						{
							ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),40,28,ig_tab_vip[c->is_vip-1]);
						}

					}
					/*if (c->is_vip > 0)
					{
						ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),40,28,ig_tab_vip[c->is_vip-1]);
					}*/
					//else if (c->is_vip == 2)
					//{
					//	ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+33+5+24*rank),24,16,ig_tab_xunleivip);
					//}
					if (c->HasBomb())
					{
						ui_render->DrawTextureWindow(Vector2(tx+810,ty+15+31+24*rank),28,28,ui_textures[8]);
					}
					rect = Core::Rectangle(tx+850, ty+15+33+5+24*rank, tx+860+130, ty+15+33+5+24*(rank+1));
					ui_render->DrawStringShadow(ui_render->font_simhei_14, name_color, ARGB(font_color.a,0,0,0), bg_color, rect, PeopleName_cut(c->GetName(),5), Unit::kAlignLeftMiddle);
				}
			}
		}

		//����
		int member_pos = 0;
		for (uint rank = 0; rank < game->scores->teams[viewer->GetTeam()].Size(); rank ++)
		{
			Character * c = game->scores->teams[viewer->GetTeam()][rank];
			if(c==viewer)
			{
				member_pos = rank;
				break;
			}
		}
		member_pos++;

		float cursor_y = ty+13;
 		float cursor_x = tx+15;
		float offset1 = 0;
		float offset2 = 0;
		if (isTDmode)
		{
			offset1 = 100;
			offset2 = 188;
		}
		for (int team = 0 ; team < 2; ++team)
		{
			if (team == 1)
			{
				cursor_y = cursor_y+248+172-13;
			}
			Core::Rectangle rect(cursor_x, cursor_y, cursor_x+95, cursor_y+33);
			ui_render->DrawStringShadow(ui_render->font_simhei_16, font_color, ARGB(font_color.a,0,0,0), bg_color, rect, gLang->GetTextW(L"����"), Unit::kAlignCenterMiddle);
			rect = Core::Rectangle(rect.Max.x, cursor_y, rect.Max.x+55, cursor_y+33);
			ui_render->DrawStringShadow(ui_render->font_simhei_16, font_color, ARGB(font_color.a,0,0,0), bg_color, rect, "", Unit::kAlignCenterMiddle);
			rect = Core::Rectangle(rect.Max.x, cursor_y, rect.Max.x+172+offset1, cursor_y+33);
			ui_render->DrawStringShadow(ui_render->font_simhei_16, font_color, ARGB(font_color.a,0,0,0), bg_color, rect, gLang->GetTextW(L"���"), Unit::kAlignCenterMiddle);
			rect = Core::Rectangle(rect.Max.x, cursor_y, rect.Max.x+78+offset2, cursor_y+33);
			ui_render->DrawStringShadow(ui_render->font_simhei_16, font_color, ARGB(font_color.a,0,0,0), bg_color, rect, gLang->GetTextW(L"ְҵ"), Unit::kAlignCenterMiddle);
			if (!isTDmode) //  [1/13/2014 aijiwei]
			{
				rect = Core::Rectangle(rect.Max.x, cursor_y, rect.Max.x+100, cursor_y+33);
				ui_render->DrawStringShadow(ui_render->font_simhei_16, font_color, ARGB(font_color.a,0,0,0), bg_color, rect, gLang->GetTextW(L"����"), Unit::kAlignCenterMiddle);
				rect = Core::Rectangle(rect.Max.x, cursor_y, rect.Max.x+108, cursor_y+33);
				ui_render->DrawStringShadow(ui_render->font_simhei_16, font_color, ARGB(font_color.a,0,0,0), bg_color, rect, gLang->GetTextW(L"��ɱ/����"), Unit::kAlignCenterMiddle);
				rect = Core::Rectangle(rect.Max.x, cursor_y, rect.Max.x+79, cursor_y+33);
				ui_render->DrawStringShadow(ui_render->font_simhei_16, font_color, ARGB(font_color.a,0,0,0), bg_color, rect, gLang->GetTextW(L"����"), Unit::kAlignCenterMiddle);
			}
			rect = Core::Rectangle(rect.Max.x, cursor_y, rect.Max.x+89, cursor_y+33);
			ui_render->DrawStringShadow(ui_render->font_simhei_16, font_color, ARGB(font_color.a,0,0,0), bg_color, rect, gLang->GetTextW(L"��ʱ"), Unit::kAlignCenterMiddle);
			CStrBuf<256> str;
			for (uint rank = 0; rank < game->scores->teams[team].Size(); rank ++)
			{
				Character * c = game->scores->teams[team][rank];
				if (c)
				{
					name_color = ARGB(255,255,244,220);
					if (c->IsDied()||c->isghost == true)
						name_color = ARGB(255,128,128,128);
					else if (!c->connected)
						name_color = ARGB(128,255,255,0);
					
					int card_num = (int)c->business_card;
					if (c->is_vip > 0)
					{
						ui_render->SetTexture(ui_common_tab_vip_name_card[c->is_vip]);
						ui_render->DrawWindow(Core::Rectangle(cursor_x ,cursor_y+33+24*rank,tx+216,cursor_y+33+24*(rank+1)),
							Core::Rectangle(4, 4, 4, 4),Core::Rectangle(4.f/24.f, 4.f/24.f, 4.f/24.f, 4.f/24.f),Core::ARGB(255,255,255,255),Core::ARGB(255,255,255,255));
					}
					if (card_num > 0 && card_num < 18)
					{
						ui_render->SetTexture(ui_common_tab_name_cards[card_num-1]);
						ui_render->DrawWindow(Core::Rectangle(cursor_x,cursor_y+33+24*rank,tx+216,cursor_y+33+24*(rank+1)),
							Core::Rectangle(0, 0, 0, 0),Core::Rectangle(0.f/1.f, 0.f/1.f, 0.f/1.f,0.f/1.f),Core::ARGB(255,255,255,255),Core::ARGB(255,255,255,255));
					}
					if (c == game->level->GetPlayer())
					{
						ui_render->SetTexture(ig_tab_line);
						ui_render->DrawWindow(Core::Rectangle(cursor_x ,cursor_y+33+24*rank,tx+791,cursor_y+33+24*(rank+1)),Core::Rectangle(4, 4, 4, 4),Core::Rectangle(4.f/24.f, 4.f/24.f, 4.f/24.f, 4.f/24.f));						
					}
					Core::Rectangle rect2(cursor_x, cursor_y+33+24*rank, cursor_x+95, cursor_y+33+24*(rank+1));
					str.format("%d", rank + 1);
					ui_render->DrawStringShadow(ui_render->font_simhei_14, name_color, ARGB(font_color.a,0,0,0), bg_color, rect2, str, Unit::kAlignCenterMiddle);

					//vip
					ServerInfo* pInfo = NULL;
					for (int i = 0; i < gGame->lobby_connection->server_list.GetCount(); ++i)
					{
						if (gGame->lobby_connection->server_list[i].id == gGame->address.server_id)
						{
							pInfo = &gGame->lobby_connection->server_list[i];
							break;
						}
					}

					if (pInfo && pInfo->servertype == SvrType_Match )// SvrType_Match
					{
						LogSystem.WriteLinef("c->basecharacter_info->dan_gradingc->basecharacter_info->dan_grading = %d",c->basecharacter_info->dan_grading);
						if (c->basecharacter_info->dan_grading == 0)
						{
							ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),90,28,ig_tab_match[0]);
						}
						else if (c->basecharacter_info->dan_grading == 1 )
						{
							ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),90,28,ig_tab_match[1]);
						}
						else if (c->basecharacter_info->dan_grading == 2 )
						{
							ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),90,28,ig_tab_match[2]);
						}
						else if (c->basecharacter_info->dan_grading == 3 )
						{
							ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),90,28,ig_tab_match[3]);
						}
						else if (c->basecharacter_info->dan_grading == 4 )
						{
							ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),90,28,ig_tab_match[4]);
						}
						else if (c->basecharacter_info->dan_grading == 5 )
						{
							ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),90,28,ig_tab_match[5]);
						}
						else if (c->basecharacter_info->dan_grading == 6 )
						{
							ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),90,28,ig_tab_match[6]);
						}
						else if (c->basecharacter_info->dan_grading == 7 )
						{
							ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),90,28,ig_tab_match[7]);
						}
						else if (c->basecharacter_info->dan_grading == 8 )
						{
							ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),90,28,ig_tab_match[8]);
						}
						else if (c->basecharacter_info->dan_grading == 9 )
						{
							ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),90,28,ig_tab_match[9]);
						}
						else if (c->basecharacter_info->dan_grading == 10 )
						{
							ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),90,28,ig_tab_match[10]);
						}
						else if (c->basecharacter_info->dan_grading == 11 )
						{
							ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),90,28,ig_tab_match[11]);
						}
						else if (c->basecharacter_info->dan_grading == 12 )
						{
							ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),90,28,ig_tab_match[12]);
						}
						else if (c->basecharacter_info->dan_grading == 13 )
						{
							ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),90,28,ig_tab_match[13]);
						}
					}
					else
					{
						if (c->is_vip > 0)
						{
							ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),40,28,ig_tab_vip[c->is_vip-1]);
						}

					}
					//if (c->is_vip > 0)
					//{
					//	ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+31+24*rank),40,28,ig_tab_vip[c->is_vip-1]);
					//}
					//else if (c->is_vip == 2)
					//{
					//	ui_render->DrawTextureWindow(Vector2(cursor_x+95,cursor_y+38+24*rank),24,16,ig_tab_xunleivip);
					//}
					if (c->HasBomb())
					{
						ui_render->DrawTextureWindow(Vector2(cursor_x+95+40,cursor_y+31+24*rank),28,28,ui_textures[8]);
					}

					//_DrawNumberTextureWindow(ui_render, ig_tab_level, Core::Vector2(cursor_x+95, cursor_y+33+24*rank), 14, 33, (c->character_info->%100)/10,0.1f);
					//_DrawNumberTextureWindow(ui_render, ig_tab_level, Core::Vector2(cursor_x+95+14, cursor_y+33+24*rank), 14, 33, gGame->scores->team_kills[0]%10,0.1f);

					//level
					//rect2 = Core::Rectangle(cursor_x+95, cursor_y+33+24*rank, cursor_x+95+55, cursor_y+33+24*(rank+1));
					//_DrawNumberTextureWindow(ui_render, ig_tab_level, Core::Vector2(cursor_x+95, cursor_y+33+24*rank), 14, 33, (c->character_info->%100)/10,0.1f);
					//_DrawNumberTextureWindow(ui_render, ig_tab_level, Core::Vector2(cursor_x+95+14, cursor_y+33+24*rank), 14, 33, gGame->scores->team_kills[0]%10,0.1f);

					rect2 = Core::Rectangle(cursor_x+95+55, cursor_y+33+24*rank, cursor_x+95+55+172+offset1, cursor_y+33+24*(rank+1));
					ui_render->DrawStringShadow(ui_render->font_simhei_14, name_color, ARGB(font_color.a,0,0,0), bg_color, rect2, c->GetName(), Unit::kAlignCenterMiddle);

					rect2 = Core::Rectangle(rect2.Max.x, cursor_y+33+24*rank, rect2.Max.x+78+offset2, cursor_y+33+24*(rank+1));
					str.format("%s", gLang->GetTextW(L"δѡ��"));
					if (c->GetCurCharinfo())
						str.format("%s", c->GetCurCharinfo()->career_name.Str());
					ui_render->DrawStringShadow(ui_render->font_simhei_14, name_color, ARGB(font_color.a,0,0,0), bg_color, rect2, str, Unit::kAlignCenterMiddle);

					if (!isTDmode)	//  [1/13/2014 aijiwei]
					{
						rect2 = Core::Rectangle(rect2.Max.x, cursor_y+33+24*rank, rect2.Max.x+100, cursor_y+33+24*(rank+1));
						str.format("%d", (int)c->all_score);
						ui_render->DrawStringShadow(ui_render->font_simhei_14, name_color, ARGB(font_color.a,0,0,0), bg_color, rect2, str, Unit::kAlignCenterMiddle);

						rect2 = Core::Rectangle(rect2.Max.x, cursor_y+33+24*rank, rect2.Max.x+108, cursor_y+33+24*(rank+1));
						str.format("%d/%d", c->num_killed, c->num_died);
						ui_render->DrawStringShadow(ui_render->font_simhei_14, name_color, ARGB(font_color.a,0,0,0), bg_color, rect2, str, Unit::kAlignCenterMiddle);

						rect2 = Core::Rectangle(rect2.Max.x, cursor_y+33+24*rank, rect2.Max.x+79, cursor_y+33+24*(rank+1));
						str.format("%d", c->num_assist);
						ui_render->DrawStringShadow(ui_render->font_simhei_14, name_color, ARGB(font_color.a,0,0,0), bg_color, rect2, str, Unit::kAlignCenterMiddle);
					}

					rect2 = Core::Rectangle(rect2.Max.x, cursor_y+33+24*rank, rect2.Max.x+89, cursor_y+33+24*(rank+1));
					str.format("%d", c->ping);
					ARGB pin_color = name_color;
					if (c->ping > 1500)
					{
						pin_color = ARGB(231, 82, 41);
					}
					ui_render->DrawStringShadow(ui_render->font_simhei_14, pin_color, ARGB(font_color.a,0,0,0), bg_color, rect2, str, Unit::kAlignCenterMiddle);
				}
			}

			switch (gLevel->game_type)
			{
			case RoomOption::kTeam:
			case RoomOption::kKnifeMode:
			case RoomOption::kItemMode:
			case RoomOption::kEditMode:
			case RoomOption::kTDMode:
				{
					tempc_ptr(Texture2D) tex1;
					tempc_ptr(Texture2D) tex2;
					if (gGame->scores->team_kills[0] > gGame->scores->team_kills[1])
					{
						tex1 = ig_tab_win_num;
						tex2 = ig_tab_lose_num;
					}	
					else if (gGame->scores->team_kills[0] == gGame->scores->team_kills[1])
					{
						tex1 = ig_tab_lose_num;
						tex2 = ig_tab_lose_num;
					}
					else
					{
						tex1 = ig_tab_lose_num;
						tex2 = ig_tab_win_num;
					}
					_DrawNumberTextureWindow(ui_render, tex1, Core::Vector2(tx+137, ty+298), 80, 108, gGame->scores->team_kills[0]/100,0.1f);
					_DrawNumberTextureWindow(ui_render, tex1, Core::Vector2(tx+137+80, ty+298), 80, 108, (gGame->scores->team_kills[0]%100)/10,0.1f);
					_DrawNumberTextureWindow(ui_render, tex1, Core::Vector2(tx+137+160, ty+298), 80, 108, gGame->scores->team_kills[0]%10,0.1f);

					_DrawNumberTextureWindow(ui_render, tex2, Core::Vector2(tx+430, ty+298), 80, 108, gGame->scores->team_kills[1]/100,0.1f);
					_DrawNumberTextureWindow(ui_render, tex2, Core::Vector2(tx+430+80, ty+298), 80, 108, (gGame->scores->team_kills[1]%100)/10,0.1f);
					_DrawNumberTextureWindow(ui_render, tex2, Core::Vector2(tx+430+160, ty+298), 80, 108, gGame->scores->team_kills[1]%10,0.1f);
				}
				break;
			case RoomOption::kHoldPoint:
			case RoomOption::kPushVehicle:
			case RoomOption::kBombMode:
			case RoomOption::kStreetBoyMode:
			case RoomOption::kTeamDeathMatch:
			case RoomOption::KMoonMode:
			case RoomOption::kAdvenceMode:
			case RoomOption::kSurvivalMode:
				{
					tempc_ptr(Texture2D) tex1;
					tempc_ptr(Texture2D) tex2;
					if (gGame->scores->team_round[0] > gGame->scores->team_round[1])
					{
						tex1 = ig_tab_win_num;
						tex2 = ig_tab_lose_num;
					}	
					else if (gGame->scores->team_round[0] == gGame->scores->team_round[1])
					{
						tex1 = ig_tab_lose_num;
						tex2 = ig_tab_lose_num;
					}
					else
					{
						tex1 = ig_tab_lose_num;
						tex2 = ig_tab_win_num;
					}
					_DrawNumberTextureWindow(ui_render, tex1, Core::Vector2(tx+137, ty+298), 80, 108, gGame->scores->team_round[0]/100,0.1f);
					_DrawNumberTextureWindow(ui_render, tex1, Core::Vector2(tx+137+80, ty+298), 80, 108, (gGame->scores->team_round[0]%100)/10,0.1f);
					_DrawNumberTextureWindow(ui_render, tex1, Core::Vector2(tx+137+160, ty+298), 80, 108, gGame->scores->team_round[0]%10,0.1f);

					_DrawNumberTextureWindow(ui_render, tex2, Core::Vector2(tx+430, ty+298), 80, 108, gGame->scores->team_round[1]/100,0.1f);
					_DrawNumberTextureWindow(ui_render, tex2, Core::Vector2(tx+430+80, ty+298), 80, 108, (gGame->scores->team_round[1]%100)/10,0.1f);
					_DrawNumberTextureWindow(ui_render, tex2, Core::Vector2(tx+430+160, ty+298), 80, 108, gGame->scores->team_round[1]%10,0.1f);
				}
				break;
			default:
				break;
			}
		}

		if (show_game_scores)
		{
			Matrix44 view, oldview, oldworld;
			oldworld = world;

			float scale = 1;
			win_time += Core::Task::GetFrameTime();
			win_anim.scale_spline.Interpolation(win_time, scale);

			world.ScaleXYZ(scale, scale, 1);
			world.Translate(Vector3(0, 0, 0));
			int win_x = 0;
			if (win_team == 0)
			{
				win_x = havewatch ? -509 : -420;
				world.TranslateXYZ(win_x, -30, 0);
			}
			else if (win_team == 1)
			{
				win_x = havewatch ? 231: 320;
				world.TranslateXYZ(win_x, -20, 0);
			}
			else
				return;
			ui_render->SetWorld(world);

			ui_render->DrawTextureWindow(Core::Vector2(-50, -100), 220, 212, ui_win, Core::Rectangle(0,0,1,1),Core::ARGB(255,255,255,255));

			ui_render->SetView(oldview);
			ui_render->SetWorld(oldworld);
		}
		else
		{
			win_time = 0;
		}

		CStrBuf<256> str;
		name_color = ARGB(214,214,214);
		Core::Rectangle rect3;
		switch (gLevel->game_type)
		{
		case RoomOption::kTeam:
				str.format(gLang->GetTextW(L"ģʽ : �ŶӾ���"));
			break;
		case RoomOption::kHoldPoint:
				str.format(gLang->GetTextW(L"ģʽ : ռ��ģʽ"));
			break;
		case RoomOption::kPushVehicle:
				str.format(gLang->GetTextW(L"ģʽ : �Ƴ�ģʽ"));
			break;
		case RoomOption::kTeamDeathMatch:
				str.format(gLang->GetTextW(L"ģʽ : ����ģʽ"));
			break;
		case RoomOption::kKnifeMode:
			str.format(gLang->GetTextW(L"ģʽ : ��սģʽ"));
			break;
		case RoomOption::KMoonMode:
			str.format(gLang->GetTextW(L"ģʽ : �����ʵ�"));
			break;
		case RoomOption::kBombMode:
			str.format(gLang->GetTextW(L"ģʽ : ����ģʽ"));
			break;
		case RoomOption::kStreetBoyMode:
			str.format(gLang->GetTextW(L"ģʽ : Ӣ��ģʽ"));
			break;
		case RoomOption::kItemMode:
			str.format(gLang->GetTextW(L"ģʽ: ����սģʽ"));
			break;
		case RoomOption::kTDMode:
			if (gLevel->room_option.rand_key.Length() == 0)
				str.format(gLang->GetTextW(L"ģʽ : ��սģʽ"));
			else
				str.format(gLang->GetTextW(L"ģʽ : ����ģʽ"));
			break;
		case RoomOption::kAdvenceMode:
			str.format(gLang->GetTextW(L"ģʽ : ʥ��������"));
			break;
		case RoomOption::kSurvivalMode:
			str.format(gLang->GetTextW(L"ģʽ : ����ģʽ"));
			break;
		case RoomOption::kMatchingMode:
			str.format(gLang->GetTextW(L"ģʽ : ƥ��ģʽ"));
			break;
		default:
			str.format(gLang->GetTextW(L"ģʽ : δ��д"));
			break;
		}

		rect3 = Core::Rectangle(tx+20,ty+248+172+245+15,tx+50+95,ty+248+172+245+30);
		ui_render->DrawStringShadow(ui_render->font_simhei_14, name_color, ARGB(font_color.a,0,0,0), bg_color, rect3, str, Unit::kAlignLeftMiddle);

		rect3 = Core::Rectangle(tx+50+200,ty+248+172+245+15,tx+50+200+95,ty+248+172+245+30);
		str.format(gLang->GetTextW(L"��ͼ�� : %s"),gLevel->name2);
		ui_render->DrawStringShadow(ui_render->font_simhei_14, name_color, ARGB(font_color.a,0,0,0), bg_color, rect3, str, Unit::kAlignLeftMiddle);

		rect3 = Core::Rectangle(tx+50+400,ty+248+172+245+15,tx+50+95+400,ty+248+172+245+30);
		switch (gLevel->game_type)
		{
		case RoomOption::kTeam:
		case RoomOption::kKnifeMode:
		case RoomOption::kItemMode:
			str.format(gLang->GetTextW(L"��ϷĿ�� : ��ɱ�ȴﵽ%d�˻�ʤ"),gLevel->rule_value);
			break;
		case RoomOption::kHoldPoint:
			str.format(gLang->GetTextW(L"��ϷĿ�� : ռ����Ƶ㣬ռ��%d�غ�ʤ��"),gLevel->rule_value);
			break;
		case RoomOption::kPushVehicle:
			str.format(gLang->GetTextW(L"��ϷĿ�� : �Ƴ������յ㣬�ɹ�%d�غ�ʤ��"),gLevel->rule_value);
			break;
		case RoomOption::kTeamDeathMatch:
			str.format(gLang->GetTextW(L"��ϷĿ�� : ����з�������ң��ɹ�%d�غ�ʤ��"),gLevel->rule_value);
			break;
		case RoomOption::KMoonMode:
			str.format(gLang->GetTextW(L"��ϷĿ�� : �򶥷��ʵ�ǰ5�������λ��֣����ָ߻�ʤ"),gLevel->rule_value);
			break;
		case RoomOption::kAdvenceMode:
			str.format(gLang->GetTextW(L"��ϷĿ�� : ��C�ң���ѫ�£��Ჿ����������"),gLevel->rule_value);
			//str.format(gLang->GetTextW(L"??????????????"),gLevel->rule_value);
			break;   
		case RoomOption::kSurvivalMode:
			str.format(gLang->GetTextW(L"��ϷĿ�꣺����Ķ����ʤ"),gLevel->rule_value);
			break;
		case RoomOption::kBombMode:
			{
				if (gLevel->GetPlayer()->GetTeam() == 0)
				{
					str.format(gLang->GetTextW(L"��ϷĿ�� : �ɹ�����Ŀ��㣬����%d�غ�ʤ��"), gLevel->rule_value);
				}
				else
				{
					str.format(gLang->GetTextW(L"��ϷĿ�� : �ɹ�����Ŀ��㣬����%d�غ�ʤ��"), gLevel->rule_value);
				}
			}
			break;
		case RoomOption::kStreetBoyMode:
			{
				str.format(gLang->GetTextW(L"��ϷĿ�� : ��ɱ�Է�Ӣ�� ��ɱ%d��ʤ��") ,gLevel->rule_value);
			}
			break;
		case RoomOption::kTDMode:
			if (0 == gLevel->GetPlayer()->GetTeam())
				str.format(gLang->GetTextW(L"��ϷĿ�� : ����50%%����Դ��"));
			else
				str.format(gLang->GetTextW(L"��ϷĿ�� : ��ס50%%����Դ��"));
			break;
		default:
			str.format(gLang->GetTextW(L"��ϷĿ�� : δ��д"));
			break;
		}

		ui_render->DrawStringShadow(ui_render->font_simhei_14, name_color, ARGB(font_color.a,255, 195, 1), bg_color, rect3, str, Unit::kAlignLeftMiddle);

		if(gGame->channel_connection && gGame->channel_connection->GetState() != ChannelConnection::kInReplay)
		{
			rect3 = Core::Rectangle(tx+20,ty+248+172+245+50,tx+50+95,ty+248+172+245+65);
			str.format(gLang->GetTextW(L"������ : %s"),gLang->GetText(gGame->address.server_name));
			ui_render->DrawStringShadow(ui_render->font_simhei_14, name_color, ARGB(font_color.a,0,0,0), bg_color, rect3, str, Unit::kAlignLeftMiddle);

			rect3 = Core::Rectangle(tx+50+200,ty+248+172+245+50,tx+50+95+200,ty+248+172+245+65);
			str.format(gLang->GetTextW(L"Ƶ�� : %s"),gLang->GetText(gGame->address.channel_name));
			ui_render->DrawStringShadow(ui_render->font_simhei_14, name_color, ARGB(font_color.a,0,0,0), bg_color, rect3, str, Unit::kAlignLeftMiddle);

			rect3 = Core::Rectangle(tx+50+400,ty+248+172+245+50,tx+50+95+400,ty+248+172+245+65);
			if (gGame->channel_connection->room_info.option.name && !isTDmode)
			{
				str.format(gLang->GetTextW(L"���� : %s"),gGame->channel_connection->room_info.option.name);
				ui_render->DrawStringShadow(ui_render->font_simhei_14, name_color, ARGB(font_color.a,0,0,0), bg_color, rect3, str, Unit::kAlignLeftMiddle);
			}
			
		}
	}
}

void InGameUINew::_DrawEnergyBar(by_ptr(UIRender) ui_render,by_ptr(Texture2D) texture_content, by_ptr(Texture2D) texture_content_alpha, by_ptr(Texture2D) texture, int x,int y,int width, int height, bool isshow)
{
	//���Ҫ�޸������������ֵ��֮��Ҫ�޸�UpdateUiScoreLine()��������еĹ�ʽ�����ˣ�����������Ҫ����fireball
	tempc_ptr(Character) viewer = gLevel->GetViewer();
	if(!viewer)
		return;

	AddEnergyEffectInfo &info = viewer->energy_bar_info;
	if (info.current_target_value <= 0.f || info.current_target_value > 1.f)
		return;

	int cx = (info.current_value + info.move_time / info.move_all_time * (info.current_target_value - info.current_value)) * width;
	int cx1 = info.current_target_value * width;

	float vspace = 0;

	if(info.current_value != info.current_target_value)
	{
		ui_render->SetTexture(texture_content_alpha);
		ui_render->DrawWindow(Core::Rectangle(x, y - height / 2 + vspace, x + cx1 + 6, y + height / 2 - vspace),Core::Rectangle(5, 5, 6, 6), Core::Rectangle(5.0f / 15.f, 5.0f / 15.f, 6.0f / 15.f, 6.0f / 15.f));
	}

	ui_render->SetTexture(texture_content);
	ui_render->DrawWindow(Core::Rectangle(x, y - height / 2 + vspace, x + cx + 6, y + height / 2 - vspace),Core::Rectangle(5, 5, 6, 6), Core::Rectangle(5.0f / 15.f, 5.0f / 15.f, 6.0f / 15.f, 6.0f / 15.f));

	if(info.flash_time < info.flash_all_time && info.current_value == info.current_target_value && isshow)
	{
		ui_render->SetTexture(texture);

		float alpha_ratio = abs(sin(info.flash_ratio));

		int alpha = 255 * alpha_ratio;

		ui_render->DrawWindow(Core::Rectangle(x, y - height / 2 - 2, x + cx, y + height / 2 + 2),Core::Rectangle(10,10,10,10),Core::Rectangle(10 / 34.f,10 / 23.f,10 / 34.f,10 / 23.f),Core::ARGB(alpha,255,255,255));
	}
}
void InGameUINew::SetInputFocus(bool value)
{
	bFoused = value;

	if (bFoused)
	{
		ImeUi_EnableIme(true);
	}
	else
	{
		ImeUi_FinalizeString();
		ImeUi_EnableIme(false);
	}
}

// input
void InGameUINew::OnInput(InputEventArgs & e)
{
	tempc_ptr(Character) player = gLevel->GetPlayer();
	tempc_ptr(Character) viewer = gLevel->GetViewer();

	if(viewer && player && viewer == player && e.Type == InputEventArgs::kKeyDown && e.Code == KC_ESCAPE && viewer->is_bag_open)
	{
		viewer->is_bag_open = false;
	}

	//for debug
	//	if(viewer && player && viewer == player && e.Type == InputEventArgs::kKeyDown && e.Code == KC_H)
	//	{
	//		AddEnergyEffectInfo &info = viewer->energy_bar_info;
	//
	//		info.move_time = 0.0f;
	//		info.move_all_time = 2.0f;
	//
	//		info.all_value = 1.0f;
	//		info.current_target_value = 0.8f;
	//		info.current_value = 0.5f;
	//
	//		info.flash_all_time = 1.0f;
	//		//info.flash_count = 10;
	//		info.flash_time = 0.0f;
	//		
	//	}

	//if (e.Type == InputEventArgs::kKeyDown && KC_P == e.Code && gGame->channel_connection)
	//{
	//	//ChatMessage ss;
	//	//ss.channel = "/online";
	//	//ss.msg = "";
	//	//ReceiveMsg(ss);

	//	//show_game_scores = true;
	//	//win_time = 0;
	//	//win_team = 0;

	//	//gGame->channel_connection->NoviceOperation(24);
	//	//gGame->channel_connection->LeaveGame();

	//	tempc_ptr(Character) player = gLevel->GetViewer();
	//	player->isshowevent = true;
	//	player->kills_kind.Clear();
	//	player->kills_kind.PushBack(kCure1);
	//}
	
	//if (e.Type == InputEventArgs::kKeyDown && e.Code == KC_F1)
	//{
		//gLevel->AddHorn("asdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdf");
		//ChatMessage msg;
		//msg.msg = String::Format("%s", gLang->GetTextW(L"���ۼ�����ʱ������3Сʱ, ���Ѿ�����ƣ����Ϸʱ�䣬������Ϸ���潫��Ϊ����ֵ��50����Ϊ�����Ľ������뾡��������Ϣ�����ʵ���������������ѧϰ���"));
		//SetWarningMsg(msg);
		//gGame->global->SystemMessage(String::Format(gLang->GetTextW(L"%s �뿪��Ϸ"), "abbbc"), "/info");
	//}

	//if (e.Type == InputEventArgs::kKeyDown && e.Code == KC_F1)
	//{
	//	AddMsgToMsgs(gLang->GetTextW(L"��ϵͳ���� ���ۼ�����ʱ������1Сʱ"));
	//}
	//if (e.Type == InputEventArgs::kKeyDown && e.Code == KC_F2)
	//{
	//	AddMsgToMsgs(gLang->GetTextW(L"��ϵͳ���� ���ۼ�����ʱ������2Сʱ"));
	//}
	//if (e.Type == InputEventArgs::kKeyDown && e.Code == KC_F3)
	//{
	//	AddMsgToMsgs(gLang->GetTextW(L"��ϵͳ���� ���ۼ�����ʱ������3Сʱ, ���Ѿ�����ƣ����Ϸʱ�䣬������Ϸ���潫��Ϊ����ֵ��50����Ϊ�����Ľ������뾡��������Ϣ�����ʵ���������������ѧϰ����"));
	//}
	//if (e.Type == InputEventArgs::kKeyDown && e.Code == KC_F4)
	//{
	//	AddMsgToMsgs(gLang->GetTextW(L"��ϵͳ���� ���Ѿ�����ƣ����Ϸʱ�䣬������Ϸ���潫��Ϊ����ֵ��50����Ϊ�����Ľ������뾡��������Ϣ�����ʵ���������������ѧϰ����"));
	//}
	//if (e.Type == InputEventArgs::kKeyDown && e.Code == KC_F5)
	//{
	//	AddMsgToMsgs(gLang->GetTextW(L"��ϵͳ���� ���ѽ��벻������Ϸʱ�䣬Ϊ�����Ľ�������������������Ϣ���粻���ߣ��������彫�ܵ��𺦣����������ѽ�Ϊ�㣬ֱ�������ۼ�����ʱ����5Сʱ�󣬲��ָܻ�����"));
	//}

	if (gGame->config->IsActionDown(kActionUIPack) && gLevel->room_option.character_id > 0 && Special_time <= 0 && !bFoused)
	{
		tempc_ptr(StateMainGame) state_game = ptr_dynamic_cast<StateMainGame>(gGame->machine.CurrentState());
		if (state_game)
		{
			Special_time = 3;
			state_game->EventCantSelectPerson.Fire(ptr_static_cast<StateMainGame>(state_game), EventSpecial(gLevel->room_option.character_id));
		}
	}

	if (gLevel->novice_index == 3)
	{
		if (input_index > -1 && input_index < 4 && e.Type == InputEventArgs::kKeyDown)
		{
			switch (input_index)
			{
			case 0:
				{
					if (KC_W == e.Code)
					{
						if (Task::GetTotalTime() - input_timer > 0.5f)
						{
							input_index++;
							input_timer = Task::GetTotalTime();
						}
					}
				}
				break;
			case 1:
				{
					if (KC_S == e.Code)
					{
						if (Task::GetTotalTime() - input_timer > 0.5f)
						{
							input_index++;
							input_timer = Task::GetTotalTime();
						}
					}
				}
				break;
			case 2:
				{
					if (KC_A == e.Code)
					{
						if (Task::GetTotalTime() - input_timer > 0.5f)
						{
							input_index++;
							input_timer = Task::GetTotalTime();
						}
					}
				}
				break;
			case 3:
				{
					if (KC_D == e.Code)
					{
						if (Task::GetTotalTime() - input_timer > 0.5f)
						{
							input_index++;
							input_timer = Task::GetTotalTime();
						}
					}
				}
				break;
			}
		}
		else if (input_index == 4)
		{
			//��ʾ����
			gLevel->novice_timer = 0.f;
			gLevel->novice_need_timer = false;
			if (gGame->channel_connection)
				gGame->channel_connection->NoviceOperation(input_index);
			input_index = -1;
		}
	}
	else if (gLevel->novice_index == 9)
	{
		if (input_index > -1 && input_index <= 3 && e.Type == InputEventArgs::kKeyDown)
		{
			switch (input_index)
			{
			case 0:
				{
					if (KC_2 == e.Code)
						input_index = 1;
				}
				break;
			case 1:
				{
					if (KC_3 == e.Code)
						input_index = 2;
				}
				break;
			case 2:
				{
					gLevel->novice_index = 10;
					gLevel->novice_timer = 0.f;
					gLevel->novice_need_timer = false;
					input_index = -1;

					tempc_ptr(Character) player = gLevel->GetPlayer();
					if (player)
					{
						switch(player->GetCurCharinfo()->career_id)
						{
						case 1:
							gLevel->novice_shoot_num = 3;
							break;
						case 2:
							gLevel->novice_shoot_num = 4;
							break;
						case 3:
							gLevel->novice_shoot_num = 2;
							break;
						case 4:
							gLevel->novice_shoot_num = 3;
							break;
						case 5:
							gLevel->novice_shoot_num = 2;
							break;
						}
					}
				}
				break;
			}
		}
	}

	if(e.Type == InputEventArgs::kKeyDown && e.Code == KC_INCLINEND && !bFoused)
	{
		SetInputFocus(!bFoused);
		gLevel->isselectperson = bFoused;
	}

	if(e.Type == InputEventArgs::kKeyDown && e.Code == KC_RETURN)
	{
		SetInputFocus(!bFoused);
		gLevel->isselectperson = bFoused;

		if (!bFoused)
		{
			currentLine = *(inGameUI_textInput->GetTextBuffer());
			if(currentLine != "")
			{
				CRefStr currentlineRefStr = currentLine.RefStr();

				//����
				if(currentlineRefStr.startwith("/s "))
				{
					currentlineRefStr.remove(0,3);
					String name = ParseParam(currentlineRefStr);
					if(name != "" && currentlineRefStr.calclen() > 0)
					{
						CStrBuf<256> whisperline;
						m_chattoname = name;
						String content = String(currentlineRefStr);
						gGame->global->Chat(name, content);
					}
				}
				//else if (currentlineRefStr.startwith("/r "))
				//{
				//	if (m_chatname.Size() > 0 && m_chatname != gLevel->GetPlayer()->GetName())
				//	{
				//		String name = m_chatname;

				//		currentlineRefStr.remove(0,3);
				//		if(name != "" && currentlineRefStr.calclen() > 0)
				//		{
				//			CStrBuf<256> whisperline;
				//			m_chattoname = name;
				//			String content = String(currentlineRefStr);
				//			gGame->global->Chat(name, content);
				//		}
				//	}
				//	else
				//	{
				//		CStrBuf<256> whisperline;
				//		whisperline.format(gLang->GetTextW(L"�޷��ҵ�������㷢���������"));
				//		AddMsgToMsgs(whisperline);
				//	}
				//}
				else if (char_mode == 4 && currentlineRefStr.compare("/c") != 0 && currentlineRefStr.compare("/t") != 0 && currentlineRefStr.compare("/r") !=  0 && currentlineRefStr.compare("/z") !=  0)
				{
					if(currentlineRefStr.calclen() > 0)
					{
						String content = String(currentlineRefStr);
						gGame->global->Chat(m_chattoname, content);
					}
				}
				else if (char_mode == 1 && m_chattoname.Size() != 0 && currentlineRefStr.calclen() > 0)
				{
					String content = String(currentlineRefStr);
					gGame->global->Chat(m_chattoname, content);
				}
				else if (currentlineRefStr.startwith("/c") && currentlineRefStr.calclen() == 2)
				{
					text_input_color = ARGB(251, 245, 231);
					char_mode = 0;
				}
				/*else if (currentlineRefStr.startwith("/z") && currentlineRefStr.calclen() == 2)
				{
					text_input_color = ARGB(143, 226, 81);
					char_mode = 2;
				}*/
				else if (currentlineRefStr.startwith("/t") && currentlineRefStr.calclen() == 2)
				{
					text_input_color = ARGB(55, 200, 255);
					char_mode = 3;
				}
				//��������
				else if(char_mode == 3)
				{
					const char *str = currentlineRefStr.buff();
					gGame->global->Chat("/t",str);
				}
				//ս������
				/*else if(char_mode == 2)
				{
					const char *str = currentlineRefStr.buff();
					gGame->global->Chat("/z",str);
				}*/
				else
				{
					gGame->global->Chat("", currentLine);
				}

				if(!bFoused)
					inGameUI_textInput->Clear();
			}
		}
	}

	if(e.IsKeyEvent())
	{
		if (bFoused)
		{
			if (e.Code == KC_ESCAPE)
			{
				inGameUI_textInput->Clear();
				SetInputFocus(false);
				gLevel->isselectperson = false;
				e.Handled = true;
			}
			else
			{
				inGameUI_textInput->OnKeyEvent(e, false);
			}
		}

		if(e.Type == InputEventArgs::kKeyUp && e.Code == KC_SPACE)
		{
			if (bFoused)
			{
				currentLine = *(inGameUI_textInput->GetTextBuffer());
				if(currentLine != "")
				{
					CRefStr currentlineRefStr = currentLine.RefStr();

					//��ǰ
					if(currentlineRefStr.startwith("/c ") && currentlineRefStr.calclen() == 3)
					{
						text_input_color = ARGB(251, 245, 231);
						char_mode = 0;
						char_mode_Tab = 0;
						inGameUI_textInput->Clear();
					}
					//����
					else if(currentlineRefStr.startwith("/t ") && currentlineRefStr.calclen() == 3)
					{
						text_input_color = ARGB(55, 200, 255);
						char_mode = 3;
						char_mode_Tab = 1;
						inGameUI_textInput->Clear();
					}
					//ս��
					/*else if(currentlineRefStr.startwith("/z ") && currentlineRefStr.calclen() == 3)
					{
						text_input_color = ARGB(143, 226, 81);
						char_mode = 2;
						inGameUI_textInput->Clear();
					}*/
				}
			}
		}
	}
	double now_time = time(NULL);
	if (e.Type == InputEventArgs::kKeyUp && e.Code == KC_V && player->IsDied() && !bFoused)
	{
		if (gGame->channel_connection->round_win_team < 0)
		{
			tempc_ptr(BaseCharacterInfo) base_info = player->basecharacter_info;
			if (base_info)
			{
				int coin = base_info->fu_huo_bi;
				if ((gLevel->use_coin_num < 2 && gLevel->game_type == RoomOption::kBoss) || (fu_huo_bi_use_count < 10 && gLevel->game_type == RoomOption::kBossPVE && player_die_time > 0.0f))
				{
					if (coin > 0)
					{			
						coin -= 1;
						gLevel->use_coin_num += 1;
						gGame->channel_connection->UseSpawnCoin(coin);
						base_info->fu_huo_bi = gLevel->fuhuo_cion = coin;			 
					}
					else
						return;
				}			
			}
		}	
	}
	else if (e.Type == InputEventArgs::kKeyUp && e.Code == KC_COMMA && !player->IsDied() && !bFoused)
	{
		m_leftScaleTime = ScaleTime;
		if (m_SelectLeftTime<=0)
		{
			m_SelectLeftTime = ICON_MOVE_TIME;
			m_SelectRightTime = 0.0f;
		}
	}
	else if (e.Type == InputEventArgs::kKeyUp && e.Code == KC_PERIOD && !player->IsDied() && !bFoused)
	{
		m_rightScaleTime = ScaleTime;
		if (m_SelectRightTime<=0)
		{
			m_SelectLeftTime = 0.0f;
			m_SelectRightTime = ICON_MOVE_TIME;
		}
	}
	else if (e.Type == InputEventArgs::kKeyUp && e.Code == KC_H && !player->IsDied() && !bFoused)
	{
		InGameItemInfo* item = m_DisplayItem[2];
		if (NULL == item || item->count == 0 || player->ItemIsCDTime(item, now_time) )
			return;
		if (player->IsCarrierMode() )
			return;
			
		gGame->channel_connection->UseItem(item->sid);
		m_KeyHScaleTime = ScaleTime;
	}
	else if (e.Type == InputEventArgs::kKeyUp && e.Code == KC_G && !player->IsDied() && !bFoused)
	{
		InGameItemInfo* item = m_DisplayItem[ITEM_ICON_NUM-1];
		if (item && item->count>0 && !player->ItemIsCDTime(item, now_time) && !player->IsCarrierMode() )
		{
			m_isCarriering = true;
			m_CarrierTime = 0.0f;
			m_KeyGScaleTime = ScaleTime;
		}
	}
	else if (e.Type == InputEventArgs::kKeyUp && e.Code == KC_6 && !player->IsDied() && !bFoused)
	{
		m_skill->type = kSillCharacter_KC6;
		gGame->channel_connection->UseSkill(m_skill);
	}

	//Tab ������ģʽ
	if (e.Type == InputEventArgs::kKeyUp && e.Code == KC_TAB && bFoused)
	{
		char_mode_Tab ++;
		if (char_mode_Tab > 2)
		{
			char_mode_Tab = 0;
		}
		if (char_mode_Tab == 0)
		{
			text_input_color = ARGB(251, 245, 231);
			char_mode = 0;
			inGameUI_textInput->Clear();
		} 
		else if (char_mode_Tab == 1)
		{
			text_input_color = ARGB(55, 200, 255);		
			char_mode = 3;
			inGameUI_textInput->Clear();
		} 
		else if (char_mode_Tab == 2)
		{
			if (m_chattoname.Length() > 0)
			{
				text_input_color = 0xFFF289E9;
				char_mode = 4;
				inGameUI_textInput->Clear();
			}
			else if (m_chatname.Length() > 0)
			{
				m_chattoname = m_chatname;
				text_input_color = 0xFFF289E9;
				char_mode = 4;
				inGameUI_textInput->Clear();
			}
			else
			{
				char_mode_Tab = 0;
				text_input_color = ARGB(251, 245, 231);
				char_mode = 0;
				inGameUI_textInput->Clear();
			}
		}
	}

}

// draw a msg
void InGameUINew::SetWarningMsg(ChatMessage & msg)
{
	if(msg.msg == "")
		warn_msg.clear();
	else
	{
		warn_msg.clear();
		warn_msg.contract(msg.msg.Str());

		warn_msg_flag = true;
		warn_msg_time = 0.0f;
	}
}

// receive a msg from server
void InGameUINew::ReceiveMsg(ChatMessage & msg)
{
	for(int i = 0; i < (int)gLevel->m_Blacklist.Size();++i)
	{
		if (gLevel->m_Blacklist[i].name == msg.sender)
		{
			return;
		}
	}

	if(gGame->global)
	{
		gGame->global->Translate(msg.msg);
		gGame->global->Translate(msg.sender);
	}
	CStrBuf<256> strBuf;
	if(msg.channel == Identifier::kNull)
	{
		strBuf.format(gLang->GetTextW(L"��%s��˵��%s"), msg.sender, msg.msg);
		AddMsgToMsgs(strBuf);
	}
	else if(msg.channel == Core::Identifier("/x"))
	{
		strBuf.format(gLang->GetTextW(L"�����ߵ硿[%s]˵��%s"), msg.sender, msg.msg);
		AddMsgToMsgs(strBuf,true);
	}
	else if(gGame->lobby_connection && msg.channel == Core::Identifier(gGame->lobby_connection->character_name))
	{
		m_chatname = Core::String::Format("%s",msg.sender);
		strBuf.format(gLang->GetTextW(L"�����[%s]����˵��%s"), msg.sender, msg.msg);
		AddMsgToMsgs(strBuf,true);
	}
	else if (gGame->lobby_connection && msg.channel == Core::Identifier(m_chattoname))
	{
		text_input_color = 0xFFF289E9;
		char_mode = 4;
		char_mode_Tab = 2;
		strBuf.format(gLang->GetTextW(L"������Ҷ�[%s]˵��%s"), msg.channel, msg.msg);
		AddMsgToMsgs(strBuf,true);
	}
	else if (msg.channel == Core::Identifier("/offline"))
	{
		strBuf.format(gLang->GetTextW(L"��� %s �����ڻ�����"), msg.sender);
		AddMsgToMsgs(strBuf);
	}
	else if(msg.channel == Core::Identifier("/info"))
	{
		strBuf.format(gLang->GetTextW(L"����Ϣ����%s"), msg.msg);
		AddMsgToMsgs(strBuf,true);
	}
	else if(msg.channel == Core::Identifier("/online"))
	{
		tempc_ptr(StateMainGame) state_main = ptr_dynamic_cast<StateMainGame>(gGame->machine.CurrentState());
		if (state_main)
		{
			gGame->global->Translate(msg.msg);
			CRefStr r_str = msg.msg.RefStr();

			int pos = r_str.contain("@!", 2);
			if ( -1 != pos)
			{
				r_str.remove(0, pos + 2);
				msg.msg = r_str;
				
			}
			Core::String str = Core::String::Format(gLang->GetTextW(L"��������ʾ����%s"), msg.msg);
			info_tip.Add(str);
		}
		else
		{
			strBuf.format(gLang->GetTextW(L"����Ϣ����%s"), msg.msg);
			AddMsgToMsgs(strBuf,true);
		}
	}
	else if(msg.channel == Core::Identifier("/sys"))
	{
		strBuf.format(gLang->GetTextW(L"��ϵͳ����%s"), msg.msg);
		AddMsgToMsgs(strBuf,true);
	}
	else if(msg.channel == Core::Identifier("/dlb"))
	{
		strBuf.format(gLang->GetTextW(L"�������ȡ�  [%s] ��%s"),msg.sender, msg.msg);
		AddMsgToMsgs(strBuf,true);
	}
	else if(msg.channel == Core::Identifier("/xlb"))
	{
		strBuf.format(gLang->GetTextW(L"��С���ȡ�  [%s] ��%s"),msg.sender, msg.msg);
		AddMsgToMsgs(strBuf,true);
	}
	else if (msg.channel == Core::Identifier("/no_l"))
	{
		strBuf.format(gLang->GetTextW(L"��Ŀǰû����ӡ�"));
		AddMsgToMsgs(strBuf);
	}
	else if (msg.channel == Core::Identifier("/no_z"))
	{
		strBuf.format(gLang->GetTextW(L"��Ŀǰû��ս�ӡ�"));
		AddMsgToMsgs(strBuf);
	}
	else if(msg.channel == Core::Identifier("/t"))
	{
		strBuf.format(gLang->GetTextW(L"�����ѡ�%s��%s"),msg.sender,msg.msg);
		AddMsgToMsgs(strBuf,true);
	}
	else if(msg.channel == Core::Identifier("/z"))
	{
		strBuf.format(gLang->GetTextW(L"��ս�ӡ�%s��%s"),msg.sender,msg.msg);
		AddMsgToMsgs(strBuf,true);
	}
	else if (msg.channel == Core::Identifier("/gag"))
	{
		strBuf.format(gLang->GetTextW(L"��˵�����졣"));
		AddMsgToMsgs(strBuf);
	}
	else if (msg.channel == Core::Identifier("/notice"))
	{
		strBuf.format(gLang->GetTextW(L"��֪ͨ����%s"), msg.msg);
		AddMsgToMsgs(strBuf,true);
	}
}

// try to get whisper name and content
String InGameUINew::ParseParam(CRefStr & Param)
{
	while (Param[0] == ' ')
		Param.remove(0);

	CStrBuf<256> o;
	while(Param.calclen() > 0 && Param[0] != ' ')
	{
		o.insert(o.calclen(), Param[0]);
		Param.remove(0);
	}
	Param.remove(0);
	return o;
}

void InGameUINew::AddMsgToMsgs(Core::String str,bool issys)
{
	fFadeTime = fFadeCoolDown;
	//bStartFade = false;
	CStrBuf<256> line;
	bool is_la_ba = false;
	bool is_info = false;
	bool is_whisper = false;
	bool is_sys = false;
	bool is_war_team = false;
	bool is_team = false;

	int len = TextLenght(str);

	int index = 0;

	Core::Rectangle rect;

	CRefStr r_str = str.RefStr();

	if(r_str.startwith(gLang->GetTextW(L"�������ȡ�").Str()) || r_str.startwith(gLang->GetTextW(L"��С���ȡ�").Str()))
	{
		int s_index = r_str.find('\n');
		while(s_index>=0)
		{
			r_str.remove(s_index);
			s_index = r_str.find('\n');
		}
		len = TextLenght(str);
	}

	while(len)
	{
		line.insert(line.len(),TextCopy(str,index,1).RefStr());

		Core::String line_str;

		rect = gRender->ui_render->font_simhei_12->MeasureString(Core::Rectangle(0,0,0,0),line);

		if(rect.Max.x >= 600 || rect.Max.x < 600 && len == 1)
		{
			line_str = line;

			line.clear();

			tempc_ptr(Character) viewer = gLevel->GetViewer();

			if(speaker_list.GetCount() ==0)
			{
				speaker_list.Add(speaker_current_list.GetAt(0));
				speaker_current_list.RemoveAt(0);
				speaker_current_list.PushBack(speaker_list.GetAt(0));

				if(viewer)
					viewer->speaker_tip_time[speaker_list.GetAt(0)] = 0.0f;

				speaker_list.RemoveAt(0);
			}
			else
			{
				if(viewer)
					viewer->speaker_tip_time[speaker_list.GetAt(0)] = 0.0f;

				speaker_current_list.Add(speaker_list.GetAt(0));
				speaker_list.RemoveAt(0);
			}

			///////////////////////////////////////
			if(issys && (line_str.RefStr().startwith(gLang->GetTextW(L"�������ȡ�").Str()) || line_str.RefStr().startwith(gLang->GetTextW(L"��С���ȡ�").Str())))
			{
				current_speaker_info = line_str;
				speaker_msg_flag = true;
				speaker_msg_time = 0.0f;

				is_la_ba = true;
				
				if (line_str.RefStr().startwith(gLang->GetTextW(L"�������ȡ�  [ϵͳ����]").Str()))
				{
					line_str = Core::String::Format(gLang->GetTextW(L"��ϵͳ����%s"),line_str+25);
					Msgs_Color.Add(Core::ARGB(255, 218, 0, 6));
				}
				else
				{
					Msgs_Color.Add(Core::ARGB(255, 252, 239, 3));
				}
			}
			else if(issys && line_str.RefStr().startwith(gLang->GetTextW(L"�����").Str()))
			{
				is_whisper = true;
				Msgs_Color.Add(0xFFF289E9);
			}
			else if(issys && line_str.RefStr().startwith(gLang->GetTextW(L"����Ϣ��").Str()))
			{
				is_info = true;
				Msgs_Color.Add(Core::ARGB(255, 183, 171, 165));
			}
			else if(issys && line_str.RefStr().startwith(gLang->GetTextW(L"��ϵͳ��").Str()))
			{
				is_sys = true;
				Msgs_Color.Add(Core::ARGB(255, 218, 0, 6));
			}
			else if(issys && line_str.RefStr().startwith(gLang->GetTextW(L"��֪ͨ��").Str()))
			{
				is_sys = true;
				Msgs_Color.Add(Core::ARGB(255, 218, 0, 6));
			}
			else if(issys && line_str.RefStr().startwith(gLang->GetTextW(L"��ս�ӡ�").Str()))
			{
				is_war_team = true;
				Msgs_Color.Add(Core::ARGB(255,143,226,81));
			}
			else if(issys && line_str.RefStr().startwith(gLang->GetTextW(L"�����ѡ�").Str()))
			{
				is_team = true;
				Msgs_Color.Add(Core::ARGB(255,55,200,255));
			}
			else if (issys && line_str.RefStr().startwith(gLang->GetTextW(L"�����ߵ硿").Str()))
			{
				Msgs_Color.Add(Core::ARGB(255,255,60,8));
			}
			else 
			{
				if(is_la_ba)
					Msgs_Color.Add(Core::ARGB(255, 252, 239, 3));
				else if(is_whisper)
					Msgs_Color.Add(0xFFF289E9);
				else if(is_info)
					Msgs_Color.Add(Core::ARGB(255, 183, 171, 165));
				else if(is_sys)
					Msgs_Color.Add(Core::ARGB(255, 218, 0, 6));
				else if(is_war_team)
					Msgs_Color.Add(Core::ARGB(255,143,226,81));
				else if(is_team)
					Msgs_Color.Add(Core::ARGB(255,55,200,255));
				else
					Msgs_Color.Add(Core::ARGB(255,255,255,255));
			}
			///////////////////////////////////

			fiveMsgs.Add(line_str);

			if(fiveMsgs.GetCount() > 5)
			{
				fiveMsgs.RemoveAt(0);
				Msgs_Color.RemoveAt(0);
			}

			line_str.Clear();
			len--;
			index++;
		}
		else
		{
			len--;
			index++;
		}
	}
}


void InGameUINew::DrawRadio(by_ptr(UIRender) render, Core::Matrix44 &world)
{
	tempc_ptr(Character) player = gLevel->GetPlayer();
	//tempc_ptr(Character) viewer = gLevel->GetViewer();

	//if(viewer)
	//	player = viewer;

	if(!player)
		return;
	if(player->IsDied())
		return;
	Bool flag = false;
	HashSet<uint, sharedc_ptr(DummyObject)>::Enumerator it(gLevel->dummy_object_set);
	while (it.MoveNext())
	{
		if(it.Value()->owner_id == player->uid && it.Value()->type == DummyObject::DUMMY_MACHINE_TURRENT && !it.Value()->need_stepfather)
		{
			flag = true;
		}
	}
	if (!flag && player->radio_state == 4)
	{
		return;
	}

	if (player->radio_state == 4 && (gLevel->game_type == RoomOption::kEditMode))
	{
		return;
	}

	Matrix44 old_world = world;

	Vector3 rt_size = gGame->guiSys->GetSize();
	
	world.SetTranslationXYZ(6,rt_size.y / 2.0f, 0);

	render->SetTexture(NullPtr);
	render->SetWorld(world);

	if(player->radio_state > 0)
		render->DrawRectangle(Core::Rectangle(0,0 - 200,230,300 - 250), Core::Rectangle(0,0,1,1), Core::ARGB(100,50,50,50));


	Core::Array<String> *str = NULL;
	if(player->radio_state == 1)
	{
		str = &normal_command_radio;
		render->DrawString(render->font_simhei_28,Core::ARGB(255,255,255),Core::ARGB(0,0,0,0),Core::Rectangle(8,0 - 230,100,100 - 230),gLang->GetTextW(L"�ҵ�����"),Unit::kAlignLeftMiddle);

	}
	if(player->radio_state == 2)
	{
		str = &team_command_radio;
		render->DrawString(render->font_simhei_28,Core::ARGB(255,255,255),Core::ARGB(0,0,0,0),Core::Rectangle(8,0 - 230,100,100 - 230),gLang->GetTextW(L"�Ŷ�����"),Unit::kAlignLeftMiddle);

	}
	if(player->radio_state == 3)
	{
		str = &reply_command_radio;

		render->DrawString(render->font_simhei_28,Core::ARGB(255,255,255),Core::ARGB(0,0,0,0),Core::Rectangle(8,0 - 230,100,100 - 230),gLang->GetTextW(L"ս�����"),Unit::kAlignLeftMiddle);
	}

	if(player->radio_state == 4 && flag)
	{
		str = &dummy_radio;

		render->DrawString(render->font_simhei_28,Core::ARGB(255,255,255),Core::ARGB(0,0,0,0),Core::Rectangle(8,0 - 230,100,100 - 230),gLang->GetTextW(L"��ǹ���ƶ�"),Unit::kAlignLeftMiddle);
	}

	CStrBuf<256> buf;

	if(str)
	{
		int size,i,index = 0;

		size = str->Size();
		

		for(i = 0 ; i < size ; i++)
		{
			buf.format("%d.%s",i+1,(*str)[i + index].Str());

			render->DrawString(render->font_simhei_20,Core::ARGB(255,255,255),Core::ARGB(0,0,0,0),Core::Rectangle(8,0 - 230 + (i+1) * 30,100,100 - 230 + (i+1) * 30),buf.buff(),Unit::kAlignLeftMiddle);
		}

		render->DrawString(render->font_simhei_20,Core::ARGB(255,255,255),Core::ARGB(0,0,0,0),Core::Rectangle(8,0 - 230 + (i+1) * 30,100,100 - 230 + (i+1) * 30),gLang->GetTextW(L"0.�˳�"),Unit::kAlignLeftMiddle);
	}

	render->SetWorld(old_world);
}


void InGameUINew::InitPersonUI(tempc_ptr(Character) character)
{
	String team[2] = {"red","blue"};
	if (character && character->basecharacter_info)
	{
		tempc_ptr(BaseCharacterInfo) base_info = character->basecharacter_info;

		//ui_bottom_info_headhui_icon  &  ui_bottom_info_headbinsi_icon
		for (uint i = 0; i < base_info->career_count; i++)
		{
			CharacterInfoSimple & career_info = base_info->career_list[i];

			if (!ui_bottom_info_headhui_icon.Contains(career_info.career_id))
			{
				String file_name = String::Format("IngameUI/person/ig_common_tool_%s_hui.dds", career_info.res_key.Str());
				sharedc_ptr(Texture2D) texture = RESOURCE_LOAD_NEW(file_name.Str(), true, Texture2D);
				//LogSystem.WriteLinef("career_info.career_id = %d",career_info.career_id);
				//LogSystem.WriteLinef("career_info.res_key.Str() = %s",career_info.res_key.Str());
				ui_bottom_info_headhui_icon.Set(career_info.career_id, texture);
			}

			if (!ui_bottom_info_headbinsi_icon.Contains(career_info.career_id))
			{
				String file_name = String::Format("IngameUI/person/ig_common_tool_%s_binsi.dds", career_info.res_key.Str());
				sharedc_ptr(Texture2D) texture = RESOURCE_LOAD_NEW(file_name.Str(), true, Texture2D);
				//LogSystem.WriteLinef("career_info.career_id = %d",career_info.career_id);
				//LogSystem.WriteLinef("career_info.res_key.Str() = %s",career_info.res_key.Str());
				ui_bottom_info_headbinsi_icon.Set(career_info.career_id, texture);
			}
		}

		//ui_common_hp_headicon
		for (uint i = 0; i < base_info->career_count; i++)
		{
			CharacterInfoSimple & career_info = base_info->career_list[i];
			if (!ui_common_hp_headicon.Contains(career_info.career_id))
			{
				String file_name = String::Format("IngameUI/ig_common_hp_ico_%s.dds", career_info.career_key.Str());
				//LogSystem.WriteLinef("career_info.career_id = %d",career_info.career_id);
				//LogSystem.WriteLinef("file_name = %s",file_name);
				sharedc_ptr(Texture2D) texture = RESOURCE_LOAD_NEW(file_name.Str(), true, Texture2D);
				ui_common_hp_headicon.Set(career_info.career_id, texture);
			}
		}
	}
	else
	{
		LogSystem.WriteLinef("player->basecharacter_info = NULL");
	}
}

void InGameUINew::_InitHeadInfo()
{
	ui_head_info_bg_center = RESOURCE_LOAD_NEW("IngameUI/headinfo/ig_common_time_bg_m.dds", true, Texture2D);
	ui_head_info_bg_left = RESOURCE_LOAD_NEW("IngameUI/headinfo/ig_common_time_bg_r.dds", true, Texture2D);
	ui_head_info_bg_right = RESOURCE_LOAD_NEW("IngameUI/headinfo/ig_common_time_bg_b.dds", true, Texture2D);
	ui_head_info_bg_TeamDeath = RESOURCE_LOAD_NEW("IngameUI/headinfo/ig_jm_time_bg_all.dds", true, Texture2D);
	ui_head_info_bg_Zombie = RESOURCE_LOAD_NEW("IngameUI/headinfo/ig_re_time_bg.dds", true, Texture2D);
	ui_head_info_bg_boss = RESOURCE_LOAD_NEW("IngameUI/headinfo/ig_boss_time_bg.dds", true, Texture2D);
	ui_head_info_time_bg = RESOURCE_LOAD_NEW("IngameUI/headinfo/ig_common_time_bg02.dds", true, Texture2D);
	ui_head_info_time_number = RESOURCE_LOAD_NEW("IngameUI/headinfo/ig_common_time_number.dds", true, Texture2D);
	ui_head_info_boss = RESOURCE_LOAD_NEW("IngameUI/headinfo/ig_boss_hp_bg.dds", true, Texture2D);
	ui_head_info_boss_hp[0] = RESOURCE_LOAD_NEW("IngameUI/headinfo/ig_boss_hp_red.dds", true, Texture2D);
	ui_head_info_boss_hp[1] = RESOURCE_LOAD_NEW("IngameUI/headinfo/ig_boss_hp_yellow.dds", true, Texture2D);
	ui_head_info_boss_hp[2] = RESOURCE_LOAD_NEW("IngameUI/headinfo/ig_boss_hp_orange.dds", true, Texture2D);
	ui_head_info_boss_hp[3] = RESOURCE_LOAD_NEW("IngameUI/headinfo/ig_boss_hp_blue.dds", true, Texture2D);
	ui_head_info_StreetBoy_Red = RESOURCE_LOAD_NEW("IngameUI/headinfo/ig_common_tubiao_hpbar_red.dds", true, Texture2D);
	ui_head_info_StreetBoy_Blue = RESOURCE_LOAD_NEW("IngameUI/headinfo/ig_common_tubiao_hpbar_blue.dds", true, Texture2D);
	ui_head_infoStreetBoy_Hp_Blue =  RESOURCE_LOAD_NEW("IngameUI/headinfo/ig_common_tubiao_kinghp_blue.dds", true, Texture2D);
	ui_head_infoStreetBoy_Hp_Red =  RESOURCE_LOAD_NEW("IngameUI/headinfo/ig_common_tubiao_kinghp_red.dds", true, Texture2D);
	ui_head_info_bg_boss_mode2_bg = RESOURCE_LOAD_NEW("IngameUI/headinfo/ig_boss1_time_bg.dds", true, Texture2D);

	ui_head_tip[0] = RESOURCE_LOAD_NEW("IngameUI/headinfo/in_gtarget_td.dds", true, Texture2D);
	ui_head_tip[1] = RESOURCE_LOAD_NEW("IngameUI/headinfo/in_gtarget_cp.dds", true, Texture2D);
	ui_head_tip[2] = RESOURCE_LOAD_NEW("IngameUI/headinfo/in_gtarget_pl.dds", true, Texture2D);
	ui_head_tip[3] = RESOURCE_LOAD_NEW("IngameUI/headinfo/in_gtarget_wo.dds", true, Texture2D);
	ui_head_tip[4] = RESOURCE_LOAD_NEW("IngameUI/headinfo/in_gtarget_boss.dds", true, Texture2D);
	ui_head_tip[5] = RESOURCE_LOAD_NEW("IngameUI/headinfo/in_gtarget_bomb_red.dds", true, Texture2D);
	ui_head_tip[6] = RESOURCE_LOAD_NEW("IngameUI/headinfo/in_gtarget_bomb_blue.dds", true, Texture2D);
	ui_head_tip[7] = RESOURCE_LOAD_NEW("IngameUI/headinfo/in_target_killhero.dds", true, Texture2D);
	ui_head_tip[8] = RESOURCE_LOAD_NEW("IngameUI/headinfo/in_gtarget_re.dds", true, Texture2D);
	ui_head_tip[9] = RESOURCE_LOAD_NEW("IngameUI/headinfo/in_gtarget_boss2_red.dds", true, Texture2D);
	ui_head_tip[10] = RESOURCE_LOAD_NEW("IngameUI/headinfo/in_gtarget_zb2.dds", true, Texture2D);
	ui_head_tip[11] = RESOURCE_LOAD_NEW("IngameUI/headinfo/in_gtarget_boss1.dds", true, Texture2D);
	ui_head_tip[12] = RESOURCE_LOAD_NEW("IngameUI/headinfo/in_gtarget_im.dds", true, Texture2D);
	ui_head_tip[13] = RESOURCE_LOAD_NEW("IngameUI/headinfo/in_gtarget_edit_red.dds", true, Texture2D);
	ui_head_tip[14] = RESOURCE_LOAD_NEW("IngameUI/headinfo/in_gtarget_edit_blue.dds", true, Texture2D);
	ui_head_tip[15] = RESOURCE_LOAD_NEW("IngameUI/headinfo/in_gtarget_jp.dds", true, Texture2D);
}

void InGameUINew::_InitHeadIcon()
{
}

void InGameUINew::_InitBottomInfo()
{	
	ui_bottomleft_info_bg[0] = RESOURCE_LOAD_NEW("InGameUI/bottom_info/ig_common_tool_red_l.dds", true, Texture2D);
	ui_bottomleft_info_bg[1] = RESOURCE_LOAD_NEW("InGameUI/bottom_info/ig_common_tool_blue_l.dds", true, Texture2D);
	ui_bottomright_info_bg[0] = RESOURCE_LOAD_NEW("InGameUI/bottom_info/ig_common_tool_red_r.dds", true, Texture2D);
	ui_bottomright_info_bg[1] = RESOURCE_LOAD_NEW("InGameUI/bottom_info/ig_common_tool_blue_r.dds", true, Texture2D);

	ui_bottomleft_info_boos = RESOURCE_LOAD_NEW("InGameUI/bottom_info/ig_boss_tool_boss_l.dds", true, Texture2D);
	ui_bottomright_info_boos = RESOURCE_LOAD_NEW("InGameUI/bottom_info/ig_boss_boss_red_r.dds", true, Texture2D);
	ui_headicon_boos = RESOURCE_LOAD_NEW("InGameUI/person/ig_boss_avt.dds", true, Texture2D);

	ui_bottommiddle_info_people = RESOURCE_LOAD_NEW("InGameUI/headinfo/ig_re_bg_01.dds", true, Texture2D);

	ui_bottom_info_X = RESOURCE_LOAD_NEW("InGameUI/bottom_info/ig_common_tool_baoxiang_X.dds", true, Texture2D);
	ui_bottom_info_small_card = RESOURCE_LOAD_NEW("InGameUI/bottom_info/ig_common_fanpai_card_bg.dds", true, Texture2D);
	ui_bottom_info_big_card = RESOURCE_LOAD_NEW("InGameUI/bottom_info/ig_common_fanpai_card_1.dds", true, Texture2D);
	ui_bottom_info_hp_add = RESOURCE_LOAD_NEW("InGameUI/bottom_info/ig_common_tool_+.dds", true, Texture2D);
	ui_bottom_info_all = RESOURCE_LOAD_NEW("InGameUI/bottom_info/ig_common_tool_wuqiongda.dds", true, Texture2D); 
	ui_bottom_info_danjia = RESOURCE_LOAD_NEW("InGameUI/bottom_info/ig_common_tool_danjia.dds", true, Texture2D);
	ui_bottom_info_fuhuobi = RESOURCE_LOAD_NEW("InGameUI/bottom_info/reliveCoin1.tga", true, Texture2D);

	ui_bottom_info_hp = RESOURCE_LOAD_NEW("InGameUI/ig_common_tool_hp.dds", true, Texture2D);
	ui_bottom_info_hp_kuang = RESOURCE_LOAD_NEW("InGameUI/ig_common_zhuizongduiyou_ hpbg.dds", true, Texture2D);

	ui_bottom_info_bullet_number = RESOURCE_LOAD_NEW("InGameUI/ig_common_tool_ numeral02.dds", true, Texture2D);
	ui_bottom_info_bullet_number2 = RESOURCE_LOAD_NEW("InGameUI/ig_common_tool_ numeral03.dds", true, Texture2D);
	ui_bottom_info_hp_number = RESOURCE_LOAD_NEW("InGameUI/ig_common_tool_ numeral02.dds", true, Texture2D);
	ui_bottom_info_CureGun[0] = RESOURCE_LOAD_NEW("InGameUI/ig_common_nursetool_bgred.dds", true, Texture2D);
	ui_bottom_info_CureGun[1] = RESOURCE_LOAD_NEW("InGameUI/ig_common_nursetool_bg.dds", true, Texture2D);
	ui_bottom_info_CureGun_Content = RESOURCE_LOAD_NEW("InGameUI/ig_common_nursetool_content.dds", true, Texture2D);
	ui_bottom_info_CureGun_PowerNum = RESOURCE_LOAD_NEW("InGameUI/ig_common_tool_ numeral01.dds", true, Texture2D);
	ui_bottom_info_CureGun_Power = RESOURCE_LOAD_NEW("InGameUI/ig_common_tool_ numeral_%.dds", true, Texture2D);
	ui_bottom_info_Exp = RESOURCE_LOAD_NEW("InGameUI/bottom_info/ig_common_power_content.dds", true, Texture2D);
	ui_bottom_info_Exp_45 = RESOURCE_LOAD_NEW("InGameUI/bottom_info/ig_common_power_content_45.dds", true, Texture2D);

	ui_bottom_info_GunTower_Picture[0] = RESOURCE_LOAD_NEW("InGameUI/bottom_info/ig_common_engineer_weapon_ico_r.dds", true, Texture2D);
	ui_bottom_info_GunTower_Picture[1] = RESOURCE_LOAD_NEW("InGameUI/bottom_info/ig_common_engineer_weapon_ico_b.dds", true, Texture2D);
	ui_bottom_info_GunTower_Move_CD[0] = RESOURCE_LOAD_NEW("InGameUI/bottom_info/ig_common_engineer_cd_bg.dds", true, Texture2D);
	ui_bottom_info_GunTower_Move_CD[1] = RESOURCE_LOAD_NEW("InGameUI/bottom_info/ig_common_engineer_cdbar_content.dds", true, Texture2D);
	ui_bottom_info_GunTower_UnBuider = RESOURCE_LOAD_NEW("InGameUI/bottom_info/ig_common_engineer_remote_ico.dds", true, Texture2D);
	ui_bottom_info_GunTower_bg = RESOURCE_LOAD_NEW("InGameUI/bottom_info/ig_common_tool_engineer_bg.dds", true, Texture2D);
	ui_bottom_info_GunTower_energy = RESOURCE_LOAD_NEW("InGameUI/bottom_info/ig_common_tool_engineer_bar_content.dds", true, Texture2D);
	ui_bottom_info_GunTower_energy_bg = RESOURCE_LOAD_NEW("InGameUI/bottom_info/ig_common_tool_engineer_bar_bg.dds", true, Texture2D);
	ui_bottom_info_GunTower_ammo = RESOURCE_LOAD_NEW("InGameUI/bottom_info/ig_common_engineer_ico_bull.dds", true, Texture2D);
	ui_bottom_info_MiniMachine_gun_1 = RESOURCE_LOAD_NEW("InGameUI/bottom_info/fatman05001ico_a.dds", true, Texture2D); 
	ui_bottom_info_MiniMachine_gun_2 = RESOURCE_LOAD_NEW("InGameUI/bottom_info/fatman05001ico_b.dds", true, Texture2D); 
}

void InGameUINew::_InitBGImage()
{
	ui_progress_bar_border = RESOURCE_LOAD_NEW("InGameUI/bar01.dds", true, Texture2D);
	ui_progress_bar_body = RESOURCE_LOAD_NEW("InGameUI/bar02.dds", true, Texture2D);

	ui_progress_bar_grenade_bg = RESOURCE_LOAD_NEW("InGameUI/ig_common_tool_shouleibg.dds", true, Texture2D);
	ui_progress_bar_grenade = RESOURCE_LOAD_NEW("InGameUI/ig_common_tool_shouleicoontent.dds", true, Texture2D);

	ui_common_power = RESOURCE_LOAD_NEW("InGameUI/ig_power_text.dds", true, Texture2D);
	ui_common_attack = RESOURCE_LOAD_NEW("InGameUI/ig_gonji_text.dds", true, Texture2D);
	ui_common_speed = RESOURCE_LOAD_NEW("InGameUI/ig_speed_text.dds", true, Texture2D);
	ui_common_hp_bg = RESOURCE_LOAD_NEW("InGameUI/ig_common_hp_bg.dds", true, Texture2D);
	ui_common_hp_friend_bg = RESOURCE_LOAD_NEW("InGameUI/ig_common_hp_bg_duiyou.dds", true, Texture2D);
	ui_common_hp[0] = RESOURCE_LOAD_NEW("InGameUI/ig_common_hp_content01.dds", true, Texture2D);
	ui_common_hp[1] = RESOURCE_LOAD_NEW("InGameUI/ig_common_hp_content02.dds", true, Texture2D);
	ui_common_hp[2] = RESOURCE_LOAD_NEW("InGameUI/ig_common_hp_content03.dds", true, Texture2D);
	for (int i = 0;i < 19; i++)
	{
		String file_name = String::Format("LobbyUI/ToolTips/badge_lv%d.dds",i);
		ui_common_weaponlevel[i] = RESOURCE_LOAD_NEW(file_name.Str(), true, Texture2D);
	}
	ui_common_notlevel = RESOURCE_LOAD_NEW("LobbyUI/ToolTips/badge_nolv.dds", true, Texture2D);
	ui_common_little_star = RESOURCE_LOAD_NEW("LobbyUI/ToolTips/little_star.dds", true, Texture2D);
	ui_common_skin_bar[0] = RESOURCE_LOAD_NEW("LobbyUI/ToolTips/skin_bar02_content.tga", true, Texture2D);
	ui_common_skin_bar[1] = RESOURCE_LOAD_NEW("LobbyUI/ToolTips/skin_bar02_content_4.tga", true, Texture2D);
	ui_common_skin_bar[2] = RESOURCE_LOAD_NEW("LobbyUI/ToolTips/skin_bar02_content_7.tga", true, Texture2D);
	ui_common_skin_bar[3] = RESOURCE_LOAD_NEW("LobbyUI/ToolTips/skin_bar02_content_10.tga", true, Texture2D);
	ui_common_skin_bar[4] = RESOURCE_LOAD_NEW("LobbyUI/ToolTips/skin_bar02_content_12.tga", true, Texture2D);
	ui_common_skin_bar[5] = RESOURCE_LOAD_NEW("LobbyUI/ToolTips/skin_bar02_content_14.tga", true, Texture2D);
	ui_common_skin_bar[6] = RESOURCE_LOAD_NEW("LobbyUI/ToolTips/skin_bar02_content_15.tga", true, Texture2D);
	ui_weapon[0] = RESOURCE_LOAD_NEW("LobbyUI/Compose/shengxing/lb_synthesis_conversion_star_01.dds", true, Texture2D);
	ui_weapon[1] = RESOURCE_LOAD_NEW("LobbyUI/Compose/shengxing/lb_synthesis_conversion_star_02.dds", true, Texture2D);
	ui_weapon[2] = RESOURCE_LOAD_NEW("LobbyUI/Compose/shengxing/lb_synthesis_conversion_star_03.dds", true, Texture2D);
	ui_weapon[3] = RESOURCE_LOAD_NEW("LobbyUI/Compose/shengxing/lb_synthesis_conversion_star_04.dds", true, Texture2D);
	ui_weapon[4] = RESOURCE_LOAD_NEW("LobbyUI/Compose/shengxing/lb_synthesis_conversion_star_05.dds", true, Texture2D);
	ui_star = RESOURCE_LOAD_NEW("LobbyUI/Compose/shengxing/lb_synthesis_conversion_ico_02.dds", true, Texture2D);

	for (int i = 0;i < 32; i++)
	{
		String file_name = String::Format("InGameUI/ig_namecard%d.dds",i+1);
		ui_common_name_cards[i] = RESOURCE_LOAD_NEW(file_name.Str(), true, Texture2D);
	}
	for (int i = 0;i < 32; i++)
	{
		String file_name = String::Format("InGameUI/tab/ig_tab_namecard%d.dds",i+1);
		ui_common_tab_name_cards[i] = RESOURCE_LOAD_NEW(file_name.Str(), true, Texture2D);
	}
	ui_common_vip_name_card = RESOURCE_LOAD_NEW("InGameUI/ig_namecard02.dds",true, Texture2D);
	ui_common_tab_vip_name_card[1] = RESOURCE_LOAD_NEW("LobbyUI/vip/vip/vip1.dds",true, Texture2D);
	ui_common_tab_vip_name_card[2] = RESOURCE_LOAD_NEW("LobbyUI/vip/vip/vip2.dds",true, Texture2D);
	ui_common_tab_vip_name_card[3] = RESOURCE_LOAD_NEW("LobbyUI/vip/vip/vip3.dds",true, Texture2D);
	ui_common_tab_vip_name_card[4] = RESOURCE_LOAD_NEW("LobbyUI/vip/vip/vip4.dds",true, Texture2D);
	ui_common_tab_vip_name_card[5] = RESOURCE_LOAD_NEW("LobbyUI/vip/vip/vip5.dds",true, Texture2D);
	ui_common_tab_vip_name_card[6] = RESOURCE_LOAD_NEW("LobbyUI/vip/vip/vip6.dds",true, Texture2D);
	ui_common_tab_vip_name_card[7] = RESOURCE_LOAD_NEW("LobbyUI/vip/vip/vip7.dds",true, Texture2D);
	ui_common_tab_vip_name_card[8] = RESOURCE_LOAD_NEW("LobbyUI/vip/vip/vip8.dds",true, Texture2D);
	ui_common_tab_vip_name_card[9] = RESOURCE_LOAD_NEW("LobbyUI/vip/vip/vip8.dds",true, Texture2D);
	WeaponKind[0] = RESOURCE_LOAD_NEW("InGameUI/arms_1.dds", true, Texture2D);
	WeaponKind[1] = RESOURCE_LOAD_NEW("InGameUI/arms_2.dds", true, Texture2D);
	WeaponKind[2] = RESOURCE_LOAD_NEW("InGameUI/arms_3.dds", true, Texture2D);
	WeaponKind[3] = RESOURCE_LOAD_NEW("InGameUI/maozi.dds", true, Texture2D);
	WeaponKind[4] = RESOURCE_LOAD_NEW("InGameUI/fuzhuang.dds", true, Texture2D);
	WeaponKind[5] = RESOURCE_LOAD_NEW("InGameUI/peishi.dds", true, Texture2D);
	WeaponBlank = RESOURCE_LOAD_NEW("InGameUI/synthesis_bar.dds", true, Texture2D);
	WeaponRed = RESOURCE_LOAD_NEW("InGameUI/synthesis_arms.dds", true, Texture2D);
	WeaponBlue = RESOURCE_LOAD_NEW("InGameUI/synthesis_deco.dds", true, Texture2D);

	addblood_tip[0] = RESOURCE_LOAD_NEW("InGameUI/UI_Borders_R01.dds", true, Texture2D);
	addblood_tip[1] = RESOURCE_LOAD_NEW("InGameUI/UI_Borders_B01.dds", true, Texture2D);

	all_tipBg[0] = RESOURCE_LOAD_NEW("InGameUI/ig_common_redbox.dds", true, Texture2D);
	all_tipBg[1] = RESOURCE_LOAD_NEW("InGameUI/ig_common_bluebox.dds", true, Texture2D);
	weapon_tipBg = RESOURCE_LOAD_NEW("InGameUI/ig_common_observation_bg_01.dds", true, Texture2D);

	ui_cure_icon[0] = RESOURCE_LOAD_NEW("InGameUI/ig_common_zhiliaoico1.dds", true, Texture2D);
	ui_cure_icon[1] = RESOURCE_LOAD_NEW("InGameUI/ig_common_zhiliaoico2.dds", true, Texture2D);

	ui_snipertarget[0] = RESOURCE_LOAD_NEW("InGameUI/ig_sniper_target_01.dds", true, Texture2D);
	ui_snipertarget[1] = RESOURCE_LOAD_NEW("InGameUI/ig_sniper_target_02.dds", true, Texture2D);
	ui_snipertarget[2] = RESOURCE_LOAD_NEW("InGameUI/ig_sniper_target_03.dds", true, Texture2D);

	ui_textures_kick_bg = RESOURCE_LOAD_NEW("InGameUI/kick/ig_tr_bg4.dds", true, Texture2D);
	ui_textures_kick_title = RESOURCE_LOAD_NEW("InGameUI/kick/ig_tr_bg3.dds", true, Texture2D);

	ui_window = RESOURCE_LOAD_NEW("InGameUI/ig_window.dds", true, Texture2D);
	ui_b = RESOURCE_LOAD_NEW("InGameUI/ig_keyboard_b.dds", true, Texture2D);
	ui_f = RESOURCE_LOAD_NEW("InGameUI/ig_keyboard_f.dds", true, Texture2D);
	ui_e = RESOURCE_LOAD_NEW("InGameUI/ig_keyboard_e.dds", true, Texture2D);
	ui_f9 = RESOURCE_LOAD_NEW("InGameUI/ig_keyboard_f9.dds", true, Texture2D);
	ui_camera = RESOURCE_LOAD_NEW("InGameUI/ig_common_cameraico.dds", true, Texture2D);
}

void InGameUINew::_InitSmallMapTextures()
{
	ui_smallmap_bg = RESOURCE_LOAD_NEW("InGameUI/ig_common_map_bg.dds", true, Texture2D);
	ui_smallmap_supply_bullet = RESOURCE_LOAD_NEW("InGameUI/ig_common_map_danyaoico.dds", true, Texture2D);
	ui_smallmap_supply_medkit = RESOURCE_LOAD_NEW("InGameUI/ig_common_map_danyaoico_full.dds", true, Texture2D);
	ui_smallmap_supply_tools = RESOURCE_LOAD_NEW("InGameUI/ig_common_map_hpico_full.dds", true, Texture2D);
	ui_smallmap_supply_commonzombie = RESOURCE_LOAD_NEW("InGameUI/ig_common_map_bujiico_full.dds", true, Texture2D);
	ui_smallmap_supply_hp = RESOURCE_LOAD_NEW("InGameUI/ig_common_map_hpico.dds", true, Texture2D);
	ui_smallmap_bomb_arrayA =  RESOURCE_LOAD_NEW("InGameUI/bomb/map_bomb_A_ico.dds", true, Texture2D);
	ui_smallmap_bomb_arrayB =  RESOURCE_LOAD_NEW("InGameUI/bomb/map_bomb_B_ico.dds", true, Texture2D);
	ui_smallmap_supply_item_special =  RESOURCE_LOAD_NEW("InGameUI/ig_common_map_item_special_man.dds", true, Texture2D);

	ui_smallmap_supply_item_ghost = RESOURCE_LOAD_NEW("InGameUI/ig_common_map_ghost.DDS", true, Texture2D);
	ui_smallmap_supply_item_snare = RESOURCE_LOAD_NEW("InGameUI/ig_common_map_snare.DDS", true, Texture2D);

}

void InGameUINew::_InitHitsImage()
{
	ui_hit_portrait = RESOURCE_LOAD_NEW("InGameUI/ig_common_hurt.dds", true, Texture2D);
}

void InGameUINew::_InitKillTextures()
{
	ui_kill_textures[0] = RESOURCE_LOAD_NEW("InGameUI/ig_kill_icon/ig_common_tubiao_putongjisha_1.dds", true, Texture2D);
	ui_kill_textures[1] = RESOURCE_LOAD_NEW("InGameUI/ig_kill_icon/ig_common_tubiao_putongjisha_2.dds", true, Texture2D);
	ui_kill_textures[2] = RESOURCE_LOAD_NEW("InGameUI/ig_kill_icon/ig_common_tubiao_putongjisha_3.dds", true, Texture2D);
	ui_kill_textures[3] = RESOURCE_LOAD_NEW("InGameUI/ig_kill_icon/ig_common_tubiao_putongjisha_4.dds", true, Texture2D);
	ui_kill_textures[4] = RESOURCE_LOAD_NEW("InGameUI/ig_kill_icon/ig_common_tubiao_putongjisha_5.dds", true, Texture2D);
	ui_kill_textures[5] = RESOURCE_LOAD_NEW("InGameUI/ig_kill_icon/ig_common_tubiao_jinshenjisha.dds", true, Texture2D);
	ui_kill_textures[6] = RESOURCE_LOAD_NEW("InGameUI/ig_kill_icon/ig_common_tubiao_baotoujisha.dds", true, Texture2D);
	ui_kill_textures[7] = RESOURCE_LOAD_NEW("InGameUI/ig_kill_icon/ig_common_tubiao_fuchou.dds", true, Texture2D);
	ui_kill_textures[8] = RESOURCE_LOAD_NEW("InGameUI/ig_kill_icon/ig_common_tubiao_baoji.dds", true, Texture2D);
	ui_kill_textures[9] = RESOURCE_LOAD_NEW("InGameUI/ig_kill_icon/ig_common_tubiao_kongzhi.dds", true, Texture2D);
	ui_kill_textures[10] = RESOURCE_LOAD_NEW("InGameUI/ig_kill_icon/ig_common_tubiao_yujin.dds", true, Texture2D);

	ui_kill_textures[11] = RESOURCE_LOAD_NEW("InGameUI/ig_kill_icon/ig_common_killmark_nurse_1.dds", true, Texture2D);
	ui_kill_textures[12] = RESOURCE_LOAD_NEW("InGameUI/ig_kill_icon/ig_common_killmark_nurse_2.dds", true, Texture2D);
	ui_kill_textures[13] = RESOURCE_LOAD_NEW("InGameUI/ig_kill_icon/ig_common_killmark_nurse_3.dds", true, Texture2D);
	ui_kill_textures[14] = RESOURCE_LOAD_NEW("InGameUI/ig_kill_icon/ig_common_killmark_nurse_4.dds", true, Texture2D);
	ui_kill_textures[15] = RESOURCE_LOAD_NEW("InGameUI/ig_kill_icon/ig_common_killmark_nurse_5.dds", true, Texture2D);

	ui_kill_textures[16] = RESOURCE_LOAD_NEW("InGameUI/bomb/ig_common_tubiao_zhuangdan.dds", true, Texture2D);
	ui_kill_textures[17] = RESOURCE_LOAD_NEW("InGameUI/bomb/ig_common_tubiao_chaidan.dds", true, Texture2D);
	ui_kill_textures[18] = RESOURCE_LOAD_NEW("InGameUI/ig_kill_icon/killhero.dds", true, Texture2D);

	ui_kill_textures[19] = RESOURCE_LOAD_NEW("InGameUI/ig_kill_icon/ig_re_tubiao_hit.dds", true, Texture2D);
	ui_kill_textures[20] = RESOURCE_LOAD_NEW("InGameUI/ig_kill_icon/ig_re_tubiao_jiangshijisha.dds", true, Texture2D);
	ui_kill_textures[21] = RESOURCE_LOAD_NEW("InGameUI/ig_kill_icon/ig_re_tubiao_kill.dds", true, Texture2D);
	ui_kill_textures[22] = RESOURCE_LOAD_NEW("InGameUI/ig_kill_icon/ig_re_tubiao_knockdown.dds", true, Texture2D);
	ui_kill_textures[23] = RESOURCE_LOAD_NEW("InGameUI/ig_kill_icon/ig_duqi_tubiao_1.dds", true, Texture2D);
	ui_kill_textures[24] = RESOURCE_LOAD_NEW("InGameUI/ig_kill_icon/ig_re_tubiao_skillknockdown.dds", true, Texture2D);
	ui_kill_textures[25] = RESOURCE_LOAD_NEW("InGameUI/ig_kill_icon/ig_common_tubiao_killboss.dds", true, Texture2D);
	ui_kill_textures[26] = RESOURCE_LOAD_NEW("InGameUI/ig_kill_icon/ig_zb2_tubiao_1.dds", true, Texture2D);
	ui_kill_textures[27] = RESOURCE_LOAD_NEW("InGameUI/ig_kill_icon/ig_zb2_tubiao_2.dds", true, Texture2D);
	ui_kill_textures[28] = RESOURCE_LOAD_NEW("InGameUI/ig_kill_icon/ig_zb2_tubiao_3.dds", true, Texture2D);
	ui_kill_textures[29] = RESOURCE_LOAD_NEW("InGameUI/ig_kill_icon/ig_zb2_tubiao_4.dds", true, Texture2D);
	ui_kill_textures[30] = RESOURCE_LOAD_NEW("InGameUI/ig_kill_icon/ig_zb2_tubiao_5.dds", true, Texture2D);
	ui_kill_textures[31] = RESOURCE_LOAD_NEW("InGameUI/ig_kill_icon/ig_common_tubiao_killboss1.dds", true, Texture2D);
	ui_kill_textures[32] = RESOURCE_LOAD_NEW("InGameUI/ig_kill_icon/ig_common_tubiao_boss1_dps1000.dds", true, Texture2D);
	ui_kill_textures[33] = RESOURCE_LOAD_NEW("InGameUI/ig_kill_icon/ig_re_tubiao_disappear.dds", true, Texture2D);
	ui_kill_textures[34] = RESOURCE_LOAD_NEW("InGameUI/ig_kill_icon/ig_re_tubiao_drug.dds", true, Texture2D);
	ui_kill_textures[35] = RESOURCE_LOAD_NEW("InGameUI/ig_kill_icon/ig_re_tubiao_charge.dds", true, Texture2D);


	ui_kill_textures_num = RESOURCE_LOAD_NEW("InGameUI/ig_kill_icon/ig_common_tubiao_number.dds", true, Texture2D);
	ui_die_bg = RESOURCE_LOAD_NEW("InGameUI/ig_common_jindutiao_bg.dds", true, Texture2D);
	ui_die = RESOURCE_LOAD_NEW("InGameUI/ig_common_jindutiao_content.dds", true, Texture2D);
}

void InGameUINew::_InitAnimSprite()
{
	//kill_anim_icon.position = Vector3(0, 0, 0);
	//kill_anim_icon.rotation = 0;
	//kill_anim_icon.scale_spline.AddPoint(0,		0, 0, 0, 2);
	//kill_anim_icon.scale_spline.AddPoint(0.15f,	2.0f, 0, 0, 2);
	//kill_anim_icon.scale_spline.AddPoint(0.19f,	1.0f, 0, 0, 2);
	//kill_anim_icon.alpha_spline.AddPoint(1.5f,	1, 0, 0, 2);
	//kill_anim_icon.alpha_spline.AddPoint(1.6f,	0, 0, 0, 2);

	kill_anim_icon.position = Vector3(0, 0, 0);
	kill_anim_icon.rotation = 0;
	kill_anim_icon.scale_spline.AddPoint(0,		2.f, 0, 0, 2);
	kill_anim_icon.scale_spline.AddPoint(0.15f,	0.5f, 0, 0, 2);
	kill_anim_icon.scale_spline.AddPoint(0.20f,	1.f, 0, 0, 2);
	kill_anim_icon.alpha_spline.AddPoint(1.5f,	1, 0, 0, 2);
	kill_anim_icon.alpha_spline.AddPoint(1.6f,	0, 0, 0, 2);

	score_anim.position = Vector3(0, 0, 0);
	score_anim.rotation = 0;
	score_anim.scale_spline.AddPoint(0,		0.003f, 0, 0, 2);
	score_anim.scale_spline.AddPoint(0.1f,	0.006f, 0, 0, 2);
	score_anim.scale_spline.AddPoint(0.2f,	0.004f, 0, 0, 2);
	score_anim.scale_spline.AddPoint(0.3f,	0.003f, 0, 0, 2);

	novice_anim.position = Vector3(0, 0, 0);
	novice_anim.rotation = 0;
	novice_anim.scale_spline.AddPoint(0,	0.003f, 0, 0, 2);
	novice_anim.scale_spline.AddPoint(0.15f,	2.0f, 0, 0, 2);
	novice_anim.scale_spline.AddPoint(0.19f,	1.0f, 0, 0, 2);
	novice_anim.scale_spline.AddPoint(0.3f,		1.0f, 0, 0, 2);
	novice_anim.scale_spline.AddPoint(10.0f,	1.0f, 0, 0, 2);

	win_anim.position = Vector3(0, 0, 0);
	win_anim.rotation = 0;
	win_anim.scale_spline.AddPoint(0.15f,	2.0f, 0, 0, 2);
	win_anim.scale_spline.AddPoint(0.19f,	1.4f, 0, 0, 2);
	win_anim.scale_spline.AddPoint(0.3f,	1.0f, 0, 0, 2);
	win_anim.scale_spline.AddPoint(20.0f,	1.0f, 0, 0, 2);

	kill_anim_icon_num[0].position = Vector3(0.22f, 0.f, 0.f);
	kill_anim_icon_num[0].rotation = 0;
	kill_anim_icon_num[0].scale_spline.AddPoint(0,		2, 0, 0, 2);
	kill_anim_icon_num[0].scale_spline.AddPoint(0.15f,	0.5f, 0, 0, 2);
	kill_anim_icon_num[0].scale_spline.AddPoint(0.20f,	1.0f, 0, 0, 2);
	kill_anim_icon_num[0].alpha_spline.AddPoint(1.5f,	1, 0, 0, 2);
	kill_anim_icon_num[0].alpha_spline.AddPoint(1.6f,	0, 0, 0, 2);

	kill_anim_icon_num[1].position = Vector3(0.32f, 0.f, 0.f);
	kill_anim_icon_num[1].rotation = 0;
	kill_anim_icon_num[1].scale_spline.AddPoint(0,		2, 0, 0, 2);
	kill_anim_icon_num[1].scale_spline.AddPoint(0.15f,	0.5f, 0, 0, 2);
	kill_anim_icon_num[1].scale_spline.AddPoint(0.20f,	1.0f, 0, 0, 2);
	kill_anim_icon_num[1].alpha_spline.AddPoint(1.5f,	1, 0, 0, 2);
	kill_anim_icon_num[1].alpha_spline.AddPoint(1.6f,	0, 0, 0, 2);
}

void InGameUINew::_InitTabShow()
{
	ui_tab_red = RESOURCE_LOAD_NEW("InGameUI/tab/ig_tab_bg1_u_r.dds", true, Texture2D);
	ui_tab_red_boss = RESOURCE_LOAD_NEW("InGameUI/tab/ig_tab_bg1_d_g.dds", true, Texture2D); 
	ui_tab_center = RESOURCE_LOAD_NEW("InGameUI/tab/ig_tab_bg1_m.dds", true, Texture2D);
	ui_tab_center_boss = RESOURCE_LOAD_NEW("InGameUI/tab/ig_boss_tab_bg1_m.dds", true, Texture2D);
	ui_tab_center_zombie = RESOURCE_LOAD_NEW("InGameUI/tab/ig_re_tab_bg1_m.dds", true, Texture2D);
	ui_tab_blue = RESOURCE_LOAD_NEW("InGameUI/tab/ig_tab_bg1_d_b.dds", true, Texture2D);
	ui_tab_gray_boss = RESOURCE_LOAD_NEW("InGameUI/tab/ig_tab_bg1_u_h.dds", true, Texture2D);
	ui_tab_gray_zombie = RESOURCE_LOAD_NEW("InGameUI/tab/ig_tab_bg_re.dds", true, Texture2D);
	ui_tab_watch = RESOURCE_LOAD_NEW("InGameUI/tab/ig_tab_bg_guancha.dds", true, Texture2D);
	ui_tab_zombie_watch = RESOURCE_LOAD_NEW("InGameUI/tab/lb_rank_bg_02.dds", true, Texture2D);
	ui_tab_zombie_hp_bg = RESOURCE_LOAD_NEW("InGameUI/tab/ig_re_bar_bg_02.dds", true, Texture2D);
	ui_tab_BossPVE_bg = RESOURCE_LOAD_NEW("InGameUI/tab/ig_bo2_tab_bg1_d_g.dds", true, Texture2D);

	ui_tab_bottom = RESOURCE_LOAD_NEW("InGameUI/tab/ig_tab_bg1_d_w.dds", true, Texture2D);
	ig_tab_bg2 = RESOURCE_LOAD_NEW("InGameUI/tab/ig_tab_bg2.dds", true, Texture2D);
	ig_tab_win_num = RESOURCE_LOAD_NEW("InGameUI/lb_summary_number_r_1.dds", true, Texture2D);
	ig_tab_lose_num = RESOURCE_LOAD_NEW("InGameUI/lb_summary_number_r_3.dds", true, Texture2D);
	ig_tab_line = RESOURCE_LOAD_NEW("InGameUI/tab/ig_tab_line.dds", true, Texture2D);
	ig_tab_level = RESOURCE_LOAD_NEW("InGameUI/tab/lb_summary_number_7b.dds", true, Texture2D);
	ig_tab_vip[0] = RESOURCE_LOAD_NEW("LobbyUI/vip/vip/VIP_button_01_normal.dds", true, Texture2D);
	ig_tab_vip[1] = RESOURCE_LOAD_NEW("LobbyUI/vip/vip/VIP_button_02_normal.dds", true, Texture2D);
	ig_tab_vip[2] = RESOURCE_LOAD_NEW("LobbyUI/vip/vip/VIP_button_03_normal.dds", true, Texture2D);
	ig_tab_vip[3] = RESOURCE_LOAD_NEW("LobbyUI/vip/vip/VIP_button_04_normal.dds", true, Texture2D);
	ig_tab_vip[4] = RESOURCE_LOAD_NEW("LobbyUI/vip/vip/VIP_button_05_normal.dds", true, Texture2D);
	ig_tab_vip[5] = RESOURCE_LOAD_NEW("LobbyUI/vip/vip/VIP_button_06_normal.dds", true, Texture2D);
	ig_tab_vip[6] = RESOURCE_LOAD_NEW("LobbyUI/vip/vip/VIP_button_07_normal.dds", true, Texture2D);
	ig_tab_vip[7] = RESOURCE_LOAD_NEW("LobbyUI/vip/vip/VIP_button_08_normal.dds", true, Texture2D);
	ig_tab_vip[8] = RESOURCE_LOAD_NEW("LobbyUI/vip/vip/VIP_button_08_normal.dds", true, Texture2D);

	ig_tab_match[0]  = RESOURCE_LOAD_NEW("LobbyUI/pipei/icon_rank00.dds", true, Texture2D);
	ig_tab_match[1]  = RESOURCE_LOAD_NEW("LobbyUI/pipei/icon_rank01_1X.dds", true, Texture2D);
	ig_tab_match[2]  = RESOURCE_LOAD_NEW("LobbyUI/pipei/icon_rank01_2X.dds", true, Texture2D);
	ig_tab_match[3]  = RESOURCE_LOAD_NEW("LobbyUI/pipei/icon_rank01_3X.dds", true, Texture2D);
	ig_tab_match[4]  = RESOURCE_LOAD_NEW("LobbyUI/pipei/icon_rank02_1X.dds", true, Texture2D);
	ig_tab_match[5]  = RESOURCE_LOAD_NEW("LobbyUI/pipei/icon_rank02_2X.dds", true, Texture2D);
	ig_tab_match[6]  = RESOURCE_LOAD_NEW("LobbyUI/pipei/icon_rank02_3X.dds", true, Texture2D);
	ig_tab_match[7]  = RESOURCE_LOAD_NEW("LobbyUI/pipei/icon_rank03_1X.dds", true, Texture2D);
	ig_tab_match[8]  = RESOURCE_LOAD_NEW("LobbyUI/pipei/icon_rank03_2X.dds", true, Texture2D);
	ig_tab_match[9]  = RESOURCE_LOAD_NEW("LobbyUI/pipei/icon_rank03_3X.dds", true, Texture2D);
	ig_tab_match[10] = RESOURCE_LOAD_NEW("LobbyUI/pipei/icon_rank04_1X.dds", true, Texture2D);
	ig_tab_match[11] = RESOURCE_LOAD_NEW("LobbyUI/pipei/icon_rank04_2X.dds", true, Texture2D);
	ig_tab_match[12] = RESOURCE_LOAD_NEW("LobbyUI/pipei/icon_rank04_3X.dds", true, Texture2D);
	ig_tab_match[13] = RESOURCE_LOAD_NEW("LobbyUI/pipei/icon_rank05_3X.dds", true, Texture2D);




	//ig_tab_xunleivip = RESOURCE_LOAD_NEW("LobbyUI/vip/lb_2_ico_0.dds", true, Texture2D);
}

void InGameUINew::_InitNovice()
{
	ui_novice_person_bg[0] = NullPtr;
	ui_novice_person_bg[1] = RESOURCE_LOAD_NEW("InGameUI/novice/ig_training_heiban_huojianbing.dds", true, Texture2D);
	ui_novice_person_bg[2] = RESOURCE_LOAD_NEW("InGameUI/novice/ig_training_heiban_jiqiangbing.dds", true, Texture2D);
	ui_novice_person_bg[3] = RESOURCE_LOAD_NEW("InGameUI/novice/ig_training_heiban_ol.dds", true, Texture2D);
	ui_novice_person_bg[4] = RESOURCE_LOAD_NEW("InGameUI/novice/ig_training_heiban_tujibing.dds", true, Texture2D);
	ui_novice_person_bg[5] = RESOURCE_LOAD_NEW("InGameUI/novice/ig_training_heiban_penhuobing.dds", true, Texture2D);
	ui_novice_tip_bg = RESOURCE_LOAD_NEW("InGameUI/novice/ig_training_bg.dds", true, Texture2D);
	ui_novice_mouse = RESOURCE_LOAD_NEW("InGameUI/novice/ig_training_mouse.dds", true, Texture2D);
	ui_novice_mouse_R = RESOURCE_LOAD_NEW("InGameUI/novice/ig_training_mouse_sg_R.dds", true, Texture2D);
	ui_novice_leftright = RESOURCE_LOAD_NEW("InGameUI/novice/ig_training_jiantou.dds", true, Texture2D);
	ui_novice_leftright_light = RESOURCE_LOAD_NEW("InGameUI/novice/ig_training_jiantou_shanguang.dds", true, Texture2D); 
	ui_novice_gks_bg = RESOURCE_LOAD_NEW("InGameUI/novice/ig_training_gks_bg.dds", true, Texture2D); 
	ui_novice_gks_down = RESOURCE_LOAD_NEW("InGameUI/novice/ig_training_gks_down.dds", true, Texture2D); 
	ui_novice_keyboard_bg = RESOURCE_LOAD_NEW("InGameUI/novice/ig_training_keyboard_bg.dds", true, Texture2D);
	ui_novice_keyboard = RESOURCE_LOAD_NEW("InGameUI/novice/ig_training_keyboard.dds", true, Texture2D);
	ui_novice_keyboard_guang = RESOURCE_LOAD_NEW("InGameUI/novice/ig_training_keyboard_shanguang.dds", true, Texture2D);
	ui_novice_number = RESOURCE_LOAD_NEW("InGameUI/novice/ig_training_number.dds", true, Texture2D);
	ui_novice_space = RESOURCE_LOAD_NEW("InGameUI/novice/ig_training_keyboard_speace.dds", true, Texture2D);
	ui_novice_space_guang = RESOURCE_LOAD_NEW("InGameUI/novice/ig_training_keyboard_speace_sg.dds", true, Texture2D); 
	ui_novice_wheel = RESOURCE_LOAD_NEW("InGameUI/novice/ig_training_jiantou_2.dds", true, Texture2D); 
	ui_novice_wheel_light = RESOURCE_LOAD_NEW("InGameUI/novice/ig_training_jiantou_2_shanhuang.dds", true, Texture2D); 
	ui_novice_jiantou_3 = RESOURCE_LOAD_NEW("InGameUI/novice/ig_training_jiantou_3.dds", true, Texture2D); 
	ui_novice_jiantou_3light = RESOURCE_LOAD_NEW("InGameUI/novice/ig_training_jiantou_3_shanguang.dds", true, Texture2D); 
	ui_novice_biaoji_bg = RESOURCE_LOAD_NEW("InGameUI/novice/ig_training_biaoji_bg.dds", true, Texture2D); 
	ui_novice_biaoji_point = RESOURCE_LOAD_NEW("InGameUI/novice/ig_training_point.dds", true, Texture2D); 
	ui_novice_guang = RESOURCE_LOAD_NEW("InGameUI/novice/ig_training_end_sg.dds", true, Texture2D); 
	ui_novice_pass = RESOURCE_LOAD_NEW("InGameUI/novice/ig_training_end_gxgg.dds", true, Texture2D); 
}

void InGameUINew::_InitBombInfo()
{
	ui_bomb_defuse_course = RESOURCE_LOAD_NEW("InGameUI/bomb/ig_bomb_bar_bg.dds", true, Texture2D);
	ui_bomb_defuse_course_In = RESOURCE_LOAD_NEW("InGameUI/bomb/ig_bomb_bar.dds", true, Texture2D);
	ui_bomb_defuse_course_Point = RESOURCE_LOAD_NEW("InGameUI/bomb/ig_bomb_bar_ico.dds", true, Texture2D);
	ui_bomb_ico = RESOURCE_LOAD_NEW("InGameUI/bomb/ig_bomb_ico_1.dds", true, Texture2D);
	ui_bomb_ico_flash = RESOURCE_LOAD_NEW("InGameUI/bomb/ig_bomb_ico_flash.dds", true, Texture2D);
	ui_bomb_Text_Planting = RESOURCE_LOAD_NEW("InGameUI/bomb/map_bomb_ico_02.dds", true, Texture2D);
	ui_bomb_Text_Defusing = RESOURCE_LOAD_NEW("InGameUI/bomb/map_bomb_ico_03.dds", true, Texture2D);
}
void InGameUINew::_InitZombieInfo()
{
	ui_zombie_poeple_bar_icon = RESOURCE_LOAD_NEW("InGameUI/bottom_info/ig_re_bar_ico.dds", true, Texture2D);
	ui_zombie_poeple_hp_bar = RESOURCE_LOAD_NEW("InGameUI/bottom_info/ig_re_bar.dds", true, Texture2D);
	ui_zombie_number_comma = RESOURCE_LOAD_NEW("InGameUI/bottom_info/ig_re_number_01.dds", true, Texture2D);
	ui_zombie_time_number = RESOURCE_LOAD_NEW("InGameUI/bottom_info/ig_re_number_02.dds", true, Texture2D);
	//ui_zombie_text = RESOURCE_LOAD_NEW("InGameUI/bottom_info/ig_re_text_01.dds", true, Texture2D);
}

void InGameUINew::_InitCommonZombieInfo()
{
	ui_commonzombie_Corpse_Mum[0] = RESOURCE_LOAD_NEW("InGameUI/CommomZombie/ig_zombiev2_avatar_mother_lv1.dds", true, Texture2D);
	ui_commonzombie_Corpse_Mum[1] = RESOURCE_LOAD_NEW("InGameUI/CommomZombie/ig_zombiev2_avatar_mother_lv2.dds", true, Texture2D);
	ui_commonzombie_Corpse_Mum[2] = RESOURCE_LOAD_NEW("InGameUI/CommomZombie/ig_zombiev2_avatar_mother_lv3.dds", true, Texture2D);
	ui_commonzombie_Corpse_Mum_Disable[0] = RESOURCE_LOAD_NEW("InGameUI/CommomZombie/ig_zombiev2_avatar_mother_lv1_disabled.dds", true, Texture2D);	
	ui_commonzombie_Corpse_Mum_Disable[1] = RESOURCE_LOAD_NEW("InGameUI/CommomZombie/ig_zombiev2_avatar_mother_lv2_disabled.dds", true, Texture2D);	
	ui_commonzombie_Corpse_Mum_Disable[2] = RESOURCE_LOAD_NEW("InGameUI/CommomZombie/ig_zombiev2_avatar_mother_lv3_disabled.dds", true, Texture2D);
	ui_commonzombie_Corpse_Child[0] = RESOURCE_LOAD_NEW("InGameUI/CommomZombie/ig_zombiev2_avatar_general_lv1.dds", true, Texture2D);
	ui_commonzombie_Corpse_Child[1] = RESOURCE_LOAD_NEW("InGameUI/CommomZombie/ig_zombiev2_avatar_general_lv2.dds", true, Texture2D);
	ui_commonzombie_Corpse_Child[2] = RESOURCE_LOAD_NEW("InGameUI/CommomZombie/ig_zombiev2_avatar_general_lv3.dds", true, Texture2D);
	ui_commonzombie_Corpse_Child_Disable[0] = RESOURCE_LOAD_NEW("InGameUI/CommomZombie/ig_zombiev2_avatar_general_lv1_disabled.dds", true, Texture2D);
	ui_commonzombie_Corpse_Child_Disable[1] = RESOURCE_LOAD_NEW("InGameUI/CommomZombie/ig_zombiev2_avatar_general_lv2_disabled.dds", true, Texture2D);
	ui_commonzombie_Corpse_Child_Disable[2] = RESOURCE_LOAD_NEW("InGameUI/CommomZombie/ig_zombiev2_avatar_general_lv3_disabled.dds", true, Texture2D);
	ui_commonzombie_Shine[0] = RESOURCE_LOAD_NEW("InGameUI/CommomZombie/ig_zombiev2_lvbar_light.dds", true, Texture2D);
	ui_commonzombie_Shine[1] = RESOURCE_LOAD_NEW("InGameUI/CommomZombie/ig_zombiev2_lvbar_v2_light.dds", true, Texture2D);
	ui_commonzombie_bottom_bg = RESOURCE_LOAD_NEW("InGameUI/CommomZombie/ig_zombiev2_lvbar_bg.dds", true, Texture2D);
	ui_commonzombie_bottom_bf[0] = RESOURCE_LOAD_NEW("InGameUI/CommomZombie/ig_zombiev2_lvbar_content.dds", true, Texture2D);
	ui_commonzombie_bottom_bf[1] = RESOURCE_LOAD_NEW("InGameUI/CommomZombie/ig_zombiev2_lvbar_v2_content.dds", true, Texture2D);
	ui_commonzombie_bottom_warning = RESOURCE_LOAD_NEW("LobbyUI/mokuai_title02.dds", true, Texture2D);
	ui_commonzombie_head_bg = RESOURCE_LOAD_NEW("InGameUI/CommomZombie/ig_zombiev2_ldentifies_bg.dds", true, Texture2D);
	ui_commonzombie_bottom_Corpse = RESOURCE_LOAD_NEW("InGameUI/CommomZombie/ig_zombiev2_ldentifies_ico_zombie.dds", true, Texture2D);
	ui_commonzombie_bottom_Corpse_ico = RESOURCE_LOAD_NEW("InGameUI/CommomZombie/ig_zombiev2_ldentifies_light_zombie.dds", true, Texture2D);
	ui_commonzombie_bottom_People = RESOURCE_LOAD_NEW("InGameUI/CommomZombie/ig_zombiev2_ldentifies_ico_human.dds", true, Texture2D);
	ui_commonzombie_bottom_People_ico = RESOURCE_LOAD_NEW("InGameUI/CommomZombie/ig_zombiev2_ldentifies_light_human.dds", true, Texture2D);
	ui_commonzombie_Skill_bg = RESOURCE_LOAD_NEW("InGameUI/CommomZombie/ig_zombiev2_box_01.dds", true, Texture2D);
	ui_commonzombie_Skill_bf = RESOURCE_LOAD_NEW("InGameUI/CommomZombie/ig_zombiev2_box_cd.dds", true, Texture2D);
	ui_commonzombie_Skill_Shine = RESOURCE_LOAD_NEW("InGameUI/CommomZombie/ig_zombiev2_box_cd_light.dds", true, Texture2D);

	ui_commonzombie_Skill_ico[0] = RESOURCE_LOAD_NEW("InGameUI/CommomZombie/ig_zombiev2_skill_ico_09.dds", true, Texture2D);
	ui_commonzombie_Skill_ico[1] = RESOURCE_LOAD_NEW("InGameUI/CommomZombie/ig_zombiev2_skill_ico_08.dds", true, Texture2D);
	ui_commonzombie_Skill_ico[2] = RESOURCE_LOAD_NEW("InGameUI/CommomZombie/ig_zombiev2_skill_ico_07.dds", true, Texture2D);
	ui_commonzombie_Skill_ico[3] = RESOURCE_LOAD_NEW("InGameUI/CommomZombie/ig_zombiev2_skill_ico_04.dds", true, Texture2D);
	ui_commonzombie_Skill_ico[4] = RESOURCE_LOAD_NEW("InGameUI/CommomZombie/ig_zombiev2_skill_ico_05.dds", true, Texture2D);
	ui_commonzombie_Skill_ico[5] = RESOURCE_LOAD_NEW("InGameUI/CommomZombie/ig_zombiev2_skill_ico_01.dds", true, Texture2D);
	ui_commonzombie_Skill_ico[6] = RESOURCE_LOAD_NEW("InGameUI/CommomZombie/ig_zombiev2_skill_ico_02.dds", true, Texture2D);
	ui_commonzombie_Skill_ico[7] = RESOURCE_LOAD_NEW("InGameUI/CommomZombie/ig_zombiev2_skill_ico_03.dds", true, Texture2D);
	ui_commonzombie_Skill_ico[8] = RESOURCE_LOAD_NEW("InGameUI/CommomZombie/ig_zombiev2_skill_ico_06.dds", true, Texture2D);
	ui_commonzombie_Skill_ico[9] = RESOURCE_LOAD_NEW("InGameUI/boss_mode2/ig_boss1_v2_skill_ico_01.dds", true, Texture2D);
	ui_commonzombie_Skill_ico[10] = RESOURCE_LOAD_NEW("InGameUI/boss_mode2/ig_boss1_v2_skill_ico_12.dds", true, Texture2D);

	ui_commonzombie_People_bottom_bg = RESOURCE_LOAD_NEW("InGameUI/CommomZombie/ig_zombiev2_bar_02_bg.dds", true, Texture2D);
	ui_commonzombie_People_bottom_energy_f = RESOURCE_LOAD_NEW("InGameUI/CommomZombie/ig_bo2_timer_hp.dds", true, Texture2D);
	ui_commonzombie_People_bottom_energy_shine = RESOURCE_LOAD_NEW("InGameUI/CommomZombie/ig_bo2_timer_hp_light.dds", true, Texture2D);
	ui_commonzombie_Key_E = RESOURCE_LOAD_NEW("InGameUI/CommomZombie/ig_zombiev2_ico_e.dds", true, Texture2D);
	ui_commonzombie_Key_G = RESOURCE_LOAD_NEW("InGameUI/CommomZombie/ig_zombiev2_ico_g.dds", true, Texture2D);
	ui_commonzombie_People_hp_bg = RESOURCE_LOAD_NEW("InGameUI/CommomZombie/ig_zombiev2_hp_01.dds", true, Texture2D);
	ui_commonzombie_People_hp_bf = RESOURCE_LOAD_NEW("InGameUI/CommomZombie/ig_zombiev2_hp_01_content.dds", true, Texture2D);
	ui_commonzombie_dying_bg = RESOURCE_LOAD_NEW("InGameUI/CommomZombie/ig_zombiev2_bg01.dds", true, Texture2D);
	ui_commonzombie_Level_up = RESOURCE_LOAD_NEW("InGameUI/CommomZombie/ig_bo2_lvevelup_ico.dds", true, Texture2D);
}

void InGameUINew::_InitBoss2Info()
{
	ui_Boss2_die =  RESOURCE_LOAD_NEW("InGameUI/boss_two/ig_bo2_teammate_bg_die_ico.dds", true, Texture2D);
	ui_Boss2_Back =  RESOURCE_LOAD_NEW("InGameUI/boss_two/ig_bo2_teammate_bg_normal.dds", true, Texture2D);
	ui_Boss2_DieBack =  RESOURCE_LOAD_NEW("InGameUI/boss_two/ig_bo2_teammate_bg_disabled.dds", true, Texture2D);
	ui_head_info_bg_Boss2 = RESOURCE_LOAD_NEW("InGameUI/boss_two/ig_bo2_timer_bg.dds", true, Texture2D);
	ui_head_info_bg_Bos_hp = RESOURCE_LOAD_NEW("InGameUI/boss_two/ig_bo2_timer_hp.dds", true, Texture2D);
	ui_head_info_bg_Bos_hp_bg = RESOURCE_LOAD_NEW("InGameUI/boss_two/ig_bo2_timer_hp_bg.dds", true, Texture2D);
	ui_head_info_bg_Bos_time_bg = RESOURCE_LOAD_NEW("InGameUI/boss_two/ig_bo2_timer_stage_bg.dds", true, Texture2D);
	ui_head_info_bg_Bos_whop = RESOURCE_LOAD_NEW("InGameUI/boss_two/ig_bo2_timer_stage_complete.dds", true, Texture2D);
	ui_head_info_bg_Bos_Now_First = RESOURCE_LOAD_NEW("InGameUI/boss_two/ig_bo2_timer_stage_current_02.dds", true, Texture2D);
	ui_head_info_bg_Bos_Now = RESOURCE_LOAD_NEW("InGameUI/boss_two/ig_bo2_timer_stage_current_01.dds", true, Texture2D);
	ui_head_info_bg_Bos_Lock = RESOURCE_LOAD_NEW("InGameUI/boss_two/ig_bo2_timer_stage_current_ico.dds", true, Texture2D);
}

void InGameUINew::_InitBossmode2Info()
{
	ui_Boss_mode2_box_life = RESOURCE_LOAD_NEW("InGameUI/boss_mode2/ig_boss1_box1_a.dds", true, Texture2D);
	ui_Boss_mode2_box_die = RESOURCE_LOAD_NEW("InGameUI/boss_mode2/ig_boss1_box1_b.dds", true, Texture2D);
	ui_Boss_mode2_Boss = RESOURCE_LOAD_NEW("InGameUI/boss_mode2/ig_boss1_ldentifies_ico_zombie.dds", true, Texture2D);
	ui_head_info_round_boss_number = RESOURCE_LOAD_NEW("InGameUI/boss_mode2/ig_boss1_number_01.dds", true, Texture2D);
	ui_head_info_round_boss_number_r = RESOURCE_LOAD_NEW("InGameUI/boss_mode2/ig_boss1_number_01_b.dds", true, Texture2D);
	ui_Boss_mode2_HP_up_bg = RESOURCE_LOAD_NEW("InGameUI/boss_mode2/ig_boss1_bg3.dds", true, Texture2D);
	ui_Boss_mode2_HP_bg = RESOURCE_LOAD_NEW("InGameUI/boss_mode2/ig_boss1_hpbar_bg.dds", true, Texture2D);
	ui_Boss_mode2_HP_bf = RESOURCE_LOAD_NEW("InGameUI/boss_mode2/ig_boss1_hpbar_content.dds", true, Texture2D);
	ui_Boss_mode2_HP_bf_r = RESOURCE_LOAD_NEW("InGameUI/boss_mode2/ig_boss1_hpbar_content_r.dds", true, Texture2D);
	ui_Boss_mode2_HP_small_bg = RESOURCE_LOAD_NEW("InGameUI/boss_mode2/ig_boss1_hpbar_bg_small.dds", true, Texture2D);
	ui_Boss_mode2_HP_small_bf = RESOURCE_LOAD_NEW("InGameUI/boss_mode2/ig_boss1_hpbar_content_small.dds", true, Texture2D);
	ui_Boss_mode2_HP_small_bf_r = RESOURCE_LOAD_NEW("InGameUI/boss_mode2/ig_boss1_hpbar_content_small_r.dds", true, Texture2D);
	ui_Boss_mode2_boss_weapon_bg = RESOURCE_LOAD_NEW("InGameUI/boss_mode2/ig_boss1_bg4.dds", true, Texture2D);
	ui_Boss_mode2_boss_weapon_bg_down = RESOURCE_LOAD_NEW("InGameUI/boss_mode2/ig_boss1_bg4_down.dds", true, Texture2D);
	ui_Boss_mode2_boss_weapon_disable_bg = RESOURCE_LOAD_NEW("InGameUI/boss_mode2/ig_boss1_ico_01.dds", true, Texture2D);
	ui_Boss_mode2_boss_weapon1 = RESOURCE_LOAD_NEW("InGameUI/boss_mode2/boss01wep01.tga", true, Texture2D);
	ui_Boss_mode2_boss_weapon2 = RESOURCE_LOAD_NEW("InGameUI/boss_mode2/boss01wep02.tga", true, Texture2D);
	ui_Boss_mode2_boss_defense_bg = RESOURCE_LOAD_NEW("InGameUI/boss_mode2/ig_boss1_kangxingbar_bg.dds", true, Texture2D);
	ui_Boss_mode2_boss_defense = RESOURCE_LOAD_NEW("InGameUI/boss_mode2/ig_boss1_kangxingbar_content.dds", true, Texture2D);
	ui_Boss_mode2_boss_ammo_icon = RESOURCE_LOAD_NEW("InGameUI/boss_mode2/ig_boss1_ico_02.dds", true, Texture2D);
	ui_Boss_mode2_boss_fuel_bg = RESOURCE_LOAD_NEW("InGameUI/boss_mode2/ig_boss1_ranliaobar_bg.dds", true, Texture2D);
	ui_Boss_mode2_boss_fuel = RESOURCE_LOAD_NEW("InGameUI/boss_mode2/ig_boss1_ranliaobar_content.dds", true, Texture2D);
	ui_Boss_mode2_person_energy_Lv = RESOURCE_LOAD_NEW("InGameUI/boss_mode2/ig_boss1_bg1.dds", true, Texture2D);
	ui_Boss_mode2_person_energy_bg = RESOURCE_LOAD_NEW("InGameUI/boss_mode2/ig_boss1_lvbar_bg.dds", true, Texture2D);
	ui_Boss_mode2_person_energy = RESOURCE_LOAD_NEW("InGameUI/boss_mode2/ig_boss1_lvbar_content.dds", true, Texture2D);
	ui_Boss_mode2_person_energy_shine = RESOURCE_LOAD_NEW("InGameUI/boss_mode2/ig_boss1_lvbar_flash.dds", true, Texture2D);
	ui_Boss_mode2_person_passiveskill[0] = RESOURCE_LOAD_NEW("InGameUI/boss_mode2/ig_boss1_v2_skill_ico_02.dds", true, Texture2D);
	ui_Boss_mode2_person_passiveskill[1] = RESOURCE_LOAD_NEW("InGameUI/boss_mode2/ig_boss1_v2_skill_ico_03.dds", true, Texture2D);
	ui_Boss_mode2_person_passiveskill[2] = RESOURCE_LOAD_NEW("InGameUI/boss_mode2/ig_boss1_v2_skill_ico_05.dds", true, Texture2D);
	ui_Boss_mode2_person_passiveskill[3] = RESOURCE_LOAD_NEW("InGameUI/boss_mode2/ig_boss1_v2_skill_ico_01.dds", true, Texture2D);
	ui_Boss_mode2_HP_num = RESOURCE_LOAD_NEW("InGameUI/boss_mode2/ig_boss1_number_02.dds", true, Texture2D);
	ui_Boss_mode2_HP_text = RESOURCE_LOAD_NEW("InGameUI/boss_mode2/ig_boss1_number_03.dds", true, Texture2D);
	ui_Boss_mode2_boss_Gun_text = RESOURCE_LOAD_NEW("InGameUI/boss_mode2/ig_boss1_number_04.dds", true, Texture2D);
	ui_Boss_mode2_boss_Gun_text_shine = RESOURCE_LOAD_NEW("InGameUI/boss_mode2/ig_boss1_number_04_flasn.dds", true, Texture2D);
	ui_Boss_mode2_person_skill_level_up = RESOURCE_LOAD_NEW("InGameUI/boss_mode2/ig_boss1_ico_lvup.dds", true, Texture2D);
	ui_Boss_mode2_person_initiativ_skill[0] = RESOURCE_LOAD_NEW("InGameUI/CommomZombie/ig_zombiev2_skill_ico_06.dds", true, Texture2D);
	ui_Boss_mode2_person_initiativ_skill[1] = RESOURCE_LOAD_NEW("InGameUI/boss_mode2/ig_boss1_v2_skill_ico_7.dds", true, Texture2D);
	ui_Boss_mode2_person_initiativ_skill[2] = RESOURCE_LOAD_NEW("InGameUI/boss_mode2/ig_boss1_v2_skill_ico_01.dds", true, Texture2D);
	ui_Boss_mode2_person_initiativ_skill[3] = RESOURCE_LOAD_NEW("InGameUI/boss_mode2/ig_boss1_v2_skill_ico_12.dds", true, Texture2D);
	ui_Boss_mode2_person_strange_spawn_skill[0] = RESOURCE_LOAD_NEW("InGameUI/boss_mode2/ig_boss1_v2_skill_ico_9.dds", true, Texture2D);
	ui_Boss_mode2_person_strange_spawn_skill[1] = RESOURCE_LOAD_NEW("InGameUI/boss_mode2/ig_boss1_v2_skill_ico_8.dds", true, Texture2D);
	ui_Boss_mode2_person_strange_spawn_skill[2] = RESOURCE_LOAD_NEW("InGameUI/boss_mode2/ig_boss1_v2_skill_ico_10.dds", true, Texture2D);
	ui_Boss_mode2_person_strange_spawn_skill[3] = RESOURCE_LOAD_NEW("InGameUI/boss_mode2/ig_boss1_v2_skill_ico_11.dds", true, Texture2D);
	ui_Boss_mode2_boss_scale_uv_left = RESOURCE_LOAD_NEW("InGameUI/boss_mode2/boss1_v2_Crosshair_human2_number_v1.dds", true, Texture2D);
	ui_Boss_mode2_boss_scale_uv_right = RESOURCE_LOAD_NEW("InGameUI/boss_mode2/boss1_v2_Crosshair_human2_number_v2.dds", true, Texture2D);
	ui_Boss_mode2_boss_scale_uv_Center = RESOURCE_LOAD_NEW("InGameUI/boss_mode2/boss1_v2_Crosshair_human1_v2.dds", true, Texture2D);
	ui_Boss_mode2_boss_scale_uv_Top = RESOURCE_LOAD_NEW("InGameUI/boss_mode2/boss1_v2_Crosshair_human2_number_v3.dds", true, Texture2D);
	ui_Boss_mode2_boss_crosshair = RESOURCE_LOAD_NEW("InGameUI/boss_mode2/boss1_v2_Crosshair_boss1.dds", true, Texture2D);
	ui_Boss_mode2_boss_crosshair_r = RESOURCE_LOAD_NEW("InGameUI/boss_mode2/boss1_v2_Crosshair_boss1_r.dds", true, Texture2D);
	ui_Boss_mode2_airplane_crosshair = RESOURCE_LOAD_NEW("InGameUI/boss_mode2/boss1_v2_Crosshair_human2.dds", true, Texture2D);
	ui_Boss_mode2_airplane_crosshair_r = RESOURCE_LOAD_NEW("InGameUI/boss_mode2/boss1_v2_Crosshair_human2_r.dds", true, Texture2D);
	ui_Boss_mode2_cannon_crosshair = RESOURCE_LOAD_NEW("InGameUI/boss_mode2/boss1_v2_Crosshair_human1.dds", true, Texture2D);
	ui_Boss_mode2_cannon_crosshair_r = RESOURCE_LOAD_NEW("InGameUI/boss_mode2/boss1_v2_Crosshair_human1_r.dds", true, Texture2D);
	ui_Boss_mode2_yun = RESOURCE_LOAD_NEW("InGameUI/boss_mode2/ig_boss1_bg6.dds", true, Texture2D);
	ui_Boss_mode2_yun_r = RESOURCE_LOAD_NEW("InGameUI/boss_mode2/ig_boss1_bg5.dds", true, Texture2D);
}


void InGameUINew::_InitItemModeInfo()
{
	ui_itemmode_People_bottom_bg = RESOURCE_LOAD_NEW("InGameUI/item_mode/ig_useitem_bar_03_bg.dds", true, Texture2D);
	ui_itemmode_People_bottom_energy_f = RESOURCE_LOAD_NEW("InGameUI/item_mode/ig_useitem_timer_hp.dds", true, Texture2D);

	ui_itemmode_Skill_bg = RESOURCE_LOAD_NEW("InGameUI/item_mode/ig_itemmode_skill_ico_bg.dds", true, Texture2D);
	ui_itemmode_Skill_ico[0] = RESOURCE_LOAD_NEW("InGameUI/item_mode/ig_itemmode_skill_ico_0.dds", true, Texture2D);
	ui_itemmode_Skill_ico[1] = RESOURCE_LOAD_NEW("InGameUI/item_mode/ig_itemmode_skill_ico_1.dds", true, Texture2D);
	ui_itemmode_Skill_ico[2] = RESOURCE_LOAD_NEW("InGameUI/item_mode/ig_itemmode_skill_ico_2.dds", true, Texture2D);
	ui_itemmode_Skill_ico[3] = RESOURCE_LOAD_NEW("InGameUI/item_mode/ig_itemmode_skill_ico_3.dds", true, Texture2D);
	ui_itemmode_Skill_ico[4] = RESOURCE_LOAD_NEW("InGameUI/item_mode/ig_itemmode_skill_ico_4.dds", true, Texture2D);
	ui_itemmode_Skill_ico[5] = RESOURCE_LOAD_NEW("InGameUI/item_mode/ig_itemmode_skill_ico_5.dds", true, Texture2D);
	ui_itemmode_Skill_ico[6] = RESOURCE_LOAD_NEW("InGameUI/item_mode/ig_itemmode_skill_ico_6.dds", true, Texture2D);
	ui_itemmode_Skill_ico[7] = RESOURCE_LOAD_NEW("InGameUI/item_mode/ig_itemmode_skill_ico_7.dds", true, Texture2D);
	ui_itemmode_Skill_ico[8] = RESOURCE_LOAD_NEW("InGameUI/item_mode/ig_itemmode_skill_ico_8.dds", true, Texture2D);
	ui_itemmode_Skill_ico[9] = RESOURCE_LOAD_NEW("InGameUI/item_mode/ig_itemmode_skill_ico_9.dds", true, Texture2D);
	ui_itemmode_Skill_ico[10] = RESOURCE_LOAD_NEW("InGameUI/item_mode/ig_itemmode_skill_ico_10.dds", true, Texture2D);
	ui_itemmode_Skill_ico[11] = RESOURCE_LOAD_NEW("InGameUI/item_mode/ig_itemmode_skill_ico_11.dds", true, Texture2D);
	ui_itemmode_Skill_ico[12] = RESOURCE_LOAD_NEW("InGameUI/item_mode/ig_itemmode_skill_ico_12.dds", true, Texture2D);
	ui_itemmode_Skill_ico[13] = RESOURCE_LOAD_NEW("InGameUI/item_mode/ig_itemmode_skill_ico_13.dds", true, Texture2D);
	ui_itemmode_Skill_ico[14] = RESOURCE_LOAD_NEW("InGameUI/item_mode/ig_itemmode_skill_ico_14.dds", true, Texture2D);
	ui_itemmode_Skill_ico[15] = RESOURCE_LOAD_NEW("InGameUI/item_mode/ig_itemmode_skill_ico_6.dds", true, Texture2D);
	ui_itemmode_Skill_ico[16] = RESOURCE_LOAD_NEW("InGameUI/item_mode/ig_itemmode_skill_ico_7.dds", true, Texture2D);
	ui_itemmode_Skill_ico[17] = RESOURCE_LOAD_NEW("InGameUI/item_mode/ig_itemmode_skill_ico_12.dds", true, Texture2D);
	ui_itemmode_Skill_ico[18] = RESOURCE_LOAD_NEW("InGameUI/item_mode/ig_itemmode_skill_ico_11.dds", true, Texture2D);
	ui_itemmode_Skill_ico[19] = RESOURCE_LOAD_NEW("LobbyUI/ibt_icon/lb_squad_buff01_01.tga", true, Texture2D);
	ui_itemmode_Skill_ico[20] = RESOURCE_LOAD_NEW("LobbyUI/ibt_icon/lb_squad_buff02_01.tga", true, Texture2D);
	ui_itemmode_Skill_ico[21] = RESOURCE_LOAD_NEW("LobbyUI/ibt_icon/lb_squad_buff04_01.tga", true, Texture2D);
	ui_itemmode_Skill_ico[22] = RESOURCE_LOAD_NEW("LobbyUI/ibt_icon/lb_squad_buff05_01.tga", true, Texture2D);
	ui_itemmode_Skill_ico[23] = RESOURCE_LOAD_NEW("LobbyUI/ibt_icon/lb_squad_buff07_01.tga", true, Texture2D);
	ui_itemmode_Skill_ico[24] = RESOURCE_LOAD_NEW("LobbyUI/ibt_icon/lb_squad_buff06_01.tga", true, Texture2D);
	ui_itemmode_Skill_ico[25] = RESOURCE_LOAD_NEW("InGameUI/item_mode/ig_itemmode_skill_ico_25.dds", true, Texture2D);

	//ui_itemmode_Skill_head[0] = RESOURCE_LOAD_NEW("InGameUI/item_mode/ig_itemmode_skill_head_0.dds", true, Texture2D);
	//ui_itemmode_Skill_head[1] = RESOURCE_LOAD_NEW("InGameUI/item_mode/ig_itemmode_skill_head_1.dds", true, Texture2D);
	//ui_itemmode_Skill_head[2] = RESOURCE_LOAD_NEW("InGameUI/item_mode/ig_itemmode_skill_head_2.dds", true, Texture2D);
	//ui_itemmode_Skill_head[3] = RESOURCE_LOAD_NEW("InGameUI/item_mode/ig_itemmode_skill_head_3.dds", true, Texture2D);
	//ui_itemmode_Skill_head[4] = RESOURCE_LOAD_NEW("InGameUI/item_mode/ig_itemmode_skill_head_4.dds", true, Texture2D);
	//ui_itemmode_Skill_head[5] = RESOURCE_LOAD_NEW("InGameUI/item_mode/ig_itemmode_skill_head_5.dds", true, Texture2D);
	//ui_itemmode_Skill_head[6] = RESOURCE_LOAD_NEW("InGameUI/item_mode/ig_itemmode_skill_head_6.dds", true, Texture2D);
	//ui_itemmode_Skill_head[7] = RESOURCE_LOAD_NEW("InGameUI/item_mode/ig_itemmode_skill_head_7.dds", true, Texture2D);
	//ui_itemmode_Skill_head[8] = RESOURCE_LOAD_NEW("InGameUI/item_mode/ig_itemmode_skill_head_8.dds", true, Texture2D);
	//ui_itemmode_Skill_head[9] = RESOURCE_LOAD_NEW("InGameUI/item_mode/ig_itemmode_skill_head_9.dds", true, Texture2D);
	//ui_itemmode_Skill_head[10] = RESOURCE_LOAD_NEW("InGameUI/item_mode/ig_itemmode_skill_head_10.dds", true, Texture2D);
	//ui_itemmode_Skill_head[11] = RESOURCE_LOAD_NEW("InGameUI/item_mode/ig_itemmode_skill_head_11.dds", true, Texture2D);
	//ui_itemmode_Skill_head[12] = RESOURCE_LOAD_NEW("InGameUI/item_mode/ig_itemmode_skill_head_12.dds", true, Texture2D);
	//ui_itemmode_Skill_head[13] = RESOURCE_LOAD_NEW("InGameUI/item_mode/ig_itemmode_skill_head_13.dds", true, Texture2D);
	//ui_itemmode_Skill_head[14] = RESOURCE_LOAD_NEW("InGameUI/item_mode/ig_itemmode_skill_head_14.dds", true, Texture2D);
}

void InGameUINew::_InitGameTypeInfoTextures()
{
	ui_hold_point_info_bg_border = RESOURCE_LOAD_NEW("InGameUI/hold_point/ig_zd_bar_bg.dds", true, Texture2D);
	ui_hold_point_info_bg_border_L = RESOURCE_LOAD_NEW("InGameUI/hold_point/ig_zd_bar_bg_L.dds", true, Texture2D);
	ui_hold_point_info_bg_border_R = RESOURCE_LOAD_NEW("InGameUI/hold_point/ig_zd_bar_bg_R.dds", true, Texture2D);
	ui_hold_point_info_progress = RESOURCE_LOAD_NEW("InGameUI/hold_point/ig_zd_bar_bg_2.dds", true, Texture2D);
	ui_hold_point_info_flag_red = RESOURCE_LOAD_NEW("InGameUI/hold_point/ig_zd_bar_red_2.dds", true, Texture2D);
	ui_hold_point_info_flag_blue = RESOURCE_LOAD_NEW("InGameUI/hold_point/ig_zd_bar_blue_2.dds", true, Texture2D);
	ui_hold_point_info_board_red = RESOURCE_LOAD_NEW("InGameUI/hold_point/ig_zd_bar_red_2_button.dds", true, Texture2D);
	ui_hold_point_info_board_blue = RESOURCE_LOAD_NEW("InGameUI/hold_point/ig_zd_bar_blue_2_button.dds", true, Texture2D);
	ui_hold_point_info_waifaguang_bg = RESOURCE_LOAD_NEW("InGameUI/hold_point/ig_zd_bar_neifaguang.dds", true, Texture2D);
	ui_hold_point_info_waifaguang_board = RESOURCE_LOAD_NEW("InGameUI/hold_point/ig_zd_bar_shanguang_2_button.dds", true, Texture2D);
	ui_hold_point_info_people = RESOURCE_LOAD_NEW("InGameUI/hold_point/ig_zd_bar_peopleico.dds", true, Texture2D);
	ui_hold_point_timer_red = RESOURCE_LOAD_NEW("InGameUI/hold_point/ig_zd_bar_red.dds", true, Texture2D);
	ui_hold_point_timer_blue = RESOURCE_LOAD_NEW("InGameUI/hold_point/ig_zd_bar_blue.dds", true, Texture2D);
	ui_hold_point_timer2_red = RESOURCE_LOAD_NEW("InGameUI/hold_point/ig_zd_biaoshi_red.dds", true, Texture2D);
	ui_hold_point_timer2_blue = RESOURCE_LOAD_NEW("InGameUI/hold_point/ig_zd_biaoshi_blue.dds", true, Texture2D);
	ui_hold_point_neifaguang = RESOURCE_LOAD_NEW("InGameUI/hold_point/ig_zd_biaoshi_shanguang.dds", true, Texture2D); 

	ui_hold_point_length = RESOURCE_LOAD_NEW("InGameUI/controlpoint.dds", true, Texture2D);

	ui_vehicle_info_bg = RESOURCE_LOAD_NEW("InGameUI/hold_point/ig_tc_carbar_bg.dds", true, Texture2D);
	ui_vehicle_info_left = RESOURCE_LOAD_NEW("InGameUI/hold_point/ig_tc_carbar_bg1.dds", true, Texture2D);
	ui_vehicle_info_right = RESOURCE_LOAD_NEW("InGameUI/hold_point/ig_tc_carbar_bg2.dds", true, Texture2D);
	ui_vehicle_info_red = RESOURCE_LOAD_NEW("InGameUI/hold_point/ig_tc_carbar_contentred.dds", true, Texture2D);
	ui_vehicle_info_blue = RESOURCE_LOAD_NEW("InGameUI/hold_point/ig_tc_carbar_contentblue.dds", true, Texture2D);
	ui_vehicle_info_shanguang_red = RESOURCE_LOAD_NEW("InGameUI/hold_point/ig_tc_carbar_contentred_shanguang.dds", true, Texture2D);
	ui_vehicle_info_shanguang_blue = RESOURCE_LOAD_NEW("InGameUI/hold_point/ig_tc_carbar_contentblue_shanguang.dds", true, Texture2D);
	ui_vehicle_info_car_red = RESOURCE_LOAD_NEW("InGameUI/hold_point/ig_tc_car_red.dds", true, Texture2D);
	ui_vehicle_info_car_blue = RESOURCE_LOAD_NEW("InGameUI/hold_point/ig_tc_car_blue.dds", true, Texture2D);
	ui_vehicle_length = RESOURCE_LOAD_NEW("InGameUI/vehicle.dds", true, Texture2D);
	ui_bomb_length = RESOURCE_LOAD_NEW("InGameUI/bomb/ig_bomb_vehicle.dds", true, Texture2D);
	ui_vehicle_people = RESOURCE_LOAD_NEW("InGameUI/hold_point/ig_tc_car_people.dds", true, Texture2D);
	ui_king_king_r = RESOURCE_LOAD_NEW("InGameUI/ig_common_hero_mark_red.dds", true, Texture2D);
	ui_king_king_b = RESOURCE_LOAD_NEW("InGameUI/ig_common_hero_mark_blue.dds", true, Texture2D);

	ui_horn = RESOURCE_LOAD_NEW("InGameUI/ig_horn.dds", true, Texture2D);
	ui_horn_bg = RESOURCE_LOAD_NEW("InGameUI/ig_common_horn_bg.dds", true, Texture2D);
}


void InGameUINew::_DrawHeadInfo(by_ptr(UIRender) ui_render)
{
	tempc_ptr(Character) viewer = gLevel->GetViewer();
	tempc_ptr(Character) bossPVE = NullPtr;
	tempc_ptr(Character) player = gLevel->GetPlayer();
	Game * game = gGame;
	if (viewer)
	{
		Matrix44 view;
		Matrix44 world;
		Core::Vector3 rt_size = gGame->guiSys->GetSize();

		view.SetScaleXYZ(2.0f/rt_size.x, -2.0f/rt_size.y, 0);
		world.SetTranslationXYZ(0, -(rt_size.y/2), 0);
		ui_render->SetView(view);
		ui_render->SetWorld(world);

		//FCM
		if (warn_msg_flag && warn_msg.calclen() > 0)
		{
			Core::String str = Core::String::Format("%s",warn_msg);
			SplitString(str,str,Core::Rectangle(0,0,400,200), ui_render->font_simhei_16);
			ui_render->DrawStringShadow(ui_render->font_simhei_16, Core::ARGB(255, 73, 73), Core::ARGB(255,0,0,0), Core::ARGB(0,0,0,0), Core::Rectangle(-200,40,200,40+200), str, Unit::kAlignCenterMiddle);
		}

		if (gLevel->boss_starttimeer > 0 && gLevel->game_type != RoomOption::kBossPVE)
		{
			if (gLevel->boss_starttimeer >= 10)
			{
				if (gLevel->boss_starttimeer > 99)
					gLevel->boss_starttimeer = 99;
				_DrawNumberTextureWindow(ui_render, ui_boss_num, Core::Vector2(-116, rt_size.y/2-68), 116, 136, (int)gLevel->boss_starttimeer/10, 0.1f);
				_DrawNumberTextureWindow(ui_render, ui_boss_num, Core::Vector2(0, rt_size.y/2-68), 116, 136, (int)gLevel->boss_starttimeer%10, 0.1f);
			}
			else
			{
				_DrawNumberTextureWindow(ui_render, ui_boss_num, Core::Vector2(-58, rt_size.y/2-68), 116, 136, gLevel->boss_starttimeer, 0.1f);
			}
		}

		int tempx = -34;
		int tempy = 9;
		int tep_num;
		float boss_hp = 0.f;
		bool next_bl = true;
		switch(gLevel->game_type)
		{
		case RoomOption::kTeam:
		case RoomOption::kPushVehicle:
		case RoomOption::kKnifeMode:
		case RoomOption::KMoonMode:
		case RoomOption::kAdvenceMode:
		case RoomOption::kHoldPoint:
		case RoomOption::kStreetBoyMode:
		case RoomOption::kItemMode:
		case RoomOption::kEditMode:
		case RoomOption::kSurvivalMode:
				ui_render->DrawTextureWindow(Core::Vector2(tempx+3, tempy), 68, 60, ui_head_info_bg_center);
			break;
		case RoomOption::kTDMode:
			ui_render->DrawTextureWindow(Core::Vector2(-300, 0), 600, 90, ui_ingame_time_bg);
			break;
		case RoomOption::kTeamDeathMatch:
				ui_render->DrawTextureWindow(Core::Vector2(-148, tempy), 296, 60, ui_head_info_bg_TeamDeath);
			break;
		case RoomOption::kBoss:
				ui_render->DrawTextureWindow(Core::Vector2(-156+3, tempy), 312, 60, ui_head_info_bg_boss);
			break;
		case RoomOption::kBombMode:
			{
				ui_render->DrawTextureWindow(Core::Vector2(-148, tempy), 296, 60, ui_head_info_bg_TeamDeath);
			}
			break;
		case RoomOption::kZombieMode:
		case RoomOption::kCommonZombieMode:
			{
				ui_render->DrawTextureWindow(Core::Vector2(-96, tempy), 192, 60, ui_head_info_bg_Zombie);
			}
			break;
		case RoomOption::kBossPVE:
			{
				tep_num =  0;
				tempy = 0;
				if (gLevel->saveplayer && gLevel->saveplayer->ispveboss)
				{
					m_current_pveboss = gLevel->saveplayer;
				}
				if (m_current_pveboss)
				{
					const Array<sharedc_ptr(Character)> & characters = gLevel->GetCharacters();
					for (U32 i = 0; i < (int)characters.Size(); i++)
					{
						if (characters[i]->uid == m_current_pveboss->uid)
							bossPVE = characters[i];
					}
				}
				if (bossPVE && bossPVE->max_hp > 0)
				{
					boss_hp = (float)bossPVE->hp / bossPVE->max_hp;
				}
				ui_render->DrawTextureWindow(Core::Vector2(-184+3-90 + 5, tempy - 3 + 25), 549, 84, ui_head_info_bg_Boss2);
				if (bossPVE && bossPVE->ui_head_icon)
				{
					ui_render->DrawTextureWindow(Core::Vector2(-184+3-90-90-20 + 5, tempy + 4), 232, 102, bossPVE->ui_head_icon);
				}
				ui_render->DrawTextureWindow(Core::Vector2(-184+3+78-116+8, tempy - 8 + 61), 493*boss_hp, 26, ui_head_info_bg_Bos_hp,Core::Rectangle(0,0,boss_hp,1));
				ui_render->DrawTextureWindow(Core::Vector2(-184+3+78-116+8, tempy - 8 + 61), 493, 26, ui_head_info_bg_Bos_hp_bg);
			}
			break;
		case RoomOption::kBossMode2:
			{
				if (player->GetTeam() == 1)
				{
					ui_render->DrawTextureWindow(Core::Vector2(-223 +3, tempy), 446, 114, ui_head_info_bg_boss_mode2_bg);
				} 
				else
				{
					ui_render->DrawTextureWindow(Core::Vector2(-96, tempy), 192, 60, ui_head_info_bg_Zombie);
				}
			}
			break;
		}
		
		Core::ARGB font_color = Core::ARGB(255, 238, 206);
		Core::ARGB bg_color = Core::ARGB(0, 0, 0, 0);
		Core::CStrBuf<256> buff;

		if (gLevel->game_type == RoomOption::kBossPVE)
		{
			tempy += 78;
		}
		else if (gLevel->game_type == RoomOption::kBossMode2)
		{
			if (player->GetTeam() == 1)
			{
				tempy += 82;
			}
		}
		else if (gLevel->game_type != RoomOption::kBoss && gLevel->game_type != RoomOption::kZombieMode && gLevel->game_type != RoomOption::kCommonZombieMode)
		{
			buff.format("%d", gGame->scores->teams[0].Size());
			ui_render->DrawFontWindow(Core::Vector2(tempx+10, tempy+28), 12, 12, ui_render->font_simhei_12, font_color, bg_color, buff, Unit::kAlignCenterMiddle);
			buff.format("%d", gGame->scores->teams[1].Size());
			if (RoomOption::kTDMode == gLevel->game_type)
				tempx+=5;
			ui_render->DrawFontWindow(Core::Vector2(tempx+53, tempy+28), 12, 12, ui_render->font_simhei_12, font_color, bg_color, buff, Unit::kAlignCenterMiddle);
		}
		else
		{
			buff.format("%d", gGame->scores->teams[1].Size());
			ui_render->DrawFontWindow(Core::Vector2(tempx+10, tempy+28), 12, 12, ui_render->font_simhei_12, font_color, bg_color, buff, Unit::kAlignCenterMiddle);
			buff.format("%d", gGame->scores->teams[0].Size());
			ui_render->DrawFontWindow(Core::Vector2(tempx+53, tempy+28), 12, 12, ui_render->font_simhei_12, font_color, bg_color, buff, Unit::kAlignCenterMiddle);
		}

		if(viewer && gLevel->round_start_wait_time > 0.f)
		{
			int second = (int)gLevel->round_start_wait_time % 60;
			buff.format(gLang->GetTextW(L"ʣ��%02d��"), second);
			if(second < 5)
			{
				if ((int)(Core::Task::GetTotalTime() * 4) & 1)
				{
					font_color = Core::ARGB(255, 0, 0);
				}
			}
			ui_render->DrawFontWindow(Core::Vector2(tempx+4, tempy+3), 64, 20, ui_render->font_simhei_14, font_color, bg_color, buff, Unit::kAlignCenterMiddle);
			
			font_color = Core::ARGB(255, 238, 206);
		}
		else
		{
			int second = gGame->round_time % 60;
			int minute = (gGame->round_time / 60) % 60;
			int hour = (gGame->round_time / 3600);
			buff.format("%d:%02d:%02d", hour, minute, second);
			ui_render->DrawFontWindow(Core::Vector2(tempx+4, tempy+3), 64, 20, ui_render->font_simhei_14, font_color, bg_color, buff, Unit::kAlignCenterMiddle);
		}

		// draw score
		if (gLevel->game_type == RoomOption::kTeam || gLevel->game_type == RoomOption::kKnifeMode || gLevel->game_type == RoomOption::kItemMode )
		{
			ui_render->SetTexture(ui_head_info_bg_left);
			ui_render->DrawWindow(Core::Rectangle(tempx-63-52,tempy,tempx+3,tempy+60),Core::Rectangle(34,0,0,0),Core::Rectangle(34.f/40.f,0.f/60.f,0.f/40.f,0.f/60.f));
			ui_render->SetTexture(ui_head_info_bg_right);
			ui_render->DrawWindow(Core::Rectangle(tempx+69,tempy,tempx+69+66+52,tempy+60),Core::Rectangle(2,0,34,0),Core::Rectangle(2.f/40.f,0.f/60.f,34.f/40.f,0.f/60.f));

			_DrawNumberTextureWindow(ui_render, ui_head_info_time_number, Core::Vector2(tempx-85, tempy+10), 26, 33, gGame->scores->team_kills[0]/100,0.1f);
			_DrawNumberTextureWindow(ui_render, ui_head_info_time_number, Core::Vector2(tempx-59, tempy+10), 26, 33, (gGame->scores->team_kills[0]%100)/10,0.1f);
			_DrawNumberTextureWindow(ui_render, ui_head_info_time_number, Core::Vector2(tempx-33, tempy+10), 26, 33, gGame->scores->team_kills[0]%10,0.1f);

			_DrawNumberTextureWindow(ui_render, ui_head_info_time_number, Core::Vector2(tempx+78, tempy+10), 26, 33, gGame->scores->team_kills[1]/100,0.1f);
			_DrawNumberTextureWindow(ui_render, ui_head_info_time_number, Core::Vector2(tempx+104, tempy+10), 26, 33, (gGame->scores->team_kills[1]%100)/10,0.1f);
			_DrawNumberTextureWindow(ui_render, ui_head_info_time_number, Core::Vector2(tempx+130, tempy+10), 26, 33, gGame->scores->team_kills[1]%10,0.1f);
		}
		else if(gLevel->game_type == RoomOption::KMoonMode)
		{
			ui_render->SetTexture(ui_head_info_bg_left);
			ui_render->DrawWindow(Core::Rectangle(tempx-63,tempy,tempx+3,tempy+60),Core::Rectangle(34,0,0,0),Core::Rectangle(34.f/40.f,0.f/60.f,0.f/40.f,0.f/60.f));
			ui_render->SetTexture(ui_head_info_bg_right);
			ui_render->DrawWindow(Core::Rectangle(tempx+69,tempy,tempx+69+66,tempy+60),Core::Rectangle(2,0,34,0),Core::Rectangle(2.f/40.f,0.f/60.f,34.f/40.f,0.f/60.f));
			_DrawNumberTextureWindow(ui_render, ui_head_info_time_number, Core::Vector2(tempx-28, tempy+10), 26, 33, gGame->scores->team_round[0],0.1f);
			_DrawNumberTextureWindow(ui_render, ui_head_info_time_number, Core::Vector2(tempx+72, tempy+10), 26, 33, gGame->scores->team_round[1],0.1f);
		}
		else if(gLevel->game_type == RoomOption::kAdvenceMode)
		{
			ui_render->SetTexture(ui_head_info_bg_left);
			ui_render->DrawWindow(Core::Rectangle(tempx-63,tempy,tempx+3,tempy+60),Core::Rectangle(34,0,0,0),Core::Rectangle(34.f/40.f,0.f/60.f,0.f/40.f,0.f/60.f));
			ui_render->SetTexture(ui_head_info_bg_right);
			ui_render->DrawWindow(Core::Rectangle(tempx+69,tempy,tempx+69+66,tempy+60),Core::Rectangle(2,0,34,0),Core::Rectangle(2.f/40.f,0.f/60.f,34.f/40.f,0.f/60.f));
			_DrawNumberTextureWindow(ui_render, ui_head_info_time_number, Core::Vector2(tempx-28, tempy+10), 26, 33, gGame->scores->team_round[0],0.1f);
			_DrawNumberTextureWindow(ui_render, ui_head_info_time_number, Core::Vector2(tempx+72, tempy+10), 26, 33, gGame->scores->team_round[1],0.1f);
		}
		else if(gLevel->game_type == RoomOption::kSurvivalMode)
		{
			ui_render->SetTexture(ui_head_info_bg_left);
			ui_render->DrawWindow(Core::Rectangle(tempx-63,tempy,tempx+3,tempy+60),Core::Rectangle(34,0,0,0),Core::Rectangle(34.f/40.f,0.f/60.f,0.f/40.f,0.f/60.f));
			ui_render->SetTexture(ui_head_info_bg_right);
			ui_render->DrawWindow(Core::Rectangle(tempx+69,tempy,tempx+69+66,tempy+60),Core::Rectangle(2,0,34,0),Core::Rectangle(2.f/40.f,0.f/60.f,34.f/40.f,0.f/60.f));
			_DrawNumberTextureWindow(ui_render, ui_head_info_time_number, Core::Vector2(tempx-28, tempy+10), 26, 33, gGame->scores->team_round[0],0.1f);
			_DrawNumberTextureWindow(ui_render, ui_head_info_time_number, Core::Vector2(tempx+72, tempy+10), 26, 33, gGame->scores->team_round[1],0.1f);
		}
		else if (gLevel->game_type == RoomOption::kHoldPoint)
		{
			zd_time += Task::GetFrameTime() * 6;
			zd_time = (zd_time >= 7200) ? 0 : zd_time;
			ui_render->SetTexture(ui_head_info_bg_left);
			ui_render->DrawWindow(Core::Rectangle(tempx-63,tempy,tempx+3,tempy+60),Core::Rectangle(34,0,0,0),Core::Rectangle(34.f/40.f,0.f/60.f,0.f/40.f,0.f/60.f));
			ui_render->SetTexture(ui_head_info_bg_right);
			ui_render->DrawWindow(Core::Rectangle(tempx+69,tempy,tempx+69+66,tempy+60),Core::Rectangle(2,0,34,0),Core::Rectangle(2.f/40.f,0.f/60.f,34.f/40.f,0.f/60.f));
			_DrawNumberTextureWindow(ui_render, ui_head_info_time_number, Core::Vector2(tempx-28, tempy+10), 26, 33, gGame->scores->team_round[0],0.1f);
			_DrawNumberTextureWindow(ui_render, ui_head_info_time_number, Core::Vector2(tempx+72, tempy+10), 26, 33, gGame->scores->team_round[1],0.1f);
		}
		else if (gLevel->game_type == RoomOption::kCommonZombieMode)
		{
			_DrawNumberTextureWindow(ui_render, ui_head_info_time_number, Core::Vector2(tempx-28, tempy+10), 26, 33, gGame->scores->team_round[1],0.1f);
			_DrawNumberTextureWindow(ui_render, ui_head_info_time_number, Core::Vector2(tempx+72, tempy+10), 26, 33, gGame->scores->team_round[0],0.1f);
			_DrawCommonZombieHeadInfo(ui_render);
		}
		else if (gLevel->game_type == RoomOption::kPushVehicle)
		{
			ui_render->SetTexture(ui_head_info_bg_left);
			ui_render->DrawWindow(Core::Rectangle(tempx-63,tempy,tempx+3,tempy+60),Core::Rectangle(34,0,0,0),Core::Rectangle(34.f/40.f,0.f/60.f,0.f/40.f,0.f/60.f));
			ui_render->SetTexture(ui_head_info_bg_right);
			ui_render->DrawWindow(Core::Rectangle(tempx+69,tempy,tempx+69+66,tempy+60),Core::Rectangle(2,0,34,0),Core::Rectangle(2.f/40.f,0.f/60.f,34.f/40.f,0.f/60.f));
			_DrawNumberTextureWindow(ui_render, ui_head_info_time_number, Core::Vector2(tempx-28, tempy+10), 26, 33, gGame->scores->team_round[0],0.1f);
			_DrawNumberTextureWindow(ui_render, ui_head_info_time_number, Core::Vector2(tempx+72, tempy+10), 26, 33, gGame->scores->team_round[1],0.1f);
		}
		else if (gLevel->game_type == RoomOption::kTeamDeathMatch || gLevel->game_type == RoomOption::kBombMode)
		{
			_DrawNumberTextureWindow(ui_render, ui_head_info_time_number, Core::Vector2(tempx-50, tempy+10), 26, 33, gGame->scores->team_round[0]/10,0.1f);
			_DrawNumberTextureWindow(ui_render, ui_head_info_time_number, Core::Vector2(tempx-24, tempy+10), 26, 33, gGame->scores->team_round[0]%10,0.1f);
			_DrawNumberTextureWindow(ui_render, ui_head_info_time_number, Core::Vector2(tempx+71, tempy+10), 26, 33, gGame->scores->team_round[1]/10,0.1f);
			_DrawNumberTextureWindow(ui_render, ui_head_info_time_number, Core::Vector2(tempx+71+26, tempy+10), 26, 33, gGame->scores->team_round[1]%10,0.1f);

			ui_render->DrawTextureWindow(Core::Vector2(tempx-95,tempy+17), 16, 20, ui_vehicle_people);
			ui_render->DrawTextureWindow(Core::Vector2(tempx+132,tempy+17), 16, 20, ui_vehicle_people);

			int team1 = 0;
			for (int i = 0; i < (int)gGame->scores->teams[0].Size();++i)
			{
				Character * c = gGame->scores->teams[0][i];
				if (c && !c->IsDied())
				{
					team1++;
				}
			}
			int team2 = 0;
			for (int i = 0; i < (int)gGame->scores->teams[1].Size();++i)
			{
				Character * c = gGame->scores->teams[1][i];
				if (c && !c->IsDied())
				{
					team2++;
				}
			}
			buff.format("x%d", team1);
			ui_render->DrawFontWindow(Core::Vector2(tempx-95+18,tempy+20), 15, 15, ui_render->font_simhei_14, Core::ARGB(255, 238, 206),  Core::ARGB(0, 0, 0, 0), buff, Unit::kAlignLeftTop);
			buff.format("x%d", team2);
			ui_render->DrawFontWindow(Core::Vector2(tempx+132+18,tempy+20), 15, 15, ui_render->font_simhei_14, Core::ARGB(255, 238, 206),  Core::ARGB(0, 0, 0, 0), buff, Unit::kAlignLeftTop);
		}
		else if (gLevel->game_type == RoomOption::kBoss)
		{
			_DrawNumberTextureWindow(ui_render, ui_head_info_time_number, Core::Vector2(tempx-20-26, tempy+10), 26, 33, gGame->scores->team_round[1]/10,0.1f);
			_DrawNumberTextureWindow(ui_render, ui_head_info_time_number, Core::Vector2(tempx-20, tempy+10), 26, 33, gGame->scores->team_round[1]%10,0.1f);
			_DrawNumberTextureWindow(ui_render, ui_head_info_time_number, Core::Vector2(tempx+70, tempy+10), 26, 33, gGame->scores->team_round[0]/10,0.1f);
			_DrawNumberTextureWindow(ui_render, ui_head_info_time_number, Core::Vector2(tempx+70+26, tempy+10), 26, 33, gGame->scores->team_round[0]%10,0.1f);
			int life = 0;
			for (int k = 0; k < (int)gGame->scores->teams[0].Size(); k++)
			{
				Character * pp = gGame->scores->teams[0][k];
				if (pp && !pp->IsDied())
				{
					life++;
				}
			}
			buff.format("x%d", life);
			//buff.format("x%d", gLevel->boss_mode_left_count);
			ui_render->DrawFontWindow(Core::Vector2(tempx+145,tempy+25), 45, 15, ui_render->font_simhei_16, Core::ARGB(255, 238, 206),  Core::ARGB(0, 0, 0, 0), buff, Unit::kAlignLeftTop);
			
			if (gGame->scores->teams[1].Size() == 0)
			{
				buff.format("100%%");
				ui_render->DrawString(ui_render->font_simhei_16, Core::ARGB(255, 238, 206), bg_color, Core::Rectangle(tempx-100, tempy+25,tempx-100+50,tempy+40), buff, Unit::kAlignCenterMiddle);

				ui_render->SetTexture(ui_head_info_boss);
				ui_render->DrawWindow(Core::Rectangle(tempx-180,tempy+20-5,tempx-180+380,tempy+20+60-5),Core::Rectangle(78,0,12,0),Core::Rectangle(78.f / 88.f, 0.f / 60.f, 12.f / 88.f, 0.f / 60.f));
			}
			else
			{
				Character * boss = gGame->scores->teams[1][0];
				if (boss && boss->max_hp > 0)
				{
					buff.format("%d%%",boss->hp * 100 / boss->max_hp);
					ui_render->DrawString(ui_render->font_simhei_16, Core::ARGB(255, 238, 206), bg_color, Core::Rectangle(tempx-100, tempy+25,tempx-100+50,tempy+40), buff, Unit::kAlignCenterMiddle);

					ui_render->SetTexture(ui_head_info_boss);
					ui_render->DrawWindow(Core::Rectangle(tempx-180,tempy+20-5,tempx-180+380,tempy+20+60-5),Core::Rectangle(78,0,12,0),Core::Rectangle(78.f / 88.f, 0.f / 60.f, 12.f / 88.f, 0.f / 60.f));

					int hp = 12500;
					float fSc = 0.f;
					int num = boss->hp / hp;
					if (num > 4)
						return;
					int num2 = boss->hp % hp;
					num = (num == 4) ? 3 : num;
					fSc = (float)num2 / (float)hp;

					if (num < 4)
					{
						if (num >= 1 && ui_head_info_boss_hp[num] && ui_head_info_boss_hp[num-1])
						{
							ui_render->SetTexture(ui_head_info_boss_hp[num-1]);
							ui_render->DrawWindow(Core::Rectangle(tempx-180+45,tempy+67-5,tempx-180+55+320,tempy+76-5),Core::Rectangle(6,4,6,7),Core::Rectangle(6.f / 36.f, 4.f / 12.f, 6.f / 36.f, 7.f / 12.f));
							ui_render->SetTexture(ui_head_info_boss_hp[num]);
							ui_render->DrawWindow(Core::Rectangle(tempx-180+45,tempy+67-5,tempx-180+55+320*fSc,tempy+76-5),Core::Rectangle(6,4,6,7),Core::Rectangle(6.f / 36.f, 4.f / 12.f, 6.f / 36.f, 7.f / 12.f));
						}
						else if (num == 0 && ui_head_info_boss_hp[num])
						{
							if (boss->hp > 0)
							{
								ui_render->SetTexture(ui_head_info_boss_hp[num]);
								ui_render->DrawWindow(Core::Rectangle(tempx-180+45,tempy+67-5,tempx-180+55+320*fSc,tempy+76-5),Core::Rectangle(6,4,6,7),Core::Rectangle(6.f / 36.f, 4.f / 12.f, 6.f / 36.f, 7.f / 12.f));
							}
						}
					}
				}
			}
		}
		else if(gLevel->game_type == RoomOption::kStreetBoyMode)
		{
			ui_render->SetTexture(ui_head_info_StreetBoy_Red);
			ui_render->DrawWindow(Core::Rectangle(tempx-63-90,tempy+5,tempx+27,tempy+5+72),Core::Rectangle(0,0,0,0),Core::Rectangle(0.f/180.f,0.f/72.f,0.f/180.f,0.f/72.f));
			ui_render->SetTexture(ui_head_info_StreetBoy_Blue);
			ui_render->DrawWindow(Core::Rectangle(tempx+69-23,tempy+5,tempx+69+66+91,tempy+5+72),Core::Rectangle(0,0,0,0),Core::Rectangle(0.f/180.f,0.f/72.f,0.f/180.f,0.f/72.f));

			ui_render->SetTexture(ui_head_info_bg_left);
			ui_render->DrawWindow(Core::Rectangle(tempx-63,tempy,tempx+3,tempy+60),Core::Rectangle(34,0,0,0),Core::Rectangle(34.f/40.f,0.f/60.f,0.f/40.f,0.f/60.f));
			ui_render->SetTexture(ui_head_info_bg_right);
			ui_render->DrawWindow(Core::Rectangle(tempx+69,tempy,tempx+69+66,tempy+60),Core::Rectangle(2,0,34,0),Core::Rectangle(2.f/40.f,0.f/60.f,34.f/40.f,0.f/60.f));
			_DrawNumberTextureWindow(ui_render, ui_head_info_time_number, Core::Vector2(tempx-28, tempy+10), 26, 33, gGame->scores->team_round[0],0.1f);
			_DrawNumberTextureWindow(ui_render, ui_head_info_time_number, Core::Vector2(tempx+72, tempy+10), 26, 33, gGame->scores->team_round[1],0.1f);

			tempc_ptr(Character) laoda_1 = gLevel->GetCharacter(gLevel->current_street_king_uid[0]);
			tempc_ptr(Character) laoda_2 = gLevel->GetCharacter(gLevel->current_street_king_uid[1]);

			if(laoda_1&& laoda_1->GetCurCharinfo() && laoda_2 && laoda_2->GetCurCharinfo())
			{
				buff.format("%s",laoda_1->GetName());
				ui_render->DrawString(ui_render->font_simhei_16, Core::ARGB(255, 238, 206), bg_color, Core::Rectangle(tempx-63-52-90, tempy+5+76,tempx+30,tempy+5+76+15), buff, Unit::kAlignCenterMiddle);
				buff.format("%s",laoda_2->GetName());
				ui_render->DrawString(ui_render->font_simhei_16, Core::ARGB(255, 238, 206), bg_color, Core::Rectangle(tempx+69-27, tempy+5+76,tempx+69+66+52+90,tempy+5+76+15), buff, Unit::kAlignCenterMiddle);

				uint career_id_blue = laoda_1->GetCurCharinfo()->career_id;
				uint career_id_red = laoda_2->GetCurCharinfo()->career_id;
				tempc_ptr(Texture2D) head_texture = laoda_1->ui_head_icon;
				if (head_texture)
				{
					ui_render->DrawTextureWindow(Core::Vector2(tempx-63-90+30, tempy-3), 55, 76, head_texture);
				}
				head_texture = laoda_2->ui_head_icon;
				if (head_texture)
				{
					ui_render->DrawTextureWindow(Core::Vector2(tempx+69+66+90-55-30, tempy-3),  55, 76, head_texture);
				}

				float fSc_1 = (float)laoda_1->hp / laoda_1->max_hp;
				fSc_1 = fSc_1<0?0:fSc_1;
				if(fSc_1>0.5)
				{
					laoda1Twoflag = true;
					laoda1Fiveflag = true;
				}
				else if(fSc_1>0.2)
				{
					laoda1Twoflag = true;
				}
				if(laoda_1->GetTeam() == 0)
				{
					if(fSc_1<0.5&&laoda1Fiveflag)
					{
						laoda1Fiveflag = false;
						gLevel->AddHorn(gLang->GetTextW(L"���Ӣ��Ѫ���ѵ���50%"));
					}
					else if(fSc_1<0.2&&laoda1Twoflag)
					{
						laoda1Twoflag = false;
						gLevel->AddHorn(gLang->GetTextW(L"���Ӣ��Ѫ���ѵ���20%"));
					}
				}
				else if(laoda_1->GetTeam() == 1)
				{
					if(fSc_1<0.5&&laoda1Fiveflag)
					{
						laoda1Fiveflag = false;
						gLevel->AddHorn(gLang->GetTextW(L"����Ӣ��Ѫ���ѵ���50%"));
					}
					else if(fSc_1<0.2&&laoda1Twoflag)
					{
						laoda1Twoflag = false;
						gLevel->AddHorn(gLang->GetTextW(L"����Ӣ��Ѫ���ѵ���20%"));
					}
				}
				ui_render->SetTexture(ui_head_infoStreetBoy_Hp_Red);
				ui_render->DrawWindow(Core::Rectangle(tempx-180+45+23+50,tempy+67-6,tempx-180+45+23+50+80*fSc_1,tempy+79-6),Core::Rectangle(0,0,0,0),Core::Rectangle(0.f / 80.f, 0.f / 12.f, 0.f / 80.f, 0.f / 12.f));

				float fSc_2 = (float)laoda_2->hp / laoda_2->max_hp;
				fSc_2 = fSc_2<0?0:fSc_2;
				
				if(fSc_2>0.5)
				{
					laoda2Twoflag = true;
					laoda2Fiveflag = true;
				}
				else if(fSc_2>0.2)
				{
					laoda2Twoflag = true;
				}

				if(laoda_2->GetTeam() == 0)
				{
					if(fSc_2<0.5&&laoda2Fiveflag)
					{
						laoda2Fiveflag = false;
						gLevel->AddHorn(gLang->GetTextW(L"���Ӣ��Ѫ���ѵ���50%"));
					}
					else if(fSc_2<0.2&&laoda2Twoflag)
					{
						laoda2Twoflag = false;
						gLevel->AddHorn(gLang->GetTextW(L"���Ӣ��Ѫ���ѵ���20%"));
					}
				}
				else if(laoda_2->GetTeam() == 1)
				{
					if(fSc_2<0.5&&laoda2Fiveflag)
					{
						laoda2Fiveflag = false;
						gLevel->AddHorn(gLang->GetTextW(L"����Ӣ��Ѫ���ѵ���50%"));
					}
					else if(fSc_2<0.2&&laoda2Twoflag)
					{
						laoda2Twoflag = false;
						gLevel->AddHorn(gLang->GetTextW(L"����Ӣ��Ѫ���ѵ���20%"));
					}
				}
				ui_render->SetTexture(ui_head_infoStreetBoy_Hp_Blue);
				ui_render->DrawWindow(Core::Rectangle(tempx-180+55+181+80*(1-fSc_2),tempy+67-6,tempx-180+55+308-47,tempy+79-6),Core::Rectangle(0,0,0,0),Core::Rectangle(0.f / 80.f, 0.f / 12.f, 0.f / 80.f, 0.f / 12.f));
			}
			else
			{
				laoda1Fiveflag = true;
				laoda1Twoflag = true;
				laoda2Fiveflag = true;
				laoda2Twoflag = true;
				laoda1win = true;
				laoda2win = true;
			}
		}
		else if(gLevel->game_type == RoomOption::kZombieMode)
		{
			_DrawNumberTextureWindow(ui_render, ui_head_info_time_number, Core::Vector2(tempx-28, tempy+10), 26, 33, gGame->scores->team_round[1],0.1f);
			_DrawNumberTextureWindow(ui_render, ui_head_info_time_number, Core::Vector2(tempx+72, tempy+10), 26, 33, gGame->scores->team_round[0],0.1f);
		}
		else if(gLevel->game_type == RoomOption::kBossMode2)
		{
			int round_time = gGame->round_time - 1;
			if (round_time < 0)
			{
				round_time = 0;
			}
			if (player->GetTeam() == 1)
			{
				_DrawNumberTextureWindow(ui_render, ui_head_info_round_boss_number, Core::Vector2(tempx-28, tempy-50), 26, 33, gGame->scores->team_round[1],0.1f);
				_DrawNumberTextureWindow(ui_render, ui_head_info_round_boss_number, Core::Vector2(tempx+72, tempy-50), 26, 33, gGame->scores->team_round[0],0.1f);
				ui_render->DrawStringShadow(ui_render->font_simhei_20, Core::ARGB(58,167,254), Core::ARGB(0,0,0), Core::ARGB(0,255,255,255),Core::Rectangle(tempx-50, 10, tempx+20, 20),gLang->GetTextW(L"BOSS"), Unit::kAlignCenterMiddle);
				ui_render->DrawStringShadow(ui_render->font_simhei_20,Core::ARGB(58,167,254), Core::ARGB(0,0,0), Core::ARGB(0,255,255,255),Core::Rectangle(-tempx - 20, 10, -tempx + 50, 20),gLang->GetTextW(L"����"), Unit::kAlignCenterMiddle);
				_DrawBossMode2HeadInfo(ui_render);
				ui_render->DrawStringShadow(ui_render->font_simhei_20, Core::ARGB(58,167,254), Core::ARGB(0,0,0), Core::ARGB(0,255,255,255),Core::Rectangle(tempx+20, tempy + 35, tempx+20, tempy + 45),gLang->GetTextW(L"��ĩ�ջ�����"), Unit::kAlignRightMiddle);
				if (round_time > 30)
				{
					_DrawNumberTextureWindow(ui_render, ui_head_info_round_boss_number, Core::Vector2(tempx+35, tempy+25), 26, 33, (round_time / 60) % 60 + 1,0.1f);
					ui_render->DrawStringShadow(ui_render->font_simhei_20, Core::ARGB(255,58,167,254), Core::ARGB(255,0,0,0), Core::ARGB(0,255,255,255),Core::Rectangle(tempx+70, tempy + 35, tempx+70, tempy + 45),gLang->GetTextW(L"����"), Unit::kAlignLeftMiddle);
				} 
				else if (round_time >= 10)
				{
					_DrawNumberTextureWindow(ui_render, ui_head_info_round_boss_number_r, Core::Vector2(tempx+22, tempy+25), 26, 33, round_time / 10 ,0.1f);
					_DrawNumberTextureWindow(ui_render, ui_head_info_round_boss_number_r, Core::Vector2(tempx+48, tempy+25), 26, 33, round_time % 10 ,0.1f);
					ui_render->DrawStringShadow(ui_render->font_simhei_20, Core::ARGB(255,58,167,254), Core::ARGB(255,0,0,0), Core::ARGB(0,255,255,255),Core::Rectangle(tempx+80, tempy + 35, tempx+80, tempy + 45),gLang->GetTextW(L"��"), Unit::kAlignLeftMiddle);
				}
				else
				{
					_DrawNumberTextureWindow(ui_render, ui_head_info_round_boss_number_r, Core::Vector2(tempx+35, tempy+25), 26, 33, round_time ,0.1f);
					ui_render->DrawStringShadow(ui_render->font_simhei_20, Core::ARGB(255,58,167,254), Core::ARGB(255,0,0,0), Core::ARGB(0,255,255,255),Core::Rectangle(tempx+70, tempy + 35, tempx+70, tempy + 45),gLang->GetTextW(L"��"), Unit::kAlignLeftMiddle);
				}
			} 
			else
			{
				_DrawNumberTextureWindow(ui_render, ui_head_info_time_number, Core::Vector2(tempx-28, tempy+10), 26, 33, gGame->scores->team_round[1],0.1f);
				_DrawNumberTextureWindow(ui_render, ui_head_info_time_number, Core::Vector2(tempx+72, tempy+10), 26, 33, gGame->scores->team_round[0],0.1f);
				_DrawCommonZombieHeadInfo(ui_render);
				ui_render->DrawStringShadow(ui_render->font_simhei_20, Core::ARGB(255,255,60,0), Core::ARGB(255,0,0,0), Core::ARGB(0,255,255,255),Core::Rectangle(tempx+20, tempy + 95, tempx+20, tempy + 105),gLang->GetTextW(L"��ĩ�ջ�����"), Unit::kAlignRightMiddle);
				if (round_time > 30)
				{
					_DrawNumberTextureWindow(ui_render, ui_head_info_round_boss_number, Core::Vector2(tempx+35, tempy+85), 26, 33, (gGame->round_time / 60) % 60 + 1,0.1f);
					ui_render->DrawStringShadow(ui_render->font_simhei_20, Core::ARGB(255,255,60,0), Core::ARGB(255,0,0,0), Core::ARGB(0,255,255,255),Core::Rectangle(tempx+70, tempy + 95, tempx+70, tempy + 105),gLang->GetTextW(L"����"), Unit::kAlignLeftMiddle);
				} 
				else if (round_time >= 10)
				{
					_DrawNumberTextureWindow(ui_render, ui_head_info_round_boss_number_r, Core::Vector2(tempx+22, tempy+85), 26, 33, round_time / 10 ,0.1f);
					_DrawNumberTextureWindow(ui_render, ui_head_info_round_boss_number_r,  Core::Vector2(tempx+48, tempy+85), 26, 33, round_time % 10 ,0.1f);
					ui_render->DrawStringShadow(ui_render->font_simhei_20, Core::ARGB(255,255,60,0), Core::ARGB(255,0,0,0), Core::ARGB(0,255,255,255),Core::Rectangle(tempx+80, tempy + 95, tempx+80, tempy + 105),gLang->GetTextW(L"��"), Unit::kAlignLeftMiddle);
				}
				else
				{
					_DrawNumberTextureWindow(ui_render, ui_head_info_round_boss_number_r,  Core::Vector2(tempx+35, tempy+85), 26, 33, round_time ,0.1f);
					ui_render->DrawStringShadow(ui_render->font_simhei_20, Core::ARGB(255,255,60,0), Core::ARGB(255,0,0,0), Core::ARGB(0,255,255,255),Core::Rectangle(tempx+70, tempy + 95, tempx+70, tempy + 105),gLang->GetTextW(L"��"), Unit::kAlignLeftMiddle);
				}
				
				if (round_time == 60)
				{
					m_Bottom_str[0] = Core::String::Format(gLang->GetTextW(L"ĩ��������Ҫ�����ˣ�����ֹBOSS��"));
					m_ShowBottom_str_time[0] = 3.0f;
				}
			}
			if (boss_mode2_minute_sound && round_time%60 != 0)
			{
				boss_mode2_minute_sound = false;
			}
			if (round_time == 10 && gLevel->boss_mode2_armor_warning)
			{
				gLevel->boss_mode2_armor_warning->start();
			}
			else if (!boss_mode2_minute_sound && round_time > 0 && (round_time%60 == 0 || round_time == 30))
			{
				FmodSystem::PlayEvent("bj/player/2d/armor_robot/armor_warning_single");
				boss_mode2_minute_sound = true;
			}
		}
		if(!gLevel->GetPlayer()->gamestart_ui && gLevel->GetPlayer()->gamestart_time > 0.00001f && gLevel->GetPlayer()->GetTeam() < 2)
		{
			gLevel->GetPlayer()->gamestart_time -= Task::GetFrameTime();
			ui_render->BeginInGameUI();
			world.SetTranslationXYZ(rt_size.x/2, rt_size.y/2, 0);
			ui_render->SetWorld(world);

			WCHAR wstr[128] = {0};
			tempc_ptr(Texture2D) temp = NullPtr;
			switch(gLevel->game_type)
			{
			case RoomOption::kTeam:
				{
					temp = ui_head_tip[0];
					wsprintf(wstr, L"����һ���㿴���ĵ���");
				}
				break;
			case RoomOption::kKnifeMode:
				{
					temp = ui_head_tip[0];	
					wsprintf(wstr, L"����һ���㿴���ĵ���");
				}
				break;
			case RoomOption::KMoonMode:
				{
					temp = ui_head_tip[0];	
					wsprintf(wstr, L"�򶥷��ʵ�ǰ5�������λ��֣����ָ߻�ʤ");
				}
				break;

			case RoomOption::kAdvenceMode:
				{
					temp = ui_head_tip[15];	
					wsprintf(wstr, L"������Ը�������������ı��������ȵ��ȵã�������꣡");
				}
				break;
			case RoomOption::kSurvivalMode:
				{
					temp = ui_head_tip[0];	
					wsprintf(wstr, L"������Դ����ȥ�����浽���Ķ����ʤ��");
				}
				break;
			case RoomOption::kHoldPoint:
				{
					temp = ui_head_tip[1];
					wsprintf(wstr, L"���Ʋ���סռ�㣬3��30��󼴿ɻ��ʤ��");
				}
				break;
			case RoomOption::kPushVehicle:
				{
					temp = ui_head_tip[2];
					wsprintf(wstr, L"���������Ƴ��Ƶ��յ㣬���ɻ��ʤ��");
					
				}
				break;
			case RoomOption::kTeamDeathMatch:
				{
					temp = ui_head_tip[3];
					wsprintf(wstr, L"����һ���㿴���ĵ���");
				}
				break;
			case RoomOption::kBoss:
				{
					temp = ui_head_tip[4];
					wsprintf(wstr, L"��BOSS������Ĵ��ս�д������");
				}
				break;
			case RoomOption::kBombMode:
				{
					if (gLevel->GetPlayer()->GetTeam() == 1 )
					{
						temp = ui_head_tip[5];
						wsprintf(wstr, L"�ɹ�ը��Ŀ������");
					} 
					else if (gLevel->GetPlayer()->GetTeam() == 0 )
					{
						temp = ui_head_tip[6];
						wsprintf(wstr, L"�ɹ�����Ŀ������");
					}
				}	
				break;
			case RoomOption::kStreetBoyMode:
				{
					temp = ui_head_tip[7];
					wsprintf(wstr, L"�ɵ��Է���Ӣ�ۣ������Ӣ��");
				}
				break;
			case RoomOption::kZombieMode:
				{					
					temp = ui_head_tip[8];		
					wsprintf(wstr, L"�ֵ�ס�����ߵĹ��ƣ�ֱ����Ԯֱ����������");
				}	
				break;
			case RoomOption::kBossPVE:
				{					
					temp = ui_head_tip[9];		
					wsprintf(wstr, L"��������BOSS");
				}	
				break;
			case RoomOption::kCommonZombieMode:
				{					
					temp = ui_head_tip[10];		
					wsprintf(wstr, L"������Ⱦģʽ");
				}	
				break;
			case RoomOption::kBossMode2:
				{					
					temp = ui_head_tip[11];		
					wsprintf(wstr, L"ĩ�ջ�������֮ǰ�������е�boss���ף�");
				}	
				break;
			case RoomOption::kItemMode:
				{					
					temp = ui_head_tip[12];		
					wsprintf(wstr, L"����ħ�������䣬ɱ������");
				}	
				break;
			case RoomOption::kEditMode:
				return;
			case RoomOption::kTDMode:
				{					
					if (gLevel->GetPlayer()->GetTeam() == 1 )
					{
						temp = ui_head_tip[14];
						wsprintf(wstr, L"�����ھ�����");
					} 
					else if (gLevel->GetPlayer()->GetTeam() == 0 )
					{
						temp = ui_head_tip[13];		
						wsprintf(wstr, L"�����з�ԭʯ�ھ�������������ԭʯ��");
					}
				}	
				break;
			default:
				break;
			}
			ui_render->DrawTextureWindow(Core::Vector2(-836/2, -300), 836, 382, temp);
			ui_render->DrawString(ui_render->font_simhei_48, Core::ARGB(0,0,0), Core::ARGB(0,0,0,0),Core::Rectangle(-250, -270, 250, -220),gLang->GetTextW(L"ʤ��Ŀ��"), Unit::kAlignCenterMiddle);
			ui_render->DrawString(ui_render->font_simhei_48, Core::ARGB(225,220,0), Core::ARGB(0,0,0,0),Core::Rectangle(-253, -273, 247, -223),gLang->GetTextW(L"ʤ��Ŀ��"), Unit::kAlignCenterMiddle);
			

			ui_render->DrawString(ui_render->font_simhei_24, Core::ARGB(0, 0, 0), Core::ARGB(0,0,0,0),Core::Rectangle(-rt_size.x/2, 37, rt_size.x/2, 67),gLang->GetTextW(wstr), Unit::kAlignCenterMiddle);
			ui_render->DrawString(ui_render->font_simhei_24, Core::ARGB(255, 255, 255), Core::ARGB(0,0,0,0),Core::Rectangle(-rt_size.x/2-2, 35, rt_size.x/2-2,65),gLang->GetTextW(wstr), Unit::kAlignCenterMiddle);
		}
	}
}

void InGameUINew::_DrawCommonZombieHeadInfo(by_ptr(UIRender) ui_render)
{
	Game * game = gGame;
	int t_y = 65;
	ui_render->DrawTextureWindow(Core::Vector2(-232,t_y),464,28,ui_commonzombie_head_bg);
	ui_render->DrawTextureWindow(Core::Vector2(15,t_y - 2),32,32,ui_commonzombie_bottom_People);
	if (gLevel->game_type == RoomOption::kBossMode2)
	{
		ui_render->DrawTextureWindow(Core::Vector2(-40,t_y - 2),32,32,ui_Boss_mode2_Boss);
	} 
	else
	{
		ui_render->DrawTextureWindow(Core::Vector2(-40,t_y - 2),32,32,ui_commonzombie_bottom_Corpse);
	}
	int _index = 0;
	for (uint rank = 0 ; rank < game->scores->teams[1].Size() ; rank++)
	{
		Character * c = game->scores->teams[1][rank];
		if (c && !c->IsDied())
		{
			ui_render->DrawTextureWindow(Core::Vector2(-65 - 18*_index,t_y + 5),17,18,ui_commonzombie_bottom_Corpse_ico);
			_index++;
		}
	}
	_index = 0;
	for (uint rank = 0 ; rank < game->scores->teams[0].Size() ; rank++)
	{
		Character * c = game->scores->teams[0][rank];
		if (c && !c->IsDied())
		{
			ui_render->DrawTextureWindow(Core::Vector2(50 + 18*_index,t_y + 5),17,18,ui_commonzombie_bottom_People_ico);
			_index++;
		}
	}
}

void InGameUINew::_DrawBossMode2HeadInfo(by_ptr(UIRender) ui_render)
{
	Game * game = gGame;
	int t_y = 90;	
	int life_num = 0,die_num = 0;
	for (uint rank = 0 ; rank < game->scores->teams[1].Size() ; rank++)
	{
		Character * c = game->scores->teams[1][rank];
		if (c && !c->IsDied())
		{
			life_num++;
		}
		else
		{
			die_num++;
		}
	}
	_DrawBossMode2_Box(ui_render,Core::Vector2(-75,t_y),Core::Vector2(16,16),Core::Vector2(-15,0),life_num,die_num,ui_Boss_mode2_box_life,ui_Boss_mode2_box_die);
	life_num = 0;
	die_num = 0;
	for (uint rank = 0 ; rank < game->scores->teams[0].Size() ; rank++)
	{
		Character * c = game->scores->teams[0][rank];
		if (c && !c->IsDied())
		{
			life_num++;
		}
		else
		{
			die_num++;
		}
	}
	_DrawBossMode2_Box(ui_render,Core::Vector2(55,t_y),Core::Vector2(16,16),Core::Vector2(15,0),life_num,die_num,ui_Boss_mode2_box_life,ui_Boss_mode2_box_die);
}

void InGameUINew::_DrawBossMode2_Box(by_ptr(UIRender) ui_render,Core::Vector2 pos,Core::Vector2 _size,Core::Vector2 space,int life_num,int die_num,by_ptr(Texture2D) texture_content,by_ptr(Texture2D) texture_cancel)
{
	for (int i = 0 ; i < life_num ; i++)
	{
		ui_render->DrawTextureWindow(pos + i*space,_size.x,_size.y,texture_content);
	}
	if (texture_cancel)
	{
		for (int i = 0 ; i < die_num ; i++)
		{
			ui_render->DrawTextureWindow(pos + (i + life_num)*space,_size.x,_size.y,texture_cancel);
		}
	}
}

void InGameUINew::_Draw_Picture_Move_uv(by_ptr(UIRender) ui_render)
{
	if (gLevel->game_type != RoomOption::kBossMode2)
	{
		return;
	}
	tempc_ptr(Character) viewer = gLevel->GetViewer();
	if (!viewer || !viewer->character_info || viewer->IsDied() || viewer->GetTeam() > 1)
	{
		return;
	}
	Matrix44 world;
	Matrix44 oldworld;
	Matrix44 oldview;
	Matrix44 view;
	Vector3 rt_size = gGame->guiSys->GetSize();
	world = Core::Matrix44::kIdentity;
	oldworld = ui_render->GetWorld();
	oldview  = ui_render->GetView();

	view.SetScaleXYZ(2.0f/rt_size.x, -2.0f/rt_size.y, 0);
	ui_render->SetView(view);
	world.SetTranslationXYZ(0, 0, 0);
	ui_render->SetWorld(world);

	if (viewer->GetTeam() == 0)
	{
		if (viewer->character_info->career_id == gLevel->boss2_sp_career_id[0] || viewer->character_info->career_id == gLevel->boss2_sp_career_id[1])
		{
			if (viewer->is_point_emeny)
			{
				ui_render->DrawTextureWindow(Core::Vector2(-256,-256),512,512,ui_Boss_mode2_cannon_crosshair_r);
			} 
			else
			{
				ui_render->DrawTextureWindow(Core::Vector2(-256,-256),512,512,ui_Boss_mode2_cannon_crosshair);
			}
			ui_render->SetTexture(ui_Boss_mode2_boss_scale_uv_Center);
			ui_render->DrawRectangleRadian(Core::Rectangle(-256,-256,256,256),Core::Vector2(0,0),Core::Rectangle(0,0,1,1),CalcHoriAngleTextureUV());
		} 
		else if (viewer->character_info->career_id == gLevel->boss2_sp_career_id[2] || viewer->character_info->career_id == gLevel->boss2_sp_career_id[3])
		{
			if (viewer->is_point_emeny)
			{
				ui_render->DrawTextureWindow(Core::Vector2(-300,-300),600,600,ui_Boss_mode2_airplane_crosshair_r);
			} 
			else
			{
				ui_render->DrawTextureWindow(Core::Vector2(-300,-300),600,600,ui_Boss_mode2_airplane_crosshair);
			}
			Vector2 v = CalcVertAngleTextureUV();
			int tex_width = ui_Boss_mode2_boss_scale_uv_left->GetWidth();
			int tex_height = ui_Boss_mode2_boss_scale_uv_left->GetHeight();
			ui_render->DrawTextureWindow(Core::Vector2(-230 - tex_width,-198),tex_width,tex_height*4/9,ui_Boss_mode2_boss_scale_uv_left,Core::Rectangle(0,v.x,1,v.y));
			ui_render->DrawTextureWindow(Core::Vector2(230,-198),tex_width,tex_height*4/9,ui_Boss_mode2_boss_scale_uv_right,Core::Rectangle(0,v.x,1,v.y));
			F32 f_u = (CalcHoriAngleTextureUV() / Core::PI + 1.0f) / 2;
			F32 f_u_shart = 0.0f;
			F32 f_u_end = 0.0f;
			if (f_u > 0.5f)
			{
				f_u_shart = f_u - 0.5f;
				f_u_end = f_u;
			}
			else
			{
				f_u_shart = f_u;
				f_u_end = f_u + 0.5f;
			}
			ui_render->DrawTextureWindow(Core::Vector2(-150,-271),300,35,ui_Boss_mode2_boss_scale_uv_Top,Core::Rectangle(f_u_shart,0,f_u_end,1));
		}
	} 
	else if (viewer->GetTeam() == 1 && viewer->is_boss)
	{
		if (viewer->is_point_emeny)
		{
			ui_render->DrawTextureWindow(Core::Vector2(-300,-300),600,600,ui_Boss_mode2_boss_crosshair_r);
		} 
		else
		{
			ui_render->DrawTextureWindow(Core::Vector2(-300,-300),600,600,ui_Boss_mode2_boss_crosshair);
		}
		F32 f_u = (CalcHoriAngleTextureUV() / Core::PI + 1.0f) / 2;
		F32 f_u_shart = 0.0f;
		F32 f_u_end = 0.0f;
		if (f_u > 0.5f)
		{
			f_u_shart = f_u - 0.5f;
			f_u_end = f_u;
		}
		else
		{
			f_u_shart = f_u;
			f_u_end = f_u + 0.5f;
		}
		ui_render->DrawTextureWindow(Core::Vector2(-110,-302),220,30,ui_Boss_mode2_boss_scale_uv_Top,Core::Rectangle(f_u_shart,0,f_u_end,1));
	}
	ui_render->SetWorld(oldworld);
	ui_render->SetView(oldview);
}

void InGameUINew::_DrawBottomInfo(by_ptr(UIRender) ui_render)
{
	if (RoomOption::kEditMode == gLevel->game_type)
		return;
	Core::Vector3 rt_size = gGame->guiSys->GetSize();
	current_screen_width_level = rt_size.x / 1600.0f;
	current_screen_height_level = rt_size.y / 1200.0f;

	tempc_ptr(Character) viewer = gLevel->GetViewer();
	tempc_ptr(Character) player = gLevel->GetPlayer();
	tempc_ptr(WeaponBase) weapon;

	if (!viewer)
		return;

	if (gLevel->GetPlayer()->IsDied())
		return;

	if (gLevel->game_type == RoomOption::kBossMode2 && player->GetTeam() == 1)
	{
		return;
	}

	Core::ARGB font_color = Core::ARGB(255, 241, 211);
	Core::ARGB power_color = Core::ARGB(255,255,255,255);
	Core::ARGB bullet_color = Core::ARGB(255,255,255,255);
	Core::ARGB bg_color = Core::ARGB(255,255,255,255);
	Core::CStrBuf<256> buff;

	Matrix44 world,view;
	bool isshow = false;
	if (viewer->state_addbloodformcure)
	{
		if ((int)(Task::GetTotalTime() * 4) & 1)
		{
			bg_color = ARGB(0, 255, 0);
		}
	}
	else  if (viewer->hp > 0 && viewer->max_hp > 0 && viewer->hp < viewer->max_hp * 0.3f)
	{
		if ((int)(Task::GetTotalTime() * 4) & 1)
		{
			isshow = true;
			bg_color = ARGB(201, 49, 49);
		}
	}

	if((gLevel->game_type == RoomOption::kNovice && gLevel->novice_index >= 5) || gLevel->game_type != RoomOption::kNovice)
	{
		if (viewer && viewer->GetCurCharinfo())
		{
			view.SetScaleXYZ(2.0f/rt_size.x, -2.0f/rt_size.y, 0);
			ui_render->SetView(view);

			/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			world.SetTranslationXYZ(-(rt_size.x/2), rt_size.y/2, 0);
			ui_render->SetWorld(world);
			Character * boss = NULL;
			if (gGame->scores && gGame->scores->teams[1].Size() > 0)
			{
				boss = gGame->scores->teams[1][0];
			}
			int left_x = 10;
			int left_y = -102;
			//left bottom
			if ((int)gLevel->rule_value - (int)gGame->scores->team_kills[0] <= 15 || (int)gLevel->rule_value - (int)gGame->scores->team_kills[1] <= 15 )
			{

			}
			else
			{
				//chenji
				if (gLevel->GetPlayer()&&gLevel->GetPlayer()->is_item_boss)
				{
					CStrBuf<256> buff;
					buff.format("%d",(int)gLevel->GetPlayer()->itemmode_flag1_timer);
					ui_render->DrawStringShadow(ui_render->font_simhei_24, ARGB(255,229,51), ARGB(0,0,0), ARGB(0, 0, 0, 0), Core::Rectangle(left_x+20, left_y-65 , left_x+20+100, left_y-65+20), gLang->GetTextW(L"ʣ�ࣺ"), Unit::kAlignLeftMiddle);
					//if (gLevel->GetPlayer()->itemmode_flag1_timer > 9)
					//{
						_DrawNumberTextureWindow(ui_render, ui_boss_num, Core::Vector2(left_x+80, left_y-70), 29, 34, (int)(gLevel->GetPlayer()->itemmode_flag1_timer/10), 0.1f);
						_DrawNumberTextureWindow(ui_render, ui_boss_num, Core::Vector2(left_x+80+29, left_y-70), 29, 34, (int)(gLevel->GetPlayer()->itemmode_flag1_timer)%10, 0.1f);
					//}
					//else
					//{
					//	_DrawNumberTextureWindow(ui_render, ui_boss_num, Core::Vector2(left_x+70, left_y-70), 29, 34, (int)gLevel->GetPlayer()->itemmode_flag1_timer + 1, 0.1f);
					//}
				}
			}
			if(gLevel->game_type == RoomOption::KMoonMode && gLevel->GetPlayer() && gLevel->GetPlayer()->is_item_boss)
			{
				CStrBuf<256> buff;
				buff.format("%d",(int)gLevel->GetPlayer()->itemmode_flag1_timer);
				ui_render->DrawStringShadow(ui_render->font_simhei_24, ARGB(255,229,51), ARGB(0,0,0), ARGB(0, 0, 0, 0), Core::Rectangle(left_x+20, left_y-65 , left_x+20+100, left_y-65+20), gLang->GetTextW(L"ʣ�ࣺ"), Unit::kAlignLeftMiddle);
				_DrawNumberTextureWindow(ui_render, ui_boss_num, Core::Vector2(left_x+80, left_y-70), 29, 34, (int)(gLevel->GetPlayer()->itemmode_flag1_timer/10), 0.1f);
				_DrawNumberTextureWindow(ui_render, ui_boss_num, Core::Vector2(left_x+80+29, left_y-70), 29, 34, (int)(gLevel->GetPlayer()->itemmode_flag1_timer)%10, 0.1f);
			}
			if ((gLevel->game_type == RoomOption::kBoss && boss == gLevel->GetPlayer())||(gLevel->game_type == RoomOption::kZombieMode && gLevel->GetPlayer()->GetTeam() == 1))
			{
				ui_render->DrawTextureWindow(Core::Vector2(left_x, left_y), 237, 100, ui_bottomleft_info_boos);
			}
			else
			{
				ui_render->DrawTextureWindow(Core::Vector2(left_x, left_y), 225, 91, ui_bottomleft_info_bg[viewer->GetTeam()]);
			}

			//head icon
			if (gLevel->game_type == RoomOption::kBoss && boss == gLevel->GetPlayer())
			{
				ui_render->DrawTextureWindow(Core::Vector2(left_x-25,left_y-28), 140, 100, ui_headicon_boos);
			}
			else
			{
				uint career_id = viewer->GetCurCharinfo()->career_id;
				tempc_ptr(Texture2D) head_texture = (viewer->ui_head_icon);
				if (head_texture)
					ui_render->DrawTextureWindow(Core::Vector2(left_x + 8, left_y - 28), 72, 100, head_texture);
				float fSc = (float)viewer->hp / viewer->max_hp;
				fSc = Core::Clamp(fSc,0,1);
				fSc = 1-fSc;
				tempc_ptr(Texture2D) headhui_texture = ui_bottom_info_headhui_icon.Get(career_id, NullPtr);
				if (headhui_texture)
					ui_render->DrawTextureWindow(Core::Vector2(left_x + 8, left_y - 28), 72, 100*fSc, headhui_texture, Core::Rectangle(0,0,1,fSc));

				tempc_ptr(Texture2D) headbinsi_texture = ui_bottom_info_headbinsi_icon.Get(career_id, NullPtr);
				if (headbinsi_texture)
				{
					if (!isshow)
						ui_render->DrawTextureWindow(Core::Vector2(left_x + 8, left_y - 28), 72, 100*fSc, headbinsi_texture, Core::Rectangle(0,0,1,fSc),Core::ARGB(127,0,0,0));
					else
						ui_render->DrawTextureWindow(Core::Vector2(left_x + 8, left_y - 28), 72, 100*fSc, headbinsi_texture, Core::Rectangle(0,0,1,fSc));
				}
			}

			//life
			if (gLevel->game_type == RoomOption::kBoss && boss == gLevel->GetPlayer())
			{
				;
			}
			else if (gLevel->game_type == RoomOption::kCommonZombieMode && player->GetTeam() == 0)
			{
				float hp_f = (float)viewer->hp/viewer->max_hp;
				if (hp_f > 1.0f)
				{
					hp_f = 1.0f;
				}
				ui_render->DrawTextureWindow(Core::Vector2(left_x + 85, left_y + 44), 108, 28, ui_commonzombie_People_hp_bg,Core::Rectangle(0,0,1,1));
				ui_render->DrawTextureWindow(Core::Vector2(left_x + 85, left_y + 44), 108*hp_f, 28, ui_commonzombie_People_hp_bf,Core::Rectangle(0,0,hp_f,1));
			}
			else
			{
				//����ֵ
				int temp_hp = viewer->hp;
				temp_hp = temp_hp > 9999 ? 9999 : temp_hp;
				ui_render->DrawTextureWindow(Core::Vector2(left_x + 78, left_y + 37), 25, 26, ui_bottom_info_hp_add,Core::Rectangle(0,0,1,1),bg_color);
				int num = 0;
				int x = 0;
				Core::String s = Core::String::Format("%d",temp_hp);
				int x_len = s.Length()-1;
				while (temp_hp)
				{							
					num = temp_hp%10;
					ui_render->DrawTextureWindow(Core::Vector2(((left_x+103)+22*x_len)-22*x, left_y+34), 22, 34, ui_bottom_info_hp_number ,Core::Rectangle(num*22/220.0f, 0, (num+1)*22/220.0f, 1),bg_color);
					temp_hp /= 10;
					x++;				
				}
			}
			if (player && player->ui_score_line > ui_score_line && !Card_Play)
			{
				SetCard_State(player->ui_score_line);
				Card_Play = true;
			}
			if (ui_score_line >= 0)
			{
				switch (ui_score_line)
				{
				case 0:
					{
						ui_render->DrawTextureWindow(Core::Vector2(left_x + 211, left_y + 54), 36, 40.5, ui_bottom_info_small_card);
						ui_render->DrawTextureWindow(Core::Vector2(left_x + 251, left_y + 54), 36, 40.5, ui_bottom_info_small_card);
						ui_render->DrawTextureWindow(Core::Vector2(left_x + 291, left_y + 54), 36, 40.5, ui_bottom_info_small_card);
					}
					break;
				case 1:
					{
						ui_render->DrawTextureWindow(Core::Vector2(left_x + 211, left_y + 50), 36, 40.5, ui_bottom_info_big_card);
						ui_render->DrawTextureWindow(Core::Vector2(left_x + 251, left_y + 54), 36, 40.5, ui_bottom_info_small_card);
						ui_render->DrawTextureWindow(Core::Vector2(left_x + 291, left_y + 54), 36, 40.5, ui_bottom_info_small_card);
					}
					break;
				case 2:
					{
						ui_render->DrawTextureWindow(Core::Vector2(left_x + 211, left_y + 50), 36, 40.5, ui_bottom_info_big_card);
						ui_render->DrawTextureWindow(Core::Vector2(left_x + 251, left_y + 50), 36, 40.5, ui_bottom_info_big_card);
						ui_render->DrawTextureWindow(Core::Vector2(left_x + 291, left_y + 54), 36, 40.5, ui_bottom_info_small_card);
					}
					break;
				case 3:
					{
						ui_render->DrawTextureWindow(Core::Vector2(left_x + 211, left_y + 50), 36, 40, ui_bottom_info_big_card);
						ui_render->DrawTextureWindow(Core::Vector2(left_x + 251, left_y + 50), 36, 40, ui_bottom_info_big_card);
						ui_render->DrawTextureWindow(Core::Vector2(left_x + 291, left_y + 50), 36, 40, ui_bottom_info_big_card);
					}
					break;
				}
// 				ui_render->DrawTextureWindow(Core::Vector2(left_x + 241, left_y + 74), 16, 16, ui_bottom_info_X);
// 				_DrawNumberTextureWindow(ui_render, ui_bottom_info_hp_number, Core::Vector2(left_x + 259, left_y + 65), 18, 28, player->ui_score_line % 10, 0.1f);
			}

			//only KItemMode
			//if (gLevel->game_type == RoomOption::kItemMode)
			//{
			//	ui_render->DrawTextureWindow(Core::Vector2(left_x + 211, left_y), 36, 40, ui_bottom_info_big_card);
			//}

			//middle info  only ZOMBIE
			if (gLevel->game_type == RoomOption::kZombieMode)
			{
				int people_num = gGame->scores->teams[0].Size();
				int zombie_num = gGame->scores->teams[1].Size();

				if (gLevel->GetPlayer()->GetTeam() == 0 && gLevel->boss_starttimeer <= 0)
				{
					int n = 0;
					for(int i = 0;i < people_num;i++)
					{
						Character * c = gGame->scores->teams[0][i];	
						
						if (c)
						{
							if (c != viewer && !c->IsDied())
							{
								ui_render->DrawTextureWindow(Core::Vector2((left_x+337)+202*n, left_y+20), 212, 74, ui_bottommiddle_info_people);
								Core::CStrBuf<256> buff;
								
								if (c->GetCurCharinfo())
								{
									//draw ����ս����
									sharedc_ptr(CharacterInfo) info = c->GetCurCharinfo();
									if (info)
									{
										int power = info->combat_power;
										int num = 0;
										int x = 0;
										if(power < 99999)
										{
											while (power)
											{					
												num = power%10;
												ui_render->DrawTextureWindow(Core::Vector2(((left_x + 488)-12.8*x)+202*n, left_y+70), 12.8, 16, ui_power_num ,Core::Rectangle(num*12.8/128.0f, 0, (num+1)*12.8/128.0f, 1));
												power /= 10;
												x++;				
											}
										}	
									}
									
									//draw ����ͷ��
									uint career_id = c->GetCurCharinfo()->career_id;
									tempc_ptr(Texture2D) head_texture = c->ui_head_icon;
									if (head_texture)
										ui_render->DrawTextureWindow(Core::Vector2((left_x+358)+202*n, left_y+30), 37, 52, head_texture);
								}

								float progress = Core::Clamp((float)c->hp / (float)c->max_hp, 0, 1);
								//draw ���ѱ�����Ѫ��
								if(c->zombie_dying_flag == 1)
								{
									ui_render->SetTexture(ui_common_hp[2]);
									ui_render->DrawWindow(Core::Rectangle((left_x+446)+202*n,left_y+58,(left_x+446+58*progress)+202*n,left_y+68),
										Core::Rectangle(5,3,5,3),Core::Rectangle(5 / 32.f, 3.f / 16.f, 5 / 32.f, 3.f / 16.f));
								}
								else
								{
									//draw ����Ѫ��
									if (progress > 0.6f)
										ui_render->SetTexture(ui_common_hp[0]);
									else if (progress > 0.3f)
										ui_render->SetTexture(ui_common_hp[1]);
									else
										ui_render->SetTexture(ui_common_hp[2]);

									if(c->hp != 0)
										ui_render->DrawWindow(Core::Rectangle((left_x+446)+202*n,left_y+46,(left_x+446+58*progress)+202*n,left_y+56),
										Core::Rectangle(5,3,5,3),Core::Rectangle(5 / 32.f, 3.f / 16.f, 5 / 32.f, 3.f / 16.f));
									ui_render->SetTexture(ui_common_hp[2]);
									ui_render->DrawWindow(Core::Rectangle((left_x+446)+202*n,left_y+58,(left_x+446+58)+202*n,left_y+68),
										Core::Rectangle(5,3,5,3),Core::Rectangle(5 / 32.f, 3.f / 16.f, 5 / 32.f, 3.f / 16.f));
								}

								// draw ��������
								buff.format("%s",c->GetName().Str());
								ui_render->DrawFontWindow(Core::Vector2((left_x+408)+202*n, left_y+25), 150, 20, ui_render->font_simhei_12, Core::ARGB(255, 238, 206),  Core::ARGB(0, 0, 0, 0), buff, Unit::kAlignLeftTop);
								if (c != viewer && c->zombie_dying_flag == 1 && player->zombie_dying_flag == 0)
								{
									buff.format(gLang->GetTextW(L"��Ķ���%s�����ˣ���ȥ������"),c->GetName().Str());
									ui_render->DrawFontWindow(Core::Vector2(left_x+450,(left_y-234)-n*20), 150, 20, ui_render->font_simhei_16, Core::ARGB(255, 254, 198, 49),  Core::ARGB(0, 0, 0, 0), buff, Unit::kAlignLeftTop);
								}
								n++;
							}
							if(c == viewer && c->zombie_dying_flag == 1)
							{
								ui_render->SetTexture(ui_bomb_defuse_course);
								ui_render->DrawWindow(Core::Rectangle(left_x+450,left_y-190,left_x+450+288,left_y-190+56),Core::Rectangle(26,0,26,0),Core::Rectangle(26.f/92.f,0.f/64.f,26.f/92.f,0.f/64.f));
								float progress = Core::Clamp((float)c->hp / (float)c->max_hp, 0, 1);

								ui_render->SetTexture(ui_zombie_poeple_hp_bar);
								if(c->hp != 0)
								{
									ui_render->DrawWindow(Core::Rectangle((left_x+464),left_y-176,(left_x+464+257*progress),left_y-150),
									Core::Rectangle(20,10,20,10),Core::Rectangle(20 / 257.f, 10.f / 24.f, 20 / 257.f, 10.f / 24.f));
									ui_render->DrawTextureWindow(Core::Vector2((left_x+464+231)-(1 - progress)*257,left_y-190),52,52,ui_zombie_poeple_bar_icon);
								}
								ui_render->DrawFontWindow(Core::Vector2(left_x, left_y-130), rt_size.x-10, 30,ui_render->font_simhei_20, Core::ARGB(255, 128, 4),  Core::ARGB(0, 0, 0, 0), gLang->GetTextW(L"�㴦�ڱ���״̬����ͬ������Ԯǰ�����ս����"), Unit::kAlignCenterTop);
								ui_render->DrawFontWindow(Core::Vector2(left_x+600, left_y-90), 400, 30,ui_render->font_simhei_20, Core::ARGB(255, 128, 4),  Core::ARGB(0, 0, 0, 0), gLang->GetTextW(L"���"), Unit::kAlignLeftMiddle);
								if(c->zombie_saver_uid != 0)
								{
									tempc_ptr(Character) from_c = gLevel->GetCharacter(c->zombie_saver_uid);
									buff.format(gLang->GetTextW(L"�����ڱ�����%s����..."),from_c->GetName().Str());
									ui_render->DrawFontWindow(Core::Vector2(left_x+450,left_y-214), 150, 20, ui_render->font_simhei_16, Core::ARGB(0, 238, 0),  Core::ARGB(0, 0, 0, 0), buff, Unit::kAlignLeftTop);
								}
								b_time += Task::GetFrameTime()*4;
								float src = Core::Sin(b_time);
								b_time = b_time > 36000.f ? 0.f : b_time;
								ui_render->DrawTextureWindow(Core::Vector2((left_x+500)-4*src,(left_y-100)-4*src),60+8*src,60+8*src,ui_f);
							}
							if (c && c == player && c->GetTeam() == 0 && !c->IsDied() && c->zombie_dying_flag == 0 && c->zombie_saving_uid == 0 && _GetDrawHelpPeopleUI())
							{
								ui_render->DrawFontWindow(Core::Vector2(left_x, left_y-130), rt_size.x-10, 30,ui_render->font_simhei_20, Core::ARGB(255, 128, 4),  Core::ARGB(0, 0, 0, 0), gLang->GetTextW(L"��Ķ��Ѵ��ڱ���״̬��"), Unit::kAlignCenterMiddle);
								ui_render->DrawFontWindow(Core::Vector2(left_x+600, left_y-90), 400, 30,ui_render->font_simhei_20, Core::ARGB(255, 128, 4),  Core::ARGB(0, 0, 0, 0), gLang->GetTextW(L"��������"), Unit::kAlignLeftMiddle);
								b_time += Task::GetFrameTime()*4;
								float src = Core::Sin(b_time);
								b_time = b_time > 36000.f ? 0.f : b_time;
								ui_render->DrawTextureWindow(Core::Vector2((left_x+500)-4*src,(left_y-100)-4*src),60+8*src,60+8*src,ui_e);

							}
							if(c && c == viewer && c->zombie_saving_uid != 0 && c->zombie_saving_timer != -1 && c->zombie_dying_flag == 0 && c->zombie_saving_flag != 0)
							{
								float saving_time = 0.f;
								saving_time = c->zombie_saving_timer/3;
								ui_render->SetTexture(ui_bomb_defuse_course);
								ui_render->DrawWindow(Core::Rectangle(left_x+450,left_y-190,left_x+450+288,left_y-190+56),Core::Rectangle(26,0,26,0),Core::Rectangle(26.f/92.f,0.f/64.f,26.f/92.f,0.f/64.f));
								ui_render->DrawTextureWindow(Core::Vector2(left_x+464,left_y-176),20.f + 237.f*(1-saving_time),28,ui_bomb_defuse_course_In,Core::Rectangle(0,0,(20.f + (1-saving_time)*237.f)/255.f,1));
								ui_render->DrawTextureWindow(Core::Vector2((left_x+464) + (1-saving_time)*226,left_y-184),40,41,ui_bomb_defuse_course_Point);
								if (gLevel->saveplayer)
								{
									buff.format(gLang->GetTextW(L"�����ھ�������%s..."),gLevel->saveplayer->GetName().Str());
									ui_render->DrawFontWindow(Core::Vector2(left_x+450,left_y-214), 150, 20, ui_render->font_simhei_16, Core::ARGB(255, 238, 206),  Core::ARGB(0, 0, 0, 0), buff, Unit::kAlignLeftTop);
								}							
								if (saving_time < 0)
								{
									c->zombie_saving_flag =  false;
								}
							}
						}															
					}
					
					if (gLevel->isCanActiveGate)
					{	
						if (gLevel->isZombieText_show)
						{
							gLevel->isZombieText_show = false;
							viewer->show_text_time = 5;
						}
						if (viewer->show_text_time > 0 )
						{
							ui_render->DrawFontWindow(Core::Vector2(left_x+350, left_y-15), 440, 30, ui_render->font_simhei_24, Core::ARGB(240, 180, 48),  Core::ARGB(0, 0, 0, 0), gLang->GetTextW(L"����ľ�Ԯֱ�����Ѿ����䣡"), Unit::kAlignLeftTop);
						}						
						ui_render->DrawFontWindow(Core::Vector2(left_x+417, left_y-55), 156, 28,ui_render->font_simhei_24, Core::ARGB(240, 180, 48),  Core::ARGB(0, 0, 0, 0), gLang->GetTextW(L"����ʱ�����ƣ�"), Unit::kAlignRightTop);
						_DrawRoundTimeShow(ui_render,left_x,left_y-41);
					}
				}
				if (gLevel->GetPlayer()->GetTeam() == 1)
				{
					ui_render->DrawFontWindow(Core::Vector2(left_x+357, left_y), 200, 30, ui_render->font_simhei_22, Core::ARGB(255, 238, 206),  Core::ARGB(0, 0, 0, 0), gLang->GetTextW(L"�������������ߣ�"), Unit::kAlignLeftTop);
					for(int i = 0;i < zombie_num;i++)
					{
						Character * z = gGame->scores->teams[1][i];
						if (z->GetCurCharinfo())
						{
							uint career_id = z->GetCurCharinfo()->career_id;
							tempc_ptr(Texture2D) head_texture = z->ui_head_icon;
							if (head_texture)
								ui_render->DrawTextureWindow(Core::Vector2((left_x+357)+43*i, left_y+30), 43, 61,head_texture);
						}
					}
					if ( gLevel->isCanActiveGate)
					{
						ui_render->DrawFontWindow(Core::Vector2(left_x+2, left_y-30), rt_size.x, 30, ui_render->font_simhei_22, Core::ARGB(0, 0, 0),  Core::ARGB(0, 0, 0, 0), gLang->GetTextW(L"����ľ�Ԯֱ�����Ѿ����䣬��ֹ���ൽ�ｵ��㣡"), Unit::kAlignCenterTop);
						ui_render->DrawFontWindow(Core::Vector2(left_x, left_y-30), rt_size.x, 30, ui_render->font_simhei_22, Core::ARGB(240, 180, 48),  Core::ARGB(0, 0, 0, 0), gLang->GetTextW(L"����ľ�Ԯֱ�����Ѿ����䣬��ֹ���ൽ�ｵ��㣡"), Unit::kAlignCenterTop);
						ui_render->DrawFontWindow(Core::Vector2(left_x+400, left_y-70), 156, 28,ui_render->font_simhei_24, Core::ARGB(240, 180, 48),  Core::ARGB(0, 0, 0, 0), gLang->GetTextW(L"����ʱ�����ƣ�"), Unit::kAlignRightTop);
						_DrawRoundTimeShow(ui_render,left_x,left_y-56);
					}
				}
			}

			if (gLevel->game_type == RoomOption::kEditMode)
			{
				tempc_ptr(Character) c = gLevel->GetPlayer();
					
				float distance = 2.f;
				NxRay ray;
				ray.orig = (const NxVec3 &)c->GetCameraPosition();
				ray.dir = (const NxVec3 &)(Vector3(0, 0, -1) * c ->GetCameraRotation());

				NxRaycastHit hit;

				uint group_id = 0;
				group_id |= 1 << PhysxSystem::kStatic;

				NxShape* shape = gPhysxScene->raycastClosestShape(ray, NX_ALL_SHAPES, hit, group_id, distance);

				if (shape)
				{
					NxActor& actor = shape->getActor();
					tempc_ptr(DummyObject) p = DummyObject::FromNxActor(actor);
					if (p && p->sub_type != 4)
					{
						_DrawCancelTowerGun(ui_render);
					}
				}
			}

			/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			//right info
			world = Matrix44::kIdentity;
			world.SetTranslationXYZ(rt_size.x/2, rt_size.y/2, 0);
			ui_render->SetWorld(world);
			int right_x = -165;
			int right_y = -59;

			if ((gLevel->game_type == RoomOption::kBoss && boss == gLevel->GetPlayer()) || (gLevel->game_type == RoomOption::kZombieMode && gLevel->GetPlayer()->GetTeam() == 1))
			{
				ui_render->DrawTextureWindow(Core::Vector2(right_x, right_y), 163, 48, ui_bottomright_info_boos);
			}
			else
			{
				ui_render->DrawTextureWindow(Core::Vector2(right_x, right_y), 163, 48, ui_bottomright_info_bg[viewer->GetTeam()]);
			}
			
			//�ӵ���Ŀ
			weapon = viewer->GetWeapon();
			if (weapon && viewer == player)
			{
				tempc_ptr(Character) player = gLevel->GetPlayer();
				if(!player)
					return;
				tempc_ptr(Character) owner = weapon->GetOwner();
				if (owner)
				{
					if (ptr_dynamic_cast<GunBase>(weapon))
					{
						int max_count = Clamp((U32)ptr_dynamic_cast<GunBase>(weapon)->max_ammo_count, 0, 999);
						int max_in_clip = Clamp((U32)ptr_dynamic_cast<GunBase>(weapon)->max_ammo_in_clip, 0, 999);
						if (max_count > 0)
						{
							int bulletCount = Clamp((U32)ptr_dynamic_cast<GunBase>(weapon)->ammo_in_clip,0,999);

							_DrawNumberTextureWindow(ui_render, ui_bottom_info_bullet_number, Core::Vector2(right_x+41, right_y-9), 29, 45, (bulletCount % 100) / 10, 0.1f);
							_DrawNumberTextureWindow(ui_render, ui_bottom_info_bullet_number, Core::Vector2(right_x+12, right_y-9), 29, 45, bulletCount / 100, 0.1f);
							_DrawNumberTextureWindow(ui_render, ui_bottom_info_bullet_number, Core::Vector2(right_x+70, right_y-9), 29, 45, bulletCount % 10, 0.1f);

							bulletCount = Clamp((U32)ptr_dynamic_cast<GunBase>(weapon)->ammo_count,0,999);

							if ((float)bulletCount / (float)ptr_dynamic_cast<GunBase>(weapon)->max_ammo_count < 0.3)
							{
								if ((int)(Task::GetTotalTime() * 4) & 1)
								{
									bullet_color = ARGB(201, 49, 49);
								}
							}
							_DrawNumberTextureWindow(ui_render, ui_bottom_info_bullet_number2, Core::Vector2(right_x+102, right_y+24), 11, 20, 10, 1.0f / 11.0f);
							_DrawNumberTextureWindow(ui_render, ui_bottom_info_bullet_number2, Core::Vector2(right_x+113, right_y+24), 11, 20, bulletCount / 100, 1.0f / 11.0f,bullet_color);
							_DrawNumberTextureWindow(ui_render, ui_bottom_info_bullet_number2, Core::Vector2(right_x+124, right_y+24), 11, 20, (bulletCount % 100) / 10, 1.0f / 11.0f,bullet_color);
							_DrawNumberTextureWindow(ui_render, ui_bottom_info_bullet_number2, Core::Vector2(right_x+135, right_y+24), 11, 20, bulletCount % 10, 1.0f / 11.0f,bullet_color);

							ui_render->DrawTextureWindow(Core::Vector2(right_x+112, right_y-9), 32, 28, ui_bottom_info_danjia,Core::Rectangle(0,0,1,1),bullet_color);
						}
						else if (max_in_clip > 0)
						{
							int bulletCount = Clamp((U32)ptr_dynamic_cast<GunBase>(weapon)->ammo_in_clip,0,999);
							if ((float)bulletCount / (float)ptr_dynamic_cast<GunBase>(weapon)->max_ammo_in_clip < 0.3)
							{
								if ((int)(Task::GetTotalTime() * 4) & 1)
								{
									bullet_color = ARGB(201, 49, 49);
								}
							}
							_DrawNumberTextureWindow(ui_render, ui_bottom_info_bullet_number, Core::Vector2(right_x+41, right_y-9), 29, 45, (bulletCount % 100) / 10, 0.1f,bullet_color);
							_DrawNumberTextureWindow(ui_render, ui_bottom_info_bullet_number, Core::Vector2(right_x+12, right_y-9), 29, 45, bulletCount / 100, 0.1f,bullet_color);
							_DrawNumberTextureWindow(ui_render, ui_bottom_info_bullet_number, Core::Vector2(right_x+70, right_y-9), 29, 45, bulletCount % 10, 0.1f,bullet_color);
							ui_render->DrawTextureWindow(Core::Vector2(right_x+112, right_y-9), 32, 28, ui_bottom_info_danjia,Core::Rectangle(0,0,1,1),bullet_color);
						}
						else if (max_count == 0 && max_in_clip == 0)
						{
 							if (weapon->GetWeaponType() == kWeaponTypeCureGun /*|| weapon->GetWeaponType() == kWeaponTypeZombieGun*/)
 							{
 								tempc_ptr(CureGun) curegun = ptr_dynamic_cast<CureGun>(weapon);

 								//POWER
 								ui_render->DrawTextureWindow(Core::Vector2(right_x+15, right_y), 120, 42, ui_bottom_info_CureGun[viewer->GetTeam()]);
 								float fSc = Core::Clamp(curegun->power / 100.0f, 0.001f, 1);
 								ui_render->SetTexture(ui_bottom_info_CureGun_Content);
 								ui_render->DrawWindow(Core::Rectangle(right_x+43, right_y+11, right_x+46+(67 * fSc),right_y + 11 + 16), Core::Rectangle(3, 3, 3, 3), Core::Rectangle(5.0f / 15.f, 5.0f / 15.f, 6.0f / 15.f, 6.0f / 15.f),power_color);

								ui_render->DrawTextureWindow(Core::Vector2(right_x+110-50+34, right_y+8), 18, 20, ui_bottom_info_CureGun_Power,Core::Rectangle(0,0,1,1));
								_DrawNumberTextureWindow(ui_render, ui_bottom_info_CureGun_PowerNum, Core::Vector2(right_x+110-50, right_y+8), 18, 20, ((int)curegun->power % 100) / 10, 0.1f);
								if (curegun->power / 100 == 1)
								{
									ui_render->DrawTextureWindow(Core::Vector2(right_x+10,right_y-60), 45, 63, ui_novice_mouse);
									if ((int)(Task::GetTotalTime() * 4) & 1)
										ui_render->DrawTextureWindow(Core::Vector2(right_x+37,right_y-47), 15, 22, ui_novice_mouse_R);
									CStrBuf<256> buff;
									buff.format(gLang->GetTextW(L"���Ҽ�ʩ��"));
									ui_render->DrawString(ui_render->font_simhei_16,ARGB(255,238,208),ARGB(1,1,1,1),Core::Rectangle(right_x+50,right_y-20,right_x+150,right_y),buff,Unit::kAlignCenterBottom);
									_DrawNumberTextureWindow(ui_render, ui_bottom_info_CureGun_PowerNum, Core::Vector2(right_x+110-50-17, right_y+8), 18, 20, (int)curegun->power / 100, 0.1f);
								}
								_DrawNumberTextureWindow(ui_render, ui_bottom_info_CureGun_PowerNum, Core::Vector2(right_x+110-50+17, right_y+8), 18, 20, (int)curegun->power % 10, 0.1f);
 							}
							else
								ui_render->DrawTextureWindow(Core::Vector2(right_x+36, right_y-5), 88, 48, ui_bottom_info_all);
						}
					}
					else if (weapon->GetWeaponType() == kWeaponTypeGunTowerBuilder)
					{
						//tempc_ptr(GunTowerBuilder) curegun = ptr_dynamic_cast<GunTowerBuilder>(weapon);
						//ui_render->DrawTextureWindow(Core::Vector2(right_x+46, right_y - 25), 69, 73, ui_bottom_info_GunTowerBuider);
					}
					else
					{
						ui_render->DrawTextureWindow(Core::Vector2(right_x+36, right_y-5), 88, 48, ui_bottom_info_all);
					}
				}
			}

			if (viewer->character_info->career_id == 7 && gLevel->game_type != RoomOption::kKnifeMode)
			{
				_DrawUI_GunTowerBuilder(ui_render);
			}
			_DrawUITimer(ui_render);

			if (viewer->character_info->career_id == 2 && weapon->GetWeaponType() == kWeaponTypeMiniMachineGun)
			{
				tempc_ptr(MiniMachineGun) MiniMachine_gun = ptr_dynamic_cast<MiniMachineGun>(weapon);
				int t_x = 0;
				int t_y = 30;
				world = Matrix44::kIdentity;
				world.TranslateXYZ(0,0,0);
				ui_render->SetWorld(world);
				if (MiniMachine_gun->setup_state != 0 && MiniMachine_gun->MiniMachineGun_info && MiniMachine_gun->MiniMachineGun_info->ammo_charge_time_max > 0 && MiniMachine_gun->MiniMachineGun_info->ammo_type != kWeaponTypeNone)
				{
					float f_u = 0.0f;
					m_MiniMachine_gun_show_time = 1.f;
					if (MiniMachine_gun->charge_state == 1)
						f_u = MiniMachine_gun->ammo_charge_time / MiniMachine_gun->MiniMachineGun_info->ammo_charge_time_max;										
					ui_render->SetTexture(ui_bomb_defuse_course);
					ui_render->DrawWindow(Core::Rectangle(t_x - 94,t_y,t_x + 94,t_y + 42),Core::Rectangle(26,0,26,0),Core::Rectangle(26.f/92.f,0.f/64.f,26.f/92.f,0.f/64.f),Core::ARGB(126,255,255,255),Core::ARGB(126,255,255,255));
					ui_render->DrawTextureWindow(Core::Vector2(t_x - 81,t_y + 12),162 * f_u,18,ui_bomb_defuse_course_In,Core::Rectangle(0,0,f_u,1));
					ui_render->DrawTextureWindow(Core::Vector2(t_x - 161,t_y -30),61,80,ui_bottom_info_MiniMachine_gun_1,Core::Rectangle(0,0,1,1));
				}
				else
				{
					if (m_MiniMachine_gun_show_time > 0)
					{
						ui_render->DrawTextureWindow(Core::Vector2(-161,0),61,80,ui_bottom_info_MiniMachine_gun_2,Core::Rectangle(0,0,1,1));
						m_MiniMachine_gun_show_time -= Task::GetFrameTime();

					}
					if(m_MiniMachine_gun_show_time < 0)
					{
						m_MiniMachine_gun_show_time = 0;
					}
				}
			}

			/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			world = Matrix44::kIdentity;
			world.TranslateXYZ(-(rt_size.x/2), rt_size.y/2, 0);
			ui_render->SetWorld(world);
			if (player)
			{
				_DrawEnergyBar(ui_render,ui_bottom_info_Exp,ui_bottom_info_Exp_45,ui_bottom_info_Exp,left_x+82,left_y+83,105,10,false);
			}
		}
	}
	ui_render->BeginInGameUI();
}

void InGameUINew::_DrawWeaponList(by_ptr(UIRender) ui_render)
{
	ui_render->BeginInGameUI();
	Core::Matrix44 world;
	Core::Vector3 rt_size = gGame->guiSys->GetSize();

	tempc_ptr(Character) player = gLevel->GetViewer();

	if(!player)
	{
		return;
	}

	if(!player->weapon_list_icon_flag || (gLevel->game_type == RoomOption::kBossMode2 && player->is_boss))
		return;

	int weapon_id_last;

	if(player->select_grenade_mode)
		weapon_id_last = player->grenade_id;
	else
		weapon_id_last = player->weapon_id_last;

	tempc_ptr(WeaponBase) w;
	w =  player->GetWeaponById(weapon_id_last);

	if(!w || !w->CanActive())
		return;

	if(player->weapon_list_icon_flag == 1)
	{
		if(w->weapon_info->icon)
		{
			float tscale = 1.0f;

			if((1.0f - player->weapon_list_icon_movetime) <= 0.5f)
				tscale = 1.0f - 0.2f * ( 1.0f - player->weapon_list_icon_movetime ) * 2.0f;
			else
				tscale = 0.8f + 0.2f * ( 0.5f - player->weapon_list_icon_movetime ) * 2.0f;

			world.TranslateXYZ(0,-85 * (1.0f - player->weapon_list_icon_movetime),0);

			ui_render->SetWorld(world);

			ui_render->SetTexture(w->weapon_info->icon);
			ui_render->BeginRectangleList(1);
			ui_render->Vertex(-175 + 22.0f * tscale, -103 + 12.0f * tscale, 0, 0, 0, ARGB(128,255, 255, 255));
			ui_render->Vertex(-10 - 23.0f *  tscale, -20 - 11.0f * tscale, 0, 1, 1, ARGB(128,255, 255, 255));
			ui_render->End();
		}
	}

	world.SetTranslationXYZ(rt_size.x - 160,rt_size.y/2 + 250 - 76,0);

	int weapon_id = player->weapon_id;

	bool grenade_flag = false;

	for(int i = 0 ; i < 4; i++)
	{
		if(i!=0)
		{
			if(weapon_id == 7)
				weapon_id = 0;
			else
				weapon_id++;

			w = player->GetWeaponById(weapon_id);
			if(!w || !w->CanActive())
			{
				i--;
				continue;
			}

			if(!player->HasBomb() && weapon_id == BOMB_SLOT)
				continue;

			if(weapon_id == player->weapon_id)
				break;

			if(weapon_id == weapon_id_last)
			{
				i--;
				continue;
			}
			if(player->select_grenade_mode && weapon_id < 3)
			{
				i--;
				continue;
			}
			if(player->select_grenade_mode == false && player->weapon_id >= 3 && weapon_id >=3)
			{
				i--;
				continue;
			}
			if(player->select_grenade_mode == false && weapon_id >= 3 && player->weapon_id < 3)
			{	
				if(grenade_flag)
				{
					i--;
					continue;
				}
				grenade_flag = true;
			}
		}
		if(i == 0 && player->weapon_list_icon_flag != 1)
		{
			weapon_id = weapon_id_last;
		}

		w = player->GetWeaponById(weapon_id);

		if(w && w->CanActive())
		{
			if(!(player->weapon_id >= 3 && player->weapon_id <= 5 && weapon_id != 6 || player->weapon_id < 3 || player->weapon_id > 5))
				continue;

			ui_render->SetTexture(w->weapon_info->icon);

			float tratio = 0.0f;
			float tscale = 0.0f;

			if(i==0 && player->weapon_list_icon_flag==1)
			{
				tratio = 100 * (1.0f - player->weapon_list_icon_movetime);


				if((1.0f - player->weapon_list_icon_movetime) <= 0.5f)
					tscale = 1.0f + 0.2f * ( 1.0f - player->weapon_list_icon_movetime ) * 2.0f;
				else
					tscale = 1.2f - 0.2f * ( 0.5f - player->weapon_list_icon_movetime ) * 2.0f;
			}
			world.TranslateXYZ(0,-60 + tratio,0);

			ui_render->SetWorld(world);

			float talpha = player->weapon_list_icon_alpha / 2.0f;
			float tratio_x = 0, tratio_y = 0;

			if(i==0 && player->weapon_list_icon_flag==1)
				talpha = 1.0f;

			ui_render->DrawRectangle(Core::Rectangle(0 - 22.0f * tscale,0 - 12.0f * tscale,120 + 23.0f * tscale,60 + 11.0f * tscale),Core::Rectangle(0,0,1,1),Core::ARGB(255.0f * talpha,255,255,255));

			if(i==0)
			{
				world.SetTranslationXYZ(rt_size.x - 160,rt_size.y/2 + 190 - 76,0);
				ui_render->SetWorld(world);

				weapon_id = player->weapon_id;
			}
		}
		else
		{
			i--;
		}
	}
}
void InGameUINew::_DrawRoundTimeShow(by_ptr(UIRender) ui_render,int left_x,int left_y)
{
	int second = gGame->round_time % 60;
	int minute = (gGame->round_time / 60) % 60;
	int hour = (gGame->round_time / 3600);

	int h = hour%10;
	int h2 = hour/10;
	ui_render->DrawTextureWindow(Core::Vector2(left_x+417+202, left_y-22), 32, 45, ui_zombie_time_number ,Core::Rectangle(h*32/320.0f, 0, (h+1)*32/320.0f, 1));
	ui_render->DrawTextureWindow(Core::Vector2(left_x+417+170, left_y-22),  32, 45, ui_zombie_time_number ,Core::Rectangle(h2*32/320.0f, 0, (h2+1)*32/320.0f, 1));

	ui_render->DrawTextureWindow(Core::Vector2((left_x+417+234),left_y-22), 16, 45,ui_zombie_number_comma);

	int m = minute%10;
	int m2 = minute/10;
	ui_render->DrawTextureWindow(Core::Vector2(left_x+417+282, left_y-22), 32, 45, ui_zombie_time_number ,Core::Rectangle(m*32/320.0f, 0, (m+1)*32/320.0f, 1));
	ui_render->DrawTextureWindow(Core::Vector2(left_x+417+250, left_y-22), 32, 45, ui_zombie_time_number ,Core::Rectangle(m2*32/320.0f, 0, (m2+1)*32/320.0f, 1));

	ui_render->DrawTextureWindow(Core::Vector2((left_x+417+314),left_y-22), 16, 45,ui_zombie_number_comma);

	int sec = second%10;
	int sec2 = second/10;
	ui_render->DrawTextureWindow(Core::Vector2(left_x+417+362, left_y-22), 32, 45, ui_zombie_time_number ,Core::Rectangle(sec*32/320.0f, 0, (sec+1)*32/320.0f, 1));
	ui_render->DrawTextureWindow(Core::Vector2(left_x+417+330, left_y-22),  32, 45, ui_zombie_time_number ,Core::Rectangle(sec2*32/320.0f, 0, (sec2+1)*32/320.0f, 1));

	int msec = gGame->m_second*10;
	int msec2 = ((int)(gGame->m_second*100))%10;
	ui_render->DrawTextureWindow(Core::Vector2(left_x+417+394, left_y-12), 20, 32, ui_zombie_time_number ,Core::Rectangle(msec*20/200.0f, 0, (msec+1)*20/200.0f, 1));
	ui_render->DrawTextureWindow(Core::Vector2(left_x+417+414, left_y-12), 20, 32, ui_zombie_time_number ,Core::Rectangle(msec2*20/200.0f, 0, (msec2+1)*20/200.0f, 1));
}
void InGameUINew::_DrawTargetEnemy(by_ptr(UIRender) ui_render)
{
	ui_render->BeginInGameUI();
	tempc_ptr(Character) viewer = gLevel->GetViewer();
	tempc_ptr(Character) player = gLevel->GetPlayer();
	int acolor = 255;
	Core::Vector3 rt_size = gGame->guiSys->GetSize();

	// draw pointed enemy name
	if (viewer)
	{
		Core::Vector3 position = gGame->camera->position;
		Core::Vector3 direction = Core::Normalize(Core::Vector3(0, 0, -1) * gGame->camera->rotation);
		position += direction * 1.f;

		uint group_id = 0;
		group_id |= 1 << PhysxSystem::kStatic;
		group_id |= 1 << PhysxSystem::kStaticRaycast;
		group_id |= 1 << PhysxSystem::kPlayer;
		group_id |= 1 << PhysxSystem::kDynamic;
		group_id |= 1 << PhysxSystem::kController;

		for (uint i = 0; i < 2; ++i)
		{
			group_id |= 1 << (PhysxSystem::kGroupStart + i);
		}

		NxCapsule capsule;
		capsule.p0 = (const NxVec3 &)position;
		capsule.p1 = (const NxVec3 &)position;
		capsule.radius = 0.05f;

		viewer->is_point_emeny = false;

		NxSweepQueryHit hit;
		tempc_ptr(Character) p = NullPtr;
		tempc_ptr(DummyObject) d = NullPtr;
		if (gPhysxScene->linearCapsuleSweep(capsule, Core::binary_cast<NxVec3>(direction * 500), NX_SF_STATICS | NX_SF_DYNAMICS, NULL, 1, &hit, NULL, group_id, NULL))
		{
			if (hit.hitShape)
			{
				NxActor& actor = hit.hitShape->getActor();

				p = Character::FromNxActor(actor);
				d = DummyObject::FromNxActor(actor);
				if (p && player && !player->IsDied())
				{
					gLevel->saveplayer = p;
					gLevel->tmpplayer = p;
					viewer->is_point_emeny = (viewer->GetTeam() != p->GetTeam());
					gLevel->targetenemy_time = 0.75f;
				}
				if (d && player && !player->IsDied())
				{
					tempc_ptr(Character) c = gLevel->GetCharacter(d->owner_id);
					if(c)
					{
						viewer->is_point_emeny = (viewer->GetTeam() != c->GetTeam());
					}
				}
			}
		}

		gLevel->targetenemy_time -= Task::GetFrameTime();
		if (gLevel->targetenemy_time < 0)
		{
			gLevel->saveplayer = NullPtr;
			gLevel->targetenemy_time = 0;
		}
		acolor = 255-(1-gLevel->targetenemy_time)*255;
		//LogSystem.WriteLinef("time = %f,| acolor = %d", gLevel->targetenemy_time,acolor);
		if (gLevel->saveplayer && gLevel->saveplayer->GetName() != Core::String::kEmpty && gLevel->targetenemy_time > 0.f)
		{
			tempc_ptr(Character) player = gLevel->GetPlayer();

			if (!player || player->GetTeam() == gLevel->saveplayer->GetTeam())
				return;

			if (gLevel->game_type == RoomOption::kBossPVE && gLevel->saveplayer->ispveboss)
			{
				Core::CStrBuf<256> result = gLevel->saveplayer->GetName();
				if(gGame->global)
					gGame->global->Translate(result);
				ui_render->DrawFontWindow(Core::Vector2(rt_size.x/2 - 80, rt_size.y/2 - 68-24-50), 160, 24, ui_render->font_simhei_20, ARGB(acolor,195,82,65), Core::ARGB(0, 0, 0, 0), result, Unit::kAlignCenterMiddle, true);
			}
			else
			{
				ui_render->DrawFontWindow(Core::Vector2(rt_size.x/2 - 80, rt_size.y/2 - 68-24-50), 160, 24, ui_render->font_simhei_20, ARGB(acolor,195,82,65), Core::ARGB(0, 0, 0, 0), gLevel->saveplayer->GetName().Str(), Unit::kAlignCenterMiddle, true);
			}
			
			F32 len = Length(gGame->camera->position - CalcNewPosition(gGame->camera->position, gLevel->saveplayer->GetTorsoPosition()));
			F32 v = gDx9Device->convergence > 0 ? gDx9Device->convergence : 1;
			if (gDx9Device->GetStereoEnable() &&  len> 0)
				v = len;
			gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_CONVERGENCE, &v, 1);

			//LogSystem.WriteLinef("headiocn = %s",gLevel->saveplayer->head_icon);			

			//draw progress
			float progress = Core::Clamp((float)gLevel->saveplayer->hp / (float)gLevel->saveplayer->max_hp, 0, 1);

			ui_render->DrawTextureWindow(Core::Vector2(rt_size.x/2 - 80, rt_size.y/2 - 68-50), 160, 28, ui_common_hp_bg,Core::Rectangle(0,0,1,1),Core::ARGB(acolor,255,255,255));

			ui_render->SetTexture(ui_common_hp[2]);
			
			if(gLevel->saveplayer->last_hp > gLevel->saveplayer->hp && !gLevel->saveplayer->is_boss)
			{			
				float last_progress = Core::Clamp((float)gLevel->saveplayer->last_hp / (float)gLevel->saveplayer->max_hp, 0, 1);
				ui_render->DrawWindow(Core::Rectangle(rt_size.x/2 - 60+136*progress - 12, rt_size.y/2-62-50, rt_size.x/2 - 60+136*last_progress,rt_size.y/2-62+16-50),
					Core::Rectangle(3,5,3,6),Core::Rectangle(3.0f / 32.f, 5.f / 16.f, 3.0f / 32.f, 6.f / 16.f),Core::ARGB(acolor * 0.5f,102,102,102),Core::ARGB(acolor * 0.5f,102,102,102));
			}

			if (progress > 0.6f)
				ui_render->SetTexture(ui_common_hp[0]);
			else if (progress > 0.3f)
				ui_render->SetTexture(ui_common_hp[1]);
			else
				ui_render->SetTexture(ui_common_hp[2]);

			if(gLevel->saveplayer->hp != 0)
				ui_render->DrawWindow(Core::Rectangle(rt_size.x/2 - 75,rt_size.y/2 - 62-50,rt_size.x/2 - 60+136*progress,rt_size.y/2 - 62+16-50),
				Core::Rectangle(3,5,3,6),Core::Rectangle(3.0f / 32.f, 5.f / 16.f, 3.0f / 32.f, 6.f / 16.f),Core::ARGB(acolor,255,255,255),Core::ARGB(acolor,255,255,255));

			ui_render->SetTexture(ui_common_power);
			ui_render->DrawWindow(Core::Rectangle(rt_size.x/2 - 75,rt_size.y/2 - 62-32,rt_size.x/2 - 75+65,rt_size.y/2 - 62-12),
			Core::Rectangle(0,0,0,0),Core::Rectangle(0.0f /1.f, 0.f / 1.f, 0.0f / 1.f, 0.f / 1.f),Core::ARGB(acolor,255,255,255),Core::ARGB(acolor,255,255,255));
			//ui_render->DrawTextureWindow(Core::Vector2(rt_size.x/2 - 75, rt_size.y/2 - 62-32), 65, 20, ui_common_power);

			String file_name;
			if(gLevel->saveplayer->is_vip == 7)
			{
				file_name = String::Format("IngameUI/vip7_crown.dds");
				sharedc_ptr(Texture2D) texture = RESOURCE_LOAD_NEW(file_name.Str(), true, Texture2D);
				ui_render->DrawTextureWindow(Core::Vector2(rt_size.x/2 - 120, rt_size.y/2 - 68-50), 44, 44, texture,Core::Rectangle(0,0,1,1),Core::ARGB(acolor,255,255,255));
			}
			else if(gLevel->saveplayer->is_vip >= 8)
			{
				file_name = String::Format("IngameUI/vip8_crown.dds");
				sharedc_ptr(Texture2D) texture = RESOURCE_LOAD_NEW(file_name.Str(), true, Texture2D);
				ui_render->DrawTextureWindow(Core::Vector2(rt_size.x/2 - 120, rt_size.y/2 - 68-50), 44, 44, texture,Core::Rectangle(0,0,1,1),Core::ARGB(acolor,255,255,255));
			}

			sharedc_ptr(CharacterInfo) info = gLevel->saveplayer->GetCurCharinfo();
			if (info)
			{
				int power = info->combat_power;
				int num = 0;
				int x = 0;
				if(power < 99999)
				{
					while (power)
					{					
						num = power%10;
						ui_render->DrawTextureWindow(Core::Vector2((rt_size.x/2 + 35)-12.8*x, rt_size.y/2-62-30), 12.8, 16, ui_power_num ,Core::Rectangle(num*12.8/128.0f, 0, (num+1)*12.8/128.0f, 1),Core::ARGB(acolor,255,255,255));
						power /= 10;
						x++;				
					}
				}
				else
				{
					for (int i = 0;i < 5;i++)
					{
						ui_render->SetTexture(ui_power_wenhao);
						ui_render->DrawWindow(Core::Rectangle((rt_size.x/2 - 15)+16*i,rt_size.y/2 - 62-32,(rt_size.x/2 - 15+16)+16*i,rt_size.y/2 - 62-12),
						Core::Rectangle(0,0,0,0),Core::Rectangle(0.0f /1.f, 0.f / 1.f, 0.0f / 1.f, 0.f / 1.f),Core::ARGB(acolor,255,255,255),Core::ARGB(acolor,255,255,255));
					}
				}
			}			
			if (gDx9Device->GetStereoEnable())
				v = gDx9Device->convergence > 0 ? gDx9Device->convergence : 1;
			gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_CONVERGENCE, &v, 1);
		}
	}
}

void InGameUINew::_DrawSniperTargetHelper(by_ptr(UIRender) ui_render)
{
	tempc_ptr(Character) viewer = gLevel->GetViewer();
	
	Matrix44 old_world,world;
	if(!viewer)
		return;

	if(!viewer->bsniperassist)
		return;

	tempc_ptr(GunBase) gun = ptr_dynamic_cast<GunBase>(viewer->GetWeapon());

	if (!gun)
		return;

	if (gun->sight_current == 0)
		return;

	if (gun->GetWeaponType() != kWeaponTypeSniperGun)
		return;

	if (gun->gun_info->sight_info.Size() <= 0)
		return;
	
	if(viewer->camera_fov > gun->gun_info->sight_info[1].level)
		return;

	Core::Matrix44 view;
	Vector3 rt_size = gGame->guiSys->GetSize();
	view.SetScaleXYZ(2.0f / rt_size.x, -2.0f / rt_size.y, 0.0f);
	view.TranslateXYZ(-1.0f, 1.0f, 0.0f);
	view.TranslateLocalXYZ(-0.5f, -0.5f, 0.0f);
	ui_render->SetWorld(Core::Matrix44::kIdentity);
	ui_render->SetView(view);

	const Core::Array<sharedc_ptr(Character)>& characters = gLevel->GetCharacters();

	int x, y;
	bool isAim = false;

	world = ui_render->GetWorld();
	old_world = world;

	for(uint i = 0 ; i < characters.Size() ; i++)
	{
		if(characters[i] && characters[i] != viewer)
		{
			if(characters[i]->GetTeam() != viewer->GetTeam() && !characters[i]->IsDied())
			{
				if(IsCharacterVisibleBySniper(characters[i],x,y,isAim))
				{
					world.SetTranslationXYZ(x,y,0);
					ui_render->SetWorld(world);

					F32 len = Length(gGame->camera->position - CalcNewPosition(gGame->camera->position, characters[i]->GetTorsoPosition()));
					F32 v = gDx9Device->convergence > 0 ? gDx9Device->convergence : 1;
					if (gDx9Device->GetStereoEnable() &&  len> 0)
						v = len;

					gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_CONVERGENCE, &v, 1);

					if(isAim)
					{
						ui_render->DrawTextureWindow(Core::Vector2(-36,-36),72,72,ui_snipertarget[1]);
						show_snipertarget_time += Task::GetFrameTime();
						if (show_snipertarget_time >= 1.0f)
						{
							show_snipertarget_time = 0.f;
						}
						float multiple = 2.0 - show_snipertarget_time;

						ui_render->DrawTextureWindow(Core::Vector2(-72*multiple/2,-72*multiple/2),72 * multiple,72 * multiple,ui_snipertarget[2]);
					}
					else
					{
						ui_render->DrawTextureWindow(Core::Vector2(-36,-36),72,72,ui_snipertarget[0]);
					}

					if (gDx9Device->GetStereoEnable())
						v = gDx9Device->convergence > 0 ? gDx9Device->convergence : 1;

					gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_CONVERGENCE, &v, 1);
				}
			}
		}
	}

	ui_render->SetWorld(old_world);
}

void InGameUINew::_DrawVehicleInfo(by_ptr(UIRender) ui_render)
{
	bool isPass = false;
	if (gLevel->vehicle[0] == NULL || gLevel->vehicle[1] == NULL)
		return;

	if (gLevel->start_chooseperson_time > 0)
		return;

	if (gGame->camera->control_mode == Camera::kDiedMode)
		isPass = true;

	tempc_ptr(Character) viewer = gLevel->GetViewer();
	tempc_ptr(Character) player = gLevel->GetPlayer();

	Matrix44 world;
	Core::Vector3 rt_size = gGame->guiSys->GetSize();

	world.SetTranslationXYZ(rt_size.x/2, rt_size.y-20, 0);
	ui_render->SetWorld(world);

	int bg_x = -180;
	int bg_y = -79;

	if (!isPass)
	{
		ui_render->DrawTextureWindow(Core::Vector2(bg_x+39, bg_y), 311, 64, ui_vehicle_info_bg);
	}

	float total_length_red = gLevel->vehicle[0]->current_vehicle_info.total_length;
	float total_length_blue = gLevel->vehicle[1]->current_vehicle_info.total_length;

	float speed_red = gLevel->vehicle[0]->current_vehicle_info.current_length-gLevel->old_vehice_length_red;
	float speed_blue = gLevel->vehicle[1]->current_vehicle_info.current_length-gLevel->old_vehice_length_blue;

	if (gLevel->vehice_timer_red > 0.f)
	{
		if (Core::Abs(gLevel->vehicle[0]->current_vehicle_info.current_length - gLevel->old_vehice_length_red) > 0.01f)
		{
			gLevel->vehice_fPersert_red += speed_red * Task::GetFrameTime() / 0.5f;
		}
		gLevel->vehice_timer_red -= Task::GetFrameTime();
		
		FMOD_EVENT_STATE audio_state = FMOD_EVENT_DEFAULT;
		gLevel->vehicle_sound[0]->getState(&audio_state);
		if ((audio_state & FMOD_EVENT_STATE_PLAYING) == 0)
		{
			FMOD_VECTOR pos = (const FMOD_VECTOR &)gLevel->vehicle[0]->GetPosition();
			FMOD_VECTOR vel = {0, 0, 0};
			gLevel->vehicle_sound[0]->set3DAttributes(&pos, &vel);
			gLevel->vehicle_sound[0]->start();
		}
		else
		{
			FMOD_VECTOR pos = (const FMOD_VECTOR &)gLevel->vehicle[0]->GetPosition();
			FMOD_VECTOR vel = {0, 0, 0};
			gLevel->vehicle_sound[0]->set3DAttributes(&pos, &vel);
		}
	}
	else
	{
		gLevel->vehice_fPersert_red = gLevel->vehicle[0]->current_vehicle_info.current_length;
		gLevel->vehice_timer_red = 0.f;
		gLevel->vehicle[0]->current_vehicle_info.player_count = 0;
		gLevel->vehicle_sound[0]->stop();
	}
	if (gLevel->vehice_timer_blue > 0.f)
	{
		if (Core::Abs(gLevel->vehicle[1]->current_vehicle_info.current_length - gLevel->old_vehice_length_blue) > 0.01f)
		{
			gLevel->vehice_fPersert_blue += speed_blue * Task::GetFrameTime() / 0.5f;
		}
		gLevel->vehice_timer_blue -= Task::GetFrameTime();

		FMOD_EVENT_STATE audio_state = FMOD_EVENT_DEFAULT;
		gLevel->vehicle_sound[1]->getState(&audio_state);
		if ((audio_state & FMOD_EVENT_STATE_PLAYING) == 0)
		{
			FMOD_VECTOR pos = (const FMOD_VECTOR &)gLevel->vehicle[1]->GetPosition();
			FMOD_VECTOR vel = {0, 0, 0};
			gLevel->vehicle_sound[1]->set3DAttributes(&pos, &vel);
			gLevel->vehicle_sound[1]->start();
		}
		else
		{
			FMOD_VECTOR pos = (const FMOD_VECTOR &)gLevel->vehicle[1]->GetPosition();
			FMOD_VECTOR vel = {0, 0, 0};
			gLevel->vehicle_sound[1]->set3DAttributes(&pos, &vel);
		}
	}
	else
	{
		gLevel->vehice_fPersert_blue = gLevel->vehicle[1]->current_vehicle_info.current_length;
		gLevel->vehice_timer_blue = 0.f;
		gLevel->vehicle[1]->current_vehicle_info.player_count = 0;
		gLevel->vehicle_sound[1]->stop();
	}
	
	float fPersert_red = gLevel->vehice_fPersert_red / total_length_red;
	float fPersert_blue = gLevel->vehice_fPersert_blue / total_length_blue;
	
	fPersert_red = Core::Clamp(fPersert_red,0,1);
	fPersert_blue = Core::Clamp(fPersert_blue,0,1);

	if (gLevel->game_type == RoomOption::kPushVehicle)
	{
		zd_time += Task::GetFrameTime() * 6;
		zd_time = (zd_time >= 7200) ? 0 : zd_time;
		zd_time += Task::GetFrameTime();
		zd_red_showtime -= Task::GetFrameTime();
	}

	float alphacolor = Core::Sin(zd_time);
	alphacolor = 100 + alphacolor * 155;
	ARGB bg_color = Core::ARGB(alphacolor, 255, 255, 255);

	if (!isPass)
	{
		Core::CStrBuf<256> buff;
		ui_render->DrawTextureWindow(Core::Vector2(bg_x+40, bg_y+40), 25+260 * fPersert_red, 20, ui_vehicle_info_red);
		if (gLevel->vehicle[0]->current_vehicle_info.player_count > 0)
			ui_render->DrawTextureWindow(Core::Vector2(bg_x+40, bg_y+40), 260 * fPersert_red, 20, ui_vehicle_info_shanguang_red,Core::Rectangle(0,0,1,1),bg_color);
		ui_render->DrawTextureWindow(Core::Vector2(bg_x+38+260*fPersert_red, bg_y+28), 56, 32, ui_vehicle_info_car_red);
		if (gLevel->vehicle[0]->current_vehicle_info.player_count > 0)
		{
			ui_render->DrawTextureWindow(Core::Vector2(bg_x+45+260*fPersert_red,bg_y+38), 12, 16, ui_hold_point_info_people);
			buff.format("x%d", gLevel->vehicle[0]->current_vehicle_info.player_count);
			ui_render->DrawFontWindow(Core::Vector2(bg_x+57+260*fPersert_red, bg_y+38), 15, 15, ui_render->font_simhei_14, Core::ARGB(255, 238, 206),  Core::ARGB(0, 0, 0, 0), buff, Unit::kAlignLeftTop);
		}

		ui_render->DrawTextureWindow(Core::Vector2(bg_x+40, bg_y+6), 25+260 * fPersert_blue, 20, ui_vehicle_info_blue);
		if (gLevel->vehicle[1]->current_vehicle_info.player_count > 0)
			ui_render->DrawTextureWindow(Core::Vector2(bg_x+40, bg_y+6), 260 * fPersert_blue, 20, ui_vehicle_info_shanguang_blue,Core::Rectangle(0,0,1,1),bg_color);
		ui_render->DrawTextureWindow(Core::Vector2(bg_x+38+260*fPersert_blue, bg_y-6), 56, 32, ui_vehicle_info_car_blue);
		if (gLevel->vehicle[1]->current_vehicle_info.player_count > 0)
		{
			ui_render->DrawTextureWindow(Core::Vector2(bg_x+45+260*fPersert_blue, bg_y+2), 12, 16, ui_hold_point_info_people);
			buff.format("x%d", gLevel->vehicle[1]->current_vehicle_info.player_count);
			ui_render->DrawFontWindow(Core::Vector2(bg_x+57+260*fPersert_blue, bg_y+2), 15, 15, ui_render->font_simhei_14, Core::ARGB(255, 238, 206),  Core::ARGB(0, 0, 0, 0), buff, Unit::kAlignLeftTop);
		}
	}

	if (!isPass)
	{
		ui_render->DrawTextureWindow(Core::Vector2(bg_x, bg_y), 44, 64, ui_vehicle_info_left);
		ui_render->DrawTextureWindow(Core::Vector2(bg_x+348, bg_y), 44, 64, ui_vehicle_info_right);
	}

	if (viewer && player && player == viewer && gLevel->vehicle[0] && gLevel->vehicle[1])
	{
		int bmp_width = ui_vehicle_length->GetWidth();
		int bmp_height = ui_vehicle_length->GetHeight();
		int size_ratio = 0;
		int team = player->GetTeam();
		if (team > 1)
			return;
		Vector3 pos = gLevel->vehicle[team]->position;
		
		Matrix44 View,Proj,ViewProj;
		gGame->camera->CalculateViewProjectionMatrix(View, Proj);
		ViewProj = View * Proj;

		TransformCoord(pos, pos, ViewProj); 
		int x = rt_size.x / 2.0f + rt_size.x / 2.0f * pos.x;
		int y = rt_size.y / 2.0f - rt_size.y / 2.0f * pos.y;
		if( pos.z > 1.0f)
			return;

		world.SetTranslationXYZ(0,10,0);
		ui_render->SetWorld(world);

		const Core::Vector3 &player_pos = (const Core::Vector3 &)player->GetPosition();
		const Core::Vector3 &object_pos = (const Core::Vector3 &)gLevel->vehicle[team]->position;

		F32 len = Length(gGame->camera->position - CalcNewPosition(gGame->camera->position, object_pos));

		F32 v = gDx9Device->convergence > 0 ? gDx9Device->convergence : 1;
		if (gDx9Device->GetStereoEnable() &&  len> 0)
			v = len;

		gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_CONVERGENCE, &v, 1);

		int length = (Vector3(player_pos.x, 0, player_pos.z) - Vector3(object_pos.x, 0, object_pos.z)).Length();
		y -= 50;
		if(length < 3)
		{
			size_ratio = 100;
		}
		else if (length >= 3 && length <= 30)
		{
			size_ratio = 100 - 120 * float(length - 3) / (30 - 3);
		}
		else
			size_ratio = -20;

		//bmp_width +=size_ratio;
		//bmp_height += size_ratio;

		ui_render->SetTexture(ui_vehicle_length);
		//ui_render->SetTexture(gLevel->vehicle[team]->rt_edge->GetTexture());
		//ui_render->BeginRectangleList(1);
		//ui_render->Vertex(x - bmp_width / 2 * 0.5f, y - bmp_height / 2 * 0.5f, 1, 0, 0, ARGB(255, 255, 255));
		//ui_render->Vertex(x + bmp_width / 2 * 0.5f, y + bmp_height / 2 * 0.5f, 1, 1, 1, ARGB(255, 255, 255));
		//ui_render->End();

		Matrix44 world,tWorld;
		tWorld = ui_render->GetWorld();

		world.SetTranslationXYZ(x,y - bmp_height / 2 * 0.5f+10.f,0);
		ui_render->SetWorld(world);

		CStrBuf<256> buff;
		buff.format("%dM",length);
		ui_render->DrawString(ui_render->font_simhei_22,ARGB(255,255,255),ARGB(1,1,1,1),Core::Rectangle(-100,0,100,0),buff,Unit::kAlignCenterBottom);

		ui_render->SetWorld(tWorld);

		if (gDx9Device->GetStereoEnable())
			v = gDx9Device->convergence > 0 ? gDx9Device->convergence : 1;

		gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_CONVERGENCE, &v, 1);
	}
}

void InGameUINew::_DrawHoldPostionInfo(by_ptr(UIRender) ui_render)
{
	Matrix44 world;
	Core::Vector3 rt_size = gGame->guiSys->GetSize();

	if (gGame->camera->control_mode == Camera::kDiedMode || gLevel->start_chooseperson_time > 0)
		return;

	world.SetTranslationXYZ(rt_size.x/2, rt_size.y, 0);
	ui_render->SetWorld(world);

	int bg_x = -197;
	int bg_y = -86;
	float freamtime = Task::GetFrameTime();

	if(gGame->channel_connection->GetState() == ChannelConnection::kInReplay)
	{
		float gamerate = 1.f;
		if (gGame->global)
		{
			gamerate = gGame->global->GetGameRate();
		}

		if(gGame->global->GetGameStop())
		{
			gamerate = 0.f;
		}

		freamtime *= gamerate; 
	}

	ui_render->SetTexture(ui_hold_point_info_bg_border_L);
	ui_render->DrawWindow(Core::Rectangle(bg_x,bg_y,bg_x+167,bg_y+80),Core::Rectangle(26,0,0,0),Core::Rectangle(26.0f/52.f, 0.0f/80.f, 0.0f/52.f, 0.0f/80.f));
	ui_render->SetTexture(ui_hold_point_info_bg_border_R);
	ui_render->DrawWindow(Core::Rectangle(bg_x+167+52,bg_y,bg_x+167+52+167,bg_y+80),Core::Rectangle(0,0,26,0),Core::Rectangle(0.0f/52.f, 0.0f/80.f, 26.0f/52.f, 0.0f/80.f));
	
	if (gLevel->holdpoint_sound && gLevel->hold_points[0].snatch_team == gLevel->GetPlayer()->GetTeam() && gLevel->hold_points[0].aabb.IsPointInside(gLevel->GetPlayer()->GetPosition()))
	{
		FMOD_EVENT_STATE audio_state = FMOD_EVENT_DEFAULT;
		gLevel->holdpoint_sound->getState(&audio_state);
		if ((audio_state & FMOD_EVENT_STATE_PLAYING) == 0)
		{
			gLevel->holdpoint_sound->start();
		}
	}
	else if (gLevel->holdpoint_sound)
	{
		gLevel->holdpoint_sound->stop();
	}

	if (0 == gLevel->hold_points[0].owner_team)
	{
		gLevel->hold_point_fPersert_red = 0.f;
		if (zd_red_showtime > 0.f)
		{
			ui_render->SetTexture(ui_hold_point_info_progress);
			ui_render->DrawWindow(Core::Rectangle(bg_x+46,bg_y-15,bg_x+46+294,bg_y-15+36),Core::Rectangle(3,0,3,0),Core::Rectangle(3.0f/84.f, 0.0f/36.f, 3.0f/84.f, 0.0f/36.f));
			float alphacolor = Core::Sin(zd_time);
			alphacolor = 100 + alphacolor * 155;
			ARGB bg_color = Core::ARGB(alphacolor, 255, 255, 255);
			zd_red_showtime -= freamtime;
			ui_render->SetTexture(ui_hold_point_info_flag_red);
			ui_render->DrawWindow(Core::Rectangle(bg_x+48,bg_y-15,bg_x+48+288,bg_y-15+36),Core::Rectangle(0,0,0,0),Core::Rectangle(0.0f/84.f, 0.0f/36.f, 0.0f/84.f, 0.0f/36.f));
			ui_render->SetTexture(ui_hold_point_info_waifaguang_bg);
			ui_render->DrawWindow(Core::Rectangle(bg_x+48,bg_y-15,bg_x+48+288,bg_y-15+36),Core::Rectangle(0,0,0,0),Core::Rectangle(0.0f/84.f, 0.0f/36.f, 0.0f/84.f, 0.0f/36.f),bg_color);
			ui_render->DrawTextureWindow(Core::Vector2(bg_x+24+288, bg_y-17), 48, 36, ui_hold_point_info_board_red,Core::Rectangle(0,0,1,1));
			ui_render->DrawTextureWindow(Core::Vector2(bg_x+24+288, bg_y-17), 48, 36, ui_hold_point_info_waifaguang_board,Core::Rectangle(0,0,1,1),bg_color);
			if (0 < gLevel->cur_holdpoint_diffnum)
			{
				ui_render->DrawTextureWindow(Core::Vector2(bg_x+36+288, bg_y-17+6), 12.0f, 16.0f, ui_hold_point_info_people);
				Core::CStrBuf<256> buff;
				Core::ARGB font_color = Core::ARGB(255, 241, 211);
				Core::ARGB bg_color = Core::ARGB(0, 0, 0, 0);

				buff.format("X%d", gLevel->cur_holdpoint_diffnum);
				ui_render->DrawFontWindow(Core::Vector2(bg_x+48+288, bg_y-17), 80.0f, 24.0f, ui_render->font_simhei_16, font_color, bg_color, buff, Unit::kAlignLeftMiddle, true);
			}
		}
	}
	else if (1 == gLevel->hold_points[0].owner_team)
	{
		gLevel->hold_point_fPersert_blue = 0.f;
		if (zd_blue_showtime > 0.f)
		{
			ui_render->SetTexture(ui_hold_point_info_progress);
			ui_render->DrawWindow(Core::Rectangle(bg_x+46,bg_y-15,bg_x+46+294,bg_y-15+36),Core::Rectangle(3,0,3,0),Core::Rectangle(3.0f/84.f, 0.0f/36.f, 3.0f/84.f, 0.0f/36.f));
			float alphacolor = Core::Sin(zd_time);
			alphacolor = 100 + alphacolor * 155;
			ARGB bg_color = Core::ARGB(alphacolor, 255, 255, 255);
			zd_blue_showtime -= freamtime;
			ui_render->SetTexture(ui_hold_point_info_flag_blue);
			ui_render->DrawWindow(Core::Rectangle(bg_x+48,bg_y-15,bg_x+48+288,bg_y-15+36),Core::Rectangle(0,0,0,0),Core::Rectangle(0.0f/84.f, 0.0f/36.f, 0.0f/84.f, 0.0f/36.f));
			ui_render->SetTexture(ui_hold_point_info_waifaguang_bg);
			ui_render->DrawWindow(Core::Rectangle(bg_x+48,bg_y-15,bg_x+48+288,bg_y-15+36),Core::Rectangle(0,0,0,0),Core::Rectangle(0.0f/84.f, 0.0f/36.f, 0.0f/84.f, 0.0f/36.f),bg_color);
			ui_render->DrawTextureWindow(Core::Vector2(bg_x+24, bg_y-17), 48, 36, ui_hold_point_info_board_blue,Core::Rectangle(0,0,1,1));
			ui_render->DrawTextureWindow(Core::Vector2(bg_x+24, bg_y-17), 48, 36, ui_hold_point_info_waifaguang_board,Core::Rectangle(0,0,1,1),bg_color);
			if (0 < gLevel->cur_holdpoint_diffnum)
			{
				ui_render->DrawTextureWindow(Core::Vector2(bg_x+36, bg_y-17+6), 12.0f, 16.0f, ui_hold_point_info_people);
				Core::CStrBuf<256> buff;
				Core::ARGB font_color = Core::ARGB(255, 241, 211);
				Core::ARGB bg_color = Core::ARGB(0, 0, 0, 0);

				buff.format("X%d", gLevel->cur_holdpoint_diffnum);
				ui_render->DrawFontWindow(Core::Vector2(bg_x+48, bg_y-17), 80.0f, 24.0f, ui_render->font_simhei_16, font_color, bg_color, buff, Unit::kAlignLeftMiddle, true);
			}
		}
	}

	{
		Core::CStrBuf<256> tempbuf;
		float fP[2];
		int timeminute[2];
		int timesecond[2];

		timeminute[0] = gLevel->team_timer[0];
		timeminute[1] = gLevel->team_timer[1];

		timesecond[0] = int( timeminute[0] ) % 60;
		timesecond[1] = int( timeminute[1] ) % 60;

		timeminute[0] = timeminute[0] / 60;
		timeminute[1] = timeminute[1] / 60;
		
		fP[0] = gLevel->team_timer[0] / 210.f;
		fP[1] = gLevel->team_timer[1] / 210.f;

		ui_render->SetTexture(ui_hold_point_timer_red);
		ui_render->DrawWindow(Core::Rectangle(bg_x+12+147*(1-fP[0]),bg_y,bg_x+12+155,bg_y+80),Core::Rectangle(12,0,0,0),Core::Rectangle(12.0f/40.f, 0.0f/80.f, 0.0f/40.f, 0.0f/80.f));
		ui_render->SetTexture(ui_hold_point_timer_blue);
		ui_render->DrawWindow(Core::Rectangle(bg_x+167+52,bg_y,bg_x+167+52+8+147*fP[1],bg_y+80),Core::Rectangle(0,0,12,0),Core::Rectangle(0.0f/40.f, 0.0f/80.f, 12.0f/40.f, 0.0f/80.f));

		ui_render->SetTexture(ui_hold_point_info_bg_border);
		ui_render->DrawWindow(Core::Rectangle(bg_x+167,bg_y,bg_x+167+52,bg_y+80),Core::Rectangle(0,0,0,0),Core::Rectangle(0, 0, 0, 0));

		ui_render->DrawTextureWindow(Core::Vector2(bg_x-1+138*(1-fP[0]), bg_y+18), 44, 60, ui_hold_point_timer2_red,Core::Rectangle(0,0,1,1));
		tempbuf.format("%d:%02d",timeminute[0] > 0 ? timeminute[0] : 0, timesecond[0] > 0 ? timesecond[0] : 0);
		ui_render->DrawFontWindow(Core::Vector2(bg_x+7+138*(1-fP[0]), bg_y+59), 100, 14, ui_render->font_simhei_14, Core::ARGB(252, 235, 198), Core::ARGB(0, 255, 255, 255), tempbuf, Unit::kAlignLeftMiddle);

		ui_render->DrawTextureWindow(Core::Vector2(bg_x+167+69+138*fP[1]-27, bg_y+18), 44, 60, ui_hold_point_timer2_blue,Core::Rectangle(0,0,1,1));
		tempbuf.format("%d:%02d",timeminute[1] > 0 ? timeminute[1] : 0, timesecond[1] > 0 ? timesecond[1] : 0);
		ui_render->DrawFontWindow(Core::Vector2(bg_x+167+69+138*fP[1]-27+7, bg_y+59), 100, 14, ui_render->font_simhei_14, Core::ARGB(252, 235, 198), Core::ARGB(0, 255, 255, 255), tempbuf, Unit::kAlignLeftMiddle);

		if (0 == gLevel->hold_points[0].owner_team)
		{
			float alphacolor = Core::Sin(zd_time);
			alphacolor = 100 + alphacolor * 155;
			ARGB bg_color = Core::ARGB(alphacolor, 255, 255, 255);
			ui_render->DrawTextureWindow(Core::Vector2(bg_x-1+138*(1-fP[0]), bg_y+18), 44, 60, ui_hold_point_neifaguang,Core::Rectangle(0,0,1,1),bg_color);
		}
		else if (1 == gLevel->hold_points[0].owner_team)
		{
			float alphacolor = Core::Sin(zd_time);
			alphacolor = 100 + alphacolor * 155;
			ARGB bg_color = Core::ARGB(alphacolor, 255, 255, 255);
			ui_render->DrawTextureWindow(Core::Vector2(bg_x+167+69+138*fP[1]-27, bg_y+18), 44, 60, ui_hold_point_neifaguang,Core::Rectangle(0,0,1,1),bg_color);
		}
	}

	if (0 == gLevel->hold_points[0].snatch_team)
	{
		ui_render->SetTexture(ui_hold_point_info_progress);
		ui_render->DrawWindow(Core::Rectangle(bg_x+46,bg_y-15,bg_x+46+294,bg_y-15+36),Core::Rectangle(3,0,3,0),Core::Rectangle(3.0f/84.f, 0.0f/36.f, 3.0f/84.f, 0.0f/36.f));

		zd_red_showtime = 1.f;
		gLevel->hold_point_fPersert_red += gLevel->speed_red*freamtime;
		float fPersert = gLevel->hold_point_fPersert_red / 96.0;
		fPersert = Core::Clamp(fPersert,0,1);
		float point_x = fPersert * 288;
		float point_y = 36;

		ui_render->SetTexture(ui_hold_point_info_flag_red);
		ui_render->DrawWindow(Core::Rectangle(bg_x+48,bg_y-15,bg_x+48+point_x,bg_y-15+point_y),Core::Rectangle(0,0,0,0),Core::Rectangle(0.0f/84.f, 0.0f/36.f, 0.0f/84.f, 0.0f/36.f));
		ui_render->DrawTextureWindow(Core::Vector2(bg_x+24+point_x, bg_y-17), 48, point_y, ui_hold_point_info_board_red,Core::Rectangle(0,0,1,1));

		if (0 < gLevel->cur_holdpoint_diffnum)
		{
			ui_render->DrawTextureWindow(Core::Vector2(bg_x+36+point_x, bg_y-17+6), 12.0f, 16.0f, ui_hold_point_info_people);
			Core::CStrBuf<256> buff;
			Core::ARGB font_color = Core::ARGB(255, 241, 211);
			Core::ARGB bg_color = Core::ARGB(0, 0, 0, 0);

			buff.format("X%d", gLevel->cur_holdpoint_diffnum);
			ui_render->DrawFontWindow(Core::Vector2(bg_x+48+point_x, bg_y-17), 80.0f, 24.0f, ui_render->font_simhei_16, font_color, bg_color, buff, Unit::kAlignLeftMiddle, true);
		}
	}
 	else if (1 == gLevel->hold_points[0].snatch_team)
 	{
		ui_render->SetTexture(ui_hold_point_info_progress);
		ui_render->DrawWindow(Core::Rectangle(bg_x+46,bg_y-15,bg_x+46+294,bg_y-15+36),Core::Rectangle(3,0,3,0),Core::Rectangle(3.0f/84.f, 0.0f/36.f, 3.0f/84.f, 0.0f/36.f));

		zd_blue_showtime = 1.f;
		gLevel->hold_point_fPersert_blue += gLevel->speed_blue*freamtime;
		float fPersert = gLevel->hold_point_fPersert_blue / 96.0;
		fPersert = Core::Clamp(fPersert,0,1);
		float point_x = fPersert * 288;
		float point_y = 36;

		ui_render->SetTexture(ui_hold_point_info_flag_blue);
		ui_render->DrawWindow(Core::Rectangle(bg_x+45+288,bg_y-15,bg_x+45+288-point_x,bg_y-15+point_y),Core::Rectangle(3,0,3,0),Core::Rectangle(0.0f/84.f, 0.0f/36.f, 0.0f/84.f, 0.0f/36.f));
		ui_render->DrawTextureWindow(Core::Vector2(bg_x+24+288-point_x, bg_y-17), 48, point_y, ui_hold_point_info_board_blue,Core::Rectangle(0,0,1,1));

		if (0 < gLevel->cur_holdpoint_diffnum)
		{
			ui_render->DrawTextureWindow(Core::Vector2(bg_x+36+288-point_x, bg_y-17+6), 12.0f, 16.0f, ui_hold_point_info_people);
			Core::CStrBuf<256> buff;
			Core::ARGB font_color = Core::ARGB(255, 241, 211);
			Core::ARGB bg_color = Core::ARGB(0, 0, 0, 0);

			buff.format("X%d", gLevel->cur_holdpoint_diffnum);
			ui_render->DrawFontWindow(Core::Vector2(bg_x+48+288-point_x, bg_y-17), 80.0f, 24.0f, ui_render->font_simhei_16, font_color, bg_color, buff, Unit::kAlignLeftMiddle, true);
		}
 	}

	if (InvalidTeam ==  gLevel->hold_points[0].owner_team && InvalidTeam == gLevel->hold_points[0].snatch_team)
	{
		gLevel->hold_point_fPersert_red = 0.f;
		gLevel->hold_point_fPersert_blue = 0.f;
		zd_red_showtime = 1.f;
		zd_blue_showtime = 1.f;
	}

	tempc_ptr(Character) viewer = gLevel->GetViewer();
	tempc_ptr(Character) player = gLevel->GetPlayer();
	if (viewer && player && player == viewer)
	{
		int bmp_width = ui_hold_point_length->GetWidth();
		int bmp_height = ui_hold_point_length->GetHeight();
		int size_ratio = 0;
		int team = player->GetTeam();
		if (team > 1)
			return;
		Vector3 pos(0,0,0);

		Matrix44 View,Proj,ViewProj;
		gGame->camera->CalculateViewProjectionMatrix(View, Proj);
		ViewProj = View * Proj;

		TransformCoord(pos, pos, ViewProj); 
		int x = rt_size.x / 2.0f + rt_size.x / 2.0f * pos.x;
		int y = rt_size.y / 2.0f - rt_size.y / 2.0f * pos.y;
		if( pos.z > 1.0f)
			return;

		world = Matrix44::kIdentity;
		world.SetTranslationXYZ(0,10,0);
		ui_render->SetWorld(world);

		const Core::Vector3 &player_pos = (const Core::Vector3 &)player->GetPosition();
		const Core::Vector3 &object_pos = (const Core::Vector3 &)pos;

		F32 len = Length(gGame->camera->position - CalcNewPosition(gGame->camera->position, object_pos));

		F32 v = gDx9Device->convergence > 0 ? gDx9Device->convergence : 1;
		if (gDx9Device->GetStereoEnable() &&  len> 0)
			v = len;

		gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_CONVERGENCE, &v, 1);

		int length = (Vector3(player_pos.x, 0, player_pos.z) - Vector3(object_pos.x, 0, object_pos.z)).Length();
		y -= 50;
		if(length < 3)
		{
			size_ratio = 100;
		}
		else if (length >= 3 && length <= 30)
		{
			size_ratio = 100 - 120 * float(length - 3) / (30 - 3);
		}
		else
			size_ratio = -20;

		ui_render->SetTexture(ui_hold_point_length);
		ui_render->BeginRectangleList(1);
		ui_render->Vertex(x - bmp_width / 2 * 0.5f, y - bmp_height / 2 * 0.5f, 1, 0, 0, ARGB(255, 255, 255));
		ui_render->Vertex(x + bmp_width / 2 * 0.5f, y + bmp_height / 2 * 0.5f, 1, 1, 1, ARGB(255, 255, 255));
		ui_render->End();

		Matrix44 tWorld;
		world = Matrix44::kIdentity;
		tWorld = ui_render->GetWorld();

		world.SetTranslationXYZ(x,y - bmp_height / 2 * 0.5f+10.f,0);
		ui_render->SetWorld(world);

		CStrBuf<256> buff;
		buff.format("%dM",length);
		ui_render->DrawString(ui_render->font_simhei_14,ARGB(255,255,255),ARGB(1,1,1,1),Core::Rectangle(-100,0,100,0),buff,Unit::kAlignCenterBottom);

		ui_render->SetWorld(tWorld);

		if (gDx9Device->GetStereoEnable())
			v = gDx9Device->convergence > 0 ? gDx9Device->convergence : 1;

		gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_CONVERGENCE, &v, 1);
	}
}

void InGameUINew::_DrawZombieInfo(by_ptr(UIRender) ui_render)
{
	//Matrix44 world;
	//Core::Vector3 rt_size = gGame->guiSys->GetSize();

	//world.SetTranslationXYZ(rt_size.x/2, rt_size.y-20, 0);
	//ui_render->SetWorld(world);

	//int bg_x = -197;
	//int bg_y = -86;
	//int people_num = gGame->scores->teams[0].Size();
	//int zombie_num = gGame->scores->teams[1].Size();

	///*tempc_ptr(Texture2D) head_texture = ui_bottom_info_head_icon[laoda_1->GetTeam()].Get(career_id_blue, NullPtr);
	//if (head_texture)
	//{
	//	ui_render->DrawTextureWindow(Core::Vector2(tempx-63-90+30, tempy-3), 55, 76, head_texture);
	//}*/
	///*if (gGame->scores->teams[0])
	//{
	//	
	//}*/
	//if (gGame->scores->teams[1])
	//{
	//	ui_render->DrawTextureWindow(Core::Vector2(bg_x, bg_y), 43, 61, ui_bottom_info_head_icon[1].Get(01, NullPtr));
	//}
}

void InGameUINew::_DrawCrossHair(by_ptr(UIRender) ui_render)
{
	tempc_ptr(Character) viewer = gLevel->GetViewer();
	by_ptr(Character) player = gLevel->GetPlayer();

	tempc_ptr(WeaponBase) weapon;

	if (viewer)
	{
		weapon = viewer->GetWeapon();
	}

	Core::Rectangle &rs = (Core::Rectangle &)ui_render->GetScissorRect();
	Core::Rectangle temp_rs = rs;

	rs.Min.x = 0.0f,rs.Max.x = F32_MAX;
	rs.Min.y = 0.0f,rs.Max.y = -F32_MAX;

	if (weapon && viewer && viewer->GetViewMode() == Character::kFirstPerson)
	{
		weapon->DrawCrossHair(ui_render);

		//׼�ǵ�CD��
		if (viewer && !viewer->IsDied())
		{
			tempc_ptr(WeaponBase) gun = viewer->GetWeapon();
			if (gun)
			{
				if(gun->weapon_info->reload_cd_bg && gun->weapon_info->reload_cd_con && player->GetFirstPerson().anim_play_time_percentage >= 0 && player->IsReloading())
				{
					int right_x = -gun->weapon_info->reload_cd_size_x/2;
					int right_y = -gun->weapon_info->reload_cd_size_y/2;
					float temp = 1 - player->GetFirstPerson().anim_play_time_percentage;
					_DrawCoolDown(right_x, right_y, gun->weapon_info->reload_cd_size_x, gun->weapon_info->reload_cd_size_y, NullPtr, gun->weapon_info->reload_cd_bg, gun->weapon_info->reload_cd_con, temp, ui_render, 0);
				}
			}
		}
	}

	if(viewer && weapon)
	{
		tempc_ptr(WeaponInfo) killerweapon = weapon->weapon_info;
		if(killerweapon)
		{
			int num = 0;
			sharedc_ptr(Level::AmmoSet) ammo_set = gLevel->character_ammoset.Get(viewer->uid, NullPtr);
			if (ammo_set)
			{
				Level::AmmoSet::Enumerator itor(*ammo_set);
				while (itor.MoveNext())
				{
					tempc_ptr(AmmoBase) tmpammo = itor.Value();
					if (tmpammo->type == kWeaponTypeAmmoStick)
					{
						num++;
					}
				}

				while(num>0)
				{
					//ui_render->SetTexture(ui_AmmoStick);
					ui_render->DrawTextureWindow(Core::Vector2(-153+40*num, 102), 30, 30, ui_AmmoStick,Core::Rectangle(0,0,1,1),Core::ARGB(255,255,255,255));
					num--;
				}

				if(viewer->stick_ammo_explode_timer > 0.f)
				{
					ui_render->DrawTextureWindow(Core::Vector2(-153+40*7, 102), 30, 30, ui_AmmoStick,Core::Rectangle(0,0,1,1),Core::ARGB(255,255,255,255));
				}
			}
		}
	}

	rs = temp_rs;

	if (viewer && viewer != player)
	{
		Matrix44 world;
		Matrix44 oldworld;
		Matrix44 oldview;
		Matrix44 view;
		Vector3 rt_size = gGame->guiSys->GetSize();
		world = Core::Matrix44::kIdentity;
		oldworld = ui_render->GetWorld();
		oldview  = ui_render->GetView();

		view.SetScaleXYZ(2.0f/rt_size.x, -2.0f/rt_size.y, 0);
		ui_render->SetView(view);
		world.SetTranslationXYZ(rt_size.x/2, 0, 0);
		ui_render->SetWorld(world);
		int ui_x = -351;
		int ui_y = 0;
		ARGB font_color = ARGB(255, 239, 206);
		ARGB bg_color = ARGB(0, 0, 0, 0);
		ui_render->SetTexture(all_tipBg[viewer->GetTeam()]);
		ui_render->DrawWindow(Core::Rectangle(ui_x,ui_y-111,ui_x+357,ui_y),Core::Rectangle(12,12,13,15),Core::Rectangle(12.0f / 51.f, 12.0f / 51.f, 13.0f / 51.f, 15.0f / 51.f));


		if (viewer->GetCurCharinfo())
		{
			//ʮ������ֵ
			float fSc = (float)viewer->hp / viewer->max_hp;
			fSc = Core::Clamp(fSc,0,1);
			ui_render->DrawTextureWindow(Core::Vector2(ui_x+17, ui_y-111+12), 88, 88, ui_bottom_info_hp_kuang);
			ui_render->DrawTextureWindow(Core::Vector2(ui_x+17, ui_y-111+12+88-(88*fSc)), 88, 88*fSc, ui_bottom_info_hp, Core::Rectangle(0, 1.0f - fSc, 1, 1));
		}

		//���ӱ�����Ƭ
		int card_num = (int)viewer->business_card;
		if (card_num > 0 && card_num < 18)
		{
			ui_render->DrawTextureWindow(Core::Vector2(ui_x+120, ui_y-111+55), 223, 40, ui_common_name_cards[card_num-1]);
		}
		if (viewer->is_vip == 1 && card_num == 0)
		{
			ui_render->DrawTextureWindow(Core::Vector2(ui_x+120, ui_y-111+55), 223, 40,ui_common_vip_name_card);
		}

		Core::CStrBuf<256> buff;
		buff.format(gLang->GetTextW(L"��ǰ�۲�"));
		ui_render->DrawFontWindow(Core::Vector2(ui_x+115, ui_y-111+18), 100, 22, ui_render->font_simhei_20, font_color, bg_color, buff, Unit::kAlignLeftMiddle);
		buff.format("%s",viewer->GetName().Str());
		ui_render->DrawFontWindow(Core::Vector2(ui_x+100, ui_y-111+55), 217, 34, ui_render->font_simhei_28, font_color, bg_color, buff, Unit::kAlignCenterMiddle);
		tempc_ptr(Character) c = viewer;

		if (c && c != player)
		{
			//tempc_ptr(WeaponBase) weapon = c->GetWeapon();
			if (weapon)
			{
				tempc_ptr(WeaponInfo) killerweapon = weapon->weapon_info;
				if (killerweapon && killerweapon->icon)
				{
					_DrawTips_show(ui_render,killerweapon,c,buff,ui_x,ui_y-111);
				}
			}					
		}
		ui_render->SetWorld(oldworld);
		ui_render->SetView(oldview);
	}
}

void InGameUINew::_DrawUITimer(by_ptr(UIRender) ui_render)
{
	Core::Vector3 rt_size = gGame->guiSys->GetSize();
	tempc_ptr(Character) viewer = gLevel->GetPlayer();
	Core::Array<WeaponBase*> guns;

	CStrBuf<256> buff;
	ARGB font_color = ARGB(251, 245, 231);
	ARGB bg_color = ARGB(0, 0, 0, 0);

	if (viewer && !viewer->IsDied())
	{
		int type = 0;
		int linenum = 0;
		for (int i = 0; i < 7;++i)
		{
			tempc_ptr(WeaponBase) gun = viewer->GetWeaponById(i);

			if(gun && (gun->weapon_info->time_to_idle > 0 || gun->GetWeaponType() == kWeaponTypeGrenade || gun->GetWeaponType() == kWeaponTypeFlash || gun->GetWeaponType() == kWeaponTypeSpecial || gun->GetWeaponType() == kWeaponTypeDrum
				 || gun->GetWeaponType() == kWeaponTypeZombieCharge))
			{
				guns.PushBack(gun);
				linenum++;
			}
			else if (gun && gun->GetWeaponType() == kWeaponTypeZombieGun)
			{
				tempc_ptr(ZombieGun) zombie =  ptr_static_cast<ZombieGun>(gun);
				if (zombie && zombie->knife_info->skill_cooldown > 0)
				{
					//LogSystem.WriteLinef("%f",zombie->knife_info->skill_cooldown);
					guns.PushBack(gun);
					linenum++;
				}
			}
		}

		if (linenum > 4)
			return;

		int right_x = -226;
		int right_y = -64;

		for (int i = 0; i < linenum;++i)
		{
			tempc_ptr(Texture2D) temp = guns[i]->weapon_info->cool_down;
			if (guns[i]->weapon_info->cool_down && ui_cooldown_circle && ui_cooldown_circle_bg && guns[i]->cdscale >= 0 && guns[i]->cdscale <= 1)
			{
 				_DrawCoolDown(right_x-52*i, right_y, 48, 48, guns[i]->weapon_info->cool_down, ui_cooldown_circle_bg, ui_cooldown_circle, guns[i]->cdscale, ui_render, 4);
				tempc_ptr(ZombieGun) zombie =  ptr_dynamic_cast<ZombieGun>(guns[i]);
				if (zombie)
				{
					tempc_ptr(Character) c =  zombie->GetOwner();
					if (c && zombie->knife_info && (int)(zombie->knife_info->skill_cooldown - c->zombiegun_cd_time) > 0)
					{
						buff.format("%d",(int)(zombie->knife_info->skill_cooldown - zombie->GetOwner()->zombiegun_cd_time));
						ui_render->DrawString(ui_render->font_simhei_20,ARGB(255,238,208),ARGB(1,1,1,1),Core::Rectangle(right_x-52*i, right_y, right_x-52*i+48, right_y+48),buff,Unit::kAlignCenterMiddle);
					}
				}
				Play_Cd_Scale_sound(i,guns[i]->cdscale,guns[i]->weapon_info->sound_name);
				if (guns[i]->cdscale > 0.02f)
				{
					guns[i]->weapon_info->cd_time = 0;
					guns[i]->weapon_info->cd_time1 = 10;
				}
				else
				{
					if (guns[i]->weapon_info->cd_time < 3.f)
					{
						Core::ARGB bg_color = ARGB(255-(guns[i]->weapon_info->cd_time/3)*255,255,255,255);
						guns[i]->weapon_info->cd_time += Task::GetFrameTime() * 3;
						int offset = (int)(guns[i]->weapon_info->cd_time*30);
						ui_render->SetTexture(guns[i]->weapon_info->cool_down);
						ui_render->DrawRectangle(Core::Rectangle((right_x-52*i)-2-offset/2, right_y-14-offset/2, (right_x-52*i)+52+offset/2, right_y+52-12+offset/2),Core::Rectangle(0, 0, 1, 1),bg_color);
					}
					else
					{
						guns[i]->weapon_info->cd_time1 = guns[i]->weapon_info->cd_time1-Task::GetFrameTime();
						if (guns[i]->weapon_info->cd_time1 < 0)
						{
							guns[i]->weapon_info->cd_time = 0;
							guns[i]->weapon_info->cd_time1 = 10;
						}
					}
				}
			}
			if (guns[i]->GetWeaponType() == kWeaponTypeZombieGun && guns[i]->cdscale >= 0.f && guns[i]->cdscale < 0.05f)
			{
				ui_render->DrawTextureWindow(Core::Vector2(right_x,right_y-70), 45, 63, ui_novice_mouse);
				if ((int)(Task::GetTotalTime() * 4) & 1)
					ui_render->DrawTextureWindow(Core::Vector2(right_x+27,right_y-57), 15, 22, ui_novice_mouse_R);
				CStrBuf<256> buff;
				buff.format(gLang->GetTextW(L"���Ҽ�ʩ��"));
				ui_render->DrawString(ui_render->font_simhei_16,ARGB(255,238,208),ARGB(1,1,1,1),Core::Rectangle(right_x+65,right_y-30,right_x+150,right_y-10),buff,Unit::kAlignLeftBottom);
			}
		}
	}
}

void InGameUINew::_DrawUI_GunTowerBuilder(by_ptr(UIRender) ui_render)
{
	if (RoomOption::kEditMode == gLevel->game_type)
		return;
	tempc_ptr(Character) player = gLevel->GetPlayer();
	int right_x = -350;
	int right_y = -90;
	if (player)
	{
		tempc_ptr(WeaponBase) Tower_gun =  player->GetWeaponById(0);
		if (Tower_gun)
		{
			CStrBuf<256> buff;
			ui_render->DrawTextureWindow(Core::Vector2(right_x + 20, right_y + 30), 172, 45, ui_bottom_info_GunTower_bg);
			gLevel->GunTower_Move_CD -= Task::GetFrameTime();
			if (player->tower_gun_count)
			{
				ui_render->DrawTextureWindow(Core::Vector2(right_x, right_y), 74, 90, ui_bottom_info_GunTower_Picture[player->GetTeam()]);
				if (gLevel->GunTower_Move_CD < 0)
				{
					gLevel->GunTower_Move_CD = 0;
				}
				else
				{
					ui_render->DrawTextureWindow(Core::Vector2(right_x+9, right_y+73), 62, 8, ui_bottom_info_GunTower_Move_CD[0]);
					ui_render->DrawTextureWindow(Core::Vector2(right_x+9, right_y+73), 62*(2.0f-gLevel->GunTower_Move_CD)/2, 8, ui_bottom_info_GunTower_Move_CD[1]);
				}
			} 
			else
			{
				ui_render->DrawTextureWindow(Core::Vector2(right_x, right_y), 74, 90, ui_bottom_info_GunTower_UnBuider);
				//ui_render->DrawTextureWindow(Core::Vector2(right_x + 75, right_y + 43), 106, 28, ui_bottom_info_GunTower_energy_bg);
				//ui_render->DrawTextureWindow(Core::Vector2(right_x + 75, right_y + 43), 106*player->tower_gun_percent, 28, ui_bottom_info_GunTower_energy,Core::Rectangle(0,0,player->tower_gun_percent,1));
			}
			ui_render->DrawTextureWindow(Core::Vector2(right_x + 75, right_y + 43), 106, 28, ui_bottom_info_GunTower_energy_bg);
			ui_render->DrawTextureWindow(Core::Vector2(right_x + 75, right_y + 43), 106*player->tower_gun_percent, 28, ui_bottom_info_GunTower_energy, Core::Rectangle(0,0,player->tower_gun_percent,1));
			buff.format("%s",gLang->GetTextW(player->tower_gun_count ? L"�ص���" : L"δ����"));
			ui_render->DrawStringShadow(ui_render->font_simhei_14, Core::ARGB(226,213,74), Core::ARGB(0,0,0), Core::ARGB(0,255,255,255),Core::Rectangle(right_x+80, right_y + 30, right_x+80, right_y + 40),buff, Unit::kAlignLeftMiddle);
		}
	}
}

void InGameUINew::Play_Cd_Scale_sound(int which,float value,Core::String string)
{
	if (gLevel->b_Scale_Cd[which] && value > 0)
	{
		gLevel->b_Scale_Cd[which] = false;
	}
	else if (!gLevel->b_Scale_Cd[which] && value == 0.0f)
	{
		tempc_ptr(Character) player = gLevel->GetPlayer();

		String str = String::Format("bj/player/2d/%s/%s_cooldown",player->GetCurCharinfo()->res_key,string.Str());
		FmodSystem::PlayEvent(str.Str());
		FmodSystem::PlayEvent("bj/ui/skill_cooldown");
		gLevel->b_Scale_Cd[which] = true;
	}
}


void InGameUINew::_DrawCoolDown(int x, int y, int width, int height, by_ptr(Texture2D) texture_icon,by_ptr(Texture2D) texture_bg, by_ptr(Texture2D) texture_content, float fProgress, by_ptr(UIRender) ui_render, int offset)
{
	fProgress = 1-fProgress;
	float color = 1;
	//color = fProgress > 0.98f ? (80.f/255.f) : 1;

	ui_render->SetTexture(texture_bg);
	ui_render->DrawRectangle(Core::Rectangle(x, y, x+width, y+height),Core::Rectangle(0, 0, 1, 1));

	ui_render->SetShaderMode(UIRender::kCoolDown);
	Vector4 cdVar(fProgress, 0.f, 0.f, color);
	gDx9Device->SetPixelShaderConstantF(PS_CONSTANT_COOLDOWNTIME, &cdVar.x);
	ui_render->SetTexture(texture_content);
	ui_render->DrawRectangle(Core::Rectangle(x, y, x+width, y+height),Core::Rectangle(0, 0, 1, 1));
	ui_render->SetShaderMode(UIRender::kCommon);

	if (texture_icon)
	{
		ui_render->SetTexture(texture_icon);
		ui_render->DrawRectangle(Core::Rectangle(x-offset/2, y-offset/2-12, x+width+offset/2, y+height+offset/2-12),Core::Rectangle(0, 0, 1, 1), Core::ARGB(color*255,255,255,255));
	}
}

void InGameUINew::UpdataMvp()
{
	if (anim_pictureIn)
	{
		anim_pictureIn->Update();
	}
	if (anim_pictureOut)
	{
		anim_pictureOut->Update();
	}
	if (anim_picture_Mvp_In)
	{
		anim_picture_Mvp_In->Update();
	}
	if (anim_picture_Mvp_Out)
	{
		anim_picture_Mvp_Out->Update();
	}

	Game * game = gGame;
	tempc_ptr(Character) My_play = gLevel->GetPlayer();
	if(!My_play)
		return;

	if ((int)My_play->all_score == 0 || (gLevel->game_type == RoomOption::kBossMode2 && My_play->GetTeam() == 1))
	{
		if (is_Mvp)
		{
			is_Mvp = false;
			SetMvp_State(false);
		}
		return;
	}
	for (int team = 0 ;team < 2 ; team++)
	{
		for (uint rank = 0; rank < game->scores->teams[team].Size(); rank ++)
		{
			Character * c = game->scores->teams[team][rank];
			if (My_play->all_score < c->all_score)
			{
				is_Mvp = false;
				SetMvp_State(false);
				return;
			}
			if (My_play->all_score == c->all_score)
			{
				if (My_play->num_killed <= c->num_killed)
				{
					if (c->num_killed > My_play->num_killed )
					{
						is_Mvp = false;
						SetMvp_State(false);
						return;
					}
					else if (My_play->num_killed == c->num_killed && c->num_assist > My_play->num_assist)
					{
						is_Mvp = false;
						SetMvp_State(false);
						return;
					}
					else if (My_play->num_killed == c->num_killed && c->num_assist == My_play->num_assist && c->num_died < My_play->num_died)
					{
						is_Mvp = false;
						SetMvp_State(false);
						return;
					}
				}
			}
		}
	}
	if (is_Mvp != true)
	{
		SetMvp_State(true);
	}
}
void InGameUINew::UpdataCard()
{
	if (anim_picture_Card_Out)
	{
		anim_picture_Card_Out->Update();
	}
	if (anim_picture_bigCard_Out)
	{
		anim_picture_bigCard_Out->Update();
	}
	if (anim_picture_bigCard_Out_next)
	{
		anim_picture_bigCard_Out_next->Update();
	}
}


void InGameUINew::SetCard_State(int num)
{
	if (num > 0)
	{
		anim_picture_Card_Out->SetPostion(231 +(num - 1)*40,-41);
		anim_picture_bigCard_Out->SetPostion(231 +(num - 1)*40,-41);
		anim_picture_bigCard_Out_next->SetPostion(231 +(num - 1)*40,-41);
	}
	if (anim_picture_Card_Out)
	{		
		anim_picture_Card_Out->Setplay(true);
	}
	if (anim_picture_bigCard_Out)
	{
		anim_picture_bigCard_Out->Setplay(true);
	}
}

void InGameUINew::SetMvp_State(bool is_play)
{
	if (anim_pictureIn)
	{
		anim_pictureIn->Setplay(is_play);
	}
	if (anim_pictureOut)
	{
		anim_pictureOut->Setplay(is_play);
	}
	if (anim_picture_Mvp_In)
	{
		anim_picture_Mvp_In->Setplay(is_play);
	}
	if (anim_picture_Mvp_Out)
	{
		anim_picture_Mvp_Out->Setplay(is_play);
	}
	if (is_play)
		gLevel->mvp_sound->start();
	else
		gLevel->mvp_sound->stop();
	
}

void InGameUINew::_DrawSmallMapBG(by_ptr(UIRender) ui_render)
{
	if (RoomOption::kEditMode == gLevel->game_type || RoomOption::kTDMode == gLevel->game_type)
		return;

	tempc_ptr(Character) viewer = gLevel->GetViewer();
	if (viewer)
	{
		Matrix44 view;
		Matrix44 world;
		Core::Vector3 rt_size = gGame->guiSys->GetSize();

		view.SetScaleXYZ(2.0f/rt_size.x, -2.0f/rt_size.y, 0);
		world.SetTranslationXYZ(-(rt_size.x/2), -(rt_size.y/2), 0);
		ui_render->SetView(view);
		ui_render->SetWorld(world);

		ui_render->DrawTextureWindow(Core::Vector2(0, 0), 230, 199, ui_smallmap_bg, Core::Rectangle(0, 0, 1, 1), Core::ARGB(255,255,255,255));

		ui_render->SetTexture(small_map);
		ui_render->BeginRectangleList(1);
		ui_render->Vertex(4, 4, 0, 0, 0, ARGB(200, 255, 255, 255));
		ui_render->Vertex(226, 195, 0, 1, 1, ARGB(200, 255, 255, 255));
		ui_render->End();
	}

 #ifndef MASTER
 	if (1)
 	{
 		Core::Vector2 move;
 		move.y = gGame->input->IsKeyRepeated(KC_NUMPAD8) - gGame->input->IsKeyRepeated(KC_NUMPAD2);
 		move.x = gGame->input->IsKeyRepeated(KC_NUMPAD6) - gGame->input->IsKeyRepeated(KC_NUMPAD4);
 
 		if (gGame->input->IsKeyDown(KC_LSHIFT))
 		{
 			gLevel->map_center += move * 0.1f;
 		}
 		else
 		{
 			gLevel->map_size += move * 0.1f;
 		}
 
 		if (gGame->input->IsKeyDown(KC_NUMPAD5))
 		{
 			CStrBuf<256> buff;
 			ARGB font_color = ARGB(251, 245, 231);
 			ARGB bg_color = ARGB(0, 0, 0, 0);
 			buff.format(gLang->GetTextW(L"��ͼ��Ϣ��%g, %g, %g, %g"), gLevel->map_center.x, gLevel->map_center.y, gLevel->map_size.x, gLevel->map_size.y);
 			ui_render->DrawStringShadow(ui_render->font_simhei_12, font_color, bg_color, Core::ARGB(0,0,0,0), Core::Rectangle(220, 0, 0, 0), buff, Unit::kAlignLeftTop);
 		}
 	}
 #endif
}

void InGameUINew::_DrawDeadUi(by_ptr(UIRender) ui_render)
{
	Matrix44 oldworld, world, oldview,view;
	oldworld = ui_render->GetWorld();
	world = ui_render->GetWorld();
	oldview = ui_render->GetView();
	Core::Vector3 rt_size = gGame->guiSys->GetSize();

	tempc_ptr(Character) viewer = gLevel->GetViewer();
	tempc_ptr(Character) player = gLevel->GetPlayer();

	ARGB font_color = ARGB(255, 239, 206);
	//0:�� 2���� 3���� 4����
	ARGB weapon_name_colors[] = {ARGB(255, 255, 255, 255), 	ARGB(255, 255, 96, 0), 		ARGB(255, 181, 58, 212),	ARGB(255, 101, 179, 239),
								 ARGB(255, 128, 239, 147), 	ARGB(255, 128, 239, 147), 	ARGB(255, 255, 255, 78), 	ARGB(255,128,239,147),};
	ARGB bg_color = ARGB(0, 0, 0, 0);
	ARGB name_colors[] = { ARGB(15, 230, 15), ARGB(230, 15, 15) };

	view.SetScaleXYZ(2.0f / rt_size.x, -2.0f / rt_size.y, 0.0f);
	view.TranslateXYZ(-1.0f, 1.0f, 0.0f);
	view.TranslateLocalXYZ(-0.5f, -0.5f, 0.0f);
	ui_render->SetWorld(Core::Matrix44::kIdentity);
	ui_render->SetView(view);
	int ui_x = -351;
	int ui_y = 0;

	if (player && player->IsDied() && gLevel->GetPlayer()->GetTeam() != 2)
	{
		//if (gGame->camera->control_mode == Camera::kDiedMode)
		if (player->died_timer <= 3.5f && player->died_timer >= 1.f && player->current_hit_info.to_uid != player->current_hit_info.from_uid && player->uid == player->current_hit_info.to_uid)
		{
			tempc_ptr(Character) c = gLevel->GetCharacter(player->current_hit_info.from_uid);
			if(c && c != player && gLevel->game_type != RoomOption::kTDMode)
			{
				Matrix44 world;
				world.SetTranslationXYZ(0,0,0);
				ui_render->SetWorld(world);
				_DrawWeaponTip(ui_render,c);

				Vector3 rt_size = gGame->guiSys->GetSize();
				world.SetTranslationXYZ(rt_size.x, 0, 0);
				ui_render->SetWorld(world);

				ui_render->SetTexture(all_tipBg[c->GetTeam()]);
				ui_render->DrawWindow(Core::Rectangle(ui_x,ui_y,ui_x+357,ui_y+111),Core::Rectangle(12,12,13,15),Core::Rectangle(12.0f / 51.f, 12.0f / 51.f, 13.0f / 51.f, 15.0f / 51.f));

				if (c->GetCurCharinfo())
				{
					//ʮ������ֵ
					float fSc = (float)c->hp / (float)c->max_hp;
					fSc = Core::Clamp(fSc,0,1);
					ui_render->DrawTextureWindow(Core::Vector2(ui_x+17, ui_y+12), 88, 88, ui_bottom_info_hp_kuang);
					ui_render->DrawTextureWindow(Core::Vector2(ui_x+17, ui_y+12+88-(88*fSc)), 88, 88*fSc, ui_bottom_info_hp, Core::Rectangle(0, 1.0f - fSc, 1, 1));
				}

				//���ӱ�����Ƭ
				int card_num = (int)c->business_card;
				if (card_num > 0 && card_num < 18)
				{
					ui_render->DrawTextureWindow(Core::Vector2(ui_x+120, ui_y+55), 223, 40, ui_common_name_cards[card_num-1]);
				}
				if (c->is_vip == 1 && card_num == 0)
				{
					ui_render->DrawTextureWindow(Core::Vector2(ui_x+120, ui_y+55), 223, 40,ui_common_vip_name_card);
				}
				Core::CStrBuf<256> buff;
				buff.format(gLang->GetTextW(L"ɱ���������"));
				ui_render->DrawFontWindow(Core::Vector2(ui_x+115, ui_y+18), 100, 22, ui_render->font_simhei_20, font_color, bg_color, buff, Unit::kAlignLeftMiddle);
				Core::String strname2 = c->GetName().Str();
				gGame->global->Translate(strname2);
				buff.format("%s",c->GetName().Str());
				ui_render->DrawFontWindow(Core::Vector2(ui_x+120, ui_y+55), 217, 34, ui_render->font_simhei_20, font_color, bg_color, strname2, Unit::kAlignCenterMiddle);


				tempc_ptr(WeaponInfo) killerweapon = player->current_hit_info.weapon;
				if (killerweapon && killerweapon->icon)
				{
					_DrawTips_show(ui_render,killerweapon,c,buff,ui_x,ui_y);
				}
				/*buff.format(gLang->GetTextW(L"����û��֣�      %d��"),player->killerinfo.totalscore);
				ui_render->DrawFontWindow(Core::Vector2(ui_x + 50, ui_y+361), 307, 20, ui_render->font_simhei_24, font_color, bg_color, buff, Unit::kAlignLeft);
				buff.format(gLang->GetTextW(L"������            %d��"),player->killerinfo.assistnum);
				ui_render->DrawFontWindow(Core::Vector2(ui_x + 50, ui_y+391), 307, 20, ui_render->font_simhei_24, font_color, bg_color, buff, Unit::kAlignLeft);*/
			}
			
		}
		else if (player->died_temp_timer <= 0 && gLevel->GetPlayer()->GetTeam() != 2)
		{
			Core::CStrBuf<256> buff;
			world.SetTranslationXYZ(0, 0 ,0);
			ui_render->SetWorld(world);

			ui_render->SetTexture(NullPtr);
			ui_render->DrawRectangle(Core::Rectangle(0,0,rt_size.x,200),Core::Rectangle(0,0,1,1),Core::ARGB(180,0,0,0));
			ui_render->DrawRectangle(Core::Rectangle(0,rt_size.y-170,rt_size.x,rt_size.y),Core::Rectangle(0,0,1,1),Core::ARGB(180,0,0,0));

			world.SetTranslationXYZ(rt_size.x/2, 0, 0);
			ui_render->SetWorld(world);
			if (gLevel->game_type != RoomOption::kNovice && gLevel->room_option.character_id == 0)
			{
				b_time += Task::GetFrameTime()*4;
				float src = Core::Sin(b_time);
				b_time = b_time > 36000.f ? 0.f : b_time;

				ui_render->DrawFontWindow(Core::Vector2(20,79), 250, 30, ui_render->font_simhei_24, font_color, bg_color, gLang->GetTextW(L"����ְҵ"), Unit::kAlignLeftMiddle, true);
				ui_render->DrawTextureWindow(Core::Vector2(-65-4*src,70-4*src),60+8*src,60+8*src,ui_b);

				ui_render->DrawFontWindow(Core::Vector2(20,150), 250, 30, ui_render->font_simhei_24, font_color, bg_color, gLang->GetTextW(L"������Ϸ����ʱ��"), Unit::kAlignLeftMiddle, true);
				ui_render->DrawTextureWindow(Core::Vector2(-65-4*src,141-4*src),60+8*src,60+8*src,ui_f9);
				ui_render->DrawTextureWindow(Core::Vector2(-125-35,140),32,44,ui_camera);
			}
			else if(gLevel->room_option.character_id > 0)
			{
				ui_render->DrawFontWindow(Core::Vector2(-125+35,79), 250, 30, ui_render->font_simhei_24, font_color, bg_color, gLang->GetTextW(L"��ǰΪְҵ����ս���ܸ���ְҵ"), Unit::kAlignCenterMiddle, true);
			}
			else
			{
				ui_render->DrawFontWindow(Core::Vector2(-145,115), 290, 30, ui_render->font_simhei_24, font_color, bg_color, gLang->GetTextW(L"���ֹ�ֻ��ѡ��һ�ν�ɫ��5��ǰ���Զ�ν������ֹأ�"), Unit::kAlignCenterMiddle, true);
			}
			
			world.SetTranslationXYZ(rt_size.x/2, rt_size.y-200, 0);
			ui_render->SetWorld(world);

			if (gLevel->start_chooseperson_time > 0 && gLevel->room_option.character_id == 0)
			{
				buff.format(gLang->GetTextW(L"%d ������ѡ��ְҵ������Ϸ"),(int)gLevel->start_chooseperson_time+1);
				ui_render->DrawFontWindow(Core::Vector2(-130,148), 260, 25, ui_render->font_simhei_24, font_color, bg_color, buff, Unit::kAlignCenterMiddle, true);
			}

			float progress = Clamp(player->relife_time / player->relife_maxtime, 0, 1);
			if (progress < 1 && gLevel->game_type != RoomOption::kTeamDeathMatch && gLevel->game_type != RoomOption::kBoss && gLevel->game_type != RoomOption::kBossPVE && gLevel->game_type != RoomOption::kBombMode && gLevel->game_type != RoomOption::kZombieMode && gLevel->game_type != RoomOption::kCommonZombieMode || (gLevel->game_type == RoomOption::kCommonZombieMode && player->relife_flag ))
			{
				Core::Rectangle border1(5, 6, 7, 7);
				Core::Rectangle border2(5, 6, 7, 7);
				buff.format(gLang->GetTextW(L"%d �������"),(int)(player->relife_maxtime-player->relife_time+1));
				ui_render->DrawFontWindow(Core::Vector2(-100,148-100), 200, 20, ui_render->font_simhei_16, font_color, bg_color, buff, Unit::kAlignCenterMiddle, true);

				ui_render->SetTexture(ui_progress_bar_border);
				ui_render->DrawWindow(Core::Rectangle(-100, 170-100, 100,184-100), Core::Rectangle(5, 6, 7, 7), Core::Rectangle(5.0f / 15.f, 6.0f / 15.f, 7.0f / 15.f, 7.0f / 15.f));
				ui_render->SetTexture(ui_progress_bar_body);
				ui_render->DrawWindow(Core::Rectangle(-100, 170-100, -100 + 194 * progress + 6, 184-100), Core::Rectangle(5, 5, 6, 6), Core::Rectangle(5.0f / 15.f, 5.0f / 15.f, 6.0f / 15.f, 6.0f / 15.f));
			}
			else if(gLevel->game_type == RoomOption::kZombieMode && player->GetTeam() == 1)
			{
				Core::Rectangle border1(5, 6, 7, 7);
				Core::Rectangle border2(5, 6, 7, 7);
				buff.format(gLang->GetTextW(L"%d �������"),(int)(player->relife_maxtime-player->relife_time+1));
				ui_render->DrawFontWindow(Core::Vector2(-100,148-100), 200, 20, ui_render->font_simhei_16, font_color, bg_color, buff, Unit::kAlignCenterMiddle, true);

				ui_render->SetTexture(ui_progress_bar_border);
				ui_render->DrawWindow(Core::Rectangle(-100, 170-100, 100,184-100), Core::Rectangle(5, 6, 7, 7), Core::Rectangle(5.0f / 15.f, 6.0f / 15.f, 7.0f / 15.f, 7.0f / 15.f));
				ui_render->SetTexture(ui_progress_bar_body);
				ui_render->DrawWindow(Core::Rectangle(-100, 170-100, -100 + 194 * progress + 6, 184-100), Core::Rectangle(5, 5, 6, 6), Core::Rectangle(5.0f / 15.f, 5.0f / 15.f, 6.0f / 15.f, 6.0f / 15.f));
			}
			else if ((gLevel->game_type == RoomOption::kBoss ||( gLevel->game_type == RoomOption::kBossPVE && player_die_time > 0.0f)) && player->GetCurCharinfo() && gGame->channel_connection->round_win_team < 0)
			{
				tempc_ptr(BaseCharacterInfo) base_info = player->basecharacter_info;
				if (base_info)
				{
					int coin = base_info->fu_huo_bi;
					
					//LogSystem.WriteLinef("fuhuobi == %d",coin);
					if (coin > 0 )
					{
						ui_render->DrawFontWindow(Core::Vector2(-100,148-100), 200, 20, ui_render->font_simhei_16, font_color, bg_color, gLang->GetTextW(L"����V��������������"), Unit::kAlignCenterMiddle, true);
						if (gLevel->game_type == RoomOption::kBossPVE)
						{
							buff.format(gLang->GetTextW(L"ÿ�θ������� 1 �����,���ܸ��� %d ��,���� %d ����ʹ�ã�"),10 - fu_huo_bi_use_count,(int)ceil(player_die_time));
							ui_render->DrawFontWindow(Core::Vector2(-100,148-80), 200, 20, ui_render->font_simhei_16, font_color, bg_color, buff , Unit::kAlignCenterMiddle, true);
						} 
						else
						{
							ui_render->DrawFontWindow(Core::Vector2(-100,148-80), 200, 20, ui_render->font_simhei_16, font_color, bg_color, gLang->GetTextW(L"ÿ�θ������� 1 �����,�������� 2 ��"), Unit::kAlignCenterMiddle, true);
						}
						ui_render->DrawTextureWindow(Core::Vector2(-28,148-50),56,56,ui_bottom_info_fuhuobi);
						buff.format(gLang->GetTextW(L"x %d"),coin);						
						ui_render->DrawFontWindow(Core::Vector2(-230,148-35), 200, 20, ui_render->font_simhei_16, font_color, bg_color, gLang->GetTextW(L"ʣ��"), Unit::kAlignRightMiddle, true);
						ui_render->DrawFontWindow(Core::Vector2(30,148-35), 200, 20, ui_render->font_simhei_16, font_color, bg_color, buff, Unit::kAlignLeftMiddle, true);
						
					}
					else
					{
						ui_render->DrawFontWindow(Core::Vector2(-100,148-100), 200, 20, ui_render->font_simhei_16, font_color, bg_color, gLang->GetTextW(L"����V��������������"), Unit::kAlignCenterMiddle, true);
						if (gLevel->game_type == RoomOption::kBossPVE)
						{
							buff.format(gLang->GetTextW(L"ÿ�θ������� 1 �����,���ܸ��� %d ��,���� %d ����ʹ�ã�"),10 - fu_huo_bi_use_count,(int)ceil(player_die_time));
							ui_render->DrawFontWindow(Core::Vector2(-100,148-80), 200, 20, ui_render->font_simhei_16, font_color, bg_color, buff , Unit::kAlignCenterMiddle, true);
						} 
						else
						{
							ui_render->DrawFontWindow(Core::Vector2(-100,148-80), 200, 20, ui_render->font_simhei_16, font_color, bg_color, gLang->GetTextW(L"ÿ�θ������� 1 �����,�������� 2 ��"), Unit::kAlignCenterMiddle, true);
						}
						ui_render->DrawTextureWindow(Core::Vector2(-105,148-50),56,56,ui_bottom_info_fuhuobi);
						buff.format(gLang->GetTextW(L"x %d ���㣬�޷���������"),coin);				
						ui_render->DrawFontWindow(Core::Vector2(-307,148-35), 200, 20, ui_render->font_simhei_16, font_color, bg_color, gLang->GetTextW(L"���"), Unit::kAlignRightMiddle, true);
						ui_render->DrawFontWindow(Core::Vector2(-56,148-35), 200, 20, ui_render->font_simhei_16, font_color, bg_color, buff, Unit::kAlignLeftMiddle, true);
					}
				}				
			}
			
			if (viewer && viewer != player && gLevel->GetPlayer()->GetTeam() != 2)
			{
				Vector3 rt_size = gGame->guiSys->GetSize();
				world.SetTranslationXYZ(rt_size.x, rt_size.y-450, 0);
				ui_render->SetWorld(world);

				ui_render->SetTexture(all_tipBg[viewer->GetTeam()]);
				ui_render->DrawWindow(Core::Rectangle(ui_x,ui_y-111,ui_x+357,ui_y),Core::Rectangle(12,12,13,15),Core::Rectangle(12.0f / 51.f, 12.0f / 51.f, 13.0f / 51.f, 15.0f / 51.f));


				if (viewer->GetCurCharinfo())
				{
					//ʮ������ֵ
					float fSc = (float)viewer->hp / viewer->max_hp;
					fSc = Core::Clamp(fSc,0,1);
					ui_render->DrawTextureWindow(Core::Vector2(ui_x+17, ui_y-111+12), 88, 88, ui_bottom_info_hp_kuang);
					ui_render->DrawTextureWindow(Core::Vector2(ui_x+17, ui_y-111+12+88-(88*fSc)), 88, 88*fSc, ui_bottom_info_hp, Core::Rectangle(0, 1.0f - fSc, 1, 1));
				}

				//���ӱ�����Ƭ
				int card_num = (int)viewer->business_card;
				if (card_num > 0 && card_num < 18)
				{
					ui_render->DrawTextureWindow(Core::Vector2(ui_x+120, ui_y-111+55), 223, 40, ui_common_name_cards[card_num-1]);
				}
				if (viewer->is_vip == 1 && card_num == 0)
				{
					ui_render->DrawTextureWindow(Core::Vector2(ui_x+120, ui_y-111+55), 223, 40,ui_common_vip_name_card);
				}
				Core::CStrBuf<256> buff;
				buff.format(gLang->GetTextW(L"��ǰ�۲�"));
				ui_render->DrawFontWindow(Core::Vector2(ui_x+115, ui_y-111+18), 100, 22, ui_render->font_simhei_20, font_color, bg_color, buff, Unit::kAlignLeftMiddle);
				buff.format("%s",viewer->GetName().Str());
				ui_render->DrawFontWindow(Core::Vector2(ui_x+100, ui_y-111+55), 217, 34, ui_render->font_simhei_28, font_color, bg_color, buff, Unit::kAlignCenterMiddle);
				tempc_ptr(Character) c = viewer;
				if (c && c != player)
				{
					tempc_ptr(WeaponBase) weapon = c->GetWeapon();
					if (weapon)
					{
						tempc_ptr(WeaponInfo) killerweapon = weapon->weapon_info;
						if (killerweapon && killerweapon->icon)
						{
							_DrawTips_show(ui_render,killerweapon,c,buff,ui_x,ui_y-111);
						}
					}					
				}				
			}
		}
		
		
		if(player && player->died_temp_timer > 0)
		{
			Vector3 rt_size = gGame->guiSys->GetSize();
			world.SetTranslationXYZ(rt_size.x, 0, 0);
			ui_render->SetWorld(world);
			//���ֹ�ɱ
			Core::CStrBuf<256> buff;
			ui_render->SetTexture(all_tipBg[player->GetTeam()]);
			ui_render->DrawWindow(Core::Rectangle(ui_x-50,ui_y+321,ui_x+357,ui_y+432),Core::Rectangle(12,12,13,15),Core::Rectangle(12.0f / 51.f, 12.0f / 51.f, 13.0f / 51.f, 15.0f / 51.f));
			buff.format(gLang->GetTextW(L"���ֹ�ɱ��      %d��"),player->killerinfo.killnum);

			ui_render->DrawFontWindow(Core::Vector2(ui_x, ui_y+331), 307, 20, ui_render->font_simhei_24, font_color, bg_color, buff, Unit::kAlignLeft);

			buff.format(gLang->GetTextW(L"����û��֣�   %d��"),player->killerinfo.totalscore);
			ui_render->DrawFontWindow(Core::Vector2(ui_x, ui_y+361), 307, 20, ui_render->font_simhei_24, font_color, bg_color, buff, Unit::kAlignLeft);
			buff.format(gLang->GetTextW(L"������         %d��"),player->killerinfo.assistnum);
			ui_render->DrawFontWindow(Core::Vector2(ui_x, ui_y+391), 307, 20, ui_render->font_simhei_24, font_color, bg_color, buff, Unit::kAlignLeft);
			//�����ɱ�������
			F32 screeny = gGame->guiSys->GetSize().y;


			int deadcount =  (screeny - (ui_y+450))/ 38;

			deadcount = Core::Clamp(deadcount, 0 , player->killerinfo.arry_losters.Size());
			if(deadcount)
			{
				ui_render->SetTexture(all_tipBg[player->GetTeam()]);
				ui_render->DrawWindow(Core::Rectangle(ui_x-50,ui_y+436,ui_x+357,ui_y+436 + 50 + deadcount * 38),Core::Rectangle(12,12,13,15),Core::Rectangle(12.0f / 51.f, 12.0f / 51.f, 13.0f / 51.f, 15.0f / 51.f));
				buff.format(gLang->GetTextW(L"�����ɱ�������"));

				ui_render->DrawFontWindow(Core::Vector2(ui_x , ui_y+448), 357, 20, ui_render->font_simhei_28, font_color, bg_color, buff, Unit::kAlignCenterMiddle);

				int curline = 0;
				while(deadcount)
				{
					int index = player->killerinfo.arry_losters.Size() - deadcount ;
					curline ++;
					buff.format("%s",PeopleName_cut(player->killerinfo.arry_losters[index].lostername,5));
					ui_render->DrawFontWindow(Core::Vector2(ui_x + 20, ui_y+440 + curline * 38), 307, 20, ui_render->font_simhei_22, font_color, bg_color, buff, Unit::kAlignLeft);
					U32 icount = 0;
					for(U32 i = 0; i < player->killerinfo.arry_losters[index].kills_kind.Size(); i++)
					{

						switch(player->killerinfo.arry_losters[index].kills_kind[i])
						{
						case kFight:
							{
								ui_render->DrawTextureWindow(Core::Vector2(ui_x + 145 + (int)icount * 40, ui_y+440 + curline * 38), 40, 38,ui_kill_textures[5]);
								//ui_render->SetTexture(ui_kill_textures[5]);
								icount++;
							}
							break;
						case kHead:
							{
								ui_render->DrawTextureWindow(Core::Vector2(ui_x + 145 + (int)icount * 40, ui_y+440 + curline * 38), 40, 38,ui_kill_textures[6]);
								icount++;						
							}
							break;
						case kBoost:
							{
								ui_render->DrawTextureWindow(Core::Vector2(ui_x + 145 + (int)icount * 40, ui_y+440 + curline * 38),40, 38,ui_kill_textures[8]);
								icount++;
							}
							break;
						case kSustain_Burn:
							{
								ui_render->DrawTextureWindow(Core::Vector2(ui_x + 145 + (int)icount * 40, ui_y+440 + curline * 38), 40, 38,ui_kill_textures[10]);
								icount++;						
							}
							break;
						case kSustain_Poison:
							{
								ui_render->DrawTextureWindow(Core::Vector2(ui_x + 145 + (int)icount * 40, ui_y+440 + curline * 38), 40, 38,ui_kill_textures[23]);
								icount++;				
							}
							break;
						case kControl:
							{
								ui_render->DrawTextureWindow(Core::Vector2(ui_x + 145 + (int)icount * 40, ui_y+440 + curline * 38), 40, 38,ui_kill_textures[9]);
								icount++;						
							}
							break;
						case kReveng:
							{
								ui_render->DrawTextureWindow(Core::Vector2(ui_x + 145 + (int)icount * 40, ui_y+440 + curline * 38), 40, 38,ui_kill_textures[7]);
								icount++;						
							}
							break;
						case KKill_King:
							{
								ui_render->DrawTextureWindow(Core::Vector2(ui_x + 145 + (int)icount * 40, ui_y+440 + curline * 38), 40, 38,ui_kill_textures[18]);
								icount++;
							}
							break;
						case KKill_Zombie:
							{
								ui_render->DrawTextureWindow(Core::Vector2(ui_x + 145 + (int)icount * 40, ui_y+440 + curline * 38), 40, 38,ui_kill_textures[20]);
								icount++;
							}
							break;
						case KKill_Kill:
							{
								ui_render->DrawTextureWindow(Core::Vector2(ui_x + 145 + (int)icount * 40, ui_y+440 + curline * 38), 40, 38,ui_kill_textures[21]);
								icount++;
							}
							break;
						
						case KKill_Knockdown:
							{
								ui_render->DrawTextureWindow(Core::Vector2(ui_x + 145 + (int)icount * 40, ui_y+440 + curline * 38), 40, 38,ui_kill_textures[22]);
								icount++;
							}
							break;
						case KKill_SkillKill:
							{
								ui_render->DrawTextureWindow(Core::Vector2(ui_x + 145 + (int)icount * 40, ui_y+440 + curline * 38), 40, 38,ui_kill_textures[23]);
								icount++;
							}
							break;
						case KKill_SkillKnockdown:
							{
								ui_render->DrawTextureWindow(Core::Vector2(ui_x + 145 + (int)icount * 40, ui_y+440 + curline * 38), 40, 38,ui_kill_textures[24]);
								icount++;
							}
							break;
						case kKillBoss:
							{
								ui_render->DrawTextureWindow(Core::Vector2(ui_x + 145 + (int)icount * 40, ui_y+440 + curline * 38), 40, 38,ui_kill_textures[25]);
								icount++;
							}
							break;
						case kCommonZombie_normal:
							{
								ui_render->DrawTextureWindow(Core::Vector2(ui_x + 145 + (int)icount * 40, ui_y+440 + curline * 38), 40, 38,ui_kill_textures[26]);
								icount++;
							}
							break;
						case kCommonZombie_King:
							{
								ui_render->DrawTextureWindow(Core::Vector2(ui_x + 145 + (int)icount * 40, ui_y+440 + curline * 38), 40, 38,ui_kill_textures[27]);
								icount++;
							}
							break;
						case kCommonZombie_LastKing:
							{
								ui_render->DrawTextureWindow(Core::Vector2(ui_x + 145 + (int)icount * 40, ui_y+440 + curline * 38), 40, 38,ui_kill_textures[28]);
								icount++;
							}
							break;
						case kCommonZombie_infect:
							{
								ui_render->DrawTextureWindow(Core::Vector2(ui_x + 145 + (int)icount * 40, ui_y+440 + curline * 38), 40, 38,ui_kill_textures[29]);
								icount++;
							}
							break;
						case kCommonZombie_infect_Last:
							{
								ui_render->DrawTextureWindow(Core::Vector2(ui_x + 145 + (int)icount * 40, ui_y+440 + curline * 38), 40, 38,ui_kill_textures[30]);
								icount++;
							}
							break;
						case kBossmode2_Boss:
							{
								ui_render->DrawTextureWindow(Core::Vector2(ui_x + 145 + (int)icount * 40, ui_y+440 + curline * 38), 40, 38,ui_kill_textures[31]);
								icount++;
							}
							break;
						case kCommonZombie_disappear:
							{
								ui_render->DrawTextureWindow(Core::Vector2(ui_x + 145 + (int)icount * 40, ui_y+440 + curline * 38), 40, 38,ui_kill_textures[33]);
								icount++;
							}
							break;
						case kCommonZombie_drug:
							{
								ui_render->DrawTextureWindow(Core::Vector2(ui_x + 145 + (int)icount * 40, ui_y+440 + curline * 38), 40, 38,ui_kill_textures[34]);
								icount++;
							}
							break;
						case kCommonZombie_charge:
							{
								ui_render->DrawTextureWindow(Core::Vector2(ui_x + 145 + (int)icount * 40, ui_y+440 + curline * 38), 40, 38,ui_kill_textures[35]);
								icount++;
							}
							break;
						//case kBossmode2_Boss_hit:
						//	{
						//		ui_render->DrawTextureWindow(Core::Vector2(ui_x + 145 + (int)icount * 40, ui_y+440 + curline * 38), 40, 38,ui_kill_textures[32]);
						//		icount++;
						//	}
						//	break;
						default:
							break;
						}
						//ui_render->DrawWindow(Core::Rectangle(ui_x + 60 + i * 40, ui_y+440 + curline * 38,ui_x + 60 + i * 40 + 40,ui_y+440 + curline * 38 + 38),Core::Rectangle(6,6,6,6),Core::Rectangle(6.0f / 16.f, 6.0f / 16.f, 6.0f / 16.f, 6.0f / 16.f));

						//ui_render->DrawRectangle(Core::Rectangle(ui_x + 60 + i * 40, ui_y+440 + curline * 38,ui_x + 60 + i * 40 + 40,ui_y+440 + curline * 38 + 38),Core::Rectangle(0,0,1,1),Core::ARGB(128,0,0,0));	
					}					
					deadcount--;
				}
			}

		}
	}



	ui_render->SetView(oldview);
	ui_render->SetWorld(oldworld);
}

void InGameUINew::_DrawTips_show(by_ptr(UIRender) ui_render,tempc_ptr(WeaponInfo) killerweapon,tempc_ptr(Character) c,Core::CStrBuf<256> buff,int ui_x,int ui_y)
{
	ARGB font_color = ARGB(255, 239, 206);
	//0:�� 2���� 3���� 4����  5:��ɫ
	ARGB weapon_name_colors[] = {ARGB(255, 255, 255, 255), 	ARGB(255, 255, 96, 0), 		ARGB(255, 181, 58, 212),	ARGB(255, 101, 179, 239),
								 ARGB(255, 128, 239, 147), 	ARGB(255, 255, 96, 0), 		ARGB(255, 255, 255, 78), 	ARGB(255,128,239,147),};
	ARGB bg_color = ARGB(0, 0, 0, 0);
	ARGB name_colors[] = { ARGB(15, 230, 15), ARGB(230, 15, 15) };

	ui_render->SetTexture(all_tipBg[c->GetTeam()]);
	ui_render->DrawWindow(Core::Rectangle(ui_x,ui_y+106,ui_x+357,ui_y+330),Core::Rectangle(12,12,13,15),Core::Rectangle(12.0f / 51.f, 12.0f / 51.f, 13.0f / 51.f, 15.0f / 51.f));
	ui_render->SetTexture(weapon_tipBg);
	ui_render->DrawWindow(Core::Rectangle(ui_x+8, ui_y+119,ui_x+344, ui_y+119+198), Core::Rectangle(216 ,36, 43, 140),Core::Rectangle(216.0f / 262.f, 36.0f / 198.f, 43.0f / 262.f, 140.0f / 198.f));
	/*buff.format(gLang->GetTextW(L"%sЯ��������"),c->GetName().Str());
	ui_render->DrawFontWindow(Core::Vector2(ui_x, ui_y+122), 357, 20, ui_render->font_simhei_28, font_color, bg_color, buff, Unit::kAlignCenterMiddle);*/

	int weapon_colors = killerweapon->color;					
	buff.format("%s",killerweapon->display_name);
	ui_render->DrawFontWindow(Core::Vector2(ui_x+79, ui_y+125), 357-85, 20, ui_render->font_simhei_24, ARGB(255, 0, 0, 0), bg_color, buff, Unit::kAlignCenterMiddle);
	ui_render->DrawFontWindow(Core::Vector2(ui_x+82, ui_y+122), 357-82, 20, ui_render->font_simhei_24, weapon_name_colors[weapon_colors], bg_color, buff, Unit::kAlignCenterMiddle);
	
	if(killerweapon->level >= 0 && killerweapon->level < 99)
		ui_render->DrawTextureWindow(Core::Vector2(ui_x+20, ui_y+125), 54, 54, ui_common_weaponlevel[killerweapon->level]);
	else
		ui_render->DrawTextureWindow(Core::Vector2(ui_x+20, ui_y+125), 54, 54, ui_common_notlevel);
	/*buff.format("%s",killerweapon->name.Str());
	ui_render->DrawFontWindow(Core::Vector2(ui_x, ui_y+151), 357, 34, ui_render->font_simhei_28, font_color, bg_color, buff, Unit::kAlignCenterMiddle);*/
	ui_render->DrawTextureWindow(Core::Vector2(ui_x+15, ui_y+210), 122, 52, killerweapon->icon);
	if(killerweapon->star && killerweapon->star > 0)
	{
		ui_render->DrawTextureWindow(Core::Vector2(ui_x+200, ui_y+158), 107, 17, ui_weapon[killerweapon->star - 1]);
	}
	UINT weadamage(0),ammooneclip(0),ammoinclip(0);
	float shootrate(0);
	if(killerweapon)
	{
		if(killerweapon->weapon_type == kWeaponTypeGrenade)
		{
			tempc_ptr(GrenadeInfo) grenade = ptr_dynamic_cast<GrenadeInfo>(killerweapon);
			if(grenade)
			{
				weadamage = (grenade->hurt + 50)/2;
			}
		}
		else if (killerweapon->weapon_type == kWeaponTypeSpecial)
		{
			tempc_ptr(SpecialGrenadeInfo) grenade = ptr_dynamic_cast<SpecialGrenadeInfo>(killerweapon);
			if(grenade)
			{
				weadamage = (grenade->hurt + 50)/2;
			}
		}
		else if(killerweapon->weapon_type == kWeaponTypeKnife)
		{
			tempc_ptr(KnifeInfo) knife = ptr_dynamic_cast<KnifeInfo>(killerweapon);
			if(knife)
			{
				weadamage = (knife->stab_hurt + 50)/2;
				shootrate = 10/knife->stab_time;
			}
		}
		else if (killerweapon->weapon_type == kWeaponTypeZombieGun)
		{
			tempc_ptr(ZombieGunInfo) knife = ptr_dynamic_cast<ZombieGunInfo>(killerweapon);
			if(knife)
			{
				weadamage = (knife->stab_hurt + 50)/2;
				shootrate = 10/knife->stab_time;
			}
		}
		else if(killerweapon->weapon_type > kWeaponTypeNone && killerweapon->weapon_type <= kWeaponTypeBow )
		{
			tempc_ptr(GunInfo) gun = ptr_dynamic_cast<GunInfo>(killerweapon);
			if(gun)
			{
				weadamage = (gun->damage + 50)/2;
				shootrate = 1/gun->fire_time  * 10;

			}
		}
		else if(killerweapon->weapon_type >= kWeaponTypeAmmoRocket && killerweapon->weapon_type <= kWeaponTypeAmmoArrow)
		{
			tempc_ptr(AmmoInfo) ammo = ptr_dynamic_cast<AmmoInfo>(killerweapon);
			if(ammo)
			{
				weadamage = (ammo->damage + 50)/2;
				shootrate = 1/ammo->hit_speed * 10;
			}
		}
		weadamage = Core::Clamp(weadamage,0,200);
		shootrate = Core::Clamp(shootrate,0.f,120.f);						

		//ui_render->DrawTextureWindow(Core::Vector2(ui_x+149, ui_y+190), 65, 18, ui_common_power);
		int power =  killerweapon->combat_power;
		int num = 0;
		int x = 0;
		if(power < 99999)
		{
			while (power)
			{					
				num = power%10;
				ui_render->DrawTextureWindow(Core::Vector2((ui_x+287)-16*x, ui_y+198), 16, 20, ui_power_num ,Core::Rectangle(num*16/160.0f, 0, (num+1)*16/160.0f, 1));
				power /= 10;
				x++;				
			}
		}
		else
		{
			for (int i = 0;i < 5;i++)
			{
				ui_render->SetTexture(ui_power_wenhao);
				ui_render->DrawWindow(Core::Rectangle((ui_x+222)+16*i,ui_y+190,(ui_x+222+16)+16*i,ui_y+210),
					Core::Rectangle(0,0,0,0),Core::Rectangle(0.0f /1.f, 0.f / 1.f, 0.0f / 1.f, 0.f / 1.f),Core::ARGB(255,255,255,255),Core::ARGB(255,255,255,255));
			}
		}

		//��������						
		//ui_render->DrawTextureWindow(Core::Vector2(ui_x+149, ui_y+232), 65, 18, ui_common_attack);
		Core::CStrBuf<256> buff;
		ui_render->SetTexture(ui_die_bg);
		ui_render->DrawWindow(Core::Rectangle(ui_x+225,ui_y+236,ui_x+225+114,ui_y+236+16),Core::Rectangle(6,6,6,6),Core::Rectangle(6.0f / 16.f, 6.0f / 16.f, 6.0f / 16.f, 6.0f / 16.f));
		float weaponDamage = killerweapon->hitdamage_gui;
		float weaponSpeed = killerweapon->hitspeed_gui;
		int starcound = 0;
		int starSpeed_cound = 0;
		if (killerweapon->weapon_type == kWeaponTypeSniperGun)
		{
			weaponDamage *= 3;
		}
		if (weaponDamage <= 50)
			starcound = 0;
		else if (weaponDamage > 400)
		{
			starcound = 0;
			weaponDamage = 50.0f;
		}
		else if (weaponDamage > 50 && weaponDamage <= 100)
			starcound = 1;
		else if (weaponDamage > 100 && weaponDamage <= 150)
			starcound = 2;
		else if (weaponDamage > 150 && weaponDamage <= 200)
			starcound = 3;
		else if (weaponDamage > 200 && weaponDamage <= 250)
			starcound = 4;
		else if (weaponDamage > 250 && weaponDamage <= 300)
			starcound = 5;
		else if (weaponDamage > 300 && weaponDamage <= 350)
			starcound = 6;
		else if (weaponDamage > 350 && weaponDamage <= 400)
			starcound = 7;
		//else
		//	starcound = 8;

		if (weaponDamage != 0)
		{
			ui_render->SetTexture(ui_common_skin_bar[starcound]);
			ui_render->DrawWindow(Core::Rectangle(ui_x+226,ui_y+237,ui_x+226+(weaponDamage-starcound*50)*2.28,ui_y+237+12),Core::Rectangle(6,6,6,6),Core::Rectangle(6.0f / 32.f, 6.0f / 12.f, 6.0f / 32.f, 6.0f / 12.f));
		}
			
		if (starcound > 0)
		{
			for (int i = 0;i < starcound;i++)
			{
				ui_render->DrawTextureWindow(Core::Vector2((ui_x+225), ui_y+252), 16, 16, ui_common_little_star);
				buff.format("X %d",starcound);
				ui_render->DrawFontWindow(Core::Vector2((ui_x+225+26), ui_y+252), 109, 20, ui_render->font_simhei_14, Core::ARGB(178,255, 255, 255), ARGB(0, 0, 0, 0), buff, Unit::kAlignLeftTop);
			}
		}

		//����ٶ�	
		if (weaponSpeed <= 50)
			starSpeed_cound = 0;
		else if (weaponSpeed > 50 && weaponSpeed <= 100)
			starSpeed_cound = 1;
		else if (weaponSpeed > 100 && weaponSpeed <= 150)
			starSpeed_cound = 2;
		else if (weaponSpeed > 150 && weaponSpeed <= 200)
			starSpeed_cound = 3;
		else if (weaponSpeed > 200 && weaponSpeed <= 250)
			starSpeed_cound = 4;
		else if (weaponSpeed > 250 && weaponSpeed <= 300)
			starSpeed_cound = 5;
		else if (weaponSpeed > 300 && weaponSpeed <= 350)
			starSpeed_cound = 6;
		else if (weaponSpeed > 350 && weaponSpeed <= 400)
			starSpeed_cound = 7;
		else
			starSpeed_cound = 8;
											
		//ui_render->DrawTextureWindow(Core::Vector2(ui_x+157, ui_y+274), 65, 18, ui_common_speed);

		ui_render->SetTexture(ui_die_bg);
		ui_render->DrawWindow(Core::Rectangle(ui_x+225,ui_y+274,ui_x+225+114,ui_y+274+16),Core::Rectangle(6,6,6,6),Core::Rectangle(6.0f / 16.f, 6.0f / 16.f, 6.0f / 16.f, 6.0f / 16.f));

		if (weaponSpeed != 0)
		{
			ui_render->SetTexture(ui_common_skin_bar[starSpeed_cound]);
			ui_render->DrawWindow(Core::Rectangle(ui_x+226,ui_y+276,ui_x+226+(weaponSpeed-starSpeed_cound*50)*2.28,ui_y+276+12),Core::Rectangle(6,6,6,6),Core::Rectangle(6.0f / 32.f, 6.0f / 12.f, 6.0f / 32.f, 6.0f / 12.f));
		}
		
		if (starSpeed_cound > 0)
		{
			for (int i = 0;i < starSpeed_cound;i++)
			{
				ui_render->DrawTextureWindow(Core::Vector2((ui_x+225), ui_y+293), 16, 16, ui_common_little_star);
				buff.format("X %d",starSpeed_cound);
				ui_render->DrawFontWindow(Core::Vector2((ui_x+225+26), ui_y+293), 109, 20, ui_render->font_simhei_14, Core::ARGB(178,255, 255, 255), ARGB(0, 0, 0, 0), buff, Unit::kAlignLeftTop);
			}
		}						
	}
}

void InGameUINew::_DrawAddBloodEffect(by_ptr(UIRender) ui_render)
{
	if(!ui_render)
		return;

	ui_render->BeginInGameUI();

	Core::Vector3 rt_size = gGame->guiSys->GetSize();
	Matrix44 world;
	ARGB font_color;
	for(int i = 0; i < array_addbloodeffect_info.GetCount(); ++i)
	{
		Core::CStrBuf<256> buff;
		switch(array_addbloodeffect_info[i].type)
		{
		case ChannelConnection::kRecoverFire:
			{
				font_color = ARGB(255,0,0);
				world.SetTranslationXYZ(25, rt_size.y, 0);
				ui_render->SetWorld(world);
				if(array_addbloodeffect_info[i].data < 10)
					buff.format("-    %d", array_addbloodeffect_info[i].data);
				else if(array_addbloodeffect_info[i].data < 100)
					buff.format("-  %d", array_addbloodeffect_info[i].data);
				else
					buff.format("-%d", array_addbloodeffect_info[i].data);
			}
			break;
		case ChannelConnection::kRecoverCuregun:
			{
				font_color = ARGB(0,255,0);
				world.SetTranslationXYZ(68, rt_size.y-25, 0);
				ui_render->SetWorld(world);
				buff.format("+");
			}
			break;
		case ChannelConnection::kRecoverSupplyHp:
			{
				font_color = ARGB(0,255,0);
				world.SetTranslationXYZ(25, rt_size.y, 0);
				ui_render->SetWorld(world);
				if(array_addbloodeffect_info[i].data < 10)
					buff.format("+    %d", array_addbloodeffect_info[i].data);
				else if(array_addbloodeffect_info[i].data < 100)
					buff.format("+  %d", array_addbloodeffect_info[i].data);
				else
					buff.format("+%d", array_addbloodeffect_info[i].data);
			}
			break;
		case ChannelConnection::kSupplyAmmo_1:
			{
				font_color = ARGB(0,255,0);
				world.SetTranslationXYZ(rt_size.x, rt_size.y, 0);
				ui_render->SetWorld(world);
				if(array_addbloodeffect_info[i].data == 100)
					buff.format("+ %d %%", array_addbloodeffect_info[i].data);
				else if(array_addbloodeffect_info[i].data < 100 && array_addbloodeffect_info[i].data >= 10)
					buff.format("  + %d %%", array_addbloodeffect_info[i].data);
				else
					buff.format("    + %d %%", array_addbloodeffect_info[i].data);
			}
			break;
		case ChannelConnection::kSupplyAmmo_2:
			{
				font_color = ARGB(0,255,0);
				world.SetTranslationXYZ(rt_size.x, rt_size.y, 0);
				ui_render->SetWorld(world);
				if(array_addbloodeffect_info[i].data < 10)
					buff.format("+    %d", array_addbloodeffect_info[i].data);
				else if(array_addbloodeffect_info[i].data < 100)
					buff.format("+  %d", array_addbloodeffect_info[i].data);
				else
					buff.format("+%d", array_addbloodeffect_info[i].data);
			}
			break;
		}
		ui_render->DrawStringShadow(ui_render->font_SHOWG_36, font_color, Core::ARGB(255,0,0,0), Core::ARGB(0,0,0,0), Core::Rectangle(array_addbloodeffect_info[i].position.x, array_addbloodeffect_info[i].position.y, array_addbloodeffect_info[i].position.x+50, array_addbloodeffect_info[i].position.y+50), buff, Unit::kAlignLeftBottom);
	}
}

void InGameUINew::DrawSmallMap(by_ptr(UIRender) ui_render)
{
	Core::Rectangle &rs = (Core::Rectangle &)ui_render->GetScissorRect();
	Core::Rectangle temp_rs = rs;

	rs.Min.x = 0.0f,rs.Max.x = F32_MAX;
	rs.Min.y = 0.0f,rs.Max.y = -F32_MAX;

	Character * player = gLevel->GetPlayer();
	Character * viewer = gLevel->GetViewer();

	if(viewer)
		player = viewer;

	if(!player)
		return;

	if (ui_render->BeginDraw(small_map->GetSurface()))
	{
		ARGB name_colors[] = { ARGB(255, 101, 74), ARGB(128, 215, 255) };
		Matrix44 view;
		Matrix44 world;
		Vector3 rt_size = ui_render->GetRenderTargetSize();

		gDx9Device->Clear(0, NULL, D3DCLEAR_TARGET, 0, 1.f, 0);

		Vector2 draw_size(230, 199);
		Vector2 map_size = gLevel->map_size;
		Vector2 map_center = gLevel->map_center;
		Vector2 map_scale = draw_size * 2 / map_size;
		float scale = Min(map_scale.y, map_scale.x) / 2;

		Character * p = player;

		Vector2 player_pos = (map_center - Vector2(p->GetPosition().x, p->GetPosition().z)) * Vector2(scale, scale);

		world.SetTranslationXYZ(-player_pos.x, -player_pos.y, 0);

		Matrix44 map_rot;
		map_rot = Matrix44::kIdentity;
		//��ͼ��ת
		//map_rot.SetRotationQuaternion(Quaternion(Vector3(1, 0, 0), HALFPI) * p->GetRotation().Conjugate() * Quaternion(Vector3(-1, 0, 0), HALFPI) * Quaternion(Vector3(0, 0, 1), PI));
		if (player->GetTeam() == 1)
		{
			map_rot.SetRotationQuaternion(Quaternion(Vector3(0, 0, -1),PI));
		}
		ui_render->SetWorld(world * map_rot);


		view.SetScaleXYZ(2.0f / rt_size.x, -2.0f / rt_size.y, 0);
		view.TranslateLocalXYZ(-0.5f, -0.5f, 0);
		ui_render->SetView(view);
		ui_render->SetProjection(Matrix44::kIdentity);

		if (gLevel->map_texture)
		{
			ui_render->SetTexture(gLevel->map_texture);
			Core::Rectangle rect;


			if (Abs(map_scale.y) > Abs(map_scale.x))
			{
				rect.Max.x = draw_size.x;
				rect.Max.y = draw_size.x / map_size.x * map_size.y;
			}
			else
			{
				rect.Max.y = draw_size.y;
				rect.Max.x = draw_size.y / map_size.y * map_size.x;
			}

			rect.Min = -rect.Max;

			ui_render->DrawRectangle(rect, Core::Rectangle(0, 0, 1, 1));

			for (U32 i = 0; i < gLevel->bomb_plant_position_array.Size(); i++)
			{
				tempc_ptr(BombPositionData) data = gLevel->bomb_plant_position_array[i];

				Vector3 pos = (const Vector3&)data->mesh->GetPosition();
				Vector2 cpos;

				cpos.x = pos.x;
				cpos.y = pos.z;
	
				cpos = (map_center - cpos) * Vector2(scale,scale);

				Vector2 line_pos = cpos - player_pos;
				if (line_pos.x > 105 || line_pos.x < -105 || line_pos.y > 89.5 || line_pos.y < -89.5)
				{
					cpos = _GetNewPostion(line_pos,player_pos);
				}				

				Matrix44 rot,trans;

				trans.SetTranslationXYZ(cpos.x, cpos.y, 0);
				//ui_render->SetWorld(trans * world * map_rot);
				//if(gLevel->game_type == RoomOption::kBombMode)
				//{
					if (player->GetTeam()==1)
					{
						//rot.SetRotationQuaternion(Quaternion(Vector3(1, 0, 0), HALFPI) * PI * Quaternion(Vector3(-1, 0, 0), HALFPI) * Quaternion(Vector3(0, 0, 1), PI));
						ui_render->SetWorld(trans * world * map_rot);
						switch (i)
						{
						case 0:
							ui_render->SetTexture(ui_smallmap_bomb_arrayA);
							ui_render->DrawRectangle(Core::Rectangle(-10, -10, 10, 10), Core::Rectangle(1, 1, 0, 0));
							break;
						case 1:
							ui_render->SetTexture(ui_smallmap_bomb_arrayB);
							ui_render->DrawRectangle(Core::Rectangle(-10, -10, 10, 10), Core::Rectangle(1, 1, 0, 0));
							break;
						default:
							break;
						}
					}
					else
					{
						ui_render->SetWorld(trans * world * map_rot);
						switch (i)
						{
						case 0:
							ui_render->SetTexture(ui_smallmap_bomb_arrayA);
							ui_render->DrawRectangle(Core::Rectangle(-10, -10, 10, 10), Core::Rectangle(0, 0, 1, 1));
							break;
						case 1:
							ui_render->SetTexture(ui_smallmap_bomb_arrayB);
							ui_render->DrawRectangle(Core::Rectangle(-10, -10, 10, 10), Core::Rectangle(0, 0, 1, 1));
							break;
						default:
							break;
						}
					}
				//}
				
			}
			
			//draw plantbomb and losebomb
			if (gLevel->bomb_on_ground && player->GetTeam() == 1)
			{
				Vector3 pos = (const Vector3&)gLevel->bomb_on_ground_position;
				Vector2 cpos;

				cpos.x = pos.x;
				cpos.y = pos.z;

				cpos = (map_center - cpos) * Vector2(scale,scale);

				Matrix44 trans;

				trans.SetTranslationXYZ(cpos.x, cpos.y, 0);

				ui_render->SetWorld(trans * world * map_rot);
				ui_render->SetTexture(ui_textures[8]);
				ui_render->DrawRectangle(Core::Rectangle(-10, -10, 10, 10), Core::Rectangle(0, 0, 1, 1));
			}

			if(gLevel->bomb_droped == true)
			{
				Vector3 pos;
				gLevel->pickup_manager->GetPickUpPosition(gLevel->bomb_droped_id,PickUpManager::kPickUpWeapon, pos);
				Vector2 cpos;

				cpos.x = pos.x;
				cpos.y = pos.z;

				cpos = (map_center - cpos) * Vector2(scale,scale);

				Matrix44 trans;

				trans.SetTranslationXYZ(cpos.x, cpos.y, 0);

				ui_render->SetWorld(trans * world * map_rot);
				ui_render->SetTexture(ui_textures[8]);
				ui_render->DrawRectangle(Core::Rectangle(-10, -10, 10, 10), Core::Rectangle(0, 0, 1, 1));

			}
			// draw supply box
			for(uint i = 0 ; i < gLevel->pickup_manager->pick_up_set.Size(); i ++)
			{
				sharedc_ptr(PickUpManager::PickUpObject) Object = gLevel->pickup_manager->pick_up_set[i];
				if(!Object || Object->type != PickUpManager::kPickUpSupply)
					continue;

				if(!Object->collider)
					continue;

				Vector3 pos = (const Vector3&)Object->collider->getGlobalPosition();
				Vector2 cpos;
				Core::Rectangle temp;
				cpos.x = pos.x;
				cpos.y = pos.z;
				cpos = (map_center - cpos) * Vector2(scale,scale);

				if (player->GetTeam() == 1 || gLevel->game_type == RoomOption::kNovice)
				{
					temp = Core::Rectangle(1, 1, 0, 0);
				}
				else
				{
					temp = Core::Rectangle(0, 0, 1, 1);
				}

				Matrix44 trans;

				trans.SetTranslationXYZ(cpos.x, cpos.y, 0);

				ui_render->SetWorld(trans * world * map_rot);

				switch(Object->SType)
				{
				case PickUpManager::kSupplyHp:
				case PickUpManager::kSupplySurvivalItemHp:
					{
						ui_render->SetTexture(ui_smallmap_supply_hp);
						ui_render->DrawRectangle(Core::Rectangle(-10, -10, 10, 10), temp);
					}
					break;
				case PickUpManager::kSupplyAmmo:
				case PickUpManager::kSupplySurvivalItemAmmo:
					{
						ui_render->SetTexture(ui_smallmap_supply_bullet);
						ui_render->DrawRectangle(Core::Rectangle(-10, -10, 10, 10), temp);
					}
					break;
				case PickUpManager::kSupplyMedkit:
					{
						ui_render->SetTexture(ui_smallmap_supply_medkit);
						ui_render->DrawRectangle(Core::Rectangle(-10, -10, 10, 10), temp);
					}
					break;
				case PickUpManager::kSupplyAllTools:
					{
						ui_render->SetTexture(ui_smallmap_supply_tools);
						ui_render->DrawRectangle(Core::Rectangle(-10, -10, 10, 10), temp);
					}
					break;
				case PickUpManager::kSupplyCommonZombie:
				case PickUpManager::kSupplySurvivalItemRandom:
					{
						ui_render->SetTexture(ui_smallmap_supply_commonzombie);
						ui_render->DrawRectangle(Core::Rectangle(-10, -10, 10, 10), temp);
					}	
					break;
				case PickUpManager::kSupplyCommonZombie2:
					{
						ui_render->SetTexture(ui_smallmap_supply_item_special);
						ui_render->DrawRectangle(Core::Rectangle(-10, -10, 10, 10), temp);
					}	
					break;
				case PickUpManager::kSupplySurvivalItemTrapAmmo:
				case PickUpManager::kSupplySurvivalItemTrapHP:
				case PickUpManager::kSupplySurvivalItemTrapExpose:
				case PickUpManager::kSupplySurvivalItemTrapBomb:
				case PickUpManager::kSupplySurvivalItemTrapDebuff:
					{
						ui_render->SetTexture(ui_smallmap_supply_item_snare);
						ui_render->DrawRectangle(Core::Rectangle(-10, -10, 10, 10), temp);
					}
					break;
				}
				if ( player->isghost && Object->SType == PickUpManager::kSupplySurvivalItemGhostFire )
				{
					ui_render->SetTexture(ui_smallmap_supply_item_ghost);
					ui_render->DrawRectangle(Core::Rectangle(-10, -10, 10, 10), temp);
				}
			}

			// draw characters
			{
				for (uint team = 0; team < 2; team ++)
				{
					if (player->GetTeam() != team)
					{
						for (uint rank = 0; rank < gGame->scores->teams[team].Size(); rank ++)
						{
							Character * c = gGame->scores->teams[team][rank];
							if (c->IsAttributeExist(kEffect_Survival_Expose))
							{
								Vector2 cpos;
								cpos.x = c->GetPosition().x;
								cpos.y = c->GetPosition().z;

								Vector2 pos = (map_center - cpos) * Vector2(scale, scale);

								Matrix44 rot, trans;
								Core::Rectangle uv;

								trans.SetTranslationXYZ(pos.x, pos.y, 0);
								rot.SetRotationQuaternion(Quaternion(Vector3(1, 0, 0), HALFPI) * c->GetRotation() * Quaternion(Vector3(-1, 0, 0), HALFPI) * Quaternion(Vector3(0, 0, 1), PI));
								ui_render->SetWorld(rot * trans * world * map_rot);
								ui_render->SetTexture(ui_textures[7]);	
								ui_render->DrawRectangle(Core::Rectangle(-12,-12,12,12), Core::Rectangle(0,0,1.0f,1.0f));
							}
						}
					}

					for (uint rank = 0; rank < gGame->scores->teams[team].Size(); rank ++)
					{
						Character * c = gGame->scores->teams[team][rank];

						if (c && c->playing && c->GetTeam() < 2)
						{
							ARGB color = name_colors[c->GetTeam() & 1];
							if (c == player)
								color = ARGB(0, 255, 0);

							Vector2 cpos;
							cpos.x = c->GetPosition().x;
							cpos.y = c->GetPosition().z;

							Vector2 pos = (map_center - cpos) * Vector2(scale, scale);

							Matrix44 rot, trans;
							Core::Rectangle uv;

							trans.SetTranslationXYZ(pos.x, pos.y, 0);
							if (c->IsDied())
							{
								rot.SetRotationQuaternion(Quaternion(Vector3(1, 0, 0), HALFPI) * p->GetRotation() * Quaternion(Vector3(-1, 0, 0), HALFPI) * Quaternion(Vector3(0, 0, 1), PI));

								ui_render->SetWorld(rot * trans * world * map_rot);
								ui_render->SetTexture(ui_textures[1]);
								ui_render->DrawRectangle(Core::Rectangle(-8, -8, 8, 8), Core::Rectangle(0.0f, 0, 1.0f, 1.0f), ARGB(255, 255, 255));
							}
							else
							{
								rot.SetRotationQuaternion(Quaternion(Vector3(1, 0, 0), HALFPI) * c->GetRotation() * Quaternion(Vector3(-1, 0, 0), HALFPI) * Quaternion(Vector3(0, 0, 1), PI));
								ui_render->SetWorld(rot * trans * world * map_rot);

								if(viewer)
								{	
									if(c->GetThirdPerson().billboard_timer)
									{
										ui_render->SetTexture(ui_textures[6]);	
										ui_render->DrawRectangle(Core::Rectangle(-10, -10, 10, 10), Core::Rectangle(0,0,1.0f,1.0f));
									}
									else if(viewer == c)
									{
										if (c->uid == gLevel->current_street_king_uid[c->GetTeam()])
										{
											ui_render->SetTexture(ui_textures[7]);	
											ui_render->DrawRectangle(Core::Rectangle(-12,-12,12,12), Core::Rectangle(0,0,1.0f,1.0f));
										}
										else if (c->HasBomb())
										{
											ui_render->SetTexture(ui_textures[8]);	
											ui_render->DrawRectangle(Core::Rectangle(-12,-12,12,12), Core::Rectangle(0,0,1.0f,1.0f));
										}
										else
										{
											/*if (player->shooting)
											{
												ui_render->SetTexture(ui_textures[2]);
												ui_render->DrawRectangle(Core::Rectangle(-12,-12,12,12), Core::Rectangle(0,0,1.0f,1.0f));					
											}
											else
											{*/
												ui_render->SetTexture(ui_textures[4]);	
												ui_render->DrawRectangle(Core::Rectangle(-64,-64,64,64), Core::Rectangle(0,0,1.0f,1.0f));
											//}								
										}
									}
									else if(viewer->GetTeam() == c->GetTeam())
									{
										if (c->uid == gLevel->current_street_king_uid[c->GetTeam()])
										{
											ui_render->SetTexture(ui_textures[7]);	
											ui_render->DrawRectangle(Core::Rectangle(-12,-12,12,12), Core::Rectangle(0,0,1.0f,1.0f));
										}
										else if (c->HasBomb())
										{
											ui_render->SetTexture(ui_textures[8]);	
											ui_render->DrawRectangle(Core::Rectangle(-12,-12,12,12), Core::Rectangle(0,0,1.0f,1.0f));
										}
										else
										{
											if (c->shooting)
											{
												c->shooting = false;
												c->show_shoot_time = 1;
												ui_render->SetTexture(ui_textures[2]);
											}
											else if (c->show_shoot_time > 0)
											{
												ui_render->SetTexture(ui_textures[2]);
											}
											else
											{
												ui_render->SetTexture(ui_textures[3]);						
											}	
											ui_render->DrawRectangle(Core::Rectangle(-10,-10,10,10), Core::Rectangle(0,0,1.0f,1.0f));		
										}
									}
								}
							}
						}
					}
				}
			}
		}

		ui_render->EndDraw();

		rs = temp_rs;
	}
}

Core::Vector2 InGameUINew::_GetNewPostion(Core::Vector2 pos,Core::Vector2 centerpos)
{
	Vector2 cpos;
	F32 F;
	if (pos.y < 0)
		F = Core::Acos(-pos.x/pos.Length()) + Core::PI;
	else
		F = Core::Acos(pos.x/pos.Length());
	F32 f = Core::Asin(89.5/Core::Vector2(105,89.5).Length());
	if (F <= f || F >= 2*Core::PI - f)
	{
		cpos.x = centerpos.x + 105;
		cpos.y = 105*Core::Tan(F) +  centerpos.y;
	} 
	else if (F > f && F <= Core::PI - f)
	{
		cpos.y = centerpos.y + 89.5;
		cpos.x = 89.5/Core::Tan(F) + centerpos.x;
	}
	else if (F > Core::PI - f && F <= Core::PI + f)
	{
		cpos.x = centerpos.x - 105;
		cpos.y = -105*Core::Tan(F) +  centerpos.y;
	}
	else if (F > Core::PI + f && F < 2*Core::PI - f)
	{
		cpos.y = centerpos.y - 89.5;
		cpos.x = -89.5/Core::Tan(F) + centerpos.x;
	}
	return cpos;
}

void InGameUINew::_DrawKillList(by_ptr(UIRender) ui_render)
{
	Game * game = gGame;
	tempc_ptr(Character) viewer = game->level->GetViewer();
	by_ptr(Character) player = gLevel->GetPlayer();
	Matrix44 world, view;
	Core::Vector3 rt_size = gGame->guiSys->GetSize();
	ARGB name_colors[] = { ARGB(255, 101, 74),ARGB(128, 215, 255) , ARGB(255,128,128,128) };

	if(gLevel->game_type == RoomOption::kStreetBoyMode)
	{
		tempc_ptr(Character) laoda_1 = gLevel->GetCharacter(gLevel->current_street_king_uid[0]);
		tempc_ptr(Character) laoda_2 = gLevel->GetCharacter(gLevel->current_street_king_uid[1]);
		if(!laoda_1 && !laoda_2)
		{
			return;
		}
	}
	// draw kill list
	if (game->scores)
	{
		float cursor_y = 0;

		view.SetScaleXYZ(2.0f/rt_size.x, -2.0f/rt_size.y, 0);
		world.SetTranslationXYZ(rt_size.x/2-8, -rt_size.y/2, 0);
		ui_render->SetView(view);
		ui_render->SetWorld(world);

		for (uint kill_id = 0; kill_id < game->scores->kill_list.Size(); kill_id++)
		{
			KillHistory & kill = game->scores->kill_list[kill_id];

			ARGB bg_color = ARGB(0, 0, 0, 0);
			ARGB bg_color2 = ARGB(151, 71, 78, 82);

			bool headshot = false;
			if (kill.weapon_info)
			{
				switch(kill.weapon_info->weapon_type)
				{
				case kWeaponTypeSniperGun:
				case kWeaponTypeRifle:
				case kWeaponTypeSubMachineGun:
				case kWeaponTypePistol:
				case kWeaponTypeDualPistol:
				case kWeaponTypeKnife:
				case kWeaponTypeShotGun:
					headshot = kill.part == 3;
					break;
				}
			}

			Core::Rectangle rect1(0, 0, 0, 0);

			float img_width = kill_headshot->GetWidth();

			float ratio = 0;

			if (!headshot)
				ratio = img_width;

			Core::String strnametemp = kill.name1;
			if (gGame->global)
				gGame->global->Translate(strnametemp);
			Core::Identifier strname  = strnametemp;
			
			if (kill.uid_assist > 0)
			{
				tempc_ptr(Character) assist = gLevel->GetCharacter(kill.uid_assist);
				if (assist)
				{
					Core::String strnamek1 = kill.name1;
					if (gGame->global)
						gGame->global->Translate(strnamek1);
					Core::String strnamek2 = assist->GetName().Str();
					if (gGame->global)
						gGame->global->Translate(strnamek2);
					strname = Core::String::Format("%s + %s", strnamek1, strnamek2);
				}
			}

			if (kill.weapon_info)
				rect1 = ui_render->font_simhei_14->MeasureString(Core::Rectangle(0, 0, 0, 0), strname, -1, 0);
			if (kill.name1 != kill.name2 && !kill.weapon_info)
				rect1 = ui_render->font_simhei_14->MeasureString(Core::Rectangle(0, 0, 0, 0), strname, -1, 0);				

			Core::String strnamek2 = kill.name2;
			if (gGame->global)
				gGame->global->Translate(strnamek2);
			Core::Rectangle rect2 = ui_render->font_simhei_14->MeasureString(Core::Rectangle(0, 0, 0, 0), strnamek2, -1, 0);

			ui_render->SetTexture(NullPtr);
			ui_render->BeginRectangleList(1);

			ui_render->Vertex(-4 - 6 - rect2.Max.x - 6 - img_width - 70 - 6 - rect1.Max.x - 6 + ratio, cursor_y, 0, 0, 0, bg_color2);
			ui_render->Vertex(-4,cursor_y + 32,0,0,0,bg_color2);
			ui_render->End();
			tempc_ptr(Character) laoda_1 = gLevel->GetCharacter(gLevel->current_street_king_uid[0]);
			tempc_ptr(Character) laoda_2 = gLevel->GetCharacter(gLevel->current_street_king_uid[1]);
			if (kill.uid_assist == -1)
			{
				ui_render->SetTexture(blast_icon);
			}
			else if (kill.sustainhurttype == kSustainFlameHurt)
			{
				ui_render->SetTexture(fire_icon);
			}
			else if(kill.weapon_info && kill.weapon_info->weapon_type == kWeaponTypeBomb)
			{
				ui_render->SetTexture(bomb_kill);
			}
			else if((laoda_1&&kill.name2.Str() == laoda_1->GetName().Str())||(laoda_2&&kill.name2.Str() == laoda_2->GetName().Str()))
			{
				ui_render->SetTexture(king_kill);
			}
			else

				ui_render->SetTexture(kill.weapon_info ? kill.weapon_info->kill_icon : kill_died);

			ui_render->BeginRectangleList(1);
			ui_render->Vertex(-4 - 6 - rect2.Max.x - 6 - img_width - 70 + ratio,cursor_y, 0, 0, 0, ARGB(255, 255, 255));

			if(headshot)
				ui_render->Vertex(-4 - 6 - rect2.Max.x - 6 - img_width, cursor_y + 32, 0, 1, 1,ARGB(255, 255, 255));
			else
				ui_render->Vertex(-4 - 6 - rect2.Max.x - 6, cursor_y + 32, 0, 1, 1,ARGB(255, 255, 255));

			ui_render->End();

			if (headshot)
			{
				ui_render->SetTexture(kill_headshot);
				ui_render->BeginRectangleList(1);
				ui_render->Vertex(-4 - 6 - rect2.Max.x - 6 - img_width,cursor_y,0,0,0,ARGB(255,255,255));
				ui_render->Vertex(-4 - 6 - rect2.Max.x - 6,cursor_y + 32,0,1,1,ARGB(255,255,255));
				ui_render->End();
			}

			if (kill.weapon_info || strname != kill.name2 && !kill.weapon_info)
				ui_render->DrawString(ui_render->font_simhei_14, name_colors[kill.team1], bg_color, Core::Rectangle(-4 - 6 - rect2.Max.x - 6 - img_width - 70 - 6 - rect1.Max.x + ratio, cursor_y, -4 - 6 - rect2.Max.x - 6 - img_width - 70 - 6 + ratio, cursor_y + 32), strname, Unit::kAlignCenterMiddle);

			Core::String strname2 = kill.name2;
			gGame->global->Translate(strname2);
			ui_render->DrawString(ui_render->font_simhei_14, name_colors[kill.team2], bg_color, Core::Rectangle(-4 - 6  - rect2.Max.x, cursor_y, -4 - 6, cursor_y+32), strname2, Unit::kAlignCenterMiddle);

			cursor_y += 36;
		}
	}
}

void InGameUINew::_DrawControlTip(by_ptr(UIRender) ui_render)
{
	Matrix44 oldworld, world;
	oldworld = ui_render->GetWorld();
	Core::Vector3 rt_size = gGame->guiSys->GetSize();
	tempc_ptr(Character) player = gLevel->GetPlayer();
	tempc_ptr(Character) viewer = gLevel->GetViewer();

	if (player && player == viewer && player->control_person_id > 0)
	{
		tempc_ptr(Character) c = gLevel->GetCharacter(player->control_person_id);
		if (c)
		{
			world.SetTranslationXYZ((rt_size.x/2),-(rt_size.y/2),0);
			ui_render->SetWorld(world);
			ui_render->SetTexture(all_tipBg[player->GetTeam()]);
			int x = -260, y = 230;
			ui_render->DrawWindow(Core::Rectangle(x,y,x+225,y+55),Core::Rectangle(12,12,13,15),Core::Rectangle(12.0f / 51.f, 12.0f / 51.f, 13.0f / 51.f, 15.0f / 51.f));
			ui_render->DrawTextureWindow(Core::Vector2(x+10+132, y-20), 73, 74, ui_control_tip);
			Core::CStrBuf<256> buff;
			buff.format(gLang->GetTextW(L"����ͽ�Ŀ�꣺"));
			ui_render->DrawFontWindow(Core::Vector2(x+11, y+5), 109, 20, ui_render->font_simhei_14, Core::ARGB(255, 239, 204), ARGB(0, 0, 0, 0), buff, Unit::kAlignLeftMiddle);

			buff.format("%s",c->GetName().Str());
			ui_render->DrawFontWindow(Core::Vector2(x+11, y+25), 144, 20, ui_render->font_simhei_14, Core::ARGB(255, 239, 204), ARGB(0, 0, 0, 0), buff, Unit::kAlignLeftMiddle);
		}
	}
}

void  InGameUINew::_ResertWeaponLevelRGB(int weaponLevel , bool isWeapon , int& r , int& g , int& b)
{
	if(isWeapon)
	{
		if(weaponLevel == 0)
		{
			r = 238;
			g = 238;
			b = 238;
		}
		else if(weaponLevel < 4)
		{
			r = 254;
			g = 199;
			b = 127;
		}
		else if(weaponLevel < 7)
		{
			r = 255;
			g = 170;
			b = 98;
		}
		else if(weaponLevel < 10)
		{
			r = 255;
			g = 127;
			b = 55;
		}
		else if(weaponLevel < 12)
		{
			r = 255;
			g = 106;
			b = 34;
		}
		else if(weaponLevel < 14)
		{
			r = 255;
			g = 88;
			b = 16;
		}
		else if(weaponLevel < 15)
		{
			r = 253;
			g = 77;
			b = 4;
		}
		else if(weaponLevel < 19)
		{
			r = 255;
			g = 67;
			b = 2;
		}
	}
	else
	{
		if(weaponLevel == 0)
		{
			r = 238;
			g = 238;
			b = 238;
		}
		else if(weaponLevel < 4)
		{
			r = 164;
			g = 255;
			b = 236;
		}
		else if(weaponLevel < 7)
		{
			r = 137;
			g = 255;
			b = 209;
		}
		else if(weaponLevel < 10)
		{
			r = 100;
			g = 255;
			b = 170;
		}
		else if(weaponLevel < 12)
		{
			r = 59;
			g = 255;
			b = 129;
		}
		else if(weaponLevel < 14)
		{
			r = 45;
			g = 246;
			b = 99;
		}
		else if(weaponLevel < 15)
		{
			r = 14;
			g = 255;
			b = 83;
		}
		else if(weaponLevel < 19)
		{
			r = 21;
			g = 243;
			b = 71;
		}
	}
}

void InGameUINew::_DrawWeaponLevel(by_ptr(UIRender) ui_render ,int x , int y , int i , int weaponLevel ,sharedc_ptr(Texture2D) color)
{
	ui_render->DrawTextureWindow(Core::Vector2(x+75, y-20+20*i), 107, 18, WeaponBlank,Core::Rectangle(0, 0, 107/107.0f, 1));
	if(weaponLevel > 0)
	{
		ui_render->DrawTextureWindow(Core::Vector2(x+75, y-20+20*i), weaponLevel*6, 18, color ,Core::Rectangle(0, 0, weaponLevel*6/107.0f, 1));
	}
}

int InGameUINew::_WeaponLevel(int level)
{
	if(level < 0 || level >= 50)
	{
		return 0;
	}
	else
	{
		return level;
	}
}

void InGameUINew::_DrawWeaponTip(by_ptr(UIRender) ui_render, tempc_ptr(Character) c)
{
	if (RoomOption::kEditMode == gLevel->game_type)
		return;
	tempc_ptr(Character) viewer = c;

	if (!viewer || !viewer->character_info)
		return;

	int x = -6, y = 230;

	int arms[3] = {0,0,0};
	int deco[3] = {0,0,0};
	int decostar[3] = {0,0,0};
	int red = 0;
	int green = 0;
	int blue = 0;
	tempc_ptr(WeaponBase) weapon;
	if(gLevel->game_type == RoomOption::kStreetBoyMode)
	{
		if(viewer->uid == gLevel->current_street_king_uid[0] || viewer->uid == gLevel->current_street_king_uid[1])
		{
			tempc_ptr(WeaponBase) weapon = viewer->GetWeaponById(0);
			if (weapon)
			{
				arms[0] = _WeaponLevel(weapon->weapon_info->level);
			}
			weapon = viewer->GetWeaponById(2);
			if (weapon)
			{
				arms[1] = _WeaponLevel(weapon->weapon_info->level);
			}

			for(int i = 0 ; i < 2 ; i++)
			{
				ui_render->DrawTextureWindow(Core::Vector2(x+9, y-20+20*i), 48, 20, WeaponKind[2*i]);
				_DrawWeaponLevel(ui_render,x-15,y,i,arms[i],WeaponRed);
				Core::CStrBuf<256> buff;
				buff.format("LV%d",arms[i]);
				_ResertWeaponLevelRGB(arms[i],true,red,green,blue);
				ui_render->DrawFontWindow(Core::Vector2(x+55+6*14+14+14+5,y-20+20*i), 109, 20, ui_render->font_simhei_14, Core::ARGB(178,red, green, blue), ARGB(0, 0, 0, 0), buff, Unit::kAlignLeftTop);
			}

			for (U32 i = 0; i < viewer->character_info->costume_set.Size(); i++)
			{
				const Costume &costume = viewer->character_info->costume_set[i];
				deco[i] = _WeaponLevel(costume.level);
			}
			int temp = deco[0];
			deco[0] = deco[1];
			deco[1] = temp;
			for(int i = 0 ; i < 3 ; i++)
			{
				ui_render->DrawTextureWindow(Core::Vector2(x+9, y-20+20*(i+2)), 48, 20, WeaponKind[i+3]);
				_DrawWeaponLevel(ui_render,x-15,y,i+2,deco[i],WeaponBlue);
				Core::CStrBuf<256> buff;
				buff.format("LV%d",deco[i]);
				_ResertWeaponLevelRGB(deco[i],false,red,green,blue);
				ui_render->DrawFontWindow(Core::Vector2(x+55+6*14+14+14+5,y-20+20*(i+2)), 109, 20, ui_render->font_simhei_14, Core::ARGB(178,red, green, blue), ARGB(0, 0, 0, 0), buff, Unit::kAlignLeftTop);
			}
		}
		else
		{
			weapon = viewer->GetWeaponById(0);
			if (weapon)
			{
				arms[0] = _WeaponLevel(weapon->weapon_info->level);
			}

			ui_render->DrawTextureWindow(Core::Vector2(x+9, y-20-20), 48, 20, WeaponKind[2]);
			_DrawWeaponLevel(ui_render,x-15,y,0,arms[0],WeaponRed);
			Core::CStrBuf<256> buff;
			buff.format("LV%d",arms[0]);
			_ResertWeaponLevelRGB(arms[0],true,red,green,blue);
			ui_render->DrawFontWindow(Core::Vector2(x+55+6*14+14+14+5,y-20-20), 109, 20, ui_render->font_simhei_14, Core::ARGB(178,red, green, blue), ARGB(0, 0, 0, 0), buff, Unit::kAlignLeftTop);

			for (U32 i = 0; i < viewer->character_info->costume_set.Size(); i++)
			{
				const Costume &costume = viewer->character_info->costume_set[i];
				deco[i] = _WeaponLevel(costume.level);
			}
			int temp = deco[0];
			deco[0] = deco[1];
			deco[1] = temp;
			for(int i = 0 ; i < 3 ; i++)
			{
				ui_render->DrawTextureWindow(Core::Vector2(x+9, y-20+20*(i+1)), 48, 20, WeaponKind[i+3]);
				_DrawWeaponLevel(ui_render,x-15,y,i+1,deco[i],WeaponBlue);
				Core::CStrBuf<256> buff;
				buff.format("LV%d",deco[i]);
				_ResertWeaponLevelRGB(deco[i],false,red,green,blue);
				ui_render->DrawFontWindow(Core::Vector2(x+55+6*14+14+14+5,y-20+20*(i+1)), 109, 20, ui_render->font_simhei_14, Core::ARGB(178,red, green, blue), ARGB(0, 0, 0, 0), buff, Unit::kAlignLeftTop);
			}
		}
	}
	//else if(gLevel->room_option.is_knife == 1 && viewer)
	else if(gLevel->game_type == RoomOption::kKnifeMode && viewer)
	{
		weapon = viewer->GetWeaponById(0);
		if (weapon)
		{
			arms[0] = _WeaponLevel(weapon->weapon_info->level);
		}

		ui_render->DrawTextureWindow(Core::Vector2(x+9, y-20), 48, 20, WeaponKind[2]);
		_DrawWeaponLevel(ui_render,x-15,y,0,arms[0],WeaponRed);
		Core::CStrBuf<256> buff;
		buff.format("LV%d",arms[0]);
		_ResertWeaponLevelRGB(arms[0],true,red,green,blue);
		ui_render->DrawFontWindow(Core::Vector2(x+55+6*14+14+14+5,y-20), 109, 20, ui_render->font_simhei_14, Core::ARGB(178,red, green, blue), ARGB(0, 0, 0, 0), buff, Unit::kAlignLeftTop);

		for (U32 i = 0; i < viewer->character_info->costume_set.Size(); i++)
		{
			const Costume &costume = viewer->character_info->costume_set[i];
			deco[i] = _WeaponLevel(costume.level);
			decostar[i] = costume.star;
		}
		int temp = deco[0];
		deco[0] = deco[1];
		deco[1] = temp;

		temp = decostar[0];
		decostar[0] = decostar[1];
		decostar[1] = temp;
		for(int i = 0 ; i < 3 ; i++)
		{
			ui_render->DrawTextureWindow(Core::Vector2(x+9, y-20+20*(i+1)), 48, 20, WeaponKind[i+3]);
			_DrawWeaponLevel(ui_render,x-15,y,i+1,deco[i],WeaponBlue);
			Core::CStrBuf<256> buff;
			buff.format("LV%d",deco[i]);
			_ResertWeaponLevelRGB(deco[i],false,red,green,blue);
			ui_render->DrawFontWindow(Core::Vector2(x+55+6*14+14+14+5,y-20+20*(i+1)), 109, 20, ui_render->font_simhei_14, Core::ARGB(178,red, green, blue), ARGB(0, 0, 0, 0), buff, Unit::kAlignLeftTop);
			if(decostar[i] > 0)
			{
				ui_render->DrawTextureWindow(Core::Vector2(x+55+40+6*14+14+14+5,y-20+20*(i+1)), 18, 17, ui_star);
				buff.format("X %d",decostar[i]);
				ui_render->DrawFontWindow(Core::Vector2(x+55+65+6*14+14+14+5,y-20+20*(i+1)), 109, 20, ui_render->font_simhei_14, Core::ARGB(178,255, 67, 2), ARGB(0, 0, 0, 0), buff, Unit::kAlignLeftTop);
			}
		}
	}
	else if(gLevel->game_type == RoomOption::KMoonMode && viewer)
	{
		tempc_ptr(WeaponBase) weapon = viewer->GetWeaponById(1);
		if (weapon)
		{
			arms[0] = _WeaponLevel(weapon->weapon_info->level);
		}
		weapon = viewer->GetWeaponById(2);
		if (weapon)
		{
			arms[1] = _WeaponLevel(weapon->weapon_info->level);
		}

		for(int i = 0 ; i < 2 ; i++)
		{
			ui_render->DrawTextureWindow(Core::Vector2(x+9, y-20+20*i), 48, 20, WeaponKind[i+1]);
			_DrawWeaponLevel(ui_render,x-15,y,i,arms[i],WeaponRed);
			Core::CStrBuf<256> buff;
			buff.format("LV%d",arms[i]);
			_ResertWeaponLevelRGB(arms[i],true,red,green,blue);
			ui_render->DrawFontWindow(Core::Vector2(x+55+6*14+14+14+5,y-20+20*i), 109, 20, ui_render->font_simhei_14, Core::ARGB(178,red, green, blue), ARGB(0, 0, 0, 0), buff, Unit::kAlignLeftTop);
		}

		for (U32 i = 0; i < viewer->character_info->costume_set.Size(); i++)
		{
			const Costume &costume = viewer->character_info->costume_set[i];
			deco[i] = _WeaponLevel(costume.level);
		}
		int temp = deco[0];
		deco[0] = deco[1];
		deco[1] = temp;
		for(int i = 0 ; i < 3 ; i++)
		{
			ui_render->DrawTextureWindow(Core::Vector2(x+9, y-20+20*(i+2)), 48, 20, WeaponKind[i+3]);
			_DrawWeaponLevel(ui_render,x-15,y,i+2,deco[i],WeaponBlue);
			Core::CStrBuf<256> buff;
			buff.format("LV%d",deco[i]);
			_ResertWeaponLevelRGB(deco[i],false,red,green,blue);
			ui_render->DrawFontWindow(Core::Vector2(x+55+6*14+14+14+5,y-20+20*(i+2)), 109, 20, ui_render->font_simhei_14, Core::ARGB(178,red, green, blue), ARGB(0, 0, 0, 0), buff, Unit::kAlignLeftTop);
		}
	}
	else
	{
		for(int i = 0 ; i < 3 ; i++)
		{
			weapon = viewer->GetWeaponById(i);
			if (weapon)
			{
				arms[i] = _WeaponLevel(weapon->weapon_info->level);
			}
		}

		for (U32 i = 0; i < viewer->character_info->costume_set.Size(); i++)
		{
			const Costume &costume = viewer->character_info->costume_set[i];
			deco[i] = _WeaponLevel(costume.level);
			decostar[i] = costume.star;
		}
		int temp = deco[0];
		deco[0] = deco[1];
		deco[1] = temp;

		temp = decostar[0];
		decostar[0] = decostar[1];
		decostar[1] = temp;

		//ui_render->DrawTextureWindow(Core::Vector2(x+75,y), 107, 17, ui_weapon[viewer->GetWeaponById(0)->weapon_info->star - 1] , Core::Rectangle(1,0,0,1));
		for(int i = 0 ; i < 3 ; i++)
		{
			ui_render->DrawTextureWindow(Core::Vector2(x+9, y-20+20*i), 48, 20, WeaponKind[i]);
			_DrawWeaponLevel(ui_render,x-15,y-20+20,i,arms[i],WeaponRed);
			Core::CStrBuf<256> buff;
			buff.format("LV%d",arms[i]);
			_ResertWeaponLevelRGB(arms[i],true,red,green,blue);
			ui_render->DrawFontWindow(Core::Vector2(x+55+6*14+14+14+5,y-20+20*i), 109, 20, ui_render->font_simhei_14, Core::ARGB(178,red, green, blue), ARGB(0, 0, 0, 0), buff, Unit::kAlignLeftTop);
			if(viewer && viewer->GetWeaponById(i) && viewer->GetWeaponById(i)->weapon_info && viewer->GetWeaponById(i)->weapon_info->star && viewer->GetWeaponById(i)->weapon_info->star>0)
			{
				ui_render->DrawTextureWindow(Core::Vector2(x+55+40+6*14+14+14+14,y-20+20*i), 18, 17, ui_star);
				buff.format("X %d",viewer->GetWeaponById(i)->weapon_info->star);
				ui_render->DrawFontWindow(Core::Vector2(x+55+65+6*14+14+5,y-20+20*i), 109, 20, ui_render->font_simhei_14, Core::ARGB(178,255, 67, 2), ARGB(0, 0, 0, 0), buff, Unit::kAlignLeftTop);
			}
		}
		for(int i = 0 ; i < 3 ; i++)
		{
			ui_render->DrawTextureWindow(Core::Vector2(x+9, y-20+20*(i+3)), 48, 20, WeaponKind[i+3]);
			_DrawWeaponLevel(ui_render,x-15,y-20+20,i+3,deco[i],WeaponBlue);
			Core::CStrBuf<256> buff;
			buff.format("LV%d",deco[i]);
			_ResertWeaponLevelRGB(deco[i],false,red,green,blue);
			ui_render->DrawFontWindow(Core::Vector2(x+55+6*14+14+14+5,y-20+20*(i+3)), 109, 20, ui_render->font_simhei_14, Core::ARGB(178,red, green, blue), ARGB(0, 0, 0, 0), buff, Unit::kAlignLeftTop);
			
			if(decostar[i] > 0)
			{
				ui_render->DrawTextureWindow(Core::Vector2(x+55+40+6*14+14+14+5,y-20+20*(i+3)), 18, 17, ui_star);
				buff.format("X %d",decostar[i]);
				ui_render->DrawFontWindow(Core::Vector2(x+55+65+6*14+14+14+5,y-20+20*(i+3)), 109, 20, ui_render->font_simhei_14, Core::ARGB(178,255, 67, 2), ARGB(0, 0, 0, 0), buff, Unit::kAlignLeftTop);
			}
		}
	}
}

void InGameUINew::_DrawHorn(by_ptr(UIRender) ui_render)
{
	Matrix44 oldworld, world;
	Matrix44 oldview;
	oldview = ui_render->GetView();
	oldworld = ui_render->GetWorld();
	Core::Vector3 rt_size = gGame->guiSys->GetSize();
	if (gLevel->showhorn)
	{
		F32 scale = Core::Sin(showhornscale);
		//if(scale >=0.5f && scale <=0.7f)
		//{
		//	scale = 0.45f;
		//}
		//else
		//{
		//	scale = scale >= 0.3f ? 0.3f : scale;
		//	scale = scale <= 0.01f ? 0.01f : scale;
		//}
		scale = 0.4f;
		ARGB bg_color = ARGB(0, 0, 0, 0);

		world.SetTranslationXYZ(0, rt_size.y/2-130, 0);
		ui_render->SetWorld(world);
		//ui_render->SetTexture(ui_horn_bg);
		//ui_render->DrawWindow(Core::Rectangle(1,0,260,200),Core::Rectangle(5,5,5,6),Core::Rectangle(5.f/36.f,5.f/36.f,5.f/36.f,6.f/36.f));

		if(gLevel->horntime >= 3.0f)
		{
			world.SetTranslationXYZ(10-20*scale, rt_size.y/2-110-20*scale, 0);
			ui_render->SetWorld(world);
			ui_render->SetTexture(ui_horn);
			ui_render->BeginRectangleList(1);
			ui_render->Vertex(0, 0, 0, 0, 0, ARGB(255,255,255));
			ui_render->Vertex(30*(1.0f+scale), 30*(1.0f+scale), 0, 1, 1, ARGB(255,255,255));
			ui_render->End();
		}
		world.SetTranslationXYZ(10, rt_size.y/2-110, 0);
		ui_render->SetWorld(world);
		float aColor = 255.0f;
		for (int i = (int)gLevel->horn_array.Size() - 1; i >= 0; --i)
		{
			Core::String str;
			str = Core::String::Format("%s",gLevel->horn_array[i]);
			//aColor -= 255.0f * 0.2f; 
			int j = (int)gLevel->horn_array.Size() - 1 - i;
			if (j == 0)
			{
				SplitString(str,str,Core::Rectangle(36,0,280,40), ui_render->font_simhei_20);
				ui_render->DrawString(ui_render->font_simhei_20,ARGB(255, 234, 230, 95),bg_color,Core::Rectangle(36, -5, 280, 35),str.Str(),Unit::kAlignLeftTop);
			}
			else
			{
				SplitString(str,str,Core::Rectangle(36,0,280,40), ui_render->font_simhei_16);
				ui_render->DrawString(ui_render->font_simhei_16,ARGB(255, 192, 192, 192),bg_color,Core::Rectangle(36, 40+40*j, 280, 40+40*(j+1)),str.Str(),Unit::kAlignLeftTop);	
			}
		}
	}

	ui_render->SetWorld(oldworld);
	ui_render->SetView(oldview);
}

void InGameUINew::_DrawScoreAnimation(by_ptr(UIRender) ui_render)
{
	Matrix44 oldworld, world;
	Matrix44 oldview;
	oldview = ui_render->GetView();
	oldworld = ui_render->GetWorld();
	world = ui_render->GetWorld();
	Vector3 rt_size = ui_render->GetRenderTargetSize();
	Character * player = gLevel->GetPlayer();
	Character * viewer = gLevel->GetViewer();
	if (viewer && player && viewer == player)
	{
		if (player->kill_score_time < 1.f && player->kill_showscore > 0)
		{
			player->kill_score_time += Task::GetFrameTime();
			Matrix44 view1;
			view1.SetTranslationXYZ(-0.25f / rt_size.x, 0.25f / rt_size.y, 0);
			view1.ScaleLocalXYZ(rt_size.y / rt_size.x, -1, 0);
			ui_render->SetView(view1);

			float scale = 1;

			score_anim.scale_spline.Interpolation(viewer->kill_score_time, scale);

			world.ScaleXYZ(scale, scale, 1);
			score_anim.position.y = 0.3f;
			world.Translate(score_anim.position);
			world.TranslateXYZ(0, -0.5f, 0);

			ui_render->SetWorld(world);
			CStrBuf<256> str;
			str.format("+ %d",(int)player->kill_showscore);
			ui_render->DrawFontWindow(Vector2(-(60*scale)/2,-(60*scale)/2),60*scale,60*scale,ui_render->font_simhei_40,ARGB(255, 241, 211),ARGB(0, 0, 0, 0),str,Unit::kAlignCenterMiddle);
		}
	}

	ui_render->SetWorld(oldworld);
	ui_render->SetView(oldview);
}

void InGameUINew::_DrawKillIcon(by_ptr(UIRender) ui_render)
{
	Matrix44 oldworld, world;
	Matrix44 oldview;
	oldview = ui_render->GetView();
	oldworld = ui_render->GetWorld();
	world = ui_render->GetWorld();
	Vector3 rt_size = ui_render->GetRenderTargetSize();
	Character * player = gLevel->GetPlayer();
	Character * viewer = gLevel->GetViewer();

	// draw kill ui
	if (viewer && player && viewer == player && !player->IsDied())
	{
		if (viewer->kill_anim_time < 1.f && viewer->kills_kind.Size() > 0)
		{
			viewer->kill_anim_time += Task::GetFrameTime();
			int type = viewer->kills_kind[0];

			if((type != kGeneral && type != kContinuation && type != KKill_Zombie && type < kCure1 && type != kBossmode2_Boss_hit) || type == kKillBoss)
			{
				switch(type)
				{
				case kFight:
					{
						kill_anim_icon.texture = ui_kill_textures[5];
						if (viewer->isshowevent)
							FmodSystem::PlayEvent("bj/event/kill_slash");
					}
					break;
				case kHead:
					{
						kill_anim_icon.texture = ui_kill_textures[6];
						if (viewer->isshowevent)
							FmodSystem::PlayEvent("bj/event/kill_headshot");
					}
					break;
				case kBoost:
					{
						kill_anim_icon.texture = ui_kill_textures[8];
						if (viewer->isshowevent)
							FmodSystem::PlayEvent("bj/event/kill_burst");
					}
					break;
				case kSustain_Burn:
					{
						kill_anim_icon.texture = ui_kill_textures[10];
						if (viewer->isshowevent)
							FmodSystem::PlayEvent("bj/event/kill_burn");
					}
					break;
				case kSustain_Poison:
					{
						kill_anim_icon.texture = ui_kill_textures[23];
					}
					break;
				case kControl:
					{
						kill_anim_icon.texture = ui_kill_textures[9];
						if (viewer->isshowevent)
							FmodSystem::PlayEvent("bj/event/kill_bounty");
					}
					break;
				case kReveng:
					{
						kill_anim_icon.texture = ui_kill_textures[7];
						if (viewer->isshowevent)
							FmodSystem::PlayEvent("bj/event/kill_revenge");
					}
					break;
				case kPlant_success:
					{
						kill_anim_icon.texture = ui_kill_textures[16];
					}
					break;
				case kDefuse_success:
						kill_anim_icon.texture = ui_kill_textures[17];
					break;
				case KKill_King:
						kill_anim_icon.texture = ui_kill_textures[18];
					break;
				case KKill_Kill:
						kill_anim_icon.texture = ui_kill_textures[21];
					break;
				case KKill_Knockdown:
						kill_anim_icon.texture = ui_kill_textures[22];
					break;
				case KKill_SkillKill:
						kill_anim_icon.texture = ui_kill_textures[23];
					break;
				case KKill_SkillKnockdown:
						kill_anim_icon.texture = ui_kill_textures[24];
					break;
				case kKillBoss:
					{
						kill_anim_icon.texture = ui_kill_textures[25];
						if (viewer->isshowevent)
							FmodSystem::PlayEvent("bj/event/alienship_kill");
					}
					break;
				case kCommonZombie_King:
					kill_anim_icon.texture = ui_kill_textures[27];
					if (viewer->isshowevent)
						FmodSystem::PlayEvent("bj/event/bio2/zombie_kill");
					break;
				case kCommonZombie_LastKing:
					kill_anim_icon.texture = ui_kill_textures[28];
					if (viewer->isshowevent)
						FmodSystem::PlayEvent("bj/event/bio2/predator_kill");
					break;
				case kCommonZombie_normal:
					kill_anim_icon.texture = ui_kill_textures[26];
					if (viewer->isshowevent)
						FmodSystem::PlayEvent("bj/event/bio2/zombie_kill");
					break;
				case kCommonZombie_infect:
					kill_anim_icon.texture = ui_kill_textures[29];
					if (viewer->isshowevent)
						FmodSystem::PlayEvent("bj/event/bio2/infection");
					break;
				case kCommonZombie_infect_Last:
					kill_anim_icon.texture = ui_kill_textures[30];
					if (viewer->isshowevent)
						FmodSystem::PlayEvent("bj/event/bio2/final_infection");
					break;
				case kBossmode2_Boss:
					kill_anim_icon.texture = ui_kill_textures[31];
					if (viewer->isshowevent)
						FmodSystem::PlayEvent("bj/event/alienship_kill");
					break;
				case kCommonZombie_disappear:
					kill_anim_icon.texture = ui_kill_textures[33];
					//if (viewer->isshowevent)
					//	FmodSystem::PlayEvent("bj/event/alienship_kill");
					break;
				case kCommonZombie_drug:
					kill_anim_icon.texture = ui_kill_textures[34];
					break;
				case kCommonZombie_charge:
					kill_anim_icon.texture = ui_kill_textures[35];
					break;
				default:
					break;
				}

				if (viewer->isshowevent)
					viewer->isshowevent = false;

				Matrix44 view1;
				view1.SetTranslationXYZ(-0.25f / rt_size.x, 0.25f / rt_size.y, 0);
				view1.ScaleLocalXYZ(rt_size.y / rt_size.x, -1, 0);
				ui_render->SetView(view1);

				float scale = 1;
				float alpha = 1;
				kill_anim_icon.scale_spline.Interpolation(viewer->kill_anim_time, scale);
				kill_anim_icon.alpha_spline.Interpolation(viewer->kill_anim_time, alpha);

				world.ScaleXYZ(scale, scale, 1);
				world.Translate(kill_anim_icon.position);
				world.TranslateXYZ(0, -0.5f, 0);

				ui_render->SetWorld(world);

				ui_render->SetTexture(kill_anim_icon.texture);
				ui_render->DrawRectangle(Core::Rectangle(-0.27f, -0.27f, 0.27f, 0.27f), Core::Rectangle(0, 0, 1, 1), ARGB(alpha * 255, 255, 255, 255));
			}
			else if(type == kGeneral || type == kContinuation || type == KKill_Zombie || type == kBossmode2_Boss_hit)
			{
				switch(type)
				{
				case kGeneral:
					{
						Core::String str = Core::String::Format("bj/event/kill_%d",viewer->lian_kill_count);
						if (viewer->isshowevent)
						{
							Core::String str = Core::String::Format("bj/event/kill_%d",viewer->lian_kill_count);
							FmodSystem::PlayEvent(str.Str());
						}
						if (viewer->lian_kill_count >= 1 && viewer->lian_kill_count <= 5)
						{
							if (gLevel->game_type == RoomOption::kTDMode)
							{
								return;
							}
							kill_anim_icon.texture = ui_kill_textures[viewer->lian_kill_count-1];	
						}
						
					}
					break;
				case kContinuation:
					{
						if (viewer->isshowevent)
						{
							if (viewer->lian_kill_count <= 8)
							{
								Core::String str = Core::String::Format("bj/event/kill_%d",viewer->lian_kill_count);
								FmodSystem::PlayEvent(str.Str());
							}
							else
							{
								FmodSystem::PlayEvent("bj/event/kill_9");
							}
						}
						if (gLevel->game_type == RoomOption::kTDMode)
						{
							return;
						}
						kill_anim_icon.texture = ui_kill_textures[4];
					}
					break;
				case KKill_Zombie:
					{
						kill_anim_icon.texture = ui_kill_textures[20];
					}
					break;
				case kBossmode2_Boss_hit:
					kill_anim_icon.texture = ui_kill_textures[32];
					if (viewer->isshowevent)
						FmodSystem::PlayEvent("bj/event/kill_1000");
					break;
				}

				if (viewer->isshowevent)
					viewer->isshowevent = false;

				Matrix44 view1;
				view1.SetTranslationXYZ(-0.25f / rt_size.x, 0.25f / rt_size.y, 0);
				view1.ScaleLocalXYZ(rt_size.y / rt_size.x, -1, 0);
				ui_render->SetView(view1);

				float scale = 1;
				float alpha = 1;
				kill_anim_icon.scale_spline.Interpolation(viewer->kill_anim_time, scale);
				kill_anim_icon.alpha_spline.Interpolation(viewer->kill_anim_time, alpha);

				world.ScaleXYZ(scale, scale, 1);
				world.Translate(kill_anim_icon.position);
				world.TranslateXYZ(0, -0.5f, 0);

				ui_render->SetWorld(world);

				ui_render->SetTexture(kill_anim_icon.texture);
				ui_render->DrawRectangle(Core::Rectangle(-0.27f, -0.27f, 0.27f, 0.27f), Core::Rectangle(0, 0, 1, 1), ARGB(alpha * 255, 255, 255, 255));
				
				int all_count = 0;
				if (type == kBossmode2_Boss_hit)
				{
					all_count = m_boss_mode2_hit_total;
				} 
				else
				{
					all_count = viewer->lian_kill_count;
				}
				if (all_count < 10 && kill_anim_icon.texture)
				{
					float scale2 = 1;
					float alpha2 = 1;
					kill_anim_icon_num[0].scale_spline.Interpolation(viewer->kill_anim_time, scale2);
					kill_anim_icon_num[0].alpha_spline.Interpolation(viewer->kill_anim_time, alpha2);
					kill_anim_icon_num[0].texture = ui_kill_textures_num;
					ui_render->SetTexture(kill_anim_icon_num[0].texture);

					world = Matrix44::kIdentity;
					world.ScaleXYZ(scale2, scale2, 1);
					world.Translate(kill_anim_icon_num[0].position);
					world.TranslateXYZ(0, -0.37f, 0);
					ui_render->SetWorld(world);
					ui_render->DrawRectangle(Core::Rectangle(-0.06f, -0.06f, 0.06f, 0.06f), Core::Rectangle(all_count * 0.1f, 0, (all_count + 1) * 0.1, 1), ARGB(alpha2 * 255, 255, 255, 255));
				}
				else if (all_count < 100 && kill_anim_icon.texture)
				{
					float scale3 = 1;
					float alpha3 = 1;
					kill_anim_icon_num[0].scale_spline.Interpolation(viewer->kill_anim_time, scale3);
					kill_anim_icon_num[0].alpha_spline.Interpolation(viewer->kill_anim_time, alpha3);
					kill_anim_icon_num[0].texture = ui_kill_textures_num;
					ui_render->SetTexture(kill_anim_icon_num[0].texture);

					world = Matrix44::kIdentity;
					world.ScaleXYZ(scale3, scale3, 1);
					world.Translate(kill_anim_icon_num[0].position);
					world.TranslateXYZ(0, -0.37f, 0);
					ui_render->SetWorld(world);
					int temp = all_count / 10;
					ui_render->DrawRectangle(Core::Rectangle(-0.06f, -0.06f, 0.06f, 0.06f), Core::Rectangle(temp * 0.1f, 0, (temp + 1) * 0.1, 1), ARGB(alpha3 * 255, 255, 255, 255));

					float scale4 = 1;
					float alpha4 = 1;
					kill_anim_icon_num[1].scale_spline.Interpolation(viewer->kill_anim_time, scale4);
					kill_anim_icon_num[1].alpha_spline.Interpolation(viewer->kill_anim_time, alpha4);
					kill_anim_icon_num[1].texture = ui_kill_textures_num;
					world = Matrix44::kIdentity;
					world.ScaleXYZ(scale4, scale4, 1);
					world.Translate(kill_anim_icon_num[1].position);
					world.TranslateXYZ(0, -0.37f, 0);
					ui_render->SetWorld(world);
					temp = all_count % 10;
					ui_render->DrawRectangle(Core::Rectangle(-0.06f, -0.06f, 0.06f, 0.06f), Core::Rectangle(temp * 0.1f, 0, (temp + 1) * 0.1, 1), ARGB(alpha4 * 255, 255, 255, 255));
				}
			}
			else
			{
				switch(type)
				{
				case kCure1:
					{
						kill_anim_icon.texture = ui_kill_textures[11];	
					}
					break;
				case kCure2:
					{
						kill_anim_icon.texture = ui_kill_textures[12];	
					}
					break;
				case kCure3:
					{
						kill_anim_icon.texture = ui_kill_textures[13];	
					}
					break;
				case kCure4:
					{
						kill_anim_icon.texture = ui_kill_textures[14];	
					}
					break;
				case kCure5:
					{
						kill_anim_icon.texture = ui_kill_textures[15];	
					}
					break;
				}
				if (viewer->isshowevent)
					viewer->isshowevent = false;

				Matrix44 view1;
				view1.SetTranslationXYZ(-0.25f / rt_size.x, 0.25f / rt_size.y, 0);
				view1.ScaleLocalXYZ(rt_size.y / rt_size.x, -1, 0);
				ui_render->SetView(view1);

				float scale = 1;
				float alpha = 1;
				kill_anim_icon.scale_spline.Interpolation(viewer->kill_anim_time, scale);
				kill_anim_icon.alpha_spline.Interpolation(viewer->kill_anim_time, alpha);

				world.ScaleXYZ(scale, scale, 1);
				world.Translate(kill_anim_icon.position);
				world.TranslateXYZ(0, -0.5f, 0);

				ui_render->SetWorld(world);

				ui_render->SetTexture(kill_anim_icon.texture);
				ui_render->DrawRectangle(Core::Rectangle(-0.27f, -0.27f, 0.27f, 0.27f), Core::Rectangle(0, 0, 1, 1), ARGB(alpha * 255, 255, 255, 255));

				if (viewer->cure_all_value > 0 && viewer->cure_all_value / 1000 < 10 && kill_anim_icon.texture)
				{
					float scale2 = 1;
					float alpha2 = 1;
					kill_anim_icon_num[0].scale_spline.Interpolation(viewer->kill_anim_time, scale2);
					kill_anim_icon_num[0].alpha_spline.Interpolation(viewer->kill_anim_time, alpha2);
					kill_anim_icon_num[0].texture = ui_kill_textures_num;
					ui_render->SetTexture(kill_anim_icon_num[0].texture);

					world = Matrix44::kIdentity;
					world.ScaleXYZ(scale2, scale2, 1);
					world.Translate(kill_anim_icon_num[0].position);
					world.TranslateXYZ(-0.14f, -0.38f, 0);
					ui_render->SetWorld(world);
					ui_render->DrawRectangle(Core::Rectangle(-0.06f, -0.06f, 0.06f, 0.06f), Core::Rectangle(viewer->cure_all_value / 1000 * 0.1f, 0, (viewer->cure_all_value / 1000 + 1) * 0.1, 1), ARGB(alpha2 * 255, 255, 255, 255));
				}
				else if (viewer->cure_all_value > 0 && viewer->cure_all_value / 1000 < 100 && kill_anim_icon.texture)
				{
					float scale3 = 1;
					float alpha3 = 1;
					kill_anim_icon_num[0].scale_spline.Interpolation(viewer->kill_anim_time, scale3);
					kill_anim_icon_num[0].alpha_spline.Interpolation(viewer->kill_anim_time, alpha3);
					kill_anim_icon_num[0].texture = ui_kill_textures_num;
					ui_render->SetTexture(kill_anim_icon_num[0].texture);

					world = Matrix44::kIdentity;
					world.ScaleXYZ(scale3, scale3, 1);
					world.Translate(kill_anim_icon_num[0].position);
					world.TranslateXYZ(-0.14f, -0.38f, 0);
					ui_render->SetWorld(world);
					int temp = viewer->cure_all_value / 1000 / 10;
					ui_render->DrawRectangle(Core::Rectangle(-0.06f, -0.06f, 0.06f, 0.06f), Core::Rectangle(temp * 0.1f, 0, (temp + 1) * 0.1, 1), ARGB(alpha3 * 255, 255, 255, 255));

					float scale4 = 1;
					float alpha4 = 1;
					kill_anim_icon_num[1].scale_spline.Interpolation(viewer->kill_anim_time, scale4);
					kill_anim_icon_num[1].alpha_spline.Interpolation(viewer->kill_anim_time, alpha4);
					kill_anim_icon_num[1].texture = ui_kill_textures_num;
					world = Matrix44::kIdentity;
					world.ScaleXYZ(scale4, scale4, 1);
					world.Translate(kill_anim_icon_num[1].position);
					world.TranslateXYZ(-0.14f, -0.38f, 0);
					ui_render->SetWorld(world);
					temp = viewer->cure_all_value / 1000 % 10;
					ui_render->DrawRectangle(Core::Rectangle(-0.06f, -0.06f, 0.06f, 0.06f), Core::Rectangle(temp * 0.1f, 0, (temp + 1) * 0.1, 1), ARGB(alpha4 * 255, 255, 255, 255));
				}
			}
		}
		else
		{
			if(viewer->kills_kind.Size() > 0)
			{
				viewer->isshowevent = true;
				viewer->kills_kind.RemoveAt(0);
				viewer->kill_anim_time = 0.f;
			}
		}
	}
	else if (player)
	{
		player->isshowevent = false;
		player->kills_kind.Clear();
		player->kill_anim_time = 0.f;
	}

	ui_render->SetWorld(oldworld);
	ui_render->SetView(oldview);
}

void InGameUINew::_DrawNumberTextureWindow(by_ptr(UIRender) ui_render, by_ptr(Texture2D) uvTexture, Core::Vector2 vPos, int width, int height, int number, float uvWidth, Core::ARGB color)
{
	ui_render->DrawTextureWindow(vPos, width, height, uvTexture, Core::Rectangle(number * uvWidth, 0, (number + 1) * uvWidth, 1),color);
}

bool InGameUINew::Draw2DOjbect(by_ptr(UIRender) ui_render, by_ptr(Texture2D) texture_content, Core::Vector3 vPos)
{
	Core::Vector3 rt_size = gGame->guiSys->GetSize();
	Matrix44 world, tworld;
	int bmp_width = texture_content->GetWidth();
	int bmp_height = texture_content->GetHeight();
	Vector3 pos;

	pos = vPos;

	Matrix44 View,Proj,ViewProj;
	gGame->camera->CalculateViewProjectionMatrix(View, Proj);
	ViewProj = View * Proj;

	TransformCoord(pos, pos, ViewProj); 
	int x = rt_size.x / 2.0f + rt_size.x / 2.0f * pos.x;
	int y = rt_size.y / 2.0f - rt_size.y / 2.0f * pos.y;

	if(!gLevel->GetViewer())
		return false;

	if( pos.z > 1.0f || x < 0 || y < 0 || x > rt_size.x || y > rt_size.y )
		return false;

	world = Matrix44::kIdentity;
	world.SetTranslationXYZ(0,10,0);
	ui_render->SetWorld(world);

	const Core::Vector3 &player_pos = gLevel->GetViewer()->GetPosition();
	const Core::Vector3 &object_pos = (const Core::Vector3 &)vPos;

	F32 len = Length(gGame->camera->position - CalcNewPosition(gGame->camera->position, object_pos));

	F32 v = gDx9Device->convergence > 0 ? gDx9Device->convergence : 1;
	if (gDx9Device->GetStereoEnable() &&  len> 0)
		v = len;

	gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_CONVERGENCE, &v, 1);

	int length = (Vector3(player_pos.x, 0, player_pos.z) - Vector3(object_pos.x, 0, object_pos.z)).Length();
	y -= 50;

	ui_render->SetTexture(texture_content);
	ui_render->BeginRectangleList(1);
	ui_render->Vertex(x - bmp_width / 2 * 0.5f, y - bmp_height / 2 * 0.5f, 1, 0, 0, ARGB(255, 255, 255));
	ui_render->Vertex(x + bmp_width / 2 * 0.5f, y + bmp_height / 2 * 0.5f, 1, 1, 1, ARGB(255, 255, 255));
	ui_render->End();

	Matrix44 tWorld;
	world = Matrix44::kIdentity;
	tWorld = ui_render->GetWorld();

	world.SetTranslationXYZ(x,y - bmp_height / 2 * 0.5f+10.f,0);
	ui_render->SetWorld(world);

	CStrBuf<256> buff;
	buff.format("%dM",length);
	ui_render->DrawString(ui_render->font_simhei_12,ARGB(255,255,255),ARGB(1,1,1,1),Core::Rectangle(-100,45,100,45),buff,Unit::kAlignCenterBottom);

	ui_render->SetWorld(tWorld);

	if (gDx9Device->GetStereoEnable())
		v = gDx9Device->convergence > 0 ? gDx9Device->convergence : 1;

	gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_CONVERGENCE, &v, 1);

	return true;
}

bool InGameUINew::Draw2DCommonzombie_Ojbect(by_ptr(UIRender) ui_render, Core::Vector3 vPos,Core::Rectangle uv)
{
	Core::Vector3 rt_size = gGame->guiSys->GetSize();
	Matrix44 world, tworld;
	int bmp_width = 204;
	int bmp_height = 40;
	Vector3 pos;

	pos = vPos;

	Matrix44 View,Proj,ViewProj;
	gGame->camera->CalculateViewProjectionMatrix(View, Proj);
	ViewProj = View * Proj;

	TransformCoord(pos, pos, ViewProj); 
	int x = rt_size.x / 2.0f + rt_size.x / 2.0f * pos.x;
	int y = rt_size.y / 2.0f - rt_size.y / 2.0f * pos.y;

	if(!gLevel->GetViewer())
		return false;

	if( pos.z > 1.0f || x < 0 || y < 0 || x > rt_size.x || y > rt_size.y )
		return false;

	world = Matrix44::kIdentity;
	world.SetTranslationXYZ(0,10,0);
	ui_render->SetWorld(world);

	const Core::Vector3 &player_pos = gLevel->GetViewer()->GetPosition();
	const Core::Vector3 &object_pos = (const Core::Vector3 &)vPos;

	F32 len = Length(gGame->camera->position - CalcNewPosition(gGame->camera->position, object_pos));

	F32 v = gDx9Device->convergence > 0 ? gDx9Device->convergence : 1;
	if (gDx9Device->GetStereoEnable() &&  len> 0)
		v = len;

	gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_CONVERGENCE, &v, 1);

	int length = (Vector3(player_pos.x, 0, player_pos.z) - Vector3(object_pos.x, 0, object_pos.z)).Length();
	y += 5;

	//ui_render->SetTexture(ui_bomb_defuse_course);
	//ui_render->DrawWindow(Core::Rectangle(t_x,t_y,-t_x,t_y + 64),Core::Rectangle(26,0,26,0),Core::Rectangle(26.f/92.f,0.f/64.f,26.f/92.f,0.f/64.f));
	//ui_render->DrawTextureWindow(Core::Vector2(t_x + 13,t_y + 17),20.f + 235.f*bomb_time,28,ui_zombie_poeple_hp_bar,Core::Rectangle(0,0,(20.f + bomb_time*235.f)/255.f,1));
	//ui_render->DrawTextureWindow(Core::Vector2(t_x + 11 + bomb_time*224 - 6,t_y + 11 - 6),52,52,ui_zombie_poeple_bar_icon);

	ui_render->SetTexture(ui_commonzombie_dying_bg);
	ui_render->BeginRectangleList(1);
	ui_render->Vertex(x - bmp_width / 2 * 0.5f, y - bmp_height / 2 * 0.5f, 1, 0, 0, ARGB(255, 255, 255));
	ui_render->Vertex(x + bmp_width / 2 * 0.5f, y + bmp_height / 2 * 0.5f, 1, 1, 1, ARGB(255, 255, 255));
	ui_render->End();

	ui_render->SetTexture(ui_zombie_poeple_hp_bar);
	ui_render->BeginRectangleList(1);
	ui_render->Vertex(x - (bmp_width - 12) / 2 * 0.5f, y - (bmp_height - 16) / 2 * 0.5f, 1, 0, 0, ARGB(255, 255, 255));
	ui_render->Vertex(x + (-(bmp_width - 12) + 2*(bmp_width - 12)*uv.Max.x) / 2 * 0.5f, y + (bmp_height - 16) / 2 * 0.5f, 1, uv.Max.x, 1, ARGB(255, 255, 255));
	ui_render->End();

	ui_render->SetTexture(ui_zombie_poeple_bar_icon);
	ui_render->BeginRectangleList(1);
	ui_render->Vertex(x + (-(bmp_width - 10) + 2*(bmp_width - 10)*uv.Max.x - 46) / 2 * 0.5f, y - (bmp_height + 6) / 2 * 0.5f, 1, 0, 0, ARGB(255, 255, 255));
	ui_render->Vertex(x + (-(bmp_width - 10) + 2*(bmp_width - 10)*uv.Max.x + 46) / 2 * 0.5f, y + (bmp_height + 6) / 2 * 0.5f, 1, 1, 1, ARGB(255, 255, 255));

	//ui_render->SetTexture(ui_bomb_defuse_course);
	//ui_render->BeginRectangleList(1);
	//ui_render->Vertex(x - bmp_width / 2 * 0.5f, y - bmp_height / 2 * 0.5f, 1, uv.Min.x, uv.Min.y, ARGB(255, 255, 255));
	//ui_render->Vertex(x + bmp_width / 2 * 0.5f, y + bmp_height / 2 * 0.5f, 1, uv.Max.x, uv.Max.y, ARGB(255, 255, 255));

	ui_render->End();

	ui_render->DrawStringShadow(ui_render->font_simhei_16, Core::ARGB(255,255,128,4), ARGB(255,0,0,0), Core::ARGB(0,0,0,0), Core::Rectangle(x - bmp_width,y + 12,x + bmp_width,y + 30), gLang->GetTextW(L"������..."), Unit::kAlignCenterMiddle);

	Matrix44 tWorld;
	world = Matrix44::kIdentity;
	tWorld = ui_render->GetWorld();

	world.SetTranslationXYZ(x,y - bmp_height / 2 * 0.5f+10.f,0);
	ui_render->SetWorld(world);

	CStrBuf<256> buff;
	buff.format("%dM",length);
	ui_render->DrawString(ui_render->font_simhei_12,ARGB(255,255,255),ARGB(1,1,1,1),Core::Rectangle(-100,-5,100,-5),buff,Unit::kAlignCenterBottom);

	ui_render->SetWorld(tWorld);

	if (gDx9Device->GetStereoEnable())
		v = gDx9Device->convergence > 0 ? gDx9Device->convergence : 1;

	gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_CONVERGENCE, &v, 1);

	return true;
}

bool InGameUINew::_DrawNoviceLength(by_ptr(UIRender) ui_render, by_ptr(Texture2D) texture_content, Core::Vector3 vPos, bool isdraw, int alllen, Core::Vector3 vPosVehicle)
{
	Core::Vector3 rt_size = gGame->guiSys->GetSize();
	Matrix44 world;
	int bmp_width = texture_content->GetWidth();
	int bmp_height = texture_content->GetHeight();
	Vector3 pos;
	if (vPosVehicle.Length() > 0)
		pos = vPosVehicle;
	else
		pos = vPos;
	
	Matrix44 View,Proj,ViewProj;
	gGame->camera->CalculateViewProjectionMatrix(View, Proj);
	ViewProj = View * Proj;

	TransformCoord(pos, pos, ViewProj); 
	int x = rt_size.x / 2.0f + rt_size.x / 2.0f * pos.x;
	int y = rt_size.y / 2.0f - rt_size.y / 2.0f * pos.y;

	if(!gLevel->GetPlayer())
		return false;

	world.SetTranslationXYZ(0,10,0);
	ui_render->SetWorld(world);

	const Core::Vector3 &player_pos = (const Core::Vector3 &)gLevel->GetPlayer()->GetPosition();
	const Core::Vector3 &object_pos = (const Core::Vector3 &)pos;

	F32 len = Length(gGame->camera->position - CalcNewPosition(gGame->camera->position, object_pos));
	F32 v = gDx9Device->convergence > 0 ? gDx9Device->convergence : 1;
	if (gDx9Device->GetStereoEnable() &&  len> 0)
		v = len;

	gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_CONVERGENCE, &v, 1);
	int length = 0;
	if (vPosVehicle.Length() > 0)
		length = (Vector3(vPosVehicle.x, 0, vPosVehicle.z) - Vector3(vPos.x, 0, vPos.z)).Length();
	else
		length = (Vector3(player_pos.x, 0, player_pos.z) - Vector3(vPos.x, 0, vPos.z)).Length();
	y -= 100;


	if (gDx9Device->GetStereoEnable())
		v = gDx9Device->convergence > 0 ? gDx9Device->convergence : 1;
	gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_CONVERGENCE, &v, 1);
	

	gLevel->novice_isdraw = isdraw;
	gLevel->novice_index_pos = vPos;


	if (length < alllen)
		return true;

	return false;
}

void InGameUINew::_DrawNovice(by_ptr(UIRender) ui_render)
{
	tempc_ptr(Character) player = gLevel->GetPlayer();
	if (!player || !player->GetCurCharinfo())
		return;

	Matrix44 world;
	Core::Vector3 rt_size = gGame->guiSys->GetSize();
	current_screen_width_level = rt_size.x / 1600.0f;
	current_screen_height_level = rt_size.y / 1200.0f;

	world.SetTranslationXYZ(rt_size.x/2,rt_size.y/2,0);
	ui_render->SetWorld(world);

	CStrBuf<256> buff;
	Core::ARGB font_color(0,0,0);
	if (gLevel->game_type == RoomOption::kNovice)
	{
		int color = (gLevel->novice_timer > 1.f ? 255 : 255-244*(1-gLevel->novice_timer));
		switch(gLevel->novice_index)
		{
		case 0:
			break;
		case 1:			//���ݲ�ͬ��ְҵ���й�����ʾ
			{
				if (ui_novice_person_bg[player->character_info->career_id])
				{
					ui_render->DrawTextureWindow(Core::Vector2(-402,-399), 804, 560, ui_novice_person_bg[player->character_info->career_id],Core::Rectangle(0,0,1,1),Core::ARGB(color,255,255,255));
					
					int temp_x[6] = {-402, -402+223, -402+300, -402+255, -402+111, -402+223}; 
					int temp_y[6] = {-399, -399+356, -399+370, -399+376, -399+344, -399+377}; 
					Core::String str = Core::String::Format(gLang->GetTextW(L"��ӭ��������ѵ����         ������㽫ѧϰ������ְҵ�Ļ����������������ʾ��������"));
					SplitString(str,str,Core::Rectangle(0,0,342,134), ui_render->font_simhei_28);
					ui_render->DrawString(ui_render->font_simhei_28, ARGB(color,208,225,224), ARGB(1,1,1,1), 
											Core::Rectangle(temp_x[player->character_info->career_id], temp_y[player->character_info->career_id], temp_x[player->character_info->career_id]+342,temp_y[player->character_info->career_id]+134), 
											str, Unit::kAlignLeftTop);
					input_index = 0;
				}
			}
			break;
		case 2:			//�ƶ������ʾ
			{
				world.SetTranslationXYZ(rt_size.x-450,rt_size.y/2+30,0);
				ui_render->SetWorld(world);

				ui_render->SetTexture(ui_novice_tip_bg);
				ui_render->DrawWindow(Core::Rectangle(0, 0, 355, 146), Core::Rectangle(21, 21, 21, 21), Core::Rectangle(21.0f/64.f, 21.0f/64.f, 21.0f/64.f, 21.0f/64.f));

				for(int i = 0; i < 5;++i)
				{
					ui_render->DrawTextureWindow(Core::Vector2(80+45*i,140), 36, 36, ui_novice_gks_bg,Core::Rectangle(0,0,1,1));
				}
				ui_render->DrawTextureWindow(Core::Vector2(80+13,152), 12, 12, ui_novice_gks_down,Core::Rectangle(0,0,1,1));

				buff.format(gLang->GetTextW(L"����ƶ���"));
				ui_render->DrawString(ui_render->font_simhei_24, ARGB(177,57,58), ARGB(1,1,1,1), Core::Rectangle(0, 30, 355, 60), buff, Unit::kAlignCenterMiddle);
				buff.format(gLang->GetTextW(L"���۲����ܵĻ�����"));
				ui_render->DrawString(ui_render->font_simhei_24, ARGB(52,50,55), ARGB(1,1,1,1), Core::Rectangle(0, 65, 355, 100), buff, Unit::kAlignCenterMiddle);
				ui_render->DrawTextureWindow(Core::Vector2(145,168), 104, 144, ui_novice_mouse);
				int timer = (int)gLevel->novice_timer;
				float theta = Core::Sin(Task::GetTotalTime()*8);
				theta = 0.75 + 0.25*theta;
				if (timer % 2 == 0)
				{
					ui_render->DrawTextureWindow(Core::Vector2(80,209), 56, 40, ui_novice_leftright,Core::Rectangle(0,0,1,1));
					ui_render->DrawTextureWindow(Core::Vector2(80,209), 56, 40, ui_novice_leftright_light,Core::Rectangle(0,0,1,1),Core::ARGB(255*theta,255,255,255));
					ui_render->DrawTextureWindow(Core::Vector2(255,209), 56, 40, ui_novice_leftright,Core::Rectangle(1,0,0,1));
				}
				else
				{
					ui_render->DrawTextureWindow(Core::Vector2(80,209), 56, 40, ui_novice_leftright,Core::Rectangle(0,0,1,1));
					ui_render->DrawTextureWindow(Core::Vector2(255,209), 56, 40, ui_novice_leftright,Core::Rectangle(1,0,0,1));
					ui_render->DrawTextureWindow(Core::Vector2(255,209), 56, 40, ui_novice_leftright_light,Core::Rectangle(1,0,0,1),Core::ARGB(255*theta,255,255,255));
				}
			}
			break;
		case 3:			//WASD��ʾ
			{
				world.SetTranslationXYZ(rt_size.x-450,rt_size.y/2+30,0);
				ui_render->SetWorld(world);

				ui_render->SetTexture(ui_novice_tip_bg);
				ui_render->DrawWindow(Core::Rectangle(0, 0, 355, 146), Core::Rectangle(21, 21, 21, 21), Core::Rectangle(21.0f/64.f, 21.0f/64.f, 21.0f/64.f, 21.0f/64.f));

				for(int i = 0; i < 5;++i)
				{
					ui_render->DrawTextureWindow(Core::Vector2(80+45*i,140), 36, 36, ui_novice_gks_bg,Core::Rectangle(0,0,1,1));
				}
				ui_render->DrawTextureWindow(Core::Vector2(80+12+45,152), 12, 12, ui_novice_gks_down,Core::Rectangle(0,0,1,1));

				buff.format("w a s d");
				ui_render->DrawString(ui_render->font_simhei_24, ARGB(177,57,58), ARGB(1,1,1,1), Core::Rectangle(0, 30, 355, 60), buff, Unit::kAlignCenterMiddle);
				buff.format(gLang->GetTextW(L"��Ӧ��ɫǰ,��,��,���ƶ���"));
				ui_render->DrawString(ui_render->font_simhei_24, ARGB(52,50,55), ARGB(1,1,1,1), Core::Rectangle(0,65,355,110), buff, Unit::kAlignCenterMiddle);
				int timer = (int)gLevel->novice_timer;
				float theta = Core::Sin(Task::GetTotalTime()*8);
				theta = 0.75 + 0.25*theta;
				//a
				ui_render->DrawTextureWindow(Core::Vector2(76,249), 76, 76, ui_novice_keyboard_bg);
				ui_render->DrawTextureWindow(Core::Vector2(78,251), 72, 72, ui_novice_keyboard);
				_DrawNumberTextureWindow(ui_render, ui_novice_number, Core::Vector2(76+24,249+24), 24, 24, 7,0.1f);
				//s
				ui_render->DrawTextureWindow(Core::Vector2(76*2,249), 76, 76, ui_novice_keyboard_bg);
				ui_render->DrawTextureWindow(Core::Vector2(78*2,251), 72, 72, ui_novice_keyboard);
				_DrawNumberTextureWindow(ui_render, ui_novice_number, Core::Vector2(76*2+28,249+24), 24, 24, 8,0.1f);
				//d
				ui_render->DrawTextureWindow(Core::Vector2(76*3,249), 76, 76, ui_novice_keyboard_bg);
				ui_render->DrawTextureWindow(Core::Vector2(78*3,251), 72, 72, ui_novice_keyboard);
				_DrawNumberTextureWindow(ui_render, ui_novice_number, Core::Vector2(76*3+30,249+24), 24, 24, 9,0.1f);
				//w
				ui_render->DrawTextureWindow(Core::Vector2(76*2,249-76), 76, 76, ui_novice_keyboard_bg);
				ui_render->DrawTextureWindow(Core::Vector2(78*2,249-76+2), 72, 72, ui_novice_keyboard);
				_DrawNumberTextureWindow(ui_render, ui_novice_number, Core::Vector2(76*2+28,249-76+24), 24, 24, 6,0.1f);

				if (input_index == 0) //w
				{
					ui_render->DrawTextureWindow(Core::Vector2(78*2,249-76+2), 72, 72, ui_novice_keyboard_guang,Core::Rectangle(1,0,0,1),Core::ARGB(255*theta,255,255,255));
				}
				else if (input_index == 1) //s
				{
					ui_render->DrawTextureWindow(Core::Vector2(78*2,251), 72, 72, ui_novice_keyboard_guang,Core::Rectangle(1,0,0,1),Core::ARGB(255*theta,255,255,255));
				}
				else if (input_index == 2) //a
				{
					ui_render->DrawTextureWindow(Core::Vector2(78,251), 72, 72, ui_novice_keyboard_guang,Core::Rectangle(1,0,0,1),Core::ARGB(255*theta,255,255,255));
				}
				else if (input_index == 3) //d
				{
					ui_render->DrawTextureWindow(Core::Vector2(78*3,251), 72, 72, ui_novice_keyboard_guang,Core::Rectangle(1,0,0,1),Core::ARGB(255*theta,255,255,255));
				}
			}
			break;
		case 5:			//���䵯ҩ
			{
				int timer = (int)gLevel->novice_timer;
				float theta = Core::Sin(Task::GetTotalTime()*4);
				float theta2 = Core::Sin(Task::GetTotalTime()*2);
				theta2 = 0.75 + 0.25*theta2;

				world.SetTranslationXYZ(80,rt_size.y,0);
				ui_render->SetWorld(world);
				ui_render->DrawTextureWindow(Core::Vector2(110-theta*36,-145+theta*20), 48, 48, ui_novice_jiantou_3);
				ui_render->DrawTextureWindow(Core::Vector2(110-theta*36,-145+theta*20), 48, 48, ui_novice_jiantou_3light,Core::Rectangle(0,0,1,1),Core::ARGB(255*theta2,255,255,255));

				world.SetTranslationXYZ(rt_size.x,rt_size.y,0);
				ui_render->SetWorld(world);
				ui_render->DrawTextureWindow(Core::Vector2(-190+theta*36,-145+theta*20), 48, 48, ui_novice_jiantou_3,Core::Rectangle(1,0,0,1));
				ui_render->DrawTextureWindow(Core::Vector2(-190+theta*36,-145+theta*20), 48, 48, ui_novice_jiantou_3light,Core::Rectangle(1,0,0,1),Core::ARGB(255*theta2,255,255,255));

				world = Matrix44::kIdentity;
				world.SetTranslationXYZ(rt_size.x-450,rt_size.y/2+30,0);
				ui_render->SetWorld(world);

				ui_render->SetTexture(ui_novice_tip_bg);
				ui_render->DrawWindow(Core::Rectangle(-20, -10, 375, 156), Core::Rectangle(21, 21, 21, 21), Core::Rectangle(21.0f/64.f, 21.0f/64.f, 21.0f/64.f, 21.0f/64.f));

				Core::String str = Core::String::Format(gLang->GetTextW(L"��ʾ������ֵ�����ҩ��������ʱ����Լ�ȡ�������������䡣"));
				SplitString(str,str,Core::Rectangle(0,0,342,50), ui_render->font_simhei_24);
				ui_render->DrawString(ui_render->font_simhei_24, ARGB(52,50,55), ARGB(1,1,1,1), Core::Rectangle(0,0,355,73), str, Unit::kAlignCenterMiddle);
				str = Core::String::Format(gLang->GetTextW(L"�뵽ǰ���Ĳ������ָ������͵�ҩ����"));
				SplitString(str,str,Core::Rectangle(0,0,342,50), ui_render->font_simhei_24);
				ui_render->DrawString(ui_render->font_simhei_24, ARGB(177,57,58), ARGB(1,1,1,1), Core::Rectangle(0,73,355,146), str, Unit::kAlignCenterMiddle);
			}
			break;
		case 6:			//�ƶ���ѵ��������һ�׶ν�����
			{
				world = Matrix44::kIdentity;
				world.SetTranslationXYZ(rt_size.x-450,rt_size.y/2+30,0);
				ui_render->SetWorld(world);

				ui_render->SetTexture(ui_novice_tip_bg);
				ui_render->DrawWindow(Core::Rectangle(-20, -10, 375, 156), Core::Rectangle(21, 21, 21, 21), Core::Rectangle(21.0f/64.f, 21.0f/64.f, 21.0f/64.f, 21.0f/64.f));
				Core::String str = Core::String::Format(gLang->GetTextW(L"���Ѿ��˽�����Ĳ�����������ͨ����������ǰ����һѵ��������ָʾĿ�괦��"));
				SplitString(str,str,Core::Rectangle(0,0,342,134), ui_render->font_simhei_24);
				ui_render->DrawString(ui_render->font_simhei_24, ARGB(52,50,55), ARGB(1,1,1,1), Core::Rectangle(15,45,15+342,45+134), str, Unit::kAlignLeftTop);
				
				//����
				bool ispass = _DrawNoviceLength(ui_render,ui_novice_biaoji_point,Vector3(15.6f,0.05f,15.918f));
				if(ispass)
				{
					gLevel->novice_index = 7;
					gLevel->novice_timer = 0.f;
					gLevel->novice_need_timer = false;
				}
			}
			break;
		case 7:			//�ո����Ŀ�ĵ���Ծ
			{
				world.SetTranslationXYZ(rt_size.x-450,rt_size.y/2+30,0);
				ui_render->SetWorld(world);

				ui_render->SetTexture(ui_novice_tip_bg);
				ui_render->DrawWindow(Core::Rectangle(0, 0, 355, 146), Core::Rectangle(21, 21, 21, 21), Core::Rectangle(21.0f/64.f, 21.0f/64.f, 21.0f/64.f, 21.0f/64.f));

				for(int i = 0; i < 5;++i)
				{
					ui_render->DrawTextureWindow(Core::Vector2(80+45*i,140), 36, 36, ui_novice_gks_bg,Core::Rectangle(0,0,1,1));
				}
				ui_render->DrawTextureWindow(Core::Vector2(80+13+90,152), 12, 12, ui_novice_gks_down,Core::Rectangle(0,0,1,1));
				buff.format(gLang->GetTextW(L"space���ո�"));
				ui_render->DrawString(ui_render->font_simhei_24, ARGB(177,57,58), ARGB(1,1,1,1), Core::Rectangle(110,35,160,65), buff, Unit::kAlignLeftTop);
				buff.format(gLang->GetTextW(L"����ʱ����ʹԽ���ϰ���"));
				ui_render->DrawString(ui_render->font_simhei_24, ARGB(52,50,55), ARGB(1,1,1,1), Core::Rectangle(50,75,240,105), buff, Unit::kAlignLeftTop);
				ui_render->DrawTextureWindow(Core::Vector2(125,209), 168, 80, ui_novice_space);
				int timer = (int)gLevel->novice_timer;
				float theta = Core::Sin(Task::GetTotalTime()*8);
				theta = 0.75 + 0.25*theta;
				ui_render->DrawTextureWindow(Core::Vector2(128,214), 160, 72, ui_novice_space_guang,Core::Rectangle(0,0,1,1),Core::ARGB(255*theta,255,255,255));

				//����
				bool ispass = _DrawNoviceLength(ui_render,ui_novice_biaoji_point,Vector3(14.13f,0.05f,15.918f),true);
				if(ispass)
				{
					gLevel->novice_index = 8;
					gLevel->novice_timer = 5.f;
					gLevel->novice_need_timer = true;
				}
			}
			break;
		case 8:			//��ʾ���
			{
				gLevel->novice_isdraw = false;
				gLevel->novice_index_pos = Vector3(0,-15,0);
				if (ui_novice_person_bg[player->character_info->career_id])
				{
					ui_render->DrawTextureWindow(Core::Vector2(-402,-399), 804, 560, ui_novice_person_bg[player->character_info->career_id],Core::Rectangle(0,0,1,1),Core::ARGB(color,255,255,255));
					
					int temp_x[6] = {-402, -402+223, -402+300, -402+255, -402+111, -402+223}; 
					int temp_y[6] = {-399, -399+356, -399+370, -399+376, -399+344, -399+377}; 
					Core::String str = Core::String::Format(gLang->GetTextW(L"��ӭ�������ѵ����         ������㽫ѧϰ������ְҵ������������������ʾ��������"));
					SplitString(str,str,Core::Rectangle(0,0,342,134), ui_render->font_simhei_28);
					ui_render->DrawString(ui_render->font_simhei_28, ARGB(color,208,225,224), ARGB(1,1,1,1), 
											Core::Rectangle(temp_x[player->character_info->career_id], temp_y[player->character_info->career_id], temp_x[player->character_info->career_id]+342,temp_y[player->character_info->career_id]+134), 
											str, Unit::kAlignLeftTop);
					input_index = 0;
				}
			}
			break;
		case 9:			//1234�͹���
			{
				world.SetTranslationXYZ(rt_size.x-450,rt_size.y/2+30,0);
				ui_render->SetWorld(world);

				ui_render->SetTexture(ui_novice_tip_bg);
				ui_render->DrawWindow(Core::Rectangle(0, 0, 355, 146), Core::Rectangle(21, 21, 21, 21), Core::Rectangle(21.0f/64.f, 21.0f/64.f, 21.0f/64.f, 21.0f/64.f));

				for(int i = 0; i < 5;++i)
				{
					ui_render->DrawTextureWindow(Core::Vector2(80+45*i,140), 36, 36, ui_novice_gks_bg,Core::Rectangle(0,0,1,1));
				}
				ui_render->DrawTextureWindow(Core::Vector2(80+13+135,152), 12, 12, ui_novice_gks_down,Core::Rectangle(0,0,1,1));
				buff.format(gLang->GetTextW(L"��ʹ��1��2��3"));
				ui_render->DrawString(ui_render->font_simhei_24, ARGB(177,57,58), ARGB(1,1,1,1), Core::Rectangle(0,35,355,65), buff, Unit::kAlignCenterMiddle);
				buff.format(gLang->GetTextW(L"�����л�������"));
				ui_render->DrawString(ui_render->font_simhei_24, ARGB(52,50,55), ARGB(1,1,1,1), Core::Rectangle(0,75,355,105), buff, Unit::kAlignCenterTop);
	
				for(int i = 0; i < 3;++i)
				{
					ui_render->DrawTextureWindow(Core::Vector2(-30+76*i,189), 76, 76, ui_novice_keyboard_bg);
					ui_render->DrawTextureWindow(Core::Vector2(-30+78*i,191), 72, 72, ui_novice_keyboard);
					_DrawNumberTextureWindow(ui_render, ui_novice_number, Core::Vector2(-30+76*i+24,189+24), 24, 24, i,0.1f);
				}
				int timer = (int)gLevel->novice_timer;
				float theta = Core::Sin(Task::GetTotalTime()*8);
				theta = 0.75 + 0.25*theta;
				if (input_index == 0) //1
				{
					ui_render->DrawTextureWindow(Core::Vector2(-30+78,191), 72, 72, ui_novice_keyboard_guang,Core::Rectangle(1,0,0,1),Core::ARGB(255*theta,255,255,255));
				}
				else if (input_index == 1) //2
				{
					ui_render->DrawTextureWindow(Core::Vector2(-30+78*2,191), 72, 72, ui_novice_keyboard_guang,Core::Rectangle(1,0,0,1),Core::ARGB(255*theta,255,255,255));
				}
				else if (input_index == 2) //3
				{
					ui_render->DrawTextureWindow(Core::Vector2(-30,191), 72, 72, ui_novice_keyboard_guang,Core::Rectangle(1,0,0,1),Core::ARGB(255*theta,255,255,255));
				}
				ui_render->DrawTextureWindow(Core::Vector2(290,168), 104, 144, ui_novice_mouse);
				//timer = (int)gLevel->novice_timer;
				//theta = Core::Sin(Task::GetTotalTime()*8);
				//ui_render->DrawTextureWindow(Core::Vector2(360,170+theta/10*45), 44, 68, ui_novice_wheel);
				//float theta2 = 0.75 + 0.25*theta;
				//ui_render->DrawTextureWindow(Core::Vector2(360,170+theta/10*45), 44, 68, ui_novice_wheel_light,Core::Rectangle(0,0,1,1),Core::ARGB(255*theta2,255,255,255));
			}
			break;
		case 10:			//������
			{
				world.SetTranslationXYZ(rt_size.x-450,rt_size.y/2+30,0);
				ui_render->SetWorld(world);

				ui_render->SetTexture(ui_novice_tip_bg);
				ui_render->DrawWindow(Core::Rectangle(-100, 0, 455, 146), Core::Rectangle(21, 21, 21, 21), Core::Rectangle(21.0f/64.f, 21.0f/64.f, 21.0f/64.f, 21.0f/64.f));

				buff.format(gLang->GetTextW(L"���¡�1��,�����������"));
				ui_render->DrawString(ui_render->font_simhei_24, ARGB(177,57,58), ARGB(1,1,1,1), Core::Rectangle(0,15,355,45), buff, Unit::kAlignCenterMiddle);
				buff.format(gLang->GetTextW(L"ʹ�����������ǹ�С�"));
				ui_render->DrawString(ui_render->font_simhei_24, ARGB(52,50,55), ARGB(1,1,1,1), Core::Rectangle(0,55,355,85), buff, Unit::kAlignCenterMiddle);

				if (player)
				{
					switch(player->character_info->career_id)
					{
					case 1:
						{
							buff.format(gLang->GetTextW(L"�ڵ����н���Ч����"));
							ui_render->DrawString(ui_render->font_simhei_24, ARGB(177,57,58), ARGB(1,1,1,1), Core::Rectangle(0,95,355,125), buff, Unit::kAlignCenterMiddle);
						}
						break;
					case 2:
						{
							buff.format(gLang->GetTextW(L"��ǹ��ס����Ҽ��ɳ���Ԥ�ȡ�"));
							ui_render->DrawString(ui_render->font_simhei_24, ARGB(177,57,58), ARGB(1,1,1,1), Core::Rectangle(0,95,355,125), buff, Unit::kAlignCenterMiddle);
						}
						break;
					case 3:
						{
							buff.format(gLang->GetTextW(L"����Ҽ����Դ���׼����׼��"));
							ui_render->DrawString(ui_render->font_simhei_24, ARGB(52,50,55), ARGB(1,1,1,1), Core::Rectangle(0,80,355,140), buff, Unit::kAlignCenterMiddle);
						}
						break;
					case 4:
						{
							Core::String str = Core::String::Format(gLang->GetTextW(L"ͻ������׼���˵�ͷ���������ɴ����˺�����"));
							SplitString(str,str,Core::Rectangle(0,80,355,140), ui_render->font_simhei_28);
							ui_render->DrawString(ui_render->font_simhei_24, ARGB(52,50,55), ARGB(1,1,1,1), Core::Rectangle(0,80,355,140), str, Unit::kAlignCenterMiddle);
						}
						break;
					case 5:
						{
							Core::String str = Core::String::Format(gLang->GetTextW(L"��ס�Ҽ�����ʹ������������������"));
							SplitString(str,str,Core::Rectangle(0,80,355,140), ui_render->font_simhei_28);
							ui_render->DrawString(ui_render->font_simhei_24, ARGB(177,57,58), ARGB(1,1,1,1), Core::Rectangle(0,80,355,140), str, Unit::kAlignCenterMiddle);
						}
						break;
					}
				}

				if (gLevel->novice_shoot_num <= 0)
				{
					gLevel->novice_index = 11;
					gLevel->novice_timer = 1.4f;
					gLevel->novice_need_timer = true;
				}
			}
			break;
		case 12:			//R����ʾ
			{
				world.SetTranslationXYZ(rt_size.x-450,rt_size.y/2+30,0);
				ui_render->SetWorld(world);

				ui_render->SetTexture(ui_novice_tip_bg);
				ui_render->DrawWindow(Core::Rectangle(0, 0, 355, 146), Core::Rectangle(21, 21, 21, 21), Core::Rectangle(21.0f/64.f, 21.0f/64.f, 21.0f/64.f, 21.0f/64.f));

				for(int i = 0; i < 5;++i)
				{
					ui_render->DrawTextureWindow(Core::Vector2(80+45*i,140), 36, 36, ui_novice_gks_bg,Core::Rectangle(0,0,1,1));
				}
				ui_render->DrawTextureWindow(Core::Vector2(80+13+180,152), 12, 12, ui_novice_gks_down,Core::Rectangle(0,0,1,1));
				if (player)
				{
					switch(player->character_info->career_id)
					{
					case 1:
						{
							buff.format("R");
							ui_render->DrawString(ui_render->font_simhei_24, ARGB(177,57,58), ARGB(1,1,1,1), Core::Rectangle(170,35,200,65), buff, Unit::kAlignLeftTop);
							buff.format(gLang->GetTextW(L"����װ�ҩ��"));
							ui_render->DrawString(ui_render->font_simhei_24, ARGB(52,50,55), ARGB(1,1,1,1), Core::Rectangle(115,75,240,105), buff, Unit::kAlignLeftTop);

							int timer = (int)gLevel->novice_timer;
							float theta = Core::Sin(Task::GetTotalTime()*8);
							theta = 0.75 + 0.25*theta;
							ui_render->DrawTextureWindow(Core::Vector2(176,199), 76, 76, ui_novice_keyboard_bg);
							ui_render->DrawTextureWindow(Core::Vector2(178,201), 72, 72, ui_novice_keyboard);
							_DrawNumberTextureWindow(ui_render, ui_novice_number, Core::Vector2(176+24,199+24), 24, 24, 5,0.1f);
							ui_render->DrawTextureWindow(Core::Vector2(178,201), 72, 72, ui_novice_keyboard_guang,Core::Rectangle(1,0,0,1),Core::ARGB(255*theta,255,255,255));
						}
						break;
					case 2:
						{
							buff.format(gLang->GetTextW(L"�ػ�ǹ�ǲ���Ҫ�ϵ��ġ�"));
							ui_render->DrawString(ui_render->font_simhei_24, ARGB(52,50,55), ARGB(1,1,1,1), Core::Rectangle(0,65,355,95), buff, Unit::kAlignCenterMiddle);
						}
						break;
					case 3:
						{

							Core::String str = Core::String::Format(gLang->GetTextW(L"����������׼���˵�ͷ����������һ����ɱЧ����"));
							SplitString(str,str,Core::Rectangle(0,80,355,140), ui_render->font_simhei_28);
							ui_render->DrawString(ui_render->font_simhei_24, ARGB(177,57,58), ARGB(1,1,1,1), Core::Rectangle(0,0,355,140), str, Unit::kAlignCenterMiddle);
						}
						break;
					case 4:
						{
							buff.format(gLang->GetTextW(L"R ����װ�ҩ��"));
							ui_render->DrawString(ui_render->font_simhei_24, ARGB(177,57,58), ARGB(1,1,1,1), Core::Rectangle(0,35,355,65), buff, Unit::kAlignCenterMiddle);
							buff.format(gLang->GetTextW(L"����Ҽ����Դ���׼����׼��"));
							ui_render->DrawString(ui_render->font_simhei_24, ARGB(52,50,55), ARGB(1,1,1,1), Core::Rectangle(0,75,355,105), buff, Unit::kAlignCenterMiddle);

							int timer = (int)gLevel->novice_timer;
							float theta = Core::Sin(Task::GetTotalTime()*8);
							theta = 0.75 + 0.25*theta;
							ui_render->DrawTextureWindow(Core::Vector2(176,199), 76, 76, ui_novice_keyboard_bg);
							ui_render->DrawTextureWindow(Core::Vector2(178,201), 72, 72, ui_novice_keyboard);
							_DrawNumberTextureWindow(ui_render, ui_novice_number, Core::Vector2(176+24,199+24), 24, 24, 5,0.1f);
							ui_render->DrawTextureWindow(Core::Vector2(178,201), 72, 72, ui_novice_keyboard_guang,Core::Rectangle(1,0,0,1),Core::ARGB(255*theta,255,255,255));
						}
						break;
					case 5:
						{
							Core::String str = Core::String::Format(gLang->GetTextW(L"����ǹ�Ļ��������Խ���˺�Խ�󣬲��ҿ�����ɶ��ݳ����˺�����"));
							SplitString(str,str,Core::Rectangle(15,50,340,134), ui_render->font_simhei_24);
							ui_render->DrawString(ui_render->font_simhei_24, ARGB(52,50,55), ARGB(1,1,1,1), Core::Rectangle(20,30,340,124), str, Unit::kAlignLeftTop);
						}
						break;
					}
				}
			}
			break;
		case 13:
			{
				_DrawNoviceLength(ui_render, ui_novice_biaoji_point, Vector3(15.908f, -0.082f, 4.726f), false);
				world.SetTranslationXYZ(rt_size.x-450,rt_size.y/2+30,0);
				ui_render->SetWorld(world);

				ui_render->SetTexture(ui_novice_tip_bg);
				ui_render->DrawWindow(Core::Rectangle(0, 0, 355, 146), Core::Rectangle(21, 21, 21, 21), Core::Rectangle(21.0f/64.f, 21.0f/64.f, 21.0f/64.f, 21.0f/64.f));

				buff.format(gLang->GetTextW(L"�����ǰ���ƶ��е�ǹ�С�"));
				ui_render->DrawString(ui_render->font_simhei_24, ARGB(52,50,55), ARGB(1,1,1,1), Core::Rectangle(0,65,355,95), buff, Unit::kAlignCenterMiddle);

				if (gLevel->novice_shoot_num <= 0)
				{
					gLevel->novice_index = 14;
					gLevel->novice_timer = 1.4f;
					gLevel->novice_need_timer = true;
				}
			}
			break;
		case 15:
			{
				world.SetTranslationXYZ(rt_size.x-450,rt_size.y/2+30,0);
				ui_render->SetWorld(world);

				ui_render->SetTexture(ui_novice_tip_bg);
				ui_render->DrawWindow(Core::Rectangle(0, 0, 355, 146), Core::Rectangle(21, 21, 21, 21), Core::Rectangle(21.0f/64.f, 21.0f/64.f, 21.0f/64.f, 21.0f/64.f));

				buff.format(gLang->GetTextW(L"���¡�2��,�����������"));
				ui_render->DrawString(ui_render->font_simhei_24, ARGB(177,57,58), ARGB(1,1,1,1), Core::Rectangle(0,35,355,65), buff, Unit::kAlignCenterMiddle);
				buff.format(gLang->GetTextW(L"ʹ�ø��������ǹ�С�"));
				ui_render->DrawString(ui_render->font_simhei_24, ARGB(52,50,55), ARGB(1,1,1,1), Core::Rectangle(0,75,355,105), buff, Unit::kAlignCenterMiddle);

				if (gLevel->novice_shoot_num <= 0)
				{
					gLevel->novice_index = 16;
					gLevel->novice_timer = 1.4f;
					gLevel->novice_need_timer = true;
				}
			}
			break;
		case 17:
			{
				world.SetTranslationXYZ(rt_size.x-450,rt_size.y/2+30,0);
				ui_render->SetWorld(world);

				ui_render->SetTexture(ui_novice_tip_bg);
				ui_render->DrawWindow(Core::Rectangle(0, 0, 355, 146), Core::Rectangle(21, 21, 21, 21), Core::Rectangle(21.0f/64.f, 21.0f/64.f, 21.0f/64.f, 21.0f/64.f));

				buff.format(gLang->GetTextW(L"���¡�3��,�����������"));
				ui_render->DrawString(ui_render->font_simhei_24, ARGB(177,57,58), ARGB(1,1,1,1), Core::Rectangle(0,35,355,65), buff, Unit::kAlignCenterMiddle);
				buff.format(gLang->GetTextW(L"ʹ�ý�ս��������ǹ�С�"));
				ui_render->DrawString(ui_render->font_simhei_24, ARGB(52,50,55), ARGB(1,1,1,1), Core::Rectangle(0,75,355,105), buff, Unit::kAlignCenterMiddle);

				if (gLevel->novice_shoot_num <= 0)
				{
					//gLevel->novice_index = 18;
					//gLevel->novice_timer = 2.f;
					//gLevel->novice_need_timer = true;
					//ֱ���������ֹ�
					gLevel->novice_index = 23;
					gLevel->novice_timer = 6.f;
					gLevel->novice_need_timer = true;
				}
			}
			break;
		case 19:
			{
				world = Matrix44::kIdentity;
				world.SetTranslationXYZ(rt_size.x-450,rt_size.y/2+30,0);
				ui_render->SetWorld(world);

				ui_render->SetTexture(ui_novice_tip_bg);
				ui_render->DrawWindow(Core::Rectangle(-20, -10, 375, 156), Core::Rectangle(21, 21, 21, 21), Core::Rectangle(21.0f/64.f, 21.0f/64.f, 21.0f/64.f, 21.0f/64.f));
				Core::String str = Core::String::Format(gLang->GetTextW(L"���Ѿ��˽�����������������ͨ����������ǰ����һѵ��������ָʾĿ�괦��"));
				SplitString(str,str,Core::Rectangle(0,0,342,134), ui_render->font_simhei_24);
				ui_render->DrawString(ui_render->font_simhei_22, ARGB(52,50,55), ARGB(1,1,1,1), Core::Rectangle(0,0,355,146), str, Unit::kAlignCenterMiddle);

				//����
				bool ispass = _DrawNoviceLength(ui_render, ui_novice_biaoji_point, Vector3(13.977f, 0.297f, 2.138f), false, 5);
				_DrawNoviceLength(ui_render, ui_novice_biaoji_point, Vector3(15.908f, -0.082f, 4.726f), true, 1);
				gLevel->novice_index_pos = Vector3(15.908f, 0.f, 4.726f);

				gLevel->novice_isdraw = true;
				if(ispass)
				{
					gLevel->novice_index = 20;
					gLevel->novice_timer = 0.f;
					gLevel->novice_need_timer = false;
				}
			}
			break;
		case 20:			//�Ƴ�
			{
				if (_DrawNoviceLength(ui_render, ui_novice_biaoji_point, Vector3(10.201f, 0.092f, 4.437f), false, 6)
					&& _DrawNoviceLength(ui_render, ui_novice_biaoji_point, Vector3(10.201f, 0.092f, 4.437f), false, 6, gLevel->vehicle[0]->GetPosition()))
				{
					world = Matrix44::kIdentity;
					world.SetTranslationXYZ(rt_size.x-450,rt_size.y/2+30,0);
					ui_render->SetWorld(world);

					ui_render->SetTexture(ui_novice_tip_bg);
					ui_render->DrawWindow(Core::Rectangle(-20, -10, 375, 156), Core::Rectangle(21, 21, 21, 21), Core::Rectangle(21.0f/64.f, 21.0f/64.f, 21.0f/64.f, 21.0f/64.f));
					Core::String str = Core::String::Format(gLang->GetTextW(L"��ӭ�����Ƴ�ģʽѵ���������㿿��ǰ���ĳ������������ǰ��ֱ���յ㣬���⳵�������ָ������͵�ҩ���볢�԰ѳ��Ƶ��յ㡣"));
					SplitString(str,str,Core::Rectangle(0,0,342,134), ui_render->font_simhei_24);
					ui_render->DrawString(ui_render->font_simhei_24, ARGB(52,50,55), ARGB(1,1,1,1), Core::Rectangle(15,8,15+342,8+134), str, Unit::kAlignLeft);
				}
				else if (_DrawNoviceLength(ui_render, ui_novice_biaoji_point, Vector3(2.91f, 1.329f, -0.931f), false, 6)
						&& _DrawNoviceLength(ui_render, ui_novice_biaoji_point, Vector3(2.91f, 1.329f, -0.931f), false, 6, gLevel->vehicle[0]->GetPosition()))
				{
					world = Matrix44::kIdentity;
					world.SetTranslationXYZ(rt_size.x-450,rt_size.y/2+30,0);
					ui_render->SetWorld(world);

					ui_render->SetTexture(ui_novice_tip_bg);
					ui_render->DrawWindow(Core::Rectangle(-20, -10, 375, 156), Core::Rectangle(21, 21, 21, 21), Core::Rectangle(21.0f/64.f, 21.0f/64.f, 21.0f/64.f, 21.0f/64.f));
					Core::String str = Core::String::Format(gLang->GetTextW(L"��������б��ʱ������������ƶ���������б�����Զ��»���б����㡣"));
					SplitString(str,str,Core::Rectangle(0,0,342,134), ui_render->font_simhei_24);
					ui_render->DrawString(ui_render->font_simhei_24, ARGB(52,50,55), ARGB(1,1,1,1), Core::Rectangle(15,25,15+342,25+134), str, Unit::kAlignLeft);
				}
			}
			break;
		case 21:
			{
				if (gLevel->vehicle_sound[0])
					gLevel->vehicle_sound[0]->stop();
				if (gLevel->vehicle_sound[1])
					gLevel->vehicle_sound[1]->stop();
				world = Matrix44::kIdentity;
				world.SetTranslationXYZ(rt_size.x-450,rt_size.y/2+30,0);
				ui_render->SetWorld(world);

				ui_render->SetTexture(ui_novice_tip_bg);
				ui_render->DrawWindow(Core::Rectangle(-20, -10, 375, 156), Core::Rectangle(21, 21, 21, 21), Core::Rectangle(21.0f/64.f, 21.0f/64.f, 21.0f/64.f, 21.0f/64.f));
				Core::String str = Core::String::Format(gLang->GetTextW(L"���Ѿ��˽�������Ƴ�ģʽ����ͨ����������ǰ����һѵ��������ָʾĿ�괦��"));
				SplitString(str,str,Core::Rectangle(0,0,342,134), ui_render->font_simhei_24);
				ui_render->DrawString(ui_render->font_simhei_24, ARGB(52,50,55), ARGB(1,1,1,1), Core::Rectangle(15,45,15+342,45+134), str, Unit::kAlignLeftTop);

				//����
				bool ispass = _DrawNoviceLength(ui_render, ui_novice_biaoji_point, Vector3(-3.014f, 2.583f, -17.184f), true, 1);
				if(ispass)
				{
					gLevel->novice_index = 22;
					gLevel->novice_timer = 0.f;
					gLevel->novice_need_timer = false;
					gLevel->team_timer[0] = 10.f;
					is_novice_holdpoint_ok = false;
					zd_fPersert_red = 0.f;
					zd_red_showtime = 0.f;
				}
			}
			break;
		case 22:
			{
				zd_speed = 16.f;

				world = Matrix44::kIdentity;
				world.SetTranslationXYZ(rt_size.x-450,rt_size.y/2+30,0);
				ui_render->SetWorld(world);

				ui_render->SetTexture(ui_novice_tip_bg);
				ui_render->DrawWindow(Core::Rectangle(-20, -10, 375, 156), Core::Rectangle(21, 21, 21, 21), Core::Rectangle(21.0f/64.f, 21.0f/64.f, 21.0f/64.f, 21.0f/64.f));
				Core::String str = Core::String::Format(gLang->GetTextW(L"��ӭ����ռ��ģʽѵ�����ڳ����м���һ����Ҫ��ռ���Ŀ�ĵأ���վ��ȥֱ���·���������ռ���������;�뿪������������ˡ�"));
				SplitString(str,str,Core::Rectangle(0,0,342,134), ui_render->font_simhei_24);
				ui_render->DrawString(ui_render->font_simhei_24, ARGB(52,50,55), ARGB(1,1,1,1), Core::Rectangle(15,8,15+342,8+134), str, Unit::kAlignLeftTop);

				world = Core::Matrix44::kIdentity;
				world.SetTranslationXYZ(rt_size.x/2, rt_size.y, 0);
				ui_render->SetWorld(world);

				int bg_x = -197;
				int bg_y = -86;
				float freamtime = Task::GetFrameTime();

				ui_render->SetTexture(ui_hold_point_info_bg_border_L);
				ui_render->DrawWindow(Core::Rectangle(bg_x,bg_y,bg_x+167,bg_y+80),Core::Rectangle(26,0,0,0),Core::Rectangle(26.0f/52.f, 0.0f/80.f, 0.0f/52.f, 0.0f/80.f));
				ui_render->SetTexture(ui_hold_point_info_bg_border_R);
				ui_render->DrawWindow(Core::Rectangle(bg_x+167+52,bg_y,bg_x+167+52+167,bg_y+80),Core::Rectangle(0,0,26,0),Core::Rectangle(0.0f/52.f, 0.0f/80.f, 26.0f/52.f, 0.0f/80.f));

				bool ispass = false;
				//����
				if (!is_novice_holdpoint_ok)
				{
					ui_render->SetTexture(ui_hold_point_info_bg_border);
					ui_render->DrawWindow(Core::Rectangle(bg_x+167,bg_y,bg_x+167+52,bg_y+80),Core::Rectangle(0,0,0,0),Core::Rectangle(0, 0, 0, 0));
					ispass = _DrawNoviceLength(ui_render, ui_novice_biaoji_point, Vector3(5.026f, 2.523f, -19.99f), false, 2.4f);
					if (ispass)
					{
						zd_fPersert_red += zd_speed * freamtime;
						zd_fPersert_red = zd_fPersert_red >= 100.f ? 100.f : zd_fPersert_red;
					}
					else
					{
						zd_fPersert_red -= zd_speed * freamtime * 0.5;
						zd_fPersert_red = zd_fPersert_red <= 0.f ? 0.f : zd_fPersert_red;
					}
					if (zd_fPersert_red >= 100.f)
					{
						is_novice_holdpoint_ok = true;
						zd_red_showtime = 1;
					}
				}

				world.SetTranslationXYZ(rt_size.x/2, rt_size.y, 0);
				ui_render->SetWorld(world);

				bg_x = -197;
				bg_y = -86;
				
				if (zd_fPersert_red > 0 && (!is_novice_holdpoint_ok || zd_red_showtime > 0))
				{
					if (zd_red_showtime > 0)
					{
						ui_render->SetTexture(ui_hold_point_info_bg_border);
						ui_render->DrawWindow(Core::Rectangle(bg_x+167,bg_y,bg_x+167+52,bg_y+80),Core::Rectangle(0,0,0,0),Core::Rectangle(0, 0, 0, 0));
					}

					ui_render->SetTexture(ui_hold_point_info_progress);
					ui_render->DrawWindow(Core::Rectangle(bg_x+46,bg_y-15,bg_x+46+294,bg_y-15+36),Core::Rectangle(3,0,3,0),Core::Rectangle(3.0f/84.f, 0.0f/36.f, 3.0f/84.f, 0.0f/36.f));

					float point_x = (zd_fPersert_red) / 100 * 288;
					float point_y = 36;

					ui_render->SetTexture(ui_hold_point_info_flag_red);
					ui_render->DrawWindow(Core::Rectangle(bg_x+48,bg_y-15,bg_x+48+point_x,bg_y-15+point_y),Core::Rectangle(0,0,0,0),Core::Rectangle(0.0f/84.f, 0.0f/36.f, 0.0f/84.f, 0.0f/36.f));
					ui_render->DrawTextureWindow(Core::Vector2(bg_x+24+point_x, bg_y-17), 48, point_y, ui_hold_point_info_board_red,Core::Rectangle(0,0,1,1));

					if (ispass)
					{
						ui_render->DrawTextureWindow(Core::Vector2(bg_x+36+point_x, bg_y-17+6), 12.0f, 16.0f, ui_hold_point_info_people);
						Core::CStrBuf<256> buff;
						Core::ARGB font_color = Core::ARGB(255, 241, 211);
						Core::ARGB bg_color = Core::ARGB(0, 0, 0, 0);
						
						buff.format("X1");
						ui_render->DrawFontWindow(Core::Vector2(bg_x+48+point_x, bg_y-17), 80.0f, 24.0f, ui_render->font_simhei_16, font_color, bg_color, buff, Unit::kAlignLeftMiddle, true);
					}
					if (zd_red_showtime > 0)
					{
						zd_time += Task::GetFrameTime() * 6;
						zd_time = (zd_time >= 7200) ? 0 : zd_time;
						zd_time += freamtime;
						zd_red_showtime -= freamtime;
						float alphacolor = Core::Sin(zd_time);
						alphacolor = 100 + alphacolor * 155;
						ARGB bg_color = Core::ARGB(alphacolor, 255, 255, 255);
						ui_render->SetTexture(ui_hold_point_info_waifaguang_bg);
						ui_render->DrawWindow(Core::Rectangle(bg_x+48,bg_y-15,bg_x+48+288,bg_y-15+36),Core::Rectangle(0,0,0,0),Core::Rectangle(0.0f/84.f, 0.0f/36.f, 0.0f/84.f, 0.0f/36.f),bg_color);
						ui_render->DrawTextureWindow(Core::Vector2(bg_x+24+288, bg_y-17), 48, 36, ui_hold_point_info_board_red,Core::Rectangle(0,0,1,1));
						ui_render->DrawTextureWindow(Core::Vector2(bg_x+24+288, bg_y-17), 48, 36, ui_hold_point_info_waifaguang_board,Core::Rectangle(0,0,1,1),bg_color);

						ui_render->DrawTextureWindow(Core::Vector2(bg_x+36+point_x, bg_y-17+6), 12.0f, 16.0f, ui_hold_point_info_people);
						Core::CStrBuf<256> buff;
						Core::ARGB font_color = Core::ARGB(255, 241, 211);
						bg_color = Core::ARGB(0, 0, 0, 0);

						buff.format("X1");
						ui_render->DrawFontWindow(Core::Vector2(bg_x+48+point_x, bg_y-17), 80.0f, 24.0f, ui_render->font_simhei_16, font_color, bg_color, buff, Unit::kAlignLeftMiddle, true);
					}
				}

				//----------------------------------------------------------------------------------------------------------------
				Core::CStrBuf<256> tempbuf;
				float fP;
				int timeminute;
				int timesecond;

				timeminute = gLevel->team_timer[0];
				timesecond = int( timeminute ) % 60;
				timeminute = timeminute / 60;

				fP = gLevel->team_timer[0] / 10.f;

				if (is_novice_holdpoint_ok && gLevel->team_timer[0] > 0.f)
				{
					gLevel->team_timer[0] -= freamtime;
				}

				ui_render->SetTexture(ui_hold_point_timer_red);
				ui_render->DrawWindow(Core::Rectangle(bg_x+12+147*(1-fP),bg_y,bg_x+12+155,bg_y+80),Core::Rectangle(12,0,0,0),Core::Rectangle(12.0f/40.f, 0.0f/80.f, 0.0f/40.f, 0.0f/80.f));
				ui_render->SetTexture(ui_hold_point_timer_blue);
				ui_render->DrawWindow(Core::Rectangle(bg_x+167+52,bg_y,bg_x+167+52+8+147,bg_y+80),Core::Rectangle(0,0,12,0),Core::Rectangle(0.0f/40.f, 0.0f/80.f, 12.0f/40.f, 0.0f/80.f));

				if (is_novice_holdpoint_ok && zd_red_showtime <= 0.f)
				{
					ui_render->SetTexture(ui_hold_point_info_bg_border);
					ui_render->DrawWindow(Core::Rectangle(bg_x+167,bg_y,bg_x+167+52,bg_y+80),Core::Rectangle(0,0,0,0),Core::Rectangle(0, 0, 0, 0));
				}

				ui_render->DrawTextureWindow(Core::Vector2(bg_x+138*(1-fP), bg_y+18), 44, 60, ui_hold_point_timer2_red,Core::Rectangle(0,0,1,1));
				tempbuf.format("%d:%02d",timeminute > 0 ? timeminute : 0, timesecond > 0 ? timesecond : 0);
				ui_render->DrawFontWindow(Core::Vector2(bg_x+7+138*(1-fP), bg_y+59), 100, 14, ui_render->font_simhei_14, Core::ARGB(252, 235, 198), Core::ARGB(0, 255, 255, 255), tempbuf, Unit::kAlignLeftMiddle);

				ui_render->DrawTextureWindow(Core::Vector2(bg_x+167+69+138-27, bg_y+18), 44, 60, ui_hold_point_timer2_blue,Core::Rectangle(0,0,1,1));
				tempbuf.format("0:10");
				ui_render->DrawFontWindow(Core::Vector2(bg_x+167+69+138-27+7, bg_y+59), 100, 14, ui_render->font_simhei_14, Core::ARGB(252, 235, 198), Core::ARGB(0, 255, 255, 255), tempbuf, Unit::kAlignLeftMiddle);

				if (gLevel->team_timer[0] <= 0.f && is_novice_holdpoint_ok)
				{
					gLevel->novice_index = 23;
					gLevel->novice_timer = 6.f;
					gLevel->novice_need_timer = true;
				}
			}
			break;
		case 23:
			{
				world = Core::Matrix44::kIdentity;
				world.SetTranslationXYZ(rt_size.x/2, rt_size.y, 0);
				ui_render->SetWorld(world);
				
				world = Core::Matrix44::kIdentity;
				ui_rotate += Core::Task::GetFrameTime() * 50;
				Matrix44 world1, world2;
				world1.SetRotationQuaternion(Quaternion(Vector3(0,0,1),ui_rotate * DEG2RAD));
				world2.SetTranslationXYZ(rt_size.x/2, rt_size.y/2,0);
				world = world1 * world2;
				ui_render->SetWorld(world);
				float theta = Core::Sin(Task::GetTotalTime()*8);
				theta = 0.5 + 0.5*theta;
				ui_render->DrawTextureWindow(Core::Vector2(-516/2, -516/2), 516, 516, ui_novice_guang,Core::Rectangle(0,0,1,1),Core::ARGB(100 + 155*theta,255,255,255));

				world = Core::Matrix44::kIdentity;

 				Matrix44 view,oldview;

				float scale = 1;
				zd_novice_time += Core::Task::GetFrameTime();
				novice_anim.scale_spline.Interpolation(zd_novice_time, scale);

				world.ScaleXYZ(scale, scale, 1);
				world.Translate(Vector3(rt_size.x/2, rt_size.y/2,0));
				world.TranslateXYZ(0, -0.5f, 0);
				ui_render->SetWorld(world);

				ui_render->DrawTextureWindow(Core::Vector2(-240, -80), 480, 160, ui_novice_pass,Core::Rectangle(0,0,1,1),Core::ARGB(255,255,255,255));

				ui_render->SetView(oldview);
			}
			break;
		default:
			break;
		}
	}
}

Vector3 InGameUINew::CalcNewPosition(const Vector3 &start, const Vector3 &end)
{
	Vector3 newPos = end;
	Vector3 direction = end - start;
	float len_old = direction.Length();
	direction.Normalize();

	//hack
	float len_new = direction.Length();

	if (len_new < 0.95 || len_new > 1.05)
		return Vector3(0,0,0);

	uint group_id = 0;
	group_id |= 1 << PhysxSystem::kStatic;
	group_id |= 1 << PhysxSystem::kStaticRaycast;

	NxRay ray;
	ray.orig = (const NxVec3 &)start;
	ray.dir = (const NxVec3 &)direction;

	float distance = 500;
	NxRaycastHit hit;

	if (gPhysxScene)
	{
		NxShape* shape = gPhysxScene->raycastClosestShape(ray, NX_ALL_SHAPES, hit, group_id, distance);
		if (shape && len_old > hit.distance)
		{
			newPos = (const Vector3 &)hit.worldImpact;
		}
	}

	//LogSystem.WriteLinef("%f, %f, %f | %f, %f, %f | %f, %f, %f | %f", start.x, start.y, start.z, end.x, end.y, end.z, hit.worldImpact.x, hit.worldImpact.y, hit.worldImpact.z, len_old - hit.distance);

	return newPos;
}

void InGameUINew::AddTipText(const Core::String& str)
{
	info_tip.Add(str);
}

void InGameUINew::OnPlayStop(by_ptr(void) sender, Core::EventArgs & e)
{
	is_Mvp = true;
	return;
}
void InGameUINew::OnPlaycardStop(by_ptr(void) sender, Core::EventArgs & e)
{
	ui_score_line++;
	Card_Play = false;
	return;
}
void InGameUINew::OnPlayBigcardStop(by_ptr(void) sender, Core::EventArgs & e)
{
	anim_picture_bigCard_Out_next->Setplay(true);
	return;
}
//������Ч���� 
void InGameUINew::OnPlaySoundBackground()
{
	if (gLevel->game_type == RoomOption::kBossMode2)
	{
		if (gLevel->audio_bossmode2_background)
		{
			FMOD_EVENT_STATE audio_state = FMOD_EVENT_DEFAULT;
			gLevel->audio_bossmode2_background->getState(&audio_state);
			if ((audio_state & FMOD_EVENT_STATE_PLAYING) != 0)
			{
				if (gGame->round_time > 61)
				{
					gLevel->audio_bossmode2_background->stop(true);
				}
			}
			else
			{
				if (gGame->round_time < 61)
				{
					gLevel->audio_bossmode2_background->start();
				}
			}
		}
		return;
	}
	if (gLevel->game_type == RoomOption::kItemMode)
	{
		if (gLevel->audio_killing_background)
		{
			FMOD_EVENT_STATE audio_state = FMOD_EVENT_DEFAULT;
			gLevel->audio_killing_background->getState(&audio_state);
			if ((audio_state & FMOD_EVENT_STATE_PLAYING) != 0)
			{
				//if ((int)gLevel->rule_value - (int)gGame->scores->team_kills[0] > 15 || (int)gLevel->rule_value - (int)gGame->scores->team_kills[1] > 15 )
				//{
				//	gLevel->audio_killing_background->stop(true);
				//}
			}
			else
			{
				if ((int)gLevel->rule_value - (int)gGame->scores->team_kills[0] == 15 || (int)gLevel->rule_value - (int)gGame->scores->team_kills[1] == 15 )
				{
					gLevel->audio_killing_background->start();
					m_Showmiddle_str_time = 4.0f;
					m_Middle_str = gLang->GetTextW(L"����ɱ¾ʱ�̣�������ұ���ɱ¾���ģ���");
					gLevel->AddHorn(gLang->GetTextW(L"����ɱ¾ʱ�̣�������ұ���ɱ¾���ģ���"));
				}
			}
		}
		return;
	}
	if (gLevel->game_type == RoomOption::kAdvenceMode)
	{
		if (gLevel->audio_chrismas_background)
		{
			FMOD_EVENT_STATE audio_state = FMOD_EVENT_DEFAULT;
			gLevel->audio_chrismas_background->getState(&audio_state);
			gLevel->audio_chrismas_background->start();
		}
		return;
	}

	if (!gLevel->audio_background)
	{
		return;
	}
	float vehice_red = 0.0f, vehice_blue = 0.0f;
	int team1 = 0;
	int team2 = 0;
	int life = 0;
	Character * boss;
	float boss_hp = 0.0f;
	tempc_ptr(Character) laoda_1;
	tempc_ptr(Character) laoda_2;
	float fSc_1;
	float fSc_2;

	FMOD_EVENT_STATE audio_state = FMOD_EVENT_DEFAULT;
	gLevel->audio_background->getState(&audio_state);
	if ((audio_state & FMOD_EVENT_STATE_PLAYING) != 0)
	{
		switch (gLevel->game_type)
		{
		case RoomOption::kTeam:
			//str.format(gLang->GetTextW(L"ģʽ : �ŶӾ���"));
			if ((int)gLevel->rule_value - (int)gGame->scores->team_kills[0] > 10 && (int)gLevel->rule_value - (int)gGame->scores->team_kills[1] > 10 )
			{
				gLevel->audio_background->stop(true);
			}
			break;
		case RoomOption::KMoonMode:
			//str.format(gLang->GetTextW(L"ģʽ : �ŶӾ���"));
			if (gLevel->team_timer[0] > 60.f && gLevel->team_timer[1] > 60.f)
			{
				gLevel->audio_background->stop(true);
			}
			break;
		case RoomOption::kAdvenceMode:
			//str.format(gLang->GetTextW(L"ģʽ : �ŶӾ���"));kAdvenceMode
			if (gLevel->team_timer[0] > 60.f && gLevel->team_timer[1] > 60.f)
			{
				gLevel->audio_background->stop(true);
			}
			break;
		case RoomOption::kSurvivalMode:
			//str.format(gLang->GetTextW(L"ģʽ : �ŶӾ���"));
			if (gLevel->team_timer[0] > 60.f && gLevel->team_timer[1] > 60.f)
			{
				gLevel->audio_background->stop(true);
			}
			break;
		case RoomOption::kHoldPoint:
			//str.format(gLang->GetTextW(L"ģʽ : ռ��ģʽ"));
			if (gLevel->team_timer[0] > 60.f && gLevel->team_timer[1] > 60.f)
			{
				gLevel->audio_background->stop(true);
			}
			break;
		case RoomOption::kPushVehicle:
			//str.format(gLang->GetTextW(L"ģʽ : �Ƴ�ģʽ"));
			vehice_red = gLevel->vehice_fPersert_red /gLevel->vehicle[0]->current_vehicle_info.total_length;
			vehice_blue = gLevel->vehice_fPersert_blue /gLevel->vehicle[1]->current_vehicle_info.total_length;
			if (vehice_red < 0.8 && vehice_blue < 0.8 )
			{
				gLevel->audio_background->stop(true);
			}
			break;
		case RoomOption::kTeamDeathMatch:
			//str.format(gLang->GetTextW(L"ģʽ : ����ģʽ"));
			for (int i = 0; i < (int)gGame->scores->teams[0].Size();++i)
			{
				Character * c = gGame->scores->teams[0][i];
				if (c && !c->IsDied())
				{
					team1++;
				}
			}
			for (int i = 0; i < (int)gGame->scores->teams[1].Size();++i)
			{
				Character * c = gGame->scores->teams[1][i];
				if (c && !c->IsDied())
				{
					team2++;
				}
			}
			if (team1 > 1 && team2 > 1)
			{
				gLevel->audio_background->stop(true);
			}
			break;
		case RoomOption::kBoss:
			//str.format(gLang->GetTextW(L"ģʽ : BOSSģʽ"));
			if ((int)gGame->scores->teams[1].Size() > 0)
			{
				for (int k = 0; k < (int)gGame->scores->teams[0].Size(); k++)
				{
					Character * pp = gGame->scores->teams[0][k];
					if (pp && !pp->IsDied())
					{
						life++;
					}
				}
				boss = gGame->scores->teams[1][0];
				if ( boss->max_hp > 0)
				{
					boss_hp = (float)boss->hp / (float)boss->max_hp;
					if (life > 3 && boss_hp > 0.2)
					{
						gLevel->audio_background->stop(true);
					}
				}
			}
			break;
		case RoomOption::kKnifeMode:
			//str.format(gLang->GetTextW(L"ģʽ : ��սģʽ"));
			if ((int)gLevel->rule_value - (int)gGame->scores->team_kills[0] > 10 && (int)gLevel->rule_value - (int)gGame->scores->team_kills[1] > 10 )
			{
				gLevel->audio_background->stop(true);
			}
			break;
		case RoomOption::kStreetBoyMode:
			//str.format(gLang->GetTextW(L"ģʽ : Ӣ��ģʽ"));
			laoda_1 = gLevel->GetCharacter(gLevel->current_street_king_uid[0]);
			laoda_2 = gLevel->GetCharacter(gLevel->current_street_king_uid[1]);
			if(laoda_1&& laoda_1->GetCurCharinfo() && laoda_2 && laoda_2->GetCurCharinfo())
			{
				fSc_1 = (float)laoda_1->hp / laoda_1->max_hp;
				fSc_2 = (float)laoda_2->hp / laoda_2->max_hp;
				if (fSc_1 > 0.5 && fSc_2 > 0.5)
				{
					gLevel->audio_background->stop(true);
				}
			}
			break;
		}
	}
	else
	{
		switch (gLevel->game_type)
		{
		case RoomOption::kTeam:
			//str.format(gLang->GetTextW(L"ģʽ : �ŶӾ���"));
			if ((int)gLevel->rule_value - (int)gGame->scores->team_kills[0] <= 10 || (int)gLevel->rule_value - (int)gGame->scores->team_kills[1] <= 10 )
			{
				gLevel->audio_background->start();
			}
			break;
		case RoomOption::KMoonMode:
			if (gLevel->team_timer[0] <= 60.f || gLevel->team_timer[1] <= 60.f)
			{
				gLevel->audio_background->start();
			}
			break;
		case RoomOption::kAdvenceMode:
			if (gLevel->team_timer[0] <= 60.f || gLevel->team_timer[1] <= 60.f)
			{
				gLevel->audio_background->start();
			}
			break;
		case RoomOption::kSurvivalMode:
			if (gLevel->team_timer[0] <= 60.f || gLevel->team_timer[1] <= 60.f)
			{
				gLevel->audio_Survival_background->start();

			}
			break;
		case RoomOption::kHoldPoint:
			//str.format(gLang->GetTextW(L"ģʽ : ռ��ģʽ"));
			if (gLevel->team_timer[0] <= 60.f || gLevel->team_timer[1] <= 60.f)
			{
				gLevel->audio_background->start();
			}
			break;
		case RoomOption::kPushVehicle:
			//str.format(gLang->GetTextW(L"ģʽ : �Ƴ�ģʽ"));
			vehice_red = gLevel->vehice_fPersert_red /gLevel->vehicle[0]->current_vehicle_info.total_length;
			vehice_blue = gLevel->vehice_fPersert_blue /gLevel->vehicle[1]->current_vehicle_info.total_length;
			if (vehice_red >= 0.8 || vehice_blue >= 0.8 )
			{
				gLevel->audio_background->start();
			}
			break;
		case RoomOption::kTeamDeathMatch:
			//str.format(gLang->GetTextW(L"ģʽ : ����ģʽ"));
			for (int i = 0; i < (int)gGame->scores->teams[0].Size();++i)
			{
				Character * c = gGame->scores->teams[0][i];
				if (c && !c->IsDied())
				{
					team1++;
				}
			}
			for (int i = 0; i < (int)gGame->scores->teams[1].Size();++i)
			{
				Character * c = gGame->scores->teams[1][i];
				if (c && !c->IsDied())
				{
					team2++;
				}
			}
			if (team1 <= 1 || team2 <= 1 )
			{
				if (!(team1 == 0 && team2 == 0))
				{
					gLevel->audio_background->start();
				}
			}
			break;
		case RoomOption::kBoss:
			//str.format(gLang->GetTextW(L"ģʽ : BOSSģʽ"));
			if ((int)gGame->scores->teams[1].Size() > 0)
			{
				for (int k = 0; k < (int)gGame->scores->teams[0].Size(); k++)
				{
					Character * pp = gGame->scores->teams[0][k];
					if (pp && !pp->IsDied())
					{
						life++;
					}
				}
				boss = gGame->scores->teams[1][0];
				if ( boss->max_hp > 0)
				{
					boss_hp = (float)boss->hp / (float)boss->max_hp;
					if (life <= 3 || boss_hp <= 0.2)
					{
						gLevel->audio_background->start();
					}
				}
			}
			break;
		case RoomOption::kKnifeMode:
			//str.format(gLang->GetTextW(L"ģʽ : ��սģʽ"));
			if ((int)gLevel->rule_value - (int)gGame->scores->team_kills[0] <= 10 || (int)gLevel->rule_value - (int)gGame->scores->team_kills[1] <= 10 )
			{
				gLevel->audio_background->start();
			}
			break;
		case RoomOption::kStreetBoyMode:
			//str.format(gLang->GetTextW(L"ģʽ : Ӣ��ģʽ"));
			laoda_1 = gLevel->GetCharacter(gLevel->current_street_king_uid[0]);
			laoda_2 = gLevel->GetCharacter(gLevel->current_street_king_uid[1]);
			if(laoda_1&& laoda_1->GetCurCharinfo() && laoda_2 && laoda_2->GetCurCharinfo())
			{
				fSc_1 = (float)laoda_1->hp / laoda_1->max_hp;
				fSc_2 = (float)laoda_2->hp / laoda_2->max_hp;
				if (fSc_1 <= 0.5 || fSc_2 <= 0.5)
				{
					gLevel->audio_background->start();
				}
			}
			break;
		//case RoomOption::kItemMode:
		//	//str.format(gLang->GetTextW(L"ģʽ : ����ģʽ"));
		//	if ((int)gLevel->rule_value - (int)gGame->scores->team_kills[0] == 15 || (int)gLevel->rule_value - (int)gGame->scores->team_kills[1] == 15 )
		//	{
		//		if (gLevel->audio_killing_background)
		//		{
		//			gLevel->audio_killing_background->stop(true);
		//		}
		//		m_Showmiddle_str_time = 4.0f;
		//		m_Middle_str = gLang->GetTextW(L"����ɱ¾ʱ�̣�������ұ���ɱ¾���ģ���");
		//		gLevel->AddHorn(gLang->GetTextW(L"����ɱ¾ʱ�̣�������ұ���ɱ¾���ģ���"));
		//	}
		//	break;
		}
	}
}

void InGameUINew::_DrawMiddleUP_String(by_ptr(UIRender) ui_render)
{
	if (m_Showmiddleup_str_time > 0.0f && m_Middleup_str)
	{
		Matrix44 oldworld;
		Matrix44 world;
		Matrix44 oldview;
		Matrix44 view;	
		float show_present = m_Showmiddleup_str_time;
		if (show_present > 1.0f)
		{
			show_present = 1.0f;
		}
		Core::Vector3 rt_size = gGame->guiSys->GetSize();
		world = Core::Matrix44::kIdentity;
		oldworld = ui_render->GetWorld();
		oldview  = ui_render->GetView();

		view.SetScaleXYZ(2.0f/rt_size.x, -2.0f/rt_size.y, 0);
		ui_render->SetView(view);
		world.SetTranslationXYZ(0, 0, 0);
		ui_render->SetWorld(world);

		ui_render->DrawStringShadow(ui_render->font_simhei_24, Core::ARGB(show_present*255,255,229,51), ARGB(show_present*255,0,0,0), Core::ARGB(0,0,0,0), Core::Rectangle(-350, -520,400, 100), m_Middleup_str.Str(), Unit::kAlignCenterMiddle);

		ui_render->SetWorld(oldworld);
		ui_render->SetView(oldview);
		m_Showmiddleup_str_time -= Task::GetFrameTime();
	}
}
void InGameUINew::_DrawMiddle_String(by_ptr(UIRender) ui_render)
{
	if (m_Showmiddle_str_time > 0.0f && m_Middle_str)
	{
		Matrix44 oldworld;
		Matrix44 world;
		Matrix44 oldview;
		Matrix44 view;	
		float show_present = m_Showmiddle_str_time;
		if (show_present > 1.0f)
		{
			show_present = 1.0f;
		}
		Core::Vector3 rt_size = gGame->guiSys->GetSize();
		world = Core::Matrix44::kIdentity;
		oldworld = ui_render->GetWorld();
		oldview  = ui_render->GetView();

		view.SetScaleXYZ(2.0f/rt_size.x, -2.0f/rt_size.y, 0);
		ui_render->SetView(view);
		world.SetTranslationXYZ(0, 0, 0);
		ui_render->SetWorld(world);
		
		ui_render->DrawStringShadow(ui_render->font_simhei_24, Core::ARGB(show_present*255,255,229,51), ARGB(show_present*255,0,0,0), Core::ARGB(0,0,0,0), Core::Rectangle(-400, 50,400, 100), m_Middle_str.Str(), Unit::kAlignCenterMiddle);

		ui_render->SetWorld(oldworld);
		ui_render->SetView(oldview);
		m_Showmiddle_str_time -= Task::GetFrameTime();
	}
	//tempc_ptr(Character) viewer = gLevel->GetViewer();
	//if(!viewer)
	//	return;
	//tempc_ptr(WeaponBase) weapon = viewer->GetWeapon();
	//if(!weapon)
	//	return;
	//tempc_ptr(WeaponInfo) killerweapon = weapon->weapon_info;
	//if(!killerweapon)
	//	return;

	//int num = 0;
	//sharedc_ptr(Level::AmmoSet) ammo_set = gLevel->character_ammoset.Get(viewer->uid, NullPtr);
	//if (ammo_set)
	//{
	//	Level::AmmoSet::Enumerator itor(*ammo_set);
	//	while (itor.MoveNext())
	//	{
	//		tempc_ptr(AmmoBase) tmpammo = itor.Value();
	//		if (tmpammo->type == kWeaponTypeAmmoStick)
	//		{
	//			num++;
	//		}
	//	}

	//	while(num>0)
	//	{
	//		//ui_render->SetTexture(ui_AmmoStick);
	//		ui_render->DrawTextureWindow(Core::Vector2(-178, 2), 30, 30, ui_AmmoStick,Core::Rectangle(0,0,1,1),Core::ARGB(255,255,255,255));
	//		num--;
	//	}
	//}
}

void InGameUINew::_DrawBottom_String(by_ptr(UIRender) ui_render)
{
	Core::ARGB str_color[2] = {Core::ARGB(255,255,90,0),Core::ARGB(255,240,180,48)};
	for (int i = 0 ; i < 2 ; i++)
	{
		if (m_ShowBottom_str_time[i] > 0.0f && m_Bottom_str[i])
		{
			Matrix44 oldworld;
			Matrix44 world;
			Matrix44 oldview;
			Matrix44 view;	
			float show_present = m_ShowBottom_str_time[i];
			if (show_present > 1.0f)
			{
				show_present = 1.0f;
			}
			Core::Vector3 rt_size = gGame->guiSys->GetSize();
			world = Core::Matrix44::kIdentity;
			oldworld = ui_render->GetWorld();
			oldview  = ui_render->GetView();

			view.SetScaleXYZ(2.0f/rt_size.x, -2.0f/rt_size.y, 0);
			ui_render->SetView(view);
			world.SetTranslationXYZ(0, rt_size.y/2, 0);
			ui_render->SetWorld(world);

			ui_render->DrawStringShadow(ui_render->font_simhei_16, Core::ARGB(show_present*str_color[i].a,str_color[i].r,str_color[i].g,str_color[i].b), ARGB(show_present*255,0,0,0), Core::ARGB(0,0,0,0), Core::Rectangle(0, -200 + 30*i,0, -200 + 30*i), m_Bottom_str[i].Str(), Unit::kAlignCenterMiddle);

			ui_render->SetWorld(oldworld);
			ui_render->SetView(oldview);
			m_ShowBottom_str_time[i] -= Task::GetFrameTime();
		}
	}
}

void InGameUINew::Commomzombie_FilterSameSkill(byte* type)
{
	for (int i = 0 ; i < commonzombie_skill.GetCount() ; i++)
	{
		SkillItem item = commonzombie_skill.GetAt(i);
		int j = 0;
		while (type[j])
		{
			if (type[j] == item.type)
			{
				commonzombie_skill.RemoveAt(i);
				i--;
				break;
			}
			j++;
		}
	}
}

void InGameUINew::OnAddSkillItem(byte type,float time)
{
	if (type >= 15)
	{
		LogSystem.WriteLinef("OnAddSkillItem  type overlength:  type = %d",type);
		return;
	}
	const Core::String  common_skill_str[15] = {"",gLang->GetTextW(L"�˺�����+10%"),gLang->GetTextW(L"�˺�����+5%"),gLang->GetTextW(L"�ƶ��ٶ�+25%"),gLang->GetTextW(L"��Ծ����+50%"),
												gLang->GetTextW(L"��������+10%"),gLang->GetTextW(L"��������+15%"),gLang->GetTextW(L"��������+20%"),gLang->GetTextW(L"����޵а�[G]ʹ��"),
												gLang->GetTextW(L"����ֵ+1000"),gLang->GetTextW(L"����ֵ+3000"),gLang->GetTextW(L"��������+100"),gLang->GetTextW(L"��������+300"),
												gLang->GetTextW(L"��ҩ+30%"),gLang->GetTextW(L"�����ǿյ�")};
	if (type > 0)
	{
		m_Showmiddle_str_time = 3.0f;
		m_Middle_str = common_skill_str[type];
	}
	if (type >= 8)
		return;
	SkillItem item;
	item.type = type;
	item.time = time;
	for (int i = 0 ; i < commonzombie_skill.GetCount() ; i++)
	{
		SkillItem item_tep = commonzombie_skill.GetAt(i);
		if (item_tep.type == type)
		{
			commonzombie_skill.SetAt(i,item);
			return;
		}
	}
	byte same_type1[2] = {1,2};
	byte same_type2[3] = {5,6,7};
	if (type == same_type1[0] || type == same_type1[1])
		Commomzombie_FilterSameSkill(same_type1
		); 
	else if (type == same_type2[0] || type == same_type2[1] || type == same_type2[2])
		Commomzombie_FilterSameSkill(same_type2);
	commonzombie_skill.Add(item);
}
void InGameUINew::OnAddItemModeItem(byte type,bool is_team , bool is_me)
{
	if (type >= 26)
	{
		return;
	}
	//-1:��, 0:�����������󣩣�1:����������С����2:�����ƶ��ٶȣ�3:�޵У�4:�Ա���5:������6:��Χ�ڶԷ�����
	//7:��Χ�ڶԷ����ң���꣩��8:��Χ�ڶԷ����ң����̣���9:��Χ�ڶԷ������ⵯ��10:������Ծ�߶ȣ�11:��Χ�ڶԷ��޷����
	//12:��Χ�ڶԷ��޷���Ծ��13:�������һ��Ч����14:������Ϊ�ڰ�����
	//15:���Լ���ȫ����٣�16:���Լ���ȫ����ң���꣩��17:���Լ���ȫ���޷���Ծ��18:���Լ���ȫ���޷�����
	Core::String  common_skill_str[26] = {gLang->GetTextW(L"��������+100%"),gLang->GetTextW(L"��������+50%"),
		gLang->GetTextW(L"�ƶ��ٶ�+50%"),gLang->GetTextW(L"�����޵�״̬��"),gLang->GetTextW(L"�㷢�����Ա�������"),gLang->GetTextW(L"�������˺ڰ�֮�У�"),
		gLang->GetTextW(L"ʹ�Է����٣�"),gLang->GetTextW(L"ʹ���˻��ҵ��߸��ŶԷ���"),gLang->GetTextW(L"ʹ���˻��ҵ��߸��ŶԷ���"),gLang->GetTextW(L"ʹ����������߸��ŶԷ���"),gLang->GetTextW(L"��Ծ�߶�+100%"),
	gLang->GetTextW(L"ʹ�Է��޷�������"),gLang->GetTextW(L"ʹ�Է��޷���Ծ��"),gLang->GetTextW(L"��������һ�ֵ��ߣ�"),gLang->GetTextW(L"������һ�����ص�����������Ϊɱ¾���ģ�\nɱ¾������2��ǿ������������2��[�ո�]����2��������[����Ҽ�]����˲��"),
	gLang->GetTextW(L"������Ҽ��٣�"),gLang->GetTextW(L"������һ��ң�"),gLang->GetTextW(L"��������޷���Ծ��"),gLang->GetTextW(L"��������޷�������"),"","","","","","",gLang->GetTextW(L"�����޵�״̬��3��󹥻��˺�+50%")};
	if (!is_team)
	{
		common_skill_str[6] = gLang->GetTextW(L"�ܵ��˼���Ч�����ƶ��ٶȼ�����");
		common_skill_str[7] = gLang->GetTextW(L"�ܵ��˻���Ч������귴ת��");
		common_skill_str[8] = gLang->GetTextW(L"�ܵ��˻���Ч�������̷�ת��");
		common_skill_str[11] = gLang->GetTextW(L"�ܵ��˷�ӡЧ�����޷�������");
		common_skill_str[12] = gLang->GetTextW(L"�ܵ��˷�ӡЧ�����޷���Ծ��");
	}
	if (!is_me)
	{
		common_skill_str[15] = gLang->GetTextW(L"�ܵ��˼���Ч�����ƶ��ٶȼ�����");
		common_skill_str[16] = gLang->GetTextW(L"�ܵ��˻���Ч������귴ת��");
		common_skill_str[17] = gLang->GetTextW(L"�ܵ��˷�ӡЧ�����޷���Ծ��");
		common_skill_str[18] = gLang->GetTextW(L"�ܵ��˷�ӡЧ�����޷�������");
	}
	if (type >= 0)
	{
		m_Showmiddle_str_time = 4.0f;
		m_Middle_str = common_skill_str[type];
	}
}

//chenji
void InGameUINew::DrawItemModeZiBao(by_ptr(UIRender) ui_render)
{
	Matrix44 oldworld;
	Matrix44 world;
	Matrix44 oldview;
	Matrix44 view;	
	Core::Vector3 rt_size = gGame->guiSys->GetSize();
	world = Core::Matrix44::kIdentity;
	oldworld = ui_render->GetWorld();
	oldview  = ui_render->GetView();

	view.SetScaleXYZ(2.0f/rt_size.x, -2.0f/rt_size.y, 0);
	ui_render->SetView(view);
	world.SetTranslationXYZ(0, 0, 0);
	ui_render->SetWorld(world);

	tempc_ptr(Character) c = gLevel->GetPlayer();
	if (c&&c->itemmode_zibao&&!c->is_item_boss)
	{
		CStrBuf<256> buff;
		buff.format("%d",(int)c->itemmode_zibao_timer);
		ui_render->DrawStringShadow(ui_render->font_simhei_48, Core::ARGB(255,255,0,0), ARGB(0,0,0,0), Core::ARGB(0,0,0,0), Core::Rectangle(-400, -200,400, -150),buff, Unit::kAlignCenterMiddle);
	}
	ui_render->SetWorld(oldworld);
	ui_render->SetView(oldview);
}

void InGameUINew::InitTDMode()
{
	ui_ingame_item_mask[0] = RESOURCE_LOAD_NEW("InGameUI/TD_mode/ig_jinzhi01.dds", true, Texture2D);
	ui_ingame_item_mask[1] = RESOURCE_LOAD_NEW("InGameUI/TD_mode/ig_cd01.dds", true, Texture2D);
	ui_ingame_item_mask[2] = RESOURCE_LOAD_NEW("InGameUI/TD_mode/ig_jinzhi01.dds", true, Texture2D);
	ui_ingame_item_mask[3] = RESOURCE_LOAD_NEW("InGameUI/TD_mode/ig_bg_keyboard_01.dds", true, Texture2D);
	ui_ingame_item_mask[4] = RESOURCE_LOAD_NEW("InGameUI/TD_mode/ig_bg_keyboard_02.dds", true, Texture2D);
	ui_ingame_item_mask[5] = RESOURCE_LOAD_NEW("InGameUI/TD_mode/ig_bg_keyboard_03.dds", true, Texture2D);
	ui_ingame_item_mask[6] = RESOURCE_LOAD_NEW("InGameUI/TD_mode/ig_bg_keyboard_04.dds", true, Texture2D);
	ui_ingame_item_mask[7] = RESOURCE_LOAD_NEW("InGameUI/TD_mode/ig_bg01.dds", true, Texture2D);

	ui_ingame_item_bg[0] = RESOURCE_LOAD_NEW("InGameUI/TD_mode/ig_kuang01.dds", true, Texture2D);
	ui_ingame_item_bg[1] = RESOURCE_LOAD_NEW("InGameUI/TD_mode/ig_kuang01.dds", true, Texture2D);
	ui_ingame_item_bg[2] = RESOURCE_LOAD_NEW("InGameUI/TD_mode/ig_kuang03.dds", true, Texture2D);
	ui_ingame_item_bg[3] = RESOURCE_LOAD_NEW("InGameUI/TD_mode/ig_kuang01.dds", true, Texture2D);
	ui_ingame_item_bg[4] = RESOURCE_LOAD_NEW("InGameUI/TD_mode/ig_kuang01.dds", true, Texture2D);
	ui_ingame_item_bg[5] = RESOURCE_LOAD_NEW("InGameUI/TD_mode/ig_kuang02.dds", true, Texture2D);

	ui_ingame_time_bg = RESOURCE_LOAD_NEW("InGameUI/TD_mode/ig_bg_jifen_01.dds", true, Texture2D);
	ui_ingame_score_bg[0] = RESOURCE_LOAD_NEW("InGameUI/TD_mode/ig_xt_red_2.dds", true, Texture2D);
	ui_ingame_score_bg[1] = RESOURCE_LOAD_NEW("InGameUI/TD_mode/ig_xt_blue_2.dds", true, Texture2D);
	ui_ingame_score_bg[2] = RESOURCE_LOAD_NEW("InGameUI/TD_mode/lb_icon_res_02.dds", true, Texture2D);

	tempc_ptr(Character) player = gLevel->GetPlayer();
	if (player)
	{
		ItemBag& bag = player->GetBag();
		InGameItemInfo* item = player->GetBagItemByIID(ITEM_CARRIER);
		m_DisplayItem[ITEM_ICON_NUM-1] = item;
		if (item)
		{
			CStrBuf<256> buf;
			buf.format("LobbyUI/ibt_icon/%s.tga", item->icon);
			ui_ingame_item_icon[ITEM_ICON_NUM-1] = RESOURCE_LOAD_NEW(buf, true, Texture2D);
		}

		ItemBag::Enumerator iter(bag);
		while(iter.MoveNext() )
		{
			if (player->ItemIsCarrier(&iter.Value() ) )
				continue;
			m_loopList.PushBack(new LinkNode<InGameItemInfo*>);
			m_loopList.Back()->data = (InGameItemInfo*)&(iter.Value() ); 
		}

		if (ITEM_ICON_NUM-1 > m_loopList.Size())
		{
			for (; m_loopList.Size()< (ITEM_ICON_NUM-1); )
			{
				m_loopList.PushBack(new LinkNode<InGameItemInfo*>);
				m_loopList.Back()->data = NULL;
			}
		}
		Core::LinkNode<InGameItemInfo*>* it = m_loopList.Front();
		for (int i = 0; i < ITEM_ICON_NUM-1 && it; ++i)
		{
			m_DisplayItem[i] = it->data;
			if (m_DisplayItem[i])
			{
				CStrBuf<256> buf;
				buf.format("LobbyUI/ibt_icon/%s.tga", m_DisplayItem[i]->icon);
				ui_ingame_item_icon[i] = RESOURCE_LOAD_NEW(buf, true, Texture2D);
			}
			it = it->GetNext();
		}
	}
}

void InGameUINew::InitEditMode()
{
	ui_ingame_info = RESOURCE_LOAD_NEW("InGameUI/TD_mode/lb_ig_squad_bg01.dds", true, Texture2D);
	ui_ingame_help = RESOURCE_LOAD_NEW("InGameUI/TD_mode/lb_ig_squad_bg02.dds", true, Texture2D);
}

void InGameUINew::_InitMoonMode()
{
	for (int i = 0;i < 5; i++)
	{
		String file_name = String::Format("InGameUI/ig_paiming_0%d.DDS",i+1);
		ui_moon_score[i] = RESOURCE_LOAD_NEW(file_name, true, Texture2D);
	}
}

void InGameUINew::InitDieBuffInfo()
{
	//die buff
	DieBuff.Clear();
	DieBuffDesc.Clear();
	//for(int i=0; i<15; ++i)
	//{
	//	String szKey =String::Format("InGameUI/item_mode/ig_itemmode_skill_head_%d.dds", i);
	//	DieBuff.PushBack(RESOURCE_LOAD_NEW(szKey, true, Texture2D));
	//	DieBuffDesc.PushBack(L"");
	//}
	//DieBuffDesc[0] =L"���ӹ����� + %d%%";
	//DieBuffDesc[1] =L"�����ƶ��ٶ� + %d%%";
	//DieBuffDesc[2] =L"������Ծ�߶� + %d%%";
	//DieBuffDesc[3] =L"�������п��� + %d%%";
	//DieBuffDesc[4] =L"�޵�";
	//DieBuffDesc[5] =L"����";
	//DieBuffDesc[6] =L"���ӱ����� + %d%%";
	//DieBuffDesc[7] =L"�Զ��ظ���ҩ + %d%%";

	const int iDieBuffCnt =(int)gLevel->die_buff_data.Size();
	for(int i=0; i<iDieBuffCnt; ++i)
	{
		String szKey =String::Format("InGameUI/item_mode/%s.dds", gLevel->die_buff_data[i].res_key.Str() );
		DieBuff.PushBack(RESOURCE_LOAD_NEW(szKey, true, Texture2D));

		String szDesc =gLevel->die_buff_data[i].res_desc;
		DieBuffDescString oDesc;
		int iSize =UTF8toUTF16((U8*)szDesc.Str(), -1, 0, 0);
		if(iSize>0 && iSize<=(DieBuffDescString::MAX_LENGTH+1)){
			UTF8toUTF16((U8*)szDesc.Str(), -1, (U16*)oDesc.Desc, DieBuffDescString::MAX_LENGTH+1);
		}
		DieBuffDesc.PushBack(oDesc);
	}
}

void InGameUINew::OnAddSkillBuff_Item(byte type,float time)
{
	SkillItem item;
	item.type = type;
	item.time = time;
	for (int i = 0 ; i < commonzombie_skill.GetCount() ; i++)
	{
		SkillItem item_tep = commonzombie_skill.GetAt(i);
		if (item_tep.type == type)
		{
			commonzombie_skill.SetAt(i,item);
			return;
		}
	}
	commonzombie_skill.Add(item);
}

void InGameUINew::CreateVideoButton()
{
	CStrBuf<256> buf;

	int j = 0;
	int _x = 0 , _y = 0;
	for(int i = 1 ; i <= 8; i++)
	{
		buf.format("InGameUI/skin_replay/skin_video_button0%d_down.tga",i);
		record_icon[j] = RESOURCE_LOAD_NEW(buf.buff(), true, Texture2D);

		j++;
		buf.format("InGameUI/skin_replay/skin_video_button0%d_normal.tga",i);
		record_icon[j] = RESOURCE_LOAD_NEW(buf.buff(), true, Texture2D);

		j++;
		buf.format("InGameUI/skin_replay/skin_video_button0%d_hover.tga",i);
		record_icon[j] = RESOURCE_LOAD_NEW(buf.buff(), true, Texture2D);

		j++;
		button[i - 1].state = 0;
		button[i - 1].rect = Core::Rectangle(_x,_y,_x + 43, _y + 43);

		_x += 44;

		button[i - 1].sub_state = false;
	}
	button_content.PushBack(8);
	button_content.PushBack(PLAY);
	button_content.PushBack(STOP);
	button_content.PushBack(PRINTSCREEN);
	
	button_content.PushBack(SLOWPLAY);
	button_content.PushBack(QUICKPLAY);
	button_content.PushBack(CHANGECAMERA);
}

void InGameUINew::_DrawPlayRecordUI(by_ptr(UIRender) render)
{
	Vector3 rt_size = gGame->guiSys->GetSize();
	Vector2 screen_size = gGame->screen->GetSize();

	Matrix44 old_world,world;

	world = render->GetWorld();
	old_world = world;


	world.SetTranslationXYZ(-20, 0, 0);
	render->SetWorld(world);

	static byte old_id;

	int _x = -44 * 7 / 2;
	for(int i = 1; i <= 7 ; i++)
	{
	
		int id = button_content[i - 1];

		if(id == InGameUINew::CHANGECAMERA)
			continue;

		Core::Rectangle rect = button[i - 1].rect;

		rect.Min.x = (rect.Min.x + rt_size.x / 2 + _x);
		rect.Max.x = (rect.Min.x + 44);

		rect.Min.y = (rect.Min.y + rt_size.y - 42);
		rect.Max.y = (rect.Min.y + 44);

		if(button[i - 1].state == 0)
			render->SetTexture(record_icon[(id - 1) * 3 + 2]);
		if(button[i - 1].state == 1)
			render->SetTexture(record_icon[(id - 1) * 3 + 1]);
		if(button[i - 1].state == 2)
			render->SetTexture(record_icon[(id - 1) * 3]);

		Core::ARGB color(255,255,255,255);
		if(id == 8 && gGame->input->IsKeyDown(KC_LCONTROL))
			color.g = color.b = 0;

		if(id != 8)
			render->DrawRectangle(rect,Core::Rectangle(0,0,1,1),color);
		//_x += 44;
	}


	render->SetWorld(old_world);
}

Vector2 InGameUINew::CalcVertAngleTextureUV()
{
	Vector3 t = gGame->camera->rotation.GetZXY();
	
	float angle_p = t.x / PI;
	angle_p = (angle_p + 1.f) / 2.f;

	return Vector2(angle_p - 0.22222f, angle_p + 0.22222f);
}

F32 InGameUINew::CalcHoriAngleTextureUV()
{
	Vector3 t = gGame->camera->rotation.GetZXY();
	return t.y;
}

void InGameUINew::SelectLeftItem()
{
	for (int i =0; i < ITEM_ICON_NUM-1; ++i)
		m_DisplayItem[i]=NULL;
	LinkNode<InGameItemInfo*>* tmp = m_loopList.Back();
	m_loopList.PopBack();
	m_loopList.PushFront(new LinkNode<InGameItemInfo*>);
	m_loopList.Front()->data = tmp->data;
	delete tmp;
	Core::LinkNode<InGameItemInfo*>* it = m_loopList.Front();
	for (int i = 0; i < ITEM_ICON_NUM-1 && it; ++i)
	{
		m_DisplayItem[i] = it->data;
		if (m_DisplayItem[i])
		{
			CStrBuf<256> buf;
			buf.format("LobbyUI/ibt_icon/%s.tga", m_DisplayItem[i]->icon);
			ui_ingame_item_icon[i] = RESOURCE_LOAD_NEW(buf, true, Texture2D);
		}
		it = it->GetNext();
	}
}

void InGameUINew::SelectRightItem()
{
	for (int i =0; i < ITEM_ICON_NUM-1; ++i)
		m_DisplayItem[i]=NULL;
	LinkNode<InGameItemInfo*>* tmp = m_loopList.Front();
	m_loopList.PopFront();
	m_loopList.PushBack(new LinkNode<InGameItemInfo*>);
	m_loopList.Back()->data = tmp->data;
	delete tmp;
	Core::LinkNode<InGameItemInfo*>* it = m_loopList.Front();
	for (int i = 0; i < ITEM_ICON_NUM-1 && it; ++i)
	{
		m_DisplayItem[i] = it->data;
		if (m_DisplayItem[i])
		{
			CStrBuf<256> buf;
			buf.format("LobbyUI/ibt_icon/%s.tga", m_DisplayItem[i]->icon);
			ui_ingame_item_icon[i] = RESOURCE_LOAD_NEW(buf, true, Texture2D);
		}
		it = it->GetNext();
	}
}
