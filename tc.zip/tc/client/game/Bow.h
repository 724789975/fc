namespace Client
{
	
	struct BowInfo : GunInfo
	{
		BowInfo()
		{
			weapon_type = kWeaponTypeBow;
		}
	};


	class Bow : public GunBase
	{
	public:
		/// constrcutor
		Bow(by_ptr(BowInfo) info);

	public:
		/// initialize
		virtual void Initialize();
		
		/// active
		virtual void Active();

		/// inactive
		virtual void Inactive();

		///update
		virtual void Update(float time);

		///reload
		virtual bool Reload();

		/// get weapon type
		virtual uint GetWeaponType();

	public:
		/// fire
		virtual bool Fire();


	private:
		sharedc_ptr(BowInfo) bow_info;

		bool Can_Fire;

		float active_time;

		float reload_time;

		Core::Quaternion camerarot;

	};
}