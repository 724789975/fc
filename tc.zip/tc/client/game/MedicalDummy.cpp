#include "pch.h"
//
//namespace Client
//{
//	MedicalDummy::MedicalDummy():recover_range(-1.f)
//								,recover_check_interval(-1.f)
//								,recover_per_count_life(0)
//								,recover_timer(-1.f)
//								,recover_per_percent_ammo(0)
//	{
//
//	}
//
//	MedicalDummy::~MedicalDummy()
//	{
//
//	}
//
//	void MedicalDummy::Initialize()
//	{
//		DummyObject::Initialize();
//	}
//
//	void MedicalDummy::UpdateLogic(float frame_time)
//	{
//		if(!gLevel)
//			return;
//		
//		recover_timer -= frame_time;
//
//		if(recover_timer < 0.f)
//		{
//			recover_timer = recover_check_interval;
//
//			tempc_ptr(Character) c_owner = gLevel->GetCharacter(dummyobjectinfo->owner_id);
//			if(!c_owner)
//				return;
//
//			float recover_range_sqr = recover_range * recover_range;
//
//
//			if(gLevel->GetPlayer())
//			{
//				float len_sqr = (gLevel->GetPlayer()->GetPosition() - GetPosition()).LengthSqr();
//				if(len_sqr < recover_range_sqr)
//				{
//					if(gGame->channel_connection)
//					{
//						gGame->channel_connection->CharacterHeal(gLevel->GetPlayer()->uid, recover_per_count_life, recover_per_percent_ammo);
//					}
//				}
//			}
//			
//			const Core::Array<sharedc_ptr(Character)>& characters = gLevel->GetCharacters();
//
//			for (uint i = 0; i < characters.Size(); i++)
//			{
//				tempc_ptr(Character) c = characters[i];
//
//				if(c->GetTeam() == c_owner->GetTeam())
//				{
//					float len_sqr = (c->GetPosition() - GetPosition()).LengthSqr();
//					if(len_sqr < recover_range_sqr)
//					{
//						if(gGame->channel_connection)
//						{
//							gGame->channel_connection->CharacterHeal(c->uid, recover_per_count_life, recover_per_percent_ammo);
//						}
//					}
//				}
//			}
//		}
//				
//		
//		
//	}
//
//	bool MedicalDummy::Create(by_ptr(DummyObjectInfo) info, const DummyBaseCreateInfo& create_info)
//	{
//		dummyobjectinfo = info;
//		recover_range = create_info.recover_range;
//		recover_check_interval = create_info.recover_check_interval;
//		recover_per_count_life = create_info.recover_per_count_life;
//		recover_per_percent_ammo = create_info.recover_per_percent_ammo;
//	
//		type = DUMMY_MEDICAL;
//		return true;
//	}
//
//}