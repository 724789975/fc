namespace Client
{
	struct SniperGunInfo : GunInfo
	{
		float sight_normal_offset;
		float sight_onair_offset;
		float sight_move_offset;
		float move_speed_offset_x0;
		float move_speed_offset_x1;
		float move_speed_offset_x2;
		float readytime;

		SniperGunInfo()
		{
			weapon_type = kWeaponTypeSniperGun;
			sight_normal_offset = 0;
			sight_onair_offset = 0.85f;
			sight_move_offset = 0.35f;

			readytime = 2.f;
		}
	};

	class SniperGun : public GunBase
	{

	public:
		/// constrcutor
		SniperGun(by_ptr(SniperGunInfo) info);

	public:
		///update
		virtual void Update(float time);

		///reload
		virtual bool Reload();

		/// initialize
		virtual void Initialize();

		/// active
		virtual void Active();

		/// inactive
		virtual void Inactive();

		/// get weapon type
		virtual uint GetWeaponType();

		/// draw crosshair
		virtual void DrawCrossHair(by_ptr(UIRender) ui_render);

	public:
		/// fire
		virtual bool Fire();

		/// Special abilities
		virtual void SpecialAbilities(bool keydown = false);

		/// set sight
		virtual void SetSight(int id);

	private:
		void ChargeFlash(float min_Value, float in_value=1.f, float out_value=1.f, float max_Value=255.f);

	private:
		float charge_time;
		float alpha_value;
		bool  fadein;

		float X0Speed;
		float X1Speed;
		float X2Speed;

	public:
		FMOD::Event * gun_audio_energy_2d;
	};
}