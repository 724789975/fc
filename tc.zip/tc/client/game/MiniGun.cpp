#include "pch.h"

using namespace Core;
using namespace Client;

#define EPSINON 0.0001f

DEFINE_PDE_TYPE_CLASS(Client::MiniGunInfo)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Client::RifleInfo);

		ADD_PDE_FIELD(fire_max_speed);
		ADD_PDE_FIELD(fire_start_speed);
		ADD_PDE_FIELD(fire_aceleration);
		ADD_PDE_FIELD(fire_resistance);

		ADD_PDE_DEFAULT_CONSTRUCTOR();
	}
};


DEFINE_PDE_TYPE_CLASS(Client::MiniGun)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Client::GunBase);

		ADD_PDE_PROPERTY_R(weapon_info);
	}
};

REGISTER_PDE_TYPE(Client::MiniGunInfo);
REGISTER_PDE_TYPE(Client::MiniGun);

namespace Client
{
	MiniGun::MiniGun(by_ptr(MiniGunInfo) info)
	{
		weapon_info = gun_info = mini_info = info;

		IsCanFire = false;

		current_speed = 0.0f;
		ratio_speed = 0.0f;

	}

	void MiniGun::Initialize()
	{		
		GunBase::Initialize();

		animation_blend = ptr_new AnimationNodeBlend(skeleton);

		animation_gun = ptr_new AnimationNodeCustom(skeleton);
		animation_gun->SetAnimationSet(animation_set);

		sharedc_ptr(BlendInfo) blend_info = ptr_new BlendInfo;
		blend_info->node = animation_gun;
		blend_info->map = ptr_new SkeletonMap(skeleton);
		blend_info->map->AddJoint("Gun_BL", false, SkeletonMap::kAddtive);
		animation_blend->AddNodeByInfo(blend_info);

		blend_info = ptr_new BlendInfo;
		blend_info->node = animation;
		blend_info->map = ptr_new SkeletonMap(skeleton);
		blend_info->map->AddJoint("Gun_RV", false);
		animation_blend->AddNodeByInfo(blend_info);
	}

	/// can active
	bool MiniGun::CanActive()
	{
		return GunBase::CanActive();
	}

	/// active
	void MiniGun::Active()
	{
		GunBase::Active();

		IsCanFire = false;

		current_speed = 0.0f;
		ratio_speed = 0.0f;

		tempc_ptr(Character) player = GetOwner();

		if(!player)
			return;
		player->fire_time_ratio = 0.0f;

		IsCanRun = false;

	}

	/// inactive
	void MiniGun::Inactive()
	{
		GunBase::Inactive();

		tempc_ptr(Character) player = GetOwner();
		if (!player)
			return;

		player->fire_time_ratio = 0.0f;

		current_speed = 0.0f;
		ratio_speed = 0.0f;
	}

	/// update
	void MiniGun::Update(float frame_time)
	{
		
	}

	/// update animation
	void MiniGun::UpdateAnimation(float time)
	{
		if (animation_blend)
			animation_blend->Update(time);
	}

	/// update mesh
	void MiniGun::UpdateMesh()
	{
		if (joint_bl_id >=0)
		{
			tempc_ptr(Pose) p = GetPose();
			
			if (p)
			{
				Transform transform = p->GetJointLocalPose(joint_bl_id);
				transform.rotation = Quaternion(Vector3(0, 0, -1), -current_speed);
				p->SetJointLocalPose(joint_bl_id, transform);
			}
		}

		int old_id = joint_bl_id;
		joint_bl_id = -1;

		GunBase::UpdateMesh();

		joint_bl_id = old_id;
	}

	/// get pose
	tempc_ptr(Pose) MiniGun::GetPose()
	{
		if (animation_blend)
		{
			tempc_ptr(Pose) animation_pose = animation_blend->GetPose();
			if (animation_pose)
				return animation_pose;
		}

		return pose;
	}

	/// get weapon type
	uint MiniGun::GetWeaponType()
	{
		return kWeaponTypeMiniGun;
	}

	/// fire
	bool MiniGun::Fire()
	{
		tempc_ptr(Character) player = GetOwner();

		if (!player)
			return false;

		float spread = 0;

		if(!IsCanFire)
			return true;

		if (!player->IsOnGround())
			spread = mini_info->onair_offset + mini_info->onair_factor * accuracy;
		else if (player->IsMoving())
			spread = mini_info->move_offset + mini_info->move_factor * accuracy;
		else
			spread = mini_info->normal_factor * accuracy;

		

		if (!FireBase(spread))
			return false;

		if (player->IsMoving())
			KickBack (mini_info->move_up_base, mini_info->move_lateral_base, mini_info->move_up_modifier, mini_info->move_lateral_modifier, mini_info->move_up_max, mini_info->move_lateral_max, mini_info->move_dir_change);
		else if (!player->IsOnGround())
			KickBack (mini_info->onair_up_base, mini_info->onair_lateral_base, mini_info->onair_up_modifier, mini_info->onair_lateral_modifier, mini_info->onair_up_max, mini_info->onair_lateral_max, mini_info->onair_dir_change);
		else if (player->GetCrouch())
			KickBack (mini_info->crouch_up_base, mini_info->crouch_lateral_base, mini_info->crouch_up_modifier, mini_info->crouch_lateral_modifier, mini_info->crouch_up_max, mini_info->crouch_lateral_max, mini_info->crouch_dir_change);
		else
			KickBack (mini_info->normal_up_base, mini_info->normal_lateral_base, mini_info->normal_up_modifier, mini_info->normal_lateral_modifier, mini_info->normal_up_max, mini_info->normal_lateral_max, mini_info->normal_dir_change);

		return true;
	}

}