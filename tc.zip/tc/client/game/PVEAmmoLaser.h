namespace Client
{
	struct PVEAmmoLaserInfo : public Core::Object
	{
		Core::Identifier mesh[MESH_LOD_LEVEL];
		Core::Identifier skeleton;

		float last_time;
		float fire_distance;
		float hit_interval;
		float fillammotime;
		float scale_begin;
		float scale_end;
		int hit_damage;
		Core::Vector3 scale;

		Core::Identifier bright_particle;
		Core::Identifier fillammo_particle;
		Core::Identifier hit_decal;
		Core::Identifier fillammo_sound;
		Core::Identifier fire_sound;

		Core::Array<BoxDesc> boxdescs;
		Core::Array<CapsuleDesc> capsuledescs;

		PVEAmmoLaserInfo()
		{
			last_time = 1;
			fire_distance = 400;
			hit_interval = 1;
		}
		void SetMesh(const Core::Identifier & value, const U32 lod_level = 0);

		void AddBoxDesc(by_ptr(BoxDesc) desc)
		{
			boxdescs.PushBack(*desc);
		}

		void AddCapsuleDesc(by_ptr(CapsuleDesc) desc)
		{
			capsuledescs.PushBack(*desc);
		}
	};

	class SkinMesh;
	class PVEAmmoLaser : public Core::Object
	{
	public:
		PVEAmmoLaser();

		~PVEAmmoLaser();

	public:
		/// initialize
		bool Initialize(U16 ammo_id, by_ptr(PVEAmmoLaserInfo) ammo_info, by_ptr(Character) owner);

		/// update
		void Update(float frame_time);

		/// on render
		void OnRender(float frame_time);

		/// timestep update
		void TimeStepUpdate(float frame_time);

		/// draw
		void Draw(Primitive::DrawType drawtype, bool immediate = false);

	public:
		void CreatePhysx(int group, const Core::Vector3 &pos, const Core::Quaternion &rot);

		void ReleasePhysx();

		void StopPhysx();

		/// is dead
		bool IsDead();

		/// get id
		U16 GetId();

		/// get ammoinfo
		tempc_ptr(PVEAmmoLaserInfo) GetAmmoInfo();

		/// get position
		const Core::Vector3 & GetPosition();

		/// set position
		void SetPosition(const Core::Vector3 & pos);

		/// move position
		void MovePosition(const Core::Vector3 & pos);

		/// get rotation
		const Core::Quaternion & GetRotation();

		/// set rotation
		void SetRotation(const Core::Quaternion & rot);

		/// move rotation
		void MoveRotation(const Core::Quaternion & rot);

		/// fire
		void Fire();

		/// reset
		void Reset();

	public:
		/// UpdateSyncData
		void UpdateSyncData(float frame_time);

		/// AddSyncData
		void AddSyncData(byte time, const Core::Vector3 &position, const Core::Vector3 &direction);

		/// HasSyncData
		bool HasSyncData();

	public:
		/// from nx actor
		static tempc_ptr(PVEAmmoLaser) FromNxActor(NxActor & actor);

	private:
		/// get joint info
		bool GetJointInfo(int joint_id, Core::Vector3 *pos, Core::Quaternion *rot);

	private:
		sharedc_ptr(PVEAmmoLaserInfo) m_AmmoInfo;
		tempc_ptr(Character) m_Owner;

		NxActor *m_Actor;

		U16 m_AmmoId;
		Core::HashSet<byte, float> m_HitCharacters;

		Core::Vector3 m_Position;
		Core::Quaternion m_Rotation;

		float m_SyncTime;

		sharedc_ptr(SkinMesh) m_Mesh;
		sharedc_ptr(Skeleton) m_Skeleton;
		sharedc_ptr(Pose) m_Pose;
		sharedc_ptr(AnimationSet) m_AnimationSet;

		sharedc_ptr(ParticleSystem) m_FillParticle;
		sharedc_ptr(ParticleSystem) m_BrightParticle;

		bool isfire;
		float firetime;
		float filltime;
		float hit_interval;

		FMOD::Event* m_fmod_fire01;
		FMOD::Event* m_fmod_fire02;
	};
}