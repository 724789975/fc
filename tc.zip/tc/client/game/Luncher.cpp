#include "pch.h"

using namespace Core;
using namespace Client;
//
//#define DEFINE_PDE_TYPE_CLASS(t)		DEFINE_PDE_TYPE(t, Core::PdeTypeInfo::kClass)
//#define	DEFINE_PDE_TYPE(t, k)			template<> struct TypeTraitsInternal::TypeTraits<t> : public TypeTraitsInternal::TypeTraitsBase<t, k>
//



DEFINE_PDE_TYPE_CLASS(Client::LuncherInfo)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Client::GunInfo);

		//ADD_PDE_FIELD(ammo_type);
		//ADD_PDE_FIELD(fly_speed);
		//ADD_PDE_FIELD(spread);
		//ADD_PDE_FIELD(normal_up_base);
		//ADD_PDE_FIELD(normal_up_modifier);
		//ADD_PDE_FIELD(normal_up_max);

		ADD_PDE_FIELD(reloadoneammo);
		//ADD_PDE_FIELD(maxstickcount);

		ADD_PDE_DEFAULT_CONSTRUCTOR();
	}
};

DEFINE_PDE_TYPE_CLASS(Client::Luncher)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Client::GunBase);
	}
};

REGISTER_PDE_TYPE(Client::LuncherInfo);
REGISTER_PDE_TYPE(Client::Luncher);

/// random float
static float RandomFloat(F32 x, F32 y)
{
	float r = (F32)rand() / (RAND_MAX + 1);
	float num = x + (y - x) * r;
	return num; 
}

namespace Client
{
	/// constrcutor
	Luncher::Luncher(by_ptr(LuncherInfo) info)
	: Can_Fire(false)
	, ammo_hide_timer(-1.f)
	, charge_timer(-1.f)
	, charging_state(false)
	{
		has_trajectory = true;
		weapon_info = gun_info = luncher_info = info;
	}

	Luncher::~Luncher()
	{
		if(owner && gLevel)
		{
			tempc_ptr(AmmoBase) fristammo = NullPtr;

			int stickcnt = 0;
			sharedc_ptr(Level::AmmoSet) ammo_set = gLevel->character_ammoset.Get(owner->uid, NullPtr);

			if(ammo_set)
			{
				Level::AmmoSet::Enumerator itor(*ammo_set);
				while (itor.MoveNext())
				{
					tempc_ptr(AmmoBase) tmpammo = itor.Value();
					if (tmpammo->type == kWeaponTypeAmmoStick)
					{
						tmpammo->is_dead = true;
					}
				}
			}
		}
	}

	/// initialize
	void Luncher::Initialize()
	{
		GunBase::Initialize();

		tempc_ptr(Character) player = GetOwner();

		// preload_ammo
		if (player && luncher_info && luncher_info->ammo_type != kWeaponTypeNone)
		{
			preload_ammoinfo = ptr_new AmmoInfo();
			preload_ammoinfo->sid = luncher_info->sid;
			preload_ammoinfo->color = luncher_info->color;
			preload_ammoinfo->hit_crit = luncher_info->hit_crit;
			preload_ammoinfo->attrs = luncher_info->attrs;
			preload_ammoinfo->weapon_type = (WeaponType)luncher_info->ammo_type;
			preload_ammoinfo->icon =luncher_info->icon;
			preload_ammoinfo->AddPartKey(luncher_info->ammopart_key);

			preload_ammoinfo->maxalive_time = luncher_info->maxalive_time;
			preload_ammoinfo->gravity = luncher_info->gravity;
			preload_ammoinfo->hurt = luncher_info->hurt;
			preload_ammoinfo->range = luncher_info->range;
			preload_ammoinfo->damage = luncher_info->damage;
			preload_ammoinfo->dmg_modify_timer_min = luncher_info->dmg_modify_timer_min;
			preload_ammoinfo->dmg_modify_timer_max = luncher_info->dmg_modify_timer_max;
			preload_ammoinfo->dmg_modify_min = luncher_info->dmg_modify_min;
			preload_ammoinfo->dmg_modify_max = luncher_info->dmg_modify_max;

			preload_ammoinfo->ammocontrolmode = luncher_info->ammocontrolmode;

			preload_ammoinfo->capsule_height = luncher_info->capsule_height;
			preload_ammoinfo->capsule_radius = luncher_info->capsule_radius;

			preload_ammoinfo->LoadPart();

			preload_ammo = AmmoFactory::CreateAmmo(preload_ammoinfo);
			if (preload_ammo)
				preload_ammo->Initialize(player->GetTeam(),false);
		}
	}

	/// active
	void Luncher::Active()
	{
		tempc_ptr(Character) player = GetOwner();
		if (!player)
			return;

		Can_Fire = true;

		GunBase::Active();
	}

	/// inactive
	void Luncher::Inactive()
	{
		GunBase::Inactive();
	}

	/// get weapon type
	uint Luncher::GetWeaponType()
	{
		return luncher_info->weapon_type;
	}

	void Luncher::TryFire()
	{
		if (next_fire_time <= 0 && idle_time <= 0)
		{
			if(charging_state && luncher_info && luncher_info->ammo_charge_time_effective > 0.f && luncher_info->ammo_charge_time_max > 0.f && luncher_info->ammo_charge_time_stable > 0.f)
			{
				Fire();
			}
		}
	}

	/// fire
	bool Luncher::Fire()
	{		
		tempc_ptr(Character) player = GetOwner();

		charging_state = false;

		if (!player)
			return false;

		if(!Can_Fire)
			return false;

		if(!luncher_info)
			return false;

		float spread = luncher_info->spread;

		//��ɢ
		if(charge_timer > luncher_info->ammo_charge_time_stable && luncher_info->ammo_spread_multiple > 0.f)
		{
			float t1 = charge_timer - luncher_info->ammo_charge_time_stable;
			float t2 = luncher_info->ammo_charge_time_max - luncher_info->ammo_charge_time_stable;
			//temp
			spread += luncher_info->ammo_spread_multiple * Clamp(t1/t2, 0.f, 1.0f) ;
		}
		
		
		float hurt_rate = 1.f;
		float gravity_addon = 0.f;
		//��������
		if(charge_timer <= luncher_info->ammo_charge_time_effective)
		{
			float percent = charge_timer / luncher_info->ammo_charge_time_effective;
			hurt_rate += luncher_info->ammo_power_multiple * Clamp(percent, 0.f, 1.0f);
			gravity_addon = luncher_info->ammo_gravity_addon * Clamp(1 - percent, 0.f, 1.0f);
		}
		else
		{
			hurt_rate += luncher_info->ammo_power_multiple;
		}
		
		
		if (!FireLuncherBase(spread, hurt_rate, gravity_addon))
			return false;
		
		//KickBack
		KickBack(luncher_info->normal_up_base, 0, luncher_info->normal_up_modifier, 0, luncher_info->normal_up_max, 0, 0);
		if (luncher_info->ammo_type == kWeaponTypeAmmoMeditNeedle)
		{
			FmodSystem::PlayEvent("OTO2/weapon_2d/syringegun/shoot");
		}
		if(luncher_info->ammo_hide_time > 0.f)
		{
			SetPartVisible("mz", false);
			ammo_hide_timer = luncher_info->ammo_hide_time;
		}

		if (owner->GetWeaponById(1) == this && gLevel->game_type == RoomOption::kBossMode2 && owner->GetTeam() == 1)
		{
			owner->boss2_special_weapon_energy -= 500.f;
		}

		return true;
	}

	bool Luncher::FireLuncherBase(float spread, float hurt_rate, float gravity_addon)
	{
		tempc_ptr(Character) player = GetOwner();

		if (!player)
			return false;

		if (!gun_info || !luncher_info)
			return false;

		if (gun_info->accuracy_divisor != -1 && gun_info->accuracy_divisor != 0)
		{
			accuracy = ((shots_fired * shots_fired * shots_fired) / gun_info->accuracy_divisor) + gun_info->accuracy_offset;

			if (accuracy > gun_info->max_inaccuracy)
				accuracy = gun_info->max_inaccuracy;
		}

		if (ammo_in_clip <= 0 && weapon_info->time_to_idle <= 0)
		{
			next_fire_time = 0.4f;
			return false;
		}
		if(weapon_info->time_to_idle <= 0)
			--ammo_in_clip;
		delay_fire = true;
		++shots_fired;
		last_fire_time = 0;

		empty = false;

		Vector3 fire_pos;

		if (gGame->channel_connection && GetJointInfo(joint_fire_id, &fire_pos, NULL))
		{
			const float max_distance = 35.0f;

			Vector3 fire_angle = player->GetLookDir().GetZXY();
			fire_angle += player->punch_angle;
			camerarot = gGame->camera->rotation;
			Quaternion rot;
			rot.SetZXY(fire_angle);

			Vector3 dir = Vector3(0, 0, -1) * rot;
			Vector3 up_dir = Vector3(0, 1, 0) * rot;
			Vector3 right_dir = Vector3(1, 0, 0) * rot;

			float x, y, z;
			x = RandomFloat( -0.5, 0.5 ) + RandomFloat( -0.5, 0.5 );
			y = RandomFloat( -0.5, 0.5 ) + RandomFloat( -0.5, 0.5 );
			z = x * x + y * y;

			dir += x * spread * right_dir + y * spread * up_dir;
			dir.Normalize();

			Vector3 hit_pos = player->GetCameraPosition() + dir * max_distance;
			dir = hit_pos - fire_pos;
			dir.Normalize();

			NxRay ray;
			NxRaycastHit hit;
			NxU32 staticGroups = 0;
			staticGroups |= 1 << PhysxSystem::kStatic;
			staticGroups |= 1 << PhysxSystem::kGroupVehicle;
			//staticGroups |= 1 << 
			Vector3 dispos = player->GetCameraPosition() - fire_pos;
			F32 vctlen = dispos.Length() * 2.5f + 0.2f;
			ray.orig =(const NxVec3 &) player->GetCameraPosition();
			ray.dir = (const NxVec3 &)dir;
			NxShape* shape = gPhysxScene->raycastClosestShape(ray, NX_ALL_SHAPES, hit, staticGroups, vctlen);
			if(shape > 0)
			{
				fire_pos = player->GetCameraPosition();
				//fire_pos += dir.Normalize() * hit.distance * 0.5;
				//ammoinfo->maxalive_time = 0.1f;
			}
			AmmoAddInInfo info;
			info.max_stick_ammo_count = luncher_info->maxstickcount;
			if (luncher_info->ammocontrolmode.controltype == kAmmoControlType_Lock && gLevel->targetenemy_time >= 0.f && player->is_point_emeny)
			{
				gGame->channel_connection->ProjectedAmmoOut(player->uid, preload_ammoinfo, luncher_info->ammo_type, fire_pos, dir * luncher_info->fly_speed, info, gLevel->tmpplayer);
			}
			else
			{
				
				info.hurt_rate = hurt_rate;
				info.default_fly_speed = luncher_info->fly_speed;
				info.gravity_addon = gravity_addon;
				info.is_need_addin_info = true;

				info.blood_disk_hit_count = luncher_info->ammo_blood_disk_hit_count;
				info.blood_disk_interval = luncher_info->ammo_blood_disk_interval;

				gGame->channel_connection->ProjectedAmmoOut(player->uid, preload_ammoinfo, luncher_info->ammo_type, fire_pos, dir * luncher_info->fly_speed, info, NullPtr);
			}

			
		}

		next_fire_time = gun_info->fire_time;

		return true;
	}

	//update
	void Luncher::Update(float time)
	{
		tempc_ptr(Character) player = GetOwner();
		if (!luncher_info)
			return;

		if (luncher_info->reloadoneammo)
			UpdateMode1(time);
		else
			UpdateMode2(time);

		UpdateCharge(time);

		if(ammo_hide_timer >= 0.f)
		{
			ammo_hide_timer -= time;
			if(ammo_hide_timer < 0.f)
			{
				SetPartVisible("mz", true);
			}
		}
	}

	///reload
	bool Luncher::Reload()
	{
		if (CanReload())
		{
			reloading = true;
			reload_time = gun_info->reload_time;
			if (!luncher_info->reloadoneammo)
			{
				if (animation)
					animation->PlayAction("reload", 0.0f, false, gun_info? gun_info->reload_time:0);
			}
			return true;
		}
		
		return false;
	}

	void Luncher::UpdateMode1(float time)
	{
		WeaponBase::Update(time);
		tempc_ptr(Character) player = GetOwner();
		if (!player)
			return;

		if (!gun_info)
			return;

		if (ammo_in_clip == 0 && ammo_count > 0 && !reloading && gun_info->time_to_idle <= 0)
		{
			player->Reload(); //this will call weapon->reload()
			Can_Fire = false;
		}

		if (next_fire_time > 0)
			next_fire_time -= time;

		if(wait_timer > 0.f && gun_info->thirdpersonviewer)
		{
			wait_timer -= time;
			if(wait_timer <= 0.f)
			{
				player->UnLockStateByType(kLSSelectWeapon);
				player->camera_distance = old_cameradistance;
				if(gLevel->GetViewer() == player)
					gGame->camera->control_mode = old_controlmode;
				gun_fire_particle->SetFirstPersonMode(true);
				player->first_action_on = false;
			}
		}

		if (player->first_action_on)
		{
			if(ammo_in_clip != 0 && Can_Fire)
			{
				reloading = false;
				player->reloading = false;
			}

			if (next_fire_time <= 0 && idle_time <= 0 && (gun_info->auto_fire || delay_fire == false))
			{
				if (player->CanFire())
				{
					tempc_ptr(LuncherInfo) luncher_info = ptr_dynamic_cast<LuncherInfo>(gun_info);
					if(luncher_info)
					{
						if(luncher_info->ammo_charge_time_max <= 0.f && luncher_info->ammo_charge_time_effective <= 0.f && luncher_info->ammo_charge_time_stable <= 0.f)
						{
							if(Fire())
							{
								next_fire_time = gun_info->fire_time;
								idle_time = weapon_info->time_to_idle;
								if(gun_info->thirdpersonviewer)
								{
									wait_timer = gun_info->fire_time;
									player->LockStateByType(kLSSelectWeapon);
									if( player->camera_distance < 0.5f)
										old_cameradistance = 0.f;
									else
										old_cameradistance = player->camera_distance;
									old_controlmode = gGame->camera->control_mode;
									player->camera_distance = player->GetHeight() * 2;

									if(gLevel->GetViewer() == player)
										gGame->camera->control_mode = Camera::kViewMode;
									gun_fire_particle->SetFirstPersonMode(false);
									player->SetMove(0, 0);
								}
							}
						}	
					}
					
				}
				else
					player->StopShoot();
			}
		}
		else
		{
			player->StopShoot();
			if (delay_fire)
			{
				delay_fire = false;
				if (shots_fired > 15)
				{
					shots_fired = 15;
				}
				decrease_shots_fired += 0.4f;
			}

			if (!gun_info->auto_fire)
				shots_fired = 0;

			if (shots_fired > 0)
			{
				decrease_shots_fired -= time;
				if (decrease_shots_fired < 0)
				{
					decrease_shots_fired = 0.0225f;
					shots_fired--;
				}
			}
		}

		UpdateEffect(time);
	}

	void Luncher::UpdateMode2(float time)
	{
		GunBase::Update(time);
	}

	bool Luncher::ChargeAbilities()
	{
		if(owner && owner->CanFire() && !charging_state)
		{
			if(ammo_in_clip != 0 && Can_Fire)
			{
				reloading = false;
				owner->reloading = false;
			}

			if (next_fire_time <= 0 && idle_time <= 0)
			{
				if(luncher_info && luncher_info->ammo_charge_time_max > 0.f && luncher_info->ammo_charge_time_effective > 0.f && luncher_info->ammo_charge_time_stable > 0.f)
				{
					if(ammo_in_clip > 0)
					{
						charging_state = true;
						charge_timer = 0.f;

						if (animation)
						{
							animation->PlayAction("charge", 0.0f, false, luncher_info->ammo_charge_time_max);

							CStrBuf<256> key;

							key.format("bj/weapon/2d/%s/pull", weapon_info->sound_name.Str());
							audio_pull = FmodSystem::PlayEvent(key);


						}

						return true;
					}
				}
			}
		}

		
		
		return false;
	}
	void Luncher::UpdateCharge(float delta)
	{
		if(luncher_info)
		{
			if(charging_state)
			{
				charge_timer += delta;
				if(charge_timer > luncher_info->ammo_charge_time_max)
				{
					Fire();
				}
			}
		}
	
	}

	void Luncher::SpecialAbilities( bool keydown )
	{
		tempc_ptr(Character) player = GetOwner();
		if (!player)
			return;

		if (player->weapon_select_state != Character::kWeaponReady)
			return;

		if (luncher_info)
		{
			switch(luncher_info->ammo_type)
			{
			case kWeaponTypeAmmoRocket:
				{
#if DEBUG_CMD
					if(gLevel && gLevel->pjtammo_cntrol)
#else
					if(0)
#endif
					{
						if(keydown)
						{
							if(!gLevel->player_manager->currentAmmo || gLevel->player_manager->currentAmmo->is_dead)
							{
								return;
							}

							Can_Fire = false;
							gGame->camera->rotation = camerarot;
							gLevel->SetCameraMode(Camera::kRojectControl);

							if (gLevel->player_manager->currentAmmo)
							{
								gLevel->player_manager->currentAmmo->SetEffectEnable(false);
							}
						}
						else
						{
							Can_Fire = true;
							camerarot = gGame->camera->rotation;
							gLevel->SetCameraMode(Camera::kCharacterControl);

							if (gLevel->player_manager->currentAmmo)
							{
								gLevel->player_manager->currentAmmo->SetEffectEnable(true);
							}
						}
					}
				}
				break;
			case kWeaponTypeAmmoStick:
				{
					if(gLevel && owner)
					{
						if(keydown)
						{
							tempc_ptr(AmmoBase) fristammo = NullPtr;

							int stickcnt = 0;
							sharedc_ptr(Level::AmmoSet) ammo_set = gLevel->character_ammoset.Get(owner->uid, NullPtr);
							
							if(ammo_set)
							{
								Level::AmmoSet::Enumerator itor(*ammo_set);
								while (itor.MoveNext())
								{
									tempc_ptr(AmmoBase) tmpammo = itor.Value();
									if (tmpammo->type == kWeaponTypeAmmoStick)
									{
										tmpammo->is_dead = true;
									}
								}
							}
						}
					}
				}
			default:
				break;
			}
		}
	}

	void Luncher::OnAnimationStartFPEvent(const Core::Identifier & groupname, int & index)
	{
		tempc_ptr(Character) player = GetOwner();
		if (!player)
			return;
		FirstPerson & first_person = player->GetFirstPerson();

		Core::String str = groupname;
		if (str == "rocketlauncher_reload" && luncher_info->reloadoneammo && ammo_count > 0)
		{
 			int ammo_need = gun_info->ammo_one_clip - ammo_in_clip;
			///ֻҪ��1��2�ζ�����ʼ��ʱ��Ҫ�����ڵ���RELOAD���������ù����߼�
			switch (index)
			{
			case 1:
				{
					/// for view model
					if (first_person.show_count != -1 && first_person.show_count > 1)
					{
						first_person.show_count -= 1;
					}
					/// for game
					else
					{
						if (ammo_need == 1 && ammo_count > 0)
						{
							index++;
						}
						if (animation)
						{
							CStrBuf<256> key;
							if(player->GetViewMode() == Character::kFirstPerson)
							{
								key.format("bj/weapon/2d/%s/reload", weapon_info->sound_name.Str());
								audio_reload = FmodSystem::PlayEvent(key);
							}
							//animation->PlayAction("reload", 0.0f, false, gun_info? gun_info->reload_time:0);
						}
					}
				}
				break;
			case 2:
				{
					/// for view model
					if (first_person.show_count != -1 && first_person.show_count > 1)
					{
						first_person.show_count -= 1;
						index -= 1;
					}
					else
					{
						if (animation)
						{
							CStrBuf<256> key;
							if(player->GetViewMode() == Character::kFirstPerson)
							{
								key.format("bj/weapon/2d/%s/reload", weapon_info->sound_name.Str());
								audio_reload = FmodSystem::PlayEvent(key);
							}
							//animation->PlayAction("reload", 0.0f, false, gun_info? gun_info->reload_time:0);
						}
					}
				}
				break;
			default:
				break;
			}
		}
	}

	void Luncher::OnAnimationEndFPEvent(const Core::Identifier & groupname, int & index)
	{
		tempc_ptr(Character) player = GetOwner();
		if (!player)
			return;
		FirstPerson & first_person = player->GetFirstPerson();

		Core::String str = groupname;
		if (str == "rocketlauncher_reload"  && luncher_info->reloadoneammo && ammo_count > 0)
		{
			int ammo_need = gun_info->ammo_one_clip - ammo_in_clip;

			switch (index)
			{
			case 0:
				{
					/// for view model
					if (first_person.show_count != -1 && first_person.show_count == 1)
					{
						first_person.show_count -= 1;
						index += 1;
					}
				}
				break;
			case 1:
				{
					/// for game
					if (reloading)
					{
						empty = false;
						ammo_in_clip++;
						ammo_need--;
						ammo_count--;
						player->ReloadReady(1);
						if(ammo_in_clip >= 1)
							Can_Fire = true;

						shots_fired = 0;
						decrease_shots_fired = 0;
						delay_fire = false;

						if(ammo_need <= 0 || ammo_count <= 0)
						{
							reloading = false;
							player->reloading = false;
							index += 1;
						}
					}
				}
				break;
			case 2:
				{
					/// for game
					if (reloading)
					{
						empty = false;
						ammo_in_clip++;
						ammo_need--;
						ammo_count--;
						player->ReloadReady(1);
						if(ammo_in_clip >= 1)
							Can_Fire = true;
						
						if(ammo_need <= 0 || ammo_count <= 0)
						{
							reloading = false;
							player->reloading = false;
						}
						else
						{
							index -= 1;
						}
					}
				}
				break;
			default:
				break;
			}
		}
	}

	void Luncher::OnAnimationStartTPEvent(const Core::Identifier & groupname, int & index)
	{
		tempc_ptr(Character) player = GetOwner();
		if (!player)
			return;
		ThirdPerson & third_person = player->GetThirdPerson();

		Core::String str = groupname;
		if (str == "rocketlauncher_reload" && luncher_info->reloadoneammo && ammo_count > 0)
		{
			switch (index)
			{
			case 1:
				{
					/// for view model
					if (third_person.show_count != -1 && third_person.show_count > 1)
					{
						third_person.show_count -= 1;
					}
					/// for game
					else
					{
						if (third_person.ammo_need_multianimation == 1)
							index++;
						if (animation)
						{
							if(player->GetViewMode() == Character::kThirdPerson)
							{
								CStrBuf<256> key;
								FMOD_VECTOR vel = {0, 0, 0};
								key.format("bj/weapon/3d/%s/reload", weapon_info->sound_name.Str());
								audio_reload = FmodSystem::Play3DEvent(key,(const FMOD_VECTOR &)player->GetPosition(),vel);
							}
							animation->PlayAction("reload", 0.0f, false, gun_info? gun_info->reload_time:0);
						}
					}
				}
				break;
			case 2:
				{
					/// for view model
					if (third_person.show_count != -1 && third_person.show_count > 1)
					{
						third_person.show_count -= 1;
						index -= 1;
					}
					else
					{
						if (animation)
						{
							if(player->GetViewMode() == Character::kThirdPerson)
							{
								CStrBuf<256> key;
								FMOD_VECTOR vel = {0, 0, 0};
								key.format("bj/weapon/3d/%s/reload", weapon_info->sound_name.Str());
								audio_reload = FmodSystem::Play3DEvent(key,(const FMOD_VECTOR &)player->GetPosition(),vel);
							}
							animation->PlayAction("reload", 0.0f, false, gun_info? gun_info->reload_time:0);
						}
					}
				}
				break;
			default:
				break;
			}
		}
	}

	void Luncher::OnAnimationEndTPEvent(const Core::Identifier & groupname, int & index)
	{
		tempc_ptr(Character) player = GetOwner();
		if (!player)
			return;
		ThirdPerson & third_person = player->GetThirdPerson();

		Core::String str = groupname;
		if (str == "rocketlauncher_reload" && luncher_info->reloadoneammo && ammo_count > 0)
		{
			switch (index)
			{
			case 0:
				{
					/// for view model
					if (third_person.show_count != -1 && third_person.show_count == 1)
					{
						third_person.show_count -= 1;
						index += 1;
					}
				}
				break;
			case 1:
				{
					/// for game
					if (third_person.reload_multianimation)
					{
						third_person.ammo_need_multianimation--;
						if(third_person.ammo_need_multianimation <= 0)
							index += 1;
					}
				}
				break;
			case 2:
				{
					/// for game
					if (third_person.reload_multianimation)
					{
						third_person.ammo_need_multianimation--;
						if(third_person.ammo_need_multianimation > 0)
							index -= 1;
					}
				}
				break;
			case 3:
				{
					third_person.ammo_need_multianimation = 0;
					third_person.reload_multianimation = false;
					third_person.node_data_upper->StopAction();
				}
				break;
			default:
				break;
			}
		}
	}

	Client::WeaponType Luncher::GetLuncherAmmoType()
	{
		if(luncher_info)
			return (WeaponType)(luncher_info->ammo_type);
		return kWeaponTypeNone;
	}

	bool Luncher::isReloadOneAmmo()
	{
		if(luncher_info->reloadoneammo)
			return true;
		return false;
	}

}