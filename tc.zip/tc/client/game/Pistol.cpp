#include "pch.h"

using namespace Core;
using namespace Client;

DEFINE_PDE_TYPE_CLASS(Client::PistolInfo)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Client::GunInfo);

		ADD_PDE_FIELD(up_modifier);
		ADD_PDE_FIELD(accuracy_time);
		ADD_PDE_FIELD(accuracy_time_modifier);
		ADD_PDE_FIELD(max_accuracy);
		ADD_PDE_FIELD(min_accuracy);

		ADD_PDE_DEFAULT_CONSTRUCTOR();
	}
};

REGISTER_PDE_TYPE(Client::PistolInfo);

DEFINE_PDE_TYPE_CLASS(Client::Pistol)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Client::GunBase);

		ADD_PDE_PROPERTY_R(weapon_info)
	}
};

REGISTER_PDE_TYPE(Client::Pistol);

/// constrcutor
Pistol::Pistol(by_ptr(PistolInfo) info)
{
	weapon_info = gun_info = pistol_info = info;
}

/// destructor
Pistol::~Pistol()
{
}

/// initialize
void Pistol::Initialize()
{
	GunBase::Initialize();
	accuracy = 0.92f;
}

/// active
void Pistol::Active()
{
	GunBase::Active();
	accuracy = 0.92f;

	tempc_ptr(Character) player = GetOwner();

	if(!player)
		return;
	player->fire_time_ratio = 0.0f;

}

/// inactive
void Pistol::Inactive()
{
	GunBase::Inactive();

	tempc_ptr(Character) player = GetOwner();
	if (!player)
		return;

	player->fire_time_ratio = 0.0f;

}

/// get weapon type
uint Pistol::GetWeaponType()
{
	return kWeaponTypePistol;
}

/// fire
bool Pistol::Fire()
{		
	tempc_ptr(Character) player = GetOwner();

	if (!player)
		return false;

	player->bag_flag = false;
	player->is_bag_open = false;

	shots_fired++;

	if(GetWeaponType()!=kWeaponTypeDualPistol)
	{
		if (shots_fired > 1)
			return false;
	}
	//
	// Mark the time of this shot and determine the accuracy modifier based on the last shot fired...
	if (last_fire_time > 0)
	{
		accuracy -= pistol_info->accuracy_time_modifier * (pistol_info->accuracy_time - last_fire_time);

		if (accuracy > pistol_info->max_accuracy)
			accuracy = pistol_info->max_accuracy;
		else if (accuracy < pistol_info->min_accuracy)
			accuracy = pistol_info->min_accuracy;

		last_fire_time = 0;
	}

	if (ammo_in_clip <= 0)
	{
		CStrBuf<256> key;
		key.format("o2o/weapons_2d/%s/empty", weapon_info->sound_name.Str());
		FMOD::Event* audio_event = FmodSystem::PlayEvent(key);

		next_fire_time = 0.4f;
		return false;
	}

	ammo_in_clip--;
	next_fire_time = gun_info->fire_time;
	idle_time =  weapon_info->time_to_idle;
	

	Vector3 fire_angle = player->GetLookDir().GetZXY();
	fire_angle += player->punch_angle;
	Quaternion rot;
	rot.SetZXY(fire_angle);

	float spread = 0;

	if (!player->IsOnGround())
		spread = pistol_info->onair_offset + pistol_info->onair_factor * (1 - accuracy);
	else if (player->IsMoving())
		spread = pistol_info->move_offset + pistol_info->move_factor * (1 - accuracy);
	else
		spread = pistol_info->normal_offset + pistol_info->normal_factor * (1 - accuracy);

	FireCheck(player->GetCameraPosition(), rot, spread);

	if (ammo_in_clip == 0)
		empty = true;

	/////////////////////////////////////////////////////////////////////////////////////////////
	//for novice
	if (gLevel->game_type == RoomOption::kNovice)
	{
		int tempid = -1;
		int gun_index = -1;
		if (gLevel->novice_index == 10)
		{
			gun_index = 0;
			tempid = 0;
		}
		else if(gLevel->novice_index == 13)
		{
			tempid = 1;
			gun_index = 0;
		}
		else if(gLevel->novice_index == 15)
		{
			tempid = 2;
			gun_index = 1;
		}
		if (gLevel->novice_index < 20)
		{
			tempc_ptr(Character) tempplayer = gLevel->GetPlayer();
			if (tempplayer && tempplayer->character_info && tempplayer->GetFirstPerson().GetWeapon(gun_index) == tempplayer->GetWeapon())
			{
				for (uint i = 0; i < gLevel->novice_guntarget_array.Size();++i)
				{
					if (gLevel->novice_guntarget_array[i]->guntarget_info->uid == tempplayer->character_info->career_id && gLevel->novice_guntarget_array[i]->GetID() == tempid)
					{
						if (gLevel->novice_guntarget_array[i]->CheckFire(player->GetCameraPosition(), rot, spread) && gLevel->novice_guntarget_array[i]->status == GUNTARGET_UP)
						{
							gLevel->novice_guntarget_array[i]->status = GUNTARGET_DOWN;
							gLevel->novice_shoot_num--;
						}
					}
				}
			}
		}
		else
		{
			tempc_ptr(Character) tempplayer = gLevel->GetPlayer();
			if (tempplayer && tempplayer->character_info)
			{
				for (uint i = 0; i < gLevel->novice_guntarget_array.Size();++i)
				{
					if (gLevel->novice_guntarget_array[i]->CheckFire(player->GetCameraPosition(), rot, spread) && gLevel->novice_guntarget_array[i]->status == GUNTARGET_UP)
					{
						gLevel->novice_guntarget_array[i]->status = GUNTARGET_DOWN;
					}
				}
			}
		}
	}
	/////////////////////////////////////////////////////////////////////////////////////////////

	Vector3 angle = player->punch_angle * RAD2DEG;
	angle.x += pistol_info->up_modifier;
	player->punch_angle = angle * DEG2RAD;

	if (player->IsMoving())
		KickBack (pistol_info->move_up_base, pistol_info->move_lateral_base, pistol_info->move_up_modifier, pistol_info->move_lateral_modifier, pistol_info->move_up_max, pistol_info->move_lateral_max, pistol_info->move_dir_change);
	else if (!player->IsOnGround())
		KickBack (pistol_info->onair_up_base, pistol_info->onair_lateral_base, pistol_info->onair_up_modifier, pistol_info->onair_lateral_modifier, pistol_info->onair_up_max, pistol_info->onair_lateral_max, pistol_info->onair_dir_change);
	else if (player->GetCrouch())
		KickBack (pistol_info->crouch_up_base, pistol_info->crouch_lateral_base, pistol_info->crouch_up_modifier, pistol_info->crouch_lateral_modifier, pistol_info->crouch_up_max, pistol_info->crouch_lateral_max, pistol_info->crouch_dir_change);
	else
		KickBack (pistol_info->normal_up_base, pistol_info->normal_lateral_base, pistol_info->normal_up_modifier, pistol_info->normal_lateral_modifier, pistol_info->normal_up_max, pistol_info->normal_lateral_max, pistol_info->normal_dir_change);


	if (gGame->channel_connection)
		gGame->channel_connection->KickBack(player->punch_angle);

	return true;
}