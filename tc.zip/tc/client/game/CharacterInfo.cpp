#include "pch.h"

using namespace Client;
using namespace Core;

DEFINE_PDE_TYPE_CLASS(Client::BarbetteInfo::CannonInfo)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_METHOD(SetRotationAngle);

		ADD_PDE_FIELD(offset);
		ADD_PDE_FIELD(rotation);

		ADD_PDE_DEFAULT_CONSTRUCTOR();
	}
};

DEFINE_PDE_TYPE_CLASS(Client::BarbetteInfo)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_METHOD(SetMesh);
		ADD_PDE_METHOD(SetParticle);
		ADD_PDE_METHOD(SetRotationAngle);
		ADD_PDE_METHOD(AddCannon);

		ADD_PDE_FIELD(name);

		ADD_PDE_FIELD(skeleton);
		ADD_PDE_FIELD(size);

		ADD_PDE_FIELD(base_offset);
		ADD_PDE_FIELD(base_rotation);

		ADD_PDE_FIELD(anglelimit);
		ADD_PDE_FIELD(speedlimit);
		ADD_PDE_FIELD(firerange_min);
		ADD_PDE_FIELD(firerange_max);
		ADD_PDE_FIELD(fire_fov);
		ADD_PDE_FIELD(fire_aspect);
		ADD_PDE_FIELD(fire_particle);

		ADD_PDE_FIELD(weapon_info);

		ADD_PDE_DEFAULT_CONSTRUCTOR();
	}
};

DEFINE_PDE_TYPE_CLASS(Client::DetachablePartInfo)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_METHOD(SetMesh);
		ADD_PDE_METHOD(AddParticle);
		ADD_PDE_METHOD(SetAnimationSet);
		ADD_PDE_METHOD(AddAnimationInfo);
		ADD_PDE_METHOD(SetFirstAnimationInfo);

		ADD_PDE_FIELD(type);
		ADD_PDE_FIELD(skeleton);
		ADD_PDE_FIELD(joint);
		ADD_PDE_FIELD(size);
		ADD_PDE_FIELD(base_offset);
		ADD_PDE_FIELD(base_rotation);
		ADD_PDE_FIELD(part);
		ADD_PDE_FIELD(proportion);

		ADD_PDE_FIELD(fix_position);
		ADD_PDE_FIELD(fix_rotation);

		ADD_PDE_DEFAULT_CONSTRUCTOR();
	}
};

DEFINE_PDE_TYPE_CLASS(Client::CharacterInfo)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_METHOD(SetDetachablePartInfo);
		ADD_PDE_METHOD(SetBarbetteInfo);
		ADD_PDE_METHOD(SetMesh);
		ADD_PDE_METHOD(AddPart);
		ADD_PDE_METHOD(SetDeadParticle);

		ADD_PDE_FIELD(team);
		ADD_PDE_FIELD(res_key);
		ADD_PDE_FIELD(first_person_skeleton);
		ADD_PDE_FIELD(third_person_skeleton);
		ADD_PDE_FIELD(first_person_animationset);
		ADD_PDE_FIELD(third_person_animationset);

		ADD_PDE_FIELD(first_person_sound_weapon_pickup);
		ADD_PDE_FIELD(third_person_sound_weapon_pickup);
		ADD_PDE_FIELD(first_person_sound_weapon_drop);
		ADD_PDE_FIELD(third_person_sound_weapon_drop);

		ADD_PDE_FIELD(banner_recover_particle);
		ADD_PDE_FIELD(clothes_particle);

		ADD_PDE_FIELD(third_person_dead_animation);

		ADD_PDE_DEFAULT_CONSTRUCTOR();
	}
};

REGISTER_PDE_TYPE(Client::BarbetteInfo::CannonInfo);
REGISTER_PDE_TYPE(Client::BarbetteInfo);
REGISTER_PDE_TYPE(Client::DetachablePartInfo);
REGISTER_PDE_TYPE(Client::CharacterInfo);

// constructor
BarbetteInfo::CannonInfo::CannonInfo()
{
	offset = Vector3::kZero;
	rotation = Quaternion::kIdentity;
}

// setrotationangle
void BarbetteInfo::CannonInfo::SetRotationAngle(const Core::Vector3 & zxy)
{
	rotation.SetZXY(zxy * DEG2RAD);
	rotation.Normalize();
}

// constructor
BarbetteInfo::BarbetteInfo()
{
	size = Vector3::kZero;

	base_offset = Vector3::kZero;
	base_rotation = Quaternion::kIdentity;

	firerange_min = 0;
	firerange_max = 0;
	fire_fov = 0;
	fire_aspect = 0;
}

// setmesh
void BarbetteInfo::SetMesh(const Core::Identifier & value, const U32 lod_level)
{
	if (!gRender->lod_control->HasLod() && lod_level > 0)
		return;

	mesh[lod_level] = value;
}

// setparticle
void BarbetteInfo::SetParticle(const Core::Identifier & name, const Core::Identifier & value)
{
	particles.Set(name, value);
}

// setrotationangle
void BarbetteInfo::SetRotationAngle(const Core::Vector3 & zxy)
{
	base_rotation.SetZXY(zxy * DEG2RAD);
	base_rotation.Normalize();
}

// addcannon
void BarbetteInfo::AddCannon(by_ptr(BarbetteInfo::CannonInfo) info)
{
	cannons.PushBack(info);
}

// constructor
DetachablePartInfo::DetachablePartInfo()
{
	type = kDetachablePartNormal;

	size = Vector3::kZero;

	base_offset = Vector3::kZero;
	base_rotation = Vector3::kZero;

	fix_position = 0;
	fix_rotation = 0;
}

/// setmesh
void DetachablePartInfo::SetMesh(const Core::Identifier & value, const U32 lod_level)
{
	if (!gRender->lod_control->HasLod() && lod_level > 0)
		return;

	mesh[lod_level] = value;
}

void DetachablePartInfo::SetAnimationSet(const Core::Identifier & value)
{
	prop_animationset = value;
}

void DetachablePartInfo::AddParticle(const Core::Identifier & value)
{
	if (!particles.Contains(value))
	{
		particles.PushBack(value);
	}
}

void DetachablePartInfo::AddAnimationInfo(const Core::Identifier & name, const float time, const byte force_first) 
{
	DetachAnimationInfo info;
	info.name = name;
	info.playtime = time;

	animation_info_array.Add(info);
}

void DetachablePartInfo::SetFirstAnimationInfo(const Core::Identifier & name, const float time, const byte force_first) 
{
	first_animation.name = name;
	first_animation.playtime = time;
}

void BaseCharacterInfo::AddItemInfo(SurvivalModeItemInfo & iteminfo)
{
	tempc_ptr(Character) c = gLevel->GetPlayer();
	if (c)
	{
		c->basecharacter_info->survivalbag.PushBack(iteminfo);

		if (c->basecharacter_info->survivalbag.Size () > 5)
		{
			c->basecharacter_info->survivalbag.PopFront();
		}

		Core::LinkNode<SurvivalModeItemInfo>* node = c->basecharacter_info->survivalbag.Front();
		while(node)
		{
			//LogSystem.WriteLinef("name = %s", node->data.name);
			node = node->GetNext();
		}
	}

}

void BaseCharacterInfo::DeleteItemInfo(int index)
{
	tempc_ptr(Character) c = gLevel->GetPlayer();
	if (c && c->basecharacter_info->survivalbag.Size() > 0)
	{
		Core::LinkNode<SurvivalModeItemInfo>* node = c->basecharacter_info->survivalbag.Front();
		int count = 1;
		while(node)
		{
			if (count == index)
			{	
				c->basecharacter_info->survivalbag.Remove(node);
				return;
			}
			count++;
		 	node = node->GetNext();
		}
	}
}

byte BaseCharacterInfo::GetItemInfoType(int index)
{
	tempc_ptr(Character) c = gLevel->GetPlayer();
	if (c && c->basecharacter_info->survivalbag.Size() > 0)
	{
		Core::LinkNode<SurvivalModeItemInfo>* node = c->basecharacter_info->survivalbag.Front();
		int count = 1;
		while(node)
		{
			if (count == index)
			{
				return node->data.type;
			}
			count++;
			node = node->GetNext();
		}
	}
	return 0;
}



// constructor
CharacterInfo::CharacterInfo()
: character_id(-1)
, team(0)
, run_speed(6)
, walk_speed(3)
, crouch_speed(3)
, acceleration(8)
, jump_velocity(7)
, throw_velocity(15)
{
}

CharacterInfo::CharacterInfo(CharacterInfo& info)
{
	character_id = info.character_id;
	name = info.name;

	for (S32 i = MESH_LOD_LEVEL - 1; i >= 0; i--)
	{
		MeshSet::Enumerator it(info.mesh_set_third_person[i]);

		while (it.MoveNext())
		{
			SetMesh(it.Key(), it.Value(), false, i);
		}
	}

	for (S32 i = MESH_LOD_LEVEL - 1; i >= 0; i--)
	{
		MeshSet::Enumerator it(info.mesh_set_first_person[i]);

		while (it.MoveNext())
		{
			SetMesh(it.Key(), it.Value(), true, i);
		}
	}

	{
		DetachablePartInfoSet::Enumerator it(info.detachablepartinfo_set);

		while (it.MoveNext())
		{
			SetDetachablePartInfo(it.Key(), it.Value());
		}
	}

	{
		BarbetteInfoSet::Enumerator it(info.barbetteinfo_set);

		while (it.MoveNext())
		{
			SetBarbetteInfo(it.Value());
		}
	}

	first_person_skeleton = info.first_person_skeleton;
	third_person_skeleton = info.third_person_skeleton;
	first_person_animationset = info.first_person_animationset;
	third_person_animationset = info.third_person_animationset;

	first_person_sound_weapon_pickup = info.first_person_sound_weapon_pickup;
	third_person_sound_weapon_pickup = info.third_person_sound_weapon_pickup;

	first_person_sound_weapon_drop = info.first_person_sound_weapon_drop;
	third_person_sound_weapon_drop = info.third_person_sound_weapon_drop;

	team = info.team;

	run_speed = info.run_speed;
	walk_speed = info.walk_speed;
	crouch_speed = info.crouch_speed;
	acceleration = info.acceleration;

	jump_velocity = info.jump_velocity;
	throw_velocity = info.throw_velocity;

	costume_set = info.costume_set;
	pack_set = info.pack_set;

	third_person_dead_animation = info.third_person_dead_animation;
	third_person_dead_particles = info.third_person_dead_particles;
}

void CharacterInfo::SetDetachablePartInfo(const Identifier & key, const DetachablePartInfo & value)
{
	detachablepartinfo_set.Set(key, value);
}

void CharacterInfo::SetBarbetteInfo(by_ptr(BarbetteInfo) info)
{
	barbetteinfo_set.Set(info->name, info);
}

void CharacterInfo::SetMesh(const Identifier & key, const Identifier & value, bool use_for_first_person, const U32 lod_level)
{
	if (!gRender->lod_control->HasLod() && lod_level > 0)
		return;

	Identifier * name = mesh_set_third_person[lod_level].Get(key);
	if (name && *name == value)
		return;

	mesh_set_third_person[lod_level].Set(key, value);

	if (use_for_first_person)
		mesh_set_first_person[lod_level].Set(key, value);
		
}

void CharacterInfo::SetDeadParticle(const Core::Identifier & joint, const Core::Identifier & value, float time)
{
	CharacterParticleInfo dp;
	dp.joint = joint;
	dp.particle = value;
	dp.time = time;
	third_person_dead_particles.PushBack(dp);
}

void CharacterInfo::LoadDefaultAvatarByType(int avatar_type)
{
}

void CharacterInfo::AddPart(const Identifier & value)
{
	Costume &costume = costume_set.PushBack();
	costume.AddPartKey(value);

	CStrBuf<256> path;
	path.format("/character/%s%s/%s.lua",career_key.Str(), team? "_1": "_0", value.Str());

	sharedc_ptr(ScriptLua) lua = RESOURCE_LOAD(path, false, ScriptLua);

	if (lua)
	{
		lua_set.Set(lua->GetKey(), lua);

		Lua::LuaState *L = Lua::LuaState::NewState();
		L->OpenLibs();

		int top = L->GetTop();
		L->NewTable();
		L->PushPtr(PDE_TYPE_OF(Vector3)->GetConstructor());
		L->SetField(-2, "Vector3");
		L->PushPtr(PDE_TYPE_OF(Quaternion)->GetConstructor());
		L->SetField(-2, "Quaternion");
		L->PushPtr(PDE_TYPE_OF(DetachablePartInfo)->GetConstructor());
		L->SetField(-2, "DetachablePartInfo");
		L->PushPtr(ptr_static_cast<CharacterInfo>(this));
		L->SetField(-2, "character");
		L->NewTable();
		L->PushValue(Lua::GLOBALSINDEX);
		L->SetField(-2, "__index");
		L->SetMetatable(-2);

		if (L->LoadBuffer(lua->GetBuffer(), lua->GetSize(), path) == 0)
		{
			L->PushValue(top + 1);
			L->SetFenv(-2);

			if (L->DoCall(0, 0))
			{
				const char *msg = L->ToString(-1);
				if (msg) Console.WriteLine(msg);
				L->Pop(1);
			}

		}
		else
		{
			const char *msg = L->ToString(-1);
			if (msg) Console.WriteLine(msg);
			L->Pop(1);
		}
		L->SetTop(top);
		L->Close();
	}
}

void CharacterInfo::LoadPart()
{
	if (!gLevel)
		return;

	if (!gLevel->lua_state)
		return;

	Lua::LuaState *L = gLevel->lua_state;

	int top = L->GetTop();
	L->NewTable();
	L->PushPtr(PDE_TYPE_OF(Vector3)->GetConstructor());
	L->SetField(-2, "Vector3");
	L->PushPtr(PDE_TYPE_OF(Quaternion)->GetConstructor());
	L->SetField(-2, "Quaternion");
	L->PushPtr(PDE_TYPE_OF(DetachablePartInfo)->GetConstructor());
	L->SetField(-2, "DetachablePartInfo");
	L->PushPtr(ptr_static_cast<CharacterInfo>(this));
	L->SetField(-2, "character");
	L->NewTable();
	L->PushValue(Lua::GLOBALSINDEX);
	L->SetField(-2, "__index");
	L->SetMetatable(-2);

	CStrBuf<256> path;

	for (uint i = 0; i < costume_set.Size(); i++)
	{
		for (uint j = 0; j < costume_set[i].parts.Size(); j++)
		{
			path.format("/character/%s%s/%s.lua",career_key.Str(), team? "_1": "_0", costume_set[i].parts[j].Str());

			sharedc_ptr(ScriptLua) lua = RESOURCE_LOAD(path, false, ScriptLua);

			if (lua)
			{
				lua_set.Set(lua->GetKey(), lua);

				if (L->LoadBuffer(lua->GetBuffer(), lua->GetSize(), path) == 0)
				{
					L->PushValue(top + 1);
					L->SetFenv(-2);

					if (L->DoCall(0, 0))
					{
						const char *msg = L->ToString(-1);
						if (msg) Console.WriteLine(msg);
						L->Pop(1);
					}

				}
				else
				{
					const char *msg = L->ToString(-1);
					if (msg) Console.WriteLine(msg);
					L->Pop(1);
				}
			}
		}
	}
	L->SetTop(top);
}

///////////////////////////////////////////////////////
namespace Client
{
	static bool ReadBaseItemInfo(Core::BinaryNetworkReader & reader, BaseItemInfo & info)
	{
		reader.ReadInt(info.sid);
		if (info.sid)
		{
			reader.ReadInt(info.player_item_id);
		
			char str[128];
			reader.ReadString(str, sizeof(str));
			info.display_name = str;

			Core::CStrBuf<128> dis_name = info.display_name;
			gGame->global->Translate(dis_name);
			info.display_name = dis_name;

			reader.ReadString(str, sizeof(str));
			info.name = str;
		
			reader.ReadByte(info.color);
			reader.ReadByte(info.level);
			reader.ReadByte(info.star);
			reader.ReadByte(info.durable);
		
			byte size = 0;
			reader.ReadByte(size);
			info.attrs.Resize(size);
			for (byte i = 0; i < size; i++)
			{
				byte size2 = 0;
				reader.ReadByte(size2);
				AttributeList &attributelist = info.attrs[i];
				attributelist.Resize(size2);
				for (byte j = 0; j < size2; j++)
				{
					reader.ReadShort(attributelist[j].type);
					reader.ReadShort(attributelist[j].value1);
					reader.ReadShort(attributelist[j].value2);
					reader.ReadShort(attributelist[j].time);
				}
			}
		
			int size_part = 0;
			reader.ReadInt(size_part);
			for (int i = 0; i < size_part; ++i)
			{
				reader.ReadString(str, sizeof(str));

				info.AddPartKey(str);
			}			
		
			return true;
		}
	
		return false;
	}

	static void ReadWeaponInfo(Core::BinaryNetworkReader & reader, WeaponInfo & info)
	{
		if (info.weapon_type == kWeaponTypeNone)
		{
			int type;
			reader.ReadInt(type);
			info.weapon_type = (WeaponType)type;
		}

		if (info.weapon_type)
		{
			reader.ReadFloat(info.change_in_time);
			reader.ReadFloat(info.move_speed_offset);
			reader.ReadFloat(info.cross_offset);

			reader.ReadFloat(info.cross_length_base);
			reader.ReadFloat(info.cross_length_factor);
			reader.ReadFloat(info.cross_distance_base);
			reader.ReadFloat(info.cross_distance_factor);

			reader.ReadFloat(info.hit_speed);
			reader.ReadFloat(info.hit_acceleration);
			reader.ReadFloat(info.hit_distance);
			reader.ReadInt(info.hit_crit);
			reader.ReadInt(info.hit_crit_head);
			reader.ReadInt(info.damage_modifer);

			reader.ReadFloat(info.time_to_idle);

			reader.ReadInt(info.combat_power);
			reader.ReadFloat(info.hitdamage_gui);
			reader.ReadFloat(info.hitspeed_gui);

			info.LoadPart();
		}
	}

	static bool WriteBaseItemInfo(Core::BinaryNetworkStream & writer, const BaseItemInfo & info)
	{
		writer.WriteInt(info.sid);
		if (info.sid)
		{
			writer.WriteInt(info.player_item_id);
		
			writer.WriteString(info.display_name);
			writer.WriteString(info.name);
		
			writer.WriteByte(info.color);
			writer.WriteByte(info.level);
			writer.WriteByte(info.star);
			writer.WriteByte(info.durable);
		
			writer.WriteByte((byte)info.attrs.Size());
			for (uint i = 0; i < info.attrs.Size(); i++)
			{
				const AttributeList &attributelist = info.attrs[i];
				writer.WriteByte((byte)attributelist.Size());
			
				for (uint j = 0; j < attributelist.Size(); j++)
				{
					writer.WriteShort(attributelist[j].type);
					writer.WriteShort(attributelist[j].value1);
					writer.WriteShort(attributelist[j].value2);
					writer.WriteShort(attributelist[j].time);
				}
			}

			int size  = (int)info.parts.Size();
			writer.WriteInt(size);
			for (int i = 0; i < size; ++i)
				writer.WriteString(info.parts[i]);
			
			return true;
		}
	
		return false;
	}

	static void WriteWeaponInfo(Core::BinaryNetworkStream & writer, WeaponInfo & info)
	{
		if (WriteBaseItemInfo(writer, info))
		{
			writer.WriteInt(info.weapon_type);

			if (info.weapon_type)
			{
				writer.WriteFloat(info.change_in_time);
				writer.WriteFloat(info.move_speed_offset);
				writer.WriteFloat(info.cross_offset);

				writer.WriteFloat(info.cross_length_base);
				writer.WriteFloat(info.cross_length_factor);
				writer.WriteFloat(info.cross_distance_base);
				writer.WriteFloat(info.cross_distance_factor);

				writer.WriteFloat(info.hit_speed);
				writer.WriteFloat(info.hit_acceleration);
				writer.WriteFloat(info.hit_distance);
				writer.WriteInt(info.hit_crit);
				writer.WriteInt(info.hit_crit_head);
				writer.WriteInt(info.damage_modifer);

				writer.WriteFloat(info.time_to_idle);

				writer.WriteInt(info.combat_power);
				writer.WriteFloat(info.hitdamage_gui);
				writer.WriteFloat(info.hitspeed_gui);
			}
		}
	}

	static void ReadGunInfo(Core::BinaryNetworkReader & reader, GunInfo & info)
	{
		ReadWeaponInfo(reader, info);

		if (info.weapon_type)
		{
			reader.ReadInt(info.accuracy_divisor);
			reader.ReadFloat(info.accuracy_offset);
			reader.ReadFloat(info.max_inaccuracy);

			reader.ReadInt(info.penetration);
			reader.ReadInt(info.damage);

			reader.ReadFloat(info.range_modifier);
			reader.ReadFloat(info.range_start);
			reader.ReadFloat(info.range_end);

			reader.ReadFloat(info.fire_time);
			reader.ReadFloat(info.reload_time);
			//reader.ReadFloat(info.zoom_time);
			//reader.ReadFloat(info.zoom_value);

			reader.ReadInt(info.ammo_one_clip);
			info.ammo_in_clip = info.ammo_one_clip;
			reader.ReadInt(info.ammo_count);

			reader.ReadByte((byte&)info.auto_fire);

			reader.ReadFloat(info.normal_offset);
			reader.ReadFloat(info.normal_factor);
			reader.ReadFloat(info.onair_offset);
			reader.ReadFloat(info.onair_factor);
			reader.ReadFloat(info.move_offset);
			reader.ReadFloat(info.move_factor);

			int size = 0;
			reader.ReadInt(size);
			if (size > 0)
			{
				info.sight_info.Resize(size);
				for (int i = 0; i < size; i++)
				{
					reader.ReadFloat(info.sight_info[i].level);
					reader.ReadFloat(info.sight_info[i].mouse_sensitivity);
					reader.ReadFloat(info.sight_info[i].move_speed_offset);
					reader.ReadFloat(info.sight_info[i].fire_speed_factor);
					reader.ReadFloat(info.sight_info[i].kickbackscale);
				}
			}
		}
	}

	static void WriteGunInfo(Core::BinaryNetworkStream & writer, GunInfo & info)
	{
		WriteWeaponInfo(writer, info);

		if (info.weapon_type)
		{
			writer.WriteInt(info.accuracy_divisor);
			writer.WriteFloat(info.accuracy_offset);
			writer.WriteFloat(info.max_inaccuracy);

			writer.WriteInt(info.penetration);
			writer.WriteInt(info.damage);
			writer.WriteFloat(info.range_modifier);
			writer.WriteFloat(info.range_start);
			writer.WriteFloat(info.range_end);

			writer.WriteFloat(info.fire_time);
			writer.WriteFloat(info.reload_time);
			//writer.WriteFloat(info.zoom_time);
			//writer.WriteFloat(info.zoom_value);

			writer.WriteInt(info.ammo_one_clip);
			writer.WriteInt(info.ammo_count);

			writer.WriteByte((byte&)info.auto_fire);

			writer.WriteFloat(info.normal_offset);
			writer.WriteFloat(info.normal_factor);
			writer.WriteFloat(info.onair_offset);
			writer.WriteFloat(info.onair_factor);
			writer.WriteFloat(info.move_offset);
			writer.WriteFloat(info.move_factor);

			int size = info.sight_info.Size();
			writer.WriteInt(size);
			for (int i = 0; i < size; i++)
			{
				writer.WriteFloat(info.sight_info[i].level);
				writer.WriteFloat(info.sight_info[i].mouse_sensitivity);
				writer.WriteFloat(info.sight_info[i].move_speed_offset);
				writer.WriteFloat(info.sight_info[i].fire_speed_factor);
				writer.WriteFloat(info.sight_info[i].kickbackscale);
			}
		}
	}

	static void ReadRifleInfo(Core::BinaryNetworkReader & reader, RifleInfo & info)
	{
		ReadGunInfo(reader, info);

		if (info.weapon_type)
		{
			reader.ReadFloat(info.normal_up_base);
			reader.ReadFloat(info.normal_lateral_base);
			reader.ReadFloat(info.normal_up_modifier);
			reader.ReadFloat(info.normal_lateral_modifier);
			reader.ReadFloat(info.normal_up_max);
			reader.ReadFloat(info.normal_lateral_max);
			reader.ReadFloat(info.normal_dir_change);

			reader.ReadFloat(info.move_up_base);
			reader.ReadFloat(info.move_lateral_base);
			reader.ReadFloat(info.move_up_modifier);
			reader.ReadFloat(info.move_lateral_modifier);
			reader.ReadFloat(info.move_up_max);
			reader.ReadFloat(info.move_lateral_max);
			reader.ReadFloat(info.move_dir_change);

			reader.ReadFloat(info.onair_up_base);
			reader.ReadFloat(info.onair_lateral_base);
			reader.ReadFloat(info.onair_up_modifier);
			reader.ReadFloat(info.onair_lateral_modifier);
			reader.ReadFloat(info.onair_up_max);
			reader.ReadFloat(info.onair_lateral_max);
			reader.ReadFloat(info.onair_dir_change);

			reader.ReadFloat(info.crouch_up_base);
			reader.ReadFloat(info.crouch_lateral_base);
			reader.ReadFloat(info.crouch_up_modifier);
			reader.ReadFloat(info.crouch_lateral_modifier);
			reader.ReadFloat(info.crouch_up_max);
			reader.ReadFloat(info.crouch_lateral_max);
			reader.ReadFloat(info.crouch_dir_change);
		}
	}

	static void WriteRifleInfo(Core::BinaryNetworkStream & writer, RifleInfo & info)
	{
		WriteGunInfo(writer, info);

		if (info.weapon_type)
		{
			writer.WriteFloat(info.normal_up_base);
			writer.WriteFloat(info.normal_lateral_base);
			writer.WriteFloat(info.normal_up_modifier);
			writer.WriteFloat(info.normal_lateral_modifier);
			writer.WriteFloat(info.normal_up_max);
			writer.WriteFloat(info.normal_lateral_max);
			writer.WriteFloat(info.normal_dir_change);

			writer.WriteFloat(info.move_up_base);
			writer.WriteFloat(info.move_lateral_base);
			writer.WriteFloat(info.move_up_modifier);
			writer.WriteFloat(info.move_lateral_modifier);
			writer.WriteFloat(info.move_up_max);
			writer.WriteFloat(info.move_lateral_max);
			writer.WriteFloat(info.move_dir_change);

			writer.WriteFloat(info.onair_up_base);
			writer.WriteFloat(info.onair_lateral_base);
			writer.WriteFloat(info.onair_up_modifier);
			writer.WriteFloat(info.onair_lateral_modifier);
			writer.WriteFloat(info.onair_up_max);
			writer.WriteFloat(info.onair_lateral_max);
			writer.WriteFloat(info.onair_dir_change);

			writer.WriteFloat(info.crouch_up_base);
			writer.WriteFloat(info.crouch_lateral_base);
			writer.WriteFloat(info.crouch_up_modifier);
			writer.WriteFloat(info.crouch_lateral_modifier);
			writer.WriteFloat(info.crouch_up_max);
			writer.WriteFloat(info.crouch_lateral_max);
			writer.WriteFloat(info.crouch_dir_change);
		}
	}

	static void ReadPistolInfo(Core::BinaryNetworkReader & reader, PistolInfo & info)
	{
		ReadGunInfo(reader, info);

		if (info.weapon_type)
		{
			reader.ReadFloat(info.up_modifier);

			reader.ReadFloat(info.accuracy_time);
			reader.ReadFloat(info.accuracy_time_modifier);
			reader.ReadFloat(info.max_accuracy);
			reader.ReadFloat(info.min_accuracy);

			reader.ReadFloat(info.normal_up_base);
			reader.ReadFloat(info.normal_lateral_base);
			reader.ReadFloat(info.normal_up_modifier);
			reader.ReadFloat(info.normal_lateral_modifier);
			reader.ReadFloat(info.normal_up_max);
			reader.ReadFloat(info.normal_lateral_max);
			reader.ReadFloat(info.normal_dir_change);

			reader.ReadFloat(info.move_up_base);
			reader.ReadFloat(info.move_lateral_base);
			reader.ReadFloat(info.move_up_modifier);
			reader.ReadFloat(info.move_lateral_modifier);
			reader.ReadFloat(info.move_up_max);
			reader.ReadFloat(info.move_lateral_max);
			reader.ReadFloat(info.move_dir_change);

			reader.ReadFloat(info.onair_up_base);
			reader.ReadFloat(info.onair_lateral_base);
			reader.ReadFloat(info.onair_up_modifier);
			reader.ReadFloat(info.onair_lateral_modifier);
			reader.ReadFloat(info.onair_up_max);
			reader.ReadFloat(info.onair_lateral_max);
			reader.ReadFloat(info.onair_dir_change);

			reader.ReadFloat(info.crouch_up_base);
			reader.ReadFloat(info.crouch_lateral_base);
			reader.ReadFloat(info.crouch_up_modifier);
			reader.ReadFloat(info.crouch_lateral_modifier);
			reader.ReadFloat(info.crouch_up_max);
			reader.ReadFloat(info.crouch_lateral_max);
			reader.ReadFloat(info.crouch_dir_change);
		}
	}

	static void WritePistolInfo(Core::BinaryNetworkStream & writer, PistolInfo & info)
	{
		WriteGunInfo(writer, info);

		if (info.weapon_type)
		{
			writer.WriteFloat(info.up_modifier);

			writer.WriteFloat(info.accuracy_time);
			writer.WriteFloat(info.accuracy_time_modifier);
			writer.WriteFloat(info.max_accuracy);
			writer.WriteFloat(info.min_accuracy);
			writer.WriteFloat(info.normal_up_base);
			writer.WriteFloat(info.normal_lateral_base);
			writer.WriteFloat(info.normal_up_modifier);
			writer.WriteFloat(info.normal_lateral_modifier);
			writer.WriteFloat(info.normal_up_max);
			writer.WriteFloat(info.normal_lateral_max);
			writer.WriteFloat(info.normal_dir_change);

			writer.WriteFloat(info.move_up_base);
			writer.WriteFloat(info.move_lateral_base);
			writer.WriteFloat(info.move_up_modifier);
			writer.WriteFloat(info.move_lateral_modifier);
			writer.WriteFloat(info.move_up_max);
			writer.WriteFloat(info.move_lateral_max);
			writer.WriteFloat(info.move_dir_change);

			writer.WriteFloat(info.onair_up_base);
			writer.WriteFloat(info.onair_lateral_base);
			writer.WriteFloat(info.onair_up_modifier);
			writer.WriteFloat(info.onair_lateral_modifier);
			writer.WriteFloat(info.onair_up_max);
			writer.WriteFloat(info.onair_lateral_max);
			writer.WriteFloat(info.onair_dir_change);

			writer.WriteFloat(info.crouch_up_base);
			writer.WriteFloat(info.crouch_lateral_base);
			writer.WriteFloat(info.crouch_up_modifier);
			writer.WriteFloat(info.crouch_lateral_modifier);
			writer.WriteFloat(info.crouch_up_max);
			writer.WriteFloat(info.crouch_lateral_max);
			writer.WriteFloat(info.crouch_dir_change);
		}
	}

	static void ReadDualPistol(Core::BinaryNetworkReader & reader, DualPistolInfo & info)
	{
		ReadPistolInfo(reader, info);
	}

	static void WriteDualPistol(Core::BinaryNetworkStream & writer, DualPistolInfo & info)
	{
		WritePistolInfo(writer, info);
	}

	static void ReadSniperGunInfo(Core::BinaryNetworkReader & reader, SniperGunInfo & info)
	{
		ReadGunInfo(reader, info);

		if (info.weapon_type)
		{
			reader.ReadFloat(info.sight_normal_offset);
			reader.ReadFloat(info.sight_onair_offset);
			reader.ReadFloat(info.sight_move_offset);
			reader.ReadFloat(info.readytime);
		}
	}

	static void WriteSniperGunInfo(Core::BinaryNetworkStream & writer, SniperGunInfo & info)
	{
		WriteGunInfo(writer, info);

		if (info.weapon_type)
		{
			writer.WriteFloat(info.sight_normal_offset);
			writer.WriteFloat(info.sight_onair_offset);
			writer.WriteFloat(info.sight_move_offset);
			writer.WriteFloat(info.readytime);
		}
	}

	static void ReadShortGunInfo(Core::BinaryNetworkReader & reader, ShotGunInfo & info)
	{
		ReadGunInfo(reader, info);

		if(info.weapon_type)
		{
			reader.ReadInt(info.shoot_bullet_count);
			reader.ReadFloat(info.spread);
			reader.ReadFloat(info.normal_up_base);
			reader.ReadFloat(info.normal_up_modifier);
			reader.ReadFloat(info.normal_up_max);
		}
	}

	static void WriteShortGunInfo(Core::BinaryNetworkStream & writer, ShotGunInfo & info)
	{
		WriteGunInfo(writer, info);

		if(info.weapon_type)
		{
			writer.WriteInt(info.shoot_bullet_count);
			writer.WriteFloat(info.spread);
			writer.WriteFloat(info.normal_up_base);
			writer.WriteFloat(info.normal_up_modifier);
			writer.WriteFloat(info.normal_up_max);
		}
	}

	static void ReadSubMachineGunInfo(Core::BinaryNetworkReader & reader, SubMachineGunInfo & info)
	{
		ReadRifleInfo(reader, info);
	}

	static void WriteSubMachineGunInfo(Core::BinaryNetworkStream & writer, SubMachineGunInfo & info)
	{
		WriteRifleInfo(writer, info);
	}

	static void ReadMachineGunInfo(Core::BinaryNetworkReader & reader, MachineGunInfo & info)
	{
		ReadRifleInfo(reader, info);
	}

	static void WriteMachineGunInfo(Core::BinaryNetworkStream & writer, MachineGunInfo & info)
	{
		WriteRifleInfo(writer, info);
	}

	static void ReadMiniMachineGunInfo(Core::BinaryNetworkReader & reader, MiniMachineGunInfo & info)
	{
		ReadShortGunInfo(reader, info);

		if (info.weapon_type)
		{
			reader.ReadFloat(info.fire_max_speed);
			reader.ReadFloat(info.fire_start_speed);
			reader.ReadFloat(info.fire_aceleration);
			reader.ReadFloat(info.fire_resistance);
			reader.ReadFloat(info.firereadytime);

			reader.ReadInt(info.ammo_type);
			reader.ReadFloat(info.ammo_charge_time_max);
			for (int i = 0; i < 3; i++)
				reader.ReadFloat(info.fly_speed[i]);
			for (int i = 0; i < 3; i++)
				reader.ReadFloat(info.fly_speed_multiple[i]);
		
			reader.ReadFloat(info.maxalive_time);
			reader.ReadByte(info.gravity);
			reader.ReadFloat(info.hurt);
			reader.ReadString(info.ammopart_key, sizeof(info.ammopart_key));
			reader.ReadFloat(info.range);
			reader.ReadFloat(info.dmg_modify_timer_min);
			reader.ReadFloat(info.dmg_modify_timer_max);
			reader.ReadFloat(info.dmg_modify_min);
			reader.ReadFloat(info.dmg_modify_max);
			reader.ReadFloat(info.capsule_height);
			reader.ReadFloat(info.capsule_radius);
		}
	}
	static void WriteMiniMachineGunInfo(Core::BinaryNetworkStream & writer, MiniMachineGunInfo & info)
	{
		WriteShortGunInfo(writer, info);

		if (info.weapon_type)
		{
			writer.WriteFloat(info.fire_max_speed);
			writer.WriteFloat(info.fire_start_speed);
			writer.WriteFloat(info.fire_aceleration);
			writer.WriteFloat(info.fire_resistance);
			writer.WriteFloat(info.firereadytime);

			writer.WriteInt(info.ammo_type);
			writer.WriteFloat(info.ammo_charge_time_max);
			for (int i = 0; i < 3; i++)
				writer.WriteFloat(info.fly_speed[i]);
			for (int i = 0; i < 3; i++)
				writer.WriteFloat(info.fly_speed_multiple[i]);
		
			writer.WriteFloat(info.maxalive_time);
			writer.WriteByte(info.gravity);
			writer.WriteFloat(info.hurt);
			writer.WriteString(info.ammopart_key);
			writer.WriteFloat(info.range);
			writer.WriteFloat(info.dmg_modify_timer_min);
			writer.WriteFloat(info.dmg_modify_timer_max);
			writer.WriteFloat(info.dmg_modify_min);
			writer.WriteFloat(info.dmg_modify_max);
			writer.WriteFloat(info.capsule_height);
			writer.WriteFloat(info.capsule_radius);
		}
	}
	static void ReadMiniGunInfo(Core::BinaryNetworkReader & reader, MiniGunInfo & info)
	{
		ReadRifleInfo(reader, info);

		if (info.weapon_type)
		{
			reader.ReadFloat(info.fire_max_speed);
			reader.ReadFloat(info.fire_start_speed);
			reader.ReadFloat(info.fire_aceleration);
			reader.ReadFloat(info.fire_resistance);
		}
	}

	static void WriteMiniGunInfo(Core::BinaryNetworkStream & writer, MiniGunInfo & info)
	{
		WriteRifleInfo(writer, info);

		if (info.weapon_type)
		{
			writer.WriteFloat(info.fire_max_speed);
			writer.WriteFloat(info.fire_start_speed);
			writer.WriteFloat(info.fire_aceleration);
			writer.WriteFloat(info.fire_resistance);
		}
	}

	static void ReadKnifeInfo(Core::BinaryNetworkReader & reader, KnifeInfo & info)
	{
		ReadWeaponInfo(reader, info);

		if (info.weapon_type)
		{
			reader.ReadFloat(info.stab_time);
			reader.ReadFloat(info.stab_light_time);

			reader.ReadFloat(info.stab_distance);
			reader.ReadFloat(info.stab_light_distance);
			reader.ReadFloat(info.stab_width);
			reader.ReadFloat(info.back_factor);

			reader.ReadFloat(info.stab_hurt);
			reader.ReadFloat(info.stab_light_hurt);
			reader.ReadInt(info.back_boost_plus);
		}
	}

	static void WriteKnifeInfo(Core::BinaryNetworkStream & writer, KnifeInfo & info)
	{
		WriteWeaponInfo(writer, info);

		if (info.weapon_type)
		{
			writer.WriteFloat(info.stab_time);
			writer.WriteFloat(info.stab_light_time);

			writer.WriteFloat(info.stab_distance);
			writer.WriteFloat(info.stab_light_distance);
			writer.WriteFloat(info.stab_width);
			writer.WriteFloat(info.back_factor);

			writer.WriteFloat(info.stab_hurt);
			writer.WriteFloat(info.stab_light_hurt);
			writer.WriteInt(info.back_boost_plus);
		}
	}

	static void ReadThrowableInfo(Core::BinaryNetworkReader & reader, ThrowableInfo & info)
	{
		ReadWeaponInfo(reader, info);

		if (info.weapon_type)
		{
	 		reader.ReadFloat(info.explode_time);
			reader.ReadFloat(info.ready_time);
			reader.ReadFloat(info.throw_out_time);
		}
	}

	static void WriteThrowableInfo(Core::BinaryNetworkStream & writer, ThrowableInfo & info)
	{
		WriteWeaponInfo(writer, info);

		if (info.weapon_type)
		{
	 		writer.WriteFloat(info.explode_time);
			writer.WriteFloat(info.ready_time);
			writer.WriteFloat(info.throw_out_time);
		}
	}

	static void ReadGrenadeInfo(Core::BinaryNetworkReader & reader, GrenadeInfo & info)
	{
		ReadThrowableInfo(reader, info);

		if (info.weapon_type)
		{
	 		reader.ReadFloat(info.range);
			reader.ReadFloat(info.hurt);
		}
	}

	static void WriteGrenadeInfo(Core::BinaryNetworkStream & writer, GrenadeInfo & info)
	{
		WriteThrowableInfo(writer, info);

		if (info.weapon_type)
		{
	 		writer.WriteFloat(info.range);
			writer.WriteFloat(info.hurt);
		}
	}

	static void ReadFlashInfo(Core::BinaryNetworkReader & reader, FlashInfo & info)
	{
		ReadThrowableInfo(reader, info);

		if (info.weapon_type)
		{
			reader.ReadFloat(info.range_start);
			reader.ReadFloat(info.range_end);
			reader.ReadFloat(info.time_max);
			reader.ReadFloat(info.time_fade);
			reader.ReadFloat(info.back_factor);
		}
	}

	static void WriteFlashInfo(Core::BinaryNetworkStream & writer, FlashInfo & info)
	{
		WriteThrowableInfo(writer, info);

		if (info.weapon_type)
		{
			writer.WriteFloat(info.range_start);
			writer.WriteFloat(info.range_end);
			writer.WriteFloat(info.time_max);
			writer.WriteFloat(info.time_fade);
			writer.WriteFloat(info.back_factor);
		}
	}

	static void ReadSmokeInfo(Core::BinaryNetworkReader & reader, SmokeInfo & info)
	{
		ReadThrowableInfo(reader, info);

		if (info.weapon_type)
		{
			reader.ReadFloat(info.time);
		}
	}

	static void WriteSmokeInfo(Core::BinaryNetworkStream & writer, SmokeInfo & info)
	{
		WriteThrowableInfo(writer, info);

		if (info.weapon_type)
		{
			writer.WriteFloat(info.time);
		}
	}

	static void ReadGrenadeSpecialInfo(Core::BinaryNetworkReader & reader, SpecialGrenadeInfo & info)
	{
		ReadThrowableInfo(reader, info);

		if (info.weapon_type)
		{
			reader.ReadFloat(info.range);
			reader.ReadFloat(info.hurt);
		}
	}

	static void WriteGrenadeSpecialInfo(Core::BinaryNetworkStream & writer, SpecialGrenadeInfo & info)
	{
		WriteThrowableInfo(writer, info);

		if (info.weapon_type)
		{
			writer.WriteFloat(info.range);
			writer.WriteFloat(info.hurt);
		}
	}

	static void ReadLuncherInfo(Core::BinaryNetworkReader & reader, LuncherInfo & info)
	{
		ReadGunInfo(reader, info);

		if (info.weapon_type)
		{
			reader.ReadInt(info.ammo_type);
			reader.ReadFloat(info.fly_speed);
			reader.ReadFloat(info.spread);
			reader.ReadFloat(info.normal_up_base);
			reader.ReadFloat(info.normal_up_modifier);
			reader.ReadFloat(info.normal_up_max);
			reader.ReadFloat(info.maxalive_time);
			reader.ReadByte(info.gravity);
			reader.ReadFloat(info.hurt);
			reader.ReadString(info.ammopart_key, sizeof(info.ammopart_key));
			reader.ReadFloat(info.range);
			reader.ReadFloat(info.throwouttime);
			reader.ReadFloat(info.dmg_modify_timer_min);
			reader.ReadFloat(info.dmg_modify_timer_max);
			reader.ReadFloat(info.dmg_modify_min);
			reader.ReadFloat(info.dmg_modify_max);
			reader.ReadFloat(info.capsule_height);
			reader.ReadFloat(info.capsule_radius);

			// ammo hide -----------------------	
			reader.ReadFloat(info.ammo_hide_time);

			// charge shoot --------------------
			reader.ReadFloat(info.ammo_charge_time_max);
			reader.ReadFloat(info.ammo_charge_time_effective);
			reader.ReadFloat(info.ammo_charge_time_stable);

			reader.ReadFloat(info.ammo_spread_multiple);
			reader.ReadFloat(info.ammo_power_multiple);
			reader.ReadFloat(info.ammo_gravity_addon);

			reader.ReadFloat(info.ammo_blood_disk_interval);
			reader.ReadInt(info.ammo_blood_disk_hit_count);

			Attribute attrinfo;
			if (info.CheckWeaponAttribute(kWeaponAttr_Self_RocketControl,attrinfo))
			{
				info.ammocontrolmode.controltype = AmmoControlType(attrinfo.value1);
				info.ammocontrolmode.anglelimit = attrinfo.value2 / 10.f;
				info.ammocontrolmode.triggertime = attrinfo.time / 1000.f;
			}
		}
	}

	static void WriteLuncherInfo(Core::BinaryNetworkStream & writer, LuncherInfo & info)
	{
		WriteGunInfo(writer, info);

		if (info.weapon_type)
		{
			writer.WriteInt(info.ammo_type);
			writer.WriteFloat(info.fly_speed);
			writer.WriteFloat(info.spread);
			writer.WriteFloat(info.normal_up_base);
			writer.WriteFloat(info.normal_up_modifier);
			writer.WriteFloat(info.normal_up_max);
			writer.WriteFloat(info.maxalive_time);
			writer.WriteByte(info.gravity);
			writer.WriteFloat(info.hurt);
			writer.WriteString(info.ammopart_key);
			writer.WriteFloat(info.range);
			writer.WriteFloat(info.throwouttime);
			writer.WriteFloat(info.dmg_modify_timer_min);
			writer.WriteFloat(info.dmg_modify_timer_max);
			writer.WriteFloat(info.dmg_modify_min);
			writer.WriteFloat(info.dmg_modify_max);
			writer.WriteFloat(info.capsule_height);
			writer.WriteFloat(info.capsule_radius);

			// ammo hide -----------------------	
			writer.WriteFloat(info.ammo_hide_time);

			// charge shoot --------------------
			writer.WriteFloat(info.ammo_charge_time_max);
			writer.WriteFloat(info.ammo_charge_time_effective);
			writer.WriteFloat(info.ammo_charge_time_stable);

			writer.WriteFloat(info.ammo_spread_multiple);
			writer.WriteFloat(info.ammo_power_multiple);
			writer.WriteFloat(info.ammo_gravity_addon);

			writer.WriteFloat(info.ammo_blood_disk_interval);
			writer.WriteInt(info.ammo_blood_disk_hit_count);


		}
	}

	static void ReadCureGunInfo(Core::BinaryNetworkReader & reader, CureGunInfo & info)
	{
		ReadGunInfo(reader, info);

		if (info.weapon_type)
		{
			reader.ReadFloat(info.maxdistance);
			reader.ReadInt(info.addblood);
		}
	}

	static void WriteCureGunInfo(Core::BinaryNetworkStream & writer, CureGunInfo & info)
	{
		WriteGunInfo(writer, info);

		if(info.weapon_type)
		{
			writer.WriteFloat(info.maxdistance);
			writer.WriteInt(info.addblood);
		}
	}


	static void WriteFlameGunInfo(Core::BinaryNetworkStream & writer, FlameGunInfo & info)
	{
		WriteGunInfo(writer, info);

		if(info.weapon_type)
		{
			writer.WriteFloat(info.special_distance);
			writer.WriteFloat(info.special_range);
			writer.WriteFloat(info.special_lasttime);
			writer.WriteFloat(info.particlenum);
			writer.WriteFloat(info.show_speed);
			writer.WriteFloat(info.hurtrange);
		}
	}

	static void ReadFlameGunInfo(Core::BinaryNetworkReader & reader, FlameGunInfo & info)
	{
		ReadGunInfo(reader, info);

		if(info.weapon_type)
		{
			reader.ReadFloat(info.special_distance);
			reader.ReadFloat(info.special_range);
			reader.ReadFloat(info.special_lasttime);
			reader.ReadFloat(info.particlenum);
			reader.ReadFloat(info.show_speed);
			reader.ReadFloat(info.hurtrange);
		}
	}

	static void ReadAmmoInfo(Core::BinaryNetworkReader & reader, AmmoInfo & info)
	{
		ReadWeaponInfo(reader, info);

		if (info.weapon_type)
		{
			reader.ReadFloat(info.maxalive_time);
			reader.ReadByte(info.gravity);
			reader.ReadFloat(info.range);
			reader.ReadFloat(info.damage);
			reader.ReadFloat(info.dmg_modify_timer_min);
			reader.ReadFloat(info.dmg_modify_timer_max);
			reader.ReadFloat(info.dmg_modify_min);
			reader.ReadFloat(info.dmg_modify_max);

			reader.ReadFloat(info.capsule_height);
			reader.ReadFloat(info.capsule_radius);
		}
	}


	static void WriteAmmoInfo(Core::BinaryNetworkStream & writer, AmmoInfo & info )
	{
		WriteWeaponInfo(writer, info);

		if (info.weapon_type)
		{
			writer.WriteFloat(info.maxalive_time);
			writer.WriteByte(info.gravity);
			writer.WriteFloat(info.range);
			writer.WriteFloat(info.damage);
			writer.WriteFloat(info.dmg_modify_timer_min);
			writer.WriteFloat(info.dmg_modify_timer_max);
			writer.WriteFloat(info.dmg_modify_min);
			writer.WriteFloat(info.dmg_modify_max);

			writer.WriteFloat(info.capsule_height);
			writer.WriteFloat(info.capsule_radius);
		}
	}

	static void ReadDrumInfo(Core::BinaryNetworkReader & reader, DrumInfo & info)
	{
		ReadGunInfo(reader, info);

		if (info.weapon_type)
		{
			reader.ReadFloat(info.range);
		}
	}

	static void WriteDrumInfo(Core::BinaryNetworkStream & writer, DrumInfo & info )
	{
		WriteGunInfo(writer, info);

		if (info.weapon_type)
		{
			writer.WriteFloat(info.range);
		}
	}

	static void ReadMilkbottleInfo(Core::BinaryNetworkReader & reader, MilkbottleInfo & info )
	{
		ReadGunInfo(reader, info);

		if (info.weapon_type)
		{
			reader.ReadFloat(info.range);
		}
	}

	static void WriteMilkbottleInfo(Core::BinaryNetworkStream & writer, MilkbottleInfo & info )
	{
		WriteGunInfo(writer, info);

		if (info.weapon_type)
		{
			writer.WriteFloat(info.range);
		}
	}
	static void ReadEquipmentInfo(Core::BinaryNetworkReader & reader, EquipmentInfo & info )
	{
		ReadWeaponInfo(reader, info);
	}

	static void WriteEquipmentInfo(Core::BinaryNetworkStream & writer, EquipmentInfo & info )
	{
		WriteWeaponInfo(writer, info);
	}

	static void ReadZombieGunInfo(Core::BinaryNetworkReader & reader, ZombieGunInfo & info )
	{
		ReadWeaponInfo(reader, info);

		if (info.weapon_type)
		{
			reader.ReadFloat(info.stab_time);
			reader.ReadFloat(info.stab_light_time);

			reader.ReadFloat(info.stab_distance);
			reader.ReadFloat(info.stab_light_distance);
			reader.ReadFloat(info.stab_width);
			reader.ReadFloat(info.back_factor);

			reader.ReadFloat(info.stab_hurt);
			reader.ReadFloat(info.stab_light_hurt);
			reader.ReadInt(info.back_boost_plus);
			
			reader.ReadFloat(info.skill_cooldown);
			reader.ReadFloat(info.skill_usetime);
		}
	}

	static void WriteZombieGunInfo(Core::BinaryNetworkStream & writer, ZombieGunInfo & info )
	{
		WriteWeaponInfo(writer, info);

		if (info.weapon_type)
		{
			writer.WriteFloat(info.stab_time);
			writer.WriteFloat(info.stab_light_time);

			writer.WriteFloat(info.stab_distance);
			writer.WriteFloat(info.stab_light_distance);
			writer.WriteFloat(info.stab_width);
			writer.WriteFloat(info.back_factor);

			writer.WriteFloat(info.stab_hurt);
			writer.WriteFloat(info.stab_light_hurt);
			writer.WriteInt(info.back_boost_plus);

			writer.WriteFloat(info.skill_cooldown);
			writer.WriteFloat(info.skill_usetime);
		}
	}

	static void ReadZombieChargeInfo(Core::BinaryNetworkReader & reader, ZombieChargeInfo & info )
	{
		ReadWeaponInfo(reader, info);

		if (info.weapon_type)
		{
			reader.ReadFloat(info.skill_cooldown);
			reader.ReadFloat(info.skill_usetime);
			reader.ReadFloat(info.skill_hurt);
		}
	}

	static void WriteZombieChargeInfo(Core::BinaryNetworkStream & writer, ZombieChargeInfo & info )
	{
		WriteWeaponInfo(writer, info);

		if (info.weapon_type)
		{
			writer.WriteFloat(info.skill_cooldown);
			writer.WriteFloat(info.skill_usetime);
			writer.WriteFloat(info.skill_hurt);
		}
	}

	static void ReadBombInfo(BinaryNetworkReader & reader, BombInfo & info)
	{
		ReadWeaponInfo(reader, info);

		if (info.weapon_type)
		{
			reader.ReadFloat(info.plant_time);
			reader.ReadFloat(info.defuse_time);
			reader.ReadFloat(info.defuse_with_item_time);
		}
	}

	static void WriteBombInfo(BinaryNetworkStream & writer, BombInfo & info)
	{
		WriteWeaponInfo(writer, info);

		if (info.weapon_type)
		{
			writer.WriteFloat(info.plant_time);
			writer.WriteFloat(info.defuse_time);
			writer.WriteFloat(info.defuse_with_item_time);
		}
	}


	static void ReadGunTowerBuilderInfo(Core::BinaryNetworkReader & reader, GunTowerBuilderInfo & info)
	{
		ReadGunInfo(reader, info);
		if (info.weapon_type)
		{
			reader.ReadFloat(info.max_distance);
			reader.ReadFloat(info.max_lift_time);
			reader.ReadFloat(info.hurt_range);
			reader.ReadFloat(info.show_speed);
			reader.ReadFloat(info.move_speed);
			reader.ReadFloat(info.move_keep_time);
			reader.ReadFloat(info.recover_range);
			reader.ReadFloat(info.recover_check_interval);
			reader.ReadFloat(info.recover_per_count_life);
			reader.ReadFloat(info.recover_per_percent_ammo);
			reader.ReadFloat(info.recover_per_minus_ammo);
		}
	}

	static void WriteGunTowerBuilderInfo(BinaryNetworkStream & writer, GunTowerBuilderInfo & info)
	{
		WriteGunInfo(writer, info);
		if (info.weapon_type)
		{
			writer.WriteFloat(info.max_distance);
			writer.WriteFloat(info.max_lift_time);
			writer.WriteFloat(info.hurt_range);
			writer.WriteFloat(info.show_speed);
			writer.WriteFloat(info.move_speed);
			writer.WriteFloat(info.move_keep_time);
			writer.WriteFloat(info.recover_range);
			writer.WriteFloat(info.recover_check_interval);
			writer.WriteFloat(info.recover_per_count_life);
			writer.WriteFloat(info.recover_per_percent_ammo);
			writer.WriteFloat(info.recover_per_minus_ammo);
		}
	}

	static void ReadGunTowerBuilderPlusInfo(Core::BinaryNetworkReader & reader, GunTowerBuilderPlusInfo & info)
	{
		ReadGunInfo(reader, info);
		if (info.weapon_type)
		{
			reader.ReadFloat(info.max_distance);
			reader.ReadFloat(info.max_lift_time);
			reader.ReadFloat(info.hurt_range);
			reader.ReadFloat(info.show_speed);
			reader.ReadFloat(info.move_speed);
			reader.ReadFloat(info.move_keep_time);
			reader.ReadFloat(info.recover_range);
			reader.ReadFloat(info.recover_check_interval);
			reader.ReadFloat(info.recover_per_count_life);
			reader.ReadFloat(info.recover_per_percent_ammo);
			reader.ReadFloat(info.recover_per_minus_ammo);


			//plus info
			GunTowerTypeInfo oTypeInfo;
			int iCnt =0;
			reader.ReadInt(iCnt);
			for(int i=0; i<iCnt; ++i)
			{	
				reader.ReadInt(oTypeInfo.DummyObjectType);
				reader.ReadInt(oTypeInfo.DummyObjectSubType);
				reader.ReadInt(oTypeInfo.SystemId);
				reader.ReadInt(oTypeInfo.MaxCount);
				reader.ReadFloat(oTypeInfo.Width);
				reader.ReadFloat(oTypeInfo.Height);
				reader.ReadString(oTypeInfo.ResKey);

				info.m_aTowerTypeInfo.PushBack(oTypeInfo);
			}
			reader.ReadInt(info.m_iMaxWallCount);
			reader.ReadInt(info.m_iMaxGuardCount);

		}
	}

	static void WriteGunTowerBuilderPlusInfo(BinaryNetworkStream & writer, GunTowerBuilderPlusInfo & info)
	{
		WriteGunInfo(writer, info);
		if (info.weapon_type)
		{
			writer.WriteFloat(info.max_distance);
			writer.WriteFloat(info.max_lift_time);
			writer.WriteFloat(info.hurt_range);
			writer.WriteFloat(info.show_speed);
			writer.WriteFloat(info.move_speed);
			writer.WriteFloat(info.move_keep_time);
			writer.WriteFloat(info.recover_range);
			writer.WriteFloat(info.recover_check_interval);
			writer.WriteFloat(info.recover_per_count_life);
			writer.WriteFloat(info.recover_per_percent_ammo);
			writer.WriteFloat(info.recover_per_minus_ammo);

			//plus info
			const int iCnt =(int)info.m_aTowerTypeInfo.Size();
			writer.WriteInt(iCnt);
			for(int i=0; i<iCnt; ++i)
			{	
				GunTowerTypeInfo& oTypeInfo =info.m_aTowerTypeInfo[i];
				writer.WriteInt(oTypeInfo.DummyObjectType);
				writer.WriteInt(oTypeInfo.DummyObjectSubType);
				writer.WriteInt(oTypeInfo.SystemId);
				writer.WriteInt(oTypeInfo.MaxCount);
				writer.WriteFloat(oTypeInfo.Width);
				writer.WriteFloat(oTypeInfo.Height);
				writer.WriteString(oTypeInfo.ResKey);
			}
			writer.WriteInt(info.m_iMaxWallCount);
			writer.WriteInt(info.m_iMaxGuardCount);
		}
	}

	sharedc_ptr(WeaponInfo) ReadWeapon(Core::BinaryNetworkReader & reader)
	{
		BaseItemInfo baseiteminfo;
		if (!ReadBaseItemInfo(reader, baseiteminfo))
			return NullPtr;

		int type = 0;
		reader.ReadInt(type);

		switch (type)
		{
		case kWeaponTypeSubMachineGun:
			{
				sharedc_ptr(SubMachineGunInfo) weapon = ptr_new SubMachineGunInfo;
				weapon->weapon_type = kWeaponTypeSubMachineGun;
				weapon->SetBaseItemInfo(baseiteminfo);
				ReadSubMachineGunInfo(reader, *weapon);
				return weapon;
			}
			break;

		case kWeaponTypePistol:
			{
				sharedc_ptr(PistolInfo) weapon = ptr_new PistolInfo;
				weapon->weapon_type = kWeaponTypePistol;
				weapon->SetBaseItemInfo(baseiteminfo);
				ReadPistolInfo(reader, *weapon);
				return weapon;
			}
			break;

		case kWeaponTypeDualPistol:
			{
				sharedc_ptr(DualPistolInfo) weapon = ptr_new DualPistolInfo;
				weapon->weapon_type = kWeaponTypeDualPistol;
				weapon->SetBaseItemInfo(baseiteminfo);
				ReadDualPistol(reader, *weapon);
				return weapon;
			}
			break;

		case kWeaponTypeRifle:
			{
				sharedc_ptr(RifleInfo) weapon = ptr_new RifleInfo;
				weapon->weapon_type = kWeaponTypeRifle;
				weapon->SetBaseItemInfo(baseiteminfo);
				ReadRifleInfo(reader, *weapon);
				return weapon;
			}
			break;

		case kWeaponTypeSniperGun:
			{
				sharedc_ptr(SniperGunInfo) weapon = ptr_new SniperGunInfo;
				weapon->weapon_type = kWeaponTypeSniperGun;
				weapon->SetBaseItemInfo(baseiteminfo);
				ReadSniperGunInfo(reader, *weapon);
				return weapon;
			}
			break;

		case kWeaponTypeShotGun:
			{
				sharedc_ptr(ShotGunInfo) weapon = ptr_new ShotGunInfo;
				weapon->weapon_type = kWeaponTypeShotGun;
				weapon->SetBaseItemInfo(baseiteminfo);
				ReadShortGunInfo(reader, *weapon);
				return weapon;
			}
			break;

		case kWeaponTypeMiniGun:
			{
				sharedc_ptr(MiniGunInfo) weapon = ptr_new MiniGunInfo;
				weapon->weapon_type = kWeaponTypeMiniGun;
				weapon->SetBaseItemInfo(baseiteminfo);
				ReadMiniGunInfo(reader, *weapon);
				return weapon;
			}
			break;

		case kWeaponTypeKnife:
			{
				sharedc_ptr(KnifeInfo) weapon = ptr_new KnifeInfo;
				weapon->weapon_type = kWeaponTypeKnife;
				weapon->SetBaseItemInfo(baseiteminfo);
				ReadKnifeInfo(reader, *weapon);
				return weapon;
			}
			break;

		case kWeaponTypeGrenade:
			{
				sharedc_ptr(GrenadeInfo) weapon = ptr_new GrenadeInfo;
				weapon->weapon_type = kWeaponTypeGrenade;
				weapon->SetBaseItemInfo(baseiteminfo);
				ReadGrenadeInfo(reader, *weapon);
				return weapon;
			}
			break;


		case kWeaponTypeFlash:
			{
				sharedc_ptr(FlashInfo) weapon = ptr_new FlashInfo;
				weapon->weapon_type = kWeaponTypeFlash;
				weapon->SetBaseItemInfo(baseiteminfo);
				ReadFlashInfo(reader, *weapon);
				return weapon;
			}
			break;

		case kWeaponTypeSmoke:
			{
				sharedc_ptr(SmokeInfo) weapon = ptr_new SmokeInfo;
				weapon->weapon_type = kWeaponTypeSmoke;
				weapon->SetBaseItemInfo(baseiteminfo);
				ReadSmokeInfo(reader, *weapon);
				return weapon;
			}
			break;

		case kWeaponTypeSpecial:
			{
				sharedc_ptr(SpecialGrenadeInfo) weapon = ptr_new SpecialGrenadeInfo;
				weapon->weapon_type = kWeaponTypeSpecial;
				weapon->SetBaseItemInfo(baseiteminfo);
				ReadGrenadeSpecialInfo(reader, *weapon);
				return weapon;
			}
			break;

			//////////////////////////////////////GL Add Start/////////////////////////////////////////
		case kWeaponTypeMeditNeedleGun:
			{
				sharedc_ptr(LuncherInfo) weapon = ptr_new LuncherInfo;
				weapon->weapon_type = kWeaponTypeMeditNeedleGun;
				weapon->SetBaseItemInfo(baseiteminfo);
				ReadLuncherInfo(reader, *weapon);
				return weapon;
			}
			break;
		case kWeaponTypeLuncher:
			{
				sharedc_ptr(LuncherInfo) weapon = ptr_new LuncherInfo;
				weapon->weapon_type = kWeaponTypeLuncher;
				weapon->SetBaseItemInfo(baseiteminfo);
				ReadLuncherInfo(reader, *weapon);
				return weapon;
			}
			break;
		case kWeaponTypeSignal:
			{
				sharedc_ptr(LuncherInfo) weapon = ptr_new LuncherInfo;
				weapon->weapon_type = kWeaponTypeSignal;
				weapon->SetBaseItemInfo(baseiteminfo);
				ReadLuncherInfo(reader, *weapon);
				return weapon;
			}
		case kWeaponTypeMiniMachineGun:
			{
				sharedc_ptr(MiniMachineGunInfo) weapon = ptr_new MiniMachineGunInfo;
				weapon->weapon_type = kWeaponTypeMiniMachineGun;
				weapon->SetBaseItemInfo(baseiteminfo);
				ReadMiniMachineGunInfo(reader, *weapon);
				return weapon;
			}
			break;
		case kWeaponTypeCureGun:
			{
				sharedc_ptr(CureGunInfo) weapon = ptr_new CureGunInfo;
				weapon->weapon_type = kWeaponTypeCureGun;
				weapon->SetBaseItemInfo(baseiteminfo);
				ReadCureGunInfo(reader, *weapon);
				return weapon;
			}
			break;
		//	//////////////////////////////////////GL Add End/////////////////////////////////////////
		//case kWeaponTypeBow:
		//	{
		//		sharedc_ptr(BowInfo) weapon = ptr_new BowInfo;
		//		weapon->weapon_type = kWeaponTypeBow;
		//		weapon->SetBaseItemInfo(baseiteminfo);
		//		ReadBowInfo(reader, *weapon);
		//		return weapon;
		//	}
		//	break;
		case kWeaponTypeFlameGun:
			{
				sharedc_ptr(FlameGunInfo) weapon = ptr_new FlameGunInfo;
				weapon->weapon_type = kWeaponTypeFlameGun;
				weapon->SetBaseItemInfo(baseiteminfo);
				ReadFlameGunInfo(reader, *weapon);
				return weapon;
			}
			break;

		case kWeaponTypeAmmoRocket:
			{
				sharedc_ptr(AmmoInfo) weapon = ptr_new AmmoInfo;
				weapon->weapon_type = kWeaponTypeAmmoRocket;
				weapon->SetBaseItemInfo(baseiteminfo);
				ReadAmmoInfo(reader, *weapon);
				return weapon;
			}
			break;
		case kWeaponTypeAmmoMeditNeedle:
			{
				sharedc_ptr(AmmoInfo) weapon = ptr_new AmmoInfo;
				weapon->weapon_type = kWeaponTypeAmmoMeditNeedle;
				weapon->SetBaseItemInfo(baseiteminfo);
				ReadAmmoInfo(reader, *weapon);
				return weapon;
			}
			break;
		case kWeaponTypeAmmoGrenade:
			{
				sharedc_ptr(AmmoInfo) weapon = ptr_new AmmoInfo;
				weapon->weapon_type = kWeaponTypeAmmoGrenade;
				weapon->SetBaseItemInfo(baseiteminfo);
				ReadAmmoInfo(reader, *weapon);
				return weapon;
			}
			break;
		case kWeaponTypeAmmoBloodDisk:
			{
				sharedc_ptr(AmmoInfo) weapon = ptr_new AmmoInfo;
				weapon->weapon_type = kWeaponTypeAmmoBloodDisk;
				weapon->SetBaseItemInfo(baseiteminfo);
				ReadAmmoInfo(reader, *weapon);
				return weapon;
			}
			break;
		case kWeaponTypeAmmoStick:
			{
				sharedc_ptr(AmmoInfo) weapon = ptr_new AmmoInfo;
				weapon->weapon_type = kWeaponTypeAmmoStick;
				weapon->SetBaseItemInfo(baseiteminfo);
				ReadAmmoInfo(reader, *weapon);
				return weapon;
			}
			break;
		case kWeaponTypeAmmoArrow:
			{
				sharedc_ptr(AmmoInfo) weapon = ptr_new AmmoInfo;
				weapon->weapon_type = kWeaponTypeAmmoArrow;
				weapon->SetBaseItemInfo(baseiteminfo);
				ReadAmmoInfo(reader, *weapon);
				return weapon;
			}
			break;
		case kWeaponTypeDrum:
			{
				sharedc_ptr(DrumInfo) weapon = ptr_new DrumInfo;
				weapon->weapon_type = kWeaponTypeDrum;
				weapon->SetBaseItemInfo(baseiteminfo);
				ReadDrumInfo(reader, *weapon);
				return weapon;
			}
			break;
		case kWeaponTypeMilkbottle:
			{
				sharedc_ptr(MilkbottleInfo) weapon = ptr_new MilkbottleInfo;
				weapon->weapon_type = kWeaponTypeMilkbottle;
				weapon->SetBaseItemInfo(baseiteminfo);
				ReadMilkbottleInfo(reader, *weapon);
				return weapon;
			}
			break;
		case kWeaponTypeEquipment:
			{
				sharedc_ptr(EquipmentInfo) weapon = ptr_new EquipmentInfo;
				weapon->weapon_type = kWeaponTypeEquipment;
				weapon->SetBaseItemInfo(baseiteminfo);
				ReadEquipmentInfo(reader, *weapon);
				return weapon;
			}
			break;
		case kWeaponTypeBomb:
			{
				sharedc_ptr(BombInfo) weapon = ptr_new BombInfo;
				weapon->weapon_type = kWeaponTypeBomb;
				weapon->SetBaseItemInfo(baseiteminfo);
				ReadBombInfo(reader, *weapon);
				return weapon;
			}
			break;

		case kWeaponTypeZombieGun:
			{
				sharedc_ptr(ZombieGunInfo) weapon = ptr_new ZombieGunInfo;
				weapon->weapon_type = kWeaponTypeZombieGun;
				weapon->SetBaseItemInfo(baseiteminfo);
				ReadZombieGunInfo(reader, *weapon);
				return weapon;
			}
			break;

		case kWeaponTypeZombieCharge:
			{
				sharedc_ptr(ZombieChargeInfo) weapon = ptr_new ZombieChargeInfo;
				weapon->weapon_type = kWeaponTypeZombieCharge;
				weapon->SetBaseItemInfo(baseiteminfo);
				ReadZombieChargeInfo(reader, *weapon);
				return weapon;
			}
			break;
		case kWeaponTypeAmmoProd:
			{
				sharedc_ptr(AmmoInfo) weapon = ptr_new AmmoInfo;
				weapon->weapon_type = kWeaponTypeAmmoProd;
				weapon->SetBaseItemInfo(baseiteminfo);
				ReadAmmoInfo(reader, *weapon);
				return weapon;
			}
			break;
		case kWeaponTypeGunTowerBuilder:
			{
				sharedc_ptr(GunTowerBuilderInfo) weapon = ptr_new GunTowerBuilderInfo;
				weapon->weapon_type = kWeaponTypeGunTowerBuilder;
				weapon->SetBaseItemInfo(baseiteminfo);
				ReadGunTowerBuilderInfo(reader, *weapon);
				return weapon;
			}
			break;
		case kWeaponTypeGunTowerBuilderPlus:
			{
				sharedc_ptr(GunTowerBuilderPlusInfo) weapon = ptr_new GunTowerBuilderPlusInfo;
				weapon->weapon_type = kWeaponTypeGunTowerBuilderPlus;
				weapon->SetBaseItemInfo(baseiteminfo);
				ReadGunTowerBuilderPlusInfo(reader, *weapon);
				return weapon;
			}
			break;
		default:
			LogSystem.WriteLinef("ReadWeapon() : unknow type %d", type);
			break;
		}

		return NullPtr;
	}

	void WriteWeapon(Core::BinaryNetworkStream & writer, WeaponInfo & info)
	{
		switch (info.weapon_type)
		{
		case kWeaponTypeSubMachineGun:
			{
				WriteSubMachineGunInfo(writer, *(SubMachineGunInfo*)&info);
			}
			break;

		case kWeaponTypePistol:
			{
				WritePistolInfo(writer, *(PistolInfo*)&info);
			}
			break;

		case kWeaponTypeDualPistol:
			{
				WriteDualPistol(writer, *(DualPistolInfo*)&info);
			}
			break;

		case kWeaponTypeRifle:
			{
				WriteRifleInfo(writer, *(RifleInfo*)&info);
			}
			break;

		case kWeaponTypeSniperGun:
			{
				WriteSniperGunInfo(writer, *(SniperGunInfo*)&info);
			}
			break;

		case kWeaponTypeShotGun:
			{
				WriteShortGunInfo(writer, *(ShotGunInfo*)&info);
			}
			break;

		//case kWeaponTypeMiniGun::
		//	{
		//		WriteMiniGunInfo(writer, *(MiniGunInfo*)&info);
		//	}
		//	break;

		case kWeaponTypeKnife:
			{
				WriteKnifeInfo(writer, *(KnifeInfo*)&info);
			}
			break;

		case kWeaponTypeGrenade:
			{
				WriteGrenadeInfo(writer, *(GrenadeInfo*)&info);
			}
			break;

		case kWeaponTypeFlash:
			{
				WriteFlashInfo(writer, *(FlashInfo*)&info);
			}
			break;

		case kWeaponTypeSmoke:
			{
				WriteSmokeInfo(writer, *(SmokeInfo*)&info);
			}
			break;

		case kWeaponTypeSpecial:
			{
				WriteGrenadeSpecialInfo(writer, *(SpecialGrenadeInfo*)&info);
			}
			break;

		case kWeaponTypeMeditNeedleGun:
		case kWeaponTypeLuncher:
		case kWeaponTypeSignal:
			{
				WriteLuncherInfo(writer, *(LuncherInfo*)&info);
			}
			break;
		case kWeaponTypeMiniMachineGun:
			{
				WriteMiniMachineGunInfo(writer, *(MiniMachineGunInfo*)&info);
			}
			break;
		case kWeaponTypeCureGun:
			{
				WriteCureGunInfo(writer, *(CureGunInfo*)&info);
			}
			break;
		case kWeaponTypeFlameGun:
			{
				WriteFlameGunInfo(writer, *(FlameGunInfo*)&info);
			}
			break;
		case kWeaponTypeDrum:
			{
				WriteDrumInfo(writer, *(DrumInfo*)&info);
			}
		case kWeaponTypeAmmoRocket:
		case kWeaponTypeAmmoMeditNeedle:
		case kWeaponTypeAmmoGrenade:
		case kWeaponTypeAmmoStick:
		case kWeaponTypeAmmoArrow:
		case kWeaponTypeAmmoBloodDisk:
		case kWeaponTypeAmmoProd:
			{
				WriteAmmoInfo(writer, *(AmmoInfo*)&info);
			}
			break;
		case kWeaponTypeMilkbottle:
			{
				WriteMilkbottleInfo(writer, *(MilkbottleInfo*)&info);
			}
			break;
		case kWeaponTypeEquipment:
			{
				WriteEquipmentInfo(writer, *(EquipmentInfo*)&info);
			}
			break;	
		case kWeaponTypeBomb:
			{
				WriteBombInfo(writer, *(BombInfo*)&info);
			}
			break;

		case kWeaponTypeZombieGun:
			{
				WriteZombieGunInfo(writer, *(ZombieGunInfo*)&info);
			}
			break;

		case kWeaponTypeZombieCharge:
			{
				WriteZombieChargeInfo(writer, *(ZombieChargeInfo*)&info);
			}
			break;
		case kWeaponTypeGunTowerBuilder:
			{
				WriteGunTowerBuilderInfo(writer, *(GunTowerBuilderInfo*)&info);
			}
			break;
		case kWeaponTypeGunTowerBuilderPlus:
			{
				WriteGunTowerBuilderPlusInfo(writer, *(GunTowerBuilderPlusInfo*)&info);
			}
			break;
		default:
			break;
		}
	}

	void ReadCostume(Core::BinaryNetworkReader & reader, Costume & info)
	{
		if (ReadBaseItemInfo(reader, info))
		{
			reader.ReadFloat(info.resistance_flame);
			reader.ReadFloat(info.resistance_explode);
			reader.ReadFloat(info.resistance_bullet);
			reader.ReadFloat(info.resistance_close);
			reader.ReadFloat(info.health_infect);
		}
	}

	void ReadPackInfo(Core::BinaryNetworkReader & reader, PackInfo & info)
	{
		reader.ReadByte(info.id);

		int size = 0;
		reader.ReadInt(size);

		for (int i = 0; i < size; ++i)
			info.weapon_set.PushBack(ReadWeapon(reader));
	}

	void ReadBuffItem(Core::BinaryNetworkReader & reader, BuffItem & item)
	{
		reader.ReadByte(item.id);
		reader.ReadByte(item.type);
		reader.ReadFloat(item.value);
	}

	void ReadCharacterInfo(Core::BinaryNetworkReader & reader, CharacterInfo & info)
	{
		int size;

		reader.ReadInt(info.character_id);
		reader.ReadInt(info.career_id);

		reader.ReadString(info.career_name);

		if(gGame->global)
			gGame->global->Translate(info.career_name);
		
		reader.ReadString(info.career_key);
		reader.ReadString(info.res_key);

		reader.ReadInt(info.max_hp);
		reader.ReadInt(info.ex_hp);
		reader.ReadInt(info.resistance);

		reader.ReadFloat(info.run_speed);
		reader.ReadFloat(info.walk_speed);
		reader.ReadFloat(info.crouch_speed);
		reader.ReadFloat(info.acceleration);

		reader.ReadFloat(info.jump_velocity);
		reader.ReadFloat(info.throw_velocity);

		reader.ReadFloat(info.controller_height);
		reader.ReadFloat(info.controller_radius);
		reader.ReadFloat(info.controller_crouch_height);

		reader.ReadByte(info.can_select);
		reader.ReadByte(info.score_scale);
		reader.ReadInt(info.combat_power);

		for (U32 i = 0; i < MESH_LOD_LEVEL ; i++)
		{
			info.mesh_set_third_person[i].Clear();
			info.mesh_set_first_person[i].Clear();
			info.mesh_set_hat[i].Clear();
		}
		info.detachablepartinfo_set.Clear();

		info.costume_set.Clear();
		reader.ReadInt(size);
		for (int i = 0; i < size; ++i)
		{
			Costume& costume = info.costume_set.PushBack();
			ReadCostume(reader, costume);
		}

		reader.ReadFloat(info.totalBloodAdd);

		info.pack_set.Clear();
		reader.ReadInt(size);
		for (int i = 0; i < size; ++i)
		{
			PackInfo& pack = info.pack_set.PushBack();
			ReadPackInfo(reader, pack);
		}
	}

	void ReadCharacterInfoHead(Core::BinaryNetworkReader & reader, BaseCharacterInfo & info)
	{
		char str[64];
		reader.ReadString(str, sizeof(str));
		info.name = str;

		reader.ReadByte(info.kick_count);
		reader.ReadInt(info.fu_huo_bi);
		reader.ReadInt(info.combat_power);
		reader.ReadInt(info.dan_grading);
		reader.ReadInt(info.nMatchingLevel);
		reader.ReadByte(info.slot_count);

		int size = 0;
		info.item_set.Clear();
		reader.ReadInt(size);
		for (int i = 0; i < size; ++i)
		{
			BuffItem& item = info.item_set.PushBack();
			ReadBuffItem(reader, item);
		}
		
		reader.ReadInt(info.career_count);
		for (uint i = 0; i < info.career_count; i++)
		{
			CharacterInfoSimple &career_info = info.career_list.PushBack();
			
			reader.ReadInt(career_info.career_id);
			reader.ReadString(career_info.career_name);
			
			if(gGame->global)
				gGame->global->Translate(career_info.career_name);
			reader.ReadString(career_info.career_key);
			reader.ReadString(career_info.res_key);
			reader.ReadByte(career_info.can_select);
		}
	}

	void WriteVector3FP(Core::BinaryNetworkStream & writer, const Vector3 & position)
	{
		short x, y, z;

		x = (short)Clamp(position.x * 128.f, -32767.f, 32767.f);
		y = (short)Clamp(position.y * 128.f, -32767.f, 32767.f);
		z = (short)Clamp(position.z * 128.f, -32767.f, 32767.f);

		writer.WriteShort(x);
		writer.WriteShort(y);
		writer.WriteShort(z);
	}

	void ReadVector3FP(Core::BinaryNetworkReader & reader, Vector3 & position)
	{
		short x, y, z;

		reader.ReadShort(x);
		reader.ReadShort(y);
		reader.ReadShort(z);

		position.x = (float)x / 128.f;
		position.y = (float)y / 128.f;
		position.z = (float)z / 128.f;
	}

	void WriteCharacterRotation(Core::BinaryNetworkStream & writer, const Quaternion & rotation)
	{
		Vector3 r = rotation.GetZXY();
		writer.WriteShort((short)(r.x * 8192.f));
		writer.WriteShort((short)(r.y * 8192.f));
	}

	void ReadCharacterRotation(Core::BinaryNetworkReader & reader, Quaternion & rotation)
	{
		short x, y;

		reader.ReadShort(x);
		reader.ReadShort(y);

		rotation.SetZXY(Vector3((float)x / 8192.f, (float)y / 8192.f, 0));
	}

	static void ReadEffectData(Core::BinaryNetworkReader & reader, EffectData & info, bool fullmode)
	{
		if (fullmode)
		{
			short type;
			byte enable;

			// ȫ��Ϣͬ��
			// ͬ��EffectDataȫ����Ϣ��δ�����Ҳ��ͬ����һ�����ڵ��ԡ�
			reader.ReadDouble(info.duration_timer);
			reader.ReadDouble(info.interval);
			reader.ReadDouble(info.interval_timer);
			reader.ReadInt(info.player_id);
			reader.ReadInt(info.player_item_id);
			reader.ReadByte(info.attr_slotid);
			reader.ReadByte(info.attr_sub_slotid);
			reader.ReadShort(info.attr_raw.type);
			reader.ReadShort(info.attr_raw.value1);
			reader.ReadShort(info.attr_raw.value2);
			reader.ReadShort(info.attr_raw.time);
			reader.ReadShort(type);
			info.type = (EEffect)type;
			reader.ReadFloat(info.value);
			reader.ReadByte(enable);
			info.enable = !!enable;
		}
		else
		{
			short type;

			// ������Ϣͬ��
			// ������EffectData��player_id��type��value��attr_raw��type�ֶΣ�δ����ܲ�ͬ����
			reader.ReadInt(info.player_id);
			reader.ReadShort(type);
			info.type = (EEffect)type;
			reader.ReadFloat(info.value);
			reader.ReadShort(info.attr_raw.type);
			info.enable = true;
		}
	}

	void ReadEffectDataList(Core::BinaryNetworkReader & reader, EffectDataList & list, bool fullmode)
	{
		int count = 0;

		reader.ReadInt(count);

		//Core::LogSystem.WriteLinef("ReadEffectDataList() count : %d", count);

		for (int i = 0; i < count; i++)
		{
			EffectData &info = list.PushBack();
			ReadEffectData(reader, info, fullmode);

			//info.DebugPrint();
		}
	}

	void ReadSkillDataList(Core::BinaryNetworkReader & reader, SkillDataList & list, bool fullmode)
	{
		int count = 0;

		reader.ReadInt(count);

		//Core::LogSystem.WriteLinef("ReadSkillDataList() count : %d", count);

		for (int i = 0; i < count; i++)
		{
			SkillData &info = list.PushBack();
			if (fullmode)
			{
				short type;
				short slot;
				byte enable;

				// ȫ��Ϣͬ��
				// ͬ��SkillDataȫ����Ϣ��δ�����Ҳ��ͬ����һ�����ڵ��ԡ�
				reader.ReadDouble(info.duration_timer);
				ReadEffectData(reader, info.effect, true);
				reader.ReadShort(type);
				info.type = (ESkill)type;
				reader.ReadFloat(info.value);
				reader.ReadShort(slot);
				info.slot = (ESkillSlot)slot;
				reader.ReadByte(enable);
				info.enable = !!enable;
			}
			else
			{
				short type;
				short slot;

				// ������Ϣͬ��
				// ������SkillData��type��effect.attr_raw��type�ֶΣ�δ����ܲ�ͬ����
				reader.ReadShort(type);
				info.type = (ESkill)type;
				reader.ReadShort(info.effect.attr_raw.type);
				reader.ReadShort(slot);
				info.slot = (ESkillSlot)slot;
				info.enable = true;
			}

			//info.DebugPrint();
		}
	}

	void ReadBagInfo(Core::BinaryNetworkReader & stream, ItemBag & bag)
	{
		bag.Clear();
		ushort itemNum = 0;
		stream.ReadShort(itemNum);
		InGameItemInfo item_info;
		for (int i = 0; i < itemNum ; ++i)
		{
			stream.ReadInt(item_info.sid);
			stream.ReadInt(item_info.subType);
			stream.ReadInt(item_info.functionID);
			stream.ReadShort(item_info.count);
			stream.ReadFloat(item_info.CDTime);
			stream.Read(&item_info.param, sizeof(item_info.param) );
			stream.ReadString(item_info.icon, sizeof(item_info.name) );
			bag.Set(item_info.sid, item_info);
		}
	}
}
