namespace Client
{
	struct ShotGunInfo : GunInfo
	{
		int   shoot_bullet_count;
		float spread;
		float normal_up_base;
		float normal_up_modifier;
		float normal_up_max;

		ShotGunInfo()
		{
			weapon_type = kWeaponTypeShotGun;
		}
	};

	class ShotGun : public GunBase , public ChangeNodeEventBase
	{
	public:
		/// constrcutor
		ShotGun(by_ptr(ShotGunInfo) info);

		DECLARE_PDE_ATTRIBUTE_R(weapon_info, tempc_ptr(ShotGunInfo))
		{
			return ShotGun_info;
		}

	public:
		///update
		virtual void Update(float time);

		//active
		virtual void Active();

		///reload
		virtual bool Reload();

		/// initialize
		virtual void Initialize();

		/*// active
		//virtual void Active();
		/// inactive
		//virtual void Inactive();*/

		/// get weapon type
		virtual uint GetWeaponType();

//		void FireEffect();

		/// animation event
		virtual void OnAnimationStartFPEvent(const Core::Identifier & groupname, int & index);
		virtual void OnAnimationStartTPEvent(const Core::Identifier & groupname, int & index);
		virtual void OnAnimationEndFPEvent(const Core::Identifier & groupname, int & index);	
		virtual void OnAnimationEndTPEvent(const Core::Identifier & groupname, int & index);	

	public:
		/// fire
		virtual bool Fire();

		sharedc_ptr(ShotGunInfo)	ShotGun_info;
	};
}