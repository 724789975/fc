#include "pch.h"

using namespace Core;
using namespace Client;

DEFINE_PDE_TYPE_CLASS(Client::RifleInfo)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Client::GunInfo);
		ADD_PDE_DEFAULT_CONSTRUCTOR();
	}
};


DEFINE_PDE_TYPE_CLASS(Client::RifleGun)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Client::GunBase);

		ADD_PDE_PROPERTY_R(weapon_info);
	}
};

REGISTER_PDE_TYPE(Client::RifleInfo);
REGISTER_PDE_TYPE(Client::RifleGun);

namespace Client
{
	RifleGun::RifleGun(by_ptr(RifleInfo) info)
	{
		weapon_info = gun_info = rifle_info = info;
	}

	void RifleGun::Initialize()
	{		
		currentSight = NormalSight;
		tempSight    = NormalSight;
		GunBase::Initialize();
	}

	/// can active
	bool RifleGun::CanActive()
	{
		return GunBase::CanActive();
	}

	/// active
	void RifleGun::Active()
	{
		GunBase::Active();
	}

	/// inactive
	void RifleGun::Inactive()
	{
		GunBase::Inactive();
	}

	/// update
	void RifleGun::Update(float frame_time)
	{
		if(gun_info->is_sights)
		{
			tempc_ptr(Character) player = GetOwner();
			if (!player)
				return;

			FirstPerson &person = player->GetFirstPerson();

			if(player->is_complete_raise)
			{
				if(person.animation_action && player->is_complete_raise==true && person.animation_action->IsActionPlaying() == false)
				{
					player->is_complete_raise = false;

					player->SetCameraFov(target_fov,target_fov);

					ChangeModeToNext();
				}
				else
				{
					raise_time += frame_time;

					int fov;
					float ratio = 1.0f;
					if(raise_time < 0.093f)
					{
						ratio = raise_time * 1000.0f / 93.f;

						if(ratio > 1.0f)
							ratio = 1.0f;

						fov = source_fov + (target_fov - source_fov) * ratio;
					}
					else
						fov = target_fov;

					player->SetCameraFov(fov,fov);
				}
				return;
			}
			{
				if(player->CanFire())
					availbleToSetSight = true;

				if(tempSight != currentSight && player->is_complete_raise == false)
					reSetModeToCurrent();
			}
		}
		
		GunBase::Update(frame_time);
	}

	/// get weapon type
	uint RifleGun::GetWeaponType()
	{
		return kWeaponTypeRifle;
	}
	/// fire
	bool RifleGun::Fire()
	{
		tempc_ptr(Character) player = GetOwner();

		if (!player)
			return false;

		float spread = 0;

		if (!player->IsOnGround())
			spread = rifle_info->onair_offset + rifle_info->onair_factor * accuracy;
		else if (player->IsMoving())
			spread = rifle_info->move_offset + rifle_info->move_factor * accuracy;
		else
			spread = rifle_info->normal_factor * accuracy;

		if (!FireBase(spread))
			return false;

		float kickbackscale = rifle_info->sight_info[currentSight].kickbackscale;
	
		
		if (player->IsMoving())
			KickBack (rifle_info->move_up_base * kickbackscale, rifle_info->move_lateral_base * kickbackscale, rifle_info->move_up_modifier * kickbackscale, rifle_info->move_lateral_modifier * kickbackscale, rifle_info->move_up_max * kickbackscale, rifle_info->move_lateral_max * kickbackscale, rifle_info->move_dir_change * kickbackscale);
		else if (!player->IsOnGround())
			KickBack (rifle_info->onair_up_base * kickbackscale, rifle_info->onair_lateral_base * kickbackscale, rifle_info->onair_up_modifier * kickbackscale, rifle_info->onair_lateral_modifier * kickbackscale, rifle_info->onair_up_max * kickbackscale, rifle_info->onair_lateral_max * kickbackscale, rifle_info->onair_dir_change * kickbackscale);
		else if (player->GetCrouch())
			KickBack (rifle_info->crouch_up_base * kickbackscale, rifle_info->crouch_lateral_base * kickbackscale, rifle_info->crouch_up_modifier * kickbackscale, rifle_info->crouch_lateral_modifier * kickbackscale, rifle_info->crouch_up_max * kickbackscale, rifle_info->crouch_lateral_max * kickbackscale, rifle_info->crouch_dir_change * kickbackscale);
		else
			KickBack (rifle_info->normal_up_base * kickbackscale, rifle_info->normal_lateral_base * kickbackscale, rifle_info->normal_up_modifier * kickbackscale, rifle_info->normal_lateral_modifier * kickbackscale, rifle_info->normal_up_max * kickbackscale, rifle_info->normal_lateral_max * kickbackscale, rifle_info->normal_dir_change * kickbackscale);
		if(gun_info->is_sights)
		{
			availbleToSetSight = false;//
			if(!gun_info->auto_fire)
			{
				SetModeToX0();
				tempSight = RifleGun::NormalSight;
			}
		}

		return true;
	}
	

	void RifleGun::DrawCrossHair(by_ptr(UIRender) ui_render)
	{
		tempc_ptr(Character) c = GetOwner();

		if (!c)
			return;

		if (!gun_info)
			return;

		F32 len = 1;
		if (gGame && gGame->camera)
		{
			len = gGame->camera->GetFar() * 0.5f;

			NxRay ray;
			ray.orig = (const NxVec3 &)gGame->camera->position;
			ray.dir = (const NxVec3 &)(Vector3(0, 0, -1) * gGame->camera->rotation);

			NxRaycastHit hit;
			float distance = 500;
			uint group_id = 0;
			group_id |= 1 << PhysxSystem::kStatic;
			group_id |= 1 << PhysxSystem::kStaticRaycast;
			for (uint i = 0; i < 2; ++i)
			{
				group_id |= 1 << (PhysxSystem::kGroupStart + i);
			}
			group_id |= 1 << PhysxSystem::kGroupVehicle;

			NxShape* shape = gPhysxScene->raycastClosestShape(ray, NX_ALL_SHAPES, hit, group_id, distance);
			if (shape)
			{
				//len = Length(gGame->camera->position - (const Vector3 &)hit.worldImpact);
				len = hit.distance;
			}
		}

		F32 v = gDx9Device->convergence > 0 ? gDx9Device->convergence : 1;
		if (gDx9Device->GetStereoEnable() &&  len> 0)
			v = len;

		gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_CONVERGENCE, &v, 1);

		if (c->GetViewMode() == Character::kFirstPerson && gun_info->sight_info.Size() > 0 && c->camera_fov <= gun_info->sight_info[1].level)
		{
			Matrix44 view;
			Vector3 rt_size = ui_render->GetRenderTargetSize();
			view.SetScaleXYZ(2.0f / rt_size.x, -2.0f / rt_size.y, 0);
			view.TranslateXYZ(-1, 1, 0);
			view.TranslateLocalXYZ(-0.5f, -0.5f, 0);
			ui_render->SetWorld(Matrix44::kIdentity);
			ui_render->SetView(view);
			ui_render->SetProjection(Matrix44::kIdentity);
			//ui_render->VertexColor(Color4::kBlack);
			ui_render->SetTexture(gun_info->sight);
			ui_render->BeginRectangleList(1);
			float uv_offset = (rt_size.x - rt_size.y) / rt_size.y * 0.5f;
			ui_render->Vertex(0, 0, 0, -uv_offset, 0, ARGB(255, 255, 255));
			ui_render->Vertex(rt_size.x, rt_size.y, 0, 1 + uv_offset, 1, ARGB(255, 255, 255));
			ui_render->End();

		
		}
		else
		{
			GunBase::DrawCrossHair(ui_render);
		}

		if (gDx9Device->GetStereoEnable())
			v = gDx9Device->convergence > 0 ? gDx9Device->convergence : 1;

		gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_CONVERGENCE, &v, 1);
	}



	///set mode
	void RifleGun::SetModeToX0()
	{
		tempc_ptr(RifleInfo) rifle_info = ptr_static_cast<RifleInfo>(weapon_info);
		if(!rifle_info)
			return;

		if(rifle_info->sight_info.Size() == 0)
			return;
		gun_info->move_speed_offset		= rifle_info->sight_info[0].move_speed_offset;

		tempc_ptr(Character) c = GetOwner();
		if (c)
		{
			c->SetCameraFov(rifle_info->sight_info[0].level, rifle_info->sight_info[0].level);
			c->mouse_sensitivity	= rifle_info->sight_info[0].mouse_sensitivity;
			c->fire_time_ratio = rifle_info->sight_info[0].fire_speed_factor;
			c->SetMoveInfoOffset(gun_info->move_speed_offset);
		}
		tempSight					= currentSight;

	}
	void RifleGun::SetModeToX1()
	{
		tempc_ptr(RifleInfo) rifle_info = ptr_static_cast<RifleInfo>(weapon_info);
		if(!rifle_info)
			return;
		gun_info->move_speed_offset = rifle_info->sight_info[1].move_speed_offset;

		tempc_ptr(Character) c = GetOwner();
		if (c)
		{
			c->SetCameraFov(rifle_info->sight_info[1].level, rifle_info->sight_info[1].level);
			c->mouse_sensitivity = rifle_info->sight_info[1].mouse_sensitivity;
			c->fire_time_ratio = rifle_info->sight_info[1].fire_speed_factor;
			c->SetMoveInfoOffset(gun_info->move_speed_offset);
		}
		tempSight = currentSight;
	}
	void RifleGun::SetModeToX2()
	{
		tempc_ptr(RifleInfo) rifle_info = ptr_static_cast<RifleInfo>(weapon_info);
		if(!rifle_info)
			return;

		gun_info->move_speed_offset = rifle_info->sight_info[2].move_speed_offset;
		tempc_ptr(Character) c = GetOwner();
		if (c)
		{
			c->SetCameraFov(rifle_info->sight_info[2].level, rifle_info->sight_info[2].level);
			c->mouse_sensitivity = rifle_info->sight_info[2].mouse_sensitivity;
			c->fire_time_ratio = rifle_info->sight_info[2].fire_speed_factor;
			c->SetMoveInfoOffset(gun_info->move_speed_offset);
		}
		tempSight = currentSight;
	}
	void RifleGun::SetModeToX3()
	{
		tempc_ptr(RifleInfo) rifle_info = ptr_static_cast<RifleInfo>(weapon_info);
		if(!rifle_info)
			return;

		gun_info->move_speed_offset = rifle_info->sight_info[3].move_speed_offset;
		tempc_ptr(Character) c = GetOwner();
		if (c)
		{
			c->SetCameraFov(rifle_info->sight_info[3].level, rifle_info->sight_info[3].level);
			c->mouse_sensitivity = rifle_info->sight_info[3].mouse_sensitivity;
			c->fire_time_ratio = rifle_info->sight_info[3].fire_speed_factor;
			c->SetMoveInfoOffset(gun_info->move_speed_offset);
		}
		tempSight = currentSight;
	}
	void RifleGun::SetModeToX4()
	{
		tempc_ptr(RifleInfo) rifle_info = ptr_static_cast<RifleInfo>(weapon_info);
		if(!rifle_info)
			return;

		gun_info->move_speed_offset = rifle_info->sight_info[4].move_speed_offset;
		tempc_ptr(Character) c = GetOwner();
		if (c)
		{
			c->SetCameraFov(rifle_info->sight_info[4].level, rifle_info->sight_info[4].level);
			c->mouse_sensitivity = rifle_info->sight_info[4].mouse_sensitivity;
			c->fire_time_ratio = rifle_info->sight_info[4].fire_speed_factor;
			c->SetMoveInfoOffset(gun_info->move_speed_offset);
		}
		tempSight = currentSight;
	}
	/// change mode
	void RifleGun::ChangeModeToNext()
	{
		if(!gun_info->is_sights)
			return;
		if(!availbleToSetSight)
			return;
		if(reloading)
			return;
		ChangeSight();
		tempc_ptr(Character) player = GetOwner();
		if (!player)
			return;
		if(player->weapon_select_state != Character::kWeaponReady)
			return;

		tempc_ptr(RifleInfo) rifle_info = ptr_static_cast<RifleInfo>(weapon_info);
		if(!rifle_info)
			return;

		if(rifle_info->sight_info.Size() > 1)
		{
			FirstPerson &person = player->GetFirstPerson();
			if(person.animation_action && currentSight == RifleGun::NormalSight && player->is_complete_raise == false && is_play == false)
			{
				player->is_complete_raise = true;
				person.animation_action->PlayAction("raise",0.0f);

				source_fov = rifle_info->sight_info[0].level;
				target_fov = rifle_info->sight_info[1].level;

				raise_time = 0.0f;

				is_play = true;
				return;
			}
			if(person.animation_action && currentSight == rifle_info->sight_info.Size()-1 && player->is_complete_raise == false && is_play == false)
			{
				player->is_complete_raise = true;
				person.animation_action->PlayAction("lower",0.0f);

				source_fov = rifle_info->sight_info[rifle_info->sight_info.Size()-1].level;
				target_fov = rifle_info->sight_info[0].level;

				raise_time = 0.0f;

				is_play = true;
				return;
			}
		}

		bool is_select_mode = false;

		is_play = false;

		if(currentSight == RifleGun::NormalSight)
		{
			if(2 <= rifle_info->sight_info.Size())
			{
				is_select_mode = true;
				SetModeToX1();
			}
			currentSight = RifleGun::X1Sight;
		}
		if(currentSight == RifleGun::X1Sight && !is_select_mode)
		{
			if(3 <= rifle_info->sight_info.Size())
			{
				is_select_mode = true;
				SetModeToX2();
			}
			currentSight = RifleGun::X2Sight;
		}
		if(currentSight == RifleGun::X2Sight && !is_select_mode)
		{
			if(4 <= rifle_info->sight_info.Size())
			{
				is_select_mode = true;
				SetModeToX3();
			}
			currentSight = RifleGun::X3Sight;
		}
		if(currentSight == RifleGun::X3Sight && !is_select_mode)
		{
			if(5 <= rifle_info->sight_info.Size())
			{
				is_select_mode = true;
				SetModeToX4();
			}
			currentSight = RifleGun::X4Sight;
		}
		if(currentSight == RifleGun::X4Sight && !is_select_mode)
		{
			currentSight = RifleGun::NormalSight;
			SetModeToX0();
		}
	}
	bool RifleGun::Reload()
	{
		if (gun_info->is_sights && CanReload())
		{
			currentSight = RifleGun::NormalSight;
			SetModeToX0();
		}
		return  GunBase::Reload();
	}

	/// change mode
	void RifleGun::SpecialAbilities(bool keydown)
	{
		if(keydown)
			return;	

		if(reloading)
			return;

		tempc_ptr(Character) player = GetOwner();
		if (!player)
			return;
		if(player->weapon_select_state != Character::kWeaponReady)
			return;

		ChangeModeToNext();;
	}

	void RifleGun::OnAnimationStartFPEvent(const Core::Identifier & groupname, int & index)
	{
		tempc_ptr(Character) player = GetOwner();
		if (!player)
			return;
		FirstPerson & first_person = player->GetFirstPerson();

		Core::String str = groupname;
		if (str == "rocketlauncher_reload" && ammo_count > 0)
		{
			switch (index)
			{
			case 1:
				{
					if (first_person.show_count != -1 && first_person.show_count > 1)
					{
						first_person.show_count -= 1;
					}
					else
					{

					}
				}
				break;
			case 2:
				{
					if (first_person.show_count != -1 && first_person.show_count > 1)
					{
						first_person.show_count -= 1;
						index -= 1;
					}
					else
					{

					}
				}
				break;
			default:
				break;
			}
		}
	}

	void RifleGun::OnAnimationStartTPEvent(const Core::Identifier & groupname, int & index)
	{
		tempc_ptr(Character) player = GetOwner();
		if (!player)
			return;
		ThirdPerson & third_person = player->GetThirdPerson();

		Core::String str = groupname;
		if (str == "rocketlauncher_reload" && ammo_count > 0)
		{
			switch (index)
			{
			case 1:
				{
					if (third_person.show_count != -1 && third_person.show_count > 1)
					{
						third_person.show_count -= 1;
					}
					else
					{

					}
				}
				break;
			case 2:
				{
					if (third_person.show_count != -1 && third_person.show_count > 1)
					{
						third_person.show_count -= 1;
						index -= 1;
					}
					else
					{

					}
				}
				break;
			default:
				break;
			}
		}
	}

	void RifleGun::OnAnimationEndFPEvent(const Core::Identifier & groupname, int & index)
	{
		tempc_ptr(Character) player = GetOwner();
		if (!player)
			return;
		FirstPerson & first_person = player->GetFirstPerson();

		Core::String str = groupname;
		if (str == "rocketlauncher_reload" && ammo_count > 0)
		{
			switch (index)
			{
			case 0:
				{
					if (first_person.show_count != -1 && first_person.show_count == 1)
					{
						first_person.show_count -= 1;
						index += 1;
					}
					else
					{

					}
				}
				break;
			default:
				break;
			}
		}
	}

	void RifleGun::OnAnimationEndTPEvent(const Core::Identifier & groupname, int & index)
	{
		tempc_ptr(Character) player = GetOwner();
		if (!player)
			return;
		ThirdPerson & third_person = player->GetThirdPerson();

		Core::String str = groupname;
		if (str == "rocketlauncher_reload" && ammo_count > 0)
		{
 			switch (index)
 			{
			case 0:
				{
					if (third_person.show_count != -1 && third_person.show_count == 1)
					{
						third_person.show_count -= 1;
						index += 1;
					}
					else
					{
						
					}
				}
				break;
 			case 3:
 				{
 					third_person.node_data_upper->StopAction();
 				}
 				break;
			default:
				break;
 			}
		}
	}
	///current state will be X1 or X4
	void RifleGun::reSetModeToCurrent()
	{
		switch(currentSight)//current = x1 or x2 ,return to normal
		{
		case X1Sight:
			SetModeToX1();
			break;
		case X2Sight:
			SetModeToX2();
			break;
		case X3Sight:
			SetModeToX3();
			break;
		case X4Sight:
			SetModeToX4();
			break;
		default:break;
		}
	}
}