namespace Client
{
	/// state
	enum State
	{
		kNone = 0,
		kLoading,
		kPrepare,
		kReady,
	};

	enum ViewerState
	{
		kFirst = 0,
		kThird,
		kFree,
		kStateNum,
	};

	struct TrapInfo
	{
		Core::Vector3 position;
		byte type;
		byte uid;
		byte team;
		double time;
		sharedc_ptr(ParticleSystem) ps;
	};

	struct Blacklist 
	{
		uint Id;
		Core::String name;
	};

	struct BombPositionData
	{
		sharedc_ptr(StaticMesh)			mesh;
		Core::Vector3					position;
	};
	static const byte InvalidTeam = (byte)-1;

	/// mesh base
	class MeshBase : public Core::Object
	{
	public:
		/// constructor
		MeshBase(const Core::Identifier & name);

		/// draw
		virtual void Draw(Primitive::DrawType, bool immediate = false);

	public:
		/// create primitve
		virtual sharedc_ptr(GsPrimitive) CreatePrimitive(const Core::Identifier & name, bool blink = false, bool async = true);

		/// add primitive
		virtual sharedc_ptr(GsPrimitive) AddPrimitive(const Core::Identifier & key, U32 lod, bool async = true);

		/// add primitive
		virtual sharedc_ptr(GsPrimitive) AddPrimitive(const Core::Identifier & key, const Core::Identifier & value, U32 lod, bool async = true);

		/// get primitive
		virtual sharedc_ptr(GsPrimitive) GetPrimitive(const Core::Identifier & key);

		/// set primitive
		virtual void SetPrimitive(const Core::Identifier & key, by_ptr(GsPrimitive) p, U32 lod);

		/// remove primitive
		virtual void RemovePrimitive(const Core::Identifier & key);

		virtual void MeshBase::SetPartVisible(int lod, const Core::Identifier & key, bool flag);

		/// get position
		virtual const Core::Vector3 & GetPosition();

		/// set position
		virtual void SetPosition(const Core::Vector3 & pos);

		/// get rotation
		virtual const Core::Quaternion & GetRotation();

		/// set rotation
		virtual void SetRotation(const Core::Quaternion & rot);

		/// get scale
		virtual const Core::Vector3 & GetScale();

		/// set scale
		virtual void SetScale(const Core::Vector3 & s);

		/// get visible
		virtual bool GetVisible();

		/// set visible
		virtual void SetVisible(bool flag);

		/// is ready
		virtual bool IsReady();

		/// get bounding box
		Core::AxisAlignedBox& GetAABB();

		/// get primitive count
		const U32 GetPrimitiveCount();
		
		/// update
		virtual void Update();

		/// update bounding box
		virtual void UpdateBoundingBox();

		/// update lod
		virtual void UpdateLod();

		/// set base lod level
		virtual void SetBaseLodLevel(S32 level);

		virtual S32 GetShaderLod();

	public:
		Core::HashSet<Core::Identifier, S32>	primitive_set[MESH_LOD_LEVEL];
		Core::Array<sharedc_ptr(GsPrimitive)>	primitive_array[MESH_LOD_LEVEL];
		U32	primitive_set_ready[MESH_LOD_LEVEL];

	protected:
		Core::String					name;
		bool							transform_dirty;

		S32		mesh_lod_level;
		S32		mesh_base_lod_level;

		S32		shader_lod_level;

	private:
		Core::Vector3		position;
		Core::Vector3		scale;
		Core::Quaternion	rotation;

		Core::AxisAlignedBox	aabb;

		bool	visible		: 1;

	};

	/// static mesh
	class StaticMesh : public MeshBase
	{
	public:
		/// constructor
		StaticMesh(const Core::Identifier & name);
	};

	/// skin mesh
	class SkinMesh : public MeshBase
	{
	public:
		/// constructor
		SkinMesh(const Core::Identifier & name);

	public:
		/// create primitve
		virtual sharedc_ptr(GsPrimitive) CreatePrimitive(const Core::Identifier & name, bool blink = false, bool async = true);

		/// draw
		virtual void Draw(Primitive::DrawType drawtype, bool immediate = false);

		/// update
		virtual void Update();

		/// update lod
		virtual void UpdateLod();

	public:
		sharedc_ptr(Pose)		pose;
	};
}

namespace Client
{
	/// character mesh
	class CharacterMesh : public SkinMesh
	{
	public:
		/// constructor
		CharacterMesh(const Core::Identifier & name);

	public:
		/// load mesh
		void LoadMesh(Core::String path);

		/// set mesh
		void SetMesh(const Core::String & key, const Core::String & value, bool is_first_person, int lod_level);

		/// add part set
		void AddPartSet(Core::String path, const Core::Array<Core::String> & parts);

		/// add part
		void AddPart(Core::String path, Core::String part);

		/// add part key
		void AddPartKey(Core::String path, Core::String part);

		/// load part
		void LoadPart();

	public:
		// hold lua script
		Core::HashSet<Core::Identifier, sharedc_ptr(ScriptLua)> lua_set;

		Core::Array<Core::String> parts;
	};

	/// character mesh
	class AnimObjectMesh: public SkinMesh
	{
	public:
		/// constructor
		AnimObjectMesh(const Core::Identifier & name);

	public:
		/// load mesh
		void LoadMesh(Core::String path);

		/// set mesh
		void SetMesh(const Core::String & key, const Core::String & value, bool is_first_person, int lod_level);

		/// add part set
		void AddPartSet(Core::String path, const Core::Array<Core::String> & parts);

		/// add part
		void AddPart(Core::String path, Core::String part);

		/// add part key
		void AddPartKey(Core::String path, Core::String part);

		/// load part
		void LoadPart();

	public:
		// hold lua script
		Core::HashSet<Core::Identifier, sharedc_ptr(ScriptLua)> lua_set;

		Core::Array<Core::String> parts;
	};
}

namespace Client
{
	/// dynamic stuff
	class DynamicStuff : public Core::Object
	{
	public:
		/// constructor
		DynamicStuff(by_ptr(Skeleton) skeleton);

	public:
		/// update
		void Update(float frame_time);

		/// draw
		void Draw(Primitive::DrawType drawtype, bool immediate = false);

	public:
		/// set animation set
		void SetAnimationSet(const char * key);

	public:
		sharedc_ptr(SkinMesh)	mesh;
		sharedc_ptr(AnimationNodeCustom)	animation;
	};
}

namespace Client
{
	class Level;

	/// character manager
	class CharacterManager
	{
	public:
		/// constructor
		CharacterManager(by_ptr(Level) l);

		/// destructor
		~CharacterManager();

	public:
		/// update
		void Update(float frame_time);

		/// timestepupdate
		void TimeStepUpdate(float frame_time);

		/// on render
		void OnRender(float frame_time);

		/// initialize
		bool Initialize();

		/// terminate
		void Terminate();

		/// add character
		void AddCharacter(by_ptr(Character) c);

		/// remove character
		void RemoveCharacter(uint id);

		/// get character
		tempc_ptr(Character) GetCharacter(uint id);

		/// get next character
		tempc_ptr(Character) GetCharacterNext(uint id, byte team_mask = 1<<0 | 1<<1, bool reverse = false);

		/// get characters
		const Core::Array<sharedc_ptr(Character)> & GetCharacters();

		/// load lua scrips
		void LoadLuaScrips();

		void AddPreloadMesh(tempc_ptr(CharacterInfo)& info);

		void AddPreloadWeapon(tempc_ptr(WeaponInfo)& weapon_info);

	private:
		Core::HashSet<Core::Identifier, sharedc_ptr(ScriptLua)> lua_set;
		Core::Array<sharedc_ptr(Character)>	character_set;
		tempc_ptr(Level)		level;
		uint				state;

		sharedc_ptr(SkinMesh)		preload_firstperson_mesh;
		sharedc_ptr(SkinMesh)		preload_thirdperson_mesh;

		sharedc_ptr(SkinMesh)		preload_weapon_mesh;
	};
}

namespace Client
{
	/// player manager
	class PlayerManager
	{
	public:
		/// constructor
		PlayerManager(by_ptr(Level) l);

	public:
		/// update
		void Update(float frame_time);

		/// timestepupdate
		void TimeStepUpdate(float frame_time);

		/// on render
		void OnRender(float frame_time);

		/// initialize
		bool Initialize();

		/// terminate
		void Terminate();

		/// update control
		void UpdateControl(by_ptr(Input) input, float time);

		///set mouseSensitivity ZoomFactor
		void SetMouseSensitivity(float fZoomFactor);

		///set mouseSensitivity Base
		void SetMouseSensitivityBase(float fBase);

		/// set camera mode
		void SetCameraMode(Camera::ControlMode mode);

		/// view mode to next
		void ViewModeToNext(bool reverse = false);

		void UpdateViewerCameraMode(const tempc_ptr(Character)& view_character);

	public:
		Character::ViewMode		view_mode;
		float					view_distance;
		uint					viewer_id;
		sharedc_ptr(Character)	player;
		tempc_ptr(Level)		level;
		uint	state;
		float	mouseSensitivity;
		float	mouseSensitivityZoomFactor;
		float	mouseSensitivityBase;

		sharedc_ptr(AmmoBase) currentAmmo;

		int		viewer_state;
		bool	need_gun_tower_ammo;
	};
}

namespace Client
{
	/// animation manager
	class AnimationManager : public Core::Object
	{
	public:
		/// on create
		virtual void OnCreate();

		/// on destroy
		virtual void OnDestroy();

		/// update
		void Update(float frame_time);

		/// load
		bool Load();

		/// unload
		void Unload();

		/// load skeleton
		bool LoadSkeleton();

		/// add animationset res
		void AddAnimationSetRes(const Core::Identifier & key, by_ptr(AnimationSetRes) res);

	private:
		Core::HashSet<Core::Identifier, sharedc_ptr(Skeleton)>			skeleton_set;
		Core::HashSet<Core::Identifier, sharedc_ptr(AnimationSetRes)>	animation_set;
	};
}

namespace Client
{
	class PhysxResource : public Resource
	{
	public:
		struct TriangleAttribute
		{
			D3DXVECTOR2_16F uv1[3];
		};

		/// physx actor
		struct PhysxActor : public Core::Object
		{
			PhysxActor()
				: actor(NULL)
				, collision_mode(0)
			{
			}

			sharedc_ptr(MemoryWriteBuffer) buffer;
			Core::Array<TriangleAttribute> attr_buffer;
			NxActor*	actor;
			int			collision_mode;
		};

	public:
		/// constructor
		PhysxResource();

	public:
		/// load data
		virtual sharedc_ptr(Object) BuildData();

		/// load data
		virtual sharedc_ptr(Object) LoadData(Core::Stream & stream);

		/// load data
		virtual bool SaveData(Core::Stream & stream);

		/// unload data
		virtual void UnloadData();

		/// on load data
		virtual bool OnLoadData(by_ptr(Object) obj);

		/// get version
		virtual short GetVersion();

	private:
		Core::Array<sharedc_ptr(PhysxActor)> actor_set;
	};

	class PhysxManager
	{
	public:
		/// constructor
		PhysxManager(by_ptr(Level) l);

	public:
		/// update
		void Update(float frame_time);

		/// load
		bool Load(const Core::Identifier & name);

		/// unload
		void Unload();

	private:
		Core::Array<sharedc_ptr(PhysxResource)>	res_set;
		tempc_ptr(Level)			level;
	};
}

namespace Client
{
	///dropedGun Manager
	class PickUpManager
	{
	public:
		/// constructor
		PickUpManager(by_ptr(Level) l);

		enum PickUpType
		{
			kPickUpWeapon = 0,
			kPickUpSupply = 1,
			kPickUpPortal = 2,
			kPickUpMachine = 3,
			kPickUpSupplyNew = 4,
		};
		
		enum SupplyType
		{
			kSupplyNone 	= 0,
			kSupplyHp		= 1,
			kSupplyAmmo 	= 2,
			kSupplyMedkit	= 3,
			kSupplyAllTools	= 4,
			kSupplyVehicle	= 5,
			kSupplyNovice	= 6,
			kSupplyGold		= 7,
			kSupplyDropWeapon = 8,
			kSupplyGoldWithForce = 9,
			kSupplyZombieGold = 10,
			kSupplyDropItem = 11,
			kSupplyCommonZombie = 12,
			kSupplyCommonZombie2 = 13,
			kSupplyMoonModeWin = 14,
			kSupplyCCoin = 15,
			kSupplyMedal = 16,
			kSupplyWrench = 17,
			kSupplyRandomBox1 = 21,
			kSupplyRandomBox2 = 22,
			kSupplyRandomBox3 = 23,
			kSupplyRandomBox4 = 24,
			kSupplySurvivalItemStart,
			kSupplySurvivalItemHp,
			kSupplySurvivalItemAmmo,
			kSupplySurvivalItemTrapAmmo,
			kSupplySurvivalItemTrapHP,
			kSupplySurvivalItemTrapExpose,
			kSupplySurvivalItemTrapBomb,
			kSupplySurvivalItemTrapDebuff,
			kSupplySurvivalItemRandom,
			kSupplySurvivalItemGhostFire,
			kSupplySurvivalIteminitiative,
			kSupplySurvivalItemEnd,
		};

		struct PickUpObject :public Core::Object
		{
			NxActor*	collider;
			NxActor*	trigger;
			uint		uid;
			bool		removed;
			float		create_Trigger_Time;
			PickUpType	type;
			SupplyType  SType;
			short		team;

			static tempc_ptr(PickUpObject) FromNxActor(NxActor & actor);
			sharedc_ptr(ParticleSystem) particle;
		};

		struct WeaponObject : public PickUpObject
		{
			sharedc_ptr(WeaponBase)	weapon;
		};

		struct SupplyObject : public PickUpObject
		{
			int value;
		};

	public:
		Core::Array<sharedc_ptr(PickUpObject)> pick_up_set;

	public:
		///Initialize
		void Initialize();

		/// Terminate
		void Terminate();

		/// update
		void Update(float frame_time);

		/// drop
		void DropWeapon(tempc_ptr(Character) chara, uint id, byte weapon_id, tempc_ptr(WeaponInfo) info);

		/// add pick up
		void AddPickUp(tempc_ptr(PickUpObject) object, const Core::Vector3 & position, const Core::Quaternion & rotation);

		void AddPickUpWithForce(tempc_ptr(PickUpObject) object, const Core::Vector3 & position, const Core::Quaternion & rotation,const Core::Vector3 & force);

		/// add gun
		tempc_ptr(WeaponObject) AddWeapon(uint id, tempc_ptr(WeaponInfo) info, const Core::Vector3 & position, const Core::Quaternion & rotation);

		// add supply
		tempc_ptr(SupplyObject) AddSupplyNew(uint id, const Core::Vector3 & position, const Core::Quaternion & rotation,SupplyType type,int value);

		/// add supply
		tempc_ptr(PickUpObject) AddSupply(uint id, const Core::Vector3 & position, const Core::Quaternion & rotation,SupplyType type, const Core::Vector3 & force, int team);

		/// generate a trigger by index
		void CreateTrigger(U32 id, const Core::Vector3 & position);

		void CreateTrigger(tempc_ptr(PickUpObject) pickup, const Core::Vector3 & position);

		/// pick
		void PickUp(tempc_ptr(Character) player, uint id);

		void PickUp(tempc_ptr(Character) player, tempc_ptr(PickUpObject) pickup);

		/// pick up weapon
		void PickUpWeapon(tempc_ptr(Character) player, uint id);

		void PickUpWeapon(tempc_ptr(Character) player, tempc_ptr(PickUpObject) pickup);

		//pick up supply new
		void PickUpSupplyNew(tempc_ptr(Character) player, uint id);

		void PickUpSupplyNew(tempc_ptr(Character) player, tempc_ptr(PickUpObject) pickup);
		
		/// pick up supply
		void PickUpSupply(tempc_ptr(Character) player, uint id);

		void PickUpSupply(tempc_ptr(Character) player, tempc_ptr(PickUpObject) pickup);

		/// remove pick up 
		void RemovePickUpWeapon(uint id);

		/// remove pick up 
		void RemovePickUpSupply(uint id);

		// remove pick up new
		void RemovePickUpSupplyNew(uint id);

		///draw
		void Draw(Primitive::DrawType drawtype, bool immediate);

		void RemoeAllSupply();

		bool GetPickUpPosition(uint uid, PickUpType type, Core::Vector3& pos);

	private:
		float	pickup_delay;
		float	pickup_delay_timer;
		float   supply_rot;
	};
}

//DieBuffData
class DieBuffData
{
public:
	float				duration_timer;		//����ʱ���ʱ����s��
	float				interval;				//���ʱ�䣨s��
	int				type;						//����EEffect
	float				value;					//Effect����
	int				rate;						//����
	Core::String  res_key;
	Core::String res_desc;
};

namespace Client
{
	/// level
	class Level : public Core::Object
	{
	public:
		struct StartPoint
		{
			int team;
			Core::Vector3 position;
			float direction;
		};

		struct SceneLeaf
		{
			float halfSize;
			uint childcount;
			Core::Vector3 position;
			sharedc_ptr(SceneLeaf) children[8];
			sharedc_ptr(Core::AxisAlignedBox) aabb;
			Core::Array< Core::AxisAlignedBox > target;
			SceneLeaf()
			{
				for(uint i =0;i< 7;i ++)
					children[i] = NullPtr;
				
				target.Clear();
				childcount = 0;
			}
		};

		struct LevelParticleInfo
		{
			Core::Identifier key;
			Core::Vector3 pos;
			Core::Vector3 nor;
		};

		struct LevelMesh
		{
			sharedc_ptr(StaticMesh) mesh;
			Core::AxisAlignedBox aabb;
		};

		struct GoldParticle
		{
			sharedc_ptr(ParticleSystem) particle;
			sharedc_ptr(ParticleSystem) particle_trail;
			sharedc_ptr(ParticleSystem) particle_kind;
			Core::Vector3 downPos;
			Core::Vector3 upPos;
			float show_time;
			FMOD::Event* firework;
			GoldParticle()
			{
				firework = NULL;
				show_time = 5.f;
			}
		};
      
        struct Fireworks
		{   
			
            sharedc_ptr(ParticleSystem) particle_Kind;
			sharedc_ptr(ParticleSystem) particle_Trail;
			Core::Vector3 UpPos;
			FMOD::Event* Firework;
            float show_Time;
			Core::Vector3 DownPos;
			Fireworks()
			{
				Firework = NULL;
				show_Time = 5.f;
			}

		};

		typedef Core::HashSet<int, LevelMesh> LevelMeshSet;

		typedef Core::HashSet<U16, sharedc_ptr(AmmoBase)> AmmoSet;

	public:
		/// constructor
		Level();

		/// destructor
		~Level();

	public:
		/// on create
		void OnCreate();

		/// on destroy
		void OnDestroy();

		/// udpate
		void Update(float frame_time);

		/// timestepupdate
		void TimeStepUpdate(float frame_time);

		/// on render
		void OnRender(float frame_time);

		/// updateOccluderPlane
		void UpdateOccluderPlane();

		/// UpdateVisibleArea
		void UpdateVisibleArea();

		void UpdateDeadZone();

		/// initialize
		bool Initialize();

		/// load
		bool Load();

		/// load map
		bool LoadMap(const Core::Identifier & name);

		/// GC
		void GC();

		/// unload
		void Unload();

		/// unload map
		void UnloadMap();

		/// start
		void Start();

		/// end 
		void End();

		/// reset
		void Reset();

		void CreateBombGroundParticle();

	public:
		/// add character
		void AddCharacter(by_ptr(Character) c);

		/// remove character
		void RemoveCharacter(uint id);

		/// get character
		tempc_ptr(Character) GetCharacter(uint id);

		/// get character next
		tempc_ptr(Character) GetCharacterNext(uint id, byte team_mask = 1<<0 | 1<<1, bool reverse = false);

		/// get characters
		const Core::Array<sharedc_ptr(Character)> & GetCharacters();

		/// get player
		tempc_ptr(Character) GetPlayer();

		/// get viewer
		tempc_ptr(Character) GetViewer();

		/// add particle
		tempc_ptr(ParticleSystem) AddParticle(const Core::Identifier & key, const Core::Vector3 & position, const Core::Vector3 & normal);

		/// 
		tempc_ptr(ParticleSystem) AddParticle(const Core::Identifier & key, const Core::Vector3 & position, const Core::Quaternion & q);

		void AddLevelParticle(const Core::Identifier & key, const Core::Vector3 & position, const Core::Vector3 & normal);

		void AddLevelParticle(const Core::Identifier & key, const Core::Vector3 & position, const Core::Quaternion & q);

		/// add particle
		tempc_ptr(ParticleSystem) AddParticle(by_ptr(ParticleSystem) particle);

		/// remove particle
		void RemoveParticle(by_ptr(ParticleSystem) particle);

		/// add decal
		void AddDecal(const Core::String key, const Core::Vector3 & target, const Core::Vector3 & normal, const Core::Vector3 & size, const F32 duration = 1.f);

		/// update particle
		void UpdateParticle(float frame_time);

		/// add bullet impact
		void AddBulletImpact(const Core::Vector3 & position, const Core::Vector3 & normal, int material_index);

		/// gen ammoid
		U16 GenAmmoId();

		
	public:
		/// about pveboss
		tempc_ptr(Character) GetPveClientByName(const Core::String &name);

		void GetLeastBloodCharacter(int team);

		void GetMaximumBloodCharacter(int team);

		void SetCharactersByBlood(int team);

	public:
		/// load sound
		bool LoadSound();

		/// load particle
		bool LoadParticle(bool reload = false);

	public:
		/// throw grenade
		void ThrowGrenade(uint id, by_ptr(ThrowableInfo) info, const Core::Vector3& position, const Core::Vector3& velocity, int team);

		/// launch ammo
		bool LaunchAmmo(byte uid, uint team, by_ptr(AmmoInfo) info, const Core::Vector3& position, const Core::Vector3& velocity, U16 ammoindex, by_ptr(Character) target = NullPtr,bool isboost = false);
		
		/// greande explode
		void GrenadeExplode(by_ptr(Grenade) grenade);

		/// on game start
		void OnGameStart();

		/// round start
		void RoundStart();

		/// round end
		void RoundEnd();

		/// shoot
		void Shoot(const Core::Vector3& target, const Core::Vector3& normal);

		/// explode grenade
		void ExplodeGrenade(uint id, float distance);

		/// ProjectedAmmo explode
		void AmmoExplode(by_ptr(AmmoBase) rocket);

		/// hit
		void Hit(Character* c, const Core::Vector3& target, int part);

		/// set camera mode
		void SetCameraMode(Camera::ControlMode mode);
		
		// occludee
		Core::Occludee					occludee;

		// get visible
		bool GetVisible(const Core::AxisAlignedBox& aabb);
		bool GetVisible(const Core::OrientBox& obb);

		void AmmoOnDead(const by_ptr(AmmoBase) ammo ,U16 ammoindex);
		void TestSummonGate();

		void SummonActiveGate(const Core::Vector3& vec, float deg, bool isactive, int team, const Core::Vector3& target_vec, const Core::Vector3& dim, const Core::Vector3& collision_dim, const Core::String& mesh_path);
		void SummonGate(const Core::Vector3& vec, float deg, int id, int team, const Core::Vector3& target_vec, const Core::Vector3& dim, const Core::Vector3& collision_dim, const Core::String& mesh_path);
		void AddGunTarget(const Core::Vector3& pos, const Core::Vector3& end_pos, float deg,int id, int uid, const Core::Vector3& collision_dim, const Core::String& mesh_path, int type);
		void SetZombieStepTwoSoundInfo(float delay_time, const Core::String& zombie_sound, const Core::String& human_sound);
		void AddActiveObject(const Core::Vector3& position,const Core:: Quaternion& qRot, const Core::String& filename, const Core::Vector3& rot_normal, float rot_360_time, float updown_distance, float updown_speed);
		void AddAnimObject(const Core:: Quaternion& qRot, const Core::String& filename) ;

		void AddDeadAABB(const Core::Vector3& min, const Core::Vector3& max);
		
		void AddManualBound(const Core::Vector3& offset, const Core::Vector3& dim, int type);
		
		bool SetAllAmmoDeadByUser(const byte uid, WeaponType wtype = kWeaponTypeNone);
		bool RemoveAllAmmoByUser(const byte uid, WeaponType wtype = kWeaponTypeNone);
		bool SetAmmoDead(const byte uid, U16 index);

		void UpdateVehicleInfo(const PushVehicleInfo& info_red, const PushVehicleInfo& info_blue);

		void InitializeVehicleInfo(const PushVehicleInfo& info_red, const PushVehicleInfo& info_blue);

		void AddHorn(const Core::String& str);

		// blacklist add
		void BlacklistAdd(uint uid,const Core::String& str);

		// blacklist clear
		void BlacklistClear();

		void BuildDeadZoneOctree();

		void RecursiveSceneBuild(const by_ptr(SceneLeaf) leaf,const Core::Vector3 &translation,float halfsize,const Core::AxisAlignedBox &aabb);
		
		void RecursiveSceneCheck(const by_ptr(SceneLeaf) leaf,const Core::Vector3 &translation);

		void ClearDefuseBombState();

		void StartDefuseBombState(float t);

		float GetBombDefusingState();
		
		float GetBombPlantingState();

		float GetBombPlantedTimer();

		bool IsCanPlantBomb();

		void UpdateReplayUI();



		void BombMode_DefuseBomb();

		void BombMode_CancelDefuseBomb();

		void ZombieMode_SaveDying();

		void ZombieMode_CancelSaveDying();

		void AddDummyObject(byte owner_id,uint uid, byte type, byte sub_type, byte need_stepfather, byte team, byte can_hurt, const char* pbuffer, int length);
		int GetDummyObjectCount(int type, const Core::String& szRes);
		int GetDummyObjectCountBySubType(int sub_type);

		bool RemoveDummyObject(uint uid);

		bool IsMachineGunTurretAreaInside(const Core::Vector3 &pos, const float w, const float h);
		bool IsMachineGunTurretArea(const Core::Vector3 &pos);

		void SetEditMapSize(float w, float h);
		float GetEditMapWidth();
		float GetEditMapHeight();

		void SetEditMapItemSize(float s);
		float GetEditMapItemSize();

	public:
		Lua::LuaState *					lua_state;
		LevelMeshSet					map_meshs;
		Core::Array<tempc_ptr(StaticMesh)>	visible_meshs;
		Core::AxisAlignedBox			map_movearea;
		sharedc_ptr(MapVisibleTree)		map_visible_tree;
		sharedc_ptr(StaticMesh)			holdpoint_mesh;
		Core::Array<U32>				level_material;
		sharedc_ptr(CharacterManager)	character_manager;
		sharedc_ptr(PlayerManager)		player_manager;
		sharedc_ptr(AnimationManager)	animation_manager;
		sharedc_ptr(PhysxManager)		physx_manager;
		sharedc_ptr(BulletManager)		bullet_manager;
		sharedc_ptr(DecalManager)		decal_manager;
		sharedc_ptr(PickUpManager)		pickup_manager;
		sharedc_ptr(LightManager)		light_manager;


		sharedc_ptr(ParticleManager)	particle_manager;
		sharedc_ptr(LevelEventMgr)		level_eventmgr;


     
		sharedc_ptr(Character) tmpplayer;
		sharedc_ptr(Character) saveplayer;

		Core::Array<Blacklist>				m_Blacklist;

	public:
		uint state;
		Core::Identifier name;
		byte game_type;
		byte use_self_weapon;
		int rule_value;

		RoomOption room_option;

		bool is_round_end:1;

		Core::String name1;
		Core::String name2;
		Core::String mode_name;
		Core::Vector2 map_center;
		Core::Vector2 map_size;

		Core::Vector3 camera_position;
		Core::Quaternion camera_rotation;

		bool force_draw_all_visible;

		Core::Array<sharedc_ptr(Texture2D)> skill_img;

		sharedc_ptr(Texture2D) map_texture;

		sharedc_ptr(Texture2D) map_lightmap;

		Core::Array<sharedc_ptr(Grenade)>	grenade_array;
		Core::HashSet<U8, sharedc_ptr(AmmoSet)> character_ammoset;
		Core::Array<sharedc_ptr(GateBase)> gate_array;
		Core::Array<sharedc_ptr(ActiveObject)> active_object_array;
		Core::Array<sharedc_ptr(AnimObject)> anim_object_array;
		Core::Array<sharedc_ptr(SpiritBall)>	spiritball_array;
		Core::Array<sharedc_ptr(DetachablePart)>	detachablepart_array;
		Core::Array<sharedc_ptr(GunTarget)> novice_guntarget_array;
		Core::HashSet<uint, sharedc_ptr(DummyObject)>	dummy_object_set;

		Core::HashSet<Core::Identifier, sharedc_ptr(ScriptLua)>	script_set;

		Core::Array<TrapInfo> trap_info;

		struct HoldPointInfo
		{
			byte owner_team;
			byte snatch_team;
			float snatching_timer;
			
			Core::AxisAlignedBox aabb;
		};

		Core::Array<HoldPointInfo>	hold_points;
		
		float						holdpoint_rotspeed;
		Core::Quaternion			holdpoint_rot;

		

		float round_end_wait_time;
		float round_start_wait_time;
		bool round_start_waiting;
		float round_total_time;

		//kick person
		byte sponsor_uid;
		byte kicked_uid;
		byte kicked_reason;
		bool kick_select_open;
		float kick_wait_time;
		int kick_agree_num;
		int kick_against_num;
		int kick_select_id;


        Core::Array<Core::Vector3> firework_vectors;
        Core::Array<sharedc_ptr(Fireworks)> firework_particles;
        float fly_Time;
        int	gold_pos_Num;
        float launch_Time;
		float Launch_Time;
		//gold particle   
		Core::Array<Core::Vector3> gold_vectors;
		Core::Array<sharedc_ptr(GoldParticle)> gold_particles;
		int	gold_pos_num;
		bool isneedparticle;
		float launch_time;
		float fly_time;
		int fuhuo_cion;
		bool isuse;
		int use_coin_num;

		// hold point
		float team_timer[2];
		byte cur_holdpoint_diffnum;
		bool  team_timer_warning[2];

		//vehicle
		bool vehicle_started[2];
		bool vehicle_half[2];
		bool vehicle_almost_end[2];



		Core::Array<LevelParticleInfo>	level_particle_info;

		Core::Array< Core::OccluderPlane > occluderplanes;
		Core::Array< Core::AxisAlignedBox > machinegunturretarea;
		Core::Array< Core::AxisAlignedBox > nomachinegunturretarea;
		Core::Array< MeshPhysXData > mesh_manual_info_array;

		float m_fEditMapWidth;
		float m_fEditMapHeight;
		float m_fEditMapItemSize;
#if DEBUG_INFO
		Core::Array< DebugPrimitiveRect > debug_occluedr_rect;

		bool renderOC;
		bool show_visible_info;

		bool render_holdpoints;
		bool render_vehicles;
#endif
		Core::Array< Core::AxisAlignedBox > check_dead_zone;

		float check_dead_timer;

		bool  render_dead_aabb;
		bool  render_debug_aabb;
#if DEBUG_INFO
		Core::Array< DebugPrimitiveRect > debug_dead_zone_rect;
		Core::Array< DebugPrimitiveRect > debug_check_zone_rect;
#endif
		bool activeOC;
	
		bool is_self_plant_bomb:1;

		bool team_hurt;

		// weapon preload
		Core::Array<sharedc_ptr(WeaponInfo)>	level_weapon_set;
		Core::Array<sharedc_ptr(WeaponBase)> level_weapon;

		// treasure
		sharedc_ptr(StaticMesh)	hp_supply;
		sharedc_ptr(StaticMesh)	Ammo_supply;
		sharedc_ptr(StaticMesh)	bighp_supply;
		sharedc_ptr(StaticMesh)	bigammo_supply;
		sharedc_ptr(StaticMesh)	gold_supply;
		sharedc_ptr(StaticMesh) zombie_hp;
		sharedc_ptr(StaticMesh) zombie_ammo;
		sharedc_ptr(StaticMesh)	dropitem_supply;
		sharedc_ptr(StaticMesh)	commonzombie_supply;
		sharedc_ptr(StaticMesh)	item_normal_supply;
		sharedc_ptr(StaticMesh)	item_special_supply;
		sharedc_ptr(StaticMesh)	moon_win_supply;
		sharedc_ptr(StaticMesh)	CCoin_supply;
		sharedc_ptr(StaticMesh)	Medal_supply;
		sharedc_ptr(StaticMesh)	Wrench_supply;
		sharedc_ptr(StaticMesh)	RandomBox_supply;
		sharedc_ptr(StaticMesh)	Trap_supply;

		struct DisguiseInfo
		{
			Core::Array<Core::String>	part_set[2];
			Core::Array<sharedc_ptr(CharacterMesh)> mesh_set;
		};

		DisguiseInfo	disguise_info;

		float	flash_light;
		float	flash_bright;
		Core::Vector3 light_position;
		Core::Vector4 light;

		Core::HashSet<int, sharedc_ptr(Spray)> spray_set;
		
		sharedc_ptr(Vehicle) vehicle[2];

		// for ui hold point
		float hold_point_fPersert_red;
		float speed_red;
		float hold_point_fPersert_blue;
		float speed_blue;

		// for vehice
		float old_vehice_length_red;
		float old_vehice_length_blue;
		float vehice_fPersert_red;
		float vehice_fPersert_blue;
		float vehice_timer_red;
		float vehice_timer_blue;

#if DEBUG_TOOLS
		sharedc_ptr(Character)	debug_character;
#endif

#if DEBUG_CMD
		bool	disable_static_collision;
		bool	focus_hurtrate;
		bool	noclip_mode;
		bool	enable_walk;
		bool	pjtammo_cntrol;
		float	hurtrate;
		float	noclip_speed;
		byte	ammo_locked_uid;
#endif

		bool	showhorn;
		float	horntime;
		Core::Deque<Core::String> horn_array;
		float	start_chooseperson_time;
		FMOD::Event*	scenesound_event;
		FMOD::Event*	scene3dsound_event;
		FMOD::Event*	holdpoint_sound;
		FMOD::Event*	vehicle_sound[2];
		FMOD::Event*	spiriteball_fly_sound;
		FMOD::Event*	mvp_sound;
		// sound
		FMOD::Event* audio_background;
		FMOD::Event* audio_Survival_background;
		FMOD::Event* audio_Survival1_background;
		Core::Vector3   sound3d_pos;
		FMOD::Event* audio_bossmode2_background;
		FMOD::Event* audio_killing_background;
		FMOD::Event* audio_chrismas_background;

		// bomb sound
		FMOD::Event* audio_bomb_2d_Plant;
		FMOD::Event* audio_bomb_3d_Plant;
		FMOD::Event* audio_bomb_2d_Defuse;
		FMOD::Event* audio_bomb_3d_Defuse;
		FMOD::Event* audio_bomb_Planting_Defusing;

		FMOD::Event* audio_bomb_3d_Plant_Timer[5];
		

		uint    last_id;
		bool    isselectperson;
		float	targetenemy_time;
		float	GunTower_Move_CD;

		int		pveboss_uid;

		//for novice
		uint	novice_index;
		float	novice_timer;
		bool    novice_need_timer;
		int     novice_shoot_num;
		sharedc_ptr(ParticleSystem) novice_particle;
		sharedc_ptr(ParticleSystem) bomb_explode_particle;

		sharedc_ptr(ParticleSystem) bomb_on_ground_particle;

		Core::Vector3 novice_index_pos;
		bool    novice_isdraw;
	
		int		boss_starttimeer;
		int		boss_mode_left_count;

		float	sensitivity_timer;
		
		sharedc_ptr(SceneLeaf) first_leaf;
		float	max_leaf_size;
		bool	is_in_DeadZoon;
		bool	use_octee_deadzoon;

		// bomb mode
		bool	bomb_on_ground;
		Core::Vector3 bomb_on_ground_position;
		Core::Quaternion bomb_on_ground_rotation;

		sharedc_ptr(StaticMesh) bomb_special_mesh;
		
		
		float	bomb_defuse_total;
		float	bomb_defuse_timer;
		float	bomb_explode_timer;
		bool	bomb_defusing;
		uint	bomb_droped_id;
		bool	bomb_droped;
		
		float	activeGateTime;
		float	activeHaveTime;
		bool	isCanActiveGate;
		bool	isZombieText_show;

		bool	bomb_exploded;
		Core::Array< Core::AxisAlignedBox > bomb_plant_aabb;

		Core::Array<sharedc_ptr(BombPositionData)> bomb_plant_position_array;

		//common zombie mode
		Core::HashSet<uint, sharedc_ptr(ParticleSystem)> somg_particle_set;
		
		// street boy mode
		byte	current_street_king_uid[2];
		byte	street_king_state[2];

		// zombie mode
		bool	zombie_saving_dying;
	
		Core::Array< Core::AxisAlignedBox > zombie_target_aabb;

		float	step_two_sound_timer;
		float	step_two_sound_default_timer;
		Core::Identifier step_two_zombie_sound;
		Core::Identifier step_two_human_sound;
		bool zombie_state_two_flag;

		FMOD::Event* zombie_state_two_muisc;
		FMOD::Event* boss_mode2_armor_warning;


		byte    kick_count;
		bool	b_Scale_Cd[4];
		bool    isGunSensitivity;

		uint	boss2_career_id;
		uint	boss2_sp_career_id[4]; //0:�̶��������1:�̶�������2:����UAV��3:��ǹUAV

		uint	item_career_id;

		bool	zombie_human_down_sound;
		bool	commonzombie_king_isShow;

		Core::Array<Core::String> moon_mode_win_list; 

	private:
		Camera	backup_camera;
		
		U16		ammoid_builder;

	public:
		Core::Array<DieBuffData> die_buff_data;
	};
}
