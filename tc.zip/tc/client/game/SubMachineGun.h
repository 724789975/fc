namespace Client
{
	struct SubMachineGunInfo : public RifleInfo
	{
		SubMachineGunInfo()
		{
			weapon_type = kWeaponTypeSubMachineGun;
		}
	};

	class SubMachineGun : public RifleGun
	{
	public:
		/// constructor
		SubMachineGun(by_ptr(SubMachineGunInfo) info);

	public:
		/// get weapon type
		virtual uint GetWeaponType();
	};
}