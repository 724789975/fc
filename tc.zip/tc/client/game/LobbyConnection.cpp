#include "pch.h"

#define USE_ENCODER 1
namespace Client
{
	const int network_version = ((1 << 0) | (0 << 8) | (0 << 16) | (27 << 24));
};

using namespace Core;
using namespace Client;

enum EServerMessage
{
    SM_ResponseRPC,
    SM_ResponseEnterLobby,
    SM_ResponseLeaveLobby,
    SM_ResponseChannelConnect,
    SM_NotifyChat,
    SM_NotifyFCM,
    SM_ForceDisconnect,
    SM_ResponseTeamInvite,
    SM_ResponseTeamJoin,
    SM_NotifyTeamInvite,
    SM_NotifyTeamMemberJoin,
    SM_NotifyTeamMemberLeave,
    SM_NotifyTeamChangeLeader,
    SM_NotifyTeamMemberInfo,
    SM_NotifyTeamLeave,
    SM_NotifyTeamRefuse,
    SM_NotifyRoomPreserve,
    SM_NotifyRoomCancelPreserve,
    SM_NotifyTeamCall,
    SM_ResponseTeamCall,
    SM_ResponseSearchRoom,
    SM_NotifyUpdateLevelList,
    SM_NotifyRefusePreserve,
    SM_NotifyRPCMessage,
    SM_ResponseEnterServer,
    SM_ResponseEnterChannel,
    SM_ResponseLeaveServer,
    SM_NotifyRefreshServerList,
    SM_NotifyRefreshChannelList,
	SM_ResponseCharacterAddress,

	SM_NotifyChatGroupInvite,
	SM_NotifyChatGroupJoin,
	SM_NotifyChatGroupLeave,
	SM_NotifyChatGroupCall,
	SM_ResponseChatGroupCreate,
	SM_ResponseChatGroupMember,

	SM_NotifyMultiChat,
	SM_NotifyLoopMsg,

	SM_ResponseApex,

	SM_ResponseBattleBattleGroups,
	SM_ResponseBattleGroupCreate,
	SM_ResponseBattleGroupJoin,
	SM_ResponseBattleGroupStartSearch,
	SM_ResponseBattleGroupChallenge,
	SM_NotifyBattleGroupInvite,
	SM_NotifyBattleGroupKick,
	SM_NotifyBattleGroupChange,
	SM_NotifyBattleGroupInfo,
	SM_NotifyBattleGroupSearching,
	SM_NotifyBattleGroupGameStart,


	SM_UpdateBillBoardInfo,





    //ƥ��
	SM_ResponseMatchingTeamCreate,
	SM_ResponseMatchingTeamInvite,
	SM_ResponseMatchingTeamJoin,
	SM_ResponseMatchingTeamLeave,
	SM_ResponseMatchingTeamKick,
	SM_ResponseMatchingTeamChangeLeader,

	SM_NotifyMatchingTeamInvite,
	SM_NotifyMatchingTeamMemberJoin,
	SM_NotifyMatchingTeamMemberLeave,
	SM_NotifyMatchingTeamChangeLeader,
	SM_NotifyMatchingTeamMemberInfo,
	SM_NotifyMatchingTeamLeave,
	SM_NotifyMatchingTeamKick,
	SM_NotifyMatchingTeamChange,

	SM_ResponseMatching,
	SM_ResponseCancelMatching,

	SM_ResponseMatchingProgress,

	// ������as�����е� ��ʱ��֪����ʲô���� �ȼӽ�ȥ
	SM_NotifyPunishedNames,		//ƥ��ʱ�����ڳͷ�ʱ����
	SM_NotifyBeginMatch,		//��ʼƥ��
	SM_NotifyLeftPunishedTime,		//����ʣ��ͷ�ʱ��

	SM_NotifyGoToMetchingRoom,		// ƥ���ʱ�� ��������ֱ�ӽ���ĳ������

	SM_ResponseLestPersonChannel,
	SM_ResponseIntoMatchingTeam,

	CM_ResponseChangeMatchMap,				// �޸ĵ�ͼ
	CM_ResponseChangeMatchGameType,				// �޸���Ϸ����

};

enum EClientMessage
{
    CM_RequestRPC,
    CM_RequestEnterLobby,
    CM_RequestLeaveLobby,
    CM_RequestChannelConnect,
    CM_RequestChat,
    CM_RequestTeamInvite,
    CM_RequestTeamJoin,
    CM_RequestTeamLeave,
    CM_RequestTeamKick,
    CM_RequestTeamChangeLeader,
    CM_RequestTeamRefuse,
    CM_RequestTeamCall,
    CM_RequestSearchRoom,
    CM_RequestCancelSearchRoom,
    CM_RequestRefusePreserve,
    CM_RequestEnterServer,
    CM_RequestEnterChannel,
    CM_RequestLeaveServer,
    CM_RequestRefreshServerList,
    CM_RequestRefreshChannelList,
	CM_RequestCharacterAddress,

	CM_SaveUserProfile,
	CM_SaveCharacterProfile,

	CM_RequestChatGroupCreate,
	CM_RequestChatGroupInvite,
	CM_RequestChatGroupJoin,
	CM_RequestChatGroupLeave,
	CM_RequestChatGroupCall,
	CM_RequestChatGroupMember,

	CM_NotifyMultiChat,

	CM_RequestApex,

	CM_RequestBattleGroups,
	CM_RequestBattleGroupCreate,
	CM_RequestBattleGroupInvite,
	CM_RequestBattleGroupJoin,
	CM_RequestBattleGroupLeave,
	CM_RequestBattleGroupInfo,
	CM_RequestBattleGroupReady,
	CM_RequestBattleGroupStartSearch,
	CM_RequestBattleGroupChallenge,

	//ƥ�� 
	CM_RequestMatchingTeamCreate,			// ��������ƥ��Ķ���(������ȵý��뷿����ܷ�)
	CM_RequestMatchingTeamJoin,				// ����
	CM_RequestMatchingTeamInvite,			// ����
	CM_RequestMatchingTeamLeave,			// �뿪(��һ����)
	CM_RequestMatchingTeamKick,				// T��
	CM_RequestMatchingTeamChangeLeader,		// ���ӳ�(��һ����)

	CM_RequestMatchingProgress,				//

	CM_RequestMatching,						// ����ƥ��
	CM_RequestCancelMatching,				// ����ƥ��

	CM_RequestLestPersonChannel,			// �����ٵ�Ƶ��

	CM_RequestIntoMatchingTeam,

	CM_RequestChangeMatchMap,				// �޸ĵ�ͼ
	CM_RequestChangeMatchGameType,				// �޸���Ϸ����


};


enum EAuthenticationState
{
	CLogin_Success,
	CLogin_Failed,
	CLogin_NeedNickName,
	CLogin_NickNameFailed,
};

REGISTER_PDE_TYPE(LobbyConnection::RpcCallback);

static void SpltCsv(const char *pBuffer, Core::Array<Core::String> &DataList, char cSplt = ',')
{
	char szBuffer[256];

	if (!pBuffer)
	{
		return;
	}

	const char* pPosStart = pBuffer;
	const char* pPosEnd = strchr(pPosStart, cSplt);

	while (pPosEnd)
	{
		int Len = pPosEnd - pPosStart;
		memcpy(szBuffer, pPosStart, Len);
		szBuffer[Len] = 0;

		Core::String tmp(szBuffer);

		tmp.Trim();
		if (tmp.Length() > 0)
			DataList.Add(tmp);

		pPosStart = pPosEnd + 1;
		pPosEnd = strchr(pPosStart, cSplt);
	}

	//last part
	Core::String tmp(pPosStart);
	tmp.Trim();
	if (tmp.Length() > 0)
		DataList.Add(tmp);
}

// -----------------------------------------------------------------
// LobbyConnection functions
// -----------------------------------------------------------------
// constructor.
LobbyConnection::LobbyConnection()
: rpc_request_count(0)
, rpc_request_id(0)
, uid(0)
, user_id(0)
, fcm_message_send_index(-1)
, fcm_message_send_timer_old(-1)
, m_dwMatchingGroupId(0)
, m_dwRoomId(0)
, m_dwSlotId(0)
{
	connection = this;
	stream = this;
}

// destructor
LobbyConnection::~LobbyConnection()
{
	bill_board_list.Clear();
}

// begin text rpc
int LobbyConnection::BeginTextRpc(const char * func, by_ptr(RpcCallback) callback)
{
	if (rpc_request_count > 0)
		return 0;

	rpc_request_id ++;
	rpc_request_count ++;
	rpc_callback = callback;

	BeginWrite();
	WriteByte(CM_RequestRPC);
	WriteInt(rpc_request_id);
	WriteString(func);

	//LogSystem.WriteLinef("BeginTextRpc : %d, %s", rpc_request_id, func);

	return rpc_request_id;
}

// add rpc argument
void LobbyConnection::TextRpcArgument(const char * key, const char * value)
{
	if (rpc_request_count > 0)
	{
		if (key && key[0])
		{
			WriteString(key);
			WriteString(value);
		}
	}
}

// end text rpc
void LobbyConnection::EndTextRpc()
{
	if (rpc_request_count > 0)
	{
		WriteString("");
		EndWrite();
	}
}


// request
void LobbyConnection::ResponseRPC()
{
	if (gGame)
	{
		uint id;

		ReadInt(id);
		rpc_request_count --;

		if (rpc_callback)
		{
			sharedc_ptr(RpcCallback) func = ptr_move(rpc_callback);
			Core::String result;
			ReadString(result);
			if(gGame->global)
				gGame->global->GetRealResult(result.Str(), result);

			//LogSystem.WriteLinef("ResponseRPC : %d, %s", id, result);

			(*func)(result);
		}
	}
}

// on message
void LobbyConnection::OnMessage()
{
	//ENCODE_START

	switch (state)
	{
#if USE_ENCODER
	case kConnected:
		{
			unsigned char key[8];
			Read(key, sizeof(key));
			des_encoder.SetKey(key, sizeof(key));

			encoder = &des_encoder;
			state = kAuthentication;
		}
		break;
#endif
	case kAuthentication:
		{
			int auth_state;
			byte ads_on;

			ReadInt(auth_state);
			ReadByte(ads_on);
			ReadInt(uid);
			ReadInt(user_id);
			character_id = user_id;
			gStartConfig.ads_on = ads_on == 0 ? false : true;

			tempc_ptr(StateLogin) login = ptr_dynamic_cast<StateLogin>(gGame->machine.CurrentState());

			if (uid && user_id && auth_state == CLogin_Success)
			{
				ReadString(user_name);
				ReadString(character_name);

				g_InGameInfo_collection.account = user_name;
				g_InGameInfo_collection.character_name = character_name;
				
				SystemInfoCollection & sys_collection = g_SystemInfo_collection;

				sys_collection.proxy_ip = gStartConfig.ip;

				sys_collection.proxy_port = gStartConfig.port;

				String configStream;
				ReadString(configStream);
				gGame->config->OnLoadConfig(configStream);
				ReadShort(gGame->account_type);

				// http ----
				{
					ReadString(gHttpConfig.http_xl_logo);
					ReadString(gHttpConfig.http_xl_report);
					ReadString(gHttpConfig.http_xl_info);

					ReadString(gHttpConfig.http_fcm);
					ReadString(gHttpConfig.http_gw);
					ReadString(gHttpConfig.http_advertising_v);
					ReadString(gHttpConfig.http_advertising_h);

					ReadString(gHttpConfig.http_paydraw);

					int length;
					ReadInt(length);

					int key = 0;
					String value;
					for (int i = 0; i < length; i++)
					{
						ReadInt(key);
						ReadString(value);
						gHttpConfig.http_pay_set.Add(key, value);
					}

					ReadString(gHttpConfig.achievement_list);
					SpltCsv(gHttpConfig.achievement_list, gGame->config->m_achievementlist, ',');

					ReadByte(gHttpConfig.nick_name_length_min);
					ReadByte(gHttpConfig.nick_name_length_max);
					ReadByte(gHttpConfig.battle_group_name_length_min);
					ReadByte(gHttpConfig.battle_group_name_length_max);
					ReadByte(gHttpConfig.room_name_length_min);
					ReadByte(gHttpConfig.room_name_length_max);
					ReadByte(gHttpConfig.time_sell_start);
					ReadByte(gHttpConfig.time_sell_start_date);
					ReadByte(gHttpConfig.time_sell_end);
					ReadByte(gHttpConfig.time_sell_end_date);
					ReadByte(gHttpConfig.time_sell_giftH);
					ReadByte(gHttpConfig.time_sell_giftM);
					ReadByte(gHttpConfig.time_sell_date);
					ReadString(gHttpConfig.buffversion);
					ReadString(gHttpConfig.quick_sell_data);
					ReadString(gHttpConfig.time_sell_gold);
					ReadString(gHttpConfig.time_sell_silver);
					ReadString(gHttpConfig.time_sell_cooper);

					ReadString(gHttpConfig.UISystemFlag);
					ReadByte(gStartConfig.xl_exe_open);
				}

				state = kInLogin;
				Console.WriteLine("Connected.");

				if (login)
				{
					login->uid = uid;
					login->character_id = user_id;
					login->OnLoginSuccess();
				}
			}
			else if(auth_state == CLogin_Failed)
			{
				if (login)
				{
					ReadString(gGame->error_message);
					gGame->global->Translate(gGame->error_message);
					if (gGame->error_message == String::kEmpty)
						gGame->error_message = "login_failed";


					login->OnLoginError();
				}
			}
			else if(auth_state == CLogin_NickNameFailed)
			{
				if (login)
				{
					ReadString(gGame->error_message);
					gGame->global->Translate(gGame->error_message);
					login->OnCreateNickNameFiled();
					// for zhiqiang
				}
			}
			else if(auth_state == CLogin_NeedNickName)
			{
				//RequestNickNameCreate(login_name);
				login->OnShowNickNameWin();
			}
		}
		break;

	case kInLogin:
		{
			byte msg;
			ReadByte(msg);

			switch (msg)
			{
			case SM_ResponseRPC:		ResponseRPC();			break;
			case SM_ResponseEnterLobby:	ResponseEnterLobby();	break;
			case SM_ForceDisconnect:	ForceDisconnect();		break;
			case SM_NotifyRPCMessage:	NotifyRPCMessage();		break;
#if ACTIVE_APEX
			case SM_ResponseApex:		OnResponseApex();			break;
#endif
			}
		}
		break;

	case kInChannel:
	case kInGame:
		{
			byte msg;
			ReadByte(msg);

			switch (msg)
			{
			case SM_ResponseRPC:			ResponseRPC();				break;
			case SM_ResponseLeaveLobby:		ResponseLeaveLobby();		break;
			case SM_NotifyChat:				NotifyChat();				break;
			case SM_NotifyFCM:				NotifyFCM();				break;
			case SM_ForceDisconnect:		ForceDisconnect();			break;
			case SM_ResponseTeamInvite:		ResponseTeamInvite();		break;
			case SM_ResponseTeamJoin:		ResponseTeamJoin();			break;
			case SM_NotifyTeamInvite:		NotifyTeamInvite();			break;
			case SM_NotifyTeamMemberJoin:	NotifyTeamMemberJoin();		break;
			case SM_NotifyTeamMemberLeave:	NotifyTeamMemberLeave();	break;
			case SM_NotifyTeamChangeLeader:	NotifyTeamChangeLeader();	break;
			case SM_NotifyTeamMemberInfo:	NotifyTeamMemberInfo();		break;
			case SM_NotifyTeamLeave:		NotifyTeamLeave();			break;
			case SM_NotifyTeamRefuse:		NotifyTeamRefuse();			break;
			case SM_NotifyRefusePreserve:	NotifyRefusePreserve();		break;
			case SM_NotifyRPCMessage:		NotifyRPCMessage();			break;
			case SM_ResponseEnterServer:	ResponseEnterServer();		break;
			case SM_ResponseLeaveServer:	ResponseLeaveServer();		break;
			case SM_NotifyRefreshServerList:NotifyRefreshServerList();	break;
			case SM_NotifyRefreshChannelList:NotifyRefreshChannelList();break;
			case SM_ResponseCharacterAddress:ResponseCharacterAddress();break;

			case SM_NotifyChatGroupInvite:	OnNotifyChatGroupInvite();break;
			case SM_NotifyChatGroupJoin:	OnNotifyChatGroupJoin();break;
			case SM_NotifyChatGroupLeave:	OnNotifyChatGroupLeave();break;
			case SM_NotifyChatGroupCall:	OnNotifyChatGroupCall();break;
			case SM_ResponseChatGroupCreate:	OnResponseChatGroupCreate();break;
			case SM_ResponseChatGroupMember:	OnResponseChatGroupMember();break;

			case SM_NotifyMultiChat:		OnNotifyMultiChat();break;
			case SM_NotifyLoopMsg:			OnNotifyLoopMsg();	break;
#if ACTIVE_APEX
			case SM_ResponseApex:			OnResponseApex();			break;
#endif
			case SM_ResponseBattleBattleGroups:		OnResponseBattleBattleGroups();	break;
			case SM_ResponseBattleGroupCreate:		OnResponseBattleGroupCreate();	break;
			case SM_ResponseBattleGroupJoin:		OnResponseBattleGroupJoin();	break;
			case SM_ResponseBattleGroupStartSearch:	OnResponseBattleGroupStartSearch();	break;
			case SM_ResponseBattleGroupChallenge:	OnResponseBattleGroupChallenge();	break;
			case SM_NotifyBattleGroupInvite:		OnNotifyBattleGroupInvite();	break;
			case SM_NotifyBattleGroupKick:			OnNotifyBattleGroupKick();		break;
			case SM_NotifyBattleGroupChange:		OnNotifyBattleGroupChange();	break;
			case SM_NotifyBattleGroupInfo:			OnNotifyBattleGroupInfo();		break;
			case SM_NotifyBattleGroupSearching:		OnNotifyBattleGroupSearching();	break;
			case SM_NotifyBattleGroupGameStart:		OnNotifyBattleGroupGameStart();	break;



			case SM_UpdateBillBoardInfo:			OnNotifyBillBoardInfo();		break;

				///ƥ��
			case SM_ResponseMatchingTeamCreate:		OnResponseMatchingTeamCreate();		break;
			case SM_ResponseMatchingTeamInvite:		OnResponseMatchingTeamInvite();     break;
			case SM_ResponseMatchingTeamJoin:		OnResponseMatchingTeamJoin();       break;
			case SM_ResponseMatchingTeamLeave:		OnResponseMatchingTeamLeave();      break;
			case SM_ResponseMatchingTeamKick:		OnResponseMatchingTeamKick();       break;
			case SM_ResponseMatchingTeamChangeLeader:OnResponseMatchingTeamChangeLeader();break;
			case SM_NotifyMatchingTeamInvite:		OnNotifyMatchingTeamInvite();       break;
			case SM_NotifyMatchingTeamMemberJoin:	OnNotifyMatchingTeamMemberJoin();  break;
			case SM_NotifyMatchingTeamMemberLeave:	OnNotifyMatchingTeamMemberLeave();break;
			case SM_NotifyMatchingTeamChangeLeader:	OnNotifyMatchingTeamChangeLeader();break;
			case SM_NotifyMatchingTeamMemberInfo:	OnNotifyMatchingTeamMemberInfo();  break;
			case SM_NotifyMatchingTeamLeave:		OnNotifyMatchingTeamLeave();            break;
			case SM_NotifyMatchingTeamKick:			OnNotifyMatchingTeamKick();             break;
			case SM_NotifyMatchingTeamChange:		OnNotifyMatchingTeamChange();         break;
			case SM_ResponseMatching:				OnResponseMatching();           	break;
			case SM_ResponseCancelMatching:			OnResponseCancelMatching();      	break;
			case SM_ResponseMatchingProgress:		OnResponseMatchingProgress();		break;
			case SM_NotifyPunishedNames:			OnNotifyPunishedNames();     		break;
			case SM_NotifyBeginMatch:				OnNotifyBeginMatch();		    	break;
			case SM_NotifyLeftPunishedTime:			On_NotifyLeftPunishedTime();			break;
			case SM_NotifyGoToMetchingRoom:			OnNotifyGoToMetchingRoom();				break;
			case SM_ResponseLestPersonChannel:		OnResponseLestPersonChannel();		break;

			}
		}
		break;

	case kInLobby:
		{
			byte msg;
			ReadByte(msg);

			switch (msg)
			{
			case SM_ResponseRPC:			ResponseRPC();				break;
			case SM_ResponseLeaveLobby:		ResponseLeaveLobby();		break;
			case SM_ResponseChannelConnect:	ResponseChannelConnect();	break;
			case SM_NotifyChat:				NotifyChat();				break;
			case SM_NotifyFCM:				NotifyFCM();				break;
			case SM_ForceDisconnect:		ForceDisconnect();			break;
			case SM_ResponseTeamInvite:		ResponseTeamInvite();		break;
			case SM_ResponseTeamJoin:		ResponseTeamJoin();			break;
			case SM_NotifyTeamInvite:		NotifyTeamInvite();			break;
			case SM_NotifyTeamMemberJoin:	NotifyTeamMemberJoin();		break;
			case SM_NotifyTeamMemberLeave:	NotifyTeamMemberLeave();	break;
			case SM_NotifyTeamChangeLeader:	NotifyTeamChangeLeader();	break;
			case SM_NotifyTeamMemberInfo:	NotifyTeamMemberInfo();		break;
			case SM_NotifyTeamLeave:		NotifyTeamLeave();			break;
			case SM_NotifyTeamRefuse:		NotifyTeamRefuse();			break;
			case SM_NotifyRoomPreserve:		NotifyRoomPreserve();			break;
			case SM_NotifyRoomCancelPreserve:NotifyRoomCancelPreserve();	break;
			case SM_ResponseTeamCall:		ResponseTeamCall();		break;
			case SM_ResponseSearchRoom:		ResponseSearchRoom();	break;
			case SM_NotifyTeamCall:			NotifyTeamCall();		break;
			case SM_NotifyUpdateLevelList:	NotifyUpdateLevelList();	break;
			case SM_NotifyRefusePreserve:	NotifyRefusePreserve();	break;
			case SM_NotifyRPCMessage:		NotifyRPCMessage();			break;
			case SM_ResponseEnterServer:	ResponseEnterServer();		break;
			case SM_ResponseLeaveServer:	ResponseLeaveServer();		break;
			case SM_NotifyRefreshServerList:NotifyRefreshServerList();	break;
			case SM_NotifyRefreshChannelList:NotifyRefreshChannelList();break;
			case SM_ResponseCharacterAddress:ResponseCharacterAddress();break;

			case SM_NotifyChatGroupInvite:	OnNotifyChatGroupInvite();break;
			case SM_NotifyChatGroupJoin:	OnNotifyChatGroupJoin();break;
			case SM_NotifyChatGroupLeave:	OnNotifyChatGroupLeave();break;
			case SM_NotifyChatGroupCall:	OnNotifyChatGroupCall();break;
			case SM_ResponseChatGroupCreate:	OnResponseChatGroupCreate();break;
			case SM_ResponseChatGroupMember:	OnResponseChatGroupMember();break;

			case SM_NotifyMultiChat:		OnNotifyMultiChat();break;
			case SM_NotifyLoopMsg:			OnNotifyLoopMsg();	break;
#if ACTIVE_APEX
			case SM_ResponseApex:			OnResponseApex();			break;
#endif
			case SM_ResponseBattleBattleGroups:		OnResponseBattleBattleGroups();	break;
			case SM_ResponseBattleGroupCreate:		OnResponseBattleGroupCreate();	break;
			case SM_ResponseBattleGroupJoin:		OnResponseBattleGroupJoin();	break;
			case SM_ResponseBattleGroupStartSearch:	OnResponseBattleGroupStartSearch();	break;
			case SM_ResponseBattleGroupChallenge:	OnResponseBattleGroupChallenge();	break;
			case SM_NotifyBattleGroupInvite:		OnNotifyBattleGroupInvite();	break;
			case SM_NotifyBattleGroupKick:			OnNotifyBattleGroupKick();		break;
			case SM_NotifyBattleGroupChange:		OnNotifyBattleGroupChange();	break;
			case SM_NotifyBattleGroupInfo:			OnNotifyBattleGroupInfo();		break;
			case SM_NotifyBattleGroupSearching:		OnNotifyBattleGroupSearching();	break;
			case SM_NotifyBattleGroupGameStart:		OnNotifyBattleGroupGameStart();	break;



			case SM_UpdateBillBoardInfo:			OnNotifyBillBoardInfo();		break;

			
		    ///ƥ��
			case SM_ResponseMatchingTeamCreate:		OnResponseMatchingTeamCreate();		break;
			case SM_ResponseMatchingTeamInvite:		OnResponseMatchingTeamInvite();     break;
			case SM_ResponseMatchingTeamJoin:		OnResponseMatchingTeamJoin();       break;
			case SM_ResponseMatchingTeamLeave:		OnResponseMatchingTeamLeave();      break;
			case SM_ResponseMatchingTeamKick:		OnResponseMatchingTeamKick();       break;
			case SM_ResponseMatchingTeamChangeLeader:OnResponseMatchingTeamChangeLeader();break;
			case SM_NotifyMatchingTeamInvite:		OnNotifyMatchingTeamInvite();       break;
			case SM_NotifyMatchingTeamMemberJoin:	OnNotifyMatchingTeamMemberJoin();  break;
			case SM_NotifyMatchingTeamMemberLeave:	OnNotifyMatchingTeamMemberLeave();break;
			case SM_NotifyMatchingTeamChangeLeader:	OnNotifyMatchingTeamChangeLeader();break;
			case SM_NotifyMatchingTeamMemberInfo:	OnNotifyMatchingTeamMemberInfo();  break;
			case SM_NotifyMatchingTeamLeave:		OnNotifyMatchingTeamLeave();            break;
			case SM_NotifyMatchingTeamKick:			OnNotifyMatchingTeamKick();             break;
			case SM_NotifyMatchingTeamChange:		OnNotifyMatchingTeamChange();         break;
			case SM_ResponseMatching:				OnResponseMatching();           	break;
			case SM_ResponseCancelMatching:			OnResponseCancelMatching();      	break;
			case SM_ResponseMatchingProgress:		OnResponseMatchingProgress();		break;
			case SM_NotifyPunishedNames:			OnNotifyPunishedNames();     		break;
			case SM_NotifyBeginMatch:				OnNotifyBeginMatch();		    	break;
			case SM_NotifyLeftPunishedTime:			On_NotifyLeftPunishedTime();			break;
			case SM_NotifyGoToMetchingRoom:			OnNotifyGoToMetchingRoom();				break;
			case SM_ResponseLestPersonChannel:		OnResponseLestPersonChannel();		break;



			}
		}
		break;
	}

	//ENCODE_END
}

static void LoadGameDescription(Core::HashSet<byte, Core::String> & description_set)
{
	// do game type scripts
	CStrBuf<256> filename("/level/game_type.lua");

	sharedc_ptr(ScriptLua) lua = RESOURCE_LOAD(filename, false, ScriptLua);

	if (lua)
	{
		Lua::LuaState *L = Lua::LuaState::NewState();
		int top = L->GetTop();
		L->NewTable();

		if (L->LoadBuffer(lua->GetBuffer(), lua->GetSize(), filename) == 0)
		{
			L->PushValue(top + 1);
			L->SetFenv(-2);
			if (L->DoCall(0, 0))
			{
				const char *msg = L->ToString(-1);
				if (msg) Console.WriteLine(msg);
				L->Pop(1);
			}
			else
			{
				description_set.Clear();
				L->GetField(top + 1, "game_type");

				int size = L->ObjLen(-1);

				for (int i = 0; i < size; i++)
				{
					L->GetField(-1, i + 1);
					description_set.Add((const RoomOption::GameType&)i, L->ToString(-1));
					L->Pop(1);
				}
			}
		}
		else
		{
			const char *msg = L->ToString(-1);
			if (msg) Console.WriteLine(msg);
			L->Pop(1);
		}
		L->Close();
	}
}

// on connected
void LobbyConnection::OnConnected()
{
	//ENCODE_START

	tempc_ptr(StateLogin) login = ptr_dynamic_cast<StateLogin>(gGame->machine.CurrentState());

	if (login)
		login->OnConnected();

#if USE_ENCODER
	xor_encoder.Reset();
	des_encoder.Reset();
	encoder = &xor_encoder;
#endif

	BeginWrite();
	WriteInt(network_version);
	WriteString(gGame->version);
	WriteString(login_name);

	if (gGame->use_luncher)
	{
		//--write xlcheckinfo
		if (gStartConfig.authentication_code == "" && 
			gStartConfig.login_code == "")
		{
			MessageBoxA(NULL, gLang->GetTextWLocal(L"��ӵ�½������"),gLang->GetTextWLocal(L"����"), MB_OK); 
			Core::Thread::Quit(); 
			return;
		}

		WriteString(gStartConfig.authentication_code);
		WriteString(gStartConfig.login_code);
	}
	else
	{
		WriteString("");
		WriteString("");
	}

#if USE_ENCODER
	unsigned char key[8];
	des_encoder.GetKey(key, sizeof(key));
	Write(key, sizeof(key));
#endif
	EndWrite();

	gGame->error_message = "login_failed";


#if USE_ENCODER
	state = kConnected;
#else
	state = kAuthentication;
#endif

	// update game type info
	LoadGameDescription(game_description_set);

	if(m_SquadPanel)
	{
		m_SquadPanel->SetParent(NullPtr);
		m_SquadPanel = NullPtr;
	}
	m_SquadPanel = ptr_new Gui::SquadPanel;

	//ENCODE_END
}

// on disconnected
void LobbyConnection::OnDisconnected(bool is_error)
{
	state = kDisconnected;
	encoder = NULL;

	if (gGame->error_message == String::kEmpty)
		gGame->error_message = "disconnected";

	if(m_SquadPanel)
	{
		m_SquadPanel->SetParent(NullPtr);
		m_SquadPanel = NullPtr;
	}

	m_CharacterProfile = NullPtr;
	m_RememberLobby = NullPtr;

	ResetCharacterTimer();
	character_name.Clear();
	character_gender = 0;
	character_group.Clear();
	character_level = 0;
}


// request enter lobby
void LobbyConnection::RequestEnterLobby(uint character_id)
{
	if (state == kInLogin)
	{
		BeginWrite();
		WriteByte(CM_RequestEnterLobby);
		//WriteInt(character_id);
		EndWrite();
	}
}

void LobbyConnection::RequestNickNameCreate(const String& name)
{
	BeginWrite();
	WriteString(name);
	EndWrite();
}
// request leave lobby
void LobbyConnection::RequestLeaveLobby()
{
	if (state > kInLogin)
	{
		BeginWrite();
		WriteByte(CM_RequestLeaveLobby);
		EndWrite();
	}
}

// request channel connect
void LobbyConnection::RequestChannelConnect(int channel_id)
{
	if (state == kInLobby)
	{
		LogSystem.WriteLinef("will connect to channel id : %d !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!", channel_id);
		BeginWrite();
		WriteByte(CM_RequestChannelConnect);
		WriteInt(channel_id);
		EndWrite();
	}
}

// response enter lobby
void LobbyConnection::ResponseEnterLobby()
{
	state = kInLobby;

	byte firstgame;
	byte is_vip;
	byte net_bar_level;
	byte business_card;
	byte is_gm;
	byte playerchecktoday;

	int  size;

	Core::String head_icon;
	if(!m_CharacterProfile)
	{
		m_CharacterProfile = ptr_new CharacterProfile;
	}
	ReadByte(firstgame);
	ReadByte(is_vip);
	ReadByte(net_bar_level);
	ReadByte(business_card);
	ReadByte(is_gm);
	ReadString(head_icon);
	ReadByte(playerchecktoday);

	ReadInt(size);

	for (int i = 0; i < size; i++)
	{
		String str;
		ReadString(str);
		bill_board_list.Add(str);
	}
// 	ReadInt(character_id);
// 	ReadString(character_name);
// 	ReadInt(character_gender);
// 	ReadString(character_group);
// 	ReadInt(character_level);

// 	String profileStream;
// 	ReadString(profileStream);
// 
// 	gGame->config->OnLoadProfile(profileStream);

	ResetCharacterTimer();

	tempc_ptr(StateLogin) state_login = ptr_dynamic_cast<StateLogin>(gGame->machine.CurrentState());

	if (state_login)
	{
		state_login->ResponseEnterLobby(character_id, playerchecktoday);
	}
}

// response leave lobby
void LobbyConnection::ResponseLeaveLobby()
{
	state = kInLogin;
	ResetCharacterTimer();
	m_CharacterProfile = NullPtr;
	character_name.Clear();
	character_gender = 0;
	character_group.Clear();
	character_level = 0;
}

// response channel connect
void LobbyConnection::ResponseChannelConnect()
{
	//ENCODE_START

	int result;
	int channel_id;
	ushort port;
	char address[512] = {0};
	byte istcp = false;

	ReadInt(result);

	if (result == kErrorNone)
	{
		ReadInt(channel_id);
		ReadShort(port);
		ReadString(address, sizeof(address));
		ReadByte(istcp);

		tempc_ptr(StateLobby) lobby = ptr_dynamic_cast<StateLobby>(gGame->machine.CurrentState());

		if (lobby)
		{
			// create channel connection
			gGame->channel_connection = ptr_new ChannelConnection;
			gGame->channel_connection->lobby_uid = uid;
			gGame->channel_connection->character_id = gGame->lobby_connection->character_id;
			int cid = gGame->lobby_connection->character_id;
			gGame->channel_connection->character_name = gGame->lobby_connection->character_name;
			Core::String strName = gGame->lobby_connection->character_name;
			gGame->channel_connection->client_connecting = true;

			if (istcp)
			{
				gGame->channel_connection->connection = &gGame->channel_connection->tcp_connection;
				gGame->channel_connection->tcp_connection.stream = gGame->channel_connection;
				gGame->channel_connection->udp_connection.stream = NULL;
				gGame->channel_connection->tcp_connection.ConnectHost(address, port);

				LogSystem.WriteLinef("Connecting channel %s:%d, tcp_mode", address, port);
			}
			else
			{
				gGame->channel_connection->connection = &gGame->channel_connection->udp_connection;
				gGame->channel_connection->tcp_connection.stream = NULL;
				gGame->channel_connection->udp_connection.stream = gGame->channel_connection;
				gGame->channel_connection->udp_connection.ConnectHost(address, port);

				LogSystem.WriteLinef("Connecting channel %s:%d, udp_mode", address, port);
			}
		}
	}
	else
	{
		LogSystem.WriteLinef("connect channel failed, result = %d", result);
	}

	tempc_ptr(StateLobby) lobby = ptr_dynamic_cast<StateLobby>(gGame->machine.CurrentState());
	if (lobby)
		lobby->EventEnterChannel.Fire(ptr_static_cast<StateLobby>(lobby), RetEventArgs(result));

	//ENCODE_END
}


// request chat
void LobbyConnection::RequestChat(const Core::Identifier & to, const Core::String & msg)
{
	if (state > kInLogin)
	{

		if (msg.Length() > 0)
		{
			CStrBuf<character_name_length> to_str(to.Str());
			CStrBuf<chat_length> msg_str(msg.Str());
			msg_str.validate();

			BeginWrite();
			WriteByte(CM_RequestChat);
			WriteString(to_str);
			WriteString(msg_str);
			EndWrite();
		}
	}
}

// response chat
void LobbyConnection::NotifyChat()
{
	CStrBuf<character_name_length> channel;
	CStrBuf<character_name_length> name;
	CStrBuf<chat_length> msg;

	ReadString(channel);
	ReadString(name);
	ReadString(msg);

	if (gGame)
	{
		ChatMessage m;
		m.channel = channel;
		m.sender = name;
		m.msg = msg;

		gGame->machine.OnChat(m);
	}
}

// notify fcm
void LobbyConnection::NotifyFCM()
{
	int current = 0;
	ReadInt(current);
	
	tempc_ptr(StateLobby) lobby = ptr_dynamic_cast<StateLobby>(gGame->machine.CurrentState());
	if(lobby)
		lobby->m_fcm_online_time = current;

	int offline_minutes = 0;
	ReadInt(offline_minutes);

	int fcm_flag = 0;
	ReadInt(fcm_flag);
	gGame->fcm_flag = fcm_flag;
	const char * message = NULL;
	int flash_time = 0;

	LogSystem.WriteLinef("NotifyFCM: %d  %d", current, offline_minutes);
	static struct notify
	{
		int time;
		String message;
		int play_time;
	}
	notifies [] =
	{
		{ 0,	"", 1},
		{ 60,	gLang->GetTextW(L"���ۼ�����ʱ������1Сʱ��"), 10},
		{ 120,	gLang->GetTextW(L"���ۼ�����ʱ������2Сʱ��"), 10},
		{ 180,	gLang->GetTextW(L"���ۼ�����ʱ������3Сʱ, ���Ѿ�����ƣ����Ϸʱ�䣬������Ϸ���潫��Ϊ����ֵ��50����Ϊ�����Ľ������뾡��������Ϣ�����ʵ���������������ѧϰ���"), 5},
		{ 210,	gLang->GetTextW(L"���Ѿ�����ƣ����Ϸʱ�䣬������Ϸ���潫��Ϊ����ֵ��50����Ϊ�����Ľ������뾡��������Ϣ�����ʵ���������������ѧϰ���"), 5},
		{ 240,	gLang->GetTextW(L"���Ѿ�����ƣ����Ϸʱ�䣬������Ϸ���潫��Ϊ����ֵ��50����Ϊ�����Ľ������뾡��������Ϣ�����ʵ���������������ѧϰ���"), 5},
		{ 270,	gLang->GetTextW(L"���Ѿ�����ƣ����Ϸʱ�䣬������Ϸ���潫��Ϊ����ֵ��50����Ϊ�����Ľ������뾡��������Ϣ�����ʵ���������������ѧϰ���"), 5},
		{ 300,	gLang->GetTextW(L"���ѽ��벻������Ϸʱ�䣬Ϊ�����Ľ�������������������Ϣ���粻���ߣ��������彫�ܵ��𺦣����������ѽ�Ϊ�㣬ֱ�������ۼ�����ʱ����5Сʱ�󣬲��ָܻ�������"), 5},
	};

		if (current >= 300)
	{
		if ((Task::GetTotalTime() - fcm_message_send_timer_old >= 900) || fcm_message_send_timer_old == -1)
		{
			fcm_message_send_timer_old = Task::GetTotalTime();
			message = notifies[7].message;
			fcm_message_send_index = current;
			for (int i = 0 ; i < notifies[7].play_time; i++)
			{
				gGame->machine.OnFCM(current, message);
			}
			tempc_ptr(StateLobby) lobby = ptr_dynamic_cast<StateLobby>(gGame->machine.CurrentState());
			if(lobby)
			{
				lobby->EventFCM_MAX.Fire(ptr_static_cast<StateLobby>(lobby), RetEventArgs());
			}
		}
	}
	else
	{
		for (int i = 0; i < ELEMENTS_OF(notifies); i ++)
		{
			if (current >= notifies[i].time && current < notifies[i+1].time && fcm_message_send_index < i)
			{
				message = notifies[i].message;
				fcm_message_send_index = i;
				for (int j = 0 ; j < notifies[i].play_time; j++)
				{
					gGame->machine.OnFCM(current, message);
				}	
				break;
			}
		}

	}
}

// force disconnect
void LobbyConnection::ForceDisconnect()
{
	ReadString(gGame->error_message);
	Disconnect();
}

// team invite
void LobbyConnection::RequestTeamInvite(const Core::String & name)
{
	if (name == character_name)
	{
		gGame->global->SystemMessage(String::Format(gLang->GetTextW(L"�㲻�������Լ����")), "/info");
	}
	else if(black_list.Contains(name))
	{
		gGame->global->SystemMessage(String::Format(gLang->GetTextW(L"%s ����ĺ������У��޷�����"), name), "/info");
	}
	else
	{
		BeginWrite();
		WriteByte(CM_RequestTeamInvite);
		WriteString(name);

		gGame->global->SystemMessage(String::Format(gLang->GetTextW(L"����%s�������������"),name), "/info");

		EndWrite();
	}
}


// team join
void LobbyConnection::RequestTeamJoin(const Core::String & name, uint uid)
{
	BeginWrite();
	WriteByte(CM_RequestTeamJoin);
	WriteString(name);
	WriteInt(uid);
	EndWrite();
}

// team leave
void LobbyConnection::RequestTeamLeave()
{
	BeginWrite();
	WriteByte(CM_RequestTeamLeave);
	EndWrite();
}

// team kick
void LobbyConnection::RequestTeamKick(const Core::String & name)
{
	BeginWrite();
	WriteByte(CM_RequestTeamKick);
	WriteString(name);
	EndWrite();
}

// team change leader
void LobbyConnection::RequestTeamChangeLeader(const Core::String & name)
{
	BeginWrite();
	WriteByte(CM_RequestTeamChangeLeader);
	WriteString(name);
	EndWrite();

}

// request team refuse
void LobbyConnection::RequestTeamRefuse(const Core::String & name, uint uid)
{
	BeginWrite();
	WriteByte(CM_RequestTeamRefuse);
	WriteString(name);
	WriteInt(uid);
	EndWrite();
}

// request team call
void LobbyConnection::RequestTeamCall(const Core::String & name)
{
	if (gGame->global->GetClientAddress().room_id > 0)
	{
		BeginWrite();
		WriteByte(CM_RequestTeamCall);
		WriteString(name);
		EndWrite();
		gGame->global->SystemMessage(String::Format(gLang->GetTextW(L"����%s�������ٻ�"), name), "/info");
	}
}

// request search room
void LobbyConnection::RequestSearchRoom(RoomSearchOptions & options)
{
	BeginWrite();
	WriteByte(CM_RequestSearchRoom);
	WriteByte(options.all_channels);
	WriteInt(options.game_type);
	WriteInt(options.level_id);
	WriteByte(options.num_clients);
	WriteByte(options.playing);
	WriteByte(options.waiting);
	EndWrite();
}
// request search room
void LobbyConnection::RequestCancelSearchRoom()
{
	BeginWrite();
	WriteByte(CM_RequestCancelSearchRoom);
	EndWrite();
}



// response team invite
void LobbyConnection::ResponseTeamInvite()
{
	int result;
	String name;

	ReadInt(result);
	ReadString(name);

	switch(result)
	{
	case kErrorNone:
		{
			gGame->global->SystemMessage(String::Format(gLang->GetTextW(L"��%s����������ѷ���"), name), "/info");
		}
		break;
	case kErrorProxyTeamInviteAlreadyInTeam:
		{
			gGame->global->SystemMessage(String::Format(gLang->GetTextW(L"%s�Ѿ������С����"), name), "/info");
		}
		break;
	case kErrorProxyTeamInviteAlreadyInOtherTeam:
		{
			gGame->global->SystemMessage(String::Format(gLang->GetTextW(L"%s�Ѿ��ڱ��С����"), name), "/info");
		}
		break;
	case kErrorProxyTeamInviteNotTeamLeader:
		{
			gGame->global->SystemMessage(String::Format(gLang->GetTextW(L"���Ѿ���С���ﵫ���Ƕӳ������ܷ�������")), "/info");
		}
		break;
	case kErrorProxyTeamInviteTeamFull:
		{
			gGame->global->SystemMessage(String::Format(gLang->GetTextW(L"���С�������������ٷ�������")), "/info");
		}
		break;
	case kErrorProxyTeamInviteClientError:
		{
			gGame->global->SystemMessage(String::Format(gLang->GetTextW(L"%s������"), name), "/info");
		}
		break;
	case kErrorProxyTeamInviteSelf:
		{
			gGame->global->SystemMessage(String::Format(gLang->GetTextW(L"�㲻�������Լ����")), "/info");
		}
		break;
	default:
		{
			gGame->global->SystemMessage(String::Format(gLang->GetTextW(L"����ʧ��"), name), "/info");
		}
		break;
	}

	gGame->machine.OnResponseTeamInvite(name, result);
	LogSystem.WriteLinef("team invite: %d, %s", result, name.Str());
}

// response team invite
void LobbyConnection::ResponseTeamJoin()
{
	int result;
	String leader_name;

	ReadInt(result);

	if (result == kErrorNone)
	{
		ReadString(leader_name);

		for (uint i = 0; i < team_members.Size(); i ++)
		{
			if (leader_name == team_members[i].name)
			{
				team_members[i].leader = true;
			}
		}
	}

	switch (result)
	{
	case kErrorNone:
		{
			if(leader_name!=gGame->lobby_connection->character_name)
				gGame->global->SystemMessage(String::Format(gLang->GetTextW(L"�������%s��С��"), leader_name), "/info");
		}
		break;
	case kErrorProxyTeamJoinLeaderError:
		{
			gGame->global->SystemMessage(String::Format(gLang->GetTextW(L"С�Ӷӳ����ֲ���")), "/info");
		}
		break;
	case kErrorProxyTeamJoinLeaderIdError:
		{
			gGame->global->SystemMessage(String::Format(gLang->GetTextW(L"С�Ӷӳ�ID����")), "/info");
		}
		break;
	case kErrorProxyTeamJoinMemberError:
		{
			gGame->global->SystemMessage(String::Format(gLang->GetTextW(L"С�ӳ�Ա���ִ���")), "/info");
		}
		break;
	case kErrorProxyTeamJoinTeamFull:
		{
			gGame->global->SystemMessage(String::Format(gLang->GetTextW(L"С���������޷�����")), "/info");
		}
		break;
	default:
		{
			gGame->global->SystemMessage(String::Format(gLang->GetTextW(L"����С����δ֪ԭ��ʧ��")), "/info");
		}
		break;
	}

	gGame->machine.OnResponseTeamJoin(leader_name, result);
	LogSystem.WriteLinef("team join: %d, %s", result, leader_name.Str());
}

// notify team invite
void LobbyConnection::NotifyTeamInvite()
{
	String name;
	uint uid;

	ReadString(name);
	ReadInt(uid);
	if(m_CharacterProfile && m_CharacterProfile->GetInviteOff())
		RequestTeamRefuse(name, uid);
	else if (black_list.Contains(name))
	{
		RequestTeamRefuse(name, uid);
		gGame->global->SystemMessage(String::Format(gLang->GetTextW(L"���յ��˺������е� %s ��������룬���Զ��ܾ�"), name), "/info");
	}
	else
		gGame->machine.OnTeamInvite(name, uid);

	LogSystem.WriteLinef("team invite: %d, %s", uid, name.Str());

	tempc_ptr(Character) c = gLevel->GetViewer();
	if(c && m_CharacterProfile && m_CharacterProfile->GetInviteOff() == false)
	{
		c->team_request_waittime = 10.0f;
		c->team_request_username = name;
		c->team_request_uid = uid;
	}
}

// notify team member join
void LobbyConnection::NotifyTeamMemberJoin()
{
	TeamMember & member = team_members.PushBack();
	member.leader = false;
	ReadString(member.name);
	ReadByte(member.gender);
	ReadInt(member.level);
	ReadInt(member.exp);
	ReadString(member.group);
	ReadInt(member.address.server_id);
	member.address.server_id = 1;
	ReadInt(member.address.channel_id);
	ReadInt(member.address.room_id);
	ReadInt(member.state);

	if(member.name!=character_name)
		gGame->global->SystemMessage(String::Format(gLang->GetTextW(L"%s������С��"), member.name), "/info");

	gGame->machine.OnTeamMemberJoin(member);
	LogSystem.WriteLinef("team member join: %s", member.name.Str());

	tempc_ptr(Character) c = gLevel->GetViewer();
	if(c && member.name == c->team_request_username)
	{
		c->team_success_join_time = 3.0f;
		c->team_request_username = member.name;
	}
}

// notify team member leave
void LobbyConnection::NotifyTeamMemberLeave()
{
	String name;
	ReadString(name);

	for (uint i = 0; i < team_members.Size(); i ++)
	{
		if (name == team_members[i].name)
		{
			team_members.RemoveAt(i);
			break;
		}
	}
	if(name!=character_name)
		gGame->global->SystemMessage(String::Format(gLang->GetTextW(L"%s�뿪��С��"),name), "/info");

	gGame->machine.OnTeamMemberLeave(name);
	LogSystem.WriteLinef("team member leave : %s", name.Str());
}

// notify team change leader
void LobbyConnection::NotifyTeamChangeLeader()
{
	String name;

	ReadString(name);

	for (uint i = 0; i < team_members.Size(); i ++)
	{
		if (name == team_members[i].name)
		{
			team_members[i].leader = true;
		}
		else
		{
			team_members[i].leader = false;
		}
	}
	gGame->machine.OnTeamChangeLeader(name);
	LogSystem.WriteLinef("team change leader : %s", name.Str());
}

// notify team member info
void LobbyConnection::NotifyTeamMemberInfo()
{
	String name;

	ReadString(name);

	for (uint i = 0; i < team_members.Size(); i ++)
	{
		TeamMember & member = team_members[i];

		if (name == member.name)
		{
			ReadByte(member.gender);
			ReadInt(member.level);
			ReadInt(member.exp);
			ReadString(member.group);
			ReadInt(member.address.server_id);
			member.address.server_id = 1;
			ReadInt(member.address.channel_id);
			ReadInt(member.address.room_id);
			ReadInt(member.state);
			gGame->machine.OnTeamMemberInfo(member);
		}
	}
	LogSystem.WriteLinef("team member info change : %s", name.Str());
}

// notify team change leader
void LobbyConnection::NotifyTeamLeave()
{
	team_members.Clear();

	gGame->global->SystemMessage(String::Format(gLang->GetTextW(L"���뿪��С��")), "/info");

	gGame->machine.OnTeamLeave();
	LogSystem.WriteLinef("team leave");
}

// notify team change leader
void LobbyConnection::NotifyTeamRefuse()
{
	String name;

	ReadString(name);

	gGame->global->SystemMessage(String::Format(gLang->GetTextW(L"%s�ܾ��������������趨Ϊ���������"), name), "/info");

	LogSystem.WriteLinef("team refuse : %s", name.Str());
}

// notify room preserve
void LobbyConnection::NotifyRoomPreserve()
{
	uint server_id;
	uint channel_id;
	ushort room_id;
	byte slot_id;
	String invite_name;

	server_id = 1;
	ReadInt(channel_id);
	ReadShort(room_id);
	ReadByte(slot_id);
	ReadString(invite_name);

	tempc_ptr(StateLobby) lobby = ptr_dynamic_cast<StateLobby>(gGame->machine.CurrentState());
	if(lobby)
	{
		lobby->OnTeamRoomPreserve(server_id, channel_id, room_id, slot_id, invite_name);
	}

	LogSystem.WriteLinef("room preserve : %d-%d-%d %s", channel_id, room_id, slot_id, invite_name.Str());
}

// notify room cancel preserve
void LobbyConnection::NotifyRoomCancelPreserve()
{
	uint server_id;
	uint channel_id;
	ushort room_id;
	byte slot_id;
	String invite_name;

	server_id = 1;
	ReadInt(channel_id);
	ReadShort(room_id);
	ReadByte(slot_id);

	tempc_ptr(StateLobby) lobby = ptr_dynamic_cast<StateLobby>(gGame->machine.CurrentState());
	if(lobby)
	{
		lobby->OnTeamRoomCancelPreserve(server_id, channel_id, room_id, slot_id);
	}

	LogSystem.WriteLinef("room cancel preserve : %d-%d-%d", server_id, channel_id, room_id, slot_id);
}

// response team call
void LobbyConnection::ResponseTeamCall()
{
	int result;
	ReadInt(result);
}

// response team call
void LobbyConnection::NotifyTeamCall()
{
	Core::String leader_name;
	ClientAddress address;

	ReadString(leader_name);
	ReadInt(address.server_id);
	ReadInt(address.channel_id);
	ReadInt(address.room_id);

	tempc_ptr(StateLobby) lobby = ptr_dynamic_cast<StateLobby>(gGame->machine.CurrentState());
	if(lobby)
	{
		lobby->OnTeamRoomCall(address.server_id, address.channel_id, address.room_id, leader_name);
	}

	LogSystem.WriteLinef("team call: %s, %d-%d-%d", leader_name.Str(), address.server_id, address.channel_id, address.room_id);
}

// response search room
void LobbyConnection::ResponseSearchRoom()
{
	byte result;
	ReadByte(result);

	if (result == 0)
	{
		uint server_id;
		uint channel_id;
		uint room_id;

		ReadInt(server_id);
		ReadInt(channel_id);
		ReadInt(room_id);

		LogSystem.WriteLinef("response search room: %d, %d, %d", server_id, channel_id, room_id);
	
		tempc_ptr(StateLobby) lobby = ptr_dynamic_cast<StateLobby>(gGame->machine.CurrentState());
	
		if(lobby)
			lobby->EventSearchRoom.Fire(ptr_static_cast<StateLobby>(lobby), RetEventArgs3(server_id, channel_id, room_id));
	}
	else
	{
		LogSystem.WriteLinef("response search room: %d", result);

		tempc_ptr(StateLobby) lobby = ptr_dynamic_cast<StateLobby>(gGame->machine.CurrentState());

		if(lobby)
			lobby->EventSearchRoom.Fire(ptr_static_cast<StateLobby>(lobby), RetEventArgs3(0, 0, 0));
	}
}

// notify update level list
void LobbyConnection::NotifyUpdateLevelList()
{
	LogSystem.WriteLinef("2321NotifyUpdateLevelList");
	int level_count = 0;
	ReadInt(level_count);
	level_list.Clear();

	if (level_count > 0)
	{
		level_list.Reserve(level_count);

		for (int i = 0; i < level_count; i++)
		{
			sharedc_ptr(LevelInfo) info = ptr_new LevelInfo;

			LevelInfo& test = *info;

			ReadInt(info->id);
			ReadString(info->name);
			ReadByte((byte&)info->type);

			ReadString(info->show_name);
			ReadString(info->description);

			ReadByte(info->is_vip);
			ReadByte(info->is_new);

			ReadInt(info->gai_lv);
			ReadByte(info->is_gm);

			if(gGame->global)
				gGame->global->Translate(info->show_name);
			
			level_list.PushBack(info);
		}
	}

	tempc_ptr(StateLobby) lobby = ptr_dynamic_cast<StateLobby>(gGame->machine.CurrentState());

	if (lobby)
	{
		lobby->OnUpdateLevelList();
	}
}

// request refuse preserve
void LobbyConnection::RequestRefusePreserve(const char * caller, int server_id, int channel_id, int room_id, uint result)
{
	BeginWrite();
	WriteByte(CM_RequestRefusePreserve);
	WriteString(caller);
	WriteInt(channel_id);
	WriteInt(room_id);
	WriteInt(result);
	EndWrite();
}

// request enter server
void LobbyConnection::RequestEnterServer(int server_id)
{
	BeginWrite();
	WriteByte(CM_RequestEnterServer);
	WriteInt(server_id);
	EndWrite();
}

// request leave server
void LobbyConnection::RequestLeaveServer()
{
	BeginWrite();
	WriteByte(CM_RequestLeaveServer);
	EndWrite();
}

// request enter server
void LobbyConnection::RequestEnterChannel(int server_id)
{
}

// notify refuse call
void LobbyConnection::NotifyRefusePreserve()
{
	Core::String name;
	uint result;
	ReadInt(result);
	ReadString(name);

	//LogSystem.WriteLinef("notify result preserve : %s(%d)", name.Str(), result);
}

// notify refuse call
void LobbyConnection::NotifyRPCMessage()
{
	Core::String message;
	ReadString(message);
	if (gGame && gGame->global)
	{
		gGame->global->GetRealResult(message.Str(), message);
	}
	
	tempc_ptr(StateLobby) lobby = ptr_dynamic_cast<StateLobby>(gGame->machine.CurrentState());

	if(lobby)
		lobby->OnRPCMessage(message);
	else
		lost_rpc_message.PushBack(message);

	//LogSystem.WriteLinef("notify rpc message : %s", message.Str());
}

// response enter server
void LobbyConnection::ResponseEnterServer()
{
	int result;
	uint server_id;
	Core::String server_name;

	ReadInt(result);
	ReadInt(server_id);
	ReadString(server_name);

	gGame->address.server_id = server_id;
	gGame->address.server_name = server_name;
	LogSystem.WriteLinef("BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB111111111111:%d", gGame->address.server_id);
	LogSystem.WriteLinef("BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB22222222222:%s",gGame->address.server_name);
	gGame->global->SystemMessage(String::Format(gLang->GetTextW(L"�����������%s"), server_name), "/info");

	tempc_ptr(StateLobby) lobby = ptr_dynamic_cast<StateLobby>(gGame->machine.CurrentState());

	if(lobby)
		lobby->OnEnterServer(result);

	ServerInfo* pInfo = NULL;
	for (int i = 0; i < server_list.GetCount(); ++i)
	{
		if (server_list[i].id == server_id)
		{
			pInfo = &server_list[i];
		}
	}
	
	if (pInfo && lobby->m_Is_in_invite == false)
	{
		if (pInfo->servertype == SvrType_Match  )// SvrType_Match
		{
			RequestLestPersonChannel(server_id);
		}
	}
	if (pInfo && lobby->m_Is_in_invite1 == false)
	{
		if (pInfo->servertype == SvrType_MatchFighting)// SvrType_Match
		{
			RequestLestPersonChannel(server_id);
		}
	}
	

	LogSystem.WriteLinef("response enter server, result = %d, id = %d", result, server_id);
}

// response leave server
void LobbyConnection::ResponseLeaveServer()
{
	gGame->global->SystemMessage(String::Format(gLang->GetTextW(L"�뿪��������%s"), gGame->address.server_name), "/info");

	gGame->address.server_id = 0;
	gGame->address.channel_id = 0;
	gGame->address.room_id = 0;
	gGame->address.server_name = "";
	gGame->address.channel_name = "";

	tempc_ptr(StateLobby) lobby = ptr_dynamic_cast<StateLobby>(gGame->machine.CurrentState());

	if(lobby)
		lobby->OnLeaveServer(0);
}

// notify refresh server list
void LobbyConnection::NotifyRefreshServerList()
{
	uint server_count;
	ReadInt(server_count);
	server_list.Resize(server_count);
	for (uint i = 0; i < server_count; i ++)
	{
		ServerInfo & s = server_list[i];

		ReadInt(s.id);
		ReadString(s.name);
		ReadInt(s.online_count);
		ReadInt(s.online_max);
		ReadByte(s.isnovice);
		ReadString(s.gametype_limit);
		uint dwServerType = 0;
		ReadInt(dwServerType);
		s.servertype = (Client::ServerType)dwServerType;
		

		ReadInt(s.nMinLevel);
		ReadInt(s.nMaxLevel);
		ReadInt(s.Channelcount);
	}
	
	tempc_ptr(StateLobby) lobby = ptr_dynamic_cast<StateLobby>(gGame->machine.CurrentState());

	if (lobby)
	{
		lobby->OnUpdateServerList();
	}
}

// notify refresh channel list
void LobbyConnection::NotifyRefreshChannelList()
{
	uint channel_count;
	ReadInt(channel_count);

	channel_list.Resize(channel_count);

	for (uint i = 0; i < channel_count; i ++)
	{
		byte is_online;
		ChannelInfo & c = channel_list[i];

		ReadInt(c.id);
		ReadString(c.name);
		ReadByte(is_online);
		ReadInt(c.online_count);
		ReadInt(c.online_max);
		ReadInt(c.min_level);
		ReadInt(c.max_level);

		c.online = is_online != 0;
	}

	tempc_ptr(StateLobby) lobby = ptr_dynamic_cast<StateLobby>(gGame->machine.CurrentState());

	if (lobby)
	{
		lobby->OnUpdateChannelList();
	}
}

// response character address
void LobbyConnection::ResponseCharacterAddress()
{
	uint userdata;
	Core::String name;
	byte online;
	ClientAddress address;

	ReadInt(userdata);
	ReadString(name);
	ReadByte(online);
	ReadInt(address.server_id);
	ReadInt(address.channel_id);
	ReadInt(address.room_id);
	ReadString(address.server_name);
	ReadString(address.channel_name);

	tempc_ptr(StateLobby) lobby = ptr_dynamic_cast<StateLobby>(gGame->machine.CurrentState());

	if (lobby)
	{
		lobby->OnAddressArrived(userdata, name, online, address);
	}
}

//  on notify chatgroup invite
void LobbyConnection::OnNotifyChatGroupInvite()
{
	uint chatgroup_uid;
	Core::String creater_name;
	Core::String name;

	ReadInt(chatgroup_uid);
	ReadString(creater_name);
	ReadString(name);

	tempc_ptr(StateLobby) lobby = ptr_dynamic_cast<StateLobby>(gGame->machine.CurrentState());

	if(lobby)
	{
		TepGroupEventArgs m;
		m.Group_id = chatgroup_uid;
		m.Groupname = creater_name;
		m.name = name;
		lobby->OnInviteGroup(m);
	}
}

// on notify chatgroup join
void LobbyConnection::OnNotifyChatGroupJoin()
{
	uint chatgroup_uid;
	Core::String name;
	byte is_vip;
	byte net_bar_level;
	byte business_card;
	byte is_gm;

	ReadInt(chatgroup_uid);
	ReadString(name);
	ReadByte(is_vip);
	ReadByte(net_bar_level);
	ReadByte(business_card);
	ReadByte(is_gm);

	if (gGame && chatgroup_uid != 0)
	{
		ChatMessage m;
		m.channel = Core::Identifier("/TepGroup");
		m.group = NULL;
		m.sender = NULL;
		m.msg = Core::String::Format(gLang->GetTextW(L"%s������ʱ������!"),name);
		m.group_id = chatgroup_uid;

		gGame->machine.OnChat(m);
	}
	if(chatgroup_uid == 0)
	{
		TepGroupMemberEventArgs m;

		tempc_ptr(StateLobby) lobby = ptr_dynamic_cast<StateLobby>(gGame->machine.CurrentState());

		if(lobby)
		{
			lobby->OnGetGroupMember(m);
		}

	}
	else
	{
		RequestChatGroupMember(chatgroup_uid);
	}
}

//  on notify chatgroup leave
void LobbyConnection::OnNotifyChatGroupLeave()
{
	uint chatgroup_uid;
	Core::String name;

	ReadInt(chatgroup_uid);
	ReadString(name);
	
	if (gGame)
	{
		ChatMessage m;
		m.channel = Core::Identifier("/TepGroup");
		m.group = NULL;
		m.sender = NULL;
		m.msg = Core::String::Format(gLang->GetTextW(L"%s�뿪��ʱ������!"),name);
		m.group_id = chatgroup_uid;

		gGame->machine.OnChat(m);
	}
	RequestChatGroupMember(chatgroup_uid);
}

// on notify chatgroup call
void LobbyConnection::OnNotifyChatGroupCall()
{
	uint chatgroup_uid;
	Core::String name;
	Core::String msg;

	ReadInt(chatgroup_uid);
	ReadString(name);
	ReadString(msg);

	if (gGame)
	{
		ChatMessage m;
		m.channel = Core::Identifier("/TepGroup");
		m.group_id = chatgroup_uid;
		m.sender = name;
		m.msg = msg;

		gGame->machine.OnChat(m);
	}
}

// on response chatgroup create
void LobbyConnection::OnResponseChatGroupCreate()
{
	uint chatgroup_uid;
	Core::String creater_name;

	ReadInt(chatgroup_uid);
	ReadString(creater_name);

	tempc_ptr(StateLobby) lobby = ptr_dynamic_cast<StateLobby>(gGame->machine.CurrentState());
	if(lobby)
	{
		TepGroupEventArgs m;
		m.name = creater_name;
		m.Group_id = chatgroup_uid;
		lobby->OnCreateGroup(m);
	}
}

// on response chatgroup member
void LobbyConnection::OnResponseChatGroupMember()
{
	uint chatgroup_uid;

	uint member_size;
	uint member_id;
	Core::String member_name;
	byte is_vip;
	byte net_bar_level;
	byte business_card;
	byte is_gm;

	ReadInt(chatgroup_uid);
	ReadInt(member_size);

	tempc_ptr(StateLobby) lobby = ptr_dynamic_cast<StateLobby>(gGame->machine.CurrentState());
	if (!lobby)
	{
		return;
	}
	
	TepGroupMemberEventArgs m;
	m.Group_id = chatgroup_uid;	
	for (uint i = 0; i < 5; i++)
	{
		if (i < member_size)
		{
			ReadInt(member_id);
			ReadString(member_name);
			ReadByte(is_vip);
			ReadByte(net_bar_level);
			ReadByte(business_card);
			ReadByte(is_gm);
			m.MemberName = member_name;
			m.MemberName_id = member_id;
			m.MemberName_vip = is_vip;
			m.MemberName_business_card = business_card;
			m.MemberName_net_bar_level = net_bar_level;
		} 
		m.num_which = i + 1;
		lobby->OnGetGroupMember(m);
		m.MemberClear();
	}
}

// on notify multichat
void LobbyConnection::OnNotifyMultiChat()
{
	CStrBuf<character_name_length> name;
	CStrBuf<group_name_length> group;
	CStrBuf<chat_length> msg;
	uint server_Type;

	ReadString(name);
	ReadString(group);
	ReadString(msg);
	ReadInt(server_Type);

	if (gGame)
	{
		ChatMessage m;
		if(group == "/InvitePlayer")
		{
			m.channel = Core::Identifier("/InvitePlayer");
			m.sender = name;
			m.server_Type = server_Type;
		}
		else if(group == "/RefuseInvite")
		{
			m.channel = Core::Identifier("/info");
			m.msg = Core::String::Format(gLang->GetTextW(L"%s�ܾ����������!"),name);
		}
		else
		{
			m.channel = Core::Identifier("/Group");
			m.group = group;
			m.sender = name;
			m.msg = msg;
		}

		gGame->machine.OnChat(m);
	}
}

void LobbyConnection::OnNotifyLoopMsg()
{
	int size;
	CStrBuf<character_name_length> name;
		
	ReadInt(size);
	for (int i = 0; i < size; i++)
	{
		ReadString(name);
		expired_weapon_name.Add(name);
	}
}
 
// request refresh server list
void LobbyConnection::RequestRefreshServerList()
{
	BeginWrite();
	WriteByte(CM_RequestRefreshServerList);
	EndWrite();
}

// request refresh server list
void LobbyConnection::RequestRefreshChannelList()
{
	BeginWrite();
	WriteByte(CM_RequestRefreshChannelList);
	EndWrite();
}


// request character address
void LobbyConnection::RequestCharacterAddress(const char * name, uint userdata)
{
	BeginWrite();
	WriteByte(CM_RequestCharacterAddress);
	WriteInt(userdata);
	WriteString(name);
	EndWrite();
}

void LobbyConnection::RequestChangeMatchMap( uint dwLevelId )
{
	BeginWrite();
	WriteByte(CM_RequestChangeMatchMap);
	WriteInt(dwLevelId);
	EndWrite();
}

void LobbyConnection::RequestChangeMatchGameType( byte cGameType )
{
	BeginWrite();
	WriteByte(CM_RequestChangeMatchGameType);
	WriteByte(cGameType);
	EndWrite();
}


void LobbyConnection::UpdateCharacterTimer( F32 frameTime )
{
	character_timer+=frameTime;
}

void LobbyConnection::ResetCharacterTimer()
{
	character_timer = 0.f;
}

F32 LobbyConnection::GetCharacterTimer()
{
	return character_timer;
}

void LobbyConnection::RestoreToStateLobby()
{
	if(m_RememberLobby)
		gGame->machine.ChangeState(m_RememberLobby);
	else
	{
		PDE_ASSERT(false, "No remembered StateLobby, Can not restore");
		gGame->machine.ChangeState(ptr_new StateSelectCharacter);
	}

	if(gGame && gGame->channel_connection)
	{

		switch (gGame->channel_connection->GetState())
		{
		case ChannelConnection::kInReplay:
			gGame->channel_connection->OnEnterChannel();
			break;
		default:
			tempc_ptr(StateLobby) lobbyState = ptr_static_cast<StateLobby>(gGame->machine.CurrentState());
			ServerInfo* pInfo = NULL;
			for (int i = 0; i < gGame->lobby_connection->server_list.GetCount(); ++i)
			{
				if (gGame->lobby_connection->server_list[i].id == gGame->address.server_id)
				{
					pInfo = &gGame->lobby_connection->server_list[i];
				}
			}

			if (lobbyState)
			{
				if (lobbyState->m_is_fight_team_server)
				{

				}
				else if (pInfo && pInfo->servertype == SvrType_Match || pInfo->servertype == SvrType_MatchFighting )
				{
					if (gGame->channel_connection)
					{
						gGame->channel_connection->Disconnect();
					}
				}
				else
				{
					gGame->channel_connection->OnEnterRoom();
				}
			}

			break;
		}

		if (gGame->global->m_FightQuit)
		{
			tempc_ptr(StateLobby) lobbyState = ptr_static_cast<StateLobby>(gGame->machine.CurrentState());
			if (lobbyState)
			{
				lobbyState->RestoreUI();
				Core::LogSystem.WriteLinef(gLang->GetTextW(L"�˳�����"));
				lobbyState->OnQuitInGame();
				return;
			}
		}		
	}

	tempc_ptr(StateLobby) lobbyState = ptr_static_cast<StateLobby>(gGame->machine.CurrentState());
	if(lobbyState)
	{
		lobbyState->RestoreUI();
	}
}

void LobbyConnection::RequestSaveConfig( const Core::String& configStream )
{
	BeginWrite();
	WriteByte(CM_SaveUserProfile);
	WriteString(configStream);
	EndWrite();
}

void LobbyConnection::RequestSaveCharacterProfile( const Core::String& profileStream )
{
	BeginWrite();
	WriteByte(CM_SaveCharacterProfile);
	WriteString(profileStream);
	EndWrite();
}

void LobbyConnection::RequestChatGroupCreate()
{
	BeginWrite();
	WriteByte(CM_RequestChatGroupCreate);
	EndWrite();
}

void LobbyConnection::RequestChatGroupInvite(uint chatgroup_uid, const Core::String& name)
{
	BeginWrite();
	WriteByte(CM_RequestChatGroupInvite);
	WriteInt(chatgroup_uid);
	WriteString(name);
	EndWrite();
}

void LobbyConnection::RequestChatGroupJoin(uint chatgroup_uid)
{
	BeginWrite();
	WriteByte(CM_RequestChatGroupJoin);
	WriteInt(chatgroup_uid);
	EndWrite();
}

void LobbyConnection::RequestChatGroupLeave(uint chatgroup_uid)
{
	BeginWrite();
	WriteByte(CM_RequestChatGroupLeave);
	WriteInt(chatgroup_uid);
	EndWrite();
}

void LobbyConnection::RequestChatGroupCall(uint chatgroup_uid, const Core::String& msg)
{
	BeginWrite();
	WriteByte(CM_RequestChatGroupCall);
	WriteInt(chatgroup_uid);
	WriteString(msg);
	EndWrite();
}

void LobbyConnection::RequestChatGroupMember(uint chatgroup_uid)
{
	BeginWrite();
	WriteByte(CM_RequestChatGroupMember);
	WriteInt(chatgroup_uid);
	EndWrite();
}

void LobbyConnection::NotifyMultiChat(const Core::String& group, const Core::String& msg, const Core::Array<Core::String>& names)
{
	BeginWrite();
	WriteByte(CM_NotifyMultiChat);
	WriteString(group);
	WriteString(msg);
	WriteInt((uint)names.Size());
	for (U32 i = 0; i < names.Size(); i++)
	{
			WriteString(names[i]);
	}
	EndWrite();
}

void LobbyConnection::CollectionInGameInfo()
{
	//��ʱ���ռ�
	return;
	InGameInfoCollection& collection = g_InGameInfo_collection;

	if(gGame->config)
		collection.full_screen = gGame->config->GetFullScreen() ? 1 : 0;

	if(gGame->screen)
	{
		Vector2 size = gGame->guiSys->GetSize();
		collection.screen_size = Core::String::Format("%dx%d",(int)size.x ,(int)size.y);
	}
	
	uint counter = 0;
	for(uint i = 0; i < collection.average_ping_array.Size(); i++)
	{
		counter += (uint)collection.average_ping_array.GetAt(i);
	}

	if (collection.average_ping_array.Size() > 0)
		collection.average_ping = counter / collection.average_ping_array.Size();
	else
		collection.average_ping = 0;
	collection.average_ping_array.Clear();

}

void LobbyConnection::RequestBattleGroups(const Core::String& group_name, uint start, uint count, byte is_searchonly)
{
	BeginWrite();
	WriteByte(CM_RequestBattleGroups);
	WriteString(group_name);
	WriteInt(start);
	WriteInt(count);
	WriteByte(is_searchonly);
	EndWrite();
}

void LobbyConnection::RequestBattleGroupCreate(uint server_id, uint channel_id, uint room_id, RoomOption &roomoption)
{
	BeginWrite();
	WriteByte(CM_RequestBattleGroupCreate);
	WriteInt(server_id);
	WriteInt(channel_id);
	WriteInt(room_id);
	WriteRoomOption(*this, roomoption);
	EndWrite();
}

void LobbyConnection::RequestBattleGroupInvite(const Core::String& name)
{
	BeginWrite();
	WriteByte(CM_RequestBattleGroupInvite);
	WriteString(name);
	EndWrite();
}

void LobbyConnection::RequestBattleGroupJoin(uint battlegroup_uid)
{
	BeginWrite();
	WriteByte(CM_RequestBattleGroupJoin);
	WriteInt(battlegroup_uid);
	EndWrite();
}

void LobbyConnection::RequestBattleGroupLeave(uint battlegroup_uid)
{
	BeginWrite();
	WriteByte(CM_RequestBattleGroupLeave);
	WriteInt(battlegroup_uid);
	EndWrite();
}

void LobbyConnection::RequestBattleGroupInfo(uint battlegroup_uid)
{
	BeginWrite();
	WriteByte(CM_RequestBattleGroupInfo);
	WriteInt(battlegroup_uid);
	EndWrite();
}

void LobbyConnection::RequestBattleGroupReady()
{
	BeginWrite();
	WriteByte(CM_RequestBattleGroupReady);
	EndWrite();
}

void LobbyConnection::RequestBattleGroupStartSearch(byte is_cancel)
{
	BeginWrite();
	WriteByte(CM_RequestBattleGroupStartSearch);
	WriteByte(is_cancel);
	EndWrite();
}

void LobbyConnection::RequestBattleGroupChallenge(uint battlegroup_uid)
{
	BeginWrite();
	WriteByte(CM_RequestBattleGroupChallenge);
	WriteInt(battlegroup_uid);
	EndWrite();
}

 //ƥ��

void LobbyConnection::RequestMatchingTeamCreate( uint server_id, uint channel_id, uint room_id, RoomOption &roomop )
{
	BeginWrite();
	WriteByte(CM_RequestMatchingTeamCreate);
	WriteInt(server_id);
	WriteInt(channel_id);
	WriteInt(room_id);
	WriteRoomOption(*this, roomop);
	EndWrite();
}

void  LobbyConnection::RequestMatchingTeamJoin( uint chatgroup_uid )
{
	BeginWrite();
	WriteByte(CM_RequestMatchingTeamJoin);
	WriteInt(chatgroup_uid);
	EndWrite();
}

void  LobbyConnection::RequestMatchingTeamInvite( const Core::String& name)
{
	BeginWrite();
	WriteByte(CM_RequestMatchingTeamInvite);
	WriteString(name);
	EndWrite();
}

void  LobbyConnection::RequestMatchingTeamLeave()
{
	BeginWrite();
	WriteByte(CM_RequestMatchingTeamLeave);
	EndWrite();
}

void  LobbyConnection::RequestMatchingTeamKick()
{
	BeginWrite();
	WriteByte(CM_RequestMatchingTeamKick);
	EndWrite();
}
void  LobbyConnection::RequestMatchingTeamChangeLeader()
{
	BeginWrite();
	WriteByte(CM_RequestMatchingTeamChangeLeader);
	EndWrite();
}

void  LobbyConnection::RequestMatchingProgress()
{
	BeginWrite();
	WriteByte(CM_RequestMatchingProgress);
	EndWrite();
}

void  LobbyConnection::RequestMatching()
{
	BeginWrite();
	WriteByte(CM_RequestMatching);
	EndWrite();
}

void  LobbyConnection::RequestCancelMatching()
{
	BeginWrite();
	WriteByte(CM_RequestCancelMatching);
	EndWrite();
}

void  LobbyConnection::RequestLestPersonChannel(uint server_id)
{
	BeginWrite();
	WriteByte(CM_RequestLestPersonChannel);
	WriteInt(server_id);
	EndWrite();
}

void LobbyConnection::IntoMatchingTeam(String name)
{
	BeginWrite();
	WriteByte(CM_RequestIntoMatchingTeam);
	WriteString(name);
	EndWrite();
}
void LobbyConnection::OnResponseBattleBattleGroups()
{
	uint battlegroup_id;
	uint battle_server_id;
	uint battle_channel_id;
	uint battle_room_id;
	RoomOption roomoption;
	uint ownerclient_uid;
	uint group_level;
	uint group_id;
	Core::String group_name;
	tempc_ptr(StateLobby) lobby = ptr_dynamic_cast<StateLobby>(gGame->machine.CurrentState());
	Core::String vs_group_name;
	int all_group_num = 0;
	if (lobby)
	{
		//lobby->m_battle_room = ptr_new BattleRoom();
		//for (int i= 0 ; i < 6 ; i++)
		//{
		//	lobby->m_battle_room->player[i].client_uid = -1;
		//	lobby->m_battle_room->player[i].character_name = "";
		//	lobby->m_battle_room->player[i].head_icon = "";
		//	lobby->m_battle_room->player[i].character_level = 0;
		//	lobby->m_battle_room->player[i].is_vip = 0;
		//	lobby->m_battle_room->player[i].net_bar_level = 0;
		//	lobby->m_battle_room->player[i].business_card = 0;
		//}
		lobby->m_zhihuisuo_num = 1;
	
	
		do
		{
			ReadInt(battlegroup_id);
			if (battlegroup_id !=0)
			{
				all_group_num++;
				ReadInt(battle_server_id);
				ReadInt(battle_channel_id);
				ReadInt(battle_room_id);
				ReadRoomOption(*this, roomoption);
				ReadInt(ownerclient_uid);
				ReadInt(group_level);
				ReadInt(group_id);
				ReadString(group_name);
				ReadString(vs_group_name);
				lobby->m_b_player_info = ptr_new BattlePlayerInfo();
				lobby->m_b_player_info->battlegroup_id = battlegroup_id;

				lobby->m_b_player_info->battle_server_id = battle_server_id;
				lobby->m_b_player_info->battle_channel_id = battle_channel_id;
				lobby->m_b_player_info->battle_room_id = battle_room_id;
				lobby->m_b_player_info->roomoption = roomoption;
				lobby->m_b_player_info->ownerclient_uid = ownerclient_uid;
				lobby->m_b_player_info->group_level = group_level;
				lobby->m_b_player_info->group_id = group_id;
				lobby->m_b_player_info->group_name = group_name;
				lobby->m_b_player_info->vs_group_name = vs_group_name;
				uint client_size;
				ReadInt(client_size);
				lobby->m_b_player_info->client_size = client_size;

				lobby->m_battle_room = ptr_new BattleRoom();
				for (int i= 0 ; i < 6 ; i++)
				{
					lobby->m_battle_room->player[i].client_uid = -1;
					lobby->m_battle_room->player[i].character_name = "";
					lobby->m_battle_room->player[i].head_icon = "";
					lobby->m_battle_room->player[i].character_level = 0;
					lobby->m_battle_room->player[i].is_vip = 0;
					lobby->m_battle_room->player[i].net_bar_level = 0;
					lobby->m_battle_room->player[i].business_card = 0;
				}

				for (uint i = 0; i < client_size; i++)
				{
					uint client_uid;
					Core::String character_name;
					Core::String head_icon;
					uint character_level;
					int character_exp;
					byte is_vip;
					byte net_bar_level;
					byte business_card;
					byte is_gm;
					byte is_ready;
					ReadInt(client_uid);
					ReadString(character_name);
					ReadString(head_icon);
					ReadInt(character_level);
					ReadInt(character_exp);
					ReadByte(is_vip);
					ReadByte(net_bar_level);
					ReadByte(business_card);
					ReadByte(is_gm);
					ReadByte(is_ready);

					lobby->m_battle_room->player[i].client_uid = client_uid;
					lobby->m_battle_room->player[i].character_name = character_name;
					lobby->m_battle_room->player[i].head_icon = head_icon;
					lobby->m_battle_room->player[i].character_level = character_level;
					lobby->m_battle_room->player[i].character_exp = character_exp;
					lobby->m_battle_room->player[i].is_vip = is_vip;
					lobby->m_battle_room->player[i].net_bar_level = net_bar_level;
					lobby->m_battle_room->player[i].business_card = business_card;
					lobby->m_battle_room->player[i].is_ready = is_ready;
				}
				if (lobby->m_tiaozhan_request == false)
				{
					lobby->EventSaveZhihuisuo.Fire(ptr_static_cast<StateLobby>(lobby), RetEventArgs());
				}
				else
				{
					lobby->EventSaveTiaoZhan.Fire(ptr_static_cast<StateLobby>(lobby), RetEventArgs());
				}
			}
		}
		while (battlegroup_id != 0);

		if (lobby->m_tiaozhan_request == false)
		{
			lobby->EventFillZhihuisuo.Fire(ptr_static_cast<StateLobby>(lobby), RetEventArgs(all_group_num));
		}
		else
		{
			lobby->EventFillTiaoZhan.Fire(ptr_static_cast<StateLobby>(lobby), RetEventArgs(all_group_num));
		}
		lobby->m_tiaozhan_request = false;
	}
}

void LobbyConnection::OnResponseBattleGroupCreate()
{
	uint battlegroup_id;
	ReadInt(battlegroup_id);
	tempc_ptr(StateLobby) lobby = ptr_dynamic_cast<StateLobby>(gGame->machine.CurrentState());
	if(lobby)
	{
		lobby->m_b_player_info = ptr_new BattlePlayerInfo();
		lobby->m_b_player_info->battlegroup_id = battlegroup_id;
		if(battlegroup_id != 0)
		{
			lobby->EnterFightCreatrRoomSuccess.Fire(ptr_static_cast<StateLobby>(lobby), RetEventArgs());
		}
		else
		{
			if(lobby)
			{
				lobby->OnLeaveServer(0);
			}
			lobby->m_is_fight_team_server = false;
		}
	}
	RequestBattleGroupInfo(battlegroup_id);
}

void LobbyConnection::OnResponseBattleGroupJoin()
{
	byte is_ok;
	uint battlegroup_id;
	uint server_id;
	uint channel_id;
	uint room_id;

	ReadByte(is_ok);
	ReadInt(battlegroup_id);
	ReadInt(server_id);
	ReadInt(channel_id);
	ReadInt(room_id);

	tempc_ptr(StateLobby) lobby = ptr_dynamic_cast<StateLobby>(gGame->machine.CurrentState());
	if (is_ok)
	{
		if(lobby)
		{
			LogSystem.WriteLinef("lobby->m_is_fight_team_server:%d", lobby->m_is_fight_team_server);
			lobby->m_b_player_info = ptr_new BattlePlayerInfo();
			lobby->m_b_player_info->battlegroup_id = battlegroup_id;
			lobby->m_is_fight_team_server = true;
			lobby->AutoChangeRoomWithPassword(server_id,channel_id,room_id,"sdfgde");
			lobby->EnterFightRoomSuccess.Fire(ptr_static_cast<StateLobby>(lobby), RetEventArgs());
		}
		RequestBattleGroupInfo(battlegroup_id);
	}
	else
	{
		if (lobby)
		{
			lobby->EnterFightRoomError.Fire(ptr_static_cast<StateLobby>(lobby), RetEventArgs());
		}
	}
}

void LobbyConnection::OnResponseBattleGroupStartSearch()
{
	byte is_ok;
	uint battlegroup_id;
	
	ReadByte(is_ok);
	ReadInt(battlegroup_id);
}

void LobbyConnection::OnResponseBattleGroupChallenge()
{
	byte is_ok;
	uint battlegroup_id;
	
	ReadByte(is_ok);
	ReadInt(battlegroup_id);
	LogSystem.WriteLinef("is_ok : %d",is_ok);
	if(is_ok == 0)
	{
		tempc_ptr(StateLobby) lobby = ptr_dynamic_cast<StateLobby>(gGame->machine.CurrentState());
		if (lobby)
		{
			for(int i = 9 ;i<15 ; i++)
			{
				lobby->ChangeSlotStatus(i,0);
			}
		}
	}
}

void LobbyConnection::OnNotifyBattleGroupInvite()
{
	uint battlegroup_id;
	String name;

	ReadInt(battlegroup_id);
	ReadString(name);
	TepGroupEventArgs ret;
	ret.Group_id = battlegroup_id;
	ret.name = name;
	tempc_ptr(StateLobby) lobby = ptr_dynamic_cast<StateLobby>(gGame->machine.CurrentState());
	if (lobby)
	{
		lobby->NotifyBattleGroupInvite.Fire(ptr_static_cast<StateLobby>(lobby), TepGroupEventArgs(ret));
	}
}

void LobbyConnection::OnNotifyBattleGroupKick()
{
	uint battlegroup_id;

	ReadInt(battlegroup_id);

	tempc_ptr(StateLobby) lobby = ptr_dynamic_cast<StateLobby>(gGame->machine.CurrentState());
	if (lobby)
	{
		lobby->NotifyBattleGroupKick.Fire(ptr_static_cast<StateLobby>(lobby), RetEventArgs());
	}
}

void LobbyConnection::OnNotifyBattleGroupChange()
{
	uint battlegroup_id;
	ReadInt(battlegroup_id);
	RequestBattleGroupInfo(battlegroup_id);
}

void LobbyConnection::OnNotifyBillBoardInfo()
{
	Core::String str;
	bool flag;
	ReadString(str);
	ReadByte((Byte&)flag);
	bill_board_list.Add(str);

	if(flag)
	{
		bill_board_list.RemoveAt(0);
	}
	
}


//ƥ��
void LobbyConnection::OnResponseMatchingTeamCreate()
{
	uint matchid;
	ReadInt(matchid);
	m_dwMatchingGroupId = matchid;

	//RequestMatching();
}

void LobbyConnection::OnResponseMatchingTeamInvite()
{

}

void LobbyConnection::OnResponseMatchingTeamJoin()
{

}

void LobbyConnection::OnResponseMatchingTeamLeave()
{

}

void LobbyConnection::OnResponseMatchingTeamKick()
{

}

void LobbyConnection::OnResponseMatchingTeamChangeLeader()
{

}

void LobbyConnection::OnNotifyMatchingTeamInvite()
{
	uint Match_id;
	Core::String Match_name;
	ReadInt(Match_id);
	ReadString(Match_name);
	tempc_ptr(StateLobby) lobby = ptr_dynamic_cast<StateLobby>(gGame->machine.CurrentState());
	if (lobby)
	{
		lobby->OnAddMatch(Match_id, Match_name);
	}
}

void LobbyConnection::OnNotifyMatchingTeamMemberJoin()
{

}

void LobbyConnection::OnNotifyMatchingTeamMemberLeave()
{

}

void LobbyConnection::OnNotifyMatchingTeamChangeLeader()
{

}

void LobbyConnection::OnNotifyMatchingTeamMemberInfo()
{

}

void LobbyConnection::OnNotifyMatchingTeamLeave()
{

}

void LobbyConnection::OnNotifyMatchingTeamKick()
{

}

void LobbyConnection::OnNotifyMatchingTeamChange()
{

}

void LobbyConnection::OnResponseMatching()
{

}

void LobbyConnection::OnResponseCancelMatching()
{
	tempc_ptr(StateLobby) lobby = ptr_dynamic_cast<StateLobby>(gGame->machine.CurrentState());
	if (lobby)
	{
		lobby->EventCancelMatch.Fire(ptr_static_cast<StateLobby>(lobby), RetEventArgs());
	}

}

void LobbyConnection::OnResponseMatchingProgress()
{

}

void LobbyConnection::OnNotifyPunishedNames()
{
	
}

void LobbyConnection::OnNotifyBeginMatch()
{
	tempc_ptr(StateLobby) lobby = ptr_dynamic_cast<StateLobby>(gGame->machine.CurrentState());  
	if (lobby)
	{
		lobby->EventMatch.Fire(ptr_static_cast<StateLobby>(lobby), RetEventArgs());
	}
}

void LobbyConnection::On_NotifyLeftPunishedTime()
{

}

void LobbyConnection::OnNotifyGoToMetchingRoom()
{
	uint dwServerId = 0;
	uint dwChannelId = 0;
	uint dwRoomId = 0;
	uint dwSlotId = 0;

	ReadInt(dwServerId);
	ReadInt(dwChannelId);
	ReadInt(dwRoomId);
	ReadInt(dwSlotId);

	LogSystem.WriteLinef("%s, %s, goto matchingroom, serverid : %d, channel id : %d, room id : %d slot id : %d", __FILE__, __FUNCTION__, dwServerId, dwChannelId, dwRoomId, dwSlotId);
	// todo ��Ϊ�Ѿ���ƥ�����
	if (gGame->address.channel_id == dwChannelId)
	{
		if(gGame && gGame->channel_connection)
		{
			{
				LogSystem.WriteLinef("%s, %s room_id : %d, slot_id : %d", __FILE__, __FUNCTION__, dwRoomId, dwSlotId);
				gGame->channel_connection->RequestRoomEnterWithSlotId(dwRoomId, dwSlotId);
			}
		}
	}
	else
	{
		RequestChannelConnect(dwChannelId);

		m_dwRoomId = dwRoomId;
		m_dwSlotId = dwSlotId;
	}
}

void LobbyConnection::OnResponseLestPersonChannel()
{
	uint battle_server_id;
	uint battle_channel_id;
	ReadInt(battle_server_id);
	ReadInt(battle_channel_id);

	if (gGame->lobby_connection)
	{
		gGame->lobby_connection->RequestChannelConnect(battle_channel_id);
	}
	
}

void LobbyConnection::OnNotifyBattleGroupInfo()
{
	uint battlegroup_id;
	uint battle_server_id;
	uint battle_channel_id;
	uint battle_room_id;
	RoomOption roomoption;
	uint ownerclient_uid;
	uint group_id;
	uint group_level;
	Core::String group_name;
	Core::String vs_group_name;
	tempc_ptr(StateLobby) lobby = ptr_dynamic_cast<StateLobby>(gGame->machine.CurrentState());
	if (lobby)
	{
		lobby->m_battle_room = ptr_new BattleRoom();
		for (int i= 0 ; i < 6 ; i++)
		{
			lobby->m_battle_room->player[i].client_uid = -1;
			lobby->m_battle_room->player[i].character_name = "";
			lobby->m_battle_room->player[i].head_icon = "";
			lobby->m_battle_room->player[i].character_level = 0;
			lobby->m_battle_room->player[i].is_vip = 0;
			lobby->m_battle_room->player[i].net_bar_level = 0;
			lobby->m_battle_room->player[i].business_card = 0;
		}
		ReadInt(battlegroup_id);
		ReadInt(battle_server_id);
		ReadInt(battle_channel_id);
		ReadInt(battle_room_id);
		ReadRoomOption(*this, roomoption);
		ReadInt(ownerclient_uid);
		ReadInt(group_level);
		ReadInt(group_id);
		ReadString(group_name);
		ReadString(vs_group_name);
		lobby->m_b_player_info = ptr_new BattlePlayerInfo();
		lobby->m_b_player_info->battlegroup_id = battlegroup_id;
		lobby->m_b_player_info->battle_server_id = battle_server_id;
		lobby->m_b_player_info->battle_channel_id = battle_channel_id;
		lobby->m_b_player_info->battle_room_id = battle_room_id;
		lobby->m_b_player_info->roomoption = roomoption;
		LogSystem.WriteLinef("roomoption: %d",roomoption.game_type);
		lobby->m_b_player_info->ownerclient_uid = ownerclient_uid;
		lobby->m_b_player_info->group_level = group_level;
		lobby->m_b_player_info->group_name = group_name;
		lobby->m_b_player_info->vs_group_name = vs_group_name;

		uint client_size;
		ReadInt(client_size);
		lobby->m_b_player_info->client_size = client_size;
		for (uint i = 0; i < client_size; i++)
		{
			uint client_uid;
			Core::String character_name;
			Core::String head_icon;
			uint character_level;
			int character_exp;
			byte is_vip;
			byte net_bar_level;
			byte business_card;
			byte is_gm;
			byte is_ready;

			ReadInt(client_uid);
			ReadString(character_name);
			ReadString(head_icon);
			ReadInt(character_level);
			ReadInt(character_exp);
			ReadByte(is_vip);
			ReadByte(net_bar_level);
			ReadByte(business_card);
			ReadByte(is_gm);
			ReadByte(is_ready);
			lobby->m_battle_room->player[i].client_uid = client_uid;
			lobby->m_battle_room->player[i].character_name = character_name;
			lobby->m_battle_room->player[i].head_icon = head_icon;
			lobby->m_battle_room->player[i].character_level = character_level;
			lobby->m_battle_room->player[i].character_exp = character_exp;
			lobby->m_battle_room->player[i].is_vip = is_vip;
			lobby->m_battle_room->player[i].net_bar_level = net_bar_level;
			lobby->m_battle_room->player[i].business_card = business_card;
			lobby->m_battle_room->player[i].is_ready = is_ready;
		}
		lobby->EventBattleRoomChange.Fire(ptr_static_cast<StateLobby>(lobby), RetEventArgs());
	}
}

void LobbyConnection::OnNotifyBattleGroupSearching()
{
	uint battlegroup_id;
	byte is_searching;

	ReadInt(battlegroup_id);
	ReadByte(is_searching);
	tempc_ptr(StateLobby) lobby = ptr_dynamic_cast<StateLobby>(gGame->machine.CurrentState());
	if (lobby)
	{
		lobby->EventBattleGroupSearching.Fire(ptr_static_cast<StateLobby>(lobby), RetEventArgs(is_searching));
	}
}

void LobbyConnection::OnNotifyBattleGroupGameStart()
{
	uint battlegroup_id;
	byte change_room;
	uint server_id, channel_id, room_id;
	byte is_challenge;
	uint team1, team2;

	ReadInt(battlegroup_id);
	ReadByte(change_room);
	ReadInt(server_id);
	ReadInt(channel_id);
	ReadInt(room_id);
	ReadByte(is_challenge);
	ReadInt(team1);
	ReadInt(team2);

	LogSystem.WriteLinef("OnNotifyBattleGroupGameStart : %d, %d, %d, %d, %d", battlegroup_id, change_room, server_id, channel_id, room_id);

	BattleChangeRoom args;
	args.change_room = change_room;
	args.server_id = server_id;
	args.channel_id = channel_id;
	args.room_id = room_id;
	args.is_challenge = is_challenge;
	args.team1 = team1;
	args.team2 = team2;
	tempc_ptr(StateLobby) lobby = ptr_dynamic_cast<StateLobby>(gGame->machine.CurrentState());
	if (lobby)
	{
		lobby->EventBattleGroupGameStart.Fire(ptr_static_cast<StateLobby>(lobby), BattleChangeRoom(args));
	}
}

void LobbyConnection::RequestApex(const char * pBuffer,int nLen)
{
	BeginWrite();
	WriteByte(CM_RequestApex);
	WriteInt(nLen);
	Write(pBuffer,nLen);
	EndWrite();
}

void LobbyConnection::OnResponseApex()
{
	int nLen;
	ReadInt(nLen);
	if(nLen > 0)
	{
#if ACTIVE_APEX
		Apex::NoticeApec_UserData((const char*)ReadData(nLen),nLen);
#endif
	}
}
