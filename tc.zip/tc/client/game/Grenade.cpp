#include "pch.h"

using namespace Core;
using namespace Client;

DEFINE_PDE_TYPE_CLASS(Client::ThrowableInfo)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Client::WeaponInfo);

		ADD_PDE_FIELD(explode_time);
		ADD_PDE_FIELD(ready_time);
		ADD_PDE_FIELD(throw_out_time);
		ADD_PDE_FIELD(gravity);

		ADD_PDE_FIELD(explode_particle);
		ADD_PDE_FIELD(trail_particle);
		ADD_PDE_FIELD(grenade_particle);
		ADD_PDE_FIELD(explode_sound);
		ADD_PDE_FIELD(ready_sound_2d);
		ADD_PDE_FIELD(ready_sound_3d);
		ADD_PDE_FIELD(throw_sound_2d);
		ADD_PDE_FIELD(throw_sound_3d);

		ADD_PDE_DEFAULT_CONSTRUCTOR();
	}
};

DEFINE_PDE_TYPE_CLASS(Client::GrenadeInfo)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Client::ThrowableInfo);

		ADD_PDE_FIELD(hurt);
		ADD_PDE_FIELD(range);

		ADD_PDE_DEFAULT_CONSTRUCTOR();
	}
};


DEFINE_PDE_TYPE_CLASS(Client::FlashInfo)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Client::ThrowableInfo);

		ADD_PDE_FIELD(range_start);
		ADD_PDE_FIELD(range_end);
		ADD_PDE_FIELD(time_max);
		ADD_PDE_FIELD(time_fade);

		ADD_PDE_DEFAULT_CONSTRUCTOR();
	}
};

DEFINE_PDE_TYPE_CLASS(Client::SmokeInfo)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Client::ThrowableInfo);

		ADD_PDE_FIELD(time);

		ADD_PDE_DEFAULT_CONSTRUCTOR();
	}
};

DEFINE_PDE_TYPE_CLASS(Client::SpecialGrenadeInfo)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Client::ThrowableInfo);

		ADD_PDE_FIELD(hurt);
		ADD_PDE_FIELD(range);

		ADD_PDE_DEFAULT_CONSTRUCTOR();
	}
};

REGISTER_PDE_TYPE(Client::ThrowableInfo);
REGISTER_PDE_TYPE(Client::GrenadeInfo);
REGISTER_PDE_TYPE(Client::FlashInfo);
REGISTER_PDE_TYPE(Client::SmokeInfo);
REGISTER_PDE_TYPE(Client::SpecialGrenadeInfo);


DEFINE_PDE_TYPE_CLASS(Client::Grenade)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Client::WeaponBase);
		//ADD_PDE_FIELD(count);
	}
};

REGISTER_PDE_TYPE(Client::Grenade);

/// constructor
Grenade::Grenade(by_ptr(ThrowableInfo) info)
	: actor(NULL)
	, timer(0.f)
	, explode_time(0.f)
	, ready_time(0.f)
	, throw_out_time(0.f)
	, id(-1)
	, state(kIdle)
	//, count(0)
	, uid(-1)
	, physx_update_time(0)
	, team(-1)
	, canOperation(false)
{
	weapon_info = grenade_info = info;
	type = info->weapon_type;
}

/// create physx
void Grenade::CreatePhysx()
{
	if (team == -1)
	{
		LogSystem.WriteLinef("Grenade::CreatePhysx error team = -1");
	}
	if (team == 0)
	{
		actor = PhysxSystem::CreateSphereCCD(position, 0.08f, PhysxSystem::kGrenadeWithTeam1);
	}
	else
	{
		actor = PhysxSystem::CreateSphereCCD(position, 0.08f, PhysxSystem::kGrenadeWithTeam2);
	}
	actor->raiseBodyFlag(NX_BF_DISABLE_GRAVITY);
	actor->setContactReportFlags(NX_NOTIFY_ON_START_TOUCH | NX_NOTIFY_FORCES);
	actor->setAngularDamping(1.0f);
	actor->setLinearDamping(0.0f);
	actor->userData = this;

	canOperation = false;
}

/// destructor
Grenade::~Grenade()
{
	if (actor)
	{
		PhysxSystem::ReleaseActor(*actor);
		actor = NULL;
	}
}

tempc_ptr(Grenade) Grenade::FromNxActor(NxActor & actor)
{
	Object * obj = (Object*)actor.userData;

	if (obj)
	{
		return ptr_dynamic_cast<Grenade>(obj);
	}

	return NullPtr;
}

/// initialize
void Grenade::Initialize()
{
	WeaponBase::Initialize();

	if (skeleton)
	{
		animation_list = ptr_new AnimationNodeList;
		animation_set = ptr_new AnimationSet;

		if (is_for_player)
		{
			CStrBuf<256> str(ANIMATION_KEY_PROP_PLAYER);

			CStrBuf<256> str_animation;
			str_animation.format("%s/%s", owner->GetCurCharinfo()->third_person_animationset, weapon_info->animation_set);

			if (weapon_info)
				str.contract(str_animation);
			
			animation_set_player = RESOURCE_GET_BYTYPE(str, ANIMATIONSET_TYPE, AnimationSetRes);
			if (animation_set_player)
			{
				animation_set_player->Load(true);
				animation_set->SetAnimationSet("weapon", animation_set_player);
			}
		}
		else
		{
			//CStrBuf<256> str(ANIMATION_KEY_PROP_CHARACTER);

			////if (owner && owner->character_info)
			////{
			////	if (owner->character_info->gender == 0)
			////		str.contract("male/");
			////	else
			////		str.contract("female/");
			////}
			////else
			////	str.contract("male/");

			//if (weapon_info)
			//	str.contract(weapon_info->animation_set.Str());

			//animation_set_character = RESOURCE_GET_BYTYPE(str.buff(), ANIMATIONSET_TYPE, AnimationSetRes);
			//if (animation_set_character)
			//{
			//	animation_set_character->Load(true);
			//}

			CStrBuf<256> str(ANIMATION_KEY_PROP_CHARACTER);

			CStrBuf<256> str_animation;
			if(owner)
			{
				str_animation.format("%s/%s", owner->GetCurCharinfo()->third_person_animationset, weapon_info->animation_set);

				if (weapon_info)
					str.contract(str_animation);

				animation_set_character = RESOURCE_GET_BYTYPE(str.buff(), ANIMATIONSET_TYPE, AnimationSetRes);
				if (animation_set_character)
				{
					animation_set_character->Load(true);
					animation_set->SetAnimationSet("weapon", animation_set_character);
				}
			}
		}

		animation->SetAnimationSet(animation_set);

		sharedc_ptr(AnimationNodePose) node = ptr_new AnimationNodePose(skeleton);
		node->SetAnimation("idle", animation_set);
		animation_list->AddNode("idle", node);

		node = ptr_new AnimationNodePose(skeleton);
		node->SetAnimation("empty", animation_set);
		animation_list->AddNode("empty", node);

		animation_list->SetActiveNode("idle");

		animation->SetAnimationNode(animation_list);

		pose = ptr_new Pose(skeleton);
	}

	state = kIdle;
	explode_time = grenade_info->explode_time;
	//tempc_ptr(Character) player =GetOwner();
	//if(player)
	//{
	//	player->SetGrenadeCDTiming(grenade_info->time_to_idle);
	//}
	//count = 1;

	if (grenade_info->explode_particle.Length() > 0)
		sharedc_ptr(ParticleSystem) explode_particle = ptr_new ParticleSystem(grenade_info->explode_particle);

	if (grenade_info->grenade_particle.Length() > 0)
		grenade_particle = ptr_new ParticleSystem(grenade_info->grenade_particle);

	if (grenade_info->trail_particle.Length() > 0)
		grenade_trail_particle = ptr_new ParticleSystem(grenade_info->trail_particle);
	if (grenade_trail_particle)
		grenade_trail_particle->SetEnable(false);
}

/// draw ui
void Grenade::DrawUI(by_ptr(UIRender) ui_render)
{
	WeaponBase::DrawUI(ui_render);

	Core::CStrBuf<256> buff;

	//if(count > 1)
	{
		buff.format("/%d", 1);
		ui_render->DrawStringShadow(ui_render->font_simhei_24, ARGB(255, 241, 211), ARGB(0,0,0), ARGB(0, 0, 0, 0), Core::Rectangle(-180, 0 - 50, 0, 1), buff, Unit::kAlignLeftBottom);
		/*buff.format("%d", count);
		ui_render->DrawStringShadow(ui_render->font_simhei_24, ARGB(255, 241, 211), ARGB(0,0,0), ARGB(0, 0, 0, 0), Core::Rectangle(0, 0 - 50, -180, 1), buff, Unit::kAlignRightBottom);*/
	}

	buff.format(weapon_info->name);
	buff.toupper();

	ui_render->DrawStringShadow(ui_render->font_simhei_14, ARGB(255, 241, 211), ARGB(0,0,0), ARGB(0, 0, 0, 0), Core::Rectangle(-100, -20, 0, -7), buff, Unit::kAlignCenterBottom);
}

/// update
void Grenade::Update(float time)
{
	WeaponBase::Update(time);
	tempc_ptr(Character) player = GetOwner();

	if (!player)
		return;

	switch (state)
	{
	case kIdle:
		{
			if (player->first_action_on && player->CanThrowGrenade() && player->grenade_cd_time < 0.f)
			{
				state = kThrowingIn;
				ready_time = grenade_info->ready_time;
				player->GrenadeThrowIn();
			}
		}
		break;

	case kThrowingIn:
		{
			ready_time -= time;
			if (ready_time <= 0)
			{
				ready_time = 0;
				state = kThrowingReady;
				player->GrenadeReady();
			}
		}
		break;

	case kThrowingReady:
		{
			if (!player->first_action_on)
			{
				state = kThrowingRequest;
				player->GrenadeThrowRequest(type);
			}
		}
		break;

	case kThrowingRequest:
		{
			if (player->grenade_throw_out)
			{
				//count--;
				state = kThrowingOut;
				throw_out_time = grenade_info->throw_out_time;
			}
		}
		break;

	case kThrowingOut:
		{
			throw_out_time -= time;
			if (throw_out_time <=0)
			{
				state = kIdle;
				player->OnGrenadeThrowOut();
				player->throwing_grenade = false;
			}
		}
		break;

	default:
		break;
	}
}

/// udpate animation
void Grenade::UpdateAnimation(float time)
{
	if (animation_list)
	{
		tempc_ptr(Character) character = GetOwner();
		if (character)
		{
			if (character->IsMoving())
				animation_list->SetActiveNode("run");
			else
				animation_list->SetActiveNode("idle");
		}
	}

	WeaponBase::UpdateAnimation(time);
}

/// update physx
void Grenade::UpdatePhysx(float frame_time)
{
	if (actor && grenade_info)
	{
		grenade_info->gravity = -9.8f * 0.80f;

		actor->addForce(NxVec3(0, grenade_info->gravity, 0), NX_ACCELERATION);
	}
}

/// can active
bool Grenade::CanActive()
{
	//if (count > 0)
	//	return true;
	//return false;
	return true;
}

/// active
void Grenade::Active()
{
	if (CanActive())
		WeaponBase::Active();
}

/// inactive
void Grenade::Inactive()
{
	WeaponBase::Inactive();
	
	tempc_ptr(Character) player =GetOwner();

	state = kIdle;

	if (player)
		player->GrenadeThrowStop();
}

/// get position
const Vector3 & Grenade::GetPosition()
{
	if (state == kThrowOut && actor)
		position = (const Vector3 &)actor->getGlobalPosition();
	return position;
}

/// set position
void Grenade::SetPosition(const Core::Vector3 & pos)
{
	if (actor)
		actor->setGlobalPosition((const NxVec3 &)pos);

	position = pos;
}


/// get rotation
const Core::Quaternion & Grenade::GetRotation()
{
	if (state == kThrowOut && actor)
		rotation = (const Quaternion &)actor->getGlobalOrientationQuat();

	return rotation;
}

/// set rotation
void Grenade::SetRotation(const Core::Quaternion & rot)
{
	if (actor)
		actor->setGlobalOrientationQuat((const NxQuat &)rot);

	rotation = rot;
}


/// throw out
void Grenade::ThrowOut(const Core::Vector3 & velocity)
{
	state = kThrowOut;
	timer = grenade_info->explode_time;
	if (actor)
		actor->setLinearVelocity((const NxVec3 &)velocity);

	if (animation)
		animation->PlayAction("nopr", 0, true, 0, true);
}

/// action throw in
void Grenade::ActionThrowIn()
{
	if (animation)
		animation->PlayAction("prepelt", 0.f);
}