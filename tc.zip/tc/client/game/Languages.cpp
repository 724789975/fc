#include "pch.h"

using namespace Core;

DEFINE_PDE_TYPE_CLASS(Client::Languages)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_METHOD(LoadLanguage);
		ADD_PDE_METHOD(SetCurLanguage);
		ADD_PDE_METHOD(GetText);

		ADD_PDE_METHOD(CallLangChangedCB);
		ADD_PDE_METHOD(SetFontOffset);
	}
};

REGISTER_PDE_TYPE(Client::Languages);

#if LANG_RBTREE
template<>
class CompareFunc<Client::LanguageString>
{
public:
	bool operator()(const Client::LanguageString & left, const Client::LanguageString & right) const
	{
		return left.key < right.key;
	}
};
#endif

namespace Client
{
	Languages* gLang = NULL;
}

namespace Client
{
	Languages::Languages()
		:cur_stringtable(NullPtr)
#if LANG_RBTREE
		,string_finder(NULL)
#endif
	{
		PDE_ASSERT(!gLang, "gLang is not null");

		gLang = this;

#if LANG_RBTREE
		string_finder = new LanguageString();
#endif
	}

	Languages::~Languages()
	{
		lang_table.Clear();
		cur_stringtable = NullPtr;

		PDE_ASSERT(gLang, "gLang is null");

		gLang = NULL;

#if LANG_RBTREE
		SAFE_DELETE(string_finder);
#endif
	}

	LangChangedCB Languages::SetLangChangedCB(LangChangedCB cb)
	{
		LangChangedCB old_cb = call_back;

		call_back = cb;

		return call_back;
	}

	bool Languages::LoadLanguage(const String &lang)
	{
		bool result = false;
		sharedc_ptr(StringTable) string_table = ptr_new StringTable();

		if (lang.Length() > 0 && !lang_table.Contains(lang))
		{
			CStrBuf<256> filename;

			filename.format("/lang/%s.lua", lang.Str());
			if (LoadLanguageLua(filename, string_table))
			{
				filename.format("/lang/%s_info.lua", lang.Str());
				if (LoadLanguageLua(filename, string_table))
				{
					filename.format("/lang/%s_font.lua", lang.Str());
					LoadFontOffset(filename);

					result = true;
				}
			}
		}

		if (!result)
			LogSystem.WriteLinef("LoadLanguage Failed, lang[%s].", lang.Str());
		else
			lang_table.Add(lang, string_table);

		return result;
	}

	bool Languages::SetCurLanguage(const String &lang)
	{
		if (lang.Length() == 0 || (!lang_table.Contains(lang) && !LoadLanguage(lang)))
		{
			LogSystem.WriteLinef("SetCurLanguage Failed, cur_lang[%s], lang[%s].", cur_lang.Str(), lang.Str());

			return false;
		}

		if (!cur_stringtable || lang != cur_lang)
		{
			tempc_ptr(StringTable) string_table = lang_table.Get(lang, NullPtr);
			bool need_callcb = !!cur_stringtable;

			PDE_ASSERT(!!string_table, "string_table is null");

			cur_lang = lang;
			cur_stringtable = string_table;

			if (need_callcb)
				CallLangChangedCB();
		}

		return true;
	}

	String Languages::GetCurLanguage()
	{
		return cur_lang;
	}

	String Languages::GetText(const String &text_key)
	{
		bool find = false;
		String ret = text_key;

		if (cur_stringtable && text_key.Length() > 0)
		{
#if LANG_RBTREE
			string_finder->SetKey(text_key);
			const LanguageString* result = cur_stringtable->find(string_finder);
			if(result)
			{
				ret = result->value;
				find = true;
			}
#else
			String *result = cur_stringtable->Get(text_key);
			if (result)
			{
				ret = *result;
				find = true;
			}
#endif
		}

		if (!find)
		{
#if LANG_RBTREE
			if (cur_stringtable)
				cur_stringtable->InsertNode(new LanguageString(text_key, text_key));
#else
			if (cur_stringtable)
				cur_stringtable->Set(text_key, text_key);
#endif

			if (text_key.Length() > 0)
				LogSystem.WriteLinef("GetText Failed, cur_lang[%s], text_key[%s].", cur_lang.Str(), text_key.Str());
		}

		return ret;
	}

	Core::String Languages::GetTextW(const wchar_t* text_key)
	{
		char buffer[2048 + 1];

		UTF16toUTF8((U16*)text_key, -1,(U8*)buffer, 2048);

		return GetText(buffer);
	}

	Core::String Languages::GetTextWLocal(const wchar_t* text_key)
	{
		char buffer[2048 + 1];

		UTF16toUTF8((U16*)text_key, -1,(U8*)buffer, 2048);

		Core::String utf8 = GetText(buffer);

		UTF8ToACP(utf8.Str(), buffer, 2048);

		return Core::String(buffer);
	}

	void Languages::CallLangChangedCB()
	{
		void *ret = NULL;

		if (call_back)
			ret = (*call_back)(NULL);
	}

	void Languages::SetFontOffset(int value)
	{
		gGame->font_size_off = value;
	}

	bool Languages::LoadLanguageLua(const String &file_name, by_ptr(StringTable) string_table)
	{
		bool result = false;

		sharedc_ptr(ScriptLua) lua = RESOURCE_LOAD(file_name, false, ScriptLua);
		if (lua)
		{
			Lua::LuaState *L = Lua::LuaState::NewState();
			L->OpenLibs();

			int top = L->GetTop();
			L->NewTable();
			if (L->LoadBuffer(lua->GetBuffer(), lua->GetSize(), file_name) == 0)
			{
				//load lang data
				L->PushValue(top + 1);
				L->SetFenv(-2);

				if (L->DoCall(0, 0))
				{
					const char *msg = L->ToString(-1);
					if (msg) Console.WriteLine(msg);
					L->Pop(1);
				}
				else
				{
					L->GetField(-1, "languages");
					int size = L->ObjLen(-1);
					for(int i = 1; i <= size; ++i)
					{
						L->PushInteger(i);
						L->GetTable(-2);

						L->PushInteger(1);
						L->GetTable(-2);
						String key = L->ToString(-1);
						L->Pop(1);

						L->PushInteger(2);
						L->GetTable(-2);
						String value = L->ToString(-1);
						L->Pop(1);

						L->Pop(1);
#if LANG_RBTREE
						string_table->InsertNode(new LanguageString(key, value));
#else
						if (string_table->Set(key, value))
						{
							LogSystem.WriteLinef("Key exist, langfile[%s], text_key[%s].", file_name.Str(), key.Str());
						}
#endif
					}
					L->Pop(1);

					result = true;
				}
			}
			else
			{
				const char *msg = L->ToString(-1);
				if (msg) Console.WriteLine(msg);
				L->Pop(1);
			}
			L->Close();
		}

		return result;
	}

	void Languages::LoadFontOffset(const String &file_name)
	{
		sharedc_ptr(ScriptLua) lua = RESOURCE_LOAD(file_name, false, ScriptLua);
		if (lua)
		{
			Lua::LuaState *L = Lua::LuaState::NewState();
			L->OpenLibs();

			L->PushPtr(gGame->langs);
			L->SetGlobal("font");

			if (L->LoadBuffer(lua->GetBuffer(), lua->GetSize(), file_name) == 0)
			{
				if (L->DoCall(0, 0))
				{
					const char *msg = L->ToString(-1);
					if (msg) Console.WriteLine(msg);
					L->Pop(1);
				}
				else
				{
				}
			}
			else
			{
				const char *msg = L->ToString(-1);
				if (msg) Console.WriteLine(msg);
				L->Pop(1);
			}
			L->Close();
		}
	}
}