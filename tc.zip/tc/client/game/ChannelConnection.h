namespace Client
{
	class StateLobby;
	class ChannelConnection : public Core::BinaryNetworkStream
	{
	public:
		enum State
		{
			kIdle,
			kConnected,
			kInChannel,
			kInRoom,
			kInGame,
			kInBalance,
			kInReplay
		};

		enum AddUIEffect
		{
			kRecoverNone 		= 0,
			kRecoverSupplyHp	= 1,
			kRecoverCuregun		= 2,
			kRecoverSelf		= 3,
			kSupplyAmmo_1		= 4,
			kSupplyAmmo_2		= 5,
			kRecoverFire		= 6,
			kRecoverVehicle		= 7,
			kRecoverNovice		= 8,
			kRecoverBaseHp		= 9,
			kRecoverWaitAddBlood = 10,
		};


		enum GameState
		{
			kAuthentication,
			kLoading,
			kWaiting,
			kAlive,
			kDied,
			kGameEnd,

			kGameLeaving,
		};

		enum HornSystemMessageType
		{
			kHornHoldPointLeft60sMessage,
			kHornHoldPointSuccessMessage,
			kHornKillMaster,
			kHornPushVehicleStartMessage,
			kHornPushVehicleHalfMessage,
			kHornPushVehicleAlmostSuccessMessage,
			kHornTriggerSnareMessage,
            
		};

		enum LeaveGameReason
		{
			kLeaveGameReasonNone,
			kLeaveGameReasonIdle,
			kLeaveGameReasonSuccessNovice,
			kLeaveGameReasonFailedNovice
		};

		enum StreetKingState
		{
			StateNone = 0,
			StateKiller,
			StateRandom,
		};
	public:
		// constructor.
		ChannelConnection();

		// destructor
		virtual ~ChannelConnection();

		// get state
		State GetState() { return (State)state; }

		// diconnect
		void Disconnect();

		// update
		void OnUpdate(float frame_time);

		// send messages
		void SendMessages();

		// is idle
		bool IsIdle();

	public:
		// on disconnected
		void OnDisconnected(bool is_error = false);

		// request channel enter
		void RequestChannelEnter();

		// reuqest channel leave
		void RequestChannelLeave();

		// request room list
		void RequestRoomList();

		// request room create
		void RequestRoomCreate(const RoomOption & option);

		// request room enter
		void RequestRoomEnter(int room_id, const char* password = NULL);

		// [2015/10/26 dengxiaobo]
		void RequestRoomEnterWithSlotId(int dwRoomId, uint dwSlotId = 0);
		// end

		// request room team enter
		void RequestRoomTeamEnter(int room_id, const char* password, const Core::Array<Core::String> & members);

		// request room leave
		void RequestRoomLeave();

		//requeset room client list
		void RequestRoomClientList();

		// request room change option
		void RequestRoomChangeOption(const RoomOption & option);

		// request room change team
		void RequestRoomChangeTeam(byte team);

		// request room change slot
		void RequestRoomChangeSlot(byte slot_id);

		// request room preserve slot
		void RequestRoomPreserveSlot(byte slot_id, const Core::String & name);

		// request room change slot status
		void RequestRoomChangeSlotStatus(byte slot_id, RoomSlot::Status status);

		// request room ready
		void RequestRoomReady(bool ready);

		// request game start
		void RequestGameStart();

		// request game enter
		void RequestGameEnter();

		// request chat
		void RequestChat(const Core::Identifier & to, const Core::String & msg);

		// request room kick client
		void RequestRoomKickClient(byte id_in_room);

		// request client list
		void RequestClientList(int start_id);
		
		// Request Novice
		bool RequestNovice();

		// Request TD Data
		void RequestTDData(int level_id, int map_level, int res_value, const Core::String & rand_key);

		void RequestMatching();

		// request change player
		void RequestChangeCareerPack(int careerpos);

		// response channel enter
		void ResponseChannelEnter();

		// response room list
		void ResponseRoomList();

		// response room create
		void ResponseRoomCreate();

		// response room enter
		void ResponseRoomEnter();

		// response room leave
		void ResponseRoomLeave();

		// response room client list
		void ResponseRoomClientList();
		void ResponseRoomClientList(Core::BinaryNetworkReader & reader);

		// response room change option
		void ResponseRoomChangeOption();

		// response room change team
		void ResponseRoomChangeTeam();

		// response room change team
		void ResponseRoomChangeSlot();

		// response room change slot status
		void ResponseRoomChangeSlotStatus();

		// response client list
		void ResponseClientList();

		// response td data
		void ResponseTDData();

		// response room ready
		void ResponseRoomReady();

		// response game start
		void ResponseGameStart();

		// response game enter
		void ResponseGameEnter();

		// notify channel client enter
		void NotifyChannelClientEnter();

		// notify channel client leave
		void NotifyChannelClientLeave();

		// notify room create
		void NotifyRoomCreate();

		// notify room close
		void NotifyRoomClose();

		// notify room list
		void NotifyRoomList();

		// notify room client enter
		void NotifyRoomClientEnter();

		// notify room client leave
		void NotifyRoomClientLeave();

		// notify room client update
		void NotifyRoomClientUpdate();

		// notify room change option
		void NotifyRoomChangeOption();

		// notify room state changed
		void NotifyRoomStateChanged();

		// notify room client count changed
		void NotifyRoomClientCountChanged();

		// notify room change team
		void NotifyClientChangeTeam();

		// notify room client ready
		void NotifyClientReady();
		
		//Notify Client AutoStart
		void NotifyClientAutoStart();

		//Notify Client AutoStartCancel
		void NotifyClientAutoStartCancel();

		// notify game start
		void NotifyGameStart();

		// notify game client enter 
		void NotifyGameClientEnter();

		// notify game client leave
		void NotifyGameClientLeave();

		// notify game start
		void NotifyGameEnd();

		// notify game start
		void NotifyGameLeave();

		// notify room kick client
		void NotifyRoomKickClient();

		// notify client change slot
		void NotifyClientChangeSlot();

		// notify room change slot status;
		void NotifyRoomChangeSlotStatus();

		// response room preserve slot
		void ResponseRoomPreserveSlot();

       
	private:
		// parse message
		void OnMessage();

		// on connected
		void OnConnected();

		// on leave channel
		void OnLeaveChannel();
	public:
		// on enter channel
		void OnEnterChannel();

		// on enter room
		void OnEnterRoom();

		
	private:
		// on leave room
		void OnLeaveRoom();

		// on room list changed
		void OnRoomListChanged();

		// on room client list changed
		void OnRoomClientListChanged();

		// on room Auto Start
		void OnRoomAutoStart(double time);

		// on room Auto Start Cancel
		void OnRoomAutoStartCancel();

		void OnRoomAutoStartLeaveBalance();

		// on room option changed
		void OnRoomOptionChanged();

		tempc_ptr(RoomInfo) GetRoomInfoById(short sId);

	public:
		uint lobby_uid;
		uint character_id;
		Core::String character_name;

		Core::Array<sharedc_ptr(RoomInfo)>	room_list;
		Core::Array<sharedc_ptr(ClientInfo)>	client_list;
		Core::FixedArray<RoomSlot, 16> room_slots;
		Core::Array<ChannelClientInfo> channel_client_list;

	public:
		// get game state
		uint GetGameState() { return game_state; }
		
		void SetGameState(GameState state) { game_state = state;}
		// on game enter
		void OnEnterGame();

		// on game leave
		void OnLeaveGame(bool stage_clear,int reason = 0);

		// on enter game balance
		void OnEnterBalance();

		// on leave game balance
		void OnLeaveBalance();

		// on game end
		void OnGameEnd();

		// on message game
		void OnMessageGame(MessagePacket & packet);

		// gen spiritball
		int GenSpiritBall(uint uid, int score, const Core::Vector3 & pos, const Core::Array<int> &kills_kind);

		// hurt
		void TakeDamage(Core::BinaryNetworkReader & reader, by_ptr(Character) from, by_ptr(Character) to, const Core::Vector3 & pos, bool isfullhurt = false, bool isboost = false);

		// sustain hurt
		void TakeSustainDamage(Core::BinaryNetworkReader & reader, by_ptr(Character) from, by_ptr(Character) to);

		// pve hurt
		void TakePveDamage(Core::BinaryNetworkReader & reader, by_ptr(Character) from, by_ptr(Character) to);

		// sync player data
		void SyncPlayerData();

		// shoot
		void Shoot(const Core::Vector3 &position, const Core::Quaternion &direction, const Core::Array<HitMessage> &hit_message, bool do_effect, float hurt_rate);
		// flame shoot
		void FlameShoot(const Core::Vector3 &position, const Core::Quaternion &direction, const Core::Array<HitMessage> &hit_message, bool do_effect, float hurt_rate);
		// kick back
		void KickBack(const Core::Vector3 & punch);

		void GunTowerShoot(uint dummy_id, const HitMessage& hit_message, const GunTowerAttackBaseInfo & tower_attack_info);

		// grenade throw in
		void GrenadeThrowIn();

		// grenade throw stop
		void GrenadeThrowStop();

		// throw grenade
		void GrenadeThrowOut(byte type, const Core::Vector3 & position, const Core::Vector3 & direction);

		// grenade explosion
		void GrenadeHurt(byte uid, by_ptr(Grenade) grenade);

		// grenade dummy explosion
		void GrenadeHurtDummy(int dummy_uid, const Core::Vector3& dummy_position, by_ptr(Grenade) grenade);

		// self hurt
		void SelfHurt(float speed);

		// poke
		void Poke(byte type);

		// poke hurt
		void PokeHurt(bool light, byte uid, byte part, bool back);

		void PokeHurtDummy(bool light, int dummy_uid, bool back);

		// game start
		void ReadyForGame(int career);

		// reload
		void Reload(short count = 0);

		// reload ready
		void ReloadReady(int count);

		// leave game
		void LeaveGame(int reason = 0);

		// select weapon
		void SelectWeapon(byte weapon_id);

		// drop weapon
		void DropWeapon();

		void DropWeaponByID(byte slot);

		// pick up weapon
		void PickUpWeapon(uint id);

		// flash bright
		void FlashBright(float bright_time, float fade_time);

		// camera fov changed
		void CameraFovChanged(float fov, float target_fov);

		// pick up supply object
		void PickUpSupplyObject(uint id);

		// pick up supply object new
		void PickUpSupplyObjectNew(uint id);

		void SetClientMessage(bool flag);

		// use item
		void UseItem_ItemMode(const Core::Array<byte> &uids);

		// zibao
		void ZiBao_ItemMode(const Core::Array<byte> &uids);

		void MoonBoss();

		// save map
		void SaveMap();

		// use skill
		void UseSkill(by_ptr(PlayerSkill) skill);

		void UseSkillSuperMan(byte playid);

		void CancelInvisible(byte playid);

		void UseSmog(byte playid, Core::Vector3 & pos);

		void SomgAreaCancel(byte playid);

		void UseSkillSuperManSuccess();

		// change pack
		void ChangePack(byte id);

		// kick client request
		void KickClientRequest(byte uid, byte reason);

		// kick client vote
		void KickClientVote(byte result);

		// suicide
		void Suicide();

		// radio report
		void RadioReport(int radio_id, int radio_item,const Core::String & avarname);

		// spawn confirm
		void SpawnConfirm();

		// action on changed
		void ActionOn(int action_type, bool is_on); 

		// projectedammo out
		void ProjectedAmmoOut(byte uid, by_ptr(WeaponInfo) weapon_info, int ammo_type, const Core::Vector3 & position, const Core::Vector3 & direction,const AmmoAddInInfo& addin, by_ptr(Character) target = NullPtr);

		//����buff
		void NeedDieBuff(int iSlot);

		// projectedammo Destroy
		void ProjectedAmmoDestroy(by_ptr(AmmoBase) ammo, U16 ammo_id);

		void CutHurt(ushort ammo_id, const Core::Array<HitMessage> & hit_message);

		// projectedammo Update
		void ProjectedAmmoUpdate(by_ptr(Level::AmmoSet) ammo_set);

		// explodeammo hurt
		void ExplodeAmmoHurt(ushort ammo_id, byte uid, by_ptr(WeaponInfo) info, float dist, float range_ratio, const Core::Vector3 &position, bool teamhurt = false,byte part = kCharacterPartTorso, float hurt_rate = 1.0f);

		void ExplodeAmmoHurtDummy(ushort ammo_id, int dummy_id, by_ptr(WeaponInfo) info, float dist, float range_ratio, const Core::Vector3 &position, bool teamhurt, float hurt_rate);

		void ExplodeProdHurt(ushort ammo_id, byte uid, by_ptr(WeaponInfo) info, bool teamhurt = false, byte part = kCharacterPartTorso);

		void ExplodeProdHurtDummy(ushort ammo_id, int dummy_id, by_ptr(WeaponInfo) info, bool teamhurt);
		
		void PVELaserHitHurt(byte owner_uid, byte hit_uid, int hit_damage);

		void PVEAmmoOut(byte owner_uid, by_ptr(PVEAmmo) pve_ammo);

		void PVEAmmoDestroy(byte owner_uid, by_ptr(PVEAmmo) pve_ammo);

		void PVEAmmoHitHurt(byte owner_uid, byte hit_uid, by_ptr(PVEAmmo) pve_ammo);

		void PVEAmmoExplodeHurt(byte owner_uid, byte hit_uid, by_ptr(PVEAmmo) pve_ammo);

		void PVEAmmoUpdate(byte owner_uid, Core::HashSet<U16, sharedc_ptr(PVEAmmo)> &pveammo_set);

		void CharacterHeal(byte character_id, int heal_life, int ammo);

		void Teleport(const Core::Vector3 &position, const Core::Quaternion &rotation);

		void ForceSpawn();

		// cure character
		void CureCharacter(byte to_uid);

		// player start an animation
		void PlayerAnimationStart(int weapontype, int firestate = 0);

		// player end an animation
		void PlayerAnimationEnd(int weapontype);

		// player call doctor
		void CallDoctor();

		// player call stop burn
		void StopBurn(byte uid);

		// novice operation
		void NoviceOperation(int index);

		void HornSystemMessage(int type, byte data);
		
		void DrumCheck();
		
		void Drink();

		// connection check
		void ConnectionCheck();

		void Spray(const Core::Vector3 & position, const Core::Vector3 & normal);

		void ChangeAmmoTeam(U16 ammoindex, byte team);

		void UseSpawnCoin(U16 coin);

		void StartPlantTower();

		void StartPlantBomb();

		void CancelPlantBomb();

		void StartDefuseBomb();

		void CancelDefuseBomb();

		void StartSaveDying(byte dying_uid);

		void CancelSaveDying();

		// on replay enter
		void OnEnterReplay();

		// on replay leave
		void OnLeaveReplay();
		
		// on update replay
		void OnUpdateReplay();

		void ReplayPlay();

		// replay open
		int ReplayOpen(Core::String path);

		// replay save
		Core::String ReplaySave(Core::String path);

		void ChargeSomething(byte playerid, byte isplayer, Core::Quaternion rot);

		void SkillKickBack(byte playerid, KickInfo info);

		void DummyObjectSyncUpdate();

		void RequestDummyObjectCreate(byte type, const char* pbuf, uint length, byte sub_type);

		void RequestDummyObjectDestory(uint id);

		void UseItem(uint sid, ushort count = 1);

		void UseItemSurvival(int index);

		void UseItemSurvivalByGhost(int index);

	private:
		// parse authentication
		void ParseAuthentication(Core::BinaryNetworkReader & reader);

		// parse character info
		void ParseCharacterInfo(Core::BinaryNetworkReader & reader);

		// parse sync game
		void ParseInitialize(Core::BinaryNetworkReader & reader);

		// parse sync player data
		void ParseSyncCharacterData(Core::BinaryNetworkReader & reader);

		// parse player join
		void ParsePlayerJoin(Core::BinaryNetworkReader & reader);

		// parse player leave
		void ParsePlayerLeave(Core::BinaryNetworkReader & reader);

		// parse spawn
		void ParseSpawn(Core::BinaryNetworkReader & reader);

		// parse bot spawn
		void ParseBotSpawn(Core::BinaryNetworkReader & reader);

		// parse shoot
		void ParseShoot(Core::BinaryNetworkReader & reader);

		// parse flame shoot
		void ParseFlameShoot(Core::BinaryNetworkReader & reader);

		// parse kick back
		void ParseKickBack(Core::BinaryNetworkReader & reader);

		// parse self hurt
		void ParseSelfHurt(Core::BinaryNetworkReader & reader);

		// parse skill hurt
		void ParseSkillHurt(Core::BinaryNetworkReader & reader);

		// parse sustain hurt
		void ParseSustainHurt(Core::BinaryNetworkReader & reader);

		// parse control person
		void ParseControlPerson(Core::BinaryNetworkReader & reader);

		// parse reveng person
		void ParseRevengPerson(Core::BinaryNetworkReader & reader);
		
		// Parse Novice Operation
		void ParseNoviceOperation(Core::BinaryNetworkReader & reader);

		// Parse Boss Flash
		void ParseBossFlash(Core::BinaryNetworkReader & reader);

		// parse grenade throw in
		void ParseGrenadeThrowIn(Core::BinaryNetworkReader & reader);

		// parse grenade throw stop
		void ParseGrenadeThrowStop(Core::BinaryNetworkReader & reader);

		// parse throw grenade
		void ParseGrenadeThrowOut(Core::BinaryNetworkReader & reader);

		void ParseGrenadeTiming(Core::BinaryNetworkReader & reader);

		// parse grenade hurt
		void ParseGrenadeHurt(Core::BinaryNetworkReader & reader);

		// parse poke
		void ParsePoke(Core::BinaryNetworkReader & reader);

		// parse poke hurt
		void ParsePokeHurt(Core::BinaryNetworkReader & reader);

		// parse reload
		void ParseReload(Core::BinaryNetworkReader & reader);

		// parse reload ready
		void ParseReloadReady(Core::BinaryNetworkReader & reader);

		// parse select weapon
		void ParseSelectWeapon(Core::BinaryNetworkReader & reader);

		// parse drop gun
		void ParseDropWeapon(Core::BinaryNetworkReader & reader);

		// parse pick up gun
		void ParsePickUpWeapon(Core::BinaryNetworkReader & reader);

		// parse dropped gun destroy
		void ParseDroppedWeaponDestroy(Core::BinaryNetworkReader & reader);

		// parse add weapon
		void ParseAddDroppedWeapon(Core::BinaryNetworkReader & reader);

		// parse add supply
		void ParseAddDroppedSupply(Core::BinaryNetworkReader & reader);

		// parse pick up supply object
		void ParsePickUpSupplyObjectNew(Core::BinaryNetworkReader & reader);

		// parse syn server script value
		void ParseSynServerScriptValue(Core::BinaryNetworkReader & reader);

		// parse synscore
		void ParseSynScore(Core::BinaryNetworkReader & reader);

		void ParseMessageClient(Core::BinaryNetworkReader & reader);

		// parse add supply object
		void ParseAddSupplyObject(Core::BinaryNetworkReader & reader);

		// parse pick up supply object
		void ParsePickUpSupplyObject(Core::BinaryNetworkReader & reader);

		// parse destroy supply object
		void ParseDestroySupplyObject(Core::BinaryNetworkReader & reader);

		// parse sync time
		void ParseSyncTime(Core::BinaryNetworkReader & reader);

		// parse game end
		void ParseGameEnd(Core::BinaryNetworkReader & reader);

		// parse game leave
		void ParseGameLeave(Core::BinaryNetworkReader & reader);
		
		// parse round start
		void ParseRoundStart(Core::BinaryNetworkReader & reader);

		// parse round start play
		void ParseRoundStartPlay(Core::BinaryNetworkReader & reader);
		
		// parse round end
		void ParseRoundEnd(Core::BinaryNetworkReader & reader);

		// parse set team
		void ParseSetTeam(Core::BinaryNetworkReader & reader);

		// parse recover health
		void ParseHealthRecover(Core::BinaryNetworkReader & reader);

		// parse player spawn timing
		void ParsePlayerSpawnTiming(Core::BinaryNetworkReader & reader);

		// parse recover stop
		void ParseRecoverStop(Core::BinaryNetworkReader & reader);

		// parse flash bright
		void ParseFlashBright(Core::BinaryNetworkReader & reader);

		// parse camera fov changed
		void ParseCameraFovChanged(Core::BinaryNetworkReader & reader);

		// parse ammo recover
		void ParseAmmoRecover(Core::BinaryNetworkReader & reader);

		void ParseAmmoDisappear(Core::BinaryNetworkReader & reader);

		// parse armor recover
		void ParseArmorRecover(Core::BinaryNetworkReader & reader);

		void ParseGameStartTimer(Core::BinaryNetworkReader & reader);

		void ParseCurePower(Core::BinaryNetworkReader & reader);

		// parse skill achieve
		void ParseSkillAchieve(Core::BinaryNetworkReader & reader);

		// parse supply ready
		void ParseSupplyReady(Core::BinaryNetworkReader & reader);

		// parse use skill
		void ParseUseSkill(Core::BinaryNetworkReader & reader);

		// parse use cure skill
		void ParseUseCureSkill(Core::BinaryNetworkReader & reader);

		void ParseCancelInvisible(Core::BinaryNetworkReader & reader);

		void ParseUseSmog(Core::BinaryNetworkReader & reader);

		// parse use skill stop
		void ParseUseSkillStop(Core::BinaryNetworkReader & reader);

		// parse supply radar
		void ParseSupplyRadar(Core::BinaryNetworkReader & reader);

		// parse change pack
		void ParseChangePack(Core::BinaryNetworkReader & reader);

		// parse kick client start
		void ParseKickClientStart(Core::BinaryNetworkReader & reader);

		// parse kick client error
		void ParseKickClientError(Core::BinaryNetworkReader & reader);

		// parse kick client end
		void ParseKickClientEnd(Core::BinaryNetworkReader & reader);

		// parse kick client vote
		void ParseKickClientVote(Core::BinaryNetworkReader & reader);

		// parse radio report
		void ParseRadioReport(Core::BinaryNetworkReader & reader);

		// parse action on
		void ParseActionOn(Core::BinaryNetworkReader & reader);

		// parse projectedammo out
		void ParseProjectedAmmoOut(Core::BinaryNetworkReader & reader);

		////����buff
		//void ParseDieBuff(Core::BinaryNetworkReader & reader);

		// parse projectedammo destroy
		void ParseProjectedAmmoDestroy(Core::BinaryNetworkReader & reader);

		// parse projectedammo update
		void ParseProjectedAmmoUpdate(Core::BinaryNetworkReader & reader);

		// parse projectedammo hurt
		void ParseProjectedAmmoHurt(Core::BinaryNetworkReader & reader);

		void ParseProjectedProdHurt(Core::BinaryNetworkReader & reader);

		// parse pveammo out
		void ParsePVEAmmoOut(Core::BinaryNetworkReader & reader);

		// parse pveammo destroy
		void ParsePVEAmmoDestroy(Core::BinaryNetworkReader & reader);

		// parse pveammo hithurt
		void ParsePVEAmmoHitHurt(Core::BinaryNetworkReader & reader);

		// parse pveammo explodehurt
		void ParsePVEAmmoExplodeHurt(Core::BinaryNetworkReader & reader);

		// parse pveammo update
		void ParsePVEAmmoUpdate(Core::BinaryNetworkReader & reader);

		// parse animation start
		void ParsePlayerAnimationStart(Core::BinaryNetworkReader & reader);

		// parse animation end
		void ParsePlayerAnimationEnd(Core::BinaryNetworkReader & reader);

		// parse call doctor
		void ParseCallDoctor(Core::BinaryNetworkReader & reader);

		// parse sync holdpointinfo
		void ParseSyncHoldPointInfo(Core::BinaryNetworkReader & reader);

		void ParseUpdateVehicleInfo(Core::BinaryNetworkReader & reader);

		void ParseInitializeVehicleInfo(Core::BinaryNetworkReader & reader);

		void ParsePlayerHitBack(Core::BinaryNetworkReader & reader);

		void PareseDrumEffect(Core::BinaryNetworkReader & reader);
	
		void PareseDrink(Core::BinaryNetworkReader & reader);

		// notify room host changed
		void ParseNotifyRoomHostChanged(Core::BinaryNetworkReader & reader);

		void ParseSprayClear(Core::BinaryNetworkReader & reader);

		void ParseSpray(Core::BinaryNetworkReader & reader);

		// notify chat
		void ParseNotifyChat(Core::BinaryNetworkReader & reader);

		void ParseBossModeAliveChanged(Core::BinaryNetworkReader & reader);

		void ParseChangeAmmoTeam(Core::BinaryNetworkReader & reader);

		void ParseSyncSkillEffect(Core::BinaryNetworkReader & reader);

		void ParseSpawnCoin(Core::BinaryNetworkReader & reader);

		void ParseStartPlantBomb(Core::BinaryNetworkReader& reader);

		void ParseCancelPlantBomb(Core::BinaryNetworkReader& reader);

		void ParsePlantBombSuccess(Core::BinaryNetworkReader & reader);

		void ParsePickUpBomb(Core::BinaryNetworkReader & reader);

		void ParseDefuseBombSuccess(Core::BinaryNetworkReader & reader);

		void ParseBombExploded(Core::BinaryNetworkReader & reader);

		void ParseStartDefuseBomb(Core::BinaryNetworkReader & reader);

		void ParseStreetKing_Flash(Core::BinaryNetworkReader & reader);

		void ParseZombie_Flash(Core::BinaryNetworkReader & reader);

		void ParseZombieMode_PlayerDying(Core::BinaryNetworkReader & reader);

		void ParseZombieModeStartSaveDying(Core::BinaryNetworkReader & reader);
		
		void ParseZombieModeCancelSaveDying(Core::BinaryNetworkReader & reader);

		void ParseZombieModeHumanRespawn(Core::BinaryNetworkReader & reader);

		void ParseZombieModeStepTwo(Core::BinaryNetworkReader & reader);

		void ParseZombieModeStartGame(Core::BinaryNetworkReader & reader);

		void ParseZombieBomer(Core::BinaryNetworkReader & reader);

		void ParseZombieBomerHurt(Core::BinaryNetworkReader & reader);

		void ParseChargeSomething(Core::BinaryNetworkReader & reader);

		void ParseCommonZombie_Flash(Core::BinaryNetworkReader & reader);

		void ParseCommonKingZombie_Flash(Core::BinaryNetworkReader & reader);

		void ParsCommonZombie_LevelChange(Core::BinaryNetworkReader & reader);

		void ParseCommonZombie_EnergyChange(Core::BinaryNetworkReader & reader);

		void ParseCommonZombie_Super(Core::BinaryNetworkReader & reader);

		void ParseCommonHuman_Super(Core::BinaryNetworkReader & reader);

		void ParseCommonZombie_Unable(Core::BinaryNetworkReader & reader);

		void ParseKing_Zombie_Respawn(Core::BinaryNetworkReader & reader);

		void ParseHumanEnergyChange(Core::BinaryNetworkReader & reader);

		void ParseHumanPowerUp(Core::BinaryNetworkReader & reader);

		void ParseUseSkillSuperMan(Core::BinaryNetworkReader & reader);
		
		void ParseSkillSuperManSuccess(Core::BinaryNetworkReader & reader);

		void ParseCommonZombieHumanDie(Core::BinaryNetworkReader & reader);

		void ParseSycnBossAction(Core::BinaryNetworkReader & reader);

		void ParseBoss2Flash(Core::BinaryNetworkReader & reader);

		void ParseBoss2Showtime(Core::BinaryNetworkReader & reader);

		void ParseBoss2SyncData(Core::BinaryNetworkReader & reader);

		void ParseUseItem_ItemMode(Core::BinaryNetworkReader & reader);
		

		void ParseItemMode_ZiBao(Core::BinaryNetworkReader & reader);

		void ParseItemModeSyncData(Core::BinaryNetworkReader & reader);

		void ParseTDMode_ResHpChange(Core::BinaryNetworkReader & reader);

		void ParseSM_MoonMode_PickWin(Core::BinaryNetworkReader & reader);

		void ParseSM_UseItem_SurvivalMode(Core::BinaryNetworkReader & reader);

		void ParseSM_UseItem_Trap(Core::BinaryNetworkReader & reader);

		void ParseSM_UseItem_Trap_Trigger(Core::BinaryNetworkReader & reader);

		void ParseTrap_HP_Disappear(Core::BinaryNetworkReader & reader);

		void ParseSurvivalMode_Ghost(Core::BinaryNetworkReader & reader);

		void ParseDieBuffData(Core::BinaryNetworkReader & reader);

		void ParseCutHurt(Core::BinaryNetworkReader & reader);

		void ParseNotifyDummyObjectCreate(Core::BinaryNetworkReader & reader);

		void ParseNotifyDummyObjectDestory(Core::BinaryNetworkReader & reader);

		void ParseDummyObjectSyncUpdate(Core::BinaryNetworkReader & reader);

		void PraseDummyChangeOwner(Core::BinaryNetworkReader & reader);

		void ParseGunTowerShoot(Core::BinaryNetworkReader & reader);

		void ParseGunTowerHurt(Core::BinaryNetworkReader & reader);
		
		void ParseTeleport(Core::BinaryNetworkReader & reader);

		void ParseRefreshBagItem(Core::BinaryNetworkReader & reader);
	private:
		State state;
		uint game_state;	

	public:
		RoomInfo room_info;

		int game_win_team;
		int round_win_team;

		Core::UdpConnection udp_connection;
		Core::TcpConnection tcp_connection;
		
		Core::Array<sharedc_ptr(MessagePacket)> message_set;
		float game_time;
		bool client_connecting;
		int replay_index;
		bool game_parse;
		float game_rate;
	private:
		float player_sync_time;
		ushort player_status;
		byte player_weapon;
		Core::Vector3 player_position;
		Core::Quaternion player_rotation;

		float ammo_sync_time;
		float dummy_sync_time;

		float network_delay;

		// network encoder
		Core::XORNetworkEncoder xor_encoder;
		// network compressor
		Core::HuffmanNetworkCompressor huffman_compressor;

	public:
		void CreateRoomTest();

	};
}