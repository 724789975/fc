namespace Client
{
	struct RifleInfo : public GunInfo
	{
		float normal_up_base;
		float normal_lateral_base;
		float normal_up_modifier;
		float normal_lateral_modifier;
		float normal_up_max;
		float normal_lateral_max;
		float normal_dir_change;

		float move_up_base;
		float move_lateral_base;
		float move_up_modifier;
		float move_lateral_modifier;
		float move_up_max;
		float move_lateral_max;
		float move_dir_change;

		float onair_up_base;
		float onair_lateral_base;
		float onair_up_modifier;
		float onair_lateral_modifier;
		float onair_up_max;
		float onair_lateral_max;
		float onair_dir_change;

		float crouch_up_base;
		float crouch_lateral_base;
		float crouch_up_modifier;
		float crouch_lateral_modifier;
		float crouch_up_max;
		float crouch_lateral_max;
		float crouch_dir_change;

		RifleInfo()
		{
			weapon_type = kWeaponTypeRifle;
		}
		
	};
	
	class RifleGun : public GunBase , public ChangeNodeEventBase
	{
	public:
		RifleGun(by_ptr(RifleInfo) info);

	public:
		DECLARE_PDE_ATTRIBUTE_R(weapon_info, tempc_ptr(RifleInfo))
		{
			return rifle_info;
		}

	public:
		/// update
		virtual void Update(float time);
		
		/// initialize
		virtual void Initialize();

		/// can active
		virtual bool CanActive();

		/// reload
		virtual bool Reload();

		/// active
		virtual void Active();

		/// inactive
		virtual void Inactive();

		/// get weapon type
		virtual uint GetWeaponType();

		/// draw crosshair
		virtual void DrawCrossHair(by_ptr(UIRender) ui_render);

		virtual void OnAnimationStartFPEvent(const Core::Identifier & groupname, int & index);
		virtual void OnAnimationStartTPEvent(const Core::Identifier & groupname, int & index);
		virtual void OnAnimationEndFPEvent(const Core::Identifier & groupname, int & index);	
		virtual void OnAnimationEndTPEvent(const Core::Identifier & groupname, int & index);	
	private:
		virtual void reSetModeToCurrent();

	public:
		/// fire
		virtual bool Fire();
		virtual void SpecialAbilities(bool keydown = false);
		enum SightState
		{
			NormalSight = 0,
			X1Sight,
			X2Sight,
			X3Sight,
			X4Sight
		};
		SightState currentSight;
		SightState tempSight;
		bool availbleToSetSight;
		
		/// change mode
		virtual void ChangeModeToNext();
		virtual void SetModeToX0();
		virtual void SetModeToX1();
		virtual void SetModeToX2();
		virtual void SetModeToX3();
		virtual void SetModeToX4();



	public:
		sharedc_ptr(RifleInfo)	rifle_info;
		bool is_play:1;
		int  source_fov;
		int  target_fov;
		float raise_time;

		bool is_sight : 1;
	};

}