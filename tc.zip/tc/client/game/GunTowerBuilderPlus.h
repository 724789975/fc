namespace Client
{
	struct GunTowerTypeInfo
	{
		GunTowerTypeInfo(){}
		int DummyObjectType;
		int DummyObjectSubType;
		int SystemId;//info �õ�
		int MaxCount;
		//int Count;
		float Width;
		float Height;
		Core::String ResKey;
	};
	struct GunTowerBuilderPlusInfo : public GunInfo
	{
		int					gun_tower_dir;
		float				max_distance;
		float				max_lift_time;
		float				hurt_range;
		float				show_speed;

		float				move_speed;
		float				move_keep_time;

		float				recover_range;
		float				recover_check_interval;
		float				recover_per_count_life;
		float				recover_per_percent_ammo;
		float				recover_per_minus_ammo;
		float outer_width;//���ڼ�����������Ƿ񽻲�
		float outer_height;//���ڼ�����������Ƿ񽻲�
		Core::Array<GunTowerTypeInfo> m_aTowerTypeInfo;

		GunTowerBuilderPlusInfo()
		{
			weapon_type = kWeaponTypeGunTowerBuilderPlus;
			gun_tower_dir = 0;
			outer_width =2;
			outer_height =2;
		}
		int m_iMaxWallCount;
		int m_iMaxGuardCount;
	};

	class GunTowerBuilderPlus : public WeaponBase
	{
	public:
		/// constructor
		GunTowerBuilderPlus(by_ptr(GunTowerBuilderPlusInfo) info);

		/// destructor
		virtual ~GunTowerBuilderPlus();

		/// get weapon type
		virtual uint GetWeaponType() { return kWeaponTypeGunTowerBuilderPlus; }

	public:
		/// draw
		virtual void Draw(Primitive::DrawType drawtype, bool immediate = false);

		/// initialize
		virtual void Initialize();

		/// udpate
		virtual void Update(float frame_time);

		/// can active
		virtual bool CanActive();

		/// active
		virtual void Active();

		/// inactive
		virtual void Inactive();

		/// update mesh
		virtual void UpdateMesh();

		/// draw ui
		virtual void DrawUI(by_ptr(UIRender) ui_render);
	public:
		/// get position
		virtual const Core::Vector3 & GetPosition();

		/// set position
		virtual void SetPosition(const Core::Vector3 & pos);

		/// plant
		void Plant(const Core::Vector3 & position);

		void EndPlant();

		void StopPlantTower();

		/// create physx
		void CreatePhysx();

		bool CanPlant();

		int GetGunTowerDir();

		void ChangeDir();

		bool IsExistTower();

		bool HasStatic();

		const Core::Vector3 GetTowerMeshPosition(const Core::Vector3 & pos);

		int GetAmmoCount();

		void SetAmmoCount(int ammocount);

		int GetMaxAmmoCount();

		bool CanPlantMore();

		void DestroyTower(const int type, const Core::String& szResKey);
		void DestroyTower(sharedc_ptr(DummyObject) oDummy);

		int GetSystemId(const int type, const Core::String& szResKey);
	public:
		int GetTowerTypeCount()const;
		GunTowerTypeInfo GetTowerType(int iIdx)const;
		bool TryCreateTower();
		void SetActiveTower(const int iIdx);
		int GetActiveTower()const;
	public:
		Core::Vector3 GetHitGridItem();
		Core::Vector3 GetPlantPosition();
		Core::Quaternion GetPlantRotation();
		Core::Vector2 GetGridItemSize();
		Core::Vector2 GetGridItemCount();
		Core::Vector2 GetMapSize();
	public:
		sharedc_ptr(GunTowerBuilderPlusInfo)	tower_info;
		int m_iActiveTowerIdx;
		bool					on_request_planting;
		int m_iReqPlantingIndex;
		sharedc_ptr(StaticMesh)			able_tower_mesh;
		sharedc_ptr(StaticMesh)			unable_tower_mesh;
		sharedc_ptr(StaticMesh)			tower_direction_mesh;
	private:
		byte					state;
		sharedc_ptr(SkinMesh) bag_mesh;
		sharedc_ptr(Skeleton) bag_skeleton;
		sharedc_ptr(Pose)	 bag_pose;
		int					ammo_count;
	};
}