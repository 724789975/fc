#include "pch.h"

using namespace Core;
using namespace Client;

DEFINE_PDE_TYPE_CLASS(Client::SniperGunInfo)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Client::GunInfo);

		//ADD_PDE_FIELD(sight_normal_offset);
		//ADD_PDE_FIELD(sight_onair_offset);
		//ADD_PDE_FIELD(sight_move_offset);
		ADD_PDE_FIELD(move_speed_offset_x0);
		ADD_PDE_FIELD(move_speed_offset_x1);
		ADD_PDE_FIELD(move_speed_offset_x2);

		ADD_PDE_DEFAULT_CONSTRUCTOR();
	}
};

REGISTER_PDE_TYPE(Client::SniperGunInfo);

namespace Client
{
	/// constrcutor
	SniperGun::SniperGun(by_ptr(SniperGunInfo) info)
		:charge_time(0.f)
	{
		weapon_info = gun_info = info;
	}

	/// initialize
	void SniperGun::Initialize()
	{
		GunBase::Initialize();
		accuracy = 0.92f;

		charge_time = 0.f;
		hurt_rate = 1.0f;

		alpha_value = 255.f;
		fadein = false;

		progress_bar01	= RESOURCE_LOAD_NEW("InGameUI/ig_common_miaozhunjing_bg.dds", true, Texture2D);
		progress_bar02	= RESOURCE_LOAD_NEW("InGameUI/ig_common_miaozhunjing_content.dds", true, Texture2D);
		
	}

	/// active
	void SniperGun::Active()
	{
		if (gun_audio_energy_2d)
			gun_audio_energy_2d->stop();

		GunBase::Active();
	}

	/// inactive
	void SniperGun::Inactive()
	{
		if (gun_audio_energy_2d)
			gun_audio_energy_2d->stop();

		GunBase::Inactive();
	}

	/// get weapon type
	uint SniperGun::GetWeaponType()
	{
		return kWeaponTypeSniperGun;
	}

	/// fire
	bool SniperGun::Fire()
	{		
		tempc_ptr(Character) player = GetOwner();

		if (!player)
			return false;

		tempc_ptr(SniperGunInfo) sniper_info = ptr_static_cast<SniperGunInfo>(weapon_info);
		if(!sniper_info)
			return false;

		if(sight_current == 0)	
		{
			float spread = 0;
			if (!player->IsOnGround())
				spread = sniper_info->onair_offset;
			else if (player->IsMoving())
				spread = sniper_info->move_offset;//0.25 is too accuratxxx
			else
				spread = sniper_info->normal_offset;//0.1d

			if (!FireBase(spread))
				return false;
		}
		else//in X1 X2 mode:the spread=0
		{
			float spread = 0;
			if (!player->IsOnGround())
				spread = sniper_info->sight_onair_offset;
			else if (player->IsMoving())
				spread = sniper_info->sight_move_offset;
			else
				spread = sniper_info->sight_normal_offset;

			if (!FireBase(spread))
				return false;
		}

		KickBack (13.0f, 0.45f, 4.28f, 0.045f, 3.75f, 3.f, 7);
		return true;
	}

	/// change mode
	void SniperGun::SpecialAbilities(bool keydown)
	{
		if(keydown)
			return;	

		if(reloading)
			return;

		tempc_ptr(Character) player = GetOwner();
		if (!player)
			return;
		if(player->weapon_select_state != Character::kWeaponReady)
			return;

		if (idle_time <= 0 && next_fire_time <= 0 && (gun_info->auto_fire || delay_fire == false))
			ChangeSight();
	}

	/// set sight
	void SniperGun::SetSight(int id)
	{
		GunBase::SetSight(id);

		if (id == 1)
		{
			tempc_ptr(Character) player = GetOwner();
			if (player == gLevel->GetPlayer())
				gLevel->isGunSensitivity = true;
			
			if (gun_audio_energy_2d)
			{
				FMOD_EVENT_STATE audio_state = FMOD_EVENT_DEFAULT;
				gun_audio_energy_2d->getState(&audio_state);
				if ((audio_state & FMOD_EVENT_STATE_PLAYING) == 0)
				{
					gun_audio_energy_2d = FmodSystem::GetEvent("bj/fx/2d/sniper_energy");
					gun_audio_energy_2d->start();
				}
			}
		}
		else if (id == 0)
		{
			tempc_ptr(Character) player = GetOwner();
			if (player == gLevel->GetPlayer())
				gLevel->isGunSensitivity = false;

			if (gun_audio_energy_2d)
				gun_audio_energy_2d->stop();
		}

		if (id == 0)
		{
			charge_time = 0.f;
			hurt_rate = 1.0f;
			alpha_value = 255;
			fadein = false;
		}
		else if (sight_temp == 0)
		{
			charge_time = 0.f;
			hurt_rate = 1.0f;
		}
	}

	void SniperGun::ChargeFlash(float min_Value, float in_value, float out_value, float max_Value)
	{
		if (fadein)
		{
			alpha_value += in_value;
			if (alpha_value >= max_Value)
			{
				alpha_value = max_Value;
				fadein = false;
			}
		}
		else
		{
			alpha_value -= out_value;
			if (alpha_value < min_Value)
			{
				alpha_value = min_Value;
				fadein = true;
			}
		}
	}

	/// update
	void SniperGun::Update(float time)
	{
		WeaponBase::Update(time);
		tempc_ptr(Character) player = GetOwner();
		if (!player)
			return;
		if (!gun_info)
			return;
		if (ammo_in_clip == 0 && ammo_count > 0)
			player->Reload();

		next_fire_time -= time;
		if (next_fire_time <= 0.1f && idle_time <= 0.1f)
			SetSightCurrent();

		tempc_ptr(SniperGunInfo) sniper_info = ptr_static_cast<SniperGunInfo>(weapon_info);
		if (sight_current > 0)
		{
			float p = player->GetTotalAttributeByType(kEffect_Infect_GunEnergy);
			
			if (charge_time > sniper_info->readytime)
			{
				charge_time = sniper_info->readytime;

				
				FMOD_EVENT_STATE audio_state = FMOD_EVENT_DEFAULT;
				gun_audio_energy_2d->getState(&audio_state);
				LogSystem.WriteLinef("123��%d ",(int)audio_state);
				if ((audio_state & FMOD_EVENT_STATE_PLAYING) == 1)
				{
					gun_audio_energy_2d->stop();
					gun_audio_energy_2d = FmodSystem::GetEvent("bj/fx/2d/sniper_energy_complete");

					gun_audio_energy_2d->start();
				}
				
			}
			else
				charge_time += time * p;
			if(charge_time == sniper_info->readytime)
			{
				ChargeFlash(100.f, time*700.f, time*400.f);
			}
			hurt_rate = 1.0f + (charge_time / sniper_info->readytime) * 2.0f;
		}

		if (reloading)
		{
			reload_time -= time;
			if (reload_time < 0)
			{
				int ammo_need = gun_info->ammo_one_clip - ammo_in_clip;

				if (ammo_need > 0)
				{
					if (ammo_need < ammo_count)
					{
						ammo_in_clip = gun_info->ammo_one_clip;
						ammo_count -= ammo_need;
					}
					else
					{
						ammo_in_clip += ammo_count;
						ammo_count = 0;
					}
				}
				reloading = false;
				player->reloading = false;
				shots_fired = 0;
				decrease_shots_fired = 0;
				delay_fire = false;
			}
		}
		else if (player->first_action_on)
		{
			if (idle_time <= 0 && next_fire_time <= 0 && (gun_info->auto_fire || delay_fire == false))
			{

				if (player->CanFire() && Fire())
				{
					next_fire_time = gun_info->fire_time;
					idle_time =  weapon_info->time_to_idle;
				}
				else
					player->StopShoot();
			}
		}
		else
		{
			player->StopShoot();
			if (delay_fire)
			{
				delay_fire = false;
				if (shots_fired > 15)
				{
					shots_fired = 15;
				}
				decrease_shots_fired += 0.4f;
			}

			//if (GetWeaponType() == kWeaponTypePistol)
			if (!gun_info->auto_fire)
				shots_fired = 0;

			if (shots_fired > 0)
			{
				decrease_shots_fired -= time;
				if (decrease_shots_fired < 0)
				{
					decrease_shots_fired = 0.0225f;
					shots_fired--;
				}
			}
		}

		UpdateEffect(time);
	}

	///reload
	bool SniperGun::Reload()
	{
		if (CanReload())
		{
			reloading = true;

			ReloadAction();
			reload_time = gun_info->reload_time;
			return true;
		}
		return false;
	}


	/// draw crosshair
	void SniperGun::DrawCrossHair(by_ptr(UIRender) ui_render)
	{
		tempc_ptr(Character) c = GetOwner();

		if (!c)
			return;

		if (!gun_info)
			return;

		F32 len = 1;
		if (gGame && gGame->camera)
		{
			len = gGame->camera->GetFar() * 0.5f;

			NxRay ray;
			ray.orig = (const NxVec3 &)gGame->camera->position;
			ray.dir = (const NxVec3 &)(Vector3(0, 0, -1) * gGame->camera->rotation);

			NxRaycastHit hit;
			float distance = 500;
			uint group_id = 0;
			group_id |= 1 << PhysxSystem::kStatic;
			group_id |= 1 << PhysxSystem::kStaticRaycast;
			for (uint i = 0; i < 2; ++i)
			{
				group_id |= 1 << (PhysxSystem::kGroupStart + i);
			}
			group_id |= 1 << PhysxSystem::kGroupVehicle;

			NxShape* shape = gPhysxScene->raycastClosestShape(ray, NX_ALL_SHAPES, hit, group_id, distance);
			if (shape)
			{
				//len = Length(gGame->camera->position - (const Vector3 &)hit.worldImpact);
				len = hit.distance;
			}
		}

		F32 v = gDx9Device->convergence > 0 ? gDx9Device->convergence : 1;
		if (gDx9Device->GetStereoEnable() &&  len> 0)
			v = len;

		gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_CONVERGENCE, &v, 1);

		if (c->GetViewMode() == Character::kFirstPerson && gun_info->sight_info.Size() > 0 && c->camera_fov <= gun_info->sight_info[1].level)
		{
			Matrix44 view;
			Vector3 rt_size = ui_render->GetRenderTargetSize();
			view.SetScaleXYZ(2.0f / rt_size.x, -2.0f / rt_size.y, 0);
			view.TranslateXYZ(-1, 1, 0);
			view.TranslateLocalXYZ(-0.5f, -0.5f, 0);
			ui_render->SetWorld(Matrix44::kIdentity);
			ui_render->SetView(view);
			ui_render->SetProjection(Matrix44::kIdentity);
			//ui_render->VertexColor(Color4::kBlack);
			ui_render->SetTexture(gun_info->sight);
			ui_render->BeginRectangleList(1);
			float uv_offset = (rt_size.x - rt_size.y) / rt_size.y * 0.5f;
			ui_render->Vertex(0, 0, 0, -uv_offset, 0, ARGB(255, 255, 255));
			ui_render->Vertex(rt_size.x, rt_size.y, 0, 1 + uv_offset, 1, ARGB(255, 255, 255));
			ui_render->End();

			if (c == gLevel->GetPlayer())
			{
				float w = rt_size.x * 0.5f + 125.f;
				float h = rt_size.y * 0.5f + 65.f;
				tempc_ptr(SniperGunInfo) sniper_info = ptr_static_cast<SniperGunInfo>(weapon_info);
				if (sniper_info)
				{
					CStrBuf<256> buff;
					float progress = Clamp(charge_time/sniper_info->readytime, 0, 1);

					view.SetTranslationXYZ(rt_size.x*0.5f + 220, rt_size.y*0.5f - 10, 0.f);
					ui_render->SetWorld(view);
					if (progress_bar01 && progress_bar02)
					{
						ui_render->DrawTextureWindow(Core::Vector2(-160, 143), 244, 32, progress_bar01);
						ui_render->DrawTextureWindow(Core::Vector2(-124, 154), progress*202, 12, progress_bar02, Core::Rectangle(0,0,1,1),Core::ARGB((U8)alpha_value, 255-5*progress, 255-220*progress, 255-220*progress));
					}
				}
			}
		}
		else
		{
			GunBase::DrawCrossHair(ui_render);
		}

		if (gDx9Device->GetStereoEnable())
			v = gDx9Device->convergence > 0 ? gDx9Device->convergence : 1;

		gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_CONVERGENCE, &v, 1);
	}
}