#include "pch.h"

using namespace Core;

DEFINE_PDE_TYPE_CLASS(Client::PVEAmmoLaserInfo)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_METHOD(SetMesh);
		ADD_PDE_METHOD(AddBoxDesc);
		ADD_PDE_METHOD(AddCapsuleDesc);

		ADD_PDE_FIELD(skeleton);
		ADD_PDE_FIELD(last_time);
		ADD_PDE_FIELD(fire_distance);
		ADD_PDE_FIELD(hit_interval);

		ADD_PDE_FIELD(scale_begin);
		ADD_PDE_FIELD(scale_end);
		ADD_PDE_FIELD(scale);

		ADD_PDE_FIELD(hit_damage);
		ADD_PDE_FIELD(hit_decal);
		ADD_PDE_FIELD(fillammo_particle);
		ADD_PDE_FIELD(bright_particle);
		ADD_PDE_FIELD(fillammotime);

		ADD_PDE_FIELD(fillammo_sound);
		ADD_PDE_FIELD(fire_sound);
	}
};

DEFINE_PDE_TYPE_CLASS(Client::PVEAmmoLaser)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
	}
};

REGISTER_PDE_TYPE(Client::PVEAmmoLaserInfo);
REGISTER_PDE_TYPE(Client::PVEAmmoLaser);

namespace Client
{
	///////////////////////////////////////////////////////////////////////////////
	void PVEAmmoLaserInfo::SetMesh(const Core::Identifier & value, const U32 lod_level)
	{
		if (!gRender->lod_control->HasLod() && lod_level > 0)
			return;

		mesh[lod_level] = value;
	}

	///////////////////////////////////////////////////////////////////////////////
	PVEAmmoLaser::PVEAmmoLaser()
		: m_Actor(NULL)
		, m_AmmoId(0)
		, m_SyncTime(0)
		, m_fmod_fire01(NULL)
		, m_fmod_fire02(NULL)
	{
		m_Position = Vector3::kZero;
		m_Rotation = Quaternion::kIdentity;
		Reset();
	}

	PVEAmmoLaser::~PVEAmmoLaser()
	{
		ReleasePhysx();
	}

	bool PVEAmmoLaser::Initialize(U16 ammo_id, by_ptr(PVEAmmoLaserInfo) ammo_info, by_ptr(Character) owner)
	{
		static const char szTeam[2] = {'r', 'b'};

		if (!ammo_info || !owner)
			return false;

		byte team = owner->GetTeam();

		sharedc_ptr(PVEAmmoLaserInfo) ammo_info_new = ptr_new PVEAmmoLaserInfo(*ammo_info);

		//�ܵĳ���ʱ����Ҫ���Ϸ�������ʱ��
		ammo_info_new->last_time += (ammo_info_new->scale_begin + ammo_info_new->scale_end + ammo_info_new->fillammotime);
		m_AmmoInfo = ammo_info_new;
		m_AmmoId = ammo_id;
		m_Owner = owner;
		
		m_Mesh = ptr_new SkinMesh(MESH_KEY_SCENEPROP);
		if (m_Mesh)
		{
			for (U32 i = 0; i < MESH_LOD_LEVEL; i++)
			{
				if (m_Mesh->AddPrimitive(m_AmmoInfo->mesh[i], m_AmmoInfo->mesh[i], i))
				{
				}
			}

			m_Skeleton = RESOURCE_LOAD(m_AmmoInfo->skeleton, false, Skeleton);
			if (m_Skeleton)
			{
				m_Pose = m_Mesh->pose = ptr_new Pose(m_Skeleton);
			}
			m_Mesh->SetScale(Vector3(0.01f,0.01f,1.f));
		}

		if (m_AmmoInfo->fillammo_particle.Length() > 0)
		{
			m_FillParticle = ptr_new ParticleSystem(m_AmmoInfo->fillammo_particle.Str(), false);
			m_FillParticle->SetPosition(Vector3(0,-100,0));
			m_FillParticle->Update(0);
			m_FillParticle->SetEnable(true);
		}

		if (m_AmmoInfo->bright_particle.Length() > 0)
		{
			m_BrightParticle = ptr_new ParticleSystem(m_AmmoInfo->bright_particle.Str(), false);
			m_BrightParticle->SetPosition(Vector3(0,-100,0));
			m_BrightParticle->Update(0);
			m_BrightParticle->SetEnable(true);
		}

		CreatePhysx(team + PhysxSystem::kGroupProjectStart, Vector3::kZero, Quaternion::kIdentity);
		StopPhysx();

		Update(0);

		return true;
	}

	void PVEAmmoLaser::CreatePhysx(int group, const Core::Vector3 &pos, const Core::Quaternion &rot)
	{
		{
			NxBodyDesc bodyDesc;

			NxActorDesc actorDesc;
			actorDesc.body = &bodyDesc;
			actorDesc.density = 100.0f;
			actorDesc.globalPose.t = (const NxVec3 &)pos;
			actorDesc.globalPose.M.fromQuat((const NxQuat &)rot);
			actorDesc.userData = this;

			for (U32 i = 0; i < m_AmmoInfo->boxdescs.Size(); i++)
			{
				NxBoxShapeDesc boxDesc;

				boxDesc.localPose.t = (const NxVec3 &)m_AmmoInfo->boxdescs[i].position;
				boxDesc.localPose.M.fromQuat((const NxQuat &)m_AmmoInfo->boxdescs[i].rotation);
				boxDesc.group = group;
				boxDesc.userData = this;

				boxDesc.dimensions = (const NxVec3 &)m_AmmoInfo->boxdescs[i].dimensions;

				actorDesc.shapes.pushBack(&boxDesc);
			}

			for (U32 i = 0; i < m_AmmoInfo->capsuledescs.Size(); i++)
			{
				NxCapsuleShapeDesc capsuleDesc;

				capsuleDesc.localPose.t = (const NxVec3 &)m_AmmoInfo->capsuledescs[i].position;
				capsuleDesc.localPose.M.fromQuat((const NxQuat &)m_AmmoInfo->capsuledescs[i].rotation);
				capsuleDesc.group = group;
				capsuleDesc.userData = this;

				capsuleDesc.radius = m_AmmoInfo->capsuledescs[i].radius;
				capsuleDesc.height = m_AmmoInfo->capsuledescs[i].height;

				actorDesc.shapes.pushBack(&capsuleDesc);
			}

 			m_Actor = PhysxSystem::CreateActor(actorDesc);

			if (m_Actor)
			{
				m_Actor->updateMassFromShapes(actorDesc.density, 0);
				m_Actor->setAngularDamping(1.0f);
				m_Actor->setLinearDamping(0.0f);
			}
		}
	}

	void PVEAmmoLaser::ReleasePhysx()
	{
		if (m_Actor)
		{
			PhysxSystem::ReleaseActor(*m_Actor);
			m_Actor = NULL;
		}
	}

	void PVEAmmoLaser::StopPhysx()
	{
		if (m_Actor)
		{
			m_Actor->raiseBodyFlag(NX_BF_KINEMATIC);
		}
	}

	/// update
	void PVEAmmoLaser::Update(float frame_time)
	{
		if (isfire)
		{
			if (filltime >= 0)
			{
				if (m_fmod_fire02)
					m_fmod_fire02->stop();
				if (!m_fmod_fire01)
				{
					FMOD_VECTOR vel = {0, 0, 0};
					m_fmod_fire01 = FmodSystem::Play3DEvent(m_AmmoInfo->fillammo_sound,(const FMOD_VECTOR &)GetPosition(),vel);
				}
				else
				{
					FMOD_EVENT_STATE audio_state = FMOD_EVENT_DEFAULT;
					m_fmod_fire01->getState(&audio_state);
					if ((audio_state & FMOD_EVENT_STATE_PLAYING) != 0)
					{
						FMOD_VECTOR vel = {0, 0, 0};
						FmodSystem::Update3DEventPosition(m_fmod_fire01,(const FMOD_VECTOR &)GetPosition(),vel);
					}
					else
					{
						m_fmod_fire01->start();
					}
				}
				filltime -= frame_time;
			}

			firetime += frame_time;
			if (firetime > m_AmmoInfo->last_time)
			{	
				isfire = false;
				if (m_Mesh)
				{
					m_Mesh->SetScale(Vector3(0.01f,0.01f,1.f));
				}
			}
			else if (filltime < 0 && 0 < firetime-m_AmmoInfo->fillammotime && firetime-m_AmmoInfo->fillammotime < m_AmmoInfo->scale_begin && m_AmmoInfo->scale_begin > 0.f)
			{
				if (m_fmod_fire01)
					m_fmod_fire01->stop();
				if (!m_fmod_fire02)
				{
					FMOD_VECTOR vel = {0, 0, 0};
					m_fmod_fire02 = FmodSystem::Play3DEvent(m_AmmoInfo->fire_sound,(const FMOD_VECTOR &)GetPosition(),vel);
				}
				else
				{
					FMOD_EVENT_STATE audio_state = FMOD_EVENT_DEFAULT;
					m_fmod_fire02->getState(&audio_state);
					if ((audio_state & FMOD_EVENT_STATE_PLAYING) != 0)
					{
						FMOD_VECTOR vel = {0, 0, 0};
						FmodSystem::Update3DEventPosition(m_fmod_fire02,(const FMOD_VECTOR &)GetPosition(),vel);
					}
					else
					{
						m_fmod_fire02->start();
					}
				}
				if (m_Mesh)
				{
					Vector3 s;
					Lerp(s, Vector3(0.01f,0.01f,1.f), m_AmmoInfo->scale, Clamp(((firetime-m_AmmoInfo->fillammotime)/m_AmmoInfo->scale_begin),0,1));
					m_Mesh->SetScale(s);
				}
			}
			else if (filltime < 0 && m_AmmoInfo->last_time - firetime < m_AmmoInfo->scale_end && m_AmmoInfo->scale_end > 0.f)
			{
				//LogSystem.WriteLinef("%f   %f",m_AmmoInfo->last_time,firetime);
				if (m_Mesh)
				{
					Vector3 s;
					Lerp(s, m_AmmoInfo->scale, Vector3(0.01f,0.01f,1.f), Clamp(((m_AmmoInfo->scale_end-(m_AmmoInfo->last_time-firetime))/m_AmmoInfo->scale_end),0,1));
					m_Mesh->SetScale(s);
				}
			}

			if (m_FillParticle)
				m_FillParticle->Update(frame_time);
			if (m_BrightParticle)
				m_BrightParticle->Update(frame_time);
		}
	}

	/// on render
	void PVEAmmoLaser::OnRender(float frame_time)
	{
		if (m_Mesh)
		{
			m_Mesh->SetPosition(GetPosition());
			m_Mesh->SetRotation(GetRotation());
			m_Mesh->Update();
		}
		if (isfire && m_FillParticle)
		{
			Vector3 pos = GetPosition();
			Quaternion rot = GetRotation();

			m_FillParticle->SetPosition(pos);
			m_FillParticle->SetRotation(rot);
		}
	}

	/// timestep update
	void PVEAmmoLaser::TimeStepUpdate(float frame_time)
	{
		if (isfire && m_Owner && m_Actor)
		{
			hit_interval-=frame_time;
			if (filltime < 0 && firetime < (m_AmmoInfo->last_time-m_AmmoInfo->scale_end))
			{
				NxSweepQueryHit hit[200];
				Vector3 rot_vec = Vector3(0, 0, -1)*GetRotation();
				rot_vec.Normalize();
				Vector3 firemotion = rot_vec * m_AmmoInfo->fire_distance;
				NxU32 num = m_Actor->linearSweep((const NxVec3 &)firemotion, NX_SF_STATICS | NX_SF_DYNAMICS | NX_SF_ALL_HITS, NULL, 200, hit, NULL);

				if (num > 0)
				{
					for(NxU32 i = 0; i < num ;i++)
					{
						NxActor &actor = hit[i].hitShape->getActor();
						tempc_ptr(Character) p = Character::FromNxActor(actor);
						tempc_ptr(Character) player = gLevel->GetPlayer();
						if (p && p == player && hit_interval < 0)
						{
							hit_interval = m_AmmoInfo->hit_interval;
							if (gGame->channel_connection)
							{
								gGame->channel_connection->PVELaserHitHurt(m_Owner->uid, p->uid, m_AmmoInfo->hit_damage);
							}
						}
					}
				}

				{
					NxRay ray;
					ray.orig = (NxVec3&)GetPosition();
					ray.dir = (NxVec3&)(Vector3(0, 0, -1)*GetRotation());

					NxRaycastHit hit;
					uint group_id = 0;
					group_id |= 1 << PhysxSystem::kStatic;

					NxShape* shape = gPhysxScene->raycastClosestShape(ray, NX_ALL_SHAPES, hit, group_id, m_AmmoInfo->fire_distance);
					if (shape && m_BrightParticle)
					{
						Vector3 pos = (Vector3&)hit.worldImpact;
						pos.y+=0.1f;
						m_BrightParticle->SetPosition(pos);
						Quaternion rot(Vector3(0,0,-1),(Vector3&)hit.worldNormal);
						m_BrightParticle->SetRotation(rot);
					}
				}
			}
		}
	}

	/// draw
	void PVEAmmoLaser::Draw(Primitive::DrawType drawtype, bool immediate)
	{
		if (isfire)
		{
			if (m_Mesh)
				m_Mesh->Draw(drawtype, immediate);
			if (immediate && m_FillParticle)
				m_FillParticle->Draw();
			if (immediate && m_BrightParticle)
				m_BrightParticle->Draw();
		}
	}

	/// is dead
	bool PVEAmmoLaser::IsDead()
	{
		return false;
	}

	/// get id
	U16 PVEAmmoLaser::GetId()
	{
		return m_AmmoId;
	}

	void PVEAmmoLaser::Fire()
	{
		if (!isfire && firetime < m_AmmoInfo->last_time)
		{
			filltime = m_AmmoInfo->fillammotime;
			isfire = true;
		}
	}

	void PVEAmmoLaser::Reset()
	{
		isfire = false;
		firetime = 0;
		filltime = 1;
		if (m_Mesh)
			m_Mesh->SetScale(Vector3(0.01f,0.01f,1.f));
		if (m_AmmoInfo)
		{
			hit_interval = m_AmmoInfo->hit_interval;
		}
		if (m_BrightParticle)
		{
			m_BrightParticle->SetPosition(Vector3(0,-100,0));
			m_BrightParticle->SetRotation(Quaternion::kIdentity);
		}
		if (m_fmod_fire01)
			m_fmod_fire01->stop();
		if (m_fmod_fire02)
			m_fmod_fire02->stop();
	}

	/// get id
	tempc_ptr(PVEAmmoLaserInfo) PVEAmmoLaser::GetAmmoInfo()
	{
		return m_AmmoInfo;
	}

	/// get position
	const Vector3 & PVEAmmoLaser::GetPosition()
	{
		if (m_Actor)
			m_Position = (const Vector3 &)m_Actor->getGlobalPosition();

		return m_Position;
	}

	/// set position
	void PVEAmmoLaser::SetPosition(const Core::Vector3 & pos)
	{
		if (m_Actor)
			m_Actor->setGlobalPosition((const NxVec3 &)pos);

		m_Position = pos;
	}

	/// move position
	void PVEAmmoLaser::MovePosition(const Vector3 & pos)
	{
		if (m_Actor)
			m_Actor->moveGlobalPosition((const NxVec3 &)pos);

		m_Position = pos;
	}

	/// get rotation
	const Core::Quaternion & PVEAmmoLaser::GetRotation()
	{
		if (m_Actor)
			m_Rotation = (const Quaternion &)m_Actor->getGlobalOrientationQuat();

		return m_Rotation;
	}

	/// set rotation
	void PVEAmmoLaser::SetRotation(const Core::Quaternion & rot)
	{
		if (m_Actor)
			m_Actor->setGlobalOrientationQuat((const NxQuat &)rot);

		m_Rotation = rot;
	}

	/// move rotation
	void PVEAmmoLaser::MoveRotation(const Quaternion & rot)
	{
		if (m_Actor)
			m_Actor->moveGlobalOrientationQuat((const NxQuat &)rot);

		m_Rotation = rot;
	}

	void PVEAmmoLaser::UpdateSyncData(float frame_time)
	{
	}

	void PVEAmmoLaser::AddSyncData(byte time, const Core::Vector3 &position, const Core::Vector3 &direction)
	{
	}

	bool PVEAmmoLaser::HasSyncData()
	{
		return false;
	}

	tempc_ptr(PVEAmmoLaser) PVEAmmoLaser::FromNxActor(NxActor & actor)
	{
		Object *obj = (Object*)actor.userData;

		if (obj)
		{
			return ptr_dynamic_cast<PVEAmmoLaser>(obj);
		}

		return NullPtr;
	}

	bool PVEAmmoLaser::GetJointInfo(int joint_id, Core::Vector3 *pos, Core::Quaternion *rot)
	{
		if (m_Skeleton)
		{
			if (joint_id >= 0)
			{
				const Transform & transform = m_Pose->GetJointModelPose(joint_id);

				if (pos)
					*pos = GetPosition() + transform.position * GetRotation();

				if (rot)
					*rot = transform.rotation * GetRotation();

				return true;
			}
		}

		return false;
	}
}
