
namespace Client
{
	struct Transform
	{
		Transform() {}
		Transform(const Core::Vector3 & pos, const Core::Quaternion & rot)
			: position(pos)
			, rotation(rot)
		{
		}

		Core::Vector3		position;
		Core::Quaternion	rotation;
		static const Transform	kNull;
	};

	struct Joint
	{
		/// constructor
		Joint()
			: parent_id(-1)
			, blend_skip(false)
		{
		}

		int					parent_id;
		Core::Identifier	name;
		bool				blend_skip;
		static const Joint	kNull;
	};

	class Pose;

	class Skeleton : public Resource
	{
	public:
		/// constructor
		Skeleton();

	public:
		/// save data
		virtual bool SaveData(Core::Stream & stream);

		/// load data
		virtual sharedc_ptr(Object) LoadData(Core::Stream & stream);

		/// load data
		virtual sharedc_ptr(Object) BuildData();

		/// unload data
		virtual void UnloadData();

		/// on load data
		virtual bool OnLoadData(by_ptr(Object) obj);

		/// get version
		virtual short GetVersion();

	public:
		/// load skeleton
		void LoadSkeleton(const Core::String & path);

		/// get joint
		const Joint & GetJoint(uint id);

		/// get joint set
		const Core::Array<Joint> & GetJointSet();

		/// set joint blend skip
		void SetJointBlendSkip(const Core::Identifier & name, bool blend_skip);

		/// get jonit id
		int GetJointId(const Core::Identifier & name);

		/// get joint parent id
		int GetJointParentId(uint id);

		/// get joint name
		const Core::Identifier & GetJointName(uint id);

		/// get joint count
		uint GetJointCount();

		/// joint is child of
		bool JointIsChildOf(uint id_child, uint id_parent);

		/// get T-pose
		const Core::Array<Transform> & GetLocalPose();

		/// get model pose
		const Core::Array<Transform> & GetModelPose();

		/// get joint local T-pose
		const Transform & GetJointLocalPose(uint id);

		/// get joint model T-pose
		const Transform & GetJonitModelPose(uint id);

		/// get name
		const Core::Identifier & GetName();

		/// get joint
		const Joint & GetJoint(uint id) const
		{
			PDE_ASSERT(id < joints.Size(), "joint id error!");
			return joints[id];
		}

	private:
		Core::Identifier		name;
		Core::Array<Joint>		joints;
		Core::HashSet<Core::Identifier, int> name_to_id;
		sharedc_ptr(Pose)		pose;	// T-pose
	};

	class SkeletonMap
	{
	public:
		enum BlendType
		{
			kNone,
			kNormal,	// not support yet
			kAddtive,
			kReplace,
		};

	public:
		/// constructor
		SkeletonMap(by_ptr(Skeleton) skeleton);

	public:
		/// add joint
		bool AddJoint(const Core::Identifier & name, bool skip_child = true, byte type = kReplace);

		/// add joint from to
		bool AddJointFromTo(const Core::Identifier & from, const Core::Identifier & to, byte type = kReplace);

		/// get map
		const Core::Array<byte> & GetMap() { return map; };

	private:
		Core::Array<byte>		map;
		sharedc_ptr(Skeleton)	skeleton;
	};

	class Animation;
	class AnimationTrack : public Core::Object
	{
		friend class Animation;
	public:
		struct JointData
		{
			Core::Identifier	name;
			uint				frame_count;
			Core::Array<float>	data;
		};

	public:
		/// constructor
		AnimationTrack()
			: frame_count(-1)
		{
		}

		/// load
		bool Load(const Core::Identifier & path);

		/// load 
		void Load(Core::Stream & stream);

		/// save
		void Save(Core::Stream & stream);

	public:
		/// get joint count
		uint GetJointCount();

		/// get joint id
		int GetJointId(const Core::Identifier & key);

		/// has joint
		bool HasJoint(const Core::Identifier & key);

		/// get position
		bool GetPosition(const Core::Identifier & key, uint frame, Core::Vector3 & pos);

		/// get position
		bool GetPosition(int id, uint frame, Core::Vector3 & pos);

		/// get position
		bool GetRotation(const Core::Identifier & key, uint frame, Core::Quaternion & rot);

		/// get position
		bool GetRotation(int id, uint frame, Core::Quaternion & rot);

		/// get transform
		bool GetTransform(const Core::Identifier & key, float time, Transform & transform);

		/// get transform
		bool GetTransform(int id, float time, Transform & transform);

		/// get frame count
		int GetFrameCount();

		/// get frame rate
		float GetFrameRate();

		/// get animation time
		float GetAnimationTime();

	private:
		Core::HashSet<Core::Identifier, int> joint_index;
		Core::Array<sharedc_ptr(JointData)> joint_array;

		int frame_count;
	};

	class Animation : public Resource
	{
	public:
		/// contructor
		Animation();

	public:
		/// load data
		virtual sharedc_ptr(Object) BuildData();

		/// load data
		virtual sharedc_ptr(Object) LoadData(Core::Stream & stream);

		/// load data
		virtual bool SaveData(Core::Stream & stream);

		/// unload data
		virtual void UnloadData();

		/// on load data
		virtual bool OnLoadData(by_ptr(Object) obj);

		/// get version
		virtual short GetVersion();

	public:
		/// rebuild
		void Rebuild(by_ptr(AnimationTrack) t, Core::Array<int> & bone_to_id);

		/// get animation track
		tempc_ptr(AnimationTrack) GetAnimationTrack() { return track; };

		/// sample track
		bool SampleTrack(float time, tempc_ptr(Skeleton) skeleton, Core::Array<Transform> & out, bool auto_circle = true);

		/// sample track
		bool SampleTrack(float time, Core::Array<int> & joints, Core::Array<Transform> & out, bool auto_circle = true);

		/// get animation time
		float GetAnimationTime();

		/// build animation joint map
		void BuildJointMap(by_ptr(Skeleton) skeleton, Core::Array<int> & joint_map);

	private:
		sharedc_ptr(AnimationTrack)	track;
	};

	class AnimationSetRes : public Resource
	{
		friend class AnimationSet;
		friend class AnimationManager;
	public:
		/// constructor
		AnimationSetRes();

	public:
		/// load data
		virtual sharedc_ptr(Object) BuildData();

		/// load data
		virtual sharedc_ptr(Object) LoadData(Core::Stream & stream);

		/// load data
		virtual bool SaveData(Core::Stream & stream);

		/// unload data
		virtual void UnloadData();

		/// on load data
		virtual bool OnLoadData(by_ptr(Object) obj);

		/// get version
		virtual short GetVersion();

	public:
		/// get animation
		tempc_ptr(Animation) GetAnimation(const Core::Identifier & key);

		/// get animation set
		tempc_ptr(AnimationSet) GetAnimationSet();

	private:
		sharedc_ptr(AnimationSet)	animation_set;
	};

	class AnimationSet : public Core::Object
	{
	public:
		friend class AnimationSetRes;
		typedef Core::IDelegate<void(*)(by_ptr(void), uint&)> EventHandler;
	public:
		/// constructor
		AnimationSet();

		/// destructor
		~AnimationSet();

	public:
		/// add animation
		void AddAnimation(const Core::Identifier & key, by_ptr(Animation) animation);

		// remove animation
		void RemoevAnimation(const Core::Identifier & key);

		/// get animation
		tempc_ptr(Animation) GetAnimation(const Core::Identifier & key);

		/// set animation
		void SetAnimation(const Core::Identifier & key, by_ptr(Animation) animation);

		/// on animation set res dirty
		void OnAnimationDirty(by_ptr(void) sender, uint & args);

		/// set animation set
		void SetAnimationSet(const Core::Identifier & key, by_ptr(AnimationSetRes) set);

		/// is ready
		bool IsReady();

		Core::Array<Core::Identifier> GetAnimationSetKeyList();

	private:
		Core::HashSet<Core::Identifier, sharedc_ptr(Animation)>	animation_set;
		Core::HashSet<Core::Identifier, sharedc_ptr(AnimationSetRes)> res_set;
		Core::HashSet<Core::Identifier, tempc_ptr(EventHandler)> handler_set;
	};

	class Pose : public Core::Object
	{
	public:
		/// constructor
		Pose(by_ptr(Skeleton) s);

	public:
		/// update model pose
		void UpdateModelPose(bool skip_lock_pose = false);

		/// initialize skeleton 
		void InitializeSkeleton();

	public:
		/// set local pose
		void SetLocalPose(const Core::Array<Transform> & transform);

		/// get skeleton
		tempc_ptr(Skeleton) GetSkeleton() { return skeleton; };

		/// set skeleton
		void SetSkeleton(by_ptr(Skeleton) s);

		/// copy local pose
		void CopyLocalPose(const Core::Array<Transform> & transforms);

		/// set local pose zero
		void SetLocalPoseZero();

		/// get joint count
		uint GetJointCount();

		/// get joint parent id
		int GetJointParentId(uint id);

		/// set joint local pose
		void SetJointLocalPose(uint id, const Transform & transform);

		/// set joint local pose position
		void SetJointLocalPosePosition(uint id, const Core::Vector3 & position);

		/// set joint local pose rotation
		void SetJointLocalPoseRotation(uint id, const Core::Quaternion & rotation);

		/// set joint model pose
		void SetJointModelPose(uint id, const Transform & transform, bool dirty = true);

		/// set joint model pose position
		void SetJointModelPosePosition(uint id, const Core::Vector3 & position, bool dirty = true);

		/// set joint model pose rotation
		void SetJointModelPoseRotation(uint id, const Core::Quaternion & rotation, bool dirty = true);

		/// set joint lock pose
		void SetJointLockPose(uint id, bool flag);

		/// get joint lock pose
		bool GetJointLockPose(uint id);

		/// get joint model pose
		const Transform & GetJointModelPose(uint id);

		/// get joint local pose
		const Transform & GetJointLocalPose(uint id);

		/// get local pose
		Core::Array<Transform> & GetLocalPose();

		/// get local pose
		const Core::Array<Transform> & GetLocalPoseConst();

		/// get model pose
		const Core::Array<Transform> & GetModelPose();

		/// blend
		void Blend(by_ptr(Pose) pose1, by_ptr(Pose) pose2, float weight);

	private:
		sharedc_ptr(Skeleton)	skeleton;
		Core::Array<Transform>	local_pose;
		Core::Array<bool>		lock_pose;
		Core::Array<Transform>	model_pose;
		bool	pose_dirty	: 1;
	};
}

namespace Client
{
	class AnimationNode
	{
	public:
		/// update
		virtual void Update(F32 time) = 0;

		/// get pose
		virtual tempc_ptr(Pose) GetPose() = 0;

		/// get addtive pose
		virtual tempc_ptr(Pose) GetAddtivePose() = 0;

		/// on active
		virtual void OnActive() = 0;

		/// on valid
		virtual void OnValid(bool valid) = 0;
	};

	interface AnimationNodeBase : public AnimationNode
	{
		/// get total time
		virtual float GetTotalTime() = 0;

		/// set time
		virtual void SetTime(float time) = 0;

		/// get time
		virtual float GetTime() = 0;

		/// get play rate
		virtual float GetPlayRate() = 0;

		/// set play rate
		virtual void SetPlayRate(float rate) = 0;

		/// get animation rate
		virtual float GetAnimationRate() = 0;

		/// set animation rate
		virtual void SetAnimationRate(float rate) = 0;

		/// set circle
		virtual void SetCircle(bool is_circle = true){};
	};

	class AnimationNodePose : public AnimationNodeBase
	{
	public:
		/// constructor
		AnimationNodePose(by_ptr(Skeleton) s);

		/// destructor
		virtual ~AnimationNodePose() {};

	public:
		/// update
		virtual void Update(F32 time);

		/// get pose
		virtual tempc_ptr(Pose) GetPose();

		/// get addtive pose
		virtual tempc_ptr(Pose) GetAddtivePose();

		/// on active
		virtual void OnActive();

		/// on valid
		virtual void OnValid(bool valid);

	public:
		/// set animation
		void SetAnimation(const Core::Identifier & key, by_ptr(AnimationSet) set);

		///set addtive base
		void SetAddtiveBase(const Core::Identifier & key);

		/// get total time
		virtual float GetTotalTime();

		/// set time
		virtual void SetTime(float time);

		/// get time
		virtual float GetTime();

		/// get play rate
		virtual float GetPlayRate();

		/// set play rate
		virtual void SetPlayRate(float rate);

		/// get animation rate
		virtual float GetAnimationRate();

		/// set animation rate
		virtual void SetAnimationRate(float rate);

		/// get animation key
		virtual const Core::Identifier & GetAnimationKey();

		/// set pose offset
		void SetPoseOffset(uint joint_id, const Transform & transform);

		/// set circle
		void SetCircle(bool is_circle = true);

	private:
		/// update pose offset
		void UpdatePoseOffset();

	private:
		sharedc_ptr(Pose)			pose;
		tempc_ptr(Skeleton)			skeleton;
		tempc_ptr(Animation)			animation;
		tempc_ptr(Animation)			animation_addtive;
		sharedc_ptr(Pose)			addtive_pose;
		sharedc_ptr(Pose)			addtive_base;
		Core::Identifier			animation_key;
		sharedc_ptr(AnimationSet)	animation_set;
		Core::Identifier			addtive_base_key;
		Core::HashSet<uint, Transform>	pose_offset;
		Core::Array<int>			joint_map;
		Core::Array<int>			joint_map_addtive;

	private:
		bool	pose_dirty;
		bool	addtive_pose_dirty;

	private:
		float	total_time;
		float	play_time;
		float	play_rate;

	public:
		bool	pause;
		bool	circle;
		float	start_time;
		float	end_time;
	};

	class AnimationNodeList : public AnimationNode
	{
	public:
		/// destructor
		virtual ~AnimationNodeList() {};

	public:
		/// update
		virtual void Update(F32 time);

		/// get addtive pose
		virtual tempc_ptr(Pose) GetAddtivePose();

		/// get pose
		virtual tempc_ptr(Pose) GetPose();

		/// on active
		virtual void OnActive();

		/// on valid
		virtual void OnValid(bool valid);
	public:
		/// add node
		bool AddNode(const Core::Identifier & key, by_ptr(AnimationNode) node);

		/// set active node
		void SetActiveNode(const Core::Identifier & key);

		tempc_ptr(AnimationNode) GetActiveNode() { return active_node; };

		const Core::String & GetActiveKey() { return active_key; };

	private:
		Core::HashSet<Core::Identifier, sharedc_ptr(AnimationNode)>	node_list;

		tempc_ptr(AnimationNode)	active_node;
		Core::String active_key;
	};

	class AnimationNodeRandom : public AnimationNode
	{
	public:
		/// constructor
		AnimationNodeRandom();

		/// destructor
		virtual ~AnimationNodeRandom() {};

	public:
		/// update
		virtual void Update(F32 time);

		/// get addtive pose
		virtual tempc_ptr(Pose) GetAddtivePose();

		/// get pose
		virtual tempc_ptr(Pose) GetPose();

		/// on active
		virtual void OnActive();

		/// on valid
		virtual void OnValid(bool valid);

		/// active node begin
		virtual bool ActiveNodeBegin();

	public:
		/// add node
		bool AddNode(by_ptr(AnimationNodePose) node, byte weight = 255, short replay_count = 1);

		tempc_ptr(AnimationNodePose) GetActiveNode() { return active_node; };

	private:
		Core::Array<sharedc_ptr(AnimationNodePose)>	node_list;
		Core::Array<int>	weight_list;
		tempc_ptr(AnimationNodePose) active_node;
		int	active_index;
		int replay_count;

		bool active_node_begin;
	};

	struct BlendInfo
	{
		/// construcor
		BlendInfo()
			: weight(1.f)
		{
		}

		float		weight;
		sharedc_ptr(SkeletonMap)	map;
		sharedc_ptr(AnimationNode)	node;
	};

	class AnimationNodeBlend : public AnimationNode
	{
	public:
		/// constructor
		AnimationNodeBlend(by_ptr(Skeleton) s);

		/// destructor
		virtual ~AnimationNodeBlend() {};

	public:
		/// update
		virtual void Update(F32 time);

		/// add node
		void AddNode(by_ptr(AnimationNode) node);

		/// add nod by info
		void AddNodeByInfo(by_ptr(BlendInfo) info);

		/// get addtive pose
		virtual tempc_ptr(Pose) GetAddtivePose();

		/// get tempc_ptr
		virtual tempc_ptr(Pose) GetPose();

		/// on active
		virtual void OnActive() {}

		/// on valid
		virtual void OnValid(bool valid);

		/// blend node
		void BlendNode();

	private:
		bool pose_dirty;
		Core::Array<sharedc_ptr(BlendInfo)>	nodes;
		sharedc_ptr(Pose)			pose;
		sharedc_ptr(Skeleton)		skeleton;
	};

	class AnimationNodeSync : public AnimationNode
	{
	public:
		AnimationNodeSync(by_ptr(Skeleton) s);

		/// destructor
		virtual ~AnimationNodeSync() {};

	public:
		/// update
		virtual void Update(float time);

		/// get addtive pose
		virtual tempc_ptr(Pose) GetAddtivePose();

		/// get pose
		virtual tempc_ptr(Pose) GetPose();

		/// on active
		virtual void OnActive();

		/// on valid
		virtual void OnValid(bool valid);
	public:
		/// add node
		virtual bool AddNode(const Core::Identifier & key, by_ptr(AnimationNodeBase));

		/// set active node
		void SetActiveNode(const Core::Identifier & key, bool is_circle = true);

		/// get active node
		tempc_ptr(AnimationNodeBase) GetActiveNode();

	private:
		Core::HashSet<const Core::Identifier, sharedc_ptr(AnimationNodeBase)>	node_list;

		tempc_ptr(AnimationNodeBase)	active_node;
		tempc_ptr(AnimationNodeBase)	sync_node;

		sharedc_ptr(Pose)	pose;

		float	sync_time;
		float	sync_total_time;
	};


	class AnimationNodeData : public AnimationNode
	{
	public:
		/// constructor
		AnimationNodeData(by_ptr(Skeleton) s);

		/// destructor
		virtual ~AnimationNodeData() {};

	public:
		/// update
		virtual void Update(F32 time);

		/// get addtive pose
		virtual tempc_ptr(Pose) GetAddtivePose();

		/// get pose
		virtual tempc_ptr(Pose) GetPose();

		/// on active
		virtual void OnActive();

		/// on valid
		virtual void OnValid(bool valid);

		// is blending
		bool IsBlending();

		// force blend
		void ForceBlend();

	public:
		///set source node
		void SetSourceNode(by_ptr(AnimationNode) node);

	private:
		sharedc_ptr(Pose)	pose;
		sharedc_ptr(Pose)	blend_pose;
		sharedc_ptr(Pose)	addtive_pose;
		sharedc_ptr(Pose)	addtive_blend_pose;
		sharedc_ptr(Pose)	addtive_source_pose;
		sharedc_ptr(Pose)	source_pose;
		sharedc_ptr(AnimationNode)		source_node;

		bool	pose_dirty;
		bool	addtive_pose_dirty;

		float	blend_time;

		bool	is_valid;

	public:
		float	blend_total_time;
	};

	class AnimationNodeOffset : public AnimationNode
	{
	public:
		/// constructor
		AnimationNodeOffset(by_ptr(Skeleton) s);

		/// destructor
		virtual ~AnimationNodeOffset() {};

	public:
		/// update
		virtual void Update(float frame_time);

		/// get addtive pose
		virtual tempc_ptr(Pose) GetAddtivePose();

		/// get pose
		virtual tempc_ptr(Pose) GetPose();

		/// on active
		virtual void OnActive();

		/// on valid
		virtual void OnValid(bool valid);
	public:
		/// set animation
		void SetAnimation(const Core::Identifier & key, by_ptr(AnimationSet) set);

	private:
		sharedc_ptr(Pose)			pose;
		sharedc_ptr(Pose)			pose_h;
		sharedc_ptr(Pose)			pose_v;
		sharedc_ptr(Skeleton)		skeleton;


		sharedc_ptr(Pose)			pose_center;
		sharedc_ptr(Pose)			pose_center_up_half;
		sharedc_ptr(Pose)			pose_center_up;
		sharedc_ptr(Pose)			pose_center_down_half;
		sharedc_ptr(Pose)			pose_center_down;
		sharedc_ptr(Pose)			pose_left;
		sharedc_ptr(Pose)			pose_left_up;
		sharedc_ptr(Pose)			pose_left_down;
		sharedc_ptr(Pose)			pose_right;
		sharedc_ptr(Pose)			pose_right_up;
		sharedc_ptr(Pose)			pose_right_down;

		bool						has_pose_center_up_half;
		bool						has_pose_center_down_half;

		sharedc_ptr(Pose)	addtive_pose;

		bool				pose_dirty;
		bool				addtive_pose_dirty;

		sharedc_ptr(AnimationSet)	animation_set;
		Core::Identifier			animation_key;
		tempc_ptr(Animation)			animation;

	public:
		float	angle_h;
		float	angle_h_left_max;
		float	angle_h_right_max;

		float	angle_v;
		float	angle_v_up_max;
		float	angle_v_down_max;

		float	angle_target_h;
		float	angle_target_v;
		float	angle_speed;
		Core::Vector2				direction;
	};

	class AnimationNodeDirection : public AnimationNodeBase
	{
	public:
		/// constructor
		AnimationNodeDirection(by_ptr(Skeleton) s);

		/// destructor
		virtual ~AnimationNodeDirection() {};

	public:
		/// update
		virtual void Update(float frame_time);

		/// get additive pose
		virtual tempc_ptr(Pose) GetAddtivePose();

		/// get pose
		virtual tempc_ptr(Pose) GetPose();

		/// on active
		virtual void OnActive();

		/// on valid
		virtual void OnValid(bool valid);

		/// get animation rate
		virtual float GetAnimationRate();

		/// set animation rate
		virtual void SetAnimationRate(float rate);

		/// set time
		virtual void SetTime(float time);

		/// get time
		virtual float GetTime(); 

		/// set play rate
		virtual void SetPlayRate(float rate);

		/// get play rate
		virtual float GetPlayRate();

		/// get total time
		virtual float GetTotalTime();

		/// set angle
		virtual void SetAngle(float a);

	private:
		tempc_ptr(Pose)		pose;
		sharedc_ptr(Pose)	pose_1;
		sharedc_ptr(Pose)	pose_2;
		tempc_ptr(Skeleton)	skeleton;

		sharedc_ptr(Pose)	addtive_pose;
		
		bool				pose_dirty;
		bool				addtive_pose_dirty;

		float	angle_speed;
		float	play_time;
		float	play_rate;
		float	angle;

	public:
		float	angle_target;

		sharedc_ptr(AnimationNodePose) animation_forward;
		sharedc_ptr(AnimationNodePose) animation_forward_left;
		sharedc_ptr(AnimationNodePose) animation_forward_right;
		sharedc_ptr(AnimationNodePose) animation_back_left;
		sharedc_ptr(AnimationNodePose) animation_back_right;
		sharedc_ptr(AnimationNodePose) animation_back;
		sharedc_ptr(AnimationNodePose) animation_left;
		sharedc_ptr(AnimationNodePose) animation_right;

	};

	class AnimationNodeCustom : public AnimationNode
	{
	public:
		/// constructor
		AnimationNodeCustom(by_ptr(Skeleton) s);

		/// destructor
		~AnimationNodeCustom() {};

	public:
		/// update
		virtual void Update(float time);

		/// get addtive pose
		virtual tempc_ptr(Pose) GetAddtivePose();

		/// get pose
		virtual tempc_ptr(Pose) GetPose();

		/// on active
		virtual void OnActive();

		/// on valid
		virtual void OnValid(bool valid);

	public:
		/// set animation set
		void SetAnimationSet(by_ptr(AnimationSet) set);

		/// set animation node
		void SetAnimationNode(by_ptr(AnimationNode) n);

		/// get animation node
		tempc_ptr(AnimationNode) GetAnimationNode();

		/// play action
		tempc_ptr(AnimationNodePose) PlayAction(const Core::Identifier & key, float blend_time, bool cycle = false, float play_time = 0, bool wait_stop = false);

		/// play action
		tempc_ptr(AnimationNodePose) PlayAction(const Core::Identifier & key, float blend_in_time, float blend_out_time, bool cycle = false, float play_time = 0, bool wait_stop = false);

		/// pause action
		void PauseAction(bool pause = true);

		/// stop action
		void StopAction(bool immediate = true);

		/// is action playing
		bool IsActionPlaying();

		/// force blend
		void ForceBlend();

	public:
		bool	action_cycle	: 1;
		bool	action_playing	: 1;
		bool	action_wait_stop: 1;
		float	blend_in_time;
		float	blend_out_time;
		float	blend_time_last;
		bool	blend_out;

		sharedc_ptr(Skeleton)			skeleton;
		sharedc_ptr(AnimationSet)		animation_set;
		sharedc_ptr(AnimationNodeData)	node_data;
		sharedc_ptr(AnimationNode)		node;
		sharedc_ptr(AnimationNodePose)	node_action;
		sharedc_ptr(AnimationNodePose)	node_action_last;

	};

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	class ChangeNodeEventBase
	{
	public:
		/// firstperson
		virtual void OnAnimationStartFPEvent(const Core::Identifier & groupname, int & index) ;		
		/// thirdperson
		virtual void OnAnimationStartTPEvent(const Core::Identifier & groupname, int & index) ;	

		/// firstperson
		virtual void OnAnimationEndFPEvent(const Core::Identifier & groupname, int & index) ;		
		/// thirdperson
		virtual void OnAnimationEndTPEvent(const Core::Identifier & groupname, int & index) ;	
	};

	class AnimationNodeGroup : public AnimationNode
	{
		/// attribute of animation
		struct NodeAttribute
		{
			Core::Identifier keyname;
			Core::Identifier addtivebase;
			float blend_time;
			bool loop;
			float play_time;
			bool waitstop;
		};

		/// one node execution call many animation or one animation
		struct GroupNode
		{
			Core::Identifier nodekey;
			int index;
			bool iscontinuity;
			Core::Array<sharedc_ptr(NodeAttribute)> array_attribute;
			int Size() { return array_attribute.Size(); }
		};

	public:
		/// constructor
		AnimationNodeGroup(by_ptr(Skeleton) s);

		/// destructor
		~AnimationNodeGroup() {};

	public:
		/// update
		virtual void Update(float frame_time);

		/// get addtive pose
		virtual tempc_ptr(Pose) GetAddtivePose();

		/// get pose
		virtual tempc_ptr(Pose) GetPose();

		/// on active
		virtual void OnActive();

		/// on valid
		virtual void OnValid(bool valid);
	public:
		/// add node
		sharedc_ptr(AnimationNodeGroup::GroupNode) AddNode(const Core::Identifier & nodekey,bool continuity = false);

		/// add attribute
		void AddNodeAttribute(tempc_ptr(GroupNode) node, const Core::Identifier & name,const Core::Identifier & addtivebase, float blend_time = 0, bool cycle = false, float play_time = 0, bool wait_stop = false);

		/// set animation set
		void SetAnimationSet(by_ptr(AnimationSet) set);

		/// set animation node
		void SetAnimationNode(by_ptr(AnimationNode) n);

		/// get animation node
		tempc_ptr(AnimationNode) GetAnimationNode();

		/// play action
		tempc_ptr(AnimationNodePose) PlayAction(const Core::Identifier & nodekey, const Core::Identifier & nodename, float playtime = 0.f);

		/// pause action
		void PauseAction(bool pause = true);

		/// stop action
		void StopAction(bool immediate = true);

		/// is action playing
		bool IsActionPlaying();

		/// force blend
		void ForceBlend();
	
		/// register event
		void RegisterEvent(by_ptr(ChangeNodeEventBase) event);

		/// set person
		void SetFirstPerson();
		void SetThirdPerson();

		/// load by lua
		void LoadGroupNode(const Core::Identifier & nodekey);

		/// is group loop
		bool IsGroupLoop(const Core::Identifier & nodekey);

		/// is now node
		bool IsNowNode(const Core::Identifier & nodekey);

		
	private:
		/// find index
		int FindIndexFromKey(const Core::Identifier & key, bool isnode);

	private:
		Core::Array<sharedc_ptr(GroupNode)> array_node;
		int groupnodeindex;
		sharedc_ptr(GroupNode) now_node;
		float time;
		bool showend;
		/// if animation have been change, call function
		sharedc_ptr(ChangeNodeEventBase) nodeevent;
		bool isfirstperson;

	public:
		sharedc_ptr(Skeleton)			skeleton;
		sharedc_ptr(AnimationNodeCustom)	node_action;	

		float Anim_Play_Totaltime;
		float Anim_Play_time;
	};
}