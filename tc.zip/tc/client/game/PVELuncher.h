namespace Client
{
	struct PVELuncherInfo : public PVEWeaponInfo
	{
		float fly_speed;

		sharedc_ptr(PVEAmmoInfo) ammo_info;

		PVELuncherInfo()
			: fly_speed(0)
		{
			weapon_type = kPVEWeaponTypeLuncher;
		}
	};

	class PVELuncher : public PVEWeaponBase
	{
	public:
		PVELuncher();

		~PVELuncher();

	public:
		bool Initialize(const Core::String &name, by_ptr(Character) c, by_ptr(PVEWeaponInfo) info);

		void Update(float time);

		void Fire(const Core::Vector3 &fire_pos, const Core::Quaternion &fire_rot, int index, by_ptr(Character) target);

		void Fire(const Core::Vector3 &fire_pos, const Core::Vector3 &target);

		void Fire(const Core::Vector3 &fire_pos, by_ptr(Character) target);

		void Reset();

		PVEWeaponType GetWeaponType();

	private:
		sharedc_ptr(PVEAmmo) m_PreloadAmmo;
	};
}