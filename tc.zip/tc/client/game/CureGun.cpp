#include "pch.h"

using namespace Core;
using namespace Client;

DEFINE_PDE_TYPE_CLASS(Client::CureGunInfo)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Client::GunInfo);

		//ADD_PDE_FIELD(maxdistance);
		//ADD_PDE_FIELD(addblood);

		ADD_PDE_DEFAULT_CONSTRUCTOR();
	}
};

DEFINE_PDE_TYPE_CLASS(Client::CureGun)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Client::GunBase);

		ADD_PDE_PROPERTY_R(weapon_info);
	}
};

REGISTER_PDE_TYPE(Client::CureGunInfo);
REGISTER_PDE_TYPE(Client::CureGun);

namespace Client
{
	/// constrcutor
	CureGun::CureGun(by_ptr(CureGunInfo) info)
		:cure_uid(0)
		,last_cure_uid(0)
		,firestate(0)
		,canfire_for_ani(false)
		,can_Special(false)
	{
		has_trajectory = true;
		weapon_info = gun_info = CureGun_info = info;
		skill = ptr_new(PlayerSkill);
		skill->type = kSkillCureGun;
		skill->effect_time = 5.f;
		my_audio_event = NULL;
	}

	CureGun::~CureGun()
	{
		if (my_audio_event)
			my_audio_event->stop();
	}

	/// random float
	static float RandomFloat(F32 x, F32 y)
	{
		float r = (F32)rand() / (RAND_MAX + 1);
		float num = x + (y - x) * r;
		return num; 
	}

	/// get weapon type
	uint CureGun::GetWeaponType()
	{
		return kWeaponTypeCureGun;
	}

	bool CureGun::CanActive()
	{
		return GunBase::CanActive();
	}

	/// active
	void CureGun::Active()
	{
		GunBase::Active();
	}

	/// inactive
	void CureGun::Inactive()
	{
		GunBase::Inactive();

		if (my_audio_event)
			my_audio_event->stop();
		gGame->channel_connection->PlayerAnimationEnd(GetWeaponType());
		firestate = 0;
		StopFireEffect();
	}

	/// udpate effect
	void CureGun::UpdateEffect(float time)
	{
		GunBase::UpdateEffect(time);

		if (firestate == 0 && is_for_player)
		{
			StopFireEffect();
		}
	}

	//update
	void CureGun::Update(float frame_time)
	{
		if(gGame->channel_connection->GetState() != ChannelConnection::kInReplay)
		{
			WeaponBase::Update(frame_time);

			tempc_ptr(Character) player = GetOwner();

			if (!player)
				return;

			if (!gun_info)
				return;

			last_fire_time += frame_time;

			if (player->first_action_on)
			{
				//ǹ������Ŀ��
				tempc_ptr(Character) cure_player = gLevel->GetCharacter(cure_uid);
				if(cure_player && canfire_for_ani)
				{
					Core::Vector3 fire_pos = Core::Vector3::kZero;
					tempc_ptr(GunBase) gun = ptr_dynamic_cast<GunBase>(player->GetWeapon(false));

					if (gun)
					{
						gun->GetJointInfo("Gun_Fire", &fire_pos, NULL);
					}
					gun_fire_particle->SetRotation(player->GetSkeletonRotation());
					gun_fire_particle->SetPosition(fire_pos);

				}

				if (next_fire_time <= 0)
				{
					if (player->CanFire())
					{
						if(!player->keep_Shoot_fp && FireCheck())
						{
							const FirstPerson & first_person = player->GetFirstPerson();
							if(first_person.animation_group)
							{
								player->keep_Shoot_fp = true;
								first_person.animation_group->PlayAction("laser_shoot","shootone");
								firestate = 1;
							}
						}	
						if (canfire_for_ani)
						{
							if (Fire())
							{
								;
							}
							else
							{
								last_cure_uid = cure_uid; cure_uid = 0;

								const FirstPerson & first_person = player->GetFirstPerson();

								if (player->keep_Shoot_fp)
								{
									firestate = 0;
									if (first_person.animation_group)
										first_person.animation_group->StopAction();
									gGame->channel_connection->PlayerAnimationEnd(GetWeaponType());
									player->StopShoot();
									StopFireEffect();
								}
								player->keep_Shoot_fp = false;
								next_fire_time = 0;

								if (my_audio_event)
									my_audio_event->stop();
							}
						}
					}
				}
				else if (next_fire_time > 0)
				{
					next_fire_time -= frame_time;
				}
			}
			else
			{
				last_cure_uid = cure_uid; cure_uid = 0;

				const FirstPerson & first_person = player->GetFirstPerson();
				if (player->keep_Shoot_fp)
				{
					firestate = 0;
					if (first_person.animation_group)
						first_person.animation_group->StopAction();
					gGame->channel_connection->PlayerAnimationEnd(GetWeaponType());
					player->StopShoot();
					StopFireEffect();
				}

				player->keep_Shoot_fp = false;
				next_fire_time = 0;

				if (my_audio_event)
					my_audio_event->stop();
			}

			UpdateEffect(frame_time);
		}
		else
		{
			UpdateViewerAnimation(frame_time);
		}
	}

	/// initialize
	void CureGun::Initialize()
	{
		GunBase::Initialize();
		CStrBuf<256> key;
		key.format("bj/weapon/2d/%s/fire", weapon_info->sound_name.Str());
		my_audio_event =FmodSystem::GetEvent(key);
		static const char szTeam[2] = {'r', 'b'};
		tempc_ptr(Character) player = GetOwner();
		if (player)
		{
			CStrBuf<256> key;
			key.format("%s_%s_%c", gun_info->fire_particle.Str(), is_for_player ? "1st" : "3rd", szTeam[player->GetTeam() & 1]);
			gun_fire_particle = ptr_new ParticleSystem(key);
			gun_fire_particle->SetFirstPersonMode(is_for_player);
		}
	}

	bool CureGun::FireCheck()
	{
		tempc_ptr(Character) player = GetOwner();
		if (!player || !CureGun_info)
			return false;

		tempc_ptr(Character) cure_player = gLevel->GetCharacter(cure_uid);
		if (cure_player && cure_player->GetTeam() == player->GetTeam())
		{
			Vector3 target_pos = cure_player->GetPosition()+Vector3(0,1.0f,0);
			Vector3 fire_pos = Vector3::kZero;
			tempc_ptr(GunBase) gun = ptr_dynamic_cast<GunBase>(player->GetWeapon(false));
			if (gun)
				gun->GetJointInfo("Gun_Fire", &fire_pos, NULL);

			Core::Vector3 dir = target_pos - fire_pos;
			NxRay ray;
			ray.orig = (const NxVec3 &)fire_pos;
			ray.dir = (const NxVec3 &)Normalize(dir);

			NxRaycastHit hit;
			uint group_id = 0;
			group_id |= 1 << PhysxSystem::kStatic;
			group_id |= 1 << PhysxSystem::kStaticRaycast;
			group_id |= 1 << PhysxSystem::kGroupVehicle;
			NxShape* shape = gPhysxScene->raycastClosestShape(ray, NX_ALL_SHAPES, hit, group_id, Core::Length(target_pos - fire_pos) / 2);
			if (shape)
			{
				if (my_audio_event)
					my_audio_event->stop();
				return false;
			}
			return true;
		}
		else
		{
			//�����µ�
			Vector3 fire_angle = player->GetLookDir().GetZXY();

			Quaternion rot;
			rot.SetZXY(fire_angle);

			float distance = CureGun_info->maxdistance;
			Vector3 pos = player->GetCameraPosition();
			Vector3 dir = Vector3(0, 0, -1) * rot;
			dir.Normalize();

			NxRaycastHit hit;
			uint group_id = 0;
			group_id |= 1 << (PhysxSystem::kGroupStart + player->GetTeam());
			group_id |= 1 << PhysxSystem::kStaticCollisionWithGateTeam1;
			group_id |= 1 << PhysxSystem::kStaticCollisionWithGateTeam2;
			
			NxRay ray;
			ray.orig = (const NxVec3 &)pos;
			ray.dir = (const NxVec3 &)dir;

			NxShape* shape = gPhysxScene->raycastClosestShape(ray, NX_ALL_SHAPES, hit, group_id, distance);

			if (shape)
			{
				NxActor& actor = shape->getActor();
				tempc_ptr(Character) p = Character::FromNxActor(actor);

				if(p)
				{
					if (!p->IsDied() && p != player && !p->zombie_dying_flag)
					{
						tempc_ptr(Character) find_player = gLevel->GetCharacter(p->uid);
						if (find_player)
						{
							Vector3 find_pos = find_player->GetPosition()+Vector3(0,1.0f,0);
							Vector3 fire_pos = Vector3::kZero;
							tempc_ptr(GunBase) gun = ptr_dynamic_cast<GunBase>(player->GetWeapon(false));
							if (gun)
								gun->GetJointInfo("Gun_Fire", &fire_pos, NULL);

							Core::Vector3 dir = find_pos - fire_pos;
							NxRay ray;
							ray.orig = (const NxVec3 &)fire_pos;
							ray.dir = (const NxVec3 &)Normalize(dir);

							NxRaycastHit hit;
							uint group_id = 0;
							group_id |= 1 << PhysxSystem::kStatic;
							group_id |= 1 << PhysxSystem::kStaticRaycast;
							group_id |= 1 << PhysxSystem::kGroupVehicle;
							NxShape* shape = gPhysxScene->raycastClosestShape(ray, NX_ALL_SHAPES, hit, group_id, Core::Length(find_pos - fire_pos) / 2);
							if (shape)
							{
								cure_uid = 0;
								if (my_audio_event)
									my_audio_event->stop();
								return false;
							}
							cure_uid = p->uid;
							return true;
						}
						else
							return false;
	
					}
				}
			}
			/*while (distance > 0.0f)
			{
				NxRay ray;
				ray.orig = (const NxVec3 &)pos;
				ray.dir = (const NxVec3 &)dir;

				NxShape* shape = gPhysxScene->raycastClosestShape(ray, NX_ALL_SHAPES, hit, group_id, distance);
				if (shape)
				{
					NxActor& actor = shape->getActor();
					tempc_ptr(Character) p = Character::FromNxActor(actor);

					if(p)
					{
						if (!p->IsDied() && p != player)
						{
							cure_uid = p->uid;
							return true;
						}
					}
					else
					{
						break;
					}

					distance -= hit.distance;
					pos = (const Vector3 &)hit.worldImpact + dir * 0.01f;
				}
				else
				{
					break;
				}
			}*/
#if 0
			//����ϴ���������
			cure_player = gLevel->GetCharacter(last_cure_uid);
			if (cure_player && cure_player->playing && !cure_player->IsDied() && 
				Length(player->GetPosition() - cure_player->GetPosition()) <= CureGun_info->maxdistance)
			{
				cure_uid = last_cure_uid;
				DoCure();

				return true;
			}
#endif
			//û�ҵ�
			cure_uid = 0;
			if (my_audio_event)
				my_audio_event->stop();
			return false;
		}
	}

	/// fire
	bool CureGun::Fire()
	{
		tempc_ptr(Character) player = GetOwner();
		if (!player || !CureGun_info)
			return false;

		if (!FireBase(0))
		{
			if (my_audio_event)
				my_audio_event->stop();
			return false;
		}

		next_fire_time = CureGun_info->fire_time;
		return FireCheck();
	}

	bool CureGun::FireBase(float spread)
	{
		tempc_ptr(Character) player = GetOwner();
		if (!player || !CureGun_info || !gPhysxScene)
			return false;

		tempc_ptr(Character) cure_player = gLevel->GetCharacter(cure_uid);
		if (cure_player && cure_player->playing && !cure_player->IsDied() && !cure_player->zombie_dying_flag && 
			Length(player->GetPosition() - cure_player->GetPosition()) <= CureGun_info->maxdistance)
		{
			DoCure();
			return true;
		}
		return false;
	}

	void CureGun::SpecialAbilities(bool keydown)
	{
		if(!keydown)
			return;

		tempc_ptr(Character) player = GetOwner();
		if(player)
		{
			if(power >= 100)
			{	
				power = 0;
				skill->uid = 0;
				gGame->channel_connection->UseSkill(skill);
				FmodSystem::PlayEvent("bj/fx/2d/invincible");
				//FMOD::Event* audio_event = NULL;
				//CStrBuf<256> key;
				//key.format("OTO2/weapon_2d/%s/energy_charged", weapon_info->sound_name.Str());
				//audio_event = gGame->fmod->GetEvent(key);
				//if (audio_event)
				//	audio_event->start();
			}
		}
	}

	void CureGun::StopFireEffect()
	{
		canfire_for_ani = false;
		if (gun_fire_particle)
		{
			gLevel->RemoveParticle(gun_fire_particle);
			gun_fire_particle->SetDead();
			gun_fire_particle->Reset();
		}
	}

	void CureGun::DoCure()
	{
		tempc_ptr(Character) player = GetOwner();

		gGame->channel_connection->CureCharacter(cure_uid);
		gGame->channel_connection->PlayerAnimationStart(GetWeaponType());
		player->Shoot(player->GetLookDir().GetZXY(),true);
	}

	void CureGun::OnAnimationStartFPEvent(const Core::Identifier & groupname, int & index)
	{
		Core::String str = groupname;
		if (str == "laser_shoot")
		{
			switch (index)
			{
			case 0:
				{
					if(my_audio_event)
						my_audio_event->start();
				}
				break;
			case 1:
				{
					canfire_for_ani = true;
					gLevel->AddParticle(gun_fire_particle);
				}
				break;
			case 2:
				{
					CStrBuf<256> key;
					key.format("bj/weapon/2d/%s/no_target", weapon_info->sound_name.Str());
					FmodSystem::PlayEvent(key);
				}
				break;
			default:
				break;
			}
		}
	}

	void CureGun::OnAnimationEndFPEvent(const Core::Identifier & groupname, int & index)
	{

	}

	void CureGun::OnAnimationStartTPEvent(const Core::Identifier & groupname, int & index)
	{

	}

	void CureGun::OnAnimationEndTPEvent(const Core::Identifier & groupname, int & index)
	{

	}
		
	///////////////////////////////////////////////////////////////
	void CureGun::UpdateViewerAnimation( float time )
	{
		tempc_ptr(Character) player = GetOwner();

		if (!player)
			return;

		if (!gun_info)
			return;

		if (player->keep_Shoot && firestate == 0)
		{
			firestate = 1;
			const FirstPerson & first_person = player->GetFirstPerson();
			player->keep_Shoot = true;
			if(first_person.animation_group)
			{
				first_person.animation_group->PlayAction("laser_shoot","shootone");
				gLevel->AddParticle(gun_fire_particle);
			}
		}
		else if (player->keep_Shoot && firestate == 1)
		{
		}
		else
		{
			firestate = 0;
			const FirstPerson & first_person = player->GetFirstPerson();
			if (first_person.animation_group)
				first_person.animation_group->StopAction();

			if (my_audio_event)
				my_audio_event->stop();
		}
	}
}
