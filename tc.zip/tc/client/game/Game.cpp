#include "pch.h"

#include <curl/curl.h>
#pragma comment(lib, "wldap32.lib" )

using namespace Core;
using namespace Client;

namespace Client
{
	Game* gGame = NULL;
}

static void ExitProgram(by_ptr(void) sender, Core::EventArgs & args)
{
	Thread::Quit();
}

static void InputHandler(by_ptr(void) sender, Client::InputEventArgs & args)
{
	if (gGame)
		gGame->OnInput(args);
}

static int lua_errorhandler(Lua::LuaState *L)
{
	const char * error_message = L->ToString(-1);
	if (error_message)
	{
		if (gGame)
			gGame->ReportError(error_message);

		Console.WriteLine(error_message);
	}

	return 1;
}

static void* LangChangedCallBack(void *p)
{
	if (gGame)
	{
		for (tempc_ptr(Gui::Control) control = gGame->guiSys; control; control = control->GetNext())
		{
			control->OnLanguageChanged(EventArgs());
		}
	}

	return NULL;
}

struct UpdateTask : public Core::Task
{
	void OnDispatch(IArguments & args)
	{
		gGame->OnUpdate();
		gGame->OnRender();

		// gc every frame
		Lua::LuaState::FromThread()->GC(Lua::GCSTEP, 64);

		if (Thread::Running())
		{
			// do this task again
			Task::Schedule(NullPtr);
		}
	}
};

extern const char * client_version;
extern const char * client_language;

Game::Game()
	: version("Unknown")
	, notify_error(true)
	, fcm_flag(0)
	, bSavePhoto(false)
	, need_leave_channel(false)
	, need_leave_roomlist(false)
	, account_type(0)
{
	IsInitApex = false;
	fps_flag = false;
	fps_limit = 30.0;
	round_time = 0;
	m_second = 1.f;
	net_bytes_send = 0;
	net_bytes_received = 0;

	font_size_off = 0;

	is_first_time_connect = true;

#ifdef MASTER
	use_luncher = true;
#else
	use_luncher = false;
#endif

	if (IsDebuggerPresent() || 
		strcmp(client_version, "Unknown") == 0)
		notify_error = true;

#if DEBUG_TOOLS
	bdebugSceneState = false;
#endif
}

void Game::ReportError(const Core::String & msg)
{
#if DEBUG_INFO
 	if (notify_error)
 	{
 		if (error_display.Empty())
 		{
 			error_display_time = 10;
 		}
 
 		error_display.PushBack(msg);
 	}
#endif
}

void Game::ClearReportError()
{
#if DEBUG_INFO
 	error_display.Clear();
#endif
}

void Game::OnCreate()
{
	Object::OnCreate();

	gGame = this;

	//lang
	langs = ptr_new Languages;
	langs->SetLangChangedCB(&LangChangedCallBack);

	//description
	description = ptr_new Description;
	description->LoadDescription();

	// config 
	config = ptr_new GameConfig;
	global = ptr_new GameGlobal;
	
	global->SetGameRate(1.0f);
	global->SetGameStop(false);

	Lua::LuaState *L = Lua::LuaState::FromThread();

	L->SetErrorHandler(&lua_errorhandler);

	L->PushPtr(langs);
	L->SetGlobal("lang");
	L->PushPtr(description);
	L->SetGlobal("description");
	L->PushPtr(config);
	L->SetGlobal("config");
	L->PushPtr(global);
	L->SetGlobal("game");

	// version info
	{
		FileStream fs;

		char buf[256];
		gethostname(buf, 256);
		CStrBuf<256> name;
		name.format("%s", buf);
		GetModuleFileNameA(NULL, buf, 256);
		Path::ContractPath(name, buf, "version");

		if (fs.Open(name.buff(), FileStream::kReadOnly))
		{
			TextStreamReader(fs).ReadString(version, '\n');
			fs.Close();
		}

		if (fs.Open("language", FileStream::kReadOnly))
		{                                                                                 
			TextStreamReader(fs).ReadString(language, '\n');
			fs.Close();
		}

		if (fs.Open("build.log", FileStream::kReadOnly))
		{
			TextStreamReader(fs).ReadString(buildlog, '\0');
			fs.Close();
		}
	}
#ifdef MASTER
	// check client and data version
	if (strcmp(client_version, version.Str()))
	{
		Core::ThrowErrorString("Version Error��");
	}
#endif

	if(language == "")
	{
		Core::ThrowErrorString("Need Language File��");
	}


	
	// create screen
	screen = ptr_new Screen;

	if (config->GetFullScreen())
		screen->SetShowCaption(false);

	screen->CenterToParent();
	screen->SetText("Final Combat");
	//screen->SetText(gLang->GetTextW(L"����"));
#ifdef MASTER
	screen->SetShowMaximizeBox(true);
	screen->SetShowMinimizeBox(true);
	screen->SetShowControlBox(true);
	screen->SetGrayClose(false);
#else
	screen->SetShowMaximizeBox(true);
	screen->SetShowMinimizeBox(true);
	screen->SetGrayClose(false);
#endif
	screen->SetSizeable(false);
	screen->UpdateStyle();
	
	screen->SetVisible(true);
	screen->SetSize(Vector2(1024, 768));
	screen->EventClose.Subscribe(NewDelegate(&ExitProgram));
	screen->EventInput.Subscribe(NewDelegate(&InputHandler));

	

	langs->SetCurLanguage(gGame->config->GetUserLanguage());

	gGame->config->LoadGraphic();
	gGame->config->LoadMouse();
	gGame->config->LoadKeys();
	gGame->config->LoadVersion();
	gGame->config->LoadQuickSetting();
	gGame->config->LoadGameing();

	ImeUi_Initialize(screen->GetHWND());

	// create directx
	dx9 = ptr_new DirectX9;
	if (!dx9->Initialize())
		return;

	// create input
	input = ptr_new Input;

	// create camera
	camera = ptr_new Camera;

	// create scoreboard
	scores = ptr_new ScoreBoard;

	// create physx
	PhysxSystem::Initialize();

	// level load
	level = ptr_new Level;

	// craete fmod
	FmodSystem::Initialize();

	FmodSystem::LoadProject("bj.fev");
	//FMOD::EventCategory* category = FmodSystem::GetCategory("sound");
	//if (category)
	//{
	//	float v = Clamp(50 / 100.f, 0.f, 1.f);
	//	category->setVolume(v);
	//}
	//category = FmodSystem::GetCategory("music");
	//if (category)
	//{
	//	float v = Clamp(50 / 100.f, 0.f, 1.f);
	//	category->setVolume(v);
	//}
	//category = FmodSystem::GetCategory("radio");
	//if (category)
	//{
	//	float v = Clamp(50 / 100.f, 0.f, 1.f);
	//	category->setVolume(v);
	//}
	config->LoadAudio();
#ifdef USE_WEB
	// web
	WebPlayer::Initialize();
#endif
	render = ptr_new D3DRender();

#if DEBUG_INFO
	debug_render = ptr_new DebugRender;
#endif

#if DEBUG_PROFILER
	CProfileManager::InitProfileHead();
#endif
	// Gui System
	guiSys = ptr_new Gui::GuiSystem;

	L->PushPtr(guiSys);
	L->SetGlobal("gui");

#ifndef MASTER
	// console
	console = ptr_new Gui::ConsoleUI;
	guiSys->SetFocusedControl(console);

	L->PushPtr(console);
	L->SetGlobal("console");
#endif

	screen->SetActive(true);

	//checkhook_thread = Thread::CreateThread(0, &CheckHookThreadEntry, NULL);

	// create frame update task.
	Task::Post(ptr_new UpdateTask);
}

void Game::OnDestroy()
{
	//if (checkhook_thread)
	//{
	//	Thread::Quit(checkhook_thread);
	//	Thread::WaitThreadExit(checkhook_thread);
	//}

#if ACTIVE_APEX
	Apex::StopApexClient();
#endif

	ImeUi_Uninitialize();

	//pipeline = NullPtr;
	//lobby_pipeline = NullPtr;

	render = NullPtr;
	guiSys = NullPtr;

	scores = NullPtr;

	if (channel_connection)
		channel_connection = NullPtr;

	if (level)
		level->Unload();

	level = NullPtr;

	Lua::LuaState::FromThread()->GC(Lua::GCCOLLECT, 0);

	PhysxSystem::Terminate();

	FmodSystem::Terminate();
#ifdef USE_WEB
	// shut down web
	WebPlayer::Terminate();
#endif
	gGame = NULL;

	// curl
	curl_global_cleanup();

	Object::OnDestroy();

#ifdef MASTER
	if(gStartConfig.ads_on)
	{
		ShellExecuteA(NULL, "open", "explorer.exe", gHttpConfig.http_paydraw, NULL, SW_SHOW);
	}

	if(gStartConfig.xl_exe_open)
	{
		char buff[MAX_PATH];
		char buff1[MAX_PATH];
		GetCurrentDirectoryA(sizeof(buff), buff);
		sprintf_s(buff1, MAX_PATH, "%s\\Defend.exe", buff);

		ShellExecuteA(NULL, "open",buff1, NULL, buff, SW_SHOW);

	}
#endif
}

void Game::OnInput(InputEventArgs & args)
{
#ifndef MASTER
	// hack for console
	if (args.Code == KC_GRAVE || args.Value == '`')
	{
		if (args.Type == InputEventArgs::kKeyDown && args.Code == KC_GRAVE)
		{
			if (console)
			{
				if (console->GetParent())
				{
					console->SetParent(NullPtr);
				}
				else
				{
					console->SetParent(guiSys);
					guiSys->SetFocusedControl(console);
				}
			}
		}

		return;
	}
#endif

	gGame->machine.OnInput(args);

	if (!args.Handled)
	{
		//gLevel->isselectperson for KC_M
		if (guiSys && !gLevel->isselectperson)
			guiSys->OnScreenInput(args);
	}
}

void Game::OnTimeStepUpdate(float frame_time)
{
	// update input
	input->Update(frame_time);

	// receive messages
	if (lobby_connection)
		lobby_connection->OnUpdate();

	if (channel_connection)
		channel_connection->OnUpdate(frame_time);

	PhysxSystem::Update(frame_time);
	machine.TimeStepUpdate(frame_time);
	//PhysxSystem::Update(frame_time);
	
	// send messages
	if (lobby_connection)
		lobby_connection->SendMessages();

	if (channel_connection)
		channel_connection->SendMessages();

	// release connection
	{
		bool disconnected = false;
		sharedc_ptr(LobbyConnection) conn1 = lobby_connection;
		sharedc_ptr(ChannelConnection) conn2 = channel_connection;

		if (conn1 && conn1->IsIdle())
		{
			disconnected = true;
			lobby_connection = NullPtr;
		}

		if (conn2 && conn2->IsIdle())
		{
			disconnected = true;
			channel_connection = NullPtr;
		}

		if (disconnected)
		{
			machine.OnDisconnect();
		}
	}
}

HRESULT Game::TakePicture()
{
	char time_buf[MAX_PATH] = {0};
	char path[MAX_PATH] = {0};
	char file_name[MAX_PATH] = {0};

	time_t ltime;
	time( &ltime );
	struct tm today = { 0, 0, 12, 25, 11, 93 };
	_localtime64_s( &today, &ltime );
	strftime(time_buf, MAX_PATH, "%Y-%m-%d-%H-%M-%S", &today);

	GetCurrentDirectoryA(sizeof(path), path);
	sprintf_s(file_name,"%s\\pictures\\%s.jpg",path, time_buf);

	HRESULT hr = D3DXSaveSurfaceToFileA(file_name, D3DXIFF_JPG, dx9->render_target, NULL, NULL);
	bSavePhoto = false;
	return hr;
}

void Game::OnUpdate()
{
	PROFILE("Game::OnUpdate");

#if ACTIVE_APEX
	Apex::UpdateApex_UserData();
#endif

	float frameTime = Task::GetFrameTime();
	float game_rate = 1.f;
	if (global)
	{
		game_rate = global->GetGameRate();
	}
	
	if(global->GetGameStop())
	{
		game_rate = 0.f;
	}

	
	frameTime *= game_rate;
	// update resource
	Resource::Update(frameTime);

	//machine.Update(frameTime);

	// time step update
	static float time_remain = 0;
	time_remain += frameTime;

	switch (config->GetTimeStepType())
	{
	case GameConfig::kTimeStepTypeFixed:
		{
			int iter = Max(1, config->GetTimeStepIter());
			float time_step_max = config->GetTimeStepMax();
			while (time_remain >= time_step_max && iter)
			{
				OnTimeStepUpdate(time_step_max);
				time_remain -= time_step_max;
				iter--;
			}
		}
		break;

	case GameConfig::kTimeStepTypeVariable:
		{
			OnTimeStepUpdate(time_remain);
			time_remain = 0;
		}
		break;
	}
	
	guiSys->Update();

	machine.Update(frameTime);

	// audio update
	FmodSystem::Update();

#if DEBUG_INFO
	// update error display
	if (!error_display.Empty())
	{
		error_display_time -= frameTime;

		if (error_display_time < 0)
		{
			error_display_time = 10;
			error_display.PopFront();
		}
	}
#endif
#ifdef _DEBUG
	//if (gGame->input->IsKeyPressed(KC_N) && gGame->input->IsKeyDown(KC_LCONTROL))
	//{

	//	m_WebBrowserVisible = !m_WebBrowserVisible;
	//	
	//	if(m_WebBrowserVisible)
	//	{
	//		InitializeWebBrowser();
	//		//m_WebBrowser->SetWindowShow(m_WebBrowserVisible);
	//	}
	//	else
	//	{
	//		//m_WebBrowser->SetWindowShow(m_WebBrowserVisible);
	//		FinalizeWebBrowser();
	//	}
	//	

	//}
#endif

	//if(dx9->IsDeviceLost()&&m_WebBrowser)
	//{
	//	FinalizeWebBrowser();
	//}
	//else if(!m_WebBrowser && !dx9->IsDeviceLost())
	//{
	//	InitializeWebBrowser();
	//}
	if (m_second > 0)
	{
		m_second -= frameTime;
		if (m_second < 0)
		{
			m_second = 0.0f;
		}
	}
}

void Game::OnRender()
{
	UIRender * ui_render = gRender->ui_render;
	{
		if (FAILED(gDx9Device->BeginScene()))
		{
			gDx9Device->Present(NULL, NULL, NULL, NULL);
			return;
		}
		gDx9Device->SetRenderTarget(0, dx9->render_target);
		gDx9Device->SetDepthStencilSurface(dx9->depth_stencil);
		gDx9Device->Clear(0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, 0, 1.f, 0);
	}

	// state render function.
	machine.Render();
	
	// render gui
	guiSys->Render(gRender->ui_render);

	// render 2d ui
	if (gRender->ui_render->BeginDraw(dx9->render_target, NULL))
	{
		tempc_ptr(UIRender) ui_render = render->ui_render;

		ImeUi_RenderUI(render->ui_render);

#if DEBUG_INFO
		Core::Rectangle scissor_rect = render->ui_render->GetScissorRect();

		// update error display
		if (!error_display.Empty())
		{
			Core::Rectangle rect(20, 20, 0, 0);

			ui_render->SetDefaultView();

			for (uint i = 0; i < error_display.Size(); i ++)
			{
				Core::String & error_message = error_display[i];
				Core::Rectangle size = ui_render->font_simhei_12->MeasureString(rect, error_message);

				ui_render->DrawString(ui_render->font_simhei_12, XRGB(255, 0, 0), XRGB(0, 0, 0), rect, error_message, Unit::kAlignLeftTop);

				rect.Min.y += size.GetExtent().y + 10;

				if (rect.Min.y > ui_render->GetVirtualViewport().GetExtent().y)
					break;
			}
		}

		static ARGB font_color = ARGB(255, 241, 211);
		static ARGB bg_color = ARGB(0, 0, 0, 0);

		if (render->render_pipeline->m_ShowDebugInfo)
		{
			ui_render->SetDefaultView();

			Core::CStrBuf<256> buff;

			F32 convergence = 0;
			NvAPI_Status status = NvAPI_Stereo_GetConvergence(gDx9Device->GetStereoHandle(), &convergence);
			buff.format("��� = %g", convergence);
			ui_render->DrawString(ui_render->font_simhei_12, font_color, bg_color, Core::Rectangle(0, 85, 0, 0), buff, Unit::kAlignLeftTop);
			buff.format("FPS = %d", gGame->fps);
			ui_render->DrawString(ui_render->font_simhei_12, font_color, bg_color, Core::Rectangle(0, 100, 0, 0), buff, Unit::kAlignLeftTop);
			buff.format("�Դ����� : %gMB", gDx9Device->total_memory);
			ui_render->DrawString(ui_render->font_simhei_12, font_color, bg_color, Core::Rectangle(0, 115, 0, 0), buff, Unit::kAlignLeftTop);
			buff.format("�Դ�ʹ���� : %gMB", gDx9Device->total_memory - gDx9Device->GetAvailableTextureMem() / 1024.f / 1024.f);
			ui_render->DrawString(ui_render->font_simhei_12, font_color, bg_color, Core::Rectangle(0, 130, 0, 0), buff, Unit::kAlignLeftTop);
			buff.format("��ͼʹ���� : %gMB", gDx9Device->texture_used / 1024.f / 1024.f);
			ui_render->DrawString(ui_render->font_simhei_12, font_color, bg_color, Core::Rectangle(0, 145, 0, 0), buff, Unit::kAlignLeftTop);
			buff.format("RenderTargetʹ���� : %gMB", gDx9Device->render_target_used / 1024.f / 1024.f);
			ui_render->DrawString(ui_render->font_simhei_12, font_color, bg_color, Core::Rectangle(0, 160, 0, 0), buff, Unit::kAlignLeftTop);
			buff.format("VertexBufferʹ���� : %gMB", gDx9Device->vertex_used / 1024.f / 1024.f);
			ui_render->DrawString(ui_render->font_simhei_12, font_color, bg_color, Core::Rectangle(0, 175, 0, 0), buff, Unit::kAlignLeftTop);
			buff.format("IndexxBufferʹ���� : %gMB", gDx9Device->index_used / 1024.f / 1024.f);
			ui_render->DrawString(ui_render->font_simhei_12, font_color, bg_color, Core::Rectangle(0, 190, 0, 0), buff, Unit::kAlignLeftTop);
		}

		{
			static bool draw_debug_info = false;

			if (gGame->input->IsKeyDown(KC_LCONTROL) && gGame->input->IsKeyPressed(KC_F1))
				draw_debug_info = !draw_debug_info;

			if (draw_debug_info)
			{
				ui_render->SetDefaultView();

				CStrBuf<256> buff;
				tempc_ptr(Character) viewer = gLevel->GetViewer();

				if (viewer)
				{
					Core::Rectangle rect(4, 80, 0, 0);

					Vector3 position;
					Vector3 dir;
					float angle;

					viewer->GetRotation().ToAxisAngle(position, angle);
					position = viewer->GetPosition();

					dir = Vector3(0, 0, -1) * viewer->GetLookDir();

					buff.format("�������꣺%g, %g, %g, ���� %g, \n�������� %g, %g, %g\n���� %.2g k/s ���� %.2g k/s",
						position.x, position.y, position.z, angle * Core::RAD2DEG, dir.x, dir.y, dir.z,
						net_bytes_send / 1024.f, net_bytes_received / 1024.f);

					ui_render->DrawString(ui_render->font_simhei_22, font_color, bg_color, rect, buff, Unit::kAlignLeftTop);
				}
			}
		}

		render->ui_render->SetScissorRect(scissor_rect);
#endif

#if DEBUG_PROFILER

		PROFILE_END("Total");

		if (CProfileManager::IsParse() == false)
		{
			CProfileNode * pNode = CProfileManager::CurrentShowRoot->GetNextNode();
			if (pNode && pNode->Get_Total_Time() > fps_limit)
			{
				gGame->fps_flag = true;
			}
		}
		CProfileManager::Parse(gGame->fps_flag);
		CProfileManager::ProfileRender();
		CProfileManager::Reset();
		CProfileManager::Clear();
		PROFILE_START("Total");
#endif
		render->ui_render->EndDraw();
	}

	{
		gDx9Device->EndScene();
		gDx9Device->Present(NULL, NULL, NULL, NULL);

		//if (gRender && gRender->GetEvaluateFlag())
		//{
		//	gRender->EvaluateHardware();
		//	gRender->SetEvaluateFlag(false);
		//	gDx9Device->SetDeviceLost();
		//}
	}

	if (bSavePhoto)
	{
		HRESULT hr = TakePicture();

		tempc_ptr(StateLobby) state_lobby = ptr_dynamic_cast<StateLobby>(machine.CurrentState());
		if (state_lobby && SUCCEEDED(hr))
		{
			state_lobby->EventSavePhoto.Fire(ptr_static_cast<StateLobby>(state_lobby), EventArgs());
		}
		tempc_ptr(StateBalance) state_balance = ptr_dynamic_cast<StateBalance>(machine.CurrentState());
		if (state_balance && SUCCEEDED(hr))
		{
			state_balance->EventSavePhoto.Fire(ptr_static_cast<StateBalance>(state_balance), EventArgs());
		}
		tempc_ptr(StateMainGame) state_game = ptr_dynamic_cast<StateMainGame>(machine.CurrentState());
		if (state_game && SUCCEEDED(hr))
		{
			state_game->EventSavePhoto.Fire(ptr_static_cast<StateMainGame>(state_game), EventArgs());
		}
	}

	// calculate FPS
	static int fps = 0;
	static double startTime = 0;
	static float max_frametime = 0;
	static float min_frametime = 0;

	static Core::CStrBuf<256> FPS;

	fps ++;
	if (Core::Task::GetTotalTime() - startTime > 1)
	{
		if (channel_connection)
		{
			if (channel_connection->udp_connection.IsConnected())
			{
				net_bytes_send = channel_connection->udp_connection.num_bytes_send;
				net_bytes_received = channel_connection->udp_connection.num_bytes_received;

				channel_connection->udp_connection.num_bytes_send = 0;
				channel_connection->udp_connection.num_bytes_received = 0;
			}

			if (channel_connection->tcp_connection.IsConnected())
			{
				net_bytes_send = channel_connection->tcp_connection.num_bytes_send;
				net_bytes_received = channel_connection->tcp_connection.num_bytes_received;

				channel_connection->tcp_connection.num_bytes_send = 0;
				channel_connection->tcp_connection.num_bytes_received = 0;
			}
		}

#ifndef MASTER
		if (screen)
		{
			FPS.format("FPS : %d, FrameTime:%gms, min: %gms max: %gms", fps, 1000.0 / (double)fps, min_frametime * 1000, max_frametime * 1000);
			screen->SetText(FPS);
		}
#endif

		this->fps = fps;
		startTime = Core::Task::GetTotalTime();
		fps = 0;
		max_frametime = 0;
		min_frametime = 1e38f;
	}
	else
	{
		// frame time.
		float frameTime = Task::GetFrameTime();

		if (min_frametime > frameTime) min_frametime = frameTime;
		if (max_frametime < frameTime) max_frametime = frameTime;
	}
}

size_t write_to_string(void *ptr, size_t size, size_t count, void *stream) 
{
	memcpy_s(stream, 2048, ptr, size * count);
	//((string*)stream)->append((char*)ptr, 0, size*count);
	return size*count;
}


bool ConvertStr2HttpStr(CURL * curl, const char* source, char* dest, int dest_length)
{
	//char buffer[128] = {0};
	
	//GBKToUTF8(source,buffer, sizeof(buffer));
	char* target = curl_easy_escape(curl, source,0);
	
	int length = strlen(target);
	
	if(length >= dest_length)
	{
		curl_free(target);
		return false;
	}

	strcpy_s(dest,dest_length, target);
	curl_free(target);

	return true;
} 
int Game::HttpXLReport(const char* report_character_id, int report_type, const char* report_desc)
{
	if(gGame->address.server_name == "")
		return -2;

	CURL * curl = curl_easy_init();
	curl_httppost *post = NULL;
	//curl_httppost *last = NULL; 

	char md5calcbuffer[2048] ={0};
	char bufMD5[1024] = {0};
	char buffer_response[2048] = {0};

	int returncode = 0;

	time_t t = time(NULL);

	SystemInfoCollection & sys_collection = g_SystemInfo_collection;
	static const char* key = "JHHSDKIQOWEI1294303JJ393034JSEUT";

	char url[4096] = "";
	strcpy_s(url, 4096, gHttpConfig.http_xl_report.Str());
	char dest[4096] = {0};
	char converter[4096] = {0};



	////targetCid
	//if(!ConvertStr2HttpStr(curl, report_character_id, converter, sizeof(converter)))
	//{
	//	returncode = -2;
	//	goto end;
	//}

	//sprintf_s(dest, sizeof(dest), "&%s=%s", "targetCid", converter);
	//strcat_s(url, sizeof(url), dest);
	////------------


	//// add key targetCid---
	//strcat_s(md5calcbuffer, sizeof(md5calcbuffer), report_character_id);
	//// ------------

	//targetRname
	if(!ConvertStr2HttpStr(curl, report_character_id, converter, sizeof(converter)))
	{
		returncode = -2;
		goto end;
	}
	sprintf_s(dest, sizeof(dest), "&%s=%s", "targetRname", converter);
	strcat_s(url, sizeof(url), dest);
	//------------


	// reporterCid
	if(!ConvertStr2HttpStr(curl, gGame->lobby_connection->user_name.Str(), converter, sizeof(converter)))
	{
		returncode = -2;
		goto end;
	}
	
	sprintf_s(dest, sizeof(dest), "&%s=%s", "reporterCid", converter);
	strcat_s(url, sizeof(url), dest);
	//------------

	// add key reporterCid---
	strcat_s(md5calcbuffer, sizeof(md5calcbuffer), gGame->lobby_connection->user_name.Str());
	// ------------


	// reporterRname
	if(!ConvertStr2HttpStr(curl, gGame->lobby_connection->character_name.Str(), converter, sizeof(converter)))
	{
		returncode = -2;
		goto end;
	}

	sprintf_s(dest, sizeof(dest), "&%s=%s", "reporterRname", converter);
	strcat_s(url, sizeof(url), dest);
	//------------


	// reporttype
	sprintf_s(dest, sizeof(dest), "&%s=%d", "reporttype", report_type);
	strcat_s(url, sizeof(url), dest);
	//------------


	// add key reporttype---
	sprintf_s(converter, sizeof(converter), "%d", report_type);
	strcat_s(md5calcbuffer, sizeof(md5calcbuffer), converter);
	// -----------


	//serverip   
	if(!ConvertStr2HttpStr(curl, sys_collection.proxy_ip.Str(), converter, sizeof(converter)))
	{
		returncode = -2;
		goto end;
	}

	sprintf_s(dest, sizeof(dest), "&%s=%s", "serverip", converter);
	strcat_s(url, sizeof(url), dest);
	
	// add key serverip---
	strcat_s(md5calcbuffer, sizeof(md5calcbuffer), sys_collection.proxy_ip.Str());
	// ------------
	
	

	//serverport   
	sprintf_s(dest, sizeof(dest), "&%s=%d", "serverport", sys_collection.proxy_port);
	strcat_s(url, sizeof(url), dest);
	// ------------

	// add key serverport---
	sprintf_s(converter, sizeof(converter), "%d", sys_collection.proxy_port);
	strcat_s(md5calcbuffer, sizeof(md5calcbuffer), converter);
	// -----------


	//reportdesc
	if(!ConvertStr2HttpStr(curl, report_desc, converter, sizeof(converter)))
	{
		returncode = -2;
		goto end;
	}

	sprintf_s(dest, sizeof(dest), "&%s=%s", "reportdesc", converter);
	strcat_s(url, sizeof(url), dest);
	// ------------

	// add key datetime---
	sprintf_s(converter, sizeof(converter), "%d", t);
	strcat_s(md5calcbuffer, sizeof(md5calcbuffer), converter);
	//------------

	// add key key from xl---
	strcat_s(md5calcbuffer, sizeof(md5calcbuffer), key);
	//------------

	// md5---------
	int len = strlen(md5calcbuffer);

	MD5::ReadBuf2MD5(md5calcbuffer, len, bufMD5, sizeof(bufMD5));

	sprintf_s(dest, sizeof(dest), "&%s=%s", "md5", bufMD5);
	strcat_s(url, sizeof(url), dest);
	//------------

	// datetime
	sprintf_s(dest, sizeof(dest), "&%s=%d", "datetime", t);
	strcat_s(url, sizeof(url), dest);
	// ---------



	curl_easy_setopt(curl, CURLOPT_URL, url); 
	curl_easy_setopt(curl, CURLOPT_POST, true); 
	curl_easy_setopt(curl, CURLOPT_TIMEOUT, 30);
	curl_easy_setopt(curl, CURLOPT_HTTPPOST, post);
	curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, write_to_string);
	curl_easy_setopt(curl, CURLOPT_WRITEDATA, &buffer_response);


	CURLcode res = curl_easy_perform(curl);
	long httpcode = 0;
	curl_easy_getinfo(curl,CURLINFO_RESPONSE_CODE, &httpcode);




	if(httpcode == 200 && res != CURLE_ABORTED_BY_CALLBACK)
	{
		int len = strlen(buffer_response);
		char c = buffer_response[len-2];
		if(c == '0')
		{
			returncode = 0;
		}
		else
		{
			returncode = -1;
		}
	}
	else
	{
		returncode = -1;
	}

end:
	curl_formfree(post);

	curl_easy_cleanup(curl);



	return returncode;
}
int Game::HttpXLInfo(const char* bugtitle, const char* bugdesc, const char* qq, const char* phone, int type)
{

	if(gGame->address.server_name == "")
		return -2;

	CURL * curl = curl_easy_init();
	curl_httppost *post = NULL;
	//curl_httppost *last = NULL; 

	char md5calcbuffer[2048] ={0};
	char bufMD5[1024] = {0};
	char buffer_response[2048] = {0};

	int returncode = 0;

	time_t t = time(NULL);


	static const char* key = "JHHSDKIQOWEI1294303JJ393034JSEUT";

	char url[4096] = "";
	strcpy_s(url, 4096, gHttpConfig.http_xl_info.Str());
	char dest[4096] = {0};
	char converter[4096] = {0};

	if(!ConvertStr2HttpStr(curl, gGame->lobby_connection->user_name.Str(), converter, sizeof(converter)))
	{
		returncode = -2;
		goto end;
	}
	
	sprintf_s(dest, sizeof(dest), "&%s=%s", "gameaccount", converter);
	strcat_s(url, sizeof(url), dest);

	// add key ---
	strcat_s(md5calcbuffer, sizeof(md5calcbuffer), gGame->lobby_connection->user_name.Str());
	strcat_s(md5calcbuffer, sizeof(md5calcbuffer), key);
	//------------

	
	if(!ConvertStr2HttpStr(curl, gGame->address.server_name.Str(), converter, sizeof(converter)))
	{
		returncode = -2;
		goto end;
	}
	sprintf_s(dest, sizeof(dest), "&%s=%s", "servername", converter);
	strcat_s(url, sizeof(url), dest);

	// add key ---
	strcat_s(md5calcbuffer, sizeof(md5calcbuffer), gGame->address.server_name.Str());
	//------------


	if(!ConvertStr2HttpStr(curl, gGame->lobby_connection->character_name.Str(), converter, sizeof(converter)))
	{
		returncode = -2;
		goto end;
	}

	sprintf_s(dest, sizeof(dest), "&%s=%s", "rolename", converter);
	strcat_s(url, sizeof(url), dest);

	if(!ConvertStr2HttpStr(curl, bugtitle, converter, sizeof(converter)))
	{
		returncode = -2;
		goto end;
	}


	sprintf_s(dest, sizeof(dest), "&%s=%s", "bugtitle", converter);
	strcat_s(url, sizeof(url), dest);


	if(!ConvertStr2HttpStr(curl, bugdesc, converter, sizeof(converter)))
	{
		returncode = -2;
		goto end;
	}


	sprintf_s(dest, sizeof(dest), "&%s=%s", "bugdesc", converter);
	strcat_s(url, sizeof(url), dest);


	if(!ConvertStr2HttpStr(curl, qq, converter, sizeof(converter)))
	{
		returncode = -2;
		goto end;
	}


	sprintf_s(dest, sizeof(dest), "&%s=%s", "qq", converter);
	strcat_s(url, sizeof(url), dest);


	if(!ConvertStr2HttpStr(curl, phone, converter, sizeof(converter)))
	{
		returncode = -2;
		goto end;
	}


	sprintf_s(dest, sizeof(dest), "&%s=%s", "phone", converter);
	strcat_s(url, sizeof(url), dest);


	if(type == 1)
		sprintf_s(dest, sizeof(dest), "&%s=%s", "type", "1");
	else
		sprintf_s(dest, sizeof(dest), "&%s=%s", "type", "2");
	strcat_s(url, sizeof(url), dest);


	sprintf_s(dest, sizeof(dest), "&%s=%d", "datetime", t);
	strcat_s(url, sizeof(url), dest);

	sprintf_s(converter, sizeof(converter), "%d", t);
	
	// add key ---
	strcat_s(md5calcbuffer, sizeof(md5calcbuffer), converter);
	//------------

	int len = strlen(md5calcbuffer);

	MD5::ReadBuf2MD5(md5calcbuffer, len, bufMD5, sizeof(bufMD5));

	sprintf_s(dest, sizeof(dest), "&%s=%s", "requestcode", bufMD5);
	strcat_s(url, sizeof(url), dest);
	
	
	SystemInfoCollection & sys_collection = g_SystemInfo_collection;
	// cpu 
	if(!ConvertStr2HttpStr(curl, sys_collection.cpu_name.Str(), converter, sizeof(converter)))
	{
		returncode = -2;
		goto end;
	}

	sprintf_s(dest, sizeof(dest), "&%s=%s", "cpu", converter);
	strcat_s(url, sizeof(url), dest);

	//osVersion
	if(!ConvertStr2HttpStr(curl, sys_collection.os.Str(), converter, sizeof(converter)))
	{
		returncode = -2;
		goto end;
	}

	sprintf_s(dest, sizeof(dest), "&%s=%s", "osVersion", converter);
	strcat_s(url, sizeof(url), dest);


	//graphics
	if(!ConvertStr2HttpStr(curl, sys_collection.video_adapter_name.Str(), converter, sizeof(converter)))
	{
		returncode = -2;
		goto end;
	}

	sprintf_s(dest, sizeof(dest), "&%s=%s", "graphics", converter);
	strcat_s(url, sizeof(url), dest);


	//graphicsDriver   
	if(!ConvertStr2HttpStr(curl, sys_collection.video_adapter_version.Str(), converter, sizeof(converter)))
	{
		returncode = -2;
		goto end;
	}

	sprintf_s(dest, sizeof(dest), "&%s=%s", "graphicsDriver", converter);
	strcat_s(url, sizeof(url), dest);
	

	//serverip   
	if(!ConvertStr2HttpStr(curl, sys_collection.proxy_ip.Str(), converter, sizeof(converter)))
	{
		returncode = -2;
		goto end;
	}

	sprintf_s(dest, sizeof(dest), "&%s=%s", "serverip", converter);
	strcat_s(url, sizeof(url), dest);


	//serverport   
	
	sprintf_s(dest, sizeof(dest), "&%s=%d", "serverport", sys_collection.proxy_port);

	strcat_s(url, sizeof(url), dest);

	//char* target = curl_easy_escape(curl, (char*)url_utf8,0);

	curl_easy_setopt(curl, CURLOPT_URL, url); 
	curl_easy_setopt(curl, CURLOPT_POST, true); 
	curl_easy_setopt(curl, CURLOPT_TIMEOUT, 30);
	curl_easy_setopt(curl, CURLOPT_HTTPPOST, post);
	curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, write_to_string);
	curl_easy_setopt(curl, CURLOPT_WRITEDATA, &buffer_response);
	

	CURLcode res = curl_easy_perform(curl);
	long httpcode = 0;
	curl_easy_getinfo(curl,CURLINFO_RESPONSE_CODE, &httpcode);

	


	if(httpcode == 200 && res != CURLE_ABORTED_BY_CALLBACK)
	{
		int len = strlen(buffer_response);
		char c = buffer_response[len-2];
		if(c == '0')
		{
			returncode = 0;
		}
		else
		{
			returncode = -1;
		}
	}
	else
	{
		returncode = -1;
	}

end:
	curl_formfree(post);

	curl_easy_cleanup(curl);

	

	return returncode;
}

int Game::HttpFaceBook()
{
	CURL * curl = curl_easy_init();
	curl_httppost *post = NULL;
	int returncode = 0;
	char buffer_response[2048] = {0};
	char url[4096] = "";

	strcpy_s(url, 4096, gFaceBookInterface.url.Str());

	char dest[4096] = {0};
	char converter[4096] = {0};

	if(!ConvertStr2HttpStr(curl, gFaceBookInterface.mark.Str(), converter, sizeof(converter)))
	{
		returncode = -2;
		goto end;
	}

	sprintf_s(dest, sizeof(dest), "&%s=%s", "mark", converter);
	strcat_s(url, sizeof(url), dest);

	if(!ConvertStr2HttpStr(curl, gFaceBookInterface.userid.Str(), converter, sizeof(converter)))
	{
		returncode = -2;
		goto end;
	}

	sprintf_s(dest, sizeof(dest), "&%s=%s", "userid", converter);
	strcat_s(url, sizeof(url), dest);

	if(!ConvertStr2HttpStr(curl, gFaceBookInterface.time.Str(), converter, sizeof(converter)))
	{
		returncode = -2;
		goto end;
	}

	sprintf_s(dest, sizeof(dest), "&%s=%s", "time", converter);
	strcat_s(url, sizeof(url), dest);

	if(!ConvertStr2HttpStr(curl, gFaceBookInterface.key.Str(), converter, sizeof(converter)))
	{
		returncode = -2;
		goto end;
	}

	sprintf_s(dest, sizeof(dest), "&%s=%s", "key", converter);
	strcat_s(url, sizeof(url), dest);

	if(!ConvertStr2HttpStr(curl, gFaceBookInterface.sign.Str(), converter, sizeof(converter)))
	{
		returncode = -2;
		goto end;
	}

	sprintf_s(dest, sizeof(dest), "&%s=%s", "sign", converter);
	strcat_s(url, sizeof(url), dest);

	curl_easy_setopt(curl, CURLOPT_URL, url); 
	curl_easy_setopt(curl, CURLOPT_POST, true); 
	curl_easy_setopt(curl, CURLOPT_TIMEOUT, 30);
	curl_easy_setopt(curl, CURLOPT_HTTPPOST, post);
	curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, write_to_string);
	curl_easy_setopt(curl, CURLOPT_WRITEDATA, &buffer_response);

	CURLcode res = curl_easy_perform(curl);
	long httpcode = 0;
	curl_easy_getinfo(curl,CURLINFO_RESPONSE_CODE, &httpcode);

	if(httpcode == 200 && res != CURLE_ABORTED_BY_CALLBACK)
	{
		int len = strlen(buffer_response);
		char c = buffer_response[len-2];
		if(c == '0')
		{
			returncode = 0;
		}
		else
		{
			returncode = -1;
		}
	}
	else
	{
		returncode = -1;
	}

end:
	curl_formfree(post);

	curl_easy_cleanup(curl);

	return returncode;
}