#include "pch.h"

using namespace Core;

DEFINE_PDE_TYPE_CLASS(Client::PVEAmmoInfo::PVEAmmoControlType)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_ENUM_CONSTRUCTOR();

		ADD_PDE_ENUM_ITEM("kControlType_None",	Client::PVEAmmoInfo::kControlType_None);
		ADD_PDE_ENUM_ITEM("kControlType_Trace",	Client::PVEAmmoInfo::kControlType_Trace);
	}
};

DEFINE_PDE_TYPE_CLASS(Client::PVEAmmoInfo)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_FIELD(ammo_type);
		ADD_PDE_FIELD(maxalive_time);
		ADD_PDE_FIELD(explode_range);
		ADD_PDE_FIELD(explode_damage);
		ADD_PDE_FIELD(hit_interval);
		ADD_PDE_FIELD(hit_damage);

		ADD_PDE_FIELD(controltype);
		ADD_PDE_FIELD(anglelimit);
		ADD_PDE_FIELD(triggertime);
		ADD_PDE_FIELD(triggerofftime);

		ADD_PDE_FIELD(hurtself);
		ADD_PDE_FIELD(ignorewall);

		ADD_PDE_FIELD(lockweight_fly);
		ADD_PDE_FIELD(lockweight_rot);

		ADD_PDE_FIELD(hit_decal);
		ADD_PDE_FIELD(explode_particle);
		ADD_PDE_FIELD(explode_sound);
		ADD_PDE_FIELD(fly_particle);
		ADD_PDE_FIELD(fly_sound);
		ADD_PDE_FIELD(fire_sound);
		ADD_PDE_FIELD(fly_joint_name);

		ADD_PDE_FIELD(skeleton);

		ADD_PDE_METHOD(AddBoxDesc);
		ADD_PDE_METHOD(AddCapsuleDesc);
		ADD_PDE_METHOD(SetMesh);
		ADD_PDE_METHOD(SetAABB);
	}
};

DEFINE_PDE_TYPE_CLASS(Client::PVEAmmo)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
	}
};

REGISTER_PDE_TYPE(Client::PVEAmmoInfo::PVEAmmoControlType);
REGISTER_PDE_TYPE(Client::PVEAmmoInfo);
REGISTER_PDE_TYPE(Client::PVEAmmo);

namespace Client
{
	///////////////////////////////////////////////////////////////////////////////
	void PVEAmmoInfo::SetMesh(const Core::Identifier & value, const U32 lod_level)
	{
		if (!gRender->lod_control->HasLod() && lod_level > 0)
			return;

		mesh[lod_level] = value;
	}

	///////////////////////////////////////////////////////////////////////////////
	PVEAmmo::PVEAmmo()
		: m_Actor(NULL)
		, m_SweepCache(NULL)

		, m_FlyJointId(0)
		, m_FlySound(NULL)
		, m_FireSound(NULL)
		, m_CanSee(false)

		, m_AmmoId(0)

		, m_SyncTime(0)
	{
		m_Velocity = Vector3::kZero;
		m_Position = Vector3::kZero;
		m_Rotation = Quaternion::kIdentity;
	}

	PVEAmmo::~PVEAmmo()
	{
		ReleasePhysx();
	}

	bool PVEAmmo::Initialize(U16 ammo_id, by_ptr(PVEAmmoInfo) ammo_info, by_ptr(Character) owner, bool is_boost, 
							const Core::Vector3 &pos, const Core::Vector3 &vel)
	{
		static const char szTeam[2] = {'r', 'b'};

		if (!ammo_info || !owner)
			return false;

		byte team = owner->GetTeam();

		m_AmmoInfo = ammo_info;
		m_AmmoId = ammo_id;
		m_Owner = owner;

		m_Mesh = ptr_new SkinMesh(MESH_KEY_WEAPON);
		if (m_Mesh)
		{
			for (U32 i = 0; i < MESH_LOD_LEVEL; i++)
			{
				if (m_Mesh->AddPrimitive(m_AmmoInfo->mesh[i], m_AmmoInfo->mesh[i], i))
				{
				}
			}

			m_Skeleton = RESOURCE_LOAD(m_AmmoInfo->skeleton, false, Skeleton);
			if (m_Skeleton)
			{
				m_Pose = m_Mesh->pose = ptr_new Pose(m_Skeleton);
			}
		}

		if (m_AmmoInfo->fly_sound.Length() > 0)
		{
			m_FlySound = FmodSystem::GetEvent(m_AmmoInfo->fly_sound);
			if (m_FlySound)
				m_FlySound->start();
		}
		
		if (m_AmmoInfo->fire_sound.Length() > 0)
		{
			m_FireSound = FmodSystem::GetEvent(m_AmmoInfo->fire_sound);
			if (m_FireSound)
				m_FireSound->start();
		}

		if (m_AmmoInfo->fly_particle.Length() > 0)
		{
			Core::String name;
			if (!is_boost)
				name = Core::String::Format("%s_%c", m_AmmoInfo->fly_particle.Str(), szTeam[team & 1]);
			else
				name = Core::String::Format("%s_%c_b%c", m_AmmoInfo->fly_particle.Str(), szTeam[team & 1], szTeam[team & 1]);
			m_FlyParticle = ptr_new ParticleSystem(name, false);
			m_FlyParticle->SetEnable(true);
		}

		if (m_Skeleton && m_AmmoInfo->fly_joint_name.Length() > 0)
		{
			m_FlyJointId = m_Skeleton->GetJointId(m_AmmoInfo->fly_joint_name);
		}

		if (!m_AmmoInfo->AABB.IsValid() && m_Mesh)
		{
			m_AmmoInfo->AABB = m_Mesh->GetAABB();
		}

		CreatePhysx(team + PhysxSystem::kGroupProjectStart, pos, Quaternion::kIdentity);
		StopPhysx();

		SetPosition(pos);
		SetVelocity(vel);

		m_LockUid = 0;
		m_FlyTime = 0;
		m_IsHitted = false;

		m_HitCharacters.Clear();

		Update(0);

		return true;
	}

	/// update
	void PVEAmmo::Update(float frame_time)
	{
		Core::Quaternion rot(Vector3(0, 1, 0), GetVelocity());
		MoveRotation(rot);

		if (m_FlyParticle)
			m_FlyParticle->Update(frame_time);
	}

	/// on render
	void PVEAmmo::OnRender(float frame_time)
	{
		PROFILE("PVEAmmo::OnRender");

		if (m_Mesh)
		{
			m_Mesh->SetPosition(GetPosition());
			m_Mesh->SetRotation(GetRotation());

			m_Mesh->Update();
		}

		if (!IsDead() || m_SyncData.Size() > 1)
		{
			if (m_FlyParticle)
			{
				Vector3 pos;
				Quaternion rot;

				if (GetJointInfo(m_FlyJointId, &pos, &rot))
				{
					m_FlyParticle->SetPosition(pos);
					m_FlyParticle->SetRotation(rot);
				}
			}

			if (m_FlySound)
			{
				FMOD_VECTOR pos = (const FMOD_VECTOR &)GetPosition();
				FMOD_VECTOR vel = (const FMOD_VECTOR &)GetVelocity();
				FMOD_VECTOR rot = (const FMOD_VECTOR &)GetRotation().GetZXY();

				m_FlySound->set3DAttributes(&pos, &vel/*, &rot*/);
			}
		}

		m_CanSee = true;
		if (m_AmmoInfo && m_AmmoInfo->AABB.IsValid())
		{
			AxisAlignedBox aabb = m_AmmoInfo->AABB;

			Matrix44 m(GetPosition(), 1, GetRotation());
			aabb.Transform(m);

			if (AABB_IS_OUTSIDE(aabb.TestIntersection(&gGame->camera->frustum, 0)))
			{
				m_CanSee = false;
			}
		}
	}

	/// timestep update
	void PVEAmmo::TimeStepUpdate(float frame_time)
	{
		PROFILE("PVEAmmo::TimeStepUpdate");

		if (!IsDead())
		{
			Array<byte> del_hitcharacters;
			HashSet<byte, float>::Enumerator itr(m_HitCharacters);
			while (itr.MoveNext())
			{
				float time_new = itr.Value() - frame_time;
				if (time_new <= 0)
					del_hitcharacters.PushBack(itr.Key());
				else
					m_HitCharacters.Set(itr.Key(), time_new);
			}
			for (U32 i = 0; i < del_hitcharacters.Size(); i++)
			{
				m_HitCharacters.Remove(del_hitcharacters[i]);
			}

			if (m_AmmoInfo->ammo_type == PVEAmmoInfo::kPVEAmmoType_HitExplode)
			{
				static const int MAX_HIT = 1;

				NxSweepQueryHit hit[MAX_HIT];

				Vector3 velocity = GetVelocity() * frame_time /*time_step*/;

				NxU32 num = m_Actor->linearSweep((const NxVec3 &)velocity, NX_SF_STATICS | NX_SF_DYNAMICS, NULL, MAX_HIT, hit, NULL/*, m_SweepCache*/);

				if (num == 0)
				{
					Vector3 pos = GetPosition() + velocity;
					MovePosition(pos);
				}
				else
				{
					m_IsHitted = true;

					OnImpact(hit, num);

					MovePosition((const Core::Vector3&)hit[0].point);
				}
			}
			else
			{
				static const int MAX_HIT = 512;

				NxSweepQueryHit hit[MAX_HIT];

				Vector3 velocity = GetVelocity() * frame_time /*time_step*/;

				NxU32 num = m_Actor->linearSweep((const NxVec3 &)velocity, NX_SF_STATICS | NX_SF_DYNAMICS, NULL, MAX_HIT, hit, NULL/*, m_SweepCache*/);

				if (num > 0)
					OnImpact(hit, num);

				Vector3 pos = GetPosition() + velocity;
				MovePosition(pos);
			}

			{
				m_FlyTime += frame_time;

				float change_ratio = 1.f;
				if (m_AmmoInfo->triggertime > 0.f)
				{
					change_ratio = m_FlyTime / m_AmmoInfo->triggertime;
					change_ratio = Clamp(Pow(change_ratio, 2.f), 0.f, 1.f);
				}

				float anglelimit_rad = m_AmmoInfo->anglelimit * change_ratio * frame_time * DEG2RAD;

				if (m_AmmoInfo->controltype == PVEAmmoInfo::kControlType_Trace && 
					m_FlyTime >= m_AmmoInfo->triggertime && 
					(m_AmmoInfo->triggerofftime == 0 || m_FlyTime <= m_AmmoInfo->triggerofftime))
				{
					tempc_ptr(Character) lock_c = gLevel->GetCharacter(m_LockUid);
					if (!lock_c || lock_c->IsDied() || 
						lock_c->GetTeam() == 2 || lock_c->GetTeam() == m_Owner->GetTeam())
					{
						// clean lock_c
						lock_c = NullPtr;

						//seach new lock_c
						const Array<sharedc_ptr(Character)> &characters = gLevel->GetCharacters();
						{
							struct SeachLockData
							{
								float fly_s;
								float turn_s;
							};

							HashSet<tempc_ptr(Character), SeachLockData> enemy_characters;

							float max_angle = m_AmmoInfo->anglelimit * DEG2RAD;
							float max_speed = GetVelocity().Length();

							Vector3 vector_try, rot_axis_tmp;
							Quaternion rot_try;
							SeachLockData data_tmp;

							for (U32 i = 0; i < characters.Size(); i++)
							{
								if (!characters[i]->IsDied() && characters[i]->GetTeam() != m_Owner->GetTeam() && 
									characters[i]->GetTeam() != 2)
								{
									vector_try = characters[i]->GetPosition() - GetPosition();
									rot_try.SetFromTo(GetVelocity(), vector_try);

									float a_try;
									rot_try.ToAxisAngle(rot_axis_tmp, a_try);

									data_tmp.fly_s = Length(vector_try) / max_speed;
									data_tmp.turn_s = a_try / max_angle;

									enemy_characters.Set(characters[i], data_tmp);
								}
							}
							tempc_ptr(Character) player = gLevel->GetPlayer();
							if (player && !player->IsDied() && 
								player->GetTeam() != m_Owner->GetTeam() && player->GetTeam() != 2)
							{
								vector_try = player->GetPosition() - GetPosition();
								rot_try.SetFromTo(GetVelocity(), vector_try);

								float a_try;
								rot_try.ToAxisAngle(rot_axis_tmp, a_try);

								data_tmp.fly_s = Length(vector_try) / max_speed;
								data_tmp.turn_s = Abs(a_try) / max_angle;

								enemy_characters.Set(player, data_tmp);
							}

							float canhit_mini_lockvalue = F32_MAX;

							float mini_lockvalue = F32_MAX;
							tempc_ptr(Character) mini_c;

							HashSet<tempc_ptr(Character), SeachLockData>::Enumerator itr(enemy_characters);
							while (itr.MoveNext())
							{
								float lockvalue = itr.Value().fly_s * m_AmmoInfo->lockweight_fly + itr.Value().turn_s * m_AmmoInfo->lockweight_rot;

								if (lockvalue < mini_lockvalue)
								{
									mini_lockvalue = lockvalue;
									mini_c = itr.Key();
								}

								if (lockvalue < canhit_mini_lockvalue && 
									(m_AmmoInfo->ammo_type == PVEAmmoInfo::kPVEAmmoType_HitThrough || 
									m_AmmoInfo->ignorewall || 
									itr.Key()->CheckCanHit(GetPosition(), F32_MAX)))
								{
									canhit_mini_lockvalue = lockvalue;
									lock_c = itr.Key();
								}
							}

							if (!lock_c)
								lock_c = mini_c;
						}

						OnLock(lock_c);
					}

					if (lock_c)
					{
						Vector3 pos_locked = lock_c->GetPosition();
						pos_locked.y += lock_c->GetHeight() * 1.0f;

						const Vector3 & pos_now = GetPosition();

						Vector3 velocity_new = pos_locked - pos_now;

						Vector3 velocity_now = GetVelocity();

						float length = velocity_now.Length();

#if 0
						{
							velocity_new.Normalize();
							velocity_new *= anglelimit_rad;
							velocity_new += velocity_now;
							velocity_new.Normalize();
							velocity_new *= length;
						}
#else
						{
							Vector3 rot_axis;
							float rot_angle;

							Quaternion rot_try(velocity_now, velocity_new);

							rot_try.ToAxisAngle(rot_axis, rot_angle);
							if (Abs(rot_angle) > anglelimit_rad)
							{
								if (rot_angle >= 0.f)
									rot_angle = anglelimit_rad;
								else
									rot_angle = -anglelimit_rad;

								rot_try.SetAxisAngle(rot_axis, rot_angle);
							}

							TransformCoord(velocity_new, velocity_now, rot_try);
							velocity_new.Normalize();
							velocity_new *= length;
						}
#endif
						SetVelocity(velocity_new);
					}
				}
			}
		}
	}

	/// draw
	void PVEAmmo::Draw(Primitive::DrawType drawtype, bool immediate)
	{
		if (m_CanSee)
		{
			if (m_Mesh)
				m_Mesh->Draw(drawtype, immediate);

			if (immediate && m_FlyParticle)
				m_FlyParticle->Draw();
		}
	}

	/// on impact
	void PVEAmmo::OnImpact(NxSweepQueryHit *hits, U32 num)
	{
		Array<tempc_ptr(Character)> hit_characters;

		for (U32 i = 0; i < num; i++)
		{
			tempc_ptr(Character) c = Character::FromNxActor(hits[i].hitShape->getActor());
			if (!c)
			{
				tempc_ptr(Vehicle) vehicle = Vehicle::FromNxActor(hits[i].hitShape->getActor());
				if (!vehicle)
					gLevel->AddDecal(m_AmmoInfo->hit_decal, (const Vector3&)hits[i].point, (const Vector3&)hits[i].normal, Vector3::kOne);
			}
			else
			{
				if (!m_HitCharacters.Contains(c->uid) && !hit_characters.Contains(c))
					hit_characters.PushBack(c);
			}
		}

		if (m_AmmoInfo->hit_damage > 0)
		{
			for (U32 i = 0; i < hit_characters.Size(); i++)
			{
				if (hit_characters[i] != m_Owner || m_AmmoInfo->hurtself)
				{
					m_HitCharacters.Set(hit_characters[i]->uid, m_AmmoInfo->hit_interval);

					if (gGame->channel_connection)
						gGame->channel_connection->PVEAmmoHitHurt(m_Owner->uid, hit_characters[i]->uid, ptr_static_cast<PVEAmmo>(this));
				}
			}
		}
	}

	/// on lock
	void PVEAmmo::OnLock(by_ptr(Character) c)
	{
		if (c && !c->IsDied())
			m_LockUid = c->uid;
	}

	/// on dead
	void PVEAmmo::OnDead()
	{
		if (m_AmmoInfo->explode_damage > 0)
		{
			float distance = 0;
			const Array<sharedc_ptr(Character)> & characters = gLevel->GetCharacters();
			tempc_ptr(Character) player = gLevel->GetPlayer();

			for (U32 i = 0; i < characters.Size(); i++)
			{
				if (m_AmmoInfo->ignorewall)
				{
					distance = Length(GetPosition() - characters[i]->GetPosition());
					if (m_AmmoInfo->explode_range >= distance && 
						(characters[i] != m_Owner || m_AmmoInfo->hurtself))
					{
						if (gGame->channel_connection)
							gGame->channel_connection->PVEAmmoExplodeHurt(m_Owner->uid, characters[i]->uid, ptr_static_cast<PVEAmmo>(this));
					}
				}
				else
				{
					if (characters[i]->CheckCanHit(GetPosition(), m_AmmoInfo->explode_range) && 
						(characters[i] != m_Owner || m_AmmoInfo->hurtself))
					{
						if (gGame->channel_connection)
							gGame->channel_connection->PVEAmmoExplodeHurt(m_Owner->uid, characters[i]->uid, ptr_static_cast<PVEAmmo>(this));
					}
				}
			}

			if (m_AmmoInfo->ignorewall)
			{
				distance = Length(GetPosition() - player->GetPosition());
				if (m_AmmoInfo->explode_range >= distance && 
					(player != m_Owner || m_AmmoInfo->hurtself))
				{
					if (gGame->channel_connection)
						gGame->channel_connection->PVEAmmoExplodeHurt(m_Owner->uid, player->uid, ptr_static_cast<PVEAmmo>(this));
				}
			}
			else
			{
				if (player->CheckCanHit(GetPosition(), m_AmmoInfo->explode_range) && 
					(player != m_Owner || m_AmmoInfo->hurtself))
				{
					if (gGame->channel_connection)
						gGame->channel_connection->PVEAmmoExplodeHurt(m_Owner->uid, player->uid, ptr_static_cast<PVEAmmo>(this));
				}
			}

			if (Length(GetPosition() - player->GetPosition()) < 15.f)
			{
				player->OnGrenadeExplode();
			}
		}

		if (m_AmmoInfo->explode_sound.Length() > 0)
			FmodSystem::Play3DEvent(m_AmmoInfo->explode_sound, (const FMOD_VECTOR &)GetPosition(), (const FMOD_VECTOR &)GetVelocity());

		if (m_AmmoInfo->explode_particle.Length() > 0)
			gLevel->AddParticle(m_AmmoInfo->explode_particle, GetPosition(), Vector3(0, 1, 0));
	}

	/// is dead
	bool PVEAmmo::IsDead()
	{
		if (m_FlyTime >= m_AmmoInfo->maxalive_time || 
			m_IsHitted == true)
		{
			return true;
		}

		return false;
	}

	/// get id
	U16 PVEAmmo::GetId()
	{
		return m_AmmoId;
	}

	/// get id
	tempc_ptr(PVEAmmoInfo) PVEAmmo::GetAmmoInfo()
	{
		return m_AmmoInfo;
	}

	/// get position
	const Vector3 & PVEAmmo::GetPosition()
	{
		if (m_Actor)
			m_Position = (const Vector3 &)m_Actor->getGlobalPosition();

		return m_Position;
	}

	/// set position
	void PVEAmmo::SetPosition(const Core::Vector3 & pos)
	{
		if (m_Actor)
			m_Actor->setGlobalPosition((const NxVec3 &)pos);

		m_Position = pos;
	}

	/// move position
	void PVEAmmo::MovePosition(const Vector3 & pos)
	{
		if (m_Actor)
			m_Actor->moveGlobalPosition((const NxVec3 &)pos);

		m_Position = pos;
	}

	/// get rotation
	const Core::Quaternion & PVEAmmo::GetRotation()
	{
		if (m_Actor)
			m_Rotation = (const Quaternion &)m_Actor->getGlobalOrientationQuat();

		return m_Rotation;
	}

	/// set rotation
	void PVEAmmo::SetRotation(const Core::Quaternion & rot)
	{
		if (m_Actor)
			m_Actor->setGlobalOrientationQuat((const NxQuat &)rot);

		m_Rotation = rot;
	}

	/// move rotation
	void PVEAmmo::MoveRotation(const Quaternion & rot)
	{
		if (m_Actor)
			m_Actor->moveGlobalOrientationQuat((const NxQuat &)rot);

		m_Rotation = rot;
	}

	/// get Velocity
	const Vector3 & PVEAmmo::GetVelocity()
	{
		if (m_Actor && m_Actor->readBodyFlag(NX_BF_KINEMATIC) == false)
			m_Velocity = (const Vector3 &)m_Actor->getLinearVelocity();

		return m_Velocity;
	}

	/// set Velocity
	void PVEAmmo::SetVelocity(const Core::Vector3 &velocity)
	{
		if (m_Actor && m_Actor->readBodyFlag(NX_BF_KINEMATIC) == false)
			m_Actor->setLinearVelocity((const NxVec3 &)velocity);

		m_Velocity = velocity;
	}

	void PVEAmmo::UpdateSyncData(float frame_time)
	{
		//if (is_player)
		//	return;

		// no sync data, return
		if (m_SyncData.Empty())
			return;

		SyncData data;
		Vector3	vel;

		// remove unused data
		while (m_SyncData.Size() > 1 && m_SyncData[1].time <= m_SyncTime)
			m_SyncData.PopFront();

		if (m_SyncData.Size() > 1)
		{
			SyncData & data1 = m_SyncData[0];
			SyncData & data2 = m_SyncData[1];

			float s = Clamp((m_SyncTime - data1.time) / (data2.time - data1.time), 0, 1);

			Lerp(data.position, data1.position, data2.position, s);
			Core::Slerp(data.rotation, data1.rotation, data2.rotation, s);

			// calculate velocity
			vel = (data.position - GetPosition()) / frame_time;

			// update time
			float delay_time = m_SyncData.Back().time - m_SyncTime;

			// scale time when delay time > 0.05
			if (delay_time > 0.1f)
				frame_time *= 1 + (delay_time - 0.1f);

			m_SyncTime += frame_time;
		}
		else
		{
			data = m_SyncData[0];
			vel = Vector3::kZero;
			m_SyncTime = m_SyncData[0].time;
		}

		MovePosition(data.position);
		MoveRotation(data.rotation);
	}

	void PVEAmmo::AddSyncData(byte time, const Core::Vector3 &position, const Core::Vector3 &direction)
	{
		if (!m_SyncData.Empty())
		{
			SyncData sync = m_SyncData.Back();

			sync.time += (float)time / 255.f;
			sync.position = position;
			sync.rotation.SetZXY(direction);

			m_SyncData.PushBack(sync);
		}
	}

	bool PVEAmmo::HasSyncData()
	{
		//return !(m_SyncData.Size() <= 1);
		return m_SyncData.Size() > 1;
	}

	tempc_ptr(PVEAmmo) PVEAmmo::FromNxActor(NxActor & actor)
	{
		Object *obj = (Object*)actor.userData;

		if (obj)
		{
			return ptr_dynamic_cast<PVEAmmo>(obj);
		}

		return NullPtr;
	}

	void PVEAmmo::CreatePhysx(int group, const Core::Vector3 &pos, const Core::Quaternion &rot)
	{
		{
			m_SweepCache = PhysxSystem::Scene()->createSweepCache();
		}

		{
			NxBodyDesc bodyDesc;

			NxActorDesc actorDesc;
			actorDesc.body = &bodyDesc;
			actorDesc.density = 100.0f;
			actorDesc.globalPose.t = (const NxVec3 &)pos;
			actorDesc.globalPose.M.fromQuat((const NxQuat &)rot);
			actorDesc.userData = this;

			for (U32 i = 0; i < m_AmmoInfo->boxdescs.Size(); i++)
			{
				NxBoxShapeDesc boxDesc;

				boxDesc.localPose.t = (const NxVec3 &)m_AmmoInfo->boxdescs[i].position;
				boxDesc.localPose.M.fromQuat((const NxQuat &)m_AmmoInfo->boxdescs[i].rotation);
				boxDesc.group = group;
				boxDesc.userData = this;

				boxDesc.dimensions = (const NxVec3 &)m_AmmoInfo->boxdescs[i].dimensions;

				actorDesc.shapes.pushBack(&boxDesc);
			}

			for (U32 i = 0; i < m_AmmoInfo->capsuledescs.Size(); i++)
			{
				NxCapsuleShapeDesc capsuleDesc;

				capsuleDesc.localPose.t = (const NxVec3 &)m_AmmoInfo->capsuledescs[i].position;
				capsuleDesc.localPose.M.fromQuat((const NxQuat &)m_AmmoInfo->capsuledescs[i].rotation);
				capsuleDesc.group = group;
				capsuleDesc.userData = this;

				capsuleDesc.radius = m_AmmoInfo->capsuledescs[i].radius;
				capsuleDesc.height = m_AmmoInfo->capsuledescs[i].height;

				actorDesc.shapes.pushBack(&capsuleDesc);
			}

			m_Actor = PhysxSystem::CreateActor(actorDesc);

			if (m_Actor)
			{
				m_Actor->updateMassFromShapes(actorDesc.density, 0);
				m_Actor->setAngularDamping(1.0f);
				m_Actor->setLinearDamping(0.0f);
				//m_Actor->userData = this;
			}
		}
	}

	void PVEAmmo::ReleasePhysx()
	{
		if (m_Actor)
		{
			PhysxSystem::ReleaseActor(*m_Actor);
			m_Actor = NULL;
		}

		if (m_SweepCache)
		{
			PhysxSystem::Scene()->releaseSweepCache(m_SweepCache);
			m_SweepCache = NULL;
		}
	}

	void PVEAmmo::StopPhysx()
	{
		if (m_Actor)
		{
			m_Actor->raiseBodyFlag(NX_BF_KINEMATIC);
		}
	}

	bool PVEAmmo::GetJointInfo(int joint_id, Core::Vector3 *pos, Core::Quaternion *rot)
	{
		if (m_Skeleton)
		{
			if (joint_id >= 0)
			{
				const Transform & transform = m_Pose->GetJointModelPose(joint_id);

				if (pos)
					*pos = GetPosition() + transform.position * GetRotation();

				if (rot)
					*rot = transform.rotation * GetRotation();

				return true;
			}
		}

		return false;
	}
}
