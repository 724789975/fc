namespace Client
{
	class LobbyConnection : public Core::TcpConnection, public Core::BinaryNetworkStream
	{
	public:
		enum State
		{
			kDisconnected,
			kConnected,
			kAuthentication,
			kInLogin,
			kInLobby,
			kInChannel,
			kInGame,
		};

		// rpc callback delegate
		typedef Core::IDelegate<void (*) (Core::String)> RpcCallback;

	public:
		// constructor.
		LobbyConnection();

		// destructor
		virtual ~LobbyConnection();

		// get state
		State GetState() { return (State)state; }

	public:
		// begin text rpc
		int BeginTextRpc(const char * func, by_ptr(RpcCallback) callback);

		// add rpc argument
		void TextRpcArgument(const char * key, const char * value);

		// end text rpc
		void EndTextRpc();

		// request enter lobby
		void RequestEnterLobby(uint character_id);

		// request leave lobby
		void RequestLeaveLobby();

		void RequestNickNameCreate(const Core::String& name);

		// request channel connect
		void RequestChannelConnect(int channel_id);

		// request chat
		void RequestChat(const Core::Identifier & to, const Core::String & msg);

		// team invite
		void RequestTeamInvite(const Core::String & name);

		// team join
		void RequestTeamJoin(const Core::String & name, uint uid);

		// team leave
		void RequestTeamLeave();

		// team kick
		void RequestTeamKick(const Core::String & name);

		// team change leader
		void RequestTeamChangeLeader(const Core::String & name);

		// request team refuse
		void RequestTeamRefuse(const Core::String & name, uint uid); 

		// request team call
		void RequestTeamCall(const Core::String & name);

		// request search room
		void RequestSearchRoom(RoomSearchOptions & options);

		// request cancel search room
		void RequestCancelSearchRoom();

		// request refuse preserve
		void RequestRefusePreserve(const char * caller, int server_id, int channel_id, int room_id, uint result);

		// request enter server
		void RequestEnterServer(int server_id);

		// request leave server
		void RequestLeaveServer();

		// request enter server
		void RequestEnterChannel(int server_id);

		// request leave server
		void RequestLeaveChannel();

		// request refresh server list
		void RequestRefreshServerList();

		// request refresh server list
		void RequestRefreshChannelList();

		// request character address
		void RequestCharacterAddress(const char * name, uint userdata);


		void RequestChangeMatchMap(uint dwLevelId);
		void RequestChangeMatchGameType(byte cGameType);

		void UpdateCharacterTimer(F32 frameTime);

		F32  GetCharacterTimer();

		void ResetCharacterTimer();

		void RestoreToStateLobby();

		void RequestSaveConfig(const Core::String& configStream);

		void RequestSaveCharacterProfile(const Core::String& profileStream);

		void RequestChatGroupCreate();

		void RequestChatGroupInvite(uint chatgroup_uid, const Core::String& name);

		void RequestChatGroupJoin(uint chatgroup_uid);

		void RequestChatGroupLeave(uint chatgroup_uid);

		void RequestChatGroupCall(uint chatgroup_uid, const Core::String& msg);

		void RequestChatGroupMember(uint chatgroup_uid);

		void NotifyMultiChat(const Core::String& group, const Core::String& msg, const Core::Array<Core::String>& names);

		void CollectionInGameInfo();


		void RequestApex(const char * pBuffer,int nLen);

		void RequestBattleGroups(const Core::String& group_name, uint start, uint count, byte is_searchonly);

		void RequestBattleGroupCreate(uint server_id, uint channel_id, uint room_id, RoomOption &roomoption);

		void RequestBattleGroupInvite(const Core::String& name);

		void RequestBattleGroupJoin(uint battlegroup_uid);

		void RequestBattleGroupLeave(uint battlegroup_uid);

		void RequestBattleGroupInfo(uint battlegroup_uid);

		void RequestBattleGroupReady();

		void RequestBattleGroupStartSearch(byte is_cancel);

		void RequestBattleGroupChallenge(uint battlegroup_uid);
      
		//ƥ�� 
		void RequestMatchingTeamCreate(uint server_id, uint channel_id, uint room_id, RoomOption &roomop);

		void RequestMatchingTeamJoin(uint chatgroup_uid);
        
		void RequestMatchingTeamInvite( const Core::String& name);

		void RequestMatchingTeamLeave();

		void RequestMatchingTeamKick();

		void RequestMatchingTeamChangeLeader();

		void RequestMatchingProgress();

		void RequestMatching();

		void RequestCancelMatching(  );

		void RequestLestPersonChannel(uint server_id);
       
		void IntoMatchingTeam(Core::String name);



		void OnResponseApex();

		void OnResponseBattleBattleGroups();

		void OnResponseBattleGroupCreate();

		void OnResponseBattleGroupJoin();

		void OnResponseBattleGroupStartSearch();

		void OnResponseBattleGroupChallenge();

		void OnNotifyBattleGroupInvite();

		void OnNotifyBattleGroupKick();

		void OnNotifyBattleGroupChange();

		void OnNotifyBattleGroupInfo();

		void OnNotifyBattleGroupSearching();

		void OnNotifyBattleGroupGameStart();


		void OnNotifyBillBoardInfo();

		//ƥ��
		void OnResponseMatchingTeamCreate();
		void OnResponseMatchingTeamInvite(); 
		void OnResponseMatchingTeamJoin();
		void OnResponseMatchingTeamLeave();
		void OnResponseMatchingTeamKick();
		void OnResponseMatchingTeamChangeLeader();
		void OnNotifyMatchingTeamInvite();
		void OnNotifyMatchingTeamMemberJoin();
		void OnNotifyMatchingTeamMemberLeave();
		void OnNotifyMatchingTeamChangeLeader();
		void OnNotifyMatchingTeamMemberInfo();
		void OnNotifyMatchingTeamLeave();	
		void OnNotifyMatchingTeamKick();
		void OnNotifyMatchingTeamChange();
		void OnResponseMatching();
		void OnResponseCancelMatching();
		void OnResponseMatchingProgress();
		void OnNotifyPunishedNames();
		void OnNotifyBeginMatch();
		void On_NotifyLeftPunishedTime();
		void OnNotifyGoToMetchingRoom();
		void OnResponseLestPersonChannel();





	public:
		Core::String login_name;
		Core::String login_pass;

	private:
		// parse message
		void OnMessage();

		// on connected
		void OnConnected();

		// on disconnected
		void OnDisconnected(bool is_error = false);

		// response
		void ResponseRPC();

		// response enter lobby
		void ResponseEnterLobby();

		// response leave lobby
		void ResponseLeaveLobby();

		// response channel connect
		void ResponseChannelConnect();

		// notiry chat
		void NotifyChat();

		// notify fcm change
		void NotifyFCM();

		// force disconnect
		void ForceDisconnect();

		// response team invite
		void ResponseTeamInvite();

		// response team invite
		void ResponseTeamJoin();

		// notify team invite
		void NotifyTeamInvite();

		// notify team member join
		void NotifyTeamMemberJoin();

		// notify team member leave
		void NotifyTeamMemberLeave();

		// notify team change leader
		void NotifyTeamChangeLeader();

		// notify team member info
		void NotifyTeamMemberInfo();

		// notify team change leader
		void NotifyTeamLeave();

		// notify team refuse
		void NotifyTeamRefuse();

		// notify room preserve
		void NotifyRoomPreserve();

		// notify room cancel preserve
		void NotifyRoomCancelPreserve();

		// response team call
		void ResponseTeamCall();

		// response team call
		void NotifyTeamCall();

		// response search room
		void ResponseSearchRoom();

		// notify update level list
		void NotifyUpdateLevelList();

		// notify refuse call
		void NotifyRefusePreserve();

		// notify rpc message
		void NotifyRPCMessage();

		// response enter server
		void ResponseEnterServer();

		// response leave server
		void ResponseLeaveServer();

		// notify refresh server list
		void NotifyRefreshServerList();

		// notify refresh channel list
		void NotifyRefreshChannelList();

		// response character address
		void ResponseCharacterAddress();

		// on notify chatgroup invite
		void OnNotifyChatGroupInvite();

		// on notify chatgroup join
		void OnNotifyChatGroupJoin();

		// on notify chatgroup leave
		void OnNotifyChatGroupLeave();

		// on notify chatgroup call
		void OnNotifyChatGroupCall();

		// on response chatgroup create
		void OnResponseChatGroupCreate();

		// on response chatgroup member
		void OnResponseChatGroupMember();

		// on notify multichat
		void OnNotifyMultiChat();

		void OnNotifyLoopMsg();



	private:
		int rpc_request_id;
		int rpc_request_count;
		sharedc_ptr(RpcCallback) rpc_callback;
		State state;

		F32  character_timer;

		// network encoder
		Core::XORNetworkEncoder xor_encoder;
		Core::DesNetworkEncoder des_encoder;

	public:
		uint uid;
		uint user_id;
		uint character_id;

		// todo
		uint m_dwMatchingGroupId;
		uint m_dwRoomId;
		uint m_dwSlotId;

		Core::String character_name;
		Core::String user_name;
		int	character_gender;
		Core::String character_group;
		int character_level;
		int fcm_message_send_index;
		float fcm_message_send_timer_old;

		Core::Array<TeamMember> team_members;
		Core::HashSet<Core::Identifier,uint> black_list;
		Core::Array<sharedc_ptr(LevelInfo)>	level_list;
		Core::HashSet<byte, Core::String>	game_description_set;

		Core::Array<ServerInfo> server_list;
		Core::Array<ChannelInfo> channel_list;

		sharedc_ptr(CharacterProfile)	m_CharacterProfile;

		sharedc_ptr(Gui::SquadPanel)		m_SquadPanel;

		sharedc_ptr(StateLobby)	m_RememberLobby;

		Core::Array<Core::String> lost_rpc_message;;
		Core::Array<Core::String> expired_weapon_name;

		Core::Array<Core::String> bill_board_list;
	};
}