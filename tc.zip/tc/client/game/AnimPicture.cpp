#include "pch.h"

using namespace Core;
using namespace Client;

DEFINE_PDE_TYPE_CLASS(Client::AnimPicture)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Core::Object);
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_EVENT(EventPlaystop);
	}
};

REGISTER_PDE_TYPE(Client::AnimPicture);

AnimPicture::AnimPicture()
: m_positon(Core::Vector2(0,0))
, m_zoom(Core::Vector2(1,1))
, m_size(Core::Vector2(0,0))
, m_zoomPoint(Core::Vector2(0,0))
, m_textureUV(Core::Rectangle(0,0,1,1))
, ui_picture(sharedc_ptr(Texture2D)(NullPtr))
, m_color(Core::ARGB(255,255,255,255))
, m_timespeed(0.01f)
, m_totletimes(1.5f)
, m_Maxtime(0.3f)
, m_retaintime(1.35f)
, m_playtimes(0.0f)
, m_Maxzoom(7.0f)
, m_Minzoom(1.0f)
, m_Sums(5)
, m_which(0)
, m_repetition(false)
, m_play(false)	
, m_timetote(0.0f)
, m_Add(1)
, m_beginAlve(0)
, m_endAlve(0)
, m_begintimes(0.3f)
, m_endtimes(0.3f)
{
}

AnimPicture::~AnimPicture()
{

}

void AnimPicture::Create(Core::String picture_str,Core::Vector2 position,Core::Vector2 size,Core::Vector2 zoompoint,int add)
{
	InitTabShow(picture_str);
	SetPostion(position);
	SetSize(size);
	SetZoomPoint(zoompoint);
	SetAdd(add);
}

void AnimPicture::render(by_ptr(UIRender) ui_render)
{
	if (!m_play)
	{
		return;
	}
	Matrix44 oldworld;
	Matrix44 world;
	Matrix44 oldview;
	Matrix44 view;	
	tempc_ptr(Character) viewer = gLevel->GetViewer();
	if (viewer)
	{
		Core::Vector3 rt_size = gGame->guiSys->GetSize();
		world = Core::Matrix44::kIdentity;
		oldworld = ui_render->GetWorld();
		oldview  = ui_render->GetView();

		view.SetScaleXYZ(2.0f/rt_size.x, -2.0f/rt_size.y, 0);
		ui_render->SetView(view);
		world.SetTranslationXYZ(-(rt_size.x/2), rt_size.y/2, 0);
		ui_render->SetWorld(world);
		ui_render->DrawTextureWindow(Core::Vector2(m_positon.x + (1 - m_zoom.x)*m_size.x*m_zoomPoint.x  ,m_positon.y + (1 - m_zoom.y)*m_size.y*m_zoomPoint.y), m_size.x*m_zoom.x, m_size.y*m_zoom.y, ui_picture,Core::Rectangle((m_which*1.0f)/m_Sums,0,(m_which + 1)*1.0f/m_Sums,1),m_color);

		ui_render->SetWorld(oldworld);
		ui_render->SetView(oldview);
	}
}

void AnimPicture::InitTabShow(Core::String str)
{
	if(str)
		ui_picture = RESOURCE_LOAD_NEW(str.Str(), true, Texture2D);
}

void AnimPicture::Update()
{
	if (!m_play)
	{
		return;
	}
	float frame_time = Task::GetFrameTime();
	m_playtimes += frame_time;
	m_timetote  += frame_time;
	if (m_playtimes > m_totletimes)
	{
		if (!m_repetition)
		{
			m_play = false;
			OnPlaystop();
		}
		m_playtimes = 0.0f;
	}
	else if (m_playtimes > m_retaintime )
	{
		m_zoom.x = m_Maxzoom - (m_Maxzoom - m_Minzoom) * (m_playtimes - m_retaintime)/(m_totletimes - m_retaintime);
		m_zoom.y = m_Maxzoom - (m_Maxzoom - m_Minzoom) * (m_playtimes - m_retaintime)/(m_totletimes - m_retaintime);
	}
	else if (m_playtimes > m_Maxtime)
	{
		m_zoom.x = m_Maxzoom;
		m_zoom.y = m_Maxzoom;
	}
	else if (m_playtimes < m_Maxtime)
	{
		m_zoom.x = (m_Maxzoom - 1) * m_playtimes/m_Maxtime + 1;
		m_zoom.y = (m_Maxzoom - 1) * m_playtimes/m_Maxtime + 1;
	}
	if (m_timetote >= m_timespeed)
	{
		m_which += m_Add;
		if (m_which >= m_Sums)
		{
			m_which = 0;
		}
		else if (m_which < 0)
		{
			m_which = m_Sums - 1;
		}
		m_timetote = 0.0f;
	}
	if (m_playtimes < m_begintimes)
	{
		m_color = Core::ARGB(255 - (255 - m_beginAlve) * m_playtimes/m_begintimes,255,255,255);
	}
	else if (m_playtimes > (m_totletimes - m_endtimes))
	{
		m_color = Core::ARGB(255 - (255 - m_endAlve) * (m_endtimes - m_totletimes + m_playtimes)/m_endtimes,255,255,255);
	} 
	else
	{
		m_color = Core::ARGB(255,255,255,255);
	}
}

void AnimPicture::SetPostion(Core::Vector2 postion)
{
	m_positon = postion;
}

void AnimPicture::SetPostion(F32 x, F32 y)
{
	m_positon.x = x;
	m_positon.y = y;
}

Core::Vector2 AnimPicture::GetPostion()
{
	return m_positon;
}

void AnimPicture::SetSize(Core::Vector2 size)
{
	m_size = size;
}

void AnimPicture::SetSize(F32 width, F32 high)
{
	m_size.x = width;
	m_size.y = high;
}

void AnimPicture::SetZoom(F32 zoom)
{
	m_zoom.x = zoom;
	m_zoom.y = zoom;
}

void AnimPicture::SetTextuv(Core::Rectangle Textuv)
{
	m_textureUV = Textuv;
}

void AnimPicture::SetColor(Core::ARGB color)
{
	m_color = color;
}

void AnimPicture::SetZoom(Core::Vector2 zoom)
{
	m_zoom = zoom;
}

void AnimPicture::SetZoomPoint(Core::Vector2 point)
{
	if (point.x > 1)
	{
		F32 x_Pos = point.x/m_size.x;
		F32 y_Pos = point.y/m_size.y;
		m_zoomPoint.x = x_Pos;
		m_zoomPoint.y = y_Pos;
	} 
	else
	{
		m_zoomPoint = point;
	}
}

void AnimPicture::Settimespeed(F32 time)
{
	m_timespeed = time;
}

void AnimPicture::Settotletimes(F32 time)
{	
	m_totletimes = time;
}

void AnimPicture::SetMaxtime(F32 time)
{
	m_Maxtime = time;
}

void AnimPicture::Setretaintime(F32 time)
{
	m_retaintime = time;
}

void AnimPicture::Setplaytimes(F32 time)
{
	m_playtimes = time;
}

void AnimPicture::SetMaxzoom(F32 zoom)
{
	m_Maxzoom = zoom;
}

void AnimPicture::SetMinzoom(F32 zoom)
{
	m_Minzoom = zoom;
}

void AnimPicture::SetSums(int sum)
{
	m_Sums = sum;
}

void AnimPicture::SetWhich(int which)
{
	m_which = which;
}

void AnimPicture::Setrepetition(bool value)
{
	m_repetition = value;
}

void AnimPicture::Setplay(bool value)
{
	if (m_play != value)
	{
		m_play = value;
		m_playtimes = 0.0f;
		m_timetote = 0.0f;
	}
}

void AnimPicture::SetAdd(int add)
{
	m_Add = add;
}

void AnimPicture::SetBegintimes(F32 time)
{
	m_begintimes = time;
}

void AnimPicture::SetEndtimes(F32 time)
{
	m_endtimes = time;
}

void AnimPicture::OnPlaystop()
{
	Core::EventArgs e;
	EventPlaystop.Fire(ptr_static_cast<Client::AnimPicture>(this), e);
}