#include "pch.h"

using namespace Core;

namespace Client
{
	static int s_OctTreeNodeIdBuilder = 0;

	static int GenOctTreeNodeId()
	{
		return s_OctTreeNodeIdBuilder++;
	}

	static void ResetOctTreeNodeIdBuilder()
	{
		s_OctTreeNodeIdBuilder = 0;
	}

	OctTreeNode::OctTreeNode()
		: m_aabb(AxisAlignedBox::kInvalid)
		, m_level(0)
		, m_id(-1)
	{
	}

	OctTreeNode::~OctTreeNode()
	{
		UnLoadData();
	}

	void OctTreeNode::BuildChild(const Core::AxisAlignedBox& box, const Core::Vector3& threshold, int level)
	{
		PDE_ASSERT(box.IsValid(), "AxisAlignedBox is invalid");

		if (!box.IsValid())
		{
			LogSystem.WriteLinef("OctTreeNode::BuildChild() : AxisAlignedBox is invalid");

			return;
		}

		//this node
		m_level = level;
		m_aabb = box;

		//child node
		StaticArray<AxisAlignedBox, OctNodeNum> childaabb;

		Vector3 extent = box.GetExtent();
		//Vector3 center = box.GetCenter();

		childaabb.PushBack(box);
		//splt x
		if (extent.x > threshold.x)
		{
			U32 splt_num = childaabb.Size();
			for (U32 i = 0; i < splt_num; i++)
			{
				AxisAlignedBox boxL(childaabb[i].Min, Vector3(childaabb[i].Max.x - extent.x * 0.5f, childaabb[i].Max.y, childaabb[i].Max.z));
				AxisAlignedBox boxR(Vector3(childaabb[i].Min.x + extent.x * 0.5f, childaabb[i].Min.y, childaabb[i].Min.z), childaabb[i].Max);

				childaabb[i] = boxL;
				childaabb.PushBack(boxR);
			}
		}
		//splt y
		if (extent.y > threshold.y)
		{
			U32 splt_num = childaabb.Size();
			for (U32 i = 0; i < splt_num; i++)
			{
				AxisAlignedBox boxT(childaabb[i].Min, Vector3(childaabb[i].Max.x, childaabb[i].Max.y - extent.y * 0.5f, childaabb[i].Max.z));
				AxisAlignedBox boxB(Vector3(childaabb[i].Min.x, childaabb[i].Min.y + extent.y * 0.5f, childaabb[i].Min.z), childaabb[i].Max);

				childaabb[i] = boxT;
				childaabb.PushBack(boxB);
			}
		}
		//splt z
		if (extent.z > threshold.z)
		{
			U32 splt_num = childaabb.Size();
			for (U32 i = 0; i < splt_num; i++)
			{
				AxisAlignedBox boxN(childaabb[i].Min, Vector3(childaabb[i].Max.x, childaabb[i].Max.y, childaabb[i].Max.z - extent.z * 0.5f));
				AxisAlignedBox boxF(Vector3(childaabb[i].Min.x, childaabb[i].Min.y, childaabb[i].Min.z + extent.z * 0.5f), childaabb[i].Max);

				childaabb[i] = boxN;
				childaabb.PushBack(boxF);
			}
		}

		PDE_ASSERT(childaabb.Size() <= OctNodeNum, "childaabb.size() is too big");

		if (childaabb.Size() <= 1)
		{
			//leaf
			m_id = GenOctTreeNodeId();

			return;
		}

		for (U32 i = 0; i < childaabb.Size(); i++)
		{
			OctTreeNode *pChild = new OctTreeNode;
			pChild->BuildChild(childaabb[i], threshold, level + 1);

			m_child.PushBack(pChild);
		}
	}

	void OctTreeNode::BuildChild(Core::Stream& stream)
	{
		UnLoadData();

		//read m_aabb
		stream.Read(m_aabb.fAxis, sizeof(AxisAlignedBox));

		//read m_visible_id_list
		U32 size = 0;
		stream.Read(&size, sizeof(U32));
		m_visible_id_list.Reserve(size);
		for (U32 i = 0; i < size; i++)
		{
			int visible_id = 0;
			stream.Read(&visible_id, sizeof(int));

			m_visible_id_list.PushBack(visible_id);
		}

		//read m_level
		stream.Read(&m_level, sizeof(int));

		//read m_id
		stream.Read(&m_id, sizeof(int));

		//read m_child
		stream.Read(&size, sizeof(U32));
		for (U32 i = 0; i < size; i++)
		{
			OctTreeNode *pChild = new OctTreeNode;
			pChild->BuildChild(stream);

			m_child.PushBack(pChild);
		}
	}

	void OctTreeNode::BuildChild(const OctTreeNode* node)
	{
		if (node)
		{
			UnLoadData();

			m_level = node->m_level;

			m_aabb = node->m_aabb;
			m_visible_id_list = node->m_visible_id_list;

			for (U32 i = 0; i < node->m_child.Size(); i++)
			{
				OctTreeNode *pChild = new OctTreeNode;
				pChild->BuildChild(node->m_child[i]);

				m_child.PushBack(pChild);
			}
		}
	}

	void OctTreeNode::SaveToStream(Core::Stream& stream)
	{
		//write m_aabb
		stream.Write(m_aabb.fAxis, sizeof(AxisAlignedBox));

		//write m_visible_id_list
		U32 size = m_visible_id_list.Size();
		stream.Write(&size, sizeof(U32));
		if (size > 0)
		{
			stream.Write(m_visible_id_list.GetData(), size * sizeof(int));
		}

		//write m_level
		stream.Write(&m_level, sizeof(int));

		//write m_id
		stream.Write(&m_id, sizeof(int));

		//write m_child
		size = m_child.Size();
		stream.Write(&size, sizeof(U32));
		for (U32 i = 0; i < size; i++)
		{
			m_child[i]->SaveToStream(stream);
		}
	}

	OctTreeNode* OctTreeNode::GetNodeByPosition(const Vector3& pos)
	{
		if (m_aabb.IsPointInside(pos))
		{
			if (IsLeaf())
			{
				return this;
			}

			for (U32 i = 0; i < m_child.Size(); i++)
			{
				OctTreeNode *pChild = m_child[i]->GetNodeByPosition(pos);
				if (pChild)
				{
					return pChild;
				}
			}
		}

		return NULL;
	}

	void OctTreeNode::GetLeaf(Core::Deque<OctTreeNode*>& list)
	{
		if (IsLeaf())
		{
			list.PushBack(this);
		}
		else
		{
			for (U32 i = 0; i < m_child.Size(); i++)
			{
				m_child[i]->GetLeaf(list);
			}
		}
	}

	void OctTreeNode::UnLoadData()
	{
		for (U32 i = 0; i < m_child.Size(); i++)
		{
			SAFE_DELETE(m_child[i]);
		}
		m_child.Clear();

		m_visible_id_list.Clear();
	}

	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	MapVisibleTree::MapVisibleTree()
		: root(NULL)
		, threshold(0.1f, 0.1f, 0.1f)
	{
	}

	MapVisibleTree::~MapVisibleTree()
	{
		UnloadData();
	}

	void MapVisibleTree::BuildTree(const Core::AxisAlignedBox& aabb, const Core::Vector3& threshold)
	{
		UnloadData();

		ResetOctTreeNodeIdBuilder();

		root = new OctTreeNode;
		root->BuildChild(aabb, threshold);

		this->threshold = threshold;
	}

	bool MapVisibleTree::BuildTree(Core::Stream& stream)
	{
		UnloadData();

		//read root
		root = new OctTreeNode;
		root->BuildChild(stream);

		//read threshold
		stream.Read(&threshold, sizeof(F32) * 3);

		return true;
	}

	bool MapVisibleTree::SaveTree(Core::Stream& stream)
	{
		if (!root)
		{
			return false;
		}

		//write root
		root->SaveToStream(stream);

		//write threshold
		stream.Write(&threshold, sizeof(F32) * 3);

		return true;
	}

	bool MapVisibleTree::GetVisibleListByPosition(const Core::Vector3& pos, const Core::Array<int>*& pVisibleList)
	{
		if (root)
		{
			OctTreeNode *pNode = root->GetNodeByPosition(pos);
			if (pNode)
			{
				pVisibleList = &pNode->GetVisibleList();

				return true;
			}
		}

		return false;
	}

	void MapVisibleTree::GetAllLeaf(Core::Deque<OctTreeNode*>& list) const
	{
		if (root)
		{
			list.Clear();

			root->GetLeaf(list);
		}
	}

	OctTreeNode* MapVisibleTree::GetRoot() const
	{
		return root;
	}

	bool MapVisibleTree::SaveData(Core::Stream& stream)
	{
		Resource::SaveData(stream);

		return SaveTree(stream);
	}

	sharedc_ptr(Object) MapVisibleTree::LoadData(Core::Stream& stream)
	{
		if (!Resource::LoadData(stream))
			return NullPtr;

		sharedc_ptr(MapVisibleTree) tree = ptr_new MapVisibleTree;

		tree->BuildTree(stream);

		return tree;
	}

	sharedc_ptr(Object) MapVisibleTree::BuildData()
	{
		sharedc_ptr(MapVisibleTree) obj = NullPtr;

		Core::FileStream treefs;
		if (treefs.Open(GetPath().Str(), FileStream::kReadOnly))
		{
			obj = ptr_new MapVisibleTree;

			if (!obj->BuildTree(treefs))
			{
				obj = NullPtr;
			}

			treefs.Close();
		}

		return obj;
	}

	void MapVisibleTree::UnloadData()
	{
		SAFE_DELETE(root);
	}

	bool MapVisibleTree::OnLoadData(by_ptr(Object) obj)
	{
		UnloadData();

		sharedc_ptr(MapVisibleTree) tree = ptr_dynamic_cast<MapVisibleTree>(obj);

		if (tree && tree->root)
		{
			root = new OctTreeNode;
			root->BuildChild(tree->root);

			threshold = tree->threshold;

			return true;
		}

		return false;
	}

	short MapVisibleTree::GetVersion()
	{
		return 1;
	}

	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	static void PrintOctTreeNode(const OctTreeNode& node, Core::TextStreamWriter& writer)
	{
		for (int i = 0; i < node.GetLevel(); i++)
		{
			writer.Writef("\t");
		}

		writer.Writef("Level:[%d], Id:[%d], ", node.GetLevel(), node.GetId());

		writer.Writef("AABB:[");
		for (int i = 0; i < 6; i++)
		{
			writer.Writef("%f, ", node.GetAABB().fAxis[i]);
		}
		writer.Writef("], ");

		writer.Writef("VisibleList:[");
		for (U32 i = 0; i < node.GetVisibleList().Size(); i++)
		{
			writer.Writef("%d, ", node.GetVisibleList()[i]);
		}
		writer.Writef("]\n");

		const Core::StaticArray<OctTreeNode*, OctNodeNum>& child_node = node.GetChilds();
		for (U32 i = 0; i < child_node.Size(); i++)
		{
			PrintOctTreeNode(*(child_node[i]), writer);
		}
	}

	void PrintMapVisibleTree(const MapVisibleTree& tree, Core::TextStreamWriter& writer)
	{
		OctTreeNode *pNode = tree.GetRoot();
		if (pNode)
		{
			PrintOctTreeNode(*pNode, writer);
		}
	}
}