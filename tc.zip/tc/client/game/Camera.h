#define NORMAL_FOV	85


namespace Client
{
	class Character;

	class Camera
	{
	public:
		enum ControlMode
		{
			kFixed,
			kFreeMove,
			kViewMode,
			kCharacterControl,
			kRojectControl,
			kDiedMode,

			kControlModeCount,
		};

	public:
		// constructor.
		Camera();

		// free move
		void FreeMove(Core::Vector3 move, Core::Vector2 rotate);

		// rotate
		void LookAt(Core::Vector3 target, Core::Vector2 rotate);

		// pool back
		void PoolBack(float distance);

		// calculate matrix
		void CalculateViewProjectionMatrix(Core::Matrix44 & view, Core::Matrix44 & projection) const;

		// update aspect
		void UpdateAspect(const Core::Vector2 & size);

		// frame update
		void FrameUpdate(by_ptr(Character) viewer, float frameTime);

		// frame update(manual)
		void ManualUpdate(float _fov, float frameTime);

		// camera near
		SIMPLE_PDE_ATTRIBUTE_RW(Near, F32);

		// camera far
		SIMPLE_PDE_ATTRIBUTE_RW(Far, F32);

	public:
		Core::Vector3 position;
		Core::Vector3 last_position;
		Core::Quaternion rotation;
		float zoom;
		float aspect;
		float distance;
		float target_distance;

		float fov;
		float target_fov;
		bool wide_screen_mode;

		ControlMode control_mode;

		bool lock_camera;

		Core::FrustumArea frustum;

		Core::Matrix44 viewMatrix;
		Core::Matrix44 projMatrix;
		Core::Matrix44 viewprojMatrix;

		Core::Matrix44 inv_viewproj_transpose;
		Core::Matrix44 inv_view_matrix;
		
		Core::Vector3 goal_position;
		float direction_rotation;
		bool isendfind;
	};
}