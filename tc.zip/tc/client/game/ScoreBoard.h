namespace Client
{
	class Game;

	struct KillHistory
	{
		Core::Identifier name1;
		Core::Identifier name2;
		uint team1;
		uint team2;
		byte part;
		int uid_assist;
		sharedc_ptr(WeaponInfo) weapon_info;
		byte sustainhurttype;
	};

	class ScoreBoard
	{
	public:
		// constructor.
		ScoreBoard();

		// add kill
		void Kill(by_ptr(Character) from, by_ptr(Character) to, byte assist, byte part, by_ptr(WeaponInfo) weapon_info,byte sustaintype = 0);

		// update
		void Update(float frameTime);

		// clear
		void Clear();

	public:
		Core::Array<sharedc_ptr(Character)> teams[3];
		Core::Array<KillHistory> kill_list;
		float kill_list_scroll_time;

		int team_score[2];
		int team_kills[2];
		int team_round[2];

		enum ScoreType
		{
			kKills,
			kRounds,
		};

		byte score_type;
	};


}