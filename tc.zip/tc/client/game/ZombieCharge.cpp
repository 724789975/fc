#include "pch.h"

using namespace Core;
using namespace Client;

DEFINE_PDE_TYPE_CLASS(Client::ZombieChargeInfo)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Client::WeaponInfo);
		ADD_PDE_DEFAULT_CONSTRUCTOR();
		ADD_PDE_FIELD(skill_cooldown);
		ADD_PDE_FIELD(skill_usetime);
		ADD_PDE_FIELD(skill_hurt);
	}
};

REGISTER_PDE_TYPE(Client::ZombieChargeInfo);

/// constructor
ZombieCharge::ZombieCharge(by_ptr(ZombieChargeInfo) info)
	: isCharge(false)
{
	weapon_info = charge_info = info;
}

/// initialize
void ZombieCharge::Initialize()
{
	WeaponBase::Initialize();
	skill = ptr_new(PlayerSkill);
	skill->type = kSkillZombieCharge;
	charge_usetime = -1.f;
}

/// udpate
void ZombieCharge::Update(float frame_time)
{
	WeaponBase::Update(frame_time);

	tempc_ptr(Character) player = GetOwner();

	if (!player)
		return;

	if (player->second_action_on && player->zombiecharge_cd_time <= 0.f && !isCharge)
	{
		charge_usetime = charge_info->skill_usetime;
		player->zombiecharge_cd_time = charge_info->skill_cooldown;
		player->LockStateByType(kLSSelectWeapon);
		player->LockStateByType(kLSJump);
		player->LockStateByType(kLSCrouch);
		player->LockStateByType(kLSCamera);
		player->SetLookDir(player->GetRotation());
		isCharge = true;
		skill->uid = 0;
		gGame->channel_connection->UseSkill(skill);
	}
	else if (isCharge)
	{
		charge_usetime -= frame_time;

		if (CheckCharge() || charge_usetime < 0.f)
		{
			charge_usetime = -1;
			isCharge = false;
			player->UnLockStateByType(kLSSelectWeapon);
			player->UnLockStateByType(kLSJump);
			player->UnLockStateByType(kLSCrouch);
			player->UnLockStateByType(kLSCamera);
			const FirstPerson & first_person = player->GetFirstPerson();
			if(first_person.animation_group)
			{
				first_person.animation_group->StopAction(true);
			}
		}
	}
}

bool ZombieCharge::CheckCharge()
{
	tempc_ptr(Character) player = GetOwner();

	if (!player || !charge_info || !gPhysxScene)
		return false;
	Core::Quaternion rotation = player->GetRotation();
	Core::Vector3 position = player->GetPosition();
	Core::Vector3 temp_pos = position + Vector3(0.f,1.35f,0.5f) * rotation;
	float distance = 1.2f;

	Vector3 dir = Vector3(0, 0, -1) * rotation;
	Vector3 scanprange(0.55f,0.55f,0.01f);
	dir.Normalize();

	Vector3 firemotion = dir * distance;

	Core::Matrix44 rotmatrix(rotation);
	NxMat33 matt;
	matt.setRow(0,NxVec3(rotmatrix._11,rotmatrix._12,rotmatrix._13));
	matt.setRow(1,NxVec3(rotmatrix._21,rotmatrix._22,rotmatrix._23));
	matt.setRow(2,NxVec3(rotmatrix._31,rotmatrix._32,rotmatrix._33));
	NxBox FlameBox((const NxVec3 &)temp_pos,(const NxVec3 &)scanprange,matt);

	//������ײ������
	NxU32 activeGroups = 0;
	activeGroups |= 1 << PhysxSystem::kStatic;
	activeGroups |= 1 << PhysxSystem::kStaticCollisionWithPerson;
	activeGroups |= 1 << (player->GetTeam() == 0 ? PhysxSystem::kGroupEnd : PhysxSystem::kGroupStart);
	activeGroups |= 1 << (player->GetTeam() == 0 ? PhysxSystem::kStaticCollisionWithGateTeam2 : PhysxSystem::kStaticCollisionWithGateTeam1);

	NxSweepQueryHit hit[200];
	NxU32 num = gPhysxScene->linearOBBSweep(FlameBox,(const NxVec3 &)firemotion, NX_SF_DYNAMICS|NX_SF_STATICS, NULL, 200, hit, NULL , activeGroups);
	if (num > 0)
	{
 		for(NxU32 i = 0; i < num ;i++)
 		{
 			if(hit[i].hitShape->getGroup() >= PhysxSystem::kGroupStart  && hit[i].hitShape->getGroup() <= PhysxSystem::kGroupEnd)
 			{
 				NxActor &actor = hit[i].hitShape->getActor();
 
 				tempc_ptr(Character) p = Character::FromNxActor(actor);
				tempc_ptr(DummyObject) dummy = DummyObject::FromNxActor(actor);
 				if (p)
 				{
					Vector3 v = Vector3(0,0,-1) * player->GetLookDir();
					v.y +=0.4f;
					v.Normalize();
					Core::Quaternion rot;
					rot.SetFromTo(Vector3(0,0,-1),v);
					gGame->channel_connection->ChargeSomething(p->uid, 1, rot);

					int part = p->GetActorId(&actor);
					gGame->channel_connection->PokeHurt(true, p->uid, part, false);
					/*return true;*/
 				}
				else if(dummy)
				{
					bool is_boost(false);
					if (gGame->channel_connection)
					{
						if( GetGaiLv(player->rand_fun.Rand(),player->rand_fun.GetRandMax()) * 10000 < weapon_info->hit_crit)
							is_boost = true;


						bool back = false;
						Vector3 front_dir = Vector3(0, 0, -1) * player->GetRotation();
						Vector3 dir = Vector3(0, 0, -1) * dummy->GetRotation();
						back = Dot(front_dir, dir) > 0;

						gGame->channel_connection->PokeHurtDummy(true, dummy->dummyobjectinfo->dummy_id, back);
					}
				}
 			}
 		}
		gGame->channel_connection->ChargeSomething(0, 0, Core::Quaternion(0,0,0,0));
		/*return true;*/
	}
	return false;
}

void ZombieCharge::DrawUI(by_ptr(UIRender) ui_render)
{
	WeaponBase::DrawUI(ui_render);

	CStrBuf<256> buff;
	buff.format(weapon_info->name);
	buff.toupper();

	ui_render->DrawStringShadow(ui_render->font_simhei_24, ARGB(255, 241, 211), ARGB(0,0,0), ARGB(0, 0, 0, 0), Core::Rectangle(-195, 0, 0, 1), "1/1", Unit::kAlignLeftBottom);

	ui_render->DrawStringShadow(ui_render->font_simhei_14, ARGB(255, 241, 211), ARGB(0,0,0), ARGB(0, 0, 0, 0), Core::Rectangle(-100, -20, 0, -7), buff, Unit::kAlignCenterBottom);
}

/// can active
bool ZombieCharge::CanActive()
{
	return WeaponBase::CanActive();
}

/// active
void ZombieCharge::Active()
{
	WeaponBase::Active();
	isCharge = false;
}

/// inactive
void ZombieCharge::Inactive()
{
	WeaponBase::Inactive();
	isCharge = false;
	charge_usetime = -1.f;
}