namespace Client
{
	class AnimPicture : public Core::Object
	{
	public:
		DECLARE_PDE_OBJECT(AnimPicture, Core::Object);

		DECLARE_PDE_EVENT(EventPlaystop,	Core::EventArgs);

		AnimPicture();
		~AnimPicture();
		void Create(Core::String picture_str,Core::Vector2 position,Core::Vector2 size,Core::Vector2 zoompoint = Core::Vector2(0,0),int add = 1);
		void render(by_ptr(UIRender) ui_render);
		void Update();
		void InitTabShow(Core::String str);

		void SetPostion(Core::Vector2 postion);
		void SetPostion(F32 x, F32 y);
		Core::Vector2 GetPostion();

		void SetSize(Core::Vector2 size);
		void SetSize(F32 width, F32 high);
		void SetZoom(F32 zoom);
		void SetTextuv(Core::Rectangle Textuv);
		void SetColor(Core::ARGB color);
		void SetZoom(Core::Vector2 zoom);
		void SetZoomPoint(Core::Vector2 point);
		void Settimespeed(F32 time);
		void Settotletimes(F32 time);
		void SetMaxtime(F32 time);
		void Setretaintime(F32 time);
		void Setplaytimes(F32 time);
		void SetMaxzoom(F32 zoom);
		void SetMinzoom(F32 zoom);
		void SetSums(int sum);
		void SetWhich(int which);
		void Setrepetition(bool value);
		void Setplay(bool value);
		void SetAdd(int add);
		void SetBegintimes(F32 time);
		void SetEndtimes(F32 time);
		void OnPlaystop();
	protected:


	private:
		sharedc_ptr(Texture2D)				ui_picture;
		Core::Vector2						m_positon;
		Core::Vector2						m_size;
		Core::Vector2						m_zoomPoint;
		Core::Vector2						m_zoom;
		Core::Rectangle						m_textureUV;
		Core::ARGB							m_color;
		F32									m_timespeed;
		F32									m_totletimes;
		F32									m_Maxtime;
		F32									m_retaintime;
		F32									m_playtimes;
		F32									m_Maxzoom;
		F32									m_Minzoom;
		int									m_Sums;
		int									m_which;
		bool								m_repetition;
		bool								m_play;
		F32									m_timetote;
		int									m_Add;
		int									m_beginAlve;
		int									m_endAlve;
		F32									m_begintimes;
		F32									m_endtimes;
	};
}