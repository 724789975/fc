#include "pch.h"

namespace Client
{

	typedef IDelegate<void (*)(const NxSweepQueryHit &)> UserCallback;

	static int MoveCapsule(NxCapsule & capsule, NxSweepQueryHit & hit, NxVec3 direction, uint group_id, uint group_id1, float half_length, Vector3& result_vec)
	{

		NxVec3 current_pos  = (capsule.p0 + capsule.p1) / 2;
		NxVec3 target_pos = current_pos + direction;
		NxVec3 p0_offset = capsule.p0 - current_pos;
		NxVec3 p1_offset = capsule.p1 - current_pos;

		// Compute current direction
		NxVec3 current_dir = target_pos - current_pos;

		float len = current_dir.magnitude();
		if (len < 0.001f)	
			return 0;

		current_dir /= len;

		if((current_dir | direction) <= 0.0f)
			return 0;;

		//hit.t = 0;
		//capsule.p0 = current_pos + p0_offset;
		//capsule.p1 = current_pos + p1_offset;
		float up_offset = 0.02f;
		int iter_count = 5;
		while(iter_count --)
		{
			uint result = gPhysxScene->linearCapsuleSweep(capsule, current_dir * len, NX_SF_STATICS | NX_SF_DYNAMICS, NULL, 1, &hit, NULL, group_id, NULL);
			if(result == 0)
			{
				capsule.p0 = target_pos + p0_offset;
				capsule.p1 = target_pos + p1_offset;
				result = gPhysxScene->linearCapsuleSweep(capsule, NxVec3(0, -1.f, 0) * 1.2f, NX_SF_STATICS | NX_SF_DYNAMICS, NULL, 1, &hit, NULL, group_id1, NULL);
				if(result != 0)
				{
					target_pos.y = hit.point.y + half_length;
					result_vec = Vector3(target_pos.x, target_pos.y, target_pos.z);
					result_vec.y += 0.02f;
					result_vec.y -= half_length;
					
					return 1;
				}
				
				return 0;
			
			}
			else
			{
				DummyObject* pDummy = DummyObject::FromNxActor(hit.hitShape->getActor());
				if(pDummy)
				{
					return 0;
					//return 2;
				}
				else
				{
					capsule.p0.y += up_offset;
					capsule.p1.y += up_offset;
					target_pos.y += up_offset;
				}
			}
		}
		

		return 0;
	}

	TurretInfo::TurretInfo():fire_interval(1.f)
							,check_range(20.f)
							,angle_speed(PI/4)
	{

	}


	///Gunturret----------------
	MachineGunTurret::MachineGunTurret():turret_rotation(Quaternion::kIdentity)
										,target_id(0)
										,gun_bh_joint_id(0)
										,gun_blend_timer(-1.f)
										,gun_blend_over(false)
										,fire_interval_timer(-1.f)
										,turret_start_animation_timer(-1.f)
										,turret_freeze_animation_timer(-1.f)
										,idle_3D_sound(NULL)
										,search_3D_sound(NULL)
										,move_timer(-1.f)
										,recover_range(-1.f)
										,recover_check_interval(-1.f)
										,recover_per_count_life(0)
										,recover_timer(-1.f)
										,recover_per_percent_ammo(0)
										,dir_type(MOVE_DIR_NONE)
										,need_sync_move(false)
						//				,can_move(true)
	{
	}

	/// destructor
	MachineGunTurret::~MachineGunTurret()
	{
		if (idle_3D_sound)
		{
			idle_3D_sound->stop(true);

		}	

		if (search_3D_sound)
		{
			search_3D_sound->stop(true);
		}
	}

	tempc_ptr(Pose) MachineGunTurret::GetPose()
	{
		if(turret_animation)
		{
			tempc_ptr(Pose) animation_pose = turret_animation->GetPose();
			if (animation_pose)
				return animation_pose;
		}

		return pose;
	}

	bool MachineGunTurret::GetTurretJointInfo(const Core::Identifier & joint_name, Vector3 * position, Quaternion * rotation)
	{
		if (turret_skeleton)
		{
			int joint_id = turret_skeleton->GetJointId(joint_name);

			if (joint_id >= 0)
			{
				const Transform & transform = GetPose()->GetJointModelPose(joint_id);
				if (position)
					*position = GetTurretPosition() + transform.position * GetTurretRotation();

				if (rotation)
					*rotation = transform.rotation * GetTurretRotation();

				return true;
			}
		}

		return false;
	}

	void MachineGunTurret::SetAmmoCount(int count)
	{
		if(count > turret_info.max_ammo_count)
		{
			ammo_count = turret_info.max_ammo_count;
		}
		else
		{
			ammo_count = count;
		}
	}

	int MachineGunTurret::GetAmmoCount()
	{
		return ammo_count;
	}

	bool MachineGunTurret::AmmoIsFull()
	{
		return (ammo_count == turret_info.max_ammo_count);
	}

	void MachineGunTurret::PlayAction(const Core::Identifier & key, float blend_time, bool loop)
	{
		//DummyObject::PlayAction(key, blend_time, loop);

		if (turret_animation)
		{
			turret_animation->PlayAction(key, blend_time, loop);
		}
	}

	bool MachineGunTurret::Create(by_ptr(DummyObjectInfo) info, const DummyBaseCreateInfo& create_info)
	{
		dummyobjectinfo = info;
		dummyobjectinfo->destory_distance = create_info.distance;
		owner_id = info->owner_id;
		turret_info.attack_base_info.base_damage = create_info.base_damage;
		turret_info.attack_base_info.damage_modifier = create_info.damage_modifier;
		turret_info.attack_base_info.range_start = create_info.range_start;
		turret_info.attack_base_info.range_end = create_info.range_end;
		turret_info.attack_base_info.range_modifier = create_info.range_modifier;

		turret_info.angle_speed = DEG2RAD * create_info.angle_speed;
		turret_info.check_angle = create_info.check_angle;
		turret_info.check_range = create_info.check_range;
		turret_info.fire_interval = create_info.fire_interval;
		turret_info.max_ammo_count = create_info.max_ammo_count;

		recover_range = create_info.recover_range;
		recover_check_interval = create_info.recover_check_interval;
		recover_per_count_life = create_info.recover_per_count_life;
		recover_per_percent_ammo = create_info.recover_per_percent_ammo;
		recover_per_minus_ammo = create_info.recover_per_minus_ammo;

		freeze_count = create_info.freeze_count;
		respawn_time = create_info.respawn_time;

		type = DUMMY_MACHINE_TURRENT;
		m_szResKey =create_info.tower_key;
		return true;
	}


	void MachineGunTurret::Draw(Primitive::DrawType drawtype, bool immediate)
	{
		if(!turret_mesh)
			return;

		turret_mesh->SetPosition(turret_position);
		turret_mesh->SetRotation(turret_rotation);

		turret_mesh->Draw(drawtype, immediate);
		DummyObject::Draw(drawtype, immediate);
		if (build_particle)
			build_particle->Draw();
	}


	Core::Quaternion MachineGunTurret::GetTurretRotation()
	{
		return turret_rotation;
	}

	Core::Vector3 MachineGunTurret::GetTurretPosition()
	{
		return turret_position;
	}

	void MachineGunTurret::Initialize()
	{
		DummyObject::Initialize();
		
		turret_position = Vector3(0, -10000.f, 0);
		turret_rotation = Quaternion::kIdentity;

		ammo_count = turret_info.max_ammo_count;
		
		if(dummyobjectinfo->turret_fire_particle.Length() > 0)
		{
			//static const char szTeam[2] = {'r', 'b'};
			//CStrBuf<256> key;
			//key.format("%s_%c", dummyobjectinfo->turret_fire_particle.Str(), szTeam[player->GetTeam() & 1]);
			turret_fire_particle = ptr_new ParticleSystem(dummyobjectinfo->turret_fire_particle);
		}
		if (dummyobjectinfo->build_particle.Length() > 0)
		{
			build_particle =  ptr_new ParticleSystem(dummyobjectinfo->build_particle);
			build_particle->SetEnable(true);
		}

		if (!idle_3D_sound)
		{
			FMOD_VECTOR vel = {0, 0, 0};
			String str;
			if (dummyobjectinfo->dummy_sound_key.Length() > 0)
				str = String::Format("bj/weapon/3d/%s/idle", dummyobjectinfo->dummy_sound_key.Str() );
			else
				str = String::Format("bj/weapon/3d/machinegun/machinegun_idle");
			idle_3D_sound = FmodSystem::GetEvent(str.Str());
		}
		else
		{
			idle_3D_sound->stop(true);
		}		

		if (!search_3D_sound)
		{
			FMOD_VECTOR vel = {0, 0, 0};
			String str;
			if (dummyobjectinfo->dummy_sound_key.Length() > 0)
				str = String::Format("bj/weapon/3d/%s/warning", dummyobjectinfo->dummy_sound_key.Str() );
			else
				str = String::Format("bj/weapon/3d/machinegun/machinegun_alert");
			search_3D_sound =  FmodSystem::GetEvent(str.Str());
		}
		else
		{
			search_3D_sound->stop(true);
		}
	}


	void MachineGunTurret::InitializeMesh()
	{
		DummyObject::InitializeMesh();

		bool hasMesh = false;
		turret_mesh = ptr_new CharacterMesh(MESH_KEY_WEAPON);
		if (dummyobjectinfo && turret_mesh)
		{
			for (U32 i = 0; i < MESH_LOD_LEVEL; i++)
			{
				CharacterInfo::MeshSet::Enumerator it(dummyobjectinfo->turret_mesh_set[i]);

				while (it.MoveNext())
				{
					turret_mesh->AddPrimitive(it.Key(), it.Value(), i);
					hasMesh = true;
				}
			}
		}
		if (!hasMesh)
		{
			turret_mesh = NullPtr;
		}
	}

	void MachineGunTurret::UpdateAnimation(float frame_time)
	{
		DummyObject::UpdateAnimation(frame_time);
		if (turret_animation)
		{
			turret_animation->Update(frame_time);
			if (turret_mesh)
			{
				turret_mesh->pose = turret_animation->GetPose();
				turret_mesh->Update();
			}
		}

		GetDummyJointInfo("Gun_BH", &turret_position, NULL);

		if(build_particle)
		{
			build_particle->SetPosition(turret_position);
			build_particle->SetRotation(turret_rotation);
			build_particle->Update(frame_time);
		}

		if(turret_fire_particle)
		{
			Vector3 fire_position;
			Quaternion fire_rotation;
			GetTurretJointInfo("Gun_Fire", &fire_position, &fire_rotation);

			turret_fire_particle->SetPosition(fire_position);
			turret_fire_particle->SetRotation(fire_rotation);
		}

		//�ϰ�����������λ����
		if(protector_actor)
		{
			Vector3 pos_projector;
			Quaternion q_projector;
			if(GetUpBodyJointInfo("Gun_EC", &pos_projector, &q_projector))
			{
				protector_actor->setGlobalPosition((const NxVec3 &) (pos_projector));
				protector_actor->setGlobalOrientationQuat((const NxQuat &) (q_projector));
			}
		}
	}

	void MachineGunTurret::UpdateBaseRotation()
	{
		if(dummy_skeleton && dummy_animation)
		{
			gun_bh_joint_id = dummy_skeleton->GetJointId("Gun_BH");
			if(dummy_animation)
			{
				DummyObject::PlayAction("idle", 0.1f,true);
				GetDummyJointInfo("Gun_BH", NULL, &idle_base_quaternion);
				DummyObject::StopAction();
			}
		}

		turret_rotation = GetRotation();

		if(dummyobjectinfo->start_animation.Length() != 0 && dummyobjectinfo->start_animation_playtime > 0.f && !need_stepfather)
		{
			DummyObject::PlayAction(dummyobjectinfo->start_animation,0.001f, false);
			PlayAction(dummyobjectinfo->start_animation,0.01f,false);
			turret_start_animation_timer = dummyobjectinfo->start_animation_playtime;
		}
		else
		{
			DummyObject::PlayAction("idle",0.2f, true);
			PlayAction("idle",0.2f,true);
		}

	}

	void MachineGunTurret::SetAnimationSet()
	{
		DummyObject::SetAnimationSet();


		turret_skeleton = RESOURCE_LOAD(dummyobjectinfo->turret_skeleton, false, Skeleton);
		if (turret_skeleton)
		{
			turret_animation = ptr_new AnimationNodeCustom(turret_skeleton);
		}

		

		if (turret_animation)
		{
			sharedc_ptr(AnimationSetRes) res = RESOURCE_GET_BYTYPE(RESOURCE_NAME(ANIMATION_KEY_PROP_CHARACTER, dummyobjectinfo->turret_animationset), ANIMATIONSET_TYPE, AnimationSetRes);
			if (res)
			{
				res->Load(false);
				sharedc_ptr(AnimationSet) animset = res->GetAnimationSet();
				if (gLevel->animation_manager)
					gLevel->animation_manager->AddAnimationSetRes(res->GetKey(), res);

				Array<Core::Identifier> animation_keylist = animset->GetAnimationSetKeyList();
				sharedc_ptr(AnimationNodeList) node_list = ptr_new AnimationNodeList();
				for(uint i = 0; i < animation_keylist.Size(); i++)
				{
					sharedc_ptr(AnimationNodePose) node_pose = ptr_new AnimationNodePose(turret_skeleton);
					node_pose->SetAnimation(animation_keylist[i], animset);
					node_list->AddNode(animation_keylist[i], node_pose);
				}
				turret_animation->SetAnimationSet(animset);
				turret_animation->SetAnimationNode(node_list);
				StopAction();

			}
		}
	}

	byte MachineGunTurret::SearchEnemy()
	{
		tempc_ptr(Character) owner = gLevel->GetCharacter(owner_id);
		if(!owner)
			return NULL;

		const Core::Array<sharedc_ptr(Character)>& characters = gLevel->GetCharacters();
		Array<int> range_enemy;
		for (uint i = 0; i < characters.Size(); i++)
		{
			tempc_ptr(Character) c = characters[i];
			
			if(!need_stepfather)
			{
				if(c->GetTeam() != owner->GetTeam() && !c->IsDied() && c->GetTeam() < 2 && Length(c->GetPosition() - GetTurretPosition()) < turret_info.check_range)
				{
					range_enemy.Add(c->uid);
				}
			}
			else
			{
				if(c->GetTeam() != owner_team && !c->IsDied() && c->GetTeam() < 2 && Length(c->GetPosition() - GetTurretPosition()) < turret_info.check_range)
				{
					range_enemy.Add(c->uid);
				}
			}
		}

		tempc_ptr(Character) c = gLevel->GetPlayer();
		if(need_stepfather)
		{
			if(c->GetTeam() != owner_team && !c->IsDied() && c->GetTeam() < 2 && Length(c->GetPosition() - GetTurretPosition()) < turret_info.check_range)
			{
				range_enemy.Add(c->uid);
			}
		}
		
		while(range_enemy.Size())
		{
			int pos = rand()%range_enemy.Size();
			int uid = range_enemy[pos];
			if(CheckIsInArea(uid))
			{
				return uid;
			}

			range_enemy.Remove(uid);
		}
				

		return NULL;

		//if(CheckIsInArea(owner_id))
		//{
		//	return owner_id;
		//}
		//else
		//{
		//	return NULL;
		//}
		//return NULL;
	}

	bool MachineGunTurret::CheckIsInArea(byte t_id)
	{
		tempc_ptr(Character) character = gLevel->GetCharacter(t_id);
		if(character && character->GetTeam() < 2 && !character->IsDied() && Length(character->GetPosition() - GetTurretPosition()) < turret_info.check_range)
		{
			Quaternion base_rotation = GetRotation();
			Vector3 base_dir = Vector3(0, 0, -1.f) * base_rotation;


			Vector3 head_position;
			//character->GetThirdPerson().GetJointInfo("head", head_position, head_rot);
			head_position = character->GetPosition() + Vector3(0, character->GetControllerHeight(), 0);

			Vector3 gun_fire_position;
			GetTurretJointInfo("Gun_Fire", &gun_fire_position, NULL);
			
			Vector3 target_dir = head_position - gun_fire_position;
			float length = target_dir.Length();
			target_dir.Normalize();


			
			if(Dot(target_dir, base_dir) > 0.f)
			{
				NxRay ray;
				ray.orig = (const NxVec3 &)gun_fire_position;
				ray.dir = (const NxVec3 &)target_dir;

				NxRaycastHit hit;

				uint group_id = 0;
				if(gLevel->GetPlayer() && character->uid == gLevel->GetPlayer()->uid)
				{
					group_id |= 1 << PhysxSystem::kPlayer;
				}
				else
				{
					group_id |= 1 << (character->GetTeam() + PhysxSystem::kGroupStart);
				}
				
				group_id |= 1 << PhysxSystem::kStatic;
				group_id |= 1 << PhysxSystem::kStaticRaycast;
				group_id |= 1 << PhysxSystem::kGroupVehicle;

				NxShape* shape = gPhysxScene->raycastClosestShape(ray, NX_ALL_SHAPES, hit, group_id, turret_info.check_range);

				if (shape)
				{
					NxActor& actor = shape->getActor();

					tempc_ptr(Character) p = Character::FromNxActor(actor);
					if(p && p->uid == t_id)
					{
						return true;
					}
					else if(hit.distance >= length)
					{
						return true;
					}
				}
				else
				{
					return true;
				}
			}	
		}
		return false;
	}
 
	void MachineGunTurret::UpdateSyncData(float frame_time)
	{
		if (sync_data.Empty())
			return;

		Vector3	vel;

		Vector3 data_position;
		Quaternion data_rotation;
		Vector3 data_base_position;

		while (sync_data.Size() > 1 && (sync_data[1].time <= sync_time))
			sync_data.PopFront();

		if(dummy_animation->IsActionPlaying() && strcmp(dummy_animation->node_action->GetAnimationKey() ,"change") == 0)
		{
			sync_time += frame_time;
			while(sync_data.Size() > 1)
			{
				sync_data.PopFront();
			}
			return;
		}

		if (sync_data.Size() > 1)
		{
			DummySyncData & data1 = sync_data[0];
			DummySyncData & data2 = sync_data[1];

			float s = Clamp((sync_time - data1.time) / (data2.time - data1.time), 0, 1);

			Vector3 data1_position, data2_position;
			Quaternion data1_rotation, data2_rotation;
			Vector3 data1_baseposition, data2_base_position;

			ReadRotationFP(data1.rotation, data1_rotation);
			ReadRotationFP(data2.rotation, data2_rotation);

			ReadVector3FP(data1.position, data1_position);
			ReadVector3FP(data2.position, data2_position);

			ReadVector3FP(data1.base_position, data1_baseposition);
			ReadVector3FP(data2.base_position, data2_base_position);
			

			Core::Slerp(data_rotation, data1_rotation, data2_rotation, s);
			Core::Lerp(data_position, data1_position, data2_position, s);
			Core::Lerp(data_base_position, data1_baseposition, data2_base_position, s);

			// update time
			float delay_time = sync_data.Back().time - sync_time;

			if (delay_time > 0.1f)
				frame_time *= 1 + (delay_time - 0.1f);

			sync_time += frame_time;
			
			ammo_count = data1.ammo_count;
			hp = data1.hp;

			freeze = (!data1.freeze == 0);
			respawn_time = data1.respawn_time;
			freeze_count = data1.freeze_count;
		}
		else
		{
			ReadVector3FP(sync_data[0].position, data_position);
	
			ReadRotationFP(sync_data[0].rotation, data_rotation);

			ReadVector3FP(sync_data[0].base_position, data_base_position);

			vel = Vector3::kZero;
			sync_time = sync_data[0].time;
			ammo_count = sync_data[0].ammo_count;
			hp = sync_data[0].hp;

			freeze = (!sync_data[0].freeze == 0);
			respawn_time = sync_data[0].respawn_time;
			freeze_count = sync_data[0].freeze_count;
		}

		turret_position = data_position;
		turret_rotation = data_rotation;
		SetPosition(data_base_position);

		if(!turret_animation->IsActionPlaying())
		{
			PlayAction("idle",0.2f,true);
			DummyObject::PlayAction("idle",0.2f, true);
		}

		if(move_timer > 0.f)
		{
			move_timer -= frame_time;
			if(move_timer <= 0.f)
			{
				dir_type = MOVE_DIR_NONE;
				DummyObject::PlayAction("idle",0.05f, true);
			}
		}

	}

	void MachineGunTurret::AddSyncData(byte time, const char* buffer, int size)
	{
		float t = sync_data.Back().time;
		DummySyncData sync;
		readUserData(buffer, size, 0, sync);
		sync.time = t + (float)time / 255.f;

		sync_data.PushBack(sync);

		if(sync.dir_move_type != MOVE_DIR_NONE)
		{
			move_timer = dummyobjectinfo->move_keep_time;
			switch(sync.dir_move_type)
			{
			case MOVE_DIR_FORWARD:
				{
					DummyObject::PlayAction("runforward",0.1f, true);
				}
				break;
			case MOVE_DIR_LEFT:
				{
					DummyObject::PlayAction("runleft",0.1f, true);
				}
				break;
			case MOVE_DIR_RIGHT:
				{
					DummyObject::PlayAction("runright",0.1f, true);
				}
				break;
			case MOVE_DIR_BACK:
				{
					DummyObject::PlayAction("runback",0.1f, true);
				}
				break;
			}
			FMOD_VECTOR vel = {0, 0, 0};
			String str = String::Format("bj/weapon/3d/%s/walk", dummyobjectinfo->tower_key.Str());
			FmodSystem::Play3DEvent(str.Str(),(const FMOD_VECTOR &)GetPosition(),vel);
		}
	}

	void MachineGunTurret::BuildSyncString()
	{
		DummySyncData sync;
		sync.time = 0.f;
		WriteVector3FP(sync.position, turret_position);
		WriteRotationFP(sync.rotation, turret_rotation);
		WriteVector3FP(sync.base_position, position);

		sync.ammo_count = ammo_count;
		sync.hp = hp;
		sync.freeze_count = freeze_count;
		sync.freeze = freeze ? 1 : 0;
		sync.respawn_time = respawn_time;

		if(need_sync_move)
		{
			sync.dir_move_type = dir_type;
			need_sync_move = false;
		}
		else
		{
			sync.dir_move_type = MOVE_DIR_NONE;
		}
		sync_data_length = writeUserData(sync_buffer, SYNC_BUFFER_SIZE, sync);

		sync_dirty = true;
	}

	void MachineGunTurret::FireCheck()
	{
		if(owner_id)
		{
			tempc_ptr(Character) character = gLevel->GetCharacter(owner_id);
			if(!character || (character->IsDied() && !need_stepfather))
				return;
		}

		tempc_ptr(Character) character = gLevel->GetCharacter(target_id);
		if(!character || character->isghost)
			return;
		Vector3 head_position;
		//Quaternion head_rot;
		//character->GetThirdPerson().GetJointInfo("head", head_position, head_rot);

		head_position = character->GetPosition() + Vector3(0, character->GetControllerHeight(), 0);

		Vector3 gun_fire_position;
		GetTurretJointInfo("Gun_Fire", &gun_fire_position, NULL);

		Vector3 target_dir = head_position - gun_fire_position;
		float length = target_dir.Length();
		target_dir.Normalize();

		NxRay ray;
		ray.orig = (const NxVec3 &)gun_fire_position;
		ray.dir = (const NxVec3 &)Normalize(target_dir);

		NxRaycastHit hit;

		uint group_id = 0;
		group_id |= 1 << PhysxSystem::kStatic;
		group_id |= 1 << PhysxSystem::kStaticRaycast;
		group_id |= 1 << PhysxSystem::kGroupVehicle;

		if(gLevel->GetPlayer() && character->uid == gLevel->GetPlayer()->uid)
		{
			group_id |= 1 << PhysxSystem::kPlayer;
		}
		else
		{
			group_id |= 1 << (character->GetTeam() + PhysxSystem::kGroupStart);
		}

		NxShape* shape = gPhysxScene->raycastClosestShape(ray, NX_ALL_SHAPES, hit, group_id, turret_info.check_range);

		if (shape)
		{
			NxActor& actor = shape->getActor();

			tempc_ptr(Character) p = Character::FromNxActor(actor);
			if((p && p->uid == target_id) )
			{
				if(gGame->channel_connection)
				{
					HitMessage message;
					message.distance = hit.distance;
					message.part = kCharacterPartHead;
					message.uid = target_id;
					message.position = head_position;
					gGame->channel_connection->GunTowerShoot(dummyobjectinfo->dummy_id, message,turret_info.attack_base_info);

					Vector3 target(hit.worldImpact.x, hit.worldImpact.y, hit.worldImpact.z);
					Vector3 normal(hit.worldNormal.x, hit.worldNormal.y, hit.worldNormal.z);
					p->ResponseHit(head_position, target, normal, kCharacterPartHead, kWeaponTypeGunTowerBuilder);
				}
			}
			else if(length <= hit.distance)
			{
				if(gGame->channel_connection)
				{
					HitMessage message;
					message.distance = hit.distance;
					message.part = kCharacterPartHead;
					message.uid = target_id;
					message.position = head_position;
					gGame->channel_connection->GunTowerShoot(dummyobjectinfo->dummy_id, message,turret_info.attack_base_info);

					Vector3 target(hit.worldImpact.x, hit.worldImpact.y, hit.worldImpact.z);
					Vector3 normal(hit.worldNormal.x, hit.worldNormal.y, hit.worldNormal.z);
					character->ResponseHit(head_position, target, normal, kCharacterPartHead, kWeaponTypeGunTowerBuilder);
				}
			}
		}

	}

	void MachineGunTurret::Fire(byte t_id, byte part)
	{
		tempc_ptr(Character) character = gLevel->GetCharacter(t_id);
		if(!character)
			return;

		Vector3 head_position;
		Quaternion head_rot;
		character->GetThirdPerson().GetJointInfo("head", head_position, head_rot);

		Vector3 gun_fire_position;
		GetTurretJointInfo("Gun_Fire", &gun_fire_position, NULL);

		Vector3 target_dir = head_position - gun_fire_position;
		float distance = target_dir.Length();
		target_dir.Normalize();

		if(distance > 0.05f)
			gLevel->bullet_manager->Add(gun_fire_position, Quaternion(Vector3(0, 0, -1), target_dir), distance, character->GetTeam(),false);

		PlayAction("shoot", 0.1f, false);
		if(turret_fire_particle)
			gLevel->AddParticle(turret_fire_particle);

		FMOD_VECTOR vel = {0, 0, 0};
		String str;
		if (dummyobjectinfo->dummy_sound_key.Length() > 0)
			str = String::Format("bj/weapon/3d/%s/fire", dummyobjectinfo->dummy_sound_key.Str() );
		else
			str = String::Format("bj/weapon/3d/%s/fire", dummyobjectinfo->tower_key.Str());
		FmodSystem::Play3DEvent(str.Str(),(const FMOD_VECTOR &)GetPosition(),vel);
	}

	void MachineGunTurret::Die()
	{
		tempc_ptr(Character) c = gLevel->GetCharacter(owner_id);
		if (c)
		{
			c->tower_gun_count -=1;
			if (tempc_ptr(GunTowerBuilder) w = ptr_dynamic_cast<GunTowerBuilder> (c->GetWeaponById(0)))
			{
				w->SetAmmoCount(GetAmmoCount());
			}
			if (tempc_ptr(GunTowerBuilderPlus) w = ptr_dynamic_cast<GunTowerBuilderPlus> (c->GetWeaponById(0)))
			{
				w->DestroyTower(type, m_szResKey);
			}

		}
		DummyObject::Die();

		if(turret_fire_particle)
			gLevel->RemoveParticle(turret_fire_particle);
		if (build_particle)
			build_particle = NullPtr;

		if (idle_3D_sound)
		{
			idle_3D_sound->stop(true);

		}	
		
		if (search_3D_sound)
		{
			search_3D_sound->stop(true);
		}

		if (RoomOption::kEditMode != gLevel->game_type)
		{
			FMOD_VECTOR vel = {0, 0, 0};
			String str;
			if (dummyobjectinfo->dummy_sound_key.Length() > 0)
				str = String::Format("bj/weapon/3d/%s/explode", dummyobjectinfo->dummy_sound_key.Str() );
			else
				str = String::Format("bj/weapon/3d/machinegun/machinegun_explode");
			FmodSystem::Play3DEvent(str.Str(),(const FMOD_VECTOR &)GetPosition(),vel);
		}
	}

	void MachineGunTurret::UpdateSound()
	{
		if(isdead)
			return;
		if(!sync_master)
		{
			if (idle_3D_sound)
			{
				FMOD_EVENT_STATE audio_state = FMOD_EVENT_DEFAULT;
				idle_3D_sound->getState(&audio_state);
				if ((audio_state & FMOD_EVENT_STATE_PLAYING) == 0)
				{
					FMOD_VECTOR vel = {0, 0, 0};
					idle_3D_sound->set3DAttributes(&(const FMOD_VECTOR &)GetPosition(), &vel);
					idle_3D_sound->start();
				}
			}
		}
		else
		{
			if(target_id == 0)
			{
				if(turret_start_animation_timer < 0.f)
				{
					search_3D_sound->stop(true);

					FMOD_EVENT_STATE audio_state = FMOD_EVENT_DEFAULT;
					idle_3D_sound->getState(&audio_state);
					if ((audio_state & FMOD_EVENT_STATE_PLAYING) == 0)
					{
						FMOD_VECTOR vel = {0, 0, 0};
						idle_3D_sound->set3DAttributes(&(const FMOD_VECTOR &)GetPosition(), &vel);
						idle_3D_sound->start();
					}
				}
			}
			else
			{
				idle_3D_sound->stop(true);

				FMOD_EVENT_STATE audio_state = FMOD_EVENT_DEFAULT;
				search_3D_sound->getState(&audio_state);
				if ((audio_state & FMOD_EVENT_STATE_PLAYING) == 0)
				{
					FMOD_VECTOR vel = {0, 0, 0};
					search_3D_sound->set3DAttributes(&(const FMOD_VECTOR &)GetPosition(), &vel);
					search_3D_sound->start();
				}
			}
		}
		if(idle_3D_sound)
		{
			FMOD_EVENT_STATE audio_state = FMOD_EVENT_DEFAULT;
			idle_3D_sound->getState(&audio_state);
			if ((audio_state & FMOD_EVENT_STATE_PLAYING) != 0)
			{
				FMOD_VECTOR vel = {0, 0, 0};
				idle_3D_sound->set3DAttributes(&(const FMOD_VECTOR &)GetPosition(), &vel);
				idle_3D_sound->start();
			}
		}
	}

	void MachineGunTurret::UpdateLogic(float frame_time)
	{
		if(!gLevel)
			return;

		tempc_ptr(Character) character = gLevel->GetCharacter(owner_id);
		//��ǹ�������һ����Χ���Ա�
		if (gLevel && (gLevel->game_type != RoomOption::kEditMode) && character && Length(character->GetPosition() - GetPosition()) > dummyobjectinfo->destory_distance && !need_stepfather)
		{
			gGame->channel_connection->RequestDummyObjectDestory(dummyobjectinfo->dummy_id);
		}

		if(freeze)
		{
			if(strcmp(dummy_animation->node_action->GetAnimationKey() ,"die") != 0)
			{
				dummy_animation->PlayAction("die", 0.1f, false, 0, true);
				turret_animation->PlayAction("die", 0.1f, false, 0, true);
			}

			return;
		}

		if(turret_freeze_animation_timer > 0.f)
		{
			turret_freeze_animation_timer -= frame_time;
			
			return;
		}

		if(turret_start_animation_timer > 0.f)
		{
			turret_start_animation_timer -= frame_time;
			if(turret_start_animation_timer <= 0.f && RoomOption::kEditMode != gLevel->game_type)
			{

				FMOD_VECTOR vel = {0, 0, 0};
				String str = String::Format("bj/weapon/3d/machinegun/machinegun_setup");
				FmodSystem::Play3DEvent(str.Str(),(const FMOD_VECTOR &)GetPosition(),vel);

				DummyObject::PlayAction("idle",0.2f, true);
				PlayAction("idle",0.2f,true);
			}
			return;
		}

		if((is_on_moving || move_timer > 0.f))
		{

			if(is_on_moving)
			{
				switch(dir_type)
				{
				case MOVE_DIR_FORWARD:
					{
						DummyObject::PlayAction("runforward",0.1f, true);
					}
					break;
				case MOVE_DIR_LEFT:
					{
						DummyObject::PlayAction("runleft",0.1f, true);
					}
					break;
				case MOVE_DIR_RIGHT:
					{
						DummyObject::PlayAction("runright",0.1f, true);
					}
					break;
				case MOVE_DIR_BACK:
					{
						DummyObject::PlayAction("runback",0.1f, true);
					}
					break;
				}
				is_on_moving = false;
			}



			move_timer -= frame_time;

			Vector3 delta = move_dir * frame_time * dummyobjectinfo->move_speed;
			delta.y = delta.Length();
			//delta.y = 0.f;
			uint group_id = 0;
			group_id |= 1 << PhysxSystem::kStatic;
			group_id |= 1 << PhysxSystem::kStaticCollisionWithPerson;
			group_id |= 1 << PhysxSystem::kController;
			group_id |= 1 << PhysxSystem::kGroupVehicle;
			group_id |= 1 << PhysxSystem::kGroupStart;
			group_id |= 1 << PhysxSystem::kGroupEnd;
			group_id |= 1 << PhysxSystem::kPlayer;
			uint group_id1 = 0;
			group_id1 |= 1 << PhysxSystem::kStatic;
			group_id1 |= 1 << PhysxSystem::kStaticCollisionWithPerson;
			group_id1 |= 1 << PhysxSystem::kController;
			group_id1 |= 1 << PhysxSystem::kGroupVehicle;
			tempc_ptr(Character) character = gLevel->GetCharacter(dummyobjectinfo->owner_id);

			if(character)
			{
				int team = character->GetTeam();
				group_id |= 1 << (PhysxSystem::kStaticCollisionWithGateTeam1 + team);
			}

			NxCapsule capsule;
			capsule.p0 = NxVec3(position.x, position.y + dummyobjectinfo->coll_box_size.x, position.z);
			capsule.p1 = capsule.p0 + NxVec3(0, dummyobjectinfo->coll_box_size.y, 0);
			capsule.radius = dummyobjectinfo->coll_box_size.x;

			NxSweepQueryHit hit;
			Vector3 result;
			int flag = MoveCapsule(capsule, hit, NxVec3(delta.x, delta.y, delta.z), group_id, group_id1, dummyobjectinfo->coll_box_size.x + dummyobjectinfo->coll_box_size.y / 2, result);
			if(flag == 1)
			{
				SetPosition(result);
			}
			else if(flag == 0)
			{
				move_timer = -1.f;
			}
			else if(flag == 2)
			{
				gGame->channel_connection->RequestDummyObjectDestory(dummyobjectinfo->dummy_id);
				move_timer = -1.f;
			}
			//else if(flag == 3)
			//{
			//	move_timer = -1.f;
			////	can_move = false;
			//}
			
			if(move_timer < 0.f)
			{
				dir_type = MOVE_DIR_NONE;
				DummyObject::PlayAction("idle",0.05f, true);
				if (!gLevel->IsMachineGunTurretArea(GetPosition()))
				{
					gGame->channel_connection->RequestDummyObjectDestory(dummyobjectinfo->dummy_id);
				}
			}

		}
		else
		{
			recover_timer -= frame_time;

			if(!need_stepfather && recover_timer < 0.f && ammo_count >= recover_per_minus_ammo && (recover_per_count_life > 0 || recover_per_percent_ammo > 0))
			{
				recover_timer = recover_check_interval;
				ammo_count -= recover_per_minus_ammo;

				tempc_ptr(Character) c_owner = gLevel->GetCharacter(dummyobjectinfo->owner_id);
				if(!c_owner)
					return;

				float recover_range_sqr = recover_range * recover_range;


				if(gLevel->GetPlayer())
				{
					float len_sqr = (gLevel->GetPlayer()->GetPosition() - GetPosition()).LengthSqr();
					if(len_sqr < recover_range_sqr)
					{
						if(gGame->channel_connection)
						{
							gGame->channel_connection->CharacterHeal(gLevel->GetPlayer()->uid, recover_per_count_life, recover_per_percent_ammo);
						}
					}
				}

				const Core::Array<sharedc_ptr(Character)>& characters = gLevel->GetCharacters();

				for (uint i = 0; i < characters.Size(); i++)
				{
					tempc_ptr(Character) c = characters[i];

					if(c->GetTeam() == c_owner->GetTeam())
					{
						float len_sqr = (c->GetPosition() - GetPosition()).LengthSqr();
						if(len_sqr < recover_range_sqr)
						{
							if(gGame->channel_connection)
							{
								gGame->channel_connection->CharacterHeal(c->uid, recover_per_count_life, recover_per_percent_ammo);
							}
						}
					}
				}
			}

			if(!turret_animation->IsActionPlaying())
			{
				PlayAction("idle",0.2f,true);
			}
			
 
			if(IsSyncMaster() && owner_id && turret_mesh)
			{
				fire_interval_timer -= frame_time;

				bool has_target = target_id == 0 ? false : true;
				if(target_id != 0)
				{
					if(!CheckIsInArea(target_id))
					{
						target_id = 0;
					}
				}

				if(target_id == 0)
					target_id = SearchEnemy();				

				if(target_id != 0)
				{
					gun_blend_over = false;
					gun_blend_timer = -1.f;
					tempc_ptr(Character) character = gLevel->GetCharacter(target_id);
					{
						Vector3 current_dir = Vector3(0, 0, -1.f) * turret_rotation;
						Vector3 gun_fire_position;
						GetTurretJointInfo("Gun_Fire", &gun_fire_position, NULL);

						Vector3 head_position;
						Quaternion head_rot;
						character->GetThirdPerson().GetJointInfo("head", head_position, head_rot);

						Vector3 target_dir = head_position - gun_fire_position;
						current_dir.Normalize();
						target_dir.Normalize();

						float delta = Dot(current_dir, target_dir);
						float angle_delta = Acos(delta);

						if(delta > 0.999f || angle_delta <= frame_time * turret_info.angle_speed)
						{
							turret_rotation = Quaternion(Vector3(0, 0, -1.f), target_dir);
							Vector3 V = turret_rotation.GetZXY();
							V.z = 0;
							turret_rotation.SetZXY(V);

							if(fire_interval_timer < 0.f && ammo_count > 0)
							{
								fire_interval_timer = turret_info.fire_interval;
								FireCheck();
								ammo_count --;
							}
						}
						else
						{
							float percent = frame_time * turret_info.angle_speed / angle_delta;

							Quaternion t = Quaternion(Vector3(0, 0, -1.f), target_dir);
							Vector3 V = t.GetZXY();
							V.z = 0;
							t.SetZXY(V);
							Slerp(turret_rotation, turret_rotation, t, percent);
						}
						DummyObject::StopAction();
					}
				}
				else
				{
					static const float blend_time = 1.f;
					if(has_target)
					{
						gun_blend_timer = blend_time;
						turn_gun_base_quaternion = turret_rotation;
					}

					if(gun_blend_timer > 0.f && !gun_blend_over)
					{
						Slerp(turret_rotation, turn_gun_base_quaternion, idle_base_quaternion, (blend_time - gun_blend_timer)/blend_time);
						gun_blend_timer -= frame_time;
						if(gun_blend_timer < 0.f)
						{
							DummyObject::PlayAction("idle",1.f, true);
							gun_blend_over = true;
						}
					}
					else if(gun_blend_over)
					{
						GetDummyJointInfo("Gun_BH", NULL, &turret_rotation);
					}
					else
					{
						DummyObject::PlayAction("idle",1.f, true);
						gun_blend_over = true;
					}
				}
			}
		}
	}
	bool MachineGunTurret::GetUpBodyJointInfo(const String& szJoint, Vector3* position, Quaternion* rotation)
	{
		if (turret_skeleton)
		{
			int joint_id = turret_skeleton->GetJointId(szJoint);

			if (joint_id >= 0)
			{
				if(GetUpBodyPose())
				{
					const Transform & transform = GetUpBodyPose()->GetJointModelPose(joint_id);
					if (position)
						*position = turret_position + transform.position * transform.rotation * turret_rotation;

					if (rotation)
						*rotation = Quaternion(Vector3(0,1,0), PI/2) * transform.rotation * turret_rotation;

					return true;
				}
			}
		}
		return false;
	}

	tempc_ptr(Pose) MachineGunTurret::GetUpBodyPose()
	{
		if(turret_animation)
		{
			tempc_ptr(Pose) animation_pose = turret_animation->GetPose();
			if (animation_pose)
				return animation_pose;
		}

		return NullPtr;
	}

	void MachineGunTurret::MoveCommand(int command_type)
	{
		//if(can_move)
		{
			command_type += 1;
			move_timer = dummyobjectinfo->move_keep_time;
			is_on_moving = true;
			need_sync_move = true;

			dir_type = command_type;


			switch(dir_type)
			{
			case MOVE_DIR_FORWARD:
				{
					move_dir = Vector3(0, 0, -1.f) * GetRotation();
				}
				break;
			case MOVE_DIR_LEFT:
				{
					Quaternion q;
					q.SetFromTo(Vector3(0,0,-1.f), Vector3(-1,0,0));
					move_dir = Vector3(0, 0, -1.f) * GetRotation() * q;
				}
				break;
			case MOVE_DIR_RIGHT:
				{
					Quaternion q;
					q.SetFromTo(Vector3(0,0,-1.f), Vector3(1,0,0));
					move_dir = Vector3(0, 0, -1.f) * GetRotation() * q;
				}
				break;
			case MOVE_DIR_BACK:
				{
					move_dir = Vector3(0, 0, 1.f) * GetRotation();
				}
				break;
			}	

			FMOD_VECTOR vel = {0, 0, 0};
			String str = String::Format("bj/weapon/3d/%s/walk", dummyobjectinfo->tower_key.Str());
			FmodSystem::Play3DEvent(str.Str(),(const FMOD_VECTOR &)GetPosition(),vel);
		}
	}
	void MachineGunTurret::UpdateFreeze(float frame_time)
	{
		if(IsSyncMaster())
		{
			if(freeze)
			{
				freeze_timer -= frame_time;
				if(freeze_timer < 0.f)
				{
					hp = dummyobjectinfo->hp;
					freeze = false;
					DummyObject::PlayAction("idle", 2.0f,true);
					PlayAction("idle", 2.0f, true);
					turret_freeze_animation_timer = 2.0f;

					if (dummyobjectinfo->dummy_sound_key.Length() > 0)
					{
						FMOD_VECTOR vel = {0, 0, 0};
						FmodSystem::Play3DEvent(String::Format("bj/weapon/3d/%s/reboot", dummyobjectinfo->dummy_sound_key.Str() ),
							(const FMOD_VECTOR &)GetPosition(), vel);
					}
					if (dummy_reborn_particle)
					{
						dummy_reborn_particle->SetEnable(true);
						dummy_reborn_particle->Reset();
					}

					if (dummy_paralysis_particle)
					{
						dummy_paralysis_particle->SetEnable(false);
					}
				}	
			}
		}
		else
		{
			if(!freeze && strcmp(dummy_animation->node_action->GetAnimationKey() ,"die") == 0)
			{
				DummyObject::PlayAction("idle", 0.1f, true);
				PlayAction("idle", 0.1f, true);
			}
			else if(freeze && strcmp(dummy_animation->node_action->GetAnimationKey() ,"die") != 0)
			{
				dummy_animation->PlayAction("die", 0.1f, false, 0, true);
				turret_animation->PlayAction("die", 0.1f, false, 0, true);
			}
		}

	}
}