namespace Client
{
	struct MilkbottleInfo : public GunInfo
	{
		float range;
		MilkbottleInfo()
		{
			weapon_type = kWeaponTypeMilkbottle;
		}

	};

	class Milkbottle : public GunBase
	{
	public:
		Milkbottle(by_ptr(MilkbottleInfo) info);

	public:
		DECLARE_PDE_ATTRIBUTE_R(weapon_info, tempc_ptr(MilkbottleInfo))
		{
			return milkbottle_info;
		}

	public:
		/// update
		virtual void Update(float time);

		/// initialize
		virtual void Initialize();

		/// can active
		virtual bool CanActive();

		/// active
		virtual void Active();

		/// inactive
		virtual void Inactive();

		/// get weapon type
		virtual uint GetWeaponType();


	public:
		/// fire
		virtual bool Fire();


		/// can fire
		virtual bool CanFire(bool check_only);

		/// fire check
		virtual void FireCheck(const Core::Vector3 & position, const Core::Quaternion & rotation, float spread, bool do_effect = true);


	public:
		sharedc_ptr(MilkbottleInfo)	milkbottle_info;
		
	private:


		
	};


}