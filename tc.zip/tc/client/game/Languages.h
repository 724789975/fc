namespace Client
{
	typedef void*(*LangChangedCB)(void*);
	#define LANG_RBTREE 0

#if LANG_RBTREE
	class LanguageString : public LinkRBable<LanguageString>
	{
	public:
		LanguageString()
		{

		}

		LanguageString(String _key)
		{
			key = _key;
		}

		LanguageString(String _key, String _value)
		{
			key = _key;
			value = _value;
		}

		void SetKey(String _key)
		{
			key = _key;
		}

		bool operator==(const Client::LanguageString & right) const
		{
			return key == right.key;
		}

		String key;
		String value;

	};
#endif
	

	class Languages
	{
	public:
		Languages();

		~Languages();

		LangChangedCB SetLangChangedCB(LangChangedCB cb);

		bool LoadLanguage(const Core::String &lang);

		bool SetCurLanguage(const Core::String &lang);

		Core::String GetCurLanguage();

		Core::String GetText(const Core::String &text_key);

		Core::String GetTextW(const wchar_t* text_key);

		Core::String GetTextWLocal(const wchar_t* text_key);

		void CallLangChangedCB();

		void SetFontOffset(int value);

	private:
#if LANG_RBTREE
		typedef LinkRBTree<LanguageString> StringTable;		
#else
		typedef Core::HashSet<Core::String, Core::String> StringTable;
#endif
		typedef Core::HashSet<Core::String, sharedc_ptr(StringTable)> LangTable;

		LangTable lang_table;

		Core::String cur_lang;
		sharedc_ptr(StringTable) cur_stringtable;

		LangChangedCB call_back;
#if LANG_RBTREE
		LanguageString* string_finder;
#endif

	private:
		bool LoadLanguageLua(const String &file_name, by_ptr(StringTable) string_table);

		void LoadFontOffset(const String &file_name);
	};
}
