namespace Client
{
	struct MachineGunInfo : public RifleInfo
	{
		MachineGunInfo()
		{
			
		}
	};

	class MachineGun : public RifleGun
	{
	public:
		/// constructor
		MachineGun(by_ptr(MachineGunInfo) info);

	public:
		/// get weapon type
		virtual uint GetWeaponType();
	};
}