namespace Client
{
	/// ammo sync data
	struct AmmoSyncData
	{
		float				time;
		Core::Vector3		position;
		Core::Quaternion	rotation;
	};

	enum AmmoControlType
	{
		kAmmoControlType_None,
		kAmmoControlType_Lock,
		kAmmoControlType_Trace,
		kAmmoControlType_Control,
	};

	struct AmmoControlMode
	{
		AmmoControlType controltype;
		float anglelimit;
		float triggertime;

		AmmoControlMode()
		{
			controltype = kAmmoControlType_None;
			anglelimit = 0;
			triggertime = 0;
		}
	};
	struct AmmoAddInInfo
	{
		bool is_need_addin_info;
		float hurt_rate;
		float gravity_addon;
		float default_fly_speed;

		float blood_disk_interval;
		int	  blood_disk_hit_count;
		int	  max_stick_ammo_count;

		AmmoAddInInfo()
		{
			is_need_addin_info = false;
			hurt_rate = 0.f;
			default_fly_speed = 0.f;
			gravity_addon = 0.f;
			blood_disk_hit_count = 0;
			blood_disk_interval = 0.f;
			max_stick_ammo_count = 0;
		}
	};
	struct AmmoInfo : public WeaponInfo
	{
		float maxalive_time;
		byte gravity;
		float range;
		float hurt;
		float damage;

		float dmg_modify_timer_min;
		float dmg_modify_timer_max;
		float dmg_modify_min;
		float dmg_modify_max;

		float capsule_height;
		float capsule_radius;

		bool hurtself;
		bool ignorewall;

		AmmoControlMode ammocontrolmode;

		Core::Identifier explode_decal;
		Core::Identifier explode_particle;
		Core::Identifier explode_sound;
		Core::Identifier fly_particle;
		Core::Identifier stick_particle;
		Core::Identifier fly_sound;
		Core::Identifier fly_joint_name;

		float hurt_rate;
		float gravity_addon;
		float default_fly_speed;

		float blood_disk_interval;
		int	  blood_disk_hit_count;

		int   max_stick_ammo_count;

		int   impact_count_max;

		AmmoInfo()
		{
			maxalive_time = 1.0f;
			gravity = 0.f;
			hurt = 0.9f;
			dmg_modify_timer_min = dmg_modify_timer_max = 0.f;
			dmg_modify_min = dmg_modify_max = 0.f;

			capsule_height = 0.04f;
			capsule_radius = 0.04f;
			
			hurtself = true;
			ignorewall = false;
			hurt_rate = 1.f;
			default_fly_speed = 1.f;

			blood_disk_hit_count = 0;
			blood_disk_interval = 0.f;
			max_stick_ammo_count = 0;
			impact_count_max = 0;
		}
	};

	class AmmoBase;
	class AmmoFactory
	{
	public:
		static sharedc_ptr(AmmoBase) CreateAmmo(by_ptr(WeaponInfo) info);
	};

	class AmmoBase : public WeaponBase
	{
	public:
		/// constructor
		AmmoBase(by_ptr(WeaponInfo) info);

		/// destructor
		virtual ~AmmoBase();

		/// get weapon type
		virtual uint GetWeaponType() { return type; }

	public:
		/// initialize
		virtual void Initialize(uint team, bool isboost) = 0;

		/// stopeffect
		virtual void StopEffect() = 0;

		/// update physx
		virtual void UpdatePhysx(float frame_time) = 0;

		/// update
		virtual void Update(float frame_time) = 0;

		/// on render
		virtual void OnRender(float frame_time) = 0;

		/// timestep update
		virtual void TimeStepUpdate(float frame_time) = 0;

		/// Impact
		virtual void OnImpact(NxActor &hit_actor, const Core::Vector3 &hit_normal, const Core::Vector3 &hit_point) = 0;

		/// UpdateSyncData
		virtual void UpdateSyncData(float frame_time) = 0;

		/// AddSyncData
		virtual void AddSyncData(byte time, const Core::Vector3 &position, const Core::Vector3 &direction) = 0;

		/// HasSyncData
		virtual bool HasSyncData() = 0;

	public:
		/// get position
		virtual const Core::Vector3 & GetPosition() = 0;

		/// set position
		virtual void SetPosition(const Core::Vector3 & pos) = 0;

		/// get rotation
		virtual const Core::Quaternion & GetRotation() = 0;

		/// set rotation
		virtual void SetRotation(const Core::Quaternion & rot) = 0;
		
		/// change ammo team
		virtual void ChangeAmmoTeam(uint team) = 0;

		/// launch out
		virtual void LaunchOut(const Core::Vector3 & velocity, by_ptr(Character) locked_c = NullPtr) = 0;

		/// create physx
		virtual void CreatePhysx() = 0;

		/// set effect enable
		virtual void SetEffectEnable(bool enable) = 0;

		// set Velocity
		virtual bool SetVelocity(const Core::Vector3 &velocity) = 0;

		// get Velocity
		virtual bool GetVelocity(Core::Vector3 &velocity) = 0;

	public:
		/// from nx actor
		static tempc_ptr(AmmoBase) FromNxActor(NxActor & actor);

	public:
		byte		uid;
		uint		team;
		U16			ammoindex;		
		int			type;

		bool		is_boost;
		bool		is_dead;

		float		impact_flyscale;//min:0  max:1
		Core::Vector3 impact_normal;
		Core::Vector3 impact_pos;
		bool		is_impact;
		bool		is_impact_character;
		bool		is_skip_render;

		
	};

	class Ammo : public AmmoBase
	{
	public:
		/// constructor
		Ammo(by_ptr(AmmoInfo) info);

		/// destructor
		~Ammo();

		/// get weapon type
		virtual uint GetWeaponType() { return type; }

	public:
		/// initialize
		virtual void Initialize(uint team, bool isboost);

		/// stopeffect
		virtual void StopEffect();

		/// update physx
		virtual void UpdatePhysx(float frame_time);

		/// update
		virtual void Update(float frame_time);

		/// on render
		virtual void OnRender(float frame_time);

		/// timestep update
		virtual void TimeStepUpdate(float frame_time);

		/// Impact
		virtual void OnImpact(NxActor &hit_actor, const Core::Vector3 &hit_normal, const Core::Vector3 &hit_point);

		/// UpdateSyncData
		virtual void UpdateSyncData(float frame_time);

		/// AddSyncData
		virtual void AddSyncData(byte time, const Core::Vector3 &position, const Core::Vector3 &directionz);

		/// HasSyncData
		virtual bool HasSyncData();

	public:
		/// get position
		virtual const Core::Vector3 & GetPosition();

		/// set position
		virtual void SetPosition(const Core::Vector3 & pos);

		/// get rotation
		virtual const Core::Quaternion & GetRotation();

		/// set rotation
		virtual void SetRotation(const Core::Quaternion & rot);
		
		/// change ammo team
		virtual void ChangeAmmoTeam(uint team);

		/// launch out
		virtual void LaunchOut(const Core::Vector3 & velocity, by_ptr(Character) locked_c = NullPtr);

		/// create physx
		virtual void CreatePhysx();

		/// set effect enable
		virtual void SetEffectEnable(bool enable);

		// set Velocity
		virtual bool SetVelocity(const Core::Vector3 &velocity);

		// get Velocity
		virtual bool GetVelocity(Core::Vector3 &velocity);

		// add Force From Up and Right
		bool AddForceFromUpRight(float UAngle,float RAngle);
		
		/// 
		void SetStickable(bool bstick);

		/// from nx actor
		static tempc_ptr(Ammo) FromNxActor(NxActor & actor);

	private:
		/// get joint info
		bool GetJointInfo(int joint_id, Core::Vector3 *pos, Core::Quaternion *rot);

		void ReleasePhysx();

		void StopPhysx();

	private:
		NxActor*	actor;
		NxActor*	actor2;
		NxSweepCache* sweep_cache;
		float		physx_update_time;
		
		sharedc_ptr(ParticleSystem) fly_particle;
		sharedc_ptr(ParticleSystem) fly_particle_boost;
		int							fly_joint_id;
		FMOD::Event*				audio_reload;
		
	public:
		sharedc_ptr(Character)	targetplayer;
		float		timer;
		float		maxfly_time;

		float		free_fly_timer;
		float		anglelimit;

		//
		Core::Vector3	init_velocity;
		bool		busephysxrot;

		bool		is_player;

		float	sync_time;
		Core::Deque<AmmoSyncData>	sync_data;

		sharedc_ptr(AmmoInfo)	ammo_info;
	};

	class Arrow:public AmmoBase
	{
	public:
		Arrow(by_ptr(AmmoInfo) info);

		/// destructor
		~Arrow();

		/// get weapon type
		virtual uint GetWeaponType() { return type; }

	public:

		virtual void Initialize(uint team, bool isboost);

		/// stopeffect
		virtual void StopEffect();

		/// update physx
		virtual void UpdatePhysx(float frame_time);

		/// update
		virtual void Update(float frame_time);

		/// timestep update
		virtual void TimeStepUpdate(float frame_time);

		/// on render
		virtual void OnRender(float frame_time);

		/// get position
		virtual const Core::Vector3 & GetPosition();

		/// set position
		virtual void SetPosition(const Core::Vector3 & pos);

		/// get rotation
		virtual const Core::Quaternion & GetRotation();

		/// set rotation
		virtual void SetRotation(const Core::Quaternion & rot);

		/// change ammo team
		virtual void ChangeAmmoTeam(uint team);

		/// launch out
		virtual void LaunchOut(const Core::Vector3 & velocity, by_ptr(Character) locked_c = NullPtr);

		/// create physx
		virtual void CreatePhysx();

		/// set effect enable
		virtual void SetEffectEnable(bool enable);

		// set Velocity
		virtual bool SetVelocity(const Core::Vector3 &velocity);

		// get Velocity
		virtual bool GetVelocity(Core::Vector3 &velocity);

		/// from nx actor
		static tempc_ptr(Arrow) FromNxActor(NxActor & actor);

		/// Impact
		virtual void OnImpact(NxActor &hit_actor, const Core::Vector3 &hit_normal, const Core::Vector3 &hit_point);

		/// UpdateSyncData
		virtual void UpdateSyncData(float frame_time);

		/// AddSyncData
		virtual void AddSyncData(byte time, const Core::Vector3 &position, const Core::Vector3 &direction);

		/// HasSyncData
		virtual bool HasSyncData();

	private:
		/// get joint info
		bool GetJointInfo(int joint_id, Core::Vector3 *pos, Core::Quaternion *rot);

		void ReleasePhysx();

		void StopPhysx();

	private:
		uint		hit_jointID;
		Core::Vector3	body_offset;
		Core::Quaternion		inverse_rotation;


		NxActor*	actor;
		NxSweepCache* sweep_cache;
		float		physx_update_time;

		sharedc_ptr(ParticleSystem) fly_particle;
		sharedc_ptr(ParticleSystem) fly_particle_boost;
		sharedc_ptr(ParticleSystem) stick_particle;
		int			fly_joint_id;
	public:
		sharedc_ptr(Character)	targetplayer;
		float		timer;
		float		maxfly_time;
		byte		hit_character_uid;

		float		free_fly_timer;
		float		anglelimit;

		//
		Core::Vector3	init_velocity;
		bool		busephysxrot;

		bool		is_player;
		float	sync_time;
		Core::Deque<AmmoSyncData>	sync_data;

		sharedc_ptr(AmmoInfo)	ammo_info;

		
	};

	class AmmoGrenade:public AmmoBase
	{
	public:
		AmmoGrenade(by_ptr(AmmoInfo) info);

		/// destructor
		~AmmoGrenade();

		/// get weapon type
		virtual uint GetWeaponType() { return type; }

	public:
		virtual void Initialize(uint team, bool isboost);

		/// stopeffect
		virtual void StopEffect();

		/// update physx
		virtual void UpdatePhysx(float frame_time);

		/// update
		virtual void Update(float frame_time);

		/// timestep update
		virtual void TimeStepUpdate(float frame_time);

		/// on render
		virtual void OnRender(float frame_time);

		/// get position
		virtual const Core::Vector3 & GetPosition();

		/// set position
		virtual void SetPosition(const Core::Vector3 & pos);

		/// get rotation
		virtual const Core::Quaternion & GetRotation();

		/// set rotation
		virtual void SetRotation(const Core::Quaternion & rot);

		/// change ammo team
		virtual void ChangeAmmoTeam(uint team);

		/// launch out
		virtual void LaunchOut(const Core::Vector3 & velocity, by_ptr(Character) locked_c = NullPtr);

		/// create physx
		virtual void CreatePhysx();

		/// set effect enable
		virtual void SetEffectEnable(bool enable);

		// set Velocity
		virtual bool SetVelocity(const Core::Vector3 &velocity);

		// get Velocity
		virtual bool GetVelocity(Core::Vector3 &velocity);

		/// from nx actor
		static tempc_ptr(AmmoGrenade) FromNxActor(NxActor & actor);

		/// Impact
		virtual void OnImpact(NxActor &hit_actor, const Core::Vector3 &hit_normal, const Core::Vector3 &hit_point);

		/// UpdateSyncData
		virtual void UpdateSyncData(float frame_time);

		/// AddSyncData
		virtual void AddSyncData(byte time, const Core::Vector3 &position, const Core::Vector3 &direction);

		/// HasSyncData
		virtual bool HasSyncData();
	private:
		/// get joint info
		bool GetJointInfo(int joint_id, Core::Vector3 *pos, Core::Quaternion *rot);

		void ReleasePhysx();

		void StopPhysx();
	private:

		NxActor*	actor;
		NxSweepCache* sweep_cache;

		sharedc_ptr(ParticleSystem) fly_particle;
		sharedc_ptr(ParticleSystem) fly_particle_boost;
		int			fly_joint_id;
		int			impact_count;
		F64			impact_time_old;
		
	public:
		sharedc_ptr(Character)	targetplayer;
		float		timer;
		float		maxfly_time;

		float		free_fly_timer;
		float		impact_modify_scale;//min:0  max:1
		float		anglelimit;

		//
		Core::Vector3	init_velocity;
		bool		stop_phyx;
		bool		busephysxrot;

		bool		is_player;


		sharedc_ptr(AmmoInfo)		ammo_info;
	};


	class AmmoBloodDisk:public AmmoBase
	{
	public:
		AmmoBloodDisk(by_ptr(AmmoInfo) info);

		/// destructor
		~AmmoBloodDisk();

		/// get weapon type
		virtual uint GetWeaponType() { return type; }

	public:
		virtual void Initialize(uint team, bool isboost);

		/// stopeffect
		virtual void StopEffect();

		/// update physx
		virtual void UpdatePhysx(float frame_time);

		/// update
		virtual void Update(float frame_time);

		/// timestep update
		virtual void TimeStepUpdate(float frame_time);

		/// on render
		virtual void OnRender(float frame_time);

		/// get position
		virtual const Core::Vector3 & GetPosition();

		/// set position
		virtual void SetPosition(const Core::Vector3 & pos);

		/// get rotation
		virtual const Core::Quaternion & GetRotation();

		/// set rotation
		virtual void SetRotation(const Core::Quaternion & rot);

		/// change ammo team
		virtual void ChangeAmmoTeam(uint team);

		/// launch out
		virtual void LaunchOut(const Core::Vector3 & velocity, by_ptr(Character) locked_c = NullPtr);

		/// create physx
		virtual void CreatePhysx();

		/// set effect enable
		virtual void SetEffectEnable(bool enable);

		// set Velocity
		virtual bool SetVelocity(const Core::Vector3 &velocity);

		// get Velocity
		virtual bool GetVelocity(Core::Vector3 &velocity);

		/// from nx actor
		static tempc_ptr(AmmoBloodDisk) FromNxActor(NxActor & actor);

		/// Impact
		virtual void OnImpact(NxActor &hit_actor, const Core::Vector3 &hit_normal, const Core::Vector3 &hit_point);

		/// UpdateSyncData
		virtual void UpdateSyncData(float frame_time);

		/// AddSyncData
		virtual void AddSyncData(byte time, const Core::Vector3 &position, const Core::Vector3 &direction);

		/// HasSyncData
		virtual bool HasSyncData();
	private:
		/// get joint info
		bool GetJointInfo(int joint_id, Core::Vector3 *pos, Core::Quaternion *rot);

		void ReleasePhysx();

		void StopPhysx();

		void UpdateHitTimer(float frame_time);

		bool CheckHitLimit(byte uid);
	private:

		NxActor*	actor;
		NxSweepCache* sweep_cache;

		sharedc_ptr(ParticleSystem) fly_particle;
		sharedc_ptr(ParticleSystem) fly_particle_boost;
		int			fly_joint_id;
		int			impact_count;
		F64			impact_time_old;

	public:
		sharedc_ptr(Character)	targetplayer;
		float		timer;
		float		maxfly_time;

		float		free_fly_timer;
		float		impact_modify_scale;//min:0  max:1
		float		anglelimit;

		//
		Core::Vector3	init_velocity;
		bool		stop_phyx;
		bool		busephysxrot;

		bool		is_player;


		sharedc_ptr(AmmoInfo)		ammo_info;
		
		Core::HashSet<byte, float> hit_timer_set;
		Core::HashSet<byte, int> hit_count_set;

		float	sync_time;
		Core::Deque<AmmoSyncData>	sync_data;

	};
}