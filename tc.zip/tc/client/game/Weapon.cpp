#include "pch.h"

using namespace Core;

DEFINE_PDE_TYPE_ENUM(Client::WeaponInfo::HandBindType)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_ENUM_ITEM("kHandNone",	Client::WeaponInfo::kHandNone);
		ADD_PDE_ENUM_ITEM("kHandLeft",	Client::WeaponInfo::kHandLeft);
		ADD_PDE_ENUM_ITEM("kHandRight",	Client::WeaponInfo::kHandRight);
		ADD_PDE_ENUM_ITEM("kHandBoth",	Client::WeaponInfo::kHandBoth);

		ADD_PDE_ENUM_CONSTRUCTOR();
	}
};

REGISTER_PDE_TYPE(Client::WeaponInfo::HandBindType);

DEFINE_PDE_TYPE_CLASS(Client::WeaponInfo)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_FIELD(name);
		ADD_PDE_FIELD(sound_name);
		ADD_PDE_FIELD(change_in_time);
		ADD_PDE_FIELD(move_speed_offset);
		ADD_PDE_FIELD(cross_offset);
		ADD_PDE_FIELD(cross_length_base);
		ADD_PDE_FIELD(cross_length_factor);
		ADD_PDE_FIELD(cross_distance_base);
		ADD_PDE_FIELD(cross_distance_factor);

		ADD_PDE_FIELD(skeleton);
		ADD_PDE_FIELD(animation_set);
		ADD_PDE_FIELD(icon);
		ADD_PDE_FIELD(kill_icon);
		ADD_PDE_FIELD(crosshair);
		ADD_PDE_FIELD(crosshair_r);

		ADD_PDE_FIELD(cool_down);
		
		ADD_PDE_FIELD(reload_cd_bg);
		ADD_PDE_FIELD(reload_cd_con);
		ADD_PDE_FIELD(reload_cd_size_x);
		ADD_PDE_FIELD(reload_cd_size_y);

		ADD_PDE_FIELD(ik_enable);
		ADD_PDE_FIELD(hand_bind_type);

		ADD_PDE_FIELD(bg_tower_mesh);
		ADD_PDE_FIELD(able_tower_mesh);
		ADD_PDE_FIELD(unable_tower_mesh);
		//ǹ������������Ч��
		ADD_PDE_FIELD(level);

		ADD_PDE_METHOD(AddPart);
		ADD_PDE_METHOD(SetMesh);
		ADD_PDE_METHOD(SetMeshColor);
		ADD_PDE_METHOD(SetMeshColorWithLevel);
		ADD_PDE_METHOD(CleanMesh);
		ADD_PDE_METHOD(SetGunEffect);
	}
};

REGISTER_PDE_TYPE(Client::WeaponInfo);

DEFINE_PDE_TYPE_CLASS(Client::BlinkSetter)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_METHOD(SetMesh);
	}
};

REGISTER_PDE_TYPE(Client::BlinkSetter);

DEFINE_PDE_TYPE_CLASS(Client::GunInfo)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Client::WeaponInfo);

		ADD_PDE_FIELD(accuracy_divisor);
		ADD_PDE_FIELD(accuracy_offset);
		ADD_PDE_FIELD(max_inaccuracy);

		ADD_PDE_FIELD(penetration);
		ADD_PDE_FIELD(damage);
		ADD_PDE_FIELD(range_modifier);
		ADD_PDE_FIELD(range_start);
		ADD_PDE_FIELD(range_end);

		ADD_PDE_FIELD(fire_time);
		ADD_PDE_FIELD(reload_time);

		ADD_PDE_FIELD(ammo_in_clip);
		ADD_PDE_FIELD(ammo_one_clip);
		ADD_PDE_FIELD(ammo_count);

		ADD_PDE_FIELD(auto_fire);
		ADD_PDE_FIELD(is_sights);

		ADD_PDE_FIELD(normal_offset);
		ADD_PDE_FIELD(normal_factor);
		ADD_PDE_FIELD(onair_offset);
		ADD_PDE_FIELD(onair_factor);
		ADD_PDE_FIELD(move_offset);
		ADD_PDE_FIELD(move_factor);

		ADD_PDE_FIELD(fire_sound);
		ADD_PDE_FIELD(fire_particle);
		ADD_PDE_FIELD(idle_particle);
		ADD_PDE_FIELD(idle_skeleton_id);
		ADD_PDE_FIELD(fire_special_particle);
		ADD_PDE_FIELD(tp_special_particle);

		ADD_PDE_FIELD(bullet_particle_first);
		ADD_PDE_FIELD(bullet_particle_third);
		
		
		ADD_PDE_FIELD(sight);
		ADD_PDE_FIELD(thirdpersonviewer);
	}
};

REGISTER_PDE_TYPE(Client::GunInfo);


DEFINE_PDE_TYPE_CLASS(Client::WeaponBase)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		
	}
};

REGISTER_PDE_TYPE(Client::WeaponBase);

DEFINE_PDE_TYPE_CLASS(Client::GunBase)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Client::WeaponBase);
	}
};

REGISTER_PDE_TYPE(Client::GunBase);

namespace Client
{
	BlinkSetter::BlinkSetter()
		: mesh(NULL) 
	{
	}

	bool BlinkSetter::SetMesh(const Core::Identifier & key, const Core::Identifier & value, const U32 lod_level)
	{
		if (!gRender->lod_control->HasLod() && lod_level > 0)
			return false;

		if (!mesh)
			return false;

		PartInfo* info = mesh[lod_level].Get(key);
		if (info)
		{
			info->blink = true;
		}
		return true;
	}
}

namespace Client
{
	static int lua_load_resource(Lua::LuaState *L)
	{
		sharedc_ptr(Resource) resource;
		const char * key = L->ToString(1);

		if (key)
		{
			resource = Resource::Load(key, true);
		}

		L->PushPtr(resource);
		return 1;
	}

	BaseItemInfo::BaseItemInfo()
		: sid(0)
		, player_item_id(0)
		, color(0)
		, level(0)
		, durable(0)
		, star(0)
	{
	}

	void BaseItemInfo::AddPartKey(const Core::Identifier & value)
	{
		parts.PushBack(value);
	}

	WeaponInfo::WeaponInfo()
		: ik_enable(true)
		, hand_bind_type(kHandRight)
		, cross_length_base(7)
		, cross_length_factor(80)
		, cross_distance_base(3)
		, cross_distance_factor(400)
		, change_in_time(1.f)
		, damage_modifer(0)
		, time_to_idle(0)
		, cd_time(0)
		, cd_time1(0)
		, reload_cd_size_x(0)
		, reload_cd_size_y(0)
	{
		blink_setter = ptr_new BlinkSetter;
		blink_setter->mesh = mesh;
	}

	// load part
	void WeaponInfo::AddPart(const Core::Identifier & part)
	{
		AddPartKey(part);

		CStrBuf<256> path;
		path.format("/weapon/%s.lua", part.Str());

		sharedc_ptr(ScriptLua) lua = RESOURCE_LOAD(path, false, ScriptLua);

		if (lua)
		{
			lua_set.Set(lua->GetKey(), lua);
			Lua::LuaState *L = Lua::LuaState::NewState();

			if (L->LoadBuffer(lua->GetBuffer(), lua->GetSize(), path) == 0)
			{
				L->NewTable();
				L->PushPtr(ptr_static_cast<WeaponInfo>(this));
				L->SetField(-2, "weapon");
				L->PushPtr(gGame->config);
				L->SetField(-2, "config");

				const static Identifier type_Vector3_name = "Core.Vector3";
				tempc_ptr(PdeTypeInfo) type_info = PdeTypeInfo::FromName(type_Vector3_name);

				if (type_info)
				{
					L->PushPtr(type_info->GetConstructor());
					L->SetField(-2, "Vector3");
				}

				const static Identifier type_Quaternion_name = "Core.Quaternion";
				type_info = PdeTypeInfo::FromName(type_Quaternion_name);

				if (type_info)
				{
					L->PushPtr(type_info->GetConstructor());
					L->SetField(-2, "Quaternion");
				}

				L->PushCFunction(lua_load_resource);
				L->SetField(-2, "texture");

				L->SetFenv(-2);
				if (L->DoCall(0, 0))
				{
					const char *msg = L->ToString(-1);
					if (msg) Console.WriteLine(msg);
					L->Pop(1);
				}

			}
			else
			{
				const char *msg = L->ToString(-1);
				if (msg) Console.WriteLine(msg);
				L->Pop(1);
			}
			L->Close();
		}
	}

	void WeaponInfo::LoadPart()
	{
		if (!gLevel)
			return;

		if (!gLevel->lua_state)
			return;

		uint size = parts.Size();
		if (size == 0)
			return;

		Lua::LuaState *L = gLevel->lua_state;
		int top = L->GetTop();
		L->NewTable();
		
		L->PushPtr(GetPtrOwner());
		L->SetField(-2, "weapon");
		L->PushPtr(gGame->config);
		L->SetField(-2, "config");

		const static Identifier type_Vector3_name = "Core.Vector3";
		tempc_ptr(PdeTypeInfo) type_info = PdeTypeInfo::FromName(type_Vector3_name);
		if (type_info)
		{
			L->PushPtr(type_info->GetConstructor());
			L->SetField(-2, "Vector3");
		}

		const static Identifier type_Quaternion_name = "Core.Quaternion";
		type_info = PdeTypeInfo::FromName(type_Quaternion_name);
		if (type_info)
		{
			L->PushPtr(type_info->GetConstructor());
			L->SetField(-2, "Quaternion");
		}

		L->PushCFunction(lua_load_resource);
		L->SetField(-2, "texture");

		CStrBuf<256> path;

		for (uint i = 0; i < size; i++)
		{
			path.format("/weapon/%s.lua", parts[i].Str());
			sharedc_ptr(ScriptLua) lua = RESOURCE_LOAD(path, false, ScriptLua);

			if (lua)
			{
				lua_set.Set(lua->GetKey(), lua);

				if (L->LoadBuffer(lua->GetBuffer(), lua->GetSize(), path) == 0)
				{
					L->PushValue(top + 1);
					L->SetFenv(-2);

					if (L->DoCall(0, 0))
					{
						const char *msg = L->ToString(-1);
						if (msg) Console.WriteLine(msg);
						L->Pop(1);
					}
				}
				else
				{
					const char *msg = L->ToString(-1);
					if (msg) Console.WriteLine(msg);
					L->Pop(1);
				}
			}
		}
		tempc_ptr(Texture2D) temp_icon = icon;
		Core::String str;
		if (color > 0)
			str = Core::String::Format("LobbyUI/ibt_icon/%s_%d.tga",name,color);
		else
			str = Core::String::Format("LobbyUI/ibt_icon/%s.tga",name,color);
		icon = RESOURCE_LOAD_NEW(str, true, Texture2D);
		if (!icon)
		{
			icon = temp_icon;
			LogSystem.WriteLinef("WeaponInfo::LoadPart() : load icon error[%s %d]", name, color);
		}
		L->SetTop(top);
	}

	static int setter_nil(Lua::LuaState * L)
	{
		return 0;
	}

	void WeaponInfo::SetPartBlink(const Identifier & part)
	{
		CStrBuf<256> path;
		path.format("/weapon/%s.lua", part.Str());

		sharedc_ptr(ScriptLua) lua = RESOURCE_LOAD(path, false, ScriptLua);

		if (lua)
		{
			lua_set.Set(lua->GetKey(), lua);
			Lua::LuaState *L = Lua::LuaState::NewState();

			if (L->LoadBuffer(lua->GetBuffer(), lua->GetSize(), path) == 0)
			{
				L->NewTable();
				L->PushPtr(ptr_static_cast<BlinkSetter>(blink_setter));
				L->GetMetatable(-1);
				L->PushCFunction(&setter_nil);
				L->SetField(-2, "__newindex");
				L->Pop(1);
				L->SetField(-2, "weapon");
				L->SetFenv(-2);
				L->PushPtr(gGame->config);
				L->SetField(-2, "config");
				if (L->DoCall(0, 0))
				{
					const char *msg = L->ToString(-1);
					if (msg) Console.WriteLine(msg);
					L->Pop(1);
				}
			}
			else
			{
				const char *msg = L->ToString(-1);
				if (msg) Console.WriteLine(msg);
				L->Pop(1);
			}
			L->SetTop(0);
		}
	}

	// set baseitem info
	void WeaponInfo::SetBaseItemInfo(const BaseItemInfo & info)
	{
		sid = info.sid;
		player_item_id = info.player_item_id;

		display_name = info.display_name;
		name = info.name;

		color = info.color;
		level = info.level;
		star = info.star;
		durable = info.durable;

		attrs = info.attrs;

		parts = info.parts;
	}

	// set mesh
	void WeaponInfo::SetMesh(const Core::Identifier & key, const Core::Identifier & value, const U32 lod_level)
	{
		if(value == Core::Identifier(""))
			return;

		if (!gRender->lod_control->HasLod() && lod_level > 0)
			return;

		PartInfo* info = mesh[lod_level].Get(key);
		if (info)
		{
			info->parts.PushBack(value);
		}
		else
		{
			PartInfo info;
			info.parts.PushBack(value);
			mesh[lod_level].Set(key, info);
		}
	}

	// set mesh color
	void WeaponInfo::SetMeshColor(const Core::Identifier & key, const Core::Identifier & value, const U32 lod_level)
	{
		if(value == Core::Identifier(""))
			return;

		//static const char szColor[] = {'n', 'r', 'p', 'b', 'g', 'o'};
		static const char szColor[] = {'n', 'n', 'n', 'n', 'n', 'n'};

		CStrBuf<256> full_value;
		full_value.format("%s_%c_lod%d.mesh", value.Str(), szColor[color % ELEMENTS_OF(szColor)], lod_level);

		SetMesh(key, full_value, lod_level);
	}

	void WeaponInfo::SetMeshColorWithLevel(const Core::Identifier & key, const Core::Identifier & value, const U32 lod_level, const U32 weapon_level)
	{
		if(value == Core::Identifier(""))
			return;

		if(level == weapon_level)
		{
			SetMesh(key, value.Str(), lod_level);
		}
		
	}
	// clean mesh
	void WeaponInfo::CleanMesh(const Core::Identifier & key, const U32 lod_level)
	{
		if (!gRender->lod_control->HasLod() && lod_level > 0)
			return;

		mesh[lod_level].Remove(key);
	}

	// check weapon attribute
	bool WeaponInfo::CheckWeaponAttribute(short type, Attribute &attributeinfo)
	{
		for (U32 i = 0; i < attrs.Size(); i++)
		{
			AttributeList &attributelist = attrs[i];
			for (U32 j = 0; j < attributelist.Size(); j++)
			{
				Attribute &attribute = attributelist[j];
				if (attribute.type == type)
				{
					attributeinfo = attribute;

					return true;
				}
			}
		}

		return false;
	}

	void WeaponInfo::SetGunEffect(const Core::Identifier& _effectName, const Core::Identifier& slot, F32 _x, F32 _y, F32 _z)
	{
		effectName = _effectName;
		effectSlot = slot;
		effectOffset.x = _x;
		effectOffset.y = _y;
		effectOffset.z = _z;
	}

	GunInfo::GunInfo()
		: accuracy_divisor(220)
		, accuracy_offset(0.3f)
		, max_inaccuracy(1)

		, penetration(1)
		, damage(0)
		, range_modifier(0.99f)
		, range_start(0.f)
		, range_end(500.f)

		, fire_time(0.10f)
		, reload_time(2.29f)
		, ammo_one_clip(30)
		, ammo_count(120)
		, ammo_in_clip(30)

		, auto_fire(true)
		, is_sights(false)
		, idle_interval(0)

		, normal_offset(0)
		, normal_factor(0.02f)
		, onair_offset(0.035f)
		, onair_factor(0.4f)
		, move_offset(0.035f)
		, move_factor(0.07f)
		, thirdpersonviewer(false)
	{
	}

}

namespace Client
{
	/// constructor
	WeaponBase::WeaponBase()
		: position(Vector3::kZero)
		, rotation(Quaternion::kIdentity)
		, is_for_player(false)
		, idle_time(0)
		, cdscale(0)
		, Zombie_gun_cd(0)
		, is_weapon_updated(true)
		, audio_change(NULL)
	{
	}

	/// destructor
	WeaponBase::~WeaponBase()
	{
		mesh = NullPtr;
		skeleton = NullPtr;
		pose = NullPtr;
		animation = NullPtr;
		
		if(grenade_particle)
			gLevel->RemoveParticle(grenade_particle);
	}

	/// initialize
	void WeaponBase::Initialize()
	{
		mesh = ptr_new SkinMesh(MESH_KEY_WEAPON);
		for (U32 i = 0; i < MESH_LOD_LEVEL; i++)
		{
			if (mesh && weapon_info)
			{
				WeaponInfo::MeshSet::Enumerator it(weapon_info->mesh[i]);

				while (it.MoveNext())
				{
					for (U32 j = 0; j < it.Value().parts.Size(); j++)
					{
						//mesh->SetPrimitive(it.Key(), mesh->CreatePrimitive(it.Value().parts[j], it.Value().blink), i);
						CRefStr s = it.Value().parts[j].Str();
						Core::Identifier temp;
						if(s.startwith("x_") && weapon_info->color == 6)
						{
							s.remove(0,2);
							mesh->SetPrimitive(s, mesh->CreatePrimitive(s, it.Value().blink), i);
						}
						else
						{
							mesh->SetPrimitive(it.Value().parts[j], mesh->CreatePrimitive(it.Value().parts[j], it.Value().blink), i);
						}
							

						
						//if (strcmp(it.Value().parts[j].Str(),"rocket01021/rv1_n_lod0.mesh") == 0 && weapon_info->color == 6)
						//{
						//	temp = ("rocket01021_1/rv1_n_lod0.mesh");
						//	mesh->SetPrimitive(temp, mesh->CreatePrimitive(temp, it.Value().blink), i);
						//}
						//else if (strcmp(it.Value().parts[j].Str(),"rocket01021/rv1_n_lod1.mesh") == 0 && weapon_info->color == 6)
						//{
						//	temp = ("rocket01021_1/rv1_n_lod1.mesh");
						//	mesh->SetPrimitive(temp, mesh->CreatePrimitive(temp, it.Value().blink), i);
						//}
						//else if (strcmp(it.Value().parts[j].Str(),"rocket01021/rv1_n_lod2.mesh") == 0 && weapon_info->color == 6)
						//{
						//	temp = ("rocket01021_1/rv1_n_lod2.mesh");
						//	mesh->SetPrimitive(temp, mesh->CreatePrimitive(temp, it.Value().blink), i);
						//}
						//else
						//{
						//	mesh->SetPrimitive(it.Value().parts[j], mesh->CreatePrimitive(it.Value().parts[j], it.Value().blink), i);
						//}
					}
				}
			}
		}
		
		// load skeleton
		skeleton = RESOURCE_LOAD(weapon_info->skeleton, false, Skeleton);

		if (skeleton)
		{
			animation  = ptr_new AnimationNodeCustom(skeleton);
			if (animation->node_data)
				animation->node_data->blend_total_time = 0.f;
			pose = ptr_new Pose(skeleton);
		}
		
		idle_time = weapon_info->time_to_idle;
	}

	void WeaponBase::SetPartVisible(const Core::Identifier & key, bool flag)
	{
		for (U32 i = 0; i < MESH_LOD_LEVEL; i++)
		{
			WeaponInfo::MeshSet::Enumerator it(weapon_info->mesh[i]);

			while (it.MoveNext())
			{
				if(it.Key() == key)
				{
					for (U32 j = 0; j < it.Value().parts.Size(); j++)
					{
						mesh->SetPartVisible(i, it.Value().parts[j], flag);
					}
				}

			}
		}
	}

	/// preload animation
	void WeaponBase::PreloadAnimation()
	{
	}

	/// can active
	bool WeaponBase::CanActive()
	{
		return true;
	}

	/// active
	void WeaponBase::Active()
	{
		SetVisible(true);

		tempc_ptr(Character) player = GetOwner();
		if(player)
		{
			player->reloading = false;
			player->shooting = false;
			player->throwing_grenade = false;
			player->grenade_throw_out = false;
			player->stabing = false;
		}
	}

	/// inactive
	void WeaponBase::Inactive()
	{
		SetVisible(false);
		if (animation)
			animation->StopAction();
		
		if(grenade_particle)
			gLevel->RemoveParticle(grenade_particle);
	}

	/// get weapon type
	uint WeaponBase::GetWeaponType()
	{
		return kWeaponTypeNone;
	}

	/// get pose
	tempc_ptr(Pose) WeaponBase::GetPose()
	{
		if(animation)
		{
			tempc_ptr(Pose) animation_pose = animation->GetPose();
			if (animation_pose)
				return animation_pose;
		}

		return pose;
	}

	void WeaponBase::UpdateGrenadeParticle()
	{
		if (grenade_particle)
		{
			Vector3 pos;
			Quaternion rot;
			tempc_ptr(Character) character = GetOwner();
			if (!character)
				return;

			grenade_particle->SetPosition(GetPosition());

			tempc_ptr(WeaponBase) third_fg = ptr_dynamic_cast<WeaponBase>(character->GetThirdPresonWeapon());
			tempc_ptr(WeaponBase) frist_fg = ptr_dynamic_cast<WeaponBase>(character->GetWeapon(true));

			if(!character->IsDied())
			{
				if(!grenade_particle->m_LinkNode.GetList())
				{
					gLevel->AddParticle(grenade_particle);
					grenade_particle->SetEnable(false);
				}
				if(character->GetViewMode() == Character::kFirstPerson)
				{
					if(frist_fg && frist_fg->grenade_particle)
					{
						frist_fg->grenade_particle->SetEnable(true);
						frist_fg->grenade_particle->SetFirstPersonMode(true);
					}
					if(third_fg && third_fg->grenade_particle)
						third_fg->grenade_particle->SetEnable(false);
				}
				else
				{
					if(frist_fg && frist_fg->grenade_particle)
						frist_fg->grenade_particle->SetEnable(false);
					if(third_fg && third_fg->grenade_particle)
					{
						third_fg->grenade_particle->SetEnable(true);
						third_fg->grenade_particle->SetFirstPersonMode(false);
					}
				}
			}	
			else
			{
				if(frist_fg && frist_fg->grenade_particle)
					frist_fg->grenade_particle->SetEnable(false);
				if(third_fg && third_fg->grenade_particle)
					third_fg->grenade_particle->SetEnable(false);
			}
		}
	}

	/// update
	void WeaponBase::Update(float time)
	{
		UpdateGrenadeParticle();
	}

	/// udpate animation
	void WeaponBase::UpdateAnimation(float time)
	{
		if (animation)
			animation->Update(time);
	}

	/// play action
	void WeaponBase::PlayAction(const Identifier & key, float blend_time, bool cycle, float play_time)
	{
		if (animation)			
			animation->PlayAction(key, blend_time, cycle, play_time);
	}

	/// stop action
	void WeaponBase::StopAction()
	{
		if (animation)
			animation->StopAction();
	}

	/// update mesh
	void WeaponBase::UpdateMesh()
	{
		if (mesh)
		{
			mesh->pose = GetPose();
			mesh->Update();
			world_aabb = mesh->GetAABB();
			local_aabb = mesh->GetAABB();
		}
		Matrix44 matrix(GetPosition(), 1, GetRotation());
		world_aabb.Transform(matrix);
	}


	/// draw
	void WeaponBase::Draw(Primitive::DrawType drawtype, bool immediate)
	{
		if (mesh)
		{
			mesh->SetPosition(GetPosition());
			mesh->SetRotation(GetRotation());
			//static const char szColor[] = {'n', 'r', 'p', 'b', 'g', 'o'};
			Vector4 ambi_color(1.0f, 1.f, 1.f, 1.f);
			Vector4 specular_color(1.0f, 1.0f, 1.0f, 1.0f);
			if(weapon_info)
			{
				switch(weapon_info->color)
				{
				case 0:
					{
						//normal
						ambi_color = Vector4(1.0f, 1.f, 1.f, 1.f);
						specular_color = Vector4(0.25f, 0.25f, 0.3f, 1.f);
					}
					break;
				case 1:
					{
						//red
						ambi_color = Vector4(1.0f, 1.f, 1.f, 1.f);
						specular_color = Vector4(1.0f, 1.f, 1.f, 1.f);
					}
					break;
				case 2:
					{
						//purple
						ambi_color = Vector4(0.96f, 0.794f, 1.f, 1.f);
						specular_color = Vector4(0.678f,0.f,0.969f, 1.f);
					}
					break;
				case 3:
					{
						//blue
						ambi_color = Vector4(0.48f, 0.662f, 1.f, 1.f);
						specular_color = Vector4(0.063f,0.588f,0.906f, 1.f);
					}
					break;
				case 4:
					{
						//green
						ambi_color = Vector4(0.815f,1.f,0.708f, 1.f);
						specular_color = Vector4(0.29f,0.863f,0.063f, 1.f);
						
					}
					break;
				case 5:
					{
						//orange
						ambi_color = Vector4(1.f, 0.854f, 0.674f, 1.f);
						specular_color = Vector4(0.969f,0.247f,0.f, 1.f);
					}
					break;
				case 6:
					{
						//
						ambi_color = Vector4(1.f, 0.854f, 0.674f, 1.f);
						specular_color = Vector4(0.969f,0.247f,0.f, 1.f);
					}
					break;
				}
				gDx9Device->SetPixelShaderConstantF(PS_CONSTANT_AMBICOLOR, &ambi_color.x);
				gDx9Device->SetPixelShaderConstantF(PS_CONSTANT_SPECULARCOLOR, &specular_color.x); 
			}
			else
			{
				gDx9Device->SetPixelShaderConstantF(PS_CONSTANT_AMBICOLOR, &ambi_color.x);
				gDx9Device->SetPixelShaderConstantF(PS_CONSTANT_SPECULARCOLOR, &specular_color.x);
			}
			
			mesh->Draw(drawtype, immediate);
		}
	}

	/// draw ui
	void WeaponBase::DrawUI(by_ptr(UIRender) ui_render)
	{
		tempc_ptr(Character) player = gLevel->GetPlayer();

		if(!player)
			return;

		if (weapon_info->icon)
		{
			ui_render->SetTexture(weapon_info->icon);
			ui_render->BeginRectangleList(1);
			ui_render->Vertex(-175, -103 - 5, 0, 0, 0, ARGB(player->weapon_current_icon_alpha * 255,255, 255, 255));
			ui_render->Vertex(-10, -20 - 5, 0, 1, 1, ARGB(player->weapon_current_icon_alpha * 255,255, 255, 255));
			ui_render->End();
		}
	}

	void WeaponBase::DrawCrossHair(by_ptr(UIRender) ui_render)
	{
		tempc_ptr(Character) player = GetOwner();

		if (!player)
			return;

		if (!weapon_info)
			return;

		Matrix44 view;
		Vector3 rt_size = ui_render->GetRenderTargetSize();
		view.SetScaleXYZ(2.0f / rt_size.x, -2.0f / rt_size.y, 0);

		ui_render->SetWorld(Matrix44::kIdentity);
		ui_render->SetView(view);
		ui_render->SetProjection(Matrix44::kIdentity);
		F32 len = 1;
		if (gGame && gGame->camera)
		{
			len = gGame->camera->GetFar() * 0.5f;

			NxRay ray;
			ray.orig = (const NxVec3 &)gGame->camera->position;
			ray.dir = (const NxVec3 &)(Vector3(0, 0, -1) * gGame->camera->rotation);

			NxRaycastHit hit;
			float distance = 500;
			uint group_id = 0;
			group_id |= 1 << PhysxSystem::kStatic;
			group_id |= 1 << PhysxSystem::kStaticRaycast;
			for (uint i = 0; i < 2; ++i)
			{
				group_id |= 1 << (PhysxSystem::kGroupStart + i);
			}
			group_id |= 1 << PhysxSystem::kGroupVehicle;

			NxShape* shape = gPhysxScene->raycastClosestShape(ray, NX_ALL_SHAPES, hit, group_id, distance);
			if (shape)
			{
				//len = Length(gGame->camera->position - (const Vector3 &)hit.worldImpact);
				len = hit.distance;
			}
		}

		F32 v = gDx9Device->convergence > 0 ? gDx9Device->convergence : 1;
		if (gDx9Device->GetStereoEnable() &&  len> 0)
			v = len;

		gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_CONVERGENCE, &v, 1);

		if (weapon_info->crosshair && weapon_info->crosshair_r && weapon_info->weapon_type != kWeaponTypeSniperGun)
		{
			if (!player->is_point_emeny)
			{
				float w = Ceil(weapon_info->crosshair->GetWidth() * 0.5f);
				float h = Ceil(weapon_info->crosshair->GetHeight() * 0.5f);
				ui_render->SetTexture(weapon_info->crosshair);
				ui_render->DrawRectangle(Core::Rectangle(-w,-h,w,h), Core::Rectangle(0,0,1,1));
			}
			else
			{
				float w = Ceil(weapon_info->crosshair_r->GetWidth() * 0.5f);
				float h = Ceil(weapon_info->crosshair_r->GetHeight() * 0.5f);
				ui_render->SetTexture(weapon_info->crosshair_r);
				ui_render->DrawRectangle(Core::Rectangle(-w,-h,w,h), Core::Rectangle(0,0,1,1));
			}
		}
		else
		{
			float offset  = player->punch_angle.Length();

			float length = weapon_info->cross_length_base;
			float distance = weapon_info->cross_distance_base;

			distance += offset * weapon_info->cross_distance_factor + player->cross_hair_offset;
			length += offset * weapon_info->cross_length_factor;

			distance = Ceil(distance);
			length = Ceil(length);

			ui_render->BeginRectangleList(8);
			ui_render->VertexColor(Color4(0, 0, 0, 1));

			// right
			ui_render->Vertex2f(distance, -2);
			ui_render->Vertex2f(distance + length + 2, 1);

			// left
			ui_render->Vertex2f(-distance - 1, -2);
			ui_render->Vertex2f(-distance - length - 3, 1);

			// bottom
			ui_render->Vertex2f(-2, distance);
			ui_render->Vertex2f(1, distance + length + 2);

			// top
			ui_render->Vertex2f(-2, -distance - 1);
			ui_render->Vertex2f(1, -distance - length - 3);

			ui_render->VertexColor(Color4(0, 1, 0, 1));

			if(player->is_point_emeny)
				ui_render->VertexColor(Color4(1, 0, 0, 1));

			// right
			ui_render->Vertex2f(distance + 1, -1);
			ui_render->Vertex2f(distance + length + 1, 0);

			// left
			ui_render->Vertex2f(-distance - 2, -1);
			ui_render->Vertex2f(-distance - length - 2, 0);

			// bottom
			ui_render->Vertex2f(-1, distance + 1);
			ui_render->Vertex2f(0, distance + length + 1);

			// top
			ui_render->Vertex2f(-1, -distance - 2);
			ui_render->Vertex2f(0, -distance - length - 2);

			ui_render->End();
			
			
		}

		if (gDx9Device->GetStereoEnable())
			v = gDx9Device->convergence > 0 ? gDx9Device->convergence : 1;

		gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_CONVERGENCE, &v, 1);
	}

	/// get mesh
	tempc_ptr(SkinMesh) WeaponBase::GetMesh()
	{
		return mesh;
	}

	/// set mesh
	void WeaponBase::SetMesh(by_ptr(SkinMesh) m)
	{
		mesh = m;
	}

	/// set mesh lod
	void WeaponBase::SetMeshLod(int lod_level)
	{
		if (mesh)
			mesh->SetBaseLodLevel(lod_level);
	}

	/// set visible
	void WeaponBase::SetVisible(bool flag)
	{
		if (mesh)
			mesh->SetVisible(flag);
	}

	/// get visible
	bool WeaponBase::GetVisible()	
	{
		if (mesh)
			return mesh->GetVisible();
		return false;
	}
	/// set position
	void WeaponBase::SetPosition(const Core::Vector3 & pos)
	{
		position = pos;
		if (mesh)
			mesh->SetPosition(pos);
	}

	/// set rotation
	void WeaponBase::SetRotation(const Core::Quaternion & rot)
	{
		rotation = rot;
		if (mesh)
			mesh->SetRotation(rot);
	}

	/// get position
	const Vector3 & WeaponBase::GetPosition()
	{
		return position;
	}

	/// get rotation
	const Quaternion & WeaponBase::GetRotation()
	{
		return rotation;
	}

	/// get owner
	tempc_ptr(Character) WeaponBase::GetOwner()
	{
		return owner;
	}

	/// set owner	
	void WeaponBase::SetOwner(by_ptr(Character) character)
	{
		owner = character;
	}

	/// change in
	void WeaponBase::ChangeIn()
	{
		if (animation)
		{
			//animation->PlayAction("change", 0.2f, false, weapon_info? weapon_info->change_in_time: 0);
			animation->PlayAction("change", 0.2f, false);
		}
	}

	/// change in sound
	void WeaponBase::ChangeInSound()
	{
		CStrBuf<256> key;
			
		key.format("bj/weapon/2d/%s/changein", weapon_info->sound_name.Str());
		audio_change = FmodSystem::PlayEvent(key);
	}

	/// is resource ready
	bool WeaponBase::IsReady()
	{
		if (animation_set_player && !animation_set_player->IsReady())
			return false;

		if (animation_set_character && !animation_set_character->IsReady())
			return false;

		if (!mesh->IsReady())
			return false;

		return true;
	}

	/// action on hit
	void WeaponBase::ActionOnHit()
	{
		if (animation && !animation->IsActionPlaying())
			animation->PlayAction("hit", 0.f);
	}
}

namespace Client
{
	GunBase::GunBase()
		: shots_fired(0)
		, accuracy(0)
		, direction(1)
		, ammo_in_clip(0)
		, ammo_count(0)
		, max_ammo_in_clip(0)
		, max_ammo_count(0)
		, next_fire_time(0)
		, reloading(false)
		, reload_time(0)
		, decrease_shots_fired(0)
		, delay_fire(true)
		, last_fire_time(0)
		, audio_reload(NULL)
		, audio_pull(NULL)
		, has_trajectory(false)
		, hurt_rate(1.f)
		, power(0.f)
		, empty(false)
	{
		old_controlmode =  Camera::kCharacterControl;
		old_cameradistance = 0.f;
	}

	/// destructor
	GunBase::~GunBase()
	{
		if(gLevel && idleparticle)
		{
			gLevel->RemoveParticle(idleparticle);
		}
	}

	/// preload animation
	void GunBase::PreloadAnimation()
	{
		if (skeleton && weapon_info)
		{
			
			sharedc_ptr(AnimationSetRes) set_res;
			if(weapon_info)
			{
				if (owner && owner->GetCurCharinfo())
				{
					CStrBuf<256> str_animation;
					str_animation.format("%s/%s", owner->character_info->first_person_animationset, weapon_info->animation_set);
					set_res = RESOURCE_GET_BYTYPE(RESOURCE_NAME(ANIMATION_KEY_PROP_PLAYER, str_animation), ANIMATIONSET_TYPE, AnimationSetRes);

					if (set_res)
					{
						set_res->Load(true);
						if (gLevel->animation_manager)
							gLevel->animation_manager->AddAnimationSetRes(set_res->GetKey(), set_res);
					}

				}
			}
			
			sharedc_ptr(AnimationSetRes) set_res1;
			if (weapon_info)
			{
				if (owner && owner->GetCurCharinfo())
				{
					CStrBuf<256> str_animation;
					str_animation.format("%s/%s", owner->character_info->third_person_animationset, weapon_info->animation_set);
					set_res1 = RESOURCE_GET_BYTYPE(RESOURCE_NAME(ANIMATION_KEY_PROP_CHARACTER, str_animation), ANIMATIONSET_TYPE, AnimationSetRes);
				}

				if (set_res1)
				{
					set_res1->Load(true);
					if (gLevel->animation_manager)
						gLevel->animation_manager->AddAnimationSetRes(set_res1->GetKey(), set_res1);
				}
			}		
		}
	}

	void GunBase::Initialize()
	{
		WeaponBase::Initialize();

		if (skeleton)
		{
			animation_list = ptr_new AnimationNodeList;
			animation_set = ptr_new AnimationSet;

			if (is_for_player)
			{
				CStrBuf<256> str(ANIMATION_KEY_PROP_PLAYER);

				CStrBuf<256> str_animation;
				str_animation.format("%s/%s", owner->GetCurCharinfo()->third_person_animationset, weapon_info->animation_set);

				if (weapon_info)
					str.contract(str_animation);

				animation_set_player = RESOURCE_GET_BYTYPE(str, ANIMATIONSET_TYPE, AnimationSetRes);
				if (animation_set_player)
				{
					animation_set_player->Load(true);
				}
				animation_set->SetAnimationSet("common", animation_set_player);
			}
			else
			{
				CStrBuf<256> str(ANIMATION_KEY_PROP_CHARACTER);

				CStrBuf<256> str_animation;
				if(owner)
				{
					str_animation.format("%s/%s", owner->GetCurCharinfo()->third_person_animationset, weapon_info->animation_set);

					if (weapon_info)
						str.contract(str_animation);

					animation_set_character = RESOURCE_GET_BYTYPE(str.buff(), ANIMATIONSET_TYPE, AnimationSetRes);
					if (animation_set_character)
					{
						animation_set_character->Load(true);
					}
					animation_set->SetAnimationSet("common", animation_set_character);
				}
				
			}

			if (animation)
			{
				animation->SetAnimationSet(animation_set);

				sharedc_ptr(AnimationNodePose) node = ptr_new AnimationNodePose(skeleton);
				node->SetAnimation("idle", animation_set);
				animation_list->AddNode("idle", node);

				node = ptr_new AnimationNodePose(skeleton);
				node->SetAnimation("empty", animation_set);
				animation_list->AddNode("empty", node);

				animation_list->SetActiveNode("idle");

				animation->SetAnimationNode(animation_list);
			}

			pose = ptr_new Pose(skeleton);

			joint_bl_id = skeleton->GetJointId("Gun_BL");
			joint_fh_id = skeleton->GetJointId("Gun_FH");
			joint_sl_id = skeleton->GetJointId("Gun_SL");
			joint_fire_id = skeleton->GetJointId("Gun_Fire");
			joint_fire_l_id = skeleton->GetJointId("Gun_Fire_L");
			joint_fire_r_id = skeleton->GetJointId("Gun_Fire_R");
			joint_ec_id = skeleton->GetJointId("Gun_EC");
			joint_ec_l_id = skeleton->GetJointId("Gun_EC_L");
			joint_ec_r_id = skeleton->GetJointId("Gun_EC_R");
			joint_fl_id = skeleton->GetJointId("Gun_FL");
			joint_sp_id = skeleton->GetJointId("Gun_SP");
			joint_gp_id = skeleton->GetJointId("Gun_GP");
		}

		ammo_count = gun_info->ammo_count;
		ammo_in_clip = gun_info->ammo_in_clip;

		max_ammo_in_clip = gun_info->ammo_one_clip;
		max_ammo_count = gun_info->ammo_count;

		if ( gLevel->game_type == RoomOption::kSurvivalMode )
		{
			ammo_count = 0;
			ammo_in_clip = 0;
			max_ammo_in_clip = 0;
			max_ammo_count = 0;
		}

		shots_fired = 0;
		decrease_shots_fired = 0;
		accuracy = 0.2f;
		delay_fire = true;

		if (weapon_info->name.Length() == 0)
			return;

		if (gun_info->fire_particle.Length())
		{
			CStrBuf<256> key;
			key.format("%s_%s", gun_info->fire_particle.Str(), is_for_player ? "1st" : "3rd");
			gun_fire_particle = ptr_new ParticleSystem(key);
			static const char szTeam[2] = {'r', 'b'};
			if(owner)
			{
				key.contractf("_b%c",szTeam[owner->GetTeam() & 1]);
				gun_fire_particle_boost = ptr_new ParticleSystem(key);
			}
		}
		if (gun_info->idle_particle.Length())
		{
			CStrBuf<256> key;
			key.format("%s_%s", gun_info->idle_particle.Str(), is_for_player ? "1st" : "3rd");
			idleparticle = ptr_new ParticleSystem(key);
		}
		
		if (gun_info->fire_special_particle.Length())
		{
			CStrBuf<256> key;
	
			key.format("%s", gun_info->fire_special_particle.Str());
			gun_special_particle = ptr_new ParticleSystem(key);
			gun_special_particle->SetEnable(false);
		}

		if(gun_info->tp_special_particle.Length())
		{
			CStrBuf<256> key;

			key.format("%s", gun_info->tp_special_particle.Str());
			tp_special_particle = ptr_new ParticleSystem(key);
			tp_special_particle->SetEnable(false);
		}

		if (is_for_player)
		{
			if (gun_info->bullet_particle_first.Length())
				gun_bullet_particle = ptr_new ParticleSystem(gun_info->bullet_particle_first);
		}
		else
		{
			if (gun_info->bullet_particle_third.Length())
				gun_bullet_particle = ptr_new ParticleSystem(gun_info->bullet_particle_third);
		}

		sight_current = 0;
		sight_temp = 0;
		gun_info->is_sights = gun_info->sight_info.Size() > 0;
	}

	/// can active
	bool GunBase::CanActive()
	{
		return WeaponBase::CanActive();
	}

	/// active
	void GunBase::Active()
	{
		WeaponBase::Active();
		shots_fired = 0;
		decrease_shots_fired = 0;
		accuracy = 0.2f;
		delay_fire = true;
		empty = false;

		tempc_ptr(Character) player = GetOwner();

		if (!player)
			return;
		
		player->dual_pistol_status = false;
		player->is_complete_raise = false;
		player->fire_time_ratio = 0.0f;

		sight_current = 0;
		sight_temp = 0;
		is_play = false;
		SetSight(sight_current);
	}

	/// inactive
	void GunBase::Inactive()
	{
		WeaponBase::Inactive();

		tempc_ptr(Character) player = GetOwner();

		if (!player)
			return;

		reloading = false;
		empty = false;

		if (audio_reload)
			audio_reload->stop(true);

		if (audio_change)
			audio_change->stop(true);

		if (audio_pull)
			audio_pull->stop(true);

		player->reloading = false;
		player->StopShoot();
		player->fire_time_ratio = 0.0f;

		sight_current = 0;
		sight_temp = 0;
		SetSight(sight_current);
		
		if(gun_info->thirdpersonviewer)
		{
			if(gGame && player->IsLockStateByType(kLSSelectWeapon))
			{
				player->UnLockStateByType(kLSSelectWeapon);
				player->camera_distance = old_cameradistance;
				gGame->camera->control_mode = old_controlmode;
			}
		}

		if(idleparticle)
		{
			gLevel->RemoveParticle(idleparticle);
		}
	}

	/// is empty
	bool GunBase::IsEmpty()
	{
		return empty;
	}

	/// udpate effect
	void GunBase::UpdateEffect(float time)
	{

		tempc_ptr(Character) character = GetOwner();
		/*if(character->occluded)
		{
			return;
		}*/

		if (gun_fire_particle)
		{
			Vector3 fire_pos;
			Quaternion fire_rot;
			
			if (GetJointInfo(joint_fire_id, &fire_pos, &fire_rot))
			{
				gun_fire_particle->SetPosition(fire_pos);
				gun_fire_particle->SetRotation(fire_rot);
			}

			if(GetWeaponType()==kWeaponTypeDualPistol)
			{
				tempc_ptr(Character) character = gLevel->GetViewer();

				if (character && GetJointInfo(joint_fire_l_id, &fire_pos, &fire_rot) && character->dual_pistol_status)
				{
					gun_fire_particle->SetPosition(fire_pos);
					gun_fire_particle->SetRotation(fire_rot);
				}

				if (character && GetJointInfo(joint_fire_r_id, &fire_pos, &fire_rot) && !character->dual_pistol_status)
				{
					gun_fire_particle->SetPosition(fire_pos);
					gun_fire_particle->SetRotation(fire_rot);
				}
			}
		}
		
		if (gun_fire_particle_boost)
		{
			Vector3 fire_pos;
			Quaternion fire_rot;

			if (GetJointInfo(joint_fire_id, &fire_pos, &fire_rot))
			{
				gun_fire_particle_boost->SetPosition(fire_pos);
				gun_fire_particle_boost->SetRotation(fire_rot);
			}

			if(GetWeaponType()==kWeaponTypeDualPistol)
			{
				tempc_ptr(Character) character = gLevel->GetViewer();

				if (character && GetJointInfo(joint_fire_l_id, &fire_pos, &fire_rot) && character->dual_pistol_status)
				{
					gun_fire_particle_boost->SetPosition(fire_pos);
					gun_fire_particle_boost->SetRotation(fire_rot);
				}

				if (character && GetJointInfo(joint_fire_r_id, &fire_pos, &fire_rot) && !character->dual_pistol_status)
				{
					gun_fire_particle_boost->SetPosition(fire_pos);
					gun_fire_particle_boost->SetRotation(fire_rot);
				}
			}
		}

		if (gun_bullet_particle)
		{
			Vector3 pos;
			Quaternion rot;

			if (GetJointInfo(joint_ec_id, &pos, &rot))
			{
				gun_bullet_particle->SetPosition(pos);
				gun_bullet_particle->SetRotation(rot);
			}

			if(GetWeaponType()==kWeaponTypeDualPistol)
			{
				tempc_ptr(Character) character = gLevel->GetViewer();

				if (character && GetJointInfo(joint_ec_l_id, &pos, &rot) && character->dual_pistol_status)
				{
					gun_bullet_particle->SetPosition(pos);
					gun_bullet_particle->SetRotation(rot);
				}
				if (character && GetJointInfo(joint_ec_r_id, &pos, &rot) && !character->dual_pistol_status)
				{
					gun_bullet_particle->SetPosition(pos);
					gun_bullet_particle->SetRotation(rot);
				}
			}
		}
		
		
		if (idleparticle)
		{
			Vector3 pos;
			Quaternion rot;
			tempc_ptr(Character) player = gLevel->GetViewer();
			if (GetJointInfo(gun_info->idle_skeleton_id.Str(), &pos, &rot))
			{
				idleparticle->SetPosition(pos);
				idleparticle->SetRotation(rot);
			}
			tempc_ptr(GunBase) third_fg = ptr_dynamic_cast<GunBase>(character->GetThirdPresonWeapon());
			tempc_ptr(GunBase) frist_fg = ptr_dynamic_cast<GunBase>(character->GetWeapon(true));
			if(!character->IsDied() /*&& character->occluded == false*/ )
			{
				if(!idleparticle->m_LinkNode.GetList())
				{
					gLevel->AddParticle(idleparticle);
					idleparticle->SetEnable(false);
				}
				if(character->GetViewMode() == Character::kFirstPerson)
				{
					if(frist_fg && frist_fg->idleparticle)
					{
						frist_fg->idleparticle->SetEnable(true);
						frist_fg->idleparticle->SetFirstPersonMode(true);
					}
					if(third_fg && third_fg->idleparticle)
						third_fg->idleparticle->SetEnable(false);
				}
				else
				{
					if(frist_fg && frist_fg->idleparticle)
						frist_fg->idleparticle->SetEnable(false);
					if(third_fg && third_fg->idleparticle)
					{
						third_fg->idleparticle->SetEnable(true);
						third_fg->idleparticle->SetFirstPersonMode(false);
					}
				}
			}	
			else
			{
				if(frist_fg && frist_fg->idleparticle)
					frist_fg->idleparticle->SetEnable(false);
				if(third_fg && third_fg->idleparticle)
					third_fg->idleparticle->SetEnable(false);
			}
		}

	}

		/// udpate animation
	void GunBase::UpdateAnimation(float time)
	{
		if (animation_list)
		{
			if (IsEmpty())
				animation_list->SetActiveNode("empty");
			else
				animation_list->SetActiveNode("idle");
		}

		WeaponBase::UpdateAnimation(time);
	}

	/// update mesh
	void GunBase::UpdateMesh()
	{
		tempc_ptr(Pose) base_pose = GetPose();

		if (skeleton && base_pose)
		{
			Transform transform;

			//if (joint_fl_id >=0)
			//{
			//	transform.position = gun_info->fl_position;
			//	transform.rotation = gun_info->fl_rotation;
			//	base_pose->SetJointLocalPose(joint_fl_id, transform);
			//}

			//if (joint_bl_id >=0)
			//{
			//	transform = base_pose->GetJointLocalPose(joint_bl_id);
			//	transform.position = Vector3(0, 0, gun_info->rs_length);
			//	base_pose->SetJointLocalPose(joint_bl_id, transform);
			//}

			//if (joint_fh_id >=0)
			//{
			//	transform = base_pose->GetJointLocalPose(joint_fh_id);
			//	transform.position = transform.position * gun_info->fh_anim_flag + Vector3(0, 0, gun_info->bl_length) * (Vector3(1,1,1) - gun_info->fh_anim_flag);
			//	base_pose->SetJointLocalPose(joint_fh_id, transform);
			//}

			//if (joint_sl_id >=0)
			//{
			//	transform = base_pose->GetJointLocalPose(joint_sl_id);
			//	transform.position = Vector3(0, 0, gun_info->fh_length);
			//	base_pose->SetJointLocalPose(joint_sl_id, transform);
			//}

			//if (joint_fire_id >=0)
			//{
			//	transform = base_pose->GetJointLocalPose(joint_fire_id);
			//	transform.position = Vector3(0, 0, gun_info->fire_offset);
			//	base_pose->SetJointLocalPose(joint_fire_id, transform);
			//}
			//if (joint_sp_id >=0)
			//{
			//	transform.position = gun_info->sp_position;
			//	transform.rotation = gun_info->sp_rotation;
			//	base_pose->SetJointLocalPose(joint_sp_id, transform);
			//}
			//if (joint_gp_id >=0)
			//{
			//	transform.position = gun_info->gp_position;
			//	transform.rotation = gun_info->gp_rotation;
			//	base_pose->SetJointLocalPose(joint_gp_id, transform);
			//}

			//int ik_id = skeleton->GetJointId("Gun_MZ");
			//const Transform & ik_arm_l = pose->GetJointModelPose(ik_id);
			//if (gGame->input->IsKeyDown(KC_N))
			//{
			//	LogSystem.WriteLinef("%f,%f,%f", ik_arm_l.position.x, ik_arm_l.position.y, ik_arm_l.position.z);
			//	//LogSystem.WriteLinef("%f,%f,%f,%f", ik_arm_l.rotation.x, ik_arm_l.rotation.y, ik_arm_l.rotation.z, ik_arm_l.rotation.w);
			//}

			//if (gGame->input->IsKeyDown(KC_M))
			//{
			//	//LogSystem.WriteLinef("%f   %f   %f", ik_arm_l.position.x, ik_arm_l.position.y, ik_arm_l.position.z);
			//	LogSystem.WriteLinef("%f,%f,%f,%f", ik_arm_l.rotation.x, ik_arm_l.rotation.y, ik_arm_l.rotation.z, ik_arm_l.rotation.w);
			//}
		}

		WeaponBase::UpdateMesh();
	}

	void GunBase::Update(float time)
	{
		WeaponBase::Update(time);


		tempc_ptr(Character) player = GetOwner();

		if (!player)
			return;

		if (!gun_info)
			return;

		last_fire_time += time;

		if (ammo_in_clip == 0 && ammo_count > 0)
			player->Reload();

		if (next_fire_time > 0)
			next_fire_time  -= time;

		if(wait_timer > 0.f && gun_info->thirdpersonviewer)
		{
			wait_timer -= time;
			if(wait_timer <= 0.f)
			{
				player->UnLockStateByType(kLSSelectWeapon);
				player->camera_distance = old_cameradistance;
				if(gLevel->GetViewer() == player)
					gGame->camera->control_mode = old_controlmode;
				player->first_action_on = false;
			}
		}

		if (reloading)
		{
			reload_time -= time;

			if (reload_time < 0)
			{
				int ammo_need = gun_info->ammo_one_clip - ammo_in_clip;

				if (ammo_need > 0)
				{
					if (ammo_need < ammo_count)
					{
						ammo_in_clip = gun_info->ammo_one_clip;
						ammo_count -= ammo_need;
						player->ReloadReady(ammo_need);
					}
					else
					{
						ammo_in_clip += ammo_count;
						player->ReloadReady(ammo_count);
						ammo_count = 0;
					}
				}

				reloading = false;
				empty = false;

				tempc_ptr(Character) player = GetOwner();

				if(player)
					player->dual_pistol_status = false;

				player->reloading = false;
				shots_fired = 0;
				decrease_shots_fired = 0;
				delay_fire = false;
				accuracy = 0.2f;
			}
		}
		else if (player->first_action_on)
		{
			if (idle_time <= 0 && next_fire_time <= 0 && (gun_info->auto_fire || delay_fire == false))
			{
				if (player->CanFire())
				{
					tempc_ptr(LuncherInfo) luncher_info = ptr_dynamic_cast<LuncherInfo>(gun_info);
					if((luncher_info && luncher_info->ammo_charge_time_max <= 0.f && luncher_info->ammo_charge_time_effective <= 0.f && luncher_info->ammo_charge_time_stable <= 0.f) || !luncher_info)
					{
						if(Fire())
						{
							if(gun_info->thirdpersonviewer)
							{
								wait_timer = gun_info->fire_time;
								player->LockStateByType(kLSSelectWeapon);
								if( player->camera_distance < 0.5f)
									old_cameradistance = 0.f;
								else
									old_cameradistance = player->camera_distance;
								old_controlmode = gGame->camera->control_mode;
								player->camera_distance = player->GetHeight() * 2;
								if(gLevel->GetViewer() == player)
									gGame->camera->control_mode = Camera::kViewMode;
								player->SetMove(0, 0);
							}
						}
					}
				}
				else
					player->StopShoot();
			}
		}
		else
		{
			if (idle_time <= 0 && next_fire_time <= 0)
			{
				player->StopShoot();
				if (delay_fire)
				{
					delay_fire = false;
					if (shots_fired > 15)
					{
						shots_fired = 15;
					}
					decrease_shots_fired += 0.4f;
				}

				if (!gun_info->auto_fire)
					shots_fired = 0;

				if (shots_fired > 0)
				{
					decrease_shots_fired -= time;
					if (decrease_shots_fired < 0)
					{
						decrease_shots_fired = 0.0225f;
						shots_fired--;
					}
				}
			}	
		}
		// for particle
		UpdateEffect(time);

		if(player->is_complete_raise)
		{
			FirstPerson &person = player->GetFirstPerson();
			if(person.animation_action && person.animation_action->IsActionPlaying() == false)
			{
				player->is_complete_raise = false;

				player->SetCameraFov(target_fov,target_fov);

				ChangeSight();
			}
			else
			{
				raise_time += time;

				int fov;
				float ratio = 1.0f;
				if(raise_time < 0.093f)
				{
					ratio = raise_time * 1000.0f / 93.f;

					if(ratio > 1.0f)
						ratio = 1.0f;

					fov = source_fov + (target_fov - source_fov) * ratio;
				}
				else
					fov = target_fov;

				player->SetCameraFov(fov,fov);

			}
		}
		else
			if (next_fire_time <= 0.1f && idle_time <= 0.1f )
				SetSightCurrent();
	}

	/// get fire position
	bool GunBase::GetJointInfo(const Core::Identifier & joint_name, Vector3 * position, Quaternion * rotation)
	{
		if (skeleton)
		{
			int joint_id = skeleton->GetJointId(joint_name);

			if (joint_id >= 0)
			{
				const Transform & transform = GetPose()->GetJointModelPose(joint_id);
				if (position)
					*position = GetPosition() + transform.position * GetRotation();

				if (rotation)
					*rotation = transform.rotation * GetRotation();

				return true;
			}
		}

		return false;
	}

	/// get fire position
	bool GunBase::GetJointInfo(int joint_id, Core::Vector3 * position, Core::Quaternion * rotation)
	{
		if (skeleton)
		{
			if (joint_id >= 0)
			{
				const Transform & transform = GetPose()->GetJointModelPose(joint_id);

				if (position)
					*position = GetPosition() + transform.position * GetRotation();

				if (rotation)
					*rotation = transform.rotation * GetRotation();

				return true;
			}
		}

		return false;
	}
	/// can reload
	bool GunBase::CanReload()
	{
		return (!reloading) && (ammo_in_clip < gun_info->ammo_one_clip) && (ammo_count > 0);
	}

	/// reload
	bool GunBase::Reload()
	{
		if (CanReload())
		{
			reloading = true;
			ReloadAction();
			reload_time = gun_info->reload_time;

			if (gun_info->is_sights)
			{
				sight_current = 0;
				sight_temp = 0;
				SetSight(0);
			}

			return true;
		}

		return false;
	}

	/// reload action
	void GunBase::ReloadAction()
	{
		if(animation)
			animation->StopAction(true);
		
		if (GetWeaponType()==kWeaponTypeShotGun)
			return;
		if (GetWeaponType()==kWeaponTypeMiniGun || GetWeaponType()==kWeaponTypeMiniMachineGun)
			return;
		if (GetWeaponType()==kWeaponTypeLuncher)
		{
			tempc_ptr(Luncher) luncher = ptr_dynamic_cast<Luncher>(this);
			if(luncher->luncher_info->reloadoneammo)
				return;
		}

		if (animation)
		{
			animation->PlayAction("reload", 0.02f);
			//animation->PlayAction("reload", 0.02f, false, gun_info? gun_info->reload_time:0 );
		}
	}

	/// reload sound
	void GunBase::ReloadSound(bool stereo)
	{
		CStrBuf<256> key;
		if (stereo)
		{
			key.format("bj/weapon/3d/%s/reload", weapon_info->sound_name.Str());

			Vector3 mz_pos;

			uint w_type = GetWeaponType();

			if(w_type!=kWeaponTypeMiniMachineGun &&
			   w_type!=kWeaponTypeLuncher &&
			   w_type!= kWeaponTypeShotGun)
			{
				tempc_ptr(Character) player = gLevel->GetPlayer();
				if (player)
				{
					if (GetJointInfo(joint_fire_id, &mz_pos, NULL))
					{
						float length = 0.f;
						length = Core::Length(player->GetPosition() - mz_pos);
						if (length < 20.f)
						{
							audio_reload = FmodSystem::GetEvent(key);
							FMOD_VECTOR pos = (const FMOD_VECTOR &)mz_pos;
							FMOD_VECTOR vel = {0, 0, 0};
							audio_reload->set3DAttributes(&pos, &vel);
							audio_reload->start();
						}
					}
				}
			}
			else if (GetWeaponType() == kWeaponTypeLuncher)
			{
				tempc_ptr(Luncher) luncher = ptr_dynamic_cast<Luncher>(this);
				if(luncher->GetLuncherAmmoType() == kWeaponTypeAmmoGrenade)
				{
					tempc_ptr(Character) player = gLevel->GetPlayer();
					if (player)
					{
						if (GetJointInfo(joint_fire_id, &mz_pos, NULL))
						{
							float length = 0.f;
							length = Core::Length(player->GetPosition() - mz_pos);
							if (length < 20.f)
							{
								audio_reload = FmodSystem::GetEvent(key);
								FMOD_VECTOR pos = (const FMOD_VECTOR &)mz_pos;
								FMOD_VECTOR vel = {0, 0, 0};
								audio_reload->set3DAttributes(&pos, &vel);
								audio_reload->start();
							}
						}
					}
				}
			}
		}
		else
		{
			uint w_type = GetWeaponType();
			if(w_type != kWeaponTypeMiniMachineGun && 
			   w_type!=kWeaponTypeLuncher && 
			   w_type!= kWeaponTypeShotGun)
			{
				key.format("bj/weapon/2d/%s/reload", weapon_info->sound_name.Str());
				audio_reload = FmodSystem::PlayEvent(key);
			}
			else if (GetWeaponType() == kWeaponTypeLuncher)
			{
				tempc_ptr(Luncher) luncher = ptr_dynamic_cast<Luncher>(this);
				if(luncher->GetLuncherAmmoType() == kWeaponTypeAmmoGrenade || luncher->GetLuncherAmmoType() == kWeaponTypeAmmoStick || luncher->GetLuncherAmmoType() == kWeaponTypeAmmoProd)
				{
					key.format("bj/weapon/2d/%s/reload", weapon_info->sound_name.Str());
					audio_reload = FmodSystem::PlayEvent(key);
				}
			}
		}
	}

	/// random float
	static float RandomFloat(F32 x, F32 y)
	{
		float r = (F32)rand() / (RAND_MAX + 1);
		float num = x + (y - x) * r;
		return num; 
	}

	/// random int
	static int RandomInt(int x, int y)
	{
		return x + (int)(rand()%(y-x));
	}

	/// fire base
	bool GunBase::FireBase(float spread)
	{
		//ENCODE_START

		tempc_ptr(Character) player = GetOwner();

		if(player)
		{
			player->bag_flag = false;
			player->is_bag_open = false;
		}

		if (!CanFire(false))
		{
			return false;
		}
		if(weapon_info->time_to_idle <= 0)
			--ammo_in_clip;
		delay_fire = true;
		++shots_fired;
		last_fire_time = 0;

		if (ammo_in_clip != 0)
			empty = false;
		

		Vector3 fire_angle = player->GetLookDir().GetZXY();
		fire_angle += player->punch_angle;

		Quaternion rot;

		rot.SetZXY(fire_angle);

		FireCheck(player->GetCameraPosition(), rot, spread);

		if (ammo_in_clip == 0)
			empty = true;

		/////////////////////////////////////////////////////////////////////////////////////////////
		//for novice
		if (gLevel->game_type == RoomOption::kNovice)
		{
			int tempid = -1;
			int gun_index = -1;
			if (gLevel->novice_index == 10)
			{
				gun_index = 0;
				tempid = 0;
			}
			else if(gLevel->novice_index == 13)
			{
				tempid = 1;
				gun_index = 0;
			}
			else if(gLevel->novice_index == 15)
			{
				tempid = 2;
				gun_index = 1;
			}

			if (gLevel->novice_index < 20)
			{
				tempc_ptr(Character) tempplayer = gLevel->GetPlayer();
				if (tempplayer && tempplayer->character_info && tempplayer->GetFirstPerson().GetWeapon(gun_index) == tempplayer->GetWeapon())
				{
					for (uint i = 0; i < gLevel->novice_guntarget_array.Size();++i)
					{
						if (gLevel->novice_guntarget_array[i]->guntarget_info->uid == tempplayer->character_info->career_id && gLevel->novice_guntarget_array[i]->GetID() == tempid)
						{
							if (tempplayer->GetWeapon() && tempplayer->GetWeapon()->GetWeaponType() == kWeaponTypeFlameGun)
							{
								sharedc_ptr(FlameGunInfo) info = ptr_dynamic_cast<FlameGunInfo>(gun_info);
								if (info && gLevel->novice_guntarget_array[i]->CheckFire(player->GetCameraPosition(), rot, spread, info->hit_distance, info->hurtrange) && gLevel->novice_guntarget_array[i]->status == GUNTARGET_UP)
								{
									gLevel->novice_guntarget_array[i]->status = GUNTARGET_DOWN;
									gLevel->novice_shoot_num--;
								}
							}
							else
							{
								if (gLevel->novice_guntarget_array[i]->CheckFire(player->GetCameraPosition(), rot, spread) && gLevel->novice_guntarget_array[i]->status == GUNTARGET_UP)
								{
									gLevel->novice_guntarget_array[i]->status = GUNTARGET_DOWN;
									gLevel->novice_shoot_num--;
								}
							}
						}
					}
				}
			}
			else
			{
				tempc_ptr(Character) tempplayer = gLevel->GetPlayer();
				if (tempplayer && tempplayer->character_info)
				{
					for (uint i = 0; i < gLevel->novice_guntarget_array.Size();++i)
					{
						if (tempplayer->GetWeapon() && tempplayer->GetWeapon()->GetWeaponType() == kWeaponTypeFlameGun)
						{
							sharedc_ptr(FlameGunInfo) info = ptr_dynamic_cast<FlameGunInfo>(gun_info);
							if (info && gLevel->novice_guntarget_array[i]->CheckFire(player->GetCameraPosition(), rot, spread, info->hit_distance, info->hurtrange) && gLevel->novice_guntarget_array[i]->status == GUNTARGET_UP)
							{
								gLevel->novice_guntarget_array[i]->status = GUNTARGET_DOWN;
							}
						}
						else
						{
							if (gLevel->novice_guntarget_array[i]->CheckFire(player->GetCameraPosition(), rot, spread) && gLevel->novice_guntarget_array[i]->status == GUNTARGET_UP)
							{
								gLevel->novice_guntarget_array[i]->status = GUNTARGET_DOWN;
							}
						}
					}
				}
			}
		}
		/////////////////////////////////////////////////////////////////////////////////////////////

		next_fire_time = gun_info->fire_time + player->fire_time_ratio;
		idle_time = weapon_info->time_to_idle;

		if (gun_info->is_sights)
		{
			if (gun_info->auto_fire == false)
			{
				sight_temp = 0;
				SetSight(0);
			}
		}

		//ENCODE_END
		return true;
	}

	/// can fire
	bool GunBase::CanFire(bool check_only)
	{
		//ENCODE_START

		tempc_ptr(Character) player = GetOwner();

		if (!player)
			return false;

		if (!gun_info)
			return false;

		if (idle_time> 0)
			return false;
			
		if (ammo_in_clip <= 0)
		{
			if (!check_only)
			{
				if(weapon_info->weapon_type != kWeaponTypeMiniMachineGun)
				{
					CStrBuf<256> key;
					key.format("bj/weapon/2d/%s/empty", weapon_info->sound_name.Str());

					FMOD::Event* audio_event = FmodSystem::PlayEvent(key);
				}

				next_fire_time = 0.4f;
			}

			return false;
		}

		//ENCODE_END
		return true;

		
	}

	/// fire effect
	void GunBase::FireCheck(const Core::Vector3 & position, const Core::Quaternion & rotation, float spread, bool do_effect)
	{
		
		//ENCODE_START

		tempc_ptr(Character) player = GetOwner();

		if (!player || !gun_info || !gPhysxScene)
			return;

		int penetration = gun_info->penetration;
		float distance = 500;
		Vector3 pos = position;
		Vector3 dir = Vector3(0, 0, -1) * rotation;
		Vector3 up_dir = Vector3(0, 1, 0) * rotation;
		Vector3 right_dir = Vector3(1, 0, 0) * rotation;

		float x, y, z;
		x = RandomFloat( -0.5, 0.5 ) + RandomFloat( -0.5, 0.5 );
		y = RandomFloat( -0.5, 0.5 ) + RandomFloat( -0.5, 0.5 );
		z = x * x + y * y;

		dir += x * spread * right_dir + y * spread * up_dir;

		dir.Normalize();

		float distance_before = 0;

		// last hit character struct
		struct
		{
			Character* p;
			Vector3 pos;
			Vector3 target;
			Vector3 normal;
			int part;
			float distance;

		}last_hit_character;

		last_hit_character.p = NULL;

		bool fire_blank = false;
		bool doeffect = do_effect;
		Array<HitMessage> hit_message;
		hit_message.Reserve(10);
		bool is_boost(false);
		if(gGame->channel_connection)
		{
			if( GetGaiLv(player->rand_fun.Rand(),player->rand_fun.GetRandMax()) * 10000 < weapon_info->hit_crit)
				is_boost = true;
		}

		while (penetration > 0)
		{
			NxRay ray;
			ray.orig = (const NxVec3 &)pos;
			ray.dir = (const NxVec3 &)dir;

			NxRaycastHit hit;
			uint group_id = 0;
			group_id |= 1 << PhysxSystem::kStatic;
			group_id |= 1 << PhysxSystem::kStaticRaycast;
			for (uint i = 0; i < 2; ++i)
			{
				if ((!gLevel->team_hurt) && i == player->GetTeam())
					continue;

				group_id |= 1 << (PhysxSystem::kGroupStart + i);
			}
			group_id |= 1 << PhysxSystem::kGroupVehicle;
			group_id |= 1 << PhysxSystem::kGroupGunTarget;
			NxShape* shape = gPhysxScene->raycastClosestShape(ray, NX_ALL_SHAPES, hit, group_id, distance);
			if (shape)
			{
				NxActor& actor = shape->getActor();
				tempc_ptr(Character) p = Character::FromNxActor(actor);

				Quaternion qdir(Vector3(0, 0, -1), dir);

				if (p != last_hit_character.p && last_hit_character.p)
				{
					//VMProtectBegin("FireCheck1");
					last_hit_character.p->ResponseHit(position, last_hit_character.target, last_hit_character.normal, last_hit_character.part,GetWeaponType(),false, is_boost);

					gLevel->Hit(last_hit_character.p, last_hit_character.target, last_hit_character.part);
					//gGame->channel_connection->Shoot(last_hit_character.pos, qdir, doeffect, last_hit_character.p->uid, last_hit_character.part, last_hit_character.distance,hurt_rate);

					// add hit message
					HitMessage & message = hit_message.PushBack();
					message.uid = last_hit_character.p->uid;
					message.part = last_hit_character.part;
					message.distance = last_hit_character.distance;
					message.position = last_hit_character.target;



					last_hit_character.p = NULL;
					penetration -= 1;

					doeffect = false;

					//VMProtectEnd();

					if (penetration <= 0)
						break;
				}

				distance -= hit.distance;
				distance_before += hit.distance;

				if (p)
				{
					int part = p->GetActorId(&actor);
					Vector3 target(hit.worldImpact.x, hit.worldImpact.y, hit.worldImpact.z);
					Vector3 normal(hit.worldNormal.x, hit.worldNormal.y, hit.worldNormal.z);

					if (last_hit_character.p != p || p->GetDamagePart(part, last_hit_character.part) == part)
					{
						last_hit_character.p = p;
						last_hit_character.pos = pos;
						last_hit_character.part = part;
						last_hit_character.target = target;
						last_hit_character.normal = normal;
						last_hit_character.distance = distance_before;
					}
				}
				else
				{
					Vector3 v(hit.worldImpact.x, hit.worldImpact.y, hit.worldImpact.z);
					if(CheckHitDummy(shape, hit_message, v, hit.distance))
					{

						penetration -= 1;
					}
					else
					{
						doeffect = false;

						switch (hit.materialIndex)
						{
						case PhysxSystem::kWood:
						case PhysxSystem::kWater:
						case PhysxSystem::kPlastic:
						case PhysxSystem::kCloth:
						case PhysxSystem::kPaper:
						case PhysxSystem::kGrass:
						case PhysxSystem::kWiregauze:
							penetration -= 1;
							break;

						default:
							penetration = 0;
							break;
						}
					}
					gLevel->AddBulletImpact((const Vector3 &)hit.worldImpact, (const Vector3 &)hit.worldNormal, hit.materialIndex);
				}

				pos = (const Vector3 &)hit.worldImpact + dir * 0.01f;
			}
			else
			{
				penetration = 0;
				fire_blank = true;
			}
		}

		Quaternion qdir(Vector3(0, 0, -1), dir);


		//VMProtectBegin("FireCheck2");
		if (last_hit_character.p)
		{
			last_hit_character.p->ResponseHit(position, last_hit_character.target, last_hit_character.normal, last_hit_character.part, GetWeaponType());

			gLevel->Hit(last_hit_character.p, last_hit_character.target, last_hit_character.part);
			//gGame->channel_connection->Shoot(last_hit_character.pos, qdir, doeffect, last_hit_character.p->uid, last_hit_character.part, last_hit_character.distance, hurt_rate);
	
			// add hit message
			HitMessage & message = hit_message.PushBack();
			message.uid = last_hit_character.p->uid;
			message.part = last_hit_character.part;
			message.distance = last_hit_character.distance;
			message.position = last_hit_character.target;

			doeffect = false;
			last_hit_character.p = NULL;
		}



		//if (fire_blank)
		//{
		//	gGame->channel_connection->Shoot(pos, qdir, doeffect);
		//}

		if (gGame->channel_connection)
		{
			gGame->channel_connection->Shoot(position, qdir, hit_message, do_effect, hurt_rate);
		}
			
		player->Shoot(position, dir, do_effect,is_boost);
		
		//VMProtectEnd();
		
		//ENCODE_END
	}

// for particle
	/// fire effect
	void GunBase::FireEffect(bool isboost)
	{
		//�޸����BUG�������ӳٵ����Ȳ���RELOAD�����������ֱ�SHOOT���������ˣ�
		reloading = false;

		// play animation
		if (animation && !IsEmpty() && GetWeaponType()!=kWeaponTypeMiniGun)
		{
			if(GetWeaponType()==kWeaponTypeDualPistol)
			{
				if(!GetOwner()->dual_pistol_status)
					animation->PlayAction("shootr", 0.f);				
				else
					animation->PlayAction("shootl", 0.f);
			}
			else
			{
				uint w_type = GetWeaponType();

				switch(w_type)
				{
				case kWeaponTypeShotGun:
				case kWeaponTypeDrum:
				case kWeaponTypeSignal:
				case kWeaponTypeLuncher:
					{
						float time = gun_info->fire_time;
						animation->PlayAction("shoot", 0.05f, 0.05f, false, time);
					}
					break;
				case kWeaponTypeSniperGun:
					{
						float time = gun_info->fire_time;
						animation->PlayAction("shoot", 0.05f, 0.05f, false);
					}
					break;
				default:
					{
						animation->PlayAction("shoot", 0.05f);
					}
					break;
				}
			}
		}

		tempc_ptr(Character) c = GetOwner();

		if (c)
		{
			tempc_ptr(GunBase) gun = ptr_dynamic_cast<GunBase>(c->GetWeapon());

			if (gun && (gun->sight_current != 0 || (c->GetViewMode() == Character::kFirstPerson && gun_info->sight_info.Size() > 0 && c->camera_fov <= gun_info->sight_info[1].level)) && gun->GetWeaponType() != kWeaponTypeSniperGun)
				return;
		}

		if(!c->occluded)
		{
			UpdateEffect(0);
			if(isboost)
			{
				if (gun_fire_particle_boost)
				{
					gLevel->AddParticle(gun_fire_particle_boost);
				}
				if (GetOwner() == gLevel->GetPlayer())
				{
					FmodSystem::PlayEvent("bj/event/crit_burst");
					c->BoostSound();
				}
				else
					c->Boost_3D_Sound();
			}
			else
			{
				if (gun_fire_particle)
					gLevel->AddParticle(gun_fire_particle);
			}
				

			if (gun_bullet_particle)
				gLevel->AddParticle(gun_bullet_particle);
		}

		if(!c->occluded)
		{
			Vector3 fire_pos;
			if(GetWeaponType()!=kWeaponTypeDualPistol)
			{
				if (GetJointInfo(joint_fire_id, &fire_pos, NULL))
				{
					gLevel->light_manager->AddPointLight(fire_pos, Vector3(255 / 255.f, 103 / 255.f, 56 / 255.f));
				}
			}
			else
			{
				if (GetJointInfo(joint_fire_l_id, &fire_pos, NULL))
					gLevel->light_manager->AddPointLight(fire_pos, Vector3(255 / 255.f, 103 / 255.f, 56 / 255.f));
				if (GetJointInfo(joint_fire_r_id, &fire_pos, NULL))
					gLevel->light_manager->AddPointLight(fire_pos, Vector3(255 / 255.f, 103 / 255.f, 56 / 255.f));
			}
		}
	}

	/// fire sound
	void GunBase::FireSound(bool stereo)
	{
		CStrBuf<256> key;
		if (stereo)
		{
			Vector3 fire_pos;

			if (GetJointInfo(joint_fire_id, &fire_pos, NULL))
			{
				tempc_ptr(Character) player = gLevel->GetPlayer();
				if (player)
				{
					if (gun_info)
						key.format("bj/weapon/3d/%s/fire", gun_info->fire_sound.Str());
					FMOD_VECTOR vel = {0, 0, 0};
					FmodSystem::Play3DEvent(key, (const FMOD_VECTOR &)fire_pos, vel);
				}
			}
		}
		else
		{
			if (gun_info)
			{
				tempc_ptr(MiniMachineGunInfo) minigun_info = ptr_dynamic_cast<MiniMachineGunInfo>(gun_info);

				if ((GetWeaponType() != kWeaponTypeMiniMachineGun) || 
					(minigun_info && minigun_info->ammo_type != kWeaponTypeNone))
				{
					key.format("bj/weapon/2d/%s/fire", gun_info->fire_sound.Str());
					FmodSystem::PlayEvent(key);
				}
			}
		}
	}

	/// kick back
	void GunBase::KickBack(float up_base, float lateral_base, float up_modifier, float lateral_modifier, float up_max, float lateral_max, int direction_change)
	{
		tempc_ptr(Character) player = GetOwner();

		if (!player)
			return;

		float kick_up;
		float kick_lateral;

		if (shots_fired == 1)
		{
			kick_up = up_base;
			kick_lateral = lateral_base;
		}
		else
		{
			kick_up = up_base + shots_fired * up_modifier;
			kick_lateral = lateral_base + shots_fired * lateral_modifier;
		}

		Vector3 angle = player->punch_angle * RAD2DEG;

		angle.x += kick_up;
		if (angle.x > up_max)
			angle.x = up_max;
		
		if (direction == 1)
		{
			angle.y += kick_lateral;
			if (angle.y > lateral_max)
			{
				angle.y = lateral_max;
			}
		}
		else
		{
			angle.y -= kick_lateral;
			if (angle.y < -lateral_max)
			{
				angle.y = -lateral_max;
			}
		}

		angle *= DEG2RAD;
		player->punch_angle = angle;

		if (direction_change && !RandomInt(0, direction_change))
			direction = 1 - direction;

		if (gGame->channel_connection)
			gGame->channel_connection->KickBack(angle);
	}

	/// change in
	void GunBase::ChangeIn()
	{
		// play animation
		if (!IsEmpty())
		{
			WeaponBase::ChangeIn();
			next_fire_time = 0.f;
		}
	}

	/// set sight current
	void GunBase::SetSightCurrent()
	{
		if(sight_temp != sight_current)
		{
			SetSight(sight_current);
			sight_temp = sight_current;
		}
	}

	/// set sight
	void GunBase::SetSight(int id)
	{
		if(!gun_info)
			return;

		int sight_size = gun_info->sight_info.Size();

		if (sight_size <= 0 || id >= sight_size)
		{
			tempc_ptr(Character) c = GetOwner();
			if (c)
				c->mouse_sensitivity = 1.0f;
			return;
		}
		tempc_ptr(Character) c = GetOwner();
		if (c)
		{
			c->SetCameraFov(gun_info->sight_info[id].level, gun_info->sight_info[id].level);
			c->mouse_sensitivity = gun_info->sight_info[id].mouse_sensitivity;
			c->fire_time_ratio = gun_info->sight_info[id].fire_speed_factor;

			gun_info->move_speed_offset	= gun_info->sight_info[id].move_speed_offset;
			c->SetMoveInfoOffset(gun_info->move_speed_offset);
		}
	}

	/// change sight
	void GunBase::ChangeSight()
	{
		if(!gun_info->is_sights)
			return;

		if(reloading)
			return;

		tempc_ptr(Character) player = GetOwner();
		if (!player)
			return;

		if(player->weapon_select_state != Character::kWeaponReady)
			return;

		if(!gun_info)
			return;

		int sight_size = gun_info->sight_info.Size();

		if(sight_size > 1)
		{
			FirstPerson &person = player->GetFirstPerson();
			if(person.animation_action && sight_current == 0 && player->is_complete_raise == false && is_play == false)
			{
				player->is_complete_raise = true;
				if (person.animation_action)
					person.animation_action->PlayAction("raise",0.0f);

				source_fov = gun_info->sight_info[0].level;
				target_fov = gun_info->sight_info[1].level;

				raise_time = 0.0f;

				is_play = true;
				return;
			}

			if(person.animation_action && sight_current == sight_size - 1 && player->is_complete_raise == false && is_play == false)
			{
				player->is_complete_raise = true;
				if (person.animation_action)
					person.animation_action->PlayAction("lower",0.0f);

				source_fov = gun_info->sight_info[sight_size - 1].level;
				target_fov = gun_info->sight_info[0].level;

				raise_time = 0.0f;

				is_play = true;
				return;
			}

			is_play = false;

			sight_temp = sight_current;
			sight_current += 1;
			sight_current = sight_current % sight_size;

			SetSight(sight_current);
		}	
	}

	/// draw ui
	void GunBase::DrawUI(by_ptr(UIRender) ui_render)
	{
		WeaponBase::DrawUI(ui_render);
		tempc_ptr(Character) viewer = GetOwner();
		if (viewer)
		{
			Core::CStrBuf<256> buff;

			buff.format("/%d", ammo_count);
			ui_render->DrawStringShadow(ui_render->font_simhei_24, ARGB(255, 241, 211), ARGB(0,0,0), ARGB(0, 0, 0, 0), Core::Rectangle(-180, 0 - 50, 0, 1), buff, Unit::kAlignLeftBottom);
			buff.format("%d", ammo_in_clip);
			ui_render->DrawStringShadow(ui_render->font_simhei_24, ARGB(255, 241, 211), ARGB(0,0,0), ARGB(0, 0, 0, 0), Core::Rectangle(0, 0 - 50, -180, 1), buff, Unit::kAlignRightBottom);

			buff.format(weapon_info->name);
			buff.toupper();

			ui_render->DrawStringShadow(ui_render->font_simhei_14, ARGB(255, 241, 211), ARGB(0,0,0), ARGB(0, 0, 0, 0), Core::Rectangle(-100, -20, 0, -7), buff, Unit::kAlignCenterBottom);
		}
	}

	/// get aabb
	const AxisAlignedBox& WeaponBase::GetWorldAABB()
	{
		return world_aabb;
	}

	/// get local aabb
	const AxisAlignedBox& WeaponBase::GetLocalAABB()
	{
		return local_aabb;
	}

	void WeaponBase::SpecialAbilities( bool keydown /*= false*/ )
	{

	}

	bool WeaponBase::ChargeAbilities()
	{
		return false;
	}

	void WeaponBase::UpdateViewerAnimation( float time )
	{

	}
 
	bool WeaponBase::CheckHitDummy(NxShape* shape, Array<HitMessage>& message_array, const Vector3& target, float distance)
	{
		NxActor& actor = shape->getActor();
		tempc_ptr(DummyObject) dummy = DummyObject::FromNxActor(actor);
		if(dummy)
		{
			// add hit message
			HitMessage & message = message_array.PushBack();
			message.dummyid = dummy->dummyobjectinfo->dummy_id;
			message.distance = distance;
			message.position = target;
			message.uid = dummy->dummyobjectinfo->owner_id;
			message.target_type = HitMessage::Dummy;

			return true;
		}

		return false; 
	}

}
