#include "pch.h"

using namespace Core;
using namespace Client;

DEFINE_PDE_TYPE_CLASS(Client::FlameGunInfo)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Client::GunInfo);
		//ADD_PDE_FIELD(lasthurt);
		//ADD_PDE_FIELD(lasttime);
		//ADD_PDE_FIELD(special_distance);
		//ADD_PDE_FIELD(special_range);
		//ADD_PDE_FIELD(special_lasttime);
		//ADD_PDE_FIELD(special_hurt);
		//ADD_PDE_FIELD(special_lasthurt);
		//ADD_PDE_FIELD(particlenum);
		//ADD_PDE_FIELD(show_speed);
		ADD_PDE_FIELD(flame_particle);
		ADD_PDE_DEFAULT_CONSTRUCTOR();
	}
};


DEFINE_PDE_TYPE_CLASS(Client::FlameGun)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Client::GunBase);

		ADD_PDE_PROPERTY_R(weapon_info);
	}
};

REGISTER_PDE_TYPE(Client::FlameGunInfo);
REGISTER_PDE_TYPE(Client::FlameGun);

namespace Client
{
	FlameGun::FlameGun(by_ptr(FlameGunInfo) info)
	{
		//info->fire_time =0.1f;
		weapon_info = gun_info = flamegun_info = info;
		skill = ptr_new(PlayerSkill);
		skill->type = kSkillWindReverse;
		skill->effect_time = info->special_lasttime;
		skill->uid = 0;
		has_trajectory = true;
		
	}
	/// destructor
	FlameGun::~FlameGun()
	{
		dequeFlame.Clear();
		arry_windprojected.Clear();
		arry_windcharacter.Clear();
		if(!windparticle->IsDead())
			windparticle->SetDead();
		tempc_ptr(Character) owner = GetOwner();
		if(owner)
			owner->UnLockStateByType(kLSSelectWeapon);
	}
	void FlameGun::Initialize()
	{		
		GunBase::Initialize();
		sharedc_ptr(FlameParticle) particle;
		CStrBuf<256> key(weapon_info->sound_name.Str());
		key.format("%s_%s", flamegun_info->flame_particle.Str(), is_for_player ? "1st" : "3rd");
		particle = ptr_new FlameParticle;
		particle->particle =  ptr_new ParticleSystem(key,true);
		dequeFlame.Add(particle);
		if(!windparticle)
		{
			CStrBuf<256> key;
			key.format("%s_%s", "coldair_muzl", is_for_player ? "1st" : "3rd");
			windparticle = ptr_new ParticleSystem(key,false);
			//windparticle->SetEnable(false);
		}
	}

	/// can active
	bool FlameGun::CanActive()
	{
		return GunBase::CanActive();
	}

	/// active
	void FlameGun::Active()
	{

		GunBase::Active();
		
		/*if(windparticle)
		{
			gLevel->AddParticle(windparticle);
			windparticle->SetEnable(false);
		}*/
	}

	/// inactive
	void FlameGun::Inactive()
	{
		GunBase::Inactive();
		tempc_ptr(Character) owner = GetOwner();
		if(owner)
			owner->UnLockStateByType(kLSSelectWeapon);
		
	/*	if(windparticle)
		{
			gLevel->RemoveParticle(windparticle);
		}*/
	}

	/// update
	void FlameGun::UpdateEffect(float time)
	{
		GunBase::UpdateEffect(time);
		tempc_ptr(Character) owner = GetOwner();
		//if(owner->occluded)
		//{
		//	return;
		//}
		//F32 speed = owner->GetCurrentSpeed().Length();
		//Vector3 dir = Vector3(0,0,-1) * owner->GetLookDir();
		//Vector3 movition = owner->GetMove();
		//F32 cosangle = Dot(movition.Normalize(),dir.Normalize());

		for(U32 i = 0; i < dequeFlame.Size(); i++)
		{
			if(dequeFlame[i]->particle->IsDead())
			{
				continue;
			}

			F32 speed = dequeFlame[i]->speed;// + speed * cosangle;

			if(dequeFlame[i]->distance1 <= dequeFlame[i]->nowdistance1 && dequeFlame[i]->havedct2)
			{
				speed = speed/2;
				if(dequeFlame[i]->distance2 > dequeFlame[i]->nowdistance2)
				{
					dequeFlame[i]->nowdistance2 += speed * time;
					dequeFlame[i]->curpos += dequeFlame[i]->direction2 * speed * time;
					dequeFlame[i]->particle->SetPosition(dequeFlame[i]->curpos);
				}
			}
			else
			{
				if(dequeFlame[i]->distance1 > dequeFlame[i]->nowdistance1)
				{

					dequeFlame[i]->nowdistance1 += speed * time;
					dequeFlame[i]->curpos += dequeFlame[i]->direction1 * speed * time;
					dequeFlame[i]->particle->SetPosition(dequeFlame[i]->curpos);
				}
			}
			//dequeFlame[i]->particle->Update(time);
		}
		


		tempc_ptr(FlameGun) third_fg = ptr_dynamic_cast<FlameGun>(owner->GetThirdPresonWeapon());
		tempc_ptr(FlameGun) frist_fg = ptr_dynamic_cast<FlameGun>(owner->GetWeapon(true));

	
		Vector3  position;
		Quaternion  rotation;
			
		if(GetJointInfo(joint_fire_id, &position, &rotation))
		{
			windparticle->SetPosition(position);
			windparticle->SetRotation(rotation);
		}
		float windreverse_time = owner->windreverse_time;
		tempc_ptr(Character) viewer = gLevel->GetViewer();
		bool baddparticle = false;
		if(windreverse_time > 0.f)
		{
			if(windreverse_time == skill->effect_time)
				baddparticle = true;
			if (windreverse_time <= 0.f)
			{
				windparticle->SetDead();
			}
		}

		if(owner->IsReady())
		{
			if(viewer && viewer == owner)
			{
				
				if(viewer->GetViewMode() == Character::kFirstPerson)
				{
					if(this == third_fg)
					{
						windparticle->SetDead();
					}
					else
					{
						third_fg->windparticle->SetDead();
						if(!owner->IsDied() && windreverse_time > 0.f)
						{
							if(baddparticle)
								gLevel->AddParticle(windparticle);
						}
						else
						{
							windparticle->SetDead();
						}
					}
				}
				else
				{
					if(this == third_fg)
					{
						if(frist_fg)
						{
							frist_fg->windparticle->SetDead();
						}
						if(!owner->IsDied() && windreverse_time > 0.f)
						{
							if(baddparticle)
								gLevel->AddParticle(windparticle);
						}
						else
							windparticle->SetDead();
					}
					else
					{
						windparticle->SetDead();
					}
				}
			}
			else
			{
				if(this == third_fg)
				{
					if(frist_fg)
					{
						frist_fg->windparticle->SetDead();
					}
					if(!owner->IsDied() && windreverse_time > 0.f)
					{
						if(baddparticle)
							gLevel->AddParticle(windparticle);
					}
					else
					{
						windparticle->SetDead();
					}
				}	
				else
				{
					windparticle->SetDead();
				}	
			}
		}
	}



	/// get weapon type
	uint FlameGun::GetWeaponType()
	{
		return kWeaponTypeFlameGun;
	}

	/// fire
	bool FlameGun::Fire()
	{
		tempc_ptr(Character) player = GetOwner();
		if (!player)
			return false;
		float windreverse_time = player->windreverse_time;
		if (windreverse_time > 0.f)
			return false;
		if (!FireBase(0))
			return false;

		return true;
	}


	void FlameGun::SpecialAbilities(bool keydown)
	{
		if(!keydown)
			return;

		tempc_ptr(Character) player = GetOwner();
		if (!player || player->IsAttributeExist(kEffect_Special_CannotOutFlame))
			return;

		float windreverse_time = player->windreverse_time;
		if(player->weapon_select_state != Character::kWeaponReady)
			return;
		if(windreverse_time > 0.f)
			return;
		//if(ammo_in_clip < 5)
		//	return;

		player->LockStateByType(kLSSelectWeapon);
		//ammo_in_clip -= 5;
		
		if(player)
		{
			skill->uid = player->uid;
			gGame->channel_connection->UseSkill(skill);
			//Core::Console.WriteLine("wind reverse!");
			player->windreverse_time = skill->effect_time;
		
		}
		
		
	}
	const Vector3 FlameGun::GetFirePos()
	{
		Vector3 pos;
		GetJointInfo(joint_fire_id,&pos,NULL);
		return pos;
	}

	void FlameGun::FireEffect(bool isboost)
	{
		tempc_ptr(Character) player = GetOwner();
		if (!player || !gun_info || !gPhysxScene || player->occluded)
			return;
		Vector3 pos;
		Quaternion rot;
		GetJointInfo(joint_fire_id,&pos,&rot);
		Vector3 dir =Vector3(0, 0,-1) * player->GetLookDir();
		dir.Normalize();

		F32 firedistance = flamegun_info->hit_distance;
		//��̬������ײ��⣬����ȡ����ײ���룬���ݴ˾�����������ײ�ж�
		NxU32 staticGroups = 0;
		staticGroups |= 1 << PhysxSystem::kStatic;
		staticGroups |= 1 << PhysxSystem::kGroupVehicle;
		NxRay ray;
		NxRaycastHit hit;
		Vector3 dispos = player->GetCameraPosition() - pos;
		F32 vctlen = dispos.Length() + 0.1f;
		ray.orig =(const NxVec3 &) player->GetCameraPosition();
		ray.dir = (const NxVec3 &)dir;
		NxShape* shape = gPhysxScene->raycastClosestShape(ray, NX_ALL_SHAPES, hit, staticGroups,vctlen);
		if(shape > 0)
		{
			firedistance = hit.distance;
		}
		else
		{
			ray.orig = (const NxVec3 &)pos;
			ray.dir = (const NxVec3 &)dir;


			NxShape* shape = gPhysxScene->raycastClosestShape(ray, NX_ALL_SHAPES, hit, staticGroups, firedistance + 0.6f);
			if(shape > 0)
			{
				if(hit.distance > firedistance)
				{
					firedistance += (hit.distance - firedistance);
				}
				else
				{
					firedistance = hit.distance -0.6f;
				}

			}
		}

		
		sharedc_ptr(FlameParticle) particle;
		if(dequeFlame.Size() >= flamegun_info->particlenum)
		{
			particle = dequeFlame.Front();
			dequeFlame.PopFront();
			dequeFlame.PushBack(particle);
			particle->particle->ResetEmittersParticles();
			particle->nowdistance1 = 0.f;
			particle->nowdistance2 = 0.f;
		}
		else
		{
			CStrBuf<256> key(weapon_info->sound_name.Str());
			key.format("%s_%s", flamegun_info->flame_particle.Str(), is_for_player ? "1st" : "3rd");
			particle = ptr_new FlameParticle;
			particle->particle =  ptr_new ParticleSystem(key);
			dequeFlame.Add(particle);
		}
		particle->particle->SetPosition(pos);
		particle->particle->SetRotation(rot);
		particle->speed = flamegun_info->show_speed;  //2m per second
		particle->direction1 = dir;
		particle->distance1 = firedistance;
		particle->curpos = pos;
		if(firedistance < flamegun_info->hit_distance)
		{
			Vector3 planenormal(hit.worldNormal.x,hit.worldNormal.y,hit.worldNormal.z);
			planenormal.Normalize();
			F32 cosangle = Dot(planenormal,-dir);
			if(cosangle == 1)
			{
				particle->havedct2 = false;
			}
			else
			{

				F32 normaldistance = firedistance * cosangle;
				particle->direction2 = dir * firedistance + planenormal * normaldistance ;
				particle->direction2.Normalize();
				particle->distance2 = (flamegun_info->hit_distance - firedistance) * (1 - cosangle);
				particle->havedct2 = true;

				ray.orig = (const NxVec3 &)(particle->curpos + particle->direction1 * particle->distance1);
				ray.dir = (const NxVec3 &)particle->direction2;
				NxShape* shape = gPhysxScene->raycastClosestShape(ray, NX_ALL_SHAPES, hit, staticGroups, particle->distance2 + 0.6f);
				if(shape)
				{
					if(hit.distance > particle->distance2)
					{
						particle->distance2 += (hit.distance - particle->distance2);
					}
					else
					{
						particle->distance2 = hit.distance  -0.6f;
					}

				}	
			}
		}
		else
		{
			particle->havedct2 = false;
		}
		animation->PlayAction("shoot", 0.2f);
		gLevel->AddParticle(particle->particle);

		if(isboost)
		{
			if (gun_fire_particle_boost)
				gLevel->AddParticle(gun_fire_particle_boost);
			player->BoostSound();
			FmodSystem::PlayEvent("bj/event/crit_burst");
		}
		else
		{
			if (gun_fire_particle)
				gLevel->AddParticle(gun_fire_particle);	
		}
	}

	void FlameGun::FireCheck( const Core::Vector3 & position, const Core::Quaternion & rotation, float spread, bool do_effect)
	{
		//ENCODE_START

		tempc_ptr(Character) player = GetOwner();

		if (!player || !gun_info || !gPhysxScene)
			return;

		float distance = flamegun_info->hit_distance;


		Vector3 dir = Vector3(0, 0, -1) * rotation;
		Vector3 scanprange(flamegun_info->hurtrange,flamegun_info->hurtrange,0.001f);
		Core::Matrix44 rotmatrix(rotation);

		dir.Normalize();

		F32 firedistance = flamegun_info->hit_distance;
		//��̬�������߼�⣬����ȡ��������룬���ݴ˾��������յ��˺���Χ���
		NxU32 staticGroups = 0;
		staticGroups |= 1 << PhysxSystem::kStatic;
		staticGroups |= 1 << PhysxSystem::kGroupVehicle;
		NxRay ray;
		ray.orig = (const NxVec3 &)position;
		ray.dir = (const NxVec3 &)dir;
		NxRaycastHit rayhit;

		NxShape* shape = gPhysxScene->raycastClosestShape(ray, NX_ALL_SHAPES, rayhit, staticGroups, firedistance);
		if(shape != 0)
		{
			NxActor& actor = shape->getActor();
			tempc_ptr(DummyObject) dummy = DummyObject::FromNxActor(actor);
			if(!dummy)
			{
				firedistance = rayhit.distance ;
				if(firedistance < 0.1f)
					firedistance = 0.1f;
			}
		}

		Vector3 firemotion = dir * firedistance;


		//�������״
		NxMat33 matt;
		matt.setRow(0,NxVec3(rotmatrix._11,rotmatrix._12,rotmatrix._13));
		matt.setRow(1,NxVec3(rotmatrix._21,rotmatrix._22,rotmatrix._23));
		matt.setRow(2,NxVec3(rotmatrix._31,rotmatrix._32,rotmatrix._33));
		NxBox FlameBox((const NxVec3 &)position,(const NxVec3 &)scanprange,matt);
		
		Array<HitMessage> hit_message;
		hit_message.Reserve(10);
		//������ײ������
		NxU32 activeGroups = 0;
		for (uint i = PhysxSystem::kGroupStart; i <= PhysxSystem::kGroupEnd; ++i)
		{
			activeGroups |= 1 << i;
		}

		activeGroups |= 1 << PhysxSystem::kStatic;

		NxSweepQueryHit hit[200];
		//�������վ���������˺���Χ
		NxU32 num = gPhysxScene->linearOBBSweep(FlameBox,(const NxVec3 &)firemotion,NX_SF_DYNAMICS|NX_SF_ALL_HITS,NULL, 200, hit, NULL , activeGroups);
		//static Core::Array<tempc_ptr(AutoMachineGun)> arry_autogun;
		for(NxU32 i = 0; i < num ;i++)
		{
			Core::Vector3 vct(hit[i].point.x, hit[i].point.y, hit[i].point.z);
			vct = vct - position;
			if(vct.Length() > distance)
				continue;
			float distance = vct.Length();

			if(hit[i].hitShape->getGroup() >= PhysxSystem::kGroupStart  && hit[i].hitShape->getGroup() <= PhysxSystem::kGroupEnd)
			{
				NxActor &actor = hit[i].hitShape->getActor();

				tempc_ptr(Character) p = Character::FromNxActor(actor);
				if (p && p != player)
				{
					if(!arry_character.Empty() && arry_character.Contains(p))
						continue;

					arry_character.PushBack(p);
					int part = p->GetActorId(&actor);

				
					//gGame->channel_connection->FlameShoot(position, qdir, false ,p->uid, part, distance, hurt_rate);
					HitMessage & message = hit_message.PushBack();
					message.uid = p->uid;
					message.part = part;
					message.distance = distance;		
				}
			}
			else if(hit[i].hitShape->getGroup() == PhysxSystem::kStatic)
			{
				Vector3 v(0,0,0);
				CheckHitDummy(hit[i].hitShape, hit_message, v, distance);
			}
		}
		Quaternion qdir(Vector3(0, 0, -1), dir);
		bool is_boost(false);



		if (gGame->channel_connection)
		{
			if( GetGaiLv(player->rand_fun.Rand(),player->rand_fun.GetRandMax()) * 10000 < weapon_info->hit_crit)
				is_boost = true;
			gGame->channel_connection->FlameShoot(position, qdir, hit_message, do_effect, hurt_rate);
		}
		//arry_autogun.Clear();
		arry_character.Clear();

		player->Shoot(dir,do_effect,is_boost);
		
	
		//ENCODE_end
	}

	void FlameGun::Update( float time )
	{
		GunBase::Update(time);
		tempc_ptr(Character) player = GetOwner();
		if(!player)
			return;
		float windreverse_time = player->windreverse_time;
		if(windreverse_time <= 0.0f)
			player->UnLockStateByType(kLSSelectWeapon);
	}


	U32 FlameGun::CheckWindReverse()
	{
		tempc_ptr(Character) player = GetOwner();
		if(player->windreverse_time == skill->effect_time)
			UpdateEffect(0.f);
		Vector3 velocity =  Vector3(0, 0, -1) * player->GetLookDir();// * frame_time /*time_step*/;
		velocity.Normalize();
		F32 distance = flamegun_info->special_distance;
		velocity *= distance;
		//ǽ������״
		NxCapsule mWindstaticCapsule;
		mWindstaticCapsule.p0 = (const NxVec3 &)GetFirePos();
		mWindstaticCapsule.p1 = mWindstaticCapsule.p0 ;
		mWindstaticCapsule.radius = 0.001f;
		//�������״
		NxCapsule mWindTestCapsule;
		mWindTestCapsule.p0 = (const NxVec3 &)GetFirePos();
		mWindTestCapsule.p1 = mWindTestCapsule.p0 ;
		mWindTestCapsule.radius = flamegun_info->special_range;

		//��̬������ײ��⣬����ȡ����ײ���룬���ݴ˾�����������ײ�ж�
		NxSweepQueryHit statichit;
		NxU32 staticGroups = 0;
		staticGroups |= 1 << PhysxSystem::kStatic;

		NxU32 num = gPhysxScene->linearCapsuleSweep(mWindstaticCapsule, (const NxVec3 &)velocity, NX_SF_STATICS, NULL, 1, &statichit, NULL , staticGroups);

		if(num > 0)
		{
			velocity = velocity * statichit.t;
			distance *= statichit.t;
		}
		//������ײ������
		NxU32 activeGroups = 0;
		for (uint i = PhysxSystem::kGroupStart; i <= PhysxSystem::kGroupEnd; ++i)
		{
			activeGroups |= 1 << i;
		}
		for (uint i = PhysxSystem::kGroupProjectStart; i <= PhysxSystem::kGroupProjectEnd; ++i)
		{
			activeGroups |= 1 << i;
		}
		activeGroups |=  1 << PhysxSystem::kPlayer;
		
		NxSweepQueryHit hit[200];
		//�������վ��뱩������ײ
		num = gPhysxScene->linearCapsuleSweep(mWindTestCapsule, (const NxVec3 &)velocity, NX_SF_DYNAMICS|NX_SF_ALL_HITS, NULL, 200, hit, NULL , activeGroups);
		if (num > 0)
		{
			NxSweepQueryHit *pHit = hit;
			for(NxU32 i = 0; i < num ;i++)
			{

				Core::Vector3 vct(pHit->point.x, pHit->point.y, pHit->point.z);
				vct = vct - GetFirePos();
				if(vct.Length() > distance)
					continue;

				NxActor &act = pHit->hitShape->getActor();
				if(0)//pHit->hitShape->getGroup() >= PhysxSystem::kGroupProjectStart  && pHit->hitShape->getGroup() <= PhysxSystem::kGroupProjectEnd
				{
					tempc_ptr(AmmoBase) projectedammo = ptr_dynamic_cast<Ammo>(static_cast<Core::Object*>(act.userData));

					if (projectedammo)// && projectedammo->uid == gLevel->GetPlayer()->uid
					{
						if(!arry_windprojected.Empty() && arry_windprojected.Contains(projectedammo))
							continue;

						bool bcontinue = false;
						if(projectedammo->type !=kWeaponTypeAmmoMeditNeedle)
						{
							tempc_ptr(Level::AmmoSet) ammoset = gLevel->character_ammoset.Get(gLevel->GetPlayer()->uid, NullPtr);
							if(ammoset)
							{
								Level::AmmoSet::Enumerator ammoitor(*ammoset);
								while (ammoitor.MoveNext())
								{
									tempc_ptr(AmmoBase) ammo = ammoitor.Value();
									if(ammo == projectedammo)
									{
										bcontinue = true;
									}
								}
							}
							
						}
						else
						{
							bcontinue = true;
						}
						if (!projectedammo->is_dead && bcontinue)
						{
							arry_windprojected.PushBack(projectedammo);
							switch(projectedammo->type)
							{
							case kWeaponTypeAmmoRocket:
							case kWeaponTypeAmmoArrow:
								{
									Core::Vector3 velocity;
									projectedammo->GetVelocity(velocity);
									Core::Vector3 dir(0,0,-1);
									dir = dir * player->GetLookDir();
									dir.Normalize();
									velocity = dir * velocity.Length();
									projectedammo->SetVelocity(velocity);
									projectedammo->ChangeAmmoTeam(player->GetTeam());
								/*	if(gGame->channel_connection)
									{
										gGame->channel_connection->ChangeAmmoTeam(projectedammo->ammoindex,player->GetTeam() );
									}*/
								}
								break;
								//notice:should not break in this case
							case kWeaponTypeAmmoStick:
								{
									tempc_ptr(Ammo) ammo = ptr_dynamic_cast<Ammo>(projectedammo);
									if (ammo)
										ammo->SetStickable(false);
								}
							case kWeaponTypeAmmoMeditNeedle:
							case kWeaponTypeAmmoGrenade:
							case kWeaponTypeAmmoBloodDisk:
							case kWeaponTypeAmmoProd:
								{
									Core::Vector3 velocity;
									projectedammo->GetVelocity(velocity);
									Core::Vector3 dir(0,0,-1);
									dir = dir * player->GetLookDir();
									dir.Normalize();
									if(velocity.Length() >= 1.0f)
									{
										velocity = dir * (velocity.Length() * 1.5f);
										act.setLinearVelocity((NxVec3&)velocity);
									}
									else
									{
										velocity = dir * 20;
										act.setLinearVelocity((const NxVec3&)velocity);
									}


								}
								break;

							default:
								break;
							}

						}
					}
				}
				else  if(pHit->hitShape->getGroup() == PhysxSystem::kGroupStart + player->GetTeam())			//PhysxSystem::kPlayer
				{
					tempc_ptr(Character) player_triggerIN = ptr_dynamic_cast<Character>(static_cast<Core::Object*>(act.userData));
					if (player_triggerIN && player_triggerIN != player  && gLevel->GetPlayer() && player == gLevel->GetPlayer())
					{
						if(player_triggerIN->special_mode == kSustainFlameState)
						{
							player_triggerIN->BurnStop();
							gGame->channel_connection->StopBurn(player_triggerIN->uid);
						}
						
					}
				}				
				else if(0)		//pHit->hitShape->getGroup() == PhysxSystem::kPlayer
				{
					tempc_ptr(Character) player_triggerIN = ptr_dynamic_cast<Character>(static_cast<Core::Object*>(act.userData));
					if (player_triggerIN)
					{
						if(!arry_windcharacter.Empty() && arry_windcharacter.Contains(player_triggerIN))
							continue;
						//jump
						if(player_triggerIN != player && player->GetTeam() != player_triggerIN->GetTeam())
						{
							if( gLevel->GetPlayer() && player_triggerIN == gLevel->GetPlayer())
							{
								arry_windcharacter.PushBack(player_triggerIN);
								player_triggerIN->AmmoJump(player->GetPosition(),true,0.4f);
							}

						}
					}
				}
				 
				pHit++;
			}
		}

		
		return arry_windprojected.GetCount() + arry_windcharacter.GetCount();
	}

	void FlameGun::EndCheckWindReverse()
	{
		tempc_ptr(Character) owner = GetOwner();
		if(!owner)
			return;
			
		if(owner->windreverse_time <= 0.0f)
		{
			if(arry_windprojected.Size())
			{
				arry_windprojected.Clear();
			}
			if(arry_windcharacter.Size())
			{
				arry_windcharacter.Clear();
			}	
		}
	}



}
