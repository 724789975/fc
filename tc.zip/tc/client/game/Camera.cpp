#include "pch.h"

using namespace Core;
using namespace Client;


Camera::Camera()
: position(0, 0, 0)
, rotation(Quaternion::kIdentity)
, aspect(1.0)
, target_distance(0)
, distance(0)
, m_Far(1000.f)
, m_Near(0.05f)
, control_mode(kCharacterControl)
, fov(90)
, target_fov(90)
, lock_camera(false)
, wide_screen_mode(false)
, isendfind(false)
, direction_rotation(0.f)
{
	frustum.Update(Matrix44::kIdentity);
}

void Camera::FreeMove(Core::Vector3 move, Core::Vector2 rotate)
{
	if (lock_camera)
		return;

	Vector3 camera_right = Vector3(1, 0, 0) * rotation;
	Vector3 camera_up(0, 1, 0);

	Quaternion qRotHorizontal(camera_up, -rotate.x);
	Quaternion qRotVertical(camera_right, -rotate.y);

	rotation = rotation * (qRotVertical * qRotHorizontal);
	rotation.Normalize();

	TransformNormal(move, move, rotation);
	position -= move;
}

// rotate
void Camera::LookAt(Core::Vector3 target, Core::Vector2 rotate)
{
	Vector3 camera_right = Vector3(1, 0, 0) * rotation;
	Vector3 camera_up(0, 1, 0);

	Quaternion qRotHorizontal(camera_up, -rotate.x);
	Quaternion qRotVertical(camera_right, -rotate.y);

	// rotation
	rotation = rotation * (qRotVertical * qRotHorizontal);

	// position
	position = target + Vector3(0, 0, -1) * rotation * distance;
}

// pool back
void Camera::PoolBack(float d)
{
	distance = Clamp(distance + d, 0, 4);
}

// calculate view matrix
void Camera::CalculateViewProjectionMatrix(Core::Matrix44 & view, Core::Matrix44 & projection) const
{
	view.SetRotationQuaternion(rotation.Conjugate());
	view.TranslateLocal(-position);

	float xScale;
	float yScale;

	{
		xScale = Ctan(fov * Core::DEG2RAD / 2);
		yScale = xScale * aspect;
	}

	projection.x = Vector4(xScale, 0, 0, 0);
	projection.y = Vector4(0, yScale, 0, 0);
	projection.z = Vector4(0, 0, m_Far / (m_Near - m_Far), -1);
	projection.w = Vector4(0, 0, m_Near * m_Far / (m_Near - m_Far), 0);
}

// update aspect
void Camera::UpdateAspect(const Core::Vector2 & size)
{
	if (size.y != 0)
		aspect = size.x / size.y;
	else
		aspect = 1;

	if (aspect > (4.f / 3.f))
		wide_screen_mode = true;
	else
		wide_screen_mode = false;
}

// frame update
void Camera::FrameUpdate(by_ptr(Character) viewer, float frameTime)
{
	if (lock_camera)
		return;

	if (control_mode == kDiedMode)
	{
		if(isendfind && Core::Length(position - goal_position) > 2.f)
		{
			Vector3 move(0, 0, 0);
			Core::Lerp(move, position, goal_position, frameTime * 4.5f);
			position = move;
			rotation = Quaternion(Vector3(0,0,-1), (goal_position - position)) ;
			move = rotation.GetZXY();
			move.z = 0;
			rotation.SetZXY(move);
			rotation.Normalize();
		}
		else if (isendfind)
		{
			rotation = Quaternion(Vector3(0,0,-1), (goal_position - position)) ;
			Vector3 move = rotation.GetZXY();
			move.z = 0;
			rotation.SetZXY(move);
			rotation.Normalize();
			isendfind = false;
			if (gGame->render && gGame->render->render_pipeline)
			{
				gGame->render->render_pipeline->m_bSaveScreen = true;
				gGame->render->render_pipeline->m_bUseSavedScreen = true;
			}
		}
	}

	if (viewer)
	{
		if (control_mode == kCharacterControl)
		{
			gLevel->SetCameraMode(viewer->camera_control_mode);
			position = viewer->camera_position;
			rotation = viewer->camera_rotation;
			distance = viewer->camera_distance;
		}

		switch (control_mode)
		{
		case kCharacterControl:
		case kViewMode:
			{
				distance = viewer->camera_distance;

				if (viewer->IsDied())
				{
					rotation = viewer->GetCameraRotation();

					Vector3 angle = viewer->camera_rotation_offset.GetZXY();
					Quaternion look_horizontal(Vector3(0, 1, 0), angle.y);
					Quaternion look_vertical(Vector3(1, 0, 0) * rotation, angle.x);

					fov = viewer->camera_fov;
					target_fov = viewer->camera_target_fov;
					position = viewer->GetCameraPosition() + distance * Core::Vector3(0, 0, 1) * rotation;

					// ray cast
					NxCapsule testCapsule;
					testCapsule.radius	= 0.05f;
					testCapsule.p0		= (const NxVec3 &)last_position;
					testCapsule.p1		= testCapsule.p0;

					uint flags = NX_SF_STATICS;
					NxSweepQueryHit hit;
					uint result = gPhysxScene->linearCapsuleSweep(testCapsule, (NxVec3 &)(position - last_position), flags, NULL, 1, &hit, NULL);

					if (result)
						position = last_position;
				}
				else if (viewer->GetViewMode() == Character::kFirstPerson)
				{
					fov = viewer->camera_fov + viewer->camera_fov_change;
					target_fov = viewer->camera_target_fov + viewer->camera_fov_change;

					rotation = viewer->GetCameraRotation();

					Quaternion look_direction(Vector3(0, 0, 1) * rotation, direction_rotation * DEG2RAD );
					rotation = rotation * look_direction;

					position = viewer->GetCameraPosition() + distance * Core::Vector3(0, 0, 1) * rotation;
					
				}
				else
				{
					fov = NORMAL_FOV;
					target_fov = NORMAL_FOV;
					rotation = viewer->camera_rotation_offset * viewer->GetCameraRotation();
					Vector3 target_pos = viewer->GetCameraPosition() + Vector3(-0.15f, -0.2f, 0) * rotation;
					Vector3 target_dir = Normalize(Vector3(0.15f, 0.30f, 1)) * rotation;

					// ray cast
					NxCapsule testCapsule;
					testCapsule.radius	= 0.05f;
					testCapsule.p0		= (const NxVec3 &)target_pos;
					testCapsule.p1		= testCapsule.p0;

					uint flags = NX_SF_STATICS;
					NxSweepQueryHit hit;
					uint result = gPhysxScene->linearCapsuleSweep(testCapsule, (NxVec3 &)target_dir * distance, flags, NULL, 1, &hit, NULL);

					float dis = distance;
					if (result)
						dis *= hit.t;

					position = target_pos + dis * target_dir;
				}
			}
			break;

		default:
			{
				fov = NORMAL_FOV;
				target_fov = NORMAL_FOV;
			}
			break;
		}

		last_position = position;
	}

	float fov_change = 180 * frameTime;

	if (Abs(target_fov - fov) < fov_change)
		fov = target_fov;
	else if (fov < target_fov)
		fov += fov_change;
	else
		fov -= fov_change;
	
	CalculateViewProjectionMatrix(viewMatrix, projMatrix);
	viewprojMatrix = viewMatrix * projMatrix;
	frustum.Update(viewprojMatrix);
	
	inv_viewproj_transpose = viewprojMatrix;
	inv_viewproj_transpose.Inverse();
	inv_viewproj_transpose.Transpose();

	inv_view_matrix = viewMatrix;
	inv_view_matrix.Inverse();
	inv_view_matrix.Transpose();
}

void Camera::ManualUpdate(float _fov, float frameTime)
{
	fov = _fov;
	target_fov = _fov;

	CalculateViewProjectionMatrix(viewMatrix, projMatrix);
	viewprojMatrix = viewMatrix * projMatrix;
	frustum.Update(viewprojMatrix);
	
	inv_viewproj_transpose = viewprojMatrix;
	inv_viewproj_transpose.Inverse();
	inv_viewproj_transpose.Transpose();

	inv_view_matrix = viewMatrix;
	inv_view_matrix.Inverse();
	inv_view_matrix.Transpose();
}
