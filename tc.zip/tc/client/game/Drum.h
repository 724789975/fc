namespace Client
{
	struct DrumInfo : public GunInfo
	{
		float range;
		DrumInfo()
		{
			weapon_type = kWeaponTypeDrum;
		}

	};

	class Drum : public GunBase
	{
	public:
		Drum(by_ptr(DrumInfo) info);

	public:
		DECLARE_PDE_ATTRIBUTE_R(weapon_info, tempc_ptr(DrumInfo))
		{
			return drum_info;
		}

	public:
		/// update
		virtual void Update(float time);

		/// initialize
		virtual void Initialize();

		/// can active
		virtual bool CanActive();

		/// active
		virtual void Active();

		/// inactive
		virtual void Inactive();

		/// get weapon type
		virtual uint GetWeaponType();


	public:
		/// fire
		virtual bool Fire();


		/// can fire
		virtual bool CanFire(bool check_only);

		/// fire check
		virtual void FireCheck(const Core::Vector3 & position, const Core::Quaternion & rotation, float spread, bool do_effect = true);


	public:
		sharedc_ptr(DrumInfo)	drum_info;
	private:
		float drum_timer;
	};


}