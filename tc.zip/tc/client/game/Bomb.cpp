#include "pch.h"

using namespace Core;
using namespace Client;

DEFINE_PDE_TYPE_CLASS(Client::BombInfo)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Client::WeaponInfo);

		ADD_PDE_FIELD(bag);
		ADD_PDE_FIELD(plant_time);
		ADD_PDE_FIELD(defuse_time);
		ADD_PDE_FIELD(defuse_with_item_time);
		ADD_PDE_FIELD(bag_skeleton);
		ADD_PDE_FIELD(character_bag);

		ADD_PDE_FIELD(particle_explode);

		ADD_PDE_FIELD(sound_explode);
		ADD_PDE_FIELD(sound_plant);
		ADD_PDE_FIELD(sound_defuse);
		ADD_PDE_FIELD(sound_click_2d);
		ADD_PDE_FIELD(sound_click_3d);
		ADD_PDE_FIELD(sound_beep1);
		ADD_PDE_FIELD(sound_beep2);
		ADD_PDE_FIELD(sound_beep3);
		ADD_PDE_FIELD(sound_beep4);
		ADD_PDE_FIELD(sound_beep5);

		ADD_PDE_DEFAULT_CONSTRUCTOR();
	}
};

REGISTER_PDE_TYPE(Client::BombInfo);

enum State
{
	kIdle,
	kPlanted,
};

/// constructor
Bomb::Bomb(by_ptr(BombInfo) info)
: actor(NULL)
, draw_bag(false)
, bomb_planting(false)
, on_request_planting(false)
{
	weapon_info = bomb_info = info;
	state = kIdle;
}

/// destructor
Bomb::~Bomb()
{
	if (actor)
	{
		PhysxSystem::ReleaseActor(*actor);
		actor = NULL;
	}

	tempc_ptr(Character) owner = GetOwner();
	if(owner)
	{
		owner->UnLockStateByType(kLSMove);
	}
	
}

/// update mesh
void Bomb::UpdateMesh()
{
	if (draw_bag)
	{
		if (bag_mesh)
		{
			bag_mesh->pose = bag_pose;
			bag_mesh->Update();
		}
	}
	else
	{
		if (state == kPlanted)
			mesh->pose = pose;
		else
			mesh->pose = GetPose();

		mesh->Update();
	}
}

/// draw
void Bomb::Draw(Primitive::DrawType drawtype, bool immediate)
{
	if (draw_bag)
	{
		if (bag_mesh)
		{
			bag_mesh->SetPosition(GetPosition());
			bag_mesh->SetRotation(GetRotation());
			bag_mesh->Draw(drawtype, immediate);
		}
	}
	else
	{
		if (mesh)
		{
			mesh->SetPosition(GetPosition());
			mesh->SetRotation(GetRotation());
			mesh->Draw(drawtype, immediate);
		}
	}
}

/// initialize
void Bomb::Initialize()
{
	WeaponBase::Initialize();

	if (bomb_info)
	{
		if (skeleton)
		{
			animation_list = ptr_new AnimationNodeList;
			animation_set = ptr_new AnimationSet;

			if (is_for_player)
			{
				CStrBuf<256> str(ANIMATION_KEY_PROP_PLAYER);

				CStrBuf<256> str_animation;
				str_animation.format("%s/%s", owner->GetCurCharinfo()->first_person_animationset, weapon_info->animation_set);

				if (weapon_info)
					str.contract(str_animation);

				animation_set_player = RESOURCE_GET_BYTYPE(str, ANIMATIONSET_TYPE, AnimationSetRes);
				if (animation_set_player)
				{
					animation_set_player->Load(true);
				}
				animation_set->SetAnimationSet("common", animation_set_player);
			}
			else
			{
				CStrBuf<256> str(ANIMATION_KEY_PROP_CHARACTER);

				CStrBuf<256> str_animation;
				if(owner)
				{
					str_animation.format("%s/%s", owner->GetCurCharinfo()->third_person_animationset, weapon_info->animation_set);

					if (weapon_info)
						str.contract(str_animation);

					animation_set_character = RESOURCE_GET_BYTYPE(str.buff(), ANIMATIONSET_TYPE, AnimationSetRes);
					if (animation_set_character)
					{
						animation_set_character->Load(true);
					}
					animation_set->SetAnimationSet("common", animation_set_character);
				}

			}

			if (animation)
			{
				animation->SetAnimationSet(animation_set);

				sharedc_ptr(AnimationNodePose) node = ptr_new AnimationNodePose(skeleton);
				node->SetAnimation("idle", animation_set);
				animation_list->AddNode("idle", node);

				node = ptr_new AnimationNodePose(skeleton);
				node->SetAnimation("empty", animation_set);
				animation_list->AddNode("empty", node);

				animation_list->SetActiveNode("idle");

				animation->SetAnimationNode(animation_list);
			}

			pose = ptr_new Pose(skeleton);
		}

		//bag_skeleton = RESOURCE_LOAD(bomb_info->bag_skeleton, false, Skeleton);

		//if (bag_skeleton)
		//{
		//	bag_mesh = ptr_new SkinMesh(MESH_KEY_WEAPON);
		//	if (bag_mesh)
		//	{
		//		bag_pose = ptr_new Pose(bag_skeleton);
		//		for (S32 i = MESH_LOD_LEVEL - 1; i >= 0; i--)
		//			bag_mesh->AddPrimitive(bomb_info->bag, i);
		//		bag_mesh->pose = bag_pose;
		//	}
		//}
	}
}

///// udpate
void Bomb::Update(float frame_time)
{
	WeaponBase::Update(frame_time);
	
	tempc_ptr(Character) owner = GetOwner();
	tempc_ptr(Character) player = gLevel->GetPlayer();

	if(!player || !owner || player != owner)
		return;
	
	tempc_ptr(StateMainGame) state_main = ptr_dynamic_cast<StateMainGame>(gGame->machine.CurrentState());
	if (state_main && !state_main->ui->bFoused)
	{
		if(!player->first_action_on && !gGame->input->IsKeyDown(KC_E) && bomb_planting && !on_request_planting)
		{
			gGame->channel_connection->CancelPlantBomb();
			on_request_planting = true;
		}
	             
		if((player->first_action_on || gGame->input->IsKeyDown(KC_E)) && !bomb_planting && CanPlant())
		{
			gGame->channel_connection->StartPlantBomb();
			on_request_planting = true;
		}
	}
}

bool Bomb::CanPlant()
{
	tempc_ptr(Character) player = GetOwner();

	if(!player)
		return false;

	if(!player->HasBomb())
		return false;

	if(on_request_planting)
		return false;


	return true;
}
//// draw UI
void Bomb::DrawUI(by_ptr(UIRender) ui_render)
{
	WeaponBase::DrawUI(ui_render);

	Core::CStrBuf<256> buff;

	buff.format("1/%d", 1);
	ui_render->DrawStringShadow(ui_render->font_simhei_24, ARGB(255, 241, 211), ARGB(0,0,0), ARGB(0, 0, 0, 0), Core::Rectangle(-195, 0 - 50, 0, 1), buff, Unit::kAlignLeftBottom);

	buff.format(weapon_info->name);
	buff.toupper();

	ui_render->DrawStringShadow(ui_render->font_simhei_14, ARGB(255, 241, 211), ARGB(0,0,0), ARGB(0, 0, 0, 0), Core::Rectangle(-100, -20, 0, -7), buff, Unit::kAlignCenterBottom);
}
/// can active
bool Bomb::CanActive()
{
	return WeaponBase::CanActive();
}

/// active
void Bomb::Active()
{
	WeaponBase::Active();
	tempc_ptr(Character) owner = GetOwner();
	if(owner)
		owner->bomb_plant_timer = -1.f;
}

/// inactive
void Bomb::Inactive()
{
	WeaponBase::Inactive();

	if(bomb_planting && !on_request_planting)
	{
		gGame->channel_connection->CancelPlantBomb();
	}

	on_request_planting = false;
	bomb_planting = false;

	
	tempc_ptr(Character) owner = GetOwner();
	if(owner)
	{
		owner->UnLockStateByType(kLSMove);

		if(!owner->HasBomb())
		{
			owner->GrenadeThrowStop();
		}
	}
		


}

/// plant
void Bomb::Plant(const Vector3 & pos)
{
	CreatePhysx();
	SetPosition(pos);
	Quaternion q = Quaternion::kIdentity;
	Quaternion q1 = Quaternion::kIdentity;

	q.SetAxisAngle(Vector3(1, 0, 0), HALFPI);

	tempc_ptr(Character) owner = GetOwner();
	if(owner)
	{
		q1.SetAxisAngle(Vector3(0,1,0), owner->GetRotation().GetZXY().y);
		owner->UnLockStateByType(kLSMove);
	}
	SetRotation(q * q1);
	state = kPlanted;
	on_request_planting = false;

}

/// create physx
void Bomb::CreatePhysx()
{
	actor = PhysxSystem::CreateBoxCCD(position, Vector3(0.5f, 0.18f, 0.5f), PhysxSystem::kGroupBomb);
	actor->setLinearDamping(5.f);
	actor->setAngularDamping(0);
	actor->setMaxAngularVelocity(0);
	actor->raiseBodyFlag(NX_BF_KINEMATIC);
}

/// get position
const Vector3 & Bomb::GetPosition()
{
	if (state == kPlanted && actor)
	{
		position = (const Vector3 &)actor->getGlobalPosition();
	}
	return position;
}

/// set position
void Bomb::SetPosition(const Core::Vector3 & pos)
{
	if(state != kPlanted)
	{
		if (actor)
			actor->setGlobalPosition((const NxVec3 &)pos);

		position = pos;
	}

}

/// plant bomb
void Bomb::PlantBomb()
{
	bomb_planting = true;
	tempc_ptr(Character) owner = GetOwner();
	if(!owner)
		return;
		
	owner->bomb_plant_timer = bomb_info->plant_time;

	if (animation)
		animation->PlayAction("pelt", 0.f, false,0.f);
	on_request_planting = false;
	if(owner == gLevel->GetPlayer())
	{
		owner->LockStateByType(kLSMove);
	}
	
}
/// stop plant bomb
void Bomb::StopPlantBomb()
{
	bomb_planting = false;
	if (animation)
		animation->StopAction();
	on_request_planting = false;

	tempc_ptr(Character) owner = GetOwner();
	if(owner)
		owner->UnLockStateByType(kLSMove);
	
	
	if (gLevel->audio_bomb_2d_Plant)
		gLevel->audio_bomb_2d_Plant->stop();
	if (gLevel->audio_bomb_3d_Plant)
		gLevel->audio_bomb_3d_Plant->stop();
	if (gLevel->audio_bomb_Planting_Defusing)
		gLevel->audio_bomb_Planting_Defusing->stop();
}