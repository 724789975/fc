namespace Client
{
	struct ZombieChargeInfo : WeaponInfo
	{
		float	skill_cooldown;
		float	skill_usetime;
		float   skill_hurt;
		ZombieChargeInfo()
		{
			weapon_type = kWeaponTypeZombieCharge;
		}
	};

	class ZombieCharge : public WeaponBase
	{
	public:
		/// constructor
		ZombieCharge(by_ptr(ZombieChargeInfo) info);

		/// get weapon type
		virtual uint GetWeaponType() { return kWeaponTypeZombieCharge; }

	public:
		/// initialize
		virtual void Initialize();

		/// udpate
		virtual void Update(float frame_time);

		/// can active
		virtual bool CanActive();

		/// active
		virtual void Active();

		/// inactive
		virtual void Inactive();

		/// draw ui
		virtual void DrawUI(by_ptr(UIRender) ui_render);

	private:
		bool CheckCharge();
		float charge_usetime;

	public:
		sharedc_ptr(ZombieChargeInfo)	charge_info;
		sharedc_ptr(PlayerSkill)		skill;
		bool isCharge;
	};
}