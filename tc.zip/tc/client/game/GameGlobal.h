namespace Client
{
	
	class GameGlobal
	{
	public:
		DECLARE_PDE_ATTRIBUTE_R(CurrentState,	tempc_ptr(GameState));
		DECLARE_PDE_ATTRIBUTE_R(ClientAddress,	ClientAddress);
		DECLARE_PDE_ATTRIBUTE_R(Player,			tempc_ptr(Character));
		DECLARE_PDE_ATTRIBUTE_R(Version,		Core::String);
		DECLARE_PDE_ATTRIBUTE_R(BuildLog,		Core::String);
		DECLARE_PDE_ATTRIBUTE_R(MasterBuild,	bool);
		DECLARE_PDE_ATTRIBUTE_RW(ErrorMessage,	Core::String);
		DECLARE_PDE_ATTRIBUTE_RW(ProfilerParse,	bool);
		DECLARE_PDE_ATTRIBUTE_RW(ProfilerLimit,	float);
		DECLARE_PDE_ATTRIBUTE_R(CharacterProfile, tempc_ptr(CharacterProfile));
		DECLARE_PDE_ATTRIBUTE_RW(FightQuit,	bool);

		DECLARE_PDE_ATTRIBUTE_RW(GameRate,		float);
		DECLARE_PDE_ATTRIBUTE_RW(GameStop,		bool);

	public:
		// temp function..
		void Connect(const Core::String & address, int port);

		// logout account
		void LogoutAccount(bool error = false);

		// logout character
		void LogoutCharacter();

		// exit
		void Exit();

		// chat
		bool Chat(const Core::Identifier & to, const Core::String & msg);

		// chatgroup
		void ChatGroup(const Core::Identifier & to, const Core::String & msg, const Core::Array<Core::String>& Name);
		
		// Chat TepGroup
		void ChatTepGroup( uint to, const Core::String & msg);

		// add system message
		bool SystemMessage(const Core::String & msg, const Core::Identifier & type);

		// set category volume
		void CategorySetVolume(const Core::String & key, int volume);

		// get category volume
		int CategoryGetVolume(const Core::String & key);

		// set category mute
		void CategorySetMute(const Core::String & key, bool mute);

		// get category mute
		bool CategoryGetMute(const Core::String & key);

		// set category pause
		void CategorySetPause(const Core::String & key, bool pause);

		// category stop
		void CategoryStop(const Core::String & key);

		// auto update
		void AutoUpdate();

		// rpc call
		bool RpcCall(Lua::LuaState *L);

		void GetRealResult(const char * str, Core::String & buf);

		void Translate(Core::CRefStr & str);

		void Translate(Core::String & str);

		int TextLenght(Core::String str);

		Core::String StrCut(Core::String str,int cut_num);

		Core::String	ReadINIString(const Core::String &sectionName, const Core::String &keyName);
		bool			WriteINIString(const Core::String &sectionName, const Core::String &keyName, const Core::String &keyValue);

		int				ReadINIInt(const Core::String &sectionName, const Core::String &keyName);
		bool			WriteINIInt(const Core::String &sectionName, const Core::String &keyName, int keyValue);

		Core::String	GetINIFileName();

		Core::CStrBuf<1024 * 128> RealResult;
		Core::CStrBuf<1024 * 128> Realbuf;

#if DEBUG_TOOLS
		// model 
		void ModelViewer();
		// scene 
		void SceneViewer();
#endif
	public:
		bool m_FightQuit;//��Ϸ���˳�
		float m_GameRate;
		bool m_GameStop;
	};
}
