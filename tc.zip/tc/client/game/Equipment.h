namespace Client
{
	struct EquipmentInfo : public WeaponInfo
	{
		
		EquipmentInfo()
		{
			weapon_type = kWeaponTypeEquipment;
		}
		Core::Identifier bandjoint;
	};

	class Equipment : public WeaponBase
	{
	public:
		Equipment(by_ptr(EquipmentInfo) info);

	public:
		/// initialize
		virtual void Initialize();
		virtual bool CanActive();

	public:
		sharedc_ptr(EquipmentInfo)	equipmentinfo;
		int bandjoint_id;
	};


}