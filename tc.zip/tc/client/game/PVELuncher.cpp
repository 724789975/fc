#include "pch.h"

using namespace Core;
using namespace Client;

DEFINE_PDE_TYPE_CLASS(Client::PVELuncherInfo)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Client::PVEWeaponInfo);

		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_FIELD(fly_speed);

		ADD_PDE_FIELD(ammo_info);
	}
};

DEFINE_PDE_TYPE_CLASS(Client::PVELuncher)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Client::PVEWeaponBase);
	}
};

REGISTER_PDE_TYPE(Client::PVELuncherInfo);
REGISTER_PDE_TYPE(Client::PVELuncher);

/// random float
static float RandomFloat(F32 x, F32 y)
{
	float r = (F32)rand() / (RAND_MAX + 1);
	float num = x + (y - x) * r;
	return num; 
}

namespace Client
{
	PVELuncher::PVELuncher()
	{
	}

	PVELuncher::~PVELuncher()
	{
	}

	bool PVELuncher::Initialize(const Core::String &name, by_ptr(Character) c, by_ptr(PVEWeaponInfo) info)
	{
		tempc_ptr(PVELuncherInfo) luncher_info = ptr_dynamic_cast<PVELuncherInfo>(info);
		if (!luncher_info)
			return false;

		if (!PVEWeaponBase::Initialize(name, c, info))
			return false;

		if (!m_PreloadAmmo)
		{
		}

		return true;
	}

	void PVELuncher::Update(float time)
	{
		PVEWeaponBase::Update(time);
	}

	void PVELuncher::Fire(const Core::Vector3 &fire_pos, const Core::Quaternion &fire_rot, int index, by_ptr(Character) target)
	{
		tempc_ptr(PVELuncherInfo) luncher_info = ptr_dynamic_cast<PVELuncherInfo>(GetWeaponInfo());

		Vector3 vel = Vector3(0, 0, -1) * fire_rot * luncher_info->fly_speed;

		sharedc_ptr(PVEAmmo) pve_ammo = ptr_new PVEAmmo();
		if (pve_ammo->Initialize(GetOwner()->GenPVEAmmoId(), luncher_info->ammo_info, GetOwner(), 
								false, fire_pos, vel))
		{
			if (target)
				pve_ammo->OnLock(target);
			GetOwner()->LaunchPVEAmmo(pve_ammo);
		}
	}

	void PVELuncher::Fire(const Core::Vector3 &fire_pos, const Core::Vector3 &target)
	{
		tempc_ptr(PVELuncherInfo) luncher_info = ptr_dynamic_cast<PVELuncherInfo>(GetWeaponInfo());

		Vector3 vel = target - fire_pos;
		vel.Normalize();
		vel *= luncher_info->fly_speed;

		sharedc_ptr(PVEAmmo) pve_ammo = ptr_new PVEAmmo();
		if (pve_ammo->Initialize(GetOwner()->GenPVEAmmoId(), luncher_info->ammo_info, GetOwner(), 
								false, fire_pos, vel))
		{
			GetOwner()->LaunchPVEAmmo(pve_ammo);
		}
	}

	void PVELuncher::Fire(const Core::Vector3 &fire_pos, by_ptr(Character) target)
	{
		if (!target)
			return;

		tempc_ptr(PVELuncherInfo) luncher_info = ptr_dynamic_cast<PVELuncherInfo>(GetWeaponInfo());

		Vector3 target_pos = target->GetPosition();
		target_pos.y += target->GetHeight() * 1.0f;

		Vector3 vel = target_pos - fire_pos;
		vel.Normalize();
		vel *= luncher_info->fly_speed;

		sharedc_ptr(PVEAmmo) pve_ammo = ptr_new PVEAmmo();
		if (pve_ammo->Initialize(GetOwner()->GenPVEAmmoId(), luncher_info->ammo_info, GetOwner(), 
								false, fire_pos, vel))
		{
			pve_ammo->OnLock(target);
			GetOwner()->LaunchPVEAmmo(pve_ammo);
		}
	}

	void PVELuncher::Reset()
	{
		String fire_interval_key;
		GetFireIntervalKey(fire_interval_key);
		GetOwner()->SetClientSynScriptNumberValue(fire_interval_key, GetWeaponInfo()->first_fire_time);
	}

	PVEWeaponType PVELuncher::GetWeaponType()
	{
		return kPVEWeaponTypeLuncher;
	}
}
