#include "pch.h"

using namespace Core;
using namespace Client;


DEFINE_PDE_TYPE_CLASS(Client::EquipmentInfo)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Client::WeaponInfo);
		ADD_PDE_FIELD(bandjoint);
		ADD_PDE_DEFAULT_CONSTRUCTOR();
	}
};


DEFINE_PDE_TYPE_CLASS(Client::Equipment)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Client::WeaponBase);
	}
};

REGISTER_PDE_TYPE(Client::EquipmentInfo);
REGISTER_PDE_TYPE(Client::Equipment);
namespace Client
{
	void Client::Equipment::Initialize()
	{
		WeaponBase::Initialize();
		tempc_ptr(Character) owner = GetOwner();
		//bandjoint_id = owner->third_person->GetJointId(equipmentinfo->bandjoint);
		//
	}

	bool Client::Equipment::CanActive()
	{
		return false;
	}


	Equipment::Equipment( by_ptr(EquipmentInfo) info )
	{
		weapon_info = equipmentinfo = info;
		bandjoint_id = -1;
	}

}