namespace Client
{
	class AnimObjectInfo : public Core::Object
	{
	public:
		AnimObjectInfo();
		void SetMesh(const Core::Identifier & key, const Core::Identifier & value, const U32 lod_level);
		void BandAnimation(int index, const Core::Identifier & animation_name, const Core::Vector3& pos);
	public:
		Core::Identifier prop_skeleton;
		Core::Identifier prop_animationset;
		Core::Quaternion rotation;
		Core::Identifier band_jointname;

		Core::Identifier sound_name;
		float			 sound_play_time;

		bool			 usebox;
		float			 boxsize_x;
		float			 boxsize_y;
		float			 boxsize_z;
		
		Core::HashSet<int, Core::Vector3> position_indexs;
		Core::HashSet<int, Core::Identifier> animation_indexs;
		typedef Core::HashSet<Core::Identifier, Core::Identifier> MeshSet;
		Core::HashSet<Core::Identifier, U32> meshset_lod;
		MeshSet mesh_set;
	};

	class AnimObject : public Core::Object
	{
		public:
			/// constructor
			AnimObject(by_ptr(AnimObjectInfo) info);
			~AnimObject();
		public:
			/// update 
			void Update(float frame_time);

			/// draw
			void Draw(Primitive::DrawType drawtype, bool immediate = false);

			/// initialize
			void Initialize();

			/// initialize mesh
			void InitializeMesh();

			/// play action
			void PlayAction(const Core::Identifier & key);
			
			/// play action by index
			void PlayActionByIndex(int);

			/// stop action
			void StopAction();

			void Reset();

		public:
			void SetAnimationSet(const char * key);

		private:
			sharedc_ptr(Skeleton) skeleton;
			sharedc_ptr(SkinMesh)	mesh;
			sharedc_ptr(AnimationNodeCustom)	animation;
			sharedc_ptr(AnimObjectInfo) animobject_info;
			bool visible;
			NxActor * actor;
			FMOD::Event*	 sound_Event;
			float			 play_timer;
			int				 now_index;
	};
}