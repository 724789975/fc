namespace Client
{
	class Description
	{
	public:
		Description();

		~Description();

		bool LoadDescription();

		Core::String GetWeaponDescriptionText(short type, short value1, short value2, short time);

		Core::ARGB GetWeaponDescriptionColor(short type, short value1, short value2, short time);

	private:
		bool LoadWeaponDescription();

	private:
		struct WeaponDescriptionData
		{
			Core::String text;
			byte has_param[3];
			Core::ARGB color;

			WeaponDescriptionData()
			{
				has_param[0] = has_param[1] = has_param[2] = 0;
				color = Core::ARGB(1, 1, 1);
			}
		};
		Core::HashSet<short, WeaponDescriptionData> WeaponDescriptionTable;
		Core::Array<Core::ARGB> WeaponDescriptionColors;
	};
}
