namespace Client
{
	#define DEFAULT_ZOMBIE_NORMAL 20
	#define	DEFAULT_ZOMBIE_BOMB 21
	#define DEFAULT_ZOMBIE_KING 30
	#define DEFAULT_COMMONZOMBIE_COM 42
	#define DEFAULT_COMMONZOMBIE_KING 41
	#define DEFAULT_COMMONZOMBIE_LAST_KING 40
	#define DEFAULT_COMMONZOMBIE_DISAPPEAR 43
	#define DEFAULT_COMMONZOMBIE_DRUG 44
	#define DEFAULT_COMMONZOMBIE_CHARGE 45

	const float DIE_BUFF_RAND_GAP_TIME =0.2f;//����buff���ʱͣ��ʱ��
	const float DIE_BUFF_RAND_TIME =2.5f;//����buff���ʱ��
	const float DIE_BUFF_STAY_TIME =1.5f;//����buffͣ��ʱ��

	const int ITEM_REDBOTTLE = 39;
	const int ITEM_AMMO = 40;
	const int ITEM_CARRIER = 41;
	const int ITEM_ATTACK = 43;
	const int ITEM_ATTACK_SPEED = 44;
	const int ITEM_BLOOD = 45;
	const int ITEM_RESISTANCE = 46;
	const int ITEM_MOVE_SPEED = 47;

	enum LockStateType
	{
		kLSNone = 0,
		kLSJump = 1,
		kLSCrouch,
		kLSSelectWeapon,
		kLSMove,
		kLSCamera,
	};

	enum KillKind
	{
		kGeneral = 0,
		kContinuation,
		kGrenade,
		kFight,
		kHead,
		kBoost,
		kSustain_Burn,
		kSustain_Poison,
		kControl,
		kReveng,
		kDefuse_success,
		kPlant_success,
		KKill_King,
		KKill_Zombie,
		KKill_Kill,
		KKill_Knockdown,
		KKill_SkillKill,
		KKill_SkillKnockdown,
		kKillBoss,
		kCommonZombie_King,
		kCommonZombie_LastKing,
		kCommonZombie_normal,
		kCommonZombie_infect,
		kCommonZombie_infect_Last,
		kCommonZombie_disappear,
		kCommonZombie_drug,
		kCommonZombie_charge,
		kBossmode2_Boss,
		kBossmode2_Boss_hit,
		kCure1,
		kCure2,
		kCure3,
		kCure4,
		kCure5,
	};

	struct HitInfo
	{
		int		hp;
		int		armor;
		float	time;
		byte	from_uid;
		byte	to_uid;
		byte	assist_uid;
		byte	part;
		Core::Quaternion dir;
		bool	boost;
		sharedc_ptr(WeaponInfo) weapon;
		byte	sustainhurttype;
	};

	struct LosterHistoryInfo
	{
		Core::Identifier lostername;
		Core::Identifier careername;
		Core::Array<int> kills_kind;
		int score;
	};

	struct KillerInfo
	{
		Core::Array<LosterHistoryInfo> arry_losters;
		int killnum;
		int assistnum;
		int totalscore;
		KillerInfo()
		{
			killnum = 0;
			assistnum = 0;
			totalscore = 0;
		}
		void Reset()
		{
			killnum = 0;
			assistnum = 0;
			totalscore = 0;
			arry_losters.Clear();
		}
	};

	struct AddEnergyEffectInfo
	{
		float current_value;
		float all_value;
		float current_target_value;

		float move_time;
		float move_all_time;

		float flash_time;
		float flash_all_time;
		float flash_ratio;
	};

	struct SkillHistoryInfo
	{
		sharedc_ptr(Texture2D) skill_icon;
		float time;
		float total_time;
	};

	struct RadioData
	{
		Core::Vector3 pos;
		int anim_id;
		float time;
		float pertime;
	};

	/// character sync data
	struct CharacterSyncData
	{
		float				time;
		Core::Vector3		position;
		Core::Quaternion	rotation;
		bool				crouch;
		bool				walk;
		bool				jump;
		bool				onground;
		bool				flying;
		bool				boost;
		Core::Vector2		move;
	};

	struct KillIDCount
	{
		byte uid;
		int count;
	};
	
	struct WeaponAttributeEffect
	{
		byte	type;
		float	effect_value1;
		float	effect_value2;
		float	effect_time;
	};

	struct CharacterParticle
	{
		sharedc_ptr(ParticleSystem) ps;
		Core::Identifier joint;
		float totle_time;
		float timer;
	};

	struct ItemParticleTime
	{
		int slot;
		float totle_time;
	};
}

namespace Client
{
	class IBarbette;

	/// character
	class Character : public DrawableObj
	{
	public:
		/// view mode
		enum ViewMode
		{
			kFirstPerson,
			kThirdPerson,
		};

		/// weapon
		enum WeaponChangeState
		{
			kWeaponReady = 0,
			kWeaponChangeOut,
			kWeaponChangeIn,
		};

	public:
		/// constructor
		Character();

		/// destructor
		~Character();

	public:
		/// on create
		void OnCreate();

		/// on destroy
		void OnDestroy();

		/// update
		void Update(float frame_time);

		/// timestepupdate
		void TimeStepUpdate(float frame_time);

		/// update
		void UpdateSyncData(float frame_time);

		/// on render
		void OnRender(float frame_time);

		/// draw
		void Draw(Primitive::DrawType drawtype, bool immediate = false);

		/// draw
		void DrawBarbette(Primitive::DrawType drawtype, bool immediate = false);

		/// get shader lod
		S32 GetShaderLod();

	private:
		void UpdateMovePointEffect(float frame_time);

	public:
		/// initialize
		void Initialize();

		/// initialize weapon
		void InitializeWeapon(const PackInfo & pack);

		/// initialize mesh
		void InitializeMesh();

		/// initialize barbette
		void InitializeBarbette();

		/// is ready
		bool IsReady();

		/// get position
		const Core::Vector3 & GetPosition();

		/// get skeleton position
		const Core::Vector3 GetTorsoPosition(bool firstperson = false);

		/// set position
		void SetPosition(const Core::Vector3 & pos);

		/// set position
		void MovePosition(const Core::Vector3 & pos);

		/// get camera position
		Core::Vector3 GetCameraPosition();

		/// get camera rotation
		Core::Quaternion GetCameraRotation();

		/// get camera Third Person position
		Core::Vector3 GetCameraThirdPersonPosition();

		/// get camera Third Person rotation
		Core::Quaternion GetCameraThirdPersonRotation();

		/// get skeleton rotation
		Core::Quaternion GetSkeletonRotation();

		/// get skeleton position
		Core::Vector3 GetSkeletonPosition();

		/// get rotation
		const Core::Quaternion & GetRotation();

		/// set face dir
		void SetLookDir(const Core::Quaternion & rot);

		/// get face dir
		const Core::Quaternion &  GetLookDir();

		/// set move
		void SetMove(float move, float shift);

		/// get direction
		const Core::Vector3 & GetMove();

		/// get direction
		const Core::Vector2 & GetDirection();

		float GetKickOnHitTimer();

		/// pool back
		float PoolBack(float distance);

		/// set camera fov
		void SetCameraFov(float fov, float target_fov);

		// radio update
		void RadioPlay(int radio_id, int radio_item, Core::String radio_avarname);

		/// projectedammo launch out
		bool AmmoLaunchOut(by_ptr(AmmoInfo) info, const Core::Vector3 & position, const Core::Vector3 & direction, U16 ammoindex, by_ptr(Character) target = NullPtr, bool isboost = false);

		// radio action
		void RadioAction();

		/// move look
		void MoveLook(float horizontal, float vertical);

		/// move camera
		void MoveCamera(float horizontal, float vertical);

		/// get current speed
		const Core::Vector3 & GetCurrentSpeed();

		/// get vertical speed
		float GetVerticalSpeed();

		/// set current speed
		void SetCurrentSpeed(const Core::Vector3 & speed);

		/// get controller height
		float GetControllerHeight();

		/// get controller radius
		float GetControllerRadius();

		/// get height
		float GetHeight();

		/// get throw velocity
		float GetThrowVelocity();

		/// get weapon
		tempc_ptr(WeaponBase) GetWeapon(bool force_first_person = true);

		/// get ThirdPreson weapon
		tempc_ptr(WeaponBase) GetThirdPresonWeapon();
		
		/// get weapon by id
		tempc_ptr(WeaponBase) GetWeaponById(uint id, bool force_first_person = true);

		/// set crouch
		void SetCrouch(bool flag = false);

		/// set walk
		void SetWalk(bool flag = false);

		/// get crouch
		bool GetCrouch();

		/// get walk
		bool GetWalk();

		/// get team
		int GetTeam();

		/// set team
		void SetTeam(int id);

		/// is jumping
		bool IsJumping();

		/// set jump
		void SetJump(bool flag);

		/// set fly
		void SetFly(bool flag);

		/// set Boost
		void SetBoost(bool flag , int dir);

		/// is flying
		bool IsFlying();

		/// is Boost
		bool IsBoost();

		/// ammo jump
		bool AmmoJump(const Core::Vector3 &AmmoPos, bool selfhurt, float jumpscale);

		/// set onground
		void SetOnGround(bool flag);

		/// is died
		bool IsDied();

		/// is on ground
		bool IsOnGround();

		/// is moving
		bool IsMoving();

		bool IsSlowMoving();
		
		/// is shooting
		bool IsShooting();

		/// is reloading
		bool IsReloading();

		/// set info
		void SetCharacterInfo(by_ptr(CharacterInfo) info);

		/// set view mode
		void SetViewMode(ViewMode mode);

		/// set move controller
		void SetMoveController(by_ptr(MoveController) controller);

		/// set Action controller
		void SetActionController(by_ptr(ActionController) controller);

		/// clear cache
		void ClearCache();

		/// get pose
		tempc_ptr(Pose) GetPose();

		/// get view mode
		ViewMode GetViewMode();

		/// get first person
		FirstPerson & GetFirstPerson();

		/// get third person
		ThirdPerson & GetThirdPerson();

		/// set move offset
		void SetMoveInfoOffset(float move_offset);

		float GetMoveInfoRunSpeed();

		/// Set CureParticle Enable
		void SetCureParticleShow(int time);

		// show bill board
		void ShowBillBoard(float time);

		void ShowItemModeHead(float time);

		/// 
		void PlaySoundEffectFromWeapon(const Core::Vector3& pos, const Core::Vector3& dir);

	public:
		/// on jump
		void OnJump();

		/// on boost
		void OnBoost(int dir);

		/// on onground
		void OnOnground();

		/// fall down
		void FallDown(float speed, bool is_onground = true);

		/// die
		void Die(const HitInfo & hit);

		/// kill
		void OnKill(const HitInfo & hit);

		/// on hit
		void OnHit(const HitInfo & info);

		void OnKickBack(const KickInfo & info, bool skip_physx);

		/// on grenade explode
		void OnGrenadeExplode();

		/// on bomb exploded
		void OnBombExploded();

		/// response hit
		void ResponseHit(const Core::Vector3 & from_position, const Core::Vector3 & target, const Core::Vector3 & normal, int part,UINT weapontype, bool no_blood = false, bool isboost = false);

		/// rebirth
		void Rebirth(int hp, int armor, const Core::Vector3& p, const Core::Quaternion& r);

		/// on hit character
		void OnHitCharacter(tempc_ptr(Character) hit_character);

		/// can reload
		bool CanReload();

		/// can fire
		bool CanFire();

		/// can throw grenade
		bool CanThrowGrenade();

		/// can stab
		bool CanStab();

		/// grenade throw in
		void GrenadeThrowIn();

		/// grenade ready
		void GrenadeReady();

		/// grenade throw request
		void GrenadeThrowRequest(byte type);

		/// grenade throw out
		void GrenadeThrowOut(int weapon_id, by_ptr(ThrowableInfo) info, const Core::Vector3 & position, const Core::Vector3 & direction);

		/// stop throw grenade
		void GrenadeThrowStop();
		
		/// on grenade throw out
		void OnGrenadeThrowOut();

		/// knife stab
		void Stab(byte type);

		/// stop stab
		void StopStab();

		/// shooting
		void Shoot(const Core::Vector3 & dir, bool do_effect, bool isboost = false);

		void Shoot(const Core::Vector3& pos, const Core::Vector3 & dir, bool do_effect, bool isboost = false);

		/// stop shooting
		void StopShoot();

		/// reload
		void Reload();

		/// reload Ready
		void ReloadReady(int count);

		/// select weapon
		void SelectWeapon(uint id,bool force = false);

		/// weapon active
		void WeaponActive(uint id);

		/// weapon inactive
		void WeaponInactive(uint id);

		/// set weapon
		void SetWeapon(int slot, by_ptr(WeaponInfo) info);

		/// change weapon
		void ChangeWeapon();

		// drop weapon
		void DropWeapon(int slot);

		void DropBomb();

		// pick up weapon
		void PickUpWeapon(int slot, by_ptr(WeaponInfo) info);

		/// create weapon
		static sharedc_ptr(WeaponBase) CreateWeapon(by_ptr(WeaponInfo) info);

		/// has bomb
		bool HasBomb();

		void SetHasBomb(bool flag);

		//����buff
		void UpdateDieBuff(float fFT);
		void SetDieBuffer(bool bNeed);
		void SetDieBufferCounter(int iCounter);
		int GetRandingDieBuff();
		int GetStayDieBuff();
		int GetDieBuffTotalCount();
		int GetDieBuffCounter();
		float GetDieBuffGapTimer();
		float GetDieBuffStayTimer();
		bool IsDieBuffAffecting();
		float GetDieBuffAffectTimer();
		int GetDieBuffAffect();

		sharedc_ptr(Bomb) GetBomb(bool force_first_person);

		void PlantBomb();

		void StopPlantBomb();

		/// preload weapon
		void PreloadWeapon(by_ptr(WeaponInfo) info);

		/// preload pack
		void PreloadPack(const PackInfo & info);

		/// recover
		void Recover(int health, byte recovertype);

		/// ammorecover
		void AmmoRecover(short ammocount,byte recovertype);

		/// recover stop
		void RecoverStop();

		/// burn
		void Burn();

		/// burn stop
		void BurnStop();

		void Poison();

		void PoisonStop();

		/// set physx control
		void SetPhysxControl(bool flag);

		/// get physx control
		bool GetPhysxControl();

		/// set physx group
		void SetPhysxGroup(uint id);

		/// get physx group
		int GetPhysxGroup();

		/// get damage part
		int GetDamagePart(int part1, int part2);

		/// get actor id
		int GetActorId(const Core::Identifier & name);

		/// get actor id
		int GetActorId(NxActor* pActor);
		
		/// get jonit id
		uint GetJointIdFromActorId(uint id);

		/// check grenade
		bool CheckGrenade(const Core::Vector3 & pos, float & distance);

		/// check grenade2
		bool CheckGrenade2(const Core::Vector3 & pos, float & distance);

		/// check flash
		bool CheckFlash(const Core::Vector3 & pos, float & distance, bool & back_bright);

		/// flash bright
		void FlashBright(float bright_time, float fade_time);

		/// use skill request
		void UseSkillRequest();

		/// use skill
		void UseSkill();

		/// use skill stop
		void UseSkillStop();

		/// get name
		Core::String GetName();

		/// add skill history
		void AddSkillHistory(sharedc_ptr(Texture2D) icon, float time);

		/// update occludee info
		void UpdateOccludee();

		/// from nx actor
		static tempc_ptr(Character) FromNxActor(NxActor & actor);

		sharedc_ptr(CharacterInfo) GetCurCharinfo();

		void SetCareer(int career, sharedc_ptr(CharacterInfo) info);

		void ClearCareerCache();

		void CallMedic();
		void BoostSound();
		void Boost_3D_Sound();

		void PreloadSkeleton();

		void SetGrenadeCDTiming(float time);
		
		void LockStateByType(byte state_type);
		void UnLockStateByType(byte state_type);
		bool IsLockStateByType(byte state_type);
		void ClearLockState();

		void SetSelfTransparency(bool on, by_ptr(WeaponInfo) weapon_info = NullPtr);
		
		void UpdateUiScoreLine();

		void RevertToRawCharacterChangeableInfo();

		void UpdateRawCharacterChangeableInfo();

		void UpdateCurrentCharacterChangeableInfo();

		float GetTotalAttributeByType(const EEffect& type, bool no_system = false);

		float GetAcquiredAttributeByType(const EEffect& type, bool no_system = false);

		bool IsAttributeExist(const EEffect& type, bool no_system = false);

		bool IsAcquiredAttributeExist(const EEffect& type, bool no_system = false);

		void UpdateMoveInfo();

		void UpdateZombieDyingCamera(float delta);

		void ClearZombieDyingCamera();

	public:
		void SetClientSynScriptStringValue(const Core::String &key, const Core::String &value);

		Core::String GetClientSynScriptStringValue(const Core::String &key);

		bool HasClientSynScriptStringValue(const Core::String &key);

		void SetClientSynScriptNumberValue(const Core::String &key, float value);

		float GetClientSynScriptNumberValue(const Core::String &key);

		bool HasClientSynScriptNumberValue(const Core::String &key);

		void ClearClientSynScriptValue();

		bool CanControl();

		void SetBossPVEAction(bool isnew);

		bool GetBossPVEAction();

		void PlayCharacterParticle(const Core::Identifier & joint, const Core::Identifier & value, float time);

		void CleanAllCharacterParticle();

		void PlayItemModeParticle(const Core::Identifier & value, float time);

		void CleanAllItemModeParticle();

		void PlayItemModeBuffTime(int slot, float time);

		void CleanAllItemModeBuffTime();

		void PlayItemModeDebuffTime(int slot, float time);

		void CleanAllItemModeDebuffTime();

		void PveClientPlayAction(const Core::String &ani_key);

		void PveClientStopAction();

		void PveClientPlaySound(const Core::String sound_key, bool is3dsound);

		bool CheckCanHit(const Core::Vector3 &pos, float max_distance);

		tempc_ptr(IBarbette) GetBarbetteByName(const Core::String &name);

		void LaunchPVEAmmo(by_ptr(PVEAmmo) pve_ammo);

		void AddPVEAmmoLaser(by_ptr(PVEAmmoLaser) pve_ammolaser);

		U16 GenPVEAmmoId();

		bool IsBossMode2();

		InGameItemInfo* GetBagItem(uint sid);

		InGameItemInfo* GetBagItemByIID(uint iid);

		ItemBag&		GetBag();

		bool ItemIsCDTime(const InGameItemInfo* item_info, double now_time);

		bool ItemIsRedBottle(const InGameItemInfo* item_info);

		bool ItemIsAmmo(const InGameItemInfo* item_info);

		bool ItemIsCarrier(const InGameItemInfo* item_info);

		bool ItemIsBuffer(const InGameItemInfo* item_info, int buff_type);

		bool IsCarrierMode();

	private:
		Core::HashSet<Core::String, Core::String> m_ClientSynScriptStringValue;
		Core::Array<Core::String> m_ClientSynScriptStringValueDirty;

		Core::HashSet<Core::String, float> m_ClientSynScriptNumberValue;
		Core::Array<Core::String> m_ClientSynScriptNumberValueDirty;

		Core::HashSet<U16, sharedc_ptr(PVEAmmo)> m_PVEAmmoSet;
		Core::HashSet<U16, sharedc_ptr(PVEAmmoLaser)> m_PVEAmmoLaserSet;
		U16 m_PVEAmmoIdBuilder;

	public:
		/// set transparency
		void SetTransparency(TransparencyKind v);

		TransparencyKind transparency;
		float transparency_value;
		float transparency_time;

		CharacterSpState special_mode;

		sharedc_ptr(Texture2D) ui_head_icon;

	public:
		sharedc_ptr(SkinMesh)	mesh;
		sharedc_ptr(ParticleSystem) gun_special_particle;
		sharedc_ptr(ParticleSystem) tp_special_particle;

		byte is_using_type;
		tempc_ptr(WeaponInfo)    current_weaponinfo;
		int						physx_group;
		Core::ARGB				light_direction;

		bool                    is_bag_prev_open:1;
		bool                    is_bag_open:1;
		bool                    is_text_show:1;
		int						current_bag_id;
		int						current_help_id;
		float					bag_dialog_wait_time;
		bool                    is_ready_bag_close:1;
		int						prev_bag_id;
		float					show_shoot_time;
		float                   show_text_time;
		
		int    radio_state;
		int    radio_id;
		int    radio_item;
		Core::String radio_avarname;
		// ui
		Core::FixedArray<HitInfo, 8>	hit_ui;
		HitInfo					current_hit_info;

		AddEnergyEffectInfo  energy_bar_info;
		
		// kill
		Core::Array<int> kills_kind;
		float	kill_anim_time;
		float   kill_score_time;
		float   special_particle_time;
		float   tp_special_particle_time;
		float   kill_showscore;
		int     lian_kill_count;
		bool    isshowevent;
		float   speaker_tip_time[5];
		Core::Array<sharedc_ptr(Texture2D)> current_pickup_object_list;
		Core::Array<int>					current_pickup_object_type_list;
		Core::Array<Core::String>			current_pickup_object_name;

		bool already_team_defuse:1;
		int	 benefitshadertype;
		float benefitshadertime;

		int cure_all_value;
		//hit 
		float   all_score;
		float   get_score;
		float   get_last_score;
		int		ui_score_line;
		int     hit_current_score;
		float   hit_scroll_time;

		int     explode_num;
		int     unexplode_num;

		int     pickup_banner_num;
		int     return_banner_num;

		Core::Array<SkillHistoryInfo> skill_history_info;

		float   fire_time_ratio;

		// score
		int		score;

		// game properties
		byte				uid;
		byte				control_uid;

		byte				is_vip;
		byte				business_card;
		byte				is_gm;
		int					level;
		Core::String		head_icon;

		ushort				ping;
		int					hp;
		int					armor;
		short				num_killed;
		short				num_died;
		short				num_assist;
		int                 damage_hp;
		int                 damage_armor;
		bool                is_display_damage_hp:1;
		float               damage_hp_time;

		double				ping_time;
		float				invincible_time;
		float				sustainflame_time;
		float				poison_time;

		byte				pack_index;

		bool				ready		: 1;
		bool				connected	: 1;
		bool				playing		: 1;
		bool				died		: 1;

		bool  is_display_c4_tip:1;
		bool  is_display_weapon_list:1;
		bool  is_display_banner:1;

		bool				reloading			: 1;
		bool				shooting			: 1;
		bool				throwing_grenade	: 1;
		bool				grenade_throw_out	: 1;
		bool				stabing				: 1;

		bool				first_action_on		: 1;
		bool				second_action_on	: 1;
		bool				planting_bomb		: 1;

		float				cross_hair_offset;
		Core::Vector3		punch_angle;
		Core::Vector3		punch_angle_velocity;
		float				height_offset;

		float				camera_fov;
		float				camera_target_fov;
		float				camera_fov_change;
		float				camera_distance;
		Camera::ControlMode camera_control_mode;
		Core::Vector3		camera_position;
		Core::Quaternion	camera_rotation;
		Core::Quaternion	camera_rotation_offset;
		float				mouse_sensitivity;

		bool					physx_control	: 1;

		// weapon
		int						weapon_id;
		int						equipment_id;
		
		sharedc_ptr(WeaponInfo)	equipment_info;

		bool					bsniperassist;
		
		int						weapon_select_state;
		int						weapon_id_next;
		int						weapon_id_last;
		
		bool					select_grenade_mode;
		int						grenade_id; 

		bool					is_complete_raise:1;
		bool					is_fov_changed:1;

		Core::Array<Arrow*>		 prod_list;
		
		//for multi_animation
		bool keep_Shoot			: 1;
		bool keep_Shoot_fp		: 1;
		bool keep_Shoot_mini	: 1;
		bool keep_Shoot_mini_tp	: 1;
		int keep_Shoot_mini_state;

		sharedc_ptr(BaseCharacterInfo)	basecharacter_info;
		sharedc_ptr(CharacterInfo)		character_info;
		int								current_career;

		Core::HashSet<uint, sharedc_ptr(CharacterInfo)> cache_character_info;

		float died_time;
		float died_timer;
		float died_temp_timer;	//����Ԥ��ʱ��

		bool dual_pistol_status:1;

		bool occluded			: 1;

		float team_request_waittime;
		float team_success_join_time;
		float team_refuse_time;
		Core::String team_request_username;
		uint  team_request_uid;

		float control_reverse_timer;
		float radar_timer;
		float radar_ui_timer;

		bool attack_level_flag:1;
		int  attack_level_count;
		float attack_level_time;

		float	sync_time;
		Core::Deque<CharacterSyncData>	sync_data;

		float	time;
		float	update_time;

		bool  relife_flag       : 1;
		
		bool  select_player_flag :1;

		float relife_time;
		float relife_maxtime;

		bool skip_grenade;

		float power_up_time;
		float disguise_time;

		float flash_bright_time;
		float flash_fade_time;

		//draw weapon list icon flag
		int   weapon_list_icon_flag;
		float  weapon_list_icon_movetime;
		float  weapon_list_icon_waittime;
		float  weapon_list_icon_alpha;
		float  weapon_current_icon_alpha;
		float  weapon_next_icon_alpha;

		int    supply_object_id;
		bool   supply_object_flag:1;

		float   supply_object_time;
		float   supply_object_alpha;

		int     old_hp;
		int     new_hp;

		Core::Occludee occludee;

		float   hits_score_wait_time;
		float   hits_score_alpha;

		bool    is_team_hurt_part:1;
		bool    is_team_hurt_dead:1;
		float	 team_hurt_time;

		bool  is_display_friend_name:1;

		float   team_hurt_part_time;
		float	team_hurt_dead_time;

		bool	is_shoot_stab:1;

		bool    bag_flag:1;
		bool    is_range_bag_flag:1;
		float   bag_wait_time;
		float   bag_flash_time;

		int		kill_effect_text_anim;
		int		kill_effect_num_anim;
		int    kill_effect_textbg_anim;

		float  kill_effect_text_time;
		float  kill_effect_num_time;
		float  kill_effect_textbg_time;
		bool   kill_effect_wait:1;
		bool   kill_effect_flag:1;

		float  key_button_effect_time;
		float  key_button_effect_size;

		Core::Vector3 born_position;

		//zmobie mode level_up effect
		bool  is_level_up_effect_flag:1;
		float is_level_up_effect_ratio[2];
		float is_level_up_effect_time[2];
		float is_level_up_effect_curtime;

		float blood_add_effect_time;
		
		bool  is_point_emeny;

		Core::Array<RadioData> radio_effect_list;

		//for ingameui
		bool	gamestart_ui;
		float   gamestart_time;

		float	grenade_cd_time;

		float	zombiegun_cd_time;
		float	zombiecharge_cd_time;

		bool	state_addbloodformcure;
		float	state_addbloodtime;

		//for curegun
		bool    state_addblood;
		bool    state_addbloodtip;
		float   state_addblood_time;
		float   state_addbloodtip_time;
		float	state_invincible;
		byte    from_cure_id;			// for tip;
		byte    from_cure_id2;			// for teamwork;
		bool    state_addblood2;

		bool    isshooting;

		int		spiritball_num;

		byte    control_person_id;
		Core::Array<byte>	array_reveng_id;
		int		accumulate_damage;
		int		max_hp;
		int		ex_hp;

		bool	is_boss;
		bool	is_fly_uav;
		bool    is_item_boss;
		int		helpkill_num;

		bool	is_move_transparency;
		float	move_transparency_timer;
		float	move_transparency_min_value;
		float	move_transparency_speed;
		Attribute attr_minigunaccurate;
		bool	breducespread;
		int		last_hp;
		float	hp_exist_timer;
		KillerInfo killerinfo;
		
		float call_magic_timer;
		RandFun rand_fun;
		
		float windreverse_time;
		NxActor* effect_collider;

		//sharedc_ptr(ToolsBox) toolsbox;
		Core::Array<sharedc_ptr(ItemParticleTime)> item_mode_buff_time;//��ʾbuffͼ��
		Core::Array<sharedc_ptr(ItemParticleTime)> item_mode_debuff_time;//��ʾdebuffͼ��

	protected:
		int		team;
		bool    isnew_action;
	private:
		MoveInfo	move_info;
		ControllerInfo	controller_info;
		ViewMode	view_mode;
		FirstPerson	first_person;
		ThirdPerson	third_person;
		sharedc_ptr(MoveController) move;
		sharedc_ptr(ActionController) action;

		float runspeed_offset;
		float walkspeed_offset;
		float crouchspeed_offset;
		float flightspeed_offset;

		bool has_bomb;

		bool die_buff;//����buff
		int die_buff_counter;//ʹ��die buff������
		int die_buff_total_count;
		int die_buff_rand_start;
		
		bool die_buff_randing;
		float die_buff_rand_timer;
		float die_buff_rand_gap_timer;

		bool die_buff_staying;
		float die_buff_stay_timer;

		bool die_buff_affecting;
		float die_buff_affect_timer;
		int die_buff_affect;

		int lock_state_type;

		Core::HashSet<Core::Identifier, sharedc_ptr(IBarbette)> barbette_set;
		Core::Array<sharedc_ptr(CharacterParticle)> dead_particles;
		Core::Array<sharedc_ptr(CharacterParticle)> character_particles;
		Core::Array<sharedc_ptr(CharacterParticle)> item_mode_particles;
	public:
		float bomb_plant_timer;

		CharacterChangeableInfo character_changeable_raw_info;

		// for debug
		CharacterChangeableInfo character_changeable_current_info;

		SkillDataList skill_array;
		EffectDataList natural_effect_array;
		EffectDataList acquired_effect_array;

		// zombie mode
		bool zombie_dying_flag;

		//�������ȵ���
		byte zombie_saving_uid;
		//���ھ��ҵ���
		byte zombie_saver_uid;

		//�����ǵ�״̬
		bool zombie_saving_flag;

		float zombie_dying_timer;

		float zombie_saving_timer;

		//common zombie mode
		int common_zombie_level;
		float common_zombie_energy;
		bool can_Invincible;
		int human_energy;
		bool is_human_super;
		bool is_zombie_super;
		float cd_time;

		//ĸ�彩ʬ����״̬
		bool common_zombie_dying_flag;
		float common_zombie_energy_percent;

		//��ʬ������Ч
		FMOD::Event* zombie_2D_breath;
		FMOD::Event* zombie_3D_breath;

		FMOD::Event* invisible_zombie_2D_breath;
		FMOD::Event* invisible_zombie_3D_breath;

		//
		FMOD::Event* boss_2D_fly;
		FMOD::Event* boss_2D_survival;
		FMOD::Event* boss_3D_fly;

		FMOD::Event* boss_2D_boost;
		FMOD::Event* boss_3D_boost;

		FMOD::Event* boss_2D_uav;
		FMOD::Event* boss_3D_uav;

		// human heart sound
		FMOD::Event* zombie_2D_human_heart;

		FMOD::Event* boss_pve;
		FMOD::Event* boss_pve_3d;
		FMOD::Event* boss_pve_scene;
		bool ishalflife;
		Core::String boss_pve_str;
		Core::String boss_pve_str_3d;

#if DEBUG_TOOLS
	public:
		/// copy SelectWeapon
		void SelectWeaponForViewer(uint id, by_ptr(WeaponInfo) info, bool force, bool isthird = false);
		void JumpByViewer();
		void UpdateModelViewer(float frame_time);
#endif

	public:
		void UpdateBossPVEData(float frame_time);

		Core::Vector3 boss_startpos;
		Core::Vector3 boss_endpos;
		Core::Quaternion boss_startrot;
		Core::Quaternion boss_endrot;
		float boss_move_time;
		float boss_action_total_time;
		float boss_action_timer;
		bool  ispveboss;
		int	  boss_action_id;

		float blood_leak_timer;

		int bosspve_phase;

		//��ʬ��Ⱦģʽ ĸ�彩ʬ����ʱ��
		float commonzombie_dying_totletime;
		float commonzombie_dying_time;

		// item mode
		float itemmode_energy;
		float itemmode_energy_max;
		//-1:��, 0:�����������󣩣�1:����������С����2:�����ƶ��ٶȣ�3:�޵У�4:�Ա���5:������6:��Χ�ڶԷ�����
		//7:��Χ�ڶԷ����ң���꣩��8:��Χ�ڶԷ����ң����̣���9:��Χ�ڶԷ������ⵯ��10:������Ծ�߶ȣ�11:��Χ�ڶԷ��޷����
		//12:��Χ�ڶԷ��޷���Ծ��13:�������һ��Ч����14:������Ϊ�ڰ�����
		//15:���Լ���ȫ����٣�16:���Լ���ȫ����ң���꣩��17:���Լ���ȫ���޷���Ծ��18:���Լ���ȫ���޷�����
		int itemmode_item_slot;
		float itemmode_zibao_timer;
		bool itemmode_zibao;
		float itemmode_flag1_timer;
		bool itemmode_flag1;
		float item_box_time;
		float quickmovecd;//˲��CD
		bool isMoonBoss;

		// boss2
		float boss2_human_energy;
		float boss2_human_energy_max;
		int boss2_human_energy_level;

		float boss2_special_weapon_energy;
		float boss2_special_weapon_energy_max;
	
		int boss2_passiveskill_level[4]; //0:�ƶ��ٶȣ�1:��Ծ�߶ȣ�2:���ԣ�3:��������
	
		int boss2_initiative_type; //0:�ޣ�1:�޵У�2:�ظ���3:�������ӣ�4:����&װ���ٶ�

		int boss2_strange_spawn;//-1:�ޣ�0:�̶��������1:�̶�������2:����UAV��3:��ǹUAV
	
		static float boss2_defence_energy;
		static float boss2_defence_energy_max;
		static int boss2_defence_energy_level;

		float boss2_move_energy;
		float boss2_move_energy_max;
		float boss2_move_energy_recovery;
		float boss2_fly_energy_down;

		bool boss2_self_kill;
		float boss2_self_kill_timer;

		float boss2_head_damage;
		float boss2_head_damage_timer;

		// for engineer
		int tower_gun_count;
		float tower_gun_percent;
		float  stick_ammo_explode_timer;

		//for common zombie
		float somg_time;

		int invisible_uid;
		int zibao_uid;
		bool is_invisible;
		int advBoxNum[4];
		float advBoxTime[4];

		//for kSurvivalMode
		int ghostfirecount;
		bool isghost;
		float spawntimebySurvival;
		float spawntimebySurvival1;
		float spawntimebySurvival2;
		float Survivalprompting;
		float Survivalprompting1;
		float SurvivalExpose;

	};
}
