namespace Client
{
	class Character;

	class FirstPerson : public Core::Object
	{
	public:
		/// constructor
		FirstPerson();

		/// destructor
		~FirstPerson();

	public:
		/// on create
		void OnCreate();

		/// on destroy();
		void OnDestroy();

		/// update
		void Update(float frame_time);

		/// on render
		void OnRender(float frame_time);

		/// draw
		void Draw(Primitive::DrawType drawtype, bool immediate = false);

		/// get shader lod
		S32 GetShaderLod();

		/// initialize
		void Initialize();

		/// initialize weapon
		void InitializeWeapon(const PackInfo & pack);

		/// initialize mesh
		void InitializeMesh();

		/// set info
		void SetCharacterInfo(by_ptr(CharacterInfo) info);

		/// preload animation
		void PreloadAnimation(by_ptr(WeaponInfo) info);

		/// preload animation
		void PreloadAnimation(const PackInfo & info);

		/// recover
		void Recover(int health,byte recover_type);
		
		/// ammo recover
		void AmmoRecover(short ammocount,byte recovertype);
		
		/// recover stop
		void RecoverStop();

		/// burn
		void Burn();

		/// burn stop
		void BurnStop();

		/// burn
		void Poison();

		/// burn stop
		void PoisonStop();

		/// is ready
		bool IsReady();

		/// is dizzy
		bool IsDizzy();

		F32 GetDizzyTime();

		void Dizzy(float addtime);
	public:
		/// get camera position
		const Core::Vector3 & GetCameraPosition();

		/// get camera rotation
		const Core::Quaternion & GetCameraRotation();

		/// get skeleton rotation
		const Core::Quaternion & GetSkeletonRotation();

		/// get skeleton position
		const Core::Vector3 & GetSkeletonPosition();

		/// get root position
		const Core::Vector3 & GetTorsoPosition();

		/// set character
		void SetCharacter(by_ptr(Character) c);

		/// get sniper sight state
		bool isSight();

	public:
		/// jump
		void OnJump();

		/// jump
		void OnBoost(int dir);

		/// on ground
		void OnOnground();

		/// fall down
		void FallDown(float speed, bool is_onground);

		/// die
		void Die(const HitInfo & info);

		/// rebirth
		void Rebirth();

		/// kill
		void OnKill(const HitInfo & hit);

		/// on hit
		void OnHit(const HitInfo & info);

		/// on hit
		void ResponseHit(const Core::Vector3 & from_position, const Core::Vector3 & target, const Core::Vector3 & normal, int part, UINT weapontype, bool no_blood = false, bool isboost = false);

		/// on grenade explode
		void OnGrenadeExplode();

		/// on bomb exploded
		void OnBombExploded();

		/// grenade throw in
		void GrenadeThrowIn();

		/// throw grenade
		void GrenadeThrowOut(by_ptr(ThrowableInfo) info, int weapon_id);

		/// stop throw grenade
		void GrenadeThrowStop();

		/// knife stab
		void Stab(byte type, int weapon_id);

		/// stop stab
		void StopStab();

		/// select weapon
		void SelectWeapon(uint weapon_id);

		/// weapon active
		void WeaponActive(uint id);

		/// weapon inactive
		void WeaponInactive(uint id);

		/// set weapon
		void SetWeapon(int slot, by_ptr(WeaponInfo) info);

		/// get weapon
		tempc_ptr(WeaponBase) GetWeapon(int id);
		
		sharedc_ptr(Bomb) GetBomb();

		/// shooting
		void Shoot(int weapon_id,bool isboost = false);

		void StartCharge();

		/// stop shooting
		void StopShoot();

		/// reload
		void Reload();

		void PlantBomb();

		// drop weapon
		void DropWeapon(int slot);

		// pick up weapon
		void PickUpWeapon(int slot, by_ptr(WeaponInfo) info);

		/// udpate weapon
		void UpdateWeapon(float frame_time);

		/// udpate equipment
		void UpdateEquipment(float frame_time);
		
		/// has bomb
		//bool FirstPerson::HasBomb();

		/// use skill
		void UseSkill(by_ptr(PlayerSkill) skill);

		/// use skill stop
		void UseSkillStop(by_ptr(PlayerSkill) skill);

	public:
		/// update audio
		void UpdateAudio(float frame_time);

		/// update animation
		void UpdateAnimation(float frame_time);

		/// update animation first person
		void UpdateAnimationFirstPerson();

		/// update animation joint
		void UpdateAnimationJoint(float frame_time);

		/// update transform
		void UpdateTransform(float frame_time);

		/// update bounding box
		void UpdateBoundingBox();

		/// get world aabb
		const Core::AxisAlignedBox& GetWorldAABB() const;

		void LoadSkeleton();

		void StopAudioStep();

#if DEBUG_TOOLS
		/// copy OnRender
		void UpdateModelViewer(float frame_time);
		void UpdateAnimationFirstPersonForViewer(float frame_time);
#endif

	private:
		/// create animation
		void CreateAnimation();

	private:
		tempc_ptr(Character)			character;
		sharedc_ptr(CharacterInfo)	character_info;
		sharedc_ptr(SkinMesh)		mesh;
		sharedc_ptr(SkinMesh)		draw_mesh;


		Core::FixedArray<sharedc_ptr(WeaponBase), 7> weapons;
		Core::FixedArray<sharedc_ptr(AnimationSetRes), 7> animation_set_weapon;


		// sound
		FMOD::Event* audio_step;
		FMOD::Event* tank_idel_2d;

		// transform
		Core::Vector3 skeleton_position;
		Core::Quaternion skeleton_rotation;
		float skeleton_punch;
		Core::Vector3 camera_position;
		Core::Quaternion camera_rotation;

		Core::Vector3 root_position;

		// aabb
		Core::AxisAlignedBox			world_aabb;

	public:
		// animation
		sharedc_ptr(Skeleton)			skeleton;
		sharedc_ptr(AnimationSet)		animation_set;
		sharedc_ptr(AnimationNodeBlend)	animation_system;
		sharedc_ptr(AnimationNodeCustom)	animation_action;
		sharedc_ptr(AnimationNodeCustom)	animation_camera;
		sharedc_ptr(AnimationNodeList)	animation_list;
		sharedc_ptr(Pose)				pose;

		sharedc_ptr(AnimationNodeGroup)	animation_group;
		int show_count;
		float anim_play_time_percentage;

	private:
		// hold weapon
		Core::Array<sharedc_ptr(WeaponBase)>		weapon_hold_set;
		int	now_step_material;
		int now_stepway;
		F32								dizzy_time;
		bool							bdizzy;

		float							weapon_reload_total_time;
		float							weapon_reload_time;
	};
}