#include "pch.h"

using namespace Core;

DEFINE_PDE_TYPE_ENUM(Client::CharacterPart)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_ENUM_ITEM("kCharacterPartTorso",		Client::kCharacterPartTorso);
		ADD_PDE_ENUM_ITEM("kCharacterPartBack",			Client::kCharacterPartBack);
		ADD_PDE_ENUM_ITEM("kCharacterPartChest",		Client::kCharacterPartChest);
		ADD_PDE_ENUM_ITEM("kCharacterPartHead",			Client::kCharacterPartHead);

		ADD_PDE_ENUM_ITEM("kCharacterPartShoulderL",	Client::kCharacterPartShoulderL);
		ADD_PDE_ENUM_ITEM("kCharacterPartArmL",			Client::kCharacterPartArmL);
		ADD_PDE_ENUM_ITEM("kCharacterPartElbowL",		Client::kCharacterPartElbowL);
		ADD_PDE_ENUM_ITEM("kCharacterPartWristL",		Client::kCharacterPartWristL);

		ADD_PDE_ENUM_ITEM("kCharacterPartShoulderR",	Client::kCharacterPartShoulderR);
		ADD_PDE_ENUM_ITEM("kCharacterPartArmR",			Client::kCharacterPartArmR);
		ADD_PDE_ENUM_ITEM("kCharacterPartElbowR",		Client::kCharacterPartElbowR);
		ADD_PDE_ENUM_ITEM("kCharacterPartWristR",		Client::kCharacterPartWristR);

		ADD_PDE_ENUM_ITEM("kCharacterPartLegL",			Client::kCharacterPartLegL);
		ADD_PDE_ENUM_ITEM("kCharacterPartKneeL",		Client::kCharacterPartKneeL);
		ADD_PDE_ENUM_ITEM("kCharacterPartAnkleL",		Client::kCharacterPartAnkleL);

		ADD_PDE_ENUM_ITEM("kCharacterPartLegR",			Client::kCharacterPartLegR);
		ADD_PDE_ENUM_ITEM("kCharacterPartKneeR",		Client::kCharacterPartKneeR);
		ADD_PDE_ENUM_ITEM("kCharacterPartAnkleR",		Client::kCharacterPartAnkleR);

		ADD_PDE_ENUM_CONSTRUCTOR();
	}
};

DEFINE_PDE_TYPE_ENUM(Client::DetachablePartType)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_ENUM_ITEM("kDetachablePartNormal",		Client::kDetachablePartNormal);

		ADD_PDE_ENUM_CONSTRUCTOR();
	}
};

DEFINE_PDE_TYPE_CLASS(Client::Character)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_METHOD(SetWeapon);
		ADD_PDE_METHOD(SetCharacterInfo);

		ADD_PDE_METHOD(SetClientSynScriptStringValue);
		ADD_PDE_METHOD(GetClientSynScriptStringValue);
		ADD_PDE_METHOD(HasClientSynScriptStringValue);

		ADD_PDE_METHOD(SetClientSynScriptNumberValue);
		ADD_PDE_METHOD(GetClientSynScriptNumberValue);
		ADD_PDE_METHOD(HasClientSynScriptNumberValue);

		ADD_PDE_METHOD(PlayCharacterParticle);
		ADD_PDE_METHOD(CleanAllCharacterParticle);
		ADD_PDE_METHOD(PveClientPlayAction);
		ADD_PDE_METHOD(PveClientStopAction);

		ADD_PDE_METHOD(SetBossPVEAction);
		ADD_PDE_METHOD(GetBossPVEAction);

		ADD_PDE_METHOD(PveClientPlaySound);

		ADD_PDE_METHOD(IsDied);
		ADD_PDE_METHOD(CheckCanHit);

		ADD_PDE_METHOD(GetBarbetteByName);
	}
};

REGISTER_PDE_TYPE(Client::CharacterPart);
REGISTER_PDE_TYPE(Client::DetachablePartType);

REGISTER_PDE_TYPE(Client::Character);

namespace Client
{
	float Character::boss2_defence_energy = 0;
	float Character::boss2_defence_energy_max = 1000;
	int Character::boss2_defence_energy_level = 0;

	// constructor
	Character::Character()
		: uid(-1)
		, control_uid(0)
		, team(-1)
		, is_vip(0)
		, business_card(0)
		, is_gm(0)
		, level(0)
		, hp(0)
		, armor(0)
		, num_killed(0)
		, num_died(0)
		, num_assist(0)
		, ping(0)
		, invincible_time(0)
		, sustainflame_time(0)
		, poison_time(0)
		, died(true)
		, cure_all_value(0)
		, kill_anim_time(0.f)
		, kill_showscore(0.f)
		, kill_score_time(1.f)
		, isshowevent(true)
		, score(0)
		, all_score(0)
		, ui_score_line(0)
		, reloading(false)
		, shooting(false)
		, throwing_grenade(false)
		, grenade_throw_out(false)
		, stabing(false)
		, planting_bomb(false)

		, first_action_on(false)
		, second_action_on(false)

		, weapon_id(-1)
		, equipment_id(-1)
		, bsniperassist(false)
		, weapon_id_next(0)
		, weapon_id_last(2)
		, weapon_select_state(kWeaponReady)

		, pack_index(0)

		, punch_angle(Vector3::kZero)
		, punch_angle_velocity(0, 0, 0)
		, height_offset(0.1f)

		, ready(false)
		, connected(false)
		, playing(false)

		, died_time(5.f)
		, died_timer(0.f)
		, died_temp_timer(0.f)
		, physx_control(false)

		, dual_pistol_status(false)

		, view_mode(kThirdPerson)

		, camera_fov(NORMAL_FOV)
		, camera_target_fov(NORMAL_FOV)
		, camera_fov_change(0)
		, camera_distance(0.f)
		, camera_control_mode(Camera::kViewMode)
		, camera_position(Vector3::kZero)
		, camera_rotation(Quaternion::kIdentity)
		, camera_rotation_offset(Quaternion::kIdentity)
		, mouse_sensitivity(1.f)

		, update_time((float)timeGetTime() / 1000.f)
		, time(0)

		, relife_flag(false)
		, relife_time(0.0f)
		, relife_maxtime(0.0f)
		, select_player_flag(true)

		, flash_bright_time(0)
		, flash_fade_time(2)
		, special_particle_time(0.f)
		, tp_special_particle_time(0.f)
		, weapon_list_icon_flag(false)
		, weapon_list_icon_waittime(0.0f)
		, weapon_list_icon_movetime(1.0f)
	    , weapon_list_icon_alpha(0.0f)

		, attack_level_flag(false)
		, attack_level_count(0)
		, explode_num(0)
		, unexplode_num(0)
		, pickup_banner_num(0)
		, return_banner_num(0)

		, hit_current_score(0)
		, hit_scroll_time(0.0f)

		, attack_level_time(0.0f)
		, old_hp(0)
		, new_hp(0)
		, cross_hair_offset(0.f)
		, occluded(false)
		, hits_score_wait_time(0.0f)
		, hits_score_alpha(0.0f)
		, control_reverse_timer(0)
		, radar_timer(0)
		, radar_ui_timer(0)
		, damage_hp(0)
		, damage_armor(0)
		, is_display_damage_hp(false)
		, damage_hp_time(0.0f)
		, bag_flag(false)
		, bag_wait_time(0.0f)
		, bag_flash_time(0.0f)
		, is_bag_open(false)
		, is_text_show(false)
		, current_bag_id(1)
		, current_help_id(1)
		, prev_bag_id(1)
		, bag_dialog_wait_time(0.0f)
		, is_ready_bag_close(false)
		, team_request_waittime(0.0f)
		, team_success_join_time(0.0f)
		, team_refuse_time(0.0f)
		, power_up_time(0.0f)
		, disguise_time(0.0f)
		, kill_effect_text_anim(0)
		, kill_effect_num_anim(0)
		, kill_effect_text_time(0.0f)
		, kill_effect_num_time(0.0f)
		, kill_effect_wait(false)
		, kill_effect_flag(false)
		, kill_effect_textbg_time(0.0f)
		, kill_effect_textbg_anim(0)
		, key_button_effect_time(0.0f)
		, key_button_effect_size(0.0f)
		, born_position(Vector3::kZero)
		, is_range_bag_flag(false)
		, transparency(kTransparencyNone)
		, transparency_value(1.0f)
		, transparency_time(0.f)
		, special_mode(kSpStateNone)
		, is_complete_raise(false)
		, is_fov_changed(false)
		, fire_time_ratio(0.0f)
		, blood_add_effect_time(0.0f)
		, is_point_emeny(false)
		, radio_state(0)
		, radio_id(-1)
		, radio_item(-1)
		, already_team_defuse(false)
		, is_team_hurt_part(false)
		, is_team_hurt_dead(false)
		, team_hurt_time(0.0f)
		, team_hurt_part_time(0.0f)
		, team_hurt_dead_time(0.0f)
		, is_shoot_stab(false)
		, is_display_friend_name(true)
		, gamestart_ui(false)
		, gamestart_time(1.0f)
		, current_career(-1)
		, grenade_cd_time(-1.f)
		, zombiegun_cd_time(0.f)
		, zombiecharge_cd_time(-1.f)
		, keep_Shoot(false)
		, keep_Shoot_fp(false)
		, keep_Shoot_mini(false)
		, keep_Shoot_mini_tp(false)
		, state_addbloodformcure(false)
		, state_addbloodtime(0.f)
		, call_magic_timer(0.f)
		, state_addblood(false)
		, state_addbloodtip(false)
		, state_addblood_time(0.0f)
		, state_addbloodtip_time(0.0f)
		, from_cure_id(0)
		, from_cure_id2(0)
		, state_addblood2(false)
		, state_invincible(0.0f)
		, skip_grenade(false)
		, isshooting(false)
		, control_person_id(0)
		, get_score(0)
		, get_last_score(0)
		, spiritball_num(0)
		, max_hp(0)
		, ex_hp(0)
		, runspeed_offset(0.f)
		, walkspeed_offset(0.f)
		, crouchspeed_offset(0.f)
		, flightspeed_offset(0.f)
		, is_boss(false)
		, is_fly_uav(false)
		, is_item_boss(false)
		, benefitshadertype(-1)
		, benefitshadertime(0.f)
		, lian_kill_count(0)
		, is_move_transparency(false)
		, move_transparency_timer(0.f)
		, move_transparency_min_value(0.f)
		, move_transparency_speed(0.f)
		, windreverse_time(-1.f)
		, breducespread(false)
		, effect_collider(NULL)
		, gun_special_particle(NullPtr)
		, tp_special_particle(NullPtr)
		, has_bomb(false)
		, bomb_plant_timer(-1.f)
		, show_shoot_time(0)
		, show_text_time (0)
		, zombie_dying_flag(false)
		, zombie_saving_flag(false)
		, zombie_saving_uid(0)
		, zombie_saver_uid(0)
		, zombie_dying_timer(0.f)
		, zombie_saving_timer(0.f)
		, common_zombie_level(0)
		, common_zombie_energy(0.f)
		, can_Invincible(false)
		, human_energy(0)
		, is_human_super(false)
		, is_zombie_super(false)
		, cd_time(-1.0f)
		, zombie_2D_breath(NULL)
		, zombie_3D_breath(NULL)
		, invisible_zombie_3D_breath(NULL)
		, invisible_zombie_2D_breath(NULL)
		, boss_2D_fly(NULL)
		, boss_3D_fly(NULL)
		, boss_2D_survival(NULL)
		, boss_2D_boost(NULL)
		, boss_3D_boost(NULL)
		, boss_2D_uav(NULL)
		, boss_3D_uav(NULL)
		, zombie_2D_human_heart(NULL)
		, common_zombie_dying_flag(false)
		, lock_state_type(0)
		, boss_action_timer(-1)
		, boss_action_total_time(-1)
		, boss_move_time(-1)
		, boss_action_id(-1)
		, ispveboss(false)
		, boss_pve(NULL)
		, boss_pve_3d(NULL)
		, boss_pve_scene(NULL)
		, ishalflife(false)
		, blood_leak_timer(-1.f)
		, isnew_action(true)
		, bosspve_phase(-1)
		, commonzombie_dying_totletime(0.0f)
		, commonzombie_dying_time(0.0f)
		, itemmode_energy(0.f)
		, itemmode_energy_max(0.f)
		, itemmode_item_slot(-1)
		, itemmode_zibao_timer(0.f)
		, itemmode_zibao(false)
		, itemmode_flag1_timer(0.f)
		, itemmode_flag1(false)
		, quickmovecd(0.f)
		, isMoonBoss(false)
		, item_box_time(0.f)
		, boss2_human_energy(0.0f)
		, boss2_human_energy_max(0.0f)
		, boss2_human_energy_level(0)
		, boss2_special_weapon_energy(0.0f)
		, boss2_special_weapon_energy_max(0.0f)
		, boss2_initiative_type(0)
		, boss2_strange_spawn(-1)
		, boss2_move_energy(0.0f)
		, boss2_move_energy_max(0.0f)
		, boss2_move_energy_recovery(0.0f)
		, boss2_fly_energy_down(0.0f)
		, boss2_self_kill(false)
		, boss2_self_kill_timer(0.0f)
		, boss2_head_damage(0.f)
		, boss2_head_damage_timer(0.f)
		, tower_gun_count(0)
		, tower_gun_percent(1.f)
		, stick_ammo_explode_timer(-1.f)
		, somg_time(-1.f)
		, invisible_uid(0)
		, zibao_uid(0)
		, is_invisible(false)
		, ghostfirecount(0)
		, isghost(false)
		, spawntimebySurvival(0.f)
		, spawntimebySurvival1(0.f)
		, spawntimebySurvival2(0.f)
		, Survivalprompting(0.f)
		, Survivalprompting1(0.f)
		, SurvivalExpose(0.f)
	{
		physx_group = PhysxSystem::kGroupStart;

		boss2_passiveskill_level[0] = 0;
		boss2_passiveskill_level[1] = 0;
		boss2_passiveskill_level[2] = 0;
		boss2_passiveskill_level[3] = 0;

		advBoxNum[0] = 0;
		advBoxNum[1] = 0;
		advBoxNum[2] = 0;
		advBoxNum[3] = 0;

		advBoxTime[0] = 0.f;
		advBoxTime[1] = 0.f;
		advBoxTime[2] = 0.f;
		advBoxTime[3] = 0.f;

		die_buff =false;
		die_buff_total_count =0;
		die_buff_counter =0;
		die_buff_rand_start =-1;
		die_buff_rand_gap_timer =DIE_BUFF_RAND_GAP_TIME;
		die_buff_rand_timer =DIE_BUFF_RAND_TIME;
		die_buff_stay_timer =DIE_BUFF_STAY_TIME;
		die_buff_randing =false;
		die_buff_staying =false;
		die_buff_affecting =false;
		die_buff_affect =-1;
	}

	// destructor
	Character::~Character()
	{
		if (effect_collider)
		{
			PhysxSystem::ReleaseActor(*effect_collider);
			effect_collider = NULL;
		}
		if (zombie_2D_breath)
		{
			zombie_2D_breath->stop();
			zombie_2D_breath = NULL;
		}		
		if (zombie_3D_breath)
		{
			zombie_3D_breath->stop();
			zombie_3D_breath = NULL;
		}
		if (invisible_zombie_2D_breath)
		{
			invisible_zombie_2D_breath->stop();
			invisible_zombie_2D_breath = NULL;
		}
		if (invisible_zombie_3D_breath)
		{
			invisible_zombie_3D_breath->stop();
			invisible_zombie_3D_breath = NULL;
		}
		if (boss_2D_fly)
		{
			boss_2D_fly->stop();
			boss_2D_fly = NULL;
		}
		if (boss_3D_fly)
		{
			boss_3D_fly->stop();
			boss_3D_fly = NULL;
		}
		if (boss_2D_survival)
		{
			boss_2D_survival->stop();
			boss_2D_survival = NULL;
		}
		if (boss_2D_boost)
		{
			boss_2D_boost->stop();
			boss_2D_boost = NULL;
		}
		if (boss_3D_boost)
		{
			boss_3D_boost->stop();
			boss_3D_boost = NULL;
		}
		if (boss_2D_uav)
		{
			boss_2D_uav->stop();
			boss_2D_uav = NULL;
		}
		if (boss_3D_uav)
		{
			boss_3D_uav->stop();
			boss_3D_uav = NULL;
		}
		if (zombie_2D_human_heart)
		{
			zombie_2D_human_heart->stop();
			zombie_2D_human_heart = NULL;
		}
		if (boss_pve)
		{
			boss_pve->stop();
			boss_pve = NULL;
		}
		if (boss_pve_3d)
		{
			boss_pve_3d->stop();
			boss_pve_3d = NULL;
		}
		if (boss_pve_scene)
		{
			boss_pve_scene->stop();
			boss_pve_scene = NULL;
		}
		m_PVEAmmoLaserSet.Clear();
	}
}


namespace Client
{
	/// on create
	void Character::OnCreate()
	{
		Object::OnCreate();

		control_uid = 0;

		for (uint i = 0; i < hit_ui.Size(); i ++)
			hit_ui[i].time = 0;

		tempc_ptr(Character) self = ptr_static_cast<Character>(this);
		first_person.SetCharacter(self);
		third_person.SetCharacter(self);

		SetActionController(ptr_new ActionController);
		SetMoveController(ptr_new MoveController);

		move_info.move_factor = 1.f;
		move_info.jump_factor = 1.f;

		move_info.crouch_speed = 2.f;
		move_info.flight_speed = 1.f;
		move_info.flight_max_speed = 5.f;
		move_info.acceleration = 8.f;

		move_info.jump_velocity = 7.f;

		hit_current_score = 0;
		keep_Shoot_mini_state = -1;

		memset(&energy_bar_info,0,sizeof(energy_bar_info));
		isshooting = false;

		control_person_id = 0;
		array_reveng_id.Clear();
		helpkill_num = 0;
		cure_all_value = 0;
		all_score = 0;
		ui_score_line = 0;
		bosspve_phase = -1;
		get_score = 250 * pow((float)4,ui_score_line);
		get_last_score = 0;

		for(int i = 0 ; i < 5; i++)
			speaker_tip_time[i] = 100.0f;
		
		switch (gLevel->game_type)
		{
		case RoomOption::kHoldPoint:
			{
				get_score = get_score * 1.3;
				get_last_score = get_last_score * 1.3;
			}
			break;
		case RoomOption::kPushVehicle:
			{
				get_score = get_score * 1.3;
				get_last_score = get_last_score * 1.3;
			}
			break;
		case RoomOption::kTeam:
			{
				get_score = get_score * 1.1;
				get_last_score = get_last_score * 1.1;
			}
			break;
		case RoomOption::KMoonMode:
			{
				get_score = get_score * 1.1;
				get_last_score = get_last_score * 1.1;
			}
			break;
		case RoomOption::kAdvenceMode:
			{
				get_score = get_score * 1.1;
				get_last_score = get_last_score * 1.1;
			}
			break;
		case RoomOption::kSurvivalMode:
			{
				get_score = get_score * 1.1;
				get_last_score = get_last_score * 1.1;
			}
			break;
		case RoomOption::kKnifeMode:
			{
				get_score = get_score * 1.2;
				get_last_score = get_last_score * 1.2;
			}
			break;
		case RoomOption::kBoss:
			{
				get_score = get_score * 1.9;
				get_last_score = get_last_score * 1.9;
			}
			break;
		case RoomOption::kTeamDeathMatch:
			{
				get_score = get_score * 6 / 10;
				get_last_score = get_last_score * 6 / 10;
			}
			break;
		case RoomOption::kBombMode:
			{
				get_score = get_score * 6 / 10;
				get_last_score = get_last_score * 6 / 10;
			}
			break;
		case RoomOption::kStreetBoyMode:
			{
				get_score = get_score * 7 / 10;
				get_last_score = get_last_score * 7 / 10;
			}
			break;
		case RoomOption::kZombieMode:
			{
				get_score = get_score * 1.1;
				get_last_score = get_last_score * 1.1;
			}
			break;
		case RoomOption::kEditMode:
			{
			}
			break;
		case RoomOption::kTDMode:
			{
			}
			break;
		}
		last_hp = 0;
		hp_exist_timer = 0.f;

		m_PVEAmmoIdBuilder = 0;

		ClearClientSynScriptValue();
	}

	/// on destroy
	void Character::OnDestroy()
	{
		action = NullPtr;
		move = NullPtr;
		kills_kind.Clear();
		cache_character_info.Clear();

		//hack for StateDebugAnim
		if (!gLevel)
		{
			Object::OnDestroy();
			return;
		}
		dead_particles.Clear();
		character_particles.Clear();
		item_mode_particles.Clear();
		item_mode_buff_time.Clear();
		item_mode_debuff_time.Clear();
		Object::OnDestroy();
	}

	//Update Occludee
	void Character::UpdateOccludee()
	{
		if (team > 1)
			return;

		occluded = false;

		if (!gLevel->activeOC)
			return;

		if(gLevel->GetViewer() == this)
			return; 

		if(gGame->camera->control_mode == Camera::kDiedMode)
			return;

		PROFILE("UpdateOccludee");

		/*Matrix44 view, proj, viewproj;

		gGame->camera->CalculateViewProjectionMatrix(view, proj);
		viewproj = view * proj;

		FrustumArea frustum;
		frustum.Update(viewproj);*/

		AxisAlignedBox aabb(third_person.GetWorldAABB());
		
		
		// frustum culling
		if (AABB_IS_OUTSIDE(aabb.TestIntersection(&gGame->camera->frustum, 0)))
		{
			occluded = true;
			return;
		}

		occludee.InitAABB( aabb, gGame->camera->viewprojMatrix, true );

		for ( uint i = 0; i<gLevel->occluderplanes.Size(); i++ )
		{
			if( gLevel->occluderplanes[i].IsVisible() )
			{
				if( gLevel->occluderplanes[i].Occlude2D( occludee ) == kBackSide)
				{
					occluded = true;
					return;
				}
			}
		}
	}

	/// update 
	void Character::UpdateSyncData(float frame_time)
	{
		// no sync data, return
		if (sync_data.Empty())
			return;

		CharacterSyncData data;
		Vector3	vel;

		// remove unused data
		while (sync_data.Size() > 1 && sync_data[1].time <= sync_time)
			sync_data.PopFront();

		if (sync_data.Size() > 1)
		{
			CharacterSyncData & data1 = sync_data[0];
			CharacterSyncData & data2 = sync_data[1];

			float s = Clamp((sync_time - data1.time) / (data2.time - data1.time), 0, 1);

			Lerp(data.position, data1.position, data2.position, s);
			Core::Slerp(data.rotation, data1.rotation, data2.rotation, s);

			data.crouch = data1.crouch;
			data.walk = data1.walk;
			data.jump = data1.jump;
			data.onground = data1.onground;
			data.move = data1.move;
			data.flying = data1.flying;
			data.boost = data1.boost;

			// calculate velocity
			vel = (data.position - GetPosition()) / frame_time;

			// update time
			float delay_time = sync_data.Back().time - sync_time;

			// scale time when delay time > 0.05
			if (delay_time > 0.1f)
				frame_time *= 1 + (delay_time - 0.1f);

			sync_time += frame_time;
		}
		else
		{
			data = sync_data[0];
			vel = Vector3::kZero;
			sync_time = sync_data[0].time;
		}

		// set character data
		SetPosition(data.position);
		SetLookDir(data.rotation);
		SetCurrentSpeed(vel);
		SetCrouch(data.crouch);
		SetWalk(data.walk);
		SetJump(data.jump);
		SetOnGround(data.onground);
		SetFly(data.flying);
		SetBoost(data.boost, 0);
		SetMove(data.move.x, data.move.y);
	}

	void Character::SetGrenadeCDTiming(float time)
	{
		grenade_cd_time = time;
	}

	void Character::UpdateUiScoreLine()
	{
		while (all_score >= get_score && ui_score_line < 3)
		{
			ui_score_line++;
			int temp_line = ui_score_line + 1;
			//���㹫ʽ �����˳�ʼ��������ҲҪ�޸�
			get_score = 250 * pow((float)4,ui_score_line);
			get_last_score =250 * pow((float)4,ui_score_line-1);

			switch (gLevel->game_type)
			{
			case RoomOption::kHoldPoint:
				{
					get_score = get_score * 1.3;
					get_last_score = get_last_score * 1.3;
				}
				break;
			case RoomOption::kPushVehicle:
				{
					get_score = get_score * 1.3;
					get_last_score = get_last_score * 1.3;
				}
				break;
			case RoomOption::kTeam:
				{
					get_score = get_score * 1.1;
					get_last_score = get_last_score * 1.1;
				}
				break;
			case RoomOption::KMoonMode:
				{
					get_score = get_score * 1.1;
					get_last_score = get_last_score * 1.1;
				}
				break;
			case RoomOption::kAdvenceMode:
				{
					get_score = get_score * 1.1;
					get_last_score = get_last_score * 1.1;
				}
				break;
			case RoomOption::kSurvivalMode:
				{
					get_score = get_score * 1.1;
					get_last_score = get_last_score * 1.1;
				}
				break;
			case RoomOption::kKnifeMode:
				{
					get_score = get_score * 1.2;
					get_last_score = get_last_score * 1.2;
				}
				break;
			case RoomOption::kBoss:
				{
					get_score = get_score * 1.9;
					get_last_score = get_last_score * 1.9;
				}
				break;
			case RoomOption::kTeamDeathMatch:
				{
					get_score = get_score * 6 / 10;
					get_last_score = get_last_score * 6 / 10;
				}
				break;
			case RoomOption::kBombMode:
				{
					get_score = get_score * 6 / 10;
					get_last_score = get_last_score * 6 / 10;
				}
				break;
			case RoomOption::kStreetBoyMode:
				{
					get_score = get_score * 7 / 10;
					get_last_score = get_last_score * 7 / 10;
				}
				break;
			case RoomOption::kZombieMode:
				{
					get_score = get_score * 1.1;
					get_last_score = get_last_score * 1.1;
				}
				break;
			case RoomOption::kEditMode:
				{
				}
				break;
			case RoomOption::kTDMode:
				{
				}
				break;
			}
			FmodSystem::PlayEvent("bj/event/get_treasurebox");
		}		
	}

	/// update
	void Character::Update(float frame_time)
	{
		PROFILE("Character::Update");
		if ( spawntimebySurvival > 0.f)
		{
			spawntimebySurvival -= frame_time;
		}		
		if ( spawntimebySurvival1 > 0.f)
		{
			spawntimebySurvival1 -= frame_time;
		}
		if ( spawntimebySurvival2 > 0.f)
		{
			spawntimebySurvival2 -= frame_time;
		}
		if ( Survivalprompting > 0.f )
		{
			Survivalprompting -= frame_time;
		}
		if ( Survivalprompting1 > 0.f )
		{
			Survivalprompting1 -= frame_time;
		}
		if ( SurvivalExpose > 0.f )
		{
			SurvivalExpose -= frame_time;
		}
		UpdateDieBuff(frame_time);
		HashSet<U16, sharedc_ptr(PVEAmmo)>::Enumerator itr(m_PVEAmmoSet);
		while (itr.MoveNext())
		{
			tempc_ptr(PVEAmmo) pve_ammo = itr.Value();
			if (pve_ammo)
				pve_ammo->Update(frame_time);
		}

		HashSet<U16, sharedc_ptr(PVEAmmoLaser)>::Enumerator itrlaser(m_PVEAmmoLaserSet);
		while (itrlaser.MoveNext())
		{
			tempc_ptr(PVEAmmoLaser) pve_ammolaser = itrlaser.Value();
			if (pve_ammolaser)
				pve_ammolaser->Update(frame_time);
		}

		if(last_hp > hp)
		{
			last_hp -= int(Ceil(100.f * frame_time));
			if(last_hp < hp)
			{
				last_hp = hp;
			}
		}

		if (call_magic_timer > 0)
			call_magic_timer -= frame_time;

		if (show_shoot_time > 0)
			show_shoot_time -= frame_time;
		else
			show_shoot_time = 0;

		if (show_text_time > 0 )
		{
			show_text_time -= frame_time;
		}
		else
			show_text_time = 0;

		if(grenade_cd_time >= 0.f)
		{
			grenade_cd_time -= frame_time;
		}

		if(max_hp != 0 && !IsDied())
		{
			float f = (float)hp / (float)max_hp;
			if(f < 0.3f)
			{
				blood_leak_timer = 1.f;
			}
		}

		if (bosspve_phase != gLevel->level_eventmgr->GetServerScriptNumberValue(GetName()))
		{
			bosspve_phase = gLevel->level_eventmgr->GetServerScriptNumberValue(GetName());
			SetBossPVEAction(true);
		}

		if(blood_leak_timer >= 0.f)
		{
			blood_leak_timer -= frame_time;
		}

		if (somg_time >= 0.f)
		{
			somg_time -= frame_time;
			if (somg_time < 0.f)
			{
				if (gLevel->somg_particle_set.Size() > 0)
				{
					HashSet<uint, sharedc_ptr(ParticleSystem)>::Enumerator itr(gLevel->somg_particle_set);
					while (itr.MoveNext())
					{
						if (itr.Key() == uid)
						{
							gLevel->RemoveParticle(itr.Value());
							gLevel->somg_particle_set.Remove(itr.Key());
							somg_time = -1.f;
							gGame->channel_connection->SomgAreaCancel(uid);
							break;
						}
					}
				}
			}
		}
		
		for (int i = 0; i < 9;++i)
		{
			WeaponBase* weapon = ptr_dynamic_cast<WeaponBase>(GetWeaponById(i));
			if(weapon && weapon->GetWeaponType() == kWeaponTypeZombieGun)
			{
				tempc_ptr(ZombieGun) zb_gun = ptr_dynamic_cast<ZombieGun>(weapon);
				if (zb_gun)
				{
					if (zombiegun_cd_time <= zb_gun->knife_info->skill_cooldown)
					{
						zombiegun_cd_time += frame_time;
					}
				}
			}
		}

		//LogSystem.WriteLinef("benefitshadertime = %f", benefitshadertime);

		if (gLevel)
		{
			if (gLevel->game_type == RoomOption::kItemMode)
			{
				if (itemmode_zibao)
				{
					itemmode_zibao_timer -= frame_time;
					if (itemmode_zibao_timer <= 0)
					{
						if (gLevel->GetPlayer() == this)
						{
							float distance = 0;
							const Array<sharedc_ptr(Character)> & characters = gLevel->GetCharacters();
							Core::Array<byte> uids;

							for (U32 i = 0; i < characters.Size(); i++)
							{
								if (characters[i]->GetTeam() < 2 && characters[i]->GetTeam() != GetTeam() &&
									characters[i]->CheckGrenade2(GetPosition() + Vector3(0,GetHeight()/2,0), distance))
								{
									if (distance <= 5.f)
										uids.PushBack(characters[i]->uid);
								}
							}

							gGame->channel_connection->ZiBao_ItemMode(uids);
						}

						itemmode_zibao = false;
					}
				}
				if (!((int)gLevel->rule_value - (int)gGame->scores->team_kills[0] <= 15 || (int)gLevel->rule_value - (int)gGame->scores->team_kills[1] <= 15) && is_item_boss && gLevel->GetPlayer() == this)
				{
					itemmode_flag1_timer -= frame_time;
					if (itemmode_flag1_timer <= 0)
					{
						if (((int)gLevel->rule_value - (int)gGame->scores->team_kills[0] <= 15 || (int)gLevel->rule_value - (int)gGame->scores->team_kills[1] <= 15))
						{
						}
						else
						{
							gGame->channel_connection->ForceSpawn();
							gLevel->GetPlayer()->is_item_boss = false;
							itemmode_flag1 = false;
						}
					}
				}
				if (quickmovecd>0 && gLevel->GetPlayer() == this)
				{
					quickmovecd -= frame_time;
				}
				if (item_box_time>0 && gLevel->GetPlayer() == this)
				{
					item_box_time -= frame_time;
				}
			}

			if (gLevel->game_type == RoomOption::KMoonMode)
			{
				quickmovecd = 500;
				if (itemmode_flag1_timer>0 && gLevel->GetPlayer() == this)
				{
					itemmode_flag1_timer -= frame_time;
				}
				
				if (itemmode_flag1_timer <= 0 && is_item_boss && gLevel->GetPlayer() == this)
				{
					gGame->channel_connection->ForceSpawn();
					gLevel->GetPlayer()->is_item_boss = false;
				}
			}
			

			if (gLevel->game_type == RoomOption::kBossMode2 && team == 1 && !IsDied())
			{
				if (IsFlying())
				{
					boss2_move_energy -= boss2_fly_energy_down * 1.5 * frame_time;
					if (boss2_move_energy < 0)
					{
						boss2_move_energy = 0;
						SetFly(false);

					}	
				}
				else if (IsBoost())
				{
					boss2_move_energy -= boss2_fly_energy_down * frame_time;
					if (boss2_move_energy < 0)
					{
						boss2_move_energy = 0;
						SetBoost(false,0);
					}	
				}
				else
				{
					boss2_move_energy += boss2_move_energy_recovery * frame_time;
					if (boss2_move_energy > boss2_move_energy_max)
						boss2_move_energy = boss2_move_energy_max;
				}
			}

			if (gLevel->game_type == RoomOption::kBossMode2 && boss2_self_kill)
			{
				boss2_self_kill_timer -= frame_time;
				if (boss2_self_kill_timer <= 0)
				{
					if (this == gLevel->GetPlayer() && gGame->channel_connection)
					{
						gGame->channel_connection->Suicide();
					}

					boss2_self_kill = false;
				}
			}

			if (gLevel->game_type == RoomOption::kBossMode2)
			{
				if (boss2_head_damage_timer > 0)
				{
					boss2_head_damage_timer -= frame_time;
					if (boss2_head_damage_timer <= 0)
					{
						boss2_head_damage_timer = 0;

						FMOD_VECTOR vel = {0, 0, 0};
						FmodSystem::Play3DEvent("bj/player/3d/armor_robot/armor_reboot", (const FMOD_VECTOR &)GetPosition(), vel);
					}
				}
			}
		}

		if (zombiecharge_cd_time >= 0.f)
		{
			zombiecharge_cd_time -= frame_time;
		}

		if (team > 1)
			return;

		// ��Ч
		{
			if (IsAttributeExist(kEffect_Invincible))
				invincible_time = 0.5f;

			if (GetAcquiredAttributeByType(kEffect_Infect_Damage, true) > 1.0f)
			{
				benefitshadertype = kWeaponAttr_Benefit_DamageAdd;
				benefitshadertime = 0.5f;
			}

			if (IsAttributeExist(kEffect_Special_ReversalMouse))
			{
				if(this == gLevel->GetPlayer())
					control_reverse_timer = 0.5f;

				first_person.Dizzy(control_reverse_timer);
			}

			if (IsAttributeExist(kEffect_Special_ReversalMouse2))
			{
				if(this == gLevel->GetPlayer())
					control_reverse_timer = 0.5f;
			}

			if (IsAttributeExist(kEffect_Special_ViewLost))
			{
				//FMOD::Event* audio_event = FmodSystem::GetEvent("bj/fx/3d/flashbomb_explode");
				//if (audio_event)
				//{
				//	FMOD_VECTOR pos = (const FMOD_VECTOR &)GetPosition();
				//	pos.y += 0.5f;
				//	FMOD_VECTOR vel = {0, 0, 0};
				//	audio_event->set3DAttributes(&pos, &vel);
				//	audio_event->start();
				//}
				FlashBright(1.f, 1.f);
			}

			if (IsAttributeExist(kEffect_Special_ViewLost2))
			{
				first_person.Dizzy(0.5f);
			}

			if (IsAttributeExist(kEffect_Infect_FOV))
			{
				static const float fov_change_speed = 55.f;

				float p = GetTotalAttributeByType(kEffect_Infect_FOV) - 1.f;

				if (!Core::Feq(camera_fov_change, p))
				{
					if (p > camera_fov_change)
					{
						camera_fov_change += fov_change_speed * frame_time;
						if (camera_fov_change > p)
						{
							camera_fov_change = p;
							is_fov_changed = true;
						}
					}
					else
					{
						camera_fov_change -= fov_change_speed * frame_time;
						if (camera_fov_change < p)
						{
							camera_fov_change = p;
							is_fov_changed = true;
						}
					}
				}
			}
			else if (is_fov_changed)
			{
				static const float fov_change_speed = 55.f;

				float p = 0;

				if (!Core::Feq(camera_fov_change, p))
				{
					if (p > camera_fov_change)
					{
						camera_fov_change += fov_change_speed * frame_time;
						if (camera_fov_change > p)
						{
							camera_fov_change = p;
							is_fov_changed = false;
						}
					}
					else
					{
						camera_fov_change -= fov_change_speed * frame_time;
						if (camera_fov_change < p)
						{
							camera_fov_change = p;
							is_fov_changed = false;
						}
					}
				}
			}
		}

		float move_factor = 1.f;
		float jump_factor = 1.f;

		FMOD_EVENT_STATE state = FMOD_EVENT_DEFAULT;

		tempc_ptr(Character) viewer = gLevel->GetViewer();
		
		if(fabs(power_up_time) > Core::EPSILON)
		{
			power_up_time -= frame_time;
		}

		if(fabs(disguise_time) > Core::EPSILON)
		{
			disguise_time -= frame_time;
		}

		blood_add_effect_time = 0.0f;

		if(bag_dialog_wait_time > 0.0f)
		{
			bag_dialog_wait_time -= frame_time;
			if(bag_dialog_wait_time <= 0.0f)
			{
				is_bag_open = false;
				is_ready_bag_close = false;
			}
		}

		if (benefitshadertime > 0.0f)
		{
			benefitshadertime -= frame_time;
		}
		
		if(team_request_waittime >= 0.0f)
		{
			team_request_waittime -= frame_time;
		}
		if(team_success_join_time >= 0.0f)
		{
			team_success_join_time -= frame_time;
		}
		if(team_refuse_time >= 0.0f)
		{
			team_refuse_time -= frame_time;
		}

		if(team_hurt_time > 0.0f)
			team_hurt_time -= frame_time;
		else
		{
			is_team_hurt_part = false;
			is_team_hurt_dead = false;
		}
		if(team_hurt_part_time > 0.0f)
			team_hurt_part_time -= frame_time * 2.0f;
		else
			team_hurt_part_time = 0.0f;

		if(team_hurt_dead_time > 0.0f)
			team_hurt_dead_time -= frame_time * 2.0f;
		else
			team_hurt_dead_time = 0.0f;

		if(bag_flag)
		{
			bag_flash_time += frame_time * 2.0f;
			bag_flash_time = fmod(bag_flash_time,Core::PI);

		}
		else
		{
			bag_flash_time = 0.0f;
		}

		if(energy_bar_info.current_value != energy_bar_info.current_target_value && 
			energy_bar_info.current_value <= energy_bar_info.all_value || (energy_bar_info.flash_time < energy_bar_info.flash_all_time))
		{
			if(energy_bar_info.move_time >= energy_bar_info.move_all_time)
			{
				energy_bar_info.move_time = energy_bar_info.move_all_time;
				energy_bar_info.current_value = energy_bar_info.current_target_value;

				energy_bar_info.flash_time += frame_time;
				energy_bar_info.flash_ratio += frame_time * 20;
			}
			else
			{
				energy_bar_info.move_time += frame_time;
			}
		}

		key_button_effect_time += frame_time * 5.0f;
		key_button_effect_time = fmod(key_button_effect_time,Core::PI);

		key_button_effect_size = fabs(cos(key_button_effect_time)) * 5.0f;

		if(is_display_damage_hp)
		{
			damage_hp_time -= frame_time;
			if(damage_hp_time <= 0.0f)
				is_display_damage_hp = false;
		}

		// update curegun effect ui
		if(state_addbloodformcure)
		{
			state_addbloodtime-=frame_time;
			if(state_addbloodtime <= 0)
				state_addbloodformcure = false;
		}

		// update relife ui
		if(relife_flag)
		{
			relife_time = relife_time + frame_time;
			if(relife_time >= relife_maxtime)
			{
				relife_flag = false;
			}
		}

		if (move)
		{
			// update move factor
			move->SetMoveFactor(move_factor);
			move->SetJumpFactor(jump_factor);
			move->Update(frame_time);
		}

		{
			/// update person
			first_person.Update(frame_time);
			third_person.Update(frame_time);
		}

		MoveCamera(-1.f, 0);

		MoveCamera(1.f, 0);

		if(zombie_dying_flag)
		{
			UpdateZombieDyingCamera(frame_time);
		}
		else
		{

			ClearZombieDyingCamera();
		}

		if(zombie_saving_uid != 0 && zombie_saving_timer > 0.f)
		{
			zombie_saving_timer -= frame_time;
			//LogSystem.WriteLinef("zombie_saving_timer:%f", zombie_saving_timer);
		}

		if (IsAttributeExist(kEffect_Special_Invisible))
		{
			transparency = kTransparencyNormal;
			if (transparency_time == 0.f)
			{
				GetThirdPerson().CreateInvisibleParticle();
			}
			transparency_time += frame_time;
			if (transparency_time < 0.3f)
				transparency_value = Lerp(1.f, 0.2f, transparency_time / 0.3f);
			else
			{
				transparency_value = 0.2f;
				GetThirdPerson().ClearInvisibleParticle();
			}
		}
		else
		{
			transparency_time = 0.f;
			transparency_value = 1.f;
			transparency = kTransparencyNone;
		}

		if (invincible_time > frame_time)
			invincible_time -= frame_time;
		else
			invincible_time = 0;

		if (sustainflame_time > frame_time)
			sustainflame_time -= frame_time;
		else
			sustainflame_time = 0;

		if (poison_time > frame_time)
			poison_time -= frame_time;
		else
			poison_time = 0;

		special_mode = kSpStateNone;
		if (invincible_time > 0)
			special_mode = kInvincible;
		else if (sustainflame_time > 0)
			special_mode = kSustainFlameState;

		/// update punch angle
		{
			static const float punch_damping = 12.0f;
			static const float punch_spring_constant = 45.f;
			Vector3 angle = punch_angle * RAD2DEG;
			if (angle.LengthSqr() > 0.001f || punch_angle_velocity.LengthSqr() > 0.001f)
			{
				angle += punch_angle_velocity * frame_time;
				float damping = 1 - (punch_damping * frame_time);
				if (damping < 0)
					damping = 0;
				punch_angle_velocity *= damping;

				float spring_force_magnitude = punch_spring_constant * frame_time;
				spring_force_magnitude = Clamp(spring_force_magnitude, 0, 2);
				punch_angle_velocity -= angle * spring_force_magnitude;
				angle = Vector3(Clamp(angle.x, 0, 89), Clamp(angle.y, -179, 179), Clamp(angle.z, -89, 89));
				punch_angle = angle * DEG2RAD;
			}
		}

		/// update cross offset
		float offset  = punch_angle.Length();
		float scale = 0;
		if (!IsOnGround())
			scale = 10;
		else if (GetCurrentSpeed().Length() > 0.01f)
		{
			scale = 5;
			if (GetCrouch())
				scale -= 2;   //scale -= 4;
			else if (GetWalk())
				scale -= 2;
		}
		//else if (GetCrouch())
		//	scale = -10;

		tempc_ptr(WeaponBase) weapon = GetWeapon();
		if (weapon && weapon->weapon_info)
			scale += weapon->weapon_info->cross_offset;

		scale = Max(0.f, scale);
		float cross_hair_move = 20 * frame_time;

		if (cross_hair_offset <= scale)
			cross_hair_offset = scale;
		else
			cross_hair_offset = Max(cross_hair_offset - cross_hair_move, scale);

		// update hit ui
		for (uint i = 0; i < hit_ui.Size(); i ++)
		{
			HitInfo & ui = hit_ui[i];

			if (ui.time > 0)
			{
				ui.time -= frame_time;
			}
		}

		// update kill ui
		for(int i = 0 ; i < 5; i++)
		{
			if(speaker_tip_time[i] < 100.0f)
				speaker_tip_time[i] += frame_time;
		}

		if (action)
			action->Update(frame_time);

		if (dead_particles.Size() > 0)
		{
			for(int i = 0; i < (int)dead_particles.Size();++i)
			{
				if (dead_particles[i]->timer > -1)
				{
					Vector3 joint_pos;
					Quaternion joint_rot;
					GetThirdPerson().GetJointInfo(dead_particles[i]->joint, joint_pos, joint_rot);
					dead_particles[i]->ps->SetPosition(joint_pos);
					dead_particles[i]->ps->SetRotation(joint_rot);
					dead_particles[i]->ps->Update(frame_time);
					dead_particles[i]->timer += frame_time;
					if (dead_particles[i]->timer > dead_particles[i]->totle_time)
					{
						dead_particles.RemoveAt(i);
						i--;
					}
				}
			}
		}

		if (character_particles.Size() > 0)
		{
			for(int i = 0; i < (int)character_particles.Size();++i)
			{
				Vector3 joint_pos;
				Quaternion joint_rot;
				GetThirdPerson().GetJointInfo(character_particles[i]->joint, joint_pos, joint_rot);
				character_particles[i]->ps->SetPosition(joint_pos);
				character_particles[i]->ps->SetRotation(joint_rot);
				character_particles[i]->ps->Update(frame_time);
				character_particles[i]->timer += frame_time;
				if (character_particles[i]->timer > character_particles[i]->totle_time)
				{
					character_particles.RemoveAt(i);
					i--;
				}
			}
		}

		if (item_mode_particles.Size() > 0)
		{
			for(int i = 0; i < (int)item_mode_particles.Size();++i)
			{
				item_mode_particles[i]->ps->SetPosition(GetPosition());
				item_mode_particles[i]->ps->SetRotation(GetRotation());
				item_mode_particles[i]->ps->Update(frame_time);
				item_mode_particles[i]->timer += frame_time;
				if (item_mode_particles[i]->timer > item_mode_particles[i]->totle_time)
				{
					item_mode_particles.RemoveAt(i);
					i--;
				}
			}
		}

		if (item_mode_buff_time.Size() > 0)
		{
			for(int i = 0; i < (int)item_mode_buff_time.Size();++i)
			{
				item_mode_buff_time[i]->totle_time -= frame_time;
				if (item_mode_buff_time[i]->totle_time < 0.1f)
				{
					item_mode_buff_time.RemoveAt(i);
					i--;
				}
			}
		}

		if (item_mode_debuff_time.Size() > 0)
		{
			for(int i = 0; i < (int)item_mode_debuff_time.Size();++i)
			{
				item_mode_debuff_time[i]->totle_time -= frame_time;
				if (item_mode_debuff_time[i]->totle_time < 0.1f)
				{
					item_mode_debuff_time.RemoveAt(i);
					i--;
				}
			}
		}

		if (IsDied() && died_timer > 0)
		{
			died_timer -= frame_time;
			died_temp_timer -= frame_time;
			if (died_timer <= 0)
			{
				ready = false;
				SetPhysxControl(false);

				if (dead_particles.Size() > 0)
				{
					for(int i = 0; i < (int)dead_particles.Size();++i)
					{
						dead_particles[i]->timer = -1;
					}
				}
				character_particles.Clear();
				
				if (item_mode_particles.Size() > 0)
				{
					for(int i = 0; i < (int)item_mode_particles.Size();++i)
					{
						item_mode_particles[i]->timer = -1;
					}
				}
				item_mode_particles.Clear();

				if (item_mode_buff_time.Size() > 0)
				{
					for(int i = 0; i < (int)item_mode_buff_time.Size();++i)
					{
						item_mode_buff_time[i]->totle_time = 0;
					}
				}
				item_mode_buff_time.Clear();

				if (item_mode_debuff_time.Size() > 0)
				{
					for(int i = 0; i < (int)item_mode_debuff_time.Size();++i)
					{
						item_mode_debuff_time[i]->totle_time = 0;
					}
				}
				item_mode_debuff_time.Clear();

				if (boss_pve_scene)
				{
					boss_pve_scene->stop();
					boss_pve_scene = NULL;
				}

				SetPosition(Vector3(-10000, -10000, -10000));
				third_person.SyncPhysxPosition();

				// set camera
				camera_fov = NORMAL_FOV;
				camera_target_fov = NORMAL_FOV;

				// temp for view mode
				if (this == gLevel->GetPlayer())
					gLevel->SetCameraMode(Camera::kViewMode);
				if (gGame->render && gGame->render->render_pipeline)
				{
					gGame->render->render_pipeline->m_bUseSavedScreen = false;
				}
			}
			else if (died_timer >= 1.f && died_timer <= 3.5f && current_hit_info.to_uid != current_hit_info.from_uid && this->uid == current_hit_info.to_uid && this == gLevel->GetPlayer())
			{
				// set camera
				camera_fov = NORMAL_FOV;
				camera_target_fov = NORMAL_FOV;

				Vector3 head_pos;
				Quaternion head_rot;

				// temp for view mode
				tempc_ptr(Character) hitviewer = gLevel->GetCharacter(current_hit_info.from_uid);
				if (gLevel->game_type != RoomOption::kBossPVE && 
					hitviewer && !hitviewer->IsDied() && hitviewer->GetThirdPerson().GetJointInfo("hat", head_pos, head_rot))
				{
					gGame->camera->goal_position = head_pos;

					if (gLevel->game_type != RoomOption::kTDMode)
						gLevel->SetCameraMode(Camera::kDiedMode);
				}
			}
		}

		// update radio map effect
		for(int i = (int)radio_effect_list.Size() - 1; i >=0 ; i--)
		{
			RadioData &item = radio_effect_list[i];

			if( item.time + frame_time >= item.pertime )
			{
				item.time = 0.0f;
				item.anim_id++;

				if(item.anim_id == 15)
					radio_effect_list.RemoveAt(i);
			}
			else
			{
				item.time += frame_time;
			}
		}
		// update flash bright time
		if (flash_bright_time > 0)
			flash_bright_time -= frame_time;

		if (flash_bright_time < 0)
			flash_bright_time = 0.f;

		// update control reserve time
		if (control_reverse_timer > 0)
			control_reverse_timer -= frame_time;

		// update radar time
		if (radar_timer > 0)
			radar_timer -= frame_time;

		if (radar_ui_timer > 0)
			radar_ui_timer -= frame_time;

		//update skill history
		for(int i = (int)skill_history_info.Size() - 1 ; i >=0 ; i--)
		{
			SkillHistoryInfo &item = skill_history_info[i];
			if(item.time > 0.0f)
				item.time -= frame_time;
			if(item.time <= 0.0f)
				skill_history_info.RemoveAt(i);
		}
		//
		if(kill_effect_flag)
		{
			kill_effect_text_time += frame_time;
			kill_effect_num_time += frame_time;
			kill_effect_textbg_time += frame_time;

			if(kill_effect_num_time >= 0.03f && kill_effect_wait==false)
			{
				kill_effect_text_time = 0.0f;
				kill_effect_text_anim++;

				if(lian_kill_count > 1)
				{
					if(kill_effect_text_anim >= 2)
					{
						kill_effect_num_anim++;

						if(kill_effect_num_anim > 6)
							kill_effect_num_anim = 6;
					}
					if(kill_effect_text_anim >= 3)
					{
						kill_effect_textbg_anim++;
						if(kill_effect_textbg_anim > 5)
							kill_effect_textbg_anim = 5;
					}

					if(kill_effect_text_anim == 10)
					{
						kill_effect_text_anim = 9;
						kill_effect_num_anim = 6;
						kill_effect_textbg_anim = 5;

						kill_effect_text_time = 0.0f;

						kill_effect_wait = true;
					}
				}
				else
				{
					if(kill_effect_text_anim >= 3)
					{
						kill_effect_textbg_anim++;

						if(kill_effect_textbg_anim > 5)
							kill_effect_textbg_anim = 5;
					}

					if(kill_effect_text_anim >= 11)
					{
						kill_effect_text_anim = 10;
						kill_effect_textbg_anim = 5;
						kill_effect_wait = true;
					}
				}

				kill_effect_num_time = 0.0f;
			}
			else if(kill_effect_wait && kill_effect_text_time >= 1.0f)
				kill_effect_flag = false;
		}

		if (effect_collider)
		{
			effect_collider->setGlobalPosition((const NxVec3 &)(this->GetPosition()+Vector3(0,GetHeight(),0)));
			effect_collider->setGlobalOrientationQuat((const NxQuat &)this->GetRotation());
		}

		//if (toolsbox)
		//{
		//	Vector3 base = Vector3(0,0,1); 
		//	base = GetPosition() + base * GetSkeletonRotation() * 2;
		//	base.y = GetPosition().y;
		//	toolsbox->SetPosition(base);
		//	toolsbox->SetRotation(GetRotation());
		//	toolsbox->SetHeight(GetHeight());
		//	toolsbox->Update(frame_time);
		//}

		if(windreverse_time > 0.f)
		{
			tempc_ptr(FlameGun) flamegun = ptr_dynamic_cast<FlameGun>(GetWeapon(false));
			if(flamegun)
			{
				flamegun->CheckWindReverse();
				windreverse_time -= frame_time;
				if(windreverse_time <= 0.f)
				{
					flamegun->EndCheckWindReverse();
				}
			}		
		}

		
		

		//��ʬ����3D��Ч����
		if (zombie_3D_breath)
		{
			FMOD_VECTOR vel = {0, 0, 0};
			FmodSystem::Update3DEventPosition(zombie_3D_breath, (const FMOD_VECTOR &)GetPosition(), vel);
		}

		//BOSS FLY��Ч����
		if (boss_3D_fly)
		{
			if(move->IsFlying())
			{
				FMOD_EVENT_STATE audio_state = FMOD_EVENT_DEFAULT;
				boss_3D_fly->getState(&audio_state);
				if ((audio_state & FMOD_EVENT_STATE_PLAYING) == 0)
				{
					boss_3D_fly->start();
				}
				FMOD_VECTOR vel = {0, 0, 0};
				boss_3D_fly->set3DAttributes(&(const FMOD_VECTOR &)GetPosition(), &vel);
			}
			else
			{
				FMOD_EVENT_STATE audio_state = FMOD_EVENT_DEFAULT;
				boss_3D_fly->getState(&audio_state);
				if ((audio_state & FMOD_EVENT_STATE_PLAYING) != 0)
				{
					boss_3D_fly->stop();
				}

			}

		}

		//BOSS FLY��Ч����
		if (boss_3D_boost)
		{
			if(move->IsBoost())
			{
				FMOD_EVENT_STATE audio_state = FMOD_EVENT_DEFAULT;
				boss_3D_boost->getState(&audio_state);
				if ((audio_state & FMOD_EVENT_STATE_PLAYING) == 0)
				{
					boss_3D_boost->start();
				}

				FMOD_VECTOR vel = {0, 0, 0};
				boss_3D_boost->set3DAttributes(&(const FMOD_VECTOR &)GetPosition(), &vel);
			}
			else
			{
				FMOD_EVENT_STATE audio_state = FMOD_EVENT_DEFAULT;
				boss_3D_boost->getState(&audio_state);
				if ((audio_state & FMOD_EVENT_STATE_PLAYING) != 0)
				{
					boss_3D_boost->stop();
				}
			}

		}

		//BOSS FLY��Ч����
		if (boss_3D_uav)
		{
			if(move->IsUavFlying())
			{
				FMOD_EVENT_STATE audio_state = FMOD_EVENT_DEFAULT;
				boss_3D_uav->getState(&audio_state);
				if ((audio_state & FMOD_EVENT_STATE_PLAYING) == 0)
				{
					boss_3D_uav->start();
				}

				FMOD_VECTOR vel = {0, 0, 0};
				boss_3D_uav->set3DAttributes(&(const FMOD_VECTOR &)GetPosition(), &vel);
			}
			else
			{
				FMOD_EVENT_STATE audio_state = FMOD_EVENT_DEFAULT;
				boss_3D_uav->getState(&audio_state);
				if ((audio_state & FMOD_EVENT_STATE_PLAYING) != 0)
				{
					boss_3D_uav->stop();
				}
			}
		}

		//����BOSSPVE��Ϣ
		UpdateBossPVEData(frame_time);
		
		
		if (boss_2D_survival)
		{
			if ( gLevel->GetPlayer()->hp < max_hp*0.3 && gLevel->GetPlayer()->hp > 2   )
			{

				FMOD_EVENT_STATE audio_state = FMOD_EVENT_DEFAULT;
				boss_2D_survival->getState(&audio_state);
				if ((audio_state & FMOD_EVENT_STATE_PLAYING) == 0)
				{
					boss_2D_survival->start();
				}

			}
			else
			{
				FMOD_EVENT_STATE audio_state = FMOD_EVENT_DEFAULT;
				boss_2D_survival->getState(&audio_state);
				if ((audio_state & FMOD_EVENT_STATE_PLAYING) != 0 )
				{
					boss_2D_survival->stop();
				}
			}
		}

		if (is_human_super)
		{
			if (cd_time > 0.0f)
			{
				cd_time -= frame_time;
			}
			else
				cd_time = 0.0f;
		}

		//����ĸ�彩ʬ����ʱ��
		if (common_zombie_dying_flag && !IsDied())
		{
			commonzombie_dying_time += Task::GetFrameTime();
			if (commonzombie_dying_time > commonzombie_dying_totletime)
			{
				commonzombie_dying_time = commonzombie_dying_totletime;
			}
		}
		else if (commonzombie_dying_time != 0.0f)
			commonzombie_dying_time = 0.0f;

		stick_ammo_explode_timer -= frame_time;


		for (int i = 0; i < 4; i++)
		{
			if (advBoxTime[i] > 0.f)
			{
				advBoxTime[i] -= frame_time;
				if (advBoxTime[i] < 0.f)
				{
					advBoxTime[i] = 0.f;
				}
			}
			
		}
	}

	/// timestepupdate
	void Character::TimeStepUpdate(float frame_time)
	{
		third_person.UpdatePhysx(frame_time);

		{
			HashSet<Core::Identifier, sharedc_ptr(IBarbette)>::Enumerator itr(barbette_set);
			while (itr.MoveNext())
			{
				tempc_ptr(IBarbette) barbette = itr.Value();
				if (barbette)
				{
					barbette->TimeStepUpdate(frame_time);
				}
			}
		}

		///----------------------------------------------------------------------
		Array<U16> dead_pveammo;
		HashSet<U16, sharedc_ptr(PVEAmmo)>::Enumerator itr(m_PVEAmmoSet);
		while (itr.MoveNext())
		{
			tempc_ptr(PVEAmmo) pve_ammo = itr.Value();
			if (pve_ammo)
			{
				pve_ammo->TimeStepUpdate(frame_time);
				if (pve_ammo->IsDead())
				{
					pve_ammo->OnDead();

					dead_pveammo.PushBack(itr.Key());

					if (gGame->channel_connection)
						gGame->channel_connection->PVEAmmoDestroy(uid, pve_ammo);
				}
			}
		}
		for (U32 i = 0; i < dead_pveammo.Size(); i++)
		{
			m_PVEAmmoSet.Remove(dead_pveammo[i]);
		}

		if (gGame->channel_connection)
			gGame->channel_connection->PVEAmmoUpdate(uid, m_PVEAmmoSet);


		///----------------------------------------------------------------------
		HashSet<U16, sharedc_ptr(PVEAmmoLaser)>::Enumerator itrlaser(m_PVEAmmoLaserSet);
		while (itrlaser.MoveNext())
		{
			tempc_ptr(PVEAmmoLaser) ammo = itrlaser.Value();
			if (ammo)
			{
				ammo->TimeStepUpdate(frame_time);
			}
		}
	}

	/// on render
	void Character::OnRender(float frame_time)
	{
		{
			HashSet<Core::Identifier, sharedc_ptr(IBarbette)>::Enumerator itr(barbette_set);
			while (itr.MoveNext())
			{
				tempc_ptr(IBarbette) barbette = itr.Value();
				if (barbette)
				{
					barbette->Update(frame_time);
				}
			}
		}
		{
			HashSet<U16, sharedc_ptr(PVEAmmo)>::Enumerator itr(m_PVEAmmoSet);
			while (itr.MoveNext())
			{
				tempc_ptr(PVEAmmo) pve_ammo = itr.Value();
				if (pve_ammo)
					pve_ammo->OnRender(frame_time);
			}
		}
		{
			HashSet<U16, sharedc_ptr(PVEAmmoLaser)>::Enumerator itr(m_PVEAmmoLaserSet);
			while (itr.MoveNext())
			{
				tempc_ptr(PVEAmmoLaser) pve_ammolaser = itr.Value();
				if (pve_ammolaser)
					pve_ammolaser->OnRender(frame_time);
			}
		}

		first_person.OnRender(frame_time);
		third_person.OnRender(frame_time);
	}

	/// draw
	void Character::Draw(Primitive::DrawType drawtype, bool immediate)
	{
		if (team > 1)
			return;

		if (!occluded)
		{
			switch (view_mode)
			{
			case kFirstPerson:
				first_person.Draw(drawtype, immediate);
				break;

			case kThirdPerson:
				third_person.Draw(drawtype, immediate);
				break;
			}
		}

		if (dead_particles.Size() > 0)
		{
			for(int i = 0; i < (int)dead_particles.Size();++i)
			{
				if (dead_particles[i]->timer > -1)
				{
					dead_particles[i]->ps->Draw();
				}
			}
		}

		if (character_particles.Size() > 0)
		{
			for(int i = 0; i < (int)character_particles.Size();++i)
			{
				character_particles[i]->ps->Draw();
			}
		}

		if (item_mode_particles.Size() > 0)
		{
			for(int i = 0; i < (int)item_mode_particles.Size();++i)
			{
				item_mode_particles[i]->ps->Draw();
			}
		}	
	}

	/// draw
	void Character::DrawBarbette(Primitive::DrawType drawtype, bool immediate)
	{
		{
			HashSet<Core::Identifier, sharedc_ptr(IBarbette)>::Enumerator itr(barbette_set);
			while (itr.MoveNext())
			{
				tempc_ptr(IBarbette) barbette = itr.Value();
				if (barbette)
				{
					barbette->Draw(drawtype, immediate);
				}
			}
		}
		{
			HashSet<U16, sharedc_ptr(PVEAmmo)>::Enumerator itr(m_PVEAmmoSet);
			while (itr.MoveNext())
			{
				tempc_ptr(PVEAmmo) pve_ammo = itr.Value();
				if (pve_ammo)
					pve_ammo->Draw(drawtype, immediate);
			}
		}
		{
			HashSet<U16, sharedc_ptr(PVEAmmoLaser)>::Enumerator itr(m_PVEAmmoLaserSet);
			while (itr.MoveNext())
			{
				tempc_ptr(PVEAmmoLaser) pve_ammolaser = itr.Value();
				if (pve_ammolaser)
					pve_ammolaser->Draw(drawtype, immediate);
			}
		}
	}

	/// get shader lod
	S32 Character::GetShaderLod()
	{
		S32 lod = 0;

		switch (view_mode)
		{
		case kFirstPerson:
			lod = first_person.GetShaderLod();
			break;

		case kThirdPerson:
			lod = third_person.GetShaderLod();
			break;
		}

		return lod;
	}
}

namespace Client
{
	/// initialize
	void Character::Initialize()
	{
		if (team > 1)
			return;

		ui_head_icon = NullPtr;

		sharedc_ptr(CharacterInfo) info = GetCurCharinfo();
		if (info)
		{
			move_info.run_speed = info->run_speed;
			move_info.walk_speed = info->walk_speed;
			move_info.crouch_speed = info->crouch_speed;
			move_info.jump_velocity = info->jump_velocity;
			move_info.acceleration = info->acceleration;
			move_info.hit_speed = 0.1f;
			move_info.hit_acceleration = info->acceleration;
			move_info.hit_distance = 0.5f;

			controller_info.controller_height = info->controller_height;
			controller_info.controller_radius = info->controller_radius;
			controller_info.controller_crouch_height = info->controller_crouch_height;

			if (move)
			{
				move->SetMoveInfo(move_info);
				move->SetControllerInfo(controller_info);
			}
			String file_name = String::Format("IngameUI/person/ig_common_tool_%s_%s.dds", info->res_key, team == 0 ? "red":"blue");

			ui_head_icon = RESOURCE_LOAD_NEW(file_name.Str(), true, Texture2D);
		}
		accumulate_damage = 0;
		connected = true;
		isshooting = false;
		runspeed_offset = 0.f;
		walkspeed_offset = 0.f;
		crouchspeed_offset = 0.f;
		flightspeed_offset = 0.f;
		special_mode = kSpStateNone;
		equipment_id = -1;
		equipment_info = NullPtr;
		bsniperassist = false;
		breducespread = false;

		InitializeBarbette();

		first_person.Initialize();
		third_person.Initialize();

		dead_particles.Clear();
		if ((int)character_info->third_person_dead_particles.Size() > 0)
		{
			for (int i = 0; i < (int)character_info->third_person_dead_particles.Size(); i++)
			{
				sharedc_ptr(CharacterParticle) dp = ptr_new CharacterParticle();
				dp->ps = ptr_new ParticleSystem(character_info->third_person_dead_particles[i].particle, false); 
				dp->ps->SetEnable(true);

				dp->joint = character_info->third_person_dead_particles[i].joint;
				dp->totle_time = character_info->third_person_dead_particles[i].time;
				dp->timer = -1;
				dead_particles.PushBack(dp);
			}
		}

		die_buff_total_count =(int)gLevel->die_buff_data.Size();
		die_buff_counter =0;
		die_buff_rand_start =-1;
		die_buff_rand_gap_timer =DIE_BUFF_RAND_GAP_TIME;
		die_buff_rand_timer =DIE_BUFF_RAND_TIME;
		die_buff_stay_timer =DIE_BUFF_STAY_TIME;
		die_buff_randing =false;
		die_buff_staying =false;
		die_buff_affecting =false;
		die_buff_affect =-1;
	}

	/// initialize weapon
	void Character::InitializeWeapon(const PackInfo & pack)
	{
		if (team > 1)
			return;

		first_person.InitializeWeapon(pack);
		third_person.InitializeWeapon(pack);
	}

	/// initialize mesh
	void Character::InitializeMesh()
	{
		if (team > 1)
			return;

		first_person.InitializeMesh();
		third_person.InitializeMesh();
	}

	/// initialize barbette
	void Character::InitializeBarbette()
	{
		barbette_set.Clear();

		sharedc_ptr(CharacterInfo) info = GetCurCharinfo();
		if (info)
		{
			CharacterInfo::BarbetteInfoSet::Enumerator it(info->barbetteinfo_set);
			while (it.MoveNext())
			{
				sharedc_ptr(Barbette) barbette = ptr_new Barbette;

				if (barbette->Initialize(ptr_static_cast<Character>(this), it.Value()))
				{
					barbette_set.Set(it.Key(), barbette);
				}
				else
				{
					Core::LogSystem.WriteLinef("initialize barbette falied : %s, %s", info->name, it.Key());
				}
			}
		}
	}

	/// is ready
	bool Character::IsReady()
	{
		bool ret = false;

		switch (view_mode)
		{
		case kFirstPerson:
			ret = first_person.IsReady();
			break;

		case kThirdPerson:
			ret = third_person.IsReady();
			break;
		}

		return ret;
	}

	/// get position
	const Core::Vector3 & Character::GetPosition()
	{
		
		if (move)
			return move->GetPosition();

		return Vector3::kZero;
		
	}

	const Core::Vector3 Character::GetTorsoPosition(bool firstperson)
	{
		return firstperson ? first_person.GetTorsoPosition() : third_person.GetTorsoPosition() * GetRotation() * Quaternion(Vector3(0, 1, 0), PI) + GetPosition() - Core::Vector3(0, 0.995926f, 0);
		//if (!skeleton)
		//	return Vector3::kZero;
		//int joint_id = skeleton->GetJointID("root");
		//if (joint_id < 0)
		//	return Vector3::kZero;
		//const Transform& trans = cam_pose->GetJointLocalPose(joint_id);
		//return trans.position;
	}

	/// set position
	void Character::SetPosition(const Core::Vector3 & pos)
	{
		if (move)
			move->SetPosition(pos);
	}

	/// set position
	void Character::MovePosition(const Core::Vector3 & pos)
	{
		if (move)
			move->MovePosition(pos);
	}

	/// get camera position
	Core::Vector3 Character::GetCameraPosition()
	{
		if (IsDied())
			return first_person.GetCameraPosition();

		switch (view_mode)
		{
		case kFirstPerson:
			return first_person.GetCameraPosition();

		case kThirdPerson:
			return third_person.GetCameraPosition();
		}

		return Vector3::kZero;
	}

	/// get skeleton rotation
	Quaternion Character::GetSkeletonRotation()
	{
		switch (view_mode)
		{
		case kFirstPerson:
			return first_person.GetSkeletonRotation();

		case kThirdPerson:
			return third_person.GetSkeletonRotation();
		}

		return Quaternion::kIdentity;
	}

	/// get skeleton position
	Vector3 Character::GetSkeletonPosition()
	{
		switch (view_mode)
		{
		case kFirstPerson:
			return first_person.GetSkeletonPosition();

		case kThirdPerson:
			return GetPosition();
		}

		return Vector3::kZero;
	}

	/// get camera rotation
	Core::Quaternion Character::GetCameraRotation()
	{
		if (IsDied())
			return first_person.GetCameraRotation();

		switch (view_mode)
		{
		case kFirstPerson:
			return first_person.GetCameraRotation();

		case kThirdPerson:
			return third_person.GetCameraRotation();
		}

		return Quaternion::kIdentity;
	}

	/// get rotation
	const Core::Quaternion & Character::GetRotation()
	{
		if (move)
			return move->GetRotation();

		return Quaternion::kIdentity;
	}

	/// get camera Third Person position
	Core::Vector3 Character::GetCameraThirdPersonPosition()
	{
		if (IsDied())
			return Vector3::kZero;
		return third_person.GetCameraPosition();
	}

	/// get camera Third Person rotation
	Core::Quaternion Character::GetCameraThirdPersonRotation()
	{
		if (IsDied())
			return Quaternion::kIdentity;
		return third_person.GetCameraRotation();
	}

	/// set face dir
	void Character::SetLookDir(const Core::Quaternion & rot)
	{
		if (move)
			move->SetLookDir(rot);
	}

	/// get face dir
	const Core::Quaternion &  Character::GetLookDir()
	{
		if (move)
			return move->GetLookDir();

		return Quaternion::kIdentity;
	}

	/// set move
	void Character::SetMove(float m, float shift)
	{
		if (move)
			move->SetMove(m, shift);
	}

	/// get move
	const Vector3 & Character::GetMove()
	{
		if (move)
			return move->GetMove();

		return Vector3::kZero;
	}

	/// get direction
	const Vector2 & Character::GetDirection()
	{
		if (move)
			return move->GetDirection();

		return Vector2::kZero;
	}

	/// pool back
	float Character::PoolBack(float distance)
	{
		//VMProtectBegin("PoolBack");
		camera_distance = Clamp(camera_distance + distance, 0, 4);
		//VMProtectEnd();

		return camera_distance;
	}

	float Character::GetKickOnHitTimer()
	{
		if (move)
			return move->kick_on_hit_timer;

		return -1.f;
	}

	/// add skill history
	void Character::AddSkillHistory(sharedc_ptr(Texture2D) icon, float time)
	{
		SkillHistoryInfo item;

		item.time = time;
		item.total_time = time;
		item.skill_icon = icon;

		for(int i = (int)skill_history_info.Size() - 1 ; i >=0 ; i--)
		{
			SkillHistoryInfo &item = skill_history_info[i];
			if(item.skill_icon == icon)
				skill_history_info.RemoveAt(i);
		}

		skill_history_info.Add(item);
	}

	/// set camera fov
	void Character::SetCameraFov(float fov, float target_fov)
	{
		if (action)
			action->SetCameraFov(fov, target_fov);

		camera_fov = fov;
		camera_target_fov = target_fov;
	}

	/// move look
	void Character::MoveLook(float horizontal, float vertical)
	{
		if (move)
			move->MoveLook(horizontal, vertical);
	}

	/// move camera
	void Character::MoveCamera(float horizontal, float vertical)
	{
		Vector3 right_dir = Vector3(1, 0, 0) * camera_rotation_offset;
		Vector3 up_dir(0, 1, 0);

		Quaternion look_horizontal(up_dir, horizontal);
		Quaternion look_vertical(right_dir, vertical);

		camera_rotation_offset = camera_rotation_offset * (look_vertical * look_horizontal);
	}

	/// get current speed
	const Core::Vector3 & Character::GetCurrentSpeed()
	{
		if (move)
			return move->current_speed;

		return Vector3::kZero;
	}

	/// get vertical speed
	float Character::GetVerticalSpeed()
	{
		if (move)
			return move->vertical_speed;

		return 0.f;
	}

	/// set current speed
	void Character::SetCurrentSpeed(const Core::Vector3 & speed)
	{
		if (move)
			move->SetCurrentSpeed(speed);
	}

	/// get controller height
	float Character::GetControllerHeight()
	{
		if (move)
			return move->controller_info.controller_height;

		return 0.f;
	}

	/// get controller radius
	float Character::GetControllerRadius()
	{
		if (move)
			return move->controller_info.controller_radius;

		return 0.f;
	}

	/// get height
	float Character::GetHeight()
	{
		if (move)
			return move->height;

		return 0.f;
	}

	/// get throw velocity
	float Character::GetThrowVelocity()
	{
		if (GetCurCharinfo())
			return GetCurCharinfo()->throw_velocity;

		return 30.f;
	}

	/// get weapon
	tempc_ptr(WeaponBase) Character::GetWeapon(bool force_first_person)
	{
		if (force_first_person)
			return first_person.GetWeapon(weapon_id);

		switch (view_mode)
		{
		case kFirstPerson:
			return first_person.GetWeapon(weapon_id);

		case kThirdPerson:
			return third_person.GetWeapon(weapon_id);
		}

		return NullPtr;
	}

	tempc_ptr(WeaponBase) Character::GetThirdPresonWeapon()
	{
		return third_person.GetWeapon(weapon_id);
	}

	/// get weapon by id
	tempc_ptr(WeaponBase) Character::GetWeaponById(uint id, bool force_first_person)
	{
		if (force_first_person)
			return first_person.GetWeapon(id);

		switch (view_mode)
		{
		case kFirstPerson:
			return first_person.GetWeapon(id);

		case kThirdPerson:
			return third_person.GetWeapon(id);
		}

		return NullPtr;
	}

	/// set crouch
	void Character::SetCrouch(bool flag)
	{
		if (move)
			move->SetCrouch(flag);
	}

	/// set walk
	void Character::SetWalk(bool flag)
	{
		if (move)
			move->SetWalk(flag);
	}

	/// get crouch
	bool Character::GetCrouch()
	{
		if (move)
			return move->GetCrouch();

		return false;
	}

	/// get walk
	bool Character::GetWalk()
	{
		if (move)
			return move->GetWalk();

		return false;
	}

	/// get team
	int Character::GetTeam()
	{
		return team;
	}

	/// set team
	void Character::SetTeam(int id)
	{
		team = id;
	}

	/// is jumping
	bool Character::IsJumping()
	{
		if (move)
			return move->IsJumping();

		return false;
	}

	/// set jump
	void Character::SetJump(bool flag)
	{
		if (move)
		{
			move->SetJump(flag);
			move->SetFlightSpeed(move_info.flight_speed + flightspeed_offset);
		}
	}

	/// set fly
	void Character::SetFly(bool flag)
	{
		if(!gLevel)
			return;
		
		if(gLevel->game_type != RoomOption::kBossMode2)
			return;
		
		
		{
			bool need_fly = false;
			if(character_info->career_id == gLevel->boss2_career_id)
			{
				need_fly = true;
			}
			else
			{
				for (uint i = 0; i < 4; i++)
				{
					if(character_info->career_id == gLevel->boss2_sp_career_id[i])
					{
						need_fly = true;
						break;
					}
				}
			}

			if(!need_fly)
			{
				return;
			}
		}


		if (move)
		{
			move->SetFly(flag);
			if(flag)
			{
				if(gLevel && gLevel->GetPlayer() == this)
				{
					if (!boss_2D_fly)
					{
						String str = String::Format("bj/player/2d/armor_robot/armor_fly");
						boss_2D_fly = FmodSystem::GetEvent(str.Str());
					}
					boss_2D_fly->start();
				}
				else
				{
					if (!boss_3D_fly)
					{
						FMOD_VECTOR vel = {0, 0, 0};
						String str = String::Format("bj/player/3d/armor_robot/armor_fly");
						boss_3D_fly = FmodSystem::GetEvent(str.Str());
					}
				}
			}
			else
			{
				if (boss_2D_fly)
				{
					boss_2D_fly->stop();
				}
				if (boss_3D_fly)
				{
					boss_3D_fly->stop();
				}
			}
		}
	}

	/// set Boost
	void Character::SetBoost(bool flag , int dir)
	{
		if(!gLevel)
			return;

		if(gLevel->game_type != RoomOption::kBossMode2)
			return;


		{
			bool need_fly = false;
			if(character_info->career_id == gLevel->boss2_career_id)
			{
				need_fly = true;
			}
			else
			{
				for (uint i = 0; i < 4; i++)
				{
					if(character_info->career_id == gLevel->boss2_sp_career_id[i])
					{
						need_fly = true;
						break;
					}
				}
			}

			if(!need_fly)
			{
				return;
			}
		}

		if (move)
		{
			move->SetBoost(flag , dir);
		}

		if(flag)
		{
			if(gLevel && gLevel->GetPlayer() == this)
			{
				if (!boss_2D_boost)
				{
					String str = String::Format("bj/player/2d/armor_robot/armor_boost");
					boss_2D_boost = FmodSystem::GetEvent(str.Str());
				}
				boss_2D_boost->start();
			}
			else
			{
				if (!boss_3D_boost)
				{
					FMOD_VECTOR vel = {0, 0, 0};
					String str = String::Format("bj/player/3d/armor_robot/armor_boost");
					boss_3D_boost = FmodSystem::GetEvent(str.Str());
				}
			}
		}
		else
		{
			if (boss_2D_boost)
			{
				boss_2D_boost->stop();
			}
			if (boss_3D_boost)
			{
				boss_3D_boost->stop();
			}
		}
	}

	/// is flying
	bool Character::IsFlying()
	{
		if (move)
			return move->IsFlying();

		return false;
	}

	/// is flying
	bool Character::IsBoost()
	{
		if (move)
			return move->IsBoost();

		return false;
	}

	/// set onground
	void Character::SetOnGround(bool flag)
	{
		if (move)
		{
			move->SetOnGround(flag);
		}
	}

	bool Character::AmmoJump(const Vector3 &AmmoPos, bool selfhurt, float jumpscale)
	{
		Vector3 jumpVelocity(0,1.f,0);
		Vector3 dir =  GetPosition();
		dir.y += 0.8f;

		if(selfhurt)
		{
			if(!IsOnGround())
				jumpVelocity = Vector3(0,0.9f,0);
		}
		else
		{
			if(!IsOnGround())
				jumpVelocity = Vector3(0,0.4f,0);
		}

		
		dir =  dir -  AmmoPos ;
		dir = dir.Normalize();
		jumpVelocity += dir;	
		jumpVelocity.Normalize();
		
		//jumpVelocity += AmmoDir;
		//jumpVelocity.Normalize();
		
		if (move)
		{
			if(move->IsJumping())
				move->SetJump(false);
			if(!selfhurt)// && !IsOnGround()
			{
				if( dir.y < AmmoPos.y && IsOnGround())
					move->SetVelocity(jumpVelocity * 20 * jumpscale);
				else
					move->SetVelocity(jumpVelocity * 40 * jumpscale);
			}
			else
				move->AddVelocity(jumpVelocity * 15 * jumpscale);
			
		}

		return true;

	}
	
	/// is died
	bool Character::IsDied()
	{
		return died;
	}

	/// is on ground
	bool Character::IsOnGround()
	{
		if (move)
			return move->IsOnGround();

		return false;
	}

	/// is moving
	bool Character::IsMoving()
	{
		if (move)
			return move->IsMoving();

		return false;
	}

	
	/// is shooting
	bool Character::IsShooting()
	{
		return shooting;
	}

	/// is reloading
	bool Character::IsReloading()
	{
		return reloading;
	}

	/// set info
	void Character::SetCharacterInfo(by_ptr(CharacterInfo) info)
	{
		character_info = info;

		first_person.SetCharacterInfo(character_info);
		third_person.SetCharacterInfo(character_info);

		if (character_info)
		{
			Initialize();
		}
	}

	/// set move offset
	void Character::SetMoveInfoOffset(float move_offset)
	{
		runspeed_offset = move_offset;
		//runspeed_offset = move_offset * 2;
		//* 2 is a fix 
	}

	float Character::GetMoveInfoRunSpeed()
	{
		return move->GetRunSpeed();
	}
	
	/// set view mode
	void Character::SetViewMode(ViewMode mode)
	{
		if (view_mode != mode)
		{
			view_mode = mode;
			camera_rotation_offset = Quaternion::kIdentity;
		}
	}

	/// set move controller
	void Character::SetMoveController(by_ptr(MoveController) controller)
	{
		move = controller;
		if (move)
			move->SetCharacter(ptr_static_cast<Character>(this));
	}

	/// set Action controller
	void Character::SetActionController(by_ptr(ActionController) controller)
	{
		action = controller;
		if (action)
			action->SetCharacter(ptr_static_cast<Character>(this));
	}
}


namespace Client
{
	/// on jump
	void Character::OnJump()
	{
		first_person.OnJump();
		third_person.OnJump();
	}

	/// on boost
	void Character::OnBoost(int dir)
	{
		first_person.OnBoost(dir);
		third_person.OnBoost(dir);
	}

	/// on onground
	void Character::OnOnground()
	{
		
		
		if (!IsDied() 
			&& ready)
		{
			NxRay ray;
			ray.orig = (const NxVec3 &)GetPosition();
			ray.orig.y += 3.f;
			ray.dir = (const NxVec3 &)Core::Vector3(0, -1, 0);

			NxRaycastHit hit;
			uint group_id = 0;
			group_id |= 1 << PhysxSystem::kStatic;
			group_id |= 1 << PhysxSystem::kStaticRaycast;
			NxShape* shape = gPhysxScene->raycastClosestShape(ray, NX_ALL_SHAPES, hit, group_id, 5.f);

			FMOD_VECTOR vel = {0, 0, 0};
			
		
			if (!IsCarrierMode() )
			{
				if(this == gLevel->GetPlayer())
				{
					switch (hit.materialIndex)
					{
					case PhysxSystem::kWood:
						FmodSystem::PlayEvent("bj/material/2d/step_jump/wood");				
						break;

					case PhysxSystem::kMetal:
						FmodSystem::PlayEvent("bj/material/2d/step_jump/metal");				
						break;

					case PhysxSystem::kConcrete:
						FmodSystem::PlayEvent("bj/material/2d/step_jump/concrete");				
						break;
					default:
						break;
					}

				}
				else
				{
					switch (hit.materialIndex)
					{
					case PhysxSystem::kWood:
						FmodSystem::Play3DEvent("bj/material/3d/step_jump/wood", (const FMOD_VECTOR &)GetPosition(), vel);				
						break;

					case PhysxSystem::kMetal:
						FmodSystem::Play3DEvent("bj/material/3d/step_jump/metal", (const FMOD_VECTOR &)GetPosition(), vel);				
						break;

					case PhysxSystem::kConcrete:
						FmodSystem::Play3DEvent("bj/material/3d/step_jump/concrete", (const FMOD_VECTOR &)GetPosition(), vel);				
						break;
					default:
						break;
					}
				}
			}

			/*
			key.format("bj/material/3d/step/wood");
			
			key.format("bj/material/3d/step/metal");
			
			key.format("bj/material/3d/step/concrete");
			*/
			
		}
		
		
		first_person.OnOnground();
		third_person.OnOnground();
	}

	/// fall down
	void Character::FallDown(float speed, bool is_onground)
	{
		if (action)
			action->FallDown(speed, is_onground);

		first_person.FallDown(speed, is_onground);
		third_person.FallDown(speed, is_onground);
	}

	/// die
	void Character::Die(const HitInfo & hit)
	{
		died = true;
		if (zombie_2D_breath)
		{
			zombie_2D_breath->stop();
		}
		if (zombie_3D_breath)
		{
			zombie_3D_breath->stop();
		}	
		if (invisible_zombie_3D_breath)
		{
			invisible_zombie_3D_breath->stop();
		}
		if (invisible_zombie_2D_breath)
		{
			invisible_zombie_2D_breath->stop();
		}
		if (boss_2D_fly)
		{
			boss_2D_fly->stop();
		}
		if (boss_2D_survival)
		{
			boss_2D_survival->stop();
		}
		if (boss_3D_fly)
		{
			boss_3D_fly->stop(true);
		}
		if (boss_2D_boost)
		{
			boss_2D_boost->stop();
		}
		if (boss_3D_boost)
		{
			boss_3D_boost->stop(true);
		}
		if (boss_2D_uav)
		{
			boss_2D_uav->stop();
		}
		if (boss_3D_uav)
		{
			boss_3D_uav->stop(true);
		}

		if (gLevel->somg_particle_set.Size() > 0)
		{
			HashSet<uint, sharedc_ptr(ParticleSystem)>::Enumerator itr(gLevel->somg_particle_set);
			while (itr.MoveNext())
			{
				if (itr.Key() == uid)
				{
					gLevel->RemoveParticle(itr.Value());
					gLevel->somg_particle_set.Remove(itr.Key());
					somg_time = -1.f;
					gGame->channel_connection->SomgAreaCancel(uid);
					break;
				}
			}
		}

		if (action)
			action->Die(hit);

		cure_all_value = 0;
		died_timer = died_time;

		basecharacter_info->survivalbag.Clear();

		if (gLevel)
		{
			if (gLevel->game_type == RoomOption::kBossMode2 && team == 1)
			{
				const Core::Array<sharedc_ptr(Character)>& characters = gLevel->GetCharacters();

				for (uint i = 0; i < characters.Size(); i++)
				{
					tempc_ptr(Character) c = characters[i];
					if (c && !c->IsDied() && c->GetTeam() == 1)
					{
						c->boss2_move_energy_max *= 1.2f;
						c->boss2_move_energy_recovery *= 1.2f;
					}
				}

				tempc_ptr(Character) c = gLevel->GetPlayer();
				if (c && !c->IsDied() && c->GetTeam() == 1)
				{
					c->boss2_move_energy_max *= 1.2f;
					c->boss2_move_energy_recovery *= 1.2f;
				}
			}
			if (gLevel->game_type == RoomOption::kBossMode2 && team == 0)
			{
				//const Core::Array<sharedc_ptr(Character)>& characters = gLevel->GetCharacters();

				//for (uint i = 0; i < characters.Size(); i++)
				//{
				//	tempc_ptr(Character) c = characters[i];
				//	if (c && !c->IsDied() && c->GetTeam() == 1)
				//	{
				//		c->boss2_move_energy_recovery *= 1.05f;
				//	}
				//}

				//tempc_ptr(Character) c = gLevel->GetPlayer();
				//if (c && !c->IsDied() && c->GetTeam() == 1)
				//{
				//	c->boss2_move_energy_recovery *= 1.05f;
				//}

				tempc_ptr(Character) from = gLevel->GetCharacter(hit.from_uid);
				if (from && from->GetTeam() == 1)
				{
					from->boss2_special_weapon_energy += 125.f;
					if (from->boss2_special_weapon_energy > from->boss2_special_weapon_energy_max)
						from->boss2_special_weapon_energy = from->boss2_special_weapon_energy_max;
					
				}
				tempc_ptr(Character) assist = gLevel->GetCharacter(hit.assist_uid);
				if (assist && assist->GetTeam() == 1)
				{
					assist->boss2_special_weapon_energy += 60.f;
					if (assist->boss2_special_weapon_energy > assist->boss2_special_weapon_energy_max)
						assist->boss2_special_weapon_energy = assist->boss2_special_weapon_energy_max;
				}
			}
		}
		
		if (ispveboss)
		{
			died_timer = 20.f;
			Core::String str = Core::String::Format("bj/player/3d/%s/finish",character_info->career_key);
			PveClientPlaySound(str, true);
		}

		if (character_info->third_person_dead_animation.Length() > 0)
		{
			PveClientPlayAction(character_info->third_person_dead_animation);
		}

		if (dead_particles.Size() > 0)
		{
			for (int i = 0; i < (int)dead_particles.Size(); ++i)
			{
				dead_particles[i]->timer = 0;
			}
		}
		character_particles.Clear();
		for(int i = 0; i < (int)prod_list.Size();++i)
		{
			prod_list[i]->timer = 0.f;
		}
		prod_list.Clear();

		for(int i = 0; i < (int)item_mode_particles.Size();++i)
		{
			item_mode_particles[i]->timer = 0.f;
		}
		item_mode_particles.Clear();
		

		for(int i = 0; i < (int)item_mode_buff_time.Size();++i)
		{
			item_mode_buff_time[i]->totle_time = 0.f;
		}
		item_mode_buff_time.Clear();

		for(int i = 0; i < (int)item_mode_debuff_time.Size();++i)
		{
			item_mode_debuff_time[i]->totle_time = 0.f;
		}
		item_mode_debuff_time.Clear();

		died_temp_timer = died_time;
		hp = 0;
		armor = 0;
		score = 0;
		accumulate_damage = 0;
		transparency = kTransparencyNone;
		lock_state_type = 0;
		benefitshadertype = 0;
		benefitshadertime = 0.f;
		camera_fov = NORMAL_FOV;
		camera_target_fov = NORMAL_FOV;
		camera_fov_change = 0;
		camera_rotation_offset = Quaternion::kIdentity;

		is_fov_changed = false;

		is_move_transparency = false;
		move_transparency_timer = 0.f;
		move_transparency_min_value = 0.f;
		move_transparency_speed = 0.f;
		show_shoot_time = 0;
		show_text_time = 0;
		equipment_info = NullPtr;
		is_item_boss = false;
		//camera_distance = 0.8f;
		itemmode_zibao = false;
		itemmode_flag1 = false;
		itemmode_item_slot = -1;
		current_hit_info = hit;
		if (current_hit_info.to_uid != current_hit_info.from_uid && this->uid == current_hit_info.to_uid && this == gLevel->GetPlayer())
		{
			gGame->camera->isendfind = true;
		}

		if (move)
			move->OnDied();

		first_person.Die(hit);
		third_person.Die(hit);
		first_person.StopShoot();
		third_person.StopShoot();

		is_bag_open = false;
		is_text_show = false;
		bag_flag = false;
		gun_special_particle = NullPtr;
		tp_special_particle = NullPtr;
		// sync data clear
		sync_data.Clear();

		if (this == gLevel->GetPlayer())
		{
			gLevel->isGunSensitivity = false;
		}
		if(this == gLevel->GetPlayer() || this == gLevel->GetViewer() && GetWeapon()->GetWeaponType() == kWeaponTypeMiniMachineGun)
		{
			tempc_ptr(MiniMachineGun) gun = ptr_dynamic_cast<MiniMachineGun>(GetWeapon());
			if (gun)
			{
				gun->FireReadyTime = 0;
				keep_Shoot_mini = false;
				if (GetFirstPerson().animation_group)
					GetFirstPerson().animation_group->StopAction(true);
				gun->next_fire_time = 0.f;
				if (gun->mini_gun_audio_spin_fire)
					gun->mini_gun_audio_spin_fire->stop();
			}
			gGame->channel_connection->PlayerAnimationEnd(kWeaponTypeMiniMachineGun);
		}

		tempc_ptr(MiniMachineGun) gun = ptr_dynamic_cast<MiniMachineGun>(GetWeapon());
		if (gun && gun->mini_gun_audio_spin_fire_3d)
			gun->mini_gun_audio_spin_fire_3d->stop();

		if(this == gLevel->GetPlayer() || this == gLevel->GetViewer() && GetWeapon()->GetWeaponType() == kWeaponTypeSniperGun)
		{
			tempc_ptr(SniperGun) gun = ptr_dynamic_cast<SniperGun>(GetWeapon());
			if (gun)
			{
				if (gun->gun_audio_energy_2d)
					gun->gun_audio_energy_2d->stop();
			}
		}
		if (this == gLevel->GetPlayer())
			lian_kill_count = 0;
		
		gLevel->RemoveAllAmmoByUser(uid,kWeaponTypeAmmoStick);

		runspeed_offset = 0.f;
		walkspeed_offset = 0.f;
		crouchspeed_offset = 0.f;
		flightspeed_offset = 0.f;

		SetMoveInfoOffset(0.f);
		SetWalk(false);

		if(gLevel->GetPlayer() == this && HasBomb())
		{
			gGame->channel_connection->DropWeaponByID(BOMB_SLOT);
		}

		zombie_saving_uid = 0;
		zombie_saver_uid = 0;
		zombie_saving_timer = -1.f;
		zombie_dying_flag = false;
		zombie_saving_flag = false;
		if (character_info->career_id == DEFAULT_COMMONZOMBIE_KING && common_zombie_dying_flag)
		{
			Core::String str = gLang->GetTextW(L"1��ĸ���������ѱ�����");
			//FmodSystem::PlayEvent("bj/event/crazy_killer");
			gLevel->AddHorn(str);
		}
		common_zombie_dying_flag = false;
		if (zombie_2D_human_heart)
		{
			zombie_2D_human_heart->stop();
			zombie_2D_human_heart = NULL;
		}
		m_PVEAmmoLaserSet.Clear();
		
		if(gLevel->GetPlayer() == this)
		{
			HashSet<uint, sharedc_ptr(DummyObject)>::Enumerator it(gLevel->dummy_object_set);
			while (it.MoveNext())
			{
				tempc_ptr(DummyObject) d = it.Value();
				if(d->owner_id == uid && !d->need_stepfather)
				{
					gGame->channel_connection->RequestDummyObjectDestory(it.Key());
				}
			}
		}
	}

	/// kill
	void Character::OnKill(const HitInfo & hit)
	{
		tempc_ptr(Character) c_to = gLevel->GetCharacter(hit.to_uid);
		tempc_ptr(Character) c_from = gLevel->GetCharacter(hit.from_uid);
		tempc_ptr(Character) assistplayer = gLevel->GetCharacter(hit.assist_uid);


		tempc_ptr(CharacterInfo) info = GetCurCharinfo();
		if (info && info->career_id == gLevel->item_career_id)
		{
			if(quickmovecd < 10)
				quickmovecd = 0;
			itemmode_flag1_timer += 1;
		}
		
		if (c_to && c_from && assistplayer && c_from == c_to && c_to->GetTeam() != assistplayer->GetTeam())
		{
			if (assistplayer->control_person_id == c_to->uid)
			{
				assistplayer->control_person_id = 0;
				c_to->GetThirdPerson().showcontrol = false;
				kills_kind.PushBack(kControl);
			}
			for (int k = 0; k < (int)assistplayer->array_reveng_id.Size(); ++k)
			{
				if (assistplayer->array_reveng_id[k] == c_to->uid)
				{
					kills_kind.PushBack(kReveng);
					c_to->GetThirdPerson().showrevenge = false;
					assistplayer->array_reveng_id.RemoveAt(k);
					break;
				}
			}
		}
		if (hit.to_uid != hit.from_uid && c_to && c_from && c_to->GetTeam()!=c_from->GetTeam())
		{
			kill_anim_time = 0.0f;
			isshowevent = true;
			kills_kind.Clear();
			spiritball_num = 0;
			bool isknife = false;
			

			if (hit.weapon && hit.weapon->weapon_type == kWeaponTypeKnife)
			{
				isknife = true;
				kills_kind.PushBack(kFight);
			}
			
			if(hit.sustainhurttype == kSustainFlameHurt)
			{
				kills_kind.PushBack(kSustain_Burn);
			}
			else if(hit.sustainhurttype == kSustainHurtPoison || hit.sustainhurttype == kSustainHurtCutHurt)
			{
				kills_kind.PushBack(kSustain_Poison);
			}

			if (hit.part == kCharacterPartHead && character_info && hit.weapon && hit.weapon->hit_crit_head > 0)
			{
				kills_kind.PushBack(kHead);
				if (c_from == gLevel->GetViewer())
				{
					FmodSystem::PlayEvent("bj/material/2d/hit_headshot");
				}
			}

			if(c_to && c_from && c_to->GetTeam() != c_from->GetTeam())
			{
				if (c_from == this)
				{
					if (c_from->control_person_id == c_to->uid)
					{
						c_from->control_person_id = 0;
						c_to->GetThirdPerson().showcontrol = false;
						kills_kind.PushBack(kControl);
					}
					for (int k = 0; k < (int)c_from->array_reveng_id.Size(); ++k)
					{
						if (c_from->array_reveng_id[k] == c_to->uid)
						{
							kills_kind.PushBack(kReveng);
							c_to->GetThirdPerson().showrevenge = false;
							c_from->array_reveng_id.RemoveAt(k);
							break;
						}
					}
				}

				if (c_to->ispveboss)
				{
					kills_kind.PushBack(kKillBoss);
				}
				if (gLevel->game_type == RoomOption::kCommonZombieMode)
				{
					if (c_to->character_info)
					{
						if (c_to->character_info->career_id == DEFAULT_COMMONZOMBIE_COM)
							kills_kind.PushBack(kCommonZombie_normal);
						else if (c_to->character_info->career_id == DEFAULT_COMMONZOMBIE_KING)
							kills_kind.PushBack(kCommonZombie_King);
						else if (c_to->character_info->career_id == DEFAULT_COMMONZOMBIE_LAST_KING)
							kills_kind.PushBack(kCommonZombie_LastKing);
						else if (c_to->character_info->career_id == DEFAULT_COMMONZOMBIE_DISAPPEAR)
							kills_kind.PushBack(kCommonZombie_disappear);
						else if (c_to->character_info->career_id == DEFAULT_COMMONZOMBIE_DRUG)
							kills_kind.PushBack(kCommonZombie_drug);
						else if (c_to->character_info->career_id == DEFAULT_COMMONZOMBIE_CHARGE)
							kills_kind.PushBack(kCommonZombie_charge);
						else if (c_to->is_human_super)
						{
							kills_kind.PushBack(kCommonZombie_infect_Last);
						}
						else
						{
							kills_kind.PushBack(kCommonZombie_infect);
						}
					}
				}
				else if (gLevel->game_type == RoomOption::kBossMode2)
				{
					if (c_to->character_info)
					{
						if (c_to->is_boss)
						{
							kills_kind.PushBack(kBossmode2_Boss);
						}
					}
				}

				lian_kill_count++;
				if (lian_kill_count < 5)
					kills_kind.PushBack(kGeneral);
				else
					kills_kind.PushBack(kContinuation);
				if(lian_kill_count == 5)
				{
					if (gLevel->GetPlayer() == this)
					{
						if (is_boss)
						{
							Core::String str = Core::String::Format("bj/player/2d/boss/yell");
							FmodSystem::PlayEvent(str.Str());
						}
						else
						{
							Core::String str = Core::String::Format("bj/player/2d/%s/yell",this->GetCurCharinfo()->career_key);
							FmodSystem::PlayEvent(str.Str());
						}
					}
					Core::CStrBuf<character_name_length> result = GetName();
					if(gGame->global)
						gGame->global->Translate(result);
					Core::String str = Core::String::Format(gLang->GetTextW(L"%s ��Ϊɱ�˿�"),result);
					FmodSystem::PlayEvent("bj/event/crazy_killer");
					gLevel->AddHorn(str);
				}
			}
			//LogSystem.WriteLinef("KingId:%d", gLevel->current_street_king_uid[0]);
			//LogSystem.WriteLinef("KingId:%d", gLevel->current_street_king_uid[1]);
			if (gLevel->game_type == RoomOption::kStreetBoyMode)
			{
				if(hit.to_uid == gLevel->current_street_king_uid[0] || hit.to_uid == gLevel->current_street_king_uid[1])
				{
					kills_kind.PushBack(KKill_King);
				}
			}
			if (gLevel->game_type == RoomOption::kZombieMode)
			{
				if(c_to->GetTeam()==1)
				{
					kills_kind.PushBack(KKill_Zombie);
					if (lian_kill_count == 10)
					{
						Core::String str = Core::String::Format(gLang->GetTextW(L"%s ��������������"),GetName());
						//FmodSystem::PlayEvent("bj/event/crazy_killer");
						gLevel->AddHorn(str);
					}
					if (gLevel->GetPlayer() == this)
					{
						if (c_to && c_to->character_info->career_id == DEFAULT_ZOMBIE_KING)
						{
							Core::String str = Core::String::Format(gLang->GetTextW(L"%s ɱ�������������ߣ���Ϊ�˾�������"),GetName());
							gLevel->AddHorn(str);
							FmodSystem::PlayEvent("bj/event/bio/human_kill_bio");
						}
					}
				}
				if (c_to->GetTeam()==0)
				{				
					if (hit.weapon && hit.weapon->weapon_type == kWeaponTypeZombieGun)
					{
						kills_kind.PushBack(KKill_Kill);
						if (gLevel->GetPlayer() == this)
						{
							FmodSystem::PlayEvent("bj/event/bio/bio_kill_human");
						}
					} 
					if(hit.weapon && (hit.weapon->weapon_type == kWeaponTypeZombieCharge || hit.weapon->weapon_type == kWeaponTypeSpecial))
					{
						kills_kind.PushBack(KKill_SkillKill);
						if (gLevel->GetPlayer() == this)
						{
							FmodSystem::PlayEvent("bj/event/bio/bio_skillkill_human");							
						}
					}
					if (gLevel->GetPlayer() == this)
					{
						//������ߵ���ʾ
						Core::String str = Core::String::Format(gLang->GetTextW(L"%sʹ%s�޷��ټ���ս���ˣ�"),c_from->GetName(),c_to->GetName());
						gLevel->AddHorn(str);
					}
					else
					{
						//������ߵ���ʾ
						Core::String str = Core::String::Format(gLang->GetTextW(L"%sʹ%s�޷��ټ���ս���ˣ�"),c_from->GetName(),c_to->GetName());
						gLevel->AddHorn(str);
					}
					FmodSystem::PlayEvent("bj/event/bio/human_killed");
				}
			}
			first_person.OnKill(hit);
			third_person.OnKill(hit);
		}
	}

	void Character::OnKickBack(const KickInfo & info, bool skip_physx)
	{
		if (move&&move->GetKickTimer() < 0.f)
			move->OnHitByVehicle(info, skip_physx);
	}

	/// on hit
	void Character::OnHit(const HitInfo & info)
	{
		float speed_factor = 1.0f;
		float acc_factor = 1.0f;
		float distance_factor = -1.0f;
		
		tempc_ptr(Character) c_from = gLevel->GetCharacter(info.from_uid);
		tempc_ptr(Character) c_to = gLevel->GetCharacter(info.to_uid);
		if (c_from && gLevel->game_type == RoomOption::kCommonZombieMode && c_to->team == 1)
		{
			tempc_ptr(WeaponInfo) weapon = c_from->GetWeapon()->weapon_info;
			if (weapon)
			{
				if (c_from->character_info->career_id == 7)
				{
					distance_factor = 1.5f;
				}
				else if (weapon->weapon_type == kWeaponTypeLuncher)
				{
					distance_factor = 5.0f;
				}
				else if(weapon->weapon_type == kWeaponTypeSniperGun)
				{
					distance_factor = 12.0f;
				}
				else if(weapon->weapon_type == kWeaponTypeMiniMachineGun)
				{
					distance_factor = 1.0f;
				}
				else if (weapon->weapon_type == kWeaponTypeMeditNeedleGun)
				{
					distance_factor = 0.0f;
				}
				else if (weapon->weapon_type == kWeaponTypeSubMachineGun)
				{
					distance_factor = 4.0f;
				}
				else if (weapon->weapon_type == kWeaponTypeFlameGun)
				{
					distance_factor = 1.0f;
				}
				else if (weapon->weapon_type == kWeaponTypeShotGun)
				{
					distance_factor = 0.5f;
				}
				else if (weapon->weapon_type == kWeaponTypePistol)
				{
					distance_factor = 2.f;
				}
				else if (weapon->weapon_type == kWeaponTypeSignal)
				{
					distance_factor = 2.f;
				}
			}
		}

		if (gLevel->game_type == RoomOption::kBossMode2 && info.part == kCharacterPartHead && c_to && c_to->is_boss)
		{
			c_to->boss2_head_damage += hp - info.hp;
			if (c_to->boss2_head_damage > 3000.f)
			{
				c_to->boss2_head_damage -= 3000.f;
				c_to->boss2_head_damage_timer = 8.f;
				Core::String str;
				if (gLevel->GetPlayer()->GetTeam() == 1)
				{
					str = Core::String::Format(gLang->GetTextW(L"%s��ʻ��boss����̱���ˣ���ȥ֧Ԯ"),c_to->GetName());
				} 
				else
				{
					str = Core::String::Format(gLang->GetTextW(L"%s��ʻ��boss����̱���ˣ���ȥ����"),c_to->GetName());
				}

				FMOD_VECTOR vel = {0, 0, 0};
				FmodSystem::Play3DEvent("bj/player/3d/armor_robot/armor_down", (const FMOD_VECTOR &)c_to->GetPosition(), vel);
				gLevel->AddHorn(str);
				tempc_ptr(StateMainGame) state_main = ptr_dynamic_cast<StateMainGame>(gGame->machine.CurrentState());
				if (state_main && gLevel && gLevel->GetPlayer()->GetTeam() == 0)
				{
					state_main->ui->m_Bottom_str[0] = Core::String::Format(gLang->GetTextW(L"%s��ʻ��BOSS����̱���ˣ���ȥ������"),c_to->GetName());
					state_main->ui->m_ShowBottom_str_time[0] = 3.0f;
				}
			}
		}

		float p = GetTotalAttributeByType(kEffect_Infect_HitBack);
		distance_factor = Max(0.f, distance_factor * p);
		if (move)
			move->OnHit(info, speed_factor, acc_factor, distance_factor);   
		if (gLevel->game_type == RoomOption::kZombieMode)
		{
			if (c_from->GetTeam() == 1 && c_from != c_to)
			{
				if (c_from == gLevel->GetPlayer())
				{
					FmodSystem::PlayEvent("bj/material/2d/bio_hit_human");
				}
			}
		}

		if(ispveboss && hp - info.hp > 100)
		{
			blood_leak_timer = 0.6f;
		}

		SetSelfTransparency(true, equipment_info);

		first_person.OnHit(info);
		third_person.OnHit(info);

		// punch angle
		punch_angle.x += 1 * DEG2RAD;

		if (punch_angle.x * RAD2DEG > 2)
			punch_angle.x = 2 * DEG2RAD;

		ushort prohp = hp;
		hp = info.hp;
				
		armor = info.armor;
		HitInfo * pHitUI = NULL;

		// find hit ui
		if (info.sustainhurttype == kSustainSurvivalMode)
			return;

		for (uint i = 0; i < hit_ui.Size(); i ++)
		{
			HitInfo & ui = hit_ui[i];

			if (ui.time > 0)
			{
				if (ui.from_uid == info.from_uid)
				{
					pHitUI = &ui;
					break;
				}
			}
			else
			{
				pHitUI = &ui;
			}
		}

		if (pHitUI)
		{
			*pHitUI = info;
			//LogSystem.WriteLinef("%d",pHitUI->hp);
		}
	}

	/// on hit character
	void Character::OnHitCharacter(tempc_ptr(Character) hit_character)
	{
		if (action)
			action->OnHitCharacter(hit_character);
	}

	/// get pose
	tempc_ptr(Pose) Character::GetPose()
	{
		switch (view_mode)
		{
		case kFirstPerson:
			return first_person.pose;

		case kThirdPerson:
			return third_person.pose;
		}

		return NullPtr;
	}

	/// get view mode
	Character::ViewMode Character::GetViewMode()
	{
		return view_mode;
	}

	/// get first person
	FirstPerson & Character::GetFirstPerson()
	{
		return first_person;
	}

	/// get third person
	ThirdPerson & Character::GetThirdPerson()
	{
		return third_person;
	}

	/// on grenade explode
	void Character::OnGrenadeExplode()
	{
		if (IsDied() == false)
		{
			first_person.OnGrenadeExplode();
			third_person.OnGrenadeExplode();
		}
	}

	/// on bomb explode
	void Character::OnBombExploded()
	{
		if (IsDied() == false)
		{
			first_person.OnBombExploded();
			third_person.OnBombExploded();
		}
	}

	/// response hit
	void Character::ResponseHit(const Core::Vector3 & from_position, const Core::Vector3 & target, const Core::Vector3 & normal, int part, UINT weapontype,bool no_blood, bool isboost)
	{
		switch (view_mode)
		{
		case kFirstPerson:
			first_person.ResponseHit(from_position, target, normal, part, weapontype, no_blood, isboost);
			break;

		case kThirdPerson:
			third_person.ResponseHit(from_position, target, normal, part, weapontype, no_blood, isboost);
			break;
		}
	}

	/// rebirth
	void Character::Rebirth(int hp, int armor, const Core::Vector3& p, const Core::Quaternion& r)
	{
		if (this == gLevel->GetPlayer())
		{
			int num = rand()%10;
			if (num < 2)
			{
				String str = String::Format("bj/player/2d/%s_phrase",character_info->res_key);
				FmodSystem::PlayEvent(str.Str());
			}
			tempc_ptr(StateMainGame) state_main = ptr_dynamic_cast<StateMainGame>(gGame->machine.CurrentState());
			if (state_main)
				state_main->ui->commonzombie_skill.Clear();
		}

		boss2_self_kill = false;
		boss2_self_kill_timer = 0.f;

		boss2_head_damage = 0.f;
		boss2_head_damage_timer = 0.f;

		somg_time = -1.f;

		if (gLevel->game_type == RoomOption::kCommonZombieMode && character_info->career_id == 43)
		{
			if (this == gLevel->GetPlayer())
			{
				if (!invisible_zombie_2D_breath)
				{
					invisible_zombie_2D_breath = FmodSystem::GetEvent("bj/player/2d/bio/bioshadow_breath");
				}
				invisible_zombie_2D_breath->start();
			} 
			else
			{
				if (!invisible_zombie_3D_breath)
				{
					FMOD_VECTOR vel = {0, 0, 0};
					String str = String::Format("bj/player/3d/bio/bioshadow_breath");
					invisible_zombie_3D_breath = FmodSystem::Play3DEvent(str.Str(),(const FMOD_VECTOR &)Vector3(0,0,0),vel);
				}
				else
				{
					invisible_zombie_3D_breath->start();
				}
			}	
		}
		else if (gLevel->game_type == RoomOption::kCommonZombieMode && character_info->career_id >= 20)
		{
			if (this == gLevel->GetPlayer())
			{
				if (!zombie_2D_breath)
				{
					zombie_2D_breath = FmodSystem::GetEvent("bj/player/2d/bio/bio_breath");
				}
				zombie_2D_breath->start();
			} 
			else
			{
				if (!zombie_3D_breath)
				{
					FMOD_VECTOR vel = {0, 0, 0};
					String str = String::Format("bj/player/3d/bio/bio_breath");
					zombie_3D_breath = FmodSystem::Play3DEvent(str.Str(),(const FMOD_VECTOR &)Vector3(0,0,0),vel);
				}
				else
				{
					zombie_3D_breath->start();
				}
			}	
		}
		else if (gLevel->game_type == RoomOption::kSurvivalMode )
		{

			if (this == gLevel->GetPlayer())
			{
				if (!boss_2D_survival)
				{
					boss_2D_survival = FmodSystem::GetEvent("bj/fx/2d/survival_low_hp");
				}
				boss_2D_survival->start();
			} 
			else
			{
				if (!boss_2D_survival)
				{
					FMOD_VECTOR vel = {0, 0, 0};
					String str = String::Format("bj/fx/2d/survival_low_hp");
					boss_2D_survival = FmodSystem::Play3DEvent(str.Str(),(const FMOD_VECTOR &)Vector3(0,0,0),vel);
				}
				else
				{
					boss_2D_survival->start();
				}
			}	

		}
		else
		{
			if (zombie_3D_breath)
			{
				zombie_3D_breath->stop();
			}
			if (zombie_2D_breath)
			{
				zombie_2D_breath->stop();
			}
			if (invisible_zombie_3D_breath)
			{
				invisible_zombie_3D_breath->stop();
			}
			if (invisible_zombie_2D_breath)
			{
				invisible_zombie_2D_breath->stop();
			}
			if (boss_2D_survival)
			{
				boss_2D_survival->stop();
			}
		}


		if (move)
			move->OnRebirth(ptr_static_cast<Character>(this), p, r);

		if (action)
			action->Rebirth();

		tempc_ptr(ZombieGun) zombiegun = ptr_dynamic_cast<ZombieGun>(GetWeaponById(0));

		if (zombiegun)
		{
			zombiegun_cd_time = zombiegun->knife_info->skill_cooldown;
		}
		else
		{
			zombiegun_cd_time = 0.0f;
		}
		
		cure_all_value = 0;
		radio_id = -1;
		radio_item = -1;
		radio_state = 0;
		// radio map
		radio_effect_list.Clear();
		show_shoot_time = 0;
		show_text_time = 0;
		// reset hit ui
		for (uint i = 0; i < hit_ui.Size(); i ++)
			hit_ui[i].time = 0;

		tempc_ptr(Character) c = gLevel->GetViewer();

		fire_time_ratio = 0.0f;

		born_position = p;

		is_shoot_stab = false;
		keep_Shoot_mini = false;
		is_level_up_effect_flag = false;
		is_level_up_effect_ratio[0] = 0.0f, is_level_up_effect_ratio[1] = 0.0f;
		is_level_up_effect_time[0] = 0.0f, is_level_up_effect_time[1] = 0.0f;
		is_level_up_effect_curtime = 0.0f;

		skill_history_info.Clear();

		already_team_defuse = false;

		is_team_hurt_part = false;
		is_team_hurt_dead = false;
		team_hurt_time = 0.0f;
		team_hurt_dead_time = 0.0f;
		team_hurt_part_time = 0.0f;

		kill_effect_text_anim = 0;
		kill_effect_num_anim = 0;
		kill_effect_text_time = 0.0f;
		kill_effect_num_time = 0.0f;
		kill_effect_flag = false;
		kill_effect_textbg_anim = 0;
		kill_effect_textbg_time = 0.0f;
		kill_effect_wait = false;

		blood_add_effect_time = 0.0f;
		lian_kill_count = 0;
		key_button_effect_time = 0.0f;
		key_button_effect_size = 0.0f;

		team_request_waittime = 0.0f;
		team_success_join_time = 0.0f;
		team_refuse_time = 0.0f;

		is_point_emeny = false;

		power_up_time = 0.0f;
		disguise_time = 0.0f;

		is_ready_bag_close = false;
		is_bag_open = false;
		is_text_show = false;
		is_range_bag_flag = false;

		//current_bag_id = 1;
		//prev_bag_id = current_bag_id;
		bag_dialog_wait_time = 0.0f;

		bag_flag = true;

		bag_wait_time = 0.0f;
		bag_flash_time = 0.0f;

		is_display_banner = true;
		is_display_c4_tip = true;
		is_display_weapon_list = true;

		damage_hp = 0;
		damage_armor = 0;
		is_display_damage_hp = false;
		damage_hp_time = 0.0f;

		current_pickup_object_list.Clear();
		current_pickup_object_type_list.Clear();
		current_pickup_object_name.Clear();

		hits_score_alpha = 0.0f;

		control_reverse_timer = 0;
		radar_timer = 0;
		radar_ui_timer = 0;

		//transparency = kTransparencyNone;
		//transparency_value = 1.0f;

		//is_move_transparency = false;
		//move_transparency_timer = 0.f;
		//move_transparency_min_value = 0.f;
		//move_transparency_speed = 0.f;

		old_hp = 0;
		new_hp = 0;

		kills_kind.Clear();
		spiritball_num = 0;
		for(int i = 0 ; i < 5; i++)
			speaker_tip_time[i] = 100.0f;

		attack_level_time = 0.0f;

		attack_level_flag = false;
		attack_level_count = 0;

		weapon_list_icon_flag = false;
		weapon_list_icon_waittime = 0.0f;
		weapon_list_icon_alpha = 0.0f;
		weapon_current_icon_alpha = 1.0f;
		weapon_next_icon_alpha = 0.0f;

		camera_fov = NORMAL_FOV;
		camera_target_fov = NORMAL_FOV;
		camera_fov_change = 0;
		//camera_distance = 0;
		camera_rotation_offset = Quaternion::kIdentity;
		camera_control_mode = Camera::kCharacterControl;

		is_fov_changed = false;

		SetPhysxControl(false);
		this->hp = hp;
		this->last_hp = hp;
		//this->old_hp = hp;
		this->armor = armor;
		ready = true;
		died_timer = 0;
		died_temp_timer = 0;
		died = false;
		weapon_id_last = 2;

		reloading = false;
		shooting = false;
		throwing_grenade = false;
		grenade_throw_out = false;
		stabing = false;
		planting_bomb = false;
		first_action_on = false;
		second_action_on = false;


		flash_bright_time = 0;
		flash_fade_time = 2.f;

		boss2_special_weapon_energy = 0.f;
		boss2_special_weapon_energy_max = 1000.f;

		first_person.Rebirth();
		third_person.Rebirth();

		// initialize sync data
		time = 0;
		sync_time = 0;
		sync_data.Clear();

		CharacterSyncData & sync = sync_data.PushBack();

		sync.time = 0;
		sync.position = GetPosition();
		sync.rotation = GetRotation();
		sync.crouch = GetCrouch();
		sync.walk = GetWalk();
		sync.jump = IsJumping();
		sync.onground = IsOnGround();
		sync.move = Vector2(0, 0);
		sync.flying = false;
		sync.boost = false;
		
		killerinfo.Reset();
		
		runspeed_offset = 0.f;
		walkspeed_offset = 0.f;
		crouchspeed_offset = 0.f;
		flightspeed_offset = 0.f;

		can_Invincible = false;

		tempc_ptr(GunTowerBuilder) w = ptr_dynamic_cast<GunTowerBuilder> (GetWeaponById(0));
		if (w)
		{
			w->SetAmmoCount(-1);
			tower_gun_percent = 1.0f;
		}
		
		SetMoveInfoOffset(0.f);
		SetWalk(false);

		gLevel->spray_set.Remove(uid);
		
	}

	/// can reload
	bool Character::CanReload()
	{
		tempc_ptr(GunBase) gun = ptr_dynamic_cast<GunBase>(GetWeapon());
		if (gun)
			return (!IsDied()) && (!reloading) && (weapon_select_state == kWeaponReady);

		return false;
	}

	/// can fire
	bool Character::CanFire()
	{
		return (!IsDied()) && (weapon_select_state == kWeaponReady) && (!IsAttributeExist(kEffect_Special_CannotFire)) && (!reloading) && (IsBossMode2()) && !isghost;
	}

	/// can throw grenade
	bool Character::CanThrowGrenade()
	{
		return (!IsDied()) && (weapon_select_state == kWeaponReady) && (!throwing_grenade);
	}

	/// can stab
	bool Character::CanStab()
	{
		return (!IsDied()) && (weapon_select_state == kWeaponReady) && (!stabing);
	}

	/// grenade throw in
	void Character::GrenadeThrowIn()
	{
		if (!action || action->GrenadeThrowIn())
		{
			throwing_grenade = true;
			first_person.GrenadeThrowIn();
			third_person.GrenadeThrowIn();
		}
	}

	/// grenade ready
	void Character::GrenadeReady()
	{
		if (action)
			action->GrenadeReady();
	}

	/// grenade throw request
	void Character::GrenadeThrowRequest(byte type)
	{
		if (action)
			action->GrenadeThrowRequest(type);
	}

	void Character::PlaySoundEffectFromWeapon(const Core::Vector3& pos, const Core::Vector3& dir)
	{
		int randnum = rand()%10;
		if (randnum <= 1)
			return;

		if (gLevel->GetPlayer() == NULL || effect_collider == NULL)
			return;

		Vector3 dir_normal = dir;
		dir_normal.Normalize();
		
		NxRay ray;
		ray.orig = (const NxVec3 &)pos;
		ray.dir = (const NxVec3 &)dir_normal;

		NxRaycastHit hit;

		uint group_id = 0;
		group_id |= 1 << PhysxSystem::kGroupSoundEffect;

		NxShape* shape = gPhysxScene->raycastClosestShape(ray, NX_ALL_SHAPES, hit, group_id, 2000);
		Vector3 play_pos;
		if (shape)
		{
			NxActor& actor = shape->getActor();
			tempc_ptr(Character) p = Character::FromNxActor(actor);
			if (p == gLevel->GetPlayer())
			{
				play_pos.x = hit.worldImpact.x;
				play_pos.y = hit.worldImpact.y;
				play_pos.z = hit.worldImpact.z;
				FMOD_VECTOR vel = {0, 0, 0};
				Core::String str = String::Format("bj/ambience/bullet_miss");
				FmodSystem::Play3DEvent(str,(const FMOD_VECTOR &)play_pos, vel);
			}
		}
	}

	/// grenade throw out
	void Character::GrenadeThrowOut(int w_id, by_ptr(ThrowableInfo) info, const Vector3 & position, const Vector3 & direction)
	{
		if (action && action->GrenadeThrowOut(info, position, direction))
		{
			if (w_id == weapon_id)
			{
				grenade_throw_out = true;
				first_person.GrenadeThrowOut(info, w_id);
				third_person.GrenadeThrowOut(info, w_id);
			}
			else
			{
				//SetWeapon(w_id, NullPtr);
				grenade_throw_out = false;
			}
			
			gLevel->ThrowGrenade(uid, info, position, direction, GetTeam());
			
			tempc_ptr(Character) player = gLevel->GetPlayer();
			if(player && player == this)
			{
				SetGrenadeCDTiming( info->time_to_idle );
				player->bag_flag = false;
			}
		}
	}

	/// stop throw grenade
	void Character::GrenadeThrowStop()
	{
		//if (action && action->GrenadeThrowStop())
		//{
		//	throwing_grenade = false;
		//	if (grenade_throw_out)
		//		SetWeapon(weapon_id, NullPtr);

		//	grenade_throw_out = false;
		//	first_person.GrenadeThrowStop();
		//	third_person.GrenadeThrowStop();
		//}
		skip_grenade = true;
	}

	/// on grenade throw out
	void Character::OnGrenadeThrowOut()
	{
		//SelectWeapon(0);
		//SelectWeapon(1);
		ChangeWeapon();
	}

	/// knife stab
	void Character::Stab(byte type)
	{
		if (action && action->Stab(type))
		{
			SetSelfTransparency(true, equipment_info);

			stabing = true;
			first_person.Stab(type, weapon_id);
			third_person.Stab(type, weapon_id);
		}
	}

	/// stop stab
	void Character::StopStab()
	{
		if (action && action->StopStab())
		{
			stabing = false;
			first_person.StopStab();
			third_person.StopStab();
		}
	}

	// Radio Action
	void Character::RadioAction()
	{
		if (is_boss)
		{
			return;
		}
		CStrBuf<character_name_length> name_str;
		bool bpress = false;
		if(gGame->config->IsActionReleased(kActionUIRadio1))
		{
			if(radio_state ==1)
			{
				radio_state = 0;
				radio_id = -1;
			}
			else
			{
				radio_state = 1;
				radio_id = 0;
			}
		}
		if(gGame->config->IsActionReleased(kActionUIRadio2))
		{
			if(radio_state==2)
			{
				radio_state = 0;
				radio_id = -1;
			}
			else
			{
				radio_state = 2;
				radio_id = 1;
			}
		}
		if(gGame->config->IsActionReleased(kActionUIRadio3))
		{
			if(radio_state == 3)
			{
				radio_state = 0;
				radio_id = -1;
			}
			else
			{
				radio_state = 3;
				radio_id = 2;
			}
		}
		if(gGame->config->IsActionReleased(kActionUIRadio4) && gLevel->GunTower_Move_CD < 0.1f)
		{
			tempc_ptr(Character) player = gLevel->GetPlayer();
			if (player)
			{
				tempc_ptr(WeaponBase) Tower_gun =  player->GetWeaponById(0);
				if (Tower_gun && player->tower_gun_count)
				{
					if(radio_state == 4)
					{
						radio_state = 0;
						radio_id = -1;
					}
					else
					{
						radio_state = 4;
						radio_id = 3;
					}
				}
			}
		}

		if(radio_state !=0)
		{
			if(gGame->config->IsActionDown(kActionMenu0))
			{
				radio_state = 0;
				radio_id = -1, radio_item = -1;
				bpress = true;
			}
			if(gGame->config->IsActionDown(kActionMenu1) && (radio_state==1 || radio_state == 2 || radio_state == 3 || radio_state == 4))
			{
				radio_item = 0;
				radio_state = 0;
				bpress = true;
			}
			if(gGame->config->IsActionDown(kActionMenu2) && (radio_state == 1 || radio_state == 2 || radio_state == 3 || radio_state == 4) )
			{
				radio_state = 0;
				radio_item = 1;
				bpress = true;
			}
			if(gGame->config->IsActionDown(kActionMenu3) && (radio_state == 1 || radio_state == 2 || radio_state == 3 || radio_state == 4) )
			{
				radio_state = 0;
				radio_item = 2;
				bpress = true;
			}
			if(gGame->config->IsActionDown(kActionMenu4) && (radio_state == 1 || radio_state == 2 || radio_state == 3 || radio_state == 4) )
			{
				radio_state = 0;
				radio_item = 3;
				bpress = true;
			}
			if(gGame->config->IsActionDown(kActionMenu5) && (radio_state == 1 || radio_state == 2 || radio_state == 3))
			{
				radio_state = 0;
				radio_item = 4;
				bpress = true;
			}
			if(gGame->config->IsActionDown(kActionMenu6) && (radio_state == 1 || radio_state == 3) )
			{
				radio_state = 0;
				radio_item = 5;
				bpress = true;
			}
		}
		if(radio_item != -1 && radio_id != -1 && bpress)
		{
		
			if(radio_id == 0 )
			{
				if(radio_item == 0)
				{
					name_str.format(gLang->GetTextW(L"�õģ��յ���"));
					if(gGame->channel_connection)
						gGame->global->Chat("/x",name_str);
				}
				if(radio_item == 1)
				{
					name_str.format(gLang->GetTextW(L"ǰ�����ֵ��ˣ�"));
					if(gGame->channel_connection)
						gGame->global->Chat("/x",name_str);
				}
				if(radio_item == 2)
				{
					name_str.format(gLang->GetTextW(L"����Ҫ�ڻ���"));
					if(gGame->channel_connection)
						gGame->global->Chat("/x",name_str);
				}
				if(radio_item == 3)
				{
					name_str.format(gLang->GetTextW(L"ǰ����ȫ��"));
					if(gGame->channel_connection)
						gGame->global->Chat("/x",name_str);
				}
				if(radio_item == 4)
				{
					name_str.format(gLang->GetTextW(L"��������"));
					if(gGame->channel_connection)
						gGame->global->Chat("/x",name_str);
				}
			}
			if(radio_id == 1)
			{
				if(radio_item == 0)
				{
					name_str.format(gLang->GetTextW(L"С�Ļ����͵Ϯ��"));
					if(gGame->channel_connection)
						gGame->global->Chat("/x",name_str);
				}

				if(radio_item == 1)
				{
					name_str.format(gLang->GetTextW(L"С�ĵ��˾ѻ��֣�"));
					if(gGame->channel_connection)
						gGame->global->Chat("/x",name_str);
				}
				if(radio_item == 2)
				{
					name_str.format(gLang->GetTextW(L"������Ҫ�ػ�ǹ�֣�"));
					if(gGame->channel_connection)
						gGame->global->Chat("/x",name_str);
				}
				if(radio_item == 3)
				{
					name_str.format(gLang->GetTextW(L"����Ư����"));
					if(gGame->channel_connection)
						gGame->global->Chat("/x",name_str);
				}

				if(radio_item == 4)
				{
					name_str.format(gLang->GetTextW(L"������أ�"));
					if(gGame->channel_connection)
						gGame->global->Chat("/x",name_str);
				}
			}

			if(radio_id == 2)
			{
				if(radio_item == 0)
				{
					name_str.format(gLang->GetTextW(L"��ҿ�ȥռ�㣡"));
					if(gGame->channel_connection)
						gGame->global->Chat("/x",name_str);
				}
				if(radio_item == 1)
				{
					name_str.format(gLang->GetTextW(L"��ҿ�ȥ�Ƴ���"));
					if(gGame->channel_connection)
						gGame->global->Chat("/x",name_str);
				}
				if(radio_item == 2)
				{
					name_str.format(gLang->GetTextW(L"�壡�壡�壡"));
					if(gGame->channel_connection)
						gGame->global->Chat("/x",name_str);
				}
				if(radio_item == 3)
				{
					name_str.format(gLang->GetTextW(L"��ҷ�ɢ����"));
					if(gGame->channel_connection)
						gGame->global->Chat("/x",name_str);
				}
				if(radio_item == 4)
				{
					name_str.format(gLang->GetTextW(L"����һ�£�"));
					if(gGame->channel_connection)
						gGame->global->Chat("/x",name_str);
				}


			}

			if(radio_id == 3)
			{
				if (gLevel->game_type == RoomOption::kEditMode)
				{
					return;
				}
				tempc_ptr(Character) player = gLevel->GetPlayer();
				if(player)
				{
					HashSet<uint, sharedc_ptr(DummyObject)>::Enumerator it(gLevel->dummy_object_set);
					while (it.MoveNext())
					{
						if(it.Value()->owner_id == player->uid && it.Value()->type == DummyObject::DUMMY_MACHINE_TURRENT)
						{
							tempc_ptr(MachineGunTurret) t  =  ptr_dynamic_cast<MachineGunTurret>(it.Value());
							if(t && !t->need_stepfather)
							{
								t->MoveCommand(radio_item);
								gLevel->GunTower_Move_CD = 2.0f;
							}
						}
					}
				}
			}

			if(gGame->channel_connection)
			{
				gGame->channel_connection->RadioReport(radio_id,radio_item, radio_avarname);
				Console.WriteLinef("radio send %s",radio_avarname);
			}

			radio_item = -1;
			radio_id = -1;
			radio_state = 0;
			radio_avarname.Clear();
		}
		
	}

	/// Set CureParticle Enable
	void Character::SetCureParticleShow(int time)
	{
		third_person.cure_particel_time = time;
	}


	// Radio Update
	void Character::RadioPlay(int radio_id, int radio_item, Core::String radio_avarname)
	{
		FMOD::Event* audio_event;
		CStrBuf<256> radio_str;
		//bj/radio/avrfireman/ch_found_enemy_01.wav
		
		tempc_ptr(Character) player = gLevel->GetPlayer();
		
		//tempc_ptr(Character) viewer = gLevel->GetViewer();
		//if(viewer)
		//	player = viewer;
		if(!player)
			return;
		if(player->IsDied())
			return;	
		if(radio_id >=0)
		{
			if( radio_avarname.Length() <= 0)
				radio_str.format("bj/radio/%s/", character_info->res_key);
			else
				radio_str.format("bj/radio/%s/", radio_avarname);
		}

		if(radio_id == 0 )
		{
			if(radio_item == 0)
			{
				radio_str.contract("roger");
				audio_event = FmodSystem::PlayEvent(radio_str.buff());
			}
			if(radio_item == 1)
			{
				radio_str.contract("found_enemy");
				audio_event = FmodSystem::PlayEvent(radio_str.buff());
			}
			if(radio_item == 2)
			{
				radio_str.contract("need_cover");
				audio_event = FmodSystem::PlayEvent(radio_str.buff());
			}
			if(radio_item == 3)
			{
				radio_str.contract("safe");
				audio_event = FmodSystem::PlayEvent(radio_str.buff());
			}
			if(radio_item == 4)
			{
				radio_str.contract("followme");
				audio_event = FmodSystem::PlayEvent(radio_str.buff());
			}
		}
		if(radio_id == 1)
		{
			if(radio_item == 0)
			{
				radio_str.contract("firebat");
				audio_event = FmodSystem::PlayEvent(radio_str.buff());
			}

			if(radio_item == 1)
			{
				radio_str.contract("sniper");
				audio_event = FmodSystem::PlayEvent(radio_str.buff());
			}
			if(radio_item == 2)
			{
				radio_str.contract("takefire");
				audio_event = FmodSystem::PlayEvent(radio_str.buff());
			}
			if(radio_item == 3)
			{
				radio_str.contract("cool");
				audio_event = FmodSystem::PlayEvent(radio_str.buff());
			}

			if(radio_item == 4)
			{
				radio_str.contract("hold");
				audio_event = FmodSystem::PlayEvent(radio_str.buff());
			}
		}

		if(radio_id == 2)
		{
			if(radio_item == 0)
			{
				radio_str.contract("takepoint");
				audio_event = FmodSystem::PlayEvent(radio_str.buff());
			}
			if(radio_item == 1)
			{
				radio_str.contract("pushup");
				audio_event = FmodSystem::PlayEvent(radio_str.buff());
			}
			if(radio_item == 2)
			{
				radio_str.contract("go");
				audio_event = FmodSystem::PlayEvent(radio_str.buff());
			}
			if(radio_item == 3)
			{
				radio_str.contract("spread");
				audio_event = FmodSystem::PlayEvent(radio_str.buff());
			}
			if(radio_item == 4)
			{
				radio_str.contract("assemble");
				audio_event = FmodSystem::PlayEvent(radio_str.buff());
			}


		}


	}

	/// ammo launch out
	bool Character::AmmoLaunchOut(by_ptr(AmmoInfo) info, const Core::Vector3 & position, const Core::Vector3 & direction, U16 ammoindex, by_ptr(Character) target, bool isboost)
	{
		Core::Vector3 dir(0, 0, -1);

		dir *= direction;
		bool rtn = false;
		if (action && action->Shoot(dir,isboost))
		{
			SetSelfTransparency(true, equipment_info);

			//reload_State = 0;//shotGun use
			
			shooting = true;

			//�޸����BUG�������ӳٵ����Ȳ���RELOAD�����������ֱ�SHOOT���������ˣ�
			reloading = false;
			
			rtn = gLevel->LaunchAmmo(uid, team, info, position, direction, ammoindex, target, isboost);

			tempc_ptr(WeaponBase) weapon = GetWeapon();
			if (weapon)
			{
				first_person.Shoot(weapon_id, isboost);
				third_person.Shoot(weapon_id, isboost);
			}

			if (this != gLevel->GetPlayer() || gGame->channel_connection->GetState() == ChannelConnection::kInReplay && weapon)
			{
				tempc_ptr(GunBase) gun = ptr_dynamic_cast<GunBase>(weapon);
				if (gun)
				{
					int max_ammo_count = gun->max_ammo_count;
					int max_ammo_one_clip = gun->max_ammo_in_clip;
					if (max_ammo_count > 0 && gun->ammo_in_clip > 0)		
						gun->ammo_in_clip--;
					else if (max_ammo_one_clip > 0 && gun->ammo_in_clip > 0)
						gun->ammo_in_clip--;
				}
			}
		}

		

		return rtn;
	}

	/// shooting
	void Character::Shoot(const Vector3 & dir, bool do_effect, bool isboost)
	{
		if (action && action->Shoot(dir,isboost))
		{
			SetSelfTransparency(true, equipment_info);
			
			shooting = true;
			
			tempc_ptr(WeaponBase) weapon = GetWeapon();
			if (weapon && do_effect)
			{
				if(!reloading && weapon->GetWeaponType() == kWeaponTypeDualPistol)
					dual_pistol_status = !dual_pistol_status;

				if(weapon->GetWeaponType() != kWeaponTypeFlameGun)
				{
					gLevel->GetPlayer()->PlaySoundEffectFromWeapon(GetPosition() + Core::Vector3(0,0.75,0), dir);
				}

				if (weapon->GetWeaponType() == kWeaponTypeShotGun)
				{
					tempc_ptr(GunBase) gun = ptr_dynamic_cast<GunBase>(weapon);

					if (gun)
					{
						first_person.Shoot(weapon_id, isboost);
						third_person.Shoot(weapon_id, isboost);
					}
				}
				else
				{
					first_person.Shoot(weapon_id, isboost);
					third_person.Shoot(weapon_id, isboost);
				}
			}

			if (this != gLevel->GetPlayer() || gGame->channel_connection->GetState() == ChannelConnection::kInReplay && weapon && do_effect)
			{
				tempc_ptr(GunBase) gun = ptr_dynamic_cast<GunBase>(weapon);
				if (gun)
				{
					int max_ammo_count = gun->max_ammo_count;
					int max_ammo_one_clip = gun->max_ammo_in_clip;
					if (max_ammo_count > 0 && gun->ammo_in_clip > 0)		
						gun->ammo_in_clip--;
					else if (max_ammo_one_clip > 0 && gun->ammo_in_clip > 0)
						gun->ammo_in_clip--;
				}
			}
		}
	}

	/// shooting
	void Character::Shoot(const Vector3& pos, const Vector3 & dir, bool do_effect, bool isboost)
	{
		if (action && action->Shoot(pos, dir,isboost))
		{
			SetSelfTransparency(true, equipment_info);
			
			shooting = true;

			tempc_ptr(WeaponBase) weapon = GetWeapon();
			if (weapon && do_effect)
			{
				if(!reloading && weapon->GetWeaponType() == kWeaponTypeDualPistol)
					dual_pistol_status = !dual_pistol_status;
				if(weapon->GetWeaponType() != kWeaponTypeFlameGun)
				{
					PlaySoundEffectFromWeapon(pos,dir);
				}

				if (weapon->GetWeaponType() == kWeaponTypeShotGun)
				{
					tempc_ptr(GunBase) gun = ptr_dynamic_cast<GunBase>(weapon);

					if (gun)
					{
						first_person.Shoot(weapon_id, isboost);
						third_person.Shoot(weapon_id, isboost);
					}
				}
				else
				{
					first_person.Shoot(weapon_id, isboost);
					third_person.Shoot(weapon_id, isboost);
				}
			}
		}
	}

	/// stop shooting
	void Character::StopShoot()
	{
		if (action && action->StopShoot())
		{
			keep_Shoot = false;
			keep_Shoot_fp = false;
			keep_Shoot_mini = false;
			keep_Shoot_mini_tp = false;
			shooting = false;
			first_person.StopShoot();
			third_person.StopShoot();
		}
	}

	/// reload
	void Character::Reload()
	{
		if (action && action->Reload())
		{
			reloading = true;
			first_person.Reload();
			third_person.Reload();
		}
		tempc_ptr(WeaponBase) weapon = GetWeapon();
		if (this != gLevel->GetPlayer() && weapon)
		{
			tempc_ptr(GunBase) gun = ptr_dynamic_cast<GunBase>(weapon);
			if (gun)
			{
				int max_ammo_count = gun->max_ammo_count;
				int max_ammo_one_clip = gun->max_ammo_in_clip;
				if (max_ammo_count > 0)		
				{
					gun->ammo_count = gun->ammo_count - gun->max_ammo_in_clip + gun->ammo_in_clip;
					gun->ammo_in_clip = gun->max_ammo_in_clip;
				}
			}
		}
	}
 
	void Character::PlantBomb()
	{
		if(action && action->PlantBomb())
		{
			first_person.PlantBomb();
			third_person.PlantBomb();
			planting_bomb = true;
		}
	}

	void Character::StopPlantBomb()
	{
		if(action)
		{
			planting_bomb = false;
			tempc_ptr(WeaponBase) w = GetWeapon(true); 
			if(w && w->GetWeaponType() == kWeaponTypeBomb)
			{
				first_person.animation_group->StopAction(true);
			}
			sharedc_ptr(Bomb) bomb = first_person.GetBomb();
			if(bomb)
				bomb->StopPlantBomb();
		}
	}

	/// reload Ready
	void Character::ReloadReady(int count)
	{
		if (action)
			action->ReloadReady(count);
	}

	/// select weapon
	void Character::SelectWeapon(uint id, bool force)
	{
		if(zombie_dying_flag && id != 1)
			return;

		if (!IsDied() && action && !IsLockStateByType(kLSSelectWeapon) && action->SelectWeapon(id, force))
		{
			weapon_select_state = kWeaponChangeIn;

			WeaponInactive(weapon_id);

			select_grenade_mode = false;

			if(weapon_id >= 3 && weapon_id <= 5 && id >=3 && id <= 5 && weapon_id_last != id)
			{
				select_grenade_mode = true;
				grenade_id = weapon_id;
			}

			if (!force  && (weapon_id < 3 || weapon_id > 5 || id < 3 || id > 5))
			{
				if(!skip_grenade)
				{
					weapon_id_last = weapon_id;		
				}
				else
				{
					skip_grenade = false;
					if(grenade_cd_time > 0.1f || weapon_id == 4)
						weapon_id_last = 0;
					else
						weapon_id_last = weapon_id;
				}
			}
	
			
			weapon_id = id;

			WeaponActive(weapon_id);


			first_person.SelectWeapon(weapon_id);
			third_person.SelectWeapon(weapon_id);

			tempc_ptr(WeaponBase) weapon = GetWeapon();
			if (weapon && weapon->weapon_info)
			{
				if (move && GetCurCharinfo())
				{

					SetMoveInfoOffset(weapon->weapon_info->move_speed_offset);
					move->SetRunSpeed(move_info.run_speed + runspeed_offset);
					move->SetHitFactor(weapon->weapon_info->hit_speed, weapon->weapon_info->hit_acceleration, weapon->weapon_info->hit_distance);
				}
			}
			//open display weapon list icon
			if(gGame)
			{
				tempc_ptr(Character) player = gLevel->GetPlayer();
				if(player == this)
				{
					weapon_list_icon_alpha = 1.0f;
					weapon_list_icon_flag = 1;
					weapon_list_icon_waittime = 0.2f;

					player->weapon_current_icon_alpha = 0.0f;
				}
			}
			UpdateRawCharacterChangeableInfo();
			UpdateCurrentCharacterChangeableInfo();
		}
	}

	
	/// weapon active
	void Character::WeaponActive(uint id)
	{
		first_person.WeaponActive(id);
		third_person.WeaponActive(id);
	}

	/// weapon inactive
	void Character::WeaponInactive(uint id)
	{
		first_person.WeaponInactive(id);
		third_person.WeaponInactive(id);
	}


	/// set weapon
	void Character::SetWeapon(int slot, by_ptr(WeaponInfo) info)
	{
		if (action && action->SetWeapon(slot, info))
		{
			current_weaponinfo = info;
			first_person.SetWeapon(slot, info);
			third_person.SetWeapon(slot, info);

			if (slot == weapon_id)
				SelectWeapon(slot, true);
		}
	}

	/// change weapon
	void Character::ChangeWeapon()
	{
		if (weapon_id_last != weapon_id)
		{
			if (this == gLevel->GetPlayer())
			{
				gLevel->isGunSensitivity = false;
			}

			tempc_ptr(WeaponBase) weapon = GetWeaponById(weapon_id_last);

			if (weapon && weapon->CanActive())
			{
			
				if( (weapon->GetWeaponType() == kWeaponTypeGrenade || weapon->GetWeaponType() == kWeaponTypeFlash || weapon->GetWeaponType() == kWeaponTypeSpecial) &&  grenade_cd_time > 0.f )
				{
			
				}
				else
				{
					SelectWeapon(weapon_id_last);
					return;
				}
				
			}
		}

		for (int i = 0; i < 7; ++i)
		{
			if (weapon_id != i)
			{
				tempc_ptr(WeaponBase) weapon = GetWeaponById(i);

				if (weapon && weapon->CanActive())
				{
					SelectWeapon(i);
					break;
				}
			}
		}
	}

	// drop weapon
	void Character::DropWeapon(int slot)
	{
		if (action && action->DropWeapon(slot))
		{
			SetWeapon(slot, NullPtr);

			first_person.DropWeapon(slot);
			third_person.DropWeapon(slot);
		}
	}

	void Character::DropBomb()
	{
		if(HasBomb() && GetBomb(true))
		{
			tempc_ptr(Bomb) bomb = GetBomb(true);
			if(bomb)
			{
				if(bomb->bomb_planting)
					bomb->StopPlantBomb();
	
				gGame->channel_connection->DropWeapon();	
				ChangeWeapon();
				SetHasBomb(false);		
			}
		}
	}

	// pick up weapon
	void Character::PickUpWeapon(int slot, by_ptr(WeaponInfo) info)
	{
		SetWeapon(slot, info);

		if (slot == 0)
			SelectWeapon(slot);

		first_person.PickUpWeapon(slot, info);
		third_person.PickUpWeapon(slot, info);
	}

	/// create weapon
	sharedc_ptr(WeaponBase) Character::CreateWeapon(by_ptr(WeaponInfo) info)
	{
		sharedc_ptr(WeaponBase) weapon;

		if (info)
		{
			switch (info->weapon_type)
			{
			case kWeaponTypeRifle:				weapon = ptr_new RifleGun(ptr_static_cast<RifleInfo>(info));				break;
			case kWeaponTypeSubMachineGun:		weapon = ptr_new SubMachineGun(ptr_static_cast<SubMachineGunInfo>(info));	break;
			
			case kWeaponTypePistol:				weapon = ptr_new Pistol(ptr_static_cast<PistolInfo>(info));					break;
			case kWeaponTypeKnife:				weapon = ptr_new Knife(ptr_static_cast<KnifeInfo>(info));					break;
			case kWeaponTypeGrenade:			weapon = ptr_new Grenade(ptr_static_cast<GrenadeInfo>(info));				break;
			case kWeaponTypeFlash:				weapon = ptr_new Grenade(ptr_static_cast<FlashInfo>(info));					break;
			case kWeaponTypeSmoke:				weapon = ptr_new Grenade(ptr_static_cast<SmokeInfo>(info));					break;
			case kWeaponTypeSpecial:			weapon = ptr_new Grenade(ptr_static_cast<SpecialGrenadeInfo>(info));		break;
			case kWeaponTypeSniperGun:			weapon = ptr_new SniperGun(ptr_static_cast<SniperGunInfo>(info));			break;
			case kWeaponTypeShotGun:			weapon = ptr_new ShotGun(ptr_static_cast<ShotGunInfo>(info));				break;
			case kWeaponTypeBomb:				weapon = ptr_new Bomb(ptr_static_cast<BombInfo>(info));						break;
			case kWeaponTypeDualPistol:			weapon = ptr_new DualPistol(ptr_static_cast<DualPistolInfo>(info));			break;
			case kWeaponTypeMiniGun:			weapon = ptr_new MiniGun(ptr_static_cast<MiniGunInfo>(info));				break;
			case kWeaponTypeMeditNeedleGun:
			case kWeaponTypeSignal:
			case kWeaponTypeLuncher:			weapon = ptr_new Luncher(ptr_static_cast<LuncherInfo>(info));				break;
			case kWeaponTypeMiniMachineGun:		weapon = ptr_new MiniMachineGun(ptr_static_cast<MiniMachineGunInfo>(info));	break;
			case kWeaponTypeCureGun:			weapon = ptr_new CureGun(ptr_static_cast<CureGunInfo>(info));				break;
			//case kWeaponTypeBow:				weapon = ptr_new Bow(ptr_static_cast<BowInfo>(info));						break;
			case kWeaponTypeFlameGun:			weapon = ptr_new FlameGun(ptr_static_cast<FlameGunInfo>(info));				break;
			case kWeaponTypeDrum:				weapon = ptr_new Drum(ptr_static_cast<DrumInfo>(info));						break;
			case kWeaponTypeMilkbottle:			weapon = ptr_new Milkbottle(ptr_static_cast<MilkbottleInfo>(info));			break;	
			case kWeaponTypeEquipment:			weapon = ptr_new Equipment(ptr_static_cast<EquipmentInfo>(info));			break;	
			case kWeaponTypeZombieGun:			weapon = ptr_new ZombieGun(ptr_static_cast<ZombieGunInfo>(info));			break;
			case kWeaponTypeZombieCharge:		weapon = ptr_new ZombieCharge(ptr_static_cast<ZombieChargeInfo>(info));		break;

			case kWeaponTypeGunTowerBuilder:	weapon = ptr_new GunTowerBuilder(ptr_static_cast<GunTowerBuilderInfo>(info));	break;
			case kWeaponTypeGunTowerBuilderPlus: weapon = ptr_new GunTowerBuilderPlus(ptr_static_cast<GunTowerBuilderPlusInfo>(info));	break;
			}
		}

		return weapon;
	}

	/// has bomb
	bool Character::HasBomb()
	{
		return has_bomb;
		//return first_person.HasBomb();
	}

	void Character::SetHasBomb(bool flag)
	{
		has_bomb = flag;
	}
	void Character::SetDieBuffer(bool bNeed)
	{
		die_buff =bNeed;
	}
	void Character::SetDieBufferCounter(int iCounter)
	{
		die_buff_counter =iCounter;
	}

	int Character::GetRandingDieBuff()
	{
		return die_buff_randing ? die_buff_rand_start : -1;
	}
	int Character::GetStayDieBuff()
	{
		return die_buff_staying ? die_buff_rand_start : -1;
	}
	int Character::GetDieBuffTotalCount()
	{
		return die_buff_total_count;
	}
	int Character::GetDieBuffCounter()
	{
		return die_buff_counter;
	}
	float Character::GetDieBuffGapTimer()
	{
		return die_buff_rand_gap_timer;
	}
	float Character::GetDieBuffStayTimer()
	{
		return die_buff_stay_timer;
	}
	bool Character::IsDieBuffAffecting()
	{
		return die_buff_affecting;
	}
	float Character::GetDieBuffAffectTimer()
	{
		return die_buff_affect_timer;
	}
	int Character::GetDieBuffAffect()
	{
		return die_buff_affect;
	}
	void Character::UpdateDieBuff(float fFT)
	{
		if(die_buff_total_count <= 0)return;
		if(die_buff)
		{
			die_buff =false;
			die_buff_rand_gap_timer =DIE_BUFF_RAND_GAP_TIME;
			die_buff_rand_timer =DIE_BUFF_RAND_TIME;
			die_buff_randing =true;
			die_buff_staying =false;
			die_buff_affecting =false;
			die_buff_affect =-1;
			die_buff_rand_start =rand() % die_buff_total_count;
		}

		if(die_buff_randing)
		{
			die_buff_rand_gap_timer -=fFT;
			if(die_buff_rand_gap_timer<=0)
			{
				die_buff_rand_start +=1;
				die_buff_rand_start =die_buff_rand_start % die_buff_total_count;
				die_buff_rand_gap_timer =DIE_BUFF_RAND_GAP_TIME;
			}

			die_buff_rand_timer -=fFT;
			if(die_buff_rand_timer <= 0)
			{
				die_buff_rand_start =(die_buff_rand_start + 2) % die_buff_total_count;
				srand((uint)Core::Task::GetTotalTime() );
				int rate = rand()%100;
				int tmp = 0;
				for(int i=0; i<die_buff_total_count; ++i)
				{
					if (tmp < gLevel->die_buff_data[i].rate && rate <= gLevel->die_buff_data[i].rate)
					{
						die_buff_rand_start = i;
						break;
					}
					tmp = gLevel->die_buff_data[i].rate;
				}
				die_buff_randing =false;
				die_buff_staying =true;
				die_buff_stay_timer =DIE_BUFF_STAY_TIME;
			}
		}
		else if(die_buff_staying)
		{
			die_buff_stay_timer -=fFT;
			if(die_buff_stay_timer <= 0)
			{
				die_buff_affect =die_buff_rand_start;
				gGame->channel_connection->NeedDieBuff(die_buff_rand_start);
				die_buff_rand_start =-1;
				die_buff_staying =false;

				die_buff_affecting =true;
				die_buff_affect_timer =gLevel->die_buff_data[die_buff_affect].duration_timer;
			}
		}
		else if(die_buff_affecting)
		{
			die_buff_affect_timer -=fFT;
			if(die_buff_affect_timer<=0)
			{
				die_buff_affecting =false;
				die_buff_affect =-1;
			}
		}
	}

	sharedc_ptr(Bomb) Character::GetBomb(bool force_first_person)
	{
		if(force_first_person)
		{
			sharedc_ptr(Bomb) bomb = first_person.GetBomb();
			return bomb;
		}
		else
		{
			sharedc_ptr(WeaponBase) weapon = GetWeaponById(BOMB_SLOT,force_first_person);
			return ptr_dynamic_cast<Bomb>(weapon);
		}
		return NullPtr;
		
	}

	/// preload animation
	void Character::PreloadWeapon(by_ptr(WeaponInfo) info)
	{
		first_person.PreloadAnimation(info);
		third_person.PreloadAnimation(info);
	}

	/// preload animation
	void Character::PreloadPack(const PackInfo & info)
	{
		for (uint i = 0; i < info.weapon_set.Size(); ++i)
		{
			PreloadWeapon(info.weapon_set[i]);
		}
	}

	/// recover
	void Character::Recover(int health,byte recover_type)
	{

		int prohp = hp;
		hp = health;

		last_hp = hp;
		if(prohp != health)
		{
			first_person.Recover(health,recover_type);
			third_person.Recover(health,recover_type);
		}
	}


	void Character::AmmoRecover(short ammocount,byte recovertype)
	{
		first_person.AmmoRecover(ammocount,recovertype);
		third_person.AmmoRecover(ammocount,recovertype);
	}
	/// recover stop
	void Character::RecoverStop()
	{
		first_person.RecoverStop();
		third_person.RecoverStop();
	}

	/// burn
	void Character::Burn()
	{
		sustainflame_time = 1.5f;
		first_person.Burn();
		third_person.Burn();
	}

	/// burn stop
	void Character::BurnStop()
	{
		sustainflame_time = 0.f;
		special_mode = kSpStateNone;
		first_person.BurnStop();
		third_person.BurnStop();
	}

	void Character::Poison()
	{
		poison_time = 1.5f;
		first_person.Poison();
		third_person.Poison();
	}

	void Character::PoisonStop()
	{
		poison_time = 0.f;
		special_mode = kSpStateNone;
		first_person.PoisonStop();
		third_person.PoisonStop();
	}

	/// set physx control
	void Character::SetPhysxControl(bool flag)
	{
		physx_control = flag;
		third_person.SetPhysxControl(flag);
	}

	/// get physx control
	bool Character::GetPhysxControl()
	{
		return physx_control;
	}

	/// set physx group
	void Character::SetPhysxGroup(uint id)
	{
		if (id != physx_group)
		{
			physx_group = id;
			third_person.SetPhysxGroup(id);
		}
	}
	
	/// get physx group
	int Character::GetPhysxGroup()
	{
		return physx_group;
	}

	/// get actor id
	int Character::GetActorId(const Identifier & name)
	{
		return third_person.GetActorId(name);
	}
	
	/// get actor id
	int Character::GetActorId(NxActor* pActor)
	{
		return third_person.GetActorId(pActor);
	}

	uint Character::GetJointIdFromActorId(uint id)
	{
		return third_person.GetJointIdFromActorId(id);
	}

	/// get damage part
	int Character::GetDamagePart(int part1, int part2)
	{
		return third_person.GetDamagePart(part1, part2);
	}

	/// check grenade
	bool Character::CheckGrenade(const Core::Vector3 & pos, float & distance)
	{
		return third_person.CheckGrenade(pos, distance);
	}

	/// check grenade2
	bool Character::CheckGrenade2(const Core::Vector3 & pos, float & distance)
	{
		return third_person.CheckGrenade2(pos, distance);
	}

	/// check flash
	bool Character::CheckFlash(const Core::Vector3 & pos, float & distance, bool & back_bright)
	{
		return third_person.CheckFlash(pos, distance, back_bright);
	}

	/// flash bright
	void Character::FlashBright(float bright_time, float fade_time)
	{
		if (bright_time > 0)
			flash_bright_time = bright_time;

		flash_fade_time = Max(Min(flash_fade_time, fade_time), 1.f);
	}

	/// use skill request
	void Character::UseSkillRequest()
	{
		//if (action)
		//	action->UseSkillRequest();
	}

	/// use skill
	void Character::UseSkill()
	{
	
	}

	/// use skill stop
	void Character::UseSkillStop()
	{
		
	}
	
	sharedc_ptr(CharacterInfo) Character::GetCurCharinfo()
	{
		return character_info;
	}

	/// get name
	Core::String Character::GetName()
	{
		if (basecharacter_info)
			return basecharacter_info->name;
		else
			return Core::String::kEmpty;
	}

	/// from nx actor
	tempc_ptr(Character) Character::FromNxActor(NxActor & actor)
	{
		if(actor.userData)
		{
			//temp hack
			Object * obj = (Object*)actor.userData;

			if (obj)
			{
				return ptr_dynamic_cast<Character>(obj);
			}

		}

		return NullPtr;
	}

	void Character::SetTransparency(TransparencyKind v)
	{
		/*transparency = v;

		transparency_value = 1.0f;*/
	}
	
	void Character::SetCareer(int career, sharedc_ptr(CharacterInfo) info)
	{
		if (info)
		{
			if (basecharacter_info)
			{
				info->name = basecharacter_info->name;
				info->team = team;
			}
			info->LoadPart();
			/*sharedc_ptr(CharacterInfo) cache_info = cache_character_info.Get(info->career_id, NullPtr);
			if (!cache_info)
			{
				if (basecharacter_info)
				{
					info->name = basecharacter_info->name;
					info->team = team;
				}

				info->LoadPart();

				cache_character_info.Set(info->career_id, info);
			}
			else
			{
				info = cache_info;
			}*/
		}

		current_career = career;
		SetCharacterInfo(info);

		weapon_id = -1;
		ping = 0;
	}

	void Character::ClearCareerCache()
	{
		cache_character_info.Clear();
	}

	void Character::CallMedic()
	{
		if (call_magic_timer <= 0)
		{
			if (character_info)
			{
				String str = String::Format("bj/player/2d/%s/medic",character_info->res_key);
				FmodSystem::PlayEvent(str.Str());
			}
			gGame->channel_connection->CallDoctor();
			call_magic_timer = 10.f;
		}
	}

	void Character::BoostSound()
	{
		if (call_magic_timer <= 0)
		{
			if (character_info)
			{
				String str = String::Format("bj/player/2d/burst_voice/%s",character_info->res_key);
				FmodSystem::PlayEvent(str.Str());
			}
		}
	}
	void Character::Boost_3D_Sound()
	{
		if (call_magic_timer <= 0)
		{
			if (character_info)
			{
				String str = String::Format("bj/player/3d/burst_voice/%s",character_info->res_key);
				FmodSystem::PlayEvent(str.Str());
			}
		}
	}


	// show bill board
	void Character::ShowBillBoard(float time)
	{
		third_person.billboard_timer = time;
	}

	// show bill board
	void Character::ShowItemModeHead(float time)
	{
		third_person.itemmode_timer = time;
	}

	void Character::PreloadSkeleton()
	{
		first_person.LoadSkeleton();
		third_person.LoadSkeleton();
	}
#if DEBUG_TOOLS
	void Character::JumpByViewer()
	{
		if (move)
			move->JumpByViewer();
	}

	void Character::SelectWeaponForViewer(uint id, by_ptr(WeaponInfo) info, bool force, bool isthird)
	{
		if (action && action->SetWeapon(id, info))
		{
			if(!isthird)
				first_person.SetWeapon(id, info);
			third_person.SetWeapon(id, info);
		}

		weapon_select_state = kWeaponChangeIn;

		WeaponInactive(weapon_id);

		select_grenade_mode = false;

		if(weapon_id >= 3 && weapon_id <= 5 && id >=3 && id <= 5 && weapon_id_last != id)
		{
			select_grenade_mode = true;
			grenade_id = weapon_id;
		}

		if (!force  && (weapon_id < 3 || weapon_id > 5 || id < 3 || id > 5))
			weapon_id_last = weapon_id;			
		
		weapon_id = id;

		WeaponActive(weapon_id);
		if(!isthird)
			first_person.SelectWeapon(weapon_id);
		third_person.SelectWeapon(weapon_id);

		tempc_ptr(WeaponBase) weapon = GetWeapon();
		if (weapon && weapon->weapon_info)
		{
			if (move && GetCurCharinfo())
			{
				//delete this call
				//move->SetRunSpeed(move_info.run_speed + weapon->weapon_info->move_speed_offset);
				move->SetHitFactor(weapon->weapon_info->hit_speed, weapon->weapon_info->hit_acceleration, weapon->weapon_info->hit_distance);
			}
		}
		//open display weapon list icon
		if(gGame)
		{
			tempc_ptr(Character) player = gLevel->GetPlayer();
			if(player == this)
			{
				weapon_list_icon_alpha = 1.0f;
				weapon_list_icon_flag = 1;
				weapon_list_icon_waittime = 0.2f;

				player->weapon_current_icon_alpha = 0.0f;
			}
		}
	}

	void Character::UpdateModelViewer(float frame_time)
	{
		if (move)
			move->UpdateForViewer(frame_time);
		// update person
		if (view_mode == kFirstPerson)
			first_person.UpdateAnimationFirstPersonForViewer(frame_time);
		else
			third_person.UpdateAnimationThirdPersonForViewer(frame_time);
	}
#endif

	void Character::LockStateByType(byte state_type)
	{
		if ((lock_state_type & (1 << state_type)) == 0)
		{
			lock_state_type |= (1 << state_type);
		}
	}
	void Character::UnLockStateByType(byte state_type)
	{
		lock_state_type &= ~(1 << state_type);
	}

	void Character::ClearLockState()
	{
		lock_state_type = 0;
	}

	bool Character::IsLockStateByType(byte state_type)
	{
		return (lock_state_type & (1 << state_type)) != 0;
	}

	void Character::UpdateZombieDyingCamera(float delta)
	{
		zombie_dying_timer += delta;
	}

	void Character::ClearZombieDyingCamera()
	{
		zombie_dying_timer = 0.f;
	}

	//////////////////////////////////////////////////////////////////////////////
	void Character::SetClientSynScriptStringValue(const String &key, const String &value)
	{
		if (GetClientSynScriptStringValue(key) != value)
		{
			m_ClientSynScriptStringValue.Set(key, value);

			if (!m_ClientSynScriptStringValueDirty.Contains(key))
			{
				m_ClientSynScriptStringValueDirty.PushBack(key);
			}
		}
	}

	String Character::GetClientSynScriptStringValue(const String &key)
	{
		return m_ClientSynScriptStringValue.Get(key, String::kEmpty);
	}

	bool Character::HasClientSynScriptStringValue(const Core::String &key)
	{
		return m_ClientSynScriptStringValue.Contains(key);
	}

	void Character::SetClientSynScriptNumberValue(const String &key, float value)
	{
		if (GetClientSynScriptNumberValue(key) != value)
		{
			m_ClientSynScriptNumberValue.Set(key, value);

			if (!m_ClientSynScriptNumberValueDirty.Contains(key))
			{
				m_ClientSynScriptNumberValueDirty.PushBack(key);
			}
		}
	}

	float Character::GetClientSynScriptNumberValue(const String &key)
	{
		return m_ClientSynScriptNumberValue.Get(key, 0);
	}

	bool Character::HasClientSynScriptNumberValue(const Core::String &key)
	{
		return m_ClientSynScriptNumberValue.Contains(key);
	}

	void Character::ClearClientSynScriptValue()
	{
		m_ClientSynScriptStringValue.Clear();
		m_ClientSynScriptStringValueDirty.Clear();

		m_ClientSynScriptNumberValue.Clear();
		m_ClientSynScriptNumberValueDirty.Clear();
	}

	bool Character::CanControl()
	{
		if (gLevel && gLevel->GetPlayer())
			return control_uid == gLevel->GetPlayer()->uid;

		return false;
	}

	void Character::PlayCharacterParticle(const Core::Identifier & joint, const Core::Identifier & value, float time)
	{
		sharedc_ptr(CharacterParticle) dp = ptr_new CharacterParticle();
		dp->ps = ptr_new ParticleSystem(value, false);
		dp->ps->SetEnable(true);
		dp->joint = joint;
		dp->totle_time = time;
		dp->timer = 0;
		character_particles.PushBack(dp);
	}

	void Character::CleanAllCharacterParticle()
	{
		character_particles.Clear();
	}

	void Character::PlayItemModeParticle(const Core::Identifier & value, float time)
	{
		sharedc_ptr(CharacterParticle) dp = ptr_new CharacterParticle();
		dp->ps = ptr_new ParticleSystem(value, false);
		dp->ps->SetEnable(true);
		dp->totle_time = time;
		dp->timer = 0;
		item_mode_particles.PushBack(dp);
	}

	void Character::CleanAllItemModeParticle()
	{
		item_mode_particles.Clear();
	}

	void Character::PlayItemModeBuffTime(int slot, float time)
	{
		bool flag = false;
		for(int i = 0; i < (int)item_mode_buff_time.Size();++i)
		{
			if (item_mode_buff_time[i]->slot == slot)
			{
				item_mode_buff_time[i]->totle_time = time;
				flag = true;
			}
		}
		if (!flag)
		{
			sharedc_ptr(ItemParticleTime) dp = ptr_new ItemParticleTime();
			dp->slot = slot;
			dp->totle_time = time;
			item_mode_buff_time.PushBack(dp);
		}
	}

	void Character::CleanAllItemModeBuffTime()
	{
		item_mode_buff_time.Clear();
	}

	void Character::PlayItemModeDebuffTime(int slot, float time)
	{
		bool flag = false;
		for(int i = 0; i < (int)item_mode_debuff_time.Size();++i)
		{
			if (item_mode_debuff_time[i]->slot == slot)
			{
				item_mode_debuff_time[i]->totle_time = time;
				flag = true;
			}
		}
		if (!flag)
		{
			sharedc_ptr(ItemParticleTime) dp = ptr_new ItemParticleTime();
			dp->slot = slot;
			dp->totle_time = time;
			item_mode_debuff_time.PushBack(dp);
		}
	}

	void Character::CleanAllItemModeDebuffTime()
	{
		item_mode_debuff_time.Clear();
	}

	void Character::PveClientPlayAction(const Core::String &ani_key)
	{
		const ThirdPerson & third_person = GetThirdPerson();
		third_person.node_group->PlayAction("bosspve", ani_key);
	}

	void Character::PveClientStopAction()
	{
		const ThirdPerson & third_person = GetThirdPerson();
		if (third_person.node_group->IsNowNode("bosspve"))
			third_person.node_group->StopAction();
	}

	void Character::SetBossPVEAction(bool isnew)
	{
		isnew_action = isnew;
	}

	bool Character::GetBossPVEAction()
	{
		return isnew_action;
	}

	void Character::PveClientPlaySound(const Core::String sound_key, bool is3dsound)
	{
		if (is3dsound)
		{
			if (!boss_pve_3d)
			{
				FMOD_VECTOR vel = {0, 0, 0};
				boss_pve_str_3d = sound_key;
				boss_pve_3d = FmodSystem::Play3DEvent(boss_pve_str_3d.Str(),(const FMOD_VECTOR &)GetPosition(),vel);
			}
			else if (boss_pve_str_3d != sound_key)
			{
				FMOD_VECTOR vel = {0, 0, 0};
				boss_pve_str_3d = sound_key;
				boss_pve_3d->stop();
				boss_pve_3d = FmodSystem::Play3DEvent(boss_pve_str_3d.Str(),(const FMOD_VECTOR &)GetPosition(),vel);
			}
			else if (boss_pve_3d)
			{
				FMOD_VECTOR vel = {0, 0, 0};
				FmodSystem::Update3DEventPosition(boss_pve_3d,(const FMOD_VECTOR &)GetPosition(),vel);
			}
		}
		else
		{
			if (!boss_pve)
			{
				boss_pve_str = sound_key;
				boss_pve = FmodSystem::PlayEvent(boss_pve_str.Str());
			}
			else if (boss_pve_str != sound_key)
			{
				boss_pve_str = sound_key;
				boss_pve->stop();
				boss_pve = FmodSystem::PlayEvent(boss_pve_str.Str());
			}
		}
	}

	bool Character::CheckCanHit(const Core::Vector3 &pos, float max_distance)
	{
		float distance = 0;
		bool ret = false;

		ret = CheckGrenade(pos, distance);
		if (ret && distance <= max_distance)
			return true;

		return false;
	}

	tempc_ptr(IBarbette) Character::GetBarbetteByName(const Core::String &name)
	{
		return barbette_set.Get(name, NullPtr);
	}

	void Character::LaunchPVEAmmo(by_ptr(PVEAmmo) pve_ammo)
	{
		if (pve_ammo && !m_PVEAmmoSet.Contains(pve_ammo->GetId()))
		{
			m_PVEAmmoSet.Set(pve_ammo->GetId(), pve_ammo);

			if (gGame->channel_connection)
				gGame->channel_connection->PVEAmmoOut(uid, pve_ammo);
		}
	}

	void Character::AddPVEAmmoLaser(by_ptr(PVEAmmoLaser) pve_ammolaser)
	{
		if (pve_ammolaser && !m_PVEAmmoLaserSet.Contains(pve_ammolaser->GetId()))
		{
			m_PVEAmmoLaserSet.Set(pve_ammolaser->GetId(),pve_ammolaser);
		}
	}

	U16 Character::GenPVEAmmoId()
	{
		return m_PVEAmmoIdBuilder++;
	}

	bool Character::IsBossMode2()
	{
		if (gLevel->game_type == RoomOption::kBossMode2)
		{
			if (is_boss && boss2_head_damage_timer > 0.001f)
				return false;

			if (GetWeapon() == GetWeaponById(1) && GetTeam() == 1)
			{
				if (boss2_special_weapon_energy >= 500.f)
					return true;
				else
					return false;
			}
			else
				return true;
		}
		else
			return true;
	}

	InGameItemInfo* Character::GetBagItem(uint sid)
	{
		 return basecharacter_info->bag.Get(sid);
	}

	InGameItemInfo* Character::GetBagItemByIID(uint iid)
	{
		ItemBag::Enumerator iter(basecharacter_info->bag);
		while(iter.MoveNext() )
		{
			if (iid == iter.Value().functionID)
				return const_cast<InGameItemInfo*>(&iter.Value());
		}

		return NULL;
	}

	ItemBag& Character::GetBag()
	{
		return basecharacter_info->bag;
	}

	bool Character::ItemIsCDTime(const InGameItemInfo* item_info, double now_time)
	{
		return (now_time - item_info->interval_timer) < item_info->CDTime;
	}

	bool Character::ItemIsRedBottle(const InGameItemInfo* item_info)
	{
		if (NULL == item_info)
			return false;

		if (6 == item_info->subType && ITEM_REDBOTTLE == item_info->functionID)
			return true;

		return false;
	}

	bool Character::ItemIsAmmo(const InGameItemInfo* item_info)
	{
		if (NULL == item_info)
			return false;

		if (6 == item_info->subType && ITEM_AMMO == item_info->functionID)
			return true;

		return false;
	}

	bool Character::ItemIsCarrier(const InGameItemInfo* item_info)
	{
		if (NULL == item_info)
			return false;

		if (3 == item_info->subType && ITEM_CARRIER == item_info->functionID)
			return true;

		return false;
	}

	bool Character::ItemIsBuffer(const InGameItemInfo* item_info, int buff_type)
	{
		if (NULL == item_info)
			return false;

		if (6 == item_info->subType && buff_type == item_info->functionID)
			return true;

		return false;
	}

	bool Character::IsCarrierMode()
	{
		if (RoomOption::kTDMode==gLevel->game_type && character_info && false==character_info->can_select)
			return true;

		return false;
	}
	//////////////////////////////////////////////////////////////////////////////
	void Character::SetSelfTransparency(bool on, by_ptr(WeaponInfo) weapon_info)
	{
		if (on == true && weapon_info)
		{
			Attribute attrinfo;
			if (weapon_info->CheckWeaponAttribute(kWeaponAttr_Self_Transparency, attrinfo))		
			{
				is_move_transparency = true;
				move_transparency_timer = attrinfo.time;
				move_transparency_min_value = attrinfo.value1 / 100.f;
				move_transparency_speed = attrinfo.value2 / 100.f;

				return;
			}
		}
		
		is_move_transparency = false;
		move_transparency_timer = 0.f;
		move_transparency_min_value = 0.f;
		move_transparency_speed = 0.f;
	}

	void Character::RevertToRawCharacterChangeableInfo()
	{
		if(character_changeable_raw_info.run_speed <= EPSILON)
			return;

		move_info.run_speed = character_changeable_raw_info.run_speed;
		move_info.crouch_speed = character_changeable_raw_info.crouch_speed;

		//max_hp = character_changeable_raw_info.max_hp;
		
		//fp
		{
			tempc_ptr(WeaponBase) weapon = GetWeapon(true);
			if(weapon)
			{
				weapon->weapon_info->change_in_time = character_changeable_raw_info.change_in_time;

				tempc_ptr(PlayerAction) p = ptr_dynamic_cast<PlayerAction>(action);
				if(p)
				{
					p->change_in_time = weapon->weapon_info->change_in_time;
				}
			}

			tempc_ptr(GunBase) gun = ptr_dynamic_cast<GunBase>(weapon);
			if(gun)
			{
				if(character_changeable_raw_info.ammo_one_clip > 0)
				{
					gun->gun_info->ammo_one_clip =	character_changeable_raw_info.ammo_one_clip;
					gun->max_ammo_in_clip = character_changeable_raw_info.ammo_one_clip;
				}
				if(character_changeable_raw_info.max_ammo_count > 0)
				{
					gun->gun_info->ammo_count = character_changeable_raw_info.max_ammo_count;
					gun->max_ammo_count = character_changeable_raw_info.max_ammo_count;
				}
				if(character_changeable_raw_info.fire_time > 0)
				{
					gun->gun_info->fire_time = character_changeable_raw_info.fire_time;
				}
				if(character_changeable_raw_info.reload_time > 0)
				{
					gun->gun_info->reload_time = character_changeable_raw_info.reload_time;
				}
			}


			tempc_ptr(Luncher) luncher = ptr_dynamic_cast<Luncher>(gun);
			if(luncher)
			{
				if(character_changeable_raw_info.ammo_fly_speed > 0)
				{
					luncher->luncher_info->fly_speed = character_changeable_raw_info.ammo_fly_speed;
				}
				if(character_changeable_raw_info.ammo_explode_range > 0)
				{
					luncher->luncher_info->range = character_changeable_raw_info.ammo_explode_range;
				}
			
			}
		}
		
		//tp
		{
			tempc_ptr(WeaponBase) weapon = GetThirdPresonWeapon();
			if(weapon)
			{
				weapon->weapon_info->change_in_time = character_changeable_raw_info.change_in_time;
			}

			tempc_ptr(GunBase) gun = ptr_dynamic_cast<GunBase>(weapon);
			if(gun)
			{
				if(character_changeable_raw_info.ammo_one_clip > 0)
				{
					gun->gun_info->ammo_one_clip =	character_changeable_raw_info.ammo_one_clip;
					gun->max_ammo_in_clip = character_changeable_raw_info.ammo_one_clip;
				}
				if(character_changeable_raw_info.max_ammo_count > 0)
				{
					gun->gun_info->ammo_count = character_changeable_raw_info.max_ammo_count;
					gun->max_ammo_count = character_changeable_raw_info.max_ammo_count;
				}
				if(character_changeable_raw_info.fire_time > 0)
				{
					gun->gun_info->fire_time = character_changeable_raw_info.fire_time;
				}
				if(character_changeable_raw_info.reload_time > 0)
				{
					gun->gun_info->reload_time = character_changeable_raw_info.reload_time;
				}
			}


			tempc_ptr(Luncher) luncher = ptr_dynamic_cast<Luncher>(gun);
			if(luncher)
			{
				if(character_changeable_raw_info.ammo_fly_speed > 0)
				{
					luncher->luncher_info->fly_speed = character_changeable_raw_info.ammo_fly_speed;
				}
				if(character_changeable_raw_info.ammo_explode_range > 0)
				{
					luncher->luncher_info->range = character_changeable_raw_info.ammo_explode_range;
				}

			}
		}
	}

	void Character::UpdateRawCharacterChangeableInfo()
	{
		character_changeable_raw_info.run_speed = move_info.run_speed;
		character_changeable_raw_info.crouch_speed = move_info.crouch_speed;

		//character_changeable_raw_info.max_hp = max_hp;
		tempc_ptr(WeaponBase) weapon = GetWeapon();
		if(weapon)
		{
			character_changeable_raw_info.change_in_time = weapon->weapon_info->change_in_time;
		}
		else
		{
			character_changeable_raw_info.change_in_time = -1;
		}

		tempc_ptr(GunBase) gun = ptr_dynamic_cast<GunBase>(weapon);
		if(gun)
		{
			character_changeable_raw_info.ammo_one_clip = gun->gun_info->ammo_one_clip;
			character_changeable_raw_info.max_ammo_count = gun->max_ammo_count;
			character_changeable_raw_info.fire_time = gun->gun_info->fire_time;
			character_changeable_raw_info.reload_time = gun->gun_info->reload_time;
		}
		else
		{
			character_changeable_raw_info.ammo_one_clip = -1;
			character_changeable_raw_info.max_ammo_count = -1;
			character_changeable_raw_info.fire_time = -1.f;
			character_changeable_raw_info.reload_time = -1.f;
		}

		tempc_ptr(Luncher) luncher = ptr_dynamic_cast<Luncher>(gun);
		if(luncher)
		{
			character_changeable_raw_info.ammo_fly_speed = luncher->luncher_info->fly_speed;
			character_changeable_raw_info.ammo_explode_range = luncher->luncher_info->range;
		}
		else
		{
			character_changeable_raw_info.ammo_fly_speed = -1.f;
			character_changeable_raw_info.ammo_explode_range = -1.f;
		}
	}

	void Character::UpdateCurrentCharacterChangeableInfo()
	{
		float p = 0.f;
		
		p = GetTotalAttributeByType(kEffect_Infect_MoveSpeed);
		move_info.run_speed = character_changeable_raw_info.run_speed * p;
		move_info.crouch_speed = character_changeable_raw_info.crouch_speed * p;
		
		character_changeable_current_info.run_speed = move_info.run_speed;
		character_changeable_current_info.crouch_speed = move_info.crouch_speed;

		// hp
		//p = GetTotalAttributeByType(kEffect_Infect_MaxHp);
		//max_hp = character_changeable_raw_info.max_hp * p;

		//character_changeable_current_info.max_hp = max_hp;

		tempc_ptr(WeaponBase) weapon = GetWeapon(true);
		if(weapon)
		{
			if(character_changeable_raw_info.change_in_time > 0.f)
			{
				p = GetTotalAttributeByType(kEffect_Infect_ChangeInTime);
				p = Max(p,0.f);
				weapon->weapon_info->change_in_time = character_changeable_raw_info.change_in_time * p;
				
				character_changeable_current_info.change_in_time = weapon->weapon_info->change_in_time;
				
				tempc_ptr(PlayerAction) p = ptr_dynamic_cast<PlayerAction>(action);
				if(p && weapon_select_state == Character::kWeaponReady)
				{
					p->change_in_time = weapon->weapon_info->change_in_time;
				}

				
			}

		}
		else
		{
			character_changeable_current_info.change_in_time = -1.f;
		}

		tempc_ptr(GunBase) gun = ptr_dynamic_cast<GunBase>(weapon);
		if(gun)
		{
			if(character_changeable_raw_info.ammo_one_clip > 0)
			{
				//if(!gun->is_weapon_updated)
				{
					p = GetTotalAttributeByType(kEffect_Infect_AmmoOneClip);

					bool flag = (gun->gun_info->ammo_one_clip == gun->ammo_in_clip);

					gun->gun_info->ammo_one_clip =	character_changeable_raw_info.ammo_one_clip * p;
					gun->max_ammo_in_clip = character_changeable_raw_info.ammo_one_clip * p;

					if(gun->gun_info->ammo_one_clip != gun->ammo_in_clip && flag)
					{
						gun->ammo_in_clip = gun->gun_info->ammo_one_clip;
					}
				}
				character_changeable_current_info.ammo_one_clip = gun->ammo_in_clip;
			}

			if(character_changeable_raw_info.max_ammo_count > 0)
			{
				//if(!gun->is_weapon_updated)
				{
					p = GetTotalAttributeByType(kEffect_Infect_AmmoCount);

					bool flag = (gun->ammo_count == gun->max_ammo_count);

					gun->max_ammo_count = character_changeable_raw_info.max_ammo_count * p;
					gun->gun_info->ammo_count = gun->max_ammo_count;
					if(gun->ammo_count != gun->max_ammo_count && flag)
					{
						gun->ammo_count = gun->max_ammo_count;
					}
				}
				character_changeable_current_info.max_ammo_count = gun->max_ammo_count;
			}

			if(character_changeable_raw_info.fire_time > 0)
			{
				p = GetTotalAttributeByType(kEffect_Infect_FireTime);
				p = Max(p,0.f);
				gun->gun_info->fire_time = character_changeable_raw_info.fire_time * p;

				character_changeable_current_info.fire_time = gun->gun_info->fire_time;
			}

			if(character_changeable_raw_info.reload_time > 0)
			{
				p = GetTotalAttributeByType(kEffect_Infect_ReloadTime);
				p = Max(p,0.f);
				gun->gun_info->reload_time = character_changeable_raw_info.reload_time * p;

				character_changeable_current_info.reload_time = gun->gun_info->reload_time;
			}
		}
		else
		{
			character_changeable_current_info.ammo_one_clip = -1;
			character_changeable_current_info.max_ammo_count = -1;
			character_changeable_current_info.fire_time = -1.f;
			character_changeable_current_info.reload_time = -1.f;
		}

		tempc_ptr(Luncher) luncher = ptr_dynamic_cast<Luncher>(gun);
		if(luncher)
		{
			if(character_changeable_raw_info.ammo_fly_speed > 0.f)
			{
				p = GetTotalAttributeByType(kEffect_Infect_AmmoFlySpeed);
				p = Max(p,0.f);
				luncher->luncher_info->fly_speed = character_changeable_raw_info.ammo_fly_speed * p;

				character_changeable_current_info.ammo_fly_speed = luncher->luncher_info->fly_speed;
			}

			if(character_changeable_raw_info.ammo_explode_range > 0.f)
			{
				p = GetTotalAttributeByType(kEffect_Infect_AmmoExplodeRange);
				p = Max(p,0.f);
				luncher->luncher_info->range = character_changeable_raw_info.ammo_explode_range * p;

				character_changeable_current_info.ammo_explode_range = luncher->luncher_info->range;
			}
		}
		else
		{
			character_changeable_current_info.ammo_fly_speed = -1.f;
			character_changeable_current_info.ammo_explode_range = -1.f;
		}
		//if(weapon)
		//{
		//	weapon->is_weapon_updated = true;
		//}
		
	}



	float Character::GetTotalAttributeByType(const EEffect& type, bool no_system)
	{
		float p = 1.00f;
		for (uint i = 0; i < natural_effect_array.Size(); i++)
		{
			const EffectData& skill = natural_effect_array[i];
			if(skill.enable && skill.type == type && (!no_system || skill.player_id != 0))
			{
				p += skill.value;
			}
		}
		for (uint i = 0; i < acquired_effect_array.Size(); i++)
		{
			const EffectData& skill = acquired_effect_array[i];
			if(skill.enable && skill.type == type && (!no_system || skill.player_id != 0))
			{
				p += skill.value;
			}
		}

		return p;
	}

	float Character::GetAcquiredAttributeByType(const EEffect& type, bool no_system)
	{
		float p = 1.00f;
		for (uint i = 0; i < acquired_effect_array.Size(); i++)
		{
			const EffectData& skill = acquired_effect_array[i];
			if(skill.enable && skill.type == type && (!no_system || skill.player_id != 0))
			{
				p += skill.value;
			}
		}

		return p;
	}

	bool Character::IsAttributeExist(const EEffect& type, bool no_system)
	{
		for (uint i = 0; i < natural_effect_array.Size(); i++)
		{
			const EffectData& skill = natural_effect_array[i];
			if(skill.enable && skill.type == type && (!no_system || skill.player_id != 0))
			{
				return true;
			}
		}
		for (uint i = 0; i < acquired_effect_array.Size(); i++)
		{
			const EffectData& skill = acquired_effect_array[i];
			if(skill.enable && skill.type == type && (!no_system || skill.player_id != 0))
			{
				return true;
			}
		}

		return false;
	}

	bool Character::IsAcquiredAttributeExist(const EEffect& type, bool no_system)
	{
		for (uint i = 0; i < acquired_effect_array.Size(); i++)
		{
			const EffectData& skill = acquired_effect_array[i];
			if(skill.enable && skill.type == type && (!no_system || skill.player_id != 0))
			{
				return true;
			}
		}

		return false;
	}

	void Character::UpdateMoveInfo()
	{
		tempc_ptr(WeaponBase) weapon = GetWeapon();
		if (move)
		{
			if (weapon && weapon->weapon_info)
			{
				
				if(IsAttributeExist(kEffect_Infect_HpInfectMoveSpeed))
				{
					float hp_infect_move_speed = GetTotalAttributeByType(kEffect_Infect_HpInfectMoveSpeed) - 1.0f;
					
					float hp_percent = (1.f - (float)hp / (float)max_hp) * 100.f;

					hp_percent = Clamp(hp_percent, 0, 100);

					move->SetRunSpeed(move_info.run_speed * (1 + hp_infect_move_speed * hp_percent) + runspeed_offset);
					move->SetCrouchSpeed(move_info.crouch_speed * (1 + hp_infect_move_speed * hp_percent) + runspeed_offset);
				}
				else
				{
					move->SetRunSpeed(move_info.run_speed + runspeed_offset);
					move->SetCrouchSpeed(move_info.crouch_speed + runspeed_offset);

					//LogSystem.WriteLinef("move_info.crouch_speed:%f    runspeed_offset %f  weapon->weapon_info->move_speed_offset   %f ",move_info.crouch_speed, runspeed_offset , weapon->weapon_info->move_speed_offset );
				}

			}
			else
			{
				move->SetRunSpeed(move_info.run_speed);
				move->SetCrouchSpeed(move_info.crouch_speed);
			}
		}
	}

	void Character::UpdateBossPVEData(float frame_time)
	{
		//LogSystem.WriteLinef("m_ClientSynScriptStringValue.Size() = %d",m_ClientSynScriptStringValue.Size());
		//LogSystem.WriteLinef("m_ClientSynScriptStringValueDirty.Size() = %d",m_ClientSynScriptStringValueDirty.Size());
		//LogSystem.WriteLinef("m_ClientSynScriptNumberValue.Size() = %d",m_ClientSynScriptNumberValue.Size());
		//LogSystem.WriteLinef("m_ClientSynScriptNumberValueDirty.Size() = %d",m_ClientSynScriptNumberValueDirty.Size());

		if (!IsDied() && ispveboss && boss_action_total_time > 0 && boss_action_timer < boss_action_total_time)
		{
			boss_action_timer += frame_time;

			if (boss_action_timer < boss_move_time && boss_move_time > 0)
			{
				float time = boss_action_timer/boss_move_time;
				time = Clamp(time,0,1);

				Vector3 pos;
				Lerp(pos, boss_startpos, boss_endpos, time);
				Vector3 vel = (pos - GetPosition()) / frame_time;
				SetCurrentSpeed(vel);
				SetPosition(pos);

				Quaternion rot;
				Lerp(rot, boss_startrot, boss_endrot, time);
				SetLookDir(rot);
			}
		}
		if (!IsDied() && ispveboss)
		{
			if (!ishalflife && hp < max_hp/2)
			{
				ishalflife = true;
				if (boss_pve_scene)
				{
					boss_pve_scene->stop();
					boss_pve_scene = FmodSystem::PlayEvent("bj/music/alienship_HPlow");
				}
			}
		}
	}

	bool Character::IsSlowMoving()
	{
		if(move)
			return move->IsSlowMoving();
		return false;
			
	}

}
