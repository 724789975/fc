#include "pch.h"

using namespace Core;

namespace Client
{
	typedef IDelegate<void (*)(const NxSweepQueryHit &)> UserCallback;

	static bool MoveCapsule(NxCapsule & capsule, NxSweepQueryHit & hit, NxVec3 direction, float friction, float skin, float min_dist, int max_iter, bool normalize, bool no_slideup, tempc_ptr(UserCallback) callback = NullPtr)
	{
		uint group_id = 1 << PhysxSystem::kStatic | 1 << PhysxSystem::kStaticCollisionWithPerson;
		group_id |= 1 << PhysxSystem::kController;
		group_id |= 1 << PhysxSystem::kGroupVehicle;
		if (gLevel)
		{
			tempc_ptr(Character) player = gLevel->GetPlayer();
			if(player)
			{
				int team = player->GetTeam();
				group_id |= 1 << (PhysxSystem::kStaticCollisionWithGateTeam1 + team);
			}
		}

#if DEBUG_CMD
		if (gLevel && gLevel->disable_static_collision)
		{
			group_id &= ~(1 << PhysxSystem::kStaticCollisionWithPerson);
		}
#endif
		bool result = false;
		bool moved = false;

		NxVec3 current_pos  = (capsule.p0 + capsule.p1) / 2;
		NxVec3 target_pos = current_pos + direction;
		NxVec3 p0_offset = capsule.p0 - current_pos;
		NxVec3 p1_offset = capsule.p1 - current_pos;

		while(max_iter--)
		{
			// Compute current direction
			NxVec3 current_dir = target_pos - current_pos;

			float len = current_dir.magnitude();
			if (len < min_dist)	break;

			current_dir /= len;

			if((current_dir | direction) <= 0.0f)
				break;

			moved = true;

			hit.t = 0;
			capsule.p0 = current_pos + p0_offset;
			capsule.p1 = current_pos + p1_offset;

			if (!gPhysxScene->linearCapsuleSweep(capsule, current_dir * (len + skin), NX_SF_STATICS | NX_SF_DYNAMICS, NULL, 1, &hit, NULL, group_id, NULL))
			{
				current_pos = target_pos;
				break;
			}

			if (callback)
				(*callback)(hit);

			float move_len = hit.t * (len + skin);
			result = true;

			if (move_len > skin)
			{
				current_pos += current_dir * (move_len - skin);
			}

			// Compute reflect direction
			NxVec3 ReflectDir;
			ComputeReflexionVector(ReflectDir, current_dir, hit.normal);
			ReflectDir.normalize();

			// Decompose it
			NxVec3 NormalCompo, TangentCompo;
			DecomposeVector(NormalCompo, TangentCompo, ReflectDir, hit.normal);

			// Compute new destination position
			const Extended amplitude = target_pos.distance(current_pos);

			target_pos = current_pos;

			if(friction != 0.0)
			{
				if(normalize)
					TangentCompo.normalize();

				if (no_slideup && TangentCompo.y > 0)
					TangentCompo.y = 0;

				target_pos += TangentCompo * float(friction * amplitude);
			}
		}

		capsule.p0 = current_pos + p0_offset;
		capsule.p1 = current_pos + p1_offset;

		return result;
	}

	static void MoveCharacter(NxCapsule & capsule, NxVec3 move, float step, float skin, uint & collision_flags, tempc_ptr(UserCallback) callback = NullPtr)
	{
		NxVec3 move_horizontal = NxVec3(move.x, 0, move.z);
		NxVec3 move_up = NxVec3(0, 0, 0);
		NxVec3 move_down = NxVec3(0, 0, 0);

		NxVec3 original_p0 = capsule.p0;
		NxVec3 original_p1 = capsule.p1;

		float min_dist = 0.001f;
		uint  max_iter = 5;

		uint CollisionFlags = 0;
		NxSweepQueryHit hit;

		if (move.y > 0)
		{
			move_up.y = move.y;
			step = 0;
		}

		if (move.y < 0)
			move_down.y = move.y;

		if ((collision_flags & NXCC_COLLISION_DOWN) == 0)
			step = 0.f;

		if(!move_horizontal.isZero())
			move_up.y += step;

		if (MoveCapsule(capsule, hit, move_up, 1, skin, min_dist, step > 0 ? 1 : max_iter, false, false, callback))
		{
			CollisionFlags |= NXCC_COLLISION_UP;

			float delta = capsule.p0.y - original_p0.y;
			if(delta < step)
				step = delta;
		}

		if (MoveCapsule(capsule, hit, move_horizontal, 1, skin, min_dist, max_iter, false, move.y > 0, callback))
		{
			CollisionFlags |= NXCC_COLLISION_SIDES;
		}

		if(!move_horizontal.isZero())
			move_down.y -= step;

		if (MoveCapsule(capsule, hit, move_down, 0, skin, min_dist, 1, false, false, callback))
		{
			CollisionFlags |= NXCC_COLLISION_DOWN;
		}
		else
		{
			if ((collision_flags & NXCC_COLLISION_DOWN) && (!move_horizontal.isZero()) && step > 0)
			{
				NxVec3 p0 = capsule.p0;
				NxVec3 p1 = capsule.p1;
				NxVec3 step_down = NxVec3(0, -step, 0);

				if (MoveCapsule(capsule, hit, step_down, 0, skin, min_dist, 1, false, false, callback))
				{
					CollisionFlags |= NXCC_COLLISION_DOWN;
				}
				else
				{
					capsule.p0 = p0;
					capsule.p1 = p1;
				}
			}
		}

		if (CollisionFlags & NXCC_COLLISION_DOWN)
		{
			if (move.y < 0)
			{
				bool slide = false;

				// on ground
				if (step > 0)
				{
					if (hit.hitShape && hit.hitShape->getType() == NX_SHAPE_MESH)
					{
						NxVec3 normal;
						NxTriangle triangle;
						NxTriangleMeshShape * shape = static_cast<NxTriangleMeshShape*>(hit.hitShape);

						shape->getTriangle(triangle, NULL, NULL, hit.internalFaceID);
						triangle.normal(normal);

						if (normal.y >= 0 && normal.y < 0.7f)
							slide = true;
					}
					else
					{
						if (hit.normal.y >= 0 && hit.normal.y < 0.7f)
							slide = true;
					}
				}
				else
				{
					float hit_height = hit.point.y;
					float capsule_height = capsule.p0.y;

					if (hit_height > capsule_height - capsule.radius * 0.9f)
						slide = true;
				}

				if (slide)
				{
					capsule.p0 = original_p0;
					capsule.p1 = original_p1;
					CollisionFlags = 0;

					// retry move horizontal
					if (MoveCapsule(capsule, hit, move_horizontal, 1, skin, min_dist, max_iter, false, step == 0, callback))
					{
						CollisionFlags |= NXCC_COLLISION_SIDES;
					}

					float recover = capsule.p0.y > original_p0.y ? capsule.p0.y - original_p0.y - move.y : -move.y;
					float MD = recover < min_dist ? recover / max_iter : min_dist;

					NxVec3 recover_point(0, -recover, 0);

					if (MoveCapsule(capsule, hit, recover_point, 1, skin, MD, max_iter, false, false, callback))
					{
						float delta = capsule.p0.y - original_p0.y;

						if (delta < -0.001f)
						{
							CollisionFlags |= NXCC_COLLISION_SLIDE;
						}
						else
						{
							CollisionFlags |= NXCC_COLLISION_DOWN;
						}
					}
				}
			}
		}

		collision_flags = CollisionFlags;
	}
}

namespace Client
{
	static const float MAX_SPEED = 20.f;
	static const float MAX_ACCELERATION = 20.f;
	/// constructor
	MoveController::MoveController()
		: position(Core::Vector3::kZero)
		, rotation(Core::Quaternion::kIdentity)
		, look_dir(Core::Quaternion::kIdentity)
		, move_dir(Core::Vector3::kZero)
		, direction(Core::Vector2::kZero)

		, current_speed(Core::Vector3::kZero)
		, move_speed(0)

		, jumping(false)
		, onground(true)
		, walk(false)
		, crouch(false)
		, flying(false)
		, uav_flying(false)
		, boost(false)
		, fall_flag(0)
		, kick_on_hit_timer(-1.f)

		, body_capsule(NULL)
		, vertical_speed(0.f)
		, begin_high(0.f)
	{
		height = controller_info.controller_height;
	}

	/// destructor
	MoveController::~MoveController()
	{
	}

	/// on create
	void MoveController::OnCreate()
	{
		Object::OnCreate();
	}

	/// on destroy
	void MoveController::OnDestroy()
	{
		ReleasePhysxObject();

		Object::OnDestroy();
	}

	/// on rebirth
	void MoveController::OnRebirth(by_ptr(Character) c, const Core::Vector3 & p, const Core::Quaternion & r)
	{
		SetPosition(p);
		SetLookDir(r);
		CreatePhysxObject(c);
		SetFly(false);
		SetBoost(false, 0);

		current_speed = Vector3::kZero;
	}

	/// on died
	void MoveController::OnDied()
	{
		ReleasePhysxObject();

		move_dir = Vector3::kZero;
		current_speed = Vector3::kZero;
		direction = Vector2::kZero;
	}

	/// on hit
	void MoveController::OnHit(const HitInfo & info, float speed_factor, float acc_factor, float distance_factor)
	{
	}

	void MoveController::OnHitByVehicle(const KickInfo & info, bool skip_physx)
	{
	}

	/// create physx object
	void MoveController::CreatePhysxObject(by_ptr(Character) character)
	{
		ReleasePhysxObject();

		body_capsule = PhysxSystem::CreateCapsule(position, controller_info.controller_height, 
						controller_info.controller_radius - controller_info.controller_skinwidth, PhysxSystem::kController, character);
		if (body_capsule)
		{
			body_capsule->raiseBodyFlag(NX_BF_KINEMATIC);
		}
	}

	/// release physx object
	void MoveController::ReleasePhysxObject()
	{
		if (body_capsule)
		{
			PhysxSystem::ReleaseActor(*body_capsule);
			body_capsule = NULL;
		}
	}

	/// set character
	void MoveController::SetCharacter(by_ptr(Character) c)
	{
		character = c;
	}


	/// update
	void MoveController::Update(float frame_time)
	{
		if (body_capsule)
		{
			//vertical_speed += frame_time * -19.6f;
			vertical_speed = Min(vertical_speed, 10.f);
		}
		else
			vertical_speed = 0.f;

		float offset = 5 * frame_time;

		offset = Min(offset, controller_info.controller_skinwidth - 0.03f);

		if (crouch && height > controller_info.controller_crouch_height)
		{
			height -= offset;

			if (height < controller_info.controller_crouch_height)
			{
				offset = offset - (controller_info.controller_crouch_height - height);
				height = controller_info.controller_crouch_height;
			}

			if (body_capsule)
			{
				NxCapsuleShape* shape =  static_cast<NxCapsuleShape*>(body_capsule->getShapes()[0]);
				if (shape)
					shape->setHeight(height);
			}
		}
		else if ((!crouch) && height < controller_info.controller_height)
		{
			NxScene* pScene = PhysxSystem::Scene();
			if (pScene)
			{
				Vector3 pos = position;
				height += offset;

				if (height > controller_info.controller_height)
				{
					offset = offset - (height - controller_info.controller_height);
					height = controller_info.controller_height;
				}

				NxCapsule capsule;

				if (!onground)
					pos.y -= offset;

				capsule.p0 = NxVec3(pos.x, pos.y + controller_info.controller_radius, pos.z);
				capsule.p1 = capsule.p0;
				capsule.p1.y += height;
				capsule.radius = controller_info.controller_radius - controller_info.controller_skinwidth;

				if (pScene->checkOverlapCapsule(capsule, NX_ALL_SHAPES, 1 << PhysxSystem::kStatic | 1 << PhysxSystem::kStaticCollisionWithPerson))
					height -= offset;

				if (body_capsule)
				{
					NxCapsuleShape* shape =  static_cast<NxCapsuleShape*>(body_capsule->getShapes()[0]);
					if (shape)
						shape->setHeight(height);
				}
			}
		}
	}

	/// set controller info
	void MoveController::SetControllerInfo(const ControllerInfo & info)
	{
		controller_info = info;

		height = controller_info.controller_height;
	}

	/// set move Info
	void MoveController::SetMoveInfo(const MoveInfo & info)
	{
		move_info = info;
	}

	/// set move factor
	void MoveController::SetMoveFactor(float factor)
	{
		move_info.move_factor = factor;
	}

	/// set jump factor
	void MoveController::SetJumpFactor(float factor)
	{
		move_info.jump_factor = factor;
	}

	/// set run speed
	void MoveController::SetRunSpeed(float speed)
	{
		move_info.run_speed = speed;
	}
	
	/// set run speed
	void MoveController::SetWalkSpeed(float speed)
	{
		move_info.walk_speed = speed;
	}
	
	/// set run speed
	void MoveController::SetCrouchSpeed(float speed)
	{
		move_info.crouch_speed = speed;
	}
	
	/// set run speed
	void MoveController::SetFlightSpeed(float speed)
	{
		move_info.flight_speed = speed;
	}

	/// set hit factor
	void MoveController::SetHitFactor(float hit_speed, float hit_acceleration, float hit_distance)
	{
		move_info.hit_speed = Clamp(hit_speed, 0.f, 1.f);
		move_info.hit_acceleration = Clamp(hit_acceleration, 0.f, move_info.acceleration);
		//move_info.hit_distance = Clamp(hit_distance, 0.f, 10.f);
	}

	/// set move
	void MoveController::SetMove(float move, float shift)
	{
		move_dir.x = -shift;
		move_dir.y = 0;
		move_dir.z = -move;

		direction.x = move;
		direction.y = shift;

		TransformNormal(move_dir, move_dir, rotation);
		move_dir.y = 0;
		move_dir.Normalize();
	}

	/// get move
	const Vector3 & MoveController::GetMove()
	{
		return move_dir;
	}

	/// get direction
	const Vector2 & MoveController::GetDirection()
	{
		return direction;
	}

	/// move look
	void MoveController::MoveLook(float horizontal, float vertical)
	{
	}

	/// get position
	const Core::Vector3 & MoveController::GetPosition()
	{
		return position;
	}

	/// set position
	void MoveController::SetPosition(const Core::Vector3 & pos)
	{
		if (body_capsule)
		{
			NxVec3 physxPos(pos.x, pos.y, pos.z);

			physxPos.y += height * 0.5f + controller_info.controller_radius;
			
			body_capsule->setGlobalPosition(physxPos);
		}

		position = pos;
	}

	/// move position
	void MoveController::MovePosition(const Core::Vector3 & pos)
	{
		NxVec3 move = (const NxVec3 &)(pos - position);
		float step = 0;

		NxCapsule capsule;
		capsule.p0 = NxVec3(position.x, position.y + controller_info.controller_radius, position.z);
		capsule.p1 = capsule.p0 + NxVec3(0, height, 0);
		capsule.radius = controller_info.controller_radius - controller_info.controller_skinwidth;
		
		uint collisionFlags = 0;
		
		if (onground)
			collisionFlags |= NXCC_COLLISION_DOWN;

		MoveCharacter(capsule, move, step, controller_info.controller_skinwidth, collisionFlags);

		position.x = capsule.p0.x;
		position.y = capsule.p0.y - controller_info.controller_radius;
		position.z = capsule.p0.z;

		NxExtendedVec3 physxPos(position.x, position.y, position.z);
		physxPos.y += height * 0.5f + controller_info.controller_radius;

		if (body_capsule)
			body_capsule->moveGlobalPosition(NxVec3(physxPos.x, physxPos.y, physxPos.z));

		if (collisionFlags & NXCC_COLLISION_UP)
			vertical_speed = -1;

		if (collisionFlags & NXCC_COLLISION_DOWN && !(collisionFlags & NXCC_COLLISION_SLIDE))
			vertical_speed = -1;
	}

	/// get rotation
	const Core::Quaternion & MoveController::GetRotation()
	{
		return rotation;
	}

	/// set rotaion
	void MoveController::SetRotation(const Core::Quaternion & rot)
	{
		rotation = rot;
	}

	/// set face dir
	void MoveController::SetLookDir(const Core::Quaternion & rot)
	{
		Vector3 front_dir = Vector3(0, 0, -1) * rot;
		Vector3 up_dir = Vector3(0, 1, 0) * rot;
		Vector3 right_dir = Vector3(1, 0, 0) * rot;


		float angle = Asin(Dot(Vector3(0, 1, 0), front_dir));
		const float limit = 89 * DEG2RAD;

		// angle is normal
		if (angle > -HALFPI && angle < HALFPI)
		{
			look_dir = rot;

			if (up_dir.y >= 0)
			{
				rotation = look_dir * Quaternion(right_dir, -angle);

				if (angle > limit)
				{
					Quaternion fix(right_dir, limit - angle);
					look_dir = rot * fix;
				}
				else if (angle < -limit)
				{
					Quaternion fix(right_dir, - angle - limit);
					look_dir = rot * fix;
				}
			}
			else
			{
				rotation = look_dir * Quaternion(right_dir, PI + angle);

				if (angle >= 0)
				{
					Quaternion fix(right_dir, angle + limit + PI);
					look_dir = rot * fix;
				}
				else if (angle < 0)
				{
					Quaternion fix(right_dir, angle - limit + PI);
					look_dir = rot * fix;
				}
			}
		}
	}

	/// get face dir
	const Core::Quaternion &  MoveController::GetLookDir()
	{
		return look_dir;
	}

	/// set crouch
	void MoveController::SetCrouch(bool flag)
	{
		if (crouch != flag)
		{
			crouch = flag;

			if (body_capsule)
			{
				NxCapsuleShape* shape =  static_cast<NxCapsuleShape*>(body_capsule->getShapes()[0]);
				if (shape)
				{
					if (crouch)
						shape->setHeight(controller_info.controller_crouch_height);
					else
						shape->setHeight(controller_info.controller_height);
				}
			}
		}
	}

	/// set walk
	void MoveController::SetWalk(bool flag)
	{
		walk = flag;
	}

	/// get crouch
	bool MoveController::GetCrouch()
	{
		return crouch;
	}

	/// get walk
	bool MoveController::GetWalk()
	{
		return walk;
	}

	/// is jumping
	bool MoveController::IsJumping()
	{
		return jumping;
	}

	/// is flying
	bool MoveController::IsFlying()
	{
		return flying;
	}

	/// is flying
	bool MoveController::IsBoost()
	{
		return boost;
	}

	bool MoveController::IsUavFlying()
	{
		return uav_flying;
	}

	/// is on ground
	bool MoveController::IsOnGround()
	{
		return onground;
	}

	/// is moving
	bool MoveController::IsMoving()
	{
		return current_speed.Length() > 3.f;
	}

	bool MoveController::IsSlowMoving()
	{
		return current_speed.Length() > 0.5f;
	}
	/// jump
	void MoveController::Jump()
	{
		if (onground)
		{
			SetOnGround(false);

			float jump_velocity = move_info.jump_velocity;
			if (character)
			{
				float temp_heigh = character->GetAcquiredAttributeByType(kEffect_Infect_JumpHeight);
				jump_velocity *= temp_heigh;
			}
			jump_velocity *= move_info.jump_factor;

			vertical_speed = jump_velocity;

			if (character)
				character->OnJump();
		}
	}

	/// fly
	void MoveController::Fly()
	{
		if (onground)
		{
			SetOnGround(false);

			float jump_velocity = move_info.jump_velocity;
			if (character)
			{
				float temp_heigh = character->GetAcquiredAttributeByType(kEffect_Infect_JumpHeight);
				jump_velocity *= temp_heigh;
			}
			jump_velocity *= move_info.jump_factor;

			vertical_speed = jump_velocity;

			if (character)
				character->OnJump();
		}
	}

	/// fly
	void MoveController::Boost(int dir)
	{
		if (character)
			character->OnBoost(dir);
	}

	/// ammo jump
	void MoveController::AmmoJump()
	{
		SetOnGround(false);
		float jump_velocity = move_info.jump_velocity;
		jump_velocity *= move_info.jump_factor * 2;

		vertical_speed = jump_velocity;

		if (character)
			character->OnJump();
	}

	float MoveController::GetKickTimer()
	{
		return kick_on_hit_timer;
	}

	/// set jump
	void MoveController::SetJump(bool flag)
	{
		if (jumping != flag)
		{
			jumping = flag;

			if (jumping)
				Jump();
		}
	}

	/// set fly
	void MoveController::SetFly(bool flag)
	{
		if (flying != flag)
		{
			flying = flag;
			if (flying)
				Fly();
		}
	}
	/// set Boost
	void MoveController::SetBoost(bool flag , int dir)
	{
		if (boost != flag)
		{
			boost = flag;
			//if (boost)
			//	Boost(dir);
		}
	}

	/// set onground
	void MoveController::SetOnGround(bool flag)
	{
		if (onground != flag)
		{
			onground = flag;
			if (onground && character)
			{	
				character->OnOnground();
				character->SetFly(false);
				fall_flag = 0;
				begin_high = 0.f;
			}
		}
	}

	/// get current speed
	void MoveController::SetCurrentSpeed(const Vector3 & speed)
	{
		current_speed = speed;
	}

	float MoveController::GetRunSpeed()
	{
		return move_info.run_speed;
	}

}


namespace Client
{
	/// constructor
	SimulateMove::SimulateMove()
		: sliding(false)

		, hit_acceleration(0.f)
		, flight_time(0.f)
		, speed_update_time(0.f)
		, speed_last_position(Vector3::kZero)
		, body_squere(NULL)
		, collision_flags(0)
		, hit_skip_physx(false)
	{
	}

	/// on create
	void SimulateMove::OnCreate()
	{
		MoveController::OnCreate();

		move_info.move_factor = 1.f;
		move_info.jump_factor = 1.f;

		move_info.run_speed = 6.f;
		move_info.walk_speed = 3.f;
		move_info.crouch_speed = 2.f;
		move_info.flight_speed = 1.f;
		move_info.flight_max_speed = 10.f;
		move_info.acceleration = 8.f;

		move_info.jump_velocity = 7.f;
	}

	/// create physx object
	void SimulateMove::CreatePhysxObject(by_ptr(Character) character)
	{
		ReleasePhysxObject();

		body_capsule = PhysxSystem::CreateCapsule(position, controller_info.controller_height, 
						controller_info.controller_radius - controller_info.controller_skinwidth, PhysxSystem::kControllerPlayer, character);
		if (body_capsule)
		{
			body_capsule->raiseBodyFlag(NX_BF_KINEMATIC);
		}
		
		body_squere = PhysxSystem::CreateSphere(position, controller_info.controller_radius - controller_info.controller_skinwidth, PhysxSystem::kNone, character);
	}

	/// release physx object
	void SimulateMove::ReleasePhysxObject()
	{
		MoveController::ReleasePhysxObject();

		if (body_squere)
		{
			PhysxSystem::ReleaseActor(*body_squere);
			body_squere = NULL;
		}
	}


	/// on rebirth
	void SimulateMove::OnRebirth(by_ptr(Character) c, const Core::Vector3 & p, const Core::Quaternion & r)
	{
		SetPosition(p);
		SetLookDir(r);
		CreatePhysxObject(c);
		SetFly(false);
		SetBoost(false, 0);

		speed_last_position = p;
		speed_update_time = 0;
		vertical_speed = 0;
		current_speed = Vector3::kZero;
	}

	/// on hit
	void SimulateMove::OnHit(const HitInfo & info, float speed_factor, float acc_factor, float distance_factor)
	{
		if (info.hp > 0 && distance_factor > 0.0f && info.sustainhurttype == kSustainNone)
		{
			current_speed *= move_info.hit_speed * speed_factor;
			hit_acceleration = move_info.hit_acceleration * acc_factor;

		
			Vector3 displayment = Vector3(0, 0, -1) * info.dir;
			displayment *= move_info.hit_distance * distance_factor;

			float step = onground ? 0.2f : 0;
			if (vertical_speed > 0) step = 0;

			NxCapsule capsule;
			capsule.p0 = NxVec3(position.x, position.y + controller_info.controller_radius, position.z);
			capsule.p1 = capsule.p0 + NxVec3(0, height, 0);
			capsule.radius = controller_info.controller_radius - controller_info.controller_skinwidth;

			MoveCharacter(capsule, (const NxVec3&)displayment, step, controller_info.controller_skinwidth, collision_flags);

			position.x = capsule.p0.x;
			position.y = capsule.p0.y - controller_info.controller_radius;
			position.z = capsule.p0.z;
		
		}
	}


	/// on hit
	void SimulateMove::OnHitByVehicle(const KickInfo & info, bool skip_physx)
	{
		if(kick_on_hit_timer < 0.f)
		{
			hit_skip_physx = skip_physx;
			kick_on_hit_timer = info.kick_time_interval;
			current_speed *= move_info.hit_speed;
			hit_acceleration = move_info.hit_acceleration;


			Vector3 displayment = Vector3(0, 0, -1) * info.dir;
			displayment *= move_info.hit_distance *  info.kick_factor;

			kick_target = displayment;

			Vector3 normalize_dis = Normalize(displayment);

			NxRay ray;
			ray.orig = (const NxVec3 &)position;
			ray.dir = (const NxVec3 &)normalize_dis;

			NxRaycastHit hit;

			uint group_id = 0;
			group_id |= 1 << PhysxSystem::kStatic;
			group_id |= 1 << PhysxSystem::kStaticCollisionWithPerson;

			if(character)
			{
				group_id |= 1 << (character->GetTeam() == 0 ? PhysxSystem::kStaticCollisionWithGateTeam1 : PhysxSystem::kStaticCollisionWithGateTeam2);
			}

			NxShape* shape = gPhysxScene->raycastClosestShape(ray, NX_ALL_SHAPES, hit, group_id, Length(displayment));
			if (shape)
			{		
				{
					kick_target = normalize_dis * hit.distance * 0.9f;
					kick_target.y += info.on_static_kick_y_offset;
				}

			}

			kick_target = kick_target / kick_on_hit_timer;
		}
	}

	/// update
	void SimulateMove::Update(float frame_time)
	{
		if (body_squere)
		{
			//vertical_speed += frame_time * -19.6f;
			NxVec3 body_velocity = body_squere->getLinearVelocity();
			vertical_speed = body_velocity.y;
		}
		else
			vertical_speed = 0.f;

		if(kick_on_hit_timer > 0.f)
		{
			kick_on_hit_timer -= frame_time;
			if(!(collision_flags & NXCC_COLLISION_SIDES))
				MovePosition(position + kick_target * frame_time);
			else
			{
				if(hit_skip_physx)
				{ 
					MovePosition(position + kick_target * frame_time);
				}
				else
				{
					kick_on_hit_timer = -1.f;
				}
			}

			return;
		}

		F32 offset = 5 * frame_time;

		offset = Min(offset, controller_info.controller_skinwidth - 0.03f);

		if (crouch && height > controller_info.controller_crouch_height)
		{
			height -= offset;

			if (height < controller_info.controller_crouch_height)
			{
				offset = offset - (controller_info.controller_crouch_height - height);
				height = controller_info.controller_crouch_height;
			}

			if (!onground)
				position.y += offset;

			if (body_capsule)
			{
				NxShape* const* pShape = body_capsule->getShapes();
				if (pShape)
				{
					NxCapsuleShape* shape =  static_cast<NxCapsuleShape*>(pShape[0]);
					if (shape)
						shape->setHeight(height);
				}
			}
		}
		else if ((!crouch) && height < controller_info.controller_height)
		{
			NxScene* pScene = PhysxSystem::Scene();
			if (pScene)
			{
				Vector3 pos = position;
				height += offset;

				if (height > controller_info.controller_height)
				{
					offset = offset - (height - controller_info.controller_height);
					height = controller_info.controller_height;
				}

				NxCapsule capsule;

				if (!onground)
					pos.y -= offset;

				capsule.p0 = NxVec3(pos.x, pos.y + controller_info.controller_radius, pos.z);
				capsule.p1 = capsule.p0;
				capsule.p1.y += height;
				capsule.radius = controller_info.controller_radius - controller_info.controller_skinwidth;

				if (pScene->checkOverlapCapsule(capsule, NX_ALL_SHAPES, 1 << PhysxSystem::kStatic | 1 << PhysxSystem::kStaticCollisionWithPerson | 1 << PhysxSystem::kController | 1 << PhysxSystem::kGroupVehicle))
					height -= offset;
				else
					position = pos;

				if (body_capsule)
				{
					NxCapsuleShape* shape =  static_cast<NxCapsuleShape*>(body_capsule->getShapes()[0]);
					if (shape)
						shape->setHeight(height);
				}
			}
		}

		if (move_dir != Vector3::kZero)
		{
			move_speed = move_info.run_speed;

			if (walk)
				move_speed = move_info.walk_speed;

			if (crouch)
				move_speed = move_info.crouch_speed;
		}
		else
			move_speed = 0.f;

		move_speed *= move_info.move_factor;

		if (direction.x == -1)
			move_speed *= 0.8f;

		// check speed
		move_speed = Clamp(move_speed, 0, MAX_SPEED);

		if (hit_acceleration > 0)
			hit_acceleration -= move_info.acceleration * frame_time;
		else
			hit_acceleration = 0;

		if (onground)
		{
			Vector3 speed = move_dir * move_speed - current_speed;

			if (speed.Length() > 1)
			{
				float acceleration = move_info.acceleration - hit_acceleration;

				// check acceleration
				acceleration = Clamp(acceleration, 0, MAX_ACCELERATION);

				current_speed += speed * Min(1.f, frame_time * acceleration);
			}
			else
				current_speed = move_dir * move_speed;
		}
		else
		{
			float dot = Dot(move_dir, Normalize(current_speed));

			if (dot < - EPSILON)
			{
				current_speed = Vector3::kZero;
			}
		}


		Vector3 speed(current_speed);
		
		if(boost)
		{
			speed += move_dir * move_info.run_speed * 1.4f;
			if (body_squere)
				speed += (const Vector3&)body_squere->getLinearVelocity(); 
		}
		else if (character->is_fly_uav)
		{
			speed += move_dir * move_info.run_speed;
			if (body_squere)
				speed += (const Vector3&)body_squere->getLinearVelocity(); 
		}
		else if (flying)
		{
			speed += move_dir * move_info.run_speed;
			if (body_squere)
				speed += (const Vector3&)body_squere->getLinearVelocity(); 
		}
		else if (!onground)
		{
			speed += move_dir * move_info.flight_speed;
			if (body_squere)
				speed += (const Vector3&)body_squere->getLinearVelocity(); 

			//float speed_length = speed.Length();
			//if (speed_length > move_info.flight_max_speed)
			//{
			//	speed.Normalize();
			//	speed *= move_info.flight_max_speed;
			//}
		}



		NxVec3 move = NxVec3(speed.x, vertical_speed, speed.z) * frame_time;
		if (vertical_speed != 0)
			move.y -= 0.5f * 19.6 * frame_time * frame_time;
		float step = onground ? 0.2f : 0;
		if (vertical_speed > 0) step = 0;

		NxCapsule capsule;
		capsule.p0 = NxVec3(position.x, position.y + controller_info.controller_radius, position.z);
		capsule.p1 = capsule.p0 + NxVec3(0, height, 0);
		capsule.radius = controller_info.controller_radius - controller_info.controller_skinwidth;

		//if (gGame->input->IsKeyDown(KC_SPACE))
		//{
		//	move = NxVec3(speed.x, -vertical_speed, speed.z) * frame_time;
		//}
		if (character->is_fly_uav)
		{
			//move.y = 0;
			//vertical_speed = 0;

			//if (vertical_speed < 0 && fall_flag)
			//{
			//	fall_flag = false;
			//	float jump_velocity = move_info.jump_velocity;
			//	if (character)
			//	{
			//		float temp_heigh = character->GetAcquiredAttributeByType(kEffect_Infect_JumpHeight);
			//		jump_velocity *= temp_heigh;
			//	}
			//	jump_velocity *= move_info.jump_factor;
			//	if(body_squere)
			//		body_squere->setLinearVelocity(NxVec3(0, jump_velocity, 0));
			//	if(body_squere)
			//	body_squere->setLinearVelocity(NxVec3(0, 0, 0));
			//}
			if (gGame->input->IsKeyDown(KC_SPACE))
			{
				SetUAVFly(true);
				if(capsule.p0.y - controller_info.controller_radius > 16)
				{
					move.y = 0;
					if(body_squere)
						body_squere->raiseBodyFlag(NX_BF_DISABLE_GRAVITY);
				}
				else
				{
					onground = true;
					Jump();
				}
			}
			else
			{
				SetUAVFly(false);
				if(body_squere)
					body_squere->clearBodyFlag(NX_BF_DISABLE_GRAVITY);
			}
			vertical_speed = 0;
		}
		else if (flying)
		{
			//if (vertical_speed < 0)
			//{
				//if (fall_flag)
				//{
				//	fall_flag = false;
				//	float jump_velocity = move_info.jump_velocity;
				//	if (character)
				//	{
				//		float temp_heigh = character->GetAcquiredAttributeByType(kEffect_Infect_JumpHeight);
				//		jump_velocity *= temp_heigh;
				//	}
				//	jump_velocity *= move_info.jump_factor;
				//	if(body_squere)
				//		body_squere->setLinearVelocity(NxVec3(0, 10, 0));
				//}
				//else
				//{
					if (gGame->input->IsKeyDown(KC_SPACE))
					{
						if (begin_high == 0)
						{
							begin_high = capsule.p0.y - controller_info.controller_radius;
						}
						if(capsule.p0.y - controller_info.controller_radius > begin_high + 9)
						{
							move.y = 0;
							if(body_squere)
								body_squere->raiseBodyFlag(NX_BF_DISABLE_GRAVITY);
						}
						else
						{
							float jump_velocity = move_info.jump_velocity;
							if (character)
							{
								float temp_heigh = character->GetAcquiredAttributeByType(kEffect_Infect_JumpHeight);
								jump_velocity *= temp_heigh;
							}
							jump_velocity *= move_info.jump_factor;
							if(body_squere)
								body_squere->setLinearVelocity(NxVec3(0, 5, 0));
						}
						//move.y = 0;
						//if(body_squere)
						//	body_squere->raiseBodyFlag(NX_BF_DISABLE_GRAVITY);
					}
					else
					{
						if(body_squere)
							body_squere->clearBodyFlag(NX_BF_DISABLE_GRAVITY);
					}
				//}
			//}
			vertical_speed = 0;
		}
		else if(character->is_item_boss)
		{
			if (gGame->input->IsKeyPressed(KC_SPACE) && fall_flag<2)
			{
				fall_flag++;
				float jump_velocity = move_info.jump_velocity;
				if (character)
				{
					float temp_heigh = character->GetAcquiredAttributeByType(kEffect_Infect_JumpHeight);
					jump_velocity *= temp_heigh;
				}
				jump_velocity *= move_info.jump_factor;
				if(body_squere)
					body_squere->setLinearVelocity(NxVec3(0, jump_velocity, 0));
			}
			if (!onground && fall_flag > 0)
			{
				SetOnGround(false);
				Vector3 speed(current_speed);
				if (move_dir != Vector3::kZero)
				{
					move_speed = move_info.run_speed;
					speed += move_dir * move_info.flight_speed;
				}
				else
					move_speed = 0.f;

				move = NxVec3(speed.x, vertical_speed, speed.z) * frame_time;
			}
			if (gGame->input->IsKeyPressed(MC_RIGHT_BUTTON) && character->quickmovecd < 0.1f)
			{
				character->quickmovecd = 5.f;
				Core::Vector3 dir = Vector3(0, 0, -1) * character->GetCameraRotation();
				dir.Normalize();
				Core::Vector3 ret;
				dir = dir * 8;
				ret = dir + character->GetPosition();

				NxVec3 move = (const NxVec3 &)(ret - position);
				float step = 0;
				NxCapsule capsule;
				capsule.p0 = NxVec3(position.x, position.y + controller_info.controller_radius, position.z);
				capsule.p1 = capsule.p0 + NxVec3(0, height, 0);
				capsule.radius = controller_info.controller_radius - controller_info.controller_skinwidth;

				uint collisionFlags = 0;

				if (onground)
					collisionFlags |= NXCC_COLLISION_DOWN;

				MoveCharacter(capsule, move, step, controller_info.controller_skinwidth, collisionFlags);

				ret.x = capsule.p0.x;
				ret.y = capsule.p0.y - controller_info.controller_radius;
				ret.z = capsule.p0.z;
				ret.y += height * 0.5f + controller_info.controller_radius;

				if(gGame && gGame->channel_connection)
				{
					gGame->channel_connection->Teleport(ret, character->GetRotation());
					QuickMoveSound();
				}
			}
		}

#if DEBUG_CMD
		if (gLevel && gLevel->noclip_mode)
		{
			if (move_speed > 0.f)
			{
				Core::Vector3 dir = Vector3(0, 0, -1) * look_dir;
				Core::Vector3 move_add = move_dir;

				move_add.y = 0;
				if (gGame->input->IsKeyDown(KC_W) || gGame->input->IsKeyDown(KC_S))
				{
					move_add.y = dir.y * (gGame->input->IsKeyDown(KC_S) ? -1.f : 1.f);
				}
				move_add.Normalize();
				move_add *= gLevel->noclip_speed * frame_time;
				capsule.p0 += (NxVec3&)move_add;
				capsule.p1 += (NxVec3&)move_add;
			}

			collision_flags = NXCC_COLLISION_DOWN;
		}
		else
#endif
		{
			sharedc_ptr(UserCallback) callback = NewDelegate(&SimulateMove::MoveCallback, ptr_static_cast<SimulateMove>(this));
			MoveCharacter(capsule, move, step, controller_info.controller_skinwidth, collision_flags, callback);
		}

		position.x = capsule.p0.x;
		position.y = capsule.p0.y - controller_info.controller_radius;
		position.z = capsule.p0.z;

		NxExtendedVec3 physxPos(position.x, position.y, position.z);
		physxPos.y += height * 0.5f + controller_info.controller_radius;

		if (body_capsule)
			body_capsule->moveGlobalPosition(NxVec3(physxPos.x, physxPos.y, physxPos.z));

		if (collision_flags & NXCC_COLLISION_UP)
		{
			vertical_speed = -1;
			if (body_squere)
				body_squere->setLinearVelocity(NxVec3(0, -1, 0));
		}

		if (body_squere)
			body_squere->setGlobalPosition((const NxVec3&)physxPos);
		// slide check
		sliding = (collision_flags & NXCC_COLLISION_SLIDE)? true: false;

		if (collision_flags & NXCC_COLLISION_DOWN)
		{
			// fall down check
			if (!sliding)
			{
				float fall_speed = vertical_speed;

				if (fall_speed < -10.f)
				{
					int damage = static_cast<int>(powf(Abs(fall_speed) - 10, 1.5f));

					if (damage && character && !character->is_boss)
						character->FallDown(-fall_speed);
				}

				vertical_speed = -1;
				if (body_squere)
					body_squere->setLinearVelocity(NxVec3(0, -1, 0));
			}

			SetOnGround(true);
			flight_time = 0.f;

			if (jumping)
			{
  				current_speed *= 0.5f;
				SetJump(false);
			}
		}
		else
		{
			flight_time += frame_time;

			if (flight_time > 0.05f)
			{
				float fall_speed = vertical_speed;
				SetOnGround(false);

				// todo
				if (fall_speed < -40)
				{
					if (character && !character->is_boss)
						character->FallDown(-fall_speed, false);
				}
			}
		}

		Vector3 player_pos = GetPosition();

		// update speed
		if (onground && (collision_flags & NXCC_COLLISION_SIDES))
		{			
			speed_update_time += frame_time;
			if (speed_update_time > 0.1f)
			{
				Vector3 offset = player_pos - speed_last_position;
				speed_last_position = player_pos;
				offset.y = 0;
				current_speed = offset / speed_update_time;
				speed_update_time = 0;
			}
		}
		else
		{
			speed_update_time = 0;
			speed_last_position = player_pos;
		}
	}

	/// move look
	void SimulateMove::MoveLook(float horizontal, float vertical)
	{
		Vector3 look_right_dir = Vector3(1, 0, 0) * look_dir;
		Vector3 look_up_dir(0, 1, 0);

		Quaternion look_horizontal(look_up_dir, horizontal);
		Quaternion look_vertical(look_right_dir, vertical);

		SetLookDir(look_dir * (look_vertical * look_horizontal));
	}

	/// set position
	void SimulateMove::SetPosition(const Core::Vector3 & pos)
	{
		position = pos;
	}

	/// set crouch
	void SimulateMove::SetCrouch(bool flag)
	{
		if (crouch != flag)
		{
			if (crouch)
			{
				NxScene* pScene = PhysxSystem::Scene();
				if (pScene)
				{
					NxCapsule capsule;
					capsule.p0 = NxVec3(position.x, position.y + controller_info.controller_radius, position.z);
					if (!onground)
						capsule.p0.y -= controller_info.controller_height - controller_info.controller_crouch_height;
					capsule.p1 = capsule.p0;
					capsule.p1.y += controller_info.controller_height;
					capsule.radius = controller_info.controller_radius - controller_info.controller_skinwidth;

					if (!pScene->checkOverlapCapsule(capsule, NX_ALL_SHAPES, 1 << PhysxSystem::kStatic | 1 << PhysxSystem::kStaticCollisionWithPerson | 1 << PhysxSystem::kController | 1 << PhysxSystem::kGroupVehicle))
					{
						crouch = false;
					}
				}
			}
			else
			{
				crouch = true;
			}
		}
	}

	/// jump
	void SimulateMove::Jump()
	{
		if (onground)
		{
			SetOnGround(false);
			float jump_velocity = move_info.jump_velocity;
			if (character)
			{
				float temp_heigh = character->GetAcquiredAttributeByType(kEffect_Infect_JumpHeight);
				jump_velocity *= temp_heigh;
			}
			jump_velocity *= move_info.jump_factor;
			if(body_squere)
			{
				if(gLevel->game_type != RoomOption::KMoonMode && gLevel->game_type != RoomOption::kAdvenceMode)
				{
					body_squere->setLinearVelocity(NxVec3(0, jump_velocity, 0));
				}
				else
				{
					body_squere->setLinearVelocity(NxVec3(0, jump_velocity*1.5, 0));
				}
			}
			if (character)
				character->OnJump();
		}
	}

	/// set fly
	void SimulateMove::SetFly(bool flag)
	{
		{
			flying = flag;
			if (flying)
				Fly();
			else
				if(body_squere)
					body_squere->clearBodyFlag(NX_BF_DISABLE_GRAVITY);
		}	
	}

	void SimulateMove::SetUAVFly(bool flag)
	{
		if (uav_flying != flag)
		{
			uav_flying = flag;
			if(uav_flying)
			{
				if(gLevel && gLevel->GetPlayer() == character)
				{
					if (!character->boss_2D_uav)
					{
						String str = String::Format("bj/player/2d/armor_robot/armor_boost");
						character->boss_2D_uav = FmodSystem::GetEvent(str.Str());
					}
					character->boss_2D_uav->start();
				}
				else
				{
					if (!character->boss_3D_uav)
					{
						FMOD_VECTOR vel = {0, 0, 0};
						String str = String::Format("bj/player/3d/armor_robot/armor_boost");
						character->boss_3D_uav = FmodSystem::GetEvent(str.Str());
					}
				}
			}
			else
			{
				if (character->boss_2D_uav)
				{
					character->boss_2D_uav->stop();
				}
				if (character->boss_3D_uav)
				{
					character->boss_3D_uav->stop();
				}
			}
		}
	}

	void SimulateMove::QuickMoveSound()
	{

		if (gLevel && gLevel->GetPlayer() == character)
		{
			Core::String str = Core::String::Format("bj/event/skill_teleport");
			FmodSystem::PlayEvent(str.Str());
		}
		else
		{
			FMOD_VECTOR vel = {0, 0, 0};
			FmodSystem::Play3DEvent("bj/event/skill_teleport_3d", (const FMOD_VECTOR &)character->GetPosition(), vel);
		}
	}

	/// add velocity
	void SimulateMove::AddVelocity(const Core::Vector3 & velocity)
	{
		if (body_squere)
		{
			NxVec3 v = body_squere->getLinearVelocity();
			v += (const NxVec3&)velocity;
			body_squere->setLinearVelocity(v);
		}
	}

	void SimulateMove::SetVelocity(const Core::Vector3 & velocity)
	{
		if (body_squere)
		{
			NxVec3 v = (const NxVec3&)velocity;
			body_squere->setLinearVelocity(v);
		}
	}
	/// get current speed
	void SimulateMove::SetCurrentSpeed(const Vector3 & speed)
	{
	}

	/// move callback
	void SimulateMove::MoveCallback(const NxSweepQueryHit & hit)
	{
		if (hit.hitShape)
		{
			switch (hit.hitShape->getGroup())
			{
			case PhysxSystem::kController:
				{
					if (hit.hitShape->userData)
					{
						if (character)
						{
							tempc_ptr(Character) c = ptr_dynamic_cast<Character>((Object*)hit.hitShape->userData);
							if (c)
								character->OnHitCharacter(c);
						}
					}
				}
				break;
			}
		}
	}

#if DEBUG_TOOLS
	void SimulateMove::JumpByViewer()
	{
		if(!jumping)
		{
			float jump_velocity = move_info.jump_velocity;
			jump_velocity *= move_info.jump_factor;
			vertical_speed = jump_velocity;
			if (character)
			{
				SetJump(true);
				character->OnJump();
			}
		}	
	}
	void SimulateMove::UpdateForViewer(float frame_time)
	{
		if (jumping)
		{
			if(flight_time > 0.05f && character->GetPosition().y<=0.0f)
			{
				float fall_speed = vertical_speed;

				SetOnGround(true);
				character->SetPosition(Vector3(0,0,0));
				flight_time = 0.f;

				if (jumping)
				{
					SetJump(false);
				}
				return;
			} 
			else
			{
				flight_time += frame_time;

				if (flight_time > 0.05f)
				{
					float fall_speed = vertical_speed;
					vertical_speed -= 19.6f * frame_time;
					SetOnGround(false);
				}
			}
			Vector3 pos = character->GetPosition();
			pos.y += vertical_speed/2*frame_time;
			character->SetPosition(pos);
		}
		else
		{
			if (move_dir != Vector3::kZero)
			{
				move_speed = move_info.run_speed;
				if (walk)
					move_speed = move_info.walk_speed;
				if (crouch)
					move_speed = move_info.crouch_speed;
			}
			else
				move_speed = 0.f;

			move_speed *= move_info.move_factor;
			move_speed = Clamp(move_speed, 0, MAX_SPEED);
			Vector3 speed = move_dir * move_speed - current_speed;
			if (speed.Length() > 1)
			{
				float acceleration = move_info.acceleration - hit_acceleration;

				// check acceleration
				acceleration = Clamp(acceleration, 0, MAX_ACCELERATION);

				current_speed += speed * Min(1.f, frame_time * acceleration);
			}
			else
				current_speed = move_dir * move_speed;
		}
	}
#endif
}
