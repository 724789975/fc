#include "pch.h"

using namespace Core;


namespace Client
{
	/// constructor
	FirstPerson::FirstPerson()
		: audio_step(NULL)
		, tank_idel_2d(NULL)
		, skeleton_position(Vector3::kZero)
		, root_position(Vector3::kZero)
		, skeleton_rotation(Quaternion::kIdentity)
		, camera_position(Vector3::kZero)
		, camera_rotation(Quaternion::kIdentity)
		, skeleton_punch(0)
		, show_count(-1)
		, now_step_material(-1)
		, dizzy_time(0.f)
		, bdizzy(false)
		, anim_play_time_percentage(-1.0f)
		, weapon_reload_total_time(0.0f)
		, weapon_reload_time(0.0f)
	{
	}

	/// destructor
	FirstPerson::~FirstPerson()
	{
		if (audio_step)
		{
			audio_step->stop(true);
			audio_step = NULL;
		}
		if (tank_idel_2d)
		{
			tank_idel_2d->stop();
			tank_idel_2d = NULL;
		}
	}

	/// on create
	void FirstPerson::OnCreate()
	{
		Object::OnCreate();
		now_step_material = -1;
	}

	/// on destroy()
	void FirstPerson::OnDestroy()
	{
		if (audio_step)
			audio_step->stop(true);

		if (tank_idel_2d)
			tank_idel_2d->stop();

		weapon_hold_set.Clear();

		Object::OnDestroy();
	}
	
	void FirstPerson::Initialize()
	{
		// load skeleton
		if (character && character_info)
		{
			LoadSkeleton();

			pose = ptr_new Pose(skeleton);

			CreateAnimation();

			InitializeMesh();

			draw_mesh = mesh;

			if (character->pack_index < character_info->pack_set.Size())
				InitializeWeapon(character_info->pack_set[character->pack_index]);
			
			
			//// hold pack
			//weapon_hold_set.Clear();
			//sharedc_ptr(WeaponBase) w;
			//for (uint i = 0; i < character_info->pack_set.Size(); i++)
			//{
			//	for (uint j = 0; j < character_info->pack_set[i].weapon_set.Size(); j++)
			//	{
			//		w = character->CreateWeapon(character_info->pack_set[i].weapon_set[j]);
			//		if (w)
			//		{
			//			w->is_for_player = true;
			//			w->SetOwner(character);
			//			w->Initialize();
			//			w->PreloadAnimation();
			//			weapon_hold_set.PushBack(w);
			//		}
			//	}
			//}
		}
	}

	/// initialize mesh
	void FirstPerson::InitializeWeapon(const PackInfo & pack)
	{
		weapons.Fill(NullPtr);
		for (uint j = 0; j < pack.weapon_set.Size(); ++j)
		{
			tempc_ptr(WeaponInfo) info = pack.weapon_set[j];
			SetWeapon(j, info);
		}
	}

	/// initialize mesh
	void FirstPerson::InitializeMesh()
	{
		mesh = ptr_new SkinMesh(MESH_KEY_PLAYER);
		for (S32 i = MESH_LOD_LEVEL - 1; i >= 0; i--)
		{
			if (mesh && character_info)
			{
				CharacterInfo::MeshSet::Enumerator it(character_info->mesh_set_first_person[i]);

				while (it.MoveNext())
				{
					mesh->AddPrimitive(it.Key(), it.Value(), i);
				}
			}
		}
	}

	/// update bounding box
	void FirstPerson::UpdateBoundingBox()
	{

		if (character && character->ready)
		{
			tempc_ptr(WeaponBase) weapon = GetWeapon(character->weapon_id);

			if (!character->IsDied())
			{
				if (draw_mesh)
					world_aabb = draw_mesh->GetAABB();
			}
		}

		const Quaternion q = skeleton_rotation * Quaternion(Vector3(0, 1, 0), PI);;
		Matrix44 m(character->GetPosition(), 1, q);
		world_aabb.Transform(m);

		tempc_ptr(WeaponBase) weapon = GetWeapon(character->weapon_id);

		if (weapon)
		{
			if (weapon->GetWorldAABB().Max >= weapon->GetWorldAABB().Min)
				world_aabb.UnionWithAABB(weapon->GetWorldAABB());
		}
	}

	/// update
	void FirstPerson::Update(float frame_time)
	{
		PROFILE("FirstPerson::Update");

		if (!character)
			return;

		// updae audio
		UpdateAudio(frame_time);

		// update animation
		UpdateAnimation(frame_time);

		tempc_ptr(WeaponBase) weapon = GetWeapon(character->weapon_id);;
		if (weapon)
			weapon->UpdateAnimation(frame_time);

		// update animation joint
		if (character->occluded == false)
		{
			if (animation_system)
				animation_system->OnValid(character->GetViewMode() == Character::kFirstPerson);

			if (character->GetViewMode() == Character::kFirstPerson)
			{
				UpdateAnimationJoint(frame_time);

				// update transform
				UpdateTransform(frame_time);

				// update weapon
				UpdateWeapon(frame_time);
				UpdateEquipment(frame_time);


				if(character != gLevel->GetPlayer())
				{
					tempc_ptr(WeaponBase) weapon = GetWeapon(character->weapon_id);
					if(weapon)
					{
						tempc_ptr(GunBase) gun = ptr_dynamic_cast<GunBase>(weapon);
						if(gun)
						{
							gun->UpdateEffect(frame_time);
						}
					}
				}
			}
			else if (character->IsDied())
			{
				UpdateAnimationJoint(frame_time);
				UpdateTransform(frame_time);
			}
		}

		if (dizzy_time <= 0)
		{
			dizzy_time = 0.f;
			bdizzy = false;
		}
		else
		{
			dizzy_time -= frame_time;	
		}

		tempc_ptr(GunBase) gun = ptr_dynamic_cast<GunBase>(GetWeapon(character->weapon_id));

		if (weapon_reload_time < weapon_reload_total_time)
		{
			weapon_reload_time += frame_time;
		}
		anim_play_time_percentage = -1.0f;
		if (gun)
		{
			if (animation_group)
			{
				if (weapon_reload_time < weapon_reload_total_time)
				{
					anim_play_time_percentage = weapon_reload_time / weapon_reload_total_time;
				} 
				else
				{
					anim_play_time_percentage = animation_group->Anim_Play_time / animation_group->Anim_Play_Totaltime;
				}
				if (anim_play_time_percentage > 1.0f)
				{
					anim_play_time_percentage = -1.0f;
				}
			}

		}
	}

	/// on render
	void FirstPerson::OnRender(float frame_time)
	{
		PROFILE("FirstPerson::OnRender");

		if (!character)
			return;

		// update animation joint
		if (character->occluded == false)
		{
			if (character->GetViewMode() == Character::kFirstPerson)
			{
				// update mesh
				if (draw_mesh)
				{
					draw_mesh->pose = pose;
					draw_mesh->Update();
				}
			}
		}

		// update bounding box
		UpdateBoundingBox();
	}

	/// update transform
	void FirstPerson::UpdateTransform(float frame_time)
	{
		if (!character || !skeleton || !pose)
			return;

		Vector3 old_punch = camera_rotation.GetZXY();
		Quaternion q;
		Vector3 look_angle = character->GetLookDir().GetZXY();

		Vector3 punch = character->punch_angle * 0.5f;

		q.SetZXY(look_angle + punch);

		// add camera rotation
		int camera_id = skeleton->GetJointId("cam");
		if (camera_id >= 0 && camera_id < (int)skeleton->GetJointCount())
		{
			const Transform & transform = pose->GetJointModelPose(camera_id);
			camera_rotation = q * transform.rotation;

			if (character->IsDied())
				camera_position = character->GetPosition() + Vector3(0, transform.position.y, transform.position.z) * (character->GetRotation() * Quaternion(Vector3(0, 1, 0), PI));
			else
				camera_position = character->GetPosition() + transform.position * (character->GetRotation() * Quaternion(Vector3(0, 1, 0), PI)) - Vector3(0, character->height_offset + character->GetControllerHeight() - character->GetHeight(), 0);

			
			Quaternion rot;

			rot.SetZXY(look_angle + punch * 0.7f);

			skeleton_position = camera_position - (Vector3(1, 1, -1) * transform.position) * (rot * transform.rotation);
		}

		Vector3 new_punch = camera_rotation.GetZXY();
		float angle_h = new_punch.y - old_punch.y;

		if (Abs(angle_h) > PI)
			angle_h -= Sgn(angle_h) * TWOPI;

		float punch_speed = 5.f * DEG2RAD * frame_time;

		if (Abs(angle_h) > 110.f * DEG2RAD * frame_time)
			skeleton_punch = Clamp(skeleton_punch + punch_speed * Sgn(angle_h), -1.5f * DEG2RAD, 1.5f * DEG2RAD);
		else
		{
			if (Abs(skeleton_punch) <= punch_speed)
				skeleton_punch = 0;
			else if (skeleton_punch < 0)
				skeleton_punch += punch_speed;
			else
				skeleton_punch -= punch_speed;
		}

		new_punch.x *= 1.02f;
		skeleton_rotation.SetZXY(new_punch);
		skeleton_rotation = skeleton_rotation * Quaternion(Vector3(0, 1, 0) * skeleton_rotation, PI);

		camera_id = skeleton->GetJointId("wristIK_l");
		if (camera_id >= 0 && camera_id < (int)skeleton->GetJointCount())
		{
			const Transform & transform = pose->GetJointModelPose(camera_id);
			Vector3 pos_center = skeleton_position + transform.position * skeleton_rotation;
			skeleton_rotation = Quaternion(skeleton_punch, 0, 0) * skeleton_rotation;
			skeleton_position = pos_center - transform.position * skeleton_rotation;
		}
	}

	/// is ready
	bool FirstPerson::IsReady()
	{
		if (!character)
			return false;

		if (draw_mesh && !draw_mesh->IsReady())
			return false;

		if (animation_set && !animation_set->IsReady())
			return false;

		int weapon_id = character->weapon_id;
		if (weapon_id >= 0 && weapon_id < 7)
			if (animation_set_weapon[weapon_id] && !animation_set_weapon[weapon_id]->IsReady())
				return false;

		tempc_ptr(WeaponBase) weapon = GetWeapon(character->weapon_id);
		if (weapon && !weapon->IsReady())
			return false;

		return true;
	}

	/// is dizzy
	bool FirstPerson::IsDizzy()
	{
		return bdizzy;
	}

	/// get dizzy time
	F32 FirstPerson::GetDizzyTime()
	{
		return dizzy_time;
	}
	
	void FirstPerson::Dizzy(float addtime)
	{
		if(bdizzy)
		{
			/*if(character->is_boss && character->hp < character->max_hp/3)
			{
				dizzy_time += addtime;
			}
			else*/
			{
				dizzy_time = addtime;
			}
		}
		else
		{
			bdizzy = true;
			dizzy_time = addtime;
		}
	}

	/// draw
	void FirstPerson::Draw(Primitive::DrawType drawtype, bool immediate)
	{
		if (character && character->ready)
		{
			//if player carries a sniper and open X1X2sight,don't draw gun and player
			tempc_ptr(WeaponBase) weapon = GetWeapon(character->weapon_id);
			if (weapon)
			{
				if(weapon->GetWeaponType() == kWeaponTypeRifle)
				{
					tempc_ptr(RifleGun) rifle_gun = ptr_dynamic_cast<RifleGun>(GetWeapon(character->weapon_id));
					if(rifle_gun)
					{
						tempc_ptr(RifleInfo) rifle_info = ptr_dynamic_cast<RifleInfo>(rifle_gun->gun_info);
						
						if (rifle_info && rifle_info->sight_info.Size()>=2 && character->camera_fov <= rifle_info->sight_info[1].level)
							return;
					}
				}

				if(weapon->GetWeaponType() == kWeaponTypeSniperGun )
				{
					tempc_ptr(SniperGun) sniper_gun = ptr_dynamic_cast<SniperGun>(GetWeapon(character->weapon_id));
					if(sniper_gun)
					{
						tempc_ptr(SniperGunInfo) sniper_info = ptr_dynamic_cast<SniperGunInfo>(sniper_gun->gun_info);

						if (sniper_info && sniper_info->sight_info.Size()>=2 && character->camera_fov <= sniper_info->sight_info[1].level)
							return;
					}
				}
				if(weapon->GetWeaponType() == kWeaponTypeRifle || weapon->GetWeaponType() == kWeaponTypeSubMachineGun )
				{
					tempc_ptr(RifleGun) rifle_gun = ptr_dynamic_cast<RifleGun>(GetWeapon(character->weapon_id));
					if(rifle_gun)
					{
						tempc_ptr(RifleInfo) rifle_info = ptr_dynamic_cast<RifleInfo>(rifle_gun->gun_info);

						if (rifle_info && rifle_info->sight_info.Size()>=2 && character->camera_fov <= rifle_info->sight_info[1].level)
							return;
					}
				}
				weapon->Draw(drawtype, immediate);
				//if(character->equipment_id >= 0)
				//{
				//	tempc_ptr(WeaponBase) equip = GetWeapon(character->equipment_id);
				//	if(equip != weapon)
				//	{
				//		equip->Draw(drawtype, immediate);
				//	}
				//}
			}

			if (draw_mesh)
			{
				draw_mesh->SetPosition(GetSkeletonPosition());
				draw_mesh->SetRotation(GetSkeletonRotation());
				draw_mesh->Draw(drawtype, immediate);
			}
			if (character )
			{
				tempc_ptr(GunTowerBuilder) guntower = ptr_dynamic_cast<GunTowerBuilder>(weapon);
				if (guntower)
				{
					if(guntower->GetWeaponType() == kWeaponTypeGunTowerBuilder && character->tower_gun_count < 1 )
					{
						if (guntower && guntower->able_tower_mesh && guntower->unable_tower_mesh && guntower->bg_tower_mesh)
						{
							Core::Vector3 towerpos;
							Quaternion towerrot;
							towerpos = guntower->GetTowerMeshPosition(character->GetPosition() + Core::Vector3(0, 2, -2) * character->GetRotation());
							towerrot = character->GetRotation() * Quaternion(Vector3(0,1,0), PI * (guntower->GetGunTowerDir()) / 2);
							guntower->able_tower_mesh->SetPosition(towerpos);
							guntower->able_tower_mesh->SetRotation(towerrot);

							guntower->bg_tower_mesh->SetPosition(towerpos);
							guntower->bg_tower_mesh->SetRotation(character->GetRotation());
							guntower->bg_tower_mesh->Draw(drawtype, immediate);
							if (guntower->CanPlant())
							{	
								guntower->able_tower_mesh->Draw(drawtype, immediate);
							}
							else
							{
								guntower->unable_tower_mesh->SetPosition(towerpos);
								guntower->unable_tower_mesh->SetRotation(towerrot);
								guntower->unable_tower_mesh->Draw(drawtype, immediate);
							}
						}
					}
				}
			}
		}
	}

	/// get shader lod
	S32 FirstPerson::GetShaderLod()
	{
		if (draw_mesh)
		{
			return draw_mesh->GetShaderLod();
		}

		return 0;
	}

	/// update animation first person
	void FirstPerson::UpdateAnimationFirstPerson()
	{
		if (!character)
			return;

		uint lower_state = 0;

		Vector3 speed_for_animation = character->GetCurrentSpeed();

		// move state
		float length = speed_for_animation.Length();

		if (length > 0.01f)
			lower_state |= 1;
		if (length < 3.f)
			lower_state |= 4;

		// stance state
		if (character->GetCrouch())
			lower_state |= 2;

		// walk state
		if (character->GetWalk())
			lower_state |= 4;

		if(character->IsFlying())
			lower_state |= 5;

		switch (lower_state)
		{
		case 1:
			if (animation_list)
				animation_list->SetActiveNode("run");
			break;

		case 3:
		//case 7:
		//	if (animation_list)
		//		animation_list->SetActiveNode("walk");
		//	break;

		//case 5:
		//	if (animation_list)
		//		animation_list->SetActiveNode("walk");
		//	break;

		default:
			if (animation_list)
				animation_list->SetActiveNode("idle");
			break;
		}
	}

	/// update animation
	void FirstPerson::UpdateAnimation(float frame_time)
	{
		PROFILE("FirstPerson::UpdateAnimation");
		UpdateAnimationFirstPerson();

		if (animation_system)
			animation_system->Update(frame_time);
		if (animation_group)
			animation_group->Update(frame_time);
	}

	void FirstPerson::StopAudioStep()
	{
		if (audio_step)
			audio_step->stop();
		if (tank_idel_2d)
			tank_idel_2d->stop();
	}

	/// update audio
	void FirstPerson::UpdateAudio(float frame_time)
	{
		if (character 
			&& !character->IsDied() 
			&& character->ready
			&& character->GetViewMode() == Character::kFirstPerson)
		{
			NxRay ray;
			ray.orig = (const NxVec3 &)character->GetPosition();
			ray.orig.y += 1.5f;
			ray.dir = (const NxVec3 &)Core::Vector3(0, -1, 0);

			NxRaycastHit hit;
			uint group_id = 0;
			group_id |= 1 << PhysxSystem::kStatic;
			group_id |= 1 << PhysxSystem::kStaticRaycast;
			NxShape* shape = gPhysxScene->raycastClosestShape(ray, NX_ALL_SHAPES, hit, group_id, 5.f);
			
			FMOD_EVENT_STATE audio_state = FMOD_EVENT_DEFAULT;

			if (audio_step)
			{
				if (character->IsOnGround())
				{
					if(character->IsMoving())
					{
						if (shape)
						{
							int stepway = now_stepway;
							now_stepway = 1;
							int step_material = now_step_material;
							CStrBuf<256> key;
							if (character->is_boss)
							{
								key.format("bj/material/2d/step/boss");
							}
							else if (gLevel && gLevel->game_type == RoomOption::kZombieMode && character->GetTeam() == 1)
							{
								key.format("bj/material/2d/step/bio_step");
							}
							else
							{
								switch (hit.materialIndex)
								{
								case PhysxSystem::kWood:
									now_step_material = 0;
									key.format("bj/material/2d/step/wood");
									break;

								case PhysxSystem::kMetal:
									now_step_material = 1;
									key.format("bj/material/2d/step/metal");
									break;

								case PhysxSystem::kConcrete:
									now_step_material = 2;
									key.format("bj/material/2d/step/concrete");
									break;

								default:
									break;
								}
							}
							if (step_material != now_step_material || now_stepway != stepway)
							{
								if (audio_step)
									audio_step->stop();
								audio_step = FmodSystem::GetEvent(key);
								if (audio_step)
									audio_step->start();
							}
							else
							{
								audio_step->getState(&audio_state);
								if ((audio_state & FMOD_EVENT_STATE_PLAYING) == 0)
								{
									audio_step = FmodSystem::GetEvent(key);
									if (audio_step)
										audio_step->start();
								}
							}
						}
					}
					else if(character->GetCrouch() && character->IsSlowMoving())
					{
						if (shape)
						{
							int stepway = now_stepway;
							now_stepway = 2;
							int step_material = now_step_material;
							CStrBuf<256> key;
							if (character->is_boss)
							{
								key.format("bj/material/2d/step/boss");
							}
							else if (gLevel && gLevel->game_type == RoomOption::kZombieMode && character->GetTeam() == 1)
							{
								key.format("bj/material/2d/step/bio_step");
							}
							else
							{
								switch (hit.materialIndex)
								{
								case PhysxSystem::kWood:
									now_step_material = 0;
									key.format("bj/material/2d/step_stealth/wood");
									break;

								case PhysxSystem::kMetal:
									now_step_material = 1;
									key.format("bj/material/2d/step_stealth/metal");
									break;

								case PhysxSystem::kConcrete:
									now_step_material = 2;
									key.format("bj/material/2d/step_stealth/concrete");
									break;

								default:
									break;
								}
							}
							if (step_material != now_step_material || stepway != now_stepway)
							{
								if (audio_step)
									audio_step->stop();
								audio_step = FmodSystem::GetEvent(key);
								if (audio_step)
									audio_step->start();
							}
							else
							{
								audio_step->getState(&audio_state);
								if ((audio_state & FMOD_EVENT_STATE_PLAYING) == 0)
								{
									audio_step = FmodSystem::GetEvent(key);
									if (audio_step)
										audio_step->start();
								}
							}
						}
					}
					else
					{
						audio_step->getState(&audio_state);
						if (audio_state & FMOD_EVENT_STATE_PLAYING)
							audio_step->stop(true);
					}
				}
				else
				{
					audio_step->getState(&audio_state);
					if (audio_state & FMOD_EVENT_STATE_PLAYING)
						audio_step->stop(true);
				}
			}
			else
			{
				if (shape)
				{
					CStrBuf<256> key;
					if (character->is_boss)
					{
						key.format("bj/material/2d/step/boss");
					}
					else if (gLevel && gLevel->game_type == RoomOption::kZombieMode && character->GetTeam() == 1)
					{
						key.format("bj/material/2d/step/bio_step");
					}
					else
					{
						if(character->GetCrouch() && character->IsSlowMoving())	
						{
							
							switch (hit.materialIndex)
							{
							case PhysxSystem::kWood:
								now_step_material = PhysxSystem::kWood;
								key.format("bj/material/2d/step_stealth/wood");
								break;

							case PhysxSystem::kMetal:
								now_step_material = PhysxSystem::kMetal;
								key.format("bj/material/2d/step_stealth/metal");
								break;

							case PhysxSystem::kConcrete:
								now_step_material = PhysxSystem::kConcrete;
								key.format("bj/material/2d/step_stealth/concrete");
								break;

							default:
								break;
							}
						}
						else
						{
							switch (hit.materialIndex)
							{
							case PhysxSystem::kWood:
								now_step_material = PhysxSystem::kWood;
								key.format("bj/material/2d/step/wood");
								break;

							case PhysxSystem::kMetal:
								now_step_material = PhysxSystem::kMetal;
								key.format("bj/material/2d/step/metal");
								break;

							case PhysxSystem::kConcrete:
								now_step_material = PhysxSystem::kConcrete;
								key.format("bj/material/2d/step/concrete");
								break;

							default:
								break;
							}
						}
						
					}
					audio_step = FmodSystem::GetEvent(key);
				}
			}
			if (tank_idel_2d && character->IsCarrierMode() )
			{
				if (!character->IsBoost() && !character->IsShooting() && !character->IsReloading() )
				{
					FMOD_EVENT_STATE audio_state = FMOD_EVENT_DEFAULT;
					tank_idel_2d->getState(&audio_state);
					if ((audio_state & FMOD_EVENT_STATE_PLAYING) == 0)
						tank_idel_2d->start();
				}
				else
				{
					FMOD_EVENT_STATE audio_state = FMOD_EVENT_DEFAULT;
					if (tank_idel_2d)
					{
						tank_idel_2d->getState(&audio_state);
						if (audio_state & FMOD_EVENT_STATE_PLAYING)
							tank_idel_2d->stop();
					}
				}
			}
			else if (character->IsCarrierMode() )
			{
				tank_idel_2d = FmodSystem::GetEvent("bj/player/2d/tank01/idle");
			}
		}
		else
		{
			FMOD_EVENT_STATE audio_state = FMOD_EVENT_DEFAULT;

			if (audio_step)
			{
				audio_step->getState(&audio_state);
				if (audio_state & FMOD_EVENT_STATE_PLAYING)
					audio_step->stop();
			}

			audio_state = FMOD_EVENT_DEFAULT;
			if (tank_idel_2d)
			{
				tank_idel_2d->getState(&audio_state);
				if (audio_state & FMOD_EVENT_STATE_PLAYING)
					tank_idel_2d->stop();
			}
		}
	}

	/// get skeleton rotation
	const Quaternion & FirstPerson::GetSkeletonRotation()
	{
		return skeleton_rotation;

	}

	/// get skeleton position
	const Vector3 & FirstPerson::GetSkeletonPosition()
	{
		return skeleton_position;
	}

	/// get root position
	const Vector3 & FirstPerson::GetTorsoPosition()
	{
		return root_position;
	}

	/// set character
	void FirstPerson::SetCharacter(by_ptr(Character) c)
	{
		character = c;
	}

	bool FirstPerson::isSight()
	{
		if (character && character->ready)
		{
			//if player carries a sniper and open X1X2sight,don't draw gun and player
			tempc_ptr(WeaponBase) weapon = GetWeapon(character->weapon_id);
			if (weapon)
			{

				if(weapon->GetWeaponType() == kWeaponTypeSniperGun)
				{
					tempc_ptr(SniperGun) sniper_gun = ptr_dynamic_cast<SniperGun>(GetWeapon(character->weapon_id));
					if(sniper_gun)
					{
						tempc_ptr(SniperGunInfo) sniper_info = ptr_dynamic_cast<SniperGunInfo>(sniper_gun->gun_info);

						if (sniper_info && sniper_info->sight_info.Size()>=2 && character->camera_fov <= sniper_info->sight_info[1].level && character->GetViewMode() == Character::kFirstPerson)
						{
							return true;
						}
					}
				}

			}
		}
		return false;
	}

	/// throw grenade
	void FirstPerson::GrenadeThrowIn()
	{
		if (animation_group)
			animation_group->PlayAction("default_prepelt", "prepelt");

		if (gLevel->GetPlayer() == character)
			FmodSystem::PlayEvent("bj/weapon/2d/grenade/fire_01");
		
		tempc_ptr(Grenade) grenade = ptr_dynamic_cast<Grenade>(GetWeapon(character->weapon_id));
		if (grenade)
			grenade->ActionThrowIn();
	}

	/// grenade throw out
	void FirstPerson::GrenadeThrowOut(by_ptr(ThrowableInfo) info, int weapon_id)
	{
		tempc_ptr(WeaponBase) weapon = GetWeapon(weapon_id);
		if (weapon)
			weapon->SetVisible(false);

		if (character)
		{
			if (gLevel->GetPlayer() == character)
				if (character->character_info->career_id >= 20)
				{
					FmodSystem::PlayEvent("bj/weapon/2d/bio_skill/bio_skill_rock");
				} 
				else
				{
					FmodSystem::PlayEvent("bj/weapon/2d/grenade/fire_02");
				}	

			if (weapon_id == character->weapon_id)
			{
				float play_time = 0;
				if (info)
					play_time = info->throw_out_time;

				if (animation_group)
					animation_group->PlayAction("default_prepelt", "pelt", play_time);
			}
		}
	}

	/// stop throw grenade
	void FirstPerson::GrenadeThrowStop()
	{
		if (animation_group)
			animation_group->StopAction();
	}

	/// stop shooting
	void FirstPerson::StopShoot()
	{
		if (animation_group && (animation_group->IsNowNode("defaultshoot") || animation_group->IsNowNode("defaultshoot_notime")))
			animation_group->StopAction(false);
	}

	void FirstPerson::StartCharge()
	{
		if (animation_group)
		{
			animation_group->PlayAction("charge", "charge", 0.f);
		}
	}

	/// fire
	void FirstPerson::Shoot(int weapon_id, bool isboost)
	{
		tempc_ptr(GunBase) gun = ptr_dynamic_cast<GunBase>(GetWeapon(weapon_id));
		if (gun && character)
		{
			float play_time = 0;
			if (gun->gun_info)
				play_time = gun->gun_info->fire_time + character->fire_time_ratio;

			if (gun->GetWeaponType() == kWeaponTypeCureGun)
			{
				if (gun->gun_fire_particle)
					gun->gun_fire_particle->SetFirstPersonMode(true);
				return;
			}
			if (gun->GetWeaponType() == kWeaponTypeMiniMachineGun)
			{
			}
			else if (gun->GetWeaponType() == kWeaponTypeShotGun || gun->GetWeaponType() == kWeaponTypeDrum || gun->GetWeaponType() == kWeaponTypeLuncher || gun->GetWeaponType() == kWeaponTypeSignal)
			{
				if (animation_group)
				{
					animation_group->PlayAction("defaultshoot", "shoot", play_time);
				}
			}
			else
			{
				if (animation_group)
				{
   					animation_group->PlayAction("defaultshoot_notime", "shoot");
				}
			}

			if (gun->gun_bullet_particle)
				gun->gun_bullet_particle->SetFirstPersonMode(true);

			if (gun->gun_fire_particle)
				gun->gun_fire_particle->SetFirstPersonMode(true);

			if (character->GetViewMode() == Character::kFirstPerson)
			{
				gun->FireSound(false);
				gun->FireEffect(isboost);
			}
		}
	}

	// drop weapon
	void FirstPerson::DropWeapon(int slot)
	{
		if (character && !character->IsDied() && character_info)
		{
			if (character->GetViewMode() == Character::kFirstPerson)
			{
				FMOD::Event* audio_event = FmodSystem::PlayEvent(character_info->first_person_sound_weapon_drop);
			}
		}
	}

	// pick up weapon
	void FirstPerson::PickUpWeapon(int slot, by_ptr(WeaponInfo) info)
	{
		if (character_info)
		{
			if (character && character->GetViewMode() == Character::kFirstPerson)
			{
				FMOD::Event* audio_event = FmodSystem::PlayEvent(character_info->first_person_sound_weapon_pickup);
			}
		}
	}
	sharedc_ptr(Bomb) FirstPerson::GetBomb()
	{
		sharedc_ptr(Bomb) weapon = ptr_dynamic_cast<Bomb>(GetWeapon(BOMB_SLOT));

		return weapon;

	}

	void FirstPerson::PlantBomb()
	{
		if (!character)
			return;
		
		sharedc_ptr(Bomb) bomb = GetBomb();
		if(bomb)
		{
			if (animation_group)
				animation_group->PlayAction("default_pelt", "pelt");
			bomb->PlantBomb();
		}	
	}
	/// reload
	void FirstPerson::Reload()
	{
		if (!character)
			return;

		tempc_ptr(GunBase) gun = ptr_dynamic_cast<GunBase>(GetWeapon(character->weapon_id));

		if (gun)
		{
			if (gun->GetWeaponType() == kWeaponTypeShotGun)
			{
				if (animation_group)
					animation_group->PlayAction("shotgun_reload", "reloadone");
			}
			else if (gun->GetWeaponType() == kWeaponTypeLuncher)
			{
				tempc_ptr(Luncher) luncher = ptr_dynamic_cast<Luncher>(gun);
				if(luncher->GetLuncherAmmoType() == kWeaponTypeAmmoRocket && luncher->isReloadOneAmmo())
				{
					if (animation_group)
						animation_group->PlayAction("rocketlauncher_reload", "reloadone");
				}
				else
				{	
					float play_time = 0;
					if (gun->gun_info)
						play_time = gun->gun_info->reload_time;
					weapon_reload_total_time = play_time;
					weapon_reload_time = 0;
					if (animation_group)
						animation_group->PlayAction("defaultreload", "reload");
				}
			}
			else
			{
				float play_time = 0;
				if (gun->gun_info)
					play_time = gun->gun_info->reload_time;

				weapon_reload_total_time = play_time;
				weapon_reload_time = 0;
				if (animation_group)
					animation_group->PlayAction("defaultreload", "reload");
			}

			gun->ReloadAction();
			if (character->GetViewMode() == Character::kFirstPerson)
				gun->ReloadSound(false);
		}
	}

	/// stab
	void FirstPerson::Stab(byte type, int weapon_id)
	{
		float play_time = 0;
		tempc_ptr(Knife) knife = ptr_dynamic_cast<Knife>(GetWeapon(weapon_id));
		tempc_ptr(ZombieGun) zb_knif = ptr_dynamic_cast<ZombieGun>(GetWeapon(weapon_id));

		if (knife)
		{
			if (knife->knife_info)
			{
				if (type % 2)
					play_time = knife->knife_info->stab_time;
				else
					play_time = knife->knife_info->stab_light_time;
			}

			if (animation_group)
			{
				if (type % 2)
				{
					if (type == 1)
						animation_group->PlayAction("default_knife_stab", "stab", play_time);
					else
						animation_group->PlayAction("default_knife_stab", "stabhit", play_time);
				}
				else
					animation_group->PlayAction("default_knife_stab", "lightstab", play_time);
			}

			if (character->GetViewMode() == Character::kFirstPerson)
				knife->StabSound(type, false);
		}
		else if (zb_knif)
		{
			if (zb_knif->knife_info)
				play_time = zb_knif->knife_info->stab_light_time;

			if (type == 1)
				animation_group->PlayAction("default_knife_stab", "stab", play_time);
			else
				animation_group->PlayAction("default_knife_stab", "stabhit", play_time);

			if (character->GetViewMode() == Character::kFirstPerson)
				zb_knif->StabSound(type, false);
		}
	}

	/// stop stab
	void FirstPerson::StopStab()
	{
		if (animation_group)
			animation_group->StopAction();
	}

	/// select weapon
	void FirstPerson::SelectWeapon(uint id)
	{
		tempc_ptr(WeaponBase) weapon = GetWeapon(id);

		if (weapon)
		{
			weapon->ChangeIn();

			if (character && !character->IsDied() && character->GetViewMode() == Character::kFirstPerson)
				weapon->ChangeInSound();

			if (animation_set && id < animation_set_weapon.Size())
				animation_set->SetAnimationSet("weapon", animation_set_weapon[id]);

			float change_in_time = 0.f;
			if (weapon->weapon_info)
				change_in_time = weapon->weapon_info->change_in_time;

			if (animation_group)
				animation_group->PlayAction("defaultchange", "change");

			if (animation_group && weapon->weapon_info)
			{
				switch (weapon->weapon_info->weapon_type)
				{
				case kWeaponTypeLuncher:
				case kWeaponTypeSignal:
					{
						tempc_ptr(Luncher) gun = ptr_dynamic_cast<Luncher>(weapon);
						animation_group->RegisterEvent(gun);
					}
					break;
				case kWeaponTypeShotGun:
					{
						tempc_ptr(ShotGun) gun = ptr_dynamic_cast<ShotGun>(weapon);
						animation_group->RegisterEvent(gun);
					}
					break;
				case kWeaponTypeCureGun:
					{
						tempc_ptr(CureGun) gun = ptr_dynamic_cast<CureGun>(weapon);
						animation_group->RegisterEvent(gun);
					}
					break;
				case kWeaponTypeMiniMachineGun:
					{
						tempc_ptr(MiniMachineGun) gun = ptr_dynamic_cast<MiniMachineGun>(weapon);
						animation_group->RegisterEvent(gun);
					}
					break;
				default:
						animation_group->RegisterEvent(NullPtr);
					break;
				}
			}
		}
	}

	/// weapon active
	void FirstPerson::WeaponActive(uint id)
	{
		tempc_ptr(WeaponBase) weapon= GetWeapon(id);
		if (weapon)
			weapon->Active();
	}

	/// weapon inactive
	void FirstPerson::WeaponInactive(uint id)
	{
		tempc_ptr(WeaponBase) weapon = GetWeapon(id);
		if (weapon)
			weapon->Inactive();
	}

	/// udpate weapon
	void FirstPerson::UpdateWeapon(float frame_time)
	{
		PROFILE("FirstPerson::UpdateWeapon");

		tempc_ptr(WeaponBase) weapon;

		if (character)
			weapon = GetWeapon(character->weapon_id);

		if (skeleton && pose && weapon && weapon->weapon_info)
		{
			int joint_id = -1;

			switch (weapon->weapon_info->hand_bind_type)
			{
			case WeaponInfo::kHandLeft:
				joint_id = skeleton->GetJointId("handweapon_l");
				break;

			default:
				joint_id = skeleton->GetJointId("handweapon_r");
				break;
			}

			if (joint_id >= 0)
			{
				Vector3 pos;
				Quaternion rot;

				if(weapon->GetWeaponType()!=kWeaponTypeDualPistol)
				{
					const Transform & transform = pose->GetJointModelPose(joint_id);

					pos = GetSkeletonPosition() + transform.position * GetSkeletonRotation();
					rot = transform.rotation * GetSkeletonRotation();
				}
				else
				{
					tempc_ptr(DualPistol) pistol = ptr_dynamic_cast<DualPistol>(weapon);
					if (pistol)
					{
						joint_id = skeleton->GetJointId("handweapon_l");
						const Transform & left_transform = pose->GetJointModelPose(joint_id);
						pistol->SetLeftWeaponTransform(left_transform);

						joint_id = skeleton->GetJointId("handweapon_r");
						const Transform & right_transform  = pose->GetJointModelPose(joint_id);
						pistol->SetRightWeaponTransform(right_transform);
					}

					pos = GetSkeletonPosition();
					rot = GetSkeletonRotation();
				}

				weapon->SetPosition(pos);
				weapon->SetRotation(rot);
			}

			weapon->UpdateMesh();
		}
	}

	/// udpate equipment
	void FirstPerson::UpdateEquipment(float frame_time)
	{
		PROFILE("FirstPerson::UpdateEquipment");

		tempc_ptr(WeaponBase) weapon;

		if (character)
			weapon = GetWeapon(character->equipment_id);

		if (skeleton && pose && weapon && weapon->weapon_info)
		{
			tempc_ptr(Equipment) equip = ptr_dynamic_cast<Equipment>(weapon);
			if(equip)
			{
				if (equip->bandjoint_id >= 0)
				{
					Vector3 pos;
					Quaternion rot;

						const Transform & transform = pose->GetJointModelPose(equip->bandjoint_id);

						pos = GetSkeletonPosition() + transform.position * GetSkeletonRotation();
						rot = transform.rotation * GetSkeletonRotation();

					weapon->SetPosition(pos);
					weapon->SetRotation(rot);
				}

			}
			weapon->UpdateMesh();
		}
	}


	/// response hit
	void FirstPerson::ResponseHit(const Vector3 & from_position, const Vector3 & target, const Vector3 & normal, int part,  UINT weapontype, bool no_blood, bool isboost)
	{
		tempc_ptr(WeaponBase) weapon = GetWeapon(character->weapon_id);
		if (weapon)
			weapon->ActionOnHit();
	}


	/// on kill
	void FirstPerson::OnKill(const HitInfo & info)
	{

	}


	/// on hit
	void FirstPerson::OnHit(const HitInfo & info)
	{
		// play sound
		if (info.hp > 0)
		{
			if (character && character->GetViewMode() == Character::kFirstPerson)
			{
				//FMOD::Event* audio_event = NULL;
				//audio_event = FmodSystem::PlayEvent("o2o/player_2d/bhit");
				if (info.part == 3)
				{
					//if(character->is_boss && character->hp < character->max_hp/3)
					//{
					//	dizzy_time += 0.5f;
					//}
					//else
					//{
						dizzy_time = 0.5f;
					//}
					bdizzy = true;
				}
			}
			else
			{
				bdizzy = false;
			}
		}
	}

	/// on grenade explode
	void FirstPerson::OnGrenadeExplode()
	{
		// camera animation
		if (animation_camera)
			animation_camera->PlayAction("camhit", 0.f);
	}

	/// on bomb explode
	void FirstPerson::OnBombExploded()
	{
		// camera animation
		if (animation_camera && character && !character->IsDied())
			animation_camera->PlayAction("camhit", 0.f);
	}

	/// jump
	void FirstPerson::OnJump()
	{
	}

	/// boost
	void FirstPerson::OnBoost(int dir)
	{
	}

	/// on ground
	void FirstPerson::OnOnground()
	{
	}

	/// fall down
	void FirstPerson::FallDown(float speed, bool is_onground)
	{
		// play sound
		if (character && character->GetViewMode() == Character::kFirstPerson)
		{

		}
	}

	/// die
	void FirstPerson::Die(const HitInfo & hit)
	{
		if (character)
		{
			if (character->GetViewMode() == Character::kFirstPerson)
			{
				if (character_info)
				{	
					if (character->is_boss)
					{
						String str = String::Format("bj/player/2d/boss/death");
						FmodSystem::PlayEvent(str.Str());
					}
					else if (gLevel->game_type == RoomOption::kCommonZombieMode && character_info->career_id == 43)
					{
						Core::String str = Core::String::Format("bj/player/2d/bio/bioshadow_death");
						FmodSystem::PlayEvent(str.Str());
					}
					else if (gLevel && gLevel->game_type == RoomOption::kZombieMode && character->GetTeam() == 1)
					{
						if (character->GetCurCharinfo()->career_id == DEFAULT_ZOMBIE_KING)
						{
							FmodSystem::PlayEvent("bj/player/2d/bio/bioking_death");
						} 
						else
						{
							FmodSystem::PlayEvent("bj/player/2d/bio/bio_death");
						}
					} 
					else if (character->IsCarrierMode() )
					{
						FmodSystem::PlayEvent("bj/player/2d/tank01/death");
					}
					else
					{
						String str = String::Format("bj/player/2d/%s/death",character_info->res_key);
						FmodSystem::PlayEvent(str.Str());
					}
				}
			}

			if (animation_camera)
				animation_camera->PlayAction("camdie", 0.f, false, 0.f, true);
			
			tempc_ptr(SniperGun) gun = ptr_dynamic_cast<SniperGun>(GetWeapon(character->weapon_id));
			if (gun)
				gun->SetSight(0);
		}
	}

	/// rebirth
	void FirstPerson::Rebirth()
	{
		draw_mesh = mesh;

		// stop animation
		if (animation_camera)
			animation_camera->StopAction();
	}

	/// get camera position
	const Vector3 & FirstPerson::GetCameraPosition()
	{
		return camera_position;

	}

	/// get camera rotation
	const Quaternion & FirstPerson::GetCameraRotation()
	{
		return camera_rotation;
	}

	/// set weapon
	void FirstPerson::SetWeapon(int slot, by_ptr(WeaponInfo) info)
	{
		if (character && slot >= 0 && slot < 7)
		{
			sharedc_ptr(WeaponBase) w;
			CStrBuf<256> str_animation;

			if (info)
			{
				w = character->CreateWeapon(info);
				if (w)
				{
					w->is_for_player = true;
					w->SetOwner(character);
					w->Initialize();
				}

				if (character_info)
					str_animation.format("%s/%s", character_info->first_person_animationset, info->animation_set);
			}
			else
			{
				if (character_info)
					str_animation.format("%s/pose", character_info->first_person_animationset);
			}

			animation_set_weapon[slot] = RESOURCE_GET_BYTYPE(RESOURCE_NAME(ANIMATION_KEY_PLAYER, str_animation), ANIMATIONSET_TYPE, AnimationSetRes);
			if (animation_set_weapon[slot])
				animation_set_weapon[slot]->Load(true);

			if (weapons[slot])
				weapons[slot]->Inactive();

			weapons[slot] = w;

			if (animation_set && slot == character->weapon_id)
				animation_set->SetAnimationSet("weapon", animation_set_weapon[slot]);
		}
	}

	/// get weapon
	tempc_ptr(WeaponBase) FirstPerson::GetWeapon(int id)
	{
		if (id >= 0 && id < 7)
			return weapons[id];

		return NullPtr;
	}

	/// set character info
	void FirstPerson::SetCharacterInfo(by_ptr(CharacterInfo) info)
	{
		character_info = info;
	}

	/// preload animation
	void FirstPerson::PreloadAnimation(by_ptr(WeaponInfo) info)
	{
		if (info && character_info)
		{
			CStrBuf<256> str;
			str.format("%s/%s", character_info->first_person_animationset, info->animation_set);
			sharedc_ptr(AnimationSetRes) res = RESOURCE_GET_BYTYPE(RESOURCE_NAME(ANIMATION_KEY_PLAYER, str), ANIMATIONSET_TYPE, AnimationSetRes);
			if (res)
			{
				res->Load(true);
				if (gLevel->animation_manager)
					gLevel->animation_manager->AddAnimationSetRes(res->GetKey(), res);
			}
		}
	}

	/// preload animation
	void FirstPerson::PreloadAnimation(const PackInfo & info)
	{
		for (uint i = 0; i < info.weapon_set.Size(); ++i)
		{
			PreloadAnimation(info.weapon_set[i]);
		}
	}

	/// use skill
	void FirstPerson::UseSkill(by_ptr(PlayerSkill) skill)
	{
		if (character && skill)
		{

		}
	}

	/// use skill stop
	void FirstPerson::UseSkillStop(by_ptr(PlayerSkill) skill)
	{
		if (character && skill)
		{
			
		}
	}

	/// recover
	void FirstPerson::Recover(int health,byte recover_type)
	{
	}
	/// ammorecover
	void FirstPerson::AmmoRecover(short ammocount,byte recovertype)
	{
	
	}

	/// recover stop
	void FirstPerson::RecoverStop()
	{
	}
	/// burn
	void FirstPerson::Burn()
	{
		
	}
	/// burn stop
	void FirstPerson::BurnStop()
	{

	}

	/// poison
	void FirstPerson::Poison()
	{

	}
	/// poison stop
	void FirstPerson::PoisonStop()
	{

	}
	/// has bomb
	//bool FirstPerson::HasBomb()
	//{
	//	for (uint i = 0; i < weapons.Size(); ++i)
	//	{
	//		if (weapons[i] && weapons[i]->GetWeaponType() == kWeaponTypeBomb)
	//			return true;
	//	}

	//	return false;
	//}
}

namespace Client
{
	void  FirstPerson::UpdateAnimationJoint(float frame_time)
	{
		PROFILE("FirstPerson::UpdateAnimationJoint");

		if (!skeleton)
			return;

		if (!animation_system)
			return;

		if (!pose)
			return;

		tempc_ptr(Pose) animation_pose = animation_system->GetPose();

		if (animation_pose)
			pose->CopyLocalPose(animation_pose->GetLocalPose());
		else
			pose->CopyLocalPose(skeleton->GetLocalPose());

		pose->UpdateModelPose(true);

		if (pose)
			root_position = pose->GetJointModelPose(skeleton->GetJointId("torso")).position - Vector3(0, 1, 0);
	}

	/// create animation set
	void FirstPerson::CreateAnimation()
	{
		if (!character_info)
			return;

		animation_set = ptr_new AnimationSet;

		//CStrBuf<256> str;
		//str.format("%s/%s", character_info->first_person_animationset, "camera");
		//sharedc_ptr(AnimationSetRes) res = RESOURCE_GET_BYTYPE(RESOURCE_NAME(ANIMATION_KEY_PLAYER, str), ANIMATIONSET_TYPE, AnimationSetRes);
		//if (res)
		//{
		//	res->Load(true);
		//	if (gLevel->animation_manager)
		//		gLevel->animation_manager->AddAnimationSetRes(res->GetKey(), res);
		//}

		//animation_set->SetAnimationSet("camera", res);

		//str.format("%s/%s", character_info->first_person_animationset, "pose");
		//res = RESOURCE_GET_BYTYPE(RESOURCE_NAME(ANIMATION_KEY_PLAYER, str), ANIMATIONSET_TYPE, AnimationSetRes);
		//if (res)
		//{
		//	res->Load(true);
		//	if (gLevel->animation_manager)
		//		gLevel->animation_manager->AddAnimationSetRes(res->GetKey(), res);
		//}

		//animation_set->SetAnimationSet("weapon", res);

		//str.format("%s/%s", character_info->first_person_animationset, "biochemical");
		//animation_set_zombie = RESOURCE_GET_BYTYPE(RESOURCE_NAME(ANIMATION_KEY_PLAYER, str), ANIMATIONSET_TYPE, AnimationSetRes);
		//if (animation_set_zombie)
		//{
		//	animation_set_zombie->Load(true);
		//	if (gLevel->animation_manager)
		//		gLevel->animation_manager->AddAnimationSetRes(res->GetKey(), animation_set_zombie);
		//}

		// create animation system
		animation_system = ptr_new AnimationNodeBlend(skeleton);

		animation_list = ptr_new AnimationNodeList();
		animation_group = ptr_new AnimationNodeGroup(skeleton);
		animation_group->SetAnimationSet(animation_set);
		animation_group->SetAnimationNode(animation_list);
		animation_group->SetFirstPerson();
		animation_group->LoadGroupNode("group_action");

		sharedc_ptr(BlendInfo) action_info = ptr_new BlendInfo;
		action_info->node = animation_group->node_action;
		action_info->map = ptr_new SkeletonMap(skeleton);
		action_info->map->AddJoint("root", false);
		animation_system->AddNodeByInfo(action_info);

		animation_camera = ptr_new AnimationNodeCustom(skeleton);
		animation_camera->SetAnimationSet(animation_set);

		sharedc_ptr(BlendInfo) camera_info = ptr_new BlendInfo;
		camera_info->node = animation_camera;
		camera_info->map = ptr_new SkeletonMap(skeleton);
		camera_info->map->AddJoint("cam", true, SkeletonMap::kAddtive);
		animation_system->AddNodeByInfo(camera_info);

		sharedc_ptr(AnimationNodePose) pose = ptr_new AnimationNodePose(skeleton);
		pose->SetAnimation("idle", animation_set);
		animation_list->AddNode("idle", pose);

		pose = ptr_new AnimationNodePose(skeleton);
		pose->SetAnimation("run", animation_set);
		animation_list->AddNode("run", pose);

		//pose = ptr_new AnimationNodePose(skeleton);
		//pose->SetAnimation("walk", animation_set);
		//animation_list->AddNode("walk", pose);

		pose = ptr_new AnimationNodePose(skeleton);
		pose->SetAnimation("shot", animation_set);
		animation_list->AddNode("shot", pose);

		pose = ptr_new AnimationNodePose(skeleton);
		pose->SetAnimation("crouch_move", animation_set);
		animation_list->AddNode("crouch_move", pose);

		pose = ptr_new AnimationNodePose(skeleton);
		pose->SetAnimation("reload", animation_set);
		animation_list->AddNode("reload", pose);

		animation_list->SetActiveNode("idle");

	}

	const AxisAlignedBox& FirstPerson::GetWorldAABB() const
	{
		return world_aabb;
	}



	void FirstPerson::LoadSkeleton()
	{
		skeleton = RESOURCE_LOAD(character_info->first_person_skeleton, false, Skeleton);
	}

#if DEBUG_TOOLS
	void FirstPerson::UpdateModelViewer(float frame_time)
	{
		if (!character)
			return;

		// update animation joint
		if (character->occluded == false)
		{
			if (character->GetViewMode() == Character::kFirstPerson)
			{
				// update mesh
				if (draw_mesh)
				{
					draw_mesh->pose = pose;
					draw_mesh->Update();
				}
			}
		}

		// update bounding box
		UpdateBoundingBox();
	}
	void FirstPerson::UpdateAnimationFirstPersonForViewer(float frame_time)
	{
		if (!character)
			return;

		UpdateModelViewer(frame_time);

		UpdateAnimation(frame_time);

		UpdateAnimationJoint(frame_time);

		UpdateTransform(frame_time);

		UpdateWeapon(frame_time);
		UpdateEquipment(frame_time);
		if (mesh)
			mesh->Update(); 
	}






#endif
}