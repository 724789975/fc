#include "pch.h"

using namespace Core;

namespace Client
{
	/// constructor
	ActionController::ActionController()
	{
	}

	/// update
	void ActionController::Update(float frame_time)
	{
	}

	/// die
	void ActionController::Die(const HitInfo & info)
	{
	}

	/// rebirth
	void ActionController::Rebirth()
	{		
		if (character)
			character->camera_rotation_offset = Quaternion::kIdentity;
	}

	/// grenade throw in
	bool ActionController::GrenadeThrowIn()
	{
		return character && !character->throwing_grenade;
	}

	/// grenade ready
	void ActionController::GrenadeReady()
	{
	}

	/// grenade throw request
	void ActionController::GrenadeThrowRequest(byte type)
	{
	}

	/// grenade throw out
	bool ActionController::GrenadeThrowOut(by_ptr(ThrowableInfo) info, const Core::Vector3 & position, const Core::Vector3 & direction)
	{
		return true;
	}

	/// stop throw grenade
	bool ActionController::GrenadeThrowStop()
	{
		return character && character->throwing_grenade;
	}

	/// knife stab
	bool ActionController::Stab(byte type)
	{
		return true;
	}

	/// stop stab
	bool ActionController::StopStab()
	{
		return true;
	}

	/// stop shooting
	bool ActionController::StopShoot()
	{
		return true;
	}

	/// fire
	bool ActionController::Shoot(const Core::Vector3 & dir, bool isboost)
	{
		if (character)
		{
			bool flag = false;
			if(gLevel->GetViewer() == character)
			{
				flag = true;
			}
			tempc_ptr(GunBase) gun = ptr_dynamic_cast<GunBase>(character->GetWeapon(flag));

			if (gun)
			{
				float bullet_distance = 0;
				float distance = 500;
				Vector3 fire_pos;
				
				if (!gun->has_trajectory && gun->GetJointInfo("Gun_Fire", &fire_pos, NULL))
				{
					//fix occluded bug
				/*	if(character->occluded)
					{
						fire_pos = character->GetPosition() +Vector3(0, 1, 0);
					}*/
					// check decal
					NxRay ray;
					ray.orig = (const NxVec3 &)fire_pos;
					ray.dir = (const NxVec3 &)Normalize(dir);

					NxRaycastHit hit;

					uint group_id = 0;
					group_id |= 1 << PhysxSystem::kStatic;
					group_id |= 1 << PhysxSystem::kStaticRaycast;
					group_id |= 1 << PhysxSystem::kGroupVehicle;
					//group_id |= 1 << PhysxSystem::kPlayer;
					for (uint i = 0; i < 2; ++i)
					{
						if ((!gLevel->team_hurt) && i == character->GetTeam())
							continue;

						group_id |= 1 << (PhysxSystem::kGroupStart + i);
					}

					NxShape* shape = gPhysxScene->raycastClosestShape(ray, NX_ALL_SHAPES, hit, group_id, distance);

					if (shape)
					{
						NxActor& actor = shape->getActor();

						tempc_ptr(Character) p = Character::FromNxActor(actor);

						if (p)
						{

							int part = p->GetActorId(&actor);
							Vector3 target(hit.worldImpact.x, hit.worldImpact.y, hit.worldImpact.z);
							Vector3 normal(hit.worldNormal.x, hit.worldNormal.y, hit.worldNormal.z);

							p->ResponseHit(fire_pos, target, normal, part, gun->GetWeaponType(),false, isboost);

						}
						else
						{
							if(gLevel->GetPlayer() != character)
							{
								gLevel->AddBulletImpact((const Vector3 &)hit.worldImpact, (const Vector3 &)hit.worldNormal, hit.materialIndex);
							}
							
						}

						bullet_distance = hit.distance;
					}
					if(bullet_distance >= 0.0005f)
					{
						if (gun  &&
							     (gun->gun_info->sight_info.Size() <= 1 
							      || character != gLevel->GetViewer()
							      || (gun->gun_info->sight_info.Size() > 1 && character->camera_fov > gun->gun_info->sight_info[1].level)
								  || gun->gun_info->weapon_type == kWeaponTypeSniperGun		      
								 )		
							)			      
						{
							// add bullet
							gLevel->bullet_manager->Add(fire_pos, Quaternion(Vector3(0, 0, -1), dir), bullet_distance,character->GetTeam(),isboost);
						}		
					}
				}

				return true;
			}
		}

		return false;
	}


	/// fire
	bool ActionController::Shoot(const Core::Vector3 & position, const Core::Vector3 & dir,bool isboost)
	{
		if (character)
		{
			bool flag = false;
			if(gLevel->GetViewer() == character)
			{
				flag = true;
			}

			tempc_ptr(GunBase) gun = ptr_dynamic_cast<GunBase>(character->GetWeapon(flag));

			if (gun)
			{
				float bullet_distance = 0;
				float distance = 500;
				Vector3 fire_pos;

				
				if (!gun->has_trajectory && gun->GetJointInfo("Gun_Fire", &fire_pos, NULL))
				{
					// check decal
					NxRay ray;
					ray.orig = (const NxVec3 &)position;
					ray.dir = (const NxVec3 &)Normalize(dir);

					NxRaycastHit hit;

					uint group_id = 0;
					group_id |= 1 << PhysxSystem::kStatic;
					group_id |= 1 << PhysxSystem::kStaticRaycast;
					group_id |= 1 << PhysxSystem::kGroupVehicle;
					//group_id |= 1 << PhysxSystem::kPlayer;
					for (uint i = 0; i < 2; ++i)
					{
						if ((!gLevel->team_hurt) && i == character->GetTeam())
							continue;

						group_id |= 1 << (PhysxSystem::kGroupStart + i);
					}

					NxShape* shape = gPhysxScene->raycastClosestShape(ray, NX_ALL_SHAPES, hit, group_id, distance);

					if (shape)
					{
						NxActor& actor = shape->getActor();

						tempc_ptr(Character) p = Character::FromNxActor(actor);

						if (p)
						{

							int part = p->GetActorId(&actor);
							Vector3 target(hit.worldImpact.x, hit.worldImpact.y, hit.worldImpact.z);
							Vector3 normal(hit.worldNormal.x, hit.worldNormal.y, hit.worldNormal.z);

							p->ResponseHit(fire_pos, target, normal, part, gun->GetWeaponType(),false, isboost);

						}
						else
						{
							if(gLevel->GetPlayer() != character)
							{
								gLevel->AddBulletImpact((const Vector3 &)hit.worldImpact, (const Vector3 &)hit.worldNormal, hit.materialIndex);
							}

						}

						bullet_distance = hit.distance;
					}
					if(bullet_distance >= 0.0005f)
					{
						if (gun && gun->sight_current == 0)
						{
							// add bullet
							gLevel->bullet_manager->Add(fire_pos, Quaternion(Vector3(0, 0, -1), dir), bullet_distance,character->GetTeam(), isboost);
						}		
						else if(gun->gun_info->weapon_type == kWeaponTypeSniperGun)
						{
							// add bullet
							gLevel->bullet_manager->Add(fire_pos, Quaternion(Vector3(0, 0, -1), dir), bullet_distance, character->GetTeam(), isboost);
						}
					}
				}

				return true;
			}
		}

		return false;
	}


	/// reload
	bool ActionController::Reload()
	{
		return true;
	}

	bool ActionController::PlantBomb()
	{
		return true;
	}

	/// reload ready
	void ActionController::ReloadReady(int count)
	{
		if (character && !character->IsDied())
		{
			tempc_ptr(GunBase) gun = ptr_dynamic_cast<GunBase>(character->GetWeapon(true));

			if (gun)
			{
				gun->ammo_in_clip += count;
				gun->ammo_count -= count;
			}
		}
	}

	/// select weapon
	bool ActionController::SelectWeapon(uint id, bool force)
	{
		if (character && !character->IsDied() && id < kWeaponTypeCount && (force || character->weapon_id != id))
		{
			if (character->GetWeaponById(id))
				return true;
		}

		return false;
	}

	/// set weapon
	bool ActionController::SetWeapon(int slot, by_ptr(WeaponInfo) info)
	{
		return slot >= 0 && slot < 7;
	}

	// drop weapon
	bool ActionController::DropWeapon(int slot)
	{
		return true;
	}

	// pick up weapon
	void ActionController::PickUpWeapon(int slot, by_ptr(WeaponInfo) info)
	{
	}

	/// set character
	void ActionController::SetCharacter(by_ptr(Character) c)
	{
		character = c;
	}

	/// set camera fov
	void ActionController::SetCameraFov(float fov, float target_fov)
	{
	}

	/// use skill request
	void ActionController::UseSkillRequest(tempc_ptr(PlayerSkill) skill)
	{
	}

	/// use skill
	void ActionController::UseSkill(tempc_ptr(PlayerSkill) skill)
	{
	}

	/// fall down
	void ActionController::FallDown(float speed, bool is_onground)
	{
	}

	/// on hit character
	void ActionController::OnHitCharacter(tempc_ptr(Character) hit_character)
	{
	}
}

namespace Client
{
	/// constructor
	PlayerAction::PlayerAction()
		: change_in_time(0)
		, selecting_weapon(false)
		, first_action_on(false)
		, second_action_on(false)
	{
	}

	/// update
	void PlayerAction::Update(float frame_time)
	{
		if (!character)
			return;

		{
			UpdateWeapon(frame_time);
			tempc_ptr(WeaponBase) weapon = character->GetWeapon();
			if (weapon)
				weapon->Update(frame_time);
		}
	}

	/// update weapon
	void PlayerAction::UpdateWeapon(float frame_time)
	{
		if (!character)
			return;

		tempc_ptr(WeaponBase) weapon = character->GetWeapon();

		if (weapon && weapon->weapon_info)
		{
			if (character->weapon_select_state > Character::kWeaponReady)
			{
				change_in_time -= frame_time;
				if (change_in_time <= 0)
				{
					change_in_time = 0;
					switch (character->weapon_select_state)
					{
					case Character::kWeaponChangeOut:
						break;

					case Character::kWeaponChangeIn:
						selecting_weapon = false;
						character->weapon_select_state = Character::kWeaponReady;
						break;

					default:
						break;
					}
				}
			}
		}
	}

	/// die
	void PlayerAction::Die(const HitInfo & info)
	{
		if (character)
		{
		}
	}

	/// rebirth
	void PlayerAction::Rebirth()
	{
		if (character)
		{
			character->camera_distance = 0;
			character->camera_rotation_offset = Quaternion::kIdentity;
			character->camera_control_mode = Camera::kCharacterControl;
		}

		first_action_on = false;
		second_action_on = false;

		gGame->camera->control_mode = Camera::kCharacterControl;

	}

	/// grenade throw in
	bool PlayerAction::GrenadeThrowIn()
	{
		if (character && !character->throwing_grenade)
		{
			if (gGame->channel_connection)
				gGame->channel_connection->GrenadeThrowIn();
			return true;
		}

		return false;
	}

	/// grenade ready
	void PlayerAction::GrenadeReady()
	{
	}

	/// grenade throw request
	void PlayerAction::GrenadeThrowRequest(byte type)
	{
		if (character && character->throwing_grenade)
		{
			Vector3 grenade_pos = character->GetCameraPosition() + Vector3(0, -0.05f, 0);
			Vector3 throw_dir = Vector3(0, 0, -1) * character->GetLookDir();

			Vector3 front_dir = Vector3(0, 0, -1) * character->GetRotation();
			Vector3 right_dir = Vector3(1, 0, 0) * character->GetRotation();
			grenade_pos = grenade_pos + right_dir/3 + front_dir/3;
			float throw_dot = Max(0.f, Dot(throw_dir, front_dir));
			throw_dir = throw_dir * Quaternion(right_dir, 10 * DEG2RAD * Pow(throw_dot, 3));
			Vector3 grenade_velocity = throw_dir * character->GetThrowVelocity();

			if (character->IsDied())
			{
				grenade_velocity *= 0;
			}
			else
			{
				Vector3 horizon_velocity(grenade_velocity.x, 0, grenade_velocity.z);
				horizon_velocity.Normalize();

				const Vector3 & current_speed = character->GetCurrentSpeed();
				float dot = Dot(horizon_velocity, Normalize(current_speed));
				float speed_length = current_speed.Length();
				speed_length *= dot;
				speed_length = Clamp(speed_length, -3, 3);

				horizon_velocity *= speed_length;
				grenade_velocity += horizon_velocity;
			}

			if (gGame->channel_connection)
				gGame->channel_connection->GrenadeThrowOut(character->weapon_id, grenade_pos, grenade_velocity);
		}
	}

	/// stop throw grenade
	bool PlayerAction::GrenadeThrowStop()
	{
		if (character && character->throwing_grenade)
		{
			if (gGame->channel_connection)
				gGame->channel_connection->GrenadeThrowStop();

			return true;
		}
		return false;
	}

	/// knife stab
	bool PlayerAction::Stab(byte type)
	{
		return character && character->CanStab() && type;
	}

	/// stop stab
	bool PlayerAction::StopStab()
	{
		return character && character->stabing;
	}

	/// fire
	bool PlayerAction::Shoot(const Core::Vector3 & dir,bool isboost)
	{
		return ActionController::Shoot(dir,isboost);
		return true;
	}

	/// stop shooting
	bool PlayerAction::StopShoot()
	{
		return character && character->shooting;
	}

	bool PlayerAction::PlantBomb()
	{
		return character && !character->planting_bomb;
	}
	/// reload
	bool PlayerAction::Reload()
	{
		if (character && character->CanReload())
		{
			tempc_ptr(GunBase) weapon_gun = ptr_dynamic_cast<GunBase>(character->GetWeapon());

			if (weapon_gun)
			{
				if (weapon_gun->Reload())
				{
					if (gGame->channel_connection)
					{
						int ammo_need = weapon_gun->gun_info->ammo_one_clip - weapon_gun->ammo_in_clip;
						ammo_need = (ammo_need < weapon_gun->ammo_count ? ammo_need : weapon_gun->ammo_count);
						gGame->channel_connection->Reload(short(ammo_need));
					}
					return true;
				}
			}
		}

		return false;
	}

	/// reload ready
	void PlayerAction::ReloadReady(int count)
	{
		if (gGame->channel_connection)
			gGame->channel_connection->ReloadReady(count);
	}

	/// select weapon
	bool PlayerAction::SelectWeapon(uint id, bool force)
	{
		if (character && !character->IsDied() && id < kWeaponTypeCount && (force || character->weapon_id != id))
		{
			if(id == BOMB_SLOT && !character->HasBomb())
				return false;

			character->RevertToRawCharacterChangeableInfo();

			tempc_ptr(WeaponBase) w = character->GetWeaponById(id);
			if (w && w->CanActive())
			{
				change_in_time = 0;

				if (w->weapon_info)
					change_in_time = w->weapon_info->change_in_time;

				selecting_weapon = true;

				if (gGame->channel_connection)
					gGame->channel_connection->SelectWeapon(id);

				return true;
			}
		}

		return false;
	}

	/// set weapon
	bool PlayerAction::SetWeapon(int slot, by_ptr(WeaponInfo) info)
	{
		return  slot >= 0 && slot < 7;
	}

	// drop weapon
	bool PlayerAction::DropWeapon(int slot)
	{
		if (character)
		{
			tempc_ptr(WeaponBase) w =  character->GetWeaponById(slot);

			if (w) 
			{
				byte type = w->GetWeaponType();

				if ((type > kWeaponTypePistol && type < kWeaponTypeKnife) || type == kWeaponTypeBomb)
				{
					if (gGame->channel_connection)
						gGame->channel_connection->DropWeapon();

					tempc_ptr(GunBase) gun = ptr_dynamic_cast<GunBase>(w);

					if (gun && gun->sight_current > 0)
					{
						gun->sight_current = 0;
						gun->SetSight(gun->sight_current);
					}

					character->ChangeWeapon();
					return true;
				}
			}
		}

		return false;
	}

	// pick up weapon
	void PlayerAction::PickUpWeapon(int slot, by_ptr(WeaponInfo) info)
	{
	}

	/// set camera fov
	void PlayerAction::SetCameraFov(float fov, float target_fov)
	{
		if (gGame->channel_connection)
			gGame->channel_connection->CameraFovChanged(fov, target_fov);
	}

	/// use skill request
	void PlayerAction::UseSkillRequest(tempc_ptr(PlayerSkill) skill)
	{
		if (skill)
		{
			//if (!skill->is_using
			//	&& !skill->is_cooldowning)
			//{
			//	if (gGame->channel_connection)
			//		gGame->channel_connection->UseSkill(skill);
			//}
		}
	}

	/// use skill
	void PlayerAction::UseSkill(tempc_ptr(PlayerSkill) skill)
	{
		if (skill)
		{
			/*switch (skill->type)
			{
			case kSkillTeleport:
				if (character && character->hero_type == 0)
				{
					const Core::Array<sharedc_ptr(Character)>& characters = gLevel->GetCharacters();

					for (uint i = 0; i < characters.Size(); i++)
					{
						tempc_ptr(Character) c = characters[i];
						if (c && !c->IsDied() && c->hero_type > 0)
						{
							if (c->GetTeam() == character->GetTeam())
								character->SetPosition(c->GetPosition());

							break;
						}
					}

				}
				break;
			}*/
		}
	}

	/// fall down
	void PlayerAction::FallDown(float speed, bool is_onground)
	{
		// hurt
		gGame->channel_connection->SelfHurt(speed);
	}

}