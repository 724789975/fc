#include "pch.h"
using namespace Core;

namespace Client
{
	/// constructor
	DetachablePart::DetachablePart()
		: actor(NULL)
		, is_died(false)
		, died_timer(15.f)
		, animation_timer(0.f)
	{
		position = Vector3::kZero;
		rotation = Quaternion::kIdentity;
	}

	/// destructor
	DetachablePart::~DetachablePart()
	{
		mesh = NullPtr;
		skeleton = NullPtr;

		if (actor)
		{
			PhysxSystem::ReleaseActor(*actor);
			actor = NULL;
		}
	}

	/// stop action
	void DetachablePart::StopAction()
	{
		if (animation)
			animation->StopAction(true);
	}

	/// play action
	void DetachablePart::PlayAction(const Core::Identifier & key, float play_time)
	{
		if (animation)
			animation->PlayAction(key,0.2f,true);

		animation_timer = play_time;
	}

	/// set animation set
	void DetachablePart::SetAnimationSet(const char * key)
	{
		if (animation)
		{
			sharedc_ptr(AnimationSetRes) res = RESOURCE_GET_BYTYPE(RESOURCE_NAME(ANIMATION_KEY_PROP_CHARACTER, key), ANIMATIONSET_TYPE, AnimationSetRes);
			if (res)
			{
				res->Load(false);
				sharedc_ptr(AnimationSet) animset = res->GetAnimationSet();
				if (gLevel->animation_manager)
					gLevel->animation_manager->AddAnimationSetRes(res->GetKey(), res);

				Array<Core::Identifier> animation_keylist = animset->GetAnimationSetKeyList();
				sharedc_ptr(AnimationNodeList) node_list = ptr_new AnimationNodeList();
				for(uint i = 0; i < animation_keylist.Size(); i++)
				{
					sharedc_ptr(AnimationNodePose) node_pose = ptr_new AnimationNodePose(skeleton);
					node_pose->SetAnimation(animation_keylist[i], animset);
					node_list->AddNode(animation_keylist[i], node_pose);
				}
				animation->SetAnimationSet(animset);
				animation->SetAnimationNode(node_list);
				StopAction();
			}
		}
	}

	/// initialize
	bool DetachablePart::Initialize(by_ptr(Character) character, const DetachablePartInfo &part_info)
	{
		if (!character)
		{
			return false;
		}

		bool hasMesh = false;
		bool hasSkel = false;
		bool hasParticle = false;
		bool hasActor = false;

		owner = character;
		data = part_info;

		mesh = ptr_new SkinMesh(MESH_KEY_CHARACTER);
		if (mesh)
		{
			for (U32 i = 0; i < MESH_LOD_LEVEL; i++)
			{
				if (mesh->AddPrimitive(part_info.mesh[i], part_info.mesh[i], i))
				{
					hasMesh = true;
				}
			}

			skeleton = RESOURCE_LOAD(part_info.skeleton, false, Skeleton);
			if (skeleton)
			{
				mesh->pose = ptr_new Pose(skeleton);
				hasSkel = true;


				if(part_info.prop_animationset)
				{
					animation = ptr_new AnimationNodeCustom(skeleton);
					SetAnimationSet(part_info.prop_animationset);

					first_animation = part_info.first_animation;
					
					for (U32 i = 0; i < part_info.animation_info_array.Size(); i++)
					{
						animation_info_array.Add(part_info.animation_info_array[i]);
					}

					if(first_animation.name.Length() != 0)
					{
						PlayAction(first_animation.name,first_animation.playtime);
					}
				}
			}
		}

		for (U32 i = 0; i < part_info.particles.Size(); i++)
		{
			sharedc_ptr(ParticleSystem) particle = ptr_new ParticleSystem(part_info.particles[i]);

			particle->SetEnable(true);
			particles.PushBack(particle);

			hasParticle = true;
		}

		actor = PhysxSystem::CreateBox(Vector3::kZero, part_info.size * 0.5f, PhysxSystem::kGroupProjectStart + character->GetTeam()/*physx_group*/);
		if (actor)
		{
			actor->userData = character;
			hasActor = true;

			NxShape* shape =  actor->getShapes()[0];

			if (shape)
			{
				shape->setLocalPosition((const NxVec3 &)data.base_offset);

				shape->setLocalOrientation((const NxQuat &)data.base_rotation);
			}
		}

		SetPhysxControl(false);

		return ((hasMesh && hasSkel) || hasParticle) && hasActor;
	}

	/// is ready
	bool DetachablePart::IsReady()
	{
		if (mesh)
		{
			return mesh->IsReady();
		}

		return true;
	}

	/// is died
	bool DetachablePart::IsDied()
	{
		return is_died;
	}

	/// update
	void DetachablePart::Update(float frame_time)
	{
		if (!IsDied())
		{
			if (GetPhysxControl())
			{
				SetPosition((const Vector3 &)actor->getGlobalPosition());
				SetRotation((const Quaternion &)actor->getGlobalOrientationQuat());

				died_timer -= frame_time;
				if (died_timer <= 0.f)
				{
					died_timer = 0;
					is_died = true;
				}
			}

		
			if (mesh)
			{
				mesh->SetPosition(GetPosition());
				mesh->SetRotation(GetRotation());


				if (animation)
				{
					int size = animation_info_array.Size();
					if(animation_timer > 0.f && size > 0)
					{
						animation_timer -= frame_time;
						if(animation_timer < 0.f)
						{
							int pos = rand()%size;
							const DetachAnimationInfo& info = animation_info_array[pos];
							PlayAction(info.name, info.playtime);
						}
					}
					animation->Update(frame_time);
					if (mesh)
					{
						mesh->pose = animation->GetPose();
						mesh->Update();
					}
				}
			}

			for (U32 i = 0; i < particles.Size(); i++)
			{
				particles[i]->SetPosition(GetPosition());
				particles[i]->SetRotation(GetRotation());

				particles[i]->Update(frame_time);
			}
		}
	}

	/// draw
	void DetachablePart::Draw(Primitive::DrawType drawtype, bool immediate)
	{
		if (mesh)
		{
			mesh->Draw(drawtype, immediate);
		}

		if (immediate)
		{
			for (U32 i = 0; i < particles.Size(); i++)
			{
				particles[i]->Draw();
			}
		}
	}

	/// onhit
	bool DetachablePart::OnHit(byte part, float prop, const Core::Vector3 & hit_dir)
	{
		if (part == data.part && data.proportion >= prop)
		{
			SetPhysxControl(true);
			AddForce(hit_dir * 5);

			return true;
		}

		return false;
	}


	/// get position
	const Vector3 & DetachablePart::GetPosition()
	{
		if (actor)
			position = (const Vector3 &)actor->getGlobalPosition();

		return position;
	}

	/// set position
	void DetachablePart::SetPosition(const Vector3 & pos)
	{
		if (data.fix_position)
		{
			if (owner)
			{
				if (actor)
					actor->setGlobalPosition((const NxVec3 &)owner->GetPosition());

				position = owner->GetPosition();
			}
		}
		else
		{
			if (actor)
				actor->setGlobalPosition((const NxVec3 &)pos);

			position = pos;
		}
	}

	/// get rotation
	const Quaternion & DetachablePart::GetRotation()
	{
		if (actor)
			rotation = (const Quaternion &)actor->getGlobalOrientationQuat();

		return rotation;
	}

	/// set rotation
	void DetachablePart::SetRotation(const Quaternion & rot)
	{
		if (data.fix_rotation)
		{
			if (actor)
				actor->setGlobalOrientationQuat((const NxQuat &)Quaternion::kIdentity);

			rotation = Quaternion::kIdentity;
		}
		else
		{
			if (actor)
				actor->setGlobalOrientationQuat((const NxQuat &)rot);

			rotation = rot;
		}
	}

	/// get detachablepart info
	const DetachablePart::DetachablePartData & DetachablePart::GetDetachablePartData()
	{
		return data;
	}


	/// add force
	void DetachablePart::AddForce(const Vector3 & dir)
	{
		if (actor)
		{
			//actor->addForce((const NxVec3 &)dir, NX_ACCELERATION);
			actor->setLinearVelocity((const NxVec3 &)dir);
		}
	}

	/// set physx control
	void DetachablePart::SetPhysxControl(bool flag)
	{
		if (actor)
		{
			if (flag)
			{
				actor->clearBodyFlag(NX_BF_KINEMATIC);
				actor->clearBodyFlag(NX_BF_DISABLE_GRAVITY);
			}
			else
			{
				actor->raiseBodyFlag(NX_BF_KINEMATIC);
				actor->raiseBodyFlag(NX_BF_DISABLE_GRAVITY);
			}
		}
	}

	/// get physx control
	bool DetachablePart::GetPhysxControl()
	{
		if (actor)
		{
			return actor->readBodyFlag(NX_BF_KINEMATIC) == false;
		}

		return false;
	}
}

namespace Client
{
	static const char *BURN_JOINTNAME[BUFFER_PARTICLE_COUNT] = 
	{	
		"back_b",
		"arm_r",
		"arm_l",
		"elbow_r",
		"elbow_l",
		"knee_r",
		"knee_l",
	};

	/// constructor
	ThirdPerson::ThirdPerson()
		: lower_rotation(Quaternion::kIdentity)
		, skeleton_rotation(Quaternion::kIdentity)
		, skeleton_rotation_oral(Quaternion::kIdentity)
		, root_position(Vector3::kZero)
		, joint_hip_id(-1)
		, skeleton_turn(false)
		, angle_h_last(0)
		, skeleton_turn_timer(0)

		, angle_target(0.f)
		, lower_state_last(0)
		, lower_animation_rate(0)

		, audio_step(NULL)
		, audio_use_equipment(NULL)
		, tank_idel_3d(NULL)

		, jump_to_run(false)
        , clothes_particle1(false)
		, camera_position(Vector3::kZero)
		, camera_rotation(Quaternion::kIdentity)
		, camera_rotation_oral(Quaternion::kIdentity)

		, show_count(-1)
		, ammo_need_multianimation(2)
		, reload_multianimation(false)
		, cure_state(0)
		, cure_state_thr(0)
		, mini_state(0)
		, mini_state_thr(0)
		, cure_particel_time(0.0f)
		, showrevenge(false)
		, showcontrol(false)
		, curboostindex(0)
		, now_step_material(-1)
		, effectbuffertimer(0.f)
		, effectbuffertype(-1)
		, footbuffertimer(0.f)
		, footbuffertype(-1)
		, rotate_limit(0.17f)
	{
		camera_joint_id = -1;
		handweapon_l_id = -1;
		handweapon_r_id = -1;
		wrist_ik_l_id = -1;
		wrist_ik_r_id = -1;
		wrist_l_id = -1;
		wrist_r_id = -1;
		back_id = -1;
	}

	/// destructor
	ThirdPerson::~ThirdPerson()
	{
		ReleasePhysxObject();

		if (audio_step)
		{
			audio_step->stop(true);
			audio_step = NULL;
		}

		if (audio_use_equipment)
		{
			audio_use_equipment->stop(true);
			audio_use_equipment = NULL;
		}

		if (tank_idel_3d)
		{
			tank_idel_3d->stop();
			tank_idel_3d = NULL;
		}

		if (cure_particle)
		{
			cure_particle->SetEnable(false);
		}
		
		if (effectbuffer)
		{
			effectbuffer->SetEnable(false);
		}
		
		if (footbuffer)
		{
			footbuffer->SetEnable(false);
		}

		if (invisiblebuffer)
		{
			invisiblebuffer->SetEnable(false);
		}
	}

	/// on create
	void ThirdPerson::OnCreate()
	{
		Object::OnCreate();
		now_step_material = -1;
		showcontrol = false;
		showrevenge = false;

	}

	/// on destroy()
	void ThirdPerson::OnDestroy()
	{
		ReleasePhysxObject();

		if (audio_step)
			audio_step->stop(true);

		if (tank_idel_3d)
			tank_idel_3d->stop();

		if (audio_use_equipment)
			audio_use_equipment->stop(true);

		weapon_hold_set.Clear();

		ClearFootParticle();
		ClearBoddyParticle();
		ClearHumanParticle();
		ClearInvisibleParticle();
		ClearEffectParticle();
		ClearZombieParticle();
		ClearGunParticle();

		Object::OnDestroy();
	}


	/// update bounding box
	void ThirdPerson::UpdateBoundingBox()
	{
		bool has_weapon = false;

		if (character && character->ready)
		{
			if (draw_mesh)
			{
				draw_mesh->pose = pose;
				draw_mesh->Update();

				world_aabb = draw_mesh->GetAABB();
			}
		}
		Matrix44 m(character->GetPosition(), 1, GetSkeletonRotation());
		world_aabb.Transform(m);

		if (!has_weapon)
			return;
		tempc_ptr(WeaponBase) weapon = GetWeapon(character->weapon_id);

		if (weapon)
		{
			if (world_aabb.Max >= world_aabb.Min)
				world_aabb.UnionWithAABB(weapon->GetWorldAABB());
		}
	}

	/// update
	void ThirdPerson::Update(float frame_time)
	{
		PROFILE("ThirdPerson::Update");

		if (!character)
			return;

		UpdateAnimation(frame_time);

		// update weapon animation
		tempc_ptr(WeaponBase) weapon = GetWeapon(character->weapon_id);

		if (weapon)
			weapon->UpdateAnimation(frame_time);
		//character->occluded == false && 
		//if (character->GetViewMode() == Character::kThirdPerson)
		{
			UpdateTransform(frame_time);
		}

		if (character->IsDied() && character->ready && !character->GetPhysxControl())
		{
			if (!animation_system || !animation_system->IsActionPlaying())
			{
				if (character_info && character_info->third_person_dead_animation.Length() == 0)
					character->SetPhysxControl(true);
			}
		}

		// update bounding box
		UpdateBoundingBox();

		UpdatePhysx(frame_time);

		UpdateAudio(frame_time);

		UpdateFootParticle(frame_time);

		UpdateGunParticle(frame_time);

		UpdateBoddyParticle(frame_time);

		UpdateHumanParticle(frame_time);

		UpdateInvisibleParticle(frame_time);

		UpdateZombieParticle(frame_time);

		UpdateEffectParticle(frame_time);

		if (damage_particle)
			damage_particle->Update(frame_time);

		if (clothes_particle)
		{
			Vector3 head_pos;
			Quaternion head_rot;

			if (GetJointInfo("chest", head_pos, head_rot))
			{
				clothes_particle->SetPosition(head_pos);
				clothes_particle->Update(frame_time);
			}
		}

		if (boostdamage_particle)
			boostdamage_particle->Update(frame_time);

		if (ammorecover_particle)
		{
			if(character)
			{
				Core::Vector3 position;
				Core::Quaternion qutation;
				if(GetJointInfo("back_b",position,qutation))
				{
					ammorecover_particle->SetPosition(position);
					ammorecover_particle->SetRotation(qutation);
				}

			}
			ammorecover_particle->Update(frame_time);
		}
			
		if (healthrecover_particle)
		{
			if(character)
			{
				Core::Vector3 position;
				Core::Quaternion qutation;
				if(GetJointInfo("back_b",position,qutation))
				{
					healthrecover_particle->SetPosition(position);
					//healthrecover_particle->SetRotation(qutation);
				}
			}
			healthrecover_particle->Update(frame_time);
		}
		
		for(int i = 0; i < BOOSTBULLET_PARTICLE_COUNT; i++)
		{
			if (boostdbullet_particle[i])//
			{
				if(!boostdbullet_particle[i]->IsDead() && boostdbullet_particle[i]->IsReady())
				{
					Vector3 head_pos;
					Quaternion head_rot;
					if (GetJointInfo("hat", head_pos, head_rot))
					{
						boostdbullet_particle[i]->SetPosition(head_pos + Vector3(0, 0.2f, 0));
					}
				}
				boostdbullet_particle[i]->Update(frame_time);
			}
		}
		
		for(int i = 0; i < BUFFER_PARTICLE_COUNT; i++)
		{
			if (burn_particle[i])//
			{
				if(!burn_particle[i]->IsDead() && burn_particle[i]->IsReady())
				{
					if(skeleton && pose)
					{
						int joint_id = skeleton->GetJointId(BURN_JOINTNAME[i]);
						if (joint_id >= 0)
						{
							const Transform & transform = pose->GetJointModelPose(joint_id);
							
							Vector3 position = character->GetPosition() + transform.position * character->GetSkeletonRotation();// 
							burn_particle[i]->SetPosition(position);
						}
					}
				}
				burn_particle[i]->Update(frame_time);
			}
		}

		for(int i = 0; i < BUFFER_PARTICLE_COUNT; i++)
		{
			if (poison_particle[i])//
			{
				if(!poison_particle[i]->IsDead() && poison_particle[i]->IsReady())
				{
					if(skeleton && pose)
					{
						int joint_id = skeleton->GetJointId(BURN_JOINTNAME[i]);
						if (joint_id >= 0)
						{
							const Transform & transform = pose->GetJointModelPose(joint_id);

							Vector3 position = character->GetPosition() + transform.position * character->GetSkeletonRotation();// 
							poison_particle[i]->SetPosition(position);
						}
					}
				}
				poison_particle[i]->Update(frame_time);
			}
		}



		if(character->is_boss && character->hp < character->max_hp/3)
		{
			int playcount = BOSS_DANGER_COUNT ;
			for(int i = 0; i < BOSS_DANGER_COUNT; i++)
			{
				if (boss_danger_particle[i])//
				{
					
					if(!boss_danger_particle[i]->IsDead() && boss_danger_particle[i]->IsReady())
					{
						if(skeleton && pose)
						{
							int joint_id = skeleton->GetJointId(BURN_JOINTNAME[i]);
							if (joint_id >= 0)
							{
								const Transform & transform = pose->GetJointModelPose(joint_id);

								Vector3 position = character->GetPosition() + transform.position * character->GetSkeletonRotation();// 
								boss_danger_particle[i]->SetPosition(position);
							}
						}
						boss_danger_particle[i]->Update(frame_time);
					}
					else if(boss_danger_particle[i]->IsReady())
					{
						playcount--;
					}
					
				}
			}
			if(!playcount)
				PlayBossDanger();
		}
		

		// update cureparticle
		if(cure_particle && cure_particle->IsReady())
		{
			Core::Vector3 torso_pos;
			Core::Quaternion torso_rot;
			if (GetJointInfo("torso",torso_pos,torso_rot))
			{
				//cure_particle->SetPosition(torso_pos);
				cure_particle->SetPosition(character->GetSkeletonPosition() + Vector3(0, 0.02f, 0));
				cure_particle->SetRotation(torso_rot);
			}
			if(!cure_particle->m_LinkNode.GetList())
			{
				gLevel->AddParticle(cure_particle);
				cure_particle->SetEnable(false);
			}
			if(cure_particel_time > 0)
			{
				cure_particel_time -= frame_time;
				cure_particle->SetEnable(true);
			}
			else
			{
				cure_particle->SetEnable(false);
			}
		}
		
		// update effectbuffer
		if(effectbuffer && effectbuffer->IsReady())
		{

			const Transform & transform = pose->GetJointModelPose(back_id);

			Vector3 position = character->GetPosition() + transform.position * character->GetSkeletonRotation();// 
			effectbuffer->SetPosition(position);

			effectbuffer->SetRotation(character->GetSkeletonRotation());
			//effectbuffer->Reset();
			if(effectbuffertimer > 0 && !character->IsDied())
			{
				effectbuffertimer -= frame_time;
				if(	character->GetViewMode() == Character::kThirdPerson)
				{
					//effectbuffer->Reset();
					//effectbuffer->SetEnable(true);
					
				}
				else
					effectbuffer->SetDead();	
					//effectbuffer->SetEnable(false);
			}
			else
			{
				
				effectbuffer->SetDead();	
				
				//effectbuffer->SetEnable(false);
				//effectbuffer->ResetEmittersParticles();
			}
		}
		// update footbuffer
		if(footbuffer && footbuffer->IsReady())
		{

			footbuffer->SetPosition(character->GetSkeletonPosition() + Vector3(0, 0.05f, 0));
			footbuffer->SetRotation(character->GetSkeletonRotation());

			if(!footbuffer->m_LinkNode.GetList())
			{
				gLevel->AddParticle(footbuffer);
				footbuffer->SetEnable(false);
			}
			if(footbuffertimer > 0 && !character->IsDied())
			{
				footbuffertimer -= frame_time;
				if(	character->GetViewMode() == Character::kThirdPerson)
					footbuffer->SetEnable(true);
				else	
					footbuffer->SetEnable(false);
			}
			else
			{
				footbuffer->SetEnable(false);
			}
		}

		if(character->gun_special_particle && character->special_particle_time > 0.f)
		{
			Core::Vector3 torso_pos;
			Core::Quaternion torso_rot;
			if (GetJointInfo("torso",torso_pos,torso_rot))
			{
				character->gun_special_particle->SetPosition(character->GetSkeletonPosition() + Vector3(0, 0.02f, 0));
				character->gun_special_particle->SetRotation(torso_rot);
			}
			if(!character->gun_special_particle->m_LinkNode.GetList())
			{
				gLevel->AddParticle(character->gun_special_particle);
				character->gun_special_particle->SetEnable(false);
			}
			if(character->special_particle_time > 0)
			{
				character->special_particle_time -= frame_time;
				character->gun_special_particle->SetEnable(true);
			}
		}

		if(character->tp_special_particle && character->tp_special_particle_time > 0.f)
		{
			Core::Vector3 torso_pos;
			Core::Quaternion torso_rot;
			if (GetJointInfo("torso",torso_pos,torso_rot))
			{
				character->tp_special_particle->SetPosition(character->GetSkeletonPosition() + Vector3(0, 0.02f, 0));
				character->tp_special_particle->SetRotation(torso_rot);
			}
			if(!character->tp_special_particle->m_LinkNode.GetList())
			{
				gLevel->AddParticle(character->tp_special_particle);
				character->tp_special_particle->SetEnable(false);
			}
			if(character->tp_special_particle_time > 0)
			{
				character->tp_special_particle_time -= frame_time;
				character->tp_special_particle->SetEnable(true);
			}
		}

		if (revenge_mesh)
			revenge_mesh->Update();

		billboard_timer -= frame_time;
		if (billboard_timer < 0.f) 
			billboard_timer = 0.f;

		itemmode_timer -= frame_time;
		if (itemmode_timer<0.f)
			itemmode_timer = 0.f;

		//updata billboard
		if (billboard_mesh)
			billboard_mesh->Update();

		if (control_mesh)
			control_mesh->Update();

		if (item_mode_head)
			item_mode_head->Update();
	}

	/// on render
	void ThirdPerson::OnRender(float frame_time)
	{
		if (!character)
			return;

		if (animation_system)
			animation_system->OnValid(character->GetViewMode() == Character::kThirdPerson);

		//character->occluded == false && 
		//if (character->GetViewMode() == Character::kThirdPerson)
		{
			UpdateAnimationJoint(frame_time);

			tempc_ptr(WeaponBase) weapon = GetWeapon(character->weapon_id);

			if (weapon)
				UpdateWeapon(frame_time);
			if(character->occluded == false)
			{
				if(character->equipment_id >= 0)
				{
					tempc_ptr(WeaponBase) equip = GetWeapon(character->equipment_id);
					if(equip)
					{
						UpdateEquipment(frame_time);
						equip->UpdateMesh();

					}
				}
			}
		}

		if (character && character->ready)
		{
			if (draw_mesh)
			{
				draw_mesh->pose = pose;
				draw_mesh->Update();
			}
		}

		if (IsReady())
		{
			DetachablePartSet::Enumerator it(detachable_part_set);
			while (it.MoveNext())
			{
				tempc_ptr(DetachablePart) detachable_part = it.Value();

				Vector3 pos;
				Quaternion rot;

				const DetachablePart::DetachablePartData & detachablepart_data = detachable_part->GetDetachablePartData();

				if (GetJointInfo(detachablepart_data.joint, pos, rot))
				{
					detachable_part->SetRotation(rot);

					detachable_part->SetPosition(pos);
				}

				detachable_part->Update(frame_time);
			}
		}
	}

	/// update transform
	void ThirdPerson::UpdateTransform(float frame_time)
	{
		if (character)
		{
			if (character->IsDied())
				camera_position = character->GetPosition() + Vector3(0, 1.3f, 0);
			else
				camera_position = character->GetPosition() + Vector3(0, character->GetControllerRadius() * 2 + character->GetHeight() - 0.2f, 0);

			if (character->IsDied())
				camera_rotation = camera_rotation_oral;
			else
				camera_rotation = character->GetRotation();

			if (skeleton)
			{
				if (camera_joint_id > 0 && camera_joint_id < (int)skeleton->GetJointCount())
				{
					const Transform & transform = pose->GetJointModelPose(camera_joint_id);
					camera_rotation = camera_rotation * transform.rotation;
				}
			}

			skeleton_rotation = skeleton_rotation_oral * Quaternion(Vector3(0, 1, 0), PI);
		}
	}

	/// initialize
	void ThirdPerson::Initialize()
	{
		if (character && character_info)
		{
			LoadSkeleton();

			CreateThirdPersonAnimation();

			Update(0);
			UpdateAnimationJoint(0);

			InitializeMesh();

			CreatePhysxObject();

			draw_mesh = mesh;

			if (character->pack_index < character_info->pack_set.Size())
				InitializeWeapon(character_info->pack_set[character->pack_index]);

			//// hold pack
			//weapon_hold_set.Clear();
			//sharedc_ptr(WeaponBase) w;
			//for (uint i = 0; i < character_info->pack_set.Size(); i++)
			//{
			//	for (uint j = 0; j < character_info->pack_set[i].weapon_set.Size(); j++)
			//	{
			//		w = character->CreateWeapon(character_info->pack_set[i].weapon_set[j]);
			//		if (w)
			//		{
			//			w->SetOwner(character);
			//			w->Initialize();
			//			w->PreloadAnimation();
			//			w->SetMeshLod(1);
			//			weapon_hold_set.PushBack(w);
			//		}
			//	}
			//}

			//load billboard;
			billboard_mesh = ptr_new StaticMesh(MESH_KEY_PROP);
			if (character->GetTeam() == 0)
				billboard_mesh->AddPrimitive("UI_addHP/UI_R_addHP.mesh",0);
			else
				billboard_mesh->AddPrimitive("UI_addHP/UI_B_addHP.mesh",0);
			
			item_mode_head = ptr_new StaticMesh(MESH_KEY_PROP);
			item_mode_head->AddPrimitive("UI_Item_Skill/ig_itemmode_skill_ico_0.mesh",0);

			control_mesh = ptr_new StaticMesh(MESH_KEY_PROP);
			control_mesh->AddPrimitive("UI_control/UI_revenge.mesh", 0);

			//damage_particle
			damage_particle = ptr_new ParticleSystem("num");

			if (strcmp(character_info->clothes_particle, "") != 0 )
			{
				clothes_particle1 = true;
				clothes_particle = ptr_new ParticleSystem(character_info->clothes_particle);
				clothes_particle->SetEnable(true);
			}
			else
			{
				clothes_particle1 = false;
				//clothes_particle = ptr_new ParticleSystem(character_info->clothes_particle);
				//clothes_particle->SetEnable(false);
			}
			
			ammorecover_particle = ptr_new ParticleSystem("prop_addammo",false);
			ammorecover_particle->SetEnable(false); 
			healthrecover_particle = ptr_new ParticleSystem("prop_addhp",false);
			healthrecover_particle->SetEnable(false);

			boostdamage_particle = ptr_new ParticleSystem("num_crit");
			for(int i = 0; i < BOOSTBULLET_PARTICLE_COUNT; i++)
			{
				boostdbullet_particle[i] = ptr_new ParticleSystem("bullet_crit",false);
				boostdbullet_particle[i]->SetDead();
				boostdbullet_particle[i]->SetEnable(false);
			}

			for(int i = 0; i < BUFFER_PARTICLE_COUNT; i++)
			{
				burn_particle[i] = ptr_new ParticleSystem("injury_fire",false);
				burn_particle[i]->SetDead();
				burn_particle[i]->SetEnable(false);
			}

			for(int i = 0; i < BUFFER_PARTICLE_COUNT; i++)
			{
				poison_particle[i] = ptr_new ParticleSystem("injury_poison",false);
				poison_particle[i]->SetDead();
				poison_particle[i]->SetEnable(false);
			}

			if(character->is_boss)
			{

				for(int i = 0; i < BOSS_DANGER_COUNT; i++)
				{
					boss_danger_particle[i] = ptr_new ParticleSystem("boss_elecflower",false);
					boss_danger_particle[i]->Reset();
					boss_danger_particle[i]->SetDead();
				}

			}


			static const char szTeam[2] = {'r', 'b'};
			if (!cure_particle)
			{
				Core::String name = Core::String::Format("%s_%c", "buff_resume", szTeam[character->GetTeam() & 1]);
				cure_particle = ptr_new ParticleSystem(name);
			}
			cure_particle->SetEnable(false);
			
			

			pose = ptr_new Pose(skeleton);

			revenge_mesh = ptr_new StaticMesh(MESH_KEY_PROP);
			revenge_mesh->AddPrimitive("UI_revenge/UI_revenge.mesh",0);
			curboostindex = 0;

			for(UINT i = 0; i < BUFFER_PARTICLE_COUNT; i++)
			{
				arry_buffer_rand.PushBack(i);
			}
			
			for(UINT i = 0; i < BOSS_DANGER_COUNT; i++)
			{
				arry_boss_danger_rand.PushBack(i);
			}
		}
		else
		{
			mesh = NullPtr;
		}
		billboard_timer = 0.f;
		itemmode_timer = 0.f;
	}

	/// update audio
	void ThirdPerson::UpdateAudio(float frame_time)
	{			
		if (character 
			&& !character->IsDied() 
			&& character->ready
			&& character->GetViewMode() == Character::kThirdPerson)
		{
			NxRay ray;
			ray.orig = (const NxVec3 &)character->GetPosition();
			ray.orig.y += 3.f;
			ray.dir = (const NxVec3 &)Core::Vector3(0, -1, 0);

			NxRaycastHit hit;
			uint group_id = 0;
			group_id |= 1 << PhysxSystem::kStatic;
			group_id |= 1 << PhysxSystem::kStaticRaycast;
			NxShape* shape = gPhysxScene->raycastClosestShape(ray, NX_ALL_SHAPES, hit, group_id, 5.f);

			FMOD_EVENT_STATE audio_state = FMOD_EVENT_DEFAULT;

			if (audio_step)
			{
				audio_step->getState(&audio_state);
				if (character->IsOnGround())
				{
					tempc_ptr(Character) player = gLevel->GetPlayer();
					float length = 0.f;
					length = Core::Length(player->GetPosition() - character->GetPosition());
					if (length < 20.f)
					{
						FMOD_VECTOR pos = (const FMOD_VECTOR &)character->GetPosition();
						FMOD_VECTOR vel = {0, 0, 0};
						audio_step->set3DAttributes(&pos, &vel);

						if (character->IsMoving())
						{
							if (shape)
							{
								int stepway = now_stepway;
								now_stepway = 1;
								int step_material = now_step_material;
								CStrBuf<256> key;
								if (character->is_boss)
								{
									key.format("bj/material/3d/step/boss");
								}
								else if (gLevel && gLevel->game_type == RoomOption::kZombieMode && character->GetTeam() == 1)
								{
									key.format("bj/material/3d/step/bio_step");
								}
								else
								{
									switch (hit.materialIndex)
									{
									case PhysxSystem::kWood:
										now_step_material = 0;
										key.format("bj/material/3d/step/wood");
										break;

									case PhysxSystem::kMetal:
										now_step_material = 1;
										key.format("bj/material/3d/step/metal");
										break;

									case PhysxSystem::kConcrete:
										now_step_material = 2;
										key.format("bj/material/3d/step/concrete");
										break;
									default:
										break;
									}
								}

								if (step_material != now_step_material || stepway != now_stepway)
								{
									if (audio_step)
										audio_step->stop();
									audio_step = FmodSystem::GetEvent(key);
									if (audio_step)
									{
										audio_step->set3DAttributes(&pos, &vel);
										audio_step->start();
									}
								}
								else
								{
									audio_step->getState(&audio_state);
									if ((audio_state & FMOD_EVENT_STATE_PLAYING) == 0)
									{
										audio_step = FmodSystem::GetEvent(key);
										if (audio_step)
										{
											audio_step->set3DAttributes(&pos, &vel);
											audio_step->start();
										}
									}
								}
							}
						}
						else if(character->GetCrouch() && character->IsSlowMoving())
						{
							
							if (shape)
							{
								int stepway = now_stepway;
								now_stepway = 2;
								int step_material = now_step_material;
								CStrBuf<256> key;
								if (character->is_boss)
								{
									key.format("bj/material/3d/step/boss");
								}
								else if (gLevel && gLevel->game_type == RoomOption::kZombieMode && character->GetTeam() == 1)
								{
									key.format("bj/material/3d/step/bio_step");
								}
								else
								{
									switch (hit.materialIndex)
									{
									case PhysxSystem::kWood:
										now_step_material = 0;
										key.format("bj/material/3d/step_stealth/wood");
										break;

									case PhysxSystem::kMetal:
										now_step_material = 1;
										key.format("bj/material/3d/step_stealth/metal");
										break;

									case PhysxSystem::kConcrete:
										now_step_material = 2;
										key.format("bj/material/3d/step_stealth/concrete");
										break;
									default:
										break;
									}
								}

								if (step_material != now_step_material || stepway != now_stepway)
								{
									if (audio_step)
										audio_step->stop();
									audio_step = FmodSystem::GetEvent(key);
									if (audio_step)
									{
										audio_step->set3DAttributes(&pos, &vel);
										audio_step->start();
									}
								}
								else
								{
									audio_step->getState(&audio_state);
									if ((audio_state & FMOD_EVENT_STATE_PLAYING) == 0)
									{
										audio_step = FmodSystem::GetEvent(key);
										if (audio_step)
										{
											audio_step->set3DAttributes(&pos, &vel);
											audio_step->start();
										}
									}
								}
							}
						}
						else
						{
							audio_step->getState(&audio_state);
							if (audio_state & FMOD_EVENT_STATE_PLAYING)
								audio_step->stop(true);
						}
					}
				}
				else
				{
					if (audio_state & FMOD_EVENT_STATE_PLAYING)
						audio_step->stop(true);
				}
			}
			else
			{
				if (shape)
				{
					CStrBuf<256> key;
					if (character->is_boss)
					{
						key.format("bj/material/3d/step/boss");
					}
					else if (gLevel && gLevel->game_type == RoomOption::kZombieMode && character->GetTeam() == 1)
					{
						key.format("bj/material/3d/step/bio_step");
					}
					else
					{
						if(character->GetCrouch())
						{
							switch (hit.materialIndex)
							{
							case PhysxSystem::kWood:
								now_step_material = 0;
								key.format("bj/material/3d/step_stealth/wood");
								break;

							case PhysxSystem::kMetal:
								now_step_material = 1;
								key.format("bj/material/3d/step_stealth/metal");
								break;

							case PhysxSystem::kConcrete:
								now_step_material = 2;
								key.format("bj/material/3d/step_stealth/concrete");
								break;

							default:
								break;
							}
						}
						else
						{
							switch (hit.materialIndex)
							{
							case PhysxSystem::kWood:
								now_step_material = 0;
								key.format("bj/material/3d/step/wood");
								break;

							case PhysxSystem::kMetal:
								now_step_material = 1;
								key.format("bj/material/3d/step/metal");
								break;

							case PhysxSystem::kConcrete:
								now_step_material = 2;
								key.format("bj/material/3d/step/concrete");
								break;

							default:
								break;
							}
						}
						
						
	
					}
					audio_step = FmodSystem::GetEvent(key);
				}
			}
			if (tank_idel_3d && character->IsCarrierMode() )
			{
				if (!character->IsBoost() && !character->IsShooting() && !character->IsReloading() )
				{
					FMOD_EVENT_STATE audio_state = FMOD_EVENT_DEFAULT;
					tank_idel_3d->getState(&audio_state);
					if ((audio_state & FMOD_EVENT_STATE_PLAYING) == 0)
					{
						FMOD_VECTOR vel = {0, 0, 0};
						tank_idel_3d->set3DAttributes(&(const FMOD_VECTOR &)character->GetPosition(), &vel);
						tank_idel_3d->start();
					}
					else
					{
						FMOD_VECTOR vel = {0, 0, 0};
						tank_idel_3d->set3DAttributes(&(const FMOD_VECTOR &)character->GetPosition(), &vel);
					}
				}
				else
				{
					FMOD_EVENT_STATE audio_state = FMOD_EVENT_DEFAULT;
					if (tank_idel_3d)
					{
						tank_idel_3d->getState(&audio_state);
						if (audio_state & FMOD_EVENT_STATE_PLAYING)
							tank_idel_3d->stop();
					}
				}
			}
			else if (character->IsCarrierMode() )
			{
				tank_idel_3d = FmodSystem::GetEvent("bj/player/3d/tank01/idle");
			}
		}
		else
		{
			FMOD_EVENT_STATE audio_state = FMOD_EVENT_DEFAULT;

			if (audio_step)
			{
				audio_step->getState(&audio_state);
				if (audio_state & FMOD_EVENT_STATE_PLAYING)
					audio_step->stop();
			}

			if (audio_use_equipment)
			{
				audio_use_equipment->getState(&audio_state);
				if (audio_state & FMOD_EVENT_STATE_PLAYING)
					audio_use_equipment->stop();
			}

			audio_state = FMOD_EVENT_DEFAULT;
			if (tank_idel_3d)
			{
				tank_idel_3d->getState(&audio_state);
				if (audio_state & FMOD_EVENT_STATE_PLAYING)
					tank_idel_3d->stop();
			}
		}
	}

	/// initialize weapon
	void ThirdPerson::InitializeWeapon(const PackInfo & pack)
	{
		weapons.Fill(NullPtr);
		for (uint j = 0; j < pack.weapon_set.Size(); ++j)
		{
			tempc_ptr(WeaponInfo) info = pack.weapon_set[j];
			SetWeapon(j, info);
		}
	}

	/// initialize mesh
	void ThirdPerson::InitializeMesh()
	{
		bool hasMesh = false;
		mesh = ptr_new CharacterMesh(MESH_KEY_CHARACTER);
		if (character_info && mesh)
		{
			for (U32 i = 0; i < MESH_LOD_LEVEL; i++)
			{
				CharacterInfo::MeshSet::Enumerator it(character_info->mesh_set_third_person[i]);

				while (it.MoveNext())
				{
					mesh->AddPrimitive(it.Key(), it.Value(), i);
					hasMesh = true;
				}
			}
		}
		if (!hasMesh)
		{
			mesh = NullPtr;
		}

		detachable_part_set.Clear();
		if (character_info)
		{
			CharacterInfo::DetachablePartInfoSet::Enumerator it(character_info->detachablepartinfo_set);
			while (it.MoveNext())
			{
				sharedc_ptr(DetachablePart) detachable_part = ptr_new DetachablePart;

				if (detachable_part->Initialize(character, it.Value()))
				{
					detachable_part_set.Set(it.Key(), detachable_part);
				}
			}
		}
	}

	/// get mesh
	tempc_ptr(SkinMesh) ThirdPerson::GetMesh()
	{
		return mesh;
	}

	/// is ready
	bool ThirdPerson::IsReady()
	{
		if (!character)
			return false;

		if (draw_mesh && !draw_mesh->IsReady())
			return false;

		DetachablePartSet::Enumerator it(detachable_part_set);
		while (it.MoveNext())
		{
			if (!it.Value()->IsReady())
				return false;
		}

		if (animation_set && !animation_set->IsReady())
			return false;

		int weapon_id = character->weapon_id;
		if (weapon_id >= 0 && weapon_id < 7)
			if (animation_set_weapon[weapon_id] && !animation_set_weapon[weapon_id]->IsReady())
				return false;

		tempc_ptr(WeaponBase) weapon = GetWeapon(character->weapon_id);
		if (weapon && !weapon->IsReady())
			return false;

		if (weapon && !weapon->GetMesh()->IsReady())
			return false;

		return true;
	}

	/// draw
	void ThirdPerson::Draw(Primitive::DrawType drawtype, bool immediate, bool drawgun)
	{	
		if (character && character->ready)
		{
			if (character->IsAttributeExist(kEffect_Special_Invisible) && character->transparency_value <= 0.2f)
				return;

			tempc_ptr(WeaponBase) weapon = GetWeapon(character->weapon_id);
			if (!character->IsDied())
			{
				if (weapon && drawgun)
				{
					weapon->Draw(drawtype, immediate);
				}
			}
			if(character->equipment_id >= 0)
			{
				tempc_ptr(WeaponBase) equip = GetWeapon(character->equipment_id);
				if(equip != weapon)
				{
					equip->Draw(drawtype, immediate);
				}
			}
			
			
			if (billboard_timer > 0.f && billboard_mesh)
			{
				billboard_mesh->SetPosition(character->GetPosition() + Vector3(0, 1.8f, 0));
				billboard_mesh->SetRotation(GetSkeletonRotation());
				billboard_mesh->Draw(drawtype, immediate);
			}

			if (itemmode_timer > 0.f && item_mode_head)
			{
				item_mode_head->SetPosition(character->GetPosition() + Vector3(0, 1.8f, 0));
				item_mode_head->SetRotation(GetSkeletonRotation());
				item_mode_head->Draw(drawtype, immediate);
			}

			if (showcontrol && !showrevenge)
			{
				if (control_mesh)
				{
					control_mesh->SetPosition(character->GetPosition() + Vector3(0, 1.8f, 0));
					control_mesh->SetRotation(GetSkeletonRotation());
					control_mesh->Draw(drawtype, immediate);
				}
			}
			else if (!showcontrol && showrevenge)
			{
				if (revenge_mesh)
				{
					revenge_mesh->SetPosition(character->GetPosition() + Vector3(0, 1.8f, 0));
					revenge_mesh->SetRotation(GetSkeletonRotation());
					revenge_mesh->Draw(drawtype, immediate);
				}
			}
			else if (showcontrol && showrevenge)
			{
				if (control_mesh && revenge_mesh)
				{
					Vector3 ctop = gGame->camera->position - character->GetPosition();
					Vector3 vec;
					vec.x = character->GetPosition().x;
					vec.y = character->GetPosition().y+1.f;
					vec.z = character->GetPosition().z;
					vec = vec - character->GetPosition();
					if (Dot(ctop, vec) > 0.99f)
					{
						vec.x = character->GetPosition().x;
						vec.y = character->GetPosition().y-1.f;
						vec.z = character->GetPosition().z;
						vec = vec - character->GetPosition();
					}
					Vector3 temp = Cross(ctop, vec);
					temp.Normalize();
					temp = temp * 0.2f;
					temp.y = 1.8f;
					control_mesh->SetPosition(character->GetPosition() + temp);
					control_mesh->SetRotation(GetSkeletonRotation());
					control_mesh->Draw(drawtype, immediate);
	
					Vector3 temp2 = Cross(ctop, vec);
					temp2.Normalize();
					temp2 = temp2 * -0.2f;
					temp2.y = 1.8f;
					revenge_mesh->SetPosition(character->GetPosition() + temp2);
					revenge_mesh->SetRotation(GetSkeletonRotation());
					revenge_mesh->Draw(drawtype, immediate);
				}
			}
			
			if (draw_mesh)
			{
				draw_mesh->SetPosition(character->GetPosition());
				draw_mesh->SetRotation(GetSkeletonRotation());
				draw_mesh->Draw(drawtype, immediate);
			}

			DetachablePartSet::Enumerator it(detachable_part_set);
			while (it.MoveNext())
			{
				it.Value()->Draw(drawtype, immediate);
			}

			if (damage_particle)
			{
				damage_particle->Draw();
			}
            if (clothes_particle1)
            {
				if (clothes_particle)
				{
					clothes_particle->Draw();
				}
            }
		
			if (boostdamage_particle)
			{
				boostdamage_particle->Draw();
			}

			if (ammorecover_particle)
			{
				ammorecover_particle->Draw();
			}
			
			if (healthrecover_particle)
			{
				healthrecover_particle->Draw();
			}

			if (foot_particle)
			{
				foot_particle->Draw();
			}
			if (gun_particle)
			{
				gun_particle->Draw();
			}

			if (human_particle)
			{
				human_particle->Draw();
			}

			if (zombie_particle1)
			{
				zombie_particle1->Draw();
			}

			if (zombie_particle2)
			{
				zombie_particle2->Draw();
			}

			if (invisiblebuffer)
			{
				invisiblebuffer->Draw();
			}

			if (boddy_particle)
			{
				boddy_particle->Draw();
			}

			float t_speed = character->GetAcquiredAttributeByType(kEffect_Infect_MoveSpeed, true);
			if (t_speed > 0.1f && t_speed < 1.f)
			{
				if (slow_particle)
					slow_particle->Draw();
			}
			else if (t_speed <= 0.1f)
			{
				if (qualm_particle)
					qualm_particle->Draw();
			}

			if(character->control_reverse_timer > 0.f)
			{
				if (reverse_particle)
					reverse_particle->Draw();
			}


			if (fast_particle[0] && t_speed > 1.f)
			{
				fast_particle[0]->Draw();
			}
			if (fast_particle[1] && t_speed > 1.f)
			{
				fast_particle[1]->Draw();
			}
			for(int i = 0; i < BOOSTBULLET_PARTICLE_COUNT; i++)
			{
				if (boostdbullet_particle[i] && !boostdbullet_particle[i]->IsDead())
				{
					boostdbullet_particle[i]->Draw();
				}
			}

			for(int i = 0; i < BUFFER_PARTICLE_COUNT; i++)
			{
				if (burn_particle[i] && !burn_particle[i]->IsDead())
				{
					burn_particle[i]->Draw();
				}
			}

			for(int i = 0; i < BUFFER_PARTICLE_COUNT; i++)
			{
				if (poison_particle[i] && !poison_particle[i]->IsDead())
				{
					poison_particle[i]->Draw();
				}
			}


			if(character->is_boss && character->hp < character->max_hp/3)
			{
				for(int i = 0; i < BOSS_DANGER_COUNT; i++)
				{
					if (boss_danger_particle[i] && !boss_danger_particle[i]->IsDead())
					{
						boss_danger_particle[i]->Draw();
					}
				}
			}
		}
	}

	/// get shader lod
	S32 ThirdPerson::GetShaderLod()
	{
		if (draw_mesh)
		{
			return draw_mesh->GetShaderLod();
		}

		return 0;
	}

	void ThirdPerson::UpdateWeapon(float frame_time)
	{
		PROFILE("ThirdPerson::UpdateWeapon");

		if (!character)
			return;

		tempc_ptr(WeaponBase) weapon = GetWeapon(character->weapon_id);

		if (skeleton && pose && weapon && weapon->weapon_info)
		{
			int joint_id = -1;

			switch (weapon->weapon_info->hand_bind_type)
			{
			case WeaponInfo::kHandLeft:
				joint_id = handweapon_l_id;
				break;

			default:
				joint_id = handweapon_r_id;
				break;
			}

			if (weapon->weapon_info->ik_enable && node_list_system->GetActiveKey() == "game")
			{
				Vector3 pos;
				Quaternion rot;
				if (weapon->GetWeaponType() != kWeaponTypeDualPistol)
				{
					if (joint_id >= 0)
					{
						const Transform & transform = pose->GetJointModelPose(joint_id);
						pos = character->GetPosition() + transform.position * GetSkeletonRotation();
						rot = transform.rotation * GetSkeletonRotation();
					}
				}
				else
				{
					tempc_ptr(DualPistol) pistol = ptr_dynamic_cast<DualPistol>(weapon);
					if (pistol)
					{
						joint_id = handweapon_l_id;
						if (joint_id >= 0)
						{
							const Transform &left_transform = pose->GetJointModelPose(joint_id);
							pistol->SetLeftWeaponTransform(left_transform);
						}

						joint_id = handweapon_r_id;
						if (joint_id >= 0)
						{
							const Transform &right_transform = pose->GetJointModelPose(joint_id);
							pistol->SetRightWeaponTransform(right_transform);
						}

						pos = character->GetPosition();
						rot = GetSkeletonRotation();
					}
				}

				weapon->SetPosition(pos);
				weapon->SetRotation(rot);
			}
			else
			{
				int wrist_ik_id = -1;
				int wrist_id = -1;

				if(weapon->GetWeaponType() != kWeaponTypeDualPistol)
				{
					if (joint_id >= 0)
					{
						const Transform & transform = pose->GetJointModelPose(joint_id);
						switch (weapon->weapon_info->hand_bind_type)
						{
						case WeaponInfo::kHandLeft:
							wrist_ik_id = wrist_ik_l_id;;
							wrist_id = wrist_l_id;;
							break;

						default:
							wrist_ik_id = wrist_ik_r_id;
							wrist_id = wrist_r_id;
							break;
						}

						if (wrist_ik_id >= 0 && wrist_id >= 0)
						{
							const Transform & ik_transform = pose->GetJointModelPose(wrist_ik_id);
							const Transform & wrist_transform = pose->GetJointModelPose(wrist_id);
							Quaternion rot = ik_transform.rotation;
							rot.Inverse();
							Vector3 pos = (transform.position - ik_transform.position) * rot;
							rot = transform.rotation * rot;
							rot.Normalize();

							pos = wrist_transform.position + pos * wrist_transform.rotation;
							rot = rot * wrist_transform.rotation;

							pos = character->GetPosition() + pos * GetSkeletonRotation();
							rot = rot * GetSkeletonRotation();

							weapon->SetPosition(pos);
							weapon->SetRotation(rot);
						}
					}
				}
				else
				{
					tempc_ptr(DualPistol) pistol = ptr_dynamic_cast<DualPistol>(weapon);
					if (pistol)
					{						
						joint_id = handweapon_l_id;
						if (joint_id >= 0)
						{
							const Transform & transform = pose->GetJointModelPose(joint_id);
							wrist_ik_id = wrist_ik_l_id;;
							wrist_id = wrist_l_id;

							if (wrist_ik_id >= 0 && wrist_id >= 0)
							{
								Transform left_transform;
								const Transform & ik_transform = pose->GetJointModelPose(wrist_ik_id);
								const Transform & wrist_transform = pose->GetJointModelPose(wrist_id);
								left_transform.rotation = ik_transform.rotation;
								left_transform.rotation.Inverse();
								left_transform.position = (transform.position - ik_transform.position) * left_transform.rotation;
								left_transform.rotation = transform.rotation * left_transform.rotation;
								left_transform.rotation.Normalize();

								left_transform.position = wrist_transform.position + left_transform.position * wrist_transform.rotation;
								left_transform.rotation = left_transform.rotation * wrist_transform.rotation;

								pistol->SetLeftWeaponTransform(left_transform);
							}
						}

						joint_id = handweapon_r_id;
						if (joint_id >= 0)
						{
							const Transform & transform = pose->GetJointModelPose(joint_id);
							wrist_ik_id = wrist_ik_r_id;;
							wrist_id = wrist_r_id;

							if (wrist_ik_id >= 0 && wrist_id >= 0)
							{
								Transform right_transform;
								const Transform & ik_transform = pose->GetJointModelPose(wrist_ik_id);
								const Transform & wrist_transform = pose->GetJointModelPose(wrist_id);
								right_transform.rotation = ik_transform.rotation;
								right_transform.rotation.Inverse();
								right_transform.position = (transform.position - ik_transform.position) * right_transform.rotation;
								right_transform.rotation = transform.rotation * right_transform.rotation;
								right_transform.rotation.Normalize();

								right_transform.position = wrist_transform.position + right_transform.position * wrist_transform.rotation;
								right_transform.rotation = right_transform.rotation * wrist_transform.rotation;

								pistol->SetRightWeaponTransform(right_transform);
							}
						}
					}

					weapon->SetPosition(character->GetPosition());
					weapon->SetRotation(GetSkeletonRotation());
				}
			}

			weapon->UpdateMesh();
			
			tempc_ptr(GunBase) gun = ptr_dynamic_cast<GunBase>(weapon);

			if (gun)
				gun->UpdateEffect(frame_time);

			if (weapon && weapon->weapon_info->weapon_type == kWeaponTypeSpecial)
			{
				weapon->UpdateGrenadeParticle();
			}
		}
	}

	/// udpate equipment
	void ThirdPerson::UpdateEquipment(float frame_time)
	{
		PROFILE("ThirdPerson::UpdateEquipment");
		if(character->equipment_id < 0)
		{
			return;
		}
		tempc_ptr(WeaponBase) weapon;

		if (character)
			weapon = GetWeapon(character->equipment_id);

		if (skeleton && pose && weapon && weapon->weapon_info)
		{
			tempc_ptr(Equipment) equip = ptr_dynamic_cast<Equipment>(weapon);
			if(equip)
			{
				if (equip->bandjoint_id >= 0)
				{
					Vector3 pos;
					Quaternion rot;

					const Transform & transform = pose->GetJointModelPose(equip->bandjoint_id);

					pos = character->GetPosition() + transform.position * GetSkeletonRotation();
					rot = transform.rotation * GetSkeletonRotation();

					weapon->SetPosition(pos);
					weapon->SetRotation(rot);
				}

			}
		}
	}

	void ThirdPerson::UpdateAnimationBossPVE(float frame_time)
	{
		if (!character)
			return;

		if (!character->ispveboss)
			return;

		if (!skeleton)
			return;

		if (!node_list_lower)
			return;

		if (!node_list_upper)
			return;

		if (!node_list_action)
			return;

		if (!node_data_lower)
			return;

		skeleton_rotation_oral = character->GetLookDir();

		node_list_lower->SetActiveNode("stand_idle");
		node_list_upper->SetActiveNode("idle");
		node_list_action->SetActiveNode("idle");
	}

	/// update animation third person
	void ThirdPerson::UpdateAnimationThirdPerson(float frame_time)
	{
		if (!character)
			return;

		if (!skeleton)
			return;

		if (!node_list_lower)
			return;
		
		if (!node_list_upper)
			return;

		if (!node_list_action)
			return;

		if (!node_data_lower)
			return;

		uint lower_state = 0;

		// move state
		float length;

		Vector2 animation_dir = Vector2::kZero;

		Vector3 dir_move = character->GetCurrentSpeed();
		dir_move.y = 0;
		length = dir_move.Length();
		dir_move.Normalize();

		Quaternion rotation = character->GetRotation();
		Vector3 dir_look = Vector3(0, 0, -1) * rotation;
		dir_look.Normalize();

		animation_dir.y = Clamp(Dot(dir_move, dir_look), -1, 1);
		Vector3 cross = Cross(dir_move, dir_look);
		angle_target = Acos(animation_dir.y);
		if (cross.y < 0)
			angle_target = - angle_target;

		animation_dir.x = Sin(Acos(animation_dir.y)) * (cross.y > 0? 1: -1);

		Vector3 front_dir = Vector3(0, 0, -1) * character->GetLookDir();
		front_dir.Normalize();
		float angle_v = Acos(Clamp(Dot(Vector3(0, 1, 0), front_dir), -1, 1));
		angle_v = Clamp(angle_v, 0, PI);
		front_dir.y = 0;
		front_dir.Normalize();
		Vector3 skeleton_dir = Vector3(0, 0, -1) * skeleton_rotation_oral;
		skeleton_dir.Normalize();
		float angle_h = Acos(Clamp(Dot(skeleton_dir, front_dir), -1, 1));
		cross = Cross(skeleton_dir, front_dir);
		if (cross.y > 0)
			angle_h = -angle_h;

		angle_h = Clamp(angle_h, -PI, PI);

		if (length > 0.01f || character->GetDirection() != Vector2::kZero)
		{
			lower_state |= 1;
		}

		float walk_speed = character_info? character_info->walk_speed: 4.f;

		// stance state
		if (character->GetCrouch())
			lower_state |= 2;

		// walk state
		if (character->IsBoost())
			lower_state |= 4;

		lower_animation_rate = 0;

		float angle_abs = Abs(angle_h);

		if (angle_abs > PI * rotate_limit || ((!gLevel->GetPlayer() || gLevel->GetPlayer() == character)&& character->gamestart_time > 0.f))
		{
			skeleton_turn = true;
			float delta = PI * (rotate_limit - 0.01f);
			delta = angle_h > 0? delta: -delta;
			skeleton_rotation_oral = Quaternion(Vector3(0, 1, 0), delta) * rotation;
		}

		if (!skeleton_turn)
		{
			bool turn = false;

			if ((character->IsJumping() && !(lower_state & 2)) || (lower_state & 1))
				turn = true;

			// auto turn
			if ((angle_abs > 5 * DEG2RAD) && Feq(angle_h, angle_h_last))
			{
				skeleton_turn_timer += frame_time;

				if (skeleton_turn_timer > 1.f)
					turn = true;
			}
			else
			{
				angle_h_last = angle_h;
				skeleton_turn_timer = 0;
			}

			if (turn)
			{
				skeleton_turn = true;
				skeleton_rotation_oral = Quaternion(Vector3(0, 1, 0), angle_h) * rotation;
			}
		}

		if (skeleton_turn)
		{
			if (angle_abs <= PI * rotate_limit)
			{
				if (angle_abs < 0.01f)
					skeleton_turn = false;
				else
				{
					float delta = Clamp(frame_time * PI * 1.0f, 0, angle_abs);
					delta = angle_h > 0? delta: -delta;
					skeleton_rotation_oral = Quaternion(Vector3(0, -1, 0), delta) * skeleton_rotation_oral;
				}
			}

			angle_h_last = angle_h;
			skeleton_turn_timer = 0;
		}

		tempc_ptr(AnimationNodeOffset) last_node_direction = ptr_dynamic_cast<AnimationNodeOffset>(node_list_upper->GetActiveNode());

		if (character->IsJumping() && !(lower_state & 2))
		{
			node_list_lower->SetActiveNode("stand_jump",false);
			node_list_upper->SetActiveNode("idle");
			node_list_action->SetActiveNode("idle");
		}
		else
		{
			switch (lower_state)
			{
			case 1:
				{
					node_list_lower->SetActiveNode("stand_run");
					float dir_factor = 0.17f;

					tempc_ptr(AnimationNodeDirection) sequence = ptr_dynamic_cast<AnimationNodeDirection>(node_list_lower->GetActiveNode());

					if (sequence)
					{
						if (lower_state_last != lower_state)
							sequence->SetAngle(angle_target);

						sequence->angle_target = angle_target;
					}

					node_list_upper->SetActiveNode("idle");
					node_list_action->SetActiveNode("idle");

					if (character->IsOnGround() && !jump_to_run)
						node_data_lower->StopAction();
				}
				break;

			case 5:		//walk
				{
					node_list_lower->SetActiveNode("stand_walk");
					float dir_factor = 0.43f;

					tempc_ptr(AnimationNodeDirection) sequence = ptr_dynamic_cast<AnimationNodeDirection>(node_list_lower->GetActiveNode());

					if (sequence)
					{
						if (lower_state_last != lower_state)
							sequence->SetAngle(angle_target);

						sequence->angle_target = angle_target;
						sequence->SetPlayRate(dir_factor * length);
					}

					node_list_upper->SetActiveNode("idle");
					node_list_action->SetActiveNode("idle");

					if (!character->IsBoost())
						node_data_lower->StopAction();
				}
				break;

			case 3:
			case 7:
				{
					node_list_lower->SetActiveNode("crouch_move");
					float dir_factor = 0.47f;

					tempc_ptr(AnimationNodeDirection) sequence = ptr_dynamic_cast<AnimationNodeDirection>(node_list_lower->GetActiveNode());

					if (sequence)
					{
						if (lower_state_last != lower_state)
							sequence->SetAngle(angle_target);

						sequence->angle_target = angle_target;
					}

					node_list_upper->SetActiveNode("crouch_idle");
					node_list_action->SetActiveNode("crouch_idle");

					node_data_lower->StopAction();
				}
				break;

			case 2:
			case 6:
				{
					node_list_lower->SetActiveNode("crouch_idle");
					node_list_upper->SetActiveNode("crouch_idle");
					node_list_action->SetActiveNode("crouch_idle");

					node_data_lower->StopAction();

				}
				break;

			default:
				{
					if (skeleton_turn)
						node_list_lower->SetActiveNode("stand_turn");
					else
						node_list_lower->SetActiveNode("stand_idle");
					node_list_upper->SetActiveNode("idle");
					node_list_action->SetActiveNode("idle");
				}
				break;
			}
		}

		lower_state_last = lower_state;

		tempc_ptr(AnimationNodeOffset) node_direction = ptr_dynamic_cast<AnimationNodeOffset>(node_list_upper->GetActiveNode());

		if (node_direction)
		{
			node_direction->angle_speed = PI * 1.0f;

			// sync direction angle
			if (last_node_direction && (node_direction != last_node_direction))
			{
				node_direction->angle_v = last_node_direction->angle_v;
				node_direction->angle_h = last_node_direction->angle_h;
			}

			node_direction->angle_target_v = angle_v;
			node_direction->angle_target_h = angle_h;
		}

		// node upper blend control
		if (node_upper_blend_info && node_upper_blend_info->map)
		{
			bool changed = false;
			if (length > 0.01f)
			{
				changed = node_upper_blend_info->map->AddJoint("torso", true, SkeletonMap::kNone);
				changed |= node_upper_blend_info->map->AddJoint("hip", false, SkeletonMap::kNone);

				changed |= node_group_blend_info->map->AddJoint("torso", true, SkeletonMap::kNone);
				changed |= node_group_blend_info->map->AddJoint("hip", false, SkeletonMap::kNone);
			}
			else
			{
				changed = node_upper_blend_info->map->AddJoint("torso", true, SkeletonMap::kAddtive);
				changed |= node_upper_blend_info->map->AddJoint("hip", false, SkeletonMap::kAddtive);

				changed |= node_group_blend_info->map->AddJoint("torso", true, SkeletonMap::kAddtive);
				changed |= node_group_blend_info->map->AddJoint("hip", false, SkeletonMap::kAddtive);
			}

			if (animation_system && changed)
				animation_system->ForceBlend();
		}
	}

	/// update animation
	void ThirdPerson::UpdateAnimation(float frame_time)
	{
		PROFILE("ThirdPerson::UpdateAnimation");
		if (character)
		{
			if (!character->ispveboss)
			{
				UpdateAnimationThirdPerson(frame_time);
				if (animation_system)
					animation_system->Update(frame_time);

				if (node_group)
					node_group->Update(frame_time);

				// weapon show animation
				if (node_list_system && node_list_system->GetActiveKey() == "show")
				{
					if (node_random && node_random->ActiveNodeBegin())
					{
						tempc_ptr(WeaponBase) weapon = GetWeapon(character->weapon_id);
						if (weapon)
						{
							weapon->StopAction();

							sharedc_ptr(AnimationNodePose) node_pose = node_random->GetActiveNode();
							if (node_pose)
							{
								weapon->PlayAction(node_pose->GetAnimationKey(), 0.05f);
							}
						}
					}
				}
			}
			else
			{
				UpdateAnimationBossPVE(frame_time);
				if (animation_system)
					animation_system->Update(frame_time);

				if (node_group)
					node_group->Update(frame_time);
			}
		}
	}

	/// jump
	void ThirdPerson::OnJump()
	{
		if (node_data_lower)
			node_data_lower->PlayAction("stdjumpup", 0.05f);
	}

	/// boost
	void ThirdPerson::OnBoost(int dir)
	{
		if (node_data_lower)
		{
			if (dir == 1)
			{
				node_data_lower->PlayAction("stdwalkforward", 0.05f);
			}
			else if( dir == 2)
			{
				node_data_lower->PlayAction("stdwalkback", 0.05f);
			}
			else if( dir == 3)
			{
				node_data_lower->PlayAction("stdwalkleft", 0.05f);
			}
			else if( dir == 4)
			{
				node_data_lower->PlayAction("stdwalkright", 0.05f);
			}
		}
	}

	/// on ground
	void ThirdPerson::OnOnground()
	{
 		if (node_data_lower && character)
		{
			//Vector3 dir_move = character->GetCurrentSpeed();
			//dir_move.y = 0;
			//float length = +-4.Length();

			//if (length > 0.2f)
			//{
				//node_data_lower->PlayAction("stdjumprun", 0.02f, 0.05f);
				//jump_to_run = true;
			//}
			//else
			{
  				node_data_lower->PlayAction("stdjumpdown", 0.02f, 0.15f);
				jump_to_run = false;
			}
		}
	}

	/// fall down
	void ThirdPerson::FallDown(float speed, bool is_onground)
	{
	}

	static void LoadForce(String key, ThirdPerson & person)
	{
		CStrBuf<256> path;
		path.format("/character/die_effect/%s.lua", key.Str());

		sharedc_ptr(ScriptLua) lua = RESOURCE_LOAD(path, false, ScriptLua);

		if (lua)
		{
			Lua::LuaState *L = Lua::LuaState::NewState();
			int top = L->GetTop();
			L->NewTable();
			if (L->LoadBuffer(lua->GetBuffer(), lua->GetSize(), path) == 0)
			{
				L->PushValue(top + 1);

				const static Identifier type_Vector3_name = "Core.Vector3";
				tempc_ptr(PdeTypeInfo) type_info = PdeTypeInfo::FromName(type_Vector3_name);

				if (type_info)
				{
					L->PushPtr(type_info->GetConstructor());
					L->SetField(-2, "Vector3");
				}

				const static Identifier type_Quaternion_name = "Core.Quaternion";
				type_info = PdeTypeInfo::FromName(type_Quaternion_name);

				if (type_info)
				{
					L->PushPtr(type_info->GetConstructor());
					L->SetField(-2, "Quaternion");
				}

				L->SetFenv(-2);

				if (L->DoCall(0, 0))
				{
					const char *msg = L->ToString(-1);
					if (msg) Console.WriteLine(msg);
					L->Pop(1);
				}
				else
				{
					L->GetField(top + 1, "force_set");
					int size = L->ObjLen(-1);

					if (size > 0)
					{
						person.physx_force_set.Resize(size);
						for (int i = 0; i < size; i++)
						{
							L->PushInteger(i + 1);
							L->GetTable(-2);

							L->PushInteger(1);
							L->GetTable(-2);
							String actor_name = L->ToString(-1);
							L->Pop(1);

							person.physx_force_set[i].actor_id = person.GetActorId(actor_name);

							sharedc_ptr(Vector3) v;

							L->PushInteger(2);
							L->GetTable(-2);
							v = ptr_static_cast<Vector3>(L->ToPtr(-1, type_Vector3_name));
							if (v)
								person.physx_force_set[i].force = *v;
							L->Pop(1);

							L->PushInteger(3);
							L->GetTable(-2);
							v = ptr_static_cast<Vector3>(L->ToPtr(-1, type_Vector3_name));
							if (v) 
								person.physx_force_set[i].position = *v;
							L->Pop(1);

							L->PushInteger(4);
							L->GetTable(-2);
							person.physx_force_set[i].space_mode = (ThirdPerson::ForceSpaceMode)(byte)L->ToNumber(-1);
							L->Pop(1);

							L->PushInteger(5);
							L->GetTable(-2);
							person.physx_force_set[i].force_mode = (NxForceMode)(byte)L->ToNumber(-1);
							L->Pop(1);

							L->PushInteger(6);
							L->GetTable(-2);
							person.physx_force_set[i].time = L->ToNumber(-1);
							L->Pop(1);

							L->Pop(1);
						}
					}
				}
			}
			else
			{
				const char *msg = L->ToString(-1);
				if (msg) Console.WriteLine(msg);
				L->Pop(1);
			}

			L->Close();
		}
	}

	/// die
	void ThirdPerson::Die(const HitInfo & hit)
	{
		if (character)
		{
			tempc_ptr(Character) enemy = gLevel->GetCharacter(hit.from_uid);
			float angle = 0;

			if (enemy && enemy != character)
			{
				hit_enemy = enemy;

				Vector3 target_dir = enemy->GetPosition() - character->GetPosition();
				target_dir.y = 0;
				target_dir.Normalize();
				camera_rotation_oral = Normalize(Quaternion(Vector3(0, 0, -1), target_dir));
			}
			else
				camera_rotation_oral = character->GetRotation();

			uint part = hit.part;
			effectbuffertimer = 0.f;
			footbuffertimer = 0.f;
			physx_force_set.Clear();

			Vector3 target_dir = Vector3(0, 0, -1) * hit.dir;
			Vector3 front_dir = Vector3(0, 0, -1) * character->GetRotation();
			angle = Acos(Clamp(Dot(target_dir, front_dir), -1, 1));
			Vector3 cross = Cross(target_dir, front_dir);
			if (cross.y < 0)
				angle = - angle;

			CStrBuf<256> path;
			float force_length = 1000;

			switch (part)
			{
			case kCharacterPartTorso:
			case kCharacterPartBack:
				force_length = 1000;
				path = "torso_";
				break;

			case kCharacterPartChest:
				force_length = 1000;
				path = "chest_";
				break;

			case kCharacterPartHead:
				force_length = 1000;
				path = "head_";
				break;

			case kCharacterPartShoulderL:
			case kCharacterPartArmL:
			case kCharacterPartElbowL:
			case kCharacterPartWristL:
				force_length = 500;
				path = "chest_";
				break;

			case kCharacterPartShoulderR:
			case kCharacterPartArmR:
			case kCharacterPartElbowR:
			case kCharacterPartWristR:
				force_length = 500;
				path = "chest_";
				break;

			case kCharacterPartLegL:
			case kCharacterPartKneeL:
			case kCharacterPartAnkleL:
				force_length = 0;
				path = "leg_l_";
				break;

			case kCharacterPartLegR:
			case kCharacterPartKneeR:
			case kCharacterPartAnkleR:
				force_length = 0;
				path = "leg_r_";
				break;

			default:
				force_length = 1000;
				path = "torso_";
				break;
			}

			if (Abs(angle) <= DEG2RAD * 45)
			{
				path.contract("front_die");
			}
			else if (Abs(angle) >= DEG2RAD * 135)
			{
				path.contract("back_die");
			}
			else if (angle > 0)
			{
				path.contract("right_die");
			}
			else
			{
				path.contract("left_die");
			}

			LoadForce(path, *this);

			if (hit.dir != Quaternion::kIdentity)
			{
				PhysxForce force = { part, Vector3::kZero, force_length * Vector3(0, 0, -1) * hit.dir, kForceSpaceWorld, NX_FORCE, 0.20f};
				physx_force_set.PushBack(force);
			}

			if (character->GetViewMode() == Character::kThirdPerson)
			{
				if (character->is_boss)
				{
					FMOD_VECTOR vel = {0, 0, 0};
					String str = String::Format("bj/player/3d/boss/death");
					FmodSystem::Play3DEvent(str.Str(),(const FMOD_VECTOR &)character->GetPosition(),vel);
				}
				else if (gLevel->game_type == RoomOption::kCommonZombieMode && character_info->career_id == 43)
				{
					Core::String str = Core::String::Format("bj/player/3d/bio/bioshadow_death");
					FmodSystem::PlayEvent(str.Str());
				}
				else if (gLevel && gLevel->game_type == RoomOption::kZombieMode && character->GetTeam() == 1)
				{
					if (character->GetCurCharinfo()->career_id == DEFAULT_ZOMBIE_KING)
					{
						FMOD_VECTOR vel = {0, 0, 0};
						String str = String::Format("bj/player/3d/bio/bioking_death");
						FmodSystem::Play3DEvent(str.Str(),(const FMOD_VECTOR &)character->GetPosition(),vel);
					} 
					else
					{
						FMOD_VECTOR vel = {0, 0, 0};
						String str = String::Format("bj/player/3d/bio/bio_death");
						FmodSystem::Play3DEvent(str.Str(),(const FMOD_VECTOR &)character->GetPosition(),vel);
					}
				} 
				else if (character->ispveboss)
				{
					;
				}
				else if (character->IsCarrierMode() )
				{
					FMOD_VECTOR vel = {0, 0, 0};
					FmodSystem::Play3DEvent("bj/player/3d/tank01/death",(const FMOD_VECTOR &)character->GetPosition(),vel);
				}
				else
				{
					FMOD_VECTOR vel = {0, 0, 0};
					String str = String::Format("bj/player/3d/%s/death",character->GetCurCharinfo()->res_key);
					FmodSystem::Play3DEvent(str.Str(),(const FMOD_VECTOR &)character->GetPosition(),vel);
				}
			}

			ClearFootParticle();
			ClearHumanParticle();
			ClearInvisibleParticle();
			ClearBoddyParticle();
			ClearEffectParticle();
			ClearZombieParticle();
			ClearGunParticle();
		}
	}

	/// set character
	void ThirdPerson::SetCharacter(by_ptr(Character) c)
	{
		character = c;
	}

	/// get skeleton rotation
	const Quaternion & ThirdPerson::GetSkeletonRotation()
	{
		return skeleton_rotation;
	}

	/// get root position
	const Core::Vector3 & ThirdPerson::GetTorsoPosition()
	{
		return root_position;
	}

	/// get camera position
	const Core::Vector3 & ThirdPerson::GetCameraPosition()
	{
		return camera_position;
	}

	/// get camera rotation
	const Core::Quaternion & ThirdPerson::GetCameraRotation()
	{
		return camera_rotation;
	}

	/// grenade throw in
	void ThirdPerson::GrenadeThrowIn()
	{
		if (node_group)
			node_group->PlayAction("default_prepelt", "prepelt");

		if (character)
		{
			FMOD_VECTOR vel = {0, 0, 0};
			String str = String::Format("bj/weapon/3d/grenade/fire_02");
			FmodSystem::Play3DEvent(str.Str(),(const FMOD_VECTOR &)character->GetPosition(),vel);
		}

		tempc_ptr(Grenade) grenade = ptr_dynamic_cast<Grenade>(GetWeapon(character->weapon_id));
		if (grenade)
			grenade->ActionThrowIn();
	}

	/// throw grenade
	void ThirdPerson::GrenadeThrowOut(by_ptr(ThrowableInfo) info, int weapon_id)
	{
		if (character)
		{
			FMOD_VECTOR vel = {0, 0, 0};
			String str = String::Format("bj/weapon/3d/grenade/fire_02");
			FmodSystem::Play3DEvent(str.Str(),(const FMOD_VECTOR &)character->GetPosition(),vel);

			float play_time = 0;
			if (info)
				play_time = info->throw_out_time;

			tempc_ptr(WeaponBase) weapon = GetWeapon(character->weapon_id);
			if (weapon)
				weapon->SetVisible(false);

			if (node_group)
			{
				if (character->GetCrouch())
					node_group->PlayAction("default_pelt", "cropelt", play_time);
				else
					node_group->PlayAction("default_pelt", "stdpelt", play_time);
			}
		}
	}

	/// stop throw grenade
	void ThirdPerson::GrenadeThrowStop()
	{
		if (node_group)
			node_group->StopAction();
	}

	/// knife stab
	void ThirdPerson::Stab(byte type, int weapon_id)
	{
		if (character)
		{
			float play_time = 0;
			tempc_ptr(Knife) knife = ptr_dynamic_cast<Knife>(GetWeapon(character->weapon_id));
			tempc_ptr(ZombieGun) zb_knif = ptr_dynamic_cast<ZombieGun>(GetWeapon(weapon_id));
			if (knife)
			{
				if (knife->knife_info)
				{
					if (type % 2)
						play_time = knife->knife_info->stab_time;
					else
						play_time = knife->knife_info->stab_light_time;
				}

				if (node_group)
				{
					CStrBuf<256> str;

					if (type % 2)
					{
						if (type == 1)
							str = "stab";
						else
							str = "stabhit";
					}
					else
						str = "lightstab";

					if (character->GetCrouch())
						str.insert(0, "cro");
					else
						str.insert(0, "std");

					node_group->PlayAction("default_knife_stab", str, play_time);
				}

				if (character->GetViewMode() == Character::kThirdPerson)
					knife->StabSound(type, true);
			}
			else if (zb_knif)
			{
				if (zb_knif->knife_info)
					play_time = zb_knif->knife_info->stab_light_time;
				if (node_group)
				{
					CStrBuf<256> str;
					if (type == 1)
						str = "stab";
					else
						str = "stabhit";

					if (character->GetCrouch())
						str.insert(0, "cro");
					else
						str.insert(0, "std");

					node_group->PlayAction("default_knife_stab", str, play_time);
				}
				if (character->GetViewMode() == Character::kThirdPerson)
					zb_knif->StabSound(type, true);
			}
		}
	}

	/// stop stab
	void ThirdPerson::StopStab()
	{
		if (node_group)
			node_group->StopAction();
	}

	/// shooting
	void ThirdPerson::Shoot(int weapon_id,bool isboost)
	{
		if (character)
		{
			float play_time = 0;
			tempc_ptr(GunBase) gun = ptr_dynamic_cast<GunBase>(GetWeapon(weapon_id));

			if (gun)
			{
				if (gun->gun_info)
					play_time = gun->gun_info->fire_time + character->fire_time_ratio;

				tempc_ptr(AnimationNodePose) action;
				
				if (node_group)
				{
					if (node_data_upper)
						node_data_upper->StopAction();
	
					if (character->GetCrouch())
					{
						//if(gun->GetWeaponType() == kWeaponTypeMilkbottle)
						/*{
							node_data_upper->PlayAction("stdidle_chazhi",0.2f,true,play_time,false);
						}*/
						switch(gun->GetWeaponType())
						{
						case kWeaponTypeCureGun:
							{
								if(node_group && cure_state == 0)
								{
									cure_state = 1;
									node_group->PlayAction("laser_shoot", "croshoot", play_time);
								}
								if (gun->gun_fire_particle)
									gLevel->AddParticle(gun->gun_fire_particle);
							}
							return;
						case kWeaponTypeMiniMachineGun:
							{
								if(node_group && mini_state == 0)
								{
									mini_state = 1;
									node_group->PlayAction("minimachinegun_shoot", "stdshootright", play_time);	
								}
							}
							break;
						default:
							node_group->PlayAction("defaultshoot", "croshoot", play_time);
							break;
						}
					}
					else
					{
						if(gun->GetWeaponType() == kWeaponTypeMilkbottle)
						{
							node_data_upper->PlayAction("stdidle_chazhi",0.2f,true,play_time,false);
						}
						switch(gun->GetWeaponType())
						{
						case kWeaponTypeCureGun:
							{
								if(node_group && cure_state_thr == 0)
								{
									cure_state_thr = 1;
									node_group->PlayAction("laser_shoot","stdshoot", play_time);
								}
								if (gun->gun_fire_particle)
									gLevel->AddParticle(gun->gun_fire_particle);
							}
							return;
						case kWeaponTypeMiniMachineGun:
							{
								if(node_group && mini_state_thr == 0)
								{
									mini_state_thr = 1;
									node_group->PlayAction("minimachinegun_shoot", "stdshootright", play_time);	
								}
							}
							break;
						default:
							node_group->PlayAction("defaultshoot","stdshoot", play_time);
							break;
						}
					}
				}

				if (node_blend_hit)
					node_blend_hit->StopAction();
				if (character->GetViewMode() == Character::kThirdPerson)
				{
					// gun effect
					gun->FireEffect(isboost);
					gun->FireSound(true);
				}
			}
		}
	}

	/// stop shooting
	void ThirdPerson::StopShoot()
	{
		if (node_group)
		{
			if (node_group->IsNowNode("defaultshoot"))
			{
				node_group->StopAction(false);
			}
			else if (node_group->IsNowNode("laser_shoot"))
			{
				cure_state = 0;
				cure_state_thr = 0;
				node_group->StopAction();
			}
			else if (node_group->IsNowNode("minimachinegun_shoot"))
			{
				mini_state = 0;
				mini_state_thr = 0;
				node_group->StopAction();
			}
		}
	}
	
	sharedc_ptr(Bomb) ThirdPerson::GetBomb()
	{
		sharedc_ptr(Bomb) weapon = ptr_dynamic_cast<Bomb>(GetWeapon(BOMB_SLOT));

		return weapon;

	}

	void ThirdPerson::PlantBomb()
	{
		if (!character)
			return;

		sharedc_ptr(Bomb) bomb = GetBomb();
		if(bomb)
		{
			if (node_group)
			{
				if (character->GetCrouch())
					node_group->PlayAction("default_pelt", "cropelt", bomb->bomb_info->plant_time);
				else
					node_group->PlayAction("default_pelt", "stdpelt", bomb->bomb_info->plant_time);
			}
			bomb->PlantBomb();
		}

	}

	/// reload
	void ThirdPerson::Reload()
	{
		if (character)
		{
			tempc_ptr(GunBase) gun = ptr_dynamic_cast<GunBase>(GetWeapon(character->weapon_id));

			if (gun)
			{
				float play_time = 0;
				if (gun->gun_info)
					play_time = gun->gun_info->reload_time;

				if (node_group)
				{
					
					if (gun->GetWeaponType() == kWeaponTypeShotGun)
					{
						play_time *= 3.0f;
						reload_multianimation = true;
						node_data_upper->PlayAction("stdidle_chazhi",0.2f,false,play_time,false);
						node_group->PlayAction("shotgun_reload","stdreloadone");
					}
					else if (gun->GetWeaponType() == kWeaponTypeLuncher)
					{

						tempc_ptr(Luncher) luncher = ptr_dynamic_cast<Luncher>(gun);
						if(luncher->GetLuncherAmmoType() == kWeaponTypeAmmoRocket && luncher->isReloadOneAmmo())
						{
							play_time *= 3.0f;
							reload_multianimation = true;
							node_data_upper->PlayAction("stdidle_chazhi",0.2f,false,play_time,false);
							node_group->PlayAction("rocketlauncher_reload","stdreloadone");
						}
						else
						{	
							node_data_upper->PlayAction("stdidle_chazhi",0.2f,false,play_time,false);
							if (character->GetCrouch())
								node_group->PlayAction("defaultreload","croreload");
							else
								node_group->PlayAction("defaultreload","stdreload");
							luncher->animation->PlayAction("reload", 0.02f, false);
						}
					}
					else
					{
						node_data_upper->PlayAction("stdidle_chazhi",0.2f,false,play_time,false);
						if (character->GetCrouch())
							node_group->PlayAction("defaultreload","croreload");
						else
							node_group->PlayAction("defaultreload","stdreload");
					}

				}

				gun->ReloadAction();

				if (character->GetViewMode() == Character::kThirdPerson)
					gun->ReloadSound(true);
			}
		}
	}

	/// select weapon
	void ThirdPerson::SelectWeapon(uint id)
	{
		tempc_ptr(WeaponBase) weapon = GetWeapon(id);	

		if (weapon)
		{
			if (node_group)
				node_group->StopAction();

			if (node_data_upper)
				node_data_upper->StopAction();

			if (animation_set && id < animation_set_weapon.Size())
				animation_set->SetAnimationSet("weapon", animation_set_weapon[id]);

			if (node_group && weapon->weapon_info && !character->ispveboss)
			{
				switch (weapon->weapon_info->weapon_type)
				{
				case kWeaponTypeLuncher:
				case kWeaponTypeSignal:
					{
						tempc_ptr(Luncher) gun = ptr_dynamic_cast<Luncher>(weapon);
						node_group->RegisterEvent(gun);
					}
					break;
				case kWeaponTypeShotGun:
					{
						tempc_ptr(ShotGun) gun = ptr_dynamic_cast<ShotGun>(weapon);
						node_group->RegisterEvent(gun);
					}
					break;
				case kWeaponTypeCureGun:
					{
						tempc_ptr(CureGun) gun = ptr_dynamic_cast<CureGun>(weapon);
						node_group->RegisterEvent(gun);
					}
					break;
				default:
					node_group->RegisterEvent(NullPtr);
					break;
				}
			}
		}
	}

	/// weapon active
	void ThirdPerson::WeaponActive(uint id)
	{
		tempc_ptr(WeaponBase) weapon= GetWeapon(id);
		if (weapon)
			weapon->Active();

		CreateGunParticle();
	}

	/// weapon inactive
	void ThirdPerson::WeaponInactive(uint id)
	{
		tempc_ptr(WeaponBase) weapon = GetWeapon(id);
		if (weapon)
			weapon->Inactive();

		ClearGunParticle();
	}

	/// set weapon
	void ThirdPerson::SetWeapon(int slot, by_ptr(WeaponInfo) info)
	{
		if (slot >= 0 && slot < 7)
		{
			if (character)
			{
				sharedc_ptr(WeaponBase) w;
				CStrBuf<256> str_animation;

				if (info)
				{
					w = character->CreateWeapon(info);

					if (w)
					{
						w->SetOwner(character);
						w->Initialize();
						w->SetMeshLod(1);
						Attribute attrinfo;
						if(w->weapon_info->weapon_type == kWeaponTypeEquipment)
						{
							character->equipment_id = slot;
							
							tempc_ptr(Equipment) equip = ptr_dynamic_cast<Equipment>(w);
							if(equip)
								equip->bandjoint_id =  skeleton->GetJointId(equip->equipmentinfo->bandjoint);

							character->equipment_info = w->weapon_info;
							character->SetSelfTransparency(true, character->equipment_info);
							
							if(w->weapon_info->CheckWeaponAttribute(kweaponAttr_Self_SniperAssist,attrinfo))		
								character->bsniperassist = true;			
							
							if(w->weapon_info->CheckWeaponAttribute(kWeaponAttr_Self_MiniGunAccurate,character->attr_minigunaccurate))
								character->breducespread = true;
						}
					}

					if (character_info)
						str_animation.format("%s/%s", character_info->third_person_animationset, info->animation_set);
				}
				else
				{
					/*if (character_info)
						str_animation.format("%s/pose", character_info->third_person_animationset);*/
					return;
				}
				

				animation_set_weapon[slot] = RESOURCE_GET_BYTYPE(RESOURCE_NAME(ANIMATION_KEY_CHARACTER, str_animation), ANIMATIONSET_TYPE, AnimationSetRes);
				if (animation_set_weapon[slot])
				{
					animation_set_weapon[slot]->Load(true);
				}

				if (weapons[slot])
					weapons[slot]->Inactive();

				weapons[slot] = w;

				if (animation_set && slot == character->weapon_id)
					animation_set->SetAnimationSet("weapon", animation_set_weapon[slot]);
			}
		}
	}

	/// get weapon
	tempc_ptr(WeaponBase) ThirdPerson::GetWeapon(int id)
	{
		if (id >= 0 && id < (int)weapons.Size())
			return weapons[id];

		return NullPtr;
	}

	/// set character info
	void ThirdPerson::SetCharacterInfo(by_ptr(CharacterInfo) info)
	{
		character_info = info;
	}

	/// preload animation
	void ThirdPerson::PreloadAnimation(by_ptr(WeaponInfo) info)
	{
		if (info && character_info/* && skeleton*/)
		{
			CStrBuf<256> str;
			str.format("%s/%s", character_info->third_person_animationset, info->animation_set);
			sharedc_ptr(AnimationSetRes) res = RESOURCE_GET_BYTYPE(RESOURCE_NAME(ANIMATION_KEY_CHARACTER, str), ANIMATIONSET_TYPE, AnimationSetRes);
			if (res)
			{
				res->Load(true);
				if (gLevel->animation_manager)
					gLevel->animation_manager->AddAnimationSetRes(res->GetKey(), res);
			}
		}
	}

	/// preload animation
	void ThirdPerson::PreloadAnimation(const PackInfo & info)
	{
		for (uint i = 0; i < info.weapon_set.Size(); ++i)
		{
			PreloadAnimation(info.weapon_set[i]);
		}
	}
	
	/// use skill
	void ThirdPerson::UseSkill(by_ptr(PlayerSkill) skill)
	{
		if (character && skill)
		{

		}
	}

	/// use skill stop
	void ThirdPerson::UseSkillStop(by_ptr(PlayerSkill) skill)
	{
		if (character && skill)
		{

		}
	}


	/// recover
	void ThirdPerson::Recover(int health,byte recover_type)
	{
		if (character && recover_type == ChannelConnection::kRecoverSupplyHp  )
		{

			healthrecover_particle->SetEnable(true);
			healthrecover_particle->Reset();
		}
		
	}
	/// ammorecover
	void ThirdPerson::AmmoRecover(short ammocount,byte recovertype)
	{
		//if (character && recovertype == ChannelConnection::kSupplyAmmo_1)
		//{
		//	ammorecover_particle->SetEnable(true);
		//	ammorecover_particle->Reset();
		//}
	}
	/// recover stop
	void ThirdPerson::RecoverStop()
	{
	}

	/// burn
	void ThirdPerson::Burn()
	{
		for(UINT i = 0; i < BUFFER_PARTICLE_COUNT/2; i++)
		{
			UINT j = rand()%(BUFFER_PARTICLE_COUNT/2) + (BUFFER_PARTICLE_COUNT - BUFFER_PARTICLE_COUNT/2);
			UINT tmp = arry_buffer_rand[i];
			arry_buffer_rand[i] = arry_buffer_rand[j];
			arry_buffer_rand[j] = tmp;
		}

		for(int i = 0; i < 2; i++)
		{
			burn_particle[arry_buffer_rand[i]]->Reset();
		}
		
	}

	/// burn stop
	void ThirdPerson::BurnStop()
	{
		for(UINT i = 0; i < BUFFER_PARTICLE_COUNT; i++)
		{
			if(!burn_particle[i]->IsDead())
			{
				burn_particle[i]->SetDead();
			}
		}
	}


	/// poison
	void ThirdPerson::Poison()
	{
		for(UINT i = 0; i < BUFFER_PARTICLE_COUNT/2; i++)
		{
			UINT j = rand()%(BUFFER_PARTICLE_COUNT/2) + (BUFFER_PARTICLE_COUNT - BUFFER_PARTICLE_COUNT/2);
			UINT tmp = arry_buffer_rand[i];
			arry_buffer_rand[i] = arry_buffer_rand[j];
			arry_buffer_rand[j] = tmp;
		}

		for(int i = 0; i < 2; i++)
		{
			poison_particle[arry_buffer_rand[i]]->Reset();
		}

	}

	/// poison stop
	void ThirdPerson::PoisonStop()
	{
		for(UINT i = 0; i < BUFFER_PARTICLE_COUNT; i++)
		{
			if(!poison_particle[i]->IsDead())
			{
				poison_particle[i]->SetDead();
			}
		}
	}


	void ThirdPerson::PlayBossDanger()
	{
		if(!character->is_boss)
			return;
		for(UINT i = 0; i < BOSS_DANGER_COUNT/2; i++)
		{
			UINT j = rand()%(BOSS_DANGER_COUNT/2) + (BOSS_DANGER_COUNT - BOSS_DANGER_COUNT/2);
			UINT tmp = arry_boss_danger_rand[i];
			arry_boss_danger_rand[i] = arry_boss_danger_rand[j];
			arry_boss_danger_rand[j] = tmp;
		}

		for(int i = 0; i < 2; i++)
		{
			boss_danger_particle[arry_boss_danger_rand[i]]->Reset();
		}
	}

	void ThirdPerson::StopPlayBossDanger()
	{
		if(!character->is_boss)
			return;
		for(UINT i = 0; i < BOSS_DANGER_COUNT; i++)
		{
			if(!boss_danger_particle[i]->IsDead())
			{
				boss_danger_particle[i]->SetDead();
			}
		}
	}
	// drop weapon
	void ThirdPerson::DropWeapon(int slot)
	{
		if (character && !character->IsDied() && character_info)
		{
			if (character->GetViewMode() == Character::kThirdPerson)
			{
				FMOD::Event* audio_event = FmodSystem::GetEvent(character_info->third_person_sound_weapon_drop);
				FMOD_VECTOR pos = (const FMOD_VECTOR &)character->GetPosition();
				FMOD_VECTOR vel = {0, 0, 0};
				audio_event->set3DAttributes(&pos, &vel);
				if (audio_event)
					audio_event->start();
			}
		}
	}

	// pick up weapon
	void ThirdPerson::PickUpWeapon(int slot, by_ptr(WeaponInfo) info)
	{
		if (character && character_info)
		{
			if (character->GetViewMode() == Character::kThirdPerson)
			{
				FMOD::Event* audio_event = FmodSystem::GetEvent(character_info->third_person_sound_weapon_pickup);
				FMOD_VECTOR pos = (const FMOD_VECTOR &)character->GetPosition();
				FMOD_VECTOR vel = {0, 0, 0};
				audio_event->set3DAttributes(&pos, &vel);
				if (audio_event)
					audio_event->start();
			}
		}
	}

	/// set physx group
	void ThirdPerson::SetPhysxGroup(uint id)
	{
		for (uint i = 0; i < physx_actor_set.Size(); ++i)
		{
			Actor & actor = physx_actor_set[i];
			NxShape* shape =  actor.actor->getShapes()[0];
			if (shape)
				shape->setGroup(id);
		}
	}

	/// response hit
	void ThirdPerson::ResponseHit(const Vector3 & from_position, const Vector3 & target, const Vector3 & normal, int part, UINT weapontype, bool no_blood, bool isboost)
	{
		if (character)
		{
			if (!no_blood)
			{
				CStrBuf<256> str;
				static const char szTeam[2] = {'r', 'b'};
				switch(weapontype)
				{
				case kWeaponTypeGrenade:
				case kWeaponTypeAmmoGrenade:
				case kWeaponTypeFlameGun:
				case kWeaponTypeAmmoBloodDisk:
				//case kWeaponTypeSniperGun:
					{
						str.contract("bullet_");

						if (part == kCharacterPartHead)
							str.contract("head");
						else
							str.contract("body");
					}
					break;
				case kWeaponTypeSniperGun:
					{
						str.contract("bulletbody_");
						str.contract("sniper");
						if(isboost)
						{
							str.contractf("_b%c", szTeam[character->GetTeam() & 1]);
						}
					}
					break;
				case kWeaponTypeAmmoRocket: 
					{
						str.contract("bulletbody_");
						str.contract("shell");
					}
					break;
				default:
					{
						str.contract("bulletbody_");
						str.contract("normal");
						if(isboost)
						{
							str.contractf("_b%c", szTeam[character->GetTeam() & 1]);
						}
					}
					break;
				}
				gLevel->AddParticle(str, target, normal);
			}

			if (!character->IsDied() && node_blend_hit)
			{
				if (node_blend_hit->IsActionPlaying() && node_blend_hit->node_action)
				{
					float total_time = node_blend_hit->node_action->GetTotalTime();
					if (total_time > 0)
					{
						float rate = Fmod(node_blend_hit->node_action->GetTime(), total_time) / total_time;
						if (rate < 0.6f)
							return;
					}

				}

				bool from_back = false;

				if (from_position != Vector3::kZero)
				{
					Vector3 front_dir = Vector3(0, 0, -1) * character->GetRotation();
					Vector3 dir = from_position - character->GetPosition();
					dir.Normalize();
					from_back = Dot(front_dir, dir) < 0;
				}

				//switch (part)
				//{
				//case kCharacterPartHead:
				//	{
				//		if (character->GetCrouch())
				//		{
				//			if (from_back)
				//				node_blend_hit->PlayAction("crohitheadback", 0.05f);
				//			else
				//				node_blend_hit->PlayAction("crohithead", 0.05f);
				//		}
				//		else
				//		{
				//			if (from_back)
				//				node_blend_hit->PlayAction("stdhitheadback", 0.05f);
				//			else
				//				node_blend_hit->PlayAction("stdhithead", 0.05f);
				//		}
				//	}
				//	break;

				//case kCharacterPartShoulderL:
				//case kCharacterPartArmL:
				//case kCharacterPartElbowL:
				//case kCharacterPartWristL:
				//	{
				//		if (character->GetCrouch())
				//			node_blend_hit->PlayAction("crohitleftarm", 0.05f);
				//		else
				//			node_blend_hit->PlayAction("stdhitleftarm", 0.05f);
				//	}
				//	break;

				//case kCharacterPartShoulderR:
				//case kCharacterPartArmR:
				//case kCharacterPartElbowR:
				//case kCharacterPartWristR:
				//	{
				//		if (character->GetCrouch())
				//			node_blend_hit->PlayAction("crohitrightarm", 0.05f);
				//		else
				//			node_blend_hit->PlayAction("stdhitrightarm", 0.05f);
				//	}
				//	break;

				//case kCharacterPartLegL:
				//case kCharacterPartKneeL:
				//case kCharacterPartAnkleL:
				//case kCharacterPartLegR:
				//case kCharacterPartKneeR:
				//case kCharacterPartAnkleR:
				//	{
				//		if (character->GetCrouch())
				//			node_blend_hit->PlayAction("crohitleg", 0.05f);
				//		else
				//			node_blend_hit->PlayAction("stdhitleg", 0.05f);
				//	}
				//	break;

				//default:
					{
						if (character->GetCrouch())
						{
							if (from_back)
								node_blend_hit->PlayAction("stdhitback", 0.05f);
							else
								node_blend_hit->PlayAction("stdhit", 0.05f);
						}
						else
						{
							if (from_back)
								node_blend_hit->PlayAction("stdhitback", 0.05f);
							else
								node_blend_hit->PlayAction("stdhit", 0.05f);
						}
					}
				//	break;
				//}
			}
		}
	}

	/// on kill
	void ThirdPerson::OnKill(const HitInfo & info)
	{
	}

	/// on hit
	void ThirdPerson::OnHit(const HitInfo & info)
	{
		Vector3 head_pos;
		Quaternion head_rot;

		if (GetJointInfo("hat", head_pos, head_rot))
		{
			if(!info.boost)
			{
				if (character && damage_particle)
				{
					int damage = character->hp - info.hp;
					if (damage > 0)
					{
						damage_particle->SetPosition(head_pos + Vector3(0, 0.2f, 0));
						damage_particle->SpawnNumber(damage);
						damage_particle->SetEnable(true);
						damage_particle->Reset();
					}
				}
			}
			else
			{
				if (character && boostdamage_particle)
				{
					int damage = character->hp - info.hp;

					if (damage > 0)
					{
						boostdamage_particle->SetPosition(head_pos + Vector3(0, 0.2f, 0));
						boostdamage_particle->SpawnNumber(damage);
						boostdamage_particle->SetEnable(true);
						boostdamage_particle->Reset();

						//if(!boostdbullet_particle[curboostindex])
						//{
						//	boostdbullet_particle[curboostindex] = ptr_new ParticleSystem("bullet_crit");
						//}
						if(!boostdbullet_particle[curboostindex]->IsDead())
						{
							boostdbullet_particle[curboostindex]->ResetEmittersParticles();
						}

						boostdbullet_particle[curboostindex]->SetEnable(true);
						boostdbullet_particle[curboostindex]->Reset();
						curboostindex = (curboostindex + 1) % BOOSTBULLET_PARTICLE_COUNT;
					}
				}
			}
		}
		
		if (character_info && gLevel)
		{
			Vector3 hit_dir = Vector3(0, 0, -1) * info.dir;
			//hit_dir.y += 1.0f;
			hit_dir.Normalize();

			Core::Array<Identifier> dead_arry;

			DetachablePartSet::Enumerator it(detachable_part_set);
			while (it.MoveNext())
			{
				tempc_ptr(DetachablePart) detachable_part = it.Value();
				if (detachable_part && detachable_part->OnHit(info.part, (float)info.hp / character->max_hp, hit_dir))
				{
					gLevel->detachablepart_array.Add(detachable_part);

					dead_arry.Add(it.Key());
				}
			}

			for (U32 index = 0; index < dead_arry.Size(); index++)
			{
				detachable_part_set.Remove(dead_arry[index]);
			}
		}
	}

	/// on grenade explode
	void ThirdPerson::OnGrenadeExplode()
	{
	}

	/// on bomb explode
	void ThirdPerson::OnBombExploded()
	{
	}

	/// rebirth
	void ThirdPerson::Rebirth()
	{
		if (character)
		{
			draw_mesh = mesh;
			
			Update(0);
			UpdateAnimationJoint(0);

			SyncPhysxPosition();
		}
	}

	/// set physx position
	void ThirdPerson::SyncPhysxPosition()
	{
		if (character && character->GetPhysxControl() == false)
		{
			if (pose)
			{
				// set actor
				for (uint i = 0; i < physx_actor_set.Size(); ++i)
				{
					if (physx_actor_set[i].actor->readBodyFlag(NX_BF_KINEMATIC))
					{
						const Transform & transform = pose->GetJointModelPose(physx_actor_set[i].joint_id);
						Quaternion rot = transform.rotation * GetSkeletonRotation();
						Vector3 pos = character->GetPosition() + transform.position * GetSkeletonRotation();

						physx_actor_set[i].actor->setGlobalPosition((const NxVec3&)pos);
						physx_actor_set[i].actor->setGlobalOrientationQuat((const NxQuat&)rot);
					}
				}
			}
		}
	}
}

namespace Client
{
	/// set physx control
	void ThirdPerson::SetPhysxControl(bool flag)
	{
		if (flag)
		{
			for (uint i = 0; i < physx_actor_set.Size(); ++i)
			{
				if (physx_actor_set[i].actor)
					physx_actor_set[i].actor->clearBodyFlag(NX_BF_KINEMATIC);

				if (pose)
					pose->SetJointLockPose(physx_actor_set[i].joint_id, true);
			}
		}
		else
		{
			for (uint i = 0; i < physx_actor_set.Size(); ++i)
			{
				if (physx_actor_set[i].actor)
					physx_actor_set[i].actor->raiseBodyFlag(NX_BF_KINEMATIC);

				if (pose)
					pose->SetJointLockPose(physx_actor_set[i].joint_id, false);
			}
		}
	}

	/// get actor id
	int ThirdPerson::GetActorId(const Identifier & name)
	{
		for (uint id = 0; id < physx_actor_set.Size(); ++id)
		{
			if (name == physx_actor_set[id].name)
				return id;
		}

		return -1;
	}

	/// get actor id
	int ThirdPerson::GetActorId(NxActor* pActor)
	{
		for (uint id = 0; id < physx_actor_set.Size(); ++id)
		{
			if (pActor == physx_actor_set[id].actor)
				return id;
		}

		return -1;
	}

	uint ThirdPerson::GetJointIdFromActorId(uint id)
	{
		if(id >= 0 && id< physx_actor_set.Size())
		{
			return physx_actor_set[id].joint_id;
		}

		return 0;
	}


	static const float part_damages[] =
	{
		// torso back_b back_c
		1.0f, 1.0f, 1.0f,

		// head
		4.0f,

		// shoulder_l arm_l elbow_l, wrist_l
		1.0f, 1.0f, 0.75f, 0.5f,

		// shoulder_r arm_r elbow_r, wrist_r
		1.0f, 1.0f, 0.75f, 0.5f,

		// leg left
		0.9f, 0.6f, 0.5f,

		// leg right
		0.9f, 0.6f, 0.5f,
	};

	Identifier joint_ik_names[] = { "ankleIK_l", "ankleIK_r" };

	/// get damage part
	int ThirdPerson::GetDamagePart(int part1, int part2)
	{
		if (part1 >= 0 && part1 < kCharacterPartCount
			&& part2 >= 0 && part2 < kCharacterPartCount)
			if (part_damages[part2] > part_damages[part1])
				return part2;
		
		return part1;
	}

	static bool ActorRayCast(uint teamid, NxActor* actor, const NxVec3 & pos, NxRaycastHit & hit)
	{
		if (actor)
		{
			NxRay ray;
			ray.orig = pos;
			ray.dir = actor->getGlobalPosition() - pos;
			ray.dir.normalize();

			uint group_id = 0;
			group_id |= 1 << PhysxSystem::kStatic;
			group_id |= 1 << PhysxSystem::kPlayer;
			group_id |= 1 << PhysxSystem::kStaticRaycast;
			group_id |= 1 << (teamid + PhysxSystem::kGroupStart);
			group_id |= 1 << PhysxSystem::kGroupVehicle;
			NxShape* shape = gPhysxScene->raycastClosestShape(ray, NX_ALL_SHAPES, hit, group_id);

			if (shape)
			{
				NxActor& raycast_actor = shape->getActor();
				if (raycast_actor.userData == actor->userData)
					return true;
			}
		}

		return false;
	}

	static bool ActorRayCast2(uint teamid, NxActor* actor, const NxVec3 & pos, NxRaycastHit & hit)
	{
		if (actor)
		{
			NxRay ray;
			ray.orig = pos;
			ray.dir = actor->getGlobalPosition() - pos;
			ray.dir.normalize();

			uint group_id = 0;
			group_id |= 1 << PhysxSystem::kStatic;
			//group_id |= 1 << PhysxSystem::kPlayer;
			//group_id |= 1 << PhysxSystem::kStaticRaycast;
			group_id |= 1 << (teamid + PhysxSystem::kGroupStart);
			//group_id |= 1 << PhysxSystem::kGroupVehicle;
			NxShape* shape = gPhysxScene->raycastClosestShape(ray, NX_ALL_SHAPES, hit, group_id);

			if (shape)
			{
				NxActor& raycast_actor = shape->getActor();
				if (raycast_actor.userData == actor->userData)
					return true;
			}
		}

		return false;
	}

	/// check grenade
	bool ThirdPerson::CheckGrenade(const Core::Vector3 & pos, float & distance)
	{
		NxRaycastHit hit;

		for (uint i = 0; i < physx_actor_set.Size(); ++i)
		{
			if (ActorRayCast(character->GetTeam(), physx_actor_set[i].actor, (const NxVec3 &)pos, hit))
			{
				distance = hit.distance;
				return true;
			}
		}

		return false;
	}

	/// check grenade2
	bool ThirdPerson::CheckGrenade2(const Core::Vector3 & pos, float & distance)
	{
		NxRaycastHit hit;

		//LogSystem.WriteLinef("CheckGrenade2() : %f %f %f", pos.x, pos.y, pos.z);

		for (uint i = 0; i < physx_actor_set.Size(); ++i)
		{
			if (ActorRayCast2(character->GetTeam(), physx_actor_set[i].actor, (const NxVec3 &)pos, hit))
			{
				distance = hit.distance;
				return true;
			}
		}

		return false;
	}

	/// check flash
	bool ThirdPerson::CheckFlash(const Core::Vector3 & pos, float & distance, bool & back_bright)
	{
		if (character)
		{
			NxRaycastHit hit;

			int actor_id = GetActorId("head");

			if (actor_id >= 0 && actor_id < (int)physx_actor_set.Size())
			{
				NxActor* actor = physx_actor_set[actor_id].actor;
				if (ActorRayCast(character->GetTeam(), actor, (const NxVec3 &)pos, hit))
				{
					Vector3 dir = pos - (const Vector3 &)actor->getGlobalPosition();
					dir.Normalize();
					Vector3 head_dir = Vector3(0, 0, -1) * character->GetLookDir();
					head_dir.Normalize();

					distance = hit.distance;
					back_bright = false;

					if (Dot(dir, head_dir) < Cos(DEG2RAD * 120))
						back_bright = true;

					return true;
				}
			}
		}

		return false;
	}

	void  ThirdPerson::UpdateAnimationJoint(float frame_time)
	{
		PROFILE("ThirdPerson::UpdateAnimationJoint");

		if (!character)
			return;

		if (!skeleton)
			return;

		if (!animation_system)
			return;

		if (!pose)
			return;

		tempc_ptr(Pose) animation_pose = animation_system->GetPose();

		if (animation_pose)
			pose->CopyLocalPose(animation_pose->GetLocalPose());
		else
			pose->CopyLocalPose(skeleton->GetLocalPose());


		if (node_list_system->GetActiveKey() == "show")
			return;

		PROFILE_START("IK");
		tempc_ptr(WeaponBase) weapon = GetWeapon(character->weapon_id);
		if (weapon && weapon->weapon_info/* && weapon->weapon_info->ik_enable*/)
		{
			if (weapon->weapon_info->ik_enable || weapon->weapon_info->hand_bind_type == WeaponInfo::kHandRight)
			{
				// ik solver
				if (wrist_ik_l_id > 0)
				{
					Transform target;
					if (!weapon->weapon_info->ik_enable)
					{
						if (wrist_ik_r_id > 0 && wrist_r_id > 0)
						{
							const Transform & ik_l_transform = pose->GetJointModelPose(wrist_ik_l_id);
							const Transform & ik_r_transform = pose->GetJointModelPose(wrist_ik_r_id);
							const Transform & wrist_transform = pose->GetJointModelPose(wrist_r_id);
							Quaternion rot = ik_r_transform.rotation;
							rot.Inverse();
							Vector3 pos = (ik_l_transform.position - ik_r_transform.position) * rot;
							rot = ik_l_transform.rotation * rot;

							target.position = wrist_transform.position + pos * wrist_transform.rotation;
							target.rotation = rot * wrist_transform.rotation;
						}
					}
					else
						target = pose->GetJointModelPose(wrist_ik_l_id);

					Transform parent_transform;
					for (uint i = 0; i < ik_l_joints.Size(); ++i)
					{
						tempc_ptr(IkJoint) joint = ik_l_joints[i];
						if (joint)
						{
							if (i == 0)
							{
								int parent_id = skeleton->GetJointParentId(joint->joint_index);
								parent_transform = pose->GetJointModelPose(parent_id);
							}
							joint->transform = pose->GetJointModelPose(joint->joint_index);
						}
					}

					IkSolver::Solver(ik_l_joints, target, 10, 0.001f);

					for (uint i = 0; i < ik_l_joints.Size(); ++i)
					{
						tempc_ptr(IkJoint) joint = ik_l_joints[i];
						if (joint && !joint->lock)
						{
							Quaternion rot;
							if (i == 0)
								rot = parent_transform.rotation;
							else
								rot = ik_l_joints[i - 1]->transform.rotation;

							rot.Inverse();
							rot = joint->transform.rotation * rot;

							pose->SetJointLocalPoseRotation(joint->joint_index, rot);
						}
					}
				}
			}

			if (weapon->weapon_info->ik_enable || weapon->weapon_info->hand_bind_type == WeaponInfo::kHandLeft)
			{
				if (wrist_ik_r_id > 0)
				{
					Transform target;
					if (!weapon->weapon_info->ik_enable)
					{
						if (wrist_ik_l_id > 0 && wrist_l_id > 0)
						{
							const Transform & ik_l_transform = pose->GetJointModelPose(wrist_ik_r_id);
							const Transform & ik_r_transform = pose->GetJointModelPose(wrist_ik_l_id);
							const Transform & wrist_transform = pose->GetJointModelPose(wrist_l_id);
							Quaternion rot = ik_r_transform.rotation;
							rot.Inverse();
							Vector3 pos = (ik_l_transform.position - ik_r_transform.position) * rot;
							rot = ik_l_transform.rotation * rot;

							target.position = wrist_transform.position + pos * wrist_transform.rotation;
							target.rotation = rot * wrist_transform.rotation;
						}
					}
					else
						target = pose->GetJointModelPose(wrist_ik_r_id);

					Transform parent_transform;
					for (uint i = 0; i < ik_r_joints.Size(); ++i)
					{
						tempc_ptr(IkJoint) joint = ik_r_joints[i];
						if (joint)
						{
							if (i == 0)
							{
								int parent_id = skeleton->GetJointParentId(joint->joint_index);
								parent_transform = pose->GetJointModelPose(parent_id);
							}
							joint->transform = pose->GetJointModelPose(joint->joint_index);
						}
					}

					IkSolver::Solver(ik_r_joints, target, 10, 0.001f);

					for (uint i = 0; i < ik_r_joints.Size(); ++i)
					{
						tempc_ptr(IkJoint) joint = ik_r_joints[i];
						if (joint && !joint->lock)
						{
							Quaternion rot;
							if (i == 0)
								rot = parent_transform.rotation;
							else
								rot = ik_r_joints[i - 1]->transform.rotation;

							rot.Inverse();
							rot = joint->transform.rotation * rot;

							pose->SetJointLocalPoseRotation(joint->joint_index, rot);
						}
					}
				}
			}
		}

		// leg ik
		if (0)
		{
			for (int ik_id = 0; ik_id < 2; ik_id++)
			{
				if (ik_leg_joints[ik_id].Size() > 1)
				{
					uint joint_id = skeleton->GetJointId(joint_ik_names[ik_id]);

					if (joint_id == -1)
						continue;

					Transform target = pose->GetJointModelPose(joint_id);
					target = pose->GetJointModelPose(ik_leg_joints[ik_id].Back()->joint_index);

					if (character->IsOnGround())
					{
						uint group_id = 0;
						group_id |= 1 << PhysxSystem::kStatic;

						const float ik_move_up = 0.4f;
						const float ik_move_down = 0.4f;

						NxCapsule capsule;
						capsule.radius = 0.1f;
						capsule.p0 = capsule.p1 = binary_cast<NxVec3>(Vector3(target.position.x, 0, target.position.z) * GetSkeletonRotation() + character->GetPosition() + Vector3(0, ik_move_up + capsule.radius, 0)); 

						NxSweepQueryHit hit;
						float ik_offset = 0;

						if (gPhysxScene->linearCapsuleSweep(capsule, NxVec3(0, -(ik_move_up + ik_move_down), 0), NX_SF_STATICS, NULL, 1, &hit, NULL, group_id, NULL))
							ik_offset = ik_move_up - (ik_move_up + ik_move_down) * hit.t;

						if (ik_leg_offset[ik_id] > ik_offset)
							ik_leg_offset[ik_id] = Max(ik_offset, ik_leg_offset[ik_id] - frame_time * 3.0f);

						if (ik_leg_offset[ik_id] < ik_offset)
							ik_leg_offset[ik_id] = Min(ik_offset, ik_leg_offset[ik_id] + frame_time * 3.0f);


						target.position.y += ik_leg_offset[ik_id];
					}
					else
					{
						ik_leg_offset[ik_id] = 0;
					}

					Transform parent_transform;
					for (uint i = 0; i < ik_leg_joints[ik_id].Size(); ++i)
					{
						tempc_ptr(IkJoint) joint = ik_leg_joints[ik_id][i];
						if (joint)
						{
							if (i == 0)
							{
								int parent_id = skeleton->GetJointParentId(joint->joint_index);
								parent_transform = pose->GetJointModelPose(parent_id);
							}
							joint->transform = pose->GetJointModelPose(joint->joint_index);
						}
					}

					IkSolver::Solver(ik_leg_joints[ik_id], target, 10, 0.001f);

					for (uint i = 0; i < ik_leg_joints[ik_id].Size(); ++i)
					{
						tempc_ptr(IkJoint) joint = ik_leg_joints[ik_id][i];
						if (joint && !joint->lock)
						{
							Quaternion rot;
							if (i == 0)
								rot = parent_transform.rotation;
							else
								rot = ik_leg_joints[ik_id][i - 1]->transform.rotation;

							rot.Inverse();
							rot = joint->transform.rotation * rot;
							rot.Normalize();

							pose->SetJointLocalPoseRotation(joint->joint_index, rot);
						}
					}
				}
			}
		}
		PROFILE_END("IK");

		if (pose)
			root_position = pose->GetJointModelPose(skeleton->GetJointId("torso")).position - Vector3(0, 1, 0);
	}

	enum ActorType
	{
		kSphere,
		kCapsule,
		kBox,
	};

	struct ActorDesc
	{
		Core::Identifier	name;
		ActorType			type;
		Core::Vector3		shape;
		bool				set_local_position;
		Core::Vector3		local_position;
		bool				set_local_rotation;
		Core::Quaternion	local_rotation;
	};


	enum JointType
	{
		kSpherical,
		kRevolute,
	};

	struct JointDesc
	{
		Identifier	a1_name;
		Identifier	a2_name;
		JointType	type;
		Vector3		axis;
		Vector3		data;
	};

	/// create actor
	static NxActor* CreateActor(const ActorDesc& desc)
	{
		switch (desc.type)
		{
		case kSphere:
			return PhysxSystem::CreateSphere(Vector3::kZero, desc.shape.x, PhysxSystem::kNone);
			break;

		case kCapsule:
			return PhysxSystem::CreateCapsule(Vector3::kZero, desc.shape.x, desc.shape.y, PhysxSystem::kNone);
			break;

		case kBox:
			return PhysxSystem::CreateBox(Vector3::kZero, Vector3(desc.shape.x, desc.shape.y, desc.shape.z), PhysxSystem::kNone);
			break;

		default:
			break;
		}

		return NULL;
	}

	/// get joint info
	bool ThirdPerson::GetJointInfo(const Core::Identifier & joint_name, Core::Vector3 &position, Core::Quaternion &rotation)
	{
		if (skeleton && pose)
		{
			int joint_id = skeleton->GetJointId(joint_name);

			if (joint_id >= 0)
			{
				const Transform & transform = pose->GetJointModelPose(joint_id);

				position = character->GetPosition() + transform.position * character->GetSkeletonRotation();
				rotation = transform.rotation * character->GetSkeletonRotation();

				return true;
			}
		}

		return false;
	}

	/// get joint info
	bool ThirdPerson::GetJointInfo(uint joint_id, Core::Vector3 &position, Core::Quaternion &rotation)
	{
		if (skeleton && pose)
		{
			if (joint_id >= 0)
			{
				const Transform & transform = pose->GetJointModelPose(joint_id);

				position = character->GetPosition() + transform.position * character->GetSkeletonRotation();
				rotation = transform.rotation * character->GetSkeletonRotation();

				return true;
			}
		}

		return false;
	}

	/// create animation
	void ThirdPerson::CreateThirdPersonAnimation()
	{
		animation_set = ptr_new AnimationSet;

		if (!skeleton)
			return;

//		skeleton->SetJointBlendSkip("wristIK_l", true);
//		skeleton->SetJointBlendSkip("wristIK_r", true);

		animation_system = ptr_new AnimationNodeCustom(skeleton);
		animation_system->SetAnimationSet(animation_set);
		if (animation_system->node_data)
			animation_system->node_data->blend_total_time = 0.f;

		node_list_system = ptr_new AnimationNodeList();
		animation_system->SetAnimationNode(node_list_system);
		sharedc_ptr(AnimationNodeBlend) animation_blend = ptr_new AnimationNodeBlend(skeleton);
		node_list_system->AddNode("game", animation_blend);

		node_random = ptr_new AnimationNodeRandom();

		sharedc_ptr(AnimationNodePose) node_pose = ptr_new AnimationNodePose(skeleton);
		node_pose->SetAnimation("stdmenu", animation_set);
		node_random->AddNode(node_pose, 0);
	
		node_list_system->AddNode("show", node_random);
		node_list_system->SetActiveNode("game");

		//upper
		{
			node_list_upper = ptr_new AnimationNodeList();
			node_data_upper = ptr_new AnimationNodeCustom(skeleton);
			node_data_upper->SetAnimationSet(animation_set);
			node_data_upper->SetAnimationNode(node_list_upper);
			if (node_data_upper->node_data)
				node_data_upper->node_data->blend_total_time = 0.08f;

			node_upper_blend_info = ptr_new BlendInfo;
			node_upper_blend_info->node = node_data_upper;
			node_upper_blend_info->map = ptr_new SkeletonMap(skeleton);
		}

		//lower
		{
			node_list_lower = ptr_new AnimationNodeSync(skeleton);
			node_data_lower = ptr_new AnimationNodeCustom(skeleton);
			if (node_data_lower->node_data)
				node_data_lower->node_data->blend_total_time = 0.1f;
			node_data_lower->SetAnimationSet(animation_set);
			node_data_lower->SetAnimationNode(node_list_lower);

			node_lower_blend_info = ptr_new BlendInfo;
			node_lower_blend_info->node = node_data_lower;
			node_lower_blend_info->map = ptr_new SkeletonMap(skeleton);
		}
		
		//node_group
		{
			node_group = ptr_new AnimationNodeGroup(skeleton);
			node_group->SetAnimationSet(animation_set);
			node_list_action = ptr_new AnimationNodeList();
			node_group->SetAnimationNode(node_list_action);
			node_group->SetThirdPerson();
			node_group->LoadGroupNode("group_action");

			node_group_blend_info = ptr_new BlendInfo;
			node_group_blend_info->node = node_group->node_action;
			node_group_blend_info->map = ptr_new SkeletonMap(skeleton);
		}
		
		//hit
		{
			node_blend_hit = ptr_new AnimationNodeCustom(skeleton);
			node_blend_hit->SetAnimationSet(animation_set);

			node_hit_blend_info = ptr_new BlendInfo;
			node_hit_blend_info->node = node_blend_hit;
			node_hit_blend_info->map = ptr_new SkeletonMap(skeleton);
		}
		
		//face
		{
			node_face = ptr_new AnimationNodeCustom(skeleton);
			node_face->SetAnimationSet(animation_set);

			node_face_blend_info = ptr_new BlendInfo;
			node_face_blend_info->node = node_face;
			node_face_blend_info->map = ptr_new SkeletonMap(skeleton);
		}
		

		{
			//////////////////////////////////////////////////////////////////////////
			CStrBuf<256> filename;
			filename.format("/character/%s/script.lua",character_info->third_person_animationset);

			sharedc_ptr(ScriptLua) lua = RESOURCE_LOAD(filename.buff(), false, ScriptLua);
			if (lua)
			{
				Lua::LuaState *L = Lua::LuaState::NewState();
				int top = L->GetTop();
				L->NewTable();
				if (L->LoadBuffer(lua->GetBuffer(), lua->GetSize(), filename.buff()) == 0)
				{

					L->PushValue(top + 1);
					L->SetFenv(-2);

					if (L->DoCall(0, 0))
					{
						const char *msg = L->ToString(-1);
						if (msg) Console.WriteLine(msg);
						L->Pop(1);
					}
					else
					{
						L->GetField(-1, "node_upper_blend_map");
						int array_size = L->ObjLen(-1);
						for(int i = 1; i <= array_size; i++)
						{
							L->PushInteger(i);
							L->GetTable(-2);

							L->PushInteger(1);
							L->GetTable(-2);
							String jointname = L->ToString(-1);
							L->Pop(1);

							L->PushInteger(2);
							L->GetTable(-2);
							bool bskipchild = L->ToBoolean(-1);
							L->Pop(1);

							L->PushInteger(3);
							L->GetTable(-2);
							byte type = L->ToInteger(-1);
							L->Pop(1);
							node_upper_blend_info->map->AddJoint(jointname,bskipchild,type);
 
							L->Pop(1);
						}
						L->Pop(1);

						L->GetField(-1, "node_lower_blend_map");
						array_size = L->ObjLen(-1);
						for(int i = 1; i <= array_size; i++)
						{
							L->PushInteger(i);
							L->GetTable(-2);

							L->PushInteger(1);
							L->GetTable(-2);
							String jointname = L->ToString(-1);
							L->Pop(1);

							L->PushInteger(2);
							L->GetTable(-2);
							bool bskipchild = L->ToBoolean(-1);
							L->Pop(1);

							L->PushInteger(3);
							L->GetTable(-2);
							byte type = L->ToInteger(-1);
							L->Pop(1);
							node_lower_blend_info->map->AddJoint(jointname,bskipchild,type);
							L->Pop(1);
						}
						L->Pop(1);

						L->GetField(-1, "node_face_blend_map");
						array_size = L->ObjLen(-1);
						for(int i = 1; i <= array_size; i++)
						{
							L->PushInteger(i);
							L->GetTable(-2);

							L->PushInteger(1);
							L->GetTable(-2);
							String jointname = L->ToString(-1);
							L->Pop(1);

							L->PushInteger(2);
							L->GetTable(-2);
							bool bskipchild = L->ToBoolean(-1);
							L->Pop(1);

							L->PushInteger(3);
							L->GetTable(-2);
							byte type = L->ToInteger(-1);
							L->Pop(1);
							node_face_blend_info->map->AddJoint(jointname,bskipchild,type);
							L->Pop(1);
						}
						L->Pop(1);

						L->GetField(-1, "node_action_blend_map");
						array_size = L->ObjLen(-1);
						for(int i = 1; i <= array_size; i++)
						{
							L->PushInteger(i);
							L->GetTable(-2);

							L->PushInteger(1);
							L->GetTable(-2);
							String jointname = L->ToString(-1);
							L->Pop(1);

							L->PushInteger(2);
							L->GetTable(-2);
							bool bskipchild = L->ToBoolean(-1);
							L->Pop(1);

							L->PushInteger(3);
							L->GetTable(-2);
							byte type = L->ToInteger(-1);
							L->Pop(1);
							node_group_blend_info->map->AddJoint(jointname,bskipchild,type);
							L->Pop(1);
						}
						L->Pop(1);

						L->GetField(-1, "node_hit_blend_map");
						array_size = L->ObjLen(-1);
						for(int i = 1; i <= array_size; i++)
						{
							L->PushInteger(i);
							L->GetTable(-2);

							L->PushInteger(1);
							L->GetTable(-2);
							String jointname = L->ToString(-1);
							L->Pop(1);

							L->PushInteger(2);
							L->GetTable(-2);
							bool bskipchild = L->ToBoolean(-1);
							L->Pop(1);

							L->PushInteger(3);
							L->GetTable(-2);
							byte type = L->ToInteger(-1);
							L->Pop(1);
							node_hit_blend_info->map->AddJoint(jointname,bskipchild,type);
							L->Pop(1);
						}
						L->Pop(1);

						L->GetField(-1, "animation_info");
						array_size = L->ObjLen(-1);

						if(array_size > 0)
						{
							for(int i = 1; i <= array_size; i++)
							{
								L->PushInteger(i);
								L->GetTable(-2);

								L->PushInteger(1);
								L->GetTable(-2);
								String index = L->ToString(-1);
								L->Pop(1);

								if(index == "rotate_limit")
								{
									L->PushInteger(2);
									L->GetTable(-2);
									rotate_limit = L->ToNumber(-1);
									L->Pop(1);
								}

								L->Pop(1);
							}

						}
						L->Pop(1);


					}
				}
				else
				{
					const char *msg = L->ToString(-1);
					if (msg) Console.WriteLine(msg);
					L->Pop(1);
				}

				L->Close();
			}
			//////////////////////////////////////////////////////////////////////////
		}

		{
			animation_blend->AddNodeByInfo(node_upper_blend_info);
			animation_blend->AddNodeByInfo(node_lower_blend_info);
			animation_blend->AddNodeByInfo(node_hit_blend_info);
			animation_blend->AddNodeByInfo(node_face_blend_info);
			animation_blend->AddNodeByInfo(node_group_blend_info);
		}
		
		sharedc_ptr(AnimationNodePose) pose;
		pose = ptr_new AnimationNodePose(skeleton);
		pose->SetAnimation("stdidle", animation_set);
		node_list_lower->AddNode("stand_idle", pose);
		pose = ptr_new AnimationNodePose(skeleton);
		pose->SetAnimation("croidle", animation_set);
		node_list_lower->AddNode("crouch_idle", pose);
		pose = ptr_new AnimationNodePose(skeleton);
		pose->SetAnimation("stdjump", animation_set);
		node_list_lower->AddNode("stand_jump", pose);
		node_list_lower->SetActiveNode("stand_idle");

		pose = ptr_new AnimationNodePose(skeleton);
		pose->SetAnimation("stdturn", animation_set);
		node_list_lower->AddNode("stand_turn", pose);
		pose = ptr_new AnimationNodePose(skeleton);
		pose->SetAnimation("croturn", animation_set);
		node_list_lower->AddNode("crouch_turn", pose);

		sharedc_ptr(AnimationNodeDirection) animation_dir = ptr_new AnimationNodeDirection(skeleton);
		pose = ptr_new AnimationNodePose(skeleton);
		pose->SetAnimation("stdrunforward", animation_set);
		pose->SetAddtiveBase("stdidlebase");
		animation_dir->animation_forward = pose;
		pose = ptr_new AnimationNodePose(skeleton);
		pose->SetAnimation("stdrunback", animation_set);
		pose->SetAddtiveBase("stdidlebase");
		animation_dir->animation_back = pose;
		pose = ptr_new AnimationNodePose(skeleton);
		pose->SetAnimation("stdrunleft", animation_set);
		pose->SetAddtiveBase("stdidlebase");
		animation_dir->animation_left = pose;
		pose = ptr_new AnimationNodePose(skeleton);
		pose->SetAnimation("stdrunright", animation_set);
		pose->SetAddtiveBase("stdidlebase");
		animation_dir->animation_right = pose;
		pose = ptr_new AnimationNodePose(skeleton);
		pose->SetAnimation("stdrunforwardleft", animation_set);
		pose->SetAddtiveBase("stdidlebase");
		animation_dir->animation_forward_left = pose;
		pose = ptr_new AnimationNodePose(skeleton);
		pose->SetAnimation("stdrunforwardright", animation_set);
		pose->SetAddtiveBase("stdidlebase");
		animation_dir->animation_forward_right = pose;
		pose = ptr_new AnimationNodePose(skeleton);
		pose->SetAnimation("stdrunbackleft", animation_set);
		pose->SetAddtiveBase("stdidlebase");
		animation_dir->animation_back_left = pose;
		pose = ptr_new AnimationNodePose(skeleton);
		pose->SetAnimation("stdrunbackright", animation_set);
		pose->SetAddtiveBase("stdidlebase");
		animation_dir->animation_back_right = pose;
		node_list_lower->AddNode("stand_run", animation_dir);

		animation_dir = ptr_new AnimationNodeDirection(skeleton);
		pose = ptr_new AnimationNodePose(skeleton);
		pose->SetAnimation("stdwalkforward", animation_set);
		pose->SetAddtiveBase("stdidlebase");
		animation_dir->animation_forward = pose;
		pose = ptr_new AnimationNodePose(skeleton);
		pose->SetAnimation("stdwalkback", animation_set);
		pose->SetAddtiveBase("stdidlebase");
		animation_dir->animation_back = pose;
		pose = ptr_new AnimationNodePose(skeleton);
		pose->SetAnimation("stdwalkleft", animation_set);
		pose->SetAddtiveBase("stdidlebase");
		animation_dir->animation_left = pose;
		pose = ptr_new AnimationNodePose(skeleton);
		pose->SetAnimation("stdwalkright", animation_set);
		pose->SetAddtiveBase("stdidlebase");
		animation_dir->animation_right = pose;
		pose = ptr_new AnimationNodePose(skeleton);
		pose->SetAnimation("stdwalkforwardleft", animation_set);
		pose->SetAddtiveBase("stdidlebase");
		animation_dir->animation_forward_left = pose;
		pose = ptr_new AnimationNodePose(skeleton);
		pose->SetAnimation("stdwalkforwardright", animation_set);
		pose->SetAddtiveBase("stdidlebase");
		animation_dir->animation_forward_right = pose;
		pose = ptr_new AnimationNodePose(skeleton);
		pose->SetAnimation("stdwalkbackleft", animation_set);
		pose->SetAddtiveBase("stdidlebase");
		animation_dir->animation_back_left = pose;
		pose = ptr_new AnimationNodePose(skeleton);
		pose->SetAnimation("stdwalkbackright", animation_set);
		pose->SetAddtiveBase("stdidlebase");
		animation_dir->animation_back_right = pose;
		node_list_lower->AddNode("stand_walk", animation_dir);

		animation_dir = ptr_new AnimationNodeDirection(skeleton);
		pose = ptr_new AnimationNodePose(skeleton);
		pose->SetAnimation("crowalkforward", animation_set);
		pose->SetAddtiveBase("croidlebase");
		animation_dir->animation_forward = pose;
		pose = ptr_new AnimationNodePose(skeleton);
		pose->SetAnimation("crowalkback", animation_set);
		pose->SetAddtiveBase("croidlebase");
		animation_dir->animation_back = pose;
		pose = ptr_new AnimationNodePose(skeleton);
		pose->SetAnimation("crowalkleft", animation_set);
		pose->SetAddtiveBase("croidlebase");
		animation_dir->animation_left = pose;
		pose = ptr_new AnimationNodePose(skeleton);
		pose->SetAnimation("crowalkright", animation_set);
		pose->SetAddtiveBase("croidlebase");
		animation_dir->animation_right = pose;
		pose = ptr_new AnimationNodePose(skeleton);
		pose->SetAnimation("crowalkforwardleft", animation_set);
		pose->SetAddtiveBase("croidlebase");
		animation_dir->animation_forward_left = pose;
		pose = ptr_new AnimationNodePose(skeleton);
		pose->SetAnimation("crowalkforwardright", animation_set);
		pose->SetAddtiveBase("croidlebase");
		animation_dir->animation_forward_right = pose;
		pose = ptr_new AnimationNodePose(skeleton);
		pose->SetAnimation("crowalkbackleft", animation_set);
		pose->SetAddtiveBase("croidlebase");
		animation_dir->animation_back_left = pose;
		pose = ptr_new AnimationNodePose(skeleton);
		pose->SetAnimation("crowalkbackright", animation_set);
		pose->SetAddtiveBase("croidlebase");
		animation_dir->animation_back_right = pose;
		node_list_lower->AddNode("crouch_move", animation_dir);
		pose->SetAddtiveBase("croidlebase");

		sharedc_ptr(AnimationNodeOffset) node_direction = ptr_new AnimationNodeOffset(skeleton);
		node_direction->SetAnimation("stdturn180", animation_set);
		node_list_upper->AddNode("idle", node_direction);
		node_direction = ptr_new AnimationNodeOffset(skeleton);
		node_direction->SetAnimation("croturn180", animation_set);
		node_direction->angle_v_down_max = 50 * DEG2RAD;
		node_list_upper->AddNode("crouch_idle", node_direction);
		node_list_upper->SetActiveNode("idle");

		pose = ptr_new AnimationNodePose(skeleton);
		pose->SetAnimation("stdidle", animation_set);
		node_list_action->AddNode("idle", pose);

		pose = ptr_new AnimationNodePose(skeleton);
		pose->SetAnimation("croidle", animation_set);
		node_list_action->AddNode("crouch_idle", pose);
		node_list_action->SetActiveNode("idle");
	}

	static void LoadActor(const String &path, Array<ActorDesc> & desc)
	{
		Lua::LuaState *L = Lua::LuaState::NewState();
		int top = L->GetTop();
		L->NewTable();
		if (L->LoadFile(path) == 0)
		{
			L->PushValue(top + 1);

			const static Identifier type_Vector3_name = "Core.Vector3";
			tempc_ptr(PdeTypeInfo) type_info = PdeTypeInfo::FromName(type_Vector3_name);

			if (type_info)
			{
				L->PushPtr(type_info->GetConstructor());
				L->SetField(-2, "Vector3");
			}

			const static Identifier type_Quaternion_name = "Core.Quaternion";
			type_info = PdeTypeInfo::FromName(type_Quaternion_name);

			if (type_info)
			{
				L->PushPtr(type_info->GetConstructor());
				L->SetField(-2, "Quaternion");
			}

			L->SetFenv(-2);

			if (L->DoCall(0, 0))
			{
				const char *msg = L->ToString(-1);
				if (msg) Console.WriteLine(msg);
				L->Pop(1);
			}
			else
			{
				L->GetField(top + 1, "actor_set");
				int size = L->ObjLen(-1);

				if (size > 0)
				{
					desc.Resize(size);
					for (int i = 0; i < size; i++)
					{
						L->PushInteger(i + 1);
						L->GetTable(-2);

						L->PushInteger(1);
						L->GetTable(-2);
						desc[i].name = L->ToString(-1);
						L->Pop(1);

						L->PushInteger(2);
						L->GetTable(-2);
						desc[i].type = (ActorType)(byte)L->ToNumber(-1);
						L->Pop(1);

						sharedc_ptr(Vector3) v;

						L->PushInteger(3);
						L->GetTable(-2);
						v = ptr_static_cast<Vector3>(L->ToPtr(-1, type_Vector3_name));
						if (v)
							desc[i].shape = *v;
						L->Pop(1);

						L->PushInteger(4);
						L->GetTable(-2);
						desc[i].set_local_position = L->ToBoolean(-1);
						L->Pop(1);

						L->PushInteger(5);
						L->GetTable(-2);
						v = ptr_static_cast<Vector3>(L->ToPtr(-1, type_Vector3_name));
						if (v)
							desc[i].local_position = *v;
						L->Pop(1);

						L->PushInteger(6);
						L->GetTable(-2);
						desc[i].set_local_rotation = L->ToBoolean(-1);
						L->Pop(1);

						L->PushInteger(7);
						L->GetTable(-2);
						sharedc_ptr(Quaternion) q = ptr_static_cast<Quaternion>(L->ToPtr(-1, type_Quaternion_name));
						if (v)
							desc[i].local_rotation = *q;
						L->Pop(1);

						L->Pop(1);
					}
				}
			}
		}
		else
		{
			const char *msg = L->ToString(-1);
			if (msg) Console.WriteLine(msg);
			L->Pop(1);
		}

		L->SetTop(top);

		L->Close();
	}

	static void LoadJoint(const String &path, Array<JointDesc> & desc)
	{
		Lua::LuaState *L = Lua::LuaState::NewState();
		int top = L->GetTop();
		L->NewTable();
		if (L->LoadFile(path) == 0)
		{
			L->PushValue(top + 1);

			const static Identifier type_Vector3_name = "Core.Vector3";
			tempc_ptr(PdeTypeInfo) type_info = PdeTypeInfo::FromName(type_Vector3_name);

			if (type_info)
			{
				L->PushPtr(type_info->GetConstructor());
				L->SetField(-2, "Vector3");
			}

			const static Identifier type_Quaternion_name = "Core.Quaternion";
			type_info = PdeTypeInfo::FromName(type_Quaternion_name);

			if (type_info)
			{
				L->PushPtr(type_info->GetConstructor());
				L->SetField(-2, "Quaternion");
			}

			L->SetFenv(-2);

			if (L->DoCall(0, 0))
			{
				const char *msg = L->ToString(-1);
				if (msg) Console.WriteLine(msg);
				L->Pop(1);
			}
			else
			{
				L->GetField(top + 1, "joint_set");
				int size = L->ObjLen(-1);

				if (size > 0)
				{
					desc.Resize(size);
					for (int i = 0; i < size; i++)
					{
						L->PushInteger(i + 1);
						L->GetTable(-2);

						L->PushInteger(1);
						L->GetTable(-2);
						desc[i].a1_name = L->ToString(-1);
						L->Pop(1);

						L->PushInteger(2);
						L->GetTable(-2);
						desc[i].a2_name = L->ToString(-1);
						L->Pop(1);

						L->PushInteger(3);
						L->GetTable(-2);
						desc[i].type = (JointType)(byte)L->ToNumber(-1);
						L->Pop(1);

						sharedc_ptr(Vector3) v;

						L->PushInteger(4);
						L->GetTable(-2);
						v = ptr_static_cast<Vector3>(L->ToPtr(-1, type_Vector3_name));
						if (v)
							desc[i].axis = *v;
						L->Pop(1);

						L->PushInteger(5);
						L->GetTable(-2);
						v = ptr_static_cast<Vector3>(L->ToPtr(-1, type_Vector3_name));
						if (v)
							desc[i].data = *v;
						L->Pop(1);

						L->Pop(1);
					}
				}
			}
		}
		else
		{
			const char *msg = L->ToString(-1);
			if (msg) Console.WriteLine(msg);
			L->Pop(1);
		}

		L->SetTop(top);
		L->Close();
	}

	/// create physx object
	void ThirdPerson::CreatePhysxObject()
	{
		if (!character)
			return;

		if (!character_info)
			return;

		if (!skeleton)
			return;

		ReleasePhysxObject();

		String path = String::Format("/character/%s/physx.lua", character_info->career_key);

		int physx_group = character->GetPhysxGroup();

		Array<ActorDesc> actor_desc_set;

		LoadActor(path, actor_desc_set);

		uint actor_size = actor_desc_set.Size();
		physx_actor_set.Resize(actor_size);

		Vector3 position = character->GetPosition();

		for (uint i = 0; i < actor_size; ++i)
		{
			Actor & actor = physx_actor_set[i];
			ActorDesc & desc = actor_desc_set[i];

			actor.name = desc.name;
			actor.joint_id = skeleton->GetJointId(actor.name);

			if (actor.joint_id >= 0 && actor.joint_id < skeleton->GetJointCount())
			{
				array_physix_id[actor.joint_id] = i;

				NxActor* pAction = CreateActor(desc);
				actor.actor = pAction;

				if (pAction)
				{
					pAction->setLinearDamping(1);
					const Transform & transform = skeleton->GetJonitModelPose(actor.joint_id);
					Vector3 pos  = position + transform.position * GetSkeletonRotation();
					Quaternion qot = transform.rotation * GetSkeletonRotation();

					pAction->setGlobalPosition((const NxVec3&)pos);
					pAction->setGlobalOrientationQuat((const NxQuat&)qot);

					pAction->userData = character;

					NxShape* shape =  pAction->getShapes()[0];

					if (shape)
					{
						shape->setGroup(physx_group);
						if (desc.set_local_position)
							shape->setLocalPosition((const NxVec3 &)desc.local_position);

						if (desc.set_local_rotation)
							shape->setLocalOrientation((const NxQuat &)desc.local_rotation);
					}
				}
			}
		}

		//set actor kinematic state
		for (uint i = 0; i < physx_actor_set.Size(); ++i)
		{
			if (physx_actor_set[i].actor)
				physx_actor_set[i].actor->raiseBodyFlag(NX_BF_KINEMATIC);
		}

	//**************************************************************************************************************	
	//                                       create joints
	//**************************************************************************************************************	
		Array<JointDesc> joint_desc_set;

		LoadJoint(path, joint_desc_set);

		uint joint_size = joint_desc_set.Size();

		for (uint i = 0; i < joint_size; ++i)
		{
			JointDesc & desc = joint_desc_set[i];

			int a1_id = GetActorId(desc.a1_name);
			int a2_id = GetActorId(desc.a2_name);

			if (a1_id >= 0 && a2_id >= 0)
			{
				switch (desc.type)
				{
				case kSpherical:
					{
						NxSphericalJointDesc spherical_desc;
						PhysxSystem::DefaultSphericalJointDesc(spherical_desc, physx_actor_set[a1_id].actor, physx_actor_set[a2_id].actor, desc.axis);
						spherical_desc.twistLimit.high.value = DEG2RAD * desc.data.x;
						spherical_desc.twistLimit.low.value = DEG2RAD * desc.data.y;
						spherical_desc.swingLimit.value = DEG2RAD * desc.data.z;
						physx_joint_set.PushBack(PhysxSystem::CreateJoint(spherical_desc));
					}
					break;

				case kRevolute:
					{
						NxRevoluteJointDesc revolute_desc;
						PhysxSystem::DefaultRevoluteJointDesc(revolute_desc, physx_actor_set[a1_id].actor, physx_actor_set[a2_id].actor, desc.axis);
						revolute_desc.limit.high.value = DEG2RAD * desc.data.x;
						revolute_desc.limit.low.value = DEG2RAD * desc.data.y;
						physx_joint_set.PushBack(PhysxSystem::CreateJoint(revolute_desc));
					}
					break;

				default:
					break;
				}
			}
		}

		// ik left hand
		sharedc_ptr(IkJoint) ik_joint = ptr_new IkJoint;
		ik_joint->joint_index = skeleton->GetJointId("arm_l");
		ik_l_joints.PushBack(ik_joint);

		ik_joint = ptr_new IkJoint;
		ik_joint->joint_index = skeleton->GetJointId("elbow_l");
		ik_l_joints.PushBack(ik_joint);

		ik_joint = ptr_new IkJoint;
		ik_joint->joint_index = skeleton->GetJointId("wrist_l");
		ik_l_joints.PushBack(ik_joint);

		// ik right hand
		ik_joint = ptr_new IkJoint;
		ik_joint->joint_index = skeleton->GetJointId("arm_r");
		ik_r_joints.PushBack(ik_joint);

		ik_joint = ptr_new IkJoint;
		ik_joint->joint_index = skeleton->GetJointId("elbow_r");
		ik_r_joints.PushBack(ik_joint);

		ik_joint = ptr_new IkJoint;
		ik_joint->joint_index = skeleton->GetJointId("wrist_r");
		ik_r_joints.PushBack(ik_joint);

		// leg IK
		ik_joint = ptr_new IkJoint;
		ik_joint->joint_index = skeleton->GetJointId("leg_l");
		ik_leg_joints[0].PushBack(ik_joint);

		ik_joint = ptr_new IkJoint;
		ik_joint->joint_index = skeleton->GetJointId("knee_l");
		ik_leg_joints[0].PushBack(ik_joint);

		ik_joint = ptr_new IkJoint;
		ik_joint->joint_index = skeleton->GetJointId("ankle_l");
		ik_leg_joints[0].PushBack(ik_joint);

		ik_joint = ptr_new IkJoint;
		ik_joint->joint_index = skeleton->GetJointId("leg_r");
		ik_leg_joints[1].PushBack(ik_joint);

		ik_joint = ptr_new IkJoint;
		ik_joint->joint_index = skeleton->GetJointId("knee_r");
		ik_leg_joints[1].PushBack(ik_joint);

		ik_joint = ptr_new IkJoint;
		ik_joint->joint_index = skeleton->GetJointId("ankle_r");
		ik_leg_joints[1].PushBack(ik_joint);

		ik_leg_offset[0] = 0;
		ik_leg_offset[1] = 0;
	}


	/// release physx object
	void ThirdPerson::ReleasePhysxObject()
	{
		for (uint i = 0; i < physx_actor_set.Size(); ++i)
		{
			if (physx_actor_set[i].actor)
			{
				PhysxSystem::ReleaseActor(*physx_actor_set[i].actor);
				physx_actor_set[i].actor = NULL;
			}
		}
		physx_actor_set.Clear();

		for (uint i = 0; i < physx_joint_set.Size(); ++i)
		{
			if (physx_joint_set[i])
				PhysxSystem::ReleaseJoint(*physx_joint_set[i]);
		}
		physx_joint_set.Clear();

		ik_l_joints.Clear();
		ik_r_joints.Clear();
		ik_leg_joints[0].Clear();
		ik_leg_joints[1].Clear();
	}

	/// update physx
	void ThirdPerson::UpdatePhysx(float frame_time)
	{
		if (!skeleton)
			return;

		if (!pose)
			return;

		if (character)
		{
			Quaternion rotation = character->GetRotation();
			Vector3 position = character->GetPosition();
			for (uint i = 0; i < physx_actor_set.Size(); ++i)
			{
				if (physx_actor_set[i].actor->readBodyFlag(NX_BF_KINEMATIC))
				{
					const Transform & transform = pose->GetJointModelPose(physx_actor_set[i].joint_id);
					Quaternion rot = transform.rotation * GetSkeletonRotation();
					Vector3 pos = position + transform.position * GetSkeletonRotation();

					physx_actor_set[i].actor->moveGlobalPosition((const NxVec3&)pos);
					physx_actor_set[i].actor->moveGlobalOrientationQuat((const NxQuat&)rot);
				}
			}

			for ( uint i = 0; i < skeleton->GetJointCount(); ++i )
			{
				if (array_physix_id[i] >= 0)
				{
					Actor & actor = physx_actor_set[array_physix_id[i]];

					if (pose->GetJointLockPose(i))
					{
						Vector3 world_pos = (const Vector3 &)actor.actor->getGlobalPosition();
						Quaternion world_rot = (const Quaternion &)actor.actor->getGlobalOrientationQuat();

						Vector3 pos;
						Quaternion rot = rotation;
						rot.Inverse();
						rot = world_rot * rot;

						Matrix44 parent_mat(position, 1, rotation);
						parent_mat.Inverse();
						TransformCoord(pos, world_pos, parent_mat);

						Matrix44 matrix(pos, 1, rot);
						matrix = matrix * Matrix44(Quaternion(Vector3(0, 1, 0), PI));
						pos.x = matrix.m[3][0];
						pos.y = matrix.m[3][1];
						pos.z = matrix.m[3][2];
						rot = matrix;
						rot.Normalize();

						pose->SetJointModelPosePosition(i, pos);
						pose->SetJointModelPoseRotation(i, rot);
					}
				}
			}

			// update force
			if (frame_time > 0.0f)
			{
				Quaternion die_rotation = rotation * Quaternion(Vector3(0, 1, 0), PI);
				for (uint i = 0; i < physx_force_set.Size(); i++)
				{
					PhysxForce & force = physx_force_set[i];
					if (force.time >= 0)
					{
						if (force.actor_id >= 0 && force.actor_id < physx_actor_set.Size())
						{
							const Actor & actor = physx_actor_set[force.actor_id];

							if (actor.actor && !actor.actor->readBodyFlag(NX_BF_KINEMATIC))
							{
								switch (force.space_mode)
								{
								case kForceSpaceLocal:
									actor.actor->addLocalForceAtLocalPos((const NxVec3 &)force.force, (const NxVec3 &)force.position, force.force_mode);
									break;

								case kForceSpaceModel:
									actor.actor->addForceAtLocalPos((const NxVec3 &)(force.force * die_rotation), (const NxVec3 &)force.position, force.force_mode);
									break;

								case kForceSpaceWorld:
									actor.actor->addForceAtLocalPos((const NxVec3 &)force.force, (const NxVec3 &)force.position, force.force_mode);
									break;
								}
							}

						}

						force.time -= frame_time;
					}
				}
			}
		}
		pose->UpdateModelPose();
	}

	const AxisAlignedBox& ThirdPerson::GetWorldAABB() const
	{
		return world_aabb;
	}

	void ThirdPerson::LoadSkeleton()
	{
		// load skeleton
		skeleton = RESOURCE_LOAD(character_info->third_person_skeleton, false, Skeleton);

		if (skeleton)
		{
			joint_hip_id = skeleton->GetJointId("hip");
			array_physix_id.Clear();
			array_physix_id.Resize(skeleton->GetJointCount(), -1);

			camera_joint_id = skeleton->GetJointId("cam");
			handweapon_l_id = skeleton->GetJointId("handweapon_l");
			handweapon_r_id = skeleton->GetJointId("handweapon_r");
			wrist_ik_l_id = skeleton->GetJointId("wristIK_l");
			wrist_ik_r_id = skeleton->GetJointId("wristIK_r");
			wrist_l_id = skeleton->GetJointId("wrist_l");
			wrist_r_id = skeleton->GetJointId("wrist_r");
			back_id = skeleton->GetJointId("back_b");
		}
	}
	
	void ThirdPerson::PlayEffectBuffer( int attributetype , float frame_time )
	{
		if(character->GetViewMode() == Character::kFirstPerson)
			return ;
		Core::String name;
		switch(attributetype)
		{
			case kWeaponAttr_Target_SlowDown:
			{	
				name = "buff_slowdown";
			}
			break;
			default:
			break;
		}


		if(attributetype != effectbuffertype || effectbuffertimer <= 0.f)
		{
			if(effectbuffer)
				effectbuffer->SetEnable(false);
			
			effectbuffer = ptr_new ParticleSystem(name);
			effectbuffertype = attributetype;
		}

	
		const Transform & transform = pose->GetJointModelPose(back_id);

		Vector3 position = character->GetPosition() + transform.position * character->GetSkeletonRotation();// 
		effectbuffer->SetPosition(position);

		effectbuffer->SetRotation(character->GetSkeletonRotation());
		//effectbuffer->ResetEmittersParticles();
		effectbuffer->Reset();
		gLevel->AddParticle(effectbuffer);
		effectbuffertimer = frame_time;
		//
	}

	void ThirdPerson::PlayFootBuffer( int attributetype , float frame_time )
	{
		Core::String name;
		switch(attributetype)
		{
		case kWeaponAttr_Benefit_DamageAdd:
			{	
				name = "buff_maxcrit";
			}
			break;
		default:
			break;
		}


		if(attributetype != footbuffertype)
		{
			if(footbuffer)
				footbuffer->SetEnable(false);

			footbuffer = ptr_new ParticleSystem(name);
			footbuffertype = attributetype;
		}

		footbuffertimer = frame_time;
		footbuffer->SetEnable(false);
	}

	void ThirdPerson::CreateFootParticle()
	{
		if(character)
		{	
			Core::String str = Core::String::Format("bigbrother_%s", character->GetTeam() == 0 ? "r" : "b");
			foot_particle = ptr_new ParticleSystem(str.Str(), true);
			foot_particle->SetEnable(true);
		}
	}

	void ThirdPerson::CreateGunParticle()
	{
		if (character)
		{
			tempc_ptr(WeaponBase) third_weapon = ptr_dynamic_cast<WeaponBase>(character->GetThirdPresonWeapon());
			if (third_weapon && third_weapon->weapon_info->effectName.Length() > 0)
			{
				gun_particle = ptr_new ParticleSystem(third_weapon->weapon_info->effectName);
				gun_particle->SetEnable(true);
			}
		}
	}

	void ThirdPerson::CreateFootParticle(const Core::Identifier & name)
	{
		if(character)
		{
			if (gLevel->game_type == RoomOption::kCommonZombieMode)
			{
				foot_particle = ptr_new ParticleSystem(name.Str(), true);
				foot_particle->SetEnable(true);
			}
		}
	}

	void ThirdPerson::CreateInvisibleParticle()
	{
		if(character)
		{	
			Core::String str = "cell03_disappear";
			invisiblebuffer = ptr_new ParticleSystem(str.Str(), true);
			invisiblebuffer->SetEnable(true);
		}
	}

	void ThirdPerson::CreateHumanParticle()
	{
		if(character)
		{	
			Core::String str = "human";
			human_particle = ptr_new ParticleSystem(str.Str(), true);
			human_particle->SetEnable(true);
		}
	}

	void ThirdPerson::CreateZombieParticle()
	{
		if(character)
		{	
			ClearZombieParticle();
			Core::String str = Core::String::Format("zombie_hand0%d", character->common_zombie_level);
			zombie_particle1 = ptr_new ParticleSystem(str.Str(), true);
			zombie_particle1->SetEnable(true);
			zombie_particle2 = ptr_new ParticleSystem(str.Str(), true);
			zombie_particle2->SetEnable(true);
		}
	}

	void ThirdPerson::CreateBoddyParticle(const Core::Identifier & name)
	{
		if(character)
		{
			if (gLevel->game_type == RoomOption::kCommonZombieMode)
			{
				foot_particle = ptr_new ParticleSystem(name.Str(), true);
				foot_particle->SetEnable(true);
			}
		}
	}

	void ThirdPerson::CreateEffectParticle()
	{
		if (!qualm_particle)
		{
			qualm_particle = ptr_new ParticleSystem("buff_giddy", true);
			qualm_particle->SetEnable(true);
			qualm_particle->Reset();
		}

		if (!reverse_particle)
		{
			reverse_particle = ptr_new ParticleSystem("buff_reverse", true);
			reverse_particle->SetEnable(true);
			reverse_particle->Reset();
		}

		
		if (!slow_particle)
		{
			slow_particle = ptr_new ParticleSystem("buff_slowdown", true);
			slow_particle->SetEnable(true);
			slow_particle->Reset();
		}
		
		if (!fast_particle[0])
		{
			fast_particle[0] = ptr_new ParticleSystem("buff_gatherway", true);
			fast_particle[0]->SetEnable(true);
			fast_particle[0]->Reset();
		}

		if (!fast_particle[1])
		{
			fast_particle[1] = ptr_new ParticleSystem("buff_gatherway01", true);
			fast_particle[1]->SetEnable(true);
			fast_particle[1]->Reset();
		}
			
	}

	void ThirdPerson::ClearFootParticle()
	{
		foot_particle = NullPtr;
	}

	void ThirdPerson::ClearGunParticle()
	{
		gun_particle = NullPtr;
	}

	void ThirdPerson::ClearBoddyParticle()
	{
		boddy_particle = NullPtr;
	}

	void ThirdPerson::ClearHumanParticle()
	{
		human_particle = NullPtr;
	}

	void ThirdPerson::ClearInvisibleParticle()
	{
		invisiblebuffer = NullPtr;
	}

	void ThirdPerson::ClearZombieParticle()
	{
		zombie_particle1 = NullPtr;
		zombie_particle2 = NullPtr;
	}

	void ThirdPerson::ClearEffectParticle()
	{
		reverse_particle = NullPtr;	
		qualm_particle = NullPtr;
		slow_particle = NullPtr;
		fast_particle[0] = NullPtr;
		fast_particle[1] = NullPtr;
	}

	void ThirdPerson::UpdateFootParticle(float frame_time)
	{
		if(foot_particle)
		{
			if(character)
			{
				foot_particle->SetPosition(character->GetSkeletonPosition() + Vector3(0, 0.05f, 0));
				foot_particle->SetRotation(character->GetSkeletonRotation());
			}
			foot_particle->Update(frame_time);
		}
	}

	void ThirdPerson::UpdateGunParticle(float frame_time)
	{
		if(gun_particle)
		{
			if(character)
			{
				Core::Vector3 position;
				Core::Quaternion qutation;
				tempc_ptr(WeaponBase) third_weapon = ptr_dynamic_cast<WeaponBase>(character->GetThirdPresonWeapon());
				if(third_weapon && GetJointInfo(third_weapon->weapon_info->effectSlot,position,qutation))
				{
					gun_particle->SetPosition(position+third_weapon->weapon_info->effectOffset*character->GetSkeletonRotation() );
					gun_particle->SetRotation(qutation);
				}
			}
			gun_particle->Update(frame_time);
		}
	}

	void ThirdPerson::UpdateHumanParticle(float frame_time)
	{
		if(human_particle)
		{
			if(character)
			{
				human_particle->SetPosition(character->GetPosition());
				human_particle->SetRotation(character->GetRotation());
			}
			human_particle->Update(frame_time);
		}
	}

	void ThirdPerson::UpdateInvisibleParticle(float frame_time)
	{
		if(invisiblebuffer)
		{
			if(character)
			{
				invisiblebuffer->SetPosition(character->GetPosition());
				invisiblebuffer->SetRotation(character->GetRotation());
			}
			invisiblebuffer->Update(frame_time);
		}
	}

	void ThirdPerson::UpdateBoddyParticle(float frame_time)
	{
		if(boddy_particle)
		{
			if(character)
			{
				Core::Vector3 position;
				Core::Quaternion qutation;
				if(GetJointInfo("torso",position,qutation))
				{
					boddy_particle->SetPosition(position);
					boddy_particle->SetRotation(qutation);
				}
			}
			boddy_particle->Update(frame_time);
		}
	}

	void ThirdPerson::UpdateZombieParticle(float frame_time)
	{
		if(zombie_particle1)
		{
			if(character)
			{
				Core::Vector3 position;
				Core::Quaternion qutation;
				if(GetJointInfo("wristIK_l",position,qutation))
				{
					zombie_particle1->SetPosition(position);
					zombie_particle1->SetRotation(qutation);
				}
			}
			zombie_particle1->Update(frame_time);
		}
		if(zombie_particle2)
		{
			if(character)
			{
				Core::Vector3 position;
				Core::Quaternion qutation;
				if(GetJointInfo("wristIK_r",position,qutation))
				{
					zombie_particle2->SetPosition(position);
					zombie_particle2->SetRotation(qutation);
				}
			}
			zombie_particle2->Update(frame_time);
		}
	}

	void ThirdPerson::UpdateEffectParticle(float frame_time)
	{
		if(character)
		{
			if (qualm_particle)
			{
				Core::Vector3 position;
				Core::Quaternion qutation;
				if(GetJointInfo("head",position,qutation))
				{
					qualm_particle->SetPosition(position);
					qualm_particle->SetRotation(qutation);
				}
				qualm_particle->Update(frame_time);
			}

			if (reverse_particle)
			{
				Core::Vector3 position;
				Core::Quaternion qutation;
				if(GetJointInfo("head",position,qutation))
				{
					reverse_particle->SetPosition(position);
					reverse_particle->SetRotation(qutation);
				}
				reverse_particle->Update(frame_time);
			}

			if(slow_particle)
			{
				Core::Vector3 position;
				Core::Quaternion qutation;
				if(GetJointInfo("chest",position,qutation))
				{
					slow_particle->SetPosition(position);
					slow_particle->SetRotation(qutation);
				}
				slow_particle->Update(frame_time);
			}

			if (fast_particle[0])
			{
				Core::Vector3 position;
				Core::Quaternion qutation;
				if(GetJointInfo("root",position,qutation))
				{
					fast_particle[0]->SetPosition(position);
					fast_particle[0]->SetRotation(qutation);
				}
				fast_particle[0]->Update(frame_time);
			}
			if (fast_particle[1])
			{
				Core::Vector3 position;
				Core::Quaternion qutation;
				if(GetJointInfo("back_b",position,qutation))
				{
					fast_particle[1]->SetPosition(position);
					fast_particle[1]->SetRotation(qutation);
				}
				fast_particle[1]->Update(frame_time);
			}
			if (!slow_particle || !qualm_particle || !fast_particle[0] || !fast_particle[1] || !reverse_particle)
			{
				CreateEffectParticle();
			}
		}
	}

#if DEBUG_TOOLS
	void ThirdPerson::UpdateModelViewer(float frame_time)
	{
		if (!character)
			return;

		UpdateAnimation(frame_time);

		// update weapon animation
		tempc_ptr(WeaponBase) weapon = GetWeapon(character->weapon_id);
		if (weapon)
			weapon->UpdateAnimation(frame_time);

		if (character->occluded == false && character->GetViewMode() == Character::kThirdPerson)
		{
			UpdateTransform(frame_time);
		}

		if (character->IsDied() && character->ready && !character->GetPhysxControl())
		{
			if (!animation_system || !animation_system->IsActionPlaying())
				character->SetPhysxControl(true);
		}

		UpdatePhysx(frame_time);

		UpdateAudio(frame_time);

		if (animation_system)
			animation_system->OnValid(character->GetViewMode() == Character::kThirdPerson);

		if (character->occluded == false && character->GetViewMode() == Character::kThirdPerson)
		{ 
			UpdateAnimationJoint(frame_time);

			tempc_ptr(WeaponBase) weapon = GetWeapon(character->weapon_id);

			if (weapon)
			{
				UpdateWeapon(frame_time);
				weapon->UpdateMesh();

				tempc_ptr(GunBase) gun = ptr_dynamic_cast<GunBase>(weapon);

				// for particle
				if (gun)
					gun->UpdateEffect(frame_time);
			}
			if(character->equipment_id >= 0)
			{
				tempc_ptr(WeaponBase) equip = GetWeapon(character->equipment_id);
				if(equip)
				{
					UpdateEquipment(frame_time);
					equip->UpdateMesh();

				}

			}
			
			// update mesh
			if (draw_mesh)
			{
				draw_mesh->pose = pose;
				draw_mesh->Update();
			}
		}

		// update bounding box
		UpdateBoundingBox();

	}

	void ThirdPerson::UpdateAnimationThirdPersonForViewer(float frame_time)
	{
		if (!character)
			return;

		UpdateModelViewer(frame_time);

		UpdateAnimationThirdPerson(frame_time);

		UpdateAnimationJoint(frame_time);

		UpdateTransform(frame_time);

		UpdateWeapon(frame_time);

		UpdateEquipment(frame_time);
		if (mesh)
			mesh->Update(); 
	}


#endif
}
