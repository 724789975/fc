namespace Client
{
	class Character;
	class ActionController : public Core::Object
	{
	public:
		/// constructor
		ActionController();

		/// update
		virtual void Update(float frame_time);

	public:
		/// die
		virtual void Die(const HitInfo & info);

		/// rebirth
		virtual void Rebirth();

		/// grenade throw in
		virtual bool GrenadeThrowIn();

		/// grenade ready
		virtual void GrenadeReady();

		/// grenade throw request
		virtual void GrenadeThrowRequest(byte type);

		/// grenade throw out
		virtual bool GrenadeThrowOut(by_ptr(ThrowableInfo) info, const Core::Vector3 & position, const Core::Vector3 & direction);

		/// stop throw grenade
		virtual bool GrenadeThrowStop();

		/// knife stab
		virtual bool Stab(byte type);

		/// stop stab
		virtual bool StopStab();

		/// shoot
		virtual bool Shoot(const Core::Vector3 & dir,bool isboost = false);

		// fix shoot position bug
		virtual bool Shoot(const Core::Vector3 & position, const Core::Vector3 & dir,bool isboost = false);

		/// stop shooting
		virtual bool StopShoot();

		/// reload
		virtual bool Reload();

		virtual bool PlantBomb();

		/// reload ready
		virtual void ReloadReady(int count);

		/// select weapon
		virtual bool SelectWeapon(uint id,bool force = false);

		/// set weapon
		virtual bool SetWeapon(int slot, by_ptr(WeaponInfo) info);

		// drop weapon
		virtual bool DropWeapon(int slot);

		// pick up weapon
		virtual void PickUpWeapon(int slot, by_ptr(WeaponInfo) info);

		/// set character
		virtual void SetCharacter(by_ptr(Character) c);

		/// set camera fov
		virtual void SetCameraFov(float fov, float target_fov);

		/// use skill request
		virtual void UseSkillRequest(tempc_ptr(PlayerSkill) skill);

		/// use skill
		virtual void UseSkill(tempc_ptr(PlayerSkill) skill);

		/// fall down
		virtual void FallDown(float speed, bool is_onground);

		/// on hit character
		virtual void OnHitCharacter(tempc_ptr(Character) hit_character);
		
	protected:
		tempc_ptr(Character) character;
	};

	class PlayerAction : public ActionController
	{
	public:
		/// constructor
		PlayerAction();

		/// update
		virtual void Update(float frame_time);

		/// update weapon
		void UpdateWeapon(float frame_time);

	public:
		/// die
		virtual void Die(const HitInfo & info);

		/// rebirth
		virtual void Rebirth();

		/// grenade throw in
		virtual bool GrenadeThrowIn();

		/// grenade ready
		virtual void GrenadeReady();

		/// grenade throw request
		virtual void GrenadeThrowRequest(byte type);

		/// stop throw grenade
		virtual bool GrenadeThrowStop();

		/// knife stab
		virtual bool Stab(byte type);

		/// stop stab
		virtual bool StopStab();

		/// shoot
		virtual bool Shoot(const Core::Vector3 & dir,bool isboost = false);

		/// stop shooting
		virtual bool StopShoot();

		virtual bool PlantBomb();

		/// reload
		virtual bool Reload();

		/// reload ready
		virtual void ReloadReady(int count);

		/// select weapon
		virtual bool SelectWeapon(uint id,bool force = false);

		/// set weapon
		virtual bool SetWeapon(int slot, by_ptr(WeaponInfo) info);

		// drop weapon
		virtual bool DropWeapon(int slot);

		// pick up weapon
		virtual void PickUpWeapon(int slot, by_ptr(WeaponInfo) info);

		/// set camera fov
		virtual void SetCameraFov(float fov, float target_fov);

		/// use skill request
		virtual void UseSkillRequest(tempc_ptr(PlayerSkill) skill);

		/// use skill
		virtual void UseSkill(tempc_ptr(PlayerSkill) skill);

		/// fall down
		virtual void FallDown(float speed, bool is_onground);

	public:
		float	change_in_time;
	private:
		
		bool	selecting_weapon	: 1;

		bool	first_action_on		: 1;
		bool	second_action_on	: 1;
	};
}