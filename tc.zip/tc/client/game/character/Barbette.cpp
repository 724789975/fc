#include "pch.h"

using namespace Core;

DEFINE_PDE_TYPE_CLASS(Client::IBarbette)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_METHOD(CanFire);
		ADD_PDE_METHOD(IsInRange);

		ADD_PDE_METHOD(Fire);
		ADD_PDE_METHOD(FirePosition);
		ADD_PDE_METHOD(FireCharacter);
		ADD_PDE_METHOD(FireToPosition);
		ADD_PDE_METHOD(FireToCharacter);

		ADD_PDE_METHOD(GetPosition);
		ADD_PDE_METHOD(GetRotation);

		ADD_PDE_METHOD(Reset);
		ADD_PDE_METHOD(SetRotationByTimer);
		ADD_PDE_METHOD(SetOffsetByTimer);
		ADD_PDE_METHOD(SetDefaultRotation);
		ADD_PDE_METHOD(SetDefaultOffset);
		ADD_PDE_METHOD(SetRotationByCharacter);
		ADD_PDE_METHOD(SetOffsetByCharacter);
		ADD_PDE_METHOD(SetOffsetAndRotationByCharacter);
	}
};

DEFINE_PDE_TYPE_CLASS(Client::Barbette)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Client::IBarbette);
	}
};

REGISTER_PDE_TYPE(Client::IBarbette);
REGISTER_PDE_TYPE(Client::Barbette);

namespace Client
{
	/// constructor
	Barbette::Barbette()
		: actor(NULL)
		, target_timer(0)
		, target_move_timer(0)
		, rot_timer(0)
		, move_timer(0)
		, can_freemove(false)
		, is_camera_updated(false)
		, lock_character_id(0)
		, lock_character_type(-1)
	{
		position = Vector3::kZero;
		rotation = Quaternion::kIdentity;
		
		default_offset = Vector3::kZero;
		final_offset = Vector3::kZero;
		record_offset = Vector3::kZero;

		rot_angle = Quaternion::kIdentity;
		record_rot = Quaternion::kIdentity;
		default_rot = Quaternion::kIdentity;
	}

	/// destructor
	Barbette::~Barbette()
	{
		if (actor)
		{
			PhysxSystem::ReleaseActor(*actor);
			actor = NULL;
		}

		if (gLevel && fire_particle)
			gLevel->RemoveParticle(fire_particle);
	}

	/// initialize
	bool Barbette::Initialize(by_ptr(Character) c, by_ptr(BarbetteInfo) info)
	{
		if (!c || !info || !info->weapon_info)
			return false;

		bool hasActor = false;
		bool hasWeapon = false;

		mesh = ptr_new SkinMesh(MESH_KEY_SCENEPROP);
		if (mesh)
		{
			for (U32 i = 0; i < MESH_LOD_LEVEL; i++)
			{
				if (mesh->AddPrimitive(info->mesh[i], info->mesh[i], i))
				{
				}
			}

			skeleton = RESOURCE_LOAD(info->skeleton, false, Skeleton);
			if (skeleton)
			{
				mesh->pose = ptr_new Pose(skeleton);
			}
		}

		if (info->fire_particle.Length() > 0)
			fire_particle = ptr_new ParticleSystem(info->fire_particle);

		HashSet<Core::Identifier, Core::Identifier>::Enumerator itr(info->particles);
		while (itr.MoveNext())
		{
			sharedc_ptr(ParticleSystem) particle = ptr_new ParticleSystem(itr.Value());

			particle->SetEnable(true);
			particles.Set(itr.Key(), particle);
		}

		actor = PhysxSystem::CreateBox(Vector3::kZero, info->size * 0.5f, PhysxSystem::kGroupStart + c->GetTeam()/*physx_group*/);
		if (actor)
		{
			actor->userData = c;
			//actor->userData = this;

			SetPhysxControl(false);

			hasActor = true;
		}

		weapon = CreatePVEWeapon(info->weapon_info->weapon_type);
		if (weapon && weapon->Initialize(info->name, c, info->weapon_info))
		{
			hasWeapon = true;
		}

		character = c;
		barbette_info = info;
		rot_angle = default_rot = barbette_info->base_rotation;
		
		default_offset = barbette_info->base_offset;

		camera.SetNear(info->firerange_min);
		camera.SetFar(info->firerange_max);
		camera.fov = camera.target_fov = info->fire_fov;
		camera.aspect = info->fire_aspect;

		Update(0);

		return hasActor && hasWeapon;
	}

	/// is ready
	bool Barbette::IsReady()
	{
		if (mesh)
			return mesh->IsReady();

		return true;
	}

	/// update
	void Barbette::Update(float frame_time)
	{
		PROFILE("Barbette::Update");

		if (GetPhysxControl())
		{
			SetPosition((const Vector3 &)actor->getGlobalPosition());
			SetRotation((const Quaternion &)actor->getGlobalOrientationQuat());
		}
		else if (!can_freemove)
		{
			Vector3 pos_center = character->GetPosition();

			if (lock_character_id > 0)
			{
				tempc_ptr(Character) lc = gLevel->GetCharacter(lock_character_id);
				//����������ת�����ٶ�
				if (lock_character_type == 1 && lc)
				{
					Vector3 pos_locked = lc->GetPosition();
					pos_locked.y += lc->GetHeight() * 1.0f;

					Vector3 rot_new = pos_locked - GetPosition();
					Vector3 rot_now = Vector3(0, 0, -1) * GetRotation();

					Vector3 rot_axis;
					float rot_angle;

					Quaternion rot_try(rot_now, rot_new);
					rot_try.ToAxisAngle(rot_axis, rot_angle);
					float anglelimit_rad = barbette_info->anglelimit * frame_time * DEG2RAD;
					if (Abs(rot_angle) > anglelimit_rad)
					{
						if (rot_angle >= 0.f)
							rot_angle = anglelimit_rad;
						else
							rot_angle = -anglelimit_rad;

						rot_try.SetAxisAngle(rot_axis, rot_angle);
					}
					SetRotation(GetRotation() * rot_try);
				}
				//�������������ٶ��ƶ���������ת
				else if (lock_character_type == 2 && lc)
				{
					tempc_ptr(Character) lc = gLevel->GetCharacter(lock_character_id);
					if (lc)
					{
						float temp_y = GetPosition().y;
						Vector3 pos_locked = lc->GetPosition();
						Vector3 pos_boss = GetPosition();
						pos_locked.y = temp_y;
						Vector3 mm = pos_locked - pos_boss;
						mm.Normalize();
						mm *= frame_time*barbette_info->speedlimit;
						SetPosition(pos_boss+mm);
					}

					if (target_timer != 0 && rot_timer < target_timer)
					{
						rot_timer += frame_time;
						Quaternion final;
						Lerp(final,record_rot,rot_angle,Clamp(rot_timer/target_timer, 0, 1));
						final.Normalize();
						barbette_info->base_rotation = final;
					}
					Quaternion rot = barbette_info->base_rotation * character->GetRotation() * Quaternion(Vector3(0,1,0),PI);
					SetRotation(rot);
				}
				//�������������ٶ��ƶ������ٶ���ת
				else if (lock_character_type == 3 && lc)
				{
					Vector3 pos_locked = lc->GetPosition();
					pos_locked.y += lc->GetHeight() * 1.0f;

					Vector3 rot_new = pos_locked - GetPosition();
					Vector3 rot_now = Vector3(0, 0, -1) * GetRotation();

					Vector3 rot_axis;
					float rot_angle;

					Quaternion rot_try(rot_now, rot_new);
					rot_try.ToAxisAngle(rot_axis, rot_angle);
					float anglelimit_rad = barbette_info->anglelimit * frame_time * DEG2RAD;
					if (Abs(rot_angle) > anglelimit_rad)
					{
						if (rot_angle >= 0.f)
							rot_angle = anglelimit_rad;
						else
							rot_angle = -anglelimit_rad;

						rot_try.SetAxisAngle(rot_axis, rot_angle);
					}
					SetRotation(GetRotation() * rot_try);
					tempc_ptr(Character) lc = gLevel->GetCharacter(lock_character_id);
					if (lc)
					{
						float temp_y = GetPosition().y;
						Vector3 pos_locked = lc->GetPosition();
						Vector3 pos_boss = GetPosition();
						pos_locked.y = temp_y;
						Vector3 mm = pos_locked - pos_boss;
						mm.Normalize();
						mm *= frame_time*barbette_info->speedlimit;
						SetPosition(pos_boss+mm);
					}
				}
			}
			else
			{
				if (target_timer != 0 && rot_timer < target_timer)
				{
					rot_timer += frame_time;
					Quaternion final;
					Lerp(final,record_rot,rot_angle,Clamp(rot_timer/target_timer, 0, 1));
					final.Normalize();
					barbette_info->base_rotation = final;
				}

				if (target_move_timer != 0 && move_timer <target_move_timer)
				{
					move_timer += frame_time;
					Vector3 pos;
					Lerp(pos,record_offset,final_offset,move_timer/target_move_timer);
					barbette_info->base_offset = pos;
				}
				Quaternion rot = barbette_info->base_rotation * character->GetRotation() * Quaternion(Vector3(0,1,0),PI);
				SetPosition(pos_center + barbette_info->base_offset * character->GetRotation() * Quaternion(Vector3(0,1,0),PI));
				SetRotation(rot);
			}
		}

		if (mesh)
		{
			mesh->SetPosition(GetPosition());
			mesh->SetRotation(GetRotation());

			mesh->Update();
		}

		if (weapon)
		{
			weapon->Update(frame_time);
		}

		if (fire_particle)
		{
			fire_particle->SetPosition(GetPosition());
			fire_particle->SetRotation(GetRotation());
			//fire_particle->Update(frame_time);
		}

		HashSet<Core::Identifier, sharedc_ptr(ParticleSystem)>::Enumerator itr(particles);
		while (itr.MoveNext())
		{
			tempc_ptr(ParticleSystem) particle = itr.Value();
			if (particle)
			{
				particle->SetPosition(GetPosition());
				particle->SetRotation(GetRotation());

				particle->Update(frame_time);
			}
		}

		is_camera_updated = false;

#if DEBUG_PHYSX
		camera.last_position = camera.position;
		camera.position = GetPosition();
		camera.rotation = GetRotation();
		camera.ManualUpdate(barbette_info->fire_fov, 0);
		is_camera_updated = true;
#endif
	}

	/// update
	void Barbette::TimeStepUpdate(float frame_time)
	{
		if (weapon)
		{
			weapon->TimeStepUpdate(frame_time);
		}
	}

	/// draw
	void Barbette::Draw(Primitive::DrawType drawtype, bool immediate)
	{
		if (mesh)
			mesh->Draw(drawtype, immediate);

		if (immediate)
		{
			HashSet<Core::Identifier, sharedc_ptr(ParticleSystem)>::Enumerator itr(particles);
			while (itr.MoveNext())
			{
				tempc_ptr(ParticleSystem) particle = itr.Value();
				if (particle)
					particle->Draw();
			}
		}

		if (weapon)
			weapon->Draw(drawtype, immediate);
	}

	/// canfire
	bool Barbette::CanFire()
	{
		if (!weapon)
			return false;

		return weapon->CanFire();
	}

	/// canfire
	bool Barbette::IsInRange(const Core::Vector3 &target)
	{
		if (!is_camera_updated)
		{
			camera.last_position = camera.position;
			camera.position = GetPosition();
			camera.rotation = GetRotation();
			camera.ManualUpdate(barbette_info->fire_fov, 0);

			is_camera_updated = true;
		}

		Vector3 pos_vp = target * camera.viewprojMatrix;

		for (U32 i = FRUSTUM_PLANE_NEAR; i < FRUSTUM_COUNT; i++)
		{
			if (camera.frustum.GetFrustumPlane((FrustumPlane)i).GetDistFromPoint(pos_vp) < 0)
			{
				return false;
			}
		}

		return true;
	}

	/// fire
	void Barbette::Fire(const Core::Quaternion &target)
	{
		Vector3 pos = GetPosition();

		Quaternion rot = GetRotation() * target;

		weapon->FireStart();

		for (U32 i = 0; i < barbette_info->cannons.Size(); i++)
		{
			weapon->Fire(pos + barbette_info->cannons[i]->offset * GetRotation(), 
						barbette_info->cannons[i]->rotation * rot, (int)i);
		}

		weapon->FireDone();

		if (fire_particle)
			gLevel->AddParticle(fire_particle);
	}

	/// fire
	void Barbette::FirePosition(const Core::Vector3 &target)
	{
		Vector3 pos = GetPosition();

		Quaternion rot(Vector3(0, 0, -1), target - pos);

		weapon->FireStart();

		for (U32 i = 0; i < barbette_info->cannons.Size(); i++)
		{
			weapon->Fire(pos + barbette_info->cannons[i]->offset * GetRotation(), 
						barbette_info->cannons[i]->rotation * rot);
		}

		weapon->FireDone();

		if (fire_particle)
			gLevel->AddParticle(fire_particle);
	}

	/// fire
	void Barbette::FireCharacter(by_ptr(Character) target)
	{
		if (target)
		{
			Vector3 target_pos = target->GetPosition();
			target_pos.y += target->GetHeight() * 1.0f;

			Vector3 pos = GetPosition();
			Quaternion rot(Vector3(0, 0, -1), target_pos - pos);

			weapon->FireStart();

			for (U32 i = 0; i < barbette_info->cannons.Size(); i++)
			{
				weapon->Fire(pos + barbette_info->cannons[i]->offset * GetRotation(), 
							barbette_info->cannons[i]->rotation * rot, target);
			}
		
			weapon->FireDone();

			if (fire_particle)
				gLevel->AddParticle(fire_particle);
		}
	}

	/// fire
	void Barbette::FireToPosition(const Core::Vector3 &target)
	{
		Vector3 pos = GetPosition();

		weapon->FireStart();

		for (U32 i = 0; i < barbette_info->cannons.Size(); i++)
		{
			weapon->Fire(pos + barbette_info->cannons[i]->offset * GetRotation(), 
						target);
		}

		weapon->FireDone();

		if (fire_particle)
			gLevel->AddParticle(fire_particle);
	}

	/// fire
	void Barbette::FireToCharacter(by_ptr(Character) target)
	{
		if (target)
		{
			Vector3 pos = GetPosition();

			weapon->FireStart();

			for (U32 i = 0; i < barbette_info->cannons.Size(); i++)
			{
				weapon->Fire(pos + barbette_info->cannons[i]->offset * GetRotation(), 
							target);
			}

			weapon->FireDone();

			if (fire_particle)
				gLevel->AddParticle(fire_particle);
		}
	}

	void Barbette::Reset()
	{
		lock_character_id = 0;
		lock_character_type = 0;
		if (weapon)
			weapon->Reset();
	}

	/// get position
	const Vector3 & Barbette::GetPosition()
	{
		if (actor)
			position = (const Vector3 &)actor->getGlobalPosition();

		return position;
	}

	/// set position
	void Barbette::SetPosition(const Vector3 &pos)
	{
		if (actor)
			actor->setGlobalPosition((const NxVec3 &)pos);

		position = pos;
	}

	/// move position
	void Barbette::MovePosition(const Vector3 &pos)
	{
		if (actor)
			actor->moveGlobalPosition((const NxVec3 &)pos);

		position = pos;
	}

	/// get rotation
	const Quaternion & Barbette::GetRotation()
	{
		if (actor)
			rotation = (const Quaternion &)actor->getGlobalOrientationQuat();

		return rotation;
	}


	const Vector3 Barbette::GetRotationAngle()
	{
		if (actor)
			rotation = (const Quaternion &)actor->getGlobalOrientationQuat();
		Vector3 q = rotation.GetZXY();

		return q;
	}

	/// set rotation
	void Barbette::SetRotation(const Quaternion &rot)
	{
		if (actor)
			actor->setGlobalOrientationQuat((const NxQuat &)rot);

		rotation = rot;
	}

	void Barbette::SetRotationAngle(const Core::Vector3 &rot)
	{
		Quaternion q;
		q.SetZXY(rot);
		if (actor)
			actor->setGlobalOrientationQuat((const NxQuat &)q);

		rotation = q;
	}

	/// move rotation
	void Barbette::MoveRotation(const Quaternion &rot)
	{
		if (actor)
			actor->moveGlobalOrientationQuat((const NxQuat &)rot);

		rotation = rot;
	}

	/// set physx control
	void Barbette::SetPhysxControl(bool flag)
	{
		if (actor)
		{
			if (flag)
			{
				actor->clearBodyFlag(NX_BF_KINEMATIC);
				actor->clearBodyFlag(NX_BF_DISABLE_GRAVITY);
			}
			else
			{
				actor->raiseBodyFlag(NX_BF_KINEMATIC);
				actor->raiseBodyFlag(NX_BF_DISABLE_GRAVITY);
			}
		}
	}

	/// get physx control
	bool Barbette::GetPhysxControl()
	{
		if (actor)
		{
			return actor->readBodyFlag(NX_BF_KINEMATIC) == false;
		}

		return false;
	}

	/// get camera
	Camera& Barbette::GetCamera()
	{
		return camera;
	}

	bool Barbette::SetRotationByTimer(const Core::Quaternion rot, float timer)
	{
		Quaternion q = rot;
		if (rot_angle != q && barbette_info)
		{
			rot_timer = 0;
			barbette_info->base_rotation = record_rot = rot_angle;
			rot_angle = q;
			target_timer = timer;
			return true;
		}
		return false;
	}

	bool Barbette::SetDefaultRotation(float timer)
	{
		if (barbette_info)
		{
			rot_timer = 0;
			rot_angle = default_rot;
			record_rot = barbette_info->base_rotation;
			target_timer = timer;
			return true;
		}
		return false;
	}

	bool Barbette::SetOffsetByTimer(const Core::Vector3 offset, float timer)
	{
		if (final_offset != offset && barbette_info)
		{
			move_timer = 0;
			barbette_info->base_offset = record_offset = final_offset;
			final_offset = offset;
			target_move_timer = timer;
			return true;
		}
		return false;
	}

	bool Barbette::SetDefaultOffset(float timer)
	{
		if (barbette_info)
		{
			move_timer = 0;
			final_offset = default_offset;
			record_offset = barbette_info->base_offset;
			target_move_timer = timer;
			return true;
		}
		return false;
	}

	bool Barbette::SetRotationByCharacter(uint uid)
	{
		lock_character_id = uid;
		lock_character_type = 1;
		return true;
	}

	bool Barbette::SetOffsetByCharacter(uint uid)
	{
		lock_character_id = uid;
		lock_character_type = 2;
		return true;
	}

	bool Barbette::SetOffsetAndRotationByCharacter(uint uid)
	{
		lock_character_id = uid;
		lock_character_type = 3;
		return true;
	}
}
