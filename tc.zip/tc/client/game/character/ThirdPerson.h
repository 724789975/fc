namespace Client
{
	class CharacterMesh;

	class DetachablePart : public Core::Object
	{
	public:
		class DetachablePartData
		{
		public:
			DetachablePartData()
			{
				base_offset = Core::Vector3::kZero;
				base_rotation = Core::Quaternion::kIdentity;

				part = kCharacterPartCount;
				proportion = 0.f;

				fix_position = 0;
				fix_rotation = 0;
			}

			/// assignment
			const DetachablePartData & operator =(const DetachablePartInfo & info)
			{
				joint = info.joint;

				base_offset = info.base_offset;
				base_rotation.SetZXY(info.base_rotation * Core::DEG2RAD);

				part = info.part;
				proportion = info.proportion;

				fix_position = info.fix_position;
				fix_rotation = info.fix_rotation;

				return *this;
			}

		public:
			Core::Identifier	joint;

			Core::Vector3		base_offset;
			Core::Quaternion	base_rotation;

			CharacterPart		part;
			float				proportion;

			int					fix_position;
			int					fix_rotation;
		};

	public:
		/// constructor
		DetachablePart();

		/// destructor
		~DetachablePart();

	public:
		/// initialize
		bool Initialize(by_ptr(Character) character, const DetachablePartInfo &part_info);

		/// is ready
		bool IsReady();

		/// is died
		bool IsDied();

		/// update 
		void Update(float frame_time);

		/// draw
		void Draw(Primitive::DrawType drawtype, bool immediate = false);

		/// onhit
		bool OnHit(byte part, float prop, const Core::Vector3 & hit_dir);

		void PlayAction(const Core::Identifier & key, float play_time);

		void StopAction();

		void SetAnimationSet(const char * key);

	public:
		/// get position
		const Core::Vector3 & GetPosition();

		/// set position
		void SetPosition(const Core::Vector3 & pos);

		/// get rotation
		const Core::Quaternion & GetRotation();

		/// set rotation
		void SetRotation(const Core::Quaternion & rot);

		/// get detachablepart info
		const DetachablePartData & GetDetachablePartData();

	protected:
		/// add force
		void AddForce(const Core::Vector3 & dir);

		/// set physxcontrol
		void SetPhysxControl(bool flag);

		/// get physxcontrol
		bool GetPhysxControl();

	protected:
		tempc_ptr(Character)	owner;

		DetachablePartData		data;

		sharedc_ptr(SkinMesh)	mesh;

		sharedc_ptr(Skeleton) skeleton;

		sharedc_ptr(AnimationNodeCustom)	animation;
		NxActor*				actor;

		Core::Array<DetachAnimationInfo> animation_info_array;

		DetachAnimationInfo				 first_animation;

		Core::Array<sharedc_ptr(ParticleSystem)> particles;

		bool					is_died;
		float					died_timer;

		Core::Vector3			position;
		Core::Quaternion		rotation;

		float					animation_timer;
	};

	const int BOOSTBULLET_PARTICLE_COUNT = 10;
	const int BUFFER_PARTICLE_COUNT = 7;
	const int BOSS_DANGER_COUNT = 7;
	//const int ZOMBIE_COUNT = 8;
	class ThirdPerson : public Core::Object
	{

	public:
		/// constructor
		ThirdPerson();

		/// destructor
		~ThirdPerson();

	public:
		/// on create
		void OnCreate();

		/// on destroy();
		void OnDestroy();

		/// update 
		void Update(float frame_time);

		/// on render
		void OnRender(float frame_time);

		/// update transform
		void UpdateTransform(float frame_time);

		/// draw
		void Draw(Primitive::DrawType drawtype, bool immediate = false, bool drawgun = true);

		/// get shader lod
		S32 GetShaderLod();

		/// initialize
		void Initialize();

		/// initialize weapon
		void InitializeWeapon(const PackInfo & pack);

		/// initialize mesh
		void InitializeMesh();

		/// get mesh
		tempc_ptr(SkinMesh) GetMesh();

		/// set info
		void SetCharacterInfo(by_ptr(CharacterInfo) info);

		/// preload animation
		void PreloadAnimation(by_ptr(WeaponInfo) info);

		/// preload animation
		void PreloadAnimation(const PackInfo & info);

		/// recover
		void Recover(int health,byte recover_type);

		/// ammorecover
		void AmmoRecover(short ammocount,byte recovertype);
		
		/// recover stop
		void RecoverStop();

		/// burn
		void Burn();

		/// burn stop
		void BurnStop();

		/// poison
		void Poison();

		/// poison stop
		void PoisonStop();
		
		/// play boss danger
		void PlayBossDanger();
		/// Stop play boss danger 
		void StopPlayBossDanger();

	public:
		/// get camera position
		const Core::Vector3 & GetCameraPosition();

		/// get camera rotation
		const Core::Quaternion & GetCameraRotation();

		/// get skeleton rotation
		const Core::Quaternion & GetSkeletonRotation();

		/// get root position
		const Core::Vector3 & GetTorsoPosition();

		/// set character
		void SetCharacter(by_ptr(Character) c);

	public:
		/// jump
		void OnJump();

		/// boost
		void OnBoost(int dir);

		/// on ground
		void OnOnground();

		/// fall down
		void FallDown(float speed, bool is_onground);

		/// die
		void Die(const HitInfo & info);

		/// rebirth
		void Rebirth();

		/// set physx position
		void SyncPhysxPosition();

		/// kill
		void OnKill(const HitInfo & hit);

		/// on hit
		void OnHit(const HitInfo & info);

		/// on hit
		void ResponseHit(const Core::Vector3 & from_position, const Core::Vector3 & target, const Core::Vector3 & normal, int part,  UINT weapontype, bool no_blood = false, bool isboost = false);

		/// on grenade explode
		void OnGrenadeExplode();

		/// on bomb exploded
		void OnBombExploded();

		/// grenade throw in
		void GrenadeThrowIn();

		/// throw grenade
		void GrenadeThrowOut(by_ptr(ThrowableInfo) info, int weapon_id);

		/// stop throw grenade
		void GrenadeThrowStop();

		/// knife stab
		void Stab(byte type, int weapon_id);

		/// stop stab
		void StopStab();

		/// select weapon
		void SelectWeapon(uint weapon_id);

		/// weapon active
		void WeaponActive(uint id);

		/// weapon inactive
		void WeaponInactive(uint id);

		/// set weapon
		void SetWeapon(int slot, by_ptr(WeaponInfo) info);

		/// get weapon
		tempc_ptr(WeaponBase) GetWeapon(int id);

		/// shooting
		void Shoot(int weapon_id,bool isboost = false);

		/// stop shooting
		void StopShoot();

		/// reload
		void Reload();

		sharedc_ptr(Bomb) GetBomb();

		void PlantBomb();

		// drop weapon
		void DropWeapon(int slot);

		// pick up weapon
		void PickUpWeapon(int slot, by_ptr(WeaponInfo) info);

		/// udpate weapon
		void UpdateWeapon(float frame_time);

		/// udpate equipment
		void UpdateEquipment(float frame_time);

		/// use skill
		void UseSkill(by_ptr(PlayerSkill) skill);

		/// use skill stop
		void UseSkillStop(by_ptr(PlayerSkill) skill);

	public:
		/// update audio
		void UpdateAudio(float frame_time);

		/// update animation
		void UpdateAnimation(float frame_time);

		/// update animation third person
		void UpdateAnimationThirdPerson(float frame_time);

		/// update animation third person
		void UpdateAnimationBossPVE(float frame_time);

		/// update animation joint
		void UpdateAnimationJoint(float frame_time);

		/// update physx
		void UpdatePhysx(float frame_time);

		/// update bounding box
		void UpdateBoundingBox();

		/// set physx control
		void SetPhysxControl(bool flag);

		/// set physx group
		void SetPhysxGroup(uint id);

		/// create physx object
		void CreatePhysxObject();

		/// release physx object
		void ReleasePhysxObject();

		/// is ready
		bool IsReady();

		/// get damage part
		int GetDamagePart(int part1, int part2);

		/// get actor id
		int GetActorId(const Core::Identifier & name);

		/// get actor id
		int GetActorId(NxActor* pActor);
		
		/// get jonit id
		uint GetJointIdFromActorId(uint id);

		/// check grenade
		bool CheckGrenade(const Core::Vector3 & pos, float & distance);

		/// check grenade2
		bool CheckGrenade2(const Core::Vector3 & pos, float & distance);

		/// check flash
		bool CheckFlash(const Core::Vector3 & pos, float & distance, bool & back_brght);

		/// get aabb
		const Core::AxisAlignedBox& GetWorldAABB() const;

		void LoadSkeleton();

#if DEBUG_TOOLS
		/// copy OnRender
		void UpdateModelViewer(float frame_time);

		void UpdateAnimationThirdPersonForViewer(float frame_time);
#endif
		void PlayEffectBuffer(int attributetype , float frame_time);
		void PlayFootBuffer(int attributetype , float frame_time);
	public:
		/// create animation
		void CreateThirdPersonAnimation();

	public:
		/// get joint info
		bool GetJointInfo(const Core::Identifier & joint_name, Core::Vector3 &position, Core::Quaternion &rotation);

		/// get joint info
		bool GetJointInfo(uint joint_id, Core::Vector3 &position, Core::Quaternion &rotation);

		void UpdateBoddyParticle(float frame_time);

		void UpdateHumanParticle(float frame_time);

		void UpdateInvisibleParticle(float frame_time);

		void UpdateFootParticle(float frame_time);

		void UpdateEffectParticle(float frame_time);

		void UpdateZombieParticle(float frame_time);

		void UpdateGunParticle(float frame_time);

		void CreateFootParticle();

		void CreateFootParticle(const Core::Identifier & name);

		void CreateGunParticle();

		void ClearBoddyParticle();

		void ClearFootParticle();

		void ClearGunParticle();

		void CreateHumanParticle();

		void CreateInvisibleParticle();

		void CreateZombieParticle();

		void CreateBoddyParticle(const Core::Identifier & name);

		void ClearInvisibleParticle();

		void ClearHumanParticle();

		void ClearZombieParticle();

		void CreateEffectParticle();

		void ClearEffectParticle();

	public:
		struct Actor
		{
			NxActor*			actor;
			Core::Identifier	name;
			uint				joint_id;
		};

		enum ForceSpaceMode
		{
			kForceSpaceLocal,
			kForceSpaceModel,
			kForceSpaceWorld,
		};

		struct PhysxForce
		{
			uint				actor_id;
			Core::Vector3		position;
			Core::Vector3		force;
			ForceSpaceMode		space_mode;
			NxForceMode			force_mode;
			float				time;
		};

		Core::Array<PhysxForce>	physx_force_set;

	private:
		Core::Array<NxJoint*>	physx_joint_set;
		Core::Array<Actor>		physx_actor_set;
		Core::Array<int>		array_physix_id;
		Core::Array<UINT>		arry_buffer_rand;
		Core::Array<UINT>		arry_boss_danger_rand;
		Core::Array<sharedc_ptr(IkJoint)>	ik_l_joints;
		Core::Array<sharedc_ptr(IkJoint)>	ik_r_joints;
		Core::Array<sharedc_ptr(IkJoint)>	ik_leg_joints[2];
		float								ik_leg_offset[2];

		int		camera_joint_id;
		int		handweapon_l_id;
		int		handweapon_r_id;
		int		wrist_ik_l_id;
		int		wrist_ik_r_id;
		int		wrist_l_id;
		int		wrist_r_id;
		int     back_id;
	private:
		typedef Core::HashSet<Core::Identifier, sharedc_ptr(DetachablePart)> DetachablePartSet;

		tempc_ptr(Character)			character;
		sharedc_ptr(CharacterInfo)	character_info;
		sharedc_ptr(CharacterMesh)	mesh;
		sharedc_ptr(SkinMesh)		draw_mesh;
		tempc_ptr(Character)			hit_enemy;
		sharedc_ptr(ParticleSystem)  cure_particle;

		sharedc_ptr(ParticleSystem)	footbuffer;
		sharedc_ptr(ParticleSystem)	invisiblebuffer;

		float footbuffertimer;
		int	  footbuffertype;
		
		
		sharedc_ptr(ParticleSystem)	effectbuffer;
		float effectbuffertimer;
		int	  effectbuffertype;
		
		DetachablePartSet			detachable_part_set;

		sharedc_ptr(ParticleSystem)	damage_particle;
		sharedc_ptr(ParticleSystem)	boostdamage_particle;
		sharedc_ptr(ParticleSystem)	boostdbullet_particle[BOOSTBULLET_PARTICLE_COUNT];

		sharedc_ptr(ParticleSystem)	burn_particle[BUFFER_PARTICLE_COUNT];
		sharedc_ptr(ParticleSystem)	poison_particle[BUFFER_PARTICLE_COUNT];

		sharedc_ptr(ParticleSystem)	boss_danger_particle[BOSS_DANGER_COUNT];
		sharedc_ptr(ParticleSystem)	healthrecover_particle;
		sharedc_ptr(ParticleSystem)	ammorecover_particle;

		sharedc_ptr(ParticleSystem) boddy_particle;
		sharedc_ptr(ParticleSystem) foot_particle;
		sharedc_ptr(ParticleSystem) slow_particle;
		sharedc_ptr(ParticleSystem) qualm_particle;
		sharedc_ptr(ParticleSystem) reverse_particle;
		sharedc_ptr(ParticleSystem) gun_particle;

		sharedc_ptr(ParticleSystem) fast_particle[2];

		sharedc_ptr(ParticleSystem)	human_particle;
		sharedc_ptr(ParticleSystem)	zombie_particle1;
		sharedc_ptr(ParticleSystem)	zombie_particle2;

		sharedc_ptr(ParticleSystem)	clothes_particle;
        bool   clothes_particle1;
		Core::FixedArray<sharedc_ptr(WeaponBase), 7> weapons;

		// animation
		sharedc_ptr(Skeleton)			skeleton;
		sharedc_ptr(AnimationSet)		animation_set;

		Core::Quaternion				lower_rotation;
		Core::Vector3					last_speed;
		int								joint_hip_id;
		bool							skeleton_turn;
		float	angle_h_last;
		float	skeleton_turn_timer;

		float	angle_target;
		uint	lower_state_last;
		float	lower_animation_rate;

		Core::Quaternion skeleton_rotation_oral;
		Core::Quaternion skeleton_rotation;
		Core::Quaternion camera_rotation_oral;
		Core::Quaternion camera_rotation;
		Core::Vector3 camera_position;

		Core::Vector3 root_position;

		Core::FixedArray<sharedc_ptr(AnimationSetRes), 7> animation_set_weapon;

		// sound
		FMOD::Event* audio_step;
		FMOD::Event* audio_use_equipment;
		FMOD::Event* tank_idel_3d;

		// aabb
		Core::AxisAlignedBox			world_aabb;

		sharedc_ptr(StaticMesh) revenge_mesh;

	public:
		sharedc_ptr(AnimationNodeCustom)	animation_system;
		sharedc_ptr(AnimationNodeList)	node_list_system;
		sharedc_ptr(AnimationNodeRandom)	node_random;

		sharedc_ptr(AnimationNodeCustom)	node_data_upper;
		sharedc_ptr(AnimationNodeList)	node_list_upper;
		sharedc_ptr(BlendInfo)			node_upper_blend_info;
		
		sharedc_ptr(AnimationNodeCustom) node_data_lower;
		sharedc_ptr(AnimationNodeSync)	node_list_lower;
		sharedc_ptr(BlendInfo)			node_lower_blend_info;

		sharedc_ptr(AnimationNodeGroup)	node_group;
		sharedc_ptr(AnimationNodeList)	node_list_action;
		sharedc_ptr(BlendInfo)			node_group_blend_info;

		sharedc_ptr(AnimationNodeCustom)	node_blend_hit;
		sharedc_ptr(BlendInfo)			node_hit_blend_info;

		sharedc_ptr(AnimationNodeCustom)	node_face;
		sharedc_ptr(BlendInfo)			node_face_blend_info;

		sharedc_ptr(Pose)				pose;
		bool							jump_to_run;
		
		float							cure_particel_time;

		sharedc_ptr(StaticMesh)			billboard_mesh;
		sharedc_ptr(StaticMesh)			control_mesh;

		sharedc_ptr(StaticMesh)			item_mode_head;

	public:
		// for model viewer	
		int show_count;			
		// for thirdperson multianimation
		int ammo_need_multianimation;
		bool reload_multianimation;
		bool showrevenge;
		bool showcontrol;
		float							billboard_timer;
		float							itemmode_timer;

	private:
		// hold weapon
		Core::Array<sharedc_ptr(WeaponBase)>		weapon_hold_set;
		int cure_state;
		int cure_state_thr;
		int mini_state;
		int mini_state_thr;
		int	now_step_material;
		//
		int now_stepway;
		
		int curboostindex;
		float rotate_limit;
	};
}