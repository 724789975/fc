namespace Client
{
	/// IBarbette
	class IBarbette : public Core::Object
	{
	public:
		/// destructor
		virtual ~IBarbette() {};

		/// initialize
		virtual bool Initialize(by_ptr(Character) c, by_ptr(BarbetteInfo) info) = 0;

		/// is ready
		virtual bool IsReady() = 0;

		/// update 
		virtual void Update(float frame_time) = 0;

		/// timestepupdate
		virtual void TimeStepUpdate(float frame_time) = 0;

		/// draw
		virtual void Draw(Primitive::DrawType drawtype, bool immediate = false) = 0;

	public:
		/// canfire
		virtual bool CanFire() = 0;

		/// isinrange
		virtual bool IsInRange(const Core::Vector3 &target) = 0;

		/// fire
		virtual void Fire(const Core::Quaternion &target) = 0;

		/// fire
		virtual void FirePosition(const Core::Vector3 &target) = 0;

		/// fire
		virtual void FireCharacter(by_ptr(Character) target) = 0;

		/// fire
		virtual void FireToPosition(const Core::Vector3 &target) = 0;

		/// fire
		virtual void FireToCharacter(by_ptr(Character) target) = 0;

		/// reset
		virtual void Reset() = 0;

	public:
		/// get position
		virtual const Core::Vector3 & GetPosition() = 0;

		/// set position
		virtual void SetPosition(const Core::Vector3 &pos) = 0;

		/// move position
		virtual void MovePosition(const Core::Vector3 &pos) = 0;

		/// get rotation
		virtual const Core::Quaternion & GetRotation() = 0;
		virtual const Core::Vector3 GetRotationAngle() = 0;

		/// set rotation
		virtual void SetRotation(const Core::Quaternion &rot) = 0;
		virtual void SetRotationAngle(const Core::Vector3 &rot) = 0;

		/// move rotation
		virtual void MoveRotation(const Core::Quaternion &rot) = 0;

		/// set physxcontrol
		virtual void SetPhysxControl(bool flag) = 0;

		/// get physxcontrol
		virtual bool GetPhysxControl() = 0;

		/// get camera
		virtual Camera& GetCamera() = 0;

		/// set final rotation
		virtual bool SetRotationByTimer(const Core::Quaternion rot, float timer) = 0;

		/// set final position
		virtual bool SetOffsetByTimer(const Core::Vector3 offset, float timer) = 0;

		/// set default rotation
		virtual bool SetDefaultRotation(float timer) = 0;

		/// set default offset
		virtual bool SetDefaultOffset(float timer) = 0;

		/// set rot by character
		virtual bool SetRotationByCharacter(uint uid) = 0;

		/// set offset by character
		virtual bool SetOffsetByCharacter(uint uid) = 0;

		virtual bool SetOffsetAndRotationByCharacter(uint uid) = 0;
	};

	/// Barbette
	class Barbette : public IBarbette
	{
	public:
		/// constructor
		Barbette();

		/// destructor
		~Barbette();

		/// initialize
		bool Initialize(by_ptr(Character) c, by_ptr(BarbetteInfo) info);

		/// is ready
		bool IsReady();

		/// update 
		void Update(float frame_time);

		/// timestepupdate
		void TimeStepUpdate(float frame_time);

		/// draw
		void Draw(Primitive::DrawType drawtype, bool immediate = false);

	public:
		/// canfire
		bool CanFire();

		/// isinrange
		bool IsInRange(const Core::Vector3 &target);

		/// fire
		void Fire(const Core::Quaternion &target);

		/// fire
		void FirePosition(const Core::Vector3 &target);

		/// fire
		void FireCharacter(by_ptr(Character) target);

		/// fire
		void FireToPosition(const Core::Vector3 &target);

		/// fire
		void FireToCharacter(by_ptr(Character) target);

		/// reset
		void Reset();

	public:
		/// get position
		const Core::Vector3 & GetPosition();

		/// set position
		void SetPosition(const Core::Vector3 &pos);

		/// move position
		void MovePosition(const Core::Vector3 &pos);

		/// get rotation
		const Core::Quaternion & GetRotation();
		const Core::Vector3 GetRotationAngle();

		/// set rotation
		void SetRotation(const Core::Quaternion &rot);
		void SetRotationAngle(const Core::Vector3 &rot);

		/// move rotation
		void MoveRotation(const Core::Quaternion &rot);

		/// set physxcontrol
		void SetPhysxControl(bool flag);

		/// get physxcontrol
		bool GetPhysxControl();

		/// get camera
		Camera& GetCamera();

		/// set final rotation
		bool SetRotationByTimer(const Core::Quaternion rot, float timer);

		/// set final position
		bool SetOffsetByTimer(const Core::Vector3 offset, float timer);

		/// set default rotation
		bool SetDefaultRotation(float timer);

		/// set default offset
		bool SetDefaultOffset(float timer);

		/// set rot by character
		bool SetRotationByCharacter(uint uid);

		/// set offset by character
		bool SetOffsetByCharacter(uint uid);

		bool SetOffsetAndRotationByCharacter(uint uid);

	private:
		tempc_ptr(Character)	character;

		sharedc_ptr(SkinMesh)	mesh;
		sharedc_ptr(Skeleton)	skeleton;

		NxActor*				actor;

		sharedc_ptr(BarbetteInfo) barbette_info;
		sharedc_ptr(PVEWeaponBase) weapon;

		sharedc_ptr(ParticleSystem) fire_particle;

		Core::Vector3			position;					//������λ��
		Core::Quaternion		rotation;					//��������ת
		bool					can_freemove;

		Core::HashSet<Core::Identifier, sharedc_ptr(ParticleSystem)> particles;

		bool					is_camera_updated;
		Camera					camera;

		//��ת���ƶ���صĲ������������κ��޸�ֻ��ͨ��SetRotationAngleByTimerȥ����
		Core::Quaternion		rot_angle;					//��ת����
		Core::Quaternion		record_rot;					//��¼֮ǰ�Ļ���
		Core::Quaternion		default_rot;				//Ĭ�ϵ���ת
		float					target_timer;				//ÿ����ת��Ҫ��ʱ�䣬��������0.5��
		float					rot_timer;					//��ǰ��ת��ʱ��

		Core::Vector3			final_offset;				//���յ�����ƫ��
		Core::Vector3			record_offset;				//��¼֮ǰ���ƶ�
		Core::Vector3			default_offset;				//Ĭ�ϵ�ƫ��
		float					move_timer;					//��ǰ�ƶ���ʱ��
		float					target_move_timer;			//ÿ���ƶ�ʱ�䣬��������0.5��
		uint					lock_character_id;			//���������˵�ID
		uint					lock_character_type;		//�����ķ�ʽ
	};
};
