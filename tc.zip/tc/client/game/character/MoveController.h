
namespace Client
{
	struct MoveInfo
	{
		float move_factor;
		float jump_factor;

		float run_speed;
		float walk_speed;
		float crouch_speed;
		float flight_speed;
		float flight_max_speed;
		float acceleration;

		float hit_speed;
		float hit_acceleration;
		float hit_distance;

		float jump_velocity;
	};

	struct ControllerInfo
	{
		float controller_height;
		float controller_radius;
		float controller_crouch_height;
		float controller_skinwidth;

		ControllerInfo()
			: controller_height(0.75f)
			, controller_crouch_height(0.30f)
			, controller_radius(0.5f)
			, controller_skinwidth(0.08f)
		{
		}
	};

	struct KickInfo
	{
		float kick_time_interval;
		float kick_factor;
		Core::Quaternion dir;
		float on_static_kick_y_offset;
		KickInfo()
		{
			kick_factor = 1.f;
			kick_time_interval = 1.f;
			on_static_kick_y_offset = 0.f;
		}
	};

	struct HitInfo;

	class MoveController : public Core::Object
	{
	public:
		/// constructor
		MoveController();

		/// destructor
		virtual ~MoveController();

	public:
		/// on create
		virtual void OnCreate();

		/// on destroy
		virtual void OnDestroy();

		/// create physx object
		virtual void CreatePhysxObject(by_ptr(Character) character);

		/// release physx object
		virtual void ReleasePhysxObject();

		/// update
		virtual void Update(float frame_time);

		/// set character
		virtual void SetCharacter(by_ptr(Character) character);

	public:
		/// set controller info
		virtual void SetControllerInfo(const ControllerInfo & info);

		/// set move Info
		virtual void SetMoveInfo(const MoveInfo & info);

		/// set move factor
		virtual void SetMoveFactor(float factor);

		/// set jump factor
		virtual void SetJumpFactor(float factor);

		/// set run speed
		virtual void SetRunSpeed(float speed);

		virtual float GetRunSpeed();
		
		virtual void SetWalkSpeed(float speed);

		virtual void SetCrouchSpeed(float speed);

		virtual void SetFlightSpeed(float speed);

		/// set hit factor
		virtual void SetHitFactor(float hit_speed, float hit_acceleration, float hit_distance);

		/// set move
		virtual void SetMove(float move, float shift);

		/// get direction
		virtual const Core::Vector3 & GetMove();

		/// get direction
		virtual const Core::Vector2 & GetDirection();

		/// move look
		virtual void MoveLook(float horizontal, float vertical);

		/// get position
		virtual const Core::Vector3 & GetPosition();

		/// set position
		virtual void SetPosition(const Core::Vector3 & pos);

		/// move position
		virtual void MovePosition(const Core::Vector3 & pos);

		/// get rotation
		virtual const Core::Quaternion & GetRotation();

		/// set rotaion
		virtual void SetRotation(const Core::Quaternion & rot);

		/// set face dir
		virtual void SetLookDir(const Core::Quaternion & rot);

		/// get face dir
		virtual const Core::Quaternion &  GetLookDir();

		/// set crouch
		virtual void SetCrouch(bool flag = false);

		/// set walk
		virtual void SetWalk(bool flag = false);

		/// get crouch
		virtual bool GetCrouch();

		/// get walk
		virtual bool GetWalk();

		/// is jumping
		virtual bool IsJumping();

		/// is flying
		virtual bool IsFlying();

		/// is boost
		virtual bool IsBoost();

		virtual bool IsUavFlying();

		/// is on ground
		virtual bool IsOnGround();

		/// is moving
		virtual bool IsMoving();

		virtual bool IsSlowMoving();
		/// jump
		virtual void AmmoJump();

		/// jump
		virtual void Jump();

		/// fly
		virtual void Fly();

		/// boost
		virtual void Boost(int dir);

		/// set jump
		virtual void SetJump(bool flag);

		/// set fly
		virtual void SetFly(bool flag);

		/// set Boost
		virtual void SetBoost(bool flag , int dir);

		/// set onground
		virtual void SetOnGround(bool flag);

		/// set current speed
		virtual void SetCurrentSpeed(const Core::Vector3 & speed);

		/// add velocity
		virtual void AddVelocity(const Core::Vector3 & velocity) {};
		
		virtual void SetVelocity(const Core::Vector3 & velocity) {};

	public:
		/// on rebirth
		virtual void OnRebirth(by_ptr(Character) c, const Core::Vector3 & p, const Core::Quaternion & r);

		/// on died
		virtual void OnDied();

		/// on hit
		virtual void OnHit(const HitInfo & info, float speed_factor = 1.0f, float acc_factor = 1.0f, float distance_factor = 0.f);

		virtual void OnHitByVehicle(const KickInfo & info, bool skip_physx);

		virtual float GetKickTimer();

#if DEBUG_TOOLS
		virtual void UpdateForViewer(float frame_time) {};
		virtual void JumpByViewer() {};
#endif

	protected:
		tempc_ptr(Character) character;

	protected:
		MoveInfo			move_info;

		Core::Quaternion	rotation;
		Core::Quaternion	look_dir;
		Core::Vector3		position;
		Core::Vector3		move_dir;
		Core::Vector2		direction;

		
		Core::Vector3		kick_target;

		int					physx_group;

		float				move_speed;
		int					fall_flag;  //�ڰ�����2����

		// state
		bool				jumping		: 1;
		bool				onground	: 1;
		bool				crouch		: 1;
		bool				walk		: 1;
		bool				flying		: 1;
		bool				boost		: 1;
		bool				uav_flying		: 1;
		

		// physx
		NxActor*			body_capsule;

	public:
		ControllerInfo		controller_info;

		float				height;
		Core::Vector3		current_speed;

		float				vertical_speed;

		float				kick_on_hit_timer;

		float				begin_high;
	};
}


namespace Client
{
	class SimulateMove : public MoveController
	{
	public:
		/// constructor
		SimulateMove();

	public:
		/// on create
		virtual void OnCreate();

		/// create physx object
		virtual void CreatePhysxObject(by_ptr(Character) character);
		/// release physx object
		virtual void ReleasePhysxObject();
		/// update
		virtual void Update(float frame_time);

	public:
		/// move look
		virtual void MoveLook(float horizontal, float vertical);

		/// set position
		virtual void SetPosition(const Core::Vector3 & pos);

		/// set crouch
		virtual void SetCrouch(bool flag = false);

		/// set current speed
		virtual void SetCurrentSpeed(const Core::Vector3 & speed);

		/// jump
		virtual void Jump();

		/// set fly
		virtual void SetFly(bool flag);

		virtual void SetUAVFly(bool flag);
		
		/// add velocity
		virtual void AddVelocity(const Core::Vector3 & velocity);
		
		virtual void SetVelocity(const Core::Vector3 & velocity);

		virtual void QuickMoveSound();

	public:
		/// on rebirth
		virtual void OnRebirth(by_ptr(Character) c, const Core::Vector3 & p, const Core::Quaternion & r);

		/// on hit
		virtual void OnHit(const HitInfo & info, float speed_factor = 1.0f, float acc_factor = 1.0f, float distance_factor = 0.f);

		/// on hit
		virtual void OnHitByVehicle(const KickInfo & info, bool skip_physx);

#if DEBUG_TOOLS
		virtual void UpdateForViewer(float frame_time);
		virtual void JumpByViewer();
#endif

	private:
		/// move callback
		void MoveCallback(const NxSweepQueryHit & hit);

	private:
		bool				sliding		: 1;

		float				hit_acceleration;

		float				flight_time;
		float				speed_update_time;
		Core::Vector3		speed_last_position;
		uint				collision_flags;
		NxActor*			body_squere;
		bool				hit_skip_physx;
	};
}