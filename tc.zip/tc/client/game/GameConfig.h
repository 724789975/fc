namespace Client
{
	enum ActionType
	{
		kActionNone = 0,
		kActionMoveForward,
		kActionMoveBackward,
		kActionMoveLeft,
		kActionMoveRight,

		kActionTurnUp,
		kActionTurnDown,
		kActionTurnLeft,
		kActionTurnRight,

		kActionJump,
		kActionCrouch,
		kActionWalk,

		kActionFire,
		kActionSecondFire,
		kActionReload,
		kActionChangeWeapon,
		kActionWeaponUp,
		kActionWeaponDown,
		kActionDropWeapon,
		kActionUseItem,
		kActionCallMedic,
		kActionShowName,
		kActionPrintScreen,
		kActionSpray,

		kActionUIGameInfo,
		kActionUIMap,
		kActionUIPack,
		kActionUIWeaponPack,
		kActionUIRadio1,
		kActionUIRadio2,
		kActionUIRadio3,
		kActionUIRadio4,
		kActionUIHelp,

		kActionSensitivityUp,
		kActionSensitivityDown,

		kActionMenu0,
		kActionMenu1,
		kActionMenu2,
		kActionMenu3,
		kActionMenu4,
		kActionMenu5,
		kActionMenu6,
		kActionMenu7,
		kActionMenu8,
		kActionMenu9,

		kActionChatCurrentEx,
		kActionChatTeamEx,

		kActionKickYes,
		kActionKickNo,

		kActionTeamYes,
		kActionTeamNo,

		kActionSuicide,

		kAction_Key1,
		kAction_Key2,
		kAction_Key3,
		kAction_Key4,
		kAction_Key5,

		kTakePicture,

		kActionUseSkill,
		kActionUseSkill2,
		kActionUseSkillSurvival_1,
		kActionUseSkillSurvival_2,
		kActionUseSkillSurvival_3,
		kActionUseSkillSurvival_4,
		kActionUseSkillSurvival_5,
		kActionDestroyTowerGun,

		kActionCount,
	};

	class GameConfig : public Core::Object
	{
	public:
		enum TimeStepType
		{
			kTimeStepTypeFixed,
			kTimeStepTypeVariable,

			kTimeStepTypeCount,
		};

		static const int ACTION_INPUT_MAX = 2;

		struct ActionBind
		{
			ActionType		action_type;
			InputCode		input_set[ACTION_INPUT_MAX];
			Core::String	description;
			bool			changeable;
		};

	public:
		// graphics
		void SetResolutionBySystem(const Core::Vector2&);

		// check multi sampler type
		bool CheckMultiSamplerType(U32 value);

		// evaluate hardware
		F32 EvaluateHardware();

		// get display mode count
		U32 GetDisplayModeCount();

		// fill display mode
		Core::Vector3 FillDisplayMode(U32 index);

		// fill refresh mode
		U32 FillRefreshRate(U32 index);

		DECLARE_PDE_EVENT(EventLoadSettings,	Client::CmdEventArgs);
		DECLARE_PDE_EVENT(EventLoadProfile,		Client::CmdEventArgs);
		DECLARE_PDE_EVENT(EventSaveProfile,		Core::EventArgs);
	
		DECLARE_PDE_ATTRIBUTE_RW(Invite,	    bool);
		DECLARE_PDE_ATTRIBUTE_RW(Version,	    int);
		DECLARE_PDE_ATTRIBUTE_RW(Moshi,	        int);
		DECLARE_PDE_ATTRIBUTE_RW(Map,	        int);
		DECLARE_PDE_ATTRIBUTE_RW(Specialjob,	int);
		DECLARE_PDE_ATTRIBUTE_RW(Roomnum,	    int);
		DECLARE_PDE_ATTRIBUTE_RW(Roomstate,   	int);

		DECLARE_PDE_ATTRIBUTE_RW(FullScreen,	bool);

		SIMPLE_PDE_ATTRIBUTE_RW(RefreshRate,	U32);
		SIMPLE_PDE_ATTRIBUTE_RW(AspectRatio,	Core::String);

		DECLARE_PDE_ATTRIBUTE_RW(VSync,			bool);
		DECLARE_PDE_ATTRIBUTE_RW(MSAA,			U32);
		DECLARE_PDE_ATTRIBUTE_RW(LeftHand,		bool);

		DECLARE_PDE_ATTRIBUTE_RW(ShaderQuality,	int);
		DECLARE_PDE_ATTRIBUTE_RW(Fluency,	int);
		SIMPLE_PDE_ATTRIBUTE_RW(ModelQuality,	int);
		SIMPLE_PDE_ATTRIBUTE_RW(TextureQuality,	int);
		SIMPLE_PDE_ATTRIBUTE_RW(DynShaderLod,	bool);
		DECLARE_PDE_ATTRIBUTE_RW(Anisotropy,	int);

		DECLARE_PDE_ATTRIBUTE_RW(AudioOff,		bool);
		DECLARE_PDE_ATTRIBUTE_RW(AudioValue,	int);
		DECLARE_PDE_ATTRIBUTE_RW(ProportionRadio,float);
		DECLARE_PDE_ATTRIBUTE_RW(ProportionMusic,float);
		DECLARE_PDE_ATTRIBUTE_RW(ProportionSound,float);

		SIMPLE_PDE_ATTRIBUTE_RW(SoftParticle,	bool);
		SIMPLE_PDE_ATTRIBUTE_RW(Shadow,			int);

		DECLARE_PDE_ATTRIBUTE_RW(Tips,	bool);

		// control
		DECLARE_PDE_ATTRIBUTE_RW(Sensitivity,	float);
		DECLARE_PDE_ATTRIBUTE_RW(SensitivityRatio,const Core::String &);
		DECLARE_PDE_ATTRIBUTE_RW(SensitivitySniper,float);
		DECLARE_PDE_ATTRIBUTE_RW(SensitivityRatioSniper,const Core::String &);
		DECLARE_PDE_ATTRIBUTE_RW(InverseMouse,	bool);

		// login
		SIMPLE_PDE_ATTRIBUTE_RW(PlayerName,		Core::String);

		DECLARE_PDE_ATTRIBUTE_RW(UIVirtualSize,	float);

		SIMPLE_PDE_ATTRIBUTE_RW(TimeStepType,	GameConfig::TimeStepType);
		SIMPLE_PDE_ATTRIBUTE_RW(TimeStepMax,	float);
		SIMPLE_PDE_ATTRIBUTE_RW(TimeStepIter,	int);

		INLINE_PDE_ATTRIBUTE_RW(SettingStream,		Core::String);
		INLINE_PDE_ATTRIBUTE_RW(ProfileStream,		Core::String);

		SIMPLE_PDE_ATTRIBUTE_RW(InviteOff,		bool);
		SIMPLE_PDE_ATTRIBUTE_RW(GuideOff,		bool);
		SIMPLE_PDE_ATTRIBUTE_RW(LeaderEnter,	bool);

		SIMPLE_PDE_ATTRIBUTE_RW(UserLanguage,	Core::String);

		SIMPLE_PDE_ATTRIBUTE_R(ConfigFile,		Core::String);

		bool GetMusicOff();
		bool GetSoundOff();
	public:
		// get user set resolution
		Core::String GetUserResolution();

		void GetUserResolution(Core::Vector2 & res);

		// set user set resolution
		void SetUserResolution(const Core::String& value);

		// get system resolution
		const Core::Vector2& GetSysResolution();

		// set system resolution
		void SetSysResolution(const Core::Vector2 value);

		// set server address
		void SetServerAddress(const Core::String& value);

		// set server port
		void SetServerPort(int value);

		// set notify error
		void SetNotifyError(bool value);

	public:
		// constructor
		GameConfig();

	public:
		// build action map
		void BuildActionMap();

		// bind action
		void BindAction(ActionType type, InputCode input, byte index = 0);

		// action to input
		InputCode ActionToInput(ActionType type, byte index = 0);

		// input to action
		ActionType InputToAction(InputCode input);

		// is input changeable
		bool IsInputChangeable(InputCode input);

		// is action changeable
		bool IsActionChangeable(ActionType type);

		// is action pressed
		bool IsActionPressed(ActionType action_type);

		// is action released
		bool IsActionReleased(ActionType action_type);

		// is action repeated
		bool IsActionRepeated(ActionType action_type);

		// is action down
		bool IsActionDown(ActionType action_type);

		// is action up
		bool IsActionUp(ActionType action_type);

		bool CheckAnisotropy(U32 value);
		bool CheckLanguages(const String &lang);

		// update audio
		void UpdateAudioProportion();

		void LoadGameing();
		void SaveGameing();
		void LoadVersion();
		void SaveVersion();
		void LoadQuickSetting();
		void SaveQuickSetting();
		void LoadMouse();
		void SaveMouse();
		void LoadGraphic();
		void SaveGraphic();
		void LoadGameQuality();
		void SaveGameQuality();
		void LoadTips();
		void SaveTips();
		void LoadAudio();
		void SaveAudio();
		void LoadKeys();
		void SaveKeys();

		void OnLoadConfig(const Core::String& configStream);
		void OnLoadProfile(const Core::String& profileStream);
		void SaveConfig();
		void SaveProfile();

		Core::Vector2 GetBestResolution();

		Core::String GetBillBoardV();
		Core::String GetBillBoardH();
		Core::String GetLogo();

		byte GetNickNameLengthMin();
		byte GetNickNameLengthMax();
		byte GetBattleGroupNameLengthMin();
		byte GetBattleGroupNameLengthMax();
		byte GetRoomNameLengthMin();
		byte GetRoomNameLengthMax();
		byte GetTimeSellDate();
		byte GetTimeSellStart();
		byte GetTimeSellStartDate();
		byte GetTimeSellEnd();
		byte GetTimeSellEndDate();
		byte GetTimeSellGiftH();
		byte GetTimeSellGiftM();
		Core::String GetQuickSellData();

		bool IsInAchievementList(const Core::String& id);
			

		const char GetUISystemFlag(int index);//0 ��ͼ  1 ��ʱ���� 2 �������� 3 ��Դ����սƥ�� 4 ��Դ����ս��ս

	private:
		bool	m_Invite:1;
		int     m_Version;
		int     m_moshi;
		int     m_map;
		int     m_specialjob;
		int     m_roomnum;
		int     m_roomstate;
		bool	m_FullScreen : 1;
		bool	m_VSync : 1;
		U32		m_MSAA;
		int		m_Anisotropy;
		Core::Vector2	user_res;
		Core::Vector2	sys_res;
		int		m_ShaderQuality;
		int		m_Fluency;

		bool	m_LeftHand;
		float	m_Sensitivity;
		float	m_SensitivitySniper;
		bool	m_InverseMouse;

		float	m_UIVirtualSize;
		float	m_NetworkDelay;
		
		bool	m_AudioOff;
		bool    m_Tips : 1;
		int		m_AudioValue;
		float	m_ProportionRadio;
		float	m_ProportionMusic;
		float	m_ProportionSound;

		ActionBind	action_map[kActionCount];
		Core::HashSet<InputCode, ActionType>	input_to_action;

		Core::String m_SettingStream;
		Core::String m_ProfileStream;

	public:
		static const ActionBind DEFAULT_ACTION_MAP[kActionCount];

		Core::String m_SensitivityRatio;
		Core::String m_SensitivityRatio_Sniper;

		Core::Array<Core::String> m_achievementlist;
	};

	struct StartConfig
	{
		Core::String ip;
		int port;
		int areaid;
		int serverid;
		bool exec;
		Core::String exec_cmd;
		Core::String upload_address;
		Core::String authentication_code;
		Core::String login_code;
		bool module_state_Open;
		bool ads_on;
		byte xl_exe_open;
	};
	
	struct HttpConfig
	{
		Core::String http_xl_logo;
		Core::String http_xl_report;
		Core::String http_xl_info;
		Core::String http_fcm;
		Core::String http_gw;
		Core::String http_advertising_v;
		Core::String http_advertising_h;
		Core::String http_paydraw;
		Core::HashSet<int, Core::String> http_pay_set;

		Core::String achievement_list;
		byte nick_name_length_min;
		byte nick_name_length_max;
		byte battle_group_name_length_min;
		byte battle_group_name_length_max;
		byte room_name_length_min;
		byte room_name_length_max;
		byte time_sell_date;
		byte time_sell_start;
		byte time_sell_start_date;
		byte time_sell_end;
		byte time_sell_end_date;
		byte time_sell_giftH;
		byte time_sell_giftM;
		Core::String buffversion;
		Core::String quick_sell_data;
		Core::String time_sell_gold;
		Core::String time_sell_silver;
		Core::String time_sell_cooper;

		Core::String UISystemFlag;

		HttpConfig()
		{
			http_xl_logo = "http://img.fc.xunlei.com/swf/pde/pde_1.swf";
			http_xl_report = "http://act.game.xunlei.com:85/xlgame_dachongfeng/bugreport?action=doReport2";
			http_xl_info = "http://act.game.xunlei.com:85/xlgame_dachongfeng/bugreport?action=doReport";
			http_fcm = "http://youxi.xunlei.com/fcm/";
			http_gw = "http://fc.xunlei.com/index/";
			http_advertising_h = "http://img.fc.xunlei.com/client/embed/484_140.swf";
			http_advertising_v = "http://img.fc.xunlei.com/client/embed/256_500.swf";
			http_paydraw = "http://fc.xunlei.com/act/paydraw/";

			nick_name_length_min = 2;
			nick_name_length_max = 8;

			battle_group_name_length_min = 1;
			battle_group_name_length_max = 10;
			room_name_length_min = 2;
			room_name_length_max = 10;
			time_sell_date = 0;
			time_sell_start = 0;
			time_sell_start_date = 0;
			time_sell_end = 0;
			time_sell_end_date = 0;
			time_sell_giftH = 0;
			time_sell_giftM = 0;
			quick_sell_data = "";
		}
		//3       http://pay.duowan.com/DepositFromGameAction.action?product=DCF
		//0		  http://youxi.xunlei.com/pay/fc/
	};

	struct SystemInfoCollection
	{
		Core::String		cpu_name;
		Core::String		video_adapter_name;
		Core::String		video_adapter_version;
		Core::String		os;
		Core::String		proxy_ip;
		int					proxy_port;

	};

	struct InGameInfoCollection
	{
		int level_id;
		int channel_id;
		Core::String account;
		Core::String character_name;
		Core::String screen_size;
		int full_screen;
		ushort average_ping;
		ushort low_ping;
		ushort high_ping;

		Core::Array<ushort> average_ping_array;
		float ping_timer;

		InGameInfoCollection()
		{
			level_id = 0;
			channel_id = 0;
			full_screen = 0;
			low_ping = 10000;
			high_ping = 0;
			average_ping = 0;
			ping_timer = 0.f;
		}
	};

	struct FaceBookInterface
	{
		Core::String userid;
		Core::String time;
		Core::String key;
		Core::String secret;
		Core::String mark;
		Core::String action;
		Core::String object;
		Core::String sign;
		Core::String url;
		FaceBookInterface()
		{
			userid = "597742659";
			time = "1371224103";
			key = "fctest";
			secret = "3fth6J9x04hN";
			mark = "testlevel";
			action = "complete";
			object = "level";
			url = "http://www.gameturk.com/portal/aqonline/og.php?";
		}
	};

}