#include "pch.h"
#include <stdio.h>
using namespace Core; 
using namespace Client;

DEFINE_PDE_TYPE_CLASS(Client::GunTowerBuilderInfo)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Client::WeaponInfo);

		ADD_PDE_DEFAULT_CONSTRUCTOR();
		ADD_PDE_FIELD(gun_tower_dir);
	}
};

REGISTER_PDE_TYPE(Client::GunTowerBuilderInfo);


enum State
{
	kIdle,
	kPlanted,
};

/// constructor
GunTowerBuilder::GunTowerBuilder(by_ptr(GunTowerBuilderInfo) info)
: on_request_planting(false)
, ammo_count(-1)
{
	weapon_info = tower_info = info;
	state = kIdle;
}

/// destructor
GunTowerBuilder::~GunTowerBuilder()
{
	tempc_ptr(Character) owner = GetOwner();
	if(owner)
	{
		owner->UnLockStateByType(kLSMove);
	}
}

/// update mesh
void GunTowerBuilder::UpdateMesh()
{
	if (state == kPlanted)
		mesh->pose = pose;
	else
		mesh->pose = GetPose();

	mesh->Update();
}

/// draw
void GunTowerBuilder::Draw(Primitive::DrawType drawtype, bool immediate)
{
	if (mesh)
	{
		mesh->SetPosition(GetPosition());
		mesh->SetRotation(GetRotation());
		mesh->Draw(drawtype, immediate);
	}
}

/// initialize
void GunTowerBuilder::Initialize()
{
	WeaponBase::Initialize();

	if (tower_info)
	{
		if (skeleton)
		{
			animation_list = ptr_new AnimationNodeList;
			animation_set = ptr_new AnimationSet;

			if (is_for_player)
			{
				CStrBuf<256> str(ANIMATION_KEY_PROP_PLAYER);

				CStrBuf<256> str_animation;
				str_animation.format("%s/%s", owner->GetCurCharinfo()->first_person_animationset, weapon_info->animation_set);

				if (weapon_info)
					str.contract(str_animation);

				animation_set_player = RESOURCE_GET_BYTYPE(str, ANIMATIONSET_TYPE, AnimationSetRes);
				if (animation_set_player)
				{
					animation_set_player->Load(true);
				}
				animation_set->SetAnimationSet("common", animation_set_player);
			}
			else
			{
				CStrBuf<256> str(ANIMATION_KEY_PROP_CHARACTER);

				CStrBuf<256> str_animation;
				if(owner)
				{
					str_animation.format("%s/%s", owner->GetCurCharinfo()->third_person_animationset, weapon_info->animation_set);

					if (weapon_info)
						str.contract(str_animation);

					animation_set_character = RESOURCE_GET_BYTYPE(str.buff(), ANIMATIONSET_TYPE, AnimationSetRes);
					if (animation_set_character)
					{
						animation_set_character->Load(true);
					}
					animation_set->SetAnimationSet("common", animation_set_character);
				}

			}

			if (animation)
			{
				animation->SetAnimationSet(animation_set);

				sharedc_ptr(AnimationNodePose) node = ptr_new AnimationNodePose(skeleton);
				node->SetAnimation("idle", animation_set);
				animation_list->AddNode("idle", node);

				node = ptr_new AnimationNodePose(skeleton);
				node->SetAnimation("empty", animation_set);
				animation_list->AddNode("empty", node);

				animation_list->SetActiveNode("idle");

				animation->SetAnimationNode(animation_list);
			}

			pose = ptr_new Pose(skeleton);
		}
	}
	CStrBuf<256> str_able_tower_mesh;
	able_tower_mesh = ptr_new StaticMesh(MESH_KEY_WEAPON);
	str_able_tower_mesh.format("%s/%s", weapon_info->name, weapon_info->able_tower_mesh);
	able_tower_mesh->AddPrimitive(str_able_tower_mesh, 0);

	CStrBuf<256> str_bg_tower_mesh;
	bg_tower_mesh = ptr_new StaticMesh(MESH_KEY_WEAPON);
	str_bg_tower_mesh.format("%s/%s", weapon_info->name, weapon_info->bg_tower_mesh);
	bg_tower_mesh->AddPrimitive(str_bg_tower_mesh, 0);

	CStrBuf<256> str_unable_tower_mesh;
	unable_tower_mesh = ptr_new StaticMesh(MESH_KEY_WEAPON);
	str_unable_tower_mesh.format("%s/%s", weapon_info->name, weapon_info->unable_tower_mesh);
	unable_tower_mesh->AddPrimitive(str_unable_tower_mesh, 0);
	
	
}

///// udpate
void GunTowerBuilder::Update(float frame_time)
{
	WeaponBase::Update(frame_time);
	
	tempc_ptr(Character) owner = GetOwner();
	tempc_ptr(Character) player = gLevel->GetPlayer(); 

	if(!player || !owner || player != owner)
		return;

	tempc_ptr(StateMainGame) state_main = ptr_dynamic_cast<StateMainGame>(gGame->machine.CurrentState());
	if (state_main && !state_main->ui->bFoused && !state_main->IsUIFocused() && !owner->tower_gun_count && !on_request_planting)
	{
		if (gGame->input->IsKeyPressed(MC_LEFT_BUTTON) && CanPlant())
		{
			Plant(able_tower_mesh->GetPosition());
			on_request_planting = true;
		}

		if(gGame->input->IsKeyPressed(MC_RIGHT_BUTTON))
		{
			ChangeDir();
		}
	}
}

bool GunTowerBuilder::CanPlant()
{
	tempc_ptr(Character) player = GetOwner();

	if(!player)
		return false;

	if (player->isghost)
		return false;

	if (HasStatic())
		return false;
	
	if (player->tower_gun_count >= 1)
		return false;

	if (!gLevel->IsMachineGunTurretArea(able_tower_mesh->GetPosition()))
		return false;

	if (IsExistTower())
		return false;

	tempc_ptr(Character) owner = GetOwner();
	if (Length(able_tower_mesh->GetPosition() - owner->GetPosition()) > tower_info->max_distance)
		return false;
	
	return true;
}
//// draw UI
void GunTowerBuilder::DrawUI(by_ptr(UIRender) ui_render)
{
	WeaponBase::DrawUI(ui_render);

	Core::CStrBuf<256> buff;

	buff.format("1/%d", 1);
	ui_render->DrawStringShadow(ui_render->font_simhei_24, ARGB(255, 241, 211), ARGB(0,0,0), ARGB(0, 0, 0, 0), Core::Rectangle(-195, 0 - 50, 0, 1), buff, Unit::kAlignLeftBottom);

	buff.format(weapon_info->name);
	buff.toupper();

	ui_render->DrawStringShadow(ui_render->font_simhei_14, ARGB(255, 241, 211), ARGB(0,0,0), ARGB(0, 0, 0, 0), Core::Rectangle(-100, -20, 0, -7), buff, Unit::kAlignCenterBottom);
}
/// can active
bool GunTowerBuilder::CanActive()
{
	return WeaponBase::CanActive();
}

/// active
void GunTowerBuilder::Active()
{
	WeaponBase::Active();
	tempc_ptr(Character) owner = GetOwner();
}

/// inactive
void GunTowerBuilder::Inactive()
{
	WeaponBase::Inactive();
}

/// plant
void GunTowerBuilder::Plant(const Vector3 & pos)
{
	CreatePhysx();
	Quaternion q = Quaternion::kIdentity;
	Quaternion q1 = Quaternion::kIdentity;

	q.SetAxisAngle(Vector3(1, 0, 0), HALFPI);

	tempc_ptr(Character) owner = GetOwner();
	if(owner)
	{
		q1.SetAxisAngle(Vector3(0,1,0), owner->GetRotation().GetZXY().y);
		owner->UnLockStateByType(kLSMove);
	}
	SetRotation(q * q1);
	owner->ChangeWeapon();
}

/// create physx
void GunTowerBuilder::CreatePhysx()
{
	DummyBaseCreateInfo info;
	info.position = able_tower_mesh->GetPosition();
	info.rotation = able_tower_mesh->GetRotation();
	if(owner && owner->GetTeam() < 2)
	{
		sprintf_s(info.key, sizeof(info.key), "%s_%d/rv1", tower_info->name, owner->GetTeam());
		sprintf_s(info.tower_key, sizeof(info.tower_key), "%s", tower_info->name);
	}
	else
	{
		sprintf_s(info.key, sizeof(info.key), "%s_0/rv1", tower_info->name);
		sprintf_s(info.tower_key, sizeof(info.tower_key), "%s", tower_info->name);
	}
	
	info.damage_modifier = tower_info->damage_modifer;
	info.range_start = tower_info->range_start;
	info.range_end = tower_info->range_end;
	info.range_modifier = tower_info->range_modifier;
	info.base_damage = tower_info->damage;

	info.angle_speed = tower_info->show_speed;
	info.check_range = tower_info->hurt_range;
	info.fire_interval = tower_info->fire_time;
	info.check_angle = PI;

	info.level = tower_info->level;

	info.life_time = tower_info->max_lift_time;
	info.distance = tower_info->max_distance;
	
	info.max_hp = 1000;
	info.move_speed = tower_info->move_speed;
	info.move_keep_time = tower_info->move_keep_time;
	info.freeze_count = 0;
	info.respawn_time = 30.f;

	Attribute attrinfo;
	if (tower_info->CheckWeaponAttribute(kWeaponAttr_Turret_TurnSpeedInfect, attrinfo))		
	{
		info.angle_speed *= (1 + attrinfo.value1 / 100.f);
	}

	if (tower_info->CheckWeaponAttribute(kWeaponAttr_Turret_ControlAreaInfect, attrinfo))		
	{
		info.distance *= (1 + attrinfo.value1 / 100.f);
	}

	int ammo_one_clip = GetMaxAmmoCount();
	
	info.max_ammo_count = GetMaxAmmoCount();
	info.current_ammo_count = (GetAmmoCount() == -1 ? ammo_one_clip : GetAmmoCount());
	SetAmmoCount(info.current_ammo_count);

	if (tower_info->CheckWeaponAttribute(kWeaponAttr_Turret_FireRangeInfect, attrinfo))		
	{
		info.check_range *= (1 + attrinfo.value1 / 100.f);
	}

	if (tower_info->CheckWeaponAttribute(kWeaponAttr_Turret_FireSpeedInfect, attrinfo))		
	{
		info.fire_interval *= (1 - attrinfo.value1 / 100.f);
	}

	if (tower_info->CheckWeaponAttribute(kWeaponAttr_Turret_FireDamageInfect, attrinfo))		
	{
		info.base_damage *= (1 + attrinfo.value1 / 100.f);
	}

	info.recover_range = tower_info->recover_range;
	info.recover_check_interval = tower_info->recover_check_interval;
	info.recover_per_count_life = (int)tower_info->recover_per_count_life;
	info.recover_per_percent_ammo = (int)tower_info->recover_per_percent_ammo;
	info.recover_per_minus_ammo = (int)tower_info->recover_per_minus_ammo;

	char buffer[SYNC_BUFFER_SIZE];
	int length = writeUserData(buffer,SYNC_BUFFER_SIZE,info);
	gGame->channel_connection->RequestDummyObjectCreate(DummyObject::DUMMY_MACHINE_TURRENT, buffer, length, 0);

}

/// get position
const Vector3 & GunTowerBuilder::GetPosition()
{
	return position;
}

/// set position
void GunTowerBuilder::SetPosition(const Core::Vector3 & pos)
{
	position = pos;
}

int GunTowerBuilder::GetGunTowerDir()
{
	return tower_info->gun_tower_dir;
}

void GunTowerBuilder::ChangeDir()
{
	tower_info->gun_tower_dir = (tower_info->gun_tower_dir + 1) % 4;
}

const Core::Vector3 GunTowerBuilder::GetTowerMeshPosition(const Vector3 & pos)
{
	Vector3 towermeshposition;
	Vector3 dir = Vector3(0, -1, 0);
	NxRay ray;
	NxRaycastHit hit;
	const float distance = 500.f;
	ray.orig = (const NxVec3 &)pos;
	ray.dir = (const NxVec3 &)dir;
	uint group_id = 0;
	group_id |= 1 << PhysxSystem::kStatic;
	NxShape* shape = gPhysxScene->raycastClosestShape(ray, NX_ALL_SHAPES, hit, group_id, distance);
	if (shape)
	{
		towermeshposition = (Vector3&)hit.worldImpact;
	}
	
	return towermeshposition;
}

bool GunTowerBuilder::IsExistTower()
{
	HashSet<uint, sharedc_ptr(DummyObject)>::Enumerator it(gLevel->dummy_object_set);
	while (it.MoveNext())
	{
		tempc_ptr(DummyObject) d = it.Value();
		if(Length(d->GetPosition() - able_tower_mesh->GetPosition()) < 1.3f)
		{
			return true;
		}
	}
	return false;
}

bool GunTowerBuilder::HasStatic()
{
	Vector3 dir = Vector3(0, 0, -1); 
	NxRay ray;
	NxRaycastHit hit;
	const float distance = Length(able_tower_mesh->GetPosition() - owner->GetCameraPosition());
	ray.orig = (const NxVec3 &)owner->GetCameraPosition();
	ray.dir = (const NxVec3 &)(able_tower_mesh->GetPosition() - owner->GetCameraPosition());
	ray.dir.normalize();
	uint group_id = 0;
	group_id |= 1 << PhysxSystem::kStatic;
	NxShape* shape = gPhysxScene->raycastClosestShape(ray, NX_ALL_SHAPES, hit, group_id, distance);
	if (shape)
	{
		if(hit.distance <= distance * 0.95f)
		{
			return true;
		}
	}
	return false;
}

int GunTowerBuilder::GetAmmoCount()
{
	return ammo_count;
}

void GunTowerBuilder::SetAmmoCount(int ammocount)
{
	if (ammocount > GetMaxAmmoCount())
		ammo_count = GetMaxAmmoCount();
	else
		ammo_count = ammocount;
}

int GunTowerBuilder::GetMaxAmmoCount()
{
	Attribute attrinfo;
	tower_info->CheckWeaponAttribute(kWeaponAttr_Turret_AmmoOneClipInfect, attrinfo);
	return tower_info->ammo_one_clip * (owner->GetTotalAttributeByType(kEffect_Infect_AmmoOneClip) + (attrinfo.value1 / 100.f));
}