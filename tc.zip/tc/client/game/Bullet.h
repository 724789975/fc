namespace Client
{
	class BulletManager
	{
	private:
		struct Bullet
		{
			Core::Vector3 start;
			Core::Quaternion direction;
			float distance;
			float position;
			float end;
			byte  team;
			bool  boost;
			Core::Vector2 scale;
		};

		Core::FixedArray<Bullet, 16> bullets;
		sharedc_ptr(StaticMesh) bullet_mesh;
		sharedc_ptr(StaticMesh) redboost_bullet_mesh;
		sharedc_ptr(StaticMesh) blueboost_bullet_mesh;
	public:
		// initialize
		void Initialize();

		// terminate
		void Terminate();

		// terminate
		~BulletManager();

		// Adds a bullet.
		void Add(const Core::Vector3 & from, const Core::Quaternion & dir, float distance, byte team, bool isboost = false);

		// Update system.
		void Update(float frametime);

		// render
		void Draw(Primitive::DrawType type, bool immediate = false);

		sharedc_ptr(BulletSmoke) bullet_smoke;
	};
}