namespace Client
{
	static void lua_LoadArray(Lua::LuaState *L, int id, Core::Array<float>& o)
	{
		int array_size = L->ObjLen(id);
		o.Clear();
		o.Reserve(array_size);
		for (int i = 0; i < array_size; i++)
		{
			L->PushInteger(i + 1);
			L->GetTable(-2);
			o.PushBack(L->ToNumber(-1));
			L->Pop(1);
		}
	}

	static void lua_LoadArray(Lua::LuaState *L, int id, Core::Array<int>& o)
	{
		int array_size = L->ObjLen(id);
		o.Clear();
		o.Reserve(array_size);
		for (int i = 0; i < array_size; i++)
		{
			L->PushInteger(i + 1);
			L->GetTable(-2);
			o.PushBack(L->ToInteger(-1));
			L->Pop(1);
		}
	}

	static void lua_LoadArray(Lua::LuaState *L, int id, Core::Array<Core::Identifier>& o)
	{
		int array_size = L->ObjLen(id);
		o.Clear();
		o.Reserve(array_size);
		for (int i = 0; i < array_size; i++)
		{
			L->PushInteger(i + 1);
			L->GetTable(-2);
			o.PushBack(L->ToString(-1));
			L->Pop(1);
		}
	}

}




//------------------------------------------------------------------------------------------------------
//					Loading Function For Particle
//------------------------------------------------------------------------------------------------------
namespace Client
{
#define	MAX_PARTICLES	0xffffffff
#define F32_SMALL_NUMBER		(1.e-8)
#define F32_KINDA_SMALL_NUMBER	(1.e-4)
#define INIT_PE_PARAMETER_FLOAT(name)														\
	SAFE_DELETE(name)																		\
	name = new PeParameterFloatConstant;
#define INIT_PE_PARAMETER_VECTOR3(name)													\
	SAFE_DELETE(name)																		\
	name = new PeParameterVector3Constant;
#define INIT_PE_PARAMETER_COLOR(name)														\
	SAFE_DELETE(name)																		\
	name = new PeParameterColorConstant;

	static void lua_LoadString(Lua::LuaState *L, char* fieldname, const char* &str)
	{
		L->GetField(-1, fieldname);
		str = L->ToString(-1);
		L->Pop(1);
	}

	static void lua_LoadFloat(Lua::LuaState *L, char* fieldname, F32 &value)
	{
		L->GetField(-1, fieldname);
		value = L->ToNumber(-1);
		L->Pop(1);
	}

	static void lua_LoadInteger(Lua::LuaState *L, char* fieldname, U32 &value)
	{
		L->GetField(-1, fieldname);
		value = L->ToInteger(-1);
		L->Pop(1);
	}

	static void lua_LoadBoolean(Lua::LuaState *L, char* fieldname, bool &value)
	{
		L->GetField(-1, fieldname);
		value = L->ToBoolean(-1);
		L->Pop(1);
	}


	static U32 lua_GetCurvePointNum(Lua::LuaState *L, char* fieldname)
	{
		L->GetField(-1, fieldname);

		int control_point_num = L->ObjLen(-1);

		L->Pop(1);

		return control_point_num;
	}

	static void lua_LoadSpline(Lua::LuaState *L, char* fieldname, Core::PdeSplineColor3 &spline)
	{
		L->GetField(-1, fieldname);

		int control_point_num = L->ObjLen(-1);
		for (int i = 0; i < control_point_num; i++)
		{
			L->PushInteger(i + 1);
			L->GetTable(-2);

			//----------input
			L->PushInteger(1);
			L->GetTable(-2);
			F32 t = L->ToNumber(-1);
			L->Pop(1);
			//----------output
			L->PushInteger(2);
			L->GetTable(-2);
			Core::Array<float> v1;
			lua_LoadArray(L, -1, v1);
			L->Pop(1);
			Core::Color3 c1 = Core::Color3(v1[0], v1[1], v1[2]);
			//----------ArriveTangent
			L->PushInteger(3);
			L->GetTable(-2);
			Core::Array<float> v2;
			lua_LoadArray(L, -1, v2);
			L->Pop(1);
			Core::Color3 c2 = Core::Color3(v1[0], v1[1], v1[2]);
			//----------LeaveTangent
			L->PushInteger(4);
			L->GetTable(-2);
			Core::Array<float> v3;
			lua_LoadArray(L, -1, v3);
			L->Pop(1);
			Core::Color3 c3 = Core::Color3(v1[0], v1[1], v1[2]);
			//----------Mode
			L->PushInteger(5);
			L->GetTable(-2);
			U32 type = L->ToInteger(-1);
			L->Pop(1);

			spline.AddPoint(t, c1, c2, c3, type);

			L->Pop(1);
		}

		L->Pop(1);
	}

	static void lua_LoadColor3(Lua::LuaState *L, char* fieldname, Core::Color3 &color)
	{
		L->GetField(-1, fieldname);

		//----------r
		L->PushInteger(1);
		L->GetTable(-2);
		color.r = L->ToNumber(-1);
		L->Pop(1);
		//----------g
		L->PushInteger(2);
		L->GetTable(-2);
		color.g = L->ToNumber(-1);
		L->Pop(1);
		//----------b
		L->PushInteger(3);
		L->GetTable(-2);
		color.b = L->ToNumber(-1);
		L->Pop(1);

		L->Pop(1);
	}
}
