namespace Client
{
	struct GunTowerBuilderInfo : public GunInfo
	{
		int					gun_tower_dir; 
		float				max_distance;
		float				max_lift_time;
		float				hurt_range;
		float				show_speed;

		float				move_speed;
		float				move_keep_time;

		float				recover_range;
		float				recover_check_interval;
		float				recover_per_count_life;
		float				recover_per_percent_ammo;
		float				recover_per_minus_ammo;

		GunTowerBuilderInfo()
		{
			weapon_type = kWeaponTypeGunTowerBuilder;
			gun_tower_dir = 0;
		}
	};

	class GunTowerBuilder : public WeaponBase
	{
	public: 
		/// constructor
		GunTowerBuilder(by_ptr(GunTowerBuilderInfo) info);

		/// destructor
		virtual ~GunTowerBuilder();

		/// get weapon type
		virtual uint GetWeaponType() { return kWeaponTypeGunTowerBuilder; }

	public:
		/// draw
		virtual void Draw(Primitive::DrawType drawtype, bool immediate = false);

		/// initialize
		virtual void Initialize();

		/// udpate
		virtual void Update(float frame_time);

		/// can active
		virtual bool CanActive();

		/// active
		virtual void Active();

		/// inactive
		virtual void Inactive();

		/// update mesh
		virtual void UpdateMesh();

		/// draw ui
		virtual void DrawUI(by_ptr(UIRender) ui_render);
	public:
		/// get position
		virtual const Core::Vector3 & GetPosition();

		/// set position
		virtual void SetPosition(const Core::Vector3 & pos);

		/// plant
		void Plant(const Core::Vector3 & position);

		void StopPlantTower();

		/// create physx
		void CreatePhysx();

		bool CanPlant();

		int GetGunTowerDir();

		void ChangeDir();

		bool IsExistTower();

		bool HasStatic();

		const Core::Vector3 GetTowerMeshPosition(const Core::Vector3 & pos);

		int GetAmmoCount();

		void SetAmmoCount(int ammocount);

		int GetMaxAmmoCount();

	public:
		sharedc_ptr(GunTowerBuilderInfo)	tower_info;
		bool					on_request_planting;
		sharedc_ptr(StaticMesh)			able_tower_mesh;
		sharedc_ptr(StaticMesh)			unable_tower_mesh;
		sharedc_ptr(StaticMesh)			bg_tower_mesh;
	private:
		byte					state;
		sharedc_ptr(SkinMesh) bag_mesh;
		sharedc_ptr(Skeleton) bag_skeleton;
		sharedc_ptr(Pose)	 bag_pose;
		int					ammo_count;
	};
}