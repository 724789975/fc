#include "pch.h"

using namespace Core;
using namespace Client;

DEFINE_PDE_TYPE_CLASS(Client::AmmoInfo)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Client::WeaponInfo);

		//ADD_PDE_FIELD(maxalive_time);
		//ADD_PDE_FIELD(gravity);
		//ADD_PDE_FIELD(range);
		//ADD_PDE_FIELD(damage);

		//ADD_PDE_FIELD(dmg_modify_timer_min);
		//ADD_PDE_FIELD(dmg_modify_timer_max);
		//ADD_PDE_FIELD(dmg_modify_min);
		//ADD_PDE_FIELD(dmg_modify_max);

		//ADD_PDE_FIELD(capsule_height);
		//ADD_PDE_FIELD(capsule_radius);
	
		ADD_PDE_FIELD(explode_decal);
		ADD_PDE_FIELD(explode_particle);
		ADD_PDE_FIELD(explode_sound);
		ADD_PDE_FIELD(fly_particle);
		ADD_PDE_FIELD(stick_particle);
		ADD_PDE_FIELD(fly_sound);
		ADD_PDE_FIELD(fly_joint_name);
		ADD_PDE_FIELD(hurtself);
		ADD_PDE_FIELD(ignorewall);
		ADD_PDE_FIELD(impact_count_max);
		ADD_PDE_DEFAULT_CONSTRUCTOR();
	}
};

REGISTER_PDE_TYPE(Client::AmmoInfo);


DEFINE_PDE_TYPE_CLASS(Client::AmmoBase)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Client::WeaponBase);
	}
};
 
REGISTER_PDE_TYPE(Client::AmmoBase);

DEFINE_PDE_TYPE_CLASS(Client::Ammo)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Client::AmmoBase);
	}
};
 
REGISTER_PDE_TYPE(Client::Ammo);

///////////////////////////////////////////////////////////////////////////////////////////////////
sharedc_ptr(AmmoBase) AmmoFactory::CreateAmmo(by_ptr(WeaponInfo) info)
{
	if (info)
	{
		switch (info->weapon_type)
		{
		case kWeaponTypeAmmoRocket:
			{
				tempc_ptr(AmmoInfo) t_info = ptr_static_cast<AmmoInfo>(info);
				return ptr_new Ammo(t_info);
			}
			break;
		case kWeaponTypeAmmoGrenade:
			{
				tempc_ptr(AmmoInfo) t_info = ptr_static_cast<AmmoInfo>(info);
				return ptr_new AmmoGrenade(t_info);
			}
			break;
		case kWeaponTypeAmmoBloodDisk:
			{
				tempc_ptr(AmmoInfo) t_info = ptr_static_cast<AmmoInfo>(info);
				return ptr_new AmmoBloodDisk(t_info);
			}
			break;
		case kWeaponTypeAmmoMeditNeedle:
		case kWeaponTypeAmmoArrow:
		case kWeaponTypeAmmoStick:
		case kWeaponTypeAmmoProd:
			{
				tempc_ptr(AmmoInfo) t_info = ptr_static_cast<AmmoInfo>(info);
				return ptr_new Arrow(t_info);
			}
			break;
		default:
			{
				tempc_ptr(AmmoInfo) t_info = ptr_static_cast<AmmoInfo>(info);
				return ptr_new Ammo(t_info);
			}

			break;
		}
	}

	return NullPtr;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
/// constructor
AmmoBase::AmmoBase(by_ptr(WeaponInfo) info)
	: uid(-1)
	, team(-1)
	, ammoindex(-1)
	, type(-1)
	, is_boost(false)
	, is_dead(false)
	, impact_flyscale(0.f)
	, impact_normal(Vector3::kZero)
	, impact_pos(Vector3::kZero)
	, is_impact(false)
	, is_impact_character(false)
	, is_skip_render(false)
{
	if (info)
	{
		weapon_info = info;
		type = info->weapon_type;
	}
}

AmmoBase::~AmmoBase()
{
}

/// from nx actor
tempc_ptr(AmmoBase) AmmoBase::FromNxActor(NxActor & actor)
{
	Object * obj = (Object*)actor.userData;

	if (obj)
	{
		return ptr_dynamic_cast<AmmoBase>(obj);
	}

	return NullPtr;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
/// constructor
Ammo::Ammo(by_ptr(AmmoInfo) info)
	: AmmoBase(info)
	, actor(NULL)
	, actor2(NULL)
	, sweep_cache(NULL)
	, timer(0.f)
	, maxfly_time(0.f)
	, free_fly_timer(0.f)
	, anglelimit(0.f)
	, physx_update_time(0)
	, fly_joint_id(-1)
	, init_velocity(0.f, 0.f, 0.f)
	, busephysxrot(true)
	, is_player(false)
	, audio_reload(NULL)
{
	ammo_info = info;
}

/// create physx
void Ammo::CreatePhysx()
{
	//NxVec3 diagInertia, mass_pos;
	//NxReal mass = NxComputeConeMass(ammo_info->capsule_radius, ammo_info->capsule_height, 1000.f);
	//NxComputeSphereInertiaTensor(diagInertia, mass, ammo_info->capsule_radius * 0.5f, false);

	//mass_pos = actor->getCMassLocalPosition();
	//mass_pos.y += ammo_info->capsule_height * (1.f / 3.f);
	//actor->setCMassOffsetLocalPosition(mass_pos);
	//actor->setMassSpaceInertiaTensor(diagInertia);
	//actor->setCCDMotionThreshold(0.f);

	is_player = false;

	tempc_ptr(Character) player = gLevel->GetPlayer();
	if (owner && player && owner->uid == player->uid)
	{
		is_player = true;
	}

	switch (type)
	{
	case kWeaponTypeAmmoRocket:
		{
			actor = PhysxSystem::CreateCapsule(position, ammo_info->capsule_height, ammo_info->capsule_radius, team + PhysxSystem::kGroupProjectStart);
			actor->raiseBodyFlag(NX_BF_KINEMATIC);

			actor2 = PhysxSystem::CreateCapsule(position, 0.01f, 0.5f, team + PhysxSystem::kGroupProjectStart);
			actor2->raiseBodyFlag(NX_BF_KINEMATIC);
			actor->setAngularDamping(1.0f);
			actor->setLinearDamping(0.0f);
			//sweep_cache = PhysxSystem::Scene()->createSweepCache();
		}
		break;
	case kWeaponTypeAmmoMeditNeedle:
		{
			actor = PhysxSystem::CreateCapsuleCCD(position, ammo_info->capsule_height, ammo_info->capsule_radius, team + PhysxSystem::kGroupProjectStart);
			if (is_player)
			{
				actor->setContactReportFlags(NX_NOTIFY_ON_START_TOUCH | NX_NOTIFY_FORCES);
				if (!ammo_info->gravity)
					actor->raiseBodyFlag(NX_BF_DISABLE_GRAVITY);
			}
			else
				actor->raiseBodyFlag(NX_BF_KINEMATIC);
			actor->setAngularDamping(1.0f);
			actor->setLinearDamping(0.0f);
		}
		break;
	case kWeaponTypeAmmoGrenade:
		{
			actor = PhysxSystem::CreateCapsuleCCD(position, ammo_info->capsule_height, ammo_info->capsule_radius, team + PhysxSystem::kGroupProjectStart);
			if (is_player)
			{
				actor->setContactReportFlags(NX_NOTIFY_ON_START_TOUCH | NX_NOTIFY_FORCES);
				if (!ammo_info->gravity)
					actor->raiseBodyFlag(NX_BF_DISABLE_GRAVITY);
			}
			else
				actor->raiseBodyFlag(NX_BF_KINEMATIC);
			actor->setAngularDamping(0.0f);
			actor->setLinearDamping(0.0f);
		}
		break;
	case kWeaponTypeAmmoBloodDisk:
		{
			actor = PhysxSystem::CreateCapsuleCCD(position, ammo_info->capsule_height, ammo_info->capsule_radius, PhysxSystem::kBloodDisk);
			if (is_player)
			{
				actor->setContactReportFlags(NX_NOTIFY_ON_START_TOUCH | NX_NOTIFY_FORCES);
				if (!ammo_info->gravity)
					actor->raiseBodyFlag(NX_BF_DISABLE_GRAVITY);
			}
			else
				actor->raiseBodyFlag(NX_BF_KINEMATIC);
			actor->setAngularDamping(0.0f);
			actor->setLinearDamping(0.0f);
		}
		break;
	case kWeaponTypeAmmoStick:
		{
			actor = PhysxSystem::CreateCapsuleCCD(position, ammo_info->capsule_height, ammo_info->capsule_radius, team + PhysxSystem::kGroupProjectStart);
			if (is_player)
			{
				actor->setContactReportFlags(NX_NOTIFY_ON_START_TOUCH | NX_NOTIFY_FORCES);
				if (!ammo_info->gravity)
					actor->raiseBodyFlag(NX_BF_DISABLE_GRAVITY);
			}
			else
				actor->raiseBodyFlag(NX_BF_KINEMATIC);
			actor->setAngularDamping(0.0f);
			actor->setLinearDamping(0.8f);
		}
		break;
	default:
		{
			LogSystem.WriteLinef("Ammo::CreatePhysx() unknow type[%d]", (int)type);
		}
		return;
	}

	if (actor)
		actor->userData = (void*)this;

	if (actor2)
		actor2->userData = (void*)this;

	FMOD_VECTOR vel = {0, 0, 0};
	audio_reload = FmodSystem::Play3DEvent("bj/fx/3d/rocket_fly",(const FMOD_VECTOR &)Vector3(10000,-10000,10000),vel);
}

/// destructor
Ammo::~Ammo()
{
	ReleasePhysx();
	StopEffect();

	if (audio_reload)
	{
		audio_reload->stop();
		audio_reload->release();
	}
}

/// initialize
void Ammo::Initialize(uint team , bool isboost)
{
	static const char szTeam[2] = {'r', 'b'};

	WeaponBase::Initialize();

	this->team = team;
	is_boost = isboost;
	maxfly_time = ammo_info->maxalive_time;

	if (ammo_info->fly_particle.Length() > 0)
	{
		Core::String name = Core::String::Format("%s_%c", ammo_info->fly_particle.Str(), szTeam[team & 1]);
		fly_particle = ptr_new ParticleSystem(name, false);
		
		Core::String boostname = Core::String::Format("%s_%c_b%c", ammo_info->fly_particle.Str(), szTeam[team & 1], szTeam[team & 1]);
		fly_particle_boost = ptr_new ParticleSystem(boostname, false);
	}

	if (skeleton && ammo_info->fly_joint_name.Length() > 0)
	{
		fly_joint_id = skeleton->GetJointId(ammo_info->fly_joint_name);
	}

	free_fly_timer = ammo_info->ammocontrolmode.triggertime;
	anglelimit = ammo_info->ammocontrolmode.anglelimit;
}

void Client::Ammo::ChangeAmmoTeam(uint team)
{
	static const char szTeam[2] = {'r', 'b'};
	if(this->team ==  team)
		return;
	if(!ammo_info)
		return;
	this->team = team;
	StopEffect();

	if (ammo_info->fly_particle.Length() > 0)
	{
		Core::String name = Core::String::Format("%s_%c", ammo_info->fly_particle.Str(), szTeam[team & 1]);
		fly_particle = ptr_new ParticleSystem(name, false);

		Core::String boostname = Core::String::Format("%s_%c_b%c", ammo_info->fly_particle.Str(), szTeam[team & 1], szTeam[team & 1]);
		fly_particle_boost = ptr_new ParticleSystem(boostname, false);
	}
	
	ReleasePhysx();
	CreatePhysx();
	
	if(is_boost)
	{
		if(fly_particle_boost)
			gLevel->AddParticle(fly_particle_boost);
	}
	else
	{
		if(fly_particle)
		gLevel->AddParticle(fly_particle);
	}
}

///
void Ammo::StopEffect()
{
	if(is_boost)
	{
		if(fly_particle_boost)
		{
			fly_particle_boost->Reset();
			fly_particle_boost->SetDead();
		}
	}
	else
	{
		if (fly_particle)
		{
			fly_particle->Reset();
			fly_particle->SetDead();
		}
	}
}

///
void Ammo::SetEffectEnable(bool enable)
{
	if(is_boost)
	{
		if (fly_particle_boost)
		{
			fly_particle_boost->SetEnable(enable);
		}
	}
	else
	{
		if (fly_particle)
		{
			fly_particle->SetEnable(enable);
		}
	}
}

/// update physx
void Ammo::UpdatePhysx(float frame_time)
{
	if (!is_dead && actor)
	{
		if (!is_impact && GetOwner() == gLevel->GetPlayer() )
		{
			Vector3 velocity_now;
			GetVelocity(velocity_now);
			Core::Quaternion rot(Vector3(0, 1, 0), velocity_now);
			SetRotation(rot);
		}

		switch (type)
		{
		case kWeaponTypeAmmoMeditNeedle:
			break;
		default:
			break;
		}
	}
}

void Ammo::Update(float frame_time)
{
	timer -= frame_time;
	if (is_player)
	{
		is_dead = is_dead | (timer <= 0.f);
	}
	else
	{
		is_dead = is_dead | (timer < -timer);
	}

	WeaponBase::Update(frame_time);

	if (!is_dead || sync_data.Size() > 1)
	{
		Vector3 pos;
		Quaternion rot;
		if(is_boost)
		{
			if(fly_particle_boost)
			{
				if (GetJointInfo(fly_joint_id, &pos, &rot))
				{
					fly_particle_boost->SetPosition(pos);
					fly_particle_boost->SetRotation(rot);
				}
			}
		}
		else
		{
			if(fly_particle)
			{
				if (GetJointInfo(fly_joint_id, &pos, &rot))
				{
					fly_particle->SetPosition(pos);
					fly_particle->SetRotation(rot);
				}
			}
		}
	}

	

	if (is_dead)
	{
		ReleasePhysx();
	}
	if (audio_reload)
	{
		FMOD_VECTOR vel = {0, 0, 0};
		FmodSystem::Update3DEventPosition(audio_reload,(const FMOD_VECTOR &)GetPosition(),vel);
	}	
}

void Ammo::OnRender(float frame_time)
{
}

void Ammo::TimeStepUpdate(float frame_time)
{
	if (is_player && ammo_info)
	{
		if (!is_dead && actor)
		{
			switch (type)
			{
			case kWeaponTypeAmmoRocket:
				{
					NxSweepQueryHit hit, hit2;
		
					Vector3 velocity_now;
					GetVelocity(velocity_now);

					Vector3 velocity = velocity_now * frame_time /*time_step*/;

					NxU32 num = actor->linearSweep((const NxVec3 &)velocity, NX_SF_STATICS | NX_SF_DYNAMICS, NULL, 1, &hit, NULL/*, sweep_cache*/);
					NxU32 num2 = actor2->linearSweep((const NxVec3 &)velocity, NX_SF_DYNAMICS, NULL, 1, &hit2, NULL/*, sweep_cache*/);

					if (num == 0 && num2 == 0)
					{
						Vector3 pos = GetPosition() + velocity;
						SetPosition(pos);
					}
					else
					{
						NxSweepQueryHit *pHit = NULL;

						if (num > 0 && num2 > 0)
						{
							pHit = hit.t < hit2.t ? &hit : &hit2;
						}
						else
						{
							pHit = num > 0 ? &hit : &hit2;
						}

						SetPosition((const Core::Vector3&)pHit->point);
						OnImpact(pHit->hitShape->getActor(), (const Core::Vector3&)pHit->normal, (const Core::Vector3&)pHit->point);
					}
				}
				break;
			default:
				break;
			}
		}

		free_fly_timer -= frame_time;
		free_fly_timer = Max(0.f, free_fly_timer);

		float change_ratio = 1.f;
		if (ammo_info->ammocontrolmode.triggertime > 0.f)
		{
			change_ratio = (ammo_info->ammocontrolmode.triggertime - free_fly_timer) / ammo_info->ammocontrolmode.triggertime;
			change_ratio = Clamp(Pow(change_ratio, 2.f), 0.f, 1.f);
		}

		if (targetplayer && change_ratio > 0.f && targetplayer->GetTeam() < 2 && !targetplayer->IsDied() && targetplayer->GetTeam() != team)
		{
			Vector3 pos_locked = targetplayer->GetPosition();
			pos_locked.y += targetplayer->GetHeight() * 1.0f;

			const Vector3 & pos_now = GetPosition();

			Vector3 velocity_new = pos_locked - pos_now;

			Vector3 velocity_now;
			GetVelocity(velocity_now);
			float length = velocity_now.Length();

#if 0
			{
				velocity_new.Normalize();
				velocity_new *= anglelimit * change_ratio * frame_time;
				velocity_new += velocity_now;
				velocity_new.Normalize();
				velocity_new *= length;
			}
#else
			{
				Vector3 rot_axis;
				float rot_angle;
				Quaternion rot_try(velocity_now, velocity_new);
				float anglelimit_rad = ammo_info->ammocontrolmode.anglelimit * change_ratio * frame_time * DEG2RAD;

				rot_try.ToAxisAngle(rot_axis, rot_angle);
				if (Abs(rot_angle) > anglelimit_rad)
				{
					if (rot_angle >= 0.f)
						rot_angle = anglelimit_rad;
					else
						rot_angle = -anglelimit_rad;

					rot_try.SetAxisAngle(rot_axis, rot_angle);
				}

				TransformCoord(velocity_new, velocity_now, rot_try);
				velocity_new.Normalize();
				velocity_new *= length;
			}
#endif

			SetVelocity(velocity_new);
			Quaternion rot(Vector3(0, 1, 0), velocity_new);
			SetRotation(rot);
		}
	}
}

/// Impact
void Ammo::OnImpact(NxActor &hit_actor, const Core::Vector3 &hit_normal, const Core::Vector3 &hit_point)
{
	tempc_ptr(Character) player = gLevel->GetPlayer();

	if (!is_player)
		return;

	impact_normal = hit_normal;
	impact_pos = hit_point;

	float fly_time = maxfly_time - Core::Max(timer, 0.f);

	if (fly_time <= ammo_info->dmg_modify_timer_min)
	{
		impact_flyscale = ammo_info->dmg_modify_min;
	}
	else if (fly_time >= ammo_info->dmg_modify_timer_max)
	{
		impact_flyscale = ammo_info->dmg_modify_max;
	}
	else
	{
		float t = (fly_time - ammo_info->dmg_modify_timer_min) / (ammo_info->dmg_modify_timer_max - ammo_info->dmg_modify_timer_min);
		impact_flyscale = ammo_info->dmg_modify_min + t * (ammo_info->dmg_modify_max - ammo_info->dmg_modify_min);
	}

	is_impact_character = false;
	tempc_ptr(Character) c = Character::FromNxActor(hit_actor);
	tempc_ptr(DummyObject) dummy = DummyObject::FromNxActor(hit_actor);
	bool is_impact_vehicle = false;
	bool is_impact_dummy = false;

	if (c)
	{
		is_impact_character = true;
	}

	
	if (!is_impact_character)
	{
		tempc_ptr(Vehicle) vehicle = Vehicle::FromNxActor(hit_actor);
		if (vehicle) 
			is_impact_vehicle = true;
	}

	
	if (!is_impact_vehicle )
	{
		if (dummy) 
			is_impact_dummy = true;
	}
	
	switch (type)
	{
	case kWeaponTypeAmmoRocket:
		{
			StopPhysx();
			StopEffect();
			
			is_dead = true;
		}
		break;

	case kWeaponTypeAmmoMeditNeedle:
		{
			StopPhysx();
			StopEffect();

			if (is_impact_character)
			{
				is_dead = true;

				//my MeditNeedle
				if (gGame->channel_connection)
				{
					bool teamhurt = (c->GetTeam() != team);
					gGame->channel_connection->ExplodeAmmoHurt(ammoindex, c->uid, ammo_info, 0.f, impact_flyscale, position, teamhurt, kCharacterPartTorso, ammo_info->hurt_rate);
				}
			}
			else if(is_impact_dummy)
			{
				is_dead = true;
				//my MeditNeedle
				if (gGame->channel_connection)
				{
					tempc_ptr(Character) owner = gLevel->GetCharacter(dummy->owner_id);
					if(owner)
					{
						bool teamhurt = (owner->GetTeam() != team);
						gGame->channel_connection->ExplodeAmmoHurtDummy(ammoindex, dummy->dummyobjectinfo->dummy_id, ammo_info, 0.f, impact_flyscale, position, teamhurt, ammo_info->hurt_rate);
					}
					else if(dummy->owner_id == 0)
					{
						gGame->channel_connection->ExplodeAmmoHurtDummy(ammoindex, dummy->dummyobjectinfo->dummy_id, ammo_info, 0.f, impact_flyscale, position, false, ammo_info->hurt_rate);
					}
				}
			}
			else if (is_impact_vehicle)
			{
				is_dead = true;
			}
		}
		break;

	case kWeaponTypeAmmoGrenade:
	case kWeaponTypeAmmoBloodDisk:
		{
			//NxVec3 vct = actor->getLinearVelocity();
			//vct.x = vct.x * 1.3;
			//actor->setLinearVelocity(vct);
			//actor->raiseBodyFlag(NX_BF_KINEMATIC);
			if(!is_impact && is_impact_character)
			{
				is_dead = true;
			}
		}
		break;
	default:
		break;
	}

	Core::Vector3 offset;

	Core::TransformCoord(offset, Vector3(0, 1, 0), GetRotation());
	offset.Normalize();
	offset *= ammo_info->capsule_height * 0.5f;

	SetPosition(impact_pos - offset);

	is_impact = true;
}

void Ammo::UpdateSyncData(float frame_time)
{
	if (is_player)
		return;

	// no sync data, return
	if (sync_data.Empty())
		return;

	AmmoSyncData data;
	Vector3	vel;

	// remove unused data
	while (sync_data.Size() > 1 && sync_data[1].time <= sync_time)
		sync_data.PopFront();

	if (sync_data.Size() > 1)
	{
		AmmoSyncData & data1 = sync_data[0];
		AmmoSyncData & data2 = sync_data[1];

		float s = Clamp((sync_time - data1.time) / (data2.time - data1.time), 0, 1);

		Lerp(data.position, data1.position, data2.position, s);
		Core::Slerp(data.rotation, data1.rotation, data2.rotation, s);

		// calculate velocity
		vel = (data.position - GetPosition()) / frame_time;

		// update time
		float delay_time = sync_data.Back().time - sync_time;

		// scale time when delay time > 0.05
		if (delay_time > 0.1f)
			frame_time *= 1 + (delay_time - 0.1f);

		sync_time += frame_time;

		//LogSystem.WriteLinef("Ammo::UpdateSyncData() : %f", sync_time);
	}
	else
	{
		data = sync_data[0];
		vel = Vector3::kZero;
		sync_time = sync_data[0].time;
	}

	SetPosition(data.position);
	SetRotation(data.rotation);
}

void Ammo::AddSyncData(byte time, const Core::Vector3 &position, const Core::Vector3 &direction)
{
	if (!sync_data.Empty())
	{
		AmmoSyncData sync = sync_data.Back();

		sync.time += (float)time / 255.f;
		sync.position = position;
		sync.rotation.SetZXY(direction);

		sync_data.PushBack(sync);
	}
}

bool Ammo::HasSyncData()
{
	//return !(sync_data.Size() <= 1);
	return sync_data.Size() > 1;
}

/// get position
const Vector3 & Ammo::GetPosition()
{
	if (actor)
		position = (const Vector3 &)actor->getGlobalPosition();
	return position;
}

/// set position
void Ammo::SetPosition(const Core::Vector3 & pos)
{
	if (actor)
		actor->setGlobalPosition((const NxVec3 &)pos);

	if (actor2)
	{
		Core::Vector3 off = init_velocity;

		off.Normalize();
		actor2->setGlobalPosition((const NxVec3 &)(pos + (off * -0.5f)));
	}

	position = pos;
}


/// get rotation
const Core::Quaternion & Ammo::GetRotation()
{
	if (actor && busephysxrot)
		rotation = (const Quaternion &)actor->getGlobalOrientationQuat();

	return rotation;
}

/// set rotation
void Ammo::SetRotation(const Core::Quaternion & rot)
{
	if (actor)
		actor->setGlobalOrientationQuat((const NxQuat &)rot);

	if (actor2)
		actor2->setGlobalOrientationQuat((const NxQuat &)rot);

	rotation = rot;
}

/// launch out
void Ammo::LaunchOut(const Core::Vector3 & velocity, by_ptr(Character) locked_c)
{
	timer = maxfly_time = ammo_info->maxalive_time;
	targetplayer = locked_c;

	if (is_player)
	{
		SetVelocity(velocity);

		//Core::Vector3 angvelocity = velocity;
		//angvelocity.x = 0;
		//actor->setAngularVelocity((const NxVec3 &)angvelocity * 3);
	}

	if(is_boost)
	{
		if (fly_particle_boost)
		{
			Vector3 pos;
			Quaternion rot;
			if (GetJointInfo(fly_joint_id, &pos, &rot))
			{
				fly_particle_boost->SetPosition(pos);
				fly_particle_boost->SetRotation(rot);
			}

			gLevel->AddParticle(fly_particle_boost);
		}
	}
	else
	{
		if (fly_particle)
		{
			Vector3 pos;
			Quaternion rot;
			if (GetJointInfo(fly_joint_id, &pos, &rot))
			{
				fly_particle->SetPosition(pos);
				fly_particle->SetRotation(rot);
			}

			gLevel->AddParticle(fly_particle);
		}
	}

	{
		sync_time = 0;
		sync_data.Clear();

		AmmoSyncData & sync = sync_data.PushBack();

		sync.time = 0;
		sync.position = GetPosition();
		sync.rotation = GetRotation();
	}
}

/// GetJointInfo
bool Ammo::GetJointInfo(int joint_id, Core::Vector3 *pos, Core::Quaternion *rot)
{
	if (skeleton)
	{
		if (joint_id >= 0)
		{
			const Transform & transform = GetPose()->GetJointModelPose(joint_id);

			if (pos)
				*pos = GetPosition() + transform.position * GetRotation();

			if (rot)
				*rot = transform.rotation * GetRotation();

			return true;
		}
	}

	return false;
}

void Ammo::ReleasePhysx()
{
	if (actor)
	{
		PhysxSystem::ReleaseActor(*actor);
		actor = NULL;
	}

	if (actor2)
	{
		PhysxSystem::ReleaseActor(*actor2);
		actor2 = NULL;
	}

	if (sweep_cache)
	{
		PhysxSystem::Scene()->releaseSweepCache(sweep_cache);
		sweep_cache = NULL;
	}
}

void Ammo::StopPhysx()
{
	if (actor)
	{
		actor->raiseBodyFlag(NX_BF_KINEMATIC);
	}

	if (actor2)
	{
		actor2->raiseBodyFlag(NX_BF_KINEMATIC);
	}
}

bool Ammo::SetVelocity( const Core::Vector3 &velocity )
{
	init_velocity = velocity;

	if (actor && actor->readBodyFlag(NX_BF_KINEMATIC) == false)
	{
		actor->setLinearVelocity((const NxVec3 &)velocity);
	}

	return true;
}

bool Ammo::GetVelocity(Core::Vector3 &velocity)
{
	if (actor && actor->readBodyFlag(NX_BF_KINEMATIC) == false)
	{
		NxVec3 vct = actor->getLinearVelocity();

		velocity.x = vct.x;
		velocity.y = vct.y;
		velocity.z = vct.z;
	}
	else
	{
		velocity = init_velocity;
	}

	return true;
}

bool Ammo::AddForceFromUpRight(float UAngle, float RAngle)
{
	Core::Vector3 velocity;
	if (!GetVelocity(velocity))
	{
		return false;
	}

	Core::Matrix44 rotmtx(gGame->camera->rotation);
	Vector3 up = rotmtx.y.xyz;
	Vector3 right = rotmtx.x.xyz;
	Core::Quaternion rotup(up, UAngle);
	Core::Quaternion rotright(right, RAngle);
	Core::Quaternion transform = rotup * rotright;
	velocity = velocity * transform;

	SetRotation(rotation * transform);

	gGame->camera->rotation = gGame->camera->rotation * transform;

	if (gGame->input->IsKeyDown(KC_PGUP))
	{
		F32 len = velocity.Length();
		velocity.Normalize();
		len += 20.f * Task::GetFrameTime();
		velocity *= len;
	}

	if (gGame->input->IsKeyDown(KC_PGDOWN))
	{
		F32 len = velocity.Length();
		velocity.Normalize();
		len -= 20.f * Task::GetFrameTime();
		if (len <= 0.f) len = 0.01f;
		velocity *= len;
	}

	if (!SetVelocity(velocity))
	{
		return false;
	}
	
	return true;
}

void Ammo::SetStickable(bool bstick)
{
	if(actor)
	{
		if(bstick)
		{
			actor->setLinearDamping(5000.f);
			actor->setAngularDamping(5000.f);
			actor->raiseBodyFlag(NX_BF_DISABLE_GRAVITY);
			actor->setGroup(1 << PhysxSystem::kStatic);
			busephysxrot = false;
		}
		else
		{
			actor->setLinearDamping(0.001f);
			actor->setAngularDamping(1.f);
			actor->clearBodyFlag(NX_BF_DISABLE_GRAVITY);
			actor->setGroup(1 << (team + PhysxSystem::kGroupProjectStart));
			busephysxrot = true;
		}
	}
}

/// from nx actor
tempc_ptr(Ammo) Ammo::FromNxActor(NxActor & actor)
{
	Object * obj = (Object*)actor.userData;

	if (obj)
	{
		return ptr_dynamic_cast<Ammo>(obj);
	}

	return NullPtr;
}

Arrow::Arrow(by_ptr(AmmoInfo) info)
: AmmoBase(info)
, actor(NULL)
, sweep_cache(NULL)
, timer(0.f)
, maxfly_time(0.f)
, free_fly_timer(0.f)
, anglelimit(0.f)
, physx_update_time(0)
, fly_joint_id(-1)
, init_velocity(0.f, 0.f, 0.f)
, busephysxrot(true)
, is_player(false)
, hit_jointID(-1)
, body_offset(Vector3::kZero)
, hit_character_uid(-1)
, inverse_rotation(Quaternion::kIdentity)

{
	ammo_info = info;
}



void Arrow::Initialize(uint team , bool isboost)
{
	static const char szTeam[2] = {'r', 'b'};

	WeaponBase::Initialize();

	this->team = team;
	is_boost = isboost;
	maxfly_time = ammo_info->maxalive_time;

	if (ammo_info->fly_particle.Length() > 0)
	{
		Core::String name = Core::String::Format("%s_%c", ammo_info->fly_particle.Str(), szTeam[team & 1]);
		fly_particle = ptr_new ParticleSystem(name, false);

		Core::String boostname = Core::String::Format("%s_%c_b%c", ammo_info->fly_particle.Str(), szTeam[team & 1], szTeam[team & 1]);
		fly_particle_boost = ptr_new ParticleSystem(boostname, false);
	}

	if(ammo_info->stick_particle.Length() > 0)
	{
		Core::String name = Core::String::Format("%s_%c", ammo_info->stick_particle.Str(), szTeam[team & 1]);
		stick_particle = ptr_new ParticleSystem(name, false);
	}

	if (skeleton && ammo_info->fly_joint_name.Length() > 0)
	{
		fly_joint_id = skeleton->GetJointId(ammo_info->fly_joint_name);
	}

	free_fly_timer = ammo_info->ammocontrolmode.triggertime;
	anglelimit = ammo_info->ammocontrolmode.anglelimit;
}

void Arrow::CreatePhysx()
{
	is_player = false;

	tempc_ptr(Character) player = gLevel->GetPlayer();
	if (owner && player && owner->uid == player->uid)
	{
		is_player = true;
	}

	actor = PhysxSystem::CreateCapsule(position, ammo_info->capsule_height, ammo_info->capsule_radius, team + PhysxSystem::kGroupProjectStart);
	actor->raiseBodyFlag(NX_BF_KINEMATIC);

	actor->setAngularDamping(1.0f);
	actor->setLinearDamping(0.0f);

	if (actor)
		actor->userData = (void*)this;
}

/// destructor
Arrow::~Arrow()
{
	
}

void Arrow::StopEffect()
{
	if(is_boost)
	{
		if(fly_particle_boost)
		{
			//fly_particle_boost->Reset();
			fly_particle_boost->SetDead();
		}
	}
	else
	{
		if (fly_particle)
		{
			//fly_particle->Reset();
			fly_particle->SetDead();
		}
	}
	if(stick_particle)
	{
		//stick_particle->Reset();
		stick_particle->SetDead();
	}
}

///
void Arrow::SetEffectEnable(bool enable)
{
	if(is_boost)
	{
		if (fly_particle_boost)
		{
			fly_particle_boost->SetEnable(enable);
		}
	}
	else
	{
		if (fly_particle)
		{
			fly_particle->SetEnable(enable);
		}
	}
}

void Arrow::Update(float frame_time)
{
	timer -= frame_time;
	if (is_player)
	{
		is_dead = is_dead | (timer <= 0.f);
	}
	else
	{
		is_dead = is_dead | (timer < -timer);
	}

	WeaponBase::Update(frame_time);

	if (!is_dead)
	{
		Vector3 pos;
		Quaternion rot;
		if(is_boost)
		{
			if(fly_particle_boost)
			{
				if (GetJointInfo(fly_joint_id, &pos, &rot))
				{
					fly_particle_boost->SetPosition(pos);
					fly_particle_boost->SetRotation(rot);
				}
			}
		}
		else
		{
			if(fly_particle)
			{
				if (GetJointInfo(fly_joint_id, &pos, &rot))
				{
					fly_particle->SetPosition(pos);
					fly_particle->SetRotation(rot);
				}
			}
		}
	}

	{
		Vector3 pos;
		Quaternion rot;
		if(stick_particle)
		{
			if (GetJointInfo(fly_joint_id, &pos, &rot))
			{
				stick_particle->SetPosition(pos);
				stick_particle->SetRotation(rot);
			}
		}
	}

	if (is_dead)
	{
		if (type == kWeaponTypeAmmoProd)
		{
			tempc_ptr(Character) player = gLevel->GetCharacter(hit_character_uid);
			if (player)
			{
				for (int i = 0; i < (int)player->prod_list.Size(); ++i)
				{
					if (player->prod_list[i] == this)
					{
						player->prod_list.RemoveAt(i);
					}
				}
			}
		}
		ReleasePhysx();

		if(stick_particle)
		{
			stick_particle->Reset();
			stick_particle->SetDead();
		}
	}
}

const Core::Vector3 & Arrow::GetPosition()
{
	if (actor)
		position = (const Vector3 &)actor->getGlobalPosition();
	return position;
}

void Arrow::SetPosition(const Core::Vector3 & pos)
{
	if (actor)
		actor->setGlobalPosition((const NxVec3 &)pos);

	position = pos;
}

const Core::Quaternion & Arrow::GetRotation()
{
	if (actor && busephysxrot)
		rotation = (const Quaternion &)actor->getGlobalOrientationQuat();

	return rotation;
}

void Arrow::SetRotation(const Core::Quaternion & rot)
{
	if (actor)
		actor->setGlobalOrientationQuat((const NxQuat &)rot);

	rotation = rot;
}

void Arrow::UpdatePhysx(float frame_time)
{
	if (!is_dead && actor)
	{
		if (!is_impact && GetOwner() == gLevel->GetPlayer() )
		{
			Vector3 velocity_now;
			GetVelocity(velocity_now);
			Core::Quaternion rot(Vector3(0, 1, 0), velocity_now);
			SetRotation(rot);
		}
	}
}

bool Arrow::GetVelocity(Core::Vector3 &velocity)
{
	if (actor && actor->readBodyFlag(NX_BF_KINEMATIC) == false)
	{
		NxVec3 vct = actor->getLinearVelocity();

		velocity.x = vct.x;
		velocity.y = vct.y;
		velocity.z = vct.z;
	}
	else
	{
		velocity = init_velocity;
	}

	return true;
}

void Arrow::OnRender(float frame_time)
{
	if(is_skip_render)
	{
		SetVisible(false);
	}
	else
	{
		if(is_impact)
		{
			tempc_ptr(Character) c = gLevel->GetCharacter(hit_character_uid);

			if(c && c->invincible_time > 0.f)
				is_dead = true;

			if(( !c && is_impact_character))
				is_dead = true;

			if(c && c->GetViewMode() == Character::kThirdPerson)
			{
				SetVisible(true);

				Vector3 gPos;
				Quaternion gRot;

				Vector3 world_pos;
				Quaternion world_rot;

				if (c->GetThirdPerson().GetJointInfo(hit_jointID, world_pos, world_rot))
				{
					gPos = body_offset * world_rot + world_pos;
					gRot = inverse_rotation * world_rot;

					SetPosition(gPos);
					SetRotation(gRot);
				}
			}
			else if(c && c->GetViewMode() == Character::kFirstPerson)
			{
				SetVisible(false);
				StopEffect();
			}
		}
	}
}

void Arrow::TimeStepUpdate(float frame_time)
{
	if (ammo_info && !is_impact)
	{
		NxSweepQueryHit hit;

		if (!is_dead && actor && !is_skip_render)
		{		
			Vector3 velocity_now;

			GetVelocity(velocity_now);
			float gravity = (float)ammo_info->gravity;
			//gravity += ammo_info->gravity_addon;
			velocity_now.y -= gravity / 100.f;
			SetVelocity(velocity_now);

			Vector3 velocity = velocity_now * frame_time;

			NxU32 num = actor->linearSweep((const NxVec3 &)velocity, NX_SF_STATICS | NX_SF_DYNAMICS, NULL, 1,&hit, NULL/*, sweep_cache*/);

			if (num == 0)
			{
				Vector3 pos = GetPosition() + velocity;
				SetPosition(pos);
			}
			else
			{
				NxSweepQueryHit *phit = &hit;
				SetPosition((const Core::Vector3&)phit->point);
				OnImpact(phit->hitShape->getActor(), (const Core::Vector3&)phit->normal, (const Core::Vector3&)phit->point);
			}
		}
		if (type == kWeaponTypeAmmoProd)
		{
			float change_ratio = 1.f;
			if (ammo_info->ammocontrolmode.triggertime > 0.f)
			{
				change_ratio = (ammo_info->ammocontrolmode.triggertime - free_fly_timer) / ammo_info->ammocontrolmode.triggertime;
				change_ratio = Clamp(Pow(change_ratio, 2.f), 0.f, 1.f);
			}
			if (targetplayer && change_ratio > 0.f && targetplayer->GetTeam() < 2 && !targetplayer->IsDied() && targetplayer->GetTeam() != team)
			{
				Vector3 pos_locked = targetplayer->GetPosition();
				pos_locked.y += targetplayer->GetHeight() * 1.0f;

				const Vector3 & pos_now = GetPosition();

				Vector3 velocity_new = pos_locked - pos_now;

				Vector3 velocity_now;
				GetVelocity(velocity_now);
				float length = velocity_now.Length();

#if 0
				{
					velocity_new.Normalize();
					velocity_new *= anglelimit * change_ratio * frame_time;
					velocity_new += velocity_now;
					velocity_new.Normalize();
					velocity_new *= length;
				}
#else
				{
					Vector3 rot_axis;
					float rot_angle;
					Quaternion rot_try(velocity_now, velocity_new);
					float anglelimit_rad = ammo_info->ammocontrolmode.anglelimit * change_ratio * frame_time * DEG2RAD;

					rot_try.ToAxisAngle(rot_axis, rot_angle);
					if (Abs(rot_angle) > anglelimit_rad)
					{
						if (rot_angle >= 0.f)
							rot_angle = anglelimit_rad;
						else
							rot_angle = -anglelimit_rad;

						rot_try.SetAxisAngle(rot_axis, rot_angle);
					}

					TransformCoord(velocity_new, velocity_now, rot_try);
					velocity_new.Normalize();
					velocity_new *= length;
				}
#endif

				SetVelocity(velocity_new);
				Quaternion rot(Vector3(0, 1, 0), velocity_new);
				SetRotation(rot);
			}
		}
	}				
} 

void Arrow::OnImpact(NxActor &hit_actor, const Core::Vector3 &hit_normal, const Core::Vector3 &hit_point)
{
	tempc_ptr(Character) player = gLevel->GetPlayer();
	tempc_ptr(Character) c = Character::FromNxActor(hit_actor);

	tempc_ptr(DummyObject) dummy = DummyObject::FromNxActor(hit_actor);
	
	if(player && c && c == player)
	{
		if(type == kWeaponTypeAmmoStick || type == kWeaponTypeAmmoProd)
		{
			is_skip_render = true;
			StopEffect();
			StopPhysx();
		}
		return;
	}
	/*else if(c)
	{
		if(type == kWeaponTypeAmmoStick || type == kWeaponTypeAmmoProd)
		{
			StopFlyEffect();
		}
	}*/

	impact_normal = hit_normal;
	impact_pos = hit_point;

	float fly_time = maxfly_time - Core::Max(timer, 0.f);

	if (fly_time <= ammo_info->dmg_modify_timer_min)
	{
		impact_flyscale = ammo_info->dmg_modify_min;
	}
	else if (fly_time >= ammo_info->dmg_modify_timer_max)
	{
		impact_flyscale = ammo_info->dmg_modify_max;
	}
	else
	{
		float t = (fly_time - ammo_info->dmg_modify_timer_min) / (ammo_info->dmg_modify_timer_max - ammo_info->dmg_modify_timer_min);
		impact_flyscale = ammo_info->dmg_modify_min + t * (ammo_info->dmg_modify_max - ammo_info->dmg_modify_min);
	}

	is_impact_character = false;
	byte part = kCharacterPartTorso;

	if (c)
	{
		is_impact_character = true;
		
		hit_character_uid = c->uid;
		part = c->GetActorId(&hit_actor);
		hit_jointID = c->GetJointIdFromActorId(part);

		Vector3 world_pos;
		Quaternion world_rot;

		if (c->GetThirdPerson().GetJointInfo(hit_jointID, world_pos, world_rot))
		{
			world_rot.Inverse();
			inverse_rotation = world_rot;

			body_offset = (impact_pos - world_pos ) * inverse_rotation;
			inverse_rotation = GetRotation() * inverse_rotation;
		}
		if (type == kWeaponTypeAmmoProd)
		{
			timer = maxfly_time;
			c->prod_list.Add(this);
			if (c->prod_list.Size() >= 6)
			{
				for(int i = 0; i < (int)c->prod_list.Size();++i)
				{
					c->prod_list[i]->timer = 0.f;
				}
				c->prod_list.Clear();
				bool teamhurt = (gLevel->player_manager->player->GetTeam() != team);
				const Array<sharedc_ptr(Character)> & characters = gLevel->GetCharacters();
				float distance = 0.f;
				for (U32 i = 0; i < characters.Size(); i++)
				{
					if (characters[i])
					{
						if(!ammo_info->ignorewall)
						{
							if (characters[i]->CheckGrenade(GetPosition(), distance) && distance < 3.f)
								gGame->channel_connection->ExplodeProdHurt(ammoindex, characters[i]->uid, ammo_info, teamhurt, kCharacterPartTorso);
						}
						else
						{
							Vector3 vctdistance = GetPosition() - characters[i]->GetPosition();
							distance =vctdistance.Length();
							gGame->channel_connection->ExplodeProdHurt(ammoindex, characters[i]->uid, ammo_info, teamhurt, kCharacterPartTorso);
						}
					}
				}
			}
		}
	}

	bool is_impact_vehicle = false;
	if (!is_impact_character)
	{
		tempc_ptr(Vehicle) vehicle = Vehicle::FromNxActor(hit_actor);
		if (vehicle) is_impact_vehicle = true;
	}
	
	bool is_impact_dummy = false;
	if (!is_impact_vehicle )
	{
		if (dummy) 
			is_impact_dummy = true;
	}
	
	tempc_ptr(GateBase) gatebase = GateBase::FromNxActor(hit_actor);
	if(gatebase) is_dead = true;

	StopPhysx();
	StopEffect();

	if (stick_particle)
	{
		gLevel->AddParticle(stick_particle);
		stick_particle->SetEnable(true);
	}

	if(type != kWeaponTypeAmmoStick)
	{
		if (is_impact_character)
		{
			//is_dead = true;

			//my MeditNeedle
			if (gGame->channel_connection && is_player)
			{
				bool teamhurt = (c->GetTeam() != team);
				gGame->channel_connection->ExplodeAmmoHurt(ammoindex, c->uid, ammo_info, 0.f, impact_flyscale, position, teamhurt ,kCharacterPartTorso, ammo_info->hurt_rate);

			}
		}
		else if (is_impact_vehicle)
		{
			is_dead = true;
		}
		else if(is_impact_dummy)
		{
			is_dead = true;

			if (gGame->channel_connection)
			{	
				tempc_ptr(Character) owner = gLevel->GetCharacter(dummy->owner_id);
				if(owner)
				{
					bool teamhurt = (owner->GetTeam() != team);
					gGame->channel_connection->ExplodeAmmoHurtDummy(ammoindex, dummy->dummyobjectinfo->dummy_id, ammo_info, 0.f, impact_flyscale, position, teamhurt, ammo_info->hurt_rate);
				}
				else if(dummy->owner_id == 0)
				{
					gGame->channel_connection->ExplodeAmmoHurtDummy(ammoindex, dummy->dummyobjectinfo->dummy_id, ammo_info, 0.f, impact_flyscale, position, false, ammo_info->hurt_rate);
				}
				
				
			}
		}
	}
	else
	{
		if (is_impact_vehicle)
		{
			is_dead = true;
		}
		else if(is_impact_dummy)
		{
			is_dead = true;
		}
	}

	SetPosition(impact_pos);
	is_impact = true;

	return;
}

void Arrow::UpdateSyncData(float frame_time)
{
	if (is_player)
		return;

	// no sync data, return
	if (sync_data.Empty())
		return;

	AmmoSyncData data;
	Vector3	vel;

	// remove unused data
	while (sync_data.Size() > 1 && sync_data[1].time <= sync_time)
		sync_data.PopFront();

	if (sync_data.Size() > 1)
	{
		AmmoSyncData & data1 = sync_data[0];
		AmmoSyncData & data2 = sync_data[1];

		float s = Clamp((sync_time - data1.time) / (data2.time - data1.time), 0, 1);

		Lerp(data.position, data1.position, data2.position, s);
		Core::Slerp(data.rotation, data1.rotation, data2.rotation, s);

		// calculate velocity
		vel = (data.position - GetPosition()) / frame_time;

		// update time
		float delay_time = sync_data.Back().time - sync_time;

		// scale time when delay time > 0.05
		if (delay_time > 0.1f)
			frame_time *= 1 + (delay_time - 0.1f);

		sync_time += frame_time;

		//LogSystem.WriteLinef("Ammo::UpdateSyncData() : %f", sync_time);
	}
	else
	{
		data = sync_data[0];
		vel = Vector3::kZero;
		sync_time = sync_data[0].time;
	}

	SetPosition(data.position);
	SetRotation(data.rotation);
	return;
}

void Arrow::AddSyncData(byte time, const Core::Vector3 &position, const Core::Vector3 &direction)
{
	if (!sync_data.Empty())
	{
		AmmoSyncData sync = sync_data.Back();

		sync.time += (float)time / 255.f;
		sync.position = position;
		sync.rotation.SetZXY(direction);

		sync_data.PushBack(sync);
	}
	return;
}

bool Arrow::HasSyncData()
{
	return sync_data.Size() > 1;
}

void Arrow::ChangeAmmoTeam(uint team)
{
	return;
}

void Arrow::LaunchOut(const Core::Vector3 & velocity, by_ptr(Character) locked_c)
{
	timer = maxfly_time = ammo_info->maxalive_time;
	targetplayer = locked_c;
	
	Vector3 v = velocity * ammo_info->hurt_rate;
	
	SetVelocity(v);

	if(is_boost)
	{
		if (fly_particle_boost)
		{
			Vector3 pos;
			Quaternion rot;
			if (GetJointInfo(fly_joint_id, &pos, &rot))
			{
				fly_particle_boost->SetPosition(pos);
				fly_particle_boost->SetRotation(rot);
			}

			gLevel->AddParticle(fly_particle_boost);
		}
	}
	else
	{
		if (fly_particle)
		{
			Vector3 pos;
			Quaternion rot;
			if (GetJointInfo(fly_joint_id, &pos, &rot))
			{
				fly_particle->SetPosition(pos);
				fly_particle->SetRotation(rot);
			}

			gLevel->AddParticle(fly_particle);
		}
	}
	if (type == kWeaponTypeAmmoProd)
	{
		sync_time = 0;
		sync_data.Clear();

		AmmoSyncData & sync = sync_data.PushBack();

		sync.time = 0;
		sync.position = GetPosition();
		sync.rotation = GetRotation();
	}
}

bool Arrow::SetVelocity( const Core::Vector3 &velocity )
{
	init_velocity = velocity;

	if (actor && actor->readBodyFlag(NX_BF_KINEMATIC) == false)
	{
		actor->setLinearVelocity((const NxVec3 &)velocity);
	}

	return true;
}

bool Arrow::GetJointInfo(int joint_id, Core::Vector3 *pos, Core::Quaternion *rot)
{
	if (skeleton)
	{
		if (joint_id >= 0)
		{
			const Transform & transform = GetPose()->GetJointModelPose(joint_id);

			if (pos)
				*pos = GetPosition() + transform.position * GetRotation();

			if (rot)
				*rot = transform.rotation * GetRotation();

			return true;
		}
	}

	return false;
}

void Arrow::StopPhysx()
{
	if (actor)
	{
		actor->raiseBodyFlag(NX_BF_KINEMATIC);
		NxShape* shape =  actor->getShapes()[0];
		if (shape)
			shape->setGroup(PhysxSystem::kNone);
	}
}

void Arrow::ReleasePhysx()
{
	if (actor)
	{
		PhysxSystem::ReleaseActor(*actor);
		actor = NULL;
	}

	if (sweep_cache)
	{
		PhysxSystem::Scene()->releaseSweepCache(sweep_cache);
		sweep_cache = NULL;
	}
}

AmmoGrenade::AmmoGrenade(by_ptr(AmmoInfo) info)
: AmmoBase(info)
, actor(NULL)
, sweep_cache(NULL)
, timer(0.f)
, maxfly_time(0.f)
, free_fly_timer(0.f)
, impact_modify_scale(0.6f)
, anglelimit(0.f)
, fly_joint_id(-1)
, init_velocity(0.f, 0.f, 0.f)
, stop_phyx(false)
, busephysxrot(true)
, is_player(false)
, impact_time_old(0.f)
, impact_count(0)
{
	ammo_info = info;
}

void AmmoGrenade::Initialize(uint team , bool isboost)
{
	static const char szTeam[2] = {'r', 'b'};

	WeaponBase::Initialize();

	this->team = team;
	is_boost = isboost;
	maxfly_time = ammo_info->maxalive_time;
	impact_modify_scale = ammo_info->hurt;
	if (ammo_info->fly_particle.Length() > 0)
	{
		Core::String name = Core::String::Format("%s_%c", ammo_info->fly_particle.Str(), szTeam[team & 1]);
		fly_particle = ptr_new ParticleSystem(name, false);

		Core::String boostname = Core::String::Format("%s_%c_b%c", ammo_info->fly_particle.Str(), szTeam[team & 1], szTeam[team & 1]);
		fly_particle_boost = ptr_new ParticleSystem(boostname, false);
	}

	if (skeleton && ammo_info->fly_joint_name.Length() > 0)
	{
		fly_joint_id = skeleton->GetJointId(ammo_info->fly_joint_name);
	}

	free_fly_timer = ammo_info->ammocontrolmode.triggertime;
	anglelimit = ammo_info->ammocontrolmode.anglelimit;
}

void AmmoGrenade::CreatePhysx()
{
	is_player = false;

	tempc_ptr(Character) player = gLevel->GetPlayer();
	if (owner && player && owner->uid == player->uid)
	{
		is_player = true;
	}

	actor = PhysxSystem::CreateCapsuleCCD(position, ammo_info->capsule_height, ammo_info->capsule_radius, team + PhysxSystem::kGroupProjectStart);
	actor->setContactReportFlags(NX_NOTIFY_ON_START_TOUCH | NX_NOTIFY_FORCES);


	actor->raiseBodyFlag(NX_BF_DISABLE_GRAVITY);

	actor->setAngularDamping(1.0f);
	actor->setLinearDamping(0.0f);

	if (actor)
		actor->userData = (void*)this;
	
}

/// destructor
AmmoGrenade::~AmmoGrenade()
{
	ReleasePhysx();
}

void AmmoGrenade::StopEffect()
{
	if(is_boost)
	{
		if(fly_particle_boost)
		{
			fly_particle_boost->Reset();
			fly_particle_boost->SetDead();
		}
	}
	else
	{
		if (fly_particle)
		{
			fly_particle->Reset();
			fly_particle->SetDead();
		}
	}
}

///
void AmmoGrenade::SetEffectEnable(bool enable)
{
	if(is_boost)
	{
		if (fly_particle_boost)
		{
			fly_particle_boost->SetEnable(enable);
		}
	}
	else
	{
		if (fly_particle)
		{
			fly_particle->SetEnable(enable);
		}
	}
}

void AmmoGrenade::Update(float frame_time)
{
	timer -= frame_time;
	if (is_player)
	{
		is_dead = is_dead | (timer <= 0.f);
	}
	else
	{
		is_dead = is_dead | (timer < -timer);
	}

	WeaponBase::Update(frame_time);

	if (!is_dead)
	{
		Vector3 pos;
		Quaternion rot;
		//Core::Quaternion rot(Vector3(0, 1, 0), velocity_now);
		if(is_boost)
		{
			if(fly_particle_boost)
			{
				if (GetJointInfo(fly_joint_id, &pos, &rot))
				{
					fly_particle_boost->SetPosition(pos);
					fly_particle_boost->SetRotation(rot);
				}
			}
		}
		else
		{
			if(fly_particle)
			{
				if (GetJointInfo(fly_joint_id, &pos, &rot))
				{
					fly_particle->SetPosition(pos);
					fly_particle->SetRotation(rot);
				}
			}
		}
	}

	if (is_dead)
	{
		ReleasePhysx();
	}
}

const Core::Vector3 & AmmoGrenade::GetPosition()
{
	if (actor)
		position = (const Vector3 &)actor->getGlobalPosition();
	return position;
}

void AmmoGrenade::SetPosition(const Core::Vector3 & pos)
{
	if (actor)
		actor->setGlobalPosition((const NxVec3 &)pos);

	position = pos;
}

const Core::Quaternion & AmmoGrenade::GetRotation()
{
	if (actor && busephysxrot)
		rotation = (const Quaternion &)actor->getGlobalOrientationQuat();

	return rotation;
}

void AmmoGrenade::SetRotation(const Core::Quaternion & rot)
{
	if (actor)
		actor->setGlobalOrientationQuat((const NxQuat &)rot);

	rotation = rot;
}

void AmmoGrenade::UpdatePhysx(float frame_time)
{
	if (!is_dead && actor)
	{
		Vector3 velocity_now;

		GetVelocity(velocity_now);

		if (Length(velocity_now) < 0.2f)
		{
			StopPhysx();
			//StopEffect();
		}
		else if (Length(velocity_now) > 0.2f && !stop_phyx && GetOwner() == gLevel->GetPlayer() )
		{
			Core::Quaternion rot(Vector3(0, 1, 0), velocity_now);
			SetRotation(rot);
		}
	}
}

bool AmmoGrenade::GetVelocity(Core::Vector3 &velocity)
{
	if (actor && actor->readBodyFlag(NX_BF_KINEMATIC) == false)
	{
		NxVec3 vct = actor->getLinearVelocity();

		velocity.x = vct.x;
		velocity.y = vct.y;
		velocity.z = vct.z;
	}
	else
	{
		velocity = init_velocity;
	}

	return true;
}

tempc_ptr(AmmoGrenade) AmmoGrenade::FromNxActor(NxActor & actor)
{
	Object * obj = (Object*)actor.userData;

	if (obj)
	{
		return ptr_dynamic_cast<AmmoGrenade>(obj);
	}

	return NullPtr;
}

void AmmoGrenade::OnRender(float frame_time)
{
	//if(is_impact)
	//{
	//	tempc_ptr(Character) c = gLevel->GetCharacter(hit_character_uid);

	//	if(c && c->invincible_time > 0.f)
	//		is_dead = true;

	//	if(( !c && is_impact_character))
	//		is_dead = true;

	//	//if(c && c->GetViewMode() == Character::kThirdPerson)
	//	//{
	//	//	SetVisible(true);
	//	//}
	//	//else if(c && c->GetViewMode() == Character::kFirstPerson)
	//	//	SetVisible(false);
	//}
}

void AmmoGrenade::TimeStepUpdate(float frame_time)
{
	
	if (ammo_info)
	{
		Vector3 velocity_now;
		GetVelocity(velocity_now);
		velocity_now.y -= (ammo_info->gravity / 0.8f * frame_time) ;
		SetVelocity(velocity_now);
	}
}

void AmmoGrenade::OnImpact(NxActor &hit_actor, const Core::Vector3 &hit_normal, const Core::Vector3 &hit_point)
{
	F64 timer = Task::GetTotalTime();
	if (timer - impact_time_old < 0.1)
		return;
	impact_time_old = timer;
	tempc_ptr(Character) player = gLevel->GetPlayer();
	tempc_ptr(Character) c = Character::FromNxActor(hit_actor);

	float fly_time = maxfly_time - Core::Max(timer, 0.f);

	if (fly_time <= ammo_info->dmg_modify_timer_min)
	{
		impact_flyscale = ammo_info->dmg_modify_min;
	}
	else if (fly_time >= ammo_info->dmg_modify_timer_max)
	{
		impact_flyscale = ammo_info->dmg_modify_max;
	}
	else
	{
		float t = (fly_time - ammo_info->dmg_modify_timer_min) / (ammo_info->dmg_modify_timer_max - ammo_info->dmg_modify_timer_min);
		impact_flyscale = ammo_info->dmg_modify_min + t * (ammo_info->dmg_modify_max - ammo_info->dmg_modify_min);
	}

	if (c)
	{
		StopPhysx();
		StopEffect();
		is_impact_character = true;
		is_dead = true;
	}
	if (impact_count >= ammo_info->impact_count_max)
	{
		StopPhysx();
		StopEffect();
		is_dead = true;
	}
	else
		impact_count++;


	Vector3 velocity;
	GetVelocity(velocity);
	velocity *= impact_modify_scale;

	float dot = Core::Dot(Core::Normalize(hit_normal), Core::Vector3(0, -1, 0));
	if (Core::Abs(dot) > 0.866f)
	{
		velocity.x *= 0.8f;
		velocity.z *= 0.8f;
	}
	SetVelocity(velocity);
}

void AmmoGrenade::UpdateSyncData(float frame_time)
{
	return;
}

void AmmoGrenade::AddSyncData(byte time, const Core::Vector3 &position, const Core::Vector3 &direction)
{
	return;
}

bool AmmoGrenade::HasSyncData()
{
	return false;
}

void AmmoGrenade::ChangeAmmoTeam(uint team)
{
	return;
}

void AmmoGrenade::LaunchOut(const Core::Vector3 & velocity, by_ptr(Character) locked_c)
{
	timer = maxfly_time = ammo_info->maxalive_time;
	targetplayer = locked_c;

	SetVelocity(velocity);

	if(is_boost)
	{
		if (fly_particle_boost)
		{
			Vector3 pos;
			Quaternion rot;
			if (GetJointInfo(fly_joint_id, &pos, &rot))
			{
				fly_particle_boost->SetPosition(pos);
				fly_particle_boost->SetRotation(rot);
			}

			gLevel->AddParticle(fly_particle_boost);
		}
	}
	else
	{
		if (fly_particle)
		{
			Vector3 pos;
			Quaternion rot;
			if (GetJointInfo(fly_joint_id, &pos, &rot))
			{
				fly_particle->SetPosition(pos);
				fly_particle->SetRotation(rot);
			}

			gLevel->AddParticle(fly_particle);
		}
	}
}

bool AmmoGrenade::SetVelocity( const Core::Vector3 &velocity )
{
	init_velocity = velocity;

	if (actor && actor->readBodyFlag(NX_BF_KINEMATIC) == false)
	{
		actor->setLinearVelocity((const NxVec3 &)velocity);
	}

	return true;
}

bool AmmoGrenade::GetJointInfo(int joint_id, Core::Vector3 *pos, Core::Quaternion *rot)
{
	if (skeleton)
	{
		if (joint_id >= 0)
		{
			const Transform & transform = GetPose()->GetJointModelPose(joint_id);

			if (pos)
				*pos = GetPosition() + transform.position * GetRotation();

			if (rot)
				*rot = transform.rotation * GetRotation();

			return true;
		}
	}

	return false;
}

void AmmoGrenade::StopPhysx()
{
	stop_phyx = true;
}

void AmmoGrenade::ReleasePhysx()
{
	if (actor)
	{
		PhysxSystem::ReleaseActor(*actor);
		actor = NULL;
	}

	if (sweep_cache)
	{
		PhysxSystem::Scene()->releaseSweepCache(sweep_cache);
		sweep_cache = NULL;
	}
}




AmmoBloodDisk::AmmoBloodDisk(by_ptr(AmmoInfo) info)
: AmmoBase(info)
, actor(NULL)
, sweep_cache(NULL)
, timer(0.f)
, maxfly_time(0.f)
, free_fly_timer(0.f)
, impact_modify_scale(0.6f)
, anglelimit(0.f)
, fly_joint_id(-1)
, init_velocity(0.f, 0.f, 0.f)
, stop_phyx(false)
, busephysxrot(true)
, is_player(false)


, impact_time_old(0.f)
, impact_count(0)
{
	ammo_info = info;
}



void AmmoBloodDisk::Initialize(uint team , bool isboost)
{
	static const char szTeam[2] = {'r', 'b'};

	WeaponBase::Initialize();

	this->team = team;
	is_boost = isboost;
	maxfly_time = ammo_info->maxalive_time;
	impact_modify_scale = ammo_info->hurt;
	if (ammo_info->fly_particle.Length() > 0)
	{
		Core::String name = Core::String::Format("%s_%c", ammo_info->fly_particle.Str(), szTeam[team & 1]);
		fly_particle = ptr_new ParticleSystem(name, false);

		Core::String boostname = Core::String::Format("%s_%c_b%c", ammo_info->fly_particle.Str(), szTeam[team & 1], szTeam[team & 1]);
		fly_particle_boost = ptr_new ParticleSystem(boostname, false);
	}

	if (skeleton && ammo_info->fly_joint_name.Length() > 0)
	{
		fly_joint_id = skeleton->GetJointId(ammo_info->fly_joint_name);
	}

	free_fly_timer = ammo_info->ammocontrolmode.triggertime;
	anglelimit = ammo_info->ammocontrolmode.anglelimit;
}

void AmmoBloodDisk::CreatePhysx()
{
	is_player = false;

	tempc_ptr(Character) player = gLevel->GetPlayer();
	if (owner && player && owner->uid == player->uid)
	{
		is_player = true;
	}
	//actor = PhysxSystem::CreateCapsuleCCD(position, ammo_info->capsule_height, ammo_info->capsule_radius, PhysxSystem::kGroupProjectStart);
	actor = PhysxSystem::CreateBoxCCD(position, Vector3(ammo_info->capsule_radius, ammo_info->capsule_height, ammo_info->capsule_radius), PhysxSystem::kBloodDisk);
	if(is_player)
	{
		actor->setContactReportFlags(NX_NOTIFY_ON_START_TOUCH | NX_NOTIFY_FORCES);
		actor->raiseBodyFlag(NX_BF_DISABLE_GRAVITY);
		actor->setAngularDamping(1.0f);
		actor->setLinearDamping(0.0f);
	}
	else
	{
		actor->raiseBodyFlag(NX_BF_KINEMATIC);
	}
	


	if (actor)
		actor->userData = (void*)this;

}

/// destructor
AmmoBloodDisk::~AmmoBloodDisk()
{
	ReleasePhysx();
}

void AmmoBloodDisk::StopEffect()
{
	if(is_boost)
	{
		if(fly_particle_boost)
		{
			fly_particle_boost->Reset();
			fly_particle_boost->SetDead();
		}
	}
	else
	{
		if (fly_particle)
		{
			fly_particle->Reset();
			fly_particle->SetDead();
		}
	}
}

///
void AmmoBloodDisk::SetEffectEnable(bool enable)
{
	if(is_boost)
	{
		if (fly_particle_boost)
		{
			fly_particle_boost->SetEnable(enable);
		}
	}
	else
	{
		if (fly_particle)
		{
			fly_particle->SetEnable(enable);
		}
	}
}

void AmmoBloodDisk::Update(float frame_time)
{
	timer -= frame_time;
	if (is_player)
	{
		is_dead = is_dead | (timer <= 0.f);
	}
	else
	{
		is_dead = is_dead | (timer < -timer);
	}

	WeaponBase::Update(frame_time);

	if (!is_dead|| sync_data.Size() > 1)
	{
		Vector3 pos = GetPosition();
		Quaternion rot = Quaternion::kIdentity;
		//Core::Quaternion rot(Vector3(0, 1, 0), velocity_now);

		if(is_boost)
		{
			if(fly_particle_boost)
			{
				//if (GetJointInfo(fly_joint_id, &pos, &rot))
				{
					fly_particle_boost->SetPosition(pos);
					fly_particle_boost->SetRotation(rot);
				}
			}
		}
		else
		{
			if(fly_particle)
			{
				//if (GetJointInfo(fly_joint_id, &pos, &rot))
				{
					fly_particle->SetPosition(pos);
					fly_particle->SetRotation(rot);
				}
			}
		}
	}

	if (is_dead)
	{
		ReleasePhysx();
	}
}

const Core::Vector3 & AmmoBloodDisk::GetPosition()
{
	if (actor)
		position = (const Vector3 &)actor->getGlobalPosition();
	return position;
}

void AmmoBloodDisk::SetPosition(const Core::Vector3 & pos)
{
	if (actor)
		actor->setGlobalPosition((const NxVec3 &)pos);

	position = pos;
}

const Core::Quaternion & AmmoBloodDisk::GetRotation()
{
	if (actor && busephysxrot)
		rotation = (const Quaternion &)actor->getGlobalOrientationQuat();

	return rotation;
}

void AmmoBloodDisk::SetRotation(const Core::Quaternion & rot)
{
	if (actor)
		actor->setGlobalOrientationQuat((const NxQuat &)rot);

	rotation = rot;
}

void AmmoBloodDisk::UpdatePhysx(float frame_time)
{
	if (!is_dead && actor && gLevel && owner == gLevel->GetPlayer())
	{
		Vector3 velocity_now;

		GetVelocity(velocity_now);

		velocity_now.Normalize();
		velocity_now *= ammo_info->default_fly_speed;

		SetVelocity(velocity_now);

		Core::Quaternion rot = Quaternion::kIdentity;
		SetRotation(rot);
	}
}

void AmmoBloodDisk::UpdateSyncData(float frame_time)
{
	if (is_player)
		return;

	// no sync data, return
	if (sync_data.Empty())
		return;

	AmmoSyncData data;
	Vector3	vel;

	// remove unused data
	while (sync_data.Size() > 1 && sync_data[1].time <= sync_time)
		sync_data.PopFront();

	if (sync_data.Size() > 1)
	{
		AmmoSyncData & data1 = sync_data[0];
		AmmoSyncData & data2 = sync_data[1];

		float s = Clamp((sync_time - data1.time) / (data2.time - data1.time), 0, 1);

		Lerp(data.position, data1.position, data2.position, s);
		Core::Slerp(data.rotation, data1.rotation, data2.rotation, s);

		// calculate velocity
		vel = (data.position - GetPosition()) / frame_time;

		// update time
		float delay_time = sync_data.Back().time - sync_time;

		// scale time when delay time > 0.05
		if (delay_time > 0.1f)
			frame_time *= 1 + (delay_time - 0.1f);

		sync_time += frame_time;

		//LogSystem.WriteLinef("Ammo::UpdateSyncData() : %f", sync_time);
	}
	else
	{
		data = sync_data[0];
		vel = Vector3::kZero;
		sync_time = sync_data[0].time;
	}

	SetPosition(data.position);
	SetRotation(data.rotation);
}

void AmmoBloodDisk::AddSyncData(byte time, const Core::Vector3 &position, const Core::Vector3 &direction)
{
	if (!sync_data.Empty())
	{
		AmmoSyncData sync = sync_data.Back();

		sync.time += (float)time / 255.f;
		sync.position = position;
		sync.rotation.SetZXY(direction);

		sync_data.PushBack(sync);
	}
}

bool AmmoBloodDisk::HasSyncData()
{
	//return !(sync_data.Size() <= 1);
	return sync_data.Size() > 1;
}

bool AmmoBloodDisk::GetVelocity(Core::Vector3 &velocity)
{
	if (actor && actor->readBodyFlag(NX_BF_KINEMATIC) == false)
	{
		NxVec3 vct = actor->getLinearVelocity();

		velocity.x = vct.x;
		velocity.y = vct.y;
		velocity.z = vct.z;
	}
	else
	{
		velocity = init_velocity;
	}

	return true;
}

tempc_ptr(AmmoBloodDisk) AmmoBloodDisk::FromNxActor(NxActor & actor)
{
	Object * obj = (Object*)actor.userData;

	if (obj)
	{
		return ptr_dynamic_cast<AmmoBloodDisk>(obj);
	}

	return NullPtr;
}

void AmmoBloodDisk::OnRender(float frame_time)
{
	
}

void AmmoBloodDisk::TimeStepUpdate(float frame_time)
{
	UpdateHitTimer(frame_time);
	
	if(is_player)
	{
		Vector3 v_now;
		GetVelocity(v_now);
		v_now.y = 0.f;
		Vector3 dir = v_now;

		Vector3 extent(ammo_info->capsule_radius,ammo_info->capsule_height,ammo_info->capsule_radius);
		dir.Normalize();
		float distance = 1.2f;
		Vector3 firemotion = dir * distance;


		Core::Matrix44 rotmatrix(Quaternion(Vector3(0.f, 0.f, -1.f), dir));
		NxMat33 matt;
		matt.setRow(0,NxVec3(rotmatrix._11,rotmatrix._12,rotmatrix._13));
		matt.setRow(1,NxVec3(rotmatrix._21,rotmatrix._22,rotmatrix._23));
		matt.setRow(2,NxVec3(rotmatrix._31,rotmatrix._32,rotmatrix._33));

		NxBox FlameBox((const NxVec3 &)GetPosition(),(const NxVec3 &)extent,matt);

		NxU32 activeGroups = 0;
		if(team == 0)
			activeGroups |= 1<< PhysxSystem::kGroupEnd;
		else
			activeGroups |= 1 << PhysxSystem::kGroupStart;

		Array<HitMessage> hit_message;
		hit_message.Reserve(10);

		NxSweepQueryHit hit[200];
		NxU32 num = gPhysxScene->linearOBBSweep(FlameBox,(const NxVec3&)firemotion,NX_SF_DYNAMICS|NX_SF_ALL_HITS,NULL, 200, hit, NULL , activeGroups);

		if(num > 0)
		{
			for(NxU32 i = 0; i < num ;i++)
			{
				NxActor &actor = hit[i].hitShape->getActor();

				tempc_ptr(Character) p = Character::FromNxActor(actor);
				if (p)
				{
					int part = p->GetActorId(&actor);

					if(hit_timer_set.Get(p->uid,-1.f) < 0.0f)
					{
						HitMessage & message = hit_message.PushBack();
						message.uid = p->uid;
						message.part = part;
						message.distance = distance;

						if(CheckHitLimit(p->uid))
						{
							hit_timer_set.Add(p->uid, 0.0f);
						}

					}
				}
			}

			if (gGame->channel_connection && hit_message.Size() > 0)
			{
				gGame->channel_connection->CutHurt(ammoindex, hit_message);
				hit_message.Clear();
			}

		}

	}
}

bool AmmoBloodDisk::CheckHitLimit(byte uid)
{
	int count = hit_count_set.Get(uid,-1);
	if(count >= 0)
	{
		if(count >= ammo_info->blood_disk_hit_count)
		{
			hit_count_set.Set(uid, 0);
			return true;
		}
		else
		{
			hit_count_set.Set(uid, count + 1);
		}
	}
	else
	{
		hit_count_set.Add(uid, 1);
	}
	return false;
}

void AmmoBloodDisk::UpdateHitTimer(float frame_time)
{
	Core::HashSet<byte, float>::Enumerator ammoitor(hit_timer_set);
	Core::Array<byte> clear_array;

	while (ammoitor.MoveNext())
	{
		float value = ammoitor.Value();
		value += frame_time;
		if(value > ammo_info->blood_disk_interval)
		{
			clear_array.Add(ammoitor.Key());
		}
		hit_timer_set.Set(ammoitor.Key(), value);
	}

	for (int n = 0; n < (int)clear_array.Size(); ++n)
	{
		hit_timer_set.Remove(clear_array[n]);
	}
}

void AmmoBloodDisk::OnImpact(NxActor &hit_actor, const Core::Vector3 &hit_normal, const Core::Vector3 &hit_point)
{
	tempc_ptr(Character) player = gLevel->GetPlayer();

	if (!is_player)
		return;

	F64 timer = Task::GetTotalTime();
	if (timer - impact_time_old < 0.1)
		return;
	impact_time_old = timer;

	float fly_time = maxfly_time - Core::Max(timer, 0.f);
	
	impact_count ++;

	Vector3 velocity;
	GetVelocity(velocity);
	velocity.Normalize();
	velocity *= ammo_info->default_fly_speed;
	
	SetVelocity(velocity);

	if (impact_count == 4)
	{
		StopPhysx();
		StopEffect();
		is_dead = true;
	}
}


void AmmoBloodDisk::ChangeAmmoTeam(uint team)
{
	return;
}

void AmmoBloodDisk::LaunchOut(const Core::Vector3 & velocity, by_ptr(Character) locked_c)
{
	timer = maxfly_time = ammo_info->maxalive_time;
	targetplayer = locked_c;

	SetVelocity(velocity);

	if(is_boost)
	{
		if (fly_particle_boost)
		{
			Vector3 pos;
			Quaternion rot;
			if (GetJointInfo(fly_joint_id, &pos, &rot))
			{
				fly_particle_boost->SetPosition(pos);
				fly_particle_boost->SetRotation(rot);
			}

			gLevel->AddParticle(fly_particle_boost);
		}
	}
	else
	{
		if (fly_particle)
		{
			Vector3 pos;
			Quaternion rot;
			if (GetJointInfo(fly_joint_id, &pos, &rot))
			{
				fly_particle->SetPosition(pos);
				fly_particle->SetRotation(rot);
			}

			gLevel->AddParticle(fly_particle);
		}
	}

	{
		sync_time = 0;
		sync_data.Clear();

		AmmoSyncData & sync = sync_data.PushBack();

		sync.time = 0;
		sync.position = GetPosition();
		sync.rotation = GetRotation();
	}
}

bool AmmoBloodDisk::SetVelocity( const Core::Vector3 &velocity )
{
	init_velocity = velocity;

	if (actor && actor->readBodyFlag(NX_BF_KINEMATIC) == false)
	{
		actor->setLinearVelocity((const NxVec3 &)velocity);
	}

	return true;
}

bool AmmoBloodDisk::GetJointInfo(int joint_id, Core::Vector3 *pos, Core::Quaternion *rot)
{
	if (skeleton)
	{
		if (joint_id >= 0)
		{
			const Transform & transform = GetPose()->GetJointModelPose(joint_id);

			if (pos)
				*pos = GetPosition() + transform.position * GetRotation();

			if (rot)
				*rot = transform.rotation * GetRotation();

			return true;
		}
	}

	return false;
}

void AmmoBloodDisk::StopPhysx()
{
	stop_phyx = true;
}

void AmmoBloodDisk::ReleasePhysx()
{
	if (actor)
	{
		PhysxSystem::ReleaseActor(*actor);
		actor = NULL;
	}

	if (sweep_cache)
	{
		PhysxSystem::Scene()->releaseSweepCache(sweep_cache);
		sweep_cache = NULL;
	}
}
