namespace Client
{
	struct KnifeInfo : public WeaponInfo
	{
		float	stab_time;
		float	stab_light_time;

		float stab_hurt;
		float stab_light_hurt;

		float stab_distance;
		float stab_light_distance;
		float stab_width;
		float back_factor;
		int back_boost_plus;
		

		Core::Identifier hit_none_light_2d;
		Core::Identifier hit_none_2d;
		Core::Identifier hit_none_light_3d;
		Core::Identifier hit_none_3d;
		Core::Identifier hit_wall_light_2d;
		Core::Identifier hit_wall_2d;
		Core::Identifier hit_wall_light_3d;
		Core::Identifier hit_wall_3d;
		Core::Identifier hit_body_light_2d;
		Core::Identifier hit_body_2d;
		Core::Identifier hit_body_light_3d;
		Core::Identifier hit_body_3d;


		Core::Identifier hit_wall_decal_easy;
		Core::Identifier hit_wall_decal_heavy;
		Core::Identifier hit_wall_decal_easy_reverse;


		KnifeInfo()
		{
			weapon_type = kWeaponTypeKnife;
			stab_distance = 2.0f;
			stab_light_distance = 1.5f;
			stab_width = 0.5f;
			back_factor = 1.f;
			back_boost_plus = 0.f;
			hit_wall_decal_easy = "scratch_easy";
			hit_wall_decal_heavy = "scratch_heavy";
			hit_wall_decal_easy_reverse = "scratch_easy_inverse";

		}
	};

	class Knife : public WeaponBase
	{
	public:
		enum HitType
		{
			kNone = 0,
			kHitNone, 
			kHitNoneLight,
			kHitWall,
			kHitWallLight,
			kHitBody,
			kHitBodyLight,
		};

	public:
		/// constructor
		Knife(by_ptr(KnifeInfo) info);

		/// get weapon type
		virtual uint GetWeaponType() { return kWeaponTypeKnife; }

	public:
		/// initialize
		virtual void Initialize();

		/// udpate
		virtual void Update(float frame_time);

		/// can active
		virtual bool CanActive();

		/// active
		virtual void Active();

		/// inactive
		virtual void Inactive();

		/// draw ui
		virtual void DrawUI(by_ptr(UIRender) ui_render);

	public:
		/// stab
		byte Stab(bool light);

		/// stab check
		void StabCheck();

		/// stab sound
		void StabSound(byte type, bool stereo = false);

	private:
		void KickBack(float up_base, float lateral_base, float up_max, float lateral_max, int direction_change);

	public:
		sharedc_ptr(KnifeInfo)	knife_info;

	private:
		bool	stabing;
		bool	stab_light;
		float	stab_time;
		float	stab_hurt_time;
		float	direction;
	};
}