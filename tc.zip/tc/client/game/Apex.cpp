#include "pch.h"


#if ACTIVE_APEX
#include "ApexClient.h"
#include  <time.h>

#pragma comment(lib, "AHClientInterface.lib")

using namespace Core;
using namespace Client;

//
//pfRec �� Apex Client �ṩ�����ݴ�������;��,GameClient �յ�GameServer��������Apex �����ݵ�ʱ��
//		�����������ָ�봦��;���:  int		NoticeApec_UserData(const char * pBuf,int nBufLen);
//

_FUNC_C_REC	pfRec = NULL;

bool g_ApexStarted = false;


namespace Apex
{
	ApexBuffer::ApexBuffer(int nlen, const char* p)
	{
		size = nlen;
		if(size == 0)
		{
			PDE_ASSERT(0, "array is empty");
		}

		if(size != 0)
		{
			pBuf = new char[nlen];
			memcpy_s(pBuf,nlen, p, nlen);
		}
	}

	ApexBuffer::~ApexBuffer()
	{
		if(pBuf)
			SAFE_DELETE_ARRAY(pBuf);
	}
	


	static long NetSendToGameServer(const char * pBuffer, int nLen)
	{
		CriticalSectionLock lock(g_Apex_lock);

		sharedc_ptr(ApexBuffer) pbuf = ptr_new ApexBuffer(nLen,pBuffer);
		g_ApexBuffer_Array.Add(pbuf);


		return 0;
	}


	int	NoticeApec_UserData(const char * pBuf,int nBufLen)
	{
		if(pfRec)
		{
			pfRec(pBuf,nBufLen);
		}
		return 0;
	};

	int	StartApexClient()
	{
		//����ApexClient;	NetSendToGameServer �ǿ������ṩ�ķ��ͺ���,
		//					pfRec				��Apex �ṩ�Ľ��ܺ���;

		LogSystem.WriteLinef("Start  Apex\n");
		long ret = CHCStart(&NetSendToGameServer, pfRec);
		g_ApexStarted = true;
		return 0;
	}

	int	StopApexClient()
	{
		//ֹͣ ApecClient
		if(g_ApexStarted)
		{
			LogSystem.WriteLinef("End  Apex\n");
			CHCEnd();
			g_ApexStarted = false;
		}

		return 0;
	}

	int UpdateApex_UserData()
	{
		if(g_ApexStarted)
		{
			if(!gGame || !gGame->lobby_connection)
			{
				return -1;
			}

			CriticalSectionLock lock(g_Apex_lock);
			
			uint length = g_ApexBuffer_Array.Size();
			for (uint i = 0; i < length; i++)
			{
				tempc_ptr(ApexBuffer) pApex = g_ApexBuffer_Array[i];
			
				gGame->lobby_connection->RequestApex(pApex->pBuf,pApex->size);
			}


		


			if(length > 0)
			{
				g_ApexBuffer_Array.Clear();
				//time_t t = time(NULL);
				//tm tp;
				//localtime_s(&tp,&t);  
				//LogSystem.WriteLinef("%d:%d:%d/n",tp.tm_hour,tp.tm_min,tp.tm_sec); 
			}		

			
			return 0;
		}

		return -1;
	}
}
#endif