namespace Client
{
	class ToolsBox : public Core::Object
	{
	public:
		ToolsBox(void);
		virtual ~ToolsBox(void);

		void InitToolsBox();
		void SetPosition(const Core::Vector3& pos);
		void SetRotation(const Core::Quaternion& rot);
		Core::Quaternion GetRotation();

		void SetHeight(const float& height);

		/// draw
		virtual void Draw(Primitive::DrawType drawtype, bool immediate = false);
		void Update(float frame_time);

		void AddMesh(const Core::Identifier & key);
		void ClearMesh();

	protected:
		void DrawAABB();

	public:
		Core::Quaternion finalrotation;
		bool isDraw;
		bool isRot;

	private:
		Core::Vector3 position;
		Core::Quaternion rotation;
		float height;

		int rotindex;
		float angle;

		NxActor* actor;
		NxRay ray[4];
		Core::Array<sharedc_ptr(StaticMesh)> mesh_array;
	};
}
