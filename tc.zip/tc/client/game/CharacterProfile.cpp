#include "pch.h"

using namespace Core;
using namespace Client;

//---------------------------------------------------------------------------------------
// type info.
//---------------------------------------------------------------------------------------
DEFINE_PDE_TYPE_CLASS(Client::CharacterProfile)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_PROPERTY_RW(InviteOff);
		ADD_PDE_PROPERTY_RW(GuideOff);
		ADD_PDE_PROPERTY_RW(LeaderEnter);
		ADD_PDE_PROPERTY_RW(SearchRoomWaiting);
		ADD_PDE_PROPERTY_RW(SearchRoomPlaying);
		ADD_PDE_PROPERTY_RW(SearchChannelCurrent);
		ADD_PDE_PROPERTY_RW(SearchChannelVIP);
		ADD_PDE_PROPERTY_RW(SearchGameTypeIndex);
		ADD_PDE_PROPERTY_RW(SearchMapName);
		ADD_PDE_PROPERTY_RW(SearchPlayerNum);
		ADD_PDE_PROPERTY_RW(SearchOptionAutoSave);
		ADD_PDE_PROPERTY_RW(LeaderEnterAutoSave);

		ADD_PDE_METHOD(Save);
	}
};

REGISTER_PDE_TYPE(Client::CharacterProfile);

namespace Client
{
	CharacterProfile::CharacterProfile()
		: m_InviteOff(false)
		, m_GuideOff(false)
		, m_LeaderEnter(false)
		, m_SearchRoomWaiting(true)
		, m_SearchRoomPlaying(true)
		, m_SearchChannelCurrent(true)
		, m_SearchChannelVIP(false)
		, m_SearchGameTypeIndex(-1)
		, m_SearchOptionAutoSave(false)
		, m_SearchPlayerNum(-1)
		, m_LeaderEnterAutoSave(false)
	{
		
	}

	void CharacterProfile::Save()
	{
		gGame->config->SaveProfile();
	}
}