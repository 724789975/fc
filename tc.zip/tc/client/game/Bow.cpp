#include "pch.h"

using namespace Core;
using namespace Client;

DEFINE_PDE_TYPE_CLASS(Client::BowInfo)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Client::GunInfo);

		ADD_PDE_DEFAULT_CONSTRUCTOR();
	}
};

REGISTER_PDE_TYPE(Client::BowInfo);


/// random float
static float RandomFloat(F32 x, F32 y)
{
	float r = (F32)rand() / (RAND_MAX + 1);
	float num = x + (y - x) * r;
	return num; 
}


/// constrcutor
Bow::Bow(by_ptr(BowInfo) info)
: Can_Fire(false)
, active_time(-1.0f)
, reload_time(-1.0f)
{
	has_trajectory = true;
	weapon_info = gun_info = bow_info = info;
}

/// initialize
void Bow::Initialize()
{
	GunBase::Initialize();

	tempc_ptr(Character) player = GetOwner();
	if (player)
		player->reload_State = 0;
}

/// active
void Bow::Active()
{
	tempc_ptr(Character) player = GetOwner();
	if (!player)
		return;

	player->reload_State = 0;
	Can_Fire = true;

	GunBase::Active();
}

/// inactive
void Bow::Inactive()
{
	GunBase::Inactive();
}

/// get weapon type
uint Bow::GetWeaponType()
{
	return kWeaponTypeBow;
}

/// fire
bool Bow::Fire()
{		
	tempc_ptr(Character) player = GetOwner();

	if (!player)
		return false;

	tempc_ptr(BowInfo) bow_info = ptr_static_cast<BowInfo>(weapon_info);
	if(!bow_info)
		return false;
	Vector3 fire_pos;
	float spread = 0.0f;

	if (gGame->channel_connection && GetJointInfo(joint_fire_id, &fire_pos, NULL))
	{
		const float max_distance = 35.0f;

		Vector3 fire_angle = player->GetLookDir().GetZXY();
		fire_angle += player->punch_angle;
		camerarot = gGame->camera->rotation;
		Quaternion rot;
		rot.SetZXY(fire_angle);

		Vector3 dir = Vector3(0, 0, -1) * rot;
		Vector3 up_dir = Vector3(0, 1, 0) * rot;
		Vector3 right_dir = Vector3(1, 0, 0) * rot;

		float x, y, z;
		x = RandomFloat( -0.5, 0.5 ) + RandomFloat( -0.5, 0.5 );
		y = RandomFloat( -0.5, 0.5 ) + RandomFloat( -0.5, 0.5 );
		z = x * x + y * y;

		dir += x * spread * right_dir + y * spread * up_dir;
		dir.Normalize();

		Vector3 hit_pos = player->GetCameraPosition() + dir * max_distance;
		dir = hit_pos - fire_pos;
		dir.Normalize();

		gGame->channel_connection->ProjectedAmmoOut(kWeaponTypeAmmoArrow, fire_pos, dir * 40);
	}
	reload_time = 0.1f;

	return true;
}


//update
void Bow::Update(float time)
{
	WeaponBase::Update(time);

	tempc_ptr(Character) player = GetOwner();
	if (!player)
		return;

	if (!bow_info)
		return;
	
	//GunBase::Update(time);
	reload_time -= time;

	if( player->second_action_on)
	{
		if( active_time >= 0.0f )
		{
			active_time = -1.f;

			const FirstPerson & first_person = player->GetFirstPerson();
			if(first_person.node_group_first)
			{		
				first_person.node_group_first->PlayAction("bow_step1", "step3");		
			}
		}
		
	}
	else if( player->first_action_on && reload_time < 0.f )
	{
		if( active_time < 0.0f )
		{
			const FirstPerson & first_person = player->GetFirstPerson();
			if(first_person.node_group_first)
			{		
				first_person.node_group_first->PlayAction("bow_step1", "step1");		
			}


			// ready to shoot
			active_time = 0.0f;
			
			//if (animation)
			//	animation->PlayAction("step1", 0.01f, false, 0,true);
		}
	}
	else if( active_time >= 0.0f )
	{
		//shoot
		active_time = -1.f;

		//reload_time = 1.5f;
		
		const FirstPerson & first_person = player->GetFirstPerson();
		if(first_person.node_group_first)
		{		
			first_person.node_group_first->PlayAction("bow_step1", "step3");		
		}

		Fire();
	}
}

///reload
bool Bow::Reload()
{
	if (CanReload())
	{
		reloading = true;
		ReloadAction();
		reload_time = gun_info->reload_time;

		return true;
	}

	return false;
}


