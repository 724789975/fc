#include "pch.h"

using namespace Core;
using namespace Client;

/// constructor
Vehicle::Vehicle(const PushVehicleInfo& info)
:	 timer(0.f)
	, maxfly_time(0.f)
	, uid(-1)
	, team(-1)
	, init_velocity(0.f, 0.f, 0.f)
	, add_up_time(0.f)
	, need_update(true)
	, need_draw_smoke(false)
{
	current_vehicle_info = info;
	team = info.team;
}

/// create physx
void Vehicle::CreatePhysx()
{
	for (uint i = 0; i < gLevel->mesh_manual_info_array.Size(); i++)
	{
		MeshPhysXData data = gLevel->mesh_manual_info_array[i];

		if(data.type == MeshPhysXData::VEHICLE_MESH)
		{
			data.actor = PhysxSystem::CreateBox(Vector3(0,0,0), data.dim, PhysxSystem::kGroupVehicle);


			data.actor->raiseBodyFlag(NX_BF_KINEMATIC);
			data.actor->userData = (void*)this;

			kinematic_actor_array.PushBack(data);
		}		
	}
}

/// destructor
Vehicle::~Vehicle()
{
	check_point_array.Clear();
	lightparticle->SetEnable(false);
	ReleasePhysx();
	StopEffect();
}

/// initialize
void Vehicle::Initialize()
{
	vehicle_mesh = ptr_new StaticMesh(MESH_KEY_PROP);
	if(team == 0)
	{
		vehicle_mesh->AddPrimitive("Vehicle_r/Vehicle.mesh",0);
		lightparticle = ptr_new ParticleSystem("glow_car_r",false);
	}
	else
	{
		vehicle_mesh->AddPrimitive("Vehicle_b/Vehicle.mesh",0);
		lightparticle = ptr_new ParticleSystem("glow_car_b",false);
	}

	vehicle_mesh->SetPosition(vehicle_mesh->GetPosition());

	lightparticle->Reset();

	InitializeVehicleInfo(current_vehicle_info);

	CreatePhysx();

	SetPosition(current_vehicle_info.position);
	Quaternion q(Vector3(0,0,1), current_vehicle_info.dir);
	SetRotation(q);


	AddSmokeEffect();
}

void Vehicle::AddSmokeEffect()
{
	

	for (int i = 0; i < 3; i++)
	{
		sharedc_ptr(ParticleSystem) dirtparticle = ptr_new ParticleSystem("car_rundirt", false);
		vehicle_smoke_particle_array.PushBack(dirtparticle);
		sharedc_ptr(ParticleSystem)& particle =  vehicle_smoke_particle_array[i];
		particle->Reset();
		particle->SetPosition(GetPosition());
		particle->SetRotation(GetRotation());
	}
}
///
void Vehicle::StopEffect()
{
	for (uint i = 0; i < vehicle_smoke_particle_array.Size(); i++)
	{
		sharedc_ptr(ParticleSystem)& smoke_particle = vehicle_smoke_particle_array[i];
		if (smoke_particle)
		{
			smoke_particle ->SetDead();
			smoke_particle = NullPtr;
		}
	}
	vehicle_smoke_particle_array.Clear();
}

/// update physx
void Vehicle::UpdatePhysx(float frame_time)
{
	
}
void Vehicle::Draw(Primitive::DrawType type, bool immediate)
{
	if(vehicle_mesh)
		vehicle_mesh->Draw(type, immediate);
}


void Vehicle::DrawParticle()
{
	if (lightparticle && !lightparticle->IsDead())
	{
		lightparticle->Draw();
	}

	if(need_draw_smoke)
	{
		for (uint i = 0; i < vehicle_smoke_particle_array.Size(); i++)
		{
			sharedc_ptr(ParticleSystem)& smoke_particle = vehicle_smoke_particle_array[i];
			if (smoke_particle)
			{
				smoke_particle->Draw();	
			}
		}
	}
}


void Vehicle::Update(float frame_time)
{
	timer -= frame_time;

	if(!need_update)
		return;
	Vector3 last_pos = GetPosition();
	Vector3 velocity = current_vehicle_info.velocity * frame_time;
	Vector3 pos = GetPosition() + velocity;
	add_up_time -= frame_time;

	if(add_up_time < 0.f)
	{
		pos = current_vehicle_info.position;
	}

	current_vehicle_info.position = pos;

	SetPosition(pos);

	Quaternion q(Vector3(0,0,1), current_vehicle_info.dir);
	Quaternion q1(Vector3(0,0,1), current_vehicle_info.last_dir);

	float lerp = Clamp(add_up_time/current_vehicle_info.time_interval,0,1);

	Core::Slerp(q, q, q1, lerp);
	Vector3 v = q.GetZXY();
	v.z = 0;
	q.SetZXY(v);

	SetRotation(q);


	{
		if(gLevel->GetPlayer())
		{
			Vector3 player_pos = gLevel->GetPlayer()->GetPosition() + Vector3(0,0.98f,0);

			Vector3 ball_center = Vector3(0,0.98f,1.091f) * GetRotation() + pos;

			float length = LengthSqr(ball_center - player_pos);
			
			Vector3 ball_center1 = Vector3(0,0.98f,0.191f) * GetRotation() + pos;
			
			float length1 = LengthSqr(ball_center1 - player_pos);

			Vector3 ball_center2 = Vector3(0,2.48f,0.191f) * GetRotation() + pos;

			float length2 = LengthSqr(ball_center2 - player_pos);

			if(length < 0.802f || length1 < 0.802f || length2 < 0.802f)
			{
				KickInfo info;
				Vector3 v = velocity;


				v.Normalize();
				v.y +=0.05f;
				info.dir.SetFromTo(Vector3(0,0,-1),v);
				info.kick_time_interval = 0.2f;
				info.kick_factor = 6.f;
				info.on_static_kick_y_offset = 1.7f;

				gLevel->GetPlayer()->OnKickBack(info, true);
			}
		}


	}



	lightparticle->Update(frame_time);

	if(!lightparticle->IsDead() && lightparticle->IsReady())
	{
			Vector3 lightOffset = Vector3(-0.012f,1.233f,-1.669f) + Vector3(0.f, 1.371f, 1.065f);
			Vector3 lightPos = (pos + lightOffset * GetRotation());
			lightparticle->SetPosition(lightPos);
	}

	// force place it

	//for (uint i = 0; i < actor_array.Size(); i++)
	//{
	//	MeshPhysXData& data = actor_array[i];
	//	data.actor->setGlobalPosition((const NxVec3 &)position);
	//	data.actor->setGlobalOrientationQuat((const NxQuat &)rotation);
	//}

	for (uint i = 0; i < vehicle_smoke_particle_array.Size(); i++)
	{
		sharedc_ptr(ParticleSystem)& smoke_particle = vehicle_smoke_particle_array[i];
		if(smoke_particle)
		{
			Vector3 dirtOffset;
			Vector3 magicalOffset = Vector3(0.f, 1.371f, 1.065f);
			switch (i)
			{
			case(0):
				dirtOffset = Vector3(0.f, -1.431f, -2.085f) + magicalOffset ;
				break;
			case(1):
				dirtOffset = Vector3(-0.647f, -1.431f, -0.275f) + magicalOffset ;
				break;
			case(2):
				dirtOffset = Vector3(0.647f, -1.431f, -0.275f) + magicalOffset ;
				break;
			default:
				dirtOffset = Vector3(0.f, -1.431f, -2.085f) + magicalOffset ;
				break;
			}

			smoke_particle->SetPosition(pos + dirtOffset * GetRotation());
			smoke_particle->SetRotation(q);
			smoke_particle->Update(frame_time);

			if((pos - last_pos).Length() > 0.f)
			{
				need_draw_smoke = true;
			}
			else
			{
				need_draw_smoke = false;
			}
		}
		

	}
}

/// get position
const Vector3 & Vehicle::GetPosition()
{
	return position;
}

/// set position
void Vehicle::SetPosition(const Core::Vector3 & pos)
{
	//magic num by zheng shuai 
	Vector3 offset = Vector3(0.f, 1.371f, 1.065f);
	offset = offset * GetRotation();
	

	for (uint i = 0; i < kinematic_actor_array.Size(); i++)
	{
		MeshPhysXData& data = kinematic_actor_array[i];
		if (!data.actor)
			return;

		Vector3 center_offset = data.center_offset;
		center_offset -= Vector3(0 ,0 ,1.189f);
		center_offset = center_offset * GetRotation();

		data.actor->setGlobalPosition((const NxVec3 &)(pos + center_offset));
	}

	vehicle_mesh->SetPosition(pos + offset);

	position = pos;
}


/// get rotation
const Core::Quaternion & Vehicle::GetRotation()
{
	return rotation;
}

/// set rotation
void Vehicle::SetRotation(const Core::Quaternion & rot)
{
	for (uint i = 0; i < kinematic_actor_array.Size(); i++)
	{
		MeshPhysXData& data = kinematic_actor_array[i];
		if (!data.actor)
			return;


		data.actor->setGlobalOrientationQuat((const NxQuat &)rot);
	}

	vehicle_mesh->SetRotation(rot);
	rotation = rot;
}

sharedc_ptr(StaticMesh) Vehicle::GetMesh()
{
	return vehicle_mesh;
}

void Vehicle::SetStartPosition(const Core::Vector3 & pos)
{
	start_pos = pos;
}

void Vehicle::SetStartDir(const Core::Vector3 & dir)
{
	start_dir = dir;
}

/// from nx actor
tempc_ptr(Vehicle) Vehicle::FromNxActor(NxActor & actor)
{
	Object * obj = (Object*)actor.userData;

	if (obj)
	{
		return ptr_dynamic_cast<Vehicle>(obj);
	}

	return NullPtr;
}

void Vehicle::ReleasePhysx()
{
	for (uint i = 0; i < kinematic_actor_array.Size(); i++)
	{
		PhysxSystem::ReleaseActor(*kinematic_actor_array[i].actor);
	}
	kinematic_actor_array.Clear();
}

void Vehicle::UpdateVehicleInfo(const PushVehicleInfo& info)
{
	Vector3 last_positon = current_vehicle_info.position;
	Vector3 last_dir = current_vehicle_info.dir;
	current_vehicle_info = info;
	current_vehicle_info.last_position = last_positon;
	current_vehicle_info.last_dir = last_dir;
	current_vehicle_info.velocity = (current_vehicle_info.position - last_positon)/current_vehicle_info.time_interval;
	add_up_time = current_vehicle_info.time_interval;

	float f = info.current_length / info.total_length;

	if(f > 0.9999f)
		need_update = false;
}


void Vehicle::InitializeVehicleInfo(const PushVehicleInfo& info)
{
	Vector3 last_positon = current_vehicle_info.position;
	Vector3 last_dir = current_vehicle_info.dir;
	current_vehicle_info = info;
	current_vehicle_info.last_position = last_positon;
	current_vehicle_info.last_dir = last_dir;
	current_vehicle_info.velocity = (current_vehicle_info.position - last_positon)/current_vehicle_info.time_interval;

	add_up_time = current_vehicle_info.time_interval;
	
	SetPosition(current_vehicle_info.position);
	Quaternion q(Vector3(0,0,1), current_vehicle_info.dir);
	SetRotation(q);

	current_vehicle_info.last_position = current_vehicle_info.position;
	current_vehicle_info.velocity = Vector3(0.f,0.f,0.f);
	
	need_update = true;


}