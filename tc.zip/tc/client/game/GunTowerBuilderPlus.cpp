#include "pch.h"
#include <stdio.h>
using namespace Core;
using namespace Client;

DEFINE_PDE_TYPE_CLASS(Client::GunTowerBuilderPlusInfo)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Client::WeaponInfo);

		ADD_PDE_DEFAULT_CONSTRUCTOR();
		ADD_PDE_FIELD(gun_tower_dir);
	}
};

REGISTER_PDE_TYPE(Client::GunTowerBuilderPlusInfo);


enum State
{
	kIdle,
	kPlanted,
};

/// constructor
GunTowerBuilderPlus::GunTowerBuilderPlus(by_ptr(GunTowerBuilderPlusInfo) info)
: on_request_planting(false)
, m_iReqPlantingIndex(-1)
, ammo_count(-1)
, m_iActiveTowerIdx(-1)
{
	weapon_info = tower_info = info;
	state = kIdle;
}

/// destructor
GunTowerBuilderPlus::~GunTowerBuilderPlus()
{
	tempc_ptr(Character) owner = GetOwner();
	if(owner)
	{
		owner->UnLockStateByType(kLSMove);
	}
}

/// update mesh
void GunTowerBuilderPlus::UpdateMesh()
{
	if (state == kPlanted)
		mesh->pose = pose;
	else
		mesh->pose = GetPose();

	mesh->Update();
}

/// draw
void GunTowerBuilderPlus::Draw(Primitive::DrawType drawtype, bool immediate)
{
	if (mesh)
	{
		mesh->SetPosition(GetPosition());
		mesh->SetRotation(GetRotation());
		mesh->Draw(drawtype, immediate);
	}
}

/// initialize
void GunTowerBuilderPlus::Initialize()
{
	WeaponBase::Initialize();

	if (tower_info)
	{
		if (skeleton)
		{
			animation_list = ptr_new AnimationNodeList;
			animation_set = ptr_new AnimationSet;

			if (is_for_player)
			{
				CStrBuf<256> str(ANIMATION_KEY_PROP_PLAYER);

				CStrBuf<256> str_animation;
				str_animation.format("%s/%s", owner->GetCurCharinfo()->first_person_animationset, weapon_info->animation_set);

				if (weapon_info)
					str.contract(str_animation);

				animation_set_player = RESOURCE_GET_BYTYPE(str, ANIMATIONSET_TYPE, AnimationSetRes);
				if (animation_set_player)
				{
					animation_set_player->Load(true);
				}
				animation_set->SetAnimationSet("common", animation_set_player);
			}
			else
			{
				CStrBuf<256> str(ANIMATION_KEY_PROP_CHARACTER);

				CStrBuf<256> str_animation;
				if(owner)
				{
					str_animation.format("%s/%s", owner->GetCurCharinfo()->third_person_animationset, weapon_info->animation_set);

					if (weapon_info)
						str.contract(str_animation);

					animation_set_character = RESOURCE_GET_BYTYPE(str.buff(), ANIMATIONSET_TYPE, AnimationSetRes);
					if (animation_set_character)
					{
						animation_set_character->Load(true);
					}
					animation_set->SetAnimationSet("common", animation_set_character);
				}

			}

			if (animation)
			{
				animation->SetAnimationSet(animation_set);

				sharedc_ptr(AnimationNodePose) node = ptr_new AnimationNodePose(skeleton);
				node->SetAnimation("idle", animation_set);
				animation_list->AddNode("idle", node);

				node = ptr_new AnimationNodePose(skeleton);
				node->SetAnimation("empty", animation_set);
				animation_list->AddNode("empty", node);

				animation_list->SetActiveNode("idle");

				animation->SetAnimationNode(animation_list);
			}

			pose = ptr_new Pose(skeleton);
		}
		SetActiveTower(1);
	}

}

///// udpate
void GunTowerBuilderPlus::Update(float frame_time)
{
	WeaponBase::Update(frame_time);
	
	tempc_ptr(Character) owner = GetOwner();
	tempc_ptr(Character) player = gLevel->GetPlayer(); 

	if(!player || !owner || player != owner)
		return;

	GetHitGridItem();

	tempc_ptr(StateMainGame) state_main = ptr_dynamic_cast<StateMainGame>(gGame->machine.CurrentState());
	if (state_main && !state_main->ui->bFoused && !state_main->IsUIFocused() && CanPlantMore() && !on_request_planting)
	{
		if (gGame->input->IsKeyPressed(MC_LEFT_BUTTON) && CanPlant())
		{
			Plant(able_tower_mesh->GetPosition());
		}

		if(gGame->input->IsKeyPressed(MC_RIGHT_BUTTON))
		{
			ChangeDir();
		}
	}
}

bool GunTowerBuilderPlus::CanPlant()
{
	tempc_ptr(Character) player = GetOwner();

	if((m_iActiveTowerIdx<0) || (m_iActiveTowerIdx >= (int)tower_info->m_aTowerTypeInfo.Size()))
		return false;

	const float fW =tower_info->m_aTowerTypeInfo[m_iActiveTowerIdx].Width;
	const float fH =tower_info->m_aTowerTypeInfo[m_iActiveTowerIdx].Height;

	if(!player)
		return false;
	
	if (!CanPlantMore())
		return false;

	if (!gLevel->IsMachineGunTurretArea(GetPlantPosition()))
		return false;

	if(!gLevel->IsMachineGunTurretAreaInside(GetPlantPosition(), fW, fH))
		return false;

	if (IsExistTower())
		return false;

	//tempc_ptr(Character) owner = GetOwner();
	//if (Length(GetPlantPosition() - owner->GetPosition()) > tower_info->max_distance)
	//	return false;
	
	return true;
}
//// draw UI
void GunTowerBuilderPlus::DrawUI(by_ptr(UIRender) ui_render)
{
	WeaponBase::DrawUI(ui_render);

	Core::CStrBuf<256> buff;

	buff.format("1/%d", 1);
	ui_render->DrawStringShadow(ui_render->font_simhei_24, ARGB(255, 241, 211), ARGB(0,0,0), ARGB(0, 0, 0, 0), Core::Rectangle(-195, 0 - 50, 0, 1), buff, Unit::kAlignLeftBottom);

	buff.format(weapon_info->name);
	buff.toupper();

	ui_render->DrawStringShadow(ui_render->font_simhei_14, ARGB(255, 241, 211), ARGB(0,0,0), ARGB(0, 0, 0, 0), Core::Rectangle(-100, -20, 0, -7), buff, Unit::kAlignCenterBottom);
}
/// can active
bool GunTowerBuilderPlus::CanActive()
{
	return WeaponBase::CanActive();
}

/// active
void GunTowerBuilderPlus::Active()
{
	WeaponBase::Active();
	tempc_ptr(Character) owner = GetOwner();
}

/// inactive
void GunTowerBuilderPlus::Inactive()
{
	WeaponBase::Inactive();
}

/// plant
void GunTowerBuilderPlus::Plant(const Vector3 & pos)
{
	CreatePhysx();
	tempc_ptr(Character) owner = GetOwner();
	if(owner && !CanPlantMore())
	{
		Quaternion q = Quaternion::kIdentity;
		Quaternion q1 = Quaternion::kIdentity;

		q.SetAxisAngle(Vector3(1, 0, 0), HALFPI);
		q1.SetAxisAngle(Vector3(0,1,0), owner->GetRotation().GetZXY().y);
		owner->UnLockStateByType(kLSMove);
		SetRotation(q * q1);
		owner->ChangeWeapon();
	}
}

void GunTowerBuilderPlus::EndPlant()
{
	if(on_request_planting)
	{
		m_iReqPlantingIndex =-1;
		on_request_planting = false;
		FmodSystem::PlayEvent("bj/event/wall_set");
	}
}

/// Get Hit Grid Item
Vector3 GunTowerBuilderPlus::GetHitGridItem()
{
	Vector3 pos =owner->GetCameraPosition();
	Vector3 dir =Vector3(0, 0, -1) * owner->GetCameraRotation();
	NxRay ray;
	ray.orig = (const NxVec3 &)pos;
	ray.dir = (const NxVec3 &)Normalize(dir);

	NxRaycastHit hit;
	uint group_id = 0;
	group_id |= 1 << PhysxSystem::kStatic;
	NxShape* shape = gPhysxScene->raycastClosestShape(ray, NX_ALL_SHAPES, hit, group_id, 10000);
	if (shape)
	{
		/*Console.WriteLinef("%f,%f,%f", hit.worldImpact.x, hit.worldImpact.y, hit.worldImpact.z);
		Console.WriteLinef("%f,%f,%f", pos.x, pos.y, pos.z);*/
		//Console.WriteLinef("%f,%f,%f", dir.x, dir.y, dir.z);

		const Vector2 vMapSize =GetMapSize();
		const float fW =vMapSize.x, fH =vMapSize.y;

		const Vector2 vItemSize =GetGridItemSize();
		const float fItemW =vItemSize.x, fItemH =vItemSize.y;

		const int iMaxX =(int)(fW / fItemW) - 1;
		const int iMaxZ =(int)(fH / fItemH) - 1;
		const int iX =(int)((hit.worldImpact.x + fW/2.f) / fItemW);
		const int iZ =(int)((hit.worldImpact.z + fH/2.f) / fItemH);

		return Vector3((float)iX, hit.worldImpact.y, (float)iZ);
	}
	return Vector3(0, -10000, 0);
}

Core::Vector3 GunTowerBuilderPlus::GetPlantPosition()
{
	const Vector2 vMapSize =GetMapSize();
	const float fW =vMapSize.x, fH =vMapSize.y;

	const Vector3 vItemSlot =GetHitGridItem();
	const Vector2 vItemSize =GetGridItemSize();
	const Vector2 vMaxItemCount(vMapSize.x/vItemSize.x, vMapSize.y/vItemSize.y);
	const float fX =-0.5f*fW + ((vItemSlot.x+0.5f)/vMaxItemCount.x) * fW;
	const float fZ =-0.5f*fH + ((vItemSlot.z+0.5f)/vMaxItemCount.y) * fH;

	/*Console.WriteLinef("PP:%f,%f,%f", fX, vItemSlot.y, fZ);*/
	return Vector3(fX, vItemSlot.y, fZ);
}
Core::Quaternion GunTowerBuilderPlus::GetPlantRotation()
{
	return Quaternion(Vector3(0,1,0), PI * (GetGunTowerDir()) / 2);
}
Core::Vector2 GunTowerBuilderPlus::GetGridItemSize()
{
	return Vector2(gLevel->GetEditMapItemSize(), gLevel->GetEditMapItemSize());
}
Core::Vector2 GunTowerBuilderPlus::GetGridItemCount()
{
	const Vector2 vMap =GetMapSize();
	const Vector2 vItem =GetGridItemSize();
	return Vector2(vMap.x/vItem.x, vMap.y/vItem.y);
}
Core::Vector2 GunTowerBuilderPlus::GetMapSize()
{
	return Vector2(gLevel->GetEditMapWidth(), gLevel->GetEditMapHeight());
}
/// Try Create Tower
int GunTowerBuilderPlus::GetTowerTypeCount()const
{
	return (int)tower_info->m_aTowerTypeInfo.Size();
}
GunTowerTypeInfo GunTowerBuilderPlus::GetTowerType(int iIdx)const
{
	return tower_info->m_aTowerTypeInfo[iIdx];
}
bool GunTowerBuilderPlus::TryCreateTower()
{
	const int iIdx =m_iActiveTowerIdx;
	if(iIdx>=0 && iIdx<GetTowerTypeCount())
	{
		const String szRes =tower_info->m_aTowerTypeInfo[iIdx].ResKey;
		const int iDummyObjectType =tower_info->m_aTowerTypeInfo[iIdx].DummyObjectType;
		const byte iDummyObjectSubType = tower_info->m_aTowerTypeInfo[iIdx].DummyObjectSubType;
		DummyBaseCreateInfo info;
		info.position = GetPlantPosition();
		info.rotation = GetPlantRotation();
		info.life_time = tower_info->max_lift_time;

		//if(owner && owner->GetTeam() < 2)
		//{
		//	sprintf_s(info.key, sizeof(info.key), "%s_%d/rv1", szRes.Str(), owner->GetTeam());
		//	sprintf_s(info.tower_key, sizeof(info.tower_key), "%s", szRes.Str());
		//}
		//else
		//{
		//	sprintf_s(info.key, sizeof(info.key), "%s_0/rv1", szRes.Str());
		//	sprintf_s(info.tower_key, sizeof(info.tower_key), "%s", szRes.Str());
		//}
		//if(owner && owner->GetTeam() < 2)
		//{
		//	sprintf_s(info.key, sizeof(info.key), "%s_%d/rv1", szRes.Str(), owner->GetTeam());
		//	sprintf_s(info.tower_key, sizeof(info.tower_key), "%s", szRes.Str());
		//}
		//else
		//{
		sprintf_s(info.key, sizeof(info.key), "%s_0/rv1", szRes.Str());
		sprintf_s(info.tower_key, sizeof(info.tower_key), "%s", szRes.Str());
		//}

		char buffer[SYNC_BUFFER_SIZE];
		int length = writeUserData(buffer,SYNC_BUFFER_SIZE,info);
		gGame->channel_connection->RequestDummyObjectCreate(iDummyObjectType, buffer, length, iDummyObjectSubType);
		return true;
	}
	return false;
}
void GunTowerBuilderPlus::SetActiveTower(const int iIdx)
{
	if(m_iActiveTowerIdx == iIdx) return;
	if(iIdx>=0 && iIdx< (int)tower_info->m_aTowerTypeInfo.Size())
	{
		m_iActiveTowerIdx =iIdx;
	
		//able mesh
		GunTowerTypeInfo& oTypeInfo =tower_info->m_aTowerTypeInfo[m_iActiveTowerIdx];
		const char* szStr =oTypeInfo.ResKey.Str();
		if(szStr == strstr(szStr, "guard_"))
		{
			able_tower_mesh = ptr_new StaticMesh("/mesh/dummy/");
			able_tower_mesh->AddPrimitive("guard_G.mesh", 0);

			unable_tower_mesh = ptr_new StaticMesh("/mesh/dummy/");
			unable_tower_mesh->AddPrimitive("guard_R.mesh", 0);
		}
		else if(szStr == strstr(szStr, "resource_"))
		{
			able_tower_mesh = ptr_new StaticMesh("/mesh/dummy/");
			able_tower_mesh->AddPrimitive("resource_G.mesh", 0);

			unable_tower_mesh = ptr_new StaticMesh("/mesh/dummy/");
			unable_tower_mesh->AddPrimitive("resource_R.mesh", 0);
		}
		else if(szStr == strstr(szStr, "wall_"))
		{
			able_tower_mesh = ptr_new StaticMesh("/mesh/dummy/");
			able_tower_mesh->AddPrimitive("wall_G.mesh", 0);

			unable_tower_mesh = ptr_new StaticMesh("/mesh/dummy/");
			unable_tower_mesh->AddPrimitive("wall_R.mesh", 0);
		}
		else
		{
			able_tower_mesh = ptr_new StaticMesh("/mesh/dummy/");
			able_tower_mesh->AddPrimitive("guard_G.mesh", 0);

			unable_tower_mesh = ptr_new StaticMesh("/mesh/dummy/");
			unable_tower_mesh->AddPrimitive("guard_R.mesh", 0);
		}

		//������
		CStrBuf<256> str_tower_res_key;
		str_tower_res_key.format("%s", oTypeInfo.ResKey.Str());
		const int iLen =str_tower_res_key.len();
		const int iLastSep =str_tower_res_key.rfind('_');
		if(-1 == iLastSep)return;
		str_tower_res_key.remove(iLastSep, iLen);
		String szPrefix(str_tower_res_key);

		CStrBuf<256> str_tower_direction_mesh;
		str_tower_direction_mesh.format("%s_wire.mesh", szPrefix.Str());

		//MessageBoxA(0, str_tower_direction_mesh, str_tower_direction_mesh, 0);

		tower_direction_mesh = ptr_new StaticMesh("/mesh/dummy/");
		tower_direction_mesh->AddPrimitive(str_tower_direction_mesh, 0);
	}
}
int GunTowerBuilderPlus::GetActiveTower()const
{
	return m_iActiveTowerIdx;
}

/// create physx
void GunTowerBuilderPlus::CreatePhysx()
{
	//SetActiveTower(rand() % (int)(tower_info->m_aTowerTypeInfo.Size()));
	if(on_request_planting = TryCreateTower())
	{
		m_iReqPlantingIndex =m_iActiveTowerIdx;
	}
}

/// get position
const Vector3 & GunTowerBuilderPlus::GetPosition()
{
	return position;
}

/// set position
void GunTowerBuilderPlus::SetPosition(const Core::Vector3 & pos)
{
	position = pos;
}

int GunTowerBuilderPlus::GetGunTowerDir()
{
	return tower_info->gun_tower_dir;
}

void GunTowerBuilderPlus::ChangeDir()
{
	tower_info->gun_tower_dir = (tower_info->gun_tower_dir + 1) % 4;
	FmodSystem::PlayEvent("bj/event/wall_rotation");
}

const Core::Vector3 GunTowerBuilderPlus::GetTowerMeshPosition(const Vector3 & pos)
{
	Vector3 towermeshposition;
	Vector3 dir = Vector3(0, -1, 0);
	NxRay ray;
	NxRaycastHit hit;
	const float distance = 500.f;
	ray.orig = (const NxVec3 &)pos;
	ray.dir = (const NxVec3 &)dir;
	uint group_id = 0;
	group_id |= 1 << PhysxSystem::kStatic;
	NxShape* shape = gPhysxScene->raycastClosestShape(ray, NX_ALL_SHAPES, hit, group_id, distance);
	if (shape)
	{
		towermeshposition = (Vector3&)hit.worldImpact;
	}
	
	return towermeshposition;
}

bool GunTowerBuilderPlus::IsExistTower()
{
	HashSet<uint, sharedc_ptr(DummyObject)>::Enumerator it(gLevel->dummy_object_set);
	while (it.MoveNext())
	{
		tempc_ptr(DummyObject) d = it.Value();
		const GunTowerTypeInfo oGTTI =tower_info->m_aTowerTypeInfo[m_iActiveTowerIdx];
		const Vector3 pos_builder(GetPlantPosition());
		const float w_builder =oGTTI.Width;
		const float h_builder =oGTTI.Height;
		Core::Rectangle rt_builder(pos_builder.x - w_builder/2, pos_builder.z - h_builder/2, pos_builder.x + w_builder/2, pos_builder.z + h_builder/2);

		const Vector3 pos_dummy(d->GetPosition());
		const float w_dummy =d->dummyobjectinfo->outer_width;
		const float h_dummy =d->dummyobjectinfo->outer_height;
		Core::Rectangle rt_dummy(pos_dummy.x - w_dummy/2, pos_dummy.z - h_dummy/2, pos_dummy.x + w_dummy/2, pos_dummy.z + h_dummy/2);

		if(rt_builder.IsIntersect(rt_dummy))
		{
			//Console.WriteLinef("already exist tower");
			return true;
		}
	}
	return false;
}

bool GunTowerBuilderPlus::HasStatic()
{
	Vector3 dir = Vector3(0, 0, -1); 
	NxRay ray;
	NxRaycastHit hit;
	const float distance = Length(able_tower_mesh->GetPosition() - owner->GetCameraPosition());
	ray.orig = (const NxVec3 &)owner->GetCameraPosition();
	ray.dir = (const NxVec3 &)(able_tower_mesh->GetPosition() - owner->GetCameraPosition());
	ray.dir.normalize();
	uint group_id = 0;
	group_id |= 1 << PhysxSystem::kStatic;
	NxShape* shape = gPhysxScene->raycastClosestShape(ray, NX_ALL_SHAPES, hit, group_id, distance);
	if (shape)
	{
		if(hit.distance <= distance * 0.95f)
		{
			return true;
		}
	}
	return false;
}

int GunTowerBuilderPlus::GetAmmoCount()
{
	return ammo_count;
}

void GunTowerBuilderPlus::SetAmmoCount(int ammocount)
{
	if (ammocount > GetMaxAmmoCount())
		ammo_count = GetMaxAmmoCount();
	else
		ammo_count = ammocount;
}

int GunTowerBuilderPlus::GetMaxAmmoCount()
{
	Attribute attrinfo;
	tower_info->CheckWeaponAttribute(kWeaponAttr_Turret_AmmoOneClipInfect, attrinfo);
	return tower_info->ammo_one_clip * (owner->GetTotalAttributeByType(kEffect_Infect_AmmoOneClip) + (attrinfo.value1 / 100.f));
}
bool GunTowerBuilderPlus::CanPlantMore()
{
	if((m_iActiveTowerIdx<0) || (m_iActiveTowerIdx >= (int)tower_info->m_aTowerTypeInfo.Size()))
		return false;
	//С��������
	GunTowerTypeInfo& oInfo =tower_info->m_aTowerTypeInfo[m_iActiveTowerIdx];
	const int iCnt =gLevel->GetDummyObjectCount(oInfo.DummyObjectType, oInfo.ResKey);
	if(iCnt >= oInfo.MaxCount) return false;

	//����������
	const int iClassCnt =gLevel->GetDummyObjectCountBySubType(oInfo.DummyObjectSubType);
	if(oInfo.DummyObjectSubType == DummyObject::SUBTYPE_WALL)
	{
		return iClassCnt < tower_info->m_iMaxWallCount;
	}
	else if(oInfo.DummyObjectSubType == DummyObject::SUBTYPE_GUARD)
	{
		return iClassCnt < tower_info->m_iMaxGuardCount;
	}
	else
	{
		return false;
	}
}

void GunTowerBuilderPlus::DestroyTower(const int type, const String& szResKey)
{
	//const int iCnt =GetTowerTypeCount();
	//for(int i=0; i<iCnt; ++i)
	//{
	//	GunTowerTypeInfo& oInfo =tower_info->m_aTowerTypeInfo[i];
	//	if(oInfo.DummyObjectType == type && oInfo.ResKey == szResKey)
	//	{
	//		oInfo.Count -=1;
	//		return;
	//	}
	//}
}

void GunTowerBuilderPlus::DestroyTower(sharedc_ptr(DummyObject) oDummy)
{
	if(!gGame || !gGame->channel_connection || !oDummy || !oDummy->dummyobjectinfo) return;
	gGame->channel_connection->RequestDummyObjectDestory(oDummy->dummyobjectinfo->dummy_id);
}
int GunTowerBuilderPlus::GetSystemId(const int type, const Core::String& szResKey)
{
	const int iCnt =GetTowerTypeCount();
	for(int i=0; i<iCnt; ++i)
	{
		GunTowerTypeInfo& oInfo =tower_info->m_aTowerTypeInfo[i];
		if(oInfo.DummyObjectType == type && oInfo.ResKey == szResKey)
		{
			return oInfo.SystemId;
		}
	}
	return -1;
}