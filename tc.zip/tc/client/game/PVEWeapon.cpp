#include "pch.h"

using namespace Core;

DEFINE_PDE_TYPE_CLASS(Client::PhysxDesc)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_FIELD(position);
		ADD_PDE_FIELD(rotation);
		ADD_PDE_FIELD(can_hitstatic);
	}
};

DEFINE_PDE_TYPE_CLASS(Client::BoxDesc)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Client::PhysxDesc);

		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_FIELD(dimensions);
	}
};

DEFINE_PDE_TYPE_CLASS(Client::CapsuleDesc)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Client::PhysxDesc);

		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_FIELD(radius);
		ADD_PDE_FIELD(height);
	}
};

DEFINE_PDE_TYPE_ENUM(Client::PVEWeaponType)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_ENUM_ITEM("kPVEWeaponTypeNone",	Client::kPVEWeaponTypeNone);
		ADD_PDE_ENUM_ITEM("kPVEWeaponTypeLuncher",	Client::kPVEWeaponTypeLuncher);
		ADD_PDE_ENUM_ITEM("kPVEWeaponTypeLaser",	Client::kPVEWeaponTypeLaser);
	}
};

DEFINE_PDE_TYPE_CLASS(Client::PVEWeaponInfo)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_FIELD(fire_interval);
		ADD_PDE_FIELD(first_fire_time);
		
		ADD_PDE_DEFAULT_CONSTRUCTOR();
	}
};

REGISTER_PDE_TYPE(Client::PhysxDesc);
REGISTER_PDE_TYPE(Client::BoxDesc);
REGISTER_PDE_TYPE(Client::CapsuleDesc);
REGISTER_PDE_TYPE(Client::PVEWeaponType);
REGISTER_PDE_TYPE(Client::PVEWeaponInfo);

//////////////////////////////////////////////////////////////
static uint GenPVEWeaponUid()
{
	static uint uid_gen = 0;

	return uid_gen++;
}
//////////////////////////////////////////////////////////////
namespace Client
{
	PVEWeaponInfo::PVEWeaponInfo()
		: weapon_type(kPVEWeaponTypeNone)
		, fire_interval(0)
		, first_fire_time(0)
	{
	}

	PVEWeaponBase::PVEWeaponBase()
		: m_Uid(GenPVEWeaponUid())
	{
	}

	PVEWeaponBase::~PVEWeaponBase()
	{
	}

	bool PVEWeaponBase::Initialize(const Core::String &name, by_ptr(Character) c, by_ptr(PVEWeaponInfo) info)
	{
		if (name.Length() == 0 || !c || !info)
			return false;

		m_Name = name;
		m_Owner = c;
		m_WeaponInfo = info;

		return true;
	}

	void PVEWeaponBase::Update(float time)
	{
		tempc_ptr(Character) owner = GetOwner();

		if (!owner)
			return;

		String fire_interval_key;
		GetFireIntervalKey(fire_interval_key);

		float fire_interval = owner->GetClientSynScriptNumberValue(fire_interval_key);
		fire_interval -= time;
		if (fire_interval < 0)
			fire_interval = 0;
		owner->SetClientSynScriptNumberValue(fire_interval_key, fire_interval);
		//LogSystem.WriteLinef("fire_interval = %f",fire_interval);
	}

	void PVEWeaponBase::TimeStepUpdate(float time)
	{
	}

	void PVEWeaponBase::Draw(Primitive::DrawType drawtype, bool immediate)
	{
	}

	bool PVEWeaponBase::CanFire()
	{
		tempc_ptr(Character) owner = GetOwner();

		if (!owner)
			return false;

		String fire_interval_key;
		GetFireIntervalKey(fire_interval_key);

		float fire_interval = owner->GetClientSynScriptNumberValue(fire_interval_key);

		return fire_interval <= 0;
	}

	void PVEWeaponBase::FireStart()
	{
	}

	void PVEWeaponBase::FireDone()
	{
		tempc_ptr(Character) owner = GetOwner();

		if (!owner)
			return;

		String fire_interval_key;
		GetFireIntervalKey(fire_interval_key);

		owner->SetClientSynScriptNumberValue(fire_interval_key, m_WeaponInfo->fire_interval);
	}

	void PVEWeaponBase::Reset()
	{
	}

	tempc_ptr(Character) PVEWeaponBase::GetOwner()
	{
		return m_Owner;
	}

	tempc_ptr(PVEWeaponInfo) PVEWeaponBase::GetWeaponInfo()
	{
		return m_WeaponInfo;
	}

	uint PVEWeaponBase::GetUid()
	{
		return m_Uid;
	}

	void PVEWeaponBase::GetFireIntervalKey(Core::String &value)
	{
		value = String::Format("PVEWeapon[%d]_FireInterval", GetUid());
	}

	//////////////////////////////////////////////////////////////////////
	sharedc_ptr(PVEWeaponBase) CreatePVEWeapon(PVEWeaponType type)
	{
		sharedc_ptr(PVEWeaponBase) weapon;

		switch (type)
		{
		case kPVEWeaponTypeLuncher:
			weapon = ptr_new PVELuncher();
			break;
		case kPVEWeaponTypeLaser:
			weapon = ptr_new PVELaser();
			break;

		default:
			break;
		}

		return weapon;
	}
}
