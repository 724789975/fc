namespace Client
{
	struct LevelEvent : public Core::Object
	{
		LevelEvent();

		SIMPLE_PDE_ATTRIBUTE_RW(Name, Core::Identifier);
		DECLARE_PDE_EVENT(EventOperate, Core::EventArgs);
	};

	class LevelEventMgr : public Core::Object
	{
	public:
		LevelEventMgr();

		~LevelEventMgr();

	public:
		void Initialize();

		void Terminate();

		void Reset();

		void TimeStepUpdate(float frame_time);

	public:
		bool LoadEventScript(const Core::String &file_name);

		bool AddFrameEvent(by_ptr(LevelEvent) frame_event);

		void DebugOutput(const Core::String &text);

	public:
		void SetClientScriptStringValue(const Core::String &key, const Core::String &value);

		Core::String GetClientScriptStringValue(const Core::String &key);

		bool HasClientScriptStringValue(const Core::String &key);

		void SetClientScriptNumberValue(const Core::String &key, float value);

		float GetClientScriptNumberValue(const Core::String &key);

		bool HasClientScriptNumberValue(const Core::String &key);

		void ClearClientScriptValue();

	public:
		void SetServerScriptStringValue(const Core::String &key, const Core::String &value);

		Core::String GetServerScriptStringValue(const Core::String &key);

		bool HasServerScriptStringValue(const Core::String &key);

		void SetServerScriptNumberValue(const Core::String &key, float value);

		float GetServerScriptNumberValue(const Core::String &key);

		bool HasServerScriptNumberValue(const Core::String &key);

		void ClearServerScriptValue();

	private:
		Core::HashSet<Core::String, Core::String> m_ClientScriptStringValue;
		Core::HashSet<Core::String, float> m_ClientScriptNumberValue;
		Core::HashSet<Core::String, Core::String> m_ServerScriptStringValue;
		Core::HashSet<Core::String, float> m_ServerScriptNumberValue;

		Core::HashSet<Core::String, sharedc_ptr(LevelEvent)> m_FrameEventMap;
		
		Lua::LuaState* m_LuaState;
		float m_timer;
	};
}
