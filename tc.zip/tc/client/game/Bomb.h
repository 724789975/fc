namespace Client
{
	struct BombInfo : public WeaponInfo
	{
		float plant_time;
		float defuse_time;
		float defuse_with_item_time;
		Core::Identifier bag;
		Core::Identifier bag_skeleton;
		Core::Identifier character_bag;

		Core::Identifier particle_explode;

		Core::Identifier sound_explode;
		Core::Identifier sound_plant;
		Core::Identifier sound_defuse;
		Core::Identifier sound_click_2d;
		Core::Identifier sound_click_3d;
		Core::Identifier sound_beep1;
		Core::Identifier sound_beep2;
		Core::Identifier sound_beep3;
		Core::Identifier sound_beep4;
		Core::Identifier sound_beep5;

		BombInfo()
		{
			plant_time = 0.f;
			defuse_with_item_time = 10.f;
			defuse_time = 15.f;
		}
	};

#define BOMB_SLOT 4
	class Bomb : public WeaponBase
	{
	public:
		/// constructor
		Bomb(by_ptr(BombInfo) info);

		/// destructor
		virtual ~Bomb();

		/// get weapon type
		virtual uint GetWeaponType() { return kWeaponTypeBomb; }

	public:
		/// draw
		virtual void Draw(Primitive::DrawType drawtype, bool immediate = false);

		/// initialize
		virtual void Initialize();

		/// udpate
		virtual void Update(float frame_time);

		/// can active
		virtual bool CanActive();

		/// active
		virtual void Active();

		/// inactive
		virtual void Inactive();

		/// update mesh
		virtual void UpdateMesh();

		/// draw ui
		virtual void DrawUI(by_ptr(UIRender) ui_render);
	public:
		/// get position
		virtual const Core::Vector3 & GetPosition();

		/// set position
		virtual void SetPosition(const Core::Vector3 & pos);

		/// plant
		void Plant(const Core::Vector3 & position);

		/// plant bomb
		void PlantBomb();

		/// stop plant bomb
		void StopPlantBomb();

		/// create physx
		void CreatePhysx();

		bool CanPlant();

	public:
		sharedc_ptr(BombInfo)	bomb_info;
		bool					draw_bag;
		bool					bomb_planting;
		bool					on_request_planting;
		
	private:
		NxActor*	actor;
		byte		state;
		sharedc_ptr(SkinMesh) bag_mesh;
		sharedc_ptr(Skeleton) bag_skeleton;
		sharedc_ptr(Pose)	 bag_pose;
	

	};
}