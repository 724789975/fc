#include "pch.h"

using namespace Core;
using namespace Client;

#define GATE_ACTION_TIME 0.3f
#define GATE_UPDATE_INTERVAL 0.2f

namespace Client
{
	/// constructor
	GateBase::GateBase(by_ptr(GateInfo) info)
	{
		gate_info = info;
		status = CLOSED;
		action_timer = -1.f;
		gate_update_timer = GATE_UPDATE_INTERVAL;
		can_move = true;

		activetime = -1.f;

		is_active = info->active_state_default;
	}

	/// destructor
	GateBase::~GateBase()
	{
		ReleasePhysX();

		for (uint i = 0; i < mesh_arry.Size(); i++)
		{
			mesh_arry[i] = NullPtr;
		}
		mesh_arry.Clear();

		gate_info = NullPtr;
	}

	void GateBase::ReleasePhysX()
	{
		for (uint i = 0; i < actor_arry.Size(); i++)
		{
			NxActor* actor = actor_arry[i];
			PhysxSystem::ReleaseActor(*actor);
		}
		actor_arry.Clear();

		PhysxSystem::ReleaseActor(*collider);
		collider = NULL;
	}

	/// initialize
	void GateBase::Initialize()
	{

		CreateMesh();

		SetPosition(gate_info->position);

		float distance = Length(gate_info->position - gate_info->target_position);
		if(distance < 0.05f)
		{
			can_move = false;
		}

		CreatePhysx();
	}

	void GateBase::SetPosition(Vector3& pos)
	{
		for (uint i = 0; i < mesh_arry.Size(); i++)
		{
			tempc_ptr(StaticMesh) p = mesh_arry[i];
			p->SetPosition(pos);
			p->SetRotation(gate_info->rotation);
		}
		base_Position[0] = pos;
		target_Position[0] = gate_info->target_position;
		current_Position[0] = pos;
	}

	/// update
	void GateBase::Update(float frame_time)
	{
		if(gate_update_timer < GATE_UPDATE_INTERVAL)
		{
			bool open_flag = false;
			gate_update_timer = GATE_UPDATE_INTERVAL;
			
			tempc_ptr(Character) player = gLevel->GetPlayer();
			if(player)
			{
				if (player && player->GetTeam() == gate_info->team)
				{
					if(gate_aabb.IsPointInside(player->GetPosition()))
					{
						AddOpenRef();
						open_flag = true;
					}
				}
			}
			
			if(!open_flag)
			{
				const Array<sharedc_ptr(Character)> & characters = gLevel->GetCharacters();
				for (U32 i = 0; i < characters.Size(); i++)
				{
					if (characters[i] && characters[i]->GetTeam() == gate_info->team)
					{
						if(gate_aabb.IsPointInside(characters[i]->GetPosition()))
						{
							AddOpenRef();
							open_flag = true;
							break;
						}
					}
				}
			}

			
			if(!open_flag && status == OPENED)
			{
				AddCloseRef();
			}
		}
		gate_update_timer -= frame_time;


		UpdatePosition(frame_time);
		for (uint i = 0; i < mesh_arry.Size(); i++)
		{
			tempc_ptr(StaticMesh) p = mesh_arry[i];
			p->Update();
		}

		if (activetime < 0.f && activetime > -1.f)
		{
			is_active = true;
		}
		else if (activetime >= 0.f)
		{
			activetime -= frame_time;
		}

		UpdatePhysX();
	}

	void GateBase::SetActiveTime(float time)
	{
		if (!is_active && time > 0)
		{
			activetime = time;
		}
		else
		{
			LogSystem.WriteLinef("GateBase::SetActiveTime error");
		}
	}

	tempc_ptr(GateBase) GateBase::FromNxActor(NxActor & actor)
	{
		Object * obj = (Object*)actor.userData;

		if (obj)
		{
			return ptr_dynamic_cast<GateBase>(obj);
		}

		return NullPtr;
	}

	void GateBase::UpdatePosition(float frame_time)
	{
		//���ڴ�
		if(status == RAISE)
		{
			action_timer< 0 ? action_timer = frame_time : action_timer += frame_time;
			if(action_timer < GATE_ACTION_TIME)
			{
				Vector3 vec = base_Position[0] + (target_Position[0] - base_Position[0]) / GATE_ACTION_TIME * action_timer;

				SetAllMeshCurrentPos(vec);				
			}
			else
			{
				SetAllMeshCurrentPos(target_Position[0]);
				status = OPENED;
			}
		}
		//���ڹر�
		else if(status == FALL)
		{
			action_timer< 0 ? action_timer = frame_time : action_timer += frame_time;
			if(action_timer < GATE_ACTION_TIME)
			{
				Vector3 vec = target_Position[0] - (target_Position[0] - base_Position[0]) / GATE_ACTION_TIME * action_timer;

				SetAllMeshCurrentPos(vec);
			}
			else
			{
				SetAllMeshCurrentPos(base_Position[0]);
				status = CLOSED;
			}
		}
	}

	void GateBase::UpdatePhysX()
	{
		collider->setGlobalPosition((const NxVec3 &)mesh_arry[0]->GetPosition());

	}

	/// draw
	void GateBase::Draw(Primitive::DrawType drawtype, bool immediate)
	{
		float f = 0;
		if(!can_move && (status == OPENED || status == RAISE))
		{
			f = 1.f;
		}
		gDx9Device->SetPixelShaderConstantF(PS_CONSTANT_GATE_STATE, &f);
		for (uint i = 0; i < mesh_arry.Size(); i++)
		{
			tempc_ptr(StaticMesh) p = mesh_arry[i];
			p->Draw(drawtype,immediate);
		}
	}

	int GateBase::GetID()
	{
		return gate_info->id;
	}

	void GateBase::CreatePhysx()
	{
		collider=PhysxSystem::CreateBox(base_Position[0], gate_info->gate_collision_box_dim, PhysxSystem::kStatic);
		collider->userData = this;
		collider->setLinearVelocity(NxVec3(0.f, 0.f, 0.f));
		collider->setAngularVelocity(NxVec3(0.f, 0.f, 0.f));
		collider->setGlobalPosition((const NxVec3 &)(gate_info->position));
		collider->raiseBodyFlag(NX_BF_KINEMATIC);;

		CreateTrigger();
	}

	void GateBase::CreateMesh()
	{
		sharedc_ptr(StaticMesh) gate = ptr_new StaticMesh(MESH_KEY_PROP);
		CStrBuf<128> buff;
		buff.format("Gate/%s", gate_info->gate_mesh_name);
		gate->AddPrimitive(buff,0);
		mesh_arry.Add(gate);
	}

	void GateBase::CreateTrigger()
	{
		gate_aabb = AxisAlignedBox(gate_info->position - gate_info->check_dim, gate_info->position + gate_info->check_dim);
	}
	
	void GateBase::AddOpenRef()
	{
		if(status == CLOSED && is_active)
		{
			status = RAISE;
			action_timer = -0.5f;
			FMOD_VECTOR vel = {0, 0, 0};
			FmodSystem::Play3DEvent("bj/ambience/door",(const FMOD_VECTOR &)GetCurPosition(),vel);
		}
	}

	void GateBase::AddCloseRef()
	{
		if(status == OPENED && is_active)
		{
			status = FALL;
			action_timer = -0.5f;
			FMOD_VECTOR vel = {0, 0, 0};
			FmodSystem::Play3DEvent("bj/ambience/door",(const FMOD_VECTOR &)GetCurPosition(),vel);
		}
	}

	int GateBase::GetStatus()
	{
		return status;
	}

	Vector3 GateBase::GetCurPosition()
	{
		return current_Position[0];
	}

	void GateBase::ResetGate()
	{

		for (uint i = 0; i < mesh_arry.Size(); i++)
		{
			tempc_ptr(StaticMesh) p = mesh_arry[i];
			p->SetPosition(base_Position[i]);
		}

		status = CLOSED;
	}

	void GateBase::SetAllMeshCurrentPos(const Core::Vector3& v)
	{
		for (uint i = 0; i < mesh_arry.Size(); i++)
		{
			tempc_ptr(StaticMesh) p = mesh_arry[i];
			p->SetPosition(v);
		}
	}

	bool GateBase::IsActive()
	{		
		return is_active;
	}

	void GateBase::ResetActiveState()
	{
		is_active = gate_info->active_state_default;
		activetime = -1.f;
	}
}