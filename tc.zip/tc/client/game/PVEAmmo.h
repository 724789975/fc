namespace Client
{
	struct PVEAmmoInfo : public Core::Object
	{
		enum PVEAmmoType
		{
			kPVEAmmoType_HitExplode,
			kPVEAmmoType_HitThrough,
		};

		enum PVEAmmoControlType
		{
			kControlType_None,
			kControlType_Trace,
		};

		int ammo_type;
		float maxalive_time;
		float explode_range;
		float explode_damage;
		float hit_interval;
		float hit_damage;

		int controltype;
		float anglelimit;
		float triggertime;
		float triggerofftime;

		bool hurtself;
		bool ignorewall;

		float lockweight_fly;
		float lockweight_rot;

		Core::Identifier hit_decal;
		Core::Identifier explode_particle;
		Core::Identifier explode_sound;
		Core::Identifier fly_particle;
		Core::Identifier fly_sound;
		Core::Identifier fire_sound;
		Core::Identifier fly_joint_name;

		Core::Array<BoxDesc> boxdescs;
		Core::Array<CapsuleDesc> capsuledescs;

		Core::Identifier mesh[MESH_LOD_LEVEL];
		Core::Identifier skeleton;

		Core::AxisAlignedBox AABB;

		PVEAmmoInfo()
			: ammo_type(kPVEAmmoType_HitExplode)
			, maxalive_time(0)
			, explode_range(0)
			, explode_damage(0)
			, hit_interval(1)
			, hit_damage(0)

			, controltype(kControlType_None)
			, anglelimit(0)
			, triggertime(0)
			, triggerofftime(0)

			, hurtself(false)
			, ignorewall(false)

			, lockweight_fly(1.f)
			, lockweight_rot(1.5f)
		{
			AABB = Core::AxisAlignedBox::kInvalid;
		}

		void AddBoxDesc(by_ptr(BoxDesc) desc)
		{
			boxdescs.PushBack(*desc);
		}

		void AddCapsuleDesc(by_ptr(CapsuleDesc) desc)
		{
			capsuledescs.PushBack(*desc);
		}

		void SetMesh(const Core::Identifier & value, const U32 lod_level = 0);

		void SetAABB(const Core::Vector3& vMin, const Core::Vector3& vMax)
		{
			AABB.Min = vMin;
			AABB.Max = vMax;
		}
	};

	class SkinMesh;
	class PVEAmmo : public Core::Object
	{
	public:
		/// sync data
		struct SyncData
		{
			float				time;
			Core::Vector3		position;
			Core::Quaternion	rotation;
		};

	public:
		PVEAmmo();

		~PVEAmmo();

	public:
		/// initialize
		bool Initialize(U16 ammo_id, by_ptr(PVEAmmoInfo) ammo_info, by_ptr(Character) owner, bool is_boost, 
						const Core::Vector3 &pos, const Core::Vector3 &vel);

		/// update
		void Update(float frame_time);

		/// on render
		void OnRender(float frame_time);

		/// timestep update
		void TimeStepUpdate(float frame_time);

		/// draw
		void Draw(Primitive::DrawType drawtype, bool immediate = false);

		/// on impact
		void OnImpact(NxSweepQueryHit *hits, U32 num);

		/// on lock
		void OnLock(by_ptr(Character) c);

		/// on dead
		void OnDead();

	public:
		/// is dead
		bool IsDead();

		/// get id
		U16 GetId();

		/// get ammoinfo
		tempc_ptr(PVEAmmoInfo) GetAmmoInfo();

		/// get position
		const Core::Vector3 & GetPosition();

		/// set position
		void SetPosition(const Core::Vector3 & pos);

		/// move position
		void MovePosition(const Core::Vector3 & pos);

		/// get rotation
		const Core::Quaternion & GetRotation();

		/// set rotation
		void SetRotation(const Core::Quaternion & rot);

		/// move rotation
		void MoveRotation(const Core::Quaternion & rot);

		/// get Velocity
		const Core::Vector3& GetVelocity();

		/// set Velocity
		void SetVelocity(const Core::Vector3 &velocity);

	public:
		/// UpdateSyncData
		void UpdateSyncData(float frame_time);

		/// AddSyncData
		void AddSyncData(byte time, const Core::Vector3 &position, const Core::Vector3 &direction);

		/// HasSyncData
		bool HasSyncData();

	public:
		/// from nx actor
		static tempc_ptr(PVEAmmo) FromNxActor(NxActor & actor);

	private:
		void CreatePhysx(int group, const Core::Vector3 &pos, const Core::Quaternion &rot);

		void ReleasePhysx();

		void StopPhysx();

		/// get joint info
		bool GetJointInfo(int joint_id, Core::Vector3 *pos, Core::Quaternion *rot);

	private:
		sharedc_ptr(PVEAmmoInfo) m_AmmoInfo;
		tempc_ptr(Character) m_Owner;

		NxActor *m_Actor;
		NxSweepCache *m_SweepCache;

		int m_FlyJointId;
		FMOD::Event *m_FlySound;
		FMOD::Event *m_FireSound;
		sharedc_ptr(ParticleSystem) m_FlyParticle;
		sharedc_ptr(SkinMesh) m_Mesh;
		sharedc_ptr(Skeleton) m_Skeleton;
		sharedc_ptr(Pose) m_Pose;
		sharedc_ptr(AnimationSet) m_AnimationSet;

		bool m_CanSee;

		U16 m_AmmoId;
		Core::HashSet<byte, float> m_HitCharacters;

		byte m_LockUid;
		float m_FlyTime;
		bool m_IsHitted;

		Core::Vector3 m_Velocity;
		Core::Vector3 m_Position;
		Core::Quaternion m_Rotation;

		float m_SyncTime;
		Core::Deque<SyncData> m_SyncData;
	};
}