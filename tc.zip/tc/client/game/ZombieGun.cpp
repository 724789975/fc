#include "pch.h"

using namespace Core;
using namespace Client;

DEFINE_PDE_TYPE_CLASS(Client::ZombieGunInfo)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Client::WeaponInfo);

		ADD_PDE_FIELD(stab_time);
		ADD_PDE_FIELD(stab_light_time);

		ADD_PDE_FIELD(stab_distance);
		ADD_PDE_FIELD(stab_light_distance);
		ADD_PDE_FIELD(stab_width);

		ADD_PDE_FIELD(back_factor);

		ADD_PDE_FIELD(skill_cooldown);

		ADD_PDE_FIELD(hit_none_light_2d);
		ADD_PDE_FIELD(hit_none_light_3d);
		ADD_PDE_FIELD(hit_wall_light_2d);
		ADD_PDE_FIELD(hit_wall_light_3d);
		ADD_PDE_FIELD(hit_body_light_2d);
		ADD_PDE_FIELD(hit_body_light_3d);

		ADD_PDE_FIELD(skill_2d);

		ADD_PDE_FIELD(hit_wall_decal_easy);
		ADD_PDE_FIELD(hit_wall_decal_heavy);
		ADD_PDE_FIELD(hit_wall_decal_easy_reverse);

		ADD_PDE_DEFAULT_CONSTRUCTOR();
	}
};

REGISTER_PDE_TYPE(Client::ZombieGunInfo);

/// constructor
ZombieGun::ZombieGun(by_ptr(ZombieGunInfo) info)
: stabing(false)
, stab_light(false)
, stab_time(0)
, stab_hurt_time(0)
, isCharge(false)
, charge_usetime(0.0f)
{
	weapon_info = knife_info = info;
	//info->skill_cooldown = 0.0f;
}

/// initialize
void ZombieGun::Initialize()
{
	WeaponBase::Initialize();
	skill = ptr_new(PlayerSkill);
	skill->type = kSkillZombie;
}

/// udpate
void ZombieGun::Update(float frame_time)
{
	WeaponBase::Update(frame_time);

	tempc_ptr(Character) player = GetOwner();

	if (!player)
		return;

	if (stabing)
	{
		stab_time -= frame_time;

		if (stab_hurt_time > 0)
		{
			stab_hurt_time -= frame_time;

			if (stab_hurt_time <= 0)
			{
				StabCheck();
			}
		}

		if (stab_time < 0)
		{
			stab_time = 0;
			stabing = false;
			player->StopStab();
		}
	}
	else if (isCharge)
	{
		charge_usetime -= frame_time;

		if (CheckCharge() || charge_usetime < 0.f)
		{
			charge_usetime = -1;
			isCharge = false;
			player->UnLockStateByType(kLSSelectWeapon);
			player->UnLockStateByType(kLSJump);
			player->UnLockStateByType(kLSCrouch);
			player->UnLockStateByType(kLSCamera);
			const FirstPerson & first_person = player->GetFirstPerson();
			if(first_person.animation_group)
			{
				first_person.animation_group->StopAction(true);
			}

			gGame->channel_connection->ChargeSomething(0, 0, Core::Quaternion(0,0,0,0));
		}
	}
	else if (player->CanStab())
	{
		if (player->first_action_on)
			player->Stab(Stab());
		else if (player->zombiegun_cd_time > knife_info->skill_cooldown && player->second_action_on)
		{
			skill->uid = 0;
			if (gLevel->game_type == RoomOption::kCommonZombieMode)
			{
				if (!player->common_zombie_dying_flag)
				{
					gGame->channel_connection->UseSkill(skill);
					UseSkillSound();
					switch(player->current_career)
					{
					case DEFAULT_COMMONZOMBIE_DRUG:
						{
							Core::Vector3 pos = player->GetPosition();
							gGame->channel_connection->UseSmog(player->uid, pos);
						}
						break;
					case DEFAULT_COMMONZOMBIE_CHARGE:
						{
							if (!isCharge)
							{
								charge_usetime = knife_info->skill_usetime;
								player->zombiecharge_cd_time = knife_info->skill_cooldown;
								player->LockStateByType(kLSSelectWeapon);
								player->LockStateByType(kLSJump);
								player->LockStateByType(kLSCrouch);
								player->LockStateByType(kLSCamera);
								player->SetLookDir(player->GetRotation());
								isCharge = true;
							}
						}
						break;
					}
				}
				else
					player->stabing = false;
			}
			else
				gGame->channel_connection->UseSkill(skill);
		}
		else
			player->stabing = false;
	}
	else
	{
		player->stabing = false;
	}
}

void ZombieGun::DrawUI(by_ptr(UIRender) ui_render)
{
	WeaponBase::DrawUI(ui_render);

	CStrBuf<256> buff;
	buff.format(weapon_info->name);
	buff.toupper();

	ui_render->DrawStringShadow(ui_render->font_simhei_24, ARGB(255, 241, 211), ARGB(0,0,0), ARGB(0, 0, 0, 0), Core::Rectangle(-195, 0, 0, 1), "1/1", Unit::kAlignLeftBottom);

	ui_render->DrawStringShadow(ui_render->font_simhei_14, ARGB(255, 241, 211), ARGB(0,0,0), ARGB(0, 0, 0, 0), Core::Rectangle(-100, -20, 0, -7), buff, Unit::kAlignCenterBottom);
}

bool ZombieGun::CheckCharge()	
{
	tempc_ptr(Character) player = GetOwner();

	if (!player || !knife_info || !gPhysxScene)
		return false;
	Core::Quaternion rotation = player->GetRotation();
	Core::Vector3 position = player->GetPosition();
	Core::Vector3 temp_pos = position + Vector3(0.f,1.35f,0.5f) * rotation;
	float distance = 1.2f;

	Vector3 dir = Vector3(0, 0, -1) * rotation;
	Vector3 scanprange(0.55f,0.55f,0.01f);
	dir.Normalize();

	Vector3 firemotion = dir * distance;

	Core::Matrix44 rotmatrix(rotation);
	NxMat33 matt;
	matt.setRow(0,NxVec3(rotmatrix._11,rotmatrix._12,rotmatrix._13));
	matt.setRow(1,NxVec3(rotmatrix._21,rotmatrix._22,rotmatrix._23));
	matt.setRow(2,NxVec3(rotmatrix._31,rotmatrix._32,rotmatrix._33));
	NxBox FlameBox((const NxVec3 &)temp_pos,(const NxVec3 &)scanprange,matt);

	//������ײ������
	NxU32 activeGroups = 0;
	activeGroups |= 1 << PhysxSystem::kStatic;
	activeGroups |= 1 << PhysxSystem::kStaticCollisionWithPerson;
	activeGroups |= 1 << (player->GetTeam() == 0 ? PhysxSystem::kGroupEnd : PhysxSystem::kGroupStart);
	activeGroups |= 1 << (player->GetTeam() == 0 ? PhysxSystem::kStaticCollisionWithGateTeam2 : PhysxSystem::kStaticCollisionWithGateTeam1);

	bool is_wall = false;
	NxSweepQueryHit hit[200];
	NxU32 num = gPhysxScene->linearOBBSweep(FlameBox,(const NxVec3 &)firemotion, NX_SF_DYNAMICS|NX_SF_STATICS, NULL, 200, hit, NULL , activeGroups);
	if (num > 0)
	{
		for(NxU32 i = 0; i < num ;i++)
		{
			if(hit[i].hitShape->getGroup() >= PhysxSystem::kGroupStart  && hit[i].hitShape->getGroup() <= PhysxSystem::kGroupEnd)
			{
				NxActor &actor = hit[i].hitShape->getActor();

				tempc_ptr(Character) p = Character::FromNxActor(actor);
				tempc_ptr(DummyObject) dummy = DummyObject::FromNxActor(actor);
				if (p)
				{
					Vector3 v = Vector3(0,0,-1) * player->GetLookDir();
					v.y +=0.4f;
					v.Normalize();
					Core::Quaternion rot;
					rot.SetFromTo(Vector3(0,0,-1),v);
					gGame->channel_connection->ChargeSomething(p->uid, 1, rot);

					int part = p->GetActorId(&actor);
					gGame->channel_connection->PokeHurt(true, p->uid, part, false);
				}
				else if(dummy)
				{
					bool is_boost(false);
					if (gGame->channel_connection)
					{
						if( GetGaiLv(player->rand_fun.Rand(),player->rand_fun.GetRandMax()) * 10000 < weapon_info->hit_crit)
							is_boost = true;


						bool back = false;
						Vector3 front_dir = Vector3(0, 0, -1) * player->GetRotation();
						Vector3 dir = Vector3(0, 0, -1) * dummy->GetRotation();
						back = Dot(front_dir, dir) > 0;

						gGame->channel_connection->PokeHurtDummy(true, dummy->dummyobjectinfo->dummy_id, back);
					}
				}
			}
			else
			{
				is_wall = true;
			}
		}
	}
	return is_wall;
}

/// can active
bool ZombieGun::CanActive()
{
	return WeaponBase::CanActive();
}

/// active
void ZombieGun::Active()
{
	WeaponBase::Active();
}

/// inactive
void ZombieGun::Inactive()
{
	WeaponBase::Inactive();

	stabing = false;
	stab_light = false;
	stab_time = 0;
	stab_hurt_time = 0;

	tempc_ptr(Character) player = GetOwner();
	if (player)
		player->StopStab();
}

/// stab
byte ZombieGun::Stab()
{
	byte type = kNone;

	if (!knife_info)
		return type;

	if (owner->IsAttributeExist(kEffect_Special_Invisible))
	{
		gGame->channel_connection->CancelInvisible(owner->uid);
	}

	if (gLevel->game_type == RoomOption::kCommonZombieMode)
	{
		tempc_ptr(Character) player = GetOwner();
		if (player->common_zombie_dying_flag)
		{
			return type;
		}
	}

	if (!stabing)
	{
		stabing = true;
		stab_time = knife_info->stab_light_time;
		stab_hurt_time = stab_time * 0.3f;

		type = kHitNone;

		tempc_ptr(Character) player = GetOwner();

		if (!player)
			return type;

		byte part = 0;

		uint group_id = 0;
		group_id |= 1 << PhysxSystem::kStatic;
		group_id |= 1 << PhysxSystem::kStaticRaycast;
		for (uint i = PhysxSystem::kGroupStart; i <= PhysxSystem::kGroupEnd; ++i)
		{
			if (!gLevel->team_hurt && 
				(i == player->GetTeam() + PhysxSystem::kGroupStart))
				continue;

			group_id |= 1 << i;
		}
		group_id |= 1 << PhysxSystem::kGroupVehicle;

		Vector3 position = player->GetCameraPosition();
		Vector3 direction = Normalize(Vector3(0, 0, -1) * player->GetCameraRotation());
		Vector3 right = Normalize(Vector3(1, 0, 0) * player->GetCameraRotation());

		NxCapsule capsule;
		capsule.p0 = binary_cast<NxVec3>(position - right * knife_info->stab_width);
		capsule.p1 = binary_cast<NxVec3>(position + right * knife_info->stab_width);
		capsule.radius = 0.1f;

		NxSweepQueryHit hit;

		if (gPhysxScene->linearCapsuleSweep(capsule, binary_cast<NxVec3>(direction * knife_info->stab_distance), NX_SF_STATICS | NX_SF_DYNAMICS, NULL, 1, &hit, NULL, group_id, NULL))
		{
			if (hit.hitShape)
			{
				NxActor& actor = hit.hitShape->getActor();
				tempc_ptr(Character) p = Character::FromNxActor(actor);

				if (p)
					type = kHitBody;
				else
					type = kHitWall;
			}
		}

		gGame->channel_connection->Poke(type);
	}
	return type;
}

/// stab check
void ZombieGun::StabCheck()
{
	tempc_ptr(Character) player = GetOwner();

	if (!player)
		return;

	byte uid = 0;
	byte part = 0;

	uint group_id = 0;
	group_id |= 1 << PhysxSystem::kStatic;
	group_id |= 1 << PhysxSystem::kStaticRaycast;
	for (uint i = PhysxSystem::kGroupStart; i <= PhysxSystem::kGroupEnd; ++i)
	{
		if (!gLevel->team_hurt && 
			(i == player->GetTeam() + PhysxSystem::kGroupStart))
			continue;

		group_id |= 1 << i;
	}
	group_id |= 1 << PhysxSystem::kGroupVehicle;

	Vector3 position = player->GetCameraPosition();
	Vector3 direction = Normalize(Vector3(0, 0, -1) * player->GetCameraRotation());
	Vector3 right = Normalize(Vector3(1, 0, 0) * player->GetCameraRotation());

	NxCapsule capsule;
	capsule.p0 = binary_cast<NxVec3>(position - right * knife_info->stab_width);
	capsule.p1 = binary_cast<NxVec3>(position + right * knife_info->stab_width);
	capsule.radius = 0.1f;

	NxSweepQueryHit hit;

	if (gPhysxScene->linearCapsuleSweep(capsule, binary_cast<NxVec3>(direction * (stab_light ? knife_info->stab_light_distance : knife_info->stab_distance)), NX_SF_STATICS | NX_SF_DYNAMICS, NULL, 1, &hit, NULL, group_id, NULL))
	{
		if (hit.hitShape)
		{
			NxActor& actor = hit.hitShape->getActor();
			tempc_ptr(Character) p = Character::FromNxActor(actor);
			tempc_ptr(DummyObject) dummy = DummyObject::FromNxActor(actor);
			if (p)
			{
				uid = p->uid;
				part = p->GetActorId(&actor);

				Vector3 target(hit.point.x, hit.point.y, hit.point.z);
				Vector3 normal(hit.normal.x, hit.normal.y, hit.normal.z);
				p->ResponseHit(position, target, normal, part, kWeaponTypeKnife);
				if (player && player->GetViewMode() == Character::kFirstPerson)
				{
					// camera animation
					if (!player->IsDied())
						player->GetFirstPerson().animation_camera->PlayAction("camhit", 0.f);
				}
				bool is_boost(false);

				if (gGame->channel_connection)
				{
					if( GetGaiLv(player->rand_fun.Rand(),player->rand_fun.GetRandMax()) * 10000 < weapon_info->hit_crit)
						is_boost = true;


					bool back = false;
					Vector3 front_dir = Vector3(0, 0, -1) * player->GetRotation();
					Vector3 dir = Vector3(0, 0, -1) * p->GetRotation();
					back = Dot(front_dir, dir) > 0;

					gGame->channel_connection->PokeHurt(stab_light, uid, part, back);
				}
			}
			else if(dummy)
			{
				bool is_boost(false);
				if (gGame->channel_connection)
				{
					if( GetGaiLv(player->rand_fun.Rand(),player->rand_fun.GetRandMax()) * 10000 < weapon_info->hit_crit)
						is_boost = true;


					bool back = false;
					Vector3 front_dir = Vector3(0, 0, -1) * player->GetRotation();
					Vector3 dir = Vector3(0, 0, -1) * dummy->GetRotation();
					back = Dot(front_dir, dir) > 0;

					gGame->channel_connection->PokeHurtDummy(stab_light, dummy->dummyobjectinfo->dummy_id, back);
				}
			}
			else
			{
				if (gGame)
				{
					sharedc_ptr(Character) player = gLevel->GetPlayer();
					if (player)
					{
						Vector3 pos = player->GetCameraPosition();
						Vector3 dir = Vector3(0, 0, -1) * player->GetLookDir();

						NxRay ray;
						ray.orig = (const NxVec3 &)pos;
						ray.dir = (const NxVec3 &)dir.Normalize();

						NxRaycastHit hit;
						uint group_id = 0;
						group_id |= 1 << PhysxSystem::kStatic;
						group_id |= 1 << PhysxSystem::kStaticRaycast;

						NxShape* shape = gPhysxScene->raycastClosestShape(ray, NX_ALL_SHAPES, hit, group_id, stab_light ? knife_info->stab_light_distance: knife_info->stab_distance);

						pos.x = hit.worldImpact.x;
						pos.y = hit.worldImpact.y;
						pos.z = hit.worldImpact.z;

						dir.x = hit.worldNormal.x;
						dir.y = hit.worldNormal.y;
						dir.z = hit.worldNormal.z;
						//LogSystem.WriteLinef("StabCheck() dir : %f %f %f", dir.x, dir.y, dir.z);
						if (stab_light)
						{
							if (gGame && gGame->config && gGame->config->GetLeftHand())
								gLevel->AddDecal(knife_info->hit_wall_decal_easy_reverse, pos, dir, Vector3::kOne);
							else
								gLevel->AddDecal(knife_info->hit_wall_decal_easy, pos, dir, Vector3::kOne);
						}
						else
							gLevel->AddDecal(knife_info->hit_wall_decal_heavy, pos, dir, Vector3::kOne);
					}
				}
			}
		}
	}
}

void ZombieGun::StabSound(byte type, bool stereo)
{		
	tempc_ptr(Character) viewer = gLevel->GetViewer();
	if(!viewer)
		return;

	if (!knife_info)
		return;

	FMOD::Event* audio_event = NULL;
	Identifier key;

	if (stereo)
	{
		switch (type)
		{
		case kHitNoneLight:
			key = knife_info->hit_none_light_3d;
			break;

		case kHitWallLight:
			key = knife_info->hit_wall_light_3d;
			break;

		case kHitBodyLight:
			key = knife_info->hit_body_light_3d;
			break;

		default:
			key = knife_info->hit_none_light_3d;
			break;
		}
	}
	else
	{
		switch (type)
		{
		case kHitNoneLight:
			key = knife_info->hit_none_light_2d;
			break;

		case kHitWallLight:
			key = knife_info->hit_wall_light_2d;
			break;

		case kHitBodyLight:
			key = knife_info->hit_body_light_2d;
			break;

		default:
			key = knife_info->hit_none_light_2d;
			break;
		}
	}

	audio_event = FmodSystem::GetEvent(key);

	if (audio_event)
	{
		if (stereo)
		{
			FMOD_VECTOR pos = (const FMOD_VECTOR &)GetPosition();
			FMOD_VECTOR vel = {0, 0, 0};
			audio_event->set3DAttributes(&pos, &vel);
		}

		audio_event->start();
	}
}

void ZombieGun::UseSkillSound()
{
	FMOD::Event* audio_event = NULL;
	Identifier key;

	audio_event = FmodSystem::GetEvent(knife_info->skill_2d);

	if (audio_event)
	{
		audio_event->start();
	}
}