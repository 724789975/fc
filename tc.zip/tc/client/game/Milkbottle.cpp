#include "pch.h"

using namespace Core;
using namespace Client;

DEFINE_PDE_TYPE_CLASS(Client:: MilkbottleInfo)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Client::GunInfo);
		ADD_PDE_DEFAULT_CONSTRUCTOR();
	}
};


DEFINE_PDE_TYPE_CLASS(Client:: Milkbottle)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Client::GunBase);

		ADD_PDE_PROPERTY_R(weapon_info);
	}
};

REGISTER_PDE_TYPE(Client::MilkbottleInfo);
REGISTER_PDE_TYPE(Client::Milkbottle);

namespace Client
{
	 Milkbottle::Milkbottle(by_ptr(MilkbottleInfo) info)
	{
		weapon_info = gun_info =  milkbottle_info = info;
		has_trajectory = true;
		wait_timer = 0.f;
	}

	void Milkbottle::Initialize()
	{		
		GunBase::Initialize();
	}

	/// can active
	bool Milkbottle::CanActive()
	{
		return GunBase::CanActive();
	}

	/// active
	void Milkbottle::Active()
	{
		GunBase::Active();
	}

	/// inactive
	void Milkbottle::Inactive()
	{
		tempc_ptr(Character) player = GetOwner();
		if(player->IsLockStateByType(kLSSelectWeapon))
		{
			player->UnLockStateByType(kLSSelectWeapon);
			player->camera_distance = old_cameradistance;
			gGame->camera->control_mode = old_controlmode;
		}

		GunBase::Inactive();
	}

	/// update
	void Milkbottle::Update(float frame_time)
	{
		tempc_ptr(Character) player = GetOwner();
		if (!player)
			return;
		if (!gun_info)
			return;
		if (next_fire_time > 0)
			next_fire_time -= frame_time;
		if(wait_timer > 0.f)
		{
			wait_timer -= frame_time;
			if(wait_timer <= 0.f)
			{
				player->UnLockStateByType(kLSSelectWeapon);
				player->camera_distance = old_cameradistance;
				if(gLevel->GetViewer() == player)
					gGame->camera->control_mode = old_controlmode;
				player->first_action_on = false;
			}
		}
		if (player->first_action_on)
		{

			if (idle_time <= 0 && next_fire_time <= 0 && (gun_info->auto_fire || delay_fire == false))
			{
				if (player->CanFire() && Fire())
				{
					next_fire_time = gun_info->fire_time;
					wait_timer = gun_info->fire_time;
					player->LockStateByType(kLSSelectWeapon);
					if( player->camera_distance < 0.5f)
						old_cameradistance = 0.f;
					else
						old_cameradistance = player->camera_distance;
					old_controlmode = gGame->camera->control_mode;
					player->camera_distance = player->GetHeight() * 2;
					if(gLevel->GetViewer() == player)
						gGame->camera->control_mode = Camera::kViewMode;
					player->SetMove(0, 0);
					idle_time = weapon_info->time_to_idle;
				}
				else
					player->StopShoot();
				
			}
		}
		else
		{
			player->StopShoot();
		}

		UpdateEffect(frame_time);
	}

	/// get weapon type
	uint Milkbottle::GetWeaponType()
	{
		return kWeaponTypeMilkbottle;
	}
	/// fire
	bool Milkbottle::Fire()
	{
		tempc_ptr(Character) player = GetOwner();

		if (!player)
			return false;
		
		
		if(!FireBase(0))
		{
			return false;
		}

		
		empty = false;
		return true;
	}

	bool Milkbottle::CanFire( bool check_only )
	{
		tempc_ptr(Character) player = GetOwner();
		if(!milkbottle_info)
		{
			return false;
		}
		if (idle_time > 0)
		{
			return false;
		}
		return true;
	}

	void Milkbottle::FireCheck( const Core::Vector3 & position, const Core::Quaternion & rotation, float spread, bool do_effect /*= true*/ )
	{
		//ENCODE_START

		tempc_ptr(Character) player = GetOwner();

		Vector3 dir = Vector3(0, 0, -1) * rotation;
		if (!player || !gun_info || !gPhysxScene)
			return;

		gGame->channel_connection->Drink();

		player->Shoot(dir, do_effect);

		//ENCODE_END
	}
	
}