namespace Client
{
	class StaticMesh;

	struct ThrowableInfo : public WeaponInfo
	{
		float explode_time;
		float ready_time;
		float throw_out_time;
		float gravity;

		Core::Identifier grenade_particle;
		Core::Identifier explode_particle;
		Core::Identifier trail_particle;
		Core::Identifier explode_sound;
		Core::Identifier ready_sound_2d;
		Core::Identifier ready_sound_3d;
		Core::Identifier throw_sound_2d;
		Core::Identifier throw_sound_3d;
	};

	struct GrenadeInfo : public ThrowableInfo
	{
		float hurt;
		float range;

		GrenadeInfo()
		{
			weapon_type = kWeaponTypeGrenade;
		}
	};

	struct FlashInfo : public ThrowableInfo
	{
		float range_start;
		float range_end;
		float time_max;
		float time_fade;
		float back_factor;

		FlashInfo()
		{
			weapon_type = kWeaponTypeFlash;
			range_start = 0;
			range_end = 80.f;
			time_max = 5.f;
			time_fade = 2.f;
			back_factor = 0.5f;
		}
	};

	struct SmokeInfo : public ThrowableInfo
	{
		float time;

		SmokeInfo()
		{
			weapon_type = kWeaponTypeSmoke;
		}
	};

	struct SpecialGrenadeInfo : public ThrowableInfo
	{
		float hurt;
		float range;

		SpecialGrenadeInfo()
		{
			weapon_type = kWeaponTypeSpecial;
		}
	};

	class Grenade : public WeaponBase
	{
	public:
		enum State
		{
			kIdle,
			kThrowingIn,
			kThrowingReady,
			kThrowingRequest,
			kThrowingOut,
			kThrowOut,
		};

	public:
		/// constructor
		Grenade(by_ptr(ThrowableInfo) info);

		/// destructor
		~Grenade();

		/// get weapon type
		virtual uint GetWeaponType() { return type; }

	public:
		/// initialize
		virtual void Initialize();

		/// update
		virtual void Update(float time);

		/// udpate animation
		virtual void UpdateAnimation(float time);

		/// update physx
		virtual void UpdatePhysx(float frame_time);

		/// draw ui
		virtual void DrawUI(by_ptr(UIRender) ui_render);

		/// can active
		virtual bool CanActive();

		static tempc_ptr(Grenade) FromNxActor(NxActor & actor);

		/// active
		virtual void Active();

		/// inactive
		virtual void Inactive();

	public:
		/// get position
		virtual const Core::Vector3 & GetPosition();

		/// set position
		virtual void SetPosition(const Core::Vector3 & pos);

		/// get rotation
		virtual const Core::Quaternion & GetRotation();

		/// set rotation
		virtual void SetRotation(const Core::Quaternion & rot);

		/// throw out
		void ThrowOut(const Core::Vector3 & velocity);

		/// create physx
		void CreatePhysx();

		/// action throw in
		void ActionThrowIn();

	private:
		NxActor*			actor;
		float		physx_update_time;

	public:
		sharedc_ptr(ThrowableInfo)	grenade_info;
		int			id;
		float		timer;
		float		ready_time;
		float		throw_out_time;
		float		explode_time;
		int			state;
		//uint		count;
		uint		uid;
		byte		type;
		int			team;
		bool        canOperation;
		sharedc_ptr(ParticleSystem)	grenade_trail_particle;
	};
}