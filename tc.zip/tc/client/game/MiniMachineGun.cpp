#include "pch.h"

using namespace Core;
using namespace Client;

DEFINE_PDE_TYPE_CLASS(Client::MiniMachineGunInfo)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Client::ShotGunInfo);
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_FIELD(charge_particle);
	}
};

DEFINE_PDE_TYPE_CLASS(Client::MiniMachineGun)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Client::GunBase);

		ADD_PDE_PROPERTY_R(weapon_info);
	}
};

REGISTER_PDE_TYPE(Client::MiniMachineGunInfo);
REGISTER_PDE_TYPE(Client::MiniMachineGun);

/// random float
static float RandomFloat(F32 x, F32 y)
{
	float r = (F32)rand() / (RAND_MAX + 1);
	float num = x + (y - x) * r;
	return num; 
}

/// constrcutor
MiniMachineGun::MiniMachineGun(by_ptr(MiniMachineGunInfo) info)
{
	ispass = false;
	ispass2 = false;
	weapon_info = gun_info = MiniMachineGun_info = info;
	time_reducespread = 0.f;

	setup_state = 0;
	charge_state = 0;

	charge_event = NULL;
	charge_event_3d = NULL;
	setup_event = NULL;
	setup_event_3d = NULL;
}

MiniMachineGun::~MiniMachineGun()
{
	if (mini_gun_audio_spin_fire)
	{
		mini_gun_audio_spin_fire->stop();
		mini_gun_audio_spin_fire = NULL;
	}
	if (mini_gun_audio_spin_fire_3d)
	{
		mini_gun_audio_spin_fire_3d->stop();
		mini_gun_audio_spin_fire_3d = NULL;
	}

	if (charge_particle)
	{
		charge_particle->SetDead();
		charge_particle->SetEnable(false);
	}

	if (charge_event)
	{
		charge_event->stop();
		charge_event = NULL;
	}
	if (charge_event_3d)
	{
		charge_event_3d->stop();
		charge_event_3d = NULL;
	}

	if (setup_event)
	{
		setup_event->stop();
		setup_event = NULL;
	}
	if (setup_event_3d)
	{
		setup_event_3d->stop();
		setup_event_3d = NULL;
	}
}

/// initialize
void MiniMachineGun::Initialize()
{
	static const char szTeam[2] = {'r', 'b'};

	GunBase::Initialize();

	tempc_ptr(Character) player = GetOwner();
	if (!player)
		return;

	accuracy = 0.92f;

	mini_gun_audio_fire = FmodSystem::GetEvent("bj/weapon/2d/minigun/fire");

	mini_gun_audio_spin_fire = FmodSystem::GetEvent("bj/weapon/2d/minigun/fire_spin");
	mini_gun_audio_spin_fire_3d = FmodSystem::GetEvent("bj/weapon/3d/minigun/fire_spin");

	if (MiniMachineGun_info && MiniMachineGun_info->ammo_type != kWeaponTypeNone)
	{
		{
			mini_gun_audio_fire = NULL;
		}

		if (MiniMachineGun_info->charge_particle.Length() > 0)
		{		
			Core::String name = Core::String::Format("%s_%c", MiniMachineGun_info->charge_particle.Str(), szTeam[player->GetTeam() & 1]);
			charge_particle = ptr_new ParticleSystem(name, false);
			charge_particle->SetEnable(false);
		}

		{
			Core::String name = Core::String::Format("bj/weapon/2d/%s/charge", MiniMachineGun_info->sound_name.Str());
			charge_event = FmodSystem::GetEvent(name);

			name = Core::String::Format("bj/weapon/3d/%s/charge", MiniMachineGun_info->sound_name.Str());
			charge_event_3d = FmodSystem::GetEvent(name);
		}

		{
			Core::String name = Core::String::Format("bj/weapon/2d/%s/setup", MiniMachineGun_info->sound_name.Str());
			setup_event = FmodSystem::GetEvent(name);

			name = Core::String::Format("bj/weapon/3d/%s/setup", MiniMachineGun_info->sound_name.Str());
			setup_event_3d = FmodSystem::GetEvent(name);
		}

		tempc_ptr(MiniMachineGunInfo) luncher_info = MiniMachineGun_info;

		preload_ammoinfo = ptr_new AmmoInfo();
		preload_ammoinfo->sid = luncher_info->sid;
		preload_ammoinfo->color = luncher_info->color;
		preload_ammoinfo->hit_crit = luncher_info->hit_crit;
		preload_ammoinfo->attrs = luncher_info->attrs;
		preload_ammoinfo->weapon_type = (WeaponType)luncher_info->ammo_type;
		preload_ammoinfo->icon =luncher_info->icon;
		preload_ammoinfo->AddPartKey(luncher_info->ammopart_key);

		preload_ammoinfo->maxalive_time = luncher_info->maxalive_time;
		preload_ammoinfo->gravity = luncher_info->gravity;
		preload_ammoinfo->hurt = luncher_info->hurt;
		preload_ammoinfo->range = luncher_info->range;
		preload_ammoinfo->damage = luncher_info->damage;
		preload_ammoinfo->dmg_modify_timer_min = luncher_info->dmg_modify_timer_min;
		preload_ammoinfo->dmg_modify_timer_max = luncher_info->dmg_modify_timer_max;
		preload_ammoinfo->dmg_modify_min = luncher_info->dmg_modify_min;
		preload_ammoinfo->dmg_modify_max = luncher_info->dmg_modify_max;

		preload_ammoinfo->ammocontrolmode = luncher_info->ammocontrolmode;

		preload_ammoinfo->capsule_height = luncher_info->capsule_height;
		preload_ammoinfo->capsule_radius = luncher_info->capsule_radius;

		preload_ammoinfo->LoadPart();

		preload_ammo = AmmoFactory::CreateAmmo(preload_ammoinfo);
		if (preload_ammo)
			preload_ammo->Initialize(player->GetTeam(),false);

		has_trajectory = true;
	}

	setup_state = 0;
	charge_state = 0;
}

/// get weapon type
uint MiniMachineGun::GetWeaponType()
{
	return kWeaponTypeMiniMachineGun;
}

/// inactive
void MiniMachineGun::Inactive()
{
	GunBase::Inactive();
	tempc_ptr(Character) player = GetOwner();
	if (!player)
		return;

	player->SetMoveInfoOffset(0.f);
	player->SetWalk(false);

	if (MiniMachineGun_info->ammo_type != kWeaponTypeNone)
	{
		player->UnLockStateByType(kLSMove);
		player->UnLockStateByType(kLSJump);
		//player->UnLockStateByType(kLSCrouch);
		player->UnLockStateByType(kLSSelectWeapon);

		setup_state = 0;
		charge_state = 0;

		if (charge_particle)
		{
			charge_particle->SetDead();
			charge_particle->SetEnable(false);

			gLevel->RemoveParticle(charge_particle);
		}

		if (charge_event)
			charge_event->stop();
		if (charge_event_3d)
			charge_event_3d->stop();

		if (setup_event)
			setup_event->stop();
		if (setup_event)
			setup_event->stop();
	}

	if(GetOwner() == gLevel->GetPlayer())
	{
		if (gGame->channel_connection)
			gGame->channel_connection->PlayerAnimationEnd(GetWeaponType());
		 if (gLevel->GetPlayer()->GetFirstPerson().animation_group)
			gLevel->GetPlayer()->GetFirstPerson().animation_group->StopAction(true);
		 next_fire_time = 0.f;

		 FireReadyTime = 0.f;
		 player->keep_Shoot_mini = false;
	}

	//sound
	if (mini_gun_audio_spin_fire)
		mini_gun_audio_spin_fire->stop();
	if (mini_gun_audio_spin_fire_3d)
		mini_gun_audio_spin_fire_3d->stop();

	if (charge_particle)
	{
		charge_particle->SetDead();
		charge_particle->SetEnable(false);
	}

	//sound
	if (charge_event)
		charge_event->stop();
	if (charge_event_3d)
		charge_event_3d->stop();

	if (setup_event)
		setup_event->stop();
	if (setup_event)
		setup_event->stop();
}

/// active
void MiniMachineGun::Active()
{
	FireReadyTime = 0.0f;

	if(animation)
	{
		if(animation->node_action)
			animation->node_action->SetPlayRate(0.0);
		animation->StopAction();
	}

	GunBase::Active();
}

/// fire
bool MiniMachineGun::Fire()
{		
	tempc_ptr(Character) player = GetOwner();

	if (!player)
		return false;

	if (!CanFire(false))
		return false;

	float spread = MiniMachineGun_info->spread;
	
	float minimumspread = player->attr_minigunaccurate.value1 / 100.0f;
	float limittime = player->attr_minigunaccurate.time;
	
	if(time_reducespread > 0.f && player->breducespread)
	{
		if(time_reducespread > limittime)
			time_reducespread = limittime;
		spread -= (spread - minimumspread) / limittime * time_reducespread;
	}

	charge_state = 0;

	if (charge_particle)
	{
		charge_particle->SetDead();
		charge_particle->SetEnable(false);

		gLevel->RemoveParticle(charge_particle);
	}

	if (charge_event)
		charge_event->stop();
	if (charge_event_3d)
		charge_event_3d->stop();

	if (setup_event)
		setup_event->stop();
	if (setup_event)
		setup_event->stop();

	if (MiniMachineGun_info->ammo_type != kWeaponTypeNone)
	{
		float charge_rate = 0;
		if (MiniMachineGun_info->ammo_charge_time_max > 0.f)
			charge_rate = Core::Clamp(ammo_charge_time/MiniMachineGun_info->ammo_charge_time_max, 0.f, 1.f);

		for (int i = 0; i < 3; i++)
		{
			if (!FireLuncherBase(spread, charge_rate, 0, i))
				return false;
		}
	}
	else
	{
		if (MiniMachineGun_info->shoot_bullet_count > 1 && ammo_in_clip >= 0)
		{
			Vector3 fire_angle = player->GetLookDir().GetZXY();
			Quaternion rot;
			rot.SetZXY(fire_angle);

			for(int i = 0; i < MiniMachineGun_info->shoot_bullet_count -1; i++)
			{
				if(i == MiniMachineGun_info->shoot_bullet_count -1)
					FireCheck(player->GetCameraPosition(), rot, 0, false);
				else
					FireCheck(player->GetCameraPosition(), rot, spread, false);
			}
		}

		FireBase(spread);
	}

	gGame->channel_connection->PlayerAnimationStart(GetWeaponType(), 2);

	if (mini_gun_audio_fire)
	{
		mini_gun_audio_fire->start();
	}

	KickBack(MiniMachineGun_info->normal_up_base, 0, MiniMachineGun_info->normal_up_modifier, 0, MiniMachineGun_info->normal_up_max, 0, 0);
	return true;
}

///reload
bool MiniMachineGun::Reload()
{
	return false;
}

//update
void MiniMachineGun::Update(float time)
{
	if(gGame->channel_connection->GetState() != ChannelConnection::kInReplay)
	{
		WeaponBase::Update(time);
		tempc_ptr(Character) player = GetOwner();
		if (!player)
			return;
		if (!gun_info)
			return;
		if (player->IsDied())
			return;

		next_fire_time -= time;

		bool is_fireammo = (MiniMachineGun_info->ammo_type != kWeaponTypeNone);
		bool is_fp = player->GetViewMode() == Character::kFirstPerson;

		FMOD_VECTOR vel = {0, 0, 0};

		if(!animation->IsActionPlaying() || strcmp( animation->node_action->GetAnimationKey(), "shoot") != 0)
		{
			animation->PlayAction("shoot", 0, true);
			if(animation->node_action)
				animation->node_action->SetPlayRate(0);
		}
		else
		{
			if (!is_fireammo)
			{
				if(animation->node_action)
					animation->node_action->SetPlayRate(FireReadyTime/MiniMachineGun_info->firereadytime);
			}
		}

		if (is_fireammo)
		{
			if (player->second_action_on)
			{
				switch (setup_state)
				{
				case 0:
					setup_state = 1;
					if (is_fp && setup_event)
					{
						setup_event->stop();
						setup_event->start();
					}
					if (!is_fp && setup_event_3d)
					{
						setup_event_3d->stop();
						setup_event_3d->set3DAttributes(&(const FMOD_VECTOR &)player->GetSkeletonPosition(), &vel);
						setup_event_3d->start();
					}
					break;
				case 2:
					setup_state = 3;
					if (is_fp && setup_event)
					{
						setup_event->stop();
						setup_event->start();
					}
					if (!is_fp && setup_event_3d)
					{
						setup_event_3d->stop();
						setup_event_3d->set3DAttributes(&(const FMOD_VECTOR &)player->GetSkeletonPosition(), &vel);
						setup_event_3d->start();
					}
					break;
				}
			}
			else
			{
				switch (setup_state)
				{
				case 1:
					setup_state = 2;
					break;
				}
			}
		}
		else
			setup_state = 0;

		Vector3 fire_pos;
		Quaternion fire_rot;
			
		GetJointInfo(joint_fire_id, &fire_pos, &fire_rot);

		//LogSystem.WriteLinef("%d %d %d", player->first_action_on, player->second_action_on, setup_state);

		if ((setup_state != 3) && 
			((player->first_action_on && !is_fireammo) || 
			player->second_action_on || (setup_state == 1 || setup_state == 2)))
		{
			FireReadyTime += time;
			if (gun_info->auto_fire || delay_fire == false)
			{
				if (player->CanFire())
				{
					if (MiniMachineGun_info->ammo_charge_time_max > 0.f)
					{
						if (charge_state == 0)
						{
							if (player->first_action_on)
							{
								charge_state = 1;
								ammo_charge_time = 0;

								if (is_fp && charge_event)
								{
									charge_event->stop();
									charge_event->start();
								}
								if (!is_fp && charge_event_3d)
								{
									charge_event_3d->stop();
									charge_event_3d->set3DAttributes(&(const FMOD_VECTOR &)fire_pos, &vel);
									charge_event_3d->start();
								}

								if (charge_particle)
								{
									charge_particle->Reset();
									charge_particle->SetFirstPersonMode(is_fp);

									charge_particle->SetPosition(fire_pos);
									charge_particle->SetRotation(fire_rot);

									charge_particle->SetEnable(true);

									gLevel->AddParticle(charge_particle);
								}
							}
						}
						else if (charge_state == 1)
						{
							if (player->first_action_on)
							{
								if (charge_event_3d)
									charge_event_3d->set3DAttributes(&(const FMOD_VECTOR &)fire_pos, &vel);
								if (charge_particle)
								{
									charge_particle->SetPosition(fire_pos);
									charge_particle->SetRotation(fire_rot);
								}

								ammo_charge_time += time;
								if (ammo_charge_time >= MiniMachineGun_info->ammo_charge_time_max)
									charge_state = 2;
							}
							else
								charge_state = 2;
						}
						else
						{
							charge_state = 0;

							if (charge_event)
								charge_event->stop();
							if (charge_event_3d)
								charge_event_3d->stop();

							if (charge_particle)
							{
								charge_particle->SetDead();
								charge_particle->SetEnable(false);

								gLevel->RemoveParticle(charge_particle);
							}
						}

						//LogSystem.WriteLinef("%f", ammo_charge_time);
					}

					const FirstPerson & first_person = player->GetFirstPerson();
					if(first_person.animation_group && !player->keep_Shoot_mini)
					{
						if (!is_fireammo && mini_gun_audio_spin_fire)
						{
							mini_gun_audio_spin_fire->stop();
							mini_gun_audio_spin_fire->start();
						}
						first_person.animation_group->PlayAction("minimachinegun_shoot", "shootone");
						player->keep_Shoot_mini = true;
						gGame->channel_connection->PlayerAnimationStart(GetWeaponType(), 1);
					}
					float fireready_percent = 1.0f;
					Attribute attrinfo;
					if (weapon_info->CheckWeaponAttribute(kWeaponAttr_Self_PrepareFireTimeInfect, attrinfo))	
					{
						fireready_percent = 1.f - (float)(attrinfo.value1) / 100.f;
						Clamp(fireready_percent,0.f,1.f);
					}
					float fire_ready_time = MiniMachineGun_info->firereadytime * fireready_percent;

					if(idle_time <= 0.f && FireReadyTime >  fire_ready_time && player->first_action_on && player->GetCurrentSpeed().Length() <= 0.01f && player->breducespread)
					{
						time_reducespread += time;
					}
					else
					{
						if(time_reducespread > 0.f)
							time_reducespread -= time;
					}
					if (idle_time <= 0.f && next_fire_time <= 0 && FireReadyTime > fire_ready_time && 
						((!is_fireammo && player->first_action_on) || (is_fireammo && charge_state == 2)))
					{
						if (!Fire())
						{
							gGame->channel_connection->PlayerAnimationStart(GetWeaponType(), 3);
						}
						next_fire_time = gun_info->fire_time;
						idle_time =  weapon_info->time_to_idle;
					}
					else if (player->second_action_on && !player->first_action_on)
					{
						gGame->channel_connection->PlayerAnimationStart(GetWeaponType(), 3);
					}

					if(FireReadyTime > fire_ready_time)
					{
						FireReadyTime = fire_ready_time;
					}
				}
				else if ((player->IsDied()))
				{
					if (mini_gun_audio_spin_fire)
						mini_gun_audio_spin_fire->stop();
				}
			}

			sharedc_ptr(CharacterInfo)& info = player->GetCurCharinfo();

			if (MiniMachineGun_info->ammo_type != kWeaponTypeNone)
			{
				float moveoffset = -player->GetMoveInfoRunSpeed() * 2;
				player->SetMoveInfoOffset(moveoffset);
				player->SetWalk(true);

				player->LockStateByType(kLSMove);
				player->LockStateByType(kLSJump);
				//player->LockStateByType(kLSCrouch);
				player->LockStateByType(kLSSelectWeapon);
			}
			else
			{
				float moveoffset = -player->GetMoveInfoRunSpeed() * 0.4;
				player->SetMoveInfoOffset(moveoffset);
				player->SetWalk(true);
			}	
		}
		else
		{
			FireReadyTime -= time;
			if(time_reducespread > 0.f)
				time_reducespread -= time;
			if(player->keep_Shoot_mini)
			{
				const FirstPerson & first_person = player->GetFirstPerson();
				if(first_person.animation_group)
					first_person.animation_group->StopAction();
				player->keep_Shoot_mini = false;
				gGame->channel_connection->PlayerAnimationEnd(GetWeaponType());
				player->StopShoot();
			}
			if (mini_gun_audio_spin_fire)
			{
				FMOD_EVENT_STATE audio_state = FMOD_EVENT_DEFAULT;
				mini_gun_audio_spin_fire->getState(&audio_state);
				if ((audio_state & FMOD_EVENT_STATE_PLAYING) != 0)
				{
					FMOD::EventParameter *eventparameter = NULL;
					mini_gun_audio_spin_fire->getParameterByIndex(0,&eventparameter);
					if (eventparameter)
					{
						eventparameter->keyOff();
					}
				}
			}

			gGame->channel_connection->PlayerAnimationStart(GetWeaponType(), 4);

			if(FireReadyTime < 0.f)
			{
				FireReadyTime = 0.f;

				if (MiniMachineGun_info->ammo_type != kWeaponTypeNone)
				{
					player->UnLockStateByType(kLSMove);
					player->UnLockStateByType(kLSJump);
					//player->UnLockStateByType(kLSCrouch);
					player->UnLockStateByType(kLSSelectWeapon);

					setup_state = 0;
					charge_state = 0;

					if (charge_event)
						charge_event->stop();
					if (charge_event_3d)
						charge_event_3d->stop();

					if (charge_particle)
					{
						charge_particle->SetDead();
						charge_particle->SetEnable(false);

						gLevel->RemoveParticle(charge_particle);
					}
				}
			}

			sharedc_ptr(CharacterInfo)& info = player->GetCurCharinfo();

			player->SetMoveInfoOffset(0);
			player->SetWalk(false);
		}

		UpdateEffect(time);
	}
	else
	{
		UpdateViewerAnimation(time);
	}
	
}

void MiniMachineGun::OnAnimationStartFPEvent(const Core::Identifier & groupname, int & index)
{

}
void MiniMachineGun::OnAnimationStartTPEvent(const Core::Identifier & groupname, int & index)
{

}
void MiniMachineGun::OnAnimationEndFPEvent(const Core::Identifier & groupname, int & index)
{

}
void MiniMachineGun::OnAnimationEndTPEvent(const Core::Identifier & groupname, int & index)
{

}



void MiniMachineGun::UpdateViewerAnimation( float time )
{
	tempc_ptr(Character) owner = GetOwner();

	if (!owner)
		return;

	if (!gun_info)
		return;

	if (owner->keep_Shoot_mini_tp)
	{
		const ThirdPerson & third_person = owner->GetThirdPerson();
		third_person.node_group->PlayAction("minimachinegun_shoot", "stdshootright");
	}

	bool is_fireammo = (MiniMachineGun_info->ammo_type != kWeaponTypeNone);

	if(!animation->IsActionPlaying() || strcmp( animation->node_action->GetAnimationKey(), "shoot") != 0)
	{
		animation->PlayAction("shoot", 0, true);
		if(animation->node_action)
			animation->node_action->SetPlayRate(0);
	}
	else
	{
		if (!is_fireammo)
		{
			if(animation->node_action)
				animation->node_action->SetPlayRate(FireReadyTime/MiniMachineGun_info->firereadytime);
		}
	}

	if (owner)
	{
		switch (owner->keep_Shoot_mini_state)
		{
		case 0:
			{
				if(FireReadyTime > MiniMachineGun_info->firereadytime)
				{
					const FirstPerson & first_person = owner->GetFirstPerson();
					if (first_person.animation_group)
						first_person.animation_group->StopAction();
				}
			}
			break;
		case 1:
			{
				const FirstPerson & first_person = owner->GetFirstPerson();
				if(first_person.animation_group && !ispass)
				{
					ispass = true;
					first_person.animation_group->PlayAction("minimachinegun_shoot", "shootone");
				}
			}
			break;
		case 2:
			{
				UpdateEffect(Task::GetFrameTime());
				const FirstPerson & first_person = owner->GetFirstPerson();
				if(first_person.animation_group && !ispass)
				{
					ispass = true;
					first_person.animation_group->PlayAction("minimachinegun_shoot", "shoottwo");
				}
			}
			break;
		case 3:
			{
				const FirstPerson & first_person = owner->GetFirstPerson();
				if(first_person.animation_group && !ispass)
				{
					ispass = true;
					first_person.animation_group->PlayAction("minimachinegun_shoot", "shoottwo");
				}
			}
			break;
		case 4:
			{
				const FirstPerson & first_person = owner->GetFirstPerson();
				ispass = false;
				if (first_person.animation_group)
					first_person.animation_group->StopAction();
			}
			break;
		default:
			break;
		}
	}

	FMOD_VECTOR vel = {0, 0, 0};
	tempc_ptr(Character) player = gLevel->GetPlayer();
	if (owner && owner != player || gGame->channel_connection->GetState() == ChannelConnection::kInReplay)
	{
		switch (owner->keep_Shoot_mini_state)
		{
		case 1:
			{
				if (!is_fireammo && mini_gun_audio_spin_fire && !ispass2)
				{
					ispass2 = true;
					mini_gun_audio_spin_fire->stop();
					mini_gun_audio_spin_fire->start();
				}
				FireReadyTime += time;
				if(FireReadyTime > MiniMachineGun_info->firereadytime)
				{
					FireReadyTime = MiniMachineGun_info->firereadytime;
				}
			}
			break;
		case 2:
			{
				FireReadyTime += time;
				if (!ispass2)
				{
					ispass2 = true;
					if (!is_fireammo && mini_gun_audio_spin_fire)
					{
						mini_gun_audio_spin_fire->stop();
						mini_gun_audio_spin_fire->start();
					}
				}
				else
				{
					UpdateEffect(Task::GetFrameTime());
					if(FireReadyTime >= MiniMachineGun_info->firereadytime)
					{
						FireReadyTime = MiniMachineGun_info->firereadytime;
						if (mini_gun_audio_fire)
						{
							if (next_fire_time < 0)
							{
								mini_gun_audio_fire->start();
								next_fire_time = gun_info->fire_time;
							}
							else
								next_fire_time -= time;
						}
					}
				}
			}
			break;
		case 3:
			{
				if (!ispass2)
				{
					ispass2 = true;
				}
				FireReadyTime += time;
				if(FireReadyTime > MiniMachineGun_info->firereadytime)
				{
					FireReadyTime = MiniMachineGun_info->firereadytime;
				}
			}
			break;
		case 4:
			{
				if (mini_gun_audio_spin_fire)
				{
					FireReadyTime -= time;
					ispass2 = false;

					FMOD_EVENT_STATE audio_state = FMOD_EVENT_DEFAULT;
					mini_gun_audio_spin_fire->getState(&audio_state);
					if ((audio_state & FMOD_EVENT_STATE_PLAYING) != 0)
					{
						FMOD::EventParameter *eventparameter = NULL;
						mini_gun_audio_spin_fire->getParameterByIndex(0,&eventparameter);
						if (eventparameter)
						{
							eventparameter->keyOff();
						}
					}
				}
			}
			break;
		default:
			break;
		}
	}

	if(FireReadyTime <= 0.f)
	{
		ispass = false;
		FireReadyTime = 0.f;
	}
}

bool MiniMachineGun::FireLuncherBase(float spread, float charge_rate, float gravity_addon, int num)
{
	tempc_ptr(Character) player = GetOwner();
	tempc_ptr(MiniMachineGunInfo) luncher_info = MiniMachineGun_info;

	if (!player)
		return false;

	if (!gun_info || !luncher_info)
		return false;

	if (gun_info->accuracy_divisor != -1 && gun_info->accuracy_divisor != 0)
	{
		accuracy = ((shots_fired * shots_fired * shots_fired) / gun_info->accuracy_divisor) + gun_info->accuracy_offset;

		if (accuracy > gun_info->max_inaccuracy)
			accuracy = gun_info->max_inaccuracy;
	}

	if (ammo_in_clip <= 0 && weapon_info->time_to_idle <= 0)
	{
		next_fire_time = 0.4f;
		return false;
	}
	if(weapon_info->time_to_idle <= 0)
		--ammo_in_clip;
	delay_fire = true;
	++shots_fired;
	last_fire_time = 0;

	empty = false;

	Vector3 fire_pos;

	if (gGame->channel_connection && GetJointInfo(joint_fire_id, &fire_pos, NULL))
	{
		const float max_distance = 35.0f;

		Vector3 fire_angle = player->GetLookDir().GetZXY();
		fire_angle += player->punch_angle;
		Quaternion camerarot = gGame->camera->rotation;
		Quaternion rot;
		rot.SetZXY(fire_angle);

		Vector3 dir = Vector3(0, 0, -1) * rot;
		Vector3 up_dir = Vector3(0, 1, 0) * rot;
		Vector3 right_dir = Vector3(1, 0, 0) * rot;

		float x, y, z;
		x = RandomFloat( -0.5, 0.5 ) + RandomFloat( -0.5, 0.5 );
		y = RandomFloat( -0.5, 0.5 ) + RandomFloat( -0.5, 0.5 );
		z = x * x + y * y;

		dir += x * spread * right_dir + y * spread * up_dir;
		dir.Normalize();

		Vector3 hit_pos = player->GetCameraPosition() + dir * max_distance;
		dir = hit_pos - fire_pos;
		dir.Normalize();

		NxRay ray;
		NxRaycastHit hit;
		NxU32 staticGroups = 0;
		staticGroups |= 1 << PhysxSystem::kStatic;
		staticGroups |= 1 << PhysxSystem::kGroupVehicle;
		//staticGroups |= 1 << 
		Vector3 dispos = player->GetCameraPosition() - fire_pos;
		F32 vctlen = dispos.Length() + 0.2f;
		ray.orig =(const NxVec3 &) player->GetCameraPosition();
		ray.dir = (const NxVec3 &)dir;
		NxShape* shape = gPhysxScene->raycastClosestShape(ray, NX_ALL_SHAPES, hit, staticGroups, vctlen);
		if(shape > 0)
		{
			fire_pos = player->GetCameraPosition();
			//fire_pos += dir.Normalize() * hit.distance * 0.5;
			//ammoinfo->maxalive_time = 0.1f;
		}

		{
			AmmoAddInInfo info;

			float hurt_rate = 1;
			float default_fly_speed = luncher_info->fly_speed[num] * (1 + charge_rate * luncher_info->fly_speed_multiple[num]);

			info.hurt_rate = hurt_rate;
			info.default_fly_speed = default_fly_speed;
			info.gravity_addon = gravity_addon;
			info.is_need_addin_info = true;

			info.blood_disk_hit_count = 0;
			info.blood_disk_interval = 0;

			gGame->channel_connection->ProjectedAmmoOut(player->uid, preload_ammoinfo, luncher_info->ammo_type, fire_pos, dir * default_fly_speed, info, NullPtr);
		}
	}

	next_fire_time = gun_info->fire_time;

	return true;
}
