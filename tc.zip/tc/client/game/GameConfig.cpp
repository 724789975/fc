#include "pch.h"
#include <stdio.h>

using namespace Core;
using namespace Client;


//---------------------------------------------------------------------------------------
// time step type
//---------------------------------------------------------------------------------------
DEFINE_PDE_TYPE_ENUM(Client::GameConfig::TimeStepType)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_ENUM_ITEM("kTimeStepTypeFixed",	Client::GameConfig::kTimeStepTypeFixed);
		ADD_PDE_ENUM_ITEM("kTimeStepTypeVariable",	Client::GameConfig::kTimeStepTypeVariable);

		ADD_PDE_ENUM_CONSTRUCTOR();
	}
};

REGISTER_PDE_TYPE(Client::GameConfig::TimeStepType);

//---------------------------------------------------------------------------------------
// time step type
//---------------------------------------------------------------------------------------
DEFINE_PDE_TYPE_ENUM(Client::ActionType)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_ENUM_ITEM("kActionNone", Client::kActionNone);

		ADD_PDE_ENUM_ITEM("kActionMoveForward", Client::kActionMoveForward);
		ADD_PDE_ENUM_ITEM("kActionMoveBackward", Client::kActionMoveBackward);
		ADD_PDE_ENUM_ITEM("kActionMoveLeft", Client::kActionMoveLeft);
		ADD_PDE_ENUM_ITEM("kActionMoveRight", Client::kActionMoveRight);

		ADD_PDE_ENUM_ITEM("kActionTurnUp", Client::kActionTurnUp);
		ADD_PDE_ENUM_ITEM("kActionTurnDown", Client::kActionTurnDown);
		ADD_PDE_ENUM_ITEM("kActionTurnLeft", Client::kActionTurnLeft);
		ADD_PDE_ENUM_ITEM("kActionTurnRight", Client::kActionTurnRight);

		ADD_PDE_ENUM_ITEM("kActionJump", Client::kActionJump);
		ADD_PDE_ENUM_ITEM("kActionCrouch", Client::kActionCrouch);
		ADD_PDE_ENUM_ITEM("kActionWalk", Client::kActionWalk);

		ADD_PDE_ENUM_ITEM("kActionFire", Client::kActionFire);
		ADD_PDE_ENUM_ITEM("kActionSecondFire", Client::kActionSecondFire);
		ADD_PDE_ENUM_ITEM("kActionReload", Client::kActionReload);
		ADD_PDE_ENUM_ITEM("kActionChangeWeapon", Client::kActionChangeWeapon);
		ADD_PDE_ENUM_ITEM("kActionWeaponUp", Client::kActionWeaponUp);
		ADD_PDE_ENUM_ITEM("kActionWeaponDown", Client::kActionWeaponDown);
		ADD_PDE_ENUM_ITEM("kActionDropWeapon", Client::kActionDropWeapon);
		ADD_PDE_ENUM_ITEM("kActionUseItem", Client::kActionUseItem);
		ADD_PDE_ENUM_ITEM("kActionCallMedic", Client::kActionCallMedic);
		ADD_PDE_ENUM_ITEM("kActionShowName", Client::kActionShowName);
		ADD_PDE_ENUM_ITEM("kActionPrintScreen", Client::kActionPrintScreen);
		ADD_PDE_ENUM_ITEM("kActionSpray", Client::kActionSpray);

		ADD_PDE_ENUM_ITEM("kActionUIGameInfo", Client::kActionUIGameInfo);
		ADD_PDE_ENUM_ITEM("kActionUIMap", Client::kActionUIMap);
		ADD_PDE_ENUM_ITEM("kActionUIPack", Client::kActionUIPack);
		ADD_PDE_ENUM_ITEM("kActionUIWeaponPack", Client::kActionUIWeaponPack);
		ADD_PDE_ENUM_ITEM("kActionUIRadio1", Client::kActionUIRadio1);
		ADD_PDE_ENUM_ITEM("kActionUIRadio2", Client::kActionUIRadio2);
		ADD_PDE_ENUM_ITEM("kActionUIRadio3", Client::kActionUIRadio3);
		ADD_PDE_ENUM_ITEM("kActionUIRadio4", Client::kActionUIRadio4);
		ADD_PDE_ENUM_ITEM("kActionUIHelp", Client::kActionUIHelp);

		ADD_PDE_ENUM_ITEM("kActionSensitivityUp", Client::kActionSensitivityUp);
		ADD_PDE_ENUM_ITEM("kActionSensitivityDown", Client::kActionSensitivityDown);

		ADD_PDE_ENUM_ITEM("kActionMenu0", Client::kActionMenu0);
		ADD_PDE_ENUM_ITEM("kActionMenu1", Client::kActionMenu1);
		ADD_PDE_ENUM_ITEM("kActionMenu2", Client::kActionMenu2);
		ADD_PDE_ENUM_ITEM("kActionMenu3", Client::kActionMenu3);
		ADD_PDE_ENUM_ITEM("kActionMenu4", Client::kActionMenu4);
		ADD_PDE_ENUM_ITEM("kActionMenu5", Client::kActionMenu5);
		ADD_PDE_ENUM_ITEM("kActionMenu6", Client::kActionMenu6);
		ADD_PDE_ENUM_ITEM("kActionMenu7", Client::kActionMenu7);
		ADD_PDE_ENUM_ITEM("kActionMenu8", Client::kActionMenu8);
		ADD_PDE_ENUM_ITEM("kActionMenu9", Client::kActionMenu9);

		ADD_PDE_ENUM_ITEM("kActionChatCurrent", Client::kActionChatCurrentEx);
		ADD_PDE_ENUM_ITEM("kActionChatTeam", Client::kActionChatTeamEx);

		ADD_PDE_ENUM_ITEM("kActionKickYes", Client::kActionKickYes);
		ADD_PDE_ENUM_ITEM("kActionKickNo", Client::kActionKickNo);

		ADD_PDE_ENUM_ITEM("kActionTeamYes", Client::kActionTeamYes);
		ADD_PDE_ENUM_ITEM("kActionTeamNo", Client::kActionTeamNo);

		ADD_PDE_ENUM_ITEM("kAction_Key1", Client::kAction_Key1);
		ADD_PDE_ENUM_ITEM("kAction_Key2", Client::kAction_Key2);
		ADD_PDE_ENUM_ITEM("kAction_Key3", Client::kAction_Key3);
		ADD_PDE_ENUM_ITEM("kAction_Key4", Client::kAction_Key4);
		ADD_PDE_ENUM_ITEM("kAction_Key5", Client::kAction_Key5);
		ADD_PDE_ENUM_ITEM("kTakePicture", Client::kTakePicture);

		ADD_PDE_ENUM_ITEM("kActionUseSkill", Client::kActionUseSkill);
		ADD_PDE_ENUM_ITEM("kActionUseSkill2", Client::kActionUseSkill2);
		ADD_PDE_ENUM_ITEM("kActionUseSkillSurvival_1", Client::kActionUseSkillSurvival_1);
		ADD_PDE_ENUM_ITEM("kActionUseSkillSurvival_2", Client::kActionUseSkillSurvival_2);
		ADD_PDE_ENUM_ITEM("kActionUseSkillSurvival_3", Client::kActionUseSkillSurvival_3);
		ADD_PDE_ENUM_ITEM("kActionUseSkillSurvival_4", Client::kActionUseSkillSurvival_4);
		ADD_PDE_ENUM_ITEM("kActionUseSkillSurvival_5", Client::kActionUseSkillSurvival_5);
		ADD_PDE_ENUM_ITEM("kActionDestroyTowerGun", Client::kActionDestroyTowerGun);

		ADD_PDE_ENUM_ITEM("kActionCount", Client::kActionCount);

		ADD_PDE_ENUM_CONSTRUCTOR();
	}
};

REGISTER_PDE_TYPE(Client::ActionType);

//---------------------------------------------------------------------------------------
// type info.
//---------------------------------------------------------------------------------------
DEFINE_PDE_TYPE_CLASS(Client::GameConfig)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_EVENT(EventLoadSettings);
		ADD_PDE_EVENT(EventLoadProfile);
		ADD_PDE_EVENT(EventSaveProfile);

		ADD_PDE_PROPERTY_RW(Invite);
		ADD_PDE_PROPERTY_RW(Version);
		ADD_PDE_PROPERTY_RW(Moshi);
		ADD_PDE_PROPERTY_RW(Map);
		ADD_PDE_PROPERTY_RW(Specialjob);
		ADD_PDE_PROPERTY_RW(Roomnum);
		ADD_PDE_PROPERTY_RW(Roomstate);
		ADD_PDE_PROPERTY_RW(FullScreen);
		ADD_PDE_PROPERTY_RW(Tips);
		//ADD_PDE_PROPERTY_RW(Resolution);
		ADD_PDE_PROPERTY_RW(UserResolution);
		ADD_PDE_PROPERTY_RW(RefreshRate);
		ADD_PDE_PROPERTY_RW(VSync);
		ADD_PDE_PROPERTY_RW(MSAA);
		ADD_PDE_PROPERTY_RW(AspectRatio);
		ADD_PDE_PROPERTY_RW(ShaderQuality);
		ADD_PDE_PROPERTY_RW(Fluency);
		ADD_PDE_PROPERTY_RW(ModelQuality);
		ADD_PDE_PROPERTY_RW(TextureQuality);
		ADD_PDE_PROPERTY_RW(DynShaderLod);
		ADD_PDE_PROPERTY_RW(Shadow);
		ADD_PDE_PROPERTY_RW(Anisotropy);
		ADD_PDE_METHOD(CheckMultiSamplerType);
		ADD_PDE_METHOD(CheckAnisotropy);
		ADD_PDE_METHOD(CheckLanguages);
		ADD_PDE_METHOD(GetDisplayModeCount);
		ADD_PDE_METHOD(FillDisplayMode);
		ADD_PDE_METHOD(FillRefreshRate);
		ADD_PDE_METHOD(EvaluateHardware);

		ADD_PDE_PROPERTY_RW(LeftHand);

		ADD_PDE_PROPERTY_RW(Sensitivity);
		ADD_PDE_PROPERTY_RW(SensitivitySniper);
		ADD_PDE_PROPERTY_RW(SensitivityRatio);
		ADD_PDE_PROPERTY_RW(InverseMouse);

		ADD_PDE_PROPERTY_RW(PlayerName);
		ADD_PDE_PROPERTY_RW(SoftParticle);
		ADD_PDE_PROPERTY_RW(UIVirtualSize);

		ADD_PDE_PROPERTY_RW(TimeStepType);
		ADD_PDE_PROPERTY_RW(TimeStepMax);
		ADD_PDE_PROPERTY_RW(TimeStepIter);

		ADD_PDE_PROPERTY_RW(AudioOff);
		ADD_PDE_PROPERTY_RW(AudioValue);
		ADD_PDE_PROPERTY_RW(ProportionRadio);
		ADD_PDE_PROPERTY_RW(ProportionMusic);
		ADD_PDE_PROPERTY_RW(ProportionSound);

		ADD_PDE_PROPERTY_RW(SettingStream);
		ADD_PDE_PROPERTY_RW(ProfileStream);

		ADD_PDE_PROPERTY_RW(InviteOff);
		ADD_PDE_PROPERTY_RW(GuideOff);
		ADD_PDE_PROPERTY_RW(LeaderEnter);

		ADD_PDE_PROPERTY_RW(UserLanguage);

		ADD_PDE_METHOD(SetServerAddress);
		ADD_PDE_METHOD(SetServerPort);
		ADD_PDE_METHOD(SetNotifyError);

		ADD_PDE_METHOD(BindAction);
		ADD_PDE_METHOD(ActionToInput);
		ADD_PDE_METHOD(InputToAction);
		ADD_PDE_METHOD(IsInputChangeable);
		ADD_PDE_METHOD(IsActionChangeable);
		ADD_PDE_METHOD(SaveConfig);
	
		ADD_PDE_METHOD(LoadGameing);
		ADD_PDE_METHOD(SaveGameing);
		ADD_PDE_METHOD(LoadVersion);
		ADD_PDE_METHOD(SaveVersion);
		ADD_PDE_METHOD(LoadQuickSetting);
		ADD_PDE_METHOD(SaveQuickSetting);
		ADD_PDE_METHOD(LoadKeys);
		ADD_PDE_METHOD(SaveKeys);
		ADD_PDE_METHOD(LoadMouse);
		ADD_PDE_METHOD(SaveMouse);
		ADD_PDE_METHOD(LoadGraphic);
		ADD_PDE_METHOD(SaveGraphic);
		ADD_PDE_METHOD(LoadGameQuality);
		ADD_PDE_METHOD(SaveGameQuality);
		ADD_PDE_METHOD(LoadTips);
		ADD_PDE_METHOD(SaveTips);
		ADD_PDE_METHOD(LoadAudio);
		ADD_PDE_METHOD(SaveAudio);
		ADD_PDE_METHOD(LoadTips);
		ADD_PDE_METHOD(SaveTips);
		ADD_PDE_METHOD(GetBestResolution);
		ADD_PDE_METHOD(UpdateAudioProportion);
		ADD_PDE_METHOD(GetBillBoardV);
		ADD_PDE_METHOD(GetBillBoardH);
		ADD_PDE_METHOD(GetLogo);
		ADD_PDE_METHOD(GetNickNameLengthMin);
		ADD_PDE_METHOD(GetNickNameLengthMax);
		ADD_PDE_METHOD(GetBattleGroupNameLengthMin);
		ADD_PDE_METHOD(GetBattleGroupNameLengthMax);
		ADD_PDE_METHOD(GetRoomNameLengthMin);
		ADD_PDE_METHOD(GetRoomNameLengthMax);
		ADD_PDE_METHOD(GetTimeSellDate);
		ADD_PDE_METHOD(GetTimeSellStart);
		ADD_PDE_METHOD(GetTimeSellStartDate);
		ADD_PDE_METHOD(GetTimeSellEnd);
		ADD_PDE_METHOD(GetTimeSellEndDate);
		ADD_PDE_METHOD(GetTimeSellGiftH);
		ADD_PDE_METHOD(GetTimeSellGiftM);
		ADD_PDE_METHOD(GetQuickSellData);
		ADD_PDE_METHOD(GetUISystemFlag);
		ADD_PDE_METHOD(IsInAchievementList);
	}
};

REGISTER_PDE_TYPE(Client::GameConfig);

namespace Client
{
	const GameConfig::ActionBind GameConfig::DEFAULT_ACTION_MAP[kActionCount] = 
	{
		{	kActionNone,			KC_UNUSED,			KC_UNUSED,		"None",			false,	},

		{	kActionMoveForward,		KC_W,				KC_UNUSED,		"MoveForward",	true,	},
		{	kActionMoveBackward,	KC_S,				KC_UNUSED,		"MoveBackward",	true,	},
		{	kActionMoveLeft,		KC_A,				KC_UNUSED,		"MoveLeft",		true,	},
		{	kActionMoveRight,		KC_D,				KC_UNUSED,		"MoveRight",	true,	},

		{	kActionTurnUp,			KC_UP,				KC_UNUSED,		"TurnUp",		false,	},
		{	kActionTurnDown,		KC_DOWN,			KC_UNUSED,		"TurnDown",		false,	},
		{	kActionTurnLeft,		KC_LEFT,			KC_UNUSED,		"TurnLeft",		false,	},
		{	kActionTurnRight,		KC_RIGHT,			KC_UNUSED,		"TurnRight",	false,	},

		{	kActionJump,			KC_SPACE,			KC_UNUSED,		"Jump",			true,	},
		{	kActionCrouch,			KC_LCONTROL,		KC_UNUSED,		"Crouch",		true,	},
		{	kActionWalk,			KC_LSHIFT,			KC_UNUSED,		"Walk",			true,	},

		{	kActionFire,			MC_LEFT_BUTTON,		KC_UNUSED,		"Fire",			false,	},
		{	kActionSecondFire,		MC_RIGHT_BUTTON,	KC_UNUSED,		"SecondFire",	false,	},
		{	kActionReload,			KC_R,				KC_UNUSED,		"Reload",		true,	},
		{	kActionChangeWeapon,	KC_Q,				KC_UNUSED,		"ChangeWeapon",	true,	},
		{	kActionWeaponUp,		MC_WHEEL_UP,		KC_UNUSED,		"WeaponUp",		false,	},
		{	kActionWeaponDown,		MC_WHEEL_DOWN,		KC_UNUSED,		"WeaponDown",	false,	},
		{	kActionDropWeapon,		KC_G,				KC_UNUSED,		"DropWeapon",	false,	},
		{	kActionUseItem,			KC_E,				KC_UNUSED,		"UseItem",		false,	},
		{	kActionCallMedic,		KC_F,				KC_UNUSED,		"CallMedic",	false,	},
		{	kActionShowName,		KC_INSERT,			KC_UNUSED,		"ShowName",		false,	},
		{	kActionPrintScreen,		KC_SYSRQ,			KC_UNUSED,		"PrintScreen",	false,	},
		{	kActionSpray,			KC_T,				KC_UNUSED,		"Spray",		false,	},

		{	kActionUIGameInfo,		KC_TAB,				KC_UNUSED,		"UIGameInfo",	false,	},
		{	kActionUIMap,			KC_M,			    KC_UNUSED,		"UIMap",		true,	},
		{	kActionUIPack,			KC_B,				KC_UNUSED,		"UIPack",		true,	},
		{	kActionUIWeaponPack,	KC_J,				KC_UNUSED,		"UIWeaponPack",	true,	},
		{	kActionUIRadio1,		KC_Z,				KC_UNUSED,		"UIRadio1",		false,	},
		{	kActionUIRadio2,		KC_X,				KC_UNUSED,		"UIRadio2",		false,	},
		{	kActionUIRadio3,		KC_C,				KC_UNUSED,		"UIRadio3",		false,	},
		{	kActionUIRadio4,		KC_T,				KC_UNUSED,		"UIRadio4",		false,	},
		{	kActionUIHelp,			KC_F1,				KC_UNUSED,		"UIHelp",		true,	},

		{	kActionSensitivityUp,	KC_PGUP,			KC_UNUSED,		"SensitivityUp",		false,	},
		{	kActionSensitivityDown,	KC_PGDOWN,			KC_UNUSED,		"SensitivityDown",		false,	},

		{	kActionMenu0,			KC_0,				KC_UNUSED,		"Menu0",		false,	},
		{	kActionMenu1,			KC_1,				KC_UNUSED,		"Menu1",		false,	},
		{	kActionMenu2,			KC_2,				KC_UNUSED,		"Menu2",		false,	},
		{	kActionMenu3,			KC_3,				KC_UNUSED,		"Menu3",		false,	},
		{	kActionMenu4,			KC_4,				KC_UNUSED,		"Menu4",		false,	},
		{	kActionMenu5,			KC_5,				KC_UNUSED,		"Menu5",		false,	},
		{	kActionMenu6,			KC_6,				KC_UNUSED,		"Menu6",		false,	},
		{	kActionMenu7,			KC_7,				KC_UNUSED,		"Menu7",		false,	},
		{	kActionMenu8,			KC_8,				KC_UNUSED,		"Menu8",		false,	},
		{	kActionMenu9,			KC_9,				KC_UNUSED,		"Menu9",		false,	},

		{	kActionChatCurrentEx,	KC_Y,				KC_UNUSED,		"ChatCurrent",	false,	},
		{	kActionChatTeamEx,		KC_U,				KC_UNUSED,		"ChatTeam",		false,	},

		{	kActionKickYes,			KC_F11,				KC_UNUSED,		"KickYes",		false,	},
		{	kActionKickNo,			KC_F12,				KC_UNUSED,		"KickNo",		false,	},

		{	kActionTeamYes,			KC_F7,				KC_UNUSED,		"TeamYes",		true,	},
		{	kActionTeamNo,			KC_F8,				KC_UNUSED,		"TeamNo",		true,	},

		{	kActionSuicide,			KC_K,				KC_UNUSED,		"Suicide",		true,	},

		{	kAction_Key1,				KC_F1,				KC_UNUSED,		"f1",		false,	},
		{	kAction_Key2,				KC_F2,				KC_UNUSED,		"f2",		false,	},
		{	kAction_Key3,				KC_F3,				KC_UNUSED,		"f3",		false,	},
		{	kAction_Key4,				KC_F4,				KC_UNUSED,		"f4",		false,	},
		{	kAction_Key5,				KC_F5,				KC_UNUSED,		"f5",		false,	},
		{	kTakePicture,				KC_F9,				KC_UNUSED,		"TakePicture",		false,	},
		{	kActionUseSkill,			KC_G,				KC_UNUSED,		"UseSkill",			true,	},
		{	kActionUseSkill2,			KC_E,				KC_UNUSED,		"UseSkill2",		true,	},
		{	kActionUseSkillSurvival_1,	KC_1,				KC_UNUSED,		"UseSkillSurvival_1",	true,	},
		{	kActionUseSkillSurvival_2,	KC_2,				KC_UNUSED,		"UseSkillSurvival_2",	true,	},
		{	kActionUseSkillSurvival_3,	KC_3,				KC_UNUSED,		"UseSkillSurvival_3",	true,	},
		{	kActionUseSkillSurvival_4,	KC_4,				KC_UNUSED,		"UseSkillSurvival_4",	true,	},
		{	kActionUseSkillSurvival_5,	KC_5,				KC_UNUSED,		"UseSkillSurvival_5",	true,	},

		{	kActionDestroyTowerGun,		KC_I,				KC_UNUSED,		"DestroyTowerGun",	false,	},
	};
}

namespace Client
{
	GameConfig::GameConfig()
		: m_FullScreen(false)
		, m_Invite(false)
		,m_Version(0)
		,m_moshi(0)
		,m_map(0)
		,m_specialjob(0)
		,m_roomnum(0)
		,m_roomstate(0)
		, m_VSync(false)
		//, m_Resolution("1024x768")
		, sys_res(Core::Vector2(1024, 768))
		, user_res(Core::Vector2(1024, 768))
		, m_RefreshRate(60)
		, m_AspectRatio("All")

		, m_ShaderQuality(0)
		, m_Fluency(0)
		, m_ModelQuality(0)
		, m_TextureQuality(0)
		, m_DynShaderLod(false)
		, m_LeftHand(false)
		, m_MSAA(0)
		, m_Anisotropy(1)
		, m_AudioOff(false)
		, m_Tips(true)
		, m_AudioValue(50)
		, m_ProportionRadio(1.f)
		, m_ProportionMusic(1.f)
		, m_ProportionSound(1.f)
		, m_Sensitivity(4.5)
		, m_SensitivitySniper(4.5)
		, m_InverseMouse(false)
		, m_SoftParticle(true)
		, m_Shadow(0)
		, m_UIVirtualSize(900)

		, m_TimeStepType(kTimeStepTypeVariable)
		, m_TimeStepMax(1.f/100.f)
		, m_TimeStepIter(12)
		, m_InviteOff(false)
		, m_GuideOff(false)
		, m_LeaderEnter(false)
	{
		char buf[256];
		gethostname(buf, 256);
		CStrBuf<256> name;
		name.format("%s", buf);
		m_PlayerName = name.buff();

		m_UserLanguage = "zh_CN";
		BuildActionMap();

		GetModuleFileNameA(NULL, buf, 256);
		Path::ContractPath(name, buf, "fc.ini");
		m_ConfigFile = name.buff();

	}
}

//---------------------------------------------------------------------------------------
// properties
//---------------------------------------------------------------------------------------
namespace Client
{
	PDE_ATTRIBUTE_GETTER(GameConfig, Invite, bool)
	{
		return m_Invite;
	}

	PDE_ATTRIBUTE_SETTER(GameConfig, Invite, bool)
	{
		if (m_Invite != value)
		{
			m_Invite = value;
		}
	}

	PDE_ATTRIBUTE_GETTER(GameConfig, Version, int)
	{
		return m_Version;
	}

	PDE_ATTRIBUTE_SETTER(GameConfig, Version, int)
	{
		if (m_Version != value)
		{
			m_Version = value;
		}
	}

	PDE_ATTRIBUTE_GETTER(GameConfig, Moshi, int)
	{
		return m_moshi;
	}

	PDE_ATTRIBUTE_SETTER(GameConfig, Moshi, int)
	{
		if (m_moshi != value)
		{
			m_moshi = value;
		}
	}

	PDE_ATTRIBUTE_GETTER(GameConfig, Map, int)
	{
		return m_map;
	}

	PDE_ATTRIBUTE_SETTER(GameConfig, Map, int)
	{
		if (m_map != value)
		{
			m_map = value;
		}
	}

	PDE_ATTRIBUTE_GETTER(GameConfig, Specialjob, int)
	{
		return m_specialjob;
	}

	PDE_ATTRIBUTE_SETTER(GameConfig, Specialjob, int)
	{
		if (m_specialjob != value)
		{
			m_specialjob = value;
		}
	}

	PDE_ATTRIBUTE_GETTER(GameConfig, Roomnum, int)
	{
		return m_roomnum;
	}

	PDE_ATTRIBUTE_SETTER(GameConfig, Roomnum, int)
	{
		if (m_roomnum != value)
		{
			m_roomnum = value;
		}
	}

	PDE_ATTRIBUTE_GETTER(GameConfig, Roomstate, int)
	{
		return m_roomstate;
	}

	PDE_ATTRIBUTE_SETTER(GameConfig, Roomstate, int)
	{
		if (m_roomstate != value)
		{
			m_roomstate = value;
		}
	}

	PDE_ATTRIBUTE_GETTER(GameConfig, FullScreen, bool)
	{
		return m_FullScreen;
	}

	PDE_ATTRIBUTE_SETTER(GameConfig, FullScreen, bool)
	{
		if (m_FullScreen != value)
		{
			m_FullScreen = value;

			if (m_FullScreen)
			{
				gGame->screen->SetShowCaption(false);
				gGame->screen->SetSizeable(false);
				gGame->screen->SetTopMost(true);
				gGame->screen->SetMaximized(true);
			}
			else
			{
				gGame->screen->SetMaximized(false);
				gGame->screen->SetTopMost(false);
				gGame->screen->SetShowCaption(true);
				gGame->screen->SetSizeable(false);
			}

			if (gGame && gGame->dx9)
				gGame->dx9->SetDeviceLost();
		}
	}

	PDE_ATTRIBUTE_GETTER(GameConfig, Tips, bool)
	{
		return m_Tips;
	}

	PDE_ATTRIBUTE_SETTER(GameConfig, Tips, bool)
	{
		if (m_Tips != value)
		{
			m_Tips = value;
		}
	}

	Core::String GameConfig::GetUserResolution()
	{
		Core::CStrBuf<256> buf;
		buf.format("%gx%g", user_res.x, user_res.y);

		return buf;
	}

	void GameConfig::GetUserResolution(Core::Vector2 & res)
	{
		res = user_res;
	}

	void GameConfig::SetUserResolution(const Core::String& value)
	{
		Vector2 v;
		if (2 != sscanf_s(value.Str(), "%fx%f", &v.x, &v.y))
		{
			v.x = 1024;
			v.y = 768;
		}

		if (user_res == v)
			return;

		if (gGame && gGame->screen)
			gGame->screen->SetAspect(v.y / v.x);

		user_res = v;

		if (gGame)
			gGame->screen->SetSize(v);
	}

	void GameConfig::UpdateAudioProportion()
	{
		int audio_value = GetAudioValue();
		int music_value = gGame->global->CategoryGetVolume("music");
		int sound_value = gGame->global->CategoryGetVolume("sound");
		if (audio_value > 0)
		{
			SetProportionMusic(1.f*music_value/audio_value);
			SetProportionSound(1.f*sound_value/audio_value);
		}
		else
		{
			SetProportionMusic(0.f);
			SetProportionSound(0.f);
		}
	}

	const Core::Vector2& GameConfig::GetSysResolution()
	{
		return sys_res;
	}

	void GameConfig::SetSysResolution(const Core::Vector2 value)
	{
		sys_res = GetFullScreen() ? user_res : value;
	}

	void GameConfig::SetResolutionBySystem(const Vector2& value)
	{
		Core::CStrBuf<256> buf;
		buf.format("%gx%g", value.x, value.y);
	}

	void GameConfig::SetServerAddress(const Core::String& value)
	{
		gStartConfig.ip = value;
	}

	void GameConfig::SetServerPort(int value)
	{
		gStartConfig.port = value;
	}

	void GameConfig::SetNotifyError(bool value)
	{
		if (gGame)
		{
			gGame->notify_error = value;
		}
	}

	PDE_ATTRIBUTE_GETTER(GameConfig, VSync, bool)
	{
		return m_VSync;
	}

	PDE_ATTRIBUTE_SETTER(GameConfig, VSync, bool)
	{
		if (m_VSync != value)
		{
			m_VSync = value;

			if (gGame && gGame->dx9)
				gGame->dx9->SetDeviceLost();
		}
	}

	bool GameConfig::CheckMultiSamplerType(U32 value)
	{
		if (!gDx9Device)
			return false;

		switch (value)
		{
		case 0:
			return true;
		case 2:
			return gDx9Device->CheckMultiSamplerType(DirectX9::kMSAA2X);
		case 4:
			return gDx9Device->CheckMultiSamplerType(DirectX9::kMSAA4X);
		case 8:
			return gDx9Device->CheckMultiSamplerType(DirectX9::kMSAA8X);
		case 16:
			return gDx9Device->CheckMultiSamplerType(DirectX9::kMSAA16X);
		};
		return false;
	}

	bool GameConfig::CheckAnisotropy(U32 value)
	{
		if (gDx9Device)
			return gDx9Device->CheckAnisotropy(value);

		return false;
	}

	bool GameConfig::CheckLanguages(const String &lang)
	{
		CStrBuf<256> filename;
		filename.format("/lang/%s.lua", lang.Str());
		sharedc_ptr(ScriptLua) lua = NullPtr;
		lua = RESOURCE_LOAD(filename, false, ScriptLua);
		if (lua->GetSize())
			return true;
		return false;
	}

	F32 GameConfig::EvaluateHardware()
	{
		//if (gRender)
		//	gRender->SetEvaluateFlag(true);

		return gRender->EvaluateHardware();

		return 0;
	}

	U32 GameConfig::GetDisplayModeCount()
	{
		if (gDx9Device)
			return gDx9Device->GetDisplayModeCount();
		else 
			return 0;
	}

	Vector3 GameConfig::FillDisplayMode(U32 index)
	{
		if (gDx9Device)
			return gDx9Device->FillDisplayMode(index);
		else
			return Vector3::kZero;
	}

	U32 GameConfig::FillRefreshRate(U32 index)
	{
		if (gDx9Device)
			return gDx9Device->FillRefreshRate(index);
		else
			return 0;
	}

	PDE_ATTRIBUTE_GETTER(GameConfig, MSAA, U32)
	{
		return m_MSAA;
	}

	PDE_ATTRIBUTE_SETTER(GameConfig, MSAA, U32)
	{
		if (m_MSAA != value)
		{
			m_MSAA = value;

			while (!CheckMultiSamplerType(m_MSAA))
			{
				Core::LogSystem.WriteLinef("Unsupport MSAA : %d", m_MSAA);
				m_MSAA /= 2;

				if (m_MSAA == 0)
					break;
			}
			//if (!CheckMultiSamplerType(m_MSAA))
			//{
			//	Core::LogSystem.WriteLinef("Unsupport MSAA : %d", m_MSAA);

			//	m_MSAA = 0;
			//}
			if (gGame && gGame->dx9)
				gGame->dx9->SetDeviceLost();
		}
	}

	PDE_ATTRIBUTE_GETTER(GameConfig, ShaderQuality, int)
	{
		return m_ShaderQuality;
	}

	PDE_ATTRIBUTE_SETTER(GameConfig, ShaderQuality, int)
	{
		if (m_ShaderQuality != value)
		{
			m_ShaderQuality = value;

			if (gGame && gGame->dx9)
				gGame->dx9->SetDeviceLost();
		}
	}
	
	PDE_ATTRIBUTE_GETTER(GameConfig, Fluency, int)
	{
		return m_Fluency;
	}

	PDE_ATTRIBUTE_SETTER(GameConfig, Fluency, int)
	{
		if (m_Fluency != value)
		{
			m_Fluency = value;
		}
	}

	PDE_ATTRIBUTE_GETTER(GameConfig, Anisotropy, int)
	{
		return m_Anisotropy;
	}

	PDE_ATTRIBUTE_SETTER(GameConfig, Anisotropy, int)
	{
		if (m_Anisotropy != value)
		{
			m_Anisotropy = value;

			while (!CheckAnisotropy(m_Anisotropy))
			{
				Core::LogSystem.WriteLinef("Unsupport Anisotropy : %d", m_Anisotropy);
				m_Anisotropy /= 2;
				if (m_Anisotropy <= 1)
				{
					m_Anisotropy = 1;
					break;
				}
			}
			//if (!CheckAnisotropy(m_Anisotropy))
			//{
			//	Core::LogSystem.WriteLinef("Unsupport Anisotropy : %d", m_Anisotropy);

			//	m_Anisotropy = 1;
			//}

			if (gGame && gGame->dx9)
				gGame->dx9->SetDeviceLost();
		}
	}

	PDE_ATTRIBUTE_GETTER(GameConfig, AudioOff, bool)
	{
		return m_AudioOff;
	}

	PDE_ATTRIBUTE_SETTER(GameConfig, AudioOff, bool)
	{
		m_AudioOff = value;
	}

	PDE_ATTRIBUTE_GETTER(GameConfig, AudioValue, int)
	{
		return (int)Clamp(m_AudioValue, 0.f, 100.f);
	}

	PDE_ATTRIBUTE_SETTER(GameConfig, AudioValue, int)
	{
		m_AudioValue = (int)Clamp(value, 0.f, 100.f);
	}

	PDE_ATTRIBUTE_GETTER(GameConfig, ProportionRadio, float)
	{
		return Clamp(m_ProportionRadio, 0.f, 1.f);
	}

	PDE_ATTRIBUTE_SETTER(GameConfig, ProportionRadio, float)
	{
		m_ProportionRadio = Clamp(value, 0.f, 1.f);
	}

	PDE_ATTRIBUTE_GETTER(GameConfig, ProportionMusic, float)
	{
		return Clamp(m_ProportionMusic, 0.f, 1.f);
	}

	PDE_ATTRIBUTE_SETTER(GameConfig, ProportionMusic, float)
	{
		m_ProportionMusic = Clamp(value, 0.f, 1.f);
	}

	PDE_ATTRIBUTE_GETTER(GameConfig, ProportionSound, float)
	{
		return Clamp(m_ProportionSound, 0.f, 1.f);
	}

	PDE_ATTRIBUTE_SETTER(GameConfig, ProportionSound, float)
	{
		m_ProportionSound = Clamp(value, 0.f, 1.f);
	}

	PDE_ATTRIBUTE_GETTER(GameConfig, LeftHand, bool)
	{
		return m_LeftHand;
	}

	PDE_ATTRIBUTE_SETTER(GameConfig, LeftHand, bool)
	{
		if (m_LeftHand != value)
		{
			m_LeftHand = value;
		}
	}

	PDE_ATTRIBUTE_GETTER(GameConfig, Sensitivity, float)
	{
		return m_Sensitivity;
	}

	PDE_ATTRIBUTE_SETTER(GameConfig, Sensitivity, float)
	{
		if (m_Sensitivity != value)
		{
			m_Sensitivity = value;
		}
	}

	PDE_ATTRIBUTE_GETTER(GameConfig, SensitivityRatio, const Core::String &)
	{
		return m_SensitivityRatio;
	}

	PDE_ATTRIBUTE_SETTER(GameConfig, SensitivityRatio, const Core::String &)
	{
		if (m_SensitivityRatio != value)
		{
			m_SensitivityRatio = value;
		}
	}

	PDE_ATTRIBUTE_GETTER(GameConfig, InverseMouse, bool)
	{
		return m_InverseMouse;
	}

	PDE_ATTRIBUTE_SETTER(GameConfig, InverseMouse, bool)
	{
		if (m_InverseMouse != value)
		{
			m_InverseMouse = value;
		}
	}

	PDE_ATTRIBUTE_GETTER(GameConfig, UIVirtualSize, float)
	{
		return m_UIVirtualSize;
	}

	PDE_ATTRIBUTE_SETTER(GameConfig, UIVirtualSize, float)
	{
		if (m_UIVirtualSize != value)
		{
			m_UIVirtualSize = value;
			gGame->guiSys->UpdateVirtualSize();
		}
	}

	PDE_ATTRIBUTE_GETTER(GameConfig, SensitivityRatioSniper, const Core::String &)
	{
		return m_SensitivityRatio_Sniper;
	}

	PDE_ATTRIBUTE_SETTER(GameConfig, SensitivityRatioSniper, const Core::String &)
	{
		if (m_SensitivityRatio_Sniper != value)
		{
			m_SensitivityRatio_Sniper = value;
		}
	}

	PDE_ATTRIBUTE_GETTER(GameConfig, SensitivitySniper, float)
	{
		return m_SensitivitySniper;
	}

	PDE_ATTRIBUTE_SETTER(GameConfig, SensitivitySniper, float)
	{
		if (m_SensitivitySniper != value)
		{
			m_SensitivitySniper = value;
		}
	}
}

//---------------------------------------------------------------------------------------
// methods
//---------------------------------------------------------------------------------------
namespace Client
{
	// build action map
	void GameConfig::BuildActionMap()
	{
		memcpy(action_map, DEFAULT_ACTION_MAP, sizeof(action_map));

		for (int i = 0; i < ELEMENTS_OF(action_map); i++)
		{
			for (int j = 0; j < ACTION_INPUT_MAX; j++)
			{
				if (action_map[i].input_set[j] != KC_UNUSED)
					input_to_action.Add(action_map[i].input_set[j], action_map[i].action_type);
			}
		}

		// load bind action

	}

	// bind action
	void GameConfig::BindAction(ActionType type, InputCode input_code, byte index)
	{
		if (IsActionChangeable(type)
			&& index < ACTION_INPUT_MAX)
		{
			if (input_code == action_map[type].input_set[index])
				return;

			if (input_code == KC_UNUSED)
			{
				input_to_action.Remove(action_map[type].input_set[index]);
				action_map[type].input_set[index] = KC_UNUSED;
			}
			else
			{
				if (IsInputChangeable(input_code) == false)
					return;

				ActionType action_type = input_to_action.Get(input_code, kActionNone);

				if (action_type != kActionNone)
				{
					for (int i = 0; i < ACTION_INPUT_MAX; i++)
					{
						if (action_map[action_type].input_set[i] == input_code)
						{
							input_to_action.Remove(input_code);
							action_map[action_type].input_set[i] = KC_UNUSED;
						}
					}
				}

				input_to_action.Remove(action_map[type].input_set[index]);
				action_map[type].input_set[index] = input_code;
				input_to_action.Set(input_code, type);
			}
		}
	}

	// action to input 
	InputCode GameConfig::ActionToInput(ActionType type, byte index)
	{
		if (type < kActionCount && index < ACTION_INPUT_MAX)
			return action_map[type].input_set[index];

		return KC_UNUSED;
	}

	// input to action
	ActionType GameConfig::InputToAction(InputCode input)
	{
		return input_to_action.Get(input, kActionNone);
	}

	// is input changeable
	bool GameConfig::IsInputChangeable(InputCode input)
	{
		ActionType action_type = InputToAction(input);

		if (action_type == kActionNone)
			return true;

		return IsActionChangeable(action_type);
	}

	// is action changeable
	bool GameConfig::IsActionChangeable(ActionType type)
	{
		if (type < kActionCount)
			return action_map[type].changeable;

		return false;
	}

	// is action pressed
	bool GameConfig::IsActionPressed(ActionType action_type)
	{
		if (action_type != kActionNone)
		{
			for (int i = 0; i < ACTION_INPUT_MAX; i++)
			{
				if (action_map[action_type].input_set[i] == KC_UNUSED)
					continue;

				if (gGame->input->IsKeyPressed(action_map[action_type].input_set[i]))
					return true;
			}
		}

		return false;
	}

	// is action released
	bool GameConfig::IsActionReleased(ActionType action_type)
	{
		if (action_type != kActionNone)
		{
			for (int i = 0; i < ACTION_INPUT_MAX; i++)
			{
				if (action_map[action_type].input_set[i] == KC_UNUSED)
					continue;

				if (gGame->input->IsKeyReleased(action_map[action_type].input_set[i]))
					return true;
			}
		}

		return false;
	}

	// is action repeated
	bool GameConfig::IsActionRepeated(ActionType action_type)
	{
		if (action_type != kActionNone)
		{
			for (int i = 0; i < ACTION_INPUT_MAX; i++)
			{
				if (action_map[action_type].input_set[i] == KC_UNUSED)
					continue;

				if (gGame->input->IsKeyRepeated(action_map[action_type].input_set[i]))
					return true;
			}
		}

		return false;
	}

	// is action down
	bool GameConfig::IsActionDown(ActionType action_type)
	{
		if (action_type != kActionNone)
		{
			for (int i = 0; i < ACTION_INPUT_MAX; i++)
			{
				if (action_map[action_type].input_set[i] == KC_UNUSED)
					continue;

				if (gGame->input->IsKeyDown(action_map[action_type].input_set[i]))
					return true;
			}
		}

		return false;
	}

	// is action up
	bool GameConfig::IsActionUp(ActionType action_type)
	{
		if (action_type != kActionNone)
		{
			for (int i = 0; i < ACTION_INPUT_MAX; i++)
			{
				if (action_map[action_type].input_set[i] == KC_UNUSED)
					continue;

				if (gGame->input->IsKeyUp(action_map[action_type].input_set[i]))
					return true;
			}
		}

		return false;
	}

	void GameConfig::LoadMouse()
	{
		char sensitivity[256];
		GetPrivateProfileStringA("Mouse", "Sensitivity", "4.5f",sensitivity, 256, m_ConfigFile );
		SetSensitivity(atof(sensitivity));

		char sensitivitysniper[256];
		GetPrivateProfileStringA("Mouse", "SensitivitySniper", "4.5f",sensitivitysniper, 256, m_ConfigFile );
		SetSensitivitySniper(atof(sensitivitysniper));

		SetInverseMouse(GetPrivateProfileIntA("Mouse", "InverseMouse", 0, m_ConfigFile) == 1);
	}

	void GameConfig::SaveMouse()
	{
		WritePrivateProfileStringA("Mouse", "Sensitivity", Core::String::Format("%0.1f", GetSensitivity()), m_ConfigFile);
		WritePrivateProfileStringA("Mouse", "SensitivitySniper", Core::String::Format("%0.1f", GetSensitivitySniper()), m_ConfigFile);
		WritePrivateProfileStringA("Mouse", "InverseMouse", GetInverseMouse()?"1":"0", m_ConfigFile);
	}

	void GameConfig::LoadGameing()
	{
		//�ܾ�����
		SetInvite(GetPrivateProfileIntA("Gameing", "Invite", 0, m_ConfigFile) == 1);

		char chTemp[256];
		//��������
		GetPrivateProfileStringA("Lang", "Language", gGame->language, chTemp, 256, m_ConfigFile);
		SetUserLanguage(chTemp);
		gGame->language = chTemp;
	}

	void GameConfig::SaveGameing()
	{
		//�ܾ�����
		WritePrivateProfileStringA("Gameing", "Invite", GetInvite()?"1":"0", m_ConfigFile);

		//��������
		WritePrivateProfileStringA("Lang", "Language",GetUserLanguage(),m_ConfigFile);
		gGame->language = GetUserLanguage();
	}

	void GameConfig::LoadVersion()
	{
		char chTemp[256];
		GetPrivateProfileStringA("VersionNumber", "Version", "0",chTemp, 256, m_ConfigFile );
		SetVersion(atoi(chTemp));
	}

	void GameConfig::SaveVersion()
	{
		WritePrivateProfileStringA("VersionNumber", "Version",Core::String::Format("%d", GetVersion()), m_ConfigFile);
	}

	void GameConfig::LoadQuickSetting()
	{
		char chTemp[256];
		GetPrivateProfileStringA("QuickSetting", "Moshi", "0",chTemp, 256, m_ConfigFile );
		SetMoshi(atoi(chTemp));

		GetPrivateProfileStringA("QuickSetting", "Map", "0",chTemp, 256, m_ConfigFile );
		SetMap(atoi(chTemp));

		GetPrivateProfileStringA("QuickSetting", "Specialjob", "0",chTemp, 256, m_ConfigFile );
		SetSpecialjob(atoi(chTemp));

		GetPrivateProfileStringA("QuickSetting", "Roomnum", "0",chTemp, 256, m_ConfigFile );
		SetRoomnum(atoi(chTemp));

		GetPrivateProfileStringA("QuickSetting", "Roomstate", "0",chTemp, 256, m_ConfigFile );
		SetRoomstate(atoi(chTemp));

	}

	void GameConfig::SaveQuickSetting()
	{
		WritePrivateProfileStringA("QuickSetting", "Moshi",Core::String::Format("%d", GetMoshi()), m_ConfigFile);
		WritePrivateProfileStringA("QuickSetting", "Map",Core::String::Format("%d", GetMap()), m_ConfigFile);
		WritePrivateProfileStringA("QuickSetting", "Specialjob",Core::String::Format("%d", GetSpecialjob()), m_ConfigFile);
		WritePrivateProfileStringA("QuickSetting", "Roomnum",Core::String::Format("%d", GetRoomnum()), m_ConfigFile);
		WritePrivateProfileStringA("QuickSetting", "Roomstate",Core::String::Format("%d", GetRoomstate()), m_ConfigFile);
	}

	void GameConfig::LoadGraphic()
	{
		//ȫ��		
		SetFullScreen(GetPrivateProfileIntA("Graphic", "FullScreen", 0, m_ConfigFile) == 1);
		//�ֱ���
		char chTemp[256];
		GetPrivateProfileStringA("Graphic", "Resolution", "1024x768",chTemp, 256, m_ConfigFile );
		SetUserResolution(chTemp);
		//�������
		GetPrivateProfileStringA("Graphic", "Fluency", gLang->GetTextW(L"��������"),chTemp, 256, m_ConfigFile );
		SetFluency(atoi(chTemp));
		//��Ļ����
		//GetPrivateProfileStringA("Graphic", "AspectRatio", "All", chTemp, 256, m_ConfigFile);
		SetAspectRatio("All");
		//ˢ����(ȫ��)
		GetPrivateProfileStringA("Graphic", "RefreshRate", "60", chTemp, 256, m_ConfigFile);
		SetRefreshRate(atoi(chTemp));
		//��ͼ����
		GetPrivateProfileStringA("Graphic", "Anisotropy", gLang->GetTextW(L"������"), chTemp, 256, m_ConfigFile);
		SetAnisotropy(atoi(chTemp));
		//�����
		GetPrivateProfileStringA("Graphic", "MSAA", gLang->GetTextW(L"��"), chTemp, 256, m_ConfigFile);
		SetMSAA(atoi(chTemp));
		//��Ӱ����
		GetPrivateProfileStringA("Graphic", "Shadow", gLang->GetTextW(L"��"), chTemp, 256, m_ConfigFile);
		SetShadow(atoi(chTemp));
		//ģ��Ʒ��
		GetPrivateProfileStringA("Graphic", "ModelQuality", gLang->GetTextW(L"��"), chTemp, 256, m_ConfigFile);
		SetModelQuality(atoi(chTemp));
		//����Ʒ��
		GetPrivateProfileStringA("Graphic", "ShaderQuality", gLang->GetTextW(L"��"), chTemp, 256, m_ConfigFile);
		SetShaderQuality(atoi(chTemp));
		//��ֱͬ��
		SetVSync(GetPrivateProfileIntA("Graphic", "VSync", 0, m_ConfigFile) == 1);
		//������
		SetSoftParticle(GetPrivateProfileIntA("Graphic", "SoftParticle", 0, m_ConfigFile) == 1);



	}

	void GameConfig::SaveGraphic()
	{
		//ȫ��
		WritePrivateProfileStringA("Graphic", "FullScreen", GetFullScreen()?"1":"0", m_ConfigFile);
		//�ֱ���
		WritePrivateProfileStringA("Graphic", "Resolution", GetUserResolution(), m_ConfigFile);
		//�������
		WritePrivateProfileStringA("Graphic", "Fluency", Core::String::Format("%d",GetFluency()), m_ConfigFile);
		//��Ļ����
		//WritePrivateProfileStringA("Graphic", "AspectRatio", GetAspectRatio(), m_ConfigFile);
		//ˢ����(ȫ��)
		WritePrivateProfileStringA("Graphic", "RefreshRate", Core::String::Format("%d", GetRefreshRate()), m_ConfigFile);
		//��ͼ����
		WritePrivateProfileStringA("Graphic", "Anisotropy", Core::String::Format("%d", GetAnisotropy()), m_ConfigFile);
		//�����
		WritePrivateProfileStringA("Graphic", "MSAA", Core::String::Format("%d", GetMSAA()), m_ConfigFile);
		//��Ӱ����
		WritePrivateProfileStringA("Graphic", "Shadow", Core::String::Format("%d", GetShadow()), m_ConfigFile);
		//ģ��Ʒ��
		WritePrivateProfileStringA("Graphic", "ModelQuality", Core::String::Format("%d", GetModelQuality()), m_ConfigFile);
		//����Ʒ��
		WritePrivateProfileStringA("Graphic", "ShaderQuality", Core::String::Format("%d", GetShaderQuality()), m_ConfigFile);
		//��ֱͬ��
		WritePrivateProfileStringA("Graphic", "VSync", GetVSync()?"1":"0", m_ConfigFile);
		//������
		WritePrivateProfileStringA("Graphic", "SoftParticle", GetSoftParticle()?"1":"0", m_ConfigFile);
	}

	void GameConfig::LoadGameQuality()
	{
		SetMSAA(GetPrivateProfileIntA("Graphic", "MSAA", 0, m_ConfigFile));
		SetAnisotropy(GetPrivateProfileIntA("Graphic", "Anisotropy", 0, m_ConfigFile));
		SetShadow(GetPrivateProfileIntA("Graphic", "Shadow", 2,m_ConfigFile));
		SetShaderQuality(GetPrivateProfileIntA("Graphic", "ShaderQuality", 1, m_ConfigFile));
		SetModelQuality(GetPrivateProfileIntA("Graphic", "ModelQuality", 2, m_ConfigFile));
		SetSoftParticle(GetPrivateProfileIntA("Graphic", "SoftParticle", 0, m_ConfigFile) == 1);
		SetFluency(GetPrivateProfileIntA("Graphic", "Fluency", 2, m_ConfigFile));
	}

	void GameConfig::SaveGameQuality()
	{
		WritePrivateProfileStringA("Graphic", "MSAA", Core::String::Format("%d", GetMSAA()), m_ConfigFile);
		WritePrivateProfileStringA("Graphic", "Anisotropy", Core::String::Format("%d", GetAnisotropy()), m_ConfigFile);
		WritePrivateProfileStringA("Graphic", "Shadow", Core::String::Format("%d", GetShadow()), m_ConfigFile);
		WritePrivateProfileStringA("Graphic", "ShaderQuality", Core::String::Format("%d", GetShaderQuality()), m_ConfigFile);
		WritePrivateProfileStringA("Graphic", "ModelQuality", Core::String::Format("%d", GetModelQuality()), m_ConfigFile);
		WritePrivateProfileStringA("Graphic", "SoftParticle", GetSoftParticle()?"1":"0", m_ConfigFile);
		WritePrivateProfileStringA("Graphic", "Fluency", Core::String::Format("%d",GetFluency()), m_ConfigFile);
	}


	void GameConfig::LoadKeys()
	{
		int forward = GetPrivateProfileIntA("Keys", "MoveForward", KC_W, m_ConfigFile);
		int backward = GetPrivateProfileIntA("Keys", "MoveBackward", KC_S, m_ConfigFile);
		int left =  GetPrivateProfileIntA("Keys", "MoveLeft", KC_A, m_ConfigFile);
		int right =  GetPrivateProfileIntA("Keys", "MoveRight", KC_D, m_ConfigFile);
		int jump = GetPrivateProfileIntA("Keys", "Jump", KC_SPACE, m_ConfigFile);
		int reload = GetPrivateProfileIntA("Keys", "Reload", KC_R, m_ConfigFile);
		int crouch = GetPrivateProfileIntA("Keys", "Crouch", KC_LCONTROL, m_ConfigFile);
		int change_weapon = GetPrivateProfileIntA("Keys", "ChangeWeapon", KC_Q, m_ConfigFile);
		int map = GetPrivateProfileIntA("Keys", "UIMap", KC_M, m_ConfigFile);
		int change = GetPrivateProfileIntA("Keys", "UIPack", KC_B, m_ConfigFile);
		int UseSkill = GetPrivateProfileIntA("Keys", "UseSkill", KC_G, m_ConfigFile);
		int UseSkill2 = GetPrivateProfileIntA("Keys", "UseSkill2", KC_E, m_ConfigFile);
		int	UseSkillSurvival_1 = GetPrivateProfileIntA("Keys", "UseSkillSurvival_1", KC_1, m_ConfigFile);	
		int	UseSkillSurvival_2 = GetPrivateProfileIntA("Keys", "UseSkillSurvival_2", KC_2, m_ConfigFile);
		int	UseSkillSurvival_3 = GetPrivateProfileIntA("Keys", "UseSkillSurvival_3", KC_3, m_ConfigFile);
		int	UseSkillSurvival_4 = GetPrivateProfileIntA("Keys", "UseSkillSurvival_4", KC_4, m_ConfigFile);
		int	UseSkillSurvival_5 = GetPrivateProfileIntA("Keys", "UseSkillSurvival_5", KC_5, m_ConfigFile);

		BindAction(kActionMoveForward,(InputCode)forward);
		BindAction(kActionMoveBackward,(InputCode)backward);
		BindAction(kActionMoveLeft,(InputCode)left);
		BindAction(kActionMoveRight,(InputCode)right);
		BindAction(kActionJump,(InputCode)jump);
		BindAction(kActionReload,(InputCode)reload);
		BindAction(kActionCrouch,(InputCode)crouch);
		BindAction(kActionChangeWeapon,(InputCode)change_weapon);
		BindAction(kActionUIMap,(InputCode)map);
		BindAction(kActionUIPack,(InputCode)change);
		BindAction(kActionUseSkill,(InputCode)UseSkill);
		BindAction(kActionUseSkill2,(InputCode)UseSkill2);
		BindAction(kActionUseSkillSurvival_1,(InputCode)UseSkillSurvival_1);
		BindAction(kActionUseSkillSurvival_2,(InputCode)UseSkillSurvival_2);
		BindAction(kActionUseSkillSurvival_3,(InputCode)UseSkillSurvival_3);
		BindAction(kActionUseSkillSurvival_4,(InputCode)UseSkillSurvival_4);
		BindAction(kActionUseSkillSurvival_5,(InputCode)UseSkillSurvival_5);
	}

	void GameConfig::SaveKeys()
	{
		for (int i = 0; i < ELEMENTS_OF(action_map); i++)
		{
			for (int j = 0; j < ACTION_INPUT_MAX; j++)
			{
				if (action_map[i].input_set[j] != KC_UNUSED)
					WritePrivateProfileStringA("Keys",action_map[i].description.Str(),Core::String::Format("%d",(int)action_map[i].input_set[j]),m_ConfigFile);
			}
		}
	}

	bool GameConfig::GetMusicOff()
	{
		return GetPrivateProfileIntA("Audio", "MusicOff", 0, m_ConfigFile) == 1;
	}
	bool GameConfig::GetSoundOff()
	{
		return GetPrivateProfileIntA("Audio", "SoundOff", 0, m_ConfigFile) == 1;
	}

	void GameConfig::LoadAudio()
	{
		if (gGame->global)
		{
			bool audio_off = GetPrivateProfileIntA("Audio","AudioOff", 0, m_ConfigFile) == 1;
			bool music_off = GetPrivateProfileIntA("Audio", "MusicOff", 0, m_ConfigFile) == 1;
			bool sound_off = GetPrivateProfileIntA("Audio", "SoundOff", 0, m_ConfigFile) == 1;
			if (audio_off)
			{
				music_off = sound_off = true;
			}
			SetAudioOff(audio_off);
			gGame->global->CategorySetMute("music", music_off);
			gGame->global->CategorySetMute("sound", sound_off);

			int audio_value = GetPrivateProfileIntA("Audio", "AudioValue", 50, m_ConfigFile);
			int music_value = GetPrivateProfileIntA("Audio", "MusicValue", 50, m_ConfigFile);
			int sound_value =  GetPrivateProfileIntA("Audio", "SoundValue", 50, m_ConfigFile);

			audio_value = Core::Max(audio_value, music_value);
			audio_value = Core::Max(audio_value, sound_value);

			SetAudioValue(audio_value);
			gGame->global->CategorySetVolume("music", music_value);
			gGame->global->CategorySetVolume("sound", sound_value);

			UpdateAudioProportion();
		}
	}

	void GameConfig::SaveAudio()
	{
		if (gGame->global)
		{
			WritePrivateProfileStringA("Audio", "AudioOff", GetAudioOff()?"1":"0", m_ConfigFile);
			WritePrivateProfileStringA("Audio","MusicOff",gGame->global->CategoryGetMute("music")?"1":"0",m_ConfigFile);
			WritePrivateProfileStringA("Audio","SoundOff",gGame->global->CategoryGetMute("sound")?"1":"0",m_ConfigFile);

			int audio_value = GetAudioValue();
			int music_value = gGame->global->CategoryGetVolume("music");
			int sound_value = gGame->global->CategoryGetVolume("sound");

			WritePrivateProfileStringA("Audio","AudioValue",Core::String::Format("%d",audio_value),m_ConfigFile);
			WritePrivateProfileStringA("Audio","MusicValue",Core::String::Format("%d",music_value),m_ConfigFile);
			WritePrivateProfileStringA("Audio","SoundValue",Core::String::Format("%d",sound_value),m_ConfigFile);
		}
	}

	void GameConfig::LoadTips()
	{
		bool tips = GetPrivateProfileIntA("Tips","Tips", 1, m_ConfigFile) == 1;
		SetTips(tips);
	}

	void GameConfig::SaveTips()
	{
		WritePrivateProfileStringA("Tips", "Tips", GetTips()?"1":"0", m_ConfigFile);
	}

	void GameConfig::SaveConfig()
	{
		if(gGame->lobby_connection && m_SettingStream.Length())
		{
			gGame->lobby_connection->RequestSaveConfig(m_SettingStream);
		}
	}

	void GameConfig::SaveProfile()
	{
		EventSaveProfile.Fire(ptr_static_cast<Client::GameConfig>(this), Core::EventArgs());
		if(gGame->lobby_connection && m_ProfileStream.Length())
		{
			gGame->lobby_connection->RequestSaveCharacterProfile(m_ProfileStream);
		}
	}

	void GameConfig::OnLoadConfig( const Core::String& configStream )
	{
		m_SettingStream = configStream;
		Client::CmdEventArgs args;
		args.Details = configStream;
		EventLoadSettings.Fire(ptr_static_cast<Client::GameConfig>(this), args);
	}

	void GameConfig::OnLoadProfile( const Core::String& profileStream )
	{
		m_ProfileStream = profileStream;
		Client::CmdEventArgs args;
		args.Details = profileStream;
		EventLoadProfile.Fire(ptr_static_cast<Client::GameConfig>(this), args);
	}

	Core::Vector2 GameConfig::GetBestResolution()
	{
		DEVMODE dm;
		dm.dmSize = sizeof(DEVMODE);
		::EnumDisplaySettings(NULL, ENUM_CURRENT_SETTINGS, &dm);

		if (gGame && gGame->screen)
			return gGame->screen->GetDesktopSize();
		else
			return Core::Vector2::kZero;
	}

	String GameConfig::GetBillBoardV()
	{
		return gHttpConfig.http_advertising_v;
	}
	
	String GameConfig::GetBillBoardH()
	{
		return gHttpConfig.http_advertising_h;
	}

	String GameConfig::GetLogo()
	{
		return gHttpConfig.http_xl_logo;
	}

	byte GameConfig::GetNickNameLengthMin()
	{
		return gHttpConfig.nick_name_length_min;
	}

	byte GameConfig::GetNickNameLengthMax()
	{
		return gHttpConfig.nick_name_length_max;
	}

	byte GameConfig::GetBattleGroupNameLengthMin()
	{
		return gHttpConfig.battle_group_name_length_min;
	}

	byte GameConfig::GetBattleGroupNameLengthMax()
	{
		return gHttpConfig.battle_group_name_length_max;
	}

	byte GameConfig::GetTimeSellDate()
	{
		return gHttpConfig.time_sell_date;
	}

	byte GameConfig::GetTimeSellStart()
	{
		return gHttpConfig.time_sell_start;
	}

	byte GameConfig::GetTimeSellStartDate()
	{
		return gHttpConfig.time_sell_start_date;
	}

	byte GameConfig::GetTimeSellEnd()
	{
		return gHttpConfig.time_sell_end;
	}

	byte GameConfig::GetTimeSellEndDate()
	{
		return gHttpConfig.time_sell_end_date;
	}

	byte GameConfig::GetTimeSellGiftH()
	{
		return gHttpConfig.time_sell_giftH;
	}

	byte GameConfig::GetTimeSellGiftM()
	{
		return gHttpConfig.time_sell_giftM;
	}

	String GameConfig::GetQuickSellData()
	{
		return gHttpConfig.quick_sell_data;
	}

	const char GameConfig::GetUISystemFlag(int index)
	{
		int lenth = gHttpConfig.UISystemFlag.Length();
		if(index > lenth-1)
		{
			return 0;
		}
		return gHttpConfig.UISystemFlag.Str()[index] - '0';
	}

	byte GameConfig::GetRoomNameLengthMin()
	{
		return gHttpConfig.room_name_length_min;
	}
	byte GameConfig::GetRoomNameLengthMax()
	{
		return gHttpConfig.room_name_length_max;
	}

	bool GameConfig::IsInAchievementList(const Core::String& id)
	{
		bool flag = false;
		for(uint i = 0; i < m_achievementlist.Size(); i++)
		{
			if (id == m_achievementlist.GetAt(i))
			{
				flag = true;
				break;
			}
		}
		return flag;
	}
}