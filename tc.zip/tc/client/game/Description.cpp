#include "pch.h"

using namespace Core;

DEFINE_PDE_TYPE_CLASS(Client::Description)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_METHOD(LoadDescription);

		ADD_PDE_METHOD(GetWeaponDescriptionText);
		ADD_PDE_METHOD(GetWeaponDescriptionColor);
	}
};

REGISTER_PDE_TYPE(Client::Description);

namespace Client
{
	Description* gDescription = NULL;
}

namespace Client
{
#define DESCRIPTION_VAR  "_VAR_"
#define DESCRIPTION_SVAR "_SVAR_"

	Description::Description()
	{
		PDE_ASSERT(!gDescription, "gDescription is not null");

		gDescription = this;
	}

	Description::~Description()
	{
		PDE_ASSERT(gDescription, "gDescription is null");

		gDescription = NULL;
	}

	bool Description::LoadDescription()
	{
		return LoadWeaponDescription();
	}

	String Description::GetWeaponDescriptionText(short type, short value1, short value2, short time)
	{
		return String::kEmpty;
	}

	ARGB Description::GetWeaponDescriptionColor(short type, short value1, short value2, short time)
	{
		return ARGB(255, 241, 211);
	}


	//
	bool Description::LoadWeaponDescription()
	{
		bool result = false;
		CStrBuf<256> filename;
		filename.format("/scripts/description/weapon.lua");

		sharedc_ptr(ScriptLua) lua = RESOURCE_LOAD(filename, false, ScriptLua);
		if (lua)
		{
			Lua::LuaState *L = Lua::LuaState::NewState();
			L->OpenLibs();

			int top = L->GetTop();
			L->NewTable();
			if (L->LoadBuffer(lua->GetBuffer(), lua->GetSize(), filename) == 0)
			{
				//load weapon description
				L->PushValue(top + 1);
				L->SetFenv(-2);

				if (L->DoCall(0, 0))
				{
					const char *msg = L->ToString(-1);
					if (msg) Console.WriteLine(msg);
					L->Pop(1);
				}
				else
				{
					WeaponDescriptionColors.Clear();
					WeaponDescriptionTable.Clear();

					L->GetField(-1, "colors");
					int size = L->ObjLen(-1);
					for(int i = 1; i <= size; ++i)
					{
						L->PushInteger(i);
						L->GetTable(-2);

						U8 a, r, g, b;

						L->PushInteger(1);
						L->GetTable(-2);
						a = L->ToInteger(-1);
						L->Pop(1);

						L->PushInteger(2);
						L->GetTable(-2);
						r = L->ToInteger(-1);
						L->Pop(1);

						L->PushInteger(3);
						L->GetTable(-2);
						g = L->ToInteger(-1);
						L->Pop(1);

						L->PushInteger(4);
						L->GetTable(-2);
						b = L->ToInteger(-1);
						L->Pop(1);

						WeaponDescriptionColors.PushBack(ARGB(a, r, g ,b));

						L->Pop(1);
					}
					L->Pop(1);

					L->GetField(-1, "weapons");
					size = L->ObjLen(-1);
					for(int i = 1; i <= size; ++i)
					{
						L->PushInteger(i);
						L->GetTable(-2);

						short type = 0;
						U32 color_index = 0;
						WeaponDescriptionData data;

						L->PushInteger(1);
						L->GetTable(-2);
						type = L->ToInteger(-1);
						L->Pop(1);

						L->PushInteger(2);
						L->GetTable(-2);
						color_index = L->ToInteger(-1) - 1;
						L->Pop(1);
						if (color_index < WeaponDescriptionColors.Size())
						{
							data.color = WeaponDescriptionColors[color_index];
						}
						else
						{
							LogSystem.WriteLinef("WeaponDescription[%d], illegal color index", i);
						}

						L->PushInteger(3);
						L->GetTable(-2);
						data.text = L->ToString(-1);
						L->Pop(1);

						L->PushInteger(4);
						L->GetTable(-2);
						data.has_param[0] = L->ToInteger(-1);
						L->Pop(1);

						L->PushInteger(5);
						L->GetTable(-2);
						data.has_param[1] = L->ToInteger(-1);
						L->Pop(1);

						L->PushInteger(6);
						L->GetTable(-2);
						data.has_param[2] = L->ToInteger(-1);
						L->Pop(1);

						WeaponDescriptionTable.Add(type, data);

						L->Pop(1);
					}
					L->Pop(1);

					result = true;
				}
			}
			else
			{
				const char *msg = L->ToString(-1);
				if (msg) Console.WriteLine(msg);
				L->Pop(1);
			}
			L->Close();
		}

		return result;
	}
}
