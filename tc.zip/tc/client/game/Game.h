namespace Client
{
	class Game : public Core::Object
	{
	public:
		Game();

		void OnCreate();
		void OnDestroy();

		void OnInput(InputEventArgs & args);
		void OnMessage();
		void OnUpdate();
		void OnRender();
		void OnTimeStepUpdate(float frame_time);

		int HttpXLInfo(const char* bugtitle, const char* bugdesc, const char* qq, const char* phone, int type);
		int HttpXLReport(const char* report_character_id, int report_type, const char* report_desc);

		int HttpFaceBook();

		HRESULT TakePicture();
	public:
		sharedc_ptr(DirectX9) dx9;
		sharedc_ptr(D3DRender) render;

#if	DEBUG_INFO
		sharedc_ptr(DebugRender)	debug_render;
#endif

		sharedc_ptr(Input)		input;
		sharedc_ptr(Level)		level;
		sharedc_ptr(Screen)		screen;
		sharedc_ptr(Camera)		camera;
		sharedc_ptr(ScoreBoard)	scores;

		sharedc_ptr(LobbyConnection) lobby_connection;
		sharedc_ptr(ChannelConnection) channel_connection;

#ifndef MASTER
		sharedc_ptr(Gui::ConsoleUI) console;
#endif

		sharedc_ptr(GameConfig) config;
		sharedc_ptr(GameGlobal) global;

		sharedc_ptr(Languages) langs;
		sharedc_ptr(Description) description;

		sharedc_ptr(Gui::GuiSystem) guiSys;

		StateMachine machine;
		ClientAddress address;

		int round_time;
		float m_second;

		uint net_bytes_send;
		uint net_bytes_received;
		uint fps;

		float font_size_off;

		//WebBrowserWindow*	m_WebBrowser;
		//bool				m_WebBrowserVisible;
		bool				fps_flag;
		double				fps_limit;

		bool				use_luncher;

		Core::String		version;
		Core::String		buildlog;
		Core::String		language;

		Core::String		error_message;

		void ReportError(const Core::String & error);

		void ClearReportError();

#if DEBUG_INFO
		Core::Deque<Core::String> error_display;
		float	error_display_time;
#endif
#if DEBUG_TOOLS
		bool bdebugSceneState;
#endif
		bool notify_error;

		bool is_first_time_connect;

		int fcm_flag;
		bool bSavePhoto;

		bool need_leave_channel;
		bool need_leave_roomlist;
		bool IsInitApex;
		
		short account_type;
		//sharedc_ptr(Core::IThread) checkhook_thread;

	};
}
