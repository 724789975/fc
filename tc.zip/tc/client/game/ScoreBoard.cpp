#include "pch.h"

using namespace Core;
using namespace Client;

struct character_compare
{
	bool operator ()(Character * c1, Character * c2) const
	{
		if (c1->all_score > c2->all_score)
			return true;

		if (c1->all_score < c2->all_score)
			return false;

		return c1->GetName() < c2->GetName();
	};
};

ScoreBoard::ScoreBoard()
{
	team_score[0] = team_score[1] = 0;
	team_kills[0] = team_kills[1] = 0;
	team_round[0] = team_round[1] = 0;
}

void ScoreBoard::Kill(by_ptr(Character) from, by_ptr(Character) to, byte assist, byte part, by_ptr(WeaponInfo) weapon_info,byte sustaintype)
{
	while (kill_list.Size() >= 5)
		kill_list.RemoveAt(0);

	KillHistory & history = kill_list.PushBack();

	history.team1 = 0;
	history.team2 = 0;
	//�ս��ɱ
	if (from && assist == from->uid)
		history.uid_assist = -1;	
	else
		history.uid_assist = assist;

	if (from && from->GetTeam() < 2)
	{
		history.name1 = from->GetName();
		history.team1 = from->GetTeam();

		if (to && from->GetTeam() != to->GetTeam())
			team_kills[from->GetTeam()] ++;
	}

	if (to && to->GetTeam() < 2)
	{
		history.name2 = to->GetName();
		history.team2 = to->GetTeam();
	}

	history.part = part;
	history.weapon_info = weapon_info;
	history.sustainhurttype = sustaintype;
	kill_list_scroll_time = 5.0f;

}

void ScoreBoard::Update(float frameTime)
{
	if (!kill_list.Empty())
	{
		kill_list_scroll_time -= frameTime;

		if (kill_list_scroll_time <= 0)
		{
			kill_list.RemoveAt(0);
			kill_list_scroll_time = 5;
		}
	}

	// refresh
	teams[0].Clear();
	teams[1].Clear();
	teams[2].Clear();

	tempc_ptr(Character) player = gLevel->GetPlayer();

	if (player)
	{
		// self
		if (player->GetTeam() < 3)
			teams[player->GetTeam()].PushBack(player);

		const Array<sharedc_ptr(Character)> & characters = gLevel->GetCharacters();

		// players.
		for (uint i = 0; i < characters.Size(); i ++)
		{
			tempc_ptr(Character) c = characters[i];

			if (c /*&& c->connected*/ && c->GetTeam() < 3)
				teams[c->GetTeam()].PushBack(c);
		}

		// sort by kill.
		quick_sort<character_compare>(teams[0].GetData(), teams[0].Size());
		quick_sort<character_compare>(teams[1].GetData(), teams[1].Size());
	}

	// update score
	switch (score_type)
	{
	case kRounds:
		team_score[0] = team_round[0];
		team_score[1] = team_round[1];
		break;

	default:
		team_score[0] = team_kills[0];
		team_score[1] = team_kills[1];
		break;
	}
}

void ScoreBoard::Clear()
{
	kill_list.Clear();
	teams[0].Clear();
	teams[1].Clear();
	teams[2].Clear();
	team_score[0] = team_score[1] = 0;
	team_kills[0] = team_kills[1] = 0;
	team_round[0] = team_round[1] = 0;
}