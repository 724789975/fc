namespace Client
{
	// client address
	struct ClientAddress
	{
		uint server_id;
		uint channel_id;
		uint room_id;

		Core::String server_name;
		Core::String channel_name;

		ClientAddress()
			: server_id(0)
			, channel_id(0)
			, room_id(0)
		{
			server_name = "";
			channel_name = "";
		}

		ClientAddress(uint server, uint channel, uint room)
			: server_id(server)
			, channel_id(channel)
			, room_id(room)
		{
		}
	};

	struct RoomOption
	{
		enum GameType
		{
			kGameTypeNone = -1,
			kTeam = 0,
			kHoldPoint,
			kPushVehicle,
			kNovice,
			kTeamDeathMatch,
			kBoss,
			kKnifeMode,
			kBombMode,
			kStreetBoyMode,
			kZombieMode,
			kBossPVE,
			kCommonZombieMode,
			kBossMode2,
			kItemMode,
			kEditMode,
			kTDMode,
			KMoonMode,
			kAdvenceMode,
			kSurvivalMode,
			kMatchingMode,
			kGameTypeCount,
		};

		enum SpecialMode
		{
			kNormal = 0,
			kSniper = 1,
			kPistal = 2,
			//kKnife = 3,

			kSpecialModeCount,
		};

		enum ViewMode
		{
			kFirstView = 0,
			kThirdView,
		};

		// constructor
		RoomOption()
			: client_count(16)
			, viewer_count(0)

			, level_id(0)
			, map_level(0)
			, character_id(0)

			, game_type(kTeam)
			, rule_value(100)
			, special_mode(kNormal)

			, round_rebirth_time_max(5)
			, dead_view_mode(kFirstView)
			, can_join_on_playing(true)
			, check_game_balance(false)
			, team_hurt(false)
			, group_match(false)
			, auto_start(false)
			, is_knife(0)
			, is_gm(0)

			, use_password(false)

			, item_id(0)
			, is_matching(0)
		{
		}

		Core::String	name;
		Core::String	map_name;

		bool			use_random_map;
		int				level_id;
		int				map_level;
		Core::String	rand_key;
		int             character_id;

		char			client_count;
		char			viewer_count;
		GameType		game_type;
		int				rule_value;
		SpecialMode		special_mode;

		short			round_rebirth_time_max;
		ViewMode		dead_view_mode;
		bool			can_join_on_playing;
		bool			check_game_balance;
		bool			team_hurt;
		bool			group_match;
		bool			auto_start;
		byte			is_knife;
		byte			is_gm;

		byte			is_matching;

		bool			use_password;
		Core::String	password;

		// room itme
		uint			item_id;
		Core::String	item_resource;
		Core::String	item_name;
	};

	struct RoomInfo
	{
		RoomInfo()
			: id(0)
			, host_id(0)
			, state(0)
			, client_count(0)
			, character_level(0)
		{
		}

		short		id;

		int				host_id;
		Core::String	host_name;
		byte			is_vip;
		byte			net_bar_level;
		uint			character_level;

		byte		state;
		char		client_count;
		RoomOption	option;
		double		autostart_time;

	};

	struct RoomSlot
	{
		enum Status
		{
			kClosed,
			kOpen,
			kView,
		};

		byte id;
		byte team;
		uint status;

		Core::String preserve_character_name;
	};

	struct ClientInfo
	{
		int				id;
		int				character_id;
		Core::String	name;
		Core::String	group;
		Core::String	icon;
		byte			team;
		byte			is_vip;
		byte			net_bar_level;
		byte			business_card;
		byte			is_gm;
		bool			ready;
		int				level;
		int				exp;
		int				top;
		int				fightnum;
		float			win_rate;
		bool			is_host;
		bool			in_game;
	};

	struct ChannelClientInfo
	{
		int				character_id;
		Core::String	name;
		Core::String	group;
		Core::String	icon;
		int				level;
		byte			is_vip;
		byte			net_bar_level;
		byte			business_card;
		byte			is_gm;
	};
	
	
	struct LevelInfo
	{
		// struct
		LevelInfo()
			: id (0)
			, type(RoomOption::kTeam)
			, is_vip(0)
			, is_new(0)
			, is_gm(0)
		{
		}
		int						id;
		Core::String			name;
		RoomOption::GameType	type;

		Core::String			show_name;
		Core::String			description;

		byte					is_vip;
		byte					is_new;

		int						gai_lv;
		byte					is_gm;
	};

	struct TeamMember
	{
		bool leader;
		Core::String name;
		Core::String group;
		byte gender;
		int level;
		int exp;
		int state;
		ClientAddress address;
	};

	struct RoomSearchOptions
	{
		bool all_channels;
		RoomOption::GameType game_type;
		uint level_id;
		byte num_clients;
		bool playing;
		bool waiting;
	};

	enum ServerType
	{
		SvrType_None = 0,				// 
		SvrType_NewComer = 1,			//����
		SvrType_Improve = 2,			//����
		SvrType_PastMaster = 3,			//���� 
		SvrType_StriveForResource = 4,  //��Դ����
		SvrType_HappyJump = 5,          //������
		SvrType_Match = 6,				// ƥ��
		SvrType_MatchFighting = 7,
	};

	struct ServerInfo
	{
		uint id;
		Core::String name;
		uint online_count;
		uint online_max;
		byte isnovice;
		Core::String gametype_limit;
		ServerType   servertype;
		uint Channelcount;
		uint nMinLevel;
		uint nMaxLevel;

	};

	struct ChannelInfo
	{
		uint id;
		Core::String name;
		bool online;
		uint online_max;
		uint online_count;
		uint min_level;
		uint max_level;
	};

	//ս��ս�Լ���Ϣ
	struct BattlePlayerInfo
	{
		BattlePlayerInfo()
			: battlegroup_id (0)
			, battle_server_id(0)
			, battle_channel_id(0)
			, battle_room_id(0)
			, ownerclient_uid(0)
			, group_level(0)
			, group_name("")
			, client_size(0)
			, vs_group_name("")
			, group_id(0)
		{
		}
		uint battlegroup_id;

		uint battle_server_id;
		uint battle_channel_id;
		uint battle_room_id;

		RoomOption roomoption;

		uint ownerclient_uid;
		uint group_level;
		Core::String group_name;
		uint group_id;
		uint client_size;
		Core::String vs_group_name;
	};
	//ս��ս������Ա��Ϣ
	struct BattleOtherPlayerInfo
	{
		BattleOtherPlayerInfo()
			: client_uid (-1)
			, character_name("")
			, head_icon("")
			, character_level(0)
			, character_exp(0)
			, is_vip(0)
			, net_bar_level(0)
			, business_card(0)
			, is_gm(0)
			, is_ready(0)
		{
		}
		uint client_uid;
		Core::String character_name;
		Core::String head_icon;
		uint character_level;
		int character_exp;
		byte is_vip;
		byte net_bar_level;
		byte business_card;
		byte is_gm;
		byte is_ready;
	};
	struct BattleRoom
	{
		BattleRoom()
		{
			for (int i = 0 ; i < 6 ; i++)
			{
				player[i] = BattleOtherPlayerInfo();
			}
		}
		BattleOtherPlayerInfo player[6];
	};

	class MessagePacket : public Core::BinaryNetworkReader
	{
	public:
		// constructor
		MessagePacket(void* data, int size, int offset = 4);

		// destructor
		~MessagePacket();

	public:
		// get message type
		byte GetMessageType();

		// get message time
		float GetMessageTime();

		// set message time
		void SetMessageTime(float time);

		// reset
		void Reset();

	public:
		void*	data_buffer;
		int		data_size;
		int		data_offset;
	};

	// read room info
	void ReadRoomInfo(Core::BinaryNetworkReader & reader, RoomInfo & info);

	// read client info
	void ReadClientInfo(Core::BinaryNetworkReader & reader, ClientInfo & info);

	// write room option
	void WriteRoomOption(Core::BinaryNetworkStream & writer, const RoomOption & option);

	// read room option
	void ReadRoomOption(Core::BinaryNetworkReader & reader, RoomOption & option);

	// read room info
	void ReadRoomSlot(Core::BinaryNetworkReader & reader, RoomSlot & slot);
}