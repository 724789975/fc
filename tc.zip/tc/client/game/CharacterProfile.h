namespace Client
{
	class CharacterProfile
	{
	public:

		SIMPLE_PDE_ATTRIBUTE_RW(InviteOff,		bool);
		SIMPLE_PDE_ATTRIBUTE_RW(GuideOff,		bool);
		SIMPLE_PDE_ATTRIBUTE_RW(LeaderEnter,	bool);
		SIMPLE_PDE_ATTRIBUTE_RW(SearchRoomWaiting,	bool);
		SIMPLE_PDE_ATTRIBUTE_RW(SearchRoomPlaying,	bool);
		SIMPLE_PDE_ATTRIBUTE_RW(SearchChannelCurrent, bool);
		SIMPLE_PDE_ATTRIBUTE_RW(SearchChannelVIP,	bool);
		SIMPLE_PDE_ATTRIBUTE_RW(SearchGameTypeIndex, int);
		SIMPLE_PDE_ATTRIBUTE_RW(SearchMapName,	Core::String);
		SIMPLE_PDE_ATTRIBUTE_RW(SearchOptionAutoSave, bool);
		SIMPLE_PDE_ATTRIBUTE_RW(SearchPlayerNum,	  int);
		SIMPLE_PDE_ATTRIBUTE_RW(LeaderEnterAutoSave,  bool);

	public:
		CharacterProfile();
		void	Save();
	};
}