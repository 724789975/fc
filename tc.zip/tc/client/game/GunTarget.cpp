#include "pch.h"

using namespace Core;
using namespace Client;

namespace Client
{
	GunTarget::GunTarget(by_ptr(GunTargetInfo) info)
	{
		guntarget_info = info;
		status = GUNTARGET_UP;
		pos_y = -2;
		is_starttoend = false;
		move_time = 0;
	}

	GunTarget::~GunTarget()
	{
		ReleasePhysX();
		mesh_guntarget = NullPtr;
		guntarget_info = NullPtr;
	}

	void GunTarget::ReleasePhysX()
	{
		PhysxSystem::ReleaseActor(*collider);
		collider = NULL;
	}

	void GunTarget::Initialize()
	{
		mesh_guntarget = ptr_new StaticMesh(MESH_KEY_PROP);
		CStrBuf<128> buff;
		buff.format("GunTarget/%s", guntarget_info->target_mesh_name);
		mesh_guntarget->AddPrimitive(buff,0);
		mesh_guntarget->SetPosition(Vector3(0,-100,0));
		SetPosition(guntarget_info->position);
		SetRotation(guntarget_info->rotation);

		collider = PhysxSystem::CreateBox(guntarget_info->position, guntarget_info->collision_box_dim, PhysxSystem::kGroupGunTarget);
		collider->userData = this;
		collider->setLinearVelocity(NxVec3(0.f, 0.f, 0.f));
		collider->setAngularVelocity(NxVec3(0.f, 0.f, 0.f));
		collider->setGlobalPosition((const NxVec3 &)(Vector3(0,-100,0)));
		collider->raiseBodyFlag(NX_BF_KINEMATIC);
	}

	void GunTarget::SetPosition(Core::Vector3& pos)
	{
		position = pos;
	}
	
	void GunTarget::SetRotation(Core::Quaternion& rot)
	{
		rotation = rot;
	}

	void GunTarget::Draw(Primitive::DrawType drawtype, bool immediate)
	{
		if (mesh_guntarget)
			mesh_guntarget->Draw(drawtype,immediate);
	}

	void GunTarget::Update(float frame_time)
	{
		if (guntarget_info->guntarget_type == STATIC)
		{
			if (status == GUNTARGET_DOWN)
			{
				if (pos_y > -2)
					pos_y -= (guntarget_info->position.y + 2) * frame_time * 10;
				else
					pos_y = -2;
			}
			else if (status == GUNTARGET_UP)
			{
				if (pos_y < guntarget_info->position.y)
					pos_y += (guntarget_info->position.y + 2) * frame_time * 10;
				else
					pos_y = guntarget_info->position.y;
			}
		}
		else
		{
			if (status == GUNTARGET_DOWN)
			{
				if (pos_y > -2)
					pos_y -= (guntarget_info->position.y + 2) * frame_time * 6;
				else
					pos_y = -2;
			}
			else if (status == GUNTARGET_UP)
			{
				if (pos_y < guntarget_info->position.y)
					pos_y += (guntarget_info->position.y + 2) * frame_time * 8;
				else
					pos_y = guntarget_info->position.y;
			}
			move_time += frame_time*0.3;
			if(status == MOVEABLE)
			{
				if (!is_starttoend)
				{
					Core::Lerp(position, guntarget_info->position, guntarget_info->end_position, move_time);
					if (Core::Length(position-guntarget_info->end_position) < 0.1f || move_time >= 1.f)
					{
						move_time = 0.f;
						is_starttoend = true;
					}
				}
				else
				{
					Core::Lerp(position, guntarget_info->end_position, guntarget_info->position, move_time);
					if (Core::Length(position-guntarget_info->position) < 0.1f || move_time >= 1.f)
					{
						move_time = 0.f;
						is_starttoend = false;
					}
				}
			}
		}
		position.y = pos_y;
		if (collider)
		{
			collider->setGlobalOrientationQuat((const NxQuat &)rotation);
		}
		if (mesh_guntarget)	
		{
			mesh_guntarget->SetPosition(position);
			mesh_guntarget->SetRotation(rotation);
			mesh_guntarget->Update();
		}
		UpdatePhysX();
	}

	int GunTarget::GetID()
	{
		return guntarget_info->id;
	}

	void GunTarget::UpdatePhysX()
	{
		collider->setGlobalPosition((const NxVec3 &)position);
	}

	bool GunTarget::CheckFire(const Core::Vector3 & pos, float & distance)
	{
		NxRaycastHit hit;

		if (collider)
		{
			NxRay ray;
			ray.orig = (NxVec3&)pos;
			ray.dir = collider->getGlobalPosition() -  (NxVec3&)pos;
			ray.dir.normalize();

			uint group_id = 0;
			group_id |= 1 << PhysxSystem::kStatic;
			group_id |= 1 << PhysxSystem::kStaticRaycast;
			group_id |= 1 << PhysxSystem::kGroupGunTarget;
			NxShape* shape = gPhysxScene->raycastClosestShape(ray, NX_ALL_SHAPES, hit, group_id);

			if (shape)
			{
				NxActor& raycast_actor = shape->getActor();
				if (raycast_actor.userData == collider->userData)
				{
					distance = hit.distance;
					return true;
				}
			}
		}

		return false;
	}

	static float RandomFloat(F32 x, F32 y)
	{
		float r = (F32)rand() / (RAND_MAX + 1);
		float num = x + (y - x) * r;
		return num; 
	}

	bool GunTarget::CheckStab(const tempc_ptr(KnifeInfo) knife_info)
	{
		tempc_ptr(Character) player = gLevel->GetPlayer();

		if (!player)
			return false;

		byte uid = 0;
		byte part = 0;

		uint group_id = 0;
		group_id |= 1 << PhysxSystem::kStatic;
		group_id |= 1 << PhysxSystem::kStaticRaycast;
		group_id |= 1 << PhysxSystem::kGroupGunTarget;

		Vector3 position = player->GetCameraPosition();
		Vector3 direction = Normalize(Vector3(0, 0, -1) * player->GetCameraRotation());
		Vector3 right = Normalize(Vector3(1, 0, 0) * player->GetCameraRotation());

		NxCapsule capsule;
		capsule.p0 = binary_cast<NxVec3>(position - right * knife_info->stab_width);
		capsule.p1 = binary_cast<NxVec3>(position + right * knife_info->stab_width);
		capsule.radius = 0.1f;

		NxSweepQueryHit hit;

		if (gPhysxScene->linearCapsuleSweep(capsule, binary_cast<NxVec3>(direction * (knife_info->stab_distance)), NX_SF_STATICS | NX_SF_DYNAMICS, NULL, 1, &hit, NULL, group_id, NULL))
		{
			if (hit.hitShape)
			{
				NxActor& raycast_actor = hit.hitShape->getActor();
				if (raycast_actor.userData == collider->userData)
				{
					return true;
				}
			}
		}
		return false;
	}

	bool GunTarget::CheckFire(const Core::Vector3 & position, const Core::Quaternion & rotation, float spread)
	{
		tempc_ptr(Character) player = gLevel->GetPlayer();
		if (!player)
			return false;

		float distance = 500;
		Vector3 pos = position;
		Vector3 dir = Vector3(0, 0, -1) * rotation;
		Vector3 up_dir = Vector3(0, 1, 0) * rotation;
		Vector3 right_dir = Vector3(1, 0, 0) * rotation;

		float x, y, z;
		x = RandomFloat( -0.5, 0.5 ) + RandomFloat( -0.5, 0.5 );
		y = RandomFloat( -0.5, 0.5 ) + RandomFloat( -0.5, 0.5 );
		z = x * x + y * y;

		dir += x * spread * right_dir + y * spread * up_dir;

		dir.Normalize();

		float distance_before = 0;

		bool fire_blank = false;

		NxRay ray;
		ray.orig = (const NxVec3 &)pos;
		ray.dir = (const NxVec3 &)dir;

		NxRaycastHit hit;
		uint group_id = 0;
		group_id |= 1 << PhysxSystem::kStatic;
		group_id |= 1 << PhysxSystem::kStaticRaycast;
		group_id |= 1 << PhysxSystem::kGroupGunTarget;

		NxShape* shape = gPhysxScene->raycastClosestShape(ray, NX_ALL_SHAPES, hit, group_id, distance);
		if (shape)
		{
			NxActor& raycast_actor = shape->getActor();
			if (raycast_actor.userData == collider->userData)
			{
				distance = hit.distance;
				return true;
			}
		}
		return false;
	}

	bool GunTarget::CheckFire(const Core::Vector3 & position, const Core::Quaternion & rotation, float spread, int userdata, int userdata2)
	{
		tempc_ptr(Character) player = gLevel->GetPlayer();

		if (!player)
			return false;

		float distance = userdata;

		Vector3 dir = Vector3(0, 0, -1) * rotation;
		Vector3 scanprange(userdata2, userdata2,0.001f);
		Core::Matrix44 rotmatrix(rotation);

		dir.Normalize();

		F32 firedistance = userdata;
		NxU32 staticGroups = 0;
		staticGroups |= 1 << PhysxSystem::kStatic;
		staticGroups |= 1 << PhysxSystem::kGroupGunTarget;
		NxRay ray;
		ray.orig = (const NxVec3 &)position;
		ray.dir = (const NxVec3 &)dir;
		NxRaycastHit rayhit;

		NxShape* shape = gPhysxScene->raycastClosestShape(ray, NX_ALL_SHAPES, rayhit, staticGroups, firedistance);
		if(shape > 0)
		{
			firedistance = rayhit.distance ;
			if(firedistance < 0.1f)
				firedistance = 0.1f;
		}

		Vector3 firemotion = dir * firedistance;
		bool fire_blank = true;

		//�������״
		NxMat33 matt;
		matt.setRow(0,NxVec3(rotmatrix._11,rotmatrix._12,rotmatrix._13));
		matt.setRow(1,NxVec3(rotmatrix._21,rotmatrix._22,rotmatrix._23));
		matt.setRow(2,NxVec3(rotmatrix._31,rotmatrix._32,rotmatrix._33));
		NxBox FlameBox((const NxVec3 &)position,(const NxVec3 &)scanprange,matt);
		

		//������ײ������
		NxU32 activeGroups = 0;
		activeGroups |=1 << PhysxSystem::kGroupGunTarget;

		NxSweepQueryHit hit[200];
		
		NxU32 num = gPhysxScene->linearOBBSweep(FlameBox,(const NxVec3 &)firemotion,NX_SF_DYNAMICS|NX_SF_ALL_HITS,NULL, 200, hit, NULL , activeGroups);
		for(NxU32 i = 0; i < num ;i++)
		{
			Core::Vector3 vct(hit[i].point.x, hit[i].point.y, hit[i].point.z);
			vct = vct - position;
			if(vct.Length() > distance)
				continue;
			float distance = vct.Length();

			if(hit[i].hitShape->getGroup() == PhysxSystem::kGroupGunTarget)
			{
				NxActor & actor = hit[i].hitShape->getActor();
				if (actor.userData == collider->userData)
				{
					return true;
				}
			}
		}
		return false;
	}

	tempc_ptr(GunTarget) GunTarget::FromNxActor(NxActor & actor)
	{
		Object * obj = (Object*)actor.userData;
		if (obj)
		{
			return ptr_dynamic_cast<GunTarget>(obj);
		}
		return NullPtr;
	}
}