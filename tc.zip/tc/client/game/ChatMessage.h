namespace Client
{
	struct ChatMessage
	{
		Core::Identifier	channel;
		Core::String		group;
		Core::String		sender;
		Core::String		msg;
		uint		        group_id;
		uint				server_Type;
	};
}