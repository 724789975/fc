namespace Client
{
	const int PLAYER_NUMBER = 16;
	const int PLAYER_CLASS = 5;
	const int PLAYER_TEAM = 2;

	const float CARRIRE_TIME	= 3.0f;
	const int	ITEM_ICON_NUM = 6;

	const float ScaleTime = 1.0f;		// ͼ��������Чʱ��

	class DieBuffDescString{
	public:
		enum{MAX_LENGTH =63};
		DieBuffDescString(){
			Desc[0] =0;
		}
		DieBuffDescString(const wchar_t* szStr){
			if(szStr && wcslen(szStr)<=MAX_LENGTH){
				wcscpy_s(Desc, szStr);
			}
			else{
				Desc[0] =0;
			}
		}		
		DieBuffDescString& operator=(const wchar_t* szStr){
			if(szStr && wcslen(szStr)<=MAX_LENGTH){
				wcscpy_s(Desc, szStr);
			}
			else{
				Desc[0] =0;
			}
			return *this;
		}

		wchar_t Desc[MAX_LENGTH+1];
	};

	class TextBox;
	class AnimPicture;
	class InGameUINew : public Core::Object
	{


		struct AnimSprite
		{
			sharedc_ptr(Texture2D)	texture;
			Core::PdeSplineF32		scale_spline;
			Core::PdeSplineF32		alpha_spline;
			Core::Vector3			position;
			Core::Float				rotation;

			AnimSprite()
				: position(0, 0, 0)
				, rotation(0)
			{}
		};

		struct SFlashInfo
		{
			float duration_timer;
			sharedc_ptr(Client::FlashPlayer) flash_player;
			Core::Rectangle player_rect;
			Core::String	name;

			SFlashInfo()
				:duration_timer(0)
				,flash_player(NullPtr)
			{
			}

			~SFlashInfo()
			{
				flash_player = NullPtr;
			}
		};

		struct DigitalSprite
		{
			sharedc_ptr(Texture2D)	texture;
			float anim_time;
			float alpha_time;
			Core::Vector2 start_pos;
			Core::Vector2 end_pos;
			Core::Vector2 pos;
			Core::String name;
			byte type;
		};

		struct AddBloodEffectInfo
		{
			int		data;
			float	time;		
			int		type;
			Core::Vector2 position;
		};

		struct SkillItem 
		{
			float	time;
			byte	type;
		};
	public:
		struct ButtonInfo
		{
			Core::Rectangle rect;
			byte state;
			byte icon_id;
			bool sub_state;
		};

		enum RecordType
		{
			CHANGECAMERA = 6,
			PRINTSCREEN = 7,
			STOP = 1,
			PLAY = 5,
			PAUSE = 4,
			SLOWPLAY = 3,
			QUICKPLAY = 2,
		};

	public:
		InGameUINew();
		~InGameUINew();
		// draw
		void Draw(by_ptr(UIRender) render);
		void OnInput(InputEventArgs & e);
		Core::String ParseParam(Core::CRefStr & Param);
		void ReceiveMsg(ChatMessage & msg);
		void SetWarningMsg(ChatMessage & msg);
		void AddMsgToMsgs(Core::String str, bool issys = false);
		int  SplitString( const Core::String& source, Core::String& target, const Core::Rectangle& rect, tempc_ptr(Client::Font) font );
		void SetInputFocus(bool value);
		void DrawSmallMap(by_ptr(UIRender) ui_render);
		void AddBloodEffectData(float time, int type, Core::Vector2 pos, int adddata = 0);
		void CloseChat();
		void InitPersonUI(tempc_ptr(Character) character);
		void DrawRadio(by_ptr(UIRender) render, Core::Matrix44 &world);
		void AddTipText(const Core::String& str);
		void OnPlayStop(by_ptr(void) sender, Core::EventArgs & e);
		void OnPlaycardStop(by_ptr(void) sender, Core::EventArgs & e);
		void OnPlayBigcardStop(by_ptr(void) sender, Core::EventArgs & e);
		void OnPlaySoundBackground();
		void OnAddSkillItem(byte type,float time);
		void OnAddSkillBuff_Item(byte type,float time);
		void OnAddItemModeItem(byte type,bool is_team,bool is_me);	

		void DrawItemModeZiBao(by_ptr(UIRender) ui_render);
		void InitTDMode();
		void InitEditMode();
		void InitDieBuffInfo();
		void Initialize_Flash(Core::String swfName, float swfTime, Core::Vector2 swfSize, Core::Rectangle drawRect);
		bool FlashIsPlaying(Core::String swfName);
		void SelectLeftItem();
		void SelectRightItem();

		


	private:
		void _InitHeadInfo();

		void _InitHeadIcon();

		void _InitBottomInfo();

		void _InitBGImage();

		void _InitSmallMapTextures();

		void _InitHitsImage();

		void _InitKillTextures();

		void _InitAnimSprite();

		void _InitGameTypeInfoTextures();

		void _InitTabShow();

		void _InitNovice();

		void _InitBombInfo();
		void _InitZombieInfo();
		void _InitBoss2Info();
		void _InitCommonZombieInfo();
		void _InitBossmode2Info();
		void _InitMoonMode();
		void _InitItemModeInfo();
		Core::Vector2 _GetNewPostion(Core::Vector2 pos,Core::Vector2 centerpos);

		


	private:
		void _DrawRoundTimeShow(by_ptr(UIRender) ui_render,int left_x,int left_y);

		void _DrawAllTeamMemberName(by_ptr(UIRender) ui_render);

		void _DrawHeadInfo(by_ptr(UIRender) ui_render);

		void _DrawBottomInfo(by_ptr(UIRender) ui_render);

		void _DrawWeaponList(by_ptr(UIRender) ui_render);

		void _DrawTargetEnemy(by_ptr(UIRender) ui_render);

		void _DrawHoldPostionInfo(by_ptr(UIRender) ui_render);

		void _DrawZombieInfo(by_ptr(UIRender) ui_render);

		void _DrawVehicleInfo(by_ptr(UIRender) ui_render);

		void _DrawSniperTargetHelper(by_ptr(UIRender) ui_render);

		void _DrawCrossHair(by_ptr(UIRender) ui_render);

		void _DrawUITimer(by_ptr(UIRender) ui_render);

		void _DrawUI_GunTowerBuilder(by_ptr(UIRender) ui_render);

		void _DrawSmallMapBG(by_ptr(UIRender) ui_render);

		void _DrawKillIcon(by_ptr(UIRender) ui_render);

		void _DrawTips_show(by_ptr(UIRender) ui_render,tempc_ptr(WeaponInfo) killerweapon,tempc_ptr(Character) c,Core::CStrBuf<256> buff,int ui_x,int ui_y);

		void _DrawAddBloodEffect(by_ptr(UIRender) ui_render);

		void _DrawDeadUi(by_ptr(UIRender) ui_render);

		void _DrawAddBloodTip(by_ptr(UIRender) render);

		void _DrawKillList(by_ptr(UIRender) ui_render);

		void _DrawScoreAnimation(by_ptr(UIRender) ui_render);

		void _DrawHorn(by_ptr(UIRender) ui_render);
		void _DrawHorn1(by_ptr(UIRender)ui_rotate);

		void _DrawControlTip(by_ptr(UIRender) ui_render);

		void  _ResertWeaponLevelRGB(int weaponLevel , bool isWeapon , int& r , int& g , int& b);

		void _DrawWeaponLevel(by_ptr(UIRender) ui_render ,int x , int y , int i , int weaponLevel ,sharedc_ptr(Texture2D) color);

		int _WeaponLevel(int level);

		void _DrawWeaponTip(by_ptr(UIRender) ui_render, tempc_ptr(Character) c);

		void _DrawTab(by_ptr(UIRender) ui_render);

		void _DrawBossTab(by_ptr(UIRender) ui_render);

		void _DrawZombieTab(by_ptr(UIRender) ui_render);

		void _DrawStartZombieTab(by_ptr(UIRender) ui_render);

		bool _GetDrawHelpPeopleUI();

		void _DrawBossPveTab(by_ptr(UIRender) ui_render);

		void _DrawCommonZombieTab(by_ptr(UIRender) ui_render);

		void _DrawNovice(by_ptr(UIRender) ui_render);

		void _DarwBigMap(by_ptr(UIRender) ui_render);

		void _DrawbombMap(by_ptr(UIRender) ui_render);

		void _DrawBombBottomInfo(by_ptr(UIRender) ui_render);

		void _DrawBomb_count_down(by_ptr(UIRender) ui_render);

		void _DrawBomb_Tips(by_ptr(UIRender) ui_render);

		bool GetbombTipsShow();

		void _Play_PlantedTimer_sound();

		void _Play_PlantedTimer_sound_stop();

		void _DrawItemModeBottomInfo(by_ptr(UIRender) ui_render);

		void _DrawMoonModeBottomInfo(by_ptr(UIRender) ui_render);

		void _DrawAdvenceModeBottomInfo(by_ptr(UIRender) ui_render);

		//����
		void _DrawSurvivalModBottomInfo(by_ptr(UIRender) ui_render);
		void _DrawGhostModBottomInfo(by_ptr(UIRender) ui_render);
        void _DrawQuantityBottmInfo( by_ptr(UIRender) ui_render);

		void _DrawTrapQuantityBottmInfo( by_ptr(UIRender) ui_render);
        void _DrawSurvivalQuantityBottmInfo( by_ptr(UIRender) ui_render);
        void _DrawGhostQuantityBottmInfo( by_ptr(UIRender) ui_render);
		void _InitHarmBottmInfo(by_ptr(UIRender) ui_render);
		void _DrawLivePromptBottmInfo( by_ptr(UIRender) ui_render);

		void _DrawBOSS2BottomInfo(by_ptr(UIRender) ui_render);
        void _InitInvincible(by_ptr(UIRender) ui_render);
	
		void _DrawCommonZombieBottomInfo(by_ptr(UIRender) ui_render);

		void _DrawCommonZombie_Level_up(by_ptr(UIRender) ui_render,Core::Vector2 pos,Core::Vector2 _size,int _len,F32& _time);

		void _DrawBossMode2_BottomInfo(by_ptr(UIRender) ui_render);

		void _DrawBossMode2_Bottom_Person_Info(by_ptr(UIRender) ui_render);

		void _DrawBossMode2_Picture_Shine(by_ptr(UIRender) ui_render,Core::Vector2 pos,Core::Vector2 _size,by_ptr(Texture2D) texture_ui);

		void _DrawBossMode2_humanSkill_rise(by_ptr(UIRender) ui_render,Core::Vector2 pos,Core::Vector2 _size,Core::Vector2 big_size,by_ptr(Texture2D) texture_ui,F32 totle_time,F32 _time);

		void _DrawBossMode2_humanSkill_rise_up(by_ptr(UIRender) ui_render,Core::Vector2 pos,Core::Vector2 _size,Core::Vector2 big_size,by_ptr(Texture2D) texture_ui,F32 totle_time,F32 _time,F32 static_time = 0.2f);

		void _DrawGunTower_Dummy(by_ptr(UIRender) ui_render);

		void _DrawTDmode(by_ptr(UIRender) ui_render);

		void _DrawEditMode(by_ptr(UIRender) ui_render);

		void _DrawCancelTowerGun(by_ptr(UIRender) ui_render);

        


	private:
		Core::Vector2 GetTextSize(by_ptr(Font) font, Core::String str);
		bool IsCharacterVisible(by_ptr(Character) c, int &x, int &y);
		bool IsGunTower_DummyVisible(by_ptr(DummyObject) tower, int &x, int &y);
		bool GetGunTower_Dummy_Hp_Position(by_ptr(DummyObject) tower, int &x, int &y);
		bool IsCharacterVisibleBySniper(by_ptr(Character) c, int &x, int &y, bool &isAim);
		void _DrawEnergyBar(by_ptr(UIRender) ui_render,by_ptr(Texture2D) texture_content, by_ptr(Texture2D) texture_content_alpha, by_ptr(Texture2D) texture, int x,int y,int width, int height, bool isshow = false);
		void _DrawNumberTextureWindow(by_ptr(UIRender) ui_render, by_ptr(Texture2D) uvTexture, Core::Vector2 vPos, int width, int height, int number, float uvWidth, Core::ARGB color = Core::ARGB(255,255,255,255));
		bool _DrawNoviceLength(by_ptr(UIRender) ui_render, by_ptr(Texture2D) texture_content, Core::Vector3 vPos, bool isdraw = true, int alllen = 1, Core::Vector3 vPosVehicle = Core::Vector3(0, 0, 0));
		Core::Vector3 CalcNewPosition(const Core::Vector3 &start, const Core::Vector3 &end);
		void _DrawCoolDown(int x, int y, int width, int height, by_ptr(Texture2D) texture_icon,by_ptr(Texture2D) texture_bg, by_ptr(Texture2D) texture_content, float fProgress, by_ptr(UIRender) ui_render, int offset = 0);
		void UpdataMvp();
		void SetMvp_State(bool is_play);
		void UpdataCard();
		void SetCard_State(int num = -1);

		bool Draw2DOjbect(by_ptr(UIRender) ui_render, by_ptr(Texture2D) texture_content, Core::Vector3 vPos);
		bool Draw2DCommonzombie_Ojbect(by_ptr(UIRender) ui_render, Core::Vector3 vPos,Core::Rectangle uv = Core::Rectangle(0,0,1,1));
		void Play_Cd_Scale_sound(int which,float value,Core::String string);
		void _DrawBOSS2BottomInfoSingle(by_ptr(UIRender) ui_render,Core::Vector2 pos,tempc_ptr(Character) c);
		void _DrawCommonZombieBottomMaps(by_ptr(UIRender) ui_render,sharedc_ptr(Texture2D)* Maps,sharedc_ptr(Texture2D)* Maps_Disable,int index = 0);
		void _DrawCommonZombieBottomdying(by_ptr(UIRender) ui_render);
		void _DrawCommonZombieBottom_PeopleImage(by_ptr(UIRender) ui_render);
		void _DrawCommonZombieHeadInfo(by_ptr(UIRender) ui_render);
		void _DrawBossMode2HeadInfo(by_ptr(UIRender) ui_render);
		// draw common zombie skill
		void _DrawCommonZombieSkill(by_ptr(UIRender) ui_render);
		void _DrawInitiativeSkill(by_ptr(UIRender) ui_render,Core::Vector2 pos,by_ptr(Texture2D) texture_button,by_ptr(Texture2D) texture_Skill,by_ptr(Texture2D) texture_Skill_shine,by_ptr(Texture2D) texture_Skill_bg,by_ptr(Texture2D) texture_Skill_bf,F32 f_v = 1.0f,F32 f_time = 0.f);
		// flash Pid
		
		void Flash_Play(by_ptr(UIRender) ui_render);
		void Delete_Flash();
		Core::String PeopleName_cut(Core::String name,int cut_num);
		void Commomzombie_FilterSameSkill(byte* type);
		void _DrawMiddle_String(by_ptr(UIRender) ui_render);
		void _DrawMiddleUP_String(by_ptr(UIRender) ui_render);
		void _DrawBottom_String(by_ptr(UIRender) ui_render);
		void _DrawBossMode2_Box(by_ptr(UIRender) ui_render,Core::Vector2 pos,Core::Vector2 _size,Core::Vector2 space,int life_num,int die_num,by_ptr(Texture2D) texture_content,by_ptr(Texture2D) texture_cancel = NullPtr);
		Core::Vector2 CalcVertAngleTextureUV();
		F32 CalcHoriAngleTextureUV();
		void _Draw_Picture_Move_uv(by_ptr(UIRender) ui_render);
		void _Draw_Die_Buff_Rand(by_ptr(UIRender) ui_render);
	public:
		// on create
		void OnCreate();
		void OnDestroy();
		void Update(float frameTime);
		void OnUpdate_SkillItem(float frameTime);
	private:
		//head info
		sharedc_ptr(Texture2D) ui_head_info_bg_center;
		sharedc_ptr(Texture2D) ui_head_info_bg_left;
		sharedc_ptr(Texture2D) ui_head_info_bg_right;
		sharedc_ptr(Texture2D) ui_head_info_bg_TeamDeath;
		sharedc_ptr(Texture2D) ui_head_info_bg_Zombie;
		sharedc_ptr(Texture2D) ui_head_info_bg_boss;
		sharedc_ptr(Texture2D) ui_head_info_time_bg;
		sharedc_ptr(Texture2D) ui_head_info_time_number;
		sharedc_ptr(Texture2D) ui_head_info_boss;
		sharedc_ptr(Texture2D) ui_head_info_boss_hp[4];
		sharedc_ptr(Texture2D) ui_head_tip[16];
		sharedc_ptr(Texture2D) ui_head_info_StreetBoy_Red;
		sharedc_ptr(Texture2D) ui_head_info_StreetBoy_Blue;
		sharedc_ptr(Texture2D) ui_head_infoStreetBoy_Hp_Blue;
		sharedc_ptr(Texture2D) ui_head_infoStreetBoy_Hp_Red;

		sharedc_ptr(Texture2D) ui_head_info_bg_boss_mode2_bg;
		sharedc_ptr(Texture2D) ui_head_info_round_boss_number;
		sharedc_ptr(Texture2D) ui_head_info_round_boss_number_r;
		
		//person info
		Core::HashSet<uint, sharedc_ptr(Texture2D)> ui_bottom_info_headhui_icon;
		Core::HashSet<uint, sharedc_ptr(Texture2D)> ui_bottom_info_headbinsi_icon;
		
		//bottom info
		sharedc_ptr(Texture2D) ui_bottomleft_info_bg[PLAYER_TEAM];
		sharedc_ptr(Texture2D) ui_bottomright_info_bg[PLAYER_TEAM];
		sharedc_ptr(Texture2D) ui_bottom_info_X;
		sharedc_ptr(Texture2D) ui_bottom_info_small_card;
		sharedc_ptr(Texture2D) ui_bottom_info_big_card;
		sharedc_ptr(Texture2D) ui_bottomleft_info_boos;
		sharedc_ptr(Texture2D) ui_bottomright_info_boos;
		sharedc_ptr(Texture2D) ui_bottommiddle_info_people;
		sharedc_ptr(Texture2D) ui_bottom_info_hp;
		sharedc_ptr(Texture2D) ui_bottom_info_hp_kuang;
		sharedc_ptr(Texture2D) ui_bottom_info_hp_number;
		sharedc_ptr(Texture2D) ui_bottom_info_hp_add;
		sharedc_ptr(Texture2D) ui_bottom_info_bullet_number;
		sharedc_ptr(Texture2D) ui_bottom_info_bullet_number2;
		sharedc_ptr(Texture2D) ui_bottom_info_CureGun[PLAYER_TEAM];
		sharedc_ptr(Texture2D) ui_bottom_info_CureGun_Content;
		sharedc_ptr(Texture2D) ui_bottom_info_CureGun_PowerNum;
		sharedc_ptr(Texture2D) ui_bottom_info_CureGun_Power;
		sharedc_ptr(Texture2D) ui_bottom_info_Exp;
		sharedc_ptr(Texture2D) ui_bottom_info_Exp_45;
		sharedc_ptr(Texture2D) ui_bottom_info_all;
		sharedc_ptr(Texture2D) ui_progress_bar_border;
		sharedc_ptr(Texture2D) ui_progress_bar_body;
		sharedc_ptr(Texture2D) ui_progress_bar_grenade_bg;
		sharedc_ptr(Texture2D) ui_progress_bar_grenade;
		sharedc_ptr(Texture2D) ui_headicon_boos;
		sharedc_ptr(Texture2D) ui_bottom_info_danjia;
		sharedc_ptr(Texture2D) ui_bottom_info_fuhuobi;
		sharedc_ptr(Texture2D) ui_bottom_info_GunTower_Picture[2];
		sharedc_ptr(Texture2D) ui_bottom_info_GunTower_Move_CD[2];
		sharedc_ptr(Texture2D) ui_bottom_info_GunTower_UnBuider;
		sharedc_ptr(Texture2D) ui_bottom_info_GunTower_bg;
		sharedc_ptr(Texture2D) ui_bottom_info_GunTower_energy;
		sharedc_ptr(Texture2D) ui_bottom_info_GunTower_energy_bg;
		sharedc_ptr(Texture2D) ui_bottom_info_GunTower_ammo;
		sharedc_ptr(Texture2D) ui_bottom_info_MiniMachine_gun_1;
		sharedc_ptr(Texture2D) ui_bottom_info_MiniMachine_gun_2;

		//ui for tab
		sharedc_ptr(Texture2D) ui_tab_red;
		sharedc_ptr(Texture2D) ui_tab_red_boss;
		sharedc_ptr(Texture2D) ui_tab_center;
		sharedc_ptr(Texture2D) ui_tab_center_boss;
		sharedc_ptr(Texture2D) ui_tab_center_zombie;
		sharedc_ptr(Texture2D) ui_tab_blue;
		sharedc_ptr(Texture2D) ui_tab_gray_boss;
		sharedc_ptr(Texture2D) ui_tab_gray_zombie;
		sharedc_ptr(Texture2D) ui_tab_bottom;
		sharedc_ptr(Texture2D) ig_tab_bg2;
		sharedc_ptr(Texture2D) ig_tab_win_num;
		sharedc_ptr(Texture2D) ig_tab_lose_num;
		sharedc_ptr(Texture2D) ig_tab_line;
		sharedc_ptr(Texture2D) ig_tab_level;
		sharedc_ptr(Texture2D) ig_tab_vip[9];
		sharedc_ptr(Texture2D) ig_tab_match[14];
		sharedc_ptr(Texture2D) ig_tab_xunleivip;
		sharedc_ptr(Texture2D) ui_tab_watch;
		sharedc_ptr(Texture2D) ui_tab_zombie_watch;
		sharedc_ptr(Texture2D) ui_tab_zombie_hp_bg;
		sharedc_ptr(Texture2D) ui_tab_BossPVE_bg;

		//ui for kill
		sharedc_ptr(Texture2D) ui_kill_textures[36];
		sharedc_ptr(Texture2D) ui_kill_textures_num;
		sharedc_ptr(Texture2D) ui_die_bg;
		sharedc_ptr(Texture2D) ui_die;

		//common ht
		sharedc_ptr(Texture2D) ui_common_hp_bg;
		sharedc_ptr(Texture2D) ui_common_hp_friend_bg;
		Core::HashSet<uint, sharedc_ptr(Texture2D)> ui_common_hp_headicon;
		sharedc_ptr(Texture2D) ui_common_hp[3];
		sharedc_ptr(Texture2D) ui_common_power;
		sharedc_ptr(Texture2D) ui_common_attack;
		sharedc_ptr(Texture2D) ui_common_speed;
		sharedc_ptr(Texture2D) ui_common_weaponlevel[18];
		sharedc_ptr(Texture2D) ui_common_notlevel;
		sharedc_ptr(Texture2D) ui_common_little_star;
		sharedc_ptr(Texture2D) ui_common_skin_bar[7];
		sharedc_ptr(Texture2D) ui_common_name_cards[32];
		sharedc_ptr(Texture2D) ui_common_vip_name_card;
		sharedc_ptr(Texture2D) ui_common_tab_name_cards[32];
		sharedc_ptr(Texture2D) ui_common_tab_vip_name_card[10];
		sharedc_ptr(Texture2D) ui_weapon[5];
		sharedc_ptr(Texture2D) ui_star;


		//small map
		sharedc_ptr(TextureBase) small_map;
		sharedc_ptr(Texture2D) ui_smallmap_bg;
		sharedc_ptr(Texture2D) ui_smallmap_supply_bullet;
		sharedc_ptr(Texture2D) ui_smallmap_supply_medkit;
		sharedc_ptr(Texture2D) ui_smallmap_supply_hp;
		sharedc_ptr(Texture2D) ui_smallmap_supply_tools;
		sharedc_ptr(Texture2D) ui_smallmap_supply_commonzombie;
		sharedc_ptr(Texture2D) ui_smallmap_bomb_arrayA;
		sharedc_ptr(Texture2D) ui_smallmap_bomb_arrayB;
		sharedc_ptr(Texture2D) ui_smallmap_supply_item_special;

		sharedc_ptr(Texture2D) ui_smallmap_supply_item_ghost;
		sharedc_ptr(Texture2D) ui_smallmap_supply_item_snare;



		//hold point info zd
		sharedc_ptr(Texture2D) ui_hold_point_info_bg_border_L;
		sharedc_ptr(Texture2D) ui_hold_point_info_bg_border;
		sharedc_ptr(Texture2D) ui_hold_point_info_bg_border_R;
		sharedc_ptr(Texture2D) ui_hold_point_info_progress;
		sharedc_ptr(Texture2D) ui_hold_point_info_flag_red;
		sharedc_ptr(Texture2D) ui_hold_point_info_flag_blue;
		sharedc_ptr(Texture2D) ui_hold_point_info_board_red;
		sharedc_ptr(Texture2D) ui_hold_point_info_board_blue;
		sharedc_ptr(Texture2D) ui_hold_point_info_waifaguang_bg;
		sharedc_ptr(Texture2D) ui_hold_point_info_waifaguang_board;
		sharedc_ptr(Texture2D) ui_hold_point_info_people;
		sharedc_ptr(Texture2D) ui_hold_point_length;
		sharedc_ptr(Texture2D) ui_hold_point_timer_red;
		sharedc_ptr(Texture2D) ui_hold_point_timer_blue;
		sharedc_ptr(Texture2D) ui_hold_point_timer2_red;
		sharedc_ptr(Texture2D) ui_hold_point_timer2_blue;
		sharedc_ptr(Texture2D) ui_hold_point_neifaguang;

		//vehicle
		sharedc_ptr(Texture2D) ui_vehicle_info_bg;
		sharedc_ptr(Texture2D) ui_vehicle_info_left;
		sharedc_ptr(Texture2D) ui_vehicle_info_right;
		sharedc_ptr(Texture2D) ui_vehicle_info_red;
		sharedc_ptr(Texture2D) ui_vehicle_info_blue;
		sharedc_ptr(Texture2D) ui_vehicle_info_shanguang_red;
		sharedc_ptr(Texture2D) ui_vehicle_info_shanguang_blue;
		sharedc_ptr(Texture2D) ui_vehicle_info_car_red;
		sharedc_ptr(Texture2D) ui_vehicle_info_car_blue;
		sharedc_ptr(Texture2D) ui_vehicle_length;
		sharedc_ptr(Texture2D) ui_bomb_length;
		sharedc_ptr(Texture2D) ui_vehicle_people;

		//king
		sharedc_ptr(Texture2D) ui_king_king_r;
		sharedc_ptr(Texture2D) ui_king_king_b;

		//Weapon Tip
		sharedc_ptr(Texture2D) WeaponKind[6];
		sharedc_ptr(Texture2D) WeaponBlank;
		sharedc_ptr(Texture2D) WeaponRed;
		sharedc_ptr(Texture2D) WeaponBlue;


		//curegun tip
		sharedc_ptr(Texture2D) addblood_tip[2];
		sharedc_ptr(Texture2D) ui_cure_icon[2];
		sharedc_ptr(Texture2D) all_tipBg[2];
		sharedc_ptr(Texture2D) weapon_tipBg;


		//Sniper Target Helper
		sharedc_ptr(Texture2D) ui_snipertarget[3];
		
		//horn
		sharedc_ptr(Texture2D) ui_horn;
		sharedc_ptr(Texture2D) ui_horn_bg;

		//draw hit ui
		sharedc_ptr(Texture2D) ui_hit_portrait;

		//draw start game time
		sharedc_ptr(Texture2D) process_bar;

		//draw kill icon
		sharedc_ptr(Texture2D) kill_died;
		sharedc_ptr(Texture2D) kill_headshot;
		sharedc_ptr(Texture2D) blast_icon;
		sharedc_ptr(Texture2D) fire_icon;
		sharedc_ptr(Texture2D) bomb_kill;
		sharedc_ptr(Texture2D) king_kill;

		//draw win icon
		sharedc_ptr(Texture2D) win_red_icon;
		sharedc_ptr(Texture2D) win_blue_icon;
		sharedc_ptr(Texture2D) win_boss_icon;
		sharedc_ptr(Texture2D) win_human_icon;
		sharedc_ptr(Texture2D) win_zombie_icon;

		sharedc_ptr(Texture2D) speaker_texture;
		sharedc_ptr(Texture2D) speaker_texture_background;

		sharedc_ptr(Texture2D) ui_textures[14];

		//cool down
		sharedc_ptr(Texture2D) ui_control_tip;
		sharedc_ptr(Texture2D) ui_cooldown_circle;
		sharedc_ptr(Texture2D) ui_cooldown_circle_bg;
		sharedc_ptr(Texture2D) ui_quick_move;

		//for kick person
		sharedc_ptr(Texture2D) ui_textures_kick_bg;
		sharedc_ptr(Texture2D) ui_textures_kick_title;

		//for novice
		sharedc_ptr(Texture2D) ui_novice_person_bg[6];
		sharedc_ptr(Texture2D) ui_novice_tip_bg;
		sharedc_ptr(Texture2D) ui_novice_mouse;
		sharedc_ptr(Texture2D) ui_novice_mouse_R;
		sharedc_ptr(Texture2D) ui_novice_leftright;
		sharedc_ptr(Texture2D) ui_novice_leftright_light;
		sharedc_ptr(Texture2D) ui_novice_gks_bg;
		sharedc_ptr(Texture2D) ui_novice_gks_down;
		sharedc_ptr(Texture2D) ui_novice_keyboard_bg;
		sharedc_ptr(Texture2D) ui_novice_keyboard;
		sharedc_ptr(Texture2D) ui_novice_keyboard_guang;
		sharedc_ptr(Texture2D) ui_novice_number;
		sharedc_ptr(Texture2D) ui_novice_space;
		sharedc_ptr(Texture2D) ui_novice_space_guang;
		sharedc_ptr(Texture2D) ui_novice_wheel;
		sharedc_ptr(Texture2D) ui_novice_wheel_light;
		sharedc_ptr(Texture2D) ui_novice_jiantou_3;
		sharedc_ptr(Texture2D) ui_novice_jiantou_3light;
		sharedc_ptr(Texture2D) ui_novice_biaoji_bg;
		sharedc_ptr(Texture2D) ui_novice_biaoji_point;
		sharedc_ptr(Texture2D) ui_novice_guang;
		sharedc_ptr(Texture2D) ui_novice_pass;

		//other
		sharedc_ptr(Texture2D) ui_window;
		sharedc_ptr(Texture2D) ui_b;
		sharedc_ptr(Texture2D) ui_f;
		sharedc_ptr(Texture2D) ui_e;
		sharedc_ptr(Texture2D) ui_camera;
		sharedc_ptr(Texture2D) ui_f9;
		sharedc_ptr(Texture2D) ui_sensitivity_box;
		sharedc_ptr(Texture2D) ui_sensitivity_box2;
		sharedc_ptr(Texture2D) ui_sensitivity_scrollbar_bg;
		sharedc_ptr(Texture2D) ui_sensitivity_scrollbar_slider;
		sharedc_ptr(Texture2D) ui_power_num;
		sharedc_ptr(Texture2D) ui_AmmoStick;

		//boss
		sharedc_ptr(Texture2D) ui_boss_num;
		sharedc_ptr(Texture2D) ui_win;
		sharedc_ptr(Texture2D) ui_Fail;
		sharedc_ptr(Texture2D) ui_power_wenhao;

		//bomb
		sharedc_ptr(Texture2D) ui_bomb_ico;
		sharedc_ptr(Texture2D) ui_bomb_ico_flash;
		sharedc_ptr(Texture2D) ui_bomb_defuse_course;
		sharedc_ptr(Texture2D) ui_bomb_defuse_course_In;
		sharedc_ptr(Texture2D) ui_bomb_defuse_course_Point;
		sharedc_ptr(Texture2D) ui_bomb_Text_Planting;
		sharedc_ptr(Texture2D) ui_bomb_Text_Defusing;

		//zombie
		sharedc_ptr(Texture2D) ui_zombie_poeple_hp_bar;
		sharedc_ptr(Texture2D) ui_zombie_poeple_bar_icon;
		sharedc_ptr(Texture2D) ui_zombie_number_comma;
		sharedc_ptr(Texture2D) ui_zombie_time_number;
		//sharedc_ptr(Texture2D) ui_zombie_text;

		//commonzombie
		sharedc_ptr(Texture2D) ui_commonzombie_Corpse_Mum[3];
		sharedc_ptr(Texture2D) ui_commonzombie_Corpse_Mum_Disable[3];
		sharedc_ptr(Texture2D) ui_commonzombie_Corpse_Child[3];
		sharedc_ptr(Texture2D) ui_commonzombie_Corpse_Child_Disable[3];
		sharedc_ptr(Texture2D) ui_commonzombie_Shine[2];
		sharedc_ptr(Texture2D) ui_commonzombie_bottom_bg;
		sharedc_ptr(Texture2D) ui_commonzombie_bottom_bf[2];
		sharedc_ptr(Texture2D) ui_commonzombie_bottom_warning;
		sharedc_ptr(Texture2D) ui_commonzombie_head_bg;
		sharedc_ptr(Texture2D) ui_commonzombie_bottom_Corpse;
		sharedc_ptr(Texture2D) ui_commonzombie_bottom_People;
		sharedc_ptr(Texture2D) ui_commonzombie_bottom_Corpse_ico;
		sharedc_ptr(Texture2D) ui_commonzombie_bottom_People_ico;
		sharedc_ptr(Texture2D) ui_commonzombie_Skill_bg;
		sharedc_ptr(Texture2D) ui_commonzombie_Skill_bf;
		sharedc_ptr(Texture2D) ui_commonzombie_Skill_Shine;
		sharedc_ptr(Texture2D) ui_commonzombie_Skill_ico[11];
		sharedc_ptr(Texture2D) ui_commonzombie_People_bottom_bg;
		sharedc_ptr(Texture2D) ui_commonzombie_People_bottom_energy_f;
		sharedc_ptr(Texture2D) ui_commonzombie_People_bottom_energy_shine;
		sharedc_ptr(Texture2D) ui_commonzombie_Key_G;
		sharedc_ptr(Texture2D) ui_commonzombie_Key_E;
		sharedc_ptr(Texture2D) ui_commonzombie_People_hp_bg;
		sharedc_ptr(Texture2D) ui_commonzombie_People_hp_bf;
		sharedc_ptr(Texture2D) ui_commonzombie_dying_bg;
		sharedc_ptr(Texture2D) ui_commonzombie_Level_up;

		//boss two
		sharedc_ptr(Texture2D) ui_Boss2_die;
		sharedc_ptr(Texture2D) ui_Boss2_Back;
		sharedc_ptr(Texture2D) ui_Boss2_DieBack;
		sharedc_ptr(Texture2D) ui_head_info_bg_Boss2;
		sharedc_ptr(Texture2D) ui_head_info_bg_Bos_hp;
		sharedc_ptr(Texture2D) ui_head_info_bg_Bos_hp_bg;
		sharedc_ptr(Texture2D) ui_head_info_bg_Bos_time_bg;
		sharedc_ptr(Texture2D) ui_head_info_bg_Bos_whop;
		sharedc_ptr(Texture2D) ui_head_info_bg_Bos_Now;
		sharedc_ptr(Texture2D) ui_head_info_bg_Bos_Now_First;
		sharedc_ptr(Texture2D) ui_head_info_bg_Bos_Lock;

		//boss mode2
		sharedc_ptr(Texture2D) ui_Boss_mode2_box_life;
		sharedc_ptr(Texture2D) ui_Boss_mode2_box_die;
		sharedc_ptr(Texture2D) ui_Boss_mode2_Boss;
		sharedc_ptr(Texture2D) ui_Boss_mode2_HP_up_bg;
		sharedc_ptr(Texture2D) ui_Boss_mode2_HP_bg;
		sharedc_ptr(Texture2D) ui_Boss_mode2_HP_bf;
		sharedc_ptr(Texture2D) ui_Boss_mode2_HP_bf_r;
		sharedc_ptr(Texture2D) ui_Boss_mode2_HP_small_bg;
		sharedc_ptr(Texture2D) ui_Boss_mode2_HP_small_bf;
		sharedc_ptr(Texture2D) ui_Boss_mode2_HP_small_bf_r;
		sharedc_ptr(Texture2D) ui_Boss_mode2_boss_weapon_bg;
		sharedc_ptr(Texture2D) ui_Boss_mode2_boss_weapon_bg_down;
		sharedc_ptr(Texture2D) ui_Boss_mode2_boss_weapon_disable_bg;
		sharedc_ptr(Texture2D) ui_Boss_mode2_boss_weapon1;
		sharedc_ptr(Texture2D) ui_Boss_mode2_boss_weapon2;
		sharedc_ptr(Texture2D) ui_Boss_mode2_boss_defense_bg;
		sharedc_ptr(Texture2D) ui_Boss_mode2_boss_defense;
		sharedc_ptr(Texture2D) ui_Boss_mode2_boss_ammo_icon;
		sharedc_ptr(Texture2D) ui_Boss_mode2_boss_fuel_bg;
		sharedc_ptr(Texture2D) ui_Boss_mode2_boss_fuel;
		sharedc_ptr(Texture2D) ui_Boss_mode2_person_energy_Lv;
		sharedc_ptr(Texture2D) ui_Boss_mode2_person_energy_bg;
		sharedc_ptr(Texture2D) ui_Boss_mode2_person_energy_shine;
		sharedc_ptr(Texture2D) ui_Boss_mode2_person_energy;
		sharedc_ptr(Texture2D) ui_Boss_mode2_person_passiveskill[4];
		sharedc_ptr(Texture2D) ui_Boss_mode2_HP_num;
		sharedc_ptr(Texture2D) ui_Boss_mode2_HP_text;
		sharedc_ptr(Texture2D) ui_Boss_mode2_boss_Gun_text;
		sharedc_ptr(Texture2D) ui_Boss_mode2_boss_Gun_text_shine;
		sharedc_ptr(Texture2D) ui_Boss_mode2_person_skill_level_up;
		sharedc_ptr(Texture2D) ui_Boss_mode2_person_initiativ_skill[4];
		sharedc_ptr(Texture2D) ui_Boss_mode2_person_strange_spawn_skill[4];

		sharedc_ptr(Texture2D) ui_Boss_mode2_boss_scale_uv_left;
		sharedc_ptr(Texture2D) ui_Boss_mode2_boss_scale_uv_right;
		sharedc_ptr(Texture2D) ui_Boss_mode2_boss_scale_uv_Center;
		sharedc_ptr(Texture2D) ui_Boss_mode2_boss_scale_uv_Top;

		sharedc_ptr(Texture2D) ui_Boss_mode2_boss_crosshair;
		sharedc_ptr(Texture2D) ui_Boss_mode2_boss_crosshair_r;
		sharedc_ptr(Texture2D) ui_Boss_mode2_airplane_crosshair;
		sharedc_ptr(Texture2D) ui_Boss_mode2_airplane_crosshair_r;
		sharedc_ptr(Texture2D) ui_Boss_mode2_cannon_crosshair;
		sharedc_ptr(Texture2D) ui_Boss_mode2_cannon_crosshair_r;
		sharedc_ptr(Texture2D) ui_Boss_mode2_yun;
		sharedc_ptr(Texture2D) ui_Boss_mode2_yun_r;

		//itemmode
		sharedc_ptr(Texture2D) ui_itemmode_People_bottom_bg;
		sharedc_ptr(Texture2D) ui_itemmode_People_bottom_energy_f;
		sharedc_ptr(Texture2D) ui_itemmode_Skill_bg;
		sharedc_ptr(Texture2D) ui_itemmode_Skill_ico[26];
		//sharedc_ptr(Texture2D) ui_itemmode_Skill_head[15];

		// ingame item tdmode
		sharedc_ptr(Texture2D) ui_ingame_item_icon[ITEM_ICON_NUM];
		sharedc_ptr(Texture2D) ui_ingame_item_bg[ITEM_ICON_NUM];
		sharedc_ptr(Texture2D) ui_ingame_item_mask[8];
		sharedc_ptr(Texture2D) ui_ingame_time_bg;
		sharedc_ptr(Texture2D) ui_ingame_score_bg[3];

		// ... editmode
		sharedc_ptr(Texture2D) ui_ingame_help;
		sharedc_ptr(Texture2D) ui_ingame_info;

		sharedc_ptr(Texture2D) ui_ingam_cancel_tower_gun;

		//moonmode
		sharedc_ptr(Texture2D) ui_moon_score[5];
		

		//����
		sharedc_ptr(Texture2D) ui_survival[5];
        sharedc_ptr(Texture2D) ui_survival1;
		sharedc_ptr(Texture2D) ui_survival2;
		sharedc_ptr(Texture2D) ui_survival4;
		sharedc_ptr(Texture2D) ui_survival5;
		sharedc_ptr(Texture2D) ui_Keying[5];
		sharedc_ptr(Texture2D) ui_survival6;
		sharedc_ptr(Texture2D) ui_survival7;
		sharedc_ptr(Texture2D) ui_survival8;
		sharedc_ptr(Texture2D) ui_survival3;
		sharedc_ptr(Texture2D) ui_survival9;
		sharedc_ptr(Texture2D) ui_survival10;
		sharedc_ptr(Texture2D) ui_survival11;
		sharedc_ptr(Texture2D) ui_survival12;
		sharedc_ptr(Texture2D) ui_survival13;
		//Die Buff
		Core::Array<sharedc_ptr(Texture2D)> DieBuff;
		Core::Array<DieBuffDescString> DieBuffDesc;
		
	private:
		float current_screen_height_level;
		float current_screen_width_level;

		float bomb_plantedtimer_part;

	public:
		bool	show_game_scores;
		bool	show_scores;
		bool	show_map;
		F64		show_tips_bomb_time;

		int		win_team;

		Core::CStrBuf<256>  warn_msg;
		Core::String  current_speaker_info;

		bool	warn_msg_flag:1;
		float   warn_msg_time;
		bool    speaker_msg_flag : 1;
		float   speaker_msg_time;

		Core::Array<DigitalSprite> tip_effect_list;
		float	input_timer;

		float	zd_time;
		float	zd_red_showtime;
		float	zd_blue_showtime;

	private:
		sharedc_ptr(Texture2D) team_request_bg_texture,team_request_bar_Texture,team_request_dialog_texture;

		Core::Array<Core::String> normal_command_radio;
		Core::Array<Core::String> team_command_radio;
		Core::Array<Core::String> reply_command_radio;
		Core::Array<Core::String> dummy_radio;
		
		float Special_time;
		
		AnimSprite kill_anim_icon;
		AnimSprite kill_anim_icon_num[2];
		AnimSprite speaker_anim[5];
		AnimSprite score_anim;
		AnimSprite novice_anim;
		AnimSprite win_anim;
		sharedc_ptr(Client::AnimPicture) anim_pictureOut;
		sharedc_ptr(Client::AnimPicture) anim_pictureIn;
		sharedc_ptr(Client::AnimPicture) anim_picture_Mvp_In;
		sharedc_ptr(Client::AnimPicture) anim_picture_Mvp_Out;
		sharedc_ptr(Client::AnimPicture) anim_picture_Card_Out;
		sharedc_ptr(Client::AnimPicture) anim_picture_bigCard_Out;
		sharedc_ptr(Client::AnimPicture) anim_picture_bigCard_Out_next;
		sharedc_ptr(Texture2D)			 anim_picture_Mvp;
		bool								is_Mvp;

		Core::ARGB text_input_color;
		int char_mode;
		int char_mode_Tab;

		sharedc_ptr(Gui::Textbox)	inGameUI_textInput;
		Core::Array<Core::String>	fiveMsgs;
		Core::Array<Core::ARGB>     Msgs_Color;
		Core::Array<int>            speaker_current_list;
		Core::Array<int>			speaker_list;
		Core::String				currentLine;
		float						fFadeTime;
		float						fFadeCoolDown;

		float						show_snipertarget_time;		

		Core::Array<AddBloodEffectInfo>	array_addbloodeffect_info;

		float						zd_speed;
		float						zd_fPersert_red;
		float						ui_rotate;
		float						zd_novice_time;
		float						win_time;
		float						b_time;
		
		int							input_index;
		Core::Array<Core::String>	info_tip;
		float						info_time;
		float						cooldown_time;	
		bool						is_novice_holdpoint_ok;
		int							ui_score_line;
		bool						Card_Play;

		F64							m_bomb_ico_time;

		bool laoda1Fiveflag;
		bool laoda1Twoflag;
		bool laoda2Fiveflag;
		bool laoda2Twoflag;
		bool laoda1win;
		bool laoda2win;

		Core::String				m_chatname;
		Core::String				m_chattoname;

		float							m_Commonzombie_energy_time;
	public:
		bool		bFoused;
		bool		isshowblood;
		F32		showhornscale;
		
		// for video----------------
		ButtonInfo	button[8];
		Core::Array<byte> button_content;
		sharedc_ptr(Texture2D) record_icon[24];
		// -------------------------
		void CreateVideoButton();

		void _DrawPlayRecordUI(by_ptr(UIRender) render);

		float	player_die_time;
		int		fu_huo_bi_use_count;

		tempc_ptr(Character)	m_current_pveboss;

		Core::Array<SkillItem>	commonzombie_skill;
		Core::String				m_Middleup_str;
		Core::String				m_Middle_str;
		Core::String				m_Middle_str1;
		float						m_Showmiddle_str_time;
		float						m_Showmiddleup_str_time;
		Core::String				m_Bottom_str[2];
		float						m_ShowBottom_str_time[2];
		float						m_commonzombie_level_isup_time[2];
		float						m_boss_mode2_shine_time;
		float						m_boss_mode2_shine_time_space;
		float						m_boss_mode2_human_skill_level_up_time[4];
		float						m_boss_mode2_human_skill_level_up_time_two[4];
		float						m_boss_mode2_boss_twoweapon_tips_time;
		int						m_boss_mode2_hit_total;
		float						m_MiniMachine_gun_show_time;

		bool						m_isCarriering;
		int						m_cur_reshp;
		int						m_max_reshp;
		float						m_CarrierTime;
		float						m_rightScaleTime;
		float						m_leftScaleTime;
		float						m_KeyGScaleTime;
		float						m_KeyHScaleTime;
		float						m_SelectLeftTime;
		float						m_SelectRightTime;
		float						m_ResTime;
		Core::LinkList<Core::LinkNode<InGameItemInfo*>>	m_loopList;
		InGameItemInfo* m_DisplayItem[ITEM_ICON_NUM];
		Core::List<SFlashInfo>	m_flash;

		sharedc_ptr(PlayerSkill) m_skill;
	};
}