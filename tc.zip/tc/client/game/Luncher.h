namespace Client
{
	struct LuncherInfo : public GunInfo
	{
		int ammo_type;
		float fly_speed;
		float spread;
		float normal_up_base;
		float normal_up_modifier;
		float normal_up_max;
		float maxalive_time;
		byte gravity;
		float hurt;
		char ammopart_key[32];
		float range;
		float throwouttime;

		float dmg_modify_timer_min;
		float dmg_modify_timer_max;
		float dmg_modify_min;
		float dmg_modify_max;

		float capsule_height;
		float capsule_radius;
		bool  reloadoneammo;

		// ammo hide -----------------------
		float ammo_hide_time;
		// ---------------------------------

		// charge shoot --------------------
		float ammo_charge_time_max;
		float ammo_charge_time_effective;
		float ammo_charge_time_stable;

		float ammo_spread_multiple;
		float ammo_power_multiple;
		float ammo_gravity_addon;
		// ---------------------------------

		float ammo_blood_disk_interval;
		int	  ammo_blood_disk_hit_count;

		int   maxstickcount;

		//ammo control mode
		AmmoControlMode ammocontrolmode;

		LuncherInfo()
		{
			weapon_type = kWeaponTypeLuncher;
			ammo_type = 0;
			reloadoneammo = false;
			ammo_hide_time = -1.f;

			ammo_charge_time_max =  -1.f;
			ammo_charge_time_effective = -1.f;
			ammo_charge_time_stable = -1.f;

			ammo_power_multiple = -1.f;
			ammo_spread_multiple = -1.f;
			ammo_gravity_addon = -1.f;
			ammo_blood_disk_hit_count = 10;
			ammo_blood_disk_interval = 1.f;
			maxstickcount = 6;
		}
	};

	class Luncher : public GunBase , public ChangeNodeEventBase
	{
	public:
		/// constrcutor
		Luncher(by_ptr(LuncherInfo) info);

		~Luncher();
	public:
		/// initialize
		virtual void Initialize();
		
		/// active
		virtual void Active();

		/// inactive
		virtual void Inactive();

		///update
		virtual void Update(float time);

		///reload
		virtual bool Reload();

		/// get weapon type
		virtual uint GetWeaponType();

		//. speaical skill
		virtual void SpecialAbilities(bool keydown = false);

		virtual bool ChargeAbilities();

		virtual void UpdateCharge(float delta);

	public:
		/// fire
		virtual bool Fire();

		virtual void TryFire();
		
		/// animation event
		virtual void OnAnimationStartFPEvent(const Core::Identifier & groupname, int & index);
		virtual void OnAnimationStartTPEvent(const Core::Identifier & groupname, int & index);
		virtual void OnAnimationEndFPEvent(const Core::Identifier & groupname, int & index);
		virtual void OnAnimationEndTPEvent(const Core::Identifier & groupname, int & index);

	public:
		WeaponType GetLuncherAmmoType();
		bool isReloadOneAmmo();
	private:
		bool FireLuncherBase(float spread, float hurt_rate, float gravity_addon);

		void UpdateMode1(float time);

		void UpdateMode2(float time);
	public:
		sharedc_ptr(LuncherInfo) luncher_info;
		sharedc_ptr(Client::ParticleSystem) idleparticle;
	private:
		Core::Quaternion camerarot;
		bool Can_Fire;

		// charge shoot -------------
		float ammo_hide_timer;
		float charge_timer;
		bool charging_state;
		//  -------------------------

	private:
		sharedc_ptr(AmmoBase) preload_ammo;
		sharedc_ptr(AmmoInfo) preload_ammoinfo;
	};
}