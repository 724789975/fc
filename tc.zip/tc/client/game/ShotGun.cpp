#include "pch.h"

using namespace Core;
using namespace Client;

DEFINE_PDE_TYPE_CLASS(Client::ShotGunInfo)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Client::GunInfo);

		//ADD_PDE_FIELD(shoot_bullet_count);
		//ADD_PDE_FIELD(spread);
		//ADD_PDE_FIELD(normal_up_base);
		//ADD_PDE_FIELD(normal_up_modifier);
		//ADD_PDE_FIELD(normal_up_max);

		ADD_PDE_DEFAULT_CONSTRUCTOR();
	}
};

DEFINE_PDE_TYPE_CLASS(Client::ShotGun)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Client::GunBase);

		ADD_PDE_PROPERTY_R(weapon_info);
	}
};

REGISTER_PDE_TYPE(Client::ShotGunInfo);
REGISTER_PDE_TYPE(Client::ShotGun);
namespace Client
{
	/// constrcutor
	ShotGun::ShotGun(by_ptr(ShotGunInfo) info)
	{
		weapon_info = gun_info = ShotGun_info = info;
	}


	/// initialize
	void ShotGun::Initialize()
	{
		GunBase::Initialize();
		accuracy = 0.92f;

		tempc_ptr(Character) player = GetOwner();
	}
	/// inactive
	/// active

	/// get weapon type
	uint ShotGun::GetWeaponType()
	{
		return kWeaponTypeShotGun;
	}

	///active
	void ShotGun::Active()
	{
		tempc_ptr(Character) player = GetOwner();
		if (!player)
			return;

		GunBase::Active();
	}

	/// fire
	bool ShotGun::Fire()
	{		
		tempc_ptr(Character) player = GetOwner();
		if (!player)
			return false;

		if (!CanFire(false))
			return false;

		float spread = ShotGun_info->spread;

		if (ShotGun_info->shoot_bullet_count > 1 && ammo_in_clip >= 0)
		{
			Vector3 fire_angle = player->GetLookDir().GetZXY();
			fire_angle += player->punch_angle;
			Quaternion rot;
			rot.SetZXY(fire_angle);

			for(int i = 0; i < ShotGun_info->shoot_bullet_count - 1; i++)
				FireCheck(player->GetCameraPosition(), rot, spread, false);
		}

		FireBase(0);
		
		//KickBack
		KickBack(ShotGun_info->normal_up_base, 0, ShotGun_info->normal_up_modifier, 0, ShotGun_info->normal_up_max, 0, 0);
		return true;
	}

	///reload
	bool ShotGun::Reload()
	{
		if (CanReload())
		{
			reloading = true;
			ReloadAction();
			reload_time = gun_info->reload_time;
			return true;
		}
		return false;
	}

	//update
	void ShotGun::Update(float time)
	{
		WeaponBase::Update(time);
		tempc_ptr(Character) player = GetOwner();
		if (!player)
			return;
		if (!gun_info)
			return;

		if (ammo_in_clip == 0 && ammo_count > 0)
		{
			player->Reload();//this will call weapon->reload()
		}

		next_fire_time -= time;
		if (player->first_action_on)
		{
			if(ammo_in_clip != 0)
			{
				reloading = false;
				player->reloading = false;
			}

			if (idle_time <= 0 && next_fire_time <= 0 && (gun_info->auto_fire || delay_fire == false))
			{
				if (player->CanFire() && Fire())
				{
					next_fire_time = gun_info->fire_time;
					idle_time =  weapon_info->time_to_idle;
				}
				else
					player->StopShoot();
			}
		}
		else
		{
			player->StopShoot();
			if (delay_fire)
			{
				delay_fire = false;
				if (shots_fired > 15)
				{
					shots_fired = 15;
				}
				decrease_shots_fired += 0.4f;
			}


			if (!gun_info->auto_fire)
				shots_fired = 0;

			if (shots_fired > 0)
			{
				decrease_shots_fired -= time;
				if (decrease_shots_fired < 0)
				{
					decrease_shots_fired = 0.0225f;
					shots_fired--;
				}
			}
		}

		UpdateEffect(time);
	}

	void Client::ShotGun::OnAnimationStartFPEvent(const Core::Identifier & groupname, int & index)
	{
		tempc_ptr(Character) player = GetOwner();
		if (!player)
			return;
		FirstPerson & first_person = player->GetFirstPerson();

		Core::String str = groupname;
		if (str == "shotgun_reload" && ammo_count > 0)
		{
			switch (index)
			{
			case 1:
				{
					if (animation)
					{
						CStrBuf<256> key;
						if(player->GetViewMode() == Character::kFirstPerson)
						{
							key.format("bj/weapon/2d/%s/reload", weapon_info->sound_name.Str());
							audio_reload = FmodSystem::PlayEvent(key);
						}
						animation->PlayAction("reload", 0.02f, false, gun_info? gun_info->reload_time:0);
					}
				}
				break;
			default:
				break;
			}
		}
	}

	void Client::ShotGun::OnAnimationStartTPEvent(const Core::Identifier & groupname, int & index)
	{
	}

	void Client::ShotGun::OnAnimationEndFPEvent(const Core::Identifier & groupname, int & index)
	{
		tempc_ptr(Character) player = GetOwner();
		if (!player)
			return;
		FirstPerson & first_person = player->GetFirstPerson();

		int ammo_need = gun_info->ammo_one_clip - ammo_in_clip;

		Core::String str = groupname;
		if (str == "shotgun_reload" && ammo_count > 0)
		{
			switch (index)
			{
			case 0:
				{
					if (first_person.show_count != -1 && first_person.show_count == 1)
					{
						first_person.show_count -= 1;
					}
				}
				break;
			case 1:
				{
					if (first_person.show_count != -1 && first_person.show_count > 1)
					{
						first_person.show_count -= 1;
						index--;
					}
					else
					{
						if (reloading)
						{
							empty = false;
							ammo_in_clip++;
							ammo_need--;
							ammo_count--;
							player->ReloadReady(1);
							shots_fired = 0;
							decrease_shots_fired = 0;
							delay_fire = false;

							if(ammo_need <= 0 || ammo_count <= 0)
							{
								reloading = false;
								player->reloading = false;
							}
							else 
							{
								index--;
							}
						}
					}
				}
				break;
			default:
				break;
			}
		}
	}

	void Client::ShotGun::OnAnimationEndTPEvent(const Core::Identifier & groupname, int & index)
	{
		tempc_ptr(Character) player = GetOwner();
		if (!player)
			return;
		ThirdPerson & third_person = player->GetThirdPerson();

		Core::String str = groupname;
		if (str == "shotgun_reload" && ammo_count > 0)
		{
			switch (index)
			{
			case 0:
				{
					if (third_person.show_count != -1 && third_person.show_count == 1)
					{
						third_person.show_count -= 1;
					}
				}
				break;
			case 1:
				{
					if (third_person.show_count != -1 && third_person.show_count > 1)
					{
						third_person.show_count -= 1;
						index--;
					}
					else
					{
						if (third_person.reload_multianimation)
						{
							third_person.ammo_need_multianimation--;
							if(third_person.ammo_need_multianimation > 0)
								index -= 1;
						}
					}
					if (animation)
					{
						if(player->GetViewMode() == Character::kThirdPerson)
						{
							CStrBuf<256> key;
							FMOD_VECTOR vel = {0, 0, 0};
							key.format("bj/weapon/3d/%s/reload", weapon_info->sound_name.Str());
							audio_reload = FmodSystem::Play3DEvent(key,(const FMOD_VECTOR &)player->GetPosition(),vel);
						}
						animation->PlayAction("reload", 0.02f, false, gun_info? gun_info->reload_time:0);
					}
				}
				break;
			case 2:
				{
					third_person.ammo_need_multianimation = 0;
					third_person.reload_multianimation = false;
					third_person.node_data_upper->StopAction();
				}
				break;
			default:
				break;
			}
		}
	}
}