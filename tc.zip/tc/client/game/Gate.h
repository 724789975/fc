namespace Client
{
	enum GateState
	{
		CLOSED = 0,
		RAISE,
		OPENED,
		FALL,
	};

	enum GateType 
	{
		SINGLE_GATE = 0,
		DOUBLE_GATE ,
		GATE_TYPE_COUNT,
	};
 
	struct GateInfo :Core::Object
	{
		GateInfo()
		{
			gate_type = 0;
			id = 0;
			active_state_default = true;
		}

		byte			 gate_type;
		int				 id;

		Core::Vector3	 position;
		Core::Quaternion rotation;

		Core::Vector3	 target_position;
		Core::Vector3	 check_dim;
		Core::Vector3    gate_collision_box_dim;
		
		int				 team;
		Core::String	 gate_mesh_name;
		bool			 active_state_default;
	};


	class GateBase : public Core::Object
	{
	public:
		/// constructor
		GateBase(by_ptr(GateInfo) info);
		/// destructor
		virtual ~GateBase();

	public:
		/// draw
		virtual void Draw(Primitive::DrawType drawtype, bool immediate = false);

		/// initialize
		virtual void Initialize();

		void ReleasePhysX();

		void SetPosition(Core::Vector3& pos);

		/// update
		void Update(float frame_time);

		void AddOpenRef();

		int GetID();

		void AddCloseRef();

		int GetStatus();

		Core::Vector3 GetCurPosition();

		void ResetGate();

		void CreateTrigger();

		void SetActiveTime(float time);

		static tempc_ptr(GateBase) FromNxActor(NxActor & actor);

		bool IsActive();

		void ResetActiveState();

	protected:
		virtual void CreateMesh();

		/// create physX
		virtual void CreatePhysx();

		virtual void UpdatePosition(float frame_time);

		void UpdatePhysX();

		void SetAllMeshCurrentPos(const Core::Vector3& v);

	public:
		sharedc_ptr(GateInfo) gate_info;

	protected:
		Core::Vector3 base_Position[2];

		Core::Vector3 target_Position[2];

		Core::Vector3 current_Position[2];

		float action_timer;

		Core::Array<NxActor*> actor_arry;

		Core::Array<sharedc_ptr(StaticMesh)> mesh_arry;

		int		status;

		NxActor*	collider;	

		Core::AxisAlignedBox gate_aabb;

		float gate_update_timer;

		bool can_move;

		float activetime;

		bool is_active;
	};
}



