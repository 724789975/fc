namespace Client
{
	class SpiritBall
	{
	public:
		/// constructor
		SpiritBall();

		/// destructor
		virtual ~SpiritBall();

	public:
		/// initialize
		virtual void Initialize(byte uid, int score_hit, const Core::Vector3 &pos, int ball_type);

		/// update
		virtual void Update(float time);

		/// draw
		virtual void Draw(Primitive::DrawType drawtype, bool immediate = false);

	public:
		/// get mesh
		tempc_ptr(StaticMesh) GetMesh();

		/// set mesh
		void SetMesh(by_ptr(StaticMesh) m);

		/// set mesh lod
		void SetMeshLod(int lod_level);

		/// set visible
		virtual void SetVisible(bool flag);

		/// get visible
		virtual bool GetVisible();

		/// get position
		virtual const Core::Vector3 & GetPosition();

		/// set position
		virtual void SetPosition(const Core::Vector3 & pos);

		/// get velocity
		virtual const Core::Vector3 & GetVelocity();

		/// set velocity
		virtual void SetVelocity(const Core::Vector3 & vel);

		/// get rotation
		Core::Quaternion GetRotation();

		/// get dead
		bool GetDead();

	private:
		sharedc_ptr(StaticMesh)		mesh;
		sharedc_ptr(ParticleSystem)	fly_particle;

		Core::Vector3				position;
		Core::Vector3				velocity;

		byte						character_uid;
		int							character_score;

		float						freefly_timer;

		bool						is_dead;
	};
}