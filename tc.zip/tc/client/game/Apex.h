#ifndef _APEX_H__
#define _APEX_H__


namespace Apex
{

#if ACTIVE_APEX

	class ApexBuffer : public Core::Object
	{
	public:
		int size;
		char* pBuf;

		ApexBuffer(int nlen, const char* p);

		~ApexBuffer();

	private:
		ApexBuffer()
		{
			size = 0;
			pBuf = NULL;
		}
	};

	int	NoticeApec_UserData(const char * pBuf,int nBufLen);

	int	StartApexClient();

	int	StopApexClient();



	// for client
	int UpdateApex_UserData();

	static Core::CriticalSection		g_Apex_lock;

	static Core::Array<sharedc_ptr(ApexBuffer)>		g_ApexBuffer_Array;
#endif
}


#endif