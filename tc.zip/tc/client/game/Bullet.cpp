#include "pch.h"

using namespace Core;
using namespace Client;

void BulletManager::Initialize()
{
	for (uint i = 0; i < bullets.Size(); i ++)
	{
		bullets[i].distance = 0;
	}

	bullet_mesh = ptr_new StaticMesh(RESOURCE_NAME(MESH_KEY_PROP, "bullet"));
	redboost_bullet_mesh = ptr_new StaticMesh(RESOURCE_NAME(MESH_KEY_PROP, "bullet"));
	blueboost_bullet_mesh = ptr_new StaticMesh(RESOURCE_NAME(MESH_KEY_PROP, "bullet"));
	
	
	bullet_mesh->AddPrimitive("bullet.mesh", 0);
	redboost_bullet_mesh->AddPrimitive("bullet_r.mesh", 0);
	blueboost_bullet_mesh->AddPrimitive("bullet_b.mesh", 0);
	bullet_smoke = ptr_new BulletSmoke();
	bullet_smoke->Initialize();
}

// terminate
void BulletManager::Terminate()
{
	bullet_mesh = NullPtr;
	blueboost_bullet_mesh = NullPtr;
	redboost_bullet_mesh = NullPtr;
	bullet_smoke = NullPtr;
}

BulletManager::~BulletManager()
{
	bullet_mesh = NullPtr;
	blueboost_bullet_mesh = NullPtr;
	redboost_bullet_mesh = NullPtr;
	bullet_smoke = NullPtr;
}

// Adds a bullet.
void BulletManager::Add(const Vector3 & from, const Quaternion & dir, float distance,byte team, bool isboost)
{
	static const float EFFECT_NUMBER_AREA = 1.5f;
	for (uint i = 0; i < bullets.Size(); i ++)
	{
		Bullet & b = bullets[i];
		if (b.distance == 0)
		{
			b.start = from;
			b.direction = dir;
			b.distance = distance;
			b.position = 0;
			b.end = 0;
			b.boost = isboost;
			b.team = team;
			if(isboost)
			{
				if(team)
				{
					b.scale = Core::Vector2(2.2f,2.2f);
				}
				else
				{
					b.scale = Core::Vector2(2.2f,2.2f);
				}
			}
			else
			{
				b.scale = Core::Vector2(2.2f,2.2f);
			}
			break;
		}
	}

	distance += BULLET_SMOKE_OFFSET;
	float d = Fmod(distance, SINGLE_SMOKE_LENGTH);
	
	int count = distance / SINGLE_SMOKE_LENGTH;

	if(d < EFFECT_NUMBER_AREA)
	{
		bullet_smoke->AddBulletSmoke(from, dir, count);
	}
	else if( distance - count * SINGLE_SMOKE_LENGTH < EFFECT_NUMBER_AREA)
	{
		bullet_smoke->AddBulletSmoke(from, dir, count + 1);
	}	
}

// Update system.
void BulletManager::Update(float frametime)
{
	for (uint i = 0; i < bullets.Size(); i ++)
	{
		Bullet & b = bullets[i];
		if (b.distance != 0)
		{
			if (b.position < b.distance)
			{
				b.end = b.position;
				b.position += frametime * 95.0f;

				if (b.position > b.distance)
					b.position = b.distance;
			}
			else
			{
				b.position = 0;
				b.distance = 0;
			}
		}
	}
	
	if (bullet_mesh)
		bullet_mesh->Update();
	
	if (redboost_bullet_mesh)
		redboost_bullet_mesh->Update();
		
	if (blueboost_bullet_mesh)
		blueboost_bullet_mesh->Update();
	
		
	if(bullet_smoke)
		bullet_smoke->Update(frametime);
}

// render
void BulletManager::Draw(Primitive::DrawType type, bool immediate)
{
	for (uint i = 0; i < bullets.Size(); i ++)
	{
		Bullet & b = bullets[i];
		if (b.distance != 0)
		{
			Vector3 translate = b.start + (Vector3(0, 0, -1) * b.direction) * b.position;

			float z = 2.2f;
			if(b.distance - b.position < z)
				z = b.position - b.end;

			Vector3 scale(b.scale.x,b.scale.y,z/*(b.position - b.end) * 30.f*/);
			
			if(b.boost)
			{
				if(b.team == 0)
				{
					if(redboost_bullet_mesh)
					{
						redboost_bullet_mesh->SetPosition(translate);
						redboost_bullet_mesh->SetRotation(b.direction);
						redboost_bullet_mesh->SetScale(scale);
						redboost_bullet_mesh->Draw(type, immediate);
					}

				}
				else
				{
					if(blueboost_bullet_mesh)
					{
						blueboost_bullet_mesh->SetPosition(translate);
						blueboost_bullet_mesh->SetRotation(b.direction);
						blueboost_bullet_mesh->SetScale(scale);
						blueboost_bullet_mesh->Draw(type, immediate);
					}
	
				}
			}
			else
			{
				if(bullet_mesh)
				{
					bullet_mesh->SetPosition(translate);
					bullet_mesh->SetRotation(b.direction);
					bullet_mesh->SetScale(scale);
					bullet_mesh->Draw(type, immediate);
				}
			}
		
			if (b.position >= b.distance)
				b.distance = 0;
		}
	}

	if(bullet_smoke)
		bullet_smoke->Draw(type,immediate);
}