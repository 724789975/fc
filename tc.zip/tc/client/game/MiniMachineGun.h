namespace Client
{
	struct MiniMachineGunInfo : ShotGunInfo
	{
		float fire_max_speed;
		float fire_start_speed;
		float fire_aceleration;
		float fire_resistance;
		float firereadytime;

		//luncher
		int ammo_type;
		float ammo_charge_time_max;
		float fly_speed[3];
		float fly_speed_multiple[3];
		//ammo
		float maxalive_time;
		byte gravity;
		float hurt;
		char ammopart_key[32];
		float range;
		float dmg_modify_timer_min;
		float dmg_modify_timer_max;
		float dmg_modify_min;
		float dmg_modify_max;
		float capsule_height;
		float capsule_radius;
		AmmoControlMode ammocontrolmode;

		Core::Identifier charge_particle;

		MiniMachineGunInfo()
		{
			weapon_type = kWeaponTypeMiniMachineGun;
			ammo_type = 0;
		}
	};

	class MiniMachineGun : public GunBase, public ChangeNodeEventBase
	{
	public:
		/// constrcutor
		MiniMachineGun(by_ptr(MiniMachineGunInfo) info);
        ~MiniMachineGun();

		DECLARE_PDE_ATTRIBUTE_R(weapon_info, tempc_ptr(MiniMachineGunInfo))
		{
			return MiniMachineGun_info;
		}

	public:
		///update
		virtual void Update(float time);

		//active
		virtual void Active();

		/// inactive
		virtual void Inactive();

		///reload
		virtual bool Reload();

		/// initialize
		virtual void Initialize();

		/// get weapon type
		virtual uint GetWeaponType();

		/// fire
		virtual bool Fire();

		virtual void OnAnimationStartFPEvent(const Core::Identifier & groupname, int & index);
		virtual void OnAnimationStartTPEvent(const Core::Identifier & groupname, int & index);
		virtual void OnAnimationEndFPEvent(const Core::Identifier & groupname, int & index);	
		virtual void OnAnimationEndTPEvent(const Core::Identifier & groupname, int & index);

		virtual void UpdateViewerAnimation(float time);

	private:
		bool FireLuncherBase(float spread, float charge_rate, float gravity_addon, int num);

	public:
		sharedc_ptr(MiniMachineGunInfo)	MiniMachineGun_info;
		float FireReadyTime;
		bool  ispass;
		bool  ispass2;

		FMOD::Event *mini_gun_audio_spin_fire;
		FMOD::Event *mini_gun_audio_spin_fire_3d;
		FMOD::Event *mini_gun_audio_fire;
		
		float ammo_charge_time;
		byte setup_state;//0:none,1:start setup,2:setuping,3:stop setup
		byte charge_state;//0:none,1:charging,2:fire
	private:
		float time_reducespread;
	
	private:
		sharedc_ptr(AmmoBase) preload_ammo;
		sharedc_ptr(AmmoInfo) preload_ammoinfo;

		sharedc_ptr(ParticleSystem) charge_particle;
		FMOD::Event *charge_event;
		FMOD::Event *charge_event_3d;
		FMOD::Event *setup_event;
		FMOD::Event *setup_event_3d;
	};
}