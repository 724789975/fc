namespace Client
{
	struct PointWithSide
	{
		PointWithSide() : outside(false)	{};
		Core::Vector3 point;
		bool outside;
	};
	class Scene;
	class SensorReport : public NxUserTriggerReport
	{
	public:
		void SetScene(Scene* s);
	private:
		virtual void onTrigger(NxShape& triggerShape, NxShape& otherShape, NxTriggerFlag status);
		Scene* scene;
	};

	class SceneObject
	{
	public:
		Mesh* mesh;
	};

	class Portal;

	class Zone : public SceneObject
	{
	public:
		Zone();
		void Draw()	{collected = false;}
		Core::Array<sharedc_ptr(Portal)>	portals;
		NxActor* actor;

		bool collected;
	};

	class Portal : public SceneObject
	{
	public:
		Portal()	{ zones[0] = zones[1] = NullPtr; }

		sharedc_ptr(Zone)	zones[2];
		Core::Plane3d		plane;
	};

	class Scene
	{
	public:
		sharedc_ptr(Zone) CreateZone(Core::String str);
		sharedc_ptr(Portal) CreatePortal(Core::String str);
		Scene(Game* pGame);
		~Scene(){}

		bool FindDraw(by_ptr(Zone) ZoneIn);

		Core::Array<sharedc_ptr(Zone)>	zone_array;
		Core::Array<sharedc_ptr(Portal)>	portal_array;

		Game*			game;
		SensorReport	sensor;

		Core::Array<sharedc_ptr(Zone)>	DrawZone;
	private:
		void CollectZone(by_ptr(Zone) zone, Core::Array<Core::Vector3>& points);
	};
}