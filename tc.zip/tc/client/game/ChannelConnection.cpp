#include "pch.h"
#include <time.h>
#define USE_COMPRESSOR 0
#define USE_ENCODER 1

using namespace Core;
using namespace Client;

enum EServerMessage
{
	SM_NotifyChannelClientEnter,
	SM_NotifyChannelClientLeave,
	SM_NotifyRoomCreate,
	SM_NotifyRoomClose,
	SM_NotifyRoomClientCountChanged,
	SM_NotifyRoomClientEnter,
	SM_NotifyRoomClientLeave,
	SM_NotifyRoomClientUpdate,
	SM_NotifyRoomList,
	SM_NotifyRoomHostChanged,
	SM_NotifyRoomChangeOption,
	SM_NotifyRoomStateChanged,
	SM_NotifyRoomKickClient,
	SM_NotifyClientChangeTeam,
	SM_NotifyClientReady,
	SM_NotifyClientAutoStart,
	SM_NotifyClientAutoStartCancel,
	SM_NotifyGameStart,
	SM_NotifyGameClientEnter,
	SM_NotifyGameClientLeave,
	SM_NotifyGameEnd,
	SM_NotifyGameLeave,

	SM_ResponseChannelEnter,

	SM_ResponseRoomList,
	SM_ResponseRoomCreate,
	SM_ResponseRoomEnter,
	SM_ResponseRoomLeave,
	SM_ResponseRoomClientList,
	SM_ResponseRoomChangeOption,
	SM_ResponseRoomChangeTeam,
	SM_ResponseRoomReady,
	SM_ResponseGameStart,
	SM_ResponseRoomChangeSlotStatus,
	SM_NotifyRoomChangeSlotStatus,
	SM_ResponseRoomChangeSlot,
	SM_NotifyClientChangeSlot,
	SM_ResponseRoomPreserveSlot,
	SM_ResponseClientList,
	SM_ResponseTDData,

	// ģʽ�޹���Ϣ start
	SM_ResponseGameEnter = 100,	// response client enter			(done)
	SM_NotifyChat,				// chat								(done)
	SM_CharacterInfo,			// server tells character info		(done)
	SM_Loading,					// server tell loading				(done)
	SM_ClientJoin,				// send when a client joined game.	(done)
	SM_ClientLeave,				// send when a client leaved game.	(done)
	SM_SyncPlayerData,			// sync player data.				(done)
	SM_PlayerSpawn,				// tells a player had spawned.		(done)
	SM_BotSpawn,				// tells a bot had spawned.			(done)
	SM_PlayerPoke,				// a player is poking.
	SM_PlayerPokeHurt,			// a player poke hurt.
	SM_PlayerShoot,				// a player is shooting.
	SM_PlayerGrenadeThrowIn,	// a player is throwing a grenade.
	SM_PlayerGrenadeThrowStop,	// a player is throwing a grenade.
	SM_PlayerGrenadeThrowOut,	// a player is throwing a grenade.
	SM_PlayerHurt,				// a player hurt himself.
	SM_PlayerGrenadeHurt,		// a player hurt by greande.
	SM_PlayerReload,			// a player is reloading.
	SM_PlayerDropWeapon,		// a player is drop weapon
	SM_PlayerPickUpWeapon,		// a player is pick up weapon
	SM_PlayerSelectWeapon,		// a player is select a weapon
	SM_DestroyDroppedWeapon,	// dropped gun destroy
	SM_SyncTime,				// sync global time.				(done)
	SM_GameLeave,				// game leave						(done)
	SM_PlayerSetTeam,			// player set team
	SM_HealthRecover,			// health recover
	SM_PlayerSpawnTiming,		// player spawn timing				(done)
	SM_PlayerRecoverStop,		// player stop recover
	SM_PlayerKickBack,			// player shoot kickback
	SM_PlayerFlashBright,		// player flash bright
	SM_PlayerCameraFovChanged,	// palyer camera fov changed
	SM_AddDroppedWeapon,		// add dropped weapon				(done)
	SM_AddSupplyObject,			// add supply object				(done)
	SM_DestroySupplyObject,		// supply object destroy
	SM_PickUpSupplyObject,		// pick up supply object
	SM_AmmoRecover,				// ammo recover
	SM_AmmoDisappear,			// ammo disappear
	SM_ArmorRecover,			// armor recover
	SM_UseSkill,				// use skill
	SM_UseCureSkill,			// use cure skill
	SM_ChangePack,				// change pack
	SM_KickClientStart,			// kick client start
	SM_KickClientError,			// kick client error				(done)
	SM_KickClientVote,			// kick client vote					(done)
	SM_KickClientEnd,			// kick client end
	SM_RadioReport,				// radio report
	SM_PlayerReloadReady,		// a player reload ready.
	SM_PlayerActionOn,			// player action on changed
	SM_ProjectedAmmoOut,		// a player is fire a ProjectedAmmo.
	SM_ProjectedAmmoDestroy,	// a player is destroy a ProjectedAmmo.
	SM_ProjectedAmmoUpdate,		// a player is updating a ProjectedAmmo
	SM_ProjectedAmmoHurt,		// a player hurt by ProjectedAmmo.
	SM_ProjectedProdHurt,
	SM_PlayerAnimationStart,	// animation start
	SM_PlayerAnimationEnd,		// animation end
	SM_CallDoctor,				// call doctor
	SM_PlayerHitBack,
	SM_PlayerFlameShoot,		// player flame shoot
	SM_PlayerSustainHurt,		// sustain hurt
	SM_ControlPerson,			// control person
	SM_RevengPerson,
	SM_DrumEffect,				// drum check
	SM_Drink,					// drink
	SM_Cure_Power,
	SM_PlayerSpray,
	SM_PlayerSprayClear,
	SM_ChangeAmmoTeam,
	SM_SyncSkillEffect,
	SM_SpawnCoin,
	SM_AddDropSupply,			// drop supply
	SM_PickUpSupplyObjectNew,	// pick up supply object new
	SM_SynServerScriptValue,	//
	SM_SynScore,				//
	SM_MessageClient,			//
	SM_PVEAmmoOut,				//
	SM_PVEAmmoDestroy,			//
	SM_PVEAmmoHitHurt,			//
	SM_PVEAmmoExplodeHurt,		//
	SM_PVEAmmoUpdate,			//
	SM_CutHurt,					//
	SM_DummyObjectCreate,		//
	SM_DummyObjectDestory,		//
	SM_DummySyncUpdate,			//
	SM_DummyChangeOwner,		//
	SM_GunTowerShoot,
	SM_GunTowerHurt,
	SM_Teleport,
	SM_SkillHurt,				//
	SM_RefreshBagItem,
	SM_DIE_BUFF_DATA,
	// ģʽ�޹���Ϣ end

	// ģʽ�����Ϣ start
	// ģʽͨ��
	SM_Authentication,			// server authentication			(done)
	SM_Initialize,				// server tells initialize info.	(done)
	SM_GameEnd,					// game end							(done)
	SM_RoundStart,				// round start						(done)
	SM_RoundStartPlay,			// round start play					(done)
	SM_RoundEnd,				// round end
	// ռ��ģʽ
	SM_SyncHoldPointInfo,		// sync hold point info
	// �Ƴ�ģʽ
	SM_InitializePushVehiclePointInfo,
	SM_UpdatePushVehiclePointInfo,	// push vehicle info
	// ѵ����
	SM_NoviceOperation,
	// BOSSģʽ
	SM_Boss_Flash,
	SM_Number_Timer,
	SM_BossModeAliveChanged,
	// ����ģʽ
	SM_StartPlantBomb,
	SM_CancelPlantBomb,
	SM_PlantBombSuccess,
	SM_PickUpBomb,
	SM_StartDefuseBomb,
	SM_BombExploded,
	SM_DefuseBombSuccess,
	// ���ģʽ
	SM_StreetKing_Flash,
	//����ģʽ
	SM_Zombie_Flash,
	SM_Zombie_Mode_PlayerDying,
	SM_Zombie_Mode_StartSaveDying,
	SM_Zombie_Mode_CancelSaveDying,
	SM_Zombie_Mode_Human_Respawn,
	SM_Zombie_Mode_Step_Two,
	SM_Zombie_Mode_StartGame,
	SM_ZombieBomer,		// zombie bomer
	SM_ZombieBomerHurt,	// zombie bomer hurt
	SM_ChargeSomething, // ײ��������
	//��ͳ����
	SM_CommonKingZombie_Flash,
	SM_CommonZombie_Flash,
	SM_CommonZombie_LevelChange,
	SM_CommonZombie_EnergyChange,
	SM_CommonZombie_Super,
	SM_CommonHuman_Super,
	SM_CommonZombie_Unable,
	SM_King_Zombie_Respawn,
	SM_HumanEnergyChange,
	SM_HumanPowerUp,
	SM_UseSkillSuperMan,
	SM_SkillSuperManSuccess,
	SM_CommonZombieHumanDie,
	SM_CancelInvisible,
	SM_UseSmog,
	//bosspveģʽ
	SM_SycnBossAction,
	//boss2ģʽ
	SM_Boss2_Flash,
	SM_Boss2_Showtime,
	SM_Boss2_SyncData,
	//����ս
	SM_UseItem_ItemMode,
	SM_ItemMode_ZiBao,
	SM_ItemMode_SyncData,
	//TDģʽ
	SM_TDMode_ResHpChange,
	//MoonMode
	SM_MoonMode_PickWin,
	//SurvivalMode
	SM_UseItem_SurvivalMode,
	SM_UseItem_Trap,
	SM_UseItem_Trap_Trigger,
	SM_Trap_HP_Disappear,
	SM_SurvivalMode_Ghost,
	// ģʽ�����Ϣ end
};

enum EClientMessage
{
	CM_RequestChannelEnter,

	CM_RequestRoomList,
	CM_RequestRoomCreate,
	CM_RequestRoomEnter,
	CM_RequestRoomLeave,
	CM_RequestRoomClientList,
	CM_RequestRoomChangeOption,
	CM_RequestRoomChangeTeam,
	CM_RequestRoomReady,
	CM_RequestRoomKickClient,
	CM_RequestGameStart,
	CM_RequestRoomChangeSlotStatus,
	CM_RequestRoomChangeSlot,
	CM_RequestRoomPreserveSlot,
	CM_RequestRoomTeamEnter,
	CM_RequestClientList,
	CM_RequestNovice,
	CM_RequestTDData,

	CM_ConnectionCheck,

	CM_RequestRoomEnterWithSlotId,

	// ģʽ�޹���Ϣ start
	CM_RequestGameEnter = 100,	// game enter request
	CM_RequestChat,				// chat												(done)
	CM_ReadyForGame,			// finished preparing resource, ready to join game.	(done)
	CM_SyncPlayerData,			// sync player data.								(done)
	CM_Shoot,					// shooting.
	CM_Poke,					// poking.
	CM_PokeHurt,				// poke hurt.
	CM_GrenadeThrowIn,			// throwing a grenade.
	CM_GrenadeThrowStop,		// throwing a grenade.
	CM_GrenadeThrowOut,			// throwing a grenade.
	CM_Hurt,					// hurt myself.
	CM_GrenadeHurt,				// hurt by grenade.
	CM_Reload,					// reloading
	CM_DropWeapon,				// drop Weapon
	CM_PickUpWeapon,			// pick up Weapon
	CM_SelectWeapon,			// select weapon
	CM_LeaveGame,				// leave game										(done)
	CM_KickBack,				// kick back
	CM_FlashBright,				// flash bright
	CM_CameraFovChanged,		// camera fov changed
	CM_PickUpSupplyObject,		// pick up supply obejct
	CM_UseSkill,				// use skill
	CM_ChangePack,				// change pack
	CM_KickClientStart,			// kick client start
	CM_KickClientVote,			// kick client vote
	CM_Suicide,					// suicide
	CM_RadioReport,				// radio report
	CM_SpawnConfirm,			// spawn confirm									(done)
	CM_ReloadReady,				// reload ready
	CM_ActionOn,				// player action on changed
	CM_ProjectedAmmoOut,		// fire a ProjectedAmmo.
	CM_ProjectedAmmoDestroy,	// destroy a ProjectedAmmo.
	CM_ProjectedAmmoUpdate,		// update a ProjectedAmmo
	CM_ProjectedAmmoHurt,		// hurt by ProjectedAmmo.
	CM_ProjectedProdHurt,		// hurt by ProjectedProd.
	CM_ChangeCareer,			//													(done)
	CM_CureCharacter,			//
	CM_PlayerAnimationStart,	// animation start
	CM_PlayerAnimationEnd,		// animation end
	CM_CallDoctor,				// call doctor
	CM_PlayerFlameShoot,		// player flame shoot
	CM_StopBurn,				// stop burn
	CM_DrumCheck,				// drum check
	CM_Drink,					// drink
	CM_Spray,					// spray
	CM_ChangeAmmoTeam,			// change ammo team
	CM_UseSpawnCoin,
	CM_PickUpSupplyObjectNew,	// pick up supply object new
	CM_OpenMessageClient,
	CM_PVEAmmoOut,				//
	CM_PVEAmmoDestroy,			//
	CM_PVEAmmoHitHurt,			//
	CM_PVEAmmoExplodeHurt,		//
	CM_PVEAmmoUpdate,			//
	CM_CutHurt,					//
	CM_DummyObjectCreate,		//
	CM_DummyObjectDestory,		//
	CM_DummySyncUpdate,			//
	CM_GunTowerShoot,			//
	CM_DummyPokeHurt,			//
	CM_DummyProjectedAmmoHurt,	//
	CM_DummyGrenadeHurt,
	CM_DummyProjectedProdHurt,
	CM_CharacterHeal,
	CM_Teleport,
	CM_ForceSpawn,
	CM_UseItem,
	CM_NEED_DIE_BUFF,
	// ģʽ�޹���Ϣ end
	
	// ģʽ�����Ϣ start
	// ѵ����
	CM_NoviceOperation,			// novice operation
	// ����ģʽ
	CM_StartPlantBomb,
	CM_CancelPlantBomb,
	CM_StartDefuseBomb,			// defuse bomb
	CM_CancelDefuseBomb,
	// ����ģʽ
	CM_StartSaveDying,
	CM_CancelSaveDying,
	CM_ChargeSomething,		

	//��ͨ����
	CM_SkillKickBack,
	CM_UseSkillSuperMan,
	CM_CancelInvisible,
	CM_UseSmog,
	CM_SomgAreaCancel,
	//����ս
	CM_UseItem_ItemMode,
	CM_ItemMode_ZiBao,
	//TD�༭ģʽ
	CM_SAVE_MAP,
	//�����ʵ�
	CM_MoonBoss,
	//SurvivalMode
	CM_UseItemSurvival,
	CM_UseItemSurvivalByGhost,
	// ģʽ�����Ϣ end


	

};

enum EPlayerData
{
	PD_None				= 0,
	PD_Status			= 1 << 0,
	PD_Rotation			= 1 << 1,
	PD_Position			= 1 << 2,
	PD_Ping				= 1 << 3,
};

enum EPlayerStatus
{
	PS_None				= 0,
	PS_Jump				= 1 << 0,
	PS_OnGround			= 1 << 1,
	PS_Crouch			= 1 << 2,
	PS_Walk				= 1 << 3,
	PS_MoveForward		= 1 << 4,
	PS_MoveBack			= 1 << 5,
	PS_MoveLeft			= 1 << 6,
	PS_MoveRight		= 1 << 7,
	PS_Fly				= 1 << 8,
	PS_Boost			= 1 << 9,
};

enum EError
{
	ERR_ReadStream,
	ERR_Write,
	ERR_Auth,
	ERR_Closed,
	ERR_Socket,
};


// -----------------------------------------------------------------
// ChannelConnection functions
// -----------------------------------------------------------------
// constructor.
ChannelConnection::ChannelConnection()
: character_id(0)
, network_delay(0.2f)
{
	client_connecting = false;
	connection = NULL;
	tcp_connection.stream = NULL;
	udp_connection.stream = NULL;

	no_delay = false;

	for (uint i = 0; i < room_slots.Size(); i ++)
	{
		room_slots[i].id = 0;
		room_slots[i].team = 0;
		room_slots[i].status = RoomSlot::kClosed;
	}
}

// destructor
ChannelConnection::~ChannelConnection()
{
	if(gGame && gGame->lobby_connection)
		gGame->lobby_connection->m_RememberLobby = NullPtr;
}

// diconnect
void ChannelConnection::Disconnect()
{
	LogSystem.WriteLinef("ChannelConnection disconnect ");

	udp_connection.Disconnect();

	//udp_connection.Disconnect();
	tcp_connection.Disconnect();
}

// update
void ChannelConnection::OnUpdate(float frame_time)
{
	PROFILE("ChannelConnection::OnUpdate");

	static float connection_check_time = 0;

	//udp_connection.OnUpdate();
	udp_connection.OnUpdate();
	tcp_connection.OnUpdate();

	if (state == kInGame || state == kInReplay)
	{
		connection_check_time += Task::GetFrameTime();
		game_time += frame_time;

		if (connection_check_time > 3)
		{
			connection_check_time = 0;
			ConnectionCheck();
		}
	}



	OnUpdateReplay();
}

// send messages
void ChannelConnection::SendMessages()
{
	udp_connection.SendMessages();
	tcp_connection.SendMessages();
}

// is idle
bool ChannelConnection::IsIdle()
{

	if (udp_connection.stream)
		return udp_connection.IsIdle();

	if (tcp_connection.stream)
		return tcp_connection.IsIdle();

	return true;
}


// on message
void ChannelConnection::OnMessage()
{
	PROFILE("ChannelConnection::OnMessage");

	switch (state)
	{
	case kConnected:
		{
			SetClientMessage(true);

			byte msg;
			ReadByte(msg);
			//LogSystem.WriteLinef("%s, %s, getmessage state : %d, message %d", __FILE__, __FUNCTION__, state, msg);

			switch (msg)
			{
			case SM_ResponseChannelEnter:		ResponseChannelEnter();		break;
			}
		}
		break;

	case kInChannel:
		{
			byte msg;
			ReadByte(msg);
			//LogSystem.WriteLinef("%s, %s, getmessage state : %d, message %d", __FILE__, __FUNCTION__, state, msg);

			switch (msg)
			{
			case SM_ResponseRoomList:		ResponseRoomList();			break;
			case SM_ResponseRoomCreate:		ResponseRoomCreate();		break;
			case SM_ResponseRoomEnter:		ResponseRoomEnter();		break;
			case SM_ResponseClientList:		ResponseClientList();		break;
			case SM_ResponseTDData:			ResponseTDData();			break;

			case SM_NotifyRoomCreate:		NotifyRoomCreate();			break;
			case SM_NotifyRoomClose:		NotifyRoomClose();			break;
			case SM_NotifyRoomList:			NotifyRoomList();			break;
			case SM_NotifyRoomChangeOption:	NotifyRoomChangeOption();	break;
			case SM_NotifyRoomStateChanged:	NotifyRoomStateChanged();	break;
			case SM_NotifyRoomHostChanged:	ParseNotifyRoomHostChanged(*this);	break;
			case SM_NotifyRoomClientCountChanged:	NotifyRoomClientCountChanged();	break;
			case SM_NotifyChat:				ParseNotifyChat(*this);				break;

			default:
				{
					LogSystem.WriteLinef("%s, %s, getmessage state : %d, message %d, can't find msg", __FILE__, __FUNCTION__, state, msg);
				}break;
			
			}
		}
		break;

	case kInRoom:
	case kInBalance:
		{
			byte msg;
			ReadByte(msg);
			//LogSystem.WriteLinef("%s, %s, getmessage state : %d, message %d", __FILE__, __FUNCTION__, state, msg);

			switch (msg)
			{
				//todo
				case SM_ResponseRoomCreate:		ResponseRoomCreate();		break;
			case SM_NotifyRoomClientEnter:			NotifyRoomClientEnter();		break;
			case SM_NotifyRoomClientLeave:			NotifyRoomClientLeave();		break;
			case SM_NotifyRoomClientUpdate:			NotifyRoomClientUpdate();		break;
			case SM_NotifyRoomChangeOption:			NotifyRoomChangeOption();		break;
			case SM_NotifyRoomStateChanged:			NotifyRoomStateChanged();		break;
			case SM_NotifyClientChangeTeam:			NotifyClientChangeTeam();		break;
			case SM_NotifyClientReady:				NotifyClientReady();			break;
			case SM_NotifyClientAutoStart:			NotifyClientAutoStart();		break;
			case SM_NotifyClientAutoStartCancel:	NotifyClientAutoStartCancel();	break;
			case SM_NotifyGameStart:				NotifyGameStart();				break;
			case SM_NotifyGameEnd:					NotifyGameEnd();				break;
			case SM_NotifyGameLeave:				NotifyGameLeave();				break;
			case SM_NotifyGameClientEnter:			NotifyGameClientEnter();		break;
			case SM_NotifyGameClientLeave:			NotifyGameClientLeave();		break;
			case SM_NotifyRoomHostChanged:			ParseNotifyRoomHostChanged(*this);	break;

			case SM_ResponseRoomLeave:			ResponseRoomLeave();		break;
			case SM_ResponseRoomClientList:		ResponseRoomClientList();	break;
			case SM_ResponseRoomChangeOption:	ResponseRoomChangeOption();	break;
			case SM_ResponseRoomChangeTeam:		ResponseRoomChangeTeam();	break;
			case SM_ResponseRoomChangeSlot:		ResponseRoomChangeSlot();	break;
			case SM_ResponseRoomReady:			ResponseRoomReady();		break;
			case SM_ResponseGameStart:			ResponseGameStart();		break;
			case SM_ResponseGameEnter:			ResponseGameEnter();		break;
			case SM_NotifyChat:					ParseNotifyChat(*this);		break;
			case SM_NotifyRoomKickClient:		NotifyRoomKickClient();		break;
			case SM_NotifyClientChangeSlot:		NotifyClientChangeSlot();	break;
			case SM_ResponseRoomChangeSlotStatus: ResponseRoomChangeSlotStatus(); break;
			case SM_NotifyRoomChangeSlotStatus:	NotifyRoomChangeSlotStatus(); break;
			case SM_ResponseRoomPreserveSlot:	ResponseRoomPreserveSlot();	break;
			case SM_ResponseClientList:			ResponseClientList();	break;
			case SM_ResponseTDData:				ResponseTDData();		break;
			default:
				{
					LogSystem.WriteLinef("%s, %s, getmessage state : %d, message %d, can't find msg", __FILE__, __FUNCTION__, state, msg);
				}break;
			}
		}
		break;

	case kInGame:
		{
			sharedc_ptr(MessagePacket) packet = ptr_new MessagePacket(read_position, read_end - read_position);
			read_position = read_end;

			if (packet)
			{
				packet->SetMessageTime(game_time);
				message_set.PushBack(packet);
				OnMessageGame(*packet);
			}
		}
		break;
	}
}

static const Identifier REPLAY_TYPE("finalcombat replay");

static void FormatReplayPath(CRefStr & buff, const char * path)
{
	const char * s = path;
	char * p = const_cast<char*>(buff.buff());

	while (s[0])
	{
		switch (s[0])
		{
		case '/':
		case '\\':
		case '?':
		case '*':
			p[0] = '-';
			break;

		case '.':
			if (s[1] == '.')
			{
				p[0] = '-';
				p[1] = '-';

				s += 2;
				p += 2;
				continue;
			}
			break;

		default:
			p[0] = s[0];
			break;
		}

		p++;
		s++;
	}

	p[0] = 0;

	buff.calclen();
}

String ChannelConnection::ReplaySave(Core::String path)
{
	int size = message_set.Size();
	if (size > 0)
	{
		DynamicMemoryStream stream;
		BinaryStreamWriter writer(stream);
		writer.WriteString(REPLAY_TYPE.Str());
		writer.WriteUInt32(network_version);
		writer.WriteUInt32(size);

		for (int i = 0; i < size; i++)
		{
			if (message_set[i])
			{
				tempc_ptr(MessagePacket) packet = message_set[i];
				writer.WriteUInt32(message_set[i]->data_size);
				writer.Write(message_set[i]->data_buffer, message_set[i]->data_size);
			}
		}

		uint length = stream.GetLength();
		stream.Seek(0, Stream::kSeekSet);
		Buffer* buffer = Buffer::Create(length);
		stream.Read(buffer->GetBufferPointer(), length);
		Buffer* compress = Buffer::Create(length + 400);
		length = Utilities::Compress(buffer->GetBufferPointer(), compress->GetBufferPointer(), length);
		buffer->Release();
		buffer = compress;
		compress = NULL;
		((uint*)buffer)[-1] = length;

		CStrBuf<256> buf;
		FormatReplayPath(buf, path);
		buf.insert(0, "/replay/");
		buf.contract(".replay");

		Path::MakeDirectory(buf);

		FileStream file;
		if (file.Open(buf, FileStream::kWriteOnly))
		{
			file.Write(buffer->GetBufferPointer(), buffer->GetBufferSize());
			file.Close();

			return buf;
		}

		buffer->Release();
		buffer = NULL;
	}

	return String::kEmpty;
}

void ChannelConnection::ReplayPlay()
{
	if(state == kInChannel)
	{
		if (message_set.Size() > 0)
		{
			OnEnterReplay();
		}
	}
}

enum ReplayError
{
	kReplayErrorNone = 0,
	kReplayErrorState,
	kReplayErrorFile,
	kReplayErrorType,
	kReplayErrorVersion,
	kReplayErrorFormat,
};

int ChannelConnection::ReplayOpen(Core::String path)
{
	int ret = kReplayErrorState;

	if (state == kInChannel)
	{
		CStrBuf<256> buf;
		FormatReplayPath(buf, path);
		buf.insert(0, "/replay/");
		buf.contract(".replay");

		ret = kReplayErrorFile;

		if (Path::IsFile(buf))
		{
			FileStream file;
			if (file.Open(buf, FileStream::kReadOnly))
			{
				Buffer* buffer = NULL;

				try
				{
					message_set.Clear();

					int length = file.GetLength();
					buffer = Buffer::Create(length);
					file.Read(buffer->GetBufferPointer(), length);
					Buffer* decompress = Buffer::Create(Utilities::DecompressSize(buffer->GetBufferPointer()));
					length = Utilities::Decompress(buffer->GetBufferPointer(), decompress->GetBufferPointer());
					buffer->Release();
					buffer = decompress;
					decompress = NULL;
					((uint*)buffer)[-1] = length;

					MemoryStream stream(buffer->GetBufferPointer(), buffer->GetBufferSize());
					BinaryStreamReader reader(stream);

					char str[32];
					reader.ReadString(str, sizeof(str));

					Identifier replay_mark(str);
					if (replay_mark != REPLAY_TYPE)
					{
						ret = kReplayErrorType;
						throw ERR_ReadStream;
					}

					int replay_version = reader.ReadInt32();

					if (replay_version != network_version)
					{
						ret = kReplayErrorVersion;
						throw ERR_ReadStream;
					}

					int size = reader.ReadUInt32();

					float message_time = 0;

					for (int i = 0; i < size; i++)
					{
						int data_size = reader.ReadUInt32();

						if (data_size > 0)
						{
							Buffer* b = Buffer::Create(data_size);
							reader.Read(b->GetBufferPointer(), data_size);

							sharedc_ptr(MessagePacket) packet = ptr_new MessagePacket(b->GetBufferPointer(), data_size , 0);
							message_set.PushBack(packet);

							b->Release();
							b = NULL;

							message_time = packet->GetMessageTime();
						}
						else
						{
							ret = kReplayErrorFormat;
							throw ERR_ReadStream;
						}
					}

					ret = kReplayErrorNone;
				}
				catch (...)
				{
					Console.WriteLinef("load replay error : %s", buf);
					message_set.Clear();

					if (ret == kReplayErrorNone)
						ret = kReplayErrorFormat;
				}

				file.Close();

				if (buffer)
				{
					buffer->Release();
					buffer = NULL;
				}
			}
		}
	}

	return ret;
}

void ChannelConnection::OnUpdateReplay()
{
	if (state != kInReplay)
		return;


	try
	{
		for (int i = replay_index; i < (int)message_set.Size(); i++)
		{
			tempc_ptr(MessagePacket) packet = message_set[i];
			byte messageType = packet->GetMessageType();
			
			if (packet)
			{
				switch (game_state)
				{
				case kLoading:
					{
						if (packet->GetMessageType() == SM_Initialize)
							return;
					}
					break;

				case kWaiting:
					{
						OnMessageGame(*packet);
						replay_index++;
						game_time = packet->GetMessageTime();
						continue;
					}
					break;
				}	

				if (packet->GetMessageTime() <= game_time)
				{
					OnMessageGame(*packet);
					replay_index++;
				}
				else
				{
					break;
				}
			}
		}
	}
	catch (...)
	{
		OnLeaveReplay();
	}

	if (replay_index >= (int)message_set.Size())
		OnLeaveReplay();
}

// on replay leave
void ChannelConnection::OnLeaveReplay()
{
	if (state == kInReplay)
	{
		if (gLevel)
			gLevel->Unload();

		if (gGame->lobby_connection)
			gGame->lobby_connection->RestoreToStateLobby();

		// reset message packet
		for (int i = 0; i < (int)message_set.Size(); i++)
		{
			if (message_set[i])
				message_set[i]->Reset();
		}

		game_parse = false;
		game_rate = 1;

		LogSystem.WriteLinef("action : leave replay");

		gGame->global->SetGameRate(1.0f);
		gGame->global->SetGameStop(false);

		
	}
}

void ChannelConnection::OnEnterReplay()
{
	if( state == kInChannel)
	{
		state = kInReplay;

		player_sync_time = 0;
		player_status = 0;
		player_position = Vector3::kZero;
		player_rotation = Quaternion::kIdentity;

		game_state = kAuthentication;
		game_time = 0;
		replay_index = 0;
		game_parse = false;
		game_rate = 1;

		LogSystem.WriteLinef("action : enter replay");
	}
}

// on connected
void ChannelConnection::OnConnected()
{
	state = kConnected;

#if USE_COMPRESSOR
	huffman_compressor.Reset();
	compressor = &huffman_compressor;
#endif

#if USE_ENCODER
	xor_encoder.Reset();
	encoder = &xor_encoder;
#endif

	RequestChannelEnter();
}

// on disconnected
void ChannelConnection::OnDisconnected(bool is_error)
{
	if (state == kInGame)
	{
		if (gLevel)
			gLevel->Unload();
	}

	ServerInfo* pInfo = NULL;
	for (int i = 0; i < gGame->lobby_connection->server_list.GetCount(); ++i)
	{
		if (gGame->lobby_connection->server_list[i].id == gGame->address.server_id)
		{
			pInfo = &gGame->lobby_connection->server_list[i];
		}
	}
	if (pInfo)
	{
		if (pInfo->servertype == SvrType_Match  || pInfo->servertype == SvrType_MatchFighting)// SvrType_Match
		{
			gGame->lobby_connection->RequestLeaveServer();
			return ;
		}

	}


	OnLeaveChannel();

	tempc_ptr(StateLobby) lobby = ptr_dynamic_cast<StateLobby>(gGame->machine.CurrentState());
	if (client_connecting)
	{
		if (lobby)
			lobby->EventEnterChannel.Fire(ptr_static_cast<StateLobby>(lobby), RetEventArgs(kErrorProxyChannelConnect));

		if(is_error && lobby)
		{
			lobby->ForceUILeaveChannel();
		}
	}

	connection = NULL;
	tcp_connection.stream = NULL;
	udp_connection.stream = NULL;

	if (lobby)
	{
		lobby->EventCancelChannel.Fire(ptr_static_cast<StateLobby>(lobby), RetEventArgs());
		lobby->BattleGroupLeave(0);
	}

	
	
}

// request channel enter
void ChannelConnection::RequestChannelEnter()
{
	if (state == kConnected)
	{
		BeginWrite();
		WriteByte(CM_RequestChannelEnter);
		WriteInt(lobby_uid);
		WriteInt(character_id);
		EndWrite();

		// start encoding
	}
}

// request room list
void ChannelConnection::RequestRoomList()
{
	if (state == kInChannel)
	{
		BeginWrite();
		WriteByte(CM_RequestRoomList);
		EndWrite();
	}
}

// request chat
void ChannelConnection::RequestChat(const Core::Identifier & to, const Core::String & msg)
{
	if (state >= kInChannel)
	{
		if (msg.Length() > 0)
		{
			CStrBuf<character_name_length> to_str(to.Str());
			CStrBuf<chat_length> msg_str(msg.Str());
			msg_str.validate();

			BeginWrite();
			WriteByte(CM_RequestChat);
			WriteString(to_str);
			WriteString(msg_str);
			EndWrite();
		}
	}
}

// request room create
void ChannelConnection::RequestRoomCreate(const RoomOption & option)
{
	LogSystem.WriteLinef("%s, %s", __FILE__, __FUNCTION__);
	if (state == kInChannel)
	{
		BeginWrite();
		WriteByte(CM_RequestRoomCreate);
		WriteRoomOption(*this, option);
		EndWrite();
	}
	else
	{
		tempc_ptr(StateLobby) lobby = ptr_dynamic_cast<StateLobby>(gGame->machine.CurrentState());
		if(lobby)
			lobby->EventCreateRoomFailed.Fire(ptr_static_cast<StateLobby>(lobby), RetEventArgs(kErrorProxyChannelConnect));
	}
}

// request room enter
void ChannelConnection::RequestRoomEnter(int room_id, const char* password)
{
	if (state == kInChannel)
	{
		BeginWrite();
		WriteByte(CM_RequestRoomEnter);
		WriteInt(room_id);
		WriteString(password);
		EndWrite();
	}
}

// request room enter
void ChannelConnection::RequestRoomTeamEnter(int room_id, const char* password, const Core::Array<Core::String> & members)
{
	if (state == kInChannel)
	{
		BeginWrite();
		WriteByte(CM_RequestRoomTeamEnter);
		WriteInt(room_id);
		WriteString(password);
		WriteByte(members.Size());
		for (uint i = 0 ;i < members.Size(); i ++)
			WriteString(members[i]);
		EndWrite();
	}
}


// request room leave
void ChannelConnection::RequestRoomLeave()
{
	if (state == kInRoom)
	{
		BeginWrite();
		WriteByte(CM_RequestRoomLeave);
		EndWrite();
	}
}

//requeset room client list
void ChannelConnection::RequestRoomClientList()
{
	LogSystem.WriteLinef("RequestRoomClientListRequestRoomClientListRequestRoomClientListRequestRoomClientList1111111");
	if (state == kInRoom || state == kInGame)
	{
		LogSystem.WriteLinef("RequestRoomClientListRequestRoomClientListRequestRoomClientListRequestRoomClientList2222222");
		BeginWrite();
		WriteByte(CM_RequestRoomClientList);
		EndWrite();
	}
}

// request room change option
void ChannelConnection::RequestRoomChangeOption(const RoomOption & option)
{
	if (state == kInRoom)
	{
		BeginWrite();
		WriteByte(CM_RequestRoomChangeOption);
		WriteRoomOption(*this, option);
		EndWrite();
	}
}

// request room change team
void ChannelConnection::RequestRoomChangeTeam(byte team)
{
	if (state == kInRoom)
	{
		BeginWrite();
		WriteByte(CM_RequestRoomChangeTeam);
		WriteByte(team);
		EndWrite();
	}
}

// request room change slot
void ChannelConnection::RequestRoomChangeSlot(byte slot_id)
{
	if (state == kInRoom)
	{
		BeginWrite();
		WriteByte(CM_RequestRoomChangeSlot);
		WriteByte(slot_id);
		EndWrite();
	}
}

// request room preserve slot
void ChannelConnection::RequestRoomPreserveSlot(byte slot_id, const Core::String & name)
{
	if (state == kInRoom)
	{
		BeginWrite();
		WriteByte(CM_RequestRoomPreserveSlot);
		WriteByte(slot_id);
		WriteString(name);
		EndWrite();
	}
}


// request room change slot status
void ChannelConnection::RequestRoomChangeSlotStatus(byte slot_id, RoomSlot::Status status)
{
	if (state == kInRoom)
	{
		BeginWrite();
		WriteByte(CM_RequestRoomChangeSlotStatus);
		WriteByte(slot_id);
		WriteInt(status);
		EndWrite();
	}
}

// request room slot preserve


// request room ready
void ChannelConnection::RequestRoomReady(bool ready)
{
	if (state == kInRoom)
	{
		BeginWrite();
		WriteByte(CM_RequestRoomReady);
		WriteByte(ready);
		EndWrite();
	}
}

// request room kick client
void ChannelConnection::RequestRoomKickClient(byte id_in_room)
{
	if (state == kInRoom)
	{
		BeginWrite();
		WriteByte(CM_RequestRoomKickClient);
		WriteByte(id_in_room);
		EndWrite();
	}
}

// request client list
void ChannelConnection::RequestClientList(int start_id)
{
	if (state == kInRoom || state == kInChannel)
	{
		BeginWrite();
		WriteByte(CM_RequestClientList);
		WriteInt(start_id);
		EndWrite();
	}
}

// request game start
void ChannelConnection::RequestGameStart()
{
	if (state == kInRoom)
	{
		BeginWrite();
		WriteByte(CM_RequestGameStart);
		EndWrite();
	}
}

// request novice
bool ChannelConnection::RequestNovice()
{
	if (state == kInChannel)
	{
		BeginWrite();
		WriteByte(CM_RequestNovice);
		EndWrite();
		tempc_ptr(StateLobby) state_main = ptr_dynamic_cast<StateLobby>(gGame->machine.CurrentState());
		if(state_main)
		{
			state_main->m_Is_Novice_Game = false;
			return true;
		}
	}
	return false;
}

// request td data
void ChannelConnection::RequestTDData(int level_id, int map_level, int res_value, const Core::String & rand_key)
{
	if (state == kInRoom)
	{
		BeginWrite();
		WriteByte(CM_RequestTDData);
		WriteInt(level_id);
		WriteInt(map_level);
		WriteInt(res_value);
		WriteString(rand_key.Str());
		EndWrite();
	}
}

// request game enter
void ChannelConnection::RequestGameEnter()
{
	if (state == kInRoom)
	{
		BeginWrite();
		WriteByte(CM_RequestGameEnter);
		EndWrite();
	}
}

// response room list
void ChannelConnection::ResponseChannelEnter()
{
	int result;
	ReadInt(result);
	ReadInt(gGame->address.channel_id);
	ReadString(gGame->address.channel_name);

	if (result == kErrorNone)
	{
		g_InGameInfo_collection.channel_id = gGame->address.channel_id;

		// on enter channel
		OnEnterChannel();

		// todo
		if(gGame && gGame->lobby_connection)
		{
			if (gGame->lobby_connection->m_dwRoomId)
			{
				LogSystem.WriteLinef("%s, %s room_id : %d, slot_id : %d", __FILE__, __FUNCTION__, gGame->lobby_connection->m_dwRoomId, gGame->lobby_connection->m_dwSlotId);
				RequestRoomEnterWithSlotId(gGame->lobby_connection->m_dwRoomId, gGame->lobby_connection->m_dwSlotId);
				gGame->lobby_connection->m_dwRoomId = 0;
				gGame->lobby_connection->m_dwSlotId = 0;
			}
		}
	}
	else
	{
		tempc_ptr(StateLobby) lobby = ptr_dynamic_cast<StateLobby>(gGame->machine.CurrentState());

		if (lobby)
			lobby->EventEnterChannel.Fire(ptr_static_cast<StateLobby>(lobby), RetEventArgs(result));

		client_connecting = false;
		Disconnect();
	}

	client_connecting = false;
}

// response room list
void ChannelConnection::ResponseRoomList()
{
	LogSystem.WriteLinef("%s, %s", __FILE__, __FUNCTION__);
	room_list.Clear();

	short room_count;
	ReadShort(room_count);
	for (int i = 0; i < room_count; ++i)
	{
		sharedc_ptr(RoomInfo) info = ptr_new RoomInfo;
		ReadRoomInfo(*this, *info);
		room_list.PushBack(info);
	}

	OnRoomListChanged();
}

// response room create
void ChannelConnection::ResponseRoomCreate()
{
	int result;
	ReadInt(result);

	// todo Ϊ���ݴ�����ôŪ�� ��ʱ���ǲ���Ҫ�޸�
	if (state == kInRoom)
	{
		ServerInfo* pInfo = NULL;
		for (int i = 0; i <gGame->lobby_connection-> server_list.GetCount(); ++i)
		{
			if (gGame->lobby_connection->server_list[i].id == gGame->address.server_id)
			{
				pInfo = &gGame->lobby_connection->server_list[i];
			}
		}
		// todo
		if (pInfo && pInfo->servertype == SvrType_Match || pInfo->servertype == SvrType_MatchFighting)
		{
			state = kInRoom;
			gGame->lobby_connection->RequestMatchingTeamCreate(gGame->address.server_id,gGame->address.channel_id,gGame->address.room_id,room_info.option);
			return;
		}
		
	}
	if (result == kErrorNone)
	{
		ReadRoomInfo(*this, room_info);

		// read slots
		for (uint i = 0; i < room_slots.Size(); i ++)
		{
			ReadRoomSlot(*this, room_slots[i]);
		}
		tempc_ptr(StateLobby) lobby = ptr_dynamic_cast<StateLobby>(gGame->machine.CurrentState());
		gGame->address.room_id = room_info.id;
		if(lobby)
		{
			if (lobby->m_is_fight_team_server)
			{
				if (lobby->m_battle_is_create)
				{
					lobby->GetBattleGroupCreate(gGame->address.server_id,gGame->address.channel_id,gGame->address.room_id,room_info.option);
				}
				else if(lobby->m_source_is_create)
				{
					
				}
			}
		}

		ServerInfo* pInfo = NULL;
		for (int i = 0; i <gGame->lobby_connection-> server_list.GetCount(); ++i)
		{
			if (gGame->lobby_connection->server_list[i].id == gGame->address.server_id)
			{
				pInfo = &gGame->lobby_connection->server_list[i];
			}
		}
		// todo
		if (pInfo && pInfo->servertype == SvrType_Match || pInfo->servertype == SvrType_MatchFighting )
		{
			//

			//RoomOption option;
			//for (uint i = 0; i < room_list.Size(); ++i)
			//{
			//	if (room_list[i] && room_list[i]->id == gGame->lobby_connection->character_id)
			//	{
			//		option = room_list[i]->option;
			//		break;
			//	}
			//}

			//state = kInRoom;
			gGame->lobby_connection->RequestMatchingTeamCreate(gGame->address.server_id,gGame->address.channel_id,gGame->address.room_id,room_info.option);
			OnEnterRoom();
		}
		else
		{
			OnEnterRoom();
		}
	}
	else
	{
		tempc_ptr(StateLobby) lobby = ptr_dynamic_cast<StateLobby>(gGame->machine.CurrentState());
		if(lobby)
			lobby->EventCreateRoomFailed.Fire(ptr_static_cast<StateLobby>(lobby), RetEventArgs(result));
	}
}

// response room enter
void ChannelConnection::ResponseRoomEnter()
{
	int result;
	ReadInt(result);

	if (result == kErrorNone)
	{
		ReadRoomInfo(*this, room_info);

		// read slots
		for (uint i = 0; i < room_slots.Size(); i ++)
		{
			ReadRoomSlot(*this, room_slots[i]);
		}

		gGame->address.room_id = room_info.id;
		OnEnterRoom();
	}
	else
	{
		tempc_ptr(StateLobby) lobby = ptr_dynamic_cast<StateLobby>(gGame->machine.CurrentState());
		if(lobby)
			lobby->EventEnterRoomFailed.Fire(ptr_static_cast<StateLobby>(lobby), RetEventArgs(result));
	}
}

// response room leave
void ChannelConnection::ResponseRoomLeave()
{
	OnLeaveRoom();
	/*ServerInfo* pInfo = NULL;
	for (int i = 0; i < gGame->lobby_connection->server_list.GetCount(); ++i)
	{
		if (gGame->lobby_connection->server_list[i].id == gGame->address.server_id)
		{
			pInfo = &gGame->lobby_connection->server_list[i];
			break;
		}
	}
	if (pInfo->servertype == SvrType_Match)
	{
		if (gGame && gGame->lobby_connection)
		{
			gGame->channel_connection->Disconnect();
		}
	}*/
}

// response room client list
void ChannelConnection::ResponseRoomClientList()
{
	for(uint i = 0 ; i < client_list.Size() ; i++)
	{
		if(client_list[i]->character_id != gGame->channel_connection->character_id)
		{
			client_list.Remove(client_list[i]);
		}
	}
	LogSystem.WriteLinef("client_countclient_countclient_countclient_cds454555555555555555555555555555555555555555555551client_countclient_countclient_countclient_countclient_countclient_count1:%d",client_list.Size());
	for(uint i = 0 ; i < client_list.Size() ; i++)
	{
		if(client_list[i]->character_id != gGame->channel_connection->character_id)
		{
			client_list.Remove(client_list[i]);
		}
	}
	LogSystem.WriteLinef("client_countclient_countclient_countclient_cds1111111111111111client_countclient_countclient_countclient_countclient_countclient_count1:%d",client_list.Size());
	for(uint i = 0 ; i < client_list.Size() ; i++)
	{
		LogSystem.WriteLinef("client_list[i].character_id:%d",client_list[i]->character_id);
	}
	LogSystem.WriteLinef("client_countclient_countclient_countclient_countclient_coun666666666666666666666client_countclient_countclient_countclient_countclient_countclient_count1:%d",client_list.Size());
	//client_list.Clear();

	int client_count;
	ReadInt(client_count);
	LogSystem.WriteLinef("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA:%d",client_count);
	for (int i = 0; i < client_count; ++i)
	{
		sharedc_ptr(ClientInfo) info = ptr_new ClientInfo;
		ReadClientInfo(*this, *info);

		LogSystem.WriteLinef("character name : %s, id : %d, my id : %d", info->name, info->character_id, gGame->channel_connection->character_id);

		if(info->character_id != gGame->channel_connection->character_id)
		{
			client_list.PushBack(info);
		}
		else
		{
			for(uint i = 0 ; i < client_list.Size() ; i++)
			{
				if(client_list[i]->character_id == gGame->channel_connection->character_id)
				{
					client_list.Remove(client_list[i]);
					break;
				}
			}
			client_list.PushBack(info);
		}
	}

	OnRoomClientListChanged();
	
}

void Client::ChannelConnection::ResponseRoomClientList(Core::BinaryNetworkReader & reader)
{
	for(uint i = 0 ; i < client_list.Size() ; i++)
	{
		if(client_list[i]->character_id != gGame->channel_connection->character_id)
		{
			client_list.Remove(client_list[i]);
		}
	}
	LogSystem.WriteLinef("client_countclient_countclient_countclient_777777777777777countclient_countclient_countclient_countclient_countclient_countclient_countclient_count2:%d",client_list.Size());
	for(uint i = 0 ; i < client_list.Size() ; i++)
	{
		if(client_list[i]->character_id != gGame->channel_connection->character_id)
		{
			client_list.Remove(client_list[i]);
		}
	}
	int client_count;
	reader.ReadInt(client_count);
	for (int i = 0; i < client_count; ++i)
	{
		sharedc_ptr(ClientInfo) info = ptr_new ClientInfo;
		ReadClientInfo(reader, *info);

		LogSystem.WriteLinef("character name : %s, id : %d, my id : %d", info->name, info->character_id, gGame->channel_connection->character_id);

		if(info->character_id != gGame->channel_connection->character_id)
		{
			client_list.PushBack(info);
		}
		else
		{
			for(uint i = 0 ; i < client_list.Size() ; i++)
			{
				if(client_list[i]->character_id == gGame->channel_connection->character_id)
				{
					client_list.Remove(client_list[i]);
					break;
				}
			}
			client_list.PushBack(info);
		}
	}

	OnRoomClientListChanged();
}

// response room change option
void ChannelConnection::ResponseRoomChangeOption()
{
	int result;
	ReadInt(result);

	LogSystem.WriteLinef("result = %d", result);

	if (result == kErrorNone)
	{
		//already do, do not send again
	}
	else
	{
		tempc_ptr(StateLobby) lobby = ptr_dynamic_cast<StateLobby>(gGame->machine.CurrentState());

		if (lobby)
		{
			lobby->EventRoomOptionChangedFailed.Fire(ptr_static_cast<StateLobby>(lobby), RetEventArgs(result));
		}
	}
}

// response room change team
void ChannelConnection::ResponseRoomChangeTeam()
{
	int result;
	ReadInt(result);

	if (result == kErrorNone)
	{
        tempc_ptr(StateLobby) lobby = ptr_dynamic_cast<StateLobby>(gGame->machine.CurrentState());
		if(lobby)
			lobby->OnInRoomChangeTeamSuccess();
	}
}

		// response room change slot
void ChannelConnection::ResponseRoomChangeSlot()
{
	int result;
	ReadInt(result);

	if (result == kErrorNone)
	{
	}
}

// notify room change slot status;
void ChannelConnection::ResponseRoomChangeSlotStatus()
{
	int result;
	ReadInt(result);

	if (result == kErrorNone)
	{
	}
}

// response room ready
void ChannelConnection::ResponseRoomReady()
{
	int result;
	ReadInt(result);

	if (result == kErrorNone)
	{
	}
        
	tempc_ptr(StateLobby) lobby = ptr_dynamic_cast<StateLobby>(gGame->machine.CurrentState());
	if(lobby)
		lobby->OnGameReady(result);
}

// response game start
void ChannelConnection::ResponseGameStart()
{
	int result;
	ReadInt(result);

	if (result == kErrorNone)
	{
		room_info.state = 2;
	}
	else
	{
		tempc_ptr(StateLobby) lobby = ptr_dynamic_cast<StateLobby>(gGame->machine.CurrentState());
		if(lobby)
			lobby->OnGameBegin(result);
	}
}

// response game enter
void ChannelConnection::ResponseGameEnter()
{
LogSystem.WriteLinef("GGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGG");
	int result;
	ReadInt(result);

	if (result == kErrorNone)
	{
		OnEnterGame();
	}

	tempc_ptr(StateLobby) lobby = ptr_dynamic_cast<StateLobby>(gGame->machine.CurrentState());
	if(lobby)
		lobby->OnGameBegin(result);
}

// notify channel client enter
void ChannelConnection::NotifyChannelClientEnter()
{

}

// notify channel client leave
void ChannelConnection::NotifyChannelClientLeave()
{
}

// notify room create
void ChannelConnection::NotifyRoomCreate()
{
	sharedc_ptr(RoomInfo) info = ptr_new RoomInfo;
	ReadRoomInfo(*this, *info);

	room_list.PushBack(info);

	OnRoomListChanged();
}

// notify room close
void ChannelConnection::NotifyRoomClose()
{
	int uid;
	ReadInt(uid);
	bool ret = false;

	for (uint i = 0; i < room_list.Size(); ++i)
	{
		if (room_list[i] && room_list[i]->id == uid)
		{
			room_list.RemoveAt(i);
			ret = true;
			break;
		}
	}

	if (ret)
		OnRoomListChanged();
}

// notify room list
void ChannelConnection::NotifyRoomList()
{
	room_list.Clear();

	short room_count;
	ReadShort(room_count);
	for (int i = 0; i < room_count; ++i)
	{
		sharedc_ptr(RoomInfo) info = ptr_new RoomInfo;
		ReadRoomInfo(*this, *info);
		room_list.PushBack(info);
	}

	OnRoomListChanged();
}

// notify room client enter
void ChannelConnection::NotifyRoomClientEnter()
{
	sharedc_ptr(ClientInfo) info = ptr_new ClientInfo;

	ReadClientInfo(*this, *info);

	LogSystem.WriteLinef("BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB");
	LogSystem.WriteLinef("client_countclient_countclient_countclient_countclient_countclient_countclient_countclient_countclient_countclient_countclient_count3:%d",client_list.Size());
	if(info->character_id != gGame->channel_connection->character_id)
	{
		client_list.PushBack(info);
	}
	else
	{
		for(uint i = 0 ; i < client_list.Size() ; i++)
		{
			if(client_list[i]->character_id == gGame->channel_connection->character_id)
			{
				client_list.Remove(client_list[i]);
				break;
			}
		}
		client_list.PushBack(info);
	}

	gGame->global->SystemMessage(String::Format(gLang->GetTextW(L"��ҡ�%s�������˷���"), info->name.Str()), "/info");

	OnRoomClientListChanged();
}

// notify room client leave
void ChannelConnection::NotifyRoomClientLeave()
{
	int cid;
	ReadInt(cid);
	LogSystem.WriteLinef("����뿪�˷�������뿪�˷�������뿪�˷�������뿪�˷�������뿪�˷�������뿪�˷�������뿪�˷���");
	for (uint i = 0; i < client_list.Size(); ++i)
	{
		if (client_list[i] && client_list[i]->character_id == cid)
		{
			gGame->global->SystemMessage(String::Format(gLang->GetTextW(L"��ҡ�%s���뿪�˷���"), client_list[i]->name.Str()), "/info");
			if(client_list[i]->character_id != gGame->channel_connection->character_id)
			{
				client_list.Remove(client_list[i]);
			}
			
			
			break;
		}
	}

	OnRoomClientListChanged();
}

// notify room client update
void ChannelConnection::NotifyRoomClientUpdate()
{
	sharedc_ptr(ClientInfo) info = ptr_new ClientInfo;

	ReadClientInfo(*this, *info);

	for (uint i = 0; i < client_list.Size(); ++i)
	{
		if (client_list[i] && client_list[i]->character_id == info->character_id)
		{
			client_list[i] = info;
			break;
		}
	}

	OnRoomClientListChanged();
}

// spray
void ChannelConnection::Spray(const Vector3 & position, const Vector3 & normal)
{
	if (state != kInGame)
		return;

	if (game_state == kGameLeaving)
		return;

	BeginWrite();
	WriteByte(CM_Spray);
	WriteVector3(position);
	WriteVector3(normal);
	EndWrite();
}

// parse spray
void ChannelConnection::ParseSpray(Core::BinaryNetworkReader & reader)
{
	byte uid;
	//int pid;
	//String path;
	//float length;
	//float width;
	float spray_index;

	Vector3 pos;
	Vector3 normal;

	reader.ReadByte(uid);
	reader.ReadFloat(spray_index);

	CStrBuf<32> spray_index_str;
	int temp_index = int(spray_index);
	
	if(temp_index == 0)
	{
		spray_index_str.format("%s", "0");
	}
	else
	{
		spray_index_str.format("%d", temp_index);
	}
	
	/*reader.ReadString(path);
	reader.ReadFloat(length);
	reader.ReadFloat(width);*/

	reader.ReadVector3(pos);
	reader.ReadVector3(normal);

	tempc_ptr(Character) c = gLevel->GetCharacter(uid);
	if(c && !gLevel->spray_set.Get(uid))
	{
		gLevel->spray_set.Add(uid, (ptr_new Client::Spray(spray_index_str, pos, normal)));
		FMOD_VECTOR vel = {0, 0, 0};
		if (c == gLevel->GetPlayer())
			FmodSystem::PlayEvent("bj/fx/2d/sprayer");
		else
			FmodSystem::Play3DEvent("bj/fx/3d/sprayer",(const FMOD_VECTOR &)pos,vel);
	}
}

// parse spray clear
void ChannelConnection::ParseSprayClear(Core::BinaryNetworkReader & reader)
{
	byte uid;
	int pid;

	reader.ReadByte(uid);
	reader.ReadInt(pid);

	tempc_ptr(Character) c = gLevel->GetCharacter(uid);
	if (c)
	{
		gLevel->spray_set.Remove(pid);
	}
}


// notify room host changed
void ChannelConnection::ParseNotifyRoomHostChanged(Core::BinaryNetworkReader & reader)
{
	short room_id;
	int host_id;
	char name[64];
	byte is_vip;
	byte net_bar_level;
	uint character_level; 

	reader.ReadShort(room_id);
	reader.ReadInt(host_id);
	reader.ReadByte(is_vip);
	reader.ReadByte(net_bar_level);
	reader.ReadInt(character_level);
	reader.ReadString(name, sizeof(name));

	switch (state)
	{
	case kInChannel:
		{
			bool ret = false;
			for (uint i = 0; i < room_list.Size(); ++i)
			{
				if (room_list[i] && room_list[i]->id == room_id)
				{
					room_list[i]->host_id = host_id;
					room_list[i]->host_name = name;
					room_list[i]->is_vip = is_vip;
					room_list[i]->net_bar_level = net_bar_level;
					room_list[i]->character_level = character_level;
					ret = true;
					break;
				}
			}

			if (ret)
				OnRoomListChanged();
		}
		break;

	case kInRoom:
	case kInGame:
	case kInBalance:
		{
			room_info.host_id = host_id;
			room_info.host_name = name;

			for (uint i = 0; i < client_list.Size(); ++i)
			{
				if (client_list[i])
				{
					if (client_list[i]->character_id == host_id)
					{
						client_list[i]->is_host = true;

					}
					else
						client_list[i]->is_host = false;
				}
			}

			OnRoomClientListChanged();
		}
		break;
	}
}

// notify room change option
void ChannelConnection::NotifyRoomChangeOption()
{
	uint uid;
	RoomOption option;
	ReadInt(uid);
	ReadRoomOption(*this, option);

	switch (state)
	{
	case kInChannel:
		{
			bool ret = false;
			for (uint i = 0; i < room_list.Size(); ++i)
			{
				if (room_list[i] && room_list[i]->id == uid)
				{
					room_list[i]->option = option;
					ret = true;
					break;
				}
			}

			if (ret)
				OnRoomListChanged();
		}
		break;

	case kInRoom:
	case kInBalance:
		{
			room_info.option = option;
			OnRoomOptionChanged();
		}
		break;
	}
}

// notify room state changed
void ChannelConnection::NotifyRoomStateChanged()
{
	short uid;
	byte room_state;
	ReadShort(uid);
	ReadByte(room_state);

	switch (state)
	{
	case kInChannel:
		{
			bool ret = false;
			for (uint i = 0; i < room_list.Size(); ++i)
			{
				if (room_list[i] && room_list[i]->id == uid)
				{
					room_list[i]->state = room_state;
					ret = true;
					break;
				}
			}

			if (ret)
				OnRoomListChanged();
		}
		break;

	case kInRoom:
	case kInBalance:
		{
			room_info.state = room_state;
		}
		break;
	}
}

// notify room client count changed
void ChannelConnection::NotifyRoomClientCountChanged()
{
	uint uid;
	uint client_count;
	ReadInt(uid);
	ReadInt(client_count);

	bool ret = false;
	for (uint i = 0; i < room_list.Size(); ++i)
	{
		if (room_list[i] && room_list[i]->id == uid)
		{
			room_list[i]->client_count = client_count;
			ret = true;
			break;
		}
	}

	if (ret)
		OnRoomListChanged();
}

// notify room change team
void ChannelConnection::NotifyClientChangeTeam()
{
	uint id;
	uint cid;
	byte team;

	ReadInt(cid);
	ReadInt(id);
	ReadByte(team);

	for (uint i = 0; i < client_list.Size(); ++i)
	{
		ClientInfo* info = client_list[i];
		if (info && info->character_id == cid)
		{
			info->id = id;
			info->team = team;
			break;
		}
	}

	OnRoomClientListChanged();
}

// notify room client ready
void ChannelConnection::NotifyClientReady()
{
	uint cid;
	bool ready;

	ReadInt(cid);
	ReadByte((byte&)ready);

	for (uint i = 0; i < client_list.Size(); ++i)
	{
		ClientInfo* info = client_list[i];
		if (info && info->character_id == cid)
		{
			info->ready = ready;
			break;
		}
	}

	OnRoomClientListChanged();
}

// Notify Client AutoStart
void ChannelConnection::NotifyClientAutoStart()
{
	double time;
	ReadDouble(time);
	OnRoomAutoStart(time);
}

// Notify Client AutoStartCancel
void ChannelConnection::NotifyClientAutoStartCancel()
{
	OnRoomAutoStartCancel();
}

// notify game start
void ChannelConnection::NotifyGameStart()
{
	room_info.state = 2;
}

// notify game start
void ChannelConnection::NotifyGameEnd()
{
	room_info.state = 1;
	tempc_ptr(StateMainGame) state_main = ptr_dynamic_cast<StateMainGame>(gGame->machine.CurrentState());
	if (state_main)
	{
		state_main->ui->CloseChat();
	}
}

// notify game leave
void ChannelConnection::NotifyGameLeave()
{
	OnLeaveGame(false);
}

// notify game client enter 
void ChannelConnection::NotifyGameClientEnter()
{
	uint cid;

	ReadInt(cid);
  LogSystem.WriteLinef(" ChannelConnection::NotifyGameClientEnter() ChannelConnection::NotifyGameClientEnter() ChannelConnection::NotifyGameClientEnter() ChannelConnection::NotifyGameClientEnter()");
	for (uint i = 0; i < client_list.Size(); ++i)
	{
		ClientInfo* info = client_list[i];
		if (info && info->character_id == cid)
		{
			info->in_game = true;
			break;
		}
	}

	OnRoomClientListChanged();
}

// notify game client leave
void ChannelConnection::NotifyGameClientLeave()
{
	uint cid;

	ReadInt(cid);
	LogSystem.WriteLinef("ChannelConnection::NotifyGameClientLeave()ChannelConnection::NotifyGameClientLeave()ChannelConnection::NotifyGameClientLeave()");
	for (uint i = 0; i < client_list.Size(); ++i)
	{
		ClientInfo* info = client_list[i];
		if (info && info->character_id == cid)
		{
			info->in_game = false;
			break;
		}
	}

	OnRoomClientListChanged();
}

void ChannelConnection::ParseBossModeAliveChanged(Core::BinaryNetworkReader & reader)
{
	int num;
	reader.ReadInt(num);

	gLevel->boss_mode_left_count = num;
}

// notify chat
void ChannelConnection::ParseNotifyChat(Core::BinaryNetworkReader & reader)
{
	CStrBuf<character_name_length> channel;
	CStrBuf<character_name_length> name;
	CStrBuf<chat_length> msg;

	reader.ReadString(channel);
	reader.ReadString(name);
	reader.ReadString(msg);

	if (gGame)
	{
		ChatMessage m;
		m.channel = channel;
		m.sender = name;
		m.msg = msg;

		gGame->machine.OnChat(m);
	}
}

// notify room kick client
void ChannelConnection::NotifyClientChangeSlot()
{
	uint character_id;
	byte inroom_id;
	byte team;

	ReadInt(character_id);
	ReadByte(inroom_id);
	ReadByte(team);

	for (uint i = 0; i < client_list.Size(); ++i)
	{
		ClientInfo* info = client_list[i];
		if (info && info->character_id == character_id)
		{
			info->id = inroom_id;
			info->team = team;
			break;
		}
	}

	OnRoomClientListChanged();
}

// notify room change slot status;
void ChannelConnection::NotifyRoomChangeSlotStatus()
{
	byte slot_id;
	int status;

	ReadByte(slot_id);
	ReadInt(status);

	if (slot_id > 0 && slot_id <= room_slots.Size())
	{
		room_slots[slot_id - 1].status = status;
	}

	tempc_ptr(StateLobby) lobby = ptr_dynamic_cast<StateLobby>(gGame->machine.CurrentState());

	if (lobby)
	{
		lobby->OnRoomSlotChanged();
	}
}

// response room preserve slot
void ChannelConnection::ResponseRoomPreserveSlot()
{
	int result;

	ReadInt(result);
}

// response client list
void ChannelConnection::ResponseClientList()
{
	uint total_count;
	uint client_start;
	uint client_count;

	ReadInt(total_count);
	ReadInt(client_start);
	ReadInt(client_count);

	channel_client_list.Resize(client_count);

	for (uint i = 0; i < client_count; i ++)
	{
		ChannelClientInfo & client = channel_client_list[i];

		ReadInt(client.character_id);
		ReadString(client.name);
		ReadString(client.group);
		ReadString(client.icon);
		ReadInt(client.level);
		ReadByte(client.is_vip);
		ReadByte(client.net_bar_level);
		ReadByte(client.business_card);
		ReadByte(client.is_gm);
		
	}
  
	tempc_ptr(StateLobby) lobby = ptr_dynamic_cast<StateLobby>(gGame->machine.CurrentState());

	if (lobby)
	{
		lobby->m_channl_list_total_count = total_count;
		lobby->m_channl_list_start = client_start;
		lobby->OnChannelClientListChanged();
	}
}

// response td data
void ChannelConnection::ResponseTDData()
{
	int result;

	ReadInt(result);
}

// notify room kick client
void ChannelConnection::NotifyRoomKickClient()
{
	uint uid;
	ReadInt(uid);

	tempc_ptr(StateLobby) lobby = ptr_dynamic_cast<StateLobby>(gGame->machine.CurrentState());
	if (lobby && lobby->m_is_fight_team_server)
	{
		return;
	}
	if (uid == character_id)
	{
		gGame->global->SystemMessage(gLang->GetTextW(L"�ǳ��ź�,��������˷���"), "/info");

		if (state == kInBalance)
			OnLeaveBalance();

		tempc_ptr(StateLobby) lobby = ptr_dynamic_cast<StateLobby>(gGame->machine.CurrentState());

		if (lobby)
			lobby->OnKickedInRoom();

	}
}

// on enter channel
void ChannelConnection::OnEnterChannel()
{
	if (state == kConnected || state == kInRoom || state == kInReplay)
	{
		if (state == kConnected)
			gGame->global->SystemMessage(String::Format(gLang->GetTextW(L"����Ƶ����%s"), gGame->address.channel_name), "/info");

		state = kInChannel;

		tempc_ptr(StateLobby) lobby = ptr_dynamic_cast<StateLobby>(gGame->machine.CurrentState());
		
		if (lobby)
		{
			ServerInfo* pInfo = NULL;
			for (int i = 0; i < gGame->lobby_connection->server_list.GetCount(); ++i)
			{
				if (gGame->lobby_connection->server_list[i].id == gGame->address.server_id)
				{
					pInfo = &gGame->lobby_connection->server_list[i];
				}
			}

			lobby->OnEnterChannel();
		}

		if(gGame && gGame->lobby_connection)
			gGame->lobby_connection->m_RememberLobby = lobby;
		else
			PDE_ASSERT(false, "Enter channel without a lobby connection");
	}
// 	RequestRoomList();
}

// on leave channel
void ChannelConnection::OnLeaveChannel()
{
	if (state != kIdle)
	{
		if (state == kInRoom || state == kInGame)
		{
			if(room_info.id>0)
				gGame->global->SystemMessage(String::Format(gLang->GetTextW(L"�뿪���䣺%s"), room_info.option.name), "/info");
		}

		gGame->global->SystemMessage(String::Format(gLang->GetTextW(L"�뿪Ƶ����%s"), gGame->address.channel_name), "/info");

		state = kIdle;
		character_id = 0;
		gGame->address.room_id = 0;
		gGame->address.channel_id = 0;
		gGame->address.channel_name = String::kEmpty;
		room_info = RoomInfo();

		room_list.Clear();

		tempc_ptr(StateLobby) lobby = ptr_dynamic_cast<StateLobby>(gGame->machine.CurrentState());

		if (lobby)
		{
			lobby->OnLeaveChannel();
		}
		else
		{
			gGame->need_leave_channel = true;
		}
	}
}


// on enter room
void ChannelConnection::OnEnterRoom()
{
	if (state == kInChannel || state ==  kInGame || state == kInBalance)
	{
		if (state == kInChannel)
		{
			if(room_info.id>0)
				gGame->global->SystemMessage(String::Format(gLang->GetTextW(L"���뷿�䣺%s"), room_info.option.name), "/info");
		}

		state = kInRoom;

		tempc_ptr(StateLobby) lobby = ptr_dynamic_cast<StateLobby>(gGame->machine.CurrentState());


		
		if (lobby->m_Is_in_invite == true )
		{
			lobby->m_Is_in_invite = false;

			ServerInfo* pInfo = NULL;
			for (int i = 0; i < gGame->lobby_connection->server_list.GetCount(); ++i)
			{
				if (gGame->lobby_connection->server_list[i].id == gGame->address.server_id)
				{
					pInfo = &gGame->lobby_connection->server_list[i];
				}
			}

			if(pInfo && pInfo->servertype == SvrType_Match )///
			{
				gGame->lobby_connection->IntoMatchingTeam(room_info.host_name);
			}
		}
		if (lobby->m_Is_in_invite1 == true )
		{
			lobby->m_Is_in_invite1 = false;

			ServerInfo* pInfo = NULL;
			for (int i = 0; i < gGame->lobby_connection->server_list.GetCount(); ++i)
			{
				if (gGame->lobby_connection->server_list[i].id == gGame->address.server_id)
				{
					pInfo = &gGame->lobby_connection->server_list[i];
				}
			}

			if(pInfo->servertype == SvrType_MatchFighting )///
			{
				gGame->lobby_connection->IntoMatchingTeam(room_info.host_name);
			}
		}
		if (lobby)
		{
			lobby->OnEnterRoom();
		}

		RequestRoomClientList();
	}
}

// on leave room
void ChannelConnection::OnLeaveRoom()
{
	LogSystem.WriteLinef("�뿪�����뿪�����뿪�����뿪�����뿪�����뿪�����뿪�����뿪�����뿪�����뿪�����뿪�����뿪�����뿪����");
	if (state == kInRoom)
	{
		if(room_info.id>0)
			gGame->global->SystemMessage(String::Format(gLang->GetTextW(L"�뿪���䣺%s"), room_info.option.name), "/info");

		LogSystem.WriteLinef("gGame->channel_connection->character_id : %d" , gGame->channel_connection->character_id);
		for(uint i = 0 ; i < client_list.Size() ; i++)
		{
			if(client_list[i]->character_id != gGame->channel_connection->character_id)
			{
				client_list.Remove(client_list[i]);
			}
		}
		//client_list.Clear();

		gGame->address.room_id = 0;
		room_info = RoomInfo();

		tempc_ptr(StateLobby) lobby = ptr_dynamic_cast<StateLobby>(gGame->machine.CurrentState());


		if (lobby)
		{
			lobby->OnLeaveRoom();
		}

		//if(lobby->match_flag)
		//{
		//	ServerInfo* pInfo = NULL;
		//	for (int i = 0; i < gGame->lobby_connection->server_list.GetCount(); ++i)
		//	{
		//		if (gGame->lobby_connection->server_list[i].id == gGame->address.server_id)
		//		{
		//			pInfo = &gGame->lobby_connection->server_list[i];
		//		}
		//	}
		//	if (pInfo)
		//	{
		//		if (pInfo->servertype == SvrType_Match )// SvrType_Match
		//		{
		//			lobby->match_flag = false;
		//			return ;
		//		}

		//	}
		//}
		//lobby->match_flag = false;
		OnEnterChannel();
	}
}

tempc_ptr(RoomInfo) ChannelConnection::GetRoomInfoById( short sId )
{
	for (uint i = 0; i < room_list.Size(); i++)
	{
		tempc_ptr(RoomInfo) room_info = room_list[i];
		if (room_info && room_info->id == sId)
			return room_info;
	}
	return NullPtr;
}

void ChannelConnection::OnRoomListChanged()
{
	tempc_ptr(StateLobby) lobby = ptr_dynamic_cast<StateLobby>(gGame->machine.CurrentState());

	if (lobby)
	{
		Core::Array<sharedc_ptr(RoomInfo)> _vip_info;
		Core::Array<sharedc_ptr(RoomInfo)> _info;
		for (int i = 0; i < (int)room_list.Size(); ++i)
		{
			if (room_list[i]->is_vip)
				_vip_info.PushBack(room_list[i]);
			else
				_info.PushBack(room_list[i]);
		}
		room_list.Clear();
		for (int i = 0; i < (int)_vip_info.Size(); ++i)
		{
			room_list.PushBack(_vip_info[i]);
		}
		for (int i = 0; i < (int)_info.Size(); ++i)
		{
			room_list.PushBack(_info[i]);
		}
		lobby->OnRoomListChanged();
	}
}

// on room client list changed
void ChannelConnection::OnRoomClientListChanged()
{
	tempc_ptr(StateLobby) lobby = ptr_dynamic_cast<StateLobby>(gGame->machine.CurrentState());

	if (lobby)
	{
		lobby->OnRoomClientListChanged();
	}
}

// on room AutoStart
void ChannelConnection::OnRoomAutoStart(double time)
{
	if (state == kInBalance)
	{
		if (gGame->channel_connection)
		{
			gGame->channel_connection->OnRoomAutoStartLeaveBalance();
			gGame->channel_connection->OnLeaveBalance();
		}
	}
	tempc_ptr(StateLobby) lobby = ptr_dynamic_cast<StateLobby>(gGame->machine.CurrentState());
	if (lobby)
	{
		lobby->OnRoomAutoStart(time);
	}
}

// on room AutoStartCancel
void ChannelConnection::OnRoomAutoStartCancel()
{
	tempc_ptr(StateLobby) lobby = ptr_dynamic_cast<StateLobby>(gGame->machine.CurrentState());
	if (lobby)
	{
		lobby->OnRoomAutoStartCancel();
	}
}

void ChannelConnection::OnRoomAutoStartLeaveBalance()
{
	tempc_ptr(StateBalance) balance = ptr_dynamic_cast<StateBalance>(gGame->machine.CurrentState());
	if (balance)
	{
		balance->OnAutoStartLeaveBalance();
	}
}

// on room option changed
void ChannelConnection::OnRoomOptionChanged()
{
	tempc_ptr(StateLobby) lobby = ptr_dynamic_cast<StateLobby>(gGame->machine.CurrentState());

	if (lobby)
	{
		lobby->OnRoomOptionChanged();
		
		LogSystem.WriteLinef("%s, %s, game type :%d", __FILE__, __FUNCTION__, lobby->GetSelfRoomInfo().option.game_type);
		gGame->lobby_connection->RequestChangeMatchGameType(lobby->GetSelfRoomInfo().option.game_type);
	}
	

}

////////////////////////////////////////////////
/// -- game
///////////////////////////////////////////////
// on game enter
void ChannelConnection::OnEnterGame()
{
	if (state == kInRoom)
	{
		state = kInGame;

		player_sync_time = 0;
		player_status = 0;
		player_position = Vector3::kZero;
		player_rotation = Quaternion::kIdentity;

		ammo_sync_time = 0;
		dummy_sync_time = 0;
		game_time = 0;
		game_state = kAuthentication;

		message_set.Clear();
		game_time = 0;

		LogSystem.WriteLinef("action : enter game");
	}
}

// on game leave
void ChannelConnection::OnLeaveGame(bool state_clear, int reason)
{
	if (state == kInGame)
	{	
		gGame->machine.ChangeState(ptr_new StateBalance(state_clear));
		tempc_ptr(Character) player = gLevel->GetPlayer();
		if(state_clear)//  || (player && player->is_vip)
		{
			tempc_ptr(StateBalance) balance = ptr_dynamic_cast<StateBalance>(gGame->machine.CurrentState());
			if(reason == kLeaveGameReasonIdle)
			{
				gGame->global->SystemMessage(gLang->GetTextW(L"�ǳ��ź�,����Ϊ����ʱ��������������"),"/info");	
				if (balance)
					balance->OnKickedIdleInGame();
			}	
		}
		else
		{
			//// ����ʱ�䲻Ҫ��ʾ���ؽ���
			if (state == kInBalance )
			{	
				OnLeaveBalance();
			}

			tempc_ptr(StateLobby) lobby = ptr_dynamic_cast<StateLobby>(gGame->machine.CurrentState());



			if(reason == kLeaveGameReasonIdle)
			{
				gGame->global->SystemMessage(gLang->GetTextW(L"�ǳ��ź�,����Ϊ����ʱ��������������"),"/info");	
				if (lobby)
					lobby->OnKickedIdleInGame();
			}
		}
	
		if (gLevel)
			gLevel->Unload();
	}
}

void ChannelConnection::OnEnterBalance()
{
	if(state == kInGame)
	{
		state = kInBalance;
	}
}

void ChannelConnection::OnLeaveBalance()
{
	if (state == kInBalance)
	{
		PDE_ASSERT(gGame && gGame->lobby_connection && gGame->lobby_connection->m_RememberLobby
			, "leave balance when there's no lobby connection or no remembered state lobby");
		if (gGame && gGame->lobby_connection)
			gGame->lobby_connection->RestoreToStateLobby();
	}
}


// on game end
void ChannelConnection::OnGameEnd()
{
	if (state == kInGame)
	{
		game_state = kGameEnd;
		gLevel->pickup_manager->RemoeAllSupply();
	}
}

// send sync player data
void ChannelConnection::SyncPlayerData()
{
	if (state != kInGame)
		return;

	if (game_state == kGameLeaving)
		return;

	float t = Task::GetTotalTime();
	float delta = t - player_sync_time;

	tempc_ptr(Character) player = gLevel->GetPlayer();

	if (!player)
		return;

	if (player->GetTeam() > 1)
		return;

	if (player->IsDied())
		return;

	ushort status = 0;
	Vector2 move_direction = player->GetDirection();

	if (player->IsJumping())		status |= PS_Jump;
	if (player->GetWalk())			status |= PS_Walk;
	if (player->GetCrouch())		status |= PS_Crouch;
	if (player->IsOnGround())		status |= PS_OnGround;
	if (move_direction.x > 0)		status |= PS_MoveForward;
	if (move_direction.x < 0)		status |= PS_MoveBack;
	if (move_direction.y > 0)		status |= PS_MoveLeft;
	if (move_direction.y < 0)		status |= PS_MoveRight;
	if (player->IsFlying())			status |= PS_Fly;
	if (player->IsBoost())			status |= PS_Boost;

	if (delta >= network_delay || (status != player_status))
	{
		byte flags = 0;

		if (status != player_status)									flags |= PD_Status;
		if (Length(player_position - player->GetPosition()) > 0.005f)	flags |= PD_Position;		
		if (player_rotation != player->GetLookDir())					flags |= PD_Rotation;

		//if (t > player->ping_time)
		//{
		//	if (udp_connection.IsConnected())
		//		player->ping = udp_connection.delay_time * 1000;
		//	else
		//		player->ping = tcp_connection.delay_time * 1000;

		//	player->ping_time = t + 2;
		//	flags |= PD_Ping;
		//}

		player_sync_time = t;
		player_status = status;
		player_position = player->GetPosition();
		player_rotation = player->GetLookDir();
		player_weapon = player->weapon_id;

		if (flags)
		{
			BeginWrite();
			WriteByte(CM_SyncPlayerData);
			WriteByte(Clamp(delta + 0.5f / 255.f, 0, 1) * 255.f);
			WriteByte(flags);

			if (flags & PD_Status)		WriteShort(player_status);
			if (flags & PD_Ping)		WriteShort(player->ping);
			if (flags & PD_Position)	WriteVector3FP(*this, player_position);
			if (flags & PD_Rotation)	WriteCharacterRotation(*this, player_rotation);

			EndWrite();
		}
	}
}

// shoot
void ChannelConnection::Shoot(const Core::Vector3 & position, const Core::Quaternion & direction, const Array<HitMessage> & hit_message, bool do_effect, float hurt_rate)
{
	if (state != kInGame)
		return;

	if (game_state == kGameLeaving)
		return;

	BeginWrite();
	WriteByte(CM_Shoot);
	WriteByte(do_effect);
	WriteFloat(hurt_rate);
	WriteCharacterRotation(*this, direction);
	WriteByte(hit_message.Size());
	for (int i = 0; i < (int)hit_message.Size(); i++)
	{
		WriteByte(hit_message[i].target_type);
		WriteByte(hit_message[i].uid);
		WriteByte(hit_message[i].part);
		WriteFloat(hit_message[i].distance);
		WriteInt(hit_message[i].dummyid);
	}
	EndWrite();
}

void ChannelConnection::GunTowerShoot(uint dummy_id, const HitMessage& hit_message, const GunTowerAttackBaseInfo & tower_attack_info)
{
	if (state != kInGame)
		return;

	if (game_state == kGameLeaving)
		return;

	BeginWrite();
	WriteByte(CM_GunTowerShoot);
	WriteInt(dummy_id);
	WriteByte(hit_message.uid);
	WriteByte(hit_message.part);
	WriteFloat(hit_message.distance);

	WriteInt(tower_attack_info.damage_modifier);
	WriteFloat(tower_attack_info.range_start);
	WriteFloat(tower_attack_info.range_end);
	WriteFloat(tower_attack_info.range_modifier);
	WriteInt(tower_attack_info.base_damage);
	EndWrite();
}

// shoot
void ChannelConnection::FlameShoot(const Core::Vector3 & position, const Core::Quaternion & direction, const Array<HitMessage> & hit_message, bool do_effect, float hurt_rate)
{
	//ENCODE_START

	if (state != kInGame)
		return;

	if (game_state == kGameLeaving)
		return;

	BeginWrite();
	WriteByte(CM_PlayerFlameShoot);
	
	WriteByte(do_effect);
	WriteFloat(hurt_rate);
	WriteCharacterRotation(*this, direction);
	
	WriteByte(hit_message.Size());
	for (int i = 0; i < (int)hit_message.Size(); i++)
	{
		WriteByte(hit_message[i].target_type);
		WriteByte(hit_message[i].uid);
		WriteByte(hit_message[i].part);
		WriteFloat(hit_message[i].distance);
		WriteInt(hit_message[i].dummyid);
	}
	EndWrite();

	//ENCODE_END
}


// kick back
void ChannelConnection::KickBack(const Core::Vector3 & punch)
{
	if (state != kInGame)
		return;

	if (game_state == kGameLeaving)
		return;

	BeginWrite();
	WriteByte(CM_KickBack);
	WriteVector3(punch);
	EndWrite();
}

// grenade throw in
void ChannelConnection::GrenadeThrowIn()
{
	if (state != kInGame)
		return;

	if (game_state == kGameLeaving)
		return;

	BeginWrite();
	WriteByte(CM_GrenadeThrowIn);
	EndWrite();
}
 
// grenade throw stop
void ChannelConnection::GrenadeThrowStop()
{
	if (state != kInGame)
		return;

	if (game_state == kGameLeaving)
		return;

	BeginWrite();
	WriteByte(CM_GrenadeThrowStop);
	EndWrite();
}

// throw grenade
void ChannelConnection::GrenadeThrowOut(byte type, const Core::Vector3 & position, const Core::Vector3 & direction)
{
	//ENCODE_START

	if (state != kInGame)
		return;

	if (game_state == kGameLeaving)
		return;

	BeginWrite();
	WriteByte(CM_GrenadeThrowOut);
	WriteByte(type);
	WriteVector3(position);
	WriteVector3(direction);
	EndWrite();

	//ENCODE_END
}

// grenade explosion
void ChannelConnection::GrenadeHurt(byte uid, by_ptr(Grenade) grenade)
{
	//ENCODE_START

	if (state != kInGame)
		return;

	if (game_state == kGameLeaving)
		return;

	if (grenade && grenade->grenade_info)
	{
		BeginWrite();
		WriteByte(CM_GrenadeHurt);
		WriteByte(uid);
		WriteVector3(grenade->GetPosition());
		WriteWeapon(*this, *grenade->grenade_info);
		EndWrite();
	}

	//ENCODE_END
}

// grenade explosion
void ChannelConnection::GrenadeHurtDummy(int dummy_uid, const Vector3& dummy_position, by_ptr(Grenade) grenade)
{
	if (state != kInGame)
		return;

	if (game_state == kGameLeaving)
		return;

	if (grenade && grenade->grenade_info)
	{
		BeginWrite();
		WriteByte(CM_DummyGrenadeHurt);
		WriteInt(dummy_uid);
		WriteVector3(grenade->GetPosition());
		WriteVector3(dummy_position);
		WriteWeapon(*this, *grenade->grenade_info);
		EndWrite();
	}
}

// poke
void ChannelConnection::Poke(byte type)
{
	if (state != kInGame)
		return;

	if (game_state == kGameLeaving)
		return;

	BeginWrite();
	WriteByte(CM_Poke);
	WriteByte(type);
	EndWrite();
}

// poke
void ChannelConnection::PokeHurt(bool light, byte uid, byte part, bool back)
{
	if (state != kInGame)
		return;

	if (game_state == kGameLeaving)
		return;

	BeginWrite();
	WriteByte(CM_PokeHurt);
	WriteByte(light);
	WriteByte(uid);
	if (uid)
	{
		WriteByte(part);
		WriteByte(back);
	}
	EndWrite();
}

void ChannelConnection::PokeHurtDummy(bool light, int dummy_uid, bool back)
{
	if (state != kInGame)
		return;

	if (game_state == kGameLeaving)
		return;

	BeginWrite();
	WriteByte(CM_DummyPokeHurt);
	WriteByte(light);
	WriteInt(dummy_uid);
	WriteByte(back);
	EndWrite();

}

// game start
void ChannelConnection::ReadyForGame(int career)
{
	if (state != kInGame)
		return;

	if (game_state != kLoading)
		return;

	BeginWrite();
	WriteByte(CM_ReadyForGame);
	WriteInt(career);
	EndWrite();

	game_state = kWaiting;
}

void ChannelConnection::Reload(short count)
{
	if (state != kInGame)
		return;

	if (game_state == kGameLeaving)
		return;

	BeginWrite();
	WriteByte(CM_Reload);
	WriteShort(count);
	EndWrite();
}

// reload ready
void ChannelConnection::ReloadReady(int count)
{
	if (state != kInGame)
		return;

	if (game_state == kGameLeaving)
		return;

	if (count <= 0)
		return;

	BeginWrite();
	WriteByte(CM_ReloadReady);
	WriteInt(count);
	EndWrite();
}

// leave game
void ChannelConnection::LeaveGame(int reason)
{
	if(state == kInReplay)
		OnLeaveReplay();

	if (state != kInGame)
		return;

	if (game_state == kGameLeaving)
		return;

	if(state != kInReplay)
	{
		BeginWrite();
		WriteByte(CM_LeaveGame);
		WriteInt(reason);
		EndWrite();
	}

	
	game_state = kGameLeaving;
}


// select weapon
void ChannelConnection::SelectWeapon(byte weapon_id)
{
	if (state != kInGame)
		return;

	if (game_state == kGameLeaving)
		return;

	tempc_ptr(Character) player = gLevel->GetPlayer();
	if (player)
	{
		BeginWrite();
		WriteByte(CM_SelectWeapon);
		WriteByte(weapon_id);
		EndWrite();
	}

}

// drop weapon
void ChannelConnection::DropWeapon()
{
	if (state != kInGame)
		return;

	if (game_state == kGameLeaving)
		return;

	tempc_ptr(Character) player = gLevel->GetPlayer();
	if (player)
	{
		
		tempc_ptr(WeaponBase) weapon = player->GetWeapon();
		if (weapon) 
		{
			byte type = weapon->GetWeaponType();

			if ((type > kWeaponTypePistol && type < kWeaponTypeKnife) || type == kWeaponTypeBomb)
			{
				BeginWrite();
				WriteByte(CM_DropWeapon);
				WriteByte(player->weapon_id);

				tempc_ptr(GunBase) gun = ptr_dynamic_cast<GunBase>(weapon);
				if (gun)
				{
					WriteInt(gun->ammo_in_clip);
					WriteInt(gun->ammo_count);
				}
				else
				{
					WriteInt(0);
					WriteInt(0);
				}

				WriteVector3(player->GetPosition());
				WriteFloat(0);
				EndWrite();
			}
		}
	}
}


// drop weapon
void ChannelConnection::DropWeaponByID(byte slot)
{
	if (state != kInGame)
		return;

	if (game_state == kGameLeaving)
		return;

	tempc_ptr(Character) player = gLevel->GetPlayer();
	if (player)
	{

		tempc_ptr(WeaponBase) weapon = player->GetWeaponById(slot);
		if (weapon) 
		{
			byte type = weapon->GetWeaponType();

			if ((type > kWeaponTypePistol && type < kWeaponTypeKnife) || type == kWeaponTypeBomb)
			{
				BeginWrite();
				WriteByte(CM_DropWeapon);
				WriteByte(slot);

				tempc_ptr(GunBase) gun = ptr_dynamic_cast<GunBase>(weapon);
				if (gun)
				{
					WriteInt(gun->ammo_in_clip);
					WriteInt(gun->ammo_count);
				}
				else
				{
					WriteInt(0);
					WriteInt(0);
				}

				WriteVector3(player->GetPosition());
				WriteFloat(0);
				EndWrite();
			}
		}
	}
}


// pick up weapon
void ChannelConnection::PickUpWeapon(uint id)
{
	if (state != kInGame)
		return;

	if (game_state == kGameLeaving)
		return;

	BeginWrite();
	WriteByte(CM_PickUpWeapon);
	WriteInt(id);
	EndWrite();
}

// flash bright
void ChannelConnection::FlashBright(float bright_time, float fade_time)
{
	if (state != kInGame)
		return;

	if (game_state == kGameLeaving)
		return;

	BeginWrite();
	WriteByte(CM_FlashBright);
	WriteFloat(bright_time);
	WriteFloat(fade_time);
	EndWrite();
}

// camera fov changed
void ChannelConnection::CameraFovChanged(float fov, float target_fov)
{
	if (state != kInGame)
		return;

	if (game_state == kGameLeaving)
		return;

	BeginWrite();
	WriteByte(CM_CameraFovChanged);
	WriteFloat(fov);
	WriteFloat(target_fov);
	EndWrite();
}

// pick up supply object
void ChannelConnection::PickUpSupplyObject(uint id)
{
	if (state != kInGame)
		return;

	if (game_state == kGameLeaving)
		return;

	BeginWrite();
	WriteByte(CM_PickUpSupplyObject);
	WriteInt(id);
	EndWrite();
}

// pick up supply object new
void ChannelConnection::PickUpSupplyObjectNew(uint id)
{
	if (state != kInGame)
		return;

	if (game_state == kGameLeaving)
		return;

	BeginWrite();
	WriteByte(CM_PickUpSupplyObjectNew);
	WriteInt(id);
	EndWrite();
}
void ChannelConnection::SetClientMessage(bool flag)
{
	if (state != kInGame)
		return;

	if (game_state == kGameLeaving)
		return;

	BeginWrite();
	WriteByte(CM_OpenMessageClient);
	WriteByte(flag ? 1 : 0);
	EndWrite();
}

void ChannelConnection::StartPlantBomb()
{
	if (state != kInGame)
		return;

	if (game_state == kGameLeaving)
		return;
	
	BeginWrite();
	WriteByte(CM_StartPlantBomb);
	EndWrite();
}

void ChannelConnection::CancelPlantBomb()
{
	if (state != kInGame)
		return;

	if (game_state == kGameLeaving)
		return;

	BeginWrite();
	WriteByte(CM_CancelPlantBomb);
	EndWrite();
}


void ChannelConnection::StartDefuseBomb()
{
	if (state != kInGame)
		return;

	if (game_state == kGameLeaving)
		return;
	
	BeginWrite();
	WriteByte(CM_StartDefuseBomb);
	EndWrite();
}

void ChannelConnection::CancelDefuseBomb()
{
	if (state != kInGame)
		return;

	if (game_state == kGameLeaving)
		return;

	BeginWrite();
	WriteByte(CM_CancelDefuseBomb);
	EndWrite();

	gLevel->ClearDefuseBombState();
}

void ChannelConnection::StartSaveDying(byte dying_uid)
{
	if (state != kInGame)
		return;

	if (game_state == kGameLeaving)
		return;

	BeginWrite();
	WriteByte(CM_StartSaveDying);
	WriteByte(dying_uid);
	EndWrite();

}

void ChannelConnection::CancelSaveDying()
{
	if (state != kInGame)
		return;

	if (game_state == kGameLeaving)
		return;

	BeginWrite();
	WriteByte(CM_CancelSaveDying);
	EndWrite();
}

// use item
void ChannelConnection::UseItem_ItemMode(const Core::Array<byte> &uids)
{
	if (state != kInGame)
		return;

	if (game_state == kGameLeaving)
		return;

	BeginWrite();
	WriteByte(CM_UseItem_ItemMode);
	WriteInt((uint)uids.Size());
	for (U32 i = 0; i < uids.Size(); i++)
		WriteByte(uids[i]);
	EndWrite();
}

// zibao
void ChannelConnection::ZiBao_ItemMode(const Core::Array<byte> &uids)
{
	if (state != kInGame)
		return;

	if (game_state == kGameLeaving)
		return;

	BeginWrite();
	WriteByte(CM_ItemMode_ZiBao);
	WriteInt((uint)uids.Size());
	for (U32 i = 0; i < uids.Size(); i++)
		WriteByte(uids[i]);
	EndWrite();
}

// use item
void ChannelConnection::MoonBoss()
{
	if (state != kInGame)
		return;

	if (game_state == kGameLeaving)
		return;

	BeginWrite();
	WriteByte(CM_MoonBoss);
	EndWrite();
}


void ChannelConnection::SaveMap()
{
	if (state != kInGame)
		return;

	if (game_state == kGameLeaving)
		return;

	if(!gLevel) return;

	sharedc_ptr(GunTowerBuilderPlus) w =ptr_dynamic_cast<GunTowerBuilderPlus>(gLevel->GetPlayer()->GetWeapon());
	if(!w) return;

	BeginWrite();
	WriteByte(CM_SAVE_MAP);

	//map info
	int iCnt = 0;

	{
		Core::HashSet<uint, sharedc_ptr(DummyObject)>::Enumerator oIt(gLevel->dummy_object_set);
		while(oIt.MoveNext())
		{
			sharedc_ptr(DummyObject) oDummy =oIt.Value();
			if ((oDummy->sub_type != DummyObject::SUBTYPE_RESOURCE) && w->GetSystemId((int)oDummy->type, oDummy->m_szResKey) != -1)
				iCnt++;
		}
	}

	WriteInt(iCnt);

	Core::HashSet<uint, sharedc_ptr(DummyObject)>::Enumerator oIt(gLevel->dummy_object_set);
	while(oIt.MoveNext())
	{
		sharedc_ptr(DummyObject) oDummy =oIt.Value();

		if (oDummy->sub_type != 4 && w->GetSystemId((int)oDummy->type, oDummy->m_szResKey) != -1)
		{
			//WriteInt((int)oDummy->type);
			WriteInt(w->GetSystemId((int)oDummy->type, oDummy->m_szResKey));
			//WriteString(oDummy->m_szResKey);

			Vector3 pos =oDummy->GetPosition();
			WriteFloat(pos.x);
			WriteFloat(pos.y);
			WriteFloat(pos.z);

			Quaternion rot =oDummy->GetRotation();
			WriteFloat(rot.x);
			WriteFloat(rot.y);
			WriteFloat(rot.z);
			WriteFloat(rot.w);
		}
	}
	EndWrite();

	LogSystem.WriteLinef("SaveMap : %d, %d", iCnt, gLevel->dummy_object_set.Size());
}

// use skill
void ChannelConnection::UseSkill(by_ptr(PlayerSkill) skill)
{
	if (state != kInGame)
		return;

	if (game_state == kGameLeaving)
		return;

	BeginWrite();
	WriteByte(CM_UseSkill);
	WriteByte(skill->type);
	WriteByte(skill->uid);
	WriteFloat(skill->effect_value);
	WriteFloat(skill->effect_time);
	EndWrite();
}

void ChannelConnection::UseSkillSuperMan(byte playid)
{
	if (state != kInGame)
		return;

	if (game_state == kGameLeaving)
		return;

	BeginWrite();
	WriteByte(CM_UseSkillSuperMan);
	WriteByte(playid);
	EndWrite();
}

void ChannelConnection::CancelInvisible(byte playid)
{
	if (state != kInGame)
		return;

	if (game_state == kGameLeaving)
		return;

	BeginWrite();
	WriteByte(CM_CancelInvisible);
	WriteByte(playid);
	EndWrite();
}

void ChannelConnection::UseSmog(byte playid, Core::Vector3 & pos)
{
	if (state != kInGame)
		return;

	if (game_state == kGameLeaving)
		return;

	BeginWrite();
	WriteByte(CM_UseSmog);
	WriteByte(playid);
	WriteVector3(pos);
	EndWrite();
}

void ChannelConnection::SomgAreaCancel(byte playid)
{
	if (state != kInGame)
		return;

	if (game_state == kGameLeaving)
		return;

	BeginWrite();
	WriteByte(CM_SomgAreaCancel);
	WriteByte(playid);
	EndWrite();
}

void ChannelConnection::UseSkillSuperManSuccess()
{
	
}

// change pack
void ChannelConnection::ChangePack(byte id)
{
	if (state != kInGame)
		return;

	if (game_state == kGameLeaving)
		return;

	BeginWrite();
	WriteByte(CM_ChangePack);
	WriteByte(id);
	EndWrite();
}

// self hurt
void ChannelConnection::SelfHurt(float speed)
{
	if (state != kInGame)
		return;

	if (game_state == kGameLeaving)
		return;

	if (!gLevel->GetPlayer()->IsDied())
	{
		BeginWrite();
		WriteByte(CM_Hurt);
		WriteFloat(speed);
		EndWrite();
	}
}

// kick client request
void ChannelConnection::KickClientRequest(byte uid, byte reason)
{
	if (state != kInGame)
		return;

	if (game_state == kGameLeaving)
		return;

	BeginWrite();
	WriteByte(CM_KickClientStart);
	WriteByte(uid);
	WriteByte(reason);
	EndWrite();
}

// kick client vote
void ChannelConnection::KickClientVote(byte result)
{
	if (state != kInGame)
		return;

	if (game_state == kGameLeaving)
		return;

	BeginWrite();
	WriteByte(CM_KickClientVote);
	WriteByte(result);
	EndWrite();
}

// suicide
void ChannelConnection::Suicide()
{
	if (state != kInGame)
		return;

	if (game_state == kGameLeaving)
		return;

	BeginWrite();
	WriteByte(CM_Suicide);
	EndWrite();
}


// radio report
void ChannelConnection::RadioReport(int radio_id, int radio_item, const Core::String & avarname)
{
	if (state != kInGame)
		return;

	if (game_state == kGameLeaving)
		return;

	BeginWrite();
	WriteByte(CM_RadioReport);
	WriteInt(radio_id);
	WriteInt(radio_item);
	WriteString(avarname);
	EndWrite();
}

// spawn confirm
void ChannelConnection::SpawnConfirm()
{
	if (state != kInGame)
		return;

	if (game_state == kGameLeaving)
		return;

	BeginWrite();
	WriteByte(CM_SpawnConfirm);
	EndWrite();
}

// action on changed
void ChannelConnection::ActionOn(int action_type, bool is_on)
{
	if (state != kInGame)
		return;

	if (game_state == kGameLeaving)
		return;

	BeginWrite();
	WriteByte(CM_ActionOn);
	WriteInt(action_type);
	WriteByte(is_on);
	EndWrite();
}

// HornSystemMessage
void ChannelConnection::HornSystemMessage(int type, byte data)
{
	switch (type)
	{
	case kHornHoldPointLeft60sMessage:
		{
			if (gLevel->GetPlayer()->GetTeam() == data)
			{
				FmodSystem::PlayEvent("bj/event/occupy_countdown");
				Core::String hornstr = Core::String::Format(gLang->GetTextW(L"�ҷ�ռ��ݵ㣬��ʣ60�룬���Ͱ�"));
				gLevel->AddHorn(hornstr);
			}
			else if(data == 0 || data == 1)
			{
				FmodSystem::PlayEvent("bj/event/occupy_countdown_enemy");
				Core::String hornstr = Core::String::Format(gLang->GetTextW(L"�Է�ռ��ݵ㣬��ʣ60�룬�ٲ��Ͼ�ȫ����"));
				gLevel->AddHorn(hornstr);
			}
		}
		break;
	case kHornHoldPointSuccessMessage:
		{
			if (gLevel->GetPlayer()->GetTeam() == data)
			{
				FmodSystem::PlayEvent("bj/event/occupy_complete");
				Core::String hornstr = Core::String::Format(gLang->GetTextW(L"�ҷ��Ѿ�ռ��ݵ�"));
				gLevel->AddHorn(hornstr);
			}
			else if(data == 0 || data == 1)
			{
				FmodSystem::PlayEvent("bj/event/occupied");
				Core::String hornstr = Core::String::Format(gLang->GetTextW(L"�з��Ѿ�ռ��ݵ�"));
				gLevel->AddHorn(hornstr);
			}
		}
		break;
	case kHornKillMaster:
		{
		}
		break;
	case kHornPushVehicleStartMessage:
		{
			if (gLevel->GetPlayer()->GetTeam() == data)
			{
				Core::String hornstr = Core::String::Format(gLang->GetTextW(L"�ҷ������䳵�Ѿ�˳������"));
				FmodSystem::PlayEvent("bj/event/vehicle_start");
				gLevel->AddHorn(hornstr);
			}
			else if(data == 0 || data == 1)
			{
				Core::String hornstr = Core::String::Format(gLang->GetTextW(L"�з������䳵�Ѿ�˳������"));
				FmodSystem::PlayEvent("bj/event/enemy_vehicle_start");
				gLevel->AddHorn(hornstr);
			}
		}
		break;
	
	case kHornPushVehicleHalfMessage:
		{
			if (gLevel->GetPlayer()->GetTeam() == data)
			{
				Core::String hornstr = Core::String::Format(gLang->GetTextW(L"�ҷ����䳵�г̹���"));
				FmodSystem::PlayEvent("bj/event/vehicle_half");
				gLevel->AddHorn(hornstr);
			}
			else if(data == 0 || data == 1)
			{
				Core::String hornstr = Core::String::Format(gLang->GetTextW(L"�з����䳵�г̹���"));
				FmodSystem::PlayEvent("bj/event/enemy_vehicle_half");
				gLevel->AddHorn(hornstr);
			}
		}
		break;
	case kHornPushVehicleAlmostSuccessMessage:
		{
			if (gLevel->GetPlayer()->GetTeam() == data)
			{
				Core::String hornstr = Core::String::Format(gLang->GetTextW(L"�ҷ������䳵��Ҫ����Ŀ�ĵأ�"));
				FmodSystem::PlayEvent("bj/event/vehicle_arrival");
				gLevel->AddHorn(hornstr);
			}
			else if(data == 0 || data == 1)
			{
				Core::String hornstr = Core::String::Format(gLang->GetTextW(L"�з������䳵��Ҫ����Ŀ�ĵأ�"));
				FmodSystem::PlayEvent("bj/event/enemy_vehicle_arrival");
				gLevel->AddHorn(hornstr);
			}
		}
		break;
	case kHornTriggerSnareMessage:
		{
			if (gLevel->GetPlayer()->GetTeam() == data)
			{
				Core::String hornstr = Core::String::Format(gLang->GetTextW(L"�ҷ����䳵�г̹���"));
				FmodSystem::PlayEvent("bj/event/enemy_vehicle_start");
				gLevel->AddHorn(hornstr);
			}
		}
		break;
	default:
		break;
	}
}

// parse Authentication
void ChannelConnection::ParseAuthentication(Core::BinaryNetworkReader & reader)
{
	sharedc_ptr(StateLobby) lobby = ptr_dynamic_cast<StateLobby>(gGame->machine.CurrentState());
	gGame->machine.ChangeState(NullPtr);

	char buff[256];

	reader.ReadString(buff, sizeof(buff));
	reader.ReadByte(gLevel->use_self_weapon);
	reader.ReadByte(gLevel->game_type);
	reader.ReadInt(gLevel->rule_value);

	ReadRoomOption(reader, gLevel->room_option);

	switch (gLevel->game_type)
	{
	case RoomOption::kHoldPoint:
		{
			int count;
			Level::HoldPointInfo hold_point;
			
			gLevel->hold_points.Clear();

			reader.ReadInt(count);
			for (int i = 0; i < count; i++)
			{
				reader.ReadByte(hold_point.owner_team);
				reader.ReadByte(hold_point.snatch_team);
				reader.ReadFloat(hold_point.snatching_timer);

				reader.ReadVector3(hold_point.aabb.Min);
				reader.ReadVector3(hold_point.aabb.Max);

				gLevel->hold_points.PushBack(hold_point);
			}

			reader.ReadFloat(gLevel->team_timer[0]);
			reader.ReadFloat(gLevel->team_timer[1]);
			reader.ReadByte(gLevel->cur_holdpoint_diffnum);

			if (0 == gLevel->hold_points[0].owner_team)
				gLevel->hold_point_fPersert_red = gLevel->hold_points[0].snatching_timer;
			else
				gLevel->hold_point_fPersert_red = 0.f;

			if (1 == gLevel->hold_points[0].owner_team)
				gLevel->hold_point_fPersert_blue = gLevel->hold_points[0].snatching_timer;
			else
				gLevel->hold_point_fPersert_blue = 0.f;
		}
		break;
	case RoomOption::kBombMode:
		{
			int count;

			gLevel->bomb_plant_aabb.Clear();

			reader.ReadInt(count);

			AxisAlignedBox aabb;

			for (int i = 0; i < count; i++)
			{
				reader.ReadVector3(aabb.Min);
				reader.ReadVector3(aabb.Max);

				gLevel->bomb_plant_aabb.PushBack(aabb);
#if DEBUG_INFO
				Vector3 points[4];
				int array[24] = 
				{
					0,1,3,2,
					0,4,6,2,
					4,5,7,6,
					1,5,7,3,
					0,1,5,4,
					2,3,7,6
				};

				for (uint i = 0;i < 6; i++)
				{
					for (uint j = 0; j < 4; j++)
					{
						AxisAlignedBox::Corner c = AxisAlignedBox::Corner(array[i * 4 + j]);
						points[j] = aabb.GetCornerPos(c);
					}
					DebugPrimitiveRect rect;
					rect.CreateVertice(points,4);

					gLevel->debug_check_zone_rect.Add(rect);
				}
#endif
			}

		}
		break;
	case RoomOption::kZombieMode:
		{
			
		}
		break;
	case RoomOption::kPushVehicle:
	case RoomOption::kNovice:
		{
			
		}
		break;
	case RoomOption::kTeamDeathMatch:
		{

		}
		break;
	case RoomOption::kBoss:
		{

		}
		break;
	case RoomOption::kKnifeMode:
		{
			
		}
		break;
	case RoomOption::KMoonMode:
		{

		}
		break;
	case RoomOption::kAdvenceMode:
		{

		}
		break;
	case RoomOption::kSurvivalMode:
		{

		}
		break;
	case RoomOption::kMatchingMode:
		{

		}
		break;
	case RoomOption::kStreetBoyMode:
		{

		}
		break;
	}

	// preload weapon
	int size;
	reader.ReadInt(size);
	gLevel->level_weapon_set.Resize(size);
	for (int i = 0; i < size; i++)
		gLevel->level_weapon_set[i] = ReadWeapon(reader);

	byte uid;
	reader.ReadByte(uid);
	reader.ReadFloat(network_delay);

	room_info.option.map_name = buff;

	round_win_team = -1;
	game_win_team = -1;

	if (lobby)
	{
		lobby->OnGameStart(uid);	
	}
}


// parse character info
void ChannelConnection::ParseCharacterInfo(Core::BinaryNetworkReader & reader)
{ 
	byte uid;
	byte team;
	sharedc_ptr(BaseCharacterInfo) base_info = ptr_new BaseCharacterInfo;
	sharedc_ptr(CharacterInfo) character_info = ptr_new CharacterInfo;

	reader.ReadByte(uid);
	reader.ReadByte(team);
	ReadCharacterInfoHead(reader, *base_info);
	if (RoomOption::kTDMode == gLevel->game_type)
		ReadBagInfo(reader, base_info->bag);
	ReadCharacterInfo(reader, *character_info);

	int current_career = character_info->career_id;

	tempc_ptr(Character) player = gLevel->GetPlayer();

	if (!player)
		return;
  
	// preload animation
	if (uid == player->uid)
	{
		player->control_uid = player->uid;
		player->SetPosition(Vector3(-10000, -10000, -10000));
		player->SetTeam(team);
		player->basecharacter_info = base_info;
		player->SetCareer(current_career, character_info);

		for (uint i = 0; i < character_info->pack_set.Size(); i++)
		{
			// preload animation
			player->PreloadPack(character_info->pack_set[i]);

			// preload weapon mesh
			for (uint j = 0; j < character_info->pack_set[i].weapon_set.Size(); j++)
			{
				gLevel->character_manager->AddPreloadWeapon(character_info->pack_set[i].weapon_set[j]);
			}
		}
		gLevel->character_manager->AddPreloadMesh(character_info);

		if (team < 2)
		{
			// level weapon set
			for (uint i = 0; i < gLevel->level_weapon_set.Size(); i++)
			{
				player->PreloadWeapon(gLevel->level_weapon_set[i]);
			}
		}

		player->SetCareer(current_career, NullPtr);
		player->weapon_id = -1;
		player->ping = 0;
		player->current_career = 0;
	}
	else
	{	
		sharedc_ptr(Character) chara = ptr_new Character;
		chara->uid = uid;
		chara->SetPosition(Vector3(-10000, -10000, -10000));
		chara->SetTeam(team);
		chara->basecharacter_info = base_info;
		chara->SetCareer(current_career, character_info);

		for (uint i = 0; i < character_info->pack_set.Size(); i++)
		{
			//chara->InitializeWeapon(character_info->pack_set[i]);

			// preload animation
			chara->PreloadPack(character_info->pack_set[i]);
		}
		gLevel->character_manager->AddPreloadMesh(character_info);

		// level weapon set
		for (uint i = 0; i < gLevel->level_weapon_set.Size(); i++)
		{
			chara->PreloadWeapon(gLevel->level_weapon_set[i]);
		}

		chara->SetCareer(current_career, NullPtr);
		chara->weapon_id = -1;
		chara->current_career = 0;

		gLevel->AddCharacter(chara);
	}

	tempc_ptr(StateMainGame) state_main = ptr_dynamic_cast<StateMainGame>(gGame->machine.CurrentState());
	if(state_main && state_main->ui)
	{
		state_main->ui->InitPersonUI(gLevel->GetCharacter(uid));
	}
}

// parse sync game
void ChannelConnection::ParseInitialize(Core::BinaryNetworkReader & reader)
{
	//VMProtectBegin("ParseInitialize");
	//ENCODE_START

	gGame->scores->Clear();

	tempc_ptr(Character) player = gLevel->GetPlayer();
	byte team;
	byte uid;
	byte game_type;
	byte is_vip;
	byte business_card;
	byte is_gm;
	Core::String head_icon;
	int	 level;
	float t;
	Vector3 position;
	byte current_king_uid[2];
	int kick_count;
	float zombie_step_time;

	byte bomb_planted = 0;

	reader.ReadByte(uid);
	reader.ReadByte(team);
	reader.ReadByte(is_vip);
	reader.ReadByte(business_card);
	reader.ReadByte(is_gm);
	reader.ReadString(head_icon);
	reader.ReadInt(level);
	reader.ReadInt(gGame->scores->team_kills[0]);
	reader.ReadInt(gGame->scores->team_kills[1]);
	reader.ReadInt(gGame->scores->team_round[0]);
	reader.ReadInt(gGame->scores->team_round[1]);
	reader.ReadByte(gGame->scores->score_type);
	reader.ReadInt(gGame->round_time);
	reader.ReadByte((Byte&)gLevel->team_hurt);
	reader.ReadInt(kick_count);
	reader.ReadByte(game_type);

	gLevel->kick_count = kick_count;

	//VMProtectEnd();

	// td mode
	int max_reshp;
	int cur_reshp;

	switch (game_type)
	{
	case RoomOption::kTeam:
	case RoomOption::kEditMode:
	case RoomOption::kAdvenceMode:
	case RoomOption::kSurvivalMode:
	
		break;
	case RoomOption::kTDMode:
		{
			reader.ReadInt(max_reshp);
			reader.ReadInt(cur_reshp);

			tempc_ptr(StateMainGame) state_main = ptr_dynamic_cast<StateMainGame>(gGame->machine.CurrentState());
			if (state_main && state_main->ui)
			{
				state_main->ui->m_cur_reshp = cur_reshp;
				state_main->ui->m_max_reshp = max_reshp;
			}

			LogSystem.WriteLinef("kTDMode : %d %d", max_reshp, cur_reshp);
		}
		break;
	case RoomOption::kBombMode:
		{
			reader.ReadByte(bomb_planted);
			if(bomb_planted == 1)
			{
				reader.ReadVector3(position);
				reader.ReadFloat(t);
			}
		}
		break;
	case RoomOption::kStreetBoyMode:
		{
			reader.ReadByte(current_king_uid[0]);
			reader.ReadByte(current_king_uid[1]);
		}
		break;
	case RoomOption::kZombieMode:
		{
			reader.ReadFloat(zombie_step_time);
		}
		break;
	case RoomOption::kBossMode2:
		{
			reader.ReadInt(gLevel->boss2_career_id);
			reader.ReadInt(gLevel->boss2_sp_career_id[0]);
			reader.ReadInt(gLevel->boss2_sp_career_id[1]);
			reader.ReadInt(gLevel->boss2_sp_career_id[2]);
			reader.ReadInt(gLevel->boss2_sp_career_id[3]);
		}
		break;
	case RoomOption::kItemMode:
	case RoomOption::KMoonMode:
		{
			reader.ReadInt(gLevel->item_career_id);
		}
		break;
	}

	player->uid = uid;
	player->SetTeam(team);
	player->is_vip = is_vip;
	player->business_card = business_card;
	player->is_gm = is_gm;
	player->level = level;
	player->head_icon = head_icon;

	if (team < 2)
	{
		gPhysxScene->setGroupCollisionFlag(PhysxSystem::kPlayer, PhysxSystem::kGroupStart + team, false);
		gPhysxScene->setGroupCollisionFlag(PhysxSystem::kPlayer, PhysxSystem::kGroupEnd - team, true);
		gPhysxScene->setGroupCollisionFlag(PhysxSystem::kPlayer, PhysxSystem::kGroupProjectStart + team, false);
		gPhysxScene->setGroupCollisionFlag(PhysxSystem::kPlayer, PhysxSystem::kGroupProjectEnd - team, true);
		player->SetPhysxGroup(PhysxSystem::kPlayer);
	}

	do
	{
		reader.ReadByte(uid);

		if (uid)
		{
			char name[64] = { 0 };
			ushort status;
			byte team;
			byte weapon;
			ushort ping;
			int health;
			int max_hp;
			int ex_hp;
			int armor;
			short num_kill;
			short num_die;
			short num_assist;
			int score;
			Core::Vector3 position;
			Core::Quaternion rotation;
			byte playing;
			byte connected;
			byte alive;
			byte has_bomb;
			
			byte c_is_vip;
			byte c_business_card;
			int  c_level;
			Core::String c_head_icon;

			sharedc_ptr(CharacterInfo) character_info = ptr_new CharacterInfo();

			reader.ReadString(name, sizeof(name));
			reader.ReadShort(status);
			reader.ReadByte(team);
			reader.ReadByte(c_is_vip);
			reader.ReadByte(c_business_card);
			reader.ReadString(c_head_icon);
			reader.ReadInt(c_level);

			reader.ReadByte(weapon);
			reader.ReadShort(ping);
			reader.ReadInt(health);
			reader.ReadInt(max_hp);
			reader.ReadInt(ex_hp);
			reader.ReadInt(armor);
			reader.ReadShort(num_kill);
			reader.ReadShort(num_die);
			reader.ReadShort(num_assist);
			reader.ReadInt(score);
			reader.ReadVector3(position);
			reader.ReadQuaternion(rotation);
			reader.ReadByte(playing);
			reader.ReadByte(connected);
			reader.ReadByte(alive);
			ReadCharacterInfo(reader, *character_info);
			reader.ReadByte(has_bomb);
			
			int career = character_info->career_id;

			switch (game_type)
			{
			case RoomOption::kTeam:
				{
				}
				break;
			}
			
			tempc_ptr(Character) chara = ptr_dynamic_cast<Character>(gLevel->GetCharacter(uid));
			if (chara)
			{
				chara->uid = uid;
				chara->SetTeam(team);
				chara->is_vip = c_is_vip;
				chara->business_card = c_business_card;
				chara->is_gm = is_gm;
				chara->level = c_level;
				chara->head_icon = c_head_icon;

				chara->num_died = num_die;
				chara->num_killed = num_kill;
				chara->num_assist = num_assist;
				chara->all_score = score;
				chara->ping = ping;
				chara->ping_time = 0;
				chara->weapon_id = -1;
				chara->max_hp = max_hp;
				chara->ex_hp = ex_hp;
				
				chara->current_career = career;

				chara->ready = true;
				chara->connected = !!connected;
				chara->playing = !!playing;
				chara->SetPhysxGroup(team + PhysxSystem::kGroupStart);

				if (alive)
				{
					chara->SetCareer(career, character_info);

					//chara->InitializeWeapon(chara->GetCurCharinfo()->pack_set[0]);
					chara->Rebirth(health, armor, position, rotation);

					chara->SelectWeapon(weapon, true);
				}
			}
		}
	}
	while (uid);

	do 
	{
		reader.ReadByte(uid);

		if (uid)
		{
			char name[64] = { 0 };
			ushort status;
			byte team;
			byte weapon;
			ushort ping;
			int health;
			int max_hp;
			int ex_hp;
			int armor;
			short num_kill;
			short num_die;
			short num_assist;
			int score;
			Core::Vector3 position;
			Core::Quaternion rotation;
			byte playing;
			byte connected;
			byte alive;
			byte has_bomb;

			byte c_is_vip;
			byte c_business_card;
			int  c_level;
			Core::String c_head_icon;
			byte c_is_gm;

			sharedc_ptr(CharacterInfo) character_info = ptr_new CharacterInfo();

			reader.ReadString(name, sizeof(name));
			reader.ReadShort(status);
			reader.ReadByte(team);
			reader.ReadByte(c_is_vip);
			reader.ReadByte(c_business_card);
			reader.ReadByte(c_is_gm);
			reader.ReadString(c_head_icon);
			reader.ReadInt(c_level);

			reader.ReadByte(weapon);
			reader.ReadShort(ping);
			reader.ReadInt(health);
			reader.ReadInt(max_hp);
			reader.ReadInt(ex_hp);
			reader.ReadInt(armor);
			reader.ReadShort(num_kill);
			reader.ReadShort(num_die);
			reader.ReadShort(num_assist);
			reader.ReadInt(score);
			reader.ReadVector3(position);
			reader.ReadQuaternion(rotation);
			reader.ReadByte(playing);
			reader.ReadByte(connected);
			reader.ReadByte(alive);
			ReadCharacterInfo(reader, *character_info);
			reader.ReadByte(has_bomb);

			int career = character_info->career_id;

			switch (game_type)
			{
			case RoomOption::kTeam:
				{
				}
				break;
			}

			tempc_ptr(Character) chara = ptr_dynamic_cast<Character>(gLevel->GetCharacter(uid));
			if (chara)
			{
				chara->uid = uid;
				chara->SetTeam(team);
				chara->is_vip = c_is_vip;
				chara->business_card = c_business_card;
				chara->is_gm = is_gm;
				chara->level = c_level;
				chara->head_icon = c_head_icon;

				chara->num_died = num_die;
				chara->num_killed = num_kill;
				chara->num_assist = num_assist;
				chara->all_score = score;
				chara->ping = ping;
				chara->ping_time = 0;
				chara->weapon_id = -1;
				chara->max_hp = max_hp;
				chara->ex_hp = ex_hp;

				chara->current_career = career;

				chara->ready = true;
				chara->connected = !!connected;
				chara->playing = !!playing;
				chara->SetPhysxGroup(team + PhysxSystem::kGroupStart);

				if (alive)
				{
					chara->SetCareer(career, character_info);

					//chara->InitializeWeapon(chara->GetCurCharinfo()->pack_set[0]);
					chara->Rebirth(health, armor, position, rotation);

					chara->SelectWeapon(weapon, true);
				}
			}
		}
	}
	while (uid);

	gLevel->SetCameraMode(Camera::kViewMode);

	gLevel->current_street_king_uid[0] = current_king_uid[0];
	gLevel->current_street_king_uid[1] = current_king_uid[1];

	if(bomb_planted == 1 && gLevel->game_type == RoomOption::kBombMode)
	{
		const Core::Array<sharedc_ptr(Character)>& characters = gLevel->GetCharacters();

		for (uint i = 0; i < characters.Size(); i++)
		{
			tempc_ptr(Character) c = characters[i];
			if(c && c->GetTeam() == 1)
			{
				tempc_ptr(Bomb) bomb = c->GetBomb(true);
				if(bomb)
				{
					bomb->Plant(position);
					gLevel->bomb_on_ground = true;

					gLevel->bomb_explode_timer = t;

					gLevel->bomb_on_ground_position = bomb->GetPosition();
					gLevel->bomb_on_ground_rotation = bomb->GetRotation();
					
					break;
				}
			}
		}
	}

	//ENCODE_END
}

// parse sync player data
void ChannelConnection::ParseSyncCharacterData(Core::BinaryNetworkReader & reader)
{
	//VMProtectBegin("ParseSyncCharacterData");

	byte uid;
	byte flags;
	byte time;

	reader.ReadByte(uid);
	reader.ReadByte(time);
	reader.ReadByte(flags);

	tempc_ptr(Character) character = ptr_dynamic_cast<Character>(gLevel->GetCharacter(uid));

	if (character)
	{
		ushort status = 0;
		ushort ping = 0;
		Vector3 position;
		Quaternion rotation;

		if (flags & PD_Status)		reader.ReadShort(status);
		if (flags & PD_Ping)		reader.ReadShort(ping); 
		if (flags & PD_Position)	ReadVector3FP(reader, position);
		if (flags & PD_Rotation)	ReadCharacterRotation(reader, rotation);

		if (flags & PD_Ping)
			character->ping = ping;

		if (!character->sync_data.Empty())
		{
			if(character != gLevel->GetPlayer())
			{
				CharacterSyncData sync = character->sync_data.Back();

				sync.time += (float)time / 255.f;

				if (flags & PD_Position)	sync.position = position;
				if (flags & PD_Rotation)	sync.rotation = rotation;
				if (flags & PD_Status)
				{
					Vector2 move_direction(0, 0);
					if (status & PS_MoveForward)	move_direction.x += 1;
					if (status & PS_MoveBack)		move_direction.x -= 1;
					if (status & PS_MoveLeft)		move_direction.y += 1;
					if (status & PS_MoveRight)		move_direction.y -= 1;

					sync.crouch = (status & PS_Crouch) != 0;
					sync.walk = (status & PS_Walk) != 0;
					sync.jump = (status & PS_Jump) != 0;
					sync.onground = (status & PS_OnGround) != 0;
					sync.flying = (status & PS_Fly) != 0;
					sync.boost = (status & PS_Boost) != 0;
					sync.move = move_direction;
				}

				character->sync_data.PushBack(sync);
			}
			else if(state == kInReplay)
			{
				CharacterSyncData sync = character->sync_data.Back();

				sync.time += (float)time / 255.f;

				if (flags & PD_Position)	sync.position = position;
				if (flags & PD_Rotation)	sync.rotation = rotation;
				if (flags & PD_Status)
				{
					Vector2 move_direction(0, 0);
					if (status & PS_MoveForward)	move_direction.x += 1;
					if (status & PS_MoveBack)		move_direction.x -= 1;
					if (status & PS_MoveLeft)		move_direction.y += 1;
					if (status & PS_MoveRight)		move_direction.y -= 1;

					sync.crouch = (status & PS_Crouch) != 0;
					sync.walk = (status & PS_Walk) != 0;
					sync.jump = (status & PS_Jump) != 0;
					sync.onground = (status & PS_OnGround) != 0;
					sync.flying = (status & PS_Fly) != 0;
					sync.boost = (status & PS_Boost) != 0;
					sync.move = move_direction;
				}

				character->sync_data.PushBack(sync);
			}
			
		}
	}
	//VMProtectEnd();
	//ENCODE_END
}

void ChannelConnection::ParsePlayerJoin(Core::BinaryNetworkReader & reader)
{
	//ENCODE_START

	//VMProtectBegin("ParsePlayerJoin");

	byte uid;
	char str[256] = {0};
	byte team;
	byte is_vip;
	byte business_card;
	byte is_gm;
	Core::String head_icon;
	int level;

	reader.ReadByte(uid);
	reader.ReadByte(team);
	reader.ReadByte(is_vip);
	reader.ReadByte(business_card);
	reader.ReadByte(is_gm);
	reader.ReadString(head_icon);
	reader.ReadInt(level);

	tempc_ptr(Character) character = ptr_dynamic_cast<Character>(gLevel->GetCharacter(uid));
	if (character)
	{
		character->SetTeam(team);
		character->is_vip = is_vip;
		character->business_card = business_card;
		character->is_gm = is_gm;
		character->level = level;
		character->head_icon = head_icon;
		character->playing = false;
		character->connected = true;

		if (team < 2)
			character->SetPhysxGroup(team + PhysxSystem::kGroupStart);

		gGame->global->SystemMessage(String::Format(gLang->GetTextW(L"%s ������Ϸ"), character->GetName().Str()), "/info");
	}
	//VMProtectEnd();
	//ENCODE_END
}

void ChannelConnection::ParsePlayerLeave(Core::BinaryNetworkReader & reader)
{
	//ENCODE_START

	byte uid;
	reader.ReadByte(uid);

	tempc_ptr(Character) character = ptr_dynamic_cast<Character>(gLevel->GetCharacter(uid));
	if (character)
	{
		if (character->connected)
		{
			if (gLevel->tmpplayer == character)
			{
				gLevel->targetenemy_time = 0.f;
				gLevel->tmpplayer = NullPtr;
			}
			if ((gLevel->kicked_uid == uid || gLevel->sponsor_uid == uid) && gLevel->kick_select_open)
			{
				gLevel->sponsor_uid = -1;
				gLevel->kick_select_open = false;
				gLevel->kick_wait_time = 0.f;
				gLevel->kick_select_id = 0;
				gLevel->kicked_uid = -1;
			}
			gGame->global->SystemMessage(String::Format(gLang->GetTextW(L"%s �뿪��Ϸ"), character->GetName().Str()), "/info");
		}
	}
	gLevel->spray_set.Remove(uid);
	gLevel->RemoveCharacter(uid);

	//ENCODE_END
}

void ChannelConnection::ParseSpawn(Core::BinaryNetworkReader & reader)
{
	//ENCODE_START
	
	byte uid;
	int hp;
	int armor;
	byte start_point = 0;
	float invincible_time = 0;
	Core::Vector3 position(0, 0, 0);
	float angle;
	int max_hp;
	int ex_hp;
	int s_rand;
	byte has_bomb = 0;
	int die_counter =0;
	int die_buff_counter =0;

	//byte pack_index;
	sharedc_ptr(CharacterInfo) character_info = ptr_new CharacterInfo();

	reader.ReadByte(uid);
	reader.ReadInt(hp);
	reader.ReadInt(max_hp);
	reader.ReadInt(ex_hp);
	reader.ReadInt(armor);
	reader.ReadInt(s_rand);
	reader.ReadVector3(position);
	reader.ReadFloat(angle);
	ReadCharacterInfo(reader, *character_info);
	reader.ReadByte(has_bomb);
	reader.ReadInt(die_counter);
	reader.ReadInt(die_buff_counter);

	int career = character_info->career_id;

	tempc_ptr(Character) c = gLevel->GetCharacter(uid);

	if (c)
	{
		Character *pPlayer = gLevel->GetPlayer();
		if(c == pPlayer)
		{
			pPlayer->relife_flag = false;
			pPlayer->relife_time = 0.0f;
			pPlayer->select_player_flag = false;
			pPlayer->SetViewMode(Character::kFirstPerson);
			game_state = kAlive;
			pPlayer->SetCrouch(false);
			SpawnConfirm();
			gLevel->SetCameraMode(Camera::kCharacterControl);
			gGame->render->render_pipeline->m_bSaveScreen = false;
			gGame->render->render_pipeline->m_bUseSavedScreen = false;
	
			tempc_ptr(SniperGun) gun = ptr_dynamic_cast<SniperGun>(pPlayer->GetWeapon());
			if (gun)
				gun->SetSight(0);
			// level weapon set
			//for (int i = 0; i < (int)gLevel->level_weapon_set.Size(); i++)
			//{
			//	c->PreloadWeapon(gLevel->level_weapon_set[i]);
			//}
			if(career != 130)
			{
				if ( (RoomOption::kTDMode == gLevel->game_type && !pPlayer->IsCarrierMode() ) || 
					RoomOption::kBoss == gLevel->game_type || RoomOption::kBossPVE == gLevel->game_type)
				{
					c->SetDieBuffer(die_counter >= 3);
					c->SetDieBufferCounter(die_buff_counter);
				}
			}
		}

		c->isghost = false;

		if ( (gLevel->game_type == RoomOption::kItemMode && career == gLevel->item_career_id) || (gLevel->game_type == RoomOption::KMoonMode && career == gLevel->item_career_id))
		{
			c->is_item_boss = true;
		}
		else
		{
			c->is_item_boss = false;
		}

		c->ready = true;
		c->connected = true;
		c->invincible_time = invincible_time;
		c->weapon_id = -1;
		c->playing = true;
		c->grenade_cd_time = -1.f;

		c->max_hp = max_hp;
		c->ex_hp = ex_hp;
		c->SetHasBomb((has_bomb != 0) ? 1 : 0); 
		c->rand_fun.Srand(s_rand);

		c->is_boss = false;
		c->is_fly_uav = false;
		c->ClearLockState();
		c->SetCareer(career, character_info);

		if (gLevel->game_type == RoomOption::kBossMode2)
		{
			if (career == gLevel->boss2_sp_career_id[0] || 
				career == gLevel->boss2_sp_career_id[1])
			{
				c->LockStateByType(kLSJump);
				c->LockStateByType(kLSCrouch);
				c->LockStateByType(kLSMove);
			}

			if (career == gLevel->boss2_sp_career_id[1] || 
				career == gLevel->boss2_sp_career_id[2])
			{
				c->LockStateByType(kLSCrouch);
			}

			if (career == gLevel->boss2_sp_career_id[2] || 
				career == gLevel->boss2_sp_career_id[3])
			{
				c->is_fly_uav = true;
			}
		}
		else if (c->IsCarrierMode() )
		{
			c->LockStateByType(kLSJump);
			c->LockStateByType(kLSCrouch);
		}

		//c->pack_index = pack_index;
		//���赱ǰ����ʼ��ֻ��1����
		//c->InitializeWeapon(c->GetCurCharinfo()->pack_set[0]);
		c->Rebirth(hp, armor, position, Quaternion(Vector3(0, 1, 0), DEG2RAD * angle));
		if (c == gLevel->GetPlayer())
		{
			gLevel->targetenemy_time = 0.f;
			tempc_ptr(StateMainGame) state_main = ptr_dynamic_cast<StateMainGame>(gGame->machine.CurrentState());
			if(state_main)
				state_main->EventCloseCharacter.Fire(ptr_static_cast<StateMainGame>(state_main), EventArgs());
		}

		c->UpdateRawCharacterChangeableInfo();
		

		for (int i = 0; i < 7; ++i)
		{
			tempc_ptr(WeaponBase) weapon = c->GetWeaponById(i);
			if (weapon && weapon->CanActive())
			{
				c->SelectWeapon(i, true);
				break;
			}
		}

		//for (int i = 0; i < 7; i++)
		//{
		//	tempc_ptr(WeaponBase) weapon = c->GetWeaponById(i);
		//	if (weapon && weapon->CanActive())
		//	{
		//		weapon->is_weapon_updated = false;
		//	}
		//}

		c->GetThirdPerson().ClearFootParticle();
		c->GetThirdPerson().ClearZombieParticle();
		c->GetThirdPerson().ClearHumanParticle();
		c->GetThirdPerson().ClearBoddyParticle();

		c->zombie_saving_uid = 0;
		c->zombie_saver_uid = 0;
		c->zombie_dying_flag = false;
		c->zombie_saving_flag = false;
		c->zombie_saving_timer = -1.f;
		if (c->zombie_2D_human_heart)
		{
			c->zombie_2D_human_heart->stop();
			c->zombie_2D_human_heart = NULL;
		}
		c->is_human_super = false;
		c->cd_time = 20.0f;
		c->common_zombie_level = 0;
		c->common_zombie_energy = 0.0f;
		c->can_Invincible = false;
		c->human_energy = 0;
	}
	//ENCODE_END
}

void ChannelConnection::ParseBotSpawn(Core::BinaryNetworkReader & reader)
{
	byte uid;
	byte team;
	int hp;
	int armor;
	Core::Vector3 position(0, 0, 0);
	Core::Vector3 rotation(0, 0, 0);
	float angle = 0;
	int max_hp;
	int ex_hp;
	int s_rand;

	//byte pack_index;
	int career = 0;
	byte start_point = 0;
	float invincible_time = 0;

 	sharedc_ptr(CharacterInfo) character_info = ptr_new CharacterInfo();

	reader.ReadByte(uid);
	reader.ReadInt(hp);
	reader.ReadInt(max_hp);
	reader.ReadInt(ex_hp);
	reader.ReadByte(team);
	reader.ReadInt(armor);
	reader.ReadInt(s_rand);
	reader.ReadVector3(position);
	reader.ReadFloat(angle);
	ReadCharacterInfo(reader, *character_info);

	tempc_ptr(Character) c = gLevel->GetCharacter(uid);

	gLevel->boss_starttimeer = -1;

	gLevel->pveboss_uid = uid;

	if (c)
	{
		if (gLevel->GetPlayer())
			c->control_uid = gLevel->GetPlayer()->uid;

		tempc_ptr(StateMainGame) state_main = ptr_dynamic_cast<StateMainGame>(gGame->machine.CurrentState());
		if(state_main)
		{
			if (state_main->ui->m_current_pveboss && state_main->ui->m_current_pveboss->ispveboss && state_main->ui->m_current_pveboss->IsDied())
				state_main->ui->m_current_pveboss = c;
			else if (!state_main->ui->m_current_pveboss)
				state_main->ui->m_current_pveboss = c;
		}

		c->ispveboss = true;
		c->ready = true;
		c->connected = true;
		c->invincible_time = invincible_time;
		c->weapon_id = -1;
		c->playing = true;
		c->grenade_cd_time = -1.f;

		c->max_hp = max_hp;
		c->ex_hp = ex_hp; 

		c->rand_fun.Srand(s_rand);
		c->SetTeam(team);

		c->is_boss = false;
		c->ClearLockState();

		c->SetCareer(career, character_info);
		c->SetPhysxGroup(team + PhysxSystem::kGroupStart);

		c->Rebirth(hp, armor, position, Quaternion(Vector3(0, 1, 0), DEG2RAD * angle));
		c->UpdateRawCharacterChangeableInfo();

		for (int i = 0; i < 7; ++i)
		{
			tempc_ptr(WeaponBase) weapon = c->GetWeaponById(i);
			if (weapon && weapon->CanActive())
			{
				c->SelectWeapon(i, true);
				break;
			}
		}

		//for (int i = 0; i < 7; i++)
		//{
		//	tempc_ptr(WeaponBase) weapon = c->GetWeaponById(i);
		//	if (weapon && weapon->CanActive())
		//	{
		//		weapon->is_weapon_updated = false;
		//	}
		//}

		c->GetThirdPerson().ClearFootParticle();
		c->GetThirdPerson().ClearZombieParticle();
		
		Core::String str = Core::String::Format("bj/music/%s",c->GetCurCharinfo()->career_key);
		c->boss_pve_scene = FmodSystem::GetEvent(str.Str());
		if (c->boss_pve_scene)
		{
			c->boss_pve_scene->start();
		}

		c->zombie_saving_uid = 0;
		c->zombie_saver_uid = 0;
		c->zombie_dying_flag = false;
		c->zombie_saving_flag = false;
		c->zombie_saving_timer = -1.f;
		if (c->zombie_2D_human_heart)
		{
			c->zombie_2D_human_heart->stop();
			c->zombie_2D_human_heart = NULL;
		}
	}
}

// parse use skill
void ChannelConnection::ParseUseSkill(Core::BinaryNetworkReader & reader)
{
	//ENCODE_START

	byte uid;
	byte from_uid;
	byte skill_type;
	float effect_value;
	float effect_time;

	reader.ReadByte(uid);
	reader.ReadByte(from_uid);
	reader.ReadByte(skill_type);
	reader.ReadFloat(effect_value);
	reader.ReadFloat(effect_time);

	tempc_ptr(Character) c = gLevel->GetCharacter(uid);
	tempc_ptr(Character) from_c = gLevel->GetCharacter(from_uid);
	tempc_ptr(Character) viewer = gLevel->GetViewer();

	if (from_c && skill_type == kSkillZombie)
	{
		if (from_c == gLevel->GetPlayer())
		{
			from_c->zombiegun_cd_time = 0;
		}
	}

	if (c)
	{
		c->UseSkill();

		switch (skill_type)
		{
		case kSkillWindReverse:
			{
				tempc_ptr(FlameGun) pflamegun = ptr_dynamic_cast<FlameGun>(c->GetWeapon(false));
				
				if(pflamegun)
				{
					if(from_c != gLevel->GetPlayer() || state == ChannelConnection::kInReplay)
						from_c->windreverse_time = effect_time;	
				}
			}
			break;
		case kSkillControlStickBomb:
			{
				gLevel->SetAllAmmoDeadByUser(uid, kWeaponTypeAmmoStick);
			}
			break;
		}
	}

	if (from_c && from_c->current_career == DEFAULT_COMMONZOMBIE_CHARGE)
	{
		if (from_c == gLevel->GetPlayer())
		{
			const FirstPerson & first_person = from_c->GetFirstPerson();
			if(first_person.animation_group)
			{
				first_person.animation_group->PlayAction("charge", "charge");
			}
		}
		else if (from_c)
		{
			const ThirdPerson & third_person = from_c->GetThirdPerson();
			if (third_person.node_list_system)
				third_person.node_list_system->SetActiveNode("show");

		}
	}

	//ENCODE_END
}

void ChannelConnection::ParseUseSkillSuperMan(Core::BinaryNetworkReader & reader)
{
	byte uid;
	reader.ReadByte(uid);
	tempc_ptr(Character) c = gLevel->GetCharacter(uid);
	c->GetThirdPerson().CreateBoddyParticle("human_wave");
}

void ChannelConnection::ParseSkillSuperManSuccess(Core::BinaryNetworkReader & reader)
{
	byte uid;
	reader.ReadByte(uid);
	tempc_ptr(Character) c = gLevel->GetCharacter(uid);
	for (uint i = 0; i < gLevel->character_manager->GetCharacters().Size(); ++i)
	{
		tempc_ptr(Character) ch =gLevel->character_manager->GetCharacters()[i];
		if (ch && ch != c)
		{
			if(Length(c->GetPosition() - ch->GetPosition()) <= 15.0f)
			{
				KickInfo info;
				Vector3 v = ch->GetPosition() - c->GetPosition();

				v.Normalize();
				v.y +=0.6f;
				info.dir.SetFromTo(Vector3(0,0,-1),v);
				info.kick_time_interval = 0.2f;
				info.kick_factor = 20.0f;
				info.on_static_kick_y_offset = 2.0f;
				gGame->channel_connection->SkillKickBack(ch->uid, info);
			}
		}
	}
	c->cd_time = 20.0f;
	FMOD_VECTOR vel = {0, 0, 0};
	FmodSystem::Play3DEvent("bj/fx/3d/bio2/hunter_shockwave",(const FMOD_VECTOR &)c->GetPosition(),vel);
	//FmodSystem::PlayEvent("bj/item/2d/pickup_item");
}

void ChannelConnection::ParseCommonZombieHumanDie(Core::BinaryNetworkReader & reader)
{
	byte uid, from, to, part;
	reader.ReadByte(uid);
	reader.ReadByte(from);
	reader.ReadByte(to);
	reader.ReadByte(part);
	sharedc_ptr(WeaponInfo) weapon_info = ReadWeapon(reader);
	sharedc_ptr(Character) f = gLevel->GetCharacter(from);
	sharedc_ptr(Character) t = gLevel->GetCharacter(to);
	sharedc_ptr(Character) player = gLevel->GetPlayer();
	if (f && t)
	{
		gGame->scores->Kill(f, t, 0, part, weapon_info);
		f->kill_anim_time = 0.0f;
		f->isshowevent = true;
		f->kills_kind.Clear();
		if (t->is_human_super)
		{
			f->kills_kind.PushBack(kCommonZombie_infect_Last);
		} 
		else
		{
			f->kills_kind.PushBack(kCommonZombie_infect);
		}
		f->lian_kill_count++;
		if (f->lian_kill_count < 5)
			f->kills_kind.PushBack(kGeneral);
		else
			f->kills_kind.PushBack(kContinuation);
		if(f == player)
		{
			if(f != t)
			{
				LosterHistoryInfo losetinfo;
				losetinfo.lostername = t->GetName();
				losetinfo.careername = t->character_info->career_name;
				losetinfo.kills_kind = f->kills_kind;
				//losetinfo.score = f->kill_showscore;
				f->killerinfo.arry_losters.Add(losetinfo);
				f->killerinfo.killnum++;
				//f->killerinfo.totalscore += f->kill_showscore;
			}
		}
		// ����
		//else if(assistplayer && assistplayer == player)
		//{
		//	assistplayer->killerinfo.assistnum++;
		//	assistplayer->all_score += player->kill_showscore;
		//}
	}	
}


void ChannelConnection::ParseCancelInvisible(Core::BinaryNetworkReader & reader)
{
	byte uid;
	reader.ReadByte(uid);
	tempc_ptr(Character) c = gLevel->GetCharacter(uid);
	if (c)
	{
		c->GetThirdPerson().CreateInvisibleParticle();
		//c->PlayItemModeParticle("cell03_disappear",10.f);
	}
}

void ChannelConnection::ParseUseSmog(Core::BinaryNetworkReader & reader)
{
	byte uid;
	Core::Vector3 pos;
	reader.ReadByte(uid);
	reader.ReadVector3(pos);

	sharedc_ptr(ParticleSystem) ps = ptr_new ParticleSystem("cell04_smoke");
	ps->SetPosition(pos);
	gLevel->somg_particle_set.Add(uid, ps);
	gLevel->AddParticle(ps);

	tempc_ptr(Character) c = gLevel->GetCharacter(uid);
	c->somg_time = 15.f;

	if (c->GetFirstPerson().animation_group)
		c->GetFirstPerson().animation_group->PlayAction("default_knife_stab", "lightstab", 1.f);
	if (c->GetThirdPerson().node_group)
		c->GetThirdPerson().node_group->PlayAction("default_knife_stab", "stdlightstab", 1.f);
}

// parse use skill
void ChannelConnection::ParseUseCureSkill(Core::BinaryNetworkReader & reader)
{
	byte uid;
	byte from_uid;
	short effect_type;
	float effect_time;

	reader.ReadByte(uid);
	reader.ReadByte(from_uid);
	reader.ReadShort(effect_type);
	reader.ReadFloat(effect_time);

	tempc_ptr(Character) c = gLevel->GetCharacter(uid);
	tempc_ptr(Character) from_c = gLevel->GetCharacter(from_uid);
	tempc_ptr(Character) viewer = gLevel->GetViewer();

	switch (effect_type)
	{
	case kWeaponAttr_Skill_AddBlood:
	case kWeaponAttr_Skill_Boost:
		{
			if(uid != from_uid)
			{	
				tempc_ptr(GunBase) gun = ptr_dynamic_cast<GunBase>(from_c->GetWeapon(false));
				if(gun && c->tp_special_particle_time <= 0)
				{
					c->tp_special_particle = gun->tp_special_particle;
					c->tp_special_particle_time = 8.0f;
				}
			}

			tempc_ptr(GunBase) gun = ptr_dynamic_cast<GunBase>(from_c->GetWeapon(false));
			if(gun && from_c->special_particle_time <= 0)
			{
				from_c->gun_special_particle = gun->gun_special_particle;
				from_c->special_particle_time = 8.0f;
			}
		}
		break;
	case kWeaponAttr_Skill_Invincible:
		LogSystem.WriteLinef("kWeaponAttr_Skill_Invincible");
		break;
	default:
		LogSystem.WriteLinef("kWeaponAttr_Skill_Type_Error");
		break;
	}
}

// parse use skill stop
void ChannelConnection::ParseUseSkillStop(Core::BinaryNetworkReader & reader)
{
	//ENCODE_START

	byte uid;
	byte type;

	reader.ReadByte(uid);
	reader.ReadByte(type);

	tempc_ptr(Character) c = gLevel->GetCharacter(uid);

	if (c)
	{
		c->UseSkillStop();
	}

	//ENCODE_END
}

// parse supply radar
void ChannelConnection::ParseSupplyRadar(Core::BinaryNetworkReader & reader)
{
	//ENCODE_START

	float effect_time;
	byte team;
	reader.ReadByte(team);
	reader.ReadFloat(effect_time);

	tempc_ptr(Character) player = gLevel->GetPlayer();
	if (player && (player->GetTeam() ==team))
	{
		player->radar_ui_timer = 3;
		player->radar_timer = effect_time;
	}

	//ENCODE_END
}

// parse change pack
void ChannelConnection::ParseChangePack(Core::BinaryNetworkReader & reader)
{
	//ENCODE_START

	byte uid;
	byte pack_index;
	PackInfo pack;

	reader.ReadByte(uid);
	reader.ReadByte(pack_index);
	ReadPackInfo(reader, pack);

	//�����ǻ���
	//tempc_ptr(Character) c = gLevel->GetCharacter(uid);

	//if (c)
	//{
	//	c->pack_index = pack_index;
	//	c->InitializeWeapon(pack);
	//	for (int i = 0; i < 7; i++)
	//	{
	//		tempc_ptr(WeaponBase) weapon = c->GetWeaponById(i);
	//		if (weapon && weapon->CanActive())
	//		{
	//			c->SelectWeapon(i, true);
	//			break;
	//		}
	//	}
	//}

	//ENCODE_END
}

// parse kick client start
void ChannelConnection::ParseKickClientError(Core::BinaryNetworkReader & reader)
{
	//ENCODE_START

	int error_id;

	reader.ReadInt(error_id);
	
	tempc_ptr(StateMainGame) state_main = ptr_dynamic_cast<StateMainGame>(gGame->machine.CurrentState());
	if(state_main)
	{
		state_main->KickPersonError.Fire(ptr_static_cast<StateMainGame>(state_main), EventKickError(error_id));
	}

	//ENCODE_END
}

// parse kick client start
void ChannelConnection::ParseKickClientStart(Core::BinaryNetworkReader & reader)
{
	//ENCODE_START

	byte sponsor_uid;
	byte kicked_uid;
	byte kicked_reason;

	reader.ReadByte(sponsor_uid);
	reader.ReadByte(kicked_uid);
	reader.ReadByte(kicked_reason);

	gLevel->kick_select_open = true;
	gLevel->kick_wait_time = 10.0f;
	gLevel->sponsor_uid = sponsor_uid;
	gLevel->kicked_uid = kicked_uid;
	gLevel->kicked_reason = kicked_reason;
	gLevel->kick_agree_num = 0;
	gLevel->kick_against_num = 0;
	gLevel->kick_select_id = 0;

	tempc_ptr(Character) c = gLevel->GetPlayer();
	if(c)
	{
		if (c->uid == sponsor_uid)
			gLevel->kick_count--;

		if(sponsor_uid == c->uid || kicked_uid == c->uid)
		{
			gLevel->kick_select_id = 3;
		}
	}

	//ENCODE_END
}

// parse kick client end
void ChannelConnection::ParseKickClientEnd(Core::BinaryNetworkReader & reader)
{
	//ENCODE_START

	byte sponsor_uid;
	byte kicked_uid;
	byte result;

	reader.ReadByte(sponsor_uid);
	reader.ReadByte(kicked_uid);
	reader.ReadByte(result);

	tempc_ptr(Character) c1 = gLevel->GetCharacter(sponsor_uid);
	tempc_ptr(Character) c2 = gLevel->GetCharacter(kicked_uid);

	if(c1 && c2)
	{
		gGame->global->SystemMessage(String::Format(gLang->GetTextW(L"%s�����߳�%s,ͶƱ%s"),c1->GetName(),c2->GetName(),result == 0?gLang->GetTextW(L"ʧ��"):gLang->GetTextW(L"�ɹ�")), "/info");
		tempc_ptr(StateMainGame) state_main = ptr_dynamic_cast<StateMainGame>(gGame->machine.CurrentState());
		if(state_main && result != 0 && c2 == gLevel->GetPlayer())
			state_main->KickPersonError.Fire(ptr_static_cast<StateMainGame>(state_main), EventKickError(5));
	}

	//ENCODE_END
}

// parse kick client vote
void ChannelConnection::ParseKickClientVote(Core::BinaryNetworkReader & reader)
{
	//ENCODE_START

	byte uid;
	byte result;

	reader.ReadByte(uid);
	reader.ReadByte(result);

	if(result)
		gLevel->kick_agree_num++;
	else
		gLevel->kick_against_num++;

	//ENCODE_END
}

// gen spiritball
int ChannelConnection::GenSpiritBall(uint uid, int score, const Core::Vector3 & pos, const Core::Array<int> &kills_kind)
{
	for (int n = 0; n < (int)kills_kind.Size(); ++n)
	{
		int spirit_ball_kind = 0;

		switch (kills_kind[n])
		{
		case kFight:
		case kHead:
		case kBoost:
		case kControl:
		case kReveng:
			spirit_ball_kind = 1;
			break;
		}

		sharedc_ptr(SpiritBall) spirit_ball = ptr_new SpiritBall();
		spirit_ball->Initialize(uid, score, pos, spirit_ball_kind);
		gLevel->spiritball_array.Add(spirit_ball);
	}

	return kills_kind.Size();
}

void ChannelConnection::TakeDamage(Core::BinaryNetworkReader & reader, by_ptr(Character) from, by_ptr(Character) to, const Vector3 & pos, bool isfullhurt, bool isboost)
{
	//VMProtectBegin("TakeDamage");
	//ENCODE_START

	if (to)
	{
		HitInfo h;
		int score_hit;

		reader.ReadByte(h.part);
		reader.ReadInt(score_hit);
		reader.ReadInt(h.hp);
		reader.ReadInt(h.armor);
		h.boost = isboost;

		h.time = 1;
		h.dir = from? (from->GetRotation() * Quaternion(Vector3(0, 1, 0), PI)) : Quaternion::kIdentity;
		h.from_uid = from? from->uid: 0;
		h.to_uid = to->uid;
		h.sustainhurttype = kSustainNone;
		tempc_ptr(Character) viewer = gLevel->GetViewer();
		tempc_ptr(Character) player = gLevel->GetPlayer();

		if (to == viewer && h.hp != 0)
		{
			FmodSystem::PlayEvent("bj/event/b_hit");
			if (isfullhurt && viewer &&viewer->GetCurCharinfo())
			{
				String str = String::Format("bj/player/2d/%s/fallhurt",viewer->GetCurCharinfo()->res_key);
				FmodSystem::PlayEvent(str.Str());
			}
		}

		if (viewer && viewer == from)
		{
			if(to != from && to->GetTeam() == from->GetTeam() && from->is_shoot_stab)
			{
				if(h.hp == 0)
				{
					from->is_team_hurt_dead = true;
					from->is_team_hurt_part = false;
					from->team_hurt_dead_time = 0.5f;
				}
				else
				{
					from->is_team_hurt_dead = false;
					from->is_team_hurt_part = true;
					from->team_hurt_part_time = 0.5f;
				}
				from->team_hurt_time = 2.0f;
			}

			if(h.hp != to->hp)
			{
				to->damage_hp_time = 1.5f;
				to->is_display_damage_hp = true;
				to->damage_armor = to->armor - h.armor;
				to->damage_hp = to->hp - h.hp;
				if(from != to)
				{
					from->accumulate_damage += to->hp - h.hp;
				}
			}
		}

		if (from && from->all_score != score_hit)
		{
			float score = score_hit - from->all_score;
			from->all_score = score_hit;

			if (viewer && viewer == from)
			{
				viewer->hits_score_wait_time = 0.0f;
				viewer->hits_score_alpha = 1.0f;

				if(viewer->hit_current_score < viewer->all_score)
					viewer->hit_scroll_time = 0.0f;
				tempc_ptr(Character) player = gLevel->GetPlayer();
				if (player == viewer)
				{
					player->kill_showscore = score;
				}
			}
		}
		
		if (from && from != to)
		{
			Vector3 dir = to->GetPosition() - pos;
			dir.y = 0;
			dir.Normalize();
			h.dir = Quaternion(Vector3(0, 0, -1), dir);
		}

		/// kill type
		if (!to->IsDied())
		{
			to->OnHit(h);
			bool ispass = true;
			if (to != from && from == viewer)
			{
				if (from->GetWeapon()->GetWeaponType() != kWeaponTypeKnife)
				{
					if (h.part == kCharacterPartHead)
					{
						ispass = false;
						FmodSystem::PlayEvent("bj/material/2d/hit_headshot");
					}
					if (h.boost)
					{
						ispass = false;
						FmodSystem::PlayEvent("bj/material/2d/hit_burst");
					}
					if (ispass)
					{
						FmodSystem::PlayEvent("bj/material/2d/hit");
					}
				}
			}

			if (viewer && from == viewer)
				viewer->score ++;

			if (h.hp == 0 || to->isghost)
			{
				h.weapon = ReadWeapon(reader);
				bool sucidebyassist = false;
				short num_killed;
				if (from == to)
				{
					sucidebyassist = true;
					reader.ReadShort(num_killed);
				}	
				else if(from)
				{
					reader.ReadShort(num_killed);
				}

				reader.ReadShort(to->num_died);
				
				byte assist_uid;
				int assistscore;

				short assist_num;
				reader.ReadByte(assist_uid);
				reader.ReadInt(assistscore);
				reader.ReadShort(assist_num);
				tempc_ptr(Character) assistplayer = gLevel->GetCharacter(assist_uid);
				h.assist_uid = assist_uid;

				if (assistplayer && assistplayer != from)
				{
					assistplayer->helpkill_num++;
					assistplayer->num_assist = assist_num;
				}
				if (assistplayer && assistplayer->all_score != assistscore && assistplayer != from)
				{
					tempc_ptr(Character) player = gLevel->GetPlayer();

					float score = assistscore - assistplayer->all_score;
					if (assistplayer != player)
						assistplayer->all_score = assistscore;
					if (viewer && viewer == assistplayer)
					{
						viewer->hits_score_wait_time = 0.0f;
						viewer->hits_score_alpha = 1.0f;

						if(viewer->hit_current_score < viewer->all_score)
							viewer->hit_scroll_time = 0.0f;
						
						if (player == viewer)
						{
							player->kill_showscore = score;
						}
					}
				}

				if (from && from != to)
				{
					from->OnKill(h);
					
					if (from == player && to != player)
					{
						from->spiritball_num = GenSpiritBall(from->uid, score_hit, to->GetPosition(), from->kills_kind);
					}
				}
				if(assistplayer)
				{
					if(from == to && assistplayer != from)
					{
						assistplayer->OnKill(h);
					}
					if (assistplayer == player && to != player && assistplayer != from)
					{
						Core::Array<int> kills_kind;
						if (assistplayer->kills_kind.Size() == 0)
						{
							kills_kind.PushBack(kGeneral);
							assistplayer->spiritball_num = GenSpiritBall(assistplayer->uid, assistscore, to->GetPosition(), kills_kind);
						}
						else
							assistplayer->spiritball_num = GenSpiritBall(assistplayer->uid, assistscore, to->GetPosition(), assistplayer->kills_kind);
					}
				}

				if (!to->isghost)
				{
					to->Die(h);
				}
				
				if (to == gLevel->GetPlayer())
				{
					gLevel->targetenemy_time = 0.f;
					gLevel->tmpplayer = NullPtr;
					gLevel->ClearDefuseBombState();
				}

				if(viewer && from == viewer && to != from && h.boost)
				{
					from->kills_kind.PushBack(kBoost);
				}

				if(assistplayer && assistplayer != from)
				{
					if(from != to)
						gGame->scores->Kill(from, to, assist_uid, h.part, h.weapon);
					else
						gGame->scores->Kill(assistplayer, to, assist_uid, h.part, h.weapon);
				}
				else
				{
					gGame->scores->Kill(from, to, 0, h.part, h.weapon);
				}
				if (game_state != kGameEnd && to == gLevel->GetPlayer())
					game_state = kDied;

				if(from == to && assistplayer && assistplayer != from)
				{
					assistplayer->num_killed = num_killed;
					h.from_uid = assistplayer->uid;

					if(assistplayer == player)
					{

						LosterHistoryInfo losetinfo;
						losetinfo.lostername = to->GetName();
						losetinfo.careername = to->character_info->career_name;
						losetinfo.kills_kind = player->kills_kind;
						losetinfo.score = player->kill_showscore;
						assistplayer->killerinfo.arry_losters.Add(losetinfo);
						assistplayer->killerinfo.killnum++;
						assistplayer->killerinfo.totalscore += player->kill_showscore;
					}
				}
				else
				{
					from->num_killed = num_killed;
					if(from == player)
					{
						if(from != to)
						{
							LosterHistoryInfo losetinfo;
							losetinfo.lostername = to->GetName();
							losetinfo.careername = to->character_info->career_name;
							losetinfo.kills_kind = player->kills_kind;
							losetinfo.score = from->kill_showscore;
							from->killerinfo.arry_losters.Add(losetinfo);
							from->killerinfo.killnum++;
							from->killerinfo.totalscore += from->kill_showscore;
						}
					}
					else if(assistplayer && assistplayer == player)
					{
						assistplayer->killerinfo.assistnum++;
						assistplayer->all_score += player->kill_showscore;
						assistplayer->killerinfo.totalscore += player->kill_showscore;
					}
				}
			}
		}
	}
	
	//VMProtectEnd();
	//ENCODE_END
}

void Client::ChannelConnection::TakeSustainDamage(Core::BinaryNetworkReader & reader, by_ptr(Character) from, by_ptr(Character) to )
{
	//VMProtectBegin("TakeSustainDamage");
	//ENCODE_START

	byte	hurttype;
	int		score;
	int		health;

	reader.ReadByte(hurttype);
	reader.ReadInt(score);
	reader.ReadInt(health);

	HitInfo h;
	h.part = 0;
	h.hp = health;
	h.time = 1;
	h.dir = from? (from->GetRotation() * Quaternion(Vector3(0, 1, 0), PI)) : Quaternion::kIdentity;
	h.from_uid = from? from->uid: 0;
	h.to_uid = to? to->uid: 0;
	h.sustainhurttype = hurttype;
	h.boost = false;

	if (to)
	{	
		switch(hurttype)
		{
		case kSustainFlameHurt:
			{
				to->Burn();
			}
			break;
		case kSustainHurtCutHurt:
		case kSustainHurtPoison:
			{
				to->Poison();
			}
			break;
		case kSustainHurtFrost:	
			{
				to->Burn();
			}
			break;
		default:
				break;
		}
		
		tempc_ptr(Character) viewer = gLevel->GetViewer();
		tempc_ptr(Character) player = gLevel->GetPlayer();

		if(player == to)
		{
			tempc_ptr(StateMainGame) state_main = ptr_dynamic_cast<StateMainGame>(gGame->machine.CurrentState());
			if(state_main && state_main->ui)
				state_main->ui->AddBloodEffectData(0.8f, kRecoverFire,Core::Vector2(50, -80), to->hp - h.hp);
		}
		if (viewer && viewer == from)
		{
			if(to != from && to->GetTeam() == from->GetTeam() && from->is_shoot_stab)
			{
				if(h.hp == 0)
				{
					from->is_team_hurt_dead = true;
					from->is_team_hurt_part = false;
					from->team_hurt_dead_time = 0.5f;
				}
				else
				{
					from->is_team_hurt_dead = false;
					from->is_team_hurt_part = true;
					from->team_hurt_part_time = 0.5f;
				}
				from->team_hurt_time = 2.0f;
			}

			if(h.hp != to->hp)
			{
				to->damage_hp_time = 1.5f;
				to->is_display_damage_hp = true;
				to->damage_armor = to->armor - h.armor;
				to->damage_hp = to->hp - h.hp;
				if(from != to)
				{
					from->accumulate_damage += to->hp - h.hp;
				}
			}
		}

		if (from && from->all_score != score)
		{
			float temp_score = score - from->all_score;
			from->all_score = score;

			if (viewer && viewer == from)
			{
				viewer->hits_score_wait_time = 0.0f;
				viewer->hits_score_alpha = 1.0f;

				if(viewer->hit_current_score < viewer->all_score)
					viewer->hit_scroll_time = 0.0f;
				tempc_ptr(Character) player = gLevel->GetPlayer();
				if (player == viewer)
				{
					player->kill_showscore = temp_score;
				}
			}
		}

		/// kill type
		if (!to->IsDied())
		{
			short	numkilled;
			short	numdied;
			short assist_num;
			byte	assistid;
			int		assistscore;
			if (health == 0)
			{
				h.weapon = ReadWeapon(reader);
				reader.ReadShort(numkilled);
				reader.ReadShort(numdied);
				reader.ReadByte(assistid);
				reader.ReadInt(assistscore);
				reader.ReadShort(assist_num);
			}
			to->OnHit(h);

			if (viewer && from == viewer)
				viewer->score ++;

			if (h.hp == 0)
			{
				to->num_died = numdied;

				tempc_ptr(Character) assistplayer = gLevel->GetCharacter(assistid);
				h.assist_uid = assistid;
				if (from == to && assistplayer && assistplayer != from)
				{
					assistplayer->num_killed = numkilled;
					h.from_uid = assistplayer->uid;
				}	
				else
				{
					from->num_killed = numkilled;
				}

				if (assistplayer && assistplayer->all_score != assistscore && assistplayer != from)
				{
					tempc_ptr(Character) player = gLevel->GetPlayer();

					float score = assistscore - assistplayer->all_score;
					if (assistplayer != player)
						assistplayer->all_score = assistscore;
					assistplayer->helpkill_num++;
					assistplayer->num_assist = assist_num;
					if (viewer && viewer == assistplayer)
					{
						viewer->hits_score_wait_time = 0.0f;
						viewer->hits_score_alpha = 1.0f;

						if(viewer->hit_current_score < viewer->all_score)
							viewer->hit_scroll_time = 0.0f;
						
						if (player == viewer)
						{
							player->kill_showscore = score;
						}
					}
				}

				if (from)
				{
					from->OnKill(h);

					if (from == player && to != player)
					{
						from->spiritball_num = GenSpiritBall(from->uid, score, to->GetPosition(), from->kills_kind);
					}
				}
					
				if(assistplayer)
				{
					if(from == to && assistplayer != from)
					{
						assistplayer->OnKill(h);
					}
					if (assistplayer == player && to != player && assistplayer != from)
					{
						Core::Array<int> kills_kind;
						if (assistplayer->kills_kind.Size() == 0)
						{
							kills_kind.PushBack(kGeneral);
							assistplayer->spiritball_num = GenSpiritBall(assistplayer->uid, assistscore, to->GetPosition(), kills_kind);
						}
						else
							assistplayer->spiritball_num = GenSpiritBall(assistplayer->uid, assistscore, to->GetPosition(), assistplayer->kills_kind);
					}
				}

				to->Die(h);
				if (to == gLevel->GetPlayer())
				{
					gLevel->targetenemy_time = 0.f;
					gLevel->tmpplayer = NullPtr;
					gLevel->ClearDefuseBombState();
				}

				if(viewer && from == viewer && to != from && h.boost)
				{
					from->kills_kind.PushBack(kBoost);
				}

				if(assistplayer && assistplayer != from)
				{
					if(from != to)
						gGame->scores->Kill(from, to, assistid, h.part, h.weapon,h.sustainhurttype);
					else
						gGame->scores->Kill(assistplayer, to, assistid, h.part, h.weapon);
				}
				else
				{
					gGame->scores->Kill(from, to, 0, h.part, h.weapon,h.sustainhurttype);
				}
				if (game_state != kGameEnd && to == gLevel->GetPlayer())
					game_state = kDied;
					
					
				if(from == to && assistplayer && assistplayer != from)
				{
					assistplayer->num_killed = numkilled;
					h.from_uid = assistplayer->uid;

					if(assistplayer == player)
					{

						LosterHistoryInfo losetinfo;
						losetinfo.lostername = to->GetName();
						losetinfo.careername = to->character_info->career_name;
						losetinfo.kills_kind = player->kills_kind;
						losetinfo.score = player->kill_showscore;
						assistplayer->killerinfo.arry_losters.Add(losetinfo);
						assistplayer->killerinfo.killnum++;
						assistplayer->killerinfo.totalscore += player->kill_showscore;
					}


				}
				else
				{
					from->num_killed = numkilled;
					if(from == player)
					{
						if(from != to)
						{
							LosterHistoryInfo losetinfo;
							losetinfo.lostername = to->GetName();
							losetinfo.careername = to->character_info->career_name;
							losetinfo.kills_kind = player->kills_kind;
							losetinfo.score = from->kill_showscore;
							from->killerinfo.arry_losters.Add(losetinfo);
							from->killerinfo.killnum++;
							from->killerinfo.totalscore += from->kill_showscore;
						}
					}
					else if(assistplayer && assistplayer == player)
					{
						assistplayer->killerinfo.assistnum++;
						assistplayer->all_score += player->kill_showscore;
					}
				}
			}
		}
	}
	//VMProtectEnd();
	//ENCODE_END
}

void Client::ChannelConnection::TakePveDamage(Core::BinaryNetworkReader & reader, by_ptr(Character) from, by_ptr(Character) to)
{
	int score;
	int	health;

	reader.ReadInt(score);
	reader.ReadInt(health);

	HitInfo h;
	h.part = 0;
	h.hp = health;
	h.time = 1;
	h.dir = from? (from->GetRotation() * Quaternion(Vector3(0, 1, 0), PI)) : Quaternion::kIdentity;
	h.from_uid = from? from->uid: 0;
	h.to_uid = to? to->uid: 0;
	h.sustainhurttype = kSustainNone;
	h.boost = false;
	h.assist_uid = 0;

	if (to)
	{
		if (!to->IsDied())
		{
			to->OnHit(h);

			if (h.hp == 0)
			{
				reader.ReadShort(to->num_died);
				if (from)
					from->OnKill(h);

				to->Die(h);
			}
		}
	}
}

void ChannelConnection::ParseShoot(Core::BinaryNetworkReader & reader)
{
	//ENCODE_START

	byte uid;
	byte hurt;
	Quaternion dir;

	bool do_effect = true;
	bool isboost;
	int hurtcount;
	reader.ReadByte(uid);
	ReadCharacterRotation(reader, dir);
	reader.ReadByte((Byte&)do_effect);
	reader.ReadByte((Byte&)isboost);
	reader.ReadInt(hurtcount);
	
	

	tempc_ptr(Character) c = gLevel->GetCharacter(uid);
	tempc_ptr(Character) viewer = gLevel->GetViewer();

	if (c)
	{
		if(gGame->channel_connection->GetState() != ChannelConnection::kInReplay)
		{
			if (c != gLevel->GetPlayer())
				c->Shoot(Core::Vector3(0, 0, -1) * dir, do_effect,isboost);
			else if(c)
				if (!c->isshooting)
					c->isshooting = true;
			c->is_shoot_stab = true;
			for(int i = 0; i < hurtcount; i++)
			{
				reader.ReadByte(hurt);

				tempc_ptr(Character) h = gLevel->GetCharacter(hurt);
				if (h)
					TakeDamage(reader, c, h, c->GetPosition(),false, isboost);
			}
		}
		else
		{
			c->Shoot(Core::Vector3(0, 0, -1) * dir, do_effect,isboost);

			if(c->GetWeapon()->GetWeaponType() == kWeaponTypeDrum)
			{
				c->accumulate_damage = 0;
			}
			
			c->is_shoot_stab = true;
			for(int i = 0; i < hurtcount; i++)
			{
				reader.ReadByte(hurt);

				tempc_ptr(Character) h = gLevel->GetCharacter(hurt);
				if (h)
					TakeDamage(reader, c, h, c->GetPosition(),false, isboost);
			}
		}
		
	}

	//ENCODE_END
}

void ChannelConnection::ParseFlameShoot(Core::BinaryNetworkReader & reader)
{
	//ENCODE_START

	byte uid;
	byte hurt;
	Quaternion dir;

	bool do_effect = true;
	bool isboost;
	int hurtcount;
	
	reader.ReadByte(uid);
	ReadCharacterRotation(reader, dir);
	reader.ReadByte((Byte&)do_effect);
	reader.ReadByte((Byte&)isboost);
	reader.ReadInt(hurtcount);

	
	
	tempc_ptr(Character) c = gLevel->GetCharacter(uid);
	tempc_ptr(Character) viewer = gLevel->GetViewer();

	if (c)
	{
		if (c != gLevel->GetPlayer() || state == ChannelConnection::kInReplay)
			c->Shoot(Core::Vector3(0, 0, -1) * dir, do_effect);

		c->is_shoot_stab = true;
		for(int i = 0; i < hurtcount; i++)
		{
			reader.ReadByte(hurt);
			tempc_ptr(Character) h = gLevel->GetCharacter(hurt);
			TakeDamage(reader, c, h, c->GetPosition(),false, isboost);
		}
	}

	//ENCODE_END
}

// parse kick back
void ChannelConnection::ParseKickBack(Core::BinaryNetworkReader & reader)
{
	//ENCODE_START

	byte uid;
	Vector3 punch;

	reader.ReadByte(uid);
	reader.ReadVector3(punch);

	tempc_ptr(Character) c = gLevel->GetCharacter(uid);
	tempc_ptr(Character) player = gLevel->GetPlayer();

	if (c && c != player)
		c->punch_angle = punch;

	//ENCODE_END
}

// parse grenade throw in
void ChannelConnection::ParseGrenadeThrowIn(Core::BinaryNetworkReader & reader)
{
	//ENCODE_START

	byte uid;
	reader.ReadByte(uid);

	tempc_ptr(Character) c = gLevel->GetCharacter(uid);
	if (c && c != gLevel->GetPlayer())
		c->GrenadeThrowIn();

	//ENCODE_END
}

// parse grenade throw stop
void ChannelConnection::ParseGrenadeThrowStop(Core::BinaryNetworkReader & reader)
{
	//ENCODE_START

	byte uid;
	reader.ReadByte(uid);

	tempc_ptr(Character) c = gLevel->GetCharacter(uid);
	if (c && c != gLevel->GetPlayer())
		c->GrenadeThrowStop();

	//ENCODE_END
}

void ChannelConnection::ParseGrenadeThrowOut(Core::BinaryNetworkReader & reader)
{
	//ENCODE_START

	byte uid;
	byte weapon_id;
	Core::Vector3 position;
	Core::Vector3 direction;

	reader.ReadByte(uid);
	reader.ReadByte(weapon_id);
	reader.ReadVector3(position);
	reader.ReadVector3(direction);
	sharedc_ptr(WeaponInfo) weapon_info  = ReadWeapon(reader);

	tempc_ptr(Character) character = gLevel->GetCharacter(uid);
	tempc_ptr(Character) player = gLevel->GetPlayer();
	if (character)
	{
		tempc_ptr(ThrowableInfo) info = ptr_dynamic_cast<ThrowableInfo>(weapon_info);
		if (info)
			character->GrenadeThrowOut(weapon_id, info, position, direction);

		
	}

	//ENCODE_END
}


void ChannelConnection::ParsePoke(Core::BinaryNetworkReader & reader)
{
	byte uid;
	byte type;

	reader.ReadByte(uid);
	reader.ReadByte(type);

	tempc_ptr(Character) character = gLevel->GetCharacter(uid);

	if (character)
	{
		character->Stab(type);
		character->is_shoot_stab = true;
	}
}

void ChannelConnection::ParsePokeHurt(Core::BinaryNetworkReader & reader)
{
	//ENCODE_START

	byte uid;
	byte type;
	byte hurt_uid;
	bool isboost;
	reader.ReadByte(uid);
	reader.ReadByte(type);
	reader.ReadByte((Byte&)isboost);
	reader.ReadByte(hurt_uid);

	tempc_ptr(Character) character = gLevel->GetCharacter(uid);
	tempc_ptr(Character) hurt = gLevel->GetCharacter(hurt_uid);

	if (character && hurt)
		TakeDamage(reader, character, hurt, character->GetPosition(),false,isboost);

	//ENCODE_END
}

void ChannelConnection::ParseReload(Core::BinaryNetworkReader & reader)
{
	//ENCODE_START

	byte uid;
	short count;
	reader.ReadByte(uid);
	reader.ReadShort(count);
	tempc_ptr(Character) character = gLevel->GetCharacter(uid);
	tempc_ptr(Character) player = gLevel->GetPlayer();
	if (character &&player != character)
	{
		character->Reload();
		character->GetThirdPerson().ammo_need_multianimation = count;
	}

	//ENCODE_END
}

// parse reload ready
void ChannelConnection::ParseReloadReady(Core::BinaryNetworkReader & reader)
{
	//ENCODE_START

	byte uid;
	int count;

	reader.ReadByte(uid);
	reader.ReadInt(count);

	tempc_ptr(Character) character = gLevel->GetCharacter(uid);
	tempc_ptr(Character) player = gLevel->GetPlayer();
	if (character && character != player)
	{
		character->ReloadReady(count);
	}

	//ENCODE_END
}

// parse drop gun
void ChannelConnection::ParseDropWeapon(Core::BinaryNetworkReader & reader)
{
	//ENCODE_START

	byte uid;
	byte weapon_id;
	uint dropped_id;
	//Vector3 pos;
	//Vector3 dir;

	reader.ReadByte(uid);
	reader.ReadByte(weapon_id);
	reader.ReadInt(dropped_id);
	sharedc_ptr(WeaponInfo) weapon_info  = ReadWeapon(reader);
	//ReadVector3(pos);
	//ReadVector3(dir);

	if (weapon_info)
	{
		tempc_ptr(Character) chara = gLevel->GetCharacter(uid);
		if (chara)
		{
			gLevel->pickup_manager->DropWeapon(chara, dropped_id, weapon_id, weapon_info);
		}

		if(weapon_info->weapon_type == kWeaponTypeBomb)
		{
			chara->SetHasBomb(false);
			FmodSystem::PlayEvent("bj/event/c4_dropped");
			Core::String str = Core::String::Format(gLang->GetTextW(L"%s �������װ���"),chara->GetName());
			gLevel->AddHorn(str);

			gLevel->bomb_droped_id = dropped_id;
			gLevel->bomb_droped = true;
		}
	}

	//ENCODE_END
}

// parse add weapo
void ChannelConnection::ParseAddDroppedWeapon(Core::BinaryNetworkReader & reader)
{
	//ENCODE_START

	uint dropped_id;
	Vector3 pos;
	float dir;

	reader.ReadInt(dropped_id);
	reader.ReadVector3(pos);
	reader.ReadFloat(dir);
	sharedc_ptr(WeaponInfo) weapon_info = ReadWeapon(reader);

	if (weapon_info && gLevel->pickup_manager)
		gLevel->pickup_manager->AddWeapon(dropped_id, weapon_info, pos, Quaternion(Vector3(0, 1, 0), dir));

	//ENCODE_END
}

void ChannelConnection::ParseAddDroppedSupply(Core::BinaryNetworkReader & reader)
{
	//ENCODE_START

	uint id;
	Byte type;
	Vector3 pos;
	int	 value;
	float dir;

	reader.ReadInt(id);
	reader.ReadByte(type);
	reader.ReadInt(value);
	reader.ReadVector3(pos);
	reader.ReadFloat(dir);

	gLevel->pickup_manager->AddSupplyNew(id, pos,  Quaternion(Vector3(0, 1, 0), dir),(PickUpManager::SupplyType)type, value);

	//ENCODE_END
}

// parse pick up supply object new
void ChannelConnection::ParsePickUpSupplyObjectNew(Core::BinaryNetworkReader & reader)
{
	//ENCODE_START

	int player_id;
	int supply_id;

	byte supply_type;

	reader.ReadInt(player_id);
	reader.ReadInt(supply_id);
	reader.ReadByte(supply_type);

	tempc_ptr(Character) viewer = gLevel->GetViewer();
	tempc_ptr(Character) c = gLevel->GetCharacter(player_id);

	if (gLevel->pickup_manager && supply_type != PickUpManager::kSupplyMedkit && supply_type != PickUpManager::kSupplyAllTools)
		gLevel->pickup_manager->RemovePickUpSupplyNew(supply_id);

	if(viewer && c)
	{
		if(viewer == c)
		{
			switch(supply_type)
			{
			case PickUpManager::kSupplyNone:				
				break;
			case PickUpManager::kSupplyHp:
			case PickUpManager::kSupplyAllTools:
				FmodSystem::PlayEvent("bj/item/2d/pickup_medic");
				break;
			case PickUpManager::kSupplyAmmo:
			case PickUpManager::kSupplyMedkit:
				FmodSystem::PlayEvent("bj/item/2d/pickup_ammo");
				break;
				break;
			}
		}
		else
		{
			float length = 0.f;
			length = Core::Length(viewer->GetPosition() - c->GetPosition());

			if (length < 15.f)
			{
				FMOD_VECTOR vel = {0, 0, 0};
				switch(supply_type)
				{
				case PickUpManager::kSupplyNone:				
					break;
				case PickUpManager::kSupplyHp:
				case PickUpManager::kSupplyAllTools:
					FmodSystem::Play3DEvent("bj/item/3d/pickup_medic",(const FMOD_VECTOR &)c->GetPosition(),vel);
					break;
				case PickUpManager::kSupplyAmmo:
				case PickUpManager::kSupplyMedkit:
					FmodSystem::Play3DEvent("bj/item/3d/pickup_ammo",(const FMOD_VECTOR &)c->GetPosition(),vel);
					break;
				}
			}
		}
	}
	//ENCODE_END
}

// parse syn server script value
void ChannelConnection::ParseSynServerScriptValue(Core::BinaryNetworkReader & reader)
{
	if (!gLevel || !gLevel->level_eventmgr)
		return;

	byte full_syn;

	Core::String key;
	Core::String svalue;
	float fvalue;

	reader.ReadByte(full_syn);

	if (full_syn)
	{
		uint value_size;

		gLevel->level_eventmgr->ClearServerScriptValue();

		reader.ReadInt(value_size);
		for (uint i = 0; i < value_size; i++)
		{
			reader.ReadString(key);
			reader.ReadString(svalue);

			gLevel->level_eventmgr->SetServerScriptStringValue(key, svalue);

			//Core::LogSystem.WriteLinef("full_syn: k : %s, sv : %s", key, svalue);
		}

		reader.ReadInt(value_size);
		for (uint i = 0; i < value_size; i++)
		{
			reader.ReadString(key);
			reader.ReadFloat(fvalue);

			gLevel->level_eventmgr->SetServerScriptNumberValue(key, fvalue);

			//Core::LogSystem.WriteLinef("full_syn: k : %s, fv : %f", key, fvalue);
		}
	}
	else
	{
		uint value_size;

		reader.ReadInt(value_size);
		for (uint i = 0; i < value_size; i++)
		{
			reader.ReadString(key);
			reader.ReadString(svalue);

			gLevel->level_eventmgr->SetServerScriptStringValue(key, svalue);

			//Core::LogSystem.WriteLinef("diff_syn: k : %s, sv : %s", key, svalue);
		}

		reader.ReadInt(value_size);
		for (uint i = 0; i < value_size; i++)
		{
			reader.ReadString(key);
			reader.ReadFloat(fvalue);

			gLevel->level_eventmgr->SetServerScriptNumberValue(key, fvalue);

			//Core::LogSystem.WriteLinef("diff_syn: k : %s, fv : %f", key, fvalue);
		}
	}
}

// parse synscore
void ChannelConnection::ParseSynScore(Core::BinaryNetworkReader & reader)
{
	byte uid;
	int score;

	reader.ReadByte(uid);
	reader.ReadInt(score);

	tempc_ptr(Character) c = gLevel->GetCharacter(uid);
	if (c)
	{
		c->all_score = score;
	}
}

void ChannelConnection::ParseMessageClient(Core::BinaryNetworkReader & reader)
{
	Core::String str;
	reader.ReadString(str);
	LogSystem.WriteLinef("server_log : %s", str.Str());
}

// parse add supply
void ChannelConnection::ParseAddSupplyObject(Core::BinaryNetworkReader & reader)
{
	//ENCODE_START

	uint id;
	Vector3 pos;
	float dir;
	byte type;
	byte from_id;
	Vector3 force = Vector3(0,0,0);
	short team;

	reader.ReadInt(id);
	reader.ReadVector3(pos);
	reader.ReadFloat(dir);
	reader.ReadByte(type);
	reader.ReadByte(from_id);
	reader.ReadShort(team);


	if (type == PickUpManager::kSupplyGold)
		gLevel->isneedparticle = true;

	if (type == PickUpManager::kSupplyGoldWithForce)
	{
		tempc_ptr(Character) tempC;

		if(gLevel&&gLevel->GetPlayer()&& gLevel->GetPlayer()->uid == from_id)
		{
			tempC = gLevel->GetPlayer();
		}
		else
		{
			const Array<sharedc_ptr(Character)> & characters = gLevel->GetCharacters();
			for (U32 i = 0; i < characters.Size(); i++)
			{
				if (characters[i] && characters[i]->uid == from_id)
				{
					tempC = characters[i];
					break;
				}
			}
		}

		if(tempC)
		{
			Vector3 vDir = pos;
			vDir.y = 0;
			vDir.Normalize();
			Quaternion qRot = Quaternion(Vector3(0,1,0), dir);
			vDir = vDir * qRot;
			vDir.Normalize();

			pos = tempC->GetPosition() + Vector3( -vDir.x * 2.5f, 5.f, -vDir.z * 2.5f);

			force = -vDir;
		}
		
		dir = 0.f;

		force = 4.f * force +  Vector3(0.f, 15.f, 0.f);
	}
	else if(type == PickUpManager::kSupplyZombieGold)
	{
		force = Vector3(0,5.0f,0);
	}

	if (gLevel->pickup_manager)
		gLevel->pickup_manager->AddSupply(id, pos,  Quaternion(Vector3(0, 1, 0), dir),(PickUpManager::SupplyType)type, force, team);

	tempc_ptr(Character) viewer = gLevel->GetViewer();
	if(viewer)
	{
		viewer->supply_object_time = 1.5f;
		viewer->supply_object_alpha = 1.0f;
		viewer->supply_object_flag = true;
		viewer->supply_object_id = 19;
	}

	//ENCODE_END
}

// parse pick up supply object
void ChannelConnection::ParsePickUpSupplyObject(Core::BinaryNetworkReader & reader)
{
	//ENCODE_START

	int player_id;
	int supply_id;
	
	byte supply_type;
	int score = 0;

	byte common_zombie_item_type;
	float common_zombie_item_time;

	reader.ReadInt(player_id);

	reader.ReadInt(supply_id);
	reader.ReadByte(supply_type);
	reader.ReadInt(score);
	tempc_ptr(Character) viewer = gLevel->GetViewer();
	tempc_ptr(Character) c = gLevel->GetCharacter(player_id);
	tempc_ptr(Character) play = gLevel->GetPlayer();
	
	if (gLevel->game_type == RoomOption::kCommonZombieMode)
	{
		reader.ReadByte(common_zombie_item_type);
		reader.ReadFloat(common_zombie_item_time);
		tempc_ptr(StateMainGame) state_main = ptr_dynamic_cast<StateMainGame>(gGame->machine.CurrentState());
		if (c == play && state_main && state_main->ui)
		{
			state_main->ui->OnAddSkillItem(common_zombie_item_type,common_zombie_item_time);
			FMOD_VECTOR vel = {0, 0, 0};
			FmodSystem::Play3DEvent("bj/item/3d/pickup_item",(const FMOD_VECTOR &)c->GetPosition(),vel);
			//FmodSystem::PlayEvent("bj/item/2d/pickup_item");
		}
		if (c != play)
			FmodSystem::PlayEvent("bj/item/2d/pickup_item");
		if (common_zombie_item_type == 8)
		{
			c->can_Invincible = true;
		}
	}
	else if (gLevel->game_type == RoomOption::kSurvivalMode && play == c)
	{
		tempc_ptr(StateMainGame) state_main = ptr_dynamic_cast<StateMainGame>(gGame->machine.CurrentState());
		if (play->isghost)
		{
			play->ghostfirecount += 5;
			FmodSystem::PlayEvent("bj/fx/2d/survival_get_ghost_fire");

		}
		else
		{
			SurvivalModeItemInfo iteminfo;
			reader.ReadString(iteminfo.name);
			reader.ReadString(iteminfo.icon);
			reader.ReadFloat(iteminfo.value);
			iteminfo.sid = supply_id;
			iteminfo.type = supply_type;
			if ( supply_type == PickUpManager::kSupplySurvivalItemHp )
			{
				if ( iteminfo.value  == 50 )
				{
					state_main->ui->m_Showmiddle_str_time = 3.0f;
					state_main->ui->m_Middle_str = gLang->GetTextW(L"�����������+50%����");
				}
				else if( iteminfo.value == 80 )
				{
					state_main->ui->m_Showmiddle_str_time = 3.0f;
					state_main->ui->m_Middle_str = gLang->GetTextW(L"�����������+80%����");
				}
			}
			else if ( supply_type == PickUpManager::kSupplySurvivalItemAmmo )
			{
				if ( iteminfo.value == 30 )
				{
					state_main->ui->m_Showmiddle_str_time = 3.0f;
					state_main->ui->m_Middle_str = gLang->GetTextW(L"����ӵ�����+30%����");
				}
				else if( iteminfo.value == 100 )
				{
					state_main->ui->m_Showmiddle_str_time = 3.0f;
					state_main->ui->m_Middle_str = gLang->GetTextW(L"����ӵ�����+100%����");
				}
			}
			else if ( supply_type == PickUpManager::kSupplySurvivalItemTrapAmmo )
			{
				state_main->ui->m_Showmiddle_str_time = 3.0f;
				state_main->ui->m_Middle_str = gLang->GetTextW(L"�����һ���ӵ�͵���������");
			}
			else if ( supply_type == PickUpManager::kSupplySurvivalItemTrapHP )
			{
				state_main->ui->m_Showmiddle_str_time = 3.0f;
				state_main->ui->m_Middle_str = gLang->GetTextW(L"�����һ������͵���������");
			}
			else if ( supply_type == PickUpManager::kSupplySurvivalItemTrapExpose )
			{
				state_main->ui->m_Showmiddle_str_time = 3.0f;
				state_main->ui->m_Middle_str = gLang->GetTextW(L"�����һ�������������");
			}
			else if ( supply_type == PickUpManager::kSupplySurvivalItemTrapBomb )
			{
				state_main->ui->m_Showmiddle_str_time = 3.0f;
				state_main->ui->m_Middle_str = gLang->GetTextW(L"�����һ�������˺��������");
			}
			else if ( supply_type == PickUpManager::kSupplySurvivalItemTrapDebuff )
			{
				state_main->ui->m_Showmiddle_str_time = 3.0f;
				state_main->ui->m_Middle_str = gLang->GetTextW(L"�����һ���˺������������");
			}
			else if ( supply_type == PickUpManager::kSupplySurvivalIteminitiative )
			{
				state_main->ui->m_Showmiddle_str_time = 3.0f;
				state_main->ui->m_Middle_str = gLang->GetTextW(L"�����һ���޵е���");
			}
			play->basecharacter_info->AddItemInfo(iteminfo);
		}
	}

	if (gLevel->pickup_manager && supply_type != PickUpManager::kSupplyMedkit && supply_type != PickUpManager::kSupplyAllTools)
			gLevel->pickup_manager->RemovePickUpSupply(supply_id);

	if(viewer && c)
	{
		if(viewer == c)
		{
			switch(supply_type)
			{
			case PickUpManager::kSupplyNone:				
				break;
			case PickUpManager::kSupplyHp:
			case PickUpManager::kSupplyAllTools:
					FmodSystem::PlayEvent("bj/item/2d/pickup_medic");
				break;
			case PickUpManager::kSupplyAmmo:
			case PickUpManager::kSupplyMedkit:
					FmodSystem::PlayEvent("bj/item/2d/pickup_ammo");
				break;
			case PickUpManager::kSupplyGoldWithForce:
			case PickUpManager::kSupplyGold:
			case PickUpManager::kSupplyZombieGold:
			case PickUpManager::kSupplyCCoin:
			case PickUpManager::kSupplyMedal:
			case PickUpManager::kSupplyWrench:
			case PickUpManager::kSupplyRandomBox1:
			case PickUpManager::kSupplyRandomBox2:
			case PickUpManager::kSupplyRandomBox3:
			case PickUpManager::kSupplyRandomBox4:
			case PickUpManager::kSupplySurvivalItemHp:
			case PickUpManager::kSupplySurvivalItemAmmo:
			case PickUpManager::kSupplySurvivalItemTrapAmmo:
			case PickUpManager::kSupplySurvivalItemTrapHP:
			case PickUpManager::kSupplySurvivalItemTrapExpose:
			case PickUpManager::kSupplySurvivalItemTrapBomb:
			case PickUpManager::kSupplySurvivalItemTrapDebuff:
			case PickUpManager::kSupplySurvivalIteminitiative:
				FmodSystem::PlayEvent("bj/event/get_goldcoin");
				break;
			}
		}
		else
		{
			float length = 0.f;
			length = Core::Length(viewer->GetPosition() - c->GetPosition());
	
			if (length < 15.f)
			{
				FMOD_VECTOR vel = {0, 0, 0};
				switch(supply_type)
				{
				case PickUpManager::kSupplyNone:				
					break;
				case PickUpManager::kSupplyHp:
				case PickUpManager::kSupplyAllTools:
					FmodSystem::Play3DEvent("bj/item/3d/pickup_medic",(const FMOD_VECTOR &)c->GetPosition(),vel);
					break;
				case PickUpManager::kSupplyAmmo:
				case PickUpManager::kSupplyMedkit:
					FmodSystem::Play3DEvent("bj/item/3d/pickup_ammo",(const FMOD_VECTOR &)c->GetPosition(),vel);
					break;
				//case PickUpManager::kSupplyGold:
				//	FmodSystem::PlayEvent("bj/event/get_goldcoin");
				//	break;
				}
			}
		}
	}

	if(viewer == c)
	{
		switch(supply_type)
		{
		case PickUpManager::kSupplyCCoin:
			{
				play->advBoxNum[0]++;
				play->advBoxTime[0] = 0.5f;
			}
			break;
		case PickUpManager::kSupplyMedal:
			{
				play->advBoxNum[1]++;
				play->advBoxTime[1] = 0.5f;
			}
			break;
		case PickUpManager::kSupplyWrench:
			{
				play->advBoxNum[2]++;
				play->advBoxTime[2] = 0.5f;
			}
			break;
		case PickUpManager::kSupplyRandomBox1:
		case PickUpManager::kSupplyRandomBox2:
		case PickUpManager::kSupplyRandomBox3:
		case PickUpManager::kSupplyRandomBox4:
			{
				play->advBoxNum[3]++;
				play->advBoxTime[3] = 0.5f;
			}
			break;
		}
	}

	if (score != 0)
	{
		bool isPass = false;
		if (c && c->all_score < score)
		{
			if (c->all_score == score)
				isPass = true;
			else if (c == gLevel->GetPlayer())
			{
				c->kill_showscore = score - c->all_score;
				c->kill_score_time = 0.f;
			}
			c->all_score = score;
		}

		tempc_ptr(Character) player = gLevel->GetPlayer();
		if (player && c && player == c && player->ui_score_line >= 0 && player->ui_score_line < 3)
		{
			AddEnergyEffectInfo &info = player->energy_bar_info;
			if (player->all_score < player->get_score && !isPass)
			{
				info.move_time = 0.0f;
				info.move_all_time = 0.75f;

				info.all_value = 1.0f;
				info.current_value = info.current_target_value;
				info.current_target_value = Core::Clamp((player->all_score - player->get_last_score)/(player->get_score - player->get_last_score),0,1);
			}
			else if (!isPass)
			{
				player->UpdateUiScoreLine();

				info.move_time = 0.0f;
				info.move_all_time = 0.75f;

				info.all_value = 1.0f;
				info.current_value = info.current_target_value;
				info.current_target_value = Core::Clamp((player->all_score - player->get_last_score)/(player->get_score - player->get_last_score),0,1);
			}
		}
	}

	//ENCODE_END
}

// parse destroy supply object
void ChannelConnection::ParseDestroySupplyObject(Core::BinaryNetworkReader & reader)
{
	//ENCODE_START

	uint uid;
	reader.ReadInt(uid);

	if (gLevel->pickup_manager)
		gLevel->pickup_manager->RemovePickUpSupply(uid);

	//ENCODE_END
}

// parse select weapon
void ChannelConnection::ParseSelectWeapon(Core::BinaryNetworkReader & reader)
{
	//ENCODE_START

	byte uid;
	byte weapon_id;

	reader.ReadByte(uid);
	reader.ReadByte(weapon_id);

	tempc_ptr(Character) character = gLevel->GetCharacter(uid);
	tempc_ptr(Character) player = gLevel->GetPlayer();
	if (character)
	{
		if(player != character || state == kInReplay)
		{
			character->RevertToRawCharacterChangeableInfo();
			character->SelectWeapon(weapon_id);
		}	
	}

	//ENCODE_END
}

// parse pick up gun
void ChannelConnection::ParsePickUpWeapon(Core::BinaryNetworkReader & reader)
{
	//ENCODE_START

	byte uid;
	byte weapon_id;
	int ammo_in_clip;
	int ammo_count;

	reader.ReadByte(uid);
	reader.ReadByte(weapon_id);
	reader.ReadInt(ammo_in_clip);
	reader.ReadInt(ammo_count);
	sharedc_ptr(WeaponInfo) weapon_info = ReadWeapon(reader);

	if (weapon_info)
	{
		tempc_ptr(Character) chara = gLevel->GetCharacter(uid);
		if (chara)
		{
			tempc_ptr(Character) viewer = gLevel->GetViewer();

			if(viewer && chara == viewer)
			{				
				if(weapon_info->weapon_type == kWeaponTypeBomb)
				{
					tempc_ptr(StateMainGame) state_main = ptr_dynamic_cast<StateMainGame>(gGame->machine.CurrentState());
					if(state_main && state_main->ui)
						state_main->ui->tip_effect_list.Clear();
					
					viewer->current_pickup_object_type_list.PushBack(1);
					viewer->current_pickup_object_list.PushBack(gLevel->skill_img[10]);

					viewer->current_pickup_object_type_list.PushBack(6);
					viewer->current_pickup_object_list.PushBack(gLevel->skill_img[10]);

					viewer->current_pickup_object_name.PushBack(weapon_info->name);

					viewer->is_display_c4_tip = false;
				}
				else
				{
					tempc_ptr(StateMainGame) state_main = ptr_dynamic_cast<StateMainGame>(gGame->machine.CurrentState());
					if(state_main && state_main->ui)
						state_main->ui->tip_effect_list.Clear();

					viewer->current_pickup_object_type_list.PushBack(0);
					viewer->current_pickup_object_list.PushBack(weapon_info->icon);

					viewer->current_pickup_object_type_list.PushBack(5);

					viewer->current_pickup_object_list.PushBack(weapon_info->icon);

					viewer->current_pickup_object_name.PushBack(weapon_info->name);

					viewer->is_display_weapon_list = false;
				}

				if(weapon_info->weapon_type == kWeaponTypeBomb)
				{
					//viewer->supply_object_time = 1.5f;
					//viewer->supply_object_alpha = 1.0f;
					//viewer->supply_object_flag = true;
					//viewer->supply_object_id = 21;
				}
			}

			tempc_ptr(GunInfo) gun = ptr_dynamic_cast<GunInfo>(weapon_info);
			if (gun)
			{
				gun->ammo_in_clip = ammo_in_clip;
				gun->ammo_count = ammo_count;
			}
			chara->PickUpWeapon(weapon_id, weapon_info);
		}
	}

	//ENCODE_END
}

// parse dropped gun destroy
void ChannelConnection::ParseDroppedWeaponDestroy(Core::BinaryNetworkReader & reader)
{
	//ENCODE_START

	uint uid;
	reader.ReadInt(uid);

	if (gLevel->pickup_manager)
		gLevel->pickup_manager->RemovePickUpWeapon(uid);

	//ENCODE_END
}

// parse grenade hurt
void ChannelConnection::ParseGrenadeHurt(Core::BinaryNetworkReader & reader)
{
	//ENCODE_START

	byte uid;
	byte hurt_uid;
	bool isboost;
	reader.ReadByte(uid);
	reader.ReadByte(hurt_uid);

	Vector3 grenade_pos;
	reader.ReadVector3(grenade_pos);
	reader.ReadByte((byte&)isboost);
	if (hurt_uid)
	{
		tempc_ptr(Character) c = gLevel->GetCharacter(hurt_uid);

		tempc_ptr(Character) h = gLevel->GetCharacter(uid);

		if(h)
			h->is_shoot_stab = false;

		TakeDamage(reader, h, c, grenade_pos,false,isboost);

		if (c)
			c->ResponseHit(grenade_pos, Vector3::kZero, Vector3::kZero, kCharacterPartTorso,kWeaponTypeGrenade, true);
	}

	//ENCODE_END
}

// parse hurt
void ChannelConnection::ParseSelfHurt(Core::BinaryNetworkReader & reader)
{
	//ENCODE_START

	byte uid;
	reader.ReadByte(uid);

	tempc_ptr(Character) character = gLevel->GetCharacter(uid);

	if (character)
	{
		character->is_shoot_stab = false;

		TakeDamage(reader, character, character, character->GetPosition(), true);
	}

	//ENCODE_END
}

// parse hurt
void ChannelConnection::ParseSkillHurt(Core::BinaryNetworkReader & reader)
{
	//ENCODE_START

	byte uid;
	byte uid_from;
	reader.ReadByte(uid);
	reader.ReadByte(uid_from);

	tempc_ptr(Character) to = gLevel->GetCharacter(uid);
	tempc_ptr(Character) from = gLevel->GetCharacter(uid_from);

	if (to)
	{
		to->is_shoot_stab = false;

		TakeDamage(reader, from, to, to->GetPosition(), true);
	}

	//ENCODE_END
}

void ChannelConnection::ParseControlPerson(Core::BinaryNetworkReader & reader)
{
	//ENCODE_START

	byte uid;
	reader.ReadByte(uid);

	tempc_ptr(Character) to = gLevel->GetCharacter(uid);
	tempc_ptr(Character) player = gLevel->GetPlayer();
	if (to && player)
	{
		for (uint team = 0; team < 3; team ++)
		{
			for (uint rank = 0; rank < gGame->scores->teams[team].Size(); rank ++)
			{
				Character * c = gGame->scores->teams[team][rank];
				c->GetThirdPerson().showcontrol = false;
			}
		}
		to->GetThirdPerson().showcontrol = true;
		player->control_person_id = uid;
	}

	//ENCODE_END
}

void ChannelConnection::ParseRevengPerson(Core::BinaryNetworkReader & reader)
{
	//ENCODE_START

	byte from_uid;
	byte to_uid;
	reader.ReadByte(from_uid);
	reader.ReadByte(to_uid);

	tempc_ptr(Character) from = gLevel->GetCharacter(from_uid);
	tempc_ptr(Character) to = gLevel->GetCharacter(to_uid);
	tempc_ptr(Character) player = gLevel->GetPlayer();
	if (from && to && player == to)
	{
		from->GetThirdPerson().showrevenge = true;
		player->array_reveng_id.PushBack(from_uid);
	}

	//ENCODE_END
}

void ChannelConnection::ParseSustainHurt(Core::BinaryNetworkReader & reader)
{
	//ENCODE_START

	byte uid;
	byte fromuid;

	reader.ReadByte(uid);
	reader.ReadByte(fromuid);

	tempc_ptr(Character) to = gLevel->GetCharacter(uid);
	tempc_ptr(Character) from = gLevel->GetCharacter(fromuid);
	if(to && from)
		TakeSustainDamage(reader, from, to);


	//ENCODE_END
}

void ChannelConnection::ParseSyncTime(Core::BinaryNetworkReader & reader)
{
	int time;
	reader.ReadInt(time);
	gGame->round_time = time;
	if (time > 0)
		gGame->m_second = 1.0f;
}

// parse game end
void ChannelConnection::ParseGameEnd(Core::BinaryNetworkReader & reader)
{
	//ENCODE_START

	byte team;
	reader.ReadByte(team);
	if (gLevel->game_type == RoomOption::kBoss)
		gGame->global->SystemMessage(String::Format(gLang->GetTextW(L"��Ϸ������%sʤ��"), team == 0 ? gLang->GetTextW(L"����") : "BOSS"), "/info");
	else if (gLevel->game_type == RoomOption::kBossPVE)
		gGame->global->SystemMessage(String::Format(gLang->GetTextW(L"��Ϸ������%sʤ��"), team == 0 ? gLang->GetTextW(L"����") : "BOSS"), "/info");
	else if (gLevel->game_type == RoomOption::kCommonZombieMode || gLevel->game_type == RoomOption::kZombieMode)
		gGame->global->SystemMessage(String::Format(gLang->GetTextW(L"��Ϸ������%sʤ��"), team == 0 ? gLang->GetTextW(L"����") : gLang->GetTextW(L"����")), "/info");
	else
	{
		if (team != 0 && team != 1)
			gGame->global->SystemMessage(gLang->GetTextW(L"��Ϸ������˫��ƽ�֣���սʧ��"),"/info");
		else
			gGame->global->SystemMessage(String::Format(gLang->GetTextW(L"��Ϸ������%sʤ��"), team == 0 ? gLang->GetTextW(L"���") : gLang->GetTextW(L"����")), "/info");
	}
	game_win_team = team;

	if (gLevel->audio_background)
	{
		gLevel->audio_background->stop(true);
		gLevel->audio_background = NULL;
	}
	if (gLevel->audio_Survival_background)
	{
		gLevel->audio_Survival_background->stop(true);
		gLevel->audio_Survival_background = NULL;
	}
	if (gLevel->audio_bossmode2_background)
	{
		gLevel->audio_bossmode2_background->stop(true);
		gLevel->audio_bossmode2_background = NULL;
	}
	if (gLevel->audio_killing_background)
	{
		gLevel->audio_killing_background->stop(true);
		gLevel->audio_killing_background = NULL;
	}
	if (gLevel->audio_chrismas_background)
	{
		gLevel->audio_chrismas_background->stop(true);
		gLevel->audio_chrismas_background = NULL;
	}
	tempc_ptr(Character) viewer = gLevel->GetViewer();
	tempc_ptr(Character) player = gLevel->GetPlayer();
	player->advBoxTime[0] = 0.5f;
	player->advBoxTime[1] = 1.f;
	player->advBoxTime[2] = 1.5f;
	player->advBoxTime[3] = 2.f;
	//banner win count down explode time
	if(viewer)
	{
		// play sound
		if(viewer->GetTeam() == game_win_team)
			FmodSystem::PlayEvent("bj/event/game_win");
		else
			FmodSystem::PlayEvent("bj/event/game_lose");
	}

	OnGameEnd();
	
	if(gGame && gGame->lobby_connection)
	{
		gGame->lobby_connection->CollectionInGameInfo();
	}
	

	//ENCODE_END
}

// parse game leave
void ChannelConnection::ParseGameLeave(Core::BinaryNetworkReader & reader)
{
	//ENCODE_START

	byte stage_clear;
	int reason;
	reader.ReadByte(stage_clear);
	reader.ReadInt(reason);
	OnLeaveGame(stage_clear != 0, reason);
	//ENCODE_END
}

// parse round start
void ChannelConnection::ParseRoundStart(Core::BinaryNetworkReader & reader)
{
	//ENCODE_START
	gLevel->spray_set.Clear();
	gLevel->bomb_on_ground = false;

	reader.ReadFloat(gLevel->round_start_wait_time);
	reader.ReadFloat(gLevel->round_total_time);
	//gLevel->round_start_wait_time -= 1.5f;
	//gLevel->round_total_time -= 1.5f;

	round_win_team = -1;
	gLevel->RoundStart();

	if(state == kInReplay)
		return;

	tempc_ptr(Character) character = gLevel->GetPlayer();
	if(character)
	{
		character->gamestart_ui = false;
		character->gamestart_time = gLevel->round_start_wait_time;
		if (gLevel->game_type == RoomOption::kNovice)
		{
			gLevel->novice_index = 1;
			gLevel->novice_timer = 5.0f;
			gLevel->novice_need_timer = true;
		}

		tempc_ptr(Character) viewer = gLevel->GetViewer();
		if (viewer && viewer->GetWeapon())
		{
			tempc_ptr(MiniMachineGun) gun = ptr_dynamic_cast<MiniMachineGun>(viewer->GetWeapon());
			if (gun && gun->mini_gun_audio_spin_fire)
				gun->mini_gun_audio_spin_fire->stop();
			if (gun && gun->mini_gun_audio_spin_fire_3d)
				gun->mini_gun_audio_spin_fire_3d->stop();
			const FirstPerson & first_person = viewer->GetFirstPerson();
			if(first_person.animation_group && gun)
				first_person.animation_group->StopAction();
			viewer->keep_Shoot_mini = false;
			gGame->channel_connection->PlayerAnimationEnd(kWeaponTypeMiniMachineGun);
			viewer->StopShoot();
		}
	}
	
	//ENCODE_END
}

// parse round start play
void ChannelConnection::ParseRoundStartPlay(Core::BinaryNetworkReader & reader)
{
	//ENCODE_START

	gLevel->round_start_wait_time = 0;
	gLevel->round_start_waiting = false;
	gLevel->Reset();

	tempc_ptr(Character) character = gLevel->GetPlayer();
	tempc_ptr( StateMainGame ) state_main = ptr_dynamic_cast<StateMainGame>(gGame->machine.CurrentState());
	if(character)
	{
		if (gGame->scores->team_round[0] == 0 && gGame->scores->team_round[1] == 0)
			FmodSystem::PlayEvent("bj/event/game_start");
		else
			FmodSystem::PlayEvent("bj/event/gameset_start");
		character->gamestart_ui = true;
		character->gamestart_time = 0.0f;
		
		if( RoomOption::kSurvivalMode == gLevel->game_type )
		{
			state_main->ui->m_Showmiddle_str_time = 5.0f;
			state_main->ui->m_Middle_str = gLang->GetTextW(L"Ѱ����Դս��");
		}
	}

	//ENCODE_END
}

// parse round end
void ChannelConnection::ParseRoundEnd(Core::BinaryNetworkReader & reader)
{
	//ENCODE_START

	reader.ReadInt(gGame->scores->team_round[0]);
	reader.ReadInt(gGame->scores->team_round[1]);

	byte team = 0;
	reader.ReadByte(team);

	if (team < 2)
	{
		round_win_team = team;

		if (gLevel->GetPlayer()->GetTeam() == round_win_team)
		{
			FmodSystem::PlayEvent("bj/event/gameset_win");
		}
		else
		{
			FmodSystem::PlayEvent("bj/event/gameset_lose");
		}
	}
	else
	{
		round_win_team = -1;
		gGame->global->SystemMessage(String::Format(gLang->GetTextW(L"�غϽ�����ƽ��")), "/info");
	}

	gLevel->RoundEnd();

	//ENCODE_END
}

// parse set team
void ChannelConnection::ParseSetTeam(Core::BinaryNetworkReader & reader)
{
	//ENCODE_START

	byte uid;
	byte team;

	reader.ReadByte(uid);
	reader.ReadByte(team);

	tempc_ptr(Character) character = gLevel->GetCharacter(uid);
	if (character)
	{
		character->SetTeam(team);

		tempc_ptr(Character) c = ptr_dynamic_cast<Character>(character);
		if (c)
		{
			if (c == gLevel->GetPlayer())
			{
				gPhysxScene->setGroupCollisionFlag(PhysxSystem::kPlayer, PhysxSystem::kGroupStart + team, false);
				gPhysxScene->setGroupCollisionFlag(PhysxSystem::kPlayer, PhysxSystem::kGroupEnd - team, true);
				gPhysxScene->setGroupCollisionFlag(PhysxSystem::kPlayer, PhysxSystem::kGroupProjectStart + team, false);
				gPhysxScene->setGroupCollisionFlag(PhysxSystem::kPlayer, PhysxSystem::kGroupProjectEnd - team, true);

				c->SetPhysxGroup(PhysxSystem::kPlayer);
			}
			else
				c->SetPhysxGroup(team + PhysxSystem::kGroupStart);
		}
	}

	//ENCODE_END
}

// parse player spawn timing
void ChannelConnection::ParsePlayerSpawnTiming(Core::BinaryNetworkReader & reader)
{
	//ENCODE_START

	float time = 0;
	reader.ReadFloat(time);

	Character *pPlayer = gLevel->GetPlayer();
	if(pPlayer)
	{
		pPlayer->relife_flag = true;
		pPlayer->relife_time = 0.0f;
		pPlayer->relife_maxtime = time;
	}

	//ENCODE_END
}

// parse recover stop
void ChannelConnection::ParseRecoverStop(Core::BinaryNetworkReader & reader)
{
	//ENCODE_START

	byte uid;
	reader.ReadByte(uid);

	tempc_ptr(Character) c = gLevel->GetCharacter(uid);
	if (c)
	{
		c->RecoverStop();
	}

	//ENCODE_END
}

// parse flash bright
void ChannelConnection::ParseFlashBright(Core::BinaryNetworkReader & reader)
{
	//ENCODE_START

	byte uid;
	float bright_time;
	float fade_time;
	reader.ReadByte(uid);
	reader.ReadFloat(bright_time);
	reader.ReadFloat(fade_time);

	tempc_ptr(Character) c = gLevel->GetCharacter(uid);
	if (c)
		c->FlashBright(bright_time, fade_time);

	//ENCODE_END
}

// parse camera fov changed
void ChannelConnection::ParseCameraFovChanged(Core::BinaryNetworkReader & reader)
{
	//ENCODE_START

	byte uid;
	float fov;
	float target_fov;

	reader.ReadByte(uid);
	reader.ReadFloat(fov);
	reader.ReadFloat(target_fov);

	tempc_ptr(Character) c = gLevel->GetCharacter(uid);
	if (c)
	{
		if(c != gLevel->GetPlayer() || state == kInReplay)
		{
			c->SetCameraFov(fov, target_fov);
		}
		
	}
		

	//ENCODE_END
}

void ChannelConnection::ParseGameStartTimer(Core::BinaryNetworkReader & reader)
{
	int number;
	reader.ReadInt(number);
	gLevel->boss_starttimeer = number;

	if(number >= 0 && gLevel->game_type != RoomOption::kBossPVE)
	{
		Core::String str = Core::String::Format("bj/event/boss_countdown_%d",number);
		FmodSystem::PlayEvent(str.Str());
	}
}

// parse ammo recover
void ChannelConnection::ParseAmmoRecover(Core::BinaryNetworkReader & reader)
{
	//ENCODE_START

	byte uid;
	int weapon_id = 0;
	int ammo_count = 0;
	int count = 0;
	bool is_dummy;

	reader.ReadByte(uid);
	reader.ReadInt(weapon_id);
	reader.ReadInt(ammo_count);
	reader.ReadInt(count);
	reader.ReadByte((byte&)is_dummy);

	tempc_ptr(Character) c = gLevel->GetCharacter(uid);
	tempc_ptr(Character) viewer = gLevel->GetViewer();
	

	if(!is_dummy)
	{
		if (c)
		{
			sharedc_ptr(GunBase) now_gun = ptr_dynamic_cast<GunBase>(c->GetWeapon());
			sharedc_ptr(GunBase) gun = ptr_dynamic_cast<GunBase>(c->GetWeaponById(weapon_id));
			tempc_ptr(GunTowerBuilder) w = ptr_dynamic_cast<GunTowerBuilder> (c->GetWeaponById(weapon_id));
			if (w)
			{
				if (w->GetAmmoCount() != -1)
				{
					int temp = 0;	
					temp = w->GetMaxAmmoCount() - w->GetAmmoCount();
					w->SetAmmoCount(w->GetAmmoCount() + w->GetMaxAmmoCount() * count / 100);
					if (viewer == c && temp > 0)
					{
						tempc_ptr(StateMainGame) state_main = ptr_dynamic_cast<StateMainGame>(gGame->machine.CurrentState());
						if(state_main && state_main->ui)
							state_main->ui->AddBloodEffectData(0.8f, kSupplyAmmo_1,Core::Vector2(-280, -80), count);
						//c->AmmoRecover(ammo_count,kSupplyAmmo_1);
						FmodSystem::PlayEvent("bj/item/2d/pickup_ammo");
					}
				}
			}
			else
			{
				if (ammo_count == 0 || count == 0)
					return;
				if (gun)
				{
					int max_ammo_count = gun->gun_info->ammo_count;	
					int max_ammo_one_clip = gun->gun_info->ammo_one_clip;
					if (max_ammo_count > 0)
					{
						int temp = 0;						
						temp = ammo_count - gun->ammo_count;
						gun->ammo_count = ammo_count;
						if (viewer == c && temp > 0)
						{
							tempc_ptr(StateMainGame) state_main = ptr_dynamic_cast<StateMainGame>(gGame->machine.CurrentState());
							if(state_main && state_main->ui)
								state_main->ui->AddBloodEffectData(0.8f, kSupplyAmmo_1,Core::Vector2(-150, -80), count);
							c->AmmoRecover(ammo_count,kSupplyAmmo_1);	
							FmodSystem::PlayEvent("bj/item/2d/pickup_ammo");
						}
					}
					else if (max_ammo_one_clip > 0)
					{
						int temp = 0;
						temp = ammo_count - gun->ammo_in_clip;
						gun->ammo_in_clip = ammo_count;
						if (viewer == c && temp > 0)
						{
							tempc_ptr(StateMainGame) state_main = ptr_dynamic_cast<StateMainGame>(gGame->machine.CurrentState());
							if(state_main && state_main->ui)
								state_main->ui->AddBloodEffectData(0.8f, kSupplyAmmo_1,Core::Vector2(-150, -80), count);
							c->AmmoRecover(ammo_count,kSupplyAmmo_1);	
							FmodSystem::PlayEvent("bj/item/2d/pickup_ammo");
						}
					}
				}
			}
		}
	}
	else
	{
		tempc_ptr(MachineGunTurret) t  =  ptr_dynamic_cast<MachineGunTurret>(gLevel->dummy_object_set.Get(weapon_id, NullPtr));
		if(t)
		{
			int temp = 0;						
			temp = t->turret_info.max_ammo_count - t->GetAmmoCount();
			t->SetAmmoCount(t->GetAmmoCount() + t->turret_info.max_ammo_count * count / 100);
			if (viewer == c && temp > 0)
			{
				tempc_ptr(StateMainGame) state_main = ptr_dynamic_cast<StateMainGame>(gGame->machine.CurrentState());
				if(state_main && state_main->ui)
					state_main->ui->AddBloodEffectData(0.8f, kSupplyAmmo_1,Core::Vector2(-280, -80), count);
				//c->AmmoRecover(ammo_count,kSupplyAmmo_1);
				FmodSystem::PlayEvent("bj/item/2d/pickup_ammo");
			}
		}
	}

	//ENCODE_END
}

void ChannelConnection::ParseAmmoDisappear(Core::BinaryNetworkReader & reader)
{
	//ENCODE_START

	byte uid;

	reader.ReadByte(uid);

	tempc_ptr(Character) c = gLevel->GetCharacter(uid);
	tempc_ptr(Character) viewer = gLevel->GetViewer();
	if (c)
	{
		sharedc_ptr(GunBase) now_gun = ptr_dynamic_cast<GunBase>(c->GetWeapon());
		sharedc_ptr(GunBase) gun = ptr_dynamic_cast<GunBase>(c->GetWeaponById(0));
		tempc_ptr(GunTowerBuilder) w = ptr_dynamic_cast<GunTowerBuilder> (c->GetWeaponById(0));
		if (w)
		{
			w->SetAmmoCount(0);
		}
		else
		{
			if (gun)
			{
				gun->ammo_count = 0;
				gun->ammo_in_clip = 0;
			}
		}
	}
	tempc_ptr(MachineGunTurret) t  =  ptr_dynamic_cast<MachineGunTurret>(gLevel->dummy_object_set.Get(0, NullPtr));
	if(t)
	{
		t->SetAmmoCount(0);
	}

	//ENCODE_END
}

void ChannelConnection::ParseTrap_HP_Disappear(Core::BinaryNetworkReader & reader)
{
	byte uid;
	reader.ReadByte(uid);
	tempc_ptr(Character) c = gLevel->GetCharacter(uid);
	if (c)
	{
		Core::LinkNode<SurvivalModeItemInfo>* node = c->basecharacter_info->survivalbag.Front();
		while(node)
		{
			if (node->data.type == PickUpManager::kSupplySurvivalItemHp)
			{
				c->basecharacter_info->survivalbag.Remove(node);
				node = c->basecharacter_info->survivalbag.Front();
			}
			else
			{
				node = node->GetNext();
			}
		}
	}
}

void ChannelConnection::ParseSurvivalMode_Ghost(Core::BinaryNetworkReader & reader)
{
	byte uid;
	int spawn_time;
	reader.ReadByte(uid);
	reader.ReadInt(spawn_time);
	tempc_ptr(Character) c = gLevel->GetCharacter(uid);
	by_ptr(Character) player = gLevel->GetPlayer();
	tempc_ptr(StateMainGame) state_main = ptr_dynamic_cast<StateMainGame>(gGame->machine.CurrentState());
	if ( c )
	{
		c->isghost = true;
		c->basecharacter_info->survivalbag.Clear();
		if ( player->isghost == true && player== c )
		{
			FmodSystem::PlayEvent("bj/fx/2d/survival_be_a_ghost");	
			state_main->ui->m_Showmiddle_str_time = 3.0f;
			state_main->ui->m_Middle_str = gLang->GetTextW(L"���ѱ�����\nѰ������֮���ͷż���");
			player->spawntimebySurvival = spawn_time * 1.f;
		}
		HashSet<uint, sharedc_ptr(DummyObject)>::Enumerator it(gLevel->dummy_object_set);
		while (it.MoveNext())
		{
			tempc_ptr(DummyObject) d = it.Value();
			if(d->owner_id == c->uid && !d->need_stepfather)
			{
				gGame->channel_connection->RequestDummyObjectDestory(it.Key());
			}
		}
	
	}
}

// parse armor recover
void ChannelConnection::ParseArmorRecover(Core::BinaryNetworkReader & reader)
{
	//ENCODE_START

	byte uid;
	int armor;
	byte type;

	reader.ReadByte(uid);
	reader.ReadInt(armor);
	reader.ReadByte(type);

	tempc_ptr(Character) c = gLevel->GetCharacter(uid);
	tempc_ptr(Character) viewer = gLevel->GetViewer();

	if (c)
	{
	}

	//ENCODE_END
}

// parse skill achieve
void ChannelConnection::ParseSkillAchieve(Core::BinaryNetworkReader & reader)
{
	//ENCODE_START

	byte uid;
	reader.ReadByte(uid);

	//ENCODE_END
}

// parse supply ready
void ChannelConnection::ParseSupplyReady(Core::BinaryNetworkReader & reader)
{
	//ENCODE_START

	int supply_count;
	reader.ReadInt(supply_count);

	//ENCODE_END
}

// parse radio report
void ChannelConnection::ParseRadioReport(Core::BinaryNetworkReader & reader)
{
	//ENCODE_START
	
	byte uid;
	int radio_id;
	int radio_item;
	Core::String radio_avrname;
	reader.ReadByte(uid);
	reader.ReadInt(radio_id);
	reader.ReadInt(radio_item);
	reader.ReadString(radio_avrname);

	tempc_ptr(Character) c = gLevel->GetCharacter(uid);
	tempc_ptr(Character) viewer = gLevel->GetViewer();

	if (c && viewer && c->GetTeam() == viewer->GetTeam())
	{
		Console.WriteLinef("radio play %s",radio_avrname);
		c->RadioPlay(radio_id,radio_item,radio_avrname);
		//RadioData item;
		//item.anim_id = 0;
		//item.pos = c->GetPosition();
		//item.pertime = 0.05f;
		//item.time = 0.0f;

		//viewer->radio_effect_list.Add(item);
	}

	//ENCODE_END
}

// parse action on
void ChannelConnection::ParseActionOn(Core::BinaryNetworkReader & reader)
{
	//ENCODE_START

	byte uid;
	int action_type;
	bool is_action_on;

	reader.ReadByte(uid);
	reader.ReadInt(action_type);
	reader.ReadByte((byte&)is_action_on);

	tempc_ptr(Character) c = gLevel->GetCharacter(uid);
	if (c)
	{
		switch (action_type)
		{
		case kActionFire:
			c->first_action_on = is_action_on;
			break;

		case kActionSecondFire:
			c->second_action_on = is_action_on;
			break;
		}
	}

	//ENCODE_END
}



// on message
void ChannelConnection::OnMessageGame(MessagePacket & packet)
{
	byte message_type = packet.GetMessageType();
	//LogSystem.WriteLinef("%s, %s, message type : %d, game_state : %d, state : %d", __FILE__, __FUNCTION__, message_type, game_state, state);
	switch (game_state)
	{
	case kAuthentication:
		{
			switch(message_type)
			{
			case SM_NotifyRoomHostChanged:	ParseNotifyRoomHostChanged(packet);	break;

			case SM_CharacterInfo:			ParseCharacterInfo(packet);	break;
			case SM_ClientJoin:				ParsePlayerJoin(packet);			break;
			case SM_ClientLeave:			ParsePlayerLeave(packet);			break;
			case SM_Authentication:			ParseAuthentication(packet);		break;
			case SM_AddDroppedWeapon:		ParseAddDroppedWeapon(packet);		break;
			case SM_AddSupplyObject:		ParseAddSupplyObject(packet);		break;
			case SM_DestroySupplyObject:	ParseDestroySupplyObject(packet);	break;
			case SM_DestroyDroppedWeapon:	ParseDroppedWeaponDestroy(packet);	break;
			case SM_AddDropSupply:			ParseAddDroppedSupply(packet);		break;
			case SM_SynServerScriptValue:	ParseSynServerScriptValue(packet);	break;
			case SM_MessageClient:			ParseMessageClient(packet);			break;
			case SM_ResponseRoomClientList:		ResponseRoomClientList(packet);	break;
			case SM_Loading:
				{
					game_state = kLoading;
				}
				break;

			default:
				{
					LogSystem.WriteLinef("%s, %s, message type : %d, game_state : %d, state : %d, error!!!!!!!!!!!11", __FILE__, __FUNCTION__, message_type, game_state, state);
				}break;
			}
		}
		break;

	case kWaiting:
	case kAlive:
	case kDied:
	case kGameLeaving:
	case kGameEnd:
		{
			switch(message_type)
			{
			case SM_NotifyRoomHostChanged:	ParseNotifyRoomHostChanged(packet);		break;

			case SM_NotifyGameLeave:		NotifyGameLeave();				break;

			case SM_CharacterInfo:			ParseCharacterInfo(packet);			break;
			case SM_Initialize:				ParseInitialize(packet);			break;
			case SM_ClientJoin:				ParsePlayerJoin(packet);			break;
			case SM_ClientLeave:			ParsePlayerLeave(packet);			break;
			case SM_SyncPlayerData:			ParseSyncCharacterData(packet);		break;
			case SM_PlayerSpawn:			ParseSpawn(packet);					break;
			case SM_BotSpawn:				ParseBotSpawn(packet);					break;
			case SM_PlayerPoke:				ParsePoke(packet);					break;
			case SM_PlayerPokeHurt:			ParsePokeHurt(packet);				break;
			case SM_PlayerShoot:			ParseShoot(packet);					break;
			case SM_PlayerGrenadeThrowIn:	ParseGrenadeThrowIn(packet);		break;
			case SM_PlayerGrenadeThrowStop:	ParseGrenadeThrowStop(packet);		break;
			case SM_PlayerGrenadeThrowOut:	ParseGrenadeThrowOut(packet);		break;
			case SM_PlayerHurt:				ParseSelfHurt(packet);				break;
			case SM_PlayerGrenadeHurt:		ParseGrenadeHurt(packet);			break;
			case SM_PlayerReload:			ParseReload(packet);				break;
			case SM_PlayerReloadReady:		ParseReloadReady(packet);			break;
			case SM_PlayerDropWeapon:		ParseDropWeapon(packet);			break;
			case SM_PlayerPickUpWeapon:		ParsePickUpWeapon(packet);			break;
			case SM_PlayerSelectWeapon:		ParseSelectWeapon(packet);			break;
			case SM_AddDroppedWeapon:		ParseAddDroppedWeapon(packet);		break;
			case SM_AddSupplyObject:		ParseAddSupplyObject(packet);		break;
			case SM_DestroySupplyObject:	ParseDestroySupplyObject(packet);	break;
			case SM_PickUpSupplyObject:		ParsePickUpSupplyObject(packet);	break;
			case SM_DestroyDroppedWeapon:	ParseDroppedWeaponDestroy(packet);	break;
			case SM_SyncTime:				ParseSyncTime(packet);				break;
			case SM_GameEnd:				ParseGameEnd(packet);				break;
			case SM_GameLeave:				ParseGameLeave(packet);				break;
			case SM_NotifyChat:				ParseNotifyChat(packet);			break;
			case SM_RoundStart:				ParseRoundStart(packet);			break;
			case SM_RoundStartPlay:			ParseRoundStartPlay(packet);		break;
			case SM_RoundEnd:				ParseRoundEnd(packet);				break;

			case SM_PlayerSetTeam:			ParseSetTeam(packet);				break;
			case SM_HealthRecover:			ParseHealthRecover(packet);			break;
			case SM_PlayerSpawnTiming:		ParsePlayerSpawnTiming(packet);		break;
			case SM_PlayerRecoverStop:		ParseRecoverStop(packet);			break;
			case SM_PlayerKickBack:			ParseKickBack(packet);				break;
			case SM_PlayerFlashBright:		ParseFlashBright(packet);			break;
			case SM_PlayerCameraFovChanged:	ParseCameraFovChanged(packet);		break;

			case SM_AmmoRecover:			ParseAmmoRecover(packet);			break;
			case SM_AmmoDisappear:			ParseAmmoDisappear(packet);			break;
			case SM_ArmorRecover:			ParseArmorRecover(packet);			break;

			case SM_UseSkill:				ParseUseSkill(packet);				break;
			case SM_UseCureSkill:			ParseUseCureSkill(packet);			break;
			case SM_ChangePack:				ParseChangePack(packet);			break;
			case SM_KickClientStart:		ParseKickClientStart(packet);		break;
			case SM_KickClientError:		ParseKickClientError(packet);		break;
			case SM_KickClientVote:			ParseKickClientVote(packet);		break;
			case SM_KickClientEnd:			ParseKickClientEnd(packet);			break;
			case SM_RadioReport:			ParseRadioReport(packet);			break;

			case SM_ProjectedAmmoOut:		ParseProjectedAmmoOut(packet);		break;
			case SM_ProjectedAmmoHurt:		ParseProjectedAmmoHurt(packet);		break;
			case SM_ProjectedProdHurt:		ParseProjectedProdHurt(packet);		break;
			case SM_ProjectedAmmoUpdate:	ParseProjectedAmmoUpdate(packet);	break;
			case SM_ProjectedAmmoDestroy:	ParseProjectedAmmoDestroy(packet);	break;
			case SM_PlayerAnimationStart:	ParsePlayerAnimationStart(packet);	break;
			case SM_PlayerAnimationEnd:		ParsePlayerAnimationEnd(packet);	break;
			case SM_CallDoctor:				ParseCallDoctor(packet);			break;
			case SM_SyncHoldPointInfo:		ParseSyncHoldPointInfo(packet);		break;
			case SM_InitializePushVehiclePointInfo: ParseInitializeVehicleInfo(packet); break;
			case SM_UpdatePushVehiclePointInfo: ParseUpdateVehicleInfo(packet); break;
			case SM_PlayerHitBack:				ParsePlayerHitBack(packet);		break;
			case SM_PlayerFlameShoot:		ParseFlameShoot(packet);			break;
			case SM_PlayerSustainHurt:		ParseSustainHurt(packet);			break;
			case SM_ControlPerson:			ParseControlPerson(packet);			break;
			case SM_RevengPerson:			ParseRevengPerson(packet);			break;
			case SM_NoviceOperation:		ParseNoviceOperation(packet);		break;
			case SM_Boss_Flash:				ParseBossFlash(packet);				break;
			case SM_Number_Timer:			ParseGameStartTimer(packet);		break;
			case SM_Cure_Power:				ParseCurePower(packet);				break;
			case SM_DrumEffect:				PareseDrumEffect(packet);			break;
			case SM_Drink:					PareseDrink(packet);				break;
			case SM_DummyObjectCreate:		ParseNotifyDummyObjectCreate(packet);break;
			case SM_DummyObjectDestory:		ParseNotifyDummyObjectDestory(packet);break;
			case SM_DummySyncUpdate:		ParseDummyObjectSyncUpdate(packet);	break;
			case SM_DummyChangeOwner:		PraseDummyChangeOwner(packet);		break;
			case SM_GunTowerShoot:			ParseGunTowerShoot(packet);			break;	
			case SM_GunTowerHurt:			ParseGunTowerHurt(packet);			break;
			case SM_Teleport:				ParseTeleport(packet);				break;
			case SM_SkillHurt:				ParseSkillHurt(packet);				break;

			case SM_PlayerSpray:			ParseSpray(packet);					break;
			case SM_PlayerSprayClear:		ParseSprayClear(packet);			break;
			case SM_BossModeAliveChanged:	ParseBossModeAliveChanged(packet);	break;
			case SM_ChangeAmmoTeam:			ParseChangeAmmoTeam(packet);		break;
			case SM_SyncSkillEffect:		ParseSyncSkillEffect(packet);		break;
			case SM_SpawnCoin:				ParseSpawnCoin(packet);				break;
			case SM_AddDropSupply:			ParseAddDroppedSupply(packet);		break;
			case SM_PickUpSupplyObjectNew:	ParsePickUpSupplyObjectNew(packet);	break;
			case SM_SynServerScriptValue:	ParseSynServerScriptValue(packet);	break;
			case SM_SynScore:				ParseSynScore(packet);				break;
			case SM_MessageClient:			ParseMessageClient(packet);			break;
			case SM_PVEAmmoOut:				ParsePVEAmmoOut(packet);			break;
			case SM_PVEAmmoDestroy:			ParsePVEAmmoDestroy(packet);		break;
			case SM_PVEAmmoHitHurt:			ParsePVEAmmoHitHurt(packet);		break;
			case SM_PVEAmmoExplodeHurt:		ParsePVEAmmoExplodeHurt(packet);	break;
			case SM_PVEAmmoUpdate:			ParsePVEAmmoUpdate(packet);			break;

			case SM_StartPlantBomb:			ParseStartPlantBomb(packet);		break;
			case SM_CancelPlantBomb:		ParseCancelPlantBomb(packet);		break;
			case SM_PlantBombSuccess:		ParsePlantBombSuccess(packet);		break;

			case SM_PickUpBomb:				ParsePickUpBomb(packet);			break;
			case SM_StartDefuseBomb:		ParseStartDefuseBomb(packet);		break;
			case SM_BombExploded:			ParseBombExploded(packet);			break;
			case SM_DefuseBombSuccess:		ParseDefuseBombSuccess(packet);		break;
			case SM_StreetKing_Flash:		ParseStreetKing_Flash(packet);			break;
			case SM_Zombie_Flash:			ParseZombie_Flash(packet);			break;
			case SM_Zombie_Mode_PlayerDying:ParseZombieMode_PlayerDying(packet);break;
			case SM_Zombie_Mode_StartSaveDying:ParseZombieModeStartSaveDying(packet);	break;
			case SM_Zombie_Mode_CancelSaveDying:ParseZombieModeCancelSaveDying(packet);	break;
			case SM_Zombie_Mode_Human_Respawn:	ParseZombieModeHumanRespawn(packet);	break;
			case SM_Zombie_Mode_Step_Two:		ParseZombieModeStepTwo(packet);	break;
			case SM_Zombie_Mode_StartGame:		ParseZombieModeStartGame(packet);	break;
			case SM_ZombieBomer:		ParseZombieBomer(packet);	break;
			case SM_ZombieBomerHurt:		ParseZombieBomerHurt(packet);			break;
			case SM_ChargeSomething:		ParseChargeSomething(packet);			break;
			case SM_CommonZombie_Flash:		ParseCommonZombie_Flash(packet);		break;
			case SM_CommonKingZombie_Flash:		ParseCommonKingZombie_Flash(packet);		break;
			case SM_CommonZombie_LevelChange:	ParsCommonZombie_LevelChange(packet);		break;
			case SM_CommonZombie_EnergyChange:	ParseCommonZombie_EnergyChange(packet);		break;
			case SM_CommonZombie_Super:			ParseCommonZombie_Super(packet);		break;
			case SM_CommonHuman_Super:			ParseCommonHuman_Super(packet);		break;
			case SM_CommonZombie_Unable:		ParseCommonZombie_Unable(packet);		break;
			case SM_King_Zombie_Respawn:		ParseKing_Zombie_Respawn(packet);		break;
			case SM_HumanEnergyChange:			ParseHumanEnergyChange(packet);		break;
			case SM_HumanPowerUp:				ParseHumanPowerUp(packet);		break;
			case SM_UseSkillSuperMan:			ParseUseSkillSuperMan(packet);		break;
			case SM_SkillSuperManSuccess:		ParseSkillSuperManSuccess(packet);		break;
			case SM_CommonZombieHumanDie:		ParseCommonZombieHumanDie(packet);		break;
			case SM_CancelInvisible:			ParseCancelInvisible(packet);		break;
			case SM_UseSmog:					ParseUseSmog(packet);		break;
				
			case SM_Boss2_Flash:				ParseBoss2Flash(packet);		break;
			case SM_Boss2_Showtime:				ParseBoss2Showtime(packet);		break;
			case SM_Boss2_SyncData:				ParseBoss2SyncData(packet);		break;

			case SM_UseItem_ItemMode:			ParseUseItem_ItemMode(packet);	break;
			case SM_ItemMode_ZiBao:				ParseItemMode_ZiBao(packet);	break;
			case SM_ItemMode_SyncData:			ParseItemModeSyncData(packet);	break;
			case SM_DIE_BUFF_DATA:				ParseDieBuffData(packet);		break;
            
			case SM_TDMode_ResHpChange:			ParseTDMode_ResHpChange(packet);break;
			case SM_MoonMode_PickWin:			ParseSM_MoonMode_PickWin(packet);break;
			case SM_UseItem_SurvivalMode:		ParseSM_UseItem_SurvivalMode(packet);break;
			case SM_UseItem_Trap:				ParseSM_UseItem_Trap(packet);	break;
			case SM_UseItem_Trap_Trigger:		ParseSM_UseItem_Trap_Trigger(packet); break;
			case SM_Trap_HP_Disappear:			ParseTrap_HP_Disappear(packet); break;
			case SM_SurvivalMode_Ghost:			ParseSurvivalMode_Ghost(packet);break;

			case SM_SycnBossAction:			ParseSycnBossAction(packet);		break;
			case SM_CutHurt:				ParseCutHurt(packet);				break;
			case SM_RefreshBagItem:			ParseRefreshBagItem(packet);		break;

			case SM_ResponseRoomClientList:		ResponseRoomClientList(packet);	break;
			default:
				{
					LogSystem.WriteLinef("%s, %s, message type : %d, game_state : %d, state : %d, error!!!!!!!!!!!2222222", __FILE__, __FUNCTION__, message_type, game_state, state);
				}break;
			}
		}
		break;

	case kLoading:
		{
			switch(message_type)
			{
			case SM_NotifyRoomHostChanged:	ParseNotifyRoomHostChanged(packet);		break;

			case SM_NotifyGameLeave:		NotifyGameLeave();			break;

			case SM_CharacterInfo:			ParseCharacterInfo(packet);			break;
			case SM_ClientJoin:				ParsePlayerJoin(packet);			break;
			case SM_ClientLeave:			ParsePlayerLeave(packet);			break;
			case SM_GameEnd:				ParseGameEnd(packet);				break;
			case SM_GameLeave:				ParseGameLeave(packet);				break;
			case SM_DestroySupplyObject:	ParseDestroySupplyObject(packet);	break;
			case SM_DestroyDroppedWeapon:	ParseDroppedWeaponDestroy(packet);	break;
			case SM_InitializePushVehiclePointInfo: ParseInitializeVehicleInfo(packet); break;
			case SM_SynServerScriptValue:	ParseSynServerScriptValue(packet);	break;
			case SM_MessageClient:			ParseMessageClient(packet);			break;

			case SM_SyncPlayerData:			ParseSyncCharacterData(packet);		break;
			case SM_ResponseRoomClientList:		ResponseRoomClientList(packet);	break;
			default:
				{
					LogSystem.WriteLinef("%s, %s, message type : %d, game_state : %d, state : %d, error!!!!!!!!!!!3333333333", __FILE__, __FUNCTION__, message_type, game_state, state);
				}break;
			}
		}break;


	default:
		{
			LogSystem.WriteLinef("%s, %s, message type : %d, game_state : %d, state : %d, error!!!!!!!!!!!44444444444", __FILE__, __FUNCTION__, message_type, game_state, state);
		}break;
	};
}

void ChannelConnection::ParseHealthRecover(Core::BinaryNetworkReader & reader)
{
	//ENCODE_START

	byte uid;
	int health;
	byte recover_type;
	byte from_uid;
	float userdata;

	reader.ReadByte(uid);
	reader.ReadInt(health);
	reader.ReadByte(recover_type);
	reader.ReadByte(from_uid);
	reader.ReadFloat(userdata);

	tempc_ptr(Character) viewer = gLevel->GetViewer();
	tempc_ptr(Character) c = gLevel->GetCharacter(uid);
	tempc_ptr(Character) from_c = gLevel->GetCharacter(from_uid);
	tempc_ptr(StateMainGame) state_main = ptr_dynamic_cast<StateMainGame>(gGame->machine.CurrentState());

	if (from_c && viewer == from_c)
	{
		int adddata = health - c->hp;
		if (from_c->cure_all_value % 1000 + adddata >= 1000)
		{
			from_c->isshowevent = true;
			from_c->kills_kind.Clear();
			int type = (from_c->cure_all_value + adddata) / 1000;
			type = type >= 5 ? 5 : type;
			switch (type)
			{
			case 1:
				from_c->kills_kind.PushBack(kCure1);
				break;
			case 2:
				from_c->kills_kind.PushBack(kCure2);
				break;
			case 3:
				from_c->kills_kind.PushBack(kCure3);
				break;
			case 4:
				from_c->kills_kind.PushBack(kCure4);
				break;
			case 5:
				from_c->kills_kind.PushBack(kCure5);
				break;
			}
		}
		from_c->cure_all_value += adddata;
	}
	if (c)
	{
		if(viewer && c && viewer == c)
		{
			int adddata = health - viewer->hp;
			switch(recover_type)
			{
			case kRecoverNone:
				break;
			case kRecoverSelf:
			case kRecoverVehicle:
			case kRecoverSupplyHp:
			case kRecoverBaseHp:
			case kRecoverWaitAddBlood:
				{
					if(state_main && state_main->ui)
						state_main->ui->AddBloodEffectData(0.8f, kRecoverSupplyHp,Core::Vector2(50, -80), adddata);						
				}
				break;
			case kRecoverCuregun:
				{
					c->state_addbloodformcure = true;
					c->state_addbloodtime = 1.0f;
					float r = (F32)rand() / (RAND_MAX + 1);
					float num = 55 + 110 * r;
					if(state_main && state_main->ui)
						state_main->ui->AddBloodEffectData(0.8f, kRecoverCuregun,Core::Vector2(-40+num, -40), -1);

					tempc_ptr(WeaponBase) weapon = viewer->GetWeapon();
					if(weapon && weapon->GetWeaponType() == kWeaponTypeCureGun)
					{
						if (!viewer->first_action_on)
						{
							if (viewer->from_cure_id == from_uid)
							{
								viewer->state_addblood = true;
								viewer->state_addbloodtip = true;
								viewer->state_addblood_time = 1.5f;
								viewer->state_addbloodtip_time = 1.5f;
								viewer->state_invincible = userdata;
							}
							else if (!viewer->state_addblood)
							{
								viewer->state_addblood = true;
								viewer->state_addbloodtip = true;
								viewer->state_addblood_time = 1.5f;
								viewer->state_addbloodtip_time = 1.5f;
								viewer->from_cure_id = from_uid;
								viewer->state_invincible = userdata;
							}
						}
					}
					else
					{
						if (viewer->from_cure_id == from_uid)
						{
							viewer->state_addblood = true;
							viewer->state_addbloodtip = true;
							viewer->state_addblood_time = 1.5f;
							viewer->state_addbloodtip_time = 1.5f;
							viewer->state_invincible = userdata;
						}
						else if (!viewer->state_addblood)
						{
							viewer->state_addblood = true;
							viewer->state_addbloodtip = true;
							viewer->state_addblood_time = 1.5f;
							viewer->state_addbloodtip_time = 1.5f;
							viewer->state_invincible = userdata;
							viewer->from_cure_id = from_uid;
						}
					}
				}
				break;
			case kRecoverNovice:
				break;
			default: 
				break;
			}
		}

		if(viewer && viewer == c && viewer->hp != health)
		{
			viewer->new_hp = health;
			viewer->old_hp = viewer->hp;

			if(gLevel->game_type == RoomOption::kNovice && gLevel->novice_index == 5)
			{
				gLevel->novice_index = 6;
				gLevel->novice_timer = 0.f;
				gLevel->novice_need_timer = false;
			}
		}

		if(recover_type == kRecoverCuregun)
		{
			c->SetCureParticleShow(1.5f);
			c->state_addblood2 = true;
			c->from_cure_id2 = from_uid;

			if(!viewer)
				return;
			tempc_ptr(WeaponBase) weapon = viewer->GetWeapon();
			if(weapon && weapon->GetWeaponType() == kWeaponTypeCureGun)
			{
				if (viewer->first_action_on)
				{
					if(viewer == c)
					{
						viewer->state_addblood = true;
						viewer->state_addblood_time = 1.5f;
						viewer->state_invincible = userdata;
					}
					viewer->state_addbloodtip = true;
					viewer->state_addbloodtip_time = 1.5f;
				}
			}
		}

		c->Recover(health, recover_type);
	}

	//ENCODE_END
}


void ChannelConnection::ParseCurePower(Core::BinaryNetworkReader & reader)
{
	byte uid;
	float power;
	int score;

	reader.ReadByte(uid);
	reader.ReadFloat(power);
	reader.ReadInt(score);

	tempc_ptr(Character) c = gLevel->GetCharacter(uid);
	if (c)
	{
		tempc_ptr(WeaponBase) weapon = c->GetWeapon();
		if (weapon->GetWeaponType() == kWeaponTypeCureGun)
		{
			tempc_ptr(GunBase) gun = ptr_dynamic_cast<GunBase>(weapon);
			if (gun)
			{
				gun->power = power;
				if (c == gLevel->GetPlayer())
				{
					tempc_ptr(CureGun) cure = ptr_dynamic_cast<CureGun>(gun);
					if (cure && !cure->can_Special && gun->power >= 100)
					{
						cure->can_Special = true;
						String str = String::Format("bj/player/2d/%s/hundred_energy_cooldown",c->character_info->res_key);
						FmodSystem::PlayEvent(str.Str());
					}
					else if (cure && gun->power < 100)
					{
						cure->can_Special = false;
					}
				}
			}
		}
	}

	bool isPass = false;
	tempc_ptr(Character) player = gLevel->GetPlayer();
	if (player && player == c && player->all_score < score)
	{
		if (player->all_score == score)
			isPass = true;
		else
		{
			player->kill_showscore = score - player->all_score;
			player->kill_score_time = 0.f;
		}

		player->all_score = score;
	}

	if (player && player == c && player->ui_score_line >= 0 && player->ui_score_line < 3)
	{
		AddEnergyEffectInfo &info = player->energy_bar_info;
		if (player->all_score < player->get_score && !isPass)
		{
			info.move_time = 0.0f;
			info.move_all_time = 0.75f;

			info.all_value = 1.0f;
			info.current_value = info.current_target_value;
			info.current_target_value = Core::Clamp((player->all_score - player->get_last_score)/(player->get_score - player->get_last_score),0,1);
		}
		else if (!isPass)
		{
			player->UpdateUiScoreLine();

			info.move_time = 0.0f;
			info.move_all_time = 0.75f;

			info.all_value = 1.0f;
			info.current_value = info.current_target_value;
			info.current_target_value = Core::Clamp((player->all_score - player->get_last_score)/(player->get_score - player->get_last_score),0,1);
		}
	}
}

void ChannelConnection::ProjectedAmmoOut(byte uid, by_ptr(WeaponInfo) weapon_info, int ammo_type, const Core::Vector3 & position, 
										 const Core::Vector3 & direction, const AmmoAddInInfo& addin, by_ptr(Character) target)
{
	// projectedammo out
	if (state != kInGame)
		return;

	if (game_state == kGameLeaving)
		return;

	tempc_ptr(Character) character = gLevel->GetCharacter(uid);
	if (character)
	{
		tempc_ptr(AmmoInfo) info = ptr_dynamic_cast<AmmoInfo>(weapon_info);
		if (info)
		{
			U16 ammoindex = gLevel->GenAmmoId();
			bool is_boost(false);
			if( GetGaiLv(character->rand_fun.Rand(),character->rand_fun.GetRandMax()) * 10000 < info->hit_crit)
				is_boost = true;

			if(addin.is_need_addin_info)
			{
				info->hurt_rate = addin.hurt_rate;
				info->gravity_addon = addin.gravity_addon;
				info->default_fly_speed = addin.default_fly_speed;
			}
			info->blood_disk_interval = addin.blood_disk_interval;
			info->blood_disk_hit_count = addin.blood_disk_hit_count;
			info->max_stick_ammo_count = addin.max_stick_ammo_count;

			bool ret = character->AmmoLaunchOut(info, position, direction, ammoindex, target,is_boost);

			if (ret)
			{
				BeginWrite();
				WriteByte(CM_ProjectedAmmoOut);
				WriteShort(ammoindex);
				WriteVector3(position);
				WriteVector3(direction);
				WriteFloat(info->hurt_rate);
				WriteFloat(info->gravity_addon);
				EndWrite();
			}
		}
	}
}

void ChannelConnection::NeedDieBuff(int iSlot)
{
	if (state != kInGame)
		return;

	if (game_state == kGameLeaving)
		return;

	BeginWrite();
	WriteByte(CM_NEED_DIE_BUFF);
	WriteInt(iSlot);
	EndWrite();
}

void ChannelConnection::ExplodeAmmoHurt(ushort ammo_id, byte uid, by_ptr(WeaponInfo) info, float dist, float range_ratio, const Core::Vector3 &position, bool teamhurt,byte part, float hurt_rate)
{
	if (state != kInGame)
		return;

	if (game_state == kGameLeaving)
		return;

	if (info)
	{
		BeginWrite();
		WriteByte(CM_ProjectedAmmoHurt);
		WriteByte(uid);
		WriteShort(ammo_id);
		WriteFloat(dist);
		WriteFloat(range_ratio);
		WriteVector3(position);
		WriteByte(part);
		WriteByte(teamhurt);
		WriteFloat(hurt_rate);
		EndWrite();
	}
}

void ChannelConnection::ExplodeAmmoHurtDummy(ushort ammo_id, int dummy_id, by_ptr(WeaponInfo) info, float dist, float range_ratio, const Core::Vector3 &position, bool teamhurt, float hurt_rate)
{
	if (state != kInGame)
		return;

	if (game_state == kGameLeaving)
		return;

	if (info)
	{
		BeginWrite();
		WriteByte(CM_DummyProjectedAmmoHurt);
		WriteInt(dummy_id);
		WriteShort(ammo_id);
		WriteFloat(dist);
		WriteFloat(range_ratio);
		WriteVector3(position);
		WriteByte(teamhurt);
		WriteFloat(hurt_rate);
		EndWrite();
	}
}

void ChannelConnection::ExplodeProdHurt(ushort ammo_id, byte uid, by_ptr(WeaponInfo) info, bool teamhurt, byte part)
{
	if (state != kInGame)
		return;

	if (game_state == kGameLeaving)
		return;

	if (info)
	{
		BeginWrite();
		WriteByte(CM_ProjectedProdHurt);
		WriteByte(uid);
		WriteShort(ammo_id);
		WriteByte(teamhurt);
		WriteByte(part);
		EndWrite();
	}
}

void ChannelConnection::ExplodeProdHurtDummy(ushort ammo_id, int dummy_id, by_ptr(WeaponInfo) info, bool teamhurt)
{
	if (state != kInGame)
		return;

	if (game_state == kGameLeaving)
		return;

	if (info)
	{
		BeginWrite();
		WriteByte(CM_DummyProjectedProdHurt);
		WriteInt(dummy_id);
		WriteShort(ammo_id);
		WriteByte(teamhurt);
		EndWrite();
	}
}

void ChannelConnection::CharacterHeal(byte character_id, int heal_life, int ammo)
{
	if (state != kInGame)
		return;

	if (game_state == kGameLeaving)
		return;

	BeginWrite();
	WriteByte(CM_CharacterHeal);
	WriteByte(character_id);
	WriteInt(heal_life);
	WriteInt(ammo);
	EndWrite();

}

void ChannelConnection::Teleport(const Core::Vector3 &position, const Core::Quaternion &rotation)
{
	if (state != kInGame)
		return;

	if (game_state == kGameLeaving)
		return;

	BeginWrite();
	WriteByte(CM_Teleport);
	WriteVector3(position);
	WriteQuaternion(rotation);
	EndWrite();
}

void ChannelConnection::ForceSpawn()
{
	if (state != kInGame)
		return;

	if (game_state == kGameLeaving)
		return;

	BeginWrite();
	WriteByte(CM_ForceSpawn);
	EndWrite();
}

void ChannelConnection::CutHurt(ushort ammo_id, const Array<HitMessage> & hit_message)
{
	if (state != kInGame)
		return;

	if (game_state == kGameLeaving)
		return;

	tempc_ptr(Character) player = gLevel->GetPlayer();
	if (!player)
		return;
	for (int i = 0; i < (int)hit_message.Size(); i++)
	{
		BeginWrite();
		WriteByte(CM_CutHurt);
		WriteByte(hit_message[i].uid);
		WriteShort(ammo_id);
		WriteByte(hit_message[i].part);
		EndWrite();
	}
}


void ChannelConnection::ProjectedAmmoDestroy(by_ptr(AmmoBase) ammo, U16 ammo_id)
{
	if (state != kInGame)
		return;

	if (game_state == kGameLeaving)
		return;

	if (!ammo)
		return;

	float t = Task::GetTotalTime();
	float delta = t - ammo_sync_time;

	byte delta_b = Clamp(delta + 0.5f / 255.f, 0, 1) * 255.f;
	byte impact_flg = (ammo->is_impact << 0) | (ammo->is_impact_character << 1);

	BeginWrite();
	WriteByte(CM_ProjectedAmmoDestroy);
	WriteShort(ammo_id);
	WriteByte(delta_b);
	WriteVector3FP(*this, ammo->GetPosition());
	WriteVector3FP(*this, ammo->GetRotation().GetZXY());
	WriteByte(impact_flg);
	WriteVector3FP(*this, ammo->impact_normal);
	WriteVector3FP(*this, ammo->impact_pos);
	EndWrite();
}

void ChannelConnection::RequestDummyObjectCreate(byte type, const char* pbuf, uint length, byte sub_type)
{
	if (state != kInGame)
		return;

	if (game_state == kGameLeaving)
		return;

	BeginWrite();
	WriteByte(CM_DummyObjectCreate);
	WriteByte(type);
	WriteInt(length);
	Write(pbuf, length);
	WriteByte(sub_type);
	EndWrite();
}

void ChannelConnection::ParseNotifyDummyObjectCreate(Core::BinaryNetworkReader & reader)
{
	byte owner_id;
	uint id;
	byte type;
	byte need_stepfather;
	byte team;
	byte can_hurt;
	byte sub_type;
	uint length;
	char buf[SYNC_BUFFER_SIZE];
	
	reader.ReadByte(owner_id);
	reader.ReadInt(id);
	reader.ReadByte(type);
	reader.ReadByte(sub_type);
	reader.ReadByte(need_stepfather);
	reader.ReadByte(team);
	reader.ReadByte(can_hurt);

	reader.ReadInt(length);
	reader.Read(buf, length);

	gLevel->AddDummyObject(owner_id, id, type, sub_type, need_stepfather, team, can_hurt, buf, length);
}

void ChannelConnection::RequestDummyObjectDestory(uint id)
{
	if (state != kInGame)
		return;

	if (game_state == kGameLeaving)
		return;

	BeginWrite();
	WriteByte(CM_DummyObjectDestory);
	WriteInt(id);
	EndWrite();
}

void ChannelConnection::DummyObjectSyncUpdate()
{
	if (state != kInGame)
		return;

	if (game_state == kGameLeaving)
		return;

	float time = Task::GetTotalTime();
	float delta = time - dummy_sync_time;

	byte delta_b = Clamp(delta + 0.5f / 255.f, 0, 1) * 255.f;
	if (delta >= 0.4f)
	{
		HashSet<uint, sharedc_ptr(DummyObject)>::Enumerator it(gLevel->dummy_object_set);

		while (it.MoveNext())
		{
			tempc_ptr(DummyObject) dummy = it.Value();
			bool need_sync = dummy->NeedSyncUpdate();
			if(need_sync)
			{
				int length;
				const char* buffer;
				buffer = dummy->GetSyncData(length);
				if(length > 0)
				{
					BeginWrite();
					WriteByte(CM_DummySyncUpdate);
					WriteInt(it.Key());
					WriteByte(delta_b);

#ifndef MASTER
					if(length > 500)
					{
						LogSystem.WriteLinef("Dummy Sync Sting Too Big %d", length);
						WriteInt(0);
						EndWrite();
					}
#endif
					WriteInt(length);
					Write(buffer,length);
					EndWrite();

					dummy_sync_time = time;
				}
			}
		}

	}

}

void ChannelConnection::ParseDummyObjectSyncUpdate(Core::BinaryNetworkReader & reader)
{
	uint uid;
	byte delta_b;
	uint size;
	char buffer[SYNC_BUFFER_SIZE];

	reader.ReadInt(uid);

	reader.ReadByte(delta_b);
	reader.ReadInt(size);
	reader.Read(buffer,size);
	tempc_ptr(DummyObject) dummy = gLevel->dummy_object_set.Get(uid, NullPtr);
	if(dummy)
	{
		dummy->AddSyncData(delta_b, buffer, size);
	}
}

void ChannelConnection::PraseDummyChangeOwner(Core::BinaryNetworkReader & reader)
{
	uint dummy_id;
	byte new_owner;
	reader.ReadInt(dummy_id);
	reader.ReadByte(new_owner);

	tempc_ptr(DummyObject) dummy = gLevel->dummy_object_set.Get(dummy_id, NullPtr);
	if(dummy)
	{
		dummy->owner_id = new_owner;
		if(dummy->IsSyncMaster())
		{
			dummy->SetSyncMaster(false);
		}
		else if(new_owner == gLevel->GetPlayer()->uid)
		{
			dummy->SetSyncMaster(true);
		}
	}

}

void ChannelConnection::ParseGunTowerShoot(Core::BinaryNetworkReader & reader)
{
	byte uid;
	uint dummy_id;
	byte hit_uid;
	byte part;
	float distance;
	byte hurt;

	reader.ReadByte(uid);
	reader.ReadInt(dummy_id);
	reader.ReadByte(hit_uid);
	reader.ReadByte(part);
	reader.ReadFloat(distance);

	reader.ReadByte(hurt);
	tempc_ptr(Character) shooter = gLevel->GetCharacter(uid);
	tempc_ptr(Character) h = gLevel->GetCharacter(hurt);

	tempc_ptr(DummyObject) dummy = gLevel->dummy_object_set.Get(dummy_id, NullPtr);

	if(dummy)
	{
		if (h && shooter)
		{
			TakeDamage(reader, shooter, h, dummy->GetPosition(),false, false);

			tempc_ptr(MachineGunTurret) gun_turret = ptr_dynamic_cast<MachineGunTurret>(dummy);
			if(gun_turret)
			{
				gun_turret->Fire(hit_uid, part);
			}
		}
	}
}

void ChannelConnection::ParseGunTowerHurt(Core::BinaryNetworkReader & reader)
{
	uint dummy_id;
	byte hit_uid;
	int damage;
	byte isboost;
	reader.ReadInt(dummy_id);
	reader.ReadByte(hit_uid);
	reader.ReadInt(damage);
	reader.ReadByte(isboost);

	{
		tempc_ptr(DummyObject) dummy = gLevel->dummy_object_set.Get(dummy_id, NullPtr);
		if(dummy && dummy->need_stepfather)
		{
			dummy->TakeDamage(damage, isboost == 0 ? false : true);
		}
	}
}

void ChannelConnection::ParseTeleport(Core::BinaryNetworkReader & reader)
{
	byte uid;
	Vector3 position;
	Quaternion rotation;

	reader.ReadByte(uid);
	reader.ReadVector3(position);
	reader.ReadQuaternion(rotation);

	tempc_ptr(Character) c = gLevel->GetCharacter(uid);
	if (c)
	{
		c->SetPosition(position);
		c->SetLookDir(rotation);
		c->SetMove(0,0);
		c->PlayItemModeParticle("prop_disappear", 10.f);
		// initialize sync data
		c->time = 0;
		c->sync_time = 0;
		c->sync_data.Clear();

		CharacterSyncData & sync = c->sync_data.PushBack();

		sync.time = 0;
		sync.position = c->GetPosition();
		sync.rotation = c->GetRotation();
		sync.crouch = c->GetCrouch();
		sync.walk = c->GetWalk();
		sync.jump = c->IsJumping();
		sync.onground = c->IsOnGround();
		sync.move = Vector2(0, 0);
		sync.flying = c->IsFlying();
		sync.boost = c->IsBoost();
	}
}

void ChannelConnection::ParseRefreshBagItem(Core::BinaryNetworkReader & reader)
{
	uint sid = 0;
	ushort count = 0;
	ushort num = 0;
	reader.ReadShort(num);
	for (int i = 0; i < num; ++i)
	{
		reader.ReadInt(sid);
		reader.ReadShort(count);
		InGameItemInfo* item = gLevel->GetPlayer()->GetBagItem(sid);
		if(item)
		{
			item->count = count;
			item->interval_timer = time(NULL);
		}
		tempc_ptr(StateMainGame) state_main = ptr_dynamic_cast<StateMainGame>(gGame->machine.CurrentState());
		tempc_ptr(Character) player = gLevel->GetPlayer();
		Core::String str;
		if (state_main && player)
		{
			state_main->ui->m_Showmiddle_str_time = 3.0f;
			sharedc_ptr(ItemParticleTime) dp = ptr_new ItemParticleTime();
			if (player->ItemIsBuffer(item, ITEM_ATTACK) )
			{
				str = Core::String::Format(gLang->GetTextW(L"����������%.0f%% !").Str() , fabs(item->param[0]) );
				state_main->ui->m_Middle_str = str;
				dp->slot = 19;
				dp->totle_time = item->param[1];
				player->item_mode_buff_time.PushBack(dp);
				CStrBuf<256> buf;
			}
			else if (player->ItemIsBuffer(item, ITEM_ATTACK_SPEED) )
			{
				str = Core::String::Format(gLang->GetTextW(L"�����ٶ�����%.0f%% !").Str() , fabs(item->param[0]) );
				state_main->ui->m_Middle_str = str;
				dp->slot = 20;
				dp->totle_time = item->param[1];
				player->item_mode_buff_time.PushBack(dp);
			}
			else if (player->ItemIsBuffer(item, ITEM_RESISTANCE) )
			{
				str = Core::String::Format(gLang->GetTextW(L"��������%.0f%% !").Str() , fabs(item->param[0]) );
				state_main->ui->m_Middle_str = str;
				dp->slot = 21;
				dp->totle_time = item->param[1];
				player->item_mode_buff_time.PushBack(dp);
			}
			else if (player->ItemIsBuffer(item, ITEM_MOVE_SPEED) )
			{
				str = Core::String::Format(gLang->GetTextW(L"�ƶ��ٶ�����%.0f%% !").Str() , fabs(item->param[0]) );
				state_main->ui->m_Middle_str = str;
				dp->slot = 22;
				dp->totle_time = item->param[1];
				player->item_mode_buff_time.PushBack(dp);
			}
			else if (player->ItemIsRedBottle(item) )
			{
				str = Core::String::Format(gLang->GetTextW(L"һ��ʱ���ڻظ�Ѫ��%.0f%% !").Str() , fabs(item->param[0]) );
				state_main->ui->m_Middle_str = str;
				dp->slot = 23;
				dp->totle_time = item->param[1];
				player->item_mode_buff_time.PushBack(dp);
			}
			else if (player->ItemIsAmmo(item) )
			{
				str = Core::String::Format(gLang->GetTextW(L"һ��ʱ���ڻظ���ҩ��%.0f%% !").Str() , fabs(item->param[0]) );
				state_main->ui->m_Middle_str = str;
				dp->slot = 24;
				dp->totle_time = item->param[1];
				player->item_mode_buff_time.PushBack(dp);
			}
			else
			{
				state_main->ui->m_Showmiddle_str_time = 0;
			}
		}
	}
}


void ChannelConnection::ParseNotifyDummyObjectDestory(Core::BinaryNetworkReader & reader)
{
	uint dummy_id;
	reader.ReadInt(dummy_id);
	tempc_ptr(DummyObject) dummy = gLevel->dummy_object_set.Get(dummy_id, NullPtr);
	
	if(dummy) 
	{
		dummy->Die();
	}
}

void ChannelConnection::ProjectedAmmoUpdate(by_ptr(Level::AmmoSet) ammo_set)
{
	if (state != kInGame)
		return;

	if (game_state == kGameLeaving)
		return;

	tempc_ptr(Character) player = gLevel->GetPlayer();

	if (!player || player->GetTeam() > 1)
		return;

	const static float update_time = 0.125f;

	float t = Task::GetTotalTime();
	float delta = t - ammo_sync_time;

	if (delta >= update_time)
	{
		if (ammo_set && ammo_set->Size() > 0)
		{
			byte delta_b = Clamp(delta + 0.5f / 255.f, 0, 1) * 255.f;

			BeginWrite();
			WriteByte(CM_ProjectedAmmoUpdate);
			WriteByte(delta_b);
			WriteShort((U16)(ammo_set->Size()));

			Core::HashSet<U16, sharedc_ptr(AmmoBase)>::Enumerator ammoitor(*ammo_set);
			while (ammoitor.MoveNext())
			{
				const sharedc_ptr(AmmoBase) &ammo = ammoitor.Value();

				WriteShort(ammoitor.Key());
				WriteVector3FP(*this, ammo->GetPosition());
				WriteVector3FP(*this, ammo->GetRotation().GetZXY());

				//LogSystem.WriteLinef("x = %f, y = %f, z = %f", ammo->GetRotation().x, ammo->GetRotation().y, ammo->GetRotation().z);

				const sharedc_ptr(Arrow) m_ammo = ptr_dynamic_cast<Arrow>(ammo);
				if (m_ammo && m_ammo->is_impact && m_ammo->is_impact_character)
				{
					WriteByte(1);
					WriteByte(m_ammo->hit_character_uid);
				}
				else
				{
					WriteByte(0);
					WriteByte(-1);
				}
			}

			EndWrite();
		}

		ammo_sync_time = t;

		//LogSystem.WriteLinef("ProjectedAmmoUpdate() : %d", delta_b);
	}
}


void ChannelConnection::PVELaserHitHurt(byte owner_uid, byte hit_uid, int hit_damage)
{
	if (state != kInGame)
		return;

	if (game_state == kGameLeaving)
		return;

	tempc_ptr(Character) player = gLevel->GetPlayer();
	if (!player || hit_damage <= 0)
		return;

	BeginWrite();
	WriteByte(CM_PVEAmmoHitHurt);
	WriteByte(owner_uid);
	WriteByte(hit_uid);
	WriteFloat(hit_damage);
	EndWrite();
}



void ChannelConnection::PVEAmmoOut(byte owner_uid, by_ptr(PVEAmmo) pve_ammo)
{
	if (state != kInGame)
		return;

	if (game_state == kGameLeaving)
		return;

	if (pve_ammo)
	{
		//BeginWrite();
		//WriteByte(CM_PVEAmmoOut);
		//EndWrite();
	}
}

void ChannelConnection::PVEAmmoDestroy(byte owner_uid, by_ptr(PVEAmmo) pve_ammo)
{
	if (state != kInGame)
		return;

	if (game_state == kGameLeaving)
		return;

	if (pve_ammo)
	{
		//BeginWrite();
		//WriteByte(CM_PVEAmmoDestroy);
		//EndWrite();
	}
}

void ChannelConnection::PVEAmmoHitHurt(byte owner_uid, byte hit_uid, by_ptr(PVEAmmo) pve_ammo)
{
	if (state != kInGame)
		return;

	if (game_state == kGameLeaving)
		return;

	if (pve_ammo)
	{
		tempc_ptr(Character) player = gLevel->GetPlayer();
		if (!player)
			return;

		if (hit_uid != player->uid)
			return;

		BeginWrite();
		WriteByte(CM_PVEAmmoHitHurt);
		WriteByte(owner_uid);
		WriteByte(hit_uid);
		WriteFloat(pve_ammo->GetAmmoInfo()->hit_damage);
		EndWrite();
	}
}

void ChannelConnection::PVEAmmoExplodeHurt(byte owner_uid, byte hit_uid, by_ptr(PVEAmmo) pve_ammo)
{
	if (state != kInGame)
		return;

	if (game_state == kGameLeaving)
		return;

	if (pve_ammo)
	{
		tempc_ptr(Character) player = gLevel->GetPlayer();
		if (!player)
			return;

		if (hit_uid != player->uid)
			return;

		BeginWrite();
		WriteByte(CM_PVEAmmoExplodeHurt);
		WriteByte(owner_uid);
		WriteByte(hit_uid);
		WriteFloat(pve_ammo->GetAmmoInfo()->explode_damage);
		EndWrite();
	}
}

void ChannelConnection::PVEAmmoUpdate(byte owner_uid, Core::HashSet<U16, sharedc_ptr(PVEAmmo)> &pveammo_set)
{
	if (state != kInGame)
		return;

	if (game_state == kGameLeaving)
		return;

	//BeginWrite();
	//WriteByte(CM_PVEAmmoUpdate);
	HashSet<U16, sharedc_ptr(PVEAmmo)>::Enumerator itr(pveammo_set);
	while (itr.MoveNext())
	{
	}
	//EndWrite();
}

// parse pveammo out
void ChannelConnection::ParsePVEAmmoOut(Core::BinaryNetworkReader & reader)
{
}

// parse pveammo destroy
void ChannelConnection::ParsePVEAmmoDestroy(Core::BinaryNetworkReader & reader)
{
}

// parse pveammo hithurt
void ChannelConnection::ParsePVEAmmoHitHurt(Core::BinaryNetworkReader & reader)
{
	byte owner_uid;
	byte hit_uid;

	reader.ReadByte(owner_uid);
	reader.ReadByte(hit_uid);

	tempc_ptr(Character) owner = gLevel->GetCharacter(owner_uid);
	tempc_ptr(Character) hit = gLevel->GetCharacter(hit_uid);

	if (owner && hit)
		TakePveDamage(reader, owner, hit);
}

// parse pveammo explodehurt
void ChannelConnection::ParsePVEAmmoExplodeHurt(Core::BinaryNetworkReader & reader)
{
	byte owner_uid;
	byte hit_uid;

	reader.ReadByte(owner_uid);
	reader.ReadByte(hit_uid);

	tempc_ptr(Character) owner = gLevel->GetCharacter(owner_uid);
	tempc_ptr(Character) hit = gLevel->GetCharacter(hit_uid);

	if (owner && hit)
		TakePveDamage(reader, owner, hit);
}

// parse pveammo update
void ChannelConnection::ParsePVEAmmoUpdate(Core::BinaryNetworkReader & reader)
{
}

// parse projectedammo out
void ChannelConnection::ParseProjectedAmmoOut(Core::BinaryNetworkReader & reader)
{
	//ENCODE_START

	byte uid;
	U16 ammoindex;
	Vector3 pos;
	Vector3 dir;
	bool isboost;
	float speed_addon;
	float gravity_addon;

	reader.ReadByte(uid);
	reader.ReadShort(ammoindex);
	reader.ReadVector3(pos);
	reader.ReadVector3(dir);
	sharedc_ptr(WeaponInfo) weapon_info  = ReadWeapon(reader);
	reader.ReadByte((byte&)isboost);
	reader.ReadFloat(speed_addon);
	reader.ReadFloat(gravity_addon);


	tempc_ptr(Character) character = gLevel->GetCharacter(uid);
	tempc_ptr(AmmoInfo) info = ptr_dynamic_cast<AmmoInfo>(weapon_info);
	info->gravity_addon = gravity_addon;
	info->hurt_rate = speed_addon;
	if (character != gLevel->GetPlayer() || state == kInReplay)
	{
		if (info)
			character->AmmoLaunchOut(info, pos, dir, ammoindex,NullPtr,isboost);
	}

	//ENCODE_END
}

//void ChannelConnection::ParseDieBuff(Core::BinaryNetworkReader & reader)
//{
//
//}

void ChannelConnection::ParseProjectedAmmoUpdate(Core::BinaryNetworkReader & reader)
{
	//ENCODE_START

	byte uid;
	byte time;
	U16 ammosize;
	U16 ammoindex;
	Vector3 position;
	Vector3 direction;
	byte is_impact;
	byte hit_character_uid;

	reader.ReadByte(time);
	reader.ReadByte(uid);
	reader.ReadShort(ammosize);


	for (U16 i = 0; i < ammosize; i++)
	{
		reader.ReadShort(ammoindex);
		ReadVector3FP(reader, position);
		ReadVector3FP(reader, direction);

		//LogSystem.WriteLinef("x = %f, y = %f, z = %f", position.x, position.y, position.z);
		reader.ReadByte(is_impact);
		reader.ReadByte(hit_character_uid);
	
		sharedc_ptr(Level::AmmoSet) ammo_set = gLevel->character_ammoset.Get(uid, NullPtr);
		if (ammo_set)
		{
			sharedc_ptr(AmmoBase) ammo = ammo_set->Get(ammoindex, NullPtr);
			if (ammo)
			{
				if (is_impact)
				{
					tempc_ptr(Arrow) m_ammo = ptr_dynamic_cast<Arrow>(ammo);
					if (m_ammo && hit_character_uid == gLevel->GetPlayer()->uid)
					{
						m_ammo->is_impact = true;
						m_ammo->hit_character_uid = hit_character_uid;
					}
				}
				ammo->AddSyncData(time, position, direction);
			}
		}
	}

	//ENCODE_END
}



// parse projectedammo hurt
void ChannelConnection::ParseProjectedAmmoHurt(Core::BinaryNetworkReader & reader)
{
	//ENCODE_START

	byte from_uid;
	byte to_uid;
	Vector3 pos;
	byte isAmmoJump;
	byte hit_part;
	int ammo_type;
	float flyscale;
	bool isboost;

	reader.ReadByte(from_uid);
	reader.ReadByte(to_uid);
	reader.ReadVector3(pos);
	reader.ReadInt(ammo_type);
	reader.ReadByte(hit_part);
	reader.ReadByte((byte &)isboost);
	tempc_ptr(Character) c = gLevel->GetCharacter(to_uid);
	tempc_ptr(Character) from = gLevel->GetCharacter(from_uid);
	
	//LogSystem.WriteLinef("hurt postion %f,%f,%f",pos.x,pos.y,pos.z );

	if (c && from)
	{
		TakeDamage(reader, from, c, pos, false, isboost);
		reader.ReadByte(isAmmoJump);
		reader.ReadFloat(flyscale);
		if(isAmmoJump)
		{
			bool selfhurt = (from == c);
			if(c == gLevel->GetPlayer() && !c->is_boss)
			{
				c->AmmoJump(pos, selfhurt, flyscale);
			}
		}
		
		c->ResponseHit(pos,c->GetPosition(),  Vector3::kZero, hit_part, ammo_type, true, isboost);
	}

	//ENCODE_END
}

void ChannelConnection::ParseProjectedProdHurt(Core::BinaryNetworkReader & reader)
{
	byte from_uid;
	byte to_uid;
	Vector3 pos;
	byte hit_part;
	int ammo_type;
	bool isboost;

	reader.ReadByte(from_uid);
	reader.ReadByte(to_uid);
	reader.ReadInt(ammo_type);
	reader.ReadByte(hit_part);
	reader.ReadByte((byte &)isboost);
	tempc_ptr(Character) c = gLevel->GetCharacter(to_uid);
	tempc_ptr(Character) from = gLevel->GetCharacter(from_uid);

	//LogSystem.WriteLinef("hurt postion %f,%f,%f",pos.x,pos.y,pos.z );

	if (c && from)
	{
		TakeDamage(reader, from, c, pos, false, isboost);
		c->ResponseHit(pos,c->GetPosition(),  Vector3::kZero, hit_part, ammo_type, true, isboost);
	}
}

void ChannelConnection::ParseProjectedAmmoDestroy(Core::BinaryNetworkReader & reader)
{
	//ENCODE_START

	byte uid;
	U16 ammoindex;
	byte time;
	Vector3 position;
	Vector3 direction;
	byte impact_flg;
	Vector3 impact_normal;
	Vector3 impact_pos;

	reader.ReadByte(uid);
	reader.ReadShort(ammoindex);
	reader.ReadByte(time);
	ReadVector3FP(reader, position);
	ReadVector3FP(reader, direction);
	reader.ReadByte(impact_flg);
	ReadVector3FP(reader, impact_normal);
	ReadVector3FP(reader, impact_pos);

	sharedc_ptr(Level::AmmoSet) ammo_set = gLevel->character_ammoset.Get(uid, NullPtr);
	if (ammo_set)
	{
		sharedc_ptr(AmmoBase) ammo = ammo_set->Get(ammoindex, NullPtr);
		if (ammo)
		{
			ammo->AddSyncData(time, position, direction);

			ammo->is_impact = !!(impact_flg & 0x1);
			ammo->is_impact_character = !!(impact_flg & 0x2);
			ammo->impact_normal = impact_normal;
			ammo->impact_pos = impact_pos;

			//ammo->SetPosition(sync.position);
			//ammo->SetRotation(sync.rotation);

			//LogSystem.WriteLinef("ParseProjectedAmmoDestroy() : %d", time);
		}
	}

	gLevel->SetAmmoDead(uid, ammoindex);

	//ENCODE_END
}

void ChannelConnection::DrumCheck()
{
	//ENCODE_START
	if (state != kInGame)
		return;

	if (game_state == kGameLeaving)
		return;

	BeginWrite();
	WriteByte(CM_DrumCheck);
	EndWrite();
	//ENCODE_END
}

void ChannelConnection::PareseDrumEffect(Core::BinaryNetworkReader & reader)
{
	byte uid;
	
	reader.ReadByte(uid);
	
	tempc_ptr(Character) c = gLevel->GetCharacter(uid);


	
}

void ChannelConnection::Drink()
{
	//ENCODE_START
		if (state != kInGame)
			return;

	if (game_state == kGameLeaving)
		return;

	BeginWrite();
	WriteByte(CM_Drink);
	EndWrite();
	//ENCODE_END
}

void ChannelConnection::ChangeAmmoTeam( U16 ammoindex, byte team )
{
	//ENCODE_START
	if (state != kInGame)
		return;

	if (game_state == kGameLeaving)
		return;

	BeginWrite();
	WriteByte(CM_ChangeAmmoTeam);
	WriteShort(ammoindex);
	WriteByte(team);
	EndWrite();
	//ENCODE_END
	
}
void ChannelConnection::UseSpawnCoin(U16 coin)
{
	//ENCODE_START
	if (state != kInGame)
		return;

	if (game_state == kGameLeaving)
		return;

	BeginWrite();
	WriteByte(CM_UseSpawnCoin);
	WriteByte(coin);
	EndWrite();
	
}

void ChannelConnection::UseItem(uint sid, ushort count /* = 1 */)
{
	if (state != kInGame)
		return;

	if (game_state == kGameLeaving)
		return;

	BeginWrite();
	WriteByte(CM_UseItem);
	WriteInt(sid);
	WriteShort(count);
	EndWrite();
}

void ChannelConnection::UseItemSurvival(int index)
{
	if (state != kInGame)
		return;

	if (game_state == kGameLeaving)
		return;

	BeginWrite();
	WriteByte(CM_UseItemSurvival);
	WriteInt(index);
	EndWrite();
}

void ChannelConnection::UseItemSurvivalByGhost(int index)
{
	if (state != kInGame)
		return;

	if (game_state == kGameLeaving)
		return;

	BeginWrite();
	WriteByte(CM_UseItemSurvivalByGhost);
	WriteInt(index);
	EndWrite();
}


void ChannelConnection::PareseDrink(Core::BinaryNetworkReader & reader)
{
	//ENCODE_START

	byte uid;

	reader.ReadByte(uid);

	tempc_ptr(Character) c = gLevel->GetCharacter(uid);

	if (c)
	{
		if (c != gLevel->GetPlayer() || state == kInReplay)
			c->Shoot(Core::Vector3(0, 0, 0), true);
		if (!c->isshooting)
			c->isshooting = true;
		c->is_shoot_stab = true;
	}

	//ENCODE_END
}

void ChannelConnection::ParseChangeAmmoTeam( Core::BinaryNetworkReader & reader )
{
	byte from_uid;
	U16	 ammoindex;
	byte team;
	reader.ReadByte(from_uid);
	reader.ReadShort(ammoindex);
	reader.ReadByte(team);
	if(gLevel)
	{

		sharedc_ptr(Level::AmmoSet) ammo_set = gLevel->character_ammoset.Get(from_uid, NullPtr);
		if (ammo_set)
		{
			sharedc_ptr(AmmoBase) ammo = ammo_set->Get(ammoindex, NullPtr);
			if (ammo)
			{
				ammo->ChangeAmmoTeam(team);
			}
		}
	}
}

void ChannelConnection::ParseSyncSkillEffect( Core::BinaryNetworkReader & reader )
{
	byte uid;

	reader.ReadByte(uid);

	tempc_ptr(Character) c = gLevel->GetCharacter(uid);
	if (c)
	{
		//Core::LogSystem.WriteLinef("ParseSyncSkillEffect() Start, name : %s", c->GetName());

		byte SyncFlg;

		reader.ReadByte(SyncFlg);

		bool is_fullmode = !!(SyncFlg & 0x1);
		bool has_skill = !!(SyncFlg & 0x2);
		bool has_natural = !!(SyncFlg & 0x4);
		bool has_acquired = !!(SyncFlg & 0x8);

		if (has_skill)
		{
			c->skill_array.Clear();
			ReadSkillDataList(reader, c->skill_array, is_fullmode);
		}
		if (has_natural)
		{
			c->natural_effect_array.Clear();
			ReadEffectDataList(reader, c->natural_effect_array, is_fullmode);
		}
		if (has_acquired)
		{
			c->acquired_effect_array.Clear();
			ReadEffectDataList(reader, c->acquired_effect_array, is_fullmode);
		}

		//Core::LogSystem.WriteLinef("ParseSyncSkillEffect() End, name : %s", c->GetName());
		c->UpdateCurrentCharacterChangeableInfo();
	}
}

void ChannelConnection::ParseSpawnCoin(Core::BinaryNetworkReader& reader)
{
	byte uid;
	bool issuccess;
	int fu_huo_bi;
	int	fu_huo_bi_use_count;

	fu_huo_bi = gLevel->fuhuo_cion;
//	gLevel->isuse = issuccess;
	reader.ReadByte(uid);
	reader.ReadByte((byte&)issuccess);
	reader.ReadInt(fu_huo_bi);
	reader.ReadInt(fu_huo_bi_use_count);

	tempc_ptr(Character) p = gLevel->GetPlayer();
	if (p && p->uid == uid)
	{
		tempc_ptr(StateMainGame) state_main = ptr_dynamic_cast<StateMainGame>(gGame->machine.CurrentState());
		if(state_main && state_main->ui)
		{
			state_main->ui->fu_huo_bi_use_count = fu_huo_bi_use_count;
		}
	}
	// todo tianzhuoqi
}

void ChannelConnection::ParseStartPlantBomb(Core::BinaryNetworkReader& reader )
{
	byte from_uid;
	bool issuccess;
	reader.ReadByte(from_uid);
	reader.ReadByte((byte&)issuccess);

	tempc_ptr(Character) c = gLevel->GetCharacter(from_uid);
	tempc_ptr(Character) p = gLevel->GetPlayer();	

	//	bool is_player = (c == p) ? true : false;

	if(c && c->IsReady() && !c->IsDied())
	{
		if(issuccess)
		{
			c->PlantBomb();
			if (c == p)
			{
				gLevel->audio_bomb_2d_Plant->start();
				gLevel->audio_bomb_Planting_Defusing->start();
			} 
			else
			{
				FMOD_VECTOR vel = {0, 0, 0};
				Core::String str = String::Format("bj/weapon/3d/c4/plant_c4");
				gLevel->audio_bomb_3d_Plant = FmodSystem::Play3DEvent(str,(const FMOD_VECTOR &)c->GetPosition(),vel);
			}
		}
		else
		{
			c->StopPlantBomb();
			if (c == p)
			{
				tempc_ptr(StateMainGame) state_main = ptr_dynamic_cast<StateMainGame>(gGame->machine.CurrentState());
				if(state_main && state_main->ui)
				{
					state_main->ui->show_tips_bomb_time = 1.0f;
				}
			}
		}
	}
}

void ChannelConnection::ParseCancelPlantBomb(Core::BinaryNetworkReader& reader)
{
	byte from_uid;
	reader.ReadByte(from_uid);

	tempc_ptr(Character) c = gLevel->GetCharacter(from_uid);
	//tempc_ptr(Character) p = gLevel->GetPlayer();	

	//bool is_player = (c == p) ? true : false;

	if(c && c->IsReady() && !c->IsDied())
	{		
		c->StopPlantBomb();	
	}
}

void ChannelConnection::ParsePlantBombSuccess(Core::BinaryNetworkReader & reader)
{
	byte from_uid;
	Vector3 pos;
	float bomb_explode_time;
	reader.ReadByte(from_uid);
	reader.ReadVector3(pos);
	reader.ReadFloat(bomb_explode_time);

	tempc_ptr(Character) c = gLevel->GetCharacter(from_uid);
	tempc_ptr(Character) p = gLevel->GetPlayer();

	bool is_player = (c == p) ? true : false;
	if(c && c->IsReady() && !c->IsDied() && c->HasBomb())
	{


		tempc_ptr(Bomb) bomb = c->GetBomb(true);
		if(bomb)
		{
			bomb->Plant(pos);
			gLevel->bomb_on_ground = true;
			gLevel->bomb_on_ground_position = bomb->GetPosition();
			gLevel->bomb_on_ground_rotation = bomb->GetRotation();

			c->SetHasBomb(false);
			c->UnLockStateByType(kLSMove);
			if (is_player)
			{
				c->isshowevent = true;
				c->kills_kind.Clear();
				c->kills_kind.PushBack(kPlant_success);
			}

			gLevel->bomb_explode_timer = bomb_explode_time;
			FmodSystem::PlayEvent("bj/event/c4_succeed");
			FmodSystem::PlayEvent("bj/event/c4_planted");
			gLevel->audio_bomb_Planting_Defusing->stop();
			Core::String str = Core::String::Format(gLang->GetTextW(L"%s �Ѿ��ɹ��������װ���"),c->GetName());
			gLevel->AddHorn(str);
			FMOD_VECTOR vel = {0, 0, 0};
			FmodSystem::Update3DEventPosition(gLevel->audio_bomb_3d_Plant_Timer[0],(const FMOD_VECTOR &)gLevel->bomb_on_ground_position,vel);
			gLevel->audio_bomb_3d_Plant_Timer[0]->start();
		}

		if(is_player)
		{
			c->ChangeWeapon();
		}
	}

}
void ChannelConnection::ParsePickUpBomb(Core::BinaryNetworkReader & reader)
{
	byte from_uid;
	byte id;
	reader.ReadByte(from_uid);
	reader.ReadByte(id);

	tempc_ptr(Character) c = gLevel->GetCharacter(from_uid);
	tempc_ptr(Character) p = gLevel->GetPlayer();

	bool is_player = (c == p) ? true : false;

	if(c && c->IsReady() && !c->IsDied())
	{
		c->SetHasBomb(true);
	}

	if (gLevel->pickup_manager)
		gLevel->pickup_manager->RemovePickUpWeapon(id);


	Core::String str = Core::String::Format(gLang->GetTextW(L"%s �������װ�"),c->GetName());
	gLevel->AddHorn(str);

	gLevel->bomb_droped_id = 0;
	gLevel->bomb_droped = false;
	
}

void ChannelConnection::ParseStartDefuseBomb(Core::BinaryNetworkReader & reader)
{
	byte uid;
	byte is_success;
	float defuse_time;
	reader.ReadByte(uid);
	reader.ReadByte(is_success);
	reader.ReadFloat(defuse_time);
	
	if(gLevel)
	{
		tempc_ptr(Character) p = gLevel->GetPlayer();
		if(p && p->uid == uid && !!is_success)
		{
			gLevel->audio_bomb_2d_Defuse = FmodSystem::PlayEvent("bj/weapon/2d/c4/change_c4");
			gLevel->audio_bomb_Planting_Defusing->start();
			gLevel->StartDefuseBombState(defuse_time);
		}
		else
		{
			FMOD_VECTOR vel = {0, 0, 0};
			Core::String str = String::Format("bj/weapon/3d/c4/change_c4"); 
			gLevel->audio_bomb_3d_Defuse = FmodSystem::Play3DEvent(str,(const FMOD_VECTOR &)p->GetPosition(),vel);
		}
	}

}

void ChannelConnection::ParseBombExploded(Core::BinaryNetworkReader & reader)
{
	if(gLevel && gLevel->bomb_explode_particle && gLevel->bomb_on_ground)
	{
		Vector3 position = gLevel->bomb_on_ground_position;
		gLevel->bomb_explode_particle->SetPosition(position);
		gLevel->bomb_explode_particle->SetEnable(true);

		if (!gLevel->bomb_explode_particle->m_LinkNode.GetList())
			gLevel->particle_manager->AddParticle(gLevel->bomb_explode_particle);

		
		gLevel->bomb_on_ground = false;
		
		gLevel->ClearDefuseBombState();

		gLevel->AddDecal("ammo_explode", position, Vector3(0, 1.f, 0), Vector3::kOne);
		FMOD_VECTOR vel = {0, 0, 0};
		Core::String str = String::Format("bj/fx/3d/c4_explode");
		FmodSystem::Play3DEvent(str,(const FMOD_VECTOR &)position,vel);
	}
	
}


void ChannelConnection::ParseDefuseBombSuccess(Core::BinaryNetworkReader & reader)
{
	byte uid;
	reader.ReadByte(uid);
	
	
	gLevel->bomb_on_ground = false;
	
	
	tempc_ptr(Character) c = gLevel->GetCharacter(uid);
	tempc_ptr(Character) p = gLevel->GetPlayer();
	FmodSystem::PlayEvent("bj/event/c4_succeed");
	FmodSystem::PlayEvent("bj/event/c4_defused");
	gLevel->audio_bomb_Planting_Defusing->stop();
	Core::String str = Core::String::Format(gLang->GetTextW(L"%s �Ѿ��ɹ�������װ���"),c->GetName());
	gLevel->AddHorn(str);	
	if (c == p)
	{
		p->UnLockStateByType(kLSMove);
		p->isshowevent = true;
		p->kills_kind.Clear();
		p->kills_kind.PushBack(kDefuse_success);
	}
	
}

// parse animation start
void ChannelConnection::ParsePlayerAnimationStart(Core::BinaryNetworkReader & reader)
{
	//ENCODE_START

	byte uid;
	int weapontype;
	int animation_state;
	reader.ReadByte(uid);
	reader.ReadInt(weapontype);
	reader.ReadInt(animation_state);
	tempc_ptr(Character) c = gLevel->GetCharacter(uid);
	tempc_ptr(Character) player = gLevel->GetPlayer();

	if (c->IsDied())
	{
		tempc_ptr(MiniMachineGun) mini = ptr_dynamic_cast<MiniMachineGun>(c->GetWeapon());
		if (mini && mini->mini_gun_audio_spin_fire_3d && mini->mini_gun_audio_spin_fire)
		{
			mini->mini_gun_audio_spin_fire->stop();
			mini->mini_gun_audio_spin_fire_3d->stop();
		}
		return;
	}

	switch(weapontype)
	{
	case kWeaponTypeCureGun:
		{
			if (c)
			{
				if (player != c || state == kInReplay)
					c->keep_Shoot = true;
				c->Shoot(c->GetLookDir().GetZXY(),true);
			}
		}
		break;
	case kWeaponTypeMiniMachineGun:
		{
			c->keep_Shoot_mini_tp = true;

			FMOD_VECTOR vel = {0, 0, 0};
			if (c)
			{
				if(c != player || state == kInReplay)
				{
					switch (animation_state)
					{
					case 1:
						{
							c->keep_Shoot_mini_state = 1;
							tempc_ptr(MiniMachineGun) mini = ptr_dynamic_cast<MiniMachineGun>(c->GetWeapon());
							if (mini && mini->mini_gun_audio_spin_fire_3d 
								&& mini->MiniMachineGun_info && mini->MiniMachineGun_info->ammo_type == kWeaponTypeNone)
							{
								mini->mini_gun_audio_spin_fire_3d->stop();
								mini->mini_gun_audio_spin_fire_3d->set3DAttributes(&(const FMOD_VECTOR &)c->GetPosition(), &vel);
								mini->mini_gun_audio_spin_fire_3d->start();
							}
						}
						break;
					case 2:
						{
							c->keep_Shoot_mini_state = 2;
							tempc_ptr(MiniMachineGun) mini = ptr_dynamic_cast<MiniMachineGun>(c->GetWeapon());
							if (mini && mini->mini_gun_audio_spin_fire_3d)
								FmodSystem::Update3DEventPosition(mini->mini_gun_audio_spin_fire_3d,(const FMOD_VECTOR &)c->GetPosition(),vel);
						}
						break;
					case 3:
						{
							c->keep_Shoot_mini_state = 3;
							tempc_ptr(MiniMachineGun) mini = ptr_dynamic_cast<MiniMachineGun>(c->GetWeapon());
							if (mini && mini->mini_gun_audio_spin_fire_3d)
								FmodSystem::Update3DEventPosition(mini->mini_gun_audio_spin_fire_3d,(const FMOD_VECTOR &)c->GetPosition(),vel);
						}
						break;
					case 4:
						{
							c->keep_Shoot_mini_state = 4;
							tempc_ptr(MiniMachineGun) mini = ptr_dynamic_cast<MiniMachineGun>(c->GetWeapon());
							if (mini && mini->mini_gun_audio_spin_fire_3d)
							{
								FMOD_EVENT_STATE audio_state = FMOD_EVENT_DEFAULT;
								mini->mini_gun_audio_spin_fire_3d->getState(&audio_state);
								if ((audio_state & FMOD_EVENT_STATE_PLAYING) != 0)
								{
									FMOD::EventParameter *eventparameter = NULL;
									mini->mini_gun_audio_spin_fire_3d->getParameterByIndex(0,&eventparameter);
									if (eventparameter)
									{
										eventparameter->keyOff();
									}
								}
							}
						}

						break;
					default:
						break;
					}

				}
			}
		}
		break;
	default:
		break;
	}

	//ENCODE_END
}

// parse animation end
void ChannelConnection::ParsePlayerAnimationEnd(Core::BinaryNetworkReader & reader)
{
	//ENCODE_START

	byte uid;
	int weapontype;
	reader.ReadByte(uid);
	reader.ReadInt(weapontype);

	tempc_ptr(Character) c = gLevel->GetCharacter(uid);
	tempc_ptr(Character) player = gLevel->GetPlayer();

	switch(weapontype)
	{
	case kWeaponTypeCureGun:
		{
			if (c)
			{
				if (player != c || state == kInReplay )
					c->keep_Shoot = false;
				c->StopShoot();
			}
		}
		break;
	case kWeaponTypeMiniMachineGun:
		{
			if (c)
			{
				if(player != c || state == kInReplay)
				c->keep_Shoot_mini_state = 0;
				c->keep_Shoot_mini_tp = false;
				c->StopShoot();
			}
		}
		break;
	default:
		break;
	}

	//ENCODE_END
}

// parse call doctor
void ChannelConnection::ParseCallDoctor(Core::BinaryNetworkReader & reader)
{
	//ENCODE_START

	byte uid;

	reader.ReadByte(uid);

	tempc_ptr(Character) c = gLevel->GetCharacter(uid);
	tempc_ptr(Character) player = gLevel->GetPlayer();
	if (player && c && c != gLevel->GetViewer() && c->GetTeam() == player->GetTeam())
	{
		float length = 0.f;
		length = Core::Length(player->GetPosition() - c->GetPosition());
		if (length < 15.f)
		{
			FMOD_VECTOR vel = {0, 0, 0};
			String str = String::Format("bj/player/3d/%s/medic",c->GetCurCharinfo()->res_key);
			FmodSystem::Play3DEvent(str.Str(),(const FMOD_VECTOR &)c->GetPosition(),vel);
		}
	}

	if(c)
	{
		CStrBuf<character_name_length> name;
		CStrBuf<chat_length> msg;
		
		msg = gLang->GetTextW(L"����ҽ��").Str();
		name = c->GetName().RefStr();

		if (gGame)
		{
			ChatMessage m;
			m.sender = name;
			m.msg = msg;
          
			gGame->machine.OnChat(m);
		}

		c->ShowBillBoard(3.f);
	}

	//ENCODE_END
}

void ChannelConnection::StopBurn(byte uid)
{
	if (state != kInGame)
		return;

	if (game_state == kGameLeaving)
		return;
	
	BeginWrite();
	WriteByte(CM_StopBurn);
	WriteByte(uid);
	EndWrite();
}

void ChannelConnection::NoviceOperation(int index)
{
	if (state != kInGame)
		return;

	if (game_state == kGameLeaving)
		return;

	BeginWrite();
	WriteByte(CM_NoviceOperation);
	WriteInt(index);
	EndWrite();
}

void ChannelConnection::ParseNoviceOperation(Core::BinaryNetworkReader & reader)
{
	int index;
	reader.ReadInt(index);

	switch(index)
	{
	case 4:
		{
			gLevel->novice_index = 5;
			gLevel->novice_timer = 0.f;
			gLevel->novice_need_timer = false;
		}
		break;
	case 20:
		{
			gLevel->novice_index = 21;
			gLevel->novice_timer = 0.f;
			gLevel->novice_need_timer = false;
		}
		break;
	default:
		break;
	}
}

void ChannelConnection::ParseBossFlash(Core::BinaryNetworkReader & reader)
{
	byte uid;
	byte team;
	int hp;
	int armor;
	byte start_point = 0;
	float invincible_time = 0;
	Core::Vector3 position(0, 0, 0);
	float angle;
	int max_hp;
	int ex_hp;
	int s_rand;
	//byte pack_index;
	int career = 0;
 	sharedc_ptr(CharacterInfo) character_info = ptr_new CharacterInfo();

	reader.ReadByte(uid);
	reader.ReadByte(team);
	reader.ReadInt(hp);
	reader.ReadInt(max_hp);
	reader.ReadInt(ex_hp);
	reader.ReadInt(armor);
	reader.ReadInt(s_rand);
	reader.ReadVector3(position);
	reader.ReadFloat(angle);
	//reader.ReadInt(career);
	ReadCharacterInfo(reader, *character_info);

	tempc_ptr(Character) c = gLevel->GetCharacter(uid);

	gLevel->boss_starttimeer = -1;

	if (c)
	{
		Character *pPlayer = gLevel->GetPlayer();
		if(c == pPlayer)
		{
			pPlayer->relife_flag = false;
			pPlayer->relife_time = 0.0f;
			pPlayer->select_player_flag = false;
			pPlayer->SetViewMode(Character::kFirstPerson);
			game_state = kAlive;
			pPlayer->SetCrouch(false);
			SpawnConfirm();
			tempc_ptr(SniperGun) gun = ptr_dynamic_cast<SniperGun>(pPlayer->GetWeapon());
			if (gun)
				gun->SetSight(0);
		}

		c->ready = true;
		c->connected = true;
		c->invincible_time = invincible_time;
		c->weapon_id = -1;

		c->playing = true;
		c->grenade_cd_time = -1.f;

		c->max_hp = max_hp;
		c->ex_hp = ex_hp;

		c->rand_fun.Srand(s_rand);

		c->is_boss = true;
		c->ClearLockState();
		c->LockStateByType(kLSJump);
		c->LockStateByType(kLSCrouch);
		
		c->SetTeam(team);

		c->SetCareer(career, character_info);
		c->SetPhysxGroup(team + PhysxSystem::kGroupStart);

		c->Rebirth(hp, armor, position, Quaternion(Vector3(0, 1, 0), DEG2RAD * angle));
		if (c == gLevel->GetPlayer())
		{
			tempc_ptr(StateMainGame) state_main = ptr_dynamic_cast<StateMainGame>(gGame->machine.CurrentState());
			if(state_main)
				state_main->EventCloseCharacter.Fire(ptr_static_cast<StateMainGame>(state_main), EventArgs());
			gLevel->targetenemy_time = 0.f;
			gLevel->tmpplayer = NullPtr;
		}

		c->UpdateRawCharacterChangeableInfo();

		for (int i = 0; i < 7; ++i)
		{
			tempc_ptr(WeaponBase) weapon = c->GetWeaponById(i);
			if (weapon && weapon->CanActive())
			{
				c->SelectWeapon(i, true);
				break;
			}
		}

		//for (int i = 0; i < 7; i++)
		//{
		//	tempc_ptr(WeaponBase) weapon = c->GetWeaponById(i);
		//	if (weapon && weapon->CanActive())
		//	{
		//		weapon->is_weapon_updated = false;
		//	}
		//}
		c->zombie_dying_flag = false;

	}
}

void ChannelConnection::ParseZombieMode_PlayerDying(Core::BinaryNetworkReader & reader)
{
	byte uid;
	int hp;
	int armor;
	int max_hp;
	int ex_hp;
	byte from_id;


	reader.ReadByte(uid);
	reader.ReadInt(hp);
	reader.ReadInt(max_hp);
	reader.ReadInt(ex_hp);
	reader.ReadInt(armor);
	reader.ReadByte(from_id);

	tempc_ptr(Character) c = gLevel->GetCharacter(uid);
	tempc_ptr(Character) player = gLevel->GetPlayer();
	tempc_ptr(Character) c_from = gLevel->GetCharacter(from_id);

	if (c && !c->zombie_dying_flag)
	{
		c->zombie_dying_flag = true;
		c->hp = hp;
		c->max_hp = max_hp;
		c->ex_hp = ex_hp;
		if(c == player)
		{
			c->UnLockStateByType(kLSSelectWeapon);
			c->LockStateByType(kLSMove);
			c->SelectWeapon(1,true);
			c->LockStateByType(kLSSelectWeapon);
		}
	
		FmodSystem::PlayEvent("bj/event/bio/human_down");
		if (c == player)
		{
			c->zombie_2D_human_heart = FmodSystem::PlayEvent("bj/event/bio/heartbeat");
		}
	}

	if (c_from->GetTeam() == 1)
	{
		if (c_from && c_from == player && c->zombie_dying_flag == 1)
		{
			c_from->kills_kind.PushBack(KKill_Knockdown);
			FmodSystem::PlayEvent("bj/event/bio/knock_down");
			Core::String str = Core::String::Format(gLang->GetTextW(L"%s�⵽��%s���ش������ˣ�̫�����ˣ�"),c->GetName(),c_from->GetName());
			gLevel->AddHorn(str);
		} 
		else if (c_from && c_from != player && c->zombie_dying_flag == 1)
		{
			Core::String str = Core::String::Format(gLang->GetTextW(L"%s�⵽��%s���ش������ˣ���ȥ��Ԯ��"),c->GetName(),c_from->GetName());
			gLevel->AddHorn(str);
		}
	}
}

void ChannelConnection::ParseZombie_Flash(Core::BinaryNetworkReader & reader)
{
	byte uid;
	byte team;
	int hp;
	int armor;
	byte start_point = 0;
	float invincible_time = 0;
	Core::Vector3 position(0, 0, 0);
	float angle;
	int max_hp;
	int ex_hp;
	int s_rand;
	//byte pack_index;
	
	sharedc_ptr(CharacterInfo) character_info = ptr_new CharacterInfo();

	reader.ReadByte(uid);
	reader.ReadByte(team);
	reader.ReadInt(hp);
	reader.ReadInt(max_hp);
	reader.ReadInt(ex_hp);
	reader.ReadInt(armor);
	reader.ReadInt(s_rand);
	reader.ReadVector3(position);
	reader.ReadFloat(angle);
	//reader.ReadInt(career);
	ReadCharacterInfo(reader, *character_info);

	int career = character_info->career_id;

	tempc_ptr(Character) c = gLevel->GetCharacter(uid);

	if (c)
	{
		Character *pPlayer = gLevel->GetPlayer();
		if(c == pPlayer)
		{
			pPlayer->relife_flag = false;
			pPlayer->relife_time = 0.0f;
			pPlayer->select_player_flag = false;
			pPlayer->SetViewMode(Character::kFirstPerson);
			game_state = kAlive;
			pPlayer->SetCrouch(false);
			SpawnConfirm();
			tempc_ptr(SniperGun) gun = ptr_dynamic_cast<SniperGun>(pPlayer->GetWeapon());
			if (gun)
				gun->SetSight(0);
		}

		c->ready = true;
		c->connected = true;
		c->invincible_time = invincible_time;
		c->weapon_id = -1;

		c->playing = true;
		c->grenade_cd_time = -1.f;

		c->max_hp = max_hp;
		c->ex_hp = ex_hp;

		c->rand_fun.Srand(s_rand);

		c->SetTeam(team);

		c->ClearLockState();

		c->SetCareer(career, character_info);
		c->SetPhysxGroup(team + PhysxSystem::kGroupStart);

		c->Rebirth(hp, armor, position, Quaternion(Vector3(0, 1, 0), DEG2RAD * angle));
		if (c == gLevel->GetPlayer())
		{
			tempc_ptr(StateMainGame) state_main = ptr_dynamic_cast<StateMainGame>(gGame->machine.CurrentState());
			if(state_main)
				state_main->EventCloseCharacter.Fire(ptr_static_cast<StateMainGame>(state_main), EventArgs());
			gLevel->targetenemy_time = 0.f;
			gLevel->tmpplayer = NullPtr;
			if (character_info->career_id == DEFAULT_ZOMBIE_KING)
			{
				FmodSystem::PlayEvent("bj/event/bio/become_bioking");
			}
		}

		c->UpdateRawCharacterChangeableInfo();

		for (int i = 0; i < 7; ++i)
		{
			tempc_ptr(WeaponBase) weapon = c->GetWeaponById(i);
			if (weapon && weapon->CanActive())
			{
				c->SelectWeapon(i, true);
				break;
			}
		}

		//for (int i = 0; i < 7; i++)
		//{
		//	tempc_ptr(WeaponBase) weapon = c->GetWeaponById(i);
		//	if (weapon && weapon->CanActive())
		//	{
		//		weapon->is_weapon_updated = false;
		//	}
		//}

		c->zombie_dying_flag = false;
	}
}

void ChannelConnection::ParseZombieModeStartSaveDying(Core::BinaryNetworkReader & reader)
{
	byte uid;
	byte dying_uid;
	float t;

	reader.ReadByte(uid);
	reader.ReadByte(dying_uid);
	reader.ReadFloat(t);

	tempc_ptr(Character) c = gLevel->GetCharacter(uid);
	tempc_ptr(Character) dying_c = gLevel->GetCharacter(dying_uid);

	if(uid != dying_uid && c && dying_c)
	{
		c->zombie_saving_uid = dying_uid;
		c->zombie_saving_timer = t;
		c->zombie_saving_flag = true;
		dying_c->zombie_saver_uid = uid;

		// todo

	}
}

void ChannelConnection::ParseZombieModeHumanRespawn(Core::BinaryNetworkReader & reader)
{
	byte uid;
	byte saver_uid;
	int hp;
	int max_hp;
	int ex_hp;
	reader.ReadByte(uid);
	reader.ReadByte(saver_uid);
	reader.ReadInt(hp);
	reader.ReadInt(max_hp);
	reader.ReadInt(ex_hp);


	tempc_ptr(Character) c = gLevel->GetCharacter(uid);
	tempc_ptr(Character) p = gLevel->GetPlayer();
	tempc_ptr(Character) saver = gLevel->GetCharacter(saver_uid);

	if (c && saver)
	{
		if (c->GetTeam() == 0)
		{
			Core::String str = Core::String::Format(gLang->GetTextW(L"%s������%s���ɵĺã�"),saver->GetName(),c->GetName());
			gLevel->AddHorn(str);
		}
		else
		{
			Core::String str = Core::String::Format(gLang->GetTextW(L"%s������%s��"),saver->GetName(),c->GetName());
			gLevel->AddHorn(str);
		}

	}
	
	if (c && c->zombie_dying_flag)
	{
		c->zombie_dying_flag = false;
		c->hp = hp;
		c->max_hp = max_hp;
		c->ex_hp = ex_hp;
		c->zombie_saver_uid = 0;

		if(c == p)
		{
			c->UnLockStateByType(kLSMove);
		}
		if (c->zombie_2D_human_heart)
		{
			c->zombie_2D_human_heart->stop();
			c->zombie_2D_human_heart = NULL;
		}

	}
}

void ChannelConnection::ParseZombieModeStepTwo(Core::BinaryNetworkReader & reader)
{
	int zombie_area_id;
	AxisAlignedBox aabb;
	reader.ReadInt(zombie_area_id);

	reader.ReadVector3(aabb.Min);
	reader.ReadVector3(aabb.Max);

	gLevel->zombie_target_aabb.Clear();

	gLevel->zombie_target_aabb.PushBack(aabb);

	LogSystem.WriteLinef(" zombie_arear %d  x: %f y:%f z; %f", zombie_area_id, aabb.GetCenter().x, aabb.GetCenter().y, aabb.GetCenter().z);
#if DEBUG_INFO
	Vector3 points[4];
	int array[24] = 
	{
		0,1,3,2,
		0,4,6,2,
		4,5,7,6,
		1,5,7,3,
		0,1,5,4,
		2,3,7,6
	};

	for (uint i = 0;i < 6; i++)
	{
		for (uint j = 0; j < 4; j++)
		{
			AxisAlignedBox::Corner c = AxisAlignedBox::Corner(array[i * 4 + j]);
			points[j] = aabb.GetCornerPos(c);
		}
		DebugPrimitiveRect rect;
		rect.CreateVertice(points,4);

		gLevel->debug_check_zone_rect.Add(rect);
	}
#endif

	for (U32 i = 0; i < gLevel->anim_object_array.Size(); i++)
	{
		gLevel->anim_object_array[i]->PlayActionByIndex(zombie_area_id);
	}
	for (U32 i = 0; i < gLevel->gate_array.Size(); i++)
	{
		tempc_ptr(GateBase) gate = gLevel->gate_array[i];
		if(gate && !gate->IsActive())
		{
			gLevel->activeHaveTime = gLevel->activeGateTime;
			gLevel->isCanActiveGate = false;
			gate->SetActiveTime(gLevel->activeGateTime);
		}
	}
	gLevel->zombie_state_two_flag = true;
	if (gLevel->zombie_state_two_muisc)
	{
		gLevel->zombie_state_two_muisc->start();
	}
	//tempc_ptr(Character) player = gLevel->GetPlayer();
	//if (player && player->GetTeam() == 0)
	//{
	//	FmodSystem::PlayEvent("bj/event/bio/bio_escape");
	//}
	//else if (player && player->GetTeam() == 1)
	//{
	//	FmodSystem::PlayEvent("bj/event/bio/bio_huntdown");
	//}
}

void ChannelConnection::ParseZombieModeStartGame(Core::BinaryNetworkReader & reader)
{
	tempc_ptr(Character) player = gLevel->GetPlayer();
	if (player->GetTeam() == 0)
	{
		FmodSystem::PlayEvent("bj/event/bio/bio_defend");
	} 
	else if (player->GetTeam() == 1)
	{
		FmodSystem::PlayEvent("bj/event/bio/bio_attack");
	}
}

void ChannelConnection::ParseZombieBomer(Core::BinaryNetworkReader & reader)
{
	byte uid;
	reader.ReadByte(uid);

	tempc_ptr(Character) c = gLevel->GetCharacter(uid);

	if (c)
	{
		gLevel->AddParticle("ammo_explosion_rocket_01005",c->GetPosition(),Core::Vector3(0,1,0));
		FMOD_VECTOR vel = {0, 0, 0};
		Core::String str = String::Format("bj/fx/3d/bio_self_explode");
		FmodSystem::Play3DEvent(str,(const FMOD_VECTOR &)c->GetPosition(), vel);
	}
}

void ChannelConnection::ParseChargeSomething(Core::BinaryNetworkReader & reader)
{
	byte uid;
	byte isplayer;
	reader.ReadByte(uid);
	reader.ReadByte(isplayer);

	if (isplayer == 0)
	{
		tempc_ptr(Character) c = gLevel->GetCharacter(uid);
		if (c != gLevel->GetPlayer())
		{
			const ThirdPerson & third_person = c->GetThirdPerson();
			if(third_person.node_group)
			{
				third_person.node_list_system->SetActiveNode("game");
			}
		}
		else if (c)
		{
			const FirstPerson & first_person = c->GetFirstPerson();
			if(first_person.animation_group)
			{
				first_person.animation_group->StopAction(true);
			}
		}
	}
}

void ChannelConnection::ParseCommonZombie_Flash(Core::BinaryNetworkReader & reader)
{
	byte uid;
	byte team;
	int hp;
	int armor;
	byte start_point = 0;
	float invincible_time = 0;
	Core::Vector3 position(0, 0, 0);
	Quaternion rotation;
	int max_hp;
	int ex_hp;
	int s_rand;
	int common_zombie_level;
	float common_zombie_energy;
	float common_zombie_energy_percent;
	//byte pack_index;

	sharedc_ptr(CharacterInfo) character_info = ptr_new CharacterInfo();

	reader.ReadByte(uid);
	reader.ReadByte(team);
	reader.ReadInt(hp);
	reader.ReadInt(max_hp);
	reader.ReadInt(ex_hp);
	reader.ReadInt(armor);
	reader.ReadInt(s_rand);
	reader.ReadVector3(position);
	reader.ReadQuaternion(rotation);
	//reader.ReadInt(career);
	ReadCharacterInfo(reader, *character_info);
	reader.ReadInt(common_zombie_level);
	reader.ReadFloat(common_zombie_energy);
	reader.ReadFloat(common_zombie_energy_percent);

	int career = character_info->career_id;

	tempc_ptr(Character) c = gLevel->GetCharacter(uid);

	if (c)
	{
		tempc_ptr(Character) pPlayer = gLevel->GetPlayer();
		if(c == pPlayer)
		{
			pPlayer->relife_flag = false;
			pPlayer->relife_time = 0.0f;
			pPlayer->select_player_flag = false;
			pPlayer->SetViewMode(Character::kFirstPerson);
			game_state = kAlive;
			pPlayer->SetCrouch(false);
			SpawnConfirm();
			tempc_ptr(SniperGun) gun = ptr_dynamic_cast<SniperGun>(pPlayer->GetWeapon());
			if (gun)
				gun->SetSight(0);
			pPlayer->common_zombie_level = common_zombie_level;
			pPlayer->common_zombie_energy = common_zombie_energy;
			pPlayer->common_zombie_energy_percent = common_zombie_energy_percent;
		}
		c->GetThirdPerson().ClearHumanParticle();
		if (c->common_zombie_level > 0)
		{
			c->GetThirdPerson().CreateZombieParticle();
		}

		c->ready = true;
		c->connected = true;
		c->invincible_time = invincible_time;
		c->weapon_id = -1;

		c->playing = true;
		c->grenade_cd_time = -1.f;

		c->max_hp = max_hp;
		c->ex_hp = ex_hp;

		c->rand_fun.Srand(s_rand);

		c->SetTeam(team);

		c->ClearLockState();

		c->SetCareer(career, character_info);
		c->SetPhysxGroup(team + PhysxSystem::kGroupStart);

		c->Rebirth(hp, armor, position, rotation);
		if (c == gLevel->GetPlayer())
		{
			tempc_ptr(StateMainGame) state_main = ptr_dynamic_cast<StateMainGame>(gGame->machine.CurrentState());
			if(state_main)
				state_main->EventCloseCharacter.Fire(ptr_static_cast<StateMainGame>(state_main), EventArgs());
			gLevel->targetenemy_time = 0.f;
			gLevel->tmpplayer = NullPtr;
			if (character_info->career_id == DEFAULT_ZOMBIE_KING)
			{
				FmodSystem::PlayEvent("bj/event/bio/become_bioking");
			}
		}

		c->UpdateRawCharacterChangeableInfo();
		c->GetThirdPerson().CreateFootParticle("zombie_showup");

		for (int i = 0; i < 7; ++i)
		{
			tempc_ptr(WeaponBase) weapon = c->GetWeaponById(i);
			if (weapon && weapon->CanActive())
			{
				c->SelectWeapon(i, true);
				break;
			}
		}

		//for (int i = 0; i < 7; i++)
		//{
		//	tempc_ptr(WeaponBase) weapon = c->GetWeaponById(i);
		//	if (weapon && weapon->CanActive())
		//	{
		//		weapon->is_weapon_updated = false;
		//	}
		//}

		c->zombie_dying_flag = false;
		bool flag = false;
		for (uint i = 0; i < c->basecharacter_info->item_set.Size(); ++i)
		{
			if (c->basecharacter_info->item_set[i].type == 51)
			{
				flag = true;
			}
		}
		//���״̬BUF
		tempc_ptr(StateMainGame) state_main = ptr_dynamic_cast<StateMainGame>(gGame->machine.CurrentState());
		if (state_main && gLevel->GetPlayer() == c)
		{
			state_main->ui->commonzombie_skill.Clear();
			state_main->ui->m_Showmiddle_str_time = 3.0f;
			if (flag)
			{
				state_main->ui->m_Middle_str = gLang->GetTextW(L"���Ϊ�����������壡");
			}
			else
			{
				state_main->ui->m_Middle_str = gLang->GetTextW(L"���Ϊ����ͨ�����壡");
			}
		}
	}
}

void ChannelConnection::ParseCommonKingZombie_Flash(Core::BinaryNetworkReader & reader)
{
	byte uid;
	byte team;
	int hp;
	int armor;
	byte start_point = 0;
	float invincible_time = 0;
	Core::Vector3 position(0, 0, 0);
	Quaternion rotation;
	int max_hp;
	int ex_hp;
	int s_rand;
	int common_zombie_level;
	float common_zombie_energy;
	float common_zombie_energy_percent;
	//byte pack_index;

	sharedc_ptr(CharacterInfo) character_info = ptr_new CharacterInfo();

	reader.ReadByte(uid);
	reader.ReadByte(team);
	reader.ReadInt(hp);
	reader.ReadInt(max_hp);
	reader.ReadInt(ex_hp);
	reader.ReadInt(armor);
	reader.ReadInt(s_rand);
	reader.ReadVector3(position);
	reader.ReadQuaternion(rotation);
	//reader.ReadInt(career);
	ReadCharacterInfo(reader, *character_info);
	reader.ReadInt(common_zombie_level);
	reader.ReadFloat(common_zombie_energy);
	reader.ReadFloat(common_zombie_energy_percent);

	int career = character_info->career_id;

	tempc_ptr(Character) c = gLevel->GetCharacter(uid);

	if (c)
	{
		tempc_ptr(Character) pPlayer = gLevel->GetPlayer();
		if(c == pPlayer)
		{
			pPlayer->relife_flag = false;
			pPlayer->relife_time = 0.0f;
			pPlayer->select_player_flag = false;
			pPlayer->SetViewMode(Character::kFirstPerson);
			game_state = kAlive;
			pPlayer->SetCrouch(false);
			SpawnConfirm();
			tempc_ptr(SniperGun) gun = ptr_dynamic_cast<SniperGun>(pPlayer->GetWeapon());
			if (gun)
				gun->SetSight(0);
			pPlayer->common_zombie_level = common_zombie_level;
			pPlayer->common_zombie_energy = common_zombie_energy;
			pPlayer->common_zombie_energy_percent = common_zombie_energy_percent;
		}

		c->ready = true;
		c->connected = true;
		c->invincible_time = invincible_time;
		c->weapon_id = -1;

		c->playing = true;
		c->grenade_cd_time = -1.f;

		c->max_hp = max_hp;
		c->ex_hp = ex_hp;

		c->rand_fun.Srand(s_rand);

		c->SetTeam(team);

		c->ClearLockState();

		c->SetCareer(career, character_info);
		c->SetPhysxGroup(team + PhysxSystem::kGroupStart);

		c->Rebirth(hp, armor, position, rotation);
		if (c == gLevel->GetPlayer())
		{
			tempc_ptr(StateMainGame) state_main = ptr_dynamic_cast<StateMainGame>(gGame->machine.CurrentState());
			if(state_main)
				state_main->EventCloseCharacter.Fire(ptr_static_cast<StateMainGame>(state_main), EventArgs());
			gLevel->targetenemy_time = 0.f;
			gLevel->tmpplayer = NullPtr;
			if (character_info->career_id == DEFAULT_ZOMBIE_KING)
			{
				FmodSystem::PlayEvent("bj/event/bio/become_bioking");
			}
		}

		c->UpdateRawCharacterChangeableInfo();
		c->GetThirdPerson().CreateFootParticle("zombie_showup");
		if (c->common_zombie_level > 0)
		{
			c->GetThirdPerson().CreateZombieParticle();
		}
		

		for (int i = 0; i < 7; ++i)
		{
			tempc_ptr(WeaponBase) weapon = c->GetWeaponById(i);
			if (weapon && weapon->CanActive())
			{
				c->SelectWeapon(i, true);
				break;
			}
		}

		//for (int i = 0; i < 7; i++)
		//{
		//	tempc_ptr(WeaponBase) weapon = c->GetWeaponById(i);
		//	if (weapon && weapon->CanActive())
		//	{
		//		weapon->is_weapon_updated = false;
		//	}
		//}

		//���״̬BUF
		bool flag = false;
		for (uint i = 0; i < c->basecharacter_info->item_set.Size(); ++i)
		{
			if (c->basecharacter_info->item_set[i].type == 51)
			{
				flag = true;
			}
		}
		tempc_ptr(StateMainGame) state_main = ptr_dynamic_cast<StateMainGame>(gGame->machine.CurrentState());
		if (state_main && gLevel->GetPlayer() == c)
		{
			state_main->ui->commonzombie_skill.Clear();
			state_main->ui->m_Showmiddle_str_time = 3.0f;
			if (flag)
			{
				state_main->ui->m_Middle_str = gLang->GetTextW(L"���Ϊ�����������壡");
			}
			else
			{
				state_main->ui->m_Middle_str = gLang->GetTextW(L"���Ϊ��ĸ�������壡");
			}
		}

		if (!gLevel->commonzombie_king_isShow)
		{
			Core::String str = gLang->GetTextW(L"ĸ����������֣�");
			FMOD_VECTOR vel = {0, 0, 0};
			FmodSystem::Play3DEvent("bj/fx/3d/bio2/zombie_appear",(const FMOD_VECTOR &)c->GetPosition(),vel);
			//FmodSystem::PlayEvent("bj/event/crazy_killer");
			gLevel->AddHorn(str);
			gLevel->commonzombie_king_isShow = true;
		}
	}
}

void ChannelConnection::ParsCommonZombie_LevelChange(Core::BinaryNetworkReader & reader)
{
	byte uid;
	int level;
	byte is_up;
	reader.ReadByte(uid);
	reader.ReadInt(level);
	reader.ReadByte(is_up);
	tempc_ptr(Character) c = gLevel->GetCharacter(uid);
	tempc_ptr(Character) Player = gLevel->GetPlayer();
	if (c)
	{
		c->common_zombie_level = level;
		if (is_up)
		{
			c->GetThirdPerson().CreateFootParticle("zombie_update");
			tempc_ptr(StateMainGame) state_main = ptr_dynamic_cast<StateMainGame>(gGame->machine.CurrentState());			
			if (Player && Player == c && state_main)
			{
				state_main->ui->m_commonzombie_level_isup_time[0] = 0.0f;
			}
			FMOD_VECTOR vel = {0, 0, 0};
			FmodSystem::Play3DEvent("bj/fx/3d/bio2/zombie_levelup",(const FMOD_VECTOR &)c->GetPosition(),vel);
			//FmodSystem::PlayEvent("bj/event/crazy_killer");
		}
		if (c->common_zombie_level > 0 && !c->is_zombie_super)
			c->GetThirdPerson().CreateZombieParticle();
		else
			c->GetThirdPerson().ClearZombieParticle();
	}
}

void ChannelConnection::ParseCommonZombie_EnergyChange(Core::BinaryNetworkReader & reader)
{
	byte uid;
	float common_zombie_energy;
	float common_zombie_energy_percent;
	reader.ReadByte(uid);
	reader.ReadFloat(common_zombie_energy);
	reader.ReadFloat(common_zombie_energy_percent);
	tempc_ptr(Character) c = gLevel->GetCharacter(uid);
	if (c)
	{
		c->common_zombie_energy = common_zombie_energy;
		c->common_zombie_energy_percent = common_zombie_energy_percent;
	}
}

void ChannelConnection::ParseCommonZombie_Super(Core::BinaryNetworkReader & reader)
{
	byte uid;
	int hp;
	int max_hp;
	int ex_hp;
	Core::Vector3 position(0, 0, 0);
	Quaternion rotation;

	sharedc_ptr(CharacterInfo) character_info = ptr_new CharacterInfo();

	reader.ReadByte(uid);
	reader.ReadInt(hp);
	reader.ReadInt(max_hp);
	reader.ReadInt(ex_hp);
	reader.ReadVector3(position);
	reader.ReadQuaternion(rotation);
	ReadCharacterInfo(reader, *character_info);

	int career = character_info->career_id;

	tempc_ptr(Character) c = gLevel->GetCharacter(uid);

	if (c)
	{
		Character *pPlayer = gLevel->GetPlayer();
		if(c == pPlayer)
		{
			pPlayer->relife_time = 0.0f;
			pPlayer->select_player_flag = false;
			pPlayer->SetViewMode(Character::kFirstPerson);
			game_state = kAlive;
			pPlayer->SetCrouch(false);
			SpawnConfirm();
			tempc_ptr(SniperGun) gun = ptr_dynamic_cast<SniperGun>(pPlayer->GetWeapon());
			if (gun)
				gun->SetSight(0);
		}

		c->relife_flag = false;
		c->ready = true;
		c->connected = true;
		c->weapon_id = -1;

		c->playing = true;
		c->grenade_cd_time = -1.f;

		c->max_hp = max_hp;
		c->ex_hp = ex_hp;

		c->ClearLockState();

		c->SetCareer(career, character_info);

		c->Rebirth(hp, 0, position, rotation);

		c->UpdateRawCharacterChangeableInfo();
		c->GetThirdPerson().CreateFootParticle("predator_showup");
		c->GetThirdPerson().ClearZombieParticle();
		c->is_zombie_super = true;

		c->zombiegun_cd_time = 0.f;

		for (int i = 0; i < 7; ++i)
		{
			tempc_ptr(WeaponBase) weapon = c->GetWeaponById(i);
			if (weapon && weapon->CanActive())
			{
				c->SelectWeapon(i, true);
				break;
			}
		}

		//for (int i = 0; i < 7; i++)
		//{
		//	tempc_ptr(WeaponBase) weapon = c->GetWeaponById(i);
		//	if (weapon && weapon->CanActive())
		//	{
		//		weapon->is_weapon_updated = false;
		//	}
		//}

		Core::String str = gLang->GetTextW(L"�ռ���������֣�");
		FMOD_VECTOR vel = {0, 0, 0};
		FmodSystem::Play3DEvent("bj/fx/3d/bio2/predator_appear",(const FMOD_VECTOR &)c->GetPosition(),vel);
		//FmodSystem::PlayEvent("bj/event/crazy_killer");
		gLevel->AddHorn(str);
	}
}

void ChannelConnection::ParseCommonHuman_Super(Core::BinaryNetworkReader & reader)
{
	byte uid;
	int hp;
	int max_hp;
	int ex_hp;
	Core::Vector3 position(0, 0, 0);
	Quaternion rotation;

	sharedc_ptr(CharacterInfo) character_info = ptr_new CharacterInfo();

	reader.ReadByte(uid);
	reader.ReadInt(hp);
	reader.ReadInt(max_hp);
	reader.ReadInt(ex_hp);
	reader.ReadVector3(position);
	reader.ReadQuaternion(rotation);
	ReadCharacterInfo(reader, *character_info);

	int career = character_info->career_id;

	tempc_ptr(Character) c = gLevel->GetCharacter(uid);

	if (c)
	{
		tempc_ptr(Character) pPlayer = gLevel->GetPlayer();
		if(c == pPlayer)
		{
			pPlayer->relife_time = 0.0f;
			pPlayer->select_player_flag = false;
			pPlayer->SetViewMode(Character::kFirstPerson);
			game_state = kAlive;
			pPlayer->SetCrouch(false);
			SpawnConfirm();
			tempc_ptr(SniperGun) gun = ptr_dynamic_cast<SniperGun>(pPlayer->GetWeapon());
			if (gun)
				gun->SetSight(0);
		}
		c->is_human_super = true;
		c->relife_flag = false;
		c->ready = true;
		c->connected = true;
		c->weapon_id = -1;

		c->playing = true;
		c->grenade_cd_time = -1.f;

		c->max_hp = max_hp;
		c->ex_hp = ex_hp;

		c->ClearLockState();

		c->SetCareer(career, character_info);

		c->Rebirth(hp, 0, position, rotation);

		c->UpdateRawCharacterChangeableInfo();

		c->GetThirdPerson().CreateFootParticle("human_showup");

		c->GetThirdPerson().CreateHumanParticle();

		//�����ż���
		gGame->channel_connection->UseSkillSuperMan(c->uid);
		
		for (int i = 0; i < 7; ++i)
		{
			tempc_ptr(WeaponBase) weapon = c->GetWeaponById(i);
			if (weapon && weapon->CanActive())
			{
				c->SelectWeapon(i, true);
				break;
			}
		}

		//for (int i = 0; i < 7; i++)
		//{
		//	tempc_ptr(WeaponBase) weapon = c->GetWeaponById(i);
		//	if (weapon && weapon->CanActive())
		//	{
		//		weapon->is_weapon_updated = false;
		//	}
		//}

		//���״̬BUF
		tempc_ptr(StateMainGame) state_main = ptr_dynamic_cast<StateMainGame>(gGame->machine.CurrentState());
		if (state_main && gLevel->GetPlayer() == c)
		{
			state_main->ui->commonzombie_skill.Clear();
			state_main->ui->m_Showmiddle_str_time = 3.0f;
			state_main->ui->m_Middle_str = gLang->GetTextW(L"���Ϊ�����������֣�");
		}

		Core::String str = gLang->GetTextW(L"����ֻʣ���1�ˣ����������ֳ��֣�");
		FMOD_VECTOR vel = {0, 0, 0};
		FmodSystem::Play3DEvent("bj/fx/3d/bio2/hunter_appear",(const FMOD_VECTOR &)c->GetPosition(),vel);
		//FmodSystem::PlayEvent("bj/event/crazy_killer");
		gLevel->AddHorn(str);
	}
}

void ChannelConnection::ParseCommonZombie_Unable(Core::BinaryNetworkReader & reader)
{
	byte uid;
	int hp;
	int max_hp;
	int ex_hp;
	float unable_time;

	sharedc_ptr(CharacterInfo) character_info = ptr_new CharacterInfo();

	reader.ReadByte(uid);
	reader.ReadInt(hp);
	reader.ReadInt(max_hp);
	reader.ReadInt(ex_hp);
	reader.ReadFloat(unable_time);


	int career = character_info->career_id;

	tempc_ptr(Character) c = gLevel->GetCharacter(uid);
	tempc_ptr(Character) play = gLevel->GetPlayer();
	tempc_ptr(StateMainGame) state_main = ptr_dynamic_cast<StateMainGame>(gGame->machine.CurrentState());
	if (c)
	{
		c->hp = hp;
		c->common_zombie_dying_flag = true;
		c->commonzombie_dying_time = 0.0f;
		c->commonzombie_dying_totletime = unable_time;
	}
}

void ChannelConnection::ParseKing_Zombie_Respawn(Core::BinaryNetworkReader & reader)
{
	byte uid;
	byte team;
	int hp;
	int armor;
	byte start_point = 0;
	float invincible_time = 0;
	Core::Vector3 position(0, 0, 0);
	Quaternion rotation;
	int max_hp;
	int ex_hp;
	int s_rand;
	int common_zombie_level;
	float common_zombie_energy;
	float common_zombie_energy_percent;

	sharedc_ptr(CharacterInfo) character_info = ptr_new CharacterInfo();

	reader.ReadByte(uid);
	reader.ReadByte(team);
	reader.ReadInt(hp);
	reader.ReadInt(max_hp);
	reader.ReadInt(ex_hp);
	reader.ReadInt(armor);
	reader.ReadInt(s_rand);
	reader.ReadVector3(position);
	reader.ReadQuaternion(rotation);
	ReadCharacterInfo(reader, *character_info);
	reader.ReadInt(common_zombie_level);
	reader.ReadFloat(common_zombie_energy);
	reader.ReadFloat(common_zombie_energy_percent);
	
	tempc_ptr(Character) c = gLevel->GetCharacter(uid);
	if (c)
	{
		Character *pPlayer = gLevel->GetPlayer();
		if(c == pPlayer)
		{
			pPlayer->relife_time = 0.0f;
			pPlayer->select_player_flag = false;
			pPlayer->SetViewMode(Character::kFirstPerson);
			game_state = kAlive;
			pPlayer->SetCrouch(false);
			SpawnConfirm();
			tempc_ptr(SniperGun) gun = ptr_dynamic_cast<SniperGun>(pPlayer->GetWeapon());
			if (gun)
				gun->SetSight(0);
			pPlayer->common_zombie_level = common_zombie_level;
			pPlayer->common_zombie_energy = common_zombie_energy;
			pPlayer->common_zombie_energy_percent = common_zombie_energy_percent;
		}
		c->relife_flag = false;
		c->common_zombie_dying_flag = false;
		c->ready = true;
		c->connected = true;
		c->invincible_time = invincible_time;
		c->weapon_id = -1;

		c->playing = true;
		c->grenade_cd_time = -1.f;

		c->max_hp = max_hp;
		c->ex_hp = ex_hp;

		c->rand_fun.Srand(s_rand);

		c->SetTeam(team);

		c->ClearLockState();

		c->SetPhysxGroup(team + PhysxSystem::kGroupStart);

		c->Rebirth(hp, 0, position, rotation);
		if (c == gLevel->GetPlayer())
		{
			tempc_ptr(StateMainGame) state_main = ptr_dynamic_cast<StateMainGame>(gGame->machine.CurrentState());
			if(state_main)
				state_main->EventCloseCharacter.Fire(ptr_static_cast<StateMainGame>(state_main), EventArgs());
			gLevel->targetenemy_time = 0.f;
			gLevel->tmpplayer = NullPtr;
			if (character_info->career_id == DEFAULT_ZOMBIE_KING)
			{
				FmodSystem::PlayEvent("bj/event/bio/become_bioking");
			}
		}

		c->UpdateRawCharacterChangeableInfo();

		for (int i = 0; i < 7; ++i)
		{
			tempc_ptr(WeaponBase) weapon = c->GetWeaponById(i);
			if (weapon && weapon->CanActive())
			{
				c->SelectWeapon(i, true);
				break;
			}
		}

		//for (int i = 0; i < 7; i++)
		//{
		//	tempc_ptr(WeaponBase) weapon = c->GetWeaponById(i);
		//	if (weapon && weapon->CanActive())
		//	{
		//		weapon->is_weapon_updated = false;
		//	}
		//}
	}
}

void ChannelConnection::ParseHumanEnergyChange(Core::BinaryNetworkReader & reader)
{
	byte uid;
	int energy;
	reader.ReadByte(uid);
	reader.ReadInt(energy);
	tempc_ptr(Character) c = gLevel->GetCharacter(uid);
	if (c)
	{
		c->human_energy = energy;
	}
}

void ChannelConnection::ParseHumanPowerUp(Core::BinaryNetworkReader & reader)
{
	byte uid;
	reader.ReadByte(uid);
	tempc_ptr(Character) c = gLevel->GetCharacter(uid);
	if (c)
	{
		c->benefitshadertype = kWeaponAttr_Benefit_DamageAdd;
		c->benefitshadertime = 10.0f;
		c->human_energy = 5000;
	}
}

void ChannelConnection::ParseZombieBomerHurt(Core::BinaryNetworkReader & reader)
{
	//ENCODE_START

	byte uid;
	byte hurt_uid;
	reader.ReadByte(uid);
	reader.ReadByte(hurt_uid);

	if (hurt_uid)
	{
		tempc_ptr(Character) c = gLevel->GetCharacter(hurt_uid);

		tempc_ptr(Character) h = gLevel->GetCharacter(uid);

		if(h)
			h->is_shoot_stab = false;

		TakeDamage(reader, h, c, h->GetPosition(),false,false);
	}

	//ENCODE_END
}

void ChannelConnection::ParseZombieModeCancelSaveDying(Core::BinaryNetworkReader & reader)
{
	byte uid;
	byte dying_uid;

	reader.ReadByte(uid);
	reader.ReadByte(dying_uid);

	tempc_ptr(Character) c = gLevel->GetCharacter(uid);
	tempc_ptr(Character) dying_c = gLevel->GetCharacter(dying_uid);

	if(c)
	{
		c->zombie_saving_uid = 0;
		c->zombie_saving_timer = -1.f;
		//c->zombie_saving_flag = false;
	}

	if(dying_c)
	{
		dying_c->zombie_saver_uid = 0;
		if (dying_c->zombie_saver_uid == 0)
		   c->zombie_saving_flag = false;
	}
}

void ChannelConnection::ParseStreetKing_Flash(Core::BinaryNetworkReader & reader)
{
	byte uid;
	byte team;
	int hp;
	int armor;
	byte start_point = 0;
	float invincible_time = 0;
	Core::Vector3 position(0, 0, 0);
	float angle;
	int max_hp;
	int ex_hp;
	int s_rand;
	//byte pack_index;
	int career = 0;
	byte street_king_state;
	sharedc_ptr(CharacterInfo) character_info = ptr_new CharacterInfo();

	reader.ReadByte(uid);
	reader.ReadByte(team);
	reader.ReadInt(hp);
	reader.ReadInt(max_hp);
	reader.ReadInt(ex_hp);
	reader.ReadInt(armor);
	reader.ReadInt(s_rand);
	reader.ReadVector3(position);
	reader.ReadFloat(angle);
	//reader.ReadInt(career);
	ReadCharacterInfo(reader, *character_info);
	reader.ReadByte(street_king_state);

	tempc_ptr(Character) c = gLevel->GetCharacter(uid);

	if (c)
	{
		Character *pPlayer = gLevel->GetPlayer();
		if(c == pPlayer)
		{
			pPlayer->relife_flag = false;
			pPlayer->relife_time = 0.0f;
			pPlayer->select_player_flag = false;
			pPlayer->SetViewMode(Character::kFirstPerson);
			game_state = kAlive;
			pPlayer->SetCrouch(false);
			SpawnConfirm();
			tempc_ptr(SniperGun) gun = ptr_dynamic_cast<SniperGun>(pPlayer->GetWeapon());
			if (gun)
				gun->SetSight(0);
		}

		c->ready = true;
		c->connected = true;
		c->invincible_time = invincible_time;
		c->weapon_id = -1;

		c->playing = true;
		c->grenade_cd_time = -1.f;

		c->max_hp = max_hp;
		c->ex_hp = ex_hp;

		c->rand_fun.Srand(s_rand);

		c->SetTeam(team);

		c->ClearLockState();

		c->SetCareer(career, character_info);
		c->SetPhysxGroup(team + PhysxSystem::kGroupStart);

		c->Rebirth(hp, armor, position, Quaternion(Vector3(0, 1, 0), DEG2RAD * angle));
		if (c == gLevel->GetPlayer())
		{
			tempc_ptr(StateMainGame) state_main = ptr_dynamic_cast<StateMainGame>(gGame->machine.CurrentState());
			if(state_main)
				state_main->EventCloseCharacter.Fire(ptr_static_cast<StateMainGame>(state_main), EventArgs());
			gLevel->targetenemy_time = 0.f;
			gLevel->tmpplayer = NullPtr;
		}

		c->UpdateRawCharacterChangeableInfo();

		for (int i = 0; i < 7; ++i)
		{
			tempc_ptr(WeaponBase) weapon = c->GetWeaponById(i);
			if (weapon && weapon->CanActive())
			{
				c->SelectWeapon(i, true);
				break;
			}
		}

		//for (int i = 0; i < 7; i++)
		//{
		//	tempc_ptr(WeaponBase) weapon = c->GetWeaponById(i);
		//	if (weapon && weapon->CanActive())
		//	{
		//		weapon->is_weapon_updated = false;
		//	}
		//}

		if(team < 2)
		{
			gLevel->current_street_king_uid[team] = uid;
			gLevel->street_king_state[team] = street_king_state;
		}

		c->GetThirdPerson().CreateFootParticle();
		c->zombie_dying_flag = false;

	}
}

// parse sync holdpointinfo
void ChannelConnection::ParseSyncHoldPointInfo(Core::BinaryNetworkReader & reader)
{
	//ENCODE_START

	int count;

	reader.ReadInt(count);

	PDE_ASSERT((U32)count == gLevel->hold_points.Size(), "hold_points is invaild");

	if (gLevel->hold_points.Size() > 0)
	{
		gLevel->hold_point_fPersert_red = gLevel->hold_points[0].snatching_timer;
		gLevel->hold_point_fPersert_blue = gLevel->hold_points[0].snatching_timer;
	}

	for (int i = 0; i < count; i++)
	{
		byte tempb = gLevel->hold_points[i].owner_team;
		reader.ReadByte(gLevel->hold_points[i].owner_team);
		reader.ReadByte(gLevel->hold_points[i].snatch_team);
		reader.ReadFloat(gLevel->hold_points[i].snatching_timer);

		if(tempb != gLevel->hold_points[i].owner_team)
		{
			HornSystemMessage(kHornHoldPointSuccessMessage,gLevel->hold_points[i].owner_team);
		}

#ifdef _DEBUG
		//LogSystem.WriteLinef("%f", (float)Task::GetTotalTime());
		//LogSystem.WriteLinef("\thold_points[%d].owner_team = %d", i, (int)gLevel->hold_points[i].owner_team);
		//LogSystem.WriteLinef("\thold_points[%d].snatch_team = %d", i, (int)gLevel->hold_points[i].snatch_team);
		//LogSystem.WriteLinef("\thold_points[%d].snatch_team = %f", i, gLevel->hold_points[i].snatching_timer);
#endif
	}

	if (gLevel->hold_points.Size() > 0)
	{
		gLevel->speed_red = gLevel->hold_points[0].snatching_timer - gLevel->hold_point_fPersert_red;
		gLevel->speed_blue = gLevel->hold_points[0].snatching_timer - gLevel->hold_point_fPersert_blue;
	}

	reader.ReadFloat(gLevel->team_timer[0]);
	reader.ReadFloat(gLevel->team_timer[1]);
	reader.ReadByte(gLevel->cur_holdpoint_diffnum);

	int score = 0;
	reader.ReadInt(score);

	bool isPass = false;
	tempc_ptr(Character) player = gLevel->GetPlayer();
	if (player && player->all_score < score)
	{
		if (player->all_score == score)
			isPass = true;
		else
		{
			player->kill_showscore = score - player->all_score;
			player->kill_score_time = 0.f;
		}

		player->all_score = score;
	}

	if (player && player->ui_score_line >= 0 && player->ui_score_line < 3)
	{
		AddEnergyEffectInfo &info = player->energy_bar_info;
		if (player->all_score < player->get_score && !isPass)
		{
			info.move_time = 0.0f;
			info.move_all_time = 0.75f;

			info.all_value = 1.0f;
			info.current_value = info.current_target_value;
			info.current_target_value = Core::Clamp((player->all_score - player->get_last_score)/(player->get_score - player->get_last_score),0,1);
		}
		else if (!isPass)
		{
			player->UpdateUiScoreLine();
			
			info.move_time = 0.0f;
			info.move_all_time = 0.75f;

			info.all_value = 1.0f;
			info.current_value = info.current_target_value;
			info.current_target_value = Core::Clamp((player->all_score - player->get_last_score)/(player->get_score - player->get_last_score),0,1);
		}
	}

	if(gLevel->team_timer[0] < 60.f && !gLevel->team_timer_warning[0] )
	{
		gLevel->team_timer_warning[0] = true;
		HornSystemMessage(kHornHoldPointLeft60sMessage,0);
	}

	if(gLevel->team_timer[1] < 60.f && !gLevel->team_timer_warning[1] )
	{
		gLevel->team_timer_warning[1] = true;
		HornSystemMessage(kHornHoldPointLeft60sMessage,1);
	}

	//ENCODE_END
}

void ChannelConnection::ParseUpdateVehicleInfo(Core::BinaryNetworkReader & reader)
{
	//ENCODE_START

	if (!gLevel->vehicle[0] || !gLevel->vehicle[1])
		return;
	float total_length_red = gLevel->vehicle[0]->current_vehicle_info.total_length;
	float total_length_blue = gLevel->vehicle[1]->current_vehicle_info.total_length;
	PushVehicleInfo info_red, info_blue;
	reader.ReadVector3(info_red.position);
	reader.ReadVector3(info_red.dir);
	info_red.team = 0;

	reader.ReadVector3(info_blue.position);
	reader.ReadVector3(info_blue.dir);
	info_blue.team = 1;
	 
	info_red.total_length = total_length_red;
	info_blue.total_length = total_length_blue;

	reader.ReadFloat(info_red.current_length);
	reader.ReadFloat(info_blue.current_length);

	float percent[2];
	percent[0] = info_red.current_length / total_length_red;
	percent[1] = info_blue.current_length / total_length_blue;

	reader.ReadInt(info_red.sliding);
	reader.ReadInt(info_blue.sliding);

	reader.ReadInt(info_red.player_count);
	reader.ReadInt(info_blue.player_count);

	reader.ReadVector3(info_red.aabb.Min);
	reader.ReadVector3(info_red.aabb.Max);

	reader.ReadVector3(info_blue.aabb.Min);
	reader.ReadVector3(info_blue.aabb.Max);

	//reader.ReadVector3(info_red.aabb_kick.Min);
	//reader.ReadVector3(info_red.aabb_kick.Max);

	//reader.ReadVector3(info_blue.aabb_kick.Min);
	//reader.ReadVector3(info_blue.aabb_kick.Max);

	reader.ReadFloat(info_red.time_interval);

	int score = 0;
	reader.ReadInt(score);

	bool isPass = false;
	tempc_ptr(Character) player = gLevel->GetPlayer();
 	if (player && player->all_score < score)
	{
		if (player->all_score == score)
			isPass = true;
		//else
		//{
		//	player->kill_showscore = score - player->all_score;
		//	player->kill_score_time = 0.f;
		//}
		player->all_score = score;
	}

	if (player && player->ui_score_line >= 0 && player->ui_score_line < 3)
	{
		AddEnergyEffectInfo &info = player->energy_bar_info;
		if (player->all_score < player->get_score && !isPass)
		{
			info.move_time = 0.0f;
			info.move_all_time = 0.75f;

			info.all_value = 1.0f;
			info.current_value = info.current_target_value;
			info.current_target_value = Core::Clamp((player->all_score - player->get_last_score)/(player->get_score - player->get_last_score),0,1);
		}
		else if (!isPass)
		{
			player->UpdateUiScoreLine();
		
			info.move_time = 0.0f;
			info.move_all_time = 0.75f;

			info.all_value = 1.0f;
			info.current_value = info.current_target_value;
			info.current_target_value = Core::Clamp((player->all_score - player->get_last_score)/(player->get_score - player->get_last_score),0,1);
		}
	}

	info_blue.time_interval = info_red.time_interval;
	//ReadFloat(info_blue.time_interval);

	gLevel->UpdateVehicleInfo(info_red, info_blue);

	if(!gLevel->vehicle_started[0] && info_red.current_length > 0.05f)
	{
		gLevel->vehicle_started[0] = true;
		HornSystemMessage(kHornPushVehicleStartMessage,0);
	}
	else if(!gLevel->vehicle_half[0] && percent[0] > 0.5f)
	{
		gLevel->vehicle_half[0] = true;
		HornSystemMessage(kHornPushVehicleHalfMessage,0);
	}
	else if(!gLevel->vehicle_almost_end[0] && percent[0] > 0.9f)
	{
		gLevel->vehicle_almost_end[0] = true;
		HornSystemMessage(kHornPushVehicleAlmostSuccessMessage,0);
	}

	if(!gLevel->vehicle_started[1] && info_blue.current_length > 0.05f)
	{
		gLevel->vehicle_started[1] = true;
		HornSystemMessage(kHornPushVehicleStartMessage,1);
	}
	else if(!gLevel->vehicle_half[1] && percent[1] > 0.5f)
	{
		gLevel->vehicle_half[1] = true;
		HornSystemMessage(kHornPushVehicleHalfMessage,1);
	}
	else if(!gLevel->vehicle_almost_end[1] && percent[1] > 0.9f)
	{
		gLevel->vehicle_almost_end[1] = true;
		HornSystemMessage(kHornPushVehicleAlmostSuccessMessage,1);
	}

	//ENCODE_END
}


void ChannelConnection::ParseInitializeVehicleInfo(Core::BinaryNetworkReader & reader)
{
	//ENCODE_START

	PushVehicleInfo info_red, info_blue;
	reader.ReadVector3(info_red.position);
	reader.ReadVector3(info_red.dir);
	info_red.team = 0;

	reader.ReadVector3(info_blue.position);
	reader.ReadVector3(info_blue.dir);
	info_blue.team = 1;

	reader.ReadFloat(info_red.total_length);
	reader.ReadFloat(info_blue.total_length);

	reader.ReadFloat(info_red.time_interval);

	info_blue.time_interval = info_red.time_interval;

	info_blue.current_length = info_red.current_length = 0.f;

	gLevel->InitializeVehicleInfo(info_red, info_blue);

	//ENCODE_END
}

void ChannelConnection::ParsePlayerHitBack(Core::BinaryNetworkReader & reader)
{
	KickInfo info;

	reader.ReadFloat(info.kick_time_interval);
	reader.ReadFloat(info.kick_factor);
	reader.ReadQuaternion(info.dir);
	reader.ReadFloat(info.on_static_kick_y_offset);

	tempc_ptr(Character) player = gLevel->GetPlayer();

	if (!player)
		return;

	player->OnKickBack(info, true);
}

void ChannelConnection::RequestChangeCareerPack( int careerpos )
{
	BeginWrite();
	WriteByte(CM_ChangeCareer);
	WriteInt(careerpos);
	EndWrite();
}

// cure character
void ChannelConnection::CureCharacter(byte to_uid)
{
	if (state != kInGame)
		return;

	if (game_state == kGameLeaving)
		return;

	BeginWrite();
	WriteByte(CM_CureCharacter);
	WriteByte(to_uid);
	EndWrite();
}

void ChannelConnection::ChargeSomething(byte playerid, byte isplayer, Core::Quaternion rot)
{
	if (state != kInGame)
		return;

	if (game_state == kGameLeaving && gLevel->game_type == RoomOption::kZombieMode)
		return; 

	BeginWrite();
	WriteByte(CM_ChargeSomething);
	WriteByte(playerid);
	WriteByte(isplayer);
	WriteQuaternion(rot);
	EndWrite();
}

void ChannelConnection::SkillKickBack(byte playerid, KickInfo info)
{
	BeginWrite();
	WriteByte(CM_SkillKickBack);
	WriteByte(playerid);
	WriteFloat(info.kick_time_interval);
	WriteFloat(info.kick_factor);
	WriteQuaternion(info.dir);
	WriteFloat(info.on_static_kick_y_offset);
	EndWrite();
}

// player start an animation
void ChannelConnection::PlayerAnimationStart(int weapontype, int firestate)
{
	if (state != kInGame)
		return;

	if (game_state == kGameLeaving)
		return;

	BeginWrite();
	WriteByte(CM_PlayerAnimationStart);
	WriteInt(weapontype);
	WriteInt(firestate);
	EndWrite();
}

// player end an animation
void ChannelConnection::PlayerAnimationEnd(int weapontype)
{
	if (state != kInGame)
		return;

	if (game_state == kGameLeaving)
		return;

	BeginWrite();
	WriteByte(CM_PlayerAnimationEnd);
	WriteInt(weapontype);
	EndWrite();
}

// player call doctor
void ChannelConnection::CallDoctor()
{
	if (state != kInGame)
		return;

	if (game_state == kGameLeaving)
		return;

	BeginWrite();
	WriteByte(CM_CallDoctor);
	EndWrite();
}

void ChannelConnection::ConnectionCheck()
{
	if (state != kInGame)
		return;

	BeginWrite();
	WriteByte(CM_ConnectionCheck);
	EndWrite();
}

void ChannelConnection::ParseCutHurt(Core::BinaryNetworkReader & reader)
{
	//ENCODE_START

	byte from_uid;
	byte to_uid;
	int ammo_type;
	bool isboost;

	reader.ReadByte(from_uid);
	reader.ReadByte(to_uid);
	reader.ReadInt(ammo_type);
	reader.ReadByte((byte &)isboost);
	tempc_ptr(Character) c = gLevel->GetCharacter(to_uid);
	tempc_ptr(Character) from = gLevel->GetCharacter(from_uid);

	//LogSystem.WriteLinef("hurt postion %f,%f,%f",pos.x,pos.y,pos.z );

	if (c && from)
	{
		TakeDamage(reader, from, c, from->GetPosition(), false, isboost);

		c->ResponseHit(from->GetPosition(),c->GetPosition(),  Vector3::kZero, 0, ammo_type, true, isboost);
	}

}

void ChannelConnection::ParseSycnBossAction(Core::BinaryNetworkReader & reader)
{
	byte uid;
	Core::Vector3 startpos(0, 0, 0);
	Core::Vector3 endpos(0, 0, 0);
	float startrot;
	float endrot;
	float total_time;
	int movetime;
	int action_id;

	reader.ReadByte(uid);
	reader.ReadVector3(startpos);
	reader.ReadVector3(endpos);
	reader.ReadFloat(startrot);
	reader.ReadFloat(endrot);
	reader.ReadInt(movetime);
	reader.ReadFloat(total_time);
	reader.ReadInt(action_id);

	//LogSystem.WriteLinef("------------------------------------------------------------------------------");
	//LogSystem.WriteLinef("startpos.x = %f   startpos.y = %f   startpos.z = %f",startpos.x,startpos.y,startpos.z);
	//LogSystem.WriteLinef("endpos.x = %f   endpos.y = %f   endpos.z = %f",endpos.x,endpos.y,endpos.z);
	//LogSystem.WriteLinef("movetime = %d   total_time = %f",movetime, total_time);

	tempc_ptr(Character) boss = gLevel->GetCharacter(uid);
	if (boss && !boss->IsDied())
	{
		boss->SetPosition(startpos);
		boss->boss_action_timer = 0;

		boss->boss_startpos = startpos;
		boss->boss_endpos = endpos;
		boss->boss_startrot.SetAxisAngle(Vector3(0,1,0),startrot*DEG2RAD);
		boss->boss_endrot.SetAxisAngle(Vector3(0,1,0),endrot*DEG2RAD);
		boss->boss_move_time = movetime;
		boss->boss_action_total_time = total_time;
		boss->boss_action_id = action_id;

		gLevel->GetLeastBloodCharacter(gLevel->GetPlayer()->GetTeam());
		gLevel->GetMaximumBloodCharacter(gLevel->GetPlayer()->GetTeam());
		gLevel->SetCharactersByBlood(gLevel->GetPlayer()->GetTeam());
	}
}

void ChannelConnection::ParseBoss2Flash(Core::BinaryNetworkReader & reader)
{
	byte uid;
	byte team;
	int hp;
	int armor;
	byte start_point = 0;
	float invincible_time = 0;
	Core::Vector3 position(0, 0, 0);
	float angle;
	int max_hp;
	int ex_hp;
	int s_rand;
	//byte pack_index;
	int career = 0;
 	sharedc_ptr(CharacterInfo) character_info = ptr_new CharacterInfo();

	reader.ReadByte(uid);
	reader.ReadByte(team);
	reader.ReadInt(hp);
	reader.ReadInt(max_hp);
	reader.ReadInt(ex_hp);
	reader.ReadInt(armor);
	reader.ReadInt(s_rand);
	reader.ReadVector3(position);
	reader.ReadFloat(angle);
	//reader.ReadInt(career);
	ReadCharacterInfo(reader, *character_info);

	career = character_info->career_id;

	tempc_ptr(Character) c = gLevel->GetCharacter(uid);

	gLevel->boss_starttimeer = -1;

	if (c)
	{
		Character *pPlayer = gLevel->GetPlayer();
		if(c == pPlayer)
		{
			pPlayer->relife_flag = false;
			pPlayer->relife_time = 0.0f;
			pPlayer->select_player_flag = false;
			pPlayer->SetViewMode(Character::kFirstPerson);
			game_state = kAlive;
			pPlayer->SetCrouch(false);
			SpawnConfirm();
			tempc_ptr(SniperGun) gun = ptr_dynamic_cast<SniperGun>(pPlayer->GetWeapon());
			if (gun)
				gun->SetSight(0);
		}

		c->ready = true;
		c->connected = true;
		c->invincible_time = invincible_time;
		c->weapon_id = -1;

		c->playing = true;
		c->grenade_cd_time = -1.f;

		c->max_hp = max_hp;
		c->ex_hp = ex_hp;

		c->rand_fun.Srand(s_rand);

		c->is_boss = true;
		c->ClearLockState();
		c->LockStateByType(kLSCrouch);
		
		c->SetTeam(team);

		c->SetCareer(career, character_info);
		c->SetPhysxGroup(team + PhysxSystem::kGroupStart);

		c->Rebirth(hp, armor, position, Quaternion(Vector3(0, 1, 0), DEG2RAD * angle));
		if (c == gLevel->GetPlayer())
		{
			tempc_ptr(StateMainGame) state_main = ptr_dynamic_cast<StateMainGame>(gGame->machine.CurrentState());
			if(state_main)
				state_main->EventCloseCharacter.Fire(ptr_static_cast<StateMainGame>(state_main), EventArgs());
			gLevel->targetenemy_time = 0.f;
			gLevel->tmpplayer = NullPtr;
		}

		c->UpdateRawCharacterChangeableInfo();

		for (int i = 0; i < 7; ++i)
		{
			tempc_ptr(WeaponBase) weapon = c->GetWeaponById(i);
			if (weapon && weapon->CanActive())
			{
				c->SelectWeapon(i, true);
				break;
			}
		}

		//for (int i = 0; i < 7; i++)
		//{
		//	tempc_ptr(WeaponBase) weapon = c->GetWeaponById(i);
		//	if (weapon && weapon->CanActive())
		//	{
		//		weapon->is_weapon_updated = false;
		//	}
		//}
		c->zombie_dying_flag = false;

		c->boss2_move_energy = 1000;
		c->boss2_move_energy_max = 1000;
		c->boss2_move_energy_recovery = 150;
		c->boss2_fly_energy_down = 80;
	}
}

void ChannelConnection::ParseBoss2Showtime(Core::BinaryNetworkReader & reader)
{
	byte uid;
	FMOD_VECTOR vel = {0, 0, 0};

	reader.ReadByte(uid);

	const Core::Array<sharedc_ptr(Character)> &characters = gLevel->GetCharacters();
	for (U32 i = 0; i < characters.Size(); i++)
	{
		tempc_ptr(Character) c = characters[i];

		if (c)
		{
			if (c->GetTeam() == 0)
			{
				c->boss2_self_kill = true;
				c->boss2_self_kill_timer = 0.1f;
			}
			else if (c->GetTeam() == 1)
			{
				gLevel->AddParticle("boss02_gameover_ex",c->GetPosition(),Core::Vector3(0,1,0));
				FmodSystem::Play3DEvent("bj/player/3d/armor_robot/armor_eow_fire",(const FMOD_VECTOR &)c->GetPosition(),vel);
			}
		}
	}

	tempc_ptr(Character) player = gLevel->GetPlayer();
	if (player)
	{
		if (player->GetTeam() == 0)
		{
			player->boss2_self_kill = true;
			player->boss2_self_kill_timer = 0.1f;
		}
		else if (player->GetTeam() == 1)
		{
			gLevel->AddParticle("boss02_gameover_ex",player->GetPosition(),Core::Vector3(0,1,0));
			FmodSystem::Play3DEvent("bj/player/3d/armor_robot/armor_eow_fire",(const FMOD_VECTOR &)player->GetPosition(),vel);
		}
	}
}

void ChannelConnection::ParseBoss2SyncData(Core::BinaryNetworkReader & reader)
{
	byte uid;

	reader.ReadByte(uid);
	int boss2_passiveskill_level_old[4] = {-1,-1,-1,-1};
	int boss2_human_energy_level_old = -1;
	int boss2_strange_spawn_old = -1;
	int boss2_defence_energy_level_old = -1;

	tempc_ptr(Character) c = gLevel->GetCharacter(uid);
	tempc_ptr(Character) player = gLevel->GetPlayer();
	if (c)
	{
		if (player && player == c)
		{
			for (int i = 0 ; i < 4 ; i++)
			{
				boss2_passiveskill_level_old[i] = c->boss2_passiveskill_level[i];
			}
			boss2_human_energy_level_old = c->boss2_human_energy_level;
			boss2_strange_spawn_old = c->boss2_strange_spawn;
		}
		boss2_defence_energy_level_old = c->boss2_defence_energy_level;
		reader.ReadFloat(c->boss2_human_energy);
		reader.ReadFloat(c->boss2_human_energy_max);
		reader.ReadInt(c->boss2_human_energy_level);
		reader.ReadIntArray(c->boss2_passiveskill_level, 4);
		reader.ReadInt(c->boss2_initiative_type);
		reader.ReadInt(c->boss2_strange_spawn);
		reader.ReadFloat(c->boss2_defence_energy);
		reader.ReadFloat(c->boss2_defence_energy_max);
		reader.ReadInt(c->boss2_defence_energy_level);
		
		//skill level up cartoon
		tempc_ptr(StateMainGame) state_main = ptr_dynamic_cast<StateMainGame>(gGame->machine.CurrentState());
		if (player && state_main)
		{
			if (player == c)
			{
				int level_up = -1;
				Core::String _str_skill[4] = {gLang->GetTextW(L"�ƶ��ٶ�"),gLang->GetTextW(L"��Ծ�߶�"),gLang->GetTextW(L"����ǿ��"),gLang->GetTextW(L"��������")};
				Core::String _str_initiative_skill[4] = {gLang->GetTextW(L"�޵�"),gLang->GetTextW(L"�ظ�"),gLang->GetTextW(L"��ŭ"),gLang->GetTextW(L"����")};
				Core::String _str_strange_skill[4] = {gLang->GetTextW(L"���ͻ����"),gLang->GetTextW(L"��������"),gLang->GetTextW(L"�ڻ�װ������"),gLang->GetTextW(L"��ǹװ������")};
				for (int i = 0 ; i < 4 ; i++)
				{
					if (c->boss2_passiveskill_level[i] > boss2_passiveskill_level_old[i])
					{
						state_main->ui->m_boss_mode2_human_skill_level_up_time[i] = 0.5f;
						level_up = i;
					}
				}
				if (boss2_human_energy_level_old > 0 && c->boss2_human_energy_level > boss2_human_energy_level_old)
				{
					state_main->ui->m_boss_mode2_shine_time = 1.0f;
					state_main->ui->m_boss_mode2_shine_time_space = 0.5f;
					if (level_up >= 0 && c->boss2_initiative_type > 0)
					{
						state_main->ui->m_Bottom_str[1] = Core::String::Format(gLang->GetTextW(L"���ս���ȼ�������Lv%d�����%s��������������%s��������"),c->boss2_human_energy_level,_str_skill[level_up].Str(),_str_initiative_skill[c->boss2_initiative_type - 1].Str());
						state_main->ui->m_ShowBottom_str_time[1] = 3.0f;
					}
					FmodSystem::PlayEvent("bj/ui/human_levelup");
				}
				if (c->boss2_strange_spawn != boss2_strange_spawn_old && c->boss2_strange_spawn >= 0 && c->boss2_strange_spawn < 4)
				{
					state_main->ui->m_Bottom_str[1] = Core::String::Format(gLang->GetTextW(L"���������⼼��%s,��G��ʹ��"),_str_strange_skill[c->boss2_strange_spawn]);
					state_main->ui->m_ShowBottom_str_time[1] = 3.0f;
				}
				if (boss2_defence_energy_level_old != c->boss2_defence_energy_level)
				{
					FmodSystem::PlayEvent("bj/ui/human_d_levelup");
				}
			} 
			else if (player->GetTeam() == 0)
			{
				if (boss2_defence_energy_level_old != c->boss2_defence_energy_level)
				{
					state_main->ui->m_Bottom_str[0] = Core::String::Format(gLang->GetTextW(L"BOSS��Ӫ�Ŀ��Եȼ�������%d"),c->boss2_defence_energy_level);
					state_main->ui->m_ShowBottom_str_time[0] = 3.0f;
				}
			}
				
		}

		//LogSystem.WriteLinef("------------------------------------------------------------------------------");
		//LogSystem.WriteLinef("c->GetName() : %s", c->GetName());
		//LogSystem.WriteLinef("c->boss2_human_energy : %f", c->boss2_human_energy);
		//LogSystem.WriteLinef("c->boss2_human_energy_max : %f", c->boss2_human_energy_max);
		//LogSystem.WriteLinef("c->boss2_human_energy_level : %d", c->boss2_human_energy_level);
		//LogSystem.WriteLinef("c->boss2_passiveskill_level[0] : %d", c->boss2_passiveskill_level[0]);
		//LogSystem.WriteLinef("c->boss2_passiveskill_level[1] : %d", c->boss2_passiveskill_level[1]);
		//LogSystem.WriteLinef("c->boss2_passiveskill_level[2] : %d", c->boss2_passiveskill_level[2]);
		//LogSystem.WriteLinef("c->boss2_passiveskill_level[3] : %d", c->boss2_passiveskill_level[3]);
		//LogSystem.WriteLinef("c->boss2_initiative_type : %d", c->boss2_initiative_type);
		//LogSystem.WriteLinef("c->boss2_strange_spawn : %d", c->boss2_strange_spawn);
		//LogSystem.WriteLinef("c->boss2_defence_energy : %f", c->boss2_defence_energy);
		//LogSystem.WriteLinef("c->boss2_defence_energy_max : %f", c->boss2_defence_energy_max);
		//LogSystem.WriteLinef("c->boss2_defence_energy_level : %d", c->boss2_defence_energy_level);
	}
}




void ChannelConnection::ParseUseItem_ItemMode(Core::BinaryNetworkReader & reader)
{
	byte uid;
	int itemmode_item_slot = -1;
	int uid_sizes = 0;
	Core::Array<byte> uids;

	reader.ReadByte(uid);
	reader.ReadInt(itemmode_item_slot);
	reader.ReadInt(uid_sizes);
	for (int i = 0; i < uid_sizes; i++)
	{
		byte t;

		reader.ReadByte(t);

		uids.PushBack(t);
	}

	//-1:��, 0:�����������󣩣�1:����������С����2:�����ƶ��ٶȣ�3:�޵У�4:�Ա���5:������6:��Χ�ڶԷ�����
	//7:��Χ�ڶԷ����ң���꣩��8:��Χ�ڶԷ����ң����̣���9:��Χ�ڶԷ������ⵯ��10:������Ծ�߶ȣ�11:��Χ�ڶԷ��޷����
	//12:��Χ�ڶԷ��޷���Ծ��13:�������һ��Ч����14:������Ϊ�ڰ�����
	//15:���Լ���ȫ����٣�16:���Լ���ȫ����ң���꣩��17:���Լ���ȫ���޷���Ծ��18:���Լ���ȫ���޷�����

	tempc_ptr(Character) viewer = gLevel->GetViewer();
	tempc_ptr(Character) c = gLevel->GetCharacter(uid);
	tempc_ptr(Character) play = gLevel->GetPlayer();
	Core::String  common_skill_Particle[26] = {"prop_hemo","prop_hemo","prop_gatherway02","","prop_explode","cell03_disappear","buff_slowdown","prop_babelism","prop_babelism","","prop_jump","prop_seal","prop_seal","","prop_change","buff_slowdown","prop_babelism","prop_seal","prop_seal","","","","","","","buff_maxcrit"};

	if (itemmode_item_slot == 5)
	{
		play->invisible_uid = uid;
	}

	if (itemmode_item_slot == 4)
	{
		play->zibao_uid = uid;
		if (c != play)
		{
			c->itemmode_zibao = true;
			c->itemmode_zibao_timer = 3.f;
		}
	}

	tempc_ptr(StateMainGame) state_main = ptr_dynamic_cast<StateMainGame>(gGame->machine.CurrentState());
	if(itemmode_item_slot == 14)
	{
		Core::String str = Core::String::Format("%s %s" ,c->GetName(), gLang->GetTextW(L"������Ϊɱ¾���ģ�"));
		if(play == c)
		{
			play->is_item_boss = true;
			state_main->ui->m_Showmiddle_str_time = 4.0f;
			state_main->ui->m_Middle_str = gLang->GetTextW(L"������һ�����ص�����������Ϊɱ¾���ģ�\nɱ¾������2��ǿ������������2��[�ո�]����2��������[����Ҽ�]����˲��");
		}
		str = Core::String::Format("%s %s",c->GetName(), gLang->GetTextW(L"������Ϊɱ¾���ģ�"));
		if (play != c)
		{
			state_main->ui->m_Showmiddle_str_time = 4.0f;
			state_main->ui->m_Middle_str = str;
		}
		gLevel->AddHorn(str);
	}
	if(c->GetTeam() != play->GetTeam())
	{
		if (itemmode_item_slot == 7 || itemmode_item_slot == 8 || itemmode_item_slot == 6 || itemmode_item_slot == 11 || itemmode_item_slot == 12)
		{
			for (int i = 0 ; i<uid_sizes ; i++)
			{
				tempc_ptr(Character) temp = gLevel->GetCharacter(uids[i]);
				if (play == temp && !play->is_item_boss)
				{
					state_main->ui->OnAddItemModeItem(itemmode_item_slot,false,true);
				}
			}
		}
	}

	if(c != play && !play->is_item_boss)
	{
		if (itemmode_item_slot == 15 || itemmode_item_slot == 16 || itemmode_item_slot ==  17 || itemmode_item_slot ==  18)
		{
			state_main->ui->OnAddItemModeItem(itemmode_item_slot,false,false);
		}
	}

	if (c == play && state_main && state_main->ui && !play->is_item_boss)
	{
		play->item_box_time = 1.f;
		state_main->ui->OnAddItemModeItem(itemmode_item_slot,true,true);
		FmodSystem::PlayEvent("bj/event/use_item");
		
	}


	if (itemmode_item_slot != -1 && itemmode_item_slot != 4)
	{
		String file_name = String::Format("UI_Item_Skill/ig_itemmode_skill_ico_%d.mesh",itemmode_item_slot);
		LogSystem.WriteLinef("%s", file_name.Str());
		c->GetThirdPerson().item_mode_head = ptr_new StaticMesh(MESH_KEY_PROP);
		c->GetThirdPerson().item_mode_head->AddPrimitive(file_name,0);
		c->ShowItemModeHead(3.f);
	}

	if(c == play)
	{
		LogSystem.WriteLinef("itemmode_item_slot:%d",itemmode_item_slot);
		if(itemmode_item_slot == 2 || itemmode_item_slot == 5 || itemmode_item_slot == 10)
		{
			c->PlayItemModeBuffTime(itemmode_item_slot,10.f);
		}
		else if(itemmode_item_slot == 3)
		{
			c->PlayItemModeBuffTime(itemmode_item_slot,5.f);
		}
		else if(itemmode_item_slot == 25)
		{
			c->PlayItemModeBuffTime(itemmode_item_slot,6.f);
		}
	}

	if (itemmode_item_slot == -1 || common_skill_Particle[itemmode_item_slot] == "")
	{
		return;
	}

	if (itemmode_item_slot == 0 || itemmode_item_slot == 1 || itemmode_item_slot == 2 || itemmode_item_slot == 3 || itemmode_item_slot == 5 || itemmode_item_slot == 10 || itemmode_item_slot == 14)
	{
		c->PlayItemModeParticle(common_skill_Particle[itemmode_item_slot],10.f);
	}
	else if (itemmode_item_slot == 25)
	{
		c->benefitshadertime = 6.0f;
	}
	else if (itemmode_item_slot == 7 || itemmode_item_slot == 8 || itemmode_item_slot == 12)
	{
		const Core::Array<sharedc_ptr(Character)>& characters = gLevel->GetCharacters();
		for (uint i = 0; i < characters.Size() ; i++)
		{
			tempc_ptr(Character) c1 = characters[i];
			for (int j = 0 ; j<uid_sizes ; j++)
			{
				tempc_ptr(Character) temp = gLevel->GetCharacter(uids[j]);
				if(c1 && c->GetTeam() != c1->GetTeam() && c1 == temp && !c1->is_item_boss)
				{
					c1->PlayItemModeParticle(common_skill_Particle[itemmode_item_slot], 10.f);
				}
			}
		}
		for (int i = 0 ; i<uid_sizes ; i++)
		{
			tempc_ptr(Character) temp = gLevel->GetCharacter(uids[i]);
			if (c->GetTeam() != play->GetTeam() && play == temp && !play->is_item_boss)
			{
				play->PlayItemModeParticle(common_skill_Particle[itemmode_item_slot], 10.f);
				play->PlayItemModeDebuffTime(itemmode_item_slot,10.f);
			}
		}
	}
	else if ( itemmode_item_slot == 11)
	{
		const Core::Array<sharedc_ptr(Character)>& characters = gLevel->GetCharacters();
		for (uint i = 0; i < characters.Size() ; i++)
		{
			tempc_ptr(Character) c1 = characters[i];
			for (int j = 0 ; j<uid_sizes ; j++)
			{
				tempc_ptr(Character) temp = gLevel->GetCharacter(uids[j]);
				if(c1 && c->GetTeam() != c1->GetTeam() && c1 == temp && !c1->is_item_boss)
				{
					c1->PlayItemModeParticle(common_skill_Particle[itemmode_item_slot], 5.f);
				}
			}
		}
		for (int i = 0 ; i<uid_sizes ; i++)
		{
			tempc_ptr(Character) temp = gLevel->GetCharacter(uids[i]);
			if (c->GetTeam() != play->GetTeam() && play == temp && !play->is_item_boss)
			{
				play->PlayItemModeParticle(common_skill_Particle[itemmode_item_slot], 5.f);
				play->PlayItemModeDebuffTime(itemmode_item_slot,5.f);
			}
		}
	}
	else if (itemmode_item_slot == 6)
	{
		const Core::Array<sharedc_ptr(Character)>& characters = gLevel->GetCharacters();
		for (uint i = 0; i < characters.Size() ; i++)
		{
			tempc_ptr(Character) c1 = characters[i];
			for (int j = 0 ; j<uid_sizes ; j++)
			{
				tempc_ptr(Character) temp = gLevel->GetCharacter(uids[j]);
				if(c1 && c->GetTeam() != c1->GetTeam() && c1 == temp && !c1->is_item_boss)
				{
					c1->GetThirdPerson().PlayEffectBuffer(kWeaponAttr_Target_SlowDown,10.f);
				}
			}
		}
		for (int i = 0 ; i<uid_sizes ; i++)
		{
			tempc_ptr(Character) temp = gLevel->GetCharacter(uids[i]);
			if (c->GetTeam() != play->GetTeam() && play == temp && !play->is_item_boss)
			{
				play->GetThirdPerson().PlayEffectBuffer(kWeaponAttr_Target_SlowDown,10.f);
				play->PlayItemModeDebuffTime(itemmode_item_slot,10.f);
			}
		}
		/*const Core::Array<sharedc_ptr(Character)>& characters = gLevel->GetCharacters();
		for (uint i = 0; i < characters.Size(); i++)
		{
			tempc_ptr(Character) c1 = characters[i];
			if(c1 && c->GetTeam() != c1->GetTeam())
			{
				c1->GetThirdPerson().PlayEffectBuffer(kWeaponAttr_Target_SlowDown,10.f);
			}
		}
		if(c->GetTeam() != play->GetTeam())
		{
			play->GetThirdPerson().PlayEffectBuffer(kWeaponAttr_Target_SlowDown,10.f);
		}*/
	}
	else if(itemmode_item_slot == 15)
	{
		const Core::Array<sharedc_ptr(Character)>& characters = gLevel->GetCharacters();
		for (uint i = 0; i < characters.Size(); i++)
		{
			tempc_ptr(Character) c1 = characters[i];
			if(c1 && c != c1 && !c1->is_item_boss)
			{
				c1->GetThirdPerson().PlayEffectBuffer(kWeaponAttr_Target_SlowDown,10.f);
			}
		}
		if(c != play && !play->is_item_boss)
		{
			play->GetThirdPerson().PlayEffectBuffer(kWeaponAttr_Target_SlowDown,10.f);
			play->PlayItemModeDebuffTime(itemmode_item_slot,10.f);
		}

	}
	else if(itemmode_item_slot == 16 || itemmode_item_slot == 17)
	{
		const Core::Array<sharedc_ptr(Character)>& characters = gLevel->GetCharacters();
		for (uint i = 0; i < characters.Size(); i++)
		{
			tempc_ptr(Character) c1 = characters[i];
			if(c1 && c != c1 && !c1->is_item_boss)
			{
				c1->PlayItemModeParticle(common_skill_Particle[itemmode_item_slot], 10.f);
			}
		}
		if(c != play && !play->is_item_boss)
		{
			play->PlayItemModeParticle(common_skill_Particle[itemmode_item_slot], 10.f);
			play->PlayItemModeDebuffTime(itemmode_item_slot,10.f);
		}
	}
	else if (itemmode_item_slot == 18)
	{
		const Core::Array<sharedc_ptr(Character)>& characters = gLevel->GetCharacters();
		for (uint i = 0; i < characters.Size(); i++)
		{
			tempc_ptr(Character) c1 = characters[i];
			if(c1 && c != c1 && !c1->is_item_boss)
			{
				c1->PlayItemModeParticle(common_skill_Particle[itemmode_item_slot], 5.f);
			}
		}
		if(c != play && !play->is_item_boss)
		{
			play->PlayItemModeParticle(common_skill_Particle[itemmode_item_slot], 5.f);
			play->PlayItemModeDebuffTime(itemmode_item_slot,5.f);
		}
	}
}
	

void ChannelConnection::ParseItemMode_ZiBao(Core::BinaryNetworkReader & reader)
{
	byte uid;
	reader.ReadByte(uid);
	//tempc_ptr(StateMainGame) state_main = ptr_dynamic_cast<StateMainGame>(gGame->machine.CurrentState());
	//if (state_main && state_main->ui)
	//{
	//	state_main->ui->DrawItemModeZiBao(uid);
	//}
	tempc_ptr(Character) c = gLevel->GetCharacter(uid);
	if (c)
	{
		c->PlayItemModeParticle("prop_explode",10.f);
		FMOD_VECTOR vel = {0, 0, 0};
		if (c == gLevel->GetPlayer())
			FmodSystem::PlayEvent("bj/fx/2d/self_explode");
		else
			FmodSystem::Play3DEvent("bj/fx/3d/self_explode",(const FMOD_VECTOR &)c->GetPosition(),vel);
	}

}

void ChannelConnection::ParseItemModeSyncData(Core::BinaryNetworkReader & reader)
{
	byte uid;

	reader.ReadByte(uid);

	tempc_ptr(Character) c = gLevel->GetCharacter(uid);

	if (c)
	{
		reader.ReadFloat(c->itemmode_energy);
		reader.ReadFloat(c->itemmode_energy_max);
		reader.ReadInt(c->itemmode_item_slot);

		//LogSystem.WriteLinef("------------------------------------------------------------------------------");
		//LogSystem.WriteLinef("c->GetName() : %s", c->GetName());
		//LogSystem.WriteLinef("c->itemmode_energy : %f", c->itemmode_energy);
		//LogSystem.WriteLinef("c->itemmode_energy_max : %f", c->itemmode_energy_max);
		//LogSystem.WriteLinef("c->itemmode_item_slot : %d", c->itemmode_item_slot);
	}
}

void ChannelConnection::ParseTDMode_ResHpChange(Core::BinaryNetworkReader & reader)
{
	int cur_reshp;
	int max_reshp;

	reader.ReadInt(cur_reshp);
	reader.ReadInt(max_reshp);

	tempc_ptr(StateMainGame) state_main = ptr_dynamic_cast<StateMainGame>(gGame->machine.CurrentState());
	if (state_main && state_main->ui)
	{
		state_main->ui->m_cur_reshp = cur_reshp;
		state_main->ui->m_max_reshp = max_reshp;
		if (state_main->ui->m_ResTime <=0)
			state_main->ui->m_ResTime = ScaleTime;
	}

	LogSystem.WriteLinef("ResHpChange : %d %d", cur_reshp, max_reshp);
}

void ChannelConnection::ParseSM_MoonMode_PickWin(Core::BinaryNetworkReader & reader)
{
	Core::String name;
	reader.ReadString(name);
	gLevel->moon_mode_win_list.PushBack(name);
}
void ChannelConnection::ParseSM_UseItem_SurvivalMode(Core::BinaryNetworkReader & reader)
{
 	byte uid;
 	int index;
 	byte type;
 	reader.ReadByte(uid);
 	reader.ReadInt(index);
 	reader.ReadByte(type);

 	tempc_ptr(Character) c = gLevel->GetCharacter(uid);
 	tempc_ptr(Character) playre = gLevel->GetPlayer();
    tempc_ptr(StateMainGame) state_main = ptr_dynamic_cast<StateMainGame>(gGame->machine.CurrentState());
	Core::LinkNode<SurvivalModeItemInfo>* node = c->basecharacter_info->survivalbag.Front();
	int count = 1;
	while(node)
	{
		if (count == index)
		{
			break;
		}
		count++;
		node = node->GetNext();
	}
     
	//value
	if( c == playre )
	{
		if ( playre->basecharacter_info->GetItemInfoType(index) == PickUpManager::kSupplySurvivalItemHp )
		{
     		if ( node->data.value == 50.0f )
			{
				
				state_main->ui->m_Showmiddle_str_time = 3.0f;
				state_main->ui->m_Middle_str = gLang->GetTextW(L"����50%����");
				FmodSystem::PlayEvent("bj/fx/2d/survival_bottle_drink");
				
			}	
			else if ( node->data.value == 80.0f ) 
			{
				
				state_main->ui->m_Showmiddle_str_time = 3.0f;
				playre->item_box_time = 2.f;
				state_main->ui->m_Middle_str = gLang->GetTextW(L"����80%����");
				FmodSystem::PlayEvent("bj/fx/2d/survival_bottle_drink");
				
			}
		}
		else if( playre->basecharacter_info->GetItemInfoType(index) == PickUpManager::kSupplySurvivalItemAmmo )
		{
			if ( node->data.value == 30.0f )
			{
				state_main->ui->m_Showmiddle_str_time = 3.0f;
				state_main->ui->m_Middle_str = gLang->GetTextW(L"����30%�ӵ�");
			}	
			else if ( node->data.value  == 100.0f )
			{
				state_main->ui->m_Showmiddle_str_time = 3.0f;
				state_main->ui->m_Middle_str = gLang->GetTextW(L"����100%�ӵ�");
			}
		}
		else if( playre->basecharacter_info->GetItemInfoType(index) == PickUpManager::kSupplySurvivalItemTrapAmmo )
		{
			state_main->ui->m_Showmiddle_str_time = 3.0f;
			state_main->ui->m_Middle_str = gLang->GetTextW(L"ʹ���ӵ�͵�����壬3��������Ч");
			FmodSystem::PlayEvent("bj/fx/2d/survival_set_trap");
		}
		else if( playre->basecharacter_info->GetItemInfoType(index) == PickUpManager::kSupplySurvivalItemTrapHP )
		{
			state_main->ui->m_Showmiddle_str_time = 3.0f;
			state_main->ui->m_Middle_str = gLang->GetTextW(L"ʹ�ò���͵�����壬3��������Ч");
			FmodSystem::PlayEvent("bj/fx/2d/survival_set_trap");
		}
		else if( playre->basecharacter_info->GetItemInfoType(index) == PickUpManager::kSupplySurvivalItemTrapExpose )
		{
			state_main->ui->m_Showmiddle_str_time = 3.0f;
			state_main->ui->m_Middle_str = gLang->GetTextW(L"ʹ�þ������壬3��������Ч");
			FmodSystem::PlayEvent("bj/fx/2d/survival_set_trap");
		}
		else if( playre->basecharacter_info->GetItemInfoType(index) == PickUpManager::kSupplySurvivalItemTrapBomb )
		{
			state_main->ui->m_Showmiddle_str_time = 3.0f;
			state_main->ui->m_Middle_str = gLang->GetTextW(L"ʹ�ò����˺����壬3��������Ч");
			FmodSystem::PlayEvent("bj/fx/2d/survival_set_trap");
		}
		else if( playre->basecharacter_info->GetItemInfoType(index) == PickUpManager::kSupplySurvivalItemTrapDebuff )
		{
			state_main->ui->m_Showmiddle_str_time = 3.0f;
			state_main->ui->m_Middle_str = gLang->GetTextW(L"ʹ���˺����壬3��������Ч");
			FmodSystem::PlayEvent("bj/fx/2d/survival_set_trap");
		}
		else if ( playre->basecharacter_info->GetItemInfoType(index) == PickUpManager::kSupplySurvivalIteminitiative )
		{
			playre->spawntimebySurvival1 = 4.0f;
			state_main->ui->m_Showmiddle_str_time = 4.0f;
			state_main->ui->m_Middle_str = gLang->GetTextW(L"����޵�");
			FmodSystem::PlayEvent("bj/fx/2d/invincible");
		}
		c->basecharacter_info->DeleteItemInfo(index); 
	}
}


void ChannelConnection::ParseSM_UseItem_Trap(Core::BinaryNetworkReader & reader)
{
	TrapInfo t;
	int ghost_fire_count;

	reader.ReadVector3(t.position);
	reader.ReadByte(t.type);
	reader.ReadByte(t.uid);
	reader.ReadByte(t.team);
	reader.ReadInt(ghost_fire_count);

	t.time = 180.f;

	tempc_ptr(Character) c = gLevel->GetPlayer();

	if (c->isghost && c->uid == t.uid)
	{
		c->ghostfirecount -= ghost_fire_count;
	}
	
	sharedc_ptr(ParticleSystem) ps = ptr_new ParticleSystem("mines_scope");
	t.position.y += 0.05f;
	ps->SetPosition(t.position);
	if (t.team == c->GetTeam())
	{
		gLevel->AddParticle(ps);
	}
	t.ps = ps;
	gLevel->trap_info.Add(t);
}
void ChannelConnection::ParseSM_UseItem_Trap_Trigger(Core::BinaryNetworkReader & reader)
{
	byte uid;
	int index;
	reader.ReadByte(uid);
	reader.ReadInt(index);
	Core::String psname = Core::String::Format("boo_0%d" ,gLevel->trap_info[index - 1].type - PickUpManager::kSupplySurvivalItemStart);
	if (gLevel->trap_info[index - 1].type - PickUpManager::kSupplySurvivalItemStart > 5)
	{
		psname = Core::String::Format("boo_05");
	}
	sharedc_ptr(ParticleSystem) ps = ptr_new ParticleSystem(psname);
	ps->SetPosition(gLevel->trap_info[index - 1].ps->m_Position);
	tempc_ptr(Character) c1 = gLevel->GetCharacter(gLevel->trap_info[index-1].uid);
	gLevel->AddParticle(ps);
	gLevel->trap_info[index - 1].ps->SetDead();
	gLevel->RemoveParticle(gLevel->trap_info[index - 1].ps);
	gLevel->trap_info[index - 1].ps = NullPtr;
	tempc_ptr(Character) c = gLevel->GetCharacter(uid);
	tempc_ptr(Character) playre = gLevel->GetPlayer();
	Core::String str;
	tempc_ptr(StateMainGame) state_main = ptr_dynamic_cast<StateMainGame>(gGame->machine.CurrentState());
	if ( c1 == playre )
	{
		switch( gLevel->trap_info[index - 1].type )
		{
		case PickUpManager::kSupplySurvivalItemTrapAmmo:
			{
				c1->Survivalprompting1 = 10;
				state_main->ui->m_Showmiddleup_str_time = 10.0f;
				state_main->ui->m_Middleup_str = Core::String::Format(gLang->GetTextW(L"%s�������������,�ӵ�������!"),c->GetName());
			}
			break;
		case PickUpManager::kSupplySurvivalItemTrapHP:
			{
				c1->Survivalprompting1 = 10;
				state_main->ui->m_Showmiddleup_str_time = 10.0f;
				state_main->ui->m_Middleup_str = Core::String::Format(gLang->GetTextW(L"%s�������������,��������������!"),c->GetName());
			}
			break;
		case PickUpManager::kSupplySurvivalItemTrapExpose:
			{
				c1->Survivalprompting1 = 10;
				state_main->ui->m_Showmiddleup_str_time = 10.0f;
				state_main->ui->m_Middleup_str = Core::String::Format(gLang->GetTextW(L"%s�������������,���ٱ�¶��!"),c->GetName());
			}
			break;
		case PickUpManager::kSupplySurvivalItemTrapBomb:
			{
				c1->Survivalprompting1 = 10;
				state_main->ui->m_Showmiddleup_str_time = 10.0f;
				state_main->ui->m_Middleup_str = Core::String::Format(gLang->GetTextW(L"%s�������������,�������ص���!"),c->GetName());

			}
			break;
		case PickUpManager::kSupplySurvivalItemTrapDebuff:
			{
				c1->Survivalprompting1 = 10;
				state_main->ui->m_Showmiddleup_str_time = 10.0f;
				state_main->ui->m_Middleup_str = Core::String::Format(gLang->GetTextW(L"%s�������������,ʧѪ�ӿ���!"),c->GetName());
			}
			break;
		}
	}
	if(c1)
	{
		if ( c == playre ) 
		{
			switch( gLevel->trap_info[index - 1].type )
			{
			case PickUpManager::kSupplySurvivalItemTrapAmmo:
				{
					c->Survivalprompting = 10;
					state_main->ui->m_Showmiddleup_str_time = 10.0f;
					state_main->ui->m_Middleup_str = Core::String::Format(gLang->GetTextW(L"����ӵ���%s��û��,�浹ù!"),c1->GetName());
					FmodSystem::PlayEvent("bj/fx/2d/survival_stealing_trap");
				}
				break;
			case PickUpManager::kSupplySurvivalItemTrapHP:
				{
					c->Survivalprompting = 10;
					state_main->ui->m_Showmiddleup_str_time = 10.0f;
					state_main->ui->m_Middleup_str = Core::String::Format(gLang->GetTextW(L"�������������%s��û��,С������!"),c1->GetName());
					FmodSystem::PlayEvent("bj/fx/2d/survival_stealing_trap");
				}
				break;
			case PickUpManager::kSupplySurvivalItemTrapExpose:
				{
					c->Survivalprompting = 10;
					state_main->ui->m_Showmiddleup_str_time = 10.0f;
					state_main->ui->m_Middleup_str = Core::String::Format(gLang->GetTextW(L"��Ϊ%s�������㱩¶������,�Ͻ���������ܰ�!"),c1->GetName());
					playre->SurvivalExpose=60.f;
					FmodSystem::PlayEvent("bj/fx/2d/survival_warning_trap");
				}
				break;
			case PickUpManager::kSupplySurvivalItemTrapBomb:
				{
					c->Survivalprompting = 10;
					state_main->ui->m_Showmiddleup_str_time = 10.0f;
					state_main->ui->m_Middleup_str = Core::String::Format(gLang->GetTextW(L"%s�������˺�����,�Ͻ�ȥ����!"),c1->GetName());
					FmodSystem::PlayEvent("bj/fx/2d/survival_cheating_trap");
				}
				break;
			case PickUpManager::kSupplySurvivalItemTrapDebuff:
				{
					c->Survivalprompting = 10;
					state_main->ui->m_Showmiddleup_str_time = 10.0f;
					state_main->ui->m_Middleup_str = Core::String::Format(gLang->GetTextW(L"��ȵ���%s�ŵ�����,Ѫ��û�е����ر��?"),c1->GetName());
					playre->spawntimebySurvival2 = 10.f;
					gLevel->audio_Survival1_background->start();
				}
				break;
			}
		}
	}
	gLevel->trap_info.RemoveAt(index - 1);
}
void ChannelConnection::ParseDieBuffData(Core::BinaryNetworkReader & reader)
{
	gLevel->die_buff_data.Clear();
	uint iCnt =0;
	reader.ReadInt(iCnt);
	uint rate_all = 0;
	for(uint i=0; i<iCnt; ++i)
	{
		DieBuffData data;
		reader.ReadFloat(data.duration_timer);
		reader.ReadFloat(data.interval);
		reader.ReadInt(data.type);
		reader.ReadFloat(data.value);
		reader.ReadString(data.res_key);
		reader.ReadString(data.res_desc);
		reader.ReadInt(data.rate);
		rate_all += data.rate;

		gGame->global->Translate(data.res_desc);
		gLevel->die_buff_data.PushBack(data);
	}

	int tmp = 0;
	for(uint i=0; i<iCnt; ++i)
	{
		gLevel->die_buff_data[i].rate = tmp+gLevel->die_buff_data[i].rate*100/rate_all;
		tmp = gLevel->die_buff_data[i].rate;
	}
	tempc_ptr(StateMainGame) state_main = ptr_dynamic_cast<StateMainGame>(gGame->machine.CurrentState());
	if (state_main && state_main->ui)
	{
		state_main->ui->InitDieBuffInfo();
	}
}

void Client::ChannelConnection::CreateRoomTest()
{
	
}

void Client::ChannelConnection::RequestRoomEnterWithSlotId( int dwRoomId, uint dwSlotId /*= 0*/ )
{
	// todo �ڷ�����Ҳ����
	//if (state == kInChannel)
	LogSystem.WriteLinef("%s, %s room_id : %d, slot_id : %d", __FILE__, __FUNCTION__, dwRoomId, dwSlotId);

	{
		BeginWrite();
		WriteByte(CM_RequestRoomEnterWithSlotId);
		WriteInt(dwRoomId);
		WriteInt(dwSlotId);
		EndWrite();
	}
}

