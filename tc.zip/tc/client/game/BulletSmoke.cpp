#include "pch.h"

using namespace Core;
using namespace Client;



namespace Client
{

	static const float SMOKE_EXIST_TIME = 0.8f;
	

	BulletSmokeObject::BulletSmokeObject():smoke_show_timer(-1.f)
										 
	{
		smoke_object_mesh = ptr_new StaticMesh(MESH_KEY_PROP);
		smoke_object_mesh->AddPrimitive("bullet_smoke/bullet_smoke.mesh",0);
	}

	BulletSmokeObject::~BulletSmokeObject()
	{
		smoke_object_mesh = NullPtr;
	}



	/// constructor
	BulletSmoke::BulletSmoke(): alive_count(MAX_SMOKE_COUNT)
	{
		for (uint i = 0; i < MAX_SMOKE_COUNT; i++)
		{
			bullet_smoke_obj[i] = NullPtr;
		}
	}

	/// destructor
	BulletSmoke::~BulletSmoke()
	{
		for (uint i = 0; i < MAX_SMOKE_COUNT; i++)
		{
			bullet_smoke_obj[i] = NullPtr;
		}
	}

	/// initialize
	void BulletSmoke::Initialize()
	{
		CreateMesh();
	}

	bool BulletSmoke::AddBulletSmoke(const Vector3 & from, const Quaternion & dir, int count)
	{
		if(alive_count < count)
			return false;

		int pos = 0;

		for (uint i = 0; i < MAX_SMOKE_COUNT; i++)
		{
			tempc_ptr(BulletSmokeObject) pTemp = bullet_smoke_obj[i];
			if(pTemp->smoke_show_timer < 0.f)
			{
				pTemp->smoke_show_timer = SMOKE_EXIST_TIME;
				Vector3 v = dir.GetZXY();
				v.z = 0;
				Quaternion q;
				q.SetZXY(v);
				pTemp->smoke_object_mesh->SetRotation(q);
				
				Vector3 dis = Vector3(0, 0 , -pos * SINGLE_SMOKE_LENGTH + BULLET_SMOKE_OFFSET);
				Vector3 position = from + dis * dir;
				pTemp->smoke_object_mesh->SetPosition(position);
				//pTemp->smoke_object_mesh->SetPosition(from);
				pos++;
				if(pos >= count)
				{
					alive_count -= count;
					return true;
				}
			}
		}
		
		return false;
	}

	/// update
	void BulletSmoke::Update(float frame_time)
	{
		for (uint i = 0; i < MAX_SMOKE_COUNT; i++)
		{
			tempc_ptr(BulletSmokeObject) pTemp = bullet_smoke_obj[i];
			if(pTemp && pTemp->smoke_show_timer > 0.f)
			{
				pTemp->smoke_show_timer -= frame_time;
				pTemp->smoke_object_mesh->Update();
				if(pTemp->smoke_show_timer < 0.f)
				{
					alive_count ++;
				}
			}
		}
	}

	/// draw
	void BulletSmoke::Draw(Primitive::DrawType drawtype, bool immediate)
	{
		for (uint i = 0; i < MAX_SMOKE_COUNT; i++)
		{
			tempc_ptr(BulletSmokeObject) pTemp = bullet_smoke_obj[i];

			if(pTemp && pTemp->smoke_show_timer > 0.f)
			{
				float f = pTemp->smoke_show_timer / SMOKE_EXIST_TIME;
				gDx9Device->SetPixelShaderConstantF(PS_CONSTANT_BULLET_SMOKE_TIME, &f);
				pTemp->smoke_object_mesh->Draw(drawtype,immediate);
			}
		}
	}

	void BulletSmoke::CreateMesh()
	{
		for (uint i = 0; i < MAX_SMOKE_COUNT; i++)
		{
			bullet_smoke_obj[i] = ptr_new BulletSmokeObject();
		}
	}


}