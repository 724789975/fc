#include "pch.h"

using namespace Core;

static float RandNumber(float min, float max)
{
	float r = (float)::rand() / ((float)RAND_MAX + 1);

	return r * (max - min) + min;
}

namespace Client
{
	SpiritBall::SpiritBall()
		: position(Vector3::kOne)
		, velocity(Vector3::kOne)

		, character_uid(0)

		, freefly_timer(0.7f)

		, is_dead(false)
	{
	}

	SpiritBall::~SpiritBall()
	{
	}

	/// initialize
	void SpiritBall::Initialize(byte uid, int score_hit, const Core::Vector3 &pos, int ball_type)
	{
		static Core::String szBall[] = {"soul_trail", "soul_trail_small"};

		//mesh = ptr_new StaticMesh(MESH_KEY_PROP);
		//mesh->AddPrimitive("lightball/lightball.mesh", 0);

		byte team = 0;
		tempc_ptr(Character) c = gLevel->GetCharacter(uid);
		if (c)
		{
			team = c->GetTeam();
		}

		Core::String name = Core::String::Format(szBall[ball_type & 1]);
		fly_particle = ptr_new ParticleSystem(name.Str(), false);

		character_uid = uid;
		character_score = score_hit;

		SetPosition(pos);
		velocity = Vector3(RandNumber(-1.5, 1.5), 5.0f + RandNumber(-0.5f, 0.5f), RandNumber(-1.5, 1.5));

		if (fly_particle)
		{
			fly_particle->SetEnable(true);
			fly_particle->SetPosition(GetPosition());
			fly_particle->SetRotation(GetRotation());
			gLevel->AddParticle(fly_particle);
		}
	}

	/// update
	void SpiritBall::Update(float time)
	{
		static const float fly_acceleration = 3.0f;

		static const float max_flyspeed = 15.0f;
		static const float max_flyspeed_sqr = max_flyspeed * max_flyspeed;

		tempc_ptr(Character) c = gLevel->GetCharacter(character_uid);
		if (!is_dead && c && !c->IsDied())
		{
			if (freefly_timer > 0.f)
			{
				freefly_timer -= time;
			}
			else
			{
				Vector3 c_pos = c->GetCameraPosition();

				c_pos.y -= 0.8f;
				Vector3 dir = c_pos - position;

				float len = dir.Length();
				float speed = velocity.Length();

				if (len > speed * time)
				{
					dir.Normalize();

					if (speed + fly_acceleration < max_flyspeed)
					{
						velocity = dir * (speed + fly_acceleration);
					}
					else
					{
						velocity = dir * max_flyspeed;
					}
				}
				else
				{
					is_dead = true;
				}
			}
		}
		else
		{
			is_dead = true;
		}

		if (!is_dead)
		{
			position += velocity * time;
		}
		else
		{
			fly_particle->SetDead();
			gLevel->RemoveParticle(fly_particle);
			FmodSystem::PlayEvent("bj/fx/3d/energyball_absorb");
			bool isPass = false;
			tempc_ptr(Character) player = gLevel->GetPlayer();
			if (!player)
				return;
			if (player->spiritball_num > 1)
			{
				player->spiritball_num--;
				return;
			}
			
			if (c && c->all_score < character_score)
			{
				if ((int)c->all_score == (int)character_score)
					isPass = true;
				c->all_score = character_score;
			}

			if (player->ui_score_line >= 0 && player->ui_score_line < 3)
			{
				AddEnergyEffectInfo &info = player->energy_bar_info;
				if (player->all_score < player->get_score && !isPass)
				{
					info.move_time = 0.0f;
					info.move_all_time = 0.75f;

					info.all_value = 1.0f;
					info.current_value = info.current_target_value;
					info.current_target_value = (player->all_score - player->get_last_score)/(player->get_score - player->get_last_score);
				}
				else if (!isPass)
				{
					player->UpdateUiScoreLine();
		
					info.move_time = 0.0f;
					info.move_all_time = 0.75f;

					info.all_value = 1.0f;
					info.current_value = info.current_target_value;
					info.current_target_value = Core::Clamp((player->all_score - player->get_last_score)/(player->get_score - player->get_last_score),0,1);
				}
			}
			if (player)
			{
				player->kill_score_time = 0.f;
			}
		}
	}

	/// draw
	void SpiritBall::Draw(Primitive::DrawType drawtype, bool immediate)
	{
		if (mesh)
		{
			mesh->SetPosition(GetPosition());
			mesh->SetRotation(GetRotation());
			mesh->Draw(drawtype, immediate);
		}

		if (fly_particle)
		{
			fly_particle->SetPosition(GetPosition());
			fly_particle->SetRotation(GetRotation());
		}
	}

	/// get mesh
	tempc_ptr(StaticMesh) SpiritBall::GetMesh()
	{
		return mesh;
	}

	/// set mesh
	void SpiritBall::SetMesh(by_ptr(StaticMesh) m)
	{
		mesh = m;
	}

	/// set mesh lod
	void SpiritBall::SetMeshLod(int lod_level)
	{
		if (mesh)
			mesh->SetBaseLodLevel(lod_level);
	}

	/// set visible
	void SpiritBall::SetVisible(bool flag)
	{
		if (mesh)
			mesh->SetVisible(flag);
	}

	/// get visible
	bool SpiritBall::GetVisible()	
	{
		if (mesh)
			return mesh->GetVisible();

		return false;
	}

	/// get position
	const Vector3 & SpiritBall::GetPosition()
	{
		return position;
	}

	/// set position
	void SpiritBall::SetPosition(const Core::Vector3 & pos)
	{
		position = pos;

		if (mesh)
			mesh->SetPosition(pos);
	}

	/// get velocity
	const Vector3 & SpiritBall::GetVelocity()
	{
		return velocity;
	}

	/// set velocity
	void SpiritBall::SetVelocity(const Core::Vector3 & vel)
	{
		velocity = vel;

		Quaternion rot(Vector3(0, 1, 0), velocity);

		if (mesh)
			mesh->SetRotation(rot);
	}

	/// get rotation
	Quaternion SpiritBall::GetRotation()
	{
		return Quaternion(Vector3(0, 1, 0), velocity);
	}

	/// get dead
	bool SpiritBall::GetDead()
	{
		return is_dead;
	}
}