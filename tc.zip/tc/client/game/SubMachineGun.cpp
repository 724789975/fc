#include "pch.h"

using namespace Client;
using namespace Core;

DEFINE_PDE_TYPE_CLASS(Client::SubMachineGunInfo)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Client::RifleInfo);

		ADD_PDE_DEFAULT_CONSTRUCTOR();
	}
};

DEFINE_PDE_TYPE_CLASS(Client::SubMachineGun)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Client::RifleGun);
	}
};

REGISTER_PDE_TYPE(Client::SubMachineGunInfo);
REGISTER_PDE_TYPE(Client::SubMachineGun);

SubMachineGun::SubMachineGun(by_ptr(SubMachineGunInfo) info)
: RifleGun(info)
{
}

/// get weapon type
uint SubMachineGun::GetWeaponType()
{
	return kWeaponTypeSubMachineGun;
}