#include "pch.h"

using namespace Core;
namespace Client
{
	struct VtxIndex
	{
		uint id;
		uint vertex;
		uint normal;
		uint texcoord;
	};
	// constructor
	DebugPrimitive::DebugPrimitive(by_ptr(DirectX9) dx9, by_ptr(Mesh) mesh)
	{

		Core::Array<VtxIndex> vtx_indices;
		vtx_indices.Reserve(mesh->NumFaceVertices());

		Core::Vector2* tc = mesh->GetUVs(0);
		for (int f = 0, i = 0; f < mesh->NumFaces(); ++ f)
		{
			Core::Array<int> vertices;
			Core::Array<int> normals;
			Core::Array<int> uvs;
			Core::Array<int> tbindex;

			mesh->GetFaceVertices(f, vertices);
			mesh->GetFaceVertexNormals(f, normals);
			mesh->GetFaceVertexUVs(f, 0, uvs);

			for (int fv = 0; fv < mesh->NumFaceVertices(f); ++ fv, ++ i)
			{
				VtxIndex& vi = vtx_indices.PushBack();
				vi.id = i;
				vi.vertex = vertices[fv];

				if (mesh->NumNormals())
					vi.normal = normals[fv];
				else
					vi.normal = -1;

				if (tc)
					vi.texcoord = uvs[fv];
				else
					vi.texcoord = -1;
			}
		}

		struct SortFunc
		{
			bool operator()(const VtxIndex& left, const VtxIndex& right) const
			{
				if (left.texcoord < right.texcoord ||
					left.normal < right.normal ||
					left.vertex < right.vertex ||
					left.id < right.id)
					return true;
				return false;
			}
		};

		Core::quick_sort(&vtx_indices[0], vtx_indices.Size(), SortFunc());

		Core::Array<uint> new_indices;
		new_indices.Resize(vtx_indices.Size());

		Core::Array<uint> vertices;
		vertices.Reserve(vtx_indices.Size());

		uint id_vertex = -1;
		uint id_normal = -1;
		uint id_texcoord = -1;
		for (uint i = 0; i < vtx_indices.Size(); ++ i)
		{
			VtxIndex& vtx_index = vtx_indices[i];
			if (id_vertex != vtx_index.vertex ||
				id_normal != vtx_index.normal ||
				id_texcoord != vtx_index.texcoord
			)
			{
				id_vertex = vtx_index.vertex;
				id_normal = vtx_index.normal;
				id_texcoord = vtx_index.texcoord;

				vertices.PushBack(i);
			}

			new_indices[vtx_index.id] = vertices.Size() - 1;
		}

		const Core::Vector3* points = mesh->GetPoints();
		const Core::Vector3* normals = mesh->GetNormals();

		struct Vertex
		{
			Vector3 position;
			D3DXVECTOR4_16F normal;
			D3DXVECTOR2_16F texcoord;
		};
		vertex_count = vertices.Size();
		gDx9Device->CreateVertexBuffer(vertex_count * sizeof(Vertex), 0, 0, D3DPOOL_MANAGED, &vertex_buffer, NULL);
		Vertex* vertex_data;
		if (SUCCEEDED(vertex_buffer->Lock(0, 0, (void**)&vertex_data, 0)))
		{
			for (uint i = 0; i < vertex_count; ++ i)
			{
				VtxIndex& v = vtx_indices[vertices[i]];
				vertex_data[i].position = points[v.vertex];

				if (normals)
					new(&vertex_data[i].normal) D3DXVECTOR4_16F(normals[v.normal].x, normals[v.normal].y, normals[v.normal].z, 0.f);
				else
					new(&vertex_data[i].normal) D3DXVECTOR4_16F(0, 0, 0, 0);


				if (tc)
					new(&vertex_data[i].texcoord) D3DXVECTOR2_16F(tc[v.texcoord].x, tc[v.texcoord].y);
				else
					new(&vertex_data[i].texcoord) D3DXVECTOR2_16F(0, 0);
			}
			vertex_buffer->Unlock();
		}

		{
			gDx9Device->CreateIndexBuffer(3 * mesh->NumTriangles() * sizeof(uint16), 0, D3DFMT_INDEX32, D3DPOOL_MANAGED, &index_buffer, NULL);
			primitive_count = mesh->NumTriangles();

			uint16* data = NULL;
			if (SUCCEEDED(index_buffer->Lock(0, 0, (void**)&data, 0)))
			{
				Core::Array<uint16*> lc_data;
				uint base_index = 0;
				for (int i = 0; i < mesh->NumFaces(); ++ i)
				{
					for (int t = 0; t < mesh->NumFaceTriangles(i); ++ t)
					{
						int idx[3];
						mesh->GetFaceTriangle(i, t, idx);
						*data = new_indices[idx[0] + base_index]; ++ data;
						*data = new_indices[idx[1] + base_index]; ++ data;
						*data = new_indices[idx[2] + base_index]; ++ data;
					}
					base_index += mesh->NumFaceVertices(i);
				}

				index_buffer->Unlock();
			}

		}
	}

	// destructor
	DebugPrimitive::~DebugPrimitive()
	{

	}



#if DEBUG_INFO

	DebugPrimitiveRect::DebugPrimitiveRect()
	{

	}

	DebugPrimitiveRect::~DebugPrimitiveRect()
	{
		vertices.Clear();
	}

	void DebugPrimitiveRect::CreateVertice(Core::Vector3* vec,uint length)
	{
		for ( uint i = 0; i < length; i++ )
		{
			vertices.PushBack( vec[i] );
		}
	}

	void DebugPrimitiveRect::Draw()
	{
		gDx9Device->SetVertexDeclaration(VD::GetVertexDeclaration(VertexDeclaration::kPosition));

		gDx9Device->DrawPrimitiveUP(D3DPT_TRIANGLEFAN, 2, vertices.GetData(), VD::GetVertexDeclarationStride(VertexDeclaration::kPosition));
	}
#endif
}