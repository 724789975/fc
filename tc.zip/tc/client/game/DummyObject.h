namespace Client
{ 
	#define SYNC_BUFFER_SIZE		256

	enum MoveDir
	{
		MOVE_DIR_NONE = 0,
		MOVE_DIR_FORWARD,
		MOVE_DIR_LEFT,
		MOVE_DIR_RIGHT,
		MOVE_DIR_BACK,
	};

	template <class T>
	int readUserData(const char* buffer,const int length, int start, T& result)
	{
		if(buffer && start + sizeof(result) <= (uint)length)
		{
			result = *(T*)((buffer + start));
			return start + sizeof(result);
		}
		return -1;
	}

	template <class T>
	int writeUserData(char* buffer,const int max_length, T& data)
	{
#ifndef MASTER
		if(sizeof(T) >= max_length)
		{

			MessageBoxA(NULL, gLang->GetTextWLocal(L"Length Overflow"),gLang->GetTextWLocal(L"Error"), MB_OK); 
			return 0;
		}
#endif
		memcpy_s(buffer, max_length, &data, sizeof(T));
		return sizeof(T);
	}
#pragma pack(push,1)

	struct GunTowerAttackBaseInfo
	{
		int damage_modifier;
		float range_start;
		float range_end;
		float range_modifier;
		int base_damage;
	};

	struct DummyBaseCreateInfo
	{
		// dummy base
		int level;
		Core::Vector3 position;
		Core::Quaternion rotation;
		char  key[32];
		char  tower_key[32];
		uint max_hp;

		//respawn
		short freeze_count;
		float respawn_time;

		// machine gun turret
		int damage_modifier;
		float range_start;
		float range_end;
		float range_modifier;
		int base_damage;

		float check_angle;
		float check_range;
		float angle_speed;
		float fire_interval;
		float life_time;
		float distance;
		int	max_ammo_count;
		int current_ammo_count;

		float move_speed;
		float move_keep_time;

		// medical
		float recover_range;
		float recover_check_interval;
		int	  recover_per_count_life;
		int   recover_per_percent_ammo;
		int   recover_per_minus_ammo;
	};

	struct DummySyncData
	{
		float time;
		short position[3];
		short rotation[3];
		short base_position[3];
		int ammo_count;
		int hp;
		byte dir_move_type;

		byte freeze;
		float respawn_time;
		byte freeze_count;
	};

	struct ServerDummyCreateInfo
	{
		Core::Vector3 position;
		Core::Quaternion rotation;

		int hp;
		int maxhp;
	
		char res_key[33];
	};

	struct ServerDummyCreateWithStepFatherInfo
	{
		byte type;
		byte sub_type;
		DummyBaseCreateInfo dummy_base_info;
	};

	struct ServerDummySyncData
	{
		float time;
		int hp;
	};

#pragma pack(pop)	

	void WriteVector3FP(short positionfp[3], const Core::Vector3 & position);

	void ReadVector3FP(short positionfp[3], Core::Vector3 & position);

	void WriteRotationFP(short rotationfp[3], const Core::Quaternion & rotation);
	
	void ReadRotationFP(short rotationfp[3], Core::Quaternion & rotation);
 
	struct DummyObjectInfo : public Core::Object
	{
		typedef Core::HashSet<Core::Identifier, Core::Identifier> MeshSet;

		DummyObjectInfo();
		void LoadConfig(Core::String key);
		
		void SetCollBoxSize(float x, float y, float z);
		Core::Vector3    coll_box_size;
		int				 coll_box_type;
		
		//����
		bool HasProtectorBox;
		void SetProtectorBoxSize(float x, float y, float z);
		void SetProtectorBoxPosition(float x, float y, float z);
		Core::Vector3    protector_box_size;
		Core::Vector3 protector_box_pos;


		uint dummy_id;
		byte owner_id;
		int  level;
		uint hp;
		byte sub_type;

		float move_speed;
		float move_keep_time;

		void SetDummyMesh(const Core::Identifier & key, const Core::Identifier & value, const U32 lod_level, const int _level);
		MeshSet dummy_mesh_set[MESH_LOD_LEVEL];
		Core::Identifier dummy_skeleton;
		Core::Identifier dummy_animationset;
		

		void SetTurretMesh(const Core::Identifier & key, const Core::Identifier & value, const U32 lod_level, const int _level);
		void SetDummyParticle(const Core::Identifier & value, const int _level, const Core::Identifier & value2);
		void SetDummyParticleMedical(const Core::Identifier & value, const int _level);
		void SetDummyHPOffset(float x, float y, float z);
		void SetDummyParalysisParticle(const Core::Identifier & value, const int _level, const Core::Identifier & value2);
		void SetDummyRebornParticle(const Core::Identifier & value, const int _level, const Core::Identifier & value2);

		void SetStartAnimation(const Core::Identifier & value, float time);
		MeshSet turret_mesh_set[MESH_LOD_LEVEL];
		Core::Identifier turret_skeleton;
		Core::Identifier turret_animationset;
		Core::Identifier dummy_particle_name;
		Core::Identifier dummy_particle_bone;
		Core::Identifier dummy_particle_medical_name;
		Core::Identifier dummy_die_particle;
		Core::Identifier turret_fire_particle;
		Core::Identifier build_particle;

		Core::Identifier dummy_paralysis_name;
		Core::Identifier dummy_reborn_name;
		Core::Identifier dummy_paralysis_bone;
		Core::Identifier dummy_reborn_bone;

		Core::Vector3 dummy_hp_offset;
		Core::Identifier start_animation;
		float start_animation_playtime;
		float destory_distance;
		

		Core::String tower_key;
		Core::Identifier dummy_sound_key;
		float outer_width;//���ڼ�����������Ƿ񽻲�
		float outer_height;//���ڼ�����������Ƿ񽻲�

	};

	class DummyObject : public DrawableObj
	{
		
	public:
		DummyObject();

		/// destructor
		~DummyObject();

		enum DummyType 
		{
			DUMMY_BASE = 0,
			DUMMY_MACHINE_TURRENT,
			DUMMY_MEDICAL,

			DUMMY_SERVER_NO_OWNER = 100,
		};
		enum DummySubType{
			SUBTYPE_WALL =0,
			SUBTYPE_GUARD =1,
			SUBTYPE_RESOURCE =4,
		};

		static tempc_ptr(DummyObject) FromNxActor(NxActor & actor);

	public:
		virtual bool Create(by_ptr(DummyObjectInfo) info, const DummyBaseCreateInfo& create_info);

		virtual bool CreateServer(by_ptr(DummyObjectInfo) info, const ServerDummyCreateInfo& create_info);

		virtual void Initialize();
		/// draw
		virtual void Draw(Primitive::DrawType drawtype, bool immediate = false);

	public:
		/// position
		virtual const Core::Vector3 & GetPosition();

		virtual void  SetPosition(const Core::Vector3 & pos);

		/// rotation
		virtual const Core::Quaternion & GetRotation();

		virtual void SetRotation(const Core::Quaternion & rot);

		void Update(float frame_time);

		virtual void UpdateLogic(float frame_time);

		virtual void UpdateFreeze(float frame_time);

		virtual void PlayAction(const Core::Identifier & key, float blend_time, bool loop);

		virtual void StopAction();
	public:
		virtual void SetVisible(bool flag);

		virtual bool GetVisible();

		virtual bool GetUpdate();

		virtual void SetUpdate(bool flag);

		virtual void SetSyncMaster(bool flag);

		virtual bool IsSyncMaster();

		virtual bool NeedSyncUpdate();

		virtual bool IsDead();

		virtual void SetSyncDirty(bool flag);

		virtual const char* GetSyncData(int& length);

		tempc_ptr(Pose) GetPose();

		bool GetDummyJointInfo(const Core::Identifier & joint_name, Core::Vector3 * position, Core::Quaternion * rotation);
	public:
		virtual void AddSyncData(byte time, const char* buffer, int size);

		virtual void Die();

		virtual void UpdateBaseRotation();

		void SetLifeTime(float t);

		void TakeDamage(int damage, bool isboost);

		bool CheckGrenade(const Core::Vector3 & pos, float & distance);

		bool GetJointInfo(const Core::Identifier & joint_name, Core::Vector3 * position, Core::Quaternion * rotation);
	protected:
		virtual void CreatePhysx();

		virtual void ReleasePhysx();

		virtual void InitializeMesh();

		virtual void SetAnimationSet();

		virtual void UpdateAnimation(float frame_time);
	private:
		virtual void UpdateSyncData(float frame_time);

		virtual void BuildSyncString();

		virtual void UpdateSound();
	protected:

		Core::Vector3 position;
		Core::Quaternion rotation;

		uint sync_data_length;
		char sync_buffer[SYNC_BUFFER_SIZE];

		Core::Deque<DummySyncData>	sync_data;

		sharedc_ptr(Skeleton) dummy_skeleton;
		
		sharedc_ptr(AnimationNodeCustom)	dummy_animation;
		sharedc_ptr(StaticMesh)				droped_box_mesh;

		NxActor* dummy_actor;
		NxActor* protector_actor;
		FMOD::Event*						idle_sound;
	public:
		sharedc_ptr(SkinMesh) dummy_mesh;
	protected:
		bool visible;
		bool need_update;
		bool sync_master;
		bool sync_dirty;

		float sync_time;
		float life_time;
		bool isdead;
		sharedc_ptr(Pose) pose;

		sharedc_ptr(ParticleSystem)	damage_particle;
		sharedc_ptr(ParticleSystem)	boostdamage_particle;

	public:
		sharedc_ptr(DummyObjectInfo) dummyobjectinfo;

		sharedc_ptr(ParticleSystem) dummy_particle;

		sharedc_ptr(ParticleSystem) dummy_medical_particle;

		// ̱����Ч
		sharedc_ptr(ParticleSystem) dummy_paralysis_particle;
		// ������Ч
		sharedc_ptr(ParticleSystem) dummy_reborn_particle;

		byte owner_id;
		byte type;
		byte sub_type;
		int hp;
		bool is_on_moving;

		bool can_hurt;
		bool need_stepfather;
		byte owner_team;
		Core::String m_szResKey;
		float freeze_timer;

		byte freeze_count;
		float respawn_time;

		bool freeze;
	};



	struct TurretInfo : public Core::Object
	{
		float check_angle;
		float check_range;
		float angle_speed;
		float fire_interval;
		int max_ammo_count;

		GunTowerAttackBaseInfo attack_base_info;
		
		TurretInfo();
	};

	class MachineGunTurret : public DummyObject
	{
	public:
		MachineGunTurret();

		/// destructor
		~MachineGunTurret();

	//public:
		virtual void Initialize();

		virtual bool Create(by_ptr(DummyObjectInfo) info, const DummyBaseCreateInfo& create_info);

	//	/// draw
		virtual void Draw(Primitive::DrawType drawtype, bool immediate = false);

		virtual Core::Quaternion GetTurretRotation();

		virtual Core::Vector3 GetTurretPosition();
		
		virtual void PlayAction(const Core::Identifier & key, float blend_time, bool loop);

		virtual void UpdateBaseRotation();

		virtual void UpdateFreeze(float frame_time);

		virtual void AddSyncData(byte time, const char* buffer, int size);

		void Fire(byte t_id, byte part);

		virtual void Die();

		void SetAmmoCount(int count);

		int GetAmmoCount();

		bool AmmoIsFull();

		void MoveCommand(int command_type);

		bool GetUpBodyJointInfo(const Core::String& szJoint, Core::Vector3* pos, Core::Quaternion* rot);
	
		tempc_ptr(Pose) GetUpBodyPose();
	
	private:
		virtual void UpdateLogic(float frame_time);

		virtual tempc_ptr(Pose) GetPose();

	protected:
		virtual void InitializeMesh();

		virtual void SetAnimationSet();

		virtual void UpdateAnimation(float frame_time);

		virtual void UpdateSyncData(float frame_time);

		virtual void BuildSyncString();

		virtual void UpdateSound();


	private:
		byte SearchEnemy();

		bool CheckIsInArea(byte t_id);
		
		bool GetTurretJointInfo(const Core::Identifier & joint_name, Core::Vector3 * position, Core::Quaternion * rotation);

		void FireCheck();

		

	private:
		sharedc_ptr(Skeleton)				turret_skeleton;
		sharedc_ptr(SkinMesh)				turret_mesh;
		sharedc_ptr(AnimationNodeCustom)	turret_animation;

		Core::Quaternion					turret_rotation;
		Core::Vector3						turret_position;

		
		byte								target_id;

		int									gun_bh_joint_id;

		Core::Quaternion					idle_base_quaternion;
		
		float								gun_blend_timer;
		bool								gun_blend_over;
		Core::Quaternion					turn_gun_base_quaternion;	

		float								fire_interval_timer;

		sharedc_ptr(ParticleSystem)			turret_fire_particle;
		sharedc_ptr(ParticleSystem)			build_particle;

		float								turret_start_animation_timer;
		float								turret_freeze_animation_timer;
		
		int									ammo_count;

		FMOD::Event*						idle_3D_sound;
		FMOD::Event*						search_3D_sound;

		byte								dir_type;
		bool								need_sync_move;
		//bool								can_move;

	public:
		TurretInfo							turret_info;
		float								move_timer;
		Core::Vector3						move_dir;

		float								recover_range;
		float								recover_check_interval;
		int	 								recover_per_count_life;
		int  								recover_per_percent_ammo;
		int  								recover_per_minus_ammo;

		float								recover_timer;
	};

	//class MedicalDummy : public DummyObject
	//{
	//public:
	//	MedicalDummy();

	//	~MedicalDummy();

	//	virtual	void Initialize();

	//	virtual void UpdateLogic(float frame_time);

	//	virtual bool Create(by_ptr(DummyObjectInfo) info, const DummyBaseCreateInfo& create_info);

	//	float recover_range;
	//	float recover_check_interval;
	//	int	  recover_per_count_life;
	//	int  recover_per_percent_ammo;

	//	float recover_timer;
	//};
}