#include "pch.h"
#include <dbghelp.h>
#include <string.h>
#include <time.h> 

//#include <setupapi.h>
//#include <devguid.h>
//#include <regstr.h>
//
//#pragma comment (lib, "Setupapi.lib")

using namespace Core;
using namespace Client;

extern const char * client_version;

EXTERN_C IMAGE_DOS_HEADER __ImageBase;
DWORD g_BuildTimeStamp = 0;

static LONG WINAPI CrashDump(struct _EXCEPTION_POINTERS *pExceptionPointers)   
{   
	SetErrorMode( SEM_NOGPFAULTERRORBOX );

	HMODULE dbghelp = LoadLibraryA("dbghelp.dll");

	typedef BOOL  (WINAPI *MiniDumpWriteDumpFunc)(
		IN HANDLE hProcess,
		IN DWORD ProcessId,
		IN HANDLE hFile,
		IN MINIDUMP_TYPE DumpType,
		IN CONST PMINIDUMP_EXCEPTION_INFORMATION ExceptionParam, OPTIONAL
		IN CONST PMINIDUMP_USER_STREAM_INFORMATION UserStreamParam, OPTIONAL
		IN CONST PMINIDUMP_CALLBACK_INFORMATION CallbackParam OPTIONAL
		);

	if (dbghelp)
	{
		MiniDumpWriteDumpFunc _MiniDumpWriteDump = (MiniDumpWriteDumpFunc)GetProcAddress(dbghelp, "MiniDumpWriteDump");

		if (_MiniDumpWriteDump)
		{
			// client version
			extern const char * client_version;

			SYSTEMTIME stLocalTime;
			GetLocalTime( &stLocalTime );

			CStrBuf<256> dump_filename;
			dump_filename.format("%s-%04d%02d%02d-%02d%02d%02d%03d.dmp", client_version,
				stLocalTime.wYear, stLocalTime.wMonth, stLocalTime.wDay,    
				stLocalTime.wHour, stLocalTime.wMinute, stLocalTime.wSecond, stLocalTime.wMilliseconds);

			HANDLE hDumpFile = CreateFileA(dump_filename.buff(), GENERIC_READ | GENERIC_WRITE, FILE_SHARE_WRITE | FILE_SHARE_READ, 0, CREATE_ALWAYS, 0, 0);

			MINIDUMP_EXCEPTION_INFORMATION ExpParam;
			ExpParam.ThreadId = GetCurrentThreadId();   
			ExpParam.ExceptionPointers = pExceptionPointers;   
			ExpParam.ClientPointers = FALSE;

			MINIDUMP_TYPE DumpType = (MINIDUMP_TYPE)(
				MiniDumpNormal 
				//| MiniDumpWithDataSegs 
				| MiniDumpWithHandleData 
				| MiniDumpWithUnloadedModules 
				| MiniDumpWithIndirectlyReferencedMemory 
				| MiniDumpScanMemory 
				| MiniDumpWithProcessThreadData 
				//| MiniDumpWithPrivateReadWriteMemory
				);

			_MiniDumpWriteDump(GetCurrentProcess(), GetCurrentProcessId(),    
								hDumpFile, DumpType, &ExpParam, NULL, NULL);

			CloseHandle(hDumpFile);
		}

		FreeModule(dbghelp);
	}

	::MessageBoxA(NULL, gLang->GetTextWLocal(L"�����쳣�˳�"), gLang->GetTextWLocal(L"����"), MB_OK);

	return EXCEPTION_EXECUTE_HANDLER;
}   



static bool MountPath(const char * vfs_path, const char * path, Path::VFSAccess access, int priority, bool existing_only = false)
{
	CStrBuf<MAX_PATH> temp;

	if (path == NULL)
		return false;

	// current directory
	if (path[0] == '~')
	{
		// current folder
		GetCurrentDirectoryA(temp.size32(), temp.buff());
		temp.calclen();
		temp.contract(path + 1);
	}
	else
	{
		// get module file name
		GetModuleFileNameA(NULL, temp.buff(), temp.size32());
		Path::GetFilePath(temp, temp.buff());

		// convert to physical path
		temp.contract(path);
	}

	bool exists = Path::Exists(temp.buff());
	
	if (exists || !existing_only)
		Path::MountVFS(vfs_path, temp.buff(), access, priority);

	return exists;
}

namespace Client
{
	StartConfig gStartConfig;
	SystemInfoCollection g_SystemInfo_collection;
	InGameInfoCollection g_InGameInfo_collection;
	HttpConfig	gHttpConfig;
	FaceBookInterface gFaceBookInterface;
}
//
//static int GetSysInfo()
//{
//	HDEVINFO hDevInfo;
//	SP_DEVINFO_DATA DeviceInfoData;
//	DWORD i;
//
//	// Create a HDEVINFO with all present devices.
//	hDevInfo = SetupDiGetClassDevsA( (LPGUID) &GUID_DEVCLASS_DISPLAY,
//		0, // Enumerator
//		0,
//		DIGCF_PRESENT  );
//
//	if (hDevInfo == INVALID_HANDLE_VALUE)
//	{
//		// Insert error handling here.
//		return 1;
//	}
//
//	// Enumerate through all devices in Set.
//
//	DeviceInfoData.cbSize = sizeof(SP_DEVINFO_DATA);
//	for (i=0;SetupDiEnumDeviceInfo(hDevInfo,i,
//		&DeviceInfoData);i++)
//	{
//		DWORD DataT;
//		LPTSTR buffer = NULL;
//		DWORD buffersize = 0;
//
//		// 
//		// Call function with null to begin with, 
//		// then use the returned buffer size 
//		// to Alloc the buffer. Keep calling until
//		// success or an unknown failure.
//		// 
//		while (!SetupDiGetDeviceRegistryProperty(
//			hDevInfo,
//			&DeviceInfoData,
//			SPDRP_DEVICEDESC,
//			&DataT,
//			(PBYTE)buffer,
//			buffersize,
//			&buffersize))
//		{
//			if (GetLastError() == 
//				ERROR_INSUFFICIENT_BUFFER)
//			{
//				// Change the buffer size.
//				if (buffer)
//					LocalFree(buffer);
//				buffer = (LPTSTR)LocalAlloc(LPTR,buffersize);
//			}
//			else
//			{
//				// Insert error handling here.
//				break;
//			}
//		}
//
//
//		CStrBuf<256> buf(buffer);
//
//		LogSystem.WriteLinef("video_adapter : %s",buf.buff());
//
//		if (buffer)
//			LocalFree(buffer);
//	}
//
//
//	if ( GetLastError()!=NO_ERROR &&
//		GetLastError()!=ERROR_NO_MORE_ITEMS )
//	{
//		// Insert error handling here.
//		return 1;
//	}
//
//	//  Cleanup
//	SetupDiDestroyDeviceInfoList(hDevInfo);
//
//	return 0;
//}
// run log
static void SetupRunLog()
{
	// current time
	SYSTEMTIME stLocalTime;
	GetLocalTime( &stLocalTime );

	CStrBuf<256> str_date;
	CStrBuf<256> str_time;

	str_date.format("%04d%02d%02d", stLocalTime.wYear, stLocalTime.wMonth, stLocalTime.wDay);
	str_time.format("%02d%02d%02d%03d", stLocalTime.wHour, stLocalTime.wMinute, stLocalTime.wSecond, stLocalTime.wMilliseconds);

    char current_path[256];
	GetCurrentDirectoryA(sizeof(current_path), current_path);

	//// check dump file
	//bool has_dump = false;

	//CStrBuf<256> buff(current_path);
	//buff.contract("/*");

	//WIN32_FIND_DATAA find_data;
	//HANDLE find_handle = FindFirstFileA(buff.buff(), &find_data);

	//if (find_handle)
	//{
	//	while (FindNextFileA(find_handle, &find_data))
	//	{
	//		if (find_data.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
	//			continue;

	//		CStrBuf<32> ext;
	//		Path::GetFileExtension(ext, find_data.cFileName);

	//		if (ext == "dmp")
	//		{
	//			has_dump = true;

	//			CStrBuf<256> str(current_path);
	//			str.contractf("/%s", find_data.cFileName);

	//			HttpPostFile("dump", 0, str.buff(), str_date, str_time);
	//			DeleteFileA(str);
	//		}
	//	}
	//}

	//// delete log
	//if (Path::IsDirectory("/logs/"))
	//{
	//	PdeItPath it;
	//	it.Reset("/logs/", false);

	//	while (it.MoveNext())
	//	{
	//		if (it.IsDirectory())
	//			continue;

	//		CStrBuf<32> ext;
	//		Path::GetFileExtension(ext, it.Name().buff());

	//		if (ext == "log")
	//		{
	//			CStrBuf<256> str;
	//			str.format("/logs/%s", it.Name().buff());
	//			Path::GetPhysicalPath(str, str, Path::kVirtualReadWrite);

	//			if (has_dump)
	//				HttpPostFile("dump", 0, str.buff(), str_date, str_time);

	//			DeleteFileA(str);
	//		}
	//	}
	//}

	Path::MakeDirectory("/logs/");

	CStrBuf<256> log_filename;
	log_filename.format("/logs/%s-%04d%02d%02d-%02d%02d%02d%03d.log", client_version,
		stLocalTime.wYear, stLocalTime.wMonth, stLocalTime.wDay,    
		stLocalTime.wHour, stLocalTime.wMinute, stLocalTime.wSecond, stLocalTime.wMilliseconds);

	LogSystem.SetDevice(log_filename);

	LogSystem.WriteLinef("version : %s", client_version);
	LogSystem.WriteLinef("time : %04d.%02d.%02d %02d:%02d:%02d.%03d", stLocalTime.wYear, stLocalTime.wMonth,
		stLocalTime.wDay, stLocalTime.wHour, stLocalTime.wMinute, stLocalTime.wSecond, stLocalTime.wMilliseconds);

	// os version
	OSVERSIONINFOEX os_version;
	ZeroMemory(&os_version, sizeof(OSVERSIONINFOEX));
	os_version.dwOSVersionInfoSize = sizeof(OSVERSIONINFOEX);

	if (GetVersionEx((OSVERSIONINFO*)&os_version))
	{
		CStrBuf<256> os_str;

		if (os_version.dwPlatformId == VER_PLATFORM_WIN32_NT) 
		{ 
			if (os_version.dwMajorVersion <= 4) 
				os_str.contractf("Microsoft Windows NT "); 
			else if (os_version.dwMajorVersion == 5) 
			{
				if (os_version.dwMinorVersion == 0)
					os_str.contractf("Microsoft Windows 2000 ");
				else if (os_version.dwMinorVersion == 1)
					os_str.contractf("Microsoft Windows XP ");
				else if (os_version.dwMinorVersion == 2)
					os_str.contractf("Microsoft Windows 2003 ");
			}
			else if (os_version.dwMajorVersion == 6)
			{
				if (os_version.dwMinorVersion == 0)
				{
					if (os_version.wProductType == VER_NT_WORKSTATION)
						os_str.contractf("Microsoft Windows VISTA ");
					else
						os_str.contractf("Microsoft Windows 2008 ");
				}
				else if (os_version.dwMinorVersion == 1)
				{
					if (os_version.wProductType == VER_NT_WORKSTATION)
						os_str.contractf("Microsoft Windows 7 ");
					else
						os_str.contractf("Microsoft Windows 2008 R2 ");
				}
			}

			if (os_str.len() > 0)
			{
				os_str.contractf( "version %d.%d (Build %d)", 
					os_version.dwMajorVersion, 
					os_version.dwMinorVersion, 
					os_version.dwBuildNumber   &   0xFFFF);
			}
		}

		LogSystem.WriteLinef("os : %s", os_str);
		g_SystemInfo_collection.os = String(os_str.buff());
	}

	// cpu info
	HKEY   hKey;     
    RegOpenKeyExA(HKEY_LOCAL_MACHINE, "HARDWARE\\DESCRIPTION\\System\\CentralProcessor\\0", 0, KEY_READ, &hKey);   
    char cpu_name[256];
    unsigned long name_len = sizeof(cpu_name);   
    DWORD reg_type = REG_SZ;   
	RegQueryValueExA(hKey, "ProcessorNameString", NULL, &reg_type, (unsigned char *)cpu_name, &name_len);  
    RegCloseKey(hKey);
	LogSystem.WriteLinef("cpu : %s", cpu_name);
	
	g_SystemInfo_collection.cpu_name = String(cpu_name);
	// memory info
	MEMORYSTATUS stat;
	GlobalMemoryStatus(&stat);
	LogSystem.WriteLinef("memory : %dMb", stat.dwTotalPhys / 1024 / 1024);

	// path info
	LogSystem.WriteLinef("path : %s", current_path);

	
}

// lua file loader
static int LuaFileLoader(Lua::LuaState * L, const char * file_name)
{
	if (L)
	{
		sharedc_ptr(ScriptLua) lua = RESOURCE_LOAD(file_name, false, ScriptLua);

		if (lua)
		{
			int status = L->LoadBuffer(lua->GetBuffer(), lua->GetSize(), file_name);

			return status;
		}
	}

	L->PushFString("cannot open %s", file_name);

	return Lua::ERRERR + 1;
}

extern HANDLE g_Heap;

int APIENTRY wWinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPWSTR lpCmdLine, int nCmdShow)
{
	//AntiDllInstall();

	//int a = GetCheckSum(&Direct3DCreate9, 100);
	// crash dump
	SetUnhandledExceptionFilter(CrashDump);

	// set lfh
	ULONG HeapInformation = 2;

	HANDLE hHeap1 = GetProcessHeap();
	BOOL bResult1 = HeapSetInformation(hHeap1, HeapCompatibilityInformation, &HeapInformation, sizeof(HeapInformation));

	HANDLE hHeap2 = (HANDLE)_get_heap_handle();
	BOOL bResult2 = HeapSetInformation(hHeap2, HeapCompatibilityInformation, &HeapInformation, sizeof(HeapInformation));

	// flash
	FlashPlayer::Initialize();

	// console
	Console.Initialize();

	// log system
	LogSystem.SetOutputStream(&Console.GetStream());

	Path::UnmountVFS("/");

#ifdef MASTER
	// release data path
	if (MountPath("/", "finalcombat.pde", Path::kVirtualRead, 0))
	{
		// do nothing
	}
	else
	{
		if (!MountPath("/", "common.pde", Path::kVirtualRead, 0))
		{
			MessageBoxW(NULL, L"Load Resource File Error!", L"", MB_OK);
			return 1;
		}
		if (!MountPath("/", "audio.pde", Path::kVirtualRead, 0))
		{
			MessageBoxW(NULL, L"Load Resource File Error!", L"", MB_OK);
			return 1;
		}
		if (!MountPath("/", "ui.pde", Path::kVirtualRead, 0))
		{
			MessageBoxW(NULL, L"Load Resource File Error!", L"", MB_OK);
			return 1;
		}
		if (!MountPath("/", "effect.pde", Path::kVirtualRead, 0))
		{
			MessageBoxW(NULL, L"Load Resource File Error!", L"", MB_OK);
			return 1;
		}
		if (!MountPath("/", "shader.pde", Path::kVirtualRead, 0))
		{
			MessageBoxW(NULL, L"Load Resource File Error!", L"", MB_OK);
			return 1;
		}
		if (!MountPath("/", "resource.pde", Path::kVirtualRead, 0))
		{
			MessageBoxW(NULL, L"Load Resource File Error!", L"", MB_OK);
			return 1;
		}
		if (!MountPath("/", "scripts.pde", Path::kVirtualRead, 0))
		{
			MessageBoxW(NULL, L"Load Resource File Error!", L"", MB_OK);
			return 1;
		}
	}
#else
	// develop data path
	if (MountPath("/", "../../../data", Path::kVirtualRead, 0))
	{
		MountPath("/", "../../../common.pde", Path::kVirtualReadWrite, 1, true);
		MountPath("/", "../../../audio.pde", Path::kVirtualReadWrite, 1, true);
		MountPath("/", "../../../ui.pde", Path::kVirtualReadWrite, 1, true);
		MountPath("/", "../../../effect.pde", Path::kVirtualReadWrite, 1, true);
		MountPath("/", "../../../shader.pde", Path::kVirtualReadWrite, 1, true);
		MountPath("/", "../../../resource.pde", Path::kVirtualReadWrite, 1, true);
		MountPath("/", "../../../scripts.pde", Path::kVirtualReadWrite, 1, true);

		MountPath("/", "../../../cache", Path::kVirtualReadWrite, 1);
	}
	else
	{
		Path::UnmountVFS("/");
		
		// release data path
		MountPath("/", "common.pde", Path::kVirtualRead, 0, true);
		MountPath("/", "audio.pde", Path::kVirtualRead, 0, true);
		MountPath("/", "ui.pde", Path::kVirtualRead, 0, true);
		MountPath("/", "effect.pde", Path::kVirtualRead, 0, true);
		MountPath("/", "shader.pde", Path::kVirtualRead, 0, true);
		MountPath("/", "resource.pde", Path::kVirtualRead, 0, true);
		MountPath("/", "scripts.pde", Path::kVirtualRead, 0, true);

		MountPath("/", "data", Path::kVirtualRead, 0);

		// current data path
		MountPath("/", "~/data", Path::kVirtualRead, 1);
		MountPath("/", "~/cache", Path::kVirtualReadWrite, 1);
	}
#endif

	// pictures path
	MountPath("/pictures", "~/pictures", Path::kVirtualReadWrite, 2);
	Path::MakeDirectory("/pictures/");

	MountPath("/replay", "~/replay", Path::kVirtualReadWrite, 2);
	MountPath("/logs", "~/logs", Path::kVirtualReadWrite, 2);

	// set lua file loader
	Lua::LuaState::file_loader = LuaFileLoader;

	// global game instance.
	sharedc_ptr(Game) game;

	try
	{
		gStartConfig.ip = "10.10.12.10";
		gStartConfig.port = 9000;

		//gStartConfig.ip = "10.10.12.11";//zlm
		//gStartConfig.port = 29000;

		//gStartConfig.ip = "183.60.208.104";//�ڲ�
		//gStartConfig.port = 9000;

		gStartConfig.ip = "10.10.12.12";//guan
		gStartConfig.port = 15000;  
		gStartConfig.areaid = -1;
		gStartConfig.serverid = -1;
		gStartConfig.exec = false;
		gStartConfig.exec_cmd = String::kEmpty;
		gStartConfig.module_state_Open = false;

		gStartConfig.ads_on = false;

		if (lpCmdLine[0])
		{
			int argc;
			LPWSTR * argv = CommandLineToArgvW(lpCmdLine,	&argc);

			for (int i = 0; i < argc; i ++)
			{
				if (_wcsicmp(argv[i], L"-areaid") == 0)
				{
					if (++i < argc)
					{
						CStrBuf<256> arg(argv[i]);
						gStartConfig.areaid = atoi(arg);
						continue;
					}
				}
				else if (_wcsicmp(argv[i], L"-serverid") == 0)
				{
					if (++i < argc)
					{
						CStrBuf<256> arg(argv[i]);
						gStartConfig.serverid = atoi(arg);
						continue;
					}
				}
				else if (_wcsicmp(argv[i], L"-info") == 0)
				{
					if (++i < argc)
					{
						CStrBuf<256> code(argv[i]);
						gStartConfig.authentication_code = code;
						continue;
					}
				}
				else if (_wcsicmp(argv[i], L"-login") == 0)
				{
					if (++i < argc)
					{
						CStrBuf<256> code(argv[i]);
						gStartConfig.login_code = code;
						continue;
					}
				}
				else if (_wcsicmp(argv[i], L"-proxysvrip") == 0)
				{
					if (++i < argc)
					{
						CStrBuf<256> address(argv[i]);
						gStartConfig.ip = address;
						continue;
					}
				}
				else if (_wcsicmp(argv[i], L"-proxysvrport") == 0)
				{
					if (++i < argc)
					{
						CStrBuf<256> arg(argv[i]);
						gStartConfig.port = atoi(arg);
						continue;
					}
				}
#ifndef MASTER
				else if (_wcsicmp(argv[i], L"-dependence") == 0)
				{
					if (++i < argc)
					{
						CStrBuf<256> arg(argv[i]);
						Resource::SetUseDependence(atoi(arg) != 0);
						continue;
					}
				}
				else if (_wcsicmp(argv[i], L"-exec") == 0)
				{
					gStartConfig.exec = true;

					if (++i < argc)
					{
						CStrBuf<256> arg(argv[i]);
						gStartConfig.exec_cmd = arg;
						continue;
					}
				}
				else if (_wcsicmp(argv[i], L"-modulestateOpen") == 0)
				{
					if (++i < argc)
					{
						CStrBuf<256> arg(argv[i]);
						gStartConfig.module_state_Open = (atoi(arg) != 0);
						continue;
					}
				}
				
#endif
			}
		}

		// setup run log
		SetupRunLog();

		// initialize thread
		Thread::Initialize();

		// init module system
		Module::Initialize();

		// initialize resource
		Resource::Initialize();

		// initialize net
		SocketStream::Initialize();

		//HttpXlInfo();

		if (bResult1)
			LogSystem.WriteLinef("lfh ok : %x", hHeap1);
		else
			LogSystem.WriteLinef("lfh failed : %x", hHeap1);

		if (bResult2)
			LogSystem.WriteLinef("lfh2 ok : %x", hHeap2);
		else
			LogSystem.WriteLinef("lfh2 failed : %x", hHeap2);

		LogSystem.WriteLinef("lfh3 : %x", g_Heap);

#ifdef MASTER
		Resource::SetUseDependence(false);
#endif

		game = ptr_new Game;
		bool rungame = true;

		if (gStartConfig.exec)
		{
			////fix for gen cache
			//DWORD ProcessAffinityMask;
			//DWORD SystemAffinityMask;
			//if (GetProcessAffinityMask(GetCurrentProcess(), &ProcessAffinityMask, &SystemAffinityMask))
			//{
			//	SetThreadAffinityMask(GetCurrentThread(), ProcessAffinityMask);

			//	Core::LogSystem.WriteLinef("disable affinitymask");
			//}

			if (gStartConfig.exec_cmd != String::kEmpty)
			{
				Lua::LuaState::FromThread()->DoFile(gStartConfig.exec_cmd, true);
				rungame = false;
				game->notify_error = false;
			}
		}

		if (rungame)
		{
			// game start
			game->machine.ChangeState(ptr_new StateInit);
		}

		while (Thread::Running())
		{
			sharedc_ptr(Task) msg = Task::Receive();

			if (msg)
			{
				Task::Dispatch(msg);
			}
		}

	}
	catch (Core::String & err)
	{
		CStrBuf<256> buff;
		buff.copy(err.RefStr());

		::MessageBoxA(NULL, buff, gLang->GetTextWLocal(L"����"), MB_OK);
	}

	// terminate resource
	Resource::Terminate();

	game = NullPtr;

	// teminate net
	WSACleanup();

	// stop modules
	Module::StopAll();

	// unload modules
	Module::Terminate();

	// terminate thread
	Thread::Terminate();

	// close log output
	LogSystem.SetOutputStream(NULL);

	// destroy console
	Console.Terminate();

	// teminate flash
	FlashPlayer::Terminate();

	return 0;
}
