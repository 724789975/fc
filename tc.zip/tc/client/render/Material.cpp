#include "pch.h"
#include "../game/LuaLoadingFunc.h"
using namespace Core;

namespace Client
{
	Material::Material()
		: vertex_level(0)
		, pixel_level(0)
	{
	}

	Material::~Material()
	{
	}

	bool Material::ChooseShader(S32 lod)
	{
		if (!vertex_shader.Size())
			return false;

		if (!pixel_shader.Size())
			return false;

		if (lod == -1)
			vertex_level = pixel_level = gRender->lod_control->GetShaderLod();
		else
			vertex_level = pixel_level = lod;

		if (vertex_shader.Size() <= vertex_level)
		{
			if (vertex_shader.Size())
				vertex_level = vertex_shader.Size() - 1;
		}
		curr_vertex_shader = vertex_shader[vertex_level];

		if (pixel_shader.Size() <= pixel_level)
		{
			if (pixel_shader.Size())
				pixel_level = pixel_shader.Size() - 1;
		}
		curr_pixel_shader = pixel_shader[pixel_level];

		return true;
	}

	bool Material::SetParameter()
	{
		if (!curr_vertex_shader || !curr_pixel_shader)
			return false;
#if DEBUG_SHADER
		for (U32 i = 0; i < vertex_uniform[vertex_level].Size(); i++)
		{
			for (U32 j = 0; j < curr_vertex_shader->value_array.Size(); j++)
			{
				if (vertex_uniform[vertex_level][i].type_name == curr_vertex_shader->value_array[j].type_name)
				{
					gDx9Device->SetVertexShaderConstantF(curr_vertex_shader->value_array[j].reg, vertex_uniform[vertex_level][i].value.GetData(), curr_vertex_shader->value_array[j].size);
				}
			}
		}

		for (U32 i = 0; i < pixel_uniform[pixel_level].Size(); i++)
		{
			for (U32 j = 0; j < curr_pixel_shader->value_array.Size(); j++)
			{
				if (pixel_uniform[pixel_level][i].type_name == curr_pixel_shader->value_array[j].type_name)
				{
					gDx9Device->SetPixelShaderConstantF(curr_pixel_shader->value_array[j].reg, pixel_uniform[pixel_level][i].value.GetData(), curr_pixel_shader->value_array[j].size);
				}
			}
		}
#else
		for (U32 i = 0; i < vertex_uniform[vertex_level].Size(); i++)
		{
			gDx9Device->SetVertexShaderConstantF(vertex_uniform[vertex_level][i].uniform.reg, vertex_uniform[vertex_level][i].value.GetData(), vertex_uniform[vertex_level][i].uniform.size);
		}

		for (U32 i = 0; i < pixel_uniform[pixel_level].Size(); i++)
		{
			gDx9Device->SetPixelShaderConstantF(pixel_uniform[pixel_level][i].uniform.reg, pixel_uniform[pixel_level][i].value.GetData(), pixel_uniform[pixel_level][i].uniform.size);
		}
	
#endif
		return true;
	}

	bool Material::SetVertexShader()
	{
		if (!curr_vertex_shader)
			return false;

		curr_vertex_shader->SetShader();
		return true;
	}

	bool Material::SetPixelShader()
	{
		if (!curr_pixel_shader)
			return false;

		curr_pixel_shader->SetShader();
		return true;
	}

	bool Material::SetTexture(S32 index)
	{
		if (!curr_pixel_shader)
			return false;

#if DEBUG_TOOLS
		if(gGame->bdebugSceneState)
		{
			for (U32 i = 0; i < texture_uniform[pixel_level].Size(); i++)
			{
				tempc_ptr(StateDebugScene) debugsence = ptr_dynamic_cast<StateDebugScene>(gGame->machine.CurrentState());
				if(!debugsence->m_bDrawColorMap && texture_uniform[pixel_level][i].uniform.reg == 0)
				{
					gDx9Device->SetTexture(texture_uniform[pixel_level][i].uniform.reg, gGame->render->render_pipeline->m_GrayTexture->GetTexture());
				}
				else if(!debugsence->m_bDrawLightMap && texture_uniform[pixel_level][i].uniform.reg == 4)
				{
					gDx9Device->SetTexture(texture_uniform[pixel_level][i].uniform.reg, gGame->render->render_pipeline->m_GrayTexture->GetTexture());
				}
				else if(!debugsence->m_bDrawMask1Map && texture_uniform[pixel_level][i].uniform.reg ==8)
				{
					gDx9Device->SetTexture(texture_uniform[pixel_level][i].uniform.reg, gGame->render->render_pipeline->m_GrayTexture->GetTexture());
				}
				else if(!debugsence->m_bDrawMask2Map && texture_uniform[pixel_level][i].uniform.reg == 5)
				{
					gDx9Device->SetTexture(texture_uniform[pixel_level][i].uniform.reg, gGame->render->render_pipeline->m_GrayTexture->GetTexture());
				}
				else if(!debugsence->m_bDrawDecal1Map && texture_uniform[pixel_level][i].uniform.reg ==6)
				{
					gDx9Device->SetTexture(texture_uniform[pixel_level][i].uniform.reg, gGame->render->render_pipeline->m_GrayTexture->GetTexture());
				}
				else if(!debugsence->m_bDrawDecal2Map && texture_uniform[pixel_level][i].uniform.reg ==7)
				{
					gDx9Device->SetTexture(texture_uniform[pixel_level][i].uniform.reg, gGame->render->render_pipeline->m_GrayTexture->GetTexture());
				}
				else
				{
					for (U32 j = 0; j < curr_pixel_shader->texture_array.Size(); j++)
					{
						if (texture_uniform[pixel_level][i].type_name == curr_pixel_shader->texture_array[j].type_name)
						{
							if (index > 0 && curr_pixel_shader->texture_array[j].reg != index)
								continue;

							sharedc_ptr(Texture) texture = texture_uniform[pixel_level][i].value;
							texture->SetBasicLod(gRender->lod_control->GetTextureLod());

							gDx9Device->SetTexture(curr_pixel_shader->texture_array[j].reg, texture->GetTexture());

							if (curr_pixel_shader->texture_array[j].reg == index)
								return true;
						}
					}
				}

			}
			return true;
		}
		else
		{
			for (U32 i = 0; i < texture_uniform[pixel_level].Size(); i++)
			{
				for (U32 j = 0; j < curr_pixel_shader->texture_array.Size(); j++)
				{
					if (texture_uniform[pixel_level][i].type_name == curr_pixel_shader->texture_array[j].type_name)
					{
						if (index > 0 && curr_pixel_shader->texture_array[j].reg != index)
							continue;

						sharedc_ptr(Texture) texture = texture_uniform[pixel_level][i].value;
						texture->SetBasicLod(gRender->lod_control->GetTextureLod());

						gDx9Device->SetTexture(curr_pixel_shader->texture_array[j].reg, texture->GetTexture());

						if (curr_pixel_shader->texture_array[j].reg == index)
							return true;
					}
				}
			}
			return true;
		}

#else
		for (U32 i = 0; i < texture_uniform[pixel_level].Size(); i++)
		{
			if (index > 0 && texture_uniform[pixel_level][i].uniform.reg != index)
				continue;

			sharedc_ptr(Texture) texture = texture_uniform[pixel_level][i].value;
			if(texture)
			{
				texture->SetBasicLod(gRender->lod_control->GetTextureLod());

				gDx9Device->SetTexture(texture_uniform[pixel_level][i].uniform.reg, texture->GetTexture());

				if (texture_uniform[pixel_level][i].uniform.reg == index)
					return true;
			}
			
		}
		return true;

#endif	
	}

	void Material::GetVertexShader(Identifier key)
	{
		CStrBuf<256> shader_key;
		shader_key.format("%s%s%s", "/shader/", key, ".vd9");
		sharedc_ptr(VertexShaderDx9)	shader = RESOURCE_LOAD(shader_key, false, VertexShaderDx9);
		vertex_shader.PushBack(shader);
	}

	void Material::GetPixelShader(Identifier key)
	{
		CStrBuf<256> shader_key;
		shader_key.format("%s%s%s", "/shader/", key, ".pd9");
		sharedc_ptr(PixelShaderDx9) shader = RESOURCE_LOAD(shader_key, false, PixelShaderDx9);
		pixel_shader.PushBack(shader);
	}

	void Material::Load(Core::Stream & stream)
	{
		CStrBuf<256> buf;
		U32 count = 0;
		U32 size = 0;
		U32 num = 0;
		stream.Read(&count, sizeof(U32));
		for (U32 j = 0; j < count; j++)
		{
			stream.Read(&size, sizeof(U32));
			buf.setlen(size);
			stream.Read(buf.buff(), size);
			GetVertexShader(buf);
		}

		stream.Read(&count, sizeof(U32));
		for (U32 j = 0; j < count; j++)
		{
			stream.Read(&size, sizeof(U32));
			buf.setlen(size);
			stream.Read(buf.buff(), size);
			GetPixelShader(buf);
		}

		stream.Read(&count, sizeof(U32));
		vertex_uniform.Resize(count);
		for (U32 i = 0; i < vertex_uniform.Size(); i++)
		{
			stream.Read(&count, sizeof(U32));
			for (U32 j = 0; j < count; j++)
			{
				U32 str_size = 0;
				stream.Read(&str_size, sizeof(U32));
				buf.setlen(str_size);
				stream.Read(buf.buff(), str_size);
				
				stream.Read(&num, sizeof(U32));
				Array<F32> value_array;
				for (U32 l = 0; l < num; l++)
				{
					F32 value = 0;
					stream.Read(&value, sizeof(U32));
					value_array.PushBack(value);
				}

				if (!vertex_shader.Size())
					continue;

				for (U32 k = 0; k < vertex_shader[i]->value_array.Size(); k++)
				{
					Uniform& uniform = vertex_shader[i]->value_array[k];

					if (uniform.type_name == Identifier(buf))
					{
						ValueUniformImpl u(uniform);
						u.type_name = uniform.type_name;
						vertex_uniform[i].PushBack(u);
						vertex_uniform[i].Back().value = value_array;
						break;
					}
				}
			}
		}

		stream.Read(&count, sizeof(U32));
		pixel_uniform.Resize(count);
		for (U32 i = 0; i < pixel_uniform.Size(); i++)
		{
			stream.Read(&count, sizeof(U32));
			for (U32 j = 0; j < count; j++)
			{
				U32 str_size = 0;
				stream.Read(&str_size, sizeof(U32));
				buf.setlen(str_size);
				stream.Read(buf.buff(), str_size);

				stream.Read(&num, sizeof(U32));
				Array<F32> value_array;
				for (U32 l = 0; l < num; l++)
				{
					F32 value = 0;
					stream.Read(&value, sizeof(U32));
					value_array.PushBack(value);
				}

				if (!pixel_shader.Size())
					continue;

				for (U32 k = 0; k < pixel_shader[i]->value_array.Size(); k++)
				{
					Uniform& uniform = pixel_shader[i]->value_array[k];

					if (uniform.type_name == Identifier(buf))
					{
						ValueUniformImpl u(uniform);
						u.type_name = uniform.type_name;
						pixel_uniform[i].PushBack(u);
						pixel_uniform[i].Back().value = value_array;
						break;
					}
				}
			}
		}

		stream.Read(&count,  sizeof(U32));
		texture_uniform.Resize(count);
		CStrBuf<256> texture_name;
		for (U32 i = 0; i < texture_uniform.Size(); i++)
		{
			stream.Read(&count, sizeof(U32));
			for (U32 j = 0; j < count; j++)
			{
				U32 str_size = 0;
				stream.Read(&str_size, sizeof(U32));
				buf.setlen(str_size);
				stream.Read(buf.buff(), str_size);

				stream.Read(&str_size, sizeof(U32));
				texture_name.setlen(str_size);
				stream.Read(texture_name.buff(), str_size);

				for (U32 j = 0; j < pixel_shader[i]->texture_array.Size(); j++)
				{
					Uniform & uniform = pixel_shader[i]->texture_array[j];

					if (uniform.type_name == buf)
					{
						TextureUniformImpl u(uniform);
						u.type_name = uniform.type_name;
						texture_uniform[i].PushBack(u);
						texture_uniform[i].Back().value = RESOURCE_LOAD(texture_name, true, Texture);
						break;
					}
				}
			}
		}
	}

	void Material::Save(Core::Stream & stream)
	{
		U32 size = 0;
		U32 count = vertex_shader.Size();
		stream.Write(&count, sizeof(U32));
		for (U32 j = 0; j < count; j++)
		{
			CStrBuf<256> buf;
			Path::GetFileNameWithoutExtension(buf, vertex_shader[j]->GetKey());
			size = buf.len();
			stream.Write(&size, sizeof(U32));
			stream.Write(buf.buff(), size);
		}

		count = pixel_shader.Size();
		stream.Write(&count, sizeof(U32));
		for (U32 j = 0; j < count; j++)
		{
			CStrBuf<256> buf;
			Path::GetFileNameWithoutExtension(buf, pixel_shader[j]->GetKey());
			size = buf.len();
			stream.Write(&size, sizeof(U32));
			stream.Write(buf.buff(), size);
		}

		size = vertex_uniform.Size();
		stream.Write(&size, sizeof(U32));
		for (U32 i = 0; i < vertex_uniform.Size(); i++)
		{
			count = vertex_uniform[i].Size();
			stream.Write(&count, sizeof(U32));
			for (U32 j = 0; j < count; j++)
			{
				ValueUniformImpl& uniform = vertex_uniform[i][j];
				size = uniform.uniform.type_name.Length();
				stream.Write(&size, sizeof(U32));
				stream.Write(uniform.uniform.type_name, size);
				size = uniform.value.Size();
				stream.Write(&size, sizeof(U32));
				stream.Write(uniform.value.GetData(), size * sizeof(F32));
			}
		}

		size = pixel_uniform.Size();
		stream.Write(&size, sizeof(U32));
		for (U32 i = 0; i < pixel_uniform.Size(); i++)
		{
			count = pixel_uniform[i].Size();
			stream.Write(&count, sizeof(U32));
			for (U32 j = 0; j < pixel_uniform[i].Size(); j++)
			{
				ValueUniformImpl& uniform = pixel_uniform[i][j];
				size = uniform.uniform.type_name.Length();
				stream.Write(&size, sizeof(U32));
				stream.Write(uniform.uniform.type_name, size);

				size = uniform.value.Size();
				stream.Write(&size, sizeof(U32));
				stream.Write(uniform.value.GetData(), size * sizeof(F32));
			}
		}

		size = texture_uniform.Size();
		stream.Write(&size, sizeof(U32));
		for (U32 i = 0; i < texture_uniform.Size(); i++)
		{
			count = texture_uniform[i].Size();
			stream.Write(&count, sizeof(U32));
			for (U32 j = 0; j < count; j++)
			{
				TextureUniformImpl& uniform = texture_uniform[i][j];
				size = uniform.uniform.type_name.Length();
				stream.Write(&size, sizeof(U32));
				stream.Write(uniform.uniform.type_name, size);
				size = uniform.value->GetKey().Length();
				stream.Write(&size, sizeof(U32));
				stream.Write(uniform.value->GetKey(), size);
			}
		}
	}

	void Material::Load(Lua::LuaState* L, String path)
	{
		for(U32 i = 0;; i++)
		{
			CStrBuf<128>	buf;
			buf.format("%s%d", "vertex_shader_lod_", i);
			L->GetField(-1, buf);
			if (String(L->ToString(-1)) == "")
			{
				L->Pop(1);
				break;
			}
			else
			{
				GetVertexShader(L->ToString(-1));
				L->Pop(1);
			}
		}

		for(U32 i = 0;; i++)
		{
			CStrBuf<128>	buf;
			buf.format("%s%d", "pixel_shader_lod_", i);
			L->GetField(-1, buf);
			if (String(L->ToString(-1)) == "")
			{
				L->Pop(1);
				break;
			}
			else
			{
				GetPixelShader(L->ToString(-1));
				L->Pop(1);
			}
		}

		L->PushNil();
		while(L->Next(-2))
		{
			vertex_uniform.Resize(vertex_shader.Size());
			pixel_uniform.Resize(pixel_shader.Size());
			texture_uniform.Resize(pixel_shader.Size());

			Identifier type_name(L->ToString(-2));
			String name = L->ToString(-1);

			Array<F32> value;
			if (L->IsTable(-1))
			{
				L->PushNil();
				while(L->Next(-2))
				{
					if (L->IsNumber(-1))
					{
						value.PushBack(L->ToNumber(-1));
						L->Pop(1);
					}
				}
			}
			else
			{
				if (L->IsNumber(-1))
					value.PushBack(L->ToNumber(-1));
			}

			for (U32 i = 0; i < pixel_shader.Size(); i++)
			{	
				for (U32 j = 0; j < pixel_shader[i]->texture_array.Size(); j++)
				{
					if (name == "")
						break;

					if (pixel_shader[i]->texture_array[j].type_name == type_name)
					{
						CStrBuf<256> key;
						Path::GetFilePath(key, path);

						TextureUniformImpl uniform(pixel_shader[i]->texture_array[j]);
						uniform.type_name = type_name;

						key.contract(name.Str());

						uniform.value = RESOURCE_LOAD(key, true, Texture);
						if (!uniform.value)
						{
							uniform.value = RESOURCE_LOAD("common/white_texture.tga", true, Texture);
						}
						texture_uniform[i].PushBack(uniform);
						continue;
					}
				}

				for (U32 i = 0; i < pixel_shader.Size(); i++)
				{
					if (!value.Size())
						break;

					for (U32 j = 0; j < pixel_shader[i]->value_array.Size(); j++)
					{
						if (pixel_shader[i]->value_array[j].type_name == type_name)
						{
							ValueUniformImpl uniform(pixel_shader[i]->value_array[j]);
							uniform.type_name = type_name;
							uniform.value = value;
							pixel_uniform[i].PushBack(uniform);
						}
					}
				}

				for (U32 i = 0; i < vertex_shader.Size(); i++)
				{
					if (!value.Size())
						break;

					for (U32 j = 0; j < vertex_shader[i]->value_array.Size(); j++)
					{
						if (vertex_shader[0]->value_array[j].type_name == type_name)
						{
							ValueUniformImpl uniform(vertex_shader[i]->value_array[j]);
							uniform.type_name = type_name;
							uniform.value = value;
							vertex_uniform[i].PushBack(uniform);
						}
					}
				}
			}
			L->Pop(1);
		}
		L->Pop(1);
	}
}