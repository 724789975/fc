namespace Client
{
	class DecalResource : public Resource
	{
	public:

		// constructor
		DecalResource();

		// destructor
		~DecalResource();

	public:
		// save data
		virtual bool SaveData(Core::Stream & stream);

		// load data
		virtual sharedc_ptr(Object) LoadData(Core::Stream & stream);

		// load data
		virtual sharedc_ptr(Object) BuildData();

		/// get version
		virtual short GetVersion();
		
		// unload data
		virtual void UnloadData();

		// on load data
		virtual bool OnLoadData(by_ptr(Object) obj);

		// material
		sharedc_ptr(Material)		material;

		// scale
		Core::Vector3				scale;

		// random rot
		bool						random_rot;

		// fade in
		F32							fade_in;

		// fade out
		F32							fade_out;

		// duration
		F32							duration;

		// texture col
		U32							texture_col;

		// texture row
		U32							texture_row;

		// bool
		bool						random_tex;


		Core::Array<Core::String>	DecalDependenceArray;

	};
	class SprayResource;
	class DecalManager;
	class Decal
	{
	public:
		friend class DecalManager;
		// constructor
		Decal();
		
		// destructor
		~Decal();

		// draw
		void Draw();

		// get 3 points
		void GetTriPoints(VertexDeclaration::StreamDecal *& v1,  VertexDeclaration::StreamDecal *& v2, VertexDeclaration::StreamDecal *& v3);

		// frustum
		Core::FrustumArea	frustum;

		// clip plane
		Core::Vector4		clip_plane[6];

		//start
		U32					start;

		// count
		int					count;

		// index
		int index;

		// left time
		F32 left_time;

		// aabb
		Core::AxisAlignedBox	aabb;

		// decal resource
		sharedc_ptr(DecalResource)	decal_resource;

		// manager
		DecalManager * manager;
	};

	class DecalManager
	{
	public:
		class DecalImpl
		{
		#define MAX_DECAL_COUNT 128
		public:
			// constructor
			DecalImpl()
				:decal_max_size(MAX_DECAL_COUNT)
			{
			}

			// destructor
			~DecalImpl()
			{
			}
		
			// deque decals
			Core::Deque<Decal> deque_decals;

			// deque vertexs
			Core::Deque<VertexDeclaration::StreamDecal> deque_vertexs;

			// decal max size
			U32 decal_max_size;
		};

	public:
		// constructor
		DecalManager();

		// destructor
		~DecalManager();

		// add decal
		void AddDecal(const Core::String key, const Core::Vector3 & target, const Core::Vector3 & normal, const Core::Vector3 & size, const F32 duration);

		// clear
		void Clear();

		// update
		void Update(F32 frametime);

		void LoadDecalList(const Core::String& path);

		// draw
		void Draw(F32 frametime);
	public:
		// decal type
		Core::HashSet<Core::Identifier, U32>			decal_types;

		// decal resource
		Core::HashSet<Core::Identifier, sharedc_ptr(DecalResource)>	decal_resources;

		Core::HashSet<Core::Identifier, sharedc_ptr(SprayResource)>  spray_resources;
			
		// decals
		Core::Array<DecalImpl>							decalimpls;
	};
}