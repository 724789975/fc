namespace Client
{
	class Parameter
	{
	public:
		// name
		SIMPLE_PDE_ATTRIBUTE_RW(Name, Core::Identifier);
	};

	// int
	class ParameterInt : public Parameter
	{
	public:
		DECLARE_PDE_ATTRIBUTE_RW(Constant,	int);
		DECLARE_PDE_ATTRIBUTE_RW(Random,	F32);
		DECLARE_PDE_ATTRIBUTE_RW(EmitLifeSpline,tempc_ptr(Core::PdeSplineF32));
		DECLARE_PDE_ATTRIBUTE_RW(ParticleLifeSpline,tempc_ptr(Core::PdeSplineF32));

		// constructor
		ParameterInt();

		// destructor
		~ParameterInt();

		//get initial value
		int GetInitial();

		// get value
		int GetEmitLifeValue(int v, F32 t);
		int GetParticleLifeValue(int v, F32 t);

		// save data
		void SaveData(Core::Stream& stream);

		// load data
		void LoadData(Core::Stream& stream);

		// save to stream
		Core::String SaveToStream(U32 pos);

		// constant
		int								m_Constant;

		// random
		F32								m_Random;

		// spline
		sharedc_ptr(Core::PdeSplineF32)	m_EmitLifeSpline;
		sharedc_ptr(Core::PdeSplineF32)	m_ParticleLifeSpline;
	};

	// float
	class ParameterFloat : public Parameter
	{
	public:
		DECLARE_PDE_ATTRIBUTE_RW(Constant,			F32);
		DECLARE_PDE_ATTRIBUTE_RW(Random,			F32);
		DECLARE_PDE_ATTRIBUTE_RW(EmitLifeSpline,	tempc_ptr(Core::PdeSplineF32));
		DECLARE_PDE_ATTRIBUTE_RW(ParticleLifeSpline,tempc_ptr(Core::PdeSplineF32));

		// constructor
		ParameterFloat();

		// destructor
		~ParameterFloat();

		//get initial value
		F32 GetInitial();

		// get value
		F32 GetEmitLifeValue(F32 v, F32 t);
		F32 GetParticleLifeValue(F32 v, F32 t);

		// save data
		void SaveData(Core::Stream& stream);

		// load data
		void LoadData(Core::Stream& stream);

		// save to stream
		Core::String SaveToStream(U32 pos);


	private:
		// constant
		F32								m_Constant;

		// random
		F32								m_Random;

		// spline
		sharedc_ptr(Core::PdeSplineF32)	m_EmitLifeSpline;
		sharedc_ptr(Core::PdeSplineF32)	m_ParticleLifeSpline;
	};

	// float2
	class ParameterFloat2 : public Parameter
	{
	public:
		DECLARE_PDE_ATTRIBUTE_RW(Constant,				Core::Vector2&);
		DECLARE_PDE_ATTRIBUTE_RW(Random,				Core::Vector2&);
		DECLARE_PDE_ATTRIBUTE_RW(EmitLifeSplineX,		tempc_ptr(Core::PdeSplineF32));
		DECLARE_PDE_ATTRIBUTE_RW(EmitLifeSplineY,		tempc_ptr(Core::PdeSplineF32));
		DECLARE_PDE_ATTRIBUTE_RW(ParticleLifeSplineX,	tempc_ptr(Core::PdeSplineF32));
		DECLARE_PDE_ATTRIBUTE_RW(ParticleLifeSplineY,	tempc_ptr(Core::PdeSplineF32));

		// constuctor
		ParameterFloat2();

		// destructor
		~ParameterFloat2();

		// get initial value
		Core::Vector2 GetInitial();

		// get value
		Core::Vector2 GetEmitLifeValue(Core::Vector2&, F32);
		Core::Vector2 GetParticleLifeValue(Core::Vector2&, F32);

		// save data
		void SaveData(Core::Stream& stream);

		// load data
		void LoadData(Core::Stream& stream);

		// save to stream
		Core::String SaveToStream(U32 pos);

		// constant
		Core::Vector2				m_Constant;

		// random
		Core::Vector2				m_Random;

		// spline
		sharedc_ptr(Core::PdeSplineF32)	m_EmitLifeSplineX;
		sharedc_ptr(Core::PdeSplineF32)	m_EmitLifeSplineY;
		sharedc_ptr(Core::PdeSplineF32)	m_ParticleLifeSplineX;
		sharedc_ptr(Core::PdeSplineF32)	m_ParticleLifeSplineY;

	};

	class ParameterFloat3 : public Parameter
	{
	public:
		DECLARE_PDE_ATTRIBUTE_RW(Constant,				Core::Vector3&);
		DECLARE_PDE_ATTRIBUTE_RW(Random,				Core::Vector3&);
		DECLARE_PDE_ATTRIBUTE_RW(EmitLifeSplineX,		tempc_ptr(Core::PdeSplineF32));
		DECLARE_PDE_ATTRIBUTE_RW(EmitLifeSplineY,		tempc_ptr(Core::PdeSplineF32));
		DECLARE_PDE_ATTRIBUTE_RW(EmitLifeSplineZ,		tempc_ptr(Core::PdeSplineF32));
		DECLARE_PDE_ATTRIBUTE_RW(ParticleLifeSplineX,	tempc_ptr(Core::PdeSplineF32));
		DECLARE_PDE_ATTRIBUTE_RW(ParticleLifeSplineY,	tempc_ptr(Core::PdeSplineF32));
		DECLARE_PDE_ATTRIBUTE_RW(ParticleLifeSplineZ,	tempc_ptr(Core::PdeSplineF32));

		// constuctor
		ParameterFloat3();

		// destructor
		~ParameterFloat3();

		// get initial value
		Core::Vector3 GetInitial();

		// get value
		Core::Vector3 GetEmitLifeValue(Core::Vector3& v, F32 t);
		Core::Vector3 GetParticleLifeValue(Core::Vector3& v, F32 t);

		// save data
		void SaveData(Core::Stream& stream);

		// load data
		void LoadData(Core::Stream& stream);

		// save to stream
		Core::String SaveToStream(U32 pos);

		// constant
		Core::Vector3				m_Constant;

		// random
		Core::Vector3				m_Random;

		// spline
		sharedc_ptr(Core::PdeSplineF32)	m_EmitLifeSplineX;
		sharedc_ptr(Core::PdeSplineF32)	m_EmitLifeSplineY;
		sharedc_ptr(Core::PdeSplineF32)	m_EmitLifeSplineZ;
		sharedc_ptr(Core::PdeSplineF32)	m_ParticleLifeSplineX;
		sharedc_ptr(Core::PdeSplineF32)	m_ParticleLifeSplineY;
		sharedc_ptr(Core::PdeSplineF32)	m_ParticleLifeSplineZ;

	};

	class ParameterColor3 : public Parameter
	{
	public:
		DECLARE_PDE_ATTRIBUTE_RW(Constant,			Core::Color3&);
		DECLARE_PDE_ATTRIBUTE_RW(Random,			F32);
		DECLARE_PDE_ATTRIBUTE_RW(EmitLifeSpline,	tempc_ptr(Core::PdeSplineF32));
		DECLARE_PDE_ATTRIBUTE_RW(ParticleLifeSpline,tempc_ptr(Core::PdeSplineF32));

		// constructor
		ParameterColor3();

		// destructor
		~ParameterColor3();

		// get value
		Core::Color3 GetEmitLifeValue(Core::Color3 v, F32 t);
		Core::Color3 GetParticleLifeValue(Core::Color3 v, F32 t);

		// save data
		void SaveData(Core::Stream& stream);

		// load data
		void LoadData(Core::Stream& stream);

		// save to stream
		Core::String SaveToStream(U32 pos);

		// get initial value
		Core::Color3 GetInitial();

		// constant
		Core::Color3				m_Constant;

		// random
		F32							m_Random;

		// spline
		sharedc_ptr(Core::PdeSplineF32)	m_EmitLifeSpline;
		sharedc_ptr(Core::PdeSplineF32)	m_ParticleLifeSpline;
	};
}
