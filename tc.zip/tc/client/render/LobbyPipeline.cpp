#include "pch.h"
using namespace Core;

String dir_name[5] = {"idle", "up", "right", "down", "left"};
String shake_name[5] = {"", "upshake", "rightshake", "downshake", "leftshake"};
namespace Client
{
	LobbyPipeline::LobbyPipeline()
	: initialized(false)
	, wide_screen(false)
	, team(0)
	, light_color(Vector4::kOne)
	, shadow_bias(0)
	, m_Intensity(Vector4::kZero)
	, anim_time(0)
	, time_left(0)
	, change_character_with_anim(false)
	, m_ShadowBias(0.006f)
	, action_state(kActionNone)
	, weapon_rotation(0)
	, cam_state(LobbyPipeline::kCameraNone)
	, last_camera_request(-1)
	, curr_cam_id(0xffffffff)
	, m_LobbyModule(L_WarZone)
	, m_OldLobbyModule(L_WarZone)
	, autorotate(false)
	, rotateangle(360)
	{

		character_rotation = Quaternion::kIdentity;

		show_avatar = false;
		show_weapon = false;
		avatar_dirty = false;
		weapon_dirty = false;
		old_screen_pos = Vector2::kZero;
		


		front_position =  Vector3::kZero;
		front_position_wide =  Vector3::kZero;
		weapon_position =  Vector3::kZero;

		for (U32 i = 0; i < 4; i++)
		{
			for (U32 j = 0; j < 2; j++)
			{
				character_light_para[i][j]= Vector4::kZero;
				weapon_light_para[i][j] = Vector4::kZero;
			}
		}
	}

	LobbyPipeline::~LobbyPipeline()
	{
		UnInitialize();


		preview_character_cache = NullPtr;
		character_info_cache = NullPtr;
		character_info = NullPtr;
	
	}

	void LobbyPipeline::LoadParticle(Core::Identifier& particle)
	{
		bg_particle = ptr_new ParticleSystem(particle, false);
		if (bg_particle)
		{
			bg_particle->SetPosition(Vector3::kZero);
			bg_particle->SetRotation(Quaternion::kIdentity);
			bg_particle->Reset();
		}
	}

	void LobbyPipeline::Initialize()
	{
		if (initialized)
			return;

		loading_particle = ptr_new ParticleSystem("ui_loading", true);
		loading_particle->Reset();

		gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_WEAPONROT, Matrix44::kIdentity);

		other_equip_map = ptr_new RenderTexture;
		other_equip_map->CreateRenderTexture(469, 549, 1, D3DUSAGE_RENDERTARGET, D3DFMT_A8R8G8B8);
		other_equip_map->CreateDepthStencil(D3DFMT_D24S8, true);

		light_depth = ptr_new RenderTexture;
		light_depth->CreateRenderTexture(2048, 2048, 1, D3DUSAGE_RENDERTARGET, D3DFMT_R32F);
		light_depth_ds = ptr_new RenderTexture;
		if (gDx9Device->ds_as_tex)
			light_depth_ds->CreateRenderTexture(2048, 2048, 1, D3DUSAGE_DEPTHSTENCIL, D3DFMT_D24S8);
		else
			light_depth->CreateDepthStencil(D3DFMT_D24S8, true);

		one_map = ptr_new RenderTexture;
		one_map->CreateRenderTexture(1, 1, 1, D3DUSAGE_RENDERTARGET, D3DFMT_A8R8G8B8, true);

		shadow_vs = RESOURCE_LOAD("/shader/shadow_vs.vd9", true, VertexShaderDx9);
		if (gDx9Device->ds_as_tex)
			shadow_ps = RESOURCE_LOAD("/shader/shadow_pcf_ds.pd9", true, PixelShaderDx9);
		else
			shadow_ps = RESOURCE_LOAD("/shader/shadow_pcf.pd9", true, PixelShaderDx9);

		shadow_dither = RESOURCE_LOAD("/common/DitherShadow.dds", true, Texture);
		shine_map = RESOURCE_LOAD("/common/shine.dds", true, Texture);

		white_texture = RESOURCE_LOAD("/common/white_texture.tga", true, Texture);
		black_texture = RESOURCE_LOAD("/common/black_texture.tga", true, Texture);


		shadow_map = ptr_new RenderTexture;
		shadow_map->CreateRenderTexture(1, 1, 1, D3DUSAGE_RENDERTARGET, D3DFMT_A8R8G8B8, true);
		shadow_map->CreateDepthStencil(D3DFMT_D24S8, true);

		pick_target = ptr_new RenderTexture;
		pick_target->CreateRenderTexture(0.5, 0.5, 1, D3DUSAGE_RENDERTARGET, D3DFMT_A8R8G8B8, 0.5f);

		pick_out_color = ptr_new RenderTarget;
		pick_out_color->CreateRenderTarget(1, 1, D3DFMT_A8R8G8B8, false, true);

		screen_downsample_rt = ptr_new RenderTarget;
		screen_downsample_rt->CreateRenderTarget(1, 1, D3DFMT_A8R8G8B8, true, false, 1);

		screen_downsample_map = ptr_new RenderTexture;
		screen_downsample_map->CreateRenderTexture(768, 768, 1, D3DUSAGE_RENDERTARGET, D3DFMT_A8R8G8B8, 0);


		sharedc_ptr(ScriptLua) lua = RESOURCE_LOAD("/mesh/scene/levellobby/script.lua", false, ScriptLua);
		if (lua)
		{
			Lua::LuaState * L = Lua::LuaState::NewState();
			L->OpenLibs();
			if (L->LoadBuffer(lua->GetBuffer(), lua->GetSize(), "/lobbylevel/lobbylevel.lua") == 0)
			{
				L->NewTable();
				L->GetGlobal("os");
				L->SetField(-2, "os");	
				L->GetGlobal("math");
				L->SetField(-2, "math");
				L->PushPtr(PDE_TYPE_OF(Vector3)->GetConstructor());
				L->SetField(-2, "Vector3");
				L->PushPtr(PDE_TYPE_OF(Vector4)->GetConstructor());
				L->SetField(-2, "Vector4");
				L->PushPtr(ptr_static_cast<LobbyPipeline>(this));
				L->SetField(-2, "lg");
				L->SetFenv(-2);

				if (L->DoCall(0, 0))
				{				
					const char *msg = L->ToString(-1);
					if (msg) Console.WriteLine(msg);
					L->Pop(1);
				}
			}
			else
			{
				const char *msg = L->ToString(-1);
				if (msg) Console.WriteLine(msg);
				L->Pop(1);
			}
			L->Close();
		}
	

		character_info = ptr_new CharacterInfo;
		preview_character = ptr_new Character;	
		preview_character_cache = ptr_new Character;
		preview_character->SetCharacterInfo(character_info);
	

		character_rotation = Quaternion(Vector3(0, 1, 0), PI);
		preview_character->ready = true;
		preview_character->died = false;
		preview_character_cache->died = false;
		preview_character_cache->ready = true;
		avatar_dirty = false;
		weapon_dirty = true;
		old_screen_pos = Vector2::kZero;
		show_weapon = true;
		show_avatar = false;
		preview_character->SetPosition(front_position);

	

		wide_screen = gGame->camera->wide_screen_mode;

		screen_vs		= RESOURCE_LOAD("/shader/screen_vs.vd9", true, Shader);
		screen_ps		= RESOURCE_LOAD("/shader/quad_ps.pd9", true, Shader);
		depth_ps		= RESOURCE_LOAD("/shader/depth_ps.pd9", true, Shader);
		gaussian_h		= RESOURCE_LOAD("/shader/gaussian_h.pd9", true, Shader);
		gaussian_w		= RESOURCE_LOAD("/shader/gaussian_w.pd9", true, Shader);
		down_sample4_ps = RESOURCE_LOAD("/shader/downsampling4.pd9", true, Shader);
		blend_ps		= RESOURCE_LOAD("/shader/screen_blend.pd9", true, Shader);
		pick_ps			= RESOURCE_LOAD("/shader/pick_ps.pd9", true, Shader);
		pick_out_vs		= RESOURCE_LOAD("/shader/lc_main.vd9", true, Shader);
		pick_out_ps		= RESOURCE_LOAD("/shader/pick_out_ps.pd9", true, Shader);
		one_ps			= RESOURCE_LOAD("/shader/one_ps.pd9", true, Shader);
		edge_ps			= RESOURCE_LOAD("/shader/skin_edge.pd9", true, Shader);

		gGame->camera->position = Vector3(0, 0.f, 50.f) / 100.f;
		//gGame->camera->rotation = Quaternion(Quaternion::kIdentity);
		gGame->camera->rotation = Quaternion(Vector3(1, 0, 0), -5.f * DEG2RAD);
		gGame->camera->fov = 55;
		gGame->camera->target_fov = 55;

		modify_weapon_camera = ptr_new Camera;
		modify_weapon_camera->position = gGame->camera->position;
		modify_weapon_camera->rotation= gGame->camera->rotation;
		modify_weapon_camera->last_position = gGame->camera->last_position;
		modify_weapon_camera->zoom = gGame->camera->zoom;
		modify_weapon_camera->aspect = gGame->camera->aspect;
		//modify_weapon_camera->fov = gGame->camera->fov;
		modify_weapon_camera->fov = 60;
		//modify_weapon_camera->target_fov = gGame->camera->target_fov;
		modify_weapon_camera->target_fov = 60;
		modify_weapon_camera->wide_screen_mode= gGame->camera->wide_screen_mode;
		modify_weapon_camera->lock_camera = gGame->camera->lock_camera;
		modify_weapon_camera->frustum = gGame->camera->frustum;

		lobby_state = LobbyPipeline::kAvatarPreview;
		curr_cam_id = 0xffffffff;

		initialized = true;
	}

	void LobbyPipeline::UnInitialize()
	{
		bg_texture = NullPtr;
		bg_particle = NullPtr;
		screen_vs = NullPtr;
		screen_ps = NullPtr;
		modify_weapon_camera = NullPtr;
		light_depth = NullPtr;
		light_depth_ds = NullPtr;
		shadow_vs = NullPtr;
		shadow_ps = NullPtr;
		shadow_dither = NullPtr;
		shadow_map = NullPtr;
		pick_target = NullPtr;
		pick_out_color = NullPtr;
		screen_downsample_rt = NullPtr;
		screen_downsample_map = NullPtr;
		blend_ps = NullPtr;
		cam_skeleton = NullPtr;
		animation = NullPtr;
		source_node = NullPtr;
		for (U32 i = 0; i < 6; i++)
			cam_anim_set[i] = NullPtr;
		cam_pose = NullPtr;
		down_sample4_ps = NullPtr;
		gaussian_h = NullPtr;
		gaussian_w = NullPtr;
		depth_ps = NullPtr;
		pick_ps = NullPtr;
		pick_out_vs = NullPtr;
		pick_out_ps = NullPtr;
		one_ps = NullPtr;
		edge_ps = NullPtr;


		preview_character = NullPtr;
		preview_character_cache = NullPtr;

		weapon_info = NullPtr;
		weapon_info_cache = NullPtr;

		side_particle = NullPtr;
		

		loading_particle = NullPtr;
		initialized = false;
	}

	void LobbyPipeline::SetLobbyState(S32 state)
	{
		if (!initialized)
			return;

		if (state == 0 && state != lobby_state)
		{
			lobby_state = LobbyPipeline::kAvatarPreview;
			weapon_position = Vector3::kMaximal;
			SetWeaponCamera(0, true);
			cam_state = kCameraNone;

		
			if (show_avatar)
			{
				preview_character->SetCharacterInfo(character_info);
				preview_character->Update(0);
				preview_character_cache->SetCharacterInfo(character_info_cache);
				preview_character_cache->Update(0);
			}
			if (show_weapon)
			{
				preview_character->SetWeapon(0, weapon_info);
				preview_character->SelectWeapon(0, true);
				weapon_info_cache = weapon_info;
				preview_character_cache->SetWeapon(0, weapon_info_cache);
				preview_character_cache->SelectWeapon(0, true);
				if (preview_character_cache->GetWeapon(0))
					preview_character_cache->GetWeapon(0)->Update(0);
			}
			
		}
		else if (state == 1 && state != lobby_state)
		{
			if (lobby_state != LobbyPipeline::kWeaponModify)
				weapon_position = Vector3::kMaximal;

			if (lobby_state == LobbyPipeline::kAvatarPreview)
			{

				if (weapon_dirty)
				{
					sharedc_ptr(WeaponInfo) temp = weapon_info;
					weapon_info = weapon_info_cache;
					weapon_info_cache = temp;
				}
				
			}

			lobby_state = LobbyPipeline::kWeaponPreview;
			weapon_rotation = 0;
			SetWeaponCamera(0);
		}
		else if (state == 2 && state != lobby_state)
		{
			if (lobby_state != LobbyPipeline::kWeaponPreview)
				weapon_position = Vector3::kMaximal;

			lobby_state = LobbyPipeline::kWeaponModify;
			weapon_rotation = 0;
			SetWeaponCamera(0);
		}
	}


	void LobbyPipeline::Update(F32 frame_time)
	{
		if (!initialized)
			return;

		UpdateCharacter(frame_time);
		UpdateWeapon(frame_time);
		UpdateCamera(frame_time);

		if (bg_particle)
		{
			bg_particle->Update(frame_time);
		}
	
		if (loading_particle)
			loading_particle->Update(frame_time);

		//for (U32 i = 0; i < 2; i++)
		//	if (side_particle[i])
		//		side_particle[i]->Update(frame_time);
	}

	void LobbyPipeline::Draw(F32 frametime)
	{
		PROFILE("LobbyPipeline::Draw");

		if (!initialized)
			return;

		gDx9Device->SetRenderTarget(0, gDx9Device->render_target);
		gDx9Device->SetDepthStencilSurface(gDx9Device->depth_stencil);
		
		gDx9Device->SetDefaultStates();

		gGame->camera->UpdateAspect(gGame->screen->GetSize());
		modify_weapon_camera->UpdateAspect(gGame->screen->GetSize());
		if ((wide_screen != gGame->camera->wide_screen_mode) || (!bg_texture) || m_LobbyModule != m_OldLobbyModule)
		{
			m_OldLobbyModule = m_LobbyModule;
			wide_screen = gGame->camera->wide_screen_mode;

			if (wide_screen)
			{
				switch(m_LobbyModule)
				{
				case L_WarZone:
				default:
					{
						bg_texture = RESOURCE_LOAD_NEW("LobbyUI/lb_bg_wallpaper01.dds", false, Texture);
					}
					break;
				}
			}				
			else
			{
				switch(m_LobbyModule)
				{
				case L_WarZone:
				default:
					{
						bg_texture = RESOURCE_LOAD_NEW("LobbyUI/lb_bg_wallpaper02.dds", false, Texture);
					}
					break;
				}
			}
		}

		gDx9Device->SetRestore();
		gDx9Device->SetRenderState(D3DRS_ZFUNC, D3DCMP_LESSEQUAL);
		gDx9Device->SetRenderState(D3DRS_CULLMODE, D3DCULL_CW);
		gDx9Device->SetRenderState(D3DRS_ZENABLE, TRUE);
		gDx9Device->SetRenderState(D3DRS_ZWRITEENABLE, TRUE);
		gDx9Device->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);

		Vector4 time(frametime, Task::GetTotalTime(), 0, 0);
		gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_TIME, &time.x);
		gDx9Device->SetPixelShaderConstantF(PS_CONSTANT_TIME, &time.x);

		Vector3 vertexs[4] = 
		{
			Vector3(-1,  1, 1),
			Vector3(-1, -1, 1),
			Vector3( 1,  1, 1),
			Vector3( 1, -1, 1),
		};

		Vector4 ViewPos(gGame->camera->position.x, gGame->camera->position.y, gGame->camera->position.z, 1.f);
		gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_VIEWPOS, &ViewPos.x);
		gDx9Device->SetPixelShaderConstantF(PS_CONSTANT_VIEWPOS, &ViewPos.x);

		gDx9Device->SetPixelShaderConstantF(PS_CONSTANT_SUNDIRECTION,	&m_SunDirection.x);
		gDx9Device->SetPixelShaderConstantF(PS_CONSTANT_FOGPARAMETER,	&m_FogPara.x);
		gDx9Device->SetPixelShaderConstantF(PS_CONSTANT_FOGCOLOR,		&m_FogColor.x);
		gDx9Device->SetPixelShaderConstantF(PS_CONSTANT_FOGYPARAMETER,	&m_YFogPara.x);
		gDx9Device->SetPixelShaderConstantF(PS_CONSTANT_FOGYCOLOR,		&m_YFogColor.x);
		gDx9Device->SetPixelShaderConstantF(PS_CONSTANT_INTENSITY,		&m_Intensity.x);
		float specular_multiple = 1.f;
		gDx9Device->SetPixelShaderConstantF(PS_CONSTANT_SPECULARMULTIPLE, &specular_multiple);

		Vector4 left_hand(1.f, 1.f, 1.f, 1.f);
		gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_LEFTHAND, &left_hand.x);
		gDx9Device->SetPixelShaderConstantF(PS_CONSTANT_LEFTHAND, &left_hand.x);

		gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_WORLD, Matrix44::kIdentity);
		gDx9Device->SetPixelShaderConstantF(PS_CONSTANT_WORLD, Matrix44::kIdentity);

		Matrix44 view, proj;
		gGame->camera->CalculateViewProjectionMatrix(view, proj);
		gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_VIEWPROJ, view * proj);
		Matrix44 invview;
		invview = view;
		invview.Inverse();

		Vector4 CameraInfo;
		CameraInfo.x = gGame->camera->GetNear();
		CameraInfo.y = gGame->camera->GetFar();
		CameraInfo.z = gGame->screen->GetSize().x;
		CameraInfo.w = gGame->screen->GetSize().y;

		gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_CAMERAINFO, &CameraInfo.x);
		gDx9Device->SetPixelShaderConstantF(PS_CONSTANT_CAMERAINFO, &CameraInfo.x);

		// draw bg
		gDx9Device->SetVertexDeclaration(VD::GetVertexDeclaration(VertexDeclaration::kPosition));
		if (screen_vs)
			screen_vs->SetShader();
		if (screen_ps)
			screen_ps->SetShader();

		if (bg_texture && bg_texture->IsReady())
			gDx9Device->SetTexture(COLOR_MAP, bg_texture->GetTexture());
		else if (black_texture)
			gDx9Device->SetTexture(COLOR_MAP, black_texture->GetTexture());
		gDx9Device->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP, 2, vertexs, VD::GetVertexDeclarationStride(VertexDeclaration::kPosition));

		// bg particle
		if (bg_particle)
		{
			bg_particle->Draw();
		}
		gDx9Device->SetRenderState(D3DRS_CULLMODE, D3DCULL_CW);
		gDx9Device->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);
		gDx9Device->SetRenderState(D3DRS_ZWRITEENABLE, TRUE);

		// draw shadow
		Vector4 shadow_map_size(2048, 2048, 1.f / 2048.f, 0.5f / 2048.f);
		gDx9Device->SetPixelShaderConstantF(PS_CONSTANT_SHADOWMAPSIZE, &shadow_map_size.x);
		gDx9Device->SetTexture(DITHER_SHADOW_MAP, shadow_dither->GetTexture());
		gDx9Device->SetRenderTarget(0, shadow_map->GetSurface());
		gDx9Device->SetDepthStencilSurface(shadow_map->GetDepthStencilSurface());
		gDx9Device->Clear(0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, 0, 1.f, 0);
		gDx9Device->SetPixelShaderConstantF(PS_CONSTANT_SHADOWDIRECTION, &m_ShadowDirection.x);
		if (black_texture)
			gDx9Device->SetTexture(EDGE_MAP, black_texture->GetTexture());

		gDx9Device->Clear(0, NULL, D3DCLEAR_ZBUFFER, 0, 1.f, 0);
	
	}

	void LobbyPipeline::DrawCharacter(F32 frametime,by_ptr(RenderTexture) rendertexture)
	{
		PROFILE("LobbyPipeline::DrawCharacter");

		if (!initialized)
			return;

		
		gDx9Device->SetRenderTarget(0, gDx9Device->render_target);
		gDx9Device->SetDepthStencilSurface(gDx9Device->depth_stencil);

		gDx9Device->SetDefaultStates();

		gGame->camera->UpdateAspect(Vector2(rendertexture->GetWidth(),	rendertexture->GetHeight()));//gGame->screen->GetSize()
		

		gDx9Device->SetRestore();
		gDx9Device->SetRenderState(D3DRS_ZFUNC, D3DCMP_LESSEQUAL);
		gDx9Device->SetRenderState(D3DRS_CULLMODE, D3DCULL_CW);
		gDx9Device->SetRenderState(D3DRS_ZENABLE, TRUE);
		gDx9Device->SetRenderState(D3DRS_ZWRITEENABLE, TRUE);
		gDx9Device->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);


		Vector3 vertexs[4] = 
		{
			Vector3(-1,  1, 1),
			Vector3(-1, -1, 1),
			Vector3( 1,  1, 1),
			Vector3( 1, -1, 1),
		};

		Vector4 ViewPos(gGame->camera->position.x, gGame->camera->position.y, gGame->camera->position.z, 1.f);
		gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_VIEWPOS, &ViewPos.x);
		gDx9Device->SetPixelShaderConstantF(PS_CONSTANT_VIEWPOS, &ViewPos.x);

		Matrix44 view, proj;
		gGame->camera->CalculateViewProjectionMatrix(view, proj);
		gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_VIEWPROJ, view * proj);
		Matrix44 invview;
		invview = view;
		
		Vector4 CameraInfo;
		CameraInfo.x = gGame->camera->GetNear();
		CameraInfo.y = gGame->camera->GetFar();
		CameraInfo.z = gGame->screen->GetSize().x;
		CameraInfo.w = gGame->screen->GetSize().y;

		gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_CAMERAINFO, &CameraInfo.x);
		gDx9Device->SetPixelShaderConstantF(PS_CONSTANT_CAMERAINFO, &CameraInfo.x);
		
		if (m_LobbyModule == L_Characters || m_LobbyModule == L_ShoppingMall || m_LobbyModule == L_PersonalInfo || m_LobbyModule == L_TopList)
		{
			if (show_avatar && preview_character->IsReady() )
			{
				preview_character->SetLookDir(character_rotation);
				//preview_character->OnRender(0);
				AxisAlignedBox aabb = preview_character->GetThirdPerson().GetWorldAABB();

				gDx9Device->SetRenderState(D3DRS_SLOPESCALEDEPTHBIAS, 0);
				gDx9Device->SetTexture(SHADOW_AO_MAP, shadow_map->GetTexture());
				gDx9Device->SetRenderState(D3DRS_ALPHABLENDENABLE, false);
				gDx9Device->SetRenderTarget(0,rendertexture->GetSurface());//gDx9Device->render_target
				gDx9Device->SetDepthStencilSurface(rendertexture->GetDepthStencilSurface());
				gDx9Device->Clear(0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, 0, 1.f, 0);
				
				Vector4 v[8];
				for (U32 i = 0; i < 4; i++)
				{
					v[i * 2    ] = character_light_para[i][0] + Vector4(preview_character->GetPosition(), 1);
					v[i * 2 + 1] = character_light_para[i][1];
				}
				gDx9Device->SetPixelShaderConstantF(PS_CONSTANT_POINTLIGHT, &v[0].x);
				gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_WEAPONROT, Matrix44::kIdentity);
				preview_character->OnRender(frametime);
				preview_character->Draw(Primitive::kScene, true);
				
			}
		
			gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_WORLD, Matrix44::kIdentity);
		}

		gDx9Device->Clear(0, NULL, D3DCLEAR_ZBUFFER, 0, 1.f, 0);

		if (show_avatar && (avatar_dirty || (weapon_dirty && show_weapon)))
		{
			loading_particle->SetPosition(front_position + Vector3(0,1,0));//(preview_character->GetPosition());
			loading_particle->Update(0);
			loading_particle->Draw();
		}
		//D3DXSaveTextureToFileA("d://1.bmp", D3DXIFF_BMP,rendertexture->GetTexture(), NULL );
	}

	void LobbyPipeline::SetWeaponPosition(Vector3 position)
	{
		if ((lobby_state == LobbyPipeline::kWeaponModify || lobby_state == LobbyPipeline::kWeaponPreview) && weapon_dirty)
			cache_weapon_position = position;
		else
			weapon_position = position;
	}

	

	void LobbyPipeline::SetAmbientIntensity(F32 v)
	{
		m_Intensity.x = v;
	}

	void LobbyPipeline::SetLightmapIntensity(F32 v)
	{
		m_Intensity.y = v;
	}


	void LobbyPipeline::SetShadowDirection(F32 x, F32 y, F32 z, F32 w)
	{
		Vector3 a(x, y, z);
		a.Normalize();
		m_ShadowDirection = Vector4(a, w);
	}

	void LobbyPipeline::SetSunDirection(F32 x, F32 y, F32 z)
	{
		m_SunDirection.x = x;
		m_SunDirection.y = y;
		m_SunDirection.z = z;
		m_SunDirection.Normalize();
	}

	void LobbyPipeline::SetModifyWeaponSunDir(F32 x, F32 y, F32 z)
	{
		m_ModifySunDir.x = x;
		m_ModifySunDir.y = y;
		m_ModifySunDir.z = z;
		m_ModifySunDir.Normalize();

	}

	void LobbyPipeline::SetFog(F32 i, F32 mind, F32 maxd, F32 r, F32 g, F32 b)
	{
		m_FogPara.x = i;
		m_FogPara.y = mind;
		m_FogPara.z = maxd;
		m_FogColor.x = r;
		m_FogColor.y = g;
		m_FogColor.z = b;
	}

	void LobbyPipeline::SetYFog(F32 i, F32 mind, F32 maxd, F32 r, F32 g, F32 b)
	{
		m_YFogPara.x = i;
		m_YFogPara.y = mind;
		m_YFogPara.z = maxd;
		m_YFogColor.x = r;
		m_YFogColor.y = g;
		m_YFogColor.z = b;
	}

	void LobbyPipeline::SetLightColor(F32 r, F32 g, F32 b)
	{
		light_color.r = r / 255.f;
		light_color.g = g / 255.f;
		light_color.b = b / 255.f;
		light_color.a = 1;
	}

	void LobbyPipeline::RotateCharacter()
	{
		autorotate = true;
		rotateangle = 360;
	}

	void LobbyPipeline::SetWeaponType(U32 side, int type)
	{
		if (!initialized)
			return;

		if (side > 1)
			return;

		sharedc_ptr(WeaponInfo) info = NullPtr;

		switch (type)
		{
		case kWeaponTypePistol:			info = ptr_new PistolInfo;			break;
		case kWeaponTypeSubMachineGun:	info = ptr_new SubMachineGunInfo;	break;
		case kWeaponTypeRifle:			info = ptr_new RifleInfo;			break;
		case kWeaponTypeSniperGun:		info = ptr_new SniperGunInfo;		break;
		case kWeaponTypeShotGun:		info = ptr_new ShotGunInfo;			break;
		case kWeaponTypeMiniGun:		info = ptr_new MiniGunInfo;			break;
		case kWeaponTypeKnife:			info = ptr_new KnifeInfo;			break;
		case kWeaponTypeGrenade:		info = ptr_new GrenadeInfo;			break;
		case kWeaponTypeFlash:			info = ptr_new FlashInfo;			break;
		case kWeaponTypeSmoke:			info = ptr_new SmokeInfo;			break;
		case kWeaponTypeSpecial:		info = ptr_new SpecialGrenadeInfo;	break;
		case kWeaponTypeBomb:			info = ptr_new BombInfo;			break;
		case kWeaponTypeDualPistol:		info = ptr_new DualPistolInfo;		break;
		case kWeaponTypeMeditNeedleGun: info = ptr_new LuncherInfo;			break;
		case kWeaponTypeLuncher:		info = ptr_new LuncherInfo;			break;
		case kWeaponTypeSignal:			info = ptr_new LuncherInfo;			break;
		case kWeaponTypeMiniMachineGun:	info = ptr_new MiniMachineGunInfo;	break;

		case kWeaponTypeCureGun:		info = ptr_new CureGunInfo;			break;
		case kWeaponTypeFlameGun:		info = ptr_new FlameGunInfo;		break;
		case kWeaponTypeDrum:			info = ptr_new DrumInfo;			break;
		case kWeaponTypeMilkbottle:		info = ptr_new MilkbottleInfo;		break;
		case kWeaponTypeEquipment:		info = ptr_new EquipmentInfo;		break;	
		case kWeaponTypeZombieGun:		info = ptr_new ZombieGunInfo;		break;
		case kWeaponTypeZombieCharge:	info = ptr_new ZombieChargeInfo;	break;
		case kWeaponTypeGunTowerBuilder:info = ptr_new GunTowerBuilderInfo;	break;
		case kWeaponTypeGunTowerBuilderPlus:info = ptr_new GunTowerBuilderPlusInfo;	break;
		}

		
		{
			if (lobby_state == LobbyPipeline::kAvatarPreview)
				weapon_info_cache = info;
			else
				weapon_info_modify_cache = info;

		}
	}

	void LobbyPipeline::SetWeaponColor(U32 side, byte color)
	{
		if (!initialized)
			return;

		if (side > 1)
		{
			return;
		}

		tempc_ptr(WeaponInfo) weapon = NullPtr;
		if (lobby_state == LobbyPipeline::kAvatarPreview)
		{
			weapon = weapon_info_cache;
			if (weapon)
			{
				weapon->color = color;
			}
			weapon_dirty = true;
		}
	}

	void LobbyPipeline::AddWeaponPart(U32 side, const Identifier& part)
	{
		if (!initialized)
			return;
		
		if (part.Length() <= 0)
			return;

		if (side > 1)
		{
			LogSystem.WriteLinef("%s, side = %d, which team?", part, side);
			return;
		}

		tempc_ptr(WeaponInfo) weapon = NullPtr;
		if (lobby_state == LobbyPipeline::kAvatarPreview)
		{
			weapon = weapon_info_cache;
			if (weapon)
			{
				weapon->AddPart(part);
			}
			weapon_dirty = true;
		}
	}

	//void LobbyPipeline::SetWeaponPartBlink(U32 side, const Identifier& part)
	//{
	//	if (!initialized)
	//		return;

	//	if (!part.Length())
	//		return;

	//	if (side > 1)
	//	{
	//		LogSystem.WriteLinef("%s, side = %d, which team?", part, side);
	//		return;
	//	}

	//	if (weapon_dirty[side])
	//	{
	//		if (weapon_info_modify_cache && preview_character_cache[side])
	//		{
	//			weapon_info_modify_cache->SetPartBlink(part);
	//		}
	//	}
	//	else
	//	{
	//		if (weapon_info_modify && preview_character[side])
	//		{
	//			weapon_info_modify->SetPartBlink(part);
	//		}
	//	}
	//}

	void LobbyPipeline::SetAvatarPart(U32 side, const Identifier& key)
	{
		if (!initialized)
			return;

		if (!key.Length())
			return;

		if (side > 1)
		{
			LogSystem.WriteLinef("%s, side = %d, which team?", key, side);
			return;
		}

		if (preview_character_cache && character_info_cache)
		{
			//character_info->AddPart(key);
			character_info_cache->AddPart(key);
			//preview_character->SetCharacterInfo(character_info);

			avatar_dirty = true;
		}
	}




	void LobbyPipeline::AvatarShow(U32 side,const Identifier& carrername)
	{	
		if (!initialized)
			return;

		if (side > 1)
			return;

		if (!preview_character)
			return;

		CStrBuf<256> path;

		character_info_cache = ptr_new CharacterInfo;
		preview_character_cache = ptr_new Character;
		preview_character_cache->died = false;
		preview_character_cache->ready = true;
		character_info_cache->team = side;

		if (character_info_cache)
		{
			character_info_cache->career_key = carrername;
			character_info->career_key = carrername;
		}

		autorotate = false;
		rotateangle = 360;
		
		show_avatar = true;

	}

	void LobbyPipeline::AvatarClear(U32 side)
	{
	
	}

	/*void LobbyPipeline::SetEquipChar(by_ptr(CharacterInfo) info)
	{
		if (!initialized)
			return;

		if (!info)
			return;

		
		U32 side = info->team;

		character_info_cache[side] = info;

		character_info[side]->first_person_skeleton = info->first_person_skeleton;
		character_info[side]->third_person_skeleton = info->third_person_skeleton;
		character_info[side]->first_person_animationset = info->first_person_animationset;
		character_info[side]->third_person_animationset = info->third_person_animationset;
		character_info[side]->character_id = info->character_id;
		character_info[side]->team = info->team;
		character_info[side]->mesh_set_third_person[0].Clear();

		preview_character[side]->SetCharacterInfo(character_info[side]);
		preview_character[side]->SetWeapon(0, NullPtr);
		preview_character[side]->SelectWeapon(0, true);
		avatar_dirty[side] = true;
		weapon_dirty[side] = true;

		preview_character_cache[side]->SetCharacterInfo(character_info_cache[side]);
		
	}*/

	void LobbyPipeline::UpdateCharacter(F32 frame_time)
	{
		if (lobby_state == LobbyPipeline::kAvatarPreview)
		{
		
			if(autorotate)
			{
				F32 angle = 360/5 * frame_time;
				rotateangle -= angle;
				if(rotateangle < 0)
				{
					angle = angle - rotateangle;
					rotateangle = 360;
					autorotate = false;
				}
				character_rotation *= Quaternion(Vector3(0, 1, 0), angle * DEG2RAD );
			}


			if(avatar_dirty && preview_character_cache)
			{
				ThirdPerson& third_person = preview_character_cache->GetThirdPerson();

				preview_character_cache->SetCharacterInfo(character_info_cache);
				//
				if(preview_character_cache->IsReady() && third_person.IsReady() && third_person.GetWeapon(0) && third_person.GetWeapon(0)->IsReady())
				{

				
					if(weapon_dirty)
					{
						preview_character_cache->SetWeapon(0, weapon_info_cache);
						preview_character_cache->SelectWeapon(0, true);
						preview_character_cache->SetPosition(front_position);
						tempc_ptr(WeaponBase)& weapon = third_person.GetWeapon(0);

						if (weapon && weapon->IsReady() && preview_character_cache->IsReady())
						{					
							weapon_info = weapon_info_cache;
							character_info = ptr_new CharacterInfo(*character_info_cache);
							character_info->career_key = character_info_cache->career_key;
							preview_character->SetCharacterInfo(character_info);
							preview_character->SetWeapon(0, weapon_info);
							preview_character->SelectWeapon(0, true);
							if (preview_character->GetThirdPerson().node_list_system)
								preview_character->GetThirdPerson().node_list_system->SetActiveNode("show");
							preview_character->Update(0);
							
							preview_character->OnRender(0);



							weapon_dirty = false;
							avatar_dirty = false;
						}
					}
					else
					{
						
						preview_character = preview_character_cache;
						if (third_person.node_list_system)
							third_person.node_list_system->SetActiveNode("show");
						preview_character->Update(frame_time);
						avatar_dirty = false;
					}
				}

			}


		}

		if (preview_character && show_avatar)
		{
			const ThirdPerson & third_person = preview_character->GetThirdPerson();



			//preview_character->Update(frame_time);


			//preview_character->OnRender(frame_time);
			preview_character->OnRender(frame_time);
			preview_character->Update(frame_time);
			//preview_character_cache->Update(frame_time);

		}

		
		

	}	

	void LobbyPipeline::UpdateWeapon(F32 frametime)
	{
	
		if (weapon_dirty)
		{
			ThirdPerson& third_person = preview_character_cache->GetThirdPerson();

			if (third_person.IsReady())
			{
				preview_character_cache->SetWeapon(0, weapon_info_cache);
				preview_character_cache->SelectWeapon(0, true);
				tempc_ptr(WeaponBase)& weapon = third_person.GetWeapon(0);

				if (weapon && weapon->IsReady() && preview_character_cache->IsReady())
				{
					if (lobby_state == LobbyPipeline::kAvatarPreview)
					{
						if (avatar_dirty)
							return;
						weapon_info = weapon_info_cache;
						
						preview_character->SetWeapon(0, weapon_info);
						preview_character->SelectWeapon(0, true);
						weapon_dirty = false;
					}
				}
			}
		}
	}

	void LobbyPipeline::UpdateCamera(F32 frametime)
	{
		//if (animation && animation->IsActionPlaying())
		//{
		//	animation->Update(frametime);
		//}	
		//else
		//{
		//	animation->node_data->SetSourceNode(source_node);
		//}

		//if (!animation->IsActionPlaying() && last_camera_request > 0)
		//{
		//	cam_state = static_cast<LobbyPipeline::CamState>(last_camera_request);
		//	control_node = animation->PlayAction(dir_name[cam_state], 0);
		//	last_camera_request = -1;
		//}

		//if ((lobby_state == LobbyPipeline::kWeaponPreview|| lobby_state == LobbyPipeline::kWeaponModify) && preview_character[team]->GetWeapon(0))
		//{
		//	preview_character[team]->GetWeapon(0)->UpdateMesh();
		//	preview_character[team]->Update(0);
		//	//preview_character[team]->OnRender(frametime);

		//	cam_pose = animation->GetPose();

		//	if (cam_pose)
		//	{
		//		const Transform& trans = cam_pose->GetJointLocalPose(joint_id);
		//		modify_weapon_camera->position = trans.position;
		//		modify_weapon_camera->rotation = trans.rotation;
		//	}
		//}

		if (action_state == LobbyPipeline::kRotWeaponBack)
		{
			if (weapon_rotation > 0)
			{
				weapon_rotation -= frametime * 128;
				if (weapon_rotation < 0)
				{
					weapon_rotation = 0;
					action_state = LobbyPipeline::kActionNone;
				}
			}
			else if (weapon_rotation < 0)
			{
				weapon_rotation += frametime * 128;
				if (weapon_rotation > 0)
				{
					weapon_rotation = 0;
					action_state = LobbyPipeline::kActionNone;
				}
			}
			else if (weapon_rotation == 0)
			{
				action_state = LobbyPipeline::kActionNone;
			}
		}
	}

}

namespace Client
{
	void LobbyPipeline::SetFrontPosition(Vector3 position, bool wide_mode)
	{
		if (wide_mode)
			front_position_wide = position;
		else
			front_position = position;
	}

	void LobbyPipeline::SetAnimTime(F32 time)
	{
		anim_time = time;
	}

	void LobbyPipeline::SetCameraPosition(Vector3 position)
	{
		if (gGame->camera)
			gGame->camera->position = position;
	}

	const Vector2 LobbyPipeline::GetCharacterPositionInScreen(U32 team)
	{
		if (team > 1)
			return Vector2::kZero;

		Vector3 p(preview_character->GetPosition());
		Vector4 pos(p.x, p.y + 1.75f, p.z, 1.f);

		Matrix44 view, proj;
		gGame->camera->CalculateViewProjectionMatrix(view, proj);

		Core::Transform(pos, pos, view * proj);
		pos /= pos.w;
		
		Vector2 out(pos.x, pos.y);
		out = out * Vector2(0.5f, -0.5f) + Vector2(0.5f, 0.5f);
		return out;
	}

	void LobbyPipeline::SetCharacterLight(const Vector4& p11, const Vector4& p12, const Vector4& p21, const Vector4& p22, const Vector4& p31, const Vector4& p32)
	{
		character_light_para[0][0] = p11;
		character_light_para[0][1] = p12;
		character_light_para[1][0] = p21;
		character_light_para[1][1] = p22;
		character_light_para[2][0] = p31;
		character_light_para[2][1] = p32;
		character_light_para[3][0] = character_light_para[3][1] = Vector4::kZero;
	}

	void LobbyPipeline::SetWeaponLight(const Vector4& p11, const Vector4& p12, const Vector4& p21, const Vector4& p22, const Vector4& p31, const Vector4& p32)
	{
		weapon_light_para[0][0] = p11;
		weapon_light_para[0][1] = p12;
		weapon_light_para[1][0] = p21;
		weapon_light_para[1][1] = p22;
		weapon_light_para[2][0] = p31;
		weapon_light_para[2][1] = p32;
		weapon_light_para[3][0] = weapon_light_para[3][1] = Vector4::kZero;
	}

	Vector3 LobbyPipeline::GetWeaponPosition()
	{
		return weapon_position;
	}

	void LobbyPipeline::SetWeaponCamera(U32 index, bool force)
	{
		if (!initialized)
			return;

		if (!animation->animation_set)
			return;

		if (force)
		{
			cam_state = static_cast<LobbyPipeline::CamState>(index);
			control_node = animation->PlayAction(dir_name[cam_state], 0);
			last_camera_request = -1;
			return;
		}

		if (cam_state == LobbyPipeline::kCameraNone)
		{
			cam_state = static_cast<LobbyPipeline::CamState>(index);
			control_node = animation->PlayAction(dir_name[cam_state], 0);
		}

		if (index == 5)
		{
			return;

			if (cam_state == 0)
				return;

			if (last_camera_request < 0)
			{
				cam_state = static_cast<LobbyPipeline::CamState>(cam_state % 10 + 20);
			}
			else
			{
				cam_state = static_cast<LobbyPipeline::CamState>(last_camera_request % 10 + 20);
				last_camera_request = -1;
			}
			control_node = animation->PlayAction(shake_name[cam_state % 10], 0);
			return;
		}

		if (index == cam_state || index == cam_state - 20)
			return;

		if (index == cam_state - 10)
		{
			control_node->SetPlayRate(1);
			cam_state = static_cast<LobbyPipeline::CamState>(index);
			return;
		}

		if (animation->IsActionPlaying())
		{
			if (cam_state > 20)
			{
				cam_state = static_cast<LobbyPipeline::CamState>(cam_state - 10);
				control_node = animation->PlayAction(dir_name[cam_state % 10], 0);
				control_node->SetPlayRate(-1);
				last_camera_request = index;
			}
			else if (cam_state > 10 && cam_state < 20)
			{
				last_camera_request = index;
			}
			else if (cam_state < 10)
			{
				control_node->SetPlayRate(-1);
				last_camera_request = index;
			}
		}
		else
		{
			cam_state = static_cast<LobbyPipeline::CamState>(cam_state % 10 + 10);
			control_node = animation->PlayAction(dir_name[cam_state % 10], 0);
			control_node->SetPlayRate(-1);
			last_camera_request = index;
		}

		if (index == LobbyPipeline::kCameraIdle)
		{
			cam_state = static_cast<LobbyPipeline::CamState>(index);
			last_camera_request = -1;
		}
	}

	void LobbyPipeline::SetCameraID(U32 id)
	{
		if (!initialized)
			return;

		if (id != curr_cam_id)
			curr_cam_id = id;
		else
			return;

		animation->SetAnimationSet(cam_anim_set[id]);
		joint_id = cam_skeleton->GetJointId("joint");

		if (cam_state == LobbyPipeline::kCameraNone)
		{
			control_node = animation->PlayAction(dir_name[cam_state], 0);
			if (control_node)
				cam_state = LobbyPipeline::kCameraIdle;
		}
	}

	
	LobbyPipeline::PickType LobbyPipeline::Pick(Vector2 pos, InputEventArgs::EventType type)
	{
		if (!initialized)
			return kPickNone;

		if (action_state == kChgCharacter)
			return kPickNone;


		if (type == InputEventArgs::kMouseUp)
		{
			switch (action_state)
			{
			case kChgCharacter:
				break;
			case kRotCharacterA:
			case kRotCharacterB:
				action_state = kActionNone;
				break;
			case kRotWeapon:
				action_state = kRotWeaponBack;
				break;
			default:
				break;
			}
			return kPickNone;
		}

		Vector2 size = gGame->screen->GetSize();
		Vector2 uv = pos / size;

		gDx9Device->BeginScene();
		gDx9Device->SetRenderTarget(0, pick_target->GetSurface());
		gDx9Device->SetDepthStencilSurface(NULL);
		gDx9Device->SetRenderState(D3DRS_ZENABLE, false);
		gDx9Device->Clear(0, NULL, D3DCLEAR_TARGET, 0x01010101, 1.f, 0);
		pick_ps->SetShader();

		if (lobby_state == LobbyPipeline::kWeaponPreview)
		{
			Vector4 color(0.f, 0.f, 1.f, 0.f);
			gDx9Device->SetPixelShaderConstantF(PS_CONSTANT_LIGHTCOLOR, &color.x);
			tempc_ptr(WeaponBase) weapon = preview_character->GetWeapon(0);
			if (weapon)
			{	
				Matrix44 w_view, w_proj;
				modify_weapon_camera->CalculateViewProjectionMatrix(w_view, w_proj);
				gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_VIEWPROJ, w_view * w_proj);
				weapon->Draw(Primitive::kEarlyZ, true);
			}
		}
		else if (lobby_state == LobbyPipeline::kAvatarPreview)
		{
			Matrix44 w_view, w_proj;
			gGame->camera->CalculateViewProjectionMatrix(w_view, w_proj);
			gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_VIEWPROJ, w_view * w_proj);


			Vector4 color = Vector4(0.f, 1.f, 0.f, 0.f);
			gDx9Device->SetPixelShaderConstantF(PS_CONSTANT_LIGHTCOLOR, &color.x);
			if (show_avatar)
				preview_character->GetThirdPerson().Draw(Primitive::kEarlyZ, true, false);
		}
		gDx9Device->SetTexture(PICK_MAP, pick_target->GetTexture());
		gDx9Device->SetRenderTarget(0, pick_out_color->GetSurface());
		gDx9Device->Clear(0, NULL, D3DCLEAR_TARGET, 0, 1.f, 0);
		pick_out_vs->SetShader();
		pick_out_ps->SetShader();
		GsPrimitive::SetVertexDeclaration("lc");
		F32 half = 0;
		gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_CHARID, &half);
		gDx9Device->SetPixelShaderConstantF(PS_CONSTANT_LIGHTCOLOR, &uv.x);
		gDx9Device->DrawPrimitiveUP(D3DPT_POINTLIST, 1, &uv.x, sizeof(F32));

		gDx9Device->SetRenderState(D3DRS_ZENABLE, true);

		D3DLOCKED_RECT lc;

		ARGB out_color;
		if (pick_out_color && pick_out_color->GetSurface() && SUCCEEDED(pick_out_color->GetSurface()->LockRect(&lc, NULL, 0)))
		{
			out_color = *(ARGB*)lc.pBits;
			HRESULT hr = pick_out_color->GetSurface()->UnlockRect();
		}
		gDx9Device->EndScene();

		if (out_color.g > 1)
		{
			if (type == InputEventArgs::kMouseDown)
			{
				action_state = kRotCharacterA;
				old_screen_pos = pos;
			}

			return kPickCharRot;
		}

		if (out_color.r > 1)
		{
			
			tempc_ptr(GameState) state = NullPtr;
			if (gGame)
				state = ptr_dynamic_cast<StateSelectCharacter>(gGame->machine.CurrentState());

			if (state)
			{
				if (type == InputEventArgs::kMouseDown)
				{
					action_state = kRotCharacterB;
					old_screen_pos = pos;
				}
				return kPickCharRot;
			}
			else
			{
				if (type == InputEventArgs::kMouseDown)
				{
					action_state = kChgCharacter;
					return kPickCharChged;
				}
				else
					return kPickCharChg;
			}
		}

		if (out_color.b > 1)
		{
			if (type == InputEventArgs::kMouseDown)
			{
				action_state = kRotWeapon;
				old_screen_pos = pos;
			}
			return kPickModifyWeapon;
		}

		return kPickNone;
	}
	
	void LobbyPipeline::BeginUpdateCursor()
	{
		old_screen_pos = Vector2::kZero;
	}
	
	void LobbyPipeline::UpdateCursor(Vector2 pos)
	{
		if (action_state == kChgCharacter)
		{
			return;
		}
		else if (action_state == kRotCharacterA)
		{
			if(old_screen_pos == Vector2::kZero)
			{
				old_screen_pos = pos;
			}
			else
			{
				character_rotation *= Quaternion(Vector3(0, 1, 0), (pos.x - old_screen_pos.x) * DEG2RAD * 0.25f);
				old_screen_pos = pos;
			}


			autorotate = false;
			rotateangle = 360;
			return;
		}
		else if (action_state == kRotWeapon)
		{			
			weapon_rotation += (pos.x - old_screen_pos.x) * 0.15f;

			if (weapon_rotation > 0 && weapon_rotation > 45.f)
				weapon_rotation = 45.f;
			
			if (weapon_rotation < 0 && weapon_rotation < -45.f)
				weapon_rotation = -45.f;

			old_screen_pos = pos;
			autorotate = false;
			rotateangle = 360;
		}
	}

	bool LobbyPipeline::GetInitialized()
	{
		return initialized;
	}

	by_ptr(RenderTexture) LobbyPipeline::GetOtherEquipMap()
	{
		return other_equip_map;
	}
}

DEFINE_PDE_TYPE_CLASS(Client::LobbyPipeline)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_METHOD(SetSunDirection);
		ADD_PDE_METHOD(SetShadowDirection);
		ADD_PDE_METHOD(SetModifyWeaponSunDir);
		ADD_PDE_METHOD(SetFog);
		ADD_PDE_METHOD(SetYFog);
		ADD_PDE_METHOD(SetLightmapIntensity);
		ADD_PDE_METHOD(SetAmbientIntensity);
		ADD_PDE_METHOD(SetWeaponType);
		ADD_PDE_METHOD(SetWeaponColor);
		ADD_PDE_METHOD(AddWeaponPart);
		//ADD_PDE_METHOD(SetWeaponPartBlink);
		ADD_PDE_METHOD(AvatarShow);
		ADD_PDE_METHOD(SetAvatarPart);
		//ADD_PDE_METHOD(SetEquipChar);
		ADD_PDE_METHOD(SetLightColor);
		ADD_PDE_METHOD(LoadParticle);
		ADD_PDE_METHOD(SetFrontPosition);
		//ADD_PDE_METHOD(ResetLookDir);
		ADD_PDE_METHOD(SetWeaponPosition);
		ADD_PDE_METHOD(SetAnimTime);
		ADD_PDE_METHOD(SetCameraPosition);
		ADD_PDE_METHOD(GetCharacterPositionInScreen);
		ADD_PDE_METHOD(SetCharacterLight);
		ADD_PDE_METHOD(SetWeaponLight);
		ADD_PDE_METHOD(SetLobbyState);
		ADD_PDE_METHOD(AvatarClear);
		ADD_PDE_METHOD(SetWeaponCamera);
		ADD_PDE_METHOD(SetCameraID);
		ADD_PDE_METHOD(GetLobbyModules);
		ADD_PDE_METHOD(SetLobbyModules);
		ADD_PDE_METHOD(RotateCharacter);
		ADD_PDE_PROPERTY_W(ShadowBias);
	}
};
REGISTER_PDE_TYPE(Client::LobbyPipeline);