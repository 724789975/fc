#include "pch.h"
using namespace Core;

namespace Client
{
	Light::Light()
		: position(Vector4::kZero)
		, color(Vector4::kZero)
		, enable(false)
		, dist(0)
	{}

	Light::~Light()
	{}

	void Light::SetPosition(const Core::Vector3& value)
	{
		position.x = value.x;
		position.y = value.y;
		position.z = value.z;
	}

	void Light::SetColor(const Core::Vector3& value)
	{
		color.x = value.x;
		color.y = value.y;
		color.z = value.z;
	}

	void Light::SetEnable(const bool value)
	{
		enable = value;
	}

	bool Light::GetEnable()
	{
		return enable;
	}

	void Light::Update(const F32 frametime)
	{
		life_time -= frametime;
		if (life_time < 0)
		{
			SetEnable(false);
		}
	}

	void Light::SetLife(const F32 life)
	{
		life_time = life;
	}
}

namespace Client
{
	void PointLight::SetAttenuation(const F32 value)
	{
		position.w = value;
	}

	void PointLight::SetIntensity(const F32 value)
	{
		color.w = value;
	}
}

namespace Client
{
	LightManager::LightManager()
	{
	}

	LightManager::~LightManager()
	{
	}

	void LightManager::Update(const F32 frametime)
	{
		LinkNode<PointLight>* node = point_lights.Front();

		while(node)
		{
			node->data.Update(frametime);
			if (!node->data.GetEnable())
			{
				LinkNode<PointLight>* node_next = node->GetNext();
				point_lights.Remove(node);
				SAFE_DELETE(node);
				node = node_next;
			}
			else
			{
				node = node->GetNext();
			}
		}
	}

	void LightManager::AddPointLight(const Vector3& position, const Vector3& color, const F32 attenuation, const F32 intensity, const F32 life)
	{
		point_lights.PushBack(new LinkNode<PointLight>);
		PointLight& light = point_lights.Back()->data;
		light.SetEnable(true);
		light.SetPosition(position);
		light.SetColor(color);
		light.SetAttenuation(attenuation);
		light.SetIntensity(intensity);
		light.SetLife(life);
	}

	void LightManager::SetLight(const U32 count, const Vector3& position)
	{
		Vector2 index(PS_CONSTANT_POINTLIGHT);

		Array<PointLight*> light_array;

		LinkNode<PointLight>* node = point_lights.Front();
		while(node)
		{
			Vector4 & light_pos = node->data.position;
			node->data.dist = Length(Vector3(light_pos.x, light_pos.y, light_pos.z) - position);
			light_array.PushBack(&node->data);
			node = node->GetNext();
		}

		struct SortFunc
		{
			bool operator()(PointLight *& left, PointLight *& right) const
			{
				if (left->dist < right->dist)
					return true;
				else return false;
			}
		};

		U32 c = Min(count, light_array.Size());
		if (c > 0)
			quick_sort(&light_array[0], light_array.Size(), SortFunc());

		for (U32 i = 0; i < 4; i++)
		{
			if (light_array.Size() > i && light_array[i] && light_array[i]->GetEnable() && i < count)
			{
				gDx9Device->SetPixelShaderConstantF(index.x++, &light_array[i]->position.x, 1);
				gDx9Device->SetPixelShaderConstantF(index.x++, &light_array[i]->color.x, 1);
			}
			else
			{
				gDx9Device->SetPixelShaderConstantF(index.x++, &Vector4::kZero.x, 1);
				gDx9Device->SetPixelShaderConstantF(index.x++, &Vector4::kZero.x, 1);
			}
		}

		F32 i = 4;
		gDx9Device->SetPixelShaderConstantF(PS_CONSTANT_LIGHTCOUNT, &i);
	}
}