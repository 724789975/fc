namespace Client
{
	class MeshBase;

	class D3DRender
	{
	public:
		enum GameState
		{
			kNotStart				= 0,

			kLoginEnter				= 1 << 1,
			kLoginLeave				= kLoginEnter | 1,
			kBalanceEnter			= 1 << 2,
			kBalanceLeave			= kBalanceEnter | 1,
			kLobbyEnter				= 1 << 3,
			kLobbyLeave				= kLobbyEnter | 1,
			kMovieEnter				= 1 << 4,
			kMovieLeave				= kMovieEnter | 1,
			kSelectCharacterEnter	= 1 << 5,
			kSelectCharacterLeave	= kSelectCharacterEnter | 1,
			kGameLoadingEnter		= 1 << 6,
			kGameLoadingLeave		= kGameLoadingEnter | 1,
			kGameEnter				= 1 << 7,
			kGameLeave				= kGameEnter | 1,

		};

		// contructor
		D3DRender();

		// desturctor
		~D3DRender();

		// set game state
		void SetGameState(GameState);

		// initialize
		void Initialize();

		// warm
		void Warm();

		// get lobby
		tempc_ptr(LobbyPipeline)	GetLobby();

		// update
		void Update(F32 frametime);

		// draw
		void Draw();

		// evaluate hardware
		F32 EvaluateHardware();

		// render pipeline
		sharedc_ptr(RenderPipeline)	render_pipeline;

		// lobby pipeline
		sharedc_ptr(LobbyPipeline)	lobby_pipeline;

		// login pipeline
		sharedc_ptr(LoginPipeline)	login_pipeline;

		//ui render
		sharedc_ptr(UIRender)	ui_render;

		// font manager
		sharedc_ptr(FontManager) font_manager;

		// lod control
		sharedc_ptr(LodControl)	lod_control;

	private:
		// state
		bool ingame;

		// frame time
		F32 frame_time;

		// initialized
		bool initialized;

		// warm texture
		//sharedc_ptr(RenderTexture)	warm_target;

		// warm ps
		sharedc_ptr(Shader)	warm_ps;

		// evaluate mesh
		sharedc_ptr(MeshBase) evaluate_mesh;
	};
}