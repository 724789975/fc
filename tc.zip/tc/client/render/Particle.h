namespace Client
{	
	// Particle
	class Particle
	{
		friend class Emitter;
	public:
		// constructor
		Particle();

		// destructor
		~Particle();

	private:
		// particle position
		Core::Vector3	m_Position;

		// particle rotation
		Core::Vector3	m_Rotation;

		// particle velocity
		Core::Vector3	m_Velocity;

		// particle angle velocity
		Core::Vector3	m_AngleVelocity;

		// size
		Core::Vector2	m_InitSize;

		// color
		Core::ARGB		m_Color;

		// animation first frame
		S32				m_AnimationFirstFrame;

		// animation last frame
		S32				m_AnimationLastFrame;

		// animation current column
		S32				m_AnimationCurrentColumn;

		// animation current row
		S32				m_AnimationCurrentRow;

		// animation fps
		F32				m_AnimationFPS;

		// loop
		bool			m_Loop;

		// particle remain time
		F32				m_ParticleTime;

		// emitter life
		F32				m_ParticleLifeTime;

		// sample time
		F32				m_SampleTime;

	private:
		// particle size
		Core::Vector2	m_ParticleSize;

		// xyz scale
		F32				m_InitXYZScale;

		// stretch
		F32				m_InitStretch;

		// acceleration
		F32				m_InitAcceleration;

		// resistance
		F32				m_InitResistance;

		// gravity
		F32				m_InitGravity;

		// turbulence 3d
		F32				m_InitTurbulence3D;
		F32				m_InitTurbulenceSize;
		F32				m_InitTurbulenceSpeed;
		Core::Vector3	m_Turbulence;

		// angle
		//F32				m_InitAngleZ;

		// angle velocity
		F32				m_InitAngleZVelocity;

		// color
		Core::Color3	m_InitColor;

		// color emissive
		Core::Color3	m_InitColorEmissive;

		// alpha
		F32				m_InitAlpha;

		// relative position
		Core::Vector3	m_RelativePosition;

		// number
		U32				m_Number;
	};

	// Emitter
	class Emitter
	{
	public:
		friend class ParticleSystem;
		// constructor
		Emitter();

		// destructor
		~Emitter();

		// update
		void Update(F32 frametime);

		// kill dead
		void KillDead();

		// reset
		void Reset();

		// reset particles
		void ResetParticles();

		// draw
		void Draw();

	public:
		// spawn
		void Spawn(F32 frametime);

		// spawn number
		void SpawnNumber(U32 num);

		// initial particle
		void InitParticle(Particle& particle);

		// resize max particles
		void Resize();

		// set position
		void SetPosition(const Core::Vector3& position);

		// set rotation
		void SetRotation(const Core::Quaternion& rotation);

	public:
		// set emitter data
		void SetEmitterData(by_ptr(ParticleResource::EmitterData) v);

		// load texture
		void LoadTexture();

	private:
		// position
		Core::Vector3					m_Position;

		// rotation
		Core::Quaternion				m_Rotation;

		// trail direction
		Core::Vector3					m_TrailDirection;

		// camera up direction
		Core::Vector3					m_CameraUpDirection;


	private:
		// enable
		SIMPLE_PDE_ATTRIBUTE_RW(Enable, bool);

		// build stream
		void BuildStream();

		// particle index
		Core::Array<U32>				ParticleIndex;

		static IDirect3DVertexBuffer9*	m_InstanceVB;
		static IDirect3DIndexBuffer9*	m_InstanceIB;

		static IDirect3DVertexBuffer9*	m_InstanceData;
		static U32						instance_size;

		sharedc_ptr(Texture)				m_Texture;

	private:
		// emitter data
		sharedc_ptr(ParticleResource::EmitterData) m_EmitterData;

		// particles
		Core::Array<Particle>		m_ParticleArray;

		// active particle
		U32							m_ActiveParticles;

		// max particle
		U32							m_MaxParticles;

		// spawn fraction			
		F32							m_SpawnFraction;

		// sample time
		F32							m_SampleTime;

		// emitter time
		F32							m_EmitterTime;

		// emitter life
		F32							m_EmitterLife;
		F32							m_EmitterLifeTimeInverse;

		// loop : 0 infinite, 1 single
		S32							m_Loop;

		// delay time
		F32							m_DelayTime;

		// count
		S32							m_InitCount;

		// emission rate
		F32							m_InitEmissionRate;

		// emission num				
		U32							m_InitEmissionNum;

		// focus angle
		F32							m_InitFocusAngle;

		// focus azimuth
		F32							m_InitFocusAzimuth;

		// emitter angle
		F32							m_InitAngle;

		// emitter position offset
		Core::Vector3				m_InitOffset;

		// emit size
		Core::Vector3				m_InitEmitSize;
		
		// vertex shader
		sharedc_ptr(Shader)			vertex_shader;

		// soft particle shader
		sharedc_ptr(Shader)			soft_pixel_shader;

		// particle shader
		sharedc_ptr(Shader)			pixel_shader;	

		// emit function
		U32 GetCount();
		F32 GetEmissionNum();
		F32 GetEmissionRate();
		F32 GetFocusAngle();
		F32 GetFocusAzimuth();
		F32 GetAngle();
		Core::Vector3 GetOffset();

		// particle function
		F32 GetXYZScale(Particle& p);
		Core::Vector2 GetParticleSize(Particle & p);
		F32	GetStretch(Particle& p);
		F32 GetAcceleration(Particle& p);
		F32 GetResistance(Particle& p);
		F32 GetGravity(Particle& p);
		F32 GetTurbulence3D(Particle& p);
		F32 GetTurbulenceSize(Particle& p);
		F32 GetTurbulenceSpeed(Particle& p);
		F32 GetAngleVelocity(Particle& p);
		Core::Color3 GetColor(Particle& p);
		Core::Color3 GetColorEmission(Particle& p);
		F32	GetAlpha(Particle& p);
	};


	// ParticleSystem
	class ParticleSystem : public Core::Object
	{
	public:
		// constructor
		ParticleSystem();
		ParticleSystem(Core::Identifier key, bool request = true);

		// destructor
		~ParticleSystem();

		// initialize
		void Initialize();

		// update
		void Update(F32 time);

		// dirty check
		void DirtyCheck();

		//// build stream
		//void BuildStream();

		// get particle
		void GetParticle(const Core::Identifier& key);

		// set vertex declaration
		void SetVertexDeclaration();

		// draw
		void Draw();

		// spawn number;
		void SpawnNumber(U32 num);

		// set position
		void SetPosition(const Core::Vector3& pos);

		// set rotation
		void SetRotation(const Core::Quaternion& q);

		// reset
		void Reset();

		//reset Emitter's particles
		void ResetEmittersParticles();

		// set dead
		void SetDead();

		// dead
		bool IsDead();

		// ready
		bool IsReady();

		// first person mode
		void SetFirstPersonMode(bool v);

		// is first person mode
		bool IsFirstPersonMode();

		INLINE_PDE_ATTRIBUTE_RW(ParticleResource, tempc_ptr(ParticleResource));

		// enable
		DECLARE_PDE_ATTRIBUTE_W(Enable, bool);

		// draw with out z test
		bool m_DrawFP;

		// position
		Core::Vector3	m_Position;

		// rotation
		Core::Quaternion m_Rotation;

	public:
		Core::LinkNode<ParticleSystem*> m_LinkNode;

	private:
		// emitter array
		Core::Array<sharedc_ptr(Emitter)>		m_EmitterArray;

		// particle resource
		sharedc_ptr(ParticleResource)			m_ParticleResource;

		// dirty flag
		Core::PdeDirtyFlag						m_DirtyFlag;

		// run
		bool									m_Run;

	};

	class ParticleManager : public DeviceManager
	{
	public:
		// constructor
		ParticleManager();

		// destructor
		~ParticleManager();

		// device create
		void DeviceCreate();

		// device lost
		void DeviceLost();

		// device reset
		void DeviceReset();

		// device desotry
		void DeviceDestory();

		// update
		void Update(F32 frametime);

		// draw
		void Draw(bool first_person);

		// clear
		void Clear();

		// add particle
		tempc_ptr(ParticleSystem) AddParticle(const Core::Identifier & key, const Core::Vector3 & pos, const Core::Vector3 & normal);

		tempc_ptr(ParticleSystem) AddParticle(const Core::Identifier & key, const Core::Vector3 & position, const Core::Quaternion & q);

		tempc_ptr(ParticleSystem) AddParticle(by_ptr(ParticleSystem) particle);

		// remove particle
		void RemoveParticle(by_ptr(ParticleSystem) particle);

		// set visible
		void SetVisible(bool bshow);
	private:
		// particle
		Core::LinkList<Core::LinkNode<ParticleSystem*>> particle_list;

		// particle resources
		Core::Array<sharedc_ptr(ParticleResource)>	particle_resources;

		// draw particle
		Core::Array<ParticleSystem*> draw_particle_array;

		// is show particle
		bool m_bShowParticle;
	};
}