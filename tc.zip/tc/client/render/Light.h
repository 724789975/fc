namespace Client
{
	// light
	class Light
	{
	public:
		// constructor
		Light();

		// desturctor
		~Light();

		// set position
		void SetPosition(const Core::Vector3& value);

		// set color
		void SetColor(const Core::Vector3& value);

		// set enable
		void SetEnable(const bool value);

		// set life
		void SetLife(const F32 value);

		// get enable
		bool GetEnable();

		// set attenuation
		virtual void SetAttenuation(const F32 value) = 0;

		// set intensity
		virtual void SetIntensity(const F32 value) = 0;

		// update
		void Update(F32 frametime);

		// position
		Core::Vector4	position;

		// color
		Core::Vector4	color;

		// enable
		bool			enable;

		// life
		F32				life_time;

		// dist
		F32				dist;
	};

	class PointLight : public Light
	{
	public:
		// set attenuation
		void SetAttenuation(const F32 value);

		// set intensity
		void SetIntensity(const F32 value);
	};

	class LightManager
	{
	public:
		// constructor
		LightManager();

		//destructor
		~LightManager();

		// update
		void Update(const F32 frametime);

		// add point light
		void AddPointLight(const Core::Vector3& position, const Core::Vector3& color, const F32 attenuation = 1, const F32 intensity = 1, const F32 life = 0.08f);

		// set light
		void SetLight(const U32 count, const Core::Vector3& position);

	private:
		//light
		Core::LinkList<Core::LinkNode<PointLight>>	point_lights;


		//sharedc_ptr(Light)	point_lights[4];
	};
}