#include "pch.h"
#include "../game/LuaLoadingFunc.h"

using namespace Core;

namespace Client
{
	ParticleResource::ParticleResource()
	{
	}

	ParticleResource::~ParticleResource()
	{
		m_EmitterData.Clear();
	}


	tempc_ptr(ParticleResource::EmitterData) ParticleResource::CreateEmitterData()
	{
		m_EmitterData.PushBack(ptr_new ParticleResource::EmitterData);
		return m_EmitterData.Back()->data;
	}

	void ParticleResource::AddEmitToList(tempc_ptr(Gui::ListTreeView) list)
	{
		LinkNode<sharedc_ptr(EmitterData)> * node = m_EmitterData.Front();
		while (node)
		{
			(list->AddItem(list->GetRootItem(), node->data->GetEmitName()))->SetTag(node->data);
			node = node->GetNext();
		}
	}

	void ParticleResource::AddEmitter(tempc_ptr(ParticleResource::EmitterData) data)
	{
		m_EmitterData.PushBack(data);
	}

	void ParticleResource::DeleteEmitter(tempc_ptr(ParticleResource::EmitterData) v)
	{
		LinkNode<sharedc_ptr(EmitterData)> * node = m_EmitterData.Front();
		while (node)
		{
			if (node->data == v)
			{
				m_EmitterData.Remove(node);
				break;
			}
			node = node->GetNext();
		}
	}

	void ParticleResource::ClearEmitterData()
	{
		m_EmitterData.Clear();
	}

	bool ParticleResource::Load(const Core::Identifier& path)
	{
		bool result = false;

		if (gLevel && gLevel->lua_state)
		{
			Lua::LuaState *L = Lua::LuaState::NewState();
			L->OpenLibs();
			int top = L->GetTop();

			L->NewTable();
			L->PushPtr(ptr_static_cast<ParticleResource>(this));
			L->SetField(-2, "particle_system");
			L->PushPtr(PDE_TYPE_OF(Vector2)->GetConstructor());
			L->SetField(-2, "Vector2");
			L->PushPtr(PDE_TYPE_OF(Vector3)->GetConstructor());
			L->SetField(-2, "Vector3");
			L->PushPtr(PDE_TYPE_OF(Color3)->GetConstructor());
			L->SetField(-2, "Color3");
			L->GetGlobal("pairs");
			L->SetField(-2, "pairs");
			L->GetGlobal("type");
			L->SetField(-2, "type");

			if (L->LoadFile("/vfx/ReadParticle.lua", true) == 0)
			{
				L->PushValue(top + 1);
				L->SetFenv(-2);
				if (L->DoCall(0, 0))
				{
					const char *msg = L->ToString(-1);
					if (msg) Console.WriteLine(msg);
					L->Pop(1);
				}
				else if (L->LoadFile(path, true) == 0)
				{
					L->PushValue(top + 1);
					L->SetFenv(-2);
					if (L->DoCall(0, 0))
					{
						const char *msg = L->ToString(-1);
						if (msg) Console.WriteLine(msg);
						L->Pop(1);
					}
					else
					{
						result = true;
					}
				}
				else
				{
					const char *msg = L->ToString(-1);
					if (msg) Console.WriteLine(msg);
					L->Pop(1);
				}
			}
			else
			{
				const char *msg = L->ToString(-1);
				if (msg) Console.WriteLine(msg);
				L->Pop(1);
			}

			L->Close();

			if (result)
			{
				LinkNode<sharedc_ptr(ParticleResource::EmitterData)> * node = m_EmitterData.Front();
				while(node)
				{
					CStrBuf<256> buff;
					Path::ContractPath(buff, "/vfx/", node->data->m_TextureName.Str());
					node->data->m_Textures = RESOURCE_LOAD(buff, true, Texture);
					//if (node->data->m_ParticleType == kVelocityImposter)
					//	node->data->vertex_shader = RESOURCE_LOAD("/shader/velocity_imposter_particle_vs.vd9", false, VertexShaderDx9);
					//else
					//	node->data->vertex_shader = RESOURCE_LOAD("/shader/default_particle_vs.vd9", false, VertexShaderDx9);
					//if (node->data->m_SoftParticle)
					//	node->data->pixel_shader = RESOURCE_LOAD("/shader/soft_particle_ps.pd9", false, PixelShaderDx9);
					//else
					//	node->data->pixel_shader = RESOURCE_LOAD("/shader/default_particle_ps.pd9", false, PixelShaderDx9);
					node = node->GetNext();
				}
			}
		}

		return result;
	}
}

namespace Client
{
	ParticleResource::EmitterData::EmitterData()
		: m_AnimationColumns(1)
		, m_AnimationRows(1)
		, m_AnimationFirstFrame(1)
		, m_AnimationLastFrame(1)
		, m_AnimationFPS(0)
		, m_AnimationLoop(0)
		, m_RandomFirstFrame(false)
		, m_RandomRange(Vector2::kZero)
		, m_TextureDirty(false)
		, m_Sort(false)
		, m_SoftParticle(false)
		, m_HeatNoise(false)
	 	, m_TrailStep(0)
		, m_TrailWidth(0)
	{
		m_CoordinateType	= ParticleResource::kWorld;
		m_ParticleType = kCamera;
		m_BlendType = kAdditive;

		m_EmitterType = kEmitterPoint;

		m_ParticleQuality = kQualityNormal;

		m_Count				= ptr_new ParameterInt;
		m_Count->SetConstant(1);

		m_EmissionRate		= ptr_new ParameterFloat;
		m_EmissionRate->SetConstant(1.f);

		m_EmissionNum		= ptr_new ParameterInt;
		m_EmissionNum->SetConstant(1);

		m_FocusAngle		= ptr_new ParameterFloat;
		m_FocusAzimuth		= ptr_new ParameterFloat;
		m_EmitAngle			= ptr_new ParameterFloat;

		m_Loop				= ptr_new ParameterInt;
		m_Loop->SetConstant(1);

		m_EmitterLife		= ptr_new ParameterFloat;
		m_EmitterLife->SetConstant(1.f);

		m_DelayTime			= ptr_new ParameterFloat;

		m_PositionOffset	= ptr_new ParameterFloat3;

		m_EmitSize			= ptr_new ParameterFloat3;
		m_EmitSize->SetConstant(Vector3(1.f, 1.f, 1.f));

		m_ParticleLife		= ptr_new ParameterFloat;
		m_ParticleLife->SetConstant(1.f);

		m_InitAngleZ		= ptr_new ParameterFloat;
		m_AngleZVelocity	= ptr_new ParameterFloat;

		m_ParticleSize		= ptr_new ParameterFloat2;
		m_ParticleSize->SetConstant(Vector2(1.f, 1.f));

		m_XYZScale			= ptr_new ParameterFloat;
		m_XYZScale->SetConstant(1.f);

		m_Stretch			= ptr_new ParameterFloat;

		m_Speed				= ptr_new ParameterFloat;
		//m_Speed->SetConstant(1.f);

		m_Acceleration		= ptr_new ParameterFloat;
		m_Resistance		= ptr_new ParameterFloat;
		m_Gravity			= ptr_new ParameterFloat;
		m_Turbulence3D		= ptr_new ParameterFloat;
		m_TurbulenceSize	= ptr_new ParameterFloat;
		m_TurbulenceSpeed	= ptr_new ParameterFloat;
		m_AngleVelocity		= ptr_new ParameterFloat;
		m_Color				= ptr_new ParameterColor3;
		m_Color->SetConstant(Color3(1, 1, 1));

		m_ColorEmissive		= ptr_new ParameterColor3;

		m_Alpha				= ptr_new ParameterFloat;
		m_Alpha->SetConstant(1);

		m_BlendType = kSourceAlphaAdd;

		m_AheadTime = ptr_new ParameterFloat;
		m_AheadTime->SetConstant(0.f);

		m_TurbulenceSmooth = 0.12345f;
	}
}

namespace Client
{
	bool ParticleResource::SaveData(Stream& stream)
	{
#ifndef MASTER
		Resource::SaveData(stream);

		U32 len = m_Name.Length();
		stream.Write(&len, sizeof(U32));
		stream.Write(m_Name.Str(), len);

		uint emitsize = m_EmitterData.Size();
		stream.Write(&emitsize, sizeof(uint));

		LinkNode<sharedc_ptr(ParticleResource::EmitterData)> * node = m_EmitterData.Front();
		while(node)
		{
			len = node->data->m_EmitName.Length();
			stream.Write(&len, sizeof(U32));
			stream.Write(node->data->m_EmitName.Str(), len);

			stream.Write(&node->data->m_CoordinateType, sizeof(ParticleResource::Coordinate_Type));
			stream.Write(&node->data->m_EmitterType, sizeof(ParticleResource::Emitter_Type));
			stream.Write(&node->data->m_ParticleQuality, sizeof(ParticleResource::Particle_Quality));
			node->data->m_Count->SaveData(stream);
			stream.Write(&node->data->m_Sort, sizeof(bool));
			stream.Write(&node->data->m_SoftParticle, sizeof(bool));
			stream.Write(&node->data->m_HeatNoise, sizeof(bool));
			node->data->m_EmissionRate->SaveData(stream);
			node->data->m_EmissionNum->SaveData(stream);
			node->data->m_FocusAngle->SaveData(stream);
			node->data->m_FocusAzimuth->SaveData(stream);
			node->data->m_EmitAngle->SaveData(stream);
			node->data->m_Loop->SaveData(stream);
			node->data->m_EmitterLife->SaveData(stream);
			node->data->m_DelayTime->SaveData(stream);
			node->data->m_AheadTime->SaveData(stream);
			node->data->m_PositionOffset->SaveData(stream);
			node->data->m_EmitSize->SaveData(stream);
			stream.Write(&node->data->m_ParticleType, sizeof(ParticleResource::Particle_Type));
			node->data->m_ParticleLife->SaveData(stream);
			node->data->m_InitAngleZ->SaveData(stream);
			node->data->m_AngleZVelocity->SaveData(stream);
			node->data->m_ParticleSize->SaveData(stream);
			node->data->m_XYZScale->SaveData(stream);
			node->data->m_Stretch->SaveData(stream);
			node->data->m_Speed->SaveData(stream);
			node->data->m_Acceleration->SaveData(stream);
			node->data->m_Resistance->SaveData(stream);
			node->data->m_Gravity->SaveData(stream);
			node->data->m_Turbulence3D->SaveData(stream);
			node->data->m_TurbulenceSize->SaveData(stream);
			node->data->m_TurbulenceSpeed->SaveData(stream);
			stream.Write(&node->data->m_TurbulenceSmooth, sizeof(F32));
			node->data->m_AngleVelocity->SaveData(stream);
			node->data->m_Color->SaveData(stream);
			node->data->m_ColorEmissive->SaveData(stream);
			node->data->m_Alpha->SaveData(stream);	
			stream.Write(&node->data->m_BlendType, sizeof(AlphaBlendMode));
			stream.Write(&node->data->m_AnimationColumns, sizeof(U32));
			stream.Write(&node->data->m_AnimationRows, sizeof(U32));
			stream.Write(&node->data->m_AnimationFirstFrame, sizeof(U32));
			stream.Write(&node->data->m_AnimationLastFrame, sizeof(U32));
			stream.Write(&node->data->m_AnimationFPS, sizeof(F32));
			stream.Write(&node->data->m_AnimationLoop, sizeof(U32));
			stream.Write(&node->data->m_RandomFirstFrame, sizeof(bool));
			stream.Write(&node->data->m_RandomRange, sizeof(Vector2));

			len = node->data->m_MaterialName.Length();
			stream.Write(&len, sizeof(U32));
			stream.Write(node->data->m_MaterialName.Str(), len);

			len = node->data->m_TextureName.Length();
			stream.Write(&len, sizeof(U32));
			stream.Write(node->data->m_TextureName.Str(), len);

			stream.Write(&node->data->m_TrailStep, sizeof(U32));
			stream.Write(&node->data->m_TrailWidth, sizeof(F32));

			node = node->GetNext();
		}
		return true;
#else
		return false;
#endif
	}

	sharedc_ptr(Object) ParticleResource::LoadData(Stream& stream)
	{
		if (!Resource::LoadData(stream))
			return NullPtr;
	
		sharedc_ptr(ParticleResource) particle_resource = ptr_new ParticleResource;

		U32 length = 0;
		CStrBuf<256> str;
		stream.Read(&length, sizeof(U32));
		str.setlen(length);
		stream.Read(str.buff(), sizeof(char) * length);
		m_Name = str;

		uint emitsize = 0;
		stream.Read(&emitsize, sizeof(uint));

		for (U32 i = 0; i < emitsize; i++)
		{
			sharedc_ptr(ParticleResource::EmitterData) emitter = ptr_new ParticleResource::EmitterData();
			LinkNode<sharedc_ptr(ParticleResource::EmitterData)>* node = particle_resource->m_EmitterData.PushBack(emitter);

			CStrBuf<256> str;
			stream.Read(&length, sizeof(U32));
			str.setlen(length);
			stream.Read(str.buff(), sizeof(char) * length);
			node->data->m_EmitName = str;

			stream.Read(&node->data->m_CoordinateType, sizeof(ParticleResource::Coordinate_Type));
			stream.Read(&node->data->m_EmitterType, sizeof(ParticleResource::Emitter_Type));
			stream.Read(&node->data->m_ParticleQuality, sizeof(ParticleResource::Particle_Quality));
			node->data->m_Count->LoadData(stream);
			stream.Read(&node->data->m_Sort, sizeof(bool));
			stream.Read(&node->data->m_SoftParticle, sizeof(bool));
			stream.Read(&node->data->m_HeatNoise, sizeof(bool));
			node->data->m_EmissionRate->LoadData(stream);
			node->data->m_EmissionNum->LoadData(stream);
			node->data->m_FocusAngle->LoadData(stream);
			node->data->m_FocusAzimuth->LoadData(stream);
			node->data->m_EmitAngle->LoadData(stream);
			node->data->m_Loop->LoadData(stream);
			node->data->m_EmitterLife->LoadData(stream);
			node->data->m_DelayTime->LoadData(stream);
			node->data->m_AheadTime->LoadData(stream);
			node->data->m_PositionOffset->LoadData(stream);
			node->data->m_EmitSize->LoadData(stream);
			stream.Read(&node->data->m_ParticleType, sizeof(ParticleResource::Particle_Type));
			node->data->m_ParticleLife->LoadData(stream);
			node->data->m_InitAngleZ->LoadData(stream);
			node->data->m_AngleZVelocity->LoadData(stream);
			node->data->m_ParticleSize->LoadData(stream);
			node->data->m_XYZScale->LoadData(stream);
			node->data->m_Stretch->LoadData(stream);
			node->data->m_Speed->LoadData(stream);
			node->data->m_Acceleration->LoadData(stream);
			node->data->m_Resistance->LoadData(stream);
			node->data->m_Gravity->LoadData(stream);
			node->data->m_Turbulence3D->LoadData(stream);
			node->data->m_TurbulenceSize->LoadData(stream);
			node->data->m_TurbulenceSpeed->LoadData(stream);
			stream.Read(&node->data->m_TurbulenceSmooth, sizeof(F32));
			node->data->m_AngleVelocity->LoadData(stream);
			node->data->m_Color->LoadData(stream);
			node->data->m_ColorEmissive->LoadData(stream);
			node->data->m_Alpha->LoadData(stream);
			stream.Read(&node->data->m_BlendType, sizeof(AlphaBlendMode));
			stream.Read(&node->data->m_AnimationColumns, sizeof(U32));
			stream.Read(&node->data->m_AnimationRows, sizeof(U32));
			stream.Read(&node->data->m_AnimationFirstFrame, sizeof(U32));
			stream.Read(&node->data->m_AnimationLastFrame, sizeof(U32));
			stream.Read(&node->data->m_AnimationFPS, sizeof(F32));
			stream.Read(&node->data->m_AnimationLoop, sizeof(U32));
			stream.Read(&node->data->m_RandomFirstFrame, sizeof(bool));
			stream.Read(&node->data->m_RandomRange, sizeof(Vector2));

			stream.Read(&length, sizeof(U32));
			str.setlen(length);
			stream.Read(str.buff(), sizeof(char) * length);
			node->data->m_MaterialName = str;

			stream.Read(&length, sizeof(U32));
			str.setlen(length);
			stream.Read(str.buff(), sizeof(char) * length);
			node->data->m_TextureName = str;

			CStrBuf<256> buff;
			Path::ContractPath(buff, "/vfx/", str);
			node->data->m_Textures = RESOURCE_LOAD(buff, true, Texture);

			stream.Read(&node->data->m_TrailStep, sizeof(U32));
			stream.Read(&node->data->m_TrailWidth, sizeof(F32));
		}
		return particle_resource;
	}

	/// get version
	short ParticleResource::GetVersion()
	{
		return 4;
	}

	sharedc_ptr(Object) ParticleResource::BuildData()
	{
#ifndef MASTER
		sharedc_ptr(ParticleResource) data = ptr_new ParticleResource;
		if (data->Load(GetKey()))
		{
			AddDependenceFilePath(GetKey());
			return data;
		}
#endif
		return NullPtr;
	}

	void ParticleResource::UnloadData()
	{
		m_EmitterData.Clear();
	}

	bool ParticleResource::OnLoadData(by_ptr(Object) obj)
	{
		tempc_ptr(ParticleResource) data = ptr_dynamic_cast<ParticleResource>(obj);
		if (obj)
		{
			m_EmitterData.Clear();

			for (Core::LinkNode<sharedc_ptr(EmitterData)> * node = data->m_EmitterData.Front(); node; node = node->GetNext())
			{
				m_EmitterData.PushBack(node->data);
			}

			return true;
		}
		return false;
	}
}

namespace Client
{
	void ParticleResource::EmitterData::SetTextureName(Identifier& value)
	{
		if (value == m_TextureName)
			return;

		m_TextureName = value;
		m_TextureDirty = true;
	}

	Identifier& ParticleResource::EmitterData::GetTextureName()
	{
		return m_TextureName;
	}
}

using namespace Client;

DEFINE_PDE_TYPE_CLASS(ParticleResource)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_METHOD(CreateEmitterData);
		ADD_PDE_METHOD(AddEmitToList);
		ADD_PDE_METHOD(AddEmitter);
		ADD_PDE_METHOD(DeleteEmitter);
		ADD_PDE_METHOD(ClearEmitterData);
		ADD_PDE_PROPERTY_RW(Name);
	}
};


REGISTER_PDE_TYPE(ParticleResource);


DEFINE_PDE_TYPE_CLASS(ParticleResource::EmitterData)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_PROPERTY_RW(CoordinateType);
		ADD_PDE_PROPERTY_RW(EmitterType);
		ADD_PDE_PROPERTY_RW(ParticleQuality);
		ADD_PDE_PROPERTY_RW(Count);
		ADD_PDE_PROPERTY_RW(Sort);
		ADD_PDE_PROPERTY_RW(SoftParticle);
		ADD_PDE_PROPERTY_RW(EmissionRate);
		ADD_PDE_PROPERTY_RW(EmissionNum);
		ADD_PDE_PROPERTY_RW(FocusAngle);
		ADD_PDE_PROPERTY_RW(FocusAzimuth);
		ADD_PDE_PROPERTY_RW(EmitAngle);
		ADD_PDE_PROPERTY_RW(Loop);
		ADD_PDE_PROPERTY_RW(EmitterLife);
		ADD_PDE_PROPERTY_RW(DelayTime);
		ADD_PDE_PROPERTY_RW(AheadTime);
		ADD_PDE_PROPERTY_RW(PositionOffset);
		ADD_PDE_PROPERTY_RW(EmitSize);
		ADD_PDE_PROPERTY_RW(ParticleType);
		ADD_PDE_PROPERTY_RW(ParticleLife);
		ADD_PDE_PROPERTY_RW(InitAngleZ);
		ADD_PDE_PROPERTY_RW(AngleZVelocity);
		ADD_PDE_PROPERTY_RW(ParticleSize);
		ADD_PDE_PROPERTY_RW(XYZScale);
		ADD_PDE_PROPERTY_RW(Stretch);
		ADD_PDE_PROPERTY_RW(Speed);
		ADD_PDE_PROPERTY_RW(Acceleration);
		ADD_PDE_PROPERTY_RW(Resistance);
		ADD_PDE_PROPERTY_RW(Gravity);
		ADD_PDE_PROPERTY_RW(Turbulence3D);
		ADD_PDE_PROPERTY_RW(TurbulenceSize);
		ADD_PDE_PROPERTY_RW(TurbulenceSpeed);
		ADD_PDE_PROPERTY_RW(TurbulenceSmooth);
		ADD_PDE_PROPERTY_RW(Color);
		ADD_PDE_PROPERTY_RW(ColorEmissive);
		ADD_PDE_PROPERTY_RW(Alpha);
		ADD_PDE_PROPERTY_RW(BlendType);
		ADD_PDE_PROPERTY_RW(AnimationFirstFrame);
		ADD_PDE_PROPERTY_RW(AnimationLastFrame);
		ADD_PDE_PROPERTY_RW(AnimationFPS);
		ADD_PDE_PROPERTY_RW(AnimationLoop);
		ADD_PDE_PROPERTY_RW(RandomFirstFrame);
		ADD_PDE_PROPERTY_RW(RandomRange);
		ADD_PDE_PROPERTY_RW(AnimationColumns);
		ADD_PDE_PROPERTY_RW(AnimationRows);
		ADD_PDE_PROPERTY_RW(EmitName);
		ADD_PDE_PROPERTY_RW(MaterialName);
		ADD_PDE_PROPERTY_RW(TextureName);
		ADD_PDE_PROPERTY_RW(TrailStep);
		ADD_PDE_PROPERTY_RW(TrailWidth);		
	}
};

REGISTER_PDE_TYPE(ParticleResource::EmitterData);

DEFINE_PDE_TYPE_ENUM(ParticleResource::Emitter_Type)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_ENUM_ITEM("EmitterPoint",			ParticleResource::kEmitterPoint);
		ADD_PDE_ENUM_ITEM("EmitterPlane",			ParticleResource::kEmitterPlane);
		ADD_PDE_ENUM_ITEM("EmitterCube",			ParticleResource::kEmitterCube);
		ADD_PDE_ENUM_ITEM("EmitterTrail",			ParticleResource::kEmitterTrail);
		ADD_PDE_ENUM_ITEM("EmitterNumber",			ParticleResource::kEmitterNumber);
		ADD_PDE_ENUM_ITEM("EmitterTypeNone",		ParticleResource::kEmitterTypeNone);

		ADD_PDE_ENUM_CONSTRUCTOR();
	}
};
REGISTER_PDE_TYPE(ParticleResource::Emitter_Type);

DEFINE_PDE_TYPE_ENUM(ParticleResource::Particle_Quality)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_ENUM_ITEM("QualityNormal",			ParticleResource::kQualityNormal);
		ADD_PDE_ENUM_ITEM("LowQualityNoSee",			ParticleResource::kLowQualityNoSee);

		ADD_PDE_ENUM_CONSTRUCTOR();
	}
};
REGISTER_PDE_TYPE(ParticleResource::Particle_Quality);

DEFINE_PDE_TYPE_ENUM(AlphaBlendMode)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_ENUM_ITEM("AlphaBase",				kSourceAlphaAdd);
		ADD_PDE_ENUM_ITEM("ColorBase",				kAlphaBlend);
		ADD_PDE_ENUM_ITEM("Additive",				kAdditive);
		ADD_PDE_ENUM_ITEM("AlphaClip",				kAlphaTest);
		ADD_PDE_ENUM_ITEM("BlendNone",				kBlendNone);

		ADD_PDE_ENUM_CONSTRUCTOR();
	}
};
REGISTER_PDE_TYPE(AlphaBlendMode);

DEFINE_PDE_TYPE_ENUM(ParticleResource::Particle_Type)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_ENUM_ITEM("Camera",					ParticleResource::kCamera);
		ADD_PDE_ENUM_ITEM("Horizontal",				ParticleResource::kHorizontal);
		ADD_PDE_ENUM_ITEM("VelocityImposter",		ParticleResource::kVelocityImposter);
		ADD_PDE_ENUM_ITEM("FollowVelocity",			ParticleResource::kFollowVelocity);
		ADD_PDE_ENUM_ITEM("ParticleTypeNone",		ParticleResource::kParticleTypeNone);

		ADD_PDE_ENUM_CONSTRUCTOR();
	}
};
REGISTER_PDE_TYPE(ParticleResource::Particle_Type);

DEFINE_PDE_TYPE_ENUM(ParticleResource::Coordinate_Type)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_ENUM_ITEM("Local",					ParticleResource::kLocal);
		ADD_PDE_ENUM_ITEM("World",					ParticleResource::kWorld);

		ADD_PDE_ENUM_CONSTRUCTOR();
	}
};
REGISTER_PDE_TYPE(ParticleResource::Coordinate_Type);