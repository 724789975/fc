#include "pch.h"
using namespace Core;

namespace Client
{
	Decal::Decal()
		: left_time(0)
		, count(0)
		, index(-1)
		, manager(NULL)
		, start(0)
	{
	}

	Decal::~Decal()
	{
	}

	void Decal::Draw()
	{
		PROFILE("Decal::Draw");

		if (!gLevel)
			return;

		if (!gLevel->GetVisible(aabb))
			return;

		VertexDeclaration::StreamDecal *pstream = manager->decalimpls[index].deque_vertexs.GetData();
		for (int i = 0; i < 6; i++)
		{
			Vector4 plane = clip_plane[i];
			Core::Transform(plane, plane, gGame->camera->inv_viewproj_transpose);
			gDx9Device->SetClipPlane(i, &plane.x);
		}

		int nrange = start + count * 3 - manager->decalimpls[index].deque_vertexs.Capacity();

		if(nrange > 0)
		{
			int outrangecount = nrange / 3;
			for (int i = 0; i < (count - outrangecount) * 3; i++)
			{
				pstream[start + i].decal_time.z = left_time;
			}
			gDx9Device->DrawPrimitiveUP(D3DPT_TRIANGLELIST, count - outrangecount, &pstream[start], VD::GetVertexDeclarationStride(VertexDeclaration::kDecal));
			for (int i = 0; i < outrangecount * 3; i++)
			{
				pstream[i].decal_time.z = left_time;
			}
			gDx9Device->DrawPrimitiveUP(D3DPT_TRIANGLELIST, outrangecount, &pstream[0], VD::GetVertexDeclarationStride(VertexDeclaration::kDecal));
		}
		else
		{
			for (int i = 0; i < count * 3; i++)
			{
				pstream[start + i].decal_time.z = left_time;
			}
			gDx9Device->DrawPrimitiveUP(D3DPT_TRIANGLELIST, count, &pstream[start], VD::GetVertexDeclarationStride(VertexDeclaration::kDecal));
		}
	}

	void Decal::GetTriPoints(VertexDeclaration::StreamDecal *& v1,  VertexDeclaration::StreamDecal *& v2, VertexDeclaration::StreamDecal *& v3)
	{
		if(manager->decalimpls[index].deque_vertexs.Size()  == manager->decalimpls[index].deque_vertexs.Capacity())
		{
			manager->decalimpls[index].deque_vertexs.Reserve(manager->decalimpls[index].deque_vertexs.Capacity() * 2);
			int nstartmove = manager->decalimpls[index].deque_vertexs.GetFrontIndex() - manager->decalimpls[index].deque_vertexs.GetBackIndex();
			if(nstartmove > 0)
			{
				for(U32 i = 0; i < manager->decalimpls[index].deque_decals.Size();i++)
				{
					if(manager->decalimpls[index].deque_decals[i].start >= manager->decalimpls[index].deque_vertexs.GetBackIndex())
					{
						manager->decalimpls[index].deque_decals[i].start += nstartmove;
					}
				}
			}
		}
		if(!count)
		{
			start = manager->decalimpls[index].deque_vertexs.GetBackIndex();
		}
		v1 = &manager->decalimpls[index].deque_vertexs.PushBack();
		v2 = &manager->decalimpls[index].deque_vertexs.PushBack();
		v3 = &manager->decalimpls[index].deque_vertexs.PushBack();
		count ++;
	}
}

namespace Client
{
	DecalResource::DecalResource()
		: scale(Vector3::kOne)
		, random_rot(false)
		, fade_in(-1)
		, fade_out(-1)
		, duration(1.f)
		, texture_col(1)
		, texture_row(1)
		, random_tex(false)
	{
		material = ptr_new Material;
	}

	DecalResource::~DecalResource()
	{
		material = NullPtr;
	}

	/// get version
	short DecalResource::GetVersion()
	{
		return 2;
	}

	bool DecalResource::SaveData(Core::Stream & stream)
	{		
#ifndef MASTER
		Resource::SaveData(stream);
		stream.Write(&scale.x, sizeof(Vector3));
		stream.Write(&random_rot, sizeof(bool));
		stream.Write(&fade_in, sizeof(F32));
		stream.Write(&fade_out, sizeof(F32));
		stream.Write(&duration, sizeof(F32));
		stream.Write(&texture_col, sizeof(U32));
		stream.Write(&texture_row, sizeof(U32));
		stream.Write(&random_tex, sizeof(bool));
		material->Save(stream);
		return true;
#else
		return false;
#endif
	}

	sharedc_ptr(Object) DecalResource::LoadData(Core::Stream & stream)
	{
		Resource::LoadData(stream);
		sharedc_ptr(DecalResource) data = ptr_new DecalResource;
		stream.Read(&data->scale.x, sizeof(Vector3));
		stream.Read(&data->random_rot, sizeof(bool));
		stream.Read(&data->fade_in, sizeof(F32));
		stream.Read(&data->fade_out, sizeof(F32));
		stream.Read(&data->duration, sizeof(F32));
		stream.Read(&data->texture_col, sizeof(U32));
		stream.Read(&data->texture_row, sizeof(U32));
		stream.Read(&data->random_tex, sizeof(bool));
		data->material->Load(stream);
		return data; 
	}

	sharedc_ptr(Object) DecalResource::BuildData()
	{
#ifndef MASTER
		sharedc_ptr(DecalResource) decal;

		Lua::LuaState * L = Lua::LuaState::NewState();
		int top = L->GetTop();
		L->NewTable();
		if (L->LoadFile(GetKey(), true) == 0)
		{
			L->PushValue(top + 1);
			L->SetFenv(-2);

			if (L->DoCall(0, 0))
			{
				const char *msg = L->ToString(-1);
				if (msg) Console.WriteLine(msg);
				L->Pop(1);
			}
			else
			{
				decal = ptr_new DecalResource;

				L->GetField(top + 1, "decal");
				L->GetField(-1, "ScaleX");
				decal->scale.x = L->IsNumber(-1) ? L->ToNumber(-1) : 1;
				L->Pop(1);

				L->GetField(-1, "ScaleY");
				decal->scale.y = L->IsNumber(-1) ? L->ToNumber(-1) : 1;
				L->Pop(1);

				L->GetField(-1, "ScaleZ");
				decal->scale.z = L->IsNumber(-1) ? L->ToNumber(-1) : 1;
				L->Pop(1);

				L->GetField(-1, "RandomRot");
				decal->random_rot = L->IsBoolean(-1) ? L->ToBoolean(-1) : false;
				L->Pop(1);

				L->GetField(-1, "FadeInTime");
				decal->fade_in = L->IsNumber(-1) ? L->ToNumber(-1) : -1;
				L->Pop(1);

				L->GetField(-1, "FadeOutTime");
				decal->fade_out = L->IsNumber(-1) ? L->ToNumber(-1) : -1;
				L->Pop(1);

				L->GetField(-1, "Duration");
				decal->duration = L->IsNumber(-1) ? L->ToNumber(-1) : 1;
				L->Pop(1);

				L->GetField(-1, "TextureCol");
				decal->texture_col = L->IsNumber(-1) ? L->ToNumber(-1) : 1;
				L->Pop(1);

				L->GetField(-1, "TextureRow");
				decal->texture_row = L->IsNumber(-1) ? L->ToNumber(-1) : 1;
				L->Pop(1);

				L->GetField(-1, "RandomTex");
				decal->random_tex = L->IsBoolean(-1) ? L->ToBoolean(-1) : false;
				L->Pop(1);

				decal->material->Load(L, GetKey());

				AddDependenceFilePath(GetKey());
			}
		}
		L->Close();
		return decal;
#else
		return NullPtr;
#endif
	}

	void DecalResource::UnloadData()
	{
		return;
	}

	bool DecalResource::OnLoadData(by_ptr(Object) obj)
	{
		tempc_ptr(DecalResource) data = ptr_dynamic_cast<DecalResource>(obj);
		material = data->material;
		scale = data->scale;
		random_rot = data->random_rot;
		fade_in = data->fade_in;
		fade_out = data->fade_out;
		duration = data->duration;
		texture_col = data->texture_col;
		texture_row = data->texture_row;
		random_tex = data->random_tex;
		return true;
	}
}

namespace
{
	using namespace Client;

	class ClipPlane
	{
	public:
		inline bool Inside(Vector3 vertices)
		{
			return Dot(vertices, normal) < dist;
		}

		inline Vector3 Clip(Vector3 start, Vector3 end, Vector3& out)
		{
			Vector3 dir = end - start;

			F32 a = Dot(dir, normal);

			if (fabs(a) < EPSILON)
				a = 0;
			else
				a = 1.f / a * (dist - Dot(start, normal));

			return Lerp(out, start, end, a);
		}

		void SetPlane(Vector3 n, F32 d)
		{
			normal = n;
			dist = d;
		}

	private:
		Vector3 normal;
		F32	   dist;

	};

	struct CollectCallbackDecal : NxUserEntityReport<NxU32>
	{
		bool TestIntersection(const Vector3 a, const Vector3 b, const Vector3 c)
		{
			Vector3 box_center = obb.Center;

			Vector3 ta = a - box_center;
			Vector3 tb = b - box_center;
			Vector3 tc = c - box_center;

			Vector3 vector[13];
			vector[12] = Normalize(Cross(b - a, c - b));

			obb.Axes(vector[9], vector[10], vector[11]);

			vector[0]	= Normalize(Cross(vector[9],  c - b));
			vector[1]	= Normalize(Cross(vector[9],  b - a));
			vector[2]	= Normalize(Cross(vector[9],  a - c));
			vector[3]	= Normalize(Cross(vector[10], c - b));
			vector[4]	= Normalize(Cross(vector[10], b - a));
			vector[5]	= Normalize(Cross(vector[10], a - c));
			vector[6]	= Normalize(Cross(vector[11], c - b));
			vector[7]	= Normalize(Cross(vector[11], b - a));
			vector[8]	= Normalize(Cross(vector[11], a - c));

			const Vector3& extent = obb.Extents;

			for (U32 i = 0; i < 13; i++)
			{
				if(vector[i].Length() < EPSILON)
					continue;
				F32 r = extent.x * abs(Dot(vector[9], vector[i])) + extent.y * abs(Dot(vector[10], vector[i])) + extent.z * abs(Dot(vector[11], vector[i]));

				F32 p0 = Dot(ta, vector[i]);
				F32 p1 = Dot(tb, vector[i]);
				F32 p2 = Dot(tc, vector[i]);

				F32 min = Min(p0, Min(p1, p2));
				F32 max = Max(p0, Max(p1, p2));

				if (Max(-max, min) > r)
					return false;
			}
			return true;
		}

		bool onEvent(NxU32 nbEntities, NxU32* entities)
		{
			NxTriangleMesh & triangle_mesh = mesh->getTriangleMesh();

			Vector3 x, y, z;
			obb.Axes(x, y, z);

			x.Normalize();
			y.Normalize();
			z.Normalize();

			Matrix44 v, p;
			Vector3 normal(nor.x, nor.y, nor.z);
			v.SetLookAt(target - normal * scale.z / 2, target + z, y);
			p.SetOrtho(obb.Extents.x, obb.Extents.y, 0, obb.Extents.z * 2);
			Matrix44 projector_matrix = v * p;

			decal->frustum.Update(projector_matrix);
			for (U32 i = 0; i < 6; i++)
			{
				Plane3d plane = decal->frustum.GetFrustumPlane(FrustumPlane(i));
				Vector4 pos(Normalize(plane.m_Normal), plane.m_Dist);
				decal->clip_plane[i] = pos;
			}

			D3DXVECTOR4_16F uv_trans;
			if (decal->decal_resource->random_tex)
			{
				U32 col = rand() % decal->decal_resource->texture_col;
				U32 row = rand() % decal->decal_resource->texture_row;

				F32 c = 1.f / decal->decal_resource->texture_col;
				F32 r = 1.f / decal->decal_resource->texture_row;

				uv_trans = D3DXVECTOR4_16F(c * col, r * row, c, r);
			}
			else
				uv_trans = D3DXVECTOR4_16F(0, 0, 1, 1);

			D3DXVECTOR4_16F decal_position = D3DXVECTOR4_16F(target.x, target.y, target.z, 2.f / decal->decal_resource->scale.z);

			decal->left_time = decal->decal_resource->duration;
			for (uint i = 0; i < nbEntities; i ++)
			{
				NxVec3 normal;
				NxTriangle triangle;
				mesh->getTriangle(triangle, NULL, NULL, entities[i], false, false);

				triangle.normal(normal);

				Vector4 decal_time;
				decal_time.x = decal->decal_resource->fade_in > 0 ? decal->decal_resource->fade_in : 0;
				decal_time.y = decal->decal_resource->fade_out > 0 ? decal->decal_resource->fade_out : 0;
				decal_time.z = decal->decal_resource->duration;
				decal_time.w = decal->decal_resource->duration;

				if ((normal | nor) > 0.005f)
				{
					VertexDeclaration::StreamDecal* v[3] = {NULL};
					decal->GetTriPoints(v[0], v[1], v[2]);
					if (!v[0] || !v[1] || !v[2])
						return false;

					v[0]->position = binary_cast<Vector3>(triangle.verts[0]);
					v[1]->position = binary_cast<Vector3>(triangle.verts[1]);
					v[2]->position = binary_cast<Vector3>(triangle.verts[2]);

					if (entities[i] < actor->attr_buffer.Size())
					{
						D3DXVECTOR2_16F * uv1 = actor->attr_buffer[entities[i]].uv1;
						v[0]->uv1 = uv1[0];
						v[1]->uv1 = uv1[1];
						v[2]->uv1 = uv1[2];
					}
					else
					{
						v[0]->uv1 = D3DXVECTOR2_16F(0, 0);
						v[1]->uv1 = D3DXVECTOR2_16F(0, 0);
						v[2]->uv1 = D3DXVECTOR2_16F(0, 0);
					}

					for (U32 c = 0; c < 3; c++)
					{
						v[c]->uv_trans = uv_trans;
						v[c]->decal_position = decal_position;

						Vector4 vector_in(v[c]->position, 1.f);
						Vector4 vector_out;
						Core::Transform(vector_out, vector_in, projector_matrix);
						Vector2 uv = Vector2(vector_out.x, vector_out.y) * Vector2(0.5, -0.5f) + Vector2(0.5f, 0.5f);
						v[c]->uv = D3DXVECTOR2_16F(uv.x, uv.y);
						v[c]->decal_time = decal_time;
					}
				}
			}
			return true;
		}

		tempc_ptr(PhysxResource::PhysxActor) actor;
		NxTriangleMeshShape * mesh;
		NxVec3 nor;
		Decal * decal;
		OrientBox obb;
		Vector3	target;
		Vector3 scale;
	};
}
namespace Client
{
	DecalManager::DecalManager()
	{
		LoadDecalList("/decal/decal_list.lua");
	}

	DecalManager::~DecalManager()
	{
		Clear();
	}

	void DecalManager::LoadDecalList(const Core::String& path)
	{
		Lua::LuaState *L = Lua::LuaState::NewState();
		int top = L->GetTop();
		L->NewTable();
		if (L->LoadFile(path) == 0)
		{
			L->PushValue(top + 1);
			L->SetFenv(-2);

			if (L->DoCall(0, 0))
			{
				const char *msg = L->ToString(-1);
				if (msg) Console.WriteLine(msg);
				L->Pop(1);
			}
			else
			{
				L->GetField(-1, "decal_resource_list");
				int array_size = L->ObjLen(-1);
				for(int i = 1; i <= array_size; i++)
				{
					L->PushInteger(i);
					L->GetTable(-2);

					L->PushInteger(1);
					L->GetTable(-2);
					String key = L->ToString(-1);
					L->Pop(1);

					L->PushInteger(2);
					L->GetTable(-2);
					String sourcepath = L->ToString(-1);
					L->Pop(1);

					decal_resources.Add(key, RESOURCE_LOAD(sourcepath, true, DecalResource));

					L->Pop(1);
				}
				L->Pop(1);
			}



		}
		L->SetTop(top);
		L->Close();

	}

	void DecalManager::Update(F32 frametime)
	{
		for (U32 i = 0; i < decalimpls.Size(); i++)
		{
			if (!decalimpls[i].deque_decals.Empty())
			{
				Core::Deque<Decal>* pdeque_decals = &decalimpls[i].deque_decals;
				Core::Deque<VertexDeclaration::StreamDecal>* pdeque_vertexs = &decalimpls[i].deque_vertexs;

				for (U32 j = 0; j < (*pdeque_decals).Size(); j++)
				{
					(*pdeque_decals)[j].left_time -= frametime;
					if ((*pdeque_decals)[j].left_time < 0)
					{
						Decal * popdecal = &(*pdeque_decals)[j];
						for(int k = 0; k < popdecal->count * 3; k++)
						{
							pdeque_vertexs->PopFront();
						}
						
						pdeque_decals->PopFront();
						j--;
					}
				}
			}
		}

		HashSet<int, sharedc_ptr(Spray)>::Enumerator it(gLevel->spray_set);
		

		while (it.MoveNext())
		{
			it.Value()->Update(frametime);
		}
	}

	void DecalManager::Draw(F32 frametime)
	{
		gDx9Device->SetVertexDeclaration(VD::GetVertexDeclaration(VertexDeclaration::kDecal));
		for (U32 i = 0; i < decalimpls.Size(); i++)
		{
			if (!decalimpls[i].deque_decals.Empty())
			{
				Core::Deque<Decal>* pdeque_decals = &decalimpls[i].deque_decals;
				Core::Deque<VertexDeclaration::StreamDecal>* pdeque_vertexs = &decalimpls[i].deque_vertexs;

				pdeque_decals->Back().decal_resource->material->ChooseShader();
				pdeque_decals->Back().decal_resource->material->SetVertexShader();
				pdeque_decals->Back().decal_resource->material->SetPixelShader();
				pdeque_decals->Back().decal_resource->material->SetTexture();

				for (U32 j = 0; j < (*pdeque_decals).Size(); j++)
				{
					(*pdeque_decals)[j].Draw();
				}
			}

		}
	}

	void DecalManager::AddDecal(String key, const Core::Vector3 & target, const Core::Vector3 & normal, const Core::Vector3 & size, const F32 duration)
	{
		if (key == String::kEmpty)
			return;

		sharedc_ptr(DecalResource) * resource = decal_resources.Get(key);
		
		if (!resource)
		{
			LogSystem.WriteLinef("%s decal resource not loaded before game start", key);
			return;
		}

		if (!(*resource)->IsReady())
			return;

		if (!gLevel)
			return;

		Vector3 nor = Normalize(normal);
		Quaternion quat(Vector3(0, 0, 1), nor);

		if ((*resource)->random_rot)
		{
			F32 degree = Fmod(rand(), TWOPI);
			quat *= Quaternion(nor, degree);
		}
		OrientBox obb(target, (*resource)->scale / 2, quat);

		if (!gLevel->GetVisible(obb))
			return;

		U32 *index = NULL;
		index = decal_types.Get(key);

		Decal * decal = NULL;

		int s = 0;
		if (index)
		{
			s = *index;
			Core::Deque<Decal>& decals = decalimpls[*index].deque_decals;
			Core::Deque<VertexDeclaration::StreamDecal>& vertexs = decalimpls[*index].deque_vertexs;
			if(decals.Size() == decalimpls[*index].decal_max_size)
			{
				Decal & popdecal = decals.Front();
				for(int k = 0; k < popdecal.count * 3; k++)
				{
					vertexs.PopFront();
				}
				decals.PopFront();
			}
			decal = &decals.PushBack();
			decal->decal_resource = *resource;
		}
		else
		{
			decal_types.Add(key, decalimpls.Size());
			s = decalimpls.Size();
			decalimpls.PushBack();
			decalimpls.Back().deque_decals.Reserve(decalimpls.Back().decal_max_size);
			decalimpls.Back().deque_vertexs.Reserve(9);
			decal = &decalimpls.Back().deque_decals.PushBack();
			decal->decal_resource = *resource;
		}

		decal->manager = this;
		decal->index = s; 
		decal->aabb = AxisAlignedBox(obb);

		NxVec3 center(binary_cast<NxVec3>(target));
		NxVec3 extend(binary_cast<NxVec3>(decal->decal_resource->scale / 2));
		NxQuat rotate(binary_cast<NxQuat>(quat));
		NxBox box(center, extend, rotate);
		NxBounds3 bounds;
		bounds.boundsOfOBB(rotate, center, extend);
		NxShape * shape_buffer[256];
		uint groups = (1 << PhysxSystem::kStatic) | (1 << PhysxSystem::kStaticRaycast);
		uint shape_count = PhysxSystem::Scene()->overlapOBBShapes(box, NX_STATIC_SHAPES , ELEMENTS_OF(shape_buffer), (NxShape**)&shape_buffer, NULL, groups);
		CollectCallbackDecal callback;
		callback.decal = decal;
		callback.obb = obb;
		callback.nor = binary_cast<NxVec3>(nor);
		callback.target = target;
		callback.scale = decal->decal_resource->scale;
		for (uint i = 0; i < shape_count; i ++)
		{
			NxShape * shape = shape_buffer[i];
			if (shape->is(NX_SHAPE_MESH))
			{
				NxTriangleMeshShape * mesh = (NxTriangleMeshShape*)shape;
				callback.mesh = mesh;
				callback.actor = ptr_dynamic_cast<PhysxResource::PhysxActor>(static_cast<Core::Object*>(mesh->getActor().userData));
				mesh->overlapAABBTriangles(bounds, 0, &callback);
			}
		}
	}

	void DecalManager::Clear()
	{
		for (U32 i = 0; i < decalimpls.Size(); i++)
		{

			decalimpls[i].deque_vertexs.Clear();
			decalimpls[i].deque_decals.Clear();
		}
		decalimpls.Clear();
		decal_types.Clear();

		spray_resources.Clear();
	}
}

