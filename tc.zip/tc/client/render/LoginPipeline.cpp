#include "pch.h"
using namespace Core;
namespace Client
{
	LoginPipeline::LoginPipeline()
		: initialized(false)
	{
	}

	LoginPipeline::~LoginPipeline()
	{
		UnInitialize();
	}

	void LoginPipeline::Initialize()
	{
		if (GetInitialized())
			return;

		bg_texture[0] = RESOURCE_LOAD("/mesh/scene/levellogin/bg_43_layer_0.dds", true, Texture);
		bg_texture[1] = RESOURCE_LOAD("/mesh/scene/levellogin/bg_43_layer_1.dds", true, Texture);
		//bg_texture[2] = RESOURCE_LOAD("/mesh/scene/levellogin/bg_43_layer_2.dds", true, Texture);
		bg_texture[2] = RESOURCE_LOAD_NEW("login/login_BG02_2.dds", true, Texture);
		bg_texture_wide[0] = RESOURCE_LOAD("/mesh/scene/levellogin/bg_lay_0.dds", true, Texture);
		bg_texture_wide[1] = RESOURCE_LOAD("/mesh/scene/levellogin/bg_lay_1.dds", true, Texture);
		//bg_texture_wide[2] = RESOURCE_LOAD("/mesh/scene/levellogin/bg_lay_2.dds", true, Texture);
		bg_texture_wide[2] = RESOURCE_LOAD_NEW("login/login_BG02.dds", true, Texture);

		//bg_particle[0] = ptr_new ParticleSystem("login_lay_0", true);
		//bg_particle[1] = ptr_new ParticleSystem("login_lay_1", true);
		//bg_particle[2] = ptr_new ParticleSystem("login_lay_2", true);
		//for (U32 i = 0; i < 3; i++)
		//{
		//	bg_particle[i]->SetPosition(Vector3::kZero);
		//	bg_particle[i]->SetRotation(Quaternion::kIdentity);
		//	bg_particle[i]->Reset();
		//}

		white_texture = RESOURCE_LOAD("/common/white_texture.tga", true, Texture);
		black_texture = RESOURCE_LOAD("/common/black_texture.tga", true, Texture);
		screen_vs = RESOURCE_LOAD("/shader/screen_vs.vd9", true, Shader);
		screen_ps = RESOURCE_LOAD("/shader/quad_ps.pd9", true, Shader);

		if (gGame && gGame->camera)
		{
			gGame->camera->position = Vector3(0, -51.591f, 0) / 100.f;
			gGame->camera->rotation = Quaternion(Vector3(1, 0, 0), 8.695f * DEG2RAD);
			gGame->camera->fov = 55;
			gGame->camera->target_fov = 55;
		}

		initialized = true;
	}

	void LoginPipeline::UnInitialize()
	{
		if (!GetInitialized())
			return;

		//for (U32 i = 0; i < 3; i++)
		//	bg_particle[i] = NullPtr;

		bg_texture[0] = NullPtr;
		bg_texture[1] = NullPtr;
		bg_texture[2] = NullPtr;
		bg_texture_wide[0] = NullPtr;
		bg_texture_wide[1] = NullPtr;
		bg_texture_wide[2] = NullPtr;
		white_texture = NullPtr;
		black_texture = NullPtr;
		initialized = false;
	}

	bool LoginPipeline::GetInitialized()
	{
		return initialized;
	}

	void LoginPipeline::Update(F32 frametime)
	{
		if (!GetInitialized())
			return;
		//if(gGame->input->IsKeyPressed(KC_E))
		//{
		//	RECT rc;
		//	rc.left = 0;
		//	rc.right = 400;
		//	rc.top = 0;
		//	rc.bottom = 300;
		//	CWebCtrlBase* pBase = new CWebCtrlBase;
 	//		HWND wnd = CreateWebWindow(&rc,"http://www.baidu.com","",pBase);

		//	PostMessage( wnd, WM_DESTROY, 0, 0 );
		//}
// 		for (U32 i = 0; i < 3; i++)
// 			if (bg_particle[i])
// 				bg_particle[i]->Update(frametime);
	}

	void LoginPipeline::Draw(F32 frame)
	{
		if (!GetInitialized())
			return;

		if (!gGame)
			return;

		if (!gGame->screen)
			return;

		bool wide = fabs(gGame->screen->GetSize().x / gGame->screen->GetSize().y) > (4.f / 3.f) + 0.01f;

		gDx9Device->SetRenderTarget(0, gDx9Device->render_target);
		gDx9Device->SetDepthStencilSurface(NULL);
		gDx9Device->SetDefaultStates();
		gDx9Device->SetRenderState(D3DRS_ZENABLE, false);
		gDx9Device->SetRenderState(D3DRS_ALPHABLENDENABLE, false);

		Matrix44 view, proj;
		if (gGame && gGame->camera)
		{
			gGame->camera->CalculateViewProjectionMatrix(view, proj);
			gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_VIEWPROJ, view * proj);
		}

		Vector4 left_hand(1.f, 1.f, 1.f, 1.f);
		gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_LEFTHAND, &left_hand.x);
		gDx9Device->SetPixelShaderConstantF(PS_CONSTANT_LEFTHAND, &left_hand.x);

		if (screen_vs && screen_vs->IsReady() && screen_ps && screen_ps->IsReady())
		{
			Vector3 vertexs[4] = 
			{
				Vector3(-1,  1, 1),
				Vector3(-1, -1, 1),
				Vector3( 1,  1, 1),
				Vector3( 1, -1, 1),
			};
			Vector4 CameraInfo;
			CameraInfo.x = gGame->camera->GetNear();
			CameraInfo.y = gGame->camera->GetFar();
			CameraInfo.z = gGame->screen->GetSize().x;
			CameraInfo.w = gGame->screen->GetSize().y;

			gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_CAMERAINFO, &CameraInfo.x);
			gDx9Device->SetPixelShaderConstantF(PS_CONSTANT_CAMERAINFO, &CameraInfo.x);
// 			if (screen_vs)	screen_vs->SetShader();
// 			if (screen_ps)	screen_ps->SetShader();
//			gDx9Device->SetAlphaBlend(kBlendNone);
// 			if (bg_texture[0] && !wide)
// 				gDx9Device->SetTexture(COLOR_MAP, bg_texture[0]->GetTexture());
// 			else if (bg_texture_wide[0] && wide)
// 				gDx9Device->SetTexture(COLOR_MAP, bg_texture_wide[0]->GetTexture());
// 			else if (black_texture)
// 				gDx9Device->SetTexture(COLOR_MAP, black_texture->GetTexture());
// 			gDx9Device->SetVertexDeclaration(VD::GetVertexDeclaration(VertexDeclaration::kPosition));
// 			gDx9Device->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP, 2, vertexs, VD::GetVertexDeclarationStride(VertexDeclaration::kPosition));
// 
// 			if (bg_particle[0])	bg_particle[0]->Draw();
// 
// 			if (screen_vs)	screen_vs->SetShader();
// 			if (screen_ps)	screen_ps->SetShader();
//			gDx9Device->SetAlphaBlend(kSourceAlphaAdd);
// 			if (bg_texture[1] && !wide)
// 				gDx9Device->SetTexture(COLOR_MAP, bg_texture[1]->GetTexture());
// 			else if(bg_texture_wide[1] && wide)
// 				gDx9Device->SetTexture(COLOR_MAP, bg_texture_wide[1]->GetTexture());
// 			else if (black_texture)
// 				gDx9Device->SetTexture(COLOR_MAP, black_texture->GetTexture());
// 			gDx9Device->SetVertexDeclaration(VD::GetVertexDeclaration(VertexDeclaration::kPosition));
// 			gDx9Device->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP, 2, vertexs, VD::GetVertexDeclarationStride(VertexDeclaration::kPosition));
// 
// 			if (bg_particle[1])	bg_particle[1]->Draw();

			if (screen_vs)	screen_vs->SetShader();
			if (screen_ps)	screen_ps->SetShader();
			gDx9Device->SetAlphaBlend(kSourceAlphaAdd);
			if (bg_texture[2] && !wide)
				gDx9Device->SetTexture(COLOR_MAP, bg_texture[2]->GetTexture());
			else if (bg_texture_wide[2] && wide)
				gDx9Device->SetTexture(COLOR_MAP, bg_texture_wide[2]->GetTexture());
			else if (black_texture)
				gDx9Device->SetTexture(COLOR_MAP, black_texture->GetTexture());
			gDx9Device->SetVertexDeclaration(VD::GetVertexDeclaration(VertexDeclaration::kPosition));
			gDx9Device->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP, 2, vertexs, VD::GetVertexDeclarationStride(VertexDeclaration::kPosition));

			//if (bg_particle[2])	bg_particle[2]->Draw();
		}
	}
}