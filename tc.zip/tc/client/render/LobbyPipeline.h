
namespace Client
{
	class Character;
	struct CharacterInfo;
	struct WeaponInfo;
	class WeaponBase;
	class StaticMesh;

	class LobbyPipeline : public Core::Object
	{
	public:
		enum LobbyModules
		{
			//���
			L_Mail = 1,        //�ʼ�
			L_FightTeam = 2,   //ս��
			L_Friends = 3,     //����
			L_Chat = 4,        //����
			//�м�
			L_WarZone = 5,     //ս��
			L_Characters = 6,  //��ɫ����
			//�Ҳ�
			L_ShoppingMall = 7,//�̳�
			L_BlackMarket = 8, //����
			L_Compose = 9,     //�ϳ�
			L_TopList = 10,    //���а�
			L_Options = 11,    //����
			L_PersonalInfo = 12,//������ϸ��Ϣ
		};
		enum CamState
		{
			kCameraNone			= -1,

			kCameraIdle			= 0,
			kCameraIdleBack		= 10,

			kCameraUp			= 1,
			kCameraUpBack		= 11,
			kCameraUpShake		= 21,

			kCameraRight		= 2,
			kCameraRightBack	= 12,
			kCameraRightShake	= 22,

			kCameraDown			= 3,
			kCameraDownBack		= 13,
			kCameraDownShake	= 23,

			kCameraLeft			= 4,
			kCameraLeftBack		= 14,
			kCameraLeftShake	= 24,
		};

		enum ActionState
		{
			kChgCharacter,
			kRotCharacterA,
			kRotCharacterB,
			kRotWeapon,
			kRotWeaponBack,	
			kActionNone,
		};

		enum PickType
		{
			kPickCharRot,
			kPickCharChg,
			kPickCharChged,
			kPickModifyWeapon,
			kPickNone,
		};

		enum LobbyState
		{
			kAvatarPreview = 0,
			kWeaponPreview,
			kWeaponModify,
			kSelectCharacter,
		};

		// constructor
		LobbyPipeline();

		// destructor
		~LobbyPipeline();

		// initialize
		void Initialize();

		// UnInitialize
		void UnInitialize();

		// update
		void Update(F32 frame_time);

		// draw
		void Draw(F32 frametime);

		// draw character
		void DrawCharacter(F32 frametime,by_ptr(RenderTexture) rendertexture);

		// pick
		PickType Pick(Core::Vector2 pos, InputEventArgs::EventType type = InputEventArgs::kMouseMove);
		// begin update cursor
		void BeginUpdateCursor();
		// update cursor
		void UpdateCursor(Core::Vector2 pos);

	public:
		// load particle
		void LoadParticle(Core::Identifier& particle);

		// set sun direction
		void SetSunDirection(F32 x, F32 y, F32 z);
		Core::Vector3 m_SunDirection;

		// set shadow direction
		void SetShadowDirection(F32 x, F32 y, F32 z, F32 w);
		Core::Vector4 m_ShadowDirection;

		void SetModifyWeaponSunDir(F32 x, F32 y, F32 z);
		Core::Vector3 m_ModifySunDir;

		// set fog
		void SetFog(F32 i, F32 mind, F32 maxd, F32 r, F32 g, F32 b);
		Core::Vector4 m_FogPara;
		Core::Vector4 m_FogColor;

		// set y fog
		void SetYFog(F32 i, F32 mind, F32 maxd, F32 r, F32 g, F32 b);
		Core::Vector4 m_YFogPara;
		Core::Vector4 m_YFogColor;

		// set intensity
		void SetLightmapIntensity(F32 v);
		void SetAmbientIntensity(F32 v);
		Core::Vector4 m_Intensity;

		// shadow bias
		SIMPLE_PDE_ATTRIBUTE_RW(ShadowBias, F32);

		// avatar
		void SetAvatarPart(U32 team, const Core::Identifier& key);
		//void SetEquipChar(by_ptr(CharacterInfo) character_info);

		// weapon
		void SetWeaponType(U32 side, int type);
		void SetWeaponColor(U32 side, byte color);
		void AddWeaponPart(U32 side, const Core::Identifier& part);
		//void SetWeaponPartBlink(U32 side, const Core::Identifier& part);
			
		// rotate character
		void RotateCharacter();
		// update animation
		void UpdateCharacter(F32 frametime);

		// update weapon
		void UpdateWeapon(F32 frametime);

		// update camera 
		void UpdateCamera(F32 frametime);


		// avatar view
		void AvatarShow(U32 sidee,const Core::Identifier& carrername);

		// set light color
		void SetLightColor(F32 r, F32 g, F32 b);

		// set lobby state
		void SetLobbyState(S32 state);

		// avatar clear
		void AvatarClear(U32 side);


	public:
		// set front position
		void SetFrontPosition(Core::Vector3 position, bool wide_mode);

		// set weapon position
		void SetWeaponPosition(Core::Vector3 position);

		// get weapon position
		Core::Vector3 GetWeaponPosition();

		// set anim time
		void SetAnimTime(F32 time);

		// set camera position
		void SetCameraPosition(Core::Vector3 position);

		// get character screen position
		const Core::Vector2 GetCharacterPositionInScreen(U32 team);

		// set character light
		void SetCharacterLight(const Core::Vector4& p11, const Core::Vector4& p12, const Core::Vector4& p21, const Core::Vector4& p22, const Core::Vector4& p31, const Core::Vector4& p32);

		// set weapon light
		void SetWeaponLight(const Core::Vector4& p11, const Core::Vector4& p12, const Core::Vector4& p21, const Core::Vector4& p22, const Core::Vector4& p31, const Core::Vector4& p32);

		// get initialized
		bool GetInitialized();

		// change modify camera
		void SetWeaponCamera(U32 index, bool force = false);

		// set cam id
		void SetCameraID(U32 id);

		// get other equip
		by_ptr(RenderTexture) GetOtherEquipMap();

		// lobby state
		LobbyState					lobby_state;

		// action state
		ActionState					action_state;
		
		LobbyModules GetLobbyModules(){return m_LobbyModule;}
		void SetLobbyModules(int module){m_LobbyModule = (LobbyModules)module;}

	private:

		// team
		U32							team;

		// anim time
		F32							anim_time;

		// change character time left
		F32							time_left;

		//change character with anim
		bool						change_character_with_anim;

		// back ground
		sharedc_ptr(Texture)			bg_texture;

		// white texture
		sharedc_ptr(Texture)			white_texture;

		// black texture
		sharedc_ptr(Texture)			black_texture;
		
		// particle
		sharedc_ptr(ParticleSystem)	bg_particle;

		// side particle
		sharedc_ptr(ParticleSystem)	side_particle;

		// preview_character
		sharedc_ptr(Character)		preview_character;

		// preview character cache
		sharedc_ptr(Character)		preview_character_cache;

		// character info
		sharedc_ptr(CharacterInfo)	character_info;

		// cache character info
		sharedc_ptr(CharacterInfo)	character_info_cache;



		// weapon info
		sharedc_ptr(WeaponInfo)		weapon_info;

		// weapon info cache
		sharedc_ptr(WeaponInfo)		weapon_info_cache;

		// weapon info modify
		sharedc_ptr(WeaponInfo)		weapon_info_modify;

		// weapon info modify cache
		sharedc_ptr(WeaponInfo)		weapon_info_modify_cache;

		// loading particle
		sharedc_ptr(ParticleSystem)	loading_particle;

		// light color
		Core::Vector4				light_color;

		// shadow bias
		F32							shadow_bias;	

		// character rotation 
		Core::Quaternion			character_rotation;

		// weapon rotation
		F32							weapon_rotation;

		// character position

		Core::Vector3				front_position;
		Core::Vector3				front_position_wide;
		Core::Vector2				old_screen_pos;

		// weapon position
		Core::Vector3				weapon_position;

		// camera
		sharedc_ptr(Camera)			modify_weapon_camera;


		// screen shader
		sharedc_ptr(Shader)			screen_vs;
		sharedc_ptr(Shader)			screen_ps;

		// initialize
		bool						initialized : 1;

		// wide screen mode
		bool						wide_screen : 1;

		// show avatar
		bool						show_avatar;

		// show weapon
		bool						show_weapon;

		// character light
		Core::Vector4				character_light_para[4][2];

		// weapon light
		Core::Vector4				weapon_light_para[4][2];

		// avatar part dirty
		bool						avatar_dirty;

		// weapon dirty
		bool						weapon_dirty;

		// cahce position
		Core::Vector3				cache_weapon_position;



		// camera state
		CamState					cam_state;


	private:
		// one map
		sharedc_ptr(RenderTexture)	one_map;

		// other equip map
		sharedc_ptr(RenderTexture)	other_equip_map;

		// light depth
		sharedc_ptr(RenderTexture)	light_depth;
		sharedc_ptr(RenderTexture)	light_depth_ds;

		// shadow shader
		sharedc_ptr(Shader)			shadow_vs;
		sharedc_ptr(Shader)			shadow_ps;

		// pick shader
		sharedc_ptr(Shader)			pick_ps;
		sharedc_ptr(Shader)			pick_out_ps;
		sharedc_ptr(Shader)			pick_out_vs;

		// shadow dither map
		sharedc_ptr(Texture)			shadow_dither;

		// shine map
		sharedc_ptr(Texture)			shine_map;

		// shadow map
		sharedc_ptr(RenderTexture)	shadow_map;

		// pick target
		sharedc_ptr(RenderTexture)	pick_target;
		
		// pick out color
		sharedc_ptr(RenderTarget)	pick_out_color;

		// down sample ps
		sharedc_ptr(Shader)			down_sample4_ps;

		// gaussian blur h
		sharedc_ptr(Shader)			gaussian_h;

		// gaussian blur w
		sharedc_ptr(Shader)			gaussian_w;

		//depth_ps
		sharedc_ptr(Shader)			depth_ps;

		// blend ps
		sharedc_ptr(Shader)			blend_ps;

		// one ps 
		sharedc_ptr(Shader)			one_ps;

		// edge ps
		sharedc_ptr(Shader)			edge_ps;

		// camera skeleton
		sharedc_ptr(Skeleton)		cam_skeleton;

		// animation 
		sharedc_ptr(AnimationNodeCustom)	animation;

		// source node
		sharedc_ptr(AnimationNodePose) source_node;

		// control node
		sharedc_ptr(AnimationNodePose) control_node;

		// animation set
		sharedc_ptr(AnimationSet)	cam_anim_set[6];

		// last quary
		S32							last_camera_request;

		// pose
		sharedc_ptr(Pose)			cam_pose;

		// joint id
		U32							joint_id;

		// curr camera id
		U32							curr_cam_id;
		LobbyModules                m_LobbyModule;
		LobbyModules                m_OldLobbyModule;
		
		bool						autorotate;
		F32							rotateangle;
	
	public:
		// screen_downsample_map
		sharedc_ptr(RenderTexture)	screen_downsample_map;

		// lobby downsample rt
		sharedc_ptr(RenderTarget)	screen_downsample_rt;

	};
}
