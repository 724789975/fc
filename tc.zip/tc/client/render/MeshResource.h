#define MESH_LOD_LEVEL	3

namespace Client
{
	// primitive
	class Primitive
	{
	public:
		enum DrawType
		{
			kEarlyZ = 0,
			kLightMap,
			kScene,
			kSceneTransparency,
			kCharacterTransparency,
			kCharacterSpecialEffect,
			kShaderManual,
			kNoZBuffer,
		};

		// constructor
		Primitive();

		// destructor
		~Primitive();

		// set stream
		void SetStream();

		// set alpha blend mode
		void SetAlphaBlend();

		// set texture
		bool SetTexture(S32 index = -1);

		// set cull mode
		void SetCullMode(bool inverse);

		// draw
		void Draw(DrawType = kScene, S32 shader_lod = -1);

		// set world matrix
		void SetWorldMatrix();

		// world matrix
		Core::Matrix44*					world_matrix;

		// primitive_count
		U32								primitive_count;

		// vertex_count
		U32								vertex_count;

		// indices
		Core::Array<U32>				indices;

		// material
		sharedc_ptr(Material)			material;

		// layer
		U32								layer;

		// vertex buffer
		sharedc_ptr(StreamBuffer)		vertex_buffer;
		
		// index buffer
		sharedc_ptr(StreamBuffer)		index_buffer;

		// cull mode
		CullMode						cull_mode;

		// blend mode
		AlphaBlendMode					blend_mode;

		// visable
		bool							visible;

		// vertex declaration type
		VertexDeclaration::VertexDeclarationType vd_type;

		// phyical materail
		U32								collision_mode;
	};

	// mesh resource
	class MeshResource : public Resource
	{
	public:
		enum MeshType
		{
			kNoneMesh,
			kStatic,
			kSkin,
			kOther,
			kPartical,
			kCount,
		};

		// constructor
		MeshResource();

		// destructor
		~MeshResource();

	public:
		/// save data
		virtual bool SaveData(Core::Stream & stream);

		/// load data
		virtual sharedc_ptr(Object) LoadData(Core::Stream & stream);

		/// load data
		virtual sharedc_ptr(Object) BuildData();

		/// unload data
		virtual void UnloadData();

		/// on load data
		virtual bool OnLoadData(by_ptr(Object) obj);

		/// get version
		virtual short GetVersion();

	public:
		/// build stream
		void BuildStream();

	private:
		/// build stream static
		void BuildStreamStatic();

		// build stream skin
		void BuildStreamSkin();

	public:
		// initialize
		void Initialize();

		// destory
		void Destory();

		// load
		bool LoadRawData(const Core::Identifier& path, F32 scale);

		// get mesh type
		MeshType	GetMeshType();

		// data
		struct
		{
			Core::Array<Core::Vector3>	vertices;
			Core::Array<Core::Vector3>	normals;
			Core::Array<Core::Vector3>	tangents;
			Core::Array<Core::Vector3>	binormals;
			Core::Array<Core::Vector2>	uv0;
			Core::Array<Core::Vector2>	uv1;
			Core::Array<Core::Vector2>	uv2;
			Core::Array<Core::Vector4>	blendweight;
			Core::Array<int>			blendindices;
			Core::Array<Core::ARGB>		color;

			void Clear()
			{
				vertices.Clear();
				normals.Clear();
				tangents.Clear();
				binormals.Clear();
				uv0.Clear();
				uv1.Clear();
				uv2.Clear();
				blendweight.Clear();
				blendindices.Clear();
				color.Clear();
			}
		}data;

		// blend name
		Core::Array<Core::Identifier>	bonename;

		// bone	aabb
		Core::Array<Core::AxisAlignedBox>	bone_aabb;

		// vertex buffer
		uint	vertex_buffer_size;

		// index buffer
		uint	index_buffer_size;

		// primitives
		Core::Array<Primitive>			primitives;

		// mesh
		sharedc_ptr(Mesh)				mesh;

		// mesh type
		MeshType						mesh_type;

		// full vertex data
		Core::Array<VertexDeclaration::StreamStatic>		vb_stream;

		// full index data
		Core::Array<U32>				ib_stream;

		// aabb
		Core::AxisAlignedBox			local_aabb;

		// physical material
		Core::Array<U32>				physical_material;
	};
}