namespace Client
{
	class Material
	{
	public:
		// constructor();
		Material();

		// destructor
		~Material();

		// choose shader
		bool ChooseShader(S32 lod = -1);

		// set parameter
		bool SetParameter();

		// set vertex shader
		bool SetVertexShader();

		// set pixel shader
		bool SetPixelShader();

		// set texture
		bool SetTexture(S32 index = -1);

		// get vertex shader
		void GetVertexShader(Core::Identifier key);

		// get pixel shader
		void GetPixelShader(Core::Identifier key);

		// load 
		void Load(Lua::LuaState* L, Core::String path);

		// load
		void Load(Core::Stream & stream);

		// save
		void Save(Core::Stream & stream);

		// vertex shader
		Core::Array<sharedc_ptr(Shader)>	vertex_shader;

		// pixel shader
		Core::Array<sharedc_ptr(Shader)>	pixel_shader;

		// vertex shader uniform
		Core::Array<Core::Array<ValueUniformImpl>>		vertex_uniform;

		// pixel shader uniform
		Core::Array<Core::Array<ValueUniformImpl>>		pixel_uniform;

		// pixel shader texture uniform
		Core::Array<Core::Array<TextureUniformImpl>>	texture_uniform;

		// current vertex shader
		tempc_ptr(Shader)				curr_vertex_shader;

		// current pixel shader
		tempc_ptr(Shader)				curr_pixel_shader;

		// vertex level
		U32 vertex_level;

		// pixel level
		U32 pixel_level;
	};
}