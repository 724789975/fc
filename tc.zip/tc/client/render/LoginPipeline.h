namespace Client
{
	class LoginPipeline : public Core::Object
	{
	public:
		// constructor
		LoginPipeline();

		// destructor
		~LoginPipeline();

		// initialize
		void Initialize();

		// Uninitialize
		void UnInitialize();

		// get initialize
		bool GetInitialized();

		// update
		void Update(F32 frametime);

		// draw
		void Draw(F32 frametime);

	private:
		// screen shader
		sharedc_ptr(Shader)			screen_vs;
		sharedc_ptr(Shader)			screen_ps;

		// texture
		sharedc_ptr(Texture)			bg_texture[3];
		sharedc_ptr(Texture)			bg_texture_wide[3];

		// particle
		sharedc_ptr(ParticleSystem)	bg_particle[3];

		// white texture
		sharedc_ptr(Texture)			white_texture;

		// black texture
		sharedc_ptr(Texture)			black_texture;

		// initialized
		bool						initialized;
	};
}