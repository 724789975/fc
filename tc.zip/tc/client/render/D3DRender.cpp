#include "pch.h"
using namespace Core;

namespace Client
{
	D3DRender* gRender = NULL;
}

namespace Client
{
	D3DRender::D3DRender()
		: ingame(false)
		, frame_time(0)
		, initialized(false)
	{
		Initialize();
	}

	D3DRender::~D3DRender()
	{
		Lua::LuaState *L = Lua::LuaState::FromThread();
		L->PushNil();
		L->SetGlobal("cg");

		L->PushNil();
		L->SetGlobal("lg");

		render_pipeline = NullPtr;
		lobby_pipeline = NullPtr;
		lod_control = NullPtr;
	}

	void D3DRender::SetGameState(GameState state)
	{
		switch (state)
		{
		case kLoginEnter:
			lobby_pipeline->UnInitialize();
			render_pipeline->UnInitialize();
			login_pipeline->Initialize();
			break;
		case kBalanceEnter:
		case kLobbyEnter:
		case kSelectCharacterEnter:
		case kGameLeave:
			lobby_pipeline->Initialize();
			render_pipeline->UnInitialize();
			login_pipeline->UnInitialize();
			ingame = false;
			break;

		case kGameEnter:
		case kGameLoadingEnter:
			lobby_pipeline->UnInitialize();
			render_pipeline->Initialize();
			login_pipeline->UnInitialize();
			ingame = true;
			break;
		case kGameLoadingLeave:
			Warm();
			break;	

		case kBalanceLeave:
			break;
		};
	}

	void D3DRender::Initialize()
	{
		if (initialized)
			return;

		//warm_target = ptr_new RenderTexture();
		//warm_target->CreateRenderTexture(1, 1, 1, D3DUSAGE_RENDERTARGET, D3DFMT_A8R8G8B8, true);

		ui_render = ptr_new UIRender(gGame->dx9);
		render_pipeline = ptr_new RenderPipeline();
		lobby_pipeline = ptr_new LobbyPipeline();
		login_pipeline = ptr_new LoginPipeline();
		font_manager = ptr_new FontManager();

		ui_render->font_simhei_12 = font_manager->GetFont("simhei", 12, 0);
		ui_render->font_simhei_14 = font_manager->GetFont("simhei", 14, 0);
		ui_render->font_simhei_16 = font_manager->GetFont("simhei", 16, 0);
		ui_render->font_simhei_20 = font_manager->GetFont("simhei", 20, 0); 
		ui_render->font_simhei_22 = font_manager->GetFont("simhei", 22, 0);
		ui_render->font_simhei_24 = font_manager->GetFont("simhei", 24, 0);
		ui_render->font_simhei_28 = font_manager->GetFont("simhei", 28, 0);
		ui_render->font_simhei_34 = font_manager->GetFont("simhei", 34, 0);
		ui_render->font_simhei_38 = font_manager->GetFont("simhei", 38, 0);
		ui_render->font_simhei_40 = font_manager->GetFont("simhei", 40, 0);
		ui_render->font_simhei_48 = font_manager->GetFont("simhei", 48, 0);
		ui_render->font_simhei_64 = font_manager->GetFont("simhei", 64, 0);

		ui_render->font_yhmo_14 = font_manager->GetFont("simhei", 14, 0);

		ui_render->font_SHOWG_24 = font_manager->GetFont("SHOWG", 24, 0);
		ui_render->font_SHOWG_36 = font_manager->GetFont("SHOWG", 36, 0);
		ui_render->font_SHOWG_48 = font_manager->GetFont("SHOWG", 48, 0);
		ui_render->font_SHOWG_56 = font_manager->GetFont("SHOWG", 56, 0);
		ui_render->font_SHOWG_64 = font_manager->GetFont("SHOWG", 64, 0);
		ui_render->font_SHOWG_72 = font_manager->GetFont("SHOWG", 72, 0);
		ui_render->font_SHOWG_80 = font_manager->GetFont("SHOWG", 80, 0);
		

		Lua::LuaState *L = Lua::LuaState::FromThread();
		L->PushPtr(ptr_static_cast<RenderPipeline>(render_pipeline));
		L->SetGlobal("cg");

		L->PushPtr(ptr_static_cast<LobbyPipeline>(lobby_pipeline));
		L->SetGlobal("lg");

		lod_control = ptr_new LodControl;
		lod_control->Initialize();

		evaluate_mesh = ptr_new StaticMesh("mesh/evaluate");
		evaluate_mesh->AddPrimitive("performanceTest.mesh", 0, true);

		gRender = this;
		initialized = true;
	}

	void D3DRender::Warm()
	{
		//if (!gDx9Device)
		//	return;

		//IDirect3DSurface9* backup = NULL;
		//gDx9Device->GetRenderTarget(0, &backup);

		//if (warm_target)
		//	gDx9Device->SetRenderTarget(0, warm_target->GetSurface());

		//VD::SetVertexDeclaration(VertexDeclaration::kPosition);

		//if (gDx9Device)
		//	gDx9Device->DrawPrimitiveUP(D3DPT_POINTLIST, 1, (void*)&Vector3::kZero.x, sizeof(Vector3));

		//if (backup)
		//	gDx9Device->SetRenderTarget(0, backup);
		//backup->Release();
	}

	tempc_ptr(LobbyPipeline) D3DRender::GetLobby()
	{
		return lobby_pipeline;
	}

	void D3DRender::Update(F32 frametime)
	{
		lod_control->Update(ingame);
		if (ingame && render_pipeline->GetInitialized())
		{
			render_pipeline->Update(frametime);
		}
		else
		{
			if (lobby_pipeline->GetInitialized())
				lobby_pipeline->Update(frametime);

			if (login_pipeline->GetInitialized())
				login_pipeline->Update(frametime);
		}
		frame_time = frametime;
	}

	void D3DRender::Draw()
	{
		if (gDx9Device && gDx9Device->GetStereoEnable())
			NvAPI_Stereo_GetConvergence(gDx9Device->GetStereoHandle(), &gDx9Device->convergence);

		F32 v = 1.f;

		if (gDx9Device->GetStereoEnable() && gDx9Device->convergence > 0)
		{
			v = gDx9Device->convergence;
		}

		gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_CONVERGENCE, &v, 1);

		if (ingame && render_pipeline->GetInitialized())
		{
			render_pipeline->Draw(frame_time);
		}
		else
		{
			if (lobby_pipeline->GetInitialized())
				lobby_pipeline->Draw(frame_time);

			if (login_pipeline->GetInitialized())
				login_pipeline->Draw(frame_time);
		}
	}

	F32 D3DRender::EvaluateHardware()
	{
		if (!gDx9Device)
			return 0;

		if (!gGame)
			return 0;

		if (!gRender)
			return 0;

		gDx9Device->EndScene();
		gDx9Device->Present(NULL, NULL, NULL, NULL);

		gDx9Device->SetRestore();

		Camera camera;
		camera.position = Vector3::kZero;
		camera.last_position = Vector3::kZero;
		camera.rotation.SetIdentity();
		camera.LookAt(Vector3(0, 0, 1), Vector2::kZero);
		camera.SetNear(0.001f);
		camera.SetFar(100.f);
		camera.UpdateAspect(Vector2(800, 600));

		Matrix44 view, proj;
		camera.CalculateViewProjectionMatrix(view, proj);

		gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_WORLD, Matrix44::kIdentity);
		gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_VIEWPROJ, view * proj);
		gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_VIEW, view);

		evaluate_mesh->SetPosition(Vector3(0, 0, -2));

		sharedc_ptr(GameConfig) config = ptr_new GameConfig;
		config->SetMSAA(0);
		config->SetSysResolution(Vector2(800, 600));
		config->SetVSync(false);

		sharedc_ptr(GameConfig) temp = gGame->config;
		gGame->config = config;

		gDx9Device->SetDeviceLost();

		for (U32 i = 0; i < 20; i++)
		{
			if (gDx9Device->IsDeviceLost())
			{
				Core::LogSystem.WriteLinef("Device Reset Fail Time = %d", i);
				gDx9Device->DeviceLost();
				Sleep(100);
			}
		}

		RenderTexture target;
		target.CreateRenderTexture(800, 600, 1, D3DUSAGE_RENDERTARGET, D3DFMT_A8R8G8B8, 1);
		target.CreateDepthStencil(D3DFMT_D24S8, true);
		gDx9Device->SetRenderTarget(0, target.GetSurface());
		gDx9Device->SetDepthStencilSurface(target.GetDepthStencilSurface());

		gDx9Device->BeginScene();
		evaluate_mesh->Draw(Primitive::kScene, true);
		gDx9Device->EndScene();
		gDx9Device->Present(NULL, NULL, NULL, NULL);

		F32 out = 0;

		LARGE_INTEGER  start_ticks;
		LARGE_INTEGER  end_ticks;
		LARGE_INTEGER  frequency;

		U32 count = 1000;

		QueryPerformanceCounter(&start_ticks);
		QueryPerformanceFrequency(&frequency);

		for (U32 i = 0; i < count; i++)
		{
			gDx9Device->BeginScene();
			gDx9Device->SetRenderTarget(0, target.GetSurface());
			gDx9Device->SetDepthStencilSurface(target.GetDepthStencilSurface());
			gDx9Device->Clear(0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER | D3DCLEAR_STENCIL, 0x7f7f7f, 1.f, 0);
			evaluate_mesh->Draw(Primitive::kScene, true);
			gDx9Device->EndScene();
			gDx9Device->SetRenderTarget(0, gDx9Device->render_target);
			gDx9Device->SetDepthStencilSurface(gDx9Device->depth_stencil);
			gDx9Device->Present(NULL, NULL, NULL, NULL);
		}
		QueryPerformanceCounter(&end_ticks);
		out += (double)(end_ticks.QuadPart - start_ticks.QuadPart) / (double)frequency.QuadPart;

		gDx9Device->Clear(0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER | D3DCLEAR_STENCIL, 0x7f7f7f, 1.f, 0);
		out = count / out;

		gGame->config = temp;
		gDx9Device->DeviceLost();
		Sleep(1000);

		Core::LogSystem.WriteLinef("perf count = %g", out);

		return out;
	}
}