#include "pch.h"
using namespace Core;

namespace Client
{
    inline F32 GetRandom(F32 min, F32 max)
    {
        F32 randNum = (F32)rand() / RAND_MAX;
        F32 num = min + (max - min) * randNum;
        return num;
    }

	inline F32 ChooseRandom(F32 first, F32 second)
	{
		F32 randNum = GetRandom(0.0f, 1.0f);
		if (randNum >= 0.5f)
			return second;
		return first;
	}
}

namespace Client
{
	ParticleManager::ParticleManager()
		: m_bShowParticle(true)
	{	
		draw_particle_array.Reserve(128);

		particle_resources.PushBack(RESOURCE_LOAD("/vfx/vfx_bullet_concrete.vfx", true, ParticleResource));
		particle_resources.PushBack(RESOURCE_LOAD("/vfx/vfx_bullet_wood.vfx", true, ParticleResource));
		particle_resources.PushBack(RESOURCE_LOAD("/vfx/vfx_bullet_metal.vfx", true, ParticleResource));
		particle_resources.PushBack(RESOURCE_LOAD("/vfx/vfx_bullet_water.vfx", true, ParticleResource));
		particle_resources.PushBack(RESOURCE_LOAD("/vfx/vfx_grenade_trail.vfx", true, ParticleResource));
		particle_resources.PushBack(RESOURCE_LOAD("/vfx/vfx_grenade_explosion.vfx", true, ParticleResource));
	}

	ParticleManager::~ParticleManager()
	{
		Clear();
		particle_resources.Clear();
		SAFE_RELEASE(Emitter::m_InstanceData);
		SAFE_RELEASE(Emitter::m_InstanceVB);
		SAFE_RELEASE(Emitter::m_InstanceIB);
		Emitter::instance_size = 0;
	}

	void ParticleManager::DeviceCreate()
	{
		SAFE_RELEASE(Emitter::m_InstanceData);
		Emitter::instance_size = 1024;
		gDx9Device->CreateVertexBuffer(Emitter::instance_size, D3DUSAGE_DYNAMIC | D3DUSAGE_WRITEONLY, 0, D3DPOOL_DEFAULT, &Emitter::m_InstanceData, NULL);
	}

	void ParticleManager::DeviceLost()
	{
		SAFE_RELEASE(Emitter::m_InstanceData);
	}
	
	void ParticleManager::DeviceReset()
	{
		gDx9Device->CreateVertexBuffer(Emitter::instance_size, D3DUSAGE_DYNAMIC | D3DUSAGE_WRITEONLY, 0, D3DPOOL_DEFAULT, &Emitter::m_InstanceData, NULL);
	}

	void ParticleManager::DeviceDestory()
	{
		DeviceLost();
		SAFE_RELEASE(Emitter::m_InstanceData);
		SAFE_RELEASE(Emitter::m_InstanceVB);
		SAFE_RELEASE(Emitter::m_InstanceIB);
	}

	void ParticleManager::Clear()
	{
		LinkNode<ParticleSystem*> * node = particle_list.Front();
		while (node)
		{
			LinkNode<ParticleSystem*> * node_next = node->GetNext();

			particle_list.Remove(node);
			ptr_static_cast<ParticleSystem>(node->data).GetPtrData()->Release();

			node = node_next;
		}

		particle_list.Clear();

		draw_particle_array.Clear();
	}

	void ParticleManager::Update(F32 frametime)
	{
		LinkNode<ParticleSystem*> * node = particle_list.Front();

		while (node)
		{
			LinkNode<ParticleSystem*> * node_next = node->GetNext();

			node->data->DirtyCheck();

			if (node->data->IsReady() && node->data->IsDead())
			{
				particle_list.Remove(node);
				ptr_static_cast<ParticleSystem>(node->data).GetPtrData()->Release();
			}
			else
			{
				node->data->Update(frametime);
			}

			node = node_next;
		}

	}

	void ParticleManager::Draw(bool first_person)
	{
		PROFILE("RenderPipeline::DrawParticle");

		if (!particle_list.Size() || !m_bShowParticle)
			return;

		if (!gDx9Device)
			return;

		if (gDx9Device->IsDeviceLost())
			return;

		draw_particle_array.Clear();

		LinkNode<ParticleSystem*> * node = particle_list.Front();
		while (node)
		{
			draw_particle_array.PushBack(node->data);
			node = node->GetNext();
		}

		struct SortFunc
		{
			bool operator() (const ParticleSystem* left, const ParticleSystem* right) const
			{
				if ((left->m_Position - gGame->camera->position).Length() < (right->m_Position - gGame->camera->position).Length())
				{
					return false;
				}
				return true;
			}
		};

		if (draw_particle_array.Size())
		{
			quick_sort(&draw_particle_array[0], draw_particle_array.Size(), SortFunc());
		}

		gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_WORLD, Matrix44::kIdentity);

		if (first_person)
		{
			for(U32 i = 0; i < draw_particle_array.Size(); i++)
			{
				if (!draw_particle_array[i]->IsDead() && draw_particle_array[i]->IsFirstPersonMode())
				{
					draw_particle_array[i]->Draw();
				}
			}
		}
		else
		{
			for(U32 i = 0; i < draw_particle_array.Size(); i++)
			{
				if (!draw_particle_array[i]->IsDead() && !draw_particle_array[i]->IsFirstPersonMode())
				{
					draw_particle_array[i]->Draw();
				}
			}
		}
	}

	tempc_ptr(ParticleSystem) ParticleManager::AddParticle(const Identifier & key, const Vector3 & position, const Vector3 & normal)
	{		
		sharedc_ptr(ParticleSystem) particle = ptr_new ParticleSystem(key);
		
		Vector3 n = Normalize(normal);
		Vector3 pos = position + n * 0.015f;

		Quaternion rot(Vector3(0, 1, 0), n);
		rot.Normalize();

		particle->SetPosition(pos);
		particle->SetRotation(rot);

		return AddParticle(particle);
	}

	tempc_ptr(ParticleSystem) ParticleManager::AddParticle(const Identifier & key, const Vector3 & position, const Quaternion & q)
	{
		sharedc_ptr(ParticleSystem) particle = ptr_new ParticleSystem(key);
		
		Vector3 n = q.GetZXY();

		Vector3 pos = position + n * 0.015f;

		particle->SetPosition(pos);
		particle->SetRotation(q);

		return AddParticle(particle);
	}

	tempc_ptr(ParticleSystem) ParticleManager::AddParticle(by_ptr(ParticleSystem) particle)
	{
		if (particle)
		{
			particle->Reset();

			if (particle->IsReady())
				particle->Update(0);

			if (!particle->m_LinkNode.GetList())
			{
				particle_list.PushBack(&particle->m_LinkNode);
				particle.GetPtrData()->AddRef();
			}
		}

		return particle;
	}

	void ParticleManager::RemoveParticle(by_ptr(ParticleSystem) particle)
	{
		if (particle && particle->m_LinkNode.GetList() == &particle_list)
		{
			particle_list.Remove(&particle->m_LinkNode);
			particle.GetPtrData()->Release();
		}
	}

	void ParticleManager::SetVisible( bool bshow )
	{
		m_bShowParticle = bshow;
	}
}

// particle
namespace Client
{
	Particle::Particle()
		: m_Position(Vector3::kZero)
		, m_Rotation(Vector3::kZero)
		, m_Velocity(Vector3::kZero)
		, m_AngleVelocity(Vector3::kZero)
		, m_InitSize(Vector3::kZero)
		, m_Color(ARGB(0, 0, 0, 0))
		, m_AnimationFirstFrame(0)
		, m_AnimationLastFrame(0)
		, m_AnimationCurrentColumn(0)
		, m_AnimationCurrentRow(0)
		, m_ParticleTime(0)
		, m_ParticleLifeTime(0)
		, m_SampleTime(0)
		, m_ParticleSize(Vector2::kZero)
		, m_InitXYZScale(0)
		, m_InitStretch(0)
		, m_InitAcceleration(0)
		, m_InitResistance(0)
		, m_InitGravity(0)
		, m_InitTurbulence3D(0)
		, m_InitTurbulenceSize(0)
		, m_InitTurbulenceSpeed(0)
		, m_Turbulence(Vector3::kZero)
		, m_InitAngleZVelocity(0)
		, m_InitColor(Vector3::kZero)
		, m_InitColorEmissive(Vector3::kZero)
		, m_InitAlpha(0)	
		, m_RelativePosition(Vector3::kZero)	
	{
	}

	Particle::~Particle()	
	{
	}
}

// emitter
namespace Client
{
	IDirect3DVertexBuffer9* Emitter::m_InstanceVB = NULL;
	IDirect3DIndexBuffer9*  Emitter::m_InstanceIB = NULL;
	IDirect3DVertexBuffer9* Emitter::m_InstanceData = NULL;
	U32						Emitter::instance_size = 0;

	Emitter::Emitter()
		: m_Enable(false)
		, m_MaxParticles(16)
		, m_ActiveParticles(0)
		, m_SpawnFraction(1)
		, m_SampleTime(0)
		, m_EmitterTime(0)
		, m_EmitterLife(0)
		, m_EmitterLifeTimeInverse(0)
		, m_DelayTime(0)
		, m_Loop(0)
		, m_InitCount(0)
		, m_InitEmissionRate(0)
		, m_InitEmissionNum(0)
		, m_InitAngle(0)
		, m_InitOffset(Vector2::kZero)
		, m_InitFocusAngle(0)
		, m_InitFocusAzimuth(0)
		, m_Position(Vector3::kZero)
		, m_Rotation(Quaternion::kIdentity)
		, m_TrailDirection(Vector3(1, 0, 0))
	{
		Resize();
		if(gGame && gGame->camera)
		{
			m_CameraUpDirection	= Vector3(0, 1, 0) * gGame->camera->rotation;
		}
	}

	Emitter::~Emitter()	
	{
	}

	void Emitter::InitParticle(Particle& particle)
	{
		if (!m_EmitterData)
			return;

		memset(&particle, 0, sizeof(particle));
		particle.m_ParticleLifeTime		= m_EmitterData->GetParticleLife()->GetEmitLifeValue(m_EmitterData->GetParticleLife()->GetInitial(), m_SampleTime);
		particle.m_InitSize				= m_EmitterData->GetParticleSize()->GetEmitLifeValue(m_EmitterData->GetParticleSize()->GetInitial(), m_SampleTime);
		particle.m_InitStretch			= m_EmitterData->GetStretch()->GetEmitLifeValue(m_EmitterData->GetStretch()->GetInitial(), m_SampleTime);
		particle.m_InitAcceleration		= m_EmitterData->GetAcceleration()->GetEmitLifeValue(m_EmitterData->GetAcceleration()->GetInitial(), m_SampleTime);
		particle.m_InitResistance		= m_EmitterData->GetResistance()->GetEmitLifeValue(m_EmitterData->GetResistance()->GetInitial(), m_SampleTime);
		particle.m_InitGravity			= m_EmitterData->GetGravity()->GetEmitLifeValue(m_EmitterData->GetGravity()->GetInitial(), m_SampleTime);
		particle.m_InitTurbulence3D		= m_EmitterData->GetTurbulence3D()->GetEmitLifeValue(m_EmitterData->GetTurbulence3D()->GetInitial(), m_SampleTime);
		particle.m_InitTurbulenceSize	= m_EmitterData->GetTurbulenceSize()->GetEmitLifeValue(m_EmitterData->GetTurbulenceSize()->GetInitial(), m_SampleTime);
		particle.m_InitTurbulenceSpeed	= m_EmitterData->GetTurbulenceSpeed()->GetEmitLifeValue(m_EmitterData->GetTurbulenceSpeed()->GetInitial(), m_SampleTime);
		particle.m_Rotation.z			= DegreeToRadian(m_EmitterData->GetInitAngleZ()->GetEmitLifeValue(m_EmitterData->GetInitAngleZ()->GetInitial(), m_SampleTime));
		particle.m_InitAngleZVelocity	= m_EmitterData->GetAngleZVelocity()->GetEmitLifeValue(m_EmitterData->GetAngleZVelocity()->GetInitial(), m_SampleTime);
		particle.m_InitColor			= m_EmitterData->GetColor()->GetEmitLifeValue(m_EmitterData->GetColor()->GetInitial(), m_SampleTime);
		particle.m_InitColorEmissive	= m_EmitterData->GetColorEmissive()->GetEmitLifeValue(m_EmitterData->GetColorEmissive()->GetInitial(), m_SampleTime);
		particle.m_InitXYZScale			= m_EmitterData->GetXYZScale()->GetEmitLifeValue(m_EmitterData->GetXYZScale()->GetInitial(), m_SampleTime);
		particle.m_InitAlpha			= m_EmitterData->GetAlpha()->GetEmitLifeValue(m_EmitterData->GetAlpha()->GetInitial(), m_SampleTime);

		F32 FocusAngle = DegreeToRadian(m_EmitterData->GetFocusAngle()->GetEmitLifeValue(m_InitFocusAngle, m_SampleTime));
		F32 FocusAzimuth = DegreeToRadian(m_EmitterData->GetFocusAzimuth()->GetEmitLifeValue(m_InitFocusAzimuth, m_SampleTime));
		Vector3 ShootDir(Cos(FocusAzimuth) * Sin(FocusAngle), Cos(FocusAngle), Sin(FocusAzimuth) * Sin(FocusAngle));
		ShootDir.Normalize();

		Quaternion Angle(Vector3(0.f, 1.f, 0.f), ShootDir);	
		F32 EmitAngle = DegreeToRadian(m_EmitterData->GetEmitAngle()->GetEmitLifeValue(m_InitAngle, m_SampleTime));
		F32 ShootPlaneRadius = Tan(EmitAngle);
		if (abs(EmitAngle - HALFPI) < EPSILON)
			ShootPlaneRadius = 1.f;
		F32 ShootPlaneX = GetRandom(-ShootPlaneRadius, ShootPlaneRadius);
		F32 ShootPlaneZ = ChooseRandom(-Sqrt(ShootPlaneRadius * ShootPlaneRadius - ShootPlaneX * ShootPlaneX), Sqrt(ShootPlaneRadius * ShootPlaneRadius - ShootPlaneX * ShootPlaneX));
		Vector3 EmitAngleDir(ShootPlaneX, 1.f, ShootPlaneZ);
		if(abs(EmitAngle - HALFPI) < EPSILON)
		{
			EmitAngleDir.y = 0.f;
		}
		else if (EmitAngle > HALFPI)
		{
			EmitAngleDir.y = -1.f;
		}
		ShootDir = Normalize(EmitAngleDir * Angle * m_Rotation);

		switch (m_EmitterData->GetEmitterType())
		{
		case ParticleResource::kEmitterPoint:
		case ParticleResource::kEmitterNumber:
			{
				particle.m_RelativePosition = GetOffset() * m_Rotation;
				particle.m_Velocity = ShootDir * m_EmitterData->GetSpeed()->GetEmitLifeValue(m_EmitterData->GetSpeed()->GetInitial(), m_SampleTime);
				break;
			}
		case ParticleResource::kEmitterPlane:
			{
				Vector3 Offset = m_EmitterData->GetEmitSize()->GetEmitLifeValue(m_InitEmitSize, m_SampleTime);
				Offset = Vector3(GetRandom(-Offset.x * 0.5, Offset.x * 0.5), 0.f, GetRandom(-Offset.z * 0.5, Offset.z * 0.5));
				particle.m_RelativePosition = GetOffset() + Offset * Angle * m_Rotation;
				particle.m_Velocity = ShootDir * m_EmitterData->GetSpeed()->GetEmitLifeValue(m_EmitterData->GetSpeed()->GetInitial(), m_SampleTime);
				break;
			}
		case ParticleResource::kEmitterCube:
			{
				Vector3 ShootDir(0, 0, 0);
				U32 choose = GetRandom(0, 5);
				ShootDir[choose / 2] = (choose % 2) ? -1 : 1;
				Vector3 Offset = m_EmitterData->GetEmitSize()->GetEmitLifeValue(m_InitEmitSize, m_SampleTime);
				Offset = Vector3(GetRandom(-Offset.x * 0.5, Offset.x * 0.5), GetRandom(-Offset.y * 0.5, Offset.y * 0.5), GetRandom(-Offset.z * 0.5, Offset.z * 0.5));
				particle.m_RelativePosition = Offset;
				particle.m_Velocity = ShootDir * m_EmitterData->GetSpeed()->GetEmitLifeValue(m_EmitterData->GetSpeed()->GetInitial(), m_SampleTime);
				break;
			}
		case ParticleResource::kEmitterTrail:
			{
				particle.m_RelativePosition = GetOffset() * m_Rotation;
				particle.m_Position = GetOffset() * m_Rotation;
				particle.m_Velocity = Vector3::kZero;
				break;
			}
		}

		if (m_EmitterData->m_RandomFirstFrame)
			//particle.m_AnimationFirstFrame = GetRandom(m_EmitterData->m_RandomRange.x, m_EmitterData->m_RandomRange.y) - 1;
		{
			F32 r = GetRandom(m_EmitterData->m_RandomRange.x, m_EmitterData->m_RandomRange.y);
			if (r - floor(r) > 0.5f)
				particle.m_AnimationFirstFrame = Ceil(r) - 1;
			else
				particle.m_AnimationFirstFrame = Floor(r) - 1;
		}
		else
			particle.m_AnimationFirstFrame = m_EmitterData->m_AnimationFirstFrame - 1;
		particle.m_AnimationLastFrame = m_EmitterData->m_AnimationLastFrame - 1;

        F32 turb3DX = GetRandom(-particle.m_InitTurbulence3D, particle.m_InitTurbulence3D);
        F32 turb3DY = GetRandom(-Sqrt(particle.m_InitTurbulence3D * particle.m_InitTurbulence3D - turb3DX * turb3DX), Sqrt(particle.m_InitTurbulence3D * particle.m_InitTurbulence3D - turb3DX * turb3DX));
        F32 turb3DZ = ChooseRandom(-Sqrt(particle.m_InitTurbulence3D * particle.m_InitTurbulence3D - turb3DX * turb3DX - turb3DY * turb3DY), Sqrt(particle.m_InitTurbulence3D * particle.m_InitTurbulence3D - turb3DX * turb3DX - turb3DY * turb3DY));
		particle.m_Turbulence = Vector3(turb3DX, turb3DY, turb3DZ);
		
		if (m_EmitterData->GetCoordinateType() == ParticleResource::kWorld)
			particle.m_RelativePosition += m_Position;
	}

	void Emitter::Resize()
	{
		while(m_MaxParticles < m_ActiveParticles)
			m_MaxParticles += 16;

		U32 oldsize = ParticleIndex.Size();

		ParticleIndex.Resize(m_MaxParticles);

		for (U32 i = oldsize; i < ParticleIndex.Size(); i++)
			ParticleIndex[i] = i;

		if (m_MaxParticles * VD::GetParticleInstanceStride() > instance_size)
		{
			SAFE_RELEASE(m_InstanceData);
			instance_size = m_MaxParticles * sizeof(VertexDeclaration::StreamParticle);
		}

		//if (!gDx9Device)
		//	return;

		//if (gDx9Device->IsDeviceLost())
		//	return;

		//if (m_MaxParticles * VD::GetParticleInstanceStride() > instance_size)
		//{
		//	SAFE_RELEASE(m_InstanceData);
		//	instance_size = m_MaxParticles * sizeof(VertexDeclaration::StreamParticle);
		//	gDx9Device->CreateVertexBuffer(instance_size, D3DUSAGE_DYNAMIC, 0, D3DPOOL_DEFAULT, &m_InstanceData, NULL);
		//}
	}

	void Emitter::SetPosition(const Vector3& position)
	{
		m_Position = position;
	}

	void Emitter::SetRotation(const Quaternion& rotation)
	{
		m_Rotation = rotation;
	}

	void Emitter::Update(F32 frametime)
	{
		PROFILE("Emitter::Update");
		if (!GetEnable())
			return;

		if (!m_EmitterData)
			return;

		m_EmitterTime += frametime;
		m_SampleTime += frametime * m_EmitterLifeTimeInverse;
		if (m_SampleTime > 1)
			m_SampleTime -= 1;

		if (m_EmitterData->GetEmitterType() == ParticleResource::kEmitterTrail)
		{
			m_SpawnFraction += frametime;

			if (m_SpawnFraction > m_EmitterLife)
			{
				m_SpawnFraction = 0;

				if (m_ActiveParticles > 1)
				{
					Particle & particle = m_ParticleArray[m_ActiveParticles - 1];
					particle.m_RelativePosition = particle.m_Position;
				}

				for (S32 i = m_ActiveParticles - 1; i > 0; i--)
				{
					Particle& particle = m_ParticleArray[ParticleIndex[i]];
					Particle& particle_prev = m_ParticleArray[ParticleIndex[i-1]];

					particle.m_Velocity = (particle_prev.m_Position - particle.m_Position) / m_EmitterLife;
					particle.m_Position = particle_prev.m_Position;

					U32 AnimationCurrentFrame = i;
					particle.m_AnimationCurrentColumn = AnimationCurrentFrame % m_EmitterData->m_AnimationColumns;
					particle.m_AnimationCurrentRow = AnimationCurrentFrame / m_EmitterData->m_AnimationColumns;
					particle.m_AngleVelocity = particle_prev.m_AngleVelocity;
				}
				if (m_ActiveParticles > 1)
				{
					Particle& particle = m_ParticleArray[ParticleIndex[0]];
					Particle& particle_next = m_ParticleArray[ParticleIndex[1]];
					particle.m_Position = m_Position;
					particle.m_Velocity = (particle.m_Position - particle_next.m_Position) / m_EmitterLife;

					U32 AnimationCurrentFrame = 0;
					particle.m_AnimationCurrentColumn = AnimationCurrentFrame % m_EmitterData->m_AnimationColumns;
					particle.m_AnimationCurrentRow = AnimationCurrentFrame / m_EmitterData->m_AnimationColumns;

					Vector3 CameraDirection = (Vector3(0, 0, 1) * gGame->camera->rotation).Normalize();
					Vector3 CameraUp = (Vector3(0, 1, 0) * gGame->camera->rotation).Normalize();
					if (fabs(Dot(Normalize(particle.m_Velocity), CameraDirection) - 1.f) < 0.0005f)
						particle.m_AngleVelocity = Cross(particle.m_Velocity, CameraUp).Normalize();
					else
						particle.m_AngleVelocity = Cross(particle.m_Velocity, CameraDirection).Normalize();
				}

				if (m_EmitterTime < m_DelayTime)
				{
					for (U32 i = 0; i < m_ActiveParticles; i++)
					{
						m_ParticleArray[ParticleIndex[i]].m_Position = m_Position;
					}
				}

				if (m_Loop > 0)
				{
					m_Loop--;
					if (m_Loop == 0)
						m_Enable = false;
				}
			}
		}
		else
		{
			KillDead();

			for (S32 i = m_ActiveParticles - 1; i >= 0; i--)
			{
				if (ParticleIndex.Size() <= (U32)i)
					continue;

				if (m_ParticleArray.Size() <= (U32)ParticleIndex[i])
					continue;

				Particle& particle = m_ParticleArray[ParticleIndex[i]];
				particle.m_ParticleTime += frametime;
				particle.m_SampleTime += (1.f / particle.m_ParticleLifeTime) * frametime;

				F32 turbulence_size = m_EmitterData->GetTurbulenceSize()->GetParticleLifeValue(particle.m_InitTurbulenceSize, particle.m_SampleTime);
				F32 turbulence_speed = m_EmitterData->GetTurbulenceSpeed()->GetParticleLifeValue(particle.m_InitTurbulenceSpeed, particle.m_SampleTime) / 1000.f;
				if (turbulence_size > 0 && turbulence_speed > 0)
				{
					F32 turb_peri = 2.f * PI * turbulence_size;
					F32 turb_dist = turbulence_speed * particle.m_ParticleTime;
					F32 turb_radian = turb_dist / turbulence_size;
					Vector3 turb_vec(Cos(turb_radian), 0.f, sin(turb_radian));
					turb_vec.Normalize();
					turb_vec *= turbulence_speed;
					F32 turb_value = particle.m_Turbulence.Length();
					F32 turbulence_3d = m_EmitterData->GetTurbulence3D()->GetParticleLifeValue(particle.m_InitTurbulence3D, particle.m_SampleTime);
					F32 turb3DX = GetRandom(-turb_value, turb_value);
					F32 turb3DY = GetRandom(-Sqrt(turb_value * turb_value - turb3DX * turb3DX), Sqrt(turb_value * turb_value - turb3DX * turb3DX));
					F32 turb3DZ = ChooseRandom(-Sqrt(turb_value * turb_value - turb3DX * turb3DX - turb3DY * turb3DY), Sqrt(turb_value * turb_value - turb3DX * turb3DX - turb3DY * turb3DY));
					Vector3 turb3DVec(turb3DX, turb3DY, turb3DZ);
					if (particle.m_SampleTime > 0.0f)
					{
						particle.m_Turbulence = particle.m_Turbulence * (1.0f - m_EmitterData->GetTurbulenceSmooth()) + Vector3(turb3DX, turb3DY, turb3DZ) * m_EmitterData->GetTurbulenceSmooth();
						particle.m_Turbulence.Normalize();
						particle.m_Turbulence *= turb_value;
					}
					particle.m_Velocity += turb_vec;
					particle.m_Velocity += particle.m_Turbulence;
				}

				particle.m_Velocity.y	+= GetGravity(particle) * frametime;
				particle.m_Color		= GetColor(particle);
				particle.m_Color.a		= Clamp(GetAlpha(particle) * 255.f, 0, 255);

				F32 resistance = GetResistance(particle) * 0.001f;
				F32 ratio = 1;
				if (resistance > 0)
				{
					if (resistance > EPSILON * 0.001f)
					{
						ratio = (Pow(NATURALE, (1.0f - resistance) * (particle.m_ParticleLifeTime - particle.m_ParticleTime)) - 1.0f) / (Pow(NATURALE, particle.m_ParticleLifeTime) - 1);
					}
				}
				if (m_EmitterData->GetCoordinateType() == ParticleResource::kLocal)
				{
					particle.m_RelativePosition += particle.m_Velocity * frametime * ratio;
					particle.m_Position = m_Position + particle.m_RelativePosition;
				}
				else
				{
					particle.m_RelativePosition += particle.m_Velocity * frametime * ratio;
					particle.m_Position = particle.m_RelativePosition;
				}
				particle.m_Rotation.z += DegreeToRadian(GetAngleVelocity(particle) * frametime);

				particle.m_ParticleSize = /*particle.m_InitSize*/GetParticleSize(particle) * GetXYZScale(particle);
				particle.m_ParticleSize.y += Length(particle.m_Velocity) * GetStretch(particle) * frametime;

				particle.m_Velocity	+= Normalize(particle.m_Velocity) * GetAcceleration(particle) * frametime;

				U32 AnimationCurrentFrame = 0;
				U32 Step = particle.m_AnimationLastFrame - particle.m_AnimationFirstFrame + 1;
				////hack ix
				if (Step == 0)
				{
					Console.WriteLinef("Emitter::Update() : Step == 0");
					Step = 1;
				}

				if (m_EmitterData->m_AnimationLoop)
				{
					AnimationCurrentFrame = particle.m_AnimationFirstFrame + (S32)(particle.m_SampleTime / (1.f / (m_EmitterData->m_AnimationLoop * Step)))% Step;
				}
				else
				{
					AnimationCurrentFrame = particle.m_AnimationFirstFrame + (S32)(particle.m_SampleTime * m_EmitterData->m_AnimationFPS) % Step;
				}

				particle.m_AnimationCurrentColumn = AnimationCurrentFrame % m_EmitterData->m_AnimationColumns;
				particle.m_AnimationCurrentRow = AnimationCurrentFrame / m_EmitterData->m_AnimationColumns;

			}
			if (m_EmitterTime < m_DelayTime)
				return;

			if (m_EmitterData->GetEmitterType() != ParticleResource::kEmitterNumber)
			{
				if (m_Loop == 0)
				{
					if (m_EmitterTime > m_EmitterLife)
					{
						Reset();
					}
					if (GetEmissionRate() > 0.f)
					{
						Spawn(frametime);
					}
				}
				else if(m_EmitterTime < m_Loop * m_EmitterLife)
				{
					if (GetEmissionRate() > 0.f)
					{
						Spawn(frametime);
					}
				}
			}

			struct SortFunc
			{
				bool operator() (const Particle& left, const Particle& right) const
				{
					if ((left.m_Position - gGame->camera->position).Length() > (right.m_Position - gGame->camera->position).Length())
					{
						return false;
					}
					return true;
				}
			};

			if (m_ParticleArray.Size() && m_EmitterData->m_Sort)
			{
				quick_sort(&m_ParticleArray[0], m_ParticleArray.Size(), SortFunc());
			}
		}
	}

	void Emitter::KillDead()
	{
		for (S32 i = m_ActiveParticles - 1; i >= 0; i--)
		{
			if (ParticleIndex.Size() <= (m_ActiveParticles - 1))
				continue;

			const U32 CurrentIndex = ParticleIndex[i];
			Particle& particle = m_ParticleArray[CurrentIndex];

			if (particle.m_SampleTime > 1.0f)
			{
				ParticleIndex[i] = ParticleIndex[m_ActiveParticles - 1];
				ParticleIndex[m_ActiveParticles - 1] = CurrentIndex;
				m_ActiveParticles--;
			}
		}
	}

	void Emitter::BuildStream()
	{
		if (!m_Enable || !m_ActiveParticles)	return;

		if (!gDx9Device)
			return;

		if (gDx9Device->IsDeviceLost())
			return;

		VertexDeclaration::StreamParticle* pVerts;

		if (!m_InstanceData)
		{
			gDx9Device->CreateVertexBuffer(instance_size, D3DUSAGE_DYNAMIC| D3DUSAGE_WRITEONLY, 0, D3DPOOL_DEFAULT, &m_InstanceData, NULL);
		}

		HRESULT hr;
		if (m_InstanceData)
			hr = m_InstanceData->Lock(0, m_ActiveParticles * sizeof(VertexDeclaration::StreamParticle), (void**)&pVerts, D3DLOCK_DISCARD);
		else
			return;

		if (SUCCEEDED(hr))
		{
			for(S32 i = m_ActiveParticles - 1; i >= 0; i--)
			{
				if (i >= (S32)ParticleIndex.Size())
					continue;

				if (ParticleIndex[i] >= m_ParticleArray.Size())
					continue;

				Particle particle = m_ParticleArray[ParticleIndex[i]];

				pVerts[i].Position = particle.m_Position;
				if (Length(particle.m_Velocity) < EPSILON)
				{
					pVerts[i].Velocity = Normalize(Vector3::kOne);
				}
				else
				{
					pVerts[i].Velocity = particle.m_Velocity;
				}
				



				pVerts[i].Rotation		= particle.m_Rotation;
				pVerts[i].Size			= particle.m_ParticleSize;
				if(m_EmitterData->GetParticleType() == ParticleResource::kFollowVelocity)
				{
					pVerts[i].Rotation = m_CameraUpDirection;
					pVerts[i].Size.z = particle.m_Rotation.z;
				}
				
				pVerts[i].Color			= particle.m_Color;
				pVerts[i].Animation		= Vector2(particle.m_AnimationCurrentColumn, particle.m_AnimationCurrentRow);
			}

			m_InstanceData->Unlock();
		}


		if (m_InstanceVB && m_InstanceIB)	return;

		if (!m_InstanceVB)
		{
			gDx9Device->CreateVertexBuffer(4 * sizeof(Vector2), D3DUSAGE_WRITEONLY, 0, D3DPOOL_MANAGED, &m_InstanceVB, NULL);
		}

		if (!m_InstanceIB)
		{
			gDx9Device->CreateIndexBuffer(4 * sizeof(U16), D3DUSAGE_WRITEONLY, D3DFMT_INDEX16, D3DPOOL_MANAGED, &m_InstanceIB, 0);
		}

		Vector2* iVerts;

		hr = m_InstanceVB->Lock(0, NULL, (void**)&iVerts, 0);

		if (SUCCEEDED(hr))
		{
			U16* pIndices;
			hr = m_InstanceIB->Lock(0, NULL, (void**)&pIndices, 0);

			if(SUCCEEDED(hr))
			{
				iVerts[0] = Vector2(0, 0);
				iVerts[1] = Vector2(1, 0);
				iVerts[2] = Vector2(0, 1);
				iVerts[3] = Vector2(1, 1);

				pIndices[0] = 0;
				pIndices[1] = 1;
				pIndices[2] = 2;
				pIndices[3] = 3;

				m_InstanceIB->Unlock();
			}
			m_InstanceVB->Unlock();
		}
	}

	void Emitter::Reset()
	{
		if (!m_EmitterData)
			return;

		m_SpawnFraction				= 1;
		m_SampleTime				= 0;
		m_EmitterTime				= 0;
		m_EmitterLife				= m_EmitterData->GetEmitterLife()->GetInitial();
		m_EmitterLifeTimeInverse	= 1.f / m_EmitterLife;
		m_DelayTime					= m_EmitterData->GetDelayTime()->GetInitial();
		m_Loop						= m_EmitterData->GetLoop()->GetInitial();
		m_InitCount					= m_EmitterData->GetCount()->GetInitial();
		m_InitEmissionRate			= m_EmitterData->GetEmissionRate()->GetInitial();
		m_InitEmissionNum			= m_EmitterData->GetEmissionNum()->GetInitial();
		m_InitAngle					= m_EmitterData->GetEmitAngle()->GetInitial();
		m_InitOffset				= m_EmitterData->GetPositionOffset()->GetInitial();
		m_InitEmitSize				= m_EmitterData->GetEmitSize()->GetInitial();
		m_InitFocusAngle			= m_EmitterData->GetFocusAngle()->GetInitial();
		m_InitFocusAzimuth			= m_EmitterData->GetFocusAzimuth()->GetInitial();
		m_Enable					= true;

		if (m_EmitterData->GetEmitterType() == ParticleResource::kEmitterTrail)
		{
			m_Loop = 0;
			for (U32 i = 0; i < m_ActiveParticles; i++)
			{
				Particle& particle = m_ParticleArray[ParticleIndex[i]];
				particle.m_Position = m_Position;
			}
		}
	}

	void Emitter::Draw()
	{
		if (!GetEnable() || m_ActiveParticles <= 0)
			return;

		if (gGame && gGame->config && gGame->config->GetShaderQuality() > 0 && m_EmitterData->GetParticleQuality() == ParticleResource::kLowQualityNoSee)
			return;

		if (!gDx9Device)
			return;

		if (!vertex_shader || !vertex_shader->SetShader())
			return;

		if (!m_Texture || !m_Texture->IsReady())
			return;

		if (!m_EmitterData)
			return;

		gDx9Device->SetTexture(COLOR_MAP, m_Texture ? m_Texture->GetTexture() : NULL);
		gDx9Device->SetRenderState(D3DRS_ZWRITEENABLE, false);
		gDx9Device->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);
		gDx9Device->SetAlphaBlend(m_EmitterData->m_BlendType);

		Vector2 cr = Vector2(m_EmitterData->m_AnimationColumns, m_EmitterData->m_AnimationRows);
		gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_ANIMCOLROW, &cr.x);


		if (m_EmitterData->GetEmitterType() == ParticleResource::kEmitterTrail)
		{
			gDx9Device->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_CLAMP);
			Array<VertexDeclaration::StreamEnvColor> vtxs;

			vtxs.Resize(m_ActiveParticles * 2 + 2);
			
			U32 j = 0;
			Vector3 direction = Vector3::kZero;
			for (U32 i = 0; i < m_ActiveParticles - 1; i++)
			{
				Particle& particle = m_ParticleArray[ParticleIndex[i]];
				Particle& particle_next = m_ParticleArray[ParticleIndex[m_ActiveParticles > i + 1 ? i + 1 : i]];

				F32 v = (F32)particle_next.m_AnimationCurrentRow / m_EmitterData->GetAnimationRows();
				if (i == 0)
				{
					vtxs[j  ].position = particle.m_Position + particle.m_AngleVelocity * m_EmitterData->GetTrailWidth() * 0.5f;
					vtxs[j++].uv1 = D3DXVECTOR2_16F(1, 0);
					vtxs[j  ].position = particle.m_Position - particle.m_AngleVelocity * m_EmitterData->GetTrailWidth() * 0.5f;
					vtxs[j++].uv1 = D3DXVECTOR2_16F(0, 0);
				}
				vtxs[j  ].position = particle_next.m_Position + particle.m_AngleVelocity * m_EmitterData->GetTrailWidth() * 0.5f;
				vtxs[j++].uv1 = D3DXVECTOR2_16F(1, v);
				vtxs[j  ].position = particle_next.m_Position - particle.m_AngleVelocity * m_EmitterData->GetTrailWidth() * 0.5f;
				vtxs[j++].uv1 = D3DXVECTOR2_16F(0, v);

			}
			if (m_ActiveParticles > 1)
			{
				U32 index = m_ActiveParticles - 1;
				Particle& particle = m_ParticleArray[ParticleIndex[index]];
				vtxs[j  ].position = particle.m_RelativePosition + particle.m_AngleVelocity * m_EmitterData->GetTrailWidth() * 0.5f;
				vtxs[j++].uv1 = D3DXVECTOR2_16F(1, 1);
				vtxs[j  ].position = particle.m_RelativePosition - particle.m_AngleVelocity * m_EmitterData->GetTrailWidth() * 0.5f;
				vtxs[j++].uv1 = D3DXVECTOR2_16F(0, 1);
			}

			gDx9Device->SetVertexDeclaration(VD::GetVertexDeclaration(VertexDeclaration::kEnvColor));
			pixel_shader->SetShader();
			gDx9Device->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP, m_ActiveParticles * 2, vtxs.GetData(), VD::GetVertexDeclarationStride(VertexDeclaration::kEnvColor));
			gDx9Device->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_WRAP);
		}
		else if (m_EmitterData->GetEmitterType() == ParticleResource::kEmitterNumber)
		{
			gDx9Device->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);
			VertexDeclaration::StreamEnvColor vtxs[4];
			Vector3 CameraDirection = (Vector3(0, 0, 1) * gGame->camera->rotation).Normalize();
			Vector3 Up = Vector3(0, 1, 0);
			Vector3 Right = Cross(CameraDirection, Up);

			F32 wide = 1.f / m_EmitterData->GetAnimationColumns();

			for (U32 i = 0; i < m_ActiveParticles; i++)
			{
				Particle& particle = m_ParticleArray[ParticleIndex[i]];
				U32 count = 0;
				U32 num = particle.m_Number;
				Array<U32> num_list;
				while(num >= 10)
				{
					num_list.PushBack(num % 10);
					num /= 10;
				}
				num_list.PushBack(num);
			
				Vector2 size = GetParticleSize(particle);

				Vector3 pos = particle.m_Position;
				for (U32 i = 0; i < num_list.Size(); i++)
				{
					vtxs[0].position = pos + Up * size.y * 0.5f;
					vtxs[0].uv1 = D3DXVECTOR2_16F(wide * (num_list[i] + 1), 0);

					vtxs[1].position = pos - Up * size.y * 0.5f;
					vtxs[1].uv1 = D3DXVECTOR2_16F(wide * (num_list[i] + 1), 1);

					pos += Right * size.x;

					vtxs[2].position = pos + Up * size.y * 0.5f;
					vtxs[2].uv1 = D3DXVECTOR2_16F(wide * num_list[i], 0);

					vtxs[3].position = pos - Up * size.y * 0.5f;
					vtxs[3].uv1 = D3DXVECTOR2_16F(wide * num_list[i], 1);

					gDx9Device->SetVertexDeclaration(VD::GetVertexDeclaration(VertexDeclaration::kEnvColor));
					pixel_shader->SetShader();
					gDx9Device->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP, 2, vtxs, VD::GetVertexDeclarationStride(VertexDeclaration::kEnvColor));
				}
			}
			gDx9Device->SetRenderState(D3DRS_CULLMODE, D3DCULL_CW);
		}
		else
		{
			BuildStream();
			gDx9Device->SetVertexDeclaration(VD::GetVertexDeclaration(VertexDeclaration::kParticle));

			if (m_EmitterData->m_SoftParticle && gGame->config->GetSoftParticle())
			{
				if (!soft_pixel_shader || !soft_pixel_shader->SetShader())
					return;
			}
			else
			{
				if (!pixel_shader ||!pixel_shader->SetShader())
					return;
			}

			gDx9Device->SetStreamSource(0, m_InstanceVB, 0, VD::GetParticleStride());
			gDx9Device->SetStreamSourceFreq(0, D3DSTREAMSOURCE_INDEXEDDATA | m_ActiveParticles);

			gDx9Device->SetStreamSource(1, m_InstanceData, 0, VD::GetParticleInstanceStride());
			gDx9Device->SetStreamSourceFreq(1, D3DSTREAMSOURCE_INSTANCEDATA | 1ul);

			gDx9Device->SetIndices(m_InstanceIB);

			switch (m_EmitterData->GetParticleType())
			{
			case ParticleResource::kCamera:
				{
					Vector3 CameraDirection = Vector3(0, 0, 1) * gGame->camera->rotation;
					Vector3 CameraUp		= Vector3(0, 1, 0) * gGame->camera->rotation;
					Vector3 CameraRight		= Vector3(1, 0, 0) * gGame->camera->rotation;
					gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_CAMERADIR, &CameraDirection.x);
					gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_CAMERAUP, &CameraUp.x);
					gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_CAMERARIGHT, &CameraRight.x);
					break;
				}
			case ParticleResource::kHorizontal:
				{
					Vector3 CameraDirection = Vector3(0, 1, 0);
					Vector3 CameraUp		= Vector3(1, 0, 0);
					Vector3 CameraRight		= Vector3(0, 0, 1);
					gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_CAMERADIR, &CameraDirection.x);
					gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_CAMERAUP, &CameraUp.x);
					gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_CAMERARIGHT, &CameraRight.x);
					break;
				}
			case ParticleResource::kVelocityImposter:
				{
					Vector3 CameraDirection = Vector3(0, 0, 1) * gGame->camera->rotation;
					Vector3 CameraUp		= Vector3(0, 1, 0) * gGame->camera->rotation;
					Vector3 CameraRight		= Vector3(1, 0, 0) * gGame->camera->rotation;
					gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_CAMERADIR, &CameraDirection.x);
					gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_CAMERAUP, &CameraUp.x);
					gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_CAMERARIGHT, &CameraRight.x);
					break;
				}
			case ParticleResource::kFollowVelocity:
				{
					Vector3 CameraDirection = Vector3(0, 0, 1) * gGame->camera->rotation;
					Vector3 CameraUp		= Vector3(0, 1, 0) * gGame->camera->rotation;
					Vector3 CameraRight		= Vector3(1, 0, 0) * gGame->camera->rotation;
					gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_CAMERADIR, &CameraDirection.x);
					gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_CAMERAUP, &CameraUp.x);
					gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_CAMERARIGHT, &CameraRight.x);
					break;
				}
			}

			gDx9Device->DrawIndexedPrimitive(D3DPT_TRIANGLESTRIP, 0, 0, 4, 0, 2);
			gDx9Device->SetStreamSourceFreq(0, 1);
			gDx9Device->SetStreamSourceFreq(1, 1);
		}
	}

	void Emitter::Spawn(F32 frametime)
	{
		if (GetCount() <= m_ActiveParticles)
			return;

		F32 NewLeftOver = m_SpawnFraction + frametime * GetEmissionRate();
		U32 Number = Floor(NewLeftOver);
		NewLeftOver = NewLeftOver - Number;

		for (U32 i = 0; i < Number * GetEmissionNum(); i++)
		{
			if (++m_ActiveParticles > m_MaxParticles)
				Resize();

			if (m_ActiveParticles > m_ParticleArray.Size())
				m_ParticleArray.PushBack();

			U32 a1 = m_ActiveParticles - 1;
			if (ParticleIndex.Size() <= a1) continue;

			U32 a2 = ParticleIndex[a1];
			if (m_ParticleArray.Size() <= a2) continue;

			m_InitAngle	= m_EmitterData->GetEmitAngle()->GetInitial();

			InitParticle(m_ParticleArray[ParticleIndex[m_ActiveParticles - 1]]);
		}
		m_SpawnFraction = NewLeftOver;
	}

	void Emitter::SpawnNumber(U32 num)
	{
		if (++m_ActiveParticles > m_MaxParticles)
			Resize();

		if (m_ActiveParticles > m_ParticleArray.Size())
			m_ParticleArray.PushBack();

		InitParticle(m_ParticleArray[ParticleIndex[m_ActiveParticles - 1]]);

		m_ParticleArray[ParticleIndex[m_ActiveParticles - 1]].m_Number = num;
	}

	void Emitter::SetEmitterData(by_ptr(ParticleResource::EmitterData) v)
	{
		m_EmitterData = v;
	}

	void Emitter::LoadTexture()
	{
		if (m_EmitterData->m_TextureName.Length() < 1)
		{
			m_Texture = RESOURCE_LOAD("common/white_texture.tga", false, Texture);
			return;
		}
		CStrBuf<256> buff;
		Path::ContractPath(buff, "/vfx/", m_EmitterData->m_TextureName.Str());
		m_Texture = RESOURCE_LOAD(buff, true, Texture);
	}

	U32 Emitter::GetCount()
	{
		if (!m_EmitterData)
			return 0;

		return m_EmitterData->GetCount()->GetEmitLifeValue(m_InitCount, m_SampleTime);
	}

	F32 Emitter::GetEmissionNum()
	{
		if (!m_EmitterData)
			return 0;

		return m_EmitterData->GetEmissionNum()->GetEmitLifeValue(m_InitEmissionNum, m_SampleTime);
	}

	F32 Emitter::GetEmissionRate()
	{
		if (!m_EmitterData)
			return 0;

		return m_EmitterData->GetEmissionRate()->GetEmitLifeValue(m_InitEmissionRate, m_SampleTime);
	}

	F32 Emitter::GetAngle()
	{
		if (!m_EmitterData)
			return 0;

		return m_EmitterData->GetEmitAngle()->GetEmitLifeValue(m_InitAngle, m_SampleTime);
	}

	Core::Vector3 Emitter::GetOffset()
	{
		if (!m_EmitterData)
			return Core::Vector3::kZero;

		return m_EmitterData->GetPositionOffset()->GetEmitLifeValue(m_InitOffset, m_SampleTime);
	}

	F32 Emitter::GetXYZScale(Particle& p)
	{
		if (!m_EmitterData)
			return 0;

		return m_EmitterData->GetXYZScale()->GetParticleLifeValue(p.m_InitXYZScale, p.m_SampleTime);
	}

	Vector2 Emitter::GetParticleSize(Particle & p)
	{
		if (!m_EmitterData)
			return Vector2::kZero;

		return m_EmitterData->GetParticleSize()->GetParticleLifeValue(p.m_InitSize, p.m_SampleTime);
	}

	F32	Emitter::GetStretch(Particle& p)
	{
		if (!m_EmitterData)
			return 0;

		return m_EmitterData->GetStretch()->GetParticleLifeValue(p.m_InitStretch, p.m_SampleTime);
	}

	F32 Emitter::GetAcceleration(Particle& p)
	{
		if (!m_EmitterData)
			return 0;

		return m_EmitterData->GetAcceleration()->GetParticleLifeValue(p.m_InitAcceleration, p.m_SampleTime);
	}

	F32 Emitter::GetResistance(Particle& p)
	{
		if (!m_EmitterData)
			return 0;

		return m_EmitterData->GetResistance()->GetParticleLifeValue(p.m_InitResistance, p.m_SampleTime);
	}

	F32 Emitter::GetGravity(Particle& p)
	{
		if (!m_EmitterData)
			return 0;

		return m_EmitterData->GetGravity()->GetParticleLifeValue(p.m_InitGravity, p.m_SampleTime);
	}

	F32 Emitter::GetTurbulence3D(Particle& p)
	{
		if (!m_EmitterData)
			return 0;

		return m_EmitterData->GetTurbulence3D()->GetParticleLifeValue(p.m_InitTurbulence3D, p.m_SampleTime);
	}

	F32 Emitter::GetTurbulenceSize(Particle& p)
	{
		if (!m_EmitterData)
			return 0;

		return m_EmitterData->GetTurbulenceSize()->GetParticleLifeValue(p.m_InitTurbulenceSize, p.m_SampleTime);
	}
	
	F32 Emitter::GetTurbulenceSpeed(Particle& p)
	{
		if (!m_EmitterData)
			return 0;

		return m_EmitterData->GetTurbulenceSpeed()->GetParticleLifeValue(p.m_InitTurbulenceSpeed, p.m_SampleTime);
	}

	F32 Emitter::GetAngleVelocity(Particle& p)
	{
		if (!m_EmitterData)
			return 0;

		return m_EmitterData->GetAngleVelocity()->GetParticleLifeValue(p.m_InitAngleZVelocity, p.m_SampleTime);
	}

	Core::Color3 Emitter::GetColor(Particle& p)
	{
		if (!m_EmitterData)
			return Color3::kBlack;

		return  m_EmitterData->GetColor()->GetParticleLifeValue(p.m_InitColor, p.m_SampleTime);
	}

	Core::Color3 Emitter::GetColorEmission(Particle& p)
	{
		if (!m_EmitterData)
			return Color3::kBlack;

		return m_EmitterData->GetColorEmissive()->GetParticleLifeValue(p.m_InitColorEmissive, p.m_SampleTime);
	}

	F32	Emitter::GetAlpha(Particle& p)
	{
		if (!m_EmitterData)
			return 0;

		return m_EmitterData->GetAlpha()->GetParticleLifeValue(p.m_InitAlpha, p.m_SampleTime);
	}

	void Emitter::ResetParticles()
	{
		for(U32 i = 0; i < m_ParticleArray.Size();i++)
		{
			InitParticle(m_ParticleArray[i]);
		}
	}

}

// particle system
namespace Client
{
	ParticleSystem::ParticleSystem()
		: m_DrawFP(false)
		, m_Position(Vector3::kZero)
		, m_Rotation(Quaternion::kIdentity)
		, m_Run(false)
	{
		m_LinkNode.data = this;
	}

	ParticleSystem::ParticleSystem(Core::Identifier key, bool request)
		: m_DrawFP(false)
		, m_Position(Vector3::kZero)
		, m_Rotation(Quaternion::kIdentity)
		, m_Run(false)
	{
		m_LinkNode.data = this;

		CStrBuf<256> path;
		path.format("/vfx/vfx_%s.vfx", key.Str());

		m_ParticleResource = RESOURCE_LOAD(path, request, ParticleResource);

		if (m_ParticleResource)
			Initialize();
		}

	ParticleSystem::~ParticleSystem()
	{
		m_EmitterArray.Clear();
		m_ParticleResource = NullPtr;
	}

	//void ParticleSystem::BuildStream()
	//{
	//	for (U32 i = 0; i < m_EmitterArray.Size(); i++)
	//		m_EmitterArray[i]->BuildStream();
	//}
	
	void ParticleSystem::SetDead()
	{
		for (U32 i = 0; i < m_EmitterArray.Size(); i++)
		{
			if (m_EmitterArray[i]->m_EmitterData->GetEmitterType() == ParticleResource::kEmitterTrail)
				m_EmitterArray[i]->m_Loop = m_EmitterArray[i]->m_EmitterData->GetTrailStep();
			else
				m_EmitterArray[i]->m_Loop = 1;
		}
	}

	bool ParticleSystem::IsDead()
	{
		for (U32 i = 0; i < m_EmitterArray.Size(); i++)
		{
			if (!m_EmitterArray[i]->m_EmitterData)
				continue;

			if (m_EmitterArray[i]->m_EmitterData->GetEmitterType() == ParticleResource::kEmitterTrail)
			{
				if (m_EmitterArray[i]->GetEnable())
					return false;
			}
			else
			{
				if (!m_EmitterArray[i]->m_Loop)
					return false;
				else
				{
					if (m_EmitterArray[i]->m_EmitterTime < (m_EmitterArray[i]->m_EmitterData->m_EmitterLife * m_EmitterArray[i]->m_EmitterData->m_Loop) ||
						m_EmitterArray[i]->m_ActiveParticles > 0)
					{
						return false;
					}
				}
			}
		}   
		return true;
	}


	// ready
	bool ParticleSystem::IsReady()
	{
		if (m_ParticleResource)
			return m_ParticleResource->IsReady();

		return false;
	}

	void ParticleSystem::SetVertexDeclaration()
	{
		gDx9Device->SetVertexDeclaration(VD::GetVertexDeclaration(VertexDeclaration::kParticle));
	}

	void ParticleSystem::Initialize()
	{
		if (!m_ParticleResource)
			return;

		m_EmitterArray.Clear();

		LinkNode<sharedc_ptr(ParticleResource::EmitterData)> * node = m_ParticleResource->m_EmitterData.Front();
		while (node)
		{
			sharedc_ptr(Emitter) emitter = ptr_new Emitter;
			emitter->SetPosition(m_Position);
			emitter->SetRotation(m_Rotation);
			emitter->SetEmitterData(node->data);
			if (node->data->m_ParticleType == ParticleResource::kVelocityImposter)
				emitter->vertex_shader = RESOURCE_LOAD("/shader/velocity_imposter_particle_vs.vd9", true, VertexShaderDx9);
			else if(node->data->m_ParticleType == ParticleResource::kFollowVelocity)
				emitter->vertex_shader = RESOURCE_LOAD("/shader/follow_velocity_particle_vs.vd9", true, VertexShaderDx9);
			else if(node->data->m_EmitterType == ParticleResource::kEmitterTrail || node->data->m_EmitterType == ParticleResource::kEmitterNumber)
				emitter->vertex_shader = RESOURCE_LOAD("/shader/lightmap_main.vd9", true, VertexShaderDx9);
			else
				emitter->vertex_shader = RESOURCE_LOAD("/shader/default_particle_vs.vd9", true, VertexShaderDx9);

			emitter->soft_pixel_shader = RESOURCE_LOAD("/shader/soft_particle_ps.pd9", true, PixelShaderDx9);

			if (emitter->m_EmitterData->GetEmitterType() ==	ParticleResource::kEmitterTrail || node->data->m_EmitterType == ParticleResource::kEmitterNumber)
			{
				emitter->pixel_shader = RESOURCE_LOAD("/shader/trail_particle_ps.pd9", true, PixelShaderDx9);
			}
			else
			{
				emitter->pixel_shader = RESOURCE_LOAD("/shader/default_particle_ps.pd9", true, PixelShaderDx9);
			}


			emitter->LoadTexture();
			m_EmitterArray.PushBack(emitter);
			if (m_EmitterArray.Back()->m_EmitterData->GetEmitterType() == ParticleResource::kEmitterTrail)
			{
				U32 step = m_EmitterArray.Back()->m_EmitterData->GetTrailStep();

				for (U32 i = 0; i < step; i++)
				{
					if (++emitter->m_ActiveParticles > emitter->m_MaxParticles)
						emitter->Resize();

					if (emitter->m_ActiveParticles > emitter->m_ParticleArray.Size())
						emitter->m_ParticleArray.PushBack();

					emitter->InitParticle(emitter->m_ParticleArray[emitter->ParticleIndex[emitter->m_ActiveParticles - 1]]);
				}
			}
			node = node->GetNext();
		}

		m_DirtyFlag = m_ParticleResource->GetDirtyFlag();
		m_DirtyFlag.Reset();
	}

	// dirty check
	void ParticleSystem::DirtyCheck()
	{
		if (m_ParticleResource)
		{
			m_DirtyFlag.Check(m_ParticleResource->GetDirtyFlag());

			if (m_DirtyFlag.IsDirty())
			{
				m_Run = false;
				Initialize();
				Reset();
			}
		}
	}

	void ParticleSystem::Update(F32 FrameTime)
	{
		DirtyCheck();

		for (U32 i = 0; i < m_EmitterArray.Size(); i++)
			m_EmitterArray[i]->Update(FrameTime);
	}

	void ParticleSystem::Reset()
	{
		for (U32 i = 0; i < m_EmitterArray.Size(); i++)
		{
			if (!m_EmitterArray[i]->m_EmitterData)
				continue;

			if (m_EmitterArray[i]->m_EmitterData->m_TextureDirty)
			{
				m_EmitterArray[i]->m_EmitterData->m_TextureDirty = false;
				m_EmitterArray[i]->LoadTexture();
			}
			m_EmitterArray[i]->Reset();
		}

		if (!m_Run)
		{
			for (U32 i = 0; i < m_EmitterArray.Size(); i++)
			{
				if (!m_EmitterArray[i]->m_EmitterData)
					continue;

				F32 rate = m_EmitterArray[i]->GetEmissionRate();
				if (rate > 4)	rate = 4;
				if (rate <= 0)	continue;
				F32 ahead_time = m_EmitterArray[i]->m_EmitterData->GetAheadTime()->GetInitial();
				if (ahead_time > 10)	ahead_time = 10;

				for (F32 j = 0; j < ahead_time; j += (1.f / rate))
				{
					m_EmitterArray[i]->Update(1.f / rate);
					m_EmitterArray[i]->KillDead();
				}
			}
			m_Run = true;
		}
	}

	void ParticleSystem::SetPosition(const Core::Vector3& position)
	{
		m_Position = position;
		for (U32 i = 0; i < m_EmitterArray.Size(); i++)
		{
			m_EmitterArray[i]->SetPosition(m_Position);
		}
	}

	void ParticleSystem::SetRotation(const Core::Quaternion& rotation)
	{
		m_Rotation = rotation;
		for (U32 i = 0; i < m_EmitterArray.Size(); i++)
		{
			m_EmitterArray[i]->SetRotation(m_Rotation);
		}
	}


	void ParticleSystem::Draw()
	{
		for (U32 i = 0; i < m_EmitterArray.Size(); i++)
		{
			m_EmitterArray[i]->Draw();
		}
	}

	void ParticleSystem::SpawnNumber(U32 num)
	{
		for (U32 i = 0; i < m_EmitterArray.Size(); i++)
		{
			if (!m_EmitterArray[i]->m_EmitterData)
				continue;

			if (m_EmitterArray[i]->m_EmitterData->GetEmitterType() == ParticleResource::kEmitterNumber)
			{
				m_EmitterArray[i]->SpawnNumber(num);
			}
		}
	}

	void ParticleSystem::SetFirstPersonMode(bool v)
	{
		m_DrawFP = v;
	}

	bool ParticleSystem::IsFirstPersonMode()
	{
		return m_DrawFP;
	}

	void ParticleSystem::SetEnable(bool v)
	{
		for (U32 i = 0; i < m_EmitterArray.Size(); i++)
			m_EmitterArray[i]->SetEnable(v);
	}

	void ParticleSystem::ResetEmittersParticles()
	{
		for (U32 i = 0; i < m_EmitterArray.Size(); i++)
		{
			m_EmitterArray[i]->ResetParticles();
		}
	}

}


DEFINE_PDE_TYPE_CLASS(Client::ParticleSystem)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_DEFAULT_CONSTRUCTOR();
		ADD_PDE_METHOD(SetParticleResource);

		ADD_PDE_METHOD(Initialize);
		ADD_PDE_METHOD(SetPosition);
		ADD_PDE_METHOD(SetRotation);
		ADD_PDE_METHOD(Reset);
	}
};
REGISTER_PDE_TYPE(Client::ParticleSystem);