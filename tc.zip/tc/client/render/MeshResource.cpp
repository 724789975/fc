#include "pch.h"
#include "../game/LuaLoadingFunc.h"

using namespace Core;

#define USE_MESH_OPTIMIZE	1

#define NAMECHECK(SIZE) if (SIZE > 256) { LogSystem.WriteLinef("%s error", GetKey()); return NullPtr; }

namespace Client
{
	Primitive::Primitive()
		: primitive_count(0)
		, vertex_count(0)
		, layer(0)
		, world_matrix(0)
		, collision_mode(0)
	{
	}

	Primitive::~Primitive()
	{
	}

	void Primitive::SetStream()
	{
		if (vertex_buffer)
			vertex_buffer->SetStream();
		if (index_buffer)
			index_buffer->SetStream();
	}

	void Primitive::SetWorldMatrix()
	{
		if (!world_matrix)
			return;
		gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_WORLD, *world_matrix);
		gDx9Device->SetPixelShaderConstantF(PS_CONSTANT_WORLD, *world_matrix);
	}

	void Primitive::Draw(DrawType drawtype, S32 shader_lod)
	{
		if (!gDx9Device)
			return;

		if (!primitive_count || !vertex_count)
			return;

		if (!visible)
			return;

		if (!material)
			return;

		if ((drawtype != kCharacterSpecialEffect) && (drawtype != kScene) && (vd_type == VertexDeclaration::kStatic) && (collision_mode != 1) && (collision_mode != 4))
			return;

		if (!material->ChooseShader(shader_lod))
			return;

		if (blend_mode == kAlphaTest)
		{
			if (gDx9Device && !gDx9Device->alpha_test_great_support)
			{
				blend_mode = kSourceAlphaAdd;
			}

			if (drawtype == kEarlyZ)
				return;
		}

		if (drawtype == kCharacterTransparency)
			gDx9Device->SetAlphaBlend(kSourceAlphaAdd);
		else
			gDx9Device->SetAlphaBlend(blend_mode);
		gDx9Device->SetRenderState(D3DRS_ZENABLE, TRUE);

		if (blend_mode & kTransparency)
		{
			gDx9Device->SetRenderState(D3DRS_ZWRITEENABLE, FALSE);
		}
		else
			gDx9Device->SetRenderState(D3DRS_ZWRITEENABLE, TRUE);

		if(drawtype == kNoZBuffer)
		{
			gDx9Device->SetRenderState(D3DRS_ZWRITEENABLE, FALSE);
			gDx9Device->SetRenderState(D3DRS_ZENABLE, FALSE);
		}

		CullMode curr_cull_mode = cull_mode;
		
		if (gDx9Device->GetInverse())
		{
			if (curr_cull_mode == kCullModeCW)
				curr_cull_mode = kCullModeCCW;
			else if (curr_cull_mode == kCullModeCCW)
				curr_cull_mode = kCullModeCW;
		}

		if (gDx9Device->GetForceCullModeNone())
		{
			curr_cull_mode = kCullModeNone;
		}

		switch (curr_cull_mode)
		{
		case kCullModeCW:
			gDx9Device->SetRenderState(D3DRS_CULLMODE, D3DCULL_CW);
			break;
		case kCullModeCCW:
			gDx9Device->SetRenderState(D3DRS_CULLMODE, D3DCULL_CCW);
			break;
		case kCullModeNone:
			gDx9Device->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);
			break;
		}

		SetStream();
		gDx9Device->SetVertexDeclaration(VD::GetVertexDeclaration(vd_type));
		SetWorldMatrix();
		switch (drawtype)
		{
		case kEarlyZ:
			if (!material->SetVertexShader()) return;
			if (blend_mode == kAlphaTest)
			{
				gDx9Device->SetAlphaBlend(blend_mode);
				if (!material->SetTexture()) return;
			}
			break;
		case kLightMap:
		case kSceneTransparency:
		case kCharacterTransparency:
		case kCharacterSpecialEffect:
			if (!material->SetVertexShader()) return;
			if (!material->SetTexture()) return;;
			if (!material->SetParameter()) return;
			break;
		case kNoZBuffer:
		case kScene:
			if (!material->SetVertexShader()) return;
			if (!material->SetPixelShader()) return;;
			if (!material->SetParameter()) return;
			if (!material->SetTexture()) return;
			break;
		case kShaderManual:
			if (!material->SetParameter()) return;
			if (!material->SetTexture()) return;
			break;
		};
	
		gDx9Device->DrawIndexedPrimitive(D3DPT_TRIANGLELIST, 0, 0, vertex_count, 0, primitive_count);
	}

	bool Primitive::SetTexture(S32 index)
	{
		return material->SetTexture(index);
	}
}

namespace Client
{
	MeshResource::MeshResource()
		: vertex_buffer_size(0)
		, index_buffer_size(0)
		, vb_stream(NULL)
		, ib_stream(NULL)
	{ 
		Initialize();
	}

	MeshResource::~MeshResource()
	{
		Destory();
	}

	void MeshResource::Initialize()
	{
		mesh_type = kNoneMesh;

		local_aabb = AxisAlignedBox::kInvalid;
	}

	/// get version
	short MeshResource::GetVersion()
	{
		return 8;
	}

	/// save data
	bool MeshResource::SaveData(Core::Stream & stream)
	{
#ifndef MASTER
		Resource::SaveData(stream);
		stream.Write(&mesh_type, sizeof(MeshType));

		//stream.Write(&local_aabb.Min.x, sizeof(Vector3));
		//stream.Write(&local_aabb.Max.x, sizeof(Vector3));

		U32 size = 0;

		if (mesh_type == kSkin)
		{
			size = bonename.Size();
			stream.Write(&size, sizeof(U32));
			for (U32 i = 0; i < bonename.Size(); i++)
			{
				size = bonename[i].Length();
				stream.Write(&size, sizeof(U32));
				stream.Write(bonename[i].Str(), size);
			}

			size = bone_aabb.Size();
			stream.Write(&size, sizeof(U32));
			for (U32 i = 0; i < bone_aabb.Size(); i++)
			{
				stream.Write(bone_aabb[i].fAxis, sizeof(AxisAlignedBox));
			}
		}
		else if (mesh_type == kStatic)
		{
			stream.Write(local_aabb.fAxis, sizeof(AxisAlignedBox));
		}

		size = 0;
		for (U32 i = 0; i < primitives.Size(); i++)
		{
			if (!primitives[i].primitive_count && !primitives[i].vertex_count)
				continue;
			size++;
		}

		stream.Write(&size, sizeof(U32));
		for (U32 i = 0; i < primitives.Size(); i++)
		{
			if (!primitives[i].primitive_count && !primitives[i].vertex_count)
				continue;

			stream.Write(&primitives[i].primitive_count, sizeof(U32));
			stream.Write(&primitives[i].vertex_count, sizeof(U32));
			stream.Write(&primitives[i].layer, sizeof(U32));
			stream.Write(&primitives[i].cull_mode, sizeof(CullMode));
			stream.Write(&primitives[i].blend_mode, sizeof(AlphaBlendMode));
			stream.Write(&primitives[i].visible, sizeof(bool));

			if (mesh_type == kStatic)
				size = primitives[i].vertex_count * sizeof(VertexDeclaration::StreamStatic);
			else if (mesh_type == kSkin)
			{
				size = primitives[i].vertex_count * sizeof(VertexDeclaration::StreamSkin);
			}
			stream.Write(&size, sizeof(U32));
			void* data = primitives[i].vertex_buffer->Lock();
			stream.Write(data, size);
			primitives[i].vertex_buffer->Unlock();

			size = primitives[i].primitive_count * 3 * sizeof(U32);
			stream.Write(&size, sizeof(U32));
			data = primitives[i].index_buffer->Lock();
			stream.Write(data, size);
			primitives[i].index_buffer->Unlock();
			
			byte has_material = 0;
			if (primitives[i].material)
			{
				has_material = 1;
				stream.Write(&has_material, sizeof(byte));
				primitives[i].material->Save(stream);
			}
			else
			{
				stream.Write(&has_material, sizeof(byte));
			}

			stream.Write(&primitives[i].collision_mode, sizeof(U32));
		}

		size = physical_material.Size();
		stream.Write(&size, sizeof(U32));
		for (U32 i = 0; i < physical_material.Size(); i++)
		{
			size = physical_material[i];
			stream.Write(&size, sizeof(int));
		}

		data.Clear();

		return true;
#else
		return false;
#endif
	}

	/// load data
	sharedc_ptr(Object) MeshResource::LoadData(Core::Stream & stream)
	{
		if (!Resource::LoadData(stream))
			return NullPtr;

		sharedc_ptr(MeshResource) data = ptr_new MeshResource;

		stream.Read(&data->mesh_type, sizeof(MeshType));

		U32 size = 0;
		if (data->mesh_type == kSkin)
		{
			stream.Read(&size, sizeof(U32));
			data->bonename.Resize(size);
			for (U32 i = 0; i < data->bonename.Size(); i++)
			{
				stream.Read(&size, sizeof(U32));
				NAMECHECK(size);
				CStrBuf<256>	buf;
				buf.setlen(size);
				stream.Read(buf.buff(), size);
				data->bonename[i] = buf;
			}

			stream.Read(&size, sizeof(U32));
			data->bone_aabb.Resize(size);
			for (U32 i = 0; i < size; i++)
			{
				stream.Read(data->bone_aabb[i].fAxis, sizeof(AxisAlignedBox));
			}

		}
		else if (data->mesh_type == kStatic)
		{
			stream.Read(&data->local_aabb.fAxis, sizeof(AxisAlignedBox));

		}
		else
		{
			LogSystem.WriteLinef("%s mesh error", GetKey());
			return NullPtr;
		}

		stream.Read(&size, sizeof(U32));
		data->primitives.Resize(size);
		for (U32 i = 0; i < data->primitives.Size(); i++)
		{
			stream.Read(&data->primitives[i].primitive_count, sizeof(U32));
			stream.Read(&data->primitives[i].vertex_count, sizeof(U32));
			stream.Read(&data->primitives[i].layer, sizeof(U32));
			stream.Read(&data->primitives[i].cull_mode, sizeof(CullMode));
			stream.Read(&data->primitives[i].blend_mode, sizeof(AlphaBlendMode));
			stream.Read(&data->primitives[i].visible, sizeof(bool));

			if (data->mesh_type == kStatic)
			{
				stream.Read(&size, sizeof(U32));
				data->primitives[i].vertex_buffer = ptr_new VertexBufferDx9(size, sizeof(VertexDeclaration::StreamStatic));
				data->primitives[i].vd_type = VertexDeclaration::kStatic;
			}
			else
			{
				stream.Read(&size, sizeof(U32));
				data->primitives[i].vertex_buffer = ptr_new VertexBufferDx9(size, sizeof(VertexDeclaration::StreamSkin));
				data->primitives[i].vd_type = VertexDeclaration::kSkin;
			}
			void* d = data->primitives[i].vertex_buffer->Lock();
			stream.Read(d, size);
			data->primitives[i].vertex_buffer->Unlock();

			stream.Read(&size, sizeof(U32));
			data->primitives[i].index_buffer = ptr_new IndexBufferDx9(size);
			d = data->primitives[i].index_buffer->Lock();
			stream.Read(d, size);
			data->primitives[i].index_buffer->Unlock();

			byte has_material = 0;
			stream.Read(&has_material, sizeof(byte));

			if (has_material)
			{
				data->primitives[i].material = ptr_new Material;
				data->primitives[i].material->Load(stream); 
			}	

			stream.Read(&data->primitives[i].collision_mode, sizeof(U32));
		}

		stream.Read(&size, sizeof(int));
		for (U32 j = 0; j < size; j++)
		{
			U32 v = 0;
			stream.Read(&v, sizeof(U32));
		}

		return data;
	}

	/// load data
	sharedc_ptr(Object) MeshResource::BuildData()
	{
#ifndef MASTER
		sharedc_ptr(MeshResource) data = ptr_new MeshResource;
		if (data->LoadRawData(GetKey(), 0.01f))
		{
			data->BuildStream();
			AddDependenceFilePath(GetKey());
			return data;
		}
#endif
		return NullPtr;
	}

	/// unload data
	void MeshResource::UnloadData()
	{
		vertex_buffer_size = 0;
		mesh_type = kNoneMesh;
	}

	/// on load data
	bool MeshResource::OnLoadData(by_ptr(Object) obj)
	{
		sharedc_ptr(MeshResource) data = ptr_static_cast<MeshResource>(obj);
		if (data)
		{
			bonename = data->bonename;
			bone_aabb = data->bone_aabb;
			index_buffer_size = data->index_buffer_size;
			vertex_buffer_size = data->vertex_buffer_size;
			primitives = data->primitives;
			mesh_type = data->mesh_type;
			local_aabb = data->local_aabb;
			vb_stream = data->vb_stream;
			ib_stream = data->ib_stream;
			physical_material = data->physical_material;
			return true;
		}
		return false;
	}

	MeshResource::MeshType MeshResource::GetMeshType()
	{
		return mesh_type;
	}

	void MeshResource::Destory()
	{
	}

	// build stream static
	void MeshResource::BuildStream()
	{
		switch(GetMeshType())
		{
		case MeshResource::kStatic:
			BuildStreamStatic();
			break;

		case MeshResource::kSkin:
			BuildStreamSkin();
			break;

		case MeshResource::kNoneMesh:
		default:
			break;
		}
	}

	/// build stream static
	void MeshResource::BuildStreamStatic()
	{
		vertex_buffer_size = data.vertices.Size() * sizeof(VertexDeclaration::StreamStatic);
		if (!vertex_buffer_size)
			return;

		vb_stream.Resize(data.vertices.Size());

		for (U32 i = 0; i < data.vertices.Size(); i++)
		{
			vb_stream[i].position = data.vertices[i];

			if (data.normals.Size() > i)
				new(&vb_stream[i].normal) D3DXVECTOR4_16F(data.normals[i].x, data.normals[i].y, data.normals[i].z, 0.f);
			else
				new(&vb_stream[i].normal) D3DXVECTOR4_16F(0, 0, 0, 0);

			if (data.binormals.Size() > i)
				new(&vb_stream[i].binormal) D3DXVECTOR4_16F(data.binormals[i].x, data.binormals[i].y, data.binormals[i].z, 0.f);
			else
				new(&vb_stream[i].binormal) D3DXVECTOR4_16F(0, 0, 0, 0);

			if (data.tangents.Size() > i)
				new(&vb_stream[i].tangent) D3DXVECTOR4_16F(data.tangents[i].x, data.tangents[i].y, data.tangents[i].z, 0.f);
			else
				new(&vb_stream[i].tangent) D3DXVECTOR4_16F(0, 0, 0, 0);

			if (data.uv0.Size() > i)
			{
				Vector2 map = data.uv0[i];
				new(&vb_stream[i].uv0) D3DXVECTOR2_16F(map.x, map.y);
			}
			else
				new(&vb_stream[i].uv0) D3DXVECTOR2_16F(0.5f, 0.5f);

			if (data.uv1.Size() > i)
			{
				Vector2 map = data.uv1[i];
				new(&vb_stream[i].uv1) D3DXVECTOR2_16F(map.x, map.y);
			}
			else
				new(&vb_stream[i].uv1) D3DXVECTOR2_16F(0.5f, 0.5f);

			if (data.uv2.Size() > i)
			{
				Vector2 map = data.uv2[i];
				new(&vb_stream[i].uv2) D3DXVECTOR2_16F(map.x, map.y);
			}
			else
				new(&vb_stream[i].uv2) D3DXVECTOR2_16F(0.5f, 0.5f);

			if (data.color.Size() > i)
			{
				ARGB color = data.color[i];
				if (color != NULL && color != -1)
					vb_stream[i].color = color;
				else
					vb_stream[i].color = Core::ARGB(255, 255, 255, 255);
			}
			else
				vb_stream[i].color = Core::ARGB(255, 255, 255, 255);
		}

		for (U32 i = 0; i < primitives.Size(); i++)
		{
			if (!primitives[i].indices.Size())
				continue;

			primitives[i].vd_type = VertexDeclaration::kStatic;

			HashSet<U32, U32> hindex;
			Array<U32>	new_vertices;
			for (U32 j = 0; j < primitives[i].indices.Size(); j++)
			{
				U32* data = hindex.Get(primitives[i].indices[j]);
				if (!data)
				{
					hindex.Add(primitives[i].indices[j], new_vertices.Size()); 
					new_vertices.PushBack(primitives[i].indices[j]);
				}
			}

			primitives[i].vertex_count = new_vertices.Size();
			primitives[i].vertex_buffer = ptr_new VertexBufferDx9(new_vertices.Size() * sizeof(VertexDeclaration::StreamStatic), VD::GetVertexDeclarationStride(VertexDeclaration::kStatic));
			primitives[i].index_buffer = ptr_new IndexBufferDx9(primitives[i].indices.Size() * sizeof(U32), sizeof(U32));

			U32 vertex_size = new_vertices.Size() * sizeof(VertexDeclaration::StreamStatic);

			U32 index_size = primitives[i].indices.Size() * sizeof(U32);
			Array<U32>	index_stream;
			index_stream.Resize(primitives[i].indices.Size());

			for(U32 j = 0; j < primitives[i].indices.Size(); j++)
			{
				index_stream[j] = *hindex.Get(primitives[i].indices[j]);
			}

#if USE_MESH_OPTIMIZE
			DWORD* face_remap = new DWORD[primitives[i].primitive_count];
			DWORD* vertices_remap = new DWORD[primitives[i].vertex_count];
			U32* remap_face_indices = new U32[index_size];

			D3DXOptimizeFaces	(index_stream.GetData(), primitives[i].primitive_count, primitives[i].vertex_count, true, (DWORD*)face_remap);
			for (U32 j = 0; j < primitives[i].primitive_count; j++)
			{
				remap_face_indices[3 * j + 0] = index_stream[face_remap[j] * 3 + 0];
				remap_face_indices[3 * j + 1] = index_stream[face_remap[j] * 3 + 1];
				remap_face_indices[3 * j + 2] = index_stream[face_remap[j] * 3 + 2];
			}

			D3DXOptimizeVertices(remap_face_indices, primitives[i].primitive_count, primitives[i].vertex_count, true, (DWORD*)vertices_remap);
			for (U32 j = 0; j < primitives[i].primitive_count; j++)
			{
				index_stream[3 * j + 0] = vertices_remap[remap_face_indices[3 * j + 0]];
				index_stream[3 * j + 1] = vertices_remap[remap_face_indices[3 * j + 1]];
				index_stream[3 * j + 2] = vertices_remap[remap_face_indices[3 * j + 2]];
			}
#endif

			U32* ibdata = (U32*)primitives[i].index_buffer->Lock();
			memcpy(ibdata, index_stream.GetData(), index_size);
			primitives[i].index_buffer->Unlock();

			
			VertexDeclaration::StreamStatic* vbdata = (VertexDeclaration::StreamStatic*)primitives[i].vertex_buffer->Lock();
			for (U32 j = 0; j < new_vertices.Size(); j++)
			{
#if	USE_MESH_OPTIMIZE
				vbdata[vertices_remap[j]] = vb_stream[new_vertices[j]];
#else
				vbdata[new_vertices[j]] = vb_stream[new_vertices[j]];
#endif
			}
			primitives[i].vertex_buffer->Unlock();

			data.Clear();

#if USE_MESH_OPTIMIZE
			SAFE_DELETE_ARRAY(face_remap);
			SAFE_DELETE_ARRAY(remap_face_indices);
			SAFE_DELETE_ARRAY(vertices_remap);
#endif
		}
	}

	/// build stream skin
	void MeshResource::BuildStreamSkin()
	{
		vertex_buffer_size = data.vertices.Size() * sizeof(VertexDeclaration::StreamSkin);

		if (!vertex_buffer_size)
			return;

		U32 vertex_count = data.vertices.Size();
		VertexDeclaration::StreamSkin* stream = new VertexDeclaration::StreamSkin[vertex_count];

		for (U32 i = 0; i < data.vertices.Size(); i++)
		{
			stream[i].position = data.vertices[i];

			if (data.normals.Size() > i)
				new(&stream[i].normal) D3DXVECTOR4_16F(data.normals[i].x, data.normals[i].y, data.normals[i].z, 0.f);
			else
				new(&stream[i].normal) D3DXVECTOR4_16F(0, 0, 0, 0);

			if (data.binormals.Size() > i)
				new(&stream[i].binormal) D3DXVECTOR4_16F(data.binormals[i].x, data.binormals[i].y, data.binormals[i].z, 0.f);
			else
				new(&stream[i].binormal) D3DXVECTOR4_16F(0, 0, 0, 0);

			if (data.tangents.Size() > i)
				new(&stream[i].tangent) D3DXVECTOR4_16F(data.tangents[i].x, data.tangents[i].y, data.tangents[i].z, 0.f);
			else
				new(&stream[i].tangent) D3DXVECTOR4_16F(0, 0, 0, 0);

			if (data.uv0.Size() > i)
			{
				Vector2 map = data.uv0[i];
				new(&stream[i].uv0) D3DXVECTOR2_16F(map.x, map.y);
			}
			else
				new(&stream[i].uv0) D3DXVECTOR2_16F(0.5f, 0.5f);

			if (data.uv1.Size() > i)
			{
				Vector2 map = data.uv1[i];
				new(&stream[i].uv1) D3DXVECTOR2_16F(map.x, map.y);
			}
			else
				new(&stream[i].uv1) D3DXVECTOR2_16F(0.5f, 0.5f);

			for (U32 j = 0; j < 4; j++)
			{
				if (data.blendweight.Size() > i)
				{
					stream[i].blendweight[j] = data.blendweight[i][j];
					stream[i].blendindices[j] = data.blendindices[i*4 + j];
				}
				else
				{
					stream[i].blendweight[j] = 0;
					stream[i].blendindices[j] = 0;
				}

			}

		}

		for (U32 i = 0; i < primitives.Size(); i++)
		{
			if (!primitives[i].indices.Size())
				continue;

			primitives[i].vd_type = VertexDeclaration::kSkin;

			HashSet<U32, U32> hindex;
			Array<U32>	new_vertices;
			for (U32 j = 0; j < primitives[i].indices.Size(); j++)
			{
				U32* data = hindex.Get(primitives[i].indices[j]);
				if (!data)
				{
					hindex.Add(primitives[i].indices[j], new_vertices.Size()); 
					new_vertices.PushBack(primitives[i].indices[j]);
				}
			}

			primitives[i].vertex_count = new_vertices.Size();
			primitives[i].vertex_buffer = ptr_new VertexBufferDx9(new_vertices.Size() * sizeof(VertexDeclaration::StreamSkin), VD::GetVertexDeclarationStride(VertexDeclaration::kSkin));
			primitives[i].index_buffer = ptr_new IndexBufferDx9(primitives[i].indices.Size() * sizeof(U32), sizeof(U32));

			U32 vertex_size = new_vertices.Size() * sizeof(VertexDeclaration::StreamStatic);
		

			U32 index_size = primitives[i].indices.Size() * sizeof(U32);
			Array<U32>	index_stream;
			index_stream.Resize(primitives[i].indices.Size());

			for(U32 j = 0; j < primitives[i].indices.Size(); j++)
			{
				index_stream[j] = *hindex.Get(primitives[i].indices[j]);
			}

#if USE_MESH_OPTIMIZE
			DWORD* face_remap = new DWORD[primitives[i].primitive_count];
			DWORD* vertices_remap = new DWORD[primitives[i].vertex_count];
			U32* remap_face_indices = new U32[index_size];

			D3DXOptimizeFaces	(index_stream.GetData(), primitives[i].primitive_count, primitives[i].vertex_count, true, (DWORD*)face_remap);
			for (U32 j = 0; j < primitives[i].primitive_count; j++)
			{
				remap_face_indices[3 * j + 0] = index_stream[face_remap[j] * 3 + 0];
				remap_face_indices[3 * j + 1] = index_stream[face_remap[j] * 3 + 1];
				remap_face_indices[3 * j + 2] = index_stream[face_remap[j] * 3 + 2];
			}

			D3DXOptimizeVertices(remap_face_indices, primitives[i].primitive_count, primitives[i].vertex_count, true, (DWORD*)vertices_remap);
			for (U32 j = 0; j < primitives[i].primitive_count; j++)
			{
				index_stream[3 * j + 0] = vertices_remap[remap_face_indices[3 * j + 0]];
				index_stream[3 * j + 1] = vertices_remap[remap_face_indices[3 * j + 1]];
				index_stream[3 * j + 2] = vertices_remap[remap_face_indices[3 * j + 2]];
			}
#endif

			U32* ibdata = (U32*)primitives[i].index_buffer->Lock();
			memcpy(ibdata, index_stream.GetData(), index_size);
			primitives[i].index_buffer->Unlock();
			
			VertexDeclaration::StreamSkin* vbdata = (VertexDeclaration::StreamSkin*)primitives[i].vertex_buffer->Lock();
			for (U32 j = 0; j < new_vertices.Size(); j++)
			{
#if	USE_MESH_OPTIMIZE
				vbdata[vertices_remap[j]] = stream[new_vertices[j]];
#else
				vbdata[new_vertices[j]] = stream[new_vertices[j]];
#endif
			}
			primitives[i].vertex_buffer->Unlock();

			data.Clear();

#if	USE_MESH_OPTIMIZE
			SAFE_DELETE_ARRAY(face_remap);
			SAFE_DELETE_ARRAY(remap_face_indices);
			SAFE_DELETE_ARRAY(vertices_remap);
#endif
		}
		SAFE_DELETE_ARRAY(stream);
	}

	bool MeshResource::LoadRawData(const Core::Identifier& path, F32 scale)
	{
		bool ret = false;

		if (!mesh)
			mesh = ptr_new Mesh;

		mesh->res_path = path;

		Lua::LuaState * L = Lua::LuaState::NewState();
		int top = L->GetTop();

		L->NewTable();
		if (L->LoadFile(path.Str(), true) == 0)
		{
			L->PushValue(top + 1);
			L->SetFenv(-2);

			if (L->DoCall(0, 0))
			{
				const char *msg = L->ToString(-1);
				if (msg) 
					Console.WriteLine(msg);
				L->Pop(1);
			}
			else
			{
				{
					L->GetField(top + 1, "Joints");
					Array<Core::Identifier> joints;
					lua_LoadArray(L, -1, joints);
					L->Pop(1);

					L->GetField(top + 1, "Mesh");

					L->GetField(-1, "Points");
					Array<float> points;
					lua_LoadArray(L, -1, points);
					L->Pop(1);

					L->GetField(-1, "FaceVertexCount");
					Array<int> face_vertex_count;
					lua_LoadArray(L, -1, face_vertex_count);
					L->Pop(1);

					L->GetField(-1, "FaceVertices");
					Array<int> face_vertices;
					lua_LoadArray(L, -1, face_vertices);
					L->Pop(1);

					mesh->Create(points.Size() / 3, face_vertex_count.Size(), (const Core::Vector3*)points.GetData(), face_vertex_count.GetData(), face_vertices.GetData());

					L->GetField(-1, "FaceTriangleCount");
					Array<int> face_triangle_count;
					lua_LoadArray(L, -1, face_triangle_count);
					L->Pop(1);

					L->GetField(-1, "FaceTriangles");
					Array<int> face_triangles;
					lua_LoadArray(L, -1, face_triangles);
					L->Pop(1);

					mesh->Triangulate(face_triangle_count.GetData(), face_triangles.GetData());

					L->GetField(-1, "Normals");
					Array<float> normals;
					lua_LoadArray(L, -1, normals);
					L->Pop(1);

					L->GetField(-1, "FaceVertexNormals");
					Array<int> face_vertex_normals;
					lua_LoadArray(L, -1, face_vertex_normals);
					L->Pop(1);

					mesh->SetNormals(normals.Size() / 3, (const Core::Vector3*)normals.GetData(), face_vertex_normals.GetData());

					L->GetField(-1, "BlendIndices");
					Array<int> indices;
					lua_LoadArray(L, -1, indices);
					L->Pop(1);

					L->GetField(-1, "BlendWeights");
					Array<float> weights;
					lua_LoadArray(L, -1, weights);
					L->Pop(1);

					L->GetField(-1, "BlendCounts");
					Array<int> counts;
					lua_LoadArray(L, -1, counts);
					L->Pop(1);

					mesh->CreateSkinCluster(joints.Size(), joints.GetData(), NULL, NULL, NULL, counts.Size(), counts.GetData(), indices.GetData(), weights.GetData());

					L->GetField(-1, "UVSets");
					int uvset_count = L->ObjLen(-1);
					for (int i = 0; i < uvset_count; ++ i)
					{
						L->PushInteger(i + 1);
						L->GetTable(-2);

						L->GetField(-1, "Name");
						const char* name = L->ToString(-1);
						L->Pop(1);

						L->GetField(-1, "Tangents");
						Core::Array<float> tangents;
						lua_LoadArray(L, -1, tangents);
						L->Pop(1);

						L->GetField(-1, "Binormals");
						Core::Array<float> binormals;
						lua_LoadArray(L, -1, binormals);
						L->Pop(1);

						L->GetField(-1, "UVs");
						Core::Array<float> uvs;
						lua_LoadArray(L, -1, uvs);
						L->Pop(1);

						L->GetField(-1, "FaceVertexUVIndices");
						Core::Array<int> face_vertex_uvs;
						lua_LoadArray(L, -1, face_vertex_uvs);
						L->Pop(1);

						L->GetField(-1, "FaceVertexTangentIndices");
						Core::Array<int> face_tb_index;
						lua_LoadArray(L, -1, face_tb_index);
						L->Pop(1);

						if (tangents.Size() > 0 && binormals.Size() && i == 0)
							mesh->CreateUVSet(name, uvs.Size() / 2, tangents.Size() / 3, face_tb_index.GetData(), (const Core::Vector2*)uvs.GetData(), (const Core::Vector3*)tangents.GetData(), (const Core::Vector3*)binormals.GetData(), face_vertex_uvs.GetData(), face_vertex_uvs.Size());
						else
							mesh->CreateUVSet(name, uvs.Size() / 2, 0, 0, (const Core::Vector2*)uvs.GetData(), NULL, NULL, face_vertex_uvs.GetData(), face_vertex_uvs.Size());
						L->Pop(1);
					}
					L->Pop(1);

					L->GetField(-1, "Colors");
					Array<float> colors;
					lua_LoadArray(L, -1, colors);
					L->Pop(1);

					L->GetField(-1, "FaceVertexColors");
					Array<int> face_vertex_colors;
					lua_LoadArray(L, -1, face_vertex_colors);
					L->Pop(1);

					mesh->CreateColorSet("default", colors.Size() / 4, (const Core::Color4*)colors.GetData(), face_vertex_colors.GetData(), face_vertex_colors.Size());

					L->GetField(-1, "FaceMaterials");
					Array<int> face_materials;
					lua_LoadArray(L, -1, face_materials);
					L->Pop(1);

					mesh->CreateShadingGroup("material", 0, NULL, face_materials.GetData());

					L->Pop(1);
				}

				bool IsSkinedMesh = false;

				struct VtxIndex
				{
					U32 id;
					U32 vertex;
					U32 normal;
					U32 texcoord[3];
					U32 color;
					U32 tb;
				};
				Array<VtxIndex> vtx_indices;
				const Vector2* map[3] = { NULL };
				map[0] = mesh->GetUVs(0);
				map[1] = mesh->GetUVs(1);
				map[2] = mesh->GetUVs(2);
				const Color4* color = mesh->GetColors(0);
				U32 color_size = mesh->GetColorsSize(0);

				for (int f = 0, i = 0; f < mesh->NumFaces(); f++)
				{
					Array<int> vertices;
					Array<int> normals;
					Array<int> texcoords[3];
					Array<int> colors;
					Array<int> tbindex;

					mesh->GetFaceVertices(f, vertices);
					mesh->GetFaceVertexNormals(f, normals);
					mesh->GetFaceVertexColors(f, 0, colors);

					for (U32 uv = 0; uv < 3; uv++)
					{
						if (map[uv])
							mesh->GetFaceVertexUVs(f, uv, texcoords[uv]);
					}

					for (int fv = 0; fv < mesh->NumFaceVertices(f); fv++, i++)
					{
						VtxIndex& vi = vtx_indices.PushBack();
						vi.id = i;
						vi.vertex = vertices[fv];

						if (color && fv < (int)color_size)
							vi.color = colors[fv];
						else
							vi.color = -1;

						if (mesh->NumNormals())
							vi.normal = normals[fv];
						else
							vi.normal = -1;

						for (U32 uv = 0; uv < 3; uv++)
						{
							if (map[uv])
								vi.texcoord[uv] = texcoords[uv][fv];
							else
								vi.texcoord[uv] = -1;
						}
					}
				}

				struct SortFunc
				{
					bool operator() (const VtxIndex& left, const VtxIndex& right) const
					{
						if (left.texcoord[0] < right.texcoord[0] ||
							left.texcoord[1] < right.texcoord[1] ||
							left.texcoord[2] < right.texcoord[2] ||
							left.color < right.color ||
							left.normal < right.normal ||
							left.vertex < right.vertex ||
							left.id < right.id)
							return true;
						return false;
					}
				};
				quick_sort(&vtx_indices[0], vtx_indices.Size(), SortFunc());

				Array<U32>	new_indices;
				new_indices.Resize(vtx_indices.Size());

				Array<U32>	vertices;
				vertices.Reserve(vtx_indices.Size());

				U32 id_vertex = -1;
				U32 id_normal = -1;
				U32 id_texcoord[3] = {-1};
				U32 id_color = -1;

				for (U32 i = 0; i < vtx_indices.Size(); i++)
				{
					VtxIndex& vtx_index = vtx_indices[i];
					if (id_vertex != vtx_index.vertex ||
						id_normal != vtx_index.normal||
						id_texcoord[0] != vtx_index.texcoord[0] ||
						id_texcoord[1] != vtx_index.texcoord[1] ||
						id_color != vtx_index.color)
					{
						id_vertex = vtx_index.vertex;
						id_normal = vtx_index.normal;
						id_texcoord[0] = vtx_index.texcoord[0];
						id_texcoord[1] = vtx_index.texcoord[1];
						id_color = vtx_index.color;

						vertices.PushBack(i);
					}
					new_indices[vtx_index.id] = vertices.Size() - 1;
				}

				Vector3* const  points = mesh->GetPoints();
				const Vector3* normals = mesh->GetNormals();
				const Vector3* tangents = mesh->GetTangents(0);
				const Vector3* binormals = mesh->GetBinormals(0);
				const Color4* colors = mesh->GetColors(0);
				U32 colors_size = mesh->GetColorsSize(0);

				for (int i = 0; i < mesh->NumVertices(); ++i)
				{
					points[i] *= scale;
				}

				U32 vertex_count = vertices.Size();

				data.Clear();

				data.vertices.Reserve(vertex_count);
				if (normals)
					data.normals.Reserve(vertex_count);
				if (tangents)
					data.tangents.Reserve(vertex_count);
				if (binormals)
					data.binormals.Reserve(vertex_count);
				if (map[0])
					data.uv0.Reserve(vertex_count);
				if (map[1])
					data.uv1.Reserve(vertex_count);
				if (colors)
					data.color.Reserve(vertex_count);
				if (map[2])
					data.uv2.Reserve(vertex_count);
				data.blendweight.Reserve(vertex_count);

				uint joint_count = mesh->NumJoints();

				const Identifier* joint_name = mesh->GetJointNames();
				for (U32 i = 0; i < joint_count; ++i)
				{
					bonename.PushBack(*(joint_name + i));
					bone_aabb.PushBack();
					bone_aabb.Back().Min = Vector3(F32_MAX, F32_MAX, F32_MAX);
					bone_aabb.Back().Max = Vector3(-F32_MAX, -F32_MAX, -F32_MAX);
				}

				for (U32 i = 0; i < vertex_count; i++)
				{
					VtxIndex& v = vtx_indices[vertices[i]];
					data.vertices.PushBack(points[v.vertex]);
					if (normals)	
						data.normals.PushBack(normals[v.normal]);
					if (map[0])
					{
						if (v.texcoord[0] < 0 || v.texcoord[0] >= vertex_count)
						{
							data.uv0.PushBack(Vector2::kZero);
						}
						else
						{
							data.uv0.PushBack(Vector2(map[0][v.texcoord[0]].x, 1.f - map[0][v.texcoord[0]].y));
						}
						if (!tangents || v.id < 0)
						{
							data.tangents.PushBack(Vector3::kZero);
						}
						else
						{
							data.tangents.PushBack(tangents[v.id]);
						}
						if (!binormals ||  v.id < 0)
						{
							data.binormals.PushBack(Vector3::kZero);
						}
						else
						{
							data.binormals.PushBack(binormals[v.id]);
						}
					}
					if (colors)
					{
						if (v.color < colors_size)
							data.color.PushBack(colors[v.color]);
						else
							data.color.PushBack(-1);
					}
					if (map[1])
					{
						if (v.texcoord[1] < 0 || v.texcoord[1] >= vertex_count)
						{
							data.uv1.PushBack(Vector2::kZero);
						}
						else
						{
							data.uv1.PushBack(Vector2(map[1][v.texcoord[1]].x, 1.f - map[1][v.texcoord[1]].y));
						}
					}
					if (map[2])
					{
						U32 i1 = v.texcoord[2];
						if (v.texcoord[2] < 0 || v.texcoord[2] >= vertex_count)
						{
							data.uv2.PushBack(Vector2::kZero);
						}
						else
						{
							data.uv2.PushBack(Vector2(map[2][v.texcoord[2]].x, 1.f - map[2][v.texcoord[2]].y));
						}
					}

					Array<int> blendindex;
					Array<F32> blendweight;
					mesh->GetWeights(v.vertex, blendindex, blendweight);

					mesh_type = kStatic;
					if (blendindex.Size() > 0)
					{
						mesh_type = kSkin;
						Vector4& bw = data.blendweight.PushBack();
						bw = Vector4::kZero;
						for (U32 j = 0; j < blendindex.Size(); j++)
						{
							data.blendindices.PushBack(blendindex[j] - 1);
							bw[j] = blendweight[j];

							// for bounding box
							
							if (bw[j] > 0.25f)
							{
								int index = blendindex[j] -1;
								if ((U32)index >= bone_aabb.Size())
								{
									LogSystem.WriteLinef("Resource Error: %s blend index[%d] bigger than bone number[%d]", path, index, bone_aabb.Size());
									return false;
								}
								Vector3& position = data.vertices.Back();
								AxisAlignedBox& aabb = bone_aabb[index];
								
								aabb.Min = Min(aabb.Min, position);
								aabb.Max = Max(aabb.Max, position);
							}
						}

						for (U32 j = blendindex.Size(); j < 4; j++)
						{
							data.blendindices.PushBack(-1);
							bw[j] = 0;
						}
					}
				}

				const int* shading_group_data = mesh->GetShadingGroupData(0);
				int shading_group_count = 0;
				for (int i = 0; i < mesh->NumFaces(); ++ i)
					shading_group_count = Max(shading_group_count, shading_group_data[i]);
				shading_group_count += 1;
				Array<U32> index_count;
				index_count.Resize(shading_group_count + 1);
				for (U32 i = 0; i < index_count.Size(); ++ i)
					index_count[i] = 0;
				for (int i = 0; i < mesh->NumFaces(); ++ i)
				{
					uint index = shading_group_data[i] + 1;
					index_count[index] += mesh->NumFaceTriangles(i);
				}
				index_buffer_size = 3 * mesh->NumTriangles() * sizeof(U32);
				{
					primitives.Resize(shading_group_count + 1);
					for (uint i = 0; i < primitives.Size(); ++ i)
					{
						primitives[i].primitive_count = index_count[i];
						primitives[i].indices.Reserve(primitives[i].primitive_count * 3);
					}

					uint base_index = 0;
					for (int i = 0; i < mesh->NumFaces(); ++ i)
					{
						U32 index = shading_group_data[i] + 1;
						for (int t = 0; t < mesh->NumFaceTriangles(i); ++ t)
						{
							int idx[3];
							mesh->GetFaceTriangle(i, t, idx);

							primitives[index].indices.PushBack(new_indices[idx[0] + base_index]);
							primitives[index].indices.PushBack(new_indices[idx[1] + base_index]);
							primitives[index].indices.PushBack(new_indices[idx[2] + base_index]);
						}
						base_index += mesh->NumFaceVertices(i);
					}
				}
				L->GetField(top + 1, "Materials");
				int material_count = L->ObjLen(-1);

				bool first = true;						
				F32 max_x;
				F32 min_x;	
				for (int p = 0; p < material_count; ++ p)
				{
					if (p + 1 >= (int)primitives.Size())
						break;

					Primitive& primitive = primitives[p + 1];

					L->PushInteger(p + 1);
					L->GetTable(-2);

					primitive.material = ptr_new Material;

					L->GetField(-1, "IsInVisible");
					primitive.visible = L->ToInteger(-1) ? false : true;
					L->Pop(1);
		
					L->GetField(-1, "CollisionMode");
					primitive.collision_mode = L->ToInteger(-1);

					if (primitive.visible && (primitive.collision_mode == 1))
					{							
						if (first)
						{
							local_aabb.Min = local_aabb.Max = data.vertices[primitive.indices[0]];
							max_x = min_x = (data.vertices[primitive.indices[0]]).x;
							first = false;
						}


						for (U32 k = 0; k < primitive.indices.Size(); k++)
						{
							local_aabb.UnionWithVector(data.vertices[primitive.indices[k]]);
							max_x = Max(data.vertices[primitive.indices[k]].x, max_x);
							min_x = Min(data.vertices[primitive.indices[k]].x, min_x);
							ib_stream.PushBack(primitive.indices[k]);
						}
					}

					L->Pop(1);

					L->GetField(-1, "BlendLayer");
					primitive.layer = L->ToInteger(-1);
					L->Pop(1);

					L->GetField(-1, "AlphaBlendMode");
					U32 blend_mode = 0;
					blend_mode = L->ToInteger(-1);
					L->Pop(1);
					if (blend_mode == 0)
					{
						primitive.blend_mode = kBlendNone;
					}
					else if (blend_mode == 1)
					{
						primitive.blend_mode = kSourceAlphaAdd;
					}
					else if (blend_mode == 2)
					{
						primitive.blend_mode = kAlphaTest;
					}
					else if (blend_mode == 3)
					{
						primitive.blend_mode = kAdditive;
					}
					else if (blend_mode == 4)
					{
						primitive.blend_mode = kAlphaTest;
					}
					else
					{
						primitive.blend_mode = kBlendNone;
						LogSystem.Writef("MeshResource::LoadRawData() Unknow Blendmode : %d", (int)blend_mode);
					}

					L->GetField(-1, "CullingMode");
					U32 cull_mode = kCullModeCW;
					cull_mode = L->ToInteger(-1);
					primitive.cull_mode = (CullMode)L->ToInteger(-1);
					L->Pop(1);

					L->GetField(-1, "PhysicsMaterial");
					int physx_material = L->ToInteger(-1);

					L->Pop(1);
					mesh->physx_material.PushBack(physx_material);
					physical_material.PushBack(physx_material);

					primitive.material->Load(L, path);

					ret = true;
				}
			}
		}

		else
		{
			const char *msg = L->ToString(-1);
			if (msg) Console.WriteLine(msg);
			L->Pop(1);
		}
		L->SetTop(top);

		L->Close();
		mesh = NullPtr;

		return ret;
	}
}