namespace Client
{
	enum AlphaBlendMode
	{
		kBlendNone =		1 << 0,
		kAlphaTest =		1 << 1,
		kSourceAlphaAdd =	1 << 2,
		kDestAlphaAdd =		1 << 3,
		kAlphaBlend =		1 << 4,
		kAdditive =			1 << 5,
		kInverseColor =		1 << 6,
		kTransparency =		kSourceAlphaAdd | kDestAlphaAdd | kAlphaBlend | kAdditive | kInverseColor,
		kOpacity =			kBlendNone | kAlphaTest,
	};

	enum CullMode
	{
		kCullModeCW = 0,
		kCullModeCCW,
		kCullModeNone,
	};
}