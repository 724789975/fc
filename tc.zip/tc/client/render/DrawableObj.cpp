#include "pch.h"

namespace Client
{
	DrawableObj::DrawableObj()
	{
		lightmap_color = ptr_new RenderTexture;
		lightmap_color->CreateRenderTexture(1, 1, 1, D3DUSAGE_RENDERTARGET, D3DFMT_A8R8G8B8);
	}

	/// destructor
	DrawableObj::~DrawableObj()
	{
	}

	///
	tempc_ptr(RenderTexture) DrawableObj::GetLightmapColor()
	{
		return lightmap_color;
	}
}