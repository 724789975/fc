namespace Client
{ 
	class DrawableObj : public Core::Object
	{
	public:
		DrawableObj();

		/// destructor
		virtual ~DrawableObj();

	public:
		/// draw
		virtual void Draw(Primitive::DrawType drawtype, bool immediate = false) = 0;

	public:
		/// get position
		virtual const Core::Vector3 & GetPosition() = 0;

		/// get rotation
		virtual const Core::Quaternion & GetRotation() = 0;

		/// get light map color
		virtual tempc_ptr(RenderTexture) GetLightmapColor();

	private:
		/// lightmap_color
		sharedc_ptr(RenderTexture) lightmap_color;
	};
}