#include "pch.h"
using namespace Core;

namespace Client
{
	inline F32 Random(F32 x, F32 y)		
	{
		F32 randNum = (F32)rand() / RAND_MAX; 
		F32 num = x + (y - x) * randNum; 
		return num; 
	}

	inline F32 ChooseRandom(F32 first, F32 second)
	{
		F32 randNum = Random(0.0f, 1.0f);
		if (randNum >= 0.5f)
			return second;
		return first;
	}
}

DEFINE_PDE_TYPE_CLASS(Client::Parameter)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_PROPERTY_RW(Name);
	}
};
REGISTER_PDE_TYPE(Client::Parameter);

DEFINE_PDE_TYPE_CLASS(Client::ParameterInt)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_SUPER(Client::Parameter);
		ADD_PDE_PROPERTY_RW(Constant);
		ADD_PDE_PROPERTY_RW(Random);
		ADD_PDE_PROPERTY_RW(EmitLifeSpline);
		ADD_PDE_PROPERTY_RW(ParticleLifeSpline);

		ADD_PDE_METHOD(GetInitial);
		ADD_PDE_METHOD(GetParticleLifeValue);
		ADD_PDE_METHOD(SaveToStream);
	}
};
REGISTER_PDE_TYPE(Client::ParameterInt);

namespace Client
{
	ParameterInt::ParameterInt()
		: m_Constant(0)
		, m_Random(0)
	{
		m_EmitLifeSpline = ptr_new PdeSplineF32;
		m_ParticleLifeSpline = ptr_new PdeSplineF32;
	}

	ParameterInt::~ParameterInt()
	{
		m_EmitLifeSpline = NullPtr;
		m_ParticleLifeSpline = NullPtr;
	}

	int ParameterInt::GetInitial()
	{
		return m_Constant * Random(1.f - m_Random, 1.f);
	}

	int ParameterInt::GetEmitLifeValue(int v, F32 t)
	{
		if (m_EmitLifeSpline->GetControlPointCount())
			return v * m_EmitLifeSpline->GetSplineValue(t);
		else
			return v;
	}

	int ParameterInt::GetParticleLifeValue(int v, F32 t)
	{
		if (m_ParticleLifeSpline->GetControlPointCount())
			return v * m_ParticleLifeSpline->GetSplineValue(t);
		else
			return v;
	}

	PDE_ATTRIBUTE_GETTER(ParameterInt, Constant, int)
	{
		return m_Constant;
	}

	PDE_ATTRIBUTE_SETTER(ParameterInt, Constant, int)
	{
		m_Constant = value;
	}

	PDE_ATTRIBUTE_GETTER(ParameterInt, Random, F32)
	{
		return m_Random;
	}

	PDE_ATTRIBUTE_SETTER(ParameterInt, Random, F32)
	{
		m_Random = value;
	}

	PDE_ATTRIBUTE_GETTER(ParameterInt, EmitLifeSpline, tempc_ptr(Core::PdeSplineF32))
	{
		return m_EmitLifeSpline;
	}

	PDE_ATTRIBUTE_SETTER(ParameterInt, EmitLifeSpline, tempc_ptr(Core::PdeSplineF32))
	{
		m_EmitLifeSpline = value;
	}

	PDE_ATTRIBUTE_GETTER(ParameterInt, ParticleLifeSpline, tempc_ptr(Core::PdeSplineF32))
	{
		return m_ParticleLifeSpline;
	}

	PDE_ATTRIBUTE_SETTER(ParameterInt, ParticleLifeSpline, tempc_ptr(Core::PdeSplineF32))
	{
		m_ParticleLifeSpline = value;
	}

	void ParameterInt::SaveData(Stream& stream)
	{
		stream.Write(&m_Constant, sizeof(int));
		stream.Write(&m_Random, sizeof(F32));

		U32 count = m_EmitLifeSpline->GetControlPointCount();
		stream.Write(&count, sizeof(U32));
		for (U32 i = 0; i < count; i++)
		{
			stream.Write(&m_EmitLifeSpline->GetControlPoint(i), sizeof(PdeSplineF32::ControlPoint));
		}

		count = m_ParticleLifeSpline->GetControlPointCount();
		stream.Write(&count, sizeof(U32));
		for (U32 i = 0; i < count; i++)
		{
			stream.Write(&m_ParticleLifeSpline->GetControlPoint(i), sizeof(PdeSplineF32::ControlPoint));
		}
	}

	void ParameterInt::LoadData(Stream& stream)
	{
		stream.Read(&m_Constant, sizeof(int));
		stream.Read(&m_Random, sizeof(F32));

		PdeSplineF32::ControlPoint point;

		U32 count;
		stream.Read(&count, sizeof(U32));
		for (U32 i = 0; i < count; i++)
		{
			stream.Read(&point, sizeof(PdeSplineF32::ControlPoint));
			m_EmitLifeSpline->AddControlPoint(point);
		}

		stream.Read(&count, sizeof(U32));
		for (U32 i = 0; i < count; i++)
		{
			stream.Read(&point, sizeof(PdeSplineF32::ControlPoint));
			m_ParticleLifeSpline->AddControlPoint(point);
		}
	}

	String ParameterInt::SaveToStream(U32 pos)
	{
		CStrBuf<1024> str;

		CStrBuf<256> s1; 
		CStrBuf<256> s2;

		CStrBuf<256> value;

		for (U32 i = 0; i < pos; i++)
		{
			s1.contract("\t");
			s2.contract("\t");
		}
		s2.contract("\t");
		str.contract("\n");
		str.contract(s1);
		str.contract("{\n");
		str.contract(s2);
		str.contract("Constant = ");
		value.format("%d,\n", GetConstant());
		str.contract(value);

		str.contract(s2);
		str.contract("Random = ");
		value.format("%g,\n", GetRandom());
		str.contract(value);

		if (GetEmitLifeSpline()->GetControlPointCount() > 0)
		{
			str.contract(s2);
			str.contract("EmitLifeSpline = \n");
			str.contract(s2);
			str.contract("{\n");
			GetEmitLifeSpline()->SaveToStream(str, s2);
			str.contract(s2);
			str.contract("},\n");
		}

		if (GetParticleLifeSpline()->GetControlPointCount() > 0)
		{
			str.contract(s2);
			str.contract("EmitLifeSpline = \n");
			str.contract(s2);
			str.contract("{\n");
			GetParticleLifeSpline()->SaveToStream(str, s2);
			str.contract(s2);
			str.contract("},\n");
		}

		str.contract(s1);
		str.contract("},\n");

		String a(str);
		return a;
	}
}

DEFINE_PDE_TYPE_CLASS(Client::ParameterFloat)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_SUPER(Client::Parameter);
		ADD_PDE_PROPERTY_RW(Constant);
		ADD_PDE_PROPERTY_RW(Random);
		ADD_PDE_PROPERTY_RW(EmitLifeSpline);
		ADD_PDE_PROPERTY_RW(ParticleLifeSpline);

		ADD_PDE_METHOD(SaveToStream);
	}
};
REGISTER_PDE_TYPE(Client::ParameterFloat);

namespace Client
{
	ParameterFloat::ParameterFloat()
		: m_Constant(0)
		, m_Random(0)
	{
		m_EmitLifeSpline = ptr_new PdeSplineF32;
		m_ParticleLifeSpline = ptr_new PdeSplineF32;
	}

	ParameterFloat::~ParameterFloat()
	{
		m_EmitLifeSpline = NullPtr;
		m_ParticleLifeSpline = NullPtr;
	}


	PDE_ATTRIBUTE_GETTER(ParameterFloat, Constant, F32)
	{
		return m_Constant;
	}

	PDE_ATTRIBUTE_SETTER(ParameterFloat, Constant, F32)
	{
		m_Constant = value;
	}

	PDE_ATTRIBUTE_GETTER(ParameterFloat, Random, F32)
	{
		return m_Random;
	}

	PDE_ATTRIBUTE_SETTER(ParameterFloat, Random, F32)
	{
		m_Random = value;
	}

	PDE_ATTRIBUTE_GETTER(ParameterFloat, EmitLifeSpline, tempc_ptr(Core::PdeSplineF32))
	{
		return m_EmitLifeSpline;
	}

	PDE_ATTRIBUTE_SETTER(ParameterFloat, EmitLifeSpline, tempc_ptr(Core::PdeSplineF32))
	{
		m_EmitLifeSpline = value;
	}

	PDE_ATTRIBUTE_GETTER(ParameterFloat, ParticleLifeSpline, tempc_ptr(Core::PdeSplineF32))
	{
		return m_ParticleLifeSpline;
	}

	PDE_ATTRIBUTE_SETTER(ParameterFloat, ParticleLifeSpline, tempc_ptr(Core::PdeSplineF32))
	{
		m_ParticleLifeSpline = value;
	}

	F32 ParameterFloat::GetInitial()
	{
		return m_Constant * Random(1.f - m_Random, 1.f);
	}

	F32 ParameterFloat::GetEmitLifeValue(F32 v, F32 t)
	{
		if (m_EmitLifeSpline->GetControlPointCount())
			return v * m_EmitLifeSpline->GetSplineValue(t);
		else
			return v;
	}

	F32 ParameterFloat::GetParticleLifeValue(F32 v, F32 t)
	{
		if (m_ParticleLifeSpline->GetControlPointCount())
			return v * m_ParticleLifeSpline->GetSplineValue(t);
		else
			return v;
	}

	void ParameterFloat::SaveData(Stream& stream)
	{
		stream.Write(&m_Constant, sizeof(F32));
		stream.Write(&m_Random, sizeof(F32));

		U32 count = m_EmitLifeSpline->GetControlPointCount();
		stream.Write(&count, sizeof(U32));
		for (U32 i = 0; i < count; i++)
		{
			stream.Write(&m_EmitLifeSpline->GetControlPoint(i), sizeof(PdeSplineF32::ControlPoint));
		}

		count = m_ParticleLifeSpline->GetControlPointCount();
		stream.Write(&count, sizeof(U32));
		for (U32 i = 0; i < count; i++)
		{
			PdeSplineF32::ControlPoint& point = m_ParticleLifeSpline->GetControlPoint(i);
			stream.Write(&m_ParticleLifeSpline->GetControlPoint(i), sizeof(PdeSplineF32::ControlPoint));
		}
	}

	void ParameterFloat::LoadData(Stream& stream)
	{
		stream.Read(&m_Constant, sizeof(F32));
		stream.Read(&m_Random, sizeof(F32));

		PdeSplineF32::ControlPoint point;

		U32 count;
		stream.Read(&count, sizeof(U32));
		for (U32 i = 0; i < count; i++)
		{
			stream.Read(&point, sizeof(PdeSplineF32::ControlPoint));
			m_EmitLifeSpline->AddControlPoint(point);
		}

		stream.Read(&count, sizeof(U32));
		for (U32 i = 0; i < count; i++)
		{
			stream.Read(&point, sizeof(PdeSplineF32::ControlPoint));
			m_ParticleLifeSpline->AddControlPoint(point);
		}
	}

	String ParameterFloat::SaveToStream(U32 pos)
	{
		//DynamicMemoryStream stream;
		//TextStreamWriter writer(stream);


		CStrBuf<1024> str;

		CStrBuf<256> s1; 
		CStrBuf<256> s2;

		CStrBuf<256> value;

		for (U32 i = 0; i < pos; i++)
		{
			s1.contract("\t");
			s2.contract("\t");
		}
		s2.contract("\t");

		//stream	
		str.contract("\n");
		str.contract(s1);
		str.contract("{\n");
		str.contract(s2);
		str.contract("Constant = ");
		value.format("%g,\n", GetConstant());
		str.contract(value);

		str.contract(s2);
		str.contract("Random = ");
		value.format("%g,\n", GetRandom());
		str.contract(value);

		if (GetEmitLifeSpline()->GetControlPointCount() > 0)
		{
			str.contract(s2);
			str.contract("EmitLifeSpline = \n");
			str.contract(s2);
			str.contract("{\n");
			GetEmitLifeSpline()->SaveToStream(str, s2);
			str.contract(s2);
			str.contract("},\n");
		}

		if (GetParticleLifeSpline()->GetControlPointCount() > 0)
		{
			str.contract(s2);
			str.contract("ParticleLifeSpline = \n");
			str.contract(s2);
			str.contract("{\n");
			GetParticleLifeSpline()->SaveToStream(str, s2);
			str.contract(s2);
			str.contract("},\n");
		}

		str.contract(s1);
		str.contract("},\n");

		String a(str);
		return a;
	}
}

DEFINE_PDE_TYPE_CLASS(Client::ParameterFloat2)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_SUPER(Client::Parameter);
		ADD_PDE_PROPERTY_RW(Constant);
		ADD_PDE_PROPERTY_RW(Random);
		ADD_PDE_PROPERTY_RW(EmitLifeSplineX);
		ADD_PDE_PROPERTY_RW(EmitLifeSplineY);
		ADD_PDE_PROPERTY_RW(ParticleLifeSplineX);
		ADD_PDE_PROPERTY_RW(ParticleLifeSplineY);
		ADD_PDE_METHOD(SaveToStream);
	}
};
REGISTER_PDE_TYPE(Client::ParameterFloat2);

namespace Client
{
	ParameterFloat2::ParameterFloat2()
		: m_Constant(Vector2::kZero)
		, m_Random(Vector2::kZero)
	{
		m_EmitLifeSplineX = ptr_new PdeSplineF32;
		m_EmitLifeSplineY = ptr_new PdeSplineF32;
		m_ParticleLifeSplineX = ptr_new PdeSplineF32;
		m_ParticleLifeSplineY = ptr_new PdeSplineF32;
	}

	ParameterFloat2::~ParameterFloat2()
	{
		m_EmitLifeSplineX = NullPtr;
		m_EmitLifeSplineY = NullPtr;
		m_ParticleLifeSplineX = NullPtr;
		m_ParticleLifeSplineY = NullPtr;

	}

	PDE_ATTRIBUTE_GETTER(ParameterFloat2, Constant, Vector2&)
	{
		return m_Constant;
	}

	PDE_ATTRIBUTE_SETTER(ParameterFloat2, Constant, Vector2&)
	{
		m_Constant = value;
	}

	PDE_ATTRIBUTE_GETTER(ParameterFloat2, Random, Vector2&)
	{
		return m_Random;
	}

	PDE_ATTRIBUTE_SETTER(ParameterFloat2, Random, Vector2&)
	{
		m_Random = value;
	}

	PDE_ATTRIBUTE_GETTER(ParameterFloat2, EmitLifeSplineX, tempc_ptr(Core::PdeSplineF32))
	{
		return m_EmitLifeSplineX;
	}

	PDE_ATTRIBUTE_SETTER(ParameterFloat2, EmitLifeSplineX, tempc_ptr(Core::PdeSplineF32))
	{
		m_EmitLifeSplineX = value;
	}

	PDE_ATTRIBUTE_GETTER(ParameterFloat2, EmitLifeSplineY, tempc_ptr(Core::PdeSplineF32))
	{
		return m_EmitLifeSplineY;
	}

	PDE_ATTRIBUTE_SETTER(ParameterFloat2, EmitLifeSplineY, tempc_ptr(Core::PdeSplineF32))
	{
		m_EmitLifeSplineY = value;
	}

	PDE_ATTRIBUTE_GETTER(ParameterFloat2, ParticleLifeSplineX, tempc_ptr(Core::PdeSplineF32))
	{
		return m_ParticleLifeSplineX;
	}

	PDE_ATTRIBUTE_SETTER(ParameterFloat2, ParticleLifeSplineX, tempc_ptr(Core::PdeSplineF32))
	{
		m_ParticleLifeSplineX = value;
	}

	PDE_ATTRIBUTE_GETTER(ParameterFloat2, ParticleLifeSplineY, tempc_ptr(Core::PdeSplineF32))
	{
		return m_ParticleLifeSplineY;
	}

	PDE_ATTRIBUTE_SETTER(ParameterFloat2, ParticleLifeSplineY, tempc_ptr(Core::PdeSplineF32))
	{
		m_ParticleLifeSplineY = value;
	}


	Vector2 ParameterFloat2::GetInitial()
	{
		return m_Constant * Vector2(Random(1.f - m_Random.x, 1.f), Random(1.f - m_Random.y, 1.f));
	}

	Vector2 ParameterFloat2::GetEmitLifeValue(Vector2& v, F32 t)
	{
		if (m_EmitLifeSplineX->GetControlPointCount() && m_EmitLifeSplineY->GetControlPointCount())
			return Vector2(m_EmitLifeSplineX->GetSplineValue(t), m_EmitLifeSplineY->GetSplineValue(t)) * v;
		else
			return v;
	}

	Vector2 ParameterFloat2::GetParticleLifeValue(Vector2& v, F32 t)
	{
		Vector2 value = v;
		if (m_ParticleLifeSplineX->GetControlPointCount())
			value.x = m_ParticleLifeSplineX->GetSplineValue(t) * v.x;
		if (m_ParticleLifeSplineY->GetControlPointCount())
			value.y = m_ParticleLifeSplineY->GetSplineValue(t) * v.y;
		return value;
	}

	void ParameterFloat2::SaveData(Stream& stream)
	{
		stream.Write(&m_Constant, sizeof(Vector2));
		stream.Write(&m_Random, sizeof(Vector2));

		U32 count = m_EmitLifeSplineX->GetControlPointCount();
		stream.Write(&count, sizeof(U32));
		for (U32 i = 0; i < count; i++)
		{
			stream.Write(&m_EmitLifeSplineX->GetControlPoint(i), sizeof(PdeSplineF32::ControlPoint));
		}

		count = m_EmitLifeSplineY->GetControlPointCount();
		stream.Write(&count, sizeof(U32));
		for (U32 i = 0; i < count; i++)
		{
			stream.Write(&m_EmitLifeSplineY->GetControlPoint(i), sizeof(PdeSplineF32::ControlPoint));
		}

		count = m_ParticleLifeSplineX->GetControlPointCount();
		stream.Write(&count, sizeof(U32));
		for (U32 i = 0; i < count; i++)
		{
			stream.Write(&m_ParticleLifeSplineX->GetControlPoint(i), sizeof(PdeSplineF32::ControlPoint));
		}

		count = m_ParticleLifeSplineY->GetControlPointCount();
		stream.Write(&count, sizeof(U32));
		for (U32 i = 0; i < count; i++)
		{
			stream.Write(&m_ParticleLifeSplineY->GetControlPoint(i), sizeof(PdeSplineF32::ControlPoint));
		}
	}

	void ParameterFloat2::LoadData(Stream& stream)
	{
		stream.Read(&m_Constant, sizeof(Vector2));
		stream.Read(&m_Random, sizeof(Vector2));

		PdeSplineF32::ControlPoint point;
		U32 count = 0;
		stream.Read(&count, sizeof(U32));
		for (U32 i = 0; i < count; i++)
		{
			stream.Read(&point, sizeof(PdeSplineF32::ControlPoint));
			m_EmitLifeSplineX->AddControlPoint(point);
		}

		stream.Read(&count, sizeof(U32));
		for (U32 i = 0; i < count; i++)
		{
			stream.Read(&point, sizeof(PdeSplineF32::ControlPoint));
			m_EmitLifeSplineY->AddControlPoint(point);
		}

		stream.Read(&count, sizeof(U32));
		for (U32 i = 0; i < count; i++)
		{
			stream.Read(&point, sizeof(PdeSplineF32::ControlPoint));
			m_ParticleLifeSplineX->AddControlPoint(point);
		}

		stream.Read(&count, sizeof(U32));
		for (U32 i = 0; i < count; i++)
		{
			stream.Read(&point, sizeof(PdeSplineF32::ControlPoint));
			m_ParticleLifeSplineY->AddControlPoint(point);
		}
	}

	String ParameterFloat2::SaveToStream(U32 pos)
	{
		CStrBuf<1024> str;

		CStrBuf<256> s1; 
		CStrBuf<256> s2;

		CStrBuf<256> value;

		for (U32 i = 0; i < pos; i++)
		{
			s1.contract("\t");
			s2.contract("\t");
		}
		s2.contract("\t");
		str.contract("\n");
		str.contract(s1);
		str.contract("{\n");
		str.contract(s2);
		str.contract("Constant = Vector2(");
		value.format("%g, %g),\n", GetConstant().x, GetConstant().y);
		str.contract(value);

		str.contract(s2);
		str.contract("Random = Vector2(");
		value.format("%g, %g),\n", GetRandom().x, GetRandom().y);
		str.contract(value);

		if (GetEmitLifeSplineX()->GetControlPointCount() > 0)
		{
			str.contract(s2);
			str.contract("EmitLifeSplineX = \n");
			str.contract(s2);
			str.contract("{\n");
			GetEmitLifeSplineX()->SaveToStream(str, s2);
			str.contract(s2);
			str.contract("},\n");
		}

		if (GetParticleLifeSplineX()->GetControlPointCount() > 0)
		{
			str.contract(s2);
			str.contract("ParticleLifeSplineX = \n");
			str.contract(s2);
			str.contract("{\n");
			GetParticleLifeSplineX()->SaveToStream(str, s2);
			str.contract(s2);
			str.contract("},\n");
		}

		if (GetEmitLifeSplineY()->GetControlPointCount() > 0)
		{
			str.contract(s2);
			str.contract("EmitLifeSplineY = \n");
			str.contract(s2);
			str.contract("{\n");
			GetEmitLifeSplineY()->SaveToStream(str, s2);
			str.contract(s2);
			str.contract("},\n");
		}

		if (GetParticleLifeSplineY()->GetControlPointCount() > 0)
		{
			str.contract(s2);
			str.contract("ParticleLifeSplineY = \n");
			str.contract(s2);
			str.contract("{\n");
			GetParticleLifeSplineY()->SaveToStream(str, s2);
			str.contract(s2);
			str.contract("},\n");
		}

		str.contract(s1);
		str.contract("},\n");

		String a(str);
		return a;
	}
}

DEFINE_PDE_TYPE_CLASS(Client::ParameterFloat3)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_SUPER(Client::Parameter);
		ADD_PDE_PROPERTY_RW(Constant);
		ADD_PDE_PROPERTY_RW(Random);
		ADD_PDE_PROPERTY_RW(EmitLifeSplineX);
		ADD_PDE_PROPERTY_RW(EmitLifeSplineY);
		ADD_PDE_PROPERTY_RW(EmitLifeSplineZ);
		ADD_PDE_PROPERTY_RW(ParticleLifeSplineX);
		ADD_PDE_PROPERTY_RW(ParticleLifeSplineY);
		ADD_PDE_PROPERTY_RW(ParticleLifeSplineZ);
		ADD_PDE_METHOD(SaveToStream)

	}
};
REGISTER_PDE_TYPE(Client::ParameterFloat3)
namespace Client
{
	ParameterFloat3::ParameterFloat3()
		: m_Constant(Vector3::kZero)
		, m_Random(Vector3::kZero)
	{
		m_EmitLifeSplineX = ptr_new PdeSplineF32;
		m_EmitLifeSplineY = ptr_new PdeSplineF32;
		m_EmitLifeSplineZ = ptr_new PdeSplineF32;
		m_ParticleLifeSplineX = ptr_new PdeSplineF32;
		m_ParticleLifeSplineY = ptr_new PdeSplineF32;
		m_ParticleLifeSplineZ = ptr_new PdeSplineF32;
	}

	ParameterFloat3::~ParameterFloat3()
	{
		m_EmitLifeSplineX = NullPtr;
		m_EmitLifeSplineY = NullPtr;
		m_EmitLifeSplineZ = NullPtr;
		m_ParticleLifeSplineX = NullPtr;
		m_ParticleLifeSplineY = NullPtr;
		m_ParticleLifeSplineZ = NullPtr;
	}

	Vector3 ParameterFloat3::GetInitial()
	{
		return m_Constant * Vector3(Random(1.f - m_Random.x, 1.f), Random(1.f - m_Random.y, 1.f), Random(1.f - m_Random.z, 1.f));
	}

	Vector3 ParameterFloat3::GetEmitLifeValue(Vector3& v, F32 t)
	{
		Vector3 value = v;
		if (m_EmitLifeSplineX->GetControlPointCount())
			value.x = m_EmitLifeSplineX->GetSplineValue(t) * v.x;
		if (m_EmitLifeSplineY->GetControlPointCount())
			value.y = m_EmitLifeSplineY->GetSplineValue(t) * v.y;
		if (m_EmitLifeSplineZ->GetControlPointCount())
			value.z = m_EmitLifeSplineZ->GetSplineValue(t) * v.z;
		return value;
	}

	Vector3 ParameterFloat3::GetParticleLifeValue(Vector3& v, F32 t)
	{
		Vector3 value = v;
		if (m_ParticleLifeSplineX->GetControlPointCount())
			value.x = m_ParticleLifeSplineX->GetSplineValue(t) * v.x;
		if (m_ParticleLifeSplineY->GetControlPointCount())
			value.y = m_ParticleLifeSplineY->GetSplineValue(t) * v.y;
		if (m_ParticleLifeSplineZ->GetControlPointCount())
			value.z = m_ParticleLifeSplineZ->GetSplineValue(t) * v.z;
		return value;
	}

	PDE_ATTRIBUTE_GETTER(ParameterFloat3, Constant, Vector3&)
	{
		return m_Constant;
	}

	PDE_ATTRIBUTE_SETTER(ParameterFloat3, Constant, Vector3&)
	{
		m_Constant = value;
	}

	PDE_ATTRIBUTE_GETTER(ParameterFloat3, Random, Vector3&)
	{
		return m_Random;
	}

	PDE_ATTRIBUTE_SETTER(ParameterFloat3, Random, Vector3&)
	{
		m_Random = value;
	}

	PDE_ATTRIBUTE_GETTER(ParameterFloat3, EmitLifeSplineX, tempc_ptr(Core::PdeSplineF32))
	{
		return m_EmitLifeSplineX;
	}

	PDE_ATTRIBUTE_SETTER(ParameterFloat3, EmitLifeSplineX, tempc_ptr(Core::PdeSplineF32))
	{
		m_EmitLifeSplineX = value;
	}

	PDE_ATTRIBUTE_GETTER(ParameterFloat3, EmitLifeSplineY, tempc_ptr(Core::PdeSplineF32))
	{
		return m_EmitLifeSplineY;
	}

	PDE_ATTRIBUTE_SETTER(ParameterFloat3, EmitLifeSplineY, tempc_ptr(Core::PdeSplineF32))
	{
		m_EmitLifeSplineY = value;
	}

	PDE_ATTRIBUTE_GETTER(ParameterFloat3, EmitLifeSplineZ, tempc_ptr(Core::PdeSplineF32))
	{
		return m_EmitLifeSplineZ;
	}

	PDE_ATTRIBUTE_SETTER(ParameterFloat3, EmitLifeSplineZ, tempc_ptr(Core::PdeSplineF32))
	{
		m_EmitLifeSplineZ = value;
	}

	PDE_ATTRIBUTE_GETTER(ParameterFloat3, ParticleLifeSplineX, tempc_ptr(Core::PdeSplineF32))
	{
		return m_ParticleLifeSplineX;
	}

	PDE_ATTRIBUTE_SETTER(ParameterFloat3, ParticleLifeSplineX, tempc_ptr(Core::PdeSplineF32))
	{
		m_ParticleLifeSplineX = value;
	}

	PDE_ATTRIBUTE_GETTER(ParameterFloat3, ParticleLifeSplineY, tempc_ptr(Core::PdeSplineF32))
	{
		return m_ParticleLifeSplineY;
	}

	PDE_ATTRIBUTE_SETTER(ParameterFloat3, ParticleLifeSplineY, tempc_ptr(Core::PdeSplineF32))
	{
		m_ParticleLifeSplineY = value;
	}

	PDE_ATTRIBUTE_GETTER(ParameterFloat3, ParticleLifeSplineZ, tempc_ptr(Core::PdeSplineF32))
	{
		return m_ParticleLifeSplineZ;
	}

	PDE_ATTRIBUTE_SETTER(ParameterFloat3, ParticleLifeSplineZ, tempc_ptr(Core::PdeSplineF32))
	{
		m_ParticleLifeSplineZ = value;
	}

	void ParameterFloat3::SaveData(Stream& stream)
	{
		stream.Write(&m_Constant, sizeof(Vector3));
		stream.Write(&m_Random, sizeof(Vector3));

		U32 count = m_EmitLifeSplineX->GetControlPointCount();
		stream.Write(&count, sizeof(U32));
		for (U32 i = 0; i < count; i++)
		{
			stream.Write(&m_EmitLifeSplineX->GetControlPoint(i), sizeof(PdeSplineF32::ControlPoint));
		}

		count = m_EmitLifeSplineY->GetControlPointCount();
		stream.Write(&count, sizeof(U32));
		for (U32 i = 0; i < count; i++)
		{
			stream.Write(&m_EmitLifeSplineY->GetControlPoint(i), sizeof(PdeSplineF32::ControlPoint));
		}

		count = m_EmitLifeSplineZ->GetControlPointCount();
		stream.Write(&count, sizeof(U32));
		for (U32 i = 0; i < count; i++)
		{
			stream.Write(&m_EmitLifeSplineZ->GetControlPoint(i), sizeof(PdeSplineF32::ControlPoint));
		}

		count = m_ParticleLifeSplineX->GetControlPointCount();
		stream.Write(&count, sizeof(U32));
		for (U32 i = 0; i < count; i++)
		{
			stream.Write(&m_ParticleLifeSplineX->GetControlPoint(i), sizeof(PdeSplineF32::ControlPoint));
		}

		count = m_ParticleLifeSplineY->GetControlPointCount();
		stream.Write(&count, sizeof(U32));
		for (U32 i = 0; i < count; i++)
		{
			stream.Write(&m_ParticleLifeSplineY->GetControlPoint(i), sizeof(PdeSplineF32::ControlPoint));
		}

		count = m_ParticleLifeSplineZ->GetControlPointCount();
		stream.Write(&count, sizeof(U32));
		for (U32 i = 0; i < count; i++)
		{
			stream.Write(&m_ParticleLifeSplineZ->GetControlPoint(i), sizeof(PdeSplineF32::ControlPoint));
		}
	}

	void ParameterFloat3::LoadData(Stream& stream)
	{
		stream.Read(&m_Constant, sizeof(Vector3));
		stream.Read(&m_Random, sizeof(Vector3));

		PdeSplineF32::ControlPoint point;
		U32 count = 0;
		stream.Read(&count, sizeof(U32));
		for (U32 i = 0; i < count; i++)
		{
			stream.Read(&point, sizeof(PdeSplineF32::ControlPoint));
			m_EmitLifeSplineX->AddControlPoint(point);
		}

		stream.Read(&count, sizeof(U32));
		for (U32 i = 0; i < count; i++)
		{
			stream.Read(&point, sizeof(PdeSplineF32::ControlPoint));
			m_EmitLifeSplineY->AddControlPoint(point);
		}

		stream.Read(&count, sizeof(U32));
		for (U32 i = 0; i < count; i++)
		{
			stream.Read(&point, sizeof(PdeSplineF32::ControlPoint));
			m_EmitLifeSplineZ->AddControlPoint(point);
		}

		stream.Read(&count, sizeof(U32));
		for (U32 i = 0; i < count; i++)
		{
			stream.Read(&point, sizeof(PdeSplineF32::ControlPoint));
			m_ParticleLifeSplineX->AddControlPoint(point);
		}

		stream.Read(&count, sizeof(U32));
		for (U32 i = 0; i < count; i++)
		{
			stream.Read(&point, sizeof(PdeSplineF32::ControlPoint));
			m_ParticleLifeSplineY->AddControlPoint(point);
		}

		stream.Read(&count, sizeof(U32));
		for (U32 i = 0; i < count; i++)
		{
			stream.Read(&point, sizeof(PdeSplineF32::ControlPoint));
			m_ParticleLifeSplineZ->AddControlPoint(point);
		}
	}


	String ParameterFloat3::SaveToStream(U32 pos)
	{
		CStrBuf<1024> str;

		CStrBuf<256> s1; 
		CStrBuf<256> s2;

		CStrBuf<256> value;

		for (U32 i = 0; i < pos; i++)
		{
			s1.contract("\t");
			s2.contract("\t");
		}
		s2.contract("\t");
		str.contract("\n");
		str.contract(s1);
		str.contract("{\n");
		str.contract(s2);
		str.contract("Constant = Vector3(");
		value.format("%g, %g, %g),\n", GetConstant().x, GetConstant().y, GetConstant().z);
		str.contract(value);

		str.contract(s2);
		str.contract("Random = Vector3(");
		value.format("%g, %g, %g),\n", GetRandom().x, GetRandom().y, GetRandom().z);
		str.contract(value);

		if (GetEmitLifeSplineX()->GetControlPointCount() > 0)
		{
			str.contract(s2);
			str.contract("EmitLifeSplineX = \n");
			str.contract(s2);
			str.contract("{\n");
			GetEmitLifeSplineX()->SaveToStream(str, s2);
			str.contract(s2);
			str.contract("},\n");
		}

		if (GetParticleLifeSplineX()->GetControlPointCount() > 0)
		{
			str.contract(s2);
			str.contract("ParticleLifeSplineX = \n");
			str.contract(s2);
			str.contract("{\n");
			GetParticleLifeSplineX()->SaveToStream(str, s2);
			str.contract(s2);
			str.contract("},\n");
		}

		if (GetEmitLifeSplineY()->GetControlPointCount() > 0)
		{
			str.contract(s2);
			str.contract("EmitLifeSplineY = \n");
			str.contract(s2);
			str.contract("{\n");
			GetEmitLifeSplineY()->SaveToStream(str, s2);
			str.contract(s2);
			str.contract("},\n");
		}

		if (GetParticleLifeSplineY()->GetControlPointCount() > 0)
		{
			str.contract(s2);
			str.contract("ParticleLifeSplineY = \n");
			str.contract(s2);
			str.contract("{\n");
			GetParticleLifeSplineY()->SaveToStream(str, s2);
			str.contract(s2);
			str.contract("},\n");
		}

		if (GetEmitLifeSplineZ()->GetControlPointCount() > 0)
		{
			str.contract(s2);
			str.contract("EmitLifeSplineZ = \n");
			str.contract(s2);
			str.contract("{\n");
			GetEmitLifeSplineZ()->SaveToStream(str, s2);
			str.contract(s2);
			str.contract("},\n");
		}

		if (GetParticleLifeSplineZ()->GetControlPointCount() > 0)
		{
			str.contract(s2);
			str.contract("ParticleLifeSplineZ = \n");
			str.contract(s2);
			str.contract("{\n");
			GetParticleLifeSplineZ()->SaveToStream(str, s2);
			str.contract(s2);
			str.contract("},\n");
		}


		str.contract(s1);
		str.contract("},\n");

		String a(str);
		return a;
	}

}

DEFINE_PDE_TYPE_CLASS(Client::ParameterColor3)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_DEFAULT_CONSTRUCTOR();

		ADD_PDE_SUPER(Client::Parameter);
		ADD_PDE_PROPERTY_RW(Constant);
		ADD_PDE_PROPERTY_RW(Random);
		ADD_PDE_PROPERTY_RW(EmitLifeSpline);
		ADD_PDE_PROPERTY_RW(ParticleLifeSpline);
		ADD_PDE_METHOD(SaveToStream);
	}
};
REGISTER_PDE_TYPE(Client::ParameterColor3);

namespace Client
{
	ParameterColor3::ParameterColor3()
		: m_Constant(Color3::kBlack)
		, m_Random(0)
	{
		m_EmitLifeSpline = ptr_new PdeSplineF32;
		m_ParticleLifeSpline = ptr_new PdeSplineF32;
	}

	ParameterColor3::~ParameterColor3()
	{
		m_EmitLifeSpline = NullPtr;
		m_ParticleLifeSpline = NullPtr;
	}

	Color3 ParameterColor3::GetInitial()
	{
		return m_Constant * Random(1.f - m_Random, 1.f);
	}

	Color3 ParameterColor3::GetEmitLifeValue(Color3 v, F32 t)
	{
		if (m_EmitLifeSpline->GetControlPointCount())
		{
			F32 SplineValue = Clamp(m_EmitLifeSpline->GetSplineValue(t), 0.f, 1.f);
			return SplineValue * v;
		}
		else
			return v;
	}

	Color3 ParameterColor3::GetParticleLifeValue(Color3 v, F32 t)
	{
		if (m_ParticleLifeSpline->GetControlPointCount())
		{
			F32 SplineValue = Clamp(m_ParticleLifeSpline->GetSplineValue(t), 0.f, 1.f);
			return SplineValue * v;
		}
		else
			return v;
	}

	PDE_ATTRIBUTE_GETTER(ParameterColor3, Constant, Color3&)
	{
		return m_Constant;
	}

	PDE_ATTRIBUTE_SETTER(ParameterColor3, Constant, Color3&)
	{
		m_Constant = value;
	}

	PDE_ATTRIBUTE_GETTER(ParameterColor3, Random, F32)
	{
		return m_Random;
	}

	PDE_ATTRIBUTE_SETTER(ParameterColor3, Random, F32)
	{
		m_Random = value;
	}

	PDE_ATTRIBUTE_GETTER(ParameterColor3, EmitLifeSpline, tempc_ptr(Core::PdeSplineF32))
	{
		return m_EmitLifeSpline;
	}

	PDE_ATTRIBUTE_SETTER(ParameterColor3, EmitLifeSpline, tempc_ptr(Core::PdeSplineF32))
	{
		m_EmitLifeSpline = value;
	}

	PDE_ATTRIBUTE_GETTER(ParameterColor3, ParticleLifeSpline, tempc_ptr(Core::PdeSplineF32))
	{
		return m_ParticleLifeSpline;
	}

	PDE_ATTRIBUTE_SETTER(ParameterColor3, ParticleLifeSpline, tempc_ptr(Core::PdeSplineF32))
	{
		m_ParticleLifeSpline = value;
	}

	void ParameterColor3::SaveData(Stream& stream)
	{
		stream.Write(&m_Constant, sizeof(Color3));
		stream.Write(&m_Random, sizeof(F32));

		U32 count = m_EmitLifeSpline->GetControlPointCount();
		stream.Write(&count, sizeof(U32));
		for (U32 i = 0; i < count; i++)
		{
			stream.Write(&m_EmitLifeSpline->GetControlPoint(i), sizeof(PdeSplineF32::ControlPoint));
		}

		count = m_ParticleLifeSpline->GetControlPointCount();
		stream.Write(&count, sizeof(U32));
		for (U32 i = 0; i < count; i++)
		{
			stream.Write(&m_ParticleLifeSpline->GetControlPoint(i), sizeof(PdeSplineF32::ControlPoint));
		}
	}

	void ParameterColor3::LoadData(Stream& stream)
	{
		stream.Read(&m_Constant, sizeof(Color3));
		stream.Read(&m_Random, sizeof(F32));

		PdeSplineF32::ControlPoint point;

		U32 count;
		stream.Read(&count, sizeof(U32));
		for (U32 i = 0; i < count; i++)
		{
			stream.Read(&point, sizeof(PdeSplineF32::ControlPoint));
			m_EmitLifeSpline->AddControlPoint(point);
		}

		stream.Read(&count, sizeof(U32));
		for (U32 i = 0; i < count; i++)
		{
			stream.Read(&point, sizeof(PdeSplineF32::ControlPoint));
			m_ParticleLifeSpline->AddControlPoint(point);
		}
	}

	String ParameterColor3::SaveToStream(U32 pos)
	{
		CStrBuf<1024> str;

		CStrBuf<256> s1; 
		CStrBuf<256> s2;

		CStrBuf<256> value;

		for (U32 i = 0; i < pos; i++)
		{
			s1.contract("\t");
			s2.contract("\t");
		}
		s2.contract("\t");

		str.contract("\n");
		str.contract(s1);
		str.contract("{\n");
		str.contract(s2);
		str.contract("Constant = Color3(");
		value.format("%g, %g, %g),\n", GetConstant().x, GetConstant().y, GetConstant().z);
		str.contract(value);

		str.contract(s2);
		str.contract("Random = ");
		value.format("%g,\n", GetRandom());
		str.contract(value);

		if (GetEmitLifeSpline()->GetControlPointCount() > 0)
		{
			str.contract(s2);
			str.contract("EmitLifeSpline = \n");
			str.contract(s2);
			str.contract("{\n");
			GetEmitLifeSpline()->SaveToStream(str, s2);
			str.contract(s2);
			str.contract("},\n");
		}

		if (GetParticleLifeSpline()->GetControlPointCount() > 0)
		{
			str.contract(s2);
			str.contract("ParticleLifeSpline = \n");
			str.contract(s2);
			str.contract("{\n");
			GetParticleLifeSpline()->SaveToStream(str, s2);
			str.contract(s2);
			str.contract("},\n");
		}

		str.contract(s1);
		str.contract("},\n");

		String a(str);
		return a;
	}
}