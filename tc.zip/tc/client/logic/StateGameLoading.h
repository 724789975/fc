namespace Client
{
	class StateGameLoading : public GameState
	{
	public:
		enum ConnectingStep
		{
			kInitialize,
			kLoading,
			kLoadError,
			kFinished,
		};
	public:
		DECLARE_PDE_EVENT(EventProgressMove,	Core::EventArgs);
		DECLARE_PDE_EVENT(EventLeave,			Core::EventArgs);
		DECLARE_PDE_EVENT(EventEnter,			Core::EventArgs);

	public:
		INLINE_PDE_ATTRIBUTE_R(Progress,		float);

	public:
		// constructor.
		StateGameLoading();

		// on enter
		void OnEnter();

		// leave state
		void OnLeave();

		// on update
		void OnUpdate(float frameTime);

		// on input
		void OnInput(InputEventArgs & e);

		// on disconnected
		void OnDisconnect();

		// render
		void OnRender();

	public:
		ConnectingStep step;

		Core::String	map_name;
		Client::RoomOption::GameType	gameMode;
		uint			player_id;

	private:
		float			m_Progress;
		int				m_ResourceCount;
		float			m_time;		//Loading����ʱ�ӳ�2��

		sharedc_ptr(StateMainGame) main_game;
	};
}