#include "pch.h"

using namespace Core;
using namespace Client;
using namespace Gui;

#define NOINPUT_LIMITTIME 300
#define SELECTPERSONMAXNUM 5

DEFINE_PDE_TYPE_CLASS(EventShowPerson)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(EventArgs);

		ADD_PDE_FIELD(person_name);
	}
};

DEFINE_PDE_TYPE_CLASS(EventCanKickNum)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(EventArgs);

		ADD_PDE_FIELD(count);
	}
};

DEFINE_PDE_TYPE_CLASS(EventSpecial)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(EventArgs);

		ADD_PDE_FIELD(count);
	}
};

DEFINE_PDE_TYPE_CLASS(EventAddSelectPerson)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(EventArgs);

		ADD_PDE_FIELD(key_name);
		ADD_PDE_FIELD(text_name);
	}
};

DEFINE_PDE_TYPE_CLASS(EventKickError)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(EventArgs);

		ADD_PDE_FIELD(error_id);
	}
};

 DEFINE_PDE_TYPE_CLASS(StateMainGame)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(GameState);

		ADD_PDE_PROPERTY_RW(EditorOn);
		ADD_PDE_PROPERTY_RW(EscHasFocus);
		ADD_PDE_PROPERTY_RW(SelectHasFocus);
		ADD_PDE_PROPERTY_RW(SelectName);
		ADD_PDE_PROPERTY_RW(TeamIndex);
		ADD_PDE_PROPERTY_RW(KickReason);
		ADD_PDE_PROPERTY_RW(KickName);
		ADD_PDE_PROPERTY_RW(IsCanCancel);
		ADD_PDE_PROPERTY_RW(IsWatch);
		ADD_PDE_PROPERTY_RW(IsReplay);
		ADD_PDE_PROPERTY_RW(IsEditMode);
		

		ADD_PDE_METHOD(Quit);
		ADD_PDE_METHOD(SetCharacterFromID);
		ADD_PDE_METHOD(GetTowerTypeCount);
		ADD_PDE_METHOD(GetDummyObjectCount);
		ADD_PDE_METHOD(GetMaxWallCount);
		ADD_PDE_METHOD(GetMaxGuardCount);
		ADD_PDE_METHOD(GetDummyObjectCountBySubType);
		ADD_PDE_METHOD(DestroyAllDummyObject);
		ADD_PDE_METHOD(SetActiveTower);
		ADD_PDE_METHOD(GetTowerType);
		ADD_PDE_METHOD(ShowKickPerson);
		ADD_PDE_METHOD(KickPerson);
		ADD_PDE_METHOD(SaveMap);

		ADD_PDE_METHOD(HttpXLInfo);
		ADD_PDE_METHOD(HttpXLReport);
#if DEBUG_CMD
		ADD_PDE_METHOD(SetDebugMode);
		ADD_PDE_METHOD(DebugCmd);
		ADD_PDE_METHOD(DisableStaticCollision);
		ADD_PDE_METHOD(EnableNoclip);
		ADD_PDE_METHOD(EnableWalk);
		ADD_PDE_METHOD(SetNoclipSpeed);
		ADD_PDE_METHOD(FocusHurtRate);
		ADD_PDE_METHOD(SetFireTime);
		ADD_PDE_METHOD(SetAmmoFlySpeed);
		ADD_PDE_METHOD(SetAmmoFlyTime);
		ADD_PDE_METHOD(SetPjtAmmoCntrol);
		ADD_PDE_METHOD(SetDrawAllVisible);
		ADD_PDE_METHOD(ShowCharacterEffect);
		ADD_PDE_METHOD(BarbetteView)
		ADD_PDE_METHOD(Teleport)
		ADD_PDE_METHOD(SetMessageClientFlag);
#endif

		ADD_PDE_EVENT(EventLeave);
		ADD_PDE_EVENT(EventChooseCharacter);
		ADD_PDE_EVENT(EventCloseCharacter);
		ADD_PDE_EVENT(EventAddSelect);

		ADD_PDE_EVENT(EventAddSelectKickPerson);
		ADD_PDE_EVENT(EventAddSelectReportPerson);
		ADD_PDE_EVENT(EventCanKick);
		ADD_PDE_EVENT(EventClearSelectKickPerson);
		ADD_PDE_EVENT(KickPersonError);
		ADD_PDE_EVENT(EventSavePhoto);
		ADD_PDE_EVENT(EventCantSelectPerson);
	}
};

 DEFINE_PDE_TYPE_CLASS(GunTowerTypeInfo)
 {
	 void OnRegister(by_ptr(PdeTypeInfo) type)
	 {
		 ADD_PDE_FIELD(DummyObjectType);
		 ADD_PDE_FIELD(MaxCount);
		 ADD_PDE_FIELD(Width);
		 ADD_PDE_FIELD(Height);
		 ADD_PDE_FIELD(ResKey);
	 }
 };

REGISTER_PDE_TYPE(StateMainGame);
REGISTER_PDE_TYPE(EventShowPerson);
REGISTER_PDE_TYPE(EventCanKickNum);
REGISTER_PDE_TYPE(EventSpecial);
REGISTER_PDE_TYPE(EventAddSelectPerson);
REGISTER_PDE_TYPE(EventKickError);
REGISTER_PDE_TYPE(GunTowerTypeInfo);
//----------------------------------------------------------------------------------
// main game state
//----------------------------------------------------------------------------------
namespace Client
{
	// constructor.
	StateMainGame::StateMainGame()
		: m_EscHasFocus(false)
		, m_SelectHasFocus(false)
		, m_TeamIndex(-1)
		, m_CharacterIndex(-1)
		, m_KickReason(1)
		, m_IsNeedReadyforGame(true)
		, noinput_limittime(0)
		, m_IsCanCancel(true)
		, m_IsWatch(false)
		, m_IsReplay(false)
		, m_IsEditMode(false)
		, quit_game(false)
	{
		SetEditorOn(false);

#if DEBUG_CMD
		m_DebugMode = false;
		m_DebugCharacterUid = 0;
#endif
	}

	// on create
	void StateMainGame::OnCreate()
	{
		Object::OnCreate();
		ui =  ptr_new InGameUINew;
		ui->SetInputFocus(false);
	}

	// enter state
	void StateMainGame::OnEnter()
	{
		if (gRender)
			gRender->SetGameState(D3DRender::kGameEnter);

		gGame->camera->wide_screen_mode = true;
		gGame->camera->fov = NORMAL_FOV;
		gGame->camera->target_fov = NORMAL_FOV;
		gGame->camera->control_mode = Camera::kFixed;

#ifndef MASTER
		gGame->console->SetParent(NullPtr);
#endif
		m_IsNeedReadyforGame = true;
		m_TeamIndex = -1;
		gGame->guiSys->SetFocused(true);

		gGame->scores->Clear();

		gLevel->OnGameStart();
		gLevel->sensitivity_timer = 0;

		PhysxSystem::PhysxEnable(true);

		if(gGame->channel_connection->GetGameState() == ChannelConnection::kLoading &&
			gGame->channel_connection->GetState() == ChannelConnection::kInReplay)
		{
			gGame->channel_connection->SetGameState(ChannelConnection::kWaiting);
		}

		m_CharacterIndex = -1;
		if (gLevel->scenesound_event)
			gLevel->scenesound_event->start();

		if (gLevel->scene3dsound_event)
		{
			FMOD_VECTOR pos = (const FMOD_VECTOR &)gLevel->sound3d_pos;
			FMOD_VECTOR vel = {0, 0, 0};
			gLevel->scene3dsound_event->set3DAttributes(&pos, &vel);
			gLevel->scene3dsound_event->start();
		}
		if(gLevel->game_type == RoomOption::kBombMode)
		{
			gLevel->bomb_explode_particle = ptr_new ParticleSystem("ammo_c4_explosion", false);
			gLevel->bomb_explode_particle->SetEnable(false);
		}
		if (gLevel->game_type == RoomOption::kNovice)
		{
			m_IsCanCancel = false;
		}

		if (gLevel->game_type == RoomOption::kNovice)
		{
			if (!gLevel->novice_particle)
			{
				Core::String name = Core::String::Format("scene_index_rb01");
				gLevel->novice_particle = ptr_new ParticleSystem(name, false);
				gLevel->novice_particle->SetEnable(false);
				gLevel->novice_particle->SetPosition(Vector3(0,0,0));
				if (gLevel->novice_particle && !gLevel->novice_particle->m_LinkNode.GetList())
					gLevel->particle_manager->AddParticle(gLevel->novice_particle);
			}
		}
		else if (gLevel->novice_particle)
		{
			gLevel->novice_particle = NullPtr;
		}

		gLevel->tmpplayer = NullPtr;
		gLevel->saveplayer = NullPtr;
		gLevel->targetenemy_time = 0.f;

		ui->InitPersonUI(gLevel->GetPlayer());
		const Core::Array<sharedc_ptr(Character)> & characters = gLevel->GetCharacters();
		for (U32 i = 0; i < characters.Size(); i++)
		{
			ui->InitPersonUI(characters[i]);
		}
		select_from_string.Clear();

		noinput_limittime = NOINPUT_LIMITTIME;
		Lua::LuaState::FromThread()->DoFile("/scripts/state_game_main.lua");
		
		if (gLevel->GetPlayer()->GetTeam() > 1)
			m_IsWatch = true;
		else
			m_IsWatch = false;

		if(gGame->channel_connection->GetState() == ChannelConnection::kInReplay)
		{
			m_IsReplay = true;
		}
		else
		{
			m_IsReplay = false;
		}

		if(gLevel->game_type == RoomOption::kEditMode)
		{
			m_IsEditMode = true;
		}
		else
		{
			m_IsEditMode = false;
		}

		ui->InitEditMode();
		ui->InitTDMode();
	}

	// leave state
	void StateMainGame::OnLeave()
	{
		if (gLevel->GetPlayer())
			gLevel->GetPlayer()->GetFirstPerson().StopAudioStep();

		if (gRender)
			gRender->SetGameState(D3DRender::kGameLeave);

		PhysxSystem::PhysxEnable(false);

		EventLeave.Fire(ptr_static_cast<StateMainGame>(this), EventArgs());

		if (gLevel->scenesound_event)
		{
			gLevel->scenesound_event->stop();
			gLevel->scenesound_event = NULL;
		}
		if (gLevel->scene3dsound_event)
		{
			gLevel->scene3dsound_event->stop();
			gLevel->scene3dsound_event = NULL;
		}
		if (gLevel->holdpoint_sound)
			gLevel->holdpoint_sound->stop();
		if (gLevel->vehicle_sound[0])
			gLevel->vehicle_sound[0]->stop();
		if (gLevel->vehicle_sound[1])
			gLevel->vehicle_sound[1]->stop();
		if (gLevel->spiriteball_fly_sound)
			gLevel->spiriteball_fly_sound->stop();
		if (gLevel->audio_bomb_Planting_Defusing)
		{
			gLevel->audio_bomb_Planting_Defusing->stop();
		}
		if (gLevel->audio_background)
		{
			gLevel->audio_background->stop(true);
			gLevel->audio_background = NULL;
		}
		if ( gLevel->audio_Survival_background )
		{
			gLevel->audio_Survival_background->stop(true);
			gLevel->audio_Survival_background = NULL;
		}
		if ( gLevel->audio_Survival1_background )
		{
			gLevel->audio_Survival1_background->stop(true);
			gLevel->audio_Survival1_background = NULL;
		}
		if (gLevel->audio_bossmode2_background)
		{
			gLevel->audio_bossmode2_background->stop(true);
			gLevel->audio_bossmode2_background = NULL;
		}
		if (gLevel->audio_killing_background)
		{
			gLevel->audio_killing_background->stop(true);
			gLevel->audio_killing_background = NULL;
		}
		if (gLevel->audio_chrismas_background)
		{
			gLevel->audio_chrismas_background->stop(true);
			gLevel->audio_chrismas_background = NULL;
		}
		if (gLevel->zombie_state_two_muisc)
		{
			gLevel->zombie_state_two_muisc->stop();
			gLevel->zombie_state_two_muisc = NULL;
		}
		for (int i = 0;i < 5;i++)
		{
			if (gLevel->audio_bomb_3d_Plant_Timer[i])
			{
				gLevel->audio_bomb_3d_Plant_Timer[i]->stop();
			}
		}
		tempc_ptr(Character) player = gLevel->GetPlayer();
		if (player)
		{
			if (player->zombie_2D_breath)
			{
				player->zombie_2D_breath->stop();
			}
			if (player->zombie_3D_breath)
			{
				player->zombie_3D_breath->stop();
			}
			if (player->invisible_zombie_3D_breath)
			{
				player->invisible_zombie_3D_breath->stop();
			}
			if (player->invisible_zombie_2D_breath)
			{
				player->invisible_zombie_2D_breath->stop();
			}
		}
		for (int i = 0;i < gLevel->GetCharacters().GetCount();i++)
		{
			tempc_ptr(Character) c = gLevel->GetCharacters().GetAt(i);
			if (c->zombie_2D_breath)
			{
				c->zombie_2D_breath->stop();
			}
			if (c->zombie_3D_breath)
			{
				c->zombie_3D_breath->stop();
			}
			if (c->invisible_zombie_3D_breath)
			{
				c->invisible_zombie_3D_breath->stop();
			}
			if (c->invisible_zombie_2D_breath)
			{
				c->invisible_zombie_2D_breath->stop();
			}
		}
		tempc_ptr(Character) viewer = gLevel->GetViewer();
		if (viewer && viewer->GetWeapon())
		{
			tempc_ptr(MiniMachineGun) gun = ptr_dynamic_cast<MiniMachineGun>(viewer->GetWeapon());
			if (gun && gun->mini_gun_audio_spin_fire)
				gun->mini_gun_audio_spin_fire->stop();
			if (gun && gun->mini_gun_audio_fire)
				gun->mini_gun_audio_fire->stop();
			if (gun && gun->mini_gun_audio_spin_fire_3d)
				gun->mini_gun_audio_spin_fire_3d->stop();

			tempc_ptr(CureGun) curegun = ptr_dynamic_cast<CureGun>(viewer->GetWeapon());
			if (curegun && curegun->my_audio_event)
				curegun->my_audio_event->stop();
		}

		Core::Array<sharedc_ptr(Character)> array = gLevel->GetCharacters();
		for(int i = 0; i < (int)array.Size();++i)
		{
			tempc_ptr(Character) pp = array[i];
			if (pp && pp->GetWeapon())
			{
				tempc_ptr(MiniMachineGun) gun = ptr_dynamic_cast<MiniMachineGun>(pp->GetWeapon());
				if (gun && gun->mini_gun_audio_spin_fire)
					gun->mini_gun_audio_spin_fire->stop();
				if (gun && gun->mini_gun_audio_fire)
					gun->mini_gun_audio_fire->stop();
				if (gun && gun->mini_gun_audio_spin_fire_3d)
					gun->mini_gun_audio_spin_fire_3d->stop();

				tempc_ptr(CureGun) curegun = ptr_dynamic_cast<CureGun>(pp->GetWeapon());
				if (curegun && curegun->my_audio_event)
					curegun->my_audio_event->stop();
			}
		}
		
		if(gLevel->bomb_explode_particle)
		{
			gLevel->bomb_explode_particle = NullPtr;
		}
		gLevel->boss_starttimeer = -1;
		gLevel->tmpplayer = NullPtr;
		gLevel->saveplayer = NullPtr;
		gLevel->targetenemy_time = 0.f;
		gLevel->kick_select_open = false;
		gLevel->kick_select_id = 0;
		gLevel->kick_wait_time = 0.f;
		gLevel->hold_points.Clear();
		ui->zd_red_showtime = 1.f;
		ui->zd_blue_showtime = 1.f;
		ui->zd_time = 0;
		gLevel->team_timer[0] = 0.f;
		gLevel->team_timer[1] = 0.f;
		gLevel->hold_point_fPersert_red = 0.f;
		gLevel->hold_point_fPersert_blue = 0.f;
		gGame->scores->Clear();

		noinput_limittime = -1;
		ui->CloseChat();
		select_from_string.Clear();

		FMOD_REVERB_PROPERTIES reverb = FMOD_PRESET_OFF;
		FmodSystem::SetSceneReverb(&reverb); 
	}

	void StateMainGame::OnInput(InputEventArgs & e)
	{
#ifndef MASTER
		if (gGame->console->GetParent())
			return;
#endif

		if(!IsUIFocused() && ui)
			ui->OnInput(e);

		if (e.Handled)
			return;

		bool bPassOn = false;
		if (e.IsKeyEvent())
		{
			if (e.Type == InputEventArgs::kKeyDown && e.Code == KC_ESCAPE)
			{
				if ((gLevel->game_type == RoomOption::kNovice) && m_SelectHasFocus)
				{
					e.Handled = true;
					return;
				}
				else
					bPassOn = true;
			}
			if (gGame->config->IsActionDown(kActionUIPack) && gLevel->game_type != RoomOption::kNovice && CanSelectPerson())
			{
				bPassOn = true;
			}
			if (gGame->config->IsActionDown(kActionUIWeaponPack) && gLevel->game_type == RoomOption::kEditMode)
			{
				bPassOn = true;
			}
		}
		
		if(e.IsKeyEvent() || (e.IsMouseEvent() /*&& e.Type !=  InputEventArgs::kMouseMove && e.Type !=  InputEventArgs::kMouseEnter && e.Type !=  InputEventArgs::kMouseLeave*/))
		{
			noinput_limittime = NOINPUT_LIMITTIME;
		}
		if (!IsUIFocused() && !bPassOn)
			e.Handled = true;
	}

	bool StateMainGame::CanSelectPerson()
	{
		if (gLevel->room_option.character_id > 0)
			return false;
		if (gLevel->GetPlayer()->GetTeam() >= 2)
			return false;
		if (gGame->channel_connection->GetState() == ChannelConnection::kInReplay)
			return false;
		return true;
	}

	// update
	void StateMainGame::OnUpdate(float frameTime)
	{
#ifndef MASTER
		if(gGame->config->IsActionPressed(kAction_Key5))
		{
			if(gGame->channel_connection)
			{
				gGame->channel_connection->SetClientMessage(true);
			}
		}
#endif

		//if (!gGame->screen->GetActive() && !m_EscHasFocus)
		//{
		//	gGame->guiSys->EventEscPressed.Fire(gGame->guiSys, InputEventArgs());
		//}

		OnDebugUpdate(frameTime);

		gLevel->Update(frameTime);
		
		if(gGame && gGame->lobby_connection && gGame->lobby_connection)
		{
			uint l = gGame->lobby_connection->expired_weapon_name.Size();
			for (uint i = 0; i < l; i++)
			{
				Core::String weapon_name = gGame->lobby_connection->expired_weapon_name.GetAt(i);
				CStrBuf<256> str;

				str.format(gLang->GetTextW(L"����[%s]��ʧЧ!!!"), weapon_name);

				gGame->global->Translate(str);
				ui->AddTipText(str);
			}
			gGame->lobby_connection->expired_weapon_name.Clear();
		}


		// audio debug
		if (0)
		{
			FMOD::System* fmod_raw = FmodSystem::GetFmodRaw();
			if (fmod_raw)
			{
				float dsp, stream, geom, update, total;
				int chansplaying;

				fmod_raw->getCPUUsage(&dsp, &stream, &geom, &update, &total);
				fmod_raw->getChannelsPlaying(&chansplaying);

				LogSystem.WriteLinef("chans %d : cpu : dsp = %.02f stream = %.02f geometry = %.02f update = %.02f total = %.02f\n", chansplaying, dsp, stream, geom, update, total);
			}
		}

		if (m_TeamIndex == -1 && CanSelectPerson())
		{
			m_TeamIndex = (int)gLevel->GetPlayer()->GetTeam();

			tempc_ptr(Character) player = gLevel->GetPlayer();
			if (player && player->basecharacter_info)
			{
				select_from_string.Clear();
				tempc_ptr(BaseCharacterInfo) base_info = player->basecharacter_info;
				int num = SELECTPERSONMAXNUM - base_info->slot_count;
				int can_select_num = 0;
				for (uint i = 0; i < base_info->career_count; i++)
				{
					CharacterInfoSimple & career_info = base_info->career_list[i];
					if (career_info.can_select)
					{
						can_select_num++;
						select_from_string.Set(career_info.res_key, career_info.career_id);
						EventAddSelect.Fire(ptr_static_cast<StateMainGame>(this), EventAddSelectPerson(career_info.res_key, career_info.career_name));
					}
				}
				for (int i = 0; i < (int)(base_info->slot_count - can_select_num); i++)
				{
					EventAddSelect.Fire(ptr_static_cast<StateMainGame>(this), EventAddSelectPerson("slot", ""));
				}
				for (int i = 0; i < num; i++)
				{
					EventAddSelect.Fire(ptr_static_cast<StateMainGame>(this), EventAddSelectPerson("lock", gLang->GetTextW(L"δ����")));
				}
			}

			EventChooseCharacter.Fire(ptr_static_cast<StateMainGame>(this), EventArgs());
			ui->SetInputFocus(false);
		}
	
		// audio listener set
		tempc_ptr(Character) viewer = gLevel->GetViewer();
		if (viewer)
		{
			FMOD_VECTOR listener_pos = (const FMOD_VECTOR &)viewer->GetPosition();
			Vector3 listener_front = Vector3(0, 0, -1) * viewer->GetRotation();
			Vector3 listener_up= Vector3(0, 1, 0) * viewer->GetRotation();

			FMOD::EventSystem* event_system = FmodSystem::GetEventSystem();
			if (event_system)
				event_system->set3DListenerAttributes(0, &listener_pos, NULL, (FMOD_VECTOR*)&listener_front, (FMOD_VECTOR*)&listener_up);
		}
	
		// update scores
		gGame->scores->Update(frameTime);

		// render update
		if (gRender)
			gRender->Update(frameTime);

		tempc_ptr(Character) player = gLevel->GetPlayer();

		if (gLevel->start_chooseperson_time > 0)
			gLevel->start_chooseperson_time -= frameTime;
		else if (m_IsNeedReadyforGame && player)
		{
			m_CharacterIndex = 0;
			int num = player->basecharacter_info->career_list.Size();
			num = rand() % num;
			m_SelectName = player->basecharacter_info->career_list[num].res_key;

			for (int i = 0; i < 3; ++i)
			{
				LogSystem.WriteLinef("%s",player->basecharacter_info->career_list[num].career_name);
				if (player->basecharacter_info->career_list[num].career_name == gLang->GetTextW(L"�ѻ���") || player->basecharacter_info->career_list[num].career_name == gLang->GetTextW(L"ҽ�Ʊ�"))
				{
					num = player->basecharacter_info->career_list.Size();
					num = rand() % num;
					m_SelectName = player->basecharacter_info->career_list[num].res_key;
				}
				else
					break;
			}

			SetCharacterFromID();
			EventCloseCharacter.Fire(ptr_static_cast<StateMainGame>(this), EventArgs());
		}
		
		if (m_SelectHasFocus)
		{
			int temp_value = -1;
			if(gGame->config->IsActionDown(kAction_Key1))
				temp_value = 0;
			if(gGame->config->IsActionDown(kAction_Key2))
				temp_value = 1;
			if(gGame->config->IsActionDown(kAction_Key3))
				temp_value = 2;
			if(gGame->config->IsActionDown(kAction_Key4))
				temp_value = 3;
			if(gGame->config->IsActionDown(kAction_Key5))
				temp_value = 4;

			if ((int)player->basecharacter_info->career_list.Size() < temp_value + 1)
				temp_value = -1;

			if(temp_value != -1)
			{
				m_CharacterIndex = 0;
				int num = player->basecharacter_info->career_list.Size();
				num = temp_value;
				m_SelectName = player->basecharacter_info->career_list[num].res_key;
				SetCharacterFromID();
				EventCloseCharacter.Fire(ptr_static_cast<StateMainGame>(this), EventArgs());
			}
		}

		if(player && player->IsDied())
		{
			noinput_limittime = NOINPUT_LIMITTIME;
		}
		//inGameUI update
		ui->Update(frameTime);
		
		//update noinput limit time
		if(noinput_limittime > 0)
		{
			noinput_limittime -= frameTime;
			if(noinput_limittime <= 0)
			{
				if(gGame->channel_connection)
				{
					gGame->channel_connection->LeaveGame(ChannelConnection::kLeaveGameReasonIdle);
				}
			}
		}

		if(quit_game)
		{
			if(gGame->channel_connection)
			{
				gGame->channel_connection->LeaveGame(ChannelConnection::kLeaveGameReasonNone);
				gGame->channel_connection->Disconnect();
				gGame->need_leave_roomlist = true;
			}
			quit_game = false;
		}
	}

	void StateMainGame::OnTimeStepUpdate(float frameTime)
	{
		Input * input = gGame->input;
		Screen * screen = gGame->screen;
		

		gLevel->TimeStepUpdate(frameTime);

		if (/*gGame->screen->GetActive() && */!IsUIFocused() && !ui->bFoused)
		{
			ui->show_scores = gGame->config->IsActionDown(kActionUIGameInfo);
			ui->show_map = gGame->config->IsActionDown(kActionUIMap);

			if (gGame->channel_connection && gGame->channel_connection->GetGameState() == ChannelConnection::kGameEnd)
				ui->show_scores = true;

			gLevel->player_manager->UpdateControl(gGame->input, frameTime);
		}

		// game end
		if (gGame->channel_connection && gGame->channel_connection->GetGameState() == ChannelConnection::kGameEnd)
		{
			ui->show_game_scores = true;
			ui->win_team = gGame->channel_connection->game_win_team;
		}

		if (!IsUIFocused() && !GetEditorOn())
		{
			// screen is active
			if (gGame->screen->GetActive() && gGame->screen->IsFocus() && gGame->channel_connection && gGame->channel_connection->GetState() != ChannelConnection::kInReplay)
			{
				// lock cursor
				input->SetCursorPosition(screen->ClientToScreen(screen->GetSize() / 2));
				screen->SetCursorShape(Screen::kCursorNull);
			}
			else
			{
				screen->SetCursorShape(Screen::kCursorArrow);
			}
		}

		if(gGame->lobby_connection)
		{
			gGame->lobby_connection->UpdateCharacterTimer(frameTime);
		}
	}

	void StateMainGame::OnDebugUpdate(float frameTime)
	{
#if DEBUG_CMD
		if (m_DebugMode)
		{
			if (gGame && gLevel)
			{
				tempc_ptr(Character) c = gLevel->GetCharacter(m_DebugCharacterUid);
				if (c)
				{
					String string;
					gGame->ClearReportError();

					string = String::Format("Character Name : %s", c->GetName());
					gGame->ReportError(string);

					string = String::Format("-----skill_array.size() : %d-----", c->skill_array.Size());
					gGame->ReportError(string);
					for (U32 i = 0; i < c->skill_array.Size(); i++)
					{
						string = c->skill_array[i].ToString();
						gGame->ReportError(string);
					}

					string = String::Format("-----natural_effect_array.size() : %d-----", c->natural_effect_array.Size());
					gGame->ReportError(string);
					for (U32 i = 0; i < c->natural_effect_array.Size(); i++)
					{
						string = c->natural_effect_array[i].ToString();
						gGame->ReportError(string);
					}

					string = String::Format("-----acquired_effect_array.size() : %d-----", c->acquired_effect_array.Size());
					gGame->ReportError(string);
					for (U32 i = 0; i < c->acquired_effect_array.Size(); i++)
					{
						string = c->acquired_effect_array[i].ToString();
						gGame->ReportError(string);
					}
				}
			}
		}
#endif
	}

	// render
	void StateMainGame::OnRender()
	{
		PROFILE("StateMainGame::OnRender");

		// level on render
		gLevel->OnRender(Task::GetFrameTime());

		// draw scene.
		if (!gRender)
			return;

		gRender->Draw();

		ui->DrawSmallMap(gRender->ui_render);

		if (gRender->ui_render->BeginDraw(gGame->dx9->render_target, gGame->dx9->depth_stencil))
		{
			ui->Draw(gRender->ui_render);
			gRender->ui_render->EndDraw();
		}
	}

	// disconnected
	void StateMainGame::OnDisconnect()
	{
		Console.WriteLine("Disconnected.");

		if (!gGame->lobby_connection)
		{
			gGame->machine.ChangeState(ptr_new StateLogin);
		}
		else
		{
 			gGame->lobby_connection->RestoreToStateLobby();
			tempc_ptr(StateLobby) lobbyState = ptr_static_cast<StateLobby>(gGame->machine.CurrentState());
			if (lobbyState)
			{
				lobbyState->OnLeaveChannel();
			}
			gGame->guiSys->ShowMessage(gLang->GetTextW(L"������Ϸ�����������ӳ�ʱ�Զ��Ͽ�\n�볢����������"));
		}
	}

	// quit
	void StateMainGame::Quit()
	{
		if (gGame->channel_connection)
		{
			if(gLevel && gLevel->game_type == RoomOption::kNovice)
			{
				gGame->channel_connection->LeaveGame(ChannelConnection::kLeaveGameReasonFailedNovice);
			}
			else
			{
				gGame->channel_connection->LeaveGame();
			}
		}
			
	}

	void StateMainGame::SetCharacterFromID()
	{
		//�����л�
		if(!m_IsNeedReadyforGame)
		{
			//if(gLevel->game_type == RoomOption::kTeamDeathMatch)
			//{
			//	if( gLevel->GetPlayer()->IsDied() || gLevel->round_start_wait_time  >  0.f )
			//	{
			//		gLevel->start_chooseperson_time = -2;
			//		if (gGame->channel_connection)
			//			gGame->channel_connection->Suicide();
			//		m_CharacterIndex = select_from_string.Get(m_SelectName, 0);
			//		gGame->channel_connection->RequestChangeCareerPack(m_CharacterIndex);
			//	}
			//}
			//else if(gLevel->game_type == RoomOption::kBoss)
			//{
			//	if( gLevel->GetPlayer()->IsDied())
			//	{
			//		gLevel->start_chooseperson_time = -2;
			//		if (gGame->channel_connection)
			//			gGame->channel_connection->Suicide();
			//		m_CharacterIndex = select_from_string.Get(m_SelectName, 0);
			//		gGame->channel_connection->RequestChangeCareerPack(m_CharacterIndex);				
			//	}
			//	else
			//	{
			//		bool flag = false;
			//		for (uint i = 0; i < gLevel->character_manager->GetCharacters().Size(); ++i)
			//		{
			//			tempc_ptr(Character) ch = gLevel->character_manager->GetCharacters()[i];
			//			if(ch && ch->is_boss)					
			//			{
			//				flag = true;
			//				break;
			//			}
			//		}
			//		if(!flag)
			//		{
			//			gLevel->start_chooseperson_time = -2;
			//			if (gGame->channel_connection)
			//				gGame->channel_connection->Suicide();
			//			m_CharacterIndex = select_from_string.Get(m_SelectName, 0);
			//			gGame->channel_connection->RequestChangeCareerPack(m_CharacterIndex);				
			//		}
			//	}
			//}
			//else
			{
				gLevel->start_chooseperson_time = -2;
				//if (gGame->channel_connection)
				//	gGame->channel_connection->Suicide();
				m_CharacterIndex = select_from_string.Get(m_SelectName, 0);
				gGame->channel_connection->RequestChangeCareerPack(m_CharacterIndex);
			}
		}
		else
		{
			gLevel->start_chooseperson_time = -2;
			m_IsNeedReadyforGame = false;
			m_CharacterIndex = select_from_string.Get(m_SelectName, 0);
			gGame->channel_connection->ReadyForGame(m_CharacterIndex);
		}
	}

	int StateMainGame::GetTowerTypeCount()
	{
		if (gLevel->game_type == RoomOption::kEditMode &&
			gLevel->GetPlayer()->GetWeapon()->GetWeaponType() == kWeaponTypeGunTowerBuilderPlus)
		{
			tempc_ptr(GunTowerBuilderPlus) weapon = ptr_static_cast<GunTowerBuilderPlus>(gLevel->GetPlayer()->GetWeapon());
			return weapon->GetTowerTypeCount();
		}
		return 0;
	}

	int StateMainGame::GetDummyObjectCount(int type, const Core::String& szRes)
	{
		if (gLevel->game_type == RoomOption::kEditMode)
		{
			return gLevel->GetDummyObjectCount(type, szRes);
		}
		return 0;
	}

	int StateMainGame::GetMaxWallCount()
	{
		tempc_ptr(GunTowerBuilderPlus) weapon = ptr_static_cast<GunTowerBuilderPlus>(gLevel->GetPlayer()->GetWeapon());
		if (weapon && weapon->tower_info)
		{
			return weapon->tower_info->m_iMaxWallCount;
		}
		return 0;
	}

	int StateMainGame::GetMaxGuardCount()
	{
		tempc_ptr(GunTowerBuilderPlus) weapon = ptr_static_cast<GunTowerBuilderPlus>(gLevel->GetPlayer()->GetWeapon());
		if (weapon && weapon->tower_info)
		{
			return weapon->tower_info->m_iMaxGuardCount;
		}
		return 0;
	}

	int StateMainGame::GetDummyObjectCountBySubType(int type)
	{
		if (gLevel)
		{
			return gLevel->GetDummyObjectCountBySubType(type);
		}
		return 0;
	}

	void StateMainGame::DestroyAllDummyObject()
	{
		HashSet<uint, sharedc_ptr(DummyObject)>::Enumerator it(gLevel->dummy_object_set);
		while (it.MoveNext())
		{
			tempc_ptr(DummyObject) d = it.Value();
			if(d->sub_type != 4)
			{
				gGame->channel_connection->RequestDummyObjectDestory(it.Key());
			}
		}
	}
	
	GunTowerTypeInfo StateMainGame::GetTowerType(int iIdx)
	{
		tempc_ptr(GunTowerBuilderPlus) weapon = ptr_static_cast<GunTowerBuilderPlus>(gLevel->GetPlayer()->GetWeapon());
		return weapon->GetTowerType(iIdx);
	}

	void StateMainGame::SetActiveTower(const int iIdx)
	{
		if (gLevel->game_type == RoomOption::kEditMode &&
			gLevel->GetPlayer()->GetWeapon()->GetWeaponType() == kWeaponTypeGunTowerBuilderPlus)
		{

			tempc_ptr(GunTowerBuilderPlus) weapon = ptr_static_cast<GunTowerBuilderPlus>(gLevel->GetPlayer()->GetWeapon());
			weapon->SetActiveTower(iIdx);
		}
		return ;
	}
	

	void StateMainGame::ShowKickPerson(int type)
	{
		if (gLevel->kick_count > 0)
		{
			m_KickName.Clear();
			EventClearSelectKickPerson.Fire(ptr_static_cast<StateMainGame>(this), EventArgs());
			EventCanKick.Fire(ptr_static_cast<StateMainGame>(this), EventCanKickNum(gLevel->kick_count));
			for (uint i = 0; i < gLevel->character_manager->GetCharacters().Size(); ++i)
			{
				tempc_ptr(Character) ch = gLevel->character_manager->GetCharacters()[i];
				if (ch)
				{
					if(gLevel->game_type == RoomOption::kBoss && ch->is_boss)
					{
						continue;
					}
					else if (ch->GetTeam() == gLevel->GetPlayer()->GetTeam() && type == 0)
					{
						EventAddSelectKickPerson.Fire(ptr_static_cast<StateMainGame>(this), EventShowPerson(ch->GetName()));
					}
					else if(type == 1)
					{
						EventAddSelectReportPerson.Fire(ptr_static_cast<StateMainGame>(this), EventShowPerson(ch->GetName()));
					}
				}
			}
		}
		else
		{
			KickPersonError.Fire(ptr_static_cast<StateMainGame>(this), EventKickError(2));
		}
	}

	void StateMainGame::KickPerson()
	{
		int uid = -1;
		for (uint i = 0; i < gLevel->character_manager->GetCharacters().Size(); ++i)
		{
			tempc_ptr(Character) ch = gLevel->character_manager->GetCharacters()[i];
			if (ch && ch->GetName() == m_KickName)
			{
				uid = ch->uid;
				gGame->channel_connection->KickClientRequest(uid,m_KickReason);
				break;
			}
		}
		m_KickName.Clear();
	}

	void StateMainGame::SaveMap()
	{
		gGame->channel_connection->SaveMap();
	}

	// is ui focused
	bool StateMainGame::IsUIFocused()
	{
// 		if (m_Menu->GetVisible())
// 			return true;

		if (GetEscHasFocus())
			return true;
		if (GetSelectHasFocus())
			return true;

#ifndef MASTER
		if (gGame->console->GetParent() && gGame->console->GetFocused())
			return true;
#endif

		return false;
	}

	// on chat
	void StateMainGame::OnChat(ChatMessage & msg)
	{
		ui->ReceiveMsg(msg);
	}

	// fcm
	void StateMainGame::OnFCM(int online_minutes, const char * message)
	{
		if (message)
		{
			ChatMessage msg;
			msg.channel = "/sys";
			msg.msg = String::Format("%s", message);
			//ui->ReceiveMsg(msg);
			ui->SetWarningMsg(msg);
		}
	}

	int StateMainGame::HttpXLInfo(const Core::String& bugtitle, const Core::String& bugdesc, const Core::String& qq, const Core::String& phone, int type)
	{
		if(gGame)
			return gGame->HttpXLInfo(bugtitle.Str(), bugdesc.Str(), qq.Str(), phone.Str(), type);

		return -1;
	}

	int StateMainGame::HttpXLReport(const Core::String& report_character_name, int report_type, const Core::String& report_desc)
	{
		if(gGame)
			return gGame->HttpXLReport(report_character_name.Str(),report_type,report_desc.Str());

		return -1;
	}

#if DEBUG_CMD
	//debug cmd
	void StateMainGame::SetDebugMode(bool bEnable)
	{
		m_DebugMode = bEnable;
	}

	//debug cmd
	void StateMainGame::DebugCmd(Core::String cmd)
	{
		//if (m_DebugMode && gGame->channel_connection)
		//	gGame->channel_connection->SendDebugCmd(cmd);
	}

	//debug
	void StateMainGame::DisableStaticCollision(bool bEnable)
	{
		if (m_DebugMode && gLevel)
			gLevel->disable_static_collision = bEnable;
	}

	//debug
	void StateMainGame::EnableNoclip(bool bEnable)
	{
		if (m_DebugMode && gLevel)
			gLevel->noclip_mode = bEnable;
	}

	//debug
	void StateMainGame::EnableWalk(bool bEnable)
	{
		if (m_DebugMode && gLevel)
			gLevel->enable_walk = bEnable;
	}

	//debug
	void StateMainGame::SetNoclipSpeed(float speed)
	{
		if (m_DebugMode && gLevel)
			gLevel->noclip_speed = speed;
	}

	//debug
	void StateMainGame::FocusHurtRate(bool bEnable, float rate)
	{
		if (m_DebugMode && gLevel)
		{
			gLevel->focus_hurtrate = bEnable;
			gLevel->hurtrate = rate;
		}
	}

	//debug
	void StateMainGame::SetFireTime(bool auto_fire, float fire_time)
	{
		if (m_DebugMode && gLevel)
		{
			tempc_ptr(Character) player = gLevel->GetPlayer();
			if (player)
			{
				tempc_ptr(GunBase) gun = ptr_dynamic_cast<GunBase>(player->GetWeaponById(player->weapon_id));
				if (gun && gun->gun_info)
				{
					gun->gun_info->auto_fire = auto_fire;
					gun->gun_info->fire_time = fire_time;
				}
			}
		}
	}

	//debug
	void StateMainGame::SetAmmoFlySpeed(float fly_speed)
	{
		if (m_DebugMode && gLevel)
		{
			tempc_ptr(Character) player = gLevel->GetPlayer();
			if (player)
			{
				tempc_ptr(Luncher) luncher = ptr_dynamic_cast<Luncher>(player->GetWeaponById(player->weapon_id));
				if (luncher && luncher->gun_info)
				{
					tempc_ptr(LuncherInfo) luncher_info = ptr_dynamic_cast<LuncherInfo>(luncher->gun_info);
					if (luncher_info) luncher_info->fly_speed = fly_speed;
				}
			}
		}
	}

	//debug
	void StateMainGame::SetAmmoFlyTime(float fly_time)
	{
		if (m_DebugMode && gLevel)
		{
			tempc_ptr(Character) player = gLevel->GetPlayer();
			if (player)
			{
				tempc_ptr(Luncher) luncher = ptr_dynamic_cast<Luncher>(player->GetWeaponById(player->weapon_id));
				if (luncher && luncher->gun_info)
				{
					tempc_ptr(LuncherInfo) luncher_info = ptr_dynamic_cast<LuncherInfo>(luncher->gun_info);
					if (luncher_info) luncher_info->maxalive_time = fly_time;
				}
			}
		}
	}

	//debug
	void StateMainGame::SetPjtAmmoCntrol(bool bEnable)
	{
		if (m_DebugMode && gLevel)
		{
			gLevel->pjtammo_cntrol = bEnable;
		}
	}

	//debug
	void StateMainGame::SetDrawAllVisible(bool bEnable)
	{
		if (gLevel)
			gLevel->force_draw_all_visible = bEnable;
	}

	//debug
	void StateMainGame::ShowCharacterEffect(Core::String name)
	{
		if (gLevel)
		{
			const Core::Array<sharedc_ptr(Character)> & characters = gLevel->GetCharacters();
			for (U32 i = 0; i < characters.Size(); i++)
			{
				if (characters[i]->GetName() == name)
				{
					m_DebugCharacterUid = characters[i]->uid;
					break;
				}
			}

			if (gLevel->GetPlayer() && gLevel->GetPlayer()->GetName() == name)
			{
				m_DebugCharacterUid = gLevel->GetPlayer()->uid;
			}
		}
	}

	//debug
	void StateMainGame::BarbetteView(Core::String c_name, Core::String b_name)
	{
		if (gLevel)
		{
			tempc_ptr(Character) c = gLevel->GetPveClientByName(c_name);
			if (c)
			{
				tempc_ptr(IBarbette) b = c->GetBarbetteByName(b_name);
				if (b)
					gGame->render->render_pipeline->debug_barbette = b;
				else
					gGame->render->render_pipeline->debug_barbette = NullPtr;
			}
			else
				gGame->render->render_pipeline->debug_barbette = NullPtr;
		}
	}

	//debug
	void StateMainGame::Teleport(float x, float y, float z)
	{
		if(gGame && gGame->channel_connection)
		{
			Core::Vector3 pos(x,y,x);
			Core::Quaternion rot(Core::Quaternion::kIdentity);

			gGame->channel_connection->Teleport(pos, rot);
		}
	}

	//debug
	void StateMainGame::SetMessageClientFlag(bool flag)
	{
		if(m_DebugMode)
		{
			if(gGame && gGame->channel_connection)
			{
				gGame->channel_connection->SetClientMessage(flag);
			}
		}
	}
#endif
}