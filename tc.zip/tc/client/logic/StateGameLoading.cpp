#include "pch.h"

using namespace Core;
using namespace Client;
using namespace Gui;


 DEFINE_PDE_TYPE_CLASS(StateGameLoading)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_PROPERTY_R(Progress);

		ADD_PDE_FIELD(map_name);
		ADD_PDE_FIELD(gameMode);

		ADD_PDE_EVENT(EventProgressMove);
		ADD_PDE_EVENT(EventLeave);
		ADD_PDE_EVENT(EventEnter);
	}
};

REGISTER_PDE_TYPE(StateGameLoading);


//----------------------------------------------------------------------------------
// game loading
//----------------------------------------------------------------------------------
namespace Client
{
}
namespace Client
{
	StateGameLoading::StateGameLoading()
		: gameMode(Client::RoomOption::kGameTypeCount)
	{
		m_Progress = 0;
		m_time = 0.0f;
	}

	void StateGameLoading::OnEnter()
	{
		if (gRender)
			gRender->SetGameState(D3DRender::kGameLoadingEnter);

		step = kInitialize;

		gLevel->Initialize();
		gLevel->GetPlayer()->uid = player_id;

		main_game = ptr_new StateMainGame;

		if (gameMode == Client::RoomOption::kTDMode || gameMode == Client::RoomOption::kEditMode )
		{
			Lua::LuaState::FromThread()->DoFile("/scripts/state_source_loading.lua");
			EventEnter.Fire(ptr_static_cast<StateGameLoading>(this), EventArgs());
		}
		else
		{
			Lua::LuaState::FromThread()->DoFile("/scripts/state_game_loading.lua");
		}
		
		step = kLoadError;

		if (gLevel->LoadMap(map_name))
		{
			gLevel->GC();
			if (gLevel->Load())
			{
				step = kLoading;
				m_Progress = 0;
				m_ResourceCount = Resource::UnloadedResCount();
			}
		}
		else
			step = kLoadError;
	}

	void StateGameLoading::OnUpdate(float frameTime)
	{
		switch (step)
		{
		//case kInitialize:
		//	{
		//		step = kLoadError;

		//		if (gLevel->LoadMap(map_name))
		//		{
		//			gLevel->GC();
		//			if (gLevel->Load())
		//			{
		//				step = kLoading;
		//				m_Progress = 0;
		//				m_ResourceCount = Resource::UnloadedResCount();
		//			}
		//		}
		//		else
		//			step = kLoadError;
		//	}
		//	break;

		case kLoading:
			{
				gLevel->GC();

				float progress = Clamp(float(m_ResourceCount - (int)Resource::UnloadedResCount()) / (float)m_ResourceCount, 0.f, 1.f);
				Sleep(1);

				if (progress > m_Progress)
				{
					m_Progress = progress;
					EventProgressMove.Fire(ptr_static_cast<StateGameLoading>(this), EventArgs());
				}

				if (!Resource::IsLoading())
				{
					m_time+=frameTime;
					if(m_time>3)
					{
						step = kFinished;
					}
				}
			}
			break;

		case kLoadError:
			{
				if (gGame->channel_connection)
					gGame->channel_connection->LeaveGame();
			}
			break;

		case kFinished:
			{
				// finished
				if (gGame->channel_connection&&gGame->channel_connection->GetGameState() == ChannelConnection::kLoading)
				{
					owner->ChangeState(main_game);
					m_time = 0.0f;
				}
			}
			break;
		}
		if (gRender)
			gRender->Update(frameTime);

		if(gGame->lobby_connection)
		{
			gGame->lobby_connection->UpdateCharacterTimer(frameTime);
		}
	}

	void StateGameLoading::OnInput(InputEventArgs & e)
	{
	}

	void StateGameLoading::OnDisconnect()
	{
		Console.WriteLine("Disconnected.");

		if (!gGame->lobby_connection)
		{
			gGame->machine.ChangeState(ptr_new StateLogin);
		}
		else
		{
			gGame->lobby_connection->RestoreToStateLobby();
			tempc_ptr(StateLobby) lobbyState = ptr_static_cast<StateLobby>(gGame->machine.CurrentState());
			if (lobbyState)
			{
				lobbyState->OnLeaveChannel();
			}
			gGame->guiSys->ShowMessage(gLang->GetTextW(L"������Ϸ�����������ӳ�ʱ�Զ��Ͽ�\n�볢����������"));		}
	}

	// render
	void StateGameLoading::OnRender()
	{
	}

	void StateGameLoading::OnLeave()
	{
		if (gRender)
			gRender->SetGameState(D3DRender::kGameLoadingLeave);

		EventLeave.Fire(ptr_static_cast<StateGameLoading>(this), EventArgs());
	}
}