
using namespace Core;
using namespace Client;

//----------------------------------------------------------------------------------
// game start
//----------------------------------------------------------------------------------
class StateTest : public GameState
{
public:
    StateTest();

	DECLARE_PDE_EVENT(EventInit,	Core::EventArgs);
	DECLARE_PDE_EVENT(EventLeave,	Core::EventArgs);
	DECLARE_PDE_EVENT(EventTest,	Core::EventArgs);
	

	void OnEnter();
	void OnLeave();

	void OnUpdate(float frameTime);
	void OnInput(InputEventArgs & e);
	void OnMessage()
	{
	}

	void OnDisconnect()
	{
	}

	// render
	void OnRender();
private:
	
};

