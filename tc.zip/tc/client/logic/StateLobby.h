namespace Client
{
	struct RetEventArgs : public Core::EventArgs
	{
		uint	Ret;

		// constructor
		RetEventArgs()
			: Ret(0)
		{
		}

		RetEventArgs(uint ret)
			: Ret(ret)
		{
		}
	};

	struct RetEventArgs3 : public Core::EventArgs
	{
		uint	a;
		uint    b;
		uint    c;

		// constructor
		RetEventArgs3()
			: a(0), b(0), c(0)
		{
		}

		RetEventArgs3(uint aa, uint bb, uint cc)
			: a(aa), b(bb), c(cc)
		{
		}
	};

	struct CmdEventArgs	: public Core::EventArgs
	{
		Core::String	Details;
	};

	struct AddressEventArgs : public Core::EventArgs
	{
		int userdata;
		Core::String name;
		byte online;
		ClientAddress address;
	};

	//ƥ��
	struct AddmatchEvenArgs : public Core::EventArgs
	{
		uint match_id;
		Core::String match_name;
	};

	struct TepGroupEventArgs : public Core::EventArgs
	{
		uint Group_id;
		Core::String name;
		Core::String Groupname;
	};

	struct ForceExitEventArgs : public Core::EventArgs
	{
		int exit_id;
	};

	struct BattleChangeRoom : public Core::EventArgs
	{
		byte change_room;
		uint server_id; 
		uint channel_id; 
		uint room_id;
		byte is_challenge;
		uint team1;
		uint team2;
	};

	struct InviteChangeRoom : public Core::EventArgs
	{
		uint group_id;
		uint server_id; 
		uint channel_id; 
		uint room_id;
	};

	struct TepGroupMemberEventArgs : public Core::EventArgs
	{
		uint Group_id;
		uint num_which;
		Core::String MemberName;
		uint         MemberName_id;
		uint         MemberName_vip;
		uint         MemberName_business_card;
		uint         MemberName_net_bar_level;
		TepGroupMemberEventArgs()
			: Group_id(0)
			, num_which(0)
			, MemberName(NULL)
			, MemberName_id(0)
			, MemberName_vip(0)
			, MemberName_business_card(0)
			, MemberName_net_bar_level(0)
		{
		}
		void MemberClear()
		{
			num_which = 0;
			MemberName = NULL;
			MemberName_id = 0;
			MemberName_vip = 0;
			MemberName_business_card = 0;
			MemberName_net_bar_level = 0;
		}
	};

	struct RoomInfo;
	struct ClientInfo;
	struct RoomOption;
	struct LevelInfo;


	class StateLobby : public GameState
	{
		friend class LobbyConnection;

	public:
		interface IRoomListCompareFunc : Gui::ListTreeView::SortFunc
		{
			bool operator ()(by_ptr(Gui::ListItem) item1, by_ptr(Gui::ListItem) item2, S32 column, int reverse);
			void Invoke(Core::IArguments & args) { throw Core::ArgumentNullException(0); };
		};
		interface IChannelListCompareFunc : Gui::ListTreeView::SortFunc
		{
			bool operator ()(by_ptr(Gui::ListItem) item1, by_ptr(Gui::ListItem) item2, S32 column, int reverse);
			void Invoke(Core::IArguments & args) { throw Core::ArgumentNullException(0); };
		};
		interface IServerListCompareFunc : Gui::ListTreeView::SortFunc
		{
			bool operator ()(by_ptr(Gui::ListItem) item1, by_ptr(Gui::ListItem) item2, S32 column, int reverse);
			void Invoke(Core::IArguments & args) { throw Core::ArgumentNullException(0); };
		};

	public:
		enum AutoChangeState
		{
			kIdle = 0,
			kLeaveRoom,
			kLeaveChannel,
			kLeaveServer,
			kEnterServer,
			kEnterChannel,
			kEnterRoom,
		};

	public:
		DECLARE_PDE_EVENT(EventOnQuitInGame,			Core::EventArgs);
		DECLARE_PDE_EVENT(EventOnNeedFCMNotified,			Core::EventArgs);
		DECLARE_PDE_EVENT(EventOnDisconnected,			Core::EventArgs);
		DECLARE_PDE_EVENT(EventLeave,					Core::EventArgs);
		DECLARE_PDE_EVENT(EventAddressChanged,			Core::EventArgs);
		DECLARE_PDE_EVENT(EventEnterRoomSuccess,	    Core::EventArgs);
		DECLARE_PDE_EVENT(EventCreateRoomFailed,	    RetEventArgs);
		DECLARE_PDE_EVENT(EventEnterRoomFailed,			RetEventArgs);
		DECLARE_PDE_EVENT(EventInRoomChangeTeamSuccess,	Core::EventArgs);
		DECLARE_PDE_EVENT(EventRoomListChanged,			Core::EventArgs);
		DECLARE_PDE_EVENT(EventUpdateNovice,			Core::EventArgs);
		DECLARE_PDE_EVENT(EventRoomClientListChanged,	Core::EventArgs);
		DECLARE_PDE_EVENT(EventRoomAutoStart,			Core::EventArgs);
		DECLARE_PDE_EVENT(EventRoomAutoStartCancel,		Core::EventArgs);
		DECLARE_PDE_EVENT(EventRoomOptionChanged,		Core::EventArgs);
		DECLARE_PDE_EVENT(EventRoomOptionChangedFailed,	RetEventArgs);
		DECLARE_PDE_EVENT(EventRoomSlotChanged,			Core::EventArgs);
		DECLARE_PDE_EVENT(EventInitUI,					Core::EventArgs);
		DECLARE_PDE_EVENT(EventRestoreUI,				Core::EventArgs);
		DECLARE_PDE_EVENT(EventKickedInRoom,			Core::EventArgs);
		
		DECLARE_PDE_EVENT(EventUpdateLevelList1,			Core::EventArgs);
		DECLARE_PDE_EVENT(EventUpdateServerList,		Core::EventArgs);
		DECLARE_PDE_EVENT(EventUpdateChannelList,		Core::EventArgs);
		DECLARE_PDE_EVENT(EventServerCmd,				CmdEventArgs);
		DECLARE_PDE_EVENT(EventIdleKicked,				Core::EventArgs);

		DECLARE_PDE_EVENT(EventGameBegin,               RetEventArgs);
		DECLARE_PDE_EVENT(EventGameReady,               RetEventArgs);

		DECLARE_PDE_EVENT(EventEnterServer,				RetEventArgs);
		DECLARE_PDE_EVENT(EventEnterChannel,			RetEventArgs);
		DECLARE_PDE_EVENT(EventCancelChannel,			RetEventArgs);
		DECLARE_PDE_EVENT(EventLeaveServer,				RetEventArgs);
		DECLARE_PDE_EVENT(EventLeaveRoom,				RetEventArgs);
		DECLARE_PDE_EVENT(EventSearchRoom,				RetEventArgs3);
		DECLARE_PDE_EVENT(EventChannelClientListChanged,Core::EventArgs);
		DECLARE_PDE_EVENT(EventCreatGroup,				TepGroupEventArgs);
		DECLARE_PDE_EVENT(EventInviteGroup,				TepGroupEventArgs);
		DECLARE_PDE_EVENT(EventGetGroupMember, TepGroupMemberEventArgs);
		DECLARE_PDE_EVENT(EventChannelEnter,Core::EventArgs);
		DECLARE_PDE_EVENT(EventChannelLeave,Core::EventArgs);

		DECLARE_PDE_EVENT(EventFocusLost,				Core::EventArgs);

		DECLARE_PDE_EVENT(EventForcelLeave,				ForceExitEventArgs);

		DECLARE_PDE_EVENT(EventAddressArrived,			AddressEventArgs);
		DECLARE_PDE_EVENT(EventMatchRoom,               AddmatchEvenArgs);
		DECLARE_PDE_EVENT(EventQueryExpiredItem,		Core::EventArgs);

		DECLARE_PDE_EVENT(EventNeedAutoPassword,		Core::EventArgs);
		DECLARE_PDE_EVENT(EventSavePhoto,				Core::EventArgs);

		DECLARE_PDE_EVENT(EventBattleRoomChange,		Core::EventArgs);
		DECLARE_PDE_EVENT(EventSaveTiaoZhan,			Core::EventArgs);
		DECLARE_PDE_EVENT(EventFillTiaoZhan,			RetEventArgs);
		DECLARE_PDE_EVENT(EventSaveZhihuisuo,			Core::EventArgs);
		DECLARE_PDE_EVENT(EventFillZhihuisuo,			RetEventArgs);
		DECLARE_PDE_EVENT(EventBattleGroupSearching,	RetEventArgs);
		DECLARE_PDE_EVENT(EventCancelMatch,             RetEventArgs);
		DECLARE_PDE_EVENT(EventMatch,             RetEventArgs);
		DECLARE_PDE_EVENT(EventBattleGroupGameStart,	BattleChangeRoom);
		DECLARE_PDE_EVENT(NotifyBattleGroupInvite,		TepGroupEventArgs);
		DECLARE_PDE_EVENT(NotifyBattleGroupKick,		RetEventArgs);
		DECLARE_PDE_EVENT(EnterFightRoomSuccess,		RetEventArgs);
		DECLARE_PDE_EVENT(EnterFightRoomError,		RetEventArgs);
		DECLARE_PDE_EVENT(EventFCM_MAX,					Core::EventArgs);
		DECLARE_PDE_EVENT(EnterFightCreatrRoomSuccess,		RetEventArgs);
		DECLARE_PDE_EVENT(EnterSourceRoomError,		RetEventArgs);

	public:
		INLINE_PDE_ATTRIBUTE_R(ChatWindow,				tempc_ptr(Gui::ChatWindow));
		INLINE_PDE_ATTRIBUTE_R(SysMsgBar,				tempc_ptr(Gui::SysMessageBar));
		DECLARE_PDE_ATTRIBUTE_R(SquadPanel,				tempc_ptr(Gui::SquadPanel));
		INLINE_PDE_ATTRIBUTE_R(LobbyPList,				tempc_ptr(Gui::LobbyPList));
		DECLARE_PDE_ATTRIBUTE_R(AmILeader,				bool);
		DECLARE_PDE_ATTRIBUTE_W(AutoPassword,			const Core::String&);
		INLINE_PDE_ATTRIBUTE_RW(Is_Need_Train,			bool);
		INLINE_PDE_ATTRIBUTE_RW(Is_in_invite,			bool);

		INLINE_PDE_ATTRIBUTE_RW(Today_Check,			bool);
		INLINE_PDE_ATTRIBUTE_RW(b_player_info,			sharedc_ptr(BattlePlayerInfo));
		INLINE_PDE_ATTRIBUTE_RW(battle_room,			sharedc_ptr(BattleRoom));
		INLINE_PDE_ATTRIBUTE_RW(Is_Novice_Game,			bool);
		INLINE_PDE_ATTRIBUTE_RW(fcm_flag,				int);
		DECLARE_PDE_ATTRIBUTE_R(autostarttime,			double);
		INLINE_PDE_ATTRIBUTE_R(need_fcm_notified,		int);
		INLINE_PDE_ATTRIBUTE_R(fcm_online_time,		int);
		INLINE_PDE_ATTRIBUTE_RW(last_channel_id,		int);
		INLINE_PDE_ATTRIBUTE_RW(channl_list_total_count,	int);
		INLINE_PDE_ATTRIBUTE_RW(channl_list_start,	int);
		INLINE_PDE_ATTRIBUTE_RW(is_fight_team_server,			bool);
		INLINE_PDE_ATTRIBUTE_RW(zhihuisuo_num,			int);
		INLINE_PDE_ATTRIBUTE_RW(battle_is_create,			bool);
		INLINE_PDE_ATTRIBUTE_RW(source_is_create,			bool);
	public:
		// constructor.
		StateLobby();

		// on create
		void OnCreate();

		void OnDestroy();

		// on enter
		void OnEnter();

		// init lobby UI
		void InitUI();

		// restore lobby UI
		void RestoreUI();

		// on leave
		void OnLeave();

		// on enter server
		void OnEnterServer(uint result);

		// on enter server
		void OnLeaveServer(uint result);

		// on enter channel
		void OnEnterChannel();

		// on leave channel
		void OnLeaveChannel();

		void OnGameBegin(uint ret);

		void OnGameReady(uint ret);

		// on enter room
		void OnEnterRoom();

		// on leave room
		void OnLeaveRoom();

		// on inroom change team success
		void OnInRoomChangeTeamSuccess();

		// on room list changed
		void OnRoomListChanged();

		// on room client list changed
		void OnRoomClientListChanged();

		// on room Auto Start
		void OnRoomAutoStart(double time);

		// on room Auto Start Cancel
		void OnRoomAutoStartCancel();

		// on room option changed
		void OnRoomOptionChanged();

		// on room slot changed
		void OnRoomSlotChanged();

		// on update level list
		void OnUpdateLevelList();

		// on update level list
		void OnUpdateServerList();

		// on update level list
		void OnUpdateChannelList();

		// on kicked in room
		void OnKickedInRoom();

		void OnQuitInGame();

		// on kicked in room
		void OnKickedIdleInGame();
		
		// on update
		void OnUpdate(float frameTime);

		// on input
		void OnInput(InputEventArgs & e);

		// on disconnect
		void OnDisconnect();

		// on render
		void OnRender();

		// on chat
		void OnChat(ChatMessage & msg);

		// on rpc message (push message)
		void OnRPCMessage(const Core::String& msg);

		// on game start
		void OnGameStart(uint player_id);

		// fcm
		void OnFCM(int online_minutes, const char * message);

		// response inviting someone
		void OnResponseTeamInvite(const Core::String& name, int result);

		// response joining a team
		void OnResponseTeamJoin(const Core::String& name, int result);

		// received a team invite
		void OnTeamInvite(const Core::String& name, int uid);

		// notify team member join
		void OnTeamMemberJoin(const Client::TeamMember& member);

		// notify team member leave
		void OnTeamMemberLeave(const Core::String& name);

		// notify team change leader
		void OnTeamChangeLeader(const Core::String& name);

		// notify team member info
		void OnTeamMemberInfo(const Client::TeamMember& member);

		// notify team change leader
		void OnTeamLeave();

		void OnFocusLost();

		// start novice
		bool StartNovice();

		int HttpXLInfo(const Core::String& bugtitle, const Core::String& bugdesc, const Core::String& qq, const Core::String& phone, int type);

		int HttpXLReport(const Core::String& report_character_name, int report_type, const Core::String& report_desc);

		//void Begin();

		//void End();

		void OnTeamRoomPreserve(uint server_id, uint channel_id, ushort room_id, byte slot_id, const Core::String& invite_name);

		void OnTeamRoomCall(uint server_id, uint channel_id, ushort room_id, const Core::String& invite_name);

		void OnTeamRoomCancelPreserve(uint server_id, uint channel_id, ushort room_id, byte slot_id);

		tempc_ptr(Gui::ListTreeView::SortFunc) GetRoomListCompareFunc() { return m_RoomListCompare; }
		tempc_ptr(Gui::ListTreeView::SortFunc) GetChannelListCompareFunc() { return m_ChannelListCompare; }
		tempc_ptr(Gui::ListTreeView::SortFunc) GetServerListCompareFunc() { return m_ServerListCompare; }

		void OnChannelClientListChanged();

		void OnCreateGroup(TepGroupEventArgs& e);

		void OnInviteGroup(TepGroupEventArgs& e);

		void OnGetGroupMember(TepGroupMemberEventArgs& e);


		int GetChannelClientCount(int);
		ChannelClientInfo GetChannelClientInfo(int id);

		// replay paly 
		void ReplayPlay();

		// replay open
		int ReplayOpen(Core::String replay_name);

		// update replay list
		void UpdateReplayList();

		// get replay count
		uint GetReplayCount();

		// get replay path
		Core::String GetReplayName(uint index);
		
		// replay delete
		void ReplayDelete(Core::String replay_name);

	public:
		void AutoChangeRoom(int server_id, int channel_id, int room_id);
		void AutoChangeRoomWithPassword(int server_id, int channel_id, int room_id, const Core::String & ps);
		void AutoEnterRoom();
		void ContinueAutoEnterRoom();

		void CancelAutoChange();

		bool IsAutoChanging();
		void AutoPhoto();
	public:
		// channel connect
		void ConnectChannel(int channel_id);

		// channel leave
		void LeaveChannel();

		void ForceUILeaveChannel();

		void ForceUILeaveServer();

	public:
		// create room
		void CreateRoom(const RoomOption & option);
		// todo
		void CreateRoomTest();

		// enter room
		void EnterRoom(int room_id, const Core::String & ps);

		// team enter room
		void TeamEnterRoom(int room_id, const Core::String & ps);

		// get room count
		int GetRoomCount();

		// get room info by id
		tempc_ptr(RoomInfo) GetRoomInfoById(short id);

		// get room
		tempc_ptr(RoomInfo) GetRoomInfo(uint index);

		// get client count
		int GetClientCount();

		// get client
		tempc_ptr(ClientInfo) GetClientInfo(uint index);

		// get my client info
		tempc_ptr(ClientInfo) GetMyClientInfo();

		//get User id
		int GetUserId();

		// get character id
		int GetCharacterId();

		// get character name
		Core::String GetCharacterName();

		// get character gender
		int GetCharacterGender();

		// change address

		// get level count
		int GetLevelCount();

		// get level info
		tempc_ptr(LevelInfo) GetLevelInfo(uint index);

		// get level info
		tempc_ptr(LevelInfo) GetLevelInfoById(int id);

		// get slot
		RoomSlot GetSlot(uint index);

		BattleOtherPlayerInfo& GetBattlePlayerInfo(uint index);

	public:
		// get self room info
		RoomInfo GetSelfRoomInfo();

		// room change option
		void RoomChangeOption(const RoomOption & option);

		// room kick client
		void RoomKickClient(byte id);

		// leave room
		void LeaveRoom();

		// start game
		void StartGame();

		// enter game
		void EnterGame();

		// ready
		void Ready(bool ready);

		// change team
		void ChangeTeam(byte team);

		// change slot
		void ChangeSlot(byte slot_id);

		// change slot status
		void ChangeSlotStatus(byte slot_id, uint status);

		// refresh client list
		void RefreshClientList(int start);

		// get game type description
		Core::String GetGameDescription(RoomOption::GameType game_type);

		// preserve slot
		void PreserveSlot(byte slot_id, const Core::String & name);

		// get server count
		int GetServerCount();

		// get server item
		ServerInfo GetServerInfo(int id,bool is_postion = true);

		// get channel count
		int GetChannelCount();

		// get channel info
		ChannelInfo GetChannelInfo(int id);

		// enter server
		void EnterServer(int id);

		// leave server
		void LeaveServer();
			
		// enter server
		void EnterChannel(int id);

		// refresh server list
		void RefreshServerList();

		// refresh channel list
		void RefreshChannelList();

		Core::Vector2 GetScreenSize();

		Core::Vector2 GetUIWindowSize();

		Core::Vector2 GetCursorPos();

	public:
		// team invite
		void TeamInvite(const Core::String & name);

		// team join
		void TeamJoin(const Core::String & name, uint uid);

		// team leave
		void TeamLeave();

		// team kick
		void TeamKick(const Core::String & name);

		// team change leader
		void TeamChangeLeader(const Core::String & name);

		// team refuse
		void TeamRefuse(const Core::String & name, uint uid);

		// team refuse to enter leader's room
		void TeamRefusePreserve(const Core::String& callerName, uint server_id, uint channel_id, ushort room_id);

		// team call
		void TeamCall(const Core::String & name);

		// group create
		void GroupCreate();
		
		// group invite
		void GroupInvite(const Core::String & name, uint uid);

		// group join
		void GroupJoin(uint uid);

		// group leave
		void GroupLeave(uint uid);

		// get group leave
		void GetGroupMember(uint uid);

		// search room
		void SearchRoom(RoomSearchOptions & options);

		// cancel search room
		void CancelSearchRoom();
		
		// blacklist add
		void BlacklistAdd(uint uid,const Core::String& str);

		// blacklist clear
		void BlacklistClear();

		//get module_state
		bool GetModuleState();

		void GetBattleGroupCreate(uint server_id, uint channel_id, uint room_id, RoomOption &roomoption);

		void BattleGroupLeave(uint battlegroup_uid);

		void GetBattleGroupJoin(uint battlegroup_uid);

		void BattleGroupReady();

		void GetBattleGroups(const Core::String& group_name, uint start, uint count, byte is_searchonly);

		void BattleGroupStartSearch(byte is_cancel);

		void BattleGroupInvite(const Core::String& name);

		void BattleGroupChallenge(uint battlegroup_uid);

		void RequestTDData(int level_id, int map_level, int res_value, const Core::String& rand_key);

		void RequestMatching();

		void RequestCancelMatching();

	public:
		void UpdateBlackList(Lua::LuaState *L);

		void RequestCharacterAddress(const Core::String& cName, int userData);

		void OnAddressArrived(int userData, const Core::String& name, byte online, const ClientAddress& address);
       
		void OnAddMatch(int match_id,const Core::String& match_name);

		void SwitchBGM(bool lobby);
	public:
		//�ı��������
		void OnChange_Lobby_Music(int type);

	private:
		void ResetAutoChangeState();

		//��ú�װ��ͨ�� �ͻ���YY
		void UpdatePrizeTime(float frameTime);

	private:
		sharedc_ptr(Gui::ChatWindow)		m_ChatWindow;
		sharedc_ptr(Gui::SysMessageBar)	m_SysMsgBar;
		sharedc_ptr(Gui::LobbyPList)		m_LobbyPList;
		//sharedc_ptr(Gui::Label)			m_NoteIcon;

		//sharedc_ptr(Character) preview_character;
		Core::Array<Core::String>		m_ReplayList;
		int m_last_channel_id;

		AutoChangeState auto_changing;
		int auto_server_id;
		int auto_channel_id;
		int auto_room_id;
		Core::String auto_room_ps;
		AutoChangeState last_autochange_error;
		F32 auto_time_out;
		Core::String auto_password;
		bool waiting_for_auto_pwd;
		bool waiting_for_auto_room_list;

		bool refresh_room_list;

		FMOD::Event* m_music_lobby;
		FMOD::Event* m_music_lobby_storage;
		FMOD::Event* m_music_lobby_match;
		FMOD::Event* m_music_tune;

//		Core::Array<uint>	m_Blacklist;

		static sharedc_ptr(IRoomListCompareFunc) m_RoomListCompare;
		static sharedc_ptr(IChannelListCompareFunc) m_ChannelListCompare;
		static sharedc_ptr(IServerListCompareFunc) m_ServerListCompare;

		//��ú�װ��ͨ�� �ͻ���YY
		float	m_Prize_times;
		int		m_Prize_Index;

	public:
		bool m_Today_Check;
		bool m_Is_Need_Train;
		bool m_Is_in_invite;
		bool m_Is_in_invite1;
		bool m_Is_Novice_Game;
		int  m_fcm_flag;
		double m_autostarttime;

		bool m_need_fcm_notified;
		int m_fcm_online_time;

		float gc_time;
		int m_channl_list_total_count;
		int m_channl_list_start;
		bool m_is_fight_team_server;
		bool m_battle_is_create;
		bool m_source_is_create;
		bool m_is_zhihuisuo;
		int m_zhihuisuo_num;
		sharedc_ptr(BattlePlayerInfo) m_b_player_info;
		sharedc_ptr(BattleRoom) m_battle_room;
		int battle_room_groupid[3];
		bool m_tiaozhan_request;
		float update_timer;
		bool match_flag;
	};
}
