#include "pch.h"

using namespace Core;
using namespace Client;


DEFINE_PDE_TYPE_CLASS(StateTest)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(GameState);
		ADD_PDE_EVENT(EventInit);
		ADD_PDE_EVENT(EventLeave);
		ADD_PDE_EVENT(EventTest);
	}
};
REGISTER_PDE_TYPE(StateTest);

StateTest::StateTest()
{

}

void StateTest::OnEnter()
{
	Lua::LuaState::FromThread()->DoFile("/scripts/state_test.lua");
	EventInit.Fire(ptr_static_cast<StateTest>(this), EventArgs());
}

void StateTest::OnLeave()
{
	EventLeave.Fire(ptr_static_cast<StateTest>(this), EventArgs());
}


void StateTest::OnUpdate(float frameTime)
{
	if (gGame->input->IsKeyPressed(KC_T))
	{
		EventTest.Fire(ptr_static_cast<StateTest>(this), EventArgs());
	}
}

void StateTest::OnInput(InputEventArgs & e)
{
	
}

void StateTest::OnRender()
{
	
}


