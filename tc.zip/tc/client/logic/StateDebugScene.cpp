#include "pch.h"

using namespace Core;
using namespace Client;

#define QUERY_FOV 90.0f

#if DEBUG_TOOLS

DEFINE_PDE_TYPE_ENUM(StateDebugScene::SampleMode)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_ENUM_ITEM("kCenter",		StateDebugScene::kCenter);
		ADD_PDE_ENUM_ITEM("kAABB",			StateDebugScene::kAABB);
		ADD_PDE_ENUM_ITEM("kInterval",		StateDebugScene::kInterval);

		ADD_PDE_ENUM_CONSTRUCTOR();
	}
};

REGISTER_PDE_TYPE(StateDebugScene::SampleMode);

DEFINE_PDE_TYPE_CLASS(StateDebugScene)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_PROPERTY_R(Progress);
		ADD_PDE_PROPERTY_RW(bDrawColorMap);
		ADD_PDE_PROPERTY_RW(bDrawLightMap);
		ADD_PDE_PROPERTY_RW(bDrawMask1Map);
		ADD_PDE_PROPERTY_RW(bDrawMask2Map);
		ADD_PDE_PROPERTY_RW(bDrawDecal1Map);
		ADD_PDE_PROPERTY_RW(bDrawDecal2Map);
		ADD_PDE_PROPERTY_RW(MoveSpeed);
		ADD_PDE_PROPERTY_RW(RotSpeed);
		ADD_PDE_EVENT(EventLeave);		
		ADD_PDE_EVENT(EventProgressMove);		
		ADD_PDE_EVENT(EventLoadingFailed);		
		ADD_PDE_EVENT(EventLoadingOk);		
		ADD_PDE_EVENT(EventLoadingBeginLoad);		
		ADD_PDE_METHOD(LoadScene);
		ADD_PDE_METHOD(SetParticleVisable);
		ADD_PDE_METHOD(SetFog);
		ADD_PDE_METHOD(AddStaticMesh);
		ADD_PDE_METHOD(ReloadResource);
		ADD_PDE_METHOD(SetLightmapIntensity);

		ADD_PDE_PROPERTY_RW(SrcSampleMode);
		ADD_PDE_PROPERTY_RW(SrcInterval);
		ADD_PDE_PROPERTY_RW(Threshold);
		ADD_PDE_PROPERTY_RW(ExcludedHeight);
	}
};

REGISTER_PDE_TYPE(StateDebugScene);

namespace Client
{
	StateDebugScene::StateDebugScene()
	{
		m_bDrawColorMap = true;
		m_bDrawLightMap = true;
		m_bDrawMask1Map = true;
		m_bDrawMask2Map = true;
		m_bDrawDecal1Map = true;
		m_bDrawDecal2Map = true;
		m_Progress = 0;
		m_MoveSpeed = 1.0;
		m_RotSpeed = 1.0;

		doqueryflag = false;

		m_SrcSampleMode = kAABB;
		m_SrcInterval = Vector3(0.1f, 0.1f, 0.1f);
		m_Threshold = Vector3(1.0f, 1.0f, 1.0f);
		m_ExcludedHeight = 5.0f;

		maptree_leaf.Clear();
		query_list.Clear();
		start_query_num = 0;
		cur_dir = kXAxis;
		cur_node = NULL;
		src_sample_points.Clear();
	}

	StateDebugScene::~StateDebugScene()
	{
		maptree_leaf.Clear();
	}

	void StateDebugScene::OnEnter()
	{
		gRender->SetGameState(D3DRender::kGameLoadingEnter);
		gGame->config->SetTimeStepType(GameConfig::kTimeStepTypeVariable);

		Lua::LuaState::FromThread()->DoFile("/scripts/state_debugscene.lua");

		gGame->camera->position = Vector3(0.f, 1.5f, 2.7f);
		gGame->camera->rotation = Quaternion(Quaternion::kIdentity);
		gGame->camera->fov = NORMAL_FOV;
		gGame->camera->target_fov = NORMAL_FOV;
		gGame->camera->control_mode = Camera::kFreeMove;
		gGame->bdebugSceneState = true;

		simple_ps = RESOURCE_LOAD("/shader/simple_ps.pd9", true, PixelShaderDx9);
	}

	void StateDebugScene::OnLeave()
	{
		gGame->bdebugSceneState = false;
		EventLeave.Fire(ptr_static_cast<StateDebugScene>(this), EventArgs());

		simple_ps = NullPtr;

		maptree_leaf.Clear();
		for (U32 i = 0; i < query_list.Size(); i++)
		{
			SAFE_RELEASE(query_list[i].d3dQuery);
		}
		query_list.Clear();
		start_query_num = 0;
		cur_node = NULL;
		src_sample_points.Clear();
	}

	void StateDebugScene::OnUpdate(float frameTime)
	{
		switch (step)
		{
		case kLoading:
			{
				float progress = Clamp(float(m_ResourceCount - (int)Resource::UnloadedResCount()) / (float)m_ResourceCount, 0.f, 1.f);

				if (progress > m_Progress)
				{
					m_Progress = progress;
					EventProgressMove.Fire(ptr_static_cast<StateDebugScene>(this), EventArgs());
				}

				if (!Resource::IsLoading())
				{
					step = kFinished;

					gRender->SetGameState(D3DRender::kGameLoadingLeave);

					gGame->camera->position = Vector3(0.f, 1.5f, 2.7f);
					gGame->camera->wide_screen_mode = true;
					gGame->camera->rotation = Quaternion(Quaternion::kIdentity);
					gGame->camera->fov = NORMAL_FOV;
					gGame->camera->target_fov = NORMAL_FOV;
					gGame->camera->control_mode = Camera::kFreeMove;
					//m_Progress = 0;
					EventLoadingOk.Fire(ptr_static_cast<StateDebugScene>(this), EventArgs());
				}
			}
			break;

		case kLoadError:
			{
				EventLoadingFailed.Fire(ptr_static_cast<StateDebugScene>(this), EventArgs());
			}
			break;

		case kFinished:
			{
				// finished
			}
			break;
		}

		if (doqueryflag)
		{
			UpdateAreaQueryInfo();
			gGame->camera->ManualUpdate(QUERY_FOV, frameTime);
		}
		else
		{
			gGame->camera->FrameUpdate(NullPtr, frameTime);

			gLevel->TimeStepUpdate(frameTime);
			gLevel->Update(frameTime);

			//update arry_supplyitems
			for(U32 i = 0; i < m_arry_supplyitems.Size(); i++)
			{
				m_arry_supplyitems[i]->Update();
			}
		}

		gRender->Update(frameTime);

		OnUpdateInput(frameTime);
	}

	void StateDebugScene::OnUpdateInput(float frameTime)
	{
		if (gGame->screen->GetActive() && !(gGame->console->GetParent() && gGame->console->GetFocused()))
		{
			Vector3 control_rotate(0, 0, 0);
			Vector3 control_move(0, 0, 0);

			float frame_time = frameTime;

			if (gGame->input->IsKeyDown(MC_LEFT_BUTTON))
			{
				control_rotate = gGame->input->GetMouseMove() * 0.002f * gGame->config->GetSensitivity()* m_RotSpeed;
				control_rotate.x += gGame->input->GetPadStick(0, 2) * frame_time * 2;
				control_rotate.y -= gGame->input->GetPadStick(0, 3) * frame_time * 2;
			}
			if (gGame->input->IsKeyDown(MC_LEFT_BUTTON))
			{
				if (gGame->input->IsKeyDown(KC_LEFT)) control_rotate.x -= 2 * frame_time;
				if (gGame->input->IsKeyDown(KC_RIGHT)) control_rotate.x += 2 * frame_time;
				if (gGame->input->IsKeyDown(KC_UP)) control_rotate.y -= 2 * frame_time;
				if (gGame->input->IsKeyDown(KC_DOWN)) control_rotate.y += 2 * frame_time;

				control_move.x = (gGame->input->IsKeyDown(KC_A) - gGame->input->IsKeyDown(KC_D)  + gGame->input->GetPadStick(0, 0)) * m_MoveSpeed;
				control_move.y = (gGame->input->IsKeyDown(KC_Q) - gGame->input->IsKeyDown(KC_E) + gGame->input->GetPadStick(0, 0)) * m_MoveSpeed;
				control_move.z = (gGame->input->IsKeyDown(KC_W) - gGame->input->IsKeyDown(KC_S) + gGame->input->GetPadStick(0, 1)) * m_MoveSpeed;
			}
			
			//if (gGame->input->IsKeyPressed(KC_I))
			//{
			//	if (!doqueryflag)
			//		StartAreaRenderQueryCheck();
			//	else
			//		EndAreaRenderQueryCheck();
			//}

			if (gGame->camera->control_mode == Camera::kFreeMove && !doqueryflag)
			{
				gGame->camera->FreeMove(control_move * 5 * frame_time, control_rotate);
			}
			else
			{
				// player control
				//character->MoveLook(-control_rotate.x, -control_rotate.y);

				//character->SetMove(control_move.z, control_move.x);//
			}

			//if (gGame->input->IsKeyPressed(KC_SPACE))
			//	character->JumpByViewer();

			//LogSystem.WriteLinef("state1 rotate: %f   %f  move: %f   %f", control_rotate.x, control_rotate.y, control_move.z, control_move.x);
		}
	}

	void StateDebugScene::OnInput(InputEventArgs & e)
	{
		
	}

	void StateDebugScene::OnDisconnect()
	{
		Console.WriteLine("Disconnected.");

		gGame->machine.ChangeState(ptr_new StateLogin);
	}

	// render
	void StateDebugScene::OnRender()
	{
		if (doqueryflag)
		{
			DoAreaRenderQueryCheck();
		}
		else 
		{
			if (step == kFinished)
			{
				gLevel->OnRender(Task::GetFrameTime());

				gRender->Draw();

				for(U32 i = 0; i < m_arry_supplyitems.Size(); i++)
				{
					m_arry_supplyitems[i]->Draw(Primitive::kScene, true);
				}
			}
		}
	}

	void StateDebugScene::DoAreaRenderQueryCheck()
	{
		if (!cur_node)
		{
			return;
		}

		//LogSystem.WriteLinef("test src_sample_points[%d], dst_sample_points[%d]", src_sample_points.Size(), dst_sample_points.Size());

		//pre_render_start---------------------------------------------------
		Matrix44 View,Proj,ViewProj;
		gDx9Device->Clear(0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER | D3DCLEAR_STENCIL, 0x7f7f7f, 1.f, 0);

		gDx9Device->SetRenderTarget(0, gGame->dx9->render_target);
		gGame->camera->CalculateViewProjectionMatrix(View, Proj);
		ViewProj = View * Proj;

		gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_WORLD, Matrix44::kIdentity);
		gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_VIEWPROJ, ViewProj);
		gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_VIEW, View);

		Vector4 ViewPos(gGame->camera->position.x, gGame->camera->position.y, gGame->camera->position.z, 1.f);
		gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_VIEWPOS, &ViewPos.x);
		gDx9Device->SetPixelShaderConstantF(PS_CONSTANT_VIEWPOS, &ViewPos.x);

		gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_PROJ, Proj);

		Vector2 ScreenSize = gGame->screen->GetSize();

		Vector4 CameraInfo;
		CameraInfo.x = gGame->camera->GetNear();
		CameraInfo.y = gGame->camera->GetFar();
		CameraInfo.z = ScreenSize.x;
		CameraInfo.w = ScreenSize.y;

		gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_CAMERAINFO, &CameraInfo.x);
		gDx9Device->SetPixelShaderConstantF(PS_CONSTANT_CAMERAINFO, &CameraInfo.x);

		Vector3 CameraDirection = Vector3(0, 0, 1) * gGame->camera->rotation;
		Vector3 CameraUp		= Vector3(0, 1, 0) * gGame->camera->rotation;
		Vector3 CameraRight		= Vector3(1, 0, 0) * gGame->camera->rotation;
		gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_CAMERADIR, &CameraDirection.x);
		gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_CAMERAUP, &CameraUp.x);
		gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_CAMERARIGHT, &CameraRight.x);

		gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_LEFTHAND, &Vector4::kOne.x);
		gDx9Device->SetPixelShaderConstantF(PS_CONSTANT_LEFTHAND, &Vector4::kOne.x);

		gDx9Device->SetRenderState(D3DRS_ZFUNC, D3DCMP_LESSEQUAL);
		gDx9Device->SetRenderState(D3DRS_CULLMODE, D3DCULL_CW);
		gDx9Device->SetRenderState(D3DRS_ZENABLE, TRUE);
		gDx9Device->SetRenderState(D3DRS_ZWRITEENABLE, TRUE);
		gDx9Device->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);

		gDx9Device->SetPixelShaderConstantF(PS_CONSTANT_CHARLIGHT, gRender->render_pipeline->character_light);

		gDx9Device->SetRenderState(D3DRS_CULLMODE, D3DCULL_CW);
		gDx9Device->Clear(0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, 0, 1.f, 0);
		simple_ps->SetShader();

		gDx9Device->SetRenderState(D3DRS_ZENABLE, true);
		gDx9Device->SetRenderState(D3DRS_ZWRITEENABLE, true);
		gDx9Device->SetRenderState(D3DRS_ZFUNC, D3DCMP_LESSEQUAL);

		gDx9Device->SetRenderState(D3DRS_COLORWRITEENABLE, 0);
		{
			Level::LevelMeshSet::Enumerator it(gLevel->map_meshs);
			while (it.MoveNext())
			{
				if (AABB_IS_OUTSIDE(it.Value().aabb.TestIntersection(&gGame->camera->frustum, 0)))
					continue;

				bool bPointInAABB = it.Value().aabb.IsPointInside(gGame->camera->position);

				gDx9Device->SetForceCullModeNone(bPointInAABB);

				HashSet<Identifier, S32>::Enumerator it1(it.Value().mesh->primitive_set[0]);
				while (it1.MoveNext())
				{
					tempc_ptr(GsPrimitive) primitive = it.Value().mesh->primitive_array[0][it1.Value()];
					if (primitive)
					{
						primitive->Draw(Primitive::kEarlyZ, true);
					}
				}

				gDx9Device->SetForceCullModeNone(false);
			}
		}
		gDx9Device->SetRenderState(D3DRS_COLORWRITEENABLE, D3DCOLORWRITEENABLE_RED | D3DCOLORWRITEENABLE_GREEN | D3DCOLORWRITEENABLE_BLUE | D3DCOLORWRITEENABLE_ALPHA);
		//pre_render_end---------------------------------------------------

		// query start-----------------------------------------------------
		{
			start_query_num = 0;
			Level::LevelMeshSet::Enumerator it(gLevel->map_meshs);
			while (it.MoveNext())
			{
				if (AABB_IS_OUTSIDE(it.Value().aabb.TestIntersection(&gGame->camera->frustum, 0)) || 
					cur_node->GetVisibleListW().Contains(it.Key()))
					continue;

				query_list[start_query_num].d3dQuery->Issue(D3DISSUE_BEGIN);

				HashSet<Identifier, S32>::Enumerator it1(it.Value().mesh->primitive_set[0]);
				while (it1.MoveNext())
				{
					tempc_ptr(GsPrimitive) primitive = it.Value().mesh->primitive_array[0][it1.Value()];
					if (it1.Value())
					{
						primitive->Draw(Primitive::kEarlyZ, true);
					}
				}

				query_list[start_query_num].d3dQuery->Issue(D3DISSUE_END);
				query_list[start_query_num].mesh_id = it.Key();

				start_query_num++;
			}
		}
		// query end-----------------------------------------------------

		// get query start-----------------------------------------------------
		for (int i = 0; i < start_query_num; i++)
		{
			DWORD pixelsVisible = 0;
			while (query_list[i].d3dQuery->GetData((void*)&pixelsVisible, sizeof(DWORD), D3DGETDATA_FLUSH) == S_FALSE);
			if (pixelsVisible != 0)
			{
				if (!cur_node->GetVisibleListW().Contains(query_list[i].mesh_id))
				{
					cur_node->GetVisibleListW().PushBack(query_list[i].mesh_id);
				}
			}
		}
		start_query_num = 0;
		// get query end-----------------------------------------------------
	}

	void StateDebugScene::StartAreaRenderQueryCheck()
	{
		if (doqueryflag)
			return;

		doqueryflag = true;

		Query tmp_query;
		U32 max_querynum = gLevel->map_meshs.Size();

		query_list.Reserve(max_querynum);
		for (U32 i = 0; i < max_querynum; i++)
		{
			gDx9Device->CreateQuery(D3DQUERYTYPE_OCCLUSION, &tmp_query.d3dQuery);
			tmp_query.mesh_id = -1;

			query_list.PushBack(tmp_query);
		}
		start_query_num = 0;

		LogSystem.WriteLinef("StartAreaRenderQueryCheck()");
		LogSystem.WriteLinef("\tSrcSampleMode[%d]", (int)m_SrcSampleMode);
		if (m_SrcSampleMode == kInterval)
			LogSystem.WriteLinef("\tSrcInterval[%f, %f, %f]", m_SrcInterval.x, m_SrcInterval.y, m_SrcInterval.z);
		LogSystem.WriteLinef("\tThreshold[%f, %f, %f]", m_Threshold.x, m_Threshold.y, m_Threshold.z);
		LogSystem.WriteLinef("\tExcludedHeight[%f]", m_ExcludedHeight);

		gLevel->map_visible_tree->BuildTree(gLevel->map_movearea, m_Threshold);

		maptree_leaf.Clear();
		gLevel->map_visible_tree->GetAllLeaf(maptree_leaf);

		LogSystem.WriteLinef("Before ExcludedMapTreeLeafByHeight(), maptree_leaf.Size() : %d", maptree_leaf.Size());

		ExcludedMapTreeLeafByHeight();

		LogSystem.WriteLinef("After ExcludedMapTreeLeafByHeight(), maptree_leaf.Size() : %d", maptree_leaf.Size());

		src_sample_points.Clear();

		cur_node = NULL;
		cur_dir = kXAxis;
	}

	void StateDebugScene::EndAreaRenderQueryCheck(bool bExit)
	{
		if (!doqueryflag)
			return;

		LogSystem.WriteLinef("calc map_visible_tree over");

		maptree_leaf.Clear();
		for (U32 i = 0; i < query_list.Size(); i++)
		{
			SAFE_RELEASE(query_list[i].d3dQuery);
		}
		query_list.Clear();
		start_query_num = 0;
		cur_dir = kXAxis;
		cur_node = NULL;
		src_sample_points.Clear();

		{
			Core::FileStream treefs;
			String filename = String::Format("../../%s.oct", gLevel->name1.Str());
			if (treefs.Open(filename.Str(), FileStream::kReadWrite))
			{
				gLevel->map_visible_tree->SaveTree(treefs);

				treefs.Close();
			}
		}

		{
			FileStream treefs;
			String filename = String::Format("../../%s.txt", gLevel->name1.Str());
			if (treefs.Open(filename.Str(), FileStream::kReadWrite))
			{
				TextStreamWriter writer(treefs);
				PrintMapVisibleTree(*gLevel->map_visible_tree, writer);
				treefs.Close();
			}
		}

		doqueryflag = false;

		if (bExit)
			::ExitProcess(0);

		return;
	}

	void StateDebugScene::GenSamplePoint(const Core::AxisAlignedBox& aabb, const Core::Vector3& interval, Core::Deque<Core::Vector3>& list, SampleMode sampleMode, bool bJitter)
	{
		list.Clear();

		switch (sampleMode)
		{
		case kCenter:
			{
				Vector3 center = aabb.GetCenter();
				list.PushBack(center);
			}
			break;
		case kAABB:
			{
				Vector3 points[8];
				aabb.ComputePoints(points);
				for (int i = 0; i < 8; i++)
				{
					list.PushBack(points[i]);
				}

				Vector3 center = aabb.GetCenter();
				list.PushBack(center);
			}
			break;
		case kInterval:
			{
				for (F32 z = aabb.Min.z; z <= aabb.Max.z; z += interval.z)
				{
					for (F32 y = aabb.Min.y; y <= aabb.Max.y; y += interval.y)
					{
						for (F32 x = aabb.Min.x; x <= aabb.Max.x; x += interval.x)
						{
							Vector3 pos(x, y, z);

							list.PushBack(pos);
						}
					}
				}
			}
			break;
		default:
			break;
		}
	}

	void StateDebugScene::UpdateAreaQueryInfo()
	{
		if (src_sample_points.Size() == 0)
		{
			if (maptree_leaf.Size() != 0)
			{
				cur_dir = kXAxis;
				cur_node = maptree_leaf.Back();
				maptree_leaf.PopBack();

				Level::LevelMeshSet::Enumerator it(gLevel->map_meshs);
				while (it.MoveNext())
				{
					if (it.Value().aabb.IsIncludeAABB(cur_node->GetAABB()) || 
						cur_node->GetAABB().IsIntersectWithAABB(it.Value().aabb) || 
						cur_node->GetAABB().IsIncludeAABB(it.Value().aabb))
					{
						if (!cur_node->GetVisibleListW().Contains(it.Key()))
							cur_node->GetVisibleListW().PushBack(it.Key());
					}
				}

				GenSamplePoint(cur_node->GetAABB(), m_SrcInterval, src_sample_points, m_SrcSampleMode);

				LogSystem.WriteLinef("start maptree_leaf[%d], src_sample_points.Size() : [%d]", maptree_leaf.Size(), src_sample_points.Size());
			}
			else if (start_query_num > 0)
			{
				LogSystem.WriteLinef("wait query over...");

				return;
			}
			else
			{
				EndAreaRenderQueryCheck(true);

				return;
			}
		}

		if (cur_dir < kQueryDirectionNum)
		{
			Vector3 src_pos = src_sample_points.Back();

			gGame->camera->position = src_pos;

			Quaternion rotation;

			switch (cur_dir)
			{
			case kXAxis:
				rotation = Quaternion(Vector3(0,0,-1), Vector3(1,0,0));
				break;
			case kMinusXAxis:
				rotation = Quaternion(Vector3(0,0,-1), Vector3(-1,0,0));
				break;
			case kYAxis:
				rotation = Quaternion(Vector3(0,0,-1), Vector3(0,1,0));
				break;
			case kMinusYAxis:
				rotation = Quaternion(Vector3(0,0,-1), Vector3(0,-1,0));
				break;
			case kZAxis:
				rotation = Quaternion(Vector3(0,0,-1), Vector3(0,0,1));
				break;
			case kMinusZAxis:
				rotation = Quaternion(Vector3(0,0,-1), Vector3(0,0,-1));
				break;
			default:
				rotation = Quaternion::kIdentity;
				break;
			}

			Vector3 zxy = rotation.GetZXY();
			zxy.z = 0.f;
			gGame->camera->rotation.SetZXY(zxy);

			cur_dir = (QueryDirection)(cur_dir + 1);
		}
		else
		{
			src_sample_points.PopBack();
			cur_dir = kXAxis;

			//try again
			UpdateAreaQueryInfo();
		}
	}

	void StateDebugScene::ExcludedMapTreeLeafByHeight()
	{
		Core::Deque<OctTreeNode*> maptreeleaf_tmp;
		NxVec3 motion(0, -m_ExcludedHeight, 0);
		NxSweepQueryHit hit;
		NxMat33 rot;
		uint group_id = 0;

		maptreeleaf_tmp.Reserve(maptree_leaf.Size());
		rot.id();
		group_id |= 1 << PhysxSystem::kStatic;

		for (U32 i = 0; i < maptree_leaf.Size(); i++)
		{
			Vector3 center = maptree_leaf[i]->GetAABB().GetCenter();
			center.y = maptree_leaf[i]->GetAABB().Max.y;

			Vector3 extents = maptree_leaf[i]->GetAABB().GetExtent() * 0.5f;
			extents.y = EPSILON;

			NxBox box((const NxVec3&)center, (const NxVec3&)extents, rot);

			NxU32 num = gPhysxScene->linearOBBSweep(box, motion, NX_SF_STATICS, NULL, 1, &hit, NULL , group_id);
			if (num)
				maptreeleaf_tmp.PushBack(maptree_leaf[i]);
		}

		maptree_leaf.Clear();
		maptree_leaf.Copy(maptreeleaf_tmp);
	}
}

namespace Client
{
	// render
	void StateDebugScene::LoadScene(const Identifier& key)
	{
		step = kLoadError;
		m_arry_supplyitems.Clear();
		EventLoadingBeginLoad.Fire(ptr_static_cast<StateDebugScene>(this), EventArgs());
		gLevel->Initialize();
		gLevel->GetPlayer()->uid = 1;

		gLevel->UnloadMap();

		if (gLevel->LoadMap(key))
		{
			gLevel->GC();
			if (gLevel->Load())
			{
				step = kLoading;
				m_Progress = 0;
				m_ResourceCount = Resource::UnloadedResCount();
			}
		}
	}

	void StateDebugScene::SetParticleVisable( bool isVisable )
	{
		if(isVisable)
		{
			gLevel->particle_manager->SetVisible(true);
		}
		else
		{
			gLevel->particle_manager->SetVisible(false);
		}
	}

	void StateDebugScene::SetFog(F32 i, F32 mind, F32 maxd, F32 r, F32 g, F32 b)
	{
		gRender->render_pipeline->SetFog(i, mind, maxd, r, g, b);
	}

	void StateDebugScene::AddStaticMesh( const Core::Identifier &key, const Vector3 &vct, const Quaternion & rot, U32 lod)
	{
		sharedc_ptr(StaticMesh) propmash  = ptr_new StaticMesh(MESH_KEY_PROP);
		propmash->AddPrimitive(key, lod);
		propmash->SetPosition(vct);
		propmash->SetRotation(rot);
		m_arry_supplyitems.PushBack(propmash);
	}

	void StateDebugScene::ReloadResource( const Core::Identifier &key)
	{
		gRender->render_pipeline->ReloadResource(key);
	}

	void StateDebugScene::SetLightmapIntensity( F32 v )
	{
		gRender->render_pipeline->SetLightmapIntensity(v);
	}
}
#endif