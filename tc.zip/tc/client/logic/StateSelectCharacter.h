namespace Client
{
	class StateSelectCharacter : public GameState
	{
	public:
		DECLARE_PDE_EVENT(EventLeave,			Core::EventArgs);

	public:
		// constructor.
		StateSelectCharacter();

		// on enter
		void OnEnter();

		// on leave
		void OnLeave();

		// on update
		void OnUpdate(float frameTime);

		// on render
		void OnRender();

		// on input
		void OnInput(InputEventArgs & e);

		// on disconnected
		void OnDisconnect();

	public:
		// enter lobby
		void EnterLobby(int character_id);

		// response enter lobby
		void ResponseEnterLobby(int character_id);

	private:
		//sharedc_ptr(Character)	preview_character;


	};
}