#include "pch.h"

using namespace Core;
using namespace Client;

#define DEBUG_DRAW_COUNT 16

#if DEBUG_TOOLS

DEFINE_PDE_TYPE_CLASS(StateDebugAnim)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_EVENT(EventLeave);
		ADD_PDE_EVENT(EventLoadCbxCharater);

		ADD_PDE_METHOD(SetCharacter);
		ADD_PDE_METHOD(SetCharacterCrouch);
		ADD_PDE_METHOD(SetCharacterShoot);
		ADD_PDE_METHOD(SetCharacterReload);
		ADD_PDE_METHOD(SetDrawJoint);
		ADD_PDE_METHOD(SetDrawCharacter);
		ADD_PDE_METHOD(SetDrawPhyicalLine);
		ADD_PDE_METHOD(SetWireFrame);
		ADD_PDE_METHOD(SetWalk);
		ADD_PDE_METHOD(LoadAnimation);
		ADD_PDE_METHOD(SetCharacterStab);
		ADD_PDE_METHOD(SetCharacterLightStab);
		ADD_PDE_METHOD(SetCharacterStabHit);
		ADD_PDE_METHOD(SetCharacterLightStabHit);
		ADD_PDE_METHOD(InitModel);
	}
};

REGISTER_PDE_TYPE(StateDebugAnim);


namespace Client
{
	StateDebugAnim::StateDebugAnim() : blockSize(5)
									, isfirst(false)
									, IsDrawJoint(false)
									, IsDrawCharacter(true)
									, IsDrawPhyicalLine(false)
									, IsWalk(false)
									, avatar(-1)
									, IsCrouch(false)
									, IsWireFrame(false)
									, Isknife(false)
									, isLoad(false)
	{
		m_SunDirection = Vector4(-0.5f, 0.18f, 0.232f, 1.0f);
		m_FogPara = Vector4(1, 0, 200, 1);
		m_FogColor = Vector4(0.5f, 0.5f, 0.5f, 1.f);
		m_YFogPara = Vector4(0, 0, 200, 1);
		m_YFogColor = Vector4(1, 1, 1, 1);
		m_Intensity = Vector4(0, 2, 1, 1);

		character_info = ptr_new CharacterInfo;
		character_info->team = 0;	

		float blockOffSet = 2.5f;

		Debug_VS = RESOURCE_LOAD("/shader/oc_vs.vd9", true, VertexShaderDx9);
		Debug_PS = RESOURCE_LOAD("/shader/oc_ps.pd9", true, PixelShaderDx9);

		for (int i = 0; i< blockSize; i++)
		{
			for (int j = 0; j < blockSize; j++)
			{
				vertices.PushBack( Vector3(i - blockOffSet,0,j - blockOffSet) );
				vertices.PushBack( Vector3(i - blockOffSet,0,j+1 - blockOffSet) );
				vertices.PushBack( Vector3(i+1 - blockOffSet,0,j - blockOffSet) );

				vertices.PushBack( Vector3(i - blockOffSet,0,j+1 - blockOffSet) );
				vertices.PushBack( Vector3(i+1 - blockOffSet,0,j - blockOffSet) );
				vertices.PushBack( Vector3(i+1- blockOffSet,0,j+1- blockOffSet) );
			}
		}
	}

	StateDebugAnim::~StateDebugAnim()
	{
		vertices.Clear();
	}

	void StateDebugAnim::OnEnter()
	{
		Lua::LuaState::FromThread()->DoFile("/scripts/state_debuganim.lua");
		InitModel();
		EventLoadCbxCharater.Fire(ptr_static_cast<StateDebugAnim>(this), Core::EventArgs());
		gLevel->debug_character = ptr_new Character;
		gLevel->debug_character->SetMoveController(ptr_new SimulateMove);
		isLoad = false;

		SetCharacter(0,"rocketlauncher",false,false);
	}

	void StateDebugAnim::OnLeave()
	{
		EventLeave.Fire(ptr_static_cast<StateDebugAnim>(this), EventArgs());
		character_info = NullPtr;
		gLevel->debug_character = NullPtr;
	}

	void StateDebugAnim::OnDisconnect()
	{
		Console.WriteLine("Disconnected.");
		gGame->machine.ChangeState(NullPtr);
	}

	// render
	void StateDebugAnim::OnRender()
	{
#if DEBUG_INFO
		gGame->camera->UpdateAspect(gGame->screen->GetSize());

		RestoreState();

		if (IsWireFrame)
			gDx9Device->SetRenderState(D3DRS_FILLMODE,D3DFILL_WIREFRAME);

		if (isLoad && gLevel->debug_character)
		{
			if (IsDrawCharacter)
				gLevel->debug_character->Draw(Primitive::kScene, true);
			if (IsDrawJoint)
				gDebugRender->DrawJoints(gLevel->debug_character);
			if (IsDrawPhyicalLine)
				gDebugRender->DrawPhyicalLine();
		}

		gDx9Device->SetRenderState(D3DRS_FILLMODE,D3DFILL_SOLID); 
		
		DrawGround();

		////LogSystem.WriteLinef("camera_position : %f, %f, %f", gGame->camera->position.x, gGame->camera->position.y, gGame->camera->position.z);
#endif
	}

	void StateDebugAnim::OnUpdate(float frameTime)
	{
		gGame->camera->FrameUpdate(gLevel->debug_character, frameTime);

		OnUpdateInput(frameTime);
		UpdateCharacter(frameTime);
	}
}
//
namespace Client
{
	void StateDebugAnim::InitModel()
	{
		consultpoint = Vector3(0.f,1.2f,0.f);
		gGame->camera->position = Vector3(0.f, 1.2f, -4.5f);
		Core::Quaternion rot = Core::Quaternion(Core::Vector3(0, 1, 0),180 * DEG2RAD);
		gGame->camera->rotation = Quaternion(rot);
		gGame->camera->fov = NORMAL_FOV;
		gGame->camera->target_fov = NORMAL_FOV;
		gGame->camera->control_mode = Camera::kFreeMove;
		if (gLevel->debug_character)
			gLevel->debug_character->SetPosition(Vector3(0, 0, 0));
	}

	void StateDebugAnim::UpdateCharacter(float fTime)
	{
		if (isLoad && gLevel->debug_character)
		{
			gLevel->debug_character->UpdateModelViewer(fTime);
		}
	}

	void StateDebugAnim::SetCharacter(int count, const Core::Identifier & weapon, bool isknife, bool isfirst)
	{
		if (!gLevel->debug_character)
			return;

		avatar = count;
		weapon_key = weapon;

		this->isfirst = isfirst;
		gLevel->debug_character->SetTeam(0);
		gLevel->debug_character->SetCharacterInfo(character_info);
		character_info->LoadDefaultAvatarByType(count);
		gLevel->debug_character->Initialize();		
		gLevel->debug_character->SetPosition(Vector3(0.f, 0.f, 0.f));
		gLevel->debug_character->weapon_id = 0;
		gLevel->debug_character->ready = true;
		gLevel->debug_character->died = false;
 
		if (weapon_key == "rocketlauncher")
		{
			sharedc_ptr(Luncher) gun;
			SetWeaponType(kWeaponTypeLuncher);
			gun = ptr_new Luncher(ptr_dynamic_cast<LuncherInfo>(weapon_info));
			gun->SetOwner(gLevel->debug_character);
			gLevel->debug_character->GetFirstPerson().animation_group->RegisterEvent(gun);
			gLevel->debug_character->GetThirdPerson().node_group->RegisterEvent(gun);
			gunbase = gun;
		}
		else if (weapon_key == "shotgun" || weapon_key == "scattergun")
		{
			sharedc_ptr(ShotGun) gun;
			SetWeaponType(kWeaponTypeShotGun);
			gun = ptr_new ShotGun(ptr_dynamic_cast<ShotGunInfo>(weapon_info));
			gun->SetOwner(gLevel->debug_character);
			gLevel->debug_character->GetFirstPerson().animation_group->RegisterEvent(gun);
			gLevel->debug_character->GetThirdPerson().node_group->RegisterEvent(gun);
			gunbase = gun;
		}
		else if (weapon_key == "Laser")
		{
			sharedc_ptr(CureGun) gun;
			SetWeaponType(kWeaponTypeShotGun);
			gun = ptr_new CureGun(ptr_dynamic_cast<CureGunInfo>(weapon_info));
			gun->SetOwner(gLevel->debug_character);
			gLevel->debug_character->GetFirstPerson().animation_group->RegisterEvent(gun);
			gLevel->debug_character->GetThirdPerson().node_group->RegisterEvent(gun);
			gunbase = gun;
		}
 		CStrBuf<256> buff;       
 		Isknife = isknife;
 		if(!isknife)
 		{
 			buff.format("%s/%s", weapon.Str(), "rv1");
 			AddWeaponPart(buff);

			buff.format("%s/%s", weapon.Str(), "mz1");
			AddWeaponPart(buff);
 		}
 		else
 		{
			SetWeaponType(kWeaponTypeKnife);
 			buff.format("%s/strider", weapon.Str());
 			AddWeaponPart(buff);
 		}

		if (isfirst)
			gLevel->debug_character->SetViewMode(Client::Character::kFirstPerson);
		else
			gLevel->debug_character->SetViewMode(Client::Character::kThirdPerson);

		isLoad = true;
	}

	void StateDebugAnim::SetCharacterCrouch(bool flag)
	{
		if (isLoad && gLevel->debug_character)
			gLevel->debug_character->SetCrouch(flag);
		IsCrouch = flag;
	}

	void StateDebugAnim::SetCharacterShoot(bool multi)
	{
		if (isLoad && gLevel->debug_character)
		{
			if (!isfirst)
			{
				if (weapon_key == "minigun")
				{
					if (!IsCrouch)
						gLevel->debug_character->GetThirdPerson().node_group->PlayAction("minimachinegun_shoot", "stdshoot");
					else
						gLevel->debug_character->GetThirdPerson().node_group->PlayAction("minimachinegun_shoot", "croshoot");
				}
				else if (weapon_key == "Laser")
				{
					if (!IsCrouch)
						gLevel->debug_character->GetThirdPerson().node_group->PlayAction("laser_shoot", "stdshoot");
					else
						gLevel->debug_character->GetThirdPerson().node_group->PlayAction("laser_shoot", "croshoot");
				}
				else
				{
					if (!IsCrouch)
						gLevel->debug_character->GetThirdPerson().node_group->PlayAction("defaultshoot", "stdshoot");
					else
						gLevel->debug_character->GetThirdPerson().node_group->PlayAction("defaultshoot", "croshoot");
				}
			}
			else
			{
				if (weapon_key == "minigun")
					gLevel->debug_character->GetFirstPerson().animation_group->PlayAction("minimachinegun_shoot", "shootone");	
				else if (weapon_key == "Laser")
					gLevel->debug_character->GetFirstPerson().animation_group->PlayAction("laser_shoot", "shootone");
				else
					gLevel->debug_character->GetFirstPerson().animation_group->PlayAction("defaultshoot", "shoot");	
			}
		}
	}

	void StateDebugAnim::SetCharacterStab()
	{
		if (isLoad && gLevel->debug_character)
		{
			if (!isfirst)
			{
				if (!IsCrouch)
					gLevel->debug_character->GetThirdPerson().node_group->PlayAction("default_knife_stab", "stdstab");
				else
					gLevel->debug_character->GetThirdPerson().node_group->PlayAction("default_knife_stab", "crostab");
			}
			else
			{
				gLevel->debug_character->GetFirstPerson().animation_group->PlayAction("default_knife_stab", "stab");
			}
		}
	}

	void StateDebugAnim::SetCharacterLightStab()
	{
		if (isLoad && gLevel->debug_character)
		{
			if (!isfirst)
			{
				if (!IsCrouch)
					gLevel->debug_character->GetThirdPerson().node_group->PlayAction("default_knife_stab", "stdlightstab");
				else
					gLevel->debug_character->GetThirdPerson().node_group->PlayAction("default_knife_stab", "crolightstab");
			}
			else
			{
				gLevel->debug_character->GetFirstPerson().animation_group->PlayAction("default_knife_stab", "lightstab");
			}
		}
	}

	void StateDebugAnim::SetCharacterStabHit()
	{
		if (isLoad && gLevel->debug_character)
		{
			if (!isfirst)
			{
				if (!IsCrouch)
					gLevel->debug_character->GetThirdPerson().node_group->PlayAction("default_knife_stab", "stdweightstab");
				else
					gLevel->debug_character->GetThirdPerson().node_group->PlayAction("default_knife_stab", "croweightstab");
			}
			else
			{
				gLevel->debug_character->GetFirstPerson().animation_group->PlayAction("default_knife_stab", "stabhit");
			}
		}
	}

	void StateDebugAnim::SetCharacterLightStabHit()
	{
		if (isLoad && gLevel->debug_character)
		{
			if (!isfirst)
			{
				if (!IsCrouch)
					gLevel->debug_character->GetThirdPerson().node_group->PlayAction("default_knife_stab", "stdweightstab");
				else
					gLevel->debug_character->GetThirdPerson().node_group->PlayAction("default_knife_stab", "croweightstab");
			}
			else
			{
				gLevel->debug_character->GetFirstPerson().animation_group->PlayAction("default_knife_stab", "lightstabhit");
			}
		}
	}

	void StateDebugAnim::SetCharacterReload(bool multi)
	{
		if (isLoad && gLevel->debug_character)
		{
			if (!isfirst)
			{
				gLevel->debug_character->GetThirdPerson().node_data_upper->PlayAction("stdidle_chazhi",0.2f,true,0.0f,false);
				if (weapon_key == "rocketlauncher")
				{
					gLevel->debug_character->GetThirdPerson().show_count = multi ? 3 : 1;
					if (!IsCrouch)
						gLevel->debug_character->GetThirdPerson().node_group->PlayAction("rocketlauncher_reload", "stdreloadone");
					else
						gLevel->debug_character->GetThirdPerson().node_group->PlayAction("rocketlauncher_reload", "stdreloadone");
				}
				else if (weapon_key == "shotgun" || weapon_key == "scattergun")
				{
					gLevel->debug_character->GetThirdPerson().show_count = multi ? 3 : 1;
					if (!IsCrouch)
						gLevel->debug_character->GetThirdPerson().node_group->PlayAction("shotgun_reload", "stdreloadone");
					else
						gLevel->debug_character->GetThirdPerson().node_group->PlayAction("shotgun_reload", "stdreloadone");
				}
				else
				{
					gLevel->debug_character->GetThirdPerson().show_count = -1;
					if (!IsCrouch)
						gLevel->debug_character->GetThirdPerson().node_group->PlayAction("defaultreload", "stdreload");
					else
						gLevel->debug_character->GetThirdPerson().node_group->PlayAction("defaultreload", "croreload");
				}
			}
			else
			{
				if (weapon_key == "rocketlauncher")
				{
					gLevel->debug_character->GetFirstPerson().show_count = multi ? 3 : 1;
					gLevel->debug_character->GetFirstPerson().animation_group->PlayAction("rocketlauncher_reload", "reloadone");
				}
				else if (weapon_key == "shotgun" || weapon_key == "scattergun")
				{
					gLevel->debug_character->GetFirstPerson().show_count = multi ? 3 : 1;
					gLevel->debug_character->GetFirstPerson().animation_group->PlayAction("shotgun_reload", "reloadone");
				}
				else
				{
					gLevel->debug_character->GetFirstPerson().show_count = -1;
					gLevel->debug_character->GetFirstPerson().animation_group->PlayAction("defaultreload", "reload");
				}
			}
		}
	}

	void StateDebugAnim::LoadAnimation(const Core::Identifier & group, const Core::Identifier & ani)
	{
		if (isLoad && gLevel->debug_character)
		{
			if (!isfirst)
			{
				//bool ismulti = gLevel->debug_character->GetThirdPerson().node_group->IsGroupLoop(group);
				gLevel->debug_character->GetThirdPerson().node_group->PlayAction(group, ani);
			}
			else
			{
				//bool ismulti = gLevel->debug_character->GetThirdPerson().node_group->IsGroupLoop(group);
				gLevel->debug_character->GetFirstPerson().animation_group->PlayAction(group, ani);
			}
		}
	}

	void StateDebugAnim::SetDrawJoint(bool flag)
	{
		IsDrawJoint = flag;
	}

	void StateDebugAnim::SetDrawPhyicalLine(bool flag)
	{
		IsDrawPhyicalLine = flag;
	}

	void StateDebugAnim::SetDrawCharacter(bool flag)
	{
		IsDrawCharacter = flag;
	}

	void StateDebugAnim::SetWireFrame(bool flag)
	{
		IsWireFrame = flag;
	}

	void StateDebugAnim::SetWalk(bool flag)
	{
		IsWalk = flag;
	}

	void StateDebugAnim::AddWeaponPart(const Core::Identifier & part)
	{
		if (!gLevel->debug_character)
			return;
		if (part.Length() <= 0)
			return;
		sharedc_ptr(WeaponInfo) weapon = weapon_info;

		if (weapon)
		{
			weapon->AddPart(part);
		}

		if (gLevel->debug_character)
		{
			if (weapon)
			{
				gLevel->debug_character->SelectWeaponForViewer(0, weapon, true);
				if (gLevel->debug_character->GetWeapon(0))
					gLevel->debug_character->GetWeapon(0)->UpdateAnimation(0);
				if (gLevel->debug_character->GetThirdPerson().node_list_system)
					gLevel->debug_character->GetThirdPerson().node_list_system->SetActiveNode("game");
			}
		}
	}

	sharedc_ptr(WeaponInfo) StateDebugAnim::SetWeaponType(WeaponType type)
	{
		switch (type)
		{
			case kWeaponTypeRifle:			weapon_info = ptr_new RifleInfo;			break;
			case kWeaponTypeSubMachineGun:	weapon_info = ptr_new SubMachineGunInfo;	break;
			case kWeaponTypePistol:			weapon_info = ptr_new PistolInfo;			break;
			case kWeaponTypeKnife:			weapon_info = ptr_new KnifeInfo;			break;
			case kWeaponTypeGrenade:		weapon_info = ptr_new GrenadeInfo;			break;
			case kWeaponTypeSniperGun:		weapon_info = ptr_new SniperGunInfo;		break;
			case kWeaponTypeShotGun:		weapon_info = ptr_new ShotGunInfo;			break;
			case kWeaponTypeBomb:			weapon_info = ptr_new BombInfo;				break;
			case kWeaponTypeDualPistol:		weapon_info = ptr_new DualPistolInfo;		break;
			case kWeaponTypeMiniGun:		weapon_info = ptr_new MiniGunInfo;			break;
			case kWeaponTypeLuncher:		weapon_info = ptr_new LuncherInfo;			break;
			case kWeaponTypeDrum:			weapon_info = ptr_new DrumInfo;				break;
			case kWeaponTypeSignal:			weapon_info = ptr_new LuncherInfo;			break;
			case kWeaponTypeMilkbottle:		weapon_info = ptr_new MilkbottleInfo;		break;
			case kWeaponTypeEquipment:		weapon_info = ptr_new EquipmentInfo;		break;
		}

		return weapon_info;
	}

	void StateDebugAnim::OnUpdateInput(float frameTime)
	{
		if (!gLevel->debug_character)
			return;

		if (gGame->screen->GetActive())
		{
			Vector3 control_rotate(0, 0, 0);
			Vector3 control_move(0, 0, 0);

			float frame_time = frameTime;

			if (gGame->input->IsKeyDown(MC_RIGHT_BUTTON))
			{
				Vector3 oldpos = gGame->camera->position;

				// rotation
				Vector3 camera_right = Vector3(1, 0, 0) * gGame->camera->rotation;
				Vector3 camera_up(0, 1, 0);
				Quaternion qRotHorizontal(camera_up, -DEG2RAD * gGame->input->GetMouseMove().x * 0.1);
				Quaternion qRotVertical(camera_right, -DEG2RAD * gGame->input->GetMouseMove().y * 0.1);

				gGame->camera->rotation = gGame->camera->rotation * (qRotVertical * qRotHorizontal);
				gGame->camera->rotation.Normalize();

				Vector3 dir = gGame->camera->position - consultpoint;
				float  dis = dir.Length();
				gGame->camera->position = consultpoint + dis * Core::Vector3(0, 0, 1) * gGame->camera->rotation;
			}
			if (gGame->input->IsKeyDown(KC_NUMPAD4)) control_rotate.x -= 4 * frame_time;
			if (gGame->input->IsKeyDown(KC_NUMPAD6)) control_rotate.x += 4 * frame_time;
			if (gGame->input->IsKeyDown(KC_NUMPAD8)) control_rotate.y -= 4 * frame_time;
			if (gGame->input->IsKeyDown(KC_NUMPAD2)) control_rotate.y += 4 * frame_time;

			// player control

			control_move.x = gGame->input->IsKeyDown(KC_A) - gGame->input->IsKeyDown(KC_D) - gGame->input->GetPadStick(0, 0);
			control_move.y = gGame->input->GetPadStick(0, 4) - gGame->input->GetPadStick(0, 5);
			control_move.z = gGame->input->IsKeyDown(KC_W) - gGame->input->IsKeyDown(KC_S) + gGame->input->GetPadStick(0, 1);
			if (!gGame->input->IsKeyDown(MC_LEFT_BUTTON))
			{
				gLevel->debug_character->MoveLook(-control_rotate.x, -control_rotate.y);
				gLevel->debug_character->SetMove(control_move.z, control_move.x);
			}

			//control_move.x = gGame->input->IsKeyDown(KC_LEFT) - gGame->input->IsKeyDown(KC_RIGHT) - gGame->input->GetPadStick(0, 0);
			//control_move.y = gGame->input->GetPadStick(0, 4) - gGame->input->GetPadStick(0, 5);
			//control_move.z = gGame->input->IsKeyDown(KC_UP) - gGame->input->IsKeyDown(KC_DOWN) + gGame->input->GetPadStick(0, 1);

			else if (gGame->camera->control_mode == Camera::kFreeMove)
			{
				gGame->camera->FreeMove(control_move * frame_time, Vector3(0, 0, 0));
			}

			if (gGame->input->IsKeyPressed(KC_SPACE))
				gLevel->debug_character->JumpByViewer();
		}
	}

	bool StateDebugAnim::RestoreState()
	{
		if (!gDx9Device)
			return false;

		Matrix44 view_matrix, proj_matrix, view_proj_matrix;

		gDx9Device->SetRestore();

		gDx9Device->SetRenderTarget(0, gGame->dx9->render_target);
		gDx9Device->SetDepthStencilSurface(gGame->dx9->depth_stencil);
		gDx9Device->Clear(0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER | D3DCLEAR_STENCIL, 0x7f7f7f, 1.f, 0);

		gGame->camera->CalculateViewProjectionMatrix(view_matrix, proj_matrix);
		view_proj_matrix = view_matrix * proj_matrix;
		gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_WORLD, Matrix44::kIdentity);
		gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_VIEW, view_matrix);
		gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_PROJ, proj_matrix);
		gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_VIEWPROJ, view_proj_matrix);
		if (!gGame->screen)
			return false;

		Vector2 screen_size = gGame->screen->GetSize();
		Vector4 vp(screen_size.x, screen_size.y, 1.f / screen_size.x, 1.f / screen_size.y);
		gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_VIEWPORTDIMENSION, view_proj_matrix);

		Core::Vector4 CameraInfo;
		CameraInfo.x = gGame->camera->GetNear();
		CameraInfo.y = gGame->camera->GetFar();
		CameraInfo.z = gGame->screen->GetSize().x;
		CameraInfo.w = gGame->screen->GetSize().y;
		gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_CAMERAINFO, &CameraInfo.x);
		gDx9Device->SetPixelShaderConstantF(PS_CONSTANT_CAMERAINFO, &CameraInfo.x);
		Vector3 CameraDirection = Vector3(0, 0, 1) * gGame->camera->rotation;
		Vector3 CameraUp		= Vector3(0, 1, 0) * gGame->camera->rotation;
		Vector3 CameraRight		= Vector3(1, 0, 0) * gGame->camera->rotation;
		gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_CAMERADIR, &CameraDirection.x);
		gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_CAMERAUP, &CameraUp.x);
		gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_CAMERARIGHT, &CameraRight.x);


		gDx9Device->SetPixelShaderConstantF(PS_CONSTANT_SUNDIRECTION, &m_SunDirection.x);
		gDx9Device->SetPixelShaderConstantF(PS_CONSTANT_FOGPARAMETER, &m_FogPara.x);
		gDx9Device->SetPixelShaderConstantF(PS_CONSTANT_FOGCOLOR, &m_FogColor.x);
		gDx9Device->SetPixelShaderConstantF(PS_CONSTANT_FOGYPARAMETER, &m_YFogPara.x);
		gDx9Device->SetPixelShaderConstantF(PS_CONSTANT_FOGYCOLOR, &m_YFogColor.x);
		gDx9Device->SetPixelShaderConstantF(PS_CONSTANT_INTENSITY, &m_Intensity.x);

		//Matrix44 character_light(
		//	Vector4(1.5f, -2.0f, 1.57f, 1.0f), 
		//	Vector4(1.0f, 1.0f, 1.0f, 1.0f), 
		//	Vector4(1.5f, 2.0f, -2.8f, 1.0f), 
		//	Vector4(1.0f, 1.0f, 1.0f, 1.0f));

		//gDx9Device->SetPixelShaderConstantF(PS_CONSTANT_CHARLIGHT, character_light);
		gDx9Device->SetPixelShaderConstantF(PS_CONSTANT_CHARLIGHT, gRender->render_pipeline->character_light);

		Vector4 ViewPos(gGame->camera->position.x, gGame->camera->position.y, gGame->camera->position.z, 1.f);
		gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_VIEWPOS, &ViewPos.x);
		gDx9Device->SetPixelShaderConstantF(PS_CONSTANT_VIEWPOS, &ViewPos.x);

		gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_LEFTHAND, &Vector4::kOne.x);
		gDx9Device->SetPixelShaderConstantF(PS_CONSTANT_LEFTHAND, &Vector4::kOne.x);

		Vector4 time(Task::GetFrameTime(), Task::GetTotalTime(), 0, 0);
		gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_TIME, &time.x);
		gDx9Device->SetPixelShaderConstantF(PS_CONSTANT_TIME, &time.x);

		gDx9Device->SetVertexShaderConstantF(VS_CONSTANT_WEAPONROT, Matrix44::kIdentity);


		gDx9Device->SetRenderState(D3DRS_ZENABLE, true);
		gDx9Device->SetRenderState(D3DRS_ZWRITEENABLE, true);
		gDx9Device->SetRenderState(D3DRS_ALPHABLENDENABLE, false);
		gDx9Device->SetRenderState(D3DRS_STENCILENABLE, false);
		gDx9Device->SetRenderState(D3DRS_CULLMODE, D3DCULL_CW);
		gDx9Device->SetRenderState(D3DRS_ZFUNC, D3DCMP_LESSEQUAL);
		gDx9Device->SetRenderState(D3DRS_CLIPPLANEENABLE, false);
		gDx9Device->SetRenderState(D3DRS_COLORWRITEENABLE, 0xf);
		gDx9Device->SetRenderState(D3DRS_SLOPESCALEDEPTHBIAS, 0);
		gDx9Device->SetRenderState(D3DRS_DEPTHBIAS, 0);
		gDx9Device->SetRenderState(D3DRS_SEPARATEALPHABLENDENABLE, FALSE);

		Vector2 index(PS_CONSTANT_POINTLIGHT);
		//Vector4 dir(0, -1, 0, 1);
		//gDx9Device->SetPixelShaderConstantF(index.x++, &dir.x, 1);
		//gDx9Device->SetPixelShaderConstantF(index.x++, &Vector4::kOne.x, 1);
		gDx9Device->SetPixelShaderConstantF(index.x++, &Vector4::kZero.x, 1);
		gDx9Device->SetPixelShaderConstantF(index.x++, &Vector4::kZero.x, 1);

		gDx9Device->SetPixelShaderConstantF(index.x++, &Vector4::kZero.x, 1);
		gDx9Device->SetPixelShaderConstantF(index.x++, &Vector4::kZero.x, 1);

		gDx9Device->SetPixelShaderConstantF(index.x++, &Vector4::kZero.x, 1);
		gDx9Device->SetPixelShaderConstantF(index.x++, &Vector4::kZero.x, 1);

		gDx9Device->SetPixelShaderConstantF(index.x++, &Vector4::kZero.x, 1);
		gDx9Device->SetPixelShaderConstantF(index.x++, &Vector4::kZero.x, 1);

		gDx9Device->SetPixelShaderConstantF(PS_CONSTANT_COLORMATRIX, Matrix44::kIdentity);

		return true;
	}

	void StateDebugAnim::DrawGround()
	{
		//draw oc panel
		DWORD flag,flag1 = 0;
		gDx9Device->GetRenderState( D3DRS_ALPHABLENDENABLE, &flag );
		gDx9Device->SetRenderState( D3DRS_ALPHABLENDENABLE, true );

		gDx9Device->GetRenderState( D3DRS_CULLMODE, &flag1 );
		gDx9Device->SetRenderState( D3DRS_CULLMODE, D3DCULL_NONE );

		//gDx9Device->SetRenderState( D3DRS_FILLMODE, D3DFILL_WIREFRAME );
		gDx9Device->SetRenderState( D3DRS_FILLMODE, D3DFILL_SOLID );

		Matrix44 View,Proj,ViewProj;
		gGame->camera->CalculateViewProjectionMatrix( View, Proj );
		ViewProj = View * Proj;

		Debug_VS->SetShader();
		Debug_PS->SetShader();

		gDx9Device->SetVertexShaderConstantF( VS_CONSTANT_VIEWPROJ, ViewProj );

		gDx9Device->SetVertexDeclaration(VD::GetVertexDeclaration(VertexDeclaration::kPosition));
		gDx9Device->DrawPrimitiveUP(D3DPT_TRIANGLELIST, 2 * blockSize * blockSize, vertices.GetData(), VD::GetVertexDeclarationStride(VertexDeclaration::kPosition));

		gDx9Device->SetRenderState( D3DRS_ALPHABLENDENABLE, flag );
		gDx9Device->SetRenderState( D3DRS_CULLMODE, flag1 );
		gDx9Device->SetRenderState( D3DRS_FILLMODE, D3DFILL_SOLID );
	}
}
#endif