#include "pch.h"

using namespace Core;
using namespace Client;

DEFINE_PDE_TYPE_CLASS(StateInit)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(GameState);
		ADD_PDE_EVENT(EventInit);
		ADD_PDE_EVENT(EventLeave);
	}
};

DEFINE_PDE_TYPE_CLASS(StateLogin)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(GameState);
		ADD_PDE_EVENT(EventLeave);
		ADD_PDE_EVENT(EventLogin);
		ADD_PDE_EVENT(EventCreateNickNameFiled);
		ADD_PDE_EVENT(EventCreateNickName);
		ADD_PDE_EVENT(EventConnected);
		ADD_PDE_EVENT(EventDisconnected);
		ADD_PDE_EVENT(EventLoginSuccess);
		ADD_PDE_EVENT(EventEnterLobbySuccess);

		ADD_PDE_METHOD(Login);
		ADD_PDE_METHOD(RequestEnterLobby);
		ADD_PDE_METHOD(RequestNickNameCreate);
	}
};

REGISTER_PDE_TYPE(StateInit);
REGISTER_PDE_TYPE(StateLogin);

namespace Client
{
	StateLogin::StateLogin(bool disconnected)
		: disconnected(disconnected)
		, uid(-1)
	{
	}

	void StateLogin::OnEnter()
	{
		if (gRender)
			gRender->SetGameState(D3DRender::kLoginEnter);

// 		gGame->guiSys->SetDrawDG(true);
		if (gGame->use_luncher)
		{
			//ֻ�е�һ�ε�½��Ҫ�Զ���ת
			if(gGame->is_first_time_connect)
			{
				LoginNew();
				Lua::LuaState::FromThread()->DoFile("/scripts/state_login_new.lua");
				gGame->is_first_time_connect = false;
			}
			else
			{
				Lua::LuaState::FromThread()->DoFile("/scripts/state_login_new.lua");
			}
		}
		else
		{
			Lua::LuaState::FromThread()->DoFile("/scripts/state_login.lua");
		}
	}

	void StateLogin::OnLeave()
	{
		if (gRender)
			gRender->SetGameState(D3DRender::kLoginLeave);

		EventLeave.Fire(ptr_static_cast<StateLogin>(this), EventArgs());
	}

	void StateLogin::OnUpdate(float frameTime)
	{
		if (disconnected)
		{
			OnDisconnect();
			disconnected = false;
		}
		if (gRender)
			gRender->Update(frameTime);
	}

	void StateLogin::OnInput(InputEventArgs & e)
	{
	}

	void StateLogin::OnDisconnect()
	{
		Console.WriteLine("Disconnected.");
	
		EventDisconnected.Fire(ptr_static_cast<StateLogin>(this), EventArgs());
	}

	// render
	void StateLogin::OnRender()
	{
		if (gRender)
			gRender->Draw();
	}

	void StateLogin::OnConnected()
	{
		EventConnected.Fire(ptr_static_cast<StateLogin>(this), EventArgs());
	}

	void StateLogin::OnLoginSuccess()
	{
		gGame->error_message = String::kEmpty;
		EventLoginSuccess.Fire(ptr_static_cast<StateLogin>(this), EventArgs());				
	}

	void StateLogin::RequestEnterLobby()
	{
		if (gGame->lobby_connection &&  -1 != uid)
		{
			gGame->lobby_connection->RequestEnterLobby(uid);
		}
	}

	void StateLogin::OnCreateNickNameFiled()
	{
		EventCreateNickNameFiled.Fire(ptr_static_cast<StateLogin>(this), EventArgs());
	}

	void StateLogin::OnShowNickNameWin()
	{
		EventCreateNickName.Fire(ptr_static_cast<StateLogin>(this), EventArgs());
	}

	void StateLogin::RequestNickNameCreate(const String& name)
	{
		if(gGame->lobby_connection)
		{
			gGame->lobby_connection->RequestNickNameCreate(name);
		}
	}

	void StateLogin::ResponseEnterLobby(int character_id, int playerchecktoday)
	{
		gGame->error_message = String::kEmpty;
		EventEnterLobbySuccess.Fire(ptr_static_cast<StateLogin>(this), EventArgs());

		gGame->machine.ChangeState(ptr_new StateLobby);
		tempc_ptr(StateLobby) lobbyState = ptr_static_cast<StateLobby>(gGame->machine.CurrentState());
		if(lobbyState)
		{
			//fireball
			lobbyState->m_Is_Need_Train = false;//(firstgame == 0);
			lobbyState->m_Today_Check = (playerchecktoday == 0);
			lobbyState->InitUI();
		}
	}

	void StateLogin::OnLoginError()
	{
		if (gGame)
			gGame->global->LogoutAccount(true);
	}
}

namespace Client
{
	void StateLogin::Login(const String & name, const String & password)
	{
		// create lobby connection
		gGame->lobby_connection = ptr_new LobbyConnection;
		gGame->lobby_connection->login_name = name;
		gGame->lobby_connection->login_pass = password;
		gGame->lobby_connection->ConnectHost(gStartConfig.ip, gStartConfig.port);
		Console.WriteLinef("Connecting server %s:%d:%s...", gStartConfig.ip.Str(), gStartConfig.port, gGame->version);
		gGame->error_message = "connect_failed";

		EventLogin.Fire(ptr_static_cast<StateLogin>(this), EventArgs());
	}

	void StateLogin::LoginNew()
	{
		// create lobby connection
		gGame->lobby_connection = ptr_new LobbyConnection;
		gGame->lobby_connection->login_name = "";
		gGame->lobby_connection->login_pass = "";
		gGame->lobby_connection->ConnectHost(gStartConfig.ip, gStartConfig.port);
		Console.WriteLinef("Connecting server %s:%d:%s...", gStartConfig.ip.Str(),  gStartConfig.port, gGame->version);
		//gGame->error_message = "connect_failed";

		EventLogin.Fire(ptr_static_cast<StateLogin>(this), EventArgs());
	}
}

namespace Client
{
	
}

namespace Client
{
	void StateInit::OnEnter()
	{
		//do all lua files
		if (gGame)
		{
			logo_timer = 10.f;
			
			if (gGame->screen)
				gGame->screen->CenterToParent();
			gGame->screen->SetVisible(true);

			Lua::LuaState::FromThread()->DoFile("/scripts/state_logo.lua");
			EventInit.Fire(ptr_static_cast<StateInit>(this), EventArgs());
		}
	}

	void StateInit::OnLeave()
	{
		EventLeave.Fire(ptr_static_cast<StateInit>(this), EventArgs());
	}

	void StateInit::OnUpdate(float frameTime)
	{
		if (logo_timer < 0)
		{
			if (!Resource::IsLoading())
				gGame->machine.ChangeState(ptr_new StateLogin);
		}
		else
		{
			logo_timer -= frameTime;
		}
	}

	void StateInit::OnInput(InputEventArgs & e)
	{
		if (e.Type == InputEventArgs::kKeyDown && e.Code == KC_ESCAPE)
		{	
			logo_timer = -1;
			if (!Resource::IsLoading())
				gGame->machine.ChangeState(ptr_new StateLogin);
		}
	}
}