#include "pch.h"

using namespace Core;
using namespace Client;
using namespace Gui;

DEFINE_PDE_TYPE_CLASS(GameState)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_METHOD(TeamInvite);
		ADD_PDE_METHOD(TeamJoin);
		ADD_PDE_METHOD(TeamLeave);
		ADD_PDE_METHOD(TeamKick);
		ADD_PDE_METHOD(TeamChangeLeader);
		ADD_PDE_METHOD(TeamRefuse);
		ADD_PDE_METHOD(TeamRefusePreserve);
		ADD_PDE_METHOD(TeamCall);
		ADD_PDE_METHOD(GroupCreate);
		ADD_PDE_METHOD(GroupInvite);
		ADD_PDE_METHOD(GroupLeave);
		ADD_PDE_METHOD(GroupJoin);
		ADD_PDE_METHOD(GetGroupMember);
	}
};

REGISTER_PDE_TYPE(Client::GameState);
