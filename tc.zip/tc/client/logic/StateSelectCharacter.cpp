#include "pch.h"

using namespace Core;
using namespace Client;

DEFINE_PDE_TYPE_CLASS(StateSelectCharacter)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_EVENT(EventLeave);
		ADD_PDE_METHOD(EnterLobby);
	}
};

REGISTER_PDE_TYPE(StateSelectCharacter);

namespace Client
{
	StateSelectCharacter::StateSelectCharacter()
	{
	}

	void StateSelectCharacter::OnEnter()
	{
		if (gRender)
			gRender->SetGameState(D3DRender::kSelectCharacterEnter);

		if (gLevel)
			gLevel->Initialize();

		//Just in case the lobby connection holds the old state lobby
		if(gGame && gGame->lobby_connection)
			gGame->lobby_connection->m_RememberLobby = NullPtr;

		Lua::LuaState::FromThread()->DoFile("/scripts/state_select_character.lua");
	}

	void StateSelectCharacter::OnLeave()
	{
		if (gRender)
			gRender->SetGameState(D3DRender::kSelectCharacterLeave);

		EventLeave.Fire(ptr_static_cast<StateSelectCharacter>(this), EventArgs());
	}

	void StateSelectCharacter::OnUpdate(float frameTime)
	{
		if (gRender)
			gRender->Update(frameTime);
	}

	void StateSelectCharacter::OnRender()
	{
		if (gRender)
			gRender->Draw();
	}

	void StateSelectCharacter::OnInput(InputEventArgs & e)
	{
	}

	void StateSelectCharacter::OnDisconnect()
	{
		Console.WriteLine("Disconnected.");

		if (!gGame->lobby_connection)
			gGame->machine.ChangeState(ptr_new StateLogin);
	}

	void StateSelectCharacter::EnterLobby(int character_id)
	{
		if (gGame->lobby_connection)
			gGame->lobby_connection->RequestEnterLobby(character_id);
	}

	// response enter lobby
	void StateSelectCharacter::ResponseEnterLobby(int character_id)
	{
		if (character_id)
		{
			gGame->machine.ChangeState(ptr_new StateLobby);
			tempc_ptr(StateLobby) lobbyState = ptr_static_cast<StateLobby>(gGame->machine.CurrentState());
			if(lobbyState)
			{
				lobbyState->InitUI();
			}
		}
		else
		{
			gGame->global->LogoutAccount();
		}
	}
}

