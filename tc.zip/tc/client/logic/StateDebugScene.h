#if DEBUG_TOOLS

namespace Client
{
	class StateDebugScene : public GameState
	{
	public:
		enum ConnectingStep
		{
			kLoading,
			kLoadError,
			kFinished,
		};

		enum SampleMode
		{
			kCenter,
			kAABB,
			kInterval,
		};

		enum QueryDirection
		{
			kXAxis = 0,
			kMinusXAxis,
			kYAxis,
			kMinusYAxis,
			kZAxis,
			kMinusZAxis,
			kQueryDirectionNum,
		};

	public:
		DECLARE_PDE_EVENT(EventLeave,			Core::EventArgs);
		DECLARE_PDE_EVENT(EventProgressMove,	Core::EventArgs);
		DECLARE_PDE_EVENT(EventLoadingFailed,	Core::EventArgs);
		DECLARE_PDE_EVENT(EventLoadingOk,		Core::EventArgs);
		DECLARE_PDE_EVENT(EventLoadingBeginLoad,Core::EventArgs);
		INLINE_PDE_ATTRIBUTE_R(Progress,		float);
		INLINE_PDE_ATTRIBUTE_RW(bDrawColorMap,	bool);
		INLINE_PDE_ATTRIBUTE_RW(bDrawLightMap,	bool);
		INLINE_PDE_ATTRIBUTE_RW(bDrawMask1Map,	bool);
		INLINE_PDE_ATTRIBUTE_RW(bDrawMask2Map,	bool);
		INLINE_PDE_ATTRIBUTE_RW(bDrawDecal1Map,	bool);
		INLINE_PDE_ATTRIBUTE_RW(bDrawDecal2Map,	bool);
		INLINE_PDE_ATTRIBUTE_RW(MoveSpeed,		float);
		INLINE_PDE_ATTRIBUTE_RW(RotSpeed,		float);

		INLINE_PDE_ATTRIBUTE_RW(SrcSampleMode,	SampleMode);
		INLINE_PDE_ATTRIBUTE_RW(SrcInterval,	Core::Vector3);
		INLINE_PDE_ATTRIBUTE_RW(Threshold,		Core::Vector3);
		INLINE_PDE_ATTRIBUTE_RW(ExcludedHeight,	float);

	public:
		// constructor
		StateDebugScene();

		// destructor.
		~StateDebugScene();

		// on enter
		void OnEnter();

		// on leave
		void OnLeave();

		// on update
		void OnUpdate(float frameTime);

		// on input
		void OnInput(InputEventArgs & e);

		// on disconnected
		void OnDisconnect();

		// render
		void OnRender();

		void DoAreaRenderQueryCheck();

		// load scene
		void LoadScene(const Core::Identifier &key);
		
		// set particle visable
		void SetParticleVisable(bool isVisable);

		// set fog
		void SetFog(F32 i, F32 mind, F32 maxd, F32 r, F32 g, F32 b);

		// Add StaticMesh
		void AddStaticMesh(const Core::Identifier &key, const Core::Vector3 &vct, const Core::Quaternion & rot, U32 lod = 0);

		// reload resource
		void ReloadResource(const Core::Identifier &key);

		// set light map Intensity
		void SetLightmapIntensity(F32 v);

		// Query
		void StartAreaRenderQueryCheck();

		void EndAreaRenderQueryCheck(bool bExit = false);

		void GenSamplePoint(const Core::AxisAlignedBox& aabb, const Core::Vector3& interval, Core::Deque<Core::Vector3>& list, SampleMode sampleMode, bool bJitter = false);

		void UpdateAreaQueryInfo();

		void ExcludedMapTreeLeafByHeight();

	public:
		bool			m_bDrawColorMap;
		bool			m_bDrawLightMap;
		bool			m_bDrawMask1Map;
		bool			m_bDrawMask2Map;
		bool			m_bDrawDecal1Map;
		bool			m_bDrawDecal2Map;

	private:
		void OnUpdateInput(float frameTime);

	private:
		struct Query
		{
			LPDIRECT3DQUERY9 d3dQuery;
			int mesh_id;
		};

		ConnectingStep	step;
		float			m_Progress;
		int				m_ResourceCount;
		Core::Array<sharedc_ptr(StaticMesh)>	m_arry_supplyitems;
		float			m_MoveSpeed;
		float			m_RotSpeed;

		//query
		bool					doqueryflag;

		SampleMode				m_SrcSampleMode;
		Core::Vector3			m_SrcInterval;
		Core::Vector3			m_Threshold;
		float					m_ExcludedHeight;

		Core::Deque<OctTreeNode*>	maptree_leaf;
		sharedc_ptr(Shader)			simple_ps;
		Core::Array<Query>			query_list;
		int							start_query_num;
		QueryDirection				cur_dir;
		OctTreeNode*				cur_node;
		Core::Deque<Core::Vector3>	src_sample_points;
	};
}

#endif