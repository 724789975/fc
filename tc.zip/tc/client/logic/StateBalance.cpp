#include "pch.h"

using namespace Core;
using namespace Client;
using namespace Gui;

DEFINE_PDE_TYPE_CLASS(StateBalance)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(GameState);

		ADD_PDE_EVENT(EventLeave);
		ADD_PDE_EVENT(EventSavePhoto);
		ADD_PDE_EVENT(EventIdleKicked);
		ADD_PDE_EVENT(EventAutoStartLeaveBalance);
		ADD_PDE_PROPERTY_R(StageClear);
		ADD_PDE_PROPERTY_R(SquadPanel);
		ADD_PDE_METHOD(Quit);
		ADD_PDE_METHOD(GetSelfRoomInfo);
		ADD_PDE_METHOD(GetMyClientInfo);
		ADD_PDE_METHOD(AutoPhoto);
		ADD_PDE_METHOD(ReplaySave);
		ADD_PDE_METHOD(GetLevelInfoById);
	}
};

REGISTER_PDE_TYPE(Client::StateBalance);

namespace Client
{
	StateBalance::StateBalance(bool cleared)
		: m_totalTime(0.0f)
		, m_StageClear(cleared)
	{
	}

	PDE_ATTRIBUTE_GETTER(StateBalance, SquadPanel, tempc_ptr(Gui::SquadPanel))
	{
		if(gGame->lobby_connection)
			return gGame->lobby_connection->m_SquadPanel;
		else
			return NullPtr;
	}

	PDE_ATTRIBUTE_GETTER(StateBalance,StageClear,bool)
	{
		return m_StageClear;
	}

	void StateBalance::OnEnter()
	{

		
		gGame->camera->fov = 55;
		gGame->camera->target_fov = 55;
		gGame->camera->UpdateAspect(gGame->screen->GetSize());
		 
		if (gRender)
			gRender->SetGameState(D3DRender::kBalanceEnter);

		if (gGame->channel_connection)
			gGame->channel_connection->OnEnterBalance();
		//Lua::LuaState::FromThread()->DoFile("/scripts/state_balance.lua");
		Lua::LuaState::FromThread()->DoFile("/scripts/state_balance_new.lua");
	}

	void StateBalance::OnLeave()
	{
		if (gRender)
			gRender->SetGameState(D3DRender::kBalanceLeave);

		EventLeave.Fire(ptr_static_cast<StateBalance>(this), EventArgs());
	}

	void StateBalance::OnUpdate(float frameTime)
	{
		m_totalTime+=frameTime;
		if(m_totalTime>1500.0f)
		{
			//Leave State
			if (gGame->channel_connection)
				gGame->channel_connection->OnLeaveBalance();
		}

		if (gRender)
			gRender->Update(frameTime);
	}

	void StateBalance::OnInput(InputEventArgs & e)
	{
		if (e.IsKeyEvent())
		{
/*		
			if (e.Type == InputEventArgs::kKeyDown && e.Code == KC_ESCAPE)
			{
				m_totalTime = 2000.f;
				e.Handled = true;
			}
*/
		}
	}

	void StateBalance::AutoPhoto()
	{
		if (!gGame->bSavePhoto)
			gGame->bSavePhoto = true;
	}

	// replay save
	void StateBalance::ReplaySave(String replay_name)
	{
		if (gGame->channel_connection)
			gGame->channel_connection->ReplaySave(replay_name);
	}

	void StateBalance::OnDisconnect()
	{
		if (!gGame->lobby_connection)
		{
			gGame->machine.ChangeState(ptr_new StateLogin);
		}
		else
		{
			gGame->lobby_connection->RestoreToStateLobby();
			tempc_ptr(StateLobby) lobbyState = ptr_static_cast<StateLobby>(gGame->machine.CurrentState());
			if (lobbyState)
			{
				lobbyState->OnLeaveChannel();
			}
			// 			gGame->machine.ChangeState(ptr_new StateLobby);
			// 			tempc_ptr(StateLobby) lobbyState = ptr_static_cast<StateLobby>(gGame->machine.CurrentState());
			// 			if(lobbyState)
			// 			{
			// 				lobbyState->InitUI();
			// 			}
			gGame->guiSys->ShowMessage(gLang->GetTextW(L"������Ϸ�����������ӳ�ʱ�Զ��Ͽ�\n�볢����������"));		}
	}

	void StateBalance::OnRender()
	{
		if (gRender)
			gRender->Draw();
	}

	RoomInfo StateBalance::GetSelfRoomInfo()
	{
		if (gGame->channel_connection)
			return gGame->channel_connection->room_info;

		return RoomInfo();
	}

	// get my client info
	tempc_ptr(ClientInfo) StateBalance::GetMyClientInfo()
	{
		int size = gGame->channel_connection->client_list.Size(); 

		for (int i = 0; i < size; i ++)
		{
			tempc_ptr(ClientInfo) info = gGame->channel_connection->client_list[i];

			if (info->character_id == gGame->channel_connection->character_id)
			{
				return info;
			}

		}

		return NullPtr;
	}
	
	// get level info
	tempc_ptr(LevelInfo) StateBalance::GetLevelInfoById(uint level_id)
	{
		if (gGame->lobby_connection)
		{
			int size = gGame->lobby_connection->level_list.Size();
			for (int i = 0; i < size; i ++)
			{
				tempc_ptr(LevelInfo) level_info = gGame->lobby_connection->level_list[i];
				if (level_info->id == level_id)
				{
					return level_info;
				}
			}
		}
		return NullPtr;
	}

	void StateBalance::Quit()
	{
		m_totalTime = 2000.f;
	}

	void StateBalance::OnAutoStartLeaveBalance()
	{
		EventAutoStartLeaveBalance.Fire(ptr_static_cast<StateBalance>(this), EventArgs());
	}

	// team invite
	void StateBalance::TeamInvite(const Core::String & name)
	{
		if (gGame->lobby_connection)
			gGame->lobby_connection->RequestTeamInvite(name);
	}

	// team join
	void StateBalance::TeamJoin(const Core::String & name, uint uid)
	{
		if (gGame->lobby_connection)
			gGame->lobby_connection->RequestTeamJoin(name, uid);
	}

	// team leave
	void StateBalance::TeamLeave()
	{
		if (gGame->lobby_connection)
			gGame->lobby_connection->RequestTeamLeave();
	}

	// team kick
	void StateBalance::TeamKick(const Core::String & name)
	{
		if (gGame->lobby_connection)
			gGame->lobby_connection->RequestTeamKick(name);
	}

	// team change leader
	void StateBalance::TeamChangeLeader(const Core::String & name)
	{
		if (gGame->lobby_connection)
			gGame->lobby_connection->RequestTeamChangeLeader(name);
	}

	// team refuse
	void StateBalance::TeamRefuse(const Core::String & name, uint uid)
	{
		if (gGame->lobby_connection)
			gGame->lobby_connection->RequestTeamRefuse(name, uid);
	}

	// team call
	void StateBalance::TeamCall(const Core::String & name)
	{
		if (gGame->lobby_connection)
			gGame->lobby_connection->RequestTeamCall(name);
	}

	void StateBalance::TeamRefusePreserve(const Core::String& callerName,uint server_id, uint channel_id, ushort room_id)
	{
		if (gGame->lobby_connection)
			gGame->lobby_connection->RequestRefusePreserve(callerName, server_id, channel_id, room_id, 0);
	}

	void StateBalance::OnResponseTeamInvite( const Core::String& name, int result )
	{
		tempc_ptr(SquadPanel) panel = GetSquadPanel();
		if(panel)
			panel->OnResponseTeamInvite(name, result);
	}

	void StateBalance::OnResponseTeamJoin( const Core::String& name, int result )
	{
		tempc_ptr(SquadPanel) panel = GetSquadPanel();
		if(panel)
			panel->OnResponseTeamJoin(name, result);
	}

	void StateBalance::OnTeamInvite( const Core::String& name, int uid )
	{
		tempc_ptr(SquadPanel) panel = GetSquadPanel();
		if(panel)
			panel->OnTeamInvite(name, uid);
	}

	void StateBalance::OnTeamMemberJoin( const Client::TeamMember& member )
	{
		tempc_ptr(SquadPanel) panel = GetSquadPanel();
		if(panel)
			panel->NewMember(member);
	}

	void StateBalance::OnTeamMemberLeave( const Core::String& name )
	{
		tempc_ptr(SquadPanel) panel = GetSquadPanel();
		if(panel)
			panel->RemoveMember(name);
	}

	void StateBalance::OnTeamChangeLeader( const Core::String& name )
	{
		tempc_ptr(SquadPanel) panel = GetSquadPanel();
		if(panel)
			panel->OnLeaderChanged(name);
	}

	void StateBalance::OnTeamMemberInfo( const Client::TeamMember& member )
	{
		tempc_ptr(SquadPanel) panel = GetSquadPanel();
		if(panel)
			panel->UpdateMember(member);
	}

	void StateBalance::OnTeamLeave()
	{
		tempc_ptr(SquadPanel) panel = GetSquadPanel();
		if(panel)
			panel->OnTeamLeave();
	}

	void StateBalance::OnTeamRoomPreserve(uint server_id, uint channel_id, ushort room_id, byte slot_id, const Core::String& invite_name)
	{
		tempc_ptr(SquadPanel) panel = GetSquadPanel();
		if(panel)
			panel->OnLeaderCall(server_id, channel_id, room_id, invite_name);
	}


	void StateBalance::OnTeamRoomCancelPreserve(uint server_id, uint channel_id, ushort room_id, byte slot_id)
	{
		tempc_ptr(SquadPanel) panel = GetSquadPanel();
		if(panel)
			panel->OnLeaderCancelCall(server_id, channel_id, room_id);
	}
	// on kicked in game
	void StateBalance::OnKickedIdleInGame()
	{
		EventIdleKicked.Fire(ptr_static_cast<StateBalance>(this), EventArgs());
	}
}