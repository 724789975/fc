//#if DEBUG_TOOLS
namespace Client
{
	class StateDebugAnim : public GameState
	{
	public:
		DECLARE_PDE_EVENT(EventLeave,				Core::EventArgs);
		DECLARE_PDE_EVENT(EventLoadCbxCharater,		Core::EventArgs);
	public:
		// constructor
		StateDebugAnim();

		// destructor.
		~StateDebugAnim();

		// on enter
		void OnEnter();

		// on leave
		void OnLeave();

		// on update
		void OnUpdate(float frameTime);

		// on disconnected
		void OnDisconnect();

		// render
		void OnRender();
		
	public:

		void UpdateCharacter(float fTime);

		///-------------for UI------------------start---------------------------
		void SetCharacter(int count, const Core::Identifier & weapon, bool isknife, bool isfirst);

		void SetCharacterCrouch(bool flag);

		void SetWalk(bool flag);

		void SetCharacterShoot(bool multi = false);

		void SetCharacterReload(bool multi = false);

		void SetCharacterStab();
		
		void SetCharacterLightStab();

		void SetCharacterStabHit();

		void SetCharacterLightStabHit();

		void SetDrawJoint(bool flag);

		void SetDrawCharacter(bool flag);

		void SetWireFrame(bool flag);

		void SetDrawPhyicalLine(bool flag);

		void LoadAnimation(const Core::Identifier & group, const Core::Identifier & ani);

		void InitModel();
		///-------------for UI-------------------end----------------------------

	private:
		void AddWeaponPart(const Core::Identifier & part);
		sharedc_ptr(WeaponInfo) SetWeaponType(WeaponType type);
		void OnUpdateInput(float frameTime);

		///render
		bool RestoreState();
		void DrawGround();

	private:
		sharedc_ptr(Shader)			Debug_VS;
		sharedc_ptr(Shader)			Debug_PS;
		Core::String				weapon_key;
		int							avatar;
		bool						isLoad;
	public:
		sharedc_ptr(CharacterInfo)	character_info;
		sharedc_ptr(WeaponInfo)		weapon_info;

		Core::Vector4 m_SunDirection;
		Core::Vector4 m_FogPara;
		Core::Vector4 m_FogColor;
		Core::Vector4 m_YFogPara;
		Core::Vector4 m_YFogColor;
		Core::Vector4 m_Intensity;

		/// for render ground
		///-------ground block count------------
		int blockSize;
		Core::Array<Core::Vector3>	vertices;
		sharedc_ptr(GunBase) gunbase;
		/// animation status
		/// character status
		bool isfirst				:1;
		bool IsDrawJoint			:1;
		bool IsDrawPhyicalLine		:1;
		bool IsWalk					:1;
		bool IsDrawCharacter		:1;
		bool IsWireFrame			:1;
		bool Isknife				:1;
		bool IsCrouch				:1;

		Core::Vector3 consultpoint;
	};
}

//#endif