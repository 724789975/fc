namespace Client
{
	class StateMachine;


	// state for the state machine.
	class GameState : public Core::Object
	{
	public:
		// constructor.
		GameState() : owner(NULL), handled(false) {}

		// destructor.
		virtual ~GameState() {}

	public:
		// enter state
		virtual void OnEnter() {}

		// update
		virtual void OnUpdate(float frameTime) {}

		// timestepupdate
		virtual void OnTimeStepUpdate(float frameTime) {}

		// render
		virtual void OnRender() {}

		// leave state
		virtual void OnLeave() {}

		// net closed
		virtual void OnDisconnect() {}

		// input
		virtual void OnInput(InputEventArgs & e) {}

		// chat
		virtual void OnChat(ChatMessage & msg) {}

		// fcm
		virtual void OnFCM(int online_minutes, const char * message) {}

		/// team operations
		// team invite
		virtual void TeamInvite(const Core::String & name) {}

		// team join
		virtual void TeamJoin(const Core::String & name, uint uid) {}

		// team leave
		virtual void TeamLeave() {}

		// team kick
		virtual void TeamKick(const Core::String & name) {}

		// team change leader
		virtual void TeamChangeLeader(const Core::String & name) {}

		// team refuse
		virtual void TeamRefuse(const Core::String & name, uint uid) {}

		// team refuse to enter leader's room
		virtual void TeamRefusePreserve(const Core::String& callerName, uint server_id, uint channel_id, ushort room_id) {}

		// team call
		virtual void TeamCall(const Core::String & name) {}

		// group create
		virtual void GroupCreate() {}

		// group invite
		virtual void GroupInvite(const Core::String & name, uint uid) {}

		//group join
		virtual void GroupJoin(uint uid) {}

		// group leave
		virtual void GroupLeave(uint uid) {}

		// Get group member
		virtual void GetGroupMember(uint uid) {}

		// received a team invite
		virtual void OnTeamInvite(const Core::String& name, int uid) {}

		// response inviting someone
		virtual void OnResponseTeamInvite(const Core::String& name, int result) {}

		// response joining a team
		virtual void OnResponseTeamJoin(const Core::String& name, int result) {}

		// notify team member join
		virtual void OnTeamMemberJoin(const Client::TeamMember& member) {}

		// notify team member leave
		virtual void OnTeamMemberLeave(const Core::String& name) {}

		// notify team change leader
		virtual void OnTeamChangeLeader(const Core::String& name) {}

		// notify team member info
		virtual void OnTeamMemberInfo(const Client::TeamMember& member) {}

		// notify team change leader
		virtual void OnTeamLeave() {}

		virtual void OnTeamRoomPreserve(uint server_id, uint channel_id, ushort room_id, byte slot_id, const Core::String& invite_name) {}

		virtual void OnTeamRoomCancelPreserve(uint server_id, uint channel_id, ushort room_id, byte slot_id) {}

	public:
		StateMachine * owner;
		bool handled;
	};


	// state machine, managing states.
	class StateMachine
	{
	public:
		void ChangeState(by_ptr(GameState) new_state)
		{
			
			if (new_state != current_state)
			{
				if (current_state)
					current_state->OnLeave();

				current_state = new_state;

				if (current_state)
				{
					current_state->owner = this;
					current_state->OnEnter();
				}
			}
		}

		void Update(float frameTime)
		{
			if (current_state)
				current_state->OnUpdate(frameTime);
		}

		void TimeStepUpdate(float frameTime)
		{
			if (current_state)
				current_state->OnTimeStepUpdate(frameTime);
		}

		void Render()
		{
			if (current_state)
				current_state->OnRender();
		}

		void OnDisconnect()
		{
			if (current_state)
				current_state->OnDisconnect();
		}

		void OnInput(InputEventArgs & e)
		{
			if (current_state)
				current_state->OnInput(e);
		}

		void OnChat(ChatMessage & msg)
		{
			if (current_state)
				current_state->OnChat(msg);
		}

		// fcm
		void OnFCM(int online_minutes, const char * message)
		{
			if (current_state)
				current_state->OnFCM(online_minutes, message);
		}

		// response inviting someone
		void OnResponseTeamInvite(const Core::String& name, int result)
		{
			if(current_state)
				current_state->OnResponseTeamInvite(name, result);
		}

		// response joining a team
		void OnResponseTeamJoin(const Core::String& name, int result)
		{
			if(current_state)
				current_state->OnResponseTeamJoin(name, result);
		}


		// received a team invite
		void OnTeamInvite(const Core::String& name, int uid)
		{
			if (current_state)
				current_state->OnTeamInvite(name, uid);
		}

		// notify team member join
		void OnTeamMemberJoin(const Client::TeamMember& member)
		{
			if (current_state)
				current_state->OnTeamMemberJoin(member);
		}

		// notify team member leave
		void OnTeamMemberLeave(const Core::String& name)
		{
			if (current_state)
				current_state->OnTeamMemberLeave(name);
		}

		// notify team change leader
		void OnTeamChangeLeader(const Core::String& name)
		{
			if (current_state)
				current_state->OnTeamChangeLeader(name);
		}

		// notify team member info
		void OnTeamMemberInfo(const Client::TeamMember& member)
		{
			if (current_state)
				current_state->OnTeamMemberInfo(member);
		}

		// notify team change leader
		void OnTeamLeave()
		{
			if (current_state)
				current_state->OnTeamLeave();
		}

		tempc_ptr(GameState) CurrentState()
		{
			return current_state;
		}

	private:
		sharedc_ptr(GameState) current_state;
	};
}