namespace Client
{
	class StateMovie : public GameState
	{
	public:
		// constructor
		StateMovie();
		~StateMovie();

		// on enter
		void OnEnter();

		// on leave
		void OnLeave();

		// on update
		void OnUpdate(float frameTime);

		// on input
		void OnInput(InputEventArgs & e);

		// render
		void OnRender();

		//fixed dshow block
		void UpdateRenderTarget();

	private:
		void* m_pTextureVideoManager;
		Client::RenderTarget m_tempRenderTarget;

		Core::String m_strShandaMovie;
		Core::String m_strPDEMovie;
		Core::String m_strGameMovie;

		int m_nCurentMovie;
	};
}