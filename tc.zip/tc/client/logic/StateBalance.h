namespace Client
{
	class StateBalance : public GameState
	{
	public:
		DECLARE_PDE_EVENT(EventLeave,			Core::EventArgs);
		DECLARE_PDE_EVENT(EventSavePhoto,		Core::EventArgs);
		DECLARE_PDE_EVENT(EventIdleKicked,		Core::EventArgs);
		DECLARE_PDE_EVENT(EventAutoStartLeaveBalance,		Core::EventArgs);
		DECLARE_PDE_ATTRIBUTE_R(SquadPanel,		tempc_ptr(Gui::SquadPanel));
		DECLARE_PDE_ATTRIBUTE_R(StageClear,		bool);

	public:
		// constructor
		StateBalance(bool cleared);

		// on enter
		void OnEnter();

		// on leave
		void OnLeave();

		// on update
		void OnUpdate(float frameTime);

		// on input
		void OnInput(InputEventArgs & e);

		// on disconnected
		void OnDisconnect();

		// render
		void OnRender();

		// quit
		void Quit();

		void OnAutoStartLeaveBalance();


		void OnKickedIdleInGame();
		// team invite
		virtual void TeamInvite(const Core::String & name);

		// team join
		virtual void TeamJoin(const Core::String & name, uint uid);

		// team leave
		virtual void TeamLeave();

		// team kick
		virtual void TeamKick(const Core::String & name);

		// team change leader
		virtual void TeamChangeLeader(const Core::String & name);

		// team refuse
		virtual void TeamRefuse(const Core::String & name, uint uid);

		// team call
		virtual void TeamCall(const Core::String & name);

		// team refuse to enter leader's room
		virtual void TeamRefusePreserve(const Core::String& callerName,uint server_id, uint channel_id, ushort room_id);

		// received a team invite
		virtual void OnTeamInvite(const Core::String& name, int uid);

		// response inviting someone
		virtual void OnResponseTeamInvite(const Core::String& name, int result);

		// response joining a team
		virtual void OnResponseTeamJoin(const Core::String& name, int result);

		// notify team member join
		virtual void OnTeamMemberJoin(const Client::TeamMember& member);

		// notify team member leave
		virtual void OnTeamMemberLeave(const Core::String& name);

		// notify team change leader
		virtual void OnTeamChangeLeader(const Core::String& name);

		// notify team member info
		virtual void OnTeamMemberInfo(const Client::TeamMember& member);

		// notify team change leader
		virtual void OnTeamLeave();

		virtual void OnTeamRoomPreserve(uint server_id, uint channel_id, ushort room_id, byte slot_id, const Core::String& invite_name);

		virtual void OnTeamRoomCancelPreserve(uint server_id, uint channel_id, ushort room_id, byte slot_id);
		
		// get level info
		tempc_ptr(LevelInfo) GetLevelInfoById(uint level_id);

		void ReplaySave(Core::String replay_name);

	public:
		RoomInfo GetSelfRoomInfo();
		void AutoPhoto();
		// get my client info
		tempc_ptr(ClientInfo) GetMyClientInfo();

	protected:
		F32		m_totalTime;
		//sharedc_ptr(Character) preview_character;
		bool	m_StageClear;
	};
}