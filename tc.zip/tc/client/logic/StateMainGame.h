namespace Client
{
	struct EventShowPerson : public Core::EventArgs
	{
		EventShowPerson(const Core::String & name)
		{
			person_name = name;
		}
		Core::String person_name;
	};

	struct EventCanKickNum : public Core::EventArgs
	{
		EventCanKickNum(int c)
		{
			count = c;
		}
		int count;
	};

	struct EventSpecial : public Core::EventArgs
	{
		EventSpecial(int c)
		{
			count = c;
		}
		int count;
	};

	struct EventAddSelectPerson : public Core::EventArgs
	{
		EventAddSelectPerson(const Core::String & key,const Core::String & textname)
		{
			key_name = key;
			text_name = textname;
		}
		Core::String key_name;
		Core::String text_name;
	};

	struct EventKickError : public Core::EventArgs
	{
		EventKickError(int error)
		{
			error_id = error;
		}
		int error_id;
	};

	class StateMainGame : public GameState
	{
	public:
		DECLARE_PDE_EVENT(EventLeave,			Core::EventArgs);

		
		DECLARE_PDE_EVENT(EventChooseCharacter,	Core::EventArgs);
		DECLARE_PDE_EVENT(EventCloseCharacter,	Core::EventArgs);
		DECLARE_PDE_EVENT(EventAddSelect,			EventAddSelectPerson);

		DECLARE_PDE_EVENT(EventAddSelectKickPerson,	EventShowPerson);
		DECLARE_PDE_EVENT(EventCanKick,				EventCanKickNum);
		DECLARE_PDE_EVENT(EventAddSelectReportPerson,	EventShowPerson);
		DECLARE_PDE_EVENT(EventClearSelectKickPerson, Core::EventArgs);
		DECLARE_PDE_EVENT(KickPersonError, EventKickError);
		DECLARE_PDE_EVENT(EventSavePhoto, Core::EventArgs);
		DECLARE_PDE_EVENT(EventCantSelectPerson, EventSpecial);

	public:
		INLINE_PDE_ATTRIBUTE_RW(EscHasFocus,	bool);
		INLINE_PDE_ATTRIBUTE_RW(SelectHasFocus,	bool);
		INLINE_PDE_ATTRIBUTE_RW(TeamIndex,		int)
		INLINE_PDE_ATTRIBUTE_RW(SelectName,		Core::String);
		INLINE_PDE_ATTRIBUTE_RW(KickReason,		int);
		INLINE_PDE_ATTRIBUTE_RW(KickName,		Core::String);

		INLINE_PDE_ATTRIBUTE_RW(IsCanCancel,	bool);
		INLINE_PDE_ATTRIBUTE_RW(IsWatch,		bool);
		INLINE_PDE_ATTRIBUTE_RW(IsReplay,		bool);
		INLINE_PDE_ATTRIBUTE_RW(IsEditMode,		bool);
		

	public:
		// constructor.
		StateMainGame();

		// on create
		void OnCreate();

		// enter state
		void OnEnter();

		// leave state
		void OnLeave();

		// on input
		void OnInput(InputEventArgs & e);

		// update
		void OnUpdate(float frameTime);

		// timestepupdate
		void OnTimeStepUpdate(float frameTime);

		// debugupdate
		void OnDebugUpdate(float frameTime);

		// render
		void OnRender();

		// disconnected
		void OnDisconnect();

		// on chat
		void OnChat(ChatMessage & msg);

		// fcm
		void OnFCM(int online_minutes, const char * message);

		// set 
		void SetCharacterFromID();

		// for edit mode
		int GetTowerTypeCount();

		int GetDummyObjectCount(int type, const Core::String& szRes);

		int GetMaxWallCount();

		int GetMaxGuardCount();

		int GetDummyObjectCountBySubType(int type);

		void DestroyAllDummyObject();

		GunTowerTypeInfo GetTowerType(int iIdx);

		void SetActiveTower(const int iIdx);

		// kick person
		void ShowKickPerson(int type = 0);

		// kick person
		void KickPerson();

		bool CanSelectPerson();

#if DEBUG_CMD
		//set debug mode
		void SetDebugMode(bool bEnable);

		//debug cmd
		void DebugCmd(Core::String cmd);

		//debug
		void DisableStaticCollision(bool bEnable);

		//debug
		void EnableNoclip(bool bEnable);

		//debug
		void EnableWalk(bool bEnable);

		//debug
		void SetNoclipSpeed(float speed);

		//debug
		void FocusHurtRate(bool bEnable, float rate);

		//debug
		void SetFireTime(bool auto_fire, float fire_time);

		//debug
		void SetAmmoFlySpeed(float fly_speed);

		//debug
		void SetAmmoFlyTime(float fly_time);

		//debug
		void SetPjtAmmoCntrol(bool bEnable);

		//debug
		void SetDrawAllVisible(bool bEnable);

		//debug
		void ShowCharacterEffect(Core::String name);

		//debug
		void BarbetteView(Core::String c_name, Core::String b_name);

		//debug
		void Teleport(float x, float y, float z);

		//debug
		void SetMessageClientFlag(bool flag);
#endif

	public:
		// is ui focused
		bool IsUIFocused();

		void SaveMap();

		// quit
		void Quit();

		int HttpXLInfo(const Core::String& bugtitle, const Core::String& bugdesc, const Core::String& qq, const Core::String& phone, int type);

		int HttpXLReport(const Core::String& report_character_name, int report_type, const Core::String& report_desc);

	public:
		sharedc_ptr(InGameUINew) ui;

		SIMPLE_PDE_ATTRIBUTE_RW(EditorOn, bool)

#if DEBUG_CMD
		bool m_DebugMode;
		byte m_DebugCharacterUid;
#endif

	private:
		bool			m_EscHasFocus;
		bool			m_SelectHasFocus;
		int				m_TeamIndex;
		bool			m_IsNeedReadyforGame;
		Core::String	m_SelectName;
		int				m_KickReason;
		Core::String	m_KickName;
		
		bool            m_IsCanCancel;
		uint			m_CharacterIndex;
		Core::HashSet<Core::String, uint> select_from_string;
		bool			m_IsWatch;
		bool			m_IsReplay;
		bool			m_IsEditMode;

	public:
		float			noinput_limittime;
		bool			quit_game;
	};
}