#include "pch.h"
#include "../system/TextureVideo.h"
using namespace Client;

// constructor
StateMovie::StateMovie()
: m_pTextureVideoManager(NULL)
, m_strShandaMovie("movie\\snda_logo.wmv")
, m_strPDEMovie("movie\\pde_logo.avi")
, m_strGameMovie("movie\\game_logo.wmv")
, m_nCurentMovie(0)
{
}

StateMovie::~StateMovie()
{
	if (m_pTextureVideoManager)
	{
		TextureVideoManager* p = reinterpret_cast<TextureVideoManager*>(m_pTextureVideoManager);
		delete p;
		p = NULL;
		m_pTextureVideoManager = NULL;
	}
}

// on enter
void StateMovie::OnEnter()
{
	if (gRender)
		gRender->SetGameState(D3DRender::kMovieEnter);

	m_pTextureVideoManager = new TextureVideoManager;

	reinterpret_cast<TextureVideoManager*>(m_pTextureVideoManager)->PlayMovie(m_strShandaMovie);

	m_tempRenderTarget.CreateRenderTarget(1, 1, D3DFMT_A32B32G32R32F, D3DMULTISAMPLE_NONE, true);
	m_tempRenderTarget.CreateDepthStencil(D3DFMT_D24S8, true);
}

// on leave
void StateMovie::OnLeave()
{
	if (gRender)
		gRender->SetGameState(D3DRender::kMovieLeave);

	if (m_pTextureVideoManager)
	{
		TextureVideoManager* p = reinterpret_cast<TextureVideoManager*>(m_pTextureVideoManager);
		delete p;
		p = NULL;
		m_pTextureVideoManager = NULL;
	}
}

// on update
void StateMovie::OnUpdate(float frameTime)
{
	if (reinterpret_cast<TextureVideoManager*>(m_pTextureVideoManager)->IsPlayOver())
	{
		++m_nCurentMovie;

		switch(m_nCurentMovie)
		{
		case 0:
			{
				reinterpret_cast<TextureVideoManager*>(m_pTextureVideoManager)->PlayMovie(m_strShandaMovie);
			}
			break;

		case 1:
			{
				reinterpret_cast<TextureVideoManager*>(m_pTextureVideoManager)->PlayMovie(m_strPDEMovie);
			}
			break;

		case 2:
			{
				reinterpret_cast<TextureVideoManager*>(m_pTextureVideoManager)->PlayMovie(m_strGameMovie);
			}
		}
	}

	if (m_nCurentMovie > 2)
	{
		gGame->machine.ChangeState(ptr_new StateLogin);
	}
}

// on input
void StateMovie::OnInput(InputEventArgs & e)
{
	if (e.IsKeyEvent())
	{
		if (e.Type == InputEventArgs::kKeyDown)
		{
			switch (e.Code)
			{
			case KC_ESCAPE:
				{
					if (m_nCurentMovie > 1)
					{
						gGame->machine.ChangeState(ptr_new StateLogin);
					}
				}
				break;
			}
		}
	}
}

// render
void StateMovie::OnRender()
{
	UpdateRenderTarget();

	if (!gRender)
		return;
	
	gRender->Draw();

	//draw cross hair
	if (gRender->ui_render->BeginDraw(gGame->dx9->render_target))
	{
		Core::Matrix44 view;
		Core::Matrix44 world;
		Core::Vector3 rt_size = gGame->guiSys->GetSize();

		view.SetScaleXYZ(2.0f / rt_size.x, -2.0f / rt_size.y, 0);
		view.TranslateXYZ(-1, 1, 0);
		view.TranslateLocalXYZ(-0.5f, -0.5f, 0);

		float imageWidth = reinterpret_cast<TextureVideoManager*>(m_pTextureVideoManager)->GetVideoWidth();
		float imageHeight = reinterpret_cast<TextureVideoManager*>(m_pTextureVideoManager)->GetVideoHeight();

		Core::Vector2 vScreen = gGame->screen->GetSize();

		float topLeftX = 0;
		float topLeftY = 0;
		float bottomRightX = 0;
		float bottomRightY = 0;

		int tempH = imageHeight * rt_size.x / imageWidth;
		int tempW = rt_size.x * imageHeight / rt_size.y;

		if(m_nCurentMovie < 2)
		{
			if (imageWidth >= vScreen.x && imageHeight >= vScreen.y)
			{
				tempW = imageWidth * rt_size.y / vScreen.y;
				topLeftX = (rt_size.x - tempW) / 2;
				bottomRightX = rt_size.x - topLeftX;

				tempH = imageHeight * rt_size.y / vScreen.y;

				topLeftY = (rt_size.y - tempH) / 2;
				bottomRightY = rt_size.y - topLeftY;
			}
			else if(imageWidth >= vScreen.x && imageHeight <= vScreen.y)
			{
				tempW = rt_size.y * imageWidth / imageHeight;
				topLeftX = (rt_size.x - tempW) / 2;
				bottomRightX = rt_size.x - topLeftX;
				topLeftY = 0;
				bottomRightY = rt_size.y;
			}
			else if (imageWidth <= vScreen.x && imageHeight >= vScreen.y)
			{
				topLeftX = 0;
				bottomRightX = rt_size.x;
				tempH = rt_size.x * imageHeight / imageWidth;
				topLeftY = (rt_size.y - tempH) / 2;
				bottomRightY = rt_size.y - topLeftY;
			}
			else if(imageWidth <= vScreen.x && imageHeight <= vScreen.y)
			{
				if (imageHeight / imageWidth > rt_size.y / rt_size.x)
				{
					topLeftX = 0;
					bottomRightX = rt_size.x;
					tempH = imageHeight * rt_size.x / imageWidth;
					topLeftY = (rt_size.y - tempH) / 2;
					bottomRightY = rt_size.y - topLeftY;
				}
				else
				{
					topLeftY = 0;
					bottomRightY = rt_size.y;
					tempW = imageWidth * rt_size.y / imageHeight;
					topLeftX = (rt_size.x - tempW) / 2;
					bottomRightX = rt_size.x - topLeftX;
				}
			}
		}
		else
		{
			if (tempH > rt_size.y)
			{
				topLeftY = 0;
				bottomRightY = rt_size.y;
				topLeftX = (rt_size.x - imageWidth * rt_size.y / imageHeight) / 2;
				bottomRightX = rt_size.x - topLeftX;
			}
			else
			{
				topLeftX = 0;
				bottomRightX = rt_size.x;
				topLeftY = (rt_size.y - tempH) / 2;
				bottomRightY = rt_size.y - topLeftY;
			}
		}

		gGame->render->ui_render->SetWorld(Core::Matrix44::kIdentity);
		gGame->render->ui_render->SetView(view);
		gGame->render->ui_render->SetProjection(Core::Matrix44::kIdentity);

		gGame->render->ui_render->DrawRectangle(Core::Rectangle(0, 0, rt_size.x, rt_size.y), Core::Rectangle(0, 0, 1, 1), Core::ARGB(255.0f, 0, 0, 0));

		if (m_pTextureVideoManager)
		{
			if (reinterpret_cast<TextureVideoManager*>(m_pTextureVideoManager)->m_pTextureVideo)
			{
				if (!reinterpret_cast<TextureVideoManager*>(m_pTextureVideoManager)->IsDShowTextureReady())
				{
					gGame->render->ui_render->DrawRectangle(Core::Rectangle(topLeftX, topLeftY, bottomRightX, bottomRightY), Core::Rectangle(0, 0, 1, 1), Core::ARGB(255.0f, 0, 0, 0));
				}
				else
				{
					gGame->render->ui_render->SetTexture(reinterpret_cast<TextureVideoManager*>(m_pTextureVideoManager)->GetTexture2D());
					gGame->render->ui_render->DrawRectangle(Core::Rectangle(topLeftX, topLeftY, bottomRightX, bottomRightY), Core::Rectangle(0, 0, 1, 1), Core::ARGB(255.0f, 255, 255, 255));
				}
			}
		}
		gRender->ui_render->EndDraw();
	}
}

//fixed dshow block
void StateMovie::UpdateRenderTarget()
{
	D3DLOCKED_RECT lc;

	if (!m_tempRenderTarget.GetSurface())
	{
		return;
	}
	if (SUCCEEDED(m_tempRenderTarget.GetSurface()->LockRect(&lc, NULL, 0)))
	{
		m_tempRenderTarget.GetSurface()->UnlockRect();
	}
}