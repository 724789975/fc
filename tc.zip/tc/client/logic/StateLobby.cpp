#include "pch.h"

using namespace Core;
using namespace Client;
using namespace Gui;

DEFINE_PDE_TYPE_CLASS(Client::RetEventArgs)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(EventArgs);
		ADD_PDE_FIELD(Ret);
	}
};
DEFINE_PDE_TYPE_CLASS(Client::CmdEventArgs)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(EventArgs);
		ADD_PDE_FIELD(Details);
	}
};
DEFINE_PDE_TYPE_CLASS(Client::AddressEventArgs)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(EventArgs);
		ADD_PDE_FIELD(userdata);
		ADD_PDE_FIELD(name);
		ADD_PDE_FIELD(online);
		ADD_PDE_FIELD(address);
	}
};

// ƥ�� 
DEFINE_PDE_TYPE_CLASS(Client::AddmatchEvenArgs)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(EventArgs);
		ADD_PDE_FIELD(match_id);
		ADD_PDE_FIELD(match_name);
	}
};

DEFINE_PDE_TYPE_CLASS(Client::TepGroupEventArgs)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(EventArgs);
		ADD_PDE_FIELD(Group_id);
		ADD_PDE_FIELD(name);
		ADD_PDE_FIELD(Groupname);
	}
};

DEFINE_PDE_TYPE_CLASS(Client::ForceExitEventArgs)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(EventArgs);
		ADD_PDE_FIELD(exit_id);
	}
};

DEFINE_PDE_TYPE_CLASS(Client::BattleChangeRoom)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(EventArgs);
		ADD_PDE_FIELD(change_room);
		ADD_PDE_FIELD(server_id);
		ADD_PDE_FIELD(channel_id);
		ADD_PDE_FIELD(room_id);
		ADD_PDE_FIELD(is_challenge);
		ADD_PDE_FIELD(team1);
		ADD_PDE_FIELD(team2);
	}
};

DEFINE_PDE_TYPE_CLASS(Client::InviteChangeRoom)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(EventArgs);
		ADD_PDE_FIELD(group_id);
		ADD_PDE_FIELD(server_id);
		ADD_PDE_FIELD(channel_id);
		ADD_PDE_FIELD(room_id);
	}
};

DEFINE_PDE_TYPE_CLASS(Client::TepGroupMemberEventArgs)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(EventArgs);
		ADD_PDE_FIELD(Group_id);
		ADD_PDE_FIELD(num_which);
		ADD_PDE_FIELD(MemberName);
		ADD_PDE_FIELD(MemberName_id);
		ADD_PDE_FIELD(MemberName_vip);
		ADD_PDE_FIELD(MemberName_business_card);
		ADD_PDE_FIELD(MemberName_net_bar_level);
	}
};
DEFINE_PDE_TYPE_CLASS(Client::RetEventArgs3)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(EventArgs);
		ADD_PDE_FIELD(a);
		ADD_PDE_FIELD(b);
		ADD_PDE_FIELD(c);
	}
};

REGISTER_PDE_TYPE(Client::RetEventArgs);
REGISTER_PDE_TYPE(Client::CmdEventArgs);
REGISTER_PDE_TYPE(Client::AddressEventArgs);
REGISTER_PDE_TYPE(Client::AddmatchEvenArgs);
REGISTER_PDE_TYPE(Client::TepGroupEventArgs);
REGISTER_PDE_TYPE(Client::ForceExitEventArgs);
REGISTER_PDE_TYPE(Client::TepGroupMemberEventArgs);
REGISTER_PDE_TYPE(Client::RetEventArgs3);
REGISTER_PDE_TYPE(Client::BattleChangeRoom);
REGISTER_PDE_TYPE(Client::InviteChangeRoom);

DEFINE_PDE_TYPE_CLASS(Client::StateLobby::IRoomListCompareFunc)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::ListTreeView::SortFunc);
	}
};
DEFINE_PDE_TYPE_CLASS(Client::StateLobby::IChannelListCompareFunc)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::ListTreeView::SortFunc);
	}
};
DEFINE_PDE_TYPE_CLASS(Client::StateLobby::IServerListCompareFunc)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(Gui::ListTreeView::SortFunc);
	}
};

DEFINE_PDE_TYPE_CLASS(ServerInfo)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_FIELD(id);
		ADD_PDE_FIELD(name);
		ADD_PDE_FIELD(online_count);
		ADD_PDE_FIELD(online_max);
		ADD_PDE_FIELD(isnovice);
		ADD_PDE_FIELD(gametype_limit);
		ADD_PDE_FIELD(Channelcount);

		ADD_PDE_FIELD(servertype );
		ADD_PDE_FIELD(nMinLevel);
		ADD_PDE_FIELD(nMaxLevel);
	}
};

DEFINE_PDE_TYPE_CLASS(ChannelInfo)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_FIELD(id);
		ADD_PDE_FIELD(name);
		ADD_PDE_FIELD(online);
		ADD_PDE_FIELD(online_count);
		ADD_PDE_FIELD(online_max);
		ADD_PDE_FIELD(min_level);
		ADD_PDE_FIELD(max_level);
	}
};

DEFINE_PDE_TYPE_CLASS(BattlePlayerInfo)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_FIELD(battlegroup_id);
		ADD_PDE_FIELD(battle_server_id);
		ADD_PDE_FIELD(battle_channel_id);
		ADD_PDE_FIELD(roomoption);
		ADD_PDE_FIELD(ownerclient_uid);
		ADD_PDE_FIELD(group_level);
		ADD_PDE_FIELD(group_name);
		ADD_PDE_FIELD(client_size);
		ADD_PDE_FIELD(vs_group_name);
		ADD_PDE_FIELD(group_id);
	}
};

DEFINE_PDE_TYPE_CLASS(BattleOtherPlayerInfo)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_FIELD(client_uid);
		ADD_PDE_FIELD(character_name);
		ADD_PDE_FIELD(head_icon);
		ADD_PDE_FIELD(character_level);
		ADD_PDE_FIELD(character_exp);
		ADD_PDE_FIELD(is_vip);
		ADD_PDE_FIELD(net_bar_level);
		ADD_PDE_FIELD(business_card);
		ADD_PDE_FIELD(is_gm);
		ADD_PDE_FIELD(is_ready);
	}
};


DEFINE_PDE_TYPE_CLASS(StateLobby)
{
	void OnRegister(by_ptr(PdeTypeInfo) type)
	{
		ADD_PDE_SUPER(GameState);

		ADD_PDE_EVENT(EventOnQuitInGame);
		ADD_PDE_EVENT(EventOnNeedFCMNotified);
		ADD_PDE_EVENT(EventOnDisconnected);
		ADD_PDE_EVENT(EventLeave);
		ADD_PDE_EVENT(EventAddressChanged);
		ADD_PDE_EVENT(EventEnterRoomSuccess);
		ADD_PDE_EVENT(EventCreateRoomFailed);
		ADD_PDE_EVENT(EventEnterRoomFailed);
		ADD_PDE_EVENT(EventInRoomChangeTeamSuccess);
		ADD_PDE_EVENT(EventRoomListChanged);
		ADD_PDE_EVENT(EventUpdateNovice);
		ADD_PDE_EVENT(EventRoomClientListChanged);
		ADD_PDE_EVENT(EventRoomAutoStart);
		ADD_PDE_EVENT(EventRoomAutoStartCancel);
		ADD_PDE_EVENT(EventRoomOptionChanged);
		ADD_PDE_EVENT(EventRoomOptionChangedFailed);
		ADD_PDE_EVENT(EventRoomSlotChanged);
		ADD_PDE_EVENT(EventInitUI);
		ADD_PDE_EVENT(EventRestoreUI);
		ADD_PDE_EVENT(EventUpdateLevelList1);
		ADD_PDE_EVENT(EventUpdateServerList);
		ADD_PDE_EVENT(EventUpdateChannelList);
		ADD_PDE_EVENT(EventKickedInRoom);
		ADD_PDE_EVENT(EventServerCmd);

		ADD_PDE_EVENT(EventGameBegin);
		ADD_PDE_EVENT(EventGameReady);
		
		ADD_PDE_EVENT(EventEnterServer);
		ADD_PDE_EVENT(EventEnterChannel);
		ADD_PDE_EVENT(EventCancelChannel);
		ADD_PDE_EVENT(EventLeaveServer);

		ADD_PDE_EVENT(EventSearchRoom);

		ADD_PDE_EVENT(EventLeaveRoom);

		ADD_PDE_EVENT(EventAddressArrived);
		ADD_PDE_EVENT(EventMatchRoom);
		ADD_PDE_EVENT(EventChannelClientListChanged);
		ADD_PDE_EVENT(EventCreatGroup);
		ADD_PDE_EVENT(EventInviteGroup);
		ADD_PDE_EVENT(EventGetGroupMember);
		ADD_PDE_EVENT(EventChannelEnter);
		ADD_PDE_EVENT(EventChannelLeave);
		ADD_PDE_EVENT(EventForcelLeave);
		
		ADD_PDE_EVENT(EventFocusLost);

		ADD_PDE_EVENT(EventQueryExpiredItem);
		ADD_PDE_EVENT(EventSavePhoto);
		ADD_PDE_EVENT(EventNeedAutoPassword);
		ADD_PDE_EVENT(EventIdleKicked);
		ADD_PDE_EVENT(EventBattleRoomChange);
		ADD_PDE_EVENT(EventSaveZhihuisuo);
		ADD_PDE_EVENT(EventFillZhihuisuo);
		ADD_PDE_EVENT(EventSaveTiaoZhan);
		ADD_PDE_EVENT(EventFillTiaoZhan);
		ADD_PDE_EVENT(EventBattleGroupSearching);

		ADD_PDE_EVENT(EventCancelMatch);
		ADD_PDE_EVENT(EventMatch);
		ADD_PDE_EVENT(EventBattleGroupGameStart);
		ADD_PDE_EVENT(NotifyBattleGroupInvite);
		ADD_PDE_EVENT(NotifyBattleGroupKick);
		ADD_PDE_EVENT(EnterFightRoomSuccess);
		ADD_PDE_EVENT(EnterFightRoomError);
		ADD_PDE_EVENT(EventFCM_MAX);
		ADD_PDE_EVENT(EnterFightCreatrRoomSuccess);
		ADD_PDE_EVENT(EnterSourceRoomError);
		ADD_PDE_PROPERTY_R(ChatWindow);
		ADD_PDE_PROPERTY_R(SysMsgBar);
		ADD_PDE_PROPERTY_R(SquadPanel);
		ADD_PDE_PROPERTY_R(LobbyPList);
		ADD_PDE_PROPERTY_R(AmILeader);
		ADD_PDE_PROPERTY_W(AutoPassword);
		ADD_PDE_PROPERTY_RW(Is_Need_Train);
		ADD_PDE_PROPERTY_RW(Is_in_invite);
		ADD_PDE_PROPERTY_RW(Is_in_invite1);
		ADD_PDE_PROPERTY_RW(Is_Novice_Game);
		ADD_PDE_PROPERTY_RW(Today_Check);
		ADD_PDE_PROPERTY_RW(b_player_info);
		ADD_PDE_PROPERTY_RW(battle_room);
		ADD_PDE_PROPERTY_RW(fcm_flag);
		ADD_PDE_PROPERTY_R(need_fcm_notified);
		ADD_PDE_PROPERTY_R(fcm_online_time);
		ADD_PDE_PROPERTY_R(autostarttime);
		ADD_PDE_PROPERTY_RW(last_channel_id);
		ADD_PDE_PROPERTY_RW(channl_list_total_count);
		ADD_PDE_PROPERTY_RW(channl_list_start);
		ADD_PDE_PROPERTY_RW(is_fight_team_server);
		ADD_PDE_PROPERTY_RW(zhihuisuo_num);
		ADD_PDE_PROPERTY_RW(battle_is_create);
		ADD_PDE_PROPERTY_RW(source_is_create);
     
		ADD_PDE_METHOD(AutoChangeRoom);
		ADD_PDE_METHOD(AutoChangeRoomWithPassword);
		ADD_PDE_METHOD(AutoPhoto);
		ADD_PDE_METHOD(CancelAutoChange);
		ADD_PDE_METHOD(IsAutoChanging);
		ADD_PDE_METHOD(ContinueAutoEnterRoom);

		ADD_PDE_METHOD(ConnectChannel);
		ADD_PDE_METHOD(LeaveChannel);

		ADD_PDE_METHOD(CreateRoom);
		ADD_PDE_METHOD(CreateRoomTest);
		ADD_PDE_METHOD(EnterRoom);
		ADD_PDE_METHOD(LeaveRoom);
		ADD_PDE_METHOD(GetRoomCount);
		ADD_PDE_METHOD(GetRoomInfo);
		ADD_PDE_METHOD(GetRoomInfoById);

		ADD_PDE_METHOD(GetUserId);
		ADD_PDE_METHOD(GetCharacterId);
		ADD_PDE_METHOD(GetCharacterName);
		ADD_PDE_METHOD(GetCharacterGender);

		ADD_PDE_METHOD(GetSelfRoomInfo);
		ADD_PDE_METHOD(RoomChangeOption);
		ADD_PDE_METHOD(RoomKickClient);
		ADD_PDE_METHOD(GetClientCount);
		ADD_PDE_METHOD(GetClientInfo);
		ADD_PDE_METHOD(GetMyClientInfo);
		ADD_PDE_METHOD(GetLevelCount);
		ADD_PDE_METHOD(GetLevelInfo);
		ADD_PDE_METHOD(GetLevelInfoById);
		ADD_PDE_METHOD(StartGame);
		ADD_PDE_METHOD(EnterGame);
		ADD_PDE_METHOD(Ready);
		ADD_PDE_METHOD(ChangeTeam);
		ADD_PDE_METHOD(ChangeSlot);
		ADD_PDE_METHOD(ChangeSlotStatus);
		ADD_PDE_METHOD(GetSlot);
		ADD_PDE_METHOD(GetGameDescription);
		ADD_PDE_METHOD(TeamEnterRoom);
		ADD_PDE_METHOD(PreserveSlot);
		ADD_PDE_METHOD(UpdateBlackList);
		ADD_PDE_METHOD(RefreshClientList);
		ADD_PDE_METHOD(GetRoomListCompareFunc);
		ADD_PDE_METHOD(GetChannelListCompareFunc);
		ADD_PDE_METHOD(GetServerListCompareFunc);
		ADD_PDE_METHOD(SearchRoom);
		ADD_PDE_METHOD(CancelSearchRoom);
		ADD_PDE_METHOD(BlacklistAdd);
		ADD_PDE_METHOD(BlacklistClear);
		ADD_PDE_METHOD(GetServerCount);
		ADD_PDE_METHOD(GetServerInfo);
		ADD_PDE_METHOD(GetChannelCount);
		ADD_PDE_METHOD(GetChannelInfo);
		ADD_PDE_METHOD(EnterServer);
		ADD_PDE_METHOD(LeaveServer);
		ADD_PDE_METHOD(RefreshServerList);
		ADD_PDE_METHOD(RefreshChannelList);
		ADD_PDE_METHOD(GetChannelClientInfo);
		ADD_PDE_METHOD(GetChannelClientCount);
		ADD_PDE_METHOD(RequestCharacterAddress);
		ADD_PDE_METHOD(OnAddressArrived);
		ADD_PDE_METHOD(SwitchBGM);
		ADD_PDE_METHOD(OnChange_Lobby_Music);

		ADD_PDE_METHOD(StartNovice);

		ADD_PDE_METHOD(GetScreenSize);
		ADD_PDE_METHOD(GetUIWindowSize);
		ADD_PDE_METHOD(GetCursorPos);

		ADD_PDE_METHOD(HttpXLInfo);
		ADD_PDE_METHOD(HttpXLReport);

		ADD_PDE_METHOD(UpdateReplayList);
		ADD_PDE_METHOD(GetReplayCount);
		ADD_PDE_METHOD(GetReplayName);
		ADD_PDE_METHOD(ReplayPlay);
		ADD_PDE_METHOD(ReplayOpen);
		ADD_PDE_METHOD(ReplayDelete);
		ADD_PDE_METHOD(GetModuleState);
		ADD_PDE_METHOD(GetBattlePlayerInfo);
		ADD_PDE_METHOD(GetBattleGroups);
		ADD_PDE_METHOD(GetBattleGroupJoin);
		ADD_PDE_METHOD(BattleGroupLeave);
		ADD_PDE_METHOD(BattleGroupReady);
		ADD_PDE_METHOD(BattleGroupStartSearch);
		ADD_PDE_METHOD(BattleGroupInvite);
		ADD_PDE_METHOD(BattleGroupChallenge);
		ADD_PDE_METHOD(RequestTDData);

		ADD_PDE_METHOD(RequestMatching);

		ADD_PDE_METHOD(RequestCancelMatching);
		
		
		//ADD_PDE_METHOD(Begin);
		//ADD_PDE_METHOD(End);
	}
};

REGISTER_PDE_TYPE(StateLobby::IRoomListCompareFunc);
REGISTER_PDE_TYPE(StateLobby::IChannelListCompareFunc);
REGISTER_PDE_TYPE(StateLobby::IServerListCompareFunc);
REGISTER_PDE_TYPE(StateLobby);
REGISTER_PDE_TYPE(ServerInfo);
REGISTER_PDE_TYPE(ChannelInfo);
REGISTER_PDE_TYPE(BattlePlayerInfo);
REGISTER_PDE_TYPE(BattleOtherPlayerInfo);

#define AUTOCHANGE_TIMEOUT 5.0f
#define TIMER_EXPIRED_ITEM_MAX 60*30.0f


namespace Client
{
	sharedc_ptr(StateLobby::IRoomListCompareFunc) StateLobby::m_RoomListCompare = ptr_new StateLobby::IRoomListCompareFunc;
	sharedc_ptr(StateLobby::IChannelListCompareFunc) StateLobby::m_ChannelListCompare = ptr_new StateLobby::IChannelListCompareFunc;
	sharedc_ptr(StateLobby::IServerListCompareFunc) StateLobby::m_ServerListCompare = ptr_new StateLobby::IServerListCompareFunc;

	bool StateLobby::IRoomListCompareFunc::operator()( by_ptr(ListItem) item1, by_ptr(ListItem) item2, S32 column, int reverse )
	{
		tempc_ptr(RoomInfo) info1 = ptr_dynamic_cast<RoomInfo>(item1->GetTag());
		tempc_ptr(RoomInfo) info2 = ptr_dynamic_cast<RoomInfo>(item2->GetTag());
		if(info1 && info2)
		{
			bool result = false;
			switch(column)
			{	
			case 0:	//���
				{
					if ((info1->is_vip && info2->is_vip) || (!info1->is_vip && !info2->is_vip))
					{
						if (reverse == 0)
							result = info1->id<info2->id;
						else
							result = info1->id>info2->id;
					}
				};
				break;
			case 3: //��������
				{
					if ((info1->is_vip && info2->is_vip) || (!info1->is_vip && !info2->is_vip))
					{
						if (reverse == 0)
							result = info1->option.name<info2->option.name;
						else
							result = info1->option.name>info2->option.name;
					}
				};
				break;
			case 4:	//ģʽ����
				{
					if ((info1->is_vip && info2->is_vip) || (!info1->is_vip && !info2->is_vip))
					{
						if (reverse == 0)
							result = info1->option.game_type<info2->option.game_type;
						else
							result = info1->option.game_type>info2->option.game_type;
					}
				}
				break;
			case 5: //ְҵս
				{
					if ((info1->is_vip && info2->is_vip) || (!info1->is_vip && !info2->is_vip))
					{
						if (reverse == 0)
							result = info1->option.character_id<info2->option.character_id;
						else
							result = info1->option.character_id>info2->option.character_id;
					}
				}
				break;
			case 6:	//��ͼ����
				{
					if ((info1->is_vip && info2->is_vip) || (!info1->is_vip && !info2->is_vip))
					{
						if (reverse == 0)
							result = info1->option.map_name<info2->option.map_name;
						else
							result = info1->option.map_name>info2->option.map_name;
					}
				}
				break;
			case 7:	//����
				{
					if ((info1->is_vip && info2->is_vip) || (!info1->is_vip && !info2->is_vip))
					{
						if (reverse == 0)
							result = info1->client_count<info2->client_count;
						else
							result = info1->client_count>info2->client_count;
					}
				}
				break;
			case 8: //״̬
				{
					if ((info1->is_vip && info2->is_vip) || (!info1->is_vip && !info2->is_vip))
					{
						if (reverse == 0)
							result = info1->state<info2->state;
						else
							result = info1->state>info2->state;
					}
				};
				break;
			}
			return result;
		}
		else
		{
			tempc_ptr(ListTreeView::SortFunc) func = ListTreeView::GetDefaultStrCompareFunc();
			if(func)
				return (*func)(item1, item2, column, reverse);
			else
			{
				PDE_ASSERT(false, "room list have no tag, and list treeview default compare func is invalid");
				return false;
			}
		}
	}
	bool StateLobby::IChannelListCompareFunc::operator()( by_ptr(ListItem) item1, by_ptr(ListItem) item2, S32 column, int reverse )
	{
		tempc_ptr(ListTreeView::SortFunc) func = ListTreeView::GetDefaultStrCompareFunc();
		if(func)
			return (*func)(item1, item2, column, reverse);
		else
		{
			PDE_ASSERT(false, "channel list compare func haven't been implemented, and list treeview default compare func is invalid");
			return false;
		}
	}
	bool StateLobby::IServerListCompareFunc::operator()( by_ptr(ListItem) item1, by_ptr(ListItem) item2, S32 column, int reverse )
	{
		tempc_ptr(ListTreeView::SortFunc) func = ListTreeView::GetDefaultStrCompareFunc();
		if(func)
			return (*func)(item1, item2, column, reverse);
		else
		{
			PDE_ASSERT(false, "server list compare func haven't been implemented, and list treeview default compare func is invalid");
			return false;
		}
	}
}

namespace Client
{
	StateLobby::StateLobby()
		: m_need_fcm_notified(false)
		, m_music_lobby(NULL)
		, m_music_lobby_storage(NULL)
		, m_music_lobby_match(NULL)
		, m_music_tune(NULL)
		, waiting_for_auto_pwd(false)
		, waiting_for_auto_room_list(false)
		, m_Is_Need_Train(false)
		, m_Is_in_invite(false)
		, m_Is_in_invite1(false)
		, m_Today_Check(false)
		, m_Is_Novice_Game(false)
		, m_fcm_flag(0)
		, m_last_channel_id(-1)
		, gc_time(0)
		, m_channl_list_total_count(0)
		, m_channl_list_start(0)
		, m_is_fight_team_server(false)
		, m_battle_is_create(false)
		, m_source_is_create(false)
		, m_is_zhihuisuo(false)
		, m_zhihuisuo_num(1)
		, m_Prize_times(10.0f)
		, m_Prize_Index(0)
		, m_tiaozhan_request(false)
		, m_fcm_online_time(-1)
		, update_timer(0.f)
		, match_flag(false)
	{
		m_b_player_info = ptr_new BattlePlayerInfo();
		m_battle_room = ptr_new BattleRoom();
		for (int i= 0 ; i < 6 ; i++)
		{
			m_battle_room->player[i].client_uid = -1;
			m_battle_room->player[i].character_name = "";
			m_battle_room->player[i].head_icon = "";
			m_battle_room->player[i].character_level = 0;
			m_battle_room->player[i].is_vip = 0;
			m_battle_room->player[i].net_bar_level = 0;
			m_battle_room->player[i].business_card = 0;
		}
		for (int i= 0 ; i < 3 ; i++)
		{
			battle_room_groupid[i] = 0;
		}
		ResetAutoChangeState();
	}

	PDE_ATTRIBUTE_GETTER(StateLobby, SquadPanel, tempc_ptr(Gui::SquadPanel))	
	{
		if(gGame->lobby_connection)
			return gGame->lobby_connection->m_SquadPanel;
		else
			return NullPtr;
	}

	PDE_ATTRIBUTE_GETTER(StateLobby, AmILeader, bool)
	{
		tempc_ptr(Gui::SquadPanel) panel = GetSquadPanel();
		if(panel)
		{
			return panel->GetHostIsLeader();
		}
		else
		{
			return false;
		}
	}

	PDE_ATTRIBUTE_GETTER(StateLobby, autostarttime, double)
	{
		return m_autostarttime;
	}

	PDE_ATTRIBUTE_SETTER(StateLobby, AutoPassword, const Core::String&)
	{
		if(auto_password!=value)
		{
			auto_password = value;
		}
	}

	void StateLobby::OnCreate()
	{
		Object::OnCreate();
	}

	void StateLobby::OnDestroy()
	{
		if (m_SysMsgBar)
		{
			m_SysMsgBar->SetParent(NullPtr);
			m_SysMsgBar = NullPtr;
		}
		Object::OnDestroy();
	}

	void StateLobby::OnEnter()
	{
		if (gRender)
			gRender->SetGameState(D3DRender::kLobbyEnter);

		ResetAutoChangeState();

		refresh_room_list = false;
		waiting_for_auto_pwd = false;
		waiting_for_auto_room_list = false;

		m_ChatWindow = ptr_new ChatWindow;
		m_SysMsgBar = ptr_new SysMessageBar;
		m_SysMsgBar->SetTextColor(ARGB(255,255,255,255));
		//m_NoteIcon = ptr_new Label;
		//m_NoteIcon->SetBackgroundColor(ARGB(0,255,255,255));
		//m_SysMsgBar->m_IconLabel = m_NoteIcon;
		m_LobbyPList = ptr_new LobbyPList;
// 		gGame->guiSys->SetDrawDG(true);

		if(gGame && gGame->guiSys)
		{
			if(m_music_lobby)
			{
				m_music_lobby->stop();
				m_music_lobby->release();
			}
			if(m_music_lobby_storage)
			{
				m_music_lobby_storage->stop();
				m_music_lobby_storage->release();
			}
			if(m_music_tune)
			{
				m_music_tune->stop();
				m_music_tune->release();
			}
			if (m_music_lobby_match)
			{
				m_music_lobby_match->stop();
				m_music_lobby_match->release();
			}
			m_music_lobby = FmodSystem::GetEvent(gGame->guiSys->GetAudioResourceName(GuiSystem::kUIA_lOBBY_MUSIC));
			m_music_lobby_storage = FmodSystem::GetEvent(gGame->guiSys->GetAudioResourceName(GuiSystem::kUIA_STORAGE));
			m_music_lobby_match = FmodSystem::GetEvent(gGame->guiSys->GetAudioResourceName(GuiSystem::kUIA_MATCH));
		}
		//Play lobby music
		if(m_music_lobby)
		{
			m_music_lobby->start();
		}

		//Lua::LuaState::FromThread()->DoFile("/scripts/state_lobby.lua");
		Lua::LuaState::FromThread()->DoFile("/scripts/state_lobby_new.lua");

#if ACTIVE_APEX
		if(!gGame->IsInitApex)
		{
			gGame->IsInitApex = true;
			Apex::StartApexClient();
		}
			
#endif
	}

	void StateLobby::InitUI()
	{
		EventInitUI.Fire(ptr_static_cast<StateLobby>(this), EventArgs());
	}

	void StateLobby::RestoreUI()
	{
		EventRestoreUI.Fire(ptr_static_cast<StateLobby>(this), EventArgs());
	}

	void StateLobby::OnLeave()
	{
		waiting_for_auto_pwd = false;
		waiting_for_auto_room_list = false;

		if (gRender)
			gRender->SetGameState(D3DRender::kLobbyLeave);

		gLevel->Unload();

		m_ChatWindow->SetParent(NullPtr);
		m_ChatWindow = NullPtr;

		m_LobbyPList->SetParent(NullPtr);
		m_LobbyPList = NullPtr;

		if(m_music_lobby)
		{
			m_music_lobby->stop();
			m_music_lobby->release();
			m_music_lobby = NULL;
		}
		if(m_music_lobby_storage)
		{
			m_music_lobby_storage->stop();
			m_music_lobby_storage->release();
			m_music_lobby_storage = NULL;
		}
		if(m_music_tune)
		{
			m_music_tune->stop();
			m_music_tune->release();
			m_music_tune = NULL;
		}
		if (m_music_lobby_match)
		{
			m_music_lobby_match->stop();
			m_music_lobby_match->release();
			m_music_lobby_match = NULL;
		}

		EventLeave.Fire(ptr_static_cast<StateLobby>(this), EventArgs());
		//gGame->lobby_pipeline->UnInitialize();
// 		gGame->guiSys->SetDrawDG(false);
	}

	// replay play
	void StateLobby::ReplayPlay()
	{
		if (gGame->channel_connection)
			gGame->channel_connection->ReplayPlay();
	}

	int StateLobby::ReplayOpen(Core::String replay_name)
	{
		if (gGame->channel_connection)
			return gGame->channel_connection->ReplayOpen(replay_name);

		return 1;
	}

	// replay delete
	void StateLobby::ReplayDelete(Core::String replay_name)
	{
		CStrBuf<128> path;
		path.format("/replay/%s.replay",replay_name);
		Path::GetPhysicalPath(path, path, Path::kVirtualReadWrite);
		DeleteFileA(path);
	}
	
	// update replay list
	void StateLobby::UpdateReplayList()
	{
		m_ReplayList.Clear();

		if (Path::IsDirectory("/replay/"))
		{
			PdeItPath it;
			it.Reset("/replay/",false);
			while (it.MoveNext())
			{
				if (it.IsDirectory())
				{
					continue;
				}

				CStrBuf<32> ext;
				CStrBuf<128> file;
				Path::GetFileExtension(ext,it.Name().buff());
				if (ext == "replay")
				{
					Path::GetFileNameWithoutExtension(file,it.Name().buff());
					m_ReplayList.PushBack(file);
				}
			}
		}
	}

	// get replay count
	uint StateLobby::GetReplayCount()
	{
		return m_ReplayList.Size();
	}

	// get replay path
	Core::String StateLobby::GetReplayName(uint index)
	{
		if (m_ReplayList.IsValidIndex(index))
		{
			return m_ReplayList[index];
		}
		return Core::String::kEmpty;
	}

	// on enter server
	void StateLobby::OnEnterServer(uint result)
	{
		EventEnterServer.Fire(ptr_static_cast<StateLobby>(this), RetEventArgs(result));

		if (auto_changing == StateLobby::kEnterServer && result == kErrorNone)
		{
			auto_changing = StateLobby::kEnterChannel;
			auto_time_out = AUTOCHANGE_TIMEOUT;
			ConnectChannel(auto_channel_id);
		}
	}

	// on enter server
	void StateLobby::OnLeaveServer(uint result)
	{
		EventLeaveServer.Fire(ptr_static_cast<StateLobby>(this), RetEventArgs(result));
		tempc_ptr(StateLobby) lobby = ptr_dynamic_cast<StateLobby>(gGame->machine.CurrentState());
		if(lobby)
		{
			if (lobby->m_is_fight_team_server)
			{
				lobby->m_is_fight_team_server = false;
			}
		}

		if(m_Is_in_invite == true)
		{
			auto_changing = StateLobby::kLeaveServer;
		}
		if(m_Is_in_invite1 == true)
		{
			auto_changing = StateLobby::kLeaveServer;
		}
		if (auto_changing == StateLobby::kLeaveServer)
		{
			auto_changing = StateLobby::kEnterServer;
			auto_time_out = AUTOCHANGE_TIMEOUT;
			EnterServer(auto_server_id);
		}
	}

	// on enter channel
	void StateLobby::OnEnterChannel()
	{
		//waiting_for_auto_room_list = false;
		EventAddressChanged.Fire(ptr_static_cast<StateLobby>(this), EventArgs());
		EventChannelEnter.Fire(ptr_static_cast<StateLobby>(this), EventArgs());
		if (auto_changing == StateLobby::kLeaveRoom)
		{
			const ClientAddress& addr = gGame->address;
			if(auto_server_id==addr.server_id && auto_channel_id==addr.channel_id)
			{
				auto_changing = StateLobby::kEnterRoom;
				auto_time_out = AUTOCHANGE_TIMEOUT;

				waiting_for_auto_room_list = true;
			}
			else
			{
				auto_changing = StateLobby::kLeaveChannel;
				auto_time_out = AUTOCHANGE_TIMEOUT;
				LeaveChannel();
			}
		}

		if (auto_changing == StateLobby::kEnterChannel)
		{
			auto_changing = StateLobby::kEnterRoom;
			auto_time_out = AUTOCHANGE_TIMEOUT;

			waiting_for_auto_room_list = true;
		}
	}

	// on leave channel
	void StateLobby::OnLeaveChannel()
	{
		EventAddressChanged.Fire(ptr_static_cast<StateLobby>(this), EventArgs());

		if(m_LobbyPList)
			m_LobbyPList->ClearChannelPlayerList();

		if (auto_changing == StateLobby::kLeaveChannel)
		{
			const ClientAddress& addr = gGame->address;
			if(auto_server_id==addr.server_id)
			{
				auto_changing = StateLobby::kEnterChannel;
				auto_time_out = AUTOCHANGE_TIMEOUT;
				ConnectChannel(auto_channel_id);
			}
			else
			{
				auto_changing = StateLobby::kLeaveServer;
				auto_time_out = AUTOCHANGE_TIMEOUT;
				LeaveServer();
			}
		}
	}

	void StateLobby::OnGameBegin(uint ret)
	{
		EventGameBegin.Fire(ptr_static_cast<StateLobby>(this), RetEventArgs(ret));
		match_flag = true;
	}

	void StateLobby::OnGameReady(uint ret)
	{
		EventGameReady.Fire(ptr_static_cast<StateLobby>(this), RetEventArgs(ret));
	}

	// on enter room
	void StateLobby::OnEnterRoom()
	{
		EventEnterRoomSuccess.Fire(ptr_static_cast<StateLobby>(this), EventArgs());
		EventAddressChanged.Fire(ptr_static_cast<StateLobby>(this), EventArgs());

		

		if (auto_changing == StateLobby::kEnterRoom)
		{
			ResetAutoChangeState();
			// 			CmdEventArgs cmdArgs;
			// 			cmdArgs.Details = "{cmd=\"switchMenu\", menu=\"PlayGame\"}";
			// 			EventServerCmd.Fire(ptr_static_cast<StateLobby>(this), cmdArgs);
		}
	}

	// on leave room
	void StateLobby::OnLeaveRoom()
	{
		EventLeaveRoom.Fire(ptr_static_cast<StateLobby>(this), RetEventArgs(0));
	}

	//on in room change team success
	void StateLobby::OnInRoomChangeTeamSuccess()
	{
		EventInRoomChangeTeamSuccess.Fire(ptr_static_cast<StateLobby>(this), EventArgs());
	}

	// on room list changed
	void StateLobby::OnRoomListChanged()
	{
		refresh_room_list = true;
		if(waiting_for_auto_room_list)
		{
			AutoEnterRoom();
		}
		waiting_for_auto_room_list = false;
	}

	// on player list changed
	void StateLobby::OnRoomClientListChanged()
	{
		EventRoomClientListChanged.Fire(ptr_static_cast<StateLobby>(this), EventArgs());
	}

	// on room Auto Start
	void StateLobby::OnRoomAutoStart(double time)
	{
		m_autostarttime = time; 
		EventRoomAutoStart.Fire(ptr_static_cast<StateLobby>(this), EventArgs());
	}

	// on room Auto Start
	void StateLobby::OnRoomAutoStartCancel()
	{
		EventRoomAutoStartCancel.Fire(ptr_static_cast<StateLobby>(this), EventArgs());
	}

	// on player list changed
	void StateLobby::OnRoomOptionChanged()
	{
		EventRoomOptionChanged.Fire(ptr_static_cast<StateLobby>(this), EventArgs());
	}

	// on room slot changed
	void StateLobby::OnRoomSlotChanged()
	{
		EventRoomSlotChanged.Fire(ptr_static_cast<StateLobby>(this), EventArgs());
	}

	// on update level list
	void StateLobby::OnUpdateLevelList()
	{
		LogSystem.WriteLinef("432432");
		EventUpdateLevelList1.Fire(ptr_static_cast<StateLobby>(this), EventArgs());
	}

	// on update level list
	void StateLobby::OnUpdateServerList()
	{
		EventUpdateServerList.Fire(ptr_static_cast<StateLobby>(this), EventArgs());
	}

	// on update level list
	void StateLobby::OnUpdateChannelList()
	{
		EventUpdateChannelList.Fire(ptr_static_cast<StateLobby>(this), EventArgs());
	}


	// on kicked in room
	void StateLobby::OnKickedInRoom()
	{
		EventKickedInRoom.Fire(ptr_static_cast<StateLobby>(this), EventArgs());
	}
	
	// on kicked in game
	void StateLobby::OnKickedIdleInGame()
	{
		EventIdleKicked.Fire(ptr_static_cast<StateLobby>(this), EventArgs());
	}

	void StateLobby::OnQuitInGame()
	{
		EventOnQuitInGame.Fire(ptr_static_cast<StateLobby>(this), EventArgs());
	}

	void StateLobby::OnUpdate(float frameTime)
	{
		if (auto_changing != StateLobby::kIdle && !waiting_for_auto_pwd)
		{
			auto_time_out -= frameTime;
			if (auto_time_out <= 0.f)
			{
				AutoChangeState curr_error = auto_changing;

				ResetAutoChangeState();

				last_autochange_error = curr_error;

				Console.WriteLinef("####Auto Change Error[%d]####", (int)last_autochange_error);
			}
		}

		if (gc_time > 5.f)
		{
			gc_time = 0.f;
			Resource::GC();
		}
		else
		{
			gc_time += frameTime;
		}

		

		if(gGame->need_leave_channel)
		{
			EventLeaveRoom.Fire(ptr_static_cast<StateLobby>(this), RetEventArgs(0));
			
			ForceUILeaveChannel();
			ForceUILeaveServer();

			gGame->need_leave_channel = false;
		}

		if(gGame->need_leave_roomlist)
		{
			ForceUILeaveChannel();

			gGame->need_leave_roomlist = false;
		}

		if(gGame->lobby_connection)
		{
			gGame->lobby_connection->UpdateCharacterTimer(frameTime);
			if(gGame->lobby_connection->GetCharacterTimer()>TIMER_EXPIRED_ITEM_MAX)
			{
				gGame->lobby_connection->ResetCharacterTimer();
				EventQueryExpiredItem.Fire(ptr_static_cast<StateLobby>(this), EventArgs());
			}
		}

		if (gRender)
			gRender->Update(frameTime);

		if (refresh_room_list && update_timer  > 1.f)
		{
			refresh_room_list = false;
			EventRoomListChanged.Fire(ptr_static_cast<StateLobby>(this), EventArgs());
			update_timer = 0.f;
		}
		update_timer += frameTime;



		if (m_Is_Novice_Game)
		{
			EventUpdateNovice.Fire(ptr_static_cast<StateLobby>(this), EventArgs());
		}
		
		//lost rpc
		if (gGame->lobby_connection && 
			gGame->lobby_connection->lost_rpc_message.Size() > 0)
		{
			for (U32 i = 0; i < gGame->lobby_connection->lost_rpc_message.Size(); i++)
			{
				OnRPCMessage(gGame->lobby_connection->lost_rpc_message[i]);
			}

			gGame->lobby_connection->lost_rpc_message.Clear();
		}

		//��ú�װ��ͨ�� �ͻ���YY
		UpdatePrizeTime(frameTime);
	}

	void StateLobby::OnInput(InputEventArgs & e)
	{
		if (e.IsKeyEvent())
		{
			tempc_ptr(Textbox) textBox = ptr_dynamic_cast<Textbox>(gGame->guiSys->GetFocusedControl());
			tempc_ptr(ConsoleUI) console = ptr_dynamic_cast<ConsoleUI>(gGame->guiSys->GetFocusedControl());
			tempc_ptr(TextArea) textArea = ptr_dynamic_cast<TextArea>(gGame->guiSys->GetFocusedControl());
			tempc_ptr(ModalControl) modal = NullPtr;
			if(gGame->guiSys->GetFocusedControl())
				modal = ptr_dynamic_cast<ModalControl>(gGame->guiSys->GetFocusedControl()->GetRoot());
			if (!textBox && !console && !textArea && !modal)
			{
				if (e.Type == InputEventArgs::kKeyDown && e.Code == KC_RETURN)
				{
					//m_ChatWindow->GetTextbox()->SetFocused(true);
				}
			}
		}
	}

	void StateLobby::OnDisconnect()
	{
		if (!gGame->lobby_connection)
		{
			gGame->machine.ChangeState(ptr_new StateLogin);
			EventOnDisconnected.Fire(ptr_static_cast<StateLobby>(this), EventArgs());
		}
		else
		{
			EventAddressChanged.Fire(ptr_static_cast<StateLobby>(this), EventArgs());
		}
	}

	// render
	void StateLobby::OnRender()
	{
		if (gRender)
			gRender->Draw();
	}

	// on chat
	void StateLobby::OnChat(ChatMessage & msg)
	{
		msg.msg.RefStr(0).replace('\r','\n');
		msg.msg.RefStr(0).replace('\n',' ');

		if (gGame->lobby_connection && gGame->lobby_connection->black_list.Contains(msg.sender))
			return;

		m_ChatWindow->ReceiveMessage(msg);
		if(msg.channel == Core::Identifier("/sys"))
		{
			if(gGame && gGame->guiSys)
			{
				gGame->guiSys->PlayAudio(GuiSystem::kUIA_SYSTEM_MESSAGE);
			}
		}
		m_SysMsgBar->ReceiveMessage(msg);
	}

	void StateLobby::OnRPCMessage( const Core::String& msg )
	{
		CmdEventArgs cmdArgs;
		cmdArgs.Details = msg;
		EventServerCmd.Fire(ptr_static_cast<StateLobby>(this), cmdArgs);
	}

	bool StateLobby::StartNovice()
	{
		if (gGame->channel_connection)
			return gGame->channel_connection->RequestNovice();
		return false;
	}

	void StateLobby::OnGameStart(uint player_id)
	{
		sharedc_ptr(StateGameLoading) loading = ptr_new StateGameLoading;
		loading->player_id = player_id;
		loading->map_name = gGame->channel_connection->room_info.option.map_name;
		loading->gameMode = gGame->channel_connection->room_info.option.game_type;
		gGame->machine.ChangeState(loading);
	}

	// fcm
	void StateLobby::OnFCM(int online_minutes, const char * message)
	{
		ChatMessage msg;
		msg.channel = "/sys";

		if (!m_need_fcm_notified)
		{
			m_fcm_flag = gGame->fcm_flag;
			m_need_fcm_notified = true;
			msg.msg = gLang->GetTextW(L"����û�в����������Ϣ");
			m_ChatWindow->ReceiveMessage(msg);
				EventOnNeedFCMNotified.Fire(ptr_static_cast<StateLobby>(this), EventArgs());
		}

		if (message)
		{
			msg.msg = message;
			m_ChatWindow->ReceiveMessage(msg);
			m_SysMsgBar->ReceiveMessage(msg);
		}
	}
};

namespace Client
{
	void StateLobby::AutoPhoto()
	{
		if (!gGame->bSavePhoto)
			gGame->bSavePhoto = true;
	}

	void StateLobby::AutoChangeRoom(int server_id, int channel_id, int room_id)
	{
		AutoChangeRoomWithPassword(server_id, channel_id, room_id, "");
	}

	void StateLobby::AutoChangeRoomWithPassword(int server_id, int channel_id, int room_id, const Core::String & ps)
	{
		auto_server_id = server_id;
		auto_channel_id = channel_id;		
		auto_room_id = room_id;
		auto_room_ps = ps;

		if(server_id<=0)
		{
			gGame->guiSys->ShowMessage(gLang->GetTextW(L"��Ч�ķ�������ַ"));
			return;
		}
		if(channel_id<=0)
		{
			gGame->guiSys->ShowMessage(gLang->GetTextW(L"��Ч��Ƶ����ַ"));
			return;
		}
		if(room_id<=0)
		{
			gGame->guiSys->ShowMessage(gLang->GetTextW(L"��Ч�ķ����ַ"));
			return;
		}

		auto_time_out = AUTOCHANGE_TIMEOUT;

		const ClientAddress& addr = gGame->address;

		CmdEventArgs cmdArgs;
		cmdArgs.Details = "{cmd=\"switchMenu\", menu=\"PlayGame\"}";
		EventServerCmd.Fire(ptr_static_cast<StateLobby>(this), cmdArgs);

		if (gGame->channel_connection)
		{
			switch (gGame->channel_connection->GetState())
			{
			case ChannelConnection::kInRoom:
				if(!(addr.server_id == server_id && addr.channel_id == channel_id && addr.room_id == room_id))
				{
					LogSystem.WriteLinef("server_id:%d", server_id);
					LogSystem.WriteLinef("channel_id:%d", channel_id);
					LogSystem.WriteLinef("room_id:%d", room_id);
					auto_changing = StateLobby::kLeaveRoom;
					LeaveRoom();
				}
				else
				{
					m_Is_in_invite = false;
					m_Is_in_invite1 = false;
					gGame->guiSys->ShowMessage(gLang->GetTextW(L"���Ѿ��ڸ÷�������"));
				}
				break;

			case ChannelConnection::kInChannel:
				if(addr.server_id == server_id && addr.channel_id == channel_id)
				{
					auto_changing = StateLobby::kEnterRoom;
					AutoEnterRoom();
				}
				else
				{
					auto_changing = StateLobby::kLeaveChannel;
					LeaveChannel();
				}
				break;

			default:
				ResetAutoChangeState();
				return;
			}
		}
		else
		{
			auto_changing = StateLobby::kEnterServer;
			EnterServer(auto_server_id);
		}
	}

	void StateLobby::CancelAutoChange()
	{
		ResetAutoChangeState();
	}

	bool StateLobby::IsAutoChanging()
	{
		return auto_changing != StateLobby::kIdle;
	}


	void StateLobby::AutoEnterRoom()
	{
		waiting_for_auto_pwd = false;
		tempc_ptr(RoomInfo) rInfo= GetRoomInfoById(auto_room_id);	
		if(rInfo)
		{
			if(!rInfo->option.use_password)
			{
				EnterRoom(auto_room_id, Core::String::kEmpty);
			}
			else if (auto_room_ps.Length() > 0)
			{
				EnterRoom(auto_room_id, auto_room_ps);
			}
			else
			{
				waiting_for_auto_pwd = true;
				EventNeedAutoPassword.Fire(ptr_static_cast<StateLobby>(this), EventArgs());
			}
		}
		else
		{
			gGame->guiSys->ShowMessage(gLang->GetTextW(L"����ID��Ч�����ܷ����Ѿ�������"));
			refresh_room_list = false;
			EnterSourceRoomError.Fire(ptr_static_cast<StateLobby>(this), RetEventArgs());
		}
	}

	void StateLobby::ContinueAutoEnterRoom()
	{
		waiting_for_auto_pwd = false;
		EnterRoom(auto_room_id, auto_password);
		auto_password = Core::String::kEmpty;
	}
}

namespace Client
{
	// channel connect
	void StateLobby::ConnectChannel(int channel_id)
	{
		if (gGame->lobby_connection)
			gGame->lobby_connection->RequestChannelConnect(channel_id);
	}
}

namespace Client
{
	// create room
	void StateLobby::CreateRoom(const RoomOption & option)
	{
		if (gGame->channel_connection)
		{
			gGame->channel_connection->RequestRoomCreate(option);
		}
		else
		{
			EventCreateRoomFailed.Fire(ptr_static_cast<StateLobby>(this), RetEventArgs(kErrorProxyChannelConnect));
		}
	}


	void StateLobby::CreateRoomTest()
	{
		if (gGame->channel_connection)
		{
			gGame->channel_connection->CreateRoomTest();
		}
		else
		{
			EventCreateRoomFailed.Fire(ptr_static_cast<StateLobby>(this), RetEventArgs(kErrorProxyChannelConnect));
		}
	}



	// enter room
	void StateLobby::EnterRoom(int room_id, const Core::String & ps)
	{
		if (gGame->channel_connection)
			gGame->channel_connection->RequestRoomEnter(room_id, ps);
	}

	// enter room
	void StateLobby::TeamEnterRoom(int room_id, const Core::String & ps)
	{
		if (gGame->channel_connection && gGame->lobby_connection)
		{
			Array<String> members;

			for (uint i = 0; i < gGame->lobby_connection->team_members.Size(); i ++)
			{
				if (gGame->lobby_connection->team_members[i].name != gGame->lobby_connection->character_name)
				{
					members.PushBack(gGame->lobby_connection->team_members[i].name);
				}
			}

			gGame->channel_connection->RequestRoomTeamEnter(room_id, ps, members);
		}
	}

	// channel leave
	void StateLobby::LeaveChannel()
	{
		if (gGame->channel_connection)
		{
			gGame->channel_connection->Disconnect();
			EventChannelLeave.Fire(ptr_static_cast<StateLobby>(this), EventArgs());
		}
	}

	void StateLobby::ForceUILeaveChannel()
	{
		ForceExitEventArgs args;
		args.exit_id = 2;
		EventForcelLeave.Fire(ptr_static_cast<StateLobby>(this), args);
	}

	void StateLobby::ForceUILeaveServer()
	{
		ForceExitEventArgs args;
		args.exit_id = 1;
		EventForcelLeave.Fire(ptr_static_cast<StateLobby>(this), args);
	}

	// get room count
	int StateLobby::GetRoomCount()
	{
		if (gGame->channel_connection)
			return gGame->channel_connection->room_list.Size(); 
		return 0;
	}

	// get room
	tempc_ptr(RoomInfo)  StateLobby::GetRoomInfo(uint index)
	{
		int size = GetRoomCount();

		if (gGame->channel_connection && index < (uint)size)
			return gGame->channel_connection->room_list[index];

		return NullPtr;
	}

	// get room by id
	tempc_ptr(RoomInfo)  StateLobby::GetRoomInfoById(short id)
	{
		if (gGame->channel_connection)
		{
			LogSystem.WriteLinef("111");
			for (uint i = 0; i < gGame->channel_connection->room_list.Size(); i++)
			{
				tempc_ptr(RoomInfo) room_info = gGame->channel_connection->room_list[i];
				if (room_info && room_info->id == id)
					return room_info;
			}
		}

		return NullPtr;
	}

	//get user id
	int StateLobby::GetUserId()
	{
		if (gGame->lobby_connection)
			return gGame->lobby_connection->uid;
		else
			return 0;
	}

	// get character id
	int StateLobby::GetCharacterId()
	{
		if (gGame->lobby_connection)
			return gGame->lobby_connection->character_id;
		else
			return 0;
	}

	// get character id
	Core::String StateLobby::GetCharacterName()
	{
		if (gGame->lobby_connection)
			return gGame->lobby_connection->character_name;
		else
			return String::kEmpty;
	}

	// get character id
	int StateLobby::GetCharacterGender()
	{
		if (gGame->lobby_connection)
			return gGame->lobby_connection->character_gender;
		else
			return 0;
	}
}

namespace Client
{

	RoomInfo StateLobby::GetSelfRoomInfo()
	{
		if (gGame->channel_connection && gGame->channel_connection->GetState() > ChannelConnection::kInChannel)
			return gGame->channel_connection->room_info;

		return RoomInfo();
	}

	// get client count
	int StateLobby::GetClientCount()
	{
		if (gGame->channel_connection)
			return gGame->channel_connection->client_list.Size(); 
		return 0;
	}

	// get client
	tempc_ptr(ClientInfo) StateLobby::GetClientInfo(uint index)
	{
		int size = GetClientCount();

		if (gGame->channel_connection && index < (uint)size)
			return gGame->channel_connection->client_list[index];

		return NullPtr;
	}

	// get my client info
	tempc_ptr(ClientInfo) StateLobby::GetMyClientInfo()
	{
		int size = GetClientCount();

		for (int i = 0; i < size; i ++)
		{
			tempc_ptr(ClientInfo) info = gGame->channel_connection->client_list[i];

			if (info->character_id == gGame->channel_connection->character_id)
			{
				return info;
			}

		}

		return NullPtr;
	}

	// room change option
	void StateLobby::RoomChangeOption(const RoomOption & option)
	{
		if (gGame->channel_connection)
			gGame->channel_connection->RequestRoomChangeOption(option);
		if (gGame->lobby_connection)
		{
			gGame->lobby_connection->RequestChangeMatchMap(option.level_id);
		}
	}

	// room kick client
	void StateLobby::RoomKickClient(byte id)
	{
		if (gGame->channel_connection)
			gGame->channel_connection->RequestRoomKickClient(id);
	}

	// leave room
	void StateLobby::LeaveRoom()
	{
		if (gGame->channel_connection)
			gGame->channel_connection->RequestRoomLeave();
	}

	// start game
	void StateLobby::StartGame()
	{
		if (gGame->channel_connection)
		{
			gGame->channel_connection->RequestGameStart();
			Console.WriteLine("Game starting...");
		}
	}

	// enter game
	void StateLobby::EnterGame()
	{
		if (gGame->channel_connection)
		{
			gGame->channel_connection->RequestGameEnter();
		}
	}

	// game ready
	void StateLobby::Ready(bool ready)
	{
		if (gGame->channel_connection)
		{
			gGame->channel_connection->RequestRoomReady(ready);
		}
	}

	// change team
	void StateLobby::ChangeTeam(byte team)
	{
		if (gGame->channel_connection)
			gGame->channel_connection->RequestRoomChangeTeam(team);
	}


	// get level count
	int StateLobby::GetLevelCount()
	{
		if (gGame->lobby_connection)
		{
			int size = gGame->lobby_connection->level_list.Size();
			LogSystem.WriteLinef("size = %d", size);
			return size;
		}
			
		return 0;
	}

	// get level info
	tempc_ptr(LevelInfo) StateLobby::GetLevelInfo(uint index)
	{
		if (gGame->lobby_connection && index < gGame->lobby_connection->level_list.Size())
		{
			tempc_ptr(LevelInfo) info = gGame->lobby_connection->level_list[index];
			return info;
		}
		return NullPtr;
	}

	tempc_ptr(LevelInfo )StateLobby::GetLevelInfoById(int id)
	{
		for(int i = 0; i < (int)gGame->lobby_connection->level_list.Size(); ++i)
		{
			if (gGame->lobby_connection->level_list[i]->id == id)
			{
				return gGame->lobby_connection->level_list[i];
			}
		}
		return NullPtr;
	}

	// change slot
	void StateLobby::ChangeSlot(byte slot_id)
	{
		if (gGame->channel_connection)
			gGame->channel_connection->RequestRoomChangeSlot(slot_id);
	}

	// change slot status
	void StateLobby::ChangeSlotStatus(byte slot_id, uint status)
	{
		if (gGame->channel_connection)
			gGame->channel_connection->RequestRoomChangeSlotStatus(slot_id, (RoomSlot::Status)status);
	}

	// preserve slot
	void StateLobby::PreserveSlot(byte slot_id, const Core::String & name)
	{
		if (gGame->channel_connection)
			gGame->channel_connection->RequestRoomPreserveSlot(slot_id, name);
	}

	// get slot
	RoomSlot StateLobby::GetSlot(uint index)
	{
		if (gGame->channel_connection)
		{
			if (index > 0 && index <= gGame->channel_connection->room_slots.Size())
				return gGame->channel_connection->room_slots[index - 1];
		}

		RoomSlot slot;
		slot.id = 0;
		slot.team = 0;
		slot.status = 0;
		return slot;
	}


	// refresh client list
	void StateLobby::RefreshClientList(int start)
	{
		if (gGame->channel_connection)
		{
			gGame->channel_connection->RequestClientList(start);
		}
	}

	// get game type description
	String StateLobby::GetGameDescription(RoomOption::GameType game_type)
	{
		if (gGame->lobby_connection)
		{
			return gGame->lobby_connection->game_description_set.Get(game_type, String::kEmpty);
		}

		return String::kEmpty;
	}

	void StateLobby::ResetAutoChangeState()
	{
		waiting_for_auto_pwd = false;
		auto_changing = StateLobby::kIdle;
		auto_channel_id = -1;
		auto_room_id = -1;
		auto_room_ps.Clear();
		last_autochange_error = StateLobby::kIdle;
		auto_time_out = 0.f;
	}

	void StateLobby::UpdatePrizeTime(float frameTime)
	{
		m_Prize_times += frameTime;
		if (m_Prize_times > 20.0f)
		{
			m_Prize_times = 0.0f;
			if (gGame->lobby_connection && gGame->lobby_connection->bill_board_list.GetCount() > 0 && m_SysMsgBar->GetWarningMessageArraySize() == 0)
			{
				m_Prize_Index++;
				if (m_Prize_Index >= gGame->lobby_connection->bill_board_list.GetCount())
				{
					m_Prize_Index = 0;
				}
				ChatMessage msg;
				msg.channel = "/pic";
				msg.msg = gGame->lobby_connection->bill_board_list.GetAt(m_Prize_Index);
				m_SysMsgBar->ReceiveMessage(msg);
			}
		}
	}

	void StateLobby::UpdateBlackList(Lua::LuaState *L)
	{
		if (gGame->lobby_connection && L->IsTable(2))
		{
			gGame->lobby_connection->black_list.Clear();
			uint id;
			Core::Identifier name;
			L->PushNil();
			while(L->Next(2))
			{
				L->PushInteger(1);
				L->GetTable(-2);
				id = L->ToInteger(-1);
				L->Pop(1);
				L->PushInteger(3);
				L->GetTable(-2);
				name = L->ToString(-1);
				gGame->lobby_connection->black_list.Add(name,id);
				L->Pop(1);
				L->Pop(1);
			}
		}
	}

	// team invite
	void StateLobby::TeamInvite(const Core::String & name)
	{
		if (gGame->lobby_connection)
			gGame->lobby_connection->RequestTeamInvite(name);
	}


	// team join
	void StateLobby::TeamJoin(const Core::String & name, uint uid)
	{
		if (gGame->lobby_connection)
			gGame->lobby_connection->RequestTeamJoin(name, uid);
	}

	// team leave
	void StateLobby::TeamLeave()
	{
		if (gGame->lobby_connection)
			gGame->lobby_connection->RequestTeamLeave();
	}

	// team kick
	void StateLobby::TeamKick(const Core::String & name)
	{
		if (gGame->lobby_connection)
			gGame->lobby_connection->RequestTeamKick(name);
	}

	// team change leader
	void StateLobby::TeamChangeLeader(const Core::String & name)
	{
		if (gGame->lobby_connection)
			gGame->lobby_connection->RequestTeamChangeLeader(name);
	}

	// team refuse
	void StateLobby::TeamRefuse(const Core::String & name, uint uid)
	{
		if (gGame->lobby_connection)
			gGame->lobby_connection->RequestTeamRefuse(name, uid);
	}

	void StateLobby::TeamRefusePreserve(const Core::String& callerName, uint server_id, uint channel_id, ushort room_id)
	{
		if (gGame->lobby_connection)
			gGame->lobby_connection->RequestRefusePreserve(callerName, server_id, channel_id, room_id, 0);
	}

	// group create
	void StateLobby::GroupCreate()
	{
		if (gGame->lobby_connection)
			gGame->lobby_connection->RequestChatGroupCreate();
	}

	// group invite
	void StateLobby::GroupInvite(const Core::String & name, uint uid)
	{
		if (gGame->lobby_connection)
			gGame->lobby_connection->RequestChatGroupInvite(uid,name);
	}

	// group join
	void StateLobby::GroupJoin(uint uid)
	{
		if (gGame->lobby_connection)
			gGame->lobby_connection->RequestChatGroupJoin(uid);
	}

	// group leave
	void StateLobby::GroupLeave(uint uid)
	{
		if (gGame->lobby_connection)
			gGame->lobby_connection->RequestChatGroupLeave(uid);
	}

	// get group member
	void StateLobby::GetGroupMember(uint uid)
	{
		if (gGame->lobby_connection)
			gGame->lobby_connection->RequestChatGroupMember(uid);
	}

	void StateLobby::OnResponseTeamInvite( const Core::String& name, int result )
	{
		tempc_ptr(SquadPanel) panel = GetSquadPanel();
		if(panel)
			panel->OnResponseTeamInvite(name, result);
	}

	void StateLobby::OnResponseTeamJoin( const Core::String& name, int result )
	{
		tempc_ptr(SquadPanel) panel = GetSquadPanel();
		if(panel)
			panel->OnResponseTeamJoin(name, result);
	}

	void StateLobby::OnTeamInvite( const Core::String& name, int uid )
	{
		tempc_ptr(SquadPanel) panel = GetSquadPanel();
		if(panel)
			panel->OnTeamInvite(name, uid);
	}

	void StateLobby::OnTeamMemberJoin( const Client::TeamMember& member )
	{
		tempc_ptr(SquadPanel) panel = GetSquadPanel();
		if(panel)
			panel->NewMember(member);
	}

	void StateLobby::OnTeamMemberLeave( const Core::String& name )
	{
		tempc_ptr(SquadPanel) panel = GetSquadPanel();
		if(panel)
			panel->RemoveMember(name);
	}

	void StateLobby::OnTeamChangeLeader( const Core::String& name )
	{
		tempc_ptr(SquadPanel) panel = GetSquadPanel();
		if(panel)
			panel->OnLeaderChanged(name);
	}

	void StateLobby::OnTeamMemberInfo( const Client::TeamMember& member )
	{
		tempc_ptr(SquadPanel) panel = GetSquadPanel();
		if(panel)
			panel->UpdateMember(member);
	}

	void StateLobby::OnTeamLeave()
	{
		tempc_ptr(SquadPanel) panel = GetSquadPanel();
		if(panel)
			panel->OnTeamLeave();
	}

	void StateLobby::OnTeamRoomPreserve(uint server_id, uint channel_id, ushort room_id, byte slot_id, const Core::String& invite_name)
	{
		tempc_ptr(SquadPanel) panel = GetSquadPanel();
		if(panel)
			panel->OnLeaderCall(server_id, channel_id, room_id, invite_name);
	}

	void StateLobby::OnTeamRoomCall(uint server_id, uint channel_id, ushort room_id, const Core::String& invite_name)
	{
		tempc_ptr(SquadPanel) panel = GetSquadPanel();
		if(panel)
			panel->OnLeaderCall(server_id, channel_id, room_id, invite_name);
	}

	void StateLobby::OnTeamRoomCancelPreserve(uint server_id, uint channel_id, ushort room_id, byte slot_id)
	{
		tempc_ptr(SquadPanel) panel = GetSquadPanel();
		if(panel)
			panel->OnLeaderCancelCall(server_id, channel_id, room_id);
	}

	void StateLobby::OnFocusLost()
	{
		EventFocusLost.Fire(ptr_static_cast<StateLobby>(this), EventArgs());
	}

	// search room
	void StateLobby::SearchRoom(RoomSearchOptions & options)
	{
		if (gGame->lobby_connection)
			gGame->lobby_connection->RequestSearchRoom(options);
	}

	// cancel search room
	void StateLobby::CancelSearchRoom()
	{
		if (gGame->lobby_connection)
			gGame->lobby_connection->RequestCancelSearchRoom();
	}
	
	// blacklist add
	void  StateLobby::BlacklistAdd(uint uid,const Core::String& str)
	{
		gGame->level->BlacklistAdd(uid,str);
	}

	// blacklist clear
	void  StateLobby::BlacklistClear()
	{
		gGame->level->BlacklistClear();
	}

	bool StateLobby::GetModuleState()
	{
		return gStartConfig.module_state_Open;
	}

	// team call
	void StateLobby::TeamCall(const Core::String & name)
	{
		if (gGame->lobby_connection)
			gGame->lobby_connection->RequestTeamCall(name);
	}

	// get server count
	int StateLobby::GetServerCount()
	{
		if (gGame->lobby_connection)
		{
			LogSystem.WriteLinef("server_listserver_listserver_listserver_list111:%d",gGame->lobby_connection->server_list.Size());
			return gGame->lobby_connection->server_list.Size();
		}

		return 0;
	}

	// get server item
	ServerInfo StateLobby::GetServerInfo(int id,bool is_postion)
	{
		if (gGame->lobby_connection)
		{
			if (is_postion)
			{
				if (gGame->lobby_connection->server_list.IsValidIndex(id))
				{
					return gGame->lobby_connection->server_list[id];
				}
			} 
			else
			{
				for (int i = 0 ; i < gGame->lobby_connection->server_list.GetCount() ; i++)
				{
					if (gGame->lobby_connection->server_list[i].id == (id + 1))
					{
						return gGame->lobby_connection->server_list[i];
					}
				}
			}
		}

		ServerInfo info;
		info.id = 0;
		info.online_count = 0;
		info.online_max = 1000;
		return info;
	}

	// get channel count
	int StateLobby::GetChannelCount()
	{
		if (gGame->lobby_connection)
			return gGame->lobby_connection->channel_list.Size();

		return 0;
	}

	// get channel info
	ChannelInfo StateLobby::GetChannelInfo(int id)
	{
		if (gGame->lobby_connection)
		{
			if (gGame->lobby_connection->channel_list.IsValidIndex(id))
			{
				return gGame->lobby_connection->channel_list[id];
			}
		}

		ChannelInfo info;
		info.id = 0;
		info.online = false;
		info.online_count = 1;
		info.online_max = 1;
		info.min_level = 0;
		info.max_level = 0;
		return info;
	}

	// enter server
	void StateLobby::EnterServer(int id)
	{
		if (gGame->lobby_connection)
			gGame->lobby_connection->RequestEnterServer(id);
	}

	// leave server
	void StateLobby::LeaveServer()
	{
		if (gGame->lobby_connection)
			gGame->lobby_connection->RequestLeaveServer();
	}

	// enter server
	void StateLobby::EnterChannel(int id)
	{
		if (gGame->lobby_connection)
			gGame->lobby_connection->RequestEnterChannel(id);
	}

	// refresh server list
	void StateLobby::RefreshServerList()
	{
		if (gGame->lobby_connection)
			gGame->lobby_connection->RequestRefreshServerList();
	}

	// refresh channel list
	void StateLobby::RefreshChannelList()
	{
		if (gGame->lobby_connection)
			gGame->lobby_connection->RequestRefreshChannelList();
	}

	void StateLobby::OnChannelClientListChanged()
	{
		EventChannelClientListChanged.Fire(ptr_static_cast<StateLobby>(this), EventArgs());
	}

	void StateLobby::OnCreateGroup(TepGroupEventArgs& e)
	{
		EventCreatGroup.Fire(ptr_static_cast<StateLobby>(this), TepGroupEventArgs(e));
	}

	void StateLobby::OnInviteGroup(TepGroupEventArgs& e)
	{
		EventInviteGroup.Fire(ptr_static_cast<StateLobby>(this), TepGroupEventArgs(e));
	}

	void StateLobby::OnGetGroupMember(TepGroupMemberEventArgs& e)
	{
		EventGetGroupMember.Fire(ptr_static_cast<StateLobby>(this), TepGroupMemberEventArgs(e));
	}

	int StateLobby::GetChannelClientCount( int )
	{
		if (gGame->channel_connection)
			return gGame->channel_connection->channel_client_list.GetCount();	
		else
			return 0;
	}

	Client::ChannelClientInfo StateLobby::GetChannelClientInfo( int id )
	{
		if (gGame->channel_connection)
		{
			if (gGame->channel_connection->channel_client_list.IsValidIndex(id))
			{
				return gGame->channel_connection->channel_client_list[id];
			}
		}

		ChannelClientInfo info;
		info.character_id = 0;
		info.name = "";
		info.group = "";
		info.level = -1;
		info.is_vip = 0;
		info.is_gm = 0;

		return info;
	}

	void StateLobby::RequestCharacterAddress(const Core::String& cName, int userData)
	{
		if (gGame->lobby_connection)
		{
			gGame->lobby_connection->RequestCharacterAddress(cName, userData);
		}
	}

	void StateLobby::OnAddressArrived( int userData, const Core::String& name, byte online, const ClientAddress& address )
	{
		AddressEventArgs args;
		args.userdata = userData;
		args.name = name;
		args.online = online;
		args.address = address;
		EventAddressArrived.Fire(ptr_static_cast<StateLobby>(this), args);
	}
    //ƥ�� 
	void StateLobby::OnAddMatch(int match_id,const Core::String& match_name)
	{
		AddmatchEvenArgs args;
		args.match_id = match_id;
		args.match_name = match_name;
		EventMatchRoom.Fire(ptr_static_cast<StateLobby>(this), args);
	}

	void StateLobby::SwitchBGM( bool lobby )
	{
		if(lobby)
		{
			if(m_music_tune)
			{
				m_music_tune->stop();
			}
			if(m_music_lobby)
			{
				m_music_lobby->start();
			}
		}
		else
		{
			if(m_music_lobby)
			{
				m_music_lobby->stop();
			}
			if(m_music_lobby_storage)
			{
				m_music_lobby_storage->stop();
			}
			if(m_music_tune)
			{
				m_music_tune->start();
			}
		}
	}

	void StateLobby::OnChange_Lobby_Music(int type)
	{
		switch (type)
		{
		case 0:		// �ֿ������Ч
			m_music_lobby->stop();
			m_music_lobby_match->stop();
			m_music_lobby_storage->start();
			break;
		case 1:		// ƥ�������Ч
			m_music_lobby->stop();
			m_music_lobby_storage->stop();
			m_music_lobby_match->start();
			break;
		case 2:		// ��������Ч
			m_music_lobby->start();
			m_music_lobby_match->stop();
			m_music_lobby_storage->stop();
			break;
		}
	}

	Core::Vector2 StateLobby::GetScreenSize()
	{
		return gGame->screen->GetSize();
	}

	Core::Vector2 StateLobby::GetUIWindowSize()
	{
		return gGame->guiSys->GetSize();
	}

	Core::Vector2 StateLobby::GetCursorPos()
	{
		Core::Vector2 vPos = Core::Vector2::kZero;
		if (gGame)
		{
			if (gGame->input)
			{
				vPos = gGame->screen->ScreenToClient(gGame->input->GetCursorPosition());
				Core::Vector2 window_size = GetUIWindowSize();
				Core::Vector2 screen_size = GetScreenSize();
				vPos = Core::Vector2(vPos.x * window_size.x / screen_size.x, vPos.y * window_size.y / screen_size.y);
				return vPos;
			}
		}
		return Core::Vector2::kZero;
	}

	int StateLobby::HttpXLInfo(const Core::String& bugtitle, const Core::String& bugdesc, const Core::String& qq, const Core::String& phone, int type)
	{
		if(gGame)
			return gGame->HttpXLInfo(bugtitle.Str(), bugdesc.Str(), qq.Str(), phone.Str(), type);

		return -1;
	}

	int StateLobby::HttpXLReport(const Core::String& report_character_name, int report_type, const Core::String& report_desc)
	{
		if(gGame)
			return gGame->HttpXLReport(report_character_name.Str(),report_type,report_desc.Str());

		return -1;
	}

	//ս��ս
	void StateLobby::GetBattleGroupCreate(uint server_id, uint channel_id, uint room_id, RoomOption &roomoption)
	{
		if (gGame)
		{
			if (gGame->lobby_connection)
				gGame->lobby_connection->RequestBattleGroupCreate(server_id,channel_id,room_id,roomoption);
		}
	}

	void StateLobby::BattleGroupLeave(uint battlegroup_uid)
	{
		if (gGame)
		{
			if (gGame->lobby_connection)
				gGame->lobby_connection->RequestBattleGroupLeave(battlegroup_uid);
		}
	}

	void StateLobby::GetBattleGroupJoin(uint battlegroup_uid)
	{
		if (gGame)
		{
			if (gGame->lobby_connection)
				gGame->lobby_connection->RequestBattleGroupJoin(battlegroup_uid);
		}
	}

	void StateLobby::BattleGroupReady()
	{
		if (gGame)
		{
			if (gGame->lobby_connection)
				gGame->lobby_connection->RequestBattleGroupReady();
		}
	}

	void StateLobby::GetBattleGroups(const Core::String& group_name, uint start, uint count, byte is_searchonly)
	{
		if (gGame)
		{
			if (gGame->lobby_connection)
			{
				gGame->lobby_connection->RequestBattleGroups(group_name,start,count,is_searchonly);
				if(count == 7)
				{
					m_tiaozhan_request = true;
				}
			}
		}
	}

	void StateLobby::BattleGroupStartSearch(byte is_cancel)
	{
		if (gGame)
		{
			if (gGame->lobby_connection)
				gGame->lobby_connection->RequestBattleGroupStartSearch(is_cancel);
		}
	}

	BattleOtherPlayerInfo& StateLobby::GetBattlePlayerInfo(uint index)
	{	
			return m_battle_room->player[index];
	}

	void StateLobby::BattleGroupInvite(const Core::String& name)
	{
		if (gGame)
		{
			if (gGame->lobby_connection)
				gGame->lobby_connection->RequestBattleGroupInvite(name);
		}
	}

	void StateLobby::BattleGroupChallenge(uint battlegroup_uid)
	{
		if (gGame)
		{
			if (gGame->lobby_connection)
				gGame->lobby_connection->RequestBattleGroupChallenge(battlegroup_uid);
		}
	}
	void StateLobby::RequestTDData(int level_id, int map_level, int res_value, const Core::String& rand_key)
	{
		if (gGame->channel_connection)
		{
			gGame->channel_connection->RequestTDData(level_id, map_level, res_value, rand_key);
		}
	}

	void StateLobby::RequestMatching()
	{
		if (gGame->lobby_connection)
		{
			gGame->lobby_connection->RequestMatching();
		}
	}

	void StateLobby::RequestCancelMatching()
	{
		if (gGame->lobby_connection)
		{
			gGame->lobby_connection->RequestCancelMatching();
		}
	}

	
}
