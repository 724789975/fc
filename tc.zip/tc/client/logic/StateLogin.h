namespace Client
{
	class StateInit : public GameState
	{
	public:
		DECLARE_PDE_EVENT(EventInit,	Core::EventArgs);
		DECLARE_PDE_EVENT(EventLeave,	Core::EventArgs);

		virtual void OnEnter();
		virtual void OnLeave();
		virtual void OnUpdate(float frameTime);
		virtual void OnInput(InputEventArgs & e);

		float logo_timer;
	};

	class StateLogin : public GameState
	{
	public:
		DECLARE_PDE_EVENT(EventLeave,			Core::EventArgs);
		DECLARE_PDE_EVENT(EventLogin,			Core::EventArgs);
		DECLARE_PDE_EVENT(EventCreateNickNameFiled,  Core::EventArgs);
		DECLARE_PDE_EVENT(EventCreateNickName,  Core::EventArgs);
		DECLARE_PDE_EVENT(EventConnected,		Core::EventArgs);
		DECLARE_PDE_EVENT(EventDisconnected,	Core::EventArgs);
		DECLARE_PDE_EVENT(EventLoginSuccess,	Core::EventArgs);
		DECLARE_PDE_EVENT(EventVersionError,	Core::EventArgs);
		DECLARE_PDE_EVENT(EventEnterLobbySuccess, Core::EventArgs);

	public:
		// constructor
		StateLogin(bool disconnected = false);

		// on enter
		void OnEnter();

		// on leave
		void OnLeave();

		// on update
		void OnUpdate(float frameTime);

		// on input
		void OnInput(InputEventArgs & e);

		// on disconnected
		void OnDisconnect();

		// render
		void OnRender();

		// on connected
		void OnConnected();

		// on login success
		void OnLoginSuccess();

		// on login error
		void OnLoginError();

		void ResponseEnterLobby(int character_id, int playerchecktoday);

		void RequestEnterLobby();

		void OnCreateNickNameFiled(); 

		void OnShowNickNameWin();

		void RequestNickNameCreate(const Core::String& name);


	public:
		// login
		void Login(const Core::String & name, const Core::String & password);

		void LoginNew();

		// logout
		void Logout();

	public:
		bool disconnected;
		int uid;
		int character_id;
	};
}