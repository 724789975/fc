#include "../core/core.h"

#ifndef DIRECTINPUT_VERSION
#define DIRECTINPUT_VERSION         0x0800
#endif
#include <d3d9.h>
#include <d3dx9.h>
#include <dinput.h>
#include <xinput.h>
#include <xact3.h>
#include <xact3d3.h>

#if defined(min)
#undef  min
#endif

#if defined(max)
#undef  max
#endif

#define USE_UTF8
//#define USE_WEB

#ifdef MASTER
	#define DEBUG_CMD		0
	#define DEBUG_PHYSX		0	// physx debug line enable
	#define DEBUG_INFO		0	// show game info enable
	#define DEBUG_CAMERA	0	// debug camera enable
	#define DEBUG_SHADER	0	// debug shader enable
	#define DEBUG_PROFILER	0	// debug profiler
	#define DEBUG_TOOLS		0	// debug tools
	#define ACTIVE_APEX		1	// active_apex
#else
#ifdef NDEBUG
	#define DEBUG_CMD		1
	#define DEBUG_PHYSX		1	// physx debug line enable
	#define DEBUG_INFO		1	// show game info enable
	#define DEBUG_CAMERA	1	// debug camera enable
	#define DEBUG_SHADER	0	// debug shader enable
	#define DEBUG_PROFILER	1	// debug profiler
	#define DEBUG_TOOLS		1	// debug tools
	#define ACTIVE_APEX		1	// active_apex
#else
	#define DEBUG_CMD		1
	#define DEBUG_PHYSX		1	// physx debug line enable
	#define DEBUG_INFO		1	// show game info enable
	#define DEBUG_CAMERA	1	// debug camera enable
	#define DEBUG_SHADER	1	// debug shader enable
	#define DEBUG_PROFILER	1	// debug profiler
	#define DEBUG_TOOLS		1	// debug tools
	#define ACTIVE_APEX		1	// active_apex
#endif
#endif

/// 
//#include <ThemidaSDK.h>
//#include <VMProtectSDK.h>

/// physx include
#include <NxPhysics.h>
#include <NxCooking.h>
#include <NxStream.h>
#include <NxDebugRenderable.h>

#include <NxControllerManager.h>
#include <NxCapsuleController.h>
#include <NxController.h>
#include <NxBoxController.h>
#include <NxCapsuleController.h>

#include <CharacterController.h>
#include <SweptBox.h>
#include <SweptCapsule.h>
#include <NxRay.h>
#include <PhysXLoader.h>
#include <CCTDebugRenderer.h>
#include <SweptVolume.h>
#include <Controller.h>
#include <BoxController.h>
#include <NxScene.h>
#include <NxActor.h>
#include <NxBoxShapeDesc.h>
#include <CharacterControllerManager.h>
#include <CapsuleController.h>
#include <Nxp.h>
#include <NxTriangle.h>
#include <NxCapsuleShapeDesc.h>

#include <NxBox.h>
#include <NxCapsule.h>
#include <NxShape.h>
#include <NxBoxShape.h>
#include <NxSphereShape.h>
#include <NxCapsuleShape.h>
#include <NxConvexShape.h>
#include <NxConvexMesh.h>
#include <NxTriangleMeshShape.h>
#include <NxTriangleMesh.h>
#include <NxTriangleMeshDesc.h>
#include <NxHeightFieldShape.h>
#include <NxHeightField.h>
#include <NxExtended.h>

/// fmod include
#include <fmod.hpp>
//#include <fmod_codec.h>
//#include <fmod_dsp.h>
#include <fmod_errors.h>
//#include <fmod_memoryinfo.h>
//#include <fmod_output.h>
#include <fmod_event.hpp>

// nvidia api
#include <nvapi.h>

#include "resource/resource.h"

#include "system/resource/Resource.h"
#include "system/resource/ScriptLua.h"
#include "system/Input.h"
#include "system/Screen.h"
#include "system/Ati.h"
#include "render/Attribute.h"
#include "system/DirectX9.h"
#include "system/Texture.h"
#include "system/RenderTarget.h"
#include "render/Uniform.h"
#include "render/StreamBuffer.h"
#include "render/Shader.h"
#include "render/Material.h"
#include "system/Mesh.h"
#include "system/Physx.h"
#include "system/UIRender.h"
#include "system/Font.h"
#include "system/Console.h"
#include "system/fmod.h"
#include "system/ImeUi.h"
#include "system/systemprofile.h"
#include "system/MD5.h"
#include "system/randfun.h"

#include "gui/Utilities.h"
#include "gui/Image.h"
#include "gui/Icon.h"
#include "gui/skin.h"

#include "gui/Control.h"
#include "gui/CachedControl.h"
#include "gui/GuiSystem.h"

#include "gui/ScrollableControl.h"
#include "gui/ScrollBar.h"
#include "gui/Window.h"
#include "gui/Button.h"

#include "gui/AnimControl.h"
#include "gui/ChangeControl.h"
#include "gui/MouseControl.h"
#include "gui/CoolDownButton.h"
#include "gui/CommandQueue.h"
#include "gui/TextInput.h"
#include "gui/Textbox.h"
#include "gui/TextArea.h"
#include "gui/CheckBox.h"
#include "gui/Slider.h"
#include "gui/ComboList.h"
#include "gui/ComboBox.h"
#include "gui/Label.h"
#include "gui/ProportionBar.h"
#include "gui/AttributePlate.h"
#include "gui/Picture.h"
#include "gui/Tabpad.h"
#include "gui/Tabpage.h"
#include "gui/PageBar.h"
#include "gui/ItemBox.h"
#include "gui/ItemBoxBtn.h"
#include "gui/Menu.h"
#include "gui/ListItem.h"
#include "gui/ListTreeView.h"
#include "gui/Header.h"
#include "gui/ListTreeViewSP.h"
#include "gui/PropertyItem.h"
#include "gui/PropertyGrid.h"
#include "gui/PropertyView.h"
#include "gui/SplineView.h"
#include "gui/ToolTip.h"
#include "gui/MutexControl.h"
#include "gui/KeyBox.h"
#include "gui/ScrollNumberButton.h"
#include "gui/MailItem.h"
#include "gui/DragLabel.h"

#include "gui/Flowlayout.h"
#include "gui/ConsoleUI.h"
#include "gui/WindowUI.h"

#include "gui/RadioButton.h"
#include "gui/ButtonList.h"

#include "gui/ImageBrowser.h"

#include "gui/ChatWindow.h"
#include "gui/MessagePanel.h"
#include "gui/SquadBlock.h"
#include "gui/ModalControl.h"
#include "gui/Chart.h"
#include "gui/LobbyPList.h"
#include "gui/Balloon.h"
#include "gui/PopupFrame.h"
#include "gui/NoticeBoard.h"
#include "gui/CBWindow.h"
#include "gui/CharacterViewer.h"
#include "gui/CharacterSlot.h"
#include "gui/InGameMainButton.h"
#include "gui/ShaderControl.h"
#include "gui/ShaderButton.h"
#include "render/flash.h"
#include "gui/FlashControl.h"
#ifdef USE_WEB
#include "render/web.h"
#include "gui/WebControl.h"
#endif
#include "gui/Calendar.h"
#include "gui/RichEditor.h"
#include "game/Camera.h"
#include "game/DebugPrimitive.h"
#include "game/Animation.h"
#include "game/IkSolver.h"

#include "render/lod.h"
#include "render/Light.h"
#include "render/ParticleParameter.h"
#include "render/VertexDeclaration.h"
#include "render/ParticleResource.h"
#include "render/MeshResource.h"
#include "render/Primitive.h"
#include "render/particle.h"
#include "render/decal.h"
#include "render/Spray.h"
#include "render/DrawableObj.h"
#include "render/RenderPipeline.h"
#include "render/LobbyPipeline.h"
#include "render/LoginPipeline.h"
#include "render/D3DRender.h"

#include "game/SpiritBall.h"
#include "game/levelinfo.h"
#include "game/PVEWeapon.h"
#include "game/PVEAmmo.h"
#include "game/PVEAmmoLaser.h"
#include "game/PVELaser.h"
#include "game/PVELuncher.h"
#include "game/Weapon.h"
#include "game/Rifle.h"
#include "game/Pistol.h"
#include "game/SniperGun.h"
#include "game/ShotGun.h"
#include "game/SubMachineGun.h"
#include "game/MachineGun.h"
#include "game/Grenade.h"
#include "game/DualPistol.h"
#include "game/MiniGun.h"
#include "game/Knife.h"
#include "game/Bomb.h"
#include "game/CharacterInfo.h"
#include "game/Ammo.h"
#include "game/Luncher.h"
#include "game/CureGun.h"
#include "game/ZombieGun.h"
#include "game/ZombieCharge.h"
#include "game/Flamegun.h"
#include "game/MiniMachineGun.h"
#include "game/Drum.h"
#include "game/Milkbottle.h"
#include "game/BulletSmoke.h"
#include "game/Equipment.h"
#include "game/ToolsBox.h"
#include "game/DummyObject.h"
#include "game/GunTowerBuilder.h"
#include "game/GunTowerBuilderPlus.h"

//#include "game/Bow.h"
#include "game/Vehicle.h"
#include "game/Character/MoveController.h"
#include "game/Character/ActionController.h"
#include "game/Character/FirstPerson.h"
#include "game/Character/ThirdPerson.h"
#include "game/Character/Character.h"
#include "game/Character/Barbette.h"
#include "game/Bullet.h"
#include "game/ChatMessage.h"
#include "game/Gate.h"

#include "game/GunTarget.h"
#include "game/ActiveObject.h"
#include "game/AnimObject.h"

#include "game/Scene.h"
#include "game/ScoreBoard.h"
#include "game/Octree.h"

#include "game/ConnectionDef.h"
#include "game/ServerError.h"
#include "game/LevelEvent.h"
#include "game/Level.h"
#include "game/InGameUINew.h"
#include "game/AnimPicture.h"

#include "game/CharacterProfile.h"
#include "game/ChannelConnection.h"
#include "game/LobbyConnection.h"

#include "logic/GameState.h"
#include "logic/StateLogin.h"
#include "logic/StateSelectCharacter.h"
#include "logic/StateLobby.h"
#include "logic/StateMainGame.h"
#include "logic/StateGameLoading.h"
#include "logic/StateBalance.h"
#include "logic/StateMovie.h"
#include "logic/StateTest.h"

#include "logic/StateDebugAnim.h"
#include "logic/StateDebugScene.h"

#include "game/Languages.h"
#include "game/Description.h"

#include "game/GameConfig.h"
#include "game/GameGlobal.h"
#include "game/Game.h"
#include "game/Apex.h"
//#include "system/security/antihook.h"
//#include "system/security/antidll.h"
//#include "system/security/AntiDebug.h"
#define character_name_length	33*4
#define chat_length				200*4+1
#define group_name_length		64*4

namespace Client
{
	extern StartConfig gStartConfig;
	extern HttpConfig gHttpConfig;
	extern FaceBookInterface gFaceBookInterface;

	extern Game* gGame;
	extern Languages* gLang;
	extern Description* gDescription;
	extern Level* gLevel;
	extern D3DRender* gRender;
#if DEBUG_INFO
	extern DebugRender* gDebugRender;
#endif

	void HttpXlInfo();

	extern SystemInfoCollection g_SystemInfo_collection;
	extern InGameInfoCollection g_InGameInfo_collection;
	extern const int network_version;
}

#ifndef MASTER
#define CHECKAUTHTIME \
	{\
		if (time(NULL) >= g_BuildTimeStamp + (3600 * 24 * 15))\
		{\
			volatile int *p = NULL;\
			*p = 0;\
		}\
	}
#else
#define CHECKAUTHTIME
#endif
