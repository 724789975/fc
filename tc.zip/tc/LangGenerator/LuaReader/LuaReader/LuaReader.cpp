#include "../liblua/src/lua.h"
#include "../liblua/src/lualib.h"
#include "../liblua/src/lauxlib.h"

#include <string>
#include <iostream>
#include <fstream>

using namespace std;

int main(int argc, char *argv[])
{
	if (argc != 3)
	{
		cout<<"LuaReader luaFile outFile"<<endl;

		return 1;
	}

	int ret_code = 0;

	static const char BOM[3] = {(char)0xEF, (char)0xBB, (char)0xBF};

	ofstream out_file(argv[2]);
	if (!out_file)
	{
		cout<<"can`t open outFile"<<endl;

		return 1;
	}

	out_file.write(BOM, 3);

	lua_State* lua_state = luaL_newstate();

	int top = lua_gettop(lua_state);
	lua_newtable(lua_state);

	if (luaL_loadfile(lua_state, argv[1]) == 0)
	{
		lua_pushvalue(lua_state, top + 1);
		lua_setfenv(lua_state, -2);

		if (lua_pcall(lua_state, 0, 0, 0) == 0)
		{
			lua_getfield(lua_state, -1, "languages");
			int size = lua_rawlen(lua_state, -1);

			for (int i = 1; i <= size; i++)
			{
				lua_pushinteger(lua_state, i);
				lua_gettable(lua_state, -2);

				lua_pushinteger(lua_state, 1);
				lua_gettable(lua_state, -2);
				string key = lua_tostring(lua_state, -1);
				lua_pop(lua_state, 1);

				lua_pushinteger(lua_state, 2);
				lua_gettable(lua_state, -2);
				string value = lua_tostring(lua_state, -1);
				lua_pop(lua_state, 1);

				lua_pop(lua_state, 1);

				out_file<<"\""<<key<<"\",\""<<value<<"\""<<endl;
			}
		}
		else
		{
			string msg = lua_tostring(lua_state, -1);
			lua_pop(lua_state, 1);

			cout<<"lua error : "<<msg<<endl;

			ret_code = 1;
		}
	}
	else
	{
		string msg = lua_tostring(lua_state, -1);
		lua_pop(lua_state, 1);

		cout<<"lua error : "<<msg<<endl;

		ret_code = 1;
	}

	lua_close(lua_state);

	return ret_code;
}