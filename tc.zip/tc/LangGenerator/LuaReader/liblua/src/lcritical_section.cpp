#if defined(_WINDOWS)
#include <windows.h>
#elif defined(_XBOX)
#include <xtl.h>
#endif

#include "lstate.h"

void lua_create_criticalsection(lua_State *L)
{
#if _WINDOWS
	G(L)->critical_section = malloc(sizeof(CRITICAL_SECTION));
	InitializeCriticalSection((LPCRITICAL_SECTION)G(L)->critical_section);
#else
	G(L)->critical_section = malloc(sizeof(long));
#endif
}

void lua_delete_criticalsection(lua_State *L)
{
#if _WINDOWS
	DeleteCriticalSection((LPCRITICAL_SECTION)G(L)->critical_section);
	free(G(L)->critical_section);
#else
	free(G(L)->critical_section);
#endif
}

void lua_enter_criticalsection(lua_State *L)
{
#if _WINDOWS
	EnterCriticalSection((LPCRITICAL_SECTION)G(L)->critical_section);
#else
	while (InterlockedCompareExchange((volatile long*)G(L)->critical_section, 1, 0) == 0);
#endif
}

void lua_leave_criticalsection(lua_State *L)
{
#if _WINDOWS
	LeaveCriticalSection((LPCRITICAL_SECTION)G(L)->critical_section);
#else
	*(volatile long*)(G(L)->critical_section) = 0;
#endif
}

