﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

using LumenWorks.Framework.IO.Csv;

namespace CsvFileReader
{
    class Program
    {
        static void Main(string[] args)
        {
            if (args.Length != 2)
            {
                Console.WriteLine("CsvReader csvFile outFile\n");

                return;
            }

            const int CSV_KEY = 0;
            const int CSV_VALUE = 1;
            const int CSV_FIELD_COUNT = 2;

            int line = 1;
            //string newline = "\r\n";

            CsvReader csv = new CsvReader(new StreamReader(args[0]), false);
            StreamWriter out_file = new StreamWriter(args[1]);

            StringWriter data_buffer = new StringWriter();

            out_file.WriteLine("languages = ");
            out_file.WriteLine("{");

            while (csv.ReadNextRecord())
            {
                if (csv.FieldCount == CSV_FIELD_COUNT)
                {
                    //write
                    out_file.WriteLine("\t{\"" + csv[CSV_KEY] + "\",\"" + csv[CSV_VALUE] + "\"},");
                }
                else
                {
                    Console.WriteLine("line read error : " + line + " " + csv.FieldCount);
                }

                line++;
            }

            out_file.WriteLine("}");

            out_file.Write(data_buffer.ToString());

            out_file.Close();
        }
    }
}
