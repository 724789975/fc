﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Gui
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {
            FileDialog dialog = sender as FileDialog;

            if (dialog != null && e.Cancel == false)
            {
                textBox1.Text = dialog.FileName;
            }
        }

        private void saveFileDialog1_FileOk(object sender, CancelEventArgs e)
        {
            FileDialog dialog = sender as FileDialog;

            if (dialog != null && e.Cancel == false)
            {
                textBox2.Text = dialog.FileName;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                openFileDialog1.Filter = "csv文件(*.csv)|*.csv|所有文件(*.*)|*.*";
            }
            else if (radioButton2.Checked)
            {
                openFileDialog1.Filter = "lua文件(*.lua)|*.lua|所有文件(*.*)|*.*";
            }

            openFileDialog1.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                saveFileDialog1.Filter = "lua文件(*.lua)|*.lua|所有文件(*.*)|*.*";
            }
            else if (radioButton2.Checked)
            {
                saveFileDialog1.Filter = "csv文件(*.csv)|*.csv|所有文件(*.*)|*.*";
            }

            saveFileDialog1.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (textBox1.Text.Length == 0 ||
                textBox2.Text.Length == 0)
            {
                MessageBox.Show("请选择文件");

                return;
            }

            Process proc = new Process();

            proc.StartInfo.FileName = Process.GetCurrentProcess().MainModule.FileName;
            int pos = proc.StartInfo.FileName.LastIndexOf('\\');
            if (pos > 0)
                proc.StartInfo.FileName = proc.StartInfo.FileName.Remove(pos);

            if (radioButton1.Checked)
            {
                proc.StartInfo.FileName += "\\tool\\CsvReader.exe";
            }
            else if (radioButton2.Checked)
            {
                proc.StartInfo.FileName += "\\tool\\LuaReader.exe";
            }

            //proc.StartInfo.UseShellExecute = false
            proc.StartInfo.CreateNoWindow = false;
            proc.StartInfo.Arguments = "\"" + textBox1.Text + "\"  \"" + textBox2.Text + "\"";

            try
            {
                proc.Start();

                proc.WaitForExit();

                proc.Close();

                MessageBox.Show("转换完毕");
            }
            catch (Exception exp)
            {
                MessageBox.Show(exp.ToString());
            }
        }
    }
}
