﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

using LumenWorks.Framework.IO.Csv;

namespace CsvFileReader
{
    class Program
    {
        static void Main(string[] args)
        {
            if (args.Length != 2)
            {
                Console.WriteLine("CsvReader csvFile outFile\n");

                return;
            }

            const int CSV_BARBETTE_NAME = 0;
            const int CSV_WEAPON_INFO = 1;
            const int CSV_BARBETTE_POS = 2;
            const int CSV_BARBETTE_ROT = 3;
            const int CSV_CANNON_POS = 4;
            const int CSV_CANNON_ROT = 5;
            const int CSV_FIELD_COUNT = 6;

            int line = 1;
            string barbette_name = "";
            bool has_barbette = false;

            CsvReader csv = new CsvReader(new StreamReader(args[0]), false);
            StreamWriter out_file = new StreamWriter(args[1]);

            StringWriter data_buffer = new StringWriter();

            out_file.WriteLine("--Start BarbetteInfo");
            out_file.WriteLine("local cannon_info");
            out_file.WriteLine("local barbette");
            out_file.WriteLine("");

            while (csv.ReadNextRecord())
            {
                if (csv.FieldCount == CSV_FIELD_COUNT)
                {
                    if (csv[CSV_BARBETTE_NAME] != barbette_name)
                    {
                        has_barbette = true;

                        if (line != 1)
                        {
                            data_buffer.WriteLine("character:SetBarbetteInfo(barbette)\n\n");
                        }

                        barbette_name = csv[CSV_BARBETTE_NAME];

                        out_file.WriteLine("--Barbette : " + barbette_name);

                        //write GetWeaponInfo
                        out_file.WriteLine("function GetWeaponInfo_" + barbette_name + "()");
                        out_file.WriteLine("\tlocal weapon_info");
                        out_file.WriteLine(csv[CSV_WEAPON_INFO]);
                        out_file.WriteLine("\treturn weapon_info");
                        out_file.WriteLine("end\n");

                        //write GetBarbette
                        out_file.WriteLine("function GetBarbette_" + barbette_name + "()");
                        out_file.WriteLine("\tlocal barbette = ptr_new (\"Client.BarbetteInfo\")");
                        out_file.WriteLine("\tbarbette.name = " + "\"" + barbette_name + "\"");
                        out_file.WriteLine("\tbarbette.base_offset = " + "Vector3(" + csv[CSV_BARBETTE_POS] + ")");
                        out_file.WriteLine("\tbarbette.base_rotation = " + "Quaternion(" + csv[CSV_BARBETTE_ROT] + ")");
                        out_file.WriteLine("\t");
                        out_file.WriteLine("\tbarbette.weapon_info = " + "GetWeaponInfo_" + barbette_name + "()");
                        out_file.WriteLine("\t");
                        out_file.WriteLine("\treturn barbette");
                        out_file.WriteLine("end\n");

                        //write barbette
                        data_buffer.WriteLine("--Barbette : " + barbette_name);
                        data_buffer.WriteLine("barbette = GetBarbette_" + barbette_name + "()\n");
                    }
                    
                    {
                        //write cannon
                        data_buffer.WriteLine("cannon_info = ptr_new (\"Client.BarbetteInfo.CannonInfo\")");
                        data_buffer.WriteLine("cannon_info.offset = " + "Vector3(" + csv[CSV_CANNON_POS] + ")");
                        data_buffer.WriteLine("cannon_info.rotation = " + "Quaternion(" + csv[CSV_CANNON_ROT] + ")");
                        data_buffer.WriteLine("barbette:AddCannon(cannon_info)\n");
                    }
                }
                else
                {
                    Console.WriteLine("line read error : " + line + " " + csv.FieldCount);
                }

                line++;
            }

            if (has_barbette)
            {
                data_buffer.WriteLine("character:SetBarbetteInfo(barbette)\n\n");
            }

            out_file.Write(data_buffer.ToString());

            out_file.Close();
        }
    }
}
