#include "pch.h"

using namespace Core;
using namespace Client;

namespace Client
{
	enum EError
	{
		ERR_Read,
	};

	// constructor
	MessagePacket::MessagePacket(void* data, int size, int offset)
		: data_buffer(NULL)
		, data_size(0)
		, data_offset(0)
	{
		if (size > 0 && offset >= 0)
		{
			data_size = size + offset;

			data_buffer = allocator::malloc(data_size);

			if (offset > 0)
				memset(data_buffer, 0, offset);

			memcpy((char*)data_buffer + offset, data, size);

			data_offset = sizeof(float) + sizeof(byte);
			read_position = (char*)data_buffer + data_offset;
			read_end = (char*)data_buffer + data_size;
		}
		else
			throw ERR_Read;
	}

	// destructor
	MessagePacket::~MessagePacket()
	{
		if (data_buffer)
		{
			allocator::free(data_buffer);
			data_buffer = NULL;
		}
	}

	// get message type
	byte MessagePacket::GetMessageType()
	{
		if (data_buffer)
			return *((byte*)data_buffer + sizeof(float));

		return 0;
	}

	// get message time
	float MessagePacket::GetMessageTime()
	{
		if (data_buffer)
			return *(float*)data_buffer;

		return 0;
	}

	// set message time
	void MessagePacket::SetMessageTime(float time)
	{
		if (data_buffer)
		{
			*(float*)data_buffer = time;
		}
	}

	// reset
	void MessagePacket::Reset()
	{
		read_position = (char*)data_buffer + data_offset;
		read_end = (char*)data_buffer + data_size;
	}

	// write room option
	void WriteRoomOption(Core::BinaryNetworkStream & writer, const RoomOption & option)
	{
		writer.WriteString(option.name.Str());
		writer.WriteString(option.map_name.Str());
		writer.WriteByte(option.use_random_map);

		writer.WriteInt(option.level_id);
		writer.WriteInt(option.map_level);
		writer.WriteString(option.rand_key.Str());
		writer.WriteByte((byte&)option.character_id);
		writer.WriteByte((byte&)option.is_knife);
		writer.WriteByte((byte&)option.is_gm);

		writer.WriteByte(option.client_count);
		writer.WriteByte(option.viewer_count);

		writer.WriteByte(option.game_type);
		writer.WriteInt(option.rule_value);
		writer.WriteByte(option.special_mode);

		writer.WriteShort(option.round_rebirth_time_max);
		writer.WriteByte(option.dead_view_mode);
		writer.WriteByte((byte&)option.can_join_on_playing);
		writer.WriteByte((byte&)option.check_game_balance);
		writer.WriteByte((byte&)option.team_hurt);
		writer.WriteByte((byte&)option.group_match);
		writer.WriteByte((byte&)option.auto_start);


		writer.WriteByte(option.use_password);
		writer.WriteString(option.password.Str());

		writer.WriteInt(option.item_id);
		writer.WriteString(option.item_resource);
		writer.WriteString(option.item_name);
		writer.WriteByte(option.is_matching);
	}

	// read room option
	void ReadRoomOption(Core::BinaryNetworkReader & reader, RoomOption & option)
	{
		reader.ReadString(option.name);
		reader.ReadString(option.map_name);
		reader.ReadByte((byte&)option.use_random_map);

		reader.ReadInt(option.level_id);
		reader.ReadInt(option.map_level);
		reader.ReadString(option.rand_key);
		reader.ReadByte((byte&)option.character_id);
		reader.ReadByte((byte&)option.is_knife);
		reader.ReadByte((byte&)option.is_gm);

		reader.ReadByte((byte&)option.client_count);
		reader.ReadByte((byte&)option.viewer_count);

		reader.ReadByte((byte&)option.game_type);
		reader.ReadInt(option.rule_value);
		reader.ReadByte((byte&)option.special_mode);

		reader.ReadShort(option.round_rebirth_time_max);
		reader.ReadByte((byte&)option.dead_view_mode);
		reader.ReadByte((byte&)option.can_join_on_playing);
		reader.ReadByte((byte&)option.check_game_balance);
		reader.ReadByte((byte&)option.team_hurt);
		reader.ReadByte((byte&)option.group_match);
		reader.ReadByte((byte&)option.auto_start);


		reader.ReadByte((byte&)option.use_password);
		reader.ReadString(option.password);

		reader.ReadInt(option.item_id);
		reader.ReadString(option.item_resource);
		reader.ReadString(option.item_name);

		//reader.ReadByte(option.is_matching);

		g_InGameInfo_collection.level_id = option.level_id;
	}

	// read room info
	void ReadRoomInfo(Core::BinaryNetworkReader & reader, RoomInfo & info)
	{
		reader.ReadShort(info.id);
		reader.ReadInt(info.host_id);

		char name[64];
		int len = 64;
		reader.ReadString(name, len);
		info.host_name = name;
		reader.ReadByte(info.is_vip);
		reader.ReadByte(info.net_bar_level);
		reader.ReadInt(info.character_level);

		reader.ReadByte(info.state);
		reader.ReadByte((byte&)info.client_count);
		ReadRoomOption(reader, info.option);
	}

	// read client info
	void ReadClientInfo(Core::BinaryNetworkReader & reader, ClientInfo & info)
	{
		char temp[64];

		reader.ReadInt(info.id);
		reader.ReadInt(info.character_id);
		reader.ReadString(temp, sizeof(temp));
		info.name = temp;
		reader.ReadString(temp, sizeof(temp));
		info.group = temp;
		reader.ReadString(temp, sizeof(temp));
		info.icon = temp;
		reader.ReadInt(info.level);
		reader.ReadInt(info.exp);
		reader.ReadByte(info.team);
		reader.ReadByte(info.is_vip);
		reader.ReadByte(info.net_bar_level);
		reader.ReadByte(info.business_card);
		reader.ReadByte(info.is_gm);
		reader.ReadByte((byte&)info.ready);
		reader.ReadInt(info.top);
		reader.ReadInt(info.fightnum);
		reader.ReadFloat(info.win_rate);
		reader.ReadByte((byte&)info.is_host);
		reader.ReadByte((byte&)info.in_game);
	}

	// read room info
	void ReadRoomSlot(Core::BinaryNetworkReader & reader, RoomSlot & slot)
	{
		reader.ReadByte(slot.id);
		reader.ReadByte(slot.team);
		reader.ReadInt(slot.status);
		reader.ReadString(slot.preserve_character_name.RefStr(32));
	}
}
