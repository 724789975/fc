#pragma once
#define _CRT_SECURE_NO_WARNINGS

#include "../core/core.h"

//win
#include <windows.h>
#include <stdio.h>
#include <tchar.h>
#include <time.h>
#include <mstcpip.h>

#if defined(min)
#undef  min
#endif

#if defined(max)
#undef  max
#endif

#pragma comment(lib, "dxerr.lib" )
#pragma comment(lib, "dxguid.lib" )
#pragma comment(lib, "d3d9.lib" )
#pragma comment(lib, "dinput8.lib")
#pragma comment(lib, "xinput.lib")
#pragma comment(lib, "X3daudio.lib")

#if defined(DEBUG) || defined(_DEBUG)
#pragma comment(lib, "d3dx9d.lib" )
#else
#pragma comment(lib, "d3dx9.lib" )
#endif

#include "sdplayer.h"
#include "player.h"
#include "session.h"

#include "../client/game/ConnectionDef.h"

#include "bot/ChatMessage.h"
#include "bot/LobbyConnection.h"
#include "bot/ChannelConnection.h"
#include "bot/robot.h"
