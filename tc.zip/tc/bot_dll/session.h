#pragma once


// session manager
class Session
{
public:
	// constructor
	Session();

	// load session
	bool Load(const char * filename);

	// clear
	void Clear();

	// next
	bool Next(Core::String & name, Core::String & value);

private:
	Core::CriticalSection cs;
	Core::Array<Core::String> name_array;
	Core::Array<Core::String> value_array;
	U32 id;
};

extern Session session;