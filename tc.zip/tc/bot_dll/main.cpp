#include "pch.h"

using namespace Core;

static sharedc_ptr(IThread) bot_thread;


static bool MountPath(const char * path, Path::VFSAccess access, int priority)
{
	CStrBuf<MAX_PATH> temp;

	if (path == NULL)
		return false;

	// current directory
	if (path[0] == '~')
	{
		// current folder
		GetCurrentDirectoryA(temp.size32(), temp.buff());
		temp.calclen();
		temp.contract(path + 1);

		Path::MountVFS("/", temp.buff(), access, priority);
		return Path::Exists(temp.buff());
	}
	else
	{
		// get module file name
		GetModuleFileNameA(NULL, temp.buff(), temp.size32());
		Path::GetFilePath(temp, temp.buff());

		// convert to physical path
		temp.contract(path);

		Path::MountVFS("/", temp.buff(), access, priority);
		return Path::Exists(temp.buff());
	}

	return false;
}

void CalcFPS()
{
	static int frames = 0;

	struct Frame_Task : public Core::Task
	{
		void OnDispatch(IArguments & args)
		{
			frames ++;
			Task::Schedule(NullPtr, 0);
		}
	};

	struct FPS_Task : public Core::Task
	{
		void OnDispatch(IArguments & args)
		{
			LogSystem.WriteLinef("FPS: %d", frames);
			frames = 0;
			Task::Schedule(NullPtr, 1);
		}
	};

	Task::Post(ptr_new Frame_Task);
	Task::Post(ptr_new FPS_Task);
}

static U32 ThreadMain(void * arg)
{
	//CalcFPS();

	try
	{
		while (Thread::Running())
		{
			sharedc_ptr(Task) msg = Task::Receive();

			if (msg)
			{
				Task::Dispatch(msg);
			}
		}
	}
	catch (String & err)
	{
		LogSystem.WriteLinef("bot_test : core exception : %s", err.Str());
	}

	return 0;
}

BOOL APIENTRY DllMain(HMODULE hModule, DWORD  ul_reason_for_call, LPVOID lpReserved)
{
	switch(ul_reason_for_call)
	{
	case DLL_PROCESS_ATTACH:
		{
#ifndef MASTER
			Path::UnmountVFS("/");

			// develop data path
			if (!MountPath("../../../data/bot", Path::kVirtualReadWrite, 0))
			{
				// release data path
				MountPath("data/bot", Path::kVirtualReadWrite, 0);
			}
#endif
			// initialize thread
			Thread::Initialize();

			// init module system
			Module::Initialize();

			// initialize net
			SocketStream::Initialize();

			// load session
			session.Load("session.log");

			// create work thread
			bot_thread = Thread::CreateThread(0, &ThreadMain, NULL);
		}
		break;

	case DLL_PROCESS_DETACH:
		{
			bot_thread = NullPtr;

			// stop modules
			Module::StopAll();

			// unload modules
			Module::Terminate();

			// terminate thread
			Thread::Terminate();

			// close log output
			LogSystem.SetOutputStream(NULL);

			// destroy console
			Console.Terminate();

			// destroy net
			SocketStream::Terminate();
		}
	}

	return TRUE;
}

struct ResponseEventArgs : Core::EventArgs
{
	int action;
	int res;
	Core::String info;
};

//�����������ⲿ����ʹ�ô˺�������������
IPlayer* SDAPI CreatePlayer(LPCTSTR szVersion)
{
	sharedc_ptr(Bot::Robot) player = ptr_new Bot::Robot;
	player->Initialize(bot_thread);
	return player.ToPointer();
}

//�����������ⲿ����ʹ�ô˺������ٻ�����
BOOL SDAPI DestroyPlayer(IPlayer* lpPlayer)
{
	Player * player = dynamic_cast<Player*>(lpPlayer);

	if (player)
	{
		player->Terminate();
		return true;
	}

	return false;
}