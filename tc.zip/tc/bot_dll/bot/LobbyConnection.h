namespace Bot
{
	class Robot;
}

#include <map>

namespace Client
{
	class LobbyConnection : public Core::TcpConnection, public Core::BinaryNetworkStream
	{
	public:
		enum State
		{
			kDisconnected,
			kConnecting,
			kConnected,
			kAuthentication,
			kInLogin,
			kInLobby,
			kInChannel,
			kInGame,
		};

		// rpc callback delegate
		typedef void (LobbyConnection::*RpcCallback) (const Core::String &);

	public:
		// constructor.
		LobbyConnection();

		// destructor
		virtual ~LobbyConnection();

		// get state
		State GetState() { return (State)state; }

	public:
		// begin text rpc
		int BeginTextRpc(const char * func, RpcCallback callback);

		// add rpc argument
		void TextRpcArgument(const char * key, const char * value);

		// add rpc argument
		void TextRpcArgumentf(const char * key, const char * format, ...);

		// end text rpc
		void EndTextRpc();

		// request enter lobby
		void RequestEnterLobby(uint character_id);

		// request leave lobby
		void RequestLeaveLobby();

		// request channel connect
		void RequestChannelConnect(int channel_id);

		// request chat
		void RequestChat(const Core::Identifier & to, const Core::String & msg);

		// request create NickName
		void RequestCreateNickName(const Core::String & args);

		// team invite
		void RequestTeamInvite(const Core::String & name);

		// team join
		void RequestTeamJoin(const Core::String & name, uint uid);

		// team leave
		void RequestTeamLeave();

		// team kick
		void RequestTeamKick(const Core::String & name);

		// team change leader
		void RequestTeamChangeLeader(const Core::String & name);

		// request team refuse
		void RequestTeamRefuse(const Core::String & name, uint uid); 

		// request team call
		void RequestTeamCall(const Core::String & name);

		// request search room
		void RequestSearchRoom(Client::RoomSearchOptions & options);

		// request cancel search room
		void RequestCancelSearchRoom();

		// request refuse preserve
		void RequestRefusePreserve(const char * caller, int channel_id, int room_id, uint result);

		// request enter server
		void RequestEnterServer(int server_id);

		// request leave server
		void RequestLeaveServer();

		// request enter server
		void RequestEnterChannel(int server_id);

		// request leave server
		void RequestLeaveChannel();

		// request refresh server list
		void RequestRefreshServerList();

		// request refresh server list
		void RequestRefreshChannelList();
		
		
		// 
		void RequestLestPersonChannel(uint server_id);
		
		void RequestMatching();
		//
		void RequestMatchingTeamCreate(uint server_id, uint channel_id, uint room_id, RoomOption &roomop);
		

	public:
		Core::String login_name;
		Core::String login_pass;

	private:
		// parse message
		void OnMessage();

		// on connected
		void OnConnected();

		// on disconnected
		void OnDisconnected(bool is_error);

		// response
		void ResponseRPC();

		// response enter lobby
		void ResponseEnterLobby();

		// response leave lobby
		void ResponseLeaveLobby();

		// response channel connect
		void ResponseChannelConnect();

		// notiry chat
		void NotifyChat();

		// notify fcm change
		void NotifyFCM();

		// force disconnect
		void ForceDisconnect();

		// response team invite
		void ResponseTeamInvite();

		// response team invite
		void ResponseTeamJoin();

		// notify team invite
		void NotifyTeamInvite();

		// notify team member join
		void NotifyTeamMemberJoin();

		// notify team member leave
		void NotifyTeamMemberLeave();

		// notify team change leader
		void NotifyTeamChangeLeader();

		// notify team member info
		void NotifyTeamMemberInfo();

		// notify team change leader
		void NotifyTeamLeave();

		// notify team refuse
		void NotifyTeamRefuse();

		// notify room preserve
		void NotifyRoomPreserve();

		// notify room cancel preserve
		void NotifyRoomCancelPreserve();

		// response team call
		void ResponseTeamCall();

		// response team call
		void NotifyTeamCall();

		// response search room
		void ResponseSearchRoom();

		// notify update level list
		void NotifyUpdateLevelList();

		// notify refuse call
		void NotifyRefusePreserve();

		// notify rpc message
		void NotifyRPCMessage();

		// response enter server
		void ResponseEnterServer();

		// response leave server
		void ResponseLeaveServer();

		// notify refresh server list
		void NotifyRefreshServerList();

		// notify refresh channel list
		void NotifyRefreshChannelList();
		
		void OnResponseLestPersonChannel();
		void OnResponseMatchingTeamCreate();
		
		void OnResponseMatching();

	public:
		// parse lua rpc
		Lua::LuaState * LoadRPCResults(int action, const Core::String & ret);

	private:
		int rpc_request_id;
		int rpc_request_count;
		State state;

		// network encoder
		Core::XORNetworkEncoder xor_encoder;

		Core::DesNetworkEncoder des_encoder;

	public:
		uint uid;
		uint user_id;
		uint character_id;

		Core::String error_message;

		bool use_luncher;
		Core::String authentication_code;

		Core::String character_name;
		int	character_gender;

		Core::Array<Client::TeamMember> team_members;

		Core::Array<sharedc_ptr(Client::LevelInfo)>	level_list;

	public:
		tempc_ptr(Bot::Robot) bot;
		RpcCallback rpc_callback;

		bool keep_alive;
		int selected_server_id;
		int selected_channel_id;
		
		std::map<uint, ServerInfo> m_mapServerInfos;
	};
}