#include "pch.h"

DEFINE_PDE_TYPE_CLASS(Bot::ChatMessage)
{
	void OnRegister(by_ptr(Core::PdeTypeInfo) type)
	{
		ADD_PDE_FIELD(channel);
		ADD_PDE_FIELD(sender);
		ADD_PDE_FIELD(msg);
	}
};

REGISTER_PDE_TYPE(Bot::ChatMessage);