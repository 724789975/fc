namespace Bot
{
	class Robot : public Player
	{
	public:
		Robot();

		// on update
		virtual void OnUpdate();

		// on login
		virtual void OnLogin(int nLoginSign,bool bKeepAlive);

		// on login out
		virtual void OnLoginOut();

		// on action
		virtual void OnAction(int nAction, const Core::String & param);

		// on initialize
		virtual void OnInitialize();

		// on terminate
		virtual void OnTerminate();

		// on logine channel
		void OnLoginChannel(uint lobby_uid, uint character_id, Core::String character_name, int channel_id, char* address, ushort port);

		//find a room and enter room
		bool FindRoomAndEnter(const Core::String & room_name, int max_client, int game_type);

		//ready for game
		void StartGame();

		//room list changed
		void OnRoomListChanged();

		//on chat
		void SendChat(const Core::String & params);

		//parse param
		Core::String ParseParam(Core::CRefStr & Param);

		bool IsHostGame();

	public:
		// response action
		void ResponseAction(int nAction, int nRes, const Core::String & szInfo);

	public:
		sharedc_ptr(Client::LobbyConnection) lobby_connection;
		sharedc_ptr(Client::ChannelConnection) channel_connection;
		bool is_host_game;
		bool is_ready;

		Core::StaticBitArray<0x10000> action_running_flags;

		Core::Identifier send_who;
		float shoot_time;
	};
}