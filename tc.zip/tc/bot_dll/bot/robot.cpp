#include "pch.h"

using namespace Core;
using namespace Bot;
using namespace Client;

Robot::Robot()
: is_host_game(false)
, send_who(Core::Identifier::kNull)
, shoot_time(5.0f)
{
	action_running_flags.Resize(action_running_flags.Capacity());
	action_running_flags.Fill(false);

	status.curLogicState = LOGIC_IN_LOGIN;
}

// on login
void Robot::OnLogin(int nLoginSign, bool bKeepAlive)
{
	if (!IsOK())
	{
		lobby_connection = ptr_new LobbyConnection;
		lobby_connection->bot = ptr_static_cast<Robot>(this);
		lobby_connection->login_name = GetLoginName();
		lobby_connection->login_pass = GetLoginPwd();
		lobby_connection->keep_alive = bKeepAlive;
		lobby_connection->Connect(GetLoginIP(), GetLoginPort());
		action_running_flags.Resize(action_running_flags.Capacity());
		action_running_flags.Fill(false);

		action_running_flags.SetBit(AC_LOGIN_IN, true);
		if (lobby_connection->IsIdle())
		{
			LogSystem.WriteLinef("lobby is idle");
		}
	}
	else
	{
		LogSystem.WriteLinef("robot not ok");
	}
}

// on login out
void Robot::OnLoginOut()
{
	action_running_flags.SetBit(AC_LOGIN_OUT, true);

	if (lobby_connection)
		lobby_connection->Disconnect();

	if (channel_connection)
		channel_connection->Disconnect();
}

// response action
void Robot::ResponseAction(int nAction, int nRes, const Core::String & szInfo)
{
	if (nAction >= 0 && nAction < (int)action_running_flags.Size())
	{
		if (action_running_flags.GetBit(nAction))
		{
			action_running_flags.SetBit(nAction, false);
			Player::ResponseAction(nAction, nRes, szInfo);
		}
		else
		{
			Player::ResponseAction(nAction, RC_NONE, szInfo);
		}
	}
}

// on action
void Robot::OnAction(int nAction, const Core::String & params)
{
	if (nAction < 0 || nAction >= (int)action_running_flags.Size())
	{
		Player::ResponseAction(nAction, RC_FAILED, "action_not_supported");
		return;
	}

	// check bot running
	if (!IsOK())
	{
		Player::ResponseAction(nAction, RC_FAILED, "not_login");
		return;
	}

	// check action running flag.
	if (action_running_flags.GetBit(nAction))
	{
		Player::ResponseAction(nAction, RC_FAILED, "action_already_running");
		return;
	}

	// set action running flag.
	action_running_flags.SetBit(nAction, true);

	//LogSystem.WriteLinef("action : %x", nAction);

	// parse actions.
	switch (nAction)
	{
	case AC_LOGIN_OUT:
		OnLoginOut();
		break;

	case AC_CREATE_NICKNAME:
		{
			if (lobby_connection)
			{
				lobby_connection->RequestCreateNickName(params);
			}			
		}
		break;

	case AC_ENTER_LOBBY:
		{
			if (lobby_connection)
			{
				lobby_connection->RequestEnterLobby(atoi(params));
			}			
		}
		break;

	case AC_LEAVE_LOBBY:
		{
			if (lobby_connection)
			{
				lobby_connection->RequestLeaveLobby();
			}			
		}
		break;

	case AC_SERVER_LIST:
		{
			if (lobby_connection)
			{
				lobby_connection->RequestRefreshServerList();
			}			
		}
		break;

	case AC_ENTER_SERVER:
		{
			if (lobby_connection)
			{
				int server_id = atoi(params.Str());
				lobby_connection->RequestEnterServer(server_id);
			}			
		}
		break;

	case AC_LEAVE_SERVER:
		{
			if (lobby_connection)
			{
				lobby_connection->RequestLeaveServer();
			}

			// Ҫ��Ƶ���е�actionȥ��
			action_running_flags.SetBit(AC_ENTER_CHANNEL, false);
			action_running_flags.SetBit(AC_LEAVE_CHANNEL, false);
		}
		break;

	case AC_CHANNEL_LIST:
		{
			if (lobby_connection)
			{
				lobby_connection->RequestRefreshChannelList();
			}			
		}
		break;

	case AC_ENTER_CHANNEL:
		{
			if (lobby_connection)
			{
				int channel_id = atoi(params.Str());
				lobby_connection->RequestChannelConnect(channel_id);
			}
			
		}
		break;

	case AC_LEAVE_CHANNEL:
		{
			if (channel_connection)
			{
				channel_connection->Disconnect();
			}			
		}
		break;

	case AC_ROOM_LIST:
		{
			if (channel_connection)
			{
				channel_connection->RequestRoomList();
			}
			else
			{
				ResponseAction(AC_ROOM_LIST, RC_FAILED, "no_channel_connection");
			}
		}
		break;

	case AC_ENTER_ROOM:
		{
			if (channel_connection)
			{
				char room_name[32];
				int max_clients= 0;
				uint game_type = 0;
				if (3 == sscanf_s(params.Str(), "%s %d %d", room_name, sizeof(room_name), &max_clients, &game_type))
				{
					if(!FindRoomAndEnter(room_name, max_clients, game_type))
					{

						ResponseAction(AC_ENTER_ROOM, RC_FAILED, "room_not_found");
					}
				}
				else
				{
					ResponseAction(nAction, RC_FAILED, "arg error");
				}
			}
		}
		break;

	case AC_CREATE_ROOM:
		{
			if (channel_connection)
			{
				char room_name[32];
				uint level_id = 0;
				uint max_clients = 0;
				uint game_type = 0;
				uint rule_value = 0;
				if (5 == sscanf_s(params.Str(), "%s %d %d %d %d", room_name, sizeof(room_name), &level_id, &max_clients, &game_type, &rule_value))
				{
					if (lobby_connection->m_mapServerInfos[lobby_connection->selected_server_id].servertype != SvrType_Match)
					{
						if (FindRoomAndEnter(room_name, max_clients, game_type))
						{
							return;
						}
					}
					for (uint i = 0; i < lobby_connection->level_list.Size(); i++)
					{
						if (lobby_connection->level_list.IsValidIndex(i))
						{
							if(lobby_connection->level_list[i]->type == game_type)
							{
								channel_connection->default_room_option.name = room_name;
								channel_connection->default_room_option.game_type = (Client::RoomOption::GameType)game_type;
								channel_connection->default_room_option.rule_value = rule_value;
								channel_connection->default_room_option.level_id = lobby_connection->level_list[i]->id;
								channel_connection->default_room_option.map_name = lobby_connection->level_list[i]->name;
								if (lobby_connection->m_mapServerInfos[lobby_connection->selected_server_id].servertype == SvrType_Match)
								{
									channel_connection->default_room_option.is_matching = 1;
								}

								channel_connection->RequestRoomCreate(channel_connection->default_room_option);
								return;
							}
						}
					}
				}
				else
				{
					ResponseAction(nAction, RC_FAILED, "invalid_param");
				}
			}
		}
		break;

	case AC_LEAVE_ROOM:
		{
			if (channel_connection)
			{
				channel_connection->RequestRoomLeave();
			}
		}
		break;

	case AC_START_GAME:
		{
			if (channel_connection)
			{
				StartGame();
			}
		}
		break;

	case AC_LEAVE_GAME:
		{
			if (channel_connection)
			{
				channel_connection->LeaveGame();
			}
		}
		break;

	case AC_CHAT:
		{
			SendChat(params);
			//static Core::Identifier chat_to = Core::Identifier::kNull;
			//if (channel_connection)
			//{
			//	channel_connection->RequestChat(chat_to, params);
			//}
			//else if (lobby_connection)
			//{
			//	lobby_connection->RequestChat(chat_to, params);
			//}			
		}
		break;
		
	case AC_ENTER_MATCH:
		{
			if (lobby_connection)
			{
				lobby_connection->RequestLestPersonChannel(atoi(params));
			}
		}
		break;
	case AC_CREATE_MATCH_TEAM:
		{
			if (lobby_connection)
			{
				lobby_connection->RequestMatchingTeamCreate(channel_connection->address.server_id,
					channel_connection->address.channel_id, channel_connection->address.room_id, channel_connection->default_room_option);
			}
		}
		break;

	default:
		{
			ResponseAction(nAction, RC_FAILED, "action_not_supported");
		}
		break;

	}
}

// on intialize
void Robot::OnInitialize()
{
}

// on terminate
void Robot::OnTerminate()
{
}


// on update
void Robot::OnUpdate()
{
	if (lobby_connection && !lobby_connection->IsIdle())
	{
		lobby_connection->OnUpdate();
		lobby_connection->SendMessages();
	}

	if (channel_connection && !channel_connection->IsIdle())
	{
		channel_connection->OnUpdate();
		channel_connection->SyncPlayerData();

		//if (1)
		//{
		//	channel_connection->Ping();
		//}

		if (status.curLogicState == LOGIC_IN_GAME 
			&& channel_connection->career != 0 
			&& channel_connection->career != 5
			)
		{
			//channel_connection->SelectWeapon(rand() % 3);
			shoot_time -= 0.01f;
			if (shoot_time < 0)
			{
				channel_connection->Shoot(channel_connection->player_position, channel_connection->player_rotation);
				shoot_time = 0.1f;
			}
		}

		channel_connection->SendMessages();
	}

	if (channel_connection && channel_connection->IsIdle())
	{
		int channel_id = channel_connection->channel_id;
		channel_connection = NullPtr;

		status.curLogicState = LOGIC_IN_LOBBY;
		ResponseAction(AC_LEAVE_CHANNEL, RC_SUCCESSED, String::Format("%d", channel_id));
	}

	if (lobby_connection && lobby_connection->IsIdle())
	{
		Core::String error_message = lobby_connection->error_message;
		lobby_connection = NullPtr;

		status.curLogicState = LOGIC_IN_LOGIN;
		ResponseAction(AC_LOGIN_OUT, RC_SUCCESSED, error_message);
	}

	if (channel_connection)
	{
		if (channel_connection->GetState() == Client::ChannelConnection::kInRoom)
		{
			if (lobby_connection->m_mapServerInfos[lobby_connection->selected_server_id].servertype != SvrType_Match)
			{
				StartGame();
			}
		}
	}
}

//on loginchannel
void Robot::OnLoginChannel(uint lobby_uid, uint character_id, Core::String character_name, int channel_id, char* address, ushort port)
{
	channel_connection = ptr_new ChannelConnection;
	channel_connection->bot = ptr_static_cast<Robot>(this);
	channel_connection->lobby_uid = lobby_uid;
	channel_connection->character_id = character_id;
	channel_connection->character_name = character_name;
	channel_connection->address.channel_id = channel_id;
	
	channel_connection->address.server_id = lobby_connection->selected_server_id;
	channel_connection->Connect(address, port);
}

//find a room and enter room
bool Robot::FindRoomAndEnter(const Core::String & room_name, int max_client, int game_type)
{
	const U32 nRoomListSize = channel_connection->room_list.Size();
	for (uint i = 0; i < nRoomListSize; ++i)
	{
		if (channel_connection->room_list[i]->state == 2 && !channel_connection->room_list[i]->option.can_join_on_playing)
		{
		}
		else if (channel_connection->room_list[i]->client_count < Min(channel_connection->room_list[i]->option.client_count, max_client) &&
			channel_connection->room_list[i]->option.use_password == false &&
			channel_connection->room_list[i]->option.game_type == (Client::RoomOption::GameType)game_type)
		{
			if (room_name != "")
			{
				if (channel_connection->room_list[i]->option.name == room_name)
				{
					channel_connection->RequestRoomEnter(channel_connection->room_list[i]->id, "");
					channel_connection->room_info = *(channel_connection->room_list[i]);
					return true;
				}
			}
			else
			{
				channel_connection->RequestRoomEnter(channel_connection->room_list[i]->id, "");
				channel_connection->room_info = *(channel_connection->room_list[i]);
				return true;
			}			
			
		}
	}

	return false;
}

//ready for game
void Robot::StartGame()
{
	if (IsHostGame())
	{
		channel_connection->RequestGameStart();
	}

	else if (channel_connection->room_info.state == 2)
	{
		channel_connection->RequestGameEnter();
	}
	else
	{
		channel_connection->RequestRoomReady(true);
	}
}

//room list changed
void Robot::OnRoomListChanged()
{
	StartGame();
}

//on chat
void Robot::SendChat(const Core::String & params)
{
	if (params != "")
	{
		Core::String chat_info = params;
		Core::CRefStr msgLine = chat_info.RefStr();

		Core::String     send_what;

		if(msgLine.startwith("/m "))
		{
			msgLine.remove(0, 3);
			Core::String name = ParseParam(msgLine);
			if(name != "" && msgLine.calclen() > 0)
			{
				Core::CStrBuf<256> whisperline;
				Core::String content = Core::String(msgLine);
				send_who = Core::Identifier(name);
				send_what = content;
			}
		}
		else if (msgLine.startwith("/w "))
		{
		}
		else if (msgLine.startwith("/p "))
		{
		}
		else if (msgLine.startwith("/xlb "))
		{
			msgLine.remove(0, 5);
			Core::String content = ParseParam(msgLine);

			send_who = Core::Identifier("/xlb");
			send_what = content;
		}
		else if (msgLine.startwith("/dlb "))
		{
			msgLine.remove(0, 5);
			Core::String content = ParseParam(msgLine);
			
			send_who = Core::Identifier("/dlb");
			send_what = content;
		}
		else
		{
			send_who = Core::Identifier::kNull;
			send_what = msgLine;
		}

		if (channel_connection)
		{
			channel_connection->RequestChat(send_who, send_what);
		}
		else if (lobby_connection)
		{
			lobby_connection->RequestChat(send_who, send_what);
		}
		ResponseAction(AC_CHAT, RC_SUCCESSED, "success");
	}
	else
	{
		ResponseAction(AC_CHAT, RC_FAILED, "msg empty");
	}

}

//parse param
Core::String Robot::ParseParam(Core::CRefStr & Param)
{
	while (Param[0] == ' ')
	{
		Param.remove(0);
	}

	Core::CStrBuf<256> o;
	//ReMoveAllSpaceAhead(Param);
	while(Param.calclen() > 0 && Param[0] != ' ')
	{
		o.insert(o.calclen(), Param[0]);
		Param.remove(0);
	}
	Param.remove(0);
	return o;
}

bool Bot::Robot::IsHostGame()
{
	if (channel_connection)
	{
		if (channel_connection->character_id == 0)
		{
			return false;
		}
		return channel_connection->room_info.host_id == channel_connection->character_id;
	}
	return false;
}
