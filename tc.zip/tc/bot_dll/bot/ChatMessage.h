namespace Bot
{
	struct ChatMessage
	{
		Core::Identifier	channel;
		Core::String		sender;
		Core::String		msg;
	};
}