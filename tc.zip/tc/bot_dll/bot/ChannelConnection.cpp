#include "pch.h"
#include <time.h>
#define USE_COMPRESSOR 0
#define USE_ENCODER 0

using namespace Bot;
using namespace Core;
using namespace Client;

enum EServerMessage
{
	SM_NotifyChannelClientEnter,
	SM_NotifyChannelClientLeave,
	SM_NotifyRoomCreate,
	SM_NotifyRoomClose,
	SM_NotifyRoomClientCountChanged,
	SM_NotifyRoomClientEnter,
	SM_NotifyRoomClientLeave,
	SM_NotifyRoomClientUpdate,
	SM_NotifyRoomList,
	SM_NotifyRoomHostChanged,
	SM_NotifyRoomChangeOption,
	SM_NotifyRoomStateChanged,
	SM_NotifyRoomKickClient,
	SM_NotifyClientChangeTeam,
	SM_NotifyClientReady,
	SM_NotifyClientAutoStart,
	SM_NotifyClientAutoStartCancel,
	SM_NotifyGameStart,
	SM_NotifyGameClientEnter,
	SM_NotifyGameClientLeave,
	SM_NotifyGameEnd,
	SM_NotifyGameLeave,

	SM_ResponseChannelEnter,

	SM_ResponseRoomList,
	SM_ResponseRoomCreate,
	SM_ResponseRoomEnter,
	SM_ResponseRoomLeave,
	SM_ResponseRoomClientList,
	SM_ResponseRoomChangeOption,
	SM_ResponseRoomChangeTeam,
	SM_ResponseRoomReady,
	SM_ResponseGameStart,
	SM_ResponseRoomChangeSlotStatus,
	SM_NotifyRoomChangeSlotStatus,
	SM_ResponseRoomChangeSlot,
	SM_NotifyClientChangeSlot,
	SM_ResponseRoomPreserveSlot,
	SM_ResponseClientList,
	SM_ResponseTDData,

	// ģʽ�޹���Ϣ start
	SM_ResponseGameEnter = 100,	// response client enter			(done)
	SM_NotifyChat,				// chat								(done)
	SM_CharacterInfo,			// server tells character info		(done)
	SM_Loading,					// server tell loading				(done)
	SM_ClientJoin,				// send when a client joined game.	(done)
	SM_ClientLeave,				// send when a client leaved game.	(done)
	SM_SyncPlayerData,			// sync player data.				(done)
	SM_PlayerSpawn,				// tells a player had spawned.		(done)
	SM_BotSpawn,				// tells a bot had spawned.			(done)
	SM_PlayerPoke,				// a player is poking.
	SM_PlayerPokeHurt,			// a player poke hurt.
	SM_PlayerShoot,				// a player is shooting.
	SM_PlayerGrenadeThrowIn,	// a player is throwing a grenade.
	SM_PlayerGrenadeThrowStop,	// a player is throwing a grenade.
	SM_PlayerGrenadeThrowOut,	// a player is throwing a grenade.
	SM_PlayerHurt,				// a player hurt himself.
	SM_PlayerGrenadeHurt,		// a player hurt by greande.
	SM_PlayerReload,			// a player is reloading.
	SM_PlayerDropWeapon,		// a player is drop weapon
	SM_PlayerPickUpWeapon,		// a player is pick up weapon
	SM_PlayerSelectWeapon,		// a player is select a weapon
	SM_DestroyDroppedWeapon,	// dropped gun destroy
	SM_SyncTime,				// sync global time.				(done)
	SM_GameLeave,				// game leave						(done)
	SM_PlayerSetTeam,			// player set team
	SM_HealthRecover,			// health recover
	SM_PlayerSpawnTiming,		// player spawn timing				(done)
	SM_PlayerRecoverStop,		// player stop recover
	SM_PlayerKickBack,			// player shoot kickback
	SM_PlayerFlashBright,		// player flash bright
	SM_PlayerCameraFovChanged,	// palyer camera fov changed
	SM_AddDroppedWeapon,		// add dropped weapon				(done)
	SM_AddSupplyObject,			// add supply object				(done)
	SM_DestroySupplyObject,		// supply object destroy
	SM_PickUpSupplyObject,		// pick up supply object
	SM_AmmoRecover,				// ammo recover
	SM_AmmoDisappear,			// ammo disappear
	SM_ArmorRecover,			// armor recover
	SM_UseSkill,				// use skill
	SM_UseCureSkill,			// use cure skill
	SM_ChangePack,				// change pack
	SM_KickClientStart,			// kick client start
	SM_KickClientError,			// kick client error				(done)
	SM_KickClientVote,			// kick client vote					(done)
	SM_KickClientEnd,			// kick client end
	SM_RadioReport,				// radio report
	SM_PlayerReloadReady,		// a player reload ready.
	SM_PlayerActionOn,			// player action on changed
	SM_ProjectedAmmoOut,		// a player is fire a ProjectedAmmo.
	SM_ProjectedAmmoDestroy,	// a player is destroy a ProjectedAmmo.
	SM_ProjectedAmmoUpdate,		// a player is updating a ProjectedAmmo
	SM_ProjectedAmmoHurt,		// a player hurt by ProjectedAmmo.
	SM_ProjectedProdHurt,
	SM_PlayerAnimationStart,	// animation start
	SM_PlayerAnimationEnd,		// animation end
	SM_CallDoctor,				// call doctor
	SM_PlayerHitBack,
	SM_PlayerFlameShoot,		// player flame shoot
	SM_PlayerSustainHurt,		// sustain hurt
	SM_ControlPerson,			// control person
	SM_RevengPerson,
	SM_DrumEffect,				// drum check
	SM_Drink,					// drink
	SM_Cure_Power,
	SM_PlayerSpray,
	SM_PlayerSprayClear,
	SM_ChangeAmmoTeam,
	SM_SyncSkillEffect,
	SM_SpawnCoin,
	SM_AddDropSupply,			// drop supply
	SM_PickUpSupplyObjectNew,	// pick up supply object new
	SM_SynServerScriptValue,	//
	SM_SynScore,				//
	SM_MessageClient,			//
	SM_PVEAmmoOut,				//
	SM_PVEAmmoDestroy,			//
	SM_PVEAmmoHitHurt,			//
	SM_PVEAmmoExplodeHurt,		//
	SM_PVEAmmoUpdate,			//
	SM_CutHurt,					//
	SM_DummyObjectCreate,		//
	SM_DummyObjectDestory,		//
	SM_DummySyncUpdate,			//
	SM_DummyChangeOwner,		//
	SM_GunTowerShoot,
	SM_GunTowerHurt,
	SM_Teleport,
	SM_SkillHurt,				//
	SM_RefreshBagItem,
	SM_DIE_BUFF_DATA,
	// ģʽ�޹���Ϣ end

	// ģʽ�����Ϣ start
	// ģʽͨ��
	SM_Authentication,			// server authentication			(done)
	SM_Initialize,				// server tells initialize info.	(done)
	SM_GameEnd,					// game end							(done)
	SM_RoundStart,				// round start						(done)
	SM_RoundStartPlay,			// round start play					(done)
	SM_RoundEnd,				// round end
	// ռ��ģʽ
	SM_SyncHoldPointInfo,		// sync hold point info
	// �Ƴ�ģʽ
	SM_InitializePushVehiclePointInfo,
	SM_UpdatePushVehiclePointInfo,	// push vehicle info
	// ѵ����
	SM_NoviceOperation,
	// BOSSģʽ
	SM_Boss_Flash,
	SM_Number_Timer,
	SM_BossModeAliveChanged,
	// ����ģʽ
	SM_StartPlantBomb,
	SM_CancelPlantBomb,
	SM_PlantBombSuccess,
	SM_PickUpBomb,
	SM_StartDefuseBomb,
	SM_BombExploded,
	SM_DefuseBombSuccess,
	// ���ģʽ
	SM_StreetKing_Flash,
	//����ģʽ
	SM_Zombie_Flash,
	SM_Zombie_Mode_PlayerDying,
	SM_Zombie_Mode_StartSaveDying,
	SM_Zombie_Mode_CancelSaveDying,
	SM_Zombie_Mode_Human_Respawn,
	SM_Zombie_Mode_Step_Two,
	SM_Zombie_Mode_StartGame,
	SM_ZombieBomer,		// zombie bomer
	SM_ZombieBomerHurt,	// zombie bomer hurt
	SM_ChargeSomething, // ײ��������
	//��ͳ����
	SM_CommonKingZombie_Flash,
	SM_CommonZombie_Flash,
	SM_CommonZombie_LevelChange,
	SM_CommonZombie_EnergyChange,
	SM_CommonZombie_Super,
	SM_CommonHuman_Super,
	SM_CommonZombie_Unable,
	SM_King_Zombie_Respawn,
	SM_HumanEnergyChange,
	SM_HumanPowerUp,
	SM_UseSkillSuperMan,
	SM_SkillSuperManSuccess,
	SM_CommonZombieHumanDie,
	SM_CancelInvisible,
	SM_UseSmog,
	//bosspveģʽ
	SM_SycnBossAction,
	//boss2ģʽ
	SM_Boss2_Flash,
	SM_Boss2_Showtime,
	SM_Boss2_SyncData,
	//����ս
	SM_UseItem_ItemMode,
	SM_ItemMode_ZiBao,
	SM_ItemMode_SyncData,
	//TDģʽ
	SM_TDMode_ResHpChange,
	//MoonMode
	SM_MoonMode_PickWin,
	//SurvivalMode
	SM_UseItem_SurvivalMode,
	SM_UseItem_Trap,
	SM_UseItem_Trap_Trigger,
	SM_Trap_HP_Disappear,
	SM_SurvivalMode_Ghost,
	// ģʽ�����Ϣ end
};

enum EClientMessage
{
	CM_RequestChannelEnter,

	CM_RequestRoomList,
	CM_RequestRoomCreate,
	CM_RequestRoomEnter,
	CM_RequestRoomLeave,
	CM_RequestRoomClientList,
	CM_RequestRoomChangeOption,
	CM_RequestRoomChangeTeam,
	CM_RequestRoomReady,
	CM_RequestRoomKickClient,
	CM_RequestGameStart,
	CM_RequestRoomChangeSlotStatus,
	CM_RequestRoomChangeSlot,
	CM_RequestRoomPreserveSlot,
	CM_RequestRoomTeamEnter,
	CM_RequestClientList,
	CM_RequestNovice,
	CM_RequestTDData,

	CM_ConnectionCheck,

	CM_RequestRoomEnterWithSlotId,

	// ģʽ�޹���Ϣ start
	CM_RequestGameEnter = 100,	// game enter request
	CM_RequestChat,				// chat												(done)
	CM_ReadyForGame,			// finished preparing resource, ready to join game.	(done)
	CM_SyncPlayerData,			// sync player data.								(done)
	CM_Shoot,					// shooting.
	CM_Poke,					// poking.
	CM_PokeHurt,				// poke hurt.
	CM_GrenadeThrowIn,			// throwing a grenade.
	CM_GrenadeThrowStop,		// throwing a grenade.
	CM_GrenadeThrowOut,			// throwing a grenade.
	CM_Hurt,					// hurt myself.
	CM_GrenadeHurt,				// hurt by grenade.
	CM_Reload,					// reloading
	CM_DropWeapon,				// drop Weapon
	CM_PickUpWeapon,			// pick up Weapon
	CM_SelectWeapon,			// select weapon
	CM_LeaveGame,				// leave game										(done)
	CM_KickBack,				// kick back
	CM_FlashBright,				// flash bright
	CM_CameraFovChanged,		// camera fov changed
	CM_PickUpSupplyObject,		// pick up supply obejct
	CM_UseSkill,				// use skill
	CM_ChangePack,				// change pack
	CM_KickClientStart,			// kick client start
	CM_KickClientVote,			// kick client vote
	CM_Suicide,					// suicide
	CM_RadioReport,				// radio report
	CM_SpawnConfirm,			// spawn confirm									(done)
	CM_ReloadReady,				// reload ready
	CM_ActionOn,				// player action on changed
	CM_ProjectedAmmoOut,		// fire a ProjectedAmmo.
	CM_ProjectedAmmoDestroy,	// destroy a ProjectedAmmo.
	CM_ProjectedAmmoUpdate,		// update a ProjectedAmmo
	CM_ProjectedAmmoHurt,		// hurt by ProjectedAmmo.
	CM_ProjectedProdHurt,		// hurt by ProjectedProd.
	CM_ChangeCareer,			//													(done)
	CM_CureCharacter,			//
	CM_PlayerAnimationStart,	// animation start
	CM_PlayerAnimationEnd,		// animation end
	CM_CallDoctor,				// call doctor
	CM_PlayerFlameShoot,		// player flame shoot
	CM_StopBurn,				// stop burn
	CM_DrumCheck,				// drum check
	CM_Drink,					// drink
	CM_Spray,					// spray
	CM_ChangeAmmoTeam,			// change ammo team
	CM_UseSpawnCoin,
	CM_PickUpSupplyObjectNew,	// pick up supply object new
	CM_OpenMessageClient,
	CM_PVEAmmoOut,				//
	CM_PVEAmmoDestroy,			//
	CM_PVEAmmoHitHurt,			//
	CM_PVEAmmoExplodeHurt,		//
	CM_PVEAmmoUpdate,			//
	CM_CutHurt,					//
	CM_DummyObjectCreate,		//
	CM_DummyObjectDestory,		//
	CM_DummySyncUpdate,			//
	CM_GunTowerShoot,			//
	CM_DummyPokeHurt,			//
	CM_DummyProjectedAmmoHurt,	//
	CM_DummyGrenadeHurt,
	CM_DummyProjectedProdHurt,
	CM_CharacterHeal,
	CM_Teleport,
	CM_ForceSpawn,
	CM_UseItem,
	CM_NEED_DIE_BUFF,
	// ģʽ�޹���Ϣ end
	
	// ģʽ�����Ϣ start
	// ѵ����
	CM_NoviceOperation,			// novice operation
	// ����ģʽ
	CM_StartPlantBomb,
	CM_CancelPlantBomb,
	CM_StartDefuseBomb,			// defuse bomb
	CM_CancelDefuseBomb,
	// ����ģʽ
	CM_StartSaveDying,
	CM_CancelSaveDying,
	CM_ChargeSomething,		

	//��ͨ����
	CM_SkillKickBack,
	CM_UseSkillSuperMan,
	CM_CancelInvisible,
	CM_UseSmog,
	CM_SomgAreaCancel,
	//����ս
	CM_UseItem_ItemMode,
	CM_ItemMode_ZiBao,
	//TD�༭ģʽ
	CM_SAVE_MAP,
	//�����ʵ�
	CM_MoonBoss,
	//SurvivalMode
	CM_UseItemSurvival,
	CM_UseItemSurvivalByGhost,
	// ģʽ�����Ϣ end
};

enum EPlayerData
{
	PD_None				= 0,
	PD_Status			= 1 << 0,
	PD_Rotation			= 1 << 1,
	PD_Position			= 1 << 2,
	PD_Ping				= 1 << 3,
};

enum EPlayerStatus
{
	PS_None				= 0,
	PS_Jump				= 1 << 0,
	PS_OnGround			= 1 << 1,
	PS_Crouch			= 1 << 2,
	PS_Walk				= 1 << 3,
	PS_MoveForward		= 1 << 4,
	PS_MoveBack			= 1 << 5,
	PS_MoveLeft			= 1 << 6,
	PS_MoveRight		= 1 << 7,
	PS_Fly				= 1 << 8,
	PS_Boost			= 1 << 9,
};

enum EError
{
	ERR_ReadStream,
	ERR_Write,
	ERR_Auth,
	ERR_Closed,
	ERR_Socket,
};

void ChannelConnection::WriteCharacterPosition(const Vector3 & position)
{
	short x, y, z;

	x = (short)Clamp(position.x * 128.f, -32767.f, 32767.f);
	y = (short)Clamp(position.y * 128.f, -32767.f, 32767.f);
	z = (short)Clamp(position.z * 128.f, -32767.f, 32767.f);

	WriteShort(x);
	WriteShort(y);
	WriteShort(z);
}

void ChannelConnection::ReadCharacterPosition(Vector3 & position)
{
	short x, y, z;

	ReadShort(x);
	ReadShort(y);
	ReadShort(z);

	position.x = (float)x / 128.f;
	position.y = (float)y / 128.f;
	position.z = (float)z / 128.f;
}

void ChannelConnection::WriteCharacterRotation(const Quaternion & rotation)
{
	Vector3 r = rotation.GetZXY();
	WriteShort((short)(r.x * 8192.f));
	WriteShort((short)(r.y * 8192.f));
}

void ChannelConnection::ReadCharacterRotation(Quaternion & rotation)
{
	short x, y;

	ReadShort(x);
	ReadShort(y);

	rotation.SetZXY(Vector3((float)x / 8192.f, (float)y / 8192.f, 0));
}

void ChannelConnection::ReadCharacterRotation(Core::BinaryNetworkReader & reader, Quaternion & rotation)
{
	short x, y;

	reader.ReadShort(x);
	reader.ReadShort(y);

	rotation.SetZXY(Vector3((float)x / 8192.f, (float)y / 8192.f, 0));
}

// -----------------------------------------------------------------
// ChannelConnection functions
// -----------------------------------------------------------------
// constructor.
ChannelConnection::ChannelConnection()
: character_id(0)
, career(0)
{
	connection = this;
	stream = this;

	for (uint i = 0; i < room_slots.Size(); i ++)
	{
		room_slots[i].id = 0;
		room_slots[i].team = 0;
		room_slots[i].status = RoomSlot::kClosed;
	}

	has_level_list = false;
}

// destructor
ChannelConnection::~ChannelConnection()
{
	Disconnect();
}

// on message
void ChannelConnection::OnMessage()
{
	switch (state)
	{
	case kConnected:
		{
			byte msg;
			ReadByte(msg);

			//LogSystem.WriteLinef("%s, %s, name : %s,  state : %d, msg : %d", __FILE__, __FUNCTION__, character_name, state, msg);
			switch (msg)
			{
			case SM_ResponseChannelEnter:		ResponseChannelEnter();		break;
			}
		}
		break;

	case kInChannel:
		{
			byte msg;
			ReadByte(msg);

			//LogSystem.WriteLinef("%s, %s, name : %s,  state : %d, msg : %d", __FILE__, __FUNCTION__, character_name, state, msg);
			switch (msg)
			{
			case SM_ResponseRoomList:		ResponseRoomList();			break;
			case SM_ResponseRoomCreate:		ResponseRoomCreate();		break;
			case SM_ResponseRoomEnter:		ResponseRoomEnter();		break;
			case SM_ResponseClientList:		break;// ResponseClientList();		break;
			case SM_ResponseTDData:			break;//ResponseTDData();			break;

			case SM_NotifyRoomCreate:		NotifyRoomCreate();			break;
			case SM_NotifyRoomClose:		NotifyRoomClose();			break;
			case SM_NotifyRoomList:			NotifyRoomList();			break;
			case SM_NotifyRoomChangeOption:	NotifyRoomChangeOption();	break;
			case SM_NotifyRoomStateChanged:	NotifyRoomStateChanged();	break;
			case SM_NotifyRoomHostChanged:	NotifyRoomHostChanged(*this);	break;
			case SM_NotifyRoomClientCountChanged:	NotifyRoomClientCountChanged();	break;
			case SM_NotifyChat:				break;//ParseNotifyChat(*this);				break;

			default:
				{
					LogSystem.WriteLinef("%s, %s, getmessage state : %d, message %d, can't find msg", __FILE__, __FUNCTION__, state, msg);
				}break;
			
			}
		}
		break;

	case kInRoom:
	case kInBalance:
		{
			byte msg;
			ReadByte(msg);

			//LogSystem.WriteLinef("%s, %s, name : %s,  state : %d, msg : %d", __FILE__, __FUNCTION__, character_name, state, msg);
			switch (msg)
			{
				//todo
				case SM_ResponseRoomCreate:		ResponseRoomCreate();		break;
			case SM_NotifyRoomClientEnter:			NotifyRoomClientEnter();		break;
			case SM_NotifyRoomClientLeave:			NotifyRoomClientLeave();		break;
			case SM_NotifyRoomClientUpdate:			NotifyRoomClientUpdate();		break;
			case SM_NotifyRoomChangeOption:			NotifyRoomChangeOption();		break;
			case SM_NotifyRoomStateChanged:			NotifyRoomStateChanged();		break;
			case SM_NotifyClientChangeTeam:			NotifyClientChangeTeam();		break;
			case SM_NotifyClientReady:				NotifyClientReady();			break;
			case SM_NotifyClientAutoStart:			break;//NotifyClientAutoStart();		break;
			case SM_NotifyClientAutoStartCancel:	break;//NotifyClientAutoStartCancel();	break;
			case SM_NotifyGameStart:				break;//NotifyGameStart();				break;
			case SM_NotifyGameEnd:					NotifyGameEnd();				break;
			case SM_NotifyGameLeave:				break;//NotifyGameLeave();				break;
			case SM_NotifyGameClientEnter:			break;//NotifyGameClientEnter();		break;
			case SM_NotifyGameClientLeave:			break;//NotifyGameClientLeave();		break;
			case SM_NotifyRoomHostChanged:			NotifyRoomHostChanged(*this);	break;

			case SM_ResponseRoomLeave:			ResponseRoomLeave();		break;
			case SM_ResponseRoomClientList:		ResponseRoomClientList();	break;
			case SM_ResponseRoomChangeOption:	ResponseRoomChangeOption();	break;
			case SM_ResponseRoomChangeTeam:		ResponseRoomChangeTeam();	break;
			case SM_ResponseRoomChangeSlot:		ResponseRoomChangeSlot();	break;
			case SM_ResponseRoomReady:			ResponseRoomReady();		break;
			case SM_ResponseGameStart:			ResponseGameStart();		break;
			case SM_ResponseGameEnter:			ResponseGameEnter();		break;
			case SM_NotifyChat:					NotifyChat(*this);				break;
			case SM_NotifyRoomKickClient:		NotifyRoomKickClient();		break;
			case SM_NotifyClientChangeSlot:		NotifyClientChangeSlot();	break;
			case SM_ResponseRoomChangeSlotStatus: ResponseRoomChangeSlotStatus(); break;
			case SM_NotifyRoomChangeSlotStatus:	NotifyRoomChangeSlotStatus(); break;
			case SM_ResponseRoomPreserveSlot:	break;//ResponseRoomPreserveSlot();	break;
			case SM_ResponseClientList:			break;// ResponseClientList();	break;
			case SM_ResponseTDData:				break;// ResponseTDData();		break;
			default:
				{
					LogSystem.WriteLinef("%s, %s, getmessage state : %d, message %d, can't find msg", __FILE__, __FUNCTION__, state, msg);
				}break;
			}
		}
		break;

	case kInGame:
		OnMessageGame();
		break;
	}
}


// on connected
void ChannelConnection::OnConnected()
{
	state = kConnected;

#if USE_COMPRESSOR
	huffman_compressor.Reset();
	compressor = &huffman_compressor;
#endif

#if USE_ENCODER
	//xor_encoder.Reset();
	//encoder = &xor_encoder;
#endif

	RequestChannelEnter();
}

// on disconnected
void ChannelConnection::OnDisconnected(bool is_error)
{
	OnLeaveChannel();
}

// request channel enter
void ChannelConnection::RequestChannelEnter()
{
	if (state == kConnected)
	{
		BeginWrite();
		WriteByte(CM_RequestChannelEnter);
		WriteInt(lobby_uid);
		WriteInt(character_id);
		EndWrite();

		// start encoding
	}
	else
	{
		bot->ResponseAction(AC_ENTER_CHANNEL, RC_FAILED, "wrong_state");
	}
}

// request room list
void ChannelConnection::RequestRoomList()
{
	if (state == kInChannel)
	{
		BeginWrite();
		WriteByte(CM_RequestRoomList);
		EndWrite();
	}
	else
	{
		bot->ResponseAction(AC_ROOM_LIST, RC_FAILED, "wrong_state");
	}
}

/*
// write room option
void ChannelConnection::WriteRoomOption(const RoomOption & option)
{
	WriteString(option.name.Str());
	WriteString(option.map_name.Str());
	WriteByte(option.use_random_map);

	WriteInt(option.level_id);
	WriteInt(option.map_level);
	WriteString(option.rand_key.Str());
	WriteByte((byte&)option.character_id);
	WriteByte((byte&)option.is_knife);
	WriteByte((byte&)option.is_gm);

	WriteByte(option.client_count);
	WriteByte(option.viewer_count);

	WriteByte(option.game_type);
	WriteInt(option.rule_value);
	WriteByte(option.special_mode);

	WriteShort(option.round_rebirth_time_max);
	WriteByte(option.dead_view_mode);
	WriteByte((byte&)option.can_join_on_playing);
	WriteByte((byte&)option.check_game_balance);
	WriteByte((byte&)option.team_hurt);
	WriteByte((byte&)option.group_match);
	WriteByte((byte&)option.auto_start);


	WriteByte(option.use_password);
	WriteString(option.password.Str());

	WriteInt(option.item_id);
	WriteString(option.item_resource);
	WriteString(option.item_name);
	WriteByte(option.is_matching);
}

// read room option
void ChannelConnection::ReadRoomOption(RoomOption & option)
{
	ReadString(option.name);
	ReadString(option.map_name);
	ReadByte((byte&)option.use_random_map);

	ReadInt(option.level_id);
	ReadInt(option.map_level);
	ReadString(option.rand_key);
	ReadByte((byte&)option.character_id);
	ReadByte((byte&)option.is_knife);
	ReadByte((byte&)option.is_gm);

	ReadByte((byte&)option.client_count);
	ReadByte((byte&)option.viewer_count);

	ReadByte((byte&)option.game_type);
	ReadInt(option.rule_value);
	ReadByte((byte&)option.special_mode);

	ReadShort(option.round_rebirth_time_max);
	ReadByte((byte&)option.dead_view_mode);
	ReadByte((byte&)option.can_join_on_playing);
	ReadByte((byte&)option.check_game_balance);
	ReadByte((byte&)option.team_hurt);
	ReadByte((byte&)option.group_match);
	ReadByte((byte&)option.auto_start);

	ReadByte((byte&)option.use_password);
	ReadString(option.password);

	ReadInt(option.item_id);
	ReadString(option.item_resource);
	ReadString(option.item_name);

	ReadByte(option.is_matching);
}

// read room info
void ChannelConnection::ReadRoomInfo(RoomInfo & info)
{
	ReadShort(info.id);
	ReadInt(info.host_id);

	char name[64];
	int len = 64;
	ReadString(name, len);
	info.host_name = name;
	ReadByte(info.is_vip);
	ReadByte(info.net_bar_level);
	ReadInt(info.character_level);


	ReadByte(info.state);
	ReadByte((byte&)info.client_count);
	ReadRoomOption(info.option);
}

// read client info
void ChannelConnection::ReadClientInfo(ClientInfo & info)
{
	char temp[64];

	ReadInt(info.id);
	ReadInt(info.character_id);
	ReadString(temp, sizeof(temp));
	info.name = temp;
	ReadString(temp, sizeof(temp));
	info.group = temp;
	ReadString(temp, sizeof(temp));
	info.icon = temp;
	ReadInt(info.level);
	ReadInt(info.exp);
	ReadByte(info.team);
	ReadByte(info.is_vip);
	ReadByte(info.net_bar_level);
	ReadByte(info.business_card);
	ReadByte(info.is_gm);
	ReadByte((byte&)info.ready);
	ReadInt(info.top);
	ReadInt(info.fightnum);
	ReadFloat(info.win_rate);
	ReadByte((byte&)info.is_host);
	ReadByte((byte&)info.in_game);
}

// read room info
void ChannelConnection::ReadRoomSlot(RoomSlot & slot)
{
	ReadByte(slot.id);
	ReadByte(slot.team);
	ReadInt(slot.status);
	ReadString(slot.preserve_character_name.RefStr(32));
}
*/

// request chat
void ChannelConnection::RequestChat(const Core::Identifier & to, const Core::String & msg)
{
	if (state >= kInChannel)
	{
		if (msg.Length() > 0)
		{
			Core::CStrBuf<32> to_str(to.Str());
			Core::CStrBuf<64> msg_str(msg.Str());
			msg_str.validate();

			BeginWrite();
			WriteByte(CM_RequestChat);
			WriteString(to_str);
			WriteString(msg_str);
			EndWrite();
		}
	}
}

// request room create
void ChannelConnection::RequestRoomCreate(const RoomOption & option)
{
	if (state == kInChannel)
	{
		BeginWrite();
		WriteByte(CM_RequestRoomCreate);
		WriteRoomOption(*this, option);
		EndWrite();
	}
}

// request room enter
void ChannelConnection::RequestRoomEnter(int room_id, const char* password)
{
	LogSystem.WriteLinef("%s, %s name : %s, state :%d", __FILE__, __FUNCTION__, character_name, state);
	if (state == kInChannel)
	{
		BeginWrite();
		WriteByte(CM_RequestRoomEnter);
		WriteInt(room_id);
		WriteString(password);
		EndWrite();
	}
}

// request room leave
void ChannelConnection::RequestRoomLeave()
{
	LogSystem.WriteLinef("%s, %s, name : %s, state : %d", __FILE__, __FUNCTION__, character_name, state);
	if (state == kInRoom)
	{
		BeginWrite();
		WriteByte(CM_RequestRoomLeave);
		EndWrite();
	}
	else
	{
		bot->ResponseAction(AC_LEAVE_ROOM, RC_FAILED, "invalid_state");
	}
}

//requeset room client list
void ChannelConnection::RequestRoomClientList()
{
	if (state == kInRoom)
	{
		BeginWrite();
		WriteByte(CM_RequestRoomClientList);
		EndWrite();
	}
}

// request room change option
void ChannelConnection::RequestRoomChangeOption(const RoomOption & option)
{
	if (state == kInRoom)
	{
		BeginWrite();
		WriteByte(CM_RequestRoomChangeOption);
		WriteRoomOption(*this, option);
		EndWrite();
	}
}

// request room change team
void ChannelConnection::RequestRoomChangeTeam(byte team)
{
	if (state == kInRoom)
	{
		BeginWrite();
		WriteByte(CM_RequestRoomChangeTeam);
		WriteByte(team);
		EndWrite();
	}
}

// request room change slot
void ChannelConnection::RequestRoomChangeSlot(byte slot_id)
{
	if (state == kInRoom)
	{
		BeginWrite();
		WriteByte(CM_RequestRoomChangeSlot);
		WriteByte(slot_id);
		EndWrite();
	}
}

// request room preserve slot
//void ChannelConnection::RequestRoomPreserveSlot(byte slot_id, const Core::String & name)
//{
//	if (state == kInRoom)
//	{
//		BeginWrite();
//		WriteByte(CM_RequestRoomPreserveSlot);
//		WriteByte(slot_id);
//		WriteString(name);
//		EndWrite();
//	}
//}


// request room change slot status
void ChannelConnection::RequestRoomChangeSlotStatus(byte slot_id, RoomSlot::Status status)
{
	if (state == kInRoom)
	{
		BeginWrite();
		WriteByte(CM_RequestRoomChangeSlotStatus);
		WriteByte(slot_id);
		WriteInt(status);
		EndWrite();
	}
}

// request room ready
void ChannelConnection::RequestRoomReady(bool ready)
{
	if (state == kInGame)
	{
		return;
	}
	if (state == kInRoom)
	{
		BeginWrite();
		WriteByte(CM_RequestRoomReady);
		WriteByte(ready);
		EndWrite();
	}
	else
	{
		bot->ResponseAction(AC_START_GAME, RC_FAILED, "invalid_state");
	}
}

// request room kick client
void ChannelConnection::RequestRoomKickClient(byte id_in_room)
{
	if (state == kInRoom)
	{
		BeginWrite();
		WriteByte(CM_RequestRoomKickClient);
		WriteByte(id_in_room);
		EndWrite();
	}
}

// request client list
//void ChannelConnection::RequestClientList(int start_id)
//{
//	if (state == kInRoom || state == kInChannel)
//	{
//		BeginWrite();
//		WriteByte(CM_RequestClientList);
//		WriteInt(start_id);
//		EndWrite();
//	}
//}

// request game start
void ChannelConnection::RequestGameStart()
{
	if (state == kInGame)
	{
		return;
	}
	if (state == kInRoom)
	{
		BeginWrite();
		WriteByte(CM_RequestGameStart);
		EndWrite();
	}
	else
	{
		bot->ResponseAction(AC_START_GAME, RC_FAILED, "invalid_state");
	}
}

// request game enter
void ChannelConnection::RequestGameEnter()
{
	if (state == kInGame)
	{
		return;
	}
	if (state == kInRoom)
	{
		BeginWrite();
		WriteByte(CM_RequestGameEnter);
		EndWrite();
	}
	else
	{
		bot->ResponseAction(AC_START_GAME, RC_FAILED, "invalid_state");
	}
}

// response room list
void ChannelConnection::ResponseChannelEnter()
{
	int result;
	ReadInt(result);

	if (result == 0)
	{
		// on enter channel
		OnEnterChannel();
	}
	else
		bot->ResponseAction(AC_ENTER_CHANNEL, RC_FAILED, "result error");
}

// response room list
void ChannelConnection::ResponseRoomList()
{
	room_list.Clear();
	Core::String result;

	short room_count;
	ReadShort(room_count);

	for (int i = 0; i < room_count; ++i)
	{
		sharedc_ptr(RoomInfo) info = ptr_new RoomInfo;
		ReadRoomInfo(*this, *info);
		room_list.PushBack(info);

		if (info->id == room_info.id)
		{
			room_info = *info;
			bot->OnRoomListChanged();
		}

		result.RefStrGrow(32, 32).contractf("%d\t%d\t%d\t%d\n", 
			info->id, info->state, info->client_count, info->option.client_count);
	}

	bot->ResponseAction(AC_ROOM_LIST, RC_SUCCESSED, result);
}

// response room create
void ChannelConnection::ResponseRoomCreate()
{
	int result = 0;
	ReadInt(result);

	if (result == 0)
	{
		ReadRoomInfo(*this, room_info);

		// read slots
		for (uint i = 0; i < room_slots.Size(); i ++)
		{
			ReadRoomSlot(*this, room_slots[i]);
		}

		address.room_id = room_info.id;
		bot->ResponseAction(AC_CREATE_ROOM, RC_SUCCESSED, "");
		OnEnterRoom();
	}
	else
	{
		bot->ResponseAction(AC_CREATE_ROOM, RC_FAILED, "");
	}
}

// response room enter
void ChannelConnection::ResponseRoomEnter()
{
	LogSystem.WriteLinef("%s, %s name : %s, state :%d", __FILE__, __FUNCTION__, character_name, state);
	int result;
	ReadInt(result);

	if (result == 0)
	{
		ReadRoomInfo(*this, room_info);

		// read slots
		for (uint i = 0; i < room_slots.Size(); i ++)
		{
			ReadRoomSlot(*this, room_slots[i]);
		}

		address.room_id = room_info.id;
		OnEnterRoom();

		bot->ResponseAction(AC_ENTER_ROOM, RC_SUCCESSED, Core::String::Format("%d", room_info.id));
	}
	else
	{
		if (result == 20019)
		{
			bot->ResponseAction(AC_LEAVE_ROOM, RC_NONE, "");
			return;
		}
		bot->ResponseAction(AC_ENTER_ROOM, RC_FAILED, "");
	}
}

// response room leave
void ChannelConnection::ResponseRoomLeave()
{
	RequestRoomList();
	OnLeaveRoom();
}

// response room client list
void ChannelConnection::ResponseRoomClientList()
{
	client_list.Clear();

	int client_count;
	ReadInt(client_count);
	for (int i = 0; i < client_count; ++i)
	{
		sharedc_ptr(ClientInfo) info = ptr_new ClientInfo;
		ReadClientInfo(*this, *info);

		client_list.PushBack(info);
	}

	OnRoomClientListChanged();
}

// response room change option
void ChannelConnection::ResponseRoomChangeOption()
{
}

// response room change team
void ChannelConnection::ResponseRoomChangeTeam()
{
}

// response room change slot
void ChannelConnection::ResponseRoomChangeSlot()
{
}

// notify room change slot status;
void ChannelConnection::ResponseRoomChangeSlotStatus()
{
}

// response room ready
void ChannelConnection::ResponseRoomReady()
{
	int result;
	ReadInt(result);

	if (result == 0)
	{
	}
	else
	{
		if (result != 20049)
		{
			bot->is_ready = false;
			bot->ResponseAction(AC_START_GAME, RC_FAILED, "failed_ready");
		}
	}
}

// response game start
void ChannelConnection::ResponseGameStart()
{
	int result;
	ReadInt(result);

	if(state == ChannelConnection::kInGame)
	{
		return;
	}

	if (result == 0)
	{
		room_info.state = 2;
	}
	else
	{
		if (result == 20053)
		{
			return;
		}
		//if (room_info.state == 2)
		//{
		//	return;
		//}
		char buffer[32];
		sprintf_s(buffer,32,"failed_start_game %d", result);
		bot->ResponseAction(AC_START_GAME, RC_FAILED, buffer);
	}
}

// response game enter
void ChannelConnection::ResponseGameEnter()
{
	int result;
	ReadInt(result);

	if (result == 0)
	{
		OnEnterGame();
	}
	else
	{
		bot->ResponseAction(AC_START_GAME, RC_FAILED, "failed_game_enter");
	}
}
// notify channel client enter
void ChannelConnection::NotifyChannelClientEnter()
{
}

// notify channel client leave
void ChannelConnection::NotifyChannelClientLeave()
{
}

// notify room create
void ChannelConnection::NotifyRoomCreate()
{
	sharedc_ptr(RoomInfo) info = ptr_new RoomInfo;
	ReadRoomInfo(*this, *info);
	room_list.PushBack(info);

	OnRoomListChanged();
}

// notify room close
void ChannelConnection::NotifyRoomClose()
{
	int uid;
	ReadInt(uid);

	for (uint i = 0; i < room_list.Size(); ++i)
	{
		if (room_list[i] && room_list[i]->id == uid)
		{
			room_list.RemoveAt(i);
			break;
		}
	}

	OnRoomListChanged();
}

// notify room client enter
void ChannelConnection::NotifyRoomClientEnter()
{
	sharedc_ptr(ClientInfo) info = ptr_new ClientInfo;

	ReadClientInfo(*this, *info);

	client_list.PushBack(info);

	OnRoomClientListChanged();
}

// notify room client leave
void ChannelConnection::NotifyRoomClientLeave()
{
	int cid;
	ReadInt(cid);

	for (uint i = 0; i < client_list.Size(); ++i)
	{
		if (client_list[i] && client_list[i]->character_id == cid)
		{
			client_list.RemoveAt(i);
			break;
		}
	}

	OnRoomClientListChanged();
}

// notify room host changed
void ChannelConnection::NotifyRoomHostChanged(Core::BinaryNetworkReader & reader)
{
	short room_id;
	int host_id;
	char name[64];
	byte is_vip;
	byte net_bar_level;
	uint character_level; 

	reader.ReadShort(room_id);
	reader.ReadInt(host_id);
	reader.ReadByte(is_vip);
	reader.ReadByte(net_bar_level);
	reader.ReadInt(character_level);
	reader.ReadString(name, sizeof(name));


	switch (state)
	{
	case kInChannel:
		{
			for (uint i = 0; i < room_list.Size(); ++i)
			{
				if (room_list[i] && room_list[i]->id == room_id)
				{
					room_list[i]->host_id = host_id;
					room_list[i]->host_name = name;
					room_list[i]->is_vip = is_vip;
					room_list[i]->net_bar_level = net_bar_level;
					break;
				}
			}

			OnRoomListChanged();
		}
		break;

	case kInRoom:
	case kInBalance:
		{
			room_info.host_id = host_id;
			room_info.host_name = name;

			if (host_id == character_id)
			{
				bot->is_host_game = true;
				bot->OnRoomListChanged();					
			}
			else
			{
				bot->is_host_game = false;
			}

			for (uint i = 0; i < client_list.Size(); ++i)
			{
				if (client_list[i])
				{
					if (client_list[i]->character_id == host_id)
					{
						client_list[i]->is_host = true;

					}
					else
						client_list[i]->is_host = false;
				}
			}

			// HACK: if 
			if (room_info.host_id == character_id)
			{
				//Core::LogSystem.WriteLinef("%s\tbecome host, start game....", bot->GetLoginName());
				bot->is_host_game = true;
				bot->StartGame();
			}

			OnRoomClientListChanged();
		}
		break;
	}
}

// notify room change option
void ChannelConnection::NotifyRoomChangeOption()
{
	uint uid;
	RoomOption option;
	ReadInt(uid);
	ReadRoomOption(*this, option);

	switch (state)
	{
	case kInChannel:
		{
			for (uint i = 0; i < room_list.Size(); ++i)
			{
				if (room_list[i] && room_list[i]->id == uid)
				{
					room_list[i]->option = option;
					break;
				}
			}

			OnRoomListChanged();
		}
		break;

	case kInRoom:
	case kInBalance:
		{
			room_info.option = option;
			OnRoomOptionChanged();
		}
		break;
	}
}

// notify room state changed
void ChannelConnection::NotifyRoomStateChanged()
{
	short uid;
	byte room_state;
	ReadShort(uid);
	ReadByte(room_state);

	switch (state)
	{
	case kInChannel:
		{
			for (uint i = 0; i < room_list.Size(); ++i)
			{
				if (room_list[i] && room_list[i]->id == uid)
				{
					room_list[i]->state = room_state;
					break;
				}
			}

			OnRoomListChanged();
		}
		break;

	case kInRoom:
	case kInBalance:
		{
			room_info.state = room_state;
		}
		break;
	}
}

// notify room client count changed
void ChannelConnection::NotifyRoomClientCountChanged()
{
	uint uid;
	uint client_count;
	ReadInt(uid);
	ReadInt(client_count);

	for (uint i = 0; i < room_list.Size(); ++i)
	{
		if (room_list[i] && room_list[i]->id == uid)
		{
			room_list[i]->client_count = client_count;
			break;
		}
	}

	OnRoomListChanged();
}

// notify room change team
void ChannelConnection::NotifyClientChangeTeam()
{
	uint id;
	uint cid;
	byte team;

	ReadInt(cid);
	ReadInt(id);
	ReadByte(team);

	for (uint i = 0; i < client_list.Size(); ++i)
	{
		ClientInfo* info = client_list[i];
		if (info && info->character_id == cid)
		{
			info->id = id;
			info->team = team;
			break;
		}
	}

	OnRoomClientListChanged();
}

// notify room client ready
void ChannelConnection::NotifyClientReady()
{
	uint cid;
	bool ready;

	ReadInt(cid);
	ReadByte((byte&)ready);

	for (uint i = 0; i < client_list.Size(); ++i)
	{
		ClientInfo* info = client_list[i];
		if (info && info->character_id == cid)
		{
			info->ready = ready;
			break;
		}
	}

	OnRoomClientListChanged();
}

// notify game start
void ChannelConnection::NotifyGameStart()
{
	room_info.state = 2;
}

// notify game start
void ChannelConnection::NotifyGameEnd()
{
	room_info.state = 1;
}

// notify game client enter 
void ChannelConnection::NotifyGameClientEnter()
{
	uint cid;

	ReadInt(cid);

	for (uint i = 0; i < client_list.Size(); ++i)
	{
		ClientInfo* info = client_list[i];
		if (info && info->character_id == cid)
		{
			info->in_game = true;
			break;
		}
	}

	OnRoomClientListChanged();
}

// notify game client leave
void ChannelConnection::NotifyGameClientLeave()
{
	uint cid;

	ReadInt(cid);

	for (uint i = 0; i < client_list.Size(); ++i)
	{
		ClientInfo* info = client_list[i];
		if (info && info->is_host && info->character_id != cid)
		{
			info->in_game = false;
			//bot->is_host_game = true;
			//bot->StartGame();
			break;
		}
	}

	for (uint i = 0; i < client_list.Size(); ++i)
	{
		ClientInfo* info = client_list[i];
		if (info && info->character_id == cid)
		{
			info->in_game = false;
			break;
		}
	}

	OnRoomClientListChanged();
}

// notify chat
void ChannelConnection::NotifyChat(Core::BinaryNetworkReader & reader)
{
}

// notify room kick client
void ChannelConnection::NotifyClientChangeSlot()
{
	uint character_id;
	byte inroom_id;
	byte team;

	ReadInt(character_id);
	ReadByte(inroom_id);
	ReadByte(team);

	for (uint i = 0; i < client_list.Size(); ++i)
	{
		ClientInfo* info = client_list[i];
		if (info && info->character_id == character_id)
		{
			info->id = inroom_id;
			info->team = team;
			break;
		}
	}

	OnRoomClientListChanged();
}

// notify room change slot status;
void ChannelConnection::NotifyRoomChangeSlotStatus()
{
	byte slot_id;
	int status;

	ReadByte(slot_id);
	ReadInt(status);

	if (slot_id > 0 && slot_id <= room_slots.Size())
	{
		room_slots[slot_id - 1].status = status;
	}
}


// notify room kick client
void ChannelConnection::NotifyRoomKickClient()
{
	uint uid;
	ReadInt(uid);

	if (uid == character_id)
	{
		state = kInChannel;
		bot->is_host_game = false;

		client_list.Clear();

		address.room_id = 0;
		room_info = RoomInfo();

		bot->ResponseAction(AC_LEAVE_ROOM, RC_NONE, "");
	}
}


// load level description
static void LoadLevelDescription(tempc_ptr(LevelInfo) info)
{

}

// on enter channel
void ChannelConnection::OnEnterChannel()
{
	if (state == kConnected || state == kInRoom)
	{
		if (state == kConnected)
		{
			// notify client enter channel after received level list.
			bot->ResponseAction(AC_ENTER_CHANNEL, RC_SUCCESSED, Core::String::Format("%d", channel_id));
		}

		state = kInChannel;
		bot->status.curLogicState = LOGIC_IN_CHANNEL;
	}
}

// on leave channel
void ChannelConnection::OnLeaveChannel()
{
	Core::String info;

	if (state != kIdle)
	{
		state = kIdle;
		character_id = 0;
		address.room_id = 0;
		address.channel_id = 0;
		room_info = RoomInfo();

		room_list.Clear();
	}
}

// on enter room
void ChannelConnection::OnEnterRoom()
{
	if (state == kInChannel || state == kInGame || state == kInBalance)
	{
		state = kInRoom;

		bot->is_host_game = room_info.host_id == character_id;
		bot->status.curLogicState = LOGIC_IN_ROOM;

		RequestRoomClientList();
	}
}

// on leave room
void ChannelConnection::OnLeaveRoom()
{
	LogSystem.WriteLinef("%s, %s, name : %s, state : %d", __FILE__, __FUNCTION__, character_name, state);
	if (state == kInRoom)
	{
		state = kInChannel;
		bot->is_host_game = false;

		client_list.Clear();

		address.room_id = 0;
		room_info = RoomInfo();

		//bot->ResponseAction(AC_LEAVE_ROOM, RC_SUCCESSED, Core::String::kEmpty);
	}
	else
	{
		//bot->ResponseAction(AC_LEAVE_ROOM, RC_FAILED, "invalid_state");
	}
}

void ChannelConnection::OnRoomListChanged()
{
}

// on room client list changed
void ChannelConnection::OnRoomClientListChanged()
{
}

// on room option changed
void ChannelConnection::OnRoomOptionChanged()
{
}

// on update level list
void ChannelConnection::OnUpdateLevelList()
{
	if (!has_level_list)
	{
		has_level_list = true;
		bot->ResponseAction(AC_ENTER_CHANNEL, RC_SUCCESSED, Core::String::Format("%d", channel_id));
	}
}

// on game enter
void ChannelConnection::OnEnterGame()
{
	if (state == kInRoom)
	{
		state = kInGame;
		bot->status.curLogicState = LOGIC_IN_GAME;

		player_sync_time = 0;
		player_ping = 0;
		ping_time = 0;

		player_status = 0;
		player_position = Core::Vector3::kZero;
		player_rotation = Core::Quaternion::kIdentity;

		game_state = kAuthentication;
		
		LogSystem.WriteLinef("%s, %s, name : %s, state : %d", __FILE__, __FUNCTION__, character_name, state);
	}
	else
	{
		bot->ResponseAction(AC_START_GAME, RC_FAILED, "wrong_state");
	}
}

// on game leave
void ChannelConnection::OnLeaveGame(bool state_clear)
{
	LogSystem.WriteLinef("%s, %s, name : %s, state : %d", __FILE__, __FUNCTION__, character_name, state);
	if (state == kInGame)
	{
		bot->ResponseAction(AC_LEAVE_GAME, state_clear ? RC_NONE : RC_SUCCESSED, Core::String::Format("%d", room_info.id));
		OnEnterRoom();
	}
}


void ChannelConnection::OnEnterBalance()
{
	if(state == kInGame)
	{
		state = kInBalance;
	}
}

void ChannelConnection::OnLeaveBalance()
{
	if (state == kInBalance)
	{
	}
}

// on game end
void ChannelConnection::OnGameEnd()
{
	if (state == kInGame)
	{
		game_state = kGameEnd;
	}
}

// send sync player data
void ChannelConnection::SyncPlayerData()
{
	if (state != kInGame)
		return;

	if (game_state == kGameLeaving)
		return;

	float t = Core::Task::GetTotalTime();
	float delta = t - player_sync_time;

	if (delta > 0.05f)
	{
		byte flags = PD_Status | PD_Position | PD_Rotation;

		player_rotation *= Core::Quaternion(Core::Vector3(0, 1, 0), Core::PI * delta);
		player_position += Core::Vector3(0, 0, -delta) * player_rotation;
		//LogSystem.WriteLinef("%s, %s, position x : %f, y : %f, z : %f", __FILE__, __FUNCTION__, player_position.x, player_position.y, player_position.z);

		player_sync_time = t;
		player_status = PS_OnGround | PS_MoveForward;

		//if (t > ping_time)
		//{
		//	player_ping = delay_time * 1000;
		//	ping_time = t + 2;
		//	flags |= PD_Ping;
		//}

		BeginWrite();
		WriteByte(CM_SyncPlayerData);
		WriteByte(Clamp(delta + 0.5f / 255.f, 0, 1) * 255.f);
		WriteByte(flags);

		if (flags & PD_Status)		WriteShort((short&)player_status);
		if (flags & PD_Ping)		WriteShort(player_ping);
		if (flags & PD_Position)	WriteCharacterPosition(player_position);
		if (flags & PD_Rotation)	WriteCharacterRotation(player_rotation);

		EndWrite();
	}
}

// shoot
void ChannelConnection::Shoot(const Core::Vector3 & position, const Core::Quaternion & direction, byte uid, byte part, float distance)
{
	if (state != kInGame)
		return;

	if (game_state == kGameLeaving)
		return;

	BeginWrite();
	WriteByte(CM_Shoot);
	WriteByte(1);
	WriteFloat(1);
	WriteCharacterRotation(direction);
	WriteByte(0);

	EndWrite();

	//LogSystem.WriteLinef("%s, %s, uid : %d", __FILE__, __FUNCTION__, uid);
}

// game start
void ChannelConnection::ReadyForGame()
{
	if (state == kInGame && game_state == kLoading)
	{
		career = (rand() % 5) + 1;
		//career = 0;

		BeginWrite();
		WriteByte(CM_ReadyForGame);
		WriteInt(career);
		EndWrite();
		game_state = kWaiting;

		bot->ResponseAction(AC_START_GAME, RC_SUCCESSED, "");
	}
	else
	{
		bot->ResponseAction(AC_START_GAME, RC_FAILED, "wrong_state");
	}
}

void ChannelConnection::Reload()
{
	if (state != kInGame)
		return;

	if (game_state == kGameLeaving)
		return;

	BeginWrite();
	WriteByte(CM_Reload);
	EndWrite();
}

// leave game
void ChannelConnection::LeaveGame()
{
	if (state != kInGame)
		return;

	if (game_state == kGameLeaving)
		return;

	BeginWrite();
	WriteByte(CM_LeaveGame);
	WriteInt(0);
	EndWrite();

	game_state = kGameLeaving;

	ingame_uid = 0;
}

// parse Authentication
void ChannelConnection::ParseAuthentication(Core::BinaryNetworkReader & reader)
{
}

// parse character info
void ChannelConnection::ParseCharacterInfo(Core::BinaryNetworkReader & reader)
{
	byte uid;
	byte team;

	reader.ReadByte(uid);
	reader.ReadByte(team);
}
 
 	// parse sync game
void ChannelConnection::ParseInitialize(Core::BinaryNetworkReader & reader)
{
	byte team;
	byte uid;
	byte game_type;
	byte is_vip;
	byte business_card;
	byte is_gm;
	Core::String head_icon;
	int	 level;
	Vector3 position;
	int kick_count;

	byte bomb_planted = 0;
	
	int temp;
	byte bTemp;

	reader.ReadByte(uid);
	reader.ReadByte(team);
	reader.ReadByte(is_vip);
	reader.ReadByte(business_card);
	reader.ReadByte(is_gm);
	reader.ReadString(head_icon);
	reader.ReadInt(level);
	reader.ReadInt(temp);
	reader.ReadInt(temp);
	reader.ReadInt(temp);
	reader.ReadInt(temp);
	reader.ReadByte(bTemp);
	reader.ReadInt(temp);
	reader.ReadByte(bTemp);
	reader.ReadInt(kick_count);
	reader.ReadByte(game_type);

	ingame_uid = uid;
}
 
// 	// parse sync player data
void ChannelConnection::ParseSyncCharacterData(Core::BinaryNetworkReader & reader)
{
}

void ChannelConnection::ParsePlayerJoin(Core::BinaryNetworkReader & reader)
{
}

void ChannelConnection::ParsePlayerLeave(Core::BinaryNetworkReader & reader)
{
}

void ChannelConnection::ParseSpawn(Core::BinaryNetworkReader & reader)
{
	byte uid;
	int hp;
	int armor;
	int max_hp;
	int ex_hp;
	int s_rand;
	byte start_point = 0;
	Core::Vector3 position(0, 0, 0);
	float angle;

	reader.ReadByte(uid);
	reader.ReadInt(hp);
	reader.ReadInt(max_hp);
	reader.ReadInt(ex_hp);
	reader.ReadInt(armor);
	reader.ReadInt(s_rand);
	reader.ReadVector3(position);
	reader.ReadFloat(angle);

	if (uid == ingame_uid)
	{
		player_position = position;

		//LogSystem.WriteLinef("%s, %s, position x : %f, y : %f, z : %f", __FILE__, __FUNCTION__, player_position.x, player_position.y, player_position.z);
		player_rotation = Core::Quaternion(Core::Vector3(0, 1, 0), Core::DEG2RAD * angle);
		player_weapon = 1;

		SyncPlayerData();

		BeginWrite();
		WriteByte(CM_SpawnConfirm);
		EndWrite();
	}
}

// parse hurt
void ChannelConnection::ParseSyncTime(Core::BinaryNetworkReader & reader)
{
}

// parse game end
void ChannelConnection::ParseGameEnd(Core::BinaryNetworkReader & reader)
{
	byte team;
	reader.ReadByte(team);

	game_win_team = team;

	LogSystem.WriteLinef("%s, %s, win team : %d, name : %s", __FILE__, __FUNCTION__, team, character_name);

	OnGameEnd();
}

// parse game leave
void ChannelConnection::ParseGameLeave(Core::BinaryNetworkReader & reader)
{
	byte stage_clear;
	reader.ReadByte(stage_clear);

	LogSystem.WriteLinef("%s, %s name : %s", __FILE__, __FUNCTION__, character_name);
	OnLeaveGame(stage_clear != 0);
}

// notify game leave
void ChannelConnection::NotifyGameLeave(Core::BinaryNetworkReader & reader)
{
	OnLeaveGame(false);
}

// parse set team
void ChannelConnection::ParseSetTeam(Core::BinaryNetworkReader & reader)
{
}

void Client::ChannelConnection::ParseShoot( Core::BinaryNetworkReader & reader )
{
	byte uid;
	Quaternion dir;

	bool do_effect = true;
	bool isboost;
	int hurtcount;
	reader.ReadByte(uid);
	ReadCharacterRotation(reader, dir);
	reader.ReadByte((Byte&)do_effect);
	reader.ReadByte((Byte&)isboost);
	reader.ReadInt(hurtcount);

	//LogSystem.WriteLinef("%s, %s, uid : %d, do_effect : %d, isboost : %d", __FILE__, __FUNCTION__, uid, do_effect, isboost);
}

void Client::ChannelConnection::SelectWeapon( uint uid )
{
	BeginWrite();
	WriteByte(CM_SelectWeapon);
	WriteByte(uid);
	EndWrite();
}

void Client::ChannelConnection::ParseSelectWeapon( Core::BinaryNetworkReader & reader )
{
	byte uid;
	byte weapon_id;

	reader.ReadByte(uid);
	reader.ReadByte(weapon_id);

	//LogSystem.WriteLinef("%s, %s, uid : %d, weapon_id : %d", __FILE__, __FUNCTION__, uid, weapon_id);
}

void Client::ChannelConnection::NotifyRoomClientUpdate()
{
	sharedc_ptr(ClientInfo) info = ptr_new ClientInfo;

	ReadClientInfo(*this, *info);

	for (uint i = 0; i < client_list.Size(); ++i)
	{
		if (client_list[i] && client_list[i]->character_id == info->character_id)
		{
			client_list[i] = info;
			break;
		}
	}
}

void Client::ChannelConnection::NotifyRoomList()
{
	room_list.Clear();

	short room_count;
	ReadShort(room_count);
	for (int i = 0; i < room_count; ++i)
	{
		sharedc_ptr(RoomInfo) info = ptr_new RoomInfo;
		ReadRoomInfo(*this, *info);
		room_list.PushBack(info);

		if (info->id == room_info.id)
		{
			bot->OnRoomListChanged();
		}
	}

	OnRoomListChanged();
}

// on message
void ChannelConnection::OnMessageGame()
{
	sharedc_ptr(MessagePacket) packet = ptr_new MessagePacket(read_position, read_end - read_position);
	read_position = read_end;

	if (!packet)
	{
		return;
	}

	switch (game_state)
	{
	case kAuthentication:
		{
			byte message_type = packet->GetMessageType();

			//LogSystem.WriteLinef("%s, %s, name : %s state : %d, msg : %d", __FILE__, __FUNCTION__, character_name, game_state, message_type);
			switch(message_type)
			{
			case SM_NotifyRoomHostChanged:	NotifyRoomHostChanged(*packet);	break;
			case SM_CharacterInfo:			ParseCharacterInfo(*packet);		break;
			case SM_Authentication:			ParseAuthentication(*packet);		break;
			case SM_Loading:
				game_state = kLoading;
				ReadyForGame();
				break;
			}
		}
		break;

	case kWaiting:
	case kAlive:
	case kDied:
	case kGameLeaving:
	case kGameEnd:
		{
			byte message_type = packet->GetMessageType();

			//LogSystem.WriteLinef("%s, %s, name : %s state : %d, msg : %d", __FILE__, __FUNCTION__, character_name, game_state, message_type);
			switch (message_type)
			{
				case SM_NotifyRoomHostChanged:	NotifyRoomHostChanged(*packet);	break;
			case SM_NotifyGameLeave:		NotifyGameLeave(*packet);			break;
			case SM_CharacterInfo:			ParseCharacterInfo(*packet);		break;
			case SM_Initialize:				ParseInitialize(*packet);			break;
			case SM_ClientJoin:				ParsePlayerJoin(*packet);			break;
			case SM_ClientLeave:			ParsePlayerLeave(*packet);			break;
			case SM_SyncPlayerData:			ParseSyncCharacterData(*packet);	break;
			case SM_PlayerSpawn:			ParseSpawn(*packet);				break;
			case SM_SyncTime:				ParseSyncTime(*packet);			break;
			case SM_GameEnd:				ParseGameEnd(*packet);				break;
			case SM_GameLeave:				ParseGameLeave(*packet);			break;
			case SM_NotifyChat:				NotifyChat(*packet);				break;
			case SM_RoundStart:				break;//ParseRoundStart(packet);			break;
			case SM_RoundStartPlay:			break;//ParseRoundStartPlay(packet);		break;
			case SM_RoundEnd:				break;//ParseRoundEnd(packet);				break;
			case SM_PlayerSetTeam:			ParseSetTeam(*packet);				break;
			case SM_PlayerShoot:			ParseShoot(*packet);				break;
			case SM_PlayerSelectWeapon:		ParseSelectWeapon(*packet);			break;
			}
		}
		break;

	case kLoading:
		{
			byte message_type = packet->GetMessageType();

			//LogSystem.WriteLinef("%s, %s, name : %s state : %d, msg : %d", __FILE__, __FUNCTION__, character_name, game_state, message_type);
			switch (message_type)
			{
				case SM_NotifyRoomHostChanged:	NotifyRoomHostChanged(*packet);	break;
				case SM_NotifyGameLeave:		NotifyGameLeave(*packet);			break;
			case SM_CharacterInfo:			ParseCharacterInfo(*packet);		break;
			case SM_GameEnd:				ParseGameEnd(*packet);				break;
			case SM_GameLeave:				ParseGameLeave(*packet);			break;
			}

		}
	};
}
