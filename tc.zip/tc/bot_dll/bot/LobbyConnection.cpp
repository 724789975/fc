#include "pch.h"

#define USE_ENCODER 1

static const int network_version = ((1 << 0) | (0 << 8) | (0 << 16) | (27 << 24));

using namespace Core;
using namespace Client;
using namespace Bot;

enum EServerMessage
{
    SM_ResponseRPC,
    SM_ResponseEnterLobby,
    SM_ResponseLeaveLobby,
    SM_ResponseChannelConnect,
    SM_NotifyChat,
    SM_NotifyFCM,
    SM_ForceDisconnect,
    SM_ResponseTeamInvite,
    SM_ResponseTeamJoin,
    SM_NotifyTeamInvite,
    SM_NotifyTeamMemberJoin,
    SM_NotifyTeamMemberLeave,
    SM_NotifyTeamChangeLeader,
    SM_NotifyTeamMemberInfo,
    SM_NotifyTeamLeave,
    SM_NotifyTeamRefuse,
    SM_NotifyRoomPreserve,
    SM_NotifyRoomCancelPreserve,
    SM_NotifyTeamCall,
    SM_ResponseTeamCall,
    SM_ResponseSearchRoom,
    SM_NotifyUpdateLevelList,
    SM_NotifyRefusePreserve,
    SM_NotifyRPCMessage,
    SM_ResponseEnterServer,
    SM_ResponseEnterChannel,
    SM_ResponseLeaveServer,
    SM_NotifyRefreshServerList,
    SM_NotifyRefreshChannelList,
	SM_ResponseCharacterAddress,

	SM_NotifyChatGroupInvite,
	SM_NotifyChatGroupJoin,
	SM_NotifyChatGroupLeave,
	SM_NotifyChatGroupCall,
	SM_ResponseChatGroupCreate,
	SM_ResponseChatGroupMember,

	SM_NotifyMultiChat,
	SM_NotifyLoopMsg,

	SM_ResponseApex,

	SM_ResponseBattleBattleGroups,
	SM_ResponseBattleGroupCreate,
	SM_ResponseBattleGroupJoin,
	SM_ResponseBattleGroupStartSearch,
	SM_ResponseBattleGroupChallenge,
	SM_NotifyBattleGroupInvite,
	SM_NotifyBattleGroupKick,
	SM_NotifyBattleGroupChange,
	SM_NotifyBattleGroupInfo,
	SM_NotifyBattleGroupSearching,
	SM_NotifyBattleGroupGameStart,


	SM_UpdateBillBoardInfo,





    //ƥ��
	SM_ResponseMatchingTeamCreate,
	SM_ResponseMatchingTeamInvite,
	SM_ResponseMatchingTeamJoin,
	SM_ResponseMatchingTeamLeave,
	SM_ResponseMatchingTeamKick,
	SM_ResponseMatchingTeamChangeLeader,

	SM_NotifyMatchingTeamInvite,
	SM_NotifyMatchingTeamMemberJoin,
	SM_NotifyMatchingTeamMemberLeave,
	SM_NotifyMatchingTeamChangeLeader,
	SM_NotifyMatchingTeamMemberInfo,
	SM_NotifyMatchingTeamLeave,
	SM_NotifyMatchingTeamKick,
	SM_NotifyMatchingTeamChange,

	SM_ResponseMatching,
	SM_ResponseCancelMatching,

	SM_ResponseMatchingProgress,

	// ������as�����е� ��ʱ��֪����ʲô���� �ȼӽ�ȥ
	SM_NotifyPunishedNames,		//ƥ��ʱ�����ڳͷ�ʱ����
	SM_NotifyBeginMatch,		//��ʼƥ��
	SM_NotifyLeftPunishedTime,		//����ʣ��ͷ�ʱ��

	SM_NotifyGoToMetchingRoom,		// ƥ���ʱ�� ��������ֱ�ӽ���ĳ������

	SM_ResponseLestPersonChannel,
	SM_ResponseIntoMatchingTeam,

};

enum EClientMessage
{
    CM_RequestRPC,
    CM_RequestEnterLobby,
    CM_RequestLeaveLobby,
    CM_RequestChannelConnect,
    CM_RequestChat,
    CM_RequestTeamInvite,
    CM_RequestTeamJoin,
    CM_RequestTeamLeave,
    CM_RequestTeamKick,
    CM_RequestTeamChangeLeader,
    CM_RequestTeamRefuse,
    CM_RequestTeamCall,
    CM_RequestSearchRoom,
    CM_RequestCancelSearchRoom,
    CM_RequestRefusePreserve,
    CM_RequestEnterServer,
    CM_RequestEnterChannel,
    CM_RequestLeaveServer,
    CM_RequestRefreshServerList,
    CM_RequestRefreshChannelList,
	CM_RequestCharacterAddress,

	CM_SaveUserProfile,
	CM_SaveCharacterProfile,

	CM_RequestChatGroupCreate,
	CM_RequestChatGroupInvite,
	CM_RequestChatGroupJoin,
	CM_RequestChatGroupLeave,
	CM_RequestChatGroupCall,
	CM_RequestChatGroupMember,

	CM_NotifyMultiChat,

	CM_RequestApex,

	CM_RequestBattleGroups,
	CM_RequestBattleGroupCreate,
	CM_RequestBattleGroupInvite,
	CM_RequestBattleGroupJoin,
	CM_RequestBattleGroupLeave,
	CM_RequestBattleGroupInfo,
	CM_RequestBattleGroupReady,
	CM_RequestBattleGroupStartSearch,
	CM_RequestBattleGroupChallenge,

	//ƥ�� 
	CM_RequestMatchingTeamCreate,			// ��������ƥ��Ķ���(������ȵý��뷿����ܷ�)
	CM_RequestMatchingTeamJoin,				// ����
	CM_RequestMatchingTeamInvite,			// ����
	CM_RequestMatchingTeamLeave,			// �뿪(��һ����)
	CM_RequestMatchingTeamKick,				// T��
	CM_RequestMatchingTeamChangeLeader,		// ���ӳ�(��һ����)

	CM_RequestMatchingProgress,				//

	CM_RequestMatching,						// ????
	CM_RequestCancelMatching,				// ????

	CM_RequestLestPersonChannel,			// ??????

	CM_RequestIntoMatchingTeam,


};

enum EAuthenticationState
{
	CLogin_Success,
	CLogin_Failed,
	CLogin_NeedNickName,
	CLogin_NickNameFailed,
};

// -----------------------------------------------------------------
// LobbyConnection functions
// -----------------------------------------------------------------
// constructor.
LobbyConnection::LobbyConnection()
: rpc_request_count(0)
, rpc_request_id(0)
, uid(0)
, user_id(0)
, selected_server_id(-1)
, selected_channel_id(-1)
{
	connection = this;
	stream = this;

	use_luncher = false;
}

// destructor
LobbyConnection::~LobbyConnection()
{
}

// begin text rpc
int LobbyConnection::BeginTextRpc(const char * func, RpcCallback callback)
{
	if (rpc_request_count > 0)
		return 0;

	rpc_request_id ++;
	rpc_request_count ++;
	rpc_callback = callback;

	BeginWrite();
	WriteByte(CM_RequestRPC);
	WriteInt(rpc_request_id);
	WriteString(func);

	return rpc_request_id;
}

// add rpc argument
void LobbyConnection::TextRpcArgument(const char * key, const char * value)
{
	if (rpc_request_count > 0)
	{
		if (key && key[0])
		{
			WriteString(key);
			WriteString(value);
		}
	}
}

// add rpc argument
void LobbyConnection::TextRpcArgumentf(const char * key, const char * format, ...)
{
	if (rpc_request_count > 0)
	{
		if (key && key[0])
		{
			Core::CStrBuf<4096> value;
			va_list args;
			va_start(args, format);
			value.formatv(format, args);
			va_end(args);

			WriteString(key);
			WriteString(value);
		}
	}
}


// end text rpc
void LobbyConnection::EndTextRpc()
{
	if (rpc_request_count > 0)
	{
		WriteString("");
		EndWrite();
	}
}

// request
void LobbyConnection::ResponseRPC()
{
	uint id;

	ReadInt(id);
	rpc_request_count --;

	Core::String result;
	ReadString(result);

	if (rpc_callback)
		(this->*rpc_callback)(result);
}

// on message
void LobbyConnection::OnMessage()
{
	//LogSystem.WriteLinef("%s, %s, state : %d", __FILE__, __FUNCTION__, state);
	switch (state)
	{
#if USE_ENCODER
	case kConnected:
		{
			//unsigned char key[8];
			//Read(key, sizeof(key));
			//des_encoder.SetKey(key, sizeof(key));

			//encoder = &des_encoder;
			//state = kAuthentication;
			int dwNum = 0;
			ReadInt(dwNum);
			state = kAuthentication;
		}
		break;
#endif
	case kAuthentication:
		{
			int auth_state;
			byte b;
			ReadInt(auth_state);
			ReadByte(b);
			ReadInt(uid);
			ReadInt(user_id);
			character_id = user_id;

			if (uid && user_id && auth_state == CLogin_Success)
			{
				Core::String laji;

				ReadString(laji);
				ReadString(character_name);

				String configStream;
				ReadString(configStream);
				//gGame->config->OnLoadConfig(configStream);
				short type;
				ReadShort(type);
				
				Core::String buffer;

				// http ----
				{
					ReadString(buffer);
					ReadString(buffer);
					ReadString(buffer);

					ReadString(buffer);
					ReadString(buffer);
					ReadString(buffer);
					ReadString(buffer);

					//ReadString(buffer);

					int length;
					ReadInt(length);

					int key = 0;
					String value;
					for (int i = 0; i < length; i++)
					{
						ReadInt(key);
						ReadString(value);
						//gHttpConfig.http_pay_set.Add(key, value);
					}

					ReadString(buffer);
					//SpltCsv(gHttpConfig.achievement_list, gGame->config->m_achievementlist, ',');

					byte bb;
					ReadByte(bb);
					ReadByte(bb);
					ReadByte(bb);
					ReadByte(bb);
					ReadByte(bb);
					ReadByte(bb);
					ReadByte(bb);
					ReadByte(bb);
					ReadByte(bb);
					ReadByte(bb);
					ReadByte(bb);
					ReadByte(bb);
					ReadByte(bb);
					ReadString(buffer);
					ReadString(buffer);
					ReadString(buffer);
					ReadString(buffer);
					ReadString(buffer);

					ReadString(buffer);
					ReadByte(bb);
				}

				state = kInLogin;
				error_message = Core::String::kEmpty;

				bot->SetOK(true);
				bot->ResponseAction(AC_LOGIN_IN, RC_SUCCESSED, Core::String::Format("%d", user_id));
			}
			else if(auth_state == CLogin_Failed)
			{
				ReadString(error_message);
				if (error_message == Core::String::kEmpty)
				{
					error_message.Format("login_failed, uid : %d. user_id : %d, auth_state : %d", uid, user_id, auth_state);
					//error_message = "login_failed";
				}

				bot->SetOK(false);
				bot->ResponseAction(AC_LOGIN_IN, RC_FAILED, error_message);
			}
			else if(auth_state == CLogin_NickNameFailed)
			{
				ReadString(error_message);

				bot->SetOK(false);
				bot->ResponseAction(AC_CREATE_NICKNAME, RC_FAILED, error_message);
			}
			else if(auth_state == CLogin_NeedNickName)
			{
				RequestCreateNickName(login_name);
			}

			if (!keep_alive)
				Disconnect();
		}
		break;

	case kInLogin:
		{
			byte msg;
			ReadByte(msg);

			//LogSystem.WriteLinef("%s, %s, state : %d, msg : %d", __FILE__, __FUNCTION__, state, msg);
			switch (msg)
			{
			case SM_ResponseRPC:		ResponseRPC();			break;
			case SM_ResponseEnterLobby:	ResponseEnterLobby();	break;
			case SM_ForceDisconnect:	ForceDisconnect();		break;
			case SM_NotifyRPCMessage:	break; //NotifyRPCMessage();		break;
#if ACTIVE_APEX
			case SM_ResponseApex:		break; //OnResponseApex();			break;
#endif
			}
		}
		break;

	case kInChannel:
	case kInGame:
		{
			byte msg;
			ReadByte(msg);

			//LogSystem.WriteLinef("%s, %s, state : %d, msg : %d", __FILE__, __FUNCTION__, state, msg);
			switch (msg)
			{
			case SM_ResponseRPC:			ResponseRPC();				break;
			case SM_ResponseLeaveLobby:		ResponseLeaveLobby();		break;
			case SM_NotifyChat:				NotifyChat();				break;
			case SM_NotifyFCM:				NotifyFCM();				break;
			case SM_ForceDisconnect:		ForceDisconnect();			break;
			case SM_ResponseTeamInvite:		ResponseTeamInvite();		break;
			case SM_ResponseTeamJoin:		ResponseTeamJoin();			break;
			case SM_NotifyTeamInvite:		NotifyTeamInvite();			break;
			case SM_NotifyTeamMemberJoin:	NotifyTeamMemberJoin();		break;
			case SM_NotifyTeamMemberLeave:	NotifyTeamMemberLeave();	break;
			case SM_NotifyTeamChangeLeader:	NotifyTeamChangeLeader();	break;
			case SM_NotifyTeamMemberInfo:	NotifyTeamMemberInfo();		break;
			case SM_NotifyTeamLeave:		NotifyTeamLeave();			break;
			case SM_NotifyTeamRefuse:		NotifyTeamRefuse();			break;
			case SM_NotifyRefusePreserve:	NotifyRefusePreserve();		break;
			case SM_NotifyRPCMessage:		NotifyRPCMessage();			break;
			case SM_ResponseEnterServer:	ResponseEnterServer();		break;
			case SM_ResponseLeaveServer:	ResponseLeaveServer();		break;
			case SM_NotifyRefreshServerList:NotifyRefreshServerList();	break;
			case SM_NotifyRefreshChannelList:NotifyRefreshChannelList();break;
			case SM_ResponseCharacterAddress:break; //ResponseCharacterAddress();break;

			case SM_NotifyChatGroupInvite:	break; //OnNotifyChatGroupInvite();break;
			case SM_NotifyChatGroupJoin:	break; //OnNotifyChatGroupJoin();break;
			case SM_NotifyChatGroupLeave:	break; //OnNotifyChatGroupLeave();break;
			case SM_NotifyChatGroupCall:	break; //OnNotifyChatGroupCall();break;
			case SM_ResponseChatGroupCreate:	break; //OnResponseChatGroupCreate();break;
			case SM_ResponseChatGroupMember:	break; //OnResponseChatGroupMember();break;

			case SM_NotifyMultiChat:		break; //OnNotifyMultiChat();break;
			case SM_NotifyLoopMsg:			break; //OnNotifyLoopMsg();	break;
#if ACTIVE_APEX
			case SM_ResponseApex:			break; //OnResponseApex();			break;
#endif
			case SM_ResponseBattleBattleGroups:		break; //OnResponseBattleBattleGroups();	break;
			case SM_ResponseBattleGroupCreate:		break; //OnResponseBattleGroupCreate();	break;
			case SM_ResponseBattleGroupJoin:		break; //OnResponseBattleGroupJoin();	break;
			case SM_ResponseBattleGroupStartSearch:	break; //OnResponseBattleGroupStartSearch();	break;
			case SM_ResponseBattleGroupChallenge:	break; //OnResponseBattleGroupChallenge();	break;
			case SM_NotifyBattleGroupInvite:		break; //OnNotifyBattleGroupInvite();	break;
			case SM_NotifyBattleGroupKick:		break; //	OnNotifyBattleGroupKick();		break;
			case SM_NotifyBattleGroupChange:		break; //OnNotifyBattleGroupChange();	break;
			case SM_NotifyBattleGroupInfo:			break; //OnNotifyBattleGroupInfo();		break;
			case SM_NotifyBattleGroupSearching:		break; //OnNotifyBattleGroupSearching();	break;
			case SM_NotifyBattleGroupGameStart:		break; //OnNotifyBattleGroupGameStart();	break;



			case SM_UpdateBillBoardInfo:			break; //OnNotifyBillBoardInfo();		break;

				///??
			case SM_ResponseMatchingTeamCreate:		OnResponseMatchingTeamCreate();		break;
			case SM_ResponseMatchingTeamInvite:		break; //OnResponseMatchingTeamInvite();     break;
			case SM_ResponseMatchingTeamJoin:		break; //OnResponseMatchingTeamJoin();       break;
			case SM_ResponseMatchingTeamLeave:		break; //OnResponseMatchingTeamLeave();      break;
			case SM_ResponseMatchingTeamKick:		break; //OnResponseMatchingTeamKick();       break;
			case SM_ResponseMatchingTeamChangeLeader:break; //OnResponseMatchingTeamChangeLeader();break;
			case SM_NotifyMatchingTeamInvite:		break; //OnNotifyMatchingTeamInvite();       break;
			case SM_NotifyMatchingTeamMemberJoin:	break; //OnNotifyMatchingTeamMemberJoin();  break;
			case SM_NotifyMatchingTeamMemberLeave:	break; //OnNotifyMatchingTeamMemberLeave();break;
			case SM_NotifyMatchingTeamChangeLeader:	break; //OnNotifyMatchingTeamChangeLeader();break;
			case SM_NotifyMatchingTeamMemberInfo:	break; //OnNotifyMatchingTeamMemberInfo();  break;
			case SM_NotifyMatchingTeamLeave:		break; //OnNotifyMatchingTeamLeave();            break;
			case SM_NotifyMatchingTeamKick:			break; //OnNotifyMatchingTeamKick();             break;
			case SM_NotifyMatchingTeamChange:		break; //OnNotifyMatchingTeamChange();         break;
			case SM_ResponseMatching:				break; //OnResponseMatching();           	break;
			case SM_ResponseCancelMatching:			break; //OnResponseCancelMatching();      	break;
			case SM_ResponseMatchingProgress:		break; //OnResponseMatchingProgress();		break;
			case SM_NotifyPunishedNames:			break; //OnNotifyPunishedNames();     		break;
			case SM_NotifyBeginMatch:				break; //OnNotifyBeginMatch();		    	break;
			case SM_NotifyLeftPunishedTime:			break; //On_NotifyLeftPunishedTime();			break;
			case SM_NotifyGoToMetchingRoom:			break; //OnNotifyGoToMetchingRoom();				break;
			case SM_ResponseLestPersonChannel:		OnResponseLestPersonChannel();		break;

			}
		}
		break;

	case kInLobby:
		{
			byte msg;
			ReadByte(msg);

			//LogSystem.WriteLinef("%s, %s, state : %d, msg : %d", __FILE__, __FUNCTION__, state, msg);

			switch (msg)
			{
			case SM_ResponseRPC:			ResponseRPC();				break;
			case SM_ResponseLeaveLobby:		ResponseLeaveLobby();		break;
			case SM_ResponseChannelConnect:	ResponseChannelConnect();	break;
			case SM_NotifyChat:				NotifyChat();				break;
			case SM_NotifyFCM:				NotifyFCM();				break;
			case SM_ForceDisconnect:		ForceDisconnect();			break;
			case SM_ResponseTeamInvite:		ResponseTeamInvite();		break;
			case SM_ResponseTeamJoin:		ResponseTeamJoin();			break;
			case SM_NotifyTeamInvite:		NotifyTeamInvite();			break;
			case SM_NotifyTeamMemberJoin:	NotifyTeamMemberJoin();		break;
			case SM_NotifyTeamMemberLeave:	NotifyTeamMemberLeave();	break;
			case SM_NotifyTeamChangeLeader:	NotifyTeamChangeLeader();	break;
			case SM_NotifyTeamMemberInfo:	NotifyTeamMemberInfo();		break;
			case SM_NotifyTeamLeave:		NotifyTeamLeave();			break;
			case SM_NotifyTeamRefuse:		NotifyTeamRefuse();			break;
			case SM_NotifyRoomPreserve:		NotifyRoomPreserve();			break;
			case SM_NotifyRoomCancelPreserve:NotifyRoomCancelPreserve();	break;
			case SM_ResponseTeamCall:		ResponseTeamCall();		break;
			case SM_ResponseSearchRoom:		ResponseSearchRoom();	break;
			case SM_NotifyTeamCall:			NotifyTeamCall();		break;
			case SM_NotifyUpdateLevelList:	NotifyUpdateLevelList();	break;
			case SM_NotifyRefusePreserve:	NotifyRefusePreserve();	break;
			case SM_NotifyRPCMessage:		NotifyRPCMessage();			break;
			case SM_ResponseEnterServer:	ResponseEnterServer();		break;
			case SM_ResponseLeaveServer:	ResponseLeaveServer();		break;
			case SM_NotifyRefreshServerList:NotifyRefreshServerList();	break;
			case SM_NotifyRefreshChannelList:NotifyRefreshChannelList();break;
			case SM_ResponseCharacterAddress:break; //ResponseCharacterAddress();break;

			case SM_NotifyChatGroupInvite:	break; //OnNotifyChatGroupInvite();break;
			case SM_NotifyChatGroupJoin:	break; //OnNotifyChatGroupJoin();break;
			case SM_NotifyChatGroupLeave:	break; //OnNotifyChatGroupLeave();break;
			case SM_NotifyChatGroupCall:	break; //OnNotifyChatGroupCall();break;
			case SM_ResponseChatGroupCreate:	break; //OnResponseChatGroupCreate();break;
			case SM_ResponseChatGroupMember:	break; //OnResponseChatGroupMember();break;

			case SM_NotifyMultiChat:		break; //OnNotifyMultiChat();break;
			case SM_NotifyLoopMsg:			break; //OnNotifyLoopMsg();	break;
#if ACTIVE_APEX
			case SM_ResponseApex:			break; //OnResponseApex();			break;
#endif
			case SM_ResponseBattleBattleGroups:		break; //OnResponseBattleBattleGroups();	break;
			case SM_ResponseBattleGroupCreate:		break; //OnResponseBattleGroupCreate();	break;
			case SM_ResponseBattleGroupJoin:		break; //OnResponseBattleGroupJoin();	break;
			case SM_ResponseBattleGroupStartSearch:	break; //OnResponseBattleGroupStartSearch();	break;
			case SM_ResponseBattleGroupChallenge:	break; //OnResponseBattleGroupChallenge();	break;
			case SM_NotifyBattleGroupInvite:		break; //OnNotifyBattleGroupInvite();	break;
			case SM_NotifyBattleGroupKick:			break; //OnNotifyBattleGroupKick();		break;
			case SM_NotifyBattleGroupChange:		break; //OnNotifyBattleGroupChange();	break;
			case SM_NotifyBattleGroupInfo:			break; //OnNotifyBattleGroupInfo();		break;
			case SM_NotifyBattleGroupSearching:		break; //OnNotifyBattleGroupSearching();	break;
			case SM_NotifyBattleGroupGameStart:		break; //OnNotifyBattleGroupGameStart();	break;



			case SM_UpdateBillBoardInfo:			break; //OnNotifyBillBoardInfo();		break;

			
		    ///??
			case SM_ResponseMatchingTeamCreate:		OnResponseMatchingTeamCreate();		break;
			case SM_ResponseMatchingTeamInvite:		break; //OnResponseMatchingTeamInvite();     break;
			case SM_ResponseMatchingTeamJoin:		break; //OnResponseMatchingTeamJoin();       break;
			case SM_ResponseMatchingTeamLeave:		break; //OnResponseMatchingTeamLeave();      break;
			case SM_ResponseMatchingTeamKick:		break; //OnResponseMatchingTeamKick();       break;
			case SM_ResponseMatchingTeamChangeLeader:break; //OnResponseMatchingTeamChangeLeader();break;
			case SM_NotifyMatchingTeamInvite:		break; //OnNotifyMatchingTeamInvite();       break;
			case SM_NotifyMatchingTeamMemberJoin:	break; //OnNotifyMatchingTeamMemberJoin();  break;
			case SM_NotifyMatchingTeamMemberLeave:	break; //OnNotifyMatchingTeamMemberLeave();break;
			case SM_NotifyMatchingTeamChangeLeader:	break; //OnNotifyMatchingTeamChangeLeader();break;
			case SM_NotifyMatchingTeamMemberInfo:	break; //OnNotifyMatchingTeamMemberInfo();  break;
			case SM_NotifyMatchingTeamLeave:		break; //OnNotifyMatchingTeamLeave();            break;
			case SM_NotifyMatchingTeamKick:			break; //OnNotifyMatchingTeamKick();             break;
			case SM_NotifyMatchingTeamChange:		break; //OnNotifyMatchingTeamChange();         break;
			case SM_ResponseMatching:				OnResponseMatching();           	break;
			case SM_ResponseCancelMatching:			break; //OnResponseCancelMatching();      	break;
			case SM_ResponseMatchingProgress:		break; //OnResponseMatchingProgress();		break;
			case SM_NotifyPunishedNames:			break; //OnNotifyPunishedNames();     		break;
			case SM_NotifyBeginMatch:				break; //OnNotifyBeginMatch();		    	break;
			case SM_NotifyLeftPunishedTime:			break; //On_NotifyLeftPunishedTime();			break;
			case SM_NotifyGoToMetchingRoom:			break; //OnNotifyGoToMetchingRoom();				break;
			case SM_ResponseLestPersonChannel:		OnResponseLestPersonChannel();		break;



			}
		}
		break;
	}
}

// on connected
void LobbyConnection::OnConnected()
{
#if USE_ENCODER
	//xor_encoder.Reset();
	//des_encoder.Reset();
	//encoder = &xor_encoder;
#endif

	BeginWrite();
	WriteInt(network_version);
	WriteString("Unknown");
	WriteString(login_name);

	WriteString(authentication_code);
	WriteString("");

#if USE_ENCODER
	//unsigned char key[8];
	//des_encoder.GetKey(key, sizeof(key));
	//Write(key, sizeof(key));
#endif

	EndWrite();

	error_message = "what error ?????";


#if USE_ENCODER
	state = kConnected;
#else
	state = kAuthentication;
#endif
}

// on disconnected
void LobbyConnection::OnDisconnected(bool is_error)
{
	bot->SetOK(false);

	if (error_message == Core::String::kEmpty)
		error_message = "disconnected";
}


// request enter lobby
void LobbyConnection::RequestEnterLobby(uint character_id)
{
	if (state == kInLogin)
	{
		BeginWrite();
		WriteByte(CM_RequestEnterLobby);
		//WriteInt(character_id);
		EndWrite();
	}
}

// request leave lobby
void LobbyConnection::RequestLeaveLobby()
{
	if (state > kInLogin)
	{
		BeginWrite();
		WriteByte(CM_RequestLeaveLobby);
		EndWrite();
	}
}

// request channel connect
void LobbyConnection::RequestChannelConnect(int channel_id)
{
	if (state == kInLobby)
	{
		BeginWrite();
		WriteByte(CM_RequestChannelConnect);
		WriteInt(channel_id);
		EndWrite();
	}
	else
	{
		bot->ResponseAction(AC_ENTER_CHANNEL, RC_FAILED, "wrong_state");
	}
}

// response enter lobby
void LobbyConnection::ResponseEnterLobby()
{
	state = kInLobby;

	byte firstgame;
	byte is_vip;
	byte net_bar_level;
	byte business_card;
	byte is_gm;
	byte playerchecktoday;
	Core::String head_icon;

	int  size;

	ReadByte(firstgame);
	ReadByte(is_vip);
	ReadByte(net_bar_level);
	ReadByte(business_card);
	ReadByte(is_gm);
	ReadString(head_icon);
	ReadByte(playerchecktoday);

	ReadInt(size);
	for (int i = 0; i < size; i++)
	{
		String str;
		ReadString(str);
		//bill_board_list.Add(str);
	}
	//int gender = 0;

	//ReadInt(character_id);
	//ReadString(name, sizeof(name));
	//ReadInt(gender);

	//character_name = name;
	//character_gender = gender;

	Core::String info;
	//info.RefStrGrow(128, 128).format("%d,%s,%d", character_id, name, character_gender);
	bot->ResponseAction(AC_ENTER_LOBBY, RC_SUCCESSED, info);
}

// response leave lobby
void LobbyConnection::ResponseLeaveLobby()
{
	state = kInLogin;

	Core::String info;
	info.RefStrGrow(128, 128).format("%d,%s", character_id, character_name);
	bot->ResponseAction(AC_LEAVE_LOBBY, RC_SUCCESSED, info);
}

// response channel connect
void LobbyConnection::ResponseChannelConnect()
{
	int result;
	int channel_id;
	ushort port;
	char address[16];
	byte isudp = false;

	ReadInt(result);

	if (result == 0)
	{
		ReadInt(channel_id);
		ReadShort(port);
		ReadString(address, sizeof(address));
		ReadByte(isudp);

		Core::String info;
		info.RefStrGrow(128, 128).format("%d,%d,%s", channel_id, port, address);
		bot->OnLoginChannel(uid, character_id, character_name, channel_id, address, port);
	}
	else
	{
		bot->ResponseAction(AC_ENTER_CHANNEL, RC_FAILED, "channel_not_valid");
	}
}


// request chat
void LobbyConnection::RequestChat(const Core::Identifier & to, const Core::String & msg)
{
	if (state > kInLogin)
	{

		if (msg.Length() > 0)
		{
			Core::CStrBuf<32> to_str(to.Str());
			Core::CStrBuf<64> msg_str(msg.Str());
			msg_str.validate();

			BeginWrite();
			WriteByte(CM_RequestChat);
			WriteString(to_str);
			WriteString(msg_str);
			EndWrite();
		}
	}
}

// request create NickName
void LobbyConnection::RequestCreateNickName(const Core::String & args)
{
	if (state == kAuthentication)
	{
		BeginWrite();
		WriteString(args.Str());
		EndWrite();
	}
}

// response chat
void LobbyConnection::NotifyChat()
{
}

// notify fcm
void LobbyConnection::NotifyFCM()
{
	int online_minutes;
	ReadInt(online_minutes);
	const char * message = NULL;


	static struct notify
	{
		int time;
		const char * message;
	} notifies [] =
	{
		{ 60,	"���ۼ�����ʱ������1Сʱ", },
		{ 120,	"���ۼ�����ʱ������2Сʱ", },
		{ 180,	"���ۼ�����ʱ������3Сʱ, ���Ѿ�����ƣ����Ϸʱ�䣬������Ϸ���潫��Ϊ����ֵ��50����Ϊ�����Ľ������뾡��������Ϣ�����ʵ���������������ѧϰ����", },
		{ 210,	"���Ѿ�����ƣ����Ϸʱ�䣬������Ϸ���潫��Ϊ����ֵ��50����Ϊ�����Ľ������뾡��������Ϣ�����ʵ���������������ѧϰ����", },
		{ 240,	"���Ѿ�����ƣ����Ϸʱ�䣬������Ϸ���潫��Ϊ����ֵ��50����Ϊ�����Ľ������뾡��������Ϣ�����ʵ���������������ѧϰ����", },
		{ 270,	"���Ѿ�����ƣ����Ϸʱ�䣬������Ϸ���潫��Ϊ����ֵ��50����Ϊ�����Ľ������뾡��������Ϣ�����ʵ���������������ѧϰ����", },
		{ 300,	"���ѽ��벻������Ϸʱ�䣬Ϊ�����Ľ�������������������Ϣ���粻���ߣ��������彫�ܵ��𺦣����������ѽ�Ϊ�㣬ֱ�������ۼ�����ʱ����5Сʱ�󣬲��ָܻ�����", },
	};

	for (int i = 0; i < ELEMENTS_OF(notifies); i ++)
	{
		if (online_minutes >= notifies[i].time)
			message = notifies[i].message;
	}

	// 		gGame->machine.OnFCM(online_minutes, message);
}

// force disconnect
void LobbyConnection::ForceDisconnect()
{
	ReadString(error_message);
	Disconnect();
}

// team invite
void LobbyConnection::RequestTeamInvite(const Core::String & name)
{
	BeginWrite();
	WriteByte(CM_RequestTeamInvite);
	WriteString(name);
	EndWrite();
}


// team join
void LobbyConnection::RequestTeamJoin(const Core::String & name, uint uid)
{
	BeginWrite();
	WriteByte(CM_RequestTeamJoin);
	WriteString(name);
	WriteInt(uid);
	EndWrite();
}

// team leave
void LobbyConnection::RequestTeamLeave()
{
	BeginWrite();
	WriteByte(CM_RequestTeamLeave);
	EndWrite();
}

// team kick
void LobbyConnection::RequestTeamKick(const Core::String & name)
{
	BeginWrite();
	WriteByte(CM_RequestTeamKick);
	WriteString(name);
	EndWrite();
}

// team change leader
void LobbyConnection::RequestTeamChangeLeader(const Core::String & name)
{
	BeginWrite();
	WriteByte(CM_RequestTeamChangeLeader);
	WriteString(name);
	EndWrite();

}

// request team refuse
void LobbyConnection::RequestTeamRefuse(const Core::String & name, uint uid)
{
	BeginWrite();
	WriteByte(CM_RequestTeamRefuse);
	WriteString(name);
	WriteInt(uid);
	EndWrite();
}

// response team invite
void LobbyConnection::ResponseTeamInvite()
{
}

// response team invite
void LobbyConnection::ResponseTeamJoin()
{
}

// notify team invite
void LobbyConnection::NotifyTeamInvite()
{
}

// notify team member join
void LobbyConnection::NotifyTeamMemberJoin()
{
}

// notify team member leave
void LobbyConnection::NotifyTeamMemberLeave()
{
}

// notify team change leader
void LobbyConnection::NotifyTeamChangeLeader()
{
}

// notify team member info
void LobbyConnection::NotifyTeamMemberInfo()
{
}

// notify team change leader
void LobbyConnection::NotifyTeamLeave()
{
}

// notify team change leader
void LobbyConnection::NotifyTeamRefuse()
{
}


// request refresh server list
void LobbyConnection::RequestRefreshServerList()
{
	BeginWrite();
	WriteByte(CM_RequestRefreshServerList);
	EndWrite();
}

// request refresh server list
void LobbyConnection::RequestRefreshChannelList()
{
	BeginWrite();
	WriteByte(CM_RequestRefreshChannelList);
	EndWrite();
}


// notify refresh server list
void LobbyConnection::NotifyRefreshServerList()
{
	Core::String info;

	uint server_count;
	ReadInt(server_count);
	
	m_mapServerInfos.clear();

	for (uint i = 0; i < server_count; i ++)
	{
		ServerInfo oInfo;

		ReadInt(oInfo.id);
		ReadString(oInfo.name);
		ReadInt(oInfo.online_count);
		ReadInt(oInfo.online_max);
		ReadByte(oInfo.isnovice);
		ReadString(oInfo.gametype_limit);

		info.RefStrGrow(32, 32).contractf("%d ", oInfo.id);


		uint dwServerType = 0;
		//ReadInt(dwServerType);
		uint dwChannelcount = 0;
		//ReadInt(oInfo.Channelcount);
		
		oInfo.servertype = (ServerType)dwServerType;
		
		m_mapServerInfos[oInfo.id] = oInfo;
	}

	bot->ResponseAction(AC_SERVER_LIST, RC_SUCCESSED, info);
}

// notify refresh channel list
void LobbyConnection::NotifyRefreshChannelList()
{
	Core::String info;

	uint channel_count;
	ReadInt(channel_count);

	for (uint i = 0; i < channel_count; i ++)
	{
		uint id;
		Core::String name;
		byte is_online;
		uint online_count;
		uint online_max;
		uint max_level;
		uint min_level;

		ReadInt(id);
		ReadString(name);
		ReadByte(is_online);
		ReadInt(online_count);
		ReadInt(online_max);

		ReadInt(min_level);
		ReadInt(max_level);

		info.RefStrGrow(32, 32).contractf("%d ", id);
	}

	bot->ResponseAction(AC_CHANNEL_LIST, RC_SUCCESSED, info);
}


// request enter server
void LobbyConnection::RequestEnterServer(int server_id)
{
	BeginWrite();
	WriteByte(CM_RequestEnterServer);
	WriteInt(server_id);
	EndWrite();
}

// request leave server
void LobbyConnection::RequestLeaveServer()
{
	BeginWrite();
	WriteByte(CM_RequestLeaveServer);
	EndWrite();
}

// notify update level list
void LobbyConnection::NotifyUpdateLevelList()
{
	int level_count = 0;
	ReadInt(level_count);

	for (int i = 0; i < level_count; i++)
	{
		sharedc_ptr(LevelInfo) info = ptr_new LevelInfo;

		LevelInfo& test = *info;

		ReadInt(info->id);
		ReadString(info->name);
		ReadByte((byte&)info->type);

		ReadString(info->show_name);
		ReadString(info->description);

		ReadByte(info->is_vip);
		ReadByte(info->is_new);
		ReadInt(info->gai_lv);

		ReadByte(info->is_gm);

		level_list.PushBack(info);
	}
}

// parse lua rpc
Lua::LuaState * LobbyConnection::LoadRPCResults(int action, const Core::String & code)
{
	Lua::LuaState *L = Lua::LuaState::NewState();
	const char * ret = L->DoString(code, 0, 0);

	if (ret)
	{
		L->Close();
		bot->ResponseAction(action, RC_FAILED, ret);
		return NULL;
	}

	L->GetGlobal("error");
	Core::String err(L->ToString(-1));
	if (err.Length())
	{
		L->Close();
		bot->ResponseAction(action, RC_FAILED, err);
		return NULL;
	}

	L->SetTop(0);
	return L;
}


// response team call
void LobbyConnection::NotifyTeamCall()
{
	Core::String leader_name;
	ClientAddress address;

	ReadString(leader_name);
	ReadInt(address.server_id);
	ReadInt(address.channel_id);
	ReadInt(address.room_id);
}


// request search room
void LobbyConnection::RequestSearchRoom(RoomSearchOptions & options)
{
	BeginWrite();
	WriteByte(CM_RequestSearchRoom);
	WriteInt(options.game_type);
	WriteInt(options.level_id);
	WriteByte(options.num_clients);
	WriteByte(options.playing);
	WriteByte(options.waiting);
	EndWrite();
}
// request search room
void LobbyConnection::RequestCancelSearchRoom()
{
	BeginWrite();
	WriteByte(CM_RequestCancelSearchRoom);
	EndWrite();
}

// response search room
void LobbyConnection::ResponseSearchRoom()
{
	byte result;
	ReadByte(result);

	if (result == 0)
	{
		uint server_id;
		uint channel_id;
		uint room_id;

		ReadInt(server_id);
		ReadInt(channel_id);
		ReadInt(room_id);
	}
	else
	{
	}
}


// notify room preserve
void LobbyConnection::NotifyRoomPreserve()
{
}

// notify room cancel preserve
void LobbyConnection::NotifyRoomCancelPreserve()
{
}


// response team call
void LobbyConnection::ResponseTeamCall()
{
}

// response enter server
void LobbyConnection::ResponseEnterServer()
{
	int result;
	uint server_id;
	Core::String server_name;

	ReadInt(result);
	ReadInt(server_id);
	ReadString(server_name);
	
	selected_server_id = server_id;
	if (bot->channel_connection)
	{
		bot->channel_connection->address.server_id = server_id;
	}

	if (result == 0)
		bot->ResponseAction(AC_ENTER_SERVER, RC_SUCCESSED, Core::String::Format("%d", server_id));
	else
		bot->ResponseAction(AC_ENTER_SERVER, RC_FAILED, Core::String::Format("%d", result));
}

// response leave server
void LobbyConnection::ResponseLeaveServer()
{
	selected_server_id = 0;
	if (bot->channel_connection)
	{
		bot->channel_connection->address.server_id = 0;
	}
	bot->ResponseAction(AC_LEAVE_SERVER, RC_SUCCESSED, "");
}

// notify refuse call
void LobbyConnection::NotifyRPCMessage()
{
}
// notify refuse call
void LobbyConnection::NotifyRefusePreserve()
{
}

void Client::LobbyConnection::RequestLestPersonChannel( uint server_id )
{
	BeginWrite();
	WriteByte(CM_RequestLestPersonChannel);
	WriteInt(server_id);
	EndWrite();
}

void Client::LobbyConnection::OnResponseLestPersonChannel()
{
	uint battle_server_id;
	uint battle_channel_id;
	ReadInt(battle_server_id);
	ReadInt(battle_channel_id);
	
	{
		bot->action_running_flags.SetBit(AC_ENTER_MATCH, false);
		bot->action_running_flags.SetBit(AC_ENTER_CHANNEL, true);
		
		RequestChannelConnect(battle_channel_id);
	}
}

void Client::LobbyConnection::RequestMatching()
{
	LogSystem.WriteLinef("%s, %s, name : %s", __FILE__, __FUNCTION__, character_name);
	BeginWrite();
	WriteByte(CM_RequestMatching);
	EndWrite();
}

void Client::LobbyConnection::OnResponseMatchingTeamCreate()
{
	uint matchid;
	ReadInt(matchid);
	
	bot->action_running_flags.SetBit(AC_CREATE_MATCH_TEAM, false);

	RequestMatching();
}

void Client::LobbyConnection::RequestMatchingTeamCreate( uint server_id, uint channel_id, uint room_id, RoomOption &roomop )
{
	BeginWrite();
	WriteByte(CM_RequestMatchingTeamCreate);
	WriteInt(server_id);
	WriteInt(channel_id);
	WriteInt(room_id);
	WriteRoomOption(*this, roomop);
	EndWrite();
}

void Client::LobbyConnection::OnResponseMatching()
{
	uint result = 0;
	ReadInt(result);
	LogSystem.WriteLinef("%s, %s, name : %s, result : %d", __FILE__, __FUNCTION__, character_name, result);
	
	if (result)
	{
		RequestMatching();
	}
}
