namespace Client
{
	class ChannelConnection : public Core::BinaryNetworkStream, public Core::TcpConnection
	{
	public:
		enum State
		{
			kIdle,
			kConnected,
			kInChannel,
			kInRoom,
			kInGame,
			kInBalance,
		};

		enum AddUIEffect
		{
			kRecoverNone 		= 0,
			kRecoverSupplyHp	= 1,
			kRecoverCuregun		= 2,
			kRecoverSelf		= 3,
			kSupplyAmmo_1		= 4,
			kSupplyAmmo_2		= 5,
			kRecoverFire		= 6,
			kRecoverVehicle		= 7,
		};


		enum GameState
		{
			kAuthentication,
			kLoading,
			kWaiting,
			kAlive,
			kDied,
			kGameEnd,

			kGameLeaving,
		};

		enum HornSystemMessageType
		{
			kHornHoldPointLeft60sMessage,
			kHornHoldPointSuccessMessage,
			kHornKillMaster,
			kHornPushVehicleStartMessage,
			kHornPushVehicleHalfMessage,
			kHornPushVehicleAlmostSuccessMessage,
		};

	public:
		// constructor.
		ChannelConnection();

		// destructor
		virtual ~ChannelConnection();

		// get state
		State GetState() { return (State)state; }

	private:
		/*
		// read room info
		void ReadRoomInfo(RoomInfo & info);

		// read client info
		void ReadClientInfo(ClientInfo & info);

		// write room option
		void WriteRoomOption(const RoomOption & option);

		// read room option
		void ReadRoomOption(RoomOption & option);

		// read room info
		void ReadRoomSlot(RoomSlot & slot);
		*/

		void WriteCharacterPosition(const Core::Vector3 & position);
		void ReadCharacterPosition(Core::Vector3 & position);

		void WriteCharacterRotation(const Core::Quaternion & rotation);
		void ReadCharacterRotation(Core::Quaternion & rotation);
		void ReadCharacterRotation(Core::BinaryNetworkReader & reader, Core::Quaternion & rotation);

	public:
		// on disconnected
		virtual void OnDisconnected(bool is_error);

		// request channel enter
		void RequestChannelEnter();

		// reuqest channel leave
		void RequestChannelLeave();

		// request room list
		void RequestRoomList();

		// request room create
		void RequestRoomCreate(const RoomOption & option);

		// request room enter
		void RequestRoomEnter(int room_id, const char* password = NULL);

		// request room leave
		void RequestRoomLeave();

		//requeset room client list
		void RequestRoomClientList();

		// request room change option
		void RequestRoomChangeOption(const RoomOption & option);

		// request room change team
		void RequestRoomChangeTeam(byte team);

		// request room change slot
		void RequestRoomChangeSlot(byte slot_id);

		// request room change slot status
		void RequestRoomChangeSlotStatus(byte slot_id, RoomSlot::Status status);

		// request room ready
		void RequestRoomReady(bool ready);

		// request game start
		void RequestGameStart();

		// request game enter
		void RequestGameEnter();

		// request chat
		void RequestChat(const Core::Identifier & to, const Core::String & msg);

		// request room kick client
		void RequestRoomKickClient(byte id_in_room);
		
		
		
		
		
		
		

		// response channel enter
		void ResponseChannelEnter();

		// response room list
		void ResponseRoomList();

		// response room create
		void ResponseRoomCreate();

		// response room enter
		void ResponseRoomEnter();

		// response room leave
		void ResponseRoomLeave();

		// response room client list
		void ResponseRoomClientList();

		// response room change option
		void ResponseRoomChangeOption();

		// response room change team
		void ResponseRoomChangeTeam();

		// response room change team
		void ResponseRoomChangeSlot();

		// response room change slot status
		void ResponseRoomChangeSlotStatus();

		// response room ready
		void ResponseRoomReady();

		// response game start
		void ResponseGameStart();

		// response game enter
		void ResponseGameEnter();
		
		
		
		
		
		

		// notify channel client enter
		void NotifyChannelClientEnter();

		// notify channel client leave
		void NotifyChannelClientLeave();

		// notify room create
		void NotifyRoomCreate();

		// notify room close
		void NotifyRoomClose();

		void NotifyRoomList();

		// notify room client enter
		void NotifyRoomClientEnter();

		// notify room client leave
		void NotifyRoomClientLeave();

		// notify room host changed
		void NotifyRoomHostChanged(Core::BinaryNetworkReader & reader);

		// notify room change option
		void NotifyRoomChangeOption();

		// notify room state changed
		void NotifyRoomStateChanged();

		// notify room client count changed
		void NotifyRoomClientCountChanged();

		// notify room change team
		void NotifyClientChangeTeam();

		// notify room client ready
		void NotifyClientReady();

		// notify game start
		void NotifyGameStart();

		// notify game client enter 
		void NotifyGameClientEnter();

		// notify game client leave
		void NotifyGameClientLeave();

		// notify game start
		void NotifyGameEnd();

		// notify game leave
		void NotifyGameLeave(Core::BinaryNetworkReader & reader);

		// notify chat
		void NotifyChat(Core::BinaryNetworkReader & reader);

		// notify room kick client
		void NotifyRoomKickClient();

		// notify client change slot
		void NotifyClientChangeSlot();

		// notify room change slot status;
		void NotifyRoomChangeSlotStatus();

	private:
		// parse message
		void OnMessage();

		// on connected
		void OnConnected();

		// on enter channel
		void OnEnterChannel();

		// on leave channel
		void OnLeaveChannel();

		// on enter room
		void OnEnterRoom();

		// on leave room
		void OnLeaveRoom();

		// on room list changed
		void OnRoomListChanged();

		// on room client list changed
		void OnRoomClientListChanged();

		// on room option changed
		void OnRoomOptionChanged();

		// on update level list
		void OnUpdateLevelList();

	public:
		uint lobby_uid;
		uint character_id;
		Core::String character_name;

		Core::Array<sharedc_ptr(RoomInfo)>	room_list;
		Core::Array<sharedc_ptr(ClientInfo)>	client_list;
		Core::FixedArray<RoomSlot, 16> room_slots;
		Core::HashSet<RoomOption::GameType, Core::String>	game_description_set;

	public:
		// get game state
		uint GetGameState() { return game_state; }

		// on game enter
		void OnEnterGame();

		// on game leave
		void OnLeaveGame(bool stage_clear);

		// on enter game balance
		void OnEnterBalance();

		// on leave game balance
		void OnLeaveBalance();

		// on game end
		void OnGameEnd();

		// on message game
		void OnMessageGame();

		// sync player data
		void SyncPlayerData();

		// shoot
		void Shoot(const Core::Vector3& position, const Core::Quaternion& direction, byte uid = 0, byte part = 0, float distance = 0.f);

		void SelectWeapon(uint uid);

		// game start
		void ReadyForGame();

		// reload
		void Reload();

		// leave game
		void LeaveGame();

		void NotifyRoomClientUpdate();

	private:
		// parse authentication
		void ParseAuthentication(Core::BinaryNetworkReader & reader);

		// parse character info
		void ParseCharacterInfo(Core::BinaryNetworkReader & reader);

		// parse sync game
		void ParseInitialize(Core::BinaryNetworkReader & reader);

		// parse sync player data
		void ParseSyncCharacterData(Core::BinaryNetworkReader & reader);

		// parse player join
		void ParsePlayerJoin(Core::BinaryNetworkReader & reader);

		// parse player leave
		void ParsePlayerLeave(Core::BinaryNetworkReader & reader);

		// parse spawn
		void ParseSpawn(Core::BinaryNetworkReader & reader);

		// parse sync time
		void ParseSyncTime(Core::BinaryNetworkReader & reader);

		// parse game end
		void ParseGameEnd(Core::BinaryNetworkReader & reader);

		// parse game leave
		void ParseGameLeave(Core::BinaryNetworkReader & reader);

		// parse set team
		void ParseSetTeam(Core::BinaryNetworkReader & reader);

		void ParseShoot(Core::BinaryNetworkReader & reader);

		void ParseSelectWeapon(Core::BinaryNetworkReader & reader);

	private:
		State state;
		uint game_state;	

	public:
		Client::ClientAddress address;
		RoomInfo room_info;

		int game_win_team;
		int round_win_team;

		int channel_id;

	public:
		byte player_status;
		byte player_weapon;
		float player_sync_time;
		Core::Vector3 player_position;
		Core::Quaternion player_rotation;

		int career;

		uint ping_time;
		ushort player_ping;

		// network encoder
		Core::XORNetworkEncoder xor_encoder;
		// network compressor
		Core::HuffmanNetworkCompressor huffman_compressor;

		//tcp only
		double pingback_time;
		bool ping_send;

	public:
		//sharedc_ptr(StateLobby)	m_OwnerLobby;
		tempc_ptr(Bot::Robot) bot;
		RoomOption default_room_option;//���������Ĭ�Ϸ�ʽ
		//RoomInfo   my_room_info;   //��ǰ�������Ϣ
		byte ingame_uid;

		bool has_level_list;


		byte game_type;
	};
}