#include "pch.h"

// global session
Session session;

// constructor
Session::Session()
: id(0)
{
}

// load session
bool Session::Load(const char * filename)
{
	Core::CriticalSectionLock lock(cs);

	// clear first.
	Clear();

	// load session file
	Core::Buffer * buff = Core::Utilities::LoadFile(filename);

	if (!buff)
		return false;

	char* pMemoryPos = (char*)buff->GetBufferPointer();
	uint dwFileLength = buff->GetBufferSize();

	int iRemberPos = 0;
	char szSessionID[256];
	char szSessionValue[256];

	for (uint i = 0; i < dwFileLength; ++i)
	{
		if( *(pMemoryPos + i) == '^' && *(pMemoryPos + i + 1) == '$' && *(pMemoryPos + i + 2) == '^')
		{
			memset( szSessionID, 0, 256);
			memcpy( szSessionID, pMemoryPos + iRemberPos, i - iRemberPos );
			iRemberPos = i + 3;
		}

		if( *(pMemoryPos + i) == '\r' && *(pMemoryPos + i + 1) == '\n')
		{
			memset(szSessionValue, 0, 256);
			memcpy(szSessionValue, pMemoryPos + iRemberPos, i - iRemberPos);

			name_array.PushBack(szSessionID);
			value_array.PushBack(szSessionValue);

			i += 2;
			iRemberPos = i;
		}
	}

	buff->Release();

	return true;
}

// clear
void Session::Clear()
{
	Core::CriticalSectionLock lock(cs);

	id = 0;
	name_array.Clear();
	value_array.Clear();
}

// next
bool Session::Next(Core::String & name, Core::String & value)
{
	Core::CriticalSectionLock lock(cs);

	if (name_array.Size())
	{
		name = name_array[id];
		value = value_array[id];

		if (++id == name_array.Size())
			id = 0;

		return true;
	}

	return false;
}