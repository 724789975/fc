﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Collections;
using System.Text.RegularExpressions;

namespace ConsoleApplication3
{
    struct StringData
    {
       public String str_data;
       public String filename;
       public int line;
    }




    class Program
    {
        static ArrayList str_Array = new ArrayList();

        static bool IsChineseLetterUTF8(String input)
        {
            int code = 0;
            int chfrom = Convert.ToInt32("4e00", 16);
            int chend = Convert.ToInt32("9fff", 16);
            for (int i = 0; i < input.Length; i++)
            {
                if (input != "")
                {
                    code = Char.ConvertToUtf32(input, i);

                    if (code >= chfrom && code <= chend)
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        static bool CheckExist(String str)
        {
            for (int i = 0; i < str_Array.Count; i++)
            {
                StringData data = (StringData)str_Array[i];

                if (str == data.str_data)
                {
                    return true;
                }
            }
            return false;
        }

        static bool FileClear(String filename)
        {
            FileStream fs = new FileStream(filename, FileMode.Open);
            if (fs == null)
                return false;

            StreamReader objReader = new StreamReader(fs);

            String sData = "";
            String sDataAfter = "";
            String mark = "lang:GetText(";

            int current = 0;

            sData = objReader.ReadToEnd();
            while (current < sData.Length)
            {
                int start = sData.IndexOf(mark, current);



                if (start == -1)
                {
                    if (current < sData.Length)
                    {
                        sDataAfter += sData.Substring(current, sData.Length - current);
                    }
                    break;
                }
                sDataAfter += sData.Substring(current, start - current);
                current = start + 1;



                int end = sData.IndexOf("\")", current);

                if (end == -1)
                {
                    break;
                }
                current = end + 2;

                String subStr = sData.Substring(start + mark.Length, end - start - mark.Length);

                sDataAfter += (subStr + "\"");
                //if (IsChineseLetterUTF8(subStr) && subStr.Length > 1)
                {
                    

                    //String temp = subStr.Substring(1, subStr.Length - 1);
                    //if (!CheckExist(temp))
                    //{
                    //    StringData data = new StringData();
                    //    data.str_data = temp;
                    //    str_Array.Add(data);
                    //}

                }
                //else
                //{
                //    sDataAfter += (subStr + "\"");
                //}
            }
            objReader.Close();
            fs.Close();

            FileStream fs1 = new FileStream(filename, FileMode.Create);
            StreamWriter objwriter = new StreamWriter(fs1);
            objwriter.Write(sDataAfter);
            objwriter.Close();
            fs1.Close();

            return true;
        }

        static bool FileReplace(String filename)
        {
            FileStream fs = new FileStream(filename, FileMode.Open);
            if (fs == null)
                return false;

            StreamReader objReader = new StreamReader(fs);

            String sData = "";
            String sDataAfter = "";

            int current = 0;

            sData = objReader.ReadToEnd();
            while (current < sData.Length)
            {
                int start = sData.IndexOf("\"", current);
                

                if (start == -1)
                {
                    if (current < sData.Length)
                    {
                        sDataAfter += sData.Substring(current, sData.Length - current);
                    }
                    break;
                }
                sDataAfter += sData.Substring(current, start - current);
                current = start + 1;

                

                int end = sData.IndexOf("\"", current);

                if (end == -1)
                {
                    break;
                }
                current = end + 1;

                String subStr = sData.Substring(start, end - start);

                if (IsChineseLetterUTF8(subStr) && subStr.Length > 1)
                {
                    sDataAfter += ("lang:GetText(" + subStr + "\")");
                    
                    String temp = subStr.Substring(1, subStr.Length - 1);
                    if (!CheckExist(temp))
                    {
                        StringData data = new StringData();
                        data.str_data = temp;
                        str_Array.Add(data);
                    }

                }
                else
                {
                    sDataAfter += (subStr + "\"");
                }
            }
            objReader.Close();
            fs.Close();
            
            FileStream fs1 = new FileStream(filename, FileMode.Create);
            StreamWriter objwriter = new StreamWriter(fs1);
            objwriter.Write(sDataAfter);
            objwriter.Close();
            fs1.Close();


            return true;
        }

        public static void ListFiles(FileSystemInfo info,int Action)
        {
            if (!info.Exists) return;

            DirectoryInfo dir = info as DirectoryInfo;
           
            if (dir == null) return;

            FileSystemInfo[] files = dir.GetFileSystemInfos();
            for (int i = 0; i < files.Length; i++)
            {
                FileInfo file = files[i] as FileInfo;

                if (file != null)
                {
                    //非目录
                    String type = file.Name.Substring(file.Name.Length - 3, 3);
                    if (type == "lua")
                    {
                        switch (Action)
                        {
                            case 0:
                                FileReplace(file.DirectoryName + "\\" + file.Name);
                                break;
                            case 1:
                                FileClear(file.DirectoryName + "\\" + file.Name);
                                break;
                        }
                    }
                }
                else
                {
                    ListFiles(files[i],Action);
                }
            }
        } 



        static void Main(string[] args)
        {
            Console.Write("请输入要查询的目录:   ");
            string dir = Console.ReadLine();
            //string dir = "c://test//";

           


            try
            {
                Console.Write("是否执行清理工作 ？          Y/N\r\n");
                ConsoleKeyInfo result = Console.ReadKey();

                if (result.KeyChar.ToString() == "Y" || result.KeyChar.ToString() == "y")
                {
                    ListFiles(new DirectoryInfo(dir), 1);
                }
                Console.Write("\r\n是否生成 ？          Y/N \r\n");

                result = Console.ReadKey();

                if (result.KeyChar.ToString() == "Y" || result.KeyChar.ToString() == "y")
                {
                    ListFiles(new DirectoryInfo(dir), 0);
                }
            }
            catch (IOException e)
            {
                Console.WriteLine(e.Message);
            }
            
            FileStream fs = new FileStream("tes.log", FileMode.Create);
            StreamWriter writer = new StreamWriter(fs);

            writer.WriteLine("languages = ");
            writer.WriteLine("{");

            for (int i = 0; i < str_Array.Count; i++)
            {
                StringData data = (StringData)str_Array[i];
                
                Console.WriteLine(data.str_data);
                writer.Write("  {\"" + data.str_data + "\" ,\"" + data.str_data + "\"},\r\n"); 
            }
            writer.WriteLine("}");

            writer.Close();
            fs.Close();
            Console.ReadLine();
        }
    }
}
