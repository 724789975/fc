#include "pch.h"

using namespace Core;

static bool MountPath(const char * path, Path::VFSAccess access, int priority)
{
	CStrBuf<MAX_PATH> temp;

	if (path == NULL)
		return false;

	// current directory
	if (path[0] == '~')
	{
		// current folder
		GetCurrentDirectoryA(temp.size32(), temp.buff());
		temp.calclen();
		temp.contract(path + 1);

		Path::MountVFS("/", temp.buff(), access, priority);
		return Path::Exists(temp.buff());
	}
	else
	{
		// get module file name
		GetModuleFileNameA(NULL, temp.buff(), temp.size32());
		Path::GetFilePath(temp, temp.buff());

		// convert to physical path
		temp.contract(path);

		Path::MountVFS("/", temp.buff(), access, priority);
		return Path::Exists(temp.buff());
	}

	return false;
}

static int lua_exit(Lua::LuaState *L)
{
	Thread::Quit();
	return 0;
}

static int lua_set_timer(Lua::LuaState *L)
{
	sharedc_ptr(Task) task = Lua::ToPtr<Core::Task>(L, 1);
	double time = L->ToNumber(2);

	if (task)
	{
		Task::Schedule(task, time);
	}
	return 0;
}

static BOOL HandlerRoutine(DWORD dwCtrlType)
{
	if (dwCtrlType == CTRL_CLOSE_EVENT)
	{
		Thread::Quit(Thread::MainThread());
		return TRUE;
	}
	return FALSE;
}


int main(int argc, char ** argv)
{
	SetConsoleCtrlHandler( (PHANDLER_ROUTINE)HandlerRoutine, TRUE );

#ifndef MASTER
	Path::UnmountVFS("/");

	// develop data path
	if (!MountPath("../../../data/bot", Path::kVirtualReadWrite, 0))
	{
		// release data path
		MountPath("data/bot", Path::kVirtualReadWrite, 0);
	}
#endif

	srand(time(NULL));

	// initialize thread
	Thread::Initialize();

	// init module system
	Module::Initialize();

	// initialize net
	SocketStream::Initialize();

	if (argc < 2)
	{
		LogSystem.WriteLine("usage : bot_test script_name.lua");
		return 1;
	}

	Lua::LuaState::FromThread()->PushCFunction(lua_exit);
	Lua::LuaState::FromThread()->SetGlobal("exit");

	Lua::LuaState::FromThread()->PushCFunction(lua_set_timer);
	Lua::LuaState::FromThread()->SetGlobal("set_timer");

	int serverid = -1;
	int channelid = -1;
	Array<CStrBuf<256>> run_files;

	for (int i = 1; i < argc; i ++)
	{
		if (_stricmp(argv[i], "-serverid") == 0)
		{
			if (++i < argc)
			{
				CStrBuf<256> arg(argv[i]);
				serverid = atoi(arg);
				continue;
			}
		}
		else if (_stricmp(argv[i], "-channelid") == 0)
		{
			if (++i < argc)
			{
				CStrBuf<256> arg(argv[i]);
				channelid = atoi(arg);
				continue;
			}
		}
		else
		{
			run_files.PushBack(CStrBuf<256>(argv[i]));
		}
	}

	if (serverid > -1)
	{
		Lua::LuaState::FromThread()->PushInteger(serverid);
		Lua::LuaState::FromThread()->SetGlobal("serverid");
	}

	if (channelid > -1)
	{
		Lua::LuaState::FromThread()->PushInteger(channelid);
		Lua::LuaState::FromThread()->SetGlobal("channelid");
	}

	for (int i = 0; i < (int)run_files.Size(); i++)
	{
		LogSystem.WriteLinef("run : %s", run_files[i]);
		Lua::LuaState::FromThread()->DoFile(run_files[i]);
	}

	try
	{
		while (Thread::Running())
		{
			sharedc_ptr(Task) msg = Task::Receive();

			if (msg)
			{
				Task::Dispatch(msg);
			}
		}

	}
	catch (String & err)
	{
		LogSystem.WriteLinef("bot_test : core exception : %s", err.Str());
	}

	// stop modules
	Module::StopAll();

	// unload modules
	Module::Terminate();

	// terminate thread
	Thread::Terminate();

	return 0;
}