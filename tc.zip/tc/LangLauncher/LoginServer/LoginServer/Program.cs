﻿using System;
using System.Collections;
using System.Text;
using System.Threading;
using System.IO;
using System.Net;
using System.Net.Sockets;

using LumenWorks.Framework.IO.Csv;

namespace LoginServer
{
    class Program
    {
        private static Hashtable m_Data;

        public static void WorkerFun(Object obj)
        {
            Console.WriteLine("WorkerFun Start");

            TcpClient client = (TcpClient)obj;

            try
            {
                StreamReader reader = new StreamReader(client.GetStream(), Encoding.UTF8);

                string usr_name = reader.ReadLine();
                string usr_pwd = reader.ReadLine();

                StreamWriter writer = new StreamWriter(client.GetStream(), Encoding.UTF8);

                string[] data = m_Data[usr_name] as string[];

                if (data != null)
                {
                    if (data[0] == usr_pwd)
                    {
                        writer.WriteLine("TRUE");
                        writer.WriteLine(data[1]);
                    }
                    else
                    {
                        writer.WriteLine("FALSE");
                        writer.WriteLine("PWD_ERROR");
                    }
                }
                else
                {
                    writer.WriteLine("FALSE");
                    writer.WriteLine("NO_USER");
                }

                writer.Flush();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.StackTrace);
            }

            Console.WriteLine("WorkerFun End");

            client.Close();
        }

        static void Main(string[] args)
        {
            if (args.Length != 3)
            {
                Console.WriteLine("LoginServer ip port csvfile\n");

                return;
            }

            const int CSV_USERNAME = 0;
            const int CSV_PWD = 1;
            const int CSV_VALUE = 2;
            const int CSV_FIELD_COUNT = 3;

            CsvReader csv = new CsvReader(new StreamReader(args[2]), false);
            m_Data = new Hashtable();

            while (csv.ReadNextRecord())
            {
                try
                {
                    if (csv.FieldCount == CSV_FIELD_COUNT)
                    {
                        string key = csv[CSV_USERNAME];

                        string[] data = new string[2];
                        data[0] = csv[CSV_PWD];
                        data[1] = csv[CSV_VALUE];

                        m_Data.Add(key, data);
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.StackTrace);
                }
            }

            TcpListener listener = new TcpListener(IPAddress.Parse(args[0]), Int32.Parse(args[1]));

            try
            {
                listener.Start();
            }
            catch (SocketException e)
            {
                Console.WriteLine(e.StackTrace);
            }

            while (true)
            {
                try
                {
                    TcpClient client = listener.AcceptTcpClient();

                    ThreadPool.QueueUserWorkItem(new WaitCallback(Program.WorkerFun), client);
                }
                catch (SocketException e)
                {
                    Console.WriteLine(e.StackTrace);
                }
            }
        }
    }
}
