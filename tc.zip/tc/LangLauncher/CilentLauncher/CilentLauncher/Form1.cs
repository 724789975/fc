﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net;          
using System.Net.Sockets;
using System.IO;
using System.Diagnostics;


namespace CilentLauncher
{

    public partial class Form1 : Form
    {
        TcpListener listener;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SendLoginMessage();

            button1.Enabled = false;
        }

        private void SendLoginMessage()
        {
            TcpClient client = new TcpClient();
            try
            {
                int num = int.Parse(textBox2.Text);
                client.Connect(textBox1.Text, num);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return;
            }

            Console.WriteLine("Server Connected");

            string name = textBox3.Text;
            string passwd = textBox4.Text;
               
            StreamWriter writer = new StreamWriter(client.GetStream(), Encoding.UTF8);
            StreamReader reader = new StreamReader(client.GetStream(), Encoding.UTF8);
            
            writer.WriteLine(name);
            writer.WriteLine(passwd);

            writer.Flush();

            Console.WriteLine("Wait Response!!!");

            string ret1 = reader.ReadLine();
            string ret2 = reader.ReadLine();
            
            if(ret1 == "TRUE")
            {
                string mFilePath = Application.StartupPath + "\\FinalCombat.exe";
                                
                string []args = new string[6];
                args[0] = "-proxysvrip ";
                args[1] = textBox5.Text;
                args[2] = " -proxysvrport ";
                args[3] = textBox6.Text;
                args[4] = " -login ";
                args[5] = ret2;

                string Arguments = String.Concat(args);
                Process.Start(mFilePath, Arguments);
            }
            else
            {
                MessageBox.Show("Login Failed");
            }

            Application.Exit();

        }
    }
}
