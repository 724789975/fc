﻿using System;
using System.Collections;
using System.Text;
using System.Threading;
using System.IO;
using System.Net;
using System.Net.Sockets;

using LumenWorks.Framework.IO.Csv;

namespace LoginInfoServer
{
    class UserKey
    {
        public int uid;
        public string key;

        public void FromStream(Stream stream)
        {
            BinaryReader reader = new BinaryReader(stream);

            uid = reader.ReadInt32();

            int str_len = reader.ReadInt32();
            key = Encoding.UTF8.GetString(reader.ReadBytes(str_len));
        }
    }

    class UserData
    {
        public static readonly UserData kEmpty = new UserData();

        public string account = "";
        public short account_type;
        public short vip_level;
        public short bar_level;

        public void ToStream(Stream stream)
        {
            BinaryWriter writer = new BinaryWriter(stream);

            byte[] buffer = Encoding.UTF8.GetBytes(account);
            writer.Write((int)buffer.Length);
            writer.Write(buffer);

            writer.Write(account_type);

            writer.Write(vip_level);

            writer.Write(bar_level);
        }
    }

    class UserInfo
    {
        public int uid;
        public byte is_success;
        public UserData data;

        public void ToStream(Stream stream)
        {
            BinaryWriter writer = new BinaryWriter(stream);

            writer.Write(uid);

            writer.Write(is_success);

            data.ToStream(stream);
        }
    }

    class Program
    {
        private static Hashtable m_Data;

        public static void WorkerFun(Object obj)
        {
            Console.WriteLine("WorkerFun Start");

            TcpClient client = (TcpClient)obj;

            try
            {
                StreamUtil stream_util = new StreamUtil(client.GetStream());
                
                UserKey key = new UserKey();
                UserInfo info = new UserInfo();

                byte[] pkg;
                while ((pkg = stream_util.ReadPkg()) != null)
                {
                    key.FromStream(new MemoryStream(pkg));

                    Console.WriteLine("Key : " + key.key);

                    UserData usr_dat = m_Data[key.key] as UserData;

                    info.uid = key.uid;
                    if (usr_dat != null)
                    {
                        info.is_success = 1;
                        info.data = usr_dat;
                    }
                    else
                    {
                        info.is_success = 0;
                        info.data = UserData.kEmpty;
                    }

                    MemoryStream stream = new MemoryStream();
                    info.ToStream(stream);

                    stream_util.WritePkg(stream.ToArray());
                }
            }
            catch (EndOfStreamException)
            {
            }
            catch (Exception e)
            {
                Console.WriteLine(e.StackTrace);
            }

            client.Close();

            Console.WriteLine("WorkerFun End");
        }

        static void Main(string[] args)
        {
            if (args.Length != 3)
            {
                Console.WriteLine("LoginInfoServer ip port csvfile\n");

                return;
            }

            const int CSV_USERKEY = 0;
            const int CSV_USERACCOUNT = 1;
            const int CSV_ACCOUNTTYPE = 2;
            const int CSV_VIPLEVEL = 3;
            const int CSV_BARLEVEL = 4;

            const int CSV_FIELD_COUNT = 5;

            CsvReader csv = new CsvReader(new StreamReader(args[2]), false);
            m_Data = new Hashtable();

            while (csv.ReadNextRecord())
            {
                try
                {
                    if (csv.FieldCount == CSV_FIELD_COUNT)
                    {
                        string key = csv[CSV_USERKEY];

                        UserData data = new UserData();
                        data.account = csv[CSV_USERACCOUNT];
                        data.account_type = Int16.Parse(csv[CSV_ACCOUNTTYPE]);
                        data.vip_level = Int16.Parse(csv[CSV_VIPLEVEL]);
                        data.bar_level = Int16.Parse(csv[CSV_BARLEVEL]);
                        
                        m_Data.Add(key, data);
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.StackTrace);
                }
            }

            Console.WriteLine("LoginInfoServer Start\n");

            TcpListener listener = new TcpListener(IPAddress.Parse(args[0]), Int32.Parse(args[1]));

            try
            {
                listener.Start();
            }
            catch (SocketException e)
            {
                Console.WriteLine(e.StackTrace);
            }

            while (true)
            {
                try
                {
                    TcpClient client = listener.AcceptTcpClient();

                    ThreadPool.QueueUserWorkItem(new WaitCallback(Program.WorkerFun), client);
                }
                catch (SocketException e)
                {
                    Console.WriteLine(e.StackTrace);
                }
            }
        }
    }
}
