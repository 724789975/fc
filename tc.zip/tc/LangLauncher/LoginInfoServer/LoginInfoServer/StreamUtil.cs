﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace LoginInfoServer
{
    class StreamUtil
    {
        private BinaryWriter m_Writer;
        private BinaryReader m_Reader;

        private const ushort MAGICNUM = 21314;
        private const int MAGICNUM_SIZE = 2;
        private const int PKGLENGHT_SIZE = 2;
        private const int HEAD_SIZE = MAGICNUM_SIZE + PKGLENGHT_SIZE;
        private const int MAX_PKGSIZE = 64 * 1024;

        public StreamUtil(Stream base_stream)
        {
            m_Writer = new BinaryWriter(base_stream);
            m_Reader = new BinaryReader(base_stream);
        }

        public byte[] ReadPkg()
        {
            ushort magic_num = m_Reader.ReadUInt16();
            if (magic_num != MAGICNUM)
            {
                throw new IOException("magic_num incorrect");
            }

            ushort pkg_size = m_Reader.ReadUInt16();
            if (pkg_size < HEAD_SIZE)
            {
                throw new IOException("pkg_size incorrect");
            }

            pkg_size -= HEAD_SIZE;

            return m_Reader.ReadBytes(pkg_size);
        }

        public void WritePkg(byte[] pkg)
        {
            long pkg_size32 = pkg.Length + HEAD_SIZE;
            if (pkg_size32 > MAX_PKGSIZE)
            {
                throw new IOException("pkg too big");
            }

            m_Writer.Write(MAGICNUM);
            m_Writer.Write((ushort)pkg_size32);
            m_Writer.Write(pkg);

            m_Writer.Flush();
        }
    }
}
